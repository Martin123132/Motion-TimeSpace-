from density_stage import ROOT,SEAL,ROUTES,MODES,SETTINGS,guard,locked,record,freeze,digest
import csv,re,ast
import numpy as np
def rows(name):
    with (ROOT/name).open() as stream:return list(csv.DictReader(stream))
def verify():
    guard()
    for name in ('density-freeze.json','source-freeze.json','photon-freeze.json'):locked(name)
    for mode in MODES:
        for split in (2,4):
            with np.load(ROOT/f'density-{mode}-{split}.npz') as f,np.load(ROOT/f'impulse-{mode}-{split}.npz') as out:
                assert np.array_equal(f['time'],out['gravity']) and np.array_equal(f['time'],out['grid'][::split])
                assert f['routes'].tolist()==list(ROUTES) and f['mismatch'].shape==(2,len(f['time']))
                assert np.isfinite(f['density']).all() and np.isfinite(out['photon']).all()
    ds=rows('density-scores.csv');gs=rows('physical-gates.csv');ps=rows('photon-scores.csv');cs=rows('photon-controls.csv')
    assert (len(ds),len(gs),len(ps),len(cs))==(28,36,60,122)
    for r in ds:assert r['passes']==str(max(float(r[k]) for k in ('rms_error_pct','peak_error_pct'))<=.5)
    for r in gs:
        assert r['component_pass']==str(max(float(r[k+'_pct']) for k in ('energy','current','joint'))<=.5)
        assert r['size_pass']==str(max(float(r[k+'_launch_pct']) for k in ('momentum','differentiated'))<.163)
    for r in ps:assert r['agreement']==str(max(float(r[k+'_error_pct']) for k in ('energy','current','joint'))<=.5)
    for r in cs:assert r['passes']==str(float(r['relative'])<=.005)
    assert all(float(r['entry_e_relative'])<=.005 and float(r['entry_j_relative'])<=.005 and float(r['filter_relative'])<=.005 for r in rows('switch-controls.csv'))
    for s in SETTINGS:assert all(float(r['relative'])<=.005 for r in rows(f'quadrature-{s}.csv'))
    for name in re.findall(r'\]\(([^)]+)\)',(ROOT/'RESULTS.md').read_text(encoding='utf8')):assert (ROOT/name).is_file()
    for script in ROOT.glob('*.py'):ast.parse(script.read_text(encoding='utf8'))
    assert not list(ROOT.rglob('__pycache__'))
    record('validation.json',dict(prior=SEAL,density_checks=len(ds),photon_controls=len(cs),photon_controls_passed=sum(r['passes']=='True' for r in cs),fidelity_scores=len(ps),passed_forecast_scores=sum(r['agreement']=='True' for r in ps),physical_gates=len(gs),passed_physical_component_gates=sum(r['component_pass']=='True' for r in gs),passing_absolute_size_gates=sum(r['size_pass']=='True' for r in gs),density_freeze=digest(ROOT/'density-freeze.json'),photon_freeze=digest(ROOT/'photon-freeze.json')))
    freeze('seal.json',sorted(p.name for p in ROOT.iterdir() if p.is_file() and p.name!='seal.json'));print(digest(ROOT/'seal.json'))
if __name__=='__main__':verify()
