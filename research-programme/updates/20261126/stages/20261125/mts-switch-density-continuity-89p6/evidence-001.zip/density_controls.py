from density_stage import ROOT,locked,guard,MODES,ROUTES
from inputs_density import np,io,stage_u
from score_density import rels,rms
from scipy.interpolate import CubicSpline
io.ROOT=ROOT
def evaluate():
    guard();locked('photon-freeze.json');results=[];refs={};fore={}
    for mode in MODES:
        with np.load(stage_u.pin(f'matter-{mode}.npz')) as packet,np.load(ROOT/f'density-{mode}-4.npz') as f:
            keys=packet['keys'].tolist();time=f['time'];state=packet['states']
            actual=state[:,keys.index('hf')]+3*state[:,keys.index('geom')]
            avg=f['mean'][:,0];ref=avg-actual;refs[mode]=(time,ref)
            fore[mode]=f['mismatch'].copy()
            for name,pred in [('follow_phase_average',np.zeros_like(ref)),('hold_switch_density',avg-f['density'][0,0]),('hold_switch_mismatch',np.full_like(ref,f['mismatch'][0,0]))]:
                er,ep,end=rels(pred,ref,time);results.append(dict(clock=mode,test=name,rms_pct=er,peak_pct=ep,end_over_peak_pct=end,passes=bool(max(er,ep)<=.5)))
    coarse=refs['p16'][0];fine=refs['p32'][0]
    for name,co,fi in [('saved mismatch',refs['p16'][1],refs['p32'][1])]+[(name,fore['p16'][i],fore['p32'][i]) for i,name in enumerate(ROUTES)]:
        aligned=CubicSpline(fine,fi,extrapolate=False)(coarse);er,ep,end=rels(co,aligned,coarse)
        results.append(dict(clock='p16 vs p32',test=name,rms_pct=er,peak_pct=ep,end_over_peak_pct=end,passes=bool(max(er,ep)<=.5)))
    io.table('density-controls.csv',results);print(results)
if __name__=='__main__':evaluate()
