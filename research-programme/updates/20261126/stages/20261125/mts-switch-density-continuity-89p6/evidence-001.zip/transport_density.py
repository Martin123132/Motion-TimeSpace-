from density_stage import ROOT,guard,pin,locked,freeze,SETTINGS
from types import SimpleNamespace
from unittest.mock import patch
pin('transport_pair.py')
from transport_pair import io,gate,transport,np
io.ROOT=ROOT
def packet(mode,unused):
    with np.load(ROOT/f'impulse-{mode}-4.npz') as fine,np.load(ROOT/f'impulse-{mode}-2.npz') as half:
        grid=fine['grid'];assert np.array_equal(grid[::2],half['grid'])
        cols={}
        for i,label in enumerate(fine['labels'].tolist()):
            for j,key in enumerate(('pair','total')):
                cols[label+'_'+key]=fine['photon'][i,:,j]/np.diff(grid)
                cols['half_'+label+'_'+key]=np.repeat(half['photon'][i,:,j]/np.diff(half['grid']),2)
        return SimpleNamespace(time=fine['gravity'],knots=grid,values=np.column_stack(list(cols.values())),keys=list(cols)),None
if __name__=='__main__':
    guard();locked('density-freeze.json');locked('source-freeze.json')
    with patch.object(transport,'ROOT',ROOT),patch.object(transport,'source',packet):
        for setting in SETTINGS:transport.project(setting);print(setting,flush=True)
    freeze('photon-freeze.json',['source-freeze.json']+[f'photons-{s}.npz' for s in SETTINGS])
