import csv
from density_stage import ROOT,pin,guard,locked,SETTINGS,MODES,ROUTES
from inputs_density import stage_u,np,io
from transport_density import gate
from cell89 import pin as legacy
from scipy.interpolate import CubicSpline
io.ROOT=ROOT
def rms(vec,time):
    w=np.diff(time);return np.sqrt(np.sum(w*(abs(vec[1:])**2+abs(vec[:-1])**2)/2)/sum(w))
def rels(value,ref,time):
    return (100*rms(value-ref,time)/rms(ref,time),100*np.max(abs(value[1:]-ref[1:]))/np.max(abs(ref[1:])),100*abs(value[-1]-ref[-1])/max(np.max(abs(ref[1:])),1e-99))
def density_score():
    rows=[];control=[];cache={}
    for mode in MODES:
        with np.load(stage_u.pin(f'matter-{mode}.npz')) as f:
            keys=f['keys'].tolist();vals=f['states'];actual=vals[:,keys.index('hf')]+3*vals[:,keys.index('geom')];j=vals[:,keys.index('hw')];time=f['eta']
        for split in (2,4):
            with np.load(ROOT/f'density-{mode}-{split}.npz') as f:
                assert np.array_equal(f['time'],time)
                target=f['mean'][:,0]-actual
                assert rms(target,time)>0
                for idx,route in enumerate(ROUTES):
                    assert np.max(abs(f['mismatch'][idx]-(f['mean'][:,0]-f['density'][idx])))<1e-8*np.max(abs(target))
                    for quantity,val,ref in [('mismatch',f['mismatch'][idx],target),('density',f['density'][idx],actual),('current',f['current'][idx],j)]:
                        er,ep,end=rels(val,ref,time)
                        rows.append(dict(mode=mode,split=split,route=route,quantity=quantity,rms_error_pct=er,peak_error_pct=ep,end_error_over_peak_pct=end,passes=bool(max(er,ep)<=.5)))
                    control.append(dict(mode=mode,split=split,route=route,entry_e_relative=abs(f['density'][idx,0]-actual[0])/max(abs(actual[0]),1e-99),entry_j_relative=abs(f['current'][idx,0]-j[0])/max(abs(j[0]),1e-99),filter_relative=f['filter_error'][idx],momentum_vs_constraint_metric_peak=np.max(abs(f['phi_minus_constraint'][idx]))))
                    cache[mode,split,route]=f['mismatch'][idx].copy()
        for route in ROUTES:
            er,ep,end=rels(cache[mode,2,route],cache[mode,4,route],time)
            rows.append(dict(mode=mode,split='2vs4',route=route,quantity='mismatch',rms_error_pct=er,peak_error_pct=ep,end_error_over_peak_pct=end,passes=bool(max(er,ep)<=.5)))
    io.table('density-scores.csv',rows);io.table('switch-controls.csv',control)
def photon_score():
    _,axis,w,_=gate.proj.old.get_media();measure=gate.previous.make_measure(axis,w)
    mag=lambda v:gate.mag(v,measure)
    with gate.pin(gate.FROZEN,'window-readouts.csv').open() as fp:
        launch={r['gravity']:float(r['launch_norm']) for r in csv.DictReader(fp) if r['model']=='MTS-minus-baseline' and r['output']=='joint'}
    scores=[];gates=[];controls=[];cache={};labels=['filtered']+[route+'_'+k for route in ROUTES for k in ('density','both')]
    def check(mode,setting,k,er):
        worst=float(np.max(er));controls.append(dict(mode=mode,setting=setting,test=k,relative=worst,passes=worst<=.005))
    for s in SETTINGS:
        name='photons-'+s+'.npz'
        with np.load(ROOT/name) as f,np.load(pin('reference/'+name)) as measured,np.load(pin('forecast/'+name)) as archived,np.load(legacy('photon-'+s+'.npz')) as original:
            grid=f['scale'];assert all(np.array_equal(grid,c) for c in (measured['scale'],archived['scale'],original['grid']))
            project=lambda z:CubicSpline(grid,z)(axis)
            for idx,mode in enumerate(MODES):
                def terms(bank):
                    vec=project(bank['values'][:,idx,0]);return {k:vec[:,i] for i,k in enumerate(bank['channels'].tolist())}
                ref=terms(measured);guess=terms(f);old=terms(archived)
                loc=original['labels'].tolist().index([mode,'primary']);mom=project(original['values'][:,loc,:3].sum(1));den=mag(mom)
                for key in ('pair','total'):
                    check(mode,s,'reproduce filtered '+key,mag(guess['filtered_'+key]-old['filtered_'+key])/mag(old['filtered_'+key]))
                    target=ref['actual_'+key]
                    for label in labels:
                        value=guess[label+'_'+key];error=mag(value-target)/mag(target)
                        share=np.sum(measure@(value*target.conj()).real)/mag(target)[2]**2
                        scores.append(dict(mode=mode,setting=s,entry=label,channel=key,energy_error_pct=100*error[0],current_error_pct=100*error[1],joint_error_pct=100*error[2],signed_share=share,agreement=bool(max(error)<=.005)))
                        check(mode,s,'half vs quarter '+label+' '+key,mag(guess['half_'+label+'_'+key]-value)/mag(value))
                        cache[mode,s,label,key]=value
                for label in ['actual']+labels:
                    vec=(ref if label=='actual' else guess)[label+'_total']
                    pct=100*mag(vec)/den;pm=100*den[2]/launch[mode];pd=100*mag(mom+vec)[2]/launch[mode]
                    gates.append(dict(mode=mode,setting=s,entry=label,energy_pct=pct[0],current_pct=pct[1],joint_pct=pct[2],component_pass=bool(max(pct)<=.5),momentum_launch_pct=pm,differentiated_launch_pct=pd,size_pass=bool(max(pm,pd)<.163)))
    for mode in MODES:
        for label in labels:
            for key in ('pair','total'):
                base=cache[mode,'primary',label,key]
                for what,mo,s in [('time',mode,'time'),('angle',mode,'angle')]+([('gravity','p16','primary')] if mode=='p32' else []):
                    check(mode,s,what+' '+label+' '+key,mag(base-cache[mo,s,label,key])/mag(base))
    for name,rows in [('photon-scores.csv',scores),('physical-gates.csv',gates),('photon-controls.csv',controls)]:io.table(name,rows)
if __name__=='__main__':
    guard()
    for name in ('density-freeze.json','source-freeze.json','photon-freeze.json'):locked(name)
    density_score();photon_score()
