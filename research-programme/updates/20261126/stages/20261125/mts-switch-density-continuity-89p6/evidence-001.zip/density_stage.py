from pathlib import Path
import hashlib,json,sys
ROOT=Path(__file__).resolve().parent
PRIOR=ROOT.parent/'mts-coupled-wave-metric-work-89p6-20261125'
SEAL='027606b94dd3e758a922ac8a7db1d4cabb2075b0224469bee70b624405e3d3d8'
MODES=('p16','p32')
ROUTES=('momentum','constraint')
SETTINGS=('primary','time','angle')
def digest(path):
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
assert digest(PRIOR/'seal.json')==SEAL
files=json.loads((PRIOR/'seal.json').read_bytes())['files']
def pin(name):
    p=PRIOR/name;assert digest(p)==files[name],name
    return p
def guard():
    assert all(not (p/'STOP-REQUESTED').exists() for p in (ROOT,PRIOR))
def record(name,value):
    p=ROOT/name
    if p.exists():assert json.loads(p.read_bytes())==value
    else:p.write_text(json.dumps(value,indent=2,sort_keys=True,allow_nan=False)+'\n',encoding='utf8')
def freeze(name,names):
    record(name,dict(prior=SEAL,files={n:digest(ROOT/n) for n in names}))
def locked(name):
    receipt=json.loads((ROOT/name).read_bytes());assert receipt['prior']==SEAL
    for n,h in receipt['files'].items():assert digest(ROOT/n)==h,n
sys.path.insert(0,str(PRIOR));pin('paired_stage.py')
