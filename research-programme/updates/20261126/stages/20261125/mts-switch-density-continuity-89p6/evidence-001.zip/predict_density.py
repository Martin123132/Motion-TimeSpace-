from density_stage import ROOT,guard,record,freeze,MODES,ROUTES
from inputs_density import prepare,NativeMean,subgrid,io,np,Blind
def phi_constraint(solver,env,physical):
    energy,j=solver.aggregate(env,physical[:,:-1]);kk=solver.kk
    return (env[1]['U']-energy/2-1.5*env[0]['h']*j/kk)/env[-1]
def operator(solver,src,t,side,mean,route):
    env=src.environment(t,side);clean=(env[0],{k:v for k,v in env[1].items() if k!='U'},*env[2:])
    av,rate=mean.at(t);n=len(t);size=13
    def rhs(state):
        x=state.copy();x[:,-3]+=av[:,0]
        if route=='constraint':x[:,-1]=phi_constraint(solver,env,x)
        slope=solver.rhs(clean,x);slope[:,-3]-=rate[:,0]
        if route=='constraint':slope[:,-1]=0
        return slope
    zero=np.zeros((n,size),complex);inh=rhs(zero);op=np.zeros((n,size+1,size+1),complex)
    op[:,:-1,-1]=inh
    for k in range(size):
        one=zero.copy();one[:,k]=1
        op[:,:-1,k]=rhs(one)-inh
    return op,rate[:,0]
def integrate(mode,split):
    src,wave,entry,clock=prepare(mode);base=src.time;grid=subgrid(base,split)
    mean=NativeMean(wave,src,clock,grid)
    cuts=np.unique(np.r_[grid,src.corners[(src.corners>grid[0])&(src.corners<grid[-1])]])
    av,_=mean.at(cuts);assert np.all(np.isfinite(av))
    solver=Blind(src);states=[];mis=[];curr=[];co=[];checks=[]
    for route in ROUTES:
        x=np.r_[entry.copy(),1+0j];x[-4]-=av[0,0];trajectory=[x.copy()];filter_integral=[av[0,0]]
        for first in range(0,len(cuts)-1,160):
            last=min(first+160,len(cuts)-1);lo=cuts[first:last];hi=cuts[first+1:last+1];width=hi-lo
            mid=(lo+hi)/2;times=(lo,lo+width/3,hi-width/3,hi)
            ops=[operator(solver,src,t,mid,mean,route) for t in times]
            dt=width[:,None,None];identity=np.eye(len(x))
            first_rate=ops[0][0];second=ops[1][0]@(identity+dt*first_rate/3)
            third=ops[2][0]@(identity+dt*(second-first_rate/3))
            fourth=ops[3][0]@(identity+dt*(first_rate-second+third))
            change=dt*(first_rate+3*second+3*third+fourth)/8
            delta_filter=width*(ops[0][1]+3*ops[1][1]+3*ops[2][1]+ops[3][1])/8
            for step,df in zip(change,delta_filter):
                x=x+step@x;trajectory.append(x.copy());filter_integral.append(filter_integral[-1]+df)
        z=np.array(trajectory)[:,:-1];flat=z[:,-3]+av[:,0];j=z[:,-2]
        actual=z.copy();actual[:,-3]=flat
        env=src.environment(cuts);con=phi_constraint(solver,env,actual)
        phi=con if route=='constraint' else z[:,-1]
        density=flat+3*phi;mismatch=-z[:,-3]-3*phi
        assert np.isfinite(z).all() and np.isfinite(density).all()
        scale=np.max(abs(av[:,0]-av[0,0]));er=float(np.max(abs(filter_integral-av[:,0]))/scale)
        assert er<=.005,(mode,route,er)
        sel=np.searchsorted(cuts,base);assert np.array_equal(cuts[sel],base)
        states.append(density[sel]);mis.append(mismatch[sel]);curr.append(j[sel]);co.append((phi-con)[sel]);checks.append(er)
    mean_base=mean.at(base)[0]
    io.pack(f'density-{mode}-{split}.npz',time=base,mean=mean_base,density=states,mismatch=mis,current=curr,phi_minus_constraint=co,entry=entry,filter_error=checks,routes=ROUTES)
    print(mode,split,'endpoint derivative integration:',checks,flush=True)
if __name__=='__main__':
    guard()
    for mode in MODES:
        for split in (2,4):integrate(mode,split)
    freeze('density-freeze.json',['PROTOCOL.md','density_stage.py','inputs_density.py','predict_density.py']+[f'density-{m}-{s}.npz' for m in MODES for s in (2,4)])
