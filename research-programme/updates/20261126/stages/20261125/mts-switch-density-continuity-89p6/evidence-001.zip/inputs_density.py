from density_stage import ROOT,guard,pin
from functools import lru_cache
from zipfile import ZipFile
pin('forecast_pair.py')
from forecast_pair import np,io,stage_u,Wave,Blind
from required_u import KEYS,Inputs
from blind_native_wave import source
from rebuild_wave import native
from average_heavy import kernel
import inputs_product as ip
from scipy.interpolate import CubicSpline,make_interp_spline
from numpy.lib import format as fmt
io.ROOT=ROOT
def columns(path,names,access):
    allowed=('I2','N2') if access=='drivers' else (*KEYS[:-2],'geom') if access=='readout' else ()
    assert names and set(names)<=set(allowed)
    if access=='readout':
        from density_stage import locked
        locked('density-freeze.json')
    with np.load(path) as meta:keys=meta['keys'].tolist()
    order=sorted((keys.index(k),i) for i,k in enumerate(names))
    with ZipFile(path) as bank,bank.open('states.npy') as stream:
        version=fmt.read_magic(stream);assert version==(1,0)
        shape,fortran,dtype=fmt.read_array_header_1_0(stream);assert not fortran and len(shape)==2 and shape[1]==len(keys)
        offset=stream.tell();out=np.empty((shape[0],len(names)),dtype=dtype)
        for row in range(shape[0]):
            for column,index in order:
                stream.seek(offset+(shape[1]*row+column)*dtype.itemsize)
                out[row,index]=np.frombuffer(stream.read(dtype.itemsize),dtype=dtype)[0]
    return out
class Drivers(Inputs):
    def __init__(self,mode):
        path=stage_u.pin(f'matter-{mode}.npz')
        with np.load(path) as bank:
            self.time=bank['eta'];self.stress=CubicSpline(np.log(bank['stress_clock']),bank['stress']);size=len(bank['keys'])
        self.quads=CubicSpline(self.time,columns(path,['I2','N2'],'drivers'))
        with np.load(ip.companion(mode)) as f:
            self.packet={k:f[k] for k in ('rho0','k2','eta','corners','cs2','companion_pres_res','companion_source_e','companion_source_j','companion_shear')}
        self.flow=ip.matter.get_flow(ip.matter.FLUID,'companion',self.time,np.zeros((size,1,2),complex),self.packet)
        original=self.flow.q;idx=self.flow.qkeys.index('U')
        with np.load(ip.archived('primary.npz')) as data:restore=make_interp_spline(np.log(data['eta']),data['restore'],k=5)
        def forcing(t):
            v=original(t).copy();v[...,idx,0]+=restore(t);return v
        self.flow.q=forcing
        import json
        frozen=json.loads(ip.prior(f'input-audit-{mode}-both.json').read_bytes());sample=forcing(self.flow.log)
        assert ip.array_hash(sample[:,idx])==frozen['U_hash']
        assert all(ip.array_hash(sample[:,self.flow.qkeys.index(k)])==frozen['receipt'][k]['host'] for k in ('Q','Fq'))
        self.wave=float(self.flow.k[0,0]);self.kk=self.wave**2;self.corners=self.packet['corners'];self.coeff=[]
        t=self.packet['eta'];v=np.column_stack((self.packet['cs2'],*[self.packet['companion_'+k][:,0] for k in ('pres_res','source_e','source_j','shear')]))
        for left,right in zip(np.r_[-np.inf,self.corners],np.r_[self.corners,np.inf]):
            select=(t>=left+5e-9)&(t<=right-5e-9);self.coeff.append(CubicSpline(t[select],v[select]))
@lru_cache(maxsize=2)
def prepare(mode):
    guard();ip.guard();src=Drivers(mode);wv=source(mode)
    with np.load(native(f'original-through89/particular-heavy-{mode}.npz')) as earlier:start=earlier['state'][:,:1]
    with np.load(native(f'particular-heavy-{mode}.npz')) as f:
        pre=ip.matter.get_flow(ip.matter.BASE89,'companion',ip.matter.physical_axis(f['eta'],89.,src.time[0]),start)
        _,obs,_,states=pre.evolve(f['stressClock'],f['stress'])
    initial=states[-1,:,0,0];x=np.array([initial[pre.ix[k]] for k in KEYS]+[0j])
    left,ext,_=pre.env(np.log(src.time[0]));vel=left['hv'];pot=(left['a']*left['hm'])**2*left['hb']
    env=src.environment(src.time[:1]);rho=env[-2][0];hub=env[0]['h'][0];den=env[-1][0]
    e=(vel*x[-2]+pot*x[-3]+ext['henergy'][0]+3*vel**2*obs[-1,0,0,0])/rho
    j=(src.kk*vel*x[-3]+ext['hJ'][0])/rho;x[-3]=0;x[-2]=j
    energy,current=Blind(src).aggregate(env,x[None,:-1])
    phi=(env[1]['U'][0]-energy[0]/2-1.5*hub*current[0]/src.kk-rho*e/2)/(den-1.5*rho)
    x[-1]=phi;x[-3]=e-3*phi
    assert np.array_equal(src.time,wv.time)
    clock=kernel.read(mode)[0]
    return src,wv,x,clock

class NativeMean:
    def __init__(self,wave,src,clock,grid):
        self.clock=clock;self.zero=clock(grid[0]);theta=self.theta(grid);assert np.all(np.diff(theta)>0)
        bg,q,*_=wave.environment(grid);fields=wave.interp(grid);hf,hw=fields[:,-3:-1].T;phi=wave.phi(grid)
        rho=src.packet['rho0']/bg['a']
        energy=(bg['hv']*hw+(bg['a']*bg['hm'])**2*bg['hb']*hf+q['henergy']+3*bg['hv']**2*phi)/rho
        current=(src.kk*bg['hv']*hf+q['hJ'])/rho
        vals=np.column_stack((energy,current));self.start=vals[0]
        self.rep=CubicSpline(theta,vals-self.start,extrapolate=False);self.integral=self.rep.antiderivative()
    def theta(self,t):return np.maximum(0,self.clock(t)-self.zero)
    def at(self,t):
        phase=self.theta(t);lo=np.maximum(0,phase-np.pi)
        av=self.start+(self.integral(phase)-self.integral(lo))/np.pi
        rate=self.clock(t,1)[:,None]*(self.rep(phase)-self.rep(lo))/np.pi
        return av,rate
def subgrid(time,split):
    cuts=time[:-1,None]+np.diff(time)[:,None]*np.arange(split)/split
    return np.r_[cuts.ravel(),time[-1]]
