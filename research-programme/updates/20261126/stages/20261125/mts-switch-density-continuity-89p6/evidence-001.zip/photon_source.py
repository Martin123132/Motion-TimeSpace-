from density_stage import ROOT,MODES,ROUTES,pin,guard,locked,freeze
from inputs_density import prepare,columns,stage_u,io,np,KEYS
from forecast_pair import branch
LABELS=('filtered','momentum_density','momentum_both','constraint_density','constraint_both')
def sources(mode,split):
    locked('density-freeze.json')
    src,wave,_,_=prepare(mode);time=src.time
    ordinary=columns(stage_u.pin(f'matter-{mode}.npz'),[*KEYS[:-2],'geom'],'readout')[:-1]
    with np.load(ROOT/f'density-{mode}-{split}.npz') as f:
        assert np.array_equal(time,f['time'])
        mean=f['mean'][:-1];options=[(mean[:,0],mean[:,1])]
        for k in range(len(ROUTES)):
            options.extend([(f['density'][k,:-1],mean[:,1]),(f['density'][k,:-1],f['current'][k,:-1])])
    phi=ordinary[:,-1];states=np.stack([np.column_stack((ordinary[:,:-1],e-3*phi,j,phi)) for e,j in options])
    init=wave.interp(time[:-1]);init[:,-1]=wave.phi(time[:-1])
    wv,dw,grid=branch(wave,init[None],split,True);mat,dm,grid_m=branch(src,states,split,False)
    assert np.array_equal(grid,grid_m);supply=np.diff(src.environment(grid)[1]['U'])/dm-np.diff(wave.environment(grid)[1]['U'])/dw
    delta=wv/dw[None,:,None]-mat/dm[None,:,None]
    pair=delta[:,:,:2].sum(2);total=pair+delta[:,:,2]+supply[None,:]
    assert np.isfinite(total).all()
    io.pack(f'impulse-{mode}-{split}.npz',grid=grid,gravity=time,photon=np.stack((pair,total),axis=2),labels=LABELS)
if __name__=='__main__':
    guard()
    for mode in MODES:
        for split in (2,4):sources(mode,split);print(mode,split,flush=True)
    freeze('source-freeze.json',['density-freeze.json','photon_source.py','transport_density.py']+[f'impulse-{m}-{s}.npz' for m in MODES for s in (2,4)])
