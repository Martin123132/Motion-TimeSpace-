from pathlib import Path
import hashlib,json,sys
ROOT=Path(__file__).resolve().parent
PRIOR=ROOT.parent/'mts-wave-geometric-work-89p6-20261125'
SEAL='816bb5dcbd954f257d06a89f1a4f79f64cb5c64e6ec19639ed21278fac8b66d0'
def digest(path):
    with path.open('rb') as fp:return hashlib.file_digest(fp,'sha256').hexdigest()
assert digest(PRIOR/'seal.json')==SEAL
files=json.loads((PRIOR/'seal.json').read_bytes())['files']
def pin(name):
    path=PRIOR/name;assert digest(path)==files[name],name
    return path
sys.path.insert(0,str(PRIOR));pin('wave_stage.py')
def owner():assert all(not (p/'STOP-REQUESTED').exists() for p in (PRIOR,ROOT))
def manifest():
    names=['average_stage.py','average_heavy.py','PROTOCOL.md']
    names += [f'prediction-{m}-{s}.npz' for m in ('p16','p32') for s in (2,4)]
    return dict(files={n:digest(ROOT/n) for n in names},prior=SEAL)
def frozen():assert json.loads((ROOT/'frozen.json').read_bytes())==manifest()
