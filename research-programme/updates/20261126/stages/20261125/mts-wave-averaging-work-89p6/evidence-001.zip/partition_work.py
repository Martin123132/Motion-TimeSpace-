from average_stage import ROOT,pin,owner,frozen
from average_heavy import setup,MODES,io,np
import wave_stage,stage_u

def partition(mode):
    ctx=setup(mode);split=4
    with np.load(pin(f'blind-{mode}-4.npz')) as blind,np.load(pin(f'work-{mode}-4.npz')) as work,np.load(wave_stage.pin(f'comparison-{mode}-4.npz')) as match,np.load(wave_stage.pin(f'required-{mode}-4.npz')) as req,np.load(stage_u.pin(f'matter-{mode}.npz')) as packet,np.load(ROOT/f'signed-{mode}-4.npz') as signed:
        grid=work['grid'];width=np.diff(work['gravity']);kk=ctx.kk;lo=grid[:-1];hi=grid[1:]
        waveenv=ctx.wave.environment(grid);mat=ctx.matched.environment(grid)
        assert all(z['term_names'].tolist()[:2]==['momentum_metric','changing_D'] for z in (blind,req))
        def heavy_native(t,env,state,sl):
            bg,q=env[:2];hf,hw,phi=state[:,-3:].T
            return ((bg['hv'][sl]*hw+((bg['a']*bg['hm'])**2*bg['hb'])[sl]*hf+q['henergy'][sl]+3*bg['hv'][sl]**2*phi)/2+
                1.5*bg['h'][sl]*(kk*bg['hv'][sl]*hf+q['hJ'][sl])/kk)
        wn=heavy_native(hi,waveenv,blind['end'],slice(1,None))-heavy_native(lo,waveenv,blind['start'],slice(None,-1))
        dm=mat[-1][1:];dw=waveenv[-1][1:];wm=(wn/dw-signed['heavy_target'])*dm
        supply=match['supplied']-work['supplied'];heavy=wn-wm
        phi0=packet['states'][:-1,packet['keys'].tolist().index('geom')]
        change=req['phi_impulse'].reshape(-1,split);mpre=(phi0[:,None]+np.column_stack((np.zeros(len(phi0)),np.cumsum(change,axis=1)[:,:-1]))).ravel()
        dnm=1.5*np.diff(waveenv[0]['hv']**2)*blind['start'][:,-1]+1.5*waveenv[0]['hv'][1:]**2*blind['impulse']
        dmm=1.5*np.diff(mat[-2])*mpre+1.5*mat[-2][1:]*req['phi_impulse']
        metric=(blind['terms'][:,:2].sum(1)-dnm)-(req['terms'][:,:2].sum(1)-dmm)
        other=(blind['terms'][:,2:].sum(1)+dnm-wn)-(req['terms'][:,2:].sum(1)+dmm-wm)
        total=(match['supplied']-match['required'])-(work['supplied']-work['required'])
        assert np.max(abs(supply+heavy+metric+other-total))<1e-8*np.max(abs(total))
        cl=lambda x:x.reshape(-1,split).sum(1)/np.sqrt(width)
        net=cl(total);big=cl(heavy);rows=[]
        for name,vec in dict(supplied_U=supply,required_heavy=heavy,required_other_metric=metric,required_other_energy_and_current=other,net=total).items():
            v=cl(vec);rows.append(dict(mode=mode,term=name,rms_over_net=np.linalg.norm(v)/np.linalg.norm(net),signed_along_heavy=np.vdot(big,v).real/np.vdot(big,big).real))
        return rows
if __name__=='__main__':
    frozen();owner();rows=[r for mode in MODES for r in partition(mode)]
    io.table('partition.csv',rows);print(rows[-5:])
