from average_stage import ROOT,owner,pin,frozen
from types import SimpleNamespace
from unittest.mock import patch
pin('project_wave_work.py')
from project_wave_work import transport,io,gate,MODES,np
io.ROOT=ROOT
def source(mode,unused):
    with np.load(ROOT/f'signed-{mode}-4.npz') as fine,np.load(ROOT/f'signed-{mode}-2.npz') as half:
        grid=fine['grid'];dt=np.diff(grid)
        assert np.array_equal(grid[::2],half['grid']) and np.array_equal(grid[::4],fine['gravity'])
        fields={k:fine[k]/dt for k in fine.files if k not in ('grid','gravity')}
        for k in ('target','heavy_target','pure','fullmap'):
            fields['half_'+k]=np.repeat(half[k]/np.diff(half['grid']),2)
        return SimpleNamespace(time=fine['gravity'],knots=grid,values=np.column_stack(list(fields.values())),keys=list(fields)),None
if __name__=='__main__':
    owner();frozen()
    with patch.object(transport,'ROOT',ROOT),patch.object(transport,'source',source):
        for setting in ('primary','time','angle'):
            transport.project(setting);print(setting,flush=True)
