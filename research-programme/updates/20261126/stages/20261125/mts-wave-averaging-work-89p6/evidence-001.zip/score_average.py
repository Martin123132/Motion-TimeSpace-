from average_stage import ROOT,pin,frozen,owner
from average_heavy import setup,io,np,MODES
from required_u import Blind,KEYS
import wave_stage,stage_u

def score(mode,split):
    ctx=setup(mode)
    with np.load(ROOT/f'prediction-{mode}-{split}.npz') as f,np.load(pin(f'work-{mode}-{split}.npz')) as work,np.load(pin(f'blind-{mode}-{split}.npz')) as blind,np.load(wave_stage.pin(f'comparison-{mode}-{split}.npz')) as matched,np.load(stage_u.pin(f'matter-{mode}.npz')) as packet:
        grid=f['grid'];gravity=f['gravity'];dt=np.diff(grid)
        assert all(np.array_equal(grid,p['grid']) for p in (work,blind,matched))
        assert np.array_equal(f['Dwave'],work['D'])
        dw=f['Dwave'];dm=f['Dmatched'];kk=ctx.kk
        def wave_weight(t,state):
            bg,q,*_=ctx.wave.environment(t);hf,hw,phi=state[:,-3:].T
            energy=bg['hv']*hw+(bg['a']*bg['hm'])**2*bg['hb']*hf+q['henergy']+3*bg['hv']**2*phi
            current=kk*bg['hv']*hf+q['hJ']
            return np.column_stack((energy/2,1.5*bg['h']*current/kk))
        native=np.sum(wave_weight(grid[1:],blind['end'])-wave_weight(grid[:-1],blind['start']),axis=1)
        phi=packet['states'][:-1,packet['keys'].tolist().index('geom')]
        state=np.column_stack((ctx.matched.state[:-1],phi));solver=Blind(ctx.matched);heavy=[];require=[]
        def pair(s):return np.column_stack((s[:,KEYS.index('hf')]+3*s[:,-1],s[:,KEYS.index('hw')]))
        for sub in range(split):
            lo=grid[sub:-1:split];hi=grid[sub+1::split];delta=solver.advance(lo,hi,state)
            require.append(solver.work(lo,hi,state,delta)[0].sum(1))
            wa,_=ctx.weights(lo);wb,_=ctx.weights(hi)
            heavy.append(((wa+wb)*pair(delta)/2+(wb-wa)*pair(state+delta/2)).sum(1))
            state=state+delta
        flatten=lambda parts:np.column_stack(parts).ravel()
        assert np.array_equal(flatten(require),matched['required'])
        match=flatten(heavy);total=(matched['supplied']-matched['required'])-(work['supplied']-work['required'])
        target=work['matched']-work['blind'];heavy_target=native/dw-match/dm
        raw=f['raw_equation'].sum(1);filtered=f['filtered_equation'];saved=f['filtered_saved'];avg=f['averaged_at_matched_weights'];ate=f['average_then_evolve']
        channels=dict(target=target,heavy_target=heavy_target,nonheavy=target-heavy_target,pure=f['commutator']/dm,fullmap=f['complete_photon'],
            pure_energy=(filtered-ate)[:,0]/dm,pure_current=(filtered-ate)[:,1]/dm,
            weighted_vs_saved=(filtered-saved).sum(1)/dm,weight_cov=(saved-avg).sum(1)/dm,closed_evolution=(avg-ate).sum(1)/dm,
            fast_removed=(raw-filtered.sum(1))/dw,den_change=filtered.sum(1)*(1/dw-1/dm),
            native_work_error=(raw-native)/dw,matched_work_error=(match-ate.sum(1))/dm)
        def identity(lhs,rhs):
            assert np.max(np.abs(lhs-rhs))<2e-9*max(np.max(abs(lhs)),np.max(abs(rhs)),np.max(abs(target)))
        identity(target,(matched['supplied']-matched['required'])/dm-(work['supplied']-work['required'])/dw)
        identity(channels['pure'],channels['weighted_vs_saved']+channels['weight_cov']+channels['closed_evolution'])
        identity(channels['fullmap'],channels['pure']+channels['fast_removed']+channels['den_change'])
        identity(channels['fullmap']-heavy_target,channels['native_work_error']+channels['matched_work_error'])
        io.pack(f'signed-{mode}-{split}.npz',grid=grid,gravity=gravity,**channels)
        width=np.diff(gravity);collapse=lambda x:x.reshape(-1,split).sum(1)/np.sqrt(width)
        rows=[]
        for name,actual in [('total',total),('heavy',native-match)]:
            actual=collapse(actual)
            for label,pred in [('order_only',f['commutator']),('complete_map',f['complete_map'])]:
                pred=collapse(pred)
                rows.append(dict(mode=mode,split=split,target=name,prediction=label,signed_share=float(np.vdot(actual,pred).real/np.vdot(actual,actual).real),error_relative=float(np.linalg.norm(actual-pred)/np.linalg.norm(actual)),target_over_supplied=float(np.linalg.norm(actual)/np.linalg.norm(collapse(matched['supplied'])))))
        return rows
if __name__=='__main__':
    owner();frozen();rows=[r for mode in MODES for split in (2,4) for r in score(mode,split)]
    io.table('local-work.csv',rows);print(rows[-4:])
