from average_stage import ROOT,SEAL,digest,pin,owner,frozen
import ast,csv,json
import numpy as np

def table(name):
    with (ROOT/name).open() as fp:return list(csv.DictReader(fp))
def save(name,obj):
    path=ROOT/name
    data=json.dumps(obj,indent=2,sort_keys=True,allow_nan=False)+'\n'
    if path.exists():assert path.read_bytes()==data.encode()
    else:path.write_bytes(data.encode())
def check():
    owner();frozen()
    rows=table('photon-accuracy.csv')
    assert len(rows)==80 and all(r['passes']=='True' and float(r['worst_relative'])<=.005 for r in rows)
    terms=table('partition.csv');assert len(terms)==10
    gates=table('unchanged-gates.csv');assert len(gates)==6
    forecasts=table('photon-scores.csv');assert len(forecasts)==24
    for r in gates:
        assert (max(float(r[k]) for k in ('energy_pct','current_pct','joint_pct'))<=.5)==(r['component_pass']=='True')
        assert (max(float(r[k]) for k in ('momentum_launch_pct','differentiated_launch_pct'))<.163)==(r['size_pass']=='True')
    for r in forecasts:assert (max(float(r[k]) for k in ('energy_error_relative','current_error_relative','joint_error_relative'))<=.005)==(r['agreement']=='True')
    local=table('local-work.csv');assert len(local)==16
    for mode in ('p16','p32'):
        for sub in (2,4):
            with np.load(ROOT/f'prediction-{mode}-{sub}.npz') as pred,np.load(ROOT/f'signed-{mode}-{sub}.npz') as sig,np.load(pin(f'work-{mode}-{sub}.npz')) as old:
                assert np.array_equal(pred['grid'],sig['grid']) and np.array_equal(pred['gravity'],old['gravity']) and np.array_equal(sig['target'],old['matched']-old['blind'])
                assert all(np.isfinite(pred[k]).all() for k in pred.files) and all(np.isfinite(sig[k]).all() for k in sig.files)
                assert pred['pressure_cancel']<1e-12 and max(pred['legacy_filter_relative'])<=.005 and pred['native_filter_rate_relative']<=.005
    for script in ROOT.glob('*.py'):ast.parse(script.read_text(encoding='utf8'))
    for s in ('angle','time','primary'):
        qr=table('quadrature-'+s+'.csv');assert len(qr)==2 and all(float(r['relative'])<.005 for r in qr)
    assert not (ROOT/'__pycache__').exists()
    save('validation.json',dict(prior=SEAL,frozen=digest(ROOT/'frozen.json'),numerical_controls=len(rows),max_control_relative=max(float(r['worst_relative']) for r in rows),forecast_scores=len(forecasts),predictions_passing=sum(r['agreement']=='True' for r in forecasts),unchanged_rate_gates_passing=sum(r['component_pass']=='True' for r in gates),unchanged_absolute_size_gates_passing=sum(r['size_pass']=='True' for r in gates),status='scored; numerical controls pass; physical gates reported separately'))
    save('seal.json',dict(prior=SEAL,files={p.name:digest(p) for p in sorted(ROOT.iterdir()) if p.is_file() and p.name!='seal.json'}))
    print('Seal:',digest(ROOT/'seal.json'))
if __name__=='__main__':check()
