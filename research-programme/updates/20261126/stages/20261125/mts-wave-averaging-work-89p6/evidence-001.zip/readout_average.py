from average_stage import ROOT,pin,owner,frozen
from photons_average import gate,io,MODES,np
from cell89 import pin as legacy
from scipy.interpolate import CubicSpline
import csv

def evaluate():
    _,axis,weights,_=gate.proj.old.get_media();measure=gate.previous.make_measure(axis,weights)
    mag=lambda v:gate.mag(v,measure)
    with gate.pin(gate.FROZEN,'window-readouts.csv').open() as fp:
        launch={r['gravity']:float(r['launch_norm']) for r in csv.DictReader(fp) if r['model']=='MTS-minus-baseline' and r['output']=='joint'}
    scores=[];checks=[];gates=[];cache={};details=[]
    for setting in ('primary','time','angle'):
        name=f'photons-{setting}.npz'
        with np.load(ROOT/name) as data,np.load(pin(name)) as old,np.load(legacy(f'photon-{setting}.npz')) as original:
            grid=data['scale'];assert all(np.array_equal(grid,g) for g in (old['scale'],original['grid']))
            proj=lambda v:CubicSpline(grid,v)(axis)
            for mi,mode in enumerate(MODES):
                col=proj(data['values'][:,mi,0]);terms={k:col[:,j] for j,k in enumerate(data['channels'].tolist())};cache[mode,setting]=terms
                archived=proj(old['values'][:,mi,0,old['channels'].tolist().index('both_blind')])
                mom=proj(original['values'][:,original['labels'].tolist().index([mode,'primary']),:3].sum(1))
                total=terms['target'];heavy=terms['heavy_target'];den=mag(mom)
                def check(label,want,got):
                    rel=mag(want-got)/mag(want)
                    checks.append(dict(mode=mode,setting=setting,test=label,worst_relative=max(rel),passes=bool(max(rel)<=.005)))
                check('archive',archived,total)
                check('heavy plus other',total,heavy+terms['nonheavy'])
                check('pressure-route components',terms['pure'],terms['pure_energy']+terms['pure_current'])
                check('order decomposition',terms['pure'],terms['weighted_vs_saved']+terms['weight_cov']+terms['closed_evolution'])
                check('full decomposition',terms['fullmap'],terms['pure']+terms['fast_removed']+terms['den_change'])
                check('heavy map error',terms['fullmap']-heavy,terms['native_work_error']+terms['matched_work_error'])
                for key in ('target','heavy_target','pure','fullmap'): check('2 vs 4 '+key,terms[key],terms['half_'+key])
                for key,val in terms.items():
                    amp=mag(val)/den*100
                    details.append(dict(mode=mode,setting=setting,channel=key,energy_common_pct=amp[0],current_common_pct=amp[1],joint_common_pct=amp[2]))
                for label,obs in [('total',total),('heavy',heavy)]:
                    for k in ('pure','fullmap'):
                        guess=terms[k];err=mag(obs-guess);norm=mag(obs);dot=measure@(obs.conj()*guess).real
                        scores.append(dict(mode=mode,setting=setting,target=label,forecast=k,joint_signed_share=dot.sum()/norm[2]**2,energy_error_relative=err[0]/norm[0],current_error_relative=err[1]/norm[1],joint_error_relative=err[2]/norm[2],joint_error_common_pct=100*err[2]/den[2],agreement=bool(max(err/norm)<=.005)))
                pp=100*mag(total)/den;momentum=100*den[2]/launch[mode];differentiated=100*mag(mom+total)[2]/launch[mode]
                gates.append(dict(mode=mode,setting=setting,energy_pct=pp[0],current_pct=pp[1],joint_pct=pp[2],component_pass=bool(max(pp)<=.5),momentum_launch_pct=momentum,differentiated_launch_pct=differentiated,size_pass=bool(max(momentum,differentiated)<.163)))
    for mode in MODES:
        for key in ('target','heavy_target','pure','fullmap'):
            for alt,left in [('time',mode),('angle',mode)]+([('primary','p16')] if mode=='p32' else []):
                vec=cache[mode,'primary'][key];other=cache[left,alt][key];er=max(mag(other-vec)/mag(vec))
                checks.append(dict(mode=mode,setting='primary',test=('gravity' if left!=mode else alt)+' '+key,worst_relative=er,passes=bool(er<=.005)))
    for name,rows in [('photon-scores',scores),('photon-accuracy',checks),('unchanged-gates',gates),('photon-terms',details)]:io.table(name+'.csv',rows)
    print([r for r in scores if r['mode']=='p32' and r['setting']=='primary'])
    print('numerical control failures:',[(r['test'],r['worst_relative']) for r in checks if not r['passes']])
if __name__=='__main__':
    owner();frozen();evaluate()
