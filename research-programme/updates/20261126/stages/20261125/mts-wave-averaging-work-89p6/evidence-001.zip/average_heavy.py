from average_stage import ROOT,PRIOR,pin,manifest,owner,sys
from functools import lru_cache
pin('blind_native_wave.py')
from blind_native_wave import source,Wave,MODES,io,np,guard,CubicSpline,peak
from required_u import Inputs
from inputs_product import make_interp_spline,prior as previous_receipt
from rebuild_wave import native
from restore89 import companion
import wave_kernel as kernel
io.ROOT=ROOT
def acquire(mode):
    owner();guard();pin(f'native-{mode}.npz')
    return Context(mode)
class Context:
    def __init__(self,mode):
        self.mode=mode;self.wave=source(mode);self.matched=Inputs(mode);self.kk=self.wave.kk
        assert np.array_equal(self.wave.time,self.matched.time)
        self.clock,self.legacy,_,_,self.rho0=kernel.read(mode)
        assert self.rho0==self.matched.packet['rho0']
        with np.load(native('material-halfstep/forcing-heavy.npz')) as data:
            keys=data['keys'].tolist();self.work=make_interp_spline(np.log(data['eta']),data['values'][[keys.index(k) for k in ('henergy','hJ')],:,0].T,k=5)
    def native_fields(self,t):
        src=self.wave;u=np.log(t);env=src.environment(t);bg,q,stress,_,_,_,_,_ =env
        slopes=dict(zip(src.flow.bgkeys,(src.flow.bg(u,1)/t[:,None]).T))
        x=src.interp(t);x[:,-1]=src.phi(t);solver=Wave(src)
        deriv=solver.rhs(solver.env(t),x)
        field,vel,phi=x[:,-3:].T;fd,vd,pd=deriv[:,-3:].T
        v=bg['hv'];dv=slopes['hv'];h=bg['h'];dh=slopes['h']
        a=bg['a'];da=slopes['a'];mass=bg['hm'];m2=(a*mass)**2;pot=m2*bg['hb']
        potd=2*a*mass*(da*mass+a*slopes['hm'])*bg['hb']+m2*slopes['hb']
        qd=self.work(u,1)/t[:,None];rho=self.rho0/a
        assert peak(self.work(u)[:,0]-q['henergy'])<1e-11*peak(q['henergy'])
        assert peak(self.work(u)[:,1]-q['hJ'])<1e-11*peak(q['hJ'])
        E=v*vel+pot*field+q['henergy']+3*v*v*phi;J=self.kk*v*field+q['hJ']
        press=(v*vel-pot*field+(q['henergy']-q['htrace'])/3+3*v*v*phi)/rho
        Ed=dv*vel+v*vd+potd*field+pot*fd+qd[:,0]+6*v*dv*phi+3*v*v*pd
        Jd=self.kk*(dv*field+v*fd)+qd[:,1]
        work=np.column_stack((E/2,1.5*h*J/self.kk))
        rate=np.column_stack((Ed/2,1.5*(dh*J+h*Jd)/self.kk))
        return np.column_stack((E/rho,J/rho,press)),work,rate
    def theta(self,t):
        return np.maximum(self.clock(t)-self.clock(self.wave.time[0]),0.)
    def rhs(self,t,y,side,probe=0):
        env=self.matched.environment(t,side)
        bg,q,stress,coef,quad,drive,rho,D=env
        h=bg['h'];e,j=y.T
        phi_rate=self.wave.p(t)
        psi=self.psi(t)
        p=coef[0]*(e+3*h*j/self.kk)+coef[1]+probe
        ed=3*phi_rate-j-3*h*p+coef[2];jd=-h*j+self.kk*(p+psi)+coef[3]
        return np.column_stack((ed,jd)),p
    def advance(self,left,right,start):
        dx=np.zeros_like(start)
        for lo,hi in zip(np.r_[-np.inf,self.matched.corners],np.r_[self.matched.corners,np.inf]):
            a=np.maximum(left,lo);b=np.minimum(right,hi);idx=np.flatnonzero(b>a)
            if not len(idx):continue
            a=a[idx];b=b[idx];mid=(a+b)/2;h=(b-a)[:,None];state=start[idx]+dx[idx]
            k1=self.rhs(a,state,mid)[0];k2=self.rhs(mid,state+h*k1/2,mid)[0]
            k3=self.rhs(mid,state+h*k2/2,mid)[0];k4=self.rhs(b,state+h*k3,mid)[0]
            dx[idx]+=h*(k1+2*k2+2*k3+k4)/6
        return dx
    def weights(self,t):
        env=self.matched.environment(t);rho=env[-2];h=env[0]['h']
        return np.column_stack((rho/2,1.5*rho*h/self.kk)),env[-1]
class Filter:
    def __init__(self,context,t):
        self.ctx=context;theta=context.theta(t);assert theta[0]==0 and np.all(np.diff(theta)>0)
        self.state,self.raw,self.rate=context.native_fields(t)
        slopes=CubicSpline(theta,self.rate/context.clock(t,1)[:,None]);primitive=slopes.antiderivative()
        self.work_equation=primitive(theta)-primitive(0)
        values=np.column_stack((self.state,self.raw,self.work_equation))
        self.start=values[0];self.primitive=CubicSpline(theta,values-self.start).antiderivative()
        self.raw_delta=self.work_equation
    def sample(self,t):
        theta=self.ctx.theta(t);lo=np.maximum(0.,theta-np.pi)
        return self.start+(self.primitive(theta)-self.primitive(lo))/np.pi
@lru_cache(maxsize=2)
def setup(mode):
    ctx=acquire(mode)
    with np.load(native(f'particular-heavy-{mode}.npz')) as d:ctx.psi=CubicSpline(d['eta'],d['psi'],extrapolate=False)
    return ctx
def make(mode,split):
    ctx=setup(mode);time=ctx.wave.time;left=time[:-1];right=time[1:]
    cuts=left[:,None]+np.diff(time)[:,None]*np.arange(split+1)/split;cuts[:,-1]=right
    grid=np.r_[cuts[:,:-1].ravel(),right[-1]]
    flt=Filter(ctx,grid);av=flt.sample(grid);state=av[::split,:2][:-1].copy()
    increments=[];pressures=[];cancellation=[];pressure_scale=[]
    for ci in range(split):
        a=cuts[:,ci];b=cuts[:,ci+1];wa,_=ctx.weights(a);wb,_=ctx.weights(b)
        dx=ctx.advance(a,b,state)
        increments.append((wb+wa)*dx/2+(wb-wa)*(state+dx/2))
        rd,p=ctx.rhs(a,state,a);env=ctx.matched.environment(a);h=env[0]['h'];rho=env[-2];co=env[3];e,j=state.T
        formula=rho*((3*ctx.wave.p(a)-j+co[2])/2+1.5*h*(-h*j+ctx.kk*ctx.psi(a)+co[3])/ctx.kk)
        check=(wa*rd).sum(1)-formula
        bump=flt.state[ci:-1:split,2]
        changed,_=ctx.rhs(a,state,a,probe=bump);cancel=(wa*(rd-changed)).sum(1)
        cancellation.extend((peak(check),peak(cancel)));pressure_scale.append(max(peak(wa*rd),peak(wa*changed)))
        pressures.append(p);state=state+dx
    inc=np.stack(increments,axis=1).reshape(-1,2)
    wt,Dm=ctx.weights(grid);Dw=ctx.wave.environment(grid)[-1];dt=np.diff(grid)
    raw=np.diff(flt.raw_delta,axis=0);ea=np.diff(av[:,5:7],axis=0);weighted=np.diff(av[:,3:5],axis=0)
    avg_weights=np.diff(av[:,:2]*wt,axis=0)
    p_m=np.stack(pressures,axis=1).ravel();pres_err=peak(p_m-av[:-1,2])/peak(av[:-1,2])
    comm=ea-inc;removal=raw-ea;total=raw.sum(1)/Dw[1:]-inc.sum(1)/Dm[1:]
    pressure_check=max(cancellation)/max(pressure_scale);assert pressure_check<1e-9
    phi=ctx.theta(grid);sample=av[::max(1,len(av)//50),:3]
    pts=grid[::max(1,len(av)//50)]
    ref,_,_,_=kernel.sample('primary',pts,ctx.clock,ctx.legacy,96,ctx.kk,0.,ctx.rho0)
    legacy=[peak(sample[:,i]-ref[key][:,0])/peak(sample[:,i]) for i,key in enumerate(('e','j','p'))]
    return dict(grid=grid,gravity=time,phase=phi,average_ejp=av[:,:3],closure_p=p_m,Dwave=Dw[1:],Dmatched=Dm[1:],
        raw_equation=raw,filtered_equation=ea,filtered_saved=weighted,averaged_at_matched_weights=avg_weights,average_then_evolve=inc,
        commutator=comm.sum(1),complete_map=raw.sum(1)-inc.sum(1),complete_photon=total,pressure_cancel=pressure_check,
        pressure_difference=pres_err,legacy_filter_relative=legacy,
        native_filter_rate_relative=peak((ea-weighted)/dt[:,None])/peak(ea/dt[:,None]))
if __name__=='__main__':
    owner()
    for mode in MODES:
        for split in (2,4):
            result=make(mode,split);io.pack(f'prediction-{mode}-{split}.npz',**result)
            print(mode,split,'pressure cancellation',result['pressure_cancel'],'legacy',result['legacy_filter_relative'],flush=True)
    io.record('frozen.json',manifest())
