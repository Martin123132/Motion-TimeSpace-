import ast
import csv
import sys
from collections import Counter
from transfer_stage import ROOT, MODES, SETTINGS, locked, guard, sha, freeze, np

def rows(name):
    with (ROOT/name).open() as stream:
        return list(csv.DictReader(stream))
def run(seal):
    guard()
    locked('source-freeze.json')
    locked('prediction-freeze.json')
    inputs = rows('inputs.csv')
    assert len(inputs)==24 and all(float(r['raw_reconstruction_fraction'])<1e-12 for r in inputs)
    comparisons,checks = rows('comparisons.csv'),rows('checks.csv')
    assert Counter(r['test'] for r in comparisons)=={'archived_drift':48,'frozen_drift_plus_saved_remainder':18}
    assert len(checks)==96
    for r in comparisons+checks:
        errs = [float(r[key]) for key in ('energy_pct','current_pct','joint_pct')]
        assert np.all(np.isfinite(errs)) and min(errs)>=0 and (max(errs)<=.5)==(r['passes']=='True')
    scores = rows('readout.csv')
    for setting in SETTINGS:
        quadrature = rows(f'quadrature-{setting}.csv')
        assert {r['mode'] for r in quadrature}==set(MODES) and max(float(r['relative']) for r in quadrature)<=.005
        for mode in MODES:
            selected = [r for r in scores if (r['mode'],r['setting'])==(mode,setting)]
            assert len(selected)==25
            def get(source,channel):
                only, = [r for r in selected if (r['source'],r['channel'])==(source,channel)]
                return float(only['signed_share_late_pct'])
            assert abs(sum(get('saved_only',k) for k in ('osc','partial'))+get('saved','drift')-100)<1e-7
            assert abs(sum(get('forecast',k) for k in ('cycle2','cycle3','cycle4'))-get('forecast','drift'))<1e-7
    for path in ROOT.glob('*.py'):
        ast.parse(path.read_text())
    assert not list(ROOT.rglob('__pycache__'))
    if seal:
        assert (ROOT/'RESULTS.md').is_file()
        freeze('seal.json',sorted(p.name for p in ROOT.iterdir() if p.is_file() and p.name!='seal.json'))
        locked('seal.json')
        print('seal',sha(ROOT/'seal.json'))
    print('verified',len(comparisons),'archive and hybrid comparisons;',len(checks),'controls')
if __name__=='__main__':
    run('--seal' in sys.argv)
