from pathlib import Path
import csv
import hashlib
import io
import json
import math
import sys

import numpy as np

ROOT = Path(__file__).resolve().parent
ARCHIVE = ROOT.parent / 'mts-later-cycle-drift-89p6-20261125'
PAIR = ROOT.parent / 'mts-energy-current-cycles24-89p6-20261125'
THIRD = ROOT.parent / 'mts-cycle3-work-forecast-89p6-20261125'
PINS = {PAIR: 'a9e14134d153d859bf01a5aad0aea95356ad0e31d54edcb0d743b343cb375f01',
        THIRD: '91e4719fb78d5e8cbd7b4fd38b5ad6cf5ca97d550750ae22be07dfa0050685f7',
        ARCHIVE: '83a6b8a7da77140a682dcf332554d12a2c851134581976645fee1bc54cc2705c'}
def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()
def pinned(folder, name):
    assert sha(folder/'seal.json') == PINS[folder]
    path = folder/name
    assert sha(path) == json.loads((folder/'seal.json').read_bytes())['files'][name], name
    return path
def guard():
    assert not any((p/'STOP-REQUESTED').exists() for p in (ROOT, ROOT.parent, *PINS))
def save(name, data):
    guard()
    path = ROOT/name
    if path.exists():
        assert path.read_bytes() == data, name
    else:
        with path.open('xb') as stream:
            stream.write(data)
def freeze(name, files):
    receipt = dict(parents={k.name:v for k,v in PINS.items()}, files={f:sha(ROOT/f) for f in files})
    save(name, (json.dumps(receipt, indent=2, sort_keys=True)+'\n').encode())
def locked(name):
    receipt = json.loads((ROOT/name).read_bytes())
    assert receipt['parents'] == {k.name:v for k,v in PINS.items()}
    for fname, expected in receipt['files'].items():
        assert sha(ROOT/fname) == expected, fname
def table(name, rows):
    stream = io.StringIO()
    writer = csv.DictWriter(stream, rows[0], lineterminator='\n')
    writer.writeheader()
    writer.writerows(rows)
    save(name, stream.getvalue().encode())
def pack(name, **values):
    stream = io.BytesIO()
    np.savez_compressed(stream, **values)
    save(name, stream.getvalue())
def net(mode, branch, sub, cycle):
    folder = THIRD if cycle == 3 else PAIR
    name = (f'forecast-{mode}-{branch}-{sub}.npz' if cycle==3 else f'prediction-{mode}-{branch}-{sub}-cycle{cycle}.npz')
    path = pinned(folder, name)
    receipt = json.loads(pinned(folder,'prediction-freeze.json').read_bytes())
    assert receipt['files'][name] == sha(path)
    with np.load(path) as bank:
        terms = dict(zip(bank['terms'].tolist(),bank['exact'],strict=True))
        keys = ('given_U','heavy','metric','ordinary') if cycle==3 else ('given_U','pair','ordinary')
        values = [terms[k] for k in keys]
        drift = complex(math.fsum(v.real for v in values), math.fsum(v.imag for v in values))
        return float(bank['left']), float(bank['right']), drift
pinned(ARCHIVE,'cycle_stage.py')
sys.path.insert(0,str(ARCHIVE))
from cycle_stage import angular, previous, MODES, SETTINGS
