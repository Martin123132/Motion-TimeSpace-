from scipy.interpolate import CubicSpline

from transfer_stage import ROOT, ARCHIVE, MODES, SETTINGS, pinned, locked, guard, angular, table, np
angular('angular_photons.py')
from angular_photons import gate
from cell89 import pin as original

def run():
    guard()
    locked('source-freeze.json')
    locked('prediction-freeze.json')
    _,axis,weight,_ = gate.proj.old.get_media()
    measure = gate.previous.make_measure(axis,weight)
    def mag(vec):
        return gate.mag(vec,measure)
    def share(vec,ref):
        return 100*(measure@(vec*ref.conj()).real).sum()/mag(ref)[2]**2
    scores,checks,recon = [],[],[]
    forecasts = {}
    def check(rows,mode,setting,kind,channel,actual,expected):
        den = mag(expected)
        assert np.all(den>0)
        error = 100*mag(actual-expected)/den
        assert np.isfinite(error).all()
        rows.append(dict(mode=mode,setting=setting,test=kind,channel=channel,energy_pct=error[0],current_pct=error[1],
                         joint_pct=error[2],passes=bool(max(error)<=.5)))
    for setting in SETTINGS:
        name = f'photons-{setting}.npz'
        with np.load(ROOT/name) as predicted, np.load(pinned(ARCHIVE,name)) as archive, np.load(original(f'photon-{setting}.npz')) as origin:
            grid = predicted['scale']
            assert np.array_equal(grid,archive['scale']) and np.array_equal(grid,origin['grid'])
            for idx,mode in enumerate(MODES):
                def unpack(data):
                    assert data['modes'].tolist()==list(MODES)
                    channels = data['channels'].tolist()
                    vec = CubicSpline(grid,data['values'][:,idx,0])(axis)
                    return dict(zip(channels,vec.swapaxes(0,1),strict=True))
                pred,ref = unpack(predicted),unpack(archive)
                mom = CubicSpline(grid,origin['values'][:,origin['labels'].tolist().index([mode,'primary']),:3].sum(1))(axis)
                norm = mag(mom)
                def record(kind,channel,vec):
                    amplitude = 100*mag(vec)/norm
                    scores.append(dict(mode=mode,setting=setting,source=kind,channel=channel,energy_common_pct=amplitude[0],
                                       current_common_pct=amplitude[1],joint_common_pct=amplitude[2],
                                       signed_share_late_pct=share(vec,ref['late']),signed_share_complete_pct=share(vec,ref['complete'])))
                for prefix in ('','half_'):
                    for channel in ('drift','cycle2','cycle3','cycle4'):
                        target = prefix+channel+('' if channel=='drift' else '_drift')
                        check(recon,mode,setting,'archived_drift',prefix+channel,pred[prefix+channel],ref[target])
                        record('forecast',prefix+channel,pred[prefix+channel])
                        record('saved',target,ref[target])
                    check(checks,mode,setting,'cycle_superposition',prefix+'drift',sum(pred[prefix+k] for k in ('cycle2','cycle3','cycle4')),pred[prefix+'drift'])
                    check(checks,mode,setting,'branch_superposition',prefix+'drift',pred[prefix+'matched']-pred[prefix+'wave'],pred[prefix+'drift'])
                for channel in ('drift','cycle2','cycle3','cycle4','matched','wave'):
                    check(checks,mode,setting,'subdivision',channel,pred['half_'+channel],pred[channel])
                    forecasts[mode,setting,channel] = pred[channel]
                complete = pred['drift']+ref['osc']
                late = complete+ref['partial']
                full = ref['first']+late
                for key,vec in [('complete',complete),('late',late),('full',full)]:
                    check(recon,mode,setting,'frozen_drift_plus_saved_remainder',key,vec,ref[key])
                    record('hybrid',key,vec)
                    record('saved',key,ref[key])
                for key in ('first','osc','partial'):
                    record('saved_only',key,ref[key])
                check(checks,mode,setting,'archive_partition','full',ref['first']+ref['drift']+ref['osc']+ref['partial'],ref['full'])
    for mode in MODES:
        for key in ('drift','cycle2','cycle3','cycle4','matched','wave'):
            base = forecasts[mode,'primary',key]
            for setting in ('time','angle'):
                check(checks,mode,'primary','photon_'+setting,key,forecasts[mode,setting,key],base)
            if mode=='p32':
                check(checks,mode,'primary','gravity',key,forecasts['p16','primary',key],base)
    for fname,rows in [('comparisons.csv',recon),('checks.csv',checks),('readout.csv',scores)]:
        table(fname,rows)
    print('comparisons',len(recon),'failed',sum(not row['passes'] for row in recon),'controls',len(checks),'failed',sum(not row['passes'] for row in checks))
if __name__=='__main__':
    run()
