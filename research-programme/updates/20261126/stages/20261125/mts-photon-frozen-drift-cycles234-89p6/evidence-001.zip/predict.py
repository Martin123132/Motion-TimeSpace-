from types import SimpleNamespace
from unittest.mock import patch
import sys

from transfer_stage import ROOT, MODES, SETTINGS, angular, previous, net, guard, table, pack, freeze, locked, np
angular('release.py')
angular('angular_photons.py')

def sources():
    from release import Drivers, source as wave_source
    guard()
    rows = []
    for mode in MODES:
        environments = (Drivers(mode), wave_source(mode))
        for sub in (2,4):
            with np.load(angular(f'angular-{mode}-{sub}.npz')) as geometry:
                grid, gravity = geometry['grid'], geometry['gravity']
            with np.load(previous(f'prediction-{mode}-{sub}.npz')) as geometry:
                prep_grid = geometry['grid']
            windows = []
            for cycle in (2,3,4):
                matched = net(mode,'matched',sub,cycle)
                wave = net(mode,'wave',sub,cycle)
                assert matched[:2] == wave[:2] and (not windows or windows[-1][1]==matched[0])
                windows.append((*matched[:2],matched[2],wave[2]))
            knots = np.unique(np.r_[grid,prep_grid,[v for window in windows for v in window[:2]]])
            assert knots[0]==grid[0] and knots[-1]==grid[-1]
            cell = np.searchsorted(grid,knots[:-1],side='right')-1
            prep_cell = np.searchsorted(prep_grid,knots[:-1],side='right')-1
            denominators = np.array([env.environment(grid)[-1][1:][cell] for env in environments])
            assert np.isfinite(denominators).all() and np.min(denominators)>0
            branch_rates = np.zeros((len(cell),3,2),complex)
            for index,(left,right,matched,wave) in enumerate(windows):
                select = (knots[:-1]>=left)&(knots[1:]<=right)
                assert np.array_equal(grid[cell[select]+1],prep_grid[prep_cell[select]+1])
                width = np.diff(knots)[select]
                assert abs(width.sum()-(right-left))<1e-13
                for branch,value in enumerate((matched,wave)):
                    rates = value/(right-left)/denominators[branch,select]
                    branch_rates[select,index,branch]=rates
                    check = abs(sum(width*rates*denominators[branch,select])-value)/abs(value)
                    assert check < 1e-12
                    rows.append(dict(mode=mode,subdivision=sub,cycle=index+2,branch=('matched','wave')[branch],
                                     start=left,end=right,net_real=value.real,net_imag=value.imag,raw_reconstruction_fraction=check))
            gap = branch_rates[:,:,0]-branch_rates[:,:,1]
            values = np.column_stack([gap.sum(1),gap,branch_rates[:,:,0].sum(1),branch_rates[:,:,1].sum(1)])
            assert not np.any(values[(knots[:-1]<windows[0][0]) | (knots[:-1]>=windows[-1][1])])
            pack(f'source-{mode}-{sub}.npz',gravity=gravity,knots=knots,values=values,
                 keys=['drift','cycle2','cycle3','cycle4','matched','wave'])
    table('inputs.csv',rows)
    freeze('source-freeze.json',['transfer_stage.py','predict.py','score.py','PROTOCOL.md','inputs.csv']+
           [f'source-{mode}-{sub}.npz' for mode in MODES for sub in (2,4)])
def packet(mode, unused):
    with np.load(ROOT/f'source-{mode}-4.npz') as fine, np.load(ROOT/f'source-{mode}-2.npz') as half:
        knots = fine['knots']
        old = half['knots']
        idx = np.searchsorted(old,knots[:-1],side='right')-1
        assert knots[0]==old[0] and knots[-1]==old[-1] and np.all(knots[1:]<=old[idx+1])
        assert np.array_equal(fine['keys'],half['keys']) and np.array_equal(fine['gravity'],half['gravity'])
        keys = fine['keys'].tolist()
        return SimpleNamespace(time=fine['gravity'],knots=knots,values=np.column_stack([fine['values'],half['values'][idx]]),
                               keys=keys+['half_'+k for k in keys]),None
def photons():
    from angular_photons import transport, io
    guard()
    locked('source-freeze.json')
    io.ROOT = ROOT
    with patch.object(transport,'ROOT',ROOT),patch.object(transport,'source',packet):
        for setting in SETTINGS:
            transport.project(setting)
    freeze('prediction-freeze.json',['source-freeze.json']+[f'photons-{setting}.npz' for setting in SETTINGS]+
           [f'quadrature-{setting}.csv' for setting in SETTINGS])
if __name__=='__main__':
    {'sources':sources,'photons':photons}[sys.argv[1]]()
