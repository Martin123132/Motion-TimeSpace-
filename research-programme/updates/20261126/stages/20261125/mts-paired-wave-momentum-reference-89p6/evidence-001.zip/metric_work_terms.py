from scipy.interpolate import CubicSpline,make_interp_spline
from twin_stage import ROOT,KIN,FIRST,MODES,np,pinned,driver,wave_input,table,locked,safe,rms

def run(mode,which):
    sub=4
    with np.load(ROOT/f'native-{mode}-{sub}.npz') as data:
        times=data['times'];geom=data['native_geometry'];ref=data['delta']
    if which=='imposed':
        with np.load(ROOT/f'imposed-{mode}-{sub}.npz') as data:ref=data['direct']
        with np.load(pinned(KIN,f'absolute-{mode}-{sub}.npz')) as raw,np.load(pinned(KIN,f'anchored-{mode}-{sub}.npz')) as pair:
            kk=raw['kk'].item();rates=CubicSpline(times,pair['departure']);primitive=rates.antiderivative()
        with np.load(pinned(FIRST,f'launch-{mode}-matched-{sub}.npz')) as incoming,np.load(driver(f'curves-{mode}-companion.npz')) as old:
            entry=incoming['launch'][12]-(old['phi'][0]-old['kick'].item())
        def geometry(t):
            g=rates(t);return entry+(primitive(t)[:,0]-primitive(times[0])[0])/3,g[:,1]/kk,g[:,0]/3,rates(t,1)[:,1]/kk
    else:
        with np.load(pinned(KIN,f'absolute-{mode}-{sub}.npz')) as raw:kk=raw['kk'].item()
        rates=CubicSpline(times,geom)
        def geometry(t):return *rates(t).T,*rates(t,1).T
    with np.load(wave_input('material-halfstep/forcing-heavy.npz')) as bank:
        names=bank['bgkeys'].tolist()
        bg=make_interp_spline(np.log(bank['eta']),bank['background'][[names.index(k) for k in ('a','h','hm','hb','hv')]].T,k=5)
    state=np.zeros((2,5),complex)
    phi0,psi0,*_=geometry(times[:1])
    state[1,0]=bg(np.log(times[0]))[4]*(3*phi0[0]+psi0[0])
    history=[state[0].copy()]
    for start in range(0,len(times)-1,128):
        safe();end=min(start+128,len(times)-1);left=times[start:end];right=times[start+1:end+1]
        arrays=[]
        for t in (left,(left+right)/2,right):
            a,h,m,b,v=bg(np.log(t)).T;om=(a*m)**2
            phi,psi,dp,ds=geometry(t)
            defect=bg(np.log(t),1)[:,4]/t+2*h*v+om*b
            arrays.append((kk+om,2*h,np.column_stack([np.zeros(t.size),3*v*dp,v*ds,-2*om*b*psi,defect*(3*phi+psi)])))
        for idx,step in enumerate(right-left):
            def fun(j,x):
                freq,drag,drive=arrays[j]
                return np.vstack([x[1],-drag[idx]*x[1]-freq[idx]*x[0]+drive[idx]])
            aa=fun(0,state);bb=fun(1,state+step*aa/2);cc=fun(1,state+step*bb/2);dd=fun(2,state+step*cc)
            state+=step/6*(aa+2*bb+2*cc+dd);history.append(state[0].copy())
    vals=np.array(history)*(kk*bg(np.log(times))[:,4,None])
    amp=rms(times,ref)
    closure=100*rms(times,ref-vals.sum(1))/amp
    scale_share=lambda v:100*np.average(((v*ref.conj()).real[1:]+(v*ref.conj()).real[:-1])/2,weights=np.diff(times))/amp**2
    return [dict(mode=mode,pair=which,source=k,rms_pct_of_response=100*rms(times,v)/amp,
                 signed_share_pct=scale_share(v),all_terms_error_pct=closure) for k,v in
            zip(('initial_physical_slope','curvature_rate','lapse_rate','lapse_value','background_interpolation_defect'),vals.T)]
if __name__=='__main__':
    safe();locked('score-receipt.json')
    table('metric-term-ledger.csv',[r for m in MODES for kind in ('imposed','native') for r in run(m,kind)])
