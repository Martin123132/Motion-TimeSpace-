from copy import copy
from scipy.interpolate import CubicSpline
from twin_stage import ROOT,CURRENT,KIN,FIRST,np,common,CASES,MODES,pinned,pack,table,freeze,locked,wave_input,safe,rms

pinned(KIN,'dynamics.py')
from dynamics import make,operator,DIM,QI,QN,inputs_density
from cycle3_inputs import earlier
SCALE=2**24

def stress_curve(mode,sub):
    with np.load(earlier(f'impulses-{mode}-{sub}.npz')) as data:
        t=data['gravity'];dense=data['wave_clock'];values=data['wave_stress']
    with np.load(wave_input(f'particular-heavy-{mode}.npz')) as bank:clock=bank['stressClock']
    knots=np.unique(np.r_[t[0],clock[(clock>t[0])&(clock<t[-1])],t[-1]])
    idx=np.searchsorted(dense,knots)
    assert np.array_equal(dense[idx],knots) and len(knots)==11 and not values[idx[0]].any()
    return inputs_density.ip.matter.spline(knots,values[idx])

def external(src,env,raw):
    bg=env[0];kk=src.kk;stress=raw*bg['enu'][:,None]
    slip=stress[:,2]/kk
    forcing=np.zeros((len(slip),DIM),complex)
    forcing[:,1]=(4/3+bg['eb']/bg['eg'])*kk*slip
    forcing[:,4]=src.wave*slip/3;forcing[:,6]=kk*slip
    for index,tag in ((8,'s'),(10,'h')):
        forcing[:,index]=bg[tag+'v']*slip
        forcing[:,index+1]=-(bg['a']*bg[tag+'m'])**2*bg[tag+'b']*slip
    stress[:,1]*=src.wave
    forcing[:,12]=stress[:,1]/(2*kk)-bg['h']*slip
    return forcing,stress

def run(mode,sub):
    live,lsolver,_,entry,_=make(mode,'wave',sub)
    base=copy(live)
    with np.load(wave_input(f'particular-heavy-{mode}.npz')) as old:
        base.stress=CubicSpline(np.log(old['stressClock']),old['stress'][:,:,0,0],extrapolate=False)
    solver=type(lsolver)(base)
    with np.load(pinned(KIN,f'absolute-{mode}-{sub}.npz')) as old:out=old['cuts']
    with np.load(pinned(FIRST,f'work-{mode}-wave-{sub}.npz')) as arc:
        edges=arc['edges'];saved=arc['states']
    grid=np.unique(np.r_[out,edges]);states=np.zeros((DIM,8),complex)
    states[:,[0,1,4,5]]=entry[:,None]
    keys=[10,11,12,QI,QN]
    history=np.empty((len(grid),len(keys),8),complex);history[0]=states[keys]
    own=stress_curve(mode,sub);fixed=[stress_curve(m,4) for m in MODES]
    edge_ix=np.searchsorted(grid,edges);cycles=[states[:,1].copy()]
    null_direct=null_abs=0.
    for start in range(0,len(grid)-1,32):
        safe();end=min(start+32,len(grid)-1)
        left,right=grid[start:end],grid[start+1:end+1];mid=(left+right)/2
        operators=[];sources=[]
        for times in (left,mid,right):
            mat,bi,bn=operator(solver,times,mid)
            mat[:,:13,QI]+=bi;mat[:,:13,QN]+=bn
            env=solver.env(times,mid)
            raw=own(np.log(times));inj,change=external(base,env,raw)
            zeros=np.zeros((len(times),13),complex)
            hi=lsolver.env(times,mid);amp=list(env);amp[2]=env[2]+SCALE*change
            rhs=np.zeros((len(times),DIM,8),complex)
            for col in (0,1,4,5):rhs[:,:,col]=mat[:,:,-1]
            rhs[:,:13,1]=lsolver.rhs(hi,zeros)
            rhs[:,:13,4]=solver.rhs(env,zeros)
            rhs[:,:13,5]=solver.rhs(amp,zeros)
            rhs[:,:,2]=inj;rhs[:,:,3]=external(base,env,np.zeros_like(raw))[0]
            for idx,curve in enumerate(fixed,6):rhs[:,:,idx]=external(base,env,curve(np.log(times)))[0]
            operators.append(mat[:,:,:DIM]);sources.append(rhs)
        for idx,width in enumerate(right-left):
            def deriv(which,trial):return operators[which][idx]@trial+sources[which][idx]
            aa=deriv(0,states);bb=deriv(1,states+width*aa/2);cc=deriv(1,states+width*bb/2);dd=deriv(2,states+width*cc)
            states+=width/6*(aa+2*bb+2*cc+dd)
            pos=start+idx+1;history[pos]=states[keys]
            null_direct=max(null_direct,max(abs(states[:,3])))
            null_abs=max(null_abs,max(abs(states[:,4]-states[:,0])))
            if pos in edge_ix:cycles.append(states[:,1].copy())
    assert np.isfinite(history).all() and null_direct==0 and null_abs==0,(null_direct,null_abs)
    replay=max(np.max(abs(np.array(cycles)-saved),axis=1)/np.max(abs(saved),axis=1))
    assert replay<.005
    use=np.searchsorted(grid,out);hh=history[use];env=solver.env(out)
    bg=env[0];kk=base.kk;raw=own(np.log(out))
    fac=kk*bg['hv'];physical=fac*hh[:,0,2]
    naive=fac*(hh[:,0,1]-hh[:,0,0]);boost=fac*(hh[:,0,5]-hh[:,0,0])/SCALE
    err=lambda x:100*rms(out,x-physical)/rms(out,physical)
    ref_geo=np.column_stack([hh[:,2,2], hh[:,2,2]+(bg['enu']*raw[:,2]-bg['eg']*hh[:,3,2]-(4*bg['er']+bg['nuS'])*hh[:,4,2])/kk])
    direct_check=err(boost)
    phys0=fac*hh[:,0,0]+env[1]['hJ']
    pack(f'native-{mode}-{sub}.npz',times=out,delta=physical,absolute_subtraction=naive,scaled_check=boost,held_field=hh[:,0,0],
         updated_field=hh[:,0,1],held_current=phys0,native_geometry=ref_geo,fixed_p16=fac*hh[:,0,6],fixed_p32=fac*hh[:,0,7],
         entry=entry[[10,11]],null=np.array([null_direct,null_abs]),replay_error=replay)
    return dict(mode=mode,sub=sub,null_direct=null_direct,null_absolute=null_abs,cycle_replay_pct=100*replay,
                physical_subtraction_error_pct=err(naive),amplified_check_pct=direct_check,amplified_pass=bool(direct_check<=.5),
                native_rms=rms(out,physical),native_pct_of_total=100*rms(out,physical)/rms(out,phys0))

if __name__=='__main__':
    safe();locked('protocol-freeze.json')
    rows=[run(m,s) for m,s in CASES]
    table('native-controls.csv',rows)
    freeze('native-freeze.json',['protocol-freeze.json','native-controls.csv']+[f'native-{m}-{s}.npz' for m,s in CASES])
