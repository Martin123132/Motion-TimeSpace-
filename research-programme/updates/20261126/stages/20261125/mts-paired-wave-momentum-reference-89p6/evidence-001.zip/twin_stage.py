import hashlib,json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent
CURRENT=ROOT.parent/'mts-switch-current-quadratures-89p6-20261125'
def digest(path):
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
expected='c865dc7c06afec41b22a7bfeb253821a1020fe663a98e1d133bf786e7962fc15'
assert digest(CURRENT/'seal.json')==expected
assert digest(CURRENT/'current_stage.py')==json.loads((CURRENT/'seal.json').read_bytes())['files']['current_stage.py']
sys.path.insert(0,str(CURRENT))
from current_stage import common,window,KIN,FIRST,np,pinned,pack,table,freeze,locked,MODES,driver,wave_input
common.PINS={**common.PINS,CURRENT:expected}
common.ROOT=window.ROOT=ROOT
def safe():window.safe()
def rms(t,vec):
    p=abs(vec)**2
    assert np.all(np.diff(t)>0)
    return np.sqrt(np.average((p[1:]+p[:-1])/2,weights=np.diff(t),axis=0))
CASES=[(mode,sub) for mode in MODES for sub in (2,4)]
if __name__=='__main__':
    safe()
    freeze('protocol-freeze.json',['PROTOCOL.md','twin_stage.py','native_pair.py','metric_pair.py','score_pair.py'])
