import ast,csv,sys
from twin_stage import ROOT,CURRENT,CASES,common,np,pinned,locked,freeze,rms

def rows(name):
    with (ROOT/name).open() as stream:return list(csv.DictReader(stream))
def run():
    for receipt in ('protocol-freeze.json','native-freeze.json','reference-freeze.json','score-receipt.json'):locked(receipt)
    pinned(CURRENT,'delta-freeze.json')
    for mode,sub in CASES:
        with np.load(ROOT/f'imposed-{mode}-{sub}.npz') as imp,np.load(ROOT/f'native-{mode}-{sub}.npz') as nat:
            t=nat['times'];assert np.array_equal(t,imp['times']) and np.array_equal(nat['entry'],imp['start'])
            assert not np.any(imp['null']) and not np.any(nat['null'])
            for name,actual,ref in [('native replay',nat['scaled_check'],nat['delta']),('two-variable check',imp['native_direct'],nat['delta']),
                                    ('imposed twin check',imp['absolute_subtraction'],imp['direct'])]:
                err=rms(t,actual-ref)/rms(t,ref);assert np.isfinite(err) and err<=.005,name
            if sub==4:assert np.array_equal(nat['delta'],nat['fixed_'+mode])
    for name,size,key in [('convergence.csv',14,'relative_pct'),('frozen-comparisons.csv',48,'error_pct')]:
        entries=rows(name);assert len(entries)==size
        for row in entries:
            err=float(row[key]);assert np.isfinite(err) and err>=0 and (err<=.5)==(row['passes']=='True')
    old=rows('old-reference-ledger.csv');assert len(old)==4 and all(float(r['identity_error_pct'])<=.5 for r in old)
    ledger=rows('metric-term-ledger.csv');assert len(ledger)==20
    for mode in ('p16','p32'):
        for kind in ('imposed','native'):
            parts=[r for r in ledger if r['mode']==mode and r['pair']==kind]
            assert abs(sum(float(r['signed_share_pct']) for r in parts)-100)<=.5 and max(float(r['all_terms_error_pct']) for r in parts)<=.5
    for path in ROOT.glob('*.py'):ast.parse(path.read_text())
    assert not list(ROOT.rglob('__pycache__'))
    if '--seal' in sys.argv:
        assert (ROOT/'RESULTS.md').is_file()
        freeze('seal.json',sorted(p.name for p in ROOT.iterdir() if p.is_file() and p.name!='seal.json'))
        locked('seal.json');print(common.sha(ROOT/'seal.json'))
if __name__=='__main__':run()
