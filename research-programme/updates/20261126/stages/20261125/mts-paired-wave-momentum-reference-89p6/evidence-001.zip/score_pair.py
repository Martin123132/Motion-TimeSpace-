from scipy.interpolate import CubicSpline
from twin_stage import ROOT,CURRENT,KIN,MODES,CASES,np,pinned,wave_input,table,freeze,locked,safe,rms

def run():
    safe();locked('reference-freeze.json')
    rows=[];closure=[];clocks=[];pairs={}
    for mode,sub in CASES:
        with np.load(ROOT/f'native-{mode}-{sub}.npz') as nat,np.load(ROOT/f'imposed-{mode}-{sub}.npz') as imp,np.load(pinned(CURRENT,f'delta-{mode}-{sub}.npz')) as pred:
            t=nat['times'];assert np.array_equal(t,imp['times']) and np.array_equal(t,pred['times'])
            sources={k:nat[k] for k in ('delta','fixed_p16','fixed_p32')}
            sources['imposed']=imp['direct'];pairs[mode,sub]=(t,sources)
            with np.load(pinned(KIN,f'anchored-{mode}-{sub}.npz')) as data:edge=data['first_end'].item()
            for label,target in [('imposed_gravity',imp['direct']),('native_stress_pair',nat['delta'])]:
                for key in ('momentum','from_geometry'):
                    trial=pred[key]
                    for segment,left,right in [('full',t[0],t[-1]),('first',t[0],edge),('later',edge,t[-1])]:
                        grid=np.unique(np.r_[left,t[(t>left)&(t<right)],right])
                        def view(vals):return CubicSpline(t,vals,extrapolate=False)(grid)
                        val=view(trial);ref=view(target)
                        width=np.diff(grid);dot=(val*ref.conj()).real
                        norm=rms(grid,ref);err=rms(grid,val-ref);ratio=100*err/norm
                        proj=np.average((dot[:-1]+dot[1:])/2,weights=width)/norm**2
                        rows.append(dict(mode=mode,sub=sub,window=segment,pair=label,forecast=key,error_pct=ratio,passes=bool(ratio<=.5),
                                         pred_rms=rms(grid,val),ref_rms=norm,error_rms=err,projection=proj,error_pct_of_total=100*err/rms(grid,view(nat['held_current']))))
            with np.load(pinned(CURRENT,f'reference-{mode}-{sub}.npz')) as old:old_delta=old['delta']
            with np.load(wave_input(f'particular-heavy-{mode}.npz')) as original:
                historical=CubicSpline(original['eta'],original['obs'][:,10,0,0])(t)
            from scipy.interpolate import make_interp_spline
            with np.load(wave_input('material-halfstep/forcing-heavy.npz')) as bank:
                vel=make_interp_spline(np.log(bank['eta']),bank['background'][bank['bgkeys'].tolist().index('hv')],k=5)(np.log(t))
            with np.load(pinned(KIN,f'absolute-{mode}-{sub}.npz')) as bank:kk=bank['kk'].item()
            held_minus_arch=kk*vel*(nat['held_field']-historical)
            norm=rms(t,old_delta)
            closure.append(dict(mode=mode,sub=sub,old_rms=norm,new_rms=rms(t,nat['delta']),held_minus_original_rms=rms(t,held_minus_arch),
                                paired_pct_of_old=100*rms(t,nat['delta'])/norm,
                                identity_error_pct=100*rms(t,old_delta-nat['delta']-held_minus_arch)/norm))
    def clocktest(label,t,lo,hi,high):
        assert t[0]==hi[0] and t[-1]==hi[-1]
        r=CubicSpline(hi,high)(t);norm=rms(t,r);err=100*rms(t,lo-r)/norm
        idx=np.searchsorted(hi,t);distance=np.minimum(abs(hi[idx]-t),abs(hi[np.maximum(idx-1,0)]-t))
        use=distance<=5e-13
        common=100*rms(t[use],(lo-r)[use])/rms(t[use],r[use])
        assert use.mean()>.995 and abs(common-err)<.005*max(1.,err)
        clocks.append(dict(test=label,relative_pct=err,shared_only_pct=common,passes=bool(err<=.5),rms_reference=norm))
    for low,hi in [(('p16',4),('p32',4)),(('p16',2),('p16',4)),(('p32',2),('p32',4))]:
        t,a=pairs[low];u,b=pairs[hi]
        for key in a:clocktest(f'{low[0]}-{low[1]}_vs_{hi[0]}-{hi[1]}_{key}',t,a[key],u,b[key])
    for mode in MODES:
        t,data=pairs[mode,4]
        clocktest(mode+'_same_clock_changed_stress',t,data['fixed_p16'],t,data['fixed_p32'])
    table('frozen-comparisons.csv',rows);table('convergence.csv',clocks);table('old-reference-ledger.csv',closure)
    freeze('score-receipt.json',['reference-freeze.json','frozen-comparisons.csv','convergence.csv','old-reference-ledger.csv'])
if __name__=='__main__':run()
