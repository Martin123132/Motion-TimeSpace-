from scipy.interpolate import CubicSpline,make_interp_spline
from twin_stage import ROOT,MODES,CASES,np,KIN,FIRST,pinned,driver,wave_input,pack,table,freeze,locked,safe,rms

def metric(times,rates,phi0,kk):
    spline=CubicSpline(times,rates,extrapolate=False)
    primitive=spline.antiderivative()
    return lambda t:np.column_stack([phi0+(primitive(t)[:,0]-primitive(times[0])[0])/3,spline(t)[:,1]/kk])

def run(mode,sub):
    with np.load(ROOT/f'native-{mode}-{sub}.npz') as arc:
        times=arc['times'];initial=arc['entry'];true=arc['delta'];native_metric=CubicSpline(times,arc['native_geometry'],extrapolate=False)
    with np.load(pinned(KIN,f'absolute-{mode}-{sub}.npz')) as raw,np.load(pinned(KIN,f'anchored-{mode}-{sub}.npz')) as corr:
        assert np.array_equal(times,raw['cuts'])
        kk=raw['kk'].item();glive=raw['gravity']+corr['metric_response'];gprep=corr['prepared'];gdiff=corr['departure']
    with np.load(pinned(FIRST,f'launch-{mode}-matched-{sub}.npz')) as start,np.load(driver(f'curves-{mode}-companion.npz')) as prepared:
        phi_live=start['launch'][12];phi_prep=prepared['phi'][0]-prepared['kick'].item()
    live_metric=metric(times,glive,phi_live,kk);prep_metric=metric(times,gprep,phi_prep,kk);diff_metric=metric(times,gdiff,phi_live-phi_prep,kk)
    with np.load(wave_input('material-halfstep/forcing-heavy.npz')) as bank:
        bgkeys=bank['bgkeys'].tolist();qkeys=bank['keys'].tolist();log=np.log(bank['eta'])
        bgcurve=make_interp_spline(log,bank['background'][[bgkeys.index(k) for k in ('a','h','hm','hb','hv')]].T,k=5)
        qcurve=make_interp_spline(log,bank['values'][[qkeys.index(k) for k in ('hfield','hmoment','hJ')]][:,:,0].T,k=5)
    state=np.zeros((2,6),complex);state[:,[0,1,3]]=initial[:,None]
    history=np.empty((len(times),2,6),complex);history[0]=state
    null_direct=null_abs=0.
    for start in range(0,len(times)-1,128):
        safe();end=min(start+128,len(times)-1);left=times[start:end];right=times[start+1:end+1]
        operators=[];sources=[]
        for clock in (left,(left+right)/2,right):
            a,hub,mass,field,vel=bgcurve(np.log(clock)).T
            eff=(a*mass)**2
            held=qcurve(np.log(clock))[:,:2]
            mat=np.zeros((len(clock),2,2));mat[:,0,1]=1;mat[:,1,0]=-kk-eff;mat[:,1,1]=-2*hub
            rhs=np.zeros((len(clock),2,6),complex)
            def gravity(pair):
                phi,psi=pair.T
                return np.column_stack([vel*(psi+3*phi),eff*field*(3*phi-psi)])
            control=prep_metric(clock)
            rhs[:,:,0]=held+gravity(control);rhs[:,:,1]=held+gravity(live_metric(clock))
            rhs[:,:,2]=gravity(diff_metric(clock));rhs[:,:,3]=held+gravity(control)
            rhs[:,:,4]=gravity(control-control);rhs[:,:,5]=gravity(native_metric(clock))
            operators.append(mat);sources.append(rhs)
        for idx,width in enumerate(right-left):
            def deriv(which,trial):return operators[which][idx]@trial+sources[which][idx]
            aa=deriv(0,state);bb=deriv(1,state+.5*width*aa);cc=deriv(1,state+.5*width*bb);dd=deriv(2,state+width*cc)
            state+=width/6*(aa+2*bb+2*cc+dd);history[start+idx+1]=state
            null_direct=max(null_direct,max(abs(state[:,4])));null_abs=max(null_abs,max(abs(state[:,3]-state[:,0])))
    assert null_direct==null_abs==0 and np.isfinite(history).all()
    fac=kk*bgcurve(np.log(times))[:,4]
    diff=fac*history[:,0,2];twin=fac*(history[:,0,1]-history[:,0,0]);native=fac*history[:,0,5]
    err=lambda vec,ref:100*rms(times,vec-ref)/rms(times,ref)
    pack(f'imposed-{mode}-{sub}.npz',times=times,direct=diff,absolute_subtraction=twin,native_direct=native,
         null=np.array([null_direct,null_abs]),start=initial)
    return dict(mode=mode,sub=sub,null_direct=null_direct,null_absolute=null_abs,direct_vs_absolute_pct=err(twin,diff),
                native_two_vs_full_pct=err(native,true),rms_delta=rms(times,diff))

if __name__=='__main__':
    safe();locked('native-freeze.json')
    rows=[run(m,s) for m,s in CASES];table('imposed-controls.csv',rows)
    freeze('reference-freeze.json',['native-freeze.json','imposed-controls.csv']+[f'imposed-{m}-{s}.npz' for m,s in CASES])
