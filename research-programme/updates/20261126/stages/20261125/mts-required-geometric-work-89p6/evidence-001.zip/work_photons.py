from stage_u import ROOT,PRIOR,pin,owner,frozen,sys
from types import SimpleNamespace
from unittest.mock import patch
pin('photon_product.py')
import photon_product as transport
from photon_product import io,np,gate,MODES
io.ROOT=ROOT
def source(mode,unused):
    with np.load(ROOT/f'comparison-{mode}-4.npz') as fine,np.load(ROOT/f'comparison-{mode}-2.npz') as half:
        fine_t=fine['grid'];grav=fine['gravity'];dt=np.diff(fine_t);den=fine['D_right'];miss=fine['equivalent']
        assert np.array_equal(fine_t[::2],half['grid'])
        native=fine['native_delta']/den
        fields=dict(mismatch=miss/dt,supplied=fine['supplied']/den/dt,required=fine['required']/den/dt,
            half=np.repeat(half['equivalent']/np.diff(half['grid']),2),archive=fine['old_matched']/dt,
            native_adjustment=native/dt,native_supported=native/dt*(fine_t[:-1]>=fine['native_start']),
            native_only_residual=(miss+native)/dt)
    return SimpleNamespace(time=grav,knots=fine_t,values=np.column_stack(list(fields.values())),keys=list(fields)),None
def main():
    frozen();owner()
    with patch.object(transport,'ROOT',ROOT),patch.object(transport,'source',source):
        for setting in ('primary','time','angle'):transport.project(setting)
if __name__=='__main__':main()
