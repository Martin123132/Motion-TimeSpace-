from stage_u import ROOT,PRIOR,SEAL,pin,owner,freeze,sys
pin('inputs_product.py');pin('matter_product.py')
from matter_product import Inputs,KEYS,MODES,peak,np,io
import inputs_product as prior
io.ROOT=ROOT
TERMS=('momentum_metric','changing_D','energy_state','energy_coefficients','energy_external','HJ_state','HJ_coefficients','HJ_external')
def guard():owner();prior.guard()
class Blind:
    def __init__(self,src,alter=None):
        self.src=src;self.kk=src.kk;self.wave=src.wave;self.alter=alter
    def env(self,t,side=None):
        b,q,stress,coef,quad,drive,rho,D=self.src.environment(t,side)
        if self.alter is not None:q['U']=self.alter(t)
        q.pop('U');return b,q,stress,coef,quad,drive,rho,D
    def aggregate(self,env,x,ext=True):
        bg,q,stress,coef,quad,drive,rho,den=env
        gx,W,B,N0,N1,cd,ct,bd,sf,sw,hf,hw=x.T
        eg=bg['eg'];eb=bg['eb'];vel=bg['sv'];pot=(bg['a']*bg['sm'])**2*bg['sb'];kk=self.kk
        energy=eg*gx+eb*bd+(4*bg['er']+bg['nuE'])*N0+bg['ec']*cd+vel*sw+pot*sf+rho*hf
        curr=eg*W+self.wave*(4*bg['er']+bg['nuJ'])*N1+bg['ec']*ct+kk*vel*sf+rho*hw
        if ext:
            energy+=q['gE']+q['btrace']+q['bKE']+stress[:,0]+q['ctrace']+q['cKE']+q['senergy']
            curr+=q['gJ']+q['bJq']+q['nuJ']+stress[:,1]+q['cJq']+q['sJ']
        return energy,curr
    def rhs(self,env,full):
        bg,q,stress,coef,quad,drive,rho,den=env
        gx,W,B,N0,N1,cd,ct,bd,sf,sw,hf,hw,phi=full.T;kk=self.kk
        h=bg['h'];eg=bg['eg'];r=bg['eb']/eg;op=bg['opacity'];bt=(W-B)/(r+4/3);gj=B+4*bt/3
        _,curr=self.aggregate(env,full[:,:-1])
        slip=(-q['Q']-eg*(quad[0]+q['ph_shift'])-(4*bg['er']+bg['nuS'])*quad[1]+stress[:,2]+q['cshear']+q['bshear']+q['sshear']+rho*coef[4])/kk
        psi=phi+slip
        phi_rate=curr/(2*kk)-h*psi+q['Fq']
        bfree=-h*bt+kk*psi+q['bspeed']
        gfree=kk*(gx/3+4*(psi+phi)/3-2*quad[0]/3)+q['ph_momentum']
        m2=(bg['a']*bg['sm'])**2;press=coef[0]*(hf+3*phi+3*h*hw/kk)+coef[1]
        return np.column_stack((-gj+q['ph_energy']-op*q['collision_heat'],
            gfree+r*(kk*psi+q['bspeed'])+op*(q['collision_b']-q['collision_ph']),
            gfree-4*bfree/3-op*((1+4/(3*r))*B+q['collision_ph']+4*q['collision_b']/(3*r)),
            -self.wave*N1+drive[0],self.wave*(N0+phi+psi-2*quad[1])/3+drive[1],
            -ct+q['cnumber'],-h*ct+kk*psi+q['cspeed'],-bt+q['bnumber'],
            sw+bg['sv']*(psi+3*phi)+q['sfield'],-2*h*sw-(kk+m2)*sf+m2*bg['sb']*(3*phi-psi)+q['smoment'],
            -hw-3*h*press+coef[2],-h*hw+kk*(press+psi)+coef[3],phi_rate))
    def advance(self,left,right,start):
        delta=np.zeros_like(start)
        for lo,hi in zip(np.r_[-np.inf,self.src.corners],np.r_[self.src.corners,np.inf]):
            a=np.maximum(left,lo);b=np.minimum(right,hi);idx=np.flatnonzero(b>a)
            if not len(idx):continue
            a=a[idx];b=b[idx];mid=(a+b)/2;dt=(b-a)[:,None];state=start[idx]+delta[idx]
            env0=self.env(a,mid);env1=self.env(mid,mid);env2=self.env(b,mid)
            k1=self.rhs(env0,state);k2=self.rhs(env1,state+dt*k1/2)
            k3=self.rhs(env1,state+dt*k2/2);k4=self.rhs(env2,state+dt*k3)
            delta[idx]+=dt*(k1+2*k2+2*k3+k4)/6
        return delta
    def work(self,left,right,start,delta):
        env0=self.env(left);env1=self.env(right);d0=env0[-1];d1=env1[-1]
        x=start[:,:-1];dx=delta[:,:-1];mid=x+dx/2;zero=np.zeros_like(x)
        def weights(env,state,external):
            energy,curr=self.aggregate(env,state,external)
            return np.column_stack((energy/2,1.5*env[0]['h']*curr/self.kk))
        moved=(weights(env1,dx,False)+weights(env0,dx,False))/2
        coeff=weights(env1,mid,False)-weights(env0,mid,False)
        ext=weights(env1,zero,True)-weights(env0,zero,True)
        terms=np.column_stack((d1*delta[:,-1],(d1-d0)*start[:,-1],moved[:,0],coeff[:,0],ext[:,0],moved[:,1],coeff[:,1],ext[:,1]))
        u0=d0*start[:,-1]+weights(env0,x,True).sum(1)
        u1=d1*(start[:,-1]+delta[:,-1])+weights(env1,x+dx,True).sum(1)
        return terms,d1,u1-u0
def calculate(mode,split,alter=None):
    guard();pin(f'matter-{mode}.npz');src=Inputs(mode);solver=Blind(src,alter)
    t=src.time;left=t[:-1];right=t[1:]
    with np.load(pin(f'matter-{mode}.npz')) as packet:
        phi=packet['states'][:-1,packet['keys'].tolist().index('geom')]
    start=np.column_stack((src.state[:-1],phi))
    knots=left[:,None]+(right-left)[:,None]*np.arange(split+1)/split;knots[:,-1]=right
    pieces=[];den=[];direct=[];change=[]
    for col in range(split):
        a,b=knots[:,col],knots[:,col+1];delta=solver.advance(a,b,start)
        v,d,ud=solver.work(a,b,start,delta);pieces.append(v);den.append(d);direct.append(ud);change.append(delta[:,-1]);start=start+delta
    grid=np.r_[knots[:,:-1].reshape(-1),t[-1]]
    flatten=lambda v:np.stack(v,axis=1).reshape(len(grid)-1,-1)
    terms=flatten(pieces);D=flatten(den)[:,0];ud=flatten(direct)[:,0];required=terms.sum(1)
    product=peak((ud-required)/np.diff(grid))/peak(required/np.diff(grid))
    assert product<1e-7 and np.all(np.isfinite(terms))
    return dict(gravity=t,grid=grid,term_names=TERMS,terms=terms,required=required,D_right=D,phi_impulse=flatten(change)[:,0],product_relative=product)
def main():
    for mode in MODES:
        for split in (2,4):
            result=calculate(mode,split);io.pack(f'required-{mode}-{split}.npz',**result)
    io.record('frozen.json',freeze());print('Both requirements frozen; no U increment scored.',flush=True)
if __name__=='__main__':main()
