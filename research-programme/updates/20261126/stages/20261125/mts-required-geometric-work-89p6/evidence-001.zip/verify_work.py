import csv,re
from stage_u import ROOT,PRIOR,SEAL,pin,frozen,owner,digest,json
from required_u import calculate,Blind,Inputs,MODES,peak,np,io
def rows(name):
    with (ROOT/name).open() as fp:return list(csv.DictReader(fp))
def verify():
    frozen();owner();checks=[]
    def check(name,result):
        assert result,name
        checks.append(name)
    for mode in MODES:
        poisoned=calculate(mode,4,lambda t:np.full_like(t,np.nan))
        with np.load(ROOT/f'required-{mode}-4.npz') as reference:
            check('all stage U poisoned '+mode,all(np.array_equal(poisoned[k],reference[k]) for k in ('required','terms','D_right','phi_impulse')))
        src=Inputs(mode);idx=np.linspace(0,len(src.time)-1,21,dtype=int);t=src.time[idx];state=src.state[idx]
        env=src.environment(t)
        num,curr=src.terms(env,state);ph=num.sum(1)/env[-1];expected,rates=src.rhs(env,state)
        blind=Blind(src);trial=blind.env(t);deriv=blind.rhs(trial,np.column_stack((state,ph)))
        check('U absent '+mode,'U' not in trial[1])
        check('combined source equations '+mode,np.max(np.max(abs(deriv[:,:-1]-expected),axis=0)/np.max(abs(expected),axis=0))<1e-10 and peak(deriv[:,-1]-rates.sum(1))/peak(rates.sum(1))<1e-10)
        for split in (2,4):
            with np.load(ROOT/f'comparison-{mode}-{split}.npz') as packet,np.load(ROOT/f'required-{mode}-{split}.npz') as saved:
                check('fixed predictions and signed comparison '+mode+str(split),np.array_equal(packet['required'],saved['required']) and np.array_equal(saved['gravity'],saved['grid'][::split]) and np.array_equal(packet['supplied']-saved['required'],packet['miss']) and np.array_equal(packet['miss']/saved['D_right'],packet['equivalent']))
                check('retained residual comparison '+mode+str(split),np.isfinite(packet['equivalent']).all() and float(packet['old_relative'])<.005 and float(saved['product_relative'])<.005)
        local=rows('local-'+mode+'.csv')
        check('raw comparisons '+mode,len(local)==4 and all(0<=int(r['cells_over_half_pct'])<=int(r['cells']) for r in local))
    floor=rows('shape-bound.csv')
    check('orthogonal residual lower bounds',len(floor)==4 and all(float(r['any_complex_constant_rms_floor_pct'])>.5 and 0<float(r['remaining_fraction_of_mismatch'])<=1 for r in floor))
    photon=rows('photon-comparisons.csv')
    check('photon replays refinement and blind tests',len(photon)==30 and all(r['passes']=='True' and max(float(r[k]) for k in ('energy_relative','current_relative','joint_relative'))<.005 for r in photon))
    gates=rows('photon-gates.csv')
    for r in gates:
        check('decisions '+str((r['mode'],r['case'],r['setting'])),(r['precision_pass']=='True')==(max(float(r[k]) for k in ('energy_pct','current_pct','joint_pct'))<=.5) and (r['size_pass']=='True')==(max(float(r[k]) for k in ('momentum_launch_pct','differentiated_launch_pct'))<.163))
    check('size passes and precision misses retained',len(gates)==12 and all(r['size_pass']=='True' and r['precision_pass']=='False' for r in gates))
    c=rows('controls.csv')
    check('refinements retained',len(c)==30 and all((r['passes']=='True')==(max(float(r[k]) for k in ('energy_relative','current_relative','joint_relative'))<=.005) for r in c) and all(r['passes']=='True' for r in c if r['refinement']!='gravity'))
    for note in ROOT.glob('*.md'):
        for item in re.findall(r'\]\(([^)]+)\)',note.read_text(encoding='utf-8')):check('link '+item,(ROOT/item).is_file())
    for file in ROOT.glob('*.py'):compile(file.read_bytes(),str(file),'exec')
    check('no temporary cache',not (ROOT/'__pycache__').exists())
    io.record('validation.json',dict(checks=checks,integrity_pass=True,blind_comparison_complete=True,photon_precision=False,photon_size=True))
    seal=ROOT/'seal.json';files={p.name:digest(p) for p in sorted(ROOT.iterdir()) if p.is_file() and p!=seal}
    io.record('seal.json',dict(files=files,prior=SEAL))
    print(len(checks),'checks;',len(files),'files; seal',digest(seal))
if __name__=='__main__':verify()
