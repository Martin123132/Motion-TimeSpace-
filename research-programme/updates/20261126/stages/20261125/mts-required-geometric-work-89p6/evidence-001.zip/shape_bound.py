from stage_u import ROOT,frozen
from score_work import MODES,io,np,guard
def run():
    frozen();guard();rows=[]
    for mode in MODES:
        with np.load(ROOT/f'comparison-{mode}-4.npz') as packet:
            grid=packet['gravity'];step=np.diff(grid);width=len(step)
            group=lambda key:packet[key].reshape(width,4).sum(1)
            actual=group('supplied');missing=group('required')-actual
            native=group('native_delta')
            for window,take in [('full',np.ones(width,bool)),('tabulated',grid[:-1]>=packet['native_start'])]:
                product=lambda a,b:np.sum(a[take].conj()*b[take]/step[take]);norm=lambda a:np.sqrt(product(a,a).real)
                along=product(actual,missing)/product(actual,actual)
                floor=norm(missing-along*actual)/norm(actual)
                assert abs(product(actual,missing-along*actual))<1e-10*norm(actual)*norm(missing)
                rows.append(dict(mode=mode,window=window,any_complex_constant_rms_floor_pct=100*floor,
                    remaining_fraction_of_mismatch=norm(missing-along*actual)/norm(missing),
                    real_signed_native_share=product(missing,native).real/norm(missing)**2,
                    rms_floor_after_native_pct=100*(norm(missing)-norm(native))/norm(actual),
                    rms_actual_after_native_pct=100*norm(missing-native)/norm(actual)))
    io.table('shape-bound.csv',rows);print(rows[-2])
if __name__=='__main__':run()
