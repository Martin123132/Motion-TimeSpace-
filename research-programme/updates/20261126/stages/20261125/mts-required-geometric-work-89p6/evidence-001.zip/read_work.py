from stage_u import ROOT,pin,frozen,owner
from work_photons import io,gate,np,MODES,transport
from cell89 import pin as legacy
from scipy.interpolate import CubicSpline
import csv
SETTINGS=('primary','time','angle')
def score():
    frozen();owner()
    _,axis,weights,_=gate.proj.old.get_media()
    measure=gate.previous.make_measure(axis,weights);mag=lambda x:gate.mag(x,measure)
    with gate.pin(gate.FROZEN,'window-readouts.csv').open() as fp:
        launch={r['gravity']:float(r['launch_norm']) for r in csv.DictReader(fp) if r['model']=='MTS-minus-baseline' and r['output']=='joint'}
    comparisons=[];stats=[];gates=[];allvals={};controls=[]
    for setting in SETTINGS:
        name='photons-'+setting+'.npz'
        with np.load(ROOT/name) as found,np.load(pin(name)) as old,np.load(transport.saved(name)) as w,np.load(legacy('photon-'+setting+'.npz')) as initial:
            grid=found['scale'];assert all(np.array_equal(grid,z) for z in (old['scale'],w['scale'],initial['grid']))
            project=lambda vec:CubicSpline(grid,vec)(axis)
            for index,mode in enumerate(MODES):
                vals=project(found['values'][:,index,0]);pieces=dict(zip(found['channels'].tolist(),np.moveaxis(vals,1,0)))
                oldwork=project(old['values'][:,index,0,old['channels'].tolist().index('independent_quarter')])
                wave=project(w['values'][:,index,w['branches'].tolist().index('wave'),:2].sum(1))
                ix=initial['labels'].tolist().index([mode,'primary'])
                mom=project(initial['values'][:,ix,:3].sum(1));den=mag(mom)
                net=pieces['mismatch'];native=pieces['native_adjustment']
                for label,ans,want in [('frozen-minus-required',pieces['supplied']-pieces['required'],net),('half-subcells',pieces['half'],net),('prior-replay',pieces['archive'],oldwork),('blind-versus-prior',net,oldwork),('native-sum',pieces['native_only_residual'],net+native)]:
                    rel=mag(ans-want)/mag(want)
                    comparisons.append(dict(mode=mode,setting=setting,check=label,energy_relative=rel[0],current_relative=rel[1],joint_relative=rel[2],passes=bool(max(rel)<=.005)))
                for key,val in {**pieces,'matched_minus_wave':net-wave,'fixed_wave':wave}.items():
                    pct=100*mag(val)/den
                    inner=measure@(net.conj()*val).real
                    stats.append(dict(mode=mode,setting=setting,term=key,energy_common_pct=pct[0],current_common_pct=pct[1],joint_common_pct=pct[2],
                                      signed_share_of_missed=inner.sum()/mag(net)[2]**2,norm_over_mismatch=mag(val)[2]/mag(net)[2]))
                    if key in ('mismatch','matched_minus_wave','fixed_wave','supplied','required','native_adjustment'):allvals[mode,setting,key]=val
                for key,vec in [('blind',net-wave),('prior',oldwork-wave)]:
                    pct=100*mag(vec)/den;pm=100*den[2]/launch[mode];pd=100*mag(mom+vec)[2]/launch[mode]
                    gates.append(dict(mode=mode,setting=setting,case=key,energy_pct=pct[0],current_pct=pct[1],joint_pct=pct[2],
                                      precision_pass=bool(max(pct)<=.5),momentum_launch_pct=pm,differentiated_launch_pct=pd,size_pass=bool(max(pm,pd)<.163)))
    for (mode,setting,key),vec in allvals.items():
        if setting!='primary':continue
        for tag,other,alt in [('time',mode,'time'),('angle',mode,'angle')]+([('gravity','p16','primary')] if mode=='p32' else []):
            rel=mag(vec-allvals[other,alt,key])/mag(vec)
            controls.append(dict(mode=mode,term=key,refinement=tag,energy_relative=rel[0],current_relative=rel[1],joint_relative=rel[2],passes=bool(max(rel)<=.005)))
    for name,rows in [('photon-comparisons',comparisons),('work-projections',stats),('photon-gates',gates),('controls',controls)]:io.table(name+'.csv',rows)
    print([r for r in gates if r['setting']=='primary' and r['case']=='blind'])
if __name__=='__main__':score()
