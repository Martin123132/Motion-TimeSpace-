from stage_u import ROOT,pin,owner,frozen,sys
from required_u import Inputs,MODES,peak,io,np,guard
from inputs_product import checked,archived,make_interp_spline
def compare(mode):
    frozen();guard();src=Inputs(mode)
    idx=src.flow.qkeys.index('U')
    with np.load(checked('native-U.npz')) as nat,np.load(archived('primary.npz')) as model:
        knots=model['eta'];assert np.array_equal(knots,nat['eta'])
        names=('potential_square','laplacian','gradient','flux_square')
        native=sum(nat['wave_'+n]-nat['matched_'+n] for n in names)
        correction_error=make_interp_spline(np.log(knots),native-model['restore'],k=5)
    rows=[]
    for split in (2,4):
        with np.load(ROOT/f'required-{mode}-{split}.npz') as pred:
            grid=pred['grid'];grav=pred['gravity'];req=pred['required'];den=pred['D_right']
            supplied=src.flow.q(np.log(grid))[:,idx,0]
            actual=np.diff(supplied);extra=np.diff(correction_error(np.log(grid)))
            diff=actual-req;equivalent=diff/den
            prior=pin(f'interior-{mode}-{split}.npz')
            with np.load(prior) as old:
                assert np.array_equal(grid,old['time'])
                expected=old['source'].sum((1,2))-old['momentum'].sum(1)
            dt=np.diff(grid)
            full=lambda x:x.reshape(-1,split).sum(1)
            change=full(actual);want=full(req);err=change-want;dtg=np.diff(grav)
            for label,mask in [('full',np.ones(len(dtg),bool)),('tabulated',grav[:-1]>=knots[0])]:
                dist=lambda x:np.sqrt(np.sum(abs(x[mask])**2/dtg[mask]))
                rel=abs(err[mask])/np.maximum(abs(change[mask]),np.finfo(float).tiny)
                rows.append(dict(mode=mode,split=split,window=label,cells=sum(mask),rms_pct_of_frozen=100*dist(err)/dist(change),
                    peak_rate_pct=100*peak(err[mask]/dtg[mask])/peak(change[mask]/dtg[mask]),max_cell_pct=100*max(rel),
                    cells_over_half_pct=sum(rel>.005),net_discrepancy_pct=100*abs(sum(err[mask]))/abs(sum(change[mask])),
                    missing_net_real=(-sum(err[mask])).real,missing_net_imag=(-sum(err[mask])).imag,
                    native_adjustment_norm_over_missing=dist(full(extra))/dist(err),
                    frozen_u_rate_rms=float(dist(change)/np.sqrt(sum(dtg[mask])))))
            recal=peak((equivalent-expected)/dt)/peak(expected/dt)
            io.pack(f'comparison-{mode}-{split}.npz',grid=grid,gravity=grav,supplied=actual,required=req,miss=diff,
                    equivalent=equivalent,native_delta=extra,native_start=knots[0],D_right=den,old_matched=expected,old_relative=recal)
    io.table(f'local-{mode}.csv',rows);print(mode,rows[-2],flush=True)
if __name__=='__main__':
    for mode in MODES:compare(mode)
