from pathlib import Path
import sys,hashlib,json
ROOT=Path(__file__).resolve().parent
PRIOR=ROOT.parent/'mts-matched-product-balance-89p6-20261125'
SEAL='e30defa5e23474f78d9ac93c5007f018b5a8c3ea3f84c7206472fe2f3137cc4d'
def digest(file):
    with file.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
assert digest(PRIOR/'seal.json')==SEAL
manifest=json.loads((PRIOR/'seal.json').read_bytes())['files']
def pin(name):
    path=PRIOR/name;assert digest(path)==manifest[name],name
    return path
sys.path.insert(0,str(PRIOR))
def owner():
    assert all(not (p/'STOP-REQUESTED').exists() for p in (ROOT,PRIOR))
def freeze():
    files={f.name:digest(f) for f in sorted(ROOT.glob('required-*.npz'))}
    assert len(files)==4
    files.update({n:digest(ROOT/n) for n in ('PROTOCOL.md','required_u.py','stage_u.py')})
    return dict(files=files,prior=SEAL)
def frozen():assert json.loads((ROOT/'frozen.json').read_bytes())==freeze()
