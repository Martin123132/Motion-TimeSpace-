from pathlib import Path
import sys,hashlib,json
from types import SimpleNamespace
from unittest.mock import patch
ROOT=Path(__file__).resolve().parent
CELLS=ROOT.parent/'mts-cell-potential-balance-89p6-20261124'
SEAL='a781475df859d3f86c9fba30c2ead37d652a52e1263519a0b55789e7c5c63fdc'
def digest(p):
    with p.open('rb') as fp:return hashlib.file_digest(fp,'sha256').hexdigest()
assert digest(CELLS/'seal.json')==SEAL
def saved(name):
    path=CELLS/name;assert digest(path)==json.loads((CELLS/'seal.json').read_bytes())['files'][name];return path
saved('cell89.py');saved('photons89.py');sys.path.insert(0,str(CELLS))
import photons89 as retained
from cell89 import io,gate,np,MODES
io.ROOT=ROOT
def guard():
    retained.guard();assert not (CELLS/'STOP-REQUESTED').exists()
def source(mode,branch):
    guard()
    with np.load(ROOT/f'predicted-{mode}.npz') as orig,np.load(ROOT/f'interior-{mode}-2.npz') as halves,np.load(ROOT/f'interior-{mode}-4.npz') as fine:
        t=orig['time'];grid=fine['time']
        assert np.array_equal(grid[::4],t) and np.array_equal(grid[::2],halves['time'])
        groups=orig['groups'].tolist();names=orig['source_names'].tolist()
        def stretch(vec,clock,num):
            return np.repeat(vec/np.diff(clock),num)
        fields={'observed':stretch(orig['target_defect'],t,4),
                'predicted_fixed_momentum':stretch(orig['predicted_phi_change']-orig['frozen_constraint'],t,4),
                'independent_mean':stretch(orig['sector_defects'].sum(1),t,4),
                'independent_half':stretch(halves['source'].sum((1,2))-halves['momentum'].sum(1),halves['time'],2)}
        parts=fine['source']/np.diff(grid)[:,None,None];mom=fine['momentum']/np.diff(grid)[:,None]
        fields['independent_quarter']=(parts.sum(1)-mom).sum(1)
        fields.update({'sector:'+key:(parts.sum(1)-mom)[:,idx] for idx,key in enumerate(groups)})
        fields.update({'product:'+key:parts[:,idx,:].sum(1) for idx,key in enumerate(names)})
        fields['product:minus_momentum']=-mom.sum(1)
    return SimpleNamespace(time=t,knots=grid,values=np.column_stack(list(fields.values())),keys=list(fields)),None
def moments(axis,at,src):
    cuts=np.unique(np.r_[axis,src.knots]);step=np.diff(axis);loc=np.searchsorted(axis,cuts[:-1],side='right')-1
    idx=np.searchsorted(src.knots,cuts[:-1],side='right')-1
    width=np.diff(cuts);mid=((cuts[:-1]-axis[loc])+width/2)/step[loc]
    basis=np.column_stack((2*(1-mid),6*mid-2))
    sums=np.zeros((len(step),2,len(src.keys)),complex)
    np.add.at(sums,loc,width[:,None,None]*basis[:,:,None]*src.values[idx,None,:])
    exact=np.zeros((len(step),len(src.keys)),complex)
    np.add.at(exact,loc,width[:,None]*src.values[idx])
    err=np.max(abs(.75*sums[:,0]+.25*sums[:,1]-exact))/np.max(abs(exact[:,0]))
    assert err<.005
    return 4*np.einsum('st,ntk->nsk',gate.proj.RAD,sums),err
def project(setting):
    guard()
    labels=source('p16',None)[0].keys
    with patch.object(retained,'BRANCHES',('matched_mean',)),patch.object(retained,'CHANNELS',labels),patch.object(retained,'source',source),patch.object(retained,'stages',moments):
        retained.transport(setting)
if __name__=='__main__':
    for setting in sys.argv[1:]:project(setting)
