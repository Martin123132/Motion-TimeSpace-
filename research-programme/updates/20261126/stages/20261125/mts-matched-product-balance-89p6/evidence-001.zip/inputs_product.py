from pathlib import Path
import hashlib,json,sys
import numpy as np
from scipy.interpolate import CubicSpline,make_interp_spline
ROOT=Path(__file__).resolve().parent
CELLS=ROOT.parent/'mts-cell-potential-balance-89p6-20261124'
PRE=ROOT.parent/'mts-fixed-geometry-resolved-current-89p6-20261124'
SEAL='a781475df859d3f86c9fba30c2ead37d652a52e1263519a0b55789e7c5c63fdc'
def digest(path):
    with path.open('rb') as fp:return hashlib.file_digest(fp,'sha256').hexdigest()
assert digest(CELLS/'seal.json')==SEAL
def pin(folder,name):
    want=json.loads((folder/'seal.json').read_bytes())['files'][name]
    path=folder/name;assert digest(path)==want,name
    return path
assert digest(PRE/'seal.json')==json.loads((CELLS/'seal.json').read_bytes())['prior']
sys.path.insert(0,str(PRE));pin(PRE,'restore89.py')
from restore89 import io,archived,checked,companion,prior,path,array_hash,SWITCH,END,MODES
import restore89
checked('replay.py')
import replay
matter=replay.matter
assert Path(matter.__file__).resolve()==io.checked('matter.py').resolve()
io.ROOT=ROOT
def guard():
    restore89.guard()
    assert all(not (p/'STOP-REQUESTED').exists() for p in (PRE,CELLS,ROOT))
def model(mode,clock,initial):
    guard()
    with np.load(companion(mode)) as pack:g=dict(pack.items())
    flow=matter.get_flow(matter.FLUID,'companion',clock,initial,g)
    original=flow.q;idx=flow.qkeys.index('U')
    with np.load(archived('primary.npz')) as data:frozen=make_interp_spline(np.log(data['eta']),data['restore'],k=5)
    def locked(at):
        values=original(at).copy();values[...,idx,0]+=frozen(at);return values
    flow.q=locked
    receipt=json.loads(prior(f'input-audit-{mode}-both.json').read_bytes());values=flow.q(flow.log)
    assert array_hash(values[:,idx])==receipt['U_hash']
    assert all(array_hash(values[:,flow.qkeys.index(k)])==receipt['receipt'][k]['host'] for k in ('Q','Fq'))
    return flow,g
def capture(mode):
    with np.load(io.old.pin('original-through89/particular-heavy-'+mode+'.npz')) as data:initial=data['state'][:,:1]
    with np.load(io.old.pin('particular-heavy-'+mode+'.npz')) as data:
        native=data['eta'];stress_time=data['stressClock'];oldstress=data['stress']
    pre=matter.get_flow(matter.BASE89,'companion',matter.physical_axis(native,89.,SWITCH),initial)
    _,obs,_,states=pre.evolve(stress_time,oldstress);initial=states[-1].copy()
    flow,g=model(mode,matter.physical_axis(native,SWITCH,END),initial)
    with np.load(path(mode,'base','curves')) as data:target=dict(data.items())
    bank=matter.FLUID/'common-heavy.npz'
    assert digest(bank)==json.loads((matter.FLUID/'bank-heavy.json').read_bytes())[bank.name]
    with np.load(bank) as data:stress_t=matter.physical_axis(data['eta'],89.,END)
    stress=target['stress']
    idx=flow.ix;bg=dict(zip(flow.bgkeys,flow.bg(flow.log[0])));rho=flow.rho0/bg['a'];kk=float(g['k2'])
    den=kk+(3*(bg['ec']+bg['eb']+bg['sv']**2+rho)+4*(bg['eg']+bg['er'])+bg['nuE'])/2
    left,force,_=pre.env(np.log(SWITCH));vel=left['hv'];pot=(left['a']*left['hm'])**2*left['hb']
    energy=(vel*initial[idx['hw']]+pot*initial[idx['hf']]+force['henergy'][0]+3*vel**2*obs[-1,0,0])/rho
    curr=(kk*vel*initial[idx['hf']]+force['hJ'][0])/rho
    at=CubicSpline(np.log(stress_t),stress)(flow.log[0])*bg['enu'];at[1]*=flow.k
    state=flow.initial[1];state[idx['hf']]=0;state[idx['hw']]=curr
    scaled=np.stack([flow.launch(0,free).T for free in range(2)],axis=-1)
    ph0=flow.observe(flow.log[0],scaled,at)[0][0,0]
    state[idx['hf']]=energy-3*(ph0-rho*energy/(2*den))/(1-3*rho/(2*den))
    clock,obs,_,states=flow.evolve(stress_t,stress)
    assert np.array_equal(clock,target['eta'])
    checks={key:float(np.max(abs(val-target[key]))/np.max(abs(target[key]))) for key,val in dict(phi=obs[:,0,0,0],psi=obs[:,1,0,0],e=states[:,idx['hf'],0]+3*obs[:,0,0],j=states[:,idx['hw'],0],rest_state=states[-1]).items()}
    assert max(checks.values())<1e-11,checks
    io.pack('matter-'+mode+'.npz',eta=clock,keys=flow.keys,states=states[:,:,0,0],stress_clock=stress_t,stress=stress[:,:,0,0])
    io.record('capture-'+mode+'.json',checks);print(mode,'saved trajectory reproduced',checks,flush=True)
if __name__=='__main__':
    for mode in sys.argv[1:]:capture(mode)
