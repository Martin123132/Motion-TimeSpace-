from matter_product import Inputs,ROOT,io,guard,np,sys,GROUPS,peak
def resolve(mode,split):
    guard();src=Inputs(mode);left=src.time[:-1];right=src.time[1:];total=right-left
    cuts=left[:,None]+total[:,None]*np.arange(split+1)/split;cuts[:,-1]=right
    start=src.state[:-1].copy();data=[];impulses=[]
    for j in range(split):
        pair=(cuts[:,j],cuts[:,j+1])
        dx,imp=src.integrate(1,pair,start)
        pieces,_=src.increments(dx,pair,start)
        data.append(pieces);impulses.append(imp)
        start=start+dx
    data=np.stack(data,axis=1);imp=np.stack(impulses,axis=1)
    time=np.r_[cuts[:,:-1].reshape(-1),right[-1]]
    assert np.array_equal(time[::split],src.time)
    with np.load(ROOT/f'predicted-{mode}.npz') as orig:
        scale=peak(orig['target_defect']/total);deviation=peak((data.sum((1,2,3))-orig['predicted_phi_change'])/total)/scale
        assert deviation<.005,deviation
    io.pack(f'interior-{mode}-{split}.npz',time=time,groups=GROUPS,source=data.reshape(-1,4,len(GROUPS)),momentum=imp.reshape(-1,len(GROUPS)),sum_check=deviation)
if __name__=='__main__':
    for mode in sys.argv[1:]:
        for split in (2,4):resolve(mode,split)
