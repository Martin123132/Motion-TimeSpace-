from inputs_product import ROOT,CELLS,io,guard,pin,model,MODES,path,np,sys,CubicSpline
GROUPS=('geometry','photon','collisionless','cold','baryon','slow','heavy')
KEYS=('gx','W','B','N0','N1','cd','ct','bd','sf','sw','hf','hw')
def peak(values):return float(np.max(abs(values)))
def sides(values):return values[:-1],values[1:]
class Inputs:
    def __init__(self,mode):
        with np.load(ROOT/f'matter-{mode}.npz') as data:
            self.time=data['eta'];keys=data['keys'].tolist()
            self.state=data['states'][:,[keys.index(key) for key in KEYS]]
            self.quads=CubicSpline(self.time,data['states'][:,[keys.index(key) for key in ('I2','N2')]])
            self.stress=CubicSpline(np.log(data['stress_clock']),data['stress'])
        self.flow,self.packet=model(mode,self.time,np.zeros((len(keys),1,2),complex))
        self.wave=float(self.flow.k[0,0]);self.kk=self.wave**2
        time=self.packet['eta'];self.corners=self.packet['corners'];self.coeff=[]
        values=np.column_stack([self.packet['cs2'],*[self.packet['companion_'+k][:,0] for k in ('pres_res','source_e','source_j','shear')]])
        for left,right in zip(np.r_[-np.inf,self.corners],np.r_[self.corners,np.inf]):
            inside=(time>=left+5e-9)&(time<=right-5e-9);self.coeff.append(CubicSpline(time[inside],values[inside]))
    def environment(self,t,side=None):
        log=np.log(t);f=self.flow
        bg=dict(zip(f.bgkeys,f.bg(log).T));q=dict(zip(f.qkeys,f.q(log)[:,:,0].T))
        stress=self.stress(log)*bg['enu'][:,None];stress[:,1]*=self.wave
        loc=np.searchsorted(self.corners,t if side is None else side,side='right');coef=np.empty((len(t),5),complex)
        for idx,curve in enumerate(self.coeff):
            take=loc==idx;coef[take]=curve(t[take])
        rho=f.rho0/bg['a'];den=self.kk+(3*(bg['ec']+bg['eb']+bg['sv']**2+rho)+4*(bg['eg']+bg['er'])+bg['nuE'])/2
        return bg,q,stress,coef.T,self.quads(t).T,f.drive(log)[:,:2,0].T,rho,den
    def terms(self,env,states,external=True):
        bg,q,stress,coef,quad,drive,rho,den=env
        gx,W,B,N0,N1,cd,ct,bd,sf,sw,hf,hw=states.T
        kk=self.kk;h=bg['h'];ratio=bg['eb']/bg['eg'];bt=(W-B)/(ratio+4/3);gj=B+4*bt/3
        pot=(bg['a']*bg['sm'])**2*bg['sb']
        zero=np.zeros_like(gx)
        stack=lambda *args:np.stack(args,axis=1)
        energy=stack(zero,bg['eg']*gx,(4*bg['er']+bg['nuE'])*N0,bg['ec']*cd,bg['eb']*bd,pot*sf+bg['sv']*sw,rho*hf)
        curr=stack(zero,bg['eg']*gj,self.wave*(4*bg['er']+bg['nuJ'])*N1,bg['ec']*ct,bg['eb']*bt,kk*bg['sv']*sf,rho*hw)
        if external:
            energy+=stack(zero,q['gE'],stress[:,0],q['ctrace']+q['cKE'],q['btrace']+q['bKE'],q['senergy'],zero)
            curr+=stack(zero,q['gJ'],q['nuJ']+stress[:,1],q['cJq'],q['bJq'],q['sJ'],zero)
        num=-.5*energy-1.5*h[:,None]*curr/kk
        if external:num[:,0]+=q['U']
        return num,curr
    def rhs(self,env,state):
        bg,q,stress,coef,quad,drive,rho,den=env
        gx,W,B,N0,N1,cd,ct,bd,sf,sw,hf,hw=state.T
        kk=self.kk;h=bg['h'];ratio=bg['eb']/bg['eg'];op=bg['opacity'];bt=(W-B)/(ratio+4/3);gj=B+4*bt/3
        num,curr=self.terms(env,state)
        slip=np.stack((-q['Q'],-bg['eg']*(quad[0]+q['ph_shift']),-(4*bg['er']+bg['nuS'])*quad[1]+stress[:,2],q['cshear'],q['bshear'],q['sshear'],rho*coef[4]),axis=1)/kk
        phi=num.sum(1)/den;psi=phi+slip.sum(1)
        rates=curr/(2*kk)-h[:,None]*(num/den[:,None]+slip);rates[:,0]+=q['Fq']
        bfree=-h*bt+kk*psi+q['bspeed']
        gfree=kk*(gx/3+4*(psi+phi)/3-2*quad[0]/3)+q['ph_momentum'];drag=4/(3*ratio)
        pot=(bg['a']*bg['sm'])**2;press=coef[0]*(hf+3*phi+3*h*hw/kk)+coef[1]
        rhs=np.stack((-gj+q['ph_energy']-op*q['collision_heat'],gfree+ratio*(bfree+h*bt)+op*(q['collision_b']-q['collision_ph']),
                      gfree-4*bfree/3-op*((1+drag)*B+q['collision_ph']+drag*q['collision_b']),
                      -self.wave*N1+drive[0],self.wave*(N0+phi+psi-2*quad[1])/3+drive[1],
                      -ct+q['cnumber'],-h*ct+kk*psi+q['cspeed'],-bt+q['bnumber'],
                      sw+bg['sv']*(psi+3*phi)+q['sfield'],-2*h*sw-(kk+pot)*sf+pot*bg['sb']*(3*phi-psi)+q['smoment'],
                      -hw-3*h*press+coef[2],-h*hw+kk*(press+psi)+coef[3]),axis=1)
        return rhs,rates
    def integrate(self,sub,interval=None,start=None):
        left,right=sides(self.time) if interval is None else interval
        if start is None:start=self.state[:-1]
        dx=np.zeros_like(start);imp=np.zeros((len(left),len(GROUPS)),complex)
        for lo,hi in zip(np.r_[-np.inf,self.corners],np.r_[self.corners,np.inf]):
            a=np.maximum(left,lo);b=np.minimum(right,hi);idx=np.where(b>a)[0];a=a[idx];b=b[idx]
            step=(b-a)/sub;h=step[:,None]
            side=(b+a)/2
            for j in range(sub):
                time=a+j*step; env0=self.environment(time,side);env1=self.environment(time+step/2,side);env2=self.environment(time+step,side)
                state=start[idx]+dx[idx]
                r0,p0=self.rhs(env0,state);r1,p1=self.rhs(env1,state+h*r0/2);r2,p2=self.rhs(env1,state+h*r1/2);r3,p3=self.rhs(env2,state+h*r2)
                dx[idx]+=h*(r0+2*r1+2*r2+r3)/6;imp[idx]+=h*(p0+2*p1+2*p2+p3)/6
        return dx,imp
    def increments(self,dx,interval=None,start=None):
        left,right=sides(self.time) if interval is None else interval
        if start is None:start=self.state[:-1]
        mid=start+dx/2;zero=np.zeros_like(start)
        env0=self.environment(left);env1=self.environment(right);d0=env0[-1];d1=env1[-1]
        n0=self.terms(env0,start)[0]
        evolution=(self.terms(env1,dx,False)[0]+self.terms(env0,dx,False)[0])/2
        coeff=self.terms(env1,mid,False)[0]-self.terms(env0,mid,False)[0]
        external=self.terms(env1,zero)[0]-self.terms(env0,zero)[0]
        background=-n0*((d1-d0)/d0)[:,None]
        pieces=np.stack((evolution,coeff,external,background),axis=1)/d1[:,None,None]
        direct=self.terms(env1,start+dx)[0]/d1[:,None]-n0/d0[:,None]
        return pieces,direct

def analyse(mode):
    guard();src=Inputs(mode);time=src.time;dt=np.diff(time)
    dx1,imp1=src.integrate(1);dx,imp=src.integrate(2)
    pieces,bysector=src.increments(dx);pred=pieces.sum((1,2));pred1=src.increments(dx1)[0].sum((1,2))
    with np.load(pin(CELLS,f'cells-{mode}-matched_mean.npz')) as saved:
        assert np.array_equal(time,saved['eta']);obs=saved['observed_change'];constraint=saved['momentum_integral'];target=saved['signed_defect']
    gain=np.diff(src.state,axis=0);stateerr=np.max(abs((dx-gain)/dt[:,None]),axis=0)/np.max(abs(gain/dt[:,None]),axis=0)
    scale=peak(target/dt)
    errors=lambda delta:peak(delta/dt)/scale
    env=src.environment(time)
    with np.load(path(mode,'base','curves')) as old:
        phi=src.terms(env,src.state)[0].sum(1)/env[-1];rate=src.rhs(env,src.state)[1].sum(1)
        assert peak(phi-old['phi'])<1e-11*peak(phi) and peak(rate-old['pd'])<1e-10*peak(rate)
    balance=pieces.sum(1)-imp
    metrics=dict(mode=mode,cells=len(dt),max_state_rate_error=float(max(stateerr)),worst_state=KEYS[np.argmax(stateerr)],peak_pred_vs_observed=peak((pred-obs)/dt)/peak(obs/dt),
        defect_scale_pred_error=errors(pred-obs),defect_scale_rate_integral_error=errors(imp.sum(1)-constraint),
        defect_scale_predicted_balance_error=errors(balance.sum(1)-target),defect_scale_substep_difference=errors(pred-pred1),defect_scale_rate_substep_difference=errors((imp-imp1).sum(1)),
        discrete_product_error=errors(pred-bysector.sum(1)),all_finite=bool(np.isfinite(pieces).all() and np.isfinite(imp).all()))
    assert metrics['all_finite'] and metrics['discrete_product_error']<.005
    io.record('local-check-'+mode+'.json',metrics)
    io.pack('predicted-'+mode+'.npz',time=time,groups=GROUPS,keys=KEYS,source_names=['rhs_state','changing_coefficient','external_numerator','changing_denominator'],dphi_components=pieces,momentum_impulses=imp,sector_defects=balance,state_rate_errors=stateerr,state_increments=dx,observed_phi_change=obs,predicted_phi_change=pred,frozen_constraint=constraint,target_defect=target,rk_substep_difference=pred-pred1)
    print(metrics,flush=True)
if __name__=='__main__':
    for mode in sys.argv[1:]:analyse(mode)
