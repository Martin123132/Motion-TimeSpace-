from matter_product import Inputs,GROUPS,KEYS,ROOT,io,np,guard,peak,MODES
def test(mode):
    src=Inputs(mode);t=src.time;env=src.environment(t)
    bg,q,stress,coef,quad,drive,rho,den=env;h=bg['h'];eg=bg['eg'];eb=bg['eb'];ratio=eb/eg;op=bg['opacity']
    groups=[GROUPS.index(k) for k in ('photon','baryon')]
    index={name:KEYS.index(name) for name in KEYS};rows=[]
    def check(label,diff,scale):
        error=peak(diff)/peak(scale);rows.append(dict(mode=mode,test=label,relative=error,passes=bool(error<=.005)))
    state=src.state
    num,curr=src.terms(env,state);phi=num.sum(1)/den
    with np.load(ROOT/f'matter-{mode}.npz') as saved:
        selected=saved['states'][:,saved['keys'].tolist().index('geom')]
        assert peak(phi-selected)/peak(selected)<1e-11
    shear=-q['Q']-eg*(quad[0]+q['ph_shift'])-(4*bg['er']+bg['nuS'])*quad[1]+stress[:,2]+q['cshear']+q['bshear']+q['sshear']+rho*coef[4]
    psi=phi+shear/src.kk
    for diagnostic in (False,True):
        use=state.copy()
        if diagnostic:use[:,index['B']]+=1j*state[:,index['W']]
        dyn,_=src.rhs(env,use);num,curr=src.terms(env,use,False)
        W=use[:,index['W']];gx=use[:,index['gx']]
        flux=eg*W
        energy_rate=-flux+eg*(q['ph_energy']-op*q['collision_heat'])+eb*q['bnumber']
        current_rate=eg*(src.kk*(gx/3+(4/3+ratio)*psi+4*phi/3-2*quad[0]/3)+q['ph_momentum']+ratio*q['bspeed']+op*(q['collision_b']-q['collision_ph']))
        postfix='algebraic slip perturbation' if diagnostic else 'retained history'
        check('total state current '+postfix,curr[:,groups].sum(1)-flux,flux)
        check('paired energy source '+postfix,eg*dyn[:,index['gx']]+eb*dyn[:,index['bd']]-energy_rate,energy_rate)
        check('paired momentum source '+postfix,eg*dyn[:,index['W']]-current_rate,current_rate)
    return rows
if __name__=='__main__':
    guard();rows=[r for mode in MODES for r in test(mode)]
    assert all(r['passes'] for r in rows);io.table('paired-matter.csv',rows);print('max paired error',max(r['relative'] for r in rows))
