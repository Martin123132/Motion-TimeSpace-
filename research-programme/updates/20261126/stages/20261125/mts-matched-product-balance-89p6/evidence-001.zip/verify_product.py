import csv,re
from matter_product import ROOT,CELLS,Inputs,io,guard,np,MODES,GROUPS,KEYS,peak
from inputs_product import pin,SEAL,digest,json
def rows(name):
    with (ROOT/name).open() as fp:return list(csv.DictReader(fp))
def verify():
    guard();checks=[]
    def require(name,ok):
        assert ok,name
        checks.append(name)
    for mode in MODES:
        data=json.loads((ROOT/f'local-check-{mode}.json').read_bytes())
        require('replay '+mode,max(json.loads((ROOT/f'capture-{mode}.json').read_bytes()).values())==0.)
        require('cell increments and product '+mode,all(data[k]<=.005 for k in ('max_state_rate_error','peak_pred_vs_observed','defect_scale_pred_error','defect_scale_predicted_balance_error','discrete_product_error','defect_scale_rate_integral_error','defect_scale_predicted_balance_error','defect_scale_substep_difference','defect_scale_rate_substep_difference')))
        src=Inputs(mode);at=len(src.time)//2
        def blind_prediction():
            pair=(src.time[at:at+1],src.time[at+1:at+2]);left=src.state[at:at+1]
            dx,imp=src.integrate(2,pair,left)
            return src.increments(dx,pair,left)[0],imp
        first=blind_prediction()
        src.state[at+1:at+2]*=(1+.01j)
        second=blind_prediction()
        require('right state hidden '+mode,all(np.array_equal(a,b) for a,b in zip(first,second)))
        with np.load(ROOT/f'predicted-{mode}.npz') as pred,np.load(pin(CELLS,f'cells-{mode}-matched_mean.npz')) as target:
            require('unaltered targets '+mode,np.array_equal(pred['time'],target['eta']) and np.array_equal(pred['target_defect'],target['signed_defect']) and pred['keys'].tolist()==list(KEYS))
        for split in (2,4):
            with np.load(ROOT/f'interior-{mode}-{split}.npz') as interior:
                require('subcell coverage '+mode+str(split),np.array_equal(interior['time'][::split],src.time) and float(interior['sum_check'])<.005 and np.isfinite(interior['source']).all())
    tests=rows('prediction-tests.csv')
    require('all independent photon checks',len(tests)==48 and all(r['passed']=='True' and max(float(r[k]) for k in ('energy_relative','current_relative','joint_relative'))<.005 for r in tests))
    gates=rows('branch-gates.csv')
    for r in gates:
        require(str((r['mode'],r['term'],r['setting']))+' gates', (r['rate_pass']=='True')==(max(float(r[k]) for k in ('energy_pct','current_pct','joint_pct'))<=.5) and (r['size_pass']=='True')==(max(float(r[k]) for k in ('momentum_launch_pct','differentiated_launch_pct'))<.163))
    require('all six size passes, rate misses retained',len(gates)==12 and all(r['size_pass']=='True' and r['rate_pass']=='False' for r in gates))
    controls=rows('refinements.csv')
    require('all refinement outcomes recorded',len(controls)==20 and all((r['passed']=='True')==(max(float(r[k]) for k in ('energy_relative','current_relative','joint_relative'))<=.005) for r in controls))
    require('fixed gravity photon refinements',all(r['passed']=='True' for r in controls if r['test']!='gravity'))
    pair=rows('paired-matter.csv')
    require('paired source and slip cancellation',len(pair)==12 and all(float(r['relative'])<.005 for r in pair))
    terms=rows('signed-terms.csv')
    for mode in MODES:
        for setting in ('primary','time','angle'):
            for prefix in ('sector:','product:'):
                subset=[float(r['signed_share']) for r in terms if r['mode']==mode and r['setting']==setting and r['term'].startswith(prefix)]
                require('signed sum '+mode+setting+prefix,len(subset)==(len(GROUPS) if prefix=='sector:' else 5) and abs(sum(subset)-1)<.005)
    for note in ROOT.glob('*.md'):
        for link in re.findall(r'\]\(([^)]+)\)',note.read_text(encoding='utf-8')):require('link '+link,(ROOT/link).is_file())
    for file in ROOT.glob('*.py'):compile(file.read_bytes(),str(file),'exec')
    require('clean directory',not (ROOT/'__pycache__').exists())
    io.record('validation.json',dict(checks=checks,integrity_pass=True,conditional_reproduction_pass=True,photon_precision_pass=False,photon_size_pass=True))
    seal=ROOT/'seal.json';files={p.name:digest(p) for p in sorted(ROOT.iterdir()) if p.is_file() and p!=seal}
    io.record('seal.json',dict(files=files,prior=SEAL))
    print(len(checks),'checks;',len(files),'files; seal',digest(seal))
if __name__=='__main__':verify()
