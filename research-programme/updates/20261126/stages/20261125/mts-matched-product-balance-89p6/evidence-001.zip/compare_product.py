import csv
from scipy.interpolate import CubicSpline
from photon_product import ROOT,CELLS,io,gate,np,MODES,saved,guard
from cell89 import pin as prior
SETTINGS=('primary','time','angle')
def run():
    guard();_,axis,weights,_=gate.proj.old.get_media()
    measure=gate.previous.make_measure(axis,weights)
    mag=lambda v:gate.mag(v,measure)
    with gate.pin(gate.FROZEN,'window-readouts.csv').open() as fp:
        launches={r['gravity']:float(r['launch_norm']) for r in csv.DictReader(fp) if r['model']=='MTS-minus-baseline' and r['output']=='joint'}
    metrics=[];scores=[];shares=[];conv=[];pool={}
    for setting in SETTINGS:
        with np.load(ROOT/f'photons-{setting}.npz') as pred,np.load(saved(f'photons-{setting}.npz')) as ref,np.load(prior(f'photon-{setting}.npz')) as raw:
            grid=pred['scale'];assert np.array_equal(grid,ref['scale']) and np.array_equal(grid,raw['grid'])
            spline=lambda v:CubicSpline(grid,v)(axis)
            for mi,mode in enumerate(MODES):
                data=spline(pred['values'][:,mi,0]);parts={key:data[:,j] for j,key in enumerate(pred['channels'].tolist())}
                archived=spline(ref['values'][:,mi]);branches=ref['branches'].tolist()
                positive=archived[:,branches.index('matched_mean')]
                refwave=archived[:,branches.index('wave'),:2].sum(1)
                target=positive[:,:2].sum(1);original=positive[:,0]
                ix=raw['labels'].tolist().index([mode,'primary']);route=spline(raw['values'][:,ix,:3].sum(1))
                den=mag(route);net=parts['independent_quarter'];oldgap=target-refwave
                checks={'legacy_endpoint_replay':(parts['observed'],original),'model_state_rhs_only':(parts['predicted_fixed_momentum'],original),
                        'both_rates_independent_cell_mean':(parts['independent_mean'],original),'full_predicted_to_archived_matched':(net,target),
                        'quarter_to_half':(net,parts['independent_half']),'surrounding_within_cell':(net,parts['independent_mean']),
                        'sector_sum':(sum(v for k,v in parts.items() if k.startswith('sector:')),net),
                        'product_sum':(sum(v for k,v in parts.items() if k.startswith('product:')),net)}
                for key,(answer,want) in checks.items():
                    err=mag(answer-want)/mag(want)
                    metrics.append(dict(setting=setting,mode=mode,test=key,energy_relative=err[0],current_relative=err[1],joint_relative=err[2],passed=bool(max(err)<=.005)))
                for tag,v in {**parts,'archived_matched':target,'fixed_wave':refwave,'prediction_minus_wave':net-refwave,'archived_minus_wave':oldgap}.items():
                    pct=100*mag(v)/den;inner=measure@(net.conj()*v).real
                    shares.append(dict(setting=setting,mode=mode,term=tag,energy_pct=pct[0],current_pct=pct[1],joint_pct=pct[2],signed_share=inner.sum()/mag(net)[2]**2))
                    if tag in ('independent_quarter','fixed_wave','prediction_minus_wave','archived_matched'):pool[setting,mode,tag]=v
                for tag,v in [('archived',oldgap),('predicted',net-refwave)]:
                    pct=100*mag(v)/den
                    pm=100*den[2]/launches[mode];pd=100*mag(route+v)[2]/launches[mode]
                    scores.append(dict(setting=setting,mode=mode,term=tag,energy_pct=pct[0],current_pct=pct[1],joint_pct=pct[2],rate_pass=bool(max(pct)<=.5),momentum_launch_pct=pm,differentiated_launch_pct=pd,size_pass=bool(max(pm,pd)<.163)))
    for (setting,mode,tag),vec in pool.items():
        if setting!='primary':continue
        for label,st,mo in [('photon_time','time',mode),('photon_angle','angle',mode)]+([('gravity','primary','p16')] if mode=='p32' else []):
            err=mag(vec-pool[st,mo,tag])/mag(vec)
            conv.append(dict(mode=mode,term=tag,test=label,energy_relative=err[0],current_relative=err[1],joint_relative=err[2],passed=bool(max(err)<=.005)))
    for name,rows in [('prediction-tests',metrics),('branch-gates',scores),('signed-terms',shares),('refinements',conv)]:io.table(name+'.csv',rows)
    print([(r['mode'],r['term'],r['joint_pct']) for r in scores if r['setting']=='primary'])
if __name__=='__main__':run()
