from project_wave_work import ROOT,pin,io,gate,MODES,np,transport,owner
from cell89 import pin as legacy
from scipy.interpolate import CubicSpline
import csv

def score():
    owner();_,axis,weights,_=gate.proj.old.get_media()
    measure=gate.previous.make_measure(axis,weights);mag=lambda x:gate.mag(x,measure)
    with gate.pin(gate.FROZEN,'window-readouts.csv').open() as fp:
        launch={r['gravity']:float(r['launch_norm']) for r in csv.DictReader(fp) if r['model']=='MTS-minus-baseline' and r['output']=='joint'}
    stats=[];checks=[];gates=[];values={};convergence=[]
    for setting in ('primary','time','angle'):
        name='photons-'+setting+'.npz'
        with np.load(ROOT/name) as found,np.load(pin(name)) as matched,np.load(transport.saved(name)) as archive,np.load(legacy('photon-'+setting+'.npz')) as saved:
            grid=found['scale'];assert all(np.array_equal(grid,g) for g in (matched['scale'],archive['scale'],saved['grid']))
            project=lambda v:CubicSpline(grid,v)(axis)
            for mi,mode in enumerate(MODES):
                cols=project(found['values'][:,mi,0]);terms={k:cols[:,j] for j,k in enumerate(found['channels'].tolist())}
                wave=project(archive['values'][:,mi,archive['branches'].tolist().index('wave'),:2].sum(1))
                match=project(matched['values'][:,mi,0,matched['channels'].tolist().index('mismatch')])
                ix=saved['labels'].tolist().index([mode,'primary']);mom=project(saved['values'][:,ix,:3].sum(1))
                den=mag(mom);blind=terms['blind'];extra=wave-blind
                compare={'wave saved impulses vs archived curved':(terms['saved'],wave),'wave reconstruction vs archived':(terms['accounted'],wave),
                    'pure blind wave versus archived':(blind,wave),'two vs four wave substeps':(terms['half'],blind),
                    'matched archive':(terms['matched'],match),'work sign':(terms['actual_work']-terms['required_work'],blind),
                    'branch subtraction':(terms['both_blind'],match-blind)}
                for label,(actual,expected) in compare.items():
                    er=mag(actual-expected)/mag(expected)
                    checks.append(dict(mode=mode,setting=setting,test=label,energy_relative=er[0],current_relative=er[1],joint_relative=er[2],passes=bool(max(er)<=.005)))
                for tag,v in {**terms,'verified_wave':wave,'saved_minus_blind_wave':extra,'matched_minus_saved_wave':match-wave}.items():
                    pct=100*mag(v)/den;inner=measure@(wave.conj()*v).real;innerextra=measure@(extra.conj()*v).real
                    stats.append(dict(mode=mode,setting=setting,term=tag,energy_common_pct=pct[0],current_common_pct=pct[1],joint_common_pct=pct[2],share_saved_wave=inner.sum()/mag(wave)[2]**2,share_saved_minus_blind=innerextra.sum()/mag(extra)[2]**2))
                    if tag in ('blind','verified_wave','matched','both_blind','matched_minus_saved_wave','saved_minus_blind_wave','heavy_state'):values[mode,setting,tag]=v
                for label,g in [('both_equations',match-blind),('matched_equations_minus_saved_wave',match-wave),('matched_minus_accounted_wave',match-terms['accounted'])]:
                    pct=100*mag(g)/den;pm=100*den[2]/launch[mode];pd=100*mag(mom+g)[2]/launch[mode]
                    gates.append(dict(mode=mode,setting=setting,case=label,energy_pct=pct[0],current_pct=pct[1],joint_pct=pct[2],rate_pass=bool(max(pct)<=.5),momentum_launch_pct=pm,differentiated_launch_pct=pd,size_pass=bool(max(pm,pd)<.163)))
    for (mode,setting,tag),vec in values.items():
        if setting!='primary':continue
        for name,mo,alt in [('photon_time',mode,'time'),('photon_angle',mode,'angle')]+([('gravity','p16','primary')] if mode=='p32' else []):
            er=mag(vec-values[mo,alt,tag])/mag(vec);convergence.append(dict(mode=mode,term=tag,refinement=name,energy_relative=er[0],current_relative=er[1],joint_relative=er[2],passes=bool(max(er)<=.005)))
    for name,rows in [('photon-components',stats),('photon-checks',checks),('photon-gates',gates),('controls',convergence)]:io.table(name+'.csv',rows)
    print([(r['mode'],r['case'],r['joint_pct']) for r in gates if r['setting']=='primary'])
if __name__=='__main__':score()
