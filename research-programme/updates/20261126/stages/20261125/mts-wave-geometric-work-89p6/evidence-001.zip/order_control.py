from project_wave_work import ROOT,io,gate,np,transport,owner
from scipy.interpolate import CubicSpline
def check():
    owner();_,axis,weights,_=gate.proj.old.get_media();measure=gate.previous.make_measure(axis,weights)
    mag=lambda z:gate.mag(z,measure);rows=[]
    for setting in ('primary','time','angle'):
        name='photons-'+setting+'.npz'
        with np.load(ROOT/name) as run,np.load(transport.saved(name)) as wave:
            assert np.array_equal(run['scale'],wave['scale'])
            raw=CubicSpline(run['scale'],run['values'][:,:,0])(axis);cols=run['channels'].tolist()
            saved=CubicSpline(wave['scale'],wave['values'][:,:,wave['branches'].tolist().index('wave'),:2].sum(2))(axis)
            blind=raw[:,:,cols.index('blind')];delta=saved-blind
            extrap=(8*saved[:,1]-saved[:,0])/7
            vecerr=mag(extrap-blind[:,1])/mag(blind[:,1])
            remainder=mag(delta[:,0]-8*delta[:,1])/mag(delta[:,0])
            ratio=mag(delta[:,0])/mag(delta[:,1])
            for i,key in enumerate(('energy','current','joint')):
                rows.append(dict(setting=setting,component=key,coarse_to_fine_norm=ratio[i],coarse_minus_eight_fine_relative=remainder[i],extrapolated_vs_blind_fine_relative=vecerr[i],passes=bool(vecerr[i]<=.005)))
    io.table('native-order-control.csv',rows)
    print([r for r in rows if r['setting']=='primary'])
if __name__=='__main__':check()
