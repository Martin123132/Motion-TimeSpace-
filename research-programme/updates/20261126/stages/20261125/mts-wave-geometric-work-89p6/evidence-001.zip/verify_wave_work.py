import csv,re
from blind_native_wave import ROOT,SEAL,MODES,np,io,guard,frozen,calculate,pin,digest,json
def rows(name):
    with (ROOT/name).open() as fp:return list(csv.DictReader(fp))
def verify():
    guard();frozen();checks=[]
    def require(label,test):
        assert test,label
        checks.append(label)
    for mode in MODES:
        receipt=json.loads((ROOT/f'replay-{mode}.json').read_bytes())
        require(mode+' native replay',all(v<=1e-10 for v in receipt['checks'].values()) and receipt['steps']==1024*int(mode[1:]))
        poisoned=calculate(mode,4,lambda t:np.full_like(t,np.nan))
        with np.load(ROOT/f'blind-{mode}-4.npz') as normal:
            require(mode+' U withheld',all(np.array_equal(normal[k],poisoned[k]) for k in ('required','terms','impulse','start','end')))
        for split in (2,4):
            with np.load(ROOT/f'work-{mode}-{split}.npz') as out,np.load(pin(f'comparison-{mode}-{split}.npz')) as matched:
                require(mode+str(split)+' exact common grid',np.array_equal(out['gravity'],out['grid'][::split]) and np.array_equal(out['grid'],matched['grid']))
                require(mode+str(split)+' unchanged matched forecast',np.array_equal(out['matched'],matched['equivalent']))
                require(mode+str(split)+' saved reference and balance identity',max(float(out[v]) for v in ('saved_knot_relative','identity_error'))<=.005)
                require(mode+str(split)+' blind sign',np.array_equal(out['blind'],(out['supplied']-out['required'])/out['D']))
        local=rows('local-'+mode+'.csv')
        require(mode+' source outcomes',len(local)==4 and all(0<=int(r['over_half_pct'])<=int(r['cells']) and float(r['rms_supplied'])>0 for r in local))
    eq=rows('equation-agreement.csv')
    require('independent unaveraged equations',len(eq)==26 and max(float(r['relative']) for r in eq)<1e-8)
    signed=rows('signed-work-comparison.csv');require('signed original-cell comparison',len(signed)==4 and all(abs(float(r['real_direction_cosine']))<=1 and float(r['half_refinement_relative'])<.005 for r in signed))
    third=rows('native-order-control.csv');require('unfitted native order control',len(third)==9 and all((r['passes']=='True')==(float(r['extrapolated_vs_blind_fine_relative'])<=.005) for r in third))
    compared=rows('photon-checks.csv');control=rows('controls.csv')
    for name,table in [('comparisons',compared),('controls',control)]:
        require(name+' full coverage',len(table)==(42 if name=='comparisons' else 35))
        require(name+' honest tolerance',all((r['passes']=='True')==(max(float(r[k]) for k in ('energy_relative','current_relative','joint_relative'))<=.005) for r in table))
    require('independent archive and signed decomposition',all(r['passes']=='True' for r in compared if r['test'] not in ('pure blind wave versus archived','two vs four wave substeps')))
    require('photon time and angular controls',all(r['passes']=='True' for r in control if r['refinement']!='gravity'))
    decisions=rows('photon-gates.csv')
    for r in decisions:
        require('gates '+str((r['mode'],r['setting'],r['case'])),(r['rate_pass']=='True')==(max(float(r[k]) for k in ('energy_pct','current_pct','joint_pct'))<=.5) and (r['size_pass']=='True')==(max(float(r[k]) for k in ('momentum_launch_pct','differentiated_launch_pct'))<.163))
    for note in ROOT.glob('*.md'):
        for link in re.findall(r'\]\(([^)]+)\)',note.read_text(encoding='utf-8')):require('link '+link,(ROOT/link).is_file())
    for code in ROOT.glob('*.py'):compile(code.read_bytes(),str(code),'exec')
    require('no temporary cache',not (ROOT/'__pycache__').exists())
    io.record('validation.json',dict(integrity_pass=True,checks=checks,native_forecast_matches_saved_wave=all(r['passes']=='True' for r in compared if r['test']=='pure blind wave versus archived'),primary_decisions=[r for r in decisions if r['setting']=='primary']))
    seal=ROOT/'seal.json';files={p.name:digest(p) for p in sorted(ROOT.iterdir()) if p.is_file() and p!=seal}
    io.record('seal.json',dict(files=files,prior=SEAL));print(len(checks),'integrity checks;',len(files),'files; seal',digest(seal))
if __name__=='__main__':verify()
