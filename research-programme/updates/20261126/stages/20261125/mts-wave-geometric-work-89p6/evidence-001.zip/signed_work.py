from score_wave_work import ROOT,MODES,io,pin,np,guard,frozen,peak
def run():
    frozen();guard();rows=[]
    for mode in MODES:
        split=4
        with np.load(ROOT/f'work-{mode}-4.npz') as wave,np.load(pin(f'comparison-{mode}-4.npz')) as matched,np.load(ROOT/f'work-{mode}-2.npz') as half:
            clock=wave['gravity'];dt=np.diff(clock)
            group=lambda v:v.reshape(len(dt),-1).sum(1)
            supplied=group(matched['supplied'])
            m=group(matched['supplied']-matched['required']);w=group(wave['supplied']-wave['required'])
            for label,use in [('all',np.ones(len(dt),bool)),('without_partial_entry',np.arange(len(dt))!=0)]:
                inner=lambda x,y:np.sum((x[use].conj()*y[use])/dt[use]);norm=lambda x:np.sqrt(inner(x,x).real)
                residual=m-w;share=inner(m,w).real/norm(m)**2
                refine=norm(group(half['supplied']-half['required'])-w)/norm(w)
                rows.append(dict(mode=mode,window=label,real_direction_cosine=inner(m,w).real/(norm(m)*norm(w)),
                           wave_signed_projection_on_matched=share,wave_norm_over_matched=norm(w)/norm(m),
                           differential_norm_over_matched=norm(residual)/norm(m),differential_rms_pct_common=100*norm(residual)/norm(supplied),
                           actual_source_increment_difference_pct_common=100*norm(group(wave['supplied'])-supplied)/norm(supplied),
                           half_refinement_relative=refine))
    io.table('signed-work-comparison.csv',rows)
    print([r for r in rows if r['window']=='all'])
if __name__=='__main__':run()
