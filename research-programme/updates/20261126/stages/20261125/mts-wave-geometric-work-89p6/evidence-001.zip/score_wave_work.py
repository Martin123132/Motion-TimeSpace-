from blind_native_wave import source,Wave,ROOT,MODES,KEYS,np,io,guard,frozen,peak,pin
from numpy.polynomial.legendre import leggauss
from inputs_product import CELLS,pin as prior_pin
def native_rhs_test(mode):
    src=source(mode);f=src.flow;solver=Wave(src);rows=[]
    with np.load(ROOT/f'native-{mode}.npz') as z:
        clock=z['eta'];trajectory=z['states'];keys=z['keys'].tolist()
        ix=np.linspace(np.searchsorted(clock,src.time[0])+1,len(clock)-1,12,dtype=int)
        env=src.environment(clock[ix]);x=trajectory[ix][:,[keys.index(k) for k in KEYS]]
        rawU=env[1]['U'];den=env[-1];h=env[0]['h'];en,j=solver.aggregate(env,x)
        phi=(rawU-en/2-1.5*h*j/src.kk)/den
        assert peak(phi-src.phi(clock[ix]))<1e-10*peak(phi)
        ans=solver.rhs(solver.env(clock[ix]),np.column_stack((x,phi)));comp=[]
        for i in ix:
            t=clock[i];u=np.log(t);y=trajectory[i,:,None,None];scale=f.factors*t**f.power[:,None,None]
            stress=src.stress(u)[:,None,None]*f.bg(u)[f.bgkeys.index('enu')];stress[1]*=f.k
            slope=f.jac_rhs(u,y/scale,1.)+f.injection(u,stress).transpose(1,0,2)
            dz=((slope+f.power[:,None,None]*y/scale)*scale/t)[:,0,0]
            comp.append([dz[keys.index(k)] for k in KEYS]+[src.p(t)])
        comp=np.asarray(comp)
        dv=np.max(abs(ans-comp),axis=0)/np.maximum(np.max(abs(comp),axis=0),1e-80)
        assert max(dv)<1e-8,(mode,dv)
        return [dict(mode=mode,variable=k,relative=v) for k,v in zip((*KEYS,'phi_rate'),dv)]
def score(mode):
    src=source(mode);solver=Wave(src);rows=[]
    for split in (2,4):
        with np.load(ROOT/f'blind-{mode}-{split}.npz') as b,np.load(pin(f'comparison-{mode}-{split}.npz')) as matched,np.load(prior_pin(CELLS,f'cells-{mode}-wave.npz')) as old:
            t=b['grid'];clock=b['gravity'];dt=np.diff(t);width=np.diff(clock);lo=t[:-1];hi=t[1:];D=b['D_right']
            assert np.array_equal(t,matched['grid']) and np.array_equal(clock,old['eta'])
            full=lambda x:x.reshape(len(width),split).sum(1)
            env=src.environment(t);sup=np.diff(env[1]['U']);req=b['required'];miss=sup-req;blind=miss/D
            nodes,weights=leggauss(4);points=lo[:,None]+dt[:,None]*(nodes+1)/2
            momentum=(dt[:,None]*weights/2*src.p(points)).sum(1)
            savedphi=src.phi(t);savedp=np.diff(savedphi)-momentum
            archive_error=peak((full(savedp)-old['signed_defect'])/width)/peak(old['signed_defect']/width)
            assert archive_error<.005,archive_error
            states=src.interp(t);states[:,-1]=savedphi;left=b['start'];right=b['end']
            env0=solver.env(lo);env1=solver.env(hi)
            def mass(env,state,ext=True):
                en,j=solver.aggregate(env,state,ext);return en/2+1.5*env[0]['h']*j/src.kk
            allD=env[-1]
            def offset(inputs):
                en,j=solver.aggregate(env,inputs[:,:-1]);return allD*savedphi+en/2+1.5*env[0]['h']*j/src.kk-env[1]['U']
            storage=np.diff(offset(states))/D
            dx1=right[:,:-1]-states[1:,:-1];dx0=left[:,:-1]-states[:-1,:-1]
            massall=(mass(env1,dx1,False)-mass(env0,dx0,False))/D
            heavy_indices=[KEYS.index(k) for k in ('hf','hw')]
            heavy0=np.zeros_like(dx0);heavy1=np.zeros_like(dx1);heavy0[:,heavy_indices]=dx0[:,heavy_indices];heavy1[:,heavy_indices]=dx1[:,heavy_indices]
            heavy=(mass(env1,heavy1,False)-mass(env0,heavy0,False))/D
            entry=(left[:,-1]-savedphi[:-1])*(env1[-1]-env0[-1])/D
            rate=b['impulse']-momentum
            remainder=heavy+(massall-heavy)+entry+storage+rate
            err=peak((full(blind+remainder)-old['signed_defect'])/width)/peak(old['signed_defect']/width)
            assert err<.005,(mode,err)
            io.pack(f'work-{mode}-{split}.npz',grid=t,gravity=clock,D=D,required=req,supplied=sup,blind=blind,saved=savedp,heavy_state=heavy,other_states=massall-heavy,entry=entry,storage=storage,rate=rate,accounted=blind+remainder,matched=matched['equivalent'],saved_knot_relative=archive_error,identity_error=err)
            for label,act,needed in [('wave',sup,req),('matched',matched['supplied'],matched['required'])]:
                true=full(act);diff=true-full(needed);norm=lambda z:np.sqrt(np.sum(abs(z)**2/width))
                rel=abs(diff)/abs(true)
                exclude=lambda z:np.sqrt(np.sum(abs(z[1:])**2/width[1:]))
                rows.append(dict(mode=mode,split=split,branch=label,cells=len(width),rate_rms_pct=100*norm(diff)/norm(true),without_entry_rate_rms_pct=100*exclude(diff)/exclude(true),peak_rate_pct=100*peak(diff/width)/peak(true/width),max_cell_pct=100*max(rel),over_half_pct=int(np.sum(rel>.005)),net_pct=100*abs(sum(diff))/abs(sum(true)),rms_supplied=float(norm(true)/np.sqrt(sum(width))),rms_discrepancy=float(norm(diff)/np.sqrt(sum(width)))))
    io.table(f'local-{mode}.csv',rows);print(rows[-2:],flush=True)
if __name__=='__main__':
    guard();frozen()
    rows=[r for mode in MODES for r in native_rhs_test(mode)];io.table('equation-agreement.csv',rows)
    for mode in MODES:score(mode)
