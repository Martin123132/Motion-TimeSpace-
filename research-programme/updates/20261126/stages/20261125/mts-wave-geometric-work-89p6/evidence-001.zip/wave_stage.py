from pathlib import Path
import hashlib,json,sys
ROOT=Path(__file__).resolve().parent
PRIOR=ROOT.parent/'mts-required-geometric-work-89p6-20261125'
SEAL='6f1ed1a5707288f88215c7e7bff3bfa38af4ab6844d8a5284650d0c74bc73b9c'
def digest(path):
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
assert digest(PRIOR/'seal.json')==SEAL
manifest=json.loads((PRIOR/'seal.json').read_bytes())['files']
def pin(name):
    path=PRIOR/name;assert digest(path)==manifest[name],name
    return path
sys.path.insert(0,str(PRIOR));pin('stage_u.py')
def owner():assert all(not (loc/'STOP-REQUESTED').exists() for loc in (ROOT,PRIOR))
