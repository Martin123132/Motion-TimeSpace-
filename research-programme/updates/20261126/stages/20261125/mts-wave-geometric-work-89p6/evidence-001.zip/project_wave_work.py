from wave_stage import ROOT,pin,owner,sys
from types import SimpleNamespace
from unittest.mock import patch
pin('work_photons.py')
import work_photons as prev
from work_photons import transport,io,gate,MODES,np
io.ROOT=ROOT
def packet(mode,branch):
    with np.load(ROOT/f'work-{mode}-4.npz') as hi,np.load(ROOT/f'work-{mode}-2.npz') as lo:
        t=hi['grid'];clock=hi['gravity'];dt=np.diff(t);assert np.array_equal(t[::2],lo['grid'])
        fields={key:hi[key]/dt for key in ('blind','saved','heavy_state','other_states','entry','storage','rate','accounted','matched')}
        fields.update(actual_work=hi['supplied']/hi['D']/dt,required_work=hi['required']/hi['D']/dt,
            half=np.repeat(lo['blind']/np.diff(lo['grid']),2),both_blind=fields['matched']-fields['blind'])
    return SimpleNamespace(time=clock,knots=t,values=np.column_stack(list(fields.values())),keys=list(fields)),None
def project():
    owner()
    with patch.object(transport,'ROOT',ROOT),patch.object(transport,'source',packet):
        for setting in ('primary','time','angle'):transport.project(setting)
if __name__=='__main__':project()
