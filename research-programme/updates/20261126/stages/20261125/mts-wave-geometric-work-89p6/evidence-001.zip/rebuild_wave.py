from wave_stage import ROOT,PRIOR,SEAL,pin,digest,owner,sys,json
import importlib.util
from unittest.mock import patch
pin('required_u.py')
from required_u import io,np,MODES,prior
from inputs_product import SWITCH,END,make_interp_spline,CubicSpline
io.ROOT=ROOT
BASE=prior.matter.BASE89
def native(name):return io.old.pin(name)
spec=importlib.util.spec_from_file_location('native_work_block',native('block.py'))
library=importlib.util.module_from_spec(spec);spec.loader.exec_module(library)
def guard():owner();library.guard();prior.guard()
def getflow(mode):
    guard();wavefile=native(f'particular-heavy-{mode}.npz')
    report=json.loads(native(f'metric-heavy-{mode}.json').read_bytes())
    bank=native('bank-heavy.json');assert digest(bank)==report['source_bank']
    hashes=json.loads(bank.read_bytes());assert len(hashes)==82 and all(digest(BASE/key)==sha for key,sha in hashes.items())
    for name in ('forcing','radiation','collisionless','origin-v2'):native('material-halfstep/'+name+'-heavy.npz')
    native('gravity89.py')
    restart=library.grav_start('heavy',mode,'particular');meta=library.grav_start('heavy',mode,'metric')
    assert report['passed'] and digest(wavefile)==report['output_digest'] and report['parent']==digest(restart)==json.loads(meta.read_bytes())['output_digest']
    with np.load(restart) as saved:
        assert saved['eta'][-1]==83.2;initial=saved['state'][:,:1];keys=saved['keys']
    with np.load(native('common-heavy.npz')) as bankdata:
        knots=bankdata['eta'];common=bankdata['S'][None]
    with np.load(native('material-halfstep/forcing-heavy.npz')) as src:act=src['eta'][8:-8]
    obj=object.__new__(prior.matter.Flow)
    with patch.object(library.regular_flow,'HOME',BASE/'material-halfstep'):library.Flight.__init__(obj,'heavy',68,6,False,True)
    assert obj.tags=='sh' and obj.keys==keys.tolist()
    obj.initial=(keys,initial);obj.wall=None;obj.start_offset=None
    q=make_interp_spline(obj.log,obj.q(obj.log),k=5);obj.bg=make_interp_spline(obj.log,obj.bg(obj.log),k=5)
    obj.k=obj.k[:1];obj.factors=obj.factors[:,:1];obj.probe=obj.probe[:,:1];obj.q=lambda u:q(u)[...,:1]
    obj.drive=library.spline(knots,common.transpose(2,1,0))
    refine=int(mode[1:]);obj.t=np.linspace(act[0],act[-1],(len(act)-1)*refine+1);obj.t[::refine]=act;obj.log=np.log(obj.t)
    return obj,wavefile,restart
def replay(mode):
    obj,path,restart=getflow(mode)
    print(mode,'native replay from 83.2 with sealed stress',flush=True)
    with np.load(path) as target:
        assert np.array_equal(obj.t,target['eta'])
        clock=target['stressClock'];stress=target['stress']
        t,obs,normal,states=obj.evolve(clock,stress)
        rate=-obs[:,3,0,0]/t-obj.bg(obj.log)[:,obj.bgkeys.index('h')]*obs[:,1,0,0]+obj.q(obj.log)[:,obj.qkeys.index('Fq'),0]
        def error(x,y,axis=0):
            return float(np.max(np.max(abs(x-y),axis=axis)/np.maximum(np.max(abs(y),axis=axis),1e-80)))
        checks=dict(phi=error(obs[:,0,0,0],target['phi']),psi=error(obs[:,1,0,0],target['psi']),momentum_rate=error(rate,target['phi_dot']),all_observables=error(obs,target['obs']),both_seed_multipoles=error(normal,target['normal']),final_state=error(states[-1],target['state']))
        assert max(checks.values())<1e-10,checks
        cut=np.searchsorted(t,SWITCH)-10;assert t[cut]<SWITCH
        io.pack(f'native-{mode}.npz',eta=t[cut:],keys=obj.keys,states=states[cut:,:,0,0],stress_clock=clock,stress=stress[:,:,0,0])
        io.record('replay-'+mode+'.json',dict(checks=checks,steps=len(t)-1,restart=digest(restart),reference=digest(path),stress_bank=digest(native('bank-heavy.json'))))
        print(mode,'verified',checks,flush=True)
if __name__=='__main__':
    for mode in sys.argv[1:]:replay(mode)
