from functools import lru_cache
from wave_stage import ROOT,PRIOR,pin,SEAL,digest,owner,sys,json
from rebuild_wave import io,np,MODES,SWITCH,END,getflow,guard,CubicSpline
from required_u import Blind,KEYS,TERMS,peak

class Source:
    def __init__(self,mode):
        self.flow,wavefile,_=getflow(mode);self.wave=float(self.flow.k[0,0]);self.kk=self.wave**2;self.corners=[]
        report=json.loads((ROOT/f'replay-{mode}.json').read_bytes());assert max(report['checks'].values())<1e-10 and report['reference']==digest(wavefile)
        with np.load(ROOT/f'native-{mode}.npz') as data:
            self.native=data['eta'];keys=data['keys'].tolist();states=data['states']
            self.interp=CubicSpline(self.native,states[:,[keys.index(n) for n in (*KEYS,'geom')]],extrapolate=False)
            self.quads=CubicSpline(self.native,states[:,[keys.index(n) for n in ('I2','N2')]],extrapolate=False)
            self.stress=CubicSpline(np.log(data['stress_clock']),data['stress'],extrapolate=False)
        with np.load(wavefile) as data:
            self.phi=CubicSpline(data['eta'],data['phi'],extrapolate=False);self.p=CubicSpline(data['eta'],data['phi_dot'],extrapolate=False)
        self.time=np.r_[SWITCH,self.native[self.native>SWITCH]]
        assert self.time[-1]==END
    def environment(self,t,side=None):
        u=np.log(t);f=self.flow
        b=dict(zip(f.bgkeys,f.bg(u).T));q=dict(zip(f.qkeys,f.q(u)[:,:,0].T))
        stress=self.stress(u)*b['enu'][:,None];stress[:,1]*=self.wave
        den=self.kk+(3*(b['ec']+b['eb']+b['sv']**2+b['hv']**2)+4*(b['eg']+b['er'])+b['nuE'])/2
        return b,q,stress,None,self.quads(t).T,f.drive(u)[:,:2,0].T,None,den
@lru_cache(maxsize=2)
def source(mode):return Source(mode)
class Wave(Blind):
    def aggregate(self,env,x,ext=True):
        b,q,stress,_,quad,drive,_,d=env
        gx,W,B,N0,N1,cd,ct,bd,sf,sw,hf,hw=x.T
        en=b['eg']*gx+b['eb']*bd+(4*b['er']+b['nuE'])*N0+b['ec']*cd
        j=b['eg']*W+self.wave*(4*b['er']+b['nuJ'])*N1+b['ec']*ct
        for tag,field,speed in [('s',sf,sw),('h',hf,hw)]:
            en+=b[tag+'v']*speed+(b['a']*b[tag+'m'])**2*b[tag+'b']*field
            j+=self.kk*b[tag+'v']*field
        if ext:
            en+=q['gE']+q['btrace']+q['bKE']+stress[:,0]+q['ctrace']+q['cKE']+q['senergy']+q['henergy']
            j+=q['gJ']+q['bJq']+q['nuJ']+stress[:,1]+q['cJq']+q['sJ']+q['hJ']
        return en,j
    def rhs(self,env,state):
        b,q,stress,_,quad,drive,_,d=env
        gx,W,B,N0,N1,cd,ct,bd,sf,sw,hf,hw,phi=state.T
        h=b['h'];r=b['eb']/b['eg'];op=b['opacity'];kk=self.kk;bt=(W-B)/(r+4/3);gj=B+4*bt/3
        curr=self.aggregate(env,state[:,:-1])[1]
        slip=(-q['Q']-b['eg']*(quad[0]+q['ph_shift'])-(4*b['er']+b['nuS'])*quad[1]+stress[:,2]+q['cshear']+q['bshear']+q['sshear']+q['hshear'])/kk
        psi=phi+slip;pd=curr/(2*kk)-h*psi+q['Fq']
        gfree=kk*(gx/3+4*(psi+phi)/3-2*quad[0]/3)+q['ph_momentum']
        fields=[]
        for tag,field,speed in [('s',sf,sw),('h',hf,hw)]:
            m2=(b['a']*b[tag+'m'])**2
            fields.extend((speed+b[tag+'v']*(psi+3*phi)+q[tag+'field'],
                           -2*h*speed-(kk+m2)*field+m2*b[tag+'b']*(3*phi-psi)+q[tag+'moment']))
        return np.column_stack((-gj+q['ph_energy']-op*q['collision_heat'],
            gfree+r*(kk*psi+q['bspeed'])+op*(q['collision_b']-q['collision_ph']),
            gfree-4*(-h*bt+kk*psi+q['bspeed'])/3-op*((1+4/(3*r))*B+q['collision_ph']+4*q['collision_b']/(3*r)),
            -self.wave*N1+drive[0],self.wave*(N0+phi+psi-2*quad[1])/3+drive[1],
            -ct+q['cnumber'],-h*ct+kk*psi+q['cspeed'],-bt+q['bnumber'],*fields,pd))

def calculate(mode,split,alter=None):
    guard();src=source(mode);solver=Wave(src,alter);time=src.time;lo=time[:-1];hi=time[1:]
    knots=lo[:,None]+(hi-lo)[:,None]*np.arange(split+1)/split;knots[:,-1]=hi
    state=src.interp(lo);state[:,-1]=src.phi(lo)
    inputs=[];outputs=[];pieces=[];scales=[];direct=[];imp=[]
    for j in range(split):
        a=knots[:,j];b=knots[:,j+1];delta=solver.advance(a,b,state)
        terms,D,raw=solver.work(a,b,state,delta)
        inputs.append(state);state=state+delta;outputs.append(state);pieces.append(terms);scales.append(D);direct.append(raw);imp.append(delta[:,-1])
    flat=lambda x:np.stack(x,axis=1).reshape(len(lo)*split,-1)
    grid=np.r_[knots[:,:-1].ravel(),time[-1]];terms=flat(pieces);required=terms.sum(1);D=flat(scales)[:,0]
    err=peak((required-flat(direct)[:,0])/np.diff(grid))/peak(required/np.diff(grid))
    assert err<.005 and np.isfinite(terms).all(),err
    return dict(gravity=time,grid=grid,terms=terms,term_names=TERMS,D_right=D,required=required,start=flat(inputs),end=flat(outputs),impulse=flat(imp)[:,0],product_error=err)
def manifest():
    names=['PROTOCOL.md','wave_stage.py','rebuild_wave.py','blind_native_wave.py']
    for mode in MODES:names.extend([f'replay-{mode}.json',f'native-{mode}.npz',*[f'blind-{mode}-{n}.npz' for n in (2,4)]])
    return dict(prior=SEAL,files={key:digest(ROOT/key) for key in names})
def frozen():assert json.loads((ROOT/'frozen.json').read_bytes())==manifest()
if __name__=='__main__':
    for mode in MODES:
        for split in (2,4):io.pack(f'blind-{mode}-{split}.npz',**calculate(mode,split))
    io.record('frozen.json',manifest());print('Wave requirements frozen before scoring.',flush=True)
