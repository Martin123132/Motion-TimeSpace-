import ast
import csv
import sys
from pressure_stage import ROOT,FIRST,common,np,MODES,SETTINGS,pinned,locked,freeze

def rows(name):
    with (ROOT/name).open() as stream:
        return list(csv.DictReader(stream))

def verify():
    for receipt in ('source-freeze.json','prediction-freeze.json','score-receipt.json'):
        locked(receipt)
    for mode in MODES:
        with np.load(ROOT/f'source-{mode}-4.npz') as fine,np.load(ROOT/f'source-{mode}-2.npz') as coarse:
            assert np.array_equal(fine['gravity'],coarse['gravity'])
            assert np.array_equal(fine['knots'][np.searchsorted(fine['knots'],coarse['knots'])],coarse['knots'])
            for src in (fine,coarse):
                assert np.all(np.diff(src['knots'])>0) and src['values'].shape==(len(src['knots'])-1,5)
                assert np.isfinite(src['values']).all()
    for name in ('PROTOCOL.md','RESULTS.md','physical-gates.csv'):
        pinned(FIRST,name)
    scores=rows('photon-score.csv')
    assert {(r['mode'],r['setting'],r['subdivision']) for r in scores}=={(m,s,n) for m in MODES for s in SETTINGS for n in ('2','4')} and len(scores)==12
    for row in scores:
        updated=np.array([float(row[k]) for k in ('updated_energy_pct','updated_current_pct','updated_joint_pct')])
        assert np.isfinite(updated).all() and (max(updated)<=.5)==(row['all_channels_pass']=='True')
        assert abs(float(row['joint_norm_change_pp']))<=float(row['increment_size_pp'])+2e-15
    controls=rows('numerical-checks.csv')
    assert len(controls)==35
    for row in controls:
        errors=[float(row[k]) for k in ('energy_pct','current_pct','joint_pct')]
        assert np.isfinite(errors).all() and (max(errors)<=.5)==(row['passes']=='True')
    for setting in SETTINGS:
        quadrature=rows(f'quadrature-{setting}.csv')
        assert len(quadrature)==2 and all(0<=float(r['relative'])<=.005 for r in quadrature)
    bessel=rows('bessel-control.csv')
    assert len(bessel)==6 and all(0<=float(r['error_pct'])<=.5 for r in bessel)
    split=rows('time-split/split-score.csv')
    assert len(split)==24 and all(max(float(r[k]) for k in ('replay_error_pct','split_addition_error_pct'))<=.5 for r in split)
    common.ROOT=ROOT/'time-split'
    for receipt in ('source-freeze.json','prediction-freeze.json','seal.json'):locked(receipt)
    common.ROOT=ROOT
    assert not list(ROOT.rglob('__pycache__'))
    for path in ROOT.glob('*.py'):ast.parse(path.read_text())
    if '--seal' in sys.argv:
        assert (ROOT/'RESULTS.md').is_file()
        freeze('seal.json',sorted(p.name for p in ROOT.iterdir() if p.is_file() and p.name!='seal.json')+['time-split/seal.json'])
        locked('seal.json')
        print(common.sha(ROOT/'seal.json'))
if __name__=='__main__':verify()
