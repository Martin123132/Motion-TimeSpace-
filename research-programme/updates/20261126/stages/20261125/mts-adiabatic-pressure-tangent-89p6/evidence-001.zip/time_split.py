import sys
from scipy.interpolate import CubicSpline
from pressure_stage import ROOT, window, common, FIRST, locked, pinned, np, MODES, SETTINGS

CHILD=ROOT/'time-split'
def split():
    locked('source-freeze.json')
    locked('score-receipt.json')
    CHILD.mkdir(exist_ok=True)
    common.ROOT=window.ROOT=CHILD
    for mode in MODES:
        for sub in (2,4):
            name=f'source-{mode}-{sub}.npz'
            with np.load(ROOT/name) as src,np.load(pinned(FIRST,f'launch-{mode}-matched-{sub}.npz')) as launch:
                edge=launch['first_end'].item()
                old=src['knots']
                knots=np.unique(np.r_[old,edge])
                ix=np.searchsorted(old,knots[:-1],side='right')-1
                full=src['values'][ix,0]
                first=np.where(knots[1:]<=edge,full,0j)
                late=np.where(knots[:-1]>=edge,full,0j)
                assert np.array_equal(full,first+late)
                common.pack(name,knots=knots,gravity=src['gravity'],values=np.column_stack([full,first,late]),keys=['all','first','later'])
    common.freeze('source-freeze.json',[f'source-{mode}-{sub}.npz' for mode in MODES for sub in (2,4)])
    window.photons()

def score_split():
    locked('prediction-freeze.json')
    common.ROOT=window.ROOT=CHILD
    locked('source-freeze.json');locked('prediction-freeze.json')
    from angular_photons import gate
    from cell89 import pin as original
    _,axis,wt,_=gate.proj.old.get_media()
    measure=gate.previous.make_measure(axis,wt)
    mag=lambda value:gate.mag(value,measure)
    rows=[]
    for setting in SETTINGS:
        name=f'photons-{setting}.npz'
        with np.load(CHILD/name) as splitbank,np.load(ROOT/name) as unsplit,np.load(pinned(window.ARCHIVE,name)) as archive,np.load(original(f'photon-{setting}.npz')) as old:
            grid=splitbank['scale']
            assert np.array_equal(grid,old['grid']) and all(np.array_equal(grid,data['scale']) for data in (archive,unsplit))
            view=lambda values:CubicSpline(grid,values)(axis)
            for idx,mode in enumerate(MODES):
                def parts(data):
                    assert data['modes'].tolist()==list(MODES)
                    return dict(zip(data['channels'].tolist(),view(data['values'][:,idx,0]).swapaxes(0,1),strict=True))
                changes=parts(splitbank);saved=parts(archive);orig=parts(unsplit)
                norm=mag(view(old['values'][:,old['labels'].tolist().index([mode,'primary']),:3]).sum(1))
                for prefix in ('','half_'):
                    full=changes[prefix+'all']
                    linear=max(100*mag(full-changes[prefix+'first']-changes[prefix+'later'])/mag(full))
                    replay=max(100*mag(full-orig[prefix+'increment'])/mag(orig[prefix+'increment']))
                    for key in ('first','later'):
                        ref=saved[prefix+'first'] if key=='first' else saved[prefix+'full']-saved[prefix+'first']
                        val=changes[prefix+key]
                        signed=(measure@(val*ref.conj()).real).sum()/mag(ref)[2]
                        rows.append(dict(mode=mode,setting=setting,subdivision=2 if prefix else 4,window=key,original_joint_pct=100*mag(ref)[2]/norm[2],
                                         increment_size_pp=100*mag(val)[2]/norm[2],signed_along_own_gap_pp=100*signed/norm[2],
                                         split_addition_error_pct=linear,replay_error_pct=replay))
    common.table('split-score.csv',rows)
    common.freeze('seal.json',sorted(p.name for p in CHILD.iterdir() if p.is_file() and p.name!='seal.json'))
    common.locked('seal.json')
    print([r for r in rows if r['setting']=='primary' and r['subdivision']==4],flush=True)

if __name__=='__main__':
    window.safe()
    {'split':split,'score':score_split}[sys.argv[1]]()
