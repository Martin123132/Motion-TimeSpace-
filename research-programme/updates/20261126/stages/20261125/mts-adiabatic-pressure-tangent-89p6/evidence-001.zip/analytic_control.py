from scipy.special import jv,yv
from pressure_stage import np,table,check

def run():
    check()
    rows=[]
    for expansion in (.5,2/3):
        order=(3*expansion-1)/2
        for mt in (800.,1500.,2500.):
            potential=jv(order,mt)**2+yv(order,mt)**2
            kinetic=jv(order+1,mt)**2+yv(order+1,mt)**2
            exact=(kinetic-potential)/(kinetic+potential)
            predicted=3*expansion/(4*mt**2)
            error=100*abs(exact-predicted)/abs(exact)
            assert error<=.5
            rows.append(dict(scale_factor_power=expansion,mass_times_proper_time=mt,exact=exact,leading=predicted,error_pct=error))
    table('bessel-control.csv',rows)
if __name__=='__main__':run()
