import sys
from scipy.interpolate import CubicSpline
from pressure_stage import ROOT, window, common, FIRST, np, MODES, previous, pinned, pack, table, freeze, check

pinned(window.PAIR,'energy_current.py')
sys.path.insert(0,str(window.PAIR))
from pair_stage import guard
from cycle3_inputs import make, inputs_density, operator, DIM, QI, QN, forms

def pressure_weight(hub, derivative, omega_squared):
    return .75*(hub**2-derivative)/omega_squared

def source(mode,split):
    src,solver,grid,entry,_=make(mode,'matched',split)
    with np.load(pinned(FIRST,f'launch-{mode}-matched-{split}.npz')) as launch:
        assert np.array_equal(entry,launch['launch'])
    kk=src.kk
    with np.load(inputs_density.ip.companion(mode)) as packet,np.load(previous(f'preparation-{mode}.npz')) as prep:
        knots=packet['eta']
        assert np.array_equal(knots,prep['eta'])
        ener=packet['companion_e'][:,0]+prep['density'][:,0]
        curr=packet['companion_j'][:,0]+prep['current']
        assert ener.shape==curr.shape==knots.shape
        speed=packet['cs2']
        omega2=kk*(1-speed)**2/(4*speed)
        assert max(abs(omega2/packet['scale']**2/(omega2[0]/packet['scale'][0]**2)-1))<1e-12
        mass2=omega2[0]/packet['scale'][0]**2
    breaks=np.asarray(src.corners)
    curves=[]
    for left,right in zip(np.r_[-np.inf,breaks],np.r_[breaks,np.inf]):
        use=(knots>=left+5e-9)&(knots<=right-5e-9)
        curves.append(CubicSpline(knots[use],np.column_stack([ener[use],curr[use]])))
    cuts=np.unique(np.r_[grid,breaks[(breaks>grid[0])&(breaks<grid[-1])]])
    state=entry.copy()
    delta=np.zeros_like(entry)
    history=[delta.copy()]
    w_min,w_max,adiabatic,gradient,ward=np.inf,-np.inf,0.,0.,0.
    for begin in range(0,len(cuts)-1,32):
        check()
        left=cuts[begin:min(begin+32,len(cuts)-1)]
        right=cuts[begin+1:begin+1+len(left)]
        mid=(left+right)/2
        sides=np.searchsorted(breaks,mid,side='right')
        operators=[]
        for times in (left,mid,right):
            matrix,photon,neutrino=operator(solver,times,mid)
            matrix[:,:13,QI]+=photon
            matrix[:,:13,QN]+=neutrino
            bg=src.environment(times,mid)[0]
            hub=bg['h']
            dh=src.flow.bg(np.log(times),1)[:,src.flow.bgkeys.index('h')]/times
            om2=bg['a']**2*mass2
            factor=pressure_weight(hub,dh,om2)
            w_min=min(w_min,min(factor));w_max=max(w_max,max(factor))
            adiabatic=max(adiabatic,max(abs(hub)/np.sqrt(om2)))
            gradient=max(gradient,max(kk/om2))
            anchor=np.empty(times.size,complex)
            for index,curve in enumerate(curves):
                select=sides==index
                if np.any(select):
                    density,current=curve(times[select]).T
                    anchor[select]=density+3*hub[select]*current/kk
            operators.append((matrix,hub,factor,anchor))
        for idx,dt in enumerate(right-left):
            def rhs(stage,control,response):
                matrix,hub,factor,anchor=operators[stage]
                mat=matrix[idx,:,:DIM];hr=hub[idx]
                departure=(control[10]+3*control[12]+3*hr*control[11]/kk-anchor[idx])+(response[10]+3*response[12]+3*hr*response[11]/kk)
                pressure=factor[idx]*departure
                dresponse=mat@response
                dresponse[10]-=3*hr*pressure
                dresponse[11]+=kk*pressure
                return mat@control+matrix[idx,:,-1],dresponse
            a,da=rhs(0,state,delta)
            b,db=rhs(1,state+.5*dt*a,delta+.5*dt*da)
            c,dc=rhs(1,state+.5*dt*b,delta+.5*dt*db)
            d,dd=rhs(2,state+dt*c,delta+dt*dc)
            state+=dt/6*(a+2*b+2*c+d)
            delta+=dt/6*(da+2*db+2*dc+dd)
            history.append(delta.copy())
    history=np.array(history)
    assert np.isfinite(history).all() and not history[0].any()
    env=src.environment(cuts)
    weights,_,den=forms(env,kk,src.wave,False)
    parts=-np.einsum('ntk,nk->nt',weights,history[:,:13])
    heavy,metric,ordinary=parts.T
    amount=heavy+metric+ordinary
    energy,current=solver.aggregate(env,history[:,:12],ext=False)
    direct=-den*history[:,12]-energy/2-1.5*env[0]['h']*current/kk
    error=max(abs(direct-amount))/max(abs(amount))
    loc=np.searchsorted(grid,cuts[:-1],side='right')-1
    assert np.all(cuts[1:]<=grid[loc+1])
    denom=src.environment(grid)[-1][loc+1]*np.diff(cuts)
    values=np.column_stack([np.diff(channel)/denom for channel in (amount,heavy,metric,ordinary,direct)])
    assert 0<=error<.005 and adiabatic<.05 and gradient<.05 and np.isfinite(values).all() and np.any(values[:,0])
    pack(f'source-{mode}-{split}.npz',knots=cuts,gravity=src.time,keys=['increment','heavy','metric','ordinary','direct'],values=values)
    return dict(mode=mode,split=split,cells=len(cuts)-1,min_w=w_min,max_w=w_max,max_H_over_m=adiabatic,max_k2_over_am2=gradient,
                constraint_agreement_pct=100*error,entry_delta=float(abs(amount[0])),max_delta_phi=float(max(abs(history[:,12]))))

if __name__=='__main__':
    check()
    assert pressure_weight(0,0,3)==0 and pressure_weight(1,1,3)==0
    assert pressure_weight(1,-1,1)==1.5 and pressure_weight(1,-.5,1)==1.125
    rows=[]
    for mode in MODES:
        for split in (2,4):
            rows.append(source(mode,split))
            print(rows[-1],flush=True)
    table('source-controls.csv',rows)
    freeze('source-freeze.json',['pressure_stage.py','pressure.py','score.py','PROTOCOL.md','source-controls.csv']+[f'source-{mode}-{split}.npz' for mode in MODES for split in (2,4)])
