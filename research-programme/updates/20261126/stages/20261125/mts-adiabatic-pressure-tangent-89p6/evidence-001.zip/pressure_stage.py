from pathlib import Path
import hashlib
import json
import sys

ROOT = Path(__file__).resolve().parent
FIRST = ROOT.parent / 'mts-first-cycle-full-window-photons-89p6-20261125'
FIRST_HASH = 'c5362b583c6074cc273103a4829605ee3b1cd07c3300706c73e76c6c56c056fd'
def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream,'sha256').hexdigest()
assert digest(FIRST/'seal.json') == FIRST_HASH
assert digest(FIRST/'window_stage.py') == json.loads((FIRST/'seal.json').read_bytes())['files']['window_stage.py']
sys.path.insert(0,str(FIRST))
import window_stage as window
from window_stage import common, np, MODES, SETTINGS, previous, pinned, locked, pack, table, freeze, angular
window.ROOT = common.ROOT = ROOT
common.PINS = {**common.PINS,FIRST:FIRST_HASH}
def check():
    window.safe()
if __name__ == '__main__':
    assert sys.argv[1:] == ['photons']
    window.photons()
