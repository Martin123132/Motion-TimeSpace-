from scipy.interpolate import CubicSpline
from pressure_stage import ROOT, window, pinned, locked, np, check, MODES, SETTINGS, angular, table, freeze

angular('angular_photons.py')
from angular_photons import gate
from cell89 import pin as original

def run():
    check()
    locked('source-freeze.json');locked('prediction-freeze.json')
    _,axis,weights,_=gate.proj.old.get_media()
    measure=gate.previous.make_measure(axis,weights)
    def mag(vec):return gate.mag(vec,measure)
    outcomes,checks,cache=[],[],{}
    def compare(mode,setting,key,one,two):
        err=100*mag(one-two)/mag(two)
        assert np.isfinite(err).all()
        checks.append(dict(mode=mode,setting=setting,control=key,energy_pct=err[0],current_pct=err[1],joint_pct=err[2],passes=bool(max(err)<=.5)))
    for setting in SETTINGS:
        name=f'photons-{setting}.npz'
        with np.load(ROOT/name) as correction,np.load(pinned(window.ARCHIVE,name)) as archive,np.load(original(f'photon-{setting}.npz')) as old:
            grid=correction['scale']
            assert np.array_equal(grid,archive['scale']) and np.array_equal(grid,old['grid'])
            def view(values):return CubicSpline(grid,values)(axis)
            for idx,mode in enumerate(MODES):
                def unpack(bank):
                    assert bank['modes'].tolist()==list(MODES)
                    return dict(zip(bank['channels'].tolist(),view(bank['values'][:,idx,0]).swapaxes(0,1),strict=True))
                new=unpack(correction);ref=unpack(archive)
                norm=mag(view(old['values'][:,old['labels'].tolist().index([mode,'primary']),:3]).sum(1))
                for prefix in ('','half_'):
                    oldgap=ref[prefix+'full'];effect=new[prefix+'increment'];updated=oldgap+effect
                    compare(mode,setting,prefix+'sum',sum(new[prefix+key] for key in ('heavy','metric','ordinary')),effect)
                    compare(mode,setting,prefix+'independent_constraint',new[prefix+'direct'],effect)
                    base=100*mag(oldgap)/norm;after=100*mag(updated)/norm;shift=100*mag(effect)/norm
                    signed=100*(measure@(effect*oldgap.conj()).real).sum()/mag(oldgap)[2]**2
                    outcomes.append(dict(mode=mode,setting=setting,subdivision=2 if prefix else 4,
                                         original_joint_pct=base[2],updated_energy_pct=after[0],updated_current_pct=after[1],
                                         updated_joint_pct=after[2],joint_norm_change_pp=after[2]-base[2],increment_size_pp=shift[2],
                                         signed_share_of_gap_pct=signed,all_channels_pass=bool(max(after)<=.5)))
                compare(mode,setting,'source_refinement',new['half_increment'],new['increment'])
                cache[mode,setting]=new['increment']
    for mode in MODES:
        for setting in ('time','angle'):
            compare(mode,setting,'photon_refinement',cache[mode,setting],cache[mode,'primary'])
    compare('p16-p32','primary','gravity_refinement',cache['p16','primary'],cache['p32','primary'])
    table('photon-score.csv',outcomes);table('numerical-checks.csv',checks)
    freeze('score-receipt.json',['prediction-freeze.json','photon-score.csv','numerical-checks.csv'])
    print([r for r in outcomes if r['setting']=='primary' and r['subdivision']==4],flush=True)
    print(len(checks),'controls; failures:',[r for r in checks if not r['passes']],flush=True)

if __name__=='__main__':run()
