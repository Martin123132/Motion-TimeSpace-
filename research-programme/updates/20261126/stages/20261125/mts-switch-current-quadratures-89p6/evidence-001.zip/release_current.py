from current_stage import MODES,check,locked,table
from score_current import release
from compare_clocks import run as compare

if __name__=='__main__':
    check()
    for name in ('launch-freeze.json','delta-freeze.json','conditional-freeze.json'):locked(name)
    rows,launches,scales=[],[],[]
    for mode in MODES:
        for sub in (2,4):
            part,init,scale=release(mode,sub)
            rows.extend(part);launches.extend(init);scales.append(scale)
    table('direct-tests.csv',rows);table('switch-states.csv',launches);table('signal-scales.csv',scales)
    compare()
