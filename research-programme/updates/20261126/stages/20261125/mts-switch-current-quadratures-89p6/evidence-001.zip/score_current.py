from scipy.interpolate import CubicSpline,make_interp_spline
from current_stage import ROOT,KIN,FIRST,MODES,np,pinned,driver,wave_input,window,check,pack,table,freeze,locked
pinned(KIN,'dynamics.py')
from dynamics import make,propagate

def rms(times,values):
    widths=np.diff(times)
    power=abs(values)**2
    return np.sqrt(np.average((power[1:]+power[:-1])/2,weights=widths,axis=0))

def release(mode,sub):
    with np.load(ROOT/f'delta-{mode}-{sub}.npz') as dp,np.load(ROOT/f'conditional-{mode}-{sub}.npz') as cp,np.load(ROOT/f'launch-{mode}.npz') as inv:
        times=dp['times'];pred=dp['momentum'];from_entry=dp['from_entry'];from_geom=dp['from_geometry']
        conditional=cp['momentum'];cf=cp['field_flux'];state=cp['states'];omega=inv['omega'].item();rho0=inv['rho0'].item()
        launch=inv['live'];prep_launch=inv['prep']
    src,solver,_,entry,_=make(mode,'wave',sub)
    with np.load(pinned(FIRST,f'work-{mode}-wave-{sub}.npz')) as arc:
        edges=arc['edges'];saved=arc['states']
    merged=np.unique(np.r_[times,edges])
    replay=propagate(src,solver,merged,entry)
    replay_err=max(np.max(abs(replay[np.searchsorted(merged,edges)]-saved),axis=1)/np.max(abs(saved),axis=1))
    assert replay_err<.005
    history=replay[np.searchsorted(merged,times)]
    bg,forcing=src.environment(times)[:2];kk=src.kk
    factors=kk*bg['hv']
    direct=factors*history[:,10]
    total=direct+forcing['hJ']
    with np.load(wave_input(f'particular-heavy-{mode}.npz')) as old:
        axis=old['eta'];field=old['obs'][:,10,0,0]
        cal=CubicSpline(axis,field)(times);quint=make_interp_spline(axis,field,k=5)(times)
    delta=factors*(history[:,10]-cal)
    with np.load(driver(f'projected-{mode}.npz')) as old:
        old_j=CubicSpline(old['eta'],old['resolved_j'][:,0])(times)*rho0/bg['a']
    refcheck=factors*cal+forcing['hJ']-old_j
    with np.load(pinned(KIN,f'anchored-{mode}-{sub}.npz')) as kin:
        boundary=kin['first_end'].item()
    rows=[]
    def record(label,guess,ref,base):
        for key,start,end in [('all',times[0],times[-1]),('first',times[0],boundary),('later',boundary,times[-1])]:
            within=(times>start)&(times<end)
            local=np.r_[start,times[within],end]
            def mag(vec):
                endvals=CubicSpline(times,vec)([start,end])
                return rms(local,np.r_[endvals[0],vec[within],endvals[1]])
            err=mag(guess-ref);den=mag(ref);common=mag(base)
            rows.append(dict(mode=mode,sub=sub,window=key,quantity=label,relative_pct=100*err/den if den else '',rms_error=err,
                             rms_target=den,pct_of_common=100*err/common,passes=bool(den>0 and err/den<=.005)))
    record('field_quadrature',state[:,0],history[:,10],history[:,10])
    record('velocity_quadrature',state[:,1],history[:,11]/omega,history[:,11]/omega)
    record('conditional_total_J',conditional,total,total)
    record('conditional_field_only_J',cf,direct,direct)
    record('delta_J',pred,delta,total)
    record('preparation_interpolation',factors*(history[:,10]-quint),delta,total)
    record('prepared_J_representation',delta+refcheck,delta,total)
    scale=lambda a:rms(times,a)
    energy=[]
    for key,trial in [('live',launch),('prepared',prep_launch)]:
        truth=history[0,10:12]/[1,omega]
        for idx,name in enumerate(('field','scaled_velocity')):
            err=abs(trial[idx]-truth[idx])/abs(truth[idx])
            energy.append(dict(mode=mode,sub=sub,launch=key,quadrature=name,relative_pct=100*err,passes=bool(err<=.005)))
    primary=dict(mode=mode,sub=sub,replay_pct=100*replay_err,delta_over_total_pct=100*scale(delta)/scale(total),
                 pred_over_total_pct=100*scale(pred)/scale(total),entry_over_total_pct=100*scale(from_entry)/scale(total),
                 metric_over_total_pct=100*scale(from_geom)/scale(total))
    pack(f'reference-{mode}-{sub}.npz',times=times,delta=delta,total=total,field=direct)
    return rows,energy,primary

if __name__=='__main__':
    check()
    for receipt in ('launch-freeze.json','delta-freeze.json','conditional-freeze.json'):locked(receipt)
    rows=[];conditions=[];scales=[]
    for m in MODES:
        for s in (2,4):
            tests,init,amount=release(m,s);rows+=tests;conditions+=init;scales.append(amount)
    table('direct-tests.csv',rows);table('switch-states.csv',conditions);table('signal-scales.csv',scales)
    compar=[]
    for part,key in [('reference','delta'),('delta','momentum'),('conditional','momentum'),('conditional','field_flux')]:
        for m,s,other,split in [('p16',4,'p32',4),('p16',2,'p16',4),('p32',2,'p32',4)]:
            with np.load(ROOT/f'{part}-{m}-{s}.npz') as lo,np.load(ROOT/f'{part}-{other}-{split}.npz') as hi:
                times=lo['times'];ix=np.searchsorted(hi['times'],times);assert np.array_equal(times,hi['times'][ix])
                ref=hi[key][ix];err=100*rms(times,lo[key]-ref)/rms(times,ref)
                compar.append(dict(test=part+'_'+key,first=m+'-'+str(s),second=other+'-'+str(split),relative_pct=err,passes=bool(err<=.5)))
    table('grid-comparison.csv',compar)
