import sys
from scipy.interpolate import CubicSpline,make_interp_spline
from current_stage import ROOT,KIN,FIRST,MODES,np,common,pinned,driver,wave_input,window,check,pack,table,freeze,locked
from infer_current import solve

def setup(mode,sub):
    with np.load(ROOT/f'launch-{mode}.npz') as arc:
        mass,kk,omega=(arc[k].item() for k in ('mass','kk','omega'))
        bgentry=arc['osc'];live=arc['live'];delta=arc['delta']
    with np.load(pinned(KIN,f'absolute-{mode}-{sub}.npz')) as raw,np.load(pinned(KIN,f'anchored-{mode}-{sub}.npz')) as corrected:
        times=raw['cuts'];g=raw['gravity']+corrected['metric_response'];dg=corrected['departure'];kinetic=raw['kinetic'];rho0=raw['rho0'].item()
    with np.load(pinned(FIRST,f'launch-{mode}-matched-{sub}.npz')) as saved,np.load(driver(f'curves-{mode}-companion.npz')) as prep:
        phi0=saved['launch'][12];diff0=phi0-(prep['phi'][0]-prep['kick'].item())
    with np.load(wave_input('matched-native/linear-heavy-00.npz')) as saved:
        keys=saved['keys'].tolist()
        bg=CubicSpline(saved['eta'],saved['values'][0][:,[keys.index('a'),keys.index('adotoa')]],extrapolate=False)
    def met(values,start):
        curve=CubicSpline(times,values)
        integral=curve.antiderivative()
        return lambda t: (start+(integral(t)[0]-integral(times[0])[0])/3,curve(t)[1]/kk)
    def ode(t,y,norm):
        a,h=bg(t)
        return np.array([y[1],-2*h*y[1]-(mass*a)**2*y[0]])
    osc=solve(ode,(times[0],times[-1]),bgentry,.0015)
    repeat=max(abs(osc(times)[1]**2*bg(times)[:,0]/rho0-1-kinetic))/max(abs(kinetic))
    assert repeat<.005,repeat
    return times,bg,osc,mass,kk,omega,met(g,phi0),met(dg,diff0),live,delta,repeat

def evolve(times,bg,osc,mass,kk,omega,geometry,initial,q,step,with_initial=True):
    center=geometry(times[len(times)//2]);amplitude=max(abs(osc(times[0])[0]),abs(osc(times[0])[1]/omega))
    unit=max(np.max(abs(initial)),np.max(abs(center))*amplitude,1e-60)
    def rhs(t,vec,norm):
        a,h=bg(t);om=(a*mass)**2;field,vel=osc(t);phi,psi=geometry(t);hq,mq=q(t)
        return np.array([omega*vec[1]+(vel*(psi+3*phi)+hq)/(unit*norm),
                         -2*h*vec[1]-(kk+om)/omega*vec[0]+(om*field*(3*phi-psi)+mq)/(omega*unit*norm)])
    from scipy.integrate import solve_ivp
    result=solve_ivp(lambda t,y:rhs(t,y,1.),(times[0],times[-1]),initial/unit if with_initial else np.zeros(2,complex),
                     method='DOP853',rtol=2e-12,atol=2e-15,max_step=step,t_eval=times)
    assert result.success and np.isfinite(result.y).all()
    return result.y.T*unit

def evaluate(mode,sub,absolute):
    times,bg,osc,mass,kk,omega,live_metric,diff_metric,live,delta,repeat=setup(mode,sub)
    zero=lambda t:(0j,0j)
    vel=osc(times)[1]
    if not absolute:
        total=evolve(times,bg,osc,mass,kk,omega,diff_metric,delta,zero,.0015)
        refined=evolve(times,bg,osc,mass,kk,omega,diff_metric,delta,zero,.00075)
        forced=evolve(times,bg,osc,mass,kk,omega,diff_metric,delta,zero,.0015,False)
        launch=evolve(times,bg,osc,mass,kk,omega,zero,delta,zero,.0015)
        error=np.linalg.norm(refined-total)/np.linalg.norm(total)
        addition=np.linalg.norm(total-forced-launch)/np.linalg.norm(total)
        assert max(error,addition)<.005
        pack(f'delta-{mode}-{sub}.npz',times=times,states=total,momentum=kk*vel*total[:,0],from_geometry=kk*vel*forced[:,0],
             from_entry=kk*vel*launch[:,0],oscillator_error=repeat,refinement=error,addition=addition)
    else:
        with np.load(wave_input('material-halfstep/forcing-heavy.npz')) as bank:
            keys=bank['keys'].tolist();axis=bank['eta']
            curves=make_interp_spline(np.log(axis),bank['values'][[keys.index(k) for k in ('hfield','hmoment','hJ')]][:,:,0].T,k=5)
        state=evolve(times,bg,osc,mass,kk,omega,live_metric,live,lambda t:curves(np.log(t))[:2],.0015)
        refined=evolve(times,bg,osc,mass,kk,omega,live_metric,live,lambda t:curves(np.log(t))[:2],.00075)
        error=np.linalg.norm(state-refined)/np.linalg.norm(state)
        assert error<.005
        field_flux=kk*vel*state[:,0];given=curves(np.log(times))[:,2]
        pack(f'conditional-{mode}-{sub}.npz',times=times,states=state,field_flux=field_flux,momentum=field_flux+given,supplied=given,refinement=error)

if __name__=='__main__':
    check();locked('launch-freeze.json')
    action=sys.argv[1];assert action in ('delta','conditional')
    if action=='conditional':locked('delta-freeze.json')
    for m in MODES:
        for s in (2,4):evaluate(m,s,action=='conditional')
    freeze(action+'-freeze.json',['launch-freeze.json' if action=='delta' else 'delta-freeze.json']+[f'{action}-{m}-{s}.npz' for m in MODES for s in (2,4)])
