import json
import hashlib
import sys
from pathlib import Path

ROOT=Path(__file__).resolve().parent
KIN=ROOT.parent/'mts-switch-kinetic-metric-work-89p6-20261125'
SEAL='4ef08b61062eb9deeb88ed0c52be6e56ed328080a64596c7cfd25caad3049b49'
def sha(path):
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
assert sha(KIN/'seal.json')==SEAL
assert sha(KIN/'kinetic_stage.py')==json.loads((KIN/'seal.json').read_bytes())['files']['kinetic_stage.py']
sys.path.insert(0,str(KIN))
from kinetic_stage import window,common,FIRST,np,MODES,locked,freeze,pack,pinned,table
common.PINS={**common.PINS,KIN:SEAL}
window.ROOT=common.ROOT=ROOT
WAVE=ROOT.parent/'mts-photon-matter-89p6-20261124'
def wave_input(name):
    assert sha(WAVE/'seal.json')=='bc32739cb1aa9f24909005b4cfde0d6c056a9508b178a4e0fe126a9ba218a159'
    path=WAVE/name
    assert sha(path)==json.loads((WAVE/'seal.json').read_bytes())['files'][name]
    return path
def driver(name):
    from cycle_stage import phase_file
    return phase_file(name)
def check():window.safe()
