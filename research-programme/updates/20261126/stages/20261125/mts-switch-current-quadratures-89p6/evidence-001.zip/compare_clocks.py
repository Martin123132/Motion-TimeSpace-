from scipy.interpolate import CubicSpline
from current_stage import ROOT,MODES,np,table,locked,check

def rms(times,values):
    return np.sqrt(np.average((abs(values[1:])**2+abs(values[:-1])**2)/2,weights=np.diff(times)))

def run():
    check();locked('conditional-freeze.json');rows=[]
    for part,key in [('reference','delta'),('delta','momentum'),('conditional','momentum'),('conditional','field_flux')]:
        for m,s,other,split in [('p16',4,'p32',4),('p16',2,'p16',4),('p32',2,'p32',4)]:
            with np.load(ROOT/f'{part}-{m}-{s}.npz') as lo,np.load(ROOT/f'{part}-{other}-{split}.npz') as hi:
                t,z=lo['times'],hi['times']
                assert t[0]==z[0] and t[-1]==z[-1]
                ix=np.searchsorted(z,t)
                dist=np.minimum(abs(z[ix]-t),abs(z[np.maximum(ix-1,0)]-t))
                shared=dist<5e-13
                assert shared.mean()>.995
                ref=CubicSpline(z,hi[key],extrapolate=False)(t)
                err=100*rms(t,lo[key]-ref)/rms(t,ref)
                alt=100*rms(t[shared],(lo[key]-ref)[shared])/rms(t[shared],ref[shared])
                linear=np.interp(t,z,hi[key])
                impact=100*rms(t,linear-ref)/rms(t,ref)
                assert impact<.5 and abs(alt-err)<.005*max(err,1.)
                rows.append(dict(test=part+'_'+key,first=m+'-'+str(s),second=other+'-'+str(split),relative_pct=err,passes=bool(err<=.5),
                                 shared_only_pct=alt,linear_vs_cubic_pct=impact,noncoincident=int(sum(~shared)),max_offset=max(dist)))
    table('grid-comparison.csv',rows)
if __name__=='__main__':run()
