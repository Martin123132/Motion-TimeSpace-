from scipy.interpolate import CubicSpline,make_interp_spline
from scipy.integrate import solve_ivp
from scipy.special import roots_legendre
from scipy.optimize import brentq
from current_stage import ROOT,KIN,FIRST,MODES,np,pinned,driver,wave_input,window,check,pack,table,freeze

def solve(fun,span,initial,maxstep):
    scale=max(np.max(abs(initial)),1e-100)
    result=solve_ivp(fun,span,initial/scale,method='DOP853',rtol=2e-12,atol=2e-15,dense_output=True,max_step=maxstep,
                     args=(scale,))
    assert result.success
    return lambda t:result.sol(t)*scale

def inputs(mode):
    with np.load(pinned(KIN,f'absolute-{mode}-4.npz')) as raw:
        start=raw['cuts'][0];mass,rho0,match=raw['controls'][:3];entry=raw['entry'];kk=float(raw['kk'])
    with np.load(wave_input('material-halfstep/forcing-heavy.npz')) as src:
        axis=src['eta'];sel=(axis>start-.25)&(axis<=start)
        keys=src['keys'].tolist();bgkeys=src['bgkeys'].tolist()
        held=make_interp_spline(np.log(axis[sel]),src['values'][[keys.index(k) for k in ('hfield','hmoment','henergy','hJ')]][:,sel,0].T,k=5)
        background=make_interp_spline(np.log(axis[sel]),src['background'][[bgkeys.index(k) for k in ('a','h')]][:,sel].T,k=5)
    with np.load(wave_input(f'particular-heavy-{mode}.npz')) as old:
        axis=old['eta'];sel=(axis>start-.21)&(axis<=start)
        metric=CubicSpline(axis[sel],np.column_stack([old[k][sel] for k in ('phi','psi')]))
    with np.load(wave_input('exact-phase-extension.npz')) as raw:
        loga=raw['heavy_efold'];end=np.log(match);sel=(loga<=end)&(loga>end-.006)
        phase=CubicSpline(loga[sel],raw['phase_h'][sel])
    def angle(t):
        return phase(np.log(background(np.log(t))[...,0]))
    top=angle(start)
    begin=brentq(lambda t:angle(t)-top+np.pi,start-.15,start,xtol=5e-14)
    assert start-.12<begin<start-.08
    with np.load(pinned(FIRST,f'launch-{mode}-matched-4.npz')) as saved:
        state=saved['launch']
        observed=np.array([state[10]+3*state[12],state[11]])
    with np.load(driver(f'companion-{mode}.npz')) as prep,np.load(window.previous(f'preparation-{mode}.npz')) as history:
        assert prep['eta'][0]==start and history['eta'][0]==start and history['density'][0,0]==0
        calibrated=np.array([prep['companion_e'][0,0],prep['companion_j'][0,0]+history['current'][0]])
    with np.load(driver(f'curves-{mode}-companion.npz')) as archived:
        live_phi=archived['pre_phi'][0]
    return start,begin,mass,rho0,kk,entry,background,metric,held,angle,observed,calibrated,live_phi

def infer(mode,order,step):
    start,begin,mass,rho0,kk,entry,bg,metric,held,angle,live,prep,lphi=inputs(mode)
    scale,hub=bg(np.log(start));omega=mass*scale;rho=rho0/scale
    field,vel=entry;amplitude=np.hypot(field,vel/omega)
    es=omega**2*amplitude/rho;js=kk*omega*amplitude/rho
    units=np.array([es,js])
    unit=max(abs(live/units))
    def homogeneous(t,y,norm):
        a,h=bg(np.log(t))
        return np.array([y[1],-2*h*y[1]-(a*mass)**2*y[0]])
    osc=solve(homogeneous,(start,begin),entry,step)
    def rhs(t,y,norm):
        trial=y.reshape(2,3);field,vel=osc(t)
        phi,psi=metric(t);a,hub=bg(np.log(t));fq,mq,*_=held(np.log(t));om=(a*mass)**2
        result=np.array([omega*trial[1],-2*hub*trial[1]-(kk+om)/omega*trial[0]])
        result[:,-1]+=np.array([vel*(psi+3*phi)+fq,(om*field*(3*phi-psi)+mq)/omega])/(unit*norm)
        return result.ravel()
    initial=np.array([[1,0,0],[0,1,0]],complex).ravel()
    back=solve(rhs,(start,begin),initial,step)
    roots,weights=roots_legendre(order)
    times=np.array([brentq(lambda t:angle(t)-angle(start)-(.5*r-.5)*np.pi,begin,start,xtol=5e-14) for r in roots])
    result=back(times).reshape(2,3,order)[0]
    vs=osc(times)[1];rs=rho0/bg(np.log(times))[:,0]
    jweights=weights*.5*kk*vs/rs
    row=(result[:2]@jweights).real/js
    energy=np.array([omega**2*field,vel*omega])/rho/es
    matrix=np.stack([energy,row])
    inst=np.stack([energy,[kk*vel/rho/js,0.]])
    singular=np.linalg.svd(matrix,compute_uv=False)
    assert singular[-1]>0
    other_j=np.sum(.5*weights*held(np.log(times))[:,3]/rs)+unit*(result[2]@jweights)
    anchorphi=metric(start)[0]
    additive=np.array([(held(np.log(start))[2]+3*vel**2*lphi)/rho,other_j])
    rhs_live=(live-additive)/units
    d_rhs=(live-prep-np.array([3*vel**2*(lphi-anchorphi)/rho,0j]))/units
    states=np.linalg.solve(matrix,np.column_stack([rhs_live,d_rhs]))
    prep_state=np.linalg.solve(matrix,(prep-additive+np.array([3*vel**2*(lphi-anchorphi)/rho,0j]))/units)
    consistency=max(abs(states[:,0]-prep_state-states[:,1]))/max(abs(states[:,0]))
    residue=max(abs(matrix@states[:,0]-rhs_live))/max(abs(rhs_live))
    assert max(consistency,residue)<2e-12
    assert np.linalg.matrix_rank([[-1.,0.],[0.,-.5]])==2 and np.linalg.matrix_rank([[-1.,0.],[0.,0.]])==1
    return dict(start=start,begin=begin,mass=mass,rho0=rho0,kk=kk,osc=entry,omega=omega,live=states[:,0],delta=states[:,1],prep=prep_state,
                matrix=matrix,instant=inst,singular=singular,live_data=live,prep_data=prep,units=units,affine=additive,
                sv_condition=singular[0]/singular[-1],instant_condition=np.linalg.cond(inst),seam_phi=lphi,ref_phi=anchorphi,residual=residue,add_check=consistency)

if __name__=='__main__':
    check();rows=[]
    for mode in MODES:
        full=infer(mode,96,.0015);control=infer(mode,48,.003)
        for key in ('matrix','live','delta'):
            val=full[key];err=np.linalg.norm(val-control[key])/np.linalg.norm(val)
            assert err<=.005
            rows.append(dict(mode=mode,check=key,refinement_pct=100*err,condition=full['sv_condition'],instant_condition=full['instant_condition']))
        pack(f'launch-{mode}.npz',**full)
    table('conditioning.csv',rows)
    freeze('launch-freeze.json',['PROTOCOL.md','current_stage.py','infer_current.py','predict_current.py','score_current.py','conditioning.csv']+[f'launch-{m}.npz' for m in MODES])
