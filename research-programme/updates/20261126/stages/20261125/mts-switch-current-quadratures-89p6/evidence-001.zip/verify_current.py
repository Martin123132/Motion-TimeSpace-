import ast
import csv
import sys
from scipy.special import roots_legendre
from current_stage import ROOT,KIN,np,common,MODES,pinned,locked,freeze

def rows(name):
    with (ROOT/name).open() as stream:return list(csv.DictReader(stream))
def verify():
    for name in ('launch-freeze.json','delta-freeze.json','conditional-freeze.json'):locked(name)
    pinned(KIN,'RESULTS.md')
    nodes,weights=roots_legendre(32);theta=(nodes-1)*np.pi/2
    velocity=np.sin(theta)
    flat=np.array([[-1,0],[(weights*velocity)@np.cos(theta)/2,(weights*velocity)@np.sin(theta)/2]])
    assert np.allclose(flat,[[-1,0],[0,.5]],atol=2e-14,rtol=0)
    for state in ([.8+.2j,-.7j],[-.9j,.3-.8j]):
        assert np.max(abs(np.linalg.solve(flat,flat@state)-state))<1e-12
    for mode in MODES:
        with np.load(ROOT/f'launch-{mode}.npz') as saved:
            assert 1<saved['sv_condition']<3 and saved['instant_condition']>1e6 and saved['residual']<1e-12
        for sub in (2,4):
            with np.load(ROOT/f'delta-{mode}-{sub}.npz') as pred,np.load(ROOT/f'conditional-{mode}-{sub}.npz') as total,np.load(ROOT/f'reference-{mode}-{sub}.npz') as ref:
                assert np.array_equal(pred['times'],ref['times']) and np.array_equal(total['times'],ref['times'])
                assert np.isfinite(ref['delta']).all() and np.isfinite(pred['momentum']).all()
                assert np.array_equal(total['momentum'],total['field_flux']+total['supplied'])
                assert max(pred['refinement'],pred['addition'],total['refinement'])<.005
    for name,size in [('direct-tests.csv',84),('switch-states.csv',16),('grid-comparison.csv',12)]:
        records=rows(name);assert len(records)==size
        for row in records:
            err=float(row['relative_pct']);assert np.isfinite(err) and err>=0 and (err<=.5)==(row['passes']=='True')
    for r in rows('signal-scales.csv'):assert float(r['replay_pct'])<.5
    assert len(rows('fixed-history-current-readout.csv'))==2
    for path in ROOT.glob('*.py'):ast.parse(path.read_text())
    assert not list(ROOT.rglob('__pycache__'))
    if '--seal' in sys.argv:
        assert (ROOT/'RESULTS.md').is_file()
        freeze('seal.json',sorted(p.name for p in ROOT.iterdir() if p.is_file() and p.name!='seal.json'))
        locked('seal.json');print(common.sha(ROOT/'seal.json'))
if __name__=='__main__':verify()
