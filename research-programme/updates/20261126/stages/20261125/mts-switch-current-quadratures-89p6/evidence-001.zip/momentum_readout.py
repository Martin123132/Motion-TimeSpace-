from scipy.interpolate import CubicSpline
from current_stage import ROOT,KIN,FIRST,MODES,np,pinned,locked,check,table
pinned(KIN,'dynamics.py')
from dynamics import make,propagate,geom
from compare_clocks import rms

def diagnostic(mode):
    split=4
    with np.load(ROOT/f'conditional-{mode}-{split}.npz') as pred,np.load(ROOT/f'reference-{mode}-{split}.npz') as saved:
        times=pred['times'];forecast=pred['momentum'];reference=saved['total']
    with np.load(pinned(KIN,f'absolute-{mode}-{split}.npz')) as kin,np.load(pinned(KIN,f'anchored-{mode}-{split}.npz')) as anch:
        assert np.array_equal(times,kin['cuts']);factor=kin['kinetic'];curve=CubicSpline(times,factor)
        external=CubicSpline(times,anch['raw_difference']);prepared=anch['prepared'][:,0];gravity=anch['departure'][:,0]
        rho0=kin['rho0'].item()
    src,solver,_,entry,_=make(mode,'matched',split)
    control=propagate(src,solver,times,entry)
    response=propagate(src,solver,times,np.zeros_like(entry),lambda t:(curve(t),curve(t)[:,None]*external(t)))
    avg=src.environment(times)[-2]*(control[:,11]+response[:,11])
    target=reference-avg
    estimate=forecast-avg
    assert np.all(np.isfinite(target))
    native,exact,_,entry,_=make(mode,'wave',split)
    with np.load(pinned(FIRST,f'work-{mode}-wave-{split}.npz')) as sealed:
        merged=np.unique(np.r_[times,sealed['edges']])
    live=propagate(native,exact,merged,entry)[np.searchsorted(merged,times)]
    bg,forcing=native.environment(times)[:2]
    assert np.array_equal(reference,native.kk*bg['hv']*live[:,10]+forcing['hJ'])
    true_factor=bg['hv']**2*bg['a']/rho0-1
    reference_geo=geom(native,exact,times,live,native=True)[:,0]
    prior_gross=factor*(gravity+prepared)
    trial_gross=prior_gross+1.5*factor*estimate/src.kk
    truth_gross=true_factor*reference_geo
    prior_delta=factor*gravity;trial_delta=prior_delta+1.5*factor*estimate/src.kk;truth_delta=true_factor*(reference_geo-prepared)
    def err(pred,true):return 100*rms(times,pred-true)/rms(times,true)
    return dict(mode=mode,missing_current_pct_of_total=100*rms(times,target)/rms(times,reference),signed_current_reconstruction_error_pct=err(estimate,target),
                kinetic_energy_work_before_pct=err(prior_gross,truth_gross),readout_only_energy_work_after_pct=err(trial_gross,truth_gross),
                prepared_delta_energy_work_before_pct=err(prior_delta,truth_delta),prepared_delta_energy_work_after_pct=err(trial_delta,truth_delta),
                readout_increment_error_pct_of_gross=100*rms(times,trial_delta-truth_delta)/rms(times,truth_gross))
if __name__=='__main__':
    check();locked('conditional-freeze.json')
    table('fixed-history-current-readout.csv',[diagnostic(m) for m in MODES])
