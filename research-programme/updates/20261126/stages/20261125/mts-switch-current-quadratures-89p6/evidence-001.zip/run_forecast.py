import sys
import predict_current as model
from current_stage import ROOT,np,MODES,check,locked,freeze

original=model.evolve
def evolve(times,bg,osc,mass,kk,omega,geometry,initial,forcing,step,with_initial=True):
    return original(times,bg,osc,mass,kk,omega,lambda t:np.asarray(geometry(t)),initial,forcing,step,with_initial)

if __name__=='__main__':
    check();locked('launch-freeze.json');model.evolve=evolve
    action=sys.argv[1];assert action in ('delta','conditional')
    parent='launch-freeze.json' if action=='delta' else 'delta-freeze.json'
    locked(parent)
    for mode in MODES:
        for sub in (2,4):model.evaluate(mode,sub,action=='conditional')
    freeze(action+'-freeze.json',[parent,'run_forecast.py']+[f'{action}-{m}-{s}.npz' for m in MODES for s in (2,4)])
