from pair_stage import ROOT,CASES,MODES,BRANCHES,tag,limits,locked,guard,table,ledger
from cycle3_inputs import make,np
from forecast_cycle3 import advance,colsum,add,index_grid
import csv
def gather():
    guard();locked('launch-freeze.json');locked('prediction-freeze.json')
    with ledger('raw-cycle-work.csv').open() as f:
        refs={(r['mode'],int(r['subdivision']),int(r['cycle'])):r for r in csv.DictReader(f) if int(r['cycle']) in (2,4)}
    assert len(refs)==8
    metrics=[];tests=[];details=[];cache={};outputs={}
    def test(m,b,n,c,kind,key,pred,ref):
        assert abs(ref)>0;err=100*abs(pred-ref)/abs(ref);assert np.isfinite(err)
        return dict(mode=m,branch=b,subdivision=n,cycle=c,test=kind,quantity=key,predicted_real=pred.real,predicted_imag=pred.imag,reference_real=ref.real,reference_imag=ref.imag,relative_pct=err,passes=bool(err<=.5))
    for case in CASES:
        m,b,n,c=case;src,solver,grid,_,_=make(m,b,n);left,right=limits(m,c);low,_,_,hi=index_grid(grid,left,right)
        row=refs[m,n,c];assert float(row['begin'])==left and float(row['end'])==right
        ref=complex(float(row[b+'_C_real']),float(row[b+'_C_imag']))
        with np.load(ROOT/f'launch-{tag(*case)}.npz') as f:initial=f['bracket_state']
        cut,_,_,prod,_=advance(src,solver,grid,low,hi,initial,b,low,extra=[left,right])
        a,z=np.searchsorted(cut,[left,right]);field=colsum(prod[a:z])
        with np.load(ROOT/f'prediction-{tag(*case)}.npz') as f:
            p=f['exact'];sample=f['cell_convention'];pr=f['primitive'];assert f['left']==left and f['right']==right
        result=dict(heavy=p[1],metric=p[2],pair=p[4],total=add([p[0],p[4],p[3]]),cell_total=add([sample[0],sample[4],sample[3]]),given_U=p[0],ordinary=p[3],half_energy=pr[1],weighted_current=pr[2])
        fieldref=dict(heavy=field[1],metric=field[2],pair=add(field[1:3]))
        primitive=dict(heavy=add(pr[1:3]),metric=pr[3],pair=add(pr[1:4]),total=add(pr))
        cache[case]=(result,fieldref,primitive,ref)
    for m in MODES:
        for n in (2,4):
            for c in (2,4):
                mat=cache[m,'matched',n,c];wave=cache[m,'wave',n,c]
                contrast=[{k:a[k]-b[k] for k in a} for a,b in zip(mat[:3],wave[:3])]
                cache[m,'matched-minus-wave',n,c]=(*contrast,mat[3]-wave[3])
    for case,(p,field,prim,ref) in cache.items():
        m,b,n,c=case
        for k in ('total','cell_total'):metrics.append(test(*case,'saved_endpoint',k,p[k],ref))
        for k in ('pair','heavy','metric'):metrics.append(test(*case,'field_basis_replay',k,p[k],field[k]))
        for k in ('pair','heavy','metric','total'):tests.append(test(*case,'energy_current_primitive',k,p[k],prim[k]))
        tests.append(test(*case,'combined_integral','pair',p['pair'],p['heavy']+p['metric']))
        for k in ('heavy','metric','pair','ordinary','given_U','half_energy','weighted_current'):
            v=p[k];details.append(dict(mode=m,branch=b,subdivision=n,cycle=c,quantity=k,real=v.real,imag=v.imag,signed_pct_of_total=100*(v*p['total'].conjugate()).real/abs(p['total'])**2))
        if n==4:
            for k in ('total','pair','heavy','metric'):
                tests.append(test(*case,'subdivision',k,cache[m,b,2,c][0][k],p[k]))
                if m=='p32':tests.append(test(*case,'gravity',k,cache['p16',b,n,c][0][k],p[k]))
    table('gates.csv',metrics);table('controls.csv',tests);table('contributions.csv',details)
    print('comparison failures',[(r['mode'],r['branch'],r['subdivision'],r['cycle'],r['test'],r['quantity'],r['relative_pct']) for r in metrics+tests if not r['passes']])
if __name__=='__main__':gather()
