from cycle3_inputs import np,forms,operator,DIM,QI,QN
from forecast_cycle3 import colsum
from pair_stage import guard
def terms(src,solver,t,side,x,dx,native):
    env=src.environment(t,side);bg,q,stress,coef,_,_,rho,den=env
    slopes=dict(zip(src.flow.bgkeys,(src.flow.bg(np.log(t),1)/t[:,None]).T))
    hub=bg['h'];dh=slopes['h'];kk=src.kk
    field,speed,phi=x[:,10:13].T;pd=dx[:,12];factor=1.5*hub/kk
    _,curr=solver.aggregate(env,x[:,:12]);transport=curr/(2*kk)+q['Fq']
    common=kk+(3*(bg['ec']+bg['eb']+bg['sv']**2)+4*(bg['eg']+bg['er'])+bg['nuE'])/2
    dcommon=(3*(slopes['ec']+slopes['eb']+2*bg['sv']*slopes['sv'])+4*(slopes['eg']+slopes['er'])+slopes['nuE'])/2
    if native:
        a=bg['a'];mass=bg['hm'];vel=bg['hv'];back=bg['hb'];mu=(a*mass)**2
        dmu=2*(a*mass)*(slopes['a']*mass+a*slopes['hm']);pot=mu*back
        defect=slopes['hv']+2*hub*vel+pot;slip=slopes['hb']-vel
        energy=vel*speed+pot*field+3*vel**2*phi+q['henergy'];current=kk*vel*field+q['hJ']
        force=q['henergy']/2+factor*q['hJ']
        heavy_rate=((defect-hub*vel)*speed/2+
            ((dmu*back+mu*slip-kk*vel)/2+1.5*(hub*(defect-2*hub*vel-pot)+dh*vel))*field+
            (3*vel*defect-1.5*hub*vel**2)*phi+1.5*vel**2*transport+
            vel*q['hmoment']/2+(pot/2+1.5*hub*vel)*q['hfield'])
        share=1.5*vel**2
    else:
        e=field+3*phi;j=speed;drho=-rho*slopes['a']/bg['a']
        energy=rho*e;current=rho*j;force=np.zeros_like(e)
        heavy_rate=(drho*e+rho*(-j+coef[2]))/2+1.5*rho*transport+1.5*((drho*hub+rho*dh-rho*hub**2)*j+rho*hub*coef[3])/kk
        share=1.5*rho
    assert np.allclose(common,den-share,rtol=2e-14,atol=0)
    metric_rate=common*pd+dcommon*phi
    weights,ext,_=forms(env,kk,src.wave,native)
    ordinary=np.einsum('nt,nt->n',weights[:,2],x[:,:13])+ext[:,2]
    return np.column_stack((heavy_rate,metric_rate,heavy_rate+metric_rate)),np.column_stack((q['U'],force,energy/2,factor*current,common*phi,ordinary))
def integrate(src,solver,grid,lo,hi,state,native,extra=()):
    corners=np.asarray(src.corners);cuts=np.unique(np.r_[lo,hi,grid[(grid>lo)&(grid<hi)],corners[(corners>lo)&(corners<hi)],extra])
    assert cuts[0]==lo and cuts[-1]==hi
    history=[state.copy()];work=[];primitive=[]
    for begin in range(0,len(cuts)-1,48):
        guard();end=min(begin+48,len(cuts)-1)
        left=cuts[begin:end];right=cuts[begin+1:end+1];mid=(left+right)/2;dt=right-left;mats=[]
        for t in (left,mid,right):
            matrix,bi,bn=operator(solver,t,mid);matrix[:,:13,QI]+=bi;matrix[:,:13,QN]+=bn;mats.append(matrix)
        xs=[[],[],[],[]];ds=[[],[],[],[]];final=[]
        for row,width in enumerate(dt):
            def rhs(i,x):return mats[i][row,:,:DIM]@x+mats[i][row,:,-1]
            xa=state;ka=rhs(0,xa);xb=xa+width*ka/2;kb=rhs(1,xb);xc=xa+width*kb/2;kc=rhs(1,xc);xd=xa+width*kc;kd=rhs(2,xd)
            state=xa+(width/6)*(ka+2*kb+2*kc+kd);history.append(state.copy());final.append(state)
            for idx,(xx,dd) in enumerate(zip((xa,xb,xc,xd),(ka,kb,kc,kd))):xs[idx].append(xx);ds[idx].append(dd)
        rates=[];obs=[]
        for idx,tt in enumerate((left,mid,mid,right)):
            v,p=terms(src,solver,tt,mid,np.asarray(xs[idx]),np.asarray(ds[idx]),native)
            rates.append(v);obs.append(p)
        _,last=terms(src,solver,right,mid,np.array(final),np.asarray(ds[-1]),native)
        change=last-obs[0]
        budgets=(dt[:,None]/6)*(rates[0]+2*rates[1]+2*rates[2]+rates[3]);budgets[:,0]+=change[:,1];budgets[:,2]+=change[:,1]
        work.extend(np.column_stack((change[:,0],-budgets[:,0],-budgets[:,1],-change[:,5],-budgets[:,2])))
        primitive.extend(np.column_stack((change[:,0],-change[:,2],-change[:,3],-change[:,4],-change[:,5])))
    return cuts,np.asarray(history),np.array(work).reshape(-1,5),np.array(primitive).reshape(-1,5)
