import sys
from pair_stage import ROOT,CASES,limits,tag,freeze,locked,guard
from cycle3_inputs import make,io,np
from forecast_cycle3 import advance,index_grid,colsum
from energy_current import integrate
io.ROOT=ROOT
def prepare(case):
    m,b,n,c=case;src,solver,grid,initial,_=make(m,b,n);left,right=limits(m,c)
    low,*_=index_grid(grid,left,right)
    _,states,*_=advance(src,solver,grid,grid[0],low,initial,b,low)
    edge=states[-1].copy();_,state,lead,_=integrate(src,solver,grid,low,left,edge,b=='wave')
    io.pack('launch-'+tag(*case)+'.npz',left=left,right=right,low=low,left_state=state[-1],bracket_state=edge,lead=colsum(lead) if len(lead) else np.zeros(5,complex))
def forecast(case):
    m,b,n,c=case;src,solver,grid,_,_=make(m,b,n);left,right=limits(m,c);low,lowend,hibegin,hi=index_grid(grid,left,right)
    with np.load(ROOT/('launch-'+tag(*case)+'.npz')) as f:
        assert f['left']==left and f['right']==right and f['low']==low
        launch=f['left_state'];lead=f['lead']
    cuts,states,work,primitive=integrate(src,solver,grid,left,hi,launch,b=='wave',[right]);pos=np.searchsorted(cuts,right)
    exact=colsum(work[:pos]);prim=colsum(primitive[:pos]);assert np.isfinite(exact).all() and np.isfinite(prim).all()
    lfrac=(lowend-left)/(lowend-low);rfrac=(right-hibegin)/(hi-hibegin);frac=np.ones(len(work));frac[cuts[:-1]<lowend]=lfrac;frac[cuts[:-1]>=hibegin]=rfrac
    archived=colsum(work*frac[:,None])+lead*lfrac
    io.pack('prediction-'+tag(*case)+'.npz',left=left,right=right,left_state=launch,right_state=states[pos],terms=['given_U','heavy','metric','ordinary','pair'],exact=exact,cell_convention=archived,primitive_terms=['given_U','half_energy','weighted_current','metric','ordinary'],primitive=prim)
if __name__=='__main__':
    guard()
    if sys.argv[1]=='prepare':
        for case in CASES:prepare(case)
        freeze('launch-freeze.json',['pair_stage.py','PROTOCOL.md','DERIVATION.md','energy_current.py','paired_predict.py','paired_score.py']+['launch-'+tag(*case)+'.npz' for case in CASES])
    elif sys.argv[1]=='predict':
        locked('launch-freeze.json')
        for case in CASES:forecast(case)
        freeze('prediction-freeze.json',['launch-freeze.json']+['prediction-'+tag(*case)+'.npz' for case in CASES])
    else:raise ValueError('unknown phase')
