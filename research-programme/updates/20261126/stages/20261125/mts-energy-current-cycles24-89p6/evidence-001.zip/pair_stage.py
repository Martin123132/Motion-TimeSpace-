from pathlib import Path
import csv,hashlib,json,sys
ROOT=Path(__file__).resolve().parent
PRE=ROOT.parent/'mts-cycle3-work-forecast-89p6-20261125'
PARENT='91e4719fb78d5e8cbd7b4fd38b5ad6cf5ca97d550750ae22be07dfa0050685f7'
def sha(path):
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
assert sha(PRE/'seal.json')==PARENT
def code(name):
    assert name in ('third_stage.py','cycle3_inputs.py','forecast_cycle3.py')
    assert sha(PRE/name)==json.loads((PRE/'seal.json').read_bytes())['files'][name]
for name in ('third_stage.py','cycle3_inputs.py','forecast_cycle3.py'):code(name)
sys.path.insert(0,str(PRE))
from third_stage import phase_file,MODES,BRANCHES,ledger
CASES=[(m,b,n,c) for m in MODES for b in BRANCHES for n in (2,4) for c in (2,4)]
def tag(m,b,n,c):return f'{m}-{b}-{n}-cycle{c}'
def guard():assert not any((p/'STOP-REQUESTED').exists() for p in (ROOT,PRE,ROOT.parent))
def freeze(name,files):
    guard();p=ROOT/name;v=dict(prior=PARENT,files={f:sha(ROOT/f) for f in files})
    if p.exists():assert json.loads(p.read_bytes())==v
    else:p.write_text(json.dumps(v,sort_keys=True,indent=2)+'\n')
def locked(name):
    v=json.loads((ROOT/name).read_bytes());assert v['prior']==PARENT
    for f,h in v['files'].items():assert sha(ROOT/f)==h
def limits(mode,cycle):
    with phase_file(f'cycles-{mode}.csv').open() as stream:
        bounds=[(float(r['begin']),float(r['finish'])) for r in csv.DictReader(stream) if int(r['cycle'])==cycle-1]
    assert len(bounds)==2 and bounds[0]==bounds[1]
    return bounds[0]
def table(name,rows):
    import io
    s=io.StringIO();writer=csv.DictWriter(s,rows[0],lineterminator='\n');writer.writeheader();writer.writerows(rows)
    p=ROOT/name;data=s.getvalue().encode()
    if p.exists():assert p.read_bytes()==data
    else:p.write_bytes(data)
