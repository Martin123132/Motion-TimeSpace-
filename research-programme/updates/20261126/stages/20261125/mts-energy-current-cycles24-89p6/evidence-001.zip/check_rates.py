from pair_stage import ROOT,MODES,BRANCHES,tag,locked,table
from cycle3_inputs import make,operator,QI,QN,DIM,np
from energy_current import terms
def run():
    locked('prediction-freeze.json');rows=[]
    for m in MODES:
        for branch in BRANCHES:
            src,solver,_,_,_=make(m,branch,4);native=branch=='wave'
            for cycle in (2,4):
                with np.load(ROOT/f'prediction-{tag(m,branch,4,cycle)}.npz') as f:
                    left=f['left'];right=f['right'];initial=f['left_state']
                t=np.linspace(left+(right-left)/100,right-(right-left)/100,11)
                matrices,bi,bn=operator(solver,t,t);matrices[:,:13,QI]+=bi;matrices[:,:13,QN]+=bn
                env=src.environment(t,t);bg,q,_,coef,_,_,rho,den=env
                ds=dict(zip(src.flow.bgkeys,(src.flow.bg(np.log(t),1)/t[:,None]).T));kk=src.kk;h=bg['h'];hp=ds['h']
                for altered in (False,True):
                    x=np.tile(initial,(len(t),1));wave=np.linspace(0,1,len(t))
                    if altered:
                        for key in (10,11,12,QI,QN):
                            x[:,key]+=max(abs(initial[key]),1e-20)*(.34*np.cos(3*wave+key)+.22j*np.sin(6*wave-key))
                    dx=np.einsum('nij,nj->ni',matrices[:,:,:DIM],x)+matrices[:,:,-1]
                    rates,_=terms(src,solver,t,t,x,dx,native)
                    phi=x[:,12];pd=dx[:,12];f=x[:,10];w=x[:,11];fd=dx[:,10];wd=dx[:,11]
                    if native:
                        v=bg['hv'];vp=ds['hv'];mass=bg['hm'];a=bg['a'];b=bg['hb'];mu=(a*mass)**2;pot=mu*b
                        potp=2*a*mass*(ds['a']*mass+a*ds['hm'])*b+mu*ds['hb']
                        ep=vp*w+v*wd+potp*f+pot*fd+6*v*vp*phi+3*v*v*pd
                        j=kk*v*f;jp=kk*(vp*f+v*fd);dhh=3*v*vp
                    else:
                        rp=-rho*ds['a']/bg['a'];ep=rp*(f+3*phi)+rho*(fd+3*pd)
                        j=rho*w;jp=rp*w+rho*wd;dhh=1.5*rp
                    href=ep/2+1.5*(hp*j+h*jp)/kk
                    dhs=3*(ds['ec']+ds['eb']+2*bg['sv']*ds['sv'])/2+2*(ds['eg']+ds['er'])+ds['nuE']/2+dhh
                    mref=(den-(1.5*bg['hv']**2 if native else 1.5*rho))*pd+(dhs-dhh)*phi
                    for key,vec,ref in [('heavy',rates[:,0],href),('metric',rates[:,1],mref),('pair',rates[:,2],href+mref)]:
                        error=100*np.max(abs(vec-ref))/np.max(abs(ref))
                        rows.append(dict(mode=m,branch=branch,cycle=cycle,probe='perturbed' if altered else 'left_state',term=key,relative_pct=error,passes=bool(error<=.5)))
    table('rate-identities.csv',rows)
    print(len(rows),'rate identities; max percent',max(r['relative_pct'] for r in rows))
if __name__=='__main__':run()
