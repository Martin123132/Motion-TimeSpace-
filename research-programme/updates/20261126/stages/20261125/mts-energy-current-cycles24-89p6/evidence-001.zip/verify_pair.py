import ast,csv,json
import numpy as np
from pair_stage import ROOT,CASES,MODES,tag,locked,freeze,guard,sha,table
def rows(name):
    with (ROOT/name).open() as stream:return list(csv.DictReader(stream))
def main():
    guard();locked('launch-freeze.json');locked('prediction-freeze.json')
    gates=rows('gates.csv');checks=rows('controls.csv');ident=rows('rate-identities.csv');terms=rows('contributions.csv')
    assert (len(gates),len(checks),len(ident),len(terms))==(120,192,48,168)
    for r in gates+checks:
        p=complex(float(r['predicted_real']),float(r['predicted_imag']));ref=complex(float(r['reference_real']),float(r['reference_imag']))
        err=100*abs(p-ref)/abs(ref);assert abs(float(r['relative_pct'])-err)<1e-9 and (err<=.5)==(r['passes']=='True')
    for r in ident:assert (float(r['relative_pct'])<=.5)==(r['passes']=='True')
    for case in CASES:
        with np.load(ROOT/f'launch-{tag(*case)}.npz') as base,np.load(ROOT/f'prediction-{tag(*case)}.npz') as out:
            assert np.array_equal(base['left_state'],out['left_state']) and base['left']==out['left'] and base['right']==out['right']
            assert out['right_state'].shape==(90,) and np.isfinite(out['right_state']).all()
    budget=[]
    for r in gates:
        if r['test']!='saved_endpoint' or r['quantity']!='total' or r['branch']!='matched-minus-wave':continue
        ref=complex(float(r['reference_real']),float(r['reference_imag']))
        chosen={v['quantity']:complex(float(v['real']),float(v['imag'])) for v in terms if all(v[k]==r[k] for k in ('branch','cycle','mode','subdivision'))}
        for sources in [('pair',),('pair','ordinary'),('pair','given_U'),('pair','ordinary','given_U')]:
            pred=sum(chosen[k] for k in sources);err=100*abs(pred-ref)/abs(ref)
            budget.append(dict(mode=r['mode'],subdivision=r['subdivision'],cycle=r['cycle'],included='+'.join(sources),relative_pct=err,passes=bool(err<=.5)))
    table('pair-only-diagnostic.csv',budget)
    for p in ROOT.glob('*.py'):ast.parse(p.read_text())
    assert not list(ROOT.rglob('__pycache__'))
    if (ROOT/'RESULTS.md').is_file():
        freeze('seal.json',sorted(p.name for p in ROOT.iterdir() if p.is_file() and p.name!='seal.json'))
        print(sha(ROOT/'seal.json'))
if __name__=='__main__':main()
