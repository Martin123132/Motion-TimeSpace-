from cycle_stage import ROOT,MODES,SETTINGS,previous,guard,locked
from angular_photons import io,gate,np
from cell89 import pin as legacy
from scipy.interpolate import CubicSpline
import csv
def run():
    guard();locked('source-freeze.json');locked('photon-freeze.json');io.ROOT=ROOT
    _,axis,w,_=gate.proj.old.get_media();measure=gate.previous.make_measure(axis,w);mag=lambda vec:gate.mag(vec,measure)
    with gate.pin(gate.FROZEN,'window-readouts.csv').open() as fp:
        launch={r['gravity']:float(r['launch_norm']) for r in csv.DictReader(fp) if r['model']=='MTS-minus-baseline' and r['output']=='joint'}
    with previous('gates.csv').open() as fp:prior={(r['mode'],r['setting']):r for r in csv.DictReader(fp)}
    scores=[];checks=[];gates=[];cache={}
    def check(mode,setting,test,label,value,expected):
        rel=100*mag(value-expected)/mag(expected);assert np.isfinite(rel).all()
        checks.append(dict(mode=mode,setting=setting,test=test,component=label,energy=rel[0],current=rel[1],joint=rel[2],passes=bool(max(rel)<=.5)))
    for setting in SETTINGS:
        name=f'photons-{setting}.npz'
        with np.load(ROOT/name) as calc,np.load(previous(name)) as change,np.load(previous('control/'+name)) as ctl,np.load(legacy(f'photon-{setting}.npz')) as origin,np.load(previous(f'launch-change-{setting}.npz')) as metric:
            grid=calc['scale'];assert all(np.array_equal(grid,f['scale']) for f in (change,ctl,metric)) and np.array_equal(grid,origin['grid'])
            project=lambda x:CubicSpline(grid,x)(axis)
            for idx,m in enumerate(MODES):
                def unpack(f):
                    assert f['modes'].tolist()==list(MODES)
                    return dict(zip(f['channels'].tolist(),project(f['values'][:,idx,0]).swapaxes(0,1)))
                val=unpack(calc);hist=unpack(change);old=unpack(ctl);mom=project(origin['values'][:,origin['labels'].tolist().index([m,'primary']),:3].sum(1));norm=mag(mom)
                physical=mom+project(metric['values'][:,metric['labels'].tolist().index([m,'primary'])].sum(1))
                ref=prior[m,setting];absolute=100*mag(physical+val['full'])[2]/launch[m];sm=100*mag(physical)[2]/launch[m];frac=100*mag(val['full'])/norm
                assert abs(absolute/float(ref['differentiated_launch_pct'])-1)<.005 and abs(sm/float(ref['momentum_launch_pct'])-1)<.005
                gates.append(dict(mode=m,setting=setting,energy=frac[0],current=frac[1],joint=frac[2],passes=bool(max(frac)<=.5),momentum_launch_pct=sm,differentiated_launch_pct=absolute,launch_pass=bool(max(sm,absolute)<.163)))
                for k,baseline in [('full',old['control']+hist['total']),('first',old['early']+hist['early']),('late',old['late']+hist['late'])]:
                    check(m,setting,'archive_replay',k,val[k],baseline)
                cycles=[k[:-6] for k in val if k.startswith('cycle') and k.endswith('_total')]
                for dest,parts in [('full',['first','late']),('late',['complete','partial']),('complete',['drift','osc']),('complete',['phase_drift','phase_osc']),('osc',['osc_den_mean','osc_kernel'])]+[(k,[c+'_'+('total' if k=='complete' else k) for c in cycles]) for k in ('complete','drift','osc')]+[(c+'_total',[c+'_drift',c+'_osc']) for c in cycles]:
                    check(m,setting,'signed_sum',dest,sum(val[k] for k in parts),val[dest])
                for k in [key for key in val if not key.startswith('half_')]:
                    vec=val[k];amp=100*mag(vec)/norm
                    def share(ref):return 100*(measure@(vec*ref.conj()).real).sum()/mag(ref)[2]**2
                    scores.append(dict(mode=m,setting=setting,component=k,energy_common_pct=amp[0],current_common_pct=amp[1],joint_common_pct=amp[2],signed_pct_of_full=share(val['full']),signed_pct_of_late=share(val['late']),signed_pct_of_complete=share(val['complete'])))
                    cache[m,setting,k]=vec;check(m,setting,'source_subdivision',k,val['half_'+k],vec)
                for a,b in [('phase_drift','drift'),('phase_osc','osc')]:check(m,setting,'drift_convention',b,val[a],val[b])
    for (m,s,k),v in cache.items():
        if s=='primary':
            for mo,st,tag in [(m,'time','photon_time'),(m,'angle','photon_angle')]+([('p16','primary','gravity')] if m=='p32' else []):check(m,s,tag,k,cache[mo,st,k],v)
    for name,rows in [('components',scores),('precision',checks),('gates',gates)]:io.table(name+'.csv',rows)
    print('checks',len(checks),'failed',[(r['test'],r['component']) for r in checks if not r['passes']])
if __name__=='__main__':run()
