from cycle_stage import ROOT,MODES,SETTINGS,angular,guard,freeze,locked
from types import SimpleNamespace
from unittest.mock import patch
angular('angular_photons.py')
from angular_photons import transport,io,np
def packet(mode,unused):
    with np.load(ROOT/f'sources-{mode}-4.npz') as fine,np.load(ROOT/f'sources-{mode}-2.npz') as half:
        knots=fine['knots'];old=half['knots'];idx=np.searchsorted(old,knots[:-1],side='right')-1
        assert knots[0]==old[0] and knots[-1]==old[-1] and np.all(knots[1:]<=old[idx+1])
        keys=fine['keys'].tolist();assert keys==half['keys'].tolist() and np.array_equal(fine['edges'],half['edges'])
        return SimpleNamespace(time=fine['gravity'],knots=knots,values=np.column_stack((fine['rates'],half['rates'][idx])),keys=keys+['half_'+k for k in keys]),None
def run():
    guard();locked('source-freeze.json');io.ROOT=ROOT
    with patch.object(transport,'ROOT',ROOT),patch.object(transport,'source',packet):
        for setting in SETTINGS:transport.project(setting)
    freeze('photon-freeze.json',['source-freeze.json']+[f'photons-{s}.npz' for s in SETTINGS])
if __name__=='__main__':run()
