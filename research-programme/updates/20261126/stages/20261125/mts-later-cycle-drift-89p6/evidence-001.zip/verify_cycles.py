import csv,ast
import numpy as np
from cycle_stage import ROOT,MODES,SETTINGS,locked,freeze,guard,digest
def rows(name):
    with (ROOT/name).open() as stream:return list(csv.DictReader(stream))
def verify():
    guard();locked('source-freeze.json');locked('photon-freeze.json')
    work=rows('raw-cycle-work.csv');scores=rows('components.csv');tests=rows('precision.csv');gates=rows('gates.csv')
    for m in MODES:
        for sub in (2,4):
            data=[r for r in work if (r['mode'],int(r['subdivision']))==(m,sub)]
            assert [r['kind'] for r in data]==['first_control']+['complete_later']*3+['partial'] and 0<float(data[-1]['phase_cycles'])<1
            with np.load(ROOT/f'sources-{m}-{sub}.npz') as f:
                grid=f['knots'];edges=f['edges'];dt=np.diff(grid);keys=f['keys'].tolist();v=dict(zip(keys,f['rates'].T))
                assert np.array_equal(edges,np.r_[[float(r['begin']) for r in data],float(data[-1]['end'])])
                for index,row in enumerate(data):
                    use=(grid[:-1]>=edges[index])&(grid[1:]<=edges[index+1])
                    actual=(v['full'][use]*dt[use]).sum();expected=complex(float(row['source_integral_real']),float(row['source_integral_imag']))
                    assert abs(actual-expected)<=1e-10*sum(dt[use]*abs(v['full'][use]))
                    if row['kind']=='complete_later':
                        assert not v[f"cycle{index+1}_total"][~use].any()
                        assert float(row['raw_osc_zero_error'])<1e-10 and float(row['phase_osc_zero_error'])<1e-10
                        assert abs(sum(v['osc_kernel'][use]*dt[use]))<=1e-10*sum(abs(v['osc'][use])*dt[use])
                    else:assert not (v['drift'][use].any() or v['osc'][use].any())
                assert np.allclose(v['full'],v['first']+v['drift']+v['osc']+v['partial'],rtol=1e-11,atol=1e-13*np.max(abs(v['full'])))
        for s in SETTINGS:
            data={r['component']:r for r in scores if (r['mode'],r['setting'])==(m,s)}
            for cols,den in [(('drift','osc'),'complete'),(('drift','osc','partial'),'late'),(('first','drift','osc','partial'),'full')]:
                assert abs(sum(float(data[k]['signed_pct_of_'+den]) for k in cols)-100)<1e-7
    assert len(gates)==6
    for r in gates:
        assert (max(float(r[k]) for k in ('energy','current','joint'))<=.5)==(r['passes']=='True')
        assert (max(float(r[k]) for k in ('momentum_launch_pct','differentiated_launch_pct'))<.163)==(r['launch_pass']=='True')
    for r in tests:assert (max(float(r[k]) for k in ('energy','current','joint'))<=.5)==(r['passes']=='True')
    for s in SETTINGS:
        q=rows('quadrature-'+s+'.csv');assert len(q)==2 and all(float(r['relative'])<=.005 for r in q)
    for p in ROOT.glob('*.py'):ast.parse(p.read_text())
    assert not list(ROOT.rglob('__pycache__'))
    freeze('seal.json',sorted(p.name for p in ROOT.iterdir() if p.is_file() and p.name!='seal.json'))
    print('verified',len(tests),'fidelity tests;',sum(r['passes']=='False' for r in tests),'over tolerance; seal',digest(ROOT/'seal.json'))
if __name__=='__main__':verify()
