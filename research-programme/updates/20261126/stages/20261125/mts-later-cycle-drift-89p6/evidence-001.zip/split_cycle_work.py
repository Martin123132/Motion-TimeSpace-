import csv,math
from cycle_stage import ROOT,MODES,previous,phase_file,earlier,angular,freeze,guard
angular('release.py');phase_file('wave_kernel.py')
from release import Drivers,source,io,np
from inputs_density import kernel
io.ROOT=ROOT
def integral(rate,width):
    samples=rate*width
    return complex(math.fsum(samples.real),math.fsum(samples.imag))
def scale_error(obs,ref):
    return np.max(np.abs(obs-ref))/max(np.max(np.abs(ref)),1e-90)
def table_values(bank,field):return bank['values'][:,bank['channels'].tolist().index(field)]
def spread(grid,knots,impulses,den):
    idx=np.searchsorted(knots,grid[:-1],side='right')-1
    assert grid[0]==knots[0] and grid[-1]==knots[-1] and np.all(grid[1:]<=knots[idx+1])
    return (impulses/np.diff(knots))[idx],den[1:][idx]
def split_run(mode,sub,matched,wave,clock,edges):
    with np.load(previous(f'prediction-{mode}-{sub}.npz')) as prep,np.load(angular(f'angular-{mode}-{sub}.npz')) as ang,np.load(earlier(f'impulses-{mode}-{sub}.npz')) as kin:
        base=ang['grid'];pgrid=prep['grid'];gravity=ang['gravity'];assert np.array_equal(base,kin['grid']) and np.array_equal(gravity,prep['gravity'])
        assert edges[0]==base[0] and edges[1]==prep['edge'] and len(edges)>=3 and 0<(clock(base[-1])-clock(edges[-1]))/np.pi<1
        axis=np.unique(np.r_[pgrid,base,edges]);width=np.diff(axis)
        dm=matched.environment(base)[-1];dw=wave.environment(base)[-1];dp=matched.environment(pgrid)[-1]
        assert min(np.min(a) for a in (dm,dw,dp))>0
        rates,denoms=zip(spread(axis,base,table_values(ang,'matched')+table_values(kin,'matched'),dm),
            spread(axis,base,-(table_values(ang,'wave')+table_values(kin,'wave')),dw),
            spread(axis,pgrid,table_values(prep,'total'),dp))
        full=np.sum(rates,axis=0); raw=np.array(rates)*denoms
        independent=spread(axis,base,table_values(ang,'live')+table_values(kin,'effect'),dm)[0]+rates[2]
        assert scale_error(full,independent)<1e-10
    end=axis[-1];edges=np.r_[edges,end];flags=np.searchsorted(edges,axis[:-1],side='right')-1
    assert np.array_equal(np.unique(flags),np.arange(len(edges)-1))
    partial=len(edges)-2;late=flags>0;complete=late&(flags<partial)
    parts=dict(full=full,first=np.where(late,0j,full),late=np.where(late,full,0j),partial=np.where(flags==partial,full,0j),complete=np.where(complete,full,0j))
    for key in ('drift','osc','osc_den_mean','osc_kernel','phase_drift','phase_osc'):parts[key]=np.zeros_like(full)
    stats=[];phase=clock(axis);assert np.all(np.diff(phase)>0)
    for segment,(left,right) in enumerate(zip(edges[:-1],edges[1:])):
        mask=flags==segment;dt=width[mask];duration=right-left;span=clock(right)-clock(left)
        assert abs(sum(dt)-duration)<1e-12 and (segment==partial or abs(span-np.pi)<1e-9)
        nets=np.array([integral(rr[mask],dt) for rr in raw]);net_matched=nets[0]+nets[2];net_wave=-nets[1]
        row=dict(mode=mode,subdivision=sub,cycle=segment+1,kind='first_control' if segment==0 else 'partial' if segment==partial else 'complete_later',begin=left,end=right,phase_cycles=span/np.pi,matched_C_real=net_matched.real,matched_C_imag=net_matched.imag,wave_C_real=net_wave.real,wave_C_imag=net_wave.imag,source_integral_real=integral(full[mask],dt).real,source_integral_imag=integral(full[mask],dt).imag)
        if segment!=0 and segment!=partial:
            drift=nets[:,None]/duration
            phase_drift=nets[:,None]*(np.diff(phase)[mask]/dt)/span
            dens=np.array(denoms)[:,mask]
            raw_osc=raw[:,mask]-drift
            zero_error=max(abs(integral(rr,dt))/max(sum(abs(rr)*dt),1e-90) for rr in raw_osc)
            assert zero_error<1e-10
            gd=(drift/dens).sum(0);go=(raw_osc/dens).sum(0)
            gp=(phase_drift/dens).sum(0);gm=integral(go,dt)/duration
            kernel_only=go-gm
            assert abs(integral(kernel_only,dt))<1e-10*sum(abs(go)*dt)
            assert scale_error(gd+go,full[mask])<1e-10
            phase_zero=max(abs(integral(rr,dt))/max(sum(abs(rr)*dt),1e-90) for rr in raw[:,mask]-phase_drift)
            assert phase_zero<1e-10
            for key,quantity in [('drift',gd),('osc',go),('phase_drift',gp),('phase_osc',full[mask]-gp),('osc_den_mean',gm),('osc_kernel',kernel_only)]:parts[key][mask]=quantity
            for key,value in [('total',full[mask]),('drift',gd),('osc',go)]:
                arr=np.zeros_like(full);arr[mask]=value;parts[f'cycle{segment+1}_{key}']=arr
            row.update(raw_osc_zero_error=zero_error,phase_osc_zero_error=phase_zero)
        else:row.update(raw_osc_zero_error='',phase_osc_zero_error='')
        stats.append(row)
    vals=np.column_stack(list(parts.values()));assert np.isfinite(vals).all()
    io.pack(f'sources-{mode}-{sub}.npz',knots=axis,gravity=gravity,keys=list(parts),rates=vals,edges=edges)
    return stats
def run():
    guard();rows=[]
    for mode in MODES:
        with phase_file(f'cycles-{mode}.csv').open() as fp:
            saved=[r for r in csv.DictReader(fp) if int(r['cycle'])>=0]
        records=[r for r in saved if r['seed']=='0'];assert [(r['begin'],r['finish']) for r in records]==[(r['begin'],r['finish']) for r in saved if r['seed']=='1']
        assert [int(r['cycle']) for r in records]==list(range(len(records))) and all(a['finish']==b['begin'] for a,b in zip(records,records[1:]))
        edges=np.array([float(records[0]['begin'])]+[float(r['finish']) for r in records])
        matched=Drivers(mode);wave=source(mode);clock=kernel.read(mode)[0]
        for sub in (2,4):rows+=split_run(mode,sub,matched,wave,clock,edges)
    io.table('raw-cycle-work.csv',rows)
    freeze('source-freeze.json',['PROTOCOL.md','cycle_stage.py','split_cycle_work.py','photons_by_cycle.py','score_cycles.py','raw-cycle-work.csv']+[f'sources-{m}-{s}.npz' for m in MODES for s in (2,4)])
if __name__=='__main__':run()
