from pathlib import Path
import json,sys,hashlib
ROOT=Path(__file__).resolve().parent
PRE=ROOT.parent/'mts-prehistory-padding-89p6-20261125'
PRIOR='7021f505d0479ad1ad1b0f8e8d3fa89df281ab32ff967ec51b963427b03dad47'
WAVES=ROOT.parent/'mts-wave-transfer-89p15-20261124'
WAVEHASH='31f9925322c86a7d9876cd31469a79dbb0f8bc1ae17acf2410c4486f9fdec962'
def digest(path):
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
def pinned(folder,seal,name):
    assert digest(folder/'seal.json')==seal
    path=folder/name;assert digest(path)==json.loads((folder/'seal.json').read_bytes())['files'][name],name
    return path
def previous(name):return pinned(PRE,PRIOR,name)
def phase_file(name):return pinned(WAVES,WAVEHASH,name)
def guard():assert not any((p/'STOP-REQUESTED').exists() for p in (ROOT,ROOT.parent,PRE,WAVES))
def freeze(name,files):
    guard();dest=ROOT/name;receipt=dict(previous=PRIOR,phase_archive=WAVEHASH,files={f:digest(ROOT/f) for f in files})
    if dest.exists():assert json.loads(dest.read_bytes())==receipt,name
    else:dest.write_text(json.dumps(receipt,sort_keys=True,indent=2)+'\n')
def locked(name):
    receipt=json.loads((ROOT/name).read_bytes());assert receipt['previous']==PRIOR and receipt['phase_archive']==WAVEHASH
    for f,h in receipt['files'].items():assert digest(ROOT/f)==h,f
sys.path.insert(0,str(PRE));previous('history_stage.py')
from history_stage import earlier,angular,MODES,SETTINGS
