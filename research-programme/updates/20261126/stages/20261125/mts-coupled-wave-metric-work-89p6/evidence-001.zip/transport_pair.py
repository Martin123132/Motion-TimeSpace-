from paired_stage import ROOT,guard,prior,source_lock,photon_lock,SETTINGS,LABELS
from types import SimpleNamespace
from unittest.mock import patch
import sys
prior('photons_average.py')
from photons_average import transport,io,gate,np
def packet(mode,unused,target=False):
    prefix='reference' if target else 'forecast'
    with np.load(ROOT/f'{prefix}-{mode}-4.npz') as fine,np.load(ROOT/f'{prefix}-{mode}-2.npz') as half:
        grid=fine['grid'];assert np.array_equal(grid[::2],half['grid'])
        cols={}
        for i,label in enumerate(fine['labels'].tolist()):
            for j,name in enumerate(fine['fields'].tolist()):
                if i>0 and name not in ('pair','total'):continue
                cols[label+'_'+name]=fine['photon'][i,:,j]/np.diff(grid)
                if name in ('pair','total'):
                    cols['half_'+label+'_'+name]=np.repeat(half['photon'][i,:,j]/np.diff(half['grid']),2)
        return SimpleNamespace(time=fine['gravity'],knots=grid,values=np.column_stack(list(cols.values())),keys=list(cols)),None
def project(target):
    guard()
    if target:
        assert (ROOT/'photons-freeze.json').exists();photon_lock()
    else:
        assert (ROOT/'source-freeze.json').exists();source_lock()
    destination=ROOT/('reference' if target else 'forecast')
    destination.mkdir(exist_ok=True);io.ROOT=destination
    with patch.object(transport,'ROOT',destination),patch.object(transport,'source',lambda m,b:packet(m,b,target)):
        for setting in SETTINGS:
            transport.project(setting);print(destination.name,setting,flush=True)
    if not target:photon_lock()
if __name__=='__main__':project('--reference' in sys.argv[1:])
