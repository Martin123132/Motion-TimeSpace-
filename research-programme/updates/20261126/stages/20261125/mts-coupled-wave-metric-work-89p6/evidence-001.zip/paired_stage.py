import hashlib,json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent
PRE=ROOT.parent/'mts-wave-averaging-work-89p6-20261125'
SEAL='bb75c626feda8adac7e57eba2011974ae20482127054258aa795b9223264faf1'
MODES=('p16','p32')
LABELS=('filtered','saved_current','saved_density','saved_both')
SETTINGS=('primary','time','angle')
def digest(path):
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
assert digest(PRE/'seal.json')==SEAL
prior_files=json.loads((PRE/'seal.json').read_bytes())['files']
def prior(name):
    path=PRE/name;assert digest(path)==prior_files[name],name
    return path
def guard():
    assert all(not (loc/'STOP-REQUESTED').exists() for loc in (ROOT,PRE))
def lock(name,files):
    receipt=dict(prior=SEAL,files={p:digest(ROOT/p) for p in files})
    path=ROOT/name
    if path.exists():assert json.loads(path.read_bytes())==receipt
    else:path.write_text(json.dumps(receipt,indent=2,sort_keys=True)+'\n',encoding='utf8')
def source_lock():
    lock('source-freeze.json',['PROTOCOL.md','paired_stage.py','forecast_pair.py','transport_pair.py']+[f'forecast-{m}-{s}.npz' for m in MODES for s in (2,4)])
def photon_lock():
    assert (ROOT/'source-freeze.json').is_file();source_lock()
    lock('photons-freeze.json',['source-freeze.json']+['forecast/photons-'+s+'.npz' for s in SETTINGS])
sys.path.insert(0,str(PRE));prior('average_stage.py')
