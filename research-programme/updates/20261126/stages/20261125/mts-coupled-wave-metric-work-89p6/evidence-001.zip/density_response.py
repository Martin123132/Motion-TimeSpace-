from paired_stage import ROOT,prior,guard,photon_lock,MODES,SETTINGS
from average_heavy import setup,np
from types import SimpleNamespace
from unittest.mock import patch
from scipy.interpolate import CubicSpline
import stage_u

def density(mode):
    ctx=setup(mode)
    with np.load(ROOT/f'forecast-{mode}-4.npz') as f,np.load(prior(f'prediction-{mode}-4.npz')) as avg,np.load(stage_u.pin(f'matter-{mode}.npz')) as initial:
        grid=f['grid'];gravity=f['gravity'];phi=initial['states'][:-1,initial['keys'].tolist().index('geom')]
        initial_difference=avg['average_ejp'][:-1:4,0]-(ctx.matched.state[:-1,-2]+3*phi)
        env=ctx.matched.environment(grid)
        prediction=-.5*np.diff(env[-2])*np.repeat(initial_difference,4)
        normalized=prediction/env[-1][1:]
        names=f['fields'].tolist();labels=f['labels'].tolist()
        observed=lambda space,k:f[space][labels.index('saved_current'),:,names.index(k)]-f[space][labels.index('saved_both'),:,names.index(k)]
        fields=dict(leading=normalized,pair=observed('photon','pair'),total=observed('photon','total'))
        collapse=lambda x:x.reshape(-1,4).sum(1)/np.sqrt(np.diff(gravity))
        rows=[]
        for k in ('pair','total'):
            obs=collapse(observed('source',k));er=np.linalg.norm(collapse(prediction)-obs)/np.linalg.norm(obs)
            rows.append(dict(mode=mode,term=k,settings='local',error_pct=er*100))
        return SimpleNamespace(time=gravity,knots=grid,keys=list(fields),values=np.column_stack(list(fields.values()))/np.diff(grid)[:,None]),rows
if __name__=='__main__':
    guard();assert (ROOT/'photons-freeze.json').is_file();photon_lock()
    data={m:density(m) for m in MODES}
    from transport_pair import transport,io,gate
    dest=ROOT/'density-diagnostic';dest.mkdir(exist_ok=True);io.ROOT=dest
    rows=[r for _,results in data.values() for r in results]
    _,axis,weight,_=gate.proj.old.get_media();measure=gate.previous.make_measure(axis,weight)
    with patch.object(transport,'ROOT',dest),patch.object(transport,'source',lambda m,b:(data[m][0],None)):
        for setting in SETTINGS:
            transport.project(setting)
            with np.load(dest/f'photons-{setting}.npz') as f:
                for idx,mode in enumerate(MODES):
                    vals=CubicSpline(f['scale'],f['values'][:,idx,0])(axis)
                    for j,k in enumerate(('pair','total'),1):
                        er=gate.mag(vals[:,0]-vals[:,j],measure)/gate.mag(vals[:,j],measure)
                        rows.append(dict(mode=mode,term=k,settings=setting,error_pct=100*max(er)))
    io.ROOT=ROOT;io.table('density-response.csv',rows);print(rows[:8])
