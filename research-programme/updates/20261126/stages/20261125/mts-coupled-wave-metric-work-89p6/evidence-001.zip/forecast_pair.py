from paired_stage import ROOT,prior,guard,source_lock,LABELS,MODES
prior('average_heavy.py')
from average_heavy import setup,io,np
from required_u import Blind
from blind_native_wave import Wave
import stage_u
io.ROOT=ROOT

def forms(env,kk,kval,is_wave):
    bg,q,stress,_,_,_,rho,den=env;h=bg['h'];fac=1.5*h/kk
    n=len(h);weights=np.zeros((n,3,13),complex);external=np.zeros((n,3),complex)
    if is_wave:
        dh=1.5*bg['hv']**2
        weights[:,0,-3]=(bg['a']*bg['hm'])**2*bg['hb']/2+fac*kk*bg['hv']
        weights[:,0,-2]=bg['hv']/2
        external[:,0]=q['henergy']/2+fac*q['hJ']
    else:
        dh=1.5*rho;weights[:,0,-3]=rho/2;weights[:,0,-2]=fac*rho
    weights[:,0,-1]=dh;weights[:,1,-1]=den-dh
    weights[:,2,0]=bg['eg']/2;weights[:,2,1]=bg['eg']*fac
    weights[:,2,3]=(4*bg['er']+bg['nuE'])/2;weights[:,2,4]=fac*kval*(4*bg['er']+bg['nuJ'])
    weights[:,2,5]=bg['ec']/2;weights[:,2,6]=fac*bg['ec'];weights[:,2,7]=bg['eb']/2
    weights[:,2,8]=(bg['a']*bg['sm'])**2*bg['sb']/2+fac*kk*bg['sv'];weights[:,2,9]=bg['sv']/2
    external[:,2]=(q['gE']+q['btrace']+q['bKE']+stress[:,0]+q['ctrace']+q['cKE']+q['senergy'])/2+fac*(q['gJ']+q['bJq']+q['nuJ']+stress[:,1]+q['cJq']+q['sJ'])
    return weights,external,den

def step(solver,a,b,states):
    increments=np.zeros_like(states)
    for low,high in zip(np.r_[-np.inf,solver.src.corners],np.r_[solver.src.corners,np.inf]):
        left=np.maximum(a,low);right=np.minimum(b,high);idx=np.flatnonzero(right>left)
        if not len(idx):continue
        left=left[idx];right=right[idx];middle=(left+right)/2;width=right-left;dt=width[:,None]
        envs=[solver.env(t,middle) for t in (left,left+width/3,right-width/3,right)]
        for label in range(len(states)):
            begin=states[label,idx]+increments[label,idx]
            first=solver.rhs(envs[0],begin)
            second=solver.rhs(envs[1],begin+dt*first/3)
            third=solver.rhs(envs[2],begin+dt*(second-first/3))
            fourth=solver.rhs(envs[3],begin+dt*(first-second+third))
            increments[label,idx]+=dt*(first+3*second+3*third+fourth)/8
    return increments

def branch(src,states,split,is_wave):
    solver=Wave(src) if is_wave else Blind(src)
    time=src.time;left=time[:-1];width=np.diff(time)
    cuts=left[:,None]+width[:,None]*np.arange(split+1)/split;cuts[:,-1]=time[1:]
    grid=np.r_[cuts[:,:-1].ravel(),time[-1]]
    weights,ext,den=forms(solver.env(grid),src.kk,src.wave,is_wave)
    parts=[]
    for j in range(split):
        delta=step(solver,cuts[:,j],cuts[:,j+1],states)
        lo=slice(j,-1,split);hi=slice(j+1,None,split)
        parts.append(np.einsum('ntk,lnk->lnt',weights[hi],delta)+np.einsum('ntk,lnk->lnt',weights[hi]-weights[lo],states)+(ext[hi]-ext[lo])[None,:,:])
        states=states+delta
    return np.stack(parts,axis=2).reshape(len(states),-1,3),den[1:],grid

def forecast(mode,split):
    ctx=setup(mode);time=ctx.wave.time
    with np.load(stage_u.pin(f'matter-{mode}.npz')) as initial:
        phi=initial['states'][:-1,initial['keys'].tolist().index('geom')]
    with np.load(prior(f'prediction-{mode}-{split}.npz')) as previous:
        assert np.array_equal(time,previous['gravity'])
        filtered=previous['average_ejp'][:-1:split,:2]
    ms=np.repeat(np.column_stack((ctx.matched.state[:-1],phi))[None,:,:],len(LABELS),axis=0)
    for idx,label in enumerate(LABELS):
        if label in ('filtered','saved_current'):ms[idx,:,-3]=filtered[:,0]-3*phi
        if label in ('filtered','saved_density'):ms[idx,:,-2]=filtered[:,1]
    ws=ctx.wave.interp(time[:-1]);ws[:,-1]=ctx.wave.phi(time[:-1])
    native,dw,grid=branch(ctx.wave,ws[None,:,:],split,True)
    matched,dm,clock=branch(ctx.matched,ms,split,False);assert np.array_equal(grid,clock)
    supply_w=np.diff(ctx.wave.environment(grid)[1]['U']);supply_m=np.diff(ctx.matched.environment(grid)[1]['U'])
    def encode(wv,mv,sw,sm):
        heavy,metric,other=(wv-mv).transpose(2,0,1)
        supply=np.broadcast_to(sm-sw,heavy.shape)
        return np.stack([heavy,metric,heavy+metric,other,supply,heavy+metric+other+supply],axis=-1)
    u=encode(native,matched,supply_w,supply_m)
    photon=encode(native/dw[None,:,None],matched/dm[None,:,None],supply_w/dw,supply_m/dm)
    assert np.isfinite(u).all() and np.isfinite(photon).all()
    io.pack(f'forecast-{mode}-{split}.npz',grid=grid,gravity=time,source=u,photon=photon,labels=LABELS,fields=('heavy','metric','pair','ordinary','supplied','total'))
if __name__=='__main__':
    guard()
    for mode in MODES:
        for split in (2,4):forecast(mode,split);print(mode,split,flush=True)
    source_lock()
