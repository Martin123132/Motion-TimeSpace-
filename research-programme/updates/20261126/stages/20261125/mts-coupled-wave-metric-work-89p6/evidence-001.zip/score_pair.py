import csv
from paired_stage import ROOT,guard,prior,photon_lock,LABELS,MODES,SETTINGS
from transport_pair import gate,io,np
from cell89 import pin as old
from scipy.interpolate import CubicSpline
io.ROOT=ROOT
def evaluate():
    guard();assert (ROOT/'photons-freeze.json').exists();photon_lock()
    _,axis,weight,_=gate.proj.old.get_media();measure=gate.previous.make_measure(axis,weight)
    mag=lambda val:gate.mag(val,measure)
    with gate.pin(gate.FROZEN,'window-readouts.csv').open() as fp:
        launch={r['gravity']:float(r['launch_norm']) for r in csv.DictReader(fp) if r['model']=='MTS-minus-baseline' and r['output']=='joint'}
    scores=[];local=[];control=[];size=[];terms=[];cache={}
    def test(mode,setting,name,err):
        value=float(np.max(err));assert np.isfinite(value)
        control.append(dict(mode=mode,setting=setting,test=name,worst_relative=value,passes=value<=.005))
    for mode in MODES:
        for split in (2,4):
            with np.load(ROOT/f'forecast-{mode}-{split}.npz') as f,np.load(ROOT/f'reference-{mode}-{split}.npz') as ref:
                assert np.array_equal(f['grid'],ref['grid']) and np.array_equal(f['fields'],ref['fields'])
                width=np.diff(f['gravity']);collapse=lambda z:z.reshape(-1,split).sum(1)/np.sqrt(width)
                for i,label in enumerate(LABELS):
                    for j,k in enumerate(f['fields'].tolist()):
                        actual=collapse(ref['source'][0,:,j]);pred=collapse(f['source'][i,:,j])
                        err=np.linalg.norm(pred-actual)/np.linalg.norm(actual)
                        local.append(dict(mode=mode,split=split,entry=label,component=k,error_pct=100*err,passes=bool(err<=.005)))
    for setting in SETTINGS:
        fn='photons-'+setting+'.npz'
        with np.load(ROOT/'forecast'/fn) as f,np.load(ROOT/'reference'/fn) as ref,np.load(prior(fn)) as prev,np.load(old(f'photon-{setting}.npz')) as motion:
            grid=f['scale'];assert all(np.array_equal(grid,u) for u in (ref['scale'],prev['scale'],motion['grid']))
            interp=lambda data:CubicSpline(grid,data)(axis)
            for m,mode in enumerate(MODES):
                def terms_at(z):
                    values=interp(z['values'][:,m,0]);return {k:values[:,j] for j,k in enumerate(z['channels'].tolist())}
                a=terms_at(ref);p=terms_at(f);arch=terms_at(prev)
                mom=interp(motion['values'][:,motion['labels'].tolist().index([mode,'primary']),:3].sum(1))
                den=mag(mom);t=a['actual_total']
                test(mode,setting,'archive_total',mag(t-arch['target'])/mag(t))
                test(mode,setting,'archive_heavy',mag(a['actual_heavy']-arch['heavy_target'])/mag(a['actual_heavy']))
                for label in ('actual','filtered'):
                    pool=a if label=='actual' else p
                    get=lambda name:pool[label+'_'+name]
                    test(mode,setting,label+'_linear_sum',mag(get('total')-get('pair')-get('ordinary')-get('supplied'))/mag(get('total')))
                    test(mode,setting,label+'_signed_pair',mag(get('pair')-get('heavy')-get('metric'))/mag(get('pair')))
                    for k in ('heavy','metric','pair','ordinary','supplied','total'):
                        v=get(k);sizepct=100*mag(v)/den
                        terms.append(dict(mode=mode,setting=setting,entry=label,term=k,energy_common_pct=sizepct[0],current_common_pct=sizepct[1],joint_common_pct=sizepct[2]))
                for k in ('pair','total'):
                    test(mode,setting,k+'_linear_entry_controls',mag(p['filtered_'+k]-p['saved_current_'+k]-p['saved_density_'+k]+p['saved_both_'+k])/mag(a['actual_'+k]))
                for label in ('actual',*LABELS):
                    pool=a if label=='actual' else p
                    for k in ('pair','total'):
                        v=pool[label+'_'+k];cache[mode,setting,label,k]=v
                        test(mode,setting,label+'_'+k+'_half_to_quarter',mag(pool['half_'+label+'_'+k]-v)/mag(v))
                for label in LABELS:
                    for forecast,target in [('pair','pair'),('pair','total'),('total','total')]+([('heavy','heavy'),('metric','metric'),('ordinary','ordinary')] if label=='filtered' else []):
                        expected=a['actual_'+target];val=p[label+'_'+forecast];diff=mag(val-expected);er=diff/mag(expected);ph=mag(val)/den*100
                        scores.append(dict(mode=mode,setting=setting,entry=label,forecast=forecast,target=target,energy_error_pct=100*er[0],current_error_pct=100*er[1],joint_error_pct=100*er[2],joint_size_common_pct=ph[2],joint_error_common_pct=100*diff[2]/den[2],passes=bool(max(er)<=.005)))
                for label,v in [('actual',t),('filtered',p['filtered_total'])]:
                    pct=100*mag(v)/den;momentum=100*den[2]/launch[mode];corr=100*mag(mom+v)[2]/launch[mode]
                    size.append(dict(mode=mode,setting=setting,entry=label,energy_common_pct=pct[0],current_common_pct=pct[1],joint_common_pct=pct[2],rate_pass=bool(max(pct)<=.5),momentum_launch_pct=momentum,differentiated_launch_pct=corr,size_pass=bool(max(momentum,corr)<.163)))
    for mode in MODES:
        for label in ('actual',*LABELS):
            for k in ('pair','total'):
                v=cache[mode,'primary',label,k]
                for alt,which in [('time',mode),('angle',mode)]+([('primary','p16')] if mode=='p32' else []):
                    test(mode,'primary',label+'_'+k+'_'+('gravity' if which!=mode else alt),mag(v-cache[which,alt,label,k])/mag(v))
    for name,rows in [('local-scores',local),('photon-scores',scores),('numerical-controls',control),('size-gates',size),('components',terms)]:io.table(name+'.csv',rows)
    print('Failed numerical controls:',[(r['mode'],r['test'],r['worst_relative']) for r in control if not r['passes']][:20])
if __name__=='__main__':evaluate()
