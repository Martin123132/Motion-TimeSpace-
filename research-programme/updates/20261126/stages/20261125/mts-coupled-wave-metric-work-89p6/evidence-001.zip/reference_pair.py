from paired_stage import ROOT,prior,guard,photon_lock,MODES
from average_heavy import setup,np,io
import average_stage,wave_stage,stage_u
io.ROOT=ROOT
def make(mode,split):
    ctx=setup(mode)
    with np.load(average_stage.pin(f'blind-{mode}-{split}.npz')) as blind,np.load(average_stage.pin(f'work-{mode}-{split}.npz')) as work,np.load(wave_stage.pin(f'comparison-{mode}-{split}.npz')) as match,np.load(wave_stage.pin(f'required-{mode}-{split}.npz')) as req,np.load(stage_u.pin(f'matter-{mode}.npz')) as packet,np.load(prior(f'signed-{mode}-{split}.npz')) as saved:
        grid=saved['grid'];assert all(np.array_equal(grid,x['grid']) for x in (work,blind,match,req))
        we=ctx.wave.environment(grid);me=ctx.matched.environment(grid);bg,q=we[:2];kk=ctx.kk
        def native_heavy(state,sl):
            hf,hw,phi=state[:,-3:].T
            energy=bg['hv'][sl]*hw+((bg['a']*bg['hm'])**2*bg['hb'])[sl]*hf+q['henergy'][sl]+3*bg['hv'][sl]**2*phi
            current=kk*bg['hv'][sl]*hf+q['hJ'][sl]
            return energy/2+1.5*bg['h'][sl]*current/kk
        wh=native_heavy(blind['end'],slice(1,None))-native_heavy(blind['start'],slice(None,-1))
        dw=we[-1][1:];dm=me[-1][1:];mh=(wh/dw-saved['heavy_target'])*dm
        delta=req['phi_impulse'].reshape(-1,split);phi=packet['states'][:-1,packet['keys'].tolist().index('geom')]
        ml=(phi[:,None]+np.column_stack((np.zeros(len(phi)),np.cumsum(delta,axis=1)[:,:-1]))).ravel()
        def pieces(den,dh,phi,delta,terms,heavy):
            inc=lambda wt:wt[1:]*delta+np.diff(wt)*phi
            metric=inc(den-dh);ordinary=terms[:,2:].sum(1)+inc(dh)-heavy
            return np.stack((heavy,metric,heavy+metric,ordinary))
        wave=pieces(we[-1],1.5*bg['hv']**2,blind['start'][:,-1],blind['impulse'],blind['terms'],wh)
        matched=pieces(me[-1],1.5*me[-2],ml,req['phi_impulse'],req['terms'],mh)
        def stack(v,supply,target):
            err=np.max(abs(v[2]+v[3]+supply-target))/np.max(abs(target))
            assert err<1e-7,err
            return np.vstack((v,supply,target)).T[None,:,:]
        src=stack(wave-matched,match['supplied']-work['supplied'],(match['supplied']-match['required'])-(work['supplied']-work['required']))
        ph=stack(wave/dw-matched/dm,match['supplied']/dm-work['supplied']/dw,saved['target'])
        io.pack(f'reference-{mode}-{split}.npz',grid=grid,gravity=work['gravity'],labels=['actual'],fields=['heavy','metric','pair','ordinary','supplied','total'],source=src,photon=ph)
if __name__=='__main__':
    guard();assert (ROOT/'photons-freeze.json').exists();photon_lock()
    for mode in MODES:
        for split in (2,4):make(mode,split)
