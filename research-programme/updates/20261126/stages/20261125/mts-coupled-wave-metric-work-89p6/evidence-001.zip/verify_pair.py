from paired_stage import ROOT,SEAL,guard,photon_lock,MODES,SETTINGS,LABELS,lock,digest
import ast,csv,re,json
from average_heavy import setup,np
from required_u import Blind
def read(name):
    with (ROOT/name).open() as stream:return list(csv.DictReader(stream))
def verify():
    guard();assert (ROOT/'photons-freeze.json').is_file();photon_lock()
    controls=read('numerical-controls.csv');assert len(controls)==158
    assert all(np.isfinite(float(row['worst_relative'])) and row['passes']==str(float(row['worst_relative'])<=.005) for row in controls)
    gates=read('size-gates.csv');assert len(gates)==12
    for row in gates:
        assert row['rate_pass']==str(max(float(row[k+'_common_pct']) for k in ('energy','current','joint'))<=.5)
        assert row['size_pass']==str(max(float(row[k+'_launch_pct']) for k in ('momentum','differentiated'))<.163)
    for row in read('photon-scores.csv'):
        assert row['passes']==str(max(float(row[k+'_error_pct']) for k in ('energy','current','joint'))<=.5)
    derivatives={}
    for mode in MODES:
        ctx=setup(mode);src=ctx.matched;solver=Blind(src)
        clock=src.time[:-1:11];env=solver.env(clock);bg=env[0];rho=env[-2];cs=env[3][0]
        assert 'U' not in env[1] and max(abs(cs))>0
        zero=np.zeros((len(clock),13),complex);kick=zero.copy();kick[:,-3]=1
        diff=solver.rhs(env,kick)-solver.rhs(env,zero);expected=zero.copy()
        expected[:,-3]=-3*bg['h']*cs;expected[:,-2]=ctx.kk*cs
        rel=np.max(abs(expected-diff))/np.max(abs(expected))
        assert rel<1e-7 and np.max(abs(diff[:,-1]))==0,rel
        derivatives[mode]=dict(density_kick_rhs_relative=float(rel),max_cs2=float(max(abs(cs))))
        for split in (2,4):
            with np.load(ROOT/f'forecast-{mode}-{split}.npz') as f,np.load(ROOT/f'reference-{mode}-{split}.npz') as r:
                assert np.array_equal(f['grid'][::split],f['gravity']) and np.array_equal(f['grid'],r['grid'])
                assert f['labels'].tolist()==list(LABELS)
                assert np.isfinite(f['source']).all() and np.isfinite(r['photon']).all()
                assert np.max(abs(f['source'][1]-f['source'][3]))>0
    for path in ROOT.glob('*.py'):ast.parse(path.read_text(encoding='utf8'))
    assert not list(ROOT.rglob('__pycache__'))
    for folder in ('forecast','reference','density-diagnostic'):
        for setting in SETTINGS:
            rows=read(folder+'/quadrature-'+setting+'.csv');assert len(rows)==2 and max(float(r['relative']) for r in rows)<.005
    diagnostic=read('density-response.csv')
    assert len(diagnostic)==16 and max(float(r['error_pct']) for r in diagnostic)<.5
    for path in re.findall(r'\]\(([^)]+)\)',(ROOT/'RESULTS.md').read_text(encoding='utf8')):assert (ROOT/path).is_file()
    output=dict(prior=SEAL,clock_controls=len(controls),clock_controls_passing=sum(r['passes']=='True' for r in controls),density_kick=derivatives,diagnostic='signed filtered-minus-saved density; not a density forecast',frozen_source=digest(ROOT/'source-freeze.json'),frozen_photons=digest(ROOT/'photons-freeze.json'))
    path=ROOT/'validation.json'
    if path.exists():assert json.loads(path.read_bytes())==output
    else:path.write_text(json.dumps(output,indent=2,sort_keys=True)+'\n',encoding='utf8')
    lock('seal.json',sorted(p.relative_to(ROOT).as_posix() for p in ROOT.rglob('*') if p.is_file() and p.name!='seal.json'))
    print('Verified',digest(ROOT/'seal.json'),derivatives)
if __name__=='__main__':verify()
