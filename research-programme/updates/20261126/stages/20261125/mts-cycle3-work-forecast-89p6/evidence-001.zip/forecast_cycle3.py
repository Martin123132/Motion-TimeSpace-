from third_stage import ROOT,CASES,tag,freeze,locked,guard
from cycle3_inputs import make,operator,forms,DIM,QI,QN,io,np
import sys,math
def add(values):
    values=np.asarray(values)
    return complex(math.fsum(values.real.ravel()),math.fsum(values.imag.ravel()))
def colsum(vals):return np.array([add(col) for col in np.asarray(vals).T])
def constraint(src,solver,t,state):
    env=src.environment(np.array([t]));energy,current=solver.aggregate(env,state[None,:12])
    return add([env[1]['U'][0],-env[-1][0]*state[12],-energy[0]/2,-1.5*env[0]['h'][0]*current[0]/src.kk])
def advance(src,solver,grid,start,end,state,branch,work_from,extra=()):
    bounds=np.asarray(src.corners);cuts=np.unique(np.r_[start,end,grid[(grid>start)&(grid<end)],bounds[(bounds>start)&(bounds<end)],extra])
    assert cuts[0]==start and cuts[-1]==end
    states=[state.copy()];work=[];products=[];layers=[]
    for begin in range(0,len(cuts)-1,48):
        guard();stop=min(begin+48,len(cuts)-1);left=cuts[begin:stop];right=cuts[begin+1:stop+1];mid=(left+right)/2
        budget=right[-1]>work_from
        stages=[]
        for time in (left,mid,right):
            mat,bi,bn=operator(solver,time,mid);mat[:,:13,QI]+=bi;mat[:,:13,QN]+=bn
            if budget:
                env=src.environment(time,mid);weights,external,_=forms(env,src.kk,src.wave,branch=='wave')
                stages.append((mat,weights,external,env[1]['U']))
            else:stages.append((mat,))
        for row,dt in enumerate(right-left):
            old=state
            def rhs(pos,x):
                mat=stages[pos][0][row]
                return mat[:,:DIM]@x+mat[:,-1]
            ka=rhs(0,old);xb=old+dt*ka/2;kb=rhs(1,xb)
            xc=old+dt*kb/2;kc=rhs(1,xc);xd=old+dt*kc;kd=rhs(2,xd)
            inc=dt*(ka+2*kb+2*kc+kd)/6;state=old+inc;states.append(state.copy())
            if left[row]<work_from:continue
            w0,wm,w1=[stage[1][row] for stage in stages]
            lower=wm-w0;upper=w1-wm
            wrate=dt*(w0@ka[:13]+2*(wm@(kb[:13]+kc[:13]))+w1@kd[:13])/6
            coeff=((3*lower-upper)@old[:13]+2*((lower+upper)@(xb[:13]+xc[:13]))+(3*upper-lower)@xd[:13])/6
            ext=stages[2][2][row]-stages[0][2][row];supply=stages[2][3][row]-stages[0][3][row]
            work.append(np.r_[supply,-(wrate+coeff+ext)])
            products.append(np.r_[supply,-(w1@inc[:13]+(w1-w0)@old[:13]+ext)])
            layers.append(np.stack((-wrate,-coeff,-ext)))
    loc=np.searchsorted(cuts,work_from);assert cuts[loc]==work_from
    return cuts,np.array(states),np.array(work).reshape(-1,4),np.array(products).reshape(-1,4),np.array(layers).reshape(-1,3,3)
def index_grid(grid,left,right):
    il=np.searchsorted(grid,left,side='right')-1;ir=np.searchsorted(grid,right,side='left')
    return grid[il],grid[il+1],grid[ir-1],grid[ir]
def prepare(case):
    mode,branch,sub=case;src,solver,grid,entry,(left,right)=make(*case)
    low,*_=index_grid(grid,left,right)
    cuts,states,work,product,_=advance(src,solver,grid,grid[0],left,entry,branch,low)
    lead=colsum(work) if len(work) else np.zeros(4,complex);lead_p=colsum(product) if len(product) else np.zeros(4,complex)
    io.pack('left-'+tag(*case)+'.npz',launch=states[-1],left=left,right=right,pre_bracket=low,lead_work=lead,lead_product=lead_p,initial_constraint=constraint(src,solver,left,states[-1]))
def forecast(case):
    mode,branch,sub=case;src,solver,grid,_,(left,right)=make(*case)
    low,loend,hibegin,hi=index_grid(grid,left,right)
    with np.load(ROOT/('left-'+tag(*case)+'.npz')) as init:
        state=init['launch'];pre=init['lead_work'];initial=init['initial_constraint'].item()
        assert left==init['left'] and low==init['pre_bracket'] and right==init['right']
    cuts,states,work,product,layers=advance(src,solver,grid,left,hi,state,branch,left,extra=[right])
    upto=np.searchsorted(cuts,right);exact=colsum(work[:upto]);cons=constraint(src,solver,right,states[upto])
    lower_fraction=(loend-left)/(loend-low);upper_fraction=(right-hibegin)/(hi-hibegin)
    fraction=np.ones(len(work));fraction[cuts[:-1]<loend]=lower_fraction;fraction[cuts[:-1]>=hibegin]=upper_fraction
    sampled=colsum(work*fraction[:,None])+pre*lower_fraction
    algebra=colsum(product[:upto]);budget=np.stack([colsum(layers[:upto,j,:]) for j in range(3)])
    assert np.isfinite(sampled).all() and np.isfinite(budget).all()
    io.pack('forecast-'+tag(*case)+'.npz',terms=['given_U','heavy','metric','ordinary'],exact=exact,cell_convention=sampled,discrete_product=algebra,left=left,right=right,brackets=[low,loend,hibegin,hi],fractions=[lower_fraction,upper_fraction],from_field_rates=budget[0],from_changing_weights=budget[1],from_given_matter=budget[2],left_constraint=initial,right_constraint=cons,direct_difference=cons-initial,right_state=states[upto],left_state=state)
if __name__=='__main__':
    guard()
    if sys.argv[1]=='prepare':
        for case in CASES:prepare(case)
        freeze('left-freeze.json',['PROTOCOL.md','third_stage.py','cycle3_inputs.py','forecast_cycle3.py','score_cycle3.py']+['left-'+tag(*c)+'.npz' for c in CASES])
    elif sys.argv[1]=='forecast':
        locked('left-freeze.json')
        for case in CASES:forecast(case)
        freeze('prediction-freeze.json',['left-freeze.json']+['forecast-'+tag(*c)+'.npz' for c in CASES])
    else:raise ValueError('unknown phase')
