from third_stage import ROOT,MODES,BRANCHES,CASES,tag,guard,locked,freeze,sha
from score_cycle3 import add,table
import numpy as np,ast,csv
def read(name):
    with (ROOT/name).open() as stream:return list(csv.DictReader(stream))
def main():
    guard();locked('left-freeze.json');locked('prediction-freeze.json')
    gates=read('endpoint-tests.csv');controls=read('controls.csv');edges=read('saved-boundaries.csv')
    assert (len(gates),len(controls),len(edges))==(24,51,8)
    for r in gates+controls:
        pred=complex(float(r['forecast_real']),float(r['forecast_imag']));ref=complex(float(r['reference_real']),float(r['reference_imag']))
        err=100*abs(pred-ref)/abs(ref);assert abs(err-float(r['complex_error_pct']))<1e-10 and (err<=.5)==(r['passes']=='True')
    for r in edges:
        assert float(r['ledger_reconstruction_relative'])<1e-8 and (float(r['cell_anchored_right_error_pct'])<=.5)==(r['passes']=='True')
    detail=[]
    for m in MODES:
        for n in (2,4):
            rows={}
            for b in BRANCHES:
                with np.load(ROOT/f'forecast-{tag(m,b,n)}.npz') as f,np.load(ROOT/f'left-{tag(m,b,n)}.npz') as l:
                    assert np.array_equal(f['left_state'],l['launch']) and f['left']==l['left'] and f['right']==l['right']
                    assert np.isfinite(f['right_state']).all()
                    rows[b]=(f['exact'],np.stack([f[k] for k in ('from_field_rates','from_changing_weights','from_given_matter')]))
            vec,pieces=[a-b for a,b in zip(rows['matched'],rows['wave'])];total=add(vec)
            for j,sector in enumerate(('heavy','complementary_metric','ordinary')):
                sector_total=add(pieces[:,j]);roundoff=32*np.finfo(float).eps*sum(np.sum(abs(row[1][:,j]))+abs(row[0][j+1]) for row in rows.values())
                assert abs(sector_total-vec[j+1])<=roundoff and abs(sector_total-vec[j+1])<=.005*abs(total)
                for k,key in enumerate(('field_rate','changing_weight','given_matter')):
                    x=pieces[k,j];detail.append(dict(mode=m,subdivision=n,sector=sector,term=key,real=x.real,imag=x.imag,signed_pct_of_branch_difference=100*(x*total.conjugate()).real/abs(total)**2))
    table('difference-detail.csv',detail)
    for p in ROOT.glob('*.py'):ast.parse(p.read_text())
    assert not list(ROOT.rglob('__pycache__'))
    if (ROOT/'RESULTS.md').exists():
        freeze('seal.json',sorted(p.name for p in ROOT.iterdir() if p.is_file() and p.name!='seal.json'))
        print(sha(ROOT/'seal.json'))
if __name__=='__main__':main()
