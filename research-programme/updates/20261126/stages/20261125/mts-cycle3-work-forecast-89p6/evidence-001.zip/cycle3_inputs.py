from third_stage import ROOT,angular,previous,earlier,phase_file,guard
import csv
from unittest.mock import patch
angular('release.py');angular('angular_operator.py')
from release import Drivers,Blind,Wave,forms,stage_u,io,np
from angular_operator import operator,DIM,QI,QN
import inputs_density
from blind_native_wave import Source
from rebuild_wave import getflow
from scipy.interpolate import CubicSpline
io.ROOT=ROOT
def make(mode,branch,sub):
    guard();iswave=branch=='wave'
    with phase_file(f'cycles-{mode}.csv').open() as stream:
        hits=[(float(r['begin']),float(r['finish'])) for r in csv.DictReader(stream) if r['cycle']=='2']
    assert len(hits)==2 and hits[0]==hits[1]
    with np.load(angular(f'angular-{mode}-{sub}.npz')) as bank:
        grid=bank['grid'];gravity=bank['gravity'];entry=bank[branch+'_entry'].copy()
    zeros=lambda t:np.zeros((len(t),2),complex)
    if iswave:
        src=object.__new__(Source);src.flow,path,_=getflow(mode);src.time=gravity;src.wave=float(src.flow.k[0,0]);src.kk=src.wave**2;src.corners=[]
        with np.load(path) as bank:clock=bank['stressClock'];held=CubicSpline(np.log(clock),bank['stress'][:,:,0,0],extrapolate=False)
    else:
        with patch.object(inputs_density,'columns',lambda *unused:zeros(gravity)):src=Drivers(mode)
        assert np.array_equal(gravity,src.time)
        with np.load(stage_u.pin(f'matter-{mode}.npz')) as bank:clock=bank['stress_clock']
        held=src.stress
        with np.load(previous(f'prediction-{mode}-{sub}.npz')) as bank:entry+=bank['entry_change']
        with np.load(previous(f'preparation-{mode}.npz')) as bank:
            epoch=bank['eta'];residual=bank['residual'][:,0]
        for i,(lo,hi) in enumerate(zip(np.r_[-np.inf,src.corners],np.r_[src.corners,np.inf])):
            mask=(epoch>=lo+5e-9)&(epoch<=hi-5e-9);original=src.coeff[i];values=original(epoch[mask]);values[:,1]+=residual[mask]
            src.coeff[i]=CubicSpline(epoch[mask],values)
    with np.load(earlier(f'impulses-{mode}-{sub}.npz')) as bank:
        dense=bank[branch+'_clock'];stress=bank[branch+'_stress']
    knots=np.unique(np.r_[gravity[0],clock[(clock>gravity[0])&(clock<gravity[-1])],gravity[-1]])
    idx=np.searchsorted(dense,knots);assert np.array_equal(dense[idx],knots) and len(knots)==11
    delta=inputs_density.ip.matter.spline(knots,stress[idx])
    src.quads=zeros;src.stress=lambda u:held(u)+delta(u)
    assert entry.shape==(DIM,) and not np.any(stress[0]) and grid[0]<hits[0][0]<hits[0][1]<grid[-1]
    return src,(Wave if iswave else Blind)(src),grid,entry,hits[0]
