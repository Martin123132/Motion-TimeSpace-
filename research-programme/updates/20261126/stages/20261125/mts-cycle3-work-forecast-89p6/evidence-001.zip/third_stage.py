from pathlib import Path
import sys,json,hashlib
ROOT=Path(__file__).resolve().parent
PRE=ROOT.parent/'mts-later-cycle-drift-89p6-20261125'
PARENT='83a6b8a7da77140a682dcf332554d12a2c851134581976645fee1bc54cc2705c'
def sha(path):
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
assert sha(PRE/'seal.json')==PARENT
def ledger(name):
    p=PRE/name;assert sha(p)==json.loads((PRE/'seal.json').read_bytes())['files'][name],name
    return p
def freeze(name,files):
    guard();v={'parent':PARENT,'files':{k:sha(ROOT/k) for k in files}};p=ROOT/name
    if p.exists():assert json.loads(p.read_bytes())==v
    else:p.write_text(json.dumps(v,sort_keys=True,indent=2)+'\n')
def locked(name):
    v=json.loads((ROOT/name).read_bytes());assert v['parent']==PARENT
    for k,h in v['files'].items():assert sha(ROOT/k)==h
def guard():assert not any((p/'STOP-REQUESTED').exists() for p in (ROOT,PRE,ROOT.parent))
sys.path.insert(0,str(PRE));ledger('cycle_stage.py')
from cycle_stage import angular,previous,earlier,phase_file,MODES
BRANCHES=('matched','wave')
CASES=[(m,b,s) for m in MODES for b in BRANCHES for s in (2,4)]
def tag(m,b,s):return f'{m}-{b}-{s}'
