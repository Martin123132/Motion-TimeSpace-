from third_stage import ROOT,MODES,CASES,BRANCHES,ledger,tag,locked,guard
import numpy as np,csv,json,math
def add(v):return complex(math.fsum(np.real(v)),math.fsum(np.imag(v)))
def table(name,rows):
    import io
    out=io.StringIO();write=csv.DictWriter(out,rows[0],lineterminator='\n');write.writeheader();write.writerows(rows)
    path=ROOT/name;data=out.getvalue().encode()
    if path.exists():assert path.read_bytes()==data
    else:path.write_bytes(data)
def evaluate():
    guard();locked('left-freeze.json');locked('prediction-freeze.json')
    with ledger('raw-cycle-work.csv').open() as stream:
        rows={(r['mode'],int(r['subdivision'])):r for r in csv.DictReader(stream) if r['cycle']=='3'}
    assert len(rows)==4
    gates=[];controls=[];parts=[];values={};terms={}
    def check(m,b,n,key,value,expected):
        assert expected!=0
        diff=value-expected;err=100*abs(diff)/abs(expected)
        assert np.isfinite(err)
        return dict(mode=m,branch=b,subdivision=n,test=key,forecast_real=value.real,forecast_imag=value.imag,reference_real=expected.real,reference_imag=expected.imag,complex_error_pct=err,real_error_pct=100*abs(diff.real)/abs(expected.real) if expected.real else None,imag_error_pct=100*abs(diff.imag)/abs(expected.imag) if expected.imag else None,passes=bool(err<=.5))
    for m,b,n in CASES:
        row=rows[m,n];ref=complex(float(row[b+'_C_real']),float(row[b+'_C_imag']))
        with np.load(ROOT/f'forecast-{tag(m,b,n)}.npz') as f:
            assert f['left']==float(row['begin']) and f['right']==float(row['end'])
            exact=add(f['exact']);sampled=add(f['cell_convention']);values[m,b,n]=(exact,sampled,ref)
            terms[m,b,n]=dict(zip(f['terms'].tolist(),f['exact']))
            for key,v in [('phase_crossing',exact),('archived_cell_convention',sampled)]:gates.append(check(m,b,n,key,v,ref))
            controls.append(check(m,b,n,'integrated_vs_predicted_endpoint',exact,f['direct_difference'].item()))
            controls.append(check(m,b,n,'integrated_vs_discrete_work',exact,add(f['discrete_product'])))
            controls.append(check(m,b,n,'phase_vs_cell_convention',exact,sampled))
            pieces=f['from_field_rates']+f['from_changing_weights']+f['from_given_matter']
            assert max(abs(pieces-f['exact'][1:]))<=1e-11*max(abs(f['exact']))
    for m in MODES:
        for n in (2,4):
            pair='matched-minus-wave';v=tuple(a-b for a,b in zip(values[m,'matched',n],values[m,'wave',n]))
            values[m,pair,n]=v;terms[m,pair,n]={k:x-terms[m,'wave',n][k] for k,x in terms[m,'matched',n].items()}
            for key,x in zip(('phase_crossing','archived_cell_convention'),v[:2]):gates.append(check(m,pair,n,key,x,v[2]))
            for label in (*BRANCHES,pair):
                total=values[m,label,n][0];components=terms[m,label,n]
                for k,x in components.items():
                    parts.append(dict(mode=m,branch=label,subdivision=n,term=k,real=x.real,imag=x.imag,magnitude_over_drift=abs(x)/abs(total),signed_share_pct=100*(x*total.conjugate()).real/abs(total)**2))
                assert abs(sum(x for x in components.values())-total)<1e-8*abs(total)
    for b in (*BRANCHES,'matched-minus-wave'):
        for m in MODES:
            for j,key in enumerate(('phase_crossing','archived_cell_convention','saved')):
                controls.append(check(m,b,4,'subdivision_'+key,values[m,b,2][j],values[m,b,4][j]))
        for j,key in enumerate(('phase_crossing','archived_cell_convention','saved')):
            controls.append(check('p32',b,4,'gravity_'+key,values['p16',b,4][j],values['p32',b,4][j]))
    table('endpoint-tests.csv',gates);table('controls.csv',controls);table('work-contributions.csv',parts)
    print('endpoint checks',len(gates),'failed',sum(not x['passes'] for x in gates),'controls',len(controls),'failed',sum(not x['passes'] for x in controls))
if __name__=='__main__':evaluate()
