from third_stage import ROOT,CASES,tag,locked,previous,angular,earlier
from cycle3_inputs import make,np
from forecast_cycle3 import constraint
from score_cycle3 import table,add
import csv
def increments(path,key):
    with np.load(path) as f:
        labels=f['channels'].tolist();return f['grid'],f['values'][:,labels.index(key)]
def at(grid,work,t):
    idx=np.searchsorted(grid,t,side='right')-1
    return add(work[:idx])+(t-grid[idx])/(grid[idx+1]-grid[idx])*work[idx]
def main():
    locked('left-freeze.json');locked('prediction-freeze.json');out=[]
    with (ROOT/'endpoint-tests.csv').open() as stream:
        refs={(r['mode'],r['branch'],int(r['subdivision'])):complex(float(r['reference_real']),float(r['reference_imag'])) for r in csv.DictReader(stream) if r['test']=='phase_crossing'}
    for case in CASES:
        m,b,n=case;src,solver,_,entry,(left,right)=make(*case)
        base,live=increments(angular(f'angular-{m}-{n}.npz'),b)
        second,feedback=increments(earlier(f'impulses-{m}-{n}.npz'),b)
        assert np.array_equal(base,second)
        den=src.environment(base)[-1][1:];blocks=[(base,den*(live+feedback))]
        if b=='matched':
            g,change=increments(previous(f'prediction-{m}-{n}.npz'),'total')
            blocks.append((g,src.environment(g)[-1][1:]*change))
        lo=add([at(grid,v,left) for grid,v in blocks]);hi=add([at(grid,v,right) for grid,v in blocks])
        initial=constraint(src,solver,base[0],entry)
        with np.load(ROOT/f'forecast-{tag(*case)}.npz') as f:
            predicted=add(f['cell_convention'])
            raw=hi-lo;err=100*abs(predicted-raw)/abs(raw)
            archive_rel=abs(raw-refs[case])/abs(raw);assert archive_rel<1e-8
            left_err=100*abs((f['left_constraint']-initial)-lo)/abs(raw);right_err=100*abs((f['right_constraint']-initial)-hi)/abs(raw)
            out.append(dict(mode=m,branch=b,subdivision=n,saved_left_since_switch_real=lo.real,saved_left_since_switch_imag=lo.imag,saved_right_since_switch_real=hi.real,saved_right_since_switch_imag=hi.imag,ledger_reconstruction_relative=archive_rel,cell_anchored_right_error_pct=err,passes=bool(err<=.5),left_state_offset_pct_cycle=left_err,right_state_offset_pct_cycle=right_err))
    table('saved-boundaries.csv',out)
if __name__=='__main__':main()
