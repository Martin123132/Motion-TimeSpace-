from scipy.interpolate import CubicSpline
from kinetic_stage import ROOT,MODES,SETTINGS,window,pinned,locked,np,table,clean
window.angular('angular_photons.py')
from angular_photons import gate
from cell89 import pin as original

def score():
    clean();locked('source-freeze.json');locked('prediction-freeze.json')
    _,axis,weight,_=gate.proj.old.get_media()
    measure=gate.previous.make_measure(axis,weight)
    mag=lambda v:gate.mag(v,measure)
    rows=[];checks=[];cache={}
    def check(mode,setting,label,a,b):
        err=100*mag(a-b)/mag(b)
        checks.append(dict(mode=mode,setting=setting,test=label,energy_pct=err[0],current_pct=err[1],joint_pct=err[2],passes=bool(max(err)<=.5)))
    for setting in SETTINGS:
        name=f'photons-{setting}.npz'
        with np.load(ROOT/name) as trial,np.load(pinned(window.ARCHIVE,name)) as archive,np.load(original(f'photon-{setting}.npz')) as old:
            grid=trial['scale'];assert np.array_equal(grid,archive['scale']) and np.array_equal(grid,old['grid'])
            view=lambda v:CubicSpline(grid,v)(axis)
            for idx,mode in enumerate(MODES):
                def parts(bank):
                    assert bank['modes'].tolist()==list(MODES)
                    return dict(zip(bank['channels'].tolist(),view(bank['values'][:,idx,0]).swapaxes(0,1),strict=True))
                new=parts(trial);ref=parts(archive)
                norm=mag(view(old['values'][:,old['labels'].tolist().index([mode,'primary']),:3]).sum(1))
                for prefix in ('','half_'):
                    gap=ref[prefix+'full'];inc=new[prefix+'increment']
                    before=100*mag(gap)/norm;after=100*mag(gap+inc)/norm
                    magnitude=100*mag(inc)/norm
                    signed=100*(measure@(inc*gap.conj()).real).sum()/(mag(gap)[2]*norm[2])
                    rows.append(dict(mode=mode,setting=setting,subdivision=2 if prefix else 4,original_joint_pct=before[2],corrected_energy_pct=after[0],
                                     corrected_current_pct=after[1],corrected_joint_pct=after[2],signed_along_gap_pp=signed,increment_size_pp=magnitude[2],
                                     first_size_pp=100*mag(new[prefix+'first'])[2]/norm[2],later_size_pp=100*mag(new[prefix+'later'])[2]/norm[2],
                                     passes=bool(max(after)<=.5)))
                    for label,val in [('parts',sum(new[prefix+k] for k in ('heavy','metric','ordinary'))),('constraint',new[prefix+'direct']),('windows',new[prefix+'first']+new[prefix+'later'])]:
                        check(mode,setting,label+prefix,val,inc)
                check(mode,setting,'source_subdivision',new['half_increment'],new['increment'])
                cache[mode,setting]=new['increment']
    for mode in MODES:
        for setting in ('time','angle'):check(mode,setting,'photon_refinement',cache[mode,setting],cache[mode,'primary'])
    check('p16-p32','primary','gravity_refinement',cache['p16','primary'],cache['p32','primary'])
    table('photon-score.csv',rows);table('photon-checks.csv',checks)
if __name__=='__main__':score()
