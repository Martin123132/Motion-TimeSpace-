import ast
import csv
import sys
from kinetic_stage import ROOT,PRIOR,common,np,MODES,SETTINGS,freeze,locked,pinned

def rows(name):
    with (ROOT/name).open() as stream:return list(csv.DictReader(stream))

def run():
    for receipt in ('raw-freeze.json','source-freeze.json','prediction-freeze.json'):locked(receipt)
    pinned(PRIOR,'RESULTS.md')
    for mode in MODES:
        for sub in (2,4):
            with np.load(ROOT/f'absolute-{mode}-{sub}.npz') as raw,np.load(ROOT/f'anchored-{mode}-{sub}.npz') as res,np.load(ROOT/f'source-{mode}-{sub}.npz') as src:
                factor=raw['kinetic'][:,None];live=raw['gravity'];delta=res['raw_difference']
                assert np.array_equal(raw['work'],factor*live)
                assert np.array_equal(live-res['prepared'],delta)
                assert np.array_equal(res['increment'],factor*(delta+res['metric_response']))
                assert np.all(np.diff(raw['phase'])>0) and np.isfinite(res['increment']).all()
                assert np.all(np.isfinite(src['values'])) and np.array_equal(src['knots'],raw['cuts'])
                assert np.max(abs(src['values'][:,0]-src['values'][:,-2:].sum(1)))<1e-12*max(abs(src['values'][:,0]))
    scores=rows('wave-comparison.csv')
    cov=rows('phase-covariance.csv')
    assert len(scores)==52 and len(cov)==80
    for row in scores+cov:
        value=float(row['relative_pct'])
        assert value>=0 and np.isfinite(value) and (value<=.5)==(row['passes']=='True')
    photons=rows('photon-score.csv')
    assert len(photons)==12
    for row in photons:
        amp=[float(row[f'corrected_{key}_pct']) for key in ('energy','current','joint')]
        assert np.isfinite(amp).all() and (max(amp)<=.5)==(row['passes']=='True')
    for row in rows('photon-checks.csv'):
        ratios=[float(row[key+'_pct']) for key in ('energy','current','joint')]
        assert np.isfinite(ratios).all() and (max(ratios)<=.5)==(row['passes']=='True')
    assert len(rows('photon-checks.csv'))==47
    attributed=rows('energy-error-attribution.csv')
    assert len(attributed)==10
    for mode in MODES:
        sector=[r for r in attributed if r['mode']==mode]
        assert abs(sum(float(r['signed_pct_of_error']) for r in sector)-100)<.005
        assert max(float(r['sum_vector_error_pct']) for r in sector)<.005
    sizes=rows('launch-sizes.csv')
    assert len(sizes)==12
    for row in sizes:
        values=[float(row[k]) for k in ('momentum_pct_launch','differentiated_pct_launch')]
        assert np.isfinite(values).all() and (max(values)<=.163)==(row['passes']=='True')
    for row in rows('route-adjoint.csv'):
        assert row['relative']=='' if row['channel']=='0' else float(row['relative'])<.005
    for setting in SETTINGS:
        assert all(float(r['relative'])<=.005 for r in rows(f'quadrature-{setting}.csv'))
    assert all(float(r['max_saved_state_error_pct'])<.5 for r in rows('wave-replay.csv'))
    assert not list(ROOT.rglob('__pycache__'))
    for path in ROOT.glob('*.py'):ast.parse(path.read_text())
    if '--seal' in sys.argv:
        assert (ROOT/'RESULTS.md').is_file()
        freeze('seal.json',sorted(p.name for p in ROOT.iterdir() if p.is_file() and p.name!='seal.json'))
        locked('seal.json');print(common.sha(ROOT/'seal.json'))
if __name__=='__main__':run()
