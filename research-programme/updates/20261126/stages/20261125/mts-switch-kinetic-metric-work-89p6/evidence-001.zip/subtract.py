from scipy.interpolate import CubicSpline
from dynamics import make,phase_file,grid_of,geom,propagate,forms
from kinetic_stage import ROOT,MODES,np,pack,table,freeze,locked,clean

def residual_sources(mode,sub):
    src,solver,grid,entry,_=make(mode,'matched',sub)
    with np.load(ROOT/f'absolute-{mode}-{sub}.npz') as raw:
        cuts=raw['cuts'];factor=raw['kinetic'];live=raw['gravity'];phase=raw['phase']
    assert np.array_equal(cuts,grid_of(src,grid))
    with np.load(phase_file(f'curves-{mode}-companion.npz')) as calibr:
        times=calibr['eta']
        prepared=CubicSpline(times,np.column_stack([3*(calibr['pd']-calibr['delta_pd']),src.kk*(calibr['psi']-calibr['delta_psi'])]),extrapolate=False)(cuts)
    with np.load(phase_file(f'projected-{mode}.npz')) as calibr:
        other=CubicSpline(calibr['eta'],calibr['resolved_lapse'][:,0])(cuts)
    lapse_error=max(abs(other-prepared[:,1]))/max(abs(prepared[:,1]))
    assert lapse_error<.005 and np.isfinite(prepared).all()
    factor_curve=CubicSpline(cuts,factor)
    raw_difference=live-prepared
    forcing_curve=CubicSpline(cuts,raw_difference)
    def feedback(times):
        value=factor_curve(times)
        return value,value[:,None]*forcing_curve(times)
    delta=propagate(src,solver,cuts,np.zeros_like(entry),feedback)
    response=geom(src,solver,cuts,delta,delta=True)
    departure=raw_difference+response
    increment=factor[:,None]*departure
    env=src.environment(cuts)
    weights,_,den=forms(env,src.kk,src.wave,False)
    components=-np.einsum('ntk,nk->nt',weights,delta[:,:13])
    full=components.sum(1)
    energy,current=solver.aggregate(env,delta[:,:12],ext=False)
    direct=-den*delta[:,12]-energy/2-1.5*env[0]['h']*current/src.kk
    err=max(abs(full-direct))/max(abs(full))
    assert err<.005 and not delta[0].any()
    cells=np.searchsorted(grid,cuts[:-1],side='right')-1
    widths=src.environment(grid)[-1][cells+1]*np.diff(cuts)
    vals=np.diff(np.column_stack([full,components,direct]),axis=0)/widths[:,None]
    edge=np.interp(np.pi,phase,cuts)
    fraction=np.clip((edge-cuts[:-1])/np.diff(cuts),0,1)
    values=np.column_stack([vals,vals[:,0]*fraction,vals[:,0]*(1-fraction)])
    pack(f'source-{mode}-{sub}.npz',gravity=src.time,knots=cuts,values=values,keys=['increment','heavy','metric','ordinary','direct','first','later'])
    pack(f'anchored-{mode}-{sub}.npz',prepared=prepared,raw_difference=raw_difference,metric_response=response,departure=departure,increment=increment,first_end=edge)
    return dict(mode=mode,sub=sub,prepared_lapse_check_pct=100*lapse_error,constraint_check_pct=100*err,
                null_work_if_metric_equals_preparation=float(np.max(abs(factor[:,None]*(prepared-prepared)))))

if __name__=='__main__':
    clean();locked('raw-freeze.json')
    rows=[residual_sources(m,s) for m in MODES for s in (2,4)]
    table('subtraction-checks.csv',rows)
    freeze('source-freeze.json',['raw-freeze.json','subtraction-checks.csv']+[f'{part}-{m}-{s}.npz' for m in MODES for s in (2,4) for part in ('source','anchored')])
