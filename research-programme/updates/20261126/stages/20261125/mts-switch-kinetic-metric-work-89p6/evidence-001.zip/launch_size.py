import csv
from unittest.mock import patch
from scipy.interpolate import CubicSpline
from kinetic_stage import ROOT,MODES,SETTINGS,window,pinned,locked,np,table,pack,clean
window.angular('angular_photons.py')
from angular_photons import gate,io
from cell89 import pin as original

class Local(gate.Interface):
    def guard(self):clean()
    def table(self,name,rows):
        assert name=='photon-adjoint.csv'
        for row in rows:
            if row['channel']==0:
                assert np.isnan(row['relative'])
                row['relative']=''
            else:assert row['relative']<.005
        table('route-adjoint.csv',rows)

def run():
    clean();locked('prediction-freeze.json')
    scale,eta,medium,_,_=gate.proj.measure('heavy')
    _,axis,weight,_=gate.proj.old.get_media()
    measure=gate.previous.make_measure(axis,weight)
    mag=lambda v:gate.mag(v,measure)[2]
    with gate.pin(gate.FROZEN,'window-readouts.csv').open() as stream:
        norm={r['gravity']:float(r['launch_norm']) for r in csv.DictReader(stream) if r['model']=='MTS-minus-baseline' and r['output']=='joint'}
    with np.load(io.old.pin('photon-accumulated-heavy.npz')) as saved:wave=saved['k'].item()
    hist={}
    for mode in MODES:
        for sub,tag in ((4,'primary'),(2,'half')):
            with np.load(ROOT/f'anchored-{mode}-{sub}.npz') as input,np.load(ROOT/f'absolute-{mode}-{sub}.npz') as raw,np.load(ROOT/f'source-{mode}-{sub}.npz') as src:
                ix=np.searchsorted(raw['cuts'],src['gravity']);assert np.array_equal(raw['cuts'][ix],src['gravity'])
                rate,psi=(input['metric_response'][ix]/[3,raw['kk']]).T
                hist[mode,tag]=dict(eta=src['gravity'],delta_pd=rate,delta_psi=psi,delta_differentiated=np.zeros_like(rate),kick=0j)
    rows=[]
    for setting in SETTINGS:
        with patch.object(gate.transfer,'ps',Local()),np.errstate(invalid='ignore'):
            values=gate.transfer.transfer(setting,eta,scale,medium,wave,hist)[:,:,:3]
        assert not values[:,:,0].any() and np.isfinite(values).all()
        pack(f'route-change-{setting}.npz',scale=scale,labels=list(hist),values=values)
        name=f'photons-{setting}.npz'
        with np.load(ROOT/name) as inc,np.load(pinned(window.ARCHIVE,name)) as ref,np.load(original(f'photon-{setting}.npz')) as old,np.load(window.previous(f'launch-change-{setting}.npz')) as prep:
            assert np.array_equal(scale,old['grid']) and all(np.array_equal(scale,z['scale']) for z in (inc,ref,prep))
            view=lambda val:CubicSpline(scale,val)(axis)
            for idx,mode in enumerate(MODES):
                base=view(old['values'][:,old['labels'].tolist().index([mode,'primary']),:3].sum(1))
                for tag,prefix in (('primary',''),('half','half_')):
                    momentum=base+view(prep['values'][:,prep['labels'].tolist().index([mode,tag])].sum(1))+view(values[:,list(hist).index((mode,tag))].sum(1))
                    def channel(z,key):return view(z['values'][:,idx,0,z['channels'].tolist().index(prefix+key)])
                    gap=channel(inc,'increment')+channel(ref,'full')
                    sm,sd=100*mag(momentum)/norm[mode],100*mag(momentum+gap)/norm[mode]
                    rows.append(dict(mode=mode,setting=setting,substep=tag,momentum_pct_launch=sm,differentiated_pct_launch=sd,passes=max(sm,sd)<=.163))
    table('launch-sizes.csv',rows)
if __name__=='__main__':run()
