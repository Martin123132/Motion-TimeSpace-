from dynamics import make,grid_of,geom,propagate,phase_file,inputs_density
from kinetic_stage import ROOT,MODES,np,pinned,FIRST,table,locked,clean
from scipy.interpolate import CubicSpline

def pieces(src,solver,clock,state,native):
    env=src.environment(clock)
    bg,forcing=env[:2]
    kk=src.kk
    curr=solver.aggregate(env,state[:,:12])[1]
    heavy=(kk*bg['hv']*state[:,10]+forcing['hJ']) if native else env[-2]*state[:,11]
    psi=geom(src,solver,clock,state,native)[:,1]/kk
    return np.column_stack([1.5*heavy/kk,1.5*(curr-heavy)/kk,-3*bg['h']*psi,3*forcing['Fq']])

def compare(mode):
    sub=4
    with np.load(ROOT/f'absolute-{mode}-{sub}.npz') as raw,np.load(ROOT/f'anchored-{mode}-{sub}.npz') as inc:
        times=raw['cuts'];factor=raw['kinetic'];offset=inc['prepared'];expected=inc['increment'];departure=inc['departure']
        curve=CubicSpline(times,factor);external=CubicSpline(times,inc['raw_difference'])
    src,solver,grid,entry,_=make(mode,'matched',sub)
    matched=propagate(src,solver,times,entry)
    response=propagate(src,solver,times,np.zeros_like(entry),lambda t:(curve(t),curve(t)[:,None]*external(t)))
    first=pieces(src,solver,times,matched+response,False)
    wave,exact,_,state,_=make(mode,'wave',sub)
    with np.load(pinned(FIRST,f'work-{mode}-wave-{sub}.npz')) as data:knots=np.unique(np.r_[times,data['edges']])
    state=propagate(wave,exact,knots,state)[np.searchsorted(knots,times)]
    second=pieces(wave,exact,times,state,True)
    bg=wave.environment(times)[0];truth=bg['hv']**2*bg['a']/src.packet['rho0']-1
    actual=truth*(geom(wave,exact,times,state,True)[:,0]-offset[:,0])
    error=expected[:,0]-actual
    decomp=np.column_stack([truth[:,None]*(first-second),(factor-truth)*departure[:,0]])
    def inner(one,two):
        prod=(one*two.conj()).real
        return np.average((prod[1:]+prod[:-1])/2,weights=np.diff(times))
    norm=inner(error,error)
    closure=100*np.sqrt(inner(error-decomp.sum(1),error-decomp.sum(1))/norm)
    assert closure<.005
    rows=[]
    for idx,key in enumerate(('heavy_momentum','other_momentum','H_lapse','supplied_Fq','kinetic_prediction')):
        vec=decomp[:,idx]
        rows.append(dict(mode=mode,term=key,rms_pct_of_error=100*np.sqrt(inner(vec,vec)/norm),
                         signed_pct_of_error=100*inner(vec,error)/norm,sum_vector_error_pct=closure))
    assert abs(sum(row['signed_pct_of_error'] for row in rows)-100)<.005
    return rows

if __name__=='__main__':
    clean();locked('prediction-freeze.json')
    table('energy-error-attribution.csv',[row for mode in MODES for row in compare(mode)])
