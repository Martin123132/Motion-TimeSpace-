from scipy.interpolate import CubicSpline
from dynamics import make,geom,propagate,inputs_density
from kinetic_stage import ROOT,FIRST,np,pinned,MODES,table,freeze,locked,clean

def score(mode,sub):
    with np.load(ROOT/f'absolute-{mode}-{sub}.npz') as raw,np.load(ROOT/f'anchored-{mode}-{sub}.npz') as result:
        cuts=raw['cuts'];phase=raw['phase'];factor=raw['kinetic'];live=raw['gravity'];work=raw['work'];rho=raw['rho0'].item()
        prepared=result['prepared'];departure=result['departure'];increment=result['increment'];corrected=live+result['metric_response']
    native,solver,grid,entry,_=make(mode,'wave',sub)
    with np.load(pinned(FIRST,f'work-{mode}-wave-{sub}.npz')) as saved:
        edges=saved['edges'];saved_states=saved['states']
    joint=np.unique(np.r_[cuts,edges])
    states=propagate(native,solver,joint,entry)
    errors=[]
    for trial,target in zip(states[np.searchsorted(joint,edges)],saved_states):
        errors.append(max(abs(trial-target))/max(abs(target)))
    assert max(errors)<.005
    selected=states[np.searchsorted(joint,cuts)]
    native_geometry=geom(native,solver,cuts,selected,native=True)
    bg=native.environment(cuts)[0]
    truth=bg['hv']**2*bg['a']/rho-1
    with np.load(inputs_density.kernel.stage.pin(f'particular-heavy-{mode}.npz')) as saved:
        original=CubicSpline(saved['eta'],np.column_stack([3*saved['phi_dot'],native.kk*saved['psi']]))(cuts)
    true_work=truth[:,None]*original
    true_delta=native_geometry-prepared
    true_inc=truth[:,None]*true_delta
    measures=np.diff(cuts)
    def rms(values):
        power=abs(values)**2
        return np.sqrt(np.average((power[1:]+power[:-1])/2,axis=0,weights=measures))
    entries=[]
    def test(key,pred,target,unit):
        for idx,(val,ref,scale) in enumerate(zip(np.atleast_1d(rms(pred-target)),np.atleast_1d(rms(target)),np.atleast_1d(unit))):
            pct=100*val/ref if ref>0 else None
            entries.append(dict(mode=mode,subdivision=sub,quantity=key,channel='kinetic' if key=='kinetic_factor' else ['energy','current'][idx],
                                error_rms=val,reference_rms=ref,relative_pct=pct,pct_of_gross_reference=100*val/scale,passes=pct is not None and pct<=.5))
    test('kinetic_factor',factor,truth,rms(truth))
    test('gross_work_vs_original_saved_wave',work,true_work,rms(true_work))
    test('historical_anchor_vs_original',prepared,original,rms(original))
    test('changed_metric_vs_updated_wave',departure,true_delta,rms(original))
    test('increment_vs_updated_wave',increment,true_inc,rms(true_work))
    test('kinetic_only_same_gravity',increment,truth[:,None]*departure,rms(true_work))
    test('updated_wave_absolute',factor[:,None]*corrected,truth[:,None]*native_geometry,rms(true_work))
    phase_ends=np.r_[np.arange(0,phase[-1],np.pi),phase[-1]]
    assert len(phase_ends)==6
    stats=[]
    def means(fields):
        curve=CubicSpline(phase,fields,axis=0).antiderivative()
        return np.diff(curve(phase_ends),axis=0)/np.diff(phase_ends)[:,None]
    def covariance(osc,geometry):
        return means(osc[:,None]*geometry)-means(osc[:,None])*means(geometry)
    forecast=covariance(factor,departure);reference=covariance(truth,true_delta)
    gross_cov=covariance(factor,live);ref_gross_cov=covariance(truth,original)
    for label,first,second in [('prepared_subtracted',forecast,reference),('gross',gross_cov,ref_gross_cov)]:
        for cycle,(pred,target) in enumerate(zip(first,second),1):
            for ix in range(2):
                den=abs(target[ix])
                err=100*abs(pred[ix]-target[ix])/den if den else None
                stats.append(dict(mode=mode,subdivision=sub,cycle=cycle,partial=cycle==5,quantity=label,channel=['energy','current'][ix],
                                  prediction_re=pred[ix].real,prediction_im=pred[ix].imag,reference_re=target[ix].real,reference_im=target[ix].imag,
                                  relative_pct=err,passes=err is not None and err<=.5))
    replay=dict(mode=mode,subdivision=sub,max_saved_state_error_pct=max(errors)*100,phase_boundaries=','.join(map(str,np.interp(phase_ends,phase,cuts))))
    return entries,stats,replay

if __name__=='__main__':
    clean();locked('raw-freeze.json');locked('source-freeze.json');locked('prediction-freeze.json')
    rows=[];cov=[];checks=[]
    for mode in MODES:
        for sub in (2,4):
            tests,cycles,check=score(mode,sub);rows+=tests;cov+=cycles;checks.append(check)
    table('wave-comparison.csv',rows);table('phase-covariance.csv',cov);table('wave-replay.csv',checks)
