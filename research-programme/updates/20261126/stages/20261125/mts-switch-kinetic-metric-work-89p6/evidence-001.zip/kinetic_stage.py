import hashlib
import json
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parent
PRIOR=ROOT.parent/'mts-adiabatic-pressure-tangent-89p6-20261125'
def sha(path):
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
assert sha(PRIOR/'seal.json')=='f010b0871483e62db39661b5ff712d94385aa57793c292356e9090a6d5fba18e'
assert sha(PRIOR/'pressure_stage.py')==json.loads((PRIOR/'seal.json').read_bytes())['files']['pressure_stage.py']
sys.path.insert(0,str(PRIOR))
from pressure_stage import window,common,FIRST,pinned,np,MODES,SETTINGS,locked,freeze,pack,table
window.ROOT=common.ROOT=ROOT
common.PINS={**common.PINS,PRIOR:sha(PRIOR/'seal.json')}
def code():
    pinned(window.PAIR,'energy_current.py')
    sys.path.insert(0,str(window.PAIR))
    import pair_stage
    import cycle3_inputs
    return cycle3_inputs
def clean():
    window.safe()
if __name__=='__main__':
    window.photons()
