from scipy.interpolate import BarycentricInterpolator, CubicSpline
from scipy.integrate import solve_ivp
from kinetic_stage import ROOT,window,np,MODES,FIRST,pack,table,freeze,locked,clean,pinned,code
core=code()
from cycle3_inputs import make,operator,DIM,QI,QN,forms,inputs_density,phase_file

def geom(src,solver,t,states,native=False,delta=False):
    env=src.environment(t)
    bg,forcing,stress,coeff=env[:4]
    kk=src.kk
    shear=-bg['eg']*states[:,QI]-(4*bg['er']+bg['nuS'])*states[:,QN]
    if not delta:
        shear+=-forcing['Q']-bg['eg']*forcing['ph_shift']+stress[:,2]+forcing['cshear']+forcing['bshear']+forcing['sshear']
        shear+=forcing['hshear'] if native else env[-2]*coeff[4]
    psi=states[:,12]+shear/kk
    curr=solver.aggregate(env,states[:,:12],ext=not delta)[1]
    rate=curr/(2*kk)-bg['h']*psi
    if not delta:rate+=forcing['Fq']
    return np.column_stack([3*rate,kk*psi])

def propagate(src,solver,cuts,state,feedback=None):
    history=[state.copy()]
    for start in range(0,len(cuts)-1,32):
        clean()
        stop=min(start+32,len(cuts)-1)
        left,right=cuts[start:stop],cuts[start+1:stop+1]
        mid=(left+right)/2
        ops=[]
        for tt in (left,mid,right):
            mat,bi,bn=operator(solver,tt,mid)
            mat[:,:13,QI]+=bi;mat[:,:13,QN]+=bn
            if feedback is not None:
                factor,external=feedback(tt)
                bg=src.environment(tt,mid)[0]
                phirow=3*mat[:,12,:DIM].copy()
                mat[:,:,-1]=0
                mat[:,10,-1]=external[:,0];mat[:,11,-1]=external[:,1]
                mat[:,10,:DIM]+=factor[:,None]*phirow
                mat[:,11,12]+=factor*src.kk
                mat[:,11,QI]-=factor*bg['eg']
                mat[:,11,QN]-=factor*(4*bg['er']+bg['nuS'])
            ops.append(mat)
        for idx,width in enumerate(right-left):
            def rhs(index,trial):
                mat=ops[index][idx]
                return mat[:,:DIM]@trial+mat[:,-1]
            one=rhs(0,state);two=rhs(1,state+width*one/2);three=rhs(1,state+width*two/2);four=rhs(2,state+width*three)
            state=state+width/6*(one+2*two+2*three+four)
            history.append(state.copy())
    out=np.asarray(history)
    assert np.isfinite(out).all()
    return out

def launch(src,cuts):
    base=inputs_density.kernel.stage
    with np.load(base.pin('exact-phase-extension.npz')) as data:
        mass=float(data['heavy_mass_mpc']);rho0=float(data['matching_density'])
        assert rho0==src.packet['rho0']
        loga=data['heavy_efold']
        match=float(data['matching_scale'])
        start=np.log(match)
        stop=np.searchsorted(loga,start,side='right')
        def state(n):
            xs=loga[stop-n:stop]
            assert xs[-1]<=start and start-xs[-1] < 1.02*(xs[-1]-xs[-2])
            vals=np.column_stack([data[k][stop-n:stop] for k in ('phi_h','phidot_h')])
            u=(xs-xs[-1])/(xs[-1]-xs[-2])
            return np.polynomial.polynomial.polyval((start-xs[-1])/(xs[-1]-xs[-2]),np.polynomial.polynomial.polyfit(u,vals,n-1))
        entry=state(6);alt=state(5)
    bg=src.environment(cuts)[0]
    assert abs(bg['a'][0]/match-1)<1e-5
    hub=CubicSpline(cuts,bg['h']);scale=CubicSpline(cuts,bg['a'])
    def solve(step):
        def rhs(eta,y):return [y[1],-2*hub(eta)*y[1]-(mass*scale(eta))**2*y[0]]
        sol=solve_ivp(rhs,(cuts[0],cuts[-1]),entry,t_eval=cuts,method='DOP853',rtol=2e-12,atol=[1e-16,1e-15],max_step=step)
        assert sol.success
        field,vel=sol.y
        kinetic=vel**2*bg['a']/rho0-1
        angle=np.unwrap(np.arctan2(-vel/(mass*bg['a']),field))
        assert np.all(np.diff(angle)>0)
        return kinetic,angle-angle[0]
    kinetic,phase=solve(.003);other,_=solve(.0015)
    init_error=np.linalg.norm((entry-alt)*[mass*match,1])/np.linalg.norm(entry*[mass*match,1])
    repeat=np.max(abs(kinetic-other))/np.max(abs(kinetic))
    assert max(init_error,repeat)<.005
    return kinetic,phase,entry,[mass,rho0,match,init_error,repeat]

def grid_of(src,grid):
    corners=np.asarray(src.corners)
    return np.unique(np.r_[grid,corners[(corners>grid[0])&(corners<grid[-1])]])

def sources(mode,sub):
    src,solver,grid,entry,_=make(mode,'matched',sub)
    cuts=grid_of(src,grid)
    kinetic,phase,osc,controls=launch(src,cuts)
    history=propagate(src,solver,cuts,entry)
    gravity=geom(src,solver,cuts,history)
    pack(f'absolute-{mode}-{sub}.npz',cuts=cuts,kinetic=kinetic,phase=phase,entry=osc,gravity=gravity,work=kinetic[:,None]*gravity,controls=controls,
         kk=src.kk,rho0=src.packet['rho0'])
    return dict(mode=mode,split=sub,field_at_switch=osc[0],velocity_at_switch=osc[1],periods=phase[-1]/np.pi,launch_order_error_pct=100*controls[-2],
                oscillator_repeat_pct=100*controls[-1])

if __name__=='__main__':
    rows=[sources(m,s) for m in MODES for s in (2,4)]
    table('switch-checks.csv',rows)
    freeze('raw-freeze.json',['PROTOCOL.md','kinetic_stage.py','dynamics.py','subtract.py','wave_score.py','photon_score.py','switch-checks.csv']+[f'absolute-{m}-{s}.npz' for m in MODES for s in (2,4)])
