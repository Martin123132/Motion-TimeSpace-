from pathlib import Path
import hashlib
import importlib.util
import json
import sys

ROOT = Path(__file__).resolve().parent
LAST = ROOT.parent / 'mts-photon-frozen-drift-cycles234-89p6-20261125'
LAST_HASH = '9d0f857e8618d2557a922c87653548b6c0692480042edb392a4f7e742e2f5bc9'
def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream,'sha256').hexdigest()
def retained(name):
    assert digest(LAST/'seal.json')==LAST_HASH
    assert digest(LAST/name)==json.loads((LAST/'seal.json').read_bytes())['files'][name]
    return LAST/name
retained('transfer_stage.py')
sys.path.insert(0,str(LAST))
import transfer_stage as common
common.ROOT = ROOT
common.PINS = {**common.PINS,LAST:LAST_HASH}
from transfer_stage import np, pinned, PAIR, ARCHIVE, guard, save, table, pack, freeze, locked, MODES, SETTINGS
CASES = [(mode,branch,sub) for mode in MODES for sub in (2,4) for branch in ('matched','wave')]
def tag(mode,branch,sub):
    return f'{mode}-{branch}-{sub}'
def guard_run():
    guard()
    assert not (ROOT/'seal.json').exists(), 'completed stage; do not relaunch'
def step_photons():
    guard_run()
    spec = importlib.util.spec_from_file_location('retained_photon_transfer',retained('predict.py'))
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    assert module.ROOT==ROOT
    module.photons()
if __name__=='__main__':
    assert sys.argv[1:] == ['photons']
    step_photons()
