import csv

from scipy.interpolate import CubicSpline
from partial_stage import ROOT, ARCHIVE, MODES, SETTINGS, CASES, tag, pinned, retained, np, table, locked, guard_run
from transfer_stage import angular
angular('angular_photons.py')
from angular_photons import gate
from cell89 import pin as original

def run():
    guard_run()
    locked('launch-freeze.json')
    locked('source-freeze.json')
    locked('prediction-freeze.json')
    with pinned(ARCHIVE,'raw-cycle-work.csv').open() as stream:
        boundaries = {(r['mode'],int(r['subdivision'])):r for r in csv.DictReader(stream) if r['kind']=='partial'}
    raw_tests = []
    for case in CASES:
        mode,branch,sub = case
        row = boundaries[mode,sub]
        assert row['cycle']=='5' and 0<float(row['phase_cycles'])<1
        with np.load(ROOT/('work-'+tag(*case)+'.npz')) as bank:
            assert bank['cuts'][0]==float(row['begin']) and bank['cuts'][-1]==float(row['end'])
            total = bank['total'].sum()
            refs = [('saved_endpoint',complex(float(row[branch+'_C_real']),float(row[branch+'_C_imag']))),
                    ('forecast_primitive',bank['primitive'].sum())]
        for key,value in refs:
            err = 100*abs(total-value)/abs(value)
            assert np.isfinite(err)
            raw_tests.append(dict(mode=mode,branch=branch,subdivision=sub,test=key,predicted_real=total.real,predicted_imag=total.imag,
                                  reference_real=value.real,reference_imag=value.imag,relative_pct=err,passes=bool(err<=.5)))
    table('raw-endpoints.csv',raw_tests)
    _,axis,weight,_ = gate.proj.old.get_media()
    measure = gate.previous.make_measure(axis,weight)
    def mag(vec):
        return gate.mag(vec,measure)
    def share(vec,ref):
        return 100*(measure@(vec*ref.conj()).real).sum()/mag(ref)[2]**2
    targets,checks,records,cache = [],[],[],{}
    def test(rows,mode,setting,kind,key,pred,ref):
        err = 100*mag(pred-ref)/mag(ref)
        assert np.isfinite(err).all()
        rows.append(dict(mode=mode,setting=setting,test=kind,channel=key,energy_error_pct=err[0],current_error_pct=err[1],
                         joint_error_pct=err[2],passes=bool(max(err)<=.5)))
    for setting in SETTINGS:
        name = f'photons-{setting}.npz'
        with np.load(ROOT/name) as new,np.load(pinned(ARCHIVE,name)) as saved,np.load(retained(name)) as previous,np.load(original(f'photon-{setting}.npz')) as origin:
            grid = new['scale']
            assert all(np.array_equal(grid,f['scale']) for f in (saved,previous)) and np.array_equal(grid,origin['grid'])
            for idx,mode in enumerate(MODES):
                def read(data):
                    assert data['modes'].tolist()==list(MODES)
                    vectors = CubicSpline(grid,data['values'][:,idx,0])(axis)
                    return dict(zip(data['channels'].tolist(),vectors.swapaxes(0,1),strict=True))
                pred,ref,drift = (read(data) for data in (new,saved,previous))
                norm = mag(CubicSpline(grid,origin['values'][:,origin['labels'].tolist().index([mode,'primary']),:3].sum(1))(axis))
                def record(kind,key,vec):
                    amp = 100*mag(vec)/norm
                    records.append(dict(mode=mode,setting=setting,source=kind,channel=key,energy_common_pct=amp[0],current_common_pct=amp[1],
                                        joint_common_pct=amp[2],signed_share_late_pct=share(vec,ref['late']),signed_share_partial_pct=share(vec,ref['partial'])))
                for prefix in ('','half_'):
                    def val(key):
                        return pred[prefix+key]
                    test(targets,mode,setting,'saved_partial',prefix+'partial',val('partial'),ref[prefix+'partial'])
                    for key,vec in [('branch_sum',val('matched')-val('wave')),('sector_sum',val('heavy_metric')+val('ordinary_given')),('primitive',val('primitive'))]:
                        test(checks,mode,setting,key,prefix+'partial',vec,val('partial'))
                for key in [k for k in pred if not k.startswith('half_')]:
                    cache[mode,setting,key] = pred[key]
                    test(checks,mode,setting,'subdivision',key,pred['half_'+key],pred[key])
                    record('predicted',key,pred[key])
                late = pred['partial']+drift['drift']
                for key,vec,goal in [('drift_plus_partial',late,ref['late']),('with_saved_osc',late+ref['osc'],ref['late']),
                                     ('with_saved_osc_and_first',ref['first']+late+ref['osc'],ref['full'])]:
                    test(targets,mode,setting,'context_reconstruction',key,vec,goal)
                    record('context',key,vec)
                for key in ('first','osc','partial','late','full'):
                    record('saved',key,ref[key])
    for mode in MODES:
        for key in ('partial','matched','wave','heavy_metric','ordinary_given','primitive'):
            for setting in ('time','angle'):
                test(checks,mode,'primary','photon_'+setting,key,cache[mode,setting,key],cache[mode,'primary',key])
            if mode=='p32':
                test(checks,mode,'primary','gravity',key,cache['p16','primary',key],cache[mode,'primary',key])
    for name,rows in [('comparisons.csv',targets),('checks.csv',checks),('readouts.csv',records)]:
        table(name,rows)
    print('rows and failures:',[(len(rows),sum(not row['passes'] for row in rows)) for rows in (raw_tests,targets,checks)])
if __name__=='__main__':
    run()
