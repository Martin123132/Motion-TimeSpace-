import ast
import csv
import sys
from partial_stage import ROOT, MODES, SETTINGS, CASES, PAIR, tag, pinned, np, freeze, locked, digest

def rows(name):
    with (ROOT/name).open() as stream:
        return list(csv.DictReader(stream))
def verify():
    for name in ('launch-freeze.json','source-freeze.json','prediction-freeze.json'):
        locked(name)
    for case in CASES:
        label = tag(*case)
        with np.load(ROOT/('launch-'+label+'.npz')) as launch,np.load(ROOT/('work-'+label+'.npz')) as work,np.load(pinned(PAIR,'prediction-'+label+'-cycle4.npz')) as parent:
            assert np.array_equal(parent['right_state'],launch['state']) and np.array_equal(launch['state'],work['left_state'])
            assert parent['right']==launch['left']==work['cuts'][0] and work['cuts'][-1]==89.6
            assert work['left_state'].shape==work['right_state'].shape==(90,) and np.isfinite(work['right_state']).all()
            assert np.all(np.diff(work['cuts'])>0) and np.array_equal(work['total'],work['pair']+work['other'])
    for mode in MODES:
        for sub in (2,4):
            with np.load(ROOT/f'source-{mode}-{sub}.npz') as source,np.load(ROOT/f'launch-{mode}-wave-{sub}.npz') as launch:
                active = source['knots'][:-1]>=launch['left']
                vals = source['values']
                assert active.any() and not np.any(vals[~active]) and (np.ptp(vals[active,0].real)>0)
                assert source['knots'][-1]==89.6 and np.isfinite(vals).all()
    for setting in SETTINGS:
        assert all(float(row['relative'])<=.005 for row in rows(f'quadrature-{setting}.csv'))
    for name,count in [('raw-endpoints.csv',16),('comparisons.csv',30),('checks.csv',102)]:
        observed = rows(name)
        assert len(observed)==count
        for row in observed:
            values = [float(row[key]) for key in row if key.endswith('error_pct') or key=='relative_pct']
            assert values and np.isfinite(values).all() and min(values)>=0 and (max(values)<=.5)==(row['passes']=='True')
    assert len(rows('readouts.csv'))==84
    for path in ROOT.glob('*.py'):
        ast.parse(path.read_text())
    assert not list(ROOT.rglob('__pycache__'))
    if '--seal' in sys.argv:
        assert (ROOT/'RESULTS.md').is_file()
        freeze('seal.json',sorted(p.name for p in ROOT.iterdir() if p.is_file() and p.name!='seal.json'))
        locked('seal.json')
        print(digest(ROOT/'seal.json'))
    print('launches, supports, receipts, comparisons and stage contents verified')
if __name__=='__main__':
    verify()
