from partial_stage import ROOT, PAIR, CASES, MODES, guard_run, tag, digest, pinned, pack, table, freeze, locked, np
import json
import sys

for name in ('energy_current.py','pair_stage.py'):
    pinned(PAIR,name)
sys.path.insert(0,str(PAIR))
from pair_stage import limits
from cycle3_inputs import make
from energy_current import integrate
from forecast_cycle3 import add
def launch():
    guard_run()
    rows = []
    receipt = json.loads(pinned(PAIR,'prediction-freeze.json').read_bytes())
    for mode,branch,sub in CASES:
        label = tag(mode,branch,sub)
        name = 'prediction-'+label+'-cycle4.npz'
        path = pinned(PAIR,name)
        assert receipt['files'][name]==digest(path)
        with np.load(path) as bank:
            state = bank['right_state']
            left = bank['right'].item()
        assert left==limits(mode,4)[1] and state.shape==(90,) and np.isfinite(state).all()
        pack('launch-'+label+'.npz',left=left,state=state)
        rows.append(dict(mode=mode,branch=branch,subdivision=sub,left=left,parent_file=name,parent_sha256=digest(path)))
    table('launches.csv',rows)
    freeze('launch-freeze.json',['PROTOCOL.md','partial_stage.py','predict_partial.py','score_partial.py','launches.csv']+
           ['launch-'+tag(*case)+'.npz' for case in CASES])
def evolve(mode,branch,sub):
    label = tag(mode,branch,sub)
    with np.load(ROOT/('launch-'+label+'.npz')) as bank:
        left,state = bank['left'].item(),bank['state']
    src,solver,grid,_,_ = make(mode,branch,sub)
    right = grid[-1]
    assert src.time[-1]==right==89.6 and grid[0]<left<right
    cuts,states,terms,primitive = integrate(src,solver,grid,left,right,state,branch=='wave')
    assert np.array_equal(states[0],state) and np.isfinite(states).all()
    assert len(cuts)>2 and cuts[0]==left and cuts[-1]==right and np.all(np.diff(cuts)>0)
    idx = np.searchsorted(grid,cuts[:-1],side='right')-1
    assert np.all(cuts[1:]<=grid[idx+1])
    den = src.environment(grid)[-1][idx+1]
    assert np.isfinite(den).all() and np.all(den>0)
    paired = terms[:,4]
    remainder = terms[:,0]+terms[:,3]
    raw = paired+remainder
    alt = np.sum(primitive,axis=1)
    scale = den*np.diff(cuts)
    rates = np.column_stack((raw,paired,remainder,alt))/scale[:,None]
    assert np.isfinite(rates).all()
    pack(f'work-{label}.npz',cuts=cuts,gravity=src.time,grid=grid,denominator=den,total=raw,
         pair=paired,other=remainder,primitive=alt,left_state=state,right_state=states[-1])
    return grid,src.time,cuts,rates
def sources():
    guard_run()
    locked('launch-freeze.json')
    for mode in MODES:
        for sub in (2,4):
            grids,axes,cuts,rates = zip(*(evolve(mode,branch,sub) for branch in ('matched','wave')))
            assert np.array_equal(grids[0],grids[1]) and np.array_equal(axes[0],axes[1])
            assert cuts[0][0]==cuts[1][0] and cuts[0][-1]==cuts[1][-1]
            knots = np.unique(np.r_[grids[0],cuts[0],cuts[1]])
            active = knots[:-1]>=cuts[0][0]
            carried = []
            for branch_cuts,bank in zip(cuts,rates):
                idx = np.searchsorted(branch_cuts,knots[:-1][active],side='right')-1
                assert np.all(knots[1:][active]<=branch_cuts[idx+1])
                val = np.zeros((len(active),bank.shape[1]),complex)
                val[active] = bank[idx]
                carried.append(val)
            matched,wave = carried
            diff = matched-wave
            values = np.column_stack((diff[:,0],matched[:,0],wave[:,0],diff[:,1],diff[:,2],diff[:,3]))
            assert not np.any(values[~active]) and np.isfinite(values).all()
            pack(f'source-{mode}-{sub}.npz',knots=knots,gravity=axes[0],values=values,
                 keys=['partial','matched','wave','heavy_metric','ordinary_given','primitive'])
    freeze('source-freeze.json',['launch-freeze.json']+['work-'+tag(*case)+'.npz' for case in CASES]+
           [f'source-{mode}-{sub}.npz' for mode in MODES for sub in (2,4)])
if __name__=='__main__':
    {'launch':launch,'sources':sources}[sys.argv[1]]()
