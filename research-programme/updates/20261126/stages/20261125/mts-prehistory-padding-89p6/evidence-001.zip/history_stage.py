from pathlib import Path
import hashlib,json,sys
ROOT=Path(__file__).resolve().parent
LAST=ROOT.parent/'mts-one-stress-response-89p6-20261125'
PRIOR='3b63aecca400c2f05e2dbb848b87619756e423d1db915741f09e3b94e3031de7'
def digest(path):
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
assert digest(LAST/'seal.json')==PRIOR
inputs=json.loads((LAST/'seal.json').read_bytes())['files']
def earlier(name):
    path=LAST/name;assert digest(path)==inputs[name],name
    return path
def guard():assert not any((p/'STOP-REQUESTED').exists() for p in (ROOT,ROOT.parent,LAST))
def freeze(name,files):
    guard();receipt=dict(prior=PRIOR,files={k:digest(ROOT/k) for k in files});path=ROOT/name
    if path.exists():assert json.loads(path.read_bytes())==receipt
    else:path.write_text(json.dumps(receipt,indent=2,sort_keys=True)+'\n')
def locked(name):
    receipt=json.loads((ROOT/name).read_bytes());assert receipt['prior']==PRIOR
    for k,h in receipt['files'].items():assert digest(ROOT/k)==h,k
sys.path.insert(0,str(LAST));earlier('one_stage.py')
from one_stage import pin as angular,MODES,SETTINGS
