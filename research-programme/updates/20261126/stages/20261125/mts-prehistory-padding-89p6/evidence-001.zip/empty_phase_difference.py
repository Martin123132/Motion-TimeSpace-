import numpy as np
from scipy.interpolate import CubicSpline
from scipy.integrate import solve_ivp
from scipy.special import roots_legendre
from inputs_density import kernel
def peak(values):return float(np.max(np.abs(values)))
def relative(values,reference):return peak(values-reference)/max(peak(reference),1e-90)
def build_prehistory(mode,src):
    clock,curves,kk,_,rho=kernel.read(mode)
    packet=src.packet;eta=packet['eta'];start=src.time[0];edge=src.corners[0];period=np.pi
    assert kk==src.kk and rho==packet['rho0'] and abs(clock(start))<1e-10 and abs(clock(edge)-period)<1e-9
    original=curves['j'];nodes=original.x;sel=nodes[(nodes<0)&(nodes> -period-.25)]
    assert sel[0]<-period and len(sel)>50
    phases=np.r_[sel,0.];entry=original(0.)[0]
    current=CubicSpline(phases,original(phases)[:,0]-entry,extrapolate=False)
    rate=CubicSpline(phases,curves['wj_phase'](phases)[:,0],extrapolate=False)
    area=current.antiderivative();work=rate.antiderivative()
    with np.load(kernel.stage.pin('matched-native/linear-heavy-00.npz')) as saved:
        hub=CubicSpline(saved['eta'],saved['values'][0,:,saved['keys'].tolist().index('adotoa')])
    def differences(t):
        theta=np.clip(clock(t),0,period);lower=theta-period
        dj=(area(0)-area(lower))/period
        factor=clock(t,1)/period
        dj=np.where(theta<period,dj,0j)
        rates=np.stack((factor*(work(0)-work(lower)),factor*(current(0.)-current(lower))),axis=-1)
        pressure=(rates+np.asarray(hub(t)*dj)[...,None])/kk
        return dj,rates,pressure
    reference,weights=roots_legendre(96);probes=np.linspace(start,edge,97)
    lo=np.clip(clock(probes),0,period)-period
    integral=(-lo/2/period)*(current(lo[:,None]*(1-reference)/2)@weights)
    dj,rates,pressure=differences(probes);area_error=relative(dj,integral);rate_error=relative(rates[:,0],rates[:,1])
    assert max(area_error,rate_error)<.005,(area_error,rate_error)
    dj0=complex(differences(start)[0]);scale=max(peak(dj),peak(pressure))
    def density_rhs(t,state):
        dj,_,dp=differences(t);return (-dj-3*hub(t)*dp)/scale
    def integrate(div):
        sol=solve_ivp(density_rhs,(start,edge),np.zeros(2,complex),method='DOP853',rtol=4e-11,atol=2e-16,dense_output=True,max_step=(edge-start)/div)
        assert sol.success
        return sol.sol(np.clip(eta,start,edge)).T*scale
    density=integrate(96);density_check=relative(integrate(48),density);assert density_check<.005
    dj,rates,dp=differences(eta)
    pres_res=dp-packet['cs2'][:,None]*(density+3*hub(eta)[:,None]*dj[:,None]/kk)
    splines=[]
    for left,right in zip(np.r_[-np.inf,src.corners],np.r_[src.corners,np.inf]):
        interior=(eta>=left+5e-9)&(eta<=right-5e-9);splines.append(CubicSpline(eta[interior],pres_res[interior]))
    def forcing(t,side):
        loc=np.searchsorted(src.corners,side,side='right');out=np.empty((len(t),2),complex)
        for idx,curve in enumerate(splines):
            which=loc==idx;out[which]=curve(t[which])
        return out
    after=eta>edge+1e-8
    assert peak(dj[after])==0 and peak(dp[after])==0 and peak(density[after]-density[-1])==0
    return dj0,forcing,dict(start=start,edge=edge,pre_knots=len(phases),first_phase=phases[0],phase_quadrature=area_error,force_rate_vs_endpoints=rate_error,density_time_refinement=density_check,entry_current_abs=abs(dj0),entry_current_fraction=abs(dj0)/abs(entry),post_density_memory_abs=abs(density[-1,0])),dict(eta=eta,current=dj,pressure=dp,density=density,residual=pres_res)
