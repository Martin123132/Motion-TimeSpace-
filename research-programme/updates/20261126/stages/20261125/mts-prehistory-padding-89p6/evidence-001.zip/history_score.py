from history_stage import ROOT,MODES,SETTINGS,angular,earlier,guard,locked
from angular_photons import gate,io,np
from cell89 import pin as legacy
from scipy.interpolate import CubicSpline
import csv
def score():
    guard()
    for rec in ('source-freeze.json','photon-freeze.json','control-freeze.json'):locked(rec)
    io.ROOT=ROOT;_,axis,w,_=gate.proj.old.get_media();measure=gate.previous.make_measure(axis,w);mag=lambda v:gate.mag(v,measure)
    with gate.pin(gate.FROZEN,'window-readouts.csv').open() as stream:
        launch={r['gravity']:float(r['launch_norm']) for r in csv.DictReader(stream) if r['model']=='MTS-minus-baseline' and r['output']=='joint'}
    gates=[];windows=[];tests=[];store={}
    def check(m,s,label,trial,ref):
        frac=100*mag(trial-ref)/mag(ref);assert np.isfinite(frac).all()
        tests.append(dict(mode=m,setting=s,check=label,energy=frac[0],current=frac[1],joint=frac[2],passes=bool(max(frac)<=.5)))
    for s in SETTINGS:
        name=f'photons-{s}.npz'
        with np.load(ROOT/name) as result,np.load(ROOT/'control'/name) as control,np.load(angular(name)) as angular_ref,np.load(earlier(name)) as stress,np.load(legacy(f'photon-{s}.npz')) as origin,np.load(ROOT/f'launch-change-{s}.npz') as physical:
            grid=result['scale'];assert all(np.array_equal(grid,f['scale']) for f in (control,angular_ref,stress,physical)) and np.array_equal(grid,origin['grid'])
            view=lambda v:CubicSpline(grid,v)(axis)
            for i,m in enumerate(MODES):
                def unpack(f):return dict(zip(f['channels'].tolist(),view(f['values'][:,i,0]).swapaxes(0,1)))
                pred=unpack(result);ctl=unpack(control);old=unpack(angular_ref)['live']+unpack(stress)['effect'];new=old+pred['total']
                orig=view(origin['values'][:,origin['labels'].tolist().index([m,'primary']),:3].sum(1));den=mag(orig)
                def phys(key):return view(physical['values'][:,physical['labels'].tolist().index([m,key])])
                launch_delta=phys('primary').sum(1);new_momentum=orig+launch_delta
                sm=100*mag(new_momentum)[2]/launch[m];sd=100*mag(new_momentum+new)[2]/launch[m];frac=100*mag(new)/den;delta=100*mag(pred['total'])/den
                gates.append(dict(mode=m,setting=s,control_joint=100*mag(old)[2]/den[2],energy=frac[0],current=frac[1],joint=frac[2],change_norm=delta[2],passes=bool(max(frac)<=.5),momentum_launch_pct=sm,differentiated_launch_pct=sd,launch_pass=bool(max(sm,sd)<.163)))
                for name1,total,parts in [('control',old,[ctl['early'],ctl['late']]),('prehistory',new,[ctl['early']+pred['early'],ctl['late']+pred['late']]),('change',pred['total'],[pred['early'],pred['late']]),('origin_of_change',pred['total'],[pred['entry'],pred['forced']])]:
                    check(m,s,name1+'_sum',sum(parts),total)
                    for key,vec in zip(('entry','forcing') if name1=='origin_of_change' else ('first_cycle','later'),parts):
                        shares=np.sum(measure@(vec*total.conj()).real)/mag(total)[2]**2
                        windows.append(dict(mode=m,setting=s,case=name1,component=key,joint_common_pct=100*mag(vec)[2]/den[2],signed_percent_of_total=100*shares))
                for key in ('total','early','late','entry','forced'):
                    check(m,s,'subdivision_'+key,pred['half_'+key],pred[key])
                check(m,s,'endpoint_rate',pred['endpoint'],pred['total'])
                check(m,s,'source_control_replay',ctl['control'],old);check(m,s,'physical_subdivision',phys('half').sum(1),launch_delta)
                store[m,s]=(new,pred['total'],launch_delta)
    for m in MODES:
        for i,key in enumerate(('gap','change','physical')):
            for mo,st,tag in [(m,'time','photon_time'),(m,'angle','angle')]+([('p16','primary','gravity')] if m=='p32' else []):
                check(m,'primary',key+'_'+tag,store[mo,st][i],store[m,'primary'][i])
    for filename,data in [('gates',gates),('windows',windows),('checks',tests)]:io.table(filename+'.csv',data)
    print([r for r in gates if r['setting']=='primary']);print('failed numerical controls',[r for r in tests if not r['passes']])
if __name__=='__main__':score()
