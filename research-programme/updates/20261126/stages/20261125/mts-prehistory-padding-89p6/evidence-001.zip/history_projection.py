from history_stage import ROOT,MODES,SETTINGS,earlier,angular,guard,locked,freeze
angular('angular_photons.py')
from angular_photons import transport,io,np
from types import SimpleNamespace
from unittest.mock import patch
import sys
def spread(axis,grid,impulses):
    idx=np.searchsorted(grid,axis[:-1],side='right')-1
    assert grid[0]==axis[0] and grid[-1]==axis[-1] and np.all(axis[1:]<=grid[idx+1])
    return (impulses/np.diff(grid)[:,None])[idx]
def packet(mode,unused,control):
    with np.load(ROOT/f'prediction-{mode}-4.npz') as pred,np.load(ROOT/f'prediction-{mode}-2.npz') as half:
        grid=pred['grid'];gravity=pred['gravity'];edge=pred['edge'].item()
        if not control:
            keys=pred['channels'].tolist()
            vals=np.column_stack((spread(grid,grid,pred['values']),spread(grid,half['grid'],half['values'])))
            keys+=['half_'+k for k in keys]
        else:
            with np.load(angular(f'angular-{mode}-4.npz')) as old,np.load(earlier(f'impulses-{mode}-4.npz')) as stress:
                base=old['grid'];assert np.array_equal(base,stress['grid'])
                live=old['values'][:,old['channels'].tolist().index('live')]
                feedback=stress['values'][:,stress['channels'].tolist().index('effect')]
                total=spread(grid,base,(live+feedback)[:,None])[:,0];early=total*(grid[1:]<=edge)
                keys=['control','early','late'];vals=np.column_stack((total,early,total-early))
        return SimpleNamespace(time=gravity,knots=grid,values=vals,keys=keys),None
def project(control):
    guard();files=['history_stage.py','empty_phase_difference.py','predict.py','history_projection.py','history_score.py','PROTOCOL.md']
    for m in MODES:
        files.append(f'preparation-{m}.npz')
        for n in (2,4):files.extend([f'prediction-{m}-{n}.npz',f'check-{m}-{n}.json',f'metric-{m}-{n}.npz'])
    if not control:freeze('source-freeze.json',files)
    locked('source-freeze.json')
    if control:locked('photon-freeze.json')
    dest=ROOT/'control' if control else ROOT
    if control:dest.mkdir(exist_ok=True)
    io.ROOT=dest
    with patch.object(transport,'ROOT',dest),patch.object(transport,'source',lambda m,b:packet(m,b,control)):
        for setting in SETTINGS:transport.project(setting)
    prefix='control/' if control else ''
    outputs=[prefix+f'photons-{s}.npz' for s in SETTINGS]
    if not control:
        gate=transport.gate;scale,eta,medium,_,_=gate.proj.measure('heavy');hist={}
        with np.load(io.old.pin('photon-accumulated-heavy.npz')) as meta:wave=float(meta['k'])
        for mode in MODES:
            for key,split in (('primary',4),('half',2)):
                with np.load(ROOT/f'metric-{mode}-{split}.npz') as f:hist[mode,key]=dict(f.items())
        with patch.object(gate.transfer,'ps',gate.Interface()):
            for setting in SETTINGS:
                values=gate.transfer.transfer(setting,eta,scale,medium,wave,hist)
                name=f'launch-change-{setting}.npz';io.pack(name,scale=scale,labels=list(hist),values=values[:,:,:3]);outputs.append(name)
        outputs.append('photon-adjoint.csv')
    freeze('control-freeze.json' if control else 'photon-freeze.json',['photon-freeze.json' if control else 'source-freeze.json']+outputs)
if __name__=='__main__':project('--control' in sys.argv)
