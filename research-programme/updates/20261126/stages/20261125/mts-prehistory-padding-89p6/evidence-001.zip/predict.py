from history_stage import ROOT,MODES,angular,guard,earlier
angular('release.py');angular('angular_operator.py')
from release import Drivers,Blind,forms,io,subgrid
from angular_operator import operator,IX,QI,QN,DIM
from empty_phase_difference import build_prehistory,np,peak,relative
from unittest.mock import patch
import sys
io.ROOT=ROOT
def evolve(src,grid,edge,delta_current,pressure):
    solver=Blind(src);env=src.environment(grid[:1]);hub=env[0]['h'][0];den=env[-1][0];rho=env[-2][0]
    state=np.zeros((DIM,5),complex)
    delta_phi=-1.5*hub*rho*delta_current/(src.kk*(den-1.5*rho))
    for col in (0,1,3):
        state[IX['geom'],col]=delta_phi;state[IX['hf'],col]=-3*delta_phi;state[IX['hw'],col]=delta_current
    energy,curr=solver.aggregate(env,state[None,:12,0],False)
    entry_work=den*delta_phi+energy[0]/2+1.5*hub*curr[0]/src.kk
    closure=abs(entry_work)/abs(den*delta_phi)
    assert closure<1e-12 and state[IX['hf'],0]+3*delta_phi==0
    entry=state[:,0].copy();bounds=np.asarray(src.corners)
    cuts=np.unique(np.r_[grid,bounds[(bounds>grid[0])&(bounds<grid[-1])]])
    ixedge=np.searchsorted(cuts,edge);assert cuts[ixedge]==edge
    changes=[];history=[state[:13].copy()];quads=[state[[QI,QN],0].copy()]
    with patch.object(src,'quads',lambda t:np.zeros((len(t),2),complex)):
        for offset in range(0,len(cuts)-1,40):
            guard();stop=min(offset+40,len(cuts)-1);left=cuts[offset:stop];right=cuts[offset+1:stop+1];width=right-left;side=(left+right)/2
            ops=[];loads=[]
            for t in (left,left+width/3,right-width/3,right):
                mat,bi,bn=operator(solver,t,side);mat[:,:13,QI]+=bi;mat[:,:13,QN]+=bn;ops.append(mat[:,:,:DIM])
                force=pressure(t,side);drive=np.zeros((len(t),DIM,5),complex)
                amp=force[:,[0,0,0,1,0]].copy();amp[:,[1,4]]=0
                hh=src.flow.bg(np.log(t))[:,src.flow.bgkeys.index('h')]
                drive[:,IX['hf']]=-3*hh[:,None]*amp;drive[:,IX['hw']]=src.kk*amp;loads.append(drive)
            for j,dt in enumerate(width):
                def rhs(level,x):return ops[level][j]@x+loads[level][j]
                aa=rhs(0,state);bb=rhs(1,state+dt*aa/3);cc=rhs(2,state+dt*(bb-aa/3));dd=rhs(3,state+dt*(aa-bb+cc))
                inc=dt*(aa+3*bb+3*cc+dd)/8;state+=inc;changes.append(inc[:13].copy());history.append(state[:13].copy());quads.append(state[[QI,QN],0].copy())
    grid=np.unique(np.r_[grid,edge]);idx=np.searchsorted(cuts,grid);low=np.asarray(history)[idx];dx=np.add.reduceat(np.array(changes),idx[:-1],axis=0)
    assert peak(low[:,:,4])==0 and relative(low[:,:,0],low[:,:,1]+low[:,:,2])<1e-10
    coeff,_,denoms=forms(src.environment(grid),src.kk,src.wave,False)
    work=np.einsum('ntk,nkc->nc',coeff[1:],dx)+np.einsum('ntk,nkc->nc',np.diff(coeff,axis=0),low[:-1])
    independent=np.diff(np.einsum('ntk,nkc->nc',coeff,low),axis=0)
    work_check=relative(independent,work);assert work_check<.005
    impulses=-work/denoms[1:,None];total,entry_only,forced,endpoint,_=impulses.T
    early=total*(grid[1:]<=edge)
    indices=np.searchsorted(grid,src.time);angulars=np.asarray(quads)[idx[indices]]
    background=src.environment(src.time);bg=background[0];phys=low[indices,:,0]
    psi=phys[:,-1]-(bg['eg']*angulars[:,0]+(4*bg['er']+bg['nuS'])*angulars[:,1])/src.kk
    _,flow_current=solver.aggregate(background,phys[:,:12],False)
    pd=flow_current/(2*src.kk)-bg['h']*psi
    return grid,np.column_stack((total,early,total-early,entry_only,forced,endpoint)),dict(entry_constraint=float(closure),entry_phi_abs=abs(delta_phi),entry_phi_real=delta_phi.real,entry_phi_imag=delta_phi.imag,entry_phidot_abs=abs(rho*delta_current/(2*src.kk)-hub*delta_phi),work_check=work_check),entry,dict(eta=src.time,delta_pd=pd,delta_psi=psi,delta_differentiated=pd,kick=delta_phi)
def build(mode):
    src=Drivers(mode);dj,pressure,checks,history=build_prehistory(mode,src)
    io.pack(f'preparation-{mode}.npz',**history)
    for split in (2,4):
        with np.load(angular(f'angular-{mode}-{split}.npz')) as prior:
            grid=prior['grid'];assert np.array_equal(grid,subgrid(src.time,split))
            original=prior['matched_entry']
        grid,vals,diag,entry,metric=evolve(src,grid,checks['edge'],dj,pressure)
        io.pack(f'metric-{mode}-{split}.npz',**metric)
        diag.update(checks);diag['entry_phi_fraction']=abs(entry[IX['geom']]/original[IX['geom']])
        io.pack(f'prediction-{mode}-{split}.npz',grid=grid,gravity=src.time,channels=['total','early','late','entry','forced','endpoint'],values=vals,entry_change=entry,edge=checks['edge'])
        io.record(f'check-{mode}-{split}.json',diag);print(mode,split,diag,flush=True)
if __name__=='__main__':
    for mode in sys.argv[1:] or MODES:build(mode)
