from history_stage import ROOT,MODES,SETTINGS,digest,guard,freeze,locked
import ast,csv,json,numpy as np
def rows(f):
    with (ROOT/f).open() as stream:return list(csv.DictReader(stream))
def verify():
    guard()
    for rec in ('source-freeze.json','photon-freeze.json','control-freeze.json'):locked(rec)
    g=rows('gates.csv');assert len(g)==6
    for row in g:
        assert (max(float(row[k]) for k in ('energy','current','joint'))<=.5)==(row['passes']=='True')
        assert (max(float(row[k]) for k in ('momentum_launch_pct','differentiated_launch_pct'))<.163)==(row['launch_pass']=='True')
    checks=rows('checks.csv')
    for row in checks:
        assert (max(float(row[k]) for k in ('energy','current','joint'))<=.5)==(row['passes']=='True')
    windows=rows('windows.csv');assert len(windows)==48
    for m in MODES:
        for s in SETTINGS:
            for group in ('control','prehistory','change','origin_of_change'):
                shares=[float(r['signed_percent_of_total']) for r in windows if (r['mode'],r['setting'],r['case'])==(m,s,group)]
                assert len(shares)==2 and abs(sum(shares)-100)<.5
        for n in (2,4):
            r=json.loads((ROOT/f'check-{m}-{n}.json').read_bytes())
            assert max(r[k] for k in ('phase_quadrature','force_rate_vs_endpoints','density_time_refinement','entry_constraint','work_check'))<.005
            with np.load(ROOT/f'prediction-{m}-{n}.npz') as f:
                grid=f['grid'];early=grid[1:]<=r['edge'];values=f['values'];assert np.isfinite(values).all()
                assert not values[early,2].any() and not values[~early,1].any()
                assert np.array_equal(values[:,0],values[:,1]+values[:,2])
    adj=rows('photon-adjoint.csv');assert len(adj)==12 and all(float(r['relative'])<=.005 for r in adj)
    for s in SETTINGS:
        for prefix in ('','control/'):
            quad=rows(prefix+f'quadrature-{s}.csv');assert len(quad)==2 and all(float(r['relative'])<.005 for r in quad)
    for script in ROOT.glob('*.py'):ast.parse(script.read_text())
    assert not list(ROOT.rglob('__pycache__'))
    freeze('seal.json',sorted(p.relative_to(ROOT).as_posix() for p in ROOT.rglob('*') if p.is_file() and p.name!='seal.json'))
    print('numerical checks',len(checks),'passed',sum(r['passes']=='True' for r in checks),'seal',digest(ROOT/'seal.json'))
if __name__=='__main__':verify()
