from types import SimpleNamespace
from unittest.mock import patch
from angular_stage import ROOT,MODES,SETTINGS,guard,locked,freeze
from angular_photons import transport,io,np
def packet(mode,unused):
    with np.load(ROOT/f'response-{mode}-4.npz') as fine,np.load(ROOT/f'response-{mode}-2.npz') as half:
        grid=fine['grid'];cols={'effect':fine['values'][:,0]/np.diff(grid)}
        assert np.array_equal(grid[::2],half['grid'])
        for i,k in enumerate(fine['channels'].tolist()):
            cols[k]=fine['values'][:,i]/np.diff(grid)
            cols['half_'+k]=np.repeat(half['values'][:,i]/np.diff(half['grid']),2)
        return SimpleNamespace(time=fine['gravity'],knots=grid,values=np.column_stack(list(cols.values())),keys=list(cols)),None
if __name__=='__main__':
    guard();locked('response-freeze.json');dest=ROOT/'response';dest.mkdir(exist_ok=True);io.ROOT=dest
    with patch.object(transport,'ROOT',dest),patch.object(transport,'source',packet):
        for s in SETTINGS:transport.project(s);print(s,flush=True)
    freeze('response-photon-freeze.json',['response-freeze.json']+['response/photons-'+s+'.npz' for s in SETTINGS])
