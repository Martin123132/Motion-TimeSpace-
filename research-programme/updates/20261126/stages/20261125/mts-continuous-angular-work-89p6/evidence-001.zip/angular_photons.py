from angular_stage import ROOT,pin,guard,locked,freeze,SETTINGS
from types import SimpleNamespace
from unittest.mock import patch
pin('photons.py')
from photons import io,transport,gate,np
io.ROOT=ROOT
def packet(mode,unused):
    with np.load(ROOT/f'angular-{mode}-4.npz') as fine,np.load(ROOT/f'angular-{mode}-2.npz') as half:
        grid=fine['grid'];assert np.array_equal(grid[::2],half['grid']);cols={}
        for i,k in enumerate(fine['channels'].tolist()):
            cols[k]=fine['values'][:,i]/np.diff(grid)
            if k in ('live','fixed','effect','photon_effect','collisionless_effect','interaction'):
                cols['half_'+k]=np.repeat(half['values'][:,i]/np.diff(half['grid']),2)
        return SimpleNamespace(time=fine['gravity'],knots=grid,values=np.column_stack(list(cols.values())),keys=list(cols)),None
if __name__=='__main__':
    guard();locked('source-freeze.json')
    with patch.object(transport,'ROOT',ROOT),patch.object(transport,'source',packet):
        for s in SETTINGS:transport.project(s);print(s,flush=True)
    freeze('photon-freeze.json',['source-freeze.json']+[f'photons-{s}.npz' for s in SETTINGS])
