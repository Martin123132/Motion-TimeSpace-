from angular_stage import ROOT,SEAL,MODES,SETTINGS,guard,locked,save,freeze,digest
import numpy as np
import csv,json,ast,re
def rows(name):
    with (ROOT/name).open() as stream:return list(csv.DictReader(stream))
def verify():
    guard()
    for name in ('source-freeze.json','photon-freeze.json','response-freeze.json','response-photon-freeze.json'):locked(name)
    for mode in MODES:
        with np.load(ROOT/f'angular-{mode}-4.npz') as a,np.load(ROOT/f'angular-{mode}-2.npz') as b,np.load(ROOT/f'response-{mode}-4.npz') as c:
            assert np.array_equal(a['grid'][::2],b['grid']) and np.array_equal(a['grid'],c['grid'])
            assert np.array_equal(a['grid'][::4],a['gravity'])
            assert len(a['state_keys'])==90 and len(set(a['state_keys']))==90
            for label in ('matched','wave'):
                assert a[label+'_quads'].shape==(len(a['grid']),2)
                assert np.array_equal(a[label+'_entry'],b[label+'_entry']) and np.isfinite(a[label+'_final']).all()
                assert np.max(abs(np.diff(a[label+'_quads'],axis=0)))>0
            assert np.isfinite(a['values']).all() and np.isfinite(c['values']).all()
    p=rows('precision.csv');d=rows('response-precision.csv');g=rows('gates.csv');o=rows('operator-and-work.csv');q=rows('quadrupole-trajectories.csv')
    assert (len(p),len(g),len(o),len(q))==(108,36,16,8)
    for r in p+d:
        assert r['passes']==str(max(float(r[k+'_pct']) for k in ('energy','current','joint'))<=.5)
    for r in g:
        assert r['component_pass']==str(max(float(r[k+'_pct']) for k in ('energy','current','joint'))<=.5)
        assert r['launch_pass']==str(max(float(r[k+'_launch_pct']) for k in ('momentum','differentiated'))<.163)
    assert all(r['passes']=='True' and float(r['relative'])<=.005 for r in o)
    assert all(r['precision_pass']==str(float(r['refinement_pct'])<=.5) for r in q)
    assert len(rows('response-terms.csv'))==36
    audit=json.loads((ROOT/'input-feedback-checks.json').read_bytes());assert len(audit)==4
    assert all(r['live_unchanged_under_prescribed_poison'] and r['held_live_feedback_selective'] for r in audit)
    for setting in SETTINGS:
        for prefix in ('','response/'):
            qr=rows(prefix+'quadrature-'+setting+'.csv')
            assert len(qr)==2 and all(float(r['relative'])<=.005 for r in qr)
    for script in ROOT.glob('*.py'):ast.parse(script.read_text(encoding='utf8'))
    assert not list(ROOT.rglob('__pycache__'))
    for name in re.findall(r'\]\(([^)]+)\)',(ROOT/'RESULTS.md').read_text(encoding='utf8')):assert (ROOT/name).is_file()
    save('validation.json',dict(prior=SEAL,primary_checks=sum(r['kind']=='primary' for r in p),primary_passed=sum(r['kind']=='primary' and r['passes']=='True' for r in p),operator_and_work_passed=len(o),direct_effect_checks_failed=sum(r['kind']=='small' and r['passes']=='False' for r in p),response_comparisons_failed=sum(r['passes']=='False' for r in d),live_rate_passes=sum(r['case']=='live' and r['component_pass']=='True' for r in g),live_size_passes=sum(r['case']=='live' and r['launch_pass']=='True' for r in g),prediction=digest(ROOT/'photon-freeze.json'),supplement=digest(ROOT/'response-photon-freeze.json')))
    freeze('seal.json',sorted(p.relative_to(ROOT).as_posix() for p in ROOT.rglob('*') if p.is_file() and p.name!='seal.json'))
    print(digest(ROOT/'seal.json'))
if __name__=='__main__':verify()
