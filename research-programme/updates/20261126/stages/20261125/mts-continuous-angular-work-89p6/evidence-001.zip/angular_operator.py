from angular_stage import pin
pin('carry.py')
from carry import np,Blind,Wave,forms
from required_u import KEYS
from scipy.interpolate import CubicSpline
from zipfile import ZipFile
from numpy.lib import format as fmt
LOW=(*KEYS,'geom')
HIGH=tuple(f'{s}{j}' for s in 'IE' for j in range(2,7))+tuple(f'N{j}' for j in range(2,69))
NAMES=(*LOW,*HIGH);IX={k:i for i,k in enumerate(NAMES)};DIM=len(NAMES)
QI=IX['I2'];QN=IX['N2']
def switch_levels(path,mode_time,native):
    with np.load(path) as data:
        keys=data['keys'].tolist();axis=data['eta'];cols=[keys.index(k) for k in HIGH]
        if native:return CubicSpline(axis,data['states'][:,cols],extrapolate=False)(mode_time)
        assert axis[0]==mode_time
    with ZipFile(path) as bank,bank.open('states.npy') as member:
        assert fmt.read_magic(member)==(1,0)
        shape,order,dtype=fmt.read_array_header_1_0(member);assert not order and shape==(len(axis),len(keys))
        return np.frombuffer(member.read(len(keys)*dtype.itemsize),dtype=dtype)[cols]
def operator(solver,t,side):
    src=solver.src;env=list(solver.env(t,side));bg,forcing,_,_,_,_,_,_=env
    assert 'U' not in forcing and src.flow.phot==6 and src.flow.limit==68 and src.flow.wall is None
    num=len(t);zero=np.zeros((num,13),complex);env[4]=np.zeros((2,num),complex)
    bias=solver.rhs(env,zero);mat=np.zeros((num,DIM,DIM+1),complex);mat[:,:13,-1]=bias
    for j in range(13):
        trial=zero.copy();trial[:,j]=1
        mat[:,:13,j]=solver.rhs(env,trial)-bias
    couplings=[]
    for idx in (0,1):
        env[4][:]=0;env[4][idx]=1
        couplings.append(solver.rhs(env,zero)-bias)
    rate=bg['opacity'];k=src.wave;ratio=bg['eb']/bg['eg'];stream=src.flow.drive(np.log(t))[:,:,0]
    assert stream.shape==(num,69)
    for sp in 'IE':
        for ell in range(2,7):
            key=f'{sp}{ell}';row=IX[key];div=2*ell+1
            if ell>2:mat[:,row,IX[f'{sp}{ell-1}']]=k*ell/div
            elif sp=='I':
                baryon=4/(3*(ratio+4/3))
                mat[:,row,IX['W']]=2*baryon/5;mat[:,row,IX['B']]=2*(1-baryon)/5
            if ell<6:
                upper=(ell+1 if sp=='I' else (ell+3)*(ell-1)/(ell+1))/div
                mat[:,row,IX[f'{sp}{ell+1}']]=-k*upper
            mat[:,row,row]-=rate
            if ell==2:
                mat[:,row,QI]+=.1*rate;mat[:,row,IX['E2']]+=.6*rate
                mat[:,row,-1]=forcing['L2' if sp=='I' else 'Le']+rate*(forcing['C'+sp+'kin']+forcing['C'+sp+'rate'])
            else:mat[:,row,-1]=forcing[key+':net']
    for ell in range(2,69):
        row=IX[f'N{ell}'];mat[:,row,IX[f'N{ell-1}']]=k*ell/(2*ell+1)
        if ell<68:mat[:,row,IX[f'N{ell+1}']]=-k*(ell+1)/(2*ell+1)
        mat[:,row,-1]=stream[:,ell]
    return mat,*couplings
def rate_at(op,index,x,prescribed):
    mat,photon,collisionless=op;v=mat[index]@x
    iv=x[QI].copy();nv=x[QN].copy()
    iv[[1,3]]=prescribed[0];nv[[1,2]]=prescribed[1]
    v[:13]+=photon[index,:,None]*iv+collisionless[index,:,None]*nv
    return v
def verify_operator(src,solver,entry,t,matrices):
    mat,photon,collisionless=matrices;flow=src.flow;hix=[flow.ix[k] for k in HIGH];results=[]
    for i,eta in enumerate(t):
        for test in (entry,entry+1e-6*(np.sin(np.arange(DIM)+.2)+1j*np.cos(np.arange(DIM)*.71))):
            phys=np.zeros((flow.n,1,1),complex)
            for j,name in enumerate(NAMES):phys[flow.ix[name],0,0]=test[j]
            scale=flow.factors*eta**flow.power[:,None,None];yy=phys/scale
            full=flow.jac_rhs(np.log(eta),yy,1.)
            converted=((full+flow.power[:,None,None]*yy)*scale/eta)[:,0,0]
            actual=mat[i]@np.r_[test,1]
            env=list(solver.env(t[i:i+1]));env[4]=test[[QI,QN],None]
            low=solver.rhs(env,test[None,:13])[0];actual[:13]+=photon[i]*test[QI]+collisionless[i]*test[QN]
            for a,b in [(actual[:13],low),(actual[13:23],converted[hix[:10]]),(actual[23:],converted[hix[10:]])]:
                results.append(np.max(abs(a-b))/max(np.max(abs(b)),1e-85))
            if test is not entry:
                results.append(np.max(abs(actual[13:]-converted[hix])/np.maximum(abs(converted[hix]),1e-19)))
    worst=float(max(results));assert worst<.005,worst
    return worst
