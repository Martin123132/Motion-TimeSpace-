from angular_stage import ROOT,MODES,locked,guard,save
from angular_operator import DIM,QI,QN,operator,rate_at,Blind,Wave,np
from carry import Drivers,source
from unittest.mock import patch
import hashlib
def signature(src,t):
    env=src.environment(t);h=hashlib.sha256()
    for key in sorted(env[1]):
        h.update(key.encode());h.update(np.ascontiguousarray(env[1][key]).tobytes())
    for item in (t,env[2],src.flow.drive(np.log(t))):
        h.update(np.ascontiguousarray(item).tobytes())
    return h.hexdigest()
def check():
    guard();locked('source-freeze.json');records=[]
    for mode in MODES:
        with np.load(ROOT/f'angular-{mode}-4.npz') as saved:
            for label,src in [('matched',Drivers(mode)),('wave',source(mode))]:
                t=src.time;clock=t[[0,len(t)//2,-1]]
                original=signature(src,t);entry=saved[label+'_entry'];solver=(Wave if label=='wave' else Blind)(src)
                with patch.object(src,'quads',lambda locations:np.zeros((len(locations),2),complex)):
                    assert signature(src,t)==original
                    data=operator(solver,clock,clock)
                state=np.tile(np.r_[entry,1][:,None],(1,4))
                for i in range(len(clock)):
                    given=entry[[QI,QN]]
                    rate=rate_at(data,i,state,given)
                    poisoned=rate_at(data,i,state,np.array([np.nan,np.nan]))
                    assert np.array_equal(rate[:,0],poisoned[:,0]) and not np.isfinite(poisoned[:13,1]).all()
                    for idx,case in ((QI,2),(QN,3)):
                        trial=state.copy();trial[idx]+=1
                        change=rate_at(data,i,trial,given)-rate
                        assert np.max(abs(change[:13,0]))>0 and np.allclose(change[:13,0],change[:13,case],atol=0,rtol=1e-14)
                        assert np.max(abs(change[:13,1]))==0.
                records.append(dict(mode=mode,branch=label,forcing_stress_drive_sha256=original,gravity_samples=len(t),live_unchanged_under_prescribed_poison=True,held_live_feedback_selective=True))
    save('input-feedback-checks.json',records)
if __name__=='__main__':check()
