from angular_stage import ROOT,MODES,SETTINGS,guard,locked
from angular_photons import gate,io,np
from scipy.interpolate import CubicSpline
from cell89 import pin as legacy
io.ROOT=ROOT
def run():
    _,axis,w,_=gate.proj.old.get_media();measure=gate.previous.make_measure(axis,w)
    mag=lambda v:gate.mag(v,measure)
    terms=[];checks=[];cache={}
    def check(m,s,k,test,est,truth):
        norm=mag(truth);assert min(norm)>0;rel=100*mag(est-truth)/norm
        checks.append(dict(mode=m,setting=s,term=k,check=test,energy_pct=rel[0],current_pct=rel[1],joint_pct=rel[2],passes=bool(max(rel)<=.5)))
    for s in SETTINGS:
        name='photons-'+s+'.npz'
        with np.load(ROOT/'response'/name) as f,np.load(ROOT/name) as primary,np.load(legacy('photon-'+s+'.npz')) as ref:
            grid=f['scale'];assert np.array_equal(grid,primary['scale']) and np.array_equal(grid,ref['grid'])
            proj=lambda x:CubicSpline(grid,x)(axis)
            for i,m in enumerate(MODES):
                def unpack(b):
                    v=proj(b['values'][:,i,0]);return {k:v[:,j] for j,k in enumerate(b['channels'].tolist())}
                out=unpack(f);before=unpack(primary)
                mom=proj(ref['values'][:,ref['labels'].tolist().index([m,'primary']),:3].sum(1));den=mag(mom)
                for k in ('effect','photon_effect','collisionless_effect','interaction','matched_effect','wave_effect'):
                    x=out[k];amp=100*mag(x)/den
                    terms.append(dict(mode=m,setting=s,term=k,energy_common_pct=amp[0],current_common_pct=amp[1],joint_common_pct=amp[2],joint_pct_of_gap=100*mag(x)[2]/mag(before['live'])[2],signed_share=np.sum(measure@(x*out['effect'].conj()).real)/mag(out['effect'])[2]**2))
                    check(m,s,k,'substep',out['half_'+k],x);check(m,s,k,'direct_subtraction',before[k],x)
                    cache[m,s,k]=x
                check(m,s,'effect','branch_sum',out['matched_effect']-out['wave_effect'],out['effect'])
                check(m,s,'effect','factorial_sum',out['photon_effect']+out['collisionless_effect']+out['interaction'],out['effect'])
    for (m,s,k),v in cache.items():
        if s!='primary':continue
        for name,mo,st in [('photon_time',m,'time'),('angle',m,'angle')]+([('gravity','p16','primary')] if m=='p32' else []):
            check(m,s,k,name,cache[mo,st,k],v)
    io.table('response-terms.csv',terms);io.table('response-precision.csv',checks)
if __name__=='__main__':
    guard();locked('response-photon-freeze.json');run()
