from angular_stage import ROOT,MODES,guard,locked,freeze
from angular_operator import DIM,QI,QN,operator,forms,Blind,Wave,np
from carry import Drivers,source,io,subgrid
from unittest.mock import patch
io.ROOT=ROOT
def derivative(op,idx,x,held):
    mat,bi,bn=op
    val=mat[idx]@x
    delta_i=x[QI,0]-held[0];delta_n=x[QN,0]-held[1]
    hi=np.array([held[0],delta_i+x[QI,1],delta_i+x[QI,2],0])
    hn=np.array([held[1],delta_n+x[QN,1],0,delta_n+x[QN,3]])
    val[:13]+=bi[idx,:,None]*hi+bn[idx,:,None]*hn
    return val
def integrate(src,entry,grid,native):
    solver=Wave(src) if native else Blind(src);quad=src.quads
    corners=np.asarray(src.corners);cuts=np.unique(np.r_[grid,corners[(corners>grid[0])&(corners<grid[-1])]])
    x=np.zeros((DIM+1,4),complex);x[:-1,0]=entry;x[-1,0]=1;incs=[];hist=[x[:13,1:].copy()]
    with patch.object(src,'quads',lambda t:np.zeros((len(t),2),complex)):
        for start in range(0,len(cuts)-1,48):
            end=min(start+48,len(cuts)-1);a=cuts[start:end];b=cuts[start+1:end+1]
            dt=b-a;mid=(a+b)/2;times=(a,a+dt/3,b-dt/3,b)
            ops=[operator(solver,t,mid) for t in times];prescribed=[quad(t) for t in times]
            for idx,width in enumerate(dt):
                def rhs(k,state):return derivative(ops[k],idx,state,prescribed[k][idx])
                aa=rhs(0,x);tmp=x.copy();tmp[:-1]=x[:-1]+width*aa/3;bb=rhs(1,tmp)
                tmp[:-1]=x[:-1]+width*(bb-aa/3);cc=rhs(2,tmp)
                tmp[:-1]=x[:-1]+width*(aa-bb+cc);dd=rhs(3,tmp)
                inc=width*(aa+3*bb+3*cc+dd)/8;x[:-1]+=inc
                incs.append(inc[:13,1:].copy());hist.append(x[:13,1:].copy())
        loc=np.searchsorted(cuts,grid);left=np.asarray(hist)[loc[:-1]];dx=np.add.reduceat(np.array(incs),loc[:-1],axis=0)
        wt,_,den=forms(src.environment(grid),src.kk,src.wave,native)
        work=np.einsum('ntk,nkd->ntd',wt[1:],dx)+np.einsum('ntk,nkd->ntd',np.diff(wt,axis=0),left)
    return -work.sum(1)/den[1:,None]
if __name__=='__main__':
    guard();locked('photon-freeze.json')
    for mode in MODES:
        src=Drivers(mode);wave=source(mode)
        for split in (2,4):
            with np.load(ROOT/f'angular-{mode}-{split}.npz') as primary:
                grid=primary['grid'];m=integrate(src,primary['matched_entry'],grid,False);w=integrate(wave,primary['wave_entry'],grid,True)
                diff=m-w;vals=np.column_stack((diff,diff[:,0]-diff[:,1]-diff[:,2],m[:,0],w[:,0]))
                assert np.isfinite(vals).all()
                io.pack(f'response-{mode}-{split}.npz',grid=grid,gravity=primary['gravity'],values=vals,channels=['effect','photon_effect','collisionless_effect','interaction','matched_effect','wave_effect'])
    freeze('response-freeze.json',['photon-freeze.json','differential.py','project_response.py']+[f'response-{m}-{s}.npz' for m in MODES for s in (2,4)])
