from pathlib import Path
import hashlib,json,sys
ROOT=Path(__file__).resolve().parent
PRE=ROOT.parent/'mts-continuous-photon-work-89p6-20261125'
SEAL='f28bc256183b4baba88f09f911a4a0d9549f10aca953d3f3a7dace907e33cd13'
MODES=('p16','p32')
CASES=('live','fixed','photon','collisionless')
SETTINGS=('primary','time','angle')
def digest(path):
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
assert digest(PRE/'seal.json')==SEAL
files=json.loads((PRE/'seal.json').read_bytes())['files']
def pin(name):
    p=PRE/name;assert digest(p)==files[name],name
    return p
def guard():assert all(not (p/'STOP-REQUESTED').exists() for p in (PRE,ROOT))
def save(name,obj):
    path=ROOT/name
    if path.exists():assert json.loads(path.read_bytes())==obj,name
    else:path.write_text(json.dumps(obj,indent=2,sort_keys=True,allow_nan=False)+'\n',encoding='utf8')
def freeze(name,parts):save(name,dict(prior=SEAL,files={p:digest(ROOT/p) for p in parts}))
def locked(name):
    receipt=json.loads((ROOT/name).read_bytes());assert receipt['prior']==SEAL
    for name,h in receipt['files'].items():assert digest(ROOT/name)==h,name
sys.path.insert(0,str(PRE));pin('continuous_stage.py')
