from angular_stage import ROOT,MODES,CASES,guard,pin,freeze
from angular_operator import operator,rate_at,verify_operator,forms,switch_levels,LOW,HIGH,DIM,QI,QN,np,Wave,Blind
from carry import Drivers,source,subgrid,forbidden,io,average_stage
import continuous_stage,stage_u
from unittest.mock import patch
io.ROOT=ROOT
def branch(src,entry,grid,native,oldquad):
    solver=Wave(src) if native else Blind(src)
    corners=np.asarray(src.corners);cuts=np.unique(np.r_[grid,corners[(corners>grid[0])&(corners<grid[-1])]])
    x=np.tile(np.r_[entry,1+0j][:,None],(1,len(CASES)))
    steps=[];history=[x[:-1].copy()];sample=grid[np.linspace(0,len(grid)-1,7,dtype=int)]
    agreement=verify_operator(src,solver,entry,sample,operator(solver,sample,sample))
    for first in range(0,len(cuts)-1,48):
        last=min(first+48,len(cuts)-1);left=cuts[first:last];right=cuts[first+1:last+1]
        width=right-left;mid=(left+right)/2;times=(left,left+width/3,right-width/3,right)
        matrices=[operator(solver,t,mid) for t in times];fixed=[oldquad(t) for t in times]
        for idx,dt in enumerate(width):
            def rhs(j,trial):return rate_at(matrices[j],idx,trial,fixed[j][idx])
            a=rhs(0,x);tmp=x.copy();tmp[:-1]=x[:-1]+dt*a/3;b=rhs(1,tmp)
            tmp[:-1]=x[:-1]+dt*(b-a/3);c=rhs(2,tmp)
            tmp[:-1]=x[:-1]+dt*(a-b+c);d=rhs(3,tmp)
            inc=dt*(a+3*b+3*c+d)/8;x[:-1]+=inc
            steps.append(inc[:13].copy());history.append(x[:-1].copy())
    ix=np.searchsorted(cuts,grid);assert np.array_equal(cuts[ix],grid)
    state=np.array(history)[ix];delta=np.add.reduceat(np.asarray(steps),ix[:-1],axis=0)
    assert np.isfinite(state).all() and np.array_equal(state[0,:,0],entry)
    env=src.environment(grid);wt,external,den=forms(env,src.kk,src.wave,native)
    def weighted(change,left):
        return np.einsum('ntk,nkc->ntc',wt[1:],change)+np.einsum('ntk,nkc->ntc',np.diff(wt,axis=0),left)
    low=state[:,:13];parts=weighted(delta,low[:-1])+np.diff(external,axis=0)[:,:,None]
    supply=env[1]['U'];gap=(np.diff(supply)[:,None]-parts.sum(1))/den[1:,None]
    differences=-weighted(delta-delta[:,:,[1]],low[:-1]-low[:-1,:,[1]]).sum(1)/den[1:,None]
    energy,current=solver.aggregate(env,low[:,:-1,0]);res=supply-den*low[:,-1,0]-energy/2-1.5*env[0]['h']*current/src.kk
    control=np.max(abs(np.diff(res)/den[1:]-gap[:,0]))/np.max(abs(gap[:,0]))
    assert control<.005 and np.max(abs(gap-gap[:,[1]]-differences))/np.max(abs(gap))<1e-8
    return dict(gap=gap,changes=differences,parts=parts[:,:,0]/den[1:,None],supply=np.diff(supply)/den[1:],
        quad=state[:,[QI,QN],0],final=state[-1,:,0],checks=[agreement,control])
def build(mode):
    matched=Drivers(mode);wave=source(mode);gravity=matched.time;assert np.array_equal(gravity,wave.time)
    with np.load(continuous_stage.pin(f'density-{mode}-4.npz')) as sealed:mlow=sealed['entry']
    wlow=wave.interp(gravity[:1])[0];wlow[-1]=wave.phi(gravity[0])
    mh=switch_levels(stage_u.pin(f'matter-{mode}.npz'),gravity[0],False)
    wh=switch_levels(average_stage.pin(f'native-{mode}.npz'),gravity[0],True)
    me=np.r_[mlow,mh];we=np.r_[wlow,wh]
    qm=matched.quads;qw=wave.quads
    for src,init in [(matched,me),(wave,we)]:
        assert np.allclose(src.quads(gravity[:1])[0],init[[QI,QN]],rtol=1e-12,atol=0)
    blank=lambda t:np.zeros((len(t),2),complex)
    with patch.object(matched,'quads',blank),patch.object(wave,'quads',blank),patch.object(wave,'interp',forbidden),patch.object(wave,'phi',forbidden),patch.object(wave,'p',forbidden):
        for split in (2,4):
            grid=subgrid(gravity,split);m=branch(matched,me,grid,False,qm);w=branch(wave,we,grid,True,qw)
            total=m['gap']-w['gap'];direct=m['changes']-w['changes']
            parts=w['parts']-m['parts'];sup=m['supply']-w['supply']
            fields={case:total[:,j] for j,case in enumerate(CASES)}
            fields.update(effect=direct[:,0],photon_effect=direct[:,2],collisionless_effect=direct[:,3],interaction=direct[:,0]-direct[:,2]-direct[:,3],
                matched=m['gap'][:,0],wave=w['gap'][:,0],matched_effect=m['changes'][:,0],wave_effect=w['changes'][:,0],heavy=parts[:,0],metric=parts[:,1],ordinary=parts[:,2],supplied=sup)
            assert np.max(abs(fields['live']-fields['fixed']-fields['effect']))<1e-8*np.max(abs(fields['live']))
            assert np.max(abs(fields['live']-parts.sum(1)-sup))<1e-8*np.max(abs(fields['live']))
            io.pack(f'angular-{mode}-{split}.npz',grid=grid,gravity=gravity,channels=list(fields),values=np.column_stack(list(fields.values())),
                matched_quads=m['quad'],wave_quads=w['quad'],matched_final=m['final'],wave_final=w['final'],state_keys=(*LOW,*HIGH),matched_entry=me,wave_entry=we,checks=m['checks']+w['checks'])
            print(mode,split,'operator and work checks',m['checks'],w['checks'],flush=True)
if __name__=='__main__':
    guard()
    for mode in MODES:build(mode)
    freeze('source-freeze.json',['angular_stage.py','PROTOCOL.md','angular_operator.py','release.py','angular_photons.py']+[f'angular-{m}-{s}.npz' for m in MODES for s in (2,4)])
