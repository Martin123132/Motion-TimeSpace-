import csv,sys
from angular_stage import ROOT,MODES,SETTINGS,CASES,guard,locked,pin
if '--quadrupoles' in sys.argv:
    from carry import io,np
else:
    from angular_photons import io,gate,np
    from cell89 import pin as legacy
from scipy.interpolate import CubicSpline
import density_stage
io.ROOT=ROOT
def rms(x,t):return np.sqrt(np.trapezoid(abs(x)**2,t,axis=0)/(t[-1]-t[0]))
def quadrupoles():
    from carry import Drivers,source
    data=[];control=[]
    for m in MODES:
        with np.load(ROOT/f'angular-{m}-4.npz') as f,np.load(ROOT/f'angular-{m}-2.npz') as half:
            grid=f['grid']
            for label,src in [('matched',Drivers(m)),('wave',source(m))]:
                val=f[label+'_quads'];stored=src.quads(grid);den=rms(stored,grid)
                er=rms(val-stored,grid)/den;ep=np.max(abs(val-stored),axis=0)/np.max(abs(stored),axis=0)
                conv=rms(val[::2]-half[label+'_quads'],grid[::2])/rms(val[::2],grid[::2])
                for i,k in enumerate(('I2','N2')):
                    data.append(dict(mode=m,branch=label,quad=k,rms_difference_pct=100*er[i],peak_difference_pct=100*ep[i],refinement_pct=100*conv[i],precision_pass=bool(conv[i]<=.005)))
            for bank,split in ((f,4),(half,2)):
                for name,er in zip(('matched_angular_rhs','matched_work','wave_angular_rhs','wave_work'),bank['checks']):
                    control.append(dict(mode=m,split=split,check=name,relative=er,passes=bool(er<=.005)))
    io.table('quadrupole-trajectories.csv',data);io.table('operator-and-work.csv',control)
def score():
    _,axis,w,_=gate.proj.old.get_media();measure=gate.previous.make_measure(axis,w);mag=lambda v:gate.mag(v,measure)
    with gate.pin(gate.FROZEN,'window-readouts.csv').open() as fp:
        launch={r['gravity']:float(r['launch_norm']) for r in csv.DictReader(fp) if r['model']=='MTS-minus-baseline' and r['output']=='joint'}
    gates=[];checks=[];small=[];contrast=[];cache={}
    def assess(mode,setting,label,a,b,kind):
        den=mag(b)
        if min(den)<=0:raise ValueError('undefined comparison '+label)
        er=mag(a-b)/den;checks.append(dict(mode=mode,setting=setting,check=label,kind=kind,energy_pct=100*er[0],current_pct=100*er[1],joint_pct=100*er[2],passes=bool(max(er)<=.005)))
    for setting in SETTINGS:
        name='photons-'+setting+'.npz'
        with np.load(ROOT/name) as f,np.load(pin(name)) as prev,np.load(density_stage.pin('reference/'+name)) as archived,np.load(legacy('photon-'+setting+'.npz')) as old:
            grid=f['scale'];assert all(np.array_equal(grid,v) for v in (prev['scale'],archived['scale'],old['grid']))
            interp=lambda x:CubicSpline(grid,x)(axis)
            for idx,mode in enumerate(MODES):
                def terms(bank):
                    v=interp(bank['values'][:,idx,0]);return {k:v[:,i] for i,k in enumerate(bank['channels'].tolist())}
                v=terms(f);before=terms(prev)['total'];reset=terms(archived)['actual_total']
                mom=interp(old['values'][:,old['labels'].tolist().index([mode,'primary']),:3].sum(1));scale=mag(mom)
                assess(mode,setting,'fixed_replays_previous',v['fixed'],before,'primary')
                for k in ('live','fixed','effect','photon_effect','collisionless_effect','interaction'):
                    assess(mode,setting,'substeps_'+k,v['half_'+k],v[k],'primary' if k in ('live','fixed') else 'small')
                    cache[mode,setting,k]=v[k]
                for k,a,b,kind in [('branches',v['matched']-v['wave'],v['live'],'primary'),('work',v['heavy']+v['metric']+v['ordinary']+v['supplied'],v['live'],'primary'),('release_identity',v['fixed']+v['effect'],v['live'],'primary'),('paired_effect_vs_difference',v['live']-v['fixed'],v['effect'],'small'),('factorial',v['photon_effect']+v['collisionless_effect']+v['interaction'],v['effect'],'small'),('effect_branches',v['matched_effect']-v['wave_effect'],v['effect'],'small')]:
                    assess(mode,setting,k,a,b,kind)
                for k,val in [(k,v[k]) for k in CASES]+[('previous',before),('per_cell',reset)]:
                    pct=100*mag(val)/scale;pm=100*scale[2]/launch[mode];pd=100*mag(mom+val)[2]/launch[mode]
                    gates.append(dict(mode=mode,setting=setting,case=k,energy_pct=pct[0],current_pct=pct[1],joint_pct=pct[2],component_pass=bool(max(pct)<=.5),momentum_launch_pct=pm,differentiated_launch_pct=pd,launch_pass=bool(max(pm,pd)<.163)))
                for k,base in [('previous',before),('fixed',v['fixed']),('per_cell',reset)]:
                    er=100*mag(v['live']-base)/mag(base)
                    contrast.append(dict(mode=mode,setting=setting,reference=k,energy_error_pct=er[0],current_error_pct=er[1],joint_error_pct=er[2],agreement=bool(max(er)<=.5)))
                for k in ('effect','photon_effect','collisionless_effect','interaction','matched_effect','wave_effect'):
                    val=v[k];pct=100*mag(val)/scale
                    small.append(dict(mode=mode,setting=setting,term=k,energy_common_pct=pct[0],current_common_pct=pct[1],joint_common_pct=pct[2],joint_pct_of_previous=100*mag(val)[2]/mag(before)[2],along_total_effect=np.sum(measure@(val*v['effect'].conj()).real)/mag(v['effect'])[2]**2))
    for mode in MODES:
        for k in ('live','fixed','effect','photon_effect','collisionless_effect','interaction'):
            ref=cache[mode,'primary',k]
            for label,mo,s in [('photon_time',mode,'time'),('angle',mode,'angle')]+([('gravity','p16','primary')] if mode=='p32' else []):
                assess(mode,'primary',label+'_'+k,cache[mo,s,k],ref,'primary' if k in ('live','fixed') else 'small')
    for name,rows in [('gates',gates),('comparisons',contrast),('release-effects',small),('precision',checks)]:io.table(name+'.csv',rows)
if __name__=='__main__':
    guard();locked('source-freeze.json');locked('photon-freeze.json')
    if '--quadrupoles' in sys.argv:quadrupoles()
    else:score()
