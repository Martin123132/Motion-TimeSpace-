from pathlib import Path
import hashlib,json,sys
ROOT=Path(__file__).resolve().parent
PRE=ROOT.parent/'mts-continuous-angular-work-89p6-20261125'
SEAL='f789ed00f130cc965715252991d103baf9146a41b88b8a5bffd75fa3ea8887c5'
def digest(path):
    with path.open('rb') as data:return hashlib.file_digest(data,'sha256').hexdigest()
assert digest(PRE/'seal.json')==SEAL
FILES=json.loads((PRE/'seal.json').read_bytes())['files']
def pin(name):
    path=PRE/name;assert digest(path)==FILES[name],name
    return path
def guard():assert not any((p/'STOP-REQUESTED').exists() for p in (PRE,ROOT,ROOT.parent))
def freeze(name,names):
    guard();obj=dict(prior=SEAL,files={k:digest(ROOT/k) for k in names})
    path=ROOT/name
    if path.exists():assert json.loads(path.read_bytes())==obj
    else:path.write_text(json.dumps(obj,indent=2,sort_keys=True)+'\n')
def locked(name):
    obj=json.loads((ROOT/name).read_bytes());assert obj['prior']==SEAL
    for k,h in obj['files'].items():assert digest(ROOT/k)==h,k
MODES=('p16','p32')
SETTINGS=('primary','time','angle')
sys.path.insert(0,str(PRE))
