from one_stage import ROOT,MODES,pin,digest,guard,freeze
pin('release.py');pin('angular_operator.py')
import release
from release import Drivers,source,Blind,Wave,forms,io,np,stage_u
from angular_operator import IX,DIM,QI,QN,operator
from inputs_density import ip,native
from types import SimpleNamespace
from scipy.interpolate import CubicSpline
from scipy.integrate import solve_ivp
from unittest.mock import patch
import json,sys
io.ROOT=ROOT
KIN=ip.matter
def peak(x):return float(np.max(np.abs(x)))
def relative(x,y):return peak(x-y)/max(peak(y),1e-95)
def injection(src,env,stress,iswave):
    bg=env[0];kk=src.kk;stress=stress*bg['enu'][:,None];lapse=stress[:,2]/kk
    out=np.zeros((len(lapse),DIM),complex)
    for key,value in {'W':kk*(4/3+bg['eb']/bg['eg'])*lapse,'N1':src.wave*lapse/3,'ct':kk*lapse,'geom':stress[:,1]*src.wave/(2*kk)-bg['h']*lapse,'sf':bg['sv']*lapse,'sw':-(bg['a']*bg['sm'])**2*bg['sb']*lapse}.items():out[:,IX[key]]=value
    if iswave:
        out[:,IX['hf']]=bg['hv']*lapse;out[:,IX['hw']]=-(bg['a']*bg['hm'])**2*bg['hb']*lapse
    else:out[:,IX['hw']]=kk*lapse
    return out
def evolve(src,grid,entry,iswave,stress=None):
    solver=(Wave if iswave else Blind)(src);corners=np.asarray(src.corners)
    cuts=np.unique(np.r_[grid,corners[(corners>grid[0])&(corners<grid[-1])]])
    count=1 if stress is None else len(stress);state=np.zeros((DIM+1,count),complex)
    if stress is None:state[:-1,0]=entry;state[-1]=1
    history=[state[:-1].copy()]
    with patch.object(src,'quads',lambda t:np.zeros((len(t),2),complex)):
        for first in range(0,len(cuts)-1,40):
            guard();last=min(first+40,len(cuts)-1);left=cuts[first:last];right=cuts[first+1:last+1];dt=right-left;mid=(left+right)/2
            ops=[];ext=[]
            for t in (left,left+dt/3,right-dt/3,right):
                mat,bi,bn=operator(solver,t,mid);mat[:,:13,QI]+=bi;mat[:,:13,QN]+=bn;ops.append(mat)
                if stress is not None:
                    env=solver.env(t,mid);ext.append(np.stack([injection(src,env,fn(np.log(t)),iswave) for fn in stress],axis=-1))
            for j,width in enumerate(dt):
                def rhs(stage,x):
                    out=ops[stage][j]@x
                    if stress is not None:out+=ext[stage][j]
                    return out
                aa=rhs(0,state);tmp=state.copy();tmp[:-1]=state[:-1]+width*aa/3;bb=rhs(1,tmp)
                tmp[:-1]=state[:-1]+width*(bb-aa/3);cc=rhs(2,tmp);tmp[:-1]=state[:-1]+width*(aa-bb+cc);dd=rhs(3,tmp)
                state[:-1]+=width*(aa+3*bb+3*cc+dd)/8;history.append(state[:-1].copy())
    return np.asarray(history)[np.searchsorted(cuts,grid)]
def driver(mode,src,grid,hist,native_wave):
    bg,q,st,coef,_,_,rho,_=src.environment(grid)
    shear=q['hshear'] if native_wave else rho*coef[4]
    lapse=hist[:,IX['geom']]+(-q['Q']-bg['eg']*(hist[:,QI]+q['ph_shift'])-(4*bg['er']+bg['nuS'])*hist[:,QN]+st[:,2]+q['cshear']+q['bshear']+q['sshear']+shear)/src.kk
    normal=hist[:,[IX[f'N{degree}'] for degree in range(69)]].copy();normal[:,0]+=hist[:,IX['geom']]
    if native_wave:
        with np.load(native('particular-heavy-'+mode+'.npz')) as f:
            t=f['eta'];idx=slice(max(0,np.searchsorted(t,grid[0])-8),None)
            t=t[idx];ref=f['normal'][idx,:,0,0];psi=f['psi'][idx];clock=f['stressClock'];assert np.array_equal(f['q'],KIN.MOM)
    else:
        with np.load(stage_u.pin('matter-'+mode+'.npz')) as f,np.load(ip.path(mode,'base','curves')) as old:
            keys=f['keys'].tolist();t=f['eta'];v=f['states'];ref=v[:,[keys.index(f'N{degree}') for degree in range(69)]].copy();ref[:,0]+=v[:,keys.index('geom')]
            assert np.array_equal(t,old['eta']) and relative(v[:,keys.index('geom')],old['phi'])<1e-11
            psi=old['psi'];clock=f['stress_clock']
    change=np.column_stack((normal,lapse))-KIN.spline(t,np.column_stack((ref,psi)))(np.log(grid))
    knots=np.unique(np.r_[grid[0],clock[(clock>grid[0])&(clock<grid[-1])],grid[-1]])
    assert np.isfinite(change).all() and peak(change)>0 and len(knots)>=4
    return change,knots
def kinetic(src,grid,change,knots,iswave):
    folder=KIN.BASE89 if iswave else KIN.FLUID
    meta=json.loads(KIN.ti.parent.pin('radiation-background.json').read_bytes())['heavy'];files=json.loads((folder/'bank-heavy.json').read_bytes())
    mom=KIN.MOM;assert len(mom)==77 and np.array_equal(mom,2.**(np.arange(-52,25)/4))
    for name in ['material-halfstep/forcing-heavy.npz','common-heavy.npz']+[f'micro-heavy-{node}.npz' for node in range(-52,25)]:
        assert digest(folder/name)==files[name],name
    with np.load(folder/'material-halfstep/forcing-heavy.npz') as f:
        bg=dict(zip(f['bgkeys'],f['background']));af=KIN.spline(f['eta'],bg['a']);energy=KIN.spline(f['eta'],bg['enu'])
    mass=meta['mass_over_temperature'];scale=peak(change);fn=KIN.spline(grid,change/scale);k=src.wave
    deg=np.arange(69);lo=k*deg/(2*deg+1);hi=-k*(deg+1)/(2*deg+1)
    def adv(x):
        out=np.zeros_like(x);out[...,1:]+=lo[1:]*x[...,:-1];out[...,:-1]+=hi[:-1]*x[...,1:];return out
    def rhs(t,state):
        u=np.log(t);at=mass*af(u);ep=np.hypot(mom,at);vel=mom/ep;slow=-at**2/(ep*(ep+mom));drivers=fn(u)
        out=vel[:,None]*adv(state.reshape(77,69))+slow[:,None]*adv(drivers[:69])
        out[:,1]-=slow/vel*k*drivers[-1]/3
        return out.ravel()
    dense=np.unique(np.r_[knots,np.linspace(grid[0],grid[-1],161)])
    def solve(max_step):
        sol=solve_ivp(rhs,(grid[0],grid[-1]),np.zeros(77*69,complex),method='DOP853',rtol=4e-10,atol=2e-16,max_step=max_step,t_eval=dense)
        assert sol.success and np.array_equal(sol.t,dense)
        return sol.y.T.reshape(len(dense),77,69)[:,:,:3].copy()
    low=solve(.0032);again=solve(.0016);lag_error=relative(low,again)
    win=SimpleNamespace(t=dense,k=np.array([k]),mass=mass,af=af,energy=energy,coeff=meta['massless_limit_coeff']/(7*np.pi**4/120),
        shape=lambda u:np.zeros(np.shape(u)+(69,1)),normal=lambda u:fn(u)[:69,None,None],lapse=lambda u:fn(u)[-1:].reshape(1,1))
    independent=[]
    for j in (0,39,76):
        original=KIN.lag_flight(win,mom[j],np.zeros((1,69,len(dense))),np.zeros((69,1,1),complex))[:,:3,0,0]
        independent.append(relative(again[:,j],original))
    vals,check=KIN.four_stresses(win,again[:,:,:,None,None]*scale);vals=vals[:,:,0,0];qerr=relative(check[:,:,0,0],vals)
    assert max(independent+[qerr,lag_error])<=.005,(independent,qerr,lag_error)
    assert peak(vals[0])==0 and peak(vals)>0
    return [KIN.spline(knots,vals[np.searchsorted(dense,knots)]),KIN.spline(dense,vals)],dict(kinetic_refinement=lag_error,independent_bins=independent,stress_quadrature=qerr,driver_peak=scale,stress_peak=peak(vals)),dense,vals
def branch(mode,src,bank,label):
    grid=bank['grid'];entry=bank[label+'_entry'];wave=label=='wave'
    states=evolve(src,grid,entry,wave)[:,:,0]
    replay=max(relative(states[-1],bank[label+'_final']),relative(states[:,[QI,QN]],bank[label+'_quads']));assert replay<1e-10,replay
    change,knots=driver(mode,src,grid,states,wave)
    stress,diag,dense,values=kinetic(src,grid,change,knots,wave)
    env=src.environment(grid);weights,_,den=forms(env,src.kk,src.wave,wave)
    solver=(Wave if wave else Blind)(src);test=solver.env(grid[:4]);trial=list(test);probe=np.ones((4,4));physical=probe*test[0]['enu'][:,None];physical[:,1]*=src.wave;trial[2]=test[2]+physical
    zero=np.zeros((4,13),complex);dr=solver.rhs(trial,zero)-solver.rhs(test,zero)
    injection_error=relative(dr,injection(src,test,probe,wave)[:,:13]);assert injection_error<1e-8,injection_error
    delta=evolve(src,grid,None,wave,stress)[:,:13]
    calc=np.einsum('ntk,nkc->nc',weights,delta)
    external=[]
    for fn in stress:
        s=fn(np.log(grid))*env[0]['enu'][:,None]
        external.append(s[:,0]/2+1.5*env[0]['h']*s[:,1]*src.wave/src.kk)
    direct=-np.diff(np.array(external).T,axis=0)/den[1:,None];work=-np.diff(calc,axis=0)/den[1:,None]
    assert np.isfinite(work+direct).all()
    diag.update(replay=replay,injection=injection_error,knots=len(knots),peak_lapse_delta=peak(change[:,-1]))
    return work+direct,direct,diag,dense,values
def build(mode):
    guard();matched=Drivers(mode);wave=source(mode)
    for split in (2,4):
        name=f'impulses-{mode}-{split}.npz';stats=f'checks-{mode}-{split}.json'
        with np.load(pin(f'angular-{mode}-{split}.npz')) as bank:
            m,md,dm,mt,mv=branch(mode,matched,bank,'matched');w,wd,dw,wt,wv=branch(mode,wave,bank,'wave')
            total=m-w
            io.pack(name,grid=bank['grid'],gravity=bank['gravity'],matched_clock=mt,matched_stress=mv,wave_clock=wt,wave_stress=wv,channels=['effect','matched','wave','dense','direct','induced'],values=np.column_stack((total[:,0],m[:,0],w[:,0],total[:,1],(md-wd)[:,0],(total-md+wd)[:,0])))
            io.record(stats,dict(matched=dm,wave=dw));print(mode,split,dm,dw,flush=True)
if __name__=='__main__':
    for mode in sys.argv[1:] or MODES:build(mode)
