from one_stage import ROOT,SEAL,MODES,SETTINGS,guard,locked,freeze,digest
from pathlib import Path
import ast,csv,json,numpy as np
def rows(name):
    with (ROOT/name).open() as stream:return list(csv.DictReader(stream))
def verify():
    guard();locked('source-freeze.json');locked('photon-freeze.json')
    for m in MODES:
        for split in (2,4):
            with np.load(ROOT/f'impulses-{m}-{split}.npz') as f:
                assert np.array_equal(f['grid'][::split],f['gravity'])
                vals=dict(zip(f['channels'],f['values'].T))
                for a,b in ((vals['matched']-vals['wave'],vals['effect']),(vals['direct']+vals['induced'],vals['effect'])):
                    assert max(abs(a-b))<=1e-11*max(abs(b))
                for name in ('matched','wave'):
                    t=f[name+'_clock'];v=f[name+'_stress'];assert v.shape==(len(t),4) and np.all(np.diff(t)>0)
                    assert not np.any(v[0]) and np.isfinite(v).all() and min(np.max(abs(v),axis=0))>0
                    assert np.array_equal(t[[0,-1]],f['grid'][[0,-1]])
                    checks=json.loads((ROOT/f'checks-{m}-{split}.json').read_bytes())[name]
                    assert max([checks[k] for k in ('kinetic_refinement','stress_quadrature','injection','replay')]+checks['independent_bins'])<=.005
    g=rows('gates.csv');checks=rows('precision.csv');assert len(g)==6 and len(checks)==46
    for r in g:
        assert (max(float(r[k]) for k in ('energy','current','joint'))<=.5)==(r['passes']=='True')
        assert (max(float(r[x]) for x in ('launch_pct','momentum_launch_pct'))<.163)==(r['launch_pass']=='True')
    for r in checks:
        assert (max(float(r[k+'_pct']) for k in ('energy','current','joint'))<=.5)==(r['passes']=='True')
    for s in SETTINGS:
        quadr=rows('quadrature-'+s+'.csv');assert len(quadr)==2 and all(float(r['relative'])<=.005 for r in quadr)
    for script in ROOT.glob('*.py'):ast.parse(script.read_text())
    assert not list(ROOT.rglob('__pycache__'))
    freeze('seal.json',sorted(p.name for p in ROOT.iterdir() if p.is_file() and p.name!='seal.json'))
    print('seal',digest(ROOT/'seal.json'))
if __name__=='__main__':verify()
