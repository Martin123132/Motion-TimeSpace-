from one_stage import ROOT,MODES,SETTINGS,pin,guard,locked
from angular_photons import gate,io,np
from cell89 import pin as legacy
from scipy.interpolate import CubicSpline
import csv
def compare():
    guard();locked('source-freeze.json');locked('photon-freeze.json');io.ROOT=ROOT
    _,axis,w,_=gate.proj.old.get_media();measure=gate.previous.make_measure(axis,w);mag=lambda v:gate.mag(v,measure)
    with gate.pin(gate.FROZEN,'window-readouts.csv').open() as stream:
        launch={r['gravity']:float(r['launch_norm']) for r in csv.DictReader(stream) if r['model']=='MTS-minus-baseline' and r['output']=='joint'}
    gates=[];checks=[];cache={};terms=[]
    def check(m,s,key,trial,ref):
        rel=100*mag(trial-ref)/mag(ref);assert np.isfinite(rel).all()
        checks.append(dict(mode=m,setting=s,check=key,energy_pct=rel[0],current_pct=rel[1],joint_pct=rel[2],passes=bool(max(rel)<=.5)))
    for s in SETTINGS:
        n=f'photons-{s}.npz'
        with np.load(ROOT/n) as packet,np.load(pin(n)) as old,np.load(legacy(f'photon-{s}.npz')) as origin:
            grid=packet['scale'];assert np.array_equal(grid,old['scale']) and np.array_equal(grid,origin['grid'])
            view=lambda x:CubicSpline(grid,x)(axis)
            for i,m in enumerate(MODES):
                def unpack(data):
                    v=view(data['values'][:,i,0]);return dict(zip(data['channels'].tolist(),v.swapaxes(0,1)))
                v=unpack(packet);before=unpack(old)['live'];effect=v['effect'];after=before+effect
                mom=view(origin['values'][:,origin['labels'].tolist().index([m,'primary']),:3].sum(1));den=mag(mom)
                out=100*mag(after)/den;was=100*mag(before)/den;size=100*mag(mom+after)[2]/launch[m]
                along=100*np.sum(measure@(effect*before.conj()).real)/(mag(before)[2]*den[2])
                original_size=100*den[2]/launch[m]
                gates.append(dict(mode=m,setting=s,before_joint=was[2],energy=out[0],current=out[1],joint=out[2],change=out[2]-was[2],feedback=100*mag(effect)[2]/den[2],signed_along_previous=along,passes=bool(max(out)<=.5),momentum_launch_pct=original_size,launch_pct=size,launch_pass=bool(max(size,original_size)<.163)))
                cache[m,s]=(after,effect)
                check(m,s,'gap_substeps',before+v['half_effect'],after);check(m,s,'gap_stress_cadence',before+v['dense'],after)
                check(m,s,'feedback_substeps',v['half_effect'],effect);check(m,s,'feedback_stress_cadence',v['dense'],effect)
                check(m,s,'feedback_branch_difference',v['matched']-v['wave'],effect);check(m,s,'feedback_work_sum',v['direct']+v['induced'],effect)
                for key in ('effect','matched','wave','direct','induced','dense'):
                    a=100*mag(v[key])/den;terms.append(dict(mode=m,setting=s,term=key,energy=a[0],current=a[1],joint=a[2]))
    for m in MODES:
        for i,key in enumerate(('gap','feedback')):
            for other,test,name in [(m,'time','photon_time'),(m,'angle','angle')]+([('p16','primary','gravity')] if m=='p32' else []):
                check(m,'primary',key+'_'+name,cache[other,test][i],cache[m,'primary'][i])
    for n,rows in [('gates',gates),('precision',checks),('terms',terms)]:io.table(n+'.csv',rows)
    print([r for r in gates if r['setting']=='primary'])
if __name__=='__main__':compare()
