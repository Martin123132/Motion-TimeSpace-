import ast
import csv
import sys
from window_stage import ROOT, MODES, SETTINGS, CASES, PAIR, label, pinned, previous, angular, locked, freeze, sha, np

def rows(name):
    with (ROOT/name).open() as stream:
        return list(csv.DictReader(stream))
def verify():
    for name in ('launch-freeze.json','source-freeze.json','prediction-freeze.json'):
        locked(name)
    for mode,branch,sub in CASES:
        tag=label(mode,branch,sub)
        with np.load(ROOT/f'launch-{tag}.npz') as launch,np.load(ROOT/f'work-{tag}.npz') as work,np.load(angular(f'angular-{mode}-{sub}.npz')) as origin,np.load(previous(f'prediction-{mode}-{sub}.npz')) as prep:
            original=origin[branch+'_entry']
            assert np.array_equal(launch['base'],original)
            assert np.array_equal(work['states'][0],original+prep['entry_change'] if branch=='matched' else original)
            assert work['states'].shape==(5,90) and np.isfinite(work['states']).all()
            assert np.array_equal(work['edges'][:2],[launch['left'],launch['first_end']]) and work['cuts'][0]==work['edges'][0] and work['cuts'][-1]==work['edges'][-1]
            assert max(work['zero_errors'])<1e-12 and np.all(work['denominator']>0)
            edges=work['edges']
        with np.load(ROOT/f'source-{mode}-{sub}.npz') as bank:
            knots=bank['knots']
            assert knots[0]==edges[0] and knots[-1]==89.6
            vec=dict(zip(bank['keys'].tolist(),bank['values'].T,strict=True))
            assert not np.any(vec['first'][knots[:-1]>=edges[1]]) and not np.any(vec['partial'][knots[1:]<=edges[-1]])
            assert np.array_equal(vec['core'],vec['first']+vec['drift']+vec['partial']) and np.array_equal(vec['full'],vec['core']+vec['osc'])
    for setting in SETTINGS:
        data=rows(f'quadrature-{setting}.csv')
        assert len(data)==2 and all(float(r['relative'])<=.005 for r in data)
    for fname,count,cols in [('first-raw.csv',8,['relative_pct']),('comparisons.csv',48,['energy_pct','current_pct','joint_pct']),
                             ('numerics.csv',153,['energy_pct','current_pct','joint_pct'])]:
        data=rows(fname)
        assert len(data)==count,(fname,len(data))
        for row in data:
            err=[float(row[k]) for k in cols]
            assert np.isfinite(err).all() and min(err)>=0 and (max(err)<=.5)==(row['passes']=='True')
    assert len(rows('common-kick.csv'))==6 and len(rows('physical-gates.csv'))==6 and len(rows('readouts.csv'))==84
    for row in rows('physical-gates.csv'):
        assert (max(float(row[k]) for k in ('energy_gap_pct','current_gap_pct','joint_gap_pct'))<=.5)==(row['gap_pass']=='True')
        assert (max(float(row[k]) for k in ('momentum_pct_of_launch','differentiated_pct_of_launch'))<=.163)==(row['size_pass']=='True')
    for row in rows('common-kick.csv'):
        assert (float(row['entry_agreement_pct'])<=.5)==(row['entry_pass']=='True')
    for path in ROOT.glob('*.py'):
        ast.parse(path.read_text())
    assert not list(ROOT.rglob('__pycache__'))
    if '--seal' in sys.argv:
        assert (ROOT/'RESULTS.md').is_file()
        freeze('seal.json',sorted(p.name for p in ROOT.iterdir() if p.is_file() and p.name!='seal.json'))
        locked('seal.json')
        print(sha(ROOT/'seal.json'))
    print('verified launches, support, predictions, vector and physical acceptance flags')
if __name__=='__main__':
    verify()
