import hashlib
import importlib.util
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent
DRIFT = ROOT.parent/'mts-photon-frozen-drift-cycles234-89p6-20261125'
PARTIAL = ROOT.parent/'mts-final-partial-wave-photons-89p6-20261125'
PARENTS = {DRIFT:'9d0f857e8618d2557a922c87653548b6c0692480042edb392a4f7e742e2f5bc9',
           PARTIAL:'c5fbe7f90e24f0ad4b8c85ea0b03a820139300691d9755f17d047929c51be5b2'}
def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream,'sha256').hexdigest()
def prior(folder,name):
    assert sha(folder/'seal.json')==PARENTS[folder]
    path=folder/name
    assert sha(path)==json.loads((folder/'seal.json').read_bytes())['files'][name],name
    return path
def frozen(folder,name,receipt):
    path=prior(folder,name)
    assert sha(path)==json.loads(prior(folder,receipt).read_bytes())['files'][name]
    return path
prior(DRIFT,'transfer_stage.py')
sys.path.insert(0,str(DRIFT))
import transfer_stage as common
common.ROOT=ROOT
common.PINS={**common.PINS,**PARENTS}
from transfer_stage import np, ARCHIVE, PAIR, MODES, SETTINGS, pack, table, guard, freeze, locked, pinned, previous, angular
CASES=[(mode,branch,sub) for mode in MODES for sub in (2,4) for branch in ('matched','wave')]
def label(mode,branch,sub):
    return f'{mode}-{branch}-{sub}'
def safe():
    guard()
    assert not (ROOT/'seal.json').exists()
def photons():
    safe()
    spec=importlib.util.spec_from_file_location('retained_window_transfer',prior(DRIFT,'predict.py'))
    module=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    assert module.ROOT==ROOT
    module.photons()
if __name__=='__main__':
    assert sys.argv[1:]==['photons']
    photons()
