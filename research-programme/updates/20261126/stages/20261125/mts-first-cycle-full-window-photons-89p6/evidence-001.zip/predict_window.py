import sys

from window_stage import ROOT, PAIR, DRIFT, PARTIAL, CASES, MODES, sha, label, safe, pinned, frozen, pack, table, freeze, locked, previous, angular, np
for filename in ('pair_stage.py','energy_current.py'):
    pinned(PAIR,filename)
sys.path.insert(0,str(PAIR))
from pair_stage import limits
from cycle3_inputs import make
from energy_current import integrate
from forecast_cycle3 import add

def launches():
    safe()
    rows=[]
    for mode,branch,sub in CASES:
        fname=f'angular-{mode}-{sub}.npz'
        with np.load(angular(fname)) as bank:
            base=bank[branch+'_entry']
            left=bank['gravity'][0]
        edge=limits(mode,1)
        assert left==edge[0] and base.shape==(90,)
        with np.load(previous(f'prediction-{mode}-{sub}.npz')) as bank:
            update=bank['entry_change']
            assert bank['edge']==edge[1]
        with np.load(previous(f'metric-{mode}-{sub}.npz')) as bank:
            kick=bank['kick'].item()
        assert update.shape==(90,) and update[12]==kick
        state=base+update if branch=='matched' else base
        assert np.isfinite(state).all()
        pack('launch-'+label(mode,branch,sub)+'.npz',base=base,launch=state,left=edge[0],first_end=edge[1],prep_kick=kick)
        rows.append(dict(mode=mode,branch=branch,subdivision=sub,start=left,first_end=edge[1],base_hash=sha(angular(fname)),
                         preparation_hash=sha(previous(f'prediction-{mode}-{sub}.npz')),kick_hash=sha(previous(f'metric-{mode}-{sub}.npz'))))
    table('launches.csv',rows)
    freeze('launch-freeze.json',['PROTOCOL.md','window_stage.py','predict_window.py','score_window.py','launches.csv']+
           ['launch-'+label(*case)+'.npz' for case in CASES])

def evolve(mode,branch,sub):
    tag=label(mode,branch,sub)
    with np.load(ROOT/f'launch-{tag}.npz') as bank:
        state=bank['launch']
    src,solver,grid,entry,_=make(mode,branch,sub)
    edges=[limits(mode,1)[0]]+[limits(mode,cycle)[1] for cycle in (1,2,3,4)]
    assert edges[0]==grid[0] and edges[-1]<grid[-1] and np.array_equal(entry,state)
    cuts,history,work,primitive=integrate(src,solver,grid,edges[0],edges[-1],state,branch=='wave',edges[1:-1])
    assert np.array_equal(history[0],state) and np.isfinite(history).all()
    dt=np.diff(cuts)
    cell=np.searchsorted(grid,cuts[:-1],side='right')-1
    assert np.all(cuts[1:]<=grid[cell+1])
    den=src.environment(grid)[-1][cell+1]
    assert np.isfinite(den).all() and min(den)>0
    raw=work[:,0]+work[:,4]+work[:,3]
    values=np.zeros((len(dt),3),complex)
    sums=[]
    zero=[]
    for cycle,(lo,hi) in enumerate(zip(edges[:-1],edges[1:]),1):
        mask=(cuts[:-1]>=lo)&(cuts[1:]<=hi)
        assert abs(dt[mask].sum()-(hi-lo))<1e-13
        net=add(raw[mask])
        sums.append(net)
        if cycle==1:
            values[mask,0]=raw[mask]/dt[mask]/den[mask]
            values[mask,2]=primitive[mask].sum(1)/dt[mask]/den[mask]
        else:
            residual=raw[mask]/dt[mask]-net/(hi-lo)
            values[mask,1]=residual/den[mask]
            err=abs(add(residual*dt[mask]))/sum(abs(residual)*dt[mask])
            assert err<1e-12
            zero.append(err)
    positions=np.searchsorted(cuts,edges)
    assert np.array_equal(cuts[positions],edges)
    pack(f'work-{tag}.npz',edges=edges,cuts=cuts,states=history[positions],raw=raw,denominator=den,sums=sums,zero_errors=zero)
    return grid,src.time,cuts,values

def rates_on(knots,source_knots,values):
    out=np.zeros((len(knots)-1,values.shape[1]),complex)
    active=(knots[:-1]>=source_knots[0])&(knots[1:]<=source_knots[-1])
    idx=np.searchsorted(source_knots,knots[:-1][active],side='right')-1
    assert np.all(knots[1:][active]<=source_knots[idx+1])
    out[active]=values[idx]
    return out

def sources():
    safe()
    locked('launch-freeze.json')
    for mode in MODES:
        for sub in (2,4):
            grid,gravity,cuts,fields=zip(*(evolve(mode,branch,sub) for branch in ('matched','wave')))
            assert np.array_equal(grid[0],grid[1]) and np.array_equal(gravity[0],gravity[1])
            banks=[]
            for folder,key in ((DRIFT,'drift'),(PARTIAL,'partial')):
                with np.load(frozen(folder,f'source-{mode}-{sub}.npz','source-freeze.json')) as bank:
                    assert np.array_equal(gravity[0],bank['gravity'])
                    banks.append((bank['knots'],bank['values'][:,[bank['keys'].tolist().index(key)]]))
            knots=np.unique(np.concatenate([grid[0],*cuts,*(item[0] for item in banks)]))
            matched,wave=[rates_on(knots,clock,vals) for clock,vals in zip(cuts,fields)]
            drift,partial=[rates_on(knots,clock,vals)[:,0] for clock,vals in banks]
            first,osc,primitive=(matched-wave).T
            first_end=limits(mode,1)[1]
            late_end=limits(mode,4)[1]
            assert not first[knots[:-1]>=first_end].any() and not partial[knots[1:]<=late_end].any()
            for vals in (osc,drift):
                assert not vals[(knots[1:]<=first_end)|(knots[:-1]>=late_end)].any()
            core=first+drift+partial
            full=core+osc
            cols=np.column_stack((full,core,first,osc,drift,partial,matched[:,0],wave[:,0],primitive))
            assert np.isfinite(cols).all()
            pack(f'source-{mode}-{sub}.npz',gravity=gravity[0],knots=knots,values=cols,
                 keys=['full','core','first','osc','drift','partial','first_matched','first_wave','first_primitive'])
    freeze('source-freeze.json',['launch-freeze.json']+['work-'+label(*case)+'.npz' for case in CASES]+
           [f'source-{mode}-{sub}.npz' for mode in MODES for sub in (2,4)])
if __name__=='__main__':
    {'launch':launches,'sources':sources}[sys.argv[1]]()
