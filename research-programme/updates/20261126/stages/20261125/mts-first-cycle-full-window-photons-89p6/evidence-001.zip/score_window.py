import csv
from scipy.interpolate import CubicSpline

from window_stage import ROOT, ARCHIVE, DRIFT, PARTIAL, CASES, MODES, SETTINGS, label, safe, frozen, previous, angular, pinned, locked, table, np
angular('angular_photons.py')
from angular_photons import gate
from cell89 import pin as original, old as legacy

def run():
    safe()
    for name in ('launch-freeze.json','source-freeze.json','prediction-freeze.json'):
        locked(name)
    with pinned(ARCHIVE,'raw-cycle-work.csv').open() as stream:
        rawref={(r['mode'],int(r['subdivision'])):r for r in csv.DictReader(stream) if r['kind']=='first_control'}
    raw=[]
    for mode,branch,sub in CASES:
        row=rawref[mode,sub]
        ref=complex(float(row[branch+'_C_real']),float(row[branch+'_C_imag']))
        with np.load(ROOT/('work-'+label(mode,branch,sub)+'.npz')) as bank:
            assert np.array_equal(bank['edges'][:2],[float(row['begin']),float(row['end'])])
            val=bank['sums'][0]
        err=100*abs(val-ref)/abs(ref)
        raw.append(dict(mode=mode,branch=branch,subdivision=sub,real=val.real,imag=val.imag,relative_pct=err,passes=bool(err<=.5)))
    table('first-raw.csv',raw)
    _,axis,weights,_=gate.proj.old.get_media()
    measure=gate.previous.make_measure(axis,weights)
    def mag(vec):
        return gate.mag(vec,measure)
    def share(vec,ref):
        return 100*(measure@(vec*ref.conj()).real).sum()/mag(ref)[2]**2
    with gate.pin(gate.FROZEN,'window-readouts.csv').open() as stream:
        launch={r['gravity']:float(r['launch_norm']) for r in csv.DictReader(stream) if r['model']=='MTS-minus-baseline' and r['output']=='joint'}
    target,controls,budget,kicks,physical,cache=[],[],[],[],[],{}
    def check(rows,mode,setting,kind,key,vec,ref):
        err=100*mag(vec-ref)/mag(ref)
        assert np.isfinite(err).all()
        rows.append(dict(mode=mode,setting=setting,test=kind,channel=key,energy_pct=err[0],current_pct=err[1],joint_pct=err[2],passes=bool(max(err)<=.5)))
    for setting in SETTINGS:
        name=f'photons-{setting}.npz'
        with np.load(ROOT/name) as new,np.load(pinned(ARCHIVE,name)) as saved,np.load(frozen(DRIFT,name,'prediction-freeze.json')) as drifts,np.load(frozen(PARTIAL,name,'prediction-freeze.json')) as tail,np.load(original(f'photon-{setting}.npz')) as old,np.load(previous(f'launch-change-{setting}.npz')) as prep:
            grid=new['scale']
            assert all(np.array_equal(grid,q['scale']) for q in (saved,drifts,tail,prep)) and np.array_equal(grid,old['grid'])
            assert old['channels'].tolist()[:3]==['kick','rate','lapse']
            def view(vec):
                return CubicSpline(grid,vec)(axis)
            for idx,mode in enumerate(MODES):
                def unpack(q):
                    assert q['modes'].tolist()==list(MODES)
                    return dict(zip(q['channels'].tolist(),view(q['values'][:,idx,0]).swapaxes(0,1),strict=True))
                pred,ref,prior_drift,prior_tail=(unpack(q) for q in (new,saved,drifts,tail))
                old_channels=view(old['values'][:,old['labels'].tolist().index([mode,'primary']),:3])
                prep_channels=view(prep['values'][:,prep['labels'].tolist().index([mode,'primary'])])
                norm=mag(old_channels.sum(1))
                def record(kind,key,vec):
                    amp=100*mag(vec)/norm
                    budget.append(dict(mode=mode,setting=setting,kind=kind,channel=key,energy_common_pct=amp[0],current_common_pct=amp[1],
                                       joint_common_pct=amp[2],signed_share_saved_full_pct=share(vec,ref['full'])))
                for prefix in ('','half_'):
                    for key,targetkey in [('first','first'),('core','full'),('full','full'),('osc','osc')]:
                        check(target,mode,setting,'archive',prefix+key,pred[prefix+key],ref[prefix+targetkey])
                    for key,vec,base in [('branch_difference',pred[prefix+'first_matched']-pred[prefix+'first_wave'],'first'),
                                         ('primitive',pred[prefix+'first_primitive'],'first'),
                                         ('frozen_core',pred[prefix+'first']+prior_drift[prefix+'drift']+prior_tail[prefix+'partial'],'core'),
                                         ('osc_plus_core',pred[prefix+'core']+pred[prefix+'osc'],'full')]:
                        check(controls,mode,setting,key,prefix+base,vec,pred[prefix+base])
                for key in [k for k in pred if not k.startswith('half_')]:
                    record('forecast',key,pred[key])
                    check(controls,mode,setting,'source_subdivision',key,pred['half_'+key],pred[key])
                    cache[mode,setting,key]=pred[key]
                for key in ('first','full','osc','drift','partial'):
                    record('archive',key,ref[key])
                kick=old_channels[:,0]+prep_channels[:,0]
                no_kick=(old_channels[:,1:]+prep_channels[:,1:]).sum(1)
                momentum=kick+no_kick
                differentiated=kick+(no_kick+pred['full'])
                check(controls,mode,setting,'common_kick_cancellation','full',differentiated-momentum,pred['full'])
                with np.load(legacy.path(mode,'base','curves')) as model,np.load(previous(f'metric-{mode}-4.npz')) as metric:
                    old_kick=model['kick'].item()
                    prep_kick=metric['kick'].item()
                with np.load(ROOT/f'launch-{mode}-matched-4.npz') as lm,np.load(ROOT/f'launch-{mode}-wave-4.npz') as lw:
                    switch_delta=lm['launch'][12]-lw['launch'][12]
                    assert prep_kick==lm['prep_kick']
                kick_err=100*abs(switch_delta-old_kick-prep_kick)/abs(old_kick+prep_kick)
                assert np.isfinite(kick_err)
                kicks.append(dict(mode=mode,setting=setting,original_real=old_kick.real,original_imag=old_kick.imag,
                                  prep_real=prep_kick.real,prep_imag=prep_kick.imag,switch_delta_real=switch_delta.real,switch_delta_imag=switch_delta.imag,
                                  entry_agreement_pct=kick_err,entry_pass=bool(kick_err<=.5),kick_joint_pct_of_launch=100*mag(kick)[2]/launch[mode]))
                amps=100*mag(pred['full'])/norm
                sm=100*mag(momentum)[2]/launch[mode]
                sd=100*mag(differentiated)[2]/launch[mode]
                physical.append(dict(mode=mode,setting=setting,energy_gap_pct=amps[0],current_gap_pct=amps[1],joint_gap_pct=amps[2],
                                     gap_pass=bool(max(amps)<=.5),momentum_pct_of_launch=sm,differentiated_pct_of_launch=sd,size_pass=bool(max(sm,sd)<=.163)))
    for mode in MODES:
        for key in ('first','full','core','osc','drift','partial','first_matched','first_wave','first_primitive'):
            for setting in ('time','angle'):
                check(controls,mode,'primary','photon_'+setting,key,cache[mode,setting,key],cache[mode,'primary',key])
            if mode=='p32':
                check(controls,mode,'primary','gravity',key,cache['p16','primary',key],cache[mode,'primary',key])
    for name,rows in [('comparisons.csv',target),('numerics.csv',controls),('readouts.csv',budget),('common-kick.csv',kicks),('physical-gates.csv',physical)]:
        table(name,rows)
    print('forecasts, controls and branch endpoints (counts / failures)',[(len(rows),sum(not r['passes'] for r in rows)) for rows in (target,controls,raw)])
if __name__=='__main__':
    run()
