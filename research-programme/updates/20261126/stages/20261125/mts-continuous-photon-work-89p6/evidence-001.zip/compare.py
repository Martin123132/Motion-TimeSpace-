import csv
from continuous_stage import ROOT,guard,locked,pin,MODES,SETTINGS
from photons import io,gate,np
from scipy.interpolate import CubicSpline
from cell89 import pin as legacy
import density_stage,average_stage
io.ROOT=ROOT
def ratio(x,y):
    den=np.max(abs(y));assert den>0
    return np.max(abs(x-y))/den
def trajectory_tests():
    rows=[]
    for mode in MODES:
        for split in (2,4):
            with np.load(ROOT/f'carry-{mode}-{split}.npz') as new,np.load(pin(f'density-{mode}-{split}.npz')) as older:
                knots=new['grid'];time=new['gravity'];assert np.array_equal(time,knots[::split]) and np.array_equal(time,older['time'])
                x=new['matched_state'][::split]
                tests=dict(density_vs_continuity=ratio(x[:,-3]+3*x[:,-1],older['density'][0]),current_vs_continuity=ratio(x[:,-2],older['current'][0]),mismatch_vs_continuity=ratio(older['mean'][:,0]-x[:,-3]-3*x[:,-1],older['mismatch'][0]))
                for i,k in enumerate(('matched_increment','wave_increment','matched_C_work','wave_C_work')):tests[k]=new['checks'][i]
                for k,v in tests.items():rows.append(dict(mode=mode,split=split,check=k,relative=v,passes=bool(v<=.005)))
        with np.load(ROOT/f'carry-{mode}-2.npz') as half,np.load(ROOT/f'carry-{mode}-4.npz') as fine:
            for name in ('matched_state','wave_state','phi_split_matched','phi_split_wave'):
                a=half[name];b=fine[name][::2];den=np.max(abs(b),axis=0)
                er=float(np.max(np.max(abs(a-b),axis=0)/np.maximum(den,1e-65)))
                rows.append(dict(mode=mode,split='2vs4',check=name,relative=er,passes=bool(er<=.005)))
    io.table('trajectory-controls.csv',rows)
def compare():
    _,axis,w,_=gate.proj.old.get_media();measure=gate.previous.make_measure(axis,w)
    mag=lambda val:gate.mag(val,measure)
    with gate.pin(gate.FROZEN,'window-readouts.csv').open() as fp:
        launch={r['gravity']:float(r['launch_norm']) for r in csv.DictReader(fp) if r['model']=='MTS-minus-baseline' and r['output']=='joint'}
    gates=[];scores=[];controls=[];sector=[];cache={}
    def check(mode,setting,name,actual,target):
        error=mag(actual-target)/mag(target)
        controls.append(dict(mode=mode,setting=setting,check=name,energy_relative=error[0],current_relative=error[1],joint_relative=error[2],passes=bool(max(error)<=.005)))
    for setting in SETTINGS:
        name='photons-'+setting+'.npz'
        with np.load(ROOT/name) as found,np.load(pin(name)) as previous,np.load(density_stage.pin('reference/'+name)) as archived,np.load(average_stage.pin(name)) as branch,np.load(legacy('photon-'+setting+'.npz')) as normalizer:
            grid=found['scale'];assert all(np.array_equal(grid,g) for g in (previous['scale'],archived['scale'],branch['scale'],normalizer['grid']))
            proj=lambda x:CubicSpline(grid,x)(axis)
            for idx,mode in enumerate(MODES):
                def terms(z):
                    vals=proj(z['values'][:,idx,0]);return {k:vals[:,i] for i,k in enumerate(z['channels'].tolist())}
                v=terms(found);orig=terms(archived);prev=terms(previous);br=terms(branch)
                target=orig['actual_total'];mom=proj(normalizer['values'][:,normalizer['labels'].tolist().index([mode,'primary']),:3].sum(1));den=mag(mom)
                check(mode,setting,'archive_identity',br['matched']-br['blind'],target)
                check(mode,setting,'branch_identity',v['matched']-v['wave'],v['total'])
                check(mode,setting,'sector_identity',v['pair']+v['ordinary']+v['supplied'],v['total'])
                check(mode,setting,'pair_identity',v['heavy']+v['metric'],v['pair'])
                check(mode,setting,'normalization_identity',v['potential_increment']+v['changing_weight'],v['total'])
                for k in ('total','pair','matched','wave','potential_increment','changing_weight'):
                    check(mode,setting,'half_vs_quarter_'+k,v['half_'+k],v[k])
                    cache[mode,setting,k]=v[k]
                vectors={'continuous':v['total'],'direct_potential':v['potential_increment'],'reset_reference':target,'previous_forecast':prev['momentum_both_total']}
                for label,vector in vectors.items():
                    pct=100*mag(vector)/den;pm=100*den[2]/launch[mode];pd=100*mag(mom+vector)[2]/launch[mode]
                    gates.append(dict(mode=mode,setting=setting,entry=label,energy_pct=pct[0],current_pct=pct[1],joint_pct=pct[2],components_pass=bool(max(pct)<=.5),momentum_launch_pct=pm,differentiated_launch_pct=pd,launch_pass=bool(max(pm,pd)<.163)))
                for label,pred,obs in [('continuous_vs_reference',v['total'],target),('continuous_vs_previous',v['total'],prev['momentum_both_total']),('continuous_pair_vs_reset_pair',v['pair'],orig['actual_pair']),('direct_vs_work',v['potential_increment'],v['total']),('matched_branch',v['matched'],br['matched']),('wave_branch',v['wave'],br['blind'])]:
                    err=mag(pred-obs)/mag(obs);signed=np.sum(measure@(pred*obs.conj()).real)/mag(obs)[2]**2
                    scores.append(dict(mode=mode,setting=setting,comparison=label,energy_error_pct=100*err[0],current_error_pct=100*err[1],joint_error_pct=100*err[2],joint_error_common_pct=100*mag(pred-obs)[2]/den[2],signed_share=signed,agreement=bool(max(err)<=.005)))
                change=v['total']-target
                for label,vect in [('matched_change',v['matched']-br['matched']),('negative_wave_change',br['blind']-v['wave'])]+[(k+'_change',v[k]-orig['actual_'+k]) for k in ('heavy','metric','ordinary','supplied')]+[(k,v[k]) for k in ('matched','wave','pair','potential_increment','changing_weight')]:
                    amp=100*mag(vect)/den
                    sector.append(dict(mode=mode,setting=setting,term=label,energy_common_pct=amp[0],current_common_pct=amp[1],joint_common_pct=amp[2],signed_along_change=np.sum(measure@(vect*change.conj()).real)/mag(change)[2]**2))
    for mode in MODES:
        for k in ('total','pair','matched','wave','potential_increment','changing_weight'):
            base=cache[mode,'primary',k]
            for caption,mo,s in [('photon_time',mode,'time'),('angle',mode,'angle')]+([('gravity','p16','primary')] if mode=='p32' else []):
                check(mode,'primary',caption+'_'+k,cache[mo,s,k],base)
    for name,rows in [('gates',gates),('signed-comparisons',scores),('reset-attribution',sector),('photon-controls',controls)]:io.table(name+'.csv',rows)
if __name__=='__main__':
    guard();locked('source-freeze.json');locked('photon-freeze.json')
    trajectory_tests();compare()
