from continuous_stage import ROOT,guard,locked,freeze,pin,SETTINGS
from types import SimpleNamespace
from unittest.mock import patch
pin('transport_density.py')
from transport_density import io,transport,gate,np
io.ROOT=ROOT
def packet(mode,unused):
    with np.load(ROOT/f'carry-{mode}-4.npz') as fine,np.load(ROOT/f'carry-{mode}-2.npz') as half:
        grid=fine['grid'];assert np.array_equal(grid[::2],half['grid'])
        cols={}
        for idx,key in enumerate(fine['channels'].tolist()):
            cols[key]=fine['values'][:,idx]/np.diff(grid)
            if key in ('total','pair','matched','wave','potential_increment','changing_weight'):
                cols['half_'+key]=np.repeat(half['values'][:,idx]/np.diff(half['grid']),2)
        return SimpleNamespace(time=fine['gravity'],knots=grid,values=np.column_stack(list(cols.values())),keys=list(cols)),None
if __name__=='__main__':
    guard();locked('source-freeze.json')
    with patch.object(transport,'ROOT',ROOT),patch.object(transport,'source',packet):
        for setting in SETTINGS:transport.project(setting);print(setting,flush=True)
    freeze('photon-freeze.json',['source-freeze.json']+[f'photons-{s}.npz' for s in SETTINGS])
