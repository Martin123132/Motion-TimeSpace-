from pathlib import Path
import hashlib,json,sys
ROOT=Path(__file__).resolve().parent
PRE=ROOT.parent/'mts-switch-density-continuity-89p6-20261125'
SEAL='a0cf5e52eb4274136ac70c2854a59dec3ad2d9197a46fada2a8cbbb21bdca411'
MODES=('p16','p32')
SETTINGS=('primary','time','angle')
def digest(path):
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
assert digest(PRE/'seal.json')==SEAL
files=json.loads((PRE/'seal.json').read_bytes())['files']
def pin(name):
    path=PRE/name;assert digest(path)==files[name],name
    return path
def guard():assert all(not (p/'STOP-REQUESTED').exists() for p in (ROOT,PRE))
def save(name,obj):
    path=ROOT/name
    if path.exists():assert json.loads(path.read_bytes())==obj,name
    else:path.write_text(json.dumps(obj,indent=2,sort_keys=True,allow_nan=False)+'\n',encoding='utf8')
def freeze(name,parts):save(name,dict(prior=SEAL,files={p:digest(ROOT/p) for p in parts}))
def locked(name):
    obj=json.loads((ROOT/name).read_bytes());assert obj['prior']==SEAL
    for part,expected in obj['files'].items():assert digest(ROOT/part)==expected,part
sys.path.insert(0,str(PRE));pin('density_stage.py')
