from continuous_stage import ROOT,SEAL,guard,locked,freeze,save,digest,MODES,SETTINGS
import ast,csv,re
import numpy as np
def read(name):
    with (ROOT/name).open() as fp:return list(csv.DictReader(fp))
def verify():
    guard();locked('source-freeze.json');locked('photon-freeze.json')
    tr=read('trajectory-controls.csv');pc=read('photon-controls.csv');g=read('gates.csv');sc=read('signed-comparisons.csv')
    assert (len(tr),len(pc),len(g),len(sc))==(36,96,24,36)
    assert all(r['passes']==str(float(r['relative'])<=.005) for r in tr)
    assert all(r['passes']==str(max(float(r[k+'_relative']) for k in ('energy','current','joint'))<=.005) for r in pc)
    assert all(r['agreement']==str(max(float(r[k+'_error_pct']) for k in ('energy','current','joint'))<=.5) for r in sc)
    for r in g:
        assert r['components_pass']==str(max(float(r[k+'_pct']) for k in ('energy','current','joint'))<=.5)
        assert r['launch_pass']==str(max(float(r[k+'_launch_pct']) for k in ('momentum','differentiated'))<.163)
    for mode in MODES:
        with np.load(ROOT/f'carry-{mode}-2.npz') as low,np.load(ROOT/f'carry-{mode}-4.npz') as hi:
            assert np.array_equal(low['grid'],hi['grid'][::2]) and np.array_equal(hi['gravity'],hi['grid'][::4])
            for k in ('matched_state','wave_state'):
                assert np.array_equal(low[k][0],hi[k][0]) and hi[k].shape==(len(hi['grid']),13) and np.isfinite(hi[k]).all()
            assert np.isfinite(hi['values']).all() and np.isfinite(low['values']).all()
    for setting in SETTINGS:
        q=read('quadrature-'+setting+'.csv');assert len(q)==2 and max(float(r['relative']) for r in q)<=.005
    for script in ROOT.glob('*.py'):ast.parse(script.read_text(encoding='utf8'))
    for name in re.findall(r'\]\(([^)]+)\)',(ROOT/'RESULTS.md').read_text(encoding='utf8')):assert (ROOT/name).is_file()
    assert not list(ROOT.rglob('__pycache__'))
    primary=[r for r in g if r['entry']=='continuous'];assert len(primary)==6
    save('validation.json',dict(prior=SEAL,source_freeze=digest(ROOT/'source-freeze.json'),photon_freeze=digest(ROOT/'photon-freeze.json'),trajectory_controls=len(tr),trajectory_passed=sum(r['passes']=='True' for r in tr),photon_controls=len(pc),photon_passed=sum(r['passes']=='True' for r in pc),continuous_component_passes=sum(r['components_pass']=='True' for r in primary),continuous_absolute_size_passes=sum(r['launch_pass']=='True' for r in primary),continuous_decisions=len(primary)))
    freeze('seal.json',sorted(p.name for p in ROOT.iterdir() if p.is_file() and p.name!='seal.json'))
    print(digest(ROOT/'seal.json'))
if __name__=='__main__':verify()
