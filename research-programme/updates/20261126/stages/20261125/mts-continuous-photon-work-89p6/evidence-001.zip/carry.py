from continuous_stage import ROOT,MODES,pin,guard,freeze
from unittest.mock import patch
from types import SimpleNamespace
pin('inputs_density.py')
from inputs_density import Drivers,source,subgrid,Blind,Wave,np,io
from forecast_pair import forms,step
import average_stage
io.ROOT=ROOT
def forbidden(*args,**kwargs):raise RuntimeError('No trajectory lookups after switch.')
def matrix(solver,time,side):
    env=solver.env(time,side);assert 'U' not in env[1]
    zero=np.zeros((len(time),13),complex);offset=solver.rhs(env,zero)
    result=np.zeros((len(time),14,14),complex);result[:,:-1,-1]=offset
    for index in range(13):
        trial=zero.copy();trial[:,index]=1
        result[:,:-1,index]=solver.rhs(env,trial)-offset
    return result
def evolve(src,entry,grid,is_wave):
    solver=Wave(src) if is_wave else Blind(src)
    corners=np.asarray(src.corners);cuts=np.unique(np.r_[grid,corners[(corners>grid[0])&(corners<grid[-1])]])
    state=np.r_[entry.copy(),1+0j];steps=[];history=[entry.copy()]
    for first in range(0,len(cuts)-1,128):
        last=min(first+128,len(cuts)-1);left=cuts[first:last];right=cuts[first+1:last+1]
        width=right-left;mid=left+width/2;dt=width[:,None,None];unit=np.eye(14)
        first_rate=matrix(solver,left,mid)
        second=matrix(solver,left+width/3,mid)@(unit+dt*first_rate/3)
        third=matrix(solver,right-width/3,mid)@(unit+dt*(second-first_rate/3))
        fourth=matrix(solver,right,mid)@(unit+dt*(first_rate-second+third))
        changes=dt*(first_rate+3*second+3*third+fourth)/8
        for transition in changes:
            delta=transition@state;state=state+delta
            steps.append(delta[:-1]);history.append(state[:-1].copy())
    index=np.searchsorted(cuts,grid);assert np.array_equal(cuts[index],grid)
    trajectory=np.array(history)[index];delta=np.add.reduceat(np.array(steps),index[:-1],axis=0)
    ix=np.unique(np.r_[0,np.linspace(0,len(grid)-2,17,dtype=int),len(grid)-2])
    direct=step(solver,grid[:-1][ix],grid[1:][ix],trajectory[:-1][ix][None])[0]
    control=float(np.max(np.max(abs(direct-delta[ix]),axis=0)/np.maximum(np.max(abs(direct),axis=0),1e-65)))
    assert control<.005,control
    assert np.isfinite(trajectory).all() and np.array_equal(trajectory[0],entry)
    env=src.environment(grid);weights,external,den=forms(env,src.kk,src.wave,is_wave)
    parts=np.einsum('ntk,nk->nt',weights[1:],delta)+np.einsum('ntk,nk->nt',np.diff(weights,axis=0),trajectory[:-1])+np.diff(external,axis=0)
    supplied=env[1]['U'];defect=np.diff(supplied)-parts.sum(1)
    energy,current=solver.aggregate(env,trajectory[:,:-1])
    residual=supplied-(den*trajectory[:,-1]+energy/2+1.5*env[0]['h']*current/src.kk)
    impulses=defect/den[1:];direct_phi=np.diff(residual/den)
    weight_term=residual[:-1]*(np.diff(den)/(den[:-1]*den[1:]))
    budget=float(np.max(abs(impulses-direct_phi-weight_term))/np.max(abs(impulses)))
    assert budget<.005,(is_wave,budget)
    return dict(state=trajectory,parts=parts/den[1:,None],supplied=np.diff(supplied)/den[1:],gap=impulses,
        direct_phi=direct_phi,weight=weight_term,residual=residual,den=den,control=control,work_identity=budget)
def build(mode):
    matched=Drivers(mode);average_stage.pin(f'native-{mode}.npz');wave=source(mode);gravity=matched.time
    assert np.array_equal(wave.time,gravity)
    with np.load(pin(f'density-{mode}-4.npz')) as previous:ms=previous['entry']
    ws=wave.interp(gravity[:1])[0];ws[-1]=wave.phi(gravity[0])
    with patch.object(wave,'interp',forbidden),patch.object(wave,'phi',forbidden),patch.object(wave,'p',forbidden):
        for split in (2,4):
            grid=subgrid(gravity,split);mat=evolve(matched,ms,grid,False);wv=evolve(wave,ws,grid,True)
            parts=wv['parts']-mat['parts'];sup=mat['supplied']-wv['supplied']
            total=mat['gap']-wv['gap'];pair=parts[:,:2].sum(1)
            channels=dict(total=total,pair=pair,matched=mat['gap'],wave=wv['gap'],heavy=parts[:,0],metric=parts[:,1],ordinary=parts[:,2],supplied=sup,
                potential_increment=mat['direct_phi']-wv['direct_phi'],changing_weight=mat['weight']-wv['weight'])
            scale=np.max(abs(total))
            assert np.max(abs(total-pair-parts[:,2]-sup))/scale<1e-8
            assert np.max(abs(total-channels['potential_increment']-channels['changing_weight']))/scale<.005
            io.pack(f'carry-{mode}-{split}.npz',grid=grid,gravity=gravity,channels=list(channels),values=np.column_stack(list(channels.values())),
                matched_state=mat['state'],wave_state=wv['state'],checks=[mat['control'],wv['control'],mat['work_identity'],wv['work_identity']],
                phi_split_matched=mat['residual']/mat['den'],phi_split_wave=wv['residual']/wv['den'])
            print(mode,split,'checked',mat['control'],wv['control'],flush=True)
if __name__=='__main__':
    guard()
    for mode in MODES:build(mode)
    freeze('source-freeze.json',['continuous_stage.py','PROTOCOL.md','carry.py','photons.py']+[f'carry-{m}-{s}.npz' for m in MODES for s in (2,4)])
