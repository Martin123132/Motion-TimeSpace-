from paired_clock import check
from mass_scope import *
from monochart import Cold,Wave
from ruler import separate


def run(grid,seed):
    digest=check()
    tag=f"g{grid}-s{seed}"
    with environment(grid):
        values={}
        for flag in (0,1):
            model=Cold(seed,"adm") if flag else Wave(seed,"adm")
            for tick in (256,512,768,1024):
                name=tag+f"-off{flag}-t{tick}.npz"
                cert=json.loads((HERE/(name+".json")).read_bytes())
                assert cert["sha"]==core.sha(HERE/name) and cert["freeze"]==digest
                with np.load(HERE/name) as data:
                    actual=Difference(data["physical_shared"],data["physical_signed"])
                    clock=tick*float(data["step"])
                host=separate(model.host,clock,actual)
                zero=separate(model.zero,clock,actual.base)
                for key in host:values[(flag,tick,*key)]=host[key]-zero[key]
        result=[]
        for row in core.read(HERE/(tag+"-scores.csv")):
            tick=int(row["tick"]);width=float(row["width"]);channel=row["channel"]
            def difference(key):
                return values[0,tick,width,channel,key]-values[1,tick,width,channel,key]
            unit=abs(float(row["newton"]))*1e-6
            forecast=float(row["prediction"])
            full=(difference("full")-forecast)/unit
            field=(difference("sampled_field")-forecast)/unit
            jacobian=difference("local_jacobian")/unit
            ruler=difference("integrated_distance")/unit
            discrepancy=abs(full-float(row["residual_ppm"]))
            assert discrepancy<.01 and abs(full-field-jacobian-ruler)<.01
            result.append(dict(tick=tick,width=width,channel=channel,field_ppm=field,jacobian_ppm=jacobian,
                               ruler_ppm=ruler,full_ppm=full,replay_mismatch_ppm=discrepancy))
        local.table(tag+"-ruler.csv",result)
    print("ruler replay",tag,flush=True)


if __name__=="__main__":run(*map(int,sys.argv[1:]))
