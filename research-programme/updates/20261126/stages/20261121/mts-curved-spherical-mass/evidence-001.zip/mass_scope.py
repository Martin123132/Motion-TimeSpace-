import sys
import json
from pathlib import Path
from contextlib import contextmanager
HERE=Path(__file__).resolve().parent
PARENT=HERE.parent/"mts-adjoint-radial-current-20261121"
sys.path.insert(0,str(PARENT))
import bridge,evolve8,lift8,local,scope,case
from mts_sbp12 import Regular
from bridge import core,np,patch,Difference
from decimal import getcontext
from read_clock import canonical_reader
from readouts import member_readings
import ref_endpoint,phase_stride


def lock():
    bridge.locked()
    seal=PARENT/"seal.json"
    assert core.sha(seal)=="ab387d9fec244bd40f24bda4b6e9819d2a6987e6e9185a75a28a737659a36855"
    for name,digest in json.loads(seal.read_bytes())["files"].items():
        assert core.sha(PARENT/name)==digest,name
    guard()


def guard():
    bridge.guard()
    if (HERE/"STOP-REQUESTED").exists() or (PARENT/"STOP-REQUESTED").exists():raise RuntimeError("owner hold")


@contextmanager
def environment(grid):
    getcontext().prec=50
    def system(flag,seed,scheme):
        with patch.object(case.parent.evolve_speed,"launch",case.parent.launch):
            return case.parent.evolve_speed.system(1024,grid,flag,seed,scheme,3)[0]
    with patch.object(local,"HERE",HERE),patch.object(case.parent,"system",system),patch.object(lift8,"Radial",Regular):
        yield


def read_tide(model,time,actual):
    old=ref_endpoint.fixed_tide
    def read(shell,start,change):return canonical_reader(shell,start,change,old)
    with patch.object(ref_endpoint,"fixed_tide",read),patch.object(phase_stride,"fixed_tide",read):
        host=member_readings(model.host,time,actual)
        zero=member_readings(model.zero,time,actual.base)
    return {key:host[key]-zero[key] for key in host}
