from paired_clock import check,lock,core,HERE,PARENT
from pathlib import Path
import csv
import json
import math
import sys


def rows(name):
    with (HERE/name).open(encoding="utf-8-sig",newline="") as file:return list(csv.DictReader(file))


def verify():
    lock()
    frozen=check()
    snapshot_count=0
    for grid,seed in ((320,1),(640,1),(640,-1)):
        tag=f"g{grid}-s{seed}"
        for flag in (0,1):
            for tick in (256,512,768,1024):
                name=f"{tag}-off{flag}-t{tick}.npz"
                receipt=json.loads((HERE/(name+".json")).read_bytes())
                assert receipt["freeze"]==frozen and receipt["sha"]==core.sha(HERE/name)
                assert receipt["min_branch"]>0 and (flag or min(receipt["min_factor"],receipt["min_number"])>0)
                snapshot_count+=1
        table=rows(f"{tag}-scores.csv")
        assert len(table)==16 and len(set((row["tick"],row["width"],row["channel"]) for row in table))==16
        for row in table:
            ppm=(float(row["measured"])-float(row["prediction"]))/(1e-6*abs(float(row["newton"])))
            assert math.isfinite(ppm) and ppm==float(row["residual_ppm"]) and (abs(ppm)<=20)==(row["inside"]=="True")
        assert len(rows(tag+"-physical-work.csv"))==120 and len(rows(tag+"-pointwise.csv"))==24
        assert len(rows(tag+"-charge.csv"))==4
        decomposition=rows(tag+"-ruler.csv")
        assert len(decomposition)==16 and all(float(row["replay_mismatch_ppm"])<.01 for row in decomposition)
        if grid==640:assert len(rows(tag+"-old-mode.csv"))==8
    witness=rows("curved-external-work-witness.csv")
    assert len(witness)==30 and len({(row["cells"],row["observable"],row["region"]) for row in witness})==30
    assert all(float(row[key])>0 for row in witness for key in ("Cmax","Pmax","external_energy_rate","external_momentum_rate"))
    assert max(float(row["relative"]) for row in witness if int(row["cells"])==256)<1e-7
    assert len(rows("signed-angular-constraints.csv"))==36 and len(rows("point-charge-crosscheck.csv"))==12
    assert (HERE/"METHOD.md").is_file() and (HERE/"RESULTS.md").is_file()
    files={item.name:core.sha(item) for item in sorted(HERE.iterdir()) if item.is_file() and item.name!="seal.json"}
    certificate=dict(parent=core.sha(PARENT/"seal.json"),freeze=frozen,snapshots=snapshot_count,files=files)
    target=HERE/"seal.json"
    if target.exists():assert json.loads(target.read_bytes())==certificate
    else:
        assert sys.argv[1:]==["seal"]
        with target.open("x",encoding="utf-8",newline="\n") as out:out.write(json.dumps(certificate,indent=2)+"\n")
    print(len(files),"files;",snapshot_count,"snapshot receipts; SHA256",core.sha(target),flush=True)


if __name__=="__main__":verify()
