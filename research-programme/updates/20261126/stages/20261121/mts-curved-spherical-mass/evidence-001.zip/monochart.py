from mass_scope import *
from native import background
from trial import sources


def log1plus(arr):
    return Difference(np.log1p(arr.base),np.log1p(arr.delta/(1+arr.base))) if isinstance(arr,Difference) else np.log1p(arr)


def both_min(arr):
    return min(float(np.min(arr.base)),float(np.min(arr.base+arr.delta)))


class MassChart:
    def __init__(self,model):
        self.model=model
        self.mesh=model.lift.mesh
        self.shell=model.shell
        self.r=self.mesh.r
        self.rf=self.mesh.faces[1:]
        zero=np.zeros_like(self.shell.initial)
        bg=background(model,zero)
        self.b0=bg["bend"]
        self.ell0=bg["ell"]
        start=self.shell.initial
        self.ka0=-start[4,0].real/3-start[5,0].real
        self.kb0=-start[4,0].real/3+start[5,0].real/2
        self.f0=1+self.r*bg["bg"]
        self.f0face=1+self.rf*self.mesh.odd_face(bg["bg"])[1:]
        self.kprime=self.der(self.kb0)
        self.B0=self.r*np.exp(self.b0)
        self.jstar0=self.r*self.kprime/self.f0+1.5*start[5,0].real
        self.uc0=bg["scale"]*self.f0
        self.energy0=bg["R"]/2+2*self.ka0*self.kb0+self.kb0**2
        rb=self.r*bg["bg"]
        one_minus_u2=-np.expm1(2*(self.b0-self.ell0))-bg["scale"]**2*rb*(2+rb)
        self.wc0=(np.exp(3*self.b0)*self.kb0**2+np.exp(self.b0)*one_minus_u2/self.r**2)/2
        self.w0=self.face(self.wc0)
        self.q0=self.face(2*self.uc0*self.jstar0/(self.r*self.B0))
        self.bf0=self.face(self.b0)
        self.kbf0=self.face(self.kb0)
        self.u0=np.sqrt(1+self.rf**2*(np.exp(2*self.bf0)*self.kbf0**2-2*self.w0*np.exp(-self.bf0)))
        self.L0=np.exp(self.bf0)*self.q0/(2*self.u0)
        self.min_branch=1.

    def face(self,arr):
        return self.mesh.face(arr)[1:]

    def centre(self,arr):
        origin=(8*arr[:1]/5-4*arr[1:2]/5+8*arr[2:3]/35-arr[3:4]/35)
        return self.mesh.centre(np.concatenate((origin,arr)))

    def der(self,arr):
        return self.mesh.odd_centre(self.mesh.grad(arr))

    def decode(self,state):
        r,rf=self.r,self.rf
        dw,db,dk,dq=(state[index,0].real for index in (0,1,4,5))
        d_bf,d_kf=self.face(db),self.face(dk)
        bf=self.bf0+d_bf;kf=self.kbf0+d_kf
        wf=self.w0+dw;q=self.q0+dq
        ds=np.exp(2*self.bf0)*(np.expm1(2*d_bf)*kf**2+d_kf*(2*self.kbf0+d_kf))
        ds-=2*np.exp(-self.bf0)*(dw+np.expm1(-d_bf)*wf)
        uratio=log1plus(rf**2*ds/self.u0**2)/2
        U=self.u0*np.exp(uratio)
        factor=np.exp(self.bf0)/(2*self.u0)
        dL=factor*(dq+np.expm1(d_bf-uratio)*q)
        L=self.L0+dL
        df=r*self.der(db);f=self.f0+df
        delta_ell=db+log1plus(df/self.f0)-r**2*self.centre(uratio/rf**2)
        dka=dk+r*(self.der(dk)-self.kprime*df/self.f0)/f-r**2*self.centre(dL)
        mapped=state.copy()
        mapped[0,0]=delta_ell
        mapped[4,0]=-dka-2*dk
        mapped[5,0]=2*(dk-dka)/3
        b=self.b0+db;kb=self.kb0+dk;ka=self.ka0+dka
        Jstar=self.jstar0+r**2*self.centre(dL)
        vol=np.exp(-3*db)/(1+df/self.f0)
        flux=self.mesh.back(self.mesh.full(rf**3*dw))
        Eg=(self.energy0+2*self.kb0*self.jstar0)*vol+2*flux*np.exp(-3*b)/(r**2*f)-2*kb*Jstar
        face_Bp=np.exp(bf)*(self.f0face+rf*self.mesh.grad(db)[1:])
        self.min_branch=min(self.min_branch,both_min(U),both_min(f),both_min(face_Bp))
        if not self.min_branch>0:raise FloatingPointError("lost outward mass chart")
        return mapped,dict(ka=ka,kb=kb,kf=kf,b=b,bf=bf,U=U,L=L,q=q,w=wf,wc=self.wc0+self.centre(dw),
                           Jstar=Jstar,Eg=Eg,f=f,Bp=face_Bp,dkprime=self.kprime+self.der(dk))

    def push(self,aux,energy,pr,shear):
        r,rf=self.r,self.rf
        ka,kb,kf,b,bf,U,q,w=(aux[key] for key in ("ka","kb","kf","b","bf","U","q","w"))
        err=aux["Eg"]-energy
        accel=-np.exp(-3*b)*aux["wc"]-(pr+err)/2
        kbdot=accel-kb**2
        face_kdot=self.face(kbdot)
        expbf=np.exp(bf)
        qdot=-2*self.face(ka+kb)*q-(U/aux["Bp"])*self.mesh.grad(err+pr)[1:]/rf-3*U*self.face(shear)/(rf**2*expbf)
        wd=kf*w+np.exp(3*bf)*kf*(face_kdot+kf**2)-np.exp(2*bf)*U*q/2
        Ldot=expbf*(qdot+q*(kf-rf**2*aux["L"]))/(2*U)
        warped=r*aux["dkprime"]/aux["f"]
        kadot=kbdot+r*self.der(kbdot)/aux["f"]-warped**2-r**2*self.centre(Ldot)
        stresswork=-(np.exp(3*bf)*kf*self.face(pr+err)+np.exp(2*bf)*U*q)/2
        return (wd,kb,kbdot,qdot),-kadot-2*kbdot,dict(C=err,work=stresswork,work_defect=wd-stresswork,ka_dot=kadot,accel=accel)

    def inputs(self,time,mapped):
        std=self.model.lift.physical(mapped,time)[0]
        physical=std if self.shell.flag else self.model.to_wave(std)
        energy,total,shear,_,__=sources(self.model,time,physical)
        return energy[0],total[0]/3+shear[0],shear[0]

    def finish(self,time,mapped,aux,out):
        rates,Kdot,_=self.push(aux,*self.inputs(time,mapped))
        if not self.shell.flag:
            out[15,0]-=(Kdot-out[4,0].real)/(2*self.shell.mu)
        for index,rate in zip((0,1,4,5),rates,strict=True):
            out[index,0]=rate
        return out


class Wave(evolve8.Wave):
    def __init__(self,seed,scheme):
        super().__init__(seed,scheme)
        self.mass=MassChart(self)

    def nonlinear(self,time,state):
        mapped,aux=self.mass.decode(state)
        return self.mass.finish(time,mapped,aux,super().nonlinear(time,mapped))


class Cold(evolve8.Cold):
    def __init__(self,seed,scheme):
        super().__init__(seed,scheme)
        self.mass=MassChart(self)

    def rhs(self,time,state):
        mapped,aux=self.mass.decode(state)
        return self.mass.finish(time,mapped,aux,super().rhs(time,mapped))
