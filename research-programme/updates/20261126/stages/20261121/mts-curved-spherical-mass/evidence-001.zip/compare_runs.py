from paired_clock import check
from mass_scope import *
from monochart import Cold
from scipy.interpolate import CubicSpline


def compare():
    check()
    result=[]
    centre=[]
    for grid,seed in ((320,1),(640,1),(640,-1)):
        with environment(grid):
            tag=f"g{grid}-s{seed}"
            model=Cold(seed,"adm");r=model.shell.r
            master=(np.arange(480)+.5)/160
            target=master[(master>.6)&(master<2.1)]
            oldtag=f"halfstep-{grid}-s{seed}"
            with np.load(local.PREVIOUS/f"frozen-current-adm-s{seed}.npz") as frozen:
                for idx,tick in enumerate(range(256,1025,256)):
                    def diff_at(base,label):
                        with np.load(base/(label+f"-off0-t{tick}.npz")) as wave,np.load(base/(label+f"-off1-t{tick}.npz")) as dust:
                            return model.shell.rho[-1]*(wave["number"][0]-dust["number"][0])
                    profile=diff_at(HERE,tag);prev=diff_at(PARENT,oldtag)
                    linear=np.interp(target,r,profile);cubic=CubicSpline(r,profile)(target)
                    reference=f"window{idx}_charge_"
                    pred=frozen[reference+"changing"]+(frozen[reference+"canonical_launch"]-frozen[reference+"launch"])
                    nrm=np.linalg.norm
                    result.append(dict(grid=grid,seed=seed,tick=tick,linear=nrm(linear-pred)/nrm(linear),cubic=nrm(cubic-pred)/nrm(cubic),
                          interpolation_spread=nrm(cubic-linear)/nrm(cubic),change_same_grid_norm=nrm((profile-prev)[(r>.6)&(r<2.1)])/nrm(profile[(r>.6)&(r<2.1)])))
            for row in core.read(HERE/(tag+"-pointwise.csv")):
                if int(row["tick"])!=1024:continue
                centre.append(dict(grid=grid,seed=seed,flag=row["flag"],region=row["region"],component=row["component"],
                                   relative=float(row["defect_rms"])/float(row["material_source_rms"]),absolute=row["defect_rms"]))
    with environment(640):
        local.table("point-charge-crosscheck.csv",result)
        local.table("signed-angular-constraints.csv",centre)


if __name__=="__main__":compare()
