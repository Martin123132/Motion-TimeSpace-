from monochart import *
from math import sqrt


def mag(arr):
    return max(float(np.max(abs(arr.base))),float(np.max(abs(arr.delta))))


def main():
    lock()
    rows=[]
    with environment(640):
        for seed in (-1,1):
            for flag in (0,1):
                model=Cold(seed,"adm") if flag else Wave(seed,"adm")
                mass=model.mass
                init=np.zeros_like(model.shell.initial)
                mapped,aux=mass.decode(init)
                std=model.lift.physical(mapped,0.)[0]
                actual=std if flag else model.to_wave(std)
                roundtrip=max(mag(actual),mag(mapped))
                assert roundtrip==0
                assert mag(aux["Eg"]-mass.energy0)<1e-20
                U=np.sqrt(1+mass.r**2*(np.exp(2*mass.b0)*mass.kb0**2-2*np.exp(-mass.b0)*mass.wc0))
                assert mag(U-mass.uc0)<5e-15
                state=init.copy()
                for index,amplitude,grid in ((0,.0013,mass.rf),(1,-.002,mass.r),(4,.003,mass.r),(5,-.0037,mass.rf)):
                    profile=np.exp(-1.3*grid**2)*(1+.11*np.cos(2*grid))
                    state.base[index,0]=amplitude*profile
                    state.delta[index,0]=.37*seed*amplitude*profile
                mapped,aux=mass.decode(state)
                E,pr,shear=mass.inputs(0.,mapped)
                rates,Kdot,test=mass.push(aux,E,pr,shear)
                tangent=np.zeros_like(state)
                for index,rate in zip((0,1,4,5),rates,strict=True):tangent[index,0]=rate
                mask=(mass.r<2.4)
                samples=[]
                for epsilon in (1e-4,2.5e-5):
                    plus,_=mass.decode(state+epsilon*tangent)
                    minus,_=mass.decode(state-epsilon*tangent)
                    d=(plus-minus)/(2*epsilon)
                    e1=mag((d[0,0].real-aux["ka"])[mask])/mag(aux["ka"][mask])
                    e2=mag((d[4,0].real-Kdot)[mask])/mag(Kdot[mask])
                    assert max(e1,e2)<5e-7,(e1,e2)
                    samples.append(max(e1,e2))
                pulse=5e-5*np.exp(-mass.r**2)
                varied,_,__=mass.push(aux,E+pulse,pr,shear)
                amp=max(abs(pulse))
                assert mag(varied[2]-rates[2]-pulse/2)<2e-12*amp
                expected=(aux["U"]/aux["Bp"])*mass.mesh.grad(pulse)[1:]/mass.rf
                actual=varied[3]-rates[3]
                assert mag((actual-expected)[mass.rf>.1])<2e-9*amp
                assert mag(test["C"])>1e-4 and mag(aux["q"])>1e-4
                incoming=model.time_step(4096*np.pi/(1024*model.shell.mu))(0.,init)
                assert np.isfinite(incoming.base).all() and np.isfinite(incoming.delta).all()
                rows.append(dict(seed=seed,flag=flag,zero_roundtrip=roundtrip,
                    inverse_launch_U_error=mag(U-mass.uc0),first_kinematic_error=samples[0],
                    finer_kinematic_error=samples[1],manufactured_energy_defect=mag(test["C"]),source_derivative_error=mag((actual-expected)[mass.rf>.1]),
                    launch_number_margin=1 if flag else model.min_number,minimum_U_or_Bprime_factor=model.mass.min_branch))
        local.table("launch-and-tangent.csv",rows)
    print(rows[-1])


if __name__=="__main__":
    main()
