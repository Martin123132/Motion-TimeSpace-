from paired_clock import check
from monochart import *
from number_chart import mul,exp
from independent_constraints import fields
from readouts import rms


def matter_current(model,change):
    shell=model.shell
    state=shell.initial+change
    model.bind(state,change)
    try:
        normal=exp(-state[0].real)
        volume=exp(-state[0].real-2*state[1].real)
        current=state[18,0].real.copy()
        for specie in range(3 if shell.flag else 2):
            population,phase=state[8+2*specie:10+2*specie].real
            current+=shell.rho[specie]*mul(volume,population)[0]*normal[0]*shell.diff(phase)[0]
        if not shell.flag:
            wave,normal_rate=state[14:16]
            moment=normal_rate+state[4].real/(2*shell.mu)
            grad=normal[0]*shell.diff(wave)[0]/shell.mu
            current-=shell.rho[-1]*np.exp(2*wave[0].real)*(moment[0].real*grad.real+(moment[0].imag-1)*grad.imag)
        return current
    finally:
        model.active={}
        model.elapsed=None


def slices(grid,seed):
    digest=check()
    tag=f"g{grid}-s{seed}"
    audit=[];projection=[];charge=[];angular=[]
    with environment(grid):
        for flag in (0,1):
            model=Cold(seed,"adm") if flag else Wave(seed,"adm")
            mass=model.mass; shell=model.shell; radius=shell.r
            for tick in (0,256,512,768,1024):
                if tick:
                    name=tag+f"-off{flag}-t{tick}.npz"
                    receipt=json.loads((HERE/(name+".json")).read_bytes())
                    assert receipt["freeze"]==digest and core.sha(HERE/name)==receipt["sha"]
                    with np.load(HERE/name) as saved:
                        encoded=Difference(saved["shared"],saved["signed"]);time=tick*float(saved["step"])
                        phys=Difference(saved["physical_shared"],saved["physical_signed"])
                else:
                    encoded=np.zeros_like(shell.initial);time=0.;phys=encoded
                mapped,aux=mass.decode(encoded)
                stored,_,bg,_=model.lift.physical(mapped,time)
                actual=stored if flag else model.to_wave(stored)
                assert np.array_equal(actual.delta,phys.delta) and np.array_equal(actual.base,phys.base)
                energy,pr,shear=mass.inputs(time,mapped)
                rates,_,terms=mass.push(aux,energy,pr,shear)
                state=shell.initial+actual
                trace=state[4,0].real;sigma=state[5,0].real
                ka=-trace/3-sigma;kb=-trace/3+sigma/2
                B=radius*np.exp(bg["bend"]); scale=bg["scale"]
                rb=radius*bg["bg"];U=scale*(1+rb);v=B*kb
                mB=(v**2-np.expm1(2*(bg["bend"]-bg["ell"]))-scale**2*rb*(2+rb))/2
                C=bg["R"]/2+2*ka*kb+kb**2-energy
                J=2*(1.5*sigma*U/B+np.exp(-bg["ell"])*shell.diff(kb))
                jm=matter_current(model,actual);P=J-jm
                vdot=B*(rates[2]+kb**2)
                Ud=U*(kb-ka)+radius*scale*shell.diff(kb)
                geom=v*mB+B*(v*vdot-U*Ud)
                material=-B**2*(v*pr+U*jm)/2
                correction=-B**2*(v*C+U*P)/2
                expected=-mB/B-B*(pr+C)/2
                for region,sel in (("core",radius<.3),("bulk",(radius>.6)&(radius<2.1))):
                    def norm(arr):return rms(arr.delta[sel])
                    def record(key,observed,wanted):
                        amp=max(norm(observed),norm(wanted))
                        audit.append(dict(seed=seed,grid=grid,tick=tick,flag=flag,region=region,quantity=key,
                           observed_rms=norm(observed),comparison_rms=norm(wanted),absolute=norm(observed-wanted),
                           relative=norm(observed-wanted)/amp if amp else None))
                    record("areal acceleration",vdot,expected)
                    record("mass work with geometric defects",geom,material+correction)
                    record("mass work physical source only",geom,material)
                    record("radial geometric versus material current",J,jm)
                    record("independent curvature density versus matter",C+energy,energy)
                    record("face mass chain versus face flux",rates[0],terms["work"])
                if grid==640 and tick:
                    with np.load(PARENT/"monopole-48.npz") as eig,np.load(PARENT/f"halfstep-640-s{seed}-off{flag}-t{tick}.npz") as old:
                        def amplitude(arr):
                            values=np.stack([arr[slot,0,:48].real for slot in (0,1,4,5)])
                            values[2:]*=shell.dx
                            return abs(np.vdot(eig["left"],values.ravel()))
                        before=amplitude(old["physical_signed"]);after=amplitude(phys.delta)
                        projection.append(dict(tick=tick,flag=flag,previous=before,current=after,ratio=after/before))
                if tick in (0,1024):
                    signed=fields(model.host,phys)-fields(model.zero,phys.base)
                    for region,sel in (("core",radius<.3),("bulk",(radius>.6)&(radius<2.1))):
                        for idx,name in enumerate(("H2","Mr2","Mtheta2")):
                            angular.append(dict(tick=tick,flag=flag,region=region,component=name,defect_rms=rms(signed[idx,sel].astype(float)),
                                                material_source_rms=rms(signed[idx+3,sel].astype(float))))
        group=grid//160
        edges=np.arange(3*grid+1)/grid;weight=np.diff(edges**3)/3
        weights=weight.reshape(-1,group).sum(axis=1)
        master=(np.arange(480)+.5)/160
        use=(master>.6)&(master<2.1)
        with np.load(local.PREVIOUS/f"frozen-current-adm-s{seed}.npz") as frozen:
            for idx,tick in enumerate(range(256,1025,256)):
                with np.load(HERE/(tag+f"-off0-t{tick}.npz")) as wave,np.load(HERE/(tag+f"-off1-t{tick}.npz")) as dust:
                    fine=shell.rho[-1]*(wave["number"][0]-dust["number"][0])
                bins=(fine*weight).reshape(-1,group).sum(axis=1)/weights
                prefix=f"window{idx}_charge_"
                prediction=frozen[prefix+"changing"]+(frozen[prefix+"canonical_launch"]-frozen[prefix+"launch"])
                error=bins[use]-prediction
                enc=np.cumsum(bins[use]*weights[use])
                charge.append(dict(tick=tick,shell_rms=rms(error)/rms(bins[use]),partial_enclosed_rms=rms(np.cumsum(error*weights[use]))/rms(enc)))
        for label,rows in (("physical-work",audit),("old-mode",projection),("charge",charge),("pointwise",angular)):
            if rows:local.table(tag+"-"+label+".csv",rows)
    print(tag,"slice checks complete",flush=True)


if __name__=="__main__":slices(*map(int,sys.argv[1:]))
