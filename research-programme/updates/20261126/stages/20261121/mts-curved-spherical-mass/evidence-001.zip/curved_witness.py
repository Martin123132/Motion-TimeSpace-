from monochart import *
from types import SimpleNamespace
import sympy as sy
from functools import lru_cache


@lru_cache(maxsize=1)
def expressions():
    radius=sy.symbols("r",positive=True)
    sq=radius**2
    b=sy.Rational(7,100)*sy.exp(-sq/2)
    kb=sy.Rational(9,100)*sy.exp(-sq/3)
    w=sy.Rational(3,125)*sy.exp(-sq/2)
    q=sy.Rational(-11,100)*sy.exp(-sq)
    E=sy.Rational(7,100)*sy.exp(-sq/4)
    pr=sy.Rational(3,100)*sy.exp(-sq/2)
    pt=pr-sq*sy.exp(-sq)/80
    j=radius*sy.exp(-sq)/75
    edot=sy.exp(-sq/3)/110
    jdot=-radius*sy.exp(-sq)/140
    B=radius*sy.exp(b);f=1+radius*sy.diff(b,radius)
    U=sy.sqrt(1+radius**2*(sy.exp(2*b)*kb**2-2*w*sy.exp(-b)))
    A=sy.exp(b)*f/U
    ell=b+sy.log(f)-sy.log(U)
    J=radius*q
    ka=kb+radius*sy.diff(kb,radius)/f-B*J/(2*U)
    K=-ka-2*kb
    Eg=2*(3*w+radius*sy.diff(w,radius))*sy.exp(-3*b)/f-B*kb*J/U
    C=Eg-E;P=J-j
    divergence=lambda arr:sy.diff(arr,radius)/A+2*U*arr/B
    etaE=edot-K*E+ka*pr+2*kb*pt+divergence(j)
    etaj=jdot-(K-ka)*j+sy.diff(pr,radius)/A+2*U*(pr-pt)/B
    cdot=2*K*C-divergence(P)-etaE
    pdot=(K-ka)*P-sy.diff(C,radius)/A-etaj
    vdot=-radius*w*sy.exp(-2*b)-B*(pr+C)/2
    wd=-sy.exp(2*b)*(sy.exp(b)*kb*(pr+C)+U*q)/2
    expr=dict(b=b,l=ell,kb=kb,ka=ka,K=K,shear=2*(kb-ka)/3,E=E,pr=pr,sr=2*(pr-pt)/3,
              j=j,edot=edot,jdot=jdot,C=C,P=P,etaE=etaE,etaj=etaj,cdot=cdot,pdot=pdot,
              wdot=wd,kbdot=vdot/B-kb**2,kadot=2*w*sy.exp(-3*b)-ka**2+pr-(E+pr+2*pt)/2-C,
              b1=sy.diff(b,radius),b2=sy.diff(b,radius,2),l1=sy.diff(ell,radius),l2=sy.diff(ell,radius,2))
    return list(expr),sy.lambdify(radius,list(expr.values()),"numpy",cse=True)


def test(grid):
    mesh=Regular(grid,3.)
    labels,func=expressions()
    cell=dict(zip(labels,func(mesh.r),strict=True));face=dict(zip(labels,func(mesh.faces[1:]),strict=True))
    zeros=np.zeros((20,2,grid),complex)
    for slot,key in ((0,"l"),(1,"b"),(4,"K"),(5,"shear")):zeros[slot,0]=cell[key]
    start=Difference(zeros,np.zeros_like(zeros))
    def deriv(arr,degree=1,odd=False):
        return mesh.odd_centre(mesh.grad(arr)) if degree==1 else mesh.back(mesh.grad(arr))
    ref=tuple({degree:np.stack((cell[name+str(degree)],0*mesh.r)) for degree in (1,2)} for name in ("l","b"))
    shell=SimpleNamespace(initial=start,r=mesh.r,diff=deriv)
    model=SimpleNamespace(shell=shell,lift=SimpleNamespace(mesh=mesh),reference=ref)
    mass=MassChart(model)
    state=np.zeros_like(start)
    _,aux=mass.decode(state)
    rates,Kdot,terms=mass.push(aux,cell["E"],cell["pr"],cell["sr"])
    tangent=np.zeros_like(state)
    for idx,rate in zip((0,1,4,5),rates,strict=True):tangent[idx,0]=rate
    step=1e-5
    plus=mass.decode(state+step*tangent)[1]["Eg"].base
    minus=mass.decode(state-step*tangent)[1]["Eg"].base
    cdot=(plus-minus)/(2*step)-cell["edot"]
    pdot=mass.rf*rates[3].base-face["jdot"]
    result=[]
    comparisons=(("Hamiltonian-transport",cdot,cell["cdot"],mesh.r),
                 ("momentum-transport",pdot,face["pdot"],mass.rf),
                 ("radial-expansion-rate",terms["ka_dot"].base,cell["kadot"],mesh.r),
                 ("areal-expansion-rate",rates[2].base,cell["kbdot"],mesh.r),
                 ("mass-work",rates[0].base,face["wdot"],mass.rf))
    for label,actual,exact,rr in comparisons:
        for region,select in (("centre",rr<.25),("bulk",(rr>.25)&(rr<2.1))):
            denom=np.linalg.norm(exact[select])
            err=np.linalg.norm((actual-exact)[select])/denom
            result.append(dict(cells=grid,observable=label,region=region,relative=err,
                               Cmax=np.max(abs(cell["C"])),Pmax=np.max(abs(face["P"])),external_energy_rate=max(abs(cell["etaE"])),
                               external_momentum_rate=max(abs(face["etaj"]))))
    return result


if __name__=="__main__":
    lock()
    rows=[]
    for grid in (64,128,256):rows.extend(test(grid))
    with environment(640):local.table("curved-external-work-witness.csv",rows)
    print("maximum on finest grid",max(row["relative"] for row in rows if row["cells"]==256),flush=True)
