from monochart import *
import argparse


def inputs():
    return {name:core.sha(HERE/name) for name in ("PROTOCOL.md","monochart.py","mass_scope.py","qualify.py","launch-and-tangent.csv","paired_clock.py")}


def freeze():
    lock()
    data=core.read(HERE/"launch-and-tangent.csv")
    assert len(data)==4 and all(float(row["zero_roundtrip"])==0 for row in data)
    with environment(640):local.manifest("freeze.json",dict(parent=core.sha(PARENT/"seal.json"),code=inputs(),
             prediction=core.sha(local.PREVIOUS/"predicted-gravity.csv"),steps=1024,phases=[256,512,768,1024],grid=[320,640],
             ppm=20,channels=["ricci","gauss"],widths=[.15,.30],qualification=data))


def check():
    meta=json.loads((HERE/"freeze.json").read_bytes())
    assert inputs()==meta["code"] and core.sha(local.PREVIOUS/"predicted-gravity.csv")==meta["prediction"]
    return core.sha(HERE/"freeze.json")


def run(grid,seed,flag):
    lock()
    digest=check()
    tag=f"g{grid}-s{seed}-off{flag}"
    with environment(grid):
        model=Cold(seed,"adm") if flag else Wave(seed,"adm")
        step=4096*np.pi/(1024*model.shell.mu)
        advance=model.time_step(step)
        state=np.zeros_like(model.shell.initial)
        initial_tick=0
        for tick in range(256,1025,256):
            name=tag+f"-t{tick}.npz"
            cert=HERE/(name+".json")
            if not cert.is_file():break
            receipt=json.loads(cert.read_bytes())
            assert receipt["sha"]==core.sha(HERE/name) and receipt["freeze"]==digest
            with np.load(HERE/name) as stored:
                assert int(stored["tick"])==tick and float(stored["step"])==step
                state=Difference(stored["shared"],stored["signed"])
            initial_tick=tick
        for tick in range(initial_tick+1,1025):
            if tick%8==1:guard()
            state=advance((tick-1)*step,state)
            if tick%256:continue
            time=tick*step
            mapped,aux=model.mass.decode(state)
            num=model.lift.physical(mapped,time)[0]
            actual=num if flag else model.to_wave(num)
            assert all(np.isfinite(arr).all() for arr in (state.base,state.delta,actual.base,actual.delta))
            assert model.mass.min_branch>0
            if not flag:assert min(model.min_number,model.min_factor)>0
            name=tag+f"-t{tick}.npz"
            local.packet(name,shared=state.base,signed=state.delta,physical_shared=actual.base,physical_signed=actual.delta,
                         number=num.delta[12 if flag else 14].real,step=step,tick=tick)
            local.manifest(name+".json",dict(freeze=digest,sha=core.sha(HERE/name),tick=tick,step=step,min_branch=model.mass.min_branch,
                                             min_number=None if flag else model.min_number,min_factor=None if flag else model.min_factor))
            print(tag,tick,flush=True)


def score(grid,seed):
    lock();digest=check()
    measured={}
    with environment(grid):
        for flag in (0,1):
            model=Cold(seed,"adm") if flag else Wave(seed,"adm")
            for tick in range(256,1025,256):
                name=f"g{grid}-s{seed}-off{flag}-t{tick}.npz"
                cert=json.loads((HERE/(name+".json")).read_bytes())
                assert cert["freeze"]==digest and core.sha(HERE/name)==cert["sha"]
                with np.load(HERE/name) as bank:
                    shift=Difference(bank["physical_shared"],bank["physical_signed"])
                    readings=read_tide(model,tick*float(bank["step"]),shift)
                for key,value in readings.items():measured[flag,tick,*key]=value
        rows=[]
        for ref in core.read(local.PREVIOUS/"predicted-gravity.csv"):
            if int(ref["seed"])!=seed or ref["mode"]!="flrw-live":continue
            tick=round(1024*float(ref["fraction"]))
            width=float(ref["width"])
            for channel in ("gauss","ricci"):
                tide=measured[0,tick,width,channel]-measured[1,tick,width,channel]
                val=(tide-float(ref["prediction"]))/(1e-6*abs(float(ref["newton"])))
                rows.append(dict(grid=grid,seed=seed,tick=tick,width=width,channel=channel,newton=ref["newton"],
                                 prediction=ref["prediction"],measured=tide,residual_ppm=val,inside=abs(val)<=20))
        assert len(rows)==16
        local.table(f"g{grid}-s{seed}-scores.csv",rows)
        print(grid,seed,sum(row["inside"] for row in rows),"/ 16; max",max(abs(row["residual_ppm"]) for row in rows),flush=True)


if __name__=="__main__":
    if sys.argv[1:]==["freeze"]:freeze()
    elif sys.argv[1]=="score":score(*map(int,sys.argv[2:]))
    else:
        grid,seed=map(int,sys.argv[1:3])
        for flag in (0,1):run(grid,seed,flag)
        score(grid,seed)
