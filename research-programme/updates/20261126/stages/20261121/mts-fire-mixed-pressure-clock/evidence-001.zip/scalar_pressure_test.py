"""Can any scalar pressure carry the passive labelled acceleration? Test circulation without differentiating noisy data."""
from trace_resolution import ring
from gas_clouds import *

def run():
    _,_,tags=bank();rows=[];meta={}
    for j,(p,obs) in enumerate(zip(OBSERVER_R,OBSERVER_MU,strict=True)):
        index=np.argmin(abs(jf.EDGES-p));a= int(np.searchsorted(jf.ANG,obs)-1)
        face=jf.EDGES[index];inner=(jf.EDGES[index-1]+face)/2;outer=(jf.EDGES[index+1]+face)/2
        ua,ub=jf.ANG[a]+np.diff(jf.ANG)[a]*np.array([.25,.75])
        taglo=tags[index-1,a];taghi=tags[index,a];sq={};counts={}
        for rad in (inner,face,outer):
            for mu in (ua,ub):
                for form in ('cubic','wendland'):sq[rad,mu,form]=0.
                counts[rad,mu]=0
        for part in range(4):
            data=clouds(part)
            for rad in (inner,face,outer):
                active=abs(data['r']-rad)<data['h']
                r,h,u,e=[data[k][active] for k in ('r','h','mu','energy')]
                for mu in (ua,ub):
                    for form in ('cubic','wendland'):
                        den=ring(r,u,h,rad,mu,form)/(4*np.pi*rad**2);sq[rad,mu,form]+=den@e
                        if form=='cubic':counts[rad,mu]+=int(np.count_nonzero(den))
        for form in ('cubic','wendland'):
            for gamma in (1.4,5/3):
                val=lambda rad,mu:(gamma-1)*sq[rad,mu,form]
                inside,edge,out=np.array([[val(rad,mu) for mu in (ua,ub)] for rad in (inner,face,outer)])
                low=taglo*(edge[0]-inside[0])+taghi*(out[0]-edge[0])
                high=taghi*(edge[1]-out[1])+taglo*(inside[1]-edge[1])
                plus=taghi*(out[1]-out[0]);minus=taglo*(inside[0]-inside[1])
                circ=low+plus+high+minus;pred=(taghi-taglo)*(edge[1]-edge[0]);norm=sum(abs(x) for x in (low,high,plus,minus))
                assert abs(circ-pred)<2e-13*max(norm,1) and np.all(edge>0)
                rows.append(dict(probe=j,shape=form,gamma=gamma,face_kpc=face,Rlo=inner,Rhi=outer,
                    mu_A=ua,mu_B=ub,weight_minus=taglo,weight_plus=taghi,
                    pressure_A=edge[0],pressure_B=edge[1],nonzero_A=counts[face,ua],nonzero_B=counts[face,ub],
                    closed_path=circ,jump_times_tangent_change=pred,total_abs_path=norm,relative_circulation=circ/norm if norm else 0.))
    table(HERE/'scalar-pressure-circulation.csv',rows,True)
if __name__=='__main__':guard();run()
