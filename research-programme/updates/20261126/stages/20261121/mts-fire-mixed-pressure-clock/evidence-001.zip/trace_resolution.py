"""Angular resolution, radial/angle averaging, dominant contributors and the true unsummed ring trace."""
from gas_clouds import *

def ring(r,mu,h,p,obs,form):
    transverse=r*np.sqrt(1-mu**2);R=p*np.sqrt(1-obs**2);z=r*mu
    scale=4*transverse*R;out=r*0;nodes,w=gauss(16)
    for sign in (-1,1):
        d2=(transverse-R)**2+(z-sign*p*obs)**2
        angle=lambda q:2*np.arcsin(np.sqrt(np.clip((q*q*h*h-d2)/np.maximum(scale,1e-200),0,1)))
        lim=[np.zeros_like(r),angle(.5),angle(1.)]
        for lo,hi in zip(lim[:-1],lim[1:],strict=True):
            for v,f in zip(nodes,w,strict=True):
                phi=lo+(hi-lo)*(v+1)/2
                q=np.sqrt(d2+scale*np.sin(phi/2)**2)/h
                out+=np.where(q<=1,p*p/ h**3*(hi-lo)*f*shape_kernel(np.minimum(q,1.),form),0.)
    return out

def influence(vals):
    absolute=abs(vals);total=absolute.sum()
    return dict(nonzero=int((absolute>0).sum()),absolute_sum=total,max_share=absolute.max()/total,
        effective_absolute_count=total**2/(absolute@absolute),cancellation=abs(vals.sum())/total)

def run():
    lab=Launch(64);gamma=5/3;caps=(32,48,64,80,120,160);degree=np.arange(0,max(caps)+2*lab.obj.bg.orders[-1]+1,2)
    allq=[];breakdown=[];imp=[]
    for j,(p,obs) in enumerate(zip(OBSERVER_R,OBSERVER_MU,strict=True)):
        rad=np.array([p]);tides=Tides(lab,rad,'paired');te=tides.sample(rad,angular(tides.ell,np.array([obs])))
        tf=float((te[0]+(gamma-1)*te[4])[0,0])
        bins=np.searchsorted(jf.EDGES,p)-1;low,high=jf.EDGES[bins:bins+2]
        data={k:[] for k in ('r','mu','h','energy','weight','inside')};bin_sum=0
        for part in range(4):
            a=clouds(part);mask=abs(a['r']-p)<a['h']
            for k in data:data[k].append(a[k][mask])
            inside=(a['cell']//256)==bins;cos=a['mu'][inside]
            co=sheet_coeffs(lab,64,'paired',gamma,j)
            bin_sum+=np.sum(a['energy'][inside]*a['weight'][inside]*np.polynomial.legendre.legval(cos,np.ravel(np.column_stack([co,0*co]))))
        a={k:np.concatenate(v) for k,v in data.items()};en=a['energy']*a['weight'];factor=-(gamma-1)*CONVERT
        for form in ('cubic','wendland'):
            arr=surface_windows(a['r'],a['h'],a['mu'],p,en[:,None],degree,28,form,True)
            density=ring(a['r'],a['mu'],a['h'],p,obs,form)
            exact=factor*((-1,1)[j]*jf.ls.G/(LIGHT**2*p**2))*tf*density*en
            for cap in caps:
                co=sheet_coeffs(lab,cap,'paired',gamma,j);signed=factor*(arr[:,:len(co)]@co)*en
                allq.append(dict(probe=j,shape=form,cap=cap,sheet=signed.sum(),exact_infinite_sheet=exact.sum(),
                    ratio_to_infinite=signed.sum()/exact.sum(),contributors=len(en)))
                if cap==64:
                    unsmooth_angular=np.polynomial.legendre.legval(a['mu'],np.column_stack([co,co*0]).ravel())
                    center_weight=factor*en*arr[:,0]*unsmooth_angular
                    breakdown.append(dict(probe=j,shape=form,uniform_containing_bin_observed_angles=factor*bin_sum*3*p*p/(high**3-low**3),
                        actual_support_radial_only=center_weight.sum(),full_support=signed.sum(),infinite_limit=exact.sum()))
                    for tag,z in [('retained',signed),('radial_only',center_weight),('infinite',exact)]:
                        imp.append(dict(probe=j,shape=form,method=tag,**influence(z)))
    table(HERE/'trace-angular-limit.csv',allq,True);table(HERE/'trace-decomposition.csv',breakdown,True);table(HERE/'trace-leverage.csv',imp,True)
if __name__=='__main__':guard();run()
