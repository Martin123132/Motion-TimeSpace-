"""Thermal source kernels with measured support. Separate shape assumptions from physical radii."""
from mixed_operators import *
from scipy.special import roots_legendre as gauss
from functools import lru_cache
@lru_cache(maxsize=1)
def layout():
    _,_,tags=bank();return tags.ravel(),jf.EDGES[len(tags)]
def shape_kernel(q,form):
    if form=='cubic':
        return 8/np.pi*np.where(q<.5,1-6*q*q+6*q**3,2*(1-q)**3)
    if form=='wendland':return 21/(2*np.pi)*(1-q)**4*(1+4*q)
    raise ValueError(form)
def shape_prime(q,form):
    if form=='cubic':return (8/np.pi)*np.where(q<.5,-12*q+18*q*q,-6*(1-q)**2)
    if form=='wendland':return -210/np.pi*q*(1-q)**3
    raise ValueError(form)
def clouds(part,kind='support'):
    path=HERE/f'gas-{kind}-{part}.npz';meta=json.loads(path.with_suffix('.json').read_bytes())
    assert digest(path)==meta['packet']
    with np.load(path) as a:out={k:a[k] for k in a.files}
    tags,outer=layout();c=out['cell'].astype(int);inside=c<len(tags)
    out.update(weight=np.where(inside,tags[np.minimum(c,len(tags)-1)],0.),inside=inside,energy=out['mass']*out['u'])
    return out
def sheet_coeffs(lab,cap,arm,gamma,probe):
    proj=cap+2*lab.obj.bg.orders[-1];degree=np.arange(0,proj+1,2);nodes,weights=gauss(max(160,int(proj)+4))
    mu=(1+nodes)/2;w=weights/2;p=OBSERVER_R[probe];rad=np.array([p]);tide=Tides(lab,rad,arm)
    values=tide.sample(rad,angular(tide.ell,mu));f=jump(mu,probe,cap)*(values[0][0]+(gamma-1)*values[4][0])
    co=(2*degree+1)*((w*f)@legvander(mu,int(degree[-1]))[:,::2])
    control=np.linspace(.0001,.9999,201);check=tide.sample(rad,angular(tide.ell,control));explicit=jump(control,probe,cap)*(check[0][0]+(gamma-1)*check[4][0])
    assert np.max(abs(legvander(control,int(degree[-1]))[:,::2]@co-explicit))<1e-8*np.max(abs(explicit))
    return co

def surface_windows(r,h,mu,p,energy,degree,order,form,individual=False):
    lmax=int(degree[-1]);nodes,w=gauss(order)
    total=np.zeros((len(degree),energy.shape[1]));parts=[]
    for i in range(0,len(r),4096):
        sl=slice(i,i+4096);rr=r[sl,None];hh=h[sl,None];cos=mu[sl,None]
        low=abs(p-rr)/hh;high=np.minimum(1.,(p+rr)/hh)
        acc=np.zeros((len(rr),len(degree)));assert np.all(high>=low)
        for k0,k1 in [(0.,.5),(.5,1.)]:
            lo=np.minimum(high,np.maximum(low,k0));hi=np.maximum(lo,np.minimum(high,k1))
            q=lo+(hi-lo)*(nodes+1)/2;wt=(hi-lo)*w/2*q*shape_kernel(q,form)/hh*(2*np.pi*p/rr)
            t=1-((q*hh)**2-(p-rr)**2)/(2*p*rr);assert np.max(abs(t))<1+1e-8
            old=np.ones_like(t);current=t.copy()
            for l in range(lmax+1):
                if l==0:poly=old
                elif l==1:poly=current
                else:old,current=current,((2*l-1)*t*current-(l-1)*old)/l;poly=current
                if not l%2:acc[:,l//2]+=np.sum(wt*poly,axis=1)
        acc*=legvander(cos[:,0],lmax)[:,::2]
        total+=acc.T@energy[sl]
        if individual:parts.append(acc)
    return np.concatenate(parts) if individual else total
def surface(order):
    lab=Launch(64);degree=np.arange(0,64+2*int(lab.obj.bg.orders[-1])+1,2);fields={};rows=[]
    tags=('raw_inner','represented')
    for j,p in enumerate(OBSERVER_R):
        vals={form:np.zeros((len(degree),2)) for form in ('cubic','wendland')};count=0
        for part in range(4):
            a=clouds(part);mask=np.abs(a['r']-p)<a['h'];count+=int(mask.sum())
            en=np.stack([a['energy']*a['inside'],a['energy']*a['weight']],axis=1)
            for form in vals:
                guard();vals[form]+=surface_windows(a['r'][mask],a['h'][mask],a['mu'][mask],p,en[mask],degree,order,form)
        for arm in ('reset','coupled','paired'):
            for gamma in (1.4,5/3):
                co=sheet_coeffs(lab,64,arm,gamma,j)
                for form,terms in vals.items():
                    for m,material in enumerate(tags):
                        rows.append(dict(probe=j,order=order,shape=form,arm=arm,gamma=gamma,material=material,intersecting=count,
                            energy_per_kpc=terms[0,m],sheet_fourth=-(gamma-1)*CONVERT*(co@terms[:,m])))
        fields.update({f'{form}_p{j}':terms for form,terms in vals.items()})
    table(HERE/f'cloud-surfaces-{order}.csv',rows,True);archive(f'surface-moments-{order}.npz',**fields)
    print('shells',order,flush=True)
if __name__=='__main__':
    for q in (10,24):surface(q)
