"""Same-input cross-checks plus independent manufactured fluid and monopole tests; no fits."""
from normal_energy import *
import csv
from scipy.integrate import quad
from collections import defaultdict
def read(name):
    with (HERE/name).open(newline='') as src:return list(csv.DictReader(src))
def select(rows,**terms):return [row for row in rows if all(str(row[k])==str(v) for k,v in terms.items())]
def item(rows,**terms):
    matches=select(rows,**terms);assert len(matches)==1,terms;return matches[0]
def calc():
    checks={};aggregates=[];testrows=[]
    for shape in ('cubic','wendland'):
        rad=np.array([.1,.9,1.,1.5,2.2]);h=np.array([2.,.45,1.,.5,.1]);p=1.25
        f=shellfraction(rad,h,p,shape)
        def independent(rr,hh):
            def angle(s):
                if s<abs(rr-p):return float(rr<p)
                if s>=rr+p:return 0.
                return (p*p-(rr-s)**2)/(4*rr*s)
            return quad(lambda s:4*np.pi*s*s/hh**3*shape_kernel(s/hh,shape)*angle(s),0,hh,
                points=[t for t in (hh*.5,abs(rr-p),rr+p) if t<hh],epsabs=3e-13)[0]
        checks['enclosed_kernel_'+shape]=float(np.max(abs(f-[independent(r,k) for r,k in zip(rad,h,strict=True)])))
        assert checks['enclosed_kernel_'+shape]<1e-13
        norm=quad(lambda s:4*np.pi*s*s*shape_kernel(s,shape),0,1,points=[.5])[0]
        assert abs(norm-1)<1e-13
    for gamma in GAM:
        step=1e-5;lam=.41;ex= -3*gamma*lam
        numeric=((1+step*lam)**(-3*gamma)-(1-step*lam)**(-3*gamma))/(2*step)
        checks['enclosed_homogeneous_'+str(gamma)]=abs(numeric/ex-1);assert abs(numeric/ex-1)<1e-8
        probe=OBSERVER_R[1];R=10.;target=abs(jf.ls.G/LIGHT**2*(3*gamma-2)*lam)
        sheet=-probe**2*(3*gamma-2)*lam*jump(np.array([.27]),1,0)[0]
        force=-(3*gamma-2)*lam*R**2*(jf.ls.G/(LIGHT**2*R**2))
        assert abs(sheet-force)<1e-13*target and abs(sheet/target+1)<1e-14
    checks['signed_homogeneous_monopole_sheet']='agrees with exterior traction on uniform ball'
    files=[f.name for f in HERE.glob('volume-*.csv')]
    for file in files:
        rows=read(file);val=max(float(r['relative_duality_error']) for r in rows)
        checks[file+'_worst_L1_duality']=val
    rows=read('volume-64-4-64.csv');assert checks['volume-64-4-64.csv_worst_L1_duality']<2e-7
    reference=read('cloud-surfaces-24.csv');coarse=read('cloud-surfaces-10.csv')
    keys=['probe','shape','arm','gamma','material']
    serr=max(abs(1-float(r['sheet_fourth'])/float(item(coarse,**{k:r[k] for k in keys})['sheet_fourth'])) for r in reference)
    checks['sheet_order10_24_relative']=serr;assert serr<1e-6
    allseed=[read(f'cloud-volume-640-{seed}-all.csv') for seed in range(4)]
    finer=read('cloud-volume-960-0-paired.csv')
    for shape in ('cubic','wendland'):
        for gamma in GAM:
            for mat in ('raw_inner','represented'):
                for arm in ARMS:
                    terms=dict(shape=shape,gamma=gamma,material=mat,arm=arm)
                    one,two=[float(item(reference,probe=j,**terms)['sheet_fourth']) for j in (0,1)]
                    def values(rows):
                        row=item(rows,**terms);b=float(row['bulk_fourth']);st=float(row['strong_pressure']);extra=0.
                        if mat=='represented':extra=float(item(rows,**(terms|dict(material='passive_minus_represented')))['strong_pressure'])
                        return np.array([b,b+one+two,st,extra,b+one+two+extra,float(row['curvature'])])
                    data=np.array([values(rows) for rows in allseed]);mean=data.mean(axis=0)
                    ag=dict(**terms,inner_sheet=one,outer_sheet=two,regular=mean[0],fourth=mean[1],
                        numerical_seed_min=data[:,1].min(),numerical_seed_max=data[:,1].max(),strong=mean[2],
                        strong_minus_weak=mean[2]-mean[1],strong_weak_SE=np.std(data[:,2]-data[:,1],ddof=1)/2,
                        paired_grid_shift=(values(finer)[1]-data[0,1] if arm=='paired' else ''),
                        passive_extra_mean=(mean[3] if mat=='represented' else ''),passive_total=(mean[4] if mat=='represented' else ''),
                        passive_min=(min(data[:,4]) if mat=='represented' else ''),passive_max=(max(data[:,4]) if mat=='represented' else ''),
                        curvature=mean[5],fourth_at_024=mean[1]*.24**4/24,ratio_to_gas_lead=.24**2*mean[1]/(12*mean[5]))
                    aggregates.append(ag)
    for shape in ('cubic','wendland'):
        for gamma in GAM:
            for mat in ('represented','raw_inner'):
                finder=lambda arm:item(aggregates,shape=shape,gamma=gamma,material=mat,arm=arm)
                rr,cc,pp=map(finder,ARMS)
                for key in ('fourth','strong','curvature'):
                    resid=abs((cc[key]-rr[key]-pp[key])/max(abs(cc[key]),abs(rr[key]),1e-40))
                    assert resid<3e-9,(shape,gamma,mat,key,resid)
    table(HERE/'clock-summary.csv',aggregates,True)
    raw,en,tags=bank();mass=raw.size
    with np.load(prior('frozen-weights.npz')) as f:stars=f['star_mass'][:mass].reshape(raw.shape)
    material={}
    for key,src in [('gas_Msun',raw),('star_Msun',stars),('thermal_Msun_km2_s2',en)]:
        big=tags>1;f=tags/tags.max();com=1-f
        pair=np.sum(src*f)+np.sum(src*com);assert np.min(com)>=0 and abs(pair/src.sum()-1)<2e-13
        material[key]=dict(original=float(src.sum()),represented=float((src*tags).sum()),
            overweight_cell_share_of_represented=float((src[big]*tags[big]).sum()/(src*tags).sum()),
            excess_above_available_in_those_cells=float(np.sum(src*np.maximum(tags-1,0))),
            deficit_in_other_cells=float(np.sum(src*np.maximum(1-tags,0))))
    record('material-labels.json',dict(cells=int(mass),cells_w_above_one=int((tags>1).sum()),maximum=float(tags.max()),components=material))
    normal={k:read(k) for k in ('normal-cell-2.csv','normal-cell-4.csv','normal-cloud-1200-0.csv','normal-cloud-2000-1.csv')}
    audit=[]
    for file,rows in normal.items():
        for shape in sorted({r['shape'] for r in rows},reverse=True):
            for mat in ('represented','raw_inner'):
                for gamma in GAM:
                    terms=dict(shape=shape,material=mat,gamma=gamma)
                    for ch in ('inner','middle','outer','compensated'):
                        a,b,c=[item(rows,arm=x,channel=ch,**terms) for x in ARMS]
                        scale=sum(abs(float(r[k])) for r in [a,b] for k in ['force_flux','force_adiabatic'])
                        err=abs(float(b['force_total'])-float(a['force_total'])-float(c['force_total']))/scale
                        assert err<5e-10,(file,terms,err)
                    row=item(rows,arm='paired',channel='compensated',**terms)
                    audit.append(dict(file=file,**terms,force_flux=row['force_flux'],force_adiabatic=row['force_adiabatic'],force_total=row['force_total']))
    table(HERE/'normal-summary.csv',audit,True)
    summary={}
    for kind in ('support','boundary'):
        rec=[json.loads((HERE/f'gas-{kind}-{i}.json').read_bytes()) for i in range(4)]
        assert all(r['energy_join_exact'] and digest(HERE/f'gas-{kind}-{r["part"]}.npz')==r['packet'] for r in rec)
        summary[kind]=dict(input=sum(r['count'] for r in rec),retained=sum(r['retained'] for r in rec),
            outside_touching_clock=sum(r['outer_centers_touching_clocks'] for r in rec),
            transferred_bytes=sum(sum(r['bytes'].values()) for r in rec))
    assert summary['support']['input']==summary['boundary']['input']==57075281
    recorded=read('trace-angular-limit.csv');assert len(recorded)==24
    for r in select(recorded,cap=64):
        orig=float(item(reference,probe=r['probe'],shape=r['shape'],arm='paired',gamma=5/3,material='represented')['sheet_fourth'])
        assert abs(float(r['sheet'])/orig-1)<1e-8
    assert len(aggregates)==24 and len(audit)==24
    record('validation.json',dict(parent=EXPECTED,checks=checks,input=summary,cloud_mean_rows=len(aggregates),
        compensated_comparison_rows=len(audit),cloud_samples=4,original_cap=64,prior_inputs_modified=False))
if __name__=='__main__':guard();calc()
