"""Read physical gas support and reproduce the saved energy assignment before retaining near-clock data."""
from mixed_pressure_io import *
import datetime,time
pinned('catalog_links.py')
from catalog_links import fetch_ids

def collect(part,end):
    exterior='--edge' in sys.argv
    tag=f'gas-{"boundary" if exterior else "support"}-{part}';out=HERE/(tag+'.npz');receipt=HERE/(tag+'.json')
    if receipt.exists():assert digest(out)==json.loads(receipt.read_bytes())['packet'];return
    old=json.loads(retained(f'thermal-s590-{part}.json').read_bytes());path,meta=paths(590,part)
    assert digest(path)==json.loads(pinned(f'gas/s590-{part}.json').read_bytes())['packet']
    ids,used=fetch_ids(590,part,end);fields=[];hashes={};bytes_used={'ParticleIDs':used}
    for key in ('InternalEnergy','SmoothingLength'):
        guard();assert time.time()<end;remote=source.Remote(old['url'],65536)
        try:
            assert list(remote.id)==old['identity']
            with source.h5py.File(remote,'r') as store:
                data=store['PartType0/'+key];assert data.shape==ids.shape
                remote.load_field(data);values=data[:];hashes[key]=hashlib.sha256(memoryview(values)).hexdigest()
                assert np.isfinite(values).all() and (values>=0).all()
                if key=='InternalEnergy':assert hashes[key]==old['field_hash']
                else:assert values.min()>0
                fields.append(values)
            bytes_used[key]=remote.transferred
        finally:remote.close()
    native_u,native_h=fields;hub,scale,*_=frames(590);axis=frames(600)[4][-1]
    mass,energy,tags=bank();limit=mass.size;energy_cell=np.zeros(COUNT+1)
    storage={k:[] for k in ('r','mu','h','mass','u','cell','native')};outside_count=0
    with np.load(path) as original:
        for shard in range(PARTS):
            ix=np.flatnonzero(ids%PARTS==shard);rows=original[f'b{shard}'];assert np.array_equal(rows['id'],ids[ix])
            h=native_h[ix].astype(float)*(scale/hub);raw=rows['m'].astype(float)*(1e10/hub);u=native_u[ix]
            xyz=rows['xyz'].astype(float);r=np.linalg.norm(xyz,axis=1);mu=np.clip(np.abs(xyz@axis)/np.maximum(r,1e-80),0,1)
            cell=rows['cell'];inside=cell<limit
            hit=(abs(r-OBSERVER_R[0])<=h)|(abs(r-OBSERVER_R[1])<=h);use=inside|hit
            if exterior:use=(~use)&(r-h<jf.EDGES[len(mass)])
            outside_count+=int(np.sum(hit&~inside))
            energy_cell+=np.bincount(cell.astype(int),weights=raw*u,minlength=COUNT+1)
            for name,arr in zip(storage,(r,mu,h,raw,u,cell,ix.astype(np.uint32)),strict=True):storage[name].append(arr[use])
    with np.load(retained(f'thermal-s590-{part}.npz')) as f:assert np.array_equal(energy_cell,f['energy_mass'])
    selected={k:np.concatenate(v) for k,v in storage.items()};archive(tag+'.npz',**selected)
    record(tag+'.json',dict(part=part,count=len(ids),retained=len(selected['r']),outer_centers_touching_clocks=outside_count,
        bytes=bytes_used,url=old['url'],identity=old['identity'],fields=hashes,h_physical_factor=scale/hub,
        proper_support_definition='full compact support radius; comoving divided by hubble parameter then multiplied by scale factor',
        energy_join_exact=True,packet=digest(out)))
    print('support',part,len(selected['r']),outside_count,flush=True)

if __name__=='__main__':
    end=datetime.datetime.fromisoformat(sys.argv[1]).timestamp();assert time.time()<end<time.time()+14400
    for part in range(4):collect(part,end)
