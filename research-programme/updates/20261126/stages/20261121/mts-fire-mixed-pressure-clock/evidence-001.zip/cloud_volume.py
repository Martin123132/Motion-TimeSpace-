"""Positive compact gas clouds: bulk integral and independently sampled pressure force on frozen launch labels."""
from gas_clouds import *
import argparse
from scipy.special import roots_legendre

class Grid:
    def __init__(self,res,arms):
        lab=Launch(64);self.arms=arms
        _,outer=layout();extent=outer
        for part in range(4):
            a=clouds(part);extent=max(extent,float(np.max(a['r']+a['h'])))
        self.limits=np.r_[1e-8,OBSERVER_R,extent+.1];self.blocks=[]
        theta=np.linspace(0,np.pi/2,res//2+1);mu=np.cos(theta);self.nt=len(mu)
        clockang=angular(DEGREES,mu,False)
        for lo,hi in zip(self.limits[:-1],self.limits[1:],strict=True):
            step=(np.arcsinh(hi/.1)-np.arcsinh(lo/.1))
            n=max(97,int(np.ceil(res*step/3)))
            radii=.1*np.sinh(np.linspace(np.arcsinh(lo/.1),np.arcsinh(hi/.1),n));radii[0]=lo;radii[-1]=np.nextafter(hi,lo)
            co=np.empty((n,len(mu),len(arms),7))
            for k,arm in enumerate(arms):
                tides=Tides(lab,radii,arm);ang=angular(tides.ell,mu)
                for first in range(0,n,32):
                    sl=slice(first,first+32);rad=radii[sl];t=tides.sample(rad,ang);ck=clock_parts(rad,mu,64,clockang)
                    bulk,grad,curv=regular(t,ck);rr,rt,tt,pp,tr=t[:5];gr,gt=ck[:2]
                    co[sl,:,k,:]=np.stack([bulk,grad,rr*gr+rt*gt,rt*gr+tt*gt,tr*gr,tr*gt,curv],axis=-1)
            self.blocks.append((co,np.arcsinh(lo/.1),(n-1)/step))
    def __call__(self,r,mu):
        selfloor=self.limits[0];r=np.clip(r,selfloor,self.limits[-1]);group=np.searchsorted(self.limits[1:-1],r)
        af=np.arccos(np.clip(mu,0,1))*((self.nt-1)*2/np.pi);j=np.minimum(af.astype(int),self.nt-2)
        val=np.empty((len(r),len(self.arms),7))
        for g,(co,low,scale) in enumerate(self.blocks):
            sel=group==g
            if not np.any(sel):continue
            rf=np.clip((np.arcsinh(r[sel]/.1)-low)*scale,0,len(co)-1)
            i=np.minimum(rf.astype(int),len(co)-2);jj=j[sel];v=(af[sel]-jj)[:,None,None];u=(rf-i)[:,None,None]
            val[sel]=(1-u)*((1-v)*co[i,jj]+v*co[i,jj+1])+u*((1-v)*co[i+1,jj]+v*co[i+1,jj+1])
        return val

def integrate(grid,res,seed):
    formnames=('cubic','wendland');materials=('raw_inner','represented','passive_minus_represented','exterior_only')
    sums=np.zeros((len(formnames),len(materials),len(grid.arms),5))
    tags,outer=layout();edges=jf.EDGES;qt,qw=roots_legendre(4)
    for typ,kind in enumerate(('support','boundary')):
        for part in range(4):
            a=clouds(part,kind)
            for start in range(0,len(a['r']),24576):
                guard();sl=slice(start,start+24576);r=a['r'][sl];mu=a['mu'][sl];h=a['h'][sl];sin=np.sqrt(1-mu**2)
                energy=a['energy'][sl];mass=a['mass'][sl];source=a['weight'][sl];raw=a['inside'][sl].astype(float)
                rng=np.random.default_rng(np.random.SeedSequence([160754,seed,typ,part,start]))
                for half in (0.,.5):
                    for u,omega in zip(half+(qt+1)/4,qw/4,strict=True):
                        eta=rng.uniform(-1,1,len(r));az=rng.uniform(0,2*np.pi,len(r))
                        uz=eta*mu-np.sqrt(1-eta**2)*sin*np.cos(az);disp=u*h
                        for sign in (-1,1):
                            rr=np.sqrt(np.maximum(1e-30,r*r+disp*disp+2*r*disp*sign*eta));z=r*mu+disp*sign*uz
                            ang=np.clip(abs(z)/rr,0,1);sr=(r*sign*eta+disp)/rr
                            st=(ang*sr-np.sign(z)*sign*uz)/np.sqrt(np.maximum(1e-28,1-ang**2))
                            f=grid(rr,ang);cell=(np.searchsorted(edges,rr,side='right')-1)*256+np.minimum((ang*256).astype(int),255)
                            wt=np.where(cell<len(tags),tags[np.clip(cell,0,len(tags)-1)],0.);diff=wt-source
                            coeff=np.stack([raw,source,diff,diff*typ],axis=0)
                            products=np.stack([f[:,:,0],f[:,:,1],(f[:,:,2]*sr[:,None]+f[:,:,3]*st[:,None])/h[:,None],
                                (f[:,:,4]*sr[:,None]+f[:,:,5]*st[:,None])/h[:,None]],axis=-1)
                            allp=((coeff*energy)@products.reshape(len(r),-1)).reshape(len(materials),len(grid.arms),4)
                            curve=(coeff*mass)@f[:,:,6]
                            for j,form in enumerate(formnames):
                                w0=2*np.pi*omega*u**2*shape_kernel(u,form)
                                w1=2*np.pi*omega*u**2*shape_prime(u,form)
                                sums[j,:,:,:4]+=allp*np.array([w0,w0,w1,w1]);sums[j,:,:,4]+=w0*curve
            print('cloud volume',res,seed,kind,part,flush=True)
    rows=[]
    for j,form in enumerate(formnames):
        for m,mat in enumerate(materials):
            for k,arm in enumerate(grid.arms):
                bulk,grad,stress,compress,curv=sums[j,m,k]
                for gam in (1.4,5/3):
                    unit=(gam-1)*CONVERT
                    rows.append(dict(res=res,seed=seed,shape=form,material=mat,arm=arm,gamma=gam,bulk_fourth=-unit*bulk,
                        strong_pressure=unit*(gam*grad+stress+(gam-1)*compress),curvature=curv))
    table(HERE/f'cloud-volume-{res}-{seed}-{"all" if len(grid.arms)>1 else "paired"}.csv',rows,True)
if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('res',type=int);parser.add_argument('seeds',nargs='+',type=int)
    parser.add_argument('--all-arms',action='store_true');args=parser.parse_args()
    arms=('reset','coupled','paired') if args.all_arms else ('paired',)
    grid=Grid(args.res,arms)
    for seed in args.seeds:integrate(grid,args.res,seed)
