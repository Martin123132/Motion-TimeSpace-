"""Private readouts use the retained FIRE/thermal and wave seals."""
import os,sys,json,hashlib,io
from pathlib import Path
for name in ('OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','OMP_NUM_THREADS','NUMEXPR_NUM_THREADS','BLIS_NUM_THREADS'):os.environ[name]='1'
HERE=Path(__file__).resolve().parent
BASE=HERE.parent/'mts-fire-live-poisson-feedback-20261121'
EXPECTED='eaac92f91d44fe582052ed2ff52250256128b0fc78d98883188bf06beb09e0eb'
def digest(path):
    with path.open('rb') as src:return hashlib.file_digest(src,'sha256').hexdigest()
assert digest(BASE/'seal.json')==EXPECTED
manifest=json.loads((BASE/'seal.json').read_bytes())
def retained(name):
    path=BASE/name;assert digest(path)==manifest[name],name
    return path
for name in ('live_poisson.py','live_feedback_sources.py','thermal_tide.py','thermal_source.py'):retained(name)
sys.path.insert(0,str(BASE))
from live_poisson import np,jf,Radial,green,basis,Launch,roots_legendre,eval_legendre,prior,legvander,table,keep,clocks,records,DEGREES,LIGHT,OBSERVER_R,OBSERVER_MU,pinned,guard as original_guard
from gas_stage import source,frames,paths,PARTS,COUNT
from scipy.constants import Julian_year,parsec
from types import SimpleNamespace
CONVERT=(1e6*Julian_year/parsec)**2
def guard():
    original_guard();assert not (HERE/'STOP-REQUESTED').exists()
def archive(name,**items):
    stream=io.BytesIO();np.savez_compressed(stream,**items);keep(HERE/name,stream.getvalue(),True)
def record(name,items):
    keep(HERE/name,(json.dumps(items,sort_keys=True,indent=2)+'\n').encode(),True)
def bank():
    mass=np.zeros(COUNT+1);thermal=mass.copy()
    for part in range(4):
        with np.load(retained(f'thermal-s590-{part}.npz')) as f:mass+=f['mass'];thermal+=f['energy_mass']
    with np.load(prior('frozen-weights.npz')) as f:tags=f['fine'].reshape(-1,256)
    raw=mass[:-1].reshape(tags.shape);energy=thermal[:-1].reshape(tags.shape)
    last=np.flatnonzero((raw*tags).sum(axis=1)>0)[-1]+1
    return raw[:last],energy[:last],tags[:last]
