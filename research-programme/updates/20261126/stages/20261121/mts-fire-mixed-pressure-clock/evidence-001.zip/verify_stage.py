"""Sign, conservation, input integrity and replay checks for the closed local stage."""
from summarize import *
def verify(sealing):
    guard()
    for name in manifest:retained(name)
    calc()
    for path in HERE.glob('*.py'):compile(path.read_bytes(),str(path),'exec')
    assert not any(p.name.endswith(('.work','.tmp','.pyc')) or p.name=='__pycache__' for p in HERE.rglob('*'))
    circ=read('scalar-pressure-circulation.csv');assert len(circ)==8
    for row in circ:
        st=float(row['closed_path']);pred=float(row['jump_times_tangent_change']);total=float(row['total_abs_path'])
        assert abs(st-pred)<total*2e-13 and (st>0)==(int(row['probe'])==1) and abs(st)>1e-5*total
    ag=read('clock-summary.csv')
    for row in select(ag,material='represented',arm='paired'):
        assert float(row['numerical_seed_min'])>0 and float(row['passive_min'])>0
        assert abs(float(row['paired_grid_shift']))<.01*float(row['fourth'])
        assert abs(float(row['strong_minus_weak']))<3*float(row['strong_weak_SE'])
    actual=read('normal-summary.csv')
    for shape in ('cubic','wendland'):
        for gamma in GAM:
            kw=dict(shape=shape,gamma=gamma,material='represented')
            one,two=[float(item(actual,file=f'normal-cloud-{s}.csv',**kw)['force_total']) for s in ('1200-0','2000-1')]
            assert one<0 and two<0 and abs(one/two-1)<.01
    shapes=read('trace-decomposition.csv')
    assert all(float(row['uniform_containing_bin_observed_angles'])<0 and float(row['full_support'])>0 for row in select(shapes,probe=0))
    weights=json.loads((HERE/'material-labels.json').read_bytes());assert weights['cells_w_above_one']>0 and weights['maximum']>1
    for component in weights['components'].values():
        net=component['excess_above_available_in_those_cells']-component['deficit_in_other_cells']
        assert abs(net+component['original']-component['represented'])<3e-12*component['original']
    import re
    for doc in HERE.glob('*.md'):
        for match in re.finditer(r'\[[^\]\n]+\]\(([^) \n]+)\)',doc.read_text(encoding='utf-8')):
            link=match.group(1)
            if '://' not in link:assert (HERE/link).is_file(), (doc.name,link)
    receipt=dict(predecessor_files_checked=len(manifest),predecessor_seal=EXPECTED,closed_paths=len(circ),
        reconstructed_clock_comparisons=len(ag),profile_and_adiabatic_rules_checked=True,
        signed_traction_and_overweight_budget_checked=True,exact_source_hashes_checked=True,private=True)
    record('final-checks.json',receipt)
    now={p.name:digest(p) for p in sorted(HERE.iterdir()) if p.is_file() and p.name!='seal.json'}
    if sealing:record('seal.json',now)
    assert json.loads((HERE/'seal.json').read_bytes())==now
    print(len(now),digest(HERE/'seal.json'),flush=True)
if __name__=='__main__':verify('--seal' in sys.argv)
