"""Independent Hessian and conservative pressure-force projections across all radial and angular faces."""
from mixed_operators import *
from collections import defaultdict
def quadrature(edges,n):
    nodes,w=roots_legendre(n);width=np.diff(edges)
    return ((edges[:-1,None]+(nodes+1)*width[:,None]/2).ravel(),(width[:,None]*w/2).ravel())

def solve(steps,q,cap,arms):
    lab=Launch(steps);mass,energy,tags=bank();n=len(mass);edges=jf.EDGES[:n+1];angle=jf.ANG;da=np.diff(angle)
    faces=lab.run.el.right*lab.obj.bg.length;breaks=np.unique(np.r_[edges,OBSERVER_R,faces[(faces>0)&(faces<edges[-1])]])
    r,rw=quadrature(breaks,q);ir=np.searchsorted(edges,r)-1;mu,mw=quadrature(angle,q)
    ar_idx=np.repeat(np.arange(256),q);af=angle[1:-1];allr=np.unique(np.r_[r,edges[1:],OBSERVER_R])
    ell=np.arange(0,cap+1,2);cp=angular(ell,mu,False);cf=angular(ell,af,False)
    rows=[]
    for arm in arms:
        obj=Tides(lab,allr,arm);ap=angular(obj.ell,mu);ah=angular(obj.ell,af)
        accum=defaultdict(lambda:np.zeros(12))
        def sets(ir,rad,mode):
            if mode=='volume':jac=(edges[ir+1]**3-edges[ir]**3)/3
            else:jac=(edges[ir+1]-edges[ir])*rad**2
            den=energy[ir]/(jac[:,None]*da)
            return den,tags[ir]
        for start in range(0,len(r),40):
            guard();sl=slice(start,start+40);rad=r[sl];ind=ir[sl];w=rw[sl,None];rf=rad[:,None]
            tide=obj.sample(rad,ap);clock=clock_parts(rad,mu,cap,cp);rr,rt,tt,pp,tr=tide[:5];kr,kt=clock[:2]
            hess,sgrad,curvature=regular(tide,clock)
            tf=obj.sample(rad,ah);kf=clock_parts(rad,af,cap,cf);rface,tface,ff=tf[:3];trface=tf[4]
            for mode in ('volume','radius'):
                den,tag=sets(ind,rad,mode)
                for gamma in (1.4,5/3):
                    flow=((gamma-1)*tr+rr)*kr+rt*kt
                    tang=-rf*np.sqrt(1-af**2)*(tface*kf[0]+((gamma-1)*trface+ff)*kf[1])
                    for material,weight in (('represented',tag),('raw_inner',np.ones_like(tag))):
                        row=accum[mode,gamma,material];p=den*weight;fac=w*rf**2*p[:,ar_idx]*mw
                        row[0]+=np.sum(fac*hess)
                        row[3]+=np.sum(fac*(gamma*sgrad-(2/rf)*flow if mode=='radius' else gamma*sgrad))
                        row[5]+=np.sum(w*np.diff(p,axis=1)*tang)
                        if mode=='volume':massden=mass[ind]/(((edges[ind+1]**3-edges[ind]**3)/3)[:,None]*da)
                        else:massden=mass[ind]/(np.diff(edges)[ind,None]*rf**2*da)
                        row[6]+=np.sum(w*rf**2*(massden*weight)[:,ar_idx]*mw*curvature)
                        if material=='represented':
                            amplitude=w*np.diff(tag,axis=1)*tang
                            left=amplitude*den[:,:-1];right=amplitude*den[:,1:]
                            row[7]+=.5*np.sum(left+right);row[8]+=np.sum(np.minimum(left,right));row[9]+=np.sum(np.maximum(left,right))
        for start in range(1,n+1,40):
            f=np.arange(start,min(start+40,n+1));rad=edges[f];rf=rad[:,None]
            tide=obj.sample(rad,ap);ck=clock_parts(rad,mu,cap,cp);rr,rt,tt,pp,tr=tide[:5]
            for mode in ('volume','radius'):
                dl,wl=sets(f-1,rad,mode);dr,wr=sets(np.minimum(f,n-1),rad,mode)
                dr[f==n]=0;wr=wr.copy();wr[f==n]=0
                for gamma in (1.4,5/3):
                    flow=rf**2*(((gamma-1)*tr+rr)*ck[0]+rt*ck[1])*mw
                    for material in ('represented','raw_inner'):
                        row=accum[mode,gamma,material]
                        change=dr*wr-dl*wl if material=='represented' else dr-dl
                        row[4]+=np.sum(flow*change[:,ar_idx])
                        if material=='represented':
                            amp=flow*(wr-wl)[:,ar_idx];lo=amp*dl[:,ar_idx];hi=amp*dr[:,ar_idx]
                            row[7]+=.5*np.sum(lo+hi);row[8]+=np.minimum(lo,hi).sum();row[9]+=np.maximum(lo,hi).sum()
        for j,p in enumerate(OBSERVER_R):
            rad=np.array([p]);index=np.searchsorted(edges,rad)-1
            assert not np.any(edges==p)
            tide=obj.sample(rad,ap);surf=p*p*jump(mu,j,cap)*mw
            for mode in ('volume','radius'):
                den,tag=sets(index,rad,mode)
                for gamma in (1.4,5/3):
                    flux=surf*((gamma-1)*tide[4]+tide[0])
                    for material in ('represented','raw_inner'):
                        weight=den*tag if material=='represented' else den
                        accum[mode,gamma,material][1+j]+=np.sum(flux*weight[:,ar_idx])
        for (mode,gamma,material),v in accum.items():
            factor=(gamma-1)*CONVERT;bulk,inn,out=-factor*v[:3];weak=bulk+inn+out
            vol,rad,ang=factor*v[3:6];strong=vol+rad+ang
            rr=dict(steps=steps,order=q,cap=cap,arm=arm,representation=mode,material=material,gamma=gamma,
                bulk=bulk,inner_sheet=inn,outer_sheet=out,fourth=weak,force_volume=vol,force_radial_faces=rad,force_angular_faces=ang,
                force_fourth=strong,relative_duality_error=abs(strong-weak)/max(abs(bulk)+abs(inn)+abs(out),1e-50),
                gas_clock_curvature=v[6],at_024=.24**4*weak/24,at_2p221=clocks()[1]**4*weak/24,
                signed_ratio_024=.24**2*weak/(12*v[6]))
            extra=dict(passive_tag_face_extra=-factor*v[7],passive_fourth=weak-factor*v[7],
                passive_interface_order_min=weak-factor*v[9],passive_interface_order_max=weak-factor*v[8])
            rr.update(extra if material=='represented' else {k:'' for k in extra})
            rows.append(rr)
    table(HERE/f'volume-{steps}-{q}-{cap}.csv',rows,True);print('volume',steps,q,cap,flush=True)
if __name__=='__main__':
    for config in ((64,4,64,('reset','coupled','paired')),(64,2,64,('paired',)),(32,4,64,('paired',)),(64,4,48,('paired',)),(64,4,80,('paired',))):
        solve(*config)
