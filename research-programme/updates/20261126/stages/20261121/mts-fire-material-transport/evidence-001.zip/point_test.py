"""Continuous particle-position readout; launch prediction is written before scoring 591."""
from material_readouts import *
from scipy.interpolate import RectBivariateSpline
from moment_io import basis
def point_table(mom):
    lab=mom.lab;bg=lab.obj.bg;box=Radial(lab,16);length=bg.length;unit=lab.obj.unit_myr
    log=np.linspace(1e-7,np.arcsinh(500/.08),1729);r=.08*np.sinh(log)
    theta=np.linspace(0,np.pi/2,193);ell=box.sell
    def direct(r):
        inside=r<box.inf*length;y=r[inside]/length;pt=np.r_[y,box.inf]
        val,grad,sec=green(lab,box,pt)
        B=np.empty((len(r),len(ell)));slope=np.empty_like(B)
        B[inside]=2*val[:-1,:,0]+y[:,None]*grad[:-1,:,0];slope[inside]=3*grad[:-1,:,0]+y[:,None]*sec[:-1,:,0]
        B[~inside]=(1-ell)*val[-1,:,0]*(box.inf*length/r[~inside,None])**(ell+1)
        slope[~inside]=-(ell+1)*B[~inside]/(r[~inside,None]/length)
        return B,slope
    harm,angle=basis(ell,np.cos(theta));B,slope=direct(r)
    fields=[B@harm,slope@harm,(B@angle)/(r[:,None]/length)]
    fits=[RectBivariateSpline(log,theta,v) for v in fields]
    xs=log[1:-1:7]+.41*(log[1]-log[0]);ys=theta[1:-1:3]+.21*theta[1]
    rr=.08*np.sinh(xs);b,d=direct(rr);bb,aa=basis(ell,np.cos(ys))
    errors=[np.linalg.norm(f(xs,ys)-ref)/np.linalg.norm(ref) for f,ref in zip(fits,[b@bb,d@bb,(b@aa)/(rr[:,None]/length)],strict=True)]
    return fits,errors

def run(label):
    guard();assert label in ('launch','endpoint')
    ss=590 if label=='launch' else 591
    if label=='endpoint':
        assert (STAGE/'point-launch.csv').exists()
        with np.load(STAGE/'stellar-links.npz') as a:link=a['parent']
        cells=[];masses=[]
        for p in range(4):
            with piece(590,p)[0] as a:cells.append(a['cell']);masses.append(a['mass_stored'])
        launchcell=np.concatenate(cells);launchmass=np.concatenate(masses);del cells,masses
    with np.load(STAGE/'frozen-weights.npz') as a:maps={k:np.r_[a[k],0.] for k in ('coarse','fine')}
    mom=Moment(64);lab=mom.lab;bg=lab.obj.bg;fits,errors=point_table(mom)
    rows={};offset=0;factor=1e10/frames(ss)[0];unit=lab.obj.unit_myr;length=bg.length
    for p in range(4):
        guard()
        with piece(ss,p)[0] as a:
            c=a['cell'];mass=a['mass_stored'].astype(float)*factor;r=a['r_kpc'].astype(float);mu=a['mu'].astype(float)
            if ss==590:vr=a['vr_kms']/bg.vel;vt=a['vt_kms']/bg.vel
            else:parents=link[offset:offset+len(c)];offset+=len(c)
        for start in range(0,len(c),200000):
            sl=slice(start,min(start+200000,len(c)));m=mass[sl];cell=c[sl];weights={}
            for key,w in maps.items():
                weights[key+'_destination']=m*w[cell]
                if ss==591:
                    ids=parents[sl];known=ids>=0;parentw=np.where(known,w[launchcell[ids]],0.)
                    weights[key+'_transported']=launchmass[ids].astype(float)*factor*parentw
                    weights[key+'_evolved']=m*parentw
            mask=np.logical_or.reduce([z!=0 for z in weights.values()])
            if not mask.any():continue
            weights={k:v[mask] for k,v in weights.items()};rr=r[sl][mask];yy=rr/length;tt=np.arccos(np.clip(mu[sl][mask],0,1));xx=np.arcsinh(rr/.08)
            assert rr.min()>0 and rr.max()<500.
            veval=lambda n:fits[n].ev(xx,tt)
            values={'virial':-veval(0)*(length/unit)**2};rates={}
            if ss==590:
                v=vr[sl][mask];t=vt[sl][mask];rates['virial']=-(veval(1)*v+veval(2)*t)*(length/unit)**2/unit
            for half,(lo,hi) in enumerate(zip(mom.range[:-1],mom.range[1:],strict=True),1):
                sel=(yy>=lo)&(yy<hi)
                for name in ('mass','gravity'):
                    col=name+str(half);scale=mom.scale(name)*unit/lab.mesh.mscale
                    k=lambda key:mom.fns[name,half,key].ev(yy[sel],tt[sel])
                    arr=np.zeros(len(rr));arr[yy<lo]=mom.inside[name,half];arr[sel]=k('D')
                    values[col]=arr*scale
                    if ss==590:
                        deriv=np.zeros(len(rr));deriv[sel]=(k('radial')-k('rest'))*v[sel]+k('polar')*t[sel]
                        rates[col]=deriv*scale/unit
            for key,wt in weights.items():
                for name,obs in values.items():
                    entry=rows.setdefault((key,name),np.zeros(2))
                    entry[0]+=wt@obs
                    if ss==590:entry[1]+=wt@rates[name]
    result=[dict(mode=k,readout=n,moment=v[0],instantaneous=v[1] if ss==590 else '') for (k,n),v in rows.items()]
    table(STAGE/f'point-{label}.csv',result,True)
    table(STAGE/'point-interpolation.csv',[dict(component=k,relative_L2_error=v) for k,v in zip(('B','B_r','B_theta_over_r'),errors,strict=True)],True)
    print(label,'interpolation',errors,flush=True)
if __name__=='__main__':run(sys.argv[1])
