"""Freeze source weights using no 591 inputs."""
from material_inputs import *
from moment_io import keep
import io

def freeze():
    checks={}
    previous('inputs/s590-0-p4.json');fixed('joint_field.py')
    codes=jf.groups(False);labels=codes.ravel()
    def census(snap):
        for part in range(4):fixed(f'mass-{snap}-{part}.npz');fixed(f'mass-{snap}-{part}.json')
        return jf.merged(snap)[0][:,0].reshape(2,-1)
    raw=census(590);end=census(600).sum(axis=0)
    with np.load(fixed('mw-positive-aperture.npz')) as data:local=data['high'].ravel()
    now=raw.sum(axis=0);g0=np.bincount(labels,weights=now);g1=np.bincount(labels,weights=end)
    loc=np.bincount(labels,weights=local);coarse=(loc/g1)[labels];target=local*(g0/g1)[labels]
    fine=np.divide(target,now,out=np.zeros_like(now),where=now>0)
    rows=[]
    for name,weight in [('coarse',coarse),('fine',fine)]:
        mapped=now*weight
        rows.append(dict(lift=name,target_mass=target.sum(),represented_mass=mapped.sum(),
            group_L1_fraction=np.sum(abs(np.bincount(labels,weights=mapped-target)))/target.sum(),
            cell_L1_fraction=sum(abs(mapped-target))/target.sum(),unpopulated_mass=target[now==0].sum(),
            empty_positive_cells=int(np.count_nonzero((now==0)&(target>0))),
            supported_star_mass=raw[1]@weight,supported_gas_mass=raw[0]@weight,
            max_weight=weight.max(),weighted_mass_above_10x=np.sum(mapped[weight>10])/target.sum()))
    assert rows[0]['group_L1_fraction']<1e-12
    assert abs(rows[1]['target_mass']-rows[1]['represented_mass']-rows[1]['unpopulated_mass'])<1e-4
    buf=io.BytesIO()
    np.savez_compressed(buf,coarse=coarse,fine=fine,target=target,launch=now,star_mass=raw[1],local=local,end_group=g1,labels=labels)
    keep(STAGE/'frozen-weights.npz',buf.getvalue(),True)
    table(STAGE/'launch-mapping.csv',rows,True)
    print(rows,flush=True)
if __name__=='__main__':guard();freeze()
