"""Read the actual initial star/gas velocities separately; no gas identities presumed."""
from material_inputs import *
def run(steps):
    with np.load(STAGE/'frozen-weights.npz') as data:maps={k:data[k] for k in ('fine','coarse')}
    mom=Moment(steps);lab=mom.lab;bg=lab.obj.bg;axis=frames(600)[4][-1]
    sums={};finer={}
    for p in range(4):
        for phase in (4,0):
            guard();arc,meta=input_piece(590,p,phase)
            with arc:
                pos=arc['pos_kpc'];mass=arc['mass_Msun'];rawv=arc['velocity_stored'].astype(float)
                rad=np.linalg.norm(pos,axis=1);unit=pos/rad[:,None];s=unit@axis;mu=np.clip(abs(s),0,1)
                theta=np.arccos(mu);y=rad/bg.length
                cell=(np.searchsorted(jf.EDGES,rad,side='right')-1)*256+np.minimum((mu*256).astype(int),255)
                hub,a,_,center,_=frames(590);h=meta['header'];hz=.1*hub*np.sqrt(h['Omega0']/a**3+h['OmegaLambda']+(1-h['Omega0']-h['OmegaLambda'])/a**2)
                v=(rawv*np.sqrt(a)-center+hz*pos)/bg.vel
                vr=np.einsum('ij,ij->i',unit,v);vt=(mu*vr-np.sign(s)*(v@axis))/np.maximum(1e-14,np.sin(theta))
                for half,(lo,hi) in enumerate(zip(mom.range[:-1],mom.range[1:],strict=True),1):
                    sel=(y>=lo)&(y<hi)
                    for name in ('mass','gravity'):
                        kernels={k:mom.fns[name,half,k].ev(y[sel],theta[sel]) for k in ('field','curvature','radial','polar','rest')}
                        current=kernels['radial']*vr[sel]+kernels['polar']*vt[sel];rest=kernels['rest']*vr[sel]
                        for mode in ('raw','coarse','fine'):
                            w=mass[sel]*mom.scale(name)/lab.mesh.mscale
                            if mode!='raw':w*=maps[mode][cell[sel]]
                            key=phase,half,name,mode
                            sums[key]=sums.get(key,0)+np.array([w@kernels['curvature']*lab.obj.unit_myr,w@kernels['field'],w@current,w@rest,w@(current-rest)])
    rows=[];raw=records(previous(f'raw-comparison-{steps}.csv'))
    for (p,h,n,m),a in sums.items():
        row=dict(steps=steps,phase=p,half=h,observable=n,lift=m,curvature=a[0],field=a[1],current=a[2],rest=a[3],gradient=a[4],cubic=a[1]+a[2])
        if m=='raw':
            old=next(r for r in raw if r['phase']==('stars' if p==4 else 'gas') and r['frame']=='catalog_proper' and r['half']==str(h) and r['observable']==n)
            assert abs(a[4]-float(old['gradient']))<1e-9*max(abs(a[4]),abs(a[2]),1e-28)
        rows.append(row)
    table(STAGE/f'initial-currents-{steps}.csv',rows,True)
if __name__=='__main__':
    for n in (64,32):run(n)
