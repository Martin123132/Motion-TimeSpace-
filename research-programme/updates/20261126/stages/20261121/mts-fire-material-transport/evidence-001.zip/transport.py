"""Cross-file global stellar cohort, including mass loss and unmatched objects separately."""
from material_inputs import *
from moment_io import keep
import io

def snapshot(snap):
    pieces=[]
    for part in range(4):
        guard();arc,meta=piece(snap,part)
        with arc:
            pieces.append({key:arc[key] for key in ('cell','mass_stored','formed_a','ParticleIDs','ParticleChildIDsNumber','ParticleIDGenerationNumber')})
    result={key:np.concatenate([p.pop(key) for p in pieces]) for key in tuple(pieces[0])}
    assert len(result['cell'])==meta['whole']
    return result

def keys(banks):
    names=('ParticleIDs','ParticleChildIDsNumber','ParticleIDGenerationNumber')
    widths=[max(1,max(int(b[k].max()) for b in banks).bit_length()) for k in names]
    keys=[]
    for bank in banks:
        if sum(widths)<=64:
            packed=bank.pop(names[0]).astype(np.uint64)
            for key,width in zip(names[1:],widths[1:],strict=True):
                packed<<=width;packed|=bank.pop(key)
        else:
            packed=np.rec.fromarrays([bank.pop(k) for k in names],names='id,child,generation')
        keys.append(packed)
    return keys,widths

def aggregate():
    with np.load(STAGE/'frozen-weights.npz') as ar:fixed_weights={key:ar[key] for key in ar.files}
    labels=fixed_weights['labels'];nc=len(labels);size=nc+1;groups_ext=np.r_[labels,91]
    maps={name:np.r_[fixed_weights[name],0.] for name in ('coarse','fine')}
    begin=snapshot(590);end=snapshot(591);key,widths=keys([begin,end])
    order=np.argsort(key[1]);sorted_key=key[1][order];assert np.all(sorted_key[:-1]!=sorted_key[1:])
    used=np.zeros(len(order),bool);parents=np.full(len(order),-1,np.int32)
    factor=1e10/frames(590)[0];raw0=np.zeros(size);raw1=np.zeros(size)
    arrays={};sums={};dt=clocks()[1]
    terms=('launch','transported','evolved','missing','destination','relabel_matched','birth_mass','stellar_loss')
    for name in maps:
        arrays.update({name+'_'+k:np.zeros(size) for k in terms})
        sums[name]=dict(crossed_group_Msun=0.,crossed_cell_Msun=0.,squared_weights=0.,largest_tag=0.)
    def hist(c,m):return np.bincount(c,weights=m,minlength=size)
    lost=0;matched=0;total_loss=0.;total_gain=0.
    proof=np.argsort(key[0]);assert np.all(key[0][proof[:-1]]!=key[0][proof[1:]]);del proof
    for start in range(0,len(key[0]),300000):
        guard();sl=slice(start,min(start+300000,len(key[0])));q=key[0][sl]
        where=np.minimum(np.searchsorted(sorted_key,q),len(order)-1);good=sorted_key[where]==q
        dest=order[where[good]];assert not used[dest].any();used[dest]=True
        parents[dest]=start+np.flatnonzero(good)
        c0=begin['cell'][sl].copy();c0[c0<0]=nc;c1=end['cell'][dest].copy();c1[c1<0]=nc
        m0=begin['mass_stored'][sl].astype(float)*factor;m1=end['mass_stored'][dest].astype(float)*factor
        assert np.array_equal(begin['formed_a'][sl][good],end['formed_a'][dest])
        raw0+=hist(c0,m0);raw1+=hist(c1,m1)
        lost+=int((~good).sum());matched+=len(dest)
        total_loss+=float(np.minimum(m1-m0[good],0).sum());total_gain+=float(np.maximum(m1-m0[good],0).sum())
        for name,weight in maps.items():
            src=m0*weight[c0];transported=src[good];live=m1*weight[c0[good]];dst=m1*weight[c1]
            for lab,cell,value in [('launch',c0,src),('transported',c1,transported),('evolved',c1,live),('missing',c0[~good],src[~good]),
                ('destination',c1,dst),('relabel_matched',c1,dst-live),('stellar_loss',c1,live-transported)]:
                arrays[name+'_'+lab]+=hist(cell,value)
            ledger=sums[name];ledger['crossed_group_Msun']+=transported[groups_ext[c0[good]]!=groups_ext[c1]].sum()
            ledger['crossed_cell_Msun']+=transported[c0[good]!=c1].sum()
            ledger['squared_weights']+=src@src;ledger['largest_tag']=max(ledger['largest_tag'],float(src.max()))
    missing1=~used;newcell=end['cell'][missing1].copy();newcell[newcell<0]=nc
    newmass=end['mass_stored'][missing1].astype(float)*factor;raw1+=hist(newcell,newmass)
    rows=[];checks=[]
    for name,weight in maps.items():
        arr=lambda k:arrays[name+'_'+k]
        new=hist(newcell,newmass*weight[newcell]);arr('birth_mass')[:]+=new;arr('destination')[:]+=new
        maxerr=lambda v:float(np.max(abs(v)))/max(1.,np.max(arr('launch')))
        check1=maxerr(arr('transported')+arr('stellar_loss')-arr('evolved'))
        check2=maxerr(arr('evolved')+arr('relabel_matched')+new-arr('destination'))
        assert max(check1,check2)<1e-11
        beginmass=arr('launch').sum();represented=arr('transported').sum()
        assert abs(represented+arr('missing').sum()-beginmass)<2e-12*beginmass
        rows.append(dict(lift=name,launch_Msun=beginmass,transported_Msun=represented,
            stellar_mass_change_Msun_yr=arr('stellar_loss').sum()/(dt*1e6),
            unmatched_launch_Msun=arr('missing').sum(),new_endpoint_Msun_yr=new.sum()/(dt*1e6),
            destination_relabel_Msun_yr=arr('relabel_matched').sum()/(dt*1e6),
            destination_net_Msun_yr=(arr('destination').sum()-beginmass)/(dt*1e6),
            crossed_group_mass_fraction=sums[name]['crossed_group_Msun']/beginmass,
            crossed_cell_mass_fraction=sums[name]['crossed_cell_Msun']/beginmass,
            effective_count=beginmass**2/sums[name]['squared_weights'],largest_tag_Msun=sums[name]['largest_tag'],
            accounting_max_relative=max(check1,check2),endpoint_outside_500_Msun=arr('transported')[-1]))
    assert np.max(abs(raw0[:-1]-fixed_weights['star_mass']))<3e-12*max(raw0[:-1])
    groups1=np.bincount(labels,weights=raw1[:-1]);oldg=np.zeros(91)
    for p in range(4):
        with input_piece(591,p,4)[0] as a:oldg+=a['group_mass_Msun']
    assert max(abs(groups1-oldg))<1e-10*max(oldg)
    meta=dict(key_bits=widths,matched=matched,unmatched_launch=lost,unmatched_endpoint=int(missing1.sum()),
              count590=len(key[0]),count591=len(key[1]),matched_raw_loss_Msun=total_loss,
              matched_raw_gain_Msun=total_gain,unmatched_endpoint_raw_Msun=newmass.sum(),interval_Myr=dt,
              unmatched_endpoint_formed_after_launch=int(np.sum(end['formed_a'][missing1]>frames(590)[1])),
              unmatched_endpoint_formed_by_end=int(np.sum(end['formed_a'][missing1]<=frames(591)[1]+1e-7)),
              exact_counts_verified=bool(lost+matched==len(key[0]) and matched+missing1.sum()==len(key[1])))
    assert meta['exact_counts_verified']
    buf=io.BytesIO();np.savez_compressed(buf,**arrays,raw0=raw0,raw1=raw1)
    keep(STAGE/'stellar-histories.npz',buf.getvalue(),True)
    buf=io.BytesIO();np.savez_compressed(buf,parent=parents)
    keep(STAGE/'stellar-links.npz',buf.getvalue(),True)
    keep(STAGE/'identity.json',(json.dumps(meta,indent=2)+'\n').encode(),True)
    table(STAGE/'stellar-mass-accounting.csv',rows,True)
    print(meta,rows,flush=True)
if __name__=='__main__':guard();aggregate()
