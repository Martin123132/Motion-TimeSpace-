"""Transport both original preparations through the same two measured epochs; no fits."""
from material_inputs import *
from mts_retarded_launch_io import Evolution,advance
from moment_io import keep
import io

def integrate(lab,start,end,count):
    obj=lab.obj;dt=clocks()[1]/(obj.unit_myr*count)
    solver=Evolution(obj,dt,lab.initial['reset']);frames_out={};norm=0.
    for name,left in lab.initial.items():
        wave=left.copy();moment=obj.moment(wave);number=np.vdot(left,left).real
        for i in range(count):
            guard()
            external=start+(end-start)*((i+.5)/count)
            wave,moment,_,_=advance(obj,solver,wave,moment,external,dt)
            norm=max(norm,abs(np.vdot(wave,wave).real/number-1))
        frames_out[name]=wave
    return frames_out,norm

def run(steps,nstep):
    lab=Launch(steps);run=lab.run;bg=lab.obj.bg;start=run.fields[590]
    with np.load(STAGE/'endpoint-field-increments.npz') as ar:incs={k:ar[k] for k in ar.files}
    sol={};rows=[];outputs={};cols=('inner_r','inner_theta','outer_r','outer_theta')
    tags=('old_stars','fine_evolved') if nstep>8 else ('old_stars','fine_transported','fine_evolved','fine_destination','coarse_transported')
    for tag in tags:
        end=start+incs['old_gas']+incs[tag]
        states,err=integrate(lab,start,end,nstep);assert err<1e-10
        forces={k:run.gravity(v)*1e-10 for k,v in states.items()};sol[tag]=forces
        for arm in ('reset','coupled','contrast'):
            f=forces[arm] if arm!='contrast' else forces['coupled']-forces['reset']
            ref=sol['old_stars'];base=ref[arm] if arm!='contrast' else ref['coupled']-ref['reset']
            row=dict(steps=steps,substeps=nstep,model=tag,arm=arm,norm_fraction=err,
                input_delta_rms_kms2=float(np.sqrt(np.sum(lab.prob*((end-start)*bg.vel**2)**2))))
            row.update(dict(zip(cols,f,strict=True)));row.update(dict(zip(('change_'+c for c in cols),f-base,strict=True)));rows.append(row)
        if steps==64 and nstep==8:
            outputs.update({tag+'_'+k:v for k,v in states.items()})
    table(STAGE/f'wave-{steps}-{nstep}.csv',rows,True)
    if outputs:
        buf=io.BytesIO();np.savez_compressed(buf,**outputs);keep(STAGE/'tested-waves-591.npz',buf.getvalue(),True)
    print('wave',steps,nstep,'finished',flush=True)
if __name__=='__main__':
    for steps,num in (((64,16),(64,32)) if '--refine' in sys.argv else ((32,2),(64,2),(64,4),(64,8))):guard();run(steps,num)
