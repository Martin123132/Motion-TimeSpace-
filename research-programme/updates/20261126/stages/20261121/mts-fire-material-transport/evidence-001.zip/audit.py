"""Cross-check mass, matched IDs, fixed preparation, point/bin readouts and paired dynamics."""
from material_inputs import *
from moment_io import keep
import ast
def run():
    guard()
    for src in STAGE.glob('*.py'):ast.parse(src.read_bytes())
    report={};meta=json.loads((STAGE/'identity.json').read_bytes())
    assert meta['unmatched_launch']==0 and meta['matched']==meta['count590']
    assert meta['unmatched_endpoint']==meta['unmatched_endpoint_formed_after_launch']==meta['unmatched_endpoint_formed_by_end']
    assert meta['count591']==meta['matched']+meta['unmatched_endpoint']
    for ss in (590,591):
        ns=[];sz=0
        for p in range(4):
            a,m=piece(ss,p)
            with a:assert len(a['cell'])==m['count'] and ('vr_kms' in a.files)==(ss==590)
            ns.append(m['count']);sz+=m['bytes'];old=json.loads(previous(f'inputs/s{ss}-{p}-p4.json').read_bytes())
            assert m['url']==old['url'] and m['identity']==old['identity']
            assert all(m['fields'][k]==v for k,v in old['field_sha256'].items())
        assert sum(ns)==meta['count'+str(ss)];report['verified_packet_bytes_'+str(ss)]=sz
    with np.load(STAGE/'stellar-links.npz') as data:
        link=data['parent'];valid=link[link>=0]
        assert len(np.unique(valid))==len(valid)==meta['count590'] and np.min(valid)==0 and np.max(valid)==len(valid)-1
    report.update(meta)
    mapping=records(STAGE/'launch-mapping.csv');assert float(mapping[0]['group_L1_fraction'])<1e-12
    for row in records(STAGE/'stellar-mass-accounting.csv'):
        assert abs(float(row['transported_Msun'])/float(row['launch_Msun'])-1)<2e-12 and float(row['accounting_max_relative'])<1e-11
    assert max(float(r['relative_L2_error']) for r in records(STAGE/'point-interpolation.csv'))<1e-7
    get=lambda filename:records(STAGE/filename)
    init=get('point-launch.csv');end=get('point-endpoint.csv');cells=get('source-moments-64.csv')
    rows=[]
    for row in end:
        which=row['mode'];name=row['readout'];lift=which.split('_')[0];dt=meta['interval_Myr']
        base=next(x for x in init if x['mode']==lift+'_destination' and x['readout']==name)
        speed=(float(row['moment'])-float(base['moment']))/dt;predict=float(base['instantaneous'])
        cell=float(next(x for x in cells if x['model']==which)[name])
        rows.append(dict(model=which,readout=name,instantaneous_material_prediction=predict,measured_secant=speed,
                         secant_minus_instant=speed-predict,cell_readout=cell,cell_minus_point=cell-speed))
    table(STAGE/'continuous-test.csv',rows,True)
    wave=[]
    for count in (2,4,8,16,32):
        rd=get(f'wave-64-{count}.csv')
        assert max(float(v['norm_fraction']) for v in rd)<1e-10
        vals=next(x for x in rd if x['arm']=='contrast' and x['model']=='fine_evolved')
        wave.append(np.array([float(vals['change_'+c]) for c in ('inner_r','inner_theta','outer_r','outer_theta')]))
    report['wave_last_refinement_max_component_change_m_s2']=max(abs(wave[-1]-wave[-2]))
    report['wave_last_refinement_vector_fraction']=np.linalg.norm(wave[-1]-wave[-2])/np.linalg.norm(wave[-1])
    assert report['wave_last_refinement_vector_fraction']<.05
    previous('hybrid-64.csv')
    old=len(cells);assert old==8
    gasstar=sum(float(r['mass_rate_Msun_yr']) for r in cells if r['model'] in ('old_stars','old_gas'))
    exterior=next(r for r in records(previous('exterior-exchange-64.csv')) if r['slope']=='near_right')
    assert abs(gasstar-float(exterior['hybrid_Msun_yr']))<1e-8
    for nr in (769,1537):
        trajectories=get(f'star-orbits-{nr}.csv')
        assert len(trajectories)==(24 if nr==1537 else 20) and len({r['selected_count'] for r in trajectories})==1
        assert int(trajectories[0]['selected_count'])==sum(json.loads(previous(f'inputs/s590-{p}-p4.json').read_bytes())['shell_count'] for p in range(4))
    orig=get('initial-currents-64.csv');sub={r['observable']+r['half']:r for r in orig if r['phase']=='4' and r['lift']=='fine'}
    orows=[]
    for nr in (769,1537):
        results=get(f'star-orbits-{nr}.csv')
        for name,pri in sub.items():
            items={float(r['time_Myr']):float(r['contrast']) for r in results if r['observable']==name}
            for time in (.06,.03):
                curvature=(items[time]+items[-time])/time**2
                cubic=3*(items[time]-items[-time])/time**3
                cp=float(pri['curvature']);jp=float(pri['cubic'])
                orows.append(dict(grid=nr,halfspan_Myr=time,observable=name,curvature=curvature,expected_curvature=cp,
                                  curvature_fractional_difference=curvature/cp-1,cubic=cubic,expected_cubic=jp,cubic_fractional_difference=cubic/jp-1))
    table(STAGE/'live-orbit-derivatives.csv',orows,True)
    assert all(np.isfinite(float(v)) for row in orows for k,v in row.items() if k!='observable')
    report['fine_short_max_curvature_error']=max(abs(r['curvature_fractional_difference']) for r in orows if r['grid']==1537 and r['halfspan_Myr']==.03)
    report['fine_short_max_cubic_error']=max(abs(r['cubic_fractional_difference']) for r in orows if r['grid']==1537 and r['halfspan_Myr']==.03)
    for document in ('RESULTS.md','DERIVATION.md','REPLAY.md'):
        path=STAGE/document
        if path.exists():
            import re
            for target in re.findall(r'\]\(([^)]+)\)',path.read_text(encoding='utf8')):
                if not target.startswith(('https://','http://')):assert (STAGE/target).is_file(),target
    assert not list(STAGE.rglob('*.work')) and not list(STAGE.rglob('*.pyc'))
    keep(STAGE/'validation.json',(json.dumps(report,indent=2,sort_keys=True)+'\n').encode(),True)
    if '--seal' in sys.argv:
        assert (STAGE/'RESULTS.md').is_file() and (STAGE/'DERIVATION.md').is_file()
        paths=sorted(p for p in STAGE.rglob('*') if p.is_file() and p!=STAGE/'seal.json')
        keep(STAGE/'seal.json',(json.dumps({p.relative_to(STAGE).as_posix():digest(p) for p in paths},indent=2,sort_keys=True)+'\n').encode(),True)
        print(len(paths),digest(STAGE/'seal.json'))
    print(json.dumps(report,indent=1))
if __name__=='__main__':run()
