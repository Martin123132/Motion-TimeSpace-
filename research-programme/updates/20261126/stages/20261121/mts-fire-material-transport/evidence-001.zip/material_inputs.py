"""Only verified, local predecessors and the private new stage directory."""
import os
for variable in ('OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','OMP_NUM_THREADS','NUMEXPR_NUM_THREADS','BLIS_NUM_THREADS'):
    os.environ[variable]='1'
from pathlib import Path
import hashlib,json,sys
STAGE=Path(__file__).resolve().parent
OLD=STAGE.parent/'mts-fire-current-moment-20261121'
def digest(path):
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
OLD_SEAL='e4b2446f5c018c3de8cb3b4175ff68d581dd984ffe87a56d62219e5d2cadd1d8'
assert digest(OLD/'seal.json')==OLD_SEAL
manifest=json.loads((OLD/'seal.json').read_bytes())
def previous(name):
    path=OLD/name;assert digest(path)==manifest[name],name
    return path
for name in ('acquire.py','moment_io.py','particle_readout.py','density_slopes.py','virial.py','drift_control.py'):previous(name)
sys.path.insert(0,str(OLD))
from density_slopes import jf,frames,groups,fixed,Launch,np,records,table,Moment,clocks
from moment_io import source,input_piece,check as inherited
def guard():
    inherited();assert not (STAGE/'STOP-REQUESTED').exists()
def piece(snap,part):
    path=STAGE/'stars'/f's{snap}-{part}.npz';meta=json.loads(path.with_suffix('.json').read_bytes())
    assert digest(path)==meta['sha256'];return np.load(path),meta
