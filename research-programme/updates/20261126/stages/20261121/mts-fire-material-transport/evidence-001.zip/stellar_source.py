"""One public stellar field and one output piece at a time."""
from material_inputs import *
import time,datetime

def collect(snap,part,deadline):
    guard()
    path=STAGE/'stars'/f's{snap}-{part}.npz';path.parent.mkdir(exist_ok=True)
    if path.with_suffix('.json').exists():
        archive,_=piece(snap,part);archive.close();return
    assert not path.exists() and not path.with_suffix('.work').exists()
    meta=json.loads(previous(f'inputs/s{snap}-{part}-p4.json').read_bytes())
    fields={};hashes={};size=0
    hub,a,center,_,_=frames(snap);axis=frames(600)[4][-1];n=meta['counts'][4]
    names=['ParticleIDs','ParticleChildIDsNumber','ParticleIDGenerationNumber','Masses','StellarFormationTime','Coordinates']
    if snap==590:names.append('Velocities')
    remote=source.Remote(meta['url'],65536)
    try:
        assert list(remote.id)==meta['identity']
        with source.h5py.File(remote,'r') as data:
            spans=[]
            for name in names:
                dataset=data['PartType4/'+name]
                dataset.id.chunk_iter(lambda chunk:spans.append((chunk.byte_offset,chunk.byte_offset+chunk.size)))
            runs=[]
            for first,last in sorted(spans):
                if runs and first<=runs[-1][1]+32768:runs[-1][1]=max(last,runs[-1][1])
                else:runs.append([first,last])
            assert sum(end-start for start,end in runs)<230_000_000
            for first,last in runs:
                guard();buf=bytearray(last-first)
                for start in range(first,last,8*1024**2):
                    assert time.time()<deadline
                    count=min(last-start,8*1024**2);buf[start-first:start-first+count]=remote.range(start,count)
                remote.spans.append((first,buf))
            for name in names:
                dataset=data['PartType4/'+name];assert len(dataset)==n
                values=dataset[:]
                hashes[name]=hashlib.sha256(memoryview(np.ascontiguousarray(values))).hexdigest()
                if name in meta['field_sha256']:assert hashes[name]==meta['field_sha256'][name]
                if name=='Coordinates':
                    radius=np.empty(n,np.float32);mu=np.empty(n,np.float32);cell=np.empty(n,np.int32)
                    if snap==590:unitvec=np.empty((n,3),np.float32);signs=np.empty(n,np.int8)
                    for start in range(0,n,240000):
                        sl=slice(start,min(start+240000,n));delta=values[sl]-hub*center
                        box=meta['header']['BoxSize'];pos=(delta-box*np.rint(delta/box))*a/hub
                        rr=np.linalg.norm(pos,axis=1);signed=(pos@axis)/np.maximum(rr,1e-80);ang=np.clip(abs(signed),0,1)
                        if snap==590:unitvec[sl]=pos/rr[:,None];signs[sl]=np.sign(signed)
                        rid=np.searchsorted(jf.EDGES,rr,side='right')-1
                        aid=np.minimum((ang*256).astype(int),255)
                        cell[sl]=np.where(rr<500,rid*256+aid,-1);radius[sl]=rr;mu[sl]=ang
                    fields.update(cell=cell,r_kpc=radius,mu=mu)
                elif name=='Velocities':
                    vv=values.astype(float)*np.sqrt(a)-frames(snap)[3]
                    vr=np.einsum('ij,ij->i',vv,unitvec);meta_h=meta['header']
                    hz=.1*hub*np.sqrt(meta_h['Omega0']/a**3+meta_h['OmegaLambda']+(1-meta_h['Omega0']-meta_h['OmegaLambda'])/a**2)
                    xx=mu.astype(float)
                    fields['vr_kms']=(vr+hz*radius).astype(np.float32)
                    fields['vt_kms']=np.divide(xx*vr-signs*(vv@axis),np.sqrt(1-xx**2),out=np.zeros_like(vr),where=xx<1).astype(np.float32)
                elif name=='Masses':fields['mass_stored']=values.copy()
                elif name=='StellarFormationTime':fields['formed_a']=values.copy()
                else:
                    limit=255 if name=='ParticleIDGenerationNumber' else 2**32-1
                    assert values.min()>=0 and values.max()<=limit
                    fields[name]=values.astype(np.uint8 if limit==255 else np.uint32)
                del values
    finally:size+=remote.transferred;remote.close()
    assert size<270_000_000
    with path.with_suffix('.work').open('xb') as stream:np.savez_compressed(stream,**fields)
    path.with_suffix('.work').rename(path)
    receipt=dict(snap=snap,part=part,count=n,whole=meta['whole'][4],url=meta['url'],identity=meta['identity'],
                 fields=hashes,bytes=size,sha256=digest(path))
    with path.with_suffix('.json').open('x') as stream:json.dump(receipt,stream,indent=2)
    print(snap,part,n,size,flush=True)

if __name__=='__main__':
    deadline=datetime.datetime.fromisoformat(sys.argv[1]).timestamp();assert time.time()<deadline<time.time()+14400
    for snap in (590,591):
        for part in range(4):collect(snap,part,deadline)
