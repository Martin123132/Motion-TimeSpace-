"""Score material sources on the original mass grid without a measured force target."""
from material_inputs import *
from virial import green,Radial
from density_slopes import legvander
from scipy.constants import parsec
from scipy.special import eval_legendre,roots_legendre
from moment_io import keep
import io

def models():
    with np.load(STAGE/'frozen-weights.npz') as a:local,end,labels=(a[k] for k in ('local','end_group','labels'))
    with np.load(STAGE/'stellar-histories.npz') as h:
        assert all(h[k][-1]==0 for k in ('coarse_transported','fine_transported','coarse_evolved','fine_evolved'))
        raw=h['raw1'][:-1]-h['raw0'][:-1]
        mapped=lambda d:local*(d/end)[labels]
        source={'old_stars':mapped(np.bincount(labels,weights=raw))}
        for mode in ('coarse','fine'):
            for kind in ('transported','evolved','destination'):
                source[mode+'_'+kind]=(h[mode+'_'+kind]-h[mode+'_launch'])[:-1]
    gas=[]
    for s in (590,591):
        m=np.zeros(91)
        for p in range(4):
            with input_piece(s,p,0)[0] as a:m+=a['group_mass_Msun']
        gas.append(m)
    return {k:v.reshape(len(jf.RC),len(jf.UC)) for k,v in source.items()},mapped(gas[1]-gas[0]).reshape(len(jf.RC),len(jf.UC))

def harmonic(ell):
    leg=legvander(jf.ANG,ell[-1]+1)
    avg=np.ones((len(jf.UC),len(ell)))
    for j,l in enumerate(ell[1:],1):avg[:,j]=np.diff(leg[:,l+1]-leg[:,l-1])/((2*l+1)*np.diff(jf.ANG))
    return avg

def newton(hist,ell):
    avg=hist@harmonic(ell);out=[]
    for R in (6.,8.3):
        r=np.hypot(R,1.5);mu=1.5/r
        kernel=(np.minimum(r,jf.RC)/np.maximum(r,jf.RC))[:,None]**ell/np.maximum(r,jf.RC)[:,None]/r
        p=eval_legendre(ell,mu);der=np.zeros_like(p);der[1:]=ell[1:]*(eval_legendre(ell[1:]-1,mu)-mu*p[1:])/(1-mu**2)
        out.extend([np.sum(avg*kernel*np.where(jf.RC[:,None]<r,-(ell+1),ell)*p),
                    -np.sqrt(1-mu**2)*np.sum(avg*kernel*der)])
    return np.array(out)*jf.ls.G*1e3/parsec

def grid_kernels(mom):
    lab=mom.lab;bg=lab.obj.bg;box=Radial(lab,16);ell=box.sell
    inwave=jf.RC<box.inf*bg.length;y=jf.RC[inwave]/bg.length
    pt=np.r_[y,box.inf];val,grad,_=green(lab,box,pt)
    B=np.empty((len(jf.RC),len(ell)))
    B[inwave]=2*val[:-1,:,0]+y[:,None]*grad[:-1,:,0]
    B[~inwave]=(1-ell)*val[-1,:,0]*(box.inf*bg.length/jf.RC[~inwave,None])**(ell+1)
    kernels={'virial':-(B*np.sqrt(2*ell+1))@harmonic(ell).T*(bg.length/lab.obj.unit_myr)**2}
    nod,wei=roots_legendre(8);mu=jf.UC[:,None]+np.diff(jf.ANG)[:,None]*nod/2;theta=np.arccos(mu)
    for half,(lo,hi) in enumerate(zip(mom.range[:-1],mom.range[1:],strict=True),1):
        radius=jf.RC/bg.length;sel=(radius>=lo)&(radius<hi)
        for name in ('mass','gravity'):
            arr=np.zeros_like(kernels['virial']);arr[radius<lo]=mom.inside[name,half]
            yy=np.broadcast_to(radius[sel,None,None],(int(sel.sum()),*theta.shape))
            arr[sel]=mom.fns[name,half,'D'].ev(yy.ravel(),np.broadcast_to(theta,yy.shape).ravel()).reshape(yy.shape)@(wei/2)
            kernels[f'{name}{half}']=arr*mom.scale(name)*lab.obj.unit_myr/lab.mesh.mscale
    return kernels

def run(steps):
    guard();mom=Moment(steps);lab=mom.lab;bg=lab.obj.bg;src,gas=models();kern=grid_kernels(mom);dt=clocks()[1]
    rows=[];fields={};harm=legvander(bg.mu,64)[:,::2].T;names=('inner_r','inner_theta','outer_r','outer_theta')
    for name,mass in dict(src,old_gas=gas).items():
        forces=newton(mass,np.arange(0,65,2))
        row=dict(steps=steps,model=name,mass_rate_Msun_yr=mass.sum()/(dt*1e6),**{k:np.sum(v*mass)/dt for k,v in kern.items()})
        row.update(dict(zip(names,forces,strict=True)));rows.append(row)
        if steps==64 and name in ('old_stars','old_gas','coarse_transported','fine_transported','fine_evolved','fine_destination'):
            fields[name]=jf.coeffs(mass,bg.rad*bg.length,64)@harm/bg.vel**2
    if fields:
        buf=io.BytesIO();np.savez_compressed(buf,**fields);keep(STAGE/'endpoint-field-increments.npz',buf.getvalue(),True)
    table(STAGE/f'source-moments-{steps}.csv',rows,True)
if __name__=='__main__':
    for steps in (64,32):run(steps)
