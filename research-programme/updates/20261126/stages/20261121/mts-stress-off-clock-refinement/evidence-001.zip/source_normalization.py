"""Unbounded-prior strip intersections for a known density and a known stress response."""
from decimal import Decimal, localcontext
from itertools import combinations
from math import isclose
from clock_test import HERE, table, task, np
from scipy.optimize import linprog


def projections(rows):
    with localcontext() as context:
        context.prec = 60
        bound = Decimal(20)
        data = [tuple(Decimal(str(value)) for value in row) for row in rows]
        edges = [(side*p,side*t,bound+side*d) for p,t,d in data for side in (1,-1)]
        options = []
        for first,second in combinations(edges,2):
            p,t,d=first
            pp,tt,dd=second
            det=p*tt-t*pp
            if not det:
                continue
            u,v=(d*tt-t*dd)/det,(p*dd-d*pp)/det
            if all(a*u+b*v-c<=Decimal("1e-42")*(1+abs(a*u)+abs(b*v)+abs(c)) for a,b,c in edges):
                options.append((u,v))
        design = np.array([[float(a),float(b)] for a,b,_ in edges])
        rhs = np.array([float(c) for _,_,c in edges])
        result={}
        for label, direction in (("density",(1.,0.)),("stress",(0.,1.))):
            for name,sign in (("min",1),("max",-1)):
                answer=linprog(np.asarray(direction)*sign,A_ub=design,b_ub=rhs,bounds=[(None,None)]*2,method="highs")
                if answer.status==2:
                    assert not options
                    result[label+"_"+name]="empty"
                elif answer.status==3:
                    result[label+"_"+name]="unbounded"
                else:
                    assert answer.success
                    extrema=(min if sign>0 else max)
                    if options:
                        index=direction.index(1.)
                        derived=float(extrema(point[index] for point in options))
                        assert isclose(derived,answer.fun*sign,abs_tol=1e-6,rel_tol=1e-7)
                        result[label+"_"+name]=derived
                    else:
                        result[label+"_"+name]=float(sign*answer.fun)
        return result


def line(rows,unit_density,unit_stress):
    low,high=float("-inf"),float("inf")
    for density,stress,measured in rows:
        scale=density*unit_density+stress*unit_stress
        if scale==0:
            if abs(measured)>20:
                return None
            continue
        left,right=sorted(((measured-20)/scale,(measured+20)/scale))
        low,high=max(low,left),min(high,right)
    return (low,high) if low<=high else None


def controls():
    independent=[(10.,0.,4.),(0.,20.,5.)]
    assert projections(independent)==dict(density_min=-1.6,density_max=2.4,stress_min=-.75,stress_max=1.25)
    assert all(value=="empty" for value in projections(independent+[(10.,0.,105.)]).values())
    parallel=[(2.,4.,50.),(4.,8.,100.)]
    assert all(value=="unbounded" for value in projections(parallel).values())
    assert line(independent,1.,1.)==(-.75,1.25) and line(parallel,1.,0.)==(20.,30.)
    assert line([(0.,0.,30.)],1.,1.) is None


def score():
    controls()
    sources=task.read(HERE/"physical-transfer.csv")
    assert len(sources)==32
    output=[]
    for label,group in (("all",sources),("temporal",[row for row in sources if row["reader"]=="temporal"]),
                        ("final-temporal",[row for row in sources if row["reader"]=="temporal" and row["tick"]=="1024"])):
        rows=[tuple(float(row[field]) for field in ("induced_density_ppm","forecast_beyond_density_ppm","measured_difference_ppm")) for row in group]
        for saved,(density,stress,measured) in zip(group,rows,strict=True):
            assert abs(measured-density-stress-float(saved["paired_error_ppm"]))<1e-7
        outcome=projections(rows)
        for tag,axis in (("common",(1,1)),("density_alone",(1,0)),("stress_alone",(0,1))):
            limits=line(rows,*axis)
            outcome[tag+"_possible"]=limits is not None
            outcome[tag+"_low"],outcome[tag+"_high"]=limits if limits else ("","")
        predicted=max(abs(measured-density-stress) for density,stress,measured in rows)
        zero=max(abs(measured) for _,_,measured in rows)
        sv=np.linalg.svd(np.array(rows)[:,:2],compute_uv=False)
        output.append(dict(readers=label,count=len(rows),unit_max_residual_ppm=predicted,unit_allowed=predicted<=20,
            zero_max_residual_ppm=zero,zero_allowed=zero<=20,small_to_large_singular_value=sv[-1]/sv[0],**outcome))
    table("two-source-constraints.csv",output)
    for row in output:print(row,flush=True)


if __name__=="__main__":
    score()
