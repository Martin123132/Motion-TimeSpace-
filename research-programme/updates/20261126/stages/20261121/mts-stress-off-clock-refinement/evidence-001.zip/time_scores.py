"""Read the signed tides on a common clock before comparing any model bands."""
from clock_test import *
from math import fsum

def indices(sign):
    if sign<0:return "negative-grid-scores.csv","native_newton","newton_twin"
    return "grid-scores.csv","native","twin"

def official(sign):
    file,nkey,tkey=indices(sign)
    assert task.lab.sha(PARENT/file)==task.meta(PARENT/"seal.json")["files"][file]
    return {(int(row["tick"]),float(row["width"]),row["reader"]):(float(row[nkey]),float(row[tkey]),float(row["n960"])) for row in task.read(PARENT/file)}

def members(sign,tick,reader,width,start,div,pin):
    def one(flag):return receipt(path_for(sign,flag,start,div,tick),pin)["observed"][reader][WIDTHS.index(width)]
    return np.array([one(0),one(1)])

def old_members(sign,tick,reader,width):
    def one(flag):return task.meta(anchor(sign,flag,tick).with_suffix(".json"))["readings"][reader][WIDTHS.index(width)]
    return np.array([one(0),one(1)])

def contrast(arr):
    return fsum((arr[0],-arr[1]))

def late():
    pin=lock();rows=[];timing=[]
    for sign in (-1,1):
        base=official(sign)
        for width in WIDTHS:
            for reader in ("temporal","space"):
                newton,twin,saved=base[1024,width,reader]
                unit=abs(newton)*1e-6
                for tick in ticks(768):
                    readings=[members(sign,tick,reader,width,768,div,pin) for div in (1,2,3)]
                    native,half,third=readings
                    shifts=[contrast(value-native)/unit for value in (half,third)]
                    timing.append(dict(sign=sign,width=width,reader=reader,tick=tick,unit_final=unit,native_tide=contrast(native),
                          late_half_tide=contrast(half),late_third_tide=contrast(third),half_minus_native_ppm=shifts[0],
                          third_minus_native_ppm=shifts[1],third_minus_half_ppm=contrast(third-half)/unit))
                    if tick!=1024:continue
                    actual=[(contrast(value)-twin)/unit for value in readings]
                    assert abs(actual[0]-saved)<1e-5
                    rows.append(dict(sign=sign,width=width,reader=reader,tick=tick,unit=unit,native_ppm=actual[0],late_half_ppm=actual[1],
                          late_third_ppm=actual[2],half_minus_native_ppm=shifts[0],third_minus_half_ppm=contrast(third-half)/unit,
                          wave_half_shift_ppm=(half-native)[0]/unit,cold_half_shift_ppm=(half-native)[1]/unit))
    table("late-time-scores.csv",rows);table("late-time-evolution.csv",timing)
    print("largest late half-native, third-half:",*[max(abs(row[key]) for row in rows) for key in ("half_minus_native_ppm","third_minus_half_ppm")],flush=True)
    return rows

def full():
    pin=lock();rows=[];diag=[];budget=[]
    for sign in (-1,1):
        base=official(sign)
        for tick in CLOCKS:
            for width in WIDTHS:
                for reader in ("temporal","space"):
                    target,twin,saved=base[tick,width,reader]
                    unit=abs(target)*1e-6
                    old=old_members(sign,tick,reader,width)
                    refined=members(sign,tick,reader,width,0,2,pin)
                    offset=(contrast(refined)-twin)/unit
                    shifted=contrast(refined-old)/unit
                    assert abs(offset-saved-shifted)<1e-5
                    rows.append(dict(sign=sign,tick=tick,width=width,reader=reader,unit=unit,newton_twin=twin,native_ppm=saved,full_half_ppm=offset,
                        full_half_minus_native_ppm=shifted,inside=abs(offset)<=20,wave_shift_ppm=(refined-old)[0]/unit,
                        cold_shift_ppm=(refined-old)[1]/unit))
                    if tick==1024:
                        local=members(sign,tick,reader,width,768,2,pin)
                        carried=contrast(refined-local)/unit
                        recent=contrast(local-old)/unit
                        assert abs(shifted-(carried+recent))<1e-6
                        budget.append(dict(sign=sign,width=width,reader=reader,native_ppm=saved,full_half_ppm=offset,
                            accumulated_step_shift_ppm=shifted,inherited_state_ppm=carried,last_quarter_ppm=recent,
                            time_change_over_native_offset=shifted/saved))
        for flag in (0,1):
            for start,div in CASES:
                for tick in CLOCKS:
                    if tick<=start:continue
                    path=path_for(sign,flag,start,div,tick)
                    receipt(path,pin)
                    with np.load(path) as bank:
                        rad=bank["r"]
                        for label,mask in (("first",rad<1/GRID),("core",rad<.3),("bulk",(rad>.6)&(rad<2.1))):
                            momentum=np.linalg.norm(bank["ind_P"][mask]);current=np.linalg.norm(bank["ind_J"][mask])
                            diag.append(dict(sign=sign,flag=flag,start=start,div=div,tick=tick,region=label,
                                ham_norm=np.linalg.norm(bank["ind_H"][mask]),polar_defect=momentum,polar_current=current,
                                defect_over_current=momentum/current if current else "",signed_first_defect=bank["ind_P"][0]))
    table("full-time-scores.csv",rows);table("inherited-clock-budget.csv",budget);table("raw-constraints.csv",diag)
    print("largest full half-native:",max(abs(row["full_half_minus_native_ppm"]) for row in rows),
          "final temporal",[(row["sign"],row["width"],row["full_half_ppm"]) for row in budget if row["reader"]=="temporal"],flush=True)
    return rows
if __name__=="__main__":
    late()
    if sys.argv[1:]!=["late"]:full()
