"""Exactly integrated fast carrier driving an otherwise slow test variable."""
from cmath import exp
from math import pi
from clock_test import table
import coupled


def moments(subdivision, harmonic):
    angle = 8*pi*harmonic
    coeff = coupled.core.central.traced.collar.coefficients(0.)
    nodes = (0.,.5,.5,1.)
    weights = (coeff[3],coeff[4],coeff[4],coeff[5])
    assert max(abs(derived-expected) for derived, expected in zip(weights,(1/6,1/3,1/3,1/6),strict=True))<1e-13
    times = [((step+node)/subdivision,weight/subdivision) for step in range(subdivision)
             for node,weight in zip(nodes,weights,strict=True)]
    constant = sum(weight*exp(1j*angle*time) for time,weight in times)
    slope = sum(weight*time*exp(1j*angle*time) for time,weight in times)
    exact_slope = 1/(1j*angle)
    step_angle=angle/subdivision
    def filt(theta):
        return (1+4*exp(1j*theta/2)+exp(1j*theta))/6
    if (4*harmonic)%subdivision:
        exact_discrete = 0j
        linear_discrete = -filt(step_angle)/(subdivision*(1-exp(1j*step_angle)))
    else:
        exact_discrete = filt(step_angle)
        linear_discrete = (subdivision-1)*exact_discrete/(2*subdivision)+(2*exp(1j*step_angle/2)+exp(1j*step_angle))/(6*subdivision)
    assert abs(constant-exact_discrete)<2e-13 and abs(slope-linear_discrete)<2e-13
    return dict(substeps=subdivision,harmonic=harmonic,constant_real=constant.real,constant_imag=constant.imag,
                exact_constant=0.,linear_real=slope.real,linear_imag=slope.imag,exact_linear_imag=exact_slope.imag,
                linear_absolute_error=abs(slope-exact_slope))


if __name__=="__main__":
    rows=[moments(div,harmonic) for harmonic in (1,2,3) for div in (1,2,3,5)]
    table("clock-phase-controls.csv",rows)
    print("manufactured forced slow channel:",len(rows),"carrier and slow-envelope controls")
