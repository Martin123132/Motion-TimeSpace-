"""Direct flat-background metric vertices and a finite source-free Maxwell packet."""
from itertools import product
from clock_test import np,table
from scipy.integrate import quad
from scipy.special import roots_hermitenorm
from numpy.polynomial.legendre import leggauss
from functools import lru_cache
from math import pi

ETA=np.diag([-1.,1.,1.,1.])
INDICES=range(4)

def photon(electric,magnetic):
    field=np.zeros((4,4));field[0,1:]=electric
    field[2,3],field[3,1],field[1,2]=magnetic
    return field-field.T

def traces(raw):
    ric=np.einsum("ac,abcd->bd",ETA,raw)
    total=np.sum(ETA*ric)
    out=np.zeros_like(raw)
    for aa,bb,cc,dd in product(INDICES,repeat=4):
        out[aa,bb,cc,dd]=(raw[aa,bb,cc,dd]-(ETA[aa,cc]*ric[bb,dd]-ETA[aa,dd]*ric[bb,cc]
            -ETA[bb,cc]*ric[aa,dd]+ETA[bb,dd]*ric[aa,cc])/2+total*(ETA[aa,cc]*ETA[bb,dd]-ETA[aa,dd]*ETA[bb,cc])/6)
    return out,ric,total

def weyl_source(field):
    raw=np.einsum("ij,kl->ijkl",field,field)
    return traces(raw-(raw+raw.transpose(0,3,1,2)+raw.transpose(0,2,3,1))/3)[0]

def metric(qcov,metric):
    riemann=np.empty((4,4,4,4))
    for aa,bb,cc,dd in product(INDICES,repeat=4):
        riemann[aa,bb,cc,dd]=(-qcov[bb]*qcov[cc]*metric[aa,dd]-qcov[aa]*qcov[dd]*metric[bb,cc]+qcov[aa]*qcov[cc]*metric[bb,dd]+qcov[bb]*qcov[dd]*metric[aa,cc])/2
    return traces(riemann)

def vertices():
    rows=[]
    for index,(electric,magnetic) in enumerate([([1.,2.,3.],[2.,-1.,1.]),([-.5,.25,1.],[0.,0.,0.]),([0.,0.,0.],[2.,3.,-1.])]):
        electric,magnetic=map(np.array,(electric,magnetic))
        field=photon(electric,magnetic);dual=photon(magnetic,-electric)
        invariant=np.sum(field*(ETA@field@ETA))
        stress=lambda arr:arr@ETA@arr.T-ETA*np.sum(arr*(ETA@arr@ETA))/4
        np.testing.assert_allclose(stress(field),stress(dual),atol=1e-14)
        source=weyl_source(field)
        np.testing.assert_allclose(source,-weyl_source(dual),rtol=0,atol=2e-14)
        for iq,qcov in enumerate(map(np.array,([.7,-1.,2.,3.],[0.,.4,.8,-.2],[1.,0.,0.,0.],[1.,0.,0.,1.]))):
            eff=-4*np.einsum("b,c,abcd->ad",qcov,qcov,source)
            assert max(abs(qcov@eff))<2e-12 and abs(np.sum(eff*ETA))<2e-12
            dyad=np.outer(electric,electric)-np.outer(magnetic,magnetic)
            value=2*qcov[1:]@(dyad-np.eye(3)*np.trace(dyad)/3)@qcov[1:]
            assert abs(eff[0,0]-value)<2e-12 and np.allclose(eff,eff.T)
            if iq==2:assert not eff[0].any()
            for ia,ib in ((0,0),(0,2),(1,1),(1,3),(2,3),(3,3)):
                probe=np.zeros((4,4));probe[ia,ib]=probe[ib,ia]=1
                weyl,ricci,scalar=metric(qcov,probe)
                direct=np.einsum("abcd,ab,cd",weyl,field,field)
                variation=np.sum(probe*eff)/2
                duval=np.einsum("abcd,ab,cd",weyl,dual,dual)
                ricdiff=np.sum(ricci*(field@ETA@field.T-dual@ETA@dual.T))
                assert abs(direct-variation)<2e-12 and abs(direct+duval)<2e-12
                assert abs(ricdiff-scalar*invariant/2)<2e-12
                rows.append(dict(field=index,momentum=iq,metric=f"{ia}{ib}",direct=direct,integrated_source=variation,
                                 dual_vertex=duval,ricci_pair=ricdiff,ricci_scalar_piece=scalar*invariant/2))
    assert max(abs(row["direct"]) for row in rows)>1
    table("maxwell-vertices.csv",rows)

@lru_cache(maxsize=3)
def modes(order):
    nodes,weights=roots_hermitenorm(order);weights=weights/np.sqrt(2*pi)
    momenta=np.stack(np.meshgrid(nodes,nodes,nodes,indexing="ij"),axis=-1).reshape(-1,3)
    measure=np.einsum("i,j,k->ijk",weights,weights,weights).ravel()
    return momenta,measure,np.linalg.norm(momenta,axis=1)

def propagate(order,when,pos,switch):
    momenta,measure,length=modes(order)
    profile=1j*np.cross(momenta,np.array([0.,0.,1.]))
    base=np.zeros_like(profile)
    electric,magnetic=(profile,base) if switch else (base,profile)
    sine=np.sinc(length*when/pi)*when
    cosine=np.cos(length*when)
    values=(cosine[:,None]*electric+1j*sine[:,None]*np.cross(momenta,magnetic),
            cosine[:,None]*magnetic-1j*sine[:,None]*np.cross(momenta,electric))
    phase=measure*np.exp(1j*(momenta@pos))
    def observe(array):
        local=(phase@array).real
        gradient=((1j*phase[:,None]*momenta).T@array).real
        laplace=(-(phase*length**2)@array).real
        assert abs(np.trace(gradient))<1e-11
        return local,np.trace(gradient@gradient)-(2/3)*(np.sum(gradient**2)+local@laplace)
    (el,de),(mag,db)=map(observe,values)
    return el,mag,2*(de-db)

def centre(when):
    from numpy.polynomial import Polynomial
    amp=Polynomial([0.,2.,0.,-2/3])
    coordinate=Polynomial([0,1])
    first=amp.deriv()-coordinate*amp
    second=first.deriv()-coordinate*first
    return 4*np.exp(-when**2)*(5*first(when)**2/6-2*amp(when)*second(when)/3)

def pulse():
    rows=[]
    for when in (0.,.2,.65,1.,1.5,2.,2.6,-.65):
        for pos in (np.array([0.,0.,0.]),np.array([.31,-.27,.18])):
            for order in (20,32):
                el,mag,left=propagate(order,when,pos,False)
                de,dm,right=propagate(order,when,pos,True)
                np.testing.assert_allclose(np.cross(el,mag),np.cross(de,dm),rtol=0,atol=2e-12)
                assert abs(el@el+mag@mag-de@de-dm@dm)<2e-12
                assert np.max(abs(np.outer(el,el)+np.outer(mag,mag)-np.outer(de,de)-np.outer(dm,dm)))<2e-12
                predicted=centre(when) if not np.any(pos) else ""
                if predicted!="":assert abs(left-right-predicted)<1e-7,(when,order,left-right,predicted)
                rows.append(dict(time=when,site="off" if pos.any() else "centre",order=order,canonical_energy=(el@el+mag@mag)/2,
                    poynting=np.linalg.norm(np.cross(el,mag)),dual_canonical_error=el@el+mag@mag-de@de-dm@dm,
                    original_weyl_tide=left,dual_weyl_tide=right,pair=left-right,analytic=predicted))
    for low,high in zip(rows[::2],rows[1::2],strict=True):assert abs(low["pair"]-high["pair"])<1e-7
    assert max(row["poynting"] for row in rows)>1e-3
    table("maxwell-pulse.csv",rows)

def apertures():
    import sympy as sp
    xx,yy,zz=coords=sp.symbols("x y z")
    radial2=xx**2+yy**2+zz**2
    mag=sp.Matrix([-yy,xx,0])*sp.exp(-radial2/2)
    curl=lambda vec:sp.Matrix([vec[(idx+2)%3].diff(coords[(idx+1)%3])-vec[(idx+1)%3].diff(coords[(idx+2)%3]) for idx in range(3)])
    lap=lambda scalar:sum(scalar.diff(coord,2) for coord in coords)
    assert sum(mag[idx].diff(coord) for idx,coord in enumerate(coords)).simplify()==0
    magnetic=mag.dot(mag)
    stf=mag*mag.T-sp.eye(3)*magnetic/3
    focus=-4*sum(stf[first,second].diff(coords[first],coords[second]) for first,second in product(range(3),repeat=2))
    spatial=lap(2*magnetic)
    acceleration=4*(mag.dot(mag.applyfunc(lap))-curl(mag).dot(curl(mag)))
    entries=[sp.lambdify(coords,sp.simplify(expression),"numpy") for expression in (focus,spatial,spatial-acceleration)]
    angles,masses=leggauss(12)
    def integral(fn,radius):
        def integrated(rr):
            values=fn(rr*np.sqrt(1-angles**2),0,rr*angles)
            return rr**2*(masses@values)*(2*pi)*(np.exp(-rr**2/(2*radius**2))/(2*pi*radius**2)**1.5 if radius else 1.)
        return quad(integrated,0,np.inf,epsabs=1e-11,epsrel=1e-12)[0]
    assert abs(integral(entries[0],None))<1e-10
    rows=[]
    for radius in (0.,.1,.4,1.,2.):
        driven,spatial,wave=(float(fn(0.,0.,0.)) if radius==0 else integral(fn,radius) for fn in entries)
        variance=radius**2/(1+2*radius**2)
        fac=(1+2*radius**2)**-1.5
        exact=40*(1+2*radius**2)**-3.5/3
        expected=fac*np.array([8-56*variance+80*variance**2,24-48*variance+80*variance**2])
        np.testing.assert_allclose([spatial,wave],expected,rtol=1e-11,atol=1e-12)
        weight=.5-expected[0]/(3*expected[1])
        if radius==0:assert abs(weight-7/18)<1e-15
        for weyl,scalar in ((0.,1.),(1.,0.),(1.,-.73),(-.4,1.3)):
            tidal=weyl*driven+2*scalar*(3*wave-2*spatial)
            ricci=12*scalar*wave
            measured=tidal-weight*ricci
            assert abs(measured-weyl*exact)<1e-10
            rows.append(dict(radius_over_L=radius,weyl=weyl,scalar=scalar,focusing=tidal,ricci_scalar=ricci,weight=weight,
                             isolated=measured,predicted=weyl*exact))
    table("maxwell-apertures.csv",rows)

if __name__=="__main__":
    vertices();pulse();apertures()
    print("metric vertices, finite Maxwell histories and finite detector checks passed",flush=True)
