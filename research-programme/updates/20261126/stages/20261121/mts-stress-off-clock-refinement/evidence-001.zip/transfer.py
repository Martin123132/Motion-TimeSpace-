"""Independent signed native-stress experiment on the same fully refined clock."""
from clock_test import *
from aperture_origin import PARENT as STRESS

def key(row):
    return int(row["seed"]),float(row["width"]),round(1024*float(row["fraction"]))

def prepare():
    pin=lock()
    oldpins=task.meta(STRESS/"seal.json")["files"]
    assert task.lab.sha(STRESS/"seal.json")==task.meta(PARENT/"seal.json")["parent"]
    inp={}
    for filename in ("newton-conserved-source.csv","stress-withdrawal-forecast.csv"):
        inp[filename]=task.lab.sha(STRESS/filename)
        assert inp[filename]==oldpins[filename]
    forecast={key(row):row for row in task.read(STRESS/"stress-withdrawal-forecast.csv") if row["order"]=="28"}
    density={key(row):row for row in task.read(STRESS/"newton-conserved-source.csv") if row["outer"]=="144.0" and row["clock"]=="expanding"}
    assert len(forecast)==len(density)==16 and set(forecast)==set(density)
    rows=[]
    for (sign,width,tick),row in sorted(forecast.items()):
        newton=float(row["newton"]);ppm=abs(newton)*1e-6
        poisson=float(density[sign,width,tick]["poisson"])
        tt=float(row["retained_tt"]);contact=float(row["moving_contact"])
        rows.append(dict(sign=sign,width=width,tick=tick,newton=newton,poisson=poisson,propagating=tt,
            contact=contact,differential=poisson+tt+contact,off_forecast=newton-poisson,unit=ppm))
    table("mechanical-forecast.csv",rows)
    write("physical-design.json",dict(clock=pin,inputs=inp,design=task.lab.sha(HERE/"TRANSFER-DESIGN.md"),
          method=task.lab.sha(Path(__file__)),forecast=task.lab.sha(HERE/"mechanical-forecast.csv")))
    print("physical forecast frozen",task.lab.sha(HERE/"physical-design.json"),flush=True)

def physical_pin():
    pin=lock()
    decl=task.meta(HERE/"physical-design.json")
    assert decl["clock"]==pin and decl["method"]==task.lab.sha(Path(__file__))
    assert decl["design"]==task.lab.sha(HERE/"TRANSFER-DESIGN.md") and decl["forecast"]==task.lab.sha(HERE/"mechanical-forecast.csv")
    return task.lab.sha(HERE/"physical-design.json")

def status():
    pin=lock()
    scores=task.read(HERE/"late-time-scores.csv")
    assert len(scores)==8
    assert all(abs(float(row["third_minus_half_ppm"]))<1 for row in scores),"Inspect noncommensurate clock first"
    for sign in (-1,1):
        for flag in (0,1):
            for start,div in CASES:
                receipt(path_for(sign,flag,start,div,1024),pin)
    return physical_pin()

def physical_path(sign,flag,tick):
    return HERE/f"physical-s{sign}-b{flag}-t{tick}.npz"

def evolve(sign,flag):
    pin=status()
    with task.system(GRID,sign,flag) as model:
        assert len(model.shell.r)==3*GRID
        step=4096*np.pi/(1024*model.shell.mu);small=step/2
        state,clock=decode(anchor(sign,flag,0))
        _,initial=physical_read(model,state,0.,"native")
        last=0
        for tick in CLOCKS:
            path=physical_path(sign,flag,tick)
            if not path.with_suffix(".json").exists():
                assert not path.exists() and not any(physical_path(sign,flag,later).exists() for later in CLOCKS if later>tick)
                break
            rec=receipt(path,pin);assert rec["previous"]==last and rec["tick"]==tick
            last=tick
        if last==1024:return
        if last:state,clock=decode(physical_path(sign,flag,last))
        for tick in CLOCKS:
            if tick<=last:continue
            advance=model.time_step(small)
            for index in range(2*last,2*tick):
                if index%8==0:guard()
                state=advance(index*small,state)
            other=path_for(sign,flag,0,2,tick)
            receipt(other,lock())
            off,finish=decode(other)
            assert finish==tick*step
            for attr in ("base","delta"):
                np.testing.assert_array_equal(getattr(state,attr)[:,0],getattr(off,attr)[:,0])
            raw,fields=physical_read(model,state,tick*step,"native")
            observed={key:observer.annuli(model,raw,initial[key],fields[key]).tolist() for key in ("temporal","space")}
            checks=task.compute(model,state,tick*step)
            packet=dict(base=state.base,delta=state.delta,clock=tick*step,r=model.shell.r)
            for key in ("ind_H","ind_P","ind_J"):packet[key]=checks[key]
            assert all(np.isfinite(arr).all() for arr in packet.values())
            assert model.mass.min_branch>0 and (flag or (model.min_number>0 and model.min_factor>0))
            stream=io.BytesIO();np.savez_compressed(stream,**packet)
            path=physical_path(sign,flag,tick);task.lab.put(path,stream.getvalue())
            write(path.with_suffix(".json").name,dict(pin=pin,sha=task.lab.sha(path),tick=tick,previous=last,
                  sign=sign,flag=flag,matched_monopoles=True,observed=observed))
            last=tick
            print("physical",sign,flag,tick,flush=True)

def score():
    pin=physical_pin();clock_pin=lock()
    rows=[]
    for row in task.read(HERE/"mechanical-forecast.csv"):
        sign=int(row["sign"]);tick=int(row["tick"]);width=float(row["width"]);idx=WIDTHS.index(width)
        unit=float(row["unit"]);newton=float(row["newton"])
        poisson,tt,contact=(float(row[key]) for key in ("poisson","propagating","contact"))
        newdata=[receipt(physical_path(sign,flag,tick),pin)["observed"] for flag in (0,1)]
        olddata=[receipt(path_for(sign,flag,0,2,tick),clock_pin)["observed"] for flag in (0,1)]
        for key in ("temporal","space"):
            physical=newdata[0][key][idx]-newdata[1][key][idx]
            removed=olddata[0][key][idx]-olddata[1][key][idx]
            delta=physical-removed
            transfer=(delta-poisson)/(tt+contact)
            radius=20*unit/abs(tt+contact)
            rows.append(dict(sign=sign,tick=tick,width=width,reader=key,unit=unit,physical=physical,withdrawn=removed,
                absolute_newton_ppm=(physical-newton)/unit,absolute_newton_plus_tt_ppm=(physical-newton-tt)/unit,
                changed_control_ppm=(removed-newton+poisson)/unit,measured_difference_ppm=delta/unit,
                induced_density_ppm=poisson/unit,after_density_ppm=(delta-poisson)/unit,
                forecast_beyond_density_ppm=(tt+contact)/unit,paired_error_ppm=(delta-poisson-tt-contact)/unit,
                transfer=transfer,band_low=transfer-radius,band_high=transfer+radius))
    table("physical-transfer.csv",rows)
    summary=[]
    for label,sel in (("all",rows),("temporal",[row for row in rows if row["reader"]=="temporal"]),("space",[row for row in rows if row["reader"]=="space"])):
        low=max(row["band_low"] for row in sel);high=min(row["band_high"] for row in sel)
        summary.append(dict(reader=label,rows=len(sel),absolute_newton_inside=sum(abs(row["absolute_newton_ppm"])<=20 for row in sel),
            absolute_newton_plus_tt_inside=sum(abs(row["absolute_newton_plus_tt_ppm"])<=20 for row in sel),
            no_response_inside=sum(abs(row["measured_difference_ppm"])<=20 for row in sel),
            density_only_inside=sum(abs(row["after_density_ppm"])<=20 for row in sel),
            full_inside=sum(abs(row["paired_error_ppm"])<=20 for row in sel),common_low=low,common_high=high,
            unit_allowed=low<=1<=high,zero_allowed=low<=0<=high,minimum_transfer=min(row["transfer"] for row in sel),maximum_transfer=max(row["transfer"] for row in sel)))
    table("transfer-summary.csv",summary)
    print(summary,flush=True)
if __name__=="__main__":
    if sys.argv[1:]==["prepare"]:prepare()
    elif sys.argv[1:]==["score"]:score()
    else:
        for branch in (0,1):evolve(int(sys.argv[1]),branch)
