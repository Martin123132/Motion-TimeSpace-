"""Refine time only on the original stress-off weak-field formations."""
import csv
import io
import json
import os
import sys
from pathlib import Path

HERE=Path(__file__).resolve().parent
PARENT=HERE.parent/"mts-stress-off-aperture-origin-20261121"
PIN="5d2e26333f2fa05e9a8497ce3e95b1930ec3d21f4c204e2ae85ae0055806c87e"
for key in ("OPENBLAS_NUM_THREADS","OMP_NUM_THREADS","MKL_NUM_THREADS","NUMEXPR_NUM_THREADS","BLIS_NUM_THREADS"):
    os.environ[key]="1"
sys.path.insert(0,str(PARENT))
from aperture_origin import physical_read,task,np,observer,WIDTHS
from stress_switch import switched,guard as inherited_guard

GRID=960
CASES=((768,1),(768,2),(768,3),(0,2))
CLOCKS=(256,512,768,1024)

def guard():
    inherited_guard()
    if (HERE/"STOP-REQUESTED").exists() or (PARENT/"STOP-REQUESTED").exists():raise RuntimeError("Owner hold")

def write(name,value):
    guard()
    task.lab.put(HERE/name,(json.dumps(value,indent=2,allow_nan=False)+"\n").encode())

def table(name,rows):
    guard()
    stream=io.StringIO(newline="")
    writer=csv.DictWriter(stream,rows[0].keys(),lineterminator="\n")
    writer.writeheader();writer.writerows(rows)
    task.lab.put(HERE/name,stream.getvalue().encode())

def freeze():
    guard()
    assert task.lab.sha(PARENT/"seal.json")==PIN
    files=task.meta(PARENT/"seal.json")["files"]
    for filename,digest in files.items():assert task.lab.sha(PARENT/filename)==digest,filename
    write("design.json",dict(parent=PIN,program=task.lab.sha(Path(__file__)),design=task.lab.sha(HERE/"DESIGN.md"),
          grids=[GRID],cases=CASES,signs=[-1,1],flags=[0,1],tol_ppm=20))
    print("frozen",task.lab.sha(HERE/"design.json"),flush=True)

def lock():
    guard()
    data=task.meta(HERE/"design.json")
    assert data["parent"]==task.lab.sha(PARENT/"seal.json")==PIN
    assert data["program"]==task.lab.sha(Path(__file__)) and data["design"]==task.lab.sha(HERE/"DESIGN.md")
    return task.lab.sha(HERE/"design.json")

def parentpath(sign,flag,tick):
    return PARENT/(f"negative-g960-b{flag}-t{tick}.npz" if sign<0 else f"fine960-b{flag}-t{tick}.npz")

def anchor(sign,flag,tick):
    guard()
    pins=task.meta(PARENT/"seal.json")["files"]
    path=parentpath(sign,flag,tick)
    cert=path.with_suffix(".json")
    assert task.lab.sha(cert)==pins[cert.name] and task.lab.sha(path)==pins[path.name]==task.meta(cert)["sha"]
    return path

def decode(path):
    with np.load(path) as data:return task.old.Difference(data["base"],data["delta"]),float(data["clock"])

def path_for(sign,flag,start,div,tick):
    return HERE/f"s{sign}-b{flag}-start{start}-div{div}-t{tick}.npz"

def ticks(start):
    return tuple(range(start+64,1025,64)) if start==768 else tuple(range(128,1025,128))

def receipt(path,pin):
    rec=task.meta(path.with_suffix(".json"))
    assert rec["pin"]==pin and task.lab.sha(path)==rec["sha"],path.name
    return rec

def run(sign,flag,start,div):
    pin=lock()
    assert sign in (-1,1) and flag in (0,1) and (start,div) in CASES
    if div!=1:
        for member in (0,1):
            assert receipt(path_for(sign,member,768,1,1024),pin)["native_exact"] is True
    first=anchor(sign,flag,start);formed=anchor(sign,flag,0)
    with task.system(GRID,sign,flag) as model:
        assert len(model.shell.r)==3*GRID
        step=4096*np.pi/(1024*model.shell.mu);small=step/div
        origin,clock0=decode(formed)
        assert clock0==0 and not origin.base.any() and not origin.delta.any()
        _,initial=physical_read(model,origin,0.,"off")
        state,clock=decode(first)
        assert clock==start*step
        last=start
        expected=ticks(start)
        for tick in expected:
            path=path_for(sign,flag,start,div,tick)
            if not path.with_suffix(".json").exists():
                assert not path.exists() and not any(path_for(sign,flag,start,div,later).exists() for later in expected if later>tick)
                break
            rec=receipt(path,pin)
            assert rec["source"]==first.name and rec["tick"]==tick and rec["previous"]==last
            last=tick
        if last==1024:return
        if last!=start:state,clock=decode(path_for(sign,flag,start,div,last))
        for tick in expected:
            if tick<=last:continue
            guard()
            with switched(model,"off"):
                advance=model.time_step(small)
                for index in range(last*div,tick*div):
                    if index%8==0:guard()
                    state=advance(index*small,state)
            if tick==1024 and div==1:
                native,finish=decode(anchor(sign,flag,1024))
                np.testing.assert_array_equal(state.base,native.base)
                np.testing.assert_array_equal(state.delta,native.delta)
                assert finish==tick*step
            raw,fields=physical_read(model,state,tick*step,"off")
            observed={key:observer.annuli(model,raw,initial[key],fields[key]).tolist() for key in ("temporal","space")}
            packet=dict(base=state.base,delta=state.delta,clock=tick*step,r=model.shell.r)
            if tick in CLOCKS:
                checks=task.compute(model,state,tick*step)
                for key in ("ind_H","ind_P","ind_J"):packet[key]=checks[key]
                if div==1:
                    old=task.meta(anchor(sign,flag,tick).with_suffix(".json"))["readings"]
                    for key in observed:np.testing.assert_allclose(observed[key],old[key],rtol=2e-13,atol=1e-34)
            assert all(np.isfinite(arr).all() for arr in packet.values())
            assert model.mass.min_branch>0 and (flag or (model.min_number>0 and model.min_factor>0))
            stream=io.BytesIO();np.savez_compressed(stream,**packet)
            path=path_for(sign,flag,start,div,tick);task.lab.put(path,stream.getvalue())
            write(path.with_suffix(".json").name,dict(pin=pin,sha=task.lab.sha(path),tick=tick,previous=last,source=first.name,
                  sign=sign,flag=flag,start=start,division=div,observed=observed,native_exact=(tick==1024 and div==1)))
            last=tick
            print(sign,flag,start,div,tick,flush=True)

def worker(sign):
    for start,div in CASES:
        for flag in (0,1):run(sign,flag,start,div)

if __name__=="__main__":
    if sys.argv[1:]==["freeze"]:freeze()
    else:worker(int(sys.argv[1]))
