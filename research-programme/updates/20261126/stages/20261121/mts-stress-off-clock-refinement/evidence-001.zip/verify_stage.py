"""Verify both sides of the restored source from their stored physical variables."""
from math import isclose
import re
from importlib.util import module_from_spec, spec_from_file_location
from clock_test import CLOCKS, GRID, HERE, PARENT, WIDTHS, anchor, decode, lock, np, observer, path_for, physical_read, receipt, task, write
spec=spec_from_file_location("native_clock_transfer",HERE/"transfer.py")
native_clock=module_from_spec(spec)
spec.loader.exec_module(native_clock)
STRESS,physical_path,physical_pin,score=native_clock.STRESS,native_clock.physical_path,native_clock.physical_pin,native_clock.score


def read_physical():
    clock_pin=lock(); pin=physical_pin()
    for name, sha in task.meta(HERE/"physical-design.json")["inputs"].items():
        assert task.lab.sha(STRESS/name)==sha
    seen=set()
    for sign in (-1,1):
        for flag in (0,1):
            with task.system(GRID,sign,flag) as model:
                origin,zero=decode(anchor(sign,flag,0));assert zero==0.
                _,initial=physical_read(model,origin,zero,"native")
                dt=4096*np.pi/(1024*model.shell.mu)
                for previous,tick in zip((0,*CLOCKS[:-1]),CLOCKS,strict=True):
                    path=physical_path(sign,flag,tick);rec=receipt(path,pin)
                    assert rec["matched_monopoles"] and (rec["sign"],rec["flag"],rec["previous"],rec["tick"])==(sign,flag,previous,tick)
                    seen.add(path.name)
                    frozen=path_for(sign,flag,0,2,tick);receipt(frozen,clock_pin)
                    other,clock=decode(frozen)
                    native,at=decode(path)
                    assert at==clock==tick*dt
                    for attr in ("base","delta"):
                        left=getattr(native,attr);right=getattr(other,attr)
                        np.testing.assert_array_equal(left[:,0],right[:,0])
                    assert any(not np.array_equal(getattr(native,attr)[:,1],getattr(other,attr)[:,1]) for attr in ("base","delta"))
                    raw,fields=physical_read(model,native,at,"native")
                    checks=task.compute(model,native,at)
                    with np.load(path) as saved:
                        np.testing.assert_array_equal(saved["r"],model.shell.r)
                        assert all(np.isfinite(saved[key]).all() for key in saved.files)
                        for key in ("ind_H","ind_P","ind_J"):np.testing.assert_array_equal(checks[key],saved[key])
                    for name in ("temporal","space"):
                        np.testing.assert_array_equal(observer.annuli(model,raw,initial[name],fields[name]),rec["observed"][name])
    assert len(seen)==16 and {p.name for p in HERE.glob("physical-*.npz")}==seen
    assert {p.name for p in HERE.glob("physical-s*.json")}=={name.replace(".npz",".json") for name in seen}


def budgets():
    import source_normalization
    source_normalization.controls()
    score()
    source_normalization.score()
    pin=physical_pin(); clockpin=lock()
    results=task.read(HERE/"physical-transfer.csv")
    forecast={(int(row["sign"]),int(row["tick"]),float(row["width"])):row for row in task.read(HERE/"mechanical-forecast.csv")}
    assert len(forecast)==16 and len(results)==32
    for row in results:
        sign,tick,width,reader=int(row["sign"]),int(row["tick"]),float(row["width"]),row["reader"]
        form=forecast[sign,tick,width];index=WIDTHS.index(width)
        ppm=float(form["unit"]);newton=float(form["newton"])
        assert ppm==abs(newton)*1e-6
        def value(native):
            def member(flag):
                file=physical_path(sign,flag,tick) if native else path_for(sign,flag,0,2,tick)
                return receipt(file,pin if native else clockpin)["observed"][reader][index]
            return member(0)-member(1)
        measured=value(True);removed=value(False)
        density=float(form["poisson"]);stress=float(form["propagating"])+float(form["contact"])
        expected=measured-removed
        assert isclose((expected-density-stress)/ppm,float(row["paired_error_ppm"]),abs_tol=1e-8)
        assert isclose((measured-newton-float(form["propagating"]))/ppm,float(row["absolute_newton_plus_tt_ppm"]),abs_tol=1e-8)
        assert isclose((expected-density)/stress,float(row["transfer"]),abs_tol=1e-10)
    counts={"clock-phase-controls":12,"late-time-scores":8,"late-time-evolution":32,
        "full-time-scores":32,"inherited-clock-budget":8,"raw-constraints":84,"mechanical-forecast":16,
        "physical-transfer":32,"transfer-summary":3,"two-source-constraints":3,
        "maxwell-vertices":72,"maxwell-pulse":32,"maxwell-apertures":20,"maxwell-energy-scaling":24,
        "maxwell-free-spatial-refinement":48,"maxwell-free-stress-sites":12,"maxwell-free-tensor-response":40,
        "maxwell-oblique-current":12}
    for name,count in counts.items():
        rows=task.read(HERE/(name+".csv"))
        assert len(rows)==count,(name,len(rows),count)
        assert all(None not in row and None not in row.values() for row in rows),name
    return sum(counts.values())


def verify(sealing):
    read_physical();count=budgets()
    if sealing:
        assert (HERE/"RESULTS.md").is_file()
        for path in HERE.glob("*.md"):
            for link in re.findall(r"\]\(([^)\s]+)\)",path.read_text(encoding="utf8")):
                if not link.startswith(("http://","https://")):assert (HERE/link).is_file(),(path,link)
        assert not (HERE/"__pycache__").exists() and not (HERE/"STOP-REQUESTED").exists()
        files={path.name:task.lab.sha(path) for path in sorted(HERE.iterdir()) if path.is_file() and path.name!="seal.json"}
        write("seal.json",dict(parent=task.lab.sha(PARENT/"seal.json"),design=lock(),physical=physical_pin(),
            off_packets=80,native_packets=16,table_rows=count,files=files))
        print("verified seal",task.lab.sha(HERE/"seal.json"),len(files),"files",count,"rows")
    else:print("verified 16 physical states and controls,",count,"CSV rows")

if __name__=="__main__":
    import sys
    verify(sys.argv[1:]==["seal"])
