"""Calibrate the prepared finite field by its total energy, not its central amplitude."""
from math import exp, pi, sqrt
from clock_test import table
from scipy.integrate import quad


def integrate(function):
    return quad(function, 0.0, float("inf"), epsabs=2e-12, epsrel=2e-13)[0]


def compare():
    rows = []
    for energy in (0.25, 1.0):
        for length in (0.625, 1.0, 2.0):
            def magnetic(radius):
                return (2/3)*(radius/length)**2*exp(-(radius/length)**2)

            unit_energy = integrate(lambda radius: 2*pi*radius**2*magnetic(radius))
            amplitude2 = energy/unit_energy
            assert abs(unit_energy/(pi**1.5*length**3/2)-1) < 2e-13
            for relative_width in (0.2, 0.5, 1.0, 2.0):
                width = length*relative_width
                def force(radius):
                    ruler = exp(-0.5*(radius/width)**2)/(2*pi*width**2)**1.5
                    return 16*pi*amplitude2*radius**4*magnetic(radius)*ruler/(3*width**4)
                direct = integrate(force)
                shape = 80/(3*pi**1.5)*(1+2*relative_width**2)**-3.5
                expected = energy/length**5*shape
                assert abs(direct/expected-1) < 2e-11
                rows.append(dict(energy=energy,length=length,relative_width=relative_width,amplitude_squared=amplitude2,
                                 curvature_per_kappa_c=direct,calorimetric_prediction=expected,
                                 scaled_measured=direct*length**5/energy,shape=shape))
    table("maxwell-energy-scaling.csv",rows)
    return rows


if __name__ == "__main__":
    values = compare()
    print(len(values), "finite-source energy and length tests; worst fractional error",
          max(abs(row["scaled_measured"]/row["shape"]-1) for row in values))
