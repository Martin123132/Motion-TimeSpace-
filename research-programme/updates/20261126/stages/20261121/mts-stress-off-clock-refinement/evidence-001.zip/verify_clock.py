"""Reopen the numerical fields, reconstruct both detectors, and check the signed budgets."""
from math import isclose
from time_scores import CASES, CLOCKS, GRID, HERE, PARENT, PIN, WIDTHS, anchor, decode, lock, np, observer, official, path_for, physical_read, receipt, task, ticks, write


def verify_formation():
    pin = lock()
    parent = task.meta(PARENT/"seal.json")
    assert task.lab.sha(PARENT/"seal.json") == PIN
    for name, expected in parent["files"].items():
        assert task.lab.sha(PARENT/name) == expected, name
    all_paths = set()
    data = {}
    for sign in (-1, 1):
        for flag in (0, 1):
            with task.system(GRID, sign, flag) as model:
                formed, initial_clock = decode(anchor(sign, flag, 0))
                assert initial_clock == 0 and not formed.base.any() and not formed.delta.any()
                _, first = physical_read(model, formed, 0., "off")
                step = 4096*np.pi/(1024*model.shell.mu)
                for start, div in CASES:
                    previous = start
                    for tick in ticks(start):
                        path = path_for(sign, flag, start, div, tick)
                        all_paths.add(path.name)
                        info = receipt(path, pin)
                        assert (info["sign"],info["flag"],info["start"],info["division"],info["previous"],info["tick"]) == (sign,flag,start,div,previous,tick)
                        assert info["source"] == anchor(sign, flag, start).name
                        assert info["native_exact"] is (div == 1 and tick == 1024)
                        previous = tick
                        state, clock = decode(path)
                        assert state.base.shape == state.delta.shape == formed.base.shape
                        assert state.base.shape[-1] == 3*GRID and clock == tick*step
                        if info["native_exact"]:
                            original, saved_clock = decode(anchor(sign,flag,tick))
                            assert saved_clock == clock
                            for attr in ("base","delta"):
                                np.testing.assert_array_equal(getattr(original, attr), getattr(state, attr))
                        with np.load(path) as bank:
                            assert set(bank.files) == ({"base","delta","clock","r"} | ({"ind_H","ind_P","ind_J"} if tick in CLOCKS else set()))
                            np.testing.assert_array_equal(bank["r"],model.shell.r)
                            assert all(np.isfinite(bank[key]).all() for key in bank.files)
                            if tick in CLOCKS:
                                constraints = task.compute(model, state, clock)
                                for key in ("ind_H","ind_P","ind_J"):
                                    np.testing.assert_array_equal(constraints[key], bank[key])
                        raw, fields = physical_read(model,state,clock,"off")
                        for reader in ("temporal","space"):
                            observations = observer.annuli(model,raw,first[reader],fields[reader])
                            np.testing.assert_array_equal(observations,info["observed"][reader])
                            for width, value in zip(WIDTHS, observations, strict=True):
                                data[sign,flag,start,div,tick,width,reader] = float(value)
    assert len(all_paths)==80 and all_paths == {path.name for path in HERE.glob("s*-start*.npz")}
    assert {path.replace(".npz",".json") for path in all_paths} == {path.name for path in HERE.glob("s*-start*.json")}
    return data


def verify_budget(data):
    def contrast(sign,start,div,tick,width,reader):
        return data[sign,0,start,div,tick,width,reader] - data[sign,1,start,div,tick,width,reader]
    def close(first,second):
        assert isclose(first,second,abs_tol=1e-5,rel_tol=1e-12), (first,second)
    expected = set((sign,tick,width,reader) for sign in (-1,1) for tick in CLOCKS for width in WIDTHS for reader in ("temporal","space"))
    rows = task.read(HERE/"full-time-scores.csv")
    seen = set()
    for row in rows:
        sign,tick,width,reader = int(row["sign"]),int(row["tick"]),float(row["width"]),row["reader"]
        seen.add((sign,tick,width,reader))
        nominal,prediction,native = official(sign)[tick,width,reader]
        ppm = abs(nominal)*1e-6
        measured = (contrast(sign,0,2,tick,width,reader)-prediction)/ppm
        close(measured,float(row["full_half_ppm"]))
        close(native,float(row["native_ppm"]))
        assert (abs(measured)<=20) == (row["inside"]=="True")
        close(measured-native,float(row["full_half_minus_native_ppm"]))
    assert seen==expected and len(seen)==len(rows)
    late = task.read(HERE/"late-time-scores.csv")
    budget = task.read(HERE/"inherited-clock-budget.csv")
    key = lambda row:(int(row["sign"]),float(row["width"]),row["reader"])
    expected_late = {(sign,width,reader) for sign,tick,width,reader in expected}
    assert set(map(key,late))==set(map(key,budget))==expected_late and len(late)==len(budget)==8
    for row in budget:
        sign,width,reader = key(row)
        nominal,prediction,native = official(sign)[1024,width,reader]
        ppm = abs(nominal)*1e-6
        ratios = [(contrast(sign,768,div,1024,width,reader)-prediction)/ppm for div in (1,2,3)]
        final = (contrast(sign,0,2,1024,width,reader)-prediction)/ppm
        local = next(other for other in late if key(other)==key(row))
        close(ratios[0],native)
        close(final-ratios[1],float(row["inherited_state_ppm"]))
        close(ratios[1]-native,float(row["last_quarter_ppm"]))
        close(ratios[2]-ratios[1],float(local["third_minus_half_ppm"]))
    assert len(task.read(HERE/"raw-constraints.csv"))==84
    assert len(task.read(HERE/"late-time-evolution.csv"))==32


def main():
    values = verify_formation()
    verify_budget(values)
    print("80 packets and all independently reconstructed angular force readings, raw constraints and signed budgets verified")

if __name__ == "__main__":
    main()
