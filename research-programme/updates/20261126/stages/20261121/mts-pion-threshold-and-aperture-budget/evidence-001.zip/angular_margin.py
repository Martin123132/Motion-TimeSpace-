"""How much *unmeasured* higher-wave amplitude would invalidate the aperture argument?"""
from calculate import np, PAIR, references, angular, totals, source_bins, bound, write
from scipy.special import eval_legendre, roots_legendre


def calculate(order=12):
    results=[]
    for near in (3.,2.,4.):
        rows=[row for item in source_bins() if (row:=bound(item,.54,1.60,near,order)) is not None]
        base=sum(references(order,near,angular.model(),-.01)[:2])
        center=sum(row["center"] for row in rows)
        radius=0.
        for row in rows:
            width=row["native_hi"]-row["native_lo"]
            full=width*(row["obs_nb"]*(1+row["sys_fraction"])+row["stat_nb"]+row["sys_nb"])
            radius+=row["box_radius"]*np.sqrt(full/(full-row["irreducible_nb_GeV"]))
        results.append(dict(b_fm=near,elastic_including_strip=base,projection_center=center,full_rate_radius=radius,
            lower_at_zero_leak=base+center-radius,upper_at_zero_leak=base+center+radius,
            min_uniform_projected_amplitude_fraction_to_reach_zero=max(0.,base+center-radius)/radius))
    return results


def blind_modes():
    nodes, weights=roots_legendre(90)
    angle=(nodes+1)/2
    out=[]
    for degree in (4,8,16,24):
        power=2*degree
        projection=power/((power+1)*(power+3))
        example=angle**power/projection
        coeff=(weights/2)@(eval_legendre(2,angle)*example)
        assert abs(coeff-1)<2e-12
        for aperture in (.6,.8):
            pol=eval_legendre(2,angle*aperture)
            ap_example=(aperture*angle)**power/projection
            offset=(weights/2)@((pol-(aperture**2-1)/2)*ap_example)/(aperture**4)
            out.append(dict(power=power,aperture=aperture,full_D=coeff,apparent_D_in_aperture=offset,
                            sup_amplitude_in_aperture=aperture**power/projection))
    return out


if __name__=="__main__":
    rows=calculate()
    write("higher-wave-margin.csv",rows)
    write("blind-modes.csv",blind_modes())
    print(rows[0])
