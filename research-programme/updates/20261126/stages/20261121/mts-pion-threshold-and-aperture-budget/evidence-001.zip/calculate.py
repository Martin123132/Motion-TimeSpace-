"""Frozen two-ray contrast: solve threshold slope and bound finite-aperture signed interference."""
import csv
import hashlib
import json
import sys
from pathlib import Path

import numpy as np
from scipy.integrate import quad
from scipy.special import roots_legendre

HERE = Path(__file__).resolve().parent
OLD = HERE.parent/"mts-photon-impact-transfer-20261121"
MARK = HERE.parent/"mts-four-pion-stress-bridge-20261121"/"mark2-total.json"
CB = HERE/"crystal-ball-total.json"
def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
assert digest(OLD/"seal.json")=="e7116c123c9eb685faa8ee70d5c20aceaa6a6061e7b88779799fbc0a77eeaa30"
for name, value in json.loads((OLD/"seal.json").read_bytes()).items():
    assert digest(OLD/name)==value
assert digest(CB)=="0b926af9879652d5a6c2c8676ec4ee16d2477e43b3b7200a0325877c713ec924"
sys.path.insert(0,str(OLD))
from impact import HC, TH, angular, elastic, energy_rule, p2, weight
from waves import born_s, kinematics

PAIR = np.sqrt(TH)
FOUR = 2*PAIR


def write(name, rows):
    with (HERE/name).open("w",encoding="utf8",newline="") as stream:
        dest = csv.DictWriter(stream,fieldnames=rows[0],lineterminator="\n")
        dest.writeheader()
        dest.writerows(rows)


def slope(model, poly):
    om = elastic.omega(TH)
    assert om.imag==0 and elastic.omega(TH*1.00001).imag==0
    left = TH*sum(weights@(1/(nodes-TH)) for nodes,weights in model.left)
    right = TH/np.pi*(model.weights@(model.kernel/(model.nodes-TH))+
                       model.tw@(model.tailkernel/(model.tail-TH)))
    pieces = np.r_[2/15, om.real*TH**3*np.array([elastic.GM*model.subtraction,left,right])]
    product = sum(pieces)*om.real*(1+poly*TH)
    return pieces, product


def references(order, near, model, poly):
    out = []
    for low,high in [(PAIR,.281),(.281,.54),(.54,FOUR),(FOUR,.60)]:
        energies, dw = energy_rule(low,high,order)
        measure = dw*2*elastic.KAPPA*(1-TH/energies**2)**1.5/energies**3*weight(energies,near)
        product = np.array([model.read(energy**2,poly)[0] for energy in energies])
        out.append(measure@product)
    return np.array(out)


def source_bins():
    out = []
    for charge, file in ((True,MARK),(False,CB)):
        data=json.loads(file.read_bytes())
        doi = "10.17182/hepdata."+("22881" if charge else "22923")+".v1/t1"
        assert data["doi"]==doi and data["headers"][1]["name"]=="SIG [NB]"
        for row in data["values"]:
            center=float(row["x"][0]["value"])
            half=(.015 if center<.75 else (.005 if center<1.5 else .01)) if charge else .025
            low,high=round(center-half,4),round(center+half,4)
            if (low<.54 and charge) or high<=.54 or low>=1.60:
                continue
            elem=row["y"][0]
            obs=float(elem["value"])
            stat=float(elem["errors"][0]["symerror"])
            if charge:
                sys_err=float(elem["errors"][1]["symerror"])
                assert elem["errors"][2]["symerror"]=="7.0%"
                scale=.07
            else:
                assert len(elem["errors"])==1
                sys_err=0.
                scale=.11 if center<.8 else .07
            out.append(dict(charge=charge,low=low,high=high,obs=obs,stat=stat,sys=sys_err,scale=scale))
    return out


def projection(energies, charged, order):
    aperture=.6 if charged else .8
    nodes, quadrature=roots_legendre(2*order)
    angles=aperture*(nodes+1)/2
    aw=quadrature*aperture/2
    pol=p2(angles)
    center=pol@aw/aperture
    var=aperture**5/5
    assert abs((pol-center)**2@aw-var)<2e-14
    speed,rate=kinematics(energies,charged)
    born=elastic.born(energies**2)
    rem=(1-speed[:,None]**2)/(1-(speed[:,None]*angles)**2)-born_s(speed)[:,None]-5*born[:,None]*pol
    if not charged:
        rem[:]=0
    offset=rem@((pol-center)*aw)/(5*var)
    orthogonal=rem-(rem@aw/aperture)[:,None]-5*offset[:,None]*(pol-center)
    assert np.max(abs(orthogonal@aw))<2e-15 and np.max(abs(orthogonal@((pol-center)*aw)))<2e-15
    return var, offset, orthogonal**2@aw, rate


def bound(row,lo,hi,near,order):
    left,right=max(row["low"],lo),min(row["high"],hi)
    if not left<right:
        return None
    charge=row["charge"]
    full,fw=energy_rule(row["low"],row["high"],order)
    _,_,irreducible,rate=projection(full,charge,order)
    spent=fw@(rate*irreducible)
    width=row["high"]-row["low"]
    energy,dw=energy_rule(left,right,order)
    var, shift, _, rate=projection(energy,charge,order)
    stress=(1-.01*energy**2)*elastic.omega(energy**2)
    kernel=2*elastic.KAPPA*(1-TH/energy**2)**1.5/energy**3*weight(energy,near)
    scale=1. if charge else .5
    center=-scale*dw@(kernel*stress.real*shift)
    norm=scale**2*dw@(kernel**2*abs(stress)**2/(25*var*rate))
    central=width*row["obs"]-spent
    box=width*(row["obs"]*(1+row["scale"])+row["stat"]+row["sys"])-spent
    assert 0 < central < box
    return dict(b_fm=near,channel="charged" if charge else "neutral",native_lo=row["low"],native_hi=row["high"],
                overlap_lo=left,overlap_hi=right,obs_nb=row["obs"],stat_nb=row["stat"],sys_nb=row["sys"],
                sys_fraction=row["scale"],irreducible_nb_GeV=spent,center=center,
                central_radius=np.sqrt(norm*central),box_radius=np.sqrt(norm*box))


def totals(rows, key):
    center=sum(row["center"] for row in rows)
    radius=sum(row[key] for row in rows)
    return np.array([center-radius,center+radius])


def run(order=12):
    inputs=source_bins()
    with (OLD/"transfer-windows.csv").open() as stream:
        prior={float(row["b_fm"]):row for row in csv.DictReader(stream) if row["b_fm"] and float(row["disk_radius_fm"])==0}
    allrows, summary=[],[]
    for near in (3.,2.,4.):
        parts=references(order,near,angular.model(),-.01)
        before=prior[near]
        assert abs(parts[1]-float(before["elastic_ref"]))<2e-14
        bounds={}; all_rows={}
        for name,low,high in [("gap",.54,.60),("mid",.60,.75),("high",.75,1.60)]:
            rows=[res for item in inputs if (res:=bound(item,low,high,near,order)) is not None]
            for chan in ("charged","neutral"):
                selected=sorted([row for row in rows if row["channel"]==chan],key=lambda row:row["overlap_lo"])
                assert selected[0]["overlap_lo"]==low and selected[-1]["overlap_hi"]==high
                assert all(first["overlap_hi"]==second["overlap_lo"] for first,second in zip(selected,selected[1:]))
            bounds[name]=totals(rows,"box_radius")
            all_rows[name]=rows
            allrows.extend(rows)
        oldmid = np.array([float(before["upper_box_lo"]),float(before["upper_box_hi"])])
        mid=np.array([max(oldmid[0],bounds["mid"][0]),min(oldmid[1],bounds["mid"][1])])
        ref=parts.sum()+mid+bounds["high"]
        varying=sum(parts[:2])+mid+bounds["high"]+bounds["gap"]
        ratio = weight(np.array([1.6]),near)[0]
        supremum_integral=quad(lambda energy: np.sqrt(3)/(2*np.pi)*(1-TH/energy**2)**1.25*
            weight(np.array([energy]),near)[0]/energy**3,1.6,np.inf,epsabs=1e-23,epsrel=1e-10)[0]
        summary.append(dict(b_fm=near,B_fm=2*near,threshold=parts[0],elastic=parts[1],gap_below_4pi=parts[2],
            gap_above_4pi=parts[3],gap_rate_lo=bounds["gap"][0],gap_rate_hi=bounds["gap"][1],
            mid_lo=mid[0],mid_hi=mid[1],high_lo=bounds["high"][0],high_hi=bounds["high"][1],
            sum_with_signed_gap_lo=ref[0],sum_with_signed_gap_hi=ref[1],sum_with_rate_gap_lo=varying[0],
            sum_with_rate_gap_hi=varying[1],tail_max_weight=ratio,tail_negative_norm_needed_ref=max(0.,ref[0])/ratio,
            tail_negative_norm_needed_rates=max(0.,varying[0])/ratio,unitarity_tail_per_mean_abs_A=supremum_integral,
            mean_abs_A_needed_ref=max(0.,ref[0])/supremum_integral,mean_abs_A_needed_rates=max(0.,varying[0])/supremum_integral))
    return allrows,summary


def slope_tests(order):
    summaries=[]
    for label,settings,poly in [("retained",{},-.01),("sum_rule_5",dict(subtraction=.19),-.01),
                ("sum_rule_3",dict(left_limit=3.,subtraction=.10),-.01),("left_3",dict(left_limit=3.),-.01),
                ("tail_2",dict(tail_power=2),-.01),("tail_5",dict(tail_power=5),-.01),
                ("tensor_light",{},-.01+1/1.255**2-1/1.275**2),("tensor_heavy",{},-.01+1/1.295**2-1/1.275**2)]:
        model=elastic.Reconstruction(order=order,**settings)
        where, signed=slope(model,poly)
        err=[]
        for eps in (1e-4,1e-5,1e-6):
            squared=TH/(1-eps)
            err.append(abs(model.read(squared,poly)[0]/eps/signed-1))
        assert err[2]<2e-6 and err[0]>err[1]>err[2]
        parts=references(order,3.,model,poly)
        summaries.append(dict(model=label,H_per_beta2=float(sum(where)),born=where[0],subtraction=where[1],
            left_cut=where[2],right_cut=where[3],stress_interference_per_beta2=signed,
            relative_direct_error_at_beta2_1e_minus6=err[2],strip=parts[0],elastic=parts[1],gap=parts[2]+parts[3]))
    return summaries


if __name__=="__main__":
    rows, results=run()
    write("aperture-budgets.csv",rows)
    write("contrast.csv",results)
    write("threshold-slope.csv",slope_tests(12))
    print(json.dumps(results[0],indent=2))
