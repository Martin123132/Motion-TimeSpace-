"""Inclusive stress susceptibility needed to overturn the exclusive lower margin."""
import numpy as np
from scipy.integrate import quad
from scipy.special import kve, roots_legendre
from calculate import FOUR, PAIR, TH, HC, elastic, energy_rule, p2, weight


def kernel_scalar(energy):
    return float(weight(np.asarray(energy),3.))


def moment(start, spacelike, order):
    threshold=start**2
    nodes, weights=roots_legendre(order)
    unit=(nodes+1)/2
    squared=threshold/unit
    val=weight(np.sqrt(squared),3.)**2*(squared+spacelike)**4/squared**6
    return (30/np.pi)*((weights/2)@(val*threshold/unit**2))


def budgets(margin):
    rows=[]
    for start,channel in ((FOUR,"four-pion only"),(.75,"states restricted above 0.75"),(1.6,"states restricted above 1.60")):
        for spacelike in (0.,1.,4.):
            value=moment(start,spacelike,96)
            other=(30/np.pi)*quad(lambda energy:2*kernel_scalar(energy)**2*(energy**2+spacelike)**4/energy**11,
                                 start,np.inf,epsabs=1e-28,epsrel=1.e-10)[0]
            assert abs(value/other-1)<1e-9
            rows.append(dict(channel=channel,W_min_GeV=start,Q2_GeV2=spacelike,cs_factor_GeVminus2=value,
                             minimum_chi_GeVminus2=margin**2/value))
    return rows


def calibration():
    nodes, aw=roots_legendre(48)
    alpha=4*np.pi*elastic.KAPPA
    worst=0.
    for energy in (.35,.55,.89,1.6):
        squared=energy**2
        beta=np.sqrt(1-TH/squared)
        stress_value=.86+.32j
        stress=2*(squared-TH)/4*np.sqrt(2/3)*p2(nodes)*stress_value
        for photon in ((.22+.5j,-.1+.7j),(1.,0.),(0.,1.)):
            overlap=sum(beta/(8*np.pi*sym)*((aw/2)@(2*4*np.pi*alpha*5*amp*p2(nodes)*stress.conjugate()))
                        for sym,amp in zip((1,2),photon))
            density=sum(beta/(8*np.pi*sym)*((aw/2)@abs(stress)**2) for sym in (1,2))
            analytic=3/2*beta**5*squared**2/(240*np.pi)*abs(stress_value)**2
            assert abs(density/analytic-1)<1e-13
            old=elastic.KAPPA*beta**3/squared**2*((photon[0]+photon[1]/2)*stress_value.conjugate()).real
            new=np.sqrt(6)/(4*np.pi*squared**3)*overlap.real
            worst=max(worst,abs(new/old-1))
        wave=np.sqrt(4/(3*alpha**2*beta))
        norm=sum(beta/(8*np.pi*sym)*((aw/2)@(2*4*np.pi*alpha*5*wave*p2(nodes))**2) for sym in (1,2))
        assert abs(norm/(80*np.pi)-1)<1e-13
    assert worst<1e-13
    return worst


def euclidean_time(margin):
    energy, widths=energy_rule(PAIR,.54,16)
    density=(1-TH/energy**2)**2.5*energy**4*abs((1-.01*energy**2)*elastic.omega(energy**2))**2/(160*np.pi)
    out=[]
    for start in (FOUR,1.6):
        for tau_fm in (.25,.50,1.):
            tau=tau_fm/HC
            def kernel_sq(point):
                arg=3.*point/HC
                fact=.5*arg**2*(kve(2,arg)-4*np.exp(-arg)*kve(2,2*arg))
                return 240*fact**2*np.exp(point*(tau-6./HC))/point**10
            factor=quad(kernel_sq,start,np.inf,epsabs=1e-27,epsrel=1e-11)[0]
            nodes,aw=roots_legendre(96);unit=(nodes+1)/2
            direct=(aw/2)@(kernel_sq(start/unit)*start/unit**2)
            assert abs(direct/factor-1)<1e-10
            floor=widths@(density*np.exp(-energy*tau))/(2*np.pi)
            ceiling=margin**2/factor
            out.append(dict(W_min_GeV=start,tau_fm=tau_fm,coefficient_GeVminus9=factor,
                            minimum_C_for_reversal_GeV5=ceiling,known_2pi_C_reference_GeV5=floor,
                            reference_to_required_C=floor/ceiling))
    return out

