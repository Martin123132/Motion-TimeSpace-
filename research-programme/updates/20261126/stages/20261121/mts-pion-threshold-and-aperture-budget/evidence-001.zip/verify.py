"""Independent rate extremizers, numerical controls, and complete offline replay."""
import json
import re
import sys
import numpy as np
from scipy.special import roots_legendre
from calculate import (HERE, TH, bound, born_s, digest, elastic, energy_rule, kinematics, p2, run, slope_tests,
                       source_bins, weight, write)
from angular_margin import calculate, blind_modes
from stress_budget import budgets, calibration, euclidean_time


def extremizers():
    results=[]
    order=16
    for item in source_bins():
        if item["low"] not in (.50,.54,.55,.57):
            continue
        limits=bound(item,.54,.60,3.,order)
        if limits is None:
            continue
        edges=sorted(set([item["low"],item["high"],limits["overlap_lo"],limits["overlap_hi"]]))
        rules=[energy_rule(low,high,order) for low,high in zip(edges,edges[1:]) if high>low]
        energy,dw=[np.concatenate(axis) for axis in zip(*rules)]
        active=(energy>.54)&(energy<.60)
        charge=item["charge"]; aperture=.6 if charge else .8
        nodes, aw=roots_legendre(48); angle=(nodes+1)*aperture/2; aw=aw*aperture/2
        pol=p2(angle)
        basis=pol-(pol@aw)/aperture
        var=(basis**2)@aw
        speed, rate=kinematics(energy,charge)
        rem=((1-speed[:,None]**2)/(1-(speed[:,None]*angle)**2)-born_s(speed)[:,None]-
             5*elastic.born(energy**2)[:,None]*pol)*int(charge)
        shift=(rem@(basis*aw))/(5*var)
        orth=rem-(rem@aw/aperture)[:,None]-5*shift[:,None]*basis
        floor=dw@(rate*((orth**2)@aw))
        cap=(edges[-1]-edges[0])*(item["obs"]*(1+item["scale"])+item["stat"]+item["sys"])
        stress=(1-.01*energy**2)*elastic.omega(energy**2)
        target=active*2*elastic.KAPPA*speed**3/energy**3*weight(energy,3.)
        profile=target*stress/rate
        normal=np.sqrt((cap-floor)/(25*var*(dw@(rate*abs(profile)**2))))
        for sign in (-1,1):
            wave=-shift+sign*normal*profile
            amplitude=5*wave[:,None]*pol+rem
            amplitude-=(amplitude@aw/aperture)[:,None]
            measured=dw@(rate*(abs(amplitude)**2@aw))
            current=(1. if charge else .5)*dw@(target*(wave*stress.conjugate()).real)
            expected=limits["center"]+sign*limits["box_radius"]
            assert abs(measured/cap-1)<1e-12 and abs(current/expected-1)<2e-8
            results.append(dict(channel=limits["channel"],native_lo=edges[0],native_hi=edges[-1],
                sign=sign,absolute_rate_relative=abs(measured/cap-1),endpoint_relative=abs(current/expected-1)))
    assert len(results)==8
    return results


def main():
    assert sys.flags.optimize==0
    rows,product=run()
    finer,check=run(18)
    err=max(abs(r[key]/s[key]-1) for r,s in zip(product,check) for key in
            ("threshold","elastic","gap_below_4pi","gap_above_4pi","mid_lo","gap_rate_lo","high_lo","sum_with_rate_gap_lo"))
    assert err<2e-7 and len(finer)==len(rows)
    assert product[0]["b_fm"]==3 and product[0]["sum_with_rate_gap_lo"]>0 and product[1]["sum_with_rate_gap_lo"]<0
    margins=calculate()
    assert .05<margins[0]["min_uniform_projected_amplitude_fraction_to_reach_zero"]<.08
    assert margins[0]["lower_at_zero_leak"]<product[0]["sum_with_rate_gap_lo"]
    variations=slope_tests(12)
    worst=calibration()
    moment=budgets(product[0]["sum_with_rate_gap_lo"])
    controls=extremizers()
    write("aperture-budgets.csv",rows)
    write("contrast.csv",product)
    write("threshold-slope.csv",variations)
    write("higher-wave-margin.csv",margins)
    write("blind-modes.csv",blind_modes())
    write("inclusive-stress-budget.csv",moment)
    write("vacuum-shear-budget.csv",euclidean_time(product[0]["sum_with_rate_gap_lo"]))
    write("extremizer-tests.csv",controls)
    (HERE/"checks.json").write_bytes((json.dumps(dict(max_quadrature_change=err,
        mixed_cut_normalization_error=worst,aperture_rows=len(rows),threshold_variants=len(variations),
        max_extremizer_error=max(r["endpoint_relative"] for r in controls)),indent=2)+"\n").encode())
    for doc in HERE.glob("*.md"):
        for link in re.findall(r"\]\(([^\s)]+)\)",doc.read_text(encoding="utf8")):
            assert link.startswith("https://") or (HERE/link).is_file(),(doc,link)
    manifest={file.name:digest(file) for file in sorted(HERE.iterdir()) if file.is_file() and file.name!="seal.json"}
    seal=HERE/"seal.json"
    if sys.argv[1:]==["--seal"]:
        with seal.open("x",encoding="utf8",newline="\n") as out:
            out.write(json.dumps(manifest,indent=2)+"\n")
    elif sys.argv[1:]==["--preview"]:
        assert not seal.exists()
    else:
        assert not sys.argv[1:] and manifest==json.loads(seal.read_bytes())
    print(len(manifest),"files",digest(seal) if seal.exists() else "preview",err,worst)


if __name__=="__main__":
    main()
