"""Optional acquisition of the one new primary table; replay uses the pinned local copy."""
import hashlib
import json
from pathlib import Path
import requests

HERE = Path(__file__).resolve().parent
if __name__ == "__main__":
    url = "https://www.hepdata.net/record/data/22923/20638/1"
    response = requests.get(url, timeout=20)
    response.raise_for_status()
    data = response.content
    assert len(data)<250_000
    table = json.loads(data)
    assert table["doi"]=="10.17182/hepdata.22923.v1/t1"
    with (HERE/"crystal-ball-total.json").open("xb") as out:
        out.write(data)
    print(len(data), hashlib.sha256(data).hexdigest())
