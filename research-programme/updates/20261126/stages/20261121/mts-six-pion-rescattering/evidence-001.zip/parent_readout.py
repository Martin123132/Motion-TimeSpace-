import csv
import hashlib
from calculate import write
from scattering import HERE,PARENT


def csv_rows(path):
    with path.open() as stream:
        return list(csv.DictReader(stream))


def run():
    source=HERE.parent/"mts-binary-polarization-rays-20261121"/"conjunction-transfer.csv"
    assert hashlib.sha256(source.read_bytes()).hexdigest()=="557b86dcb256335fab20a88cdb48dfdbeec7368e91bcc63234fa6eec843a383d"
    geometry=[row for row in csv_rows(source) if row["geometry"]=="G4945_00_DD_central" and row["receiver"]=="infinity"]
    assert len(geometry)==1
    transfer=float(geometry[0]["corrected_s_per_m2"])
    direct=float(csv_rows(PARENT/"window.csv")[-1]["direct_GeVminus2"])
    feedback={row["term"]:float(row["PV_direct_spline_GeVminus2"]) for row in csv_rows(HERE/"same-window.csv") if row["grid"]=="8-6-10-9"}
    assert set(feedback)=={"H3","H4","A1","A2"}
    rows=[]
    for label,val in (("direct_4pi_tree",direct),("feedback_H3_A1",feedback["H3"]+feedback["A1"]),
                      ("feedback_H4_A2",feedback["H4"]+feedback["A2"])):
        optical=-val*(.1973269804e-15)**2
        rows.append(dict(contribution=label,window_GeV="4m_pi to 0.8",moment_GeVminus2=val,c_W_optical_m2=optical,
                         transfer_s_per_m2=transfer,partial_delay_s=transfer*optical))
    write("conditional-parent-readout.csv",rows)
    print(rows)


if __name__=="__main__":
    run()

