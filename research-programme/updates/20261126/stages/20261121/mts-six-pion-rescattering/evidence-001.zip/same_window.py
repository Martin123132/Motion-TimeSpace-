import csv
import json
from pathlib import Path
import numpy as np
from scipy.integrate import quad
from scipy.interpolate import CubicSpline
from calculate import write
from controls import number_shapes
from scattering import HERE,MASS,PARENT,THRESH,elastic,roots_legendre


def prefactor(squared,term):
    momentum=4*MASS**2
    if term=="H3":
        return squared**2*(squared-momentum)
    if term=="H4":
        return squared**3*(squared-momentum)
    if term=="A1":
        return squared
    if term=="A2":
        return squared**2
    raise ValueError(term)


def readout(squared,term):
    weight=elastic.KAPPA*(1-4*MASS**2/squared)**1.5/squared**2
    if term[0]=="H":
        return weight
    shape=np.shape(squared)
    born=np.array([elastic.born(val) for val in np.ravel(squared)]).reshape(shape)
    return weight*born


def calculate():
    with (HERE/"dispersion-nodes.csv").open() as stream:
        nodes=list(csv.DictReader(stream))
    with (HERE/"absorptive-cuts.csv").open() as stream:
        fixed=list(csv.DictReader(stream))
    with (PARENT/"window.csv").open() as stream:
        direct=float(list(csv.DictReader(stream))[-1]["direct_GeVminus2"])
    low,high=THRESH**2,.8**2
    width=high-low
    rows=[]
    reference=number_shapes()["coefficients"]
    for order,grid in ((6,"6-4-8-7"),(10,"6-4-8-7"),(10,"8-6-10-9")):
        selected=[row for row in nodes if int(row["energy_order"])==order and row["rule"]==grid]
        assert len(selected)==order
        energy=np.array([float(row["W_GeV"]) for row in selected])
        edges,weights=roots_legendre(order)
        assert np.max(abs(energy-(THRESH+(.8-THRESH)*(1+edges)/2)))<2e-16
        quadw=energy*(.8-THRESH)*weights
        sample=energy**2
        subnodes,subweights=roots_legendre(40)
        inside=low+width*(1+subnodes)/2
        ordinary=subweights*width/2
        endpoint=next(row for row in fixed if float(row["W_GeV"])==.8 and row["rule"]==grid)
        for term in ("H3","H4","A1","A2"):
            key="Im"+term[0]
            rho=np.array([float(row[key+"_4"]) for row in selected])
            end=float(endpoint[key+"_4"])
            bare=readout(sample,term)
            local=bare*prefactor(sample,term)
            mapped=(readout(inside,term)*prefactor(inside,term)-local[:,None])/(sample[:,None]-inside)
            upper_coeff=readout(high,term)*end
            total=(np.dot(quadw,rho*(mapped@ordinary)/prefactor(sample,term))+
                   np.dot(quadw,(rho*bare-upper_coeff*(sample-low)/width)*np.log((sample-low)/(high-sample)))+
                   width*upper_coeff/2)/np.pi
            interpolated=CubicSpline(np.r_[THRESH,energy,.8],
                          np.r_[reference[key],rho/(energy-THRESH)**5.5,end/(.8-THRESH)**5.5])
            def density(squared):
                delta=(squared-low)/(np.sqrt(squared)+THRESH)
                return delta**5.5*interpolated(np.sqrt(squared))/prefactor(squared,term)
            def by_source(squared):
                value,error=quad(density,low,high,weight="cauchy",wvar=squared,epsabs=1e-14,epsrel=1e-10)
                return value*readout(squared,term)*prefactor(squared,term)/np.pi
            reversed_total,error=quad(by_source,low,high,epsabs=5e-21,epsrel=4e-9,limit=120)
            rows.append(dict(term=term,energy_order=order,grid=grid,PV_swapped_GeVminus2=total,
                             PV_direct_spline_GeVminus2=reversed_total,
                             relative_difference=total/reversed_total-1,
                             signed_fraction_of_direct=reversed_total/direct))
    write("same-window.csv",rows)
    for term in ("H3","H4","A1","A2"):
        chosen=[row for row in rows if row["term"]==term]
        assert abs(chosen[-1]["relative_difference"])<.001
        assert max(abs(row["PV_direct_spline_GeVminus2"]/chosen[-1]["PV_direct_spline_GeVminus2"]-1)
                   for row in chosen[:-1])<.003
    print(rows[-4:])


if __name__=="__main__":
    calculate()

