import csv
import hashlib
import json
import sys
from itertools import combinations
from pathlib import Path

import numpy as np

HERE=Path(__file__).resolve().parent
PARENT=HERE.parent/"mts-four-pion-photon-cut-20261121"
PIN="c3dc3a70020db571ec0d55b4cf680e6b828d826530aa12868c370542269cb098"
assert hashlib.sha256((PARENT/"seal.json").read_bytes()).hexdigest()==PIN
for name,digest in json.loads((PARENT/"seal.json").read_bytes()).items():
    assert hashlib.sha256((PARENT/name).read_bytes()).hexdigest()==digest
sys.path.insert(0,str(PARENT))
from integrate import project,sky
from sources import DECAY, MASS, THRESH, CHARGES, FLAVOR, GRAM, INVERSE, dot, stress, elastic, roots_legendre
import angular


def pairings(labels):
    if not labels:
        yield ()
        return
    for slot,other in enumerate(labels[1:],1):
        for rest in pairings(labels[1:slot]+labels[slot+1:]):
            yield ((labels[0],other),)+rest


MATCH=list(pairings(tuple(range(6))))
INNER=list(pairings(tuple(range(4))))
CUTS=list(combinations(range(4),2))
assert len(MATCH)==15


def flavor(pairs):
    external=next((pair for pair in pairs if 4 in pair and 5 in pair),None)
    keep=[tuple(sorted(pair)) for pair in pairs if max(pair)<4]
    if not external:
        keep+=[tuple(sorted(min(pair) for pair in pairs if max(pair)>=4))]
    return INNER.index(tuple(sorted(keep))),1. if external else 1/3


def layout():
    result=[]
    for left in CUTS:
        right=tuple(idx for idx in range(4) if idx not in left)
        triples=(left+(4,),right+(5,))
        weights=np.zeros((3,3,3))
        for ai in range(3):
            for bi in range(3):
                fixed=[tuple(val for idx,val in enumerate(side) if idx!=omit)
                       for side,omit in zip(triples,(ai,bi))]
                partition,factor=flavor(fixed+[(triples[0][ai],triples[1][bi])])
                weights[partition,ai,bi]=factor
        result.append((left,right,weights))
    return result


DIAGRAMS=layout()


def full_subamplitude(mom,mass=MASS,decay=DECAY):
    pair_sum={(ia,ib):mom[ia]+mom[ib] for ia,ib in combinations(range(6),2)}
    pairs={pair:dot(vec,vec)-mass**2 for pair,vec in pair_sum.items()}
    contact=[]
    poles=[]
    for pairing in MATCH:
        contact.append(sum(pairs[key] for key in pairing)/decay**4)
        exchange=0.
        for idx,(ia,ib) in enumerate(pairing):
            first,second=[pair for pos,pair in enumerate(pairing) if pos!=idx]
            for leg in (ia,ib):
                total=pair_sum[first]+mom[leg]
                exchange-=pairs[first]*pairs[second]/(dot(total,total)-mass**2)
        poles.append(exchange/decay**4)
    return np.array(contact),np.array(poles)


def crossed(mom,direction):
    energy=mom[:,0].sum()
    pion=np.sqrt(energy**2/4-MASS**2)*np.array(direction)
    return np.vstack((mom,np.r_[-energy/2,-pion],np.r_[-energy/2,pion]))


def moments(ratio):
    square=ratio**2
    assert np.all(square<1)
    values=np.empty((len(ratio),3))
    small=ratio<.2
    for power in range(3):
        values[small,power]=np.polynomial.polynomial.polyval(square[small],1/(2*np.arange(14)+2*power+1))
    rem=~small
    values[rem,0]=np.arctanh(ratio[rem])/ratio[rem]
    values[rem,1]=(values[rem,0]-1)/square[rem]
    values[rem,2]=(values[rem,1]-1/3)/square[rem]
    return values.T


def axis_integral(matrix,axis,ratio):
    long=axis[:,:,None]*axis[:,None,:]
    perp=np.eye(3)-long
    vec=(matrix@axis[:,None,:,None])[...,0]
    axial=np.sum(vec*axis[:,None,:],axis=-1)
    vec-=axial[...,None]*axis[:,None,:]
    trace=np.trace(matrix,axis1=-2,axis2=-1)-axial
    cross=vec[:,:,:,None]*axis[:,None,None,:]+axis[:,None,:,None]*vec[:,:,None,:]
    sub=matrix-cross-axial[...,None,None]*long[:,None]
    base,second,fourth=moments(ratio)[:,:,None]
    mixed=second-fourth
    quartic=base-2*second+fourth
    result=(fourth*axial+mixed*trace/2)[...,None,None]*long[:,None]
    result+=mixed[...,None,None]*cross
    result+=(mixed*axial/2+quartic*trace/8)[...,None,None]*perp[:,None]
    result+=quartic[...,None,None]*sub/4
    return stress.tracefree(result)


def kernel(mom,energy):
    final=2*np.sqrt(energy**2/4-MASS**2)
    result=np.zeros((len(mom),3,3,3))
    max_ratio=0.
    for left,right,weights in DIAGRAMS:
        pair=mom[:,left[0]]+mom[:,left[1]]
        den=dot(pair,pair)-energy*pair[:,0]
        slope=final*pair[:,1:]
        length=np.linalg.norm(slope,axis=-1)
        assert np.all(den+length<=-MASS**2+1e-13)
        unit=np.divide(slope,length[:,None],out=np.zeros_like(slope),where=length[:,None]>0)
        unit[length==0,2]=1.
        ratio=-length/den
        max_ratio=max(max_ratio,float(ratio.max()))
        reduced=[]
        for group,sign in ((left,1),(right,-1)):
            first,second=mom[:,group[0]],mom[:,group[1]]
            pure=first+second
            base=np.stack((MASS**2-energy*second[:,0],MASS**2-energy*first[:,0],dot(pure,pure)-MASS**2),axis=1)
            linear=sign*final*np.stack((second[:,1:],first[:,1:],np.zeros_like(slope)),axis=1)
            reduced.append(linear-base[:,:,None]*(slope/den[:,None])[:,None,:])
        matrix=np.einsum("jab,eai,ebk->ejik",weights,*reduced,optimize=True)
        symmetric=(matrix+matrix.swapaxes(-1,-2))/2
        result-=axis_integral(symmetric,unit,ratio)/(den*DECAY**4)[:,None,None,None]
    return result,max_ratio

