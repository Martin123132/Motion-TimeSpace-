import csv
import json
from functools import lru_cache

import numpy as np
from controls import angular_checks,elastic_check,number_shapes,reference_check
from scattering import (GRAM,HERE,INVERSE,MASS,THRESH,angular,elastic,kernel,project,roots_legendre,sky,stress)


def write(name,rows):
    with (HERE/name).open("w",newline="",encoding="utf8") as stream:
        writer=csv.DictWriter(stream,fieldnames=rows[0])
        writer.writeheader()
        writer.writerows(rows)


def phase_space(energy,rule):
    mass_order,polar_order,azimuth_count,_=rule
    unit,mw=stress.mass_rule(mass_order)
    angle,aw=roots_legendre(polar_order)
    first,second,left,right,phase=np.meshgrid(unit,unit,angle,angle,np.arange(azimuth_count)*2*np.pi/azimuth_count,indexing="ij")
    excess=energy-THRESH
    mass_a=2*MASS+excess*first
    remain=excess*(1-first)
    mass_b=2*MASS+remain*second
    events,speed=stress.events(energy,mass_a,mass_b,left,right,phase,MASS)
    measure=(4*mass_a*mass_b*excess*remain*speed*np.sqrt(1-(2*MASS/mass_a)**2)*np.sqrt(1-(2*MASS/mass_b)**2)/
             ((2*np.pi)**2*(8*np.pi)**3))
    weight=(measure*mw[:,None,None,None,None]*mw[None,:,None,None,None]*aw[None,None,:,None,None]*
            aw[None,None,None,:,None]/(4*azimuth_count))
    return events.reshape(-1,4,4),weight.ravel()


@lru_cache(None)
def evaluate(energy,rule):
    mom,weights=phase_space(energy,rule)
    beta=np.sqrt(1-(2*MASS/energy)**2)
    p2=(beta*energy/2)**2
    phi2=beta/(8*np.pi)
    born=elastic.born(energy**2)
    accum=np.zeros(5)
    max_ratio=0.
    for start in range(0,len(mom),512):
        packet=mom[start:start+512]
        strong,ratio=kernel(packet,energy)
        max_ratio=max(max_ratio,ratio)
        photon,_=project(packet,energy,sky(rule[-1]))
        emt=stress.tracefree(sum(stress.vertices(packet))[...,1:,1:])
        inner=lambda mat,other:np.sum(mat*other,axis=(1,2,3))
        singlet=np.einsum("jk,ekab->ejab",GRAM,strong)
        ph=inner(strong,photon)*3/64
        st=inner(singlet,emt)*3/(192*p2)
        lost=(3*beta/(256*np.pi))*inner(singlet,strong)
        phnorm=(7.5/24)*inner(np.einsum("jk,ekab->ejab",INVERSE,photon),photon)
        stnorm=inner(np.einsum("jk,ekab->ejab",GRAM,emt),emt)/120
        accum+=weights[start:start+len(packet)]@np.stack((ph,st,lost,phnorm,stnorm),-1)
    ph,st,lost,phnorm,stnorm=accum
    refH=angular.read_wave(energy)
    refA=elastic.omega(energy**2)*(1-.01*energy**2)
    ratio_ph=np.sqrt(phnorm/(phi2*(10/3)*abs(refH)**2))
    ratio_st=np.sqrt(stnorm/(phi2*(4/5)*p2**2*abs(refA)**2))
    cos_ph=(ph/abs(refH))/(.5*np.sqrt(lost)*ratio_ph)
    cos_st=(st/abs(refA))/(.5*np.sqrt(lost)*ratio_st)
    assert max(abs(cos_ph),abs(cos_st))<=1+1e-10 and 0<lost<1
    return dict(W_GeV=energy,rule="-".join(map(str,rule)),events=len(mom),ImH_4=ph,ImA_4=st,P2to4_LO=lost,
                H_Born=born,phase_ph_tree_rad=ph/born,phase_T_tree_rad=st,relative_phase_tree_rad=ph/born-st,
                ph_over_ref_modulus=ph/abs(refH),stress_over_ref_modulus=st/abs(refA),
                overlap_ph=cos_ph,overlap_stress=cos_st,max_denominator_slope_ratio=max_ratio)


def run():
    checks={"literature_example":reference_check(),"angular":angular_checks(),
            "elastic_unitarity_abs":elastic_check(),"threshold":number_shapes()}
    rules=((6,4,8,7),(8,6,10,9))
    energies=(THRESH+.00025,THRESH+.0005,.60,.65,.70,.75,.80)
    points=[]
    for energy in energies:
        for rule in rules:
            points.append(evaluate(energy,rule))
        print("evaluated",energy,flush=True)
    fine=evaluate(.80,(10,8,14,12))
    points.append(fine)
    points.append(evaluate(.80,(8,6,10,13)))
    write("absorptive-cuts.csv",points)
    names=("ImH_4","ImA_4","P2to4_LO")
    checks["lower_grid_changes"]=dict((key,max(abs(evaluate(en,rules[0])[key]/evaluate(en,rules[1])[key]-1) for en in energies))
                                       for key in names)
    checks["upper_grid_changes"]=dict((key,abs(fine[key]/evaluate(.8,rules[1])[key]-1)) for key in names)
    assert max(checks["upper_grid_changes"].values())<.001
    coeff=checks["threshold"]["coefficients"]
    checks["threshold_relative"]={}
    for key,name in zip(names,("ImH","ImA","probability")):
        near,far=[evaluate(en,rules[1])[key]/(en-THRESH)**5.5 for en in energies[:2]]
        checks["threshold_relative"][name]=(2*near-far)/coeff[name]-1
    assert max(map(abs,checks["threshold_relative"].values()))<1e-4
    (HERE/"checks.json").write_text(json.dumps(checks,indent=2,allow_nan=False)+"\n",encoding="utf8")
    print(fine,checks,flush=True)


if __name__=="__main__":
    run()

