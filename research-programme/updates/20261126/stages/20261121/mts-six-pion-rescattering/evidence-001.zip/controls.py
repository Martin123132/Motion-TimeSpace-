from fractions import Fraction
from math import gamma
import numpy as np
from scattering import (CHARGES,DECAY,DIAGRAMS,FLAVOR,GRAM,MASS,MATCH,THRESH,crossed,dot,
                        flavor,full_subamplitude,kernel,roots_legendre,sky,stress)


def reference_check():
    mass,decay=.139570,.0927
    momentum=.1
    spatial=np.array([[1,0,0],[-.5,np.sqrt(.75),0],[-.5,-np.sqrt(.75),0],[0,0,1],
                      [np.sqrt(.75),0,-.5],[-np.sqrt(.75),0,-.5]])*momentum
    energy=np.sqrt(mass**2+momentum**2)
    momenta=np.column_stack((energy*np.r_[np.ones(3),-np.ones(3)],spatial))
    contact,poles=full_subamplitude(momenta,mass,decay)
    assert round(contact[0]*decay**2,2)==15.99 and round(poles[0]*decay**2,2)==-319.00
    return dict(contact=float(contact[0]*decay**2),exchange=float(poles[0]*decay**2))


def number_shapes():
    transform=np.array([[1,1,1],[1,-1,-1],[-1,1,-1],[-1,-1,1]])/2
    matrix=np.zeros((3,3,3))
    for left,right,weights in DIAGRAMS:
        pair=sum(transform[list(left)])
        const=np.array([-3,-3,3])
        lvec=np.stack((transform[left[1]],transform[left[0]],np.zeros(3)))+const[:,None]*pair/4
        rvec=-np.stack((transform[right[1]],transform[right[0]],np.zeros(3)))+const[:,None]*pair/4
        addition=3*np.einsum("jab,ai,bk->jik",weights,lvec,rvec)
        matrix+=(addition+addition.swapaxes(-1,-2))/2
    raw=[]
    for charge_index,charges in enumerate(CHARGES):
        mat=np.zeros((4,4))
        for part,(ia,ib,ic,idp) in enumerate(stress.PAIRS):
            if FLAVOR[part,charge_index]:
                for leg in range(4):
                    for other in range(4):
                        coeff=-3 if leg==other else 3 if ((leg in (ia,ib))==(other in (ia,ib))) else -5
                        mat[leg,other]+=coeff*charges[leg]*charges[other]/16
        raw.append(transform.T@mat@transform)
    gamma_mat=np.einsum("jc,cab->jab",FLAVOR,raw)
    stress_mat=2*(np.eye(3)[:,:,None]*np.eye(3)[:,None,:]-3*np.eye(3)/8)
    photon=3/64*(2/15)**2*(10/99)*np.sum(matrix*gamma_mat)
    emt=1/192*(2/15)*(10/99)*np.einsum("jab,jk,kab",matrix,GRAM,stress_mat)
    probability=(3/256)*(2/15)**2*(10/99)*np.einsum("jab,jk,kab",matrix,GRAM,matrix)
    common=MASS*(2*np.pi**4.5/gamma(4.5))*(2*MASS)**5.5/(8*(2*np.pi)**8*(2*MASS)**4)
    coefficients=dict(ImH=photon*common/(MASS**2*DECAY**6),ImA=emt*common/(MASS**2*DECAY**6),
                      probability=probability*common*np.sqrt(.75)/(np.pi*DECAY**8))
    rational=[str(Fraction(float(val)).limit_denominator(10000000)) for val in (photon,emt,probability)]
    return dict(jacobi=matrix.tolist(),rational=rational,coefficients=coefficients)


def angular_checks():
    packet,_=stress.events(.752,.325,.342,np.array([.11,-.47]),np.array([-.26,.60]),np.array([1.62,.83]),MASS)
    closed,ratio=kernel(packet,.752)
    worst=0.; perm_error=0.; neutral_error=0.; contact_only=0.
    for index,mom in enumerate(packet):
        total=np.zeros((3,3,3))
        contacts=np.zeros_like(total)
        for ray in sky(12):
            crossed_mom=crossed(mom,ray[:3])
            contact,poles=full_subamplitude(crossed_mom)
            combined=contact+poles
            for data,external in ((total,combined),(contacts,contact)):
                for value,pairing in zip(external,MATCH):
                    part,weight=flavor(pairing)
                    data[part]+=value*weight*ray[10:].reshape(3,3)
        worst=max(worst,float(np.max(abs(total-closed[index]))/np.max(abs(closed[index]))))
        contact_only=max(contact_only,float(np.max(abs(contacts))))
        fixed=crossed(mom,[0,0,1])
        amplitude=sum(full_subamplitude(fixed))
        from itertools import combinations
        neutral=-MASS**2/DECAY**4
        for pair in combinations(range(1,6),2):
            triple=fixed[0]+fixed[pair[0]]+fixed[pair[1]]
            neutral-=MASS**4/DECAY**4/(dot(triple,triple)-MASS**2)
        neutral_error=max(neutral_error,abs(amplitude.sum()-neutral))
        rng=np.random.default_rng(6439)
        for rep in range(24):
            perm=rng.permutation(6)
            permuted=sum(full_subamplitude(fixed[perm]))
            for slot,pairs in enumerate(MATCH):
                labels=tuple(sorted(tuple(sorted((perm[ia],perm[ib]))) for ia,ib in pairs))
                perm_error=max(perm_error,abs(permuted[slot]-amplitude[MATCH.index(labels)]))
        assert np.allclose(sum(full_subamplitude(-fixed)),amplitude,rtol=1e-13,atol=1e-12)
    assert worst<5e-8 and contact_only<2e-10 and perm_error<1e-9 and neutral_error<1e-9
    return dict(angular_relative=worst,analytic_contact_D_zero=contact_only,full_crossing_abs=perm_error,
                all_neutral_angle_coordinate_abs=neutral_error,max_denominator_ratio=ratio)


def elastic_check():
    beta=.77
    phi2=beta/(8*np.pi)
    directions=sky(8)
    beam=directions[:,:3]
    weight=directions[:,9]
    p2=lambda cosine:(3*cosine**2-1)/2
    kernel_elastic=32*np.pi*5*.031*p2(beam@beam.T)
    errors=[]
    for values in ((1.27,-.54,.62),(-1.46,.91,.13)):
        strength=sum(values)/3
        drive=3*strength*p2(beam[:,2])
        got=phi2/4*(kernel_elastic@(weight*drive))/3
        errors.append(float(np.max(abs(got-beta*.031*strength*p2(beam[:,2])))))
    assert max(errors)<1e-14
    return max(errors)


if __name__=="__main__":
    print(reference_check(),angular_checks(),number_shapes(),elastic_check())

