import csv
import json
import numpy as np
from scattering import (CHARGES,FLAVOR,GRAM,HERE,MASS,MATCH,angular,crossed,elastic,flavor,
                        full_subamplitude,kernel,project,sky,stress)
from sources import NB,tensor


def reciprocal():
    energy=.72
    phase=np.sqrt(1-(2*MASS/energy)**2)/(8*np.pi)
    p2=energy**2/4-MASS**2
    born=elastic.born(energy**2)
    packet,_=stress.events(energy,.33,.32,np.array([.23]),np.array([-.46]),np.array([1.76]),MASS)
    mom=packet[0]
    rays=sky(8)
    final=sky(14)
    strong=np.zeros((len(final),3))
    for idx,ray in enumerate(final):
        amplitude=sum(full_subamplitude(crossed(mom,ray[:3])))
        for value,pairing in zip(amplitude,MATCH):
            channel,weight=flavor(pairing)
            strong[idx,channel]+=weight*value
    kernel_legendre=(3*(rays[:,:3]@final[:,:3].T)**2-1)/2
    rescatter=(kernel_legendre*final[:,9])@(strong@FLAVOR)
    dph=phase/4*10*born*rescatter
    dst=phase/4*3*4*p2/np.sqrt(6)*rescatter
    emt=stress.tracefree(sum(stress.vertices(packet))[0,:,1:,1:])
    four_imag=0.
    for idx,ray in enumerate(rays):
        polarization=(3*np.outer(ray[:3],ray[:3])-np.eye(3))/np.sqrt(6)
        st=(np.einsum("ij,cij->c",polarization,emt)@FLAVOR)
        beam=energy/2*np.r_[1.,ray[:3]]
        other=energy/2*np.r_[1.,-ray[:3]]
        basis=ray[3:9].reshape(2,3)
        photon=np.zeros(len(CHARGES))
        for qidx in np.nonzero(FLAVOR.any(axis=0))[0]:
            mat=tensor(mom,CHARGES[qidx],beam,other)
            photon[qidx]=-np.trace(basis@mat[1:,1:]@basis.T)/4
        four_imag+=ray[9]*(dph[idx]@st-photon@dst[idx])/24
    strong_proj,ratio=kernel(packet,energy)
    ph_proj,_=project(packet,energy,rays)
    imh=(3/64)*np.sum(strong_proj*ph_proj)
    ima=3/(192*p2)*np.einsum("jab,jk,kab",strong_proj[0],GRAM,emt)
    two_imag=phase*4*p2/np.sqrt(6)*(imh-born*ima)
    residual=float((two_imag+four_imag)/abs(two_imag))
    assert abs(residual)<3e-8 and abs(two_imag)>1e-3
    return dict(two=two_imag,four=four_imag,relative_sum=residual)


def run():
    check=reciprocal()
    with (HERE/"absorptive-cuts.csv").open() as stream:
        row=list(csv.DictReader(stream))[-2]
    assert row["rule"]=="10-8-14-12" and float(row["W_GeV"])==.8
    probability=float(row["P2to4_LO"])
    momentum2=.8**2/4-MASS**2
    check["isospin0_J2_cross_section_nb_at_0p8"]=10*np.pi*probability/momentum2*NB
    (HERE/"reciprocal.json").write_text(json.dumps(check,indent=2,allow_nan=False)+"\n",encoding="utf8")
    print(check)


if __name__=="__main__":
    run()

