import argparse
import csv
import hashlib
import json
from pathlib import Path
from scattering import HERE,PARENT,PIN

FILESET=("scattering.py","controls.py","calculate.py","disperse.py","same_window.py","reciprocal.py","parent_readout.py",
         "verify.py","DERIVATION.md","DISPERSION.md","RESULTS.md","REPLAY.md","absorptive-cuts.csv","checks.json",
         "dispersion-window.csv","dispersion-nodes.csv","subthreshold-values.csv","same-window.csv","reciprocal.json",
         "conditional-parent-readout.csv")


def validate():
    counts={"absorptive-cuts.csv":16,"dispersion-window.csv":3,"dispersion-nodes.csv":26,
            "subthreshold-values.csv":9,"same-window.csv":12,"conditional-parent-readout.csv":3}
    for name,count in counts.items():
        with (HERE/name).open() as stream:
            values=list(csv.DictReader(stream))
        assert len(values)==count and all(None not in row and None not in row.values() for row in values)
    test=json.loads((HERE/"checks.json").read_bytes())
    assert test["literature_example"]["exchange"]<0<test["literature_example"]["contact"]
    assert max(test["upper_grid_changes"].values())<.001
    assert max(map(abs,test["threshold_relative"].values()))<1e-4
    assert abs(json.loads((HERE/"reciprocal.json").read_bytes())["relative_sum"])<3e-8
    assert {item.name for item in HERE.iterdir() if item.name!="seal.json"}==set(FILESET)
    return {name:hashlib.sha256((HERE/name).read_bytes()).hexdigest() for name in FILESET}


if __name__=="__main__":
    parser=argparse.ArgumentParser()
    parser.add_argument("--seal",action="store_true")
    products=validate()
    receipt=HERE/"seal.json"
    if parser.parse_args().seal:
        with receipt.open("x",encoding="utf8",newline="\n") as stream:
            stream.write(json.dumps(products,indent=2)+"\n")
    assert json.loads(receipt.read_bytes())==products
    print("Verified",len(FILESET),"files; seal",hashlib.sha256(receipt.read_bytes()).hexdigest(),"prior",PIN)

