import numpy as np
from calculate import evaluate,write
from scattering import HERE,MASS,THRESH,elastic,roots_legendre
import json


def rule(low,high,order):
    abscissa,weight=roots_legendre(order)
    return low+(high-low)*(1+abscissa)/2,weight*(high-low)/2


def finite_window(order,grid):
    energy,weights=rule(THRESH,.8,order)
    rows=[evaluate(point,grid) for point in energy]
    spectral=np.array([[row["ImH_4"],row["ImA_4"]] for row in rows])
    upper=energy**2
    reference=weights*(2*energy)/np.pi
    pair=4*MASS**2
    def shifts(squared):
        squared=np.atleast_1d(squared)[:,None]
        factor=reference/(upper-squared)
        photon=factor*(squared/upper)**2*(squared-pair)/(upper-pair)
        stress=factor*squared/upper
        return np.stack([photon@spectral[:,0],(photon*squared/upper)@spectral[:,0],
                         stress@spectral[:,1],(stress*squared/upper)@spectral[:,1]],axis=-1)
    sample=[dict(W_GeV=val,photon_three_sub=row[0],photon_four_sub=row[1],
                 stress_one_sub=row[2],stress_two_sub=row[3])
            for val,row in zip((.40,.50,.54),shifts(np.array([.4,.5,.54])**2))]
    lower,outer=rule(.281,.54,36)
    vals=shifts(lower**2)
    observed=outer*(2*elastic.KAPPA/lower**3)*(1-(2*MASS/lower)**2)**1.5
    point=np.array([elastic.born(val**2) for val in lower])
    indirect=observed@(vals*np.column_stack((np.ones_like(point),np.ones_like(point),point,point)))
    budget=dict(photon_three_sub_GeVminus2=indirect[0],photon_four_sub_GeVminus2=indirect[1],
                stress_one_sub_GeVminus2=indirect[2],stress_two_sub_GeVminus2=indirect[3])
    nodes=np.array([.30,.38,.46,.54])**2
    shape=reference/np.prod(upper-nodes[:,None],axis=0)
    third=shape@spectral
    direct=np.column_stack([(reference/(upper-node))@spectral for node in nodes])
    bary=np.array([1/np.prod(node-np.delete(nodes,idx)) for idx,node in enumerate(nodes)])
    assert np.max(abs((direct@bary)/third-1))<1e-10
    changed=shifts(nodes)
    assert abs(bary@changed[:,0]/third[0]-1)<1e-10
    assert abs(bary@changed[:,3]/third[1]-1)<1e-10
    node_sig=nodes**2*(nodes-pair)
    photon_poly=np.diff((changed[:,0]-changed[:,1])/node_sig)
    stress_poly=np.diff((changed[:,2]-changed[:,3])/nodes)
    assert np.max(abs(photon_poly))<1e-15 and np.max(abs(stress_poly))<1e-15
    five=np.array([.30,.36,.42,.48,.54])**2
    fourth=(reference/np.prod(upper-five[:,None],axis=0))@spectral
    factors=np.array([1/np.prod(node-np.delete(five,idx)) for idx,node in enumerate(five)])
    assert np.max(abs((factors@shifts(five))/np.repeat(fourth,2)-1))<1e-9
    differences=dict(third_H_GeVminus6=third[0],third_A_GeVminus6=third[1],
                     fourth_H_GeVminus8=fourth[0],fourth_A_GeVminus8=fourth[1])
    return budget,differences,sample,rows


def run():
    results=[]
    values=[]
    separate=[]
    samples=[]
    for order,grid in ((6,(6,4,8,7)),(10,(6,4,8,7)),(10,(8,6,10,9))):
        label=dict(energy_order=order,grid="-".join(map(str,grid)))
        budget,differences,sample,rows=finite_window(order,grid)
        results.append(dict(**label,**budget,**differences))
        values.append(list(budget.values())+list(differences.values()))
        separate.extend(dict(**label,**row) for row in sample)
        samples.extend(dict(energy_order=order,**row) for row in rows)
    assert np.max(abs(np.array(values[:-1])/values[-1]-1))<.003
    write("dispersion-window.csv",results)
    write("subthreshold-values.csv",separate)
    write("dispersion-nodes.csv",samples)
    print(results,flush=True)


if __name__=="__main__":
    run()

