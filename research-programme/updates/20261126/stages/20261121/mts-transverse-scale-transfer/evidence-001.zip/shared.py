import os
for setting in ("OPENBLAS_NUM_THREADS","MKL_NUM_THREADS","NUMEXPR_NUM_THREADS","OMP_NUM_THREADS","BLIS_NUM_THREADS"):
    os.environ[setting]="1"
import csv
import hashlib
import io
import json
from fractions import Fraction
from pathlib import Path
import numpy as np

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
FREE=ROOT/"mts-mixed-current-weyl-extractor-20261121"
D450=ROOT/"mts-d450-rectangle-clover-ward-20261121"
REGISTER=ROOT/"source-intake/functional_rg/4944/visible_CFF_matching_components.csv"
PINS={FREE:"de33739c4e144efceef1b1151c9289f7166ccd8779a4c768fb2d195117994a1b",D450:"e03e21d9d35f1c705c447758eb8d04b5f6f4f9d44e62714fe285bf25095da768"}

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def guard():
    assert not any((folder/"STOP-REQUESTED").exists() for folder in (HERE,ROOT,FREE,D450))
    for folder,pin in PINS.items():
        assert sha(folder/"seal.json")==pin
        for name,stamp in json.loads((folder/"seal.json").read_bytes())["files"].items():
            assert sha(folder/name)==stamp
    assert sha(REGISTER)=="96a8b2f3efe054681203516422e1f1133a725ce70cb1f36fb0a5ab3b863b7b2a"

def read(path):
    with path.open(encoding="utf-8-sig",newline="") as handle:
        return list(csv.DictReader(handle))

def save(name,blob):
    raw=blob if isinstance(blob,bytes) else blob.encode()
    path=HERE/name
    if path.exists():
        if path.read_bytes()!=raw:
            raise ValueError("Replay mismatch: "+name)
    else:
        with path.open("xb") as handle:
            handle.write(raw)

def table(name,rows):
    buffer=io.StringIO(newline="")
    writer=csv.DictWriter(buffer,fieldnames=list(rows[0]),lineterminator="\n")
    writer.writeheader()
    writer.writerows(rows)
    save(name,buffer.getvalue())

def banks():
    return [("-".join(map(str,row["indices"])),dict(zip(row["indices"],map(Fraction,row["weights"])))) for row in json.loads((FREE/"frozen-projectors.json").read_bytes())["projectors"]]
