from scale_kernel import banks, edge, guard, np, quadrature, table, direct

def run():
    guard()
    controls=[]
    for bank,weights in banks():
        nodes,mass=quadrature(weights,64)
        high=2.**28
        scales=[0.]+[2.**idx for idx in range(-6,29,2)]
        assert scales[-1]==high
        bound=np.zeros(2)
        for index,coeff in weights.items():
            psq=1+index**2
            limit=edge(index)
            bound+=abs(float(coeff))*np.array([2*psq/3+2*limit,8*psq/6+2*(abs(1-index**2)+2*limit)])
        tail=bound*np.log1p(high*max(edge(i) for i in weights))/high
        differences=np.array([(large-small)* (mass@(nodes/((1+large*nodes)*(1+small*nodes))))
                              for small,large in zip(scales,scales[1:])])
        estimate=differences.sum(axis=0)
        truth=np.array([1/180,-1/90])
        assert np.all(abs(estimate-truth)<tail)
        np.testing.assert_allclose(estimate+direct(weights,high**.5),truth,atol=2.e-11,rtol=0)
        sample=np.array([.125,.25,.5])
        arg=sample**2
        coeff=np.array([4.,-5.,1.])
        values=np.array([direct(weights,ratio) for ratio in sample])
        free=coeff@values
        shifted=values+(1.7-4*2.3*arg)[:,None]
        np.testing.assert_allclose(coeff@shifted,free,atol=2.e-11,rtol=0)
        shifted+=(-.4*16*arg**2)[:,None]
        np.testing.assert_allclose(coeff@shifted-free,np.full(2,-.4*16*(coeff@arg**2)),atol=2.e-11,rtol=0)
        for idx,label in enumerate(("scalar","Dirac")):
            controls.append(dict(bank=bank,loop=label,scale_pairs=len(scales)-1,max_t=high,from_differences=estimate[idx],
                                 true_loop_intercept=truth[idx],analytic_abs_tail_bound=tail[idx],three_point_second_difference=free[idx],
                                 dimension10_unit_gain=16*(coeff@arg**2)))
    table("uv-and-contact-control.csv",controls)

if __name__=="__main__":
    run()
