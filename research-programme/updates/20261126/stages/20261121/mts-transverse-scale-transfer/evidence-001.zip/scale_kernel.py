from shared import FREE, HERE, banks, guard, np, read, table
from functools import lru_cache
from fractions import Fraction
from scipy.special import roots_legendre
import sys
sys.path.insert(0,str(FREE))
from charged_scalar import integrate as scalar_loop, gram
from spinor import integrate as dirac_loop

@lru_cache(None)
def unit_rule(order):
    nodes,weights=roots_legendre(order)
    return (1+nodes)/2,weights/2

def smooth_rule(left,right,order):
    nodes,weights=unit_rule(order)
    return left+(right-left)*np.sin(np.pi*nodes/2)**2,weights*(right-left)*np.pi/2*np.sin(np.pi*nodes)

def edge(index):
    psq=1+index**2
    return 1. if psq<=2 else psq**2/(4*(psq-1))

def density(index,inv_cut,order):
    psq=1+index**2
    dot=1-index**2
    width=np.sqrt(max(0.,1-4*inv_cut/psq))
    bubble=psq*width**3/6
    splits=[0.,1.]
    if width>0:
        splits.extend(((1-width)/2,(1+width)/2))
    if psq==1:
        splits.append(inv_cut)
    elif psq**2>4*(psq-1)*inv_cut:
        disc=np.sqrt(psq**2-4*(psq-1)*inv_cut)
        splits.extend((2*inv_cut/(psq+disc),(psq+disc)/(2*(psq-1))))
    splits=sorted(set(val for val in splits if 0<=val<=1))
    scalar,dirac=4*bubble,8*(bubble+inv_cut*width)
    for left,right in zip(splits,splits[1:]):
        nodes,weights=smooth_rule(left,right,order)
        peak=nodes*(psq+(1-psq)*nodes)
        extent=np.minimum(nodes,np.sqrt(np.maximum(0,peak-inv_cut)))
        integrated=extent*(peak-extent**2/3)
        scalar-=4*(weights@(integrated-inv_cut*extent))
        dirac+=4*(weights@((nodes-1)*dot*extent-2*integrated))
    return np.array([scalar,dirac])

def quadrature(weights,order):
    seams=sorted(set([0.,1.]+[(1+index**2)/4 for index in weights]+[edge(i) for i in weights]))
    nodes,measure=[],[]
    for left,right in zip(seams,seams[1:]):
        abscissae,gauss=smooth_rule(left,right,order)
        nodes.extend(abscissae)
        measure.extend([weight*sum(float(factor)*density(index,cut,order) for index,factor in weights.items())
                        for cut,weight in zip(abscissae,gauss)])
    return np.array(nodes),np.array(measure).T

def direct(weights,ratio):
    return sum(float(weight)*np.array([scalar_loop(*gram(index),ratio,1.,1.,64)[0],dirac_loop(index,ratio,64)])
               for index,weight in weights.items())

def run():
    guard()
    moments,changes,signs=[],[],[]
    for bank,weights in banks():
        nodes,measures=quadrature(weights,48)
        coarse,coarse_measures=quadrature(weights,32)
        species=("scalar","Dirac")
        for idx,filename in enumerate(("exact-series.csv","dirac-series.csv")):
            for row in read(FREE/filename):
                if row["bank"]!=bank:
                    continue
                degree=int(row["momentum_power"])//2-2
                truth=Fraction(row["coefficient"])
                observed=(-1)**degree*(measures[idx]@nodes**degree)
                assert abs(observed-float(truth))<2.e-11
                moments.append(dict(bank=bank,loop=species[idx],degree=degree,exact=str(truth),integral=observed,error=observed-float(truth)))
        for inv in (.01,.1,.4,.8,.97,1.1,1.4,2.55):
            value=sum(float(weight)*density(index,inv,48) for index,weight in weights.items())
            for idx,label in enumerate(species):
                signs.append(dict(bank=bank,loop=label,inverse_cut=inv,signed_density=value[idx]))
        for ratio in (.125,.25,.5,1.,2.):
            high=ratio**2
            low=high/4
            delta=-(high-low)*measures@(nodes/((1+low*nodes)*(1+high*nodes)))
            coarse_result=-(high-low)*coarse_measures@(coarse/((1+low*coarse)*(1+high*coarse)))
            large,small=direct(weights,ratio),direct(weights,ratio/2)
            np.testing.assert_allclose(large,measures@(1/(1+high*nodes)),atol=2.e-11,rtol=0)
            np.testing.assert_allclose(delta,large-small,atol=2.e-11,rtol=0)
            np.testing.assert_allclose(delta,coarse_result,atol=2.e-11,rtol=0)
            for idx,label in enumerate(species):
                slope=-measures[idx]@nodes
                curvature=measures[idx]@nodes**2
                leading=slope*(high-low)
                next_term=curvature*(high**2-low**2)
                for shift in (-2.7,1.9):
                    assert abs((large[idx]+shift)-(small[idx]+shift)-delta[idx])<2.e-11
                changes.append(dict(bank=bank,loop=label,eps_high_over_m=ratio,delta=delta[idx],direct=large[idx]-small[idx],
                                    quadrature_change=delta[idx]-coarse_result[idx],dim8=leading,dim10=next_term,
                                    beyond_dim10=delta[idx]-leading-next_term))
    table("scale-differences.csv",changes)
    table("cut-moments.csv",moments)
    table("signed-cut-witnesses.csv",signs)

if __name__=="__main__":
    run()
