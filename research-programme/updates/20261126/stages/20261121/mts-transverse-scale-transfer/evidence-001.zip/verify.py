from shared import D450, FREE, HERE, PINS, REGISTER, ROOT, guard, json, np, read, save, sha
import re
import sys

EXPECTED={"scale-differences":20,"cut-moments":22,"signed-cut-witnesses":32,"uv-and-contact-control":4,
          "paired-spacing":8,"onshell-moments":15,"onshell-form-factor":18,"pion-aperture-bins":140,"pion-born-coverage":3}


def run(seal):
    guard()
    for key,number in EXPECTED.items():
        values=read(HERE/(key+".csv"))
        assert len(values)==number and all(None not in row and None not in row.values() for row in values)
    for row in read(HERE/"scale-differences.csv"):
        assert abs(float(row["delta"])-float(row["direct"]))<2.e-11
        assert abs(float(row["quadrature_change"]))<2.e-11
    for row in read(HERE/"uv-and-contact-control.csv"):
        assert abs(float(row["from_differences"])-float(row["true_loop_intercept"]))<float(row["analytic_abs_tail_bound"])<1.e-7
    curves=read(HERE/"paired-spacing.csv")
    for key in ("0-1-2","1-2-3"):
        selected=[row for row in curves if row["bank"]==key]
        assert [row["size"] for row in selected]==["24","48","64","96"]
        changes=np.abs([float(row["relative_discrepancy"]) for row in selected])
        assert np.all(np.diff(changes)<0) and changes[-1]>.03
        assert max(abs(float(row["injected_then_subtracted"])-float(row["lattice_difference"])) for row in selected)<2.e-10
    signed=json.loads((HERE/"matched-vector.json").read_bytes())
    assert signed["signed_optical_W_m2"]<0 and abs(signed["old_over_magnitude"]-600)<1.e-5 and not signed["total_QCD_determined"]
    obs=json.loads((HERE/"pion-aperture.json").read_bytes())
    angles=read(HERE/"pion-aperture-bins.csv")
    assert sum(bool(row["angular_sum_minus_table1_relative"]) for row in angles)==3
    assert obs["max_selected_differential_total_discrepancy"]<.0001
    assert 0<obs["conditional_per_sup_abs_A_charged_GeVminus2"]<obs["all_pointwise_upwards_errors_GeVminus2"]
    sourcepins={1:"438be5582a2485922bc1d6ddf78acf1f2dc3e012978c94c1819c60555ccec557",
                2:"42c4773856e6a3f09291f8b873ed672a21de7ecd98c2157a8389ed3d9e7e6982",
                96:"ed9ac31ade69931d4c720dfc175682905d1ce2173d241c28fd2ecb816e67d258",
                141:"e246664ffa2daccf353a503685c89525215861bcef87aeff523d046d89dd3e28"}
    for number,stamp in sourcepins.items():
        assert sha(HERE/f"belle-t{number}.json")==stamp
    prov=REGISTER.parent/"PROVENANCE.md"
    assert sha(prov)=="da4cda35608a9117adf5fb3bd1c9c024d2bb0575f66e8a04e538134da718b3bd"
    files={}
    for path in sorted(HERE.iterdir()):
        assert path.is_file()
        if path.name=="seal.json":
            continue
        files[path.name]=sha(path)
        if path.suffix==".py":
            compile(path.read_bytes(),str(path),"exec")
        if path.suffix==".md":
            for link in re.findall(r"\[[^]\n]*\]\(([^)\s]+)\)",path.read_text(encoding="utf-8")):
                if "://" not in link:
                    assert (HERE/link).is_file(),link
    summary=dict(files=files,parent={folder.name:pin for folder,pin in PINS.items()},
                 other_inputs={str(path.relative_to(ROOT)):sha(path) for path in (REGISTER,prov)},csv_rows=sum(EXPECTED.values()))
    if seal:
        save("seal.json",json.dumps(summary,indent=2,sort_keys=True)+"\n")
    assert json.loads((HERE/"seal.json").read_bytes())==summary
    print(len(files),"files",summary["csv_rows"],"data rows; seal",sha(HERE/"seal.json"))


if __name__=="__main__":
    assert __debug__ and sys.argv[1:] in ([],["--seal"])
    run(sys.argv[1:]==["--seal"])
