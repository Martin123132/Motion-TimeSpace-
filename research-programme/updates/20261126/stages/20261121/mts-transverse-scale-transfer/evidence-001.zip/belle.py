from shared import HERE, guard, json, np, save, table
from cut import HBARC, alpha, partial
import sys
import requests
from scipy.integrate import quad

TABLES={1:44742,2:44744,96:44999,141:45085}
MASS=.1395704
NB_PER_GEV2=HBARC**2/1.e-37
CHARGE2=4*np.pi*alpha
DW=.005
DZ=.05

def p2norm(low,high):
    primitive=lambda val:(9*val**5/5-2*val**3+val)/4
    return primitive(high)-primitive(low)

def separation(value):
    beta=np.sqrt(1-4*MASS**2/value**2)
    return beta, np.sqrt(32*np.pi)*beta**2.5/(CHARGE2*value**2)*alpha/(4*np.pi)

def cross(item):
    val=item["y"][0]
    central=float(val["value"])
    upper=sum(float(err["symerror"]) if "symerror" in err else float(err["asymerror"]["plus"]) for err in val["errors"])
    assert central>=0 and upper>0
    return np.array([central,central+upper])/NB_PER_GEV2

def run(acquire):
    guard()
    data={}
    for num,rec in TABLES.items():
        name=f"belle-t{num}.json"
        if acquire:
            with requests.get(f"https://www.hepdata.net/record/data/51842/{rec}/1/",timeout=20,stream=True) as response:
                response.raise_for_status()
                blob=response.raw.read(160001,decode_content=True)
            assert len(blob)<160001
            save(name,blob)
        data[num]=json.loads((HERE/name).read_bytes())
        assert data[num]["doi"]==f"10.17182/hepdata.51842.v1/t{num}" and data[num]["keywords"]["reactions"]==["GAMMA GAMMA --> PI+ PI-"]
    total=data[1]
    assert total["headers"][-1]["name"]=="SIG [NB]" and len(total["values"])==140
    rows=[]
    for idx,item in enumerate(total["values"]):
        energy=float(item["x"][0]["value"])
        low=.8+idx*DW
        assert abs(low+DW/2-energy)<1.e-12 and low>3*MASS
        beta,kernel=separation(low)
        bound=DW*kernel*np.sqrt(p2norm(0,.6)*cross(item))
        aligned=np.array([bound[0],bound[1]])
        angle_check=None
        key=idx+2
        if key in data:
            sub=data[key]
            assert sub["headers"][-1]["name"]=="D(SIG)/DABS(COS(THETA)) [NB]" and len(sub["values"])==12
            energy_label="W" if key==2 else "SQRTS(S)"
            if key!=2:
                assert sub["qualifiers"]["SQRT(S)"][0]["value"]=="0.0 GeV"
            assert abs(float(sub["qualifiers"][energy_label][0]["value"].split()[0])-energy)<1.e-10
            cumulative=np.zeros(2)
            summed=0.
            for label,entry in enumerate(sub["values"]):
                left=label*DZ
                assert abs(float(entry["x"][0]["value"])-left-DZ/2)<1.e-10
                sigma=cross(entry)*DZ
                summed+=sigma[0]
                cumulative+=np.sqrt(p2norm(left,left+DZ)*sigma)
            aligned=DW*kernel*cumulative
            angle_check=summed/cross(item)[0]-1
        rows.append(dict(W_GeV=energy,central_intensity_ceiling_GeVminus2=bound[0],error_box_ceiling_GeVminus2=bound[1],
                         with_available_angular_bins_GeVminus2=aligned[0],angular_sum_minus_table1_relative=angle_check))
    table("pion-aperture-bins.csv",rows)
    for energy in (.45,.81,1.27,1.49):
        beta,kernel=separation(energy)
        amp=lambda angle:2*CHARGE2*(1-beta**2)/(1-beta**2*angle**2)
        opposite=lambda angle:2*CHARGE2*beta**2*(1-angle**2)/(1-beta**2*angle**2)
        measure=lambda angle:beta*(amp(angle)**2+opposite(angle)**2)/(32*np.pi*energy**2)
        actual=quad(lambda angle:(3*angle**2-1)*amp(angle)/(4*CHARGE2),0,.6)[0]
        outward=quad(lambda angle:(3*angle**2-1)*amp(angle)/(4*CHARGE2),.6,1.)[0]
        assert abs(actual+outward-(1-beta**2)*partial(beta))<2.e-11
        ceiling=np.sqrt(p2norm(0,.6)*32*np.pi*energy**2/beta*quad(measure,0,.6)[0])/(2*CHARGE2)
        assert abs(actual)<ceiling
    summary=dict(conditional_per_sup_abs_A_charged_GeVminus2=sum(row["central_intensity_ceiling_GeVminus2"] for row in rows),
                 all_pointwise_upwards_errors_GeVminus2=sum(row["error_box_ceiling_GeVminus2"] for row in rows),
                 energy_interval_GeV=[.8,1.5],abs_cos_max=.6,number_energy_bins=len(rows),
                 scope="charged two-pion, observed angular part only; conditional on true corrected bin averages; error box is not a confidence level",
                 max_selected_differential_total_discrepancy=max(abs(row["angular_sum_minus_table1_relative"]) for row in rows if row["angular_sum_minus_table1_relative"] is not None))
    save("pion-aperture.json",json.dumps(summary,indent=2)+"\n")

if __name__=="__main__":
    run(sys.argv[1:]==["--acquire"])
