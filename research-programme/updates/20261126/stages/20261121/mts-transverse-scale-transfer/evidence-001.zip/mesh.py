from shared import D450, FREE, banks, guard, np, read, table
import math
import sys
sys.path.insert(0,str(FREE))
from lattice import bank as loop_terms
from charged_scalar import integrate,gram


def circulation(size,mode,index):
    clock,place=np.indices((size,size))
    phase=2*np.pi*mode/size
    waves=[np.exp(1j*phase*(-clock+sign*index*place)) for sign in (1,-1)]
    shear=np.exp(2j*phase*clock)
    total=0j
    for extent,width,coeff in ((1,1,5/3),(2,1,-1/12),(1,2,-1/12)):
        for axis in (0,1):
            corner=(shear+np.roll(shear,-extent,axis=axis))/2
            center=shear*np.exp(1j*phase*extent*(axis==0))
            flux=[width*(np.roll(w,-extent,axis=axis)-w) for w in waves]
            total-=coeff*np.mean((2*corner+center)*flux[0]*flux[1]/3)
    assert abs(total.imag)<2.e-10
    return total.real

def run():
    guard()
    rows=[]
    for size in (24,48,64,96):
        mass=24/size
        observed={}
        for mode in (1,2):
            saved=FREE/f"lattice-readout-{size}-am{mass:.6f}-n{mode}.csv"
            eps=2*np.pi*mode/size
            if not saved.exists():
                terms=[math.fsum(loop_terms(size,mass,index,mode)) for index in range(4)]
            for label,weights in banks():
                true=sum(float(weight)*integrate(*gram(index),eps/mass,1.,1.,48)[0] for index,weight in weights.items())
                if saved.exists():
                    record=next(row for row in read(saved) if row["bank"]==label)
                    assert abs(float(record["continuum_same_momentum"])-true)<2.e-11
                    discrete=float(record["normalized_coefficient"])
                else:
                    discrete=sum(float(weight)*terms[index] for index,weight in weights.items())*mass**2*(4*np.pi)**2/eps**4
                from_links=sum(float(weight)*circulation(size,mode,index) for index,weight in weights.items())*mass**2/eps**4
                template=0. if label=="0-1-2" else mass**2/eps**4*sum(coeff*width**2*(2*np.sin(extent*eps/2)**2)**3/20 for extent,width,coeff in ((1,1,5/3),(2,1,-1/12),(1,2,-1/12)))
                assert abs(template-from_links)<2.e-10
                for strength in (-3.4,2.1):
                    assert abs(discrete+from_links*strength-template*strength-discrete)<2.e-10
                observed[label,mode]=discrete,true,from_links,template
        for label,weights in banks():
            discrete,true,contact,template=np.subtract(observed[label,2],observed[label,1])
            rows.append(dict(size=size,am=mass,mL=24,eps_low_over_m=2*np.pi/24,bank=label,lattice_difference=discrete,
                             continuum_difference=true,relative_discrepancy=discrete/true-1,unit_Maxwell_difference=contact,
                             injected_then_subtracted=discrete+2.1*(contact-template)))
    table("paired-spacing.csv",rows)

if __name__=="__main__":
    run()
