from shared import HERE, ROOT, FREE, REGISTER, guard, np, read, save, table, json, Fraction
import hashlib
import io
import math
import re
import sys
import tarfile
import urllib.request
from scipy.constants import alpha
from scipy.integrate import quad
from scipy.special import roots_legendre

ARCHIVE="https://arxiv.org/src/2108.05896v3"
HBARC=0.1973269804e-15
MASS_W=80.3692

def source():
    with urllib.request.urlopen(ARCHIVE,timeout=20) as stream:
        blob=stream.read(3000001)
    assert hashlib.sha256(blob).hexdigest()=="26d279c3b0f116ebeb36efaf73f379fb933c50c764de3f133fcc73fe0bc5a685"
    with tarfile.open(fileobj=io.BytesIO(blob)) as container:
        paper=container.extractfile("TimeDelay_v3.tex").read()
    assert hashlib.sha256(paper).hexdigest()=="3b6f28fea9761dae1a4ab2fef2df18dc486a4f55496d7fa74f3c95898cd4f2f7"
    text=paper.decode()
    prefactors=[]
    for sector,pattern in (("Electron",r"i\s*\\frac\{2\s*\\alpha"),("Scalar",r"\\frac\{i\s*\\alpha"),("Vector",r"-\s*\\frac\{3\s*i\s*\\alpha")):
        section=re.split(r"\\subsection\*\{"+sector+r" loops",text)[-1].split(r"\subsection")[0]
        match=re.search(r"(?m)^\\Disc\s+F_3\(t\)\s*=\s*&\s*(.*)$",section)
        assert match and re.match(pattern,match[1])
        simplified="".join(match[1].split())
        assert (r"\left(3t\sqrt{\tau}-2" if sector=="Scalar" else r"\left(-3t\sqrt{\tau}+2") in simplified
        assert r"2m^2+t" in simplified and r"\tanh^{-1}\sqrt{\tau}" in simplified
        prefactors.append({"Electron":2,"Scalar":-1,"Vector":-3}[sector])
    assert [value/prefactors[1] for value in prefactors]==[-2,1,3]
    save("cut-source.json",json.dumps(dict(version=ARCHIVE,archive_sha256=hashlib.sha256(blob).hexdigest(),member="TimeDelay_v3.tex",member_sha256=hashlib.sha256(paper).hexdigest(),equations="Appendix D massive cuts for F3; eqs. 1.11-12; table 3"),indent=2)+"\n")

def partial(beta):
    if beta<.05:
        return sum(beta**(2*idx)*2*idx/((2*idx+1)*(2*idx+3)) for idx in range(1,9))
    return ((3-beta**2)*np.arctanh(beta)-3*beta)/(2*beta**3)

def cut_density(beta):
    return 2*beta**4*partial(beta)

def integrate(momentum):
    return quad(lambda beta:cut_density(beta)*(1-beta**2)/(4+momentum*(1-beta**2)),0,1,epsabs=4.e-15,epsrel=2.e-13)[0]

def moment(order):
    total=Fraction(0)
    for idx in range(order+2):
        harmonic=lambda which:sum(Fraction(1,2*offset+1) for offset in range(which+1))/(2*which+2)
        weight=(-1)**idx*math.comb(order+1,idx)
        total+=weight*(3*harmonic(idx)-harmonic(idx+1)-Fraction(3,2*idx+3))
    return total*Fraction((-1)**order,4**(order+1))

def run():
    guard()
    receipt=json.loads((HERE/"cut-source.json").read_bytes())
    assert receipt["version"]==ARCHIVE
    nodes,weights=roots_legendre(192)
    for beta in (.001,.17,.55,.88,.997):
        angular=np.dot(weights,(3*nodes**2-1)/(1-beta**2*nodes**2))/4
        assert abs(partial(beta)-angular)<2.e-11
    factors={"charged scalar":1,"Dirac":-2,"gauge W":3}
    rows=[]
    for spin,factor in factors.items():
        for degree in range(5):
            exact=factor*moment(degree)
            direct=quad(lambda be:factor*(-1)**degree*cut_density(be)*((1-be**2)/4)**(degree+1),0,1,epsabs=1.e-15)[0]
            assert abs(direct-float(exact))<2.e-12
            rows.append(dict(spin=spin,momentum_power_in_Qsquared=degree,coefficient=str(exact),cut_integral=direct))
    assert moment(0)==Fraction(1,180)
    table("onshell-moments.csv",rows)
    profiles=[]
    for momentum in (0.,.0625,.25,1.,4.,36.):
        for label,factor in factors.items():
            value=factor*integrate(momentum)
            profiles.append(dict(loop=label,Q2_over_m2=momentum,euclidean_matched=value,change_from_zero=value-factor/180))
    table("onshell-form-factor.csv",profiles)
    ledger={row["component_id"]:float(row["coefficient_or_bound_m2"]) for row in read(REGISTER) if row["component_id"] in ("CFF4944_02_W_spin1","CFF4944_01_free_leptons")}
    optical=json.loads((FREE/"signed-transport.json").read_bytes())
    assert optical["lorentz_scalar_times_prefactor"]=="-1/180" and optical["lorentz_spinor_times_prefactor"]=="1/90"
    vector=-float(3*moment(0))*alpha/(4*np.pi)*(HBARC/MASS_W)**2
    old=ledger["CFF4944_02_W_spin1"]
    assert abs(vector/(-old/600)-1)<1.e-7
    subtotal=abs(ledger["CFF4944_01_free_leptons"])+vector
    coefficient=dict(signed_optical_W_m2=vector,old_abs_envelope_m2=old,old_over_magnitude=old/abs(vector),
                     parametric_mass_error_only_m2=abs(vector)*2*.0133/MASS_W,
                     known_leptons_plus_W_m2=subtotal,known_leptons_plus_W_delay_s=subtotal*optical["retained_K_s_per_m2"],
                     W_delay_alone_s=vector*optical["retained_K_s_per_m2"],
                     assumptions="one-loop electromagnetic, unit-charge SM gauge vector; common metric; no arbitrary vector magnetic moment or independent CFF contact",
                     total_QCD_determined=False)
    save("matched-vector.json",json.dumps(coefficient,indent=2)+"\n")

if __name__=="__main__":
    if sys.argv[1:]==["--acquire"]:
        source()
    run()
