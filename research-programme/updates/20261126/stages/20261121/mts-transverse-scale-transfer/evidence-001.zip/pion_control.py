from belle import CHARGE2, MASS, alpha, guard, np, partial, quad, table
from cut import integrate


def hpiece(beta, left, right):
    return quad(lambda z:(3*z*z-1)/2*(1-beta**2)/(1-beta**2*z*z),left,right,epsabs=1.e-13)[0]

def run():
    guard()
    coeff=alpha/(4*np.pi)
    windows=[]
    for name,lower,upper in (("threshold_to_Belle",2*MASS,.8),("Belle",.8,1.5),("above_Belle",1.5,np.inf)):
        begin,end=[np.sqrt(max(0,1-(2*MASS/value)**2)) for value in (lower,upper)]
        row=dict(window=name)
        for tag,left,right in (("central",0.,.6),("outside",.6,1.),("complete",0.,1.)):
            def integrand(beta):
                weight=beta**4/(2*MASS**2)
                if tag=="complete":
                    return weight*(1-beta**2)*partial(beta)
                return weight*hpiece(beta,left,right)
            row[tag+"_Euclidean_GeVminus2"]=coeff*quad(integrand,begin,end,epsabs=2.e-13)[0]
        assert abs(row["central_Euclidean_GeVminus2"]+row["outside_Euclidean_GeVminus2"]-row["complete_Euclidean_GeVminus2"])<2.e-11
        windows.append(row)
    total=sum(row["complete_Euclidean_GeVminus2"] for row in windows)
    assert abs(total-coeff*integrate(0)/MASS**2)<2.e-13
    for row in windows:
        row["fraction_of_all_energy_and_angle_Born"]=row["complete_Euclidean_GeVminus2"]/total
    table("pion-born-coverage.csv",windows)

if __name__=="__main__":
    run()
