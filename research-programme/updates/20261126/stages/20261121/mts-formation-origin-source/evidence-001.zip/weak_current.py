from polar_cartesian import *
from scipy.interpolate import CubicSpline
from numpy.polynomial.legendre import leggauss

def weight(radius,edge,volume):
    x=radius/edge; window=(1-x*x)**6
    slope=-12*radius/edge**2*(1-x*x)**5
    if volume:return radius**2*window,radius**2*slope+2*radius*window
    return window,slope

def readout(rad,coefficients,edge,volume,rule):
    A,B,C,J,oldP=coefficients
    delta=rad[1]-rad[0];n=int(round(edge/delta));assert abs(n*delta-edge)<1e-14
    if rule==0:
        axis=rad[:n];vals=[val[:n] for val in coefficients];wgt=np.full(n,delta)
    else:
        xi,wt=leggauss(rule)
        axis=((np.arange(n)[:,None]+(xi+1)/2)*delta).ravel()
        wgt=np.tile(wt*delta/2,n)
        expanded=np.r_[-rad[7::-1],rad[:n+5]]
        vals=[CubicSpline(expanded,np.r_[val[7::-1],val[:n+5]])(axis) for val in coefficients]
    av,bv,cv,jv,pv=vals
    win,dwin=weight(axis,edge,volume)
    drive=win*cv-((dwin*axis+win)*(av-A[0])+(dwin*axis**3+3*win*axis**2)*(bv-B[0]))/2
    norm=fsum(wgt*win*abs(jv))
    return {key:fsum(wgt*arr)/norm for key,arr in (("cartesian",drive-win*jv),("spherical",win*pv),("current",win*jv))}

def measure(grid,seed,flag):
    rows=[]
    with old.environment(grid),patch.object(carrier,"launch",candidate):
        model=(old.Cold if flag else old.Wave)(seed,"adm")
        r=model.shell.r;s=r**2
        for tick in (0,256,512,768,1024):
            if tick:
                name=f"quarter-g{grid}-s{seed}-off{flag}" if tick==256 else f"extended-g{grid}-s{seed}-off{flag}-t{tick}"
                assert json.loads((HERE/(name+".json")).read_bytes())["sha"]==core.sha(HERE/(name+".npz"))
                with np.load(HERE/(name+".npz")) as data:
                    state=old.Difference(data["shared"],data["signed"]);time=float(data["clock"])
                    J=data["J"];residual=data["ind_P" if tick==256 else "independent"]
            else:
                state=np.zeros_like(model.shell.initial);time=0.
                with patch.object(evolve8,"revise",revised):calc=compute(model,state,time)
                J=calc["J"];residual=calc["ind_P"]
            mapped,aux=model.mass.decode(state)
            _,_,bg,_=model.lift.physical(mapped,time)
            h,p=geometric(model,mapped,aux,time)
            m=np.expm1(2*(bg["ell"]-bg["bend"]))/s;kt=-aux["kb"];dk=(aux["kb"]-aux["ka"])/s
            M=mixed(h,p,s,m,kt,dk)
            C=angular(h,M,s,m,(bg["eg"]-bg["bg"])/r,bg["bg"]/(2*r),dk,0.,0.)
            coeff=[M[0].delta,M[1].delta,C.delta,J,residual]
            for edge in (.025,.05,.1,.3):
                for volume in (False,True):
                    for rule in (0,8,16):
                        result=readout(r,coeff,edge,volume,rule)
                        rows.append(dict(grid=grid,seed=seed,flag=flag,tick=tick,edge=edge,volume=volume,order=rule,**result))
    return rows

def known():
    rows=[]
    for grid in (320,640):
        r=(np.arange(grid)+.5)/grid;s=r**2
        A=.4+.23*s-.07*s**2;B=.11-.03*s+.1*s**2;C=s*(.02+.05*s)
        actual=s*(.23-.14*s)+s**2*(-.03+.2*s)+C
        for edge in (.025,.05,.1,.3):
            for volume in (False,True):
                for ratio in (1.,.7):
                    J=ratio*actual;err=actual-J
                    val=readout(r,(A,B,C,J,err),edge,volume,16)
                    expected=(1-ratio)/ratio
                    rows.append(dict(grid=grid,edge=edge,volume=volume,ratio=ratio,measured=val["cartesian"],error=abs(val["cartesian"]-expected)))
    assert max(row["error"] for row in rows)<2e-6
    table("weak-manufactured.csv",rows)

if __name__=="__main__":
    if sys.argv[1:]==["test"]:known()
    else:
        grid,seed,flag=map(int,sys.argv[1:])
        table(f"weak-angular-g{grid}-s{seed}-off{flag}.csv",measure(grid,seed,flag))
