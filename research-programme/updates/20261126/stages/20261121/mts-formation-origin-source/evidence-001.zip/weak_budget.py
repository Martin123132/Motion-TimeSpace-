from compare_formation import *
from scipy.interpolate import BarycentricInterpolator

def moments(sim,state,time,quadrature=32):
    mesh=sim.mesh
    nodes,weights=leggauss(quadrature);radius=mesh.h*(nodes+1)/2;weights*=mesh.h/2
    operator=BarycentricInterpolator(mesh.loc[0],np.eye(mesh.order+1),rng=0)
    at=operator(radius);slope=operator.derivative(radius)
    inside=[sim.mesh.grid(field)[...,mesh.elem[0]] for field in state]
    mono=inside[0]@at.T;dx=inside[0]@slope.T
    C=mono[0]/radius;vel=(dx[1]-mono[1]/radius)/radius
    D,psi=[field@at.T for field in inside[1:]]
    pgrad=inside[2]@slope.T
    bg=sim.ref.solution(time)*sim.ref.weight
    base,dr,_=sim.operators(radius);Dn=bg[0]@base;Pn=bg[1]@base;Pr=bg[1]@dr
    flux=(1+C)*pgrad+vel*D+C*Pr+vel*Dn
    tangent=(1+C)*psi+C*Pn
    return ((2*radius**3*flux)@weights,(6*radius**2*tangent)@weights)

def test():
    lock();rows=[];epochs=(0,7,36)
    for rate in (4,5):
        sim=carrier.prior.sphere(144,rate);op=FirstElement(sim);h=op.h
        for seed in (1,-1):
            for panel in epochs:
                if panel:
                    with np.load(HERE/f"formation-h{rate}-s{seed}-p{panel}.npz") as data:
                        state=tuple(data[key] for key in ("mono","density","velocity"))
                else:state=op.project(labels(sim,seed))
                now=TIMES[panel]
                hub,_=sim.patch.coeff(now)
                slope=op.rates(state,now)
                coef=slope[1][...,:op.count]@op.extract.T
                inner=sum(coef[...,idx]*h**5/(7+2*idx) for idx in range(3))
                overlap=slope[1][...,op.count-1]*h**2*sim.mesh.radw[1,0]
                test_lhs=(inner+overlap)*hub
                rad,ang=moments(sim,state,now)
                interface=h**2*op.from_neighbor(state,now)
                rhs=rad+ang+interface
                old_mono=sim.rates(state,now)[0][...,:op.count]
                new_mono=slope[0][...,:op.count]
                weight=sim.mesh.lump[:op.count]*sim.mesh.loc[0,1:]
                mono_error=np.max(abs((new_mono-old_mono)@weight))/(np.max(abs(old_mono)@weight) or 1.)
                for flag in (0,1):
                    for idx in range(3):
                        key=flag,idx
                        norm=abs(rad[key])+abs(ang[key])+abs(interface[key])
                        assert norm>0.
                        err=abs(test_lhs[key]-rhs[key])/norm
                        rows.append(dict(rate=rate,seed=seed,panel=panel,flag=flag,species=idx,
                                   integrated_rate=test_lhs[key],radial_flux=rad[key],angular_flux=ang[key],neighbor=interface[key],
                                   relative_error=err,omit_polar_error=abs(test_lhs[key]-(rad[key]+interface[key]))/norm,
                                   monopole_change_of_mass_moment=mono_error))
                        assert err<1e-8 and mono_error<1e-12,(key,err,mono_error)
    table("explicit-flux-work.csv",rows)
    print("independent moment",max(row["relative_error"] for row in rows))
if __name__=="__main__":test()
