from scope_src import *

def independent(obj):
    all_fields=obj.m
    u0,du=obj.grid.evaluate(obj.f0)
    quad,dquad=obj.grid.evaluate(obj.f2)
    u=1+u0
    monopole=obj.fq.get("clock_e0",0.)
    sectors={}
    for number,rho in enumerate(obj.rh):
        n,grad,speed,D,Dr,P=[all_fields[key][number] for key in ("n","g","p","D","Dr","P")]
        if obj.canonical and number==obj.j:
            G=grad/n-6*du/u
            dG=Dr/n-grad*D/n**2-6*dquad/u+6*du*quad/u**2
            w=(speed**2+obj.eps*G**2)/(2*u**4)
            dw=(speed*P+obj.eps*G*dG)/u**4-4*w*quad/u
        else:
            gamma=np.sqrt(1+speed**2/u**4)
            w=speed**2/(u**4*(1+gamma))
            dw=(speed*P-2*speed**2*quad/u)/(gamma*u**4)
        monopole=monopole+rho*((n-1+n*w)*np.exp(-6*np.log1p(u0))+np.expm1(-6*np.log1p(u0)))
        sectors[f"number{number}"]=rho*D/(4*u)
        sectors[f"kinetic{number}"]=rho*(D*w+n*dw)/(4*u)
        sectors[f"volume{number}"]=-6*rho*n*(1+w)*quad/(4*u**2)
    sectors["conformal_prefactor"]=5*u**4*quad*monopole/4
    env=obj.fq["other"] if obj.clock is None else obj.clock.original_other
    sectors["surrounding"]=u**5*env/4
    sectors["normal_graph"]=(obj.fq["other"]-env)*u**5/4
    sectors["extrinsic"]=3*obj.b0*obj.b2/(8*u**7)-21*obj.b0**2*quad/(16*u**8)
    return sectors

def run():
    lock()
    sim=carrier.prior.sphere(144,5);green=carrier.prior.load_integrator()
    sources={};predictions={};rows=[];replay=[]
    for seed in (0,1,-1):
        state=carrier.prior.start_state(sim,144,5,seed)
        for flag in (0,1):
            guard()
            bg,press,_=family.pressure(flag)
            grid,shapes,inputs0=inputs(sim,state,144,5,flag,bg,press)
            green.attach(grid,32)
            with patch.object(family,"ResolvingSlice",green.Slice):
                result,obj=prepare(sim,state,grid,shapes,inputs0,bg,press,1024,flag)
            bank,source,_=carrier.launch(1024,flag,seed)
            with np.load(bank) as saved:
                assert set(result)==set(saved.files)
                for name in result:np.testing.assert_array_equal(result[name],saved[name],err_msg=name)
            with np.load(source) as data:
                target=data["src"][1]
            np.testing.assert_array_equal(target,obj.hsource(2,*grid.evaluate(obj.f2)))
            pieces=independent(obj)
            discrepancy=float(np.max(abs(sum(pieces.values())-target))/np.max(abs(target)))
            assert discrepancy<2e-14,discrepancy
            inputs_direct=sim.mesh.grid(state[1])[flag][:,sim.mesh.elem[0]]
            density_slope=slope(sim.mesh.loc[0],inputs_direct)*obj.rh/4
            predictions[seed,flag]=density_slope
            sources[seed,flag]={key:arr[0].copy() for key,arr in pieces.items()}
            replay.append(dict(seed=seed,flag=flag,bank=core.sha(bank),source=core.sha(source),source_points=target.size,
                packet_fields=len(result),analytic_error_over_peak=discrepancy))
            print("replayed",seed,flag,discrepancy,flush=True)
    for seed in (1,-1):
        for flag in (0,1):
            base=sources[0,flag]
            parts={key:float(slope(grid.points[0],arr-base[key])) for key,arr in sources[seed,flag].items()}
            ref=coefficients(flag,seed)[0][1,1]-coefficients(flag,0)[0][1,1]
            for key,value in parts.items():rows.append(dict(seed=seed,flag=flag,sector=key,linear=value,total=ref,fraction=value/ref))
            direct=sum(predictions[seed,flag])
            rows.append(dict(seed=seed,flag=flag,sector="formation_number_forecast",linear=direct,total=ref,fraction=direct/ref))
            assert abs(sum(parts.values())/ref-1)<1e-7 and abs(direct/ref-1)<1e-7
    table("preparation-replay.csv",replay);table("source-sectors.csv",rows)

if __name__=="__main__":run()
