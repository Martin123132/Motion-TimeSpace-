from later_clock import late_lock
from scope_src import *

def grade():
    seal=late_lock();metric=[];momentum=[];cov=[]
    forecasts={(int(row["seed"]),float(row["width"]),float(row["fraction"])):row for row in core.read(HERE/"matched-gravity-prediction.csv")}
    orig=LAST.parent/"mts-polar-momentum-transport-20261121"
    for grid,seed in ((320,1),(640,1),(640,-1)):
        clockseries={}
        for flag in (0,1):
            allgeo=core.read(HERE/f"cartesian-momentum-g{grid}-s{seed}-off{flag}.csv")
            allweak=core.read(HERE/f"weak-angular-g{grid}-s{seed}-off{flag}.csv")
            assert len(allgeo)==45 and len(allweak)==120
            for tick in (256,512,768,1024):
                path=HERE/(f"quarter-g{grid}-s{seed}-off{flag}" if tick==256 else f"extended-g{grid}-s{seed}-off{flag}-t{tick}")
                cert=json.loads(path.with_suffix(".json").read_bytes())
                assert core.sha(path.with_suffix(".npz"))==cert["sha"] and cert["tick"]==tick
                if tick==256:
                    tides={row["width"]+"-"+row["channel"]:float(row["new"]) for row in core.read(HERE/(path.name+"-tides.csv"))}
                else:
                    assert cert["freeze"]==seal
                    tides=cert["tides"]
                old=orig/f"split{grid}-s{seed}-off{flag}-t{tick}"
                before=json.loads(old.with_suffix(".json").read_bytes());assert core.sha(old.with_suffix(".npz"))==before["sha"]
                clockseries[flag,tick]=tides,before["tide"]
                with np.load(path.with_suffix(".npz")) as saved,np.load(old.with_suffix(".npz")) as native:
                    r=(np.arange(saved["J"].size)+.5)/grid;den=saved["J"]
                    for region,mask in (("first",r<1/grid),("core",r<.3),("bulk",(r>.6)&(r<2.1))):
                        for channel,old_key,new_key in (("independent","ind_P","ind_P" if tick==256 else "independent"),("native","P","P" if tick==256 else "native")):
                            norm=np.linalg.norm
                            old_err=norm(native[old_key][mask])/norm(native["J"][mask]);new_err=norm(saved[new_key][mask])/norm(den[mask])
                            momentum.append(dict(grid=grid,seed=seed,flag=flag,tick=tick,region=region,channel=channel,original=old_err,changed=new_err,improvement=old_err/new_err))
                for edge in (.025,.05,.1,.3):
                    chosen=[row for row in allweak if int(row["tick"])==tick and float(row["edge"])==edge and row["volume"]=="True"]
                    assert len(chosen)==3
                    low,mid,high=sorted(chosen,key=lambda row:int(row["order"]))
                    cov.append(dict(grid=grid,seed=seed,flag=flag,tick=tick,edge=edge,weak_actual=high["cartesian"],weak_old_reader=high["spherical"],
                           quad_spread=abs(float(mid["cartesian"])-float(high["cartesian"])),
                           midpoint_spread=abs(float(low["cartesian"])-float(high["cartesian"]))))
        for tick in (256,512,768,1024):
            for width in (.15,.3):
                ref=forecasts[seed,width,tick/1024]
                for channel in ("gauss","ricci"):
                    key=str(width)+"-"+channel
                    old=clockseries[0,tick][1][key]-clockseries[1,tick][1][key]
                    new=clockseries[0,tick][0][key]-clockseries[1,tick][0][key]
                    unit=1e-6*abs(float(ref["matched_newton"]))
                    error=(new-float(ref["matched"]))/unit
                    metric.append(dict(grid=grid,seed=seed,tick=tick,width=width,channel=channel,old=old,new=new,
                             prediction=ref["matched"],matched_newton=ref["matched_newton"],matched_tt=ref["matched_tt"],residual_ppm=error,
                             old_error_ppm=(old-float(ref["native"]))/(abs(float(ref["native_newton"]))*1e-6),
                             newton_only_ppm=(new-float(ref["matched_newton"]))/unit,inside=abs(error)<=20))
    assert len(metric)==48 and len(momentum)==144 and len(cov)==96
    table("proper-tides-full.csv",metric);table("physical-momentum-full.csv",momentum);table("integrated-current-full.csv",cov)
    for grid in (320,640):
        for tick in (256,512,768,1024):
            group=[row for row in metric if row["grid"]==grid and row["tick"]==tick]
            print(grid,tick,sum(row["inside"] for row in group),len(group),max(abs(row["residual_ppm"]) for row in group))
if __name__=="__main__":grade()
