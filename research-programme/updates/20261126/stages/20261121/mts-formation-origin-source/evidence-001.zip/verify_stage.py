from scope_src import *
from formation_trial import TIMES
from later_clock import late_lock
import ast

def main():
    seal=late_lock();arrays=0;rows=0;sizes={}
    digests={};count_clocks=0
    for path in sorted(HERE.iterdir()):
        if path.name=="seal.json":continue
        assert path.is_file() and path.suffix in (".py",".json",".npz",".csv",".md"),path
        digests[path.name]=core.sha(path)
        if path.suffix==".py":compile(path.read_text(encoding="utf-8"),str(path),"exec")
        if path.suffix==".json":
            with path.open(encoding="utf-8") as reader:obj=json.load(reader)
            if path.stem.startswith("extended-g"):
                assert obj["freeze"]==seal and obj["sha"]==core.sha(path.with_suffix(".npz"))
                assert obj["tick"] in (512,768,1024)
                count_clocks+=1
        if path.suffix==".npz":
            with np.load(path,allow_pickle=False) as bank:
                for key in bank.files:
                    assert np.isfinite(bank[key]).all(),(path,key)
                    arrays+=1
        if path.suffix==".csv":
            data=core.read(path);assert data and all(None not in row and None not in row.values() for row in data)
            sizes[path.name]=len(data);rows+=len(data)
    for name,count in (("source-sectors.csv",56),("preparation-replay.csv",6),("regular-continuity-rate.csv",144),
                        ("explicit-flux-work.csv",72),("formed-source-h5.csv",56),("weak-manufactured.csv",32),
                        ("cartesian-divergence-control.csv",4),("matched-gravity-prediction.csv",16),("proper-tides-full.csv",48),
                        ("physical-momentum-full.csv",144),("integrated-current-full.csv",96)):
        assert sizes[name]==count,(name,sizes[name],count)
    for res in (4,5):
        for seed in (1,-1):
            name=f"formation-h{res}-s{seed}"
            cert=json.loads((HERE/(name+"-finished.json")).read_bytes())
            assert cert["sha"]==core.sha(HERE/(name+"-p36.npz")) and cert["tick"]==1429 and cert["clock"]==float(TIMES[-1])
    assert count_clocks==18 and all(name in digests for name in ("DERIVATION.md","RESULTS.md","CURRENT-READOUT.md"))
    with patch.object(local,"HERE",HERE):local.manifest("seal.json",dict(previous=core.sha(LAST/"seal.json"),runs=18+6,
               arrays=arrays,csv_rows=rows,counts=sizes,files=digests))
    print(core.sha(HERE/"seal.json"),len(digests),rows,arrays)
if __name__=="__main__":main()
