from scope_src import *

def direct(sim,r,seed):
    p=sim.patch;k=p.k
    mono=p.p.chart.fourier(0.)*p.p.chart.selectors[0]*seed
    ns=p.count
    dspec,pspec=(sim.ref.solution(0.)*sim.ref.weight)
    dens=mono[:ns];pot=mono[ns:2*ns]
    array=np.outer(k,r)
    j0=spherical_jn(0,array);dr0=spherical_jn(0,array,derivative=True)*k[:,None]
    j2=spherical_jn(2,array);dr2=spherical_jn(2,array,derivative=True)*k[:,None]
    host=dens@j0;grad=dens@dr0;velocity=pot@dr0
    d=dspec@j2;v=pspec@j2
    dv=pspec@dr2;dd=dspec@dr2
    hub,_=p.coeff(0.)
    rate=(host*((pspec*k**2)@j2)-grad*dv-velocity*dd+((pot*k**2)@j0)*d)/hub
    return rate,(host*dv+velocity*d)/hub,host*v/hub

def centre_limit(sim,seed):
    p=sim.patch;k=p.k;ns=p.count;hub,_=p.coeff(0.)
    mono=p.p.chart.fourier(0.)*p.p.chart.selectors[0]*seed
    dspec,pspec=sim.ref.solution(0.)*sim.ref.weight
    C0=mono[:ns].sum(axis=-1);C2=-(mono[:ns]@(k**2))/6;v1=-(mono[ns:2*ns]@(k**2))/3
    d2=dspec@(k**2)/15;p2=pspec@(k**2)/15;p4=-(pspec@(k**4))/210
    return -(14*C0*p4+4*C2*p2+5*v1*d2)/hub

def exact_weak_samples(sim,seed):
    m=sim.mesh;coords=m.loc[:2].ravel();_,flux,angular=direct(sim,coords,seed)
    currents=flux.reshape(*flux.shape[:-1],2,-1);angles=angular.reshape(*angular.shape[:-1],2,-1)
    load=(m.radw[:2]*currents)@m.der+6*m.qw*angles
    vals=load[...,0,1:].copy();vals[...,-1]+=load[...,1,0]
    return vals/m.m[:m.order]

def bounded(rate):
    return float(np.max(abs(rate)))

def run(sim,resolution):
    mesh=sim.mesh;r=mesh.loc[0]
    rows=[]
    for seed in (1,-1):
        state=sim.init();state=(seed*state[0],*state[1:])
        raw=sim.rates(state,0.)[1][...,:mesh.order]
        strong=direct(sim,r,seed)[0]
        weak=exact_weak_samples(sim,seed)
        ref=centre_limit(sim,seed)
        exact0=direct(sim,np.array([mesh.h/5000]),seed)[0][...,0]/(mesh.h/5000)**2
        np.testing.assert_allclose(exact0,ref,rtol=1e-8,atol=1e-17)
        shape=lambda arr:np.concatenate((np.zeros_like(arr[...,:1]),arr),axis=-1)
        slopes=[slope(r,value) for value in (shape(raw),shape(weak),strong)]
        rows.extend(dict(resolution=resolution,seed=seed,flag=flag,species=idx,
                raw_linear=slopes[0][flag,idx],exact_flux_lumped_linear=slopes[1][flag,idx],
                sampled_continuum_linear=slopes[2][flag,idx],continuum_linear=0.,
                centre_rate_r2=ref[flag,idx],first_cell_raw_relative=raw[flag,idx,0]/strong[flag,idx,1]-1,
                first_cell_exact_flux_lumped_relative=weak[flag,idx,0]/strong[flag,idx,1]-1)
                for flag in (0,1) for idx in range(3))
    return rows

def endpoint_test():
    lock();rows=[];saved=[]
    for res in (4,5,8,10):
        sim=carrier.prior.sphere(144,res)
        rows+=run(sim,res)
        if res not in (4,5):continue
        for edge in (120,144):
            for seed in (1,-1):
                with np.load(formation(edge,res,seed)) as bank:
                    assert np.isclose(bank["x"][-1],family.SPAN*family.DLOG,rtol=1e-15,atol=0)
                    data=bank["density"][...,:sim.mesh.order]
                    values=np.concatenate([0*data[...,:1],data],axis=-1)
                    linear=slope(sim.mesh.loc[0],values)
                    for flag in (0,1):
                        for idx in range(3):
                            saved.append(dict(resolution=res,edge=edge,seed=seed,flag=flag,species=idx,
                                              linear=linear[flag,idx],first=values[flag,idx,1]))
    table("first-rate-controls.csv",rows);table("formation-endpoints.csv",saved)
    for row in rows:
        if row["seed"]==1 and row["flag"]==1 and row["species"]==0:print(row,flush=True)

if __name__=="__main__":endpoint_test()
