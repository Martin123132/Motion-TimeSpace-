import os
import sys
from pathlib import Path
from contextlib import contextmanager
from functools import lru_cache
import json
HERE=Path(__file__).resolve().parent
LAST=HERE.parent/"mts-cartesian-origin-transport-20261121"
sys.path.insert(0,str(LAST))
from base_origin import lock as previous_lock,guard as previous_guard,patch,core,local,np
from green_origin import coefficients
import local_case as carrier
from local_stage import formation
from launch_data import inputs,prepare,family
from numpy.polynomial.legendre import leggauss
from scipy.special import spherical_jn
from scipy.interpolate import BarycentricInterpolator
from math import fsum
from time import perf_counter

def guard():
    previous_guard()
    if (HERE/"STOP-REQUESTED").exists():raise RuntimeError("owner hold")

def lock():
    guard()
    seal=LAST/"seal.json"
    assert core.sha(seal)=="e9ae2706a83201fa13ffc300b4369567f8ae6a6babdef0450f12f1b32307a540"
    for name,digest in json.loads(seal.read_bytes())["files"].items():assert core.sha(LAST/name)==digest,name
    previous_lock()

def table(name,rows):
    guard()
    with patch.object(local,"HERE",HERE):local.table(name,rows)

def manifest(name,fields):
    guard()
    with patch.object(local,"HERE",HERE):local.manifest(name,fields)

def packet(name,**fields):
    guard()
    with patch.object(local,"HERE",HERE):local.packet(name,**fields)

def slope(nodes,values):
    op=BarycentricInterpolator(nodes,np.eye(len(nodes)),rng=0).derivative(0.)
    return np.asarray(values)@op
