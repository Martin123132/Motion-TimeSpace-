from aperture_trial import scores
from compare_formation import *
import ast

def gather():
    from aperture_trial import frozen
    frozen()
    cert=json.loads((HERE/"matched-forecast.json").read_bytes())
    assert cert["forecasts"]==core.sha(HERE/"matched-gravity-prediction.csv")
    scores();fore={ (int(row["seed"]),float(row["width"])):row for row in core.read(HERE/"matched-gravity-prediction.csv") if float(row["fraction"])==.25}
    rows=[];stats={}
    for obs in core.read(HERE/"quarter-aperture-comparison.csv"):
        ref=fore[int(obs["seed"]),float(obs["width"])]
        error=(float(obs["new"])-float(ref["matched"]))/(abs(float(ref["matched_newton"]))*1e-6)
        rows.append(dict(grid=obs["grid"],seed=obs["seed"],width=obs["width"],channel=obs["channel"],
                         measured=obs["new"],matched=ref["matched"],matched_newton=ref["matched_newton"],
                         matched_tt=ref["matched_tt"],matched_ppm=error,passes=abs(error)<=20,old_ppm=obs["old_ppm"]))
    table("matched-apertures.csv",rows)
    stats["apertures"]={g:[sum(row["passes"] for row in rows if row["grid"]==g),sum(row["grid"]==g for row in rows),
                            max(abs(row["matched_ppm"]) for row in rows if row["grid"]==g)] for g in ("320","640")}
    core_rows=[];previous=core.read(LAST/"saved-origin-coefficients.csv")
    for grid,seed in ((320,1),(640,1),(640,-1)):
        for flag in (0,1):
            name=f"quarter-g{grid}-s{seed}-off{flag}"
            path=HERE/(name+".npz")
            assert json.loads((HERE/(name+".json")).read_bytes())["sha"]==core.sha(path)
            with np.load(path) as saved:
                for field,archive in (("metric","hd"),("extrinsic","pd")):
                    old=next(row for row in previous if (row["grid"],row["seed"],row["flag"],row["sector"],row["coef"],row["tick"])==(str(grid),str(seed),str(flag),field,"d","256"))
                    for cell in (0,1,7):
                        prior=float(old[f"cell{cell}"])
                        now=saved[archive][cell]
                        core_rows.append(dict(grid=grid,seed=seed,flag=flag,field=field,cell=cell,old=prior,new=now,new_over_old=now/prior))
    table("quarter-central-geometry.csv",core_rows)
    def read(file):return core.read(HERE/file)
    def bounds(data):return [float(min(data)),float(max(data))]
    regular=[x for x in read("regular-continuity-rate.csv") if x["resolution"]=="5" and x["seed"]!="0" and x["order"]=="20"]
    stats["raw_first_err"]=bounds([abs(float(row["raw_relative"])) for row in regular])
    stats["fixed_first_err"]=bounds([abs(float(row["repaired_relative"])) for row in regular])
    stats["fixed_centre_coeff_err"]=bounds([abs(float(row["r2_relative"])) for row in regular])
    checks=read("first-rate-controls.csv")
    stats["analytic_flux_replaced_over_old_slope"]=bounds([float(row["exact_flux_lumped_linear"])/float(row["raw_linear"]) for row in checks if row["resolution"]=="5"])
    stats["max_rel_source_decomp"]=max(float(row["analytic_error_over_peak"]) for row in read("preparation-replay.csv"))
    stats["source_linear_total_err"]=max(abs(float(row["fraction"])-1) for row in read("source-sectors.csv") if row["sector"]=="formation_number_forecast")
    stats["moment_residual"]=max(float(row["relative_error"]) for row in read("explicit-flux-work.csv"))
    stats["omit_polar"]=bounds([float(row["omit_polar_error"]) for row in read("explicit-flux-work.csv")])
    stats["mass_projection"]=max(float(row["monopole_change_of_mass_moment"]) for row in read("explicit-flux-work.csv"))
    def by_keys(data,fields):return {tuple(x[key] for key in fields):x for x in data}
    fields=("seed","flag","radius","tag")
    high,low=(by_keys(read(f"formed-source-h{g}.csv"),fields) for g in (5,4))
    stats["after_source_slope"]=bounds([abs(float(x["signed_linear"])) for x in high.values() if x["tag"]=="regular"])
    for tag in ("regular","native"):
        idx=[k for k,x in high.items() if x["radius"]=="0.00078125" and x["tag"]==tag]
        stats[tag+"_r2_mesh_change"]=bounds([abs(float(high[k]["signed_quadratic"])/float(low[k]["signed_quadratic"])-1) for k in idx])
    centers=[row for row in high.values() if row["radius"]=="0.00078125" and row["tag"]=="regular"]
    stats["curvature_reduction"]=bounds([abs(float(high[row["seed"],row["flag"],row["radius"],"native"]["signed_Rd"])/float(row["signed_Rd"])) for row in centers])
    stats["node_change_by_region"]={zone:max(float(row["relative_2norm"]) for row in read("formed-nodes-h5.csv") if row["part"]==zone) for zone in ("origin","neighbours","bulk")}
    acceleration=by_keys(read("formed-acceleration-h5.csv"),("seed","flag","radius","channel","tag"))
    stats["max_relative_force_change"]={key:max(abs(float(row["value"])/float(acceleration[row["seed"],row["flag"],row["radius"],key,"native"]["value"])-1)
        for row in acceleration.values() if row["tag"]=="regular" and row["channel"]==key) for key in ("host_radial","radial","polar")}
    mom=[row for pth in HERE.glob("quarter-g640-*-momentum.csv") for row in core.read(pth)]
    stats["independent_centre_old"]=bounds([float(row["old_relative"]) for row in mom if row["channel"]=="ind_P" and row["region"]=="cell0"])
    stats["independent_centre_new"]=bounds([float(row["new_relative"]) for row in mom if row["channel"]=="ind_P" and row["region"]=="cell0"])
    stats["independent_centre_improvement"]=bounds([float(row["old_relative"])/float(row["new_relative"]) for row in mom if row["channel"]=="ind_P" and row["region"]=="cell0"])
    stats["previous_forecast_move"]=bounds([float(row["combined_shift_ppm"]) for row in fore.values()])
    assert len(rows)==12 and len(core_rows)==36
    manifest("measurements.json",stats)
    print(json.dumps(stats,indent=1))
if __name__=="__main__":gather()
