from scope_src import *
import base_origin as old
from chart_origin import geometric
from polar_balance import compute
from mass_scope import read_tide
from saved_centre import signed
from split_curvature import revised,evolve8

NATIVE=carrier.launch

def candidate(level,flag,seed):
    if not seed:return NATIVE(level,flag,seed)
    assert level==1024
    base=f"prepared-s{seed}-off{flag}"
    bank=HERE/(base+".npz");rhs=HERE/(base+"-rhs.npz")
    cert=json.loads((HERE/(base+".json")).read_bytes())
    assert core.sha(bank)==cert["bank"] and core.sha(rhs)==cert["rhs"]
    return bank,rhs,(0.,cert["bc"])

def freeze():
    lock()
    manifest("aperture-freeze.json",dict(files={name:core.sha(HERE/name) for name in
             ("aperture_trial.py","formed-source-h5.csv","formation-freeze.json","scope_src.py",*(f"prepared-s{seed}-off{flag}.json" for seed in (1,-1) for flag in (0,1)))},
             forecasts=core.sha(local.PREVIOUS/"predicted-gravity.csv"),steps_in_quarter=256,
             grids=[320,640],checks="Re-evolve each prepared positive host on both grids and negative host on the fine grid. Reuse the original split-curvature equations and surrounding bank; compare against the original signed Newton/incoming stress forecast as a sensitivity control, not a new matched prediction. Retain native and independent centre momentum and the unchanged 20 ppm reference band. No masking central cells."))

def frozen():
    lock()
    meta=json.loads((HERE/"aperture-freeze.json").read_bytes())
    assert all(core.sha(HERE/key)==val for key,val in meta["files"].items())
    assert core.sha(local.PREVIOUS/"predicted-gravity.csv")==meta["forecasts"]
    return core.sha(HERE/"aperture-freeze.json")

def trial(grid,seed,flag):
    seal=frozen();name=f"quarter-g{grid}-s{seed}-off{flag}"
    prior=old.PREVIOUS/f"split{grid}-s{seed}-off{flag}-t256.npz"
    cert=json.loads(prior.with_suffix(".json").read_bytes())
    assert core.sha(prior)==cert["sha"]
    with old.environment(grid),patch.object(carrier,"launch",candidate),patch.object(evolve8,"revise",revised):
        model=(old.Cold if flag else old.Wave)(seed,"adm")
        state=np.zeros_like(model.shell.initial)
        step=4096*np.pi/(model.shell.mu*1024)
        advance=model.time_step(step);start=perf_counter()
        def data(state,clock):
            mapped,aux=model.mass.decode(state);raw,geo,bg,_=model.lift.physical(mapped,clock)
            physical=raw if flag else model.to_wave(raw)
            h,p=geometric(model,mapped,aux,clock)
            return read_tide(model,clock,physical),signed(h[3]),signed(p[3])
        launch,h0,p0=data(state,0.)
        for tick in range(1,257):
            if tick%8==1:guard()
            state=advance((tick-1)*step,state)
            if tick%64==0:print(name,tick,round(perf_counter()-start,1),flush=True)
        clock=step*256
        assert np.all(np.isfinite(state.base)) and np.all(np.isfinite(state.delta)) and model.mass.min_branch>0
        if not flag:assert model.min_number>0 and model.min_factor>0
        metrics,hd,pd=data(state,clock);diagnose=compute(model,state,clock)
        rows=[];norm=np.linalg.norm;r=model.shell.r
        with np.load(prior) as bank:
            for channel in ("ind_P","P"):
                for region,mask in (("cell0",r<1/grid),("core",r<.3),("bulk",(r>.6)&(r<2.1))):
                    row=dict(grid=grid,seed=seed,flag=flag,channel=channel,region=region)
                    for tag,which in (("old",bank),("new",diagnose)):
                        defect=which[channel][mask];current=which["J"][mask]
                        row[tag+"_defect_norm"]=norm(defect);row[tag+"_current_norm"]=norm(current)
                        row[tag+"_relative"]=norm(defect)/norm(current)
                    rows.append(row)
        table(name+"-momentum.csv",rows)
        entries=[]
        for (width,channel),value in metrics.items():
            entries.append(dict(grid=grid,seed=seed,flag=flag,width=width,channel=channel,
                  launch=launch[width,channel],new=value,old=cert["tide"][str(width)+"-"+channel]))
        table(name+"-tides.csv",entries)
        packet(name+".npz",shared=state.base,signed=state.delta,h0=h0,p0=p0,hd=hd,pd=pd,
               J=diagnose["J"],P=diagnose["P"],ind_P=diagnose["ind_P"],clock=clock)
        manifest(name+".json",dict(freeze=seal,min_branch=model.mass.min_branch,sha=core.sha(HERE/(name+".npz")),tick=256))
def scores():
    frozen();rows=[]
    for grid,seed in ((320,1),(640,1),(640,-1)):
        bands={(float(row["width"]),row["mode"]):row for row in core.read(local.PREVIOUS/"predicted-gravity.csv") if int(row["seed"])==seed and float(row["fraction"])==.25}
        banks=[core.read(HERE/f"quarter-g{grid}-s{seed}-off{flag}-tides.csv") for flag in (0,1)]
        for wave,cold in zip(*banks):
            width=float(wave["width"]);channel=wave["channel"];band=bands[width,"flrw-live"]
            assert cold["width"]==wave["width"] and cold["channel"]==channel
            new=float(wave["new"])-float(cold["new"]);prior=float(wave["old"])-float(cold["old"])
            unit=1e-6*abs(float(band["newton"]));pred=float(band["prediction"])
            rows.append(dict(grid=grid,seed=seed,width=width,channel=channel,old=prior,new=new,
                       original_prediction=pred,original_newton=band["newton"],old_ppm=(prior-pred)/unit,
                       new_ppm=(new-pred)/unit,shift_ppm=(new-prior)/unit,inside_original=abs(new-pred)<=20*unit))
    table("quarter-aperture-comparison.csv",rows)
if __name__=="__main__":
    if sys.argv[1:]==["freeze"]:freeze()
    elif sys.argv[1:]==["score"]:scores()
    else:trial(*map(int,sys.argv[1:]))
