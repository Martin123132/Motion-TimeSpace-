from compare_formation import load_state,FirstElement
from scope_src import *
from contextlib import ExitStack
from copy import copy
import detector
import material_history as mechanical
import driven_wave as driven
from numpy.polynomial.legendre import legvander
from aperture_trial import frozen
NATIVE=detector.family.BalancedNative

def regular_sim(*args,**kwargs):
    sim=NATIVE(*args,**kwargs)
    base=copy(sim)
    sim.rates=FirstElement(base).rates
    return sim

def start(sim,edge,rate,seed):
    assert (edge,rate)==(144,5)
    return load_state(rate,seed) if seed else tuple(np.zeros_like(arr) for arr in sim.init())

@contextmanager
def route():
    with ExitStack() as stack:
        for module in (detector,mechanical,mechanical.tensor):
            stack.enter_context(patch.object(module,"start_state",start))
        stack.enter_context(patch.object(family,"BalancedNative",regular_sim))
        stack.enter_context(patch.object(mechanical,"packet",lambda name,**kw:packet("matched-"+name,**kw)))
        stack.enter_context(patch.object(mechanical,"table",lambda name,rows:table("matched-"+name,rows)))
        yield

def contrasts(members):
    return {(seed,width,frac):((members[seed,0,frac,width]-members[0,0,frac,width])-
                     (members[seed,1,frac,width]-members[0,1,frac,width]))[0]
            for seed in (1,-1) for width in (.15,.3) for frac in (.25,.5,.75,1.)}

def stress(path,op):
    with np.load(path) as bank:
        axes=[bank[key] for key in ("xi","b","hubble","expansion")]
        nodes=bank["local_nodes"];loc=op.x/float(bank["spacing"]);cells=loc.astype(int)
        basis=legvander(2*(loc-cells)-1,len(nodes)-1)
        inverse=np.linalg.inv(legvander(2*nodes-1,len(nodes)-1))
        field=np.array([op.spectrum(np.einsum("ijk,ijk->ij",basis,(raw@inverse.T)[cells])) for raw in bank["radial"]])
    return {(width,frac):result for width in (.15,.3) for frac,result in driven.advance(op,"flrw-live",1024,*axes,field,width)}

def run():
    frozen()
    previous={(int(row["seed"]),float(row["width"]),float(row["fraction"])):row for row in core.read(local.PREVIOUS/"predicted-gravity.csv") if row["mode"]=="flrw-live"}
    op=driven.RadialSpectrum(160,12)
    old_n=contrasts(detector.evolve(32))
    print("native Newton replay",flush=True)
    with route():
        guard();new_n=contrasts(detector.evolve(32));print("regular Newton",flush=True)
        guard();mechanical.history(32)
    rows=[]
    for seed in (1,-1):
        guard();old_stress=stress(mechanical.HERE/f"source-history-p32-s{seed}.npz",op)
        new_stress=stress(HERE/f"matched-source-history-p32-s{seed}.npz",op)
        for (width,frac),old_tt in old_stress.items():
            key=seed,width,frac;ref=previous[key]
            native=old_n[key]+old_tt
            unit=abs(float(ref["newton"]))*1e-6
            assert abs(old_n[key]-float(ref["newton"]))<.001*unit
            assert abs(native-float(ref["prediction"]))<.001*unit
            new_tt=new_stress[width,frac];forecast=new_n[key]+new_tt
            rows.append(dict(seed=seed,width=width,fraction=frac,native_newton=old_n[key],native_tt=old_tt,native=native,
                             matched_newton=new_n[key],matched_tt=new_tt,matched=forecast,
                             newton_shift_ppm=(new_n[key]-old_n[key])/unit,tt_shift_ppm=(new_tt-old_tt)/unit,
                             combined_shift_ppm=(forecast-native)/unit))
    table("matched-gravity-prediction.csv",rows)
    manifest("matched-forecast.json",dict(algorithm=core.sha(Path(__file__)),source=core.sha(HERE/"formation-freeze.json"),
        forecasts=core.sha(HERE/"matched-gravity-prediction.csv"),histories={str(seed):core.sha(HERE/f"matched-source-history-p32-s{seed}.npz") for seed in (1,-1)},
        independence="No GR output read to build forecast; thresholds unchanged."))
if __name__=="__main__":run()
