from aperture_trial import *
from launch_acceleration import signed
from split_curvature import increment
from chart_origin import geometric
from saved_centre import signed

def freeze_late():
    meta=frozen()
    prediction=json.loads((HERE/"matched-forecast.json").read_bytes())
    assert prediction["forecasts"]==core.sha(HERE/"matched-gravity-prediction.csv")
    seals={}
    for path in HERE.glob("quarter-g*-off?.json"):
        sheet=json.loads(path.read_bytes());assert sheet["freeze"]==meta and sheet["sha"]==core.sha(path.with_suffix(".npz"))
        seals[path.name]=core.sha(path)
    assert len(seals)==6
    manifest("long-clock-freeze.json",dict(quarter=seals,matched=core.sha(HERE/"matched-forecast.json"),
            reference=meta,code=core.sha(Path(__file__)),runs=[[640,1],[640,-1],[320,1]],ticks=[512,768,1024],
            primary="independently matched signed Newton plus FLRW propagating stress, same 20 ppm, two proper-ruler widths and both Riemann readouts",
            diagnostics="independent and native raw centre, core and bulk momentum, Hamiltonian, number, Ricci coefficient; no post-hoc removal"))

def late_lock():
    early=frozen();meta=json.loads((HERE/"long-clock-freeze.json").read_bytes())
    assert meta["reference"]==early and meta["matched"]==core.sha(HERE/"matched-forecast.json")
    assert meta["code"]==core.sha(Path(__file__))
    for key,digest in meta["quarter"].items():assert core.sha(HERE/key)==digest
    return core.sha(HERE/"long-clock-freeze.json")

def march_late(grid,seed,flag):
    seal=late_lock();stem=f"quarter-g{grid}-s{seed}-off{flag}";tag=f"extended-g{grid}-s{seed}-off{flag}";start=perf_counter()
    read=HERE/(stem+".npz")
    with old.environment(grid),patch.object(carrier,"launch",candidate),patch.object(evolve8,"revise",revised):
        model=(old.Cold if flag else old.Wave)(seed,"adm")
        step=4096*np.pi/(model.shell.mu*1024);advance=model.time_step(step)
        begin=256
        for idx in (512,768,1024):
            after=HERE/(tag+f"-t{idx}.json")
            if not after.exists():break
            saved=json.loads(after.read_bytes());assert saved["freeze"]==seal and core.sha(after.with_suffix(".npz"))==saved["sha"]
            begin=idx;read=after.with_suffix(".npz")
        with np.load(read) as bank:
            assert bank["clock"]==begin*step
            state=old.Difference(bank["shared"],bank["signed"])
        for tick in range(begin+1,1025):
            if tick%8==1:guard()
            state=advance((tick-1)*step,state)
            if tick%256:continue
            clock=tick*step
            assert np.isfinite(state.base).all() and np.isfinite(state.delta).all() and model.mass.min_branch>0
            if not flag:assert model.min_number>0 and model.min_factor>0
            mapped,aux=model.mass.decode(state)
            raw,geo,bg,_=model.lift.physical(mapped,clock);actual=raw if flag else model.to_wave(raw)
            h,p=geometric(model,mapped,aux,clock)
            tides=read_tide(model,clock,actual);extra=compute(model,state,clock)
            key=tag+f"-t{tick}"
            packet(key+".npz",shared=state.base,signed=state.delta,clock=clock,hd=signed(h[3]),pd=signed(p[3]),J=extra["J"],native=extra["P"],
                   independent=extra["ind_P"],H=extra["H"],number=raw.delta[12 if flag else 14].real,r=model.shell.r)
            manifest(key+".json",dict(tick=tick,freeze=seal,sha=core.sha(HERE/(key+".npz")),min_branch=model.mass.min_branch,
                                      tides={str(width)+"-"+channel:value for (width,channel),value in tides.items()}))
            print(tag,tick,round(perf_counter()-start,1),flush=True)

if __name__=="__main__":
    if sys.argv[1:]==["freeze"]:freeze_late()
    else:march_late(*map(int,sys.argv[1:]))
