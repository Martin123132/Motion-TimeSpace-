from aperture_trial import *
from chart_origin import Jets,radial
from cartesian_witness import tensor,Q

def mixed(h,p,size,m,kt,dk):
    inverse=m/(1+size*m)
    a,b,c,d=tuple(value-kt*metric for value,metric in zip(p,h))
    right=b-dk*(h[0]+size*h[1])
    partial=d-dk*(h[1]+h[2]+size*h[3])
    return (a,b-inverse*(a+size*b),right,c,partial-inverse*(right+c+size*partial))

def angular(h,M,size,m,Fs_over_F,z,dk,da,db_left):
    a,left,right,c,d=M
    F=1+size*m
    derivative=2*da+2*size*db_left
    algebra=2*left-right-4*c-2*size*d
    cs=(4*z+Fs_over_F)*(a+size*left)-(m-2*z)/F*(a+size*right)
    deformation=-dk/F*(radial(h,size)-(1+2*size*z)*(h[0]+size*h[1]))
    return (derivative+algebra+cs+deformation)*size/2

def analytic(size):
    m=.11+.023*size
    g=1+.07*size+.017*size**2
    kt=-.07+.06*size
    dk=.03+.04*size
    h=(.09+.04*size,.07-.05*size,.12+.023*size,-.061+.033*size**2)
    p=(.025+.07*size,.14+.03*size**2,-.05+.07*size,.062-.011*size**2)
    return m,g,kt,dk,h,p

def curved_test():
    def tensors(position,epsilon):
        size=position@position;m,g,kt,dk,h,p=analytic(size)
        outer=np.outer(position,position)
        G=g*(np.eye(3)+m*outer)
        K=G@(kt*np.eye(3)+dk*outer)
        return G+g*epsilon*tensor(position,h),K+g*epsilon*tensor(position,p)
    def direct(pos,eps):
        G,K=tensors(pos,eps)
        inv=np.linalg.inv(G);M=inv@K
        deriv=[];dm=[]
        for axis in np.eye(3):
            grad=[];mixed_grad=[]
            for offset,weight in ((-2,1),(-1,-8),(1,8),(2,-1)):
                gt,kt=tensors(pos+offset*1e-3*axis,eps)
                grad.append(weight*gt);mixed_grad.append(weight*np.linalg.solve(gt,kt))
            deriv.append(sum(grad)/.012);dm.append(sum(mixed_grad)/.012)
        d=np.array(deriv);dM=np.array(dm)
        lower=(d.transpose(2,0,1)+d.transpose(2,1,0)-d)/2
        conn=np.einsum("ab,bij->aij",inv,lower)
        return (np.einsum("jji->i",dM)-np.einsum("ijj->i",dM)+np.einsum("jjl,li->i",conn,M)-np.einsum("lji,jl->i",conn,M))
    rows=[]
    for xyz in ([.3,-.1,.66],[-.28,.48,.24],[.05,.015,-.033],[.99,.31,-.73]):
        pos=np.array(xyz);s=pos@pos;m,g,kt,dk,h,p=analytic(s)
        M=mixed(h,p,s,m,kt,dk)
        sc=s+1e-21j;mc,_,ktc,dkc,hc,pc=analytic(sc)
        dM=[val.imag/1e-21 for val in mixed(hc,pc,sc,mc,ktc,dkc)]
        u=Q@pos;perp=u-(pos@u)*pos/s
        projected=direct(pos,1e-21j).imag/1e-21@perp/(perp@u)
        pred=angular(h,M,s,m,(m+s*.023)/(1+s*m),(.07+.034*s)/(2*g),dk,dM[0],dM[1])*2/s
        rows.append(dict(point=str(xyz),predicted=pred,measured=projected,abs_error=abs(pred-projected)))
    assert max(row["abs_error"] for row in rows)<5e-10
    table("cartesian-divergence-control.csv",rows)

def saved_trials(grid,seed,flag):
    rows=[]
    with old.environment(grid),patch.object(carrier,"launch",candidate):
        model=(old.Cold if flag else old.Wave)(seed,"adm")
        r=model.shell.r;s=r**2
        tag=f"quarter-g{grid}-s{seed}-off{flag}"
        for tick in (0,256,512,768,1024):
            if tick:
                name=tag if tick==256 else f"extended-g{grid}-s{seed}-off{flag}-t{tick}"
                receipt=json.loads((HERE/(name+".json")).read_bytes())
                assert receipt["sha"]==core.sha(HERE/(name+".npz"))
                with np.load(HERE/(name+".npz")) as data:
                    state=old.Difference(data["shared"],data["signed"]);time=float(data["clock"])
                    J=data["J"];P=data["ind_P" if tick==256 else "independent"]
            else:
                state=np.zeros_like(model.shell.initial);time=0.
                with patch.object(evolve8,"revise",revised):calc=compute(model,state,time)
                J=calc["J"];P=calc["ind_P"]
            mapped,aux=model.mass.decode(state)
            _,_,bg,_=model.lift.physical(mapped,time)
            h,p=geometric(model,mapped,aux,time)
            m=np.expm1(2*(bg["ell"]-bg["bend"]))/s;kt=-aux["kb"];dk=(aux["kb"]-aux["ka"])/s
            M=mixed(h,p,s,m,kt,dk)
            for order in (4,6,8):
                jets=Jets(r,order)
                motion=angular(h,M,s,m,(bg["eg"]-bg["bg"])/r,bg["bg"]/(2*r),dk,jets.first_of(M[0]),jets.first_of(M[1])).delta
                defect=motion-J
                for label,mask in (("first",r<1/grid),("core",r<.3),("bulk",(r>.6)&(r<2.1))):
                    norm=np.linalg.norm
                    den=norm(J[mask]);assert den>0
                    rows.append(dict(grid=grid,seed=seed,flag=flag,tick=tick,order=order,region=label,
                                     cartesian=norm(defect[mask])/den,spherical=norm(P[mask])/den,readout_distance=norm((defect-P)[mask])/den,
                                     current=den,cart_signed_first=defect[0],spherical_signed_first=P[0]))
    return rows

if __name__=="__main__":
    frozen()
    if sys.argv[1:]==["test"]:curved_test()
    else:
        grid,seed,flag=map(int,sys.argv[1:])
        table(f"cartesian-momentum-g{grid}-s{seed}-off{flag}.csv",saved_trials(grid,seed,flag))
