from regular_space import *
from local_stage import TIMES
from hashlib import sha256

def freeze():
    lock()
    for name in ("regular-continuity-rate.csv","first-rate-controls.csv","source-sectors.csv"):
        assert (HERE/name).exists()
    manifest("formation-freeze.json",dict(files={key:core.sha(HERE/key) for key in
             ("regular_space.py","first_flux.py","formation_trial.py","scope_src.py","regular-continuity-rate.csv")},
             signed=[1,-1],resolutions=[4,5],edge=144,rk_per_DLOG=176,launch_q=1024,
             tests="Use original elapsed formation, incoming modes, exterior, resolved histories and two species controls. Report the integral moments, raw inner coefficient, matched radii, and changed formation acceleration. No post-evolution filtering or fit; no GR clock promotion from this test."))

def check_freeze():
    lock();path=HERE/"formation-freeze.json"
    config=json.loads(path.read_bytes())
    for name,digest in config["files"].items():assert core.sha(HERE/name)==digest
    return core.sha(path)

def march(res,seed):
    cert=check_freeze();guard()
    sim=carrier.prior.sphere(144,res);op=FirstElement(sim)
    orig=labels(sim,seed);state=op.project(orig);tick=0;timing=perf_counter()
    for kind,ini,new,basis,mass in zip(("mono","dn","phase"),orig,state,(op.radial,op.angular,op.angular),
                                       (sim.mesh.lump,sim.mesh.m,sim.mesh.m),strict=True):
        weight=mass[:op.count]*basis[:,0]
        signed=(new[...,:op.count]-ini[...,:op.count])@weight
        scale=np.max(abs(ini[...,:op.count])@weight)
        assert np.max(abs(signed))<1e-14*scale+1e-60
    name=f"formation-h{res}-s{seed}"
    for panel,(begin,end) in enumerate(zip(TIMES,TIMES[1:]),1):
        guard()
        count=max(8,int(round((end-begin)/(family.DLOG/176))))
        step=(end-begin)/count
        for idx in range(count):
            if idx%16==0:guard()
            time=begin+step*idx
            shift=lambda rates,delta:tuple(val+delta*der for val,der in zip(state,rates))
            first=op.rates(state,time)
            second=op.rates(shift(first,step/2),time+step/2)
            third=op.rates(shift(second,step/2),time+step/2)
            fourth=op.rates(shift(third,step),time+step)
            state=tuple(val+step*(aa+2*bb+2*cc+dd)/6 for val,aa,bb,cc,dd in zip(state,first,second,third,fourth))
            tick+=1
        assert all(np.isfinite(field).all() for field in state)
        if panel in (1,7,16,24,32,len(TIMES)-1):
            packet(name+f"-p{panel}.npz",clock=end,tick=tick,mono=state[0],density=state[1],velocity=state[2])
            print(name,panel,tick,round(perf_counter()-timing,1),flush=True)
    manifest(name+"-finished.json",dict(freeze=cert,tick=tick,clock=float(TIMES[-1]),model="regular-weak-first-element",
        sha=core.sha(HERE/(name+f"-p{len(TIMES)-1}.npz"))))
if __name__=="__main__":
    if sys.argv[1:]==["freeze"]:freeze()
    else:march(*map(int,sys.argv[1:]))
