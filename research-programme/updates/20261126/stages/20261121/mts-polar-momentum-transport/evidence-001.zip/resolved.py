from face_flux import *
from compare_polar import window_power


def run(grid,seed):
    digest=locked();profiles={};rows=[]
    tag=f"split{grid}-s{seed}"
    with workspace(grid):
        for flag in (0,1):
            model=Cold(seed,"adm") if flag else Wave(seed,"adm")
            r=model.shell.r
            meshes={f"order{degree}":operator(degree//2,r.size,3.) for degree in (8,12,24)}
            for tick in (256,512,768,1024):
                path=HERE/f"{tag}-off{flag}-t{tick}.npz"
                assert json.loads(path.with_suffix(".json").read_bytes())["sha"]==core.sha(path)
                with np.load(path) as bank:
                    clock=tick*(4096*np.pi/(1024*model.shell.mu))
                    profile=divergence(model,Difference(bank["base"],bank["delta"]),clock,meshes)
                    profile.update({key:bank[key] for key in ("P","ind_P","stencil","J","readout","eta","H","stable_H")})
                profiles[flag,tick]=profile
        for branch in ("wave","cold","wave-minus-cold"):
            for tick in (256,512,768,1024):
                def get(key):
                    wave=profiles[0,tick][key];dust=profiles[1,tick][key]
                    return wave if branch=="wave" else dust if branch=="cold" else wave-dust
                for name,mask in (("core",r<.3),("bulk",(r>.6)&(r<2.1))):
                    norm=lambda arr:np.linalg.norm(arr[mask])
                    denom=norm(get("J"))
                    rows.append(dict(grid=grid,seed=seed,branch=branch,tick=tick,region=name,
                      P=norm(get("P"))/denom,ind_P=norm(get("ind_P"))/denom,
                      flux8=norm(get("order8")-get("J"))/denom,flux12=norm(get("order12")-get("J"))/denom,
                      flux24=norm(get("order24")-get("J"))/denom,
                      unresolved_stencil=norm(get("readout")-get("stencil"))/norm(get("readout")),
                      high_frequency_fraction=window_power(get("readout")[mask])))
        local.table(tag+"-independent-flux.csv",rows)


if __name__=="__main__":run(*map(int,sys.argv[1:]))
