from polar_balance import *
from mts_sbp12 import Regular,interpolation


def operator(half,size,edge):
    class Independent(Regular):
        first,mean=interpolation(half)
    return Independent(size,edge)


def divergence(model,state,time,meshes):
    shell=model.shell;lift=model.lift;mesh=lift.mesh
    mapped,aux=model.mass.decode(state)
    raw,geo,bg,_=lift.physical(mapped,time)
    full=shell.initial+raw
    shear=full[5].real;trace=full[4].real
    newpi=mapped[6,1].real-(lift.to_pi(0*shear[1],shear[0],1.5*shear[1],geo["b"],geo["v"],bg)-lift.pi_offset)
    dl=-mapped[4,1].real/3-mapped[5,1].real
    db=-mapped[4,1].real/3+mapped[5,1].real/2
    vf=lift.v0face+(mesh.full(newpi)-2*mesh.faces*mesh.grad(db)-2*mesh.face(db-dl))/3
    factor=np.exp(mesh.face(4*bg["bend"]-bg["ell"]))
    dens=np.exp(bg["ell"]+2*bg["bend"])*shell.r**2
    flux=-mesh.faces**3*factor*vf/2
    lower=-2*trace[1]/3-shear[1]/2-2*full[7,1].real-1.5*shear[0]*geo["l"]
    actual={name:(other.back(flux)/dens+lower).delta for name,other in meshes.items()}
    actual["Vf"]=vf.delta
    return actual


def run(grid,seed):
    digest=locked()
    data={}
    with workspace(grid):
        for flag in (0,1):
            model=Cold(seed,"adm") if flag else Wave(seed,"adm")
            meshes={f"order{degree}":operator(degree//2,len(model.shell.r),3.) for degree in (6,8,12,16,24)}
            for tick in (0,256,512,768,1024):
                state,time=restart(model,grid,seed,tick,digest)
                data.update({f"b{flag}t{tick}_{key}":field for key,field in divergence(model,state,time,meshes).items()})
        local.packet(f"g{grid}-s{seed}-flux.npz",**data)


if __name__=="__main__":
    for grid,seed in ((320,1),(640,1),(640,-1)):run(grid,seed)
