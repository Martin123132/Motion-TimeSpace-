from split_clock import revised,increment,read_tide,compute,inputs
from split_curvature import *
from mass_scope import read_tide


def control():
    digest=locked()
    config=json.loads((HERE/"split-freeze.json").read_bytes())
    assert inputs()==config["code"] and digest==config["preceding"]
    with workspace(320):
        parent=core.sha(HERE/"split-freeze.json")
        local.manifest("coarse-freeze.json",dict(parent=parent,protocol=core.sha(HERE/"CONTROL.md"),
                    code=core.sha(Path(__file__)),grid=320,sign=1,steps=1024))
        freeze=core.sha(HERE/"coarse-freeze.json")
        measured={}
        for flag in (0,1):
            model=Cold(1,"adm") if flag else Wave(1,"adm")
            tag=f"split320-s1-off{flag}"
            step=4096*np.pi/(model.shell.mu*1024)
            with np.load(PREV/f"g320-s1-off{flag}-t256.npz") as orig:assert float(orig["step"])==step
            advance=model.time_step(step)
            state=np.zeros_like(model.shell.initial)
            begin=0
            for tick in range(256,1025,256):
                path=HERE/(tag+f"-t{tick}.npz")
                if not path.exists():break
                cert=json.loads(path.with_suffix(".json").read_bytes())
                assert cert["freeze"]==freeze and cert["sha"]==core.sha(path)
                with np.load(path) as bank:state=Difference(bank["base"],bank["delta"])
                measured[flag,tick]={(width,channel):cert["tide"][f"{width}-{channel}"] for width in (.15,.30) for channel in ("gauss","ricci")}
                begin=tick
            with patch.object(evolve8,"revise",revised):
                for tick in range(begin+1,1025):
                    if tick%8==1:guard()
                    state=advance((tick-1)*step,state)
                    if tick%256:continue
                    clock=tick*step
                    mapped,_=model.mass.decode(state)
                    raw,geo,bg,_=model.lift.physical(mapped,clock)
                    actual=raw if flag else model.to_wave(raw)
                    data=compute(model,state,clock)
                    addition,_=increment(model,clock,mapped,geo,bg)
                    data["stable_H"]=data["H"]+(addition-(model.lift.spatial(geo,bg)[0]-np.exp(-2*mapped[0,0].real)*model.lift.R_dis)).delta
                    measured[flag,tick]=read_tide(model,clock,actual)
                    path=HERE/(tag+f"-t{tick}.npz")
                    local.packet(path.name,base=state.base,delta=state.delta,**data)
                    assert model.mass.min_branch>0 and (flag or min(model.min_factor,model.min_number)>0)
                    local.manifest(path.with_suffix(".json").name,dict(freeze=freeze,sha=core.sha(path),tick=tick,flag=flag,seed=1,
                              min_branch=model.mass.min_branch,tide={str(width)+"-"+channel:value for (width,channel),value in measured[flag,tick].items()}))
                    print(tag,tick,flush=True)
        rows=[]
        for row in core.read(local.PREVIOUS/"predicted-gravity.csv"):
            if row["mode"]!="flrw-live" or int(row["seed"])!=1:continue
            tick=round(1024*float(row["fraction"]));width=float(row["width"])
            for channel in ("gauss","ricci"):
                tide=measured[0,tick][width,channel]-measured[1,tick][width,channel]
                residual=(tide-float(row["prediction"]))/(abs(float(row["newton"]))*1e-6)
                rows.append(dict(tick=tick,width=width,channel=channel,measured=tide,newton=row["newton"],prediction=row["prediction"],residual_ppm=residual,inside=abs(residual)<=20))
        local.table("split320-s1-scores.csv",rows)
        print("spatial control:",sum(row["inside"] for row in rows),"/ 16",flush=True)


if __name__=="__main__":control()
