from shell_flux import WINDOWS
from split_curvature import *
from trial import sources
from math import fsum


def source_terms(model,state,time):
    shell=model.shell;mu=shell.mu
    mapped,aux=model.mass.decode(state);stored,geo,bg,_=model.lift.physical(mapped,time)
    physical=stored if shell.flag else model.to_wave(stored)
    actual=shell.initial+physical
    ell,bend=actual[:2].real;K=actual[4].real
    B=shell.r*np.exp(bend[0]);volume=np.exp(ell[0])*B**2
    measure=exp(-ell-2*bend)
    geometric=geo["l"]
    allstress=sources(model,time,physical)
    obs=shell.incident.external(time)
    shellzero=0*K[0]
    def sector(j,c,lower):return (volume*j,B**2*B*c,volume*lower)
    result={"env":sector(B*actual[19,1].real,obs[5],obs[3]/3-obs[4]/2-2*obs[6])}
    model.bind(actual,physical)
    try:
        for idx in range(3 if shell.flag else 2):
            number,potential=actual[8+idx*2:10+idx*2].real
            density=shell.rho[idx]*mul(number,measure)
            radial=mul(exp(-ell),shell.diff(potential));speed=square(radial)
            gamma=np.sqrt(1+speed[0])
            cross=density[0]*radial[0]*potential[1]/(B*gamma)
            press_rr=density[0]*speed[0]/gamma
            result[("matter1","matter2","heavy")[idx]]=sector(density[0]*potential[1],cross,-press_rr*geometric)
            if idx==2:pop=number[0];phase=potential[1];amprate=shellzero
        if not shell.flag:
            wave,zeta=actual[14:16]
            normal=zeta.real+K/(2*mu);imag=zeta.imag-model.unit
            grad=mul(exp(-ell),shell.diff(wave))/mu
            gradient=square(grad.real)+square(grad.imag)
            excess=square(normal)+square(zeta.imag)-2*zeta.imag
            density=shell.rho[-1]*exp(2*wave.real)
            pop=(model.initial_number+stored[14].real)[0]
            phase=wave[1].imag/mu
            amprate=-normal[0]*wave[1].real/(mu*(1-zeta[0].imag))
            cross_amp=density[0]*grad[0].real*wave[1].real/(B*mu)
            cross_phase=density[0]*grad[0].imag*wave[1].imag/(B*mu)
            iso=mul(density,(excess-gradient)/2)[1]
            background=mul(density,gradient)[0]*geometric
            current=-density[0]*(normal[0]*wave[1].real+imag[0]*wave[1].imag)/mu
            result["heavy"]=sector(current,cross_amp+cross_phase,iso-background)
            result["wave_amplitude_flux"]=B**2*B*cross_amp
            result["wave_phase_flux"]=B**2*B*cross_phase
            result["wave_diagonal"]=volume*iso;result["wave_background_shear"]=volume*background
    finally:
        model.active={};model.elapsed=None
    energy,stress,sr,cross,tensor=allstress
    result["independent_total"]=(sum(result[sector][0] for sector in ("matter1","matter2","heavy","env")),B**2*B*cross,
                                  volume*(stress[1]/3-sr[1]/2-2*tensor-1.5*sr[0]*geometric))
    return result,pop,phase,amprate


def evaluate(grid,seed):
    locked();rows=[]
    with workspace(grid):
        models=[Wave(seed,"adm"),Cold(seed,"adm")]
        r=models[0].shell.r;dx=models[0].shell.dx
        for tick in (0,256,512,768,1024):
            terms=[]
            for flag,model in enumerate(models):
                if tick:
                    file=HERE/f"split{grid}-s{seed}-off{flag}-t{tick}.npz"
                    cert=json.loads(file.with_suffix(".json").read_bytes())
                    assert core.sha(file)==cert["sha"]
                    with np.load(file) as data:state=Difference(data["base"],data["delta"])
                else:state=np.zeros_like(model.shell.initial)
                terms.append(source_terms(model,state,tick*(4096*np.pi/(1024*model.shell.mu))))
            (wave,pop,phase,amprate),(dust,dpop,dphase,damp)=terms
            prefactor=models[0].shell.rho[-1]*r**2
            parts={"number_part":prefactor*(pop-dpop)*dphase,"phase_part":prefactor*pop*(phase-dphase),
                   "normal_amplitude_part":prefactor*pop*amprate}
            for center,width in WINDOWS:
                u=(r-center)/width;taper=np.maximum(1-u**2,0);weight=taper**6;dw=-12*u*taper**5/width
                def integrate(a,coef=weight):return fsum(a.delta*coef)*dx
                row=dict(grid=grid,seed=seed,tick=tick,clock=tick*4096*np.pi/(1024*models[0].shell.mu),centre=center,width=width)
                for name in ("matter1","matter2","heavy","env","independent_total"):
                    j,flux,lower=(a-b for a,b in zip(wave[name],dust[name]))
                    row[name+"_J"]=integrate(j)
                    row[name+"_radial"]=integrate(flux,dw)
                    row[name+"_angular"]=-integrate(lower)
                    row[name+"_drive"]=row[name+"_radial"]+row[name+"_angular"]
                for name,field in parts.items():row[name]=integrate(field)
                row["partition_error"]=row["heavy_J"]-sum(row[key] for key in parts)
                row["wave_amp_radial"]=integrate(wave["wave_amplitude_flux"],dw)
                row["wave_phase_minus_cold_radial"]=integrate(wave["wave_phase_flux"]-dust["heavy"][1],dw)
                row["wave_diagonal"]=-integrate(wave["wave_diagonal"])
                row["wave_background_minus_cold_angular"]=integrate(wave["wave_background_shear"]+dust["heavy"][2])
                row["radial_split_error"]=row["heavy_radial"]-row["wave_amp_radial"]-row["wave_phase_minus_cold_radial"]
                row["angular_split_error"]=row["heavy_angular"]-row["wave_diagonal"]-row["wave_background_minus_cold_angular"]
                row["sector_stress_error"]=row["independent_total_drive"]-sum(row[key+"_drive"] for key in ("matter1","matter2","heavy","env"))
                rows.append(row)
        local.table(f"split{grid}-s{seed}-source-partition.csv",rows)
    print("microscopic source partition",grid,seed,flush=True)


if __name__=="__main__":evaluate(*map(int,sys.argv[1:]))
