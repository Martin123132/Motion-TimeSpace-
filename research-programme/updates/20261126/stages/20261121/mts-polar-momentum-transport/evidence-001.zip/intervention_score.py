from polar_scope import *
from math import sqrt


def compare(seed,stop):
    locked();result=[];scores=[]
    digest=core.sha(HERE/"split-freeze.json")
    with np.load(HERE/f"g640-s{seed}-polar.npz") as old:
        r=old["r"]
        for tick in range(256,stop+1,256):
            tides={}
            for flag in (0,1):
                tag=f"split640-s{seed}-off{flag}-t{tick}"
                cert=json.loads((HERE/(tag+".json")).read_bytes())
                assert cert["freeze"]==digest and cert["sha"]==core.sha(HERE/(tag+".npz"))
                tides[flag]=cert["tide"]
                with np.load(HERE/(tag+".npz")) as bank:
                    pre=f"b{flag}t{tick}_"
                    for region,mask in (("core",r<.3),("bulk",(r>.6)&(r<2.1))):
                        for name in ("ind_P","P","ind_H","H","stencil"):
                            prev=old[pre+name][mask]
                            new=bank["stable_H" if name=="H" else name][mask]
                            prev_scale=old[pre+"J"][mask];new_scale=bank["J"][mask]
                            result.append(dict(seed=seed,flag=flag,tick=tick,region=region,observable=name,
                              old_rms=np.linalg.norm(prev)/sqrt(sum(mask)),new_rms=np.linalg.norm(new)/sqrt(sum(mask)),
                              ratio=np.linalg.norm(new)/np.linalg.norm(prev),old_over_current=np.linalg.norm(prev)/np.linalg.norm(prev_scale),
                              new_over_current=np.linalg.norm(new)/np.linalg.norm(new_scale)))
            for row in core.read(local.PREVIOUS/"predicted-gravity.csv"):
                if int(row["seed"])!=seed or row["mode"]!="flrw-live" or round(1024*float(row["fraction"]))!=tick:continue
                width=float(row["width"])
                for channel in ("gauss","ricci"):
                    key=str(width)+"-"+channel
                    measured=tides[0][key]-tides[1][key]
                    resid=(measured-float(row["prediction"]))/(abs(float(row["newton"]))*1e-6)
                    scores.append(dict(seed=seed,tick=tick,width=width,channel=channel,prediction=row["prediction"],
                        newton=row["newton"],measured=measured,residual_ppm=resid,inside=abs(resid)<=20))
    assert len(scores)==stop//64
    with workspace(640):
        local.table(f"split-s{seed}-through{stop}-comparison.csv",result)
        local.table(f"split-s{seed}-through{stop}-scores.csv",scores)
    for row in result:
        if row["observable"]=="ind_P" and row["region"]=="bulk":print(row["flag"],row["tick"],"ratio",row["ratio"])
    print("tides",sum(row["inside"] for row in scores),"/",len(scores),flush=True)


if __name__=="__main__":compare(*map(int,sys.argv[1:]))
