import sys
from pathlib import Path
from contextlib import contextmanager
from decimal import getcontext
import json
import csv
import io

HERE=Path(__file__).resolve().parent
PREV=HERE.parent/"mts-curved-spherical-mass-20261121"
sys.path.insert(0,str(PREV))
from monochart import Wave,Cold,np,Difference,local,core,environment,patch
from mass_scope import guard as saved_guard
from paired_clock import check as frozen
from number_chart import mul,exp,square,inv,pair
from trial import sources
from independent_constraints import fields
from readouts import joined
from endpoints import D


def guard():
    saved_guard()
    if (HERE/"STOP-REQUESTED").exists():raise RuntimeError("Owner hold")


def locked():
    guard()
    path=PREV/"seal.json"
    assert core.sha(path)=="828d5607b40fe11e4b32d73441868a2a288a9085c36b8c1e972ee594e8931d4d"
    cert=json.loads(path.read_bytes())
    for name,digest in cert["files"].items():assert core.sha(PREV/name)==digest,name
    return frozen()


@contextmanager
def workspace(grid):
    with environment(grid),patch.object(local,"HERE",HERE):
        getcontext().prec=50
        yield


def restart(model,grid,seed,tick,digest):
    guard()
    if not tick:return np.zeros_like(model.shell.initial),0.
    name=f"g{grid}-s{seed}-off{int(model.shell.flag)}-t{tick}.npz"
    cert=json.loads((PREV/(name+".json")).read_bytes())
    assert cert["freeze"]==digest and cert["sha"]==core.sha(PREV/name)
    with np.load(PREV/name) as saved:
        return Difference(saved["shared"],saved["signed"]),float(saved["step"])*tick
