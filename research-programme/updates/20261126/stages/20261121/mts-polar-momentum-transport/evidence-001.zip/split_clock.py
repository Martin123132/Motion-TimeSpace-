from split_curvature import *
from mass_scope import read_tide
from polar_balance import compute
import hashlib


def inputs():
    return {name:core.sha(HERE/name) for name in ("TRIAL.md","split_curvature.py","qualify_split.py",
        "principal-arithmetic.csv","split-qualification.csv","split_clock.py","polar_balance.py","polar_scope.py")}


def make_freeze():
    parent=locked()
    with workspace(640):local.manifest("split-freeze.json",dict(code=inputs(),preceding=parent,
        source=core.sha(local.PREVIOUS/"predicted-gravity.csv"),quarter=256,stop=1024,gate=20))


def march(seed,flag,stop):
    saved=locked()
    digest=core.sha(HERE/"split-freeze.json")
    cert=json.loads((HERE/"split-freeze.json").read_bytes())
    assert cert["code"]==inputs() and cert["preceding"]==saved and cert["source"]==core.sha(local.PREVIOUS/"predicted-gravity.csv")
    assert flag in (0,1) and seed in (-1,1) and stop in (256,1024)
    with workspace(640):
        model=Cold(seed,"adm") if flag else Wave(seed,"adm")
        tag=f"split640-s{seed}-off{flag}"
        step=4096*np.pi/(1024*model.shell.mu)
        with np.load(PREV/f"g640-s{seed}-off{flag}-t256.npz") as original:assert float(original["step"])==step
        advance=model.time_step(step)
        state=np.zeros_like(model.shell.initial)
        begin=0
        for tick in range(256,stop+1,256):
            path=HERE/(tag+f"-t{tick}.npz")
            if not path.exists():break
            receipt=json.loads(path.with_suffix(".json").read_bytes())
            assert receipt["freeze"]==digest and receipt["sha"]==core.sha(path)
            with np.load(path) as bank:state=Difference(bank["base"],bank["delta"])
            begin=tick
        with patch.object(evolve8,"revise",revised):
            for tick in range(begin+1,stop+1):
                if tick%8==1:guard()
                state=advance((tick-1)*step,state)
                if tick%256:continue
                assert np.isfinite(state.delta).all() and np.isfinite(state.base).all()
                time=tick*step
                mapped,_=model.mass.decode(state)
                raw,geo,bg,_=model.lift.physical(mapped,time)
                phys=raw if flag else model.to_wave(raw)
                data=compute(model,state,time)
                new,other=increment(model,time,mapped,geo,bg)
                data["stable_H"]=data["H"]+(new-(model.lift.spatial(geo,bg)[0]-np.exp(-2*mapped[0,0].real)*model.lift.R_dis)).delta
                score=read_tide(model,time,phys)
                path=HERE/(tag+f"-t{tick}.npz")
                local.packet(path.name,base=state.base,delta=state.delta,**data)
                assert model.mass.min_branch>0 and (flag or min(model.min_factor,model.min_number)>0)
                local.manifest(path.with_suffix(".json").name,dict(freeze=digest,sha=core.sha(path),tick=tick,flag=flag,seed=seed,
                              min_branch=model.mass.min_branch,tide={str(width)+"-"+channel:value for (width,channel),value in score.items()}))
                print(tag,tick,flush=True)


if __name__=="__main__":
    if sys.argv[1:]==["freeze"]:make_freeze()
    else:march(*map(int,sys.argv[1:]))
