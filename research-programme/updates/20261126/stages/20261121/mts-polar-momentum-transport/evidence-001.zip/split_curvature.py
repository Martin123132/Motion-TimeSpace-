from polar_scope import *
from native import background
import evolve8

ORIGINAL=evolve8.revise


def principal(lift,chart):
    mesh=lift.mesh
    ell,trace,mass,beta=chart
    section=mesh.back(mesh.faces*mesh.full(mass))
    return (-2*(section-6*beta)/mesh.mass2,
            mesh.lap(ell,6)+(2*section-mesh.back(mesh.grad(mesh.r**2*trace)))/mesh.mass2)


def secondary(lift,geo,bg):
    mesh=lift.mesh;r=mesh.r;rf=mesh.faces
    ell,bend,tilt,tensor=(geo[k] for k in ("l","b","v","d"))
    mass=mesh.full(geo["chart"][2]);beta=geo["chart"][3]
    shift=2*rf*mesh.odd_face(bg["bg"]*(bend-ell))
    a,other=lift.ang_coeff(bg)
    metric_beta=-(r*a*mesh.even_back(geo["vf"])+other*mesh.centre(geo["vf"]))/2
    ne=bg["ne"];delta=bg["delta"]
    normal=bg["X"]+bg["R"]/2;tangent=(bg["R"]-normal)/2
    corr=-2*normal*ell-4*tangent*bend-2*ne*(mesh.back(rf*shift)+(2*bg["bg"]-bg["eg"])*r*mesh.centre(mass+shift))/mesh.mass2
    corr+=12*(delta*beta+(ne+delta)*metric_beta)/mesh.mass2
    fb=r*bg["bg"]
    xcorr=(-delta*(4*bend+6*tensor)+ne*fb*(2*r*mesh.odd_centre(mesh.grad(bend))+6*tilt-2*(2+fb)*ell))/mesh.mass2
    return corr,-xcorr-corr/2


def increment(model,time,state,geo,bg):
    lift=model.lift
    if not hasattr(model,"secondary0"):
        initial=np.zeros_like(model.shell.initial)
        model.secondary0=secondary(lift,lift.geometry(initial,0.),lift.initbg)
    shifts=tuple(state[idx,1].real for idx in range(4))
    primary=principal(lift,shifts)
    remainder=secondary(lift,geo,bg)
    scale=np.exp(-2*state[0,0].real)
    return tuple(bg["ne"]*part+(rest-scale*old) for part,rest,old in zip(primary,remainder,model.secondary0,strict=True))


def revised(model,time,state,change,geo,bg,rates,result):
    value=increment(model,time,state,geo,bg)
    lift=model.lift
    with patch.object(lift,"spatial",return_value=value),patch.object(lift,"R_dis",0.),patch.object(lift,"rad_dis",0.):
        return ORIGINAL(model,time,state,change,geo,bg,rates,result)
