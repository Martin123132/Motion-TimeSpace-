from shell_flux import shells,WINDOWS
from split_curvature import *
from independent_constraints import fields
from scipy.interpolate import CubicSpline


def full_slices(grid,seed):
    digest=locked()
    tag=f"split{grid}-s{seed}"
    truth=core.sha(HERE/("split-freeze.json" if grid==640 else "coarse-freeze.json"))
    samples={};charges={};weak=[]
    with workspace(grid):
        for flag in (0,1):
            model=Cold(seed,"adm") if flag else Wave(seed,"adm")
            r=model.shell.r
            for tick in (0,256,512,768,1024):
                original,time=restart(model,grid,seed,tick,digest)
                if tick:
                    name=tag+f"-off{flag}-t{tick}.npz"
                    receipt=json.loads((HERE/name).with_suffix(".json").read_bytes())
                    assert receipt["sha"]==core.sha(HERE/name) and receipt["freeze"]==truth
                    with np.load(HERE/name) as input_data:trial=Difference(input_data["base"],input_data["delta"])
                else:trial=original
                for label,stored in (("old",original),("split",trial)):
                    mapped,aux=model.mass.decode(stored)
                    raw,geo,bg,_=model.lift.physical(mapped,time)
                    phys=raw if flag else model.to_wave(raw)
                    charges[label,flag,tick]=raw.delta[12 if flag else 14,0].real
                    readings=(fields(model.host,phys)-fields(model.zero,phys.base)).astype(float)
                    samples[label,flag,tick]=readings
                    if label=="split":
                        with patch.object(evolve8,"revise",revised):
                            values=shells(model,stored,time)
                        radius=model.shell.r
                        H,other=increment(model,time,mapped,geo,bg)
                        legacy=model.lift.spatial(geo,bg)[0]-np.exp(-2*mapped[0,0].real)*model.lift.R_dis
                        volume=np.exp(model.mass.ell0+mapped[0,0].real+2*aux["b"])*radius**2
                        dh=volume*(H-legacy)
                        for value,(centre,width) in zip(values,WINDOWS,strict=True):
                            weight=np.maximum(1-((r-centre)/width)**2,0)**6
                            adj=-sum(weight*dh.delta)*model.shell.dx/2
                            value["hamiltonian_work"]+=adj
                            value["weak_work_difference"]+=adj
                            value["geometry_weak_error"]-=adj
                            weak.append(dict(grid=grid,seed=seed,flag=flag,tick=tick,**value))
        rows=[];numbers=[]
        for name,flags in (("wave",[0]),("cold",[1]),("wave-minus-cold",[0,1])):
            def arrays(label,tick):
                first=samples[label,flags[0],tick]
                return first if len(flags)==1 else first-samples[label,1,tick]
            for tick in (0,256,512,768,1024):
                original=arrays("old",tick);trial=arrays("split",tick)
                for region,mask in (("core",r<.3),("bulk",(r>.6)&(r<2.1)),("centre-eight",np.arange(r.size)<8),
                                    ("outside-central-0.03",(r>.03)&(r<.3))):
                    vol=r[mask]**2;vol/=sum(vol)
                    for idx,label in enumerate(("H2","Mr2","Mtheta2")):
                        norm=lambda arr:np.linalg.norm(arr[mask])/np.sqrt(sum(mask))
                        source=norm(trial[idx+3]);defect=norm(trial[idx]);old=norm(original[idx])
                        sustained=norm(trial[idx]-arrays("split",0)[idx])
                        change=norm(trial[idx+3]-arrays("split",0)[idx+3])
                        rows.append(dict(grid=grid,seed=seed,branch=name,tick=tick,region=region,observable=label,
                           source=source,original_defect=old,corrected_defect=defect,relative=defect/source if source else "",
                           old_relative=old/norm(original[idx+3]) if norm(original[idx+3]) else "",
                           change_ratio=defect/old if old else "",
                           signed_drift=sustained,source_change=change,drift_over_change=sustained/change if change else "",
                           volume_relative=np.sqrt(sum(vol*trial[idx,mask]**2)/sum(vol*trial[idx+3,mask]**2)) if source else ""))
        target=(np.arange(480)+.5)/160;use=(target>.6)&(target<2.1)
        ratios=grid//160;volume=np.diff((np.arange(3*grid+1)/grid)**3)/3
        weights=volume.reshape(-1,ratios).sum(1)
        with np.load(local.PREVIOUS/f"frozen-current-adm-s{seed}.npz") as frozen:
            for idx,tick in enumerate((256,512,768,1024)):
                current=model.shell.rho[-1]*(charges["split",0,tick]-charges["split",1,tick])
                before=model.shell.rho[-1]*(charges["old",0,tick]-charges["old",1,tick])
                ref=f"window{idx}_charge_"
                pred=frozen[ref+"changing"]+(frozen[ref+"canonical_launch"]-frozen[ref+"launch"])
                coarse=((current*volume).reshape(-1,ratios).sum(1)/weights)[use]
                cubic=CubicSpline(r,current)(target[use])
                linear=np.interp(target[use],r,current)
                norm=np.linalg.norm
                mask=(r>.6)&(r<2.1)
                numbers.append(dict(grid=grid,seed=seed,tick=tick,native_change=norm((current-before)[mask])/norm(current[mask]),
                    coarse_relative=norm(coarse-pred)/norm(coarse),cubic_relative=norm(cubic-pred)/norm(cubic),
                    linear_relative=norm(linear-pred)/norm(linear),
                    cumulative_relative=norm(np.cumsum((coarse-pred)*weights[use]))/norm(np.cumsum(coarse*weights[use]))))
        local.table(tag+"-independent-field.csv",rows);local.table(tag+"-charge.csv",numbers);local.table(tag+"-shell-work.csv",weak)
    print(tag,"independent point samples, charge and shell work",flush=True)


if __name__=="__main__":full_slices(*map(int,sys.argv[1:]))
