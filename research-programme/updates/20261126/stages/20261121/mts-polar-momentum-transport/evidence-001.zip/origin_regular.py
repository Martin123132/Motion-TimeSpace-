from polar_scope import *
from fractions import Fraction
from math import prod


def coefficients(value,h,count,stride):
    indices=[stride*idx for idx in range(count)]
    xs=[Fraction(2*idx+1,2)**2 for idx in indices]
    intercept=[prod(-other/(x-other) for other in xs if other!=x) for x in xs]
    slope=[-a*sum(1/other for other in xs if other!=x) for a,x in zip(intercept,xs)]
    head=sum(float(w)*value[idx] for idx,w in zip(indices,intercept))
    second=sum(float(w)*(value[idx]-value[indices[0]]) for idx,w in zip(indices,slope))/h**2
    return head,second


def analytic():
    rows=[]
    for grid in (320,640):
        h=1/grid;r=(np.arange(40)+.5)*h
        c=.29+.13*r**2+.07*r**4;sf=.58+.14*r**2;tf=.29-.11*r**2
        trace=.41*r**2;s0=.035*r**2;ell2=.17+.16*r**2
        bend=.03+.23*r**2;scale=1+.19*r**2
        lower=3*scale*c-sf/2-2*tf-2*trace/3-1.5*s0*ell2
        exact=5*.13+(3*.19+6*.23)*.29-.14/2+2*.11-2*.41/3-1.5*.035*.17
        for count,stride in ((4,1),(6,1),(4,2)):
            coeff=lambda arr:coefficients(arr,h,count,stride)
            val,second=coeff(lower)
            result=second+2*coeff(scale)[0]*coeff(c)[1]+6*coeff(scale)[0]*coeff(bend)[1]*coeff(c)[0]
            assert abs(val)<2e-15 and abs(result-exact)<1e-8
            rows.append(dict(grid=grid,points=count,stride=stride,constant=val,second=result,exact=exact))
    return rows


def actual(grid,seed):
    digest=locked();rows=[];tag=f"split{grid}-s{seed}"
    with workspace(grid):
        for flag in (0,1):
            model=Cold(seed,"adm") if flag else Wave(seed,"adm")
            h=model.shell.dx
            for tick in (0,256,512,768,1024):
                if tick:
                    path=HERE/(tag+f"-off{flag}-t{tick}.npz")
                    assert core.sha(path)==json.loads(path.with_suffix(".json").read_bytes())["sha"]
                    with np.load(path) as pkt:state=Difference(pkt["base"],pkt["delta"]);j=pkt["J"]
                else:
                    state=np.zeros_like(model.shell.initial)
                    with np.load(HERE/f"g{grid}-s{seed}-polar.npz") as pkt:j=pkt[f"b{flag}t0_J"]
                time=tick*(4096*np.pi/(1024*model.shell.mu))
                mapped,_=model.mass.decode(state)
                raw,geo,bg,_=model.lift.physical(mapped,time)
                fields=model.shell.initial+raw
                tau,shear,cross,tensor=(fields[idx,1].real for idx in range(4,8))
                s0=fields[5,0].real
                scale=bg["scale"]
                combined=3*scale*cross-shear/2-2*tensor-2*tau/3-1.5*s0*geo["l"]
                for count,stride in ((4,1),(6,1),(4,2)):
                    coeff=lambda arr:coefficients(arr,h,count,stride)
                    intercept,slope=coeff(combined)
                    first=coeff(scale)[0]
                    geometric=slope+2*first*coeff(cross)[1]+6*first*coeff(bg["bend"])[1]*coeff(cross)[0]
                    j0,j2=coeff(j)
                    rows.append(dict(grid=grid,seed=seed,flag=flag,tick=tick,points=count,stride=stride,
                        estimated_geometric_constant=intercept.delta,estimated_material_constant=j0,
                        estimated_geometric_coefficient=geometric.delta,estimated_material_coefficient=j2,
                        constant_over_eighth_current=(intercept.delta-j0)/abs(j[7]) if j[7] else "",
                        slope_error_over_matter=(geometric.delta-j2)/abs(j2) if j2 else "",
                        centre_cross_minus_half_shear=(coeff(cross)[0]-coeff(shear)[0]/2).delta,
                        centre_tensor_minus_half_shear=(coeff(tensor)[0]-coeff(shear)[0]/2).delta))
        local.table(tag+"-origin-series.csv",rows)


if __name__=="__main__":
    if sys.argv[1:]==["test"]:
        with workspace(320):local.table("origin-manufactured.csv",analytic())
    else:actual(*map(int,sys.argv[1:]))
