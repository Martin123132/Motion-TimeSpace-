from polar_scope import *
from scipy.interpolate import CubicSpline


def material(model,encoded,actual,stored,stage,geo,bg,aux,Kdot):
    shell=model.shell
    incident=shell.incident.external(model.polar_time)
    state=shell.initial+actual
    ell,bend,_,_,trace,shear=state[:6].real
    vol=exp(-ell-2*bend)
    B=shell.r*np.exp(bend[0])
    k_b=aux["kb"]; unit=pair(np.ones_like(shell.r))
    zero=0*state[5,0].real
    def div(pressure,anis,cross,tensor):
        return model.lift.divergence(pressure,anis,cross,tensor,geo,bg)[1]
    banks={"env":(B*state[19,1].real,B*(stage[19,1].real+k_b*state[19,1].real),
            div(pair(incident[1],incident[3])/3,pair(zero,incident[4]),incident[5],incident[6]))}
    model.bind(state,actual)
    try:
        for idx in range(3 if shell.flag else 2):
            number,phase=state[8+idx*2:10+idx*2].real
            ndot,pdot=stage[8+idx*2:10+idx*2].real
            density=shell.rho[idx]*mul(number,vol)
            ddot=shell.rho[idx]*mul(vol,ndot+mul(number,trace))
            radial=mul(exp(-ell),shell.diff(phase));speed=square(radial)
            gamma=np.sqrt(1+speed[0]);inverse=inv(pair(gamma,speed[1]/(2*gamma)))
            stress=mul(density,mul(speed,inverse))
            cross=density[0]*radial[0]*phase[1]/(B*gamma)
            banks[("matter1","matter2","heavy")[idx]]=(density[0]*phase[1],ddot[0]*phase[1]+density[0]*pdot[1],
                                    div(stress/3,2*stress/3,cross,zero))
        if not shell.flag:
            mu=shell.mu
            wave,zeta=state[14:16]
            zdot=stage[15]+2j*mu*encoded[15]
            mr=zeta.real+trace/(2*mu);mi=zeta.imag-unit
            mrd=zdot[0].real+Kdot/(2*mu)
            logr=(mul(stage[14].real,inv(model.initial_number+stored[14].real))+trace+
                  mul(zdot.imag,inv(unit-zeta.imag)))/2
            density=shell.rho[-1]*exp(2*wave.real)
            amplitude=wave[1].real;phase=wave[1].imag
            contraction=mr[0]*amplitude+mi[0]*phase
            grad=mul(exp(-ell),shell.diff(wave))/mu
            gradient=square(grad.real)+square(grad.imag)
            excess=square(mr)+square(zeta.imag)-2*zeta.imag
            pressure=mul(density,(3*excess-gradient)/6)
            anis=2*mul(density,gradient)/3
            cross=density[0]*(grad[0].conj()*wave[1]).real/(B*mu)
            banks["heavy"]=(-density[0]*contraction/mu,-density[0]*(2*logr[0]*contraction+
                 mrd*amplitude+zdot[0].imag*phase+mr[0]*logr[1]+mi[0]*mu*zeta[1].imag)/mu,div(pressure,anis,cross,zero))
    finally:
        model.active={};model.elapsed=None
    return banks


def independent(model,phys):
    def observation(shell,shift):
        data=fields(shell,shift)
        bend=joined(shell.initial[1,0].real)+joined(shift[1,0].real)
        B=joined(shell.r)*np.exp(bend)
        return np.stack((B*data[2],B*data[5],data[0]))
    return (observation(model.host,phys)-observation(model.zero,phys.base)).astype(float)


def compute(model,state,time,ind=True):
    shell=model.shell;lift=model.lift;mesh=lift.mesh
    mapped,aux=model.mass.decode(state)
    raw,geo,bg,rates=lift.physical(mapped,time)
    phys=raw if shell.flag else model.to_wave(raw)
    source=sources(model,time,phys)
    energy,stress,sr,cross,tensor=source
    _,Kdot,_=model.mass.push(aux,energy[0],stress[0]/3+sr[0],sr[0])
    stage=model.rhs(time,state) if shell.flag else model.nonlinear(time,state)
    model.polar_time=time
    sectors=material(model,state,phys,raw,stage,geo,bg,aux,Kdot)
    full=shell.initial+phys;trace=full[4].real;shear=full[5].real
    native=lift.initial_tau+state[7,1].real
    total,derivative,divergence=(sum(entry[idx] for entry in sectors.values()) for idx in range(3))
    total_div=lift.divergence(stress/3,sr,cross,tensor,geo,bg)[1]
    scalar_raw,_=lift.spatial(geo,bg)
    scaled=np.exp(-2*mapped[0,0].real)
    scalar=scaled*(lift.launch_scalar-lift.R_dis)+scalar_raw
    H=scalar+(2*square(trace)/3-1.5*square(shear)-2*energy)[1]
    balance=native-total
    eta=derivative-trace[0]*total+divergence
    predicted=trace[0]*balance-H/2-eta
    measured=stage[7,1].real-derivative
    delta_m=state[6,1].real-(lift.to_pi(0*shear[1],shear[0],1.5*shear[1],geo["b"],geo["v"],bg)-lift.pi_offset)
    dl=-mapped[4,1].real/3-mapped[5,1].real
    db=-mapped[4,1].real/3+mapped[5,1].real/2
    vf=lift.v0face+(mesh.full(delta_m)-2*mesh.faces*mesh.grad(db)-2*mesh.face(db-dl))/3
    scale=bg["scale"];radius=shell.r
    stencil=-radius*scale**2*(shell.diff(mesh.centre(vf))-mesh.even_back(vf))/2
    lower=-shear[1]/2-2*full[7,1].real-1.5*shear[0]*geo["l"]-2*trace[1]/3
    cfield=full[6,1].real
    collocated=radius*scale*(shell.diff(cfield)+3*(1/radius+bg["bg"])*cfield)+lower
    aa,other=lift.ang_coeff(bg)
    face=lower-(radius*(1+aa)*mesh.even_back(vf)+(3+other)*mesh.centre(vf))/2
    comp=dict(native=native,J=total,P=balance,K0=trace[0],Kwork=trace[0]*balance,H=H,eta=eta,
              Hdrive=-H/2,etadrive=-eta,Pdot=measured,identity_error=measured-predicted,divergence=divergence,
              sector_sum_error=divergence-total_div,cell=collocated,face=face,stencil=stencil)
    for name,(jj,jdot,div) in sectors.items():
        comp["J_"+name]=jj;comp["eta_"+name]=jdot-trace[0]*jj+div
        comp["Jdot_"+name]=jdot;comp["div_"+name]=div
    data={key:np.asarray(value.delta).real.copy() for key,value in comp.items()}
    if ind:
        dec_p,dec_j,dec_h=independent(model,phys)
        data.update(ind_P=dec_p,ind_J=dec_j,ind_H=dec_h,readout=dec_p-data["P"])
    return data


def run(grid,seed):
    digest=locked()
    tag=f"g{grid}-s{seed}"
    profiles={}
    with workspace(grid):
        for flag in (0,1):
            model=Cold(seed,"adm") if flag else Wave(seed,"adm")
            for tick in (0,256,512,768,1024):
                state,time=restart(model,grid,seed,tick,digest)
                data=compute(model,state,time)
                for name,field in data.items():profiles[f"b{flag}t{tick}_{name}"]=field
                if tick:profiles["step"]=time/tick
        profiles["r"]=model.shell.r
        local.packet(tag+"-polar.npz",**profiles)
    print("completed",tag,flush=True)


if __name__=="__main__":run(*map(int,sys.argv[1:]))
