from polar_scope import *
import sympy as sy
from types import SimpleNamespace
from functools import lru_cache
from lift8 import Lift
from mts_sbp12 import Regular
import evolve8


@lru_cache(maxsize=1)
def geometry():
    radius,angle,eps=sy.symbols("r angle eps",positive=True)
    sq=radius**2
    Y=(3*sy.cos(angle)**2-1)/2;Yt=sy.diff(Y,angle)
    angular_tensor=sy.diff(Y,angle,2)+3*Y
    ell=sy.exp(-sq/2)/16;bend=-sy.exp(-sq/3)/19
    L=sq*sy.exp(-sq)/9;tang=sq*sy.exp(-sq/2)/13
    sr0=sq*sy.exp(-sq/3)/17
    p0=sy.exp(-sq/7)/5
    pressure=sq*sy.exp(-sq/2)/11;shear=sq*sy.exp(-sq/5)/12
    cross=sq*sy.exp(-sq/4)/8;tensor=sq*sy.exp(-sq)/10
    radial_scale=sy.exp(ell+eps*L*Y)
    angular_scale=radius*sy.exp(bend+eps*tang*Y)
    measure=radial_scale*angular_scale**2*sy.sin(angle)
    rr=p0+sr0+eps*(pressure+shear)*Y
    tt=p0-sr0/2+eps*((pressure-shear/2)*Y+tensor*angular_tensor)
    pp=tt-2*eps*tensor*angular_tensor
    rt=eps*angular_scale/radial_scale*cross*Yt
    covdiv=(sy.diff(measure*rt,radius)+sy.diff(measure*tt,angle))/measure-(
        rr*sy.diff(sy.log(radial_scale),angle)+(tt+pp)*sy.diff(sy.log(angular_scale),angle)+pp*sy.cot(angle))
    first=sy.diff(covdiv,eps).subs(eps,0)/Yt
    names=("ell","b","bp","l2","p","s0","s2","c","t","true1","true2")
    terms=(ell,bend,sy.diff(bend,radius),L,pressure,sr0,shear,cross,tensor,
           sy.simplify(first.subs(angle,sy.pi/4)),sy.simplify(first.subs(angle,sy.pi/3)))
    return names,sy.lambdify(radius,terms,"numpy",cse=True)


def evaluate(cells):
    grid=Regular(cells,3.)
    r=grid.r
    labels,fun=geometry()
    data=dict(zip(labels,fun(r),strict=True))
    assert np.max(abs(data["true1"]-data["true2"]))<1e-13
    shell=SimpleNamespace(r=r,flag=True,diff=lambda arr:grid.odd_centre(grid.grad(arr)))
    model=SimpleNamespace(shell=shell,scheme="adm")
    lift=Lift.__new__(Lift)
    lift.mesh=grid;lift.shell=shell;lift.r=r
    model.lift=lift
    K=-.27
    H=r**2*np.exp(-r**2/2)/9
    forcing=-r**2*np.exp(-r**2/4)/7
    defect0=r**2*np.exp(-r**2/3)/8
    material0=r**2*np.exp(-r**2)/13
    time=.37
    gain=np.exp(K*time)
    chi=np.expm1(K*time)/K
    j=gain*material0+chi*(forcing-data["true1"])
    P=gain*defect0+chi*(-H/2-forcing)
    jdot=gain*(K*material0+forcing-data["true1"])
    pdot=gain*(K*defect0-H/2-forcing)
    start=np.zeros((20,2,cells))
    start[4,0]=K
    lift.start=start;shell.initial=start
    z=np.zeros_like(r);zeros=np.stack((z,z))
    lift.initial_m=z;lift.initial_tau=j+P
    lift.launch_scalar=H;lift.R_dis=z;lift.launch_x=z;lift.rad_dis=z
    lift.spatial=lambda geo,bg:(z,z)
    geo={"l":data["l2"]+z,"b":z,"v":z}
    bg={"bg":data["bp"],"scale":np.exp(data["b"]-data["ell"]),"R":z}
    pressure=np.stack((z,data["p"]))
    shear=np.stack((data["s0"],data["s2"]))
    v=(z,)*4
    with patch.object(evolve8,"sources",return_value=(zeros,3*pressure,shear,data["c"],data["t"])):
        out=evolve8.revise(model,time,0*start,0*start,geo,bg,v,0*start)
    div=lift.divergence(pressure,shear,data["c"],data["t"],geo,bg)[1]
    errors=[]
    for key,measured,exact in (("mixed covariant divergence",div,data["true1"]),("geometric theta rate",out[7,1],jdot+pdot),
                      ("forced defect rate",out[7,1]-jdot,pdot),("material source recovered",jdot-K*j+div,forcing)):
        for region,mask in (("centre",r<.3),("interior",(r>.6)&(r<2.1))):
            errors.append(dict(cells=cells,observable=key,region=region,relative=np.linalg.norm((measured-exact)[mask])/np.linalg.norm(exact[mask]),
                     forcing_max=max(abs(forcing)),Hmax=max(abs(H)),Pmax=max(abs(P))))
    return errors


if __name__=="__main__":
    locked();rows=[]
    for cells in (64,128,256):rows.extend(evaluate(cells))
    with workspace(640):local.table("manufactured-curved-polar.csv",rows)
    finest=max(row["relative"] for row in rows if row["cells"]==256)
    print("finest maximum",finest)
    assert finest<1e-7
