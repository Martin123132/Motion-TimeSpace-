from polar_scope import *
from itertools import islice


CASES=((320,1),(640,1),(640,-1))
TARGET="final-quarter-frozen.csv"


def forecast():
    locked()
    results=[]
    for grid,seed in CASES:
        path=HERE/f"split{grid}-s{seed}-source-partition.csv"
        with path.open(encoding="utf-8-sig",newline="") as stream:
            training=list(islice(csv.DictReader(stream),20))
        assert len(training)==20 and set(int(row["tick"]) for row in training)=={0,256,512,768}
        for centre in sorted({float(row["centre"]) for row in training}):
            group=[row for row in training if float(row["centre"])==centre]
            assert [int(row["tick"]) for row in group]==[0,256,512,768]
            clock=[float(row["clock"]) for row in group]
            step=clock[-1]-clock[-2]
            def col(key):return np.array([float(row[key]) for row in group])
            force=col("heavy_drive")
            restricted=col("wave_phase_minus_cold_radial")+col("wave_background_minus_cold_angular")
            third=lambda f:step*(23*f[3]-16*f[2]+5*f[1])/12
            results.append(dict(grid=grid,seed=seed,centre=centre,from_tick=768,to_tick=1024,
                       J_start=group[-1]["heavy_J"],quadratic=third(force),linear=step*(3*force[3]-force[2])/2,
                       constant=step*force[3],restricted=third(restricted),no_force=0))
    with workspace(640):
        local.table(TARGET,results)
        local.manifest("quarter-prediction-lock.json",dict(forecast=core.sha(HERE/TARGET),protocol=core.sha(HERE/"QUARTER-PREDICTION.md"),
             predictor=core.sha(Path(__file__)),cases=15,maximum_tick=768))
    print("15 forecasts frozen without final rows")


def score():
    locked()
    cert=json.loads((HERE/"quarter-prediction-lock.json").read_bytes())
    assert (cert["forecast"],cert["protocol"],cert["predictor"])==(core.sha(HERE/TARGET),core.sha(HERE/"QUARTER-PREDICTION.md"),core.sha(Path(__file__)))
    trials=core.read(HERE/TARGET);results=[]
    for pred in trials:
        grid,seed=int(pred["grid"]),int(pred["seed"])
        centre=float(pred["centre"]);tick=int(pred["to_tick"])
        source=core.read(HERE/f"split{grid}-s{seed}-shell-work.csv")
        def direct(at,flag):
            chosen=[float(row["current_heavy"]) for row in source if int(row["tick"])==at and int(row["flag"])==flag and float(row["centre"])==centre]
            assert len(chosen)==1
            return chosen[0]
        launch=direct(768,0)-direct(768,1)
        end=direct(tick,0)-direct(tick,1)
        actual=end-launch
        for variant in ("quadratic","linear","constant","restricted","no_force"):
            value=float(pred[variant])
            results.append(dict(grid=grid,seed=seed,centre=centre,variant=variant,measured_change=actual,
                       predicted_change=value,absolute_error=abs(value-actual),relative_error=abs(value/actual-1) if actual else "",
                       initial_evaluator_difference=launch-float(pred["J_start"])))
    with workspace(640):local.table("final-quarter-scored.csv",results)
    print("75 signed comparisons, five variants at fifteen sites")


if __name__=="__main__":
    if sys.argv[1:]==["freeze"]:forecast()
    elif sys.argv[1:]==["score"]:score()
    else:raise SystemExit("Choose freeze or score")
