from split_curvature import *
from decimal import Decimal,localcontext
from mts_sbp12 import Regular
from types import SimpleNamespace


def decimal_principal(mesh,chart,idx):
    dec=Decimal.from_float
    h=dec(mesh.h)
    weights=[dec(v) for v in mesh.first]
    ell,trace,packed,beta=chart
    faces=[dec(v) for v in mesh.faces]
    cells=[dec(v) for v in mesh.r]
    def grad(func,face):
        return sum(v*(func(face+j)-func(face-1-j)) for j,v in enumerate(weights))/h
    def back(func):
        return sum(v*(func(idx+j+1)-func(idx-j)) for j,v in enumerate(weights))/h
    section=back(lambda k: faces[k]*packed[k-1])
    radius=cells[idx]
    lap=back(lambda k:faces[k]**6*grad(lambda k:ell[k],k))/radius**6
    div=back(lambda k:grad(lambda k:cells[k]**2*trace[k],k))
    return (-2*(section-6*beta[idx])/radius**2,lap+(2*section-div)/radius**2)


def tiny():
    mesh=Regular(240,3.);lift=SimpleNamespace(mesh=mesh)
    initial=tuple(np.exp(-(.4+.06*idx)*mesh.r**2)*(1+idx*.23) for idx in range(4))
    shift=tuple(1e-18*(1+idx)*np.exp(-mesh.r**2)*np.cos((idx+2)*mesh.r) for idx in range(4))
    naive=[a-b for a,b in zip(principal(lift,tuple(a+b for a,b in zip(initial,shift))),principal(lift,initial))]
    stable=principal(lift,shift)
    with localcontext() as ctx:
        ctx.prec=68
        dec=lambda series:[[Decimal.from_float(v) for v in arr] for arr in series]
        start=dec(initial);inc=dec(shift)
        final=[[a+b for a,b in zip(row,other)] for row,other in zip(start,inc)]
        result=[]
        for pos in (48,75,101,136):
            old=decimal_principal(mesh,start,pos)
            new=decimal_principal(mesh,final,pos)
            for channel in (0,1):
                exact=float(new[channel]-old[channel])
                result.append(dict(cell=pos,channel=channel,reference=exact,stable=stable[channel][pos],naive=naive[channel][pos],
                         stable_error=abs(stable[channel][pos]/exact-1),naive_error=abs(naive[channel][pos]/exact-1)))
    assert max(row["stable_error"] for row in result)<1e-9
    assert min(row["naive_error"] for row in result)>.1
    return result


def main():
    locked();rows=[]
    with workspace(640):
        for seed in (1,-1):
            for flag in (0,1):
                model=Cold(seed,"adm") if flag else Wave(seed,"adm")
                state=np.zeros_like(model.shell.initial)
                r=model.shell.r
                for size in (0.,.001):
                    for idx in range(4):
                        coord=model.lift.mesh.faces[1:] if idx==2 else r
                        sign=1 if idx%2==0 else -1
                        state.base[idx,1]=sign*size*coord**(3 if idx==2 else 2)*np.exp(-coord**2)
                        state.delta[idx,1]=.28*size*coord**(3 if idx==2 else 2)*np.exp(-2*coord**2)
                    state.base[1,0]=size*np.exp(-r**2)
                    state.delta[1,0]=seed*.13*size*np.exp(-r**2/2)
                    mapped,_=model.mass.decode(state)
                    _,geo,bg,_=model.lift.physical(mapped,0.)
                    raw=model.lift.spatial(geo,bg)
                    scale=np.exp(-2*mapped[0,0].real)
                    old=(raw[0]-scale*model.lift.R_dis,raw[1]-scale*model.lift.rad_dis)
                    new=increment(model,0.,mapped,geo,bg)
                    for idx in (0,1):
                        for member in ("base","delta"):
                            sel=r<2.4
                            obs=getattr(new[idx],member)[sel];ref=getattr(old[idx],member)[sel]
                            denom=np.linalg.norm(ref)
                            discrepancy=np.linalg.norm(obs-ref)/(denom or 1)
                            assert (discrepancy<1e-9 and denom>0) if size else (not np.any(obs) and not np.any(ref))
                            rows.append(dict(seed=seed,flag=flag,size=size,member=member,channel=idx,reference_norm=denom,discrepancy=discrepancy))
        local.table("principal-arithmetic.csv",tiny());local.table("split-qualification.csv",rows)
    print("qualification",len(rows),max(row["discrepancy"] for row in rows),flush=True)


if __name__=="__main__":main()
