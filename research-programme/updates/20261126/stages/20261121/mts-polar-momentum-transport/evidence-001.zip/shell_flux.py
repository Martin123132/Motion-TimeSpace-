from polar_balance import *
from math import fsum


WINDOWS=((.18,.15),(.45,.30),(.90,.15),(1.35,.30),(1.80,.15))


def shells(model,state,time):
    shell=model.shell
    mapped,aux=model.mass.decode(state)
    raw,geo,bg,_=model.lift.physical(mapped,time)
    change=raw if shell.flag else model.to_wave(raw)
    actual=shell.initial+change
    stage=model.rhs(time,state) if shell.flag else model.nonlinear(time,state)
    energy,stress,anis,cross,tensor=sources(model,time,change)
    _,Kdot,__=model.mass.push(aux,energy[0],stress[0]/3+anis[0],anis[0])
    model.polar_time=time
    banks=material(model,state,change,raw,stage,geo,bg,aux,Kdot)
    jt,jdot,div=(sum(group[idx] for group in banks.values()) for idx in range(3))
    ell,bend=actual[:2].real
    trace,shear=actual[4:6].real
    B=shell.r*np.exp(bend[0])
    volume=np.exp(ell[0])*B**2
    cube=B*B**2
    K=trace[0]
    native=model.lift.initial_tau+state[7,1].real
    lowerK=-2*trace[1]/3-shear[1]/2-2*actual[7,1].real-1.5*shear[0]*geo["l"]
    lowerS=stress[1]/3-anis[1]/2-2*tensor-1.5*anis[0]*geo["l"]
    scalar,_=model.lift.spatial(geo,bg)
    factor=np.exp(-2*mapped[0,0].real)
    H=scalar+factor*(model.lift.launch_scalar-model.lift.R_dis)+(2*square(trace)/3-1.5*square(shear)-2*energy)[1]
    result=[]
    for center,width in WINDOWS:
        distance=(shell.r-center)/width
        taper=np.maximum(1-distance**2,0)
        weight=taper**6;grad=-12*distance*taper**5/width
        def integrate(arr):return fsum(arr.delta)*shell.dx
        total=lambda arr:integrate(weight*volume*arr)
        radialS=integrate(grad*cube*cross)
        angularS=-total(lowerS)
        material_rate=total(jdot-K*jt)
        geometric_rate=total(stage[7,1].real-K*native)
        material_value=total(jt)
        geometric=total(native)
        ibp_K=-integrate(grad*cube*actual[6,1].real)+total(lowerK)
        source_work=total(jdot-K*jt+div)
        h_work=-total(H)/2
        radialK=-integrate(grad*cube*actual[6,1].real)
        flux=radialS+angularS
        row=dict(centre=center,width=width,clock=time,J=material_value,T=geometric,difference=total(native-jt),
                 weak_geometric=ibp_K,weak_defect=ibp_K-material_value,radial_K=radialK,angular_K=total(lowerK),
                 Jdot=material_rate,Tdot=geometric_rate,radial_flux=radialS,angular_stress=angularS,
                 stress_prediction=flux,eta=source_work,hamiltonian_work=h_work,
                 material_weak_error=material_rate-flux,geometry_weak_error=geometric_rate-flux-h_work,
                 difference_rate=geometric_rate-material_rate,weak_work_difference=h_work-source_work,
                 abs_J=fsum(abs((weight*volume*jt).delta))*shell.dx,
                 abs_geometric_terms=fsum(abs((grad*cube*actual[6,1].real).delta)+abs((weight*volume*lowerK).delta))*shell.dx,
                 stress_scale=fsum(abs((grad*cube*cross).delta)+abs((weight*volume*lowerS).delta))*shell.dx)
        for sector,(current,rate,stressdiv) in banks.items():
            row["current_"+sector]=total(current)
            row["work_"+sector]=total(rate-K*current+stressdiv)
        result.append(row)
    return result


def run(grid,seed):
    digest=locked()
    banks=[]
    with workspace(grid):
        for flag in (0,1):
            model=Cold(seed,"adm") if flag else Wave(seed,"adm")
            for tick in (0,256,512,768,1024):
                state,time=restart(model,grid,seed,tick,digest)
                banks.extend(dict(grid=grid,seed=seed,flag=flag,tick=tick,**row) for row in shells(model,state,time))
        local.table(f"g{grid}-s{seed}-shell-work.csv",banks)
    print("shell work",grid,seed,flush=True)


if __name__=="__main__":run(*map(int,sys.argv[1:]))
