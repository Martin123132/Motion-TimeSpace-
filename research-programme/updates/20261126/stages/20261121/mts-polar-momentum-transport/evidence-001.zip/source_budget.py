from polar_scope import *


def simpson(vals,dt):
    return dt*(vals[0]+4*vals[1]+2*vals[2]+4*vals[3]+vals[4])/12


def main():
    locked();outputs=[]
    for grid,seed in ((320,1),(640,1),(640,-1)):
        tag=f"split{grid}-s{seed}"
        records=core.read(HERE/(tag+"-source-partition.csv"))
        independent=core.read(HERE/(tag+"-shell-work.csv"))
        for center in sorted({float(row["centre"]) for row in records}):
            group=sorted([row for row in records if float(row["centre"])==center],key=lambda row:int(row["tick"]))
            assert len(group)==5
            wave,dust=(sorted([row for row in independent if int(row["flag"])==flag and float(row["centre"])==center],
                        key=lambda row:int(row["tick"])) for flag in (0,1))
            col=lambda key:np.array([float(row[key]) for row in group])
            separate=lambda key:np.array([float(a[key])-float(b[key]) for a,b in zip(wave,dust)])
            clock=col("clock");dur=clock[-1]
            total_drive=col("independent_total_drive")
            total_change=col("independent_total_J")[-1]-col("independent_total_J")[0]
            source_scale=max(abs(total_change),np.trapezoid(abs(total_drive),clock))
            assert source_scale>0
            detail={}
            for sector in ("matter1","matter2","env","heavy","independent_total"):
                charge=col(sector+"_J");force=col(sector+"_drive")
                delta=charge[-1]-charge[0];pred=simpson(force,dur)
                detail[sector+"_change"]=delta
                detail[sector+"_from_boundary_flux"]=simpson(col(sector+"_radial"),dur)
                detail[sector+"_from_angular_stress"]=simpson(col(sector+"_angular"),dur)
                detail[sector+"_pred"]=pred
                scale=max(abs(delta),np.trapezoid(abs(force),clock))
                detail[sector+"_residual_over_total_scale"]=(delta-pred)/source_scale
                detail[sector+"_relative"]=(delta-pred)/scale if scale else ""
            amp_scale=max(abs(col("number_part"))+abs(col("phase_part"))+abs(col("normal_amplitude_part")))
            details=[("number","number_part"),("phase","phase_part"),("normal_amplitude","normal_amplitude_part")]
            for name,key in details:
                vals=col(key);detail[name+"_launch"]=vals[0];detail[name+"_change"]=vals[-1]-vals[0]
            for name in ("wave_amp_radial","wave_phase_minus_cold_radial","wave_diagonal","wave_background_minus_cold_angular"):
                detail["integral_"+name]=simpson(col(name),dur)
            per_wave=max(abs(separate("J")))*1e-14
            outputs.append(dict(grid=grid,seed=seed,centre=center,width=group[0]["width"],scale=source_scale,
                sector_operator_replay=max(abs(total_drive-separate("stress_prediction")))/(source_scale/dur),
                sector_sum_check=max(abs(col("sector_stress_error")))/(source_scale/dur),
                normal_form_check=max(abs(col("partition_error")))/amp_scale if amp_scale else "",
                previous_current_crosscheck=max(abs(separate("J")-col("independent_total_J")))/max(max(abs(separate("J"))),per_wave),
                quadrature_spread=(simpson(total_drive,dur)-dur*(total_drive[0]+4*total_drive[2]+total_drive[4])/6)/source_scale,
                **detail))
    with workspace(640):local.table("microscopic-work-budget.csv",outputs)
    print(len(outputs),"independent integrated matter budgets",flush=True)


if __name__=="__main__":main()
