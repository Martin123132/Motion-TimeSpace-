from polar_scope import *
from mass_scope import read_tide
from math import isfinite,isclose


def ledger(grid,seed,deep):
    label=f"split{grid}-s{seed}"
    digest=core.sha(HERE/("coarse-freeze.json" if grid==320 else "split-freeze.json"))
    read={}
    with workspace(grid):
        for flag in (0,1):
            model=Cold(seed,"adm") if flag else Wave(seed,"adm")
            for tick in (256,512,768,1024):
                path=HERE/(label+f"-off{flag}-t{tick}.npz")
                cert=json.loads(path.with_suffix(".json").read_bytes())
                assert cert["sha"]==core.sha(path) and cert["freeze"]==digest and cert["min_branch"]>0
                assert (cert["flag"],cert["seed"],cert["tick"])==(flag,seed,tick)
                tides=cert["tide"]
                assert set(tides)=={f"{width}-{key}" for width in (.15,.3) for key in ("gauss","ricci")}
                assert all(isfinite(v) for v in tides.values())
                if deep and tick==1024:
                    with np.load(path) as packet:stored=Difference(packet["base"],packet["delta"])
                    time=tick*(4096*np.pi/(1024*model.shell.mu))
                    shift=model.mass.decode(stored)[0]
                    raw=model.lift.physical(shift,time)[0]
                    actual=raw if flag else model.to_wave(raw)
                    direct=read_tide(model,time,actual)
                    assert all(tides[f"{width}-{key}"]==value for (width,key),value in direct.items())
                read[flag,tick]=tides
    file=label+"-scores.csv" if grid==320 else f"split-s{seed}-through1024-scores.csv"
    scores=core.read(HERE/file)
    assert len(scores)==len({(row["tick"],row["width"],row["channel"]) for row in scores})==16
    for row in scores:
        tick=int(row["tick"]);key=row["width"]+"-"+row["channel"]
        tide=read[0,tick][key]-read[1,tick][key]
        assert tide==float(row["measured"]) and ((abs(float(row["residual_ppm"]))<=20)==(row["inside"]=="True"))
        assert (tide-float(row["prediction"]))/(1e-6*abs(float(row["newton"])))==float(row["residual_ppm"])
    assert len(core.read(HERE/(label+"-independent-field.csv")))==180 and len(core.read(HERE/(label+"-charge.csv")))==4
    assert len(core.read(HERE/(label+"-independent-flux.csv")))==24 and len(core.read(HERE/(label+"-origin-series.csv")))==30
    for name,count in ((label+"-shell-work.csv",50),(label+"-source-partition.csv",25)):
        data=core.read(HERE/name);assert len(data)==count and all(all(isfinite(float(val)) for val in row.values()) for row in data)
    return sum(row["inside"]=="True" for row in scores)


def main():
    locked()
    tables={"manufactured-curved-polar.csv":24,"readout-attribution.csv":90,"common-shells.csv":180,"current-sectors.csv":360,
        "integrated-flux.csv":135,"principal-arithmetic.csv":8,"split-qualification.csv":32,"microscopic-work-budget.csv":15,
        "final-quarter-frozen.csv":15,"final-quarter-scored.csv":75}
    for key,count in tables.items():assert len(core.read(HERE/key))==count
    for row in core.read(HERE/"manufactured-curved-polar.csv"):
        if int(row["cells"])==256:assert float(row["relative"])<1e-7
        assert min(float(row[key]) for key in ("Pmax","Hmax","forcing_max"))>0
    assert max(float(row["stable_error"]) for row in core.read(HERE/"principal-arithmetic.csv"))<1e-9
    assert max(float(row["discrepancy"]) for row in core.read(HERE/"split-qualification.csv"))<1e-9
    sources=core.read(HERE/"microscopic-work-budget.csv")
    assert all(float(row["scale"])>0 and isfinite(float(row["independent_total_relative"])) for row in sources)
    assert max(abs(float(row[key])) for row in sources for key in ("normal_form_check","sector_sum_check","sector_operator_replay","previous_current_crosscheck"))<1e-9
    assert len(core.read(HERE/"origin-manufactured.csv"))==6
    forecast=json.loads((HERE/"quarter-prediction-lock.json").read_bytes())
    assert forecast["forecast"]==core.sha(HERE/"final-quarter-frozen.csv") and forecast["maximum_tick"]==768
    results={f"{grid},{seed}":ledger(grid,seed,"--replay-final" in sys.argv) for grid,seed in ((320,1),(640,1),(640,-1))}
    assert (HERE/"RESULTS.md").is_file() and (HERE/"DERIVATION.md").is_file()
    files={path.name:core.sha(path) for path in sorted(HERE.iterdir()) if path.is_file() and path.name!="seal.json"}
    doc=dict(parent=core.sha(PREV/"seal.json"),scores=results,files=files)
    path=HERE/"seal.json"
    if path.exists():assert json.loads(path.read_bytes())==doc
    else:
        assert "--seal" in sys.argv
        with path.open("x",encoding="utf-8",newline="\n") as handle:handle.write(json.dumps(doc,indent=2)+"\n")
    print("verified",len(files),"files; proper readings",results,"seal",core.sha(path),flush=True)


if __name__=="__main__":main()
