from polar_scope import *
from scipy.interpolate import CubicSpline
from math import sqrt


def safe_ratio(value,scale):return value/scale if scale else ""


def window_power(values):
    power=abs(np.fft.rfft(np.hanning(len(values))*values))**2
    freq=2*np.fft.rfftfreq(len(values))
    return sum(power[freq>.8])/sum(power) if sum(power) else 0.


def per_grid(grid,seed):
    label=f"g{grid}-s{seed}"
    rows=[]
    pair=[]
    sector=[]
    with np.load(HERE/(label+"-polar.npz")) as bank,np.load(HERE/(label+"-flux.npz")) as face:
        r=bank["r"];group=grid//160
        edges=np.arange(len(r)+1)/grid
        weights=np.diff(edges**3)
        common=(np.arange(len(r)//group)+.5)/160
        for branch in ("wave","cold","wave-minus-cold"):
            for tick in (0,256,512,768,1024):
                def get(key,src=bank):
                    wave=src[f"b0t{tick}_"+key]
                    dust=src[f"b1t{tick}_"+key]
                    return wave if branch=="wave" else dust if branch=="cold" else wave-dust
                for region,(low,high) in (("core",(0.,.3)),("bulk",(.6,2.1))):
                    use=(r>low)&(r<high)
                    chosen=(common>low)&(common<high)
                    norm=lambda arr:float(np.linalg.norm(arr[use]))
                    source=norm(get("J"))
                    raw=get("ind_P");staggered=get("P")
                    difference=get("readout")
                    def rr(arr):return norm(arr)/source
                    row=dict(grid=grid,seed=seed,branch=branch,tick=tick,region=region,
                            native=rr(staggered),collocated=rr(raw),independent_current_agreement=rr(get("J")-get("ind_J")),
                            face_reconstruction=rr(get("face")-get("native")),legacy_reconstruction=rr(get("cell")-get("ind_J")-raw),
                            difference=rr(difference),unexplained_over_difference=safe_ratio(norm(difference-get("stencil")),norm(difference)),
                            above_80pct_nyquist=window_power(difference[use]),fresh_H_over_J=rr(get("H")),
                            analytic_transport_error=norm(get("identity_error")),sector_stress_error=norm(get("sector_sum_error")))
                    for degree in (6,8,12,16,24):row[f"flux{degree}"]=rr(get(f"order{degree}",face)-get("J"))
                    rows.append(row)
                    for projection in ("cell-volume","centre-cubic"):
                        def reduce(arr):
                            if projection=="centre-cubic":return CubicSpline(r,arr)(common[chosen])
                            return ((arr*weights).reshape(-1,group).sum(1)/weights.reshape(-1,group).sum(1))[chosen]
                        denom=np.linalg.norm(reduce(get("ind_J")))
                        pair.append(dict(grid=grid,seed=seed,branch=branch,tick=tick,region=region,projection=projection,
                            source_rms=denom/sqrt(sum(chosen)),native=np.linalg.norm(reduce(staggered))/denom,
                            collocated=np.linalg.norm(reduce(raw))/denom,flux24=np.linalg.norm(reduce(get("order24",face)-get("J")))/denom,
                            numerator_rms=np.linalg.norm(reduce(raw))/sqrt(sum(chosen))))
                    for key in ("env","matter1","matter2","heavy"):
                        work=get("eta_"+key);rate=get("Jdot_"+key);div=get("div_"+key)
                        sector.append(dict(grid=grid,seed=seed,branch=branch,tick=tick,region=region,sector=key,
                             current_norm=norm(get("J_"+key)),total_current_norm=source,rate_norm=norm(rate),
                             stress_norm=norm(div),eta_norm=norm(work),transport_drive_norm=norm(get("Hdrive")),
                             relative=safe_ratio(norm(work),max(norm(div),norm(rate)))))
    return rows,pair,sector


def integrals(grid,seed):
    records=core.read(HERE/f"g{grid}-s{seed}-shell-work.csv")
    outputs=[]
    for center in sorted({float(row["centre"]) for row in records}):
        for branch in ("wave","cold","wave-minus-cold"):
            def series(name):
                parsed=[sorted([row for row in records if int(row["flag"])==flag and float(row["centre"])==center],
                              key=lambda row:int(row["tick"])) for flag in (0,1)]
                wave,dust=(np.array([float(row[name]) for row in subset]) for subset in parsed)
                if branch=="wave" or name=="clock":return wave
                return dust if branch=="cold" else wave-dust
            clock=series("clock");duration=clock[-1]
            for field,driver in (("J","stress_prediction"),("T","geometric drive"),("difference","weak_work_difference")):
                rates=series("stress_prediction")+series("hamiltonian_work") if driver=="geometric drive" else series(driver)
                change=series(field)[-1]-series(field)[0]
                fine=duration*(rates[0]+4*rates[1]+2*rates[2]+4*rates[3]+rates[4])/12
                coarse=duration*(rates[0]+4*rates[2]+rates[4])/6
                norm=max(abs(change),np.trapezoid(abs(rates),clock))
                outputs.append(dict(grid=grid,seed=seed,branch=branch,centre=center,field=field,change=change,
                       from_flux=fine,coarse_estimate=coarse,scale=norm,relative=safe_ratio(abs(change-fine),norm),
                       quadrature_spread=safe_ratio(abs(fine-coarse),norm)))
    return outputs


def main():
    locked()
    summaries=[];matched=[];sectors=[];work=[]
    for grid,seed in ((320,1),(640,1),(640,-1)):
        rows,pairs,terms=per_grid(grid,seed)
        summaries.extend(rows);matched.extend(pairs);sectors.extend(terms);work.extend(integrals(grid,seed))
    with workspace(640):
        local.table("readout-attribution.csv",summaries);local.table("common-shells.csv",matched)
        local.table("current-sectors.csv",sectors);local.table("integrated-flux.csv",work)
    print(len(summaries),len(matched),len(sectors),len(work))


if __name__=="__main__":main()
