"""Leading one-way and coherent round-trip rate comparison, from the two Newtonian momentum sources."""
from directional import HOME, BASE, Experiment, np, jf, sys, guard, table, fields, raw_bank, angles, roots_legendre, OBSERVER_R, LIGHT, csv
from split_tensor import invert_vector, harmonics
from directional import prepare

def shell_sums(radii,targets,degrees,charge):
    zones=np.searchsorted(targets,radii)
    upper=np.r_[targets,np.inf][zones];lower=np.r_[0.,targets][zones]
    near=charge/upper[:,None]*(radii[:,None]/upper[:,None])**degrees
    far=charge/radii[:,None]*(lower[:,None]/radii[:,None])**degrees
    left=np.stack([np.bincount(zones,weights=col,minlength=len(targets)+1)[:-1] for col in near.T],axis=1)
    right=np.stack([np.bincount(zones,weights=col,minlength=len(targets)+1)[1:] for col in far.T],axis=1)
    ratio=targets[:-1,None]/targets[1:,None]
    fw=ratio**(degrees+1); bw=ratio**degrees
    for index in range(1,len(targets)):
        left[index]+=left[index-1]*fw[index-1]
    for index in range(len(targets)-2,-1,-1):
        right[index]+=right[index+1]*bw[index]
    return left,right

def direct_current(radii,radial_weights,points,ell,src_r,src_t):
    angular=ell*(ell+1);normal=2*ell+1
    mass=radial_weights*radii**2
    def invert(degrees,source):
        near,far=shell_sums(radii,points,degrees,mass[:,None]*source)
        return (-(near+far)/(2*degrees+1),((degrees+1)*near-degrees*far)/(points[:,None]*(2*degrees+1)))
    plus=invert(ell[1:]-1,((src_r+(ell+1)*src_t)/normal)[:,1:])
    minus=invert(ell[1:]+1,((ell*src_t-src_r)/normal)[:,1:])
    mono=invert(ell[:1]+1,src_r[:,:1])
    radial,radial_pr=[np.column_stack([zero,ell[1:]*up-(ell[1:]+1)*down]) for zero,up,down in zip(mono,plus,minus)]
    polar=np.column_stack([np.zeros(len(points)),plus[0]+minus[0]])
    acceleration=radial_pr+(2*radial-angular*polar)/points[:,None]
    coord=points[:,None]
    longitudinal=np.zeros_like(radial);longitudinal_pr=longitudinal.copy()
    for term in (0,1):
        for interior in (True,False):
            exponent=(ell+2*term) if interior else (1-ell-2*term)
            exp_at_point=1-exponent
            source=((src_r*exponent+angular*src_t)/normal)*(.5*(-1/(2*ell-1) if not term else 1/(2*ell+3)))
            if interior:
                charge=mass[:,None]*source*(radii[:,None]**(2*term-1))
                part=shell_sums(radii,points,ell,charge)[0]*coord**(2-2*term)
            else:
                charge=mass[:,None]*source*radii[:,None]**(1-2*term)
                part=shell_sums(radii,points,ell,charge)[1]*coord**(2*term)
            longitudinal+=part
            longitudinal_pr+=part*exp_at_point/coord
    bt=-4*(polar-longitudinal/coord)
    bt[:,0]=0.
    return acceleration,-4*(radial-longitudinal_pr),bt,longitudinal,longitudinal_pr

def acceleration_sources(radii,host,wave,ell,mu,weights):
    val,der,_=angles(mu,ell)
    sources=[]
    for early in range(0,len(radii),128):
        sl=slice(early,early+128);r=radii[sl,None]
        def get(part):
            size=part[0].shape[1]
            return part[1][sl]@val[:,:size].T,part[0][sl]@der[:,:size].T/r,part[2][sl]@val[:,:size].T
        ur,ut,du=get(host);wr,wt,dw=get(wave)
        rows=[]
        for radial,polar in ((du*wr,du*wt),(dw*ur,dw*ut)):
            raw=(radial*weights)@val*(2*ell+1)
            other=(polar*weights)@der*(2*ell+1)
            other[:,0]=0;other[:,1:]/=(ell*(ell+1))[1:]
            rows.append(np.stack((raw,other),axis=1))
        sources.append(np.stack(rows,axis=1))
    return np.concatenate(sources)

def experiment(order,mode,ray_order):
    guard()
    box=Experiment(0,1);mass,edges=raw_bank(box);wave_edges=box.lab.run.el.right*box.bg.length
    ell=np.arange(0,133,2); mu,weight=roots_legendre(160);weight/=2
    radii=OBSERVER_R; start,end=6.,8.3;z=1.5; span=end-start
    borders=np.unique(np.r_[edges,wave_edges])
    knots=np.r_[start,np.sqrt(borders[(borders>radii[0])&(borders<radii[1])]**2-z*z),end]
    nodes,rule=roots_legendre(ray_order)
    ray=(knots[:-1,None]+np.diff(knots)[:,None]*(1+nodes)/2).ravel()
    ds=(np.diff(knots)[:,None]*rule/2).ravel()
    ray_points=np.r_[start,ray,end]
    points=np.hypot(ray_points,z)
    cuts=np.unique(np.r_[0.,borders,points]);nd,wt=roots_legendre(order)
    rad=(cuts[:-1,None]+np.diff(cuts)[:,None]*(1+nd)/2).ravel()
    integral=(np.diff(cuts)[:,None]*wt/2).ravel()
    pair=fields(box,mass,edges,rad,mode,order)
    source=acceleration_sources(rad,*pair,ell,mu,weight)
    sky_r,sky_t,_=angles(z/points,ell)
    projr=z/points; projs=ray_points/points
    allsource=[];controls=[]
    for name,bank in (('ordinary',source[:,0]),('wave',source[:,1]),('both',source.sum(axis=1))):
        acceleration,shift_r,shift_t,longitudinal,long_pr=direct_current(rad,integral,points,ell,bank[:,0],bank[:,1])
        readout=(acceleration*sky_r).sum(axis=1)
        shift=projs*(shift_r*sky_r).sum(axis=1)+projr*(shift_t*sky_t).sum(axis=1)
        if name=='both':
            packet,gr,gw,gm=prepare(box,order,mode,full=True)
            _,probes,solved,at,_,_=packet
            for obs,idx in enumerate((0,-1)):
                point=points[idx];i=np.argmin(np.abs(probes-point))
                assert abs(probes[i]-point)<1.e-11
                point=probes[i];eps=.0005
                hi,lo=[np.argmin(abs(probes-point*(1+sign*eps))) for sign in (1,-1)]
                deriv=(solved[hi,2]-solved[lo,2])/(2*point*eps)
                xx,yy=invert_vector(gr,gw,harmonics(ell,gm),point,harmonics(ell,at)[i],ell)
                alt_r=-2*(xx[0]-2*deriv/3);alt_t=-2*(yy[0]-2*solved[i,2]/(3*point));alt_t[0]=0.
                near,far=shell_sums(gr,np.array([point]),ell,gm[:,0]*(gw*gr**2)[:,None])
                trace_slip=-(near+far)[0]+3*longitudinal[idx]
                trace_slope=((ell+1)*near-ell*far)[0]/point+3*long_pr[idx]
                exact_shift=-2*(xx[0]-2*trace_slope/3)
                norm=lambda rr,tt:np.sqrt(np.sum((rr**2+ell*(ell+1)*tt**2)/(2*ell+1)))
                controls.append(dict(observer=obs,relative_gravity_vs_mass_current=norm(alt_r-shift_r[idx],alt_t-shift_t[idx])/norm(shift_r[idx],shift_t[idx]),
                                     relative_trace_slip=norm(trace_slip-solved[i,2],0.)/norm(solved[i,2],0.),
                                     relative_exact_slope_shift=norm(exact_shift-shift_r[idx],alt_t-shift_t[idx])/norm(shift_r[idx],shift_t[idx]),
                                     radial_monopole=shift_r[idx,0],source_scale=norm(shift_r[idx],shift_t[idx])))
        allsource.append((name,readout,shift))
    with (HOME/f'clock-{mode}-{order}.csv').open(newline='') as src:
        saved=list(csv.DictReader(src))[-1]
    records=[]
    factor=LIGHT**(-4)
    for name,acc,shift in allsource:
        for direction in ('out','in','roundtrip'):
            if direction=='roundtrip':
                landing=2*span**2*acc[0];integrated=-4*span*(ds@acc[1:-1]); dragging=0.
                doppler=2*span*(end*acc[-1]-start*acc[0])
                static=rods=0.
            else:
                outward=direction=='out';sgn=1 if outward else -1
                landing=.5*span**2*acc[-1 if outward else 0]
                integrated=-2*ds@((ray-start if outward else end-ray)*acc[1:-1])
                dragging=sgn*(ds@shift[1:-1])
                doppler=sgn*span*(end*acc[-1] if outward else start*acc[0])
                static=sgn*float(saved['coordinate']) if name=='both' else 0.
                rods=sgn*float(saved['matched']) if name=='both' else 0.
            propagation=(landing+integrated+dragging)*factor
            records.append(dict(sources=name,direction=direction,ray_nodes=len(ray),clock_accel_difference=(acc[-1]-acc[0])/LIGHT**2,
                                receiver_evolution=landing*factor,integrated_scalar=integrated*factor,
                                integrated_shift=dragging*factor,propagation=propagation,rod_doppler=doppler*factor,
                                coordinate_total=static+propagation if name=='both' else '',
                                maintained_rods_total=rods+propagation+doppler*factor if name=='both' else ''))
    table(HOME/f'link-{mode}-{order}-{ray_order}.csv',records,True)
    table(HOME/f'current-trace-{mode}-{order}-{ray_order}.csv',controls,True)
if __name__=='__main__':
    experiment(int(sys.argv[1]),sys.argv[2],int(sys.argv[3]))
