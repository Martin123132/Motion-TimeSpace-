"""Separate the longitudinal scalar, solenoidal vector, and transverse tensor on the isolated flat slice."""
from directional import HOME, Experiment, OBSERVER_R, np, sys, table, prepare, guard

def harmonics(degrees,projections):
    norm=1/(2*degrees+1);angular=degrees*(degrees+1)
    output=projections[...,3:6,:].copy()
    output[...,0,:]/=norm
    output[...,1,1:]/=(norm*angular)[1:]
    output[...,2,1:]/=(norm*angular*(angular-2))[1:]
    output[...,1:,0]=0.
    return output

def invert_vector(radius,weight,profile,point,local,degrees):
    angular=degrees*(degrees+1)
    aa,bb,dd=profile.transpose(1,0,2)
    ar,bt=3*aa-angular*bb,3*bb-.5*aa-.5*(angular-2)*dd
    factors=2*degrees+1
    def integrate(index,source,term,edge):
        rad=radius[:,None]
        kernel=(np.minimum(rad,point)/np.maximum(rad,point))**index/np.maximum(rad,point)
        left=radius<point
        near=point*edge+(weight[left]*radius[left])@(kernel[left]*(term[left]-(index+2)*source[left]))
        far=-point*edge+(weight[~left]*radius[~left])@(kernel[~left]*(term[~left]-(1-index)*source[~left]))
        return np.array([-(near+far)/(2*index+1),((index+1)*near-index*far)/((2*index+1)*point)])
    plus=integrate(degrees[1:]-1,((aa+(degrees+1)*bb)/factors)[:,1:],
                        ((ar+(degrees+1)*bt)/factors)[:,1:],((local[0]+(degrees+1)*local[1])/factors)[1:])
    minus=integrate(degrees[1:]+1,((degrees*bb-aa)/factors)[:,1:],
                        ((degrees*bt-ar)/factors)[:,1:],((degrees*local[1]-local[0])/factors)[1:])
    spin0=integrate(np.array([1]),aa[:,:1],ar[:,:1],local[0,:1])
    radial=np.column_stack([spin0,degrees[1:]*plus-(degrees[1:]+1)*minus])
    polar=np.column_stack([np.zeros(2),plus+minus])
    return radial,polar

def decompose(degrees,radius,weight,profile,point,local,slip,first,second):
    angular=degrees*(degrees+1)
    radial,polar=invert_vector(radius,weight,profile,point,local,degrees)
    vr=radial[0]-2*first/3; vrp=radial[1]-2*second/3
    vt=polar[0]-2*slip/(3*point);vtp=polar[1]-2*(first/point-slip/point**2)/3
    vt[0]=vtp[0]=0.
    div=vrp+2*vr/point-angular*vt/point
    scalar=np.array([2*(second-first/point)/3+angular*slip/(3*point**2),first/point-slip/point**2,slip/point**2])
    vector=np.array([2*vrp-2*div/3,vtp+(vr-vt)/point,2*vt/point])
    scalar[1:,0]=vector[1:,0]=0.
    return scalar,vector,local-scalar-vector,div

def norm2(degrees,block):
    angular=degrees*(degrees+1)
    return np.array([1.5,2,.5])@((block**2*np.array([np.ones_like(degrees),angular,angular*(angular-2)])/(2*degrees+1)).sum(axis=1))

def run(order,mode):
    (degrees,probes,solved,at,_,_),radii,weights,moments=prepare(Experiment(0,1),order,mode,full=True)
    profile=harmonics(degrees,moments);nodes=harmonics(degrees,at)
    rows=[];modes=[]
    for obs,point in enumerate(OBSERVER_R):
        index=np.searchsorted(probes,point)
        local=nodes[index];scale=np.sqrt(norm2(degrees,local))
        for eps in (.001,.0005):
            lo,hi=(np.searchsorted(probes,point*(1+sign*eps)) for sign in (-1,1))
            slip=solved[index,2]
            first=(solved[hi,2]-solved[lo,2])/(2*eps*point)
            second=(solved[hi,2]-2*slip+solved[lo,2])/(eps*point)**2
            scalar,vector,tensor,div=decompose(degrees,radii,weights,profile,point,local,slip,first,second)
            terms=[np.sqrt(norm2(degrees,arr))/scale for arr in (scalar,vector,tensor,vector+tensor)]
            overlap=(norm2(degrees,vector+tensor)-norm2(degrees,vector)-norm2(degrees,tensor))/(2*scale*scale)
            rows.append(dict(observer=obs,mode=mode,order=order,step=eps,source_rms=scale,scalar_ratio=terms[0],
                vector_ratio=terms[1],tensor_ratio=terms[2],nonscalar_ratio=terms[3],local_vector_tensor_overlap=overlap,
                relative_div_vector=np.sqrt(np.sum(div**2/(2*degrees+1)))/scale))
            if eps==.0005:
                for pos,degree in enumerate(degrees):
                    modes.append(dict(observer=obs,ell=degree,**{group+'_'+comp:arr[j,pos] for group,arr in
                        (('scalar',scalar),('vector',vector),('tensor',tensor),('source',local)) for j,comp in enumerate(('rr','rt','shear'))}))
    table(HOME/f'split-{mode}-{order}.csv',rows,True)
    table(HOME/f'split-modes-{mode}-{order}.csv',modes,True)
if __name__=='__main__':
    guard()
    run(int(sys.argv[1]),sys.argv[2])
