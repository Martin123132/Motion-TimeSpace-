"""Separate ray sampling, stored epoch interpolation, and evolution-step changes on the same grid."""
from directional import HOME,np,table,guard,csv
from scipy.interpolate import CubicSpline
from scipy.integrate import simpson

def static():
    with (HOME/'link-volume-8-4.csv').open(newline='') as stream:
        return {r['direction']:r for r in csv.DictReader(stream) if r['sources']=='both'}

def close(count,time_stride,ray_stride):
    ref=static()
    with np.load(HOME/f'flight-readout-{count}.npz') as data:
        position=data['line'][::ray_stride];zeta=position-position[0];span=zeta[-1]
        history=(data['wave']+data['ordinary'])[::time_stride,::ray_stride]
    eta=np.arange(0,2*count+1,time_stride)/count
    grids=zeta/span
    output=[]
    for direction in ('out','in','roundtrip'):
        arrival=2. if direction=='roundtrip' else 1.
        emitter=-1 if direction=='in' else 0; receiver=-1 if direction=='out' else 0
        splines=CubicSpline(eta,history,axis=0)
        signs=1 if direction!='in' else -1
        start=position[emitter]*splines(0.,1)[emitter]
        end=position[receiver]*splines(arrival,1)[receiver]
        doppler=signs*(end-start)/span
        if direction=='roundtrip':
            doppler=(2*position[-1]*splines(1.,1)[-1]-end-start)/span
        endpoint=splines(arrival)[receiver]-splines(0.)[emitter]
        first=np.diag(splines(grids if direction!='in' else 1-grids,1))
        if direction=='roundtrip':
            first=first+np.diag(splines(2-grids,1))
        integrated=-2*simpson(first,x=grids)
        forecast=ref[direction]
        passive=endpoint+integrated+float(forecast['integrated_shift'])
        static_rods=float(forecast['maintained_rods_total'])-float(forecast['propagation'])-float(forecast['rod_doppler'])
        result=static_rods+passive+doppler
        output.append(dict(steps_per_flight=count,time_stride=time_stride,ray_stride=ray_stride,direction=direction,endpoint=endpoint,
                    scalar_integral=integrated,doppler=doppler,log_rate=result,relative_to_launch=result/float(forecast['maintained_rods_total'])-1))
    return output

if __name__=='__main__':
    guard()
    results=[]
    for count in (8,16):
        for ts in ((1,) if count==8 else (1,2)):
            for rs in ((1,) if count==8 else (1,2)):
                results.extend(close(count,ts,rs))
    table(HOME/'flight-sampling.csv',results,True)
