"""Analytic compact scalar, transverse-vector, and TT fields exercise the isolated projectors."""
from directional import HOME,np,solve,roots_legendre,table,guard
from split_tensor import decompose,norm2
from numpy.polynomial import Polynomial

def analytic(rad,ell):
    active=rad<1
    x=Polynomial([0.,1.]); cutoff=(1-x*x)**7
    phi=x**(ell+2)*cutoff
    stream=.7*x**(ell+3)*cutoff
    seed=.28*x**(ell+2)*cutoff
    def val(poly,degree=0):
        return np.where(active,poly.deriv(degree)(rad),0.)
    pot,first,second=(val(phi,order) for order in (0,1,2))
    angular=ell*(ell+1)
    scalar=np.array([2*(second-first/rad)/3+angular*pot/(3*rad**2),first/rad-pot/rad**2,pot/rad**2])
    if ell==0:
        scalar[1:]=0
        return pot,first,second,scalar,np.zeros_like(scalar),np.zeros_like(scalar)
    vr=angular*val(stream)/rad
    vrp=angular*(val(stream,1)/rad-val(stream)/rad**2)
    vt=val(stream,1)+val(stream)/rad
    vtp=val(stream,2)+val(stream,1)/rad-val(stream)/rad**2
    vector=np.array([2*vrp,vtp+(vr-vt)/rad,2*vt/rad])
    rr=val(seed)
    rt=(rad*val(seed,1)+3*rr)/angular
    rtp=(rad*val(seed,2)+4*val(seed,1))/angular
    shear=2*(rad*rtp+3*rt-rr/2)/(angular-2)
    return pot,first,second,scalar,vector,np.array([rr,rt,shear])

def test():
    degrees=np.arange(0,9,2);angular=degrees*(degrees+1);normal=2*degrees+1
    proj=np.array([1/normal,angular/normal,angular*(angular-2)/normal])
    points=np.array([.27,.63,1.18]);cuts=np.unique(np.r_[0.,np.linspace(0,1,11),points])
    nd,rule=roots_legendre(20);radii=(cuts[:-1,None]+np.diff(cuts)[:,None]*(nd+1)/2).ravel()
    weights=(np.diff(cuts)[:,None]*rule/2).ravel()
    output=[]
    for offset,ell in enumerate(degrees):
        *_,ss,vv,tt=analytic(radii,ell)
        p,p1,p2,sp,vp,tp=analytic(points,ell)
        for kind in ('scalar','vector','tensor','mixed'):
            factors=np.array([float(kind==key or kind=='mixed') for key in ('scalar','vector','tensor')])
            if ell==0 and kind in ('vector','tensor'):
                continue
            local=factors[0]*sp+factors[1]*vp+factors[2]*tp;bulk=factors[0]*ss+factors[1]*vv+factors[2]*tt
            profile=np.zeros((len(radii),3,len(degrees)));profile[:,:,offset]=bulk.T
            moments=np.zeros((len(radii),7,len(degrees)));moments[:,3:6,:]=profile*proj
            solved=solve(points,radii,weights,moments,np.zeros((len(points),len(degrees))),degrees)
            for idx,point in enumerate(points):
                here=np.zeros((3,len(degrees)));here[:,offset]=local[:,idx]
                jet=np.eye(len(degrees))[offset]*factors[0]
                scalar,vector,tensor,div=decompose(degrees,radii,weights,profile,point,here,solved[idx,2],p1[idx]*jet,p2[idx]*jet)
                scale=max(1.e-7,np.abs(bulk).max())
                output.append(dict(mode=kind,ell=ell,radius=point,slip_absolute=np.max(abs(solved[idx,2]-p[idx]*jet)),
                   scalar_relative=np.max(abs(scalar[:,offset]-factors[0]*sp[:,idx]))/scale,
                   vector_relative=np.max(abs(vector[:,offset]-factors[1]*vp[:,idx]))/scale,
                   tensor_relative=np.max(abs(tensor[:,offset]-factors[2]*tp[:,idx]))/scale,div_relative=np.max(abs(div))/scale))
    table(HOME/'analytic-projection-controls.csv',output,True)

if __name__=='__main__':
    guard()
    test()
