"""Replay the retained reciprocal Newtonian dynamics over the photon flight, independently of the curvature law."""
from directional import HOME, BASE, np, Experiment, sys, LIGHT, guard, table, angles, jf, csv, digest
from matched_io import Evolution, advance, gather_force, multipoles, keep
from scipy.constants import Julian_year,parsec
import io

def packet(path,**arrays):
    buf=io.BytesIO()
    np.savez_compressed(buf,**arrays)
    keep(path,buf.getvalue(),True)

def run(count,arm,source):
    assert count in (8,16,32) and source in ('raw','represented') and arm in ('reset','coupled')
    name=HOME/f'flight-{count}-{arm}-{source}.npz'
    assert not name.exists()
    assert (HOME/'link-volume-8-4.csv').exists()
    guard()
    box=Experiment(0,1);obj=box.obj;lab=box.lab
    line=np.linspace(6.,8.3,count+1);points=np.hypot(line,1.5);eyes=angles(1.5/points,2*np.arange(33))[0]
    targets=np.unique(np.r_[box.targets,points])
    wave_ids=np.searchsorted(targets,box.native);observer_ids=np.searchsorted(targets,points)
    dt=(line[-1]-line[0])*parsec/(LIGHT*1e6*Julian_year*count)
    massmap=box.mass[source];ii,jj=np.nonzero(massmap);mass=massmap[ii,jj]
    radius=box.r[ii];mu=box.mu[jj]
    xx=radius*np.sqrt(1-mu**2);zz=radius*mu;vx=np.zeros_like(xx);vz=vx.copy()
    start=multipoles(radius,mu,mass,targets);previous=start
    external=box.field+(box.static if source=='raw' else 0.)
    initial=lab.initial[arm];state=initial.copy();mom=obj.moment(state)
    waves=[state.copy()];position=[np.zeros(len(points))];norm=0.
    acceleration=gather_force(lab,box.native,box.wm(state),xx,zz)
    solver=Evolution(obj,dt/obj.unit_myr,lab.initial['reset'])
    for step in range(2*count):
        guard()
        vx+=.5*dt*acceleration[0];vz+=.5*dt*acceleration[1];xx+=dt*vx;zz+=dt*vz
        radius=np.hypot(xx,zz);mu=np.abs(zz)/radius
        now=multipoles(radius,mu,mass,targets)
        drive=external+((.5*(now+previous)-start)[wave_ids]@box.harm.T)/box.bg.vel**2
        state,mom,_,_=advance(obj,solver,state,mom,drive,dt/obj.unit_myr)
        waves.append(state.copy())
        position.append(np.sum((now-start)[observer_ids]*eyes,axis=1)/LIGHT**2)
        acceleration=gather_force(lab,box.native,box.wm(state),xx,zz)
        vx+=.5*dt*acceleration[0];vz+=.5*dt*acceleration[1]
        norm=max(norm,abs(np.vdot(state,state).real/np.vdot(initial,initial).real-1))
        previous=now
    assert norm<1.e-10
    packet(name,wave=np.stack(waves),ordinary=np.stack(position),line=line,dt_Myr=dt,worst_norm=norm)
    print(count,arm,source,dt,norm,flush=True)

def reduce(count):
    from scipy.integrate import simpson
    box=Experiment(0,1)
    packets={}
    for arm in ('reset','coupled'):
        for source in ('raw','represented'):
            with np.load(HOME/f'flight-{count}-{arm}-{source}.npz') as saved:
                packets[arm,source]={k:saved[k] for k in saved.files}
    line=packets['reset','raw']['line'];points=np.hypot(line,1.5);d=line[-1]-line[0];index=np.arange(count+1)
    deg=2*np.arange(33)
    eyes=angles(1.5/points,deg)[0]
    kernel= (np.minimum(points[:,None],box.native)/np.maximum(points[:,None],box.native))[:,:,None]**deg/np.maximum(points[:,None],box.native)[:,:,None]
    kernel*=(-jf.ls.G/LIGHT**2)*eyes[:,None,:]
    wave=[];ordinary=[]
    for arm in ('coupled','reset'):
        raw=packets[arm,'raw'];rep=packets[arm,'represented']
        values=[]
        for first,second in zip(raw['wave'],rep['wave']):
            density=(box.obj.sky(first-second).conj()*box.obj.sky(first+second)).real
            moments=box.lab.mesh.mscale*box.bg.sqrt[:,None]**2*((density*box.bg.aw)@box.harm)
            values.append(np.einsum('pnl,nl->p',kernel,moments))
        wave.append(np.stack(values));ordinary.append(raw['ordinary']-rep['ordinary'])
    qw=wave[0]-wave[1];qo=ordinary[0]-ordinary[1]
    packet(HOME/f'flight-readout-{count}.npz',line=line,ordinary=qo,wave=qw)
    rows=[]
    with (HOME/'link-volume-8-4.csv').open(newline='') as stream:
        static={r['direction']:r for r in csv.DictReader(stream) if r['sources']=='both'}
    coord=float(static['out']['coordinate_total'])-float(static['out']['propagation'])
    rods=float(static['out']['maintained_rods_total'])-float(static['out']['propagation'])-float(static['out']['rod_doppler'])
    def derivative(arr):
        result=np.empty_like(arr)
        for t in range(len(arr)):
            win=np.clip(t-2,0,len(arr)-5)+np.arange(5)
            dx=win-t
            stencil=np.linalg.solve(dx[None,:]**np.arange(5)[:,None],np.array([0.,1.,0.,0.,0.]))
            result[t]=count*stencil@arr[win]
        return result
    for key,history in (('wave',qw),('ordinary',qo),('both',qw+qo)):
        gradient=derivative(history)
        for direction in ('out','in','roundtrip'):
            sgn=1 if direction!='in' else -1
            sites=index if sgn==1 else count-index
            boundary=history[count,sites[-1]]-history[0,sites[0]]
            integral=-2*simpson(gradient[index,sites],dx=1/count)
            doppler=sgn*(line[sites[-1]]*gradient[count,sites[-1]]-line[sites[0]]*gradient[0,sites[0]])/d
            if direction=='roundtrip':
                boundary=history[2*count,0]-history[0,0]
                integral+=-2*simpson(gradient[count+index,count-index],dx=1/count)
                doppler+=(line[-1]*gradient[count,-1]-line[0]*gradient[2*count,0])/d
            propagation=boundary+integral;shift=float(static[direction]['integrated_shift'])
            constant=0 if direction=='roundtrip' else sgn
            rows.append(dict(nodes=count,source=key,direction=direction,receiver_evolution=boundary,integrated_scalar=integral,
                        maintained_doppler=doppler,scalar_propagation=propagation,
                        coordinate_with_launch_shift=constant*coord+propagation+shift if key=='both' else '',
                        maintained_with_launch_shift=constant*rods+propagation+shift+doppler if key=='both' else ''))
    table(HOME/f'finite-link-{count}.csv',rows,True)

if __name__=='__main__':
    if sys.argv[1]=='reduce':
        reduce(int(sys.argv[2]))
    else:
        run(int(sys.argv[1]),sys.argv[2],sys.argv[3])
