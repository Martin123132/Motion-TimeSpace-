"""Compare the previous degree-64 clock kernel and the new complete product kernel at identical endpoints."""
from light_link import Experiment,raw_bank,np,fields,direct_current,acceleration_sources,angles,roots_legendre,OBSERVER_R,LIGHT,HOME,BASE,guard,table,csv
from scipy.constants import Julian_year,parsec

def check(box,mode,order):
    mass,edges=raw_bank(box);ell=np.arange(0,133,2)
    cuts=np.unique(np.r_[0.,edges,box.lab.run.el.right*box.bg.length,OBSERVER_R]);nd,wt=roots_legendre(order)
    r=(cuts[:-1,None]+np.diff(cuts)[:,None]*(1+nd)/2).ravel();weights=(np.diff(cuts)[:,None]*wt/2).ravel()
    pair=fields(box,mass,edges,r,mode,order);mu,aw=roots_legendre(160)
    sky=angles(1.5/OBSERVER_R,ell)[0]
    sources=acceleration_sources(r,*pair,ell,mu,aw/2)[:,1]
    acceleration,*_=direct_current(r,weights,OBSERVER_R,ell,sources[:,0],sources[:,1])
    measured=np.diff(sky*acceleration,axis=0)[0]*(1e6*Julian_year/parsec/LIGHT)**2
    with (BASE/'continuum-host-response.csv').open(newline='') as handle:
        old=next(row for row in csv.DictReader(handle) if row['arm']=='paired' and row['mode']==mode and int(row['quadrature'])==order)
    ref=float(old['clock_acceleration'])
    return dict(geometry=mode,order=order,prior=ref,matched_clock_kernel=measured[ell<=64].sum(),
                extended_clock_kernel=measured.sum(),high_band=measured[ell>64].sum(),
                same_kernel_relative=measured[ell<=64].sum()/ref-1,full_relative=measured.sum()/ref-1)

if __name__=='__main__':
    guard()
    box=Experiment(0,1)
    table(HOME/'kernel-bandwidth.csv',[check(box,mode,q) for mode,q in (('volume',4),('volume',8),('radius',8))],True)
