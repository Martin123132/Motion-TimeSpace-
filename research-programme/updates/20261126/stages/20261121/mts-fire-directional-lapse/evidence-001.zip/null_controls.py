"""Independent pulse-transfer/Jacobi test with moving endpoints, a reflector, and a time-dependent shift."""
from directional import HOME,np,table,guard
from scipy.integrate import solve_ivp,quad
from scipy.optimize import brentq

def static(position):
    return .021*position**2-.07*position

def acceleration(position):
    return .16-.09*position+.04*position**2

def shift(position):
    return .08+.035*position

def clock_rate(amp,time,radius,moving):
    pos=radius*(1+.5*amp*time**2*acceleration(radius)) if moving else radius
    speed=amp*radius*time*acceleration(radius) if moving else 0.
    pot=amp*(static(pos)+.5*time**2*acceleration(pos))
    return np.sqrt(np.exp(2*pot)-2*amp*time*shift(pos)*speed-np.exp(-2*pot)*speed**2)

def transfer(amp,departure,first,last,moving):
    def world(time,point):
        return point*(1+.5*amp*time*time*acceleration(point)) if moving else point
    start=world(departure,first);sign=np.sign(last-first)
    def ode(time,pos):
        pot=amp*(static(pos)+.5*time**2*acceleration(pos))
        cross=amp*time*shift(pos)
        return (-cross+sign*np.sqrt(cross**2+1))*np.exp(2*pot)
    def arrived(time,pos):
        return pos[0]-world(time,last)
    arrived.terminal=True
    sol=solve_ivp(ode,(departure,departure+2),[start],events=arrived,method='DOP853',rtol=2e-13,atol=1e-15,max_step=.16)
    assert sol.success and len(sol.t_events[0])==1
    return sol.t_events[0][0]

def rate(amp,direction,moving):
    inner,outer=1.1,1.91
    start,end=(outer,inner) if direction=='in' else (inner,outer)
    def finish(time):
        last=transfer(amp,time,start,end,moving)
        return transfer(amp,last,end,start,moving) if direction=='roundtrip' else last
    delta=.007
    arrival=finish(0.)
    elapsed=(finish(-2*delta)-8*finish(-delta)+8*finish(delta)-finish(2*delta))/(12*delta)
    return np.log(clock_rate(amp,arrival,start if direction=='roundtrip' else end,moving)*elapsed/clock_rate(amp,0,start,moving))

def estimate(direction,moving):
    inner,outer=1.1,1.91;span=outer-inner
    if direction=='roundtrip':
        return (2*span**2*acceleration(inner)-4*span*quad(acceleration,inner,outer)[0]+
                2*span*(outer*acceleration(outer)-inner*acceleration(inner))*moving)
    first,last=(inner,outer) if direction=='out' else (outer,inner)
    sign=np.sign(last-first)
    return (static(last)-static(first)+.5*span**2*acceleration(last)
           -2*quad(lambda s:s*acceleration(first+sign*s),0.,span)[0]
           +sign*quad(shift,inner,outer)[0]+sign*span*last*acceleration(last)*moving)

if __name__=='__main__':
    guard();rows=[]
    for direction in ('out','in','roundtrip'):
        for moving in (False,True):
            pred=estimate(direction,moving)
            for amp in (.006,.003,.0015):
                actual=(rate(amp,direction,moving)-rate(-amp,direction,moving))/(2*amp)
                rows.append(dict(direction=direction,moving=moving,amplitude=amp,predicted=pred,direct=actual,
                                 absolute_error=abs(actual-pred)))
    table(HOME/'exact-null-controls.csv',rows,True)
