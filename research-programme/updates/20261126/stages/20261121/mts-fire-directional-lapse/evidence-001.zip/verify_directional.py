"""Read-only scientific and integrity checks; --seal is for first creation only."""
import json
import sys
import re
from directional import HOME,BASE,EXPECTED,pinned,digest,np,csv
from matched_io import keep
from scipy.constants import Julian_year,parsec

def rows(name,root=HOME):
    with (root/name).open(newline='') as handle:
        data=list(csv.DictReader(handle))
    assert data and all(None not in row and None not in row.values() for row in data),name
    return data

def find(data,**kwargs):
    selection=[row for row in data if all(row[k]==str(value) for k,value in kwargs.items())]
    assert len(selection)==1,kwargs
    return selection[0]

def f(row,key):
    return float(row[key])

def save_json(name,data):
    keep(HOME/name,(json.dumps(data,sort_keys=True,indent=2)+'\n').encode(),True)

def verify(seal):
    assert __debug__
    for name,expected in pinned.items():
        assert digest(BASE/name)==expected,name
    for file in HOME.iterdir():
        assert file.is_file() and file.suffix not in ('.work','.part','.tmp','.pyc'),file
        if file.suffix=='.py':compile(file.read_bytes(),str(file),'exec')
        if file.suffix=='.md':
            for link in re.findall(r'\[[^\]]+\]\(([^)]+)\)',file.read_text(encoding='utf-8')):
                assert link.startswith('https://') or (HOME/link).is_file(),(file,link)
        if file.suffix=='.csv':rows(file.name)
    report={'predecessor':EXPECTED,'predecessor_files':len(pinned)}
    max_shell=max_duality=max_exact=max_mode=max_trace=max_shift=0.
    splits=[]
    for geometry,order,ray in (('volume',4,3),('volume',8,4),('radius',8,4)):
        key=f'{geometry}-{order}'
        data=rows(f'clock-{key}.csv');modes=rows(f'multipoles-{key}.csv')
        old=find(rows('isolated-area-clock.csv',BASE),model=geometry,order=order)
        rate=find(data,observer='outer-minus-inner')
        max_shell=max(max_shell,abs(f(rate,'monopole')/f(old,'lapse_coordinate')-1))
        for obs in (0,1):
            values=[row for row in modes if row['observer']==str(obs)]
            assert [int(row['ell']) for row in values]==list(range(0,133,2))
            max_duality=max(max_duality,sum(abs(f(v,'spatial')-f(v,'direct')) for v in values)/sum(abs(f(v,'spatial')) for v in values))
            exact=[v for v in rows('exact-normal.csv') if v['geometry']==geometry and int(v['order'])==order and int(v['obs'])==obs]
            assert len(exact)==len(values)
            max_exact=max(max_exact,sum(abs(f(v,'weak')-f(v,'direct')) for v in exact)/sum(abs(f(v,'weak')) for v in exact))
            eyes=np.polynomial.legendre.legvander(1.5/np.hypot((6.,8.3)[obs],1.5),132).ravel()[::2]
            assert abs(sum((f(v,'weak')-f(v,'gauss'))*p for v,p in zip(exact,eyes)))<1e-27
            clock=find(data,observer=obs)
            max_mode=max(max_mode,abs(sum(f(v,'contribution') for v in values)/f(clock,'coordinate')-1))
            assert abs(f(clock,'matched')-f(clock,'coordinate')-f(clock,'circumference')-f(clock,'height'))<1e-29
        assert f(rate,'coordinate')>0>f(rate,'matched')
        traces=rows(f'current-trace-{key}-{ray}.csv')
        max_trace=max(max_trace,max(f(r,'relative_trace_slip') for r in traces))
        max_shift=max(max_shift,max(f(r,'relative_exact_slope_shift') for r in traces))
        links=rows(f'link-{key}-{ray}.csv')
        for direction in ('in','out','roundtrip'):
            whole=find(links,direction=direction,sources='both')
            for col in ('receiver_evolution','integrated_scalar','integrated_shift','rod_doppler'):
                subtotal=sum(f(find(links,direction=direction,sources=src),col) for src in ('ordinary','wave'))
                assert abs(subtotal-f(whole,col))<3e-29
            assert f(whole,'maintained_rods_total')<0
        assert f(find(links,sources='both',direction='out'),'integrated_shift')==-f(find(links,sources='both',direction='in'),'integrated_shift')
        assert f(find(links,sources='both',direction='roundtrip'),'integrated_shift')==0
        wave=find(links,sources='wave',direction='out')
        oldcurv=find(rows('continuum-host-response.csv',BASE),arm='paired',mode=geometry,quadrature=order)
        band=find(rows('kernel-bandwidth.csv'),geometry=geometry,order=order)
        assert abs(f(band,'matched_clock_kernel')/f(oldcurv,'clock_acceleration')-1)<2e-7
        assert abs(f(wave,'clock_accel_difference')*(1e6*Julian_year/parsec)**2/f(band,'extended_clock_kernel')-1)<2e-7
        assert abs(f(band,'high_band')-(f(band,'extended_clock_kernel')-f(band,'matched_clock_kernel')))<1e-26
        if order==8:
            split=rows(f'split-{key}.csv')
            for obs in (0,1):
                fine=find(split,observer=obs,step=.0005);coarse=find(split,observer=obs,step=.001)
                assert .06<f(fine,'nonscalar_ratio')<.07 and f(fine,'relative_div_vector')<1e-7
                assert abs(f(fine,'tensor_ratio')-f(coarse,'tensor_ratio'))<1e-6
                splits.append([geometry,obs,f(fine,'vector_ratio'),f(fine,'tensor_ratio')])
    assert max_shell<1e-12 and max_exact<1e-11 and max_mode<1e-12 and max_trace<1e-11 and max_shift<1e-10
    report.update(monopole_relative=max_shell,original_gauss_normal_gate=max_duality<1e-11,gauss_normal_duality=max_duality,
                  exact_angular_normal_duality=max_exact,sum_of_modes=max_mode,trace_relative=max_trace,
                  current_shift_relative=max_shift,angular_rms_ratios=splits)
    analytic=rows('analytic-projection-controls.csv');null=rows('exact-null-controls.csv')
    assert {r['mode'] for r in analytic}=={'scalar','vector','tensor','mixed'} and len(analytic)==54
    assert max(f(r,k) for r in analytic for k in ('slip_absolute','scalar_relative','vector_relative','tensor_relative','div_relative'))<1e-10
    for direction in ('in','out','roundtrip'):
        for moving in ('False','True'):
            trip=[f(find(null,direction=direction,moving=moving,amplitude=amp),'absolute_error') for amp in (.006,.003,.0015)]
            assert trip[-1]<1e-7 and all(3.5<a/b<4.5 for a,b in zip(trip,trip[1:]))
    rod_err=0.
    for model in ('radius','volume'):
        for obs in (0,1):
            row=find(rows('rod-roots.csv'),mode=model,observer=obs,amplitude=.0005)
            ref=find(rows(f'clock-{model}-8.csv'),observer=obs)
            target=f(ref,'circumference')+f(ref,'height')
            assert abs(f(row,'split_integral_prediction')/target-1)<1e-5
            rod_err=max(rod_err,abs(f(row,'relocation')/target-1))
    assert rod_err<1e-5
    report.update(analytic_projection_controls=len(analytic),null_controls=len(null),rod_root_relative=rod_err)
    starts={};maxnorm=0.;largest_fraction=0.
    forecast=rows('link-volume-8-4.csv')
    summary={}
    for count in (8,16):
        for arm in ('reset','coupled'):
            for source in ('raw','represented'):
                with np.load(HOME/f'flight-{count}-{arm}-{source}.npz') as packet:
                    assert len(packet['wave'])==2*count+1 and packet['ordinary'].shape==(2*count+1,count+1)
                    assert np.isfinite(packet['wave']).all() and np.isfinite(packet['ordinary']).all()
                    assert np.all(packet['ordinary'][0]==0) and abs(count*float(packet['dt_Myr'])-.0075015966874851)<1e-14
                    maxnorm=max(maxnorm,float(packet['worst_norm']))
                    if arm in starts:assert np.array_equal(packet['wave'][0],starts[arm])
                    else:starts[arm]=packet['wave'][0].copy()
        for direction in ('out','in','roundtrip'):
            finite=find(rows(f'finite-link-{count}.csv'),source='both',direction=direction)
            direct=find(forecast,sources='both',direction=direction)
            ratio=f(finite,'maintained_with_launch_shift')/f(direct,'maintained_rods_total')-1
            largest_fraction=max(largest_fraction,abs(ratio))
            summary[f'{count}_{direction}']=ratio
            spline=find(rows('flight-sampling.csv'),steps_per_flight=count,time_stride=1,ray_stride=1,direction=direction)
            assert abs(f(spline,'log_rate')/f(finite,'maintained_with_launch_shift')-1)<.0002
    assert not np.array_equal(starts['coupled'],starts['reset']) and maxnorm<1e-10 and largest_fraction<.02
    report.update(trajectory_packets=8,finite_flight_relative=summary,maximum_wave_norm_drift=maxnorm)
    if seal:save_json('validation.json',report)
    assert json.loads((HOME/'validation.json').read_bytes())==report
    hashes={file.name:digest(file) for file in sorted(HOME.iterdir()) if file.name!='seal.json'}
    if seal:save_json('seal.json',hashes)
    assert json.loads((HOME/'seal.json').read_bytes())==hashes
    print('Verified',len(hashes),'files:',digest(HOME/'seal.json'))
    print(json.dumps(report,indent=2))
if __name__=='__main__':
    verify(sys.argv[1:]==['--seal'])
