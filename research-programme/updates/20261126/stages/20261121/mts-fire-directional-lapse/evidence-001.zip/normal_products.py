"""Node-free angular contraction for the normal Einstein equation, using exact factorial Gaunt weights."""
from directional import HOME,BASE,Experiment,np,raw_bank,fields,angles,roots_legendre,OBSERVER_R,OBSERVER_MU,LIGHT,guard,table,csv
from light_link import shell_sums
from math import factorial
from functools import cache

@cache
def gaunt(left,right,total):
    if total<abs(left-right) or total>left+right or (left+right+total)%2:
        return 0.
    half=(left+right+total)//2
    factors=[factorial(half-index) for index in (left,right,total)]
    numerator=factorial(half)**2
    denominator=factorial(2*half+1)
    for index,fac in zip((left,right,total),factors):
        numerator*=factorial(2*(half-index))
        denominator*=fac**2
    return numerator/denominator

def calculate(box,order,mode):
    ell=np.arange(0,133,2);left=ell[:33];right=ell[:35]
    weights=np.array([[[gaunt(int(a),int(b),int(c)) for c in ell] for b in right] for a in left])
    spin=weights*(left[:,None,None]*(left[:,None,None]+1)+right[None,:,None]*(right[None,:,None]+1)-ell*(ell+1))/2
    mix=weights.reshape(-1,len(ell));spin=spin.reshape(-1,len(ell))
    mass,edges=raw_bank(box);end=box.lab.run.el.right*box.bg.length
    cuts=np.unique(np.r_[0.,edges,end,OBSERVER_R]);nodes,rule=roots_legendre(order)
    radial=(cuts[:-1,None]+np.diff(cuts)[:,None]*(1+nodes)/2).ravel()
    measure=(np.diff(cuts)[:,None]*rule/2).ravel()
    t,wt=roots_legendre(32);t=(1+t)/2
    radial=np.r_[radial,end[-1]/t];measure=np.r_[measure,wt*end[-1]/(2*t*t)]
    full=np.r_[radial,OBSERVER_R];host,wave=fields(box,mass,edges,full,mode,order)
    values=[]
    for start in range(0,len(full),96):
        sl=slice(start,start+96)
        u,ur,ulap=[col[sl] for col in host];w,wr,wlap=[col[sl] for col in wave]
        product=lambda a,b:(a[:,:,None]*b[:,None,:]).reshape(len(a),-1)
        uw=product(u,w)
        gradient=product(ur,wr)@mix+(uw@spin)/full[sl,None]**2
        source=(product(ulap,w)+product(u,wlap))@mix+gradient
        values.append(np.stack([uw@mix,gradient,source],axis=1))
    data=np.concatenate(values)
    saved=csv.DictReader((HOME/f'multipoles-{mode}-{order}.csv').read_text().splitlines())
    old={(int(r['observer']),int(r['ell'])):float(r['spatial']) for r in saved}
    kernel=lambda index:sum(shell_sums(radial,OBSERVER_R,ell,(measure*radial**2)[:,None]*data[:-2,index]))
    weak=(2*ell+1)*data[-2:,0]+kernel(1);direct=-kernel(2)
    output=[]
    for obs in (0,1):
        for pos,deg in enumerate(ell):
            output.append(dict(geometry=mode,order=order,obs=obs,ell=deg,weak=weak[obs,pos]/LIGHT**4,
                          direct=direct[obs,pos]/LIGHT**4,gauss=old[obs,deg]))
    return output
if __name__=='__main__':
    guard()
    box=Experiment(0,1)
    table(HOME/'exact-normal.csv',sum((calculate(box,q,mode) for q,mode in ((4,'volume'),(8,'volume'),(8,'radius'))),[]),True)
