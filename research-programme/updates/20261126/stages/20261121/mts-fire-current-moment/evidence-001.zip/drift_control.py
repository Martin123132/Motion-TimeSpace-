"""Paired forward/backward position displacements of the same actual particles, not new dynamics."""
from particle_readout import *

def evaluate(mom,name,half,coordinates,axis):
    radius=np.linalg.norm(coordinates,axis=1)
    y=radius/mom.lab.obj.bg.length;lo,hi=mom.range[half-1:half+1]
    ans=np.zeros(len(y));inside=y<lo;ans[inside]=mom.inside[name,half]
    mask=~inside&(y<hi)
    theta=np.arccos(np.clip(abs(coordinates[mask]@axis)/radius[mask],0,1))
    ans[mask]=mom.fns[name,half,'D'].ev(y[mask],theta)
    return ans

def run():
    mom=Moment(64);lab=mom.lab;axis=frames(600)[4][-1]
    rows=records(HERE/'particle-64-590.csv');out=[]
    for p in range(4):
        for phase in (0,4):
            check();a,meta=input_piece(590,p,phase)
            with a:
                pos=a['pos_kpc'];mass=a['mass_Msun']/lab.mesh.mscale;hub,exp,_,center,_=frames(590)
                h=meta['header'];hz=.1*hub*np.sqrt(h['Omega0']/exp**3+h['OmegaLambda']+(1-h['Omega0']-h['OmegaLambda'])/exp**2)
                vel=a['velocity_stored'].astype(float)*np.sqrt(exp)-center+hz*pos
            for dt in (.0125,.00625):
                move=dt*vel/977.7922216807892
                for half in (1,2):
                    for name in ('mass','gravity'):
                        change=evaluate(mom,name,half,pos+move,axis)-evaluate(mom,name,half,pos-move,axis)
                        actual=float(mass@change)*mom.scale(name)*lab.obj.unit_myr/(2*dt)
                        ref=next(r for r in rows if r['half']==str(half) and r['piece']==str(p) and r['phase']==str(phase) and r['observable']==name and r['frame']=='catalog_proper')
                        out.append(dict(piece=p,phase=phase,half=half,observable=name,halfstep_Myr=dt,drift=actual,
                                        analytic=float(ref['gradient']),error=actual-float(ref['gradient'])))
    table(HERE/'particle-drift-64.csv',out,True)
if __name__=='__main__':run()
