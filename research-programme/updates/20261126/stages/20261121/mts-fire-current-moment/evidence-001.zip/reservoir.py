"""Conditional source-completion sensitivity. No mass or current is fitted to either arm."""
from virial import *

def run(steps):
    lab=Launch(steps);obj=lab.obj;unit=obj.unit_myr;length=obj.bg.length
    box=Radial(lab,16);limit=box.el.right[-1]*length;l=box.sell
    src=records(HERE/'transfer-source-checks.csv');m={int(row['snap']):float(row['transferred_joint_delta_Msun']) for row in src}
    dl,dr,*_=clocks();left=(m[590]-m[589])/dl;right=(m[591]-m[590])/dr
    rates={'near_left':left,'near_right':right,'unequal_center':(dr*left+dl*right)/(dl+dr)}
    nodes,w=roots_legendre(32);s=(1+nodes)/2;weight=w/2*30*s**2*(1-s)**2;assert abs(weight.sum()-1)<1e-14
    testbeds=[(30.,45.),(60.,90.),(125.,180.),(limit,limit*1.2)]
    sampling=np.array([a+(b-a)*s for a,b in testbeds])
    inside=sampling<limit;points=np.r_[sampling[inside]/length,box.el.right[-1]]
    val,grad,_=green(lab,box,points);B=np.empty((*sampling.shape,len(l)))
    B[inside]=2*val[:-1,:,0]+points[:-1,None]*grad[:-1,:,0]
    B[~inside]=(1-l)*val[-1,:,0]*(limit/sampling[~inside,None])**(l+1)
    scales=(length/unit)**2;rows=[]
    local=records(HERE/f'virial-{steps}-16.csv')
    for idx,(a,b) in enumerate(testbeds):
        for eta in (-1.,0.,2.):
            mean=weight@(B[idx,:,0]+eta*B[idx,:,1]/np.sqrt(5))*scales
            for label,rate in rates.items():
                direct=next(v for v in local if v['slope']==label)
                interior=float(direct['interior_cubic_Msun_kpc2_Myr3'])
                corr=rate*mean
                rows.append(dict(steps=steps,slope=label,inner_kpc=a,outer_kpc=b,angular_P2=eta,
                    transferred_Msun_Myr=rate,reservoir_Msun_Myr=-rate,weighted_kernel_kpc2_Myr2=mean,
                    cubic_density_change_Msun_kpc2_Myr3=corr,augmented_interior=interior+corr,
                    absolute_fraction=abs(corr/interior),vacuum_bound_if_outside=abs(rate)*float(direct['outer_abs_kpc2_Myr2_per_Msun_Myr']) if a>=limit else ''))
    table(HERE/f'reservoir-{steps}.csv',rows,True)
if __name__=='__main__':
    for steps in (64,32):check();run(steps)
