"""Apply the unchanged FIRE mass-group transfer, not a velocity transfer."""
from particle_readout import *
fixed('joint_field.py')
import joint_field as jf
from numpy.polynomial.legendre import legvander

def input_fields(lab,save=False):
    with np.load(fixed('mw-positive-aperture.npz')) as data:local=data['high']
    codes=jf.groups(False);labels=codes.ravel();bg=lab.obj.bg
    historical={}
    for snap in (590,600):
        for piece in range(4):
            for suffix in ('json','npz'):fixed(f'mass-{snap}-{piece}.{suffix}')
        actual=jf.merged(snap)[0][:,0]
        historical[snap]=np.array([np.bincount(labels,weights=slab.ravel(),minlength=91) for slab in actual])
    end=historical[600].sum(axis=0);assert end.min()>0
    fields={};checks=[]
    for snap in (589,590,591):
        results=np.zeros((2,91));numbers=np.zeros(2,np.int64);pieces=np.zeros(2,np.int64)
        for piece in range(4):
            for idx,phase in enumerate((0,4)):
                a,meta=input_piece(snap,piece,phase)
                with a:results[idx]+=a['group_mass_Msun'];numbers[idx]+=a['group_count'].sum()
                pieces[idx]+=meta['counts'][phase]
        assert list(pieces)==[meta['whole'][0],meta['whole'][4]]
        delta=local*(results.sum(axis=0)[codes]/end[codes]-1)
        fields[snap]=jf.coeffs(delta,bg.rad*bg.length,64)@legvander(bg.mu,64)[:,::2].T/bg.vel**2
        for idx,phase in enumerate((0,4)):
            row=dict(snap=snap,phase=phase,all_particle_count=int(pieces[idx]),group_count=int(numbers[idx]),
                     group_mass_Msun=results[idx].sum(),transferred_joint_delta_Msun=delta.sum(),old_relative_mass_difference='',old_relative_field_difference='')
            if snap==590:
                ratio=np.max(abs(results[idx]-historical[snap][idx])/historical[snap][idx])
                field_ratio=np.max(abs(fields[snap]-lab.run.fields[snap]))/np.max(abs(lab.run.fields[snap]))
                assert ratio<1e-10 and field_ratio<1e-9,(ratio,field_ratio)
                row.update(old_relative_mass_difference=ratio,old_relative_field_difference=field_ratio)
            checks.append(row)
    if save:table(HERE/'transfer-source-checks.csv',checks,True)
    return fields

def slope_fields(lab,fields):
    dl,dr,_,_=clocks();unit=lab.obj.unit_myr
    left=(fields[590]-fields[589])*(unit/dl);right=(fields[591]-fields[590])*(unit/dr)
    rates={'near_left':left,'near_right':right,'unequal_center':(dr*left+dl*right)/(dl+dr)}
    for tag,lo,hi in [('broad_left',586,590),('broad_right',590,600)]:
        rates[tag]=(lab.run.fields[hi]-lab.run.fields[lo])*(unit/(lab.run.ages[hi]-lab.run.ages[lo]))
    return rates

def project(lab,rates):
    pr=Probe(lab,22);bg=lab.obj.bg;r=pr.r[:,None];nn=pr.ordinary_count
    angular,_=basis(pr.ls,bg.mu);pot,g,_,_,_=waves(lab,pr)
    v=pot@angular;slope=g@angular
    volume=r**2*np.r_[pr.w,np.zeros(len(pr.faces))][:,None]*bg.aw
    measure=r**2*np.r_[pr.w,np.ones(len(pr.faces))][:,None]*bg.aw
    previous=records(retained(f'current-reduction-{lab.steps}.csv'))
    rows=[]
    for label,dotfield in rates.items():
        _,der,rho,jumps=pr.measured(dotfield,True)
        mass=np.vstack([rho[:nn]@angular,jumps[nn:]@angular])*measure
        for half,(lo,hi) in enumerate(zip(lab.mesh.knots[:-1],lab.mesh.knots[1:],strict=True),1):
            pick=pr.bins==half-1
            for name in ('mass','gravity'):
                f,ff=weights(name,r[pick],lo,hi);sc=(lab.mesh.mscale if name=='mass' else lab.unit/lab.mesh.ep)/lab.obj.unit_myr**3
                scalar=f*(slope[pick]+2*v[pick]/r[pick]);mean=-2*(ff-f/r[pick])*(g[pick,0,None]-pot[pick,0,None]/r[pick])
                continuity=-np.sum(mass[pick]*scalar)*sc;spherical=-np.sum((volume[pick]*der[pick,0,None])*mean)*sc
                orig=next(row for row in previous if row['half']==str(half) and row['observable']==name and row['source_slope']==('right' if 'right' in label else 'left'))
                field=float(orig['wave_field_jerk']);known=field+continuity+spherical;bound=float(orig['remaining_radial_bound_per_kms'])
                if label.startswith('broad'):
                    assert abs(known-float(orig['determined_part']))<2e-7*max(abs(known),abs(continuity),1e-30)
                rows.append(dict(steps=lab.steps,half=half,observable=name,slope=label,field=field,continuity=continuity,
                                 spherical=spherical,density_jerk=continuity+spherical,determined=known,
                                 remaining_per_kms=bound,speed_needed_kms=abs(known)/bound))
    return rows

if __name__=='__main__':
    for steps in (64,32):
        check();lab=Launch(steps)
        if steps==64:fields=input_fields(lab,True)
        table(HERE/f'hybrid-{steps}.csv',project(lab,slope_fields(lab,fields)),True)
    print('Compared both historical secants and both real neighboring source banks')
