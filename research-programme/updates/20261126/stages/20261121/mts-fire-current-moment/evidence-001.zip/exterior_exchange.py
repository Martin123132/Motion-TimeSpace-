"""Test actual simulated exterior mass supply, and a distinct conservative per-cone construction."""
from reservoir import *

def run(steps):
    lab=Launch(steps);bg=lab.obj.bg;box=Radial(lab,16);dl,dr,*_=clocks();limit=box.inf*bg.length
    codes=jf.groups(False);cuts,_=groups();outer=codes>=84
    with np.load(fixed('mw-positive-aperture.npz')) as src:local=src['high']
    def raw(snap):
        if snap==600:
            for p in range(4):fixed(f'mass-600-{p}.npz')
            return np.bincount(codes.ravel(),weights=jf.merged(600)[0][:,0].sum(axis=0).ravel())
        tot=np.zeros(91)
        for p in range(4):
            for phase in (0,4):
                arc,_=input_piece(snap,p,phase)
                with arc:tot+=arc['group_mass_Msun']
        return tot
    end=raw(600);banks={s:raw(s) for s in (589,590,591)}
    g=jf.merged(590)[0][:,0].sum(axis=0)*outer
    valid=np.flatnonzero(np.any(outer,axis=1));rad=jf.RC[valid];wave=rad<limit
    points=np.r_[rad[wave]/bg.length,box.inf];l=box.sell;val,grad,_=green(lab,box,points)
    B=np.empty((len(rad),len(l)))
    B[wave]=2*val[:-1,:,0]+points[:-1,None]*grad[:-1,:,0]
    B[~wave]=(1-l)*val[-1,:,0]*(limit/rad[~wave,None])**(l+1)
    leg=legvander(jf.ANG,l[-1]+1);harm=np.ones((len(jf.UC),len(l)))
    for j,ell in enumerate(l[1:],1):
        harm[:,j]=np.diff(leg[:,ell+1]-leg[:,ell-1])/(np.sqrt(2*ell+1)*np.diff(jf.ANG))
    angular_basis=(B@harm.T)*(bg.length/lab.obj.unit_myr)**2
    angular_mean=[]
    for ang in range(7):
        mass=g[valid]*(codes[valid]%7==ang)
        angular_mean.append(np.sum(mass*angular_basis)/mass.sum())
    angular_mean=np.array(angular_mean);rows=[];cones=[]
    local_total=np.bincount(codes.ravel(),weights=local.ravel());gain=local_total/end
    assert np.sum(local_total[-7:])==0
    mean_gain=local_total.sum()/end[:-7].sum();group_rows=[];mass_budget=[]
    ls=(banks[590]-banks[589])/dl;rs=(banks[591]-banks[590])/dr
    for label,rates in [('near_left',ls),('near_right',rs),('unequal_center',(dr*ls+dl*rs)/(dr+dl))]:
        inside=np.bincount((codes%7).ravel(),weights=(local*(rates/end)[codes]).ravel());outside=rates[-7:]
        residual=inside+outside
        uniform=mean_gain*rates[:-7].sum();contrast=(gain[:-7]-mean_gain)*rates[:-7]
        assert abs(uniform+sum(contrast)-inside.sum())<1e-10*sum(abs(contrast))
        mass_budget.append(dict(steps=steps,slope=label,mean_weight=mean_gain,uniform_weight_rate_Msun_yr=uniform/1e6,
            redistribution_Msun_yr=sum(contrast)/1e6,total_Msun_yr=inside.sum()/1e6))
        for j in range(84):
            group_rows.append(dict(steps=steps,slope=label,radial_group=j//7,angle_group=j%7,weight=gain[j],
                mean_weight=mean_gain,raw_rate_Msun_yr=rates[j]/1e6,
                redistribution_Msun_yr=contrast[j]/1e6,hybrid_rate_Msun_yr=gain[j]*rates[j]/1e6))
        extmass=np.bincount((codes[valid]%7).ravel(),weights=g[valid].ravel())
        lift=-g[valid]*(inside/extmass)[codes[valid]%7]
        assert abs(np.sum(lift)+inside.sum())<1e-12*sum(abs(inside))
        assert abs(-np.sum(lift*angular_basis)-inside@angular_mean)<1e-12*max(sum(abs(inside*angular_mean)),1e-30)
        for j in range(7):
            cones.append(dict(steps=steps,slope=label,cone=j,transfer_rate=inside[j],FIRE_exterior_rate=outside[j],
                              mean_kernel=angular_mean[j],required_exterior_rate=-inside[j],mismatch=residual[j]))
        rows.append(dict(steps=steps,slope=label,group_boundary_kpc=cuts[-1],exterior_end_kpc=500.,
                         hybrid_Msun_yr=inside.sum()/1e6,raw_inside_Msun_yr=rates[:-7].sum()/1e6,
                         raw_exterior_Msun_yr=outside.sum()/1e6,raw_total_Msun_yr=rates.sum()/1e6,
                         mixed_unbalanced_Msun_yr=residual.sum()/1e6,cone_mismatch_L1_Msun_yr=sum(abs(residual))/1e6,
                         compensated_rate_Msun_yr=(inside.sum()+lift.sum())/1e6,
                         measured_template_cubic=-(outside@angular_mean),conservative_template_cubic=inside@angular_mean,
                         abs_conservative_norm=sum(abs(inside*angular_mean))))
    table(HERE/f'exterior-exchange-{steps}.csv',rows,True)
    table(HERE/f'exterior-cones-{steps}.csv',cones,True)
    table(HERE/f'group-redistribution-{steps}.csv',group_rows,True)
    table(HERE/f'mass-budget-{steps}.csv',mass_budget,True)
if __name__=='__main__':
    for n in (64,32):check();run(n)
