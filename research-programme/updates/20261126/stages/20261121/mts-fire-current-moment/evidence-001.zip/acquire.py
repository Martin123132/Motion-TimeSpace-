"""Bounded public input reader. Only one field from one baryonic species in RAM at a time."""
from pathlib import Path
import datetime
import hashlib
import io
import json
import os
import sys
import time
HERE=Path(__file__).resolve().parent
BANK=HERE.parent/'mts-fire-joint-baryon-history-20261120'
def filehash(path):
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
assert filehash(BANK/'seal.json')=='19c78eaa158a766bd409c0a64504788b1346542eccee37c004083a918c480d67'
known=json.loads((BANK/'seal.json').read_bytes())['files']
def fixed(name):
    path=BANK/name;assert filehash(path)==known[name],name
    return path
fixed('fire_source.py');fixed('collect_particles.py')
sys.path.insert(0,str(BANK))
from fire_source import Remote,uri,h5py,np,guard
from collect_particles import EDGES,ANG
def frames(snap):
    data=np.loadtxt(io.StringIO('\n'.join(v.strip() for v in fixed(f'{snap}_coords_DR.txt').read_text().splitlines() if not v.startswith('#')) .replace('\n',' ')))
    assert data.shape==(17,)
    return data[0],data[1],data[2:5],data[5:8],data[8:].reshape(3,3)
def groups():
    cuts=np.array([EDGES[np.argmin(abs(EDGES-dist))] for dist in (0,.5,1,2,3,4,6,8,10,14,20,25,30)])
    return cuts,np.array([0,1/32,1/16,1/8,1/4,1/2,3/4,1])
def packet(snap,piece,species,deadline):
    guard()
    assert not (HERE/'STOP-REQUESTED').exists()
    folder=HERE/'inputs';folder.mkdir(exist_ok=True)
    stem=f's{snap}-{piece}-p{species}';path=folder/(stem+'.npz');receipt=folder/(stem+'.json')
    if receipt.exists():
        assert json.loads(receipt.read_bytes())['packet_sha256']==filehash(path)
        return
    assert not path.exists(),'inspect incomplete receipt before any re-fetch'
    data={};hashes={};size=0;calls=0;identity=None;start_time=time.monotonic()
    hub,scale,centre,velocity,rotation=frames(snap);terminal=frames(600)[4][-1]
    original=json.loads(fixed(f'mass-{snap}-{piece}.json').read_bytes()) if snap==590 else None
    for key in (['Coordinates','Masses','Velocities'] if snap==590 else ['Coordinates','Masses']):
        assert time.time()<deadline and not (HERE/'STOP-REQUESTED').exists()
        remote=Remote(uri(snap,piece),65536)
        try:
            if identity is None:identity=remote.id
            assert identity==remote.id
            if original:assert list(identity)==original['server_identity']
            with h5py.File(remote,'r') as archive:
                attrs=archive['Header'].attrs;dataset=archive[f'PartType{species}/{key}']
                counts=[int(x) for x in attrs['NumPart_ThisFile']];whole=[int(x) for x in attrs['NumPart_Total']]
                assert int(attrs['NumFilesPerSnapshot'])==4 and len(dataset)==counts[species]
                assert abs(float(attrs['Time'])-scale)<1e-6 and abs(float(attrs['HubbleParam'])-hub)<1e-9
                header={item:float(attrs[item]) for item in ('Time','HubbleParam','Omega0','OmegaLambda','BoxSize')}
                remote.load_field(dataset)
                values=dataset[:];hashes[key]=hashlib.sha256(memoryview(np.ascontiguousarray(values))).hexdigest()
                if original and key!='Velocities':
                    assert hashes[key]==original['fields_sha256'][f'PartType{species}'][key.lower()]
                if key=='Coordinates':
                    bins,angles=groups();n=len(values)
                    group_index=np.full(n,-1,np.int16);sel=[];positions=[]
                    for lo in range(0,n,250000):
                        delta=values[lo:lo+250000]-centre*hub
                        pos=(delta-header['BoxSize']*np.rint(delta/header['BoxSize']))*(scale/hub)
                        radius=np.sqrt(np.einsum('ij,ij->i',pos,pos));mask=radius<500.
                        cosine=np.clip(abs(pos@terminal)/np.maximum(radius,1e-100),0.,1.)
                        rid=np.searchsorted(bins,radius,side='right')-1
                        aid=np.minimum(np.searchsorted(angles,cosine,side='right')-1,6)
                        group_index[lo:lo+len(delta)]=np.where(mask,rid*7+aid,-1)
                        chosen=np.flatnonzero((radius>=5.75)&(radius<9.))
                        sel.append(chosen+lo);positions.append(pos[chosen])
                    select=np.concatenate(sel)
                    data['pos_kpc']=np.concatenate(positions)
                    data['index']=select.astype(np.uint32)
                    data['group']=group_index[select]
                elif key=='Masses':
                    weights=values.astype(float)*(1e10/hub);assert weights.min()>0 and np.isfinite(weights).all()
                    mask=group_index>=0
                    data['group_mass_Msun']=np.bincount(group_index[mask],weights=weights[mask],minlength=91)
                    data['group_count']=np.bincount(group_index[mask],minlength=91)
                    data['mass_Msun']=weights[select]
                    mass_total=weights.sum()
                    del weights
                else:
                    data['velocity_stored']=values[select].copy()
                del values
            size+=remote.transferred;calls+=remote.calls
        finally:remote.close()
    assert size<660_000_000 and len(select)>0
    temp=path.with_suffix('.work')
    with temp.open('xb') as out:np.savez_compressed(out,**data)
    temp.rename(path)
    result=dict(snap=snap,piece=piece,species=species,url=uri(snap,piece),identity=identity,header=header,
                counts=counts,whole=whole,field_sha256=hashes,packet_sha256=filehash(path),bytes=size,requests=calls,
                full_mass_Msun=float(mass_total),shell_count=len(select),axis=terminal.tolist(),center_comoving_kpc=centre.tolist(),
                center_peculiar_kms=velocity.tolist(),seconds=round(time.monotonic()-start_time,2))
    with receipt.open('x',encoding='utf8',newline='\n') as out:out.write(json.dumps(result,sort_keys=True,indent=2)+'\n')
    print(stem,len(select),'particles retained;',size,'bytes fetched;',result['seconds'],'s',flush=True)
if __name__=='__main__':
    assert len(sys.argv)==2
    deadline=datetime.datetime.fromisoformat(sys.argv[1]).timestamp();assert time.time()<deadline<time.time()+4*3600
    for snap in (590,591,589):
        for piece in range(4):
            for phase in (4,0):packet(snap,piece,phase,deadline)
