"""Three-dimensional tests of a gradient current kernel, including a real surface flux."""
from moment_io import *
from scipy.integrate import solve_ivp
from scipy.special import roots_legendre
from numpy.polynomial.polynomial import polyfit

def run():
    tensor=np.array([[.4,.24,.1],[.24,-.75,.16],[.1,.16,.21]])
    linear=np.array([.55,-.3,.19]);tilt=np.array([.15,.06,-.09])
    tide=np.array([[.5,-.07,0],[-.07,.4,.03],[0,.03,.66]])
    start=np.array([.62,-.83,.24]);velocity=np.array([-.29,.51,.33]);init=np.r_[start,velocity]
    g=linear+tensor@start
    pred2=-(start@g);pred3=-(start@tilt+velocity@(3*g+tensor@start))
    def system(t,state,active):
        pos=state[:3]
        return np.r_[state[3:],-tide@pos-active*(linear+tensor@pos+t*tilt)]
    rows=[]
    for halfspan in (.09,.045):
        ts=np.linspace(-halfspan,halfspan,17);vals=np.zeros(len(ts))
        for sign in (-1,1):
            mask=ts*sign>0;points=np.sort(ts[mask])[::sign]
            for arm in (0,1):
                sol=solve_ivp(system,(0,sign*halfspan),init,args=(arm,),t_eval=points,method='DOP853',rtol=1e-13,atol=2e-15)
                assert sol.success
                vals[mask]+=(2*arm-1)*np.sum(sol.y[:3]**2,axis=0)[::sign]/2
        coeff=polyfit(ts/halfspan,vals,7)
        for what,got,want in [('curvature',2*coeff[2]/halfspan**2,pred2),('cubic',6*coeff[3]/halfspan**3,pred3)]:
            assert abs(got-want)<2e-8
            rows.append(dict(test='actual_orbits_'+what,control=halfspan,direct=got,expected=want,error=got-want))
    phi=np.arange(256)*2*np.pi/256
    path=np.stack([1.13*np.cos(phi),.61*np.sin(phi),.15*np.sin(2*phi)],axis=1)+np.array([.8,-.3,.1])
    tangent=np.stack([-1.13*np.sin(phi),.61*np.cos(phi),.30*np.cos(2*phi)],axis=1)
    loop=-2*np.pi*np.mean(np.sum(tangent*(3*(path@tensor+linear)+path@tensor),axis=1))
    assert abs(loop)<1e-13
    rows.append(dict(test='circulating_current',control=256,direct=loop,expected=0,error=loop))
    r,w=roots_legendre(24);r=(1+r)/2;w=w/2
    for shift in (0.,1.7):
        beta=-.37
        direct=-4*beta*np.sum(w*r**4);bulk=3*beta*np.sum(w*r**2*(2*shift+2*r**2))
        surface=-beta*(2*shift+2)
        assert abs(bulk+surface-direct)<1e-13 and abs(bulk-direct)>.1
        rows.append(dict(test='open_surface_with_gauge_shift',control=shift,direct=bulk+surface,expected=direct,error=bulk+surface-direct))
    table(HERE/'virial-analytic-controls.csv',rows,True)
if __name__=='__main__':run()
