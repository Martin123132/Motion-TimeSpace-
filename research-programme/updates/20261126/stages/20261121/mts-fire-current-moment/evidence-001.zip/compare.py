"""Aggregate pieces only after coverage; keep finite time slopes distinct from velocity moments."""
from particle_readout import *

def regroup(rows,phases,frame,key):
    return sum(float(row[key]) for row in rows if int(row['phase']) in phases and row['frame']==frame)

def run(steps):
    dl,dr,bulk,trajectory=clocks()
    lab=Launch(steps);tunit=lab.obj.unit_myr;rows=[]
    raw={snap:records(HERE/f'particle-{steps}-{snap}.csv') for snap in (589,590,591)}
    for half in (1,2):
        for observable in ('mass','gravity'):
            filtered={snap:[r for r in batch if r['half']==str(half) and r['observable']==observable] for snap,batch in raw.items()}
            for label,phases in [('gas',(0,)),('stars',(4,)),('joint',(0,4))]:
                dens=np.array([regroup(filtered[s],phases,'catalog_proper' if s==590 else 'density','density_weight') for s in (589,590,591)])
                left,right=np.diff(dens)/[dl,dr]*tunit;center=(dr*left+dl*right)/(dl+dr)
                for frame in ('catalog_proper','catalog_peculiar','trajectory_proper'):
                    row=dict(steps=steps,half=half,observable=observable,phase=label,frame=frame)
                    row.update({key:regroup(filtered[590],phases,frame,key) for key in ('particle_count','curvature','field','current','rest','gradient','net')})
                    assert abs(row['gradient']+row['rest']-row['current'])<1e-12*max(abs(row['rest']),abs(row['current']),1e-30)
                    row.update(left=left,right=right,center=center,right_minus_instant=right-row['gradient'],
                               center_minus_instant=center-row['gradient'])
                    rows.append(row)
    table(HERE/f'raw-comparison-{steps}.csv',rows,True)
if __name__=='__main__':
    for steps in (64,32):check();run(steps)
