"""Read-only checks. Seal only after both neighboring snapshots and all diagnostic tables exist."""
from moment_io import *
import ast

def verify():
    check();audit={};metas=[]
    for p in HERE.glob('*.py'):ast.parse(p.read_bytes(),filename=p.name)
    for snap in (589,590,591):
        for piece in range(4):
            for phase in (0,4):
                data,meta=input_piece(snap,piece,phase)
                with data:
                    assert tuple([meta['snap'],meta['piece'],meta['species']])==(snap,piece,phase)
                    assert data['pos_kpc'].shape==(meta['shell_count'],3) and len(data['group_mass_Msun'])==91
                    assert ('velocity_stored' in data.files)==(snap==590)
                    assert np.all(np.diff(data['index'].astype(np.int64))>0)
                    assert meta['counts'][phase]>=int(data['group_count'].sum())>=meta['shell_count']
                    assert all(len(v)==64 for v in meta['field_sha256'].values())
                metas.append(meta)
    audit.update(packets=len(metas),fetched_bytes=sum(m['bytes'] for m in metas),snap590_shell=sum(m['shell_count'] for m in metas if m['snap']==590))
    source=records(HERE/'transfer-source-checks.csv');assert len(source)==6 and {int(r['snap']) for r in source}=={589,590,591}
    audit['max_old_field_difference']=max(float(r['old_relative_field_difference'] or 0) for r in source)
    assert audit['max_old_field_difference']<1e-9
    for n in (32,64):
        rows=records(HERE/f'raw-comparison-{n}.csv');assert len(rows)==36
        for s,count in ((589,32),(590,96),(591,32)):assert len(records(HERE/f'particle-{n}-{s}.csv'))==count
        for row in rows:
            for key,value in row.items():
                if key not in ('observable','phase','frame'):assert np.isfinite(float(value))
        for row in (x for x in rows if x['phase']=='joint'):
            subs=[x for x in rows if x['phase']!='joint' and all(x[k]==row[k] for k in ('frame','half','observable'))]
            assert len(subs)==2
            for key in ('rest','current','net','center','curvature'):
                values=[float(x[key]) for x in subs]
                assert abs(sum(values)-float(row[key]))<1e-9*max(max(map(abs,values)),1e-30)
        assert max(float(r['derivative_fraction']) for r in records(HERE/f'gradient-{n}.csv'))<1e-6
        hybrid=records(HERE/f'hybrid-{n}.csv');assert len(hybrid)==20
        res=records(HERE/f'reservoir-{n}.csv');assert len(res)==36
        exchange=records(HERE/f'exterior-exchange-{n}.csv');budget=records(HERE/f'mass-budget-{n}.csv')
        assert len(exchange)==len(budget)==3 and len(records(HERE/f'group-redistribution-{n}.csv'))==252
        assert len(records(HERE/f'exterior-cones-{n}.csv'))==21
        for ex,bd in zip(exchange,budget,strict=True):
            assert ex['slope']==bd['slope'] and abs(float(ex['compensated_rate_Msun_yr']))<1e-10
            assert abs(float(ex['hybrid_Msun_yr'])-float(bd['uniform_weight_rate_Msun_yr'])-float(bd['redistribution_Msun_yr']))<1e-9
        for row in res:
            assert float(row['transferred_Msun_Myr'])==-float(row['reservoir_Msun_Myr'])
            if row['vacuum_bound_if_outside']:
                assert abs(float(row['cubic_density_change_Msun_kpc2_Myr3']))<=float(row['vacuum_bound_if_outside'])*(1+1e-9)
        for q in ((16,24) if n==64 else (16,)):
            vs=records(HERE/f'virial-{n}-{q}.csv');assert len(vs)==5
            for row in vs:
                for key,weak in [('curvature_Msun_kpc2_Myr2','weak_curvature'),('field_Msun_kpc2_Myr3','weak_field'),('density_Msun_kpc2_Myr3','weak_density')]:
                    assert abs(float(row[key])-float(row[weak]))<1e-7*max(abs(float(row[key])),1.)
                assert float(row['vacuum_kernel_identity_max'])<1e-14
    controls=records(HERE/'virial-analytic-controls.csv');assert len(controls)==7
    assert max(abs(float(row['error'])) for row in controls)<2e-8
    drifts=records(HERE/'particle-drift-64.csv');assert len(drifts)==64
    errs=[]
    for tag in ('mass','gravity'):
        for half in ('1','2'):
            a=[r for r in drifts if r['observable']==tag and r['half']==half and r['halfstep_Myr']=='0.00625']
            assert len(a)==8
            errs.append(abs(sum(float(r['error']) for r in a)/sum(float(r['analytic']) for r in a)))
    audit['max_fine_particle_drift_difference']=max(errs);assert max(errs)<1e-3
    va=records(HERE/'virial-64-16.csv');vb=records(HERE/'virial-64-24.csv')
    audit['virial_volume_order_difference']=max(abs(float(a['interior_cubic_Msun_kpc2_Myr3'])/float(b['interior_cubic_Msun_kpc2_Myr3'])-1) for a,b in zip(va,vb,strict=True))
    assert audit['virial_volume_order_difference']<2e-7
    assert not list(HERE.rglob('*.work')) and not list(HERE.rglob('*.pyc'))
    audit['parent_seal']=SEAL
    return audit
if __name__=='__main__':
    result=verify();raw=(json.dumps(result,indent=2,sort_keys=True)+'\n').encode()
    keep(HERE/'validation.json',raw,True)
    if '--seal' in sys.argv:
        assert (HERE/'RESULTS.md').is_file()
        paths=sorted(p for p in HERE.rglob('*') if p.is_file() and p!=HERE/'seal.json')
        values={p.relative_to(HERE).as_posix():filehash(p) for p in paths}
        keep(HERE/'seal.json',(json.dumps(values,indent=2,sort_keys=True)+'\n').encode(),True)
        print('sealed',len(paths),'files',filehash(HERE/'seal.json'))
    print(raw.decode())
