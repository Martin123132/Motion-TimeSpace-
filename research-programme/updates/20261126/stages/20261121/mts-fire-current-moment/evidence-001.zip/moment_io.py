"""Pinned inputs and two frozen weak readouts, independent of any particle velocities."""
import sys
import json
from pathlib import Path
import importlib.util
spec=importlib.util.spec_from_file_location('fire_particle_source',Path(__file__).with_name('acquire.py'))
source=importlib.util.module_from_spec(spec);spec.loader.exec_module(source)
HERE,BANK,filehash,fixed,groups,frames=(source.HERE,source.BANK,source.filehash,source.fixed,source.groups,source.frames)
PREV=HERE.parent/'mts-fire-sourced-radial-clock-20261121'
SEAL='01fc5c2b9419db6f9931ba996eafe7345019c7192c8012898c8e3f043d6ed578'
assert filehash(PREV/'seal.json')==SEAL
manifest=json.loads((PREV/'seal.json').read_bytes())
def retained(name):
    path=PREV/name;assert filehash(path)==manifest[name],name
    return path
for name in ('ordinary_momentum.py','ordinary_jerk.py','current_reduction.py','mts_radial_inputs.py'):retained(name)
sys.path.insert(0,str(PREV))
from ordinary_momentum import Probe
from mts_radial_inputs import Launch,np,table,keep,records,eval_legendre,check as ancestor_check
from scipy.interpolate import CubicSpline,RectBivariateSpline
def check():
    ancestor_check()
    assert not (HERE/'STOP-REQUESTED').exists()
def input_piece(snap,piece,species):
    stem=f's{snap}-{piece}-p{species}'
    path=HERE/'inputs'/(stem+'.npz')
    receipt=json.loads(path.with_suffix('.json').read_bytes())
    assert receipt['packet_sha256']==filehash(path)
    return np.load(path),receipt
def intervals(steps=64):
    data=np.loadtxt(fixed('snapshot_times.txt'))
    return {int(row[0]):row[3]*1000 for row in data if 580<=row[0]<=600}
def basis(degrees,mu):
    harm=eval_legendre(degrees[:,None],mu)*np.sqrt(2*degrees[:,None]+1)
    theta=np.zeros_like(harm);use=abs(mu)<1
    for idx,degree in enumerate(degrees[1:],1):
        theta[idx,use]=-np.sqrt(2*degree+1)*degree*(eval_legendre(degree-1,mu[use])-mu[use]*eval_legendre(degree,mu[use]))/np.sqrt(1-mu[use]**2)
    return harm,theta
def waves(lab,probe):
    run=lab.run;obj=lab.obj
    reset,coupled=lab.initial.values()
    val,grad,curv=probe.heavydifference(reset,coupled,True)
    d=[]
    for state in (reset,coupled):
        rate=-1j*(obj.bare@state+obj.multiply(run.fields[590]+obj.phi(obj.moment(state)),state)-obj.mu*state)
        v,g,_=probe.heavydifference((state-rate)/np.sqrt(2),(state+rate)/np.sqrt(2),True)
        d.append((v,g))
    return val,grad,curv,d[1][0]-d[0][0],d[1][1]-d[0][1]
def weights(name,y,lo,hi):
    width=hi-lo;p=(y-lo)/width
    bump=(4*p*(1-p))**3
    first=192*p**2*(1-p)**2*(1-2*p)/width
    if name=='mass':
        return first,384*p*(1-p)*((1-2*p)**2-p*(1-p))/width**2
    volume=16/35*width*(lo**2+lo*width+5/18*width**2)
    return bump/volume,first/volume
class Moment:
    def __init__(self,steps,nrad=385,nangle=193):
        self.lab=lab=Launch(steps);pr=Probe(lab,24)
        self.range=lab.mesh.knots;self.fns={};self.inside={}
        val,grad,curv,_,dgrad=waves(lab,pr)
        r,idx=np.unique(pr.r,return_index=True)
        interp=CubicSpline(r,np.stack([val[idx],grad[idx],curv[idx],dgrad[idx]],axis=-1))
        theta=np.linspace(0,np.pi/2,nangle);harm,theta_basis=basis(pr.ls,np.cos(theta))
        self.checks=[]
        for half,(lo,hi) in enumerate(zip(self.range[:-1],self.range[1:],strict=True),1):
            y=np.linspace(lo,hi,nrad);radius=y[:,None]
            values=interp(y);potential,gradient,curvature,dotgrad=[values[:,:,j] for j in range(4)]
            v=potential@harm;g=gradient@harm;c=curvature@harm;dg=dotgrad@harm
            gt=(potential@theta_basis)/radius;hrt=(gradient@theta_basis)/radius-gt/radius
            for name in ('mass','gravity'):
                first,second=weights(name,radius,lo,hi)
                radial=-3*second*g-first*c;polar=-3*first*gt/radius-first*hrt
                rem=-2*(second-first/radius)*(g-v/radius)
                mean=(-2*(second-first/radius)*(gradient[:,0,None]-potential[:,0,None]/radius))[:,0]
                integral=CubicSpline(y,mean).antiderivative()
                ss=integral(y)-integral(hi)
                den=ss[:,None]-first*(g+2*v/radius)
                fields=dict(D=den,rest=rem-mean[:,None],radial=radial,polar=polar,field=-first*dg,curvature=-first*g)
                self.inside[name,half]=ss[0]
                for key,arr in fields.items():self.fns[name,half,key]=RectBivariateSpline(y,theta,arr,s=0)
                testy=y[2:-2:7]+.37*(y[1]-y[0]);testt=theta[2:-2:7]+.21*theta[1]
                f=lambda key:self.fns[name,half,key]
                for axis,direct in [('radial',f('radial')(testy,testt)-f('rest')(testy,testt)),('polar',f('polar')(testy,testt))]:
                    analytic=f('D')(testy,testt,dx=1) if axis=='radial' else f('D')(testy,testt,dy=1)/testy[:,None]
                    self.checks.append(dict(steps=steps,half=half,observable=name,axis=axis,
                        derivative_fraction=np.linalg.norm(analytic-direct)/np.linalg.norm(direct)))
    def scale(self,name):
        unit=self.lab.mesh.mscale if name=='mass' else self.lab.unit/self.lab.mesh.ep
        return unit/self.lab.obj.unit_myr**3
