"""Direct weak current and independent mass-history sums, resolved by snapshot and phase."""
from moment_io import *
import csv

def clocks():
    t=intervals();dl=t[590]-t[589];dr=t[591]-t[590]
    hub,a,c,bulk,_=frames(590)
    left=(c-frames(589)[2])/dl;right=(frames(591)[2]-c)/dr
    trajectory=977.7922216807892*a*(dr*left+dl*right)/(dl+dr)
    return dl,dr,bulk,trajectory

def mass_energy(mom,snap):
    lab=mom.lab;axis=frames(600)[4][-1];dl,dr,bulk,trajectory=clocks()
    cut=groups()[0][6];assert 5.75<cut<9.
    assert 5.75<min(mom.range)*lab.obj.bg.length<max(mom.range)*lab.obj.bg.length<9.
    rows=[]
    for piece in range(4):
        for phase in (0,4):
            check()
            with input_piece(snap,piece,phase)[0] as archive:
                pos=archive['pos_kpc'];mass=archive['mass_Msun']
                rad=np.linalg.norm(pos,axis=1);unit=pos/rad[:,None]
                y=rad/lab.obj.bg.length;smu=unit@axis
                mu=np.clip(abs(smu),0,1);theta=np.arccos(mu)
                below=archive['group_mass_Msun'].reshape(13,7)[:6].sum()-mass[rad<cut].sum()
                assert below>=0
                streams={}
                if snap==590:
                    hub,a,_,_,_=frames(590);meta=json.loads((HERE/'inputs'/f's590-{piece}-p{phase}.json').read_bytes())['header']
                    hubble=.1*hub*np.sqrt(meta['Omega0']/a**3+meta['OmegaLambda']+(1-meta['Omega0']-meta['OmegaLambda'])/a**2)
                    peculiar=archive['velocity_stored'].astype(float)*np.sqrt(a)
                    for tag,cent,expansion in [('catalog_proper',bulk,hubble),('catalog_peculiar',bulk,0.),('trajectory_proper',trajectory,hubble)]:
                        vec=(peculiar-cent+expansion*pos)/lab.obj.bg.vel
                        vr=np.einsum('ij,ij->i',vec,unit)
                        vt=(mu*vr-np.sign(smu)*(vec@axis))/np.maximum(1e-14,np.sin(theta))
                        streams[tag]=(vr,vt)
                for half,(lo,hi) in enumerate(zip(mom.range[:-1],mom.range[1:],strict=True),1):
                    active=(y>=lo)&(y<hi)
                    mass_low=below+mass[y<lo].sum()
                    yy=y[active];tt=theta[active];wm=mass[active]/lab.mesh.mscale
                    for name in ('mass','gravity'):
                        scale=mom.scale(name);sums={}
                        for key in (('D','curvature','field','rest','radial','polar') if snap==590 else ('D',)):
                            arr=mom.fns[name,half,key].ev(yy,tt)*wm*scale
                            if key in ('radial','rest','polar'):sums[key]=arr
                            else:sums[key]=arr.sum()
                        history=sums['D']+mass_low/lab.mesh.mscale*scale*mom.inside[name,half]
                        for tag in streams or ['density']:
                            row=dict(steps=lab.steps,snap=snap,piece=piece,phase=phase,half=half,observable=name,frame=tag,
                                     particle_count=int(active.sum()),density_weight=history)
                            if streams:
                                vr,vt=streams[tag];current=sums['radial']@vr[active]+sums['polar']@vt[active]
                                residual=sums['rest']@vr[active]
                                row.update(curvature=sums['curvature']*lab.obj.unit_myr,field=sums['field'],current=current,
                                           rest=residual,gradient=current-residual,net=sums['field']+current)
                            rows.append(row)
    return rows
if __name__=='__main__':
    steps=int(sys.argv[1]);snap=int(sys.argv[2]);assert steps in (32,64) and snap in (589,590,591)
    check();mom=Moment(steps);rows=mass_energy(mom,snap)
    table(HERE/f'particle-{steps}-{snap}.csv',rows,True)
    if snap==590:table(HERE/f'gradient-{steps}.csv',mom.checks,True)
    print(steps,snap,'particle rows',len(rows),'max gradient error',max(r['derivative_fraction'] for r in mom.checks),flush=True)
