from fractions import Fraction
from math import gamma
import numpy as np
from sources import CHARGES, DECAY, FLAVOR, GRAM, INVERSE, MASS, METRIC, PAIRS, THRESH, dot, stress, tensor
from integrate import project,sky


def two_channel_normalization():
    from sources import alpha,elastic
    from angular import model
    cosine,weight=np.polynomial.legendre.leggauss(64)
    legendre=(3*cosine**2-1)/2
    errors=[]
    for energy in (.56,.65,.74,.80):
        beta=np.sqrt(1-(2*MASS/energy)**2)
        signed,wave,form,_=model().read(energy**2)
        beta2=beta**2
        momentum2=energy**2*beta2/4
        beta_phase=beta/(8*np.pi)
        point=(1-beta2)/(1-beta2*cosine**2)
        shift=(10/3)*(wave-elastic.born(energy**2))*legendre
        emt=4*momentum2/np.sqrt(6)*legendre*form
        mixed=beta_phase*np.real(np.dot(weight/2,(point+1.5*shift)*emt.conjugate()))
        converted=4*np.sqrt(6)*alpha*mixed/energy**5
        reference=2*elastic.KAPPA*beta**3*signed/energy**3
        errors.append(abs(converted/reference-1))
    assert max(errors)<1e-13
    return max(errors)


def coefficients_at_threshold():
    transform=np.array([[1,1,1],[1,-1,-1],[-1,1,-1],[-1,-1,1]])/2
    shapes=[]
    for charge_index,charges in enumerate(CHARGES):
        matrix=np.zeros((4,4))
        for partition,(ia,ib,ic,idp) in enumerate(PAIRS):
            if not FLAVOR[partition,charge_index]:
                continue
            for leg in range(4):
                for other in range(4):
                    coeff=(-3 if leg==other else 3 if (leg in (ia,ib))==(other in (ia,ib)) else -5)
                    matrix[leg,other]+=coeff*charges[leg]*charges[other]
        shapes.append(transform.T@matrix@transform/16)
    projected=np.einsum("jc,cab->jab",FLAVOR,shapes)
    stress_shape=2*(np.eye(3)[:,:,None]*np.eye(3)[:,None,:]-3*np.eye(3)/8)
    mixed_shape=(2/5)*np.sum(projected*stress_shape)*10/(99*24)
    photon_shape=(2/15)*np.einsum("jab,jk,kab",projected,INVERSE,projected)*10/(99*24)
    stress_shape_norm=np.einsum("jab,jk,kab",stress_shape,GRAM,stress_shape)*10/(99*120)
    assert abs(stress_shape_norm-29/704)<1e-15
    common=(MASS*(2*np.pi**4.5/gamma(4.5))*(2*MASS)**5.5)/(8*(2*np.pi)**8*(2*MASS)**4*DECAY**4)
    return dict(mixed_rational_sqrt6=str(Fraction(mixed_shape).limit_denominator(1000000)),
                photon_rational=str(Fraction(photon_shape).limit_denominator(1000000)),
                J4_coefficient=common*mixed_shape/(np.sqrt(6)*MASS**2),
                gamma_coefficient=common*photon_shape/MASS**4,stress_coefficient=common*stress_shape_norm)


def control():
    order=4
    rays=sky(order)
    mom=stress.events(.76,.329,.358,np.array([.18]),np.array([-.38]),np.array([1.23]),MASS)[0]
    fast,mixed_rate=project(mom,.76,rays)
    raw,expected_rate=np.zeros((3,3,3)),0.
    ward_error=bose_error=permutation_error=0.
    missing=[]
    charges=[(1,-1,0,0),(1,-1,1,-1)]
    for ray in rays:
        direction=ray[:3]
        first=.38*np.r_[1.,direction]
        second=.38*np.r_[1.,-direction]
        for charge in charges:
            mat=tensor(mom[0],charge,first,second)
            lower=first@METRIC
            ward_error=max(ward_error,np.max(abs(lower@mat)),np.max(abs(mat@(METRIC@second))))
            missing.append(np.linalg.norm(lower@tensor(mom[0],charge,first,second,False)))
            bose_error=max(bose_error,np.max(abs(mat-tensor(mom[0],charge,second,first).T)))
            perm=[2,0,3,1]
            swapped=tensor(mom[0,perm],np.array(charge)[perm],first,second)
            permutation_error=max(permutation_error,np.max(abs(mat-swapped)))
        basis=ray[3:9].reshape(2,3)
        expected_rate+=ray[9]*np.sum((basis@tensor(mom[0],charges[0],first,second)[1:,1:]@basis.T)**2)
        for charge_index in np.nonzero(FLAVOR.any(axis=0))[0]:
            mat=tensor(mom[0],CHARGES[charge_index],first,second)
            raw+=(-np.trace(basis@mat[1:,1:]@basis.T)/4*FLAVOR[:,charge_index,None,None])*ray[10:].reshape(3,3)
    assert max(ward_error,bose_error,permutation_error)<3e-11 and min(missing)>1.
    assert np.max(abs(fast[0]-raw))<5e-12 and abs(mixed_rate[0]/expected_rate-1)<5e-13
    assert not np.any(tensor(mom[0],(0,0,0,0),first,second))
    rest=np.tile([MASS,0.,0.,0.],(4,1))
    first=2*MASS*np.array([1.,0,0,1.])
    second=2*MASS*np.array([1.,0,0,-1.])
    threshold=-np.trace(tensor(rest,charges[0],first,second)[1:3,1:3])/4
    assert abs(threshold*(-4*DECAY**2/3)-1)<5e-15
    born_error=residue_error=two_projection=0.
    energy=.71
    first=np.array([1.,0,0,1.])*energy/2
    second=np.array([1.,0,0,-1.])*energy/2
    beta=np.sqrt(1-(2*MASS/energy)**2)
    cosines,weights=np.polynomial.legendre.leggauss(64)
    for angle,weight in zip(cosines,weights):
        positive=energy/2*np.r_[1.,beta*np.sqrt(1-angle**2),0.,beta*angle]
        negative=first+second-positive
        born=(2*METRIC+np.outer(2*positive-first,2*negative-second)/(-2*dot(positive,first))+
              np.outer(2*negative-first,2*positive-second)/(-2*dot(positive,second)))
        stripped=(np.outer(2*positive-first,2*positive-2*first-second)/(-2*dot(positive,first))+
                  np.outer(2*positive-2*second-first,2*positive-second)/(-2*dot(positive,second))-2*METRIC)
        residue_error=max(residue_error,np.max(abs(stripped+born)))
        helicity=-np.trace(born[1:3,1:3])/4
        born_error=max(born_error,abs(helicity-(1-beta**2)/(1-beta**2*angle**2)))
        two_projection+=weight/2*(3*angle**2-1)/2*helicity
    from sources import elastic
    assert max(residue_error,born_error,abs(two_projection-elastic.born(energy**2)))<2e-13
    return dict(ward_abs=float(ward_error),omitted_seagull_min_norm=float(min(missing)),bose_abs=float(bose_error),
                permutation_abs=float(permutation_error),native_flavor_and_spin_abs=float(np.max(abs(fast[0]-raw))),
                native_rate_relative=float(mixed_rate[0]/expected_rate-1),threshold_mixed_charge_b=float(threshold),
                two_pion_Born_max_error=float(born_error),external_pole_sign_check=float(residue_error),
                born_D_wave_error=float(two_projection-elastic.born(energy**2)),two_channel_conversion_relative=two_channel_normalization(),
                threshold=coefficients_at_threshold())


if __name__=="__main__":
    print(control())

