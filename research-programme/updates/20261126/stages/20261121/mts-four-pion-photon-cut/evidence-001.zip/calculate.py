import csv
import json
import numpy as np
from checks import control
from integrate import integrate
from sources import PRIOR, THRESH, roots_legendre, save, table

MEDIUM=(7,5,10,8)
FINE=(9,6,12,10)


def calculate():
    controls=control()
    comparison=(THRESH+.0005,THRESH+.001,.60,.70,.80,.85)
    points=[]
    for energy in comparison:
        for rule in (MEDIUM,FINE):
            points.append(integrate(energy,rule))
        print("verified energy",energy,flush=True)
    for rule in ((9,6,12,14),(10,8,16,10)):
        points.append(integrate(.8,rule))
    table("four-pion.csv",points)
    central=[row for row in points if row["rule"]=="9-6-12-10"]
    quantities=("J4_GeV2","photon_norm","stress_norm_GeV4","mixed_charge_unpolarized_nb")
    differences=[max(abs(test[name]/ref[name]-1) for name in quantities)
                 for test in points for ref in central if test["W_GeV"]==ref["W_GeV"]]
    assert max(differences)<.001, differences
    controls["max_relative_grid_test"]=max(differences)
    with (PRIOR/"stress-norm.csv").open() as stream:
        old={float(row["W_GeV"]):float(row["spec4_LO_GeV4"]) for row in csv.DictReader(stream)}
    controls["recovered_stress_max_relative"]=max(abs(row["stress_norm_GeV4"]/old[row["W_GeV"]]-1)
                                                for row in central if row["W_GeV"] in old)
    assert controls["recovered_stress_max_relative"]<1e-5
    for key,target in zip(quantities[:3],("J4_coefficient","gamma_coefficient","stress_coefficient")):
        threshold_limit=(2*central[0][key]/(central[0]["W_GeV"]-THRESH)**5.5-
                         central[1][key]/(central[1]["W_GeV"]-THRESH)**5.5)
        controls["extrapolated_"+key]=threshold_limit/controls["threshold"][target]-1
        assert abs(controls["extrapolated_"+key])<8e-5
    with (PRIOR/"window-moments.csv").open() as stream:
        elastic=sum(float(row["reference_GeVminus2"]) for row in csv.DictReader(stream)
                    if row["status"]=="one_channel_reference_only")
    samples=[]
    integrals=[]
    for order,rule in ((5,MEDIUM),(8,MEDIUM),(8,FINE)):
        node,weights=roots_legendre(order)
        span=.80-THRESH
        terms=[]
        for coordinate,weight in zip(node,weights):
            row=integrate(THRESH+span*(1+coordinate)/2,rule)
            terms.append(weight*span/2*row["signed_integrand_GeVminus3"])
            samples.append(dict(energy_order=order,weight_GeV=weight*span/2,**row))
        total=sum(terms)
        integrals.append(dict(energy_order=order,rule="-".join(map(str,rule)),direct_GeVminus2=total,
                              prior_one_channel_reference_GeVminus2=elastic,direct_over_reference=total/elastic))
        print("integrated",integrals[-1],flush=True)
    assert max(abs(row["direct_GeVminus2"]/integrals[-1]["direct_GeVminus2"]-1) for row in integrals)<.001
    table("window-nodes.csv",samples)
    table("window.csv",integrals)
    argus=json.loads((PRIOR/"argus-four-mixed.json").read_bytes())
    first=argus["values"][0]
    assert float(first["x"][0]["value"])==central[-1]["W_GeV"]
    controls["ARGUS_mixed_charge"]={"W_GeV":central[-1]["W_GeV"],"tree_nb":central[-1]["mixed_charge_unpolarized_nb"],
                                     "entry":first["y"][0],"data_doi":argus["doi"]}
    save("checks.json",controls)


if __name__=="__main__":
    calculate()

