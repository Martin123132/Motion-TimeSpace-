import ctypes
from functools import lru_cache
import numpy as np
from sources import DECAY, MASS, THRESH, NB, HERE, INVERSE, alpha, coefficients, dot, roots_legendre, stress
import angular

array=np.ctypeslib.ndpointer(dtype=np.float64,flags="C_CONTIGUOUS")
native=ctypes.CDLL(str(HERE/"project.dll")).project
native.argtypes=[ctypes.c_int,ctypes.c_int,ctypes.c_double]+[array]*6
native.restype=None


@lru_cache(None)
def sky(order):
    cosine,weights=roots_legendre(order)
    phase=2*np.pi*np.arange(2*order)/(2*order)
    angle,azimuth=np.meshgrid(cosine,phase,indexing="ij")
    angle,azimuth=angle.ravel(),azimuth.ravel()
    sine=np.sqrt(1-angle**2)
    ray=np.stack((sine*np.cos(azimuth),sine*np.sin(azimuth),angle),-1)
    polar=np.stack((angle*np.cos(azimuth),angle*np.sin(azimuth),-sine),-1)
    perp=np.stack((-np.sin(azimuth),np.cos(azimuth),np.zeros_like(angle)),-1)
    weight=np.repeat(weights/(4*order),2*order)
    shape=ray[:,:,None]*ray[:,None,:]-np.eye(3)/3
    return np.ascontiguousarray(np.c_[ray,polar,perp,weight,(weight[:,None,None]*shape).reshape(len(ray),9)])


def project(mom,energy,directions):
    mom=np.ascontiguousarray(mom,dtype=np.float64)
    scalar,linear=coefficients(mom)
    projected=np.zeros((len(mom),3,3,3))
    unpol=np.zeros(len(mom))
    native(len(mom),len(directions),energy,mom,scalar,linear,directions,projected,unpol)
    neutral=mom[:,2]+mom[:,3]
    unpol*=((dot(neutral,neutral)-MASS**2)/DECAY**2)**2
    return projected,unpol


def integrate(energy,rule):
    mass_order,decay_order,az_count,beam_order=rule
    nodes,mw=stress.mass_rule(mass_order)
    cosines,aw=roots_legendre(decay_order)
    pair_a,pair_b,cos_a,cos_b,az=np.meshgrid(nodes,nodes,cosines,cosines,np.arange(az_count)*2*np.pi/az_count,indexing="ij")
    excess=energy-THRESH
    mass_a=2*MASS+excess*pair_a
    slack=excess*(1-pair_a)
    mass_b=2*MASS+slack*pair_b
    mom,relative=stress.events(energy,mass_a,mass_b,cos_a,cos_b,az,MASS)
    measure=(4*mass_a*mass_b*excess*slack*relative*np.sqrt(1-(2*MASS/mass_a)**2)*np.sqrt(1-(2*MASS/mass_b)**2)/
             ((2*np.pi)**2*(8*np.pi)**3))
    weight=(measure*mw[:,None,None,None,None]*mw[None,:,None,None,None]*aw[None,None,:,None,None]*
            aw[None,None,None,:,None]/(4*az_count)).ravel()
    mom=mom.reshape(-1,4,4)
    totals=np.zeros(4)
    for start in range(0,len(mom),512):
        packet=mom[start:start+512]
        contact,poles=stress.vertices(packet)
        emt=stress.tracefree((contact+poles)[...,1:,1:])
        photon,unpol=project(packet,energy,sky(beam_order))
        photon_norm=(7.5/24)*np.einsum("ejab,jk,ekab->e",photon,INVERSE,photon)
        mixed=np.sum(photon*emt,axis=(1,2,3))*np.sqrt(1.5)/24
        stress_norm=(6*np.sum(emt**2,axis=(1,2,3))+3*np.sum(emt.sum(axis=1)**2,axis=(1,2)))/120
        assert np.all(abs(mixed)<=np.sqrt(photon_norm*stress_norm)*(1+5e-12))
        totals+=weight[start:start+len(packet)]@np.array([mixed,photon_norm,stress_norm,unpol]).T
    mixed,photon_norm,stress_norm,unpol=totals
    beta=np.sqrt(1-(2*MASS/energy)**2)
    phase2=beta/(8*np.pi)
    wave=angular.read_wave(energy)
    stress_ref=abs(angular.elastic.omega(energy**2))*(1-.01*energy**2)
    two_gamma=(10/3)*abs(wave)**2*phase2
    two_stress=1.5*phase2*(8/15)*(energy*beta/2)**4*stress_ref**2
    two_mixed=np.sqrt(two_gamma*two_stress)
    intensity=unpol*(4*np.pi*alpha)**2*NB/(16*energy**2)
    return dict(W_GeV=energy,rule="-".join(map(str,rule)),J4_GeV2=mixed,photon_norm=photon_norm,
                stress_norm_GeV4=stress_norm,signed_integrand_GeVminus3=4*np.sqrt(6)*alpha*mixed/energy**5,
                r_gamma=np.sqrt(photon_norm/two_gamma),r_T=np.sqrt(stress_norm/two_stress),
                direct_over_abs_elastic=mixed/two_mixed,correlation=mixed/np.sqrt(photon_norm*stress_norm),
                mixed_charge_unpolarized_nb=intensity)

