import csv
import hashlib
import json
import sys
from itertools import product
from pathlib import Path

import numpy as np

HERE=Path(__file__).resolve().parent
PRIOR=HERE.parent/"mts-four-pion-stress-bridge-20261121"
seal=(PRIOR/"seal.json").read_bytes()
assert hashlib.sha256(seal).hexdigest()=="f0c870961439fd514759ae2df293e50307b56c28cb4d4a75c48d459ab14facf8"
for name,digest in json.loads(seal).items():
    assert hashlib.sha256((PRIOR/name).read_bytes()).hexdigest()==digest
sys.path.insert(0,str(PRIOR))
import stress
from common import DECAY,MASS,NB,THRESH,alpha,elastic,roots_legendre

PAIRS=stress.PAIRS
METRIC=stress.METRIC
CHARGES=np.array(list(product((-1,0,1),repeat=4)))
FLAVOR=np.array([(CHARGES[:,ia]+CHARGES[:,ib]==0)&(CHARGES[:,ic]+CHARGES[:,idp]==0)
                 for ia,ib,ic,idp in PAIRS],float)
GRAM=FLAVOR@FLAVOR.T
INVERSE=np.linalg.inv(GRAM)
WEIGHTS=np.einsum("kf,jf,fi,fl->kjil",FLAVOR,FLAVOR,CHARGES,CHARGES)
assert np.array_equal(GRAM,6*np.eye(3)+3)
dot=stress.dot


def save(name,result):
    (HERE/name).write_text(json.dumps(result,indent=2,allow_nan=False)+"\n",encoding="utf8")


def table(name,results):
    with (HERE/name).open("w",newline="",encoding="utf8") as stream:
        writer=csv.DictWriter(stream,fieldnames=results[0])
        writer.writeheader()
        writer.writerows(results)


def tensor(mom,charge,first,second,contact=True):
    charge=np.asarray(charge)
    answer=np.zeros((4,4))
    both=first+second
    for ia,ib,ic,idp in PAIRS:
        if charge[ia]+charge[ib] or charge[ic]+charge[idp]:
            continue
        def strong(left,right):
            subset=mom[ia]+mom[ib]
            if left in (ia,ib):
                subset=subset-first
            if right in (ia,ib):
                subset=subset-second
            return (dot(subset,subset)-MASS**2)/DECAY**2
        for leg,ext in enumerate(mom):
            if not charge[leg]:
                continue
            den1=-2*dot(ext,first)
            den2=-2*dot(ext,second)
            denq=dot(both,both)-2*dot(ext,both)
            term=(np.outer(2*ext-first,2*ext-2*first-second)/den1+
                  np.outer(2*ext-2*second-first,2*ext-second)/den2)
            if contact:
                term-=2*METRIC
            answer+=charge[leg]**2*strong(leg,leg)*term/denq
            for other,ext2 in enumerate(mom):
                if other!=leg and charge[other]:
                    answer+=charge[leg]*charge[other]*strong(leg,other)*np.outer(
                        2*ext-first,2*ext2-second)/(den1*(-2*dot(ext2,second)))
    return answer


def coefficients(mom):
    energy=mom[0,:,0].sum()
    scalar=np.zeros((len(mom),3,4,4))
    linear=np.zeros((len(mom),3,4,4,3))
    for partition,(ia,ib,ic,idp) in enumerate(PAIRS):
        pair=mom[:,ia]+mom[:,ib]
        same=dot(pair,pair)-MASS**2
        other=mom[:,ic]+mom[:,idp]
        opp=dot(other,other)-MASS**2
        for leg in range(4):
            for last in range(4):
                left=leg in (ia,ib)
                right=last in (ia,ib)
                if left and right:
                    base=opp
                elif not left and not right:
                    base=same
                else:
                    base=same-energy*pair[:,0]
                    linear[:,:,leg,last]+=((1 if left else -1)*energy*pair[:,None,1:]*
                                           WEIGHTS[partition,None,:,leg,last,None])
                scalar[:,:,leg,last]+=base[:,None]*WEIGHTS[partition,:,leg,last]
    return np.ascontiguousarray(scalar/DECAY**2),np.ascontiguousarray(linear/DECAY**2)
