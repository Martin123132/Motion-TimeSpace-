import argparse
import hashlib
import json
from pathlib import Path
import numpy as np
from integrate import integrate
from sources import HERE,MASS,save,table

SOURCE="https://users.ph.nat.tum.de/T39/T39_files/T39_people_files/duell_files/Dipl-MultiPion.pdf"
DIGEST="47c7bde79cca520230c22343d2a4fd2a673b367e8bba8011d055c0a01d14988b"
RATIOS=(5.,5.25,5.5,5.75,6.25)


def extract(path):
    import fitz
    data=Path(path).read_bytes()
    assert hashlib.sha256(data).hexdigest()==DIGEST
    with fitz.open(stream=data,filetype="pdf") as doc:
        page=doc[66]
        assert "Figure 5.9:" in page.get_text()
        drawing=page.get_drawings()
        x_ticks=[drawing[idx]["rect"].x0 for idx in range(72,93,5)]
        y_ticks=[drawing[idx]["rect"].y0 for idx in range(94,125,5)]
        markers=[d["rect"] for d in drawing if d["color"] and .45<d["color"][0]<.55 and d["rect"].width<.001]
        transform_x=np.polyfit(x_ticks,np.arange(4.,9.),1)
        transform_y=np.polyfit(y_ticks,np.arange(0,3.5,.5),1)
        assert max(abs(np.polyval(transform_x,x_ticks)-np.arange(4.,9.)))<2e-5
        assert max(abs(np.polyval(transform_y,y_ticks)-np.arange(0,3.5,.5)))<2e-5
        points=[]
        for ratio in RATIOS:
            matched=[r for r in markers if abs(np.polyval(transform_x,r.x0)-ratio)<2e-5]
            assert len(matched)==1
            rect=matched[0]
            points.append(dict(ratio=ratio,plot_x=rect.x0,plot_y_top=rect.y0,plot_y_bottom=rect.y1,
                               published_tree_nb=float(np.polyval(transform_y,(rect.y0+rect.y1)/2))))
        return dict(source=SOURCE,sha256=DIGEST,figure="5.9; printed p.67; lower mixed-charge error bars",
                    x_ticks=x_ticks,y_ticks=y_ticks,points=points)


def run(pdf=None):
    if pdf:
        save("external-points.json",extract(pdf))
    receipt=json.loads((HERE/"external-points.json").read_bytes())
    assert receipt["sha256"]==DIGEST and receipt["source"]==SOURCE
    rows=[]
    for item in receipt["points"]:
        energy=MASS*item["ratio"]
        calc=integrate(energy,(9,6,12,10))["mixed_charge_unpolarized_nb"]
        delta=calc/item["published_tree_nb"]-1
        rows.append(dict(W_GeV=energy,W_over_m=item["ratio"],published_tree_nb=item["published_tree_nb"],
                         calculated_tree_nb=calc,fractional_difference=delta))
    table("external-comparison.csv",rows)
    print(rows,flush=True)


if __name__=="__main__":
    parser=argparse.ArgumentParser()
    parser.add_argument("--pdf")
    run(parser.parse_args().pdf)

