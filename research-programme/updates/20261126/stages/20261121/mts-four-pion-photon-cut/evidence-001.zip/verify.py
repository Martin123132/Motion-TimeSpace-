import argparse
import csv
import hashlib
import json
from pathlib import Path
from sources import HERE,PRIOR

FILES=("sources.py","project.cpp","project.dll","build.cmd","calculate.py","integrate.py","checks.py",
       "external_check.py","external-points.json","external-comparison.csv","checks.json","four-pion.csv",
       "window-nodes.csv","window.csv","DERIVATION.md","RESULTS.md","REPLAY.md","verify.py")


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def verify(seal=False):
    data={name:digest(HERE/name) for name in FILES}
    receipt=HERE/"seal.json"
    if seal:
        with receipt.open("x",encoding="utf8",newline="\n") as stream:
            stream.write(json.dumps(data,indent=2)+"\n")
    assert json.loads(receipt.read_bytes())==data
    assert set(data)|{"seal.json"}=={item.name for item in HERE.iterdir() if item.is_file()}
    def rows(name):
        with (HERE/name).open() as stream:
            return list(csv.DictReader(stream))
    values=rows("four-pion.csv")
    assert len(values)==14 and len(rows("window-nodes.csv"))==21 and len(rows("window.csv"))==3
    checks=json.loads((HERE/"checks.json").read_bytes())
    assert checks["two_channel_conversion_relative"]<1e-13
    assert checks["omitted_seagull_min_norm"]>1 and checks["ward_abs"]<1e-11
    external=rows("external-comparison.csv")
    assert len(external)==5 and max(abs(float(row["fractional_difference"])) for row in external)<.003
    assert all(0<float(row["correlation"])<=1 for row in values)
    print("Verified",len(data),"stage files,",digest(receipt),"prior",digest(PRIOR/"seal.json"))


if __name__=="__main__":
    parser=argparse.ArgumentParser()
    parser.add_argument("--seal",action="store_true")
    verify(parser.parse_args().seal)

