from library import solver as task
import sys

np=task.np
def grade(grid,seed):
    lock=task.lock()
    tides=[];regional=[];volume=[];changed=[]
    root=task.HERE
    refs={(int(row["seed"]),float(row["width"]),round(1024*float(row["fraction"]))):row
          for row in task.read(task.FORM/"matched-gravity-prediction.csv")}
    oldt={(int(row["grid"]),int(row["seed"]),int(row["tick"]),float(row["width"]),row["channel"]):row
          for row in task.read(task.FORM/"proper-tides-full.csv")}
    both={}
    for flag in (0,1):
        with task.system(grid,seed,flag) as model:
            for tick in task.CLOCKS:
                name=task.tag(grid,seed,flag,tick)
                meta=task.meta(root/(name+".json"))
                assert meta["design"]==lock and meta["sha"]==task.lab.sha(root/(name+".npz"))
                with np.load(root/(name+".npz")) as candidate,np.load(task.original(grid,seed,flag,tick)) as saved:
                    radius=candidate["r"];clock=float(candidate["clock"])
                    oldst=task.old.Difference(saved["shared"],saved["signed"])
                    newst=task.old.Difference(candidate["shared"],candidate["signed"])
                    original=task.evaluate(model,oldst,clock)
                    for key,stored in (("ind_P","ind_P" if tick==256 else "independent"),("J","J")):
                        np.testing.assert_allclose(original[key],saved[stored],atol=0,rtol=1e-12)
                    for comp in ("shared","signed"):
                        assert np.array_equal(candidate[comp][:,0],saved[comp][:,0])
                    for key in ("ind_P","P","ind_J","J","ind_H","alt_H","H"):
                        for region,mask in (("first",radius<1/grid),("core",radius<.3),("bulk",(radius>.6)&(radius<2.1))):
                            before=original[key][mask];after=candidate[key][mask]
                            before_j=np.linalg.norm(original["J"][mask]);after_j=np.linalg.norm(candidate["J"][mask])
                            old_size=np.linalg.norm(before);new_size=np.linalg.norm(after)
                            regional.append(dict(flag=flag,tick=tick,field=key,region=region,old_first=before[0],new_first=after[0],
                                           old_norm=old_size,new_norm=new_size,change_norm=np.linalg.norm(after-before),
                                           ratio=new_size/old_size if old_size else "",old_material_norm=before_j,new_material_norm=after_j,
                                           old_over_current=old_size/before_j if key in ("P","ind_P") and before_j else "",
                                           new_over_current=new_size/after_j if key in ("P","ind_P") and after_j else ""))
                    norm=np.linalg.norm
                    for slot in range(len(newst.delta)):
                        for reg,label in ((radius<.3,"core"),((radius>.6)&(radius<2.1),"bulk")):
                            a=oldst.delta[slot,1,reg];b=newst.delta[slot,1,reg]
                            changed.append(dict(flag=flag,tick=tick,slot=slot,region=label,old_norm=norm(a),new_norm=norm(b),
                                                change_norm=norm(b-a),change_over_old=norm(b-a)/norm(a) if norm(a) else ""))
                    for level,edge in enumerate((.025,.3)):
                        for index,order in enumerate((0,8,16)):
                            for k,ch in enumerate(("cartesian","spherical","current")):
                                a=original["weak"][level,index,k];b=candidate["weak"][level,index,k]
                                volume.append(dict(flag=flag,tick=tick,radius=edge,order=order,channel=ch,old=a,new=b,diff=b-a))
                    both[tick,flag]=original["tide"],candidate["tide"]
    for tick in task.CLOCKS:
        for idx,width in enumerate((.15,.3)):
            reference=refs[seed,width,tick]
            unit=abs(float(reference["matched_newton"]))*1e-6
            expect=float(reference["matched"]);newton=float(reference["matched_newton"])
            for j,channel in enumerate(("ricci","gauss")):
                old=both[tick,0][0][idx,j]-both[tick,1][0][idx,j]
                new=both[tick,0][1][idx,j]-both[tick,1][1][idx,j]
                prev=oldt[grid,seed,tick,width,channel]
                assert abs(old-float(prev["new"]))<1e-4*unit
                residual=(new-expect)/unit
                tides.append(dict(tick=tick,width=width,channel=channel,matched=expect,matched_newton=newton,
                                  old=old,new=new,residual_ppm=residual,old_ppm=(old-expect)/unit,
                                  change_ppm=(new-old)/unit,newton_only_ppm=(new-newton)/unit,inside=abs(residual)<=20))
    for name,rows in (("regions",regional),("weak",volume),("slots",changed),("bands",tides)):
        task.table(f"g{grid}-s{seed}-{name}.csv",rows)
    print(grid,seed,"bands",sum(row["inside"] for row in tides),"/",len(tides),"max ppm",max(abs(row["residual_ppm"]) for row in tides),flush=True)
    print("end P/J",[(row["flag"],row["old_over_current"],row["new_over_current"]) for row in regional
          if (row["region"],row["tick"],row["field"])==("first",1024,"ind_P")],flush=True)

if __name__=="__main__":
    grade(*map(int,sys.argv[1:]))

