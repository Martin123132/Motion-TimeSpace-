"""Conditional curvature of the curved TT completion for the measured radial change."""
import sys
from library import solver as task
np=task.np

def run(grid,seed):
    task.lock();rows=[]
    for flag in (0,1):
        with task.system(grid,seed,flag) as model:
            r=model.shell.r
            for tick in task.CLOCKS:
                key=task.tag(grid,seed,flag,tick)
                assert task.meta(task.HERE/(key+".json"))["sha"]==task.lab.sha(task.HERE/(key+".npz"))
                with np.load(task.HERE/(key+".npz")) as new,np.load(task.original(grid,seed,flag,tick)) as orig:
                    original=task.old.Difference(orig["shared"],orig["signed"])
                    changed=task.old.Difference(new["shared"]-orig["shared"],new["signed"]-orig["signed"])
                    assert not np.any(changed.base[:,0]) and not np.any(changed.delta[:,0])
                    time=float(new["clock"]);mapped=model.mass.decode(original)[0]
                    _,_,bg,_=model.lift.physical(mapped,time)
                    bp,ep,ell,bend=(bg[k] for k in ("bg","eg","ell","bend"))
                    bpp=model.reference[1][2][0]+model.shell.diff(mapped[1,0].real,2)
                    warp=2*bg["ne"]*(np.expm1(2*(ell-bend))/r**2-ep/r-bp*ep+bpp)
                    ric=-3*bg["X"]-bg["R"]/2
                    profile=changed[0,1].real
                    trial=warp*profile;other=ric*profile
                    actual=new["ind_H"]-task.compute(model,original,time)["ind_H"]
                    for reg,mask in (("first",r<1/grid),("core",r<.3),("bulk",(r>.6)&(r<2.1))):
                        n=np.linalg.norm
                        denominator=n(actual[mask]);size=n(trial.delta[mask])
                        bound=(np.max(abs(warp.base[mask]))*n(profile.delta[mask])+
                               np.max(abs(warp.delta[mask]))*n((profile.base+profile.delta)[mask]))
                        assert size<=bound*(1+1e-12)
                        rows.append(dict(flag=flag,tick=tick,region=reg,mismatch_norm=denominator,trial_TT_scalar_norm=size,
                                         trial_signed_first=trial.delta[mask][0],two_geometry_forms_difference=n((other.delta-trial.delta)[mask]),
                                         conditional_bound=bound,trial_over_mismatch=size/denominator if denominator else "",
                                         bound_over_mismatch=bound/denominator if denominator else ""))
    task.table(f"g{grid}-s{seed}-curved-TT.csv",rows)
    print("curved",grid,seed,[(r["flag"],r["bound_over_mismatch"]) for r in rows if (r["tick"],r["region"])==(1024,"first")],flush=True)
if __name__=="__main__":run(*map(int,sys.argv[1:]))

