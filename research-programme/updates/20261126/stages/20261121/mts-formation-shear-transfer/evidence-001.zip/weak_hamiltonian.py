"""Test the flat scalar curvature variation weakly on the actual metric change."""
from library import solver as task
from spatial_budget import curvature
from scipy.interpolate import CubicSpline
from numpy.polynomial.legendre import leggauss
from math import fsum
import sys
np=task.np

def weak(radius, metric, point, edge, order, method):
    step=radius[1]-radius[0];count=round(edge/step)
    assert abs(count*step-edge)<1e-12
    nodes=np.r_[-radius[7::-1],radius[:count+6]]
    query,weight=leggauss(order)
    axis=((np.arange(count)[:,None]+(query+1)/2)*step).ravel()
    weights=np.tile(weight*step/2,count)
    def interpolate(values):
        ext=np.r_[values[7::-1],values[:count+6]]
        if method=="cubic":return CubicSpline(nodes,ext)(axis)
        if method=="linear":return np.interp(axis,nodes,ext)
        raise ValueError(method)
    ell,bend,tilt,tensor=(interpolate(value) for value in metric)
    remainder=1-(axis/edge)**2
    win=remainder**6
    dw=-12*axis/edge**2*remainder**5
    d2=-12/edge**2*remainder**5+120*axis**2/edge**4*remainder**4
    dr=win+axis*dw
    ddr=2*win+4*axis*dw+axis**2*d2
    terms=[(-4*dr+16*win)*ell,(-4*ddr+12*dr+8*win)*bend,(12*dr-24*win)*tilt,12*win*tensor]
    norm=fsum(weights*axis**2*win)
    weakval=sum(fsum(weights*value) for value in terms)/norm
    strong=fsum(weights*axis**2*win*interpolate(point))/norm
    return weakval,strong,sum(fsum(weights*abs(value)) for value in terms)/norm

def control():
    rows=[]
    for grid in (320,640):
        rad=(np.arange(grid)+.5)/grid
        for edge in (.025,.15,.3):
            for kind in ("constant-D","nonzero-scalar","null"):
                zero=np.zeros_like(rad)
                if kind=="constant-D":
                    metric=(zero,zero,zero,np.ones_like(rad));point=12/rad**2
                    xi,wt=leggauss(40);x=edge*(1+xi)/2
                    exact=12*np.dot(wt,(1-(x/edge)**2)**6)/np.dot(wt,x*x*(1-(x/edge)**2)**6)
                elif kind=="nonzero-scalar":
                    metric=(zero,zero,zero,rad**2);point=12*np.ones_like(rad);exact=12.
                else:
                    ell=1+.7*rad**2;tilt=1+7*rad**2/6
                    metric=(ell,-ell/2,tilt,rad*(7*rad/3)/2+1.5*tilt-ell/2)
                    point=zero;exact=0.
                result,_,scale=weak(rad,metric,point,edge,16,"cubic")
                assert abs(result-exact)/max(abs(exact),scale)<1e-12
                rows.append(dict(grid=grid,edge=edge,kind=kind,analytic=exact,weak=result,absolute_error=abs(result-exact)))
    task.table("weak-H-controls.csv",rows)

def study(grid,seed):
    task.lock();control()
    rows=[]
    for flag in (0,1):
        with task.system(grid,seed,flag) as model:
            radius=model.shell.r
            for tick in task.CLOCKS:
                key=task.tag(grid,seed,flag,tick)
                assert task.meta(task.HERE/(key+".json"))["sha"]==task.lab.sha(task.HERE/(key+".npz"))
                with np.load(task.HERE/(key+".npz")) as new,np.load(task.original(grid,seed,flag,tick)) as old:
                    clock=float(new["clock"])
                    oldstate=task.old.Difference(old["shared"],old["signed"])
                    newstate=task.old.Difference(new["shared"],new["signed"])
                    original=task.compute(model,oldstate,clock)
                    before=task.lab.rawfield(model,oldstate,clock);after=task.lab.rawfield(model,newstate,clock)
                    metric=after.delta[:4,1].real-before.delta[:4,1].real
                    flat=curvature(grid,metric,radius,model.shell.weights,model.shell.average)
                    full=new["ind_H"]-original["ind_H"]
                    for edge in (.025,.15,.3):
                        for method in ("cubic","linear"):
                            for order in (8,16):
                                val,point,scale=weak(radius,metric,flat,edge,order,method)
                                _,extra,_=weak(radius,metric,full-flat,edge,order,method)
                                rows.append(dict(flag=flag,tick=tick,edge=edge,method=method,order=order,
                                                 volume_flat_weak=val,volume_flat_point=point,
                                                 volume_nonflat_remainder=extra,volume_full_point=point+extra,
                                                 weak_flat_plus_read_remainder=val+extra,
                                                 absolute_weak_terms=scale,peak_full_point=np.max(abs(full[radius<edge]))))
    task.table(f"g{grid}-s{seed}-weak-H.csv",rows)
if __name__=="__main__":study(*map(int,sys.argv[1:]))

