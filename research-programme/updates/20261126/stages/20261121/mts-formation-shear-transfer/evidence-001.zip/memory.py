"""Transport the measured pre-960 angular discrepancy without reapplying its sources."""
from library import solver as task
from curved_tangent import system,anchor
import sys
np=task.np

def product(flag,variant,sub):
    assert variant in ("memory","forced") and (sub in (1,2) if variant=="memory" else sub==2)
    task.lock()
    grid=640;seed=1
    t0=960;stop=1024
    root=task.HERE;seedname=task.tag(grid,seed,flag,t0)
    assert task.meta(root/(seedname+".json"))["sha"]==task.lab.sha(root/(seedname+".npz"))
    with system(seed,flag,int(variant=="forced"),int(variant=="forced")) as model,task.flux(model,grid):
        initial,when=anchor(seed,flag,t0)
        with np.load(root/(seedname+".npz")) as current:
            assert float(current["clock"])==when
            assert np.array_equal(current["shared"][:,0],initial.base[:,0]) and np.array_equal(current["signed"][:,0],initial.delta[:,0])
            if variant=="memory":
                for first,field in ((initial.base,"shared"),(initial.delta,"signed")):
                    first[:,1]=current[field][:,1]-first[:,1]
            else:
                initial=task.old.Difference(current["shared"],current["signed"])
        dt=4096*np.pi/(1024*model.shell.mu);step=model.time_step(dt/sub);state=initial
        assert dt*t0==when
        for num in range(t0*sub,stop*sub+1):
            if num%(8*sub)==0:task.guard()
            if num>t0*sub:state=step((num-1)*dt/sub,state)
            if num not in (t0*sub,stop*sub):continue
            time=num*dt/sub;data=task.compute(model,state,time)
            name=f"window-f{flag}-{variant}-d{sub}-t{num//sub}.npz"
            task.packet(name,dict(base=state.base[:,1],delta=state.delta[:,1],H=data["H"],P=data["P"],ind_H=data["ind_H"],ind_P=data["ind_P"],
                                  J=data["J"],ind_J=data["ind_J"],radius=model.shell.r,clock=time))
    print("window",flag,variant,sub,flush=True)

def window_scores():
    rows=[];traces=[]
    for flag in (0,1):
        for tick in (960,1024):
            last=task.PRIOR/f"w20-s1-off{flag}-control-t{tick}.npz"
            assert task.meta(task.PRIOR/f"w20-s1-off{flag}-control.json")["files"][last.name]==task.lab.sha(last)
            newest=task.HERE/(task.tag(640,1,flag,tick)+".npz")
            with np.load(newest) as full,np.load(last) as hybrid,np.load(task.HERE/f"window-f{flag}-memory-d1-t{tick}.npz") as native,np.load(task.HERE/f"window-f{flag}-memory-d2-t{tick}.npz") as half,np.load(task.HERE/f"window-f{flag}-forced-d2-t{tick}.npz") as forced:
                radius=full["r"]
                for field in ("base","delta","H","P","ind_H","ind_P","J","ind_J"):
                    value=full[{"base":"shared","delta":"signed"}.get(field,field)]
                    if field in ("base","delta"):value=value[:,1]
                    partial=hybrid[field];target=value-partial
                    for region,mask in (("first",radius<1/640),("core",radius<.3),("bulk",(radius>.6)&(radius<2.1))):
                        norm=np.linalg.norm
                        current=value[...,mask];diff=target[...,mask];size=norm(diff)
                        a=native[field][...,mask];b=half[field][...,mask];c=forced[field][...,mask]
                        rows.append(dict(flag=flag,tick=tick,field=field,region=region,direct_norm=norm(a),target_norm=size,
                                         carry_absolute_error=norm(a-diff),carry_relative=norm(a-diff)/size if size else "",
                                         half_carry_minus_native=norm(a-b),half_difference_over_signal=norm(a-b)/norm(a) if norm(a) else "",
                                         half_forced_change=norm(c-current),half_forced_change_over_native=norm(c-current)/norm(current) if norm(current) else ""))
                    if field not in ("base","delta"):
                        traces.append(dict(flag=flag,tick=tick,field=field,continuous=value[0],hybrid=partial[0],
                                           continuous_half=forced[field][0],carried_predicted=native[field][0],carried_half=half[field][0],
                                           carried_observed=target[0]))
    task.table("window-scores.csv",rows);task.table("window-centre.csv",traces)

if __name__=="__main__":
    if sys.argv[1:]==["grade"]:window_scores()
    else:
        flag=int(sys.argv[1])
        for variant,sub in (("memory",1),("memory",2),("forced",2)):product(flag,variant,sub)

