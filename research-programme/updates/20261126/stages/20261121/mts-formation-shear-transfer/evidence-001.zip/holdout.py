from library import solver as task
import sys
FILES=("NEGATIVE-PREDICTION.md","null_channel.py","campaign.py","score.py","design.json")
def pin():
    spec={name:task.lab.sha(task.HERE/name) for name in FILES}
    path=task.HERE/"holdout-pin.json"
    if not path.exists():
        assert not list(task.HERE.glob("g640-s-1-off*-t*.json"))
    task.send(path.name,spec)
def check():
    pin()
    rows=[r for r in task.read(task.HERE/"g640-s-1-null-channel.csv") if r["region"]=="first" and int(r["tick"])==1024]
    assert len(rows)==4
    for r in rows:
        measured=float(r["observed_first"]);predicted=float(r["predicted_first"])
        r["pass_relative_2e5"]=abs(measured-predicted)<=2e-5*abs(measured) if measured else ""
    task.table("negative-origin-prediction.csv",rows)
    print([(r["flag"],r["field"],r["relative_error"],r["pass_relative_2e5"]) for r in rows])
if __name__=="__main__":
    if sys.argv[1:]==["pin"]:pin()
    else:check()

