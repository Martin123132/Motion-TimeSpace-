"""Continuous angular shear flux from the sealed formation launch, unchanged physics."""
from pathlib import Path
import os
import csv
import io
import json
import sys
from contextlib import contextmanager
from time import perf_counter

for key in ("OPENBLAS_NUM_THREADS","OMP_NUM_THREADS","MKL_NUM_THREADS","NUMEXPR_NUM_THREADS","BLIS_NUM_THREADS"):
    os.environ[key]="1"
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
PRIOR=HERE.parent/"mts-curved-angular-tangent-20261121"
FORM=HERE.parent/"mts-formation-origin-source-20261121"
sys.path.insert(0,str(PRIOR))
import weighted_transfer as transfer
from curved_tangent import lab,old,patch,carrier,candidate,evolve8,revised,compute,np
from independent_geometry import measurement
from coupling_scores import readout,mixed,angular,geometric

PREP="f00c8b1a01a205ddadd650d6c225fb3ef1a2627d67934f2ec4b6688bb16d39f2"
PULSE="8290df0028b9c7feeedb89b30e49c959f0d63c55460e9f24da03842c2ff397c3"
TICKS=(0,128,256,384,512,640,768,896,960,1024)
CLOCKS=(256,512,768,1024)
RUNS=((640,1),(640,-1),(320,1))

def guard():
    transfer.guard()
    if (HERE/"STOP-REQUESTED").exists(): raise RuntimeError("Owner hold")

def put(name,data):
    guard()
    lab.put(HERE/name,data)

def send(name,obj):
    put(name,(json.dumps(obj,indent=2,allow_nan=False)+"\n").encode())

def packet(name,fields):
    assert all(np.isfinite(value).all() for value in fields.values())
    stream=io.BytesIO()
    np.savez_compressed(stream,**fields)
    put(name,stream.getvalue())

def table(name,rows):
    stream=io.StringIO(newline="")
    writer=csv.DictWriter(stream,rows[0].keys(),lineterminator="\n")
    writer.writeheader()
    writer.writerows(rows)
    put(name,stream.getvalue().encode())

def read(name):
    with Path(name).open(newline="") as stream:return list(csv.DictReader(stream))

def meta(path):
    return json.loads(path.read_bytes())

def freeze():
    guard()
    for folder,sha in ((FORM,PREP),(PRIOR,PULSE)):
        assert lab.sha(folder/"seal.json")==sha
        for name,digest in meta(folder/"seal.json")["files"].items(): assert lab.sha(folder/name)==digest,name
    send("design.json",dict(solver=lab.sha(Path(__file__)),formation=PREP,operator=PULSE,
        grids_and_signs=RUNS,ticks=TICKS,paired_flags=[0,1],dt="4096pi/(1024 mu); unchanged",
        differs="Only the derivative pair in r^-6 D_b[r_f^6 D_f L] for the angular metric increment; same saved derivatives and launch, surrounding bank, readouts and nonangular state.",
        gates="Do not reject or skip the centre. Both signs/fine and positive/coarse against independent matched Newton+TT at 20 ppm; diagnose independent and native first, core, bulk momentum against the material current and raw Hamiltonian; sample two weak radii with midpoint and 8/16 quadrature. Compare every archived control, and late switch when available. No pointwise tolerance inferred from the tidal band."))
    print("frozen",lab.sha(HERE/"design.json"),flush=True)

def lock():
    guard()
    spec=meta(HERE/"design.json")
    assert spec["solver"]==lab.sha(Path(__file__)) and lab.sha(FORM/"seal.json")==PREP and lab.sha(PRIOR/"seal.json")==PULSE
    return lab.sha(HERE/"design.json")

def tag(grid,seed,flag,tick):
    return f"g{grid}-s{seed}-off{flag}-t{tick}"

def original(grid,seed,flag,tick):
    key=f"quarter-g{grid}-s{seed}-off{flag}" if tick==256 else f"extended-g{grid}-s{seed}-off{flag}-t{tick}"
    name=FORM/(key+".npz")
    cert=meta(name.with_suffix(".json"))
    assert cert["sha"]==lab.sha(name)==meta(FORM/"seal.json")["files"][name.name]
    return name

@contextmanager
def system(grid,seed,flag):
    with old.environment(grid),patch.object(carrier,"launch",candidate),patch.object(evolve8,"revise",revised):
        yield (old.Cold if flag else old.Wave)(seed,"adm")

@contextmanager
def flux(model,grid):
    with patch.object(transfer,"GRID",grid),transfer.weighted(model):yield

def evaluate(model,state,clock):
    result=compute(model,state,clock)
    fields={k:result[k] for k in ("H","ind_H","P","ind_P","J","ind_J")}
    fields["alt_H"]=result["ind_H"]+measurement(model,state,clock)
    tide=lab.read_tide(model,clock,lab.rawfield(model,state,clock))
    mapped,aux=model.mass.decode(state)
    _,_,back,_=model.lift.physical(mapped,clock)
    metric,curvature=geometric(model,mapped,aux,clock)
    rad=model.shell.r
    square=rad**2
    mass=np.expm1(2*(back["ell"]-back["bend"]))/square
    shear=(aux["kb"]-aux["ka"])/square
    mix=mixed(metric,curvature,square,mass,-aux["kb"],shear)
    cov=angular(metric,mix,square,mass,(back["eg"]-back["bg"])/rad,back["bg"]/(2*rad),shear,0.,0.)
    coeff=[mix[0].delta,mix[1].delta,cov.delta,fields["J"],fields["ind_P"]]
    fields["weak"]=np.array([[list(readout(rad,coeff,edge,True,order).values()) for order in (0,8,16)] for edge in (.025,.3)])
    fields["tide"]=np.array([[tide[width,name] for name in ("ricci","gauss")] for width in (.15,.3)])
    return fields

def march(grid,seed,flag):
    seal=lock()
    assert (grid,seed) in RUNS and flag in (0,1)
    with system(grid,seed,flag) as model,flux(model,grid):
        step=4096*np.pi/(1024*model.shell.mu)
        advance=model.time_step(step)
        existing=[]
        for tick in TICKS:
            name=tag(grid,seed,flag,tick)
            marker=HERE/(name+".json")
            raw=HERE/(name+".npz")
            if not marker.exists():
                assert not raw.exists(),f"Orphaned state: {raw}"
                continue
            info=meta(marker)
            assert info["tick"]==tick and info["design"]==seal and info["sha"]==lab.sha(raw)
            existing.append(tick)
        assert existing==list(TICKS[:len(existing)])
        if existing and existing[-1]==1024:return
        if existing:
            begin=existing[-1]
            with np.load(HERE/(tag(grid,seed,flag,begin)+".npz")) as saved:
                assert saved["clock"]==begin*step
                state=old.Difference(saved["shared"],saved["signed"])
        else:
            begin=-1
            zeros=np.zeros_like(model.shell.initial)
            state=old.Difference(zeros.copy(),zeros.copy()) if isinstance(zeros,np.ndarray) else zeros
        start=perf_counter()
        for tick in range(begin+1,1025):
            if tick%8==0:guard()
            if tick:state=advance((tick-1)*step,state)
            if tick not in TICKS:continue
            clock=tick*step
            name=tag(grid,seed,flag,tick)
            result=evaluate(model,state,clock)
            if tick in CLOCKS:
                with np.load(original(grid,seed,flag,tick)) as native:
                    assert native["clock"]==clock
                    for row,key in ((state.base,"shared"),(state.delta,"signed")):
                        np.testing.assert_array_equal(row[:,0],native[key][:,0])
            assert model.mass.min_branch>0
            if not flag and tick:assert model.min_number>0 and model.min_factor>0
            packet(name+".npz",dict(shared=state.base,signed=state.delta,r=model.shell.r,clock=clock,**result))
            send(name+".json",dict(tick=tick,design=seal,sha=lab.sha(HERE/(name+".npz")),grid=grid,sign=seed,cold=flag))
            print(name,round(perf_counter()-start,1),flush=True)

if __name__=="__main__":
    if sys.argv[1:]==["freeze"]:freeze()
    else:march(*map(int,sys.argv[1:]))

