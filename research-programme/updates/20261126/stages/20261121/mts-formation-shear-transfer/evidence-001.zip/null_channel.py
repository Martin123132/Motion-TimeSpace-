"""Predict the cross-run constraint difference from radial metric and shear alone."""
from library import solver as task
from spatial_budget import curvature
from continuum_metric import legacy
from fractions import Fraction as Rat
import sys
np=task.np

def control():
    rows=[]
    for power in range(0,17,2):
        first=lambda n:Rat(n)
        beta=-Rat(1,2);tilt=1+first(power)/3
        tensor=(first(power)/2+Rat(3,2))*tilt-Rat(1,2)
        ham=-4*power*(power-1)*beta+power*(4-12*beta-12*tilt)+16+8*beta-24*tilt+12*tensor
        independent=power*tilt
        face=power*tilt
        assert not ham and not (independent-face)
        rows.append(dict(power=power,flat_H=str(ham),flat_P=str((face-independent)/2)))
    task.table("analytic-null.csv",rows)

def study(grid,seed):
    task.lock();control()
    states=[];terms=[];profiles={}
    for flag in (0,1):
        with task.system(grid,seed,flag) as model:
            mesh=model.lift.mesh;sh=model.shell;radius=mesh.r;weights=sh.weights;av=sh.average
            def observe(metric,velocity):
                zero=np.zeros_like(metric)
                ell,bend,face,tensor=mesh.decode((metric,zero,zero,zero))
                H=curvature(grid,np.array([ell,bend,mesh.centre(face),tensor]),radius,weights,av)
                face=mesh.decode((velocity,zero,zero,zero))[2]
                P=-radius*(legacy(mesh.centre(face),sh.dx,weights,av)[0]-mesh.even_back(face))/2
                return H,P
            for tick in task.CLOCKS:
                name=task.tag(grid,seed,flag,tick)
                assert task.meta(task.HERE/(name+".json"))["sha"]==task.lab.sha(task.HERE/(name+".npz"))
                with np.load(task.HERE/(name+".npz")) as new,np.load(task.original(grid,seed,flag,tick)) as old:
                    raw=task.old.Difference(old["shared"],old["signed"]);time=float(old["clock"])
                    previous=task.compute(model,raw,time)
                    change=new["signed"][:,1].real-old["signed"][:,1].real
                    pred=observe(change[0],-change[5])
                    for field,output in zip(("ind_H","ind_P"),pred):
                        actual=new[field]-previous[field]
                        for what,values in (("pred",output),("meas",actual)):
                            profiles[f"f{flag}t{tick}_{field}_{what}"]=values
                        for reg,mask in (("first",radius<1/grid),("first8",radius<8/grid),("core",radius<.3),("bulk",(radius>.6)&(radius<2.1))):
                            n=np.linalg.norm
                            err=n((output-actual)[mask]);den=n(actual[mask])
                            states.append(dict(flag=flag,tick=tick,field=field,region=reg,observed_first=actual[mask][0],
                                              predicted_first=output[mask][0],signal_norm=den,error_norm=err,
                                              relative_error=err/den if den else ""))
                    for field,arr in (("ell",change[0]),("minus_shear",-change[5])):
                        zero=np.zeros_like(arr)
                        l,b,face,d=mesh.decode((arr,zero,zero,zero));v=mesh.centre(face)
                        if field=="ell":
                            slope,second=legacy(np.stack((l,b,v,d)),sh.dx,weights,av)
                            parts=(-4*second[1],(4*slope[0]-12*slope[1]-12*slope[2])/radius,(16*l+8*b-24*v+12*d)/radius**2)
                        else:parts=(-radius*legacy(v,sh.dx,weights,av)[0]/2,radius*mesh.even_back(face)/2)
                        terms.append(dict(flag=flag,tick=tick,field=field,first_part=parts[0][0],second_part=parts[1][0],
                                          third_part=parts[2][0] if len(parts)>2 else 0.,sum=sum(a[0] for a in parts)))
    task.table(f"g{grid}-s{seed}-null-channel.csv",states)
    task.table(f"g{grid}-s{seed}-null-terms.csv",terms)
    task.packet(f"g{grid}-s{seed}-null-profiles.npz",profiles)
    print("central signed response",grid,seed,[(r["field"],r["flag"],r["relative_error"]) for r in states if r["tick"]==1024 and r["region"]=="first"],flush=True)
if __name__=="__main__":study(*map(int,sys.argv[1:]))

