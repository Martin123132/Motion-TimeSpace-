import math
from library import solver as task

np=task.np
def validate():
    pin=task.lock()
    assert task.meta(task.HERE/"holdout-pin.json")=={name:task.lab.sha(task.HERE/name) for name in ("NEGATIVE-PREDICTION.md","null_channel.py","campaign.py","score.py","design.json")}
    inputs=task.meta(task.FORM/"seal.json")["files"]
    for parent,expected in ((task.FORM,task.PREP),(task.PRIOR,task.PULSE)):
        assert task.lab.sha(parent/"seal.json")==expected
        for file,sha in task.meta(parent/"seal.json")["files"].items():assert task.lab.sha(parent/file)==sha,file
    actual={}
    counts={}
    def table(name,count):
        rows=task.read(task.HERE/name)
        assert len(rows)==count and all(None not in r and None not in r.values() for r in rows),name
        counts[name]=count
        return rows
    forecasts={(int(row["seed"]),float(row["width"]),float(row["fraction"])):row for row in task.read(task.FORM/"matched-gravity-prediction.csv")}
    for grid,seed in task.RUNS:
        for flag in (0,1):
            clocks=[]
            for tick in task.TICKS:
                name=task.tag(grid,seed,flag,tick)
                cert=task.meta(task.HERE/(name+".json"))
                assert cert["design"]==pin and cert["sha"]==task.lab.sha(task.HERE/(name+".npz"))
                assert (cert["grid"],cert["sign"],cert["cold"],cert["tick"])==(grid,seed,flag,tick)
                with np.load(task.HERE/(name+".npz")) as state:
                    assert all(np.isfinite(state[k]).all() for k in state.files)
                    clocks.append(float(state["clock"]))
                    assert len(state["r"])==3*grid and state["weak"].shape==(2,3,3)
                    if tick==0:assert not np.any(state["shared"]) and not np.any(state["signed"])
                    if tick in task.CLOCKS:
                        with np.load(task.original(grid,seed,flag,tick)) as base:
                            for k in ("shared","signed"):np.testing.assert_array_equal(state[k][:,0],base[k][:,0])
                        actual[grid,seed,flag,tick]=state["tide"]
            np.testing.assert_allclose(clocks,np.array(task.TICKS)*clocks[-1]/1024,atol=1e-16)
        prefix=f"g{grid}-s{seed}-"
        bands=table(prefix+"bands.csv",16)
        for r in bands:
            tick=int(r["tick"]);width=float(r["width"]);i=(.15,.3).index(width);j=("ricci","gauss").index(r["channel"])
            observed=actual[grid,seed,0,tick][i,j]-actual[grid,seed,1,tick][i,j]
            ref=forecasts[seed,width,tick/1024];error=(observed-float(ref["matched"]))/(abs(float(ref["matched_newton"]))*1e-6)
            assert observed==float(r["new"]) and math.isclose(error,float(r["residual_ppm"]),rel_tol=1e-12)
            assert (r["inside"]=="True")==(abs(error)<=20)
        for suffix,count in (("regions",168),("weak",144),("origin-source",32),("rate-test",96),("summation",64),
                             ("null-channel",64),("null-terms",16),("weak-H",96),("radial-wave",320),("curved-TT",24)):
            rows=table(prefix+suffix+".csv",count)
            if suffix=="summation":assert max(float(r["relative_closure"]) for r in rows)<1e-10
            if suffix=="curved-TT":
                assert all(float(r["trial_TT_scalar_norm"])<=float(r["conditional_bound"])*(1+1e-12) for r in rows)
        for r in table(prefix+"null-channel.csv",64):
            with np.load(task.HERE/(prefix+"null-profiles.npz")) as data:
                key="f"+r["flag"]+"t"+r["tick"]+"_"+r["field"]
                if r["region"]=="first":
                    obs,pred=data[key+"_meas"][0],data[key+"_pred"][0]
                    assert (obs,pred)==(float(r["observed_first"]),float(r["predicted_first"]))
        slots=task.read(task.HERE/(prefix+"slots.csv"));assert len(slots)>200
        counts[prefix+"slots.csv"]=len(slots)
    for variant,sub in (("memory",1),("memory",2),("forced",2)):
        for flag in (0,1):
            for tick in (960,1024):
                with np.load(task.HERE/f"window-f{flag}-{variant}-d{sub}-t{tick}.npz") as bank:
                    assert all(np.isfinite(bank[k]).all() for k in bank.files)
    for name,count in (("window-scores",96),("window-centre",24),("analytic-null",9),("curved-slice-tests",12),
                       ("cartesian-tensor-tests",24),("weak-H-controls",18),("negative-origin-prediction",4),
                       ("exact-weight-laws",2),("exact-origin-weights",20)):
        data=table(name+".csv",count)
        if name=="negative-origin-prediction":
            for row in data:assert (row["pass_relative_2e5"]=="True")==(float(row["relative_error"])<=2e-5)
    assert set(counts)=={p.name for p in task.HERE.glob("*.csv")}
    files={p.name:task.lab.sha(p) for p in sorted(task.HERE.iterdir()) if p.is_file() and p.name!="seal.json"}
    task.send("seal.json",dict(design=pin,parents=[task.PREP,task.PULSE],continuous_trajectories=6,full_state_packets=60,
                               short_evolutions=6,short_packets=12,rows=counts,files=files))
    print(len(files),"files,",sum(counts.values()),"data rows, seal",task.lab.sha(task.HERE/"seal.json"))

if __name__=="__main__":validate()

