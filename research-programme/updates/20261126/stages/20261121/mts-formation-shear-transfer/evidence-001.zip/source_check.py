"""Measure the signed forcing from the operator switch, not a post-hoc curvature fit."""
from library import solver as task
from stencil import exact_action
import sys

np=task.np
def study(grid,seed):
    task.lock()
    rows=[];slots=[];work=[]
    for flag in (0,1):
        with task.system(grid,seed,flag) as model:
            mesh=model.lift.mesh;improved=task.transfer.mesh_at(grid,20,3.)
            for tick in task.CLOCKS:
                name=task.tag(grid,seed,flag,tick)
                assert task.meta(task.HERE/(name+".json"))["sha"]==task.lab.sha(task.HERE/(name+".npz"))
                for kind,path in (("original",task.original(grid,seed,flag,tick)),("continuous",task.HERE/(name+".npz"))):
                    with np.load(path) as bank:
                        state=task.old.Difference(bank["shared"],bank["signed"]);clock=float(bank["clock"])
                    mapped,aux=model.mass.decode(state)
                    _,_,bg,_=model.lift.physical(mapped,clock)
                    ell=mapped[0,1].real
                    diff=improved.lap(ell,6)-mesh.lap(ell,6)
                    expected=-bg["ne"]*diff
                    rhs=model.rhs if flag else model.nonlinear
                    oldrate=rhs(clock,state)
                    with task.flux(model,grid):newrate=rhs(clock,state)
                    for label in ("base","delta"):
                        raw=getattr(ell,label);full=getattr(state,label)
                        measured=getattr(newrate,label)-getattr(oldrate,label)
                        direct=getattr(expected,label)
                        masked=measured.copy();masked[5,1]=0
                        assert not np.any(masked),(label,flag,tick)
                        predicted,low,rest,total,scale=exact_action(raw,grid)
                        numeric=getattr(diff,label)[0]
                        spacing=np.spacing(np.abs(raw[:20]))
                        from stencil import split
                        floor=float(sum(abs(float(c))*step for c,step in zip(split()[0],spacing))*grid**2/2)
                        measured_first=float(measured[5,1,0].real)
                        rows.append(dict(flag=flag,tick=tick,state=kind,part=label,exact_difference=predicted,
                                         direct_float=numeric,direct_absolute_error=abs(predicted-numeric),
                                         level4=low,levels5plus=rest,absolute_level_sum=total,
                                         absolute_weighted_sum=scale,half_ulp_sample_bound=floor,
                                         shear_rate_prediction=direct[0],shear_rate_measured=measured_first,
                                         rate_absolute_error=abs(measured_first-direct[0])))
                        for reg,mask in (("first",mesh.r<1/grid),("core",mesh.r<.3),("bulk",(mesh.r>.6)&(mesh.r<2.1))):
                            norm=np.linalg.norm;target=direct[mask];error=measured[5,1,mask]-target
                            slots.append(dict(flag=flag,tick=tick,state=kind,part=label,region=reg,
                                              measured_norm=norm(measured[5,1,mask]),predicted_norm=norm(target),
                                              absolute_discrepancy=norm(error),relative_discrepancy=norm(error)/norm(target) if norm(target) else ""))
                        for order,op in ((12,mesh),(20,improved)):
                            face=op.grad(raw);lhs=float(np.dot(raw*op.mass6,op.lap(raw,6))*op.h)
                            rhsnorm=float(np.dot(op.faces**6,face**2)*op.h)
                            assert rhsnorm>=0
                            work.append(dict(flag=flag,tick=tick,state=kind,part=label,order=order,
                                             cell_work=lhs,face_energy=rhsnorm,relative_closure=abs(lhs+rhsnorm)/rhsnorm if rhsnorm else 0.))
    task.table(f"g{grid}-s{seed}-origin-source.csv",rows)
    task.table(f"g{grid}-s{seed}-rate-test.csv",slots)
    task.table(f"g{grid}-s{seed}-summation.csv",work)
    print("rate identity",grid,seed,"worst direct difference",max(v["relative_discrepancy"] or 0 for v in slots),
          "summation",max(v["relative_closure"] for v in work),flush=True)

if __name__=="__main__":study(*map(int,sys.argv[1:]))

