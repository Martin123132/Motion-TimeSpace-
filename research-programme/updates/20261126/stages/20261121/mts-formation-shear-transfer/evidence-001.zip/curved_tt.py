"""Independent metric-jet Ricci variation for curved spherical spatial slices."""
from library import solver as task
import sympy as sp

def tests():
    rad,mu=sp.symbols("r u");phi=sp.Symbol("p")
    axes=(rad,mu,phi);sphere=1-mu**2;harm=(3*mu**2-1)/2
    out=[]
    for label,area in (("flat",rad),("curved",rad+rad**3/13+rad**5/37)):
        f=1-rad**2/3+rad**4/7
        v=area*f.diff(rad)/3+area.diff(rad)*f
        d=area*v.diff(rad)/2+3*area.diff(rad)*v/2-f/2
        metric=sp.diag(1,area**2/sphere,area**2*sphere)
        shift=sp.zeros(3)
        shift[0,0]=2*f*harm
        shift[0,1]=shift[1,0]=area*v*harm.diff(mu)
        shift[1,1]=area**2*(-f*harm/sphere+d*(harm.diff(mu,2)-mu*harm.diff(mu)/sphere+3*harm/sphere))
        shift[2,2]=area**2*(-f*harm*sphere+d*(-mu*sphere*harm.diff(mu)+3*harm*sphere))
        for kind,h in (("TT",shift),("conformal",2*(1+rad**2)*metric)):
            jets={}
            for key,tensor in (("g",metric),("h",h)):
                jets[key]=tensor
                for j,c in enumerate(axes):
                    jets[key,j]=tensor.diff(c)
                    for k,e in enumerate(axes):jets[key,j,k]=jets[key,j].diff(e)
            for radial,angle in ((sp.Rational(1,4),sp.Rational(1,3)),(sp.Rational(2,3),sp.Rational(-2,5)),(1,sp.Rational(3,4))):
                subs={rad:radial,mu:angle}
                values={k:a.subs(subs) for k,a in jets.items()}
                g,hval=values["g"],values["h"]
                gi=g.inv();hi=-gi*hval*gi
                def combo(key,i,j,l,*rest):
                    return (values[(key,i,*rest)][l,j]+values[(key,j,*rest)][l,i]-values[(key,l,*rest)][i,j])/2
                inds=range(3)
                G={};H={};dG={};dH={}
                for i in inds:
                    for j in inds:
                        vec=sp.Matrix([combo("g",i,j,l) for l in inds]);dv=sp.Matrix([combo("h",i,j,l) for l in inds])
                        G[i,j]=gi*vec;H[i,j]=hi*vec+gi*dv
                        for k in inds:
                            dgi=-gi*values["g",k]*gi
                            dhi=-dgi*hval*gi-gi*values["h",k]*gi-gi*hval*dgi
                            vprime=sp.Matrix([combo("g",i,j,l,k) for l in inds])
                            dvprime=sp.Matrix([combo("h",i,j,l,k) for l in inds])
                            dG[i,j,k]=dgi*vec+gi*vprime
                            dH[i,j,k]=dhi*vec+hi*vprime+dgi*dv+gi*dvprime
                Ric=sp.zeros(3);variation=sp.zeros(3)
                for i in inds:
                    for j in inds:
                        Ric[i,j]=sum(dG[i,j,k][k]-dG[i,k,j][k] for k in inds)
                        variation[i,j]=sum(dH[i,j,k][k]-dH[i,k,j][k] for k in inds)
                        for k in inds:
                            for l in inds:
                                Ric[i,j]+=G[i,j][l]*G[k,l][k]-G[i,k][l]*G[j,l][k]
                                variation[i,j]+=H[i,j][l]*G[k,l][k]+G[i,j][l]*H[k,l][k]-H[i,k][l]*G[j,l][k]-G[i,k][l]*H[j,l][k]
                measured=sp.trace(hi*Ric+gi*variation)
                if kind=="TT":
                    expected=(2*f*((1-area.diff(rad)**2)/area**2+area.diff(rad,2)/area)*harm).subs(subs)
                    for j in inds:
                        div=sum(gi[i,k]*(values["h",i][k,j]-sum(G[i,k][l]*hval[l,j]+G[i,j][l]*hval[k,l] for l in inds)) for k in inds for i in inds)
                        assert div==0
                    assert sp.trace(gi*hval)==0
                else:
                    potential=1+rad**2
                    lap=(potential.diff(rad,2)+2*area.diff(rad)/area*potential.diff(rad)).subs(subs)
                    expected=-2*potential.subs(subs)*sp.trace(gi*Ric)-4*lap
                assert measured==expected
                out.append(dict(background=label,field=kind,r=str(radial),mu=str(angle),direct_R_variation=str(measured),
                                predicted_R_variation=str(expected),numeric=float(measured),exact_difference=0))
    task.table("curved-slice-tests.csv",out)
    print(len(out),"independent curvature variations")
if __name__=="__main__":tests()

