"""Avoid a name collision with a separately retained historical solver called campaign."""
from importlib.util import module_from_spec, spec_from_file_location
from pathlib import Path
spec=spec_from_file_location("formation_shear_solver",Path(__file__).with_name("campaign.py"))
solver=module_from_spec(spec)
spec.loader.exec_module(solver)

