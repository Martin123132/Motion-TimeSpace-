from library import solver as task
import sys
np=task.np

def study(grid,seed):
    task.lock()
    rows=[]
    for flag in (0,1):
        with task.system(grid,seed,flag) as model:
            low=model.lift.mesh;high=task.transfer.mesh_at(grid,20,3.)
            rhs=model.rhs if flag else model.nonlinear
            for tick in task.CLOCKS:
                key=task.tag(grid,seed,flag,tick)
                assert task.meta(task.HERE/(key+".json"))["sha"]==task.lab.sha(task.HERE/(key+".npz"))
                with np.load(task.HERE/(key+".npz")) as new,np.load(task.original(grid,seed,flag,tick)) as original:
                    old=task.old.Difference(original["shared"],original["signed"])
                    revised=task.old.Difference(new["shared"],new["signed"])
                    clock=float(new["clock"])
                    before=rhs(clock,old)
                    with task.flux(model,grid):after=rhs(clock,revised)
                    change=task.old.Difference(revised.base-old.base,revised.delta-old.delta)
                    rate=task.old.Difference(after.base-before.base,after.delta-before.delta)
                    observed=-rate[4,1].real/3-rate[5,1].real
                    velocity=-change[4,1].real/3-change[5,1].real
                    np.testing.assert_allclose(rate[0,1].delta.real,velocity.delta,atol=1e-29,rtol=1e-5)
                    mapped=model.mass.decode(old)[0]
                    back=model.lift.physical(mapped,clock)[2]["ne"]
                    radial=low.r
                    propagation=back*high.lap(change[0,1].real,6)
                    drive=back*(high.lap(old[0,1].real,6)-low.lap(old[0,1].real,6))
                    cross=back*(2*low.back(low.faces*low.full(change[2,1].real))-low.back(low.grad(radial**2*change[1,1].real)))/low.mass2
                    for tag,term in (("propagation",propagation),("donor",drive),("other_chart",cross),("propagation_plus_donor",propagation+drive),("all_principal",propagation+drive+cross)):
                        for label in ("delta","base"):
                            act=getattr(observed,label);approx=getattr(term,label)
                            for reg,mask in (("first",radial<1/grid),("first8",radial<8/grid),("core",radial<.3),("bulk",(radial>.6)&(radial<2.1))):
                                n=np.linalg.norm
                                den=n(act[mask])
                                rows.append(dict(flag=flag,tick=tick,region=reg,term=tag,part=label,measured_first=act[mask][0],
                                                 predicted_first=approx[mask][0],measured_norm=den,term_norm=n(approx[mask]),
                                                 difference_norm=n((approx-act)[mask]),relative_error=n((approx-act)[mask])/den if den else ""))
    task.table(f"g{grid}-s{seed}-radial-wave.csv",rows)
    print("radial acceleration",grid,seed,[(r["flag"],r["term"],r["relative_error"]) for r in rows if (r["tick"],r["region"],r["part"])==(1024,"first","delta")],flush=True)

if __name__=="__main__":study(*map(int,sys.argv[1:]))

