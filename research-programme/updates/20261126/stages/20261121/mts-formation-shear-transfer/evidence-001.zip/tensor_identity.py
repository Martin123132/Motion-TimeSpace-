"""Exact Cartesian vacuum witness, not a stencil or a constraint projection."""
from pathlib import Path
import sys
import sympy as sp
from library import solver as task

def analytic():
    x,y,z,t=sp.symbols("x y z t",real=True)
    s=sp.Symbol("s")
    coords=(x,y,z);pos=sp.Matrix(coords);square=pos.dot(pos);identity=sp.eye(3)
    quad=sp.Matrix([[2,1,-1],[1,-3,2],[-1,2,1]])
    shape=pos.dot(quad*pos)
    radial=lambda value: 14*sp.diff(value,s)+4*s*sp.diff(value,s,2)
    def evolved(start,vel):
        result=sp.S.Zero
        for shift,part in ((0,start),(1,vel)):
            for level in range(sp.degree(part,s)+1):
                result+=part*t**(2*level+shift)/sp.factorial(2*level+shift)
                part=radial(part)
        return result
    f=evolved(1-2*s+s**2,1+s/3)
    first=sp.diff(f,s);second=sp.diff(f,s,2)
    d=f+sp.Rational(8,3)*s*first+sp.Rational(2,3)*s**2*second
    field=(2*d*quad+(-4*first-sp.Rational(4,3)*s*second)*(pos*(quad*pos).T+(quad*pos)*pos.T)+
           (sp.Rational(8,3)*first+sp.Rational(2,3)*s*second)*shape*identity+sp.Rational(2,3)*second*shape*pos*pos.T)
    field=field.subs(s,square).applyfunc(sp.expand)
    def lap(value):return sum(sp.diff(value,c,2) for c in coords)
    def divergence(tensor):return sp.Matrix([sum(sp.diff(tensor[i,j],coords[j]) for j in range(3)) for i in range(3)])
    def scalar(tensor):
        div=divergence(tensor)
        return sum(sp.diff(div[i],coords[i]) for i in range(3))-lap(sp.trace(tensor))
    def momentum(tensor):return divergence(tensor-identity*sp.trace(tensor))
    checks=[]
    def zero(name,expression):
        items=list(expression) if isinstance(expression,sp.MatrixBase) else [expression]
        for index,item in enumerate(items):
            assert sp.expand(item)==0,(name,index)
            checks.append(dict(check=name,component=index,exact_residual=0))
    zero("radial wave",sp.diff(f,t,2)-radial(f))
    zero("trace",sp.trace(field));zero("divergence",divergence(field))
    zero("physical Hamiltonian",scalar(field));zero("physical momentum",momentum(-field.diff(t)/2))
    zero("Cartesian vacuum wave",field.applyfunc(lap)-field.diff(t,2))
    zero("radial metric projection",pos.dot(field*pos)-2*f.subs(s,square)*shape)
    zero("radial tidal projection",pos.dot((-field.diff(t,2)/2)*pos)+radial(f).subs(s,square)*shape)
    origin=(-field.diff(t,2)/2).subs({x:0,y:0,z:0,t:0})
    assert origin==28*quad and origin!=sp.zeros(3)
    zero("nonzero trace perturbation",scalar(field+2*square**2*identity)+80*square)
    zero("nonzero momentum perturbation",momentum(-field.diff(t)/2+square*identity)+4*pos)
    task.table("cartesian-tensor-tests.csv",checks)
    task.send("cartesian-tidal-witness.json",dict(test="f(s,0)=1-2s+s^2, f_t(s,0)=1+s/3; local polynomial witness",tidal_at_origin=[[int(v) for v in row] for row in origin.tolist()],checks=len(checks)))
    print(len(checks),"Cartesian identities; E_ij(0) = 28 Q")
if __name__=="__main__":analytic()

