"""Exact origin weights for the continuous shear-transfer experiment."""
from fractions import Fraction as Rat
from math import comb, prod, factorial
from functools import lru_cache
from library import solver as task

def mirror(index):
    return index if index>=0 else -1-index

@lru_cache
def stencil(order):
    distances=[Rat(2*j+1,2) for j in range(order//2)]
    weights=[prod(y*y/(y*y-x*x) for y in distances if y!=x)/(2*x) for x in distances]
    result=[Rat(0)]*order
    for idx,outer in enumerate(weights):
        for face,sgn in ((1+idx,1),(-idx,-1)):
            for inner,c in enumerate(weights):
                coeff=64*sgn*outer*face**6*c
                result[mirror(face+inner)]+=coeff
                result[mirror(face-inner-1)]-=coeff
    return result

def moment(row,power):
    return sum(c*Rat(2*j+1,2)**power for j,c in enumerate(row))

def exact(order):
    row=stencil(order)
    assert sum(row)==0
    for power in range(2,order-5,2):
        assert moment(row,power)==power*(power+5)*Rat(1,2)**(power-2)
    power=order-4
    leading=(moment(row,power)-power*(power+5)*Rat(1,2)**(power-2))/factorial(power)
    assert leading
    return dict(order=order,first_missed_even_power=power,leading_derivative=str(leading),
                leading_h_power=power-2,absolute_weight_sum=float(sum(map(abs,row))),
                bound_per_unit_sample_error_at_640=float(sum(map(abs,row)))*640**2)

@lru_cache
def split():
    coeff=[right-left for right,left in zip(stencil(20),stencil(12)+[Rat(0)]*8)]
    diff=[]
    for level in range(20):
        row=[0]*20
        for j in range(-level,level+1):
            row[mirror(j)]+=(-1)**(level+j)*comb(2*level,level+j)
        diff.append(row)
    rest=coeff.copy()
    series=[Rat(0)]*20
    for level in reversed(range(20)):
        series[level]=rest[level]
        rest=[a-series[level]*b for a,b in zip(rest,diff[level])]
    assert not any(rest) and not any(series[:4]) and series[4]
    return coeff,[[s*w for w in row] for s,row in zip(series,diff)]

def exact_action(samples,grid):
    coeff,blocks=split()
    vals=[Rat.from_float(float(x))*grid**2 for x in samples[:20]]
    terms=[sum(a*b for a,b in zip(row,vals)) for row in blocks]
    net=sum(a*b for a,b in zip(coeff,vals))
    assert net==sum(terms)
    return tuple(map(float,(net,terms[4],sum(terms[5:]),sum(abs(x) for x in terms),sum(abs(a*b) for a,b in zip(coeff,vals)))))

def run():
    task.table("exact-weight-laws.csv",[exact(order) for order in (12,20)])
    coeff,series=split()
    rows=[dict(cell=idx,old=str(old),new=str(new),difference=str(new-old)) for idx,(old,new) in
          enumerate(zip(stencil(12)+[Rat(0)]*8,stencil(20)))]
    task.table("exact-origin-weights.csv",rows)
    for degree in range(0,16,2):
        vals=[(j+.5)**degree for j in range(20)]
        observed=exact_action(vals,1)[0]
        expected=float(moment(coeff,degree))
        assert abs(observed-expected)<=1e-6*max(1,abs(expected))
    print("origin",exact(12),exact(20),flush=True)

if __name__=="__main__":run()

