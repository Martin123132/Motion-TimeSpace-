"""Past-cone shell readout for the real scalar, including its derivative null stress."""
import numpy as np
from numpy.polynomial.legendre import legvander
from scipy.special import eval_legendre, roots_legendre, spherical_jn
from prepare import OpticalMesh, guard, local_state


def integration(mesh, impact, count, splits, wave):
    depth = np.array([20.,35.,50.])/mesh.op["length"]
    joins = np.sqrt(np.maximum(0.,mesh.edge**2-impact**2))
    edges = np.unique(np.clip(np.r_[joins,depth],depth[0],depth[-1]))
    edges = np.r_[((edges[:-1,None]+np.diff(edges)[:,None]*np.arange(splits)/splits).ravel()),edges[-1]]
    center = (edges[1:]+edges[:-1])/2
    half = np.diff(edges)/2
    points, weights = roots_legendre(count)
    position = center[:,None]+half[:,None]*points
    tent = position*np.minimum(position-depth[0],depth[2]-position)/(depth[1]-depth[0])
    degrees = np.arange(count)
    moments = (np.exp(1j*wave*center)*half)[:,None]*spherical_jn(degrees,wave*half[:,None])*(1j**degrees)*(2*degrees+1)
    fast = (moments@legvander(points,count-1).T)*weights
    slow = half[:,None]*weights
    exact = -(depth[0]*np.exp(1j*wave*depth[0])-2*depth[1]*np.exp(1j*wave*depth[1])+depth[2]*np.exp(1j*wave*depth[2]))/((depth[1]-depth[0])*wave**2)
    exact += -2j*(np.exp(1j*wave*depth[0])-2*np.exp(1j*wave*depth[1])+np.exp(1j*wave*depth[2]))/((depth[1]-depth[0])*wave**3)
    numeric = np.sum(fast*tent)
    assert abs(numeric-exact)<2e-11*max(abs(exact),1e-3),(numeric,exact)
    return position.ravel(),(slow*tent).ravel(),(fast*tent).ravel()


def maps(mesh, impact, height):
    op = mesh.op
    radii = np.hypot(impact,height)
    mu = height/radii
    elem = np.searchsorted(mesh.edge,radii)-1
    half = np.diff(mesh.edge)[elem]/2
    coords = (radii-mesh.edge[elem])/half-1
    local = legvander(coords,7)@mesh.interp
    radial = (legvander(coords,6)@mesh.derivative)/half[:,None]
    knots = elem[:,None]*7+np.arange(8)
    angular = eval_legendre(mesh.orders,mu[:,None])*mesh.scale
    tang = mesh.orders*(eval_legendre(np.maximum(0,mesh.orders-1),mu[:,None])*mesh.scale-mu[:,None]*angular)
    val = local[:,:,None]*angular[:,None,:]/radii[:,None,None]
    der = (radial*mu[:,None])[:,:,None]*angular[:,None,:]/radii[:,None,None]
    der += local[:,:,None]*(tang-mu[:,None]*angular)[:,None,:]/radii[:,None,None]**2
    ground = [np.einsum("pal,pal->p",item,mesh.ground[knots])[:,None] for item in (val,der)]
    fields = []
    for item in (val,der):
        pieces = []
        for degree,block in enumerate(op["block"]):
            nodal = np.pad(block/np.sqrt(op["weight"][:,None]),((1,1),(0,0)))
            pieces.append(np.einsum("pa,pak->pk",item[:,:,degree],nodal[knots]))
        flat = np.concatenate(pieces,axis=1)
        fields.append((flat@op["u"],flat@op["momentum"]))
    return *ground,*fields


EPOCHS=np.array([-21.,-15.75,-10.5,-5.25,0.])

def compute(prep,order,split):
    mesh=OpticalMesh(prep["op"])
    eps=prep["eps"]
    nu=1+eps**2*prep["energy"]
    impact=8.3/prep["op"]["length"]
    heights,slow,fast=integration(mesh,impact,order,split,2*nu/eps)
    values=np.zeros((len(EPOCHS),6,5),complex)
    for start in range(0,len(heights),32):
        guard()
        part=slice(start,start+32)
        height=heights[part]
        ground,gradient,element,gradient_element=maps(mesh,impact,height)
        base=1j*nu*ground+eps*gradient
        def dot(row,field):
            return np.einsum("nm,nmh->nh",row,field)
        for idx,epoch in enumerate(EPOCHS):
            pos,vel,accel,phase,rate=local_state(prep,epoch*prep["year"]-eps*height)
            env=dot(element[0],pos)+1j*dot(element[1],vel)
            spatial=dot(gradient_element[0],pos)+1j*dot(gradient_element[1],vel)
            temporal=dot(element[0],vel)+1j*dot(element[1],accel)
            raw=1j*nu*env+eps*spatial-eps**2*temporal
            driven=raw+1j*phase*base-1j*eps**2*rate*ground
            linear=2*base*driven
            phase_exact=np.exp(2j*phase)*(base**2+2*base*(raw-1j*eps**2*rate*ground))-base**2
            values[idx,:,0]+=eps**2*fast[part]@linear
            values[idx,:,1]+=eps**2*slow[part]@(2*np.real(base.conj()*driven))
            values[idx,:,2]+=eps**2*fast[part]@(base**2)
            values[idx,:,3]+=eps**2*fast[part]@phase_exact
            values[idx,:,4]+=eps**2*fast[part]@(2*base*raw)
    return values

