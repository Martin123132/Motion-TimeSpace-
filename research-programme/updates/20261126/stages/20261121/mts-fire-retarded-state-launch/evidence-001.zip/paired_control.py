"""Centered finite-amplitude response without subtracting independently rounded waves."""
from mts_retarded_launch_io import *

def check_pairs(steps,save):
    lab=Launch(steps);obj=lab.obj;run=lab.run;count,dt=run.interval(590,600)
    solver=Evolution(obj,dt,lab.initial['reset']);rows=[];errors=[]
    for amplitude in (2**-5,2**-7,2**-9):
        forces={}
        for tag,initial in lab.initial.items():
            even=initial.copy();odd=np.zeros_like(even)
            for tick in range(count):
                check();ext=run.external(590,600,tick,count)
                mean_even=even;mean_odd=odd
                def moments(a,b):
                    return obj.moment(a)+amplitude**2*obj.moment(b),run.sky_cross(obj.sky(a),b)
                start_even,start_odd=moments(even,odd)
                for iteration in range(48):
                    end_even,end_odd=moments(2*mean_even-even,2*mean_odd-odd)
                    potential=ext+obj.phi((start_even+end_even)/2)-solver.pref
                    perturb=lab.smooth+obj.phi((start_odd+end_odd)/2)
                    a=solver.factor.solve(even-.5j*dt*(obj.multiply(potential,mean_even)+amplitude**2*obj.multiply(perturb,mean_odd)))
                    b=solver.factor.solve(odd-.5j*dt*(obj.multiply(potential,mean_odd)+obj.multiply(perturb,mean_even)))
                    error=max(np.linalg.norm(a-mean_even),np.linalg.norm(b-mean_odd))
                    mean_even,mean_odd=a,b
                    if error<2e-14:break
                else:raise ArithmeticError('finite-amplitude centered map')
                even=2*mean_even-even;odd=2*mean_odd-odd
            assert max(abs(inner(even+sign*amplitude*odd,even+sign*amplitude*odd)/obj.number-1) for sign in (-1,1))<1e-8
            forces[tag]=lab.unit*lab.shell(even,odd)
        observed=forces['coupled']-forces['reset'];expected=float(records(HERE/f'paired-{steps}.csv')[0]['smooth_probe_SI'])
        error=abs(observed/expected-1);errors.append(error)
        raw,=[r for r in records(HERE/f'nonlinear-{steps}.csv') if float(r['amplitude'])==amplitude]
        rows.append(dict(steps=steps,amplitude=amplitude,centered_SI=observed,tangent_SI=expected,
                         relative_error=error,raw_relative_error=float(raw['relative_error']),
                         direct_centered_relative_difference=float(raw['nonlinear_SI'])/observed-1))
    assert errors[-1]<2e-5 and errors[-1]<errors[0]/20,errors
    table(HERE/f'centered-{steps}.csv',rows,save)
if __name__=='__main__':
    assert sys.argv[1:2] in (['32'],['64']) and sys.argv[2:] in ([],['--save'])
    check_pairs(int(sys.argv[1]),bool(sys.argv[2:]))
