"""Test the actual ultraviolet reach of the fourth-order dispersion on the retained waves."""
from mts_retarded_launch_io import *
from scipy.linalg import eigh

class Dispersion:
    def __init__(self,lab):
        mesh=lab.mesh;self.kin=mesh.kin;angular=len(lab.obj.bg.orders);self.angular=angular
        self.bases=[];spec=[];self.filters=[]
        for idx in range(angular):
            block=self.kin[idx::angular,idx::angular].toarray()
            energy,vectors=eigh(block,driver='evd')
            assert energy.min()>0
            root=np.sqrt(1+2*mesh.ep*energy)
            ratio=(2*mesh.ep*energy/(1+root))*(root+3)/(1+root)**2
            assert ratio.min()>0 and ratio.max()<1
            self.filters.append(ratio);self.bases.append(vectors);spec.append(energy)
        self.energy=np.array(spec);self.max=mesh.ep*self.energy.max()
        self.ep=mesh.ep
    def correction(self,state):
        blocks=(self.kin@(self.kin@state)).reshape(-1,self.angular).T
        change=np.array([basis@(fact*(basis.T@block)/2) for basis,fact,block in zip(self.bases,self.filters,blocks,strict=True)])
        return change.T.ravel()
    def tail(self,state):
        power=np.array([abs(basis.T@part)**2 for basis,part in zip(self.bases,state.reshape(-1,self.angular).T,strict=True)])
        assert abs(power.sum()/np.vdot(state,state).real-1)<1e-12
        return power[self.ep*self.energy>.01].sum()/power.sum()

def test(steps,save):
    lab=Launch(steps);obj=lab.obj;run=lab.run;disp=Dispersion(lab)
    count,dt=run.interval(590,600);solver=Evolution(obj,dt,lab.initial['reset'])
    diffs={};onset={};tails={};known=float(records(HERE/f'paired-{steps}.csv')[0]['density_state_SI'])
    for tag,initial in lab.initial.items():
        state=initial.copy();tangent=np.zeros_like(initial);tail=disp.tail(state)
        for idx in range(count):
            check();step=Step(lab,solver,state,run.external(590,600,idx,count),dt)
            tangent=step.forward(tangent,disp.correction(step.mid));state=step.right
            tail=max(tail,disp.tail(state))
        diffs[tag]=lab.unit*lab.shell(state,tangent);tails[tag]=tail
        endpoint=lab.mesh.states[tag]
        onset[tag]=lab.unit/obj.unit_myr*lab.shell(endpoint,-1j*disp.correction(endpoint))
    shift=diffs['coupled']-diffs['reset'];rate=onset['coupled']-onset['reset']
    table(HERE/f'dispersion-{steps}.csv',[dict(steps=steps,eps_Kmax=disp.max,reset_max_fraction_eps_K_gt_0p01=tails['reset'],
        coupled_max_fraction_eps_K_gt_0p01=tails['coupled'],retarded_SI=known,exact_flat_dispersion_shift_SI=shift,
        relative_shift=shift/known,instantaneous_shift_SI_per_Myr=rate)],save)
    results=[]
    saved=records(HERE/f'onset-{steps}.csv')[0]
    predicted=float(saved['predicted_native_SI_per_Myr'])
    for power in (21,24,27,30,33,36):
        tick=2.**-power;sol=Evolution(obj,tick,lab.mesh.states['reset']);rates={}
        for tag in ('reset','coupled'):
            check();state=lab.mesh.states[tag]
            step=Step(lab,sol,state,run.fields[600],tick)
            tangent=step.forward(np.zeros_like(state),lab.drive(step.total,step.mid))
            rates[tag]=lab.unit/obj.unit_myr*lab.shell(step.right,tangent)/tick
        matched=rates['coupled']-rates['reset']
        results.append(dict(steps=steps,power=power,elapsed_Myr=tick*obj.unit_myr,
            measured_SI_per_Myr=matched,predicted_SI_per_Myr=predicted,relative_error=matched/predicted-1))
    table(HERE/f'onset-limit-{steps}.csv',results,save)
    print('dispersion and differential limit',steps,disp.max,shift/known,results[-1]['relative_error'],flush=True)
if __name__=='__main__':
    assert sys.argv[1:2] in (['32'],['64']) and sys.argv[2:] in ([],['--save'])
    test(int(sys.argv[1]),bool(sys.argv[2:]))
