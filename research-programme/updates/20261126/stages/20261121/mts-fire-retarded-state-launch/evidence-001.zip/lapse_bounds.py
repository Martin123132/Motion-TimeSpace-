"""Sharp field-gradient bounds and transfer of maximizing waveforms across time grids."""
from mts_retarded_launch_io import *

def bound(save):
    kernels={}
    for steps in STEPS:
        with np.load(HERE/f'kernel-{steps}.npz') as packet:
            kernels[steps]=packet['shared_lapse_SI']
            radius=packet['radius_y']
    first,second=[kernels[steps] for steps in STEPS]
    assert len(second)==2*len(first) and second.shape[1:]==first.shape[1:]
    grouped=second.reshape(len(first),2,*first.shape[1:]).sum(axis=1)
    differences=[]
    for name,reduce in [('arbitrary',lambda arr:arr),('radial',lambda arr:arr.sum(axis=-1)),
                        ('static_radial',lambda arr:arr.sum(axis=(0,2)))]:
        coarse=reduce(first);fine=reduce(grouped)
        differences.append(dict(family=name,coarse_gain=np.abs(coarse).sum(),fine_gain_on_coarse_time_cells=np.abs(fine).sum(),
                                fine_response_to_coarse_maximizer=(fine*np.sign(coarse)).sum(),
                                coarse_response_to_fine_maximizer=(coarse*np.sign(fine)).sum(),
                                kernel_L1_distance=np.abs(coarse-fine).sum()))
    out=[]
    for steps,kernel in kernels.items():
        lab=Launch(steps)
        delta=np.diff(radius)
        totals=records(HERE/f'paired-{steps}.csv')[0]
        target=abs(float(totals['conditional_time_SI']))
        for name,radial in [('time_varying',kernel.sum(axis=-1)),('static',kernel.sum(axis=(0,2))[None,:])]:
            assert np.max(abs(radial.sum(axis=1)))<1e-13*np.abs(radial).sum()
            primitive=np.cumsum(radial,axis=1)[:,:-1]
            gain=np.sum(abs(primitive)*delta)
            extremal=np.c_[np.zeros(len(radial)),np.cumsum(-np.sign(primitive)*delta,axis=1)]
            direct=(radial*extremal).sum()
            assert abs(direct/gain-1)<1e-11
            options=np.diff(extremal,axis=1)/delta
            assert np.max(abs(options))<1+5e-11
            normed=target/gain
            out.append(dict(steps=steps,family=name,gain_SI_per_unit_dQ_dy=gain,min_gradient_dQ_dy=normed,
                minimum_added_acceleration_SI=normed*lab.unit,extremal_relative_defect=abs(direct/gain-1)))
    table(HERE/'radial-gradient.csv',out,save);table(HERE/'grid-transfer.csv',differences,save)
if __name__=='__main__':
    assert sys.argv[1:] in ([],['--save'])
    bound(bool(sys.argv[1:]))
