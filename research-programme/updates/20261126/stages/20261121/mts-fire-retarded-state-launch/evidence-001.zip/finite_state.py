"""Independent endpoint check using normalized, phase-aligned waves rather than a density tangent."""
from mts_retarded_launch_io import *

def check_state(save):
    rows=[]
    for steps in STEPS:
        lab=Launch(steps);results={};amp=lab.mesh.ep
        with np.load(HERE/f'state-{steps}.npz') as bank:
            for arm in ('reset','coupled'):
                base=bank[arm+'_leading'];sub=bank[arm+'_known']
                norm=np.vdot(base,base).real
                phase=np.vdot(base,sub)/norm
                assert abs(phase.real)<1e-9
                sub=sub-phase*base
                factor=np.linalg.norm(sub)/np.sqrt(norm);angle=amp*factor
                tangent=sub/factor;wave=np.cos(angle)*base+np.sin(angle)*tangent
                assert abs(np.vdot(wave,wave).real/norm-1)<1e-12
                scale=lab.unit/amp
                finite=scale*(lab.shell(base,tangent)*np.sin(angle)*np.cos(angle)+
                    .5*lab.shell(tangent,tangent)*np.sin(angle)**2-.5*lab.shell(base,base)*np.sin(angle)**2)
                direct=scale*.5*lab.shell(wave+base,wave-base)
                linear=lab.unit*lab.shell(base,sub)
                assert abs(finite-direct)<2e-25
                results[arm]=(linear,finite)
                rows.append(dict(steps=steps,arm=arm,phase_free_fraction=2*np.sin(angle/2),
                                 removed_phase_rad=amp*phase.imag,linear_SI=linear,normalized_arc_SI=finite,
                                 direct_density_SI=direct,relative_difference=finite/linear-1))
        linear,finite=np.subtract(results['coupled'],results['reset'])
        expected=float(records(HERE/f'paired-{steps}.csv')[0]['density_state_SI'])
        assert abs(linear/expected-1)<1e-8 and abs(finite/linear-1)<2e-5
    table(HERE/'finite-state.csv',rows,save)
if __name__=='__main__':
    assert sys.argv[1:] in ([],['--save'])
    check_state(bool(sys.argv[1:]))
