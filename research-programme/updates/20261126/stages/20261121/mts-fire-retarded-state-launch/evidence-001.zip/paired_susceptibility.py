"""Summarize branch-specific lapse sensitivity and the terms in the derived PN drive."""
from mts_retarded_launch_io import *

def summarize(save):
    bounds=[];budgets=[]
    for steps in STEPS:
        lab=Launch(steps)
        state=float(records(HERE/f'paired-{steps}.csv')[0]['density_state_SI'])
        target=abs(float(records(HERE/f'paired-{steps}.csv')[0]['conditional_time_SI']))
        with np.load(HERE/f'differential-kernel-{steps}.npz') as archive:
            difference=archive['differential_lapse_SI']
        with np.load(HERE/f'kernel-{steps}.npz') as archive:
            common=archive['shared_lapse_SI'];radius=archive['radius_y']
        for which,kernel in [('shared',common),('coupled_minus_reset',difference)]:
            for label,radial in [('static',kernel.sum(axis=(0,2))[None,:]),('time_varying',kernel.sum(axis=-1))]:
                gain=(abs(np.cumsum(radial,axis=-1)[:,:-1])*np.diff(radius)).sum()
                half=np.abs(radial).sum()
                bounds.append(dict(steps=steps,field=which,radial_family=label,
                    gain_SI_per_gradient=gain,gain_SI_per_half_range=half,
                    min_half_range_Q_for_equal_time_magnitude=target/half,
                    min_radial_accel_SI_for_equal_time_magnitude=target/gain*lab.unit))
        rows=records(HERE/f'drive-history-{steps}.csv')
        total=0
        for name in dict.fromkeys(row['source'] for row in rows):
            legs=[sum(float(r['propagated_endpoint_SI']) for r in rows if r['source']==name and r['arm']==arm) for arm in ('coupled','reset')]
            matched=legs[0]-legs[1];total+=matched
            budgets.append(dict(steps=steps,source=name,reset_SI=legs[1],coupled_SI=legs[0],matched_SI=matched,
                                signed_fraction_of_net=matched/state))
        assert abs(total/state-1)<2e-7,(steps,total,state)
    table(HERE/'paired-lapse-susceptibility.csv',bounds,save)
    table(HERE/'drive-budget.csv',budgets,save)
if __name__=='__main__':
    assert sys.argv[1:] in ([],['--save'])
    summarize(bool(sys.argv[1:]))
