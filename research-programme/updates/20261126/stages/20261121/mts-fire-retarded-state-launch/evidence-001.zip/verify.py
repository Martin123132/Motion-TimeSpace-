"""Verify retained inputs, independent numerical paths and dated local restart."""
from mts_retarded_launch_io import *

def verify(save):
    check()
    for name in manifest:parent_file(name)
    rows_total=0;report={};expected={'PROTOCOL.md','DERIVATION.md','RESULTS.md','mts_retarded_launch_io.py','evolve.py',
        'launch_checks.py','paired_control.py','kinetic_check.py','increment_onset.py','lapse_bounds.py',
        'paired_susceptibility.py','finite_state.py','verify.py','validation.json'}
    def read(name,count):
        nonlocal rows_total
        path=HERE/(name+'.csv');rows=records(path)
        assert len(rows)==count
        assert all(None not in row and all(value not in (None,'','nan','inf','-inf') for value in row.values()) for row in rows)
        rows_total+=count;expected.add(path.name)
        return rows
    for steps in STEPS:
        suffix=f'-{steps}';ticks=9 if steps==32 else 18
        def group(name,n):return read(name+suffix,n)
        main,=group('paired',1)
        assert float(main['duration_Myr'])==22.190426999999545
        assert int(main['intervals'])==ticks
        history=group('history',ticks*6);pieces=group('drive-history',ticks*12);adjoint=group('adjoint',6)
        budget=group('budget',4);prep,=group('preparation',1)
        onset=group('onset',6);late=group('onset-limit',6);stable=group('increment-onset',6)
        direct=group('nonlinear',3);centered=group('centered',3);states=group('nonlinear-state',6)
        disp,=group('dispersion',1)
        checks={};report[str(steps)]=checks
        checks['occupation_derivative_max']=max(abs(float(r['number_derivative'])) for r in history)
        checks['leading_endpoint_L2_max']=max(float(r['leading_endpoint_error']) for r in adjoint)
        checks['forward_reverse_max_SI']=max(float(r['error_SI']) for r in adjoint)
        checks['native_launch_relative_error']=abs(float(stable[-1]['relative_error']))
        checks['raw_perturbation_final_relative_error']=float(direct[-1]['relative_error'])
        checks['centered_perturbation_final_relative_error']=float(centered[-1]['relative_error'])
        checks['max_monopole_shared_static_radial_gain']=float(budget[-1]['gain_SI_per_Q'])
        checks['kinetic_resummation_shift_fraction']=float(disp['relative_shift'])
        assert checks['occupation_derivative_max']<1e-8 and checks['leading_endpoint_L2_max']<1e-8
        assert checks['forward_reverse_max_SI']<1e-27 and checks['native_launch_relative_error']<2e-5
        assert abs(float(direct[-1]['relative_error']))<2e-5 and float(centered[-1]['relative_error'])<float(centered[0]['relative_error'])/20
        change=float(main['density_state_SI'])
        assert float(main['conditional_spatial_SI'])>0 and float(main['conditional_time_SI'])>0
        assert abs((float(main['conditional_spatial_SI'])-float(main['conditional_time_SI']))/float(main['unchanged_slip_SI'])-1)<1e-12
        assert abs(float(disp['relative_shift']))<2e-5 and abs(float(disp['retarded_SI'])/change-1)<1e-12
        for key in ('state','kernel','differential-kernel','initial-adjoint'):
            path=HERE/(key+suffix+'.npz');expected.add(path.name)
            with np.load(path) as archive:
                for member in archive:
                    assert np.isfinite(archive[member]).all(),member
        with np.load(HERE/('kernel'+suffix+'.npz')) as archive:
            kernel=archive['shared_lapse_SI'];assert kernel.shape[0]==ticks
        with np.load(HERE/('differential-kernel'+suffix+'.npz')) as archive:
            odd=archive['differential_lapse_SI'];assert odd.shape==kernel.shape
        total=abs(odd+kernel/2).sum()+abs(odd-kernel/2).sum()
        assert abs(total/float(prep['independent_lapse_gain_SI'])-1)<1e-12
        assert abs(total)>abs(kernel).sum()
    read('radial-gradient',4);read('grid-transfer',3);read('paired-lapse-susceptibility',8);read('drive-budget',12);read('finite-state',4)
    data=dict(status='conditional retarded 590-to-600 response and grid lapse sensitivities',parent_seal=EXPECTED,
              checked_csv_rows=rows_total,results=report)
    keep(HERE/'validation.json',(json.dumps(data,indent=2,sort_keys=True)+'\n').encode(),save)
    actual={p.name for p in HERE.iterdir()}-{'seal.json'}
    assert actual==expected,(actual-expected,expected-actual)
    seal={name:digest(HERE/name) for name in sorted(expected)}
    keep(HERE/'seal.json',(json.dumps(seal,indent=2,sort_keys=True)+'\n').encode(),save)
    print('Verified',rows_total,'rows,',len(expected),'sealed files;',digest(HERE/'seal.json'))
if __name__=='__main__':
    assert sys.argv[1:] in ([],['--save'])
    verify(bool(sys.argv[1:]))
