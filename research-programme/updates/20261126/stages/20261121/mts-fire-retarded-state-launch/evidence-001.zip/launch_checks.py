"""Independent early-time and nonlinear tests; no reuse of the adjoint for these controls."""
from mts_retarded_launch_io import *

def run(steps,save):
    lab=Launch(steps);obj=lab.obj;base=lab.run
    assert not np.any(base.fields[600])
    numerical=[];totals=[];detail=[]
    pack=np.load(HERE/f'state-{steps}.npz')
    current=records(parent_file('current-check.csv'))
    for divisor in (512,2048,8192,32768,131072,524288):
        dt=1/divisor;solver=Evolution(obj,dt,lab.mesh.states['reset'])
        branch={}
        for tag in ('reset','coupled'):
            check()
            state=lab.mesh.states[tag]
            step=Step(lab,solver,state,base.fields[600],dt)
            tangent=step.forward(np.zeros_like(state),lab.drive(step.total,step.mid))
            step_rate=lab.shell(step.right,tangent)/dt
            instant=lab.mesh.ordinary+lab.mesh.pots[tag]
            local_piece=lab.shell(state,-1j*obj.multiply(.5*instant**2,state))
            oldrows=[row for row in current if row['steps']==str(steps) and row['order']=='28' and row['arm']==tag]
            native=sum(float(row['volume_rate']) for row in oldrows)+local_piece
            surface=sum(float(row['surface_rate']) for row in oldrows)
            branch[tag]=np.array([step_rate,native,surface,local_piece])*lab.unit/obj.unit_myr
        diff=branch['coupled']-branch['reset']
        numerical.append(dict(steps=steps,divisor=divisor,duration_Myr=dt*obj.unit_myr,measured_rate_SI_per_Myr=diff[0],
            predicted_native_SI_per_Myr=diff[1],predicted_surface_SI_per_Myr=diff[2],local_projection_SI_per_Myr=diff[3],
            relative_to_native=diff[0]/diff[1]-1,relative_to_surface=diff[0]/diff[2]-1))
    count,dt=base.interval(590,600)
    conv=[]
    for amplitude in (2**-5,2**-7,2**-9):
        matched={}
        for tag,initial in lab.initial.items():
            check()
            solver=Evolution(obj,dt,initial);states={}
            for sign in (-1,1):
                state=initial.copy();moment=obj.moment(state)
                for tick in range(count):
                    ext=base.external(590,600,tick,count)+amplitude*sign*lab.smooth
                    state,moment,_,_=advance(obj,solver,state,moment,ext,dt)
                assert abs(inner(state,state)/obj.number-1)<1e-8
                states[sign]=state
            derivative=(states[1]-states[-1])/(2*amplitude)
            average=(states[1]+states[-1])/2
            matched[tag]=lab.unit*lab.shell(average,derivative)
            tangent=pack[tag+'_smooth']
            detail.append(dict(steps=steps,arm=tag,amplitude=amplitude,state_derivative_relative_error=np.linalg.norm(derivative-tangent)/np.linalg.norm(tangent)))
        paired=matched['coupled']-matched['reset']
        predicted=float(records(HERE/f'paired-{steps}.csv')[0]['smooth_probe_SI'])
        conv.append(abs(paired/predicted-1))
        totals.append(dict(steps=steps,amplitude=amplitude,nonlinear_SI=paired,tangent_SI=predicted,relative_error=conv[-1]))
    assert conv[-1]<2e-5,conv
    if conv[-1]>=conv[0]/20:
        print('direct differences become noise-limited; use separate cancellation-free pair test',steps,conv,flush=True)
    for suffix,data in [('onset',numerical),('nonlinear',totals),('nonlinear-state',detail)]:
        table(HERE/f'{suffix}-{steps}.csv',data,save)
    pack.close()
    print('tested onset and nonlinear responses',steps,numerical[-1]['relative_to_native'],conv[-1],flush=True)
if __name__=='__main__':
    assert sys.argv[1:2] in (['32'],['64']) and sys.argv[2:] in ([],['--save'])
    run(int(sys.argv[1]),bool(sys.argv[2:]))
