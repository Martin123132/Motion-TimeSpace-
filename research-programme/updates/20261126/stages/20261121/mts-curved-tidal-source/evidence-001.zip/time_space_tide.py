"""Independent temporal and spatial readers on the archived formation states."""
import csv
import io
import sys
from contextlib import nullcontext
from math import fsum
from pathlib import Path

HERE = Path(__file__).resolve().parent
PARENT = HERE.parent / "mts-formation-shear-transfer-20261121"
sys.path.insert(0, str(PARENT))
from library import solver as task
from readouts import core
from trial import exp, mul, pair, square
from continuum_metric import legacy

np = task.np
PIN = "5298fe3da00df1bb87eff54dd5748e5c81b54e4e63e81a4a914ad37b66f80019"

def table(name, rows):
    file = io.StringIO(newline="")
    writer = csv.DictWriter(file, rows[0], lineterminator="\n")
    writer.writeheader()
    writer.writerows(rows)
    task.lab.put(HERE / name, file.getvalue().encode())

def variant(model, grid, order):
    return task.flux(model, grid) if order == 20 else nullcontext()

def state_at(grid, seed, flag, tick, order):
    name = task.tag(grid, seed, flag, tick) + ".npz"
    path = PARENT / name
    if order == 20 or tick == 0:
        assert task.lab.sha(path) == task.meta(PARENT / "seal.json")["files"][name]
    else:
        path = task.original(grid, seed, flag, tick)
    with np.load(path) as saved:
        return task.old.Difference(saved["shared"], saved["signed"]), float(saved["clock"])

def annuli(model, physical, start, now):
    def one(shell, delta, initial_field, field_change):
        metric = core.ep.exp(shell.initial[0].real)
        window = core.ep.Window(shell, shell.initial, np.zeros_like(shell.initial), 8)
        def optical(values):
            spline = window.spline(values)
            antiderivative = spline.antiderivative()
            return spline(window.pos), antiderivative(window.pos)-antiderivative(0.)[:,None]
        geom, length = optical(metric)
        radial = delta[0].real
        drift = metric[0]*np.expm1(radial[0])
        dg, dl = optical(np.stack((drift,metric[1]*np.expm1(radial[0])+(metric[0]+drift)*radial[1])))
        raw, change = window.at(initial_field), window.at(field_change)
        nodes, weights = core.ep.leggauss(8)
        result = []
        for width in (.15,.3):
            half = core.ep.CENTER*width
            def shift(degree):
                return sum(weight*core.ep.weight(length[0]+.5*(node+1)*dl[0],half,degree) for node,weight in zip(nodes,weights))*dl[0]/2
            win = core.ep.weight(length[0],half),shift(1)
            slope = core.ep.weight(length[0],half,1),shift(2)
            factors = list(zip(geom,dg))
            field = list(zip(raw,change))
            value = (core.ep.secant(win,factors[0],field[1])+core.ep.secant(win,factors[1],field[0])
                     +core.ep.secant(slope,factors[0],(length[1],dl[1]),field[0]))
            result.append(1024*fsum(window.quad*value))
        return np.array(result)
    diff = now-start
    return (one(model.host,physical.base+physical.delta,start.base+start.delta,diff.base+diff.delta)
            -one(model.zero,physical.base,start.base,diff.base))

def spatial(model, physical):
    full = model.shell.initial+physical
    ell, bend, tilt, angular = (full[idx].real for idx in range(4))
    def derivative(value,degree):
        def evaluate(arr):
            return legacy(arr,model.shell.dx,model.shell.weights,model.shell.average)[degree-1]
        return task.old.Difference(evaluate(value.base),evaluate(value.delta))
    def slope(slot, degree):
        return model.reference[slot][degree]+derivative(physical[slot].real,degree)
    radius = model.shell.r
    first, tiltprime = slope(1,1), derivative(tilt[1],1)
    ellprime = slope(0,1)
    inverse = exp(-2*ell)
    sphere = np.exp(-2*bend[0])
    direct = 2*slope(1,2)-2*mul(ellprime,first)-2*ellprime/radius
    direct[1] += 6*(tiltprime-ellprime[0]*tilt[1])/radius
    direct = mul(inverse,direct)
    direct[0] += 2*inverse[0]*np.expm1(2*(ell[0]-bend[0]))/radius**2
    direct[1] += (inverse[0]*(4*ell[1]-6*tilt[1])+sphere*(8*bend[1]+12*angular[1]-6*ell[1]))/radius**2
    return -direct/3

def fd(model,grid,order,state,clock,step):
    start = model.mass.decode(state)[0][5].real
    change = start*0
    with variant(model,grid,order):
        advance = model.time_step(step)
        offset = state
        for idx,weight in enumerate((48,-36,16,-3),1):
            offset = advance(clock+(idx-1)*step,offset)
            change += weight*(model.mass.decode(offset)[0][5].real-start)
    return change/(12*step)

def fields(model,grid,order,state,clock,with_fd):
    mapped, aux = model.mass.decode(state)
    physical = task.lab.rawfield(model,state,clock)
    full = model.shell.initial+physical
    trace, shear = (full[idx].real for idx in (4,5))
    energy, stresses, anis, _, _ = task.evolve8.sources(model,clock,physical)
    rates, _, info = model.mass.push(aux,energy[0],stresses[0]/3+anis[0],anis[0])
    with variant(model,grid,order):
        dyn = model.rhs(clock,state) if model.shell.flag else model.nonlinear(clock,state)
    derivative = pair(2*(rates[2]-info["ka_dot"])/3,dyn[5,1].real)
    curvature = spatial(model,physical)
    kinetic = 2*mul(trace,shear)/3+square(shear)/2
    extra = -mul(trace,shear)/3+square(shear)/2
    data = dict(temporal=kinetic-derivative,space=-curvature+extra+anis,
                neg_weyl=kinetic-derivative-anis/2,stress=anis,spatial_curvature=curvature,
                shear_time=derivative,kinematic=kinetic)
    if with_fd:
        for div in (2,4):
            spacing = (1 if clock==0 else -1)*4096*np.pi/(1024*model.shell.mu*div)
            data["fd"+str(div)] = kinetic-fd(model,grid,order,state,clock,spacing)
    return physical,data

def run(grid,seed):
    task.lock()
    assert task.lab.sha(PARENT/"seal.json")==PIN and (grid,seed) in task.RUNS
    aperture, profiles, checks = [],[],[]
    for flag in (0,1):
        with task.system(grid,seed,flag) as model:
            for order in (12,20):
                for tick in (0,*task.CLOCKS):
                    task.guard()
                    state, clock = state_at(grid,seed,flag,tick,order)
                    raw, data = fields(model,grid,order,state,clock,tick in (0,1024))
                    if tick==0:
                        start=data
                    for label in ("temporal","space","fd2","fd4"):
                        if label not in data:continue
                        diff=(data[label]-data["space"]).delta[1]
                        fd_error=(data[label]-data["temporal"]).delta[1]
                        for reg,mask in (("first",model.shell.r<1/grid),("r<0.3",model.shell.r<.3),("bulk",(model.shell.r>.6)&(model.shell.r<2.1))):
                            def norm(arr):return np.linalg.norm(arr[mask])
                            profiles.append(dict(flag=flag,order=order,tick=tick,reader=label,region=reg,
                                signed_first=data[label].delta[1][mask][0],space_first=data["space"].delta[1][mask][0],
                                difference_first=diff[mask][0],difference_norm=norm(diff),space_norm=norm(data["space"].delta[1]),
                                vs_time_norm=norm(fd_error)))
                    if not tick:continue
                    readings={key:annuli(model,raw,start[key],value) for key,value in data.items()}
                    assert np.allclose(readings["temporal"]-readings["stress"]/2,readings["neg_weyl"],rtol=1e-9,atol=1e-29)
                    for idx,width in enumerate((.15,.3)):
                        for key,value in readings.items():
                            aperture.append(dict(flag=flag,order=order,tick=tick,width=width,field=key,value=value[idx]))
                    if order==20:
                        with np.load(PARENT/(task.tag(grid,seed,flag,tick)+".npz")) as saved: prior=saved["tide"][:,0]
                    else:
                        prior=[None,None]
                    for idx,width in enumerate((.15,.3)):
                        checks.append(dict(flag=flag,order=order,tick=tick,width=width,
                                           reproduced=readings["space"][idx],archived=prior[idx]))
                print(grid,seed,flag,order,"finished",flush=True)
    for name,rows in (("apertures",aperture),("profiles",profiles),("crosscheck",checks)):
        table(f"g{grid}-s{seed}-{name}.csv",rows)

if __name__=="__main__":
    run(*map(int,sys.argv[1:]))

