"""Score two existing forecasts against identical temporal Riemann readings and scale."""
from time_space_tide import HERE,task,table

def run():
    forecasts={(int(r["seed"]),float(r["fraction"]),float(r["width"])):r for r in task.read(task.FORM/"matched-gravity-prediction.csv")}
    rows=[]
    for r in task.read(HERE/"paired-detectors.csv"):
        if r["reader"] not in ("temporal","fd2","fd4"):continue
        tick,seed,width=int(r["tick"]),int(r["sign"]),float(r["width"])
        f=forecasts[seed,tick/1024,width]
        newton,stress,total=(float(f[k]) for k in ("matched_newton","matched_tt","matched"))
        signal=float(r["signal"])
        unit=abs(newton)*1e-6
        assert abs(total-(newton+stress))<1e-12*unit+1e-15*abs(total)
        rows.append(dict(grid=r["grid"],sign=seed,order=r["order"],tick=tick,width=width,reader=r["reader"],signal=signal,
                         matched_newton=newton,predicted_stress=stress,measured_excess=signal-newton,
                         measured_over_predicted=(signal-newton)/stress,
                         newton_residual_ppm=(signal-newton)/unit,full_residual_ppm=(signal-total)/unit,
                         newton_within=abs(signal-newton)<=20*unit,full_within=abs(signal-total)<=20*unit))
    table("newton-vs-driven.csv",rows)
    print(len(rows),"paired no-fit forecast comparisons")
if __name__=="__main__":run()
