import csv
import hashlib
import json
import math
import re
import sys
from collections import Counter
from pathlib import Path
from time_space_tide import HERE,PARENT,PIN,task
import compare_tides
import newton_test

def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()

def run():
    task.lock()
    assert sha(PARENT/"seal.json")==PIN
    for folder in (PARENT,task.FORM,task.PRIOR):
        for name,digest in task.meta(folder/"seal.json")["files"].items():
            assert sha(folder/name)==digest,name
    compare_tides.run()
    newton_test.run()
    counts={"paired-detectors.csv":216,"raw-centre-change.csv":72,"spacetime-controls.csv":20,"newton-vs-driven.csv":72}
    for grid,seed in task.RUNS:
        for suffix,count in (("apertures",240),("crosscheck",32),("profiles",168),("radial-source",1800)):
            counts[f"g{grid}-s{seed}-{suffix}.csv"]=count
    assert {p.name for p in HERE.glob("*.csv")}==set(counts)
    for name,count in counts.items():
        rows=task.read(HERE/name)
        assert len(rows)==count and all(None not in row and None not in row.values() for row in rows)
        for row in rows:
            for value in row.values():
                try: numeric=float(value)
                except ValueError:continue
                assert math.isfinite(numeric)
    for grid,seed in task.RUNS:
        prefix=f"g{grid}-s{seed}-"
        for suffix,columns in (("apertures",("flag","order","tick","width","field")),
                               ("radial-source",("flag","order","tick","series","region","term")),
                               ("profiles",("flag","order","tick","region","reader"))):
            rows=task.read(HERE/(prefix+suffix+".csv"))
            assert len(rows)==len({tuple(row[c] for c in columns) for row in rows})
        rows=task.read(HERE/(prefix+"radial-source.csv"))
        values={tuple(row[c] for c in ("flag","order","tick","series","region","term")):float(row["first"]) for row in rows}
        for key,observed in values.items():
            if key[-1]!="predicted":continue
            parts=[values[(*key[:-1],tag)] for tag in ("spatial_TT","other_shape","extrinsic","matter")]
            assert abs(math.fsum(parts)-observed)<=1e-24+1e-12*sum(map(abs,parts))
    controls=task.read(HERE/"spacetime-controls.csv")
    assert len({(r["mode"],r["step"],r["field"]) for r in controls})==20
    for row in controls:
        assert float(row["energy_density_min"])>0 and float(row["prediction"])!=0
        assert float(row["abs_error"])<30*float(row["step"])**2
    tests=task.read(HERE/"newton-vs-driven.csv")
    passed=Counter()
    for row in tests:
        if row["order"]!="12" or row["reader"]!="temporal":continue
        for which in ("newton","full"):
            assert (row[which+"_within"]=="True")== (abs(float(row[which+"_residual_ppm"]))<=20)
            if row[which+"_within"]=="True":passed[int(row["grid"]),int(row["sign"]),which]+=1
    assert [passed[g,s,k] for g,s in task.RUNS for k in ("newton","full")]==[2,8,2,8,6,3]
    for document in HERE.glob("*.md"):
        for url in re.findall(r"\[[^\]]*\]\(([^)]+)\)",document.read_text(encoding="utf-8")):
            if not url.startswith("https://"):assert (HERE/url).is_file(),url
    dependencies={}
    for module in tuple(sys.modules.values()):
        filename=getattr(module,"__file__",None)
        if not filename:continue
        file=Path(filename).resolve()
        if file.suffix==".py" and file.is_relative_to(HERE.parent) and not file.is_relative_to(HERE):
            dependencies[file.relative_to(HERE.parent).as_posix()]=sha(file)
    files={p.name:sha(p) for p in sorted(HERE.iterdir()) if p.is_file() and p.name!="seal.json"}
    payload=dict(parent=PIN,local_imports=dict(sorted(dependencies.items())),files=files,rows=counts)
    task.lab.put(HERE/"seal.json",(json.dumps(payload,indent=2,allow_nan=False)+"\n").encode())
    print(len(files),"local files;",sum(counts.values()),"data rows;",len(dependencies),"imported source fingerprints;",sha(HERE/"seal.json"))
if __name__=="__main__":run()
