"""Proper-radius decomposition of the radial angular metric acceleration."""
from time_space_tide import task, np, state_at, variant, table, PIN, PARENT
from continuum_metric import legacy

def measure(model,grid,order,state,time):
    physical=task.lab.rawfield(model,state,time)
    full=model.shell.initial+physical
    wave=full[0,1].real
    bend=full[1,1].real
    tilt=full[2,1].real
    def derivatives(value):
        def parts(arr):return legacy(arr,model.shell.dx,model.shell.weights,model.shell.average)
        return [task.old.Difference(base,delta) for base,delta in zip(parts(value.base),parts(value.delta))]
    increments=[derivatives(physical[idx].real) for idx in (0,1)]
    def deriv(slot,degree):return model.reference[slot][degree]+increments[slot][degree-1]
    radius=model.shell.r
    ellprime,bprime,bsecond=(deriv(0,1)[0],deriv(1,1)[0],deriv(1,2)[0])
    slope,b_slope,curv,b_curv=(deriv(0,1)[1],deriv(1,1)[1],deriv(0,2)[1],deriv(1,2)[1])
    tiltprime=derivatives(tilt)[0]
    inv=np.exp(-2*full[0,0].real)
    logdens=bprime+1/radius
    coeff=inv*(6*(np.expm1(2*(full[0,0].real-full[1,0].real))/radius**2-bprime*(2/radius+bprime))
               -2*(bsecond+bprime*(2/radius+bprime)-ellprime*logdens))
    propagation=inv*(curv+(6*logdens-ellprime)*slope)
    potential=-coeff*wave
    shape_gap=2*b_slope-slope+6*(tilt-wave)/radius-6*bprime*wave
    gap_slope=2*b_curv-curv+6*(tiltprime-slope)/radius-6*(tilt-wave)/radius**2-6*(bsecond*wave+bprime*slope)
    longitudinal=inv*(gap_slope+(2*logdens-ellprime)*shape_gap)
    energy,stress,anis,_,_=task.evolve8.sources(model,time,physical)
    trace=full[4].real
    shear=full[5].real
    kinetic=-2*trace[0]*trace[1]/3-trace[1]*shear[0]-trace[0]*shear[1]
    matter=energy[1]/2-stress[1]/6+anis[1]
    with variant(model,grid,order):
        rhs=model.rhs(time,state) if model.shell.flag else model.nonlinear(time,state)
    observed=-rhs[4,1].real/3-rhs[5,1].real
    total=propagation+potential+longitudinal+kinetic+matter
    return dict(observed=observed,spatial_TT=propagation+potential,curvature_potential=potential,
                other_shape=longitudinal,extrinsic=kinetic,energy=energy[1]/2,
                stress_trace=-stress[1]/6,stress_TF=anis[1],matter=matter,predicted=total)

def run(grid,seed):
    task.lock()
    assert task.lab.sha(PARENT/"seal.json")==PIN
    rows=[]
    for flag in (0,1):
        with task.system(grid,seed,flag) as model:
            previous={}
            for tick in (0,*task.CLOCKS):
                current={}
                for order in (12,20):
                    state,time=state_at(grid,seed,flag,tick,order)
                    current[str(order)]=measure(model,grid,order,state,time)
                current["switch"]={k:current["20"][k]-value for k,value in current["12"].items()}
                if not tick:previous=current
                for scheme,fields in current.items():
                    for kind in ("absolute","change_from_formation"):
                        values={k:(val if kind=="absolute" else val-previous[scheme][k]).delta for k,val in fields.items()}
                        observed=values["observed"]
                        for region,mask in (("first",model.shell.r<1/grid),("core",model.shell.r<.3),("bulk",(model.shell.r>.6)&(model.shell.r<2.1))):
                            def norm(val):return np.linalg.norm(val[mask])
                            den=norm(observed)
                            for key,val in values.items():
                                rows.append(dict(flag=flag,order=scheme,tick=tick,series=kind,region=region,term=key,first=val[mask][0],
                                    norm=norm(val),observed_norm=den,residual_norm=norm(val-observed),
                                    relative_error=norm(val-observed)/den if den else ""))
    table(f"g{grid}-s{seed}-radial-source.csv",rows)

if __name__=="__main__":
    import sys
    run(*map(int,sys.argv[1:]))

