from time_space_tide import HERE, PARENT, task, table

def run():
    truth={(int(row["seed"]),float(row["fraction"]),float(row["width"])):row for row in task.read(task.FORM/"matched-gravity-prediction.csv")}
    scores=[]
    centre=[]
    for grid,seed in task.RUNS:
        prefix=f"g{grid}-s{seed}-"
        data={(int(row["flag"]),int(row["order"]),int(row["tick"]),float(row["width"]),row["field"]):float(row["value"]) for row in task.read(HERE/(prefix+"apertures.csv"))}
        bands={(int(row["tick"]),float(row["width"])):row for row in task.read(PARENT/(prefix+"bands.csv")) if row["channel"]=="ricci"}
        old={(int(row["tick"]),float(row["width"])):float(row["new"]) for row in task.read(task.FORM/"proper-tides-full.csv")
             if int(row["grid"])==grid and int(row["seed"])==seed and row["channel"]=="ricci"}
        raw={(int(row["flag"]),int(row["order"]),int(row["tick"]),row["reader"]):row for row in task.read(HERE/(prefix+"profiles.csv")) if row["region"]=="first"}
        for order in (12,20):
            for tick in task.CLOCKS:
                for width in (.15,.3):
                    forecast=truth[seed,tick/1024,width]
                    scale=abs(float(forecast["matched_newton"]))
                    matched=float(forecast["matched"])
                    saved=old[tick,width] if order==12 else float(bands[tick,width]["new"])
                    def difference(field):
                        return data[0,order,tick,width,field]-data[1,order,tick,width,field]
                    for reader in ("temporal","space","fd2","fd4","neg_weyl","stress"):
                        if (0,order,tick,width,reader) not in data:continue
                        signal=difference(reader)
                        ppm=(signal-matched)/scale*1e6
                        eligible=reader in ("temporal","space","fd2","fd4")
                        scores.append(dict(grid=grid,sign=seed,order=order,tick=tick,width=width,reader=reader,
                            wave=data[0,order,tick,width,reader],cold=data[1,order,tick,width,reader],signal=signal,
                            matched=matched if eligible else "",scale=scale,forecast_ppm=ppm if eligible else "",
                            inside=abs(ppm)<=20 if eligible else "",minus_saved_ppm=(signal-saved)/scale*1e6 if eligible else "",
                            minus_temporal_ppm=(signal-difference("temporal"))/scale*1e6))
                        if reader=="space":
                            assert abs(signal-saved)/scale<1e-6,(grid,seed,order,tick,width)
                for flag in (0,1):
                    for reader in ("temporal","fd2","fd4"):
                        if (flag,order,tick,reader) not in raw:continue
                        here,initial=(raw[flag,order,end,reader] for end in (tick,0))
                        motion=float(here["signed_first"])-float(initial["signed_first"])
                        space=float(here["space_first"])-float(initial["space_first"])
                        delta=float(here["difference_first"])-float(initial["difference_first"])
                        centre.append(dict(grid=grid,sign=seed,flag=flag,order=order,tick=tick,reader=reader,change=motion,
                            spatial_change=space,reader_difference=delta,relative_to_spatial_change=delta/abs(space) if space else ""))
    table("paired-detectors.csv",scores)
    table("raw-centre-change.csv",centre)
    for grid,seed in task.RUNS:
        for order in (12,20):
            for reader in ("temporal","space","fd2","fd4"):
                rows=[r for r in scores if (r["grid"],r["sign"],r["order"],r["reader"])==(grid,seed,order,reader)]
                print(grid,seed,order,reader,sum(r["inside"] for r in rows),len(rows),
                      "max ppm",round(max(abs(r["forecast_ppm"]) for r in rows),3),
                      "max vs archived",round(max(abs(r["minus_saved_ppm"]) for r in rows),3))
if __name__=="__main__":run()
