"""Direct four-dimensional metric curvature; no ADM evolution or saved field stencil."""
import itertools
import sympy as sp
from time_space_tide import table

time,radius,mu,phi,amplitude = sp.symbols("t r u p e")
axes = (time,radius,mu,phi)
harmonic=(3*mu**2-1)/2
cap=1-mu**2

def direct(metric,point):
    indices=range(metric.rows)
    coords=axes if metric.rows==4 else axes[1:]
    def at(matrix):
        return matrix.subs(point)
    base=at(metric)
    inverse=base.inv()
    first=[at(metric.diff(coord)) for coord in coords]
    second=[[at(metric.diff(left,right)) for right in coords] for left in coords]
    christ={}
    for left,right in itertools.product(indices,repeat=2):
        christ[left,right]=sp.Matrix([(first[left][idx,right]+first[right][idx,left]-first[idx][left,right])/2 for idx in indices])
    def riemann(one,two,three,four):
        principal=(second[two][three][one,four]+second[one][four][two,three]
                   -second[two][four][one,three]-second[one][three][two,four])/2
        return principal+(christ[two,three].T*inverse*christ[one,four]-christ[two,four].T*inverse*christ[one,three])[0]
    ric=sp.Matrix(metric.rows,metric.rows,lambda left,right:sum(inverse[idx,jdx]*riemann(idx,left,jdx,right)
                  for idx,jdx in itertools.product(indices,repeat=2) if inverse[idx,jdx]))
    mixed=inverse*ric
    if metric.rows==3:
        return dict(rr=mixed[0,0],scalar=sp.trace(mixed))
    def tf(matrix):
        return matrix[1,1]-sum(matrix[idx,idx] for idx in (1,2,3))/3
    electric=inverse*sp.Matrix(4,4,lambda left,right:riemann(left,0,right,0))
    return dict(tidal=tf(electric),pi=tf(mixed),density=ric[0,0]+sp.trace(mixed)/2)

def run():
    out=[]
    node={time:sp.Rational(1,7),radius:sp.Rational(2,3),mu:sp.Rational(1,3)}
    for mode in ("TT","general"):
        scale=1+time/3+time**2/11
        area=radius*(1-radius**2/18)*(1+time/4+time**2/23)
        def proper(value):return value.diff(radius)/scale
        expansion=proper(area)/area
        ell=(1+time/5+time**2/7)*(1-radius**2/3+radius**4/9)
        if mode=="TT":
            bend=-ell/2
            tilt=area*proper(ell)/3+proper(area)*ell
            tensor=(area*proper(tilt)+3*proper(area)*tilt-ell)/2
        else:
            bend=radius**2*(1+time**2)/7
            tilt=radius**4*(1-time)/13
            tensor=radius**2*(1+2*time)/11
        metric=sp.diag(-1,scale**2,area**2/cap,area**2*cap)
        variation=sp.zeros(4)
        variation[1,1]=2*scale**2*ell*harmonic
        variation[1,2]=variation[2,1]=scale*area*tilt*harmonic.diff(mu)
        variation[2,2]=area**2*(2*bend*harmonic/cap+tensor*(harmonic.diff(mu,2)-mu*harmonic.diff(mu)/cap+3*harmonic/cap))
        variation[3,3]=area**2*(2*bend*harmonic*cap+tensor*(-mu*cap*harmonic.diff(mu)+3*harmonic*cap))
        shell=2*proper(bend)-2*expansion*ell+6*tilt/area
        normal=-proper(shell)-2*expansion*shell+2*ell*proper(expansion)+6*ell/area**2
        scalar=(8*bend+12*tensor)/area**2+2*normal-2*expansion*shell
        trace0=-scale.diff(time)/scale-2*area.diff(time)/area
        trace1=-ell.diff(time)-2*bend.diff(time)
        shear0=-scale.diff(time)/scale-trace0/3
        shear1=-ell.diff(time)-trace1/3
        ksigma=trace0*shear1+trace1*shear0
        kinetic=2*ksigma/3+shear0*shear1
        tidal=shear1.diff(time)-kinetic
        pi=normal-scalar/3+ksigma-shear1.diff(time)
        expect=dict(rr=normal,scalar=scalar,tidal=tidal,pi=pi,weyl=tidal+pi/2)
        if mode=="TT":
            reduced=(-proper(proper(ell))-6*expansion*proper(ell)
                     +(6*(1-proper(area)**2)/area**2-2*proper(proper(area))/area)*ell)
            assert (reduced-normal).subs(node)==0
        metric=metric+amplitude*variation
        for step in (sp.Rational(1,10000),sp.Rational(1,1000000)):
            values=[]
            for sign in (-1,1):
                point={**node,amplitude:sign*step}
                data=direct(metric,point)
                data.update(direct(metric[1:,1:],point))
                data["weyl"]=data["tidal"]+data["pi"]/2
                assert data["density"]>0
                values.append(data)
            for key,expression in expect.items():
                prediction=(expression*harmonic).subs(node)
                difference=(values[1][key]-values[0][key])/(2*step)
                error=abs(float(difference-prediction))
                assert prediction and error<30*float(step)**2,(mode,key,prediction,error)
                out.append(dict(mode=mode,field=key,step=float(step),prediction=float(prediction),metric_difference=float(difference),
                                abs_error=error,energy_density_min=float(min(row["density"] for row in values))))
    table("spacetime-controls.csv",out)
    print(len(out),"nonzero component controls")

if __name__=="__main__":run()
