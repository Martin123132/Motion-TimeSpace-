"""Saved dual modal coordinates and exact short-time evolution on one quartic drive panel."""
import hashlib
import json
from math import factorial
from pathlib import Path
from functools import lru_cache
import zipfile
import numpy as np
from scipy.interpolate import CubicSpline
from scipy.special import eval_legendre,roots_legendre

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
AXIS=ROOT/"mts-lmc-fixed-occupation-axisymmetric-20261119"
OLD=ROOT/"mts-einstein-photon-phase-20261121"
TAGS=("L2M10","L2M10first","L2M11","L3M10","L3M10rad","L3M11")

def sha(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream,"sha256").hexdigest()

@lru_cache
def saved(name):
    guard()
    path=AXIS/name
    assert sha(path)==manifest()[name],name
    return path

def guard():
    assert not any((directory/"STOP-REQUESTED").exists() for directory in (ROOT,AXIS,OLD,HERE,
        ROOT/"mts-lmc-tidal-history-20261119",ROOT/"mts-finite-bar-mean-response-20261119"))

@lru_cache
def manifest():
    path=AXIS/"seal.json"
    assert sha(path)=="a46d251285faaba640cea0288634284d6d3046a9693e934921a28936060c6f70"
    return json.loads(path.read_bytes())["files"]

@lru_cache
def drive_tail(tag):
    path=saved(f"shell-{tag}-r320-l40-q36-t16.npz")
    with np.load(path) as bank:
        times,radii=bank["time"][-5:],bank["radius"]
    with zipfile.ZipFile(path) as archive,archive.open("V.npy") as stream:
        version=np.lib.format.read_magic(stream)
        assert version==(1,0)
        shape,fortran,dtype=np.lib.format.read_array_header_1_0(stream)
        assert not fortran and shape[1:]==(len(radii),21) and dtype==np.dtype("float64")
        size=int(np.prod(shape[1:]))*dtype.itemsize
        stream.seek((shape[0]-5)*size,1)
        tail=np.frombuffer(stream.read(),dtype=dtype).reshape(5,*shape[1:])
    return times,radii,tail

def get_op(case,keep=-100):
    with np.load(saved(f"operators/{case}-k{keep}.npz")) as raw:
        return {key:raw[key] for key in ("r","orders","block","ground","u","momentum","sigma","sky","length","velocity","weight","mu","aw")}

def projected_drive(op,tag):
    times,radii,tail=drive_tail(tag)
    modes=op["orders"]
    angular=np.sqrt(2*modes+1)*eval_legendre(modes,op["mu"][:,None])
    external=np.arange(0,42,2)
    ext=np.sqrt(2*external+1)*eval_legendre(external,op["mu"][:,None])
    knots=op["length"]*op["r"]
    potential=CubicSpline(radii,tail,axis=1)(np.minimum(radii[-1],knots))
    potential[:,knots>radii[-1]]=0
    product=(potential@ext.T)*(op["ground"]@angular.T)
    field=product@(op["aw"][:,None]*angular)/op["velocity"]**2
    force=np.einsum("lrk,trl->tlk",op["block"],field,optimize=True).reshape(5,-1)@op["u"]
    return times*op["velocity"]/op["length"],force

def drive_derivatives(times,force,center):
    span=times[-1]-times[0]
    coords=(times-center)/span
    coeff=np.linalg.solve(np.vander(coords,5,increasing=True),force)
    return np.array([vector*factorial(degree)/span**degree for degree,vector in enumerate(coeff)])

def transport(sigma,elapsed,position,speed,derivs):
    angle=-1j*sigma*elapsed
    exp=np.exp(angle)
    coeff=exp
    result=(position+1j*speed/sigma)*exp
    small=abs(angle)<.85
    for idx,force in enumerate(derivs):
        nextcoef=np.empty_like(angle)
        nextcoef[~small]=(coeff[~small]-1/factorial(idx))/angle[~small]
        local=angle[small]
        nextcoef[small]=np.polynomial.polynomial.polyval(local,[1./factorial(deg+idx+1) for deg in range(20)])
        coeff=nextcoef
        result-=1j*elapsed**(idx+1)*coeff*force/sigma
    return result.real,result.imag*sigma

def initial(op,case,delay_origin,keep=-100):
    def reduce(field):
        return np.einsum("lrk,rl->lk",op["block"],field,optimize=True).ravel()
    positions=[];speeds=[];derivatives=[];terminal=[];records=[];endrates=[];endforces=[]
    for history in TAGS:
        times,force=projected_drive(op,history)
        assert times[-1]==0 and times[0]<-2*delay_origin
        with np.load(saved(f"states/{case}-{history}-k{keep}-r320-l40-q36-t16-v16.npz")) as state:
            endpos=op["momentum"].T@reduce(state["x"])
            endrate=op["u"].T@reduce(state["y"])
            previous=state["sky_time"][-2]
            assert abs(state["time_native"][-2]*op["velocity"]/op["length"]-times[0])<1e-13
        terminal.append(endpos)
        terminal_d=drive_derivatives(times,force,0.)
        endrates.append(endrate);endforces.append(terminal_d)
        pos,rate=transport(op["sigma"],-delay_origin,endpos,endrate,terminal_d)
        driving=drive_derivatives(times,force,-delay_origin)
        positions.append(pos);speeds.append(rate);derivatives.append(driving)
        prev,_=transport(op["sigma"],times[0]+delay_origin,pos,rate,driving)
        discrepancy=np.linalg.norm(op["sky"]@prev-previous)/np.linalg.norm(previous)
        recovered,velocity=transport(op["sigma"],delay_origin,pos,rate,driving)
        roundtrip=max(np.linalg.norm(recovered-endpos)/np.linalg.norm(endpos),
                      np.linalg.norm(velocity-endrate)/np.linalg.norm(endrate))
        assert discrepancy<1e-9 and roundtrip<2e-9,(discrepancy,roundtrip)
        records.append(dict(case=case,history=history,previous_epoch_sky_relative=discrepancy,
                            return_state_relative=roundtrip,panel_start=float(times[0]),center=-delay_origin))
    return (np.array(positions).T,np.array(speeds).T,np.moveaxis(np.array(derivatives),0,-1),np.array(terminal).T,
            records,np.array(endrates).T,np.moveaxis(np.array(endforces),0,-1))

def trig_kernel(angle):
    result=[np.cos(angle),np.sinc(angle/np.pi)]
    for degree in range(2,7):
        values=np.empty_like(angle)
        small=abs(angle)<1.
        values[~small]=(1/factorial(degree-2)-result[degree-2][~small])/angle[~small]**2
        if degree==2:
            values[~small]=.5*np.sinc(angle[~small]/(2*np.pi))**2
        values[small]=np.polynomial.polynomial.polyval(angle[small]**2,[(-1.)**idx/factorial(2*idx+degree) for idx in range(12)])
        result.append(values)
    return result

