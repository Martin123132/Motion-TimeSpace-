"""Contract even and odd null-time kernels; no extension beyond the saved orbit."""
from collections import defaultdict
import numpy as np
from scipy import constants
from modes import get_op,initial,TAGS,trig_kernel,transport,guard
from geometry import OpticalMesh

def parity_test(op,states,span):
    position,speed,source=states[:3]
    sigma=op["sigma"]
    errors=[]
    for delta in (span/367,span*.31,span*.97):
        kernels=trig_kernel(sigma*delta)
        for col in (0,3):
            forward,fp=transport(sigma,delta,position[:,col],speed[:,col],source[:,:,col])
            reverse,rp=transport(sigma,-delta,position[:,col],speed[:,col],source[:,:,col])
            accel=-sigma**2*position[:,col]-source[0,:,col]
            de=accel*delta**2*kernels[2]-source[2,:,col]*delta**4*kernels[4]-source[4,:,col]*delta**6*kernels[6]
            jo=accel*delta*kernels[1]-source[2,:,col]*delta**3*kernels[3]-source[4,:,col]*delta**5*kernels[5]
            do=speed[:,col]*delta*kernels[1]-source[1,:,col]*delta**3*kernels[3]-source[3,:,col]*delta**5*kernels[5]
            je=speed[:,col]*kernels[0]-source[1,:,col]*delta**2*kernels[2]-source[3,:,col]*delta**4*kernels[4]
            for value,actual in ((position[:,col]+de+do,forward),(position[:,col]+de-do,reverse),
                                 (je+jo,fp),(je-jo,rp)):
                errors.append(np.linalg.norm(value-actual)/np.linalg.norm(actual))
    assert max(errors)<3e-12,max(errors)
    return max(errors)

def integrate(mesh,states,vertical,transverse,slow=1.):
    op=mesh.op
    position,speed,drive,endpos=states[:4]
    sigma=op["sigma"]
    eps=op["velocity"]*1000/constants.c*slow
    accel=-sigma[:,None]**2*position-drive[0]
    totals=defaultdict(lambda:np.zeros((3,len(TAGS))))
    heights,measure=mesh.panels(vertical)
    for start in range(0,len(heights),48):
        guard()
        section=slice(start,start+48)
        local=heights[section]
        delay=eps*local[:,None]
        density,current,transverse_flow=mesh.readout(local,transverse,with_weak=True)
        kernels=trig_kernel(delay*sigma)
        weights=measure[section,None]
        def row(field,factor=1.):
            return np.einsum("zom,zm->om",field,weights*factor,optimize=True)
        base=row(density);basis=row(current)
        totals["central"]+=base@position
        totals["terminal"]+=base@endpos
        totals["static_current"]+=basis@speed*(-2*eps)
        totals["density_even"]+=(row(density,delay**2*kernels[2])@accel-row(density,delay**4*kernels[4])@drive[2]
                               -row(density,delay**6*kernels[6])@drive[4])
        totals["current_odd"]+=(-2*eps)*(row(current,delay*kernels[1])@accel-row(current,delay**3*kernels[3])@drive[2]
                                      -row(current,delay**5*kernels[5])@drive[4])
        totals["density_second"]+=row(density,delay**2/2)@accel
        totals["current_second"]+=(-2*eps)*row(current,delay)@accel
        totals["weak_transverse"]+=row(transverse_flow,delay**2/2)@accel
        totals["density_odd"]+=(row(density,delay*kernels[1])@speed-row(density,delay**3*kernels[3])@drive[1]
                               -row(density,delay**5*kernels[5])@drive[3])
        totals["current_even"]+=(-2*eps)*(row(current,kernels[0])@speed-row(current,delay**2*kernels[2])@drive[1]
                                         -row(current,delay**4*kernels[4])@drive[3])
        totals["density_first"]+=row(density,delay)@speed
    return totals

