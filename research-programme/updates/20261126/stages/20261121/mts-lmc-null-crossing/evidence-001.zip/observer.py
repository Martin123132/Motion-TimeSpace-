"""Finite affine-distance focusing and time variation on two axial observer worldlines."""
from math import factorial
import numpy as np
from scipy import constants
from scipy.special import roots_legendre
from modes import trig_kernel,guard

DISTANCES=np.array([20.,35.,50.])

def terminal_step(t,sigma,pos,rate,drive):
    kernels=trig_kernel(t*sigma)
    accel0=-sigma[:,None]**2*pos-drive[0]
    def term(factor,field):
        return factor[:,:,None]*field
    diff=term(t**2*kernels[2],accel0)+term(t*kernels[1],rate)
    vel=term(t*kernels[1],accel0)+term(kernels[0],rate)
    force_change=0.
    for degree in range(1,5):
        diff-=term(t**(degree+2)*kernels[degree+2],drive[degree])
        vel-=term(t**(degree+1)*kernels[degree+1],drive[degree])
        force_change+=term(t**degree/factorial(degree),drive[degree])
    acceleration=accel0-sigma[:,None]**2*diff-force_change
    return diff,vel,acceleration

def focusing(mesh,states,order,transverse):
    end,rate,drive=states[3],states[5],states[6]
    eps=mesh.op["velocity"]*1000/constants.c
    length=mesh.op["length"]
    depths=DISTANCES/length
    breaks=np.unique(np.clip(np.r_[0.,depths,*[np.sqrt(np.maximum(0.,mesh.edge**2-impact**2)) for impact in mesh.impacts]],0.,depths[-1]))
    xs,ws=roots_legendre(order)
    half=np.diff(breaks)/2
    heights=(breaks[:-1,None]+half[:,None]*(1+xs)).ravel()
    measure=(half[:,None]*ws).ravel()
    output={}
    jetstep=1.6e-5
    for start in range(0,len(heights),40):
        guard()
        section=slice(start,start+40)
        height=heights[section]
        delay=-eps*height[:,None]
        density,current=mesh.readout(height,transverse)
        density,current=density[:,:2],current[:,:2]
        grids=height[:,None]*np.maximum(0.,1-height[:,None]/depths)
        tent=height*np.maximum(0.,np.minimum(height-depths[0],depths[2]-height))/(depths[1]-depths[0])
        weights=(np.column_stack((grids,tent))*measure[section,None]).T
        def save(name,field):
            block=eps**2*np.einsum("sn,nrh->srh",weights,field,optimize=True)
            output[name]=output.get(name,0.)+block
        def project(stencil,field):
            return np.einsum("nrm,nmh->nrh",stencil,field,optimize=True)
        save("static_density",density@end)
        save("frozen_flow",2*eps*(current@rate))
        for idx in range(3):
            diff,velocity,accel=terminal_step(delay-idx*jetstep,mesh.op["sigma"],end,rate,drive)
            time_density=project(density,diff)
            flow=2*eps*project(current,velocity)
            save("past"+str(idx),time_density+flow)
            if idx==0:
                save("time_density",time_density)
                save("flow",flow)
                save("drift",project(density,velocity)+2*eps*project(current,accel))
    for value in output.values():
        shell=np.tensordot(np.array([1.,-2.,1.])*depths/(depths[1]-depths[0]),value[:3],axes=1)
        assert np.allclose(shell,value[3],rtol=2e-10,atol=1e-30)
    fd=(3*output["past0"]-4*output["past1"]+output["past2"])/(2*jetstep)
    relative=abs(fd/output["drift"]-1)
    assert np.max(relative)<2e-5,np.max(relative)
    output["derivative_control"]=relative
    return output

