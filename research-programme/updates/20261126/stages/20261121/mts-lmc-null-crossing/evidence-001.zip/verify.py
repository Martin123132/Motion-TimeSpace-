"""Bounded one-worker replay; normal run is read-only."""
import os
for setting in ("OMP_NUM_THREADS","MKL_NUM_THREADS","OPENBLAS_NUM_THREADS","BLIS_NUM_THREADS","NUMEXPR_NUM_THREADS"):
    os.environ[setting]="1"
import csv
import io
import json
import re
import sys
import numpy as np
from scipy import constants
from controls import mesh_controls,archived_flux
from crossing import integrate,parity_test
from modes import HERE,ROOT,OLD,TAGS,sha,guard,get_op,initial
from observer import focusing,DISTANCES
from geometry import OpticalMesh

def total(data):
    return data["density_even"]+data["current_odd"]

def refinement(first,second):
    return abs(first-second)/np.maximum(abs(second),np.finfo(float).tiny)

def encode(rows):
    buff=io.StringIO(newline="")
    writer=csv.DictWriter(buff,rows[0].keys(),lineterminator="\n")
    writer.writeheader();writer.writerows(rows)
    return buff.getvalue().encode()

def case_output(case,previous):
    checks=mesh_controls()
    op=get_op(case)
    eps=float(op["velocity"]*1000/constants.c)
    origin=30*eps
    length=op["length"]*1000*constants.parsec
    units=np.array([op["velocity"]**2*1e6/(2*np.pi*constants.G*length)]*2+
                   [4*op["velocity"]**2*1e6*length/constants.c**3])[:,None]
    states=initial(op,case,origin)
    checks.update(paired_time_propagators_max_relative=parity_test(op,states,origin),archived_flux_max_relative=archived_flux(op,case))
    mesh=OpticalMesh(op)
    coarse=integrate(mesh,states,8,8)
    fine=integrate(mesh,states,12,12)
    probe=integrate(mesh,states,6,7,slow=.5)
    focal=focusing(mesh,states,12,8)
    first_focus=focusing(mesh,states,8,6)
    records=states[4]
    del mesh,states,op
    smallop=get_op(case,-64)
    smallstate=initial(smallop,case,origin,-64)
    smallmesh=OpticalMesh(smallop)
    small=integrate(smallmesh,smallstate,10,10)
    other_focus=focusing(smallmesh,smallstate,10,8)
    delta=total(fine)
    tab=[];full=[];errors=[];continuity=[]
    faster=refinement(4*total(probe),delta)
    tol=2e-5
    previous_norm=np.array([[float(previous[case,tag][key]) for tag in TAGS] for key in
                           ("inner_column_kg_m2","outer_column_kg_m2","delta_GR_seconds_inner_minus_outer")])
    normalized_time=length/(eps*constants.c)
    cal=refinement(fine["terminal"]*units,previous_norm)
    assert np.max(cal)<tol
    for hidx,tag in enumerate(TAGS):
        for basis,table in (("enriched_100",fine),("enriched_64",small)):
            conv=float(units[2,0])
            direct=table["density_second"][2,hidx]*conv
            axial=-table["current_second"][2,hidx]*conv/2
            side=table["weak_transverse"][2,hidx]*conv
            weak_net=side-axial
            actual=direct-2*axial
            continuity.append(dict(case=case,history=tag,basis=basis,second_density_seconds=direct,
                                   by_axial_transport_seconds=axial,by_radial_boundary_seconds=side,
                                   direct_net_seconds=actual,weak_net_seconds=weak_net,
                                   relative_net_defect=abs(weak_net/actual-1),pass_target=bool(abs(weak_net/actual-1)<tol)))
        for idx,channel in enumerate(("column_6_kg_m2","column_8.3_kg_m2","delay_6_minus_8.3_s")):
            def value(key):
                return float(fine[key][idx,hidx]*units[idx,0])
            corr=float(delta[idx,hidx]*units[idx,0])
            quad=refinement(total(coarse),delta)[idx,hidx]
            trunc=refinement(total(small),delta)[idx,hidx]
            second=value("density_second")+value("current_second")
            full.append(dict(case=case,history=tag,channel=channel,terminal_snapshot=value("terminal"),
                             frozen_at_mid_crossing=value("central"),density_sampling=value("density_even"),
                             longitudinal_flow_sampling=value("current_odd"),moving_minus_same_epoch_frozen=corr,
                             moving_value=value("central")+corr,second_order_prediction=second,
                             correction_fraction=corr/value("central"),relative_second_order_error=abs(second/corr-1),
                             quadrature_relative=quad,basis_comparison_relative=trunc,
                             original_basis_gate_pass=bool(trunc<tol),double_light_speed_quarter_relative=faster[idx,hidx],
                             matched_GR_same_source_minus_MTS_metric=0.))
        for sidx,label in enumerate(("20kpc","35kpc","50kpc","20_to_50_tent")):
            for ridx,impact in enumerate((6.,8.3)):
                def get(key,table=focal):
                    return float(table[key][sidx,ridx,hidx])
                static=get("static_density");density=get("time_density");flow=get("flow")
                yearly=get("drift")*(365.25*86400)/normalized_time
                quad=refinement(first_focus["static_density"]+first_focus["past0"],focal["static_density"]+focal["past0"])[sidx,ridx,hidx]
                sub=refinement(other_focus["static_density"]+other_focus["past0"],focal["static_density"]+focal["past0"])[sidx,ridx,hidx]
                sub_drift=refinement(other_focus["drift"],focal["drift"])[sidx,ridx,hidx]
                tab.append(dict(case=case,history=tag,impact_kpc=impact,source=label,snapshot_density_convergence=static,
                                density_sampling=density,instantaneous_current=get("frozen_flow"),sampled_current=flow,
                                past_cone_convergence=static+density+flow,drift_per_julian_year=yearly,
                                frozen_profile_drift_per_year=0.,backward_time_difference_relative=get("derivative_control"),
                                quadrature_relative=quad,basis_relative=sub,basis_drift_relative=sub_drift,
                                basis_gate_pass=bool(sub<tol),basis_drift_gate_pass=bool(sub_drift<tol)))
    for key,cls,fval,cval in [
            ("full_second_order_sum","full",delta,total(coarse)),("full_density_even","full",fine["density_even"],coarse["density_even"]),
            ("full_current_odd","full",fine["current_odd"],coarse["current_odd"]),
            ("focusing_lightcone_density_change","finite",focal["time_density"],first_focus["time_density"]),
            ("focusing_lightcone_flow","finite",focal["flow"],first_focus["flow"]),
            ("focusing_drift","finite",focal["drift"],first_focus["drift"])]:
        peak=float(np.max(refinement(cval,fval)))
        errors.append(dict(case=case,geometry=cls,quantity=key,largest_relative_quadrature_change=peak,
                           retained_target=tol,pass_target=peak<tol))
    checks["source_time_span_Myr"]=float(2*origin*normalized_time/(1e6*365.25*86400))
    checks["previous_raw_optical_replay_max_relative"]=float(cal.max())
    checks["maximum_quarter_scaling_relative"]=float(faster.max())
    return full,tab,records,errors,continuity,checks

def generate():
    guard()
    assert sha(OLD/"seal.json")=="ecad0985b762697f19877d8d6501a53653ea9b7287f523440fe06a1666d1b92d"
    for name,value in json.loads((OLD/"seal.json").read_bytes()).items():
        assert sha(OLD/name)==value,name
    with (OLD/"lmc-columns.csv").open(newline="") as stream:
        previous={(int(row["preparation"]),row["history"]):row for row in csv.DictReader(stream)}
    accumulated=[[],[],[],[],[]];summary={}
    for case in (0,1):
        print(f"Replaying saved preparation {case+1}/2",flush=True)
        result=case_output(case,previous)
        for dataset,rows in zip(accumulated,result[:5]):
            dataset.extend(rows)
        summary[case]=result[-1]
    return {**{name:encode(rows) for name,rows in zip(("full-paths.csv","finite-observers.csv","time-controls.csv","quadrature.csv","continuity.csv"),accumulated)},
            "checks.json":(json.dumps(summary,indent=2)+"\n").encode()}

if __name__=="__main__":
    initialize=sys.argv[1:]==["--initialize"]
    assert initialize or not sys.argv[1:]
    products=generate()
    for name,data in products.items():
        path=HERE/name
        if initialize and not path.exists():
            with path.open("xb") as out:
                out.write(data)
        assert path.read_bytes()==data,name
    docs=["RESULTS.md","DERIVATION.md"]
    for name in docs:
        for target in re.findall(r"\]\(([^)]+)\)",(HERE/name).read_text(encoding="utf8")):
            assert target.startswith("https://") or (HERE/target).is_file(),target
    names=sorted([*products,*docs,"modes.py","geometry.py","crossing.py","observer.py","controls.py","verify.py"])
    payload=(json.dumps({name:sha(HERE/name) for name in names},indent=2)+"\n").encode()
    seal=HERE/"seal.json"
    if initialize and not seal.exists():
        with seal.open("xb") as out:
            out.write(payload)
    assert seal.read_bytes()==payload
    print(f"Verified {len(names)} files; {sha(seal)}")

