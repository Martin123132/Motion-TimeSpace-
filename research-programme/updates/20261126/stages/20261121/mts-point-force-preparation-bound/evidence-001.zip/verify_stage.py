from pathlib import Path
import csv
import hashlib
import json
import sys
from sharp_certificate import calculate

HERE=Path(__file__).resolve().parent
files=('PROTOCOL.md','DERIVATION.md','RESULTS.md','bound.py','density.py','sharp_certificate.py','verify_stage.py',
    'angular.csv','gaussian.csv','sites.csv','histories.csv','hardy-approach.csv','sharp-certificate.json',
    'density-forces.csv','density-controls.csv','dephased.csv')
def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream,'sha256').hexdigest()
def read(name):
    with (HERE/name).open(newline='',encoding='utf8') as src:
        return list(csv.DictReader(src))
def verify():
    old=HERE.parent/'mts-lmc-three-lobed-response-20261121'
    assert digest(old/'seal.json')=='7583497faea8b2bb7164e6c93f259bef169fc665b32ac84ae2c6589b1a9ace5b'
    assert json.loads((HERE/'sharp-certificate.json').read_bytes())==calculate()
    history=read('histories.csv')
    sites=read('sites.csv')
    test=read('density-forces.csv')
    control=read('dephased.csv')
    measured=read('density-controls.csv')
    assert len(history)==len(measured)==12 and len(sites)==len(test)==len(control)==96
    def key(row):
        return row['case'],row['model'],float(row['R']),float(row['z']),row['component']
    index={key(row):row for row in test}
    assert len(set(map(key,control)))==len(index)==96
    for row in control:
        first=index[key(row)]
        assert (first['low'],first['high'])==(row['low'],row['high'])
        assert abs((float(row['total'])-float(first['total']))-float(row['mixture_minus_pure']))<1e-12
        assert float(row['phase_average_check'])<1e-12
    for row in history:
        case,name=row['case'],row['history']
        points=[pt for pt in sites if pt['case']==case and pt['history']==name]
        assert len(points)==8 and len({(pt['R'],pt['z'],pt['model']) for pt in points})==8
        mts=[pt for pt in points if pt['model']=='mts']
        assert len(mts)==4 and all(not pt['gradient_specific_lower'] for pt in points if pt['model']=='nfw')
        need=max(float(pt['gradient_specific_lower']) for pt in mts)
        assert need==float(row['required_specific_gradient_energy'])
        assert need/float(row['driven_specific_upper'])>29.8
        for pt in points:
            assert abs(float(pt['vector_gap'])**2-float(pt['delta_radial'])**2-float(pt['delta_polar'])**2)<1e-12
        for group in (test,control):
            group=[pt for pt in group if pt['case']==case and pt['model']==name]
            assert len(group)==8 and sum(pt['inside']=='True' for pt in group)==2
            for pt in group:
                assert (float(pt['low'])<=float(pt['total'])<=float(pt['high']))==(pt['inside']=='True')
        item,=[pt for pt in measured if pt['case']==case and pt['model']==name]
        assert float(item['actual_max_vector'])<float(row['all_direction_force_upper'])<float(row['strongest_required_force'])
    return {name:digest(HERE/name) for name in files}
if __name__=='__main__':
    receipt=verify()
    data=(json.dumps(receipt,indent=2,sort_keys=True)+'\n').encode()
    seal=HERE/'seal.json'
    if sys.argv[1:]==['--save'] and not seal.exists():
        with seal.open('xb') as stream:
            stream.write(data)
    else:
        assert seal.read_bytes()==data
    print('verified',len(receipt),'files',digest(seal))
