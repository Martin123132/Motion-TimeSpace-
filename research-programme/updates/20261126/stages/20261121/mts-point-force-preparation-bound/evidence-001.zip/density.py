from bound import *
from pulse_space import basis, angular, slope

def maps(bg,max_order):
    mu,weight=roots_legendre(96)
    mu,weight=(mu+1)/2,weight/2
    limit=2*(3+int(bg.orders[-1]))
    all_maps={}
    angular_wave={mode:basis(bg.orders+mode,mode,mu) for mode in (0,2,3)}
    for mode in range(max_order+1):
        degrees=np.arange(mode,limit+1,2)
        projection=basis(degrees,mode,mu)*weight[:,None]
        direct=[];match=[]
        for idx,cyl in enumerate((6.,8.3)):
            radius=bg.mesh.probes[idx]
            cosine=1.5/np.hypot(cyl,1.5)
            inside=bg.mesh.inner[idx]/bg.mesh.weight
            outer=1-inside
            low=inside[:,None]*np.minimum(bg.rad[:,None]/radius,1.)**degrees/radius
            high=outer[:,None]*np.minimum(radius/bg.rad[:,None],1.)**degrees/bg.rad[:,None]
            polar=np.array([slope(deg,mode,cosine) for deg in degrees])*np.sqrt(1-cosine**2)
            radial=np.array([angular(deg,mode,cosine) for deg in degrees])
            for raw in (-(low*(degrees+1)-high*degrees)*radial,-(low+high)*polar):
                kernel=raw*(bg.vel**2*UNIT/bg.length)*(1 if mode==0 else 2*(-1)**mode)/(radius*(2*degrees+1))
                direct.append(kernel@projection.T)
                match.append(kernel[:,:bg.count]@projection[:,:bg.count].T)
        all_maps[mode]=np.array(direct),np.array(match)
    return all_maps,angular_wave

def read_field(fields,kernels):
    acc=np.zeros(4)
    for mode,coef in fields.items():
        acc+=np.einsum('ika,ka->i',kernels[mode],coef.real,optimize=True)
    return acc

def run():
    guard()
    results=[];checks=[];dephased=[]; hist=rows(HERE/'histories.csv')
    original=rows(verified(QUAD,'combined-force-ledger.csv'))
    for case in (0,1):
        full=sector(case,3);bg=full.bg;op=reduced(full,128)
        matrices,harmonics=maps(bg,6)
        whole={key:val[0] for key,val in matrices.items()}
        old={key:val[1] for key,val in matrices.items()}
        with np.load(verified(QUAD,f'operators/{case}-64.npz')) as pack:
            m2block,m2waves=pack['block'],pack['waves']
        gsky=bg.ground@harmonics[0].T
        ground=read_field({0:gsky**2},whole)
        for model in MODELS:
            guard()
            summary,=[r for r in hist if int(r['case'])==case and r['history']==model]
            normalize=float(summary['mass_normalization']); gnormalize=float(summary['ground_normalization'])
            with np.load(verified(AX,f'states/{case}-{model}-k-100-r320-l40-q36-t16-v16.npz')) as saved:
                axis=saved['x']+1j*saved['y']
            with np.load(verified(QUAD,f'states/{case}-64-{model}-r192-l24-t16-d1.npz')) as saved:
                double=lift(m2block,m2waves,saved['displacement'],saved['velocity'])
            with np.load(verified(WAVE,f'fine-{case}-128-{model}.npz')) as saved:
                triple=lift(op.block,op.waves,saved['position'],saved['velocity'])
                check3=saved['meridian_complex'].real
            fields={0:axis@harmonics[0].T}
            for mode,(displacement,rate) in ((2,double),(3,triple)):
                fields[mode]=(.5*(displacement+1j*rate))@harmonics[mode].T
                fields[-mode]=(.5*(displacement.conj()+1j*rate.conj()))@harmonics[mode].T
            linear={0:2*gsky*fields[0].real}
            for mode in (2,3):
                linear[mode]=gsky*(fields[mode]+fields[-mode].conj())
            squared={mode:sum(fields[key+mode]*amp.conj() for key,amp in fields.items() if key+mode in fields) for mode in range(7)}
            full_change=normalize**2*(read_field(linear,whole)+read_field(squared,whole))+(normalize**2-gnormalize**2)*ground
            mean_change=normalize**2*read_field({0:linear[0]+squared[0]},whole)+(normalize**2-gnormalize**2)*ground
            sampled=np.zeros_like(gsky)
            for angle in 2*np.pi*np.arange(16)/16:
                sampled+=abs(gsky+sum(np.exp(1j*mode*angle)*value for mode,value in fields.items()))**2/16
            exact_mean=gsky**2+linear[0]+squared[0].real
            phase_error=np.max(abs(sampled-exact_mean))/np.max(exact_mean)
            assert phase_error<1e-12
            linear_saved=read_field(linear,old)
            linear_full=read_field(linear,whole)
            context=[r for r in original if r['tag']==TAGS[case] and r['orbit']==model and r['background']=='mts']
            errors=[]
            for idx,(rad,label) in enumerate(((6.,'radial'),(6.,'polar'),(8.3,'radial'),(8.3,'polar'))):
                north,=[r for r in context if float(r['z'])>0 and float(r['R'])==rad and r['component']==label]
                expected=sum(float(north[key]) for key in ('fixed_number_m0','lowest_m2','remaining_m2'))+check3[idx]
                errors.append(abs(linear_saved[idx]-expected))
                for row in (r for r in context if float(r['R'])==rad and r['component']==label):
                    sign=-1 if label=='polar' and float(row['z'])<0 else 1
                    base=float(row['stationary'])+float(row['direct_satellite'])
                    final=base+sign*full_change[idx];lower,upper=float(row['low']),float(row['high'])
                    results.append(dict(case=case,model=model,R=rad,z=row['z'],component=label,base=base,
                        linear_matched=sign*linear_saved[idx],linear_full=sign*linear_full[idx],finite_density_change=sign*full_change[idx],
                        density_vs_full_linear=sign*(full_change[idx]-linear_full[idx]),total=final,low=lower,high=upper,
                        inside=lower<=final<=upper,linear_inside=lower<=base+sign*linear_saved[idx]<=upper))
                    mean_total=base+sign*mean_change[idx]
                    dephased.append(dict(case=case,model=model,R=rad,z=row['z'],component=label,pure_change=sign*full_change[idx],
                        mixture_change=sign*mean_change[idx],total=mean_total,low=lower,high=upper,inside=lower<=mean_total<=upper,
                        mixture_minus_pure=mean_total-final,phase_average_check=phase_error))
            bound=float(summary['all_direction_force_upper'])
            actual=max(np.linalg.norm(full_change[:2]),np.linalg.norm(full_change[2:]))
            assert actual<bound and max(errors)<1e-8,(model,actual,bound,errors)
            checks.append(dict(case=case,model=model,matched_force_error=max(errors),actual_max_vector=actual,
                upper_bound=bound,actual_over_upper=actual/bound,linear_tail=max(abs(linear_full-linear_saved)),
                square_plus_normalization_max=max(abs(full_change-linear_full))))
        print('checked normalized densities',case,flush=True)
    assert len(results)==96 and len(checks)==12
    for name,records in [('density-forces.csv',results),('density-controls.csv',checks),('dephased.csv',dephased)]:
        data=encode(records)
        if sys.argv[1:]==['--save'] and not (HERE/name).exists():
            with (HERE/name).open('xb') as dest:
                dest.write(data)
        else:
            assert (HERE/name).read_bytes()==data
if __name__=='__main__':
    run()
