from fractions import Fraction
from pathlib import Path
import json
import sys

HERE=Path(__file__).resolve().parent
def square(degree):
    return Fraction(16*(degree+1)**2,(2*degree+1)**3*(2*degree+3)**3)

def certify(number,limit,upper):
    pivot=number
    for degree in range(limit):
        if pivot<=0:
            return False
        pivot=number-square(degree)/pivot
    if upper:
        tail=Fraction(8,(2*limit+3)*(2*limit+5))
        assert number>tail
        pivot-=square(limit)/(number-tail)
    return pivot>0

def calculate():
    lower=Fraction('0.782087227798')
    upper=Fraction('0.782087227800')
    assert not certify(lower,16,False) and certify(upper,16,True)
    return {'lower':str(lower),'upper':str(upper),'maximum_degree_in_exact_test':16,'arithmetic':'exact rational LDL and infinite-tail Schur bound',
        'lower_decimal':str(float(lower)),'upper_decimal':str(float(upper))}
if __name__=='__main__':
    receipt=calculate()
    raw=(json.dumps(receipt,indent=2,sort_keys=True)+'\n').encode()
    path=HERE/'sharp-certificate.json'
    if sys.argv[1:]==['--save'] and not path.exists():
        with path.open('xb') as stream:
            stream.write(raw)
    else:
        assert path.read_bytes()==raw
    print(receipt)
