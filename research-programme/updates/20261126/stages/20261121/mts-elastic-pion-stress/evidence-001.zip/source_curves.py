"""Retrieve versioned originals into memory; export only data knots, not papers."""
from pathlib import Path
import hashlib
import io
import tarfile

import fitz
import numpy as np
import requests

HERE = Path(__file__).resolve().parent


def download(url):
    with requests.get(url, stream=True, timeout=(8, 24)) as response:
        response.raise_for_status()
        raw = bytearray()
        for block in response.iter_content(65536):
            raw.extend(block)
            if len(raw) > 3500000:
                raise ValueError("unexpected source size")
    return bytes(raw)


def drawing(raw, digest, page):
    assert hashlib.sha256(raw).hexdigest() == digest
    with fitz.open(stream=raw, filetype="pdf") as doc:
        return doc[page].get_drawings()


def line(path):
    segments = path["items"]
    assert all(part[0] == "l" for part in segments)
    assert all(left[2] == right[1] for left, right in zip(segments, segments[1:]))
    points = np.array([segments[0][1], *[item[2] for item in segments]])
    assert np.all(np.diff(points[:, 0]) >= 0)
    return points.T


def store(name, header, values):
    data = io.StringIO()
    np.savetxt(data, values, delimiter=",", header=header, comments="", fmt="%.12g")
    result = data.getvalue().encode("ascii")
    dest = HERE / (name + ".csv")
    if dest.exists():
        assert dest.read_bytes() == result, f"source replay differs: {name}"
    else:
        dest.write_bytes(result)


def main():
    graph = drawing(download("https://arxiv.org/pdf/1404.7524v2"),
                    "181bb0619921c12105f3ec83f059375fb3d4eb1b5494f992ae652847a819cd94", 18)
    first, last = [graph[index]["items"][0][1].x for index in (34, 40)]
    zero, one = [graph[index]["items"][0][1].y for index in (42, 52)]
    assert abs((graph[38]["rect"].x0-first)/(last-first)-2/3) < .001
    assert abs((graph[48]["rect"].y0-zero)/(one-zero)-.6) < .001
    assert graph[5]["color"] == (0., 1., 0.) and graph[9]["color"] == (0., 0., 0.)
    for index, name in [(9,"dp-central"),(5,"dp-upper"),(8,"dp-lower")]:
        abscissa, ordinate = line(graph[index])
        assert len(abscissa) == 50
        store(name, "W_GeV,abs_F0_D0", np.column_stack((.3+.3*(abscissa-first)/(last-first),
                                                         (ordinate-zero)/(one-zero))))
    with tarfile.open(fileobj=io.BytesIO(download("https://arxiv.org/src/2411.13398v2"))) as archive:
        raw = archive.extractfile("fig/Omnes02_sing.pdf").read()
        space = archive.extractfile("fig/GFF_pi.pdf").read()
    graph = drawing(raw,"a60da6267ed6308d681fd45d17ac0877f6631cce429a5c1843b54480c53e9f19",0)
    first, last = [graph[index]["items"][0][1].x for index in (14, 66)]
    zero, two = [graph[index]["items"][0][1].y for index in (72, 76)]
    assert abs((graph[56]["rect"].x0-first)/(last-first)-1/3) < .0001
    assert abs((graph[80]["rect"].y0-zero)/(two-zero)-2) < .0001
    for index, name in [(1,"real"), (0,"imag")]:
        abscissa, ordinate = line(graph[index])
        assert len(abscissa) in (437,521)
        store("cao-"+name, "W_GeV,Omega_"+name, np.column_stack((.5+1.5*(abscissa-first)/(last-first),
                                                                2*(ordinate-zero)/(two-zero))))
    graph = drawing(space,"19a9e76c56876a332bf4f5824df55065b9334c45b9a705c2ab1e143f833c5cdd",0)
    first,last=[graph[index]["items"][0][1].x for index in (217,237)]
    zero,one=[graph[index]["items"][0][1].y for index in (238,258)]
    abscissa,ordinate=line(graph[181])
    assert graph[181]["color"]==(1.,0.,0.) and len(abscissa)==75
    store("cao-spacelike","minus_t_GeV2,A",np.column_stack((2*(abscissa-first)/(last-first),
                                                            (ordinate-zero)/(one-zero))))


if __name__ == "__main__":
    main()
