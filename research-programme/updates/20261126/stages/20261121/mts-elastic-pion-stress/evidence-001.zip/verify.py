"""Offline checks: no fitting, no writes unless --receipt is requested."""
import hashlib
import json
import sys

import numpy as np
from scipy.integrate import quad
from scipy.special import roots_legendre

from elastic import (DP, END, GM, HERE, KAPPA, KNOTS, MASS, TH, Reconstruction,
                     born, data, gauss, integrate, omega, rh_kernel)


def checked_inputs():
    prior=HERE.parent/"mts-transverse-scale-transfer-20261121"
    assert hashlib.sha256((prior/"seal.json").read_bytes()).hexdigest()=="8e252e9539a8c97affb746fa043b57ee2b796d88575101560cc347314e21bf69"


def local_pv(model, pole):
    index=np.searchsorted(KNOTS,pole)
    low,high=KNOTS[index-1:index+1]
    def entry(value):
        return float(rh_kernel(value,omega(value)))
    near=quad(entry,low,high,weight="cauchy",wvar=pole,epsabs=5e-13)[0]
    side=0.
    for edges in (KNOTS[:index],KNOTS[index:]):
        offsets=abs(edges-pole)
        sign=np.sign(edges[0]-pole)
        extra=pole+sign*min(offsets)*1.5**np.arange(1,np.ceil(np.log(max(offsets)/min(offsets))/np.log(1.5)))
        nodes,weights=gauss(np.unique(np.r_[edges,extra[(extra>edges[0])&(extra<edges[-1])]]),16)
        side+=weights@(rh_kernel(nodes,omega(nodes))/(nodes-pole))
    return near+side+model.tw@(model.tailkernel/(model.tail-pole))


def verify():
    checked_inputs()
    model=Reconstruction()
    archive=json.loads((HERE/"moments.json").read_text(encoding="utf8"))
    assert archive["units"]=="GeV^-2"
    output={}
    for name in ("real","imag"):
        energies,vals=data("cao-"+name)
        assert np.all(np.diff(energies)>=0) and np.isfinite(vals).all()
    grid=np.linspace(.281,.54,45)
    p2=lambda angle:(3*angle**2-1)/2
    angular=[]
    cg=[]
    gm=[]
    for energy in grid:
        vel2=1-TH/energy**2
        beta=np.sqrt(vel2)
        angular.append(abs(quad(lambda angle:p2(angle)*(1-vel2)/(1-vel2*angle**2),0,1)[0]-born(energy**2)))
        source_dp=np.sqrt(5/16)*(1-vel2)/vel2*((3-vel2)/beta*np.log((1+beta)/(1-beta))-6)
        cg.append(abs(DP*np.sqrt(2/3)*source_dp-born(energy**2)))
        source_gm=-2*MASS**2/energy**2*((1-3/vel2)*2*np.arctanh(beta)/beta+6/vel2)
        gm.append(abs(GM*(-2/np.sqrt(3))*source_gm-born(energy**2)))
    assert max(angular+cg+gm)<2e-13
    output["max_absolute_Born_error"]=max(angular+cg+gm)
    isotensor=np.array([-1/np.sqrt(3),np.sqrt(2/3)])
    assert abs(isotensor@[1.,1/np.sqrt(2)])<1e-15
    full=quad(lambda beta: beta**4*born(TH/(1-beta**2))/(2*MASS**2),0,1,epsabs=2e-12)[0]*KAPPA
    assert abs(full-KAPPA/(180*MASS**2))<2e-12
    output["point_scalar_full_GeVminus2"]=full
    errors=[]; pv_errors=[]
    for energy in (.29,.333,.389,.439,.479,.527):
        pole=energy**2
        om, base, parts=model.parts(pole)
        pv=local_pv(model,pole)
        pref=pole**2*(pole-TH)
        independent_right=pref*pole*pv/np.pi
        pv_errors.append(abs(independent_right-parts[2]))
        discontinuity=1j*pref*pole*rh_kernel(pole,om)
        source=born(pole)+om*(sum(parts[:2])+independent_right+discontinuity)
        signed,hsum,stress,_=model.read(pole)
        errors.append(abs(source-hsum))
        assert abs((source*stress.conjugate()).imag)<2e-10 and signed>0
    assert max(pv_errors)<2e-9 and max(errors)<3e-9
    wrong_pole=abs(((born(pole)+om*(sum(parts[:2])+independent_right-discontinuity))*stress.conjugate()).imag)
    assert wrong_pole>1e-5
    output.update(max_abs_alternate_pv_term_error=max(pv_errors),max_abs_complex_wave_error=max(errors),
                  wrong_pole_imaginary_product=wrong_pole)
    spaces=np.linspace(.05,2.,40)
    observed=np.interp(spaces,*data("cao-spacelike"))
    delta=(1+.01*spaces)*np.array([model.spacelike(-value) for value in spaces])/observed-1
    assert np.max(abs(delta))<.012
    output["max_relative_spacelike_stress_discrepancy"]=np.max(abs(delta))
    main=archive["windows"]["0.281000_0.540000"]
    sub=archive["windows"]
    for key,saved in main.items():
        assert abs(saved-sum(sub[idx][key] for idx in ("0.281000_0.350000","0.350000_0.450000","0.450000_0.540000")))<5e-12
    replay=integrate(model,.281,.54,10)
    assert max(abs(main[key]-replay[key]) for key in main)<2e-10
    assert archive["dp_green_covered"]==archive["dp_test_points"]
    outputs=np.genfromtxt(HERE/"products.csv",delimiter=",",names=True)
    for row in outputs:
        signed,hsum,stress,parts=model.read(row["W_GeV"]**2)
        assert abs(signed-row["product"])<1e-13 and abs(stress-row["A_real"]-1j*row["A_imag"])<1e-12
    output.update(signed_vs_modulus_ratio=main["signed"]/main["DP_magnitude"],
                  physical_over_point=main["signed"]/main["point"],
                  alternate_moment_abs_difference=abs(replay["signed"]-main["signed"]),
                  gridsize=len(outputs))
    return output


if __name__=="__main__":
    result=json.dumps(verify(),indent=2)+"\n"
    if "--receipt" in sys.argv:
        (HERE/"checks.json").write_text(result,encoding="utf8")
    print(result,end="")
