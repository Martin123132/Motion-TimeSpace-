"""Independent flat constraint response: continuum Hankel integral and same-grid wave."""
from clock_lab import HERE,PREV,WIDTH,GRID,AMP,np,put,read_parent
from mts_sbp12 import Regular
from scipy.special import roots_legendre,spherical_jn
import io


def integrals(radius,elapsed,count):
    nodes,weights=roots_legendre(count)
    nodes,weights=9*(nodes+1),9*weights
    radial=radius/WIDTH
    time=elapsed/WIDTH
    kernel=spherical_jn(2,radial[:,None]*nodes) * (weights*np.exp(-nodes**2/4))
    coeff=3/np.sqrt(np.pi)
    initial=-2*radial**4*np.exp(-radial**2)
    polar=initial+(coeff/2)*(kernel @ (nodes**2*2*np.sin(nodes*time/2)**2))
    hamiltonian=-coeff/WIDTH*(kernel @ (nodes**3*np.sin(nodes*time)))
    rate=-coeff/WIDTH**2*(kernel @ (nodes**4*np.cos(nodes*time)))
    return np.stack((polar,hamiltonian,rate))


def lattice(mesh,source_radius,step,subdivisions):
    radius,faces=mesh.r,mesh.faces
    profile=(source_radius/WIDTH)**4*np.exp(-(source_radius/WIDTH)**2)
    state=np.array([-2*profile,np.zeros_like(radius),-24*profile/radius**2])
    def rhs(fields):
        polar,ham,rate=fields
        curvature=(mesh.back(faces**2*mesh.grad(ham))-6*ham)/mesh.mass2
        return np.array([-ham/2,rate,curvature])
    fields=[state]
    increment=step/subdivisions
    for sub in range(64*subdivisions):
        first=rhs(state)
        second=rhs(state+increment*first/2)
        third=rhs(state+increment*second/2)
        fourth=rhs(state+increment*third)
        state=state+increment*(first+2*second+2*third+fourth)/6
        if (sub+1)%(16*subdivisions)==0:fields.append(state)
    return np.array(fields)


def forecast():
    with np.load(read_parent(1,0,768)) as bank:
        tick=float(bank["clock"])/768;radius=bank["r"]
    mesh=Regular(len(radius),len(radius)/GRID)
    labels=np.arange(len(radius))+.5
    np.testing.assert_array_equal(mesh.r,(mesh.faces[1:]+mesh.faces[:-1])/2)
    np.testing.assert_array_equal(radius,labels/GRID)
    region=radius<.12
    clock=np.arange(0,65,16)
    analytic=np.array([integrals(radius[region],native*tick,128) for native in clock])
    other=np.array([integrals(radius[region],native*tick,192) for native in clock])
    initial=radius[region]/WIDTH
    np.testing.assert_allclose(analytic[0,2],-24/WIDTH**2*initial**2*np.exp(-initial**2),rtol=1e-12,atol=1e-9)
    assert np.max(abs((analytic-other)*np.array([1,WIDTH,WIDTH**2])[None,:,None]))<1e-11
    values=lattice(mesh,radius,tick,4)[:,:,region]
    check=lattice(mesh,radius,tick,8)[:,:,region]
    assert np.max(abs((values-check)*np.array([1,WIDTH,WIDTH**2])[None,:,None]))<1e-8
    output=io.BytesIO()
    np.savez_compressed(output,r=radius[region],ticks=960+clock,continuum=analytic*AMP,lattice=check*AMP)
    put(HERE/"flat-forecast.npz",output.getvalue())

if __name__=="__main__":
    forecast()
