"""Diagnostics on unchanged late snapshots; no temporal interpolation or masking."""
from decimal import Decimal,localcontext
from clock_lab import HERE,PREV,code,np,old,GRID,patch,carrier,candidate,evolve8,revised,compute,parent,json
from late_score import entry,table
import importlib.util
spec=importlib.util.spec_from_file_location("formation_weak_current",PREV/"weak_current.py")
saved_weak=importlib.util.module_from_spec(spec)
spec.loader.exec_module(saved_weak)
readout,mixed,angular,geometric=(getattr(saved_weak,key) for key in ("readout","mixed","angular","geometric"))
from split_curvature import principal


def precise(mesh,chart,cell):
    num=lambda value: Decimal.from_float(float(value))
    coeff=[num(value) for value in mesh.first]
    dx=num(mesh.h)
    def radius(idx):return num(mesh.r[idx])
    def faces(idx):return num(mesh.faces[idx])
    def sample(field,idx):return num(chart[field][idx if idx>=0 else -idx-1])
    def facegrad(func,idx):
        return sum(coef*(func(idx+offset)-func(idx-1-offset)) for offset,coef in enumerate(coeff))/dx
    def back(func):
        def at(idx):return func(idx) if idx>=0 else 2*func(0)-func(-idx)
        return sum(coef*(at(cell+1+offset)-at(cell-offset)) for offset,coef in enumerate(coeff))/dx
    section=back(lambda idx:faces(idx)*sample(2,idx-1) if idx else Decimal(0))
    second=back(lambda idx:faces(idx)**6*facegrad(lambda pos:sample(0,pos),idx))
    gradtrace=back(lambda idx:facegrad(lambda pos:sample(1,pos)*radius(pos if pos>=0 else -pos-1)**2,idx))
    rad=radius(cell)
    return float(-2*(section-6*sample(3,cell))/rad**2),float(second/rad**6+(2*section-gradtrace)/rad**2)


def diagnose():
    weak=[];arith=[];transport=[]
    for flag in (0,1):
        for seed in (1,-1):
            with old.environment(GRID),patch.object(carrier,"launch",candidate),patch.object(evolve8,"revise",revised):
                model=(old.Cold if flag else old.Wave)(seed,"adm")
                radius=model.shell.r;size=radius**2
                for start,div in ([(768,1),(768,2)]+([(960,3)] if seed==1 else [])):
                    tag=code(seed,flag,start,div,0)
                    for tick in (start,1024):
                        with entry(tag,tick) as bank:
                            state=old.Difference(bank["shared"],bank["signed"]);time=float(bank["clock"])
                            current=bank["J"];residual=bank["ind_P"]
                        mapped,aux=model.mass.decode(state)
                        _,_,back,_=model.lift.physical(mapped,time)
                        metric,curvature=geometric(model,mapped,aux,time)
                        mass=np.expm1(2*(back["ell"]-back["bend"]))/size
                        kappa=-aux["kb"];dk=(aux["kb"]-aux["ka"])/size
                        parts=mixed(metric,curvature,size,mass,kappa,dk)
                        angular_part=angular(metric,parts,size,mass,(back["eg"]-back["bg"])/radius,back["bg"]/(2*radius),dk,0.,0.)
                        coefficients=[parts[0].delta,parts[1].delta,angular_part.delta,current,residual]
                        for edge in (.025,.05,.1,.3):
                            for rule in (0,8,16):
                                val=readout(radius,coefficients,edge,True,rule)
                                weak.append(dict(seed=seed,flag=flag,start=start,div=div,tick=tick,edge=edge,order=rule,**val))
                        chart=tuple(mapped[idx,1].real for idx in range(4))
                        signed=tuple(value.delta for value in chart)
                        ordinary=principal(model.lift,signed)
                        naive=[left-right for left,right in zip(principal(model.lift,tuple(value.base+value.delta for value in chart)),
                                                                 principal(model.lift,tuple(value.base for value in chart)))]
                        with localcontext() as ctx:
                            ctx.prec=60
                            for cell in (0,1,2,4,8,16):
                                high=precise(model.lift.mesh,signed,cell)
                                for idx,field in enumerate(("scalar","radial")):
                                    exact=high[idx];low=float(ordinary[idx][cell])
                                    arith.append(dict(seed=seed,flag=flag,start=start,div=div,tick=tick,cell=cell,field=field,
                                            reference=exact,binary64=low,relative_error=abs(low-exact)/abs(exact) if exact else "",
                                            naive_error=abs(naive[idx][cell]-exact)/abs(exact) if exact else ""))
                        reading=compute(model,state,time)
                        if tick==start:
                            origin=(residual-reading["P"],reading["stencil"])
                        change=residual-reading["P"]-origin[0]
                        pred=reading["stencil"]-origin[1]
                        for region,mask in (("first",radius<1/GRID),("core",radius<.3),("bulk",(radius>.6)&(radius<2.1))):
                            if tick==start:continue
                            length=np.linalg.norm(change[mask])
                            transport.append(dict(seed=seed,flag=flag,start=start,div=div,tick=tick,region=region,
                                             change_norm=length,stencil_error=np.linalg.norm((change-pred)[mask])/length if length else "",
                                             actual_first=change[mask][0],stencil_first=pred[mask][0],
                                             current_readout_difference=np.linalg.norm((reading["ind_J"]-current)[mask])/np.linalg.norm(current[mask])))
    table("integrated-momentum.csv",weak)
    table("same-input-arithmetic.csv",arith)
    table("actual-stencil-transfer.csv",transport)


if __name__=="__main__":diagnose()
