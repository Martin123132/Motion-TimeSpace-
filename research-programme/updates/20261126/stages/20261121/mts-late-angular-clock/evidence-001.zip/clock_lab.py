"""Matched finite-step and injected angular transport, never project constraints."""
import os
import sys
from pathlib import Path
from unittest.mock import patch
import json
import hashlib
import io
from time import perf_counter

for key in ("OPENBLAS_NUM_THREADS","OMP_NUM_THREADS","MKL_NUM_THREADS","NUMEXPR_NUM_THREADS","BLIS_NUM_THREADS"):
    os.environ[key] = "1"
sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
PREV = HERE.parent / "mts-formation-origin-source-20261121"
sys.path.insert(0,str(PREV))
import aperture_trial as parent
from aperture_trial import old,carrier,candidate,evolve8,revised,read_tide,compute,np

PIN = "f00c8b1a01a205ddadd650d6c225fb3ef1a2627d67934f2ec4b6688bb16d39f2"
GRID = 640
AMP = 1e-20
WIDTH = .02


def sha(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream,"sha256").hexdigest()


def guard():
    parent.guard()
    if (HERE/"STOP-REQUESTED").exists():
        raise RuntimeError("Owner hold")


def put(path,content):
    guard()
    if path.exists():
        assert path.read_bytes() == content,path
    else:
        with path.open("xb") as target:
            target.write(content)


def send(name,fields):
    put(HERE/name,(json.dumps(fields,indent=2,allow_nan=False)+"\n").encode())


def lock():
    guard()
    assert sha(PREV/"seal.json") == PIN
    files = json.loads((PREV/"seal.json").read_bytes())["files"]
    for name,digest in files.items():
        assert sha(PREV/name) == digest,name
    from later_clock import late_lock
    late_lock()
    send("inputs.json",dict(parent=PIN,files=len(files),code=sha(Path(__file__)),grid=GRID,
         tests="Both signs and matter branches: last 256 ticks native and half. Same-start short final 64 ticks on positive host: native, half, third to break the two-carrier-phase resonance. Native positive host +/- smooth angular curvature perturbations, separate from scored clocks.",
         pulse=dict(amplitude=AMP,width=WIDTH,variable="change only signed angular slot 7 by -2*A*(r/w)^4*exp(-(r/w)^2)"),
         assessment="20 ppm of absolute matched Newton tide. First-cell independent P/|J| and core/bulk are diagnostics, never masks or predictions. Check native endpoint reproducibility; no changed matter, source, foreground, grid or tolerance."))


def code(seed,flag,start,div,kick):
    return f"s{seed}-off{flag}-from{start}-d{div}-p{kick}"


def read_parent(seed,flag,tick):
    path=PREV/f"extended-g{GRID}-s{seed}-off{flag}-t{tick}.npz"
    seals=json.loads((PREV/"seal.json").read_bytes())["files"]
    assert sha(PREV/"seal.json")==PIN and seals[path.name]==sha(path)
    return path


def rawfield(model,state,clock):
    mapped,_=model.mass.decode(state)
    raw=model.lift.physical(mapped,clock)[0]
    return raw if model.shell.flag else model.to_wave(raw)


def record(model,state,clock,tag,tick):
    phys=rawfield(model,state,clock)
    extra=compute(model,state,clock)
    tides=read_tide(model,clock,phys)
    fields={key:extra[key] for key in ("J","ind_J","P","ind_P","H","ind_H","Pdot","Kwork","Hdrive","etadrive")}
    fields.update(shared=state.base,signed=state.delta,clock=clock,r=model.shell.r,p7=phys.delta[7,1].real,
                  h3=phys.delta[3,1].real)
    assert all(np.isfinite(value).all() for value in fields.values())
    assert model.mass.min_branch>0
    output=io.BytesIO()
    np.savez_compressed(output,**fields)
    name=f"{tag}-t{tick}"
    path=HERE/(name+".npz");put(path,output.getvalue())
    send(name+".json",dict(tick=tick,clock=float(clock),parent=PIN,inputs=sha(HERE/"inputs.json"),
          sha=sha(path),tides={str(width)+"-"+channel:float(value) for (width,channel),value in tides.items()}))


def march(seed,flag,start,div,kick):
    guard()
    frozen=json.loads((HERE/"inputs.json").read_bytes())
    assert frozen["code"]==sha(Path(__file__)) and frozen["parent"]==PIN
    assert seed in (-1,1) and flag in (0,1)
    assert ((start==768 and div in (1,2) and kick==0) or
            (seed==1 and start==960 and ((div in (2,3) and kick==0) or (div==1 and kick in (-1,1)))))
    tag=code(seed,flag,start,div,kick)
    path=read_parent(seed,flag,768) if start==768 else HERE/(code(seed,flag,768,1,0)+"-t960.npz")
    if start!=768:
        stamp=json.loads(path.with_suffix(".json").read_bytes())
        assert stamp["inputs"]==sha(HERE/"inputs.json") and stamp["sha"]==sha(path)
    with old.environment(GRID),patch.object(carrier,"launch",candidate),patch.object(evolve8,"revise",revised):
        model=(old.Cold if flag else old.Wave)(seed,"adm")
        step=4096*np.pi/(1024*model.shell.mu)
        advance=model.time_step(step/div)
        with np.load(path) as saved:
            assert saved["clock"] == start*step
            state=old.Difference(saved["shared"],saved["signed"])
        rind=model.shell.r/WIDTH
        if kick:
            pulse=kick*AMP*rind**4*np.exp(-rind**2)
            before=rawfield(model,state,start*step)
            state.delta[7,1]-=2*pulse
            after=rawfield(model,state,start*step)
            diff=after.delta-before.delta
            assert np.array_equal(before.base,after.base)
            assert np.linalg.norm(diff[7,1].real-pulse)<1e-8*np.linalg.norm(pulse)
            diff[7,1]=0
            assert not np.any(diff)
        now=perf_counter()
        marks=sorted({start,832,896,960,976,992,1008,1024} & set(range(start,1025)))
        record(model,state,start*step,tag,start)
        for sub in range(start*div,1024*div):
            if sub%8==0:guard()
            state=advance(sub*step/div,state)
            if (sub+1)%div==0 and (sub+1)//div in marks:
                tick=(sub+1)//div
                record(model,state,tick*step,tag,tick)
                print(tag,tick,round(perf_counter()-now,1),flush=True)
        if not flag:assert model.min_number>0 and model.min_factor>0
        if start==768 and div==1:
            with np.load(read_parent(seed,flag,1024)) as saved:
                assert np.array_equal(state.base,saved["shared"]) and np.array_equal(state.delta,saved["signed"]),tag
        send(tag+"-end.json",dict(inputs=sha(HERE/"inputs.json"),tag=tag,marks=marks,source=sha(path),final_tick=1024))

if __name__=="__main__":
    if sys.argv[1:]==["freeze"]:lock()
    else:march(*map(int,sys.argv[1:]))
