"""Propagate the eight flat angular metric slots to predict the second readout."""
import io
from clock_lab import HERE,np,old,GRID,patch,carrier,candidate,evolve8,revised,AMP,WIDTH,code,put
from split_curvature import principal
from late_score import entry,table


def transfer(model,step,subdivision,initial=None):
    lift=model.lift;mesh=lift.mesh
    radius=mesh.r;faces=mesh.faces
    if initial is None:
        state=np.zeros((8,len(radius)))
        state[7]=-2*(model.shell.r/WIDTH)**4*np.exp(-(model.shell.r/WIDTH)**2)
    else:
        state=initial.copy()
    def rhs(now):
        ell,trace,mass,beta,extr,shear,pi,tau=now
        ham,radial=principal(lift,(ell,trace,mass,beta))
        return np.array([-extr/3-shear,-extr,pi,tau,ham,-radial-ham/3,-(faces*mesh.grad(ham))[1:]/2,-ham/2])
    def observation(now):
        extr,shear,pi,tau=now[4:]
        velocity=(mesh.full(pi)-2*faces*mesh.grad(-extr/3+shear/2)-3*mesh.face(shear))/3
        collocated=tau-radius*(model.shell.diff(mesh.centre(velocity))-mesh.even_back(velocity))/2
        return np.stack((tau,collocated,principal(lift,now[:4])[0]))[:,:np.sum(radius<.12)]
    rows=[observation(state)]
    dt=step/subdivision
    for sub in range(64*subdivision):
        first=rhs(state);second=rhs(state+dt*first/2)
        third=rhs(state+dt*second/2);fourth=rhs(state+dt*third)
        state=state+dt*(first+2*second+2*third+fourth)/6
        if (sub+1)%(16*subdivision)==0:rows.append(observation(state))
    return np.array(rows)


def run():
    with old.environment(GRID),patch.object(carrier,"launch",candidate),patch.object(evolve8,"revise",revised):
        model=old.Cold(1,"adm")
        dt=4096*np.pi/(model.shell.mu*1024)
        high=transfer(model,dt,8)*AMP;low=transfer(model,dt,4)*AMP
    with np.load(HERE/"flat-forecast.npz") as flat:
        forecast=flat["lattice"];radius=flat["r"];ticks=flat["ticks"]
    scale=np.array([1,1,WIDTH])[None,:,None]/AMP
    assert np.max(abs((high-low)*scale))<1e-7
    assert np.max(abs(high[:,0]-forecast[:,0]))<1e-8*AMP
    assert np.max(abs(high[:,2]-forecast[:,1]))<1e-7*AMP/WIDTH
    output=io.BytesIO();np.savez_compressed(output,predicted=high,r=radius,ticks=ticks)
    put(HERE/"flat-angular-forecast.npz",output.getvalue())
    rows=[]
    for flag in (0,1):
        for idx,tick in enumerate(ticks):
            with entry(code(1,flag,960,1,1),tick) as plus,entry(code(1,flag,960,1,-1),tick) as minus:
                read=lambda field:(plus[field][:len(radius)]-minus[field][:len(radius)])/2
                for key,pred,actual in (("ind_P",high[idx,1],read("ind_P")),
                                        ("readout-minus-native",high[idx,1]-high[idx,0],read("ind_P")-read("P"))):
                    for region,mask in (("first",radius<1/GRID),("pulse",radius<.1)):
                        norm=np.linalg.norm(actual[mask])
                        rows.append(dict(flag=flag,tick=tick,field=key,region=region,
                             observed_first=actual[mask][0],predicted_first=pred[mask][0],
                             residual_over_observed=np.linalg.norm((pred-actual)[mask])/norm if norm else "",
                             max_residual_over_launch=np.max(np.abs((pred-actual)[mask]))/AMP))
    table("pulse-stencil-prediction.csv",rows)

if __name__=="__main__":run()
