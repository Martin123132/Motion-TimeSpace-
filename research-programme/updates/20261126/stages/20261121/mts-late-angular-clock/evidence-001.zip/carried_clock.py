"""Forecast the transport of the *actual* pre-existing time-discretization difference."""
from angular_symbol import transfer
from clock_lab import HERE,old,GRID,patch,carrier,candidate,evolve8,revised,np,code,put
from late_score import entry,table
import io


def run():
    rows=[];attribution=[];profiles={}
    for flag in (0,1):
        group=code(1,flag,768,2,0)
        short=code(1,flag,960,2,0)
        native=code(1,flag,768,1,0)
        with entry(group,960) as fine,entry(short,960) as coarse:
            initial=(fine["signed"][:8,1]-coarse["signed"][:8,1]).real
            radius=fine["r"];radius=radius[radius<.12]
        with old.environment(GRID),patch.object(carrier,"launch",candidate),patch.object(evolve8,"revise",revised):
            model=(old.Cold if flag else old.Wave)(1,"adm")
            step=4096*np.pi/(1024*model.shell.mu)
            allslots=transfer(model,step,2,initial)
            continuous=transfer(model,step,8,initial)
            tensor=np.zeros_like(initial)
            tensor[0]=initial[0];tensor[5]=initial[5]+initial[4]/3
            shear=transfer(model,step,2,tensor)
        profiles[f"b{flag}_all"]=allslots;profiles[f"b{flag}_tensor"]=shear
        profiles[f"b{flag}_refined"]=continuous
        real=[]
        for index,tick in enumerate((960,976,992,1008,1024)):
            with entry(group,tick) as full,entry(short,tick) as last,entry(native,tick) as coarse:
                def delta(key):return full[key][:len(radius)]-last[key][:len(radius)]
                def geom(key,current):return delta(key)+delta(current)
                measured=np.stack((geom("P","J"),geom("ind_P","ind_J"),delta("H")))
                real.append(measured)
                for key in ("P","ind_P","J","ind_J","h3","p7"):
                    seeded=delta(key)
                    local=(last[key]-coarse[key])[:len(radius)]
                    total=(full[key]-coarse[key])[:len(radius)]
                    np.testing.assert_allclose(seeded+local,total,rtol=1e-13,atol=1e-40)
                    for region,mask in (("first",radius<1/GRID),("inner",radius<.1)):
                        norm=np.linalg.norm(total[mask])
                        attribution.append(dict(flag=flag,tick=tick,field=key,region=region,
                                     earlier=seeded[mask][0],late=local[mask][0],total=total[mask][0],
                                     earlier_norm_ratio=np.linalg.norm(seeded[mask])/norm if norm else "",
                                     late_norm_ratio=np.linalg.norm(local[mask])/norm if norm else ""))
                for which,key in enumerate(("encoded_geom","independent_geom","hamiltonian")):
                    for region,mask in (("first",radius<1/GRID),("inner",radius<.1)):
                        obs=measured[which,mask];flat=allslots[index,which,mask];tensor=shear[index,which,mask]
                        diff_refined=(continuous[index,which,mask]-flat)
                        norm=np.linalg.norm(obs)
                        rows.append(dict(flag=flag,tick=tick,field=key,region=region,observed_first=obs[0],
                                 flat_first=flat[0],tensor_first=tensor[0],driven_first=(flat-tensor)[0],
                                 observed_norm=norm,flat_error=np.linalg.norm(flat-obs)/norm if norm else "",
                                 tensor_only_error=np.linalg.norm(tensor-obs)/norm if norm else "",
                                 clock_refinement_over_observed=np.linalg.norm(diff_refined)/norm if norm else ""))
        profiles[f"b{flag}_curved"]=np.array(real)
    table("carried-angular-mode.csv",rows)
    table("early-late-clock-split.csv",attribution)
    output=io.BytesIO()
    np.savez_compressed(output,r=radius,**profiles)
    put(HERE/"carried-profiles.npz",output.getvalue())

if __name__=="__main__":run()
