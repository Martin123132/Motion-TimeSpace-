"""Interior generator of the source-free angular shear and first-cell concentration."""
from clock_lab import HERE,GRID,old,carrier,candidate,evolve8,revised,patch,np,code
from late_score import table,entry
from scipy.linalg import eigh


def test():
    rows=[];samples=[]
    with old.environment(GRID),patch.object(carrier,"launch",candidate),patch.object(evolve8,"revise",revised):
        model=old.Cold(1,"adm")
        mesh=model.lift.mesh;radius=mesh.r;faces=mesh.faces
        step=4096*np.pi/(model.shell.mu*1024)
        for size in (32,64,96):
            cols=np.eye(size)
            grad=np.stack([mesh.grad(np.pad(col/radius[:size]**3,(0,len(radius)-size))) for col in cols],axis=1)
            transformed=faces[:,None]**3*grad
            stiff=transformed.T@transformed
            applied=np.stack([-mesh.back(faces**6*grad[:,idx])[:size]/radius[:size]**3 for idx in range(size)],axis=1)
            assert np.linalg.norm(stiff-applied)<1e-12*np.linalg.norm(stiff)
            values,vectors=eigh(stiff)
            assert values[0]>0
            freq=np.sqrt(values[-1]);vec=vectors[:,-1]
            point=vec/radius[:size]**3
            threshold=np.searchsorted(np.cumsum(vec**2),.99)+1
            for div in (1,2,3):
                angle=1j*freq*step/div
                gain=abs(1+angle+angle**2/2+angle**3/6+angle**4/24)
                rows.append(dict(support_cells=size,div=div,omega_h=freq/GRID,phase_per_substep=abs(angle),
                                 gain_per_native=gain**div,stable_shear_CFL=abs(angle)<np.sqrt(8),weighted_99percent_cells=threshold))
            if size!=96:continue
            for flag in (0,1):
                for name,first,second in (("prior-clock-difference",(768,2,0),(960,2,0)),("antisymmetric-pulse",(960,1,1),(960,1,-1))):
                    factor=1 if name.startswith("prior") else .5
                    for tick in (960,976,992,1008,1024):
                        with entry(code(1,flag,*first),tick) as left,entry(code(1,flag,*second),tick) as right:
                            change=factor*(left["signed"][:8,1,:size]-right["signed"][:8,1,:size]).real
                            value=change[0]
                            speed=-change[4]/3-change[5]
                            moment=np.dot(vec,radius[:size]**3*value)
                            rate=np.dot(vec,radius[:size]**3*speed)
                            samples.append(dict(flag=flag,series=name,tick=tick,
                                 actual_first=value[0],top_shear_first=point[0]*moment,
                                 actual_velocity_first=speed[0],top_velocity_first=point[0]*rate,
                                 modal_norm=np.hypot(moment,rate/freq)))
    table("shear-spectrum.csv",rows)
    table("highest-shear-projection.csv",samples)

if __name__=="__main__":test()
