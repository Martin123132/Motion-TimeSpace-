"""Same-launch zero-pulse restart and frozen-chart superposition check."""
from clock_lab import HERE,old,carrier,candidate,evolve8,revised,patch,np,code,GRID,guard,compute,send,sha
from late_score import entry,table
import sys


def check(flag):
    tag=code(1,flag,768,1,0)
    rows=[];exact=[]
    with old.environment(GRID),patch.object(carrier,"launch",candidate),patch.object(evolve8,"revise",revised):
        model=(old.Cold if flag else old.Wave)(1,"adm")
        step=4096*np.pi/(1024*model.shell.mu);advance=model.time_step(step)
        with entry(tag,960) as anchor:
            state=old.Difference(anchor["shared"],anchor["signed"])
        for tick in range(960,1025):
            if tick>960:state=advance((tick-1)*step,state)
            if tick%8==0:guard()
            if tick%16:continue
            with entry(tag,tick) as ref,entry(code(1,flag,960,1,1),tick) as plus,entry(code(1,flag,960,1,-1),tick) as minus:
                assert np.array_equal(state.base,ref["shared"]) and np.array_equal(state.delta,ref["signed"])
                exact.append(int(tick))
                assert np.array_equal(plus["shared"],state.base) and np.array_equal(minus["shared"],state.base)
                assert np.array_equal(plus["signed"][:,0],state.delta[:,0]) and np.array_equal(minus["signed"][:,0],state.delta[:,0])
                mean_shift=((plus["signed"]-state.delta)+(minus["signed"]-state.delta))/2
                midpoint=old.Difference(state.base.copy(),state.delta+mean_shift)
                middle=compute(model,midpoint,tick*step)
                for key in ("ind_P","P","ind_H","H","ind_J","J"):
                    total=((plus[key]-ref[key])+(minus[key]-ref[key]))/2
                    transported=middle[key]-ref[key]
                    local=total-transported
                    odd=(plus[key]-minus[key])/2
                    radius=ref["r"]
                    for region,mask in (("first",radius<1/GRID),("pulse",radius<.1)):
                        norm=np.linalg.norm(total[mask])
                        oddnorm=np.linalg.norm(odd[mask])
                        rows.append(dict(flag=flag,tick=tick,region=region,key=key,total_even_first=total[mask][0],
                                         from_state_first=transported[mask][0],from_readout_first=local[mask][0],
                                         readout_norm_over_even=np.linalg.norm(local[mask])/norm if norm else "",
                                         even_over_odd=norm/oddnorm if oddnorm else ""))
    assert exact==[960,976,992,1008,1024]
    table(f"symmetry-control-off{flag}.csv",rows)
    send(f"restart-control-off{flag}.json",dict(flag=flag,ticks=exact,shared_and_signed_bitwise=True,
         input=sha(HERE/(tag+"-t960.npz")),shared_and_monopole_identical_for_both_pulses=True))

if __name__=="__main__":check(int(sys.argv[1]))
