from late_score import entry,table
from clock_lab import np,code
from scipy.optimize import brentq


def test():
    rows=[]
    for flag in (0,1):
        for tick in (976,992,1008,1024):
            with entry(code(1,flag,768,1,0),tick) as coarse,entry(code(1,flag,960,2,0),tick) as middle,entry(code(1,flag,960,3,0),tick) as fine:
                radius=fine["r"]
                for key in ("ind_P","P","ind_H","H","J","p7","h3"):
                    for region,mask in (("first",radius<1/640),("core",radius<.3),("bulk",(radius>.6)&(radius<2.1))):
                        first=(coarse[key]-middle[key])[mask];second=(middle[key]-fine[key])[mask]
                        high=np.linalg.norm(first);low=np.linalg.norm(second)
                        cosine=np.dot(first,second)/(high*low) if high*low else 0.
                        ratio=high/low if low else None
                        fn=lambda power:np.expm1(np.log(2)*power)/(-np.expm1(-np.log(1.5)*power))
                        order=brentq(lambda power:fn(power)-ratio,1e-5,10) if (ratio and fn(1e-5)<ratio<fn(10) and cosine>.95) else ""
                        rows.append(dict(flag=flag,tick=tick,key=key,region=region,coarse_to_mid=high,
                                         mid_to_fine=low,ratio=ratio if ratio is not None else "",cosine=cosine,
                                         apparent_order=order,fine_norm=np.linalg.norm(fine[key][mask])))
    table("same-start-three-clocks.csv",rows)

if __name__=="__main__":test()
