from clock_lab import HERE,PREV,PIN,sha,np,json,code,send,guard
import csv
import sys


def verify():
    guard()
    assert sha(PREV/"seal.json")==PIN
    inputs=sha(HERE/"inputs.json")
    assert json.loads((HERE/"inputs.json").read_bytes())["code"]==sha(HERE/"clock_lab.py")
    parent=json.loads((PREV/"seal.json").read_bytes())["files"]
    for name,digest in parent.items():assert sha(PREV/name)==digest,name
    expected=set()
    full=0
    for seed in (1,-1):
        for flag in (0,1):
            configs=[(768,1,0),(768,2,0)]+([(960,2,0),(960,3,0),(960,1,1),(960,1,-1)] if seed==1 else [])
            for start,div,kick in configs:
                tag=code(seed,flag,start,div,kick);expected.add(tag)
                meta=json.loads((HERE/(tag+"-end.json")).read_bytes())
                assert meta["inputs"]==inputs and meta["final_tick"]==1024 and meta["tag"]==tag
                ticks=[tick for tick in (768,832,896,960,976,992,1008,1024) if tick>=start]
                assert meta["marks"]==ticks
                source=(parent[f"extended-g640-s{seed}-off{flag}-t768.npz"] if start==768 else
                        sha(HERE/(code(seed,flag,768,1,0)+"-t960.npz")))
                assert meta["source"]==source
                for tick in ticks:
                    path=HERE/f"{tag}-t{tick}.npz";snap=json.loads(path.with_suffix(".json").read_bytes())
                    assert snap["inputs"]==inputs and sha(path)==snap["sha"]
                    with np.load(path,allow_pickle=False) as bank:
                        assert float(bank["clock"])==snap["clock"] and tick==snap["tick"]
                        assert set(snap["tides"])=={"0.3-gauss","0.3-ricci","0.15-gauss","0.15-ricci"}
                        assert all(np.isfinite(value) for value in snap["tides"].values()) and all(np.isfinite(bank[key]).all() for key in bank.files)
                        if tick==1024 and start==768 and div==1:
                            with np.load(PREV/f"extended-g640-s{seed}-off{flag}-t1024.npz") as old:
                                for key in ("shared","signed"):assert np.array_equal(bank[key],old[key])
                    full+=1
    assert len(expected)==16 and len(list(HERE.glob("*-end.json")))==16 and full==104
    assert len(list(HERE.glob("*-t*.npz")))==full
    counts={}
    for path in HERE.glob("*.csv"):
        with path.open(encoding="utf-8",newline="") as source:
            rows=list(csv.DictReader(source))
        assert rows and all(None not in row and None not in row.values() for row in rows)
        counts[path.name]=len(rows)
    assert counts=={"angular-transfer.csv":80,"integrated-momentum.csv":240,"same-input-arithmetic.csv":240,
                    "actual-stencil-transfer.csv":30,"step-differences.csv":320,"proper-tides.csv":24,"momentum.csv":504,
                    "same-start-three-clocks.csv":168,"pulse-stencil-prediction.csv":40,
                    "carried-angular-mode.csv":60,"early-late-clock-split.csv":120,
                    "shear-spectrum.csv":9,"highest-shear-projection.csv":20,
                    "symmetry-control-off0.csv":60,"symmetry-control-off1.csv":60},counts
    for flag in (0,1):
        replay=json.loads((HERE/f"restart-control-off{flag}.json").read_bytes())
        assert replay["ticks"]==[960,976,992,1008,1024] and replay["shared_and_signed_bitwise"]
        assert replay["shared_and_monopole_identical_for_both_pulses"] and replay["input"]==sha(HERE/(code(1,flag,768,1,0)+"-t960.npz"))
        with (HERE/f"symmetry-control-off{flag}.csv").open(newline="") as src:
            symmetry={(row["tick"],row["key"]):float(row["total_even_first"]) for row in csv.DictReader(src) if row["region"]=="first"}
        with (HERE/"angular-transfer.csv").open(newline="") as src:
            for row in csv.DictReader(src):
                if row["region"]=="first" and int(row["flag"])==flag:
                    assert float(row["even_norm"])==abs(symmetry[row["tick"],row["key"]])
    for path in HERE.glob("*.py"):compile(path.read_text(encoding="utf-8"),str(path),"exec")
    files={path.name:sha(path) for path in sorted(HERE.iterdir()) if path.is_file() and path.name!="seal.json"}
    assert len(files)==len(list(HERE.iterdir()))-int((HERE/"seal.json").exists())
    assert "RESULTS.md" in files and "DERIVATION.md" in files
    value=dict(parent=PIN,inputs=inputs,runs=len(expected),snapshots=full,csv_counts=counts,files=files)
    if sys.argv[1:]==["--seal"]:send("seal.json",value)
    else:assert json.loads((HERE/"seal.json").read_bytes())==value
    print(sha(HERE/"seal.json"),len(files),full,sum(counts.values()))

if __name__=="__main__":verify()
