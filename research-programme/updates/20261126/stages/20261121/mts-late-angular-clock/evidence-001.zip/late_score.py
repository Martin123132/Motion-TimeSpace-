"""Score the unchanged predictions on the late angular clock."""
import csv
import io
from clock_lab import HERE,PREV,AMP,WIDTH,np,json,sha,put,code,PIN
from flat_pulse import forecast


def table(name,rows):
    buf=io.StringIO(newline="")
    writer=csv.DictWriter(buf,rows[0].keys(),lineterminator="\n")
    writer.writeheader()
    writer.writerows(rows)
    put(HERE/name,buf.getvalue().encode())


def sheet(tag,tick):
    path=HERE/f"{tag}-t{tick}.json"
    data=json.loads(path.read_bytes())
    assert data["parent"]==PIN and data["inputs"]==sha(HERE/"inputs.json")
    assert data["sha"]==sha(path.with_suffix(".npz"))
    return data


def entry(tag,tick):
    sheet(tag,tick)
    return np.load(HERE/f"{tag}-t{tick}.npz")


def checks():
    forecast()
    with (PREV/"matched-gravity-prediction.csv").open(newline="") as file:
        predictions={(int(row["seed"]),float(row["width"])):row for row in csv.DictReader(file) if float(row["fraction"])==1}
    measures=[];tides=[];timing=[]
    for seed in (1,-1):
        families=[(768,1),(768,2)]+([(960,2),(960,3)] if seed==1 else [])
        for start,div in families:
            clocks={}
            for flag in (0,1):
                tag=code(seed,flag,start,div,0)
                end=json.loads((HERE/(tag+"-end.json")).read_bytes())
                for tick in end["marks"]:
                    with entry(tag,tick) as bank:
                        radius=bank["r"]
                        for region,mask in (("first",radius<1/640),("core",radius<.3),("bulk",(radius>.6)&(radius<2.1))):
                            current=np.linalg.norm(bank["J"][mask])
                            for key in ("ind_P","P"):
                                field=bank[key][mask]
                                measures.append(dict(seed=seed,flag=flag,start=start,div=div,tick=tick,region=region,field=key,
                                    ratio=np.linalg.norm(field)/current,signed_first=field[0],J_first=bank["J"][mask][0]))
                clocks[flag]=sheet(tag,1024)["tides"]
            for width in (.15,.3):
                ref=predictions[seed,width]
                for channel in ("gauss","ricci"):
                    key=f"{width}-{channel}"
                    signal=clocks[0][key]-clocks[1][key]
                    ppm=(signal-float(ref["matched"]))/(1e-6*abs(float(ref["matched_newton"])))
                    tides.append(dict(seed=seed,start=start,div=div,width=width,channel=channel,wave=clocks[0][key],
                                      cold=clocks[1][key],signal=signal,ref=ref["matched"],ppm=ppm,inside=abs(ppm)<=20))
        for flag in (0,1):
            for start,div1,div2,base in [(768,1,2,768)]+([(960,1,2,768),(960,2,3,960)] if seed==1 else []):
                for tick in (976,992,1008,1024):
                    with entry(code(seed,flag,base,div1,0),tick) as low,entry(code(seed,flag,start,div2,0),tick) as high:
                        for key in ("ind_P","P","J","h3","p7"):
                            radius=low["r"]
                            for region,mask in (("first",radius<1/640),("core",radius<.3)):
                                left=low[key][mask];right=high[key][mask]
                                timing.append(dict(seed=seed,flag=flag,start=start,tick=tick,div1=div1,div2=div2,field=key,
                                    region=region,difference=np.linalg.norm(right-left),relative_to_finer=np.linalg.norm(right-left)/np.linalg.norm(right),
                                    change_first=right[0]-left[0]))
    assert len(tides)==24
    table("proper-tides.csv",tides)
    table("momentum.csv",measures)
    table("step-differences.csv",timing)


def pulse():
    records=[]
    with np.load(HERE/"flat-forecast.npz") as pred:
        grid=pred["r"]
        for flag in (0,1):
            for index,tick in enumerate(pred["ticks"]):
                with entry(code(1,flag,960,1,1),tick) as plus,entry(code(1,flag,960,1,-1),tick) as minus,entry(code(1,flag,768,1,0),tick) as ctrl:
                    np.testing.assert_array_equal(ctrl["r"][:len(grid)],grid)
                    if tick==960:
                        assert np.array_equal(plus["J"],ctrl["J"]) and np.array_equal(minus["J"],ctrl["J"])
                    for key,column in (("P",0),("ind_P",0),("H",1),("ind_H",1)):
                        odd=(plus[key]-minus[key])[:len(grid)]/2
                        even=((plus[key]-ctrl[key])+(minus[key]-ctrl[key]))[:len(grid)]/2
                        for region,mask in (("first",grid<1/640),("pulse",grid<.1)):
                            observed=odd[mask]
                            ref=pred["continuum"][index,column,mask]
                            lattice=pred["lattice"][index,column,mask]
                            common=AMP if column==0 else AMP/WIDTH
                            denom=np.linalg.norm(ref)
                            row=dict(flag=flag,tick=tick,key=key,region=region,raw=observed[0],flat=ref[0],
                                grid_flat=lattice[0],odd_norm=np.linalg.norm(observed),even_norm=np.linalg.norm(even[mask]),
                                max_error_in_launch_units=np.max(abs(observed-ref))/common,
                                residual_over_flat=np.linalg.norm(observed-ref)/denom if denom else "",
                                residual_over_grid=np.linalg.norm(observed-lattice)/np.linalg.norm(lattice) if np.any(lattice) else "",
                                grid_vs_continuum=np.linalg.norm(lattice-ref)/denom if denom else "")
                            records.append(row)
                    if tick==960:
                        expected=-2*AMP*(grid/WIDTH)**4*np.exp(-(grid/WIDTH)**2)
                        for key in ("P","ind_P"):
                            diff=(plus[key]-minus[key])[:len(grid)]/2
                            assert np.linalg.norm(diff-expected)<1e-8*np.linalg.norm(expected),key
    table("angular-transfer.csv",records)


if __name__=="__main__":
    checks()
    pulse()
