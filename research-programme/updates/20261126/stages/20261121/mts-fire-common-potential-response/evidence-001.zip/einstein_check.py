"""Independent symbolic Ricci and heavy-carrier checks. No galaxy fit or import of numerical shell formula."""
from pathlib import Path
from functools import lru_cache
import json
import sys
import sympy as sym

HERE=Path(__file__).resolve().parent
def calculate(spherical):
    tim,first,second,third=sym.symbols('t x y z',real=True)
    coords=(tim,first,second,third)
    args=coords[:2] if spherical else coords
    spatial=sym.Function('lambda')(*args);lapse=sym.Function('nu')(*args)
    factors=(1,1,first**2,first**2*sym.sin(second)**2) if spherical else (1,1,1,1)
    metric=[-sym.exp(2*lapse)]+[factors[index]*sym.exp(2*spatial) for index in (1,2,3)]
    @lru_cache(None)
    def gamma(up,left,right):
        numer=0
        if up==left:numer+=sym.diff(metric[up],coords[right])
        if up==right:numer+=sym.diff(metric[up],coords[left])
        if left==right:numer-=sym.diff(metric[left],coords[up])
        return sym.simplify(numer/(2*metric[up]))
    def ricci(left,right):
        return sum(sym.diff(gamma(index,left,right),coords[index])-sym.diff(gamma(index,left,index),coords[right])+
            sum(gamma(index,left,right)*gamma(other,index,other)-gamma(other,left,index)*gamma(index,right,other)
                for other in range(4)) for index in range(4))
    if spherical:
        exact=ricci(1,1)-ricci(2,2)/first**2
        total=spatial+lapse;dsp=sym.diff(spatial,first);dlap=sym.diff(lapse,first)
        expected=-sym.diff(total,first,2)+sym.diff(total,first)/first+dsp**2-dlap**2+2*dsp*dlap
        assert sym.simplify(exact-expected)==0
        mass=sym.symbols('mass',positive=True);q=mass/(2*first)
        reduced=expected.subs({spatial:2*sym.log(1+q),lapse:sym.log((1-q)/(1+q))}).doit()
        assert sym.simplify(reduced)==0
        assert sym.series(-sym.log(1-q*q),mass,0,4).removeO()==q*q
        return ['time_dependent_spherical_tracefree_equation','exact_isotropic_Schwarzschild_vacuum','log_potential_vacuum_coefficient']
    def predicted(left,right):
        return (-sym.diff(lapse+spatial,left,right)+sym.diff(spatial,left)*sym.diff(spatial,right)
                -sym.diff(lapse,left)*sym.diff(lapse,right)+sym.diff(lapse,left)*sym.diff(spatial,right)
                +sym.diff(lapse,right)*sym.diff(spatial,left))
    assert sym.simplify(ricci(1,2)-predicted(first,second))==0
    assert sym.simplify(ricci(1,1)-ricci(2,2)-predicted(first,first)+predicted(second,second))==0
    potential=sym.Function('U')(*coords)
    geometric=predicted(first,second).subs({spatial:-potential,lapse:potential}).doit()
    assert sym.simplify(geometric+2*sym.diff(potential,first)*sym.diff(potential,second))==0
    return ['cartesian_offdiagonal','cartesian_diagonal_difference','quadratic_gradient_coefficient']

def carrier():
    phase,mass=sym.symbols('phase mass',positive=True)
    real,imag,left_r,left_i,right_r,right_i=sym.symbols('a b p q h j',real=True)
    def field(a,b):return sym.sqrt(2)*(a*sym.cos(phase)+b*sym.sin(phase))/mass
    def avg(expr):return sym.integrate(expr,(phase,0,2*sym.pi))/(2*sym.pi)
    value=field(real,imag);dot=mass*sym.diff(value,phase)
    assert sym.simplify(avg((dot**2+(mass*value)**2)/2)-real**2-imag**2)==0
    assert sym.simplify(avg(field(left_r,left_i)*field(right_r,right_i))-(left_r*right_r+left_i*right_i)/mass**2)==0
    return ['real_carrier_rest_normalization','real_carrier_tracefree_gradient_coefficient']
if __name__=='__main__':
    assert sys.argv[1:] in ([],['--save'])
    checks=calculate(False)+calculate(True)+carrier()
    data=(json.dumps(dict(exact_checks=checks),indent=2,sort_keys=True)+'\n').encode();path=HERE/'einstein-identities.json'
    if sys.argv[1:] and not path.exists():
        with path.open('xb') as output:output.write(data)
    else:assert path.read_bytes()==data
    print('verified',len(checks),'exact identities')
