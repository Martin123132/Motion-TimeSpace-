"""Separate the force of the retarded density into ordinary Newton multipoles."""
from counterflow_control_io import *
from scipy.constants import parsec
from scipy.special import roots_legendre
from numpy.polynomial.legendre import legvander,legval,legder
from measure import shape

def calculate(save):
    rows=[]
    for steps in STEPS:
        run=Run(steps);el=run.el;bg=run.obj.bg
        with np.load(HERE/f'tested-fields-{steps}.npz') as packet:
            mean=el.nodes((packet['exact_+1.0']+packet['passive'])/2)
            perturbations=[el.nodes(packet[k]) for k in ('retarded_monopole','retarded_angular')]
        degrees=np.arange(0,2*max(bg.orders)+1,2)
        mu,wa=roots_legendre(80);polys=legvander(mu,degrees[-1])
        wave=(polys[:,bg.orders]*np.sqrt(2*bg.orders+1)).T
        projection=polys[:,degrees]*wa[:,None]/2
        coefficients=np.eye(degrees[-1]+1)[:,degrees]
        sample,weights=roots_legendre(30)
        checkrows=records(HERE/f'retarded-{steps}.csv')
        for radius in (6.,8.3):
            target=np.hypot(radius,1.5)/bg.length;cosine=1.5/np.hypot(radius,1.5)
            radial=legval(cosine,coefficients);angular=-np.sqrt(1-cosine**2)*legval(cosine,legder(coefficients))
            site='inner' if radius==6. else 'outer';sources={}
            for inside in (True,False):
                lo=el.left if inside else np.maximum(target,el.left)
                hi=np.minimum(el.right,target) if inside else el.right
                idx=np.flatnonzero(hi>lo)
                grid=lo[idx,None]+(hi-lo)[idx,None]*(sample+1)/2
                interpol=shape(el.knots,(grid-el.left[idx,None])/el.width[idx,None])[0]
                base=(interpol@mean[idx])@wave
                newton=(grid[:,:,None]/target)**degrees/target if inside else (target/grid[:,:,None])**degrees/grid[:,:,None]
                kernel=(hi-lo)[idx,None,None]*weights[None,:,None]/2*newton/target*(bg.vel**2*(1e13/parsec)/bg.length)
                for name,part in zip(('monopole_drive','angular_drive'),perturbations,strict=True):
                    change=2*(base.conj()*((interpol@part[idx])@wave)).real
                    integrals=np.sum(kernel*(change@projection),axis=(0,1))
                    components=[integrals*radial*(-degrees-1 if inside else degrees),integrals*angular]
                    for label,values in zip(('radial','polar'),components,strict=True):
                        sources[name,label]=sources.get((name,label),0.)+values.sum()
                        for ell,value in zip(degrees,values,strict=True):
                            rows.append(dict(steps=steps,R=radius,component=label,source=name,side='inner' if inside else 'outer',
                                             density_degree=ell,force_contribution=value))
                            if ell==0 and (label=='polar' or not inside):assert value==0
            for (name,label),total in sources.items():
                rec,=[r for r in checkrows if int(r['epoch'])==600 and r['site']==site+'_'+label]
                assert abs(total-float(rec[name]))<1e-12
    assert len(rows)==1120
    table(HERE/'density-multipoles.csv',rows,save)
    print('verified interior/exterior contributions for both drive channels through density degree 68')
if __name__=='__main__':
    assert sys.argv[1:] in ([],['--save']);calculate(bool(sys.argv[1:]))
