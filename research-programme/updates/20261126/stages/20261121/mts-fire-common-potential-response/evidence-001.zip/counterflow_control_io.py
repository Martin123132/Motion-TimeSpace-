"""Pinned inputs for the common-potential intervention."""
from pathlib import Path
import hashlib
import io
import importlib.util
import json
import os
import sys

HERE=Path(__file__).resolve().parent
PREVIOUS=HERE.parent/'mts-fire-prepared-gradient-20261121'
RECEIPT='1e17aec24a8fa2df0d14d3e9bfdccfef18006eb3c4a16fd1597713ce224ace23'
def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def prior(name):
    seal=PREVIOUS/'seal.json'
    assert digest(seal)==RECEIPT
    path=PREVIOUS/name
    assert digest(path)==json.loads(seal.read_bytes())[name]
    return path
for script in ('pair.py','inherit.py','measure.py','rate.py','full_force.py'):prior(script)
sys.path.insert(0,str(PREVIOUS))
from measure import FIRE,OLD,jf,np,pinned,table,keep,check as old_check,Elements,records
from inherit import EARLY
pair_spec=importlib.util.spec_from_file_location('fire_prepared_paired_balance',prior('pair.py'))
archived_pair=importlib.util.module_from_spec(pair_spec)
pair_spec.loader.exec_module(archived_pair)
advance=archived_pair.advance
from full_force import Readout
from rate import gradient_root
from disk import Evolution
STEPS=(32,64)
AMPLITUDES=(-1.,-.5,.5,1.)
LABELS=('inner_radial','inner_polar','outer_radial','outer_polar')
HOST='anchorA'
def check():
    old_check()
    assert not (HERE/'STOP-REQUESTED').exists()
def save_packet(path,arrays,save):
    stream=io.BytesIO();np.savez_compressed(stream,**arrays)
    keep(path,stream.getvalue(),save)
def receipt(target,names,save):
    body={n:digest(HERE/n) for n in names}
    keep(HERE/target,(json.dumps(body,indent=2,sort_keys=True)+'\n').encode(),save)
def validate_receipt(target):
    for name,expected in json.loads((HERE/target).read_bytes()).items():assert digest(HERE/name)==expected,name

class Run:
    def __init__(self,steps):
        check()
        assert steps in STEPS
        self.steps=steps
        self.obj=obj=jf.Assembly(HOST)
        self.el=Elements(obj.bg)
        self.grad=gradient_root(obj.bg.mesh.kinetic(obj.bg.orders,True),obj.bg.hshape)
        self.units=obj.bg.vel**2/obj.number
        self.rules=[Readout(self.el,radius,30) for radius in (6.,8.3)]
        with np.load(pinned(OLD,f'wave-{HOST}-joint-{steps}-572_579_586_590_600.npz')) as bank:self.base0=bank['states'][0].astype(complex)
        with np.load(pinned(FIRE,f'wave-{HOST}-joint-{steps}.npz')) as bank:
            self.reference={572:self.base0,**dict(zip(map(int,bank['snapshots']),bank['states'],strict=True))}
        with np.load(pinned(EARLY,f'state-{HOST}-three-{steps}.npz')) as bank:
            self.actual0=bank['states'][list(bank['snapshots']).index(572)]
        self.number=np.vdot(self.base0,self.base0).real
        assert abs(self.number/obj.number-1)<1e-10 and abs(np.vdot(self.actual0,self.actual0).real/self.number-1)<1e-10
        self.rotation=np.exp(-1j*np.angle(np.vdot(self.base0,self.actual0)))
        self.inherited=self.actual0*self.rotation*np.sqrt(self.number/np.vdot(self.actual0,self.actual0).real)
        cosine=np.vdot(self.base0,self.inherited)/self.number
        assert cosine.real>0 and abs(cosine.imag)<1e-13
        normal=self.inherited-self.base0*cosine.real
        sine=np.linalg.norm(normal)/np.sqrt(self.number)
        self.theta=np.arctan2(sine,cosine.real)
        self.tangent=normal*(self.theta/sine)
        assert abs(np.vdot(self.base0,self.tangent))/self.number<1e-13
        assert self.err(self.path(1),self.inherited)<1e-12
        self.epochs=tuple(self.reference)
        assert self.epochs==(572,579,581,586,590,600)
        times=np.loadtxt(pinned(OLD,'snapshot_times.txt'))
        self.ages={e:times[times[:,0]==e,3].item()*1000 for e in self.epochs}
        self.fields={}
        for epoch in self.epochs:
            folder=FIRE if epoch==581 else OLD
            with np.load(pinned(folder,f'forcing-{epoch}.npz')) as bank:
                assert np.array_equal(bank['physical_r'],obj.bg.rad*obj.bg.length)
                self.fields[epoch]=bank['joint']/obj.bg.vel**2
    def path(self,amplitude,base=None,tang=None):
        base=self.base0 if base is None else base;tang=self.tangent if tang is None else tang
        return np.cos(amplitude*self.theta)*base+np.sin(amplitude*self.theta)/self.theta*tang
    def err(self,value,expected):
        return np.linalg.norm(value-expected)/np.sqrt(self.number)
    def interval(self,start,end):
        duration=(self.ages[end]-self.ages[start])/self.obj.unit_myr
        count=int(np.ceil(self.steps*duration))
        return count,duration/count
    def external(self,start,end,tick,count):
        return self.fields[start]+((tick+.5)/count)*(self.fields[end]-self.fields[start])
    def sky_cross(self,left_sky,right):
        return (2*(left_sky.conj()*self.obj.sky(right)).real)@self.obj.wave.weights
    def gravity(self,vec):
        nodes=self.el.nodes(vec)
        return np.concatenate([rule(nodes) for rule in self.rules])
    def cross_force(self,left,right):
        return (self.gravity(left+right)-self.gravity(left-right))/2
    def distance(self,left,right):
        off,ref=map(self.grad,(left,right))
        phase=np.exp(-1j*np.angle(np.vdot(ref,off)))
        return self.units*np.linalg.norm(phase*off-ref)**2

def linear_mid(run,solver,old,dt,local,source):
    obj=run.obj;mid=old
    for counter in range(30):
        extra=source(2*mid-old) if source else 0.
        rhs=old-.5j*dt*(obj.multiply(local,mid)+extra)
        updated=solver.factor.solve(rhs)
        err=np.linalg.norm(updated-mid)/np.sqrt(run.number)
        mid=updated
        if err<2e-14:return 2*updated-old,updated
    raise ArithmeticError(('linear midpoint',counter,err))

def parse():
    assert sys.argv[1:2] in (['32'],['64']) and sys.argv[2:] in ([],['--save'])
    return int(sys.argv[1]),bool(sys.argv[2:])
