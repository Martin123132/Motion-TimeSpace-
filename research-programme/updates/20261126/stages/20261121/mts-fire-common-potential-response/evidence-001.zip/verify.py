"""Read-only scientific and provenance checks, other than explicitly saving the new receipt."""
from collections import Counter,defaultdict
from counterflow_control_io import *
def validate(save):
    check()
    counts={'bands':576,'vectors':96,'odd-even':96,'refinement-response':480,'refinement-totals':288,
            'work-summary':2,'matched-einstein-shell':16,'shell-controls':4,'metric-stress':72,'stress-controls':8,
            'density-multipoles':1120}
    for steps in STEPS:
        validate_receipt(f'prediction-lock-{steps}.json')
        for name,num in [('predictions',96),('differentiated-controls',6),('physical',96),('nonlinear-checks',6),('retarded',24),('source-work',5)]:
            counts[f'{name}-{steps}']=num
    for name,count in counts.items():
        assert len(records(HERE/(name+'.csv')))==count,name
    results={}
    for steps in STEPS:
        vectors=records(HERE/'vectors.csv')
        real=[v for v in vectors if int(v['steps'])==steps and int(v['epoch'])==600 and float(v['s'])==1.]
        assert len(real)==2
        for row in real:
            assert 0<float(row['quadratic_relative'])<float(row['linear_relative'])<.01
        physical=records(HERE/f'physical-{steps}.csv');data={(int(r['epoch']),float(r['s']),r['site']):r for r in physical}
        ref=records(prior('inheritance.csv'))
        for epoch in (572,579,581,586,590,600):
            incoming,=[r for r in ref if r['host']==HOST and int(r['steps'])==steps and int(r['epoch'])==epoch and r['history']=='three']
            for site in LABELS:
                rec=data[epoch,1.,site]
                assert abs(float(incoming['inherited_'+site])-float(rec['exact_delta']))<1e-8
                assert abs(float(rec['coupled_distance_kms2'])/float(incoming['inherited_gradient_kms2'])-1)<2e-5
        for site in LABELS:
            endpoint=data[600,1.,site]
            assert float(endpoint['exact_delta'])*float(endpoint['passive_delta'])<0
        for sign in (-1.,1.):
            large=data[600,sign,'inner_radial'];small=data[600,sign/2,'inner_radial']
            assert 3.8<float(large['state_linear_error'])/float(small['state_linear_error'])<4.2
            assert 7.5<float(large['state_quadratic_error'])/float(small['state_quadratic_error'])<8.5
        checks=records(HERE/f'nonlinear-checks-{steps}.csv')
        assert all(max(float(c[key]) for key in ('saved_reset_error','saved_full_error','retarded_field_error','force_split_defect'))<1e-8 for c in checks)
        full=records(HERE/f'retarded-{steps}.csv')
        entry,=[r for r in full if r['site']=='inner_radial' and int(r['epoch'])==600]
        duty=float(entry['monopole_drive'])/float(entry['physical_feedback'])
        assert .999<duty<1.
        energy,=[r for r in records(HERE/'work-summary.csv') if int(r['steps'])==steps]
        assert float(energy['peak_work_defect'])<.0003 and float(energy['max_reciprocity_defect'])<1e-7
        assert abs(float(energy['tracer_energy_change'])-float(energy['tracer_ordinary_work'])-float(energy['tracer_metric_work']))<.0003
        tests=[r for r in records(HERE/'bands.csv') if int(r['steps'])==steps]
        groups=Counter((r['arm'],r['history']) for r in tests if r['inside']=='True')
        assert len(groups)==36 and set(groups.values())=={2}
        shell=[r for r in records(HERE/'matched-einstein-shell.csv') if int(r['steps'])==steps]
        for row in shell:
            assert abs(sum(float(row[k]) for k in ('delta_heavy_stress','delta_wave_geometry','ordinary_wave_geometry_cross'))-float(row['total_difference']))<1e-18
            assert (float(row['total_difference'])<0)==(row['branch']=='coupled')
        for branch in ('coupled','passive'):
            vals=np.array([float(r['total_difference']) for r in shell if r['branch']==branch])
            assert np.max(abs(vals/vals[0]-1))<1e-8
        results[steps]=dict(matched_arms_and_histories=len(groups),monopole_fraction_inner_radial=duty,
                        max_saved_full_state_error=max(float(c['saved_full_error']) for c in checks))
    refs=records(HERE/'refinement-totals.csv')
    assert all(r['same_band']=='True' and r['passes_2e_minus5']=='True' for r in refs)
    own=[r for r in records(HERE/'refinement-response.csv') if int(r['epoch'])==600 and float(r['s'])==1. and r['metric']=='exact_delta']
    assert len(own)==4 and all(r['passes_2e_minus5']=='False' for r in own)
    assert len(json.loads((HERE/'einstein-identities.json').read_bytes())['exact_checks'])==8
    publish=dict(previous_seal=RECEIPT,counts=counts,checks=results,small_endpoint_timestep_failures=4,
                 prediction_locks={str(s):digest(HERE/f'prediction-lock-{s}.json') for s in STEPS})
    keep(HERE/'validation.json',(json.dumps(publish,indent=2,sort_keys=True)+'\n').encode(),save)
    names=['PROTOCOL.md','SOURCE-SPLIT.md','DERIVATION.md','METRIC-STRESS.md','RESULTS.md','counterflow_control_io.py',
           'predict.py','physical_test.py','source_work.py','angular_readout.py','metric_stress.py','metric_shell.py',
           'einstein_check.py','einstein-identities.json','compare.py','verify.py','validation.json']
    for s in STEPS:names.extend([f'prediction-lock-{s}.json',f'predicted-fields-{s}.npz',f'tested-fields-{s}.npz'])
    names.extend(k+'.csv' for k in counts)
    assert len(names)==len(set(names))
    receipt('seal.json',sorted(names),save)
    print('verified',len(names),'files; 576 signed totals and 8 symbolic checks; seal',digest(HERE/'seal.json'))
if __name__=='__main__':
    assert sys.argv[1:] in ([],['--save']);validate(bool(sys.argv[1:]))
