"""The active self-energy and the energy of a tracer in the reset metric are different."""
from counterflow_control_io import np

class SourceWork:
    def __init__(self,run,start,end,count):
        self.run=run;self.obj=run.obj
        self.ext0=run.fields[start];self.difference=run.fields[end]-self.ext0
        self.count=count;self.factor=run.units
        self.ordinary=np.zeros(3);self.bath=0.;self.reciprocity=0.;self.curvature=[];self.peak=0.
    def inner(self,field,pot):
        obj=self.obj
        return np.sum((abs(obj.sky(field))**2*obj.bg.aw)*pot*obj.bg.mesh.weight[:,None])
    def values(self,states,ext,selfphis):
        obj=self.obj
        energies=np.array([np.vdot(vec,obj.bare@vec).real+self.inner(vec,ext) for vec in states])
        natural=energies+np.array([.5*self.inner(vec,phi) for vec,phi in zip(states,selfphis,strict=True)])
        imposed=energies+np.array([self.inner(vec,selfphis[0]) for vec in states])
        delta=selfphis[2]-selfphis[0]
        correction=.5*(self.inner(states[2],delta)-self.inner(states[0],delta))
        defect=(natural[2]-natural[0])-(imposed[2]-imposed[0])-correction
        assert abs(self.factor*defect)<1e-7 and self.factor*correction<1e-8
        self.curvature.append(self.factor*correction)
        return np.array([natural[0],natural[1],imposed[2]])*self.factor
    def begin(self,states):
        self.states=tuple(states);self.phis=[self.obj.phi(self.obj.moment(vec)) for vec in states]
        self.initial=self.values(states,self.ext0,self.phis)
    def next(self,tick,states):
        obj=self.obj;old=self.states;oldphi=self.phis
        phis=[obj.phi(obj.moment(vec)) for vec in states]
        self.ordinary+=np.array([.5*self.factor*(self.inner(before,self.difference)+self.inner(after,self.difference))/self.count
                                 for before,after in zip(old,states,strict=True)])
        change=phis[0]-oldphi[0];tracer=(phis[2]+oldphi[2])/2
        bath=self.factor*.5*(self.inner(old[2],change)+self.inner(states[2],change))
        reciprocal=self.factor*(self.inner(states[0],tracer)-self.inner(old[0],tracer))
        self.bath+=bath;self.reciprocity=max(self.reciprocity,abs(bath-reciprocal))
        self.states=tuple(states);self.phis=phis
        if (tick+1)%16==0 or tick+1==self.count:
            self.final=self.values(states,self.ext0+self.difference*((tick+1)/self.count),phis)
            self.balance=self.final-self.initial-self.ordinary-[0.,0.,self.bath]
            self.peak=max(self.peak,max(abs(self.balance)))
    def result(self):
        assert self.peak<.0003 and self.reciprocity<1e-7,(self.peak,self.reciprocity)
        return dict(reset_work=self.ordinary[0],active_work=self.ordinary[1],tracer_ordinary_work=self.ordinary[2],
            tracer_metric_work=self.bath,tracer_energy_change=(self.final-self.initial)[2],
            peak_work_defect=self.peak,max_step_reciprocity_defect=self.reciprocity,
            tracer_self_energy_curvature_at_end=self.curvature[-1])
