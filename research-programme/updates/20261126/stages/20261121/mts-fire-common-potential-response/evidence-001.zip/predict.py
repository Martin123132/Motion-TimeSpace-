from counterflow_control_io import *

def run_prediction(steps,save):
    run=Run(steps);obj=run.obj;number=run.number
    base=run.base0.copy();passive_tangent=run.tangent.copy();first=run.tangent.copy()
    second=-.5*run.theta**2*base
    predictions=[];controls=[];pack={}
    names=['PROTOCOL.md','counterflow_control_io.py','predict.py']
    def collect(epoch):
        check();base_force=run.gravity(base)
        lin=run.cross_force(base,first);quad=run.cross_force(base,second)+run.gravity(first)
        native_lin=obj.forces(run.sky_cross(obj.sky(base),first))[:4]
        native_quad=obj.forces(run.sky_cross(obj.sky(base),second)+obj.moment(first))[:4]
        assert max(abs(lin-native_lin))<1e-8 and max(abs(quad-native_quad))<1e-8
        null1=2*np.vdot(base,first).real/number
        null2=(2*np.vdot(base,second).real+np.vdot(first,first).real)/number
        cross=np.vdot(base,passive_tangent)/number
        pnorm=np.vdot(passive_tangent,passive_tangent).real/number-run.theta**2
        assert max(abs(null1),abs(null2),abs(cross),abs(pnorm))<1e-10
        err=run.err(base,run.reference[epoch]);assert err<1e-8
        controls.append(dict(epoch=epoch,steps=steps,initial_angle=run.theta,reset_state_error=err,
            linear_norm_derivative=null1,quadratic_norm_coefficient=null2,passive_overlap=abs(cross),
            passive_tangent_norm_defect=pnorm,linear_force_native_defect=max(abs(lin-native_lin)),
            quadratic_force_native_defect=max(abs(quad-native_quad))))
        for label,vec in [('base',base),('passive_tangent',passive_tangent),('first',first),('second',second)]:
            pack[f'{label}_{epoch}']=vec.copy()
        for amp in AMPLITUDES:
            tracer=run.path(amp,base,passive_tangent);tracer_change=run.gravity(tracer)-base_force
            assert abs(np.vdot(tracer,tracer).real/number-1)<1e-10
            dist=run.distance(tracer,base)
            for index,site in enumerate(LABELS):
                predictions.append(dict(steps=steps,epoch=epoch,s=amp,site=site,reset_force=base_force[index],
                    passive_delta=tracer_change[index],passive_gradient_distance=dist,tangent=lin[index],
                    curvature_coefficient=quad[index],predicted_linear_delta=amp*lin[index],
                    predicted_quadratic_delta=amp*lin[index]+amp**2*quad[index]))
    collect(572)
    for start,end in zip(run.epochs,run.epochs[1:]):
        count,dt=run.interval(start,end);solver=Evolution(obj,dt,base);moment=obj.moment(base)
        for tick in range(count):
            if tick%16==0:check()
            ext=run.external(start,end,tick,count)
            final,nmoment,mid,phi=advance(obj,solver,base,moment,ext,dt)
            local=ext+phi-solver.pref
            passive_tangent,_=linear_mid(run,solver,passive_tangent,dt,local,None)
            start_sky=obj.sky(base);end_sky=obj.sky(final)
            old_p=run.sky_cross(start_sky,first)
            def delta_phi(new):
                return obj.phi((old_p+run.sky_cross(end_sky,new))/2)
            newfirst,midfirst=linear_mid(run,solver,first,dt,local,lambda new:obj.multiply(delta_phi(new),mid))
            mixed_source=obj.multiply(delta_phi(newfirst),midfirst)
            fixed=run.sky_cross(start_sky,second)+obj.moment(first)+obj.moment(newfirst)
            def second_source(new):
                return mixed_source+obj.multiply(obj.phi((fixed+run.sky_cross(end_sky,new))/2),mid)
            second,_=linear_mid(run,solver,second,dt,local,second_source)
            first=newfirst;base=final;moment=nmoment
        print('predicted',steps,start,end,'reset error',run.err(base,run.reference[end]),flush=True)
        collect(end)
    for key,rows in [('predictions',predictions),('differentiated-controls',controls)]:
        name=f'{key}-{steps}.csv';names.append(name);table(HERE/name,rows,save)
    name=f'predicted-fields-{steps}.npz';save_packet(HERE/name,pack,save);names.append(name)
    receipt(f'prediction-lock-{steps}.json',names,save)
if __name__=='__main__':run_prediction(*parse())
