from counterflow_control_io import *
from collections import Counter,defaultdict

def compare(save):
    bands=[];series=[];parity=[];overall=[];summaries=[];resolution=[];peak=[]
    for steps in STEPS:
        validate_receipt(f'prediction-lock-{steps}.json')
        rows=records(HERE/f'physical-{steps}.csv')
        assert len(rows)==96
        outcomes={(int(r['epoch']),float(r['s']),r['site']):r for r in rows}
        forecast={(int(r['epoch']),float(r['s']),r['site']):r for r in records(HERE/f'predictions-{steps}.csv')}
        def vector(epoch,amp,key):
            return np.array([float(outcomes[epoch,amp,site][key]) for site in LABELS])
        for epoch in (572,579,581,586,590,600):
            for amp in AMPLITUDES:
                for index,site in enumerate(('inner','outer')):
                    at=slice(2*index,2*index+2)
                    active=vector(epoch,amp,'exact_delta')[at];passive=vector(epoch,amp,'passive_delta')[at]
                    linear=vector(epoch,amp,'predicted_linear')[at];quadratic=vector(epoch,amp,'predicted_quadratic')[at]
                    feedback=active-passive;size=np.linalg.norm(active)
                    error1=np.linalg.norm(linear-active);error2=np.linalg.norm(quadratic-active)
                    series.append(dict(steps=steps,epoch=epoch,s=amp,site=site,active_size=size,passive_size=np.linalg.norm(passive),
                        actual_feedback_size=np.linalg.norm(feedback),feedback_projected_fraction=feedback@active/size**2,
                        linear_error=error1,quadratic_error=error2,linear_relative=error1/size,quadratic_relative=error2/size))
            for amp in (.5,1.):
                pos=vector(epoch,amp,'exact_delta');neg=vector(epoch,-amp,'exact_delta')
                odd=(pos-neg)/(2*amp);even=(pos+neg)/(2*amp**2)
                tangent=np.array([float(forecast[epoch,amp,site]['tangent']) for site in LABELS])
                curvature=np.array([float(forecast[epoch,amp,site]['curvature_coefficient']) for site in LABELS])
                for index,site in enumerate(LABELS):
                    parity.append(dict(steps=steps,epoch=epoch,abs_s=amp,site=site,odd_slope=odd[index],
                        tangent=tangent[index],even_coefficient=even[index],curvature=curvature[index],
                        slope_defect=odd[index]-tangent[index],curvature_defect=even[index]-curvature[index]))
        baselines=records(pinned(FIRE,f'bands-{HOST}-joint-{steps}.csv'))
        physical=records(pinned(EARLY,f'bands-{HOST}-three-{steps}.csv'))
        archive={(r['model'],r['history'],r['R'],r['z'],r['component']):r for r in physical}
        for base in baselines:
            model=base['model'];site=('inner_' if float(base['R'])==6. else 'outer_')+base['component']
            sign=-1 if base['component']=='polar' and float(base['z'])<0 else 1
            full=archive[model,base['history'],base['R'],base['z'],base['component']]
            source=outcomes[600,1.,site]
            arms={'reset':0.,'passive_density':float(source['passive_delta']),'full':float(source['exact_delta']),
                  'first_order':float(source['predicted_linear']),'second_order':float(source['predicted_quadratic'])} if model=='MTS' else {'static_NFW':0.}
            for arm,shift in arms.items():
                total=float(base['total'])+sign*shift
                lo,hi=float(base['low']),float(base['high'])
                assert (lo,hi)==(float(full['low']),float(full['high']))
                if arm in ('full','static_NFW'):assert abs(total-float(full['total']))<1e-8
                bands.append(dict(steps=steps,history=base['history'],R=base['R'],z=base['z'],component=base['component'],
                    arm=arm,lo=lo,hi=hi,signed_change=sign*shift,total=total,inside=lo<=total<=hi))
        work=records(HERE/f'source-work-{steps}.csv')
        summaries.append(dict(steps=steps,substeps=sum(int(r['substeps']) for r in work),
            **{k:sum(float(r[k]) for r in work) for k in ('reset_work','active_work','tracer_ordinary_work','tracer_metric_work','tracer_energy_change')},
            peak_work_defect=max(float(r['peak_work_defect']) for r in work),
            max_reciprocity_defect=max(float(r['max_step_reciprocity_defect']) for r in work)))
        for epoch in (572,579,581,586,590,600):
            for amp in AMPLITUDES:
                for key in ('exact_delta','passive_delta','predicted_linear','predicted_quadratic','self_feedback_delta'):
                    overall.append(dict(steps=steps,epoch=epoch,s=amp,metric=key,vector=vector(epoch,amp,key)))
    pairs=defaultdict(dict)
    for b in bands:pairs[b['history'],b['R'],b['z'],b['component'],b['arm']][b['steps']]=b
    for key,items in pairs.items():
        coarse,fine=(items[s] for s in STEPS)
        absolute=abs(coarse['total']-fine['total'])
        resolution.append(dict(history=key[0],R=key[1],z=key[2],component=key[3],arm=key[4],
                              total_relative=absolute/abs(fine['total']),passes_2e_minus5=absolute<=2e-5*abs(fine['total']),
                              same_band=coarse['inside']==fine['inside']))
    pairs=defaultdict(dict)
    for row in overall:pairs[row['epoch'],row['s'],row['metric']][row['steps']]=row['vector']
    for (epoch,amp,metric),values in pairs.items():
        for index,site in enumerate(LABELS):
            coarse,fine=(values[s][index] for s in STEPS);err=abs(fine-coarse)
            peak.append(dict(epoch=epoch,s=amp,metric=metric,site=site,absolute=err,
                         relative=err/abs(fine) if fine else '',passes_2e_minus5=err<=2e-5*abs(fine)))
    assert len(bands)==576 and len(series)==96 and len(parity)==96 and len(resolution)==288
    for name,data in [('bands',bands),('vectors',series),('odd-even',parity),('refinement-totals',resolution),
                      ('refinement-response',peak),('work-summary',summaries)]:
        table(HERE/(name+'.csv'),data,save)
    print('verified 576 signed comparisons; perturbation refinement reported separately')
if __name__=='__main__':
    assert sys.argv[1:] in ([],['--save']);compare(bool(sys.argv[1:]))
