"""Spherical part of the wave-stress contribution to the two linear metric potentials."""
from counterflow_control_io import *
from measure import shape
from numpy.polynomial import Polynomial
from scipy.constants import c,parsec
from scipy.special import roots_legendre

class RadialStress:
    def __init__(self,el,point,order):
        self.orders=el.bg.orders;self.y=point;nodes,weights=roots_legendre(order)
        self.blocks=[]
        for exterior in (False,True):
            lo=np.maximum(el.left,point) if exterior else el.left
            hi=el.right if exterior else np.minimum(el.right,point)
            keep=hi>lo;idx=np.flatnonzero(keep)
            rr=lo[keep,None]+(hi-lo)[keep,None]*(nodes+1)/2
            quadrature=(hi-lo)[keep,None]*weights/2
            values,deriv=shape(el.knots,(rr-el.left[idx,None])/el.width[idx,None])
            self.blocks.append((idx,rr,quadrature,values,deriv/el.width[idx,None,None]))
    def evaluate(self,wave):
        pick,rr,weights,shape0,_=self.blocks[0]
        enclosed=np.sum(weights*np.sum(abs(shape0@wave[pick])**2,axis=2))
        pick,rr,weights,shape1,rate=self.blocks[1]
        values=shape1@wave[pick];du=rate@wave[pick]
        angular=np.sum(abs(values)**2*(self.orders*(self.orders+1)),axis=-1)/(2*rr**4)
        radial=np.sum(abs(du-values/rr[:,:,None])**2,axis=2)/rr**2
        result=[]
        for pressure in (radial,-angular):
            kernel=weights*pressure/rr
            result.extend([np.sum(kernel*(rr**2-self.y**2)),2*self.y*np.sum(kernel)])
        return np.array([-enclosed/self.y**2,*result])

def polynomial_test(el,point):
    edge=el.right[np.searchsorted(el.right,point*2)]
    rule=RadialStress(el,point,24)
    results=[]
    for degree in (0,2):
        rad=Polynomial([0.,1.])
        amp=rad**degree*(1-(rad/edge)**2)**2
        field=np.zeros(el.bg.hshape)
        field[:,np.flatnonzero(el.bg.orders==degree)[0]]=np.where(el.bg.rad<edge,el.bg.rad*amp(el.bg.rad),0.)*el.bg.sqrt
        actual=rule.evaluate(el.nodes(field.ravel()))
        enclosed=((rad*amp)**2).integ()(point)
        expected=[-enclosed/point**2]
        for pol in (amp.deriv()**2,-.5*degree*(degree+1)*(amp//rad)**2):
            assert abs(pol(0.))<1e-12
            over=pol//rad
            integ=over.integ();area=integ(edge)-integ(point)
            weighted=(rad**2*over).integ()
            expected.extend([weighted(edge)-weighted(point)-point**2*area,2*point*area])
        error=np.max(abs(actual-expected))/max(abs(np.array(expected)))
        assert error<1e-10,(degree,error)
        results.append(dict(degree=degree,probe=point,source_edge=edge,relative_max_error=error))
    return results

def calculate(save):
    rows=[];checks=[]
    for steps in STEPS:
        validate_receipt(f'prediction-lock-{steps}.json')
        run=Run(steps);el=run.el;bg=run.obj.bg
        suppression=(bg.vel/(c/1000))**2
        factor=bg.vel**2/bg.length*(1e13/parsec)
        with np.load(pinned(EARLY,f'state-{HOST}-three-{steps}.npz')) as packet:
            saved=dict(zip(map(int,packet['snapshots']),packet['states'],strict=True))
        with np.load(HERE/f'tested-fields-{steps}.npz') as product:
            final=product['exact_+1.0'];tracer=product['passive']
        with np.load(HERE/f'predicted-fields-{steps}.npz') as predictions:
            for cyl in (6.,8.3):
                probe=np.hypot(cyl,1.5)/bg.length
                checks.extend([dict(steps=steps,**rec) for rec in polynomial_test(el,probe)])
                rules=[RadialStress(el,probe,order) for order in (18,30)]
                for epoch in run.epochs:
                    base=predictions[f'base_{epoch}']
                    passive=run.path(1.,base,predictions[f'passive_tangent_{epoch}'])
                    full=saved[epoch]
                    if epoch==600:
                        assert run.err(passive,tracer)<1e-8 and run.err(final,full*np.exp(-1j*np.angle(np.vdot(final,full))))<1e-8
                        full=final;passive=tracer
                    for key,vec in [('reset',base),('passive',passive),('coupled',full)]:
                        fine,other=[rule.evaluate(el.nodes(vec)) for rule in rules[::-1]]
                        assert np.allclose(fine,other,rtol=5e-12,atol=1e-14)
                        gravity,pot_r,acc_r,pot_t,acc_t=fine
                        rows.append(dict(steps=steps,epoch=epoch,R=cyl,spherical_probe_kpc=probe*bg.length,branch=key,
                            newton_wave_monopole=gravity*factor,slip_potential_kms2=(pot_r+pot_t)*bg.vel**2*suppression,
                            radial_stress_force=acc_r*factor*suppression,angular_stress_force=acc_t*factor*suppression,
                            slip_force=(acc_r+acc_t)*factor*suppression,slip_over_abs_newton=(acc_r+acc_t)*suppression/abs(gravity),
                            refinement_relative=np.linalg.norm(fine-other)/np.linalg.norm(fine)))
    assert len(rows)==72 and len(checks)==8
    table(HERE/'metric-stress.csv',rows,save);table(HERE/'stress-controls.csv',checks,save)
    print('verified spherical wave-stress constraint at two probes, eight manufactured radial/angular controls')
if __name__=='__main__':
    assert sys.argv[1:] in ([],['--save']);calculate(bool(sys.argv[1:]))
