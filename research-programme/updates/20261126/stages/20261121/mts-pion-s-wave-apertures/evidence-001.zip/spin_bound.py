"""Finite-aperture bounds and explicit non-identifiability controls; no wave fitted."""
import numpy as np
from waves import angular, born_s, elastic, energy_rule, kinematics, p2, roots_legendre, save, table


def geometry(group, order):
    left, right = np.array([item[3:5] for item in group]).T
    assert left[0] == 0 and np.allclose(left[1:], right[:-1], atol=1e-14)
    nodes, weights = roots_legendre(order)
    angles = left[:, None] + (right-left)[:, None]*(nodes+1)/2
    return angles, weights/2, (right-left)/right[-1], right[-1]


def source(energies, angles, charged):
    beta, rate = kinematics(energies, charged)
    born = elastic.born(energies**2)
    pole = (1-beta[:, None, None]**2)/(1-(beta[:, None, None]*angles)**2)
    rest = pole-born_s(beta)[:, None, None]-5*born[:, None, None]*p2(angles)
    target = np.array([angular.read_wave(energy) for energy in energies])
    hadron = (1-.01*energies**2)*elastic.omega(energies**2)
    kernel = 2*elastic.KAPPA*beta**3/energies**3
    return (rest if charged else np.zeros_like(rest)), born, target, hadron, kernel, rate


def projected_bounds(angular_weight, pol, residual, limit, inner, coarse_lo, coarse_hi):
    def allowed(value):
        shape = 5*value*pol + residual
        mean = shape@angular_weight
        variance = (shape-mean[:, None])**2@angular_weight
        room = limit-variance
        if np.any(room<0):
            return False
        half = np.sqrt(room)
        return np.max(-mean-half)<=np.min(-mean+half)

    assert allowed(inner)
    scale = 2*max(abs(coarse_lo-inner), abs(coarse_hi-inner))
    outside = []
    for sign in (-1, 1):
        bad = inner+sign*scale
        assert not allowed(bad)
        good = inner
        for _ in range(56):
            mid = (bad+good)/2
            if allowed(mid):
                good = mid
            else:
                bad = mid
        outside.append(bad)
    return max(coarse_lo, outside[0]), min(coarse_hi, outside[1])


def bound_group(group, order, box):
    channel, low, high = group[0][:3]
    start, stop = max(.6, low), min(.75, high)
    assert start < stop
    angles, aw, widths, aperture = geometry(group, 3*order)
    observed = np.array([item[5]+box*(item[6]+(item[7] or 0.)) for item in group])
    assert np.all(observed>0)
    energies, ew = energy_rule(start, stop, order)
    charge = channel=="charged"
    rest, born, target, hadron, kernel, rate = source(energies, angles, charge)
    weighted = ew*kernel
    projected = np.einsum("e,eij->ij", weighted*hadron.real, rest)
    physical = (born if charge else 0)+(2/3)*(target-born)
    reference = weighted@(physical*hadron.conjugate()).real
    limited = (high-low)*np.sum(ew*kernel**2*abs(hadron)**2/rate)*observed
    pol = p2(angles)
    mean = widths@(pol@aw)
    variance = widths@((pol-mean)**2@aw)
    assert abs(variance-aperture**4/5)<2e-15
    center = -(widths@(((pol-mean)*projected)@aw))/(5*variance)
    radius = np.sqrt(widths@limited/variance)/5
    lower, upper = projected_bounds(aw, pol, projected, limited, 0., center-radius, center+radius)
    factor = 1 if charge else .5
    return dict(channel=channel,W_low=low,W_high=high,overlap_lo=start,overlap_hi=stop,
                coverage=aperture,box=box,channel_weight=factor,coarse_lo=factor*(center-radius),
                coarse_hi=factor*(center+radius),binwise_lo=factor*lower,binwise_hi=factor*upper,
                reference=factor*reference)


def bump(unit):
    return np.sqrt(630.)*unit**2*(1-unit)**2


def witness_group(group, order, center):
    channel, low, high = group[0][:3]
    charge = channel=="charged"
    angles, aw, _, _ = geometry(group, 3*order)
    energies, ew = energy_rule(low, high, order)
    rest, born, target, _, _, rate = source(energies, angles, charge)
    fixed = rest+5*((float(charge)-2/3)*born)[:, None, None]*p2(angles)
    shift = (10/3)*target[:, None, None]*p2(angles)
    if center:
        aperture = .6
        mean_pol = (aperture**2-1)/2
        beta, _ = kinematics(energies, charge)
        mean_pole = (1-beta**2)*np.arctanh(beta*aperture)/(beta*aperture)
        mean_fixed = float(charge)*(mean_pole-born_s(beta))-(10/3)*born*mean_pol
        fixed -= mean_fixed[:,None,None]
        shift -= ((10/3)*target*mean_pol)[:,None,None]
    def intensity(squares):
        return (ew*rate/(high-low))@(squares@aw)

    quad = intensity(abs(shift)**2)
    linear = intensity(2*(shift*fixed.conjugate()).real)
    const = intensity(abs(fixed)**2)
    observed = np.array([item[5] for item in group])
    discriminant = linear**2+4*quad*(observed-const)
    assert np.all(quad>0) and np.all(discriminant>0)
    root = np.sqrt(discriminant)
    lower = (-linear-root)/(2*quad)
    upper = (-linear+root)/(2*quad)
    rows = [dict(channel=channel,S_witness="zero_mean_0p6" if center else "zero_S",W_low=low,W_high=high,z_low=item[3],z_high=item[4],
                 observed=item[5],quadratic=quad[idx],linear=linear[idx],constant=const[idx],
                 nu_lo=lower[idx],nu_hi=upper[idx]) for idx,item in enumerate(group)]
    for nu in (-1,0,1):
        direct = intensity(abs(fixed+nu*shift)**2)
        assert max(abs(direct-(const+nu*(linear+nu*quad))))<1e-10
        deficit = observed-direct
        for idx,row in enumerate(rows):
            row[f"remaining_{nu}"]=deficit[idx]
        if min(deficit)>=0:
            left = np.array([row[3] for row in group])[:,None]
            width = np.array([row[4]-row[3] for row in group])[:,None]
            profile = bump((angles-left)/width)
            filled = (bump((energies-low)/(high-low))[:,None,None]*profile
                      *np.sqrt(deficit[None,:,None]/rate[:,None,None]))
            error = max(abs(intensity(abs(fixed+nu*shift)**2+filled**2)-observed))
            assert error < 1e-8, error
    return rows


def run(order):
    data = angular.dataset()
    groups = [[row for row in data if row[:3]==key] for key in sorted({row[:3] for row in data})]
    bounds, witnesses = [], []
    for group in groups:
        for center in (False,True):
            witnesses.extend(witness_group(group, order, center))
        if group[0][1]<.75 and group[0][2]>.60:
            for box in (0,1):
                bounds.append(bound_group(group, order, box))
    assert len(witnesses)==296 and len(bounds)==20
    for channel in ("charged","neutral"):
        assert abs(sum(row["overlap_hi"]-row["overlap_lo"] for row in bounds
                       if row["channel"]==channel and not row["box"])-.15)<1e-13
    totals = {f"{key}_{box}":sum(row[key] for row in bounds if row["box"]==box)
              for key in ("binwise_lo","binwise_hi","coarse_lo","coarse_hi","reference") for box in (0,1)}
    ref=totals["reference_0"]
    for name in ("zero_S","zero_mean_0p6"):
        selected = [row for row in witnesses if row["S_witness"]==name]
        low = totals["nu_lo_"+name] = max(row["nu_lo"] for row in selected)
        high = totals["nu_hi_"+name] = min(row["nu_hi"] for row in selected)
        totals["min_power_"+name] = min(row[f"remaining_{nu}"] for row in selected for nu in (-1,0,1))
        assert 0 < ref and totals["binwise_lo_0"] <= low*ref <= high*ref <= totals["binwise_hi_0"]
    assert totals["binwise_lo_1"]<=totals["binwise_lo_0"] and totals["binwise_hi_1"]>=totals["binwise_hi_0"]
    return bounds,witnesses,totals


if __name__=="__main__":
    _,_,rough = run(16)
    groups,bins,results = run(24)
    errors = {key:abs(value-rough[key]) for key,value in results.items()}
    assert all(err<2e-7*max(abs(results[key]),1e-10) for key,err in errors.items()), errors
    table("moment-bounds.csv",groups)
    table("helicity-witness.csv",bins)
    save("gravity-window.json",dict(results=results,refinement_absolute=errors))
    print(results)

