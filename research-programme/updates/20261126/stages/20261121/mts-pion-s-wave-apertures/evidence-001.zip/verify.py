import csv
import hashlib
import json
import re
import sys
from pathlib import Path
import numpy as np
from scipy.special import eval_legendre
from waves import HERE, angular, elastic, roots_legendre
from spin_bound import projected_bounds


def read(name):
    with (HERE/name).open(encoding="utf8", newline="") as stream:
        return list(csv.DictReader(stream))


def value(row,key):
    return float(row[key])


def geometric_fixture():
    nodes, weights=roots_legendre(40)
    weights=weights/2
    left=np.arange(8)*.075
    width=.075
    angle=left[:,None]+width*(1+nodes)/2
    pol=eval_legendre(2,angle)
    mean=(pol@weights).mean()
    var=(((pol-mean)**2)@weights).mean()
    assert abs(var-.6**4/5)<1e-15
    quartic=eval_legendre(4,angle)
    assert abs((((pol-mean)*quartic)@weights).mean()/var)>.1
    for sign in (-1,1):
        degree=sign*.83
        limit=((5*degree*(pol-mean))**2)@weights
        radius=np.sqrt(limit.mean()/var)/5
        assert abs(radius-abs(degree))<1e-14
        for offset in (0j,2-3j):
            same=5*degree*(pol-mean)+offset+.3*quartic
            measured=(abs(same)**2+.01*(1-angle**2)**2)@weights
            lo,hi=projected_bounds(weights,pol,.3*quartic,measured,degree,-20.,20.)
            assert lo-1e-13<=degree<=hi+1e-13


def checks():
    geometric_fixture()
    source=angular.dataset()
    bins=read("bin-comparison.csv")
    assert len(bins)==len(source)==148
    by_key={(item[0],item[1],item[3]):item for item in source}
    for row in bins:
        item=by_key[row["channel"],value(row,"W_low"),value(row,"z_low")]
        assert np.allclose([value(row,key) for key in ("W_high","z_high","observed_nb_per_z","stat")],
                           [item[idx] for idx in (2,4,5,6)],atol=1e-13,rtol=0)
        assert abs(value(row,"dp_H")-sum(value(row,key) for key in
                   ("dp_S_sq","dp_S_interference","fixed_same_remainder_sq","opposite_sq")))<1e-10
    for floor in read("charged-helicity-floor.csv"):
        group=[row for row in bins if row["channel"]=="charged" and value(row,"W_low")==value(floor,"W_lo")]
        assert len(group)==6
        width=np.array([value(row,"z_high")-value(row,"z_low") for row in group])
        pole=np.array([value(row,"opposite_sq") for row in group])
        limit=np.array([value(row,"observed_nb_per_z")+int(floor["stat_box"])*value(row,"stat") for row in group])
        dist=np.sqrt((width@(np.maximum(0,np.sqrt(pole)-np.sqrt(limit))**2))/(width@pole))
        assert abs(dist-value(floor,"min_binwise_relative_norm_change"))<1e-13
    windows=json.loads((HERE/"gravity-window.json").read_bytes())["results"]
    direct=elastic.integrate(angular.model(),.6,.75,10)["signed"]
    assert abs(direct/windows["reference_0"]-1)<2e-7
    for mode in (0,1):
        lo,hi=(windows[f"binwise_{key}_{mode}"] for key in ("lo","hi"))
        assert windows[f"coarse_lo_{mode}"]<lo<0<hi<windows[f"coarse_hi_{mode}"]
    witnesses=read("helicity-witness.csv")
    for kind in ("zero_S","zero_mean_0p6"):
        selected=[row for row in witnesses if row["S_witness"]==kind]
        assert len(selected)==148
        for nu in (-1,0,1):
            for row in selected:
                gap=value(row,"observed")-sum(value(row,key)*term for key,term in
                                               (("quadratic",nu**2),("linear",nu),("constant",1)))
                assert abs(gap-value(row,f"remaining_{nu}"))<1e-9
                if kind=="zero_mean_0p6":
                    assert gap>0
    cones,weights=read("neutral-cone.csv"),read("neutral-weights.csv")
    assert len(cones)==60 and len(weights)==816
    for row in cones:
        selected=[item for item in weights if all(item[key]==row[key] for key in ("W_lo","W_hi","nu","errors"))]
        actual=[by_key["neutral",value(row,"W_lo"),value(item,"z_lo")] for item in selected]
        left,right,obs,stat,sys_err=np.array([entry[3:] for entry in actual]).T
        err=stat+(sys_err if row["errors"]=="stat_plus_sys" else 0)
        nodes,aw=roots_legendre(12)
        pol=eval_legendre(2,(left[:,None]+right[:,None]+(right-left)[:,None]*nodes)/2)
        mean=pol@aw/2
        square=(pol**2)@aw/2
        shape=((1-pol)**2)@aw/2
        power=value(row,"D_power_nb")
        dual=np.array([value(item,"weight") for item in selected])
        pred=value(row,"S_power")+value(row,"SD_interference")*mean+power*square+value(row,"opposite_P2sq_power")*shape
        upper=max(abs(pred-obs)/err)
        assert abs(upper-value(row,"min_budget_upper"))<1e-8
        assert dual.sum()<0 and dual@shape<=0
        lower=max(0.,(dual@(obs-power*square)-power*(dual@mean)**2/(-sum(dual)))/(abs(dual)@err))
        assert abs(lower-value(row,"min_budget_lower"))<1e-7 and -1e-8 < upper-lower < 1.1e-6
    return len(cones),direct


if __name__=="__main__":
    count,reference=checks()
    for doc in HERE.glob("*.md"):
        for link in re.findall(r"\]\(([^\s)]+)\)",doc.read_text(encoding="utf8")):
            if not link.startswith("https://"):
                assert (HERE/link).is_file(),(doc,link)
    files=sorted(path for path in HERE.iterdir() if path.is_file() and path.name!="seal.json")
    hashes={path.name:hashlib.sha256(path.read_bytes()).hexdigest() for path in files}
    seal=HERE/"seal.json"
    if sys.argv[1:]==["--seal"]:
        with seal.open("x",encoding="utf-8",newline="\n") as stream:
            stream.write(json.dumps(hashes,indent=2)+"\n")
    else:
        assert len(sys.argv)==1 and hashes==json.loads(seal.read_bytes())
    print(f"{len(files)} files; {count} certified profiles; independent moment {reference:.11g}; seal {hashlib.sha256(seal.read_bytes()).hexdigest()}")

