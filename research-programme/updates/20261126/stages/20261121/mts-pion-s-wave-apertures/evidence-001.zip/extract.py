import argparse
import csv
import hashlib
import io
from pathlib import Path
import urllib.request

import fitz
import numpy as np

HERE=Path(__file__).resolve().parent
URL="https://arxiv.org/pdf/1404.7524v2"
HASH="181bb0619921c12105f3ec83f059375fb3d4eb1b5494f992ae652847a819cd94"


def ticks(drawings,indices,values,axis):
    pixels=[drawings[idx]["rect"][axis] for idx in indices]
    assert all(drawings[idx]["color"]==(0.,0.,0.) for idx in indices)
    coef=np.polyfit(pixels,values,1)
    assert np.max(abs(np.polyval(coef,pixels)-values))<.0006*abs(values[-1]-values[0])
    return lambda val:np.polyval(coef,val)


def marker(drawings,idx):
    obj=drawings[idx]
    assert obj["type"]=="f" and obj["fill"]==(0.,0.,0.) and len(obj["items"])==4
    rect=obj["rect"]
    return np.array([(rect.x0+rect.x1)/2,(rect.y0+rect.y1)/2])


def write(name,fields,rows):
    path=HERE/name
    data=io.StringIO(newline="")
    writer=csv.writer(data,lineterminator="\n")
    writer.writerow(fields)
    writer.writerows(rows)
    result=data.getvalue().encode("ascii")
    if path.exists():
        assert path.read_bytes()==result,name
    else:
        path.write_bytes(result)


def extract(raw):
    assert hashlib.sha256(raw).hexdigest()==HASH
    with fitz.open(stream=raw,filetype="pdf") as doc:
        page=doc[41]
        assert "Figure 22:" in page.get_text() and "25 MeV" in page.get_text()
        graph=page.get_drawings()
        for iso in (0,2):
            offset=0 if iso==0 else 1770
            step=.3 if iso==0 else .2
            horiz=ticks(graph,range(1726+offset,1735+offset,2),np.arange(-3,2)*step,0)
            vert=ticks(graph,range(1737+offset,1746+offset,2),np.arange(-1,4)*step,1)
            start=3565 if iso==0 else 3658
            spacing=.025 if iso==0 else .1
            rows=[]
            for idx in range(25 if iso==0 else 7):
                pixel=marker(graph,start+2*idx)
                if iso==0 and idx%4==0:
                    check=marker(graph,3541+idx//2)
                    assert np.max(abs(pixel-check))<.012
                rows.append((round(.3+idx*spacing,6),float(horiz(pixel[0])),float(vert(pixel[1]))))
            write(f"isospin-{iso}.csv",("W_GeV","Re_F_S","Im_F_S"),rows)
        page=doc[36]
        assert "Figure 16:" in page.get_text()
        graph=page.get_drawings()
        for iso,offset,index,yrange in ((0,0,184,500),(2,92,187,200)):
            horiz=ticks(graph,range(40+offset,55+offset,2),np.arange(1,9)*.2,0)
            if iso==0:
                ys=range(56,67,2)
            else:
                ys=range(148,157,2)
            vert=ticks(graph,ys,np.linspace(0,yrange,len(ys)),1)
            curve=graph[index]
            assert curve["color"]==(0.,0.,0.) and len(curve["items"])==130
            parts=curve["items"]
            assert all(part[0]=="l" for part in parts)
            pts=np.array([parts[0][1],*[part[2] for part in parts]])
            arr=np.c_[horiz(pts[:,0]),vert(pts[:,1])]
            assert np.all(np.diff(arr[:,0])>=0)
            write(f"sigma-{iso}.csv",("W_GeV","sigma_I_S_nb"),arr[(arr[:,0]>.285)&(arr[:,0]<.925)])


if __name__=="__main__":
    parser=argparse.ArgumentParser()
    parser.add_argument("--pdf",type=Path)
    args=parser.parse_args()
    if args.pdf:
        extract(args.pdf.read_bytes())
    else:
        with urllib.request.urlopen(URL,timeout=35) as response:
            extract(response.read(3500000))

