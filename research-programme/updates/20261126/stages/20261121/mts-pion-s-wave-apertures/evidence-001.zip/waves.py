import csv
import hashlib
import json
import sys
from functools import lru_cache
from pathlib import Path
import numpy as np
from scipy.interpolate import PchipInterpolator

HERE=Path(__file__).resolve().parent
PRIOR=HERE.parent/"mts-four-pion-stress-bridge-20261121"
SIX=HERE.parent/"mts-six-pion-rescattering-20261121"
for source,seal in ((SIX,"42a047ce2a559a4201fa96870d63cc627abc43d46462aff87c848e59b4675d9e"),
                    (PRIOR,"f0c870961439fd514759ae2df293e50307b56c28cb4d4a75c48d459ab14facf8")):
    raw=(source/"seal.json").read_bytes()
    assert hashlib.sha256(raw).hexdigest()==seal
    for name,digest in json.loads(raw).items():
        assert hashlib.sha256((source/name).read_bytes()).hexdigest()==digest
sys.path.insert(0,str(PRIOR))
import angular
from common import NB,MASS,alpha,elastic,roots_legendre

SQ2=np.sqrt(2.)
SQ3=np.sqrt(3.)
MODELS=("loop_B","loop_H","dp_B","dp_H","dp_negH")


def table(name,rows):
    with (HERE/name).open("w",newline="",encoding="utf8") as stream:
        writer=csv.DictWriter(stream,fieldnames=rows[0])
        writer.writeheader();writer.writerows(rows)


def save(name,info):
    (HERE/name).write_text(json.dumps(info,indent=2,allow_nan=False)+"\n",encoding="utf8")


@lru_cache(None)
def data(iso):
    return np.loadtxt(HERE/f"isospin-{iso}.csv",delimiter=",",skiprows=1).T


@lru_cache(None)
def cubic(iso,index):
    values=data(iso)
    return PchipInterpolator(values[0],values[index],extrapolate=False)


def iso_wave(energy,iso,linear=False):
    nodes,real,imag=data(iso)
    assert np.all((energy>=nodes[0])&(energy<=nodes[-1]))
    if linear:
        return np.interp(energy,nodes,real)+1j*np.interp(energy,nodes,imag)
    return cubic(iso,1)(energy)+1j*cubic(iso,2)(energy)


def physical(first,second,charged):
    return -(SQ2*first+second)/SQ3 if charged else SQ2*(-first+SQ2*second)/SQ3


def kinematics(energy,charged):
    beta=np.sqrt(1-(2*MASS/energy)**2)
    return beta,(1+int(charged))*np.pi*alpha**2*NB*beta/energy**2


def born_s(beta):
    return (1-beta**2)*np.arctanh(beta)/beta


def p2(angle):
    return (3*angle**2-1)/2


@lru_cache(None)
def energy_rule(low,high,order):
    knots=np.unique(np.r_[low,high,data(0)[0],data(2)[0],elastic.REAL[0],elastic.IMAG[0]])
    edges=knots[(knots>=low)&(knots<=high)]
    assert edges[0]==low and edges[-1]==high
    return elastic.gauss(edges,order)


def pieces(energy,angle,charged,linear=False):
    beta,rate=kinematics(energy,charged)
    same0,op0=angular.amplitudes(energy,angle,"charged" if charged else "neutral",False)
    born=(1-beta**2)/(1-beta**2*angle**2)
    angular_tail=born-born_s(beta) if charged else np.zeros_like(angle)
    loop=complex((same0-angular_tail).mean())
    assert np.max(abs(same0-angular_tail-loop))<2e-14
    dp=physical(iso_wave(energy,0,linear),iso_wave(energy,2,linear),charged)
    target=angular.read_wave(energy)
    base=elastic.born(energy**2)
    kept=angular_tail+(10/3)*(target-base)*p2(angle)
    flipped=angular_tail+(10/3)*(-target-base)*p2(angle)
    other=np.broadcast_to(op0,angle.shape)
    rate_of=lambda wave:rate*(abs(wave)**2+abs(other)**2)
    vals=[rate_of(loop+angular_tail),rate_of(loop+kept),rate_of(dp+angular_tail),rate_of(dp+kept),rate_of(dp+flipped)]
    vals+=list(np.broadcast_arrays(rate*abs(dp)**2,rate*2*(dp.conjugate()*kept).real,
                                  rate*abs(kept)**2,rate*abs(other)**2))
    return np.asarray(vals)


def controls():
    output=[]
    for iso in (0,2):
        energy,real,imag=data(iso)
        selected=(energy>=.5)&(energy<=.8)
        mass,rate=np.loadtxt(HERE/f"sigma-{iso}.csv",delimiter=",",skiprows=1).T
        for val,source in zip(energy[selected],(real+1j*imag)[selected]):
            calc=kinematics(val,True)[1]*abs(source)**2
            published=np.interp(val,mass,rate)
            output.append(dict(isospin=iso,W_GeV=val,from_argand_nb=calc,figure16_nb=published,delta_nb=calc-published))
    assert max(abs(row["delta_nb"]) for row in output)<.17
    table("normalization-check.csv",output)
    samples,weights=roots_legendre(80); angles=(1+samples)/2
    errors=[]
    for energy in (.555,.61,.715,.795):
        beta,_=kinematics(energy,True)
        initial=born_s(beta)
        assert abs(physical(-np.sqrt(2/3)*initial,-initial/SQ3,True)-initial)<3e-14
        assert abs(physical(-np.sqrt(2/3)*initial,-initial/SQ3,False))<3e-14
        projected=0j
        for channel,factor in ((True,1),(False,.5)):
            pol=physical(iso_wave(energy,0),iso_wave(energy,2),channel)
            rest=((1-beta**2)/(1-beta**2*angles**2)-initial) if channel else 0.
            same=pol+rest+(10/3)*(angular.read_wave(energy)-elastic.born(energy**2))*p2(angles)
            projected+=factor*weights@(same*p2(angles))/2
            assert abs(weights@same/2-pol)<2e-14
        errors.append(abs(projected-angular.read_wave(energy)))
    assert max(errors)<2e-14
    return dict(max_fig16_nb=max(abs(row["delta_nb"]) for row in output),max_D_wave_change=max(errors))

