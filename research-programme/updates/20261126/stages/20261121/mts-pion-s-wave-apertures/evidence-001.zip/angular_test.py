import csv
import numpy as np
from waves import HERE,PRIOR,MODELS,angular,controls,energy_rule,pieces,roots_legendre,save,table

KEYS=MODELS+("dp_S_sq","dp_S_interference","fixed_same_remainder_sq","opposite_sq")


def integrate_bins(channel,low,high,left,right,order,linear=False):
    nodes,weights=roots_legendre(12)
    angle=(left[:,None]+right[:,None]+(right-left)[:,None]*nodes)/2
    energies,ew=energy_rule(low,high,order)
    summed=np.zeros((len(KEYS),len(left)))
    for energy,weight in zip(energies,ew):
        vals=pieces(energy,angle,channel=="charged",linear)
        summed+=weight*(vals@weights/2)
    return summed/(high-low)


def neutral_contrast(left,right,vals,stat,systematic,models):
    power=lambda degree:(right**(degree+1)-left**(degree+1))/((degree+1)*(right-left))
    second=(3*power(2)-1)/2
    square=(9*power(4)-6*power(2)+1)/4
    design=np.array([np.ones_like(left),second,square]).T
    cleaned=design/stat[:,None]
    coef=np.linalg.pinv(cleaned)[2]/stat
    assert np.max(abs(coef@design-[0,0,1]))<5e-11
    evidence=coef@vals
    sigma=np.linalg.norm(coef*stat)
    sysbox=abs(coef)@systematic
    coeffs={name:float(coef@models[idx]) for idx,name in enumerate(MODELS)}
    assert abs(coeffs["dp_H"]-coeffs["loop_H"])<1e-8 and abs(coeffs["dp_B"])<1e-8
    return dict(c_obs_nb=evidence,c_stat_if_independent=sigma,c_sys_box=sysbox,
                c_all_errors_box=abs(coef)@(stat+systematic),**{"c_"+name:val for name,val in coeffs.items()},
                sign_separation_over_stat=abs(coeffs["dp_H"]-coeffs["dp_negH"])/sigma)


def run():
    checked=controls()
    with (PRIOR/"angular-comparison.csv").open() as stream:
        earlier=list(csv.DictReader(stream))
    data=angular.dataset()
    rows=[]; summaries=[]; contrast=[]
    for channel,low,high in sorted({row[:3] for row in data}):
        group=[row for row in data if row[:3]==(channel,low,high)]
        left,right,obs,stat,sys=[np.array([row[idx] if row[idx] is not None else 0. for row in group]) for idx in range(3,8)]
        width=right-left;aperture=right[-1]
        assert left[0]==0 and np.allclose(right[:-1],left[1:],atol=1e-14)
        vals=integrate_bins(channel,low,high,left,right,6)
        coarse=integrate_bins(channel,low,high,left,right,4)
        alternative=integrate_bins(channel,low,high,left,right,6,True)
        for idx,source in enumerate(group):
            row=dict(channel=channel,W_low=low,W_high=high,z_low=left[idx],z_high=right[idx],
                     observed_nb_per_z=obs[idx],stat=stat[idx],sys=source[-1],**dict(zip(KEYS,vals[:,idx])),
                     dp_H_linear_interp=alternative[3,idx],quadrature_change=vals[3,idx]-coarse[3,idx])
            ref=next(v for v in earlier if v["channel"]==channel and float(v["W_lo"])==low and float(v["z_lo"])==left[idx])
            row["replay_difference"]=vals[1,idx]-float(ref["replace_D"])
            rows.append(row)
        sector=dict(channel=channel,W_low=low,W_high=high,aperture=aperture)
        total=np.r_[obs@width,vals@width]
        allvals=np.vstack((obs,vals[:len(MODELS)]))
        angular_mean=(right**3-left**3)/(3*width)
        moment=(3*angular_mean-1)/2
        centered=moment-(aperture**2-1)/2
        assert abs(centered@width)<1e-14
        srow=dict(**sector,observed=total[0],**dict(zip(KEYS,total[1:])),
                  dp_H_linear_interp=alternative[3]@width)
        for idx,name in enumerate(("observed",)+MODELS):
            srow["shape_TV_"+name]=.5*width@abs(allvals[idx]/total[idx]-obs/total[0])
            srow["centered_P2_"+name]=width@(centered*allvals[idx])/total[idx]
        summaries.append(srow)
        if channel=="neutral":
            contrast.append(dict(**sector,**neutral_contrast(left,right,obs,stat,sys,vals)))
    assert len(rows)==148 and len(contrast)==10 and len(summaries)==12
    checked.update(bins=len(rows),max_quad=max(abs(row["quadrature_change"]) for row in rows),
                   max_saved_difference=max(abs(row["replay_difference"]) for row in rows),
                   max_interp_bin_difference=max(abs(row["dp_H"]-row["dp_H_linear_interp"]) for row in rows))
    assert checked["max_quad"]<1e-5 and checked["max_saved_difference"]<.001
    assert max(abs(row["dp_H"]-sum(row[k] for k in KEYS[-4:])) for row in rows)<1e-10
    for channel in ("charged","neutral"):
        subset=[row for row in summaries if row["channel"]==channel]
        for key in ("loop_H","dp_H","dp_B","dp_negH"):
            checked[channel+"_"+key+"_rate_MAE_nb"]=np.mean([abs(row[key]-row["observed"]) for row in subset])
            checked[channel+"_"+key+"_mean_shape_TV"]=np.mean([row["shape_TV_"+key] for row in subset])
    floor=[]
    for low in sorted({row["W_low"] for row in rows if row["channel"]=="charged"}):
        group=[row for row in rows if row["channel"]=="charged" and row["W_low"]==low]
        width=np.array([row["z_high"]-row["z_low"] for row in group])
        born=np.array([row["opposite_sq"] for row in group])
        for box in (0,1):
            allowed=np.array([row["observed_nb_per_z"]+box*row["stat"] for row in group])
            fraction=np.clip(np.sqrt(allowed/born),0,1)
            norm=np.sqrt(width@(born*(1-fraction)**2)/(width@born))
            pooled=max(0.,1-np.sqrt((width@allowed)/(width@born)))
            assert norm>=pooled-1e-14 and max(born*fraction**2-allowed)<1e-12
            floor.append(dict(W_lo=low,W_hi=group[0]["W_high"],stat_box=box,
                    born_opposite_aperture_nb=width@born,max_any_opposite_nb=width@allowed,
                    min_intensity_fraction_lost=max(0.,1-width@allowed/(width@born)),
                    min_pooled_relative_norm_change=pooled,min_binwise_relative_norm_change=norm,
                    excess_bins=int(sum(born>allowed)),total_bins=len(group)))
    table("charged-helicity-floor.csv",floor)
    table("bin-comparison.csv",rows);table("aperture-results.csv",summaries)
    table("neutral-S-independent.csv",contrast);save("checks.json",checked)
    print(checked)


if __name__=="__main__":
    run()

