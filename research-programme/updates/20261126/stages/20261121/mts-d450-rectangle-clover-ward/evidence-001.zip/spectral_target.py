"""Transport two-current inputs to the longitudinal stress target; no fitted MTS parameter."""
from empirical import EE, HIGH, LOW, ROOT, save, unpack
from fractions import Fraction
from itertools import combinations
import json
import re
import sys
import numpy as np

MEMBER = "s05_running.tex"
VERSION = "2511.01623v2"
ARCHIVE_HASH = "af0d2135cbda9b3f02cca1801f727f867512f38e41e1d8364efba2f43b6207a8"


def acquire():
    texts, receipt = unpack(VERSION, [MEMBER])
    assert receipt["archive_sha256"] == ARCHIVE_HASH
    text = texts[MEMBER]
    equation = text.split(r"\label{eq:pade_pigg}")[1].split(r"\end{equation}")[0]
    parameters = [float(value) for value in re.findall(r"(-?\d+\.\d+)x", equation)]
    matrix = text.split(r"\label{eq:pade_pigg_corr_matrix}")[1].split(r"\end{equation}")[0]
    assert r"\times 10^{-6}" in matrix
    matrix = matrix.split(r"\begin{bmatrix}")[-1].split(r"\end{bmatrix}")[0]
    covariance = [[float(value) * 1.e-6 for value in row.split("&")] for row in matrix.strip().split(r"\\")]
    tab = text.split(r"\label{tab:dalpha_sin2_space_like_resl}")[0].rsplit(r"\begin{tabular}", 1)[1]
    assert r"\Delta\alpha_{\mathrm{had}}^{(5)}" in tab and "isospin-symmetric" in tab
    knots = re.findall(r"\$([\d.]+)\$\s*&\s*([\d.]+)(?:\([\d.]+\)){3}\[([\d.]+)\]\s*&", tab)
    assert len(parameters) == 5 and len(knots) == 11 and len(covariance) == 5
    data = dict(provenance=receipt, parameters=parameters, covariance=covariance,
                table_1e_minus5=knots, table_label="tab:dalpha_sin2_space_like_resl")
    save("current-hvp-inputs.json", json.dumps(data, indent=2) + "\n")


def stencil(point, knots):
    weights = {}
    for node in knots:
        weight = Fraction(1)
        for other in knots:
            if other != node:
                weight *= (point-other)/(node-other)
        weights[node] = weight
    error_sign = (-1)**(len(knots)+1) * np.prod([point-node for node in knots])
    assert error_sign != 0 and sum(weights.values()) == 1
    return "lower" if error_sign > 0 else "upper", weights


def candidates(point, nodes):
    subset = sorted(nodes, key=lambda x: (abs(x-point), x))[:5]
    out = {"lower": [], "upper": []}
    for count in (2, 3, 4):
        for chosen in combinations(sorted(subset), count):
            kind, weights = stencil(point, chosen)
            for pole in (Fraction(1, 100), Fraction(1), Fraction(10**3)):
                kernel = lambda x: x/(pole+x)
                residual = kernel(point)-sum(value*kernel(node) for node, value in weights.items())
                predicted = (-1)**(count+1)*pole/(pole+point)*np.prod([(point-node)/(pole+node) for node in chosen])
                assert residual == predicted and (residual > 0) == (kind == "lower")
            out[kind].append(weights)
    return out


def enclose(data, use_errors):
    central = {Fraction(node): Fraction(val) for node, val, err in data}
    widths = {Fraction(node): Fraction(err) if use_errors else 0 for node, val, err in data}
    central[Fraction(0)] = widths[Fraction(0)] = Fraction(0)
    low, high = (candidates(Fraction(str(point)), central) for point in (LOW, HIGH))
    answers = {}
    for side, opposite in (("lower", "upper"), ("upper", "lower")):
        optimal = None
        for large in high[side]:
            for small in low[opposite]:
                weights = {node: large.get(node, 0)-small.get(node, 0) for node in central}
                estimate = sum(val*central[node] for node, val in weights.items())
                margin = sum(abs(val)*widths[node] for node, val in weights.items())
                bound = estimate-margin if side == "lower" else estimate+margin
                if optimal is None or (bound > optimal[0] if side == "lower" else bound < optimal[0]):
                    optimal = (bound, {str(node): str(val) for node, val in weights.items() if val})
        answers[side] = dict(delta=float(optimal[0])*1.e-5, rational_weights_by_GeV2=optimal[1])
    return answers


def run():
    data = json.loads((ROOT/"current-hvp-inputs.json").read_bytes())
    assert data["provenance"]["archive_sha256"] == ARCHIVE_HASH
    params = np.asarray(data["parameters"])
    covariance = np.asarray(data["covariance"])
    assert np.array_equal(covariance, covariance.T) and min(np.linalg.eigvalsh(covariance)) > 0
    def hvp(point, coeff):
        numer = point**np.arange(1, 3)
        denom = point**np.arange(1, 4)
        value = numer @ coeff[:2]
        scale = 1 + denom @ coeff[2:]
        return value/scale, np.r_[numer/scale, -value*denom/scale**2]
    high, dhigh = hvp(HIGH, params)
    low, dlow = hvp(LOW, params)
    factor = LOW*HIGH/(2*(HIGH-LOW))
    gradient = EE*factor*(dhigh-dlow)
    for axis in range(len(params)):
        displaced = params + 1.e-18j*np.eye(len(params))[axis]
        numerical = EE*factor*(hvp(HIGH, displaced)[0]-hvp(LOW, displaced)[0]).imag/1.e-18
        np.testing.assert_allclose(numerical, gradient[axis], rtol=2.e-12)
    estimate = EE*factor*(high-low)
    result = dict(pade_metric_GeV2=estimate, pade_propagated_error_GeV2=np.sqrt(gradient@covariance@gradient))
    for key, box in (("fixed_central_knots", False), ("reported_marginal_error_box", True)):
        bounds = enclose(data["table_1e_minus5"], box)
        interval = [factor*bounds[side]["delta"] for side in ("lower", "upper")]
        result[key] = dict(interval_GeV2=interval, ordered=bool(interval[0] <= interval[1]), witnesses=bounds)
        if box:
            assert interval[0] < estimate < interval[1]
    save("spectral-anchor.json", json.dumps(result, indent=2) + "\n")
    print(estimate, result["pade_propagated_error_GeV2"], *(result[key]["interval_GeV2"] for key in ("fixed_central_knots", "reported_marginal_error_box")))


if __name__ == "__main__":
    if sys.argv[1:] == ["--acquire"]:
        acquire()
    run()
