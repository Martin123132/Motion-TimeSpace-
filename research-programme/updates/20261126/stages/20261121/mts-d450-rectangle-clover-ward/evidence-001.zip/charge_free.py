"""Transfer a charge-independent longitudinal matching observable to periodic lattice momenta."""
from base import ROOT, config, json, np, table
from empirical import EE, HIGH, LOW
from maxwell_ward import nonforward, read_hvp, shapes
import csv

SCALE_FM = .0756
HBARC = .1973269804


def maxwell(left, right, spatial):
    total = [0j, 0., 0.]
    transfer = -(left+right)
    magnetic = 1j*(8*np.sin(transfer)-np.sin(2*transfer))/6
    for extent, width, coeff in shapes("D450-shape"):
        weight = float(coeff)*width**2
        common = sum(abs(np.expm1(1j*extent*value))**2 for value in spatial)
        electric = np.expm1(1j*extent*left)*np.expm1(1j*extent*right)
        total[0] += weight*(-np.expm1(1j*extent*transfer)*electric/extent + magnetic*common)
        for idx, freq in enumerate((left,right), 1):
            total[idx] += weight*(abs(np.expm1(1j*extent*freq))**2 + common)
    return np.array(total)


def combinations(observed, template, left, right):
    stress, small, large = observed
    base_stress, base_small, base_large = template
    improved_stress = stress-base_stress*small/base_small
    improved_hvp = large-base_large*small/base_small
    defect = improved_stress+1j*left*improved_hvp
    uncorrected = stress+1j*(left*large+right*small)
    pure = base_stress+1j*(left*base_large+right*base_small)
    assert abs(defect-(uncorrected-pure*small/base_small))<2.e-13
    return np.array((improved_stress, improved_hvp, defect))


def check_fixture():
    with (ROOT/"colored-direct-0.csv").open() as stream:
        names = [item for item in csv.DictReader(stream) if item["geometry"]=="lapse" or item["legs"]=="2"]
    observed = np.zeros(3, complex)
    assert [row["pt"] for row in names] == ["-1", "-1", "-2"]
    for case, weight in enumerate((.4,.6)):
        with (ROOT/f"colored-direct-{case}.csv").open() as stream:
            indexed = {(row["geometry"],row["pt"],row["kt"],row["n"]):row for row in csv.DictReader(stream)}
        for idx, key in enumerate(names):
            row=indexed[tuple(key[field] for field in ("geometry","pt","kt","n"))]
            observed[idx] += weight*complex(float(row["re"]),float(row["im"]))
    left, right, spatial = np.pi/5*np.array([-1,-2,2])
    template = maxwell(left, right, [spatial,0.])
    shear, pinch = nonforward(5,-.5,-1,1,"D450-shape",True)
    np.testing.assert_allclose(template,[shear,read_hvp(5,-.5,1,"D450-shape"),read_hvp(5,-1,-1,"D450-shape")],atol=2.e-14)
    assert abs(pinch-1j*(left*template[2]+right*template[1]))<2.e-14
    result=combinations(observed,template,left,right)
    for offset in (-7.3,.1,12.4):
        np.testing.assert_allclose(combinations(observed+offset*template,template,left,right),result,atol=2.e-13,rtol=0)
    assert np.max(abs(combinations(template,template,left,right)))<2.e-14
    assert abs(result[-1])>.01
    return abs(result[-1])


def compute():
    physical = json.loads((ROOT/"current-hvp-inputs.json").read_bytes())
    params = np.asarray(physical["parameters"])
    cov = np.asarray(physical["covariance"])
    def running(point):
        numer = point**np.arange(1,3)
        denom = point**np.arange(1,4)
        bottom = 1+denom@params[2:]
        value = numer@params[:2]/bottom
        return EE*value, EE*np.r_[numer/bottom,-value*denom/bottom]
    nt, nx, ny, nz = config()["shape"]
    assert nt == 2*nx and nx == ny == nz
    conversion = HBARC/SCALE_FM
    freq = 2*np.pi/nt
    limit = int(12**.5/(freq*conversion))
    best = {}
    for smaller in range(1,limit+1):
        for larger in range(smaller+1,limit+1):
            for horizontal in range(limit//2+1):
                for vertical in range(horizontal+1):
                    transverse = 4*(horizontal**2+vertical**2)
                    lo,hi = [(num**2+transverse)*(freq*conversion)**2 for num in (smaller,larger)]
                    if not .25 <= lo < hi <= 12 or not transverse:
                        continue
                    distance = np.log(lo/LOW)**2+np.log(hi/HIGH)**2
                    options = ["nearest"]+(["nearest_continuum_Maxwell_zero"] if smaller*larger==transverse else [])
                    for label in options:
                        candidate=(distance,smaller,larger,horizontal,vertical,lo,hi)
                        if label not in best or candidate<best[label]:
                            best[label]=candidate
    records=[]
    for name,(distance,smaller,larger,horizontal,vertical,lo,hi) in best.items():
        left, right = -smaller*freq,larger*freq
        spatial = 2*freq*np.array([horizontal,vertical])
        transfer = -left-right
        response,small,large = maxwell(left,right,spatial)
        unit_vertex = .5*(left*right+spatial@spatial)*conversion**2
        running_lo, grad_lo = running(lo)
        running_hi, grad_hi = running(hi)
        factor = left*hi/(2*transfer)
        expected = factor*(running_hi-running_lo)
        gradient = factor*(grad_hi-grad_lo)
        template = np.array([2j*transfer*unit_vertex,lo,hi])
        for bare in (-4.,0.,1.,2.4):
            currents = np.array([lo*(bare-running_lo),hi*(bare-running_hi)])
            ward = -1j*(left*currents[1]+right*currents[0])
            obs = np.r_[ward, currents]
            result = combinations(obs,template,left,right)
            assert abs(result[0]/(2j*transfer)-expected)<2.e-14 and abs(result[-1])<2.e-14
        for mass2 in (.13,1.8,7.4):
            mixing = .31
            b_lo,b_hi = [-mixing*momentum/(momentum+mass2) for momentum in (lo,hi)]
            vertex = unit_vertex*(1+b_lo*b_hi+mixing*(b_lo+b_hi))+.5*mass2*b_lo*b_hi
            current_lo = lo*(1+mixing*b_lo)
            assert abs(vertex-unit_vertex*current_lo/lo-factor*mixing*(b_lo-b_hi))<1.e-14
        records.append(dict(selection=name,minus_pt=smaller,kt=larger,nx=horizontal,nz=vertical,
                            low_GeV2=lo,high_GeV2=hi,continuum_unit_Maxwell_metric_GeV2=unit_vertex,
                            lattice_unit_Maxwell_metric_GeV2=(response/(2j*transfer)).real*conversion**2,
                            lattice_ward_defect_reduced_GeV2=((response+1j*(left*large+right*small))/(2j*transfer)).real*conversion**2,
                            continuum_subtracted_metric_GeV2=expected,pade_error_GeV2=np.sqrt(gradient@cov@gradient)))
    assert len(records)==2
    table("periodic-momentum-targets.csv",records)
    print(records)
    print("Maxwell-subtracted coarse fixture Ward defect / site:",check_fixture())


if __name__=="__main__":
    compute()
