from base import *
import itertools
import math
import re
import sys
import tarfile
from scipy.constants import alpha
from sources import fetch

LOW,HIGH=1.81,6.07
EE=4*np.pi*alpha

def unpack(key,member):
    data=fetch("https://arxiv.org/src/"+key,8000000)
    with tarfile.open(fileobj=io.BytesIO(data)) as archive:
        blobs={item:archive.extractfile(item).read() for item in member}
    return {item:blob.decode() for item,blob in blobs.items()},dict(version=key,archive_sha256=sha(data),
                                                                  members={item:sha(blob) for item,blob in blobs.items()})

def error_pair(value):
    val,err=re.fullmatch(r"([\d.]+)\((\d+)\)",value).groups()
    return float(val),int(err)*10**(-len(val.split(".")[1]))

def acquire():
    record,src=unpack("2203.08676v2",["sections/extrapolation.tex","tables/running_results2.csv"])
    main=record["sections/extrapolation.tex"]
    body=main.split(r"\label{eq:approx_gg}")[1].split(r"\end{equation}")[0]
    pairs=[error_pair(item) for item in re.findall(r"\\num\{([\d.]+\(\d+\))\}",body)]
    corr=main.split(r"\label{eq:approx_gg_corr}")[1].split(r"= \begin{pmatrix}")[1].split(r"\end{pmatrix}")[0]
    triangle=[[float(v) for v in line.split("&")] for line in corr.strip().split(r"\\") if line.strip()]
    assert len(pairs)==6 and [len(row) for row in triangle]==list(range(1,7))
    neighbors=[]
    for row in csv.DictReader(io.StringIO(record["tables/running_results2.csv"])):
        point=float(row["Q2GeV"])
        if 1.69<=point<=1.91 or 5.89<=point<=6.21 or point in (1,4):
            neighbors.append(dict(Q2=point,HVP=float(row["gg_mean"])))
    table("published-hvp-knots.csv",neighbors)
    raw,op=unpack("hep-ex/0505072v3",["pr407_journal.tex"])
    text=raw["pr407_journal.tex"]
    assert re.search(r"237\s*\\pm\s*58\s*\\pm\s*43\s*\\pm\s*30",text)
    assert re.search(r"440\s*\\pm\s*58\s*\\pm\s*43\s*\\pm\s*30",text)
    assert "6.07" in text and "1.81" in text
    raw,bot=unpack("2101.08103v2",["upspaper.tex"])
    block=raw["upspaper.tex"]
    start=block.index("4 & 0.0905(23)")
    entries=re.findall(r"(?m)^\s*(4|6|8|10)\s*&\s*([\d.]+\(\d+\))",block[start:start+225])
    assert [int(label) for label,_ in entries]==[4,6,8,10]
    save("hvp-inputs.json",json.dumps(dict(sources=[src,op,bot],hvp_pairs=pairs,corr_triangle=triangle,
                  bottom_G_roots=[error_pair(val) for _,val in entries],OPAL_hadronic=[237,58,43,30],
                  OPAL_total=[440,58,43,30],OPAL_units="1e-5",range_GeV2=[LOW,HIGH]),indent=2)+"\n")

def bottom_interval(values):
    moments=[val**(idx-2)/(9*math.factorial(idx)) for idx,val in zip((4,6,8,10),values)]
    coeffs=[sum(LOW**power*HIGH**(order-power) for power in range(order+1)) for order in range(4)]
    upper=sum((-1)**idx*moments[idx]*coeffs[idx] for idx in (0,1,2))
    lower=upper-coeffs[3]*moments[3]
    return np.array([lower,upper])*EE*(HIGH-LOW)

def evaluate():
    data=json.loads((ROOT/"hvp-inputs.json").read_bytes())
    par,errors=np.array(data["hvp_pairs"]).T
    corr=np.eye(6)
    for idx,row in enumerate(data["corr_triangle"]):
        corr[idx,:idx+1]=corr[:idx+1,idx]=row
    covariance=corr*np.outer(errors,errors)
    assert np.min(np.linalg.eigvalsh(corr))>0
    def hvp(point,parameters=par):
        terms=point**np.arange(1,4)
        num,den=terms@parameters[:3],1+terms@parameters[3:]
        return num/den,np.r_[terms/den,-num*terms/den**2]
    values=[hvp(point) for point in (LOW,HIGH)]
    delta=EE*(values[1][0]-values[0][0])
    gradient=EE*(values[1][1]-values[0][1])
    width=np.sqrt(gradient@covariance@gradient)
    numerical=[]
    for idx in range(6):
        plus=par.copy().astype(complex)
        plus[idx]+=1e-15j
        numerical.append(EE*((hvp(HIGH,plus)[0]-hvp(LOW,plus)[0]).imag/1e-15))
    np.testing.assert_allclose(gradient,numerical,rtol=2e-13)
    with (ROOT/"published-hvp-knots.csv").open() as handle:
        points=np.array([[float(row["Q2"]),float(row["HVP"])] for row in csv.DictReader(handle)])
    interp=EE*np.diff(np.interp([LOW,HIGH],points[:,0],points[:,1]))[0]
    low_neighbors=points[:,0][(points[:,0]>=1.7)&(points[:,0]<=1.91)]
    high_neighbors=points[:,0][(points[:,0]>=5.9)&(points[:,0]<=6.21)]
    assert low_neighbors.min()<=LOW<=low_neighbors.max() and high_neighbors.min()<=HIGH<=high_neighbors.max()
    bottom,berr=np.array(data["bottom_G_roots"]).T
    bmin,bmax=bottom_interval(bottom)
    corners=np.array([bottom_interval(bottom+berr*signs) for signs in itertools.product((-1,1),repeat=4)])
    ptime=-LOW/np.sqrt(LOW+HIGH)
    ktime=HIGH/np.sqrt(LOW+HIGH)
    radius=np.sqrt(LOW*HIGH/(LOW+HIGH))
    qtime=-ptime-ktime
    scale=LOW*HIGH/(2*(HIGH-LOW))
    assert abs(ptime*HIGH+ktime*LOW)<1e-14
    bb=(bmin+bmax)/2
    for mass2 in (.028,.45,1.,4.,13.):
        coupling=.43
        induced=lambda point:-coupling*point/(point+mass2)
        running=lambda point:-coupling*induced(point)
        stress=.5*(ptime*ktime+radius**2)*(1+induced(LOW)*induced(HIGH)+coupling*(induced(LOW)+induced(HIGH)))+.5*mass2*induced(LOW)*induced(HIGH)
        assert abs(stress-scale*(running(HIGH)-running(LOW)))<1e-14
        for offset in (-3.7,0,2.1):
            kernel=lambda point:point*(offset-running(point))
            assert abs(stress+(ptime*kernel(HIGH)+ktime*kernel(LOW))/(2*qtime))<1e-14
    opal=np.array(data["OPAL_hadronic"])*1e-5
    rows=[dict(source="OPAL hadronic after leptonic subtraction",delta=opal[0],metric_AA_GeV2=scale*opal[0]),
          dict(source="Ce et al udsc covariance Padé",delta=delta,metric_AA_GeV2=scale*delta),
          dict(source="udsc by linear interpolation of published knots",delta=interp,metric_AA_GeV2=scale*interp),
          dict(source="udsc plus connected bottom central bracket midpoint",delta=delta+bb,metric_AA_GeV2=scale*(delta+bb))]
    table("physical-ward-targets.csv",rows)
    summary=dict(scale_GeV2=scale,p0_GeV=ptime,k0_GeV=ktime,spatial_GeV=radius,q0_GeV=qtime,
                 OPAL_metric_errors_GeV2=(scale*opal[1:]).tolist(),OPAL_total_error_quadrature_GeV2=scale*np.linalg.norm(opal[1:]),
                 four_flavor_pade_metric_error_linearized_GeV2=scale*width,
                 pade_minus_local_interpolation_GeV2=scale*(delta-interp),
                 bottom_delta_central_moment_bracket=[bmin,bmax],
                 bottom_delta_one_marginal_error_box_not_joint_CI=[corners[:,0].min(),corners[:,1].max()],
                 alpha_used=alpha,metric_vertex="d^3 W / d(g00) dA_y dA_y; canonical photon; euclidean")
    save("physical-uncertainty.json",json.dumps(summary,indent=2)+"\n")
    print(rows,summary)

if __name__=="__main__":
    if "--acquire" in sys.argv:
        acquire()
    evaluate()
