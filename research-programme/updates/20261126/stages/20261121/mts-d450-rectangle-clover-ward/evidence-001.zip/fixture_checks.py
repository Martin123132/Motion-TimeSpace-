"""Exact-source tests and the deliberately non-physical ensemble Ward comparison."""
from colored import Background, Kernel, Probe, analytic, new_links, matrix, lift
from colored import CASES, CHOICES, GAMMA, ID3, LT, LX, MASSES, PAR, ROOT, SITE, SPACE, STEP, VOL, adjoint, banks, csv, np, table

TOL = 2.e-10


def controls():
    bg = Background(new_links(CASES[0][0]))
    clean = Background(np.tile(ID3, (len(SITE), 4, 1, 1)))
    spin = GAMMA[0]@GAMMA[1]@GAMMA[2]@GAMMA[3]
    gamma5 = np.kron(np.eye(len(SITE)), np.kron(spin, ID3))
    base_probe = Probe(-1, -2, 1, "lapse")
    magnetic = Probe(-1, -2, 1, "TT")
    magnetic.legs[:] = 0
    field = 2*np.pi/LX
    magnetic.legs[0, :, 2] = field*SPACE
    flat_color = Kernel(clean, magnetic, "color").blocks(MASSES[0], 1., amps=(0,1,0))[0]
    leaf = -.5j*np.sin(field)*lift(GAMMA[1]@GAMMA[2], np.tile(ID3, (len(SITE), 1, 1)))
    checks = []
    def exact(label, value):
        assert np.isfinite(value) and value < TOL, (label, value)
        checks.append(dict(check=label, absolute_error=value, threshold=TOL))
    reference = matrix(Kernel(bg, base_probe, "color").blocks(MASSES[0], 1.), (1,-1)).toarray()
    for source in CHOICES:
        prefactor = {"color":0., "split":1., "product":PAR["csw"]}[source]
        magnetic_clover = Kernel(clean, magnetic, source).blocks(MASSES[0], 1., amps=(0,1,0))[0]
        exact(source+"_uniform_flux_clover", np.max(abs(magnetic_clover-flat_color-prefactor*leaf)))
        probe = Probe(-1, -2, 1, "lapse")
        kernel = Kernel(bg, probe, source)
        quark = matrix(kernel.blocks(MASSES[0], 1.), (1,-1)).toarray()
        exact(source+"_identical_at_zero", np.max(abs(quark-reference)))
        exact(source+"_gamma5_Hermitian", np.max(abs(gamma5@quark@gamma5 - adjoint(quark))))
        swap = Probe(-2, -1, -1, "lapse")
        direct = sum(analytic(kernel).values())
        exact(source+"_Bose", abs(direct-sum(analytic(Kernel(bg, swap, source)).values())))
        for left,right in (("grad","A"),("A","grad")):
            longitudinal = Kernel(bg, Probe(-1,-2,1,"lapse",left,right), source)
            exact(source+"_"+left+"_"+right, abs(sum(analytic(longitudinal).values())))
        charge, amplitude = 2/3, .13
        potential = np.sin(SITE * 1.127)
        ordinary = Probe(-1,-2,1,"TT")
        ordinary.legs = ordinary.legs.real
        gauged = Probe(-1,-2,1,"TT")
        gauged.legs = ordinary.legs.copy()
        for axis, move in enumerate(STEP):
            gauged.legs[0,:,axis] += potential[move]-potential
        phases = np.repeat(np.exp(1j*charge*amplitude*potential), 12)
        def operator(external):
            return matrix(Kernel(bg, external, source).blocks(MASSES[0], charge, amps=(.021,amplitude,-.09)), (1,-1)).toarray()
        exact(source+"_finite_U1", np.max(abs(operator(gauged)-phases.conj()[:,None]*operator(ordinary)*phases[None,:])))
    table("source-controls.csv", checks)
    return max(row["absolute_error"] for row in checks)


def results():
    averaged = {}
    for case, weight in enumerate((.4,.6)):
        def read(prefix):
            with (ROOT/f"{prefix}-{case}.csv").open() as stream:
                return list(csv.DictReader(stream))
        plain, refined = read("colored-direct"), read("refined-direct")
        fine = {(row["source"],row["geometry"],row["pt"],row["kt"],row["n"]):row for row in refined}
        assert len(plain)==8 and len(fine)==6
        sums = {}
        for row in plain:
            key=tuple(row[label] for label in ("source","geometry","pt","kt","n"))
            answer=complex(float(row["re"]),float(row["im"]))
            if row["legs"]=="2":
                assert float(row["independent_error"])<2.e-7
            else:
                better=fine[key]
                assert max(float(better[label]) for label in ("error_outer","error_inner","radius_difference"))<2.e-7
                assert abs(answer-complex(float(better["direct_real"]),float(better["direct_imag"])))<2.e-7
            averaged[key]=averaged.get(key,0j)+weight*answer
    def value(source,geometry,pt,kt,mode):
        return averaged[source,geometry,str(pt),str(kt),str(mode)]
    shear = value("split","lapse",-1,-2,1)
    pinch = 2j*np.pi/LT*(-value("split","TT",-2,2,-1)-2*value("split","TT",-1,1,1))
    relative=abs(shear+pinch)/abs(pinch)
    indices,weights=banks()[0]
    bank=sum(float(weight)*value("split","TT",-2,-2,mode) for mode,weight in zip(indices,weights))/(2*np.pi/LX)**4
    rows={"lapse_stress":shear,"two_current_pinch":pinch,"Ward_residual":shear+pinch,
          "Ward_relative":complex(relative),"first_TT_bank_lattice":bank}
    for source in CHOICES:
        rows[source+"_TT_at_n1"]=value(source,"TT",-2,-2,1)
    table("synthetic-readouts.csv", [dict(quantity=key,real=result.real,imag=result.imag) for key,result in rows.items()])
    print("Two-history Ward relative residual:",relative,"; first TT bank:",bank)
    return rows


if __name__=="__main__":
    print("Max exact-source error:",controls())
    results()
