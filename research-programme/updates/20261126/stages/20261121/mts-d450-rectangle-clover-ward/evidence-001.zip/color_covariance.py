from action import Background, Kernel, Probe, MASSES, PAR, ID4, SITE, STEP, adjoint, lift, matrix, new_links
from base import np, table
from scipy.linalg import block_diag


def run():
    raw = new_links(852)
    rotations = new_links(194)[:,1]
    rotated = np.empty_like(raw)
    for axis, move in enumerate(STEP):
        rotated[:,axis] = rotations @ raw[:,axis] @ adjoint(rotations[move])
    color_frames = block_diag(*lift(ID4,rotations))
    original, transformed = Background(raw), Background(rotated)
    result = []
    for source in ("color","split","product"):
        probe = Probe(-1,-2,1,"lapse")
        before, after = [Kernel(bg,probe,source) for bg in (original,transformed)]
        args = dict(amps=(.019,.051,-.037))
        def get(kernel):
            return matrix(kernel.blocks(MASSES[0],2/3,**args),(1,-1)).toarray()
        matrix_error = np.max(abs(get(after)-color_frames@get(before)@adjoint(color_frames)))
        action_error = abs(after.gauge(.019)-before.gauge(.019))/ (4*len(SITE))
        assert max(action_error, matrix_error)<2.e-10
        result.append(dict(source=source, finite_color_covariance=matrix_error, rectangular_action_error_per_site=action_error))
    table("color-covariance.csv",result)


if __name__=="__main__":
    run()
