from action import *
import sys

CASES=[(852,.4),(1699,.6)]
CHOICES=("color","split","product")

def pairtrace(left,right):
    return np.einsum("ij,ji->",left,right)

def single_log(kernel,mass,second=False):
    masks=(2,4,6) if second else range(1,8)
    blocks={mask:kernel.blocks(mass,1.,bits=mask) for mask in (0,*masks)}
    jac=np.zeros(3,complex)
    hess=np.zeros(3,complex)
    third=np.zeros(3,complex)
    for twist in TWISTS:
        inv=np.linalg.inv(matrix(blocks[0],twist).toarray())
        dressed={mask:inv@matrix(blocks[mask],twist) for mask in masks}
        for idx,mask in enumerate((1,2,4)):
            if mask in dressed:
                jac[idx]-=np.trace(dressed[mask])
        for idx,(first,last) in enumerate(((2,4),(1,4),(1,2))):
            if first|last in dressed:
                hess[idx]+=-np.trace(dressed[first|last])+pairtrace(dressed[first],dressed[last])
        if not second:
            third[0]-=pairtrace(dressed[1]@dressed[2],dressed[4])+pairtrace(dressed[1]@dressed[4],dressed[2])
            third[1]+=sum(pairtrace(dressed[first],dressed[7-first]) for first in (1,2,4))
            third[2]-=np.trace(dressed[7])
    return jac,hess,third

def analytic(kernel,second=False):
    totals=[np.zeros(3,complex) for idx in range(3)]
    for mass,charges in ((MASSES[0],(2/3,-1/3)),(MASSES[1],(-1/3,))):
        linear=sum(charges)
        squared=sum(charge**2 for charge in charges)
        jets=single_log(kernel,mass,second)
        for idx,factor in enumerate(([len(charges),linear,linear],[squared,linear,linear],squared)):
            totals[idx]+=jets[idx]*factor
    singles,pairs,third=totals
    if second:
        return {"two_current":pairs[0]/VOL,"measure":-singles[1]*singles[2]/VOL}
    glue=kernel.gauge(derivative=True)
    return dict(triangle=third[0]/VOL,contact_pair=third[1]/VOL,contact_triple=third[2]/VOL,
                glue_cov=-glue*pairs[0]/VOL,quark_cov=-np.dot(singles,pairs)/VOL,
                cumulant=(singles[0]+glue)*singles[1]*singles[2]/VOL)

class Direct:
    def __init__(self,kernel):
        self.kernel=kernel
        self.zero=self.action((0,0,0))
        assert abs(np.exp(-1j*self.zero.imag)-1)<2e-9
    def action(self,inputs):
        total=self.kernel.gauge(inputs[0])
        for mass,charge in FLAVORS:
            ops=self.kernel.blocks(mass,charge,amps=inputs)
            total-=sum(slog(matrix(ops,twist)) for twist in TWISTS)
        return total
    def diff(self,step,second):
        legs=2 if second else 3
        total=0j
        for corner in product((-1,1),repeat=legs):
            amps=tuple(step*factor for factor in corner)
            total-=np.prod(corner)*np.expm1(self.zero-self.action((0,*amps) if second else amps))
        return total/((2*step)**legs*VOL)

def run(index):
    seed,_=CASES[index]
    bg=Background(new_links(seed))
    parts=[]
    rows=[]
    configurations=[(choice,"TT",-2,-2,1,False) for choice in CHOICES]
    configurations += [("split","TT",-2,-2,mode,False) for mode in (0,2)]
    configurations += [("split","lapse",-1,-2,1,False),("split","TT",-1,1,1,True),("split","TT",-2,2,-1,True)]
    for choice,geometry,pt,kt,mode,second in configurations:
        kernel=Kernel(bg,Probe(pt,kt,mode,geometry),choice)
        labels=dict(case=index,source=choice,geometry=geometry,pt=pt,kt=kt,n=mode,legs=2 if second else 3)
        pieces=analytic(kernel,second)
        for term,val in pieces.items():
            parts.append(dict(**labels,term=term,real=val.real,imag=val.imag))
        expect=sum(pieces.values())
        direct=Direct(kernel)
        coarse,fine=[direct.diff(step,second) for step in (.014,.007)]
        quarter=direct.diff(.0035,second)
        extra1=(4*fine-coarse)/3
        extra2=(4*quarter-fine)/3
        final=(16*extra2-extra1)/15
        error=abs(final-expect)
        rows.append(dict(**labels,re=expect.real,im=expect.imag,step014_error=abs(coarse-expect),
                         fourth_error=abs(extra1-expect),independent_re=final.real,independent_im=final.imag,
                         independent_error=error))
        print(index,choice,geometry,pt,kt,mode,"error",error,flush=True)
    table(f"colored-parts-{index}.csv",parts)
    table(f"colored-direct-{index}.csv",rows)

if __name__=="__main__":
    run(int(sys.argv[1]))
