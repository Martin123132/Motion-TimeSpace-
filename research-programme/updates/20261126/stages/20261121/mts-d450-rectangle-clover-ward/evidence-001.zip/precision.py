from colored import *

def read(case):
    with (ROOT/f"colored-direct-{case}.csv").open() as stream:
        return list(csv.DictReader(stream))

def run(case):
    bg=Background(new_links(CASES[case][0]))
    out=[]
    for row in read(case):
        pt,kt,mode,legs=(int(row[key]) for key in ("pt","kt","n","legs"))
        if legs==2:
            continue
        kernel=Kernel(bg,Probe(pt,kt,mode,row["geometry"]),row["source"])
        direct=Direct(kernel)
        expected=complex(float(row["re"]),float(row["im"]))
        readings=[]
        for radius in (.010,.008):
            angles=np.exp(1j*np.arange(6)*np.pi/6)
            readings.append(sum(direct.diff(radius*angle,False) for angle in angles)/len(angles))
        errors=[abs(item-expected) for item in readings]
        out.append(dict(case=case,source=row["source"],geometry=row["geometry"],pt=pt,kt=kt,n=mode,
                        direct_real=readings[-1].real,direct_imag=readings[-1].imag,
                        error_outer=errors[0],error_inner=errors[1],radius_difference=abs(readings[0]-readings[1])))
        print("projected source derivative",case,row["source"],row["geometry"],mode,errors,flush=True)
    table(f"refined-direct-{case}.csv",out)
    assert max(max(row["error_outer"],row["error_inner"],row["radius_difference"]) for row in out)<2e-7

if __name__=="__main__":
    run(int(sys.argv[1]))
