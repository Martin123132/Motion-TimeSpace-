from base import *
from itertools import product
from scipy.linalg import expm
from scipy.sparse import bsr_matrix
from scipy.sparse.linalg import splu

PAR=config()
LT,LX=10,5
COORD=np.array(list(product(range(LT),range(LX))))
CLOCK,SPACE=COORD.T
SITE=np.arange(LT*LX)
VOL=len(SITE)*4
STEP=[((CLOCK+1)%LT)*LX+SPACE,CLOCK*LX+(SPACE+1)%LX,SITE,SITE]
BACK=[np.argsort(shift) for shift in STEP]
ID4=np.eye(4)
ID3=np.eye(3)
ID12=np.eye(12)
PAULI=(np.array([[0,1],[1,0]]),np.array([[0,-1j],[1j,0]]),np.diag([1,-1]))
GAMMA=[np.kron(PAULI[0],mat) for mat in PAULI]+[np.kron(PAULI[1],np.eye(2))]
ETA=(0,0,-1,1)
NEIGH=np.stack((SITE,STEP[0],BACK[0],STEP[1],BACK[1]),axis=1)
ORDER=np.argsort(NEIGH,axis=1)
COLS=np.take_along_axis(NEIGH,ORDER,axis=1).astype(np.int32).ravel()
PTR=np.arange(0,len(SITE)*5+1,5,dtype=np.int32)
TWISTS=tuple(product((1,-1),repeat=2))
LOOPS=((1,1,5/3),(2,1,-1/12),(1,2,-1/12))
MASSES=[1/(2*kappa)-4 for kappa in PAR["kappas"]]
FLAVORS=list(zip((MASSES[0],MASSES[0],MASSES[1]),(2/3,-1/3,-1/3)))
assert PAR["csw"]==1.915595 and PAR["beta"]==3.46

def lift(spin,color):
    return np.einsum("ij,sab->siajb",spin,color).reshape(len(SITE),12,12)

def adjoint(mat):
    return mat.conj().swapaxes(-1,-2)

def new_links(seed):
    rng=np.random.default_rng(seed)
    links=np.empty((len(SITE),4,3,3),complex)
    for slot in SITE:
        for axis in range(4):
            trial=rng.normal(size=(3,3))+1j*rng.normal(size=(3,3))
            herm=(trial+trial.conj().T)/2
            links[slot,axis]=expm(.38j*(herm-np.trace(herm)*ID3/3))
    return links

def signs(index,repeat=1):
    return [index+1]*repeat

def loop(links,path):
    cursor=SITE.copy()
    result=np.broadcast_to(ID3,(len(SITE),3,3))
    route=[]
    for direction in path:
        axis=abs(direction)-1
        sign=int(np.sign(direction))
        anchor=cursor if sign==1 else BACK[axis][cursor]
        edge=links[anchor,axis]
        result=result@(edge if sign==1 else adjoint(edge))
        route.append((axis,anchor,sign))
        cursor=STEP[axis][anchor] if sign==1 else anchor
    assert np.array_equal(cursor,SITE)
    return result,route

def flux(field,route):
    return sum(sign*field[anchor,axis] for axis,anchor,sign in route)

class Background:
    def __init__(self,links):
        self.links=links
        self.rect=[]
        self.leaves={}
        for axis in range(4):
            for other in range(axis+1,4):
                first,second=axis+1,other+1
                perimeter=[first,second,-first,-second]
                self.leaves[axis,other]=[loop(links,perimeter[offset:]+perimeter[:offset]) for offset in range(4)]
                for wide,high,weight in LOOPS:
                    contour=[first]*wide+[second]*high+[-first]*wide+[-second]*high
                    color,_=loop(links,contour)
                    density=1-np.trace(color,axis1=1,axis2=2).real/3
                    self.rect.append((axis,other,wide if axis==0 else 0,weight,density))

def wave(time,spatial):
    return np.exp(2j*np.pi*(time*CLOCK/LT+spatial*SPACE/LX))

def photon(time,spatial,kind="A"):
    root=wave(time,spatial)
    if kind=="grad":
        return np.stack([root[move]-root for move in STEP],axis=1)
    result=np.zeros((len(SITE),4),complex)
    result[:,2]=root
    return result

class Probe:
    def __init__(self,pt,kt,n,geometry="TT",left="A",right="A"):
        self.pt,self.kt,self.n=pt,kt,n
        self.geometry=geometry
        self.height=wave(-(pt+kt),0)
        self.q=-2*np.pi*(pt+kt)/LT
        self.legs=np.array([photon(pt,n,left),photon(kt,-n,right)])
    def site(self):
        if self.geometry=="TT":
            return np.zeros_like(self.height)
        return self.height*1j*(8*np.sin(self.q)-np.sin(2*self.q))/6
    def measure(self,axis,other=None,extent=1,operator="frame"):
        if self.geometry=="TT":
            if other is None:
                power=ETA[axis] if operator=="wilson" else ETA[axis]/2
                return "exp",power*self.height
            if operator=="face":
                centre=np.exp(.5j*extent*self.q)
                factor=centre*(1+2*np.cos(.5*extent*self.q))/3
                return "exp",(ETA[axis]+ETA[other])*self.height*factor
            return "exp",.5*(ETA[axis]+ETA[other])*self.height
        if other is None and axis==0:
            return ("inverse",self.height*np.expm1(1j*self.q)) if operator=="wilson" else ("linear",0*self.height)
        if other is not None and axis==0:
            return ("inverse",self.height*np.expm1(1j*self.q*extent)/extent) if operator=="face" else ("linear",0*self.height)
        return "linear",self.site()

def metric(profile,amplitude,derivative):
    scheme,coefficient=profile
    if derivative is not None:
        return (-coefficient if scheme=="inverse" else coefficient) if derivative else np.ones_like(coefficient)
    return np.exp(amplitude*coefficient) if scheme=="exp" else (
        1/(1+amplitude*coefficient) if scheme=="inverse" else 1+amplitude*coefficient)

def phase(coeffs,amplitudes,bits):
    if bits is not None:
        result=np.ones(len(SITE),complex)
        for index in (0,1):
            if bits & (2<<index):
                result*=coeffs[index]
        return result
    return np.exp(amplitudes[1]*coeffs[0]+amplitudes[2]*coeffs[1])

class Kernel:
    def __init__(self,bg,probe,completion):
        self.bg,self.probe,self.completion=bg,probe,completion
        self.leaves={}
        for pair,leaves in bg.leaves.items():
            self.leaves[pair]=[(color,np.array([flux(leg,route) for leg in probe.legs])) for color,route in leaves]
    def gauge(self,amplitude=0.,derivative=None):
        return 4*PAR["beta"]*sum(weight*np.dot(density,metric(self.probe.measure(axis,other,extent,"face"),amplitude,derivative))
                                   for axis,other,extent,weight,density in self.bg.rect)
    def blocks(self,mass,charge,amps=(0.,0.,0.),bits=None):
        height,_,_=amps
        has_h=None if bits is None else bool(bits&1)
        has_photon=bits is not None and bits&6
        site_weight=metric(("linear",self.probe.site()),height,has_h)
        diag=np.zeros((len(SITE),12,12),complex)
        if not has_photon:
            diag+=mass*site_weight[:,None,None]*ID12
        plus,minus=[],[]
        for axis in range(4):
            ww=metric(self.probe.measure(axis,operator="wilson"),height,has_h)
            frame=metric(self.probe.measure(axis),height,has_h)
            if not has_photon:
                diag+=(.5*(ww+ww[BACK[axis]]))[:,None,None]*ID12
            link=self.bg.links[:,axis]
            wrap=np.where((axis==0)&(CLOCK==LT-1),-1.,1.)
            for sign,group in ((1,plus),(-1,minus)):
                color=link if sign==1 else adjoint(link)
                term=-ww[:,None,None]*lift(ID4,color)+sign*frame[:,None,None]*lift(GAMMA[axis],color)
                photon_phase=phase(sign*1j*charge*self.probe.legs[:,:,axis],amps,bits)
                term*= (.5*wrap*photon_phase)[:,None,None]
                group.append(term if sign==1 else term[BACK[axis]])
        for (axis,other),leaves in self.leaves.items():
            pauli=np.zeros((len(SITE),3,3),complex)
            for color,angles in leaves:
                pos=phase(1j*charge*angles,amps,bits)
                neg=phase(-1j*charge*angles,amps,bits)
                if self.completion=="product":
                    pauli+=PAR["csw"]*(color*pos[:,None,None]-adjoint(color)*neg[:,None,None])
                else:
                    if not has_photon:
                        pauli+=PAR["csw"]*(color-adjoint(color))
                    if self.completion=="split":
                        pauli+=(pos-neg)[:,None,None]*ID3
            pauli*=metric(self.probe.measure(axis,other),height,has_h)[:,None,None]/8
            diag-=.5*lift(GAMMA[axis]@GAMMA[other],pauli)
        return diag,plus,minus

def matrix(blocks,twists):
    diag,plus,minus=blocks
    sy,sz=twists
    data=np.stack((diag+sy*(plus[2]+minus[2])+sz*(plus[3]+minus[3]),plus[0],minus[0],plus[1],minus[1]),axis=1)
    data=data[SITE[:,None],ORDER].reshape(-1,12,12)
    result=bsr_matrix((data,COLS,PTR),shape=(12*len(SITE),12*len(SITE))).tocsc()
    result.eliminate_zeros()
    return result

def parity(perm):
    visited=set()
    count=0
    for start in range(len(perm)):
        if start not in visited:
            count+=1
            label=start
            while label not in visited:
                visited.add(label)
                label=perm[label]
    return (len(perm)-count)%2

def slog(operator):
    decomp=splu(operator)
    diagonal=decomp.U.diagonal()
    angle=sum(np.angle(diagonal))+np.pi*(parity(decomp.perm_r)+parity(decomp.perm_c))
    return sum(np.log(abs(diagonal)))+1j*np.angle(np.exp(1j*angle))
