from base import *
from fractions import Fraction
import sympy as sp

def shapes(action):
    par=config()
    return [(1,1,Fraction(1)),(2,1,Fraction(0)),(1,2,Fraction(0))] if action=="plaquette" else [
        (1,1,Fraction(par["c0"])),(2,1,Fraction(par["c1"])),(1,2,Fraction(par["c1"]))]

def symbolic():
    variable,fraction,step=sp.symbols("u f x",real=True)
    rows=[]
    for name in ("plaquette","D450-shape"):
        loops=shapes(name)
        moments=[sum(ww*length**2*extent**power for extent,length,ww in loops) for power in (2,4,6)]
        assert moments==([1,1,1] if name=="plaquette" else [1,0,-4])
        for bank,(indices,weights) in enumerate(banks(),1):
            vertex=0
            for mode,weight in zip(indices,weights):
                for extent,length,coeff in loops:
                    center=sp.chebyshevt(extent,variable)
                    vertex+=weight*length**2*coeff*2*((1-fraction+fraction*center)*(1-center)-1+sp.chebyshevt(mode*extent,variable))
            leakage=sp.factor(sp.diff(vertex,variable,2).subs(variable,1)/8)
            assert sp.simplify(leakage-moments[1]*(3*fraction-2)/96)==0
            improved=sp.factor(vertex.subs(fraction,sp.Rational(2,3)))
            expected=sum(coeff*length**2*(1-sp.chebyshevt(extent,variable))**3/20 for extent,length,coeff in loops)
            assert sp.simplify(improved-(expected if bank==2 else 0))==0
            rows.append(dict(action=name,bank=bank,leading_false_coefficient=str(leakage),improved_numerator=str(improved),
                             improved_divided_order2=str(moments[2]/Fraction(160) if bank==2 else 0)))
    table("exact-maxwell.csv",rows)

def samples(size):
    clock,radial=np.indices((2*size,size))
    return (clock,radial),2*np.pi/size

def wave(coords,omega,spatial):
    return np.exp(1j*(omega*coords[0]+spatial*coords[1]))

def loop_flux(field,axis,extent,length):
    return length*(np.roll(field,-extent,axis=axis)-field)

def read_hvp(size,temporal,radial,name):
    coords,unit=samples(size)
    field=wave(coords,temporal*unit,radial*unit)
    return sum(float(coeff)*np.mean(abs(loop_flux(field,axis,extent,length))**2)
               for extent,length,coeff in shapes(name) for axis in (0,1))

def tt(size,mode,name,fraction):
    coords,unit=samples(size)
    height=wave(coords,2*unit,0)
    fields=[wave(coords,-unit,sign*mode*unit) for sign in (1,-1)]
    total=0j
    for extent,length,coeff in shapes(name):
        for axis in (0,1):
            corners=(height+np.roll(height,-extent,axis=axis))/2
            center=wave((coords[0]+extent*(axis==0)/2,coords[1]),2*unit,0)
            flux1,flux2=(loop_flux(field,axis,extent,length) for field in fields)
            total-=float(coeff)*np.mean((fraction*corners+(1-fraction)*center)*flux1*flux2)
    return total

def nonforward(size,pt,kt,mode,name,improve):
    coords,unit=samples(size)
    freq=-(pt+kt)
    displacement=wave(coords,freq*unit,0)
    left=wave(coords,pt*unit,mode*unit)
    right=wave(coords,kt*unit,-mode*unit)
    def diff(dist):
        return (np.roll(displacement,-dist,axis=0)-np.roll(displacement,dist,axis=0))/(2*dist)
    magnetic=(4*diff(1)-diff(2))/3 if improve else diff(1)
    shear=0j
    direct=0j
    for extent,length,coeff in shapes(name):
        for axis in (0,1):
            change=magnetic if axis==1 else -(np.roll(displacement,-extent,axis=0)-displacement)/extent
            flux1=loop_flux(left,axis,extent,length)
            flux2=loop_flux(right,axis,extent,length)
            shear+=float(coeff)*np.mean(change*flux1*flux2)
            for original,other,tau in ((left,flux2,pt),(right,flux1,kt)):
                local_lie=displacement*(1j*tau*unit)*original
                direct+=float(coeff)*np.mean(loop_flux(local_lie,axis,extent,length)*other)
    pinch=1j*unit*(pt*read_hvp(size,kt,-mode,name)+kt*read_hvp(size,pt,mode,name))
    assert abs(direct-pinch)<1e-13 and abs(pinch)>1e-12
    return shear,pinch

def run():
    symbolic()
    ttl=[]
    rows=[]
    for name in ("plaquette","D450-shape"):
        for size in (8,16,32,64,128):
            unit=2*np.pi/size
            for fraction in (0.,2/3,1.):
                vals=[tt(size,mode,name,fraction) for mode in range(4)]
                for bank,(indices,weights) in enumerate(banks(),1):
                    readout=sum(float(weight)*vals[idx] for idx,weight in zip(indices,weights))/unit**4
                    if fraction==2/3:
                        prediction=0 if bank==1 else sum(float(coeff)*length**2*(1-np.cos(extent*unit))**3/20
                                                         for extent,length,coeff in shapes(name))/unit**4
                        assert abs(readout-prediction)<1e-10
                    ttl.append(dict(operator=name,Lx=size,bank=bank,fraction=fraction,reading=readout.real,imag=readout.imag))
            for pt,kt,mode in [(-1,-1,1),(-1,-2,1),(-2,-1,1),(-.5,-1.5,2),(-1,-2,0)]:
                for improved in (False,True):
                    stress,pinch=nonforward(size,pt,kt,mode,name,improved)
                    rows.append(dict(operator=name,Lx=size,pt=pt,kt=kt,n=mode,improved=int(improved),
                                     metric_imag=stress.imag,flat_pinch_imag=pinch.imag,
                                     relative_defect=abs((stress+pinch)/pinch)))
    for pt,kt,mode in [(-1,-2,1),(-.5,-1.5,2)]:
        selected=[row for row in rows if row["operator"]=="D450-shape" and row["pt"]==pt and row["kt"]==kt
                  and row["n"]==mode and row["improved"]]
        assert selected[-2]["relative_defect"]/selected[-1]["relative_defect"]>14
    table("rectangular-maxwell.csv",ttl)
    table("nonforward-maxwell-ward.csv",rows)

if __name__=="__main__":
    run()
