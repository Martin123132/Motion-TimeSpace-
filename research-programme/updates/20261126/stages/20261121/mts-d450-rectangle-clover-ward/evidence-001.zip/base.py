import os
for name in ("OPENBLAS_NUM_THREADS","OMP_NUM_THREADS","MKL_NUM_THREADS","NUMEXPR_NUM_THREADS"):
    os.environ[name]="1"
import csv
import hashlib
import io
import json
from pathlib import Path
import numpy as np

ROOT=Path(__file__).resolve().parent
PREV=ROOT.parent/"mts-quark-gluon-mixed-source-20261121"
BANK=ROOT.parent/"mts-mixed-current-weyl-extractor-20261121"/"frozen-projectors.json"

def sha(data):
    return hashlib.sha256(data).hexdigest()

def save(name,data):
    dest=ROOT/name
    raw=data if isinstance(data,bytes) else data.encode()
    if dest.exists():
        if dest.read_bytes()!=raw:
            raise ValueError(f"Replay changed {name}")
    else:
        with dest.open("xb") as stream:
            stream.write(raw)

def table(name,rows):
    out=io.StringIO(newline="")
    writer=csv.DictWriter(out,fieldnames=tuple(rows[0]),lineterminator="\n")
    writer.writeheader()
    writer.writerows(rows)
    save(name,out.getvalue())

def banks():
    from fractions import Fraction
    raw=BANK.read_bytes()
    assert sha(raw)=="acb38f7efd7966cf34d52beebd7449837d3731219bb196504d91881c9eff78db"
    return [(row["indices"],[Fraction(val) for val in row["weights"]]) for row in json.loads(raw)["projectors"]]

def config():
    return json.loads((ROOT/"production.json").read_bytes())
