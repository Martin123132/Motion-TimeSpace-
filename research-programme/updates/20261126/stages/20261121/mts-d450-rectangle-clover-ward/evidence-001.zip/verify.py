"""Seal after all numerical checks; default mode verifies without modifying files."""
import csv
import hashlib
import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
PREVIOUS = ROOT.parent/"mts-quark-gluon-mixed-source-20261121"/"seal.json"
PREVIOUS_SHA = "6fc4df033479fdc484b8c39f797ccad8326c39430d342cb5fa83ba8eee1e0641"


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def run(create):
    assert __debug__ and digest(PREVIOUS)==PREVIOUS_SHA
    previous=json.loads(PREVIOUS.read_bytes())
    for name, pin in previous["files"].items():
        assert digest(PREVIOUS.parent/name)==pin
    for name,pin in previous["source_sha256"].items():
        assert digest(ROOT.parent/name)==pin
    files=sorted(ROOT.iterdir())
    assert not any(path.is_dir() for path in files)
    report={"parent_seal_sha256":PREVIOUS_SHA,"files":{},"csv_rows":{}}
    for path in files:
        if path.name=="seal.json":
            continue
        assert path.suffix in {".py",".json",".csv",".md",".xml"}
        report["files"][path.name]=digest(path)
        if path.suffix==".py":
            compile(path.read_bytes(),str(path),"exec")
        if path.suffix==".csv":
            with path.open(newline="", encoding="utf-8") as stream:
                reader=csv.DictReader(stream)
                rows=list(reader)
                assert rows and len(set(reader.fieldnames))==len(reader.fieldnames)
                for row in rows:
                    assert row.keys()==set(reader.fieldnames) and all(val not in ("",None) for val in row.values())
                report["csv_rows"][path.name]=len(rows)
        if path.suffix==".md":
            for target in re.findall(r"\[[^]\n]*\]\(([^)\s]+)\)",path.read_text(encoding="utf-8")):
                if "://" not in target:
                    assert (ROOT/target).is_file(),target
    expected={"colored-direct-0.csv":8,"colored-direct-1.csv":8,"colored-parts-0.csv":40,
              "colored-parts-1.csv":40,"exact-maxwell.csv":4,"nonforward-maxwell-ward.csv":100,
              "periodic-momentum-targets.csv":2,"physical-ward-targets.csv":4,"published-hvp-knots.csv":9,
              "record-weights.csv":3,"rectangular-maxwell.csv":60,"refined-direct-0.csv":6,
              "refined-direct-1.csv":6,"source-controls.csv":21,"color-covariance.csv":3,"synthetic-readouts.csv":8}
    assert report["csv_rows"]==expected
    def rows(name):
        with (ROOT/name).open(encoding="utf-8") as stream:
            return list(csv.DictReader(stream))
    improved = [float(row["relative_defect"]) for row in rows("nonforward-maxwell-ward.csv") if
                (row["operator"],row["pt"],row["kt"],row["n"],row["improved"])==("D450-shape","-1","-2","1","1")]
    assert len(improved)==5 and improved[-1]<7.e-6 and min(improved[idx]/improved[idx+1] for idx in (2,3))>14
    assert all(float(row["absolute_error"])<float(row["threshold"])==2.e-10 for row in rows("source-controls.csv"))
    for row in rows("color-covariance.csv"):
        assert max(float(row[field]) for field in ("finite_color_covariance","rectangular_action_error_per_site"))<2.e-10
    misses=0
    for case in (0,1):
        original=rows(f"colored-direct-{case}.csv")
        misses+=sum(float(row["independent_error"])>=2.e-7 for row in original)
        assert all(float(row["independent_error"])<2.e-7 for row in original if row["legs"]=="2")
        refined=rows(f"refined-direct-{case}.csv")
        assert all(max(float(row[key]) for key in ("error_outer","error_inner","radius_difference"))<2.e-7 for row in refined)
    assert misses==7
    for row in rows("record-weights.csv"):
        assert row["raw_sha256"]==digest(ROOT/f"record-{row['id']}.xml")
    spec=json.loads((ROOT/"spectral-anchor.json").read_bytes())
    for label in ("reported_marginal_error_box","fixed_central_knots"):
        low,high=spec[label]["interval_GeV2"]
        assert low<spec["pade_metric_GeV2"]<high
    dest=ROOT/"seal.json"
    if create and not dest.exists():
        with dest.open("x",encoding="utf-8",newline="\n") as handle:
            handle.write(json.dumps(report,indent=2,sort_keys=True)+"\n")
    assert json.loads(dest.read_bytes())==report
    print("Verified",len(report["files"]),"files;",sum(expected.values()),"CSV rows; seal",digest(dest))


if __name__=="__main__":
    assert sys.argv[1:] in ([],["--seal"])
    run(sys.argv[1:]==["--seal"])
