from base import *
import re
import sys
import tarfile
import urllib.request
import xml.etree.ElementTree as ET
from decimal import Decimal

MDC="https://www-zeuthen.desy.de/ape-cgi-bin/ildg-mdc.cgi?"
CHAIN="mc://ldg/cls/nf21/D450r010"
DOC="https://luscher.web.cern.ch/luscher/openQCD/openQCD-1.6.tar.gz"

def fetch(url,limit):
    with urllib.request.urlopen(url,timeout=25) as stream:
        data=stream.read(limit+1)
    if len(data)>limit:
        raise ValueError("Size limit exceeded")
    return data

def parse(name):
    return ET.fromstring((ROOT/name).read_bytes())

def one(tree,label):
    vals=tree.findall(".//{*}"+label)
    assert len(vals)==1
    return vals[0].text.strip()

def main(acquire=False):
    if acquire:
        save("ensemble.xml",fetch(MDC+"action=get&collection=ensemble&grid=ldg&id="+CHAIN,40000))
        listing=fetch(MDC+"action=list&collection=config&grid=ldg&id="+CHAIN,500000).decode()
        numbers=sorted(set(int(num) for num in re.findall(r"lfn://ldg/cls/nf21/D450r010/D450r010n([0-9]+)",listing)))
        assert len(numbers)>20
        indices=[numbers[0],numbers[len(numbers)//2],numbers[-1]]
        save("record-selection.json",json.dumps(dict(number_listed=len(numbers),ids=indices,selection="first, median index, last by integer suffix; not a statistical sample"),indent=2)+"\n")
        for num in indices:
            save(f"record-{num}.xml",fetch(MDC+"action=get&grid=ldg&collection=config&id=lfn://ldg/cls/nf21/D450r010/D450r010n"+str(num),16000))
        data=fetch(DOC,3000000)
        with tarfile.open(fileobj=io.BytesIO(data)) as archive:
            members={key:sha(archive.extractfile(next(name for name in archive.getnames() if name.endswith("/"+key))).read())
                     for key in ("doc/dirac.pdf","doc/gauge_action.pdf","modules/sw_term/sw_term.c")}
        save("upstream-version.json",json.dumps(dict(url=DOC,bytes=len(data),sha256=sha(data),members=members),indent=2)+"\n")
    science=parse("ensemble.xml")
    assert one(science,"markovChainURI")==CHAIN
    text=(ROOT/"ensemble.xml").read_text()
    size=science.find(".//{*}size")
    assert [int(one(size,axis)) for axis in "txyz"]==[128,64,64,64]
    glue=science.find(".//{*}treelevelSymanzikGluonAction")
    assert one(glue,"gaugeGroup")=="SU(3)" and one(glue,"normalisation")=="cs_sum_to_one"
    assert [Decimal(one(glue,key)) for key in ("beta","c0","c1","c2","c3")]==list(map(Decimal,["3.46","1.666666666666667","-0.0833333333333333","0","0"]))
    quarks=science.findall(".//{*}npCloverQuarkAction")
    assert [(one(row,"numberOfFlavours"),one(row,"kappa")) for row in quarks]==[("2","0.137126"),("1","0.136420428639937")]
    assert all(one(row,"cSW")=="1.915595" and one(row,"normalisation")=="sqrt2kappa" for row in quarks)
    assert "Periodic boundary conditions" in text and "theta = 0.0,0.0,0.0" in text
    records=[]
    for num in json.loads((ROOT/"record-selection.json").read_bytes())["ids"]:
        tree=parse(f"record-{num}.xml")
        assert one(tree,"markovChainURI")==CHAIN and one(tree,"version")=="1.6"
        assert one(tree,"dataLFN")==f"lfn://ldg/cls/nf21/D450r010/D450r010n{num}"
        est,tm,rat=[Decimal(one(tree,key)) for key in ("RWtotal","RWTM2_EO","RWRAT")]
        assert abs(est/(tm*rat)-1)<Decimal("2e-15")
        records.append(dict(id=num,update=one(tree,"update"),plaquette=one(tree,"avePlaquette"),weight=str(est),
                            twisted_mass=str(tm),strange_rational=str(rat),raw_sha256=sha((ROOT/f"record-{num}.xml").read_bytes())))
    table("record-weights.csv",records)
    save("production.json",json.dumps(dict(chain=CHAIN,shape=[128,64,64,64],beta=3.46,c0="5/3",c1="-1/12",csw=1.915595,
        kappas=[.137126,.136420428639937],flavors=[2,1],quark_temporal_sign=-1,spatial_twists=[0,0,0],
        code="openQCD 1.6 (configuration metadata)",source_metric="not specified by flat chain",
        electromagnetic_clover="not specified by flat chain",archive_glossary="openQCD 2.0 (not executable provenance)"),indent=2)+"\n")
    print("Verified records:",[(row["id"],row["weight"]) for row in records])

if __name__=="__main__":
    main(sys.argv[1:]==["--acquire"])
