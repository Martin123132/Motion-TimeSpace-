"""Resolve the order of limits after the eightfold mesh showed a turnover of the short-time coefficient."""
from material_evolution import *
def run(probe):
    dom=Domain(probe,3,8,0);rows=[]
    for flip in (False,):
        terms=jet(dom,5/3,6)
        for steps in (32,64):
            states=[integrate(dom,arm,active,5/3,steps,.03)[0] for active in (False,True) for arm in ('reset','coupled')]
            for time in states[0]:
                values=endpoint(dom,[s[time] for s in states],6)
                inferred=(values[3]-values[1])*24/time**4
                rows.append(dict(probe=probe,steps=steps,time_Myr=time,inferred=inferred,
                    analytic=sum(terms),fractional_difference=inferred/sum(terms)-1))
    table(ROOT/f'early-p{probe}.csv',rows,True)
if __name__=='__main__':guard();run(int(sys.argv[1]))
