"""Axisymmetric affine material triangles, ideal-gas energy and its first two shape derivatives."""
from gas_inputs import *
from scipy.interpolate import CubicHermiteSpline
from scipy.special import eval_legendre
from functools import lru_cache
from numpy.polynomial.legendre import legvander

def scatter(index,values,size):
    return np.column_stack([np.bincount(index.ravel(),weights=values[:,:,k].ravel(),minlength=size) for k in range(values.shape[-1])])
def poly(ell,mu):
    vv=legvander(mu,int(ell[-1]));v=vv[:,ell];st=np.sqrt(1-mu**2)
    return v,-ell*(vv[:,np.maximum(ell-1,0)]-mu[:,None]*v)/st[:,None]

@lru_cache(maxsize=1)
def gravitational():
    lab=Launch(64);r=np.linspace(5.,9.9,1001);field={}
    for arm in ('reset','coupled','paired'):
        tide=Tides(lab,r,arm);ell=tide.ell;scale=tide.bg.length
        factor=-scale**2*np.sqrt(2*ell+1)
        field[arm]=CubicHermiteSpline(r,tide.val*factor,tide.dr*(factor/scale),axis=0)
    return ell,field
def gravity(pos,arm,tangent=None):
    rad,mu=coord(pos);ell,fields=gravitational();f=fields[arm];assert np.all((rad>f.x[0])&(rad<f.x[-1]))
    cs=np.sqrt(1-mu**2);er=np.column_stack((cs,mu));et=np.column_stack((mu,-cs))
    val,dt=poly(ell,mu);pot=f(rad);der=f(rad,1)
    dot=lambda a,b:np.sum(a*b,axis=1)
    vr=dot(der,val);vt=dot(pot,dt)/rad
    if tangent is None:return dot(pot,val),-vr[:,None]*er-vt[:,None]*et
    dd=-ell*(ell+1)*val-(mu/cs)[:,None]*dt
    rr=dot(f(rad,2),val);rt=(dot(der,dt)-vt)/rad;tt=(vr+dot(pot,dd)/rad)/rad
    ar=dot(er,tangent);at=dot(et,tangent)
    return -(rr*ar+rt*at)[:,None]*er-(rt*ar+tt*at)[:,None]*et

def geometry(pos,idx,direction=None):
    v=pos[idx];r=v[:,:,0];z=v[:,:,1];dr=r[:,1:]-r[:,:1];dz=z[:,1:]-z[:,:1]
    area=(dr[:,0]*dz[:,1]-dr[:,1]*dz[:,0])/2
    dA=np.stack((np.roll(z,-1,axis=1)-np.roll(z,1,axis=1),np.roll(r,1,axis=1)-np.roll(r,-1,axis=1)),axis=2)/2
    factor=4*np.pi/3;sr=np.sum(r,axis=1);grad=factor*sr[:,None,None]*dA
    grad[:,:,0]+=factor*area[:,None]
    vol=factor*area*sr
    assert np.min(vol)>0,'element inversion'
    if direction is None:return vol,grad
    d=direction[idx];u,w=d[:,:,0],d[:,:,1];ds=np.sum(u,axis=1);change=np.sum(d*dA,axis=(1,2))
    ddA=np.stack((np.roll(w,-1,axis=1)-np.roll(w,1,axis=1),np.roll(u,1,axis=1)-np.roll(u,-1,axis=1)),axis=2)/2
    dg=factor*(ds[:,None,None]*dA+sr[:,None,None]*ddA);dg[:,:,0]+=factor*change[:,None]
    return vol,grad,np.sum(grad*d,axis=(1,2)),dg

class Domain:
    def __init__(self,probe,padding,refine,form,stride=1,flip=False):
        self.probe=probe;rad,ang,ir,ia=axes(probe,padding,refine);self.ref=refine
        n=len(rad);rr,aa=np.meshgrid(rad,ang,indexing='ij');self.pos=loc(rr,aa).reshape(-1,2)
        i,j=np.meshgrid(np.arange(n-1),np.arange(n-1),indexing='ij');i=i.ravel();j=j.ravel();node=i*n+j
        corners=np.column_stack([node,node+n,node+n+1,node+1]);which=((i+j+int(flip))%2).astype(bool)
        idx=np.empty((len(node),2,3),int)
        idx[~which]=corners[~which][:,[[0,1,2],[2,3,0]]];idx[which]=corners[which][:,[[0,1,3],[2,3,1]]]
        self.idx=idx.reshape(-1,3);self.size=n*n;self.freeze=((rr==rad[0])|(rr==rad[-1])|(aa==ang[0])|(aa==ang[-1])).ravel()
        orig_i=ir-2-padding+i//refine;orig_j=ia-2-padding+j//refine
        self.coretri=np.repeat((orig_i>=ir-2)&(orig_i<ir+2)&(orig_j>=ia-2)&(orig_j<ia+2),2)
        inode,jnode=np.indices((n,n));low=padding*refine;high=(padding+4)*refine
        self.corenode=((inode>low)&(inode<high)&(jnode>low)&(jnode<high)).ravel()
        self.refvol,_=geometry(self.pos,self.idx);v=self.pos[self.idx];self.tag=np.repeat(banktags()[orig_i,orig_j],2)
        self.shapes=np.array([[2/3,1/6,1/6],[1/6,2/3,1/6],[1/6,1/6,2/3]])
        pts=np.einsum('qa,tad->tqd',self.shapes,v)
        densities=lookup(probe,form,stride)(pts.reshape(-1,2)).reshape(len(v),3,2)
        avg=np.einsum('tqi,tq->ti',densities,pts[:,:,0])/np.sum(pts[:,:,0],axis=1)[:,None]
        self.mass=avg[:,0]*self.refvol;self.thermal=avg[:,1]*self.refvol*CONVERT
        sr=v[:,:,0].sum(axis=1);self.share=(sr[:,None]+v[:,:,0])/(4*sr[:,None])
        self.mn=self.lump(self.mass);self.wmn=self.lump(self.mass*self.tag)
        self.fn=self.wmn/self.mn
        assert self.mn.min()>0 and np.all(self.wmn[~self.freeze]>0),'missing effective material at an interior vertex'
    def lump(self,m):
        return np.bincount(self.idx.ravel(),weights=(m[:,None]*self.share).ravel(),minlength=self.size)
    def forces(self,x,gamma,active,d=None):
        if d is None:vol,grad=geometry(x,self.idx)
        else:vol,grad,dv,dg=geometry(x,self.idx,d)
        j=vol/self.refvol;pressure=(gamma-1)*self.thermal/self.refvol*j**(-gamma)
        each=pressure[:,None,None]*(grad if d is None else dg-gamma*(dv/vol)[:,None,None]*grad)
        own=scatter(self.idx,self.tag[:,None,None]*each,self.size)
        raw=scatter(self.idx,each,self.size)
        denom=self.wmn if active else self.mn
        accel=np.divide((own if active else raw),denom[:,None],out=np.zeros_like(raw),where=denom[:,None]>0)
        return accel,raw,own,each,j
@lru_cache(maxsize=1)
def banktags():return bank()[2]
