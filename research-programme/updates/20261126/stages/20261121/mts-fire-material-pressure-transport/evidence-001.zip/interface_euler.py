"""Planar frozen-trace limit at the two original radial faces; independent conservative grid evolution."""
from gas_inputs import *
from scipy.optimize import brentq
import csv

def star(g,l,r):
    wl,wr=l,r
    if wl==wr:return wl/g,0.,-1.,1.
    def side(p,w):
        p0=w/g;k=p/p0
        if p>p0:return (p-p0)*np.sqrt(2/((g+1)*w*(p+(g-1)/(g+1)*p0)))
        return 2*np.expm1((g-1)/(2*g)*np.log(k))/(g-1)
    pressure=brentq(lambda p:side(p,wl)+side(p,wr),min(l,r)/g,max(l,r)/g,xtol=1e-18,rtol=4e-15)
    speed=(side(pressure,wr)-side(pressure,wl))/2
    front=lambda w:np.sqrt((g+1)/(2*g)*(pressure*g/w)+(g-1)/(2*g)) if pressure>w/g else 1.
    return pressure,speed,-front(wl),front(wr)

def profile(g,l,r,xi):
    pressure,speed,cl,cr=star(g,l,r)
    v=np.zeros_like(xi);p=v.copy()
    for w,sign in ((l,-1),(r,1)):
        use=(xi<speed) if sign<0 else (xi>=speed);s=sign*xi;ps=w/g
        p[use]=ps
        if pressure>ps:
            inner=use&(s<(cr if sign==1 else -cl));p[inner]=pressure;v[inner]=speed
        else:
            cstar=(pressure/ps)**((g-1)/(2*g));tail=sign*speed+cstar
            inner=use&(s<tail);p[inner]=pressure;v[inner]=speed
            fan=use&(s>=tail)&(s<1)
            vel=2*sign*(s[fan]-1)/(g+1);cs=1+(g-1)*sign*vel/2
            v[fan]=vel;p[fan]=ps*cs**(2*g/(g-1))
    return v,p

def grid(g,l,r,n):
    dx=4/n;xx=np.linspace(-2+dx/2,2-dx/2,n);weight=np.where(xx<0,l,r)
    U=np.column_stack([weight,0*xx,weight/(g*(g-1))]);start=U.copy();t=0.
    while t<1:
        vel=U[:,1]/U[:,0];p=(g-1)*(U[:,2]-.5*U[:,1]*vel);c=np.sqrt(g*p/U[:,0])
        alpha=abs(vel)+c;dt=min(.8*dx/alpha.max(),1-t)
        flux=np.column_stack([U[:,1],U[:,1]*vel+p,(U[:,2]+p)*vel])
        inner=(flux[1:]+flux[:-1]-np.maximum(alpha[1:],alpha[:-1])[:,None]*np.diff(U,axis=0))/2
        U-=dt/dx*np.diff(np.vstack((flux[:1],inner,flux[-1:])),axis=0);t+=dt
    v=U[:,1]/U[:,0];p=(g-1)*(U[:,2]-.5*U[:,1]*v);exact,ep=profile(g,l,r,xx);ps,us,_,_=star(g,l,r)
    return dict(cells=n,velocity_L1_relative=np.mean(abs(v-exact))/max(abs(us),1e-100),
        pressure_L1_relative=np.mean(abs(p-ep))/max(abs(l-r)/g,1e-100),
        plateau_velocity_relative=abs(np.mean(v[abs(xx)<.36])-us)/max(abs(us),1e-100),
        impulse_error_fraction=abs(dx*np.sum(U[:,1])-(l-r)/g)/max(abs(l-r)/g,1e-100),
        mass_energy_error=float(max(abs(dx*(U-start).sum(axis=0)[[0,2]]))))
def run():
    outputs=[];checks=[]
    previous=list(csv.DictReader((OLD/'scalar-pressure-circulation.csv').read_text().splitlines()))
    for row in previous:
        probe=int(row['probe']);shape=row['shape'];g=float(row['gamma']);face=float(row['face_kpc'])
        wleft=float(row['weight_minus']);wright=float(row['weight_plus'])
        for point in ('A','B'):
            mu=float(row['mu_'+point]);dens,energy=lookup(probe,int(shape=='wendland'))(loc(np.array([face]),np.array([mu])))[0]
            physical=(g-1)*energy;assert abs(physical/float(row['pressure_'+point])-1)<1e-7
            cs=np.sqrt(g*physical/dens);p,speed,sl,sr=star(g,wleft,wright)
            gap=OBSERVER_R[probe]-face;arrive=gap/(sl*cs*np.sqrt(CONVERT))
            xi=gap/(.24*cs*np.sqrt(CONVERT))
            probe_v=profile(g,wleft,wright,np.array([xi]))[0][0]
            outputs.append(dict(probe=probe,point=point,shape=shape,gamma=g,face_kpc=face,mu=mu,w_left=wleft,w_right=wright,
                raw_density=dens,raw_pressure=physical,raw_sound_kms=cs,
                passive_normal_contact_kms=0.,effective_normal_contact_kms=speed*cs,
                acoustic_linear_kms=cs*np.log(wleft/wright)/(2*g),star_pressure=p*dens*cs**2,
                left_front_kms=sl*cs,right_front_kms=sr*cs,first_arrival_Myr=arrive,
                local_slab_probe_velocity_024=probe_v*cs,required_passive_traction=physical*(wright-wleft)))
        for n in (256,512,1024):
            result=grid(g,wleft,wright,n)
            checks.append(dict(probe=probe,shape=shape,gamma=g,**result))
        _,us,_,_=star(g,wleft,wright);ps2,us2,_,_=star(g,wleft/60,wright/60)
        assert abs(us-us2)<1e-13 and abs(ps2*60-p)<1e-13
    table(ROOT/'interface-solutions.csv',outputs,True);table(ROOT/'interface-grid-check.csv',checks,True)
if __name__=='__main__':guard();run()
