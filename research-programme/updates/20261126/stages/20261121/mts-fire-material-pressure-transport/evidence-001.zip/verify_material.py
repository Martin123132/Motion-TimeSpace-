from material_io import *
import re,csv

def read(file):
    with (ROOT/file).open(newline='') as f:return list(csv.DictReader(f))
def select(rows,**terms):return [r for r in rows if all(str(r[k])==str(v) for k,v in terms.items())]
def one(rows,**terms):
    x=select(rows,**terms);assert len(x)==1,(terms,len(x));return x[0]
def key(probe,mesh,steps):
    return f'p{probe}-b3-m{mesh}-k0-g17-t{steps}-s1-d0-q6.csv'
def run(seal):
    guard()
    for file,want in pinned.items():assert sha(OLD/file)==want,file
    for py in ROOT.glob('*.py'):compile(py.read_bytes(),str(py),'exec')
    assert not any(path.name.endswith(('.work','.pyc','.tmp')) or path.name=='__pycache__' for path in ROOT.rglob('*'))
    tests=json.loads((ROOT/'independent-checks.json').read_bytes())
    assert len(tests)==12 and max(tests.values())<1e-7
    clocks=[];logs=[]
    for f in sorted(ROOT.glob('clock-p*.csv')):
        vals=read(f.name);assert len(vals)==4
        dyn=read(f.name.replace('clock-','transport-'));assert len(dyn)==16
        for i in vals:
            assert float(i['tagged_core_mass'])>0 and all(np.isfinite(float(v)) for k,v in i.items() if k!='shape')
        clocks+=vals;logs+=dyn
    assert len(clocks)==96 and len(logs)==384
    passive=select(logs,fluid='passive');positive=min(float(r['min_volume_ratio']) for r in logs)
    checks=dict(minimum_volume_ratio=positive,largest_complement_error=max(float(r['complementary_force_error']) for r in passive),
        largest_momentum_residual=max(float(r['label_momentum_residual_L1']) for r in passive),
        largest_energy_residual=max(float(r['energy_error_rel']) for r in logs),
        largest_split_work_residual=max(float(r['split_work_rel']) for r in passive))
    assert positive>0 and checks['largest_complement_error']<2e-14 and checks['largest_momentum_residual']<1e-12
    assert checks['largest_energy_residual']<1e-4 and checks['largest_split_work_residual']<1e-3
    fields=read('aperture-fields-4.csv');coarse=read('aperture-fields-2.csv')
    rec=read('reciprocity-4.csv');rco=read('reciprocity-2.csv')
    for r in rec:
        terms={k:r[k] for k in ('arm','material','representation')};s=one(rco,**terms)
        assert abs(float(r['minimum_relative_RMS'])/float(s['minimum_relative_RMS'])-1)<1e-7
        assert 0<float(r['minimum_relative_RMS'])<=float(r['unscaled_acceleration_RMS'])
    for r in fields:
        terms={k:r[k] for k in ('source','material','representation')};s=one(coarse,**terms)
        assert all(abs(float(r[k])/float(s[k])-1)<1e-5 for k in r if k not in terms)
    bars=[]
    for probe in (0,1):
        for ref,n in ((1,128),(2,256),(4,256),(8,512)):
            r=read('clock-'+key(probe,ref,n))[-1]
            bars.append({k:r[k] for k in ('probe','mesh','steps','tagged_core_mass','passive_paired','effective_paired','double_difference','analytic_fourth','inferred_fourth','sheet_readout')})
        base=bars[-4];fine=bars[-1];small=read('clock-'+key(probe,1,64))[-1]
        assert abs(float(small['double_difference'])/float(base['double_difference'])-1)<1e-4
        assert float(fine['analytic_fourth'])<0<float(base['analytic_fourth'])
        assert float(fine['double_difference'])>0
        early=read(f'early-p{probe}.csv');v=[one(early,steps=64,time_Myr=t) for t in (.00375,.0075,.015,.03)]
        assert abs(float(v[0]['fractional_difference']))<.02 and abs(float(v[0]['fractional_difference']))<abs(float(v[-1]['fractional_difference']))
        for arm in ('reset','coupled'):
            full=read('transport-'+key(probe,1,128));half=read('transport-'+key(probe,1,64))
            for fluid in ('passive','effective'):
                a,b=(one(src,arm=arm,fluid=fluid,time=.24) for src in (full,half))
                assert .18< float(a['energy_error_rel'])/float(b['energy_error_rel'])<.35
        with np.load(ROOT/f'final-p{probe}.npz') as p:
            assert np.isfinite(p['passive_reset']).all() and np.linalg.norm(p['effective_coupled']-p['passive_coupled'])>0
    table(ROOT/'mesh-comparison.csv',bars,True)
    riem=read('interface-grid-check.csv')
    for p in (0,1):
        for form in ('cubic','wendland'):
            for gamma in (1.4,5/3):
                mesh=[one(riem,probe=p,shape=form,gamma=gamma,cells=n) for n in (256,512,1024)]
                for col in ('velocity_L1_relative','pressure_L1_relative'):
                    hi,mid,lo=[float(v[col]) for v in mesh];assert hi>mid>lo
                assert float(mesh[-1]['impulse_error_fraction'])<4e-13
    front=read('interface-newton-field.csv')
    for r in select(front,time_Myr=.24):
        if int(r['probe'])==1:assert float(r['field_reset_m_s2'])==float(r['field_coupled_m_s2'])==0.
        else:assert float(r['field_reset_m_s2'])>0
    assert max(float(r['dipole_relative_error']) for r in front)<2e-10
    for f in ROOT.glob('*.md'):
        for link in re.findall(r'\[[^\]\n]+\]\(([^) \n]+)\)',f.read_text(encoding='utf-8')):
            if '://' not in link:assert (ROOT/link).is_file(),link
    record('validation.json',dict(predecessor_sha256=SOURCE,predecessor_files_verified=len(pinned),
        hydro_configs=len(clocks)//4,evolved_trajectories=len(logs)//4,clock_records=len(clocks),
        explicit_controls=tests,balances=checks,complete_galactic_clock=False,independent_pressure_clock_spatially_converged=False,
        Euler_1D_check_rows=len(riem),Newton_halfspace_readouts=len(front),least_scalar_bound_rows=len(rec)))
    now={p.name:sha(p) for p in sorted(ROOT.iterdir()) if p.is_file() and p.name!='seal.json'}
    if seal:record('seal.json',now)
    assert json.loads((ROOT/'seal.json').read_bytes())==now
    print(len(now),sha(ROOT/'seal.json'),checks)
if __name__=='__main__':run('--seal' in sys.argv)
