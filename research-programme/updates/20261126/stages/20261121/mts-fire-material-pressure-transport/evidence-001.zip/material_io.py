import hashlib,sys,json,os,io
from pathlib import Path
for var in ('OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','OMP_NUM_THREADS','NUMEXPR_NUM_THREADS','BLIS_NUM_THREADS'):os.environ[var]='1'
ROOT=Path(__file__).resolve().parent
OLD=ROOT.parent/'mts-fire-mixed-pressure-clock-20261121'
def sha(path):
    with path.open('rb') as src:return hashlib.file_digest(src,'sha256').hexdigest()
SOURCE='3cea6b32af4e81792a8a4f21cbf799d5e75ae587923174fb125ca5a59a35eccb'
assert sha(OLD/'seal.json')==SOURCE
pinned=json.loads((OLD/'seal.json').read_bytes())
for item in ('trace_resolution.py','gas_clouds.py','mixed_operators.py','mixed_pressure_io.py'):
    assert sha(OLD/item)==pinned[item]
sys.path.insert(0,str(OLD))
from gas_clouds import clouds,shape_kernel,np,bank,jf,OBSERVER_R,OBSERVER_MU,CONVERT,Launch,Tides,angular,DEGREES,LIGHT,eval_legendre,legvander,gauss,keep,table,guard as prior_guard
def guard():
    prior_guard();assert not (ROOT/'STOP-REQUESTED').exists()
def packet(name,**values):
    buf=io.BytesIO();np.savez_compressed(buf,**values);keep(ROOT/name,buf.getvalue(),True)
def record(name,values):
    keep(ROOT/name,(json.dumps(values,sort_keys=True,indent=2)+'\n').encode(),True)
def loc(rad,mu):return np.stack([rad*np.sqrt(1-mu*mu),rad*mu],axis=-1)
def coord(pos):
    rad=np.linalg.norm(pos,axis=-1);return rad,pos[...,1]/rad
def axes(probe,padding,refine=1):
    radius=OBSERVER_R[probe];angle=OBSERVER_MU[probe]
    ir=np.argmin(abs(jf.EDGES-radius));ia=np.argmin(abs(jf.ANG-angle))
    span=2+padding
    def split(arr,i):
        cuts=arr[i-span:i+span+1];return np.r_[np.linspace(cuts[:-1],cuts[1:],refine,endpoint=False,axis=1).ravel(),cuts[-1]]
    return split(jf.EDGES,ir),split(jf.ANG,ia),ir,ia
