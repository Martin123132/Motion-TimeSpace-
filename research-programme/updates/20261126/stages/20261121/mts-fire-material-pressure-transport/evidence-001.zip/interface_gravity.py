"""Newtonian field of the isolated artificial pressure front, relative to the same tagged passive step."""
from interface_euler import *
from lagrangian import gravity
from scipy.constants import parsec
from functools import lru_cache
@lru_cache(maxsize=64)
def nodes(n):return gauss(n)
def density(g,l,r,xi):
    pstar,us,cl,cr=star(g,l,r);v,p=profile(g,l,r,xi);w=np.where(xi<us,l,r);p0=w/g
    b=(g-1)/(g+1);ratio=p/p0
    return np.where(p>p0,w*(ratio+b)/(1+b*ratio),w*ratio**(1/g)),v
def values(g,l,r,xi):
    rho,v=density(g,l,r,xi);ref=np.where(xi<0,l,r)
    return rho-ref,xi*(rho-ref)-rho*v
def integrate(g,l,r,upper):
    ps,us,cl,cr=star(g,l,r);ends=[cl,cr,0.,us]
    for w,sgn in ((l,-1),(r,1)):
        if ps<w/g:ends.append(us+sgn*(ps*g/w)**((g-1)/(2*g)))
    ends=np.unique(np.clip(ends,cl,max(cl,upper)).tolist()+[max(cl,upper)])
    mass=dipole=fieldint=0.;v,w=nodes(12)
    for a,b in zip(ends[:-1],ends[1:],strict=True):
        xi=a+(b-a)*(1+v)/2;rule=w*(b-a)/2;d,field=values(g,l,r,xi)
        mass+=rule@d;dipole+=rule@(xi*d);fieldint+=rule@field
    return mass,dipole,fieldint
def run():
    rows=[];scale=1000/parsec
    for row in csv.DictReader((ROOT/'interface-solutions.csv').read_text().splitlines()):
        probe=int(row['probe']);g=float(row['gamma']);l=float(row['w_left']);r=float(row['w_right'])
        rad=float(row['face_kpc']);mu=float(row['mu']);cs=float(row['raw_sound_kms']);rho=float(row['raw_density']);gap=OBSERVER_R[probe]-rad
        pos=loc(np.array([rad]),np.array([mu]));er=pos/rad
        accel={arm:float((gravity(pos,arm)[1]*er).sum()) for arm in ('reset','coupled')}
        pstar,u,left,right=star(g,l,r)
        mass,moment,fieldint=integrate(g,l,r,right+1)
        target=(l-r)/(2*g)
        assert abs(mass)<2e-14 and abs(moment/target-1)<2e-10 and abs(fieldint/target+1)<2e-10
        for t in (.12,.24,.48):
            width=cs*np.sqrt(CONVERT)*t
            gs={};scene={}
            for arm,a in accel.items():
                xi=(gap-.5*a*t*t)/width;d,N=values(g,l,r,np.array([xi]));direct,_,I=integrate(g,l,r,xi)
                assert abs(direct-N[0])<3e-14
                gs[arm]=-4*np.pi*jf.ls.G*rho*width*N[0]*scale
                scene[arm]=dict(xi=float(xi),delta_density_fraction=float(d[0]),field=gs[arm],potential=4*np.pi*jf.ls.G*rho*width**2*I)
            ans=dict(probe=probe,point=row['point'],shape=row['shape'],gamma=g,time_Myr=t,
                radial_wave_reset=accel['reset'],radial_wave_coupled=accel['coupled'],far_mass_integral=mass,
                dipole_relative_error=abs(moment/target-1),infinite_slab_potential_step_over_c2=4*np.pi*jf.ls.G*rho*width**2*fieldint/LIGHT**2,
                field_reset_m_s2=gs['reset'],field_coupled_m_s2=gs['coupled'],paired_field_m_s2=gs['coupled']-gs['reset'],
                density_contrast_reset=scene['reset']['delta_density_fraction'],density_contrast_coupled=scene['coupled']['delta_density_fraction'],
                xi_reset=scene['reset']['xi'],xi_coupled=scene['coupled']['xi'])
            rows.append(ans)
    table(ROOT/'interface-newton-field.csv',rows,True)
if __name__=='__main__':guard();run()
