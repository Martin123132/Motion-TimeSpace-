"""Aperture-wide test of sourcing with w while accelerating unit-inertia raw matter; not a new fit."""
from material_io import *
from finite_volume import quadrature
from mixed_pressure_io import prior
from scipy.constants import parsec
def run(order):
    gas,en,w=bank();n=len(gas)
    with np.load(prior('frozen-weights.npz')) as f:stars=f['star_mass'][:w.size].reshape(w.shape)
    mats=(gas,stars,gas+stars);names=('gas','stars','joint')
    edges=jf.EDGES[:n+1];lab=Launch(64);fe=lab.run.el.right*lab.obj.bg.length
    cuts=np.unique(np.r_[edges,OBSERVER_R,fe[(fe>0)&(fe<edges[-1])]]);r,rw=quadrature(cuts,order);ir=np.searchsorted(edges,r)-1
    mu,mw=quadrature(jf.ANG,order);fra=np.tile(gauss(order)[1]/2,256)
    modes=('volume','radius');arms=('reset','coupled','paired')
    out=np.zeros((3,2,3,5));tides=[Tides(lab,r,arm) for arm in arms]
    ang=angular(tides[0].ell,mu)[0:2]
    V=legvander(jf.ANG,65);L=DEGREES;mean=np.ones((256,len(L)))
    for k,l in enumerate(L[1:],1):mean[:,k]=np.diff(V[:,l+1]-V[:,l-1])/((2*l+1)*np.diff(jf.ANG))
    channels=['raw','tag','difference']; moments=np.array([[a@mean,(a*w)@mean,(a*(1-w))@mean] for a in mats])
    fields=np.zeros((3,3,2,2,3));dweights=np.stack([np.ones_like(w),w,w*w,abs(1-w),(1-w)**2],axis=0)
    for st in range(0,len(r),40):
        sl=slice(st,st+40);x=r[sl];ind=ir[sl]
        measure=(3*rw[sl]*x*x/np.diff(edges**3)[ind],rw[sl]/np.diff(edges)[ind])
        for i,t in enumerate(tides):
            ar=t.bg.length*(t.dr[sl]@ang[0]);at=t.bg.length*(t.val[sl]@ang[1])/(x[:,None]/t.bg.length)
            power=((ar**2+at**2)*fra).reshape(len(x),256,order).sum(axis=2)
            for m,mat in enumerate(mats):
                cells=np.einsum('br,kbr->kb',power*mat[ind],dweights[:,ind])
                for k,weights in enumerate(measure):out[i,k,m]+=cells@weights
        for j,(p,obs) in enumerate(zip(OBSERVER_R,OBSERVER_MU,strict=True)):
            coeff=-jf.ls.G*(np.minimum(x,p)/np.maximum(x,p))[:,None]**L/np.maximum(x,p)[:,None]
            pol,dt=angular(L,np.array([obs]),False)[:2];pol=pol[:,0];dt=dt[:,0]
            nobs=np.where(x[:,None]<p,-(L+1),L)
            test=np.stack((coeff*pol, -coeff*nobs*pol/p*1000/parsec,-coeff*dt/p*1000/parsec),axis=2)
            for k,weights in enumerate(measure):
                fields[:,:,k,j]+=np.einsum('mcbk,bkl,b->mcl',moments[:,:,ind,:],test,weights)
    rows=[];potrows=[]
    for m,name in enumerate(names):
        for k,mode in enumerate(modes):
            for i,arm in enumerate(arms):
                raw,weight,sq,absolute,res=out[i,k,m];alpha=weight/sq
                rows.append(dict(material=name,representation=mode,arm=arm,raw_virtual_work=raw,
                    tagged_virtual_work=weight,raw_minus_tag=raw-weight,L1_work_fraction=absolute/raw,
                    unscaled_acceleration_RMS=np.sqrt(res/raw),least_squares_scale=alpha,
                    minimum_relative_RMS=np.sqrt(max(0,1-weight**2/(raw*sq)))))
            for c,ch in enumerate(channels):
                (vi,ri,ti),(vo,ro,to)=fields[m,c,k]
                potrows.append(dict(material=name,representation=mode,source=ch,inner_radial_m_s2=ri,outer_radial_m_s2=ro,
                    inner_polar_m_s2=ti,outer_polar_m_s2=to,clock=(vo-vi)/LIGHT**2))
                if c==2:assert np.max(abs(fields[m,0,k]-fields[m,1,k]-fields[m,2,k])/np.maximum(abs(fields[m,0,k]),1e-30))<1e-12
    table(ROOT/f'reciprocity-{order}.csv',rows,True);table(ROOT/f'aperture-fields-{order}.csv',potrows,True)
if __name__=='__main__':
    for order in (2,4):guard();run(order)
