"""Short, conservative material evolutions on the two fixed source patches."""
from clock_patch import *
import argparse

def integrate(dom,arm,active,gamma,nsteps,end):
    sz=dom.size;mn=dom.wmn if active else dom.mn
    dt=end/nsteps;zero=np.zeros((sz,2));ds=zero.copy();vel=zero.copy();mask=~dom.freeze
    scale=banktags().max();f=dom.tag/scale;fn=dom.fn/scale
    nodes=dom.corenode
    def read(d):
        pos=dom.pos+d;ag,raw,own,each,j=dom.forces(pos,gamma,active)
        phi,acc=gravity(pos,arm);force=ag+acc;force[~mask]=0
        ex=fn[:,None]*raw-own/scale
        neg=scatter(dom.idx,(1-f)[:,None,None]*each,sz);back=(1-fn[:,None])*raw-neg
        res=np.max(abs(ex+back));norm=np.max(np.sum(abs(each),axis=(1,2)))
        return force,raw,own,acc,ex,res/norm,phi,j
    old=read(ds);phi0=old[-2];ein=dom.thermal*(dom.tag if active else 1)
    minj=1.;error=0.;work=0.;work_abs=0.;raw_abs=0.;exchange_abs=0.;qpulse=np.zeros(2)
    pki=np.zeros(2);gravi=np.zeros(2);stored={};stats=[]
    nx=dom.fn
    for it in range(1,nsteps+1):
        if it%32==1:guard()
        mid=vel+dt/2*old[0];dx=dt*mid;ds+=dx;new=read(ds);vel=mid+dt/2*new[0]
        for subs,wt in ((old,.5),(new,.5)):
            _,ra,own,ag,ex,er,_,j=subs
            error=max(error,er);minj=min(minj,j.min())
            if not active:
                work+=wt*np.sum(ex*dx);work_abs+=wt*np.sum(abs(ex*dx))
                exchange_abs+=wt*dt*np.sum(np.linalg.norm(ex[nodes],axis=1))
                qpulse+=wt*dt*np.sum(ex[nodes],axis=0)
                pki+=wt*dt*np.sum(own[nodes]/scale,axis=0)
                gravi+=wt*dt*np.sum((dom.mn*fn)[nodes,None]*ag[nodes],axis=0)
            raw_abs+=wt*np.sum(abs(ra*dx))
        old=new
        if it in {nsteps//8,nsteps//4,nsteps//2,nsteps}:
            j=old[-1];pot=old[-2]-phi0;kin=np.sum(vel**2,axis=1)/2
            speci=np.expm1((1-gamma)*np.log(j));energy=ein@speci+mn@(kin+pot)
            press_norm=np.sum(abs(ein*speci))
            wp=dom.thermal@(f*speci)+(dom.mn*fn)@(kin+pot)
            change=np.sum(dom.mn[nodes,None]*fn[nodes,None]*vel[nodes],axis=0)
            res=change-qpulse-pki-gravi
            stats.append(dict(time=it*dt,arm=arm,fluid='effective' if active else 'passive',min_volume_ratio=minj,
                energy_error=energy,absolute_pressure_energy=press_norm,energy_error_rel=abs(energy)/max(press_norm,1e-200),
                complementary_force_error=error if not active else '',label_exchange_R=qpulse[0] if not active else '',
                label_exchange_Z=qpulse[1] if not active else '',label_impulse_L1=exchange_abs if not active else '',
                core_label_momentum_R=change[0] if not active else '',core_label_momentum_Z=change[1] if not active else '',
                core_label_own_pressure_R=pki[0] if not active else '',core_label_own_pressure_Z=pki[1] if not active else '',
                core_label_gravity_R=gravi[0] if not active else '',core_label_gravity_Z=gravi[1] if not active else '',
                label_momentum_residual_L1=np.linalg.norm(res)/max(exchange_abs,np.linalg.norm(change),1e-90) if not active else '',
                split_work=work if not active else '',split_energy_change=wp if not active else '',
                split_work_rel=abs(wp-work)/max(work_abs,1e-100) if not active else '',max_displacement=float(np.max(np.linalg.norm(ds,axis=1)))))
            stored[it*dt]=ds.copy()
    return stored,stats

def jet(dom,gamma,q):
    pos=dom.pos;d=gravity(pos,'paired')[1];d[dom.freeze]=0
    e=dom.forces(pos,gamma,True)[0]-dom.forces(pos,gamma,False)[0];e[dom.freeze]=0
    jp=dom.forces(pos,gamma,True,d)[0]-dom.forces(pos,gamma,False,d)[0]
    jg=gravity(pos,'paired',e);jp[dom.freeze]=0;jg[dom.freeze]=0
    terms=launch_clock(dom,d,e,jp,jg,q)
    return terms
def calculate(probe,pad,ref,form,gamma,steps,stride=1,flip=False,q=6):
    guard();dom=Domain(probe,pad,ref,form,stride,flip)
    short=f'p{probe}-b{pad}-m{ref}-k{form}-g{round(10*gamma)}-t{steps}-s{stride}-d{int(flip)}-q{q}'
    meta=dict(probe=probe,padding=pad,mesh=ref,shape=['cubic','wendland'][form],gamma=gamma,steps=steps,density_stride=stride,flip=int(flip),clock_q=q)
    stored=[];log=[];out=[];terms=jet(dom,gamma,q);controls={}
    for active in (False,True):
        for arm in ('reset','coupled'):
            ds,trace=integrate(dom,arm,active,gamma,steps,.24);stored.append(ds)
            log.extend([meta|row for row in trace])
    for t in stored[0]:
        snapshots=[s[t] for s in stored];values=endpoint(dom,snapshots,q)
        coeff=(values[3]-values[1])*24/t**4
        out.append(meta|dict(time_Myr=t,passive_reset=values[0],passive_paired=values[1],effective_reset=values[2],effective_paired=values[3],
            effective_minus_passive_reset=values[2]-values[0],double_difference=values[3]-values[1],inferred_fourth=coeff,
            analytic_fourth=sum(terms),pressure_jacobian=terms[0],gravity_jacobian=terms[1],regular_readout=terms[2],sheet_readout=terms[3],
            relative_to_launch=coeff/sum(terms)-1,tagged_core_mass=np.sum((dom.tag*dom.mass)[dom.coretri])))
    table(ROOT/f'transport-{short}.csv',log,True);table(ROOT/f'clock-{short}.csv',out,True)
    if pad==3 and ref==1 and stride==1 and form==0 and not flip and steps==128 and q==6 and gamma>1.5:
        packet(f'final-p{probe}.npz',position=dom.pos,triangles=dom.idx,weight=dom.tag,raw_mass=dom.mass,core=dom.coretri,
            **{f'{a}_{b}':stored[2*i+j][.24] for i,a in enumerate(('passive','effective')) for j,b in enumerate(('reset','coupled'))})
    print(short,terms,out[-1]['inferred_fourth'],flush=True)
if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('probe',type=int);parser.add_argument('mode');args=parser.parse_args()
    base=(3,1,0,5/3,128); configs={
        'base':[base,(3,1,0,5/3,64)],
        'controls':[(5,1,0,5/3,128),(3,1,1,5/3,128),(3,1,0,1.4,128),(3,1,0,5/3,128,2),(3,1,0,5/3,128,1,True),(3,1,0,5/3,128,1,False,10)],
        'fine':[(3,2,0,5/3,256),(3,2,0,5/3,128)]}
    for config in configs[args.mode]:calculate(args.probe,*config)
