"""Independent mechanics controls, before interpreting the small paired clock."""
from material_evolution import *
def run():
    results={}
    for probe in (0,1):
        dom=Domain(probe,3,1,0);pos=dom.pos;g=5/3;rng=np.random.default_rng(27013+probe)
        v=rng.normal(size=pos.shape)*.01;v[dom.freeze]=0;step=1e-5
        A,F,_,_,_=dom.forces(pos,g,False)
        def denergy(delta):
            vol,_=geometry(pos+delta*v,dom.idx)
            return dom.thermal@np.expm1((1-g)*np.log(vol/dom.refvol))
        err=abs((denergy(step)-denergy(-step))/(2*step)+np.sum(F*v))/np.sum(abs(F*v))
        assert err<1e-7;results[f'pressure_virtual_work_p{probe}']=err
        for active in (False,True):
            fd=(dom.forces(pos+step*v,g,active)[0]-dom.forces(pos-step*v,g,active)[0])/(2*step)
            derivative=dom.forces(pos,g,active,v)[0]
            err=np.linalg.norm(fd-derivative)/np.linalg.norm(derivative)
            assert err<1e-7;results[f'pressure_jacobian_p{probe}_{active}']=err
        dgrav=(gravity(pos+step*v,'paired')[1]-gravity(pos-step*v,'paired')[1])/(2*step)
        ana=gravity(pos,'paired',v);err=np.linalg.norm(dgrav-ana)/np.linalg.norm(ana)
        assert err<1e-6;results[f'gravity_jacobian_p{probe}']=err
        center=np.zeros_like(v);center[:,1]=1.
        vol,dV,dVol,dgrad=geometry(pos,dom.idx,center)
        assert np.max(abs(dVol))<1e-13 and np.max(abs(dgrad))<1e-12
        const=0.37;dom.tag=np.full(len(dom.mass),const);dom.wmn=dom.lump(dom.tag*dom.mass);dom.fn=dom.wmn/dom.mn
        for arm in ('reset','coupled'):
            left,trace=integrate(dom,arm,False,g,32,.12);right,other=integrate(dom,arm,True,g,32,.12)
            err=np.max(abs(left[.12]-right[.12]))/np.max(abs(left[.12]))
            assert err<2e-12 and float(trace[-1]['label_impulse_L1'])<1e-10
            results[f'constant_label_p{probe}_{arm}']=err
    record('independent-checks.json',results)
if __name__=='__main__':guard();run()
