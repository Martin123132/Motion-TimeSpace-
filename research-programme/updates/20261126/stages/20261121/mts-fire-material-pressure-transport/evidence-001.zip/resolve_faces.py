"""Spatial diagnostic at unchanged endpoints; do not extrapolate mesh-dependent pressure tractions."""
from material_evolution import *
if __name__=='__main__':
    probe=int(sys.argv[1]);meshes=[int(x) for x in sys.argv[2:]]
    for ref in meshes:
        calculate(probe,3,ref,0,5/3,64*ref)
