import argparse
import hashlib
import io
from pathlib import Path
from urllib.request import urlopen
import fitz
import numpy as np

HERE=Path(__file__).resolve().parent
PAPERS={"1404.7524v2":"181bb0619921c12105f3ec83f059375fb3d4eb1b5494f992ae652847a819cd94",
        "1006.5373v1":"df6cb335ea2e599857572cc79360cd354922655c7954467ef7a8047834414663"}


def axis(pixels,values):
    fit=np.polyfit(pixels,values,1)
    assert max(abs(np.polyval(fit,pixels)-values))<.001*abs(values[-1]-values[0])
    return lambda points: np.polyval(fit,points)


def ticks(graph,indices,values,dim):
    return axis([graph[idx]["rect"][dim] for idx in indices],np.array(values))


def write(name,graph,indices,calx,caly,color):
    points=[]
    for idx in indices:
        entry=graph[idx]
        items=entry["items"]
        assert entry["type"]=="s" and entry["color"]==color and all(item[0]=="l" for item in items)
        if points:
            assert np.max(abs(np.array(points[-1])-np.array(items[0][1])))<.02
        else:
            points.append(items[0][1])
        points.extend(item[2] for item in items)
    coords=np.array(points)
    energy=calx(coords[:,0])
    val=caly(coords[:,1])
    assert min(np.diff(energy))>=-1e-9
    unique,inverse=np.unique(energy,return_inverse=True)
    avg=np.bincount(inverse,weights=val)/np.bincount(inverse)
    assert max(abs(avg[inverse]-val))<.15
    mask=(unique>=.27)&(unique<=2.01)
    buf=io.StringIO()
    np.savetxt(buf,np.c_[unique[mask],avg[mask]],delimiter=",",fmt="%.12g",header="W_GeV,"+name,comments="")
    blob=buf.getvalue().encode("ascii")
    dest=HERE/(name+".csv")
    if dest.exists():
        assert dest.read_bytes()==blob
    else:
        with dest.open("xb") as out: out.write(blob)


def extract(ident,raw):
    assert hashlib.sha256(raw).hexdigest()==PAPERS[ident]
    with fitz.open(stream=raw,filetype="pdf") as doc:
        black=(0.,0.,0.)
        if ident.startswith("1006"):
            page=doc[28]
            assert "Figure 6:" in page.get_text() and "lower curve" in " ".join(page.get_text().split())
            graph=page.get_drawings()
            ticks0=[item[1] for item in graph[52]["items"][::2]]
            horiz=axis([pt.x for pt in ticks0[7:]],np.arange(2,11)*.2)
            vert=axis([pt.y for pt in ticks0[:7]],np.arange(-6,1))
            write("gm-phase2-deg",graph,[54,55],horiz,vert,black)
            return
        page=doc[12]
        assert "Figure 2:" in page.get_text()
        graph=page.get_drawings()
        horiz=ticks(graph,range(254,267,2),np.arange(2,9)*.2,0)
        phase_cal=ticks(graph,range(269,278,2),np.arange(-1,4)*50,1)
        phase_zero=graph[271]["rect"][1]
        vert=lambda points:phase_cal(points)-phase_cal(phase_zero)
        for iso,ids,col in ((0,[323,324],black),(2,[325,326],(1.,0.,0.))):
            write(f"dp-phase{iso}-deg",graph,ids,horiz,vert,col)
        page=doc[36]
        assert "Figure 16:" in page.get_text()
        graph=page.get_drawings()
        for iso,off,idx,ys,maximum in ((0,0,186,range(56,67,2),500),(2,92,189,range(148,157,2),200)):
            horiz=ticks(graph,range(40+off,55+off,2),np.arange(1,9)*.2,0)
            vert=ticks(graph,ys,np.linspace(0,maximum,len(ys)),1)
            write(f"dp-sigma{iso}-nb",graph,[idx],horiz,vert,(0.,0.,1.))
        graph=doc[18].get_drawings()
        for iso,idx,xidx,xval,yidx,yval in (
                (0,14,range(34,41,2),np.arange(3,7)*.1,range(42,53,2),np.arange(6)*.2),
                (2,221,range(259,270,2),np.arange(2,8)*.2,range(272,283,2),np.arange(6)*.2)):
            write(f"dp-direct{iso}-modulus",graph,[idx],ticks(graph,xidx,xval,0),ticks(graph,yidx,yval,1),black)


if __name__=="__main__":
    parser=argparse.ArgumentParser()
    parser.add_argument("--prefix")
    args=parser.parse_args()
    for paper in PAPERS:
        if args.prefix:
            extract(paper,Path(args.prefix+paper+".pdf").read_bytes())
        else:
            with urlopen("https://arxiv.org/pdf/"+paper,timeout=25) as stream:
                extract(paper,stream.read(3500000))

