"""Carry corrected normalization to the on-shell photon gravitational form factor."""
import numpy as np
from helicity import HERE,TH,angular,elastic
from compare import write
from joint import normalization
from spin_bound import geometry,projected_bounds,source
from waves import energy_rule,p2


def kernel(kind,energy):
    squared=energy**2
    if kind=="constant":return np.ones_like(energy)
    if kind=="difference":return TH/(squared+TH)
    if kind=="curvature":return 2*TH**2/((squared+TH)*(squared+2*TH))
    raise ValueError(kind)


def interval(group,kind,box,shared):
    channel,low,hi=group[0][:3]
    charge=channel=="charged"
    energies,ew=energy_rule(max(.6,low),min(.75,hi),12)
    angles,aw,widths,aperture=geometry(group,24)
    observed=np.array([(1+int(charge)*shared)*r[5]+box*(r[6]+(r[7] or 0.)) for r in group])
    rest,_,_,hadron,base,rate=source(energies,angles,charge)
    factor=kernel(kind,energies)*base
    projected=np.einsum("e,eij->ij",ew*factor*hadron.real,rest)
    limit=(hi-low)*(ew@(factor**2*abs(hadron)**2/rate))*observed
    pol=p2(angles)
    mean=widths@(pol@aw)
    variance=aperture**4/5
    center=-(widths@(((pol-mean)*projected)@aw))/(5*variance)
    radius=np.sqrt(widths@limit/variance)/5
    return np.array(projected_bounds(aw,pol,projected,limit,0.,center-radius,center+radius))*(1 if charge else .5)


def run():
    output=[];data=angular.dataset();eps=normalization()
    groups=[[r for r in data if r[:3]==key] for key in sorted(set(r[:3] for r in data)) if key[1]<.75 and key[2]>.60]
    assert len(groups)==10
    for low,hi in ((.281,.54),(.6,.75)):
        energies,ew=energy_rule(low,hi,12);squared=energies**2
        hadron=(1-.01*squared)*elastic.omega(squared)
        measure=2*elastic.KAPPA*(1-TH/squared)**1.5/energies**3
        integrand=measure*(np.array([angular.read_wave(val) for val in energies])*hadron.conjugate()).real
        raw=np.array([ew@(integrand*squared/(squared+mult*TH)) for mult in range(3)])
        for idx,(kind,contrast) in enumerate((("constant",[1,0,0]),("difference",[1,-1,0]),("curvature",[1,-2,1]))):
            expected=ew@(integrand*kernel(kind,energies))
            assert abs(np.dot(contrast,raw)-expected)<1e-18
            if idx:
                assert sum(contrast)==0
            if idx==2:
                assert np.dot(contrast,np.arange(3))==0
            value=dict(W_lo=low,W_hi=hi,quantity=kind,u_GeV2=TH,ref_GeVminus2=expected)
            if low==.6:
                for mode,budget,shift in (("central",0,0.),("pointwise_box",1,0.),("with_shared_norm",1,eps)):
                    lo,upper=sum((interval(group,kind,budget,shift) for group in groups),start=np.zeros(2))
                    value[mode+"_lo"]=lo;value[mode+"_hi"]=upper
                    assert lo<expected<upper
            output.append(value)
    keys=output[-1].keys()
    write("matched-gravity.csv",[{key:row.get(key) for key in keys} for row in output])
    return output


if __name__=="__main__":
    print(run())

