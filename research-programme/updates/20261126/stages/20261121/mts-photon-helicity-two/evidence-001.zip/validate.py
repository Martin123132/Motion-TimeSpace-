import hashlib
import json
import re
import sys
from functools import lru_cache
import numpy as np
from scipy.integrate import quad
from helicity import HERE,OLD,TH,NORM,ROT,TO_DP,Signed,angular,born_dp,data,elastic,interp,kinematics,physical,roots_legendre,solution,waves_at
from joint import normalization,rows
from compare import write


def local_pv(model,energy):
    squared=energy**2
    panel=np.searchsorted(model.grid,squared)-1
    left,right=model.grid[panel:panel+2]
    assert left<squared<right
    independent=quad(lambda val:float(model.kernel(val)),left,right,weight="cauchy",wvar=squared,
                     epsabs=1e-10,epsrel=1e-9,limit=140)[0]
    for edges in (model.grid[:panel+1],model.grid[panel+1:]):
        if len(edges)<2: continue
        nodes,weights=elastic.gauss(edges,32)
        ordinary=(weights*model.kernel(nodes)/(nodes-squared)).reshape(-1,32).sum(axis=1)
        for idx in np.flatnonzero(np.minimum(abs(edges[1:]-squared),abs(edges[:-1]-squared))<.2*np.diff(edges)):
            ordinary[idx]=quad(lambda val:float(model.kernel(val))/(val-squared),*edges[idx:idx+2],epsabs=1e-10,epsrel=1e-10)[0]
        independent+=ordinary.sum()
    independent+=np.sum(model.tailint/(model.tail-squared))
    return independent


def validate():
    normalization()
    angle,weight=roots_legendre(72);angle=(angle+1)/2;weight=weight/2
    basis=NORM*(1-angle**2)
    assert abs(weight@basis**2-1)<1e-14
    checks=[]
    for energy in (.279141,.282,.35,.549,.60713,.70719,.79629):
        beta,_=kinematics(energy,True)
        photon=beta**2*(1-angle**2)/(1-(beta*angle)**2)
        bare=born_dp(energy**2)
        assert abs(weight@(basis*photon)-bare)<3e-13
        assert abs(weight@(basis*(photon-bare*basis)))<3e-13
        born=ROT[0]*bare
        assert abs(physical(*born,True)-bare)<1e-14 and abs(physical(*born,False))<1e-14
        if energy<.3:continue
        for iso in (0,2):
            model=solution(iso)
            val,central,reduced=model.parts(energy)
            squared=energy**2; om=model.om(squared); pv=local_pv(model,energy)
            canceled=model.born_scale*bare/om+1j*squared**2*(squared-TH)*model.kernel(squared)
            assert abs(canceled.imag)<1e-14 and reduced<0
            direct=val+TO_DP*om*squared**2*(squared-TH)*(pv-central)/np.pi
            assert abs(direct-val)<1e-6
            checks.append(dict(test="PV_signed_wave",I=iso,W=energy,absolute_difference=abs(direct-val)))
    tensor=solution(2).om
    for iso in (0,2):
        finer=Signed(iso,order=18)
        for energy in (.55,.653,.70719,.75,.80):
            change=abs(finer.parts(energy)[0]-solution(iso).parts(energy)[0])
            assert change<2e-6
            checks.append(dict(test="dispersive_quadrature",I=iso,W=energy,absolute_difference=change))
    for squared in (-4.,-.17,.67129**2,1.38**2):
        if squared<0:
            nodes,weights=elastic.gauss(tensor.grid,22)
            logom=squared/np.pi*(weights@(np.interp(nodes,tensor.grid,tensor.phase)/(nodes*(nodes-squared))))
        else:
            lo,hi=tensor.grid[0],tensor.grid[-1]
            at=np.interp(squared,tensor.grid,tensor.phase)
            grid=np.unique(np.r_[tensor.grid,squared])
            nodes,weights=elastic.gauss(grid,24)
            delta=np.interp(nodes,tensor.grid,tensor.phase)
            logom=(weights@((delta-at)/(nodes-squared)-delta/nodes)+at*np.log((hi-squared)/(squared-lo)))/np.pi+1j*at
        diff=abs(np.exp(logom)/tensor(squared)-1)
        assert diff<1e-11
        checks.append(dict(test="independent_Omnes",I=2,W=squared,absolute_difference=diff))
    for iso in (0,2):
        energy=np.linspace(.42,.59,30) if iso==0 else np.linspace(.42,.8,50)
        val=abs(np.array([waves_at(point,"dp")[iso//2] for point in energy]))
        delta=max(abs(interp(f"dp-direct{iso}-modulus",energy)-val))
        checks.append(dict(test="DP_Fig3_vs_16_modulus",I=iso,W="",absolute_difference=delta))
        assert delta<.008
    expected=json.loads((OLD/"gravity-window.json").read_bytes())["results"]
    result=next(row for row in rows(HERE/"matched-gravity.csv") if row["W_lo"]=="0.6" and row["quantity"]=="constant")
    for mode,idx in (("central",0),("pointwise_box",1)):
        for limit in ("lo","hi"):
            assert abs(float(result[mode+"_"+limit])-expected[f"binwise_{limit}_{idx}"])<1e-12
    assert float(result["with_shared_norm_lo"])<float(result["pointwise_box_lo"])
    assert float(result["with_shared_norm_hi"])>float(result["pointwise_box_hi"])
    apertures=rows(HERE/"apertures.csv")
    bins=rows(HERE/"bin-predictions.csv")
    assert len(apertures)==144 and len(bins)==148
    for row in apertures:
        group=[b for b in bins if all(b[k]==row[k] for k in ("channel","W_lo","W_hi"))]
        total=sum((float(b["z_hi"])-float(b["z_lo"]))*float(b[row["model"]+"_total"]) for b in group)
        assert abs(total-float(row["total"]))<1e-11
        assert abs(sum(float(row[k]) for k in ("pure_D2","higher_Born","interference"))-float(row["opposite"]))<1e-11
    joint=rows(HERE/"joint-phase-floor.csv")
    assert len(joint)==54 and all(float(r["opposite_floor"])<=float(r["frozen_opposite"])+1e-12 for r in joint)
    failures=[r for r in joint if float(r["box_excess_any_like"])>0]
    assert len(failures)==1 and all(failures[0][k]==v for k,v in [("model","dispersion"),("charged_lo","0.65"),("z_lo","0.2"),("z_hi","0.3")])
    for name in ("dp_matched","dispersion"):
        chosen=[r for r in joint if r["model"]==name and r["charged_lo"]=="0.65" and r["z_hi"]=="0.6" and r["z_lo"]=="0"]
        assert len(chosen)==1
        row=chosen[0]
        assert (float(row["box_excess_frozen_like"])>0)==(name=="dispersion")
    return checks


if __name__=="__main__":
    checks=validate()
    write("controls.csv",checks)
    for doc in HERE.glob("*.md"):
        for link in re.findall(r"\]\(([^\s)]+)\)",doc.read_text(encoding="utf8")):
            if not link.startswith("https://"):
                assert (HERE/link).is_file(),(doc,link)
    digests={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(HERE.iterdir())
             if p.is_file() and p.name!="seal.json"}
    seal=HERE/"seal.json"
    if sys.argv[1:]==["--seal"]:
        with seal.open("x",encoding="utf8",newline="\n") as dest:
            dest.write(json.dumps(digests,indent=2)+"\n")
    else:
        assert len(sys.argv)==1 and digests==json.loads(seal.read_bytes())
    print(f"{len(digests)} files; verified " + hashlib.sha256(seal.read_bytes()).hexdigest())

