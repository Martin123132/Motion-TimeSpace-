import csv
import json
import numpy as np
from helicity import HERE,OLD,ROT,NORM,born_dp,elastic,kinematics,roots_legendre
from compare import write

def rows(path):
    with path.open(encoding="utf8") as stream:return list(csv.DictReader(stream))


def normalization():
    data=json.loads((OLD.parent/"mts-four-pion-stress-bridge-20261121"/"mark2-angles.json").read_bytes())
    errors=[entry["errors"][1] for item in data["values"][:2] for entry in item["y"]]
    assert len(errors)==12 and all(err["symerror"]=="7.0%" and "overall normalisation" in err["label"] for err in errors)
    return .07


def profile():
    eps=normalization()
    bins=[row for row in rows(HERE/"bin-predictions.csv") if row["channel"]=="charged"]
    obs,stat=np.array([[float(row[k]) for k in ("obs","stat")] for row in bins]).T
    output=[]
    for name in ("born","dispersion","dp_matched","sub_sum_rule","polarizabilities","cut3","iso2_long_tail"):
        model=np.array([float(r[name+"_total"]) for r in bins]);op=np.array([float(r[name+"_opp"]) for r in bins])
        def interval(budget):
            return max(-eps,max((model-budget*stat)/obs-1)),min(eps,min((model+budget*stat)/obs-1))
        low,high=0.,max(abs(model-obs)/stat)
        for _ in range(55):
            mid=(low+high)/2
            lo,hi=interval(mid)
            if lo<=hi:high=mid
            else:low=mid
        lo,hi=interval(high+1e-12)
        assert lo<=hi and max(abs(model-(1+(lo+hi)/2)*obs)/stat)<high+1e-8
        output.append(dict(model=name,zero_shift_max_stat=max(abs(model-obs)/stat),min_max_stat=high,
                           shared_shift=(lo+hi)/2,min_opp_max_stat=max(0.,max((op-(1+eps)*obs)/stat)),
                           one_stat_required_shift_lo=interval(1.)[0],one_stat_allowed_shift_hi=interval(1.)[1]))
    write("charged-shared-normalization.csv",output)
    floor=[]
    for key in sorted(set(r["W_lo"] for r in bins)):
        group=[r for r in bins if r["W_lo"]==key]
        width=np.array([float(r["z_hi"])-float(r["z_lo"]) for r in group])
        pole,yval,error=np.array([[float(r[k]) for k in ("born_opp","obs","stat")] for r in group]).T
        for shift in (0,eps):
            for budget in (0,1):
                limit=(1+shift)*yval+budget*error
                change=np.sqrt(width@(np.maximum(0,np.sqrt(pole)-np.sqrt(limit))**2)/(width@pole))
                floor.append(dict(W_lo=key,normalization_shift=shift,stat_box=budget,relative_norm_floor=change,
                                  disallowed_bins=int(sum(pole>limit))))
    write("corrected-born-floors.csv",floor)


def joint():
    eps=normalization()
    original=rows(OLD/"bin-comparison.csv")
    source=rows(HERE/"signed-waves.csv")
    grid=np.array([float(r["W"]) for r in source])
    selections=[(.55,.65,.60,.66),(.65,.75,.64,.76),(.55,.75,.60,.76)]
    results=[]
    for cl,ch,nl,nh in selections:
        for zl,zh in [(0,.6),(0,.3),(.3,.6)]+[(idx/10,(idx+1)/10) for idx in range(6)]:
            relevant=[row for row in original if float(row["z_low"])>=zl-1e-12 and float(row["z_high"])<=zh+1e-12 and
                      ((row["channel"]=="charged" and cl<=float(row["W_low"]) and float(row["W_high"])<=ch) or
                       (row["channel"]=="neutral" and nl<=float(row["W_low"]) and float(row["W_high"])<=nh))]
            counts={name:0. for name in ("area","like","observed","charged","box","ref")}
            for row in relevant:
                area=(float(row["W_high"])-float(row["W_low"]))*(float(row["z_high"])-float(row["z_low"]))
                charge=row["channel"]=="charged"
                counts["area"]+=area
                counts["like"]+=area*(float(row["dp_H"])-float(row["opposite_sq"]))
                counts["observed"]+=area*float(row["observed_nb_per_z"])
                counts["charged"]+=charge*area*float(row["observed_nb_per_z"])
                counts["box"]+=area*(float(row["stat"])+float(row["sys"] or 0))
            assert abs(counts["area"]-((ch-cl)+(nh-nl))*(zh-zl))<1e-12
            znode,aw=roots_legendre(24)
            z=(zl+zh+(zh-zl)*znode)/2;aw=aw*(zh-zl)/2
            u=NORM*(1-z**2);norm=aw@u**2
            for name in ("dispersion","dp_matched"):
                floor=0.;frozen=0.
                changes=sorted(set((cl,ch,nl,nh)))
                for start,stop in zip(changes[:-1],changes[1:]):
                    charged=cl<=(start+stop)/2<=ch;neutral=nl<=(start+stop)/2<=nh
                    edges=np.r_[start,grid[(grid>start)&(grid<stop)],stop]
                    energy,ew=elastic.gauss(edges,6)
                    beta,rate=kinematics(energy,True);bare=born_dp(energy**2)
                    rest=beta[:,None]**2*(1-z**2)/(1-(beta[:,None]*z)**2)-bare[:,None]*u
                    cross=rest@(aw*u);res=rest**2@aw
                    waves=np.array([sum(unit*np.interp(energy,grid,[float(r[f"{name}_{iso}_{part}"]) for r in source])
                                        for unit,part in ((1,"re"),(1j,"im"))) for iso in (0,2)])
                    physical=ROT@waves
                    total=np.zeros_like(energy)
                    if charged:total+=abs(physical[0])**2*norm+2*cross*physical[0].real+res
                    if neutral:total+=abs(physical[1])**2*norm
                    if charged and neutral:
                        lowest=norm*np.sum(abs(waves)**2,axis=0)+res-2*abs(cross)*(abs(ROT[0])@abs(waves))
                        check=np.sum(abs(physical)**2,axis=0)*norm+res+2*cross*physical[0].real
                        assert max(abs(total-check))<1e-12
                    else:
                        first,second=abs(ROT[int(neutral),:,None]*waves)
                        rmin=abs(first-second);rmax=first+second
                        optimum=np.clip(charged*abs(cross)/norm,rmin,rmax)
                        lowest=norm*optimum**2+charged*(res-2*abs(cross)*optimum)
                    assert min(lowest)>-1e-12 and min(total-lowest)>-1e-12
                    floor+=ew@(rate*lowest);frozen+=ew@(rate*total)
                box=counts["observed"]+counts["box"]+eps*counts["charged"]
                results.append(dict(charged_lo=cl,charged_hi=ch,neutral_lo=nl,neutral_hi=nh,z_lo=zl,z_hi=zh,model=name,
                                    observed_nb_GeV=counts["observed"],frozen_like=counts["like"],opposite_floor=floor,
                                    frozen_opposite=frozen,excess_any_like=floor-counts["observed"],
                                    excess_frozen_like=floor+counts["like"]-counts["observed"],upper_box=box,
                                    box_excess_any_like=floor-box,box_excess_frozen_like=floor+counts["like"]-box))
    write("joint-phase-floor.csv",results)
    print([(r["charged_lo"],r["charged_hi"],r["model"],r["excess_any_like"],r["excess_frozen_like"],r["box_excess_frozen_like"])
           for r in results if r["z_lo"]==0 and r["z_hi"]==.6])


if __name__=="__main__":
    profile();joint()

