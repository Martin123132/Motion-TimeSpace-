import csv
import io
import json
import numpy as np
from helicity import HERE,OLD,TH,NORM,ROT,Signed,angular,born_dp,data,elastic,kinematics,physical,roots_legendre,waves_at

MODEL=("born","dispersion","dp_matched","dp_reverse_both","dp_reverse_0","dp_reverse_2",
       "replace_0_only","replace_2_only","sub_sum_rule","polarizabilities","cut3","iso2_long_tail")


def write(name,rows):
    buf=io.StringIO(newline="")
    writer=csv.DictWriter(buf,rows[0].keys(),lineterminator="\n")
    writer.writeheader();writer.writerows(rows)
    (HERE/name).write_bytes(buf.getvalue().encode("utf8"))


def configuration():
    return {"dispersion":(Signed(0),Signed(2)),
            "sub_sum_rule":(Signed(0,sub_mode="sum_rule"),None),
            "polarizabilities":(Signed(0,sub_mode="polar"),Signed(2,sub_mode="polar")),
            "cut3":(Signed(0,limit=3,sub_mode="sum_rule"),Signed(2,limit=3)),
            "iso2_long_tail":(None,Signed(2,tail=16.))}


def bank():
    config=configuration()
    rows=[]; subs=[]
    for key,pair in config.items():
        for idx,model in enumerate(pair):
            if model is not None:
                subs.append(dict(branch=key,I=idx*2,left_SR=model.left_sr,right_SR=model.right_sr,
                                 sum_rule=model.sr,subtraction_used=model.sub))
    for energy in np.linspace(.55,.8,501):
        row=dict(W=energy)
        base=ROT[0]*born_dp(energy**2)
        old=waves_at(energy,"dp")
        gm=[instance.parts(energy)[0] for instance in config["dispersion"]]
        branches=dict(born=base,dispersion=gm,dp_matched=old,dp_reverse_both=-old,
                      dp_reverse_0=old*[-1,1],dp_reverse_2=old*[1,-1],replace_0_only=[gm[0],base[1]],
                      replace_2_only=[base[0],gm[1]])
        for name,models in list(config.items())[1:]:
            branches[name]=[gm[idx] if model is None else model.parts(energy)[0] for idx,model in enumerate(models)]
        for name,pair in branches.items():
            for iso,val in zip((0,2),pair):
                row[f"{name}_{iso}_re"]=float(val.real);row[f"{name}_{iso}_im"]=float(val.imag)
        rows.append(row)
    write("signed-waves.csv",rows);write("subtractions.csv",subs)
    return rows


def calculate(source,order,stride):
    rows=[];sums=[];boxes=[]
    bins=list(csv.DictReader((OLD/"bin-comparison.csv").open(encoding="utf8")))
    grid=np.array([row["W"] for row in source])[::stride]
    def wave(name,iso,energies):
        return sum(unit*np.interp(energies,grid,[row[f"{name}_{iso}_{part}"] for row in source[::stride]])
                   for unit,part in ((1,"re"),(1j,"im")))
    for channel,lo,hi in sorted({(r["channel"],float(r["W_low"]),float(r["W_high"])) for r in bins}):
        group=[r for r in bins if r["channel"]==channel and float(r["W_low"])==lo]
        charge=channel=="charged"
        edges=np.unique(np.r_[lo,grid[(grid>lo)&(grid<hi)],hi])
        energies,ew=elastic.gauss(edges,order)
        beta,rate=kinematics(energies,charge)
        left,right,obs,stat,oldop,like=np.array([[float(row[key]) for key in
                   ("z_low","z_high","observed_nb_per_z","stat","opposite_sq","dp_H")] for row in group]).T
        like=like-oldop
        angles,aw=roots_legendre(2*order+6)
        z=left[:,None]+(right-left)[:,None]*(1+angles)/2
        harmonic=NORM*(1-z**2)
        bare=born_dp(energies**2)
        born=beta[:,None,None]**2*(1-z**2)/(1-(beta[:,None,None]*z)**2)
        rest=(born-bare[:,None,None]*harmonic)*float(charge)
        binrows=[dict(channel=channel,W_lo=lo,W_hi=hi,z_lo=start,z_hi=stop,obs=datum,stat=err,like=fixed)
                 for start,stop,datum,err,fixed in zip(left,right,obs,stat,like)]
        ew=ew*rate/(hi-lo)
        average=lambda arr:ew@(arr@(aw/2))
        width=right-left
        for name in MODEL:
            first,other=(wave(name,iso,energies) for iso in (0,2))
            coef=physical(first,other,charge) if name!="born" else float(charge)*bare
            amp=rest+coef[:,None,None]*harmonic
            rate_bin=average(abs(amp)**2)
            remainder=average(rest**2)
            interf=average(2*rest*coef.real[:,None,None]*harmonic)
            pure=rate_bin-interf-remainder
            if name=="born":
                assert max(abs(rate_bin-oldop))<1e-9
            distance=np.sqrt(max(0.,width@average(abs(amp-born*float(charge))**2))/(width@oldop)) if charge else None
            for idx,row in enumerate(binrows):
                row[name+"_opp"]=rate_bin[idx];row[name+"_total"]=rate_bin[idx]+like[idx]
            full=rate_bin+like
            area=width@full; observed=width@obs
            shape=.5*width@abs(full/area-obs/observed)
            sums.append(dict(channel=channel,W_lo=lo,W_hi=hi,model=name,obs=observed,opposite=width@rate_bin,
                             total=area,residual=area-observed,shape_TV=shape,pure_D2=width@pure,
                             higher_Born=width@remainder,interference=width@interf,relative_amp_change=distance,
                             excess_opp_bins=int(sum(rate_bin>obs)),excess_opp_stat_bins=int(sum(rate_bin>obs+stat))))
        rows.extend(binrows)
        mags=[abs(wave("dp_matched",iso,energies))*abs(physical(float(iso==0),float(iso==2),charge)) for iso in (0,2)]
        small,large=abs(mags[0]-mags[1]),mags[0]+mags[1]
        def envelope(rr,cross,norm):
            minimizing=np.clip(abs(cross)/norm,small,large)
            return (ew@(rr+norm*minimizing**2-2*abs(cross)*minimizing),
                    ew@(rr+norm*large**2+2*abs(cross)*large))
        rest2=rest**2@(aw/2);mixed=(rest*harmonic)@(aw/2);norm=harmonic**2@(aw/2)
        for idx,row in enumerate(binrows):
            low,high=envelope(rest2[:,idx],mixed[:,idx],norm[idx])
            assert all(low-1e-9<=row[name+"_opp"]<=high+1e-9 for name in MODEL if name.startswith("dp_"))
            row["dp_unfixed_opp_lo"]=low;row["dp_unfixed_opp_hi"]=high
        low,high=envelope(rest2@width,mixed@width,norm@width)
        boxes.append(dict(channel=channel,W_lo=lo,W_hi=hi,obs=width@obs,like=width@like,opposite_lo=low,opposite_hi=high,
                          total_lo=low+width@like,total_hi=high+width@like))
    return rows,sums,boxes


if __name__=="__main__":
    source=bank()
    bins,windows,boxes=calculate(source,6,1)
    coarse,_,_=calculate(source,4,2)
    assert len(bins)==148 and len(windows)==144
    error=max(abs(fine[key]-rough[key]) for fine,rough in zip(bins,coarse)
              for key in fine if key.endswith("_opp") or key in ("dp_unfixed_opp_lo","dp_unfixed_opp_hi"))
    assert error<.025,error
    write("bin-predictions.csv",bins);write("apertures.csv",windows);write("phase-envelopes.csv",boxes)
    print("maximum refinement change, nb per unit cosine:",error)
    for channel in ("charged","neutral"):
        for key in ("born","dispersion","dp_matched"):
            selected=[r for r in windows if r["channel"]==channel and r["model"]==key]
            print(channel,key,np.mean([abs(row["residual"]) for row in selected]),
                  np.mean([row["shape_TV"] for row in selected]),[round(row["opposite"],3) for row in selected])

