from local import *
from native import Lift,background
from number_chart import mul,exp,inv,square,pair


def sources(model,time,change):
    shell=model.shell
    state=shell.initial+change
    model.bind(state,change)
    try:
        ell,bend,_,_,trace=state[:5].real
        mu=shell.mu
        nr=exp(-ell);volume=exp(-ell-2*bend)
        unit=pair(np.ones_like(shell.r))
        obs=shell.incident.external(time)
        energy=state[17].real.copy()
        pressure=pair(obs[1],obs[3])
        sr=pair(np.zeros_like(shell.r),obs[4])
        sc,st=obs[5:7]
        for species in range(3 if shell.flag else 2):
            number,pot=state[8+species*2:10+species*2].real
            vn=mul(nr,shell.diff(pot));vt=pot[1]*np.exp(-bend[0])/shell.r
            vv=square(vn)
            root=np.sqrt(1+vv[0])
            gamma=pair(root,vv[1]/(2*root))
            rest=shell.rho[species]*mul(number,volume)
            stress=mul(rest,mul(vv,inv(gamma)))
            energy+=mul(rest,gamma);pressure+=stress
            sr+=2*stress/3
            sc=sc+rest[0]*vn[0]*vt/root
        if not shell.flag:
            wave,z=state[14:16]
            moment=z+trace/(2*mu)
            gradient=mul(nr,shell.diff(wave))/mu
            excess=square(moment.real)+square(moment.imag)-2*moment.imag
            gg=square(gradient.real)+square(gradient.imag)
            rest=shell.rho[-1]*exp(2*wave.real)
            energy+=mul(rest,unit+(excess+gg)/2)
            pressure+=mul(rest,(3*excess-gg)/2)
            sr+=2*mul(rest,gg)/3
            sc=sc+rest[0]*(gradient[0].conj()*wave[1]).real*np.exp(-bend[0])/(shell.r*mu)
        return energy,pressure,sr,sc,st
    finally:
        model.active={}
        model.elapsed=None


def revise(model,time,state,change,geo,bg,rates,result):
    lift=model.lift;mf=lift.mesh;start=model.shell.initial
    E,S,sr,sc,st=sources(model,time,change)
    K=start[4].real+change[4].real
    shear=start[5].real+change[5].real
    r=mf.r;rf=mf.faces
    scaled=np.exp(-2*change[0,0].real)
    Rraw,radraw=lift.spatial(geo,bg)
    scalar=scaled*lift.launch_scalar+(Rraw-scaled*lift.R_dis)
    radial=scaled*(-lift.launch_x-lift.launch_scalar/2)+(radraw-scaled*lift.rad_dis)
    H=pair(bg["R"],scalar)+2*square(K)/3-1.5*square(shear)-2*E
    trace_dot=scalar+2*K[0]*K[1]+(S[1]-3*E[1])/2
    ell_dd=radial-2*K[0]*K[1]/3-K[1]*shear[0]-K[0]*shear[1]+sr[1]+E[1]/2-S[1]/6
    curl_r,curl_t=lift.divergence(S/3,sr,sc,st,geo,bg)
    geom_pi=lift.initial_m+state[6,1].real
    geom_tau=lift.initial_tau+state[7,1].real
    background_j=model.shell.diff(shear[0]-2*K[0]/3)+3*(1/r+bg["bg"])*shear[0]
    pi_rate=mf.face(K[0])[1:]*geom_pi+(rf*mf.face(K[1]*background_j))[1:]-.5*(rf*mf.grad(H[1]))[1:]-curl_r
    tau_rate=K[0]*geom_tau-.5*H[1]-curl_t
    if model.scheme=="original":
        trace_dot-=H[1]
        ell_dd+=H[1]/2
        corr_r,corr_t=lift.divergence(2*H/3,-H/6,0*sc,0*st,geo,bg)
        pi_rate+=corr_r
        tau_rate+=corr_t
    before=result[4,1].real.copy()
    for index,rate in enumerate(rates):result[index,1]=rate
    result[4,1]=trace_dot
    result[5,1]=-ell_dd-trace_dot/3
    result[6,1]=pi_rate
    result[7,1]=tau_rate
    if not model.shell.flag:
        result[15,1]-=(trace_dot-before)/(2*model.shell.mu)
    return result


class Wave(Canonical):
    def __init__(self,seed,scheme):
        super().__init__(seed,scheme)
        self.lift=Lift(self)

    def nonlinear(self,time,state):
        std,geo,bg,rates=self.lift.physical(state,time)
        result=super().nonlinear(time,std)
        return revise(self,time,state,self.to_wave(std),geo,bg,rates,result)


class Cold(Evolution):
    def __init__(self,seed,scheme):
        super().__init__(1,seed,scheme)
        self.lift=Lift(self)

    def rhs(self,time,state):
        std,geo,bg,rates=self.lift.physical(state,time)
        result=super().rhs(time,std)
        return revise(self,time,state,std,geo,bg,rates,result)
