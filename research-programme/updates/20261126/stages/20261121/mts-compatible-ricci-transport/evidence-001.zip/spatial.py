from local import *
from math import factorial


class Jet:
    __array_priority__=1000

    def __init__(self,coef):
        self.arr=np.asarray(coef)

    def const(self,value):
        array=np.zeros_like(self.arr)
        array[0]=value
        return Jet(array)

    def __add__(self,other):
        if not isinstance(other,Jet):other=self.const(other)
        return Jet(self.arr+other.arr)

    __radd__=__add__

    def __neg__(self):
        return Jet(-self.arr)

    def __sub__(self,other):
        return self+(-other)

    def __rsub__(self,other):
        return -self+other

    def __mul__(self,other):
        if not isinstance(other,Jet):return Jet(self.arr*other)
        return Jet([sum(self.arr[k]*other.arr[n-k] for k in range(n+1)) for n in range(len(self.arr))])

    __rmul__=__mul__

    def inv(self):
        coeff=[1/self.arr[0]]
        for n in range(1,len(self.arr)):
            coeff.append(-sum(self.arr[k]*coeff[n-k] for k in range(1,n+1))/self.arr[0])
        return Jet(coeff)

    def __truediv__(self,other):
        return self*(other.inv() if isinstance(other,Jet) else 1/other)

    def __rtruediv__(self,other):
        return self.inv()*other

    def diff(self):
        return Jet([*(n*self.arr[n] for n in range(1,len(self.arr))),0*self.arr[0]])

    def exp(self):
        coeff=[np.exp(self.arr[0])]
        for n in range(1,len(self.arr)):
            coeff.append(sum(k*self.arr[k]*coeff[n-k] for k in range(1,n+1))/n)
        return Jet(coeff)

    @property
    def val(self):
        return self.arr[0]


def coordinate(points,order=4):
    rr=Jet(np.zeros((order+1,len(points))))
    rr.arr[0]=points
    rr.arr[1]=1
    return rr


def ricci(rr,logA,logAngular,ell,bend,tilt,tensor):
    A=logA.exp(); B=rr*logAngular.exp()
    L=B.diff()/B
    k=2*L/A
    X=-1/(B*B)+k*k/4
    R0=2/(B*B)-2*k.diff()/A-1.5*k*k
    Rn=X+R0/2
    Rt=(R0-Rn)/2
    alpha=B/(rr*A)
    m=2*rr*bend.diff()+2*rr*L*(bend-ell)+3*tilt
    beta=-(B/(2*A))*((alpha*tilt).diff()+3*L*alpha*tilt)+ell+bend+tensor
    R=-2*Rn*ell-4*Rt*bend-2*((B*B*m/(rr*A)).diff()/(A*B*B)-6*beta/(B*B))
    dk=(2*bend.diff()+6*tilt/rr-2*L*ell)/A
    xx=-(4*bend+6*tensor)/(B*B)+k*dk/2
    s0=X+R0/6
    sr=xx+R/6
    cross=B*((xx.diff()-ell*X.diff())/A+1.5*(k*sr+dk*s0))/6
    angular=(B*(cross.diff()+3*L*cross)/A-R/6-sr/2-1.5*s0*ell)/2
    return dict(scalar=R.val,normal=xx.val,cross=cross.val,tensor=angular.val,
                background_scalar=R0.val,background_normal=X.val)


def oracle(rr,logA,logB,ell,bend,tilt,tensor,theta=.713):
    import sympy as sym
    angle=sym.symbols("theta")
    ss,cc=sym.sin(angle),sym.cos(angle)
    Y=(3*cc**2-1)/2
    prime=Y.diff(angle)
    tensor_angle=prime.diff(angle)+3*Y
    tensor_phi=ss*cc*prime+3*ss**2*Y
    angles=(sym.Integer(1),Y,prime,tensor_angle,ss**2,ss**2*Y,tensor_phi)
    from functools import lru_cache
    multipliers=np.asarray([[float(expr.diff(angle,n).subs(angle,theta)) for n in (0,1,2)] for expr in angles])
    A=logA.exp(); B=rr*logB.exp()
    radial=A*A; sphere=B*B
    eps=1e-25j
    entries=((0,0,[(radial,0),(2*eps*radial*ell,1)]),
             (0,1,[(eps*sphere*tilt/rr,2)]),(1,1,[(sphere,0),(2*eps*sphere*bend,1),(eps*sphere*tensor,3)]),
             (2,2,[(sphere,4),(2*eps*sphere*bend,5),(eps*sphere*tensor,6)]))
    def metric(dr,da):
        result=np.zeros((len(rr.val),3,3),dtype=complex)
        for i,j,terms in entries:
            result[:,i,j]=sum(rad.arr[dr]*factorial(dr)*multipliers[idx,da] for rad,idx in terms)
            result[:,j,i]=result[:,i,j]
        return result
    g=metric(0,0); dg=[metric(1,0),metric(0,1),0*g]
    dd=[[metric(2,0),metric(1,1),0*g],[metric(1,1),metric(0,2),0*g],[0*g,0*g,0*g]]
    inv=np.linalg.inv(g)
    derivinv=[-inv@item@inv for item in dg]
    def christoffel(deriv):
        return np.stack([np.stack([np.stack([.5*(deriv[j][:,a,k]+deriv[k][:,a,j]-deriv[a][:,j,k]) for k in range(3)],axis=-1) for j in range(3)],axis=-2) for a in range(3)],axis=1)
    low=christoffel(dg)
    raise_index=lambda mat,lower:np.einsum("nia,najk->nijk",mat,lower)
    conn=raise_index(inv,low)
    dconn=[raise_index(derivinv[k],low)+raise_index(inv,christoffel(dd[k])) for k in range(3)]
    tensor_ricci=np.einsum("nkij,nlkl->nij",conn,conn)-np.einsum("nlik,nkjl->nij",conn,conn)
    for i in range(3):
        for j in range(3):
            tensor_ricci[:,i,j]+=sum(dconn[k][:,k,i,j]-dconn[j][:,k,i,k] for k in range(3))
    R=np.einsum("nij,nij->n",inv,tensor_ricci)
    G=tensor_ricci-g*.5*R[:,None,None]
    lapse=1/np.sqrt(inv[:,0,0])
    normal=inv[:,:,0]*lapse[:,None]
    radial=np.einsum("ni,nij,nj->n",normal,G,normal)
    cross=np.einsum("ni,ni->n",normal,G[:,:,1])/np.sqrt(g[:,1,1])
    tracefree=G[:,1,1]/g[:,1,1]-G[:,2,2]/g[:,2,2]
    return dict(scalar=R.imag/(eps.imag*multipliers[1,0]),normal=radial.imag/(eps.imag*multipliers[1,0]),
                cross=cross.imag/(eps.imag*multipliers[2,0]),tensor=tracefree.imag/(eps.imag*(multipliers[3,0]-multipliers[6,0]/multipliers[4,0])),
                background_scalar=R.real,background_normal=radial.real)
