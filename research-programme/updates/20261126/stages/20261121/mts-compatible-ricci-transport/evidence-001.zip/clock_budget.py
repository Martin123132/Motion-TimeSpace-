from decimal import getcontext
import argparse
from curved_clock import sources
from local import *
from ruler import separate


def run(scheme,grid,quarters):
    guard()
    getcontext().prec=46
    tag=f"clock-{scheme}-{grid}-s1"
    pin=json.loads((HERE/(tag+"-protocol.json")).read_bytes())
    assert pin["source"]==sources()
    def system(flag,seed,scheme):
        with patch.object(case.parent.evolve_speed,"launch",case.parent.launch):
            return case.parent.evolve_speed.system(1024,grid,flag,seed,scheme,3)[0]
    measured={}
    with patch.object(case.parent,"system",system):
        for flag in (0,1):
            model=Evolution(1,1,scheme) if flag else Canonical(1,scheme)
            for tick in range(128,128*quarters+1,128):
                with np.load(HERE/f"{tag}-off{flag}-t{tick}.npz") as snapshot:
                    state=Difference(snapshot["physical_shared"],snapshot["physical_signed"])
                    seconds=tick*float(snapshot["step"])
                host=separate(model.host,seconds,state)
                zero=separate(model.zero,seconds,state.base)
                for key in host:
                    measured[tick,flag,*key]=host[key]-zero[key]
    rows=[]
    for row in core.read(HERE/f"{tag}-q{quarters}.csv"):
        tick,width,channel=int(row["tick"]),float(row["width"]),row["channel"]
        unit=abs(float(row["newton"]))*1e-6
        parts={part:measured[tick,0,width,channel,part]-measured[tick,1,width,channel,part]
               for part in ("sampled_field","local_jacobian","integrated_distance","full")}
        replay=(parts["full"]-float(row["measured"]))/unit
        closure=(sum(parts[key] for key in ("sampled_field","local_jacobian","integrated_distance"))-parts["full"])/unit
        rows.append(dict(grid=grid,scheme=scheme,tick=tick,channel=channel,width=width,
                         field_minus_forecast_ppm=(parts["sampled_field"]-float(row["forecast"]))/unit,
                         jacobian_ppm=parts["local_jacobian"]/unit,ruler_ppm=parts["integrated_distance"]/unit,
                         sum_replay_ppm=replay,closure_ppm=closure))
        assert np.isfinite(closure) and np.isfinite(replay)
        if abs(float(row["residual_ppm"]))<1e6:
            assert abs(replay)<.01 and abs(closure)<.01,(replay,closure)
    table(f"{tag}-q{quarters}-budget.csv",rows)
    print(len(rows), "paired decompositions",flush=True)


if __name__=="__main__":
    parser=argparse.ArgumentParser()
    parser.add_argument("scheme",choices=("adm","original"))
    parser.add_argument("grid",type=int)
    parser.add_argument("quarters",type=int)
    args=parser.parse_args()
    run(args.scheme,args.grid,args.quarters)
