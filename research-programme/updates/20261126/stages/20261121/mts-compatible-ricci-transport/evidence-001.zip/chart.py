from local import *
from scipy.linalg import eigh_tridiagonal


class Chart:
    def __init__(self,cells,edge):
        self.h=edge/cells
        self.faces=np.arange(cells+1)*self.h
        self.r=(self.faces[1:]+self.faces[:-1])/2
        self.mass2=self.weights(2)
        self.mass6=self.weights(6)

    def weights(self,power):
        return (self.faces[1:]**(power+1)-self.faces[:-1]**(power+1))/((power+1)*self.h)

    def face(self,arr):
        return np.concatenate((arr[:1],.5*(arr[1:]+arr[:-1]),arr[-1:]))

    def grad(self,arr):
        return np.concatenate((0*arr[:1],np.diff(arr)/self.h,0*arr[-1:]))

    def back(self,face):
        return np.diff(face)/self.h

    def centre(self,face):
        return (face[1:]+face[:-1])/2

    def full(self,packed):
        return np.r_[0*packed[:1],packed]

    def encode(self,ell,bend,tilt_face,tensor):
        trace=ell+2*bend
        mixed=2*self.faces*self.grad(bend)+2*self.face(bend-ell)+3*tilt_face
        polar=-self.r*self.back(tilt_face)/2-1.5*self.centre(tilt_face)+ell+bend+tensor
        return np.array([ell,trace,mixed[1:],polar])

    def decode(self,state):
        ell,trace,stored,polar=state
        bend=(trace-ell)/2
        tilt=(self.full(stored)-2*self.faces*self.grad(bend)-2*self.face(bend-ell))/3
        tensor=polar+self.r*self.back(tilt)/2+1.5*self.centre(tilt)-ell-bend
        return ell,bend,tilt,tensor

    def curvature(self,state):
        return -2*(self.back(self.faces*self.full(state[2]))-6*state[3])/self.mass2

    def lap(self,values,power):
        mass=self.mass2 if power==2 else self.mass6
        return self.back(self.faces**power*self.grad(values))/mass

    def force(self,state):
        ell,trace,stored,polar=state
        section=self.back(self.faces*self.full(stored))
        scalar=-2*(section-6*polar)/self.mass2
        driver=self.back(self.grad(self.r**2*trace))
        radial=self.lap(ell,6)+(2*section-driver)/self.mass2
        return np.array([radial,-scalar,-.5*(self.faces*self.grad(scalar))[1:],-.5*scalar])

    def matter(self,energy,radial_s,trace_s,div_r,div_t):
        return np.array([radial_s+(energy-trace_s)/2,(3*energy-trace_s)/2,
                         (self.faces*(self.grad(energy)-div_r))[1:],energy-self.r*div_t])

    def spectrum(self,power,angular):
        mass=self.mass2 if power==2 else self.mass6
        bonds=self.faces[1:-1]**power/self.h**2
        diagonal=(np.r_[0.,bonds]+np.r_[bonds,0.]+angular)/mass
        off=-bonds/np.sqrt(mass[:-1]*mass[1:])
        return eigh_tridiagonal(diagonal,off,eigvals_only=True)
