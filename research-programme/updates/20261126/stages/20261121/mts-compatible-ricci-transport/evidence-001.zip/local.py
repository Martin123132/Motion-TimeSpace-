import io
import csv
import json
import sys
from pathlib import Path
from hashlib import sha256

HERE=Path(__file__).resolve().parent
PREVIOUS=HERE.parent/"mts-canonical-full-clock-1024-20261120"
sys.path.insert(0,str(PREVIOUS))
import scope
from scope import np, core, Difference, Canonical, Evolution, case
from unittest.mock import patch


def guard():
    scope.guard()
    if (HERE/"STOP-REQUESTED").exists():
        raise RuntimeError("owner stop")


def locked():
    guard()
    pin=PREVIOUS/"seal.json"
    assert core.sha(pin)=="a01241b19c02cf673d9bf233865905af04c79210361f86ee8bc5d2177e8c226d"
    for name,digest in json.loads(pin.read_bytes())["files"].items():
        assert core.sha(PREVIOUS/name)==digest,name
    scope.locked()


def save(name,raw):
    guard()
    path=HERE/name
    if path.exists():
        assert path.read_bytes()==raw,name
        return
    temp=path.with_suffix(path.suffix+".partial")
    with temp.open("xb") as out:
        out.write(raw)
    temp.rename(path)


def packet(name,**fields):
    stream=io.BytesIO()
    np.savez_compressed(stream,**fields)
    save(name,stream.getvalue())


def table(name,rows):
    stream=io.StringIO(newline="")
    writer=csv.DictWriter(stream,fieldnames=list(rows[0]),lineterminator="\n")
    writer.writeheader()
    writer.writerows(rows)
    save(name,stream.getvalue().encode())


def manifest(name,value):
    save(name,(json.dumps(value,indent=2,allow_nan=False)+"\n").encode())
