from local import *
from chart import Chart


class Mesh(Chart):
    def grad(self,arr):
        return np.concatenate((0*arr[:1],(arr[1:]-arr[:-1])/self.h,0*arr[-1:]))

    def back(self,face):
        return (face[1:]-face[:-1])/self.h

    def full(self,packed):
        return np.concatenate((0*packed[:1],packed))

    def lap(self,values,power):
        mass=self.mass2 if power==2 else self.mass6
        return self.back(self.faces**power*self.grad(values))/mass

    def decode(self,state):
        ell,trace,stored,polar=state
        bend=(trace-ell)/2
        tilt=(self.full(stored)-2*self.faces*self.grad(bend)-2*self.face(bend-ell))/3
        tensor=polar+self.r*self.back(tilt)/2+1.5*self.centre(tilt)-ell-bend
        return ell,bend,tilt,tensor

    def encode(self,ell,bend,tilt_face,tensor):
        mixed=2*self.faces*self.grad(bend)+2*self.face(bend-ell)+3*tilt_face
        polar=-self.r*self.back(tilt_face)/2-1.5*self.centre(tilt_face)+ell+bend+tensor
        return ell,ell+2*bend,mixed[1:],polar


def split(arr):
    return arr.base,arr.delta


def background(model,inc):
    start=model.shell.initial
    ell=start[0,0].real+inc[0,0].real
    bend=start[1,0].real+inc[1,0].real
    def der(idx,degree):
        return model.reference[idx][degree][0]+model.shell.diff(inc[idx,0].real,degree)
    rr=model.shell.r
    eg, bg, bb=der(0,1),der(1,1),der(1,2)
    ne=np.exp(-2*ell)
    scale=np.exp(bend-ell)
    diff=ne*np.expm1(2*(ell-bend))
    curvature=2*diff/rr**2+ne*(-4*bb+4*(eg-3*bg)/rr+4*eg*bg-6*bg**2)
    normalG=-diff/rr**2+ne*bg*(2/rr+bg)
    return dict(ell=ell,bend=bend,eg=eg,bg=bg,ne=ne,scale=scale,delta=diff,R=curvature,X=normalG)


class Lift:
    def __init__(self,model):
        self.model=model
        self.shell=model.shell
        self.mesh=Mesh(len(self.shell.r),self.shell.r.size*self.shell.dx)
        self.r=self.shell.r
        self.start=self.shell.initial
        zero=np.zeros_like(self.start)
        bg=background(model,zero)
        self.initbg=bg
        mesh=self.mesh;r=self.r
        self.initial_geo=mesh.encode(self.start[0,1].real,self.start[1,1].real,mesh.face(self.start[2,1].real),self.start[3,1].real)
        udots=self.base_rate(self.start)
        face=mesh.face(udots[2])
        self.v0=udots
        self.v0face=face
        self.slope_offset=udots[2]-mesh.centre(face)
        self.initial_velocity=mesh.encode(udots[0],udots[1],face,udots[3])
        self.pi_offset=self.to_pi(0*udots[0],self.start[5,0].real,1.5*self.start[5,1].real,self.start[1,1].real,self.start[2,1].real,bg)
        self.tau_offset=self.to_tau(0*udots[0],face,self.start[5,0].real,self.start[0,1].real,bg)
        self.initial_m=self.initial_velocity[2]+self.pi_offset
        self.initial_tau=self.initial_velocity[3]+self.tau_offset
        self.initial_uf=self.initial_velocity
        L,b,v,d=(self.start[i,1].real for i in range(4))
        assert all(np.max(abs(arr))==0 for obj in (v,d) for arr in split(obj))
        rr=self.r; grad=model.reference[1][1][1]; second=model.reference[1][2][1]; first=model.reference[0][1][1]
        F=1+rr*bg["bg"]
        self.launch_scalar=(bg["ne"]*(-4*second+(4*first-12*grad)/rr+4*first*bg["bg"]+4*bg["eg"]*grad-12*bg["bg"]*grad
            -2*L*(-4*model.reference[1][2][0]+4*(bg["eg"]-3*bg["bg"])/rr+4*bg["eg"]*bg["bg"]-6*bg["bg"]**2))
            +((bg["ne"]+bg["delta"])*(8*b+12*L)+4*bg["ne"]*L)/rr**2)
        self.launch_x=(-(bg["ne"]+bg["delta"])*4*b+bg["ne"]*F*(2*rr*grad-2*F*L))/rr**2
        geo=self.geometry(zero,0.)
        self.R_dis,self.rad_dis=self.spatial(geo,bg)

    @staticmethod
    def base_rate(start):
        trace,shear,cross,tensor=(start[i,1].real for i in range(4,8))
        return -trace/3-shear,-trace/3+shear/2,-2*np.exp(start[0,0].real-start[1,0].real)*cross,-2*tensor

    def to_pi(self,mt,s0,velocity_gap,b,v,bg):
        mf=self.mesh;rf=mf.faces
        return (mf.full(mt)+2*rf*mf.face(bg["bg"]*velocity_gap)+3*mf.face(s0)*(rf*mf.grad(b)+3*mf.face(v)))[1:]

    def ang_coeff(self,bg):
        sqdiff=np.expm1(2*(bg["bend"]-bg["ell"]))
        aa=1+sqdiff
        return sqdiff,3*sqdiff+self.r*aa*(4*bg["bg"]-bg["eg"])

    def to_tau(self,bt,vf,s0,ell,bg):
        a,other=self.ang_coeff(bg)
        return bt-(self.r*a*self.mesh.back(vf)+other*self.mesh.centre(vf))/2-1.5*s0*ell

    def geometry(self,state,time):
        mf=self.mesh
        y=tuple(state[i,1].real for i in range(4))
        dv=tuple(x-time*v for x,v in zip(y,self.initial_velocity,strict=True))
        _,__,lifted,tensor=mf.decode(dv)
        l=y[0]
        b=(y[1]-l)/2
        v=lifted+time*self.v0face
        d=tensor+time*self.v0[3]
        vc=mf.centre(lifted)+time*self.v0[2]
        return dict(l=self.start[0,1].real+l,b=self.start[1,1].real+b,vf=mf.face(self.start[2,1].real)+v,v=vc+self.start[2,1].real,
                    d=self.start[3,1].real+d,chart=tuple(old+shift for old,shift in zip(self.initial_geo,y,strict=True)),inc=(l,b,vc,d))

    def spatial(self,geo,bg):
        mf=self.mesh;r,rf=self.r,mf.faces
        l,b,v,d=geo["l"],geo["b"],geo["v"],geo["d"]
        ell,u,m,beta=geo["chart"]
        mface=mf.full(m)
        shift_m=2*rf*mf.face(bg["bg"]*(b-l))
        aa,other=self.ang_coeff(bg)
        shift_beta=-(r*aa*mf.back(geo["vf"])+other*mf.centre(geo["vf"]))/2
        sec=mf.back(rf*mface)
        Hflat=-2*(sec-6*beta)/mf.mass2
        flat=mf.lap(ell,6)+(2*sec-mf.back(mf.grad(r**2*u)))/mf.mass2
        normal=bg["X"]+bg["R"]/2
        tangent=(bg["R"]-normal)/2
        correction=-2*normal*l-4*tangent*b-2*bg["ne"]*(mf.back(rf*shift_m)+(2*bg["bg"]-bg["eg"])*r*mf.centre(mface+shift_m))/mf.mass2
        correction+=12*(bg["delta"]*beta+(bg["ne"]+bg["delta"])*shift_beta)/mf.mass2
        fb=r*bg["bg"]
        xcorr=(-bg["delta"]*(4*b+6*d)+bg["ne"]*fb*(2*r*mf.centre(mf.grad(b))+6*v-2*(2+fb)*l))/mf.mass2
        return bg["ne"]*Hflat+correction,bg["ne"]*flat-xcorr-correction/2

    def physical(self,state,time):
        mf=self.mesh;bg=background(self.model,state);geo=self.geometry(state,time)
        out=state.copy()
        for slot,shift in enumerate(geo["inc"]):out[slot,1]=shift
        trace=self.start[4,1].real+state[4,1].real
        radial=self.start[5,1].real+state[5,1].real
        s0=self.start[5,0].real+state[5,0].real
        vl=-trace/3-radial;vb=-trace/3+radial/2
        delta_mt=state[6,1].real-(self.to_pi(0*radial,s0,1.5*radial,geo["b"],geo["v"],bg)-self.pi_offset)
        mt=self.initial_velocity[2]+delta_mt
        dl=-state[4,1].real/3-state[5,1].real
        db=-state[4,1].real/3+state[5,1].real/2
        delta_v=(mf.full(delta_mt)-2*mf.faces*mf.grad(db)-2*mf.face(db-dl))/3
        vf=self.v0face+delta_v
        dbeta=state[7,1].real-(self.to_tau(0*radial,vf,s0,geo["l"],bg)-self.tau_offset)
        beta=self.initial_velocity[3]+dbeta
        dt=dbeta+self.r*mf.back(delta_v)/2+1.5*mf.centre(delta_v)-dl-db
        out[6,1]=np.expm1(state[1,0].real-state[0,0].real)*self.start[6,1].real-bg["scale"]*mf.centre(delta_v)/2
        out[7,1]=-dt/2
        return out,geo,bg,(vl,vl+2*vb,mt,beta)

    def divergence(self,pressure,shear,cross,angular,geo,bg):
        mf=self.mesh;rf=mf.faces
        sr0,sr=shear
        radial=rf*mf.grad(pressure[1]+sr)+3*mf.face((1+self.r*bg["bg"])*sr)+3*mf.face(sr0)*(rf*mf.grad(geo["b"])+3*mf.face(geo["v"]))-6*mf.face(cross/bg["scale"])
        tang=self.r*bg["scale"]*(self.shell.diff(cross)+3*(1/self.r+bg["bg"])*cross)+pressure[1]-sr/2-2*angular-1.5*sr0*geo["l"]
        return radial[1:],tang
