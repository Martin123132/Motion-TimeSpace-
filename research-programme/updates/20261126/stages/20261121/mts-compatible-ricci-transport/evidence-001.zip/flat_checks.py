from local import *
from chart import Chart
from scipy.special import hyp0f1
from scipy.optimize import brentq
from math import sqrt


def norm(arr):
    return np.linalg.norm(arr.ravel())


def test():
    locked()
    rows=[]
    rng=np.random.default_rng(47261121)
    for count in (48,96,192):
        op=Chart(count,3.)
        raw=rng.normal(size=(4,count))
        geom=op.decode(raw)
        back=op.encode(*geom)
        inv=norm(back-raw)/norm(raw)
        assert inv<2e-11
        pos=rng.normal(size=raw.shape)
        vel=rng.normal(size=raw.shape)
        energy,press,srr,polar_flux=rng.normal(size=(4,count))
        current_r,div_r=rng.normal(size=(2,count+1))
        current_t,div_t=rng.normal(size=(2,count))
        current_r[[0,-1]]=div_r[[0,-1]]=0
        scalar=op.curvature(pos)-2*energy
        residual_r=op.full(vel[2])-op.faces*current_r
        residual_t=vel[3]-op.r*current_t
        energy_rate=-(op.back(op.faces**2*current_r)-6*op.r*current_t)/op.mass2
        hrate=op.curvature(vel)-2*energy_rate
        expect=-2*(op.back(op.faces*residual_r)-6*residual_t)/op.mass2
        accel=op.force(pos)+op.matter(energy,srr,press,div_r,div_t)
        momentum_r=op.full(accel[2])+op.faces*div_r
        momentum_t=accel[3]+op.r*div_t
        errH=norm(hrate-expect)/norm(expect)
        errM=max(norm(momentum_r+.5*op.faces*op.grad(scalar))/norm(momentum_r),
                 norm(momentum_t+.5*scalar)/norm(momentum_t))
        assert max(errH,errM)<2e-13
        scalar_tt=op.curvature(op.force(pos))
        vacuum=op.curvature(pos)
        err_wave=norm(scalar_tt-op.lap(vacuum,2)+6*vacuum/op.mass2)/norm(scalar_tt)
        assert err_wave<2e-13
        specH=op.spectrum(2,6)
        specTT=op.spectrum(6,0)
        assert specH[0]>0 and specTT[0]>-1e-10
        rows.append(dict(cells=count,inverse_relative=inv,H_transport=errH,M_transport=errM,source_free_scalar_wave=err_wave,
            min_scalar_frequency2=specH[0],min_tensor_frequency2=specTT[0],tensor_first_nonconstant_frequency2=specTT[1]))
    table("flat-conservation.csv",rows)


def physical():
    edge=3.
    wavenumber=brentq(lambda k:hyp0f1(4.5,-(k*edge)**2/4),2.,2.7)
    rows=[]
    for count in (48,96,192):
        op=Chart(count,edge)
        initial=hyp0f1(3.5,-(wavenumber*op.r)**2/4)
        pos=np.zeros((4,count));pos[0]=initial
        vel=np.zeros_like(pos)
        duration=1.9/wavenumber
        ticks=int(np.ceil(duration/(.12*op.h)))
        step=duration/ticks
        def energy():
            return (op.h/2)*(np.sum(op.mass6*vel[0]**2)+np.sum(op.faces**6*op.grad(pos[0])**2))
        e0=energy()
        for tick in range(ticks):
            vel+=.5*step*op.force(pos)
            pos+=step*vel
            vel+=.5*step*op.force(pos)
        expected=initial*np.cos(wavenumber*duration)
        error=norm((pos[0]-expected)*np.sqrt(op.mass6))/norm(initial*np.sqrt(op.mass6))
        frequency=np.sqrt(op.spectrum(6,0)[1])
        speed_error=abs(frequency/wavenumber-1)
        rows.append(dict(cells=count,k=wavenumber,time=duration,ticks=ticks,tensor_relative=error,speed_error=speed_error,
                         energy_relative=abs(energy()/e0-1),max_constraint=max(abs(op.curvature(pos)))))
        assert np.max(abs(pos[1:]))==0
    assert all(earlier["tensor_relative"]>3.5*later["tensor_relative"] for earlier,later in zip(rows,rows[1:]))
    assert rows[-1]["speed_error"]<1e-4
    table("tensor-wave.csv",rows)
    print(rows[-1],flush=True)


if __name__=="__main__":
    test()
    physical()
