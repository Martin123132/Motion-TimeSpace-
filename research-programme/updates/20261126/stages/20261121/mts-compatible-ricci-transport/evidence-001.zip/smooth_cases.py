from local import *
import spatial
from spatial import Jet, coordinate, ricci,oracle
from numpy.polynomial import polynomial as poly


def fitjet(values,indices,spacing):
    width=5
    nodes=np.arange(-width,width+1,dtype=float)
    weights=np.linalg.inv(poly.polyvander(nodes,10))[:5]
    local=values[indices[:,None]+nodes.astype(int)]
    delta=local-values[indices,None]
    coeff=(weights@delta.T)/spacing**np.arange(5)[:,None]
    coeff[0]=values[indices]
    return Jet(coeff)


def fixture(rr):
    sq=rr*rr
    tensor=.17*(-sq).exp()
    tilt=tensor+sq*(-.6*sq).exp()/3
    shear=2*tilt-tensor/2+sq*sq*(-.75*sq).exp()/7
    trace=sq*(-.32*sq).exp()/6
    return (rr,.08*(-sq).exp(),-.06*(-.4*sq).exp(),(trace+2*shear)/3,(trace-shear)/3,tilt,tensor)


def main():
    locked()
    rows=[]
    def compare(label,data):
        expected=ricci(*data)
        for angle in (.54,1.17):
            direct=oracle(*data,theta=angle)
            for name,field in direct.items():
                measured=expected[name]
                diff=np.max(abs(measured-field))
                scale=np.max(abs(field))
                rows.append(dict(source=label,angle=angle,field=name,reference=scale,absolute=diff,
                                 relative=diff/scale if scale else "",tolerance=3e-12*max(scale,1) if name.startswith("background") else 1e-10*scale+1e-32))
                assert diff<=rows[-1]["tolerance"],(label,name,diff,scale)
    compare("smooth-strong",fixture(coordinate(np.linspace(.13,2.60,83))))
    for flag in (0,1):
        for seed in (1,-1):
            model=Evolution(1,seed,"adm") if flag else Canonical(seed,"adm")
            for tick in (0,128,512):
                if tick:
                    name=f"adm-s{seed}-off{flag}-n512-t{tick}.npz"
                    assert core.sha(PREVIOUS/name)==json.loads((PREVIOUS/(name+".json")).read_bytes())["sha"]
                    with np.load(PREVIOUS/name) as bank:
                        shift=Difference(bank["shared"],bank["signed"])
                    physical=shift if flag else model.to_wave(shift)
                    full=model.host.initial+physical.base+physical.delta
                else:full=model.host.initial
                shell=model.host
                indices=np.arange(85,365,6)
                rr=coordinate(shell.r[indices])
                coeff=[fitjet(arr,indices,shell.dx) for arr in (full[0,0].real,full[1,0].real,*(full[j,1].real for j in range(4)))]
                compare(f"q1024-off{flag}-s{seed}-t{tick}",(rr,*coeff))
    table("independent-spatial-ricci.csv",rows)
    print(len(rows),"components")


if __name__=="__main__":
    main()
