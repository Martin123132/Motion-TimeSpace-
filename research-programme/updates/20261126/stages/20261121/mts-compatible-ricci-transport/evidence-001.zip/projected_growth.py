from local import *
from chart import Chart


def main():
    rows=[]
    for cells in (64,96,128):
        mesh=Chart(cells,1.)
        basis=np.eye(cells)
        def acceleration(curvature):
            return (mesh.back(mesh.faces*mesh.face(curvature))+3*curvature)/mesh.mass2
        matrix=np.stack([acceleration(unit) for unit in basis],axis=1)
        vals,vecs=np.linalg.eig(matrix)
        rate=np.sqrt(vals.astype(complex))
        index=np.argmax(rate.real)
        vec=vecs[:,index]
        assert abs(rate[index].imag)<1e-10 and np.argmax(abs(vec))==0
        h=mesh.h
        rows.append(dict(cells=cells,rate_times_h=h*rate[index].real,
            centre_fraction_squared=float(abs(vec[0])**2/np.linalg.norm(vec)**2),
            residual=np.linalg.norm(matrix@vec-vals[index]*vec)/abs(vals[index])))
    table("projected-flat-growth.csv",rows)
    outputs=[]
    for flag in (0,1):
        values=[]
        for tick in (256,384,512):
            with np.load(HERE/f"clock-original-160-s1-off{flag}-t{tick}.npz") as bank:
                values.append(float(bank["physical_signed"][0,1,0].real))
                step=float(bank["step"])
        factor=rows[-1]["rate_times_h"]*160*step
        predicted=128*np.log(sum(factor**n/fact for n,fact in enumerate((1,1,2,6,24))))
        for tick,left,right in zip((384,512),values[:-1],values[1:],strict=True):
            measured=np.log(abs(right/left))
            outputs.append(dict(flag=flag,tick=tick,measured_log_gain=measured,flat_RK4_log_gain=predicted,
                                factor_ratio=np.exp(measured-predicted)))
    table("projected-growth-replay.csv",outputs)
    print(rows[-1],outputs[-1])


if __name__=="__main__":
    main()
