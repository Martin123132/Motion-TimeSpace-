from decimal import getcontext
import argparse
from local import PREVIOUS, HERE, guard, locked, np, core, case, patch, scope, manifest, table, packet
from trial import Cold, Wave
import ref_endpoint
import phase_stride
from readouts import member_readings
from read_clock import canonical_reader


def sources():
    return {name:core.sha(HERE/name) for name in ("local.py","native.py","chart.py","trial.py","curved_clock.py")}


def calculate(scheme,grid,seed,quarters):
    locked()
    getcontext().prec=46
    pin=scope.check_freeze()
    forecast_path=PREVIOUS/"predicted-gravity.csv"
    forecast={(int(row["seed"]),float(row["width"]),float(row["fraction"])):(float(row["newton"]),float(row["prediction"]))
              for row in core.read(forecast_path) if row["mode"]=="flrw-live"}
    tag=f"clock-{scheme}-{grid}-s{seed}"
    manifest(tag+"-protocol.json",dict(prediction=core.sha(forecast_path),source=sources(),previous=pin,steps=512,quarter=128,
             grid=grid,seed=seed,scheme=scheme,normalization="absolute signed Newton term",ppm_gate=20,channels=["gauss","ricci"],
             priors_changed=False,launch_correction="analytic-minus-discrete fixed offset scaled by local radial metric",
             note="An evolution test. The mixed numerical chart is experimental; use the original detector."))
    def system(flag,seed,scheme):
        with patch.object(case.parent.evolve_speed,"launch",case.parent.launch):
            return case.parent.evolve_speed.system(1024,grid,flag,seed,scheme,3)[0]
    measurements={}
    with patch.object(case.parent,"system",system):
        for flag in (0,1):
            guard()
            model=Cold(seed,scheme) if flag else Wave(seed,scheme)
            total=4096*np.pi/model.shell.mu
            step=total/512
            advance=model.time_step(step)
            state=np.zeros_like(model.shell.initial)
            start=model.lift.physical(state,0.)[0]
            assert not np.any(start.base) and not np.any(start.delta)
            for tick in range(1,128*quarters+1):
                if tick%8==1:guard()
                state=advance((tick-1)*step,state)
                if tick%128:continue
                assert np.isfinite(state.base).all() and np.isfinite(state.delta).all()
                clock=tick*step
                std=model.lift.physical(state,clock)[0]
                actual=std if flag else model.to_wave(std)
                if not flag:assert model.min_number>0 and model.min_factor>0
                name=f"{tag}-off{flag}-t{tick}.npz"
                packet(name,shared=state.base,signed=state.delta,physical_shared=actual.base,
                       physical_signed=actual.delta,number=std.delta[12 if flag else 14].real,step=step,tick=tick)
                original=ref_endpoint.fixed_tide
                def precise(shell,start,change):
                    return canonical_reader(shell,start,change,original)
                with patch.object(ref_endpoint,"fixed_tide",precise),patch.object(phase_stride,"fixed_tide",precise):
                    host=member_readings(model.host,clock,actual)
                    zero=member_readings(model.zero,clock,actual.base)
                for key in host:
                    measurements[tick,flag,*key]=host[key]-zero[key]
                print(scheme,grid,flag,tick,flush=True)
    rows=[]
    for tick in range(128,quarters*128+1,128):
        for width in (.15,.30):
            ref,pred=forecast[seed,width,tick/512]
            for channel in ("gauss","ricci"):
                actual=measurements[tick,0,width,channel]-measurements[tick,1,width,channel]
                ppm=(actual-pred)/(1e-6*abs(ref))
                assert np.isfinite(ppm)
                rows.append(dict(scheme=scheme,grid=grid,seed=seed,tick=tick,width=width,channel=channel,
                                 newton=ref,forecast=pred,measured=actual,residual_ppm=ppm,inside=abs(ppm)<=20))
    table(f"{tag}-q{quarters}.csv",rows)
    print("maximum absolute residual ppm",max(abs(row["residual_ppm"]) for row in rows),flush=True)


if __name__=="__main__":
    parser=argparse.ArgumentParser()
    parser.add_argument("scheme",choices=("original","adm"))
    parser.add_argument("grid",type=int,choices=(80,160,320))
    parser.add_argument("seed",type=int,choices=(-1,1))
    parser.add_argument("quarters",type=int,choices=(1,2,3,4))
    args=parser.parse_args()
    calculate(args.scheme,args.grid,args.seed,args.quarters)
