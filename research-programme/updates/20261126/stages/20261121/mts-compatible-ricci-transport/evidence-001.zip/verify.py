from local import *
from curved_clock import sources


def run():
    locked()
    assert not list(HERE.glob("*.partial"))
    forecast=core.read(PREVIOUS/"predicted-gravity.csv")
    assert len(core.read(HERE/"independent-spatial-ricci.csv"))==156
    for row in core.read(HERE/"independent-spatial-ricci.csv"):
        assert float(row["absolute"])<=float(row["tolerance"])
    flat=core.read(HERE/"flat-conservation.csv")
    assert len(flat)==3 and max(float(row[key]) for row in flat for key in ("H_transport","M_transport"))<1.5e-16
    tensors=core.read(HERE/"tensor-wave.csv")
    for first,second in zip(tensors[:-1],tensors[1:],strict=True):
        assert float(second["max_constraint"])==0
        assert all(3.9<float(first[key])/float(second[key])<4.1 for key in ("speed_error","energy_relative"))
    diagnostics={}
    for scheme,grid,quarters in (("original",160,4),("adm",160,1),("adm",320,1)):
        tag=f"clock-{scheme}-{grid}-s1"
        pin=json.loads((HERE/(tag+"-protocol.json")).read_bytes())
        assert pin["source"]==sources() and pin["ppm_gate"]==20 and pin["previous"]==scope.check_freeze()
        assert pin["prediction"]==core.sha(PREVIOUS/"predicted-gravity.csv")
        rows=core.read(HERE/f"{tag}-q{quarters}.csv")
        budget=core.read(HERE/f"{tag}-q{quarters}-budget.csv")
        keys={(int(row["tick"]),float(row["width"]),row["channel"]) for row in rows}
        assert keys=={(tick,width,channel) for tick in range(128,quarters*128+1,128) for width in (.15,.3) for channel in ("gauss","ricci")}
        assert len(rows)==len(keys)==len(budget)
        for row,parts in zip(rows,budget,strict=True):
            for key in ("tick","channel","width"):assert row[key]==parts[key]
            matches=[item for item in forecast if item["mode"]=="flrw-live" and item["seed"]=="1" and float(item["fraction"])==int(row["tick"])/512 and item["width"]==row["width"]]
            assert len(matches)==1 and row["forecast"]==matches[0]["prediction"] and row["newton"]==matches[0]["newton"]
            residual=(float(row["measured"])-float(row["forecast"]))/(abs(float(row["newton"]))*1e-6)
            assert residual==float(row["residual_ppm"]) and (abs(residual)<=20)==(row["inside"]=="True")
            assert row["inside"]=="False"
            if scheme=="adm":
                diagnostics[grid,row["width"],row["channel"]]=residual
        for tick in range(128,quarters*128+1,128):
            for flag in (0,1):
                with np.load(HERE/f"{tag}-off{flag}-t{tick}.npz") as state:
                    assert int(state["tick"])==tick and float(state["step"])>0
                    assert state["physical_signed"].shape==state["shared"].shape==(20,2,3*grid)
                    assert all(np.all(np.isfinite(state[key])) for key in state.files)
    for width in ("0.15","0.3"):
        for channel in ("gauss","ricci"):
            assert 3.9<diagnostics[160,width,channel]/diagnostics[320,width,channel]<4.1
    growth=core.read(HERE/"projected-growth-replay.csv")
    assert len(growth)==4 and max(abs(float(row["factor_ratio"])-1) for row in growth)<.00024
    files={item.name:core.sha(item) for item in sorted(HERE.iterdir()) if item.is_file() and item.name!="seal.json"}
    if sys.argv[1:]==["--seal"]:
        manifest("seal.json",dict(files=files,parent=core.sha(PREVIOUS/"seal.json")))
    else:assert len(sys.argv)==1
    seal=json.loads((HERE/"seal.json").read_bytes())
    assert seal["files"]==files and seal["parent"]==core.sha(PREVIOUS/"seal.json")
    print(len(files),"files",core.sha(HERE/"seal.json"),flush=True)


if __name__=="__main__":
    run()
