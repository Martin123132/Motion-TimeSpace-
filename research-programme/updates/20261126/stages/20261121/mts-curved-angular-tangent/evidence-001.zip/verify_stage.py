import csv
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
PARENT = HERE.parent / "mts-late-angular-clock-20261121"


def digest(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def read(path):
    return json.loads(path.read_bytes())


def files_match(folder, receipt):
    for name, expected in receipt["files"].items():
        assert digest(folder / name) == expected, name


def main():
    contract = read(HERE / "contract.json")
    assert contract["parent"] == digest(PARENT / "seal.json") == "2386e63e4fb88d03302e1fe803934f9ff74755557d7266929207001b901cfb93"
    files_match(PARENT, read(PARENT / "seal.json"))
    assert contract["source"] == digest(HERE / "curved_tangent.py")
    for name in ("weighted-freeze.json", "second-freeze.json"):
        files_match(HERE, read(HERE / name))
    for pattern, count, pin_key, pin_name in (("s*-off*-*.json", 18, "contract", "contract.json"),
                                             ("w20-*.json", 12, "freeze", "weighted-freeze.json"),
                                             ("second-o*.json", 4, "freeze", "second-freeze.json")):
        receipts = list(HERE.glob(pattern))
        assert len(receipts) == count
        for path in receipts:
            receipt = read(path)
            assert receipt[pin_key] == digest(HERE / pin_name) and receipt["files"]
            files_match(HERE, receipt)
    with (HERE / "weighted-proper-bands.csv").open(newline="") as source:
        bands = list(csv.DictReader(source))
    assert len(bands) == 8 and all(abs(float(row["ppm"])) <= 20 and row["inside"] == "True" for row in bands)
    target = HERE / "seal.json"
    payload = {path.name: digest(path) for path in sorted(HERE.iterdir()) if path.is_file() and path != target}
    if target.exists():
        assert read(target)["files"] == payload
    else:
        with target.open("x", encoding="utf-8", newline="\n") as stream:
            json.dump(dict(parent=contract["parent"], files=payload), stream, indent=2)
            stream.write("\n")
    print(len(payload), "verified files;", digest(target))


if __name__ == "__main__":
    main()
