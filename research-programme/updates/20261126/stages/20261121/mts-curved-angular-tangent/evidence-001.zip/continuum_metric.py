"""Continuum linear ADM impulse, rotating the Cartesian quadrupole at fixed sightline."""
from curved_tangent import HERE,np,WIDTH,AMP,packet,table,TICKS,anchor
from scipy.special import roots_legendre
from flat_pulse import integrals


def kernels(order,angular,mode="tangential"):
    roots,weights=roots_legendre(order);wave=9*(roots+1)
    cosines,polar=roots_legendre(angular)
    azimuth=2*np.pi*np.arange(16)/16
    cosines3=np.broadcast_to(cosines[:,None],(angular,len(azimuth)))
    sine=np.sqrt(1-cosines3**2)
    normal=np.stack((sine*np.cos(azimuth),sine*np.sin(azimuth),cosines3),axis=-1)
    normal2=normal[...,None]*normal[...,None,:]
    eye=np.eye(3);proj=eye-normal2
    radial=wave[:,None,None,None,None];squared=radial**2
    directions=(np.diag([-.5,-.5,1.]),np.array([[0.,0.,1.],[0.,0.,0.],[1.,0.,0.]]),np.diag([1.,-1.,0.]))
    both=[];trans=[]
    for block,quad in enumerate(directions):
        vec=normal@quad
        sym=vec[...,None]*normal[...,None,:]+normal[...,None]*vec[...,None,:]
        angular_q=np.sum(vec*normal,axis=-1)[...,None,None]
        source=((3-2*squared+squared**2/8)*quad+(1.5-squared/8)*squared*sym
                +(-1+squared/16)*squared*angular_q*eye+squared**2*angular_q*normal2/16)
        if mode=="constant-tensor":source=np.broadcast_to(quad,source.shape)
        else:assert mode=="tangential"
        velocity=-2*source
        assert np.max(abs(np.trace(source,axis1=-1,axis2=-2)))<1e-9
        transverse=proj@velocity@proj
        correction=transverse+normal2*np.trace(transverse,axis1=-1,axis2=-2)[...,None,None]
        def select(data):
            mean=data.mean(axis=2)
            if block==0:return [mean[...,2,2]/2,(mean[...,0,0]+mean[...,1,1])/4]
            if block==1:return [mean[...,0,2]/2]
            return [(mean[...,0,0]-mean[...,1,1])/4]
        both.extend(select(velocity));trans.extend(select(correction))
    factor=(9*weights*wave**2*np.exp(-wave**2/4))[:,None]*polar[None,:]/(4*np.sqrt(np.pi))
    return wave, wave[:,None]*cosines,factor*np.array(both),factor*np.array(trans)


def fourier(radius,elapsed,bank):
    wave,projected,original,correction=bank
    u=elapsed/WIDTH
    transform=u*original+(np.sin(wave*u)/wave-u)[None,:,None]*correction
    velocity=original+(np.cos(wave*u)-1)[None,:,None]*correction
    derivatives=[]
    for order in (0,1,2):
        phase=(radius/WIDTH)[:,None]*projected.ravel()[None,:]
        basis=(-2*np.sin(phase/2)**2,-np.sin(phase),-np.cos(phase))[order]
        field=(transform*projected**order).reshape(4,-1)@basis.T
        if order==0:
            origin=np.sum(transform,axis=(1,2))
            shape=np.array([.5,-.25,.5,.5])
            amplitude=np.dot(origin,shape)/np.dot(shape,shape)
            assert np.max(abs(origin-amplitude*shape))<1e-12
            field+=amplitude*shape[:,None]
        derivatives.append(field)
    speed=velocity.reshape(4,-1)@np.cos((radius/WIDTH)[:,None]*projected.ravel()).T
    return np.array(derivatives),speed


def scalar(radius,value,slope,hessian):
    ell,bend,tilt,tensor=value
    return (-4*hessian[1]+(4*slope[0]-12*slope[1]-12*slope[2])/radius+
            (16*ell+8*bend-24*tilt+12*tensor)/radius**2)


def legacy(values,dx,weights,average):
    size=values.shape[-1]
    padded=np.concatenate((values[...,2::-1],values,values[...,:-4:-1]),axis=-1)
    face=sum(weight*(padded[...,3+idx:3+idx+size+1]-padded[...,2-idx:2-idx+size+1])
             for idx,weight in enumerate(weights))/dx
    ext=np.concatenate((-face[...,2:0:-1],face,-face[...,-2:-4:-1]),axis=-1)
    first=sum(weight*(ext[...,3+idx:3+idx+size]+ext[...,2-idx:2-idx+size]) for idx,weight in enumerate(average))
    second=sum(weight*(ext[...,3+idx:3+idx+size]-ext[...,2-idx:2-idx+size]) for idx,weight in enumerate(weights))/dx
    return first,second


def tests():
    from curved_tangent import system
    with system(1,1,0,0) as model:weights=model.shell.weights;average=model.shell.average;dt=4096*np.pi/(model.shell.mu*1024)
    bank=kernels(80,52);fine=kernels(112,72)
    outputs={};rows=[]
    for grid in (320,640,1280):
        radius=(np.arange(int(.12*grid)+10)+.5)/grid;coord=radius/WIDTH
        for tick in TICKS:
            time=(tick-960)*dt
            data,speed=fourier(radius,time,bank)
            check,speed2=fourier(radius,time,fine)
            assert max(np.max(abs(data-check)),np.max(abs(speed-speed2)))<1e-11
            if tick==960:
                expect=np.zeros_like(speed);expect[3]=-2*coord**4*np.exp(-coord**2)
                assert np.max(abs(speed-expect))<1e-12
            exact=scalar(coord,*data)*AMP/WIDTH
            green=integrals(radius,time,128)[1]*AMP
            norm=max(np.linalg.norm(green),1e-60)
            assert np.linalg.norm(exact-green)/norm<1e-8
            assert abs(exact[0]-green[0])<1e-7*abs(green[0])+1e-50
            first,second=legacy(data[0],1/(grid*WIDTH),weights,average)
            sampled=scalar(coord,data[0],first,second)*AMP/WIDTH
            key=f"g{grid}t{tick}"
            outputs[key+"_metric"]=data[0]*AMP*WIDTH;outputs[key+"_exact"]=exact;outputs[key+"_legacy"]=sampled
            outputs[f"g{grid}r"]=radius
            for region,mask in (("first",radius<1/grid),("core",radius<.1)):
                scale=np.linalg.norm(green[mask])
                rows.append(dict(grid=grid,tick=tick,region=region,exact_first=green[mask][0],sampled_first=sampled[mask][0],
                                 relative=np.linalg.norm((sampled-green)[mask])/scale if scale else ""))
    packet("continuum-metric.npz",**outputs);table("exact-metric-reader.csv",rows)

if __name__=="__main__":tests()
