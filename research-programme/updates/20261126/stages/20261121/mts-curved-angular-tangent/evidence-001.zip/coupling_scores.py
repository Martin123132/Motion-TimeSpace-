from curved_tangent import *
from local_balance import readout,mixed,angular,geometric
from trial import sources


def sample(seed,flag,mode,tick):
    tag=f"s{seed}-off{flag}-{mode}"
    cert=json.loads((HERE/(tag+".json")).read_bytes())
    path=HERE/f"{tag}-t{tick}.npz"
    assert cert["contract"]==lab.sha(HERE/"contract.json") and cert["files"][path.name]==lab.sha(path)
    with np.load(path) as saved:return {key:saved[key] for key in saved.files}


def three(values):
    total=values[0];remainder=np.zeros_like(total)
    for other in values[1:]:
        together=total+other
        remainder+=np.where(abs(total)>=abs(other),(total-together)+other,(other-together)+total)
        total=together
    return total+remainder


def pulses():
    rows=[];scales=[];stress=[]
    for flag in (0,1):
        with system(1,flag,0,0) as model:
            for tick in TICKS:
                pulse=sample(1,flag,"pulse",tick);negative=sample(1,flag,"minus",tick);scaled=sample(1,flag,"scaled",tick)
                for key in ("base","delta","raw","P","ind_P","H","ind_H","J","ind_J"):
                    val=pulse[key];m=negative[key];s=scaled[key]/AMP_SCALE
                    n=np.linalg.norm(val);ep=np.linalg.norm(val+m);es=np.linalg.norm(val-s)
                    if n:assert max(ep,es)/n<1e-8,(flag,tick,key,ep/n,es/n)
                    else:assert ep==0 and es==0
                    scales.append(dict(flag=flag,tick=tick,key=key,norm=n,sign_error=ep,power_error=es))
                with entry(code(1,flag,768,1,0),tick) as ctrl,entry(code(1,flag,960,1,1),tick) as high,entry(code(1,flag,960,1,-1),tick) as low:
                    for key in ("ind_H","H","ind_P","P","J","ind_J"):
                        for branch,obs,pred in (("plus",high[key]-ctrl[key],pulse[key]),("minus",low[key]-ctrl[key],negative[key]),
                                                ("odd",(high[key]-low[key])/2,pulse[key])):
                            for name,mask in (("first",pulse["r"]<1/GRID),("inner",pulse["r"]<.1)):
                                den=np.linalg.norm(obs[mask]);scale=np.linalg.norm(pred[mask]);err=np.linalg.norm((obs-pred)[mask])
                                rows.append(dict(flag=flag,tick=tick,quantity=key,branch=branch,region=name,
                                          observed_first=obs[mask][0],predicted_first=pred[mask][0],norm_observed=den,
                                          norm_predicted=scale,error=err,relative_observed=err/den if den else "",relative_predicted=err/scale if scale else ""))
                if tick==1024:
                    state,clock=anchor(1,flag,tick)
                    state.base[:,1]=pulse["base"];state.delta[:,1]=pulse["delta"]
                    calc=compute(model,state,clock);raw=lab.rawfield(model,state,clock)
                    energy,pressure,diagonal,cross,tensor=sources(model,clock,raw)
                    currents=[calc["J_"+key] for key in ("env","matter1","matter2","heavy")]
                    for label,val in [("J_"+key,calc["J_"+key]) for key in ("env","matter1","matter2","heavy")]+[
                        ("delta_energy",energy.delta[1]),("pressure_trace",pressure.delta[1]),("stress_radial",diagonal.delta[1]),
                        ("stress_cross",cross.delta),("stress_tensor",tensor.delta),("total_current",calc["J"])]:
                        mask=pulse["r"]<.1
                        stress.append(dict(flag=flag,term=label,at_first=float(np.real(val[0])),core_norm=float(np.linalg.norm(val[mask]))))
                    assert np.linalg.norm(sum(currents)-calc["J"])<=1e-12*sum(np.linalg.norm(val) for val in currents)
    table("signed-pulse-predictions.csv",rows);table("homogeneity.csv",scales);table("induced-matter.csv",stress)


def forced():
    rawrows=[];weak=[];observations=[];tidal=[]
    forecasts={(int(row["seed"]),float(row["width"])):row for row in lab.parent.core.read(lab.PREV/"matched-gravity-prediction.csv") if float(row["fraction"])==1.}
    for seed in (1,-1):
        totals={}
        for flag in (0,1):
            with system(seed,flag,1,1) as model:
                for tick in TICKS:
                    parts=[sample(seed,flag,mode,tick) for mode in ("carried","prepared","surrounding")]
                    state,clock=anchor(seed,flag,tick)
                    for key in ("base","delta"):getattr(state,key)[:,1]=three([piece[key] for piece in parts])
                    fitted=compute(model,state,clock)
                    with entry(code(seed,flag,768,1,0),tick) as ref:
                        radius=ref["r"];current=ref["J"]
                        for key in ("J","H","P","ind_J","ind_H","ind_P"):
                            exact=ref[key];value=fitted[key]
                            separate=three([item[key] for item in parts])
                            for name,mask in (("first",radius<1/GRID),("inner",radius<.3)):
                                den=np.linalg.norm(exact[mask]);err=np.linalg.norm((value-exact)[mask])
                                cond=sum(np.linalg.norm(item[key][mask]) for item in parts)
                                rawrows.append(dict(seed=seed,flag=flag,tick=tick,key=key,region=name,original=exact[mask][0],
                                    reassembled=value[mask][0],carried=parts[0][key][mask][0],prepared=parts[1][key][mask][0],
                                    surrounding=parts[2][key][mask][0],relative=err/den if den else "",absolute=err,
                                    split_error_over_parts=np.linalg.norm((value-separate)[mask])/cond if cond else "",
                                    condition=cond/den if den else "",current_norm=np.linalg.norm(current[mask])))
                        if tick in (960,1024):
                            mapped,aux=model.mass.decode(state);raw,_,bg,_=model.lift.physical(mapped,clock)
                            metric,curvature=geometric(model,mapped,aux,clock)
                            size=radius**2;mass=np.expm1(2*(bg["ell"]-bg["bend"]))/size
                            dk=(aux["kb"]-aux["ka"])/size
                            terms=mixed(metric,curvature,size,mass,-aux["kb"],dk)
                            ang=angular(metric,terms,size,mass,(bg["eg"]-bg["bg"])/radius,bg["bg"]/(2*radius),dk,0.,0.)
                            coefficients=[terms[0].delta,terms[1].delta,ang.delta,fitted["J"],fitted["ind_P"]]
                            for edge in (.025,.3):
                                for rule in (0,8,16):
                                    val=readout(radius,coefficients,edge,True,rule)
                                    weak.append(dict(seed=seed,flag=flag,tick=tick,edge=edge,order=rule,**val))
                    raw=lab.rawfield(model,state,clock)
                    member=lab.read_tide(model,clock,raw)
                    for (width,channel),value in member.items():
                        observations.append(dict(seed=seed,flag=flag,tick=tick,width=width,channel=channel,tide=value))
                        if tick==1024:totals[flag,width,channel]=value
        for width in (.15,.3):
            forecast=forecasts[seed,width]
            unit=1e-6*abs(float(forecast["matched_newton"]))
            for channel in ("ricci","gauss"):
                value=totals[0,width,channel]-totals[1,width,channel]
                error=(value-float(forecast["matched"]))/unit
                tidal.append(dict(seed=seed,width=width,channel=channel,wave=totals[0,width,channel],cold=totals[1,width,channel],
                         combined=value,forecast=forecast["matched"],newton=forecast["matched_newton"],ppm=error,inside=abs(error)<=20))
    table("real-source-reassembly.csv",rawrows);table("local-volume.csv",weak)
    table("proper-observers.csv",observations);table("unchanged-bands.csv",tidal)

if __name__=="__main__":
    if sys.argv[1:]==["pulse"]:pulses()
    elif sys.argv[1:]==["forced"]:forced()
    else:raise ValueError("select pulse or forced")
