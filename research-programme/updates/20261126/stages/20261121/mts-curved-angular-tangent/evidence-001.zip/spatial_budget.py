"""Separate field evolution, sampled curvature and actual curved/matter contributions."""
from curved_tangent import *
from continuum_metric import legacy,scalar
from mts_sbp12 import Regular
from types import SimpleNamespace
from scipy.special import roots_legendre


def flat(grid,edge,subdivision,dt):
    mesh=Regular(int(edge*grid),edge);tube=SimpleNamespace(mesh=mesh)
    radius=(np.arange(len(mesh.r))+.5)/grid
    state=np.zeros((8,len(radius)))
    state[7]=-2*(radius/WIDTH)**4*np.exp(-(radius/WIDTH)**2)
    def rhs(now):
        ell,trace,mass,beta,extr,shear,pi,tau=now
        ham,rad=principal(tube,now[:4])
        return np.array([-extr/3-shear,-extr,pi,tau,ham,-rad-ham/3,-(mesh.faces*mesh.grad(ham))[1:]/2,-ham/2])
    def metric(now):
        ell,bend,face,angular=mesh.decode(now[:4])
        return np.array([ell,bend,mesh.centre(face),angular])*AMP
    fields=[metric(state)]
    elapsed=dt/subdivision
    for sub in range(64*subdivision):
        first=rhs(state);second=rhs(state+elapsed*first/2)
        third=rhs(state+elapsed*second/2);fourth=rhs(state+elapsed*third)
        state+=elapsed*(first+2*second+2*third+fourth)/6
        if (sub+1)%(16*subdivision)==0:fields.append(metric(state))
    return np.array(fields)


def curvature(grid,arr,radius,weights,average):
    first,second=legacy(arr,1/grid,weights,average)
    return scalar(radius,arr,first,second)


def budget():
    rows=[];actual=[];outputs={};measure=[]
    with system(1,1,0,0) as model:
        dt=4096*np.pi/(1024*model.shell.mu);weights=model.shell.weights;average=model.shell.average
    with np.load(HERE/"continuum-metric.npz") as exact:
        for grid in (320,640,1280):
            guard();rr=exact[f"g{grid}r"];count=len(rr);coord=rr/WIDTH
            fine=flat(grid,.375,8,dt);repeat=flat(grid,.375,16,dt)
            if grid==640:
                large=flat(grid,3.,8,dt)
                native=flat(grid,.375,1,dt)
                assert np.max(abs((large[:,:,:count]-fine[:,:,:count])/(AMP*WIDTH)))<1e-10
            for index,tick in enumerate(TICKS):
                key=f"g{grid}t{tick}"
                target=exact[key+"_exact"];reader=exact[key+"_legacy"]
                fine_h=curvature(grid,fine[index,:,:count],rr,weights,average)
                refined=curvature(grid,repeat[index,:,:count],rr,weights,average)
                masks=(("first",rr<1/grid),("inner",rr<.1))
                for reg,mask in masks:
                    den=np.linalg.norm(target[mask])
                    for name,signal in (("exact_sample_reader",reader-target),("evolution",fine_h-reader),
                                        ("total",fine_h-target),("time",fine_h-refined)):
                        rows.append(dict(grid=grid,tick=tick,region=reg,term=name,signed_first=signal[mask][0],target_first=target[mask][0],
                                         norm_relative=np.linalg.norm(signal[mask])/den if den else ""))
                differences=fine[index,:,:count]-exact[key+"_metric"]
                for slot,label in enumerate(("ell","bend","tilt","tensor")):
                    only=np.zeros_like(differences);only[slot]=differences[slot]
                    contribution=curvature(grid,only,rr,weights,average)
                    measure.append(dict(grid=grid,tick=tick,field=label,metric_error_first=differences[slot,0],
                                        curvature_error_first=contribution[0],true_curvature_first=target[0]))
                if grid==640:
                    for flag in (0,1):
                        path=HERE/f"s1-off{flag}-pulse-t{tick}.npz"
                        cert=json.loads((HERE/f"s1-off{flag}-pulse.json").read_bytes())
                        assert lab.sha(path)==cert["files"][path.name]
                        with np.load(path) as sim:
                            curved=sim["ind_H"][:count]
                            curved_metric=sim["raw"][:4,:count].real
                        same_flat=curvature(grid,curved_metric,rr,weights,average)
                        same_step=curvature(grid,native[index,:,:count],rr,weights,average)
                        for reg,mask in masks:
                            den=np.linalg.norm(target[mask])
                            for name,signal in (("reader_on_exact",reader-target),("flat_grid_evolution",fine_h-reader),
                                                ("native_flat_time",same_step-fine_h),("curved_history_field",same_flat-same_step),("curved_metric_and_matter",curved-same_flat),
                                                ("actual_total",curved-target)):
                                actual.append(dict(flag=flag,tick=tick,region=reg,term=name,signed_first=signal[mask][0],
                                                 target_first=target[mask][0],norm_relative=np.linalg.norm(signal[mask])/den if den else ""))
                outputs[key+"_flat"]=fine_h[:np.sum(rr<.1)]
    packet("flat-reader-by-grid.npz",**outputs);table("spatial-resolution.csv",rows)
    table("curved-H-budget.csv",actual);table("geometric-terms.csv",measure)

if __name__=="__main__":budget()
