"""Evaluate the angular first variation on both evolving curved monopoles."""
from pathlib import Path
import sys
from contextlib import contextmanager
from copy import copy
import csv
import io
import json
from time import perf_counter

HERE=Path(__file__).resolve().parent
PREV=HERE.parent/"mts-late-angular-clock-20261121"
sys.path.insert(0,str(PREV))
import clock_lab as lab
from clock_lab import old,patch,np,carrier,candidate,evolve8,revised,GRID,AMP,WIDTH,compute
import coupled
from late_score import entry,code
from split_curvature import principal

PIN="2386e63e4fb88d03302e1fe803934f9ff74755557d7266929207001b901cfb93"
JOBS={"pulse":(0,0),"minus":(0,0),"scaled":(0,0),"carried":(0,0),"prepared":(1,0),"surrounding":(0,1)}
TICKS=(960,976,992,1008,1024)
AMP_SCALE=2.**32


def guard():
    lab.guard()
    if (HERE/"STOP-REQUESTED").exists():raise RuntimeError("owner hold")


def put(path,content):
    guard();lab.put(HERE/path,content)


def send(name,data):
    put(name,(json.dumps(data,indent=2,allow_nan=False)+"\n").encode())


def table(name,rows):
    output=io.StringIO(newline="")
    writer=csv.DictWriter(output,rows[0].keys(),lineterminator="\n")
    writer.writeheader();writer.writerows(rows)
    put(name,output.getvalue().encode())


def packet(name,**fields):
    assert all(np.isfinite(arr).all() for arr in fields.values())
    output=io.BytesIO();np.savez_compressed(output,**fields);put(name,output.getvalue())


def checkparent():
    guard();assert lab.sha(PREV/"seal.json")==PIN
    manifest=json.loads((PREV/"seal.json").read_bytes())
    for key,digest in manifest["files"].items():assert lab.sha(PREV/key)==digest,key
    return manifest


class Bank:
    def __init__(self,original):self.original=original
    def at(self,time):
        values=self.original.at(time)
        assert len(values)==7
        return [*values[:2],*(np.zeros_like(value) for value in values[2:])]


def truncated(array):
    value=array.copy()
    value[...,1,:]=0
    return value


@contextmanager
def system(seed,flag,launch,external):
    with old.environment(GRID),patch.object(carrier,"launch",candidate),patch.object(evolve8,"revise",revised):
        original=coupled.parent.system
        def build(*args):
            shell=copy(original(*args))
            if not launch:
                shell.initial=truncated(shell.initial)
                shell.ref_geometry=tuple(tuple(truncated(value) for value in row) for row in shell.ref_geometry)
            if not external:
                shell.incident=copy(shell.incident)
                shell.incident.bank=Bank(shell.incident.bank)
            return shell
        with patch.object(coupled.parent,"system",build):
            model=(old.Cold if flag else old.Wave)(seed,"adm")
            yield model


def anchor(seed,flag,tick):
    if seed==1 or tick!=960:
        tag=code(seed,flag,768,1,0)
    else:tag=code(-1,flag,768,1,0)
    with entry(tag,tick) as ref:
        return old.Difference(ref["shared"],ref["signed"]),float(ref["clock"])


def state_for(saved,mode,radius):
    val=saved.copy()
    if mode!="carried":
        val.base[:,1]=0;val.delta[:,1]=0
    if mode in ("pulse","minus","scaled"):
        gain={"pulse":1.,"minus":-1.,"scaled":AMP_SCALE}[mode]
        val.delta[7,1]=-2*gain*AMP*(radius/WIDTH)**4*np.exp(-(radius/WIDTH)**2)
    return val


def summary(seed,flag,mode,tick,model,state,time):
    ref,_=anchor(seed,flag,tick)
    for left,right in ((ref.base,state.base),(ref.delta,state.delta)):
        assert np.array_equal(left[:,0],right[:,0]),(mode,tick,"monopole")
    if mode in ("pulse","minus","scaled"):
        assert not np.any(state.base[:,1]),(mode,tick,"shared pulse acquired a source")
    physical=lab.rawfield(model,state,time)
    vals=compute(model,state,time)
    channels={key:vals[key] for key in ("P","ind_P","H","ind_H","J","ind_J","Hdrive","stencil")}
    name=f"s{seed}-off{flag}-{mode}-t{tick}"
    packet(name+".npz",base=state.base[:,1],delta=state.delta[:,1],raw=physical.delta[:,1],
           **channels,r=model.shell.r,clock=time)
    return name


def prepare():
    checkparent()
    tests=[]
    for flag in (0,1):
        state,time=anchor(1,flag,960)
        pieces=[];physical=[];sources=[]
        for kind,(launch,external) in {"full":(1,1),"zero":(0,0),"carried":(0,0),"prepared":(1,0),"surrounding":(0,1)}.items():
            with system(1,flag,launch,external) as model:
                val=state if kind=="full" else state_for(state,kind,model.shell.r)
                rate=(model.rhs if flag else model.nonlinear)(time,val)
                raw=lab.rawfield(model,val,time)
                current=compute(model,val,time)
                if kind=="full":
                    reference=rate.copy();refraw=raw.copy();record=current
                else:
                    for aa,bb in ((rate.base,reference.base),(rate.delta,reference.delta)):
                        assert np.array_equal(aa[:,0],bb[:,0])
                    if kind=="zero":
                        assert not np.any(rate.base[:,1]) and not np.any(rate.delta[:,1])
                        assert not any(np.any(current[key]) for key in ("ind_H","ind_P","P","H","J"))
                    else:pieces.append(rate);physical.append(raw);sources.append(current)
        for view in ("base","delta"):
            for typ,parts,total in (("rhs",pieces,reference),("physical",physical,refraw)):
                original=getattr(total,view)[:,1]
                other=sum(getattr(item,view)[:,1] for item in parts)
                for slot in range(len(original)):
                    absolute=np.linalg.norm(other[slot]-original[slot])
                    norm=sum(np.linalg.norm(getattr(item,view)[slot,1]) for item in parts)
                    err=absolute/norm if norm else 0.
                    if not norm:assert absolute==0
                    tests.append(dict(flag=flag,view=view,type=typ,slot=slot,norm=norm,absolute=absolute,relative=err))
        for key in ("P","ind_P","J","ind_J","H","ind_H"):
            total=sum(item[key] for item in sources);num=np.linalg.norm(total-record[key]);den=sum(np.linalg.norm(item[key]) for item in sources)
            tests.append(dict(flag=flag,view="signed",type="readout",slot=key,norm=den,absolute=num,relative=num/den if den else 0.))
    table("launch-affine-check.csv",tests)
    print("affine",[(row["flag"],row["type"],row["slot"],row["relative"]) for row in sorted(tests,key=lambda row:-row["relative"])[:5]])
    send("contract.json",dict(parent=PIN,source=lab.sha(Path(__file__)),grid=GRID,ticks=TICKS,amplitude=AMP,width=WIDTH,
         design="Same two curved monopoles at every RK stage. Zero-angular input must stay zero. For the free pulse the surrounding angular variation is zero, not its monopole. Reconstruct the no-pulse run as carried state + fixed angular preparation + actual external angular drive. Measure aggregate apertures with full physical observer and original 20 ppm band; do not add proper rulers separately. Compare both pulse signs individually and mark failures."))


def run(seed,flag,mode):
    guard();cert=json.loads((HERE/"contract.json").read_bytes())
    assert cert["source"]==lab.sha(Path(__file__)) and cert["parent"]==lab.sha(PREV/"seal.json")==PIN
    saved,time=anchor(seed,flag,960)
    with system(seed,flag,*JOBS[mode]) as model:
        dt=4096*np.pi/(1024*model.shell.mu);assert time==960*dt
        advance=model.time_step(dt);state=state_for(saved,mode,model.shell.r)
        files={};start=perf_counter()
        for tick in range(960,1025):
            if tick%8==0:guard()
            if tick>960:state=advance((tick-1)*dt,state)
            if tick in TICKS:
                name=summary(seed,flag,mode,tick,model,state,tick*dt)
                files[name+".npz"]=lab.sha(HERE/(name+".npz"))
        send(f"s{seed}-off{flag}-{mode}.json",dict(contract=lab.sha(HERE/"contract.json"),files=files,monopoles_bitwise=True))
        print(seed,flag,mode,round(perf_counter()-start,1),flush=True)


if __name__=="__main__":
    if sys.argv[1:]==["prepare"]:prepare()
    else:run(int(sys.argv[1]),int(sys.argv[2]),sys.argv[3])
