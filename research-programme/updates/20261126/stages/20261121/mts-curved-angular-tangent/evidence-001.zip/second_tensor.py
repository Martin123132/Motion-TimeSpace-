"""Independent nonzero-centre Cartesian K pulse; predict before evolving."""
from curved_tangent import *
from order_probe import symbol
from weighted_transfer import weighted
from independent_geometry import derivatives,interpolation,full_pulse_check,measurement,host
from continuum_metric import kernels,fourier,scalar,integrals
from contextlib import nullcontext


def freeze_second():
    checkparent()
    with system(1,1,0,0) as model:weights=model.shell.weights;avg=model.shell.average;dt=4096*np.pi/(1024*model.shell.mu)
    r=(np.arange(82)+.5)/GRID
    bank=kernels(96,64,"constant-tensor");rows=[];out={"r":r}
    for order in (12,20):
        fields=symbol(640,order,"weighted",dt,1,"constant-tensor")
        for idx,tick in enumerate(TICKS):
            elapsed=(tick-960)*dt
            metric,speed=fourier(r,elapsed,bank)
            if tick==960:
                profile=np.exp(-(r/WIDTH)**2)
                assert np.max(abs(speed-np.array([-profile,profile/2,-profile,-profile])))<1e-12
            exact=integrals(r,elapsed,128)[1]*AMP/3
            own=scalar(r/WIDTH,*metric)*AMP/WIDTH
            assert abs(own[0]-exact[0])<1e-7*abs(exact[0])+1e-46
            assert np.linalg.norm(own-exact)<1e-8*np.linalg.norm(exact)+1e-46
            for reader,coeff in (("old",(weights,avg)),("alternate",interpolation(6))):
                preds=[]
                for data in (metric[0]*AMP*WIDTH,fields[idx,:,:len(r)]):
                    first,second=derivatives(data,1/GRID,*coeff)
                    preds.append(scalar(r,data,first,second))
                key=f"o{order}t{tick}{reader}"
                out[key]=preds[1]
                out[key+"_exact"]=exact;out[key+"_sampled"]=preds[0]
                rows.append(dict(order=order,tick=tick,reader=reader,exact=exact[0],sampled=preds[0][0],flat_grid=preds[1][0]))
    table("second-forecast.csv",rows);packet("second-forecast.npz",**out)
    names=["second_tensor.py","independent_geometry.py","continuum_metric.py","order_probe.py","second-forecast.npz","second-forecast.csv","weighted-freeze.json"]
    send("second-freeze.json",dict(files={name:lab.sha(HERE/name) for name in names},
         prediction="K_cov/e^(2b)=A exp(-(r/w)^2) Q everywhere including the centre. Continuum flat H equals one third of the first pulse, not its entire metric response. Flat discrete forecasts frozen separately for each reader and evolution order. Neither force coupling, width, amplitude nor readout adjusted after this test."))


def initial(model,state,time):
    r=model.shell.r;mesh=model.lift.mesh
    zero=lambda val:old.Difference(np.zeros_like(val),val)
    for item in (state.base,state.delta):item[:,1]=0
    mapped,_=model.mass.decode(state);_,geo,bg,_=model.lift.physical(mapped,time)
    field=zero(AMP*np.exp(-(r/WIDTH)**2))
    vf=zero(-AMP*np.exp(-(mesh.faces/WIDTH)**2))
    trace=field*np.expm1(2*(bg["bend"]-bg["ell"]));shear=field+2*trace/3
    dl=-field-trace;db=field/2
    chart=mesh.encode(dl,db,vf,-field)
    corr1=2*mesh.faces*mesh.odd_face(bg["bg"]*1.5*shear)
    metric,other=model.lift.ang_coeff(bg)
    corr2=-(r*metric*mesh.even_back(vf)+other*mesh.centre(vf))/2
    state[4,1]=trace;state[5,1]=shear;state[6,1]=chart[2]+corr1[1:];state[7,1]=chart[3]+corr2
    if not model.shell.flag:state[15,1]=-trace/(2*model.shell.mu)
    phys=lab.rawfield(model,state,time)
    expect=[trace.delta,shear.delta,host(bg["scale"])*field.delta/2,field.delta/2]
    for idx,want in enumerate(expect,4):
        assert np.max(abs(phys.delta[idx,1].real-want))<1e-7*AMP,(idx,np.max(abs(phys.delta[idx,1].real-want))/AMP)
    assert not np.any(phys.delta[:4,1]) and not np.any(phys.base[:,1])
    for idx in range(8,20):
        if idx==15 and not model.shell.flag:assert not np.any(phys.delta[idx,1]+trace.delta/(2*model.shell.mu))
        else:assert not np.any(phys.delta[idx,1])
    return state


def run(flag,order):
    freeze=json.loads((HERE/"second-freeze.json").read_bytes());assert all(lab.sha(HERE/name)==val for name,val in freeze["files"].items())
    rows=[];data={}
    with system(1,flag,0,0) as model,(weighted(model) if order==20 else nullcontext()):
        state,time=anchor(1,flag,960);state=initial(model,state,time)
        dt=4096*np.pi/(1024*model.shell.mu);advance=model.time_step(dt)
        with np.load(HERE/"second-forecast.npz") as bank:
            n=int(np.sum(bank["r"]<.1))
            for tick in range(960,1025):
                if tick%8==0:guard()
                if tick>960:state=advance((tick-1)*dt,state)
                if tick not in TICKS:continue
                orig,_=anchor(1,flag,tick)
                assert np.isfinite(state.delta).all() and np.array_equal(state.base[:,0],orig.base[:,0])
                assert np.array_equal(state.delta[:,0],orig.delta[:,0]) and not np.any(state.base[:,1])
                vals=compute(model,state,tick*dt)
                curves=[vals["ind_H"],vals["ind_H"]+measurement(model,state,tick*dt)]
                direct=full_pulse_check(model,state,tick*dt)
                for name,curve,verify in zip(("old","alternate"),curves,direct):
                    assert np.linalg.norm((curve-verify)[:n])<1e-8*np.linalg.norm(curve[:n])+1e-43
                    key=f"o{order}t{tick}{name}"
                    for region,mask in (("first",bank["r"][:n]<1/GRID),("inner",bank["r"][:n]<.1)):
                        observe=curve[:n][mask];flat=bank[key][:n][mask];truth=bank[key+"_exact"][:n][mask];size=np.linalg.norm(truth)
                        rows.append(dict(flag=flag,order=order,tick=tick,reader=name,region=region,measured=observe[0],
                                    predicted=flat[0],continuum=truth[0],error=np.linalg.norm(observe-truth)/size if size else "",
                                    forecast_error=np.linalg.norm(observe-flat)/size if size else ""))
                    data[f"t{tick}{name}"]=curve
                data[f"t{tick}signed"]=state.delta[:,1]
                data[f"t{tick}J"]=vals["J"];data[f"t{tick}ind_P"]=vals["ind_P"]
    tag=f"second-o{order}-off{flag}";table(tag+".csv",rows);packet(tag+".npz",**data)
    send(tag+".json",dict(freeze=lab.sha(HERE/"second-freeze.json"),files={name:lab.sha(HERE/name) for name in (tag+".csv",tag+".npz")}))

if __name__=="__main__":
    if sys.argv[1:]==["freeze"]:freeze_second()
    else:run(*map(int,sys.argv[1:]))
