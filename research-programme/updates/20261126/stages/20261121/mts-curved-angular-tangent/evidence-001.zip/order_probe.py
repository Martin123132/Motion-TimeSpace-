"""Test weighted angular flux order and the rest of the discretization separately."""
from curved_tangent import *
from mts_sbp12 import Regular,interpolation
from continuum_metric import legacy
from spatial_budget import curvature
from scipy.linalg import eigvalsh
from fractions import Fraction
from math import prod


def mesh_at(grid,order,edge):
    first,mean=interpolation(order//2)
    class AngularMesh(Regular):
        pass
    AngularMesh.first=first;AngularMesh.mean=mean
    return AngularMesh(int(grid*edge),edge)


def spectral(mesh,dt):
    size=48
    grad=np.stack([mesh.grad(np.pad(row/mesh.r[:size]**3,(0,len(mesh.r)-size))) for row in np.eye(size)],axis=1)
    gram=mesh.faces[:,None]**3*grad
    omega=np.sqrt(eigvalsh(gram.T@gram)[-1]);return float(omega*dt)


def first_flux(order,power):
    knots=[Fraction(2*idx+1,2) for idx in range(order//2)]
    coeff=[prod(other**2/(other**2-dist**2) for other in knots if other!=dist)/(2*dist) for dist in knots]
    def flux(face):return face**6*sum(c*((face+x)**power-(face-x)**power) for c,x in zip(coeff,knots))
    return 64*sum(c*(flux(1+idx)-flux(-idx)) for idx,c in enumerate(coeff))


def symbol(grid,order,select,dt,subdivision=4,profile="tangential"):
    hi=mesh_at(grid,order,.375);lo=mesh_at(grid,12,.375)
    mesh=hi if select in ("all","rest") else lo
    shear=hi if select in ("all","weighted") else lo
    r=mesh.r;faces=mesh.faces;radius=(np.arange(len(r))+.5)/grid
    state=np.zeros((8,len(r)))
    if profile=="tangential":
        state[7]=-2*(radius/WIDTH)**4*np.exp(-(radius/WIDTH)**2)
    elif profile=="constant-tensor":
        height=np.exp(-(radius/WIDTH)**2);vf=-np.exp(-(faces/WIDTH)**2)
        encoded=mesh.encode(-height,height/2,vf,-height)
        state[5]=height;state[6]=encoded[2];state[7]=encoded[3]
    else:raise ValueError(profile)
    def rhs(now):
        ell,trace,mass,beta,extr,sigma,pi,tau=now
        section=mesh.back(faces*mesh.full(mass))
        ham=-2*(section-6*beta)/mesh.mass2
        rad=shear.lap(ell,6)+(2*section-mesh.back(mesh.grad(r**2*trace)))/mesh.mass2
        return np.array([-extr/3-sigma,-extr,pi,tau,ham,-rad-ham/3,-(faces*mesh.grad(ham))[1:]/2,-ham/2])
    def output():
        ell,bend,face,tensor=mesh.decode(state[:4])
        return AMP*np.array([ell,bend,mesh.centre(face),tensor])
    fields=[output()]
    step=dt/subdivision
    for sub in range(64*subdivision):
        a=rhs(state);b=rhs(state+step*a/2);c=rhs(state+step*b/2);d=rhs(state+step*c)
        state+=step*(a+2*b+2*c+d)/6
        if (sub+1)%(16*subdivision)==0:fields.append(output())
    return np.array(fields)


def test():
    with system(1,0,0,0) as model:
        dt=4096*np.pi/(1024*model.shell.mu);weights=model.shell.weights;avg=model.shell.average
    rows=[];monomials=[]
    with np.load(HERE/"continuum-metric.npz") as exact:
        for grid in (320,640):
            rr=exact[f"g{grid}r"];size=len(rr)
            for order in (12,16,20):
                mesh=mesh_at(grid,order,.375)
                phase=spectral(mesh,dt)
                for power in (4,6,8,10,12,14,16):
                    idx=0
                    stiff=mesh.lap((mesh.r/mesh.h)**power,6)[idx]*mesh.h**2
                    target=power*(power+5)*(mesh.r[idx]/mesh.h)**(power-2)
                    rational=first_flux(order,power)
                    analytical=power*(power+5)*Fraction(1,2)**(power-2)
                    assert (rational==analytical)==(power+5<=order)
                    monomials.append(dict(grid=grid,order=order,power=power,numerical=float(stiff),analytic=float(target),
                                          exact_stencil=float(rational),exact_polynomial=(rational==analytical),
                                          absolute=abs(stiff-target),phase=phase))
                for selection in (("all",) if order==12 else ("weighted","rest","all")):
                    fields=symbol(grid,order,selection,dt,4)
                    for index,tick in enumerate(TICKS[1:],start=1):
                        key=f"g{grid}t{tick}";true=exact[key+"_exact"];nominal=exact[key+"_legacy"]
                        predicted=curvature(grid,fields[index,:,:size],rr,weights,avg)
                        for label,mask in (("first",rr<1/grid),("inner",rr<.1)):
                            scale=np.linalg.norm(true[mask])
                            rows.append(dict(grid=grid,order=order,change=selection,region=label,tick=tick,
                                          target=true[mask][0],computed=predicted[mask][0],sampled=nominal[mask][0],
                                          error_total=np.linalg.norm((predicted-true)[mask])/scale,
                                          evolution_error=np.linalg.norm((predicted-nominal)[mask])/scale,
                                          weighted_phase=phase,stable_at_native_for_weighted_mode=(phase<np.sqrt(8))))
    table("weighted-order-trials.csv",rows);table("monomial-flux.csv",monomials)

if __name__=="__main__":test()
