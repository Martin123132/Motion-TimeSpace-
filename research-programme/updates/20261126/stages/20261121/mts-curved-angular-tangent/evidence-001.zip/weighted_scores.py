from independent_geometry import *
from coupling_scores import readout,mixed,angular,geometric
import operator


def test():
    paired=[];responses=[];tides=[];weak=[];centres=[]
    with np.load(HERE/"weighted-forecast.npz") as forecast:
        for flag in (0,1):
            for tick in TICKS:
                withhold=forecast[f"f{flag}t{tick}"]
                def get(mode):
                    return stored(1,flag,tick,mode,True)[2]
                zero=get("control");p=get("pulse");m=get("minus");high=get("add");low=get("subtract")
                radius=zero["r"];num=len(withhold)
                for label,mask in (("first",radius[:num]<1/GRID),("inner",radius[:num]<.1)):
                    observed=p["ind_H"][:num][mask];pred=withhold[mask];norm=np.linalg.norm(pred)
                    responses.append(dict(flag=flag,tick=tick,region=label,observed=observed[0],forecast=pred[0],
                          norm_difference=np.linalg.norm(observed-pred),relative=np.linalg.norm(observed-pred)/norm if norm else ""))
                for key in ("ind_H","H","ind_P","P","ind_J","J"):
                    assert np.linalg.norm(p[key]+m[key])<1e-8*np.linalg.norm(p[key])+1e-50
                    for tag,actual,pred in (("plus",high[key]-zero[key],p[key]),("minus",low[key]-zero[key],m[key]),
                                            ("odd",(high[key]-low[key])/2,p[key])):
                        for reg,mask in (("first",radius<1/GRID),("inner",radius<.1)):
                            size=np.linalg.norm(pred[mask]);err=np.linalg.norm((actual-pred)[mask])
                            paired.append(dict(flag=flag,tick=tick,field=key,branch=tag,region=reg,measured=actual[mask][0],
                                    predicted=pred[mask][0],error_over_tangent=err/size if size else "",norm_difference=err))
    predictions={(int(row["seed"]),float(row["width"])):row for row in lab.parent.core.read(lab.PREV/"matched-gravity-prediction.csv") if float(row["fraction"])==1}
    oldbands={(int(row["seed"]),float(row["width"]),row["channel"]):row for row in lab.parent.core.read(PREV/"proper-tides.csv") if row["start"]=="768" and row["div"]=="1"}
    for seed in (1,-1):
        totals={}
        for flag in (0,1):
            with system(seed,flag,1,1) as model:
                values=lab.parent.core.read(HERE/f"w20-s{seed}-off{flag}-tides.csv")
                for row in values:
                    if int(row["tick"])==1024:totals[flag,float(row["width"]),row["channel"]]=float(row["tide"])
                for tick in (960,1024):
                    state,time,snap=stored(seed,flag,tick,"control",True)
                    orig,_=anchor(seed,flag,tick)
                    with entry(code(seed,flag,768,1,0),tick) as baseline:
                        for name,st,val in (("original",orig,baseline),("weighted",state,snap)):
                            radius=val["r"];size=radius**2
                            change=measurement(model,st,time)
                            for reg,mask in (("first",radius<1/GRID),("core",radius<.3),("bulk",(radius>.6)&(radius<2.1))):
                                for field,actual in (("ind_H",val["ind_H"]),("alternate_H",val["ind_H"]+change),("ind_P",val["ind_P"]),("P",val["P"])):
                                    centres.append(dict(seed=seed,flag=flag,tick=tick,method=name,region=reg,field=field,
                                          signed_first=actual[mask][0],norm=np.linalg.norm(actual[mask]),material_J_norm=np.linalg.norm(val["J"][mask])))
                            mapped,aux=model.mass.decode(st);_,_,bg,_=model.lift.physical(mapped,time)
                            h,p=geometric(model,mapped,aux,time)
                            mass=np.expm1(2*(bg["ell"]-bg["bend"]))/size;dk=(aux["kb"]-aux["ka"])/size
                            mix=mixed(h,p,size,mass,-aux["kb"],dk)
                            cov=angular(h,mix,size,mass,(bg["eg"]-bg["bg"])/radius,bg["bg"]/(2*radius),dk,0.,0.)
                            coefficients=[mix[0].delta,mix[1].delta,cov.delta,val["J"],val["ind_P"]]
                            for edge in (.025,.3):
                                for order in (0,8,16):
                                    error=readout(radius,coefficients,edge,True,order)
                                    weak.append(dict(seed=seed,flag=flag,tick=tick,method=name,edge=edge,order=order,**error))
        for width in (.15,.3):
            ref=predictions[seed,width];scale=abs(float(ref["matched_newton"]))*1e-6
            for key in ("ricci","gauss"):
                val=totals[0,width,key]-totals[1,width,key];pred=float(ref["matched"])
                ppm=(val-pred)/scale
                tides.append(dict(seed=seed,width=width,channel=key,measured=val,reference=pred,ppm=ppm,inside=abs(ppm)<=20,
                              weighted_minus_previous_ppm=ppm-float(oldbands[seed,width,key]["ppm"])))
    table("weighted-live-forecast-scores.csv",responses);table("weighted-live-signed-pulses.csv",paired)
    table("weighted-proper-bands.csv",tides);table("weighted-weak-momentum.csv",weak);table("weighted-raw-centre.csv",centres)

if __name__=="__main__":test()
