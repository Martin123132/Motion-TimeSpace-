"""Change only the curvature measurement's angular first and second derivatives."""
from curved_tangent import *
from mts_sbp12 import interpolation
from continuum_metric import legacy,scalar
from weighted_transfer import weighted
from trial import sources
from endpoints import D
from decimal import localcontext


def derivatives(values,dx,weights,average):
    half=len(weights)
    cells=values.shape[-1]
    padded=np.concatenate((values[...,:half][...,::-1],values,values[...,-half:][...,::-1]),axis=-1)
    face=sum(w*(padded[...,half+idx:half+idx+cells+1]-padded[...,half-1-idx:half-1-idx+cells+1]) for idx,w in enumerate(weights))/dx
    ext=np.concatenate((-face[...,half-1:0:-1],face,-face[...,-2:-half-1:-1]),axis=-1)
    first=sum(w*(ext[...,half+idx:half+idx+cells]+ext[...,half-1-idx:half-1-idx+cells]) for idx,w in enumerate(average))
    second=sum(w*(ext[...,half+idx:half+idx+cells]-ext[...,half-1-idx:half-1-idx+cells]) for idx,w in enumerate(weights))/dx
    return first,second


def host(array):return array.base+array.delta


def measurement(model,state,time):
    raw=lab.rawfield(model,state,time)
    shell=model.shell
    weights,aver=shell.weights,shell.average
    high,hiavg=interpolation(6)
    r=shell.r
    mapped,aux=model.mass.decode(state)
    _,geo,bg,_=model.lift.physical(mapped,time)
    a=bg["ne"];bgprime=bg["bg"];egprime=bg["eg"]
    def delta(array):
        def one(values):
            old=derivatives(values,shell.dx,weights,aver)
            new=derivatives(values,shell.dx,high,hiavg)
            return [new[idx]-old[idx] for idx in (0,1)]
        shared=one(array.base);signed=one(array.delta)
        return [old.Difference(x,y) for x,y in zip(shared,signed)]
    dell,_=delta(raw[0,1].real);db,dbb=delta(raw[1,1].real);dv,_=delta(raw[2,1].real)
    change=a*(-4*dbb+(4*egprime-12*bgprime-12/r)*db+4*(bgprime+1/r)*dell-12*dv/r)
    return change.delta


def full_pulse_check(model,state,time):
    raw=lab.rawfield(model,state,time)
    assert not np.any(raw.base[:,1]) and not np.any(model.host.initial[:,1])
    shell=model.shell;r=shell.r
    mapped,_=model.mass.decode(state)
    _,_,bg,_=model.lift.physical(mapped,time)
    a=np.exp(-2*host(bg["ell"]));e=np.exp(-2*host(bg["bend"]))
    bp=host(bg["bg"]);ep=host(bg["eg"]);dx=shell.dx
    bpp=host(model.reference[1][2][0])+legacy(host(raw[1,0].real),dx,shell.weights,shell.average)[1]
    ell,bend,tilt,tensor,ktr,shear=raw.delta[:6,1].real
    for value in (ell,bend,tilt,tensor,ktr,shear):assert np.isfinite(value).all()
    energy=sources(model,time,raw)[0].delta[1].real
    trace0=model.host.initial[4,0].real+host(raw[4,0].real)
    shear0=model.host.initial[5,0].real+host(raw[5,0].real)
    result=[]
    for weights,average in ((shell.weights,shell.average),interpolation(6)):
        deriv,second=derivatives(np.array([ell,bend,tilt]),dx,weights,average)
        dl,db,dv=deriv
        three=a*(-4*second[1]+(4*ep-12*bp-12/r)*db+4*(bp+1/r)*dl-12*dv/r)
        three+=(a*(4*ell-24*tilt)+e*(8*bend+12*tensor+12*ell))/r**2+12*a*(ep-3*bp)*tilt/r
        three+=ell*a*(12*(bp**2+2*bp/r)+4*(2*bpp-2*ep*bp-2*ep/r))
        result.append(three+(4/3)*trace0*ktr-3*shear0*shear-2*energy)
    return result


def stored(seed,flag,tick,mode,weighted_run):
    name=(f"w20-" if weighted_run else "")+f"s{seed}-off{flag}-{mode}"
    path=HERE/f"{name}-t{tick}.npz"
    cert=json.loads((HERE/f"{name}.json").read_bytes())
    assert lab.sha(path)==cert["files"][path.name]
    with np.load(path) as bank:values={key:bank[key] for key in bank.files}
    state,time=anchor(seed,flag,tick)
    state.base[:,1]=values["base"];state.delta[:,1]=values["delta"]
    return state,time,values


def report():
    rows=[]
    with np.load(HERE/"continuum-metric.npz") as bank:
        for flag in (0,1):
            with system(1,flag,0,0) as model:
                for tick in TICKS:
                    n=int(np.sum(model.shell.r<.1))
                    exact=bank[f"g640t{tick}_exact"][:n]
                    for changed in (False,True):
                        state,time,snap=stored(1,flag,tick,"pulse",changed)
                        old_measure=snap["ind_H"];correction=measurement(model,state,time)
                        independent=full_pulse_check(model,state,time)
                        for actual,cross in ((old_measure,independent[0]),(old_measure+correction,independent[1])):
                            scale=np.linalg.norm(actual[:n])
                            assert np.linalg.norm((actual-cross)[:n])<1e-8*scale+1e-45,(flag,tick,changed,scale)
                        for name,pred in (("old",old_measure),("alternate",old_measure+correction)):
                            for region,mask in (("first",model.shell.r[:n]<1/GRID),("inner",model.shell.r[:n]<.1)):
                                den=np.linalg.norm(exact[mask]);err=np.linalg.norm((pred[:n]-exact)[mask])
                                rows.append(dict(flag=flag,tick=tick,weighted=int(changed),reader=name,region=region,
                                       value=pred[:n][mask][0],continuum=exact[mask][0],relative=err/den if den else "",absolute=err))
    table("crossed-curvature-readers.csv",rows)

if __name__=="__main__":report()
