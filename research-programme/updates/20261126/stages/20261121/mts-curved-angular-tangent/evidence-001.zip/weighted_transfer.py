"""Prospective fixed-grid curved test: upgrade only the weighted r^6 shear flux."""
from curved_tangent import *
from order_probe import mesh_at,symbol,spectral
from spatial_budget import curvature
import split_curvature


def freeze():
    checkparent()
    with system(1,1,0,0) as model:
        dt=4096*np.pi/(1024*model.shell.mu);weights=model.shell.weights;avg=model.shell.average
    assert spectral(mesh_at(GRID,20,.375),dt)<np.sqrt(8)
    times={order:symbol(GRID,order,"weighted",dt,1) for order in (12,20)}
    with np.load(HERE/"continuum-metric.npz") as exact:
        r=exact["g640r"];n=len(r);mask=r<.1;rows=[];data={}
        for idx,tick in enumerate(TICKS):
            reads={order:curvature(GRID,field[idx,:,:n],r,weights,avg)[mask] for order,field in times.items()}
            for flag in (0,1):
                name=f"s1-off{flag}-pulse-t{tick}.npz"
                cert=json.loads((HERE/f"s1-off{flag}-pulse.json").read_bytes())
                assert lab.sha(HERE/name)==cert["files"][name]
                with np.load(HERE/name) as oldwave:oldH=oldwave["ind_H"][:sum(mask)]
                value=oldH+(reads[20]-reads[12])
                key=f"f{flag}t{tick}"
                data[key]=value
                rows.append(dict(flag=flag,tick=tick,old=oldH[0],predicted=value[0],flat_20=reads[20][0],
                        continuum=exact[f"g640t{tick}_exact"][0],sampled=exact[f"g640t{tick}_legacy"][0]))
    packet("weighted-forecast.npz",**data);table("weighted-forecast.csv",rows)
    inputs=["weighted_transfer.py","weighted-order-trials.csv","continuum-metric.npz","weighted-forecast.npz","weighted-forecast.csv","contract.json"]
    send("weighted-freeze.json",dict(files={name:lab.sha(HERE/name) for name in inputs},
        method="20th order in D_b(r^6 D_f L)/r^6 only. Original sector coupling, separate low flux and original independent reader and source retained. Full unforced both host signs; independent tangents and actual signed added pulses on the positive host. Only last 64 ticks changed.",
        decision="Score against direct continuum and its samples; predict new curved independent H from the frozen old curved value plus the flat same-clock difference, no fit. Keep the original 20 ppm wave-minus-cold tide gate. Do not suppress an adverse first cell or infer accuracy of an earlier trajectory."))


@contextmanager
def weighted(model):
    mesh=model.lift.mesh
    better=mesh_at(GRID,20,3.)
    np.testing.assert_array_equal(mesh.r,better.r)
    def principal_only(lift,chart):
        ell,trace,mass,beta=chart
        section=mesh.back(mesh.faces*mesh.full(mass))
        scalar=-2*(section-6*beta)/mesh.mass2
        radial=better.lap(ell,6)+(2*section-mesh.back(mesh.grad(mesh.r**2*trace)))/mesh.mass2
        return scalar,radial
    with patch.object(split_curvature,"principal",principal_only):yield


def run(seed,flag,mode):
    assert mode in ("pulse","minus","control","add","subtract") and(seed==1 or mode=="control")
    meta=json.loads((HERE/"weighted-freeze.json").read_bytes())
    assert all(lab.sha(HERE/name)==value for name,value in meta["files"].items())
    tangent=mode in ("pulse","minus")
    with system(seed,flag,int(not tangent),int(not tangent)) as model,weighted(model):
        state,time=anchor(seed,flag,960)
        if tangent:state=state_for(state,mode,model.shell.r)
        elif mode!="control":
            label="pulse" if mode=="add" else "minus"
            signal=state_for(state,label,model.shell.r)
            state.delta[:,1]+=signal.delta[:,1]
        dt=4096*np.pi/(1024*model.shell.mu);assert time==960*dt
        advance=model.time_step(dt);files={};observer=[];start=perf_counter()
        for tick in range(960,1025):
            if tick%8==0:guard()
            if tick>960:state=advance((tick-1)*dt,state)
            if tick not in TICKS:continue
            ref,_=anchor(seed,flag,tick)
            assert np.array_equal(state.base[:,0],ref.base[:,0]) and np.array_equal(state.delta[:,0],ref.delta[:,0])
            raw=lab.rawfield(model,state,tick*dt);read=compute(model,state,tick*dt)
            path=f"w20-s{seed}-off{flag}-{mode}-t{tick}.npz"
            packet(path,base=state.base[:,1],delta=state.delta[:,1],physical=raw.delta[:,1],r=model.shell.r,clock=tick*dt,
                   **{key:read[key] for key in ("P","ind_P","H","ind_H","J","ind_J")})
            files[path]=lab.sha(HERE/path)
            if mode=="control":
                tides=lab.read_tide(model,tick*dt,raw)
                observer.extend(dict(tick=tick,width=width,channel=channel,tide=value) for (width,channel),value in tides.items())
        if observer:table(f"w20-s{seed}-off{flag}-tides.csv",observer)
        send(f"w20-s{seed}-off{flag}-{mode}.json",dict(freeze=lab.sha(HERE/"weighted-freeze.json"),files=files))
        print(seed,flag,mode,round(perf_counter()-start,1),flush=True)

if __name__=="__main__":
    if sys.argv[1:]==["freeze"]:freeze()
    else:run(int(sys.argv[1]),int(sys.argv[2]),sys.argv[3])
