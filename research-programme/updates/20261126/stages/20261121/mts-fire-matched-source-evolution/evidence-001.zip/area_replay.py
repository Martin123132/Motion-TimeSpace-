"""Check surface matching on the retained fields by solving for area before taking differences."""
from crossed_metric import Experiment, np, prior, jf, DEGREES, OBSERVER_R, LIGHT, guard, ROOT, table, host_grid, wave_grid
from scipy.interpolate import CubicHermiteSpline
from scipy.optimize import brentq
from scipy.special import roots_legendre, eval_legendre

def replay():
    guard()
    box = Experiment(0, 1)
    with np.load(prior('frozen-weights.npz')) as saved:
        tag = saved['fine'].reshape(-1, 256)
        raw = saved['launch'].reshape(tag.shape)
        last = np.flatnonzero((raw * tag).sum(axis=1) > 0)[-1] + 1
        mass = (raw * (1 - tag))[:last]
    angle, weights = roots_legendre(96)
    harmonics = eval_legendre(DEGREES[:, None], angle)
    weights = weights / 2
    rows = []
    for mode in ('volume', 'radius'):
        shell_results = []
        for radius in OBSERVER_R:
            radii = radius * (1 + np.linspace(-.03, .03, 121))
            host, dhost, _ = host_grid(mass, jf.EDGES[:last+1], radii, mode, 8)
            wave, dwave, _ = wave_grid(box, radii)
            functions = [CubicHermiteSpline(radii, value, derivative, axis=0) for value, derivative in ((host, dhost), (wave, dwave))]
            normalizers = np.array([np.max(abs(function(radius) @ harmonics)) for function in functions])
            assert (normalizers > 0).all()
            def one_clock(first, second):
                def potential(point):
                    return (first * functions[0](point) / normalizers[0] + second * functions[1](point) / normalizers[1]) @ harmonics
                def area_condition(point):
                    return (point/radius)**2 * (weights @ np.exp(-2*potential(point))) - 1
                root = brentq(area_condition, radii[0], radii[-1], xtol=1.e-14)
                field = potential(root)
                area_weights = weights * np.exp(-2*field)
                return (area_weights @ field) / area_weights.sum()
            estimates = {}
            for amplitude in (.004, .002, .001, .0005):
                estimates[amplitude] = sum(first * second * one_clock(first*amplitude, second*amplitude)
                    for first in (-1, 1) for second in (-1, 1)) * normalizers.prod() / (4*amplitude**2 * LIGHT**4)
            shell_results.append(estimates)
        for amplitude, inner in shell_results[0].items():
            rows.append(dict(model=mode, amplitude=amplitude, mixed_geometry=shell_results[1][amplitude]-inner))
    table(ROOT/'area-replay-retained.csv', rows, True)

if __name__ == '__main__':
    replay()
