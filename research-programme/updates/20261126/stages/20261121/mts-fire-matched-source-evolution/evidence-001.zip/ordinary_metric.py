"""Densitized kinetic energy and monopole anisotropic stress, using the same mass as source and inertia."""
from matched_io import *
from scipy.constants import parsec,Julian_year
UNITS=(parsec/(1.e6*Julian_year))**2
def sum_force(r,vr,vt,mass,probes,mix):
    factor=-jf.ls.G/LIGHT**2*1000/parsec*UNITS
    shell=(r>probes[0])&(r<probes[-1]);near=(r[:,None]<probes)
    speed=vr**2+vt**2;anis=vr**2-vt**2/2
    normal=(speed[shell]*mass[shell])@(near[shell]@(mix/probes**2))*.5*factor
    slip=(anis[shell]*mass[shell]/r[shell]**3)@(near[shell]@(mix*probes))*2*factor
    direct=np.array([np.sum((mass*speed)[r<p])/(2*p**2) for p in probes])@mix*factor
    alternative=np.array([-2*p*np.sum((mass[r>p]*anis[r>p])/r[r>p]**3) for p in probes])@mix*factor
    return np.array([normal,slip,normal-slip,direct-normal,alternative-slip])
def output(rows,arm,source,material,kind,mode,vals):
    normal,slip,time,diff,alt=vals
    rows.append(dict(arm=arm,source=source,material=material,phase=kind,layout=mode,spatial_force=normal,
        slip_force=slip,time_force=time,alt_normal_residual=diff,alt_slip_residual=alt))
def run():
    rows=[];controls=[]
    for spread in (0,2):
        box=Experiment(spread,1);lab=box.lab;probes=lab.mesh.knots*lab.obj.bg.length;mix=lab.mesh.weights
        assert np.allclose(probes[[0,-1]],OBSERVER_R) and abs(mix@(1/probes**2))<1e-13 and abs(mix@probes)<1e-12
        for arm,state in lab.initial.items():
            acc=conjugate_acc(lab,box.r,box.mu,box.wm(state))
            for source in ('raw','represented'):
                mass=box.mass[source];i,j=np.nonzero(mass)
                for mat,part in (('active',mass),('passive_tag',box.mass['represented']),('active_stars',box.mass['stars' if source=='raw' else 'tagstars'])):
                    val=sum_force(box.r[i],.24*acc[0][i,j],.24*acc[1][i,j],part[i,j],probes,mix)
                    output(rows,arm,source,mat,'launch_prediction_at_024',spread,val)
                if spread:continue
                key=label(0,1,16,arm,source)
                with np.load(ROOT/f'parcels-{key}.npz') as f:
                    assert np.array_equal(f['index_i'],i) and np.array_equal(f['index_j'],j)
                    x=f['x0']+f['dx'];z=f['z0']+f['dz'];vx=f['vx'];vz=f['vz']
                    m=f['mass'];tag=f['readout']
                radius=np.hypot(x,z);vr=(vx*x+vz*z)/radius;vt=(vx*z-vz*x)/radius
                for mat,part in (('active',m),('passive_tag',tag),('active_stars',box.mass['stars' if source=='raw' else 'tagstars'][i,j])):
                    output(rows,arm,source,mat,'measured_at_024',spread,sum_force(radius,vr,vt,part,probes,mix))
                controls.append(dict(arm=arm,source=source,kinetic_energy_direct=.5*UNITS*(m@(vx*vx+vz*vz)),
                    kinetic_energy_hamiltonian=float(records(ROOT/f'run-{key}.csv')[-1]['kinetic']),
                    crossings=int(np.sum((box.r[i,None]<probes)!=(radius[:,None]<probes)))))
    table(ROOT/'ordinary-kinetic-metric.csv',rows,True);table(ROOT/'ordinary-kinetic-controls.csv',controls,True)
if __name__=='__main__':guard();run()
