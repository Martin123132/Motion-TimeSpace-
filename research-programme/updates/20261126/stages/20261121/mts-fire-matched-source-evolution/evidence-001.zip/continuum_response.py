"""The host-dependent wave clock acceleration follows from continuity and momentum, not from fitting an endpoint."""
from crossed_metric import *
from mts_radial_inputs import shape
from scipy.constants import Julian_year,parsec

def evaluate(box,edges,mass,mode,q,angular):
    lab=box.lab;el=lab.run.el;L=box.bg.length;ell=DEGREES;wave_orders=box.bg.orders
    cuts=np.unique(np.r_[0,edges,el.right*L,OBSERVER_R]);nd,wt=roots_legendre(q)
    rr=(cuts[:-1,None]+np.diff(cuts)[:,None]*(1+nd)/2).ravel();iw=(np.diff(cuts)[:,None]*wt/2).ravel()
    u,du,_=host_grid(mass,edges,rr,mode,q)
    mun,wm=roots_legendre(angular);mu=(1+mun)/2;wm/=2
    poly=legvander(mu,64);harm=poly[:,::2].T
    dt=-ell[:,None]*(poly[:,np.maximum(0,ell-1)].T-mu*harm)/np.sqrt(1-mu**2)
    wh=np.sqrt(2*wave_orders[:,None]+1)*eval_legendre(wave_orders[:,None],mu)
    index=np.minimum(len(el.right)-1,np.searchsorted(el.right,rr/L));sh=shape(el.knots,(rr/L-el.left[index])/el.width[index])[0]
    val=[np.einsum('ij,ijk->ik',sh,el.nodes(v)[index]) for v in lab.initial.values()]
    result=np.zeros((3,3));massunits=lab.mesh.mscale/L;conversion=(1.e6*Julian_year/parsec)**2
    for first in range(0,len(rr),64):
        sl=slice(first,first+64);r=rr[sl,None];kr=np.zeros((len(r),len(mu)));kt=kr.copy()
        for p,o,sign in zip(OBSERVER_R,OBSERVER_MU,(-1,1),strict=True):
            n=np.where(r<p,ell,-(ell+1))
            co=(-sign*jf.ls.G/LIGHT**2*eval_legendre(ell,o))*(np.minimum(r,p)/np.maximum(r,p))**ell/np.maximum(r,p)/r
            kr+=(n*co)@harm;kt+=co@dt
        gr=-du[sl]@harm*conversion;gt=-(u[sl]/r)@dt*conversion
        A,B=(v[sl]@wh for v in val);profiles=(abs(A)**2,abs(B)**2,((B-A).conj()*(B+A)).real)
        for k,density in enumerate(profiles):
            measure=massunits*iw[sl,None]*wm*density
            result[k]+=np.array([measure.sum(),np.sum(measure*kr*gr),np.sum(measure*kt*gt)])
    return [dict(arm=arm,mode=mode,quadrature=q,angular=angular,mass_Msun=F[0],radial=F[1],polar=F[2],clock_acceleration=F[1]+F[2]) for arm,F in zip(('reset','coupled','paired'),result,strict=True)]
def run():
    box=Experiment(0,1)
    with np.load(prior('frozen-weights.npz')) as f:
        t=f['fine'].reshape(-1,256);m=f['launch'].reshape(t.shape);n=np.flatnonzero((m*t).sum(axis=1)>0)[-1]+1;mass=(m*(1-t))[:n]
    out=[]
    for q,ang in ((4,112),(8,160)):
        for mode in ('volume','radius'):out.extend(evaluate(box,jf.EDGES[:n+1],mass,mode,q,ang))
    table(ROOT/'continuum-host-response.csv',out,True)
if __name__=='__main__':guard();run()
