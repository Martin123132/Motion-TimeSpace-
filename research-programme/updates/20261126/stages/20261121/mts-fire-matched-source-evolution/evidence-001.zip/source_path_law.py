"""The same tagged carriers in different *physical* hosts: compute the first host-dependent motion from field equations."""
from matched_evolution import *
from numpy.polynomial.legendre import legvander
def density_jets(box,initial,shift):
    lab,obj=box.lab,box.obj;t0=free_derivative(lab,initial,box.field);d=-1j*obj.multiply(shift,initial)/obj.unit_myr
    t1=t0+d;common=box.field+obj.phi(obj.moment(initial))
    change=obj.phi(lab.run.sky_cross(obj.sky(initial),d))
    dd=-1j*(obj.bare@d+obj.multiply(common,d)-obj.mu*d+obj.multiply(shift,t1)+obj.multiply(change,initial))/obj.unit_myr
    norm=lab.mesh.mscale*box.bg.sqrt[:,None]**2*box.bg.aw
    sky=obj.sky(initial);q1=2*(sky.conj()*obj.sky(d)).real
    q2=2*(sky.conj()*obj.sky(dd)+obj.sky(t1+t0).conj()*obj.sky(d)).real
    return [(norm*q)@box.harm for q in (q1,q2)]
def path_prediction(box,arm):
    m=box.mass['represented'];outputs=[]
    for moments in density_jets(box,box.lab.initial[arm],box.static):
        acc=conjugate_acc(box.lab,box.r,box.mu,moments)
        co=analytic(box.r,box.mu,m,acc,OBSERVER_R)
        outputs.append(float(np.diff((co*box.eyes).sum(axis=1))[0]/LIGHT**2))
    return outputs
def delta_clock(x,z,dx,dz):
    ans=np.empty_like(x)
    for first in range(0,len(x),1024):
        sl=slice(first,first+1024);X=x[sl];Z=z[sl];u=dx[sl];v=dz[sl];r=np.hypot(X,Z);re=np.hypot(X+u,Z+v);mu=Z/r
        dr=(2*(X*u+Z*v)+u*u+v*v)/(r+re);dm=(v-mu*dr)/re;mue=mu+dm;pol=legvander(mu,64)
        dif=np.zeros_like(pol);dif[:,1]=dm
        for ell in range(2,65):dif[:,ell]=((2*ell-1)*(dm*pol[:,ell-1]+mue*dif[:,ell-1])-(ell-1)*dif[:,ell-2])/ell
        total=np.zeros_like(r);ell=DEGREES
        for p,o,sgn in zip(OBSERVER_R,OBSERVER_MU,(-1,1),strict=True):
            n=np.where(r[:,None]<p,ell,-(ell+1));n1=np.where(re[:,None]<p,ell,-(ell+1))
            log=n*np.log1p(dr/r)[:,None];cross=(r<p)!=(re<p)
            if cross.any():log[cross]=-n[cross]*np.log1p((r[cross]-p)/p)[:,None]+n1[cross]*np.log1p((re[cross]-p)/p)[:,None]
            ep=np.expm1(log)
            kernel=(np.minimum(p,r)/np.maximum(p,r))[:,None]**ell/np.maximum(p,r)[:,None]
            coeff=-sgn*jf.ls.G/LIGHT**2*eval_legendre(ell,o)
            total+=((ep*pol[:,::2]+(1+ep)*dif[:,::2])*kernel)@coeff
        ans[sl]=total
    return ans
def main(spread=0,order=1,count=16):
    box=Experiment(spread,order);rows=[];stable=[]
    for arm in ('reset','coupled'):
        c3,c4=path_prediction(box,arm);rr=records(ROOT/f'run-{label(spread,order,count,arm,"raw")}.csv')
        tr=records(ROOT/f'run-{label(spread,order,count,arm,"represented")}.csv')
        for a,b in zip(rr,tr,strict=True):
            t=float(a['time_Myr']);diff=float(a['tag_motion'])-float(b['tag_motion'])
            p3=t**3*c3/6;p4=t**4*c4/24
            rows.append(dict(arm=arm,time_Myr=t,third=c3,fourth=c4,pred_cubic=p3,pred_quartic=p4,
                predicted=p3+p4,measured=diff,population_difference=float(a['ordinary_motion'])-float(a['tag_motion']),
                relative_error=(diff-p3-p4)/max(abs(diff),1e-50)))
        if spread==0 and count==16:
            with np.load(ROOT/f'parcels-{label(spread,order,count,arm,"raw")}.npz') as raw,np.load(ROOT/f'parcels-{label(spread,order,count,arm,"represented")}.npz') as rep:
                cut=raw['readout']>0
                for key in ('index_i','index_j','x0','z0'):assert np.array_equal(raw[key][cut],rep[key])
                dr=raw['dx'][cut]-rep['dx'];dz=raw['dz'][cut]-rep['dz'];x=rep['x0']+rep['dx'];z=rep['z0']+rep['dz']
                tag=rep['mass'];assert np.array_equal(raw['readout'][cut],tag)
                direct=float(tag@delta_clock(x,z,dr,dz));population=float((raw['mass']-raw['readout'])@delta_clock(raw['x0'],raw['z0'],raw['dx'],raw['dz']))
                stable.append(dict(arm=arm,positive_common_parcels=int(cut.sum()),direct_trajectory_clock=direct,
                    separate_readout_difference=diff,trajectory_RMS_parsec=1e3*np.sqrt(tag@(dr**2+dz**2)/tag.sum()),
                    pure_population_motion=population,closure=(float(rr[-1]['ordinary_motion'])-float(tr[-1]['ordinary_motion']))-(direct+population)))
    table(ROOT/f'path-jets-r{spread}-a{order}-n{count}.csv',rows,True)
    if stable:table(ROOT/'stable-matched-paths.csv',stable,True)
if __name__=='__main__':guard();main(*[int(x) for x in sys.argv[1:]])
