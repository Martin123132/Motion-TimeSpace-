"""Difference in host AND wave preparation at the matched initial surface in the retained scalar constraints."""
from local_exchange import *
from live_poisson import green,Radial
from types import SimpleNamespace
def host_grid(material,edges,x,mode,q):
    ell=DEGREES
    vv=legvander(jf.ANG,65);pm=np.ones((256,len(ell)))
    for i,l in enumerate(ell[1:],1):pm[:,i]=np.diff(vv[:,l+1]-vv[:,l-1])/((2*l+1)*np.diff(jf.ANG))
    moment=material@pm;cuts=np.unique(np.r_[edges,x]);lo=cuts[:-1];hi=cuts[1:]
    interior=(lo+hi)/2<edges[-1];cell=np.clip(np.searchsorted(edges,(lo+hi)/2)-1,0,len(edges)-2)
    nd,w=roots_legendre(q);r=lo[:,None]+np.diff(cuts)[:,None]*(1+nd)/2
    frac=(3*r*r/np.diff(edges**3)[cell,None] if mode=='volume' else 1/np.diff(edges)[cell,None])
    measure=(np.diff(cuts)[:,None]*w/2)*frac*interior[:,None]
    inc=np.einsum('bq,bql->bl',measure/hi[:,None],(r/hi[:,None])[:,:,None]**ell)*moment[cell]
    dec=np.einsum('bq,bql->bl',measure/r,(lo[:,None]/r)[:,:,None]**ell)*moment[cell]
    ff=np.zeros((len(cuts),len(ell)));gg=ff.copy();ratio=lo/hi
    for j in range(len(lo)):ff[j+1]=ratio[j]**(ell+1)*ff[j]+inc[j]
    for j in range(len(lo)-1,-1,-1):gg[j]=ratio[j]**ell*gg[j+1]+dec[j]
    idx=np.searchsorted(cuts,x);f=ff[idx];g=gg[idx];loc=np.clip(np.searchsorted(edges,x)-1,0,len(edges)-2)
    fac=3*x**2/np.diff(edges**3)[loc] if mode=='volume' else 1/np.diff(edges)[loc]
    gravity=jf.ls.G
    return -gravity*(f+g),gravity*((ell+1)*f-ell*g)/x[:,None],gravity*((2*ell+1)*moment[loc])*(fac*(x<edges[-1])/x**2)[:,None]
def wave_grid(box,x):
    lab=box.lab;basis=Radial(lab,16);v,p,s=green(lab,basis,x/box.bg.length);ell=basis.sell
    scale=box.bg.vel**2*np.sqrt(2*ell+1);L=box.bg.length
    f=v[:,:,0]*scale;d=p[:,:,0]*scale/L;dd=s[:,:,0]*scale/L**2
    out=[]
    for k in (f,d,dd+2*d/x[:,None]-f*(ell*(ell+1))/x[:,None]**2):
        full=np.zeros((len(x),len(DEGREES)));kept=ell<=DEGREES[-1];full[:,ell[kept]//2]=k[:,kept];out.append(full)
    return tuple(out)
def calculate(box,knots,mix,q,mode,material,edges):
    original=box.lab.run.el.right*box.bg.length
    cuts=np.unique(np.r_[knots,edges[(edges>knots[0])&(edges<knots[-1])],original[(original>knots[0])&(original<knots[-1])]])
    lo,hi=cuts[:-1],cuts[1:];nodes,weights=roots_legendre(q)
    r=(lo[:,None]+(hi-lo)[:,None]*(1+nodes)/2).ravel();integration=((hi-lo)[:,None]*weights/2).ravel()
    x=np.r_[knots,r]
    u,du,lu=host_grid(material,edges,x,mode,q);w,dw,lw=wave_grid(box,x)
    norm=1/(2*DEGREES+1)
    avg=lambda a,b:np.sum(a*b*norm,axis=1)
    radial=avg(du,dw);tan=avg(u*DEGREES*(DEGREES+1),w)/x**2;cross=radial+tan;tf=radial-.5*tan
    prod=avg(du,w)+avg(u,dw)
    inner=(r[:,None]<knots);kn=inner@(mix/knots**2);ks=inner@(mix*knots)
    convert=1000/parsec/LIGHT**2
    term0=-(mix@prod[:3])*convert
    term1=(integration@(kn*r*r*cross[3:]))*convert
    slip=-4*(integration@(ks*tf[3:]/r))*convert
    lap=avg(u,lw)+avg(w,lu)+cross
    direct=-(integration@(kn*r*r*lap[3:]))*convert
    # Comparisons are made with the same isolated potential zero in both hosts.
    return dict(model=mode,q=q,product_force=term0,normal_gradient_source=term1,spatial_force=term0+term1,slip_force=slip,
        time_force=term0+term1-slip,direct_spatial_force=direct,
        normal_duality_error=abs(term0+term1-direct)/(abs(term0)+abs(term1)+abs(direct)))
def manufactured():
    # Constant excess densities inside two overlapping homogeneous balls: U'=a r, W'=b r in the probe shell.
    # The radial gradient source integrates to ab r^3/5 up to the removed homogeneous force.
    box=Experiment(0,1);p=box.lab.mesh.knots*box.bg.length;mix=box.lab.mesh.weights
    a=.41;b=-.16;k=.8;h=-.3;wts,nodes=roots_legendre(12)[::-1]
    rr=np.concatenate([x+(y-x)*(1+nodes)/2 for x,y in zip(p[:-1],p[1:],strict=True)])
    iw=np.concatenate([wts*(y-x)/2 for x,y in zip(p[:-1],p[1:],strict=True)])
    kn=(rr[:,None]<p)@(mix/p**2);ks=(rr[:,None]<p)@(mix*p)
    # U=k+a r^2/2, W=h+b r^2/2. The derivative of UW contains ab r^3.
    norm=-(mix@(a*p*(h+b*p*p/2)+b*p*(k+a*p*p/2)))+iw@(kn*rr**4*a*b)
    slip=-4*(iw@(ks*rr*a*b))
    ex=-.8*a*b*(mix@p**3);ez=-2*a*b*(mix@p**3)
    assert abs(norm/ex-1)<1e-12 and abs(slip/ez-1)<1e-12
    return dict(analytic_normal=ex,integrated_normal=norm,analytic_slip=ez,integrated_slip=slip)
def run():
    box=Experiment(0,1);p=box.lab.mesh.knots*box.bg.length;mix=box.lab.mesh.weights
    with np.load(prior('frozen-weights.npz')) as f:
        tags=f['fine'].reshape(-1,256);raw=f['launch'].reshape(tags.shape);last=np.flatnonzero((tags*raw).sum(axis=1)>0)[-1]+1
        diff=(raw*(1-tags))[:last]
    edges=jf.EDGES[:last+1]
    rows=[calculate(box,p,mix,q,mode,diff,edges) for q in (4,8,12) for mode in ('volume','radius')]
    table(ROOT/'matched-initial-einstein.csv',rows,True);save('homogeneous-ball-control.json',manufactured())
if __name__=='__main__':guard();run()
