from pathlib import Path
import io,json,os,sys,hashlib
for key in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','BLIS_NUM_THREADS'):os.environ[key]='1'
ROOT=Path(__file__).resolve().parent;AREA=ROOT.parent
PARENT=AREA/'mts-fire-material-pressure-transport-20261121';LIVE=AREA/'mts-fire-live-poisson-feedback-20261121'
FROZEN='24d60d067c33cd096c3ba779870047b3dd4faa20f1bd287225cee1e266e5cec5'
def sha(path):
    with path.open('rb') as inp:return hashlib.file_digest(inp,'sha256').hexdigest()
def manifest(path,expected):assert sha(path/'seal.json')==expected;return json.loads((path/'seal.json').read_bytes())
authority=manifest(PARENT,FROZEN);old=manifest(LIVE,'eaac92f91d44fe582052ed2ff52250256128b0fc78d98883188bf06beb09e0eb')
def checked(root,name,pool):
    p=root/name;assert sha(p)==pool[name],name;return p
for name in ('closed_exchange.py','live_poisson.py','live_feedback_sources.py','wave_return.py','reciprocity.py','pilot_readout.py'):checked(LIVE,name,old)
sys.path.insert(0,str(LIVE))
from closed_exchange import np,jf,Launch,LIGHT,DEGREES,OBSERVER_R,OBSERVER_MU,legvander,eval_legendre,roots_legendre,gather_force,conjugate_acc,analytic,multipoles,Evolution,advance,clock_gradient,table,keep,prior,records,guard as before_guard
from wave_return import physicalpart,free_derivative
def guard():before_guard();assert not (ROOT/'STOP-REQUESTED').exists()
def packet(name,**arrays):
    buf=io.BytesIO();np.savez_compressed(buf,**arrays);keep(ROOT/name,buf.getvalue(),True)
def save(name,data):keep(ROOT/name,(json.dumps(data,sort_keys=True,indent=2)+'\n').encode(),True)
def label(spread,order,count,arm,source):return f'{source}-{arm}-r{spread}-a{order}-n{count}'
def stateclock(lab,a,b):
    return np.vdot(clock_gradient(lab,(a+b)*.5),a-b).real*1e-10
class Experiment:
    def __init__(self,spread,order):
        self.lab=lab=Launch(64);self.obj=lab.obj;self.bg=bg=lab.obj.bg;self.native=bg.length*bg.rad
        self.targets=np.unique(np.r_[self.native,OBSERVER_R,700.]);self.ix=np.searchsorted(self.targets,self.native)
        self.obs=np.searchsorted(self.targets,OBSERVER_R);self.eyes=eval_legendre(DEGREES,OBSERVER_MU[:,None])
        self.harm=legvander(bg.mu,64)[:,::2]
        with np.load(prior('frozen-weights.npz')) as data:
            tag=data['fine'].reshape(-1,256);full=data['launch'].reshape(tag.shape);stars=data['star_mass'].reshape(tag.shape)
        last=np.flatnonzero((full*tag).sum(axis=1)>0)[-1]+1;edges=jf.EDGES[:last+1]
        grid=jf.RC[:last];index=np.arange(last);frac=np.ones(last)
        if spread:
            cuts=np.unique(np.r_[edges,self.targets[(self.targets>0)&(self.targets<edges[-1])]])
            lo,hi=cuts[:-1],cuts[1:];idx=np.searchsorted(edges,(lo+hi)*.5)-1;nodes,rule=roots_legendre(spread)
            grid=(lo[:,None]+(hi-lo)[:,None]*(nodes+1)/2).ravel()
            frac=((hi-lo)[:,None]*rule/(2*np.diff(edges)[idx,None])).ravel();index=np.repeat(idx,spread)
        self.r=grid;nodes,rule=roots_legendre(order);self.mu=(jf.UC[:,None]+nodes*np.diff(jf.ANG)[:,None]/2).ravel()
        self.mass={}
        for key,hist in (('raw',full),('represented',full*tag),('stars',stars),('tagstars',stars*tag)):
            self.mass[key]=(frac[:,None,None]*hist[index,:,None]*rule/2).reshape(len(grid),len(self.mu))
        self.initial_coef={name:self.co(self.mass[name]) for name in ('represented','raw')}
        self.field=lab.run.fields[590];self.static=self.sky(self.initial_coef['raw']-self.initial_coef['represented'])
    def co(self,arr):
        i,j=np.nonzero(arr);return multipoles(self.r[i],self.mu[j],arr[i,j],self.targets)
    def sky(self,co):return co[self.ix]@self.harm.T/self.bg.vel**2
    def ordinary(self,co):return float(np.diff((co[self.obs]*self.eyes).sum(axis=1))[0]/LIGHT**2)
    def wm(self,state):return self.lab.mesh.mscale*self.bg.sqrt[:,None]**2*((abs(self.obj.sky(state))**2*self.bg.aw)@self.harm)
