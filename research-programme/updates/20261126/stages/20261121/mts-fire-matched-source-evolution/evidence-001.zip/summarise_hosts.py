"""Keep static replacement, motion of the active ordinary mass, tracer-only paths and wave readouts separate."""
from matched_io import *
def scalar(row,name):return float(row[name])
def run():
    box=Experiment(0,1);allrows=[];paired=[];metric=[]
    for spread,steps in ((0,16),(2,8)):
        for arm in ('reset','coupled'):
            data={};waves={}
            for src in ('raw','represented'):
                key=label(spread,1,steps,arm,src);data[src]=records(ROOT/f'run-{key}.csv')
                with np.load(ROOT/f'wave-{key}.npz') as f:waves[src]={k:f[k] for k in f.files if k.startswith(('live','fix'))}
            for a,b in zip(data['raw'],data['represented'],strict=True):
                i=a['step'];t=float(a['time_Myr']);diff=lambda key:float(a[key])-float(b[key])
                quench=stateclock(box.lab,waves['raw']['fix'+i],waves['represented']['fix'+i])
                livewave=stateclock(box.lab,waves['raw']['live'+i],waves['represented']['live'+i]);wfb=diff('wave_feedback')
                energy_slope=diff('kinetic')
                allrows.append(dict(arm=arm,rspread=spread,steps=steps,time_Myr=t,static_mass=diff('initial_ordinary_clock'),
                    static_driver_wave=quench,population_motion=float(a['ordinary_motion'])-float(a['tag_motion']),
                    common_tag_path=diff('tag_motion'),active_mass_motion=diff('ordinary_motion'),moving_source_wave=wfb,
                    raw_feedback=float(a['total_feedback']),represented_feedback=float(b['total_feedback']),
                    live_wave_cross=livewave,wave_subtraction_check=livewave-(wfb+quench),postlaunch_change=quench+diff('total_feedback'),
                    net_including_static=diff('initial_ordinary_clock')+quench+diff('total_feedback'),additional_kinetic=energy_slope))
        for t in (.06,.12,.24):
            aa,bb=[next(x for x in allrows if x['arm']==arm and x['rspread']==spread and x['time_Myr']==t) for arm in ('coupled','reset')]
            paired.append(dict(time_Myr=t,rspread=spread,steps=steps,**{k:aa[k]-bb[k] for k in aa if k not in ('arm','rspread','steps','time_Myr')}))
    table(ROOT/'host-budget.csv',allrows,True);table(ROOT/'four-way-budget.csv',paired,True)
    kinetic=records(ROOT/'ordinary-kinetic-metric.csv')
    for spread,phase in ((0,'measured_at_024'),(0,'launch_prediction_at_024'),(2,'launch_prediction_at_024')):
        for source in ('raw','represented'):
            for material in ('active','passive_tag','active_stars'):
                a,b=[next(r for r in kinetic if r['arm']==arm and r['source']==source and r['material']==material and int(r['layout'])==spread and r['phase']==phase) for arm in ('coupled','reset')]
                metric.append(dict(source=source,material=material,phase=phase,layout=spread,**{k:float(a[k])-float(b[k]) for k in ('spatial_force','slip_force','time_force')}))
    table(ROOT/'paired-kinetic-metric.csv',metric,True)
if __name__=='__main__':guard();run()
