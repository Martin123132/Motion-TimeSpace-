"""A local field-stress transaction on the same two-way Newtonian interaction and transported masses."""
from matched_io import *
from scipy.constants import parsec
class ShellField:
    def __init__(self,r,m,lo,hi):
        self.l=DEGREES;self.unit=np.sqrt(lo*hi);self.lo=lo;self.hi=hi;u=self.unit;l=self.l
        inside=r<lo;outside=r>hi;sel=~(inside|outside)
        self.inner=((r[inside,None]/u)**l*m[inside]).sum(axis=0)
        self.outer=((u/r[outside,None])**(l+1)*m[outside]).sum(axis=0)
        self.r,index=np.unique(r[sel],return_inverse=True);mids=m[sel]
        self.m=np.stack([np.bincount(index,weights=mids[:,k],minlength=len(self.r)) for k in range(len(l))],axis=1)
        self.prefix=np.vstack([self.inner,self.inner+np.cumsum((self.r[:,None]/u)**l*self.m,axis=0)])
        tail=np.cumsum(((u/self.r[:,None])**(l+1)*self.m)[::-1],axis=0)[::-1]
        self.suffix=np.vstack([self.outer+tail,self.outer])
    def force(self,x,side=.5):
        ix=np.searchsorted(self.r,x);rr=x[:,None];l=self.l;u=self.unit
        S=(u/rr)**l/rr*self.prefix[ix];E=(rr/u)**l/u*self.suffix[ix]
        gr=jf.ls.G/rr*(l*E-(l+1)*S);at=jf.ls.G/rr*(S+E)
        on=(ix<len(self.r))&(self.r[np.minimum(ix,len(self.r)-1)]==x) if len(self.r) else np.zeros(len(x),bool)
        if on.any():gr[on]-=side*jf.ls.G*(2*l+1)*self.m[ix[on]]/rr[on]**2
        return gr,at
def bfun(r,lo,hi,form):
    s=(r-lo)/(hi-lo);a=4*s*(1-s)
    if form=='compact':return a**4,16*a**3*(1-2*s)/(hi-lo)
    if form=='constant':return np.ones_like(s),0*s
    if form=='virial':return r/np.sqrt(lo*hi),np.ones_like(s)/np.sqrt(lo*hi)
    raise ValueError(form)
def local(box,mass,r,mu,wm,lo,hi,order):
    mat=ShellField(r,mass[:,None]*legvander(mu,64)[:,::2],lo,hi)
    wave=ShellField(box.native,wm,lo,hi);cuts=np.unique(np.r_[lo,hi,mat.r,wave.r]);qw,ww=roots_legendre(order)
    rr=(cuts[:-1,None]+np.diff(cuts)[:,None]*(1+qw)/2).ravel();weights=(np.diff(cuts)[:,None]*ww/2).ravel()
    n=2*DEGREES+1;ell=DEGREES;results=[]
    def tr(x,side=.5):
        ar,at=mat.force(x,side);br,bt=wave.force(x,side)
        rad=np.sum(ar*br/n,axis=1);theta=np.sum(at*bt*ell*(ell+1)/n,axis=1)
        return (rad-theta)/jf.ls.G,-2*rad/jf.ls.G
    mr=mat.r;wr=wave.r;mw=np.sum(mat.m*wave.force(mr)[0],axis=1);ww=np.sum(wave.m*mat.force(wr)[0],axis=1)
    bd=np.array([lo,hi]);left=tr(bd,0)[0]*bd**2;right=tr(bd,1)[0]*bd**2
    for form in ('compact','constant','virial'):
        fm=bfun(mr,lo,hi,form)[0]@mw;fw=bfun(wr,lo,hi,form)[0]@ww
        volume=np.zeros(2)
        for first in range(0,len(rr),2048):
            sl=slice(first,first+2048);x=rr[sl];f,df=bfun(x,lo,hi,form);a,b=tr(x)
            volume+=np.array([weights[sl]@(x**2*a*df),weights[sl]@(x*b*f)])
        bm=bfun(mr,lo,hi,form)[0]*mw;bw=bfun(wr,lo,hi,form)[0]*ww
        ms=bm[(mr==lo)|(mr==hi)].sum();ws=bw[(wr==lo)|(wr==hi)].sum()
        for fraction in (0.,.5,1.):
            boundary=bfun(bd,lo,hi,form)[0]*np.array([fraction*left[0]+(1-fraction)*right[0],fraction*right[1]+(1-fraction)*left[1]])
            fm1=fm-(1-fraction)*ms;fw1=fw-(1-fraction)*ws
            stress=volume.sum()+boundary[0]-boundary[1];scale=abs(fm1)+abs(fw1)
            results.append(dict(window=form,order=order,boundary_fraction=fraction,material_force=fm1,wave_force=fw1,sum_of_forces=fm1+fw1,
                radial_stress_work=volume[0],tangential_stress_work=volume[1],inner_traction=boundary[0],outer_traction=boundary[1],
                boundary_material_force=ms,boundary_wave_force=ws,combined_stress=stress,absolute_residual=stress-fm1-fw1,
                relative_residual=abs(stress-fm1-fw1)/max(scale,1.e-99),
                shell_radii=len(cuts),coincident_sheet_radii=int(np.intersect1d(mat.r,wave.r).size)))
    return results
def run(arm):
    box=Experiment(0,1);out=[]
    for source in ('raw','represented'):
        key=label(0,1,16,arm,source)
        with np.load(ROOT/f'parcels-{key}.npz') as f:mass=f['mass'];x0=f['x0'];z0=f['z0'];dx=f['dx'];dz=f['dz']
        with np.load(ROOT/f'wave-{key}.npz') as f:wave=f['live16']
        for phase,state,xx,zz in (('start',box.lab.initial[arm],x0,z0),('end',wave,x0+dx,z0+dz)):
            radius=np.hypot(xx,zz);mu=np.abs(zz)/radius;wm=box.wm(state)
            for order in (2,4):
                out.extend([dict(arm=arm,source=source,phase=phase,**q) for q in local(box,mass,radius,mu,wm,*OBSERVER_R,order)])
    table(ROOT/f'boundary-matched-exchange-{arm}.csv',out,True)
if __name__=='__main__':guard();run(sys.argv[1])
