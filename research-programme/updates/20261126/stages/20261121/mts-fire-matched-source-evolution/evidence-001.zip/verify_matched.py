"""Verify local receipts and both parents; no dynamical evolution is run here."""
import csv
import json
import re
import sys
from matched_io import ROOT, PARENT, LIVE, np, sha, authority, old, checked, save

def rows(name):
    with (ROOT/name).open(newline='') as stream:
        return list(csv.DictReader(stream))

def select(table, **keys):
    return [row for row in table if all(row[key] == str(value) for key, value in keys.items())]

def one(table, **keys):
    result = select(table, **keys)
    assert len(result) == 1, keys
    return result[0]

def number(row, key):
    return float(row[key])

def verify(seal):
    assert __debug__, 'Run without -O'
    for root, hashes in ((PARENT, authority), (LIVE, old)):
        for name in hashes:
            checked(root, name, hashes)
    for file in ROOT.glob('*.py'):
        compile(file.read_bytes(), str(file), 'exec')
    assert not any(path.is_dir() or path.name.endswith(('.part','.work','.tmp')) for path in ROOT.iterdir())
    for file in ROOT.glob('*.md'):
        for url in re.findall(r'\[[^\]]+\]\(([^)]+)\)', file.read_text(encoding='utf-8')):
            assert url.startswith('https://') or (ROOT/url).exists(), (file, url)
    report = dict(verified_parents=[len(authority),len(old)])
    stage_tables = list(ROOT.glob('run-*.csv'))
    assert len(stage_tables) == 14
    energy = {}
    worst_norm = worst_monopole = replay_error = 0.
    for file in stage_tables:
        time_rows = rows(file.name)
        assert [number(row,'time_Myr') for row in time_rows] == [.06,.12,.24]
        for row in time_rows:
            worst_norm = max(worst_norm,number(row,'worst_norm'))
            worst_monopole = max(worst_monopole,abs(number(row,'exterior_monopole')))
        assert (ROOT/file.name.replace('run-','wave-').replace('.csv','.npz')).is_file()
    for arm in ('coupled','reset'):
        errs = [abs(number(rows(f'run-raw-{arm}-r0-a1-n{count}.csv')[-1],'total_energy_error')) for count in (4,8,16)]
        assert all(3.5 < coarse/fine < 4.5 for coarse,fine in zip(errs,errs[1:]))
        energy[arm] = errs
        with np.load(LIVE/f'closed-1-16-{arm}.npz') as archive, np.load(ROOT/f'wave-represented-{arm}-r0-a1-n16.npz') as current:
            replay_error = max(replay_error,float(np.max(abs(archive['endpoint_wave']-current['live16']))))
        legacy = list(csv.DictReader((LIVE/f'closed-1-16-{arm}.csv').read_text().splitlines()))[-1]
        current = rows(f'run-represented-{arm}-r0-a1-n16.csv')[-1]
        assert abs(number(legacy,'ordinary_clock_change')-number(current,'ordinary_motion')) < 1e-24
    assert replay_error < 1.e-12 and worst_norm < 1e-10 and worst_monopole < 1e-8
    report.update(runs=len(stage_tables),raw_energy_by_arm=energy,worst_norm=worst_norm,worst_monopole=worst_monopole,represented_wave_replay_max_abs=replay_error)
    budget = rows('four-way-budget.csv')
    native = one(budget,time_Myr=.24,rspread=0); spread = one(budget,time_Myr=.24,rspread=2)
    for row in budget:
        assert number(row,'static_mass') == 0.
        assert abs(sum(number(row,k) for k in ('static_driver_wave','active_mass_motion','moving_source_wave'))-number(row,'postlaunch_change')) < 1.e-24
        assert abs(number(row,'wave_subtraction_check')) < 1.e-22
    assert number(native,'raw_feedback') < number(native,'represented_feedback') < 0
    report['radial_and_time_layout_fractional_spread'] = abs(number(spread,'postlaunch_change')/number(native,'postlaunch_change')-1)
    assert report['radial_and_time_layout_fractional_spread'] < .002
    continuum = rows('continuum-host-response.csv')
    predictions = rows('prediction-r0-a1.csv')
    native_curv = number(one(predictions,arm='coupled',source='raw'),'static_driver_clock_second')-number(one(predictions,arm='reset',source='raw'),'static_driver_clock_second')
    curv = number(one(continuum,arm='paired',mode='volume',quadrature=8),'clock_acceleration')
    report['continuum_vs_native_curvature_fraction'] = abs(curv/native_curv-1)
    report['continuum_vs_endpoint_fraction'] = abs(.5*.24**2*curv/number(native,'static_driver_wave')-1)
    assert max(report['continuum_vs_native_curvature_fraction'],report['continuum_vs_endpoint_fraction']) < .003
    for record in rows('stable-matched-paths.csv'):
        assert int(record['positive_common_parcels']) == 220278 and abs(number(record,'closure')) < 1.e-21
        assert 0 < number(record,'direct_trajectory_clock') < number(record,'pure_population_motion')*1.e-4
    exchange = sum((rows(f'boundary-matched-exchange-{arm}.csv') for arm in ('coupled','reset')),[])
    reference = sum((rows(f'local-exchange-{arm}.csv') for arm in ('coupled','reset')),[])
    assert len(exchange)==144 and {r['boundary_fraction'] for r in exchange} == {'0.0','0.5','1.0'}
    for tag, table in (('corrected',exchange),('unmatched',reference)):
        report[tag+'_shell_residual'] = max(number(r,'relative_residual') for r in select(table,order=4))
    assert report['corrected_shell_residual'] < 1.e-12 and report['unmatched_shell_residual'] > .004
    for record in rows('ordinary-kinetic-controls.csv'):
        assert abs(number(record,'kinetic_energy_direct')/number(record,'kinetic_energy_hamiltonian')-1) < 1.e-12
    forces = rows('matched-initial-einstein.csv'); clocks = rows('isolated-area-clock.csv')
    sphere = json.loads((ROOT/'homogeneous-ball-control.json').read_bytes())
    for kind in ('normal','slip'):
        assert abs(sphere['integrated_'+kind]-sphere['analytic_'+kind]) < 1.e-12
    assert len(forces)==6 and max(number(r,'normal_duality_error') for r in forces) < 1.e-12
    assert len(clocks)==4 and max(number(r,'duality') for r in clocks) < 1.e-12
    for clock in clocks:
        assert number(clock,'lapse_coordinate') > 0 > number(clock,'area_mean_log_clock') > number(clock,'effective_rate_ratio')
        assert abs(number(clock,'lapse_coordinate')+number(clock,'area_radius_term')+number(clock,'area_weight_term')-number(clock,'area_mean_log_clock')) < 1.e-29
    test = rows('area-clock-control.csv')
    assert all(3.9 < number(coarse,'rel')/number(fine,'rel') < 4.1 for coarse,fine in zip(test,test[1:]))
    geometry_errors = {}
    for model in ('volume','radius'):
        clock = one(clocks,order=8,model=model)
        predicted = number(clock,'area_radius_term')+number(clock,'area_weight_term')
        seq = [abs(number(r,'mixed_geometry')/predicted-1) for r in select(rows('area-replay-retained.csv'),model=model)]
        assert len(seq)==4 and seq[-1] < 2e-6 and seq[-1]<seq[0]
        geometry_errors[model] = seq
    report['nonlinear_area_vs_derivative'] = geometry_errors
    output = ROOT/'validation.json'
    if seal:
        save(output.name,report)
    assert json.loads(output.read_bytes())==report
    hashes = {p.name:sha(p) for p in sorted(ROOT.iterdir()) if p.name!='seal.json'}
    if seal:
        save('seal.json',hashes)
    assert json.loads((ROOT/'seal.json').read_bytes()) == hashes
    print('Verified',len(hashes),'files;',sha(ROOT/'seal.json'))
    print(json.dumps(report,indent=2))

if __name__=='__main__':
    verify(sys.argv[1:] == ['--seal'])
