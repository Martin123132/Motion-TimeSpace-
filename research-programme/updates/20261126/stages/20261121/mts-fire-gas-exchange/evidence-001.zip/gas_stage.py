import os
for var in ('OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','OMP_NUM_THREADS','NUMEXPR_NUM_THREADS','BLIS_NUM_THREADS'):
    os.environ[var]='1'
import sys,json,hashlib,io
from pathlib import Path
ROOT=Path(__file__).resolve().parent
STARS=ROOT.parent/'mts-fire-material-transport-20261121'
def digest(path):
    with path.open('rb') as inp:return hashlib.file_digest(inp,'sha256').hexdigest()
SEAL='9f3cf7501a23f9eccc268cf69b42da38f9fb746260a2c4dcd896e5e6dcc97402'
assert digest(STARS/'seal.json')==SEAL
manifest=json.loads((STARS/'seal.json').read_bytes())
def prior(name):
    p=STARS/name;assert digest(p)==manifest[name],name
    return p
for name in ('material_inputs.py','material_readouts.py','wave_response.py'):prior(name)
sys.path.insert(0,str(STARS))
from material_inputs import np,source,jf,frames,fixed,groups,clocks,previous,Launch,records,table,guard as parent_guard
from moment_io import keep
def guard():
    parent_guard();assert not (ROOT/'STOP-REQUESTED').exists()
def archive(name,**data):
    out=io.BytesIO();np.savez_compressed(out,**data);keep(ROOT/name,out.getvalue(),True)
def record(name,values):
    keep(ROOT/name,(json.dumps(values,indent=2,sort_keys=True)+'\n').encode(),True)
def cuts():
    with np.load(prior('frozen-weights.npz')) as packet:
        return {name:np.r_[packet[name],0.] for name in ('fine','coarse')}
COUNT=len(jf.RC)*len(jf.UC);PARTS=16
dtype=np.dtype([('id','<u4'),('child','<u4'),('gen','u1'),('cell','<i4'),('m','<f4'),('xyz','<f4',(3,))])
def paths(s,p):
    base=ROOT/'gas'/f's{s}-{p}'
    return base.with_suffix('.npz'),base.with_suffix('.json')
