"""Cross-check alias-risk families and births with the published z=0 to earlier-index pointers."""
from ancestry import *
from fire_source import BASE
import datetime,time
def fetch_ids(s,p,deadline):
    path,rr=paths(s,p);meta=json.loads(rr.read_bytes());r=source.Remote(meta['url'],65536)
    try:
        assert list(r.id)==meta['identity']
        with source.h5py.File(r,'r') as h:
            d=h['PartType0/ParticleIDs'];spans=[];d.id.chunk_iter(lambda ch:spans.append((ch.byte_offset,ch.byte_offset+ch.size)))
            runs=[]
            for u,v in sorted(spans):
                if runs and u<=runs[-1][1]+4096:runs[-1][1]=max(v,runs[-1][1])
                else:runs.append([u,v])
            for u,v in runs:
                buf=bytearray(v-u)
                for start in range(u,v,8*1024**2):
                    guard();assert time.time()<deadline;n=min(v-start,8*1024**2);buf[start-u:start-u+n]=r.range(start,n)
                r.spans.append((u,buf))
            ids=d[:];assert hashlib.sha256(memoryview(ids)).hexdigest()==meta['field_sha256']['ParticleIDs']
        return ids,r.transferred
    finally:r.close()

def select(deadline):
    births=np.load(ROOT/'stellar-ledger.npz')['births'];rootset=[]
    for k in range(PARTS):
        a=shard(590,k);b=np.concatenate([shard(591,k),births[births['id']%PARTS==k]])
        rootset.extend(np.union1d(keys(a)[2],keys(b)[2]).tolist());del a,b
    risk=np.unique(rootset);assert len(risk)==sum(int(r['ambiguous_roots']) for r in records(ROOT/'family-checks.csv'))
    targets=np.union1d(risk,births['id']);out={'risk':risk};traffic=0
    for s in (590,591):
        stars0=json.loads(prior('identity.json').read_bytes())['count'+str(s)]
        offset=stars0;alls=[];ii=[]
        for p in range(4):
            ids,nb=fetch_ids(s,p,deadline);traffic+=nb
            wanted=np.flatnonzero(np.isin(ids,targets)|((ids%1048576)==0));selected=ids[wanted]
            native=paths(s,p)[0]
            with np.load(native) as arc:
                for k in range(PARTS):
                    take=selected%PARTS==k;arr=arc[f'b{k}']
                    rr=arr[np.isin(arr['id'],targets)|((arr['id']%1048576)==0)]
                    assert np.array_equal(rr['id'],selected[take])
                    ii.append(offset+wanted[take]);alls.append(rr)
            offset+=len(ids);print('native IDs',s,p,flush=True)
        if s==591:
            with np.load(prior('stellar-links.npz')) as a:new=a['parent']<0
            ii.append(np.flatnonzero(new));alls.append(births)
        idx=np.concatenate(ii);arr=np.concatenate(alls);order=np.argsort(idx)
        out[f'i{s}']=idx[order];out[f'a{s}']=arr[order]
    archive('pointer-targets.npz',**out);record('pointer-index-receipt.json',dict(bytes=traffic,risk_roots=risk.tolist()))

def scan(deadline):
    with np.load(ROOT/'pointer-targets.npz') as a:idx=[a[f'i{s}'] for s in (590,591)]
    remote=[];hf=[];offsets=[];receipts=[];hashes=[hashlib.sha256(),hashlib.sha256()];lists=[[],[],[]]
    try:
        for s in (590,591):
            url=BASE+f'track/star_gas_pointers_{s}.hdf5';r=source.Remote(url,65536);remote.append(r)
            h=source.h5py.File(r,'r');hf.append(h);d=h['z0.to.z.index']
            assert d.chunks is None and d.compression is None and d.dtype==np.dtype('<i4')
            assert int(h['z0.snapshot.index'][()])==600 and int(h['z.snapshot.index'][()])==s
            lo,hi=h['z.gas.index.limits'][:];assert int(lo)==json.loads(prior('identity.json').read_bytes())['count'+str(s)]
            offsets.append(d.id.get_offset());receipts.append(dict(url=url,id=r.id,count=len(d),total=int(hi),star_offset=int(lo)))
        n=receipts[0]['count'];assert n==receipts[1]['count']
        for st in range(0,n,2000000):
            guard();assert time.time()<deadline;num=min(n-st,2000000);pairs=[];used=np.zeros(num,bool)
            for j,r in enumerate(remote):
                raw=r.range(offsets[j]+4*st,4*num);hashes[j].update(raw);vals=np.frombuffer(raw,'<i4')
                assert np.all(vals<receipts[j]['total'])
                ix=np.minimum(np.searchsorted(idx[j],vals),len(idx[j])-1);used|=(idx[j][ix]==vals);pairs.append(vals)
            for col,v in zip(lists,(pairs[0][used],pairs[1][used],st+np.flatnonzero(used)),strict=True):col.append(v.copy())
        for j,row in enumerate(receipts):row.update(bytes=remote[j].transferred,array_hash=hashes[j].hexdigest())
    finally:
        for h in hf:h.close()
        for r in remote:r.close()
    archive('pointer-links.npz',left=np.concatenate(lists[0]),right=np.concatenate(lists[1]),via600=np.concatenate(lists[2]))
    record('pointer-data.json',receipts)

if __name__=='__main__':
    end=datetime.datetime.fromisoformat(sys.argv[1]).timestamp();assert time.time()<end<time.time()+14400
    if not (ROOT/'pointer-targets.npz').exists():select(end)
    if not (ROOT/'pointer-links.npz').exists():scan(end)
