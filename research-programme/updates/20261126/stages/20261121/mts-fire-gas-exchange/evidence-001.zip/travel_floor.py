"""Lower bounds from radial/height bin support, allowing all unresolved positions within each bin."""
from material_exchange_bounds import *
def envelopes(s,d,low,hi,cap,dt):
    # An unconstrained external mass has the entire clipped range available.
    low=np.minimum(low,cap);hi=np.minimum(hi,cap);grid=np.unique(np.r_[0,low,hi,cap])
    pos=(grid[1:]+grid[:-1])/2;width=np.diff(grid)
    def cdf(m,x,where):
        order=np.argsort(x);cs=np.r_[0.,np.cumsum(m[order],dtype=np.longdouble)]
        return cs[np.searchsorted(x[order],where,side='right')].astype(float)
    smin=cdf(s,hi,pos);smax=cdf(s,low,pos);dmin=cdf(d,hi,pos);dmax=cdf(d,low,pos)
    mismatch=np.maximum.reduce([np.zeros(len(pos)),smin-dmax,dmin-smax])
    dist=float(width@mismatch);floor=dist/s.sum()/dt*977.7922216807892
    rows=[]
    for velocity in (0.,25.,50.,200.,1000.,299792.458):
        reach=velocity*dt/977.7922216807892
        # One-sided Hall inequalities at every relevant jump, not just bin midpoints.
        points=np.unique(np.clip(np.r_[low,hi,low-reach,hi-reach],0,cap))
        sm=cdf(s,hi,points);dm=cdf(d,hi,points);sd=cdf(s,low,points+reach);dd=cdf(d,low,points+reach)
        need=max(0.,np.max(sm-dd),np.max(dm-sd))
        rows.append(dict(speed_kms=velocity,unavoidable_raw_mass_above_speed_Msun=need,minimum_fraction=need/s.sum()))
    return floor,dist,rows

def run():
    la,own,s,d,mis,w=inputs('fine');s=s.astype(float);d=d.astype(float)
    radlo=np.repeat(jf.EDGES[:-1],256);radhi=np.repeat(jf.EDGES[1:],256)
    mulo=np.tile(jf.ANG[:-1],len(jf.RC));muhi=np.tile(jf.ANG[1:],len(jf.RC))
    dt=clocks()[1];rows=[];speedrows=[]
    for label,low,hi,cap in [('radius30',radlo,radhi,30.),('radius500',radlo,radhi,500.),
        ('height10',radlo*mulo,radhi*muhi,10.),('height30',radlo*mulo,radhi*muhi,30.)]:
        # Outside the aperture radius exceeds 500, but height need not be large.
        low=np.r_[low,cap if 'radius' in label else 0.,0.];hi=np.r_[hi,cap,cap]
        floor,dist,sub=envelopes(s,d,low,hi,cap,dt)
        rows.append(dict(projection=label,exchange_Msun=s.sum(),minimum_path_mass_kpc_Msun=dist,
                         minimum_mean_speed_kms=floor,minimum_rms_speed_kms=floor,minimum_transport_energy_J=.5*s.sum()*1.98847e30*(floor*1000)**2))
        for q in sub:speedrows.append(dict(projection=label,**q))
    table(ROOT/'travel-floors.csv',rows,True);table(ROOT/'speed-feasibility.csv',speedrows,True)
if __name__=='__main__':run()
