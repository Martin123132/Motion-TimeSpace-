"""Nonoverlapping binary identity intervals; mass ledgers before any field calculation."""
from gas_stage import *

def hist(c,m):return np.bincount(c.astype(np.intp),weights=m,minlength=COUNT+1)
def cells(x):return np.where(x<0,COUNT,x)
def stars():
    mapping=cuts();base=[];bm=[];factor=1e10/frames(590)[0]
    for p in range(4):
        with np.load(prior(f'stars/s590-{p}.npz')) as a:base.append(cells(a['cell']));bm.append(a['mass_stored'])
    bc=np.concatenate(base);mass=np.concatenate(bm);del base,bm
    with np.load(prior('stellar-links.npz')) as ar:link=ar['parent']
    donor=np.zeros(COUNT+1);launch=hist(bc,mass.astype(float)*factor);oldstar={k:np.zeros_like(donor) for k in mapping};births=[]
    off=0
    for p in range(4):
        with np.load(prior(f'stars/s591-{p}.npz')) as a:
            n=len(a['cell']);ids=link[off:off+n];off+=n;live=ids>=0;b=ids[live];e=cells(a['cell']);m=a['mass_stored'].astype(float)*factor
            lost=mass[b].astype(float)*factor-m[live];assert min(lost)>=0
            donor+=hist(bc[b],lost)
            for k,w in mapping.items():oldstar[k]+=hist(e[live],m[live]*w[bc[b]])
            new=np.zeros((~live).sum(),dtype);new['cell']=e[~live];new['m']=a['mass_stored'][~live]
            for tag,src in [('id','ParticleIDs'),('child','ParticleChildIDsNumber'),('gen','ParticleIDGenerationNumber')]:new[tag]=a[src][~live]
            births.append(new)
    new=np.concatenate(births);assert len(new)==json.loads(prior('identity.json').read_bytes())['unmatched_endpoint']
    archive('stellar-ledger.npz',donor=donor,launch=launch,births=new,**oldstar)
    return new

def reverse(x):
    v=x.astype(np.uint32).copy()
    for n,mask in ((1,0x55555555),(2,0x33333333),(4,0x0f0f0f0f),(8,0x00ff00ff)):
        v=((v>>n)&mask)|((v&mask)<<n)
    return (v>>16)|(v<<16)

def keys(a):
    loc=reverse(a['child']).astype(np.uint64);root=a['id'].astype(np.uint64)
    key=(root<<32)|loc
    gen=a['gen'].astype(np.int64)
    shift=np.left_shift(np.uint64(1),np.clip(32-gen,0,32).astype(np.uint64))
    bad=(gen>=30)|(a['child'].astype(np.uint64)>=np.left_shift(np.uint64(1),np.minimum(gen,32).astype(np.uint64)))
    order=np.argsort(key,kind='stable')
    overlap=(root[order[1:]]==root[order[:-1]])&(loc[order[1:]]<loc[order[:-1]]+shift[order[:-1]])
    ambiguous=np.unique(np.r_[a['id'][bad],a['id'][order[1:][overlap]]])
    return key,order,ambiguous

def match(left,right):
    k0,o0,b0=keys(left);k1,_,b1=keys(right);bad=np.union1d(b0,b1)
    okroot=~np.isin(right['id'],bad)
    pos=np.searchsorted(k0[o0],k1,side='right')-1;candidate=o0[np.maximum(pos,0)]
    g0=left['gen'][candidate].astype(int);g1=right['gen'].astype(int)
    mask=(np.left_shift(np.uint64(1),np.minimum(g0,32).astype(np.uint64))-np.uint64(1))
    ok=(pos>=0)&okroot&(right['id']==left['id'][candidate])&(g1>=g0)&((right['child'].astype(np.uint64)&mask)==left['child'][candidate])
    parent=np.where(ok,candidate,-1);depth=np.where(ok,g1-g0,0)
    return parent,depth,bad

def shard(s,k):
    pieces=[]
    for p in range(4):
        path,receipt=paths(s,p);rr=json.loads(receipt.read_bytes())
        with np.load(path) as ar:part=ar[f'b{k}']
        assert len(part)==rr['counts'][k] and np.all(part['id']%PARTS==k)
        pieces.append(part)
    return np.concatenate(pieces)

def reduce(k,new):
    guard();a=shard(590,k);gas=shard(591,k);n=len(gas)
    ep=np.concatenate((gas,new[new['id']%PARTS==k]));del gas
    par,gap,bad=match(a,ep);ok=par>=0;ip=par[ok]
    m=a['m'].astype(float)*(1e10/frames(590)[0]);me=ep['m'].astype(float)*(1e10/frames(591)[0])
    c=a['cell'];ce=ep['cell'];nc=len(a);modes=cuts()
    multiplicity=np.bincount(ip,minlength=nc);coverage=np.bincount(ip,weights=np.exp2(-gap[ok].astype(float)),minlength=nc)
    assert max(coverage)<=1+1e-14
    total=np.bincount(ip,weights=me[ok],minlength=nc)
    inherited=np.minimum(m*coverage,total)
    t=np.zeros(len(ep));t[ok]=inherited[ip]*(me[ok]/total[ip])
    assert np.max(t-me)<1e-9
    req=np.maximum(0,me-t);supply=np.maximum(0,m-inherited)
    equal=np.zeros(len(ep));equal[ok]=m[ip]*np.exp2(-gap[ok].astype(float))
    sym=np.minimum(equal,me)
    flags=np.arange(len(ep))>=n;birth=flags[ok]
    ledger=dict(shard=k,launch=nc,end_gas=n,births=len(ep)-n,exact_gas=int(np.sum(ok&~flags&(gap==0))),
        split_gas=int(np.sum(ok&~flags&(gap>0))),exact_birth=int(np.sum(ok&flags&(gap==0))),
        split_birth=int(np.sum(ok&flags&(gap>0))),unmapped_gas=int(np.sum(~ok&~flags)),unmapped_birth=int(np.sum(~ok&flags)),
        ambiguous_roots=len(bad),ambiguous_launch=int(np.isin(a['id'],bad).sum()),ambiguous_end=int(np.isin(ep['id'],bad).sum()),
        parent_gone=int(np.sum(coverage==0)),partial_parent=int(np.sum((coverage>0)&(coverage<1))),multi_child=int(np.sum(multiplicity>1)),
        max_depth=int(max(gap)),birth_inherited_Msun=t[flags].sum(),birth_total_Msun=me[flags].sum(),
        launch_mass_Msun=m.sum(),endpoint_gas_mass_Msun=me[~flags].sum(),supply_Msun=supply.sum(),demand_Msun=req.sum(),
        unknown_initial_Msun=m[coverage==0].sum(),unknown_final_Msun=me[~ok].sum(),raw_change_explained=(req.sum()-supply.sum())-(me.sum()-m.sum()))
    assert abs(ledger['raw_change_explained'])<1e-12*m.sum()
    arrays=dict(raw0=hist(c,m),raw1=hist(ce,me),gas_donor=hist(c,supply),demand=hist(ce,req),
                demand_birth=hist(ce[flags],req[flags]),birthraw=hist(ce[flags],me[flags]),
                sym_donor=hist(c,np.maximum(0,m-np.bincount(ip,weights=sym[ok],minlength=nc))),sym_demand=hist(ce,me-sym))
    for mode,w in modes.items():
        source=w[c[ip]];binweight=hist(ce[ok],t[ok]*source);given=hist(c,m*w[c])
        arrays[mode+'_kept']=binweight;arrays[mode+'_symkept']=hist(ce[ok],sym[ok]*source)
        arrays[mode+'_birthkeep']=hist(ce[ok][birth],t[ok][birth]*source[birth])
        arrays[mode+'_idtracer']=hist(ce[ok],equal[ok]*source)
        arrays[mode+'_untraced']=hist(c,w[c]*m*(1-coverage))
        arrays[mode+'_launch']=given
        ledger[mode+'_unmapped_Msun']=np.sum(m*w[c]*(1-coverage))
        ledger[mode+'_unmapped_endpoint_destination_Msun']=me[~ok]@w[ce[~ok]]
        assert abs(given.sum()-binweight.sum()-supply@w[c])<2e-12*max(given.sum(),1)
    return arrays,ledger

def main():
    for s in (590,591):
        for p in range(4):
            f,r=paths(s,p);assert digest(f)==json.loads(r.read_bytes())['packet']
    new=stars();out={};reports=[]
    for k in range(PARTS):
        arrays,row=reduce(k,new);reports.append(row)
        for key,val in arrays.items():
            if key not in out:out[key]=val
            else:out[key]+=val
        print('shard',k,'unmapped end',row['unmapped_gas'],flush=True)
    archive('gas-ledger.npz',**out);table(ROOT/'family-checks.csv',reports,True)
if __name__=='__main__':main()
