"""How much additional, unobserved exchange could undo a sign? Include a no-retention control."""
from material_exchange_bounds import *
def run():
    lab=Launch(64);ks=kernel_bank(lab);launch,own,s,d,mis,w=inputs('fine')
    with np.load(ROOT/'gas-ledger.npz') as g,np.load(ROOT/'stellar-ledger.npz') as b:
        raw0=g['raw0']+b['launch'];raw1=g['raw1'].copy()
    with np.load(prior('stellar-links.npz')) as a:parents=a['parent'];off=0
    for p in range(4):
        with np.load(prior(f'stars/s591-{p}.npz')) as a:
            cell=a['cell'];m=a['mass_stored'];n=len(cell);live=parents[off:off+n]>=0;off+=n
            raw1+=np.bincount(np.where(cell[live]<0,COUNT,cell[live]),weights=m[live].astype(float)*(1e10/frames(591)[0]),minlength=COUNT+1)
    retain0=np.r_[raw0,0.];retain0[:-1]-=s[:-1];retain1=np.r_[raw1,0.];retain1[:-1]-=d[:-1]
    eps=1e-12*raw0.max();assert min(retain0.min(),retain1.min())>-eps
    retain0=np.maximum(retain0,0);retain1=np.maximum(retain1,0)
    assert abs(retain1.sum()/retain0.sum()-1)<1e-12
    amount=retain0.sum();out=[];floors=[]
    offset=float(records(previous('virial-64-24.csv'))[0]['field_Msun_kpc2_Myr3'])
    for tag in ('inner_radial','outer_radial','clock_outer_minus_inner','virial'):
        K=ks[tag];intercept=offset if tag=='virial' else 0.
        def bounds(f):
            a=s+f*retain0;b=d+f*retain1;base=((1-f)*own-launch)@K[:-1]+intercept
            return [base+extremum(a,b,w,K,mx)@K for mx in (False,True)]
        old=bounds(0.);direction=1 if old[0]>0 else -1 if old[1]<0 else 0
        same=lambda v: v[0]>0 if direction==1 else v[1]<0
        for f in (0.,1e-6,1e-5,1e-4,1e-3,.01,.1,1.):
            low,high=bounds(f);out.append(dict(quantity=tag,released_fraction=f,released_raw_Msun=f*amount,minimum=low,maximum=high))
        gap=max(0.,old[0],-old[1]);span=np.ptp(w[(s+retain0)>0])*np.ptp(K[(d+retain1)>0])
        lower=gap/span if span else 0.;upper=None
        if direction and not same(bounds(1.)):
            lo,hi=0.,1.
            for _ in range(33):
                mid=(lo+hi)/2
                if same(bounds(mid)):lo=mid
                else:hi=mid
            upper=hi*amount
            assert lower<=upper*(1+1e-8)
        floors.append(dict(quantity=tag,original_gap=gap,arbitrary_extra_mass_necessary_Msun=lower,
            uniform_release_sufficient_fraction=hi if upper is not None else '',uniform_release_sufficient_Msun=upper if upper is not None else '',
            all_retained_raw_Msun=amount))
    table(ROOT/'hidden-turnover.csv',out,True);table(ROOT/'turnover-sign-thresholds.csv',floors,True)
if __name__=='__main__':guard();run()
