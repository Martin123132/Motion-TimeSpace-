"""Audit receipts, independent checks, budgets, both nonlinear arms and the limits of the linearization."""
from gas_stage import *
import ast,csv,re
from collections import defaultdict

def run():
    total_http=0;packets=[]
    for snap in (590,591):
        for part in range(4):
            path,receipt=paths(snap,part);old=json.loads(previous(f'inputs/s{snap}-{part}-p0.json').read_bytes())
            facts=json.loads(receipt.read_bytes());assert digest(path)==facts['packet']
            assert facts['identity']==old['identity'] and facts['url']==old['url']
            for key in ('Coordinates','Masses'):assert facts['field_sha256'][key]==old['field_sha256'][key]
            assert facts['total']==sum(facts['counts'])==old['counts'][0]
            total_http+=sum(facts['bytes'].values());packets.append(facts['packet'])
    family=records(ROOT/'family-checks.csv');sums=lambda key:sum(int(r[key]) for r in family)
    assert len(family)==16 and sums('launch')==57075281 and sums('end_gas')==57073835 and sums('births')==1617
    assert sums('exact_gas')+sums('split_gas')+sums('unmapped_gas')==sums('end_gas')
    assert sums('parent_gone')==sums('unmapped_gas')==3339 and sums('unmapped_birth')==sums('partial_parent')==0
    assert sums('multi_child')==171 and sums('ambiguous_roots')==18
    tests=records(ROOT/'transport-lp-controls.csv');assert len(tests)==20 and max(abs(float(r['error'])) for r in tests)<1e-10
    force=records(ROOT/'force-clock-check.csv');assert len(force)==2 and max(abs(float(r['relative_error'])) for r in force)<2e-7
    operator=records(ROOT/'pre-gas-operator.csv');op_err=max(abs(float(r['relative_discrepancy'])) for r in operator)
    waves={};linear_errors={};step_change={}
    channels=('inner_radial','inner_polar','outer_radial','outer_polar','clock_outer_minus_inner')
    for shape,n in ((32,4),(64,8),(64,16),(64,32)):
        rows=records(ROOT/f'combined-wave-{shape}-{n}.csv');assert max(float(r['norm_drift']) for r in rows)<1e-10
        for tag in {r['model'] for r in rows}:
            vals={r['arm']:r for r in rows if r['model']==tag};assert set(vals)=={'reset','coupled','contrast'}
            for ch in channels:assert float(vals['coupled'][ch])-float(vals['reset'][ch])==float(vals['contrast'][ch])
            waves[n,tag]=vals['contrast']
    for r in records(ROOT/'linear-wave-bounds-16.csv'):
        key=r['channel'];lo=float(r['minimum_change']);hi=float(r['maximum_change'])
        measured=[float(waves[16,'wave_'+key+'_'+direction][key])-float(waves[16,'fine_nearby'][key]) for direction in ('min','max')]
        linear_errors[key]=dict(low=lo,high=hi,nonlinear_low_plan=measured[0],nonlinear_high_plan=measured[1],
            max_error_relative_to_width=max(abs(measured[0]-lo),abs(measured[1]-hi))/(hi-lo))
        step_change[key]=abs(float(waves[32,'fine_nearby']['change_'+key])-float(waves[16,'fine_nearby']['change_'+key]))
    live=records(ROOT/'live-clock-curvature.csv');groups=defaultdict(float)
    for row in live:
        if row['phase']!='uncovered':
            value=float(row['clock_curvature_per_Myr2'])
            groups[tuple(int(row[k]) for k in ('steps','angle_order','cap','radial_spread_order'))]+=value
            if row['displacement_eighth']:assert max(abs(float(row[k])/value-1) for k in ('displacement_half','displacement_eighth'))<1e-8
    source=groups[64,4,64,0];curvature_sensitive=max(abs(x/source-1) for x in groups.values())
    assert source<0 and all(x<0 for x in groups.values())
    provider=json.loads((ROOT/'pointer-data.json').read_bytes());assert len(provider)==2 and all(r['count']==71036559 and len(r['array_hash'])==64 and r['bytes']>=4*r['count'] for r in provider)
    ledger=json.loads((ROOT/'catalog-ledger.json').read_bytes())
    with np.load(ROOT/'catalog-recovery.npz') as rec:
        n=len(rec['raw']);assert n==ledger['strict_pairs'] and all(len(np.unique(rec[k]))==n for k in ('native590','native591'))
        assert np.all(rec['raw']>0) and abs(rec['raw'].sum()-ledger['strict_mass_Msun'])<=1e-4
    cat=records(ROOT/'catalog-bounds.csv');assert len(cat)==10
    for row in cat:
        lo,hi,olo,ohi=[float(row[k]) for k in ('minimum','maximum','previous_min','previous_max')]
        pad=max(abs(olo),abs(ohi))*2e-8;assert olo-pad<=lo<=hi+pad and hi<=ohi+pad
    better=records(ROOT/'catalog-recovery.csv');conservative=records(ROOT/'mass-exchange.csv')
    assert abs(float(conservative[0]['raw_exchange_Msun'])-float(better[0]['raw_exchange_Msun'])-ledger['strict_mass_Msun'])<.01
    shifted=records(ROOT/'catalog-wave.csv')
    for n in (16,32):
        for model in ('catalog_nearby','catalog_independent','catalog_ordinary_clock_min','catalog_ordinary_clock_max'):
            rr={r['arm']:r for r in shifted if int(r['count'])==n and r['model']==model}
            assert set(rr)=={'reset','coupled','contrast'} and all(float(r['norm_drift'])<1e-10 for r in rr.values())
            for ch in channels:assert float(rr['coupled'][ch])-float(rr['reset'][ch])==float(rr['contrast'][ch])
    attribution=json.loads((ROOT/'return-attribution.json').read_bytes())
    returned=float(json.loads(prior('identity.json').read_bytes())['matched_raw_loss_Msun'])
    assert abs(returned+attribution['old_star_donors_Msun'])<1e-5
    assert 0<attribution['stellar_return_into_gas_min_Msun']<=attribution['stellar_return_into_gas_max_Msun']<=abs(returned)+1e-5
    assert ledger['births_corroborated']+ledger['unmatched_birth_pointers']==1617
    exceptions=json.loads((ROOT/'birth-pointer-exceptions.json').read_bytes())
    assert len(exceptions)==ledger['unmatched_birth_pointers'] and ledger['births_with_contrary_links']==0
    tightwave=records(ROOT/'catalog-wave-linear.csv')
    assert len(tightwave)==5 and all(0<float(r['surviving_fraction'])<=1.00000001 for r in tightwave)
    clocklinear=next(r for r in tightwave if r['channel']=='clock_outer_minus_inner')
    low=float(clocklinear['minimum_relative_original_nearby']);high=float(clocklinear['maximum_relative_original_nearby'])
    extremedata=records(ROOT/'catalog-wave-clock-extremes.csv');assert len(extremedata)==4
    extreme_err=max(abs(float(r['contrast_relative_original_nearby'])-(low if r['plan']=='min' else high))/(high-low) for r in extremedata if int(r['count'])==16)
    assert all(float(r['norm_drift'])<1e-10 for r in extremedata)
    for p in ROOT.glob('*.py'):ast.parse(p.read_bytes())
    for p in ROOT.glob('*.csv'):
        with p.open(newline='',encoding='utf-8-sig') as stream:
            data=list(csv.reader(stream));assert len(data)>1 and len(set(data[0]))==len(data[0]) and all(len(r)==len(data[0]) for r in data)
    for p in ROOT.glob('*.md'):
        for path in re.findall(r'\]\(([^)\s]+)\)',p.read_text(encoding='utf-8')):
            if '://' not in path:assert (p.parent/path).exists(),path
    assert not list(ROOT.rglob('*.work')) and not list(ROOT.rglob('*.pyc'))
    record('validation.json',dict(predecessor_seal=SEAL,verified_gas_packets=len(set(packets)),gas_range_bytes=total_http,
        pointer_array_sha256=[r['array_hash'] for r in provider],strict_pairs=ledger['strict_pairs'],lp_controls=len(tests),
        maximum_pre_gas_operator_error=op_err,nonlinear_extreme_plan_comparison=linear_errors,
        last_time_refinement_nominal_change=step_change,clock_source_launch_curvature=source,
        largest_clock_curvature_sensitivity=curvature_sensitive,source_dt_Myr=clocks()[1],catalog_nonlinear_rows=len(shifted),
        catalog_clock_extreme_plan_error_over_linear_width=extreme_err,raw_old_star_donor_fraction=attribution['old_star_fraction']))
    if '--seal' in sys.argv:
        for name in ('RESULTS.md','REPLAY.md','DERIVATION.md'):assert (ROOT/name).is_file()
        manifest={p.relative_to(ROOT).as_posix():digest(p) for p in sorted(ROOT.rglob('*')) if p.is_file() and p.name!='seal.json'}
        record('seal.json',manifest);print('sealed',len(manifest),digest(ROOT/'seal.json'))
if __name__=='__main__':guard();run()
