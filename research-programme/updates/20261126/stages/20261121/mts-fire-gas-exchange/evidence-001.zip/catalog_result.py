"""Resolve only mutually corroborated, unique identity triples; preserve the old outer envelope."""
from ancestry import match,hist
from wave_exchange import *
from collections import Counter

def locate(values,index):
    pos=np.minimum(np.searchsorted(index,values),len(index)-1)
    return np.where(index[pos]==values,pos,-1)

def triples(rows):
    return list(zip(rows['id'].tolist(),rows['child'].tolist(),rows['gen'].tolist(),strict=True))

def recover():
    with np.load(ROOT/'pointer-targets.npz') as store:
        left,right=store['a590'],store['a591'];il,ir=store['i590'],store['i591'];risk=store['risk']
    with np.load(ROOT/'pointer-links.npz') as store:
        pl,pr,via=store['left'],store['right'],store['via600']
    assert len(np.unique(via))==len(via) and np.all(np.diff(il)>0) and np.all(np.diff(ir)>0)
    endpoints=np.unique(np.stack((pl,pr),axis=1),axis=0)
    pos=endpoints[(endpoints>=0).all(axis=1)]
    lc=Counter(pos[:,0].tolist());rc=Counter(pos[:,1].tolist())
    incomplete_l=set(endpoints[(endpoints[:,1]<0)&(endpoints[:,0]>=0),0].tolist())
    incomplete_r=set(endpoints[(endpoints[:,0]<0)&(endpoints[:,1]>=0),1].tolist())
    lt,rt=triples(left),triples(right)
    kl,kr=Counter(lt),Counter(rt)
    predicted,depth,bad=match(left,right);assert np.array_equal(risk,bad)
    lpos=locate(pos[:,0],il);rpos=locate(pos[:,1],ir)
    flagl=np.isin(left['id'],risk);flagr=np.isin(right['id'],risk)
    nstars=int(json.loads(prior('identity.json').read_bytes())['count591'])
    birth=ir<nstars;assert int(birth.sum())==1617
    report=Counter();recovered=[];checked=set();wrong=set();safe=set()
    for (raw_l,raw_r),li,ri in zip(pos.tolist(),lpos,rpos,strict=True):
        if ri>=0 and predicted[ri]>=0:
            if il[predicted[ri]]==raw_l:
                safe.add(ri)
                if birth[ri]:checked.add(ri)
            else:
                if birth[ri]:wrong.add(ri)
                report['nonrisk_contrary_endpoint_links']+=1
        if li<0 or ri<0:
            report['links_touching_unselected_counterpart']+=1;continue
        if not (flagl[li] and flagr[ri]):continue
        report['risk_to_risk_distinct_pairs']+=1
        if lt[li]!=rt[ri]:continue
        report['same_risk_triple_pairs']+=1
        if lc[raw_l]!=1 or rc[raw_r]!=1:continue
        report['unique_bidirectional_and_same_triple_pairs']+=1
        if raw_l in incomplete_l or raw_r in incomplete_r:continue
        if kl[lt[li]]!=1 or kr[rt[ri]]!=1:continue
        recovered.append((li,ri))
    pair=np.asarray(recovered,dtype=int).reshape(-1,2);li,ri=pair.T
    assert len(set(li))==len(li)==len(set(ri)) and not np.any(birth[ri])
    factor=1e10/frames(590)[0]
    moved=np.minimum(left['m'][li].astype(float),right['m'][ri].astype(float))*factor
    c0,c1=left['cell'][li],right['cell'][ri];weight=cuts()['fine'];dur=clocks()[1]
    speed=np.linalg.norm(right['xyz'][ri].astype(float)-left['xyz'][li].astype(float),axis=1)*977.79222168/dur
    archive('catalog-recovery.npz',native590=il[li],native591=ir[ri],origin=c0,destination=c1,raw=moved,speed_km_s=speed)
    raw_unknown=left['m'][flagl].astype(float).sum()*factor
    report.update(dict(terminal_witnesses=len(via),distinct_pairs_with_both_present=len(pos),risk_families=len(risk),
        risk_launch=int(flagl.sum()),risk_end=int(flagr.sum()),strict_pairs=len(li),remaining_ambiguous_launch=int(flagl.sum())-len(li),
        strict_mass_Msun=float(moved.sum()),strict_tagged_Msun=float(weight[c0]@moved),
        risk_launch_raw_Msun=raw_unknown,remaining_risk_launch_raw_Msun=raw_unknown-float(left['m'][li].astype(float).sum()*factor),
        unmatched_birth_pointers=1617-len(checked),births_corroborated=len(checked),births_with_contrary_links=len(wrong),
        checked_nonrisk_end=len(safe),eligible_nonrisk_end=int((predicted>=0).sum()),
        risk_native_left_without_positive_pair=int(sum(int(lc[int(v)]==0) for v in il[flagl])),
        risk_native_right_without_positive_pair=int(sum(int(rc[int(v)]==0) for v in ir[flagr])),
        matched_speed_median_km_s=float(np.median(speed)) if len(speed) else None,
        matched_speed_max_km_s=float(np.max(speed)) if len(speed) else None))
    record('catalog-ledger.json',dict(report))
    return c0,c1,moved

def budgets(c0,c1,amount):
    lab=Launch(64);launch,own,s,d,mis,w=inputs('fine')
    sup=s[:-1]-hist(c0,amount);dem=d[:-1]-hist(c1,amount)
    assert min(sup.min(),dem.min())>=-1e-5
    sup,dem,after=normalize(np.maximum(0,sup),np.maximum(0,dem));assert abs(after-mis)<1e-4
    base=np.r_[own+hist(c1,w[c0]*amount)-launch,0.];bounds=[];summary=[];wave=[];fields={}
    before={r['quantity']:r for r in records(ROOT/'observable-bounds.csv')}
    measures=kernel_bank(lab)
    for local,name in ((True,'catalog_nearby'),(False,'catalog_independent')):
        inc,_=allocate(sup,dem,w,local);net=base+inc
        assert abs(net.sum())<1e-2
        fields[name]=potential(lab,net)
        summary.append(dict(model=name,raw_exchange_Msun=float(sup.sum()),tagged_exchange_Msun=float(sup@w),
            extra_raw_sink_Msun=dem[-1],sink_tags=inc[-1],outside_change=net[-2],
            inside_rate_Msun_yr=net[:COUNT].sum()/(clocks()[1]*1e6),**{key:net@kernel for key,kernel in measures.items()}))
    for key,kernel in measures.items():
        lv=extremum(sup,dem,w,kernel,False);hv=extremum(sup,dem,w,kernel,True)
        lo=(base+lv)@kernel;hi=(base+hv)@kernel
        blo,bhi=float(before[key]['minimum']),float(before[key]['maximum'])
        slack=2e-8*max(abs(blo),abs(bhi),1e-40)
        assert blo-slack<=lo<=hi+slack and hi<=bhi+slack,(key,blo,lo,hi,bhi)
        assert all(lo-slack<=r[key]<=hi+slack for r in summary)
        bounds.append(dict(quantity=key,minimum=lo,maximum=hi,previous_min=blo,previous_max=bhi,
            surviving_width_fraction=(hi-lo)/(bhi-blo),nearby=summary[0][key],independent=summary[1][key]))
        if key=='clock_outer_minus_inner':
            fields['catalog_ordinary_clock_min']=potential(lab,base+lv);fields['catalog_ordinary_clock_max']=potential(lab,base+hv)
    table(ROOT/'catalog-recovery.csv',summary,True);table(ROOT/'catalog-bounds.csv',bounds,True)
    start=lab.run.fields[590]
    for count in (16,32):
        controls={r['model']:r for r in records(ROOT/f'combined-wave-64-{count}.csv') if r['arm']=='contrast'}
        for name,field in fields.items():
            guard();states,err=integrate(lab,start,start+field,count);assert err<1e-10
            vals={arm:np.r_[lab.run.gravity(x),clock(lab,x)]*1e-10 for arm,x in states.items()}
            vals['contrast']=vals['coupled']-vals['reset']
            for arm,v in vals.items():
                row=dict(count=count,model=name,arm=arm,norm_drift=err,**dict(zip(ALL,v,strict=True)))
                if arm=='contrast':row.update({'vs_nearby_'+k:u-float(controls['fine_nearby'][k]) for k,u in zip(ALL,v,strict=True)})
                else:row.update({'vs_nearby_'+k:'' for k in ALL})
                wave.append(row)
    table(ROOT/'catalog-wave.csv',wave,True)
if __name__=='__main__':guard();budgets(*recover())
