"""Fixed-position gravitational clock comparison from the same retained open Newtonian Green source."""
from gas_stage import *
from scipy.special import roots_legendre,eval_legendre
from scipy.constants import parsec
from full_force import Readout
from functools import lru_cache

@lru_cache(maxsize=2)
def clock_parts(lab):
    bg=lab.obj.bg;el=lab.run.el;ell=np.arange(0,2*max(bg.orders)+1,2)
    ang,ww=roots_legendre(80);avg=eval_legendre(ell[:,None],(1+ang)/2)*ww/2
    nodes,weights=roots_legendre(30);parts=[]
    for R,rule,sign in zip((6.,8.3),lab.run.rules,(-1.,1.),strict=True):
        target=np.hypot(R,1.5)/bg.length;mu=1.5/np.hypot(R,1.5);s=eval_legendre(ell,mu)
        for inner,idx,act in zip((True,False),rule.indices,rule.actions,strict=True):
            lo=el.left[idx] if inner else np.maximum(target,el.left[idx]);hi=np.minimum(target,el.right[idx]) if inner else el.right[idx]
            r=lo[:,None]+(hi-lo)[:,None]*(nodes+1)/2
            green=(r[:,:,None]/target)**ell/target if inner else (target/r[:,:,None])**ell/r[:,:,None]
            ker=(-sign*1e10*(bg.vel/299792.458)**2*(hi-lo)[:,None,None]*weights[None,:,None]/2*green*s)@avg
            parts.append((idx,act,rule.wave,ker))
    return parts
def clock(lab,state):
    nodes=lab.run.el.nodes(state)
    return sum(np.sum(ker*abs((act@nodes[idx])@wave)**2) for idx,act,wave,ker in clock_parts(lab))
def clock_gradient(lab,state):
    bg=lab.obj.bg;el=lab.run.el;nodes=el.nodes(state)
    acc=np.zeros((len(bg.rad)+2,len(bg.orders)),complex)
    for idx,act,wave,ker in clock_parts(lab):
        val=(act@nodes[idx])@wave
        grad=act.swapaxes(1,2)@(2*(ker*val)@wave.T)
        np.add.at(acc,el.indices[idx].ravel(),grad.reshape(-1,len(bg.orders)))
    out=(acc[1:-1]/bg.sqrt[:,None]).ravel()
    assert abs(np.vdot(out,state).real-2*clock(lab,state))<1e-10*max(abs(clock(lab,state)),1e-7)
    return out

def check_clock():
    lab=Launch(64);n,w=roots_legendre(20);r=7.15+1.15*n;rows=[]
    integrals=dict.fromkeys(lab.initial,0.)
    for p,weight in zip(r,1.15*w,strict=True):
        probe=Readout(lab.run.el,p,30);rad=np.hypot(p,1.5)
        for arm,state in lab.initial.items():
            gr,gt=probe(lab.run.el.nodes(state))*1e-10
            integrals[arm]-=weight*(gr*p/rad+gt*1.5/rad)*1000*parsec/(299792458.**2)
    for arm,state in lab.initial.items():
        direct=clock(lab,state)*1e-10;line=integrals[arm]
        assert abs(direct-line)<2e-7*abs(direct)
        rows.append(dict(arm=arm,direct_fraction=direct,line_integral_fraction=line,relative_error=(direct-line)/direct))
    table(ROOT/'force-clock-check.csv',rows,True)
if __name__=='__main__':check_clock()
