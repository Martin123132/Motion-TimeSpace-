"""Paired nonlinear waves and adjoint of their four Newtonian force contrasts."""
from material_exchange_bounds import *
from wave_response import integrate
from mts_retarded_launch_io import Step,Evolution
from metric_clock import clock,clock_gradient
LABELS=('inner_radial','inner_polar','outer_radial','outer_polar')
ALL=LABELS+('clock_outer_minus_inner',)

def gradient(lab,state,channel):
    run=lab.run;bg=lab.obj.bg;rule=run.rules[channel//2];nodes=run.el.nodes(state)
    acc=np.zeros((len(bg.rad)+2,len(bg.orders)),complex)
    for i,action,ks in zip(rule.indices,rule.actions,rule.kernels,strict=True):
        f=(action@nodes[i])@rule.wave
        grad=action.swapaxes(1,2)@(2*(ks[channel%2]*f)@rule.wave.T)
        np.add.at(acc,run.el.indices[i].ravel(),grad.reshape(-1,len(bg.orders)))
    result=(acc[1:-1]/bg.sqrt[:,None]).ravel()
    val=run.gravity(state)[channel]
    assert abs(np.vdot(result,state).real-2*val)<1e-10*max(abs(val),1e-8)
    return result

def to_mass(lab,force):
    bg=lab.obj.bg;ell=np.arange(0,65,2);rad=bg.rad*bg.length
    p=force@legvander(bg.mu,64)[:,::2];ratio=np.minimum(rad[:,None],jf.RC)/np.maximum(rad[:,None],jf.RC)
    div=1/np.maximum(rad[:,None],jf.RC);moment=np.empty((len(jf.RC),len(ell)))
    ratio2=ratio**2;power=div.copy()
    for j in range(len(ell)):
        moment[:,j]=p[:,j]@power;power*=ratio2
    return (-jf.ls.G/bg.vel**2)*(moment@harmonic(ell).T).ravel()

def kernels(lab,count,ref,pert,with_clock=False):
    start=lab.run.fields[590];dt=clocks()[1]/(lab.obj.unit_myr*count)
    solver=Evolution(lab.obj,dt,lab.initial['reset']);global_k=[];controls=[]
    for arm,init in lab.initial.items():
        current=init.copy();history=[];tan=np.zeros_like(init)
        for i in range(count):
            guard();frac=(i+.5)/count;step=Step(lab,solver,current,start+frac*ref,dt)
            tan=step.forward(tan,lab.obj.multiply(frac*pert,step.mid))
            current=step.right;history.append(step)
        sk=[]
        for j,key in enumerate(ALL if with_clock else LABELS):
            end=gradient(lab,current,j) if j<4 else clock_gradient(lab,current);forward=float(np.vdot(end,tan).real)
            sens=np.zeros_like(ref);back=end
            for it in reversed(range(count)):
                back,du=history[it].backward(back);sens+=((it+.5)/count)*dt*lab.sky_kernel(du,history[it].mid)
            adj=float(np.sum(sens*pert));controls.append(dict(arm=arm,steps=count,channel=key,forward=forward,adjoint=adj,error=adj-forward))
            assert abs(adj-forward)<2e-6*max(abs(forward),1e-8),(j,forward,adj)
            sk.append(sens*1e-10)
        global_k.append(sk)
    return [hi-lo for hi,lo in zip(global_k[1],global_k[0],strict=True)],controls

def build_kernel(count):
    lab=Launch(64);ar=np.load(ROOT/'joint-field-increments.npz')
    ref=ar['fine_nearby'];pert=ar['fine_independent']-ref
    sky,rows=kernels(lab,count,ref,pert,True)
    launch,own,s,d,mis,w=inputs('fine')
    with np.load(ROOT/'reference-change.npz') as a:ref_mass=a['change']
    additions,log=allocate(s,d,w,False);diff=np.r_[own-launch,0.]+additions-ref_mass
    output={};fields={};bounds=[]
    for j,key in enumerate(ALL):
        K=np.r_[to_mass(lab,sky[j]),0.,0.]
        real=float(np.sum(sky[j]*pert));trans=diff@K
        assert abs(real-trans)<3e-6*max(abs(real),1e-26),(real,trans)
        low=extremum(s,d,w,K,False);high=extremum(s,d,w,K,True);base=np.r_[own-launch,0.]-ref_mass
        bounds.append(dict(count=count,channel=key,minimum_change=(base+low)@K,maximum_change=(base+high)@K,
                           independent_change=trans,direct_projection=real,reference_change=0.))
        output[key]=K
        for direction,extra in [('min',low),('max',high)]:
            fields[key+'_'+direction]=potential(lab,np.r_[own-launch,0.]+extra)
    table(ROOT/f'adjoint-checks-{count}.csv',rows,True);table(ROOT/f'linear-wave-bounds-{count}.csv',bounds,True)
    archive(f'wave-mass-kernels-{count}.npz',**output);archive(f'wave-extreme-fields-{count}.npz',**fields)

def run(steps,count,extreme):
    lab=Launch(steps);start=lab.run.fields[590]
    with np.load(ROOT/'joint-field-increments.npz') as a:models={k:a[k] for k in a.files}
    with np.load(prior('endpoint-field-increments.npz')) as a:models['stellar_only']=a['fine_evolved']+a['old_gas']
    if extreme:
        with np.load(ROOT/'wave-extreme-fields-16.npz') as a:models.update({'wave_'+k:a[k] for k in a.files})
    if count>=32:models={k:v for k,v in models.items() if k in ('old','fine_nearby','fine_independent','wave_inner_radial_min','wave_inner_radial_max')}
    rows=[];save={};base={}
    for key,field in models.items():
        guard();states,error=integrate(lab,start,start+field,count);assert error<1e-10
        fs={arm:np.r_[lab.run.gravity(x),clock(lab,x)]*1e-10 for arm,x in states.items()}
        fs['contrast']=fs['coupled']-fs['reset']
        if key=='old':base=fs
        for arm in fs:
            row=dict(steps=steps,count=count,model=key,arm=arm,norm_drift=error,
                    rms_input_kms2=np.sqrt(np.sum(lab.prob*field**2))*lab.obj.bg.vel**2)
            row.update(dict(zip(ALL,fs[arm],strict=True)))
            row.update(dict(zip(('change_'+k for k in ALL),fs[arm]-base[arm],strict=True)));rows.append(row)
        if steps==64 and count==16 and key in ('old','fine_nearby','fine_independent'):
            save.update({key+'_'+arm:x for arm,x in states.items()})
    table(ROOT/f'combined-wave-{steps}-{count}.csv',rows,True)
    if save:archive('joint-waves-591.npz',**save)
    print('wave completed',steps,count,flush=True)
if __name__=='__main__':
    for count in (8,16):guard();build_kernel(count)
    for n,c,ext in ((32,4,False),(64,8,False),(64,16,True),(64,32,True)):run(n,c,ext)
