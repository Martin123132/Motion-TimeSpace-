"""Conservative gas/star allocations and one-observable ranges at fixed mass marginals."""
from gas_stage import *
from material_readouts import grid_kernels,harmonic,legvander,parsec,eval_legendre
from moment_io import Moment

def normalize(s,d):
    assert s.min()>=0 and d.min()>=0
    mismatch=float(s.sum()-d.sum())
    return np.r_[s,max(-mismatch,0.)],np.r_[d,max(mismatch,0.)],mismatch

def layers():
    cell=np.arange(COUNT);ir,im=np.divmod(cell,256)
    for level in range(12):
        shift=2**level
        groups=(ir//shift)*((255//shift)+1)+im//shift
        yield np.r_[groups,groups.max()+1,groups.max()+2]
    yield np.zeros(COUNT+2,int)

def allocate(s,d,w,local):
    s=s.copy();d=d.copy();label=s*w;out=d*0;log=[]
    for level,g in enumerate(layers() if local else (np.zeros_like(s,int),)):
        ds=np.bincount(g,weights=s);rs=np.bincount(g,weights=d);ls=np.bincount(g,weights=label)
        used=np.minimum(ds,rs)
        send=np.divide(used,ds,out=ds*0,where=ds>0)
        recv=np.divide(used,rs,out=rs*0,where=rs>0)
        mean=np.divide(ls,ds,out=ls*0,where=ds>0)
        incoming=d*recv[g]*mean[g]
        out+=incoming
        log.append(dict(level=level,raw_Msun=used.sum(),label_Msun=incoming.sum()))
        s*=1-send[g];d*=1-recv[g];label*=1-send[g]
    assert max(s.sum(),d.sum())<1e-10*max(out.sum(),1.)
    return out,log

def extremum(s,d,w,k,maximize):
    donor=np.flatnonzero(s>0);receiver=np.flatnonzero(d>0)
    donor=donor[np.argsort(w[donor],kind='stable')]
    receiver=receiver[np.argsort(k[receiver],kind='stable')]
    if not maximize:receiver=receiver[::-1]
    sm=s[donor].astype(np.longdouble);dm=d[receiver].astype(np.longdouble)
    ct=np.r_[np.longdouble(0),np.cumsum(sm)];dt=np.cumsum(dm);ws=w[donor]
    assert abs(ct[-1]-dt[-1])<1e-10*ct[-1]
    dt[-1]=ct[-1];ix=np.minimum(np.searchsorted(ct,dt,side='right')-1,len(sm)-1)
    cumulative=np.r_[np.longdouble(0),np.cumsum(sm*ws)]
    z=cumulative[ix]+(dt-ct[ix])*ws[ix]
    out=np.zeros(len(k));out[receiver]=np.diff(np.r_[np.longdouble(0),z])
    assert out.min()>=-1e-8 and abs(out.sum()-s@w)<1e-10*max(s@w,1)
    return out

def inputs(mode,sym=False):
    with np.load(ROOT/'gas-ledger.npz') as gas,np.load(ROOT/'stellar-ledger.npz') as stars:
        w=cuts()[mode];launch=gas[mode+'_launch']+w*stars['launch']
        s=gas['sym_donor' if sym else 'gas_donor']+stars['donor'];d=gas['sym_demand' if sym else 'demand']
        own=gas[mode+('_symkept' if sym else '_kept')]+stars[mode]
        tracer=gas[mode+'_idtracer'];lost=gas[mode+'_untraced']
    return launch,own,*normalize(s,d),np.r_[w,0.]

def newton_kernels():
    ell=np.arange(0,65,2);avg=harmonic(ell)
    out={};clocks_at=[]
    for lab,R in [('inner',6.),('outer',8.3)]:
        r=np.hypot(R,1.5);mu=1.5/r;p=eval_legendre(ell,mu);der=np.zeros_like(p)
        der[1:]=ell[1:]*(eval_legendre(ell[1:]-1,mu)-mu*p[1:])/(1-mu**2)
        base=jf.ls.G*(1e3/parsec)*(np.minimum(jf.RC,r)/np.maximum(jf.RC,r))[:,None]**ell/np.maximum(jf.RC,r)[:,None]/r
        out[lab+'_radial']=(base*np.where(jf.RC[:,None]<r,-(ell+1),ell)*p)@avg.T
        out[lab+'_polar']=(base*(-np.sqrt(1-mu**2)*der))@avg.T
        clocks_at.append((-base*(parsec/1e3)*r/(299792.458**2)*p)@avg.T)
    out['clock_outer_minus_inner']=clocks_at[1]-clocks_at[0]
    return out
def kernel_bank(lab):
    mom=Moment(lab.steps);ker=grid_kernels(mom);dt=clocks()[1]
    return {k:np.r_[v.ravel(),0.,0.] for k,v in dict({k:v/dt for k,v in ker.items()},**newton_kernels()).items()}
def potential(lab,m):
    bg=lab.obj.bg
    hist=m[:COUNT].reshape(len(jf.RC),256)
    return jf.coeffs(hist,bg.rad*bg.length,64)@legvander(bg.mu,64)[:,::2].T/bg.vel**2

def evaluate():
    lab=Launch(64);kernels=kernel_bank(lab);summary=[];extrema=[];inputs_out={};massrows=[];logs=[]
    dt=clocks()[1]
    with np.load(prior('endpoint-field-increments.npz')) as field:inputs_out['old']=field['old_stars']+field['old_gas']
    with np.load(ROOT/'gas-ledger.npz') as gas,np.load(ROOT/'stellar-ledger.npz') as stars:
        with np.load(prior('frozen-weights.npz')) as f:
            assert np.max(abs(gas['raw0'][:COUNT]+stars['launch'][:COUNT]-f['launch']))<1e-10*max(f['launch'])
    for mode,sym in [('fine',False),('coarse',False),('fine',True)]:
        launch,own,s,d,mis,w=inputs(mode,sym)
        total_donor=s@w;stage=mode+('_symmetric' if sym else '')
        for local,tag in [(True,'nearby'),(False,'independent')]:
            addition,log=allocate(s,d,w,local);added=np.r_[own-launch,0.]+addition
            name=stage+'_'+tag
            assert abs(added.sum())<3e-12*launch.sum()
            logs.extend([dict(model=name,**row) for row in log])
            row={k:added@v for k,v in kernels.items()}
            summary.append(dict(model=name,**row))
            massrows.append(dict(model=name,launch_Msun=launch.sum(),retained_Msun=own.sum(),raw_exchange_Msun=s.sum(),
                tagged_exchange_Msun=total_donor,raw_donor_minus_demand_Msun=mis,extra_raw_source_Msun=s[-1],extra_raw_sink_Msun=d[-1],
                added_to_ext_sink_Msun=addition[-1],outside_500_Msun=added[-2],inside_rate_Msun_yr=added[:COUNT].sum()/(dt*1e6)))
            if not sym or local:inputs_out[name]=potential(lab,added)
            if mode=='fine' and not sym and local:archive('reference-change.npz',change=added)
        if mode=='fine' and not sym:
            for key,K in kernels.items():
                base=np.r_[own-launch,0.]@K
                lower=extremum(s,d,w,K,False);upper=extremum(s,d,w,K,True)
                lo=base+lower@K;hi=base+upper@K
                for rr in summary[-2:]:
                    assert lo-1e-11*max(abs(lo),abs(hi))<=rr[key]<=hi+1e-11*max(abs(lo),abs(hi))
                extrema.append(dict(quantity=key,retained=base,minimum=lo,maximum=hi,interval_width=hi-lo,
                    local_value=summary[-2][key],independent_value=summary[-1][key]))
                if key in ('inner_radial','virial'):
                    for labtag,extra in [('min',lower),('max',upper)]:inputs_out[key+'_'+labtag]=potential(lab,np.r_[own-launch,0.]+extra)
    table(ROOT/'source-observables.csv',summary,True);table(ROOT/'mass-exchange.csv',massrows,True)
    table(ROOT/'exchange-levels.csv',logs,True);table(ROOT/'observable-bounds.csv',extrema,True)
    archive('joint-field-increments.npz',**inputs_out)
if __name__=='__main__':guard();evaluate()
