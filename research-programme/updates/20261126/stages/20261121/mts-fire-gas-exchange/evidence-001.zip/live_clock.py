"""First clock feedback from live ordinary matter: shared-stress launch derivative, not a fitted source history."""
from material_exchange_bounds import *
from virial import Radial,green,basis
from scipy.special import roots_legendre
G_C2=jf.ls.G/(299792.458**2)
def testkernel(radius,mu,cap):
    ret=radius*0.+mu*0.
    for R,sign in ((6.,-1.),(8.3,1.)):
        p=np.hypot(R,1.5);coef=eval_legendre(np.arange(cap+1),1.5/p)
        base=np.maximum(p,radius);ratio=np.minimum(p,radius)/base
        old=np.ones_like(mu);now=mu.copy();power=ratio.copy();value=old.copy()
        for l in range(2,cap+1):
            new=((2*l-1)*mu*now-(l-1)*old)/l;old,now=now,new;power=power*ratio
            if not l%2:value+=coef[l]*power*new
        ret-=sign*G_C2*value/base
    return ret

def evaluate(steps,order,cap,rspread,shift=False):
    guard();lab=Launch(steps);bg=lab.obj.bg;box=Radial(lab,16);edge=jf.EDGES
    with np.load(prior('frozen-weights.npz')) as f:
        tp=f['target'].reshape(len(jf.RC),256);star=(f['fine']*f['star_mass']).reshape(tp.shape);actual=(f['fine']*f['launch']).reshape(tp.shape)
    n=np.flatnonzero(np.any(tp>0,axis=1))[-1]+1
    weights=[star[:n],(actual-star)[:n],(tp-actual)[:n]];labels=('stars','gas','uncovered')
    if rspread:
        split=np.unique(np.r_[edge[:n+1],np.hypot([6.,8.3],1.5)]);ix=np.searchsorted(edge,(split[1:]+split[:-1])/2)-1
        nd,wt=roots_legendre(rspread);rad=(split[:-1,None]+(1+nd)*(split[1:]-split[:-1])[:,None]/2).ravel()
        measure=((split[1:]-split[:-1])[:,None]/np.diff(edge)[ix,None]*wt/2).ravel();ir=np.repeat(ix,rspread)
    else:rad=jf.RC[:n];measure=np.ones(n);ir=np.arange(n)
    val,grad,_=green(lab,box,rad/bg.length);gg=bg.length/lab.obj.unit_myr**2
    nodes,ws=roots_legendre(order);mu=(jf.UC[:,None]+np.diff(jf.ANG)[:,None]*nodes/2).ravel()
    sin=np.sqrt(1-mu**2);h,th=basis(box.sell,mu);ell=np.arange(0,cap+1,2)
    pol,der=basis(ell,mu);pol/=np.sqrt(2*ell+1)[:,None];der/=np.sqrt(2*ell+1)[:,None]
    res=np.zeros((3,3))
    for start in range(0,len(rad),48):
        sl=slice(start,min(len(rad),start+48));r=rad[sl,None]
        ar=-gg*(grad[sl,:,0]@h);at=-gg*(val[sl,:,0]@th)/(r/bg.length)
        kr=np.zeros_like(ar);kt=np.zeros_like(at)
        for R,sign in ((6.,-1.),(8.3,1.)):
            p=np.hypot(R,1.5);term=-sign*G_C2*eval_legendre(ell,1.5/p)*(np.minimum(r,p)/np.maximum(r,p))**ell/np.maximum(r,p)
            kr+=(term*np.where(r<p,ell,-(ell+1))/r)@pol
            kt+=term@der/r
        direct=kr*ar+kt*at
        probes=[direct]
        if shift:
            for eps in (.5,.125):
                values=[]
                for s in (-eps,eps):
                    xx=r*sin+s*(ar*sin+at*mu);zz=r*mu+s*(ar*mu-at*sin);rr=np.hypot(xx,zz)
                    values.append(testkernel(rr,abs(zz)/rr,cap))
                probes.append((values[1]-values[0])/(2*eps))
        for i,dp in enumerate(probes):
            av=dp.reshape(len(r),256,order)@(ws/2)
            for j,w in enumerate(weights):res[i,j]+=np.sum(av*w[ir[sl]]*measure[sl,None])
    return [dict(steps=steps,angle_order=order,cap=cap,radial_spread_order=rspread,phase=name,
        clock_curvature_per_Myr2=res[0,j],displacement_half=res[1,j] if shift else '',displacement_eighth=res[2,j] if shift else '') for j,name in enumerate(labels)]
if __name__=='__main__':
    rows=[]
    for n,o,cap,spread,shift in ((64,4,64,0,True),(64,8,64,0,False),(64,4,48,0,False),(64,4,80,0,False),(64,4,64,2,False),(64,4,64,4,False),(32,4,64,0,False)):
        rows+=evaluate(n,o,cap,spread,shift)
    table(ROOT/'live-clock-curvature.csv',rows,True)
