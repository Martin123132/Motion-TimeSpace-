"""Freeze independent generator checks on the earlier stellar comparison before using gas changes."""
from wave_exchange import *
def run():
    lab=Launch(64);bg=lab.obj.bg;start=lab.run.fields[590]
    with np.load(prior('endpoint-field-increments.npz')) as a:ref=a['old_stars']+a['old_gas'];pert=a['fine_evolved']-a['old_stars']
    count=4;sky,control=kernels(lab,count,ref,pert)
    trial=np.zeros((len(jf.RC),len(jf.UC)));trial[1100:1350:9,::27]=1.6e6;trial[830:1160:11,7::31]=-1.2e6
    vf=potential(lab,trial.ravel())
    results=[]
    for tag,drive in [('stellar',pert),('independent',vf)]:
        half=.2
        values=[]
        for sign in (-1,1):
            st,_=integrate(lab,start,start+ref+sign*half*drive,count)
            values.append((lab.run.gravity(st['coupled'])-lab.run.gravity(st['reset']))*1e-10)
        for j,which in enumerate(LABELS):
            pred=np.sum(sky[j]*drive);actual=(values[1][j]-values[0][j])/(2*half)
            transpose=to_mass(lab,sky[j])@trial.ravel() if tag=='independent' else pred
            assert abs(pred-transpose)<2e-8*max(abs(pred),1e-27)
            results.append(dict(test=tag,channel=which,analytic=pred,finite_difference=actual,relative_discrepancy=(pred-actual)/max(abs(pred),1e-30),mass_projection=transpose))
    table(ROOT/'pre-gas-operator.csv',results,True);table(ROOT/'pre-gas-duality.csv',control,True)
    print('maximum central difference',max(abs(x['relative_discrepancy']) for x in results))
if __name__=='__main__':run()
