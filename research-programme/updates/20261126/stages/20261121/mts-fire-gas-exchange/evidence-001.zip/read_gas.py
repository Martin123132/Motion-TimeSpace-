"""Read each physical HDF chunk range once per requested field; save low-ID shards for bounded joins."""
from gas_stage import *
import time,datetime

def collect(s,p,deadline):
    path,receipt=paths(s,p);path.parent.mkdir(exist_ok=True);guard()
    if receipt.exists():
        assert digest(path)==json.loads(receipt.read_bytes())['packet'];return
    assert not path.exists() and not path.with_suffix('.work').exists()
    old=json.loads(previous(f'inputs/s{s}-{p}-p0.json').read_bytes());n=old['counts'][0];bank=np.empty(n,dtype)
    sizes={};hashes={};hub,a,centre,_,_=frames(s);axis=frames(600)[4][-1]
    for name,key in [('ParticleIDs','id'),('ParticleChildIDsNumber','child'),('ParticleIDGenerationNumber','gen'),('Masses','m'),('Coordinates','xyz')]:
        guard();assert time.time()<deadline
        remote=source.Remote(old['url'],65536)
        try:
            assert list(remote.id)==old['identity']
            with source.h5py.File(remote,'r') as h:
                d=h['PartType0/'+name];assert len(d)==n
                spans=[];d.id.chunk_iter(lambda ch:spans.append((ch.byte_offset,ch.byte_offset+ch.size)))
                runs=[]
                for left,right in sorted(spans):
                    if runs and left<=runs[-1][1]+32768:runs[-1][1]=max(runs[-1][1],right)
                    else:runs.append([left,right])
                assert sum(b-a for a,b in runs)<445_000_000
                for left,right in runs:
                    guard();buf=bytearray(right-left)
                    for pos in range(left,right,8*1024**2):
                        assert time.time()<deadline
                        count=min(8*1024**2,right-pos);buf[pos-left:pos-left+count]=remote.range(pos,count)
                    remote.spans.append((left,buf))
                hs=hashlib.sha256()
                for start in range(0,n,250000):
                    sl=slice(start,min(start+250000,n));x=d[sl];hs.update(memoryview(np.ascontiguousarray(x)))
                    if key=='xyz':
                        box=old['header']['BoxSize'];delta=x-hub*centre
                        xyz=(delta-box*np.rint(delta/box))*(a/hub);bank['xyz'][sl]=xyz
                        r=np.sqrt(np.einsum('ij,ij->i',xyz,xyz));mu=np.clip(abs(xyz@axis)/np.maximum(r,1e-80),0,1)
                        rid=np.searchsorted(jf.EDGES,r,side='right')-1;aid=np.minimum((mu*256).astype(int),255)
                        bank['cell'][sl]=np.where(r<500,256*rid+aid,COUNT)
                    else:
                        if key=='m':assert x.min()>0 and np.isfinite(x).all() and x.dtype==np.float32
                        else:assert x.min()>=0 and x.max()<=(255 if key=='gen' else 2**32-1)
                        bank[key][sl]=x
                hashes[name]=hs.hexdigest()
                if name in old['field_sha256']:assert hashes[name]==old['field_sha256'][name]
            sizes[name]=remote.transferred
        finally:remote.close()
    shard=bank['id']%PARTS;indices=np.argsort(shard,kind='stable');counts=np.bincount(shard,minlength=PARTS)
    offsets=np.r_[0,np.cumsum(counts)]
    assert offsets[-1]==n
    import zipfile
    with zipfile.ZipFile(path.with_suffix('.work'),'x',compression=zipfile.ZIP_DEFLATED,compresslevel=1,allowZip64=True) as z:
        for k in range(PARTS):
            with z.open(f'b{k}.npy','w',force_zip64=True) as stream:np.lib.format.write_array(stream,bank[indices[offsets[k]:offsets[k+1]]],allow_pickle=False)
    path.with_suffix('.work').rename(path)
    record(str(receipt.relative_to(ROOT)),dict(snap=s,part=p,counts=counts.tolist(),total=n,whole=old['whole'][0],url=old['url'],
            identity=old['identity'],field_sha256=hashes,bytes=sizes,packet=digest(path)))
    print(s,p,n,'cells;',sum(sizes.values()),'bytes',flush=True)
if __name__=='__main__':
    deadline=datetime.datetime.fromisoformat(sys.argv[1]).timestamp();assert time.time()<deadline<time.time()+14400
    for s in (590,591):
        for p in range(4):collect(s,p,deadline)
