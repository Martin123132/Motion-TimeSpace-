from ancestry import *
from material_exchange_bounds import extremum,allocate
from scipy.optimize import linprog

def run():
    def members(keys):
        arr=np.zeros(len(keys),dtype)
        for i,(rid,child,gen) in enumerate(keys):arr[i]['id']=rid;arr[i]['child']=child;arr[i]['gen']=gen
        return arr
    a=members([(19,0,0),(31,1,1),(31,0,1),(101,0,0),(201,0,30),(77,0,0)])
    b=members([(31,0,2),(19,0,0),(31,2,2),(31,1,1),(201,0,30),(40,0,0),(77,0,2),(77,2,2),(77,1,1)])
    idx,gap,bad=match(a,b)
    assert idx.tolist()==[2,0,2,1,-1,-1,5,5,5] and gap.tolist()==[1,0,1,0,0,0,2,2,1] and list(bad)==[201]
    c=members([(9,0,0),(9,0,1),(11,5,1)]);d=members([(9,0,2),(11,0,0)])
    assert np.all(match(c,d)[0]<0)
    rng=np.random.default_rng(671912);rows=[]
    for trial in range(10):
        s=rng.integers(1,12,6).astype(float);d=rng.integers(1,10,7).astype(float);d*=s.sum()/d.sum()
        w=rng.integers(0,15,6)/3;k=rng.normal(size=7);ns=len(s);nd=len(d)
        T=np.r_[np.repeat(np.eye(ns),nd,axis=1),np.tile(np.eye(nd),(1,ns))]
        for mx in (True,False):
            actual=extremum(s,d,w,k,mx);cost=np.outer(w,k).ravel();flag=-1 if mx else 1
            exact=linprog(flag*cost,A_eq=T,b_eq=np.r_[s,d],bounds=(0,None),method='highs')
            assert exact.success and abs(exact.fun*flag-actual@k)<1e-10
            rows.append(dict(trial=trial,maximize=mx,assignment=actual@k,independent_lp=flag*exact.fun,error=actual@k-flag*exact.fun))
    table(ROOT/'transport-lp-controls.csv',rows,True)
if __name__=='__main__':run()
