"""Bounds with explicit locality, outside-grid tails and surplus assumptions."""
from material_exchange_bounds import *
def grouped_range(s,d,w,ker):
    supply=s.copy();demand=d.copy();n=len(s);result={k:np.zeros(2) for k in ker};rows=[]
    for lev,g in enumerate(layers()):
        ds=np.bincount(g,weights=supply);rs=np.bincount(g,weights=demand);matched=np.minimum(ds,rs)
        send=supply*np.divide(matched,ds,out=np.zeros_like(ds),where=ds>0)[g]
        recv=demand*np.divide(matched,rs,out=np.zeros_like(rs),where=rs>0)[g]
        active=np.flatnonzero((send>0)|(recv>0));order=active[np.argsort(g[active],kind='stable')]
        split=np.r_[0,np.flatnonzero(np.diff(g[order]))+1,len(order)]
        simple=lev==0
        for key,K in ker.items():
            if simple:
                value=(w*send)@K
                result[key]+=value
            else:
                for lo,hi in zip(split[:-1],split[1:],strict=True):
                    ix=order[lo:hi]
                    if not len(ix):continue
                    sp=send[ix];rp=recv[ix];wp=w[ix];kp=K[ix]
                    if np.count_nonzero(sp)==1:
                        value=(wp[sp>0][0])*(rp@kp);result[key]+=value
                    elif np.count_nonzero(rp)==1:
                        value=(sp@wp)*kp[rp>0][0];result[key]+=value
                    else:
                        for j,maximize in enumerate((False,True)):result[key][j]+=extremum(sp,rp,wp,kp,maximize)@kp
        supply=np.maximum(0,supply-send);demand=np.maximum(0,demand-recv)
        unavoidable=.5*np.sum(np.abs(np.bincount(g,weights=s)-np.bincount(g,weights=d)))
        assert abs(unavoidable-supply.sum())<1e-10*s.sum(),(lev,unavoidable,supply.sum())
        rows.append(dict(level=lev,paired_raw_Msun=send.sum(),remaining_raw_Msun=supply.sum(),
                         min_raw_crossing_mass_Msun=unavoidable,remaining_fraction=supply.sum()/s.sum()))
    return result,rows

def run():
    lab=Launch(64);ker=kernel_bank(lab)
    source_bounds=records(ROOT/'observable-bounds.csv')
    with np.load(ROOT/'wave-mass-kernels-16.npz') as a:wker={'wave_'+k:a[k] for k in a.files}
    with np.load(ROOT/'reference-change.npz') as a:ref=a['change']
    launch,own,s,d,mis,w=inputs('fine');base=np.r_[own-launch,0.]
    # Linearized wave kernels refer to differences about the nearby plan.
    subset={k:ker[k] for k in ('virial','inner_radial','clock_outer_minus_inner')}
    subset.update({k:wker[k] for k in ('wave_inner_radial','wave_clock_outer_minus_inner')})
    local,levels=grouped_range(s,d,w,subset);table(ROOT/'unavoidable-crossings.csv',levels,True)
    near,_=allocate(s,d,w,True);rows=[];maximum_tag=w[s>0].max();dt=clocks()[1];rshell=np.hypot(8.3,1.5)
    outer_limit=min(w.max()*d[-2],s@w)+max(0,own[-1]-launch[-1])
    tail_acc=outer_limit*jf.ls.G*(1e3/parsec)/(500-rshell)**2
    cbase=float(records(previous('virial-64-24.csv'))[0]['field_Msun_kpc2_Myr3'])
    for key,K in subset.items():
        pivot=base-(ref if key.startswith('wave_') else 0)
        lo=extremum(s,d,w,K,False);hi=extremum(s,d,w,K,True)
        small,big=local[key]+pivot@K
        full_lo=(pivot+lo)@K;full_hi=(pivot+hi)@K;nom=(pivot+near)@K
        span=(full_hi-full_lo);eps=1e-9*max(span,abs(full_lo),abs(full_hi),1e-35)
        assert full_lo-eps<=small<=nom+eps and nom-eps<=big<=full_hi+eps,(key,full_lo,small,nom,big,full_hi)
        offset=cbase if key=='virial' else 0.
        row=dict(observable=key,minimum=full_lo,maximum=full_hi,nearby=nom,
            nested_minimum=small,nested_maximum=big,kept_width_fraction=(big-small)/span if span else 0.,
            field_offset=offset,minimum_with_offset=full_lo+offset,maximum_with_offset=full_hi+offset,
            unlabelled_source_bound=s[-1]*w.max()*np.max(abs(K)),
            tail_bound=tail_acc if key=='inner_radial' else tail_acc*(2.3*1000*parsec)/(299792458.**2) if key=='clock_outer_minus_inner' else
            outer_limit/dt*5.995e-10 if key=='virial' else '')
        rows.append(row)
    table(ROOT/'exchange-widths.csv',rows,True)
    record('exterior-budget.json',dict(raw_extra_source=s[-1],raw_extra_sink=d[-1],raw_outside_demand=d[-2],
            max_tagged_outside_change=outer_limit,maximum_donor_weight=maximum_tag,
            acceleration_tail_bound_m_s2=tail_acc,clock_difference_tail_bound=tail_acc*(2.3*1000*parsec)/(299792458.**2)))
if __name__=='__main__':guard();run()
