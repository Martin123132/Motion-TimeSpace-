"""Offline regeneration, independent massive-potential and crossed-response checks."""
import json
import re
import sys
import numpy as np
import mpmath as mp
from transfer import (HERE,ROOT,LP2,KEYS,constants,digest,diff_weight,kernels,run,write)
import vertices, controls, crossed, portal_transfer as portal


def inputs():
    pins={
        "MTS-ROLLING-BACKGROUND-TWO-PHOTON-MATCH.md":"2eafaa1623a99d7a40583ce392649911eb1aa3001fd87b6a76309472fd1d564b",
        "MTS-EM-TWO-PHOTON-MOTION-PAIR.md":"175724a7417d5b2f14eba1cfc66b1532ed3578ad89bbd2e9af346352c7eea67e",
        "MTS-HEAVY-BATH-COUNTERFLOW-AND-GALACTIC-STRESS.md":"d78faf07c70739eee12ec1dd72731ccfe2d91c83c094b2bcfe8b21cf4038b6bc",
        "mts-transverse-scale-transfer-20261121/matched-vector.json":"ef642cbe75a58e097df7f1b9a116aa870e35a835f46aa3b8bbbd496cd7ea69c5",
        "mts-binary-polarization-rays-20261121/conjunction-forecasts.csv":"0ab24386ccda0820d3bfb438cb7e4e692a1f498991d81cb8dc81e3992ac74235",
        "4947-Y5-R2FR-local-GR-Newton-Maxwell-calibration-count-and-universal-source-residue-certificate.md":"0b71f50c85ab4c5761755aa11544910a1a1e4fcacc901236432705a5ba36563f",
        "5197-Y5-R2FR-universal-gap-cross-arena-compatibility-and-route-separation-theorem.md":"f01f94465168758886800556f345e370910f6913e80f1a4a0c646bbe7abe0c0a",
        "5183-Y5-R2FR-Wick-sign-consistent-static-pair-response-and-5182-supersession.md":"c8aafba0a982c957d844b0db4165d46c30236d62296c38d4eb7d8e34fc25cc36"}
    for name,sha in pins.items():
        assert digest(ROOT/name)==sha
    assert abs(np.sqrt(LP2)/constants.physical_constants["Planck length"][0]-1)<2e-7
    assert abs(portal.MASS_FAST/9.585761787277403e-25-1)<1e-15


def panel_tests(output):
    for row in output:
        if row["force"]<=0 or not 0<row["bending"]<.75*row["force"]:
            raise ValueError(row)
    for val in (1e-11,.0019,.0021,.99):
        with mp.workdps(90):
            arg=mp.mpf(val)
            independent=float(arg**2/2*(mp.besselk(2,arg)-4*mp.besselk(2,2*arg)))
        assert abs(diff_weight(np.array([val]))[0]/independent-1)<3e-10
    for first,second,cap in ((4.5,6.,4.),(5.,12.,16.),(10.,30.,64.)):
        alt=portal.normalized_d(np.sqrt(np.array([first,second])),1.,cap,80)
        assert abs((alt[1]-alt[0])/crossed.difference(first,second,cap)-1)<1e-8
    for val in (1e-4,.08,.25):
        with mp.workdps(45):
            exact=float(mp.quad(lambda cut:(1-1/cut)**3/(cut+val),[1,3,30]))
        assert abs(portal.log_integral(np.array([val]),1.,30.)[0]/exact-1)<1e-12
    nodes,aw=portal.roots_legendre(36)
    sample=(1+nodes)/2
    coeff=portal.normalized_d(sample,0.,1.,64)
    small_cap=3e-15*portal.WITNESS/portal.HC
    with mp.workdps(85):
        def weighted(cap):
            amounts=[]
            for val,quadw in zip(sample,aw):
                arg=mp.mpf(cap)*float(val)
                amounts.append(float(quadw*val**3)*arg**2*(mp.besselk(2,arg)-4*mp.besselk(2,2*arg))/2)
            return mp.fsum(w*float(c) for w,c in zip(amounts,coeff))/mp.fsum(amounts)
        exact=float(weighted(2*small_cap)-weighted(small_cap))
    assert abs(portal.short_contrast(0.,small_cap,48)/exact-1)<1e-9


def main():
    assert not sys.flags.optimize
    inputs()
    shapes,examples=run()
    angular=vertices.check()
    external=controls.spatial_checks()
    controls.analytic()
    panel_tests(shapes)
    density=controls.partial_density()
    cross=crossed.controls()
    joined=portal.run()
    refined=portal.run(order=64)
    worst=max(abs(row[k]/other[k]-1) for row,other in zip(joined,refined) for k in
              ("window_average_difference_per_eta_lambda","window_D_per_eta_lambda_eV4"))
    assert worst<1e-7
    for row in joined:
        if row["near_m"]==.1:
            assert abs(row["window_average_difference_per_eta_lambda"]/row["massless_scaling_limit"]-1)<.0002
    assert 0.<joined[0]["window_average_difference_per_eta_lambda"]<1e-22
    for row in examples:
        assert 0<row["fractional_bending"]<row["fractional_force"]
        assert abs(row["fractional_bending"]/row["fractional_force"]-1-
                   row["lens_over_dynamical_mass_shift"]/row["fractional_force"])<1e-14
    write("angular-projections.csv",angular)
    write("massive-transfer.csv",shapes)
    write("retained-examples.csv",examples)
    write("independent-controls.csv",external)
    write("crossed-cut.csv",cross)
    write("intrinsic-screen.csv",joined)
    stats=dict(input_files=8,helicity_fixtures=len(angular),spectral_relative=density,
               max_published_potential_relative=max(abs(r["Newton_external"]) for r in external),
               max_screen_Hessian_relative=max(abs(r["tidal_Hessian"]) for r in external),
               max_portal_refinement_relative=worst,shape_rows=len(shapes),scale_rows=len(examples),
               intrinsic_rows=len(joined),crossed_rows=len(cross),planck_length_squared_m2=LP2)
    (HERE/"checks.json").write_bytes((json.dumps(stats,indent=2)+"\n").encode())
    for doc in HERE.glob("*.md"):
        for link in re.findall(r"\]\(([^\s)]+)\)",doc.read_text(encoding="utf8")):
            assert link.startswith("https://") or (HERE/link).is_file(),(doc,link)
    manifest={p.name:digest(p) for p in sorted(HERE.iterdir()) if p.is_file() and p.name!="seal.json"}
    seal=HERE/"seal.json"
    if sys.argv[1:]==["--seal"]:
        with seal.open("x",encoding="utf8",newline="\n") as dest:
            dest.write(json.dumps(manifest,indent=2)+"\n")
    elif sys.argv[1:]==["--preview"]:
        assert not seal.exists()
    else:
        assert not sys.argv[1:] and manifest==json.loads(seal.read_bytes())
    print(len(manifest),digest(seal) if seal.exists() else "preview",stats)


if __name__=="__main__":
    main()
