"""Isolate the eta*lambda contact monomial in the crossed photon-scalar unitarity cut."""
import numpy as np
from scipy.integrate import quad
from scipy.special import roots_legendre
from vertices import METRIC, dot


def born_cm(invariant,helicity,angle,mass=1.):
    energy=np.sqrt(invariant)
    momentum=(invariant-mass**2)/(2*energy)
    scalar_energy=energy-momentum
    sine=np.sqrt(1-angle**2)
    kin=momentum*np.array([1.,0.,0.,1.])
    kout=-momentum*np.array([1.,sine,0.,angle])
    pol=np.array([0,1,1j,0])/np.sqrt(2)
    other=np.array([0,angle,-helicity*1j,-sine])/np.sqrt(2)
    left=-np.array([scalar_energy,0,0,-momentum])
    right=np.array([scalar_energy,-momentum*sine,0,-momentum*angle])
    first=np.outer(kin,pol)-np.outer(pol,kin)
    second=np.outer(kout,other)-np.outer(other,kout)
    prod=np.sum((METRIC@first@METRIC)*second)
    stress=-first@METRIC@second.T
    stress=stress+stress.T+METRIC*prod/2
    return prod.real/2,((METRIC@left)@stress@(METRIC@right)).real


def discontinuity_checks():
    for invariant in (1.15,2.,5.,23.):
        mom2=(invariant-1)**2/(4*invariant)
        phase=1-1/invariant
        for angle in (-.73,.2,.92):
            flip,noflip=born_cm(invariant,-1,angle)
            assert abs(flip/(-mom2*(1-angle))-1)<2e-13 and abs(noflip)<1e-12
            flip0,non=born_cm(invariant,1,angle)
            assert abs(non/(invariant*mom2*(1+angle))-1)<1e-13 and abs(flip0)<1e-13
            for eta,lam in ((0.,3.),(-2.,0.),(.31,-1.1)):
                tree=mom2/(24*np.pi)*np.array([[lam*invariant,-eta],[-eta,lam*invariant]])
                disc=48*np.pi*(1-angle)/2*phase*(tree@tree)[0,1]/flip
                expect=eta*lam*(invariant-1)**3/(48*np.pi*invariant)
                assert abs(disc-expect)<1e-13*max(1,abs(expect))


def legendre_kernel(cut,pair):
    half=pair*np.sqrt(1-4/pair)/2
    offset=cut-1+pair/2
    ratio=half/offset
    if ratio<.35:
        return sum(15*(idx+1)/((2*idx+3)*(2*idx+5))*ratio**(2*idx)
                   for idx in range(19))/offset**3
    inv=1/ratio
    second=(3*inv**2-1)*np.arctanh(ratio)/2-3*inv/2
    return 7.5*second/half**3


def difference(pair1,pair2,cutoff):
    def integrand(cut):
        return (cut-1)**3/cut*(legendre_kernel(cut,pair2)-legendre_kernel(cut,pair1))
    return quad(integrand,1.,cutoff,epsabs=1e-12,epsrel=1e-11)[0]/(48*np.pi**2)


def direct(pair,cutoff,sub):
    grid,weights=roots_legendre(56)
    half=pair*np.sqrt(1-4/pair)/2
    cross1=1-pair/2+half*grid;cross2=1-pair/2-half*grid
    def scalar(value):
        return sub[0]+value*sub[1]+value**2*sub[2]+value**3/(48*np.pi**2)*quad(
            lambda cut:(cut-1)**3/(cut**4*(cut-value)),1.,cutoff,epsabs=1e-14,epsrel=1e-11)[0]
    vals=np.array([scalar(left)+scalar(right) for left,right in zip(cross1,cross2)])
    return 15/(4*half**2)*(weights/2)@((3*grid**2-1)/2*vals)


def controls():
    discontinuity_checks()
    rows=[]
    for first,second in ((4.5,6.),(5.,12.),(10.,30.)):
        for cap in (4.,16.,64.):
            val=difference(first,second,cap)
            independent=direct(second,cap,(0.,0.,0.))-direct(first,cap,(0.,0.,0.))
            shifted=direct(second,cap,(.13,-.23,.083))-direct(first,cap,(.13,-.23,.083))
            assert val<0 and max(abs(independent/val-1),abs(shifted/val-1))<1e-7
            rows.append(dict(s1_over_m2=first,s2_over_m2=second,crossed_cap_over_m2=cap,
                delta_B_per_eta_lambda=val,direct=independent,shifted_subtractions=shifted))
    return rows


if __name__=="__main__":
    print(controls()[4])

