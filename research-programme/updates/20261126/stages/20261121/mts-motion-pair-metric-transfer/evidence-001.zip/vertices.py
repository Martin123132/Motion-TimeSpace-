"""Independent covariant angular projections; metric signature (+---)."""
import numpy as np
from scipy.special import roots_legendre
from transfer import write

METRIC=np.diag([1.,-1.,-1.,-1.])
ETENSOR=np.diag([-1.,-1.,2.])/np.sqrt(6.)
def dot(first,second):
    return first@METRIC@second


def weyl(perturb,momentum):
    cov=METRIC@momentum
    riemann=(-np.einsum("b,c,ad->abcd",cov,cov,perturb)-np.einsum("a,d,bc->abcd",cov,cov,perturb)
             +np.einsum("a,c,bd->abcd",cov,cov,perturb)+np.einsum("b,d,ac->abcd",cov,cov,perturb))/2
    ricci=np.einsum("ac,abcd->bd",METRIC,riemann)
    def cross(left,right):
        return np.einsum("ac,bd->abcd",left,right)-np.einsum("ad,bc->abcd",left,right)
    scalar=np.sum(METRIC*ricci)
    return riemann-(cross(METRIC,ricci)+cross(ricci,METRIC))/2+scalar*cross(METRIC,METRIC)/6


def input_state(energy,beta,angle,az,helicity,gauge=0.):
    beam=energy/2
    kin=beam*np.array([1.,0.,0.,1.]); other=beam*np.array([1.,0.,0.,-1.])
    first=np.array([0,1,1j,0])/np.sqrt(2)+gauge*kin
    second=np.array([0,1,-helicity*1j,0])/np.sqrt(2)-.7*gauge*other
    direction=np.array([np.sqrt(1-angle**2)*np.cos(az),np.sqrt(1-angle**2)*np.sin(az),angle])
    out=beam*np.r_[1.,beta*direction]
    back=beam*np.r_[1.,-beta*direction]
    return kin,other,first,second,out,back


def tensors(energy,beta,angle,az,helicity,gauge=0.):
    kin,other,first,second,out,back=input_state(energy,beta,angle,az,helicity,gauge)
    squared=energy**2
    total=kin+other
    strength=lambda moment,pol:np.outer(moment,pol)-np.outer(pol,moment)
    field1,field2=strength(kin,first),strength(other,second)
    prod=np.sum((METRIC@field1@METRIC)*field2)
    one=-field1@METRIC@field2.T
    minimal=one+one.T+METRIC*prod/2
    matter=-np.outer(out,back)-np.outer(back,out)+METRIC*squared/2
    assert np.max(abs((METRIC@total)@matter))<1e-12 and np.max(abs((METRIC@total)@minimal))<1e-12
    trace=np.sum(METRIC*matter)
    response=2*(METRIC@matter@METRIC-METRIC*trace/2)/squared
    curvature=2*np.einsum("abcd,ab,cd",weyl(response,total),field1,field2)
    minimal_exchange=np.sum(response*minimal)/2
    direct=(METRIC@out)@minimal@(METRIC@back)
    terms=[]
    for outgoing in (out,back):
        virtual=kin-outgoing
        vertex1=dot(kin,virtual)*first-dot(first,virtual)*kin
        vertex2=dot(other,virtual)*second-dot(second,virtual)*other
        terms.append(-dot(vertex1,vertex2)/dot(virtual,virtual))
    corr=prod*((dot(out,kin)*dot(back,other)+dot(out,other)*dot(back,kin)))
    return np.array([prod/2,direct,minimal_exchange,curvature,*terms,corr])


def check():
    nodes,aw=roots_legendre(28)
    pol=(3*nodes**2-1)/2
    rows=[]
    for energy,beta in ((.7,.23),(1.,.72),(1.4,.94)):
        for helicity in (1,-1):
            blocks=np.array([tensors(energy,beta,angle,.29,helicity) for angle in nodes])
            gauge=np.array([tensors(energy,beta,angle,.29,helicity,.38) for angle in nodes])
            rotated=np.array([tensors(energy,beta,angle,1.17,helicity) for angle in nodes])
            assert np.max(abs(abs(blocks)-abs(rotated)))<4e-14
            assert np.max(abs(blocks-gauge))<4e-14
            moment=(5*aw/2*pol)@blocks
            if helicity==1:
                assert np.max(abs(blocks[:,1:3]))<1e-13
                assert max(abs(moment[[0,1,2,4,5]]))<1e-13
                assert max(abs(blocks[:,4:6]-energy**2/4).flat)<1e-13
                coeff=energy**4*beta**2/3
                assert abs(abs(moment[3])/coeff-1)<1e-12
                assert max(abs(blocks[:,3]-moment[3]*pol))<1e-13
                assert abs(abs(moment[6])/(energy**6*beta**2/12)-1)<2e-12
            else:
                assert max(abs(blocks[:,[0,3,6]]).flat)<1e-13
                assert max(abs(blocks[:,1]))>.001
            rows.append(dict(W=energy,beta=beta,helicity_product=helicity,
                        max_portal= max(abs(blocks[:,0])),max_stress=max(abs(blocks[:,1])),
                        max_einstein=max(abs(blocks[:,2])),max_curvature=max(abs(blocks[:,3])),
                        equal_D_portal=abs(moment[0]) if helicity==1 else "",
                        equal_D_curvature=moment[3].real if helicity==1 else "",
                        equal_D_dimension10=moment[6].real if helicity==1 else "",
                        max_ward_change=np.max(abs(blocks-gauge))))
    return rows


if __name__=="__main__":
    rows=check()
    write("angular-projections.csv",rows)
    print(rows[0])
