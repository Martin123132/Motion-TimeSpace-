"""Finite-window eta*lambda cut in the same ray readout; no value assigned to either coupling."""
import numpy as np
from scipy.special import roots_legendre
from transfer import HC,WITNESS,MASS_FAST,MASS_LIGHT,diff_weight


def log_integral(spacelike,mass2,limit):
    if mass2==0:
        return np.log1p(limit/spacelike)
    ratio=spacelike/mass2
    high=limit/mass2
    out=np.empty_like(ratio)
    small=ratio<.22
    if np.any(small):
        indices=np.arange(4)
        coeff=np.array([1.,-3.,3.,-1.])
        def moment(degree):
            if degree==0:
                return np.log(high)+coeff[1:]@((1-high**(-indices[1:]))/indices[1:])
            return coeff@((1-high**(-degree-indices))/(degree+indices))
        out[small]=sum((-ratio[small])**step*moment(step) for step in range(24))
    large=ratio[~small]
    base=np.log1p((high-1)/(1+large))
    term1=(np.log(high)-base)/large
    term2=(1-1/high-term1)/large
    term3=((1-1/high**2)/2-term2)/large
    out[~small]=base-3*term1+3*term2-term3
    return out


def normalized_d(energy,mass2,limit,order):
    nodes,aw=roots_legendre(order)
    angle=1-((1+nodes)/2)**2
    weights=aw*(1+nodes)/2
    squared=energy**2
    speed=np.sqrt(1-4*mass2/squared)
    center=squared/2-mass2
    spread=squared*speed/2
    near=center[:,None]-spread[:,None]*angle
    far=center[:,None]+spread[:,None]*angle
    def amplitude(val):
        return val**2*log_integral(val,mass2,limit)
    moments=(amplitude(near)+amplitude(far)-2*amplitude(center)[:,None])@(weights*(3*angle**2-1)/2)
    return 15*moments/(48*np.pi**2*squared**2*speed**2)


def ray(opening,cap,order=40):
    low=opening
    high=min(cap,low+110)
    levels=np.unique(np.r_[low,low+np.array([.003,.1,1,4,12,45]),high])
    nodes,aw=roots_legendre(order)
    coord=(1+nodes)/2
    interval=levels[(levels>=low)&(levels<=high)]
    integ=weighted=0.
    for start,stop in zip(interval,interval[1:]):
        energy=start+(stop-start)*coord**2
        weights=aw*(stop-start)*coord
        beta=np.sqrt(1-(opening/energy)**2)
        response=2*energy**3*beta**5*diff_weight(energy)
        integ+=weights@response
        weighted+=(weights*response)@normalized_d(energy,opening**2/4,cap**2,order)
    return integ,weighted/integ


def run(order=40):
    results=[]
    for label,mass in (("massless_control",0.),("retained_light",MASS_LIGHT),("retained_fast",MASS_FAST)):
        for dist in (3e-15,.0002,.001,.01,.1):
            opening=2*mass*dist/HC
            cap=dist*WITNESS/HC
            integ,avg=ray(opening,cap,order)
            _,far=ray(2*opening,2*cap,order)
            contrast=(far-avg if cap>=1e-4 else short_contrast(mass/WITNESS,cap,order))
            results.append(dict(pole=label,mass_eV=mass,near_m=dist,far_m=2*dist,third_m=4*dist,
                pair_max_eV=WITNESS,crossed_max_eV=WITNESS,scaled_dim10_weight=integ,
                window_D_per_eta_lambda_eV4=weighted_unit(integ,avg,dist),
                window_average_B_per_eta_lambda=avg,window_average_difference_per_eta_lambda=contrast,
                massless_scaling_limit=np.log(2)/(24*np.pi**2)))
    return results


def short_contrast(mass,cap,order):
    nodes,aw=roots_legendre(order)
    energy=2*mass+(1-2*mass)*(1+nodes)/2
    speed=np.sqrt(1-(2*mass/energy)**2)
    arg=cap*energy
    def small(arg):
        return arg**2/12*(15*(np.log(arg/2)+np.euler_gamma-.75)+16*np.log(2))
    base=aw*energy**5*speed**5*(1+small(arg))
    base/=sum(base)
    relative=(small(2*arg)-small(arg))/(1+small(arg))
    coeff=normalized_d(energy,mass**2,1.,order)
    return (base*(coeff-base@coeff))@relative/(1+base@relative)


def weighted_unit(integ,avg,dist):
    return integ*avg*(HC/dist)**4/(1920*np.pi**2)


if __name__=="__main__":
    print(run()[-2])

