"""Motion-pair cut of the calibrated metric between conserved sources. Natural lengths unless marked SI."""
import csv
import hashlib
import json
from pathlib import Path
import numpy as np
from scipy import constants
from scipy.special import kv, roots_legendre

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
OLD=ROOT/"mts-pion-threshold-and-aperture-budget-20261121"
def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
assert digest(OLD/"seal.json")=="0649e172463441ea47c0cc262dc2961c675c614371ab54bb93d6ba801f64b8e3"
for name,sha in json.loads((OLD/"seal.json").read_bytes()).items():
    assert digest(OLD/name)==sha
HC=constants.hbar*constants.c/constants.electron_volt
LP2=constants.hbar*constants.G/(constants.c**3)
VECTOR=ROOT/"mts-transverse-scale-transfer-20261121"/"matched-vector.json"
C_KNOWN=json.loads(VECTOR.read_bytes())["known_leptons_plus_W_m2"]
MASS_LIGHT=1.095668516985692e-33
MASS_ALT=1.773835953883273e-33
MASS_FAST=9.585761787277403e-25
WITNESS=1e-3
KEYS=("potential","force","spatial_potential","common_time_over_4tM","bending",
      "tidal","tidal_weighted_difference")


def write(name,rows):
    with (HERE/name).open("w",encoding="utf8",newline="") as stream:
        out=csv.DictWriter(stream,fieldnames=rows[0],lineterminator="\n")
        out.writeheader()
        out.writerows(rows)


def screened(arg):
    return .5*arg**2*kv(2,arg)


def diff_weight(arg):
    small=arg<.002
    result=np.empty_like(arg)
    result[~small]=screened(arg[~small])-screened(2*arg[~small])
    near=arg[small]
    result[small]=.75*near**2+near**4/16*(15*(np.log(near/2)+np.euler_gamma-.75)+16*np.log(2))
    return result


def integrands(energy,opening,improvement):
    beta2=(1-opening/energy)*(1+opening/energy)
    speed=np.sqrt(np.maximum(0.,beta2))
    tensor=speed**5/(120*np.pi)
    trace=speed*(1-6*improvement+.5*(opening/energy)**2)**2/(48*np.pi)
    newton=(4*tensor+2*trace)/3
    spatial=(2*tensor-2*trace)/3
    yuk=np.exp(-energy)
    return 2*energy*np.array([newton*yuk,newton*yuk*(1+energy),spatial*yuk,
                 tensor*kv(0,energy),tensor*energy*kv(1,energy),tensor*screened(energy),
                 tensor*diff_weight(energy)])


def kernels(opening,cap=np.inf,xi=0.,order=64):
    if opening>=cap:
        return dict.fromkeys(KEYS,0.)
    high=min(cap,opening+128.)
    points=np.unique(np.r_[opening,opening+np.array([.001,.03,.2,1,4,12,36,80]),high])
    if opening>0.:
        points=np.unique(np.r_[points,opening*np.array([1.01,1.1,2.,5.,15.])])
    edges=points[(points>=opening)&(points<=high)]
    grid,aw=roots_legendre(order)
    unit=(grid+1)/2
    values=np.zeros(len(KEYS))
    for low,hi in zip(edges,edges[1:]):
        delta=hi-low
        energy=low+delta*unit**2
        values+=integrands(energy,opening,xi)@(aw*delta*unit)
    return dict(zip(KEYS,values))


def run():
    shapes=[]
    for opening in (0.,.001,.1,.5,1.,2.,4.,10.,40.):
        for xi in (0.,1/6):
            row=kernels(opening,xi=xi)
            shapes.append(dict(two_mass_times_distance=opening,xi=xi,**row,
                               bending_to_force=row["bending"]/row["force"]))
    examples=[]
    binary=ROOT/"mts-binary-polarization-rays-20261121"/"conjunction-forecasts.csv"
    with binary.open() as stream:
        far=float(next(row for row in csv.DictReader(stream) if row["geometry"]=="G4945_00_DD_central")["impact_m"])
    for label,mass in (("light_Lambda0",MASS_LIGHT),("light_alternative",MASS_ALT),("fast_example",MASS_FAST)):
        for length in (3e-15,52e-6,.01,1.,far,constants.parsec,3*constants.parsec):
            opening=2*mass*length/HC
            cap=WITNESS*length/HC
            for role,upper in (("saved_band",cap),("constant_vertex_benchmark",np.inf)):
                vals=kernels(opening,upper)
                scale=LP2/length**2
                ratio=scale*vals["tidal_weighted_difference"]
                examples.append(dict(pole=label,mass_eV=mass,near_m=length,far_m=2*length,role=role,
                    max_W_eV=WITNESS if role=="saved_band" else "",two_mb=opening,
                    fractional_potential=scale*vals["potential"],fractional_force=scale*vals["force"],
                    fractional_bending=scale*vals["bending"],lens_over_dynamical_mass_shift=scale*(vals["bending"]-vals["force"]),
                    fractional_tidal=scale*vals["tidal"],
                    D_over_c=ratio,D_m2_leptons_W_partial=ratio*C_KNOWN if role=="saved_band" else ""))
    return shapes,examples


if __name__=="__main__":
    shapes,examples=run()
    write("massive-transfer.csv",shapes)
    write("retained-examples.csv",examples)
    print(shapes[0]);print(examples[:2])
