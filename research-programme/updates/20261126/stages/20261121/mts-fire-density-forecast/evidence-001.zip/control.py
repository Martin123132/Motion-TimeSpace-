import csv
import json
import sys
from freeze_density import HOME, ROOT, SOURCE, RADII, np, digest, checked, save_json, save_rows
from scipy.special import eval_legendre, roots_legendre

FROZEN = '56e6fe56045146e609bdb80a970949886d0bcf0d49312d8332fe72b068d17776'
FLIGHT = ROOT / 'mts-fire-directional-lapse-20261121'


def run():
    freeze = json.loads(checked(HOME / 'freeze.json', FROZEN).read_bytes())
    with checked(HOME/'density-forecast.csv', freeze['density']).open(newline='') as stream:
        rows = list(csv.DictReader(stream))
    sys.path.insert(0, str(SOURCE))
    from absolute_current import Experiment, shape, guard
    guard()
    box = Experiment(0, 1)
    elements = box.lab.run.el
    length = box.bg.length
    degrees = np.arange(0, 70, 2)
    mu, weights = roots_legendre(92)
    angular = eval_legendre(box.bg.orders, mu[:, None]) * np.sqrt(2 * box.bg.orders + 1)
    projection = (weights[:, None]/2) * eval_legendre(degrees, mu[:, None]) * (2*degrees+1)
    nodes, quadrature = roots_legendre(16)
    volumes = 4 * np.pi / 3 * np.diff(RADII**3)
    panels = []
    for inner, outer in zip(RADII[:-1]/length, RADII[1:]/length):
        edges = np.r_[inner, elements.right[(elements.right>inner)&(elements.right<outer)], outer]
        radii = (edges[:-1,None]+np.diff(edges)[:,None]*(nodes+1)/2).ravel()
        measure = (np.diff(edges)[:,None]*quadrature/2).ravel()
        indices = np.searchsorted(elements.right, radii)
        basis = shape(elements.knots, (radii-elements.left[indices])/elements.width[indices])[0]
        panels.append((indices, basis, measure))

    def bilinear(left, right):
        first, second = elements.nodes(left), elements.nodes(right)
        output = []
        for volume, (indices, basis, measure) in zip(volumes, panels):
            sky1 = np.einsum('ri,rim->rm', basis, first[indices]) @ angular.T
            sky2 = np.einsum('ri,rim->rm', basis, second[indices]) @ angular.T
            output.append(box.lab.mesh.mscale / volume * (measure @ ((sky1.conj()*sky2).real @ projection)))
        return np.array(output)

    def scores(value, target):
        delta = value - target
        norm = lambda array: np.sqrt(np.sum(volumes[:,None]*array**2/(2*degrees+1)))
        return float(np.max(abs(delta[:,0]))/np.max(abs(target[:,0]))), float(norm(delta)/norm(target))

    authority = json.loads(checked(FLIGHT/'seal.json', 'b3de88dae7ca047c80bba71d04957085dc3f6c805a5d1a89d0b747ad1587f16c').read_bytes())
    results, measured, refinements = [], [], []
    used, coarse = {}, {}
    for arm in ('reset','coupled'):
        selection = [row for row in rows if row['arm']==arm and row['direction']=='forward']
        target = np.array([float(row['drho_dt_Msun_kpc3_Myr']) for row in selection]).reshape(2,35)
        forecast_density = np.array([float(row['rho_Msun_kpc3']) for row in selection]).reshape(2,35)
        for source in ('represented','raw'):
            for resolution in (8,16):
                name = f'flight-{resolution}-{arm}-{source}.npz'
                used[name] = authority[name]
                guard()
                with np.load(checked(FLIGHT/name, authority[name])) as saved:
                    dt = float(saved['dt_Myr'])
                    start, first, second = saved['wave'][:3]
                assert dt > 0 and np.array_equal(start, box.lab.initial[arm])
                absolute = bilinear(start, start)
                launch_err = scores(absolute, forecast_density)
                one = bilinear(first-start, first+start)/dt
                two = (4*one-bilinear(second-start, second+start)/dt)/2
                for stencil, derivative in (('first',one), ('second',two)):
                    for label, sign in (('forward',1),('reversed',-1)):
                        mono, full = scores(derivative, sign*target)
                        results.append(dict(arm=arm, source=source, resolution=resolution, stencil=stencil, direction=label,
                              dt_Myr=dt, monopole_error=mono, angular_rms_error=full, launch_mono_error=launch_err[0],
                              launch_angular_error=launch_err[1], numerical_pass=mono<=.005 and full<=.005))
                for index, field in enumerate(two):
                    for degree, value in zip(degrees, field):
                        measured.append(dict(arm=arm,source=source,resolution=resolution,shell=index+1,ell=degree,
                                             inferred_rate_Msun_kpc3_Myr=value))
                if resolution == 8:
                    coarse[arm,source] = two
                else:
                    difference = two-coarse[arm,source]
                    mono, full = scores(target+difference,target)
                    refinements.append(dict(arm=arm, source=source, coarse_fine_mono=mono, coarse_fine_angular=full))
    save_rows('internal-control.csv', results)
    save_rows('internal-measured-slopes.csv', measured)
    save_json('internal-control.json', dict(frozen=FROZEN, inputs=used, refinements=refinements,
              protocol=digest(HOME/'CONTROL.md'), generator=digest(HOME/'control.py'),
              control_only=True, independent_wave_history=False))
    for row in results:
        if row['resolution']==16 and row['stencil']=='second': print(row['arm'],row['source'],row['direction'],row['monopole_error'],row['angular_rms_error'],row['launch_angular_error'])


if __name__ == '__main__':
    run()
