import csv
import json
import math
import sys
from pathlib import Path
from freeze_density import HOME, SOURCE, PARITY, RADII, checked, digest, save_json, np
from control import FLIGHT, FROZEN


def rows(name):
    with (HOME/name).open(newline='') as stream:
        return list(csv.DictReader(stream))


def verify(make_seal=False):
    frozen = json.loads(checked(HOME/'freeze.json', FROZEN).read_bytes())
    for name, field in (('freeze_density.py','generator'),('density-forecast.csv','density'),('enclosed-forecast.csv','mass'),('PROTOCOL.md','protocol')):
        checked(HOME/name, frozen[field])
    checked(PARITY/'seal.json', frozen['predecessor'])
    checked(SOURCE/'seal.json', frozen['source'])
    for name, signature in frozen['inputs'].items():
        checked(SOURCE/name, signature)
    forecast = rows('density-forecast.csv')
    faces = rows('enclosed-forecast.csv')
    assert len(forecast) == 280 and len(faces) == 12
    tolerance = frozen['parity_tolerance']
    assert tolerance == 1e-9 and frozen['numerical_ceiling'] == .005
    for arm in ('coupled', 'reset'):
        rates = []
        for direction in ('forward','reversed'):
            selected = [row for row in forecast if row['arm']==arm and row['direction']==direction]
            borders = [row for row in faces if row['arm']==arm and row['direction']==direction]
            assert np.array_equal([float(row['r_kpc']) for row in borders], RADII)
            total = np.array([float(row['dmass_dt_Msun_Myr']) for row in borders])
            for index, (left, right) in enumerate(zip(RADII[:-1], RADII[1:])):
                members = [row for row in selected if float(row['inner_kpc'])==left and float(row['outer_kpc'])==right]
                assert [int(row['ell']) for row in members] == list(range(0,70,2))
                volume = 4*np.pi/3*(right**3-left**3)
                assert math.isclose((total[index+1]-total[index])/volume, float(members[0]['drho_dt_Msun_kpc3_Myr']), rel_tol=tolerance)
            rates.append(np.array([[float(row['rho_Msun_kpc3']),float(row['drho_dt_Msun_kpc3_Myr'])] for row in selected]))
        assert np.array_equal(rates[0], rates[1]*[1,-1]) and np.isfinite(rates).all()
    tests = rows('internal-control.csv')
    reference = json.loads((HOME/'internal-control.json').read_bytes())
    assert reference['frozen'] == FROZEN and reference['control_only'] and not reference['independent_wave_history']
    checked(HOME/'CONTROL.md', reference['protocol'])
    checked(HOME/'control.py', reference['generator'])
    for name, signature in reference['inputs'].items():
        checked(FLIGHT/name, signature)
    second = [row for row in tests if row['stencil']=='second']
    assert len(second)==16 and len(reference['inputs'])==8
    assert len(rows('internal-measured-slopes.csv'))==560
    for row in second:
        assert float(row['launch_angular_error'])<tolerance
        errors = [float(row[key]) for key in ('monopole_error','angular_rms_error')]
        if row['direction']=='forward':
            assert max(errors)<.005 and row['numerical_pass']=='True'
        else:
            assert min(errors)>1.99 and row['numerical_pass']=='False'
    gate = json.loads((HOME/'history-gate.json').read_bytes())
    assert gate['forecast']==FROZEN and gate['qualified']==0 and gate['independent_sign'] is None
    for candidate in gate['candidates']:
        assert not candidate['qualifies'] and candidate['reason']
        for source in candidate['sources']:
            checked(Path(source['path']),source['sha256'])
    hashes = {path.name:digest(path) for path in sorted(HOME.iterdir()) if path.is_file() and path.name!='seal.json'}
    if make_seal:
        save_json('seal.json', hashes)
    assert hashes == json.loads((HOME/'seal.json').read_bytes())
    print('Verified',len(hashes),'files;',digest(HOME/'seal.json'))


if __name__ == '__main__':
    if not __debug__:
        raise RuntimeError('Verification requires assertions')
    verify(sys.argv[1:]==['--seal'])
