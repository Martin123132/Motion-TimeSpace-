"""Freeze and replay all path, pressure, timing-fit and distance-transfer controls."""
import argparse
import csv
import io
import json
from wave_clock import HERE,ROOT,Wave,Ray,TAGS,geometry,safe,sha,timing_jet,YEAR
import numpy as np
from scipy import constants
from pulsar_cadence_projection import Cadence,EPOCHS
from noise_transfer import ReleasedNoise,joint,distance_transfer
from scipy.integrate import simpson

SKY=ROOT/"mts-solar-differential-acceleration-20261119"
LAB=ROOT/"mts-lmc-proper-clock-screen-20261121"
PRIMARY=("J1713+0747","J0613-0200")

def contents():
    safe()
    assert sha(LAB/"seal.json")=="480250cbbfa645845fbe697d48a8499abc7561b7f990f6a6a872556bb90ea893"
    for name,digest in json.loads((LAB/"seal.json").read_bytes()).items():
        assert sha(LAB/name)==digest
    assert sha(SKY/"geometry.csv")=="1a1b14f08dbc97e36af23889462c72977b5a76063bdae7a7589a0a7ac182d96b"
    with (SKY/"geometry.csv").open() as handle:
        rows=list(csv.DictReader(handle))
    assert len(rows)==len({row["NAME"] for row in rows})==26
    return rows

def controls():
    metric=np.diag([-1.,1.,1.,1.])
    results=[]
    for velocity in ([0,0,0],[.0005,-.0003,.0004],[.09,-.123,.2]):
        momentum=np.array(velocity)
        energy=np.sqrt(1+momentum@momentum)
        lower=np.r_[-energy,momentum]
        stress=-.5*np.outer(lower,lower)+.25*metric
        field=-4*np.pi*stress
        for direction in ([1.,0,0],[0,1.,0],[.6,0,.8]):
            axis=np.r_[0.,direction];long=lower@axis;time=lower[0]
            curvature=2*(time**2*(axis@field@axis)+long**2*field[0,0]-2*time*long*(field[0]@axis))
            exact=-2*np.pi*(energy**2-long**2)
            assert abs(curvature/exact-1)<2e-15
            results.append(curvature/exact-1)
    h=2e-3
    stamp=np.linspace(-30.,0.,5)
    omega=.092
    artificial=(1+h*stamp+1j*h**2*stamp**2)[:,None,None]
    coefficients,_=timing_jet(artificial,stamp,omega)
    poly=coefficients[:,0,0]/YEAR
    tube=np.polynomial.polynomial.polyvander((stamp+15)/15,2)@poly
    first=(poly[1]+2*poly[2]*(stamp+15)/15)/15
    second=2*poly[2]/15**2
    defect=np.max(abs(second-2j*omega*first-omega**2*tube-1j*omega*artificial[:,0,0]))
    assert defect<3e-15
    return dict(plane_stress_relative=max(abs(np.array(results))),antiderivative_residual=defect)

def clock_identity():
    from scipy.special import roots_legendre
    nodes,weights=roots_legendre(64)
    depth=1.71;omega=7.37
    pos=depth*(1+nodes)/2;measure=depth/2*weights*np.exp(1j*omega*pos)
    phase=np.exp(1j*omega*depth)
    result={}
    for name,first,second in (("uniform_lapse",[1.2],[0.]),("uniform_acceleration",[1.2,.9],[0.]),
            ("varying_metric",[.7,.3,.13,-.09],[.2,-.3,.31])):
        phi=np.polynomial.Polynomial(first);psi=np.polynomial.Polynomial(second)
        velocity=phi.deriv()/(1j*omega)
        direct=phase*phi(depth)-phi(0.)+velocity(0.)-phase*velocity(depth)-1j*omega*(measure@(phi(pos)+psi(pos)))
        freely_falling=measure@(phi.deriv(2)(pos)-omega**2*psi(pos))/(-1j*omega)
        result[name+"_redshift_error"]=abs(direct-freely_falling)
        assert abs(direct-freely_falling)<5e-13
        if name!="varying_metric":
            assert abs(direct)<5e-13
    return result

def normalization():
    from prepare import saved
    gravity_solar=1.3271244e20/(1e9*constants.parsec)
    physical=ROOT/"mts-rotating-bar-wave-drive-20261119"/"extra-mean.csv"
    with physical.open() as stream:
        catalog={row["case"]:float(row["dark_mass"]) for row in csv.DictReader(stream)}
    result={}
    for case,name in enumerate(("reference","added-free2-plus")):
        with np.load(saved(f"operators/{case}-k-100.npz")) as op:
            mass=float(op["mass"])*float(op["velocity"])**2*float(op["length"])/gravity_solar
            result[name+"_relative_mass"]=abs(mass/catalog[name]-1)
            assert result[name+"_relative_mass"]<2e-5
    return result

def retain(name,data,init):
    path=HERE/name
    if init and not path.exists():
        with path.open("xb") as stream:
            stream.write(data)
    assert path.read_bytes()==data,name

def table(name,rows,init):
    stream=io.StringIO(newline="")
    writer=csv.DictWriter(stream,rows[0].keys(),lineterminator="\n")
    writer.writeheader()
    writer.writerows(rows)
    retain(name,stream.getvalue().encode(),init)

def pack(data):
    return (json.dumps(data,sort_keys=True,indent=2,allow_nan=False)+"\n").encode()

def diagnostic(model):
    axis=np.array([1.,0.,0.])
    ray=Ray(model,axis,.08,12,1)
    original=model.harmonic
    def artificial(direction,pos,epoch):
        return np.column_stack((np.ones_like(pos),1+.28*pos-.17*pos**2))
    model.harmonic=artificial
    try:
        dist=np.array([0.,np.pi*2/model.k,.026,.052,.08])
        z,end=ray.readout(dist,[0.])
        plane=np.exp(1j*model.k*dist)
        expected=1-plane
        assert np.max(abs(z[0,:,0]-expected))<3e-12
        wave=1j*model.k
        primitive=(plane-1)/wave
        first=dist*plane/wave-primitive/wave
        second=dist**2*plane/wave-2*first/wave
        expected2=-wave*(primitive+.28*first-.17*second)
        assert np.max(abs(z[0,:,1]-expected2))<3e-12
    finally:
        model.harmonic=original

def sample(wave,row,order,splits,dist_grid):
    axis=geometry(row)
    distance=float(row["DIST"])/wave.length
    sigma=float(row["DIST_ERR"])/wave.length
    if dist_grid:
        count=max(32,int(np.ceil(2*sigma*wave.k*48/(2*np.pi))))
        count+=count%2
        targets=np.linspace(distance-sigma,distance+sigma,count+1)
        center=count//2
    else:
        targets=np.array([distance])
        center=0
    ray=Ray(wave,axis,distance+sigma,order,splits)
    red,end=ray.readout(targets,EPOCHS)
    timing,error=timing_jet(red,EPOCHS,wave.omega)
    endtiming,_=timing_jet(end,EPOCHS,wave.omega)
    return timing,endtiming,center,error

def run(init):
    rows=contents()
    checks=controls()
    directions=[];cadences=[];precision=[];densities=[];distance_rows=[]
    noisy=[];array=[];recovery=[];dist_refine=[]
    for case in (0,1):
        wave=Wave(case,-100,8)
        other=Wave(case,-64,4)
        diagnostic(wave)
        omega=wave.omega
        schedules={(name,kind):Cadence(name,omega,unit=(kind=="equal")) for name in PRIMARY for kind in ("white","equal")}
        noises={name:ReleasedNoise(name,omega) for name in PRIMARY}
        vectors={};pathsets={}
        for index,name in enumerate(PRIMARY):
            if not case:
                recovery.append(dict(name=name,**noises[name].recovery(6403+index)))
        terrestrial=wave.harmonic(np.array([1.,0,0]),np.array([0.]),0.)[0]
        density_scale=(omega/YEAR)**2/(4*np.pi*constants.G)*constants.c**2/(constants.eV*1e9)/1e6
        densities.append(dict(case=case,ground_potential_amplitude=terrestrial[0].real,
            earth_ground_timing_amplitude_ns=terrestrial[0].real*YEAR/omega*1e9,
            mean_ground_density_GeV_cm3=density_scale*terrestrial[0].real,
            double_period_year=2*np.pi/omega,wavelength_pc=2*np.pi/wave.k*wave.length*1000,
            withheld_wave_time_relative=wave.time_error))
        for row in rows:
            name=row["NAME"]
            coeff,endpoint,center,err=sample(wave,row,14,2,True)
            low,_,_,_=sample(wave,row,9,1,False)
            alt,_,_,_=sample(other,row,14,2,False)
            earth=-1j*terrestrial[0].real*YEAR/omega
            nominal=coeff[0,center]
            assert np.max(err)/max(terrestrial[0].real,1e-30)<1e-9
            for idx,tag in enumerate(("ground",*TAGS)):
                current=coeff[:,:,0].copy()
                endterm=endpoint[0,center,0]
                if idx:
                    current+=coeff[:,:,idx]
                    endterm+=endpoint[0,center,idx]
                value=current[0,center]
                sizes=abs(current[0])*1e9
                contrast=abs(nominal[idx])*1e9
                metric=dict(case=case,name=name,state=tag)
                directions.append(dict(**metric,distance_kpc=row["DIST"],distance_sigma_kpc=row["DIST_ERR"],
                    propagation_sigma_rad=float(row["DIST_ERR"])*wave.k/wave.length,
                    epoch_mid_induced_or_ground_peak_ns=contrast,total_peak_ns=abs(value)*1e9,
                    nominal_total_real_ns=value.real*1e9,nominal_total_imag_ns=value.imag*1e9,
                    endpoint_only_peak_ns=abs(endterm)*1e9,complex_line_minus_endpoint_ns=abs(value-endterm)*1e9,
                    fractional_complex_line_change=abs(value-endterm)/abs(value),
                    flat_clock_shared_phase=True))
                meanpower=np.trapezoid(sizes**2,dx=1/(len(sizes)-1))
                fine_average=np.sqrt(simpson(sizes**2,dx=1/(len(sizes)-1)))
                coarse_average=np.sqrt(simpson(sizes[::2]**2,dx=2/(len(sizes)-1)))
                dist_refine.append(dict(**metric,refined_uniform_sensitivity_rms_ns=fine_average,
                    half_grid_relative=abs(coarse_average/fine_average-1),
                    original_20ppm_pass=abs(coarse_average/fine_average-1)<2e-5))
                distance_rows.append(dict(**metric,trial_count=len(sizes),sampled_min_peak_ns=min(sizes),sampled_max_peak_ns=max(sizes),
                    uniform_sensitivity_rms_peak_ns=np.sqrt(meanpower),
                    half_grid_rms_relative=abs(np.sqrt(np.trapezoid(sizes[::2]**2,dx=2/(len(sizes)-1))/meanpower)-1)))
                for label,test in (("spatial",low),("basis_and_time",alt)):
                    difference=abs(test[0,0,idx]-nominal[idx])/abs(nominal[idx])
                    precision.append(dict(**metric,comparison=label,relative=difference,original_20ppm_pass=difference<2e-5))
                if name not in PRIMARY:
                    continue
                for part,cube in (("total",current),("induced_only",coeff[:,:,idx])):
                    if not idx and part=="induced_only":
                        continue
                    key=(tag,part)
                    vectors.setdefault(key,{})[name]=cube[:,center]
                    pathsets.setdefault(key,{})[name]=cube.T
                    noisy.append(dict(**metric,contribution=part,**noises[name].report(cube[:,center])))
                for kind in ("white","equal"):
                    cad=schedules[name,kind]
                    for part,cube in (("total",current),("induced_only",coeff[:,:,idx])):
                        if not idx and part=="induced_only":
                            continue
                        amplitudes=cad.nominal(cube[:,center],omega)
                        _,_,post,*_=cad.amplitudes(cube.T)
                        rms=np.sqrt(np.mean(post**2,axis=-1))*1e9
                        cadences.append(dict(**metric,weighting=kind,contribution=part,design_rank=cad.rank,
                            toa_count=cad.count,span_year=cad.span,**amplitudes,
                            sampled_distance_min_phase_mean_ns=rms.min(),sampled_distance_max_phase_mean_ns=rms.max(),
                            earth_only_post_phase_mean_ns=cad.nominal(np.array([earth,0.,0.]),omega)["post_rms_phase_mean_ns"]))
        for (tag,part),values in vectors.items():
            array.append(dict(case=case,state=tag,contribution=part,**joint(noises,values),
                **distance_transfer(noises,pathsets[tag,part])))
        null=joint(noises,{name:np.array([earth,0.,0.]) for name in PRIMARY})
        assert null["mean_snr_retained_after_clock"]<1e-7
        print("completed",case,flush=True)
    assert len(directions)==364 and len(precision)==728
    for name,data in (("sightlines.csv",directions),("distance.csv",distance_rows),("design-transfer.csv",cadences),
                      ("precision.csv",precision),("local-density.csv",densities)):
        table(name,data,init)
    for name,rows in (("fixed-noise.csv",noisy),("clock-control.csv",array),("synthetic-recovery.csv",recovery),("distance-refinement.csv",dist_refine)):
        table(name,rows,init)
    retain("checks.json",pack(checks),init)
    retain("metric-identity.json",pack({**clock_identity(),**normalization()}),init)
    if (HERE/"RESULTS.md").exists() and (HERE/"DERIVATION.md").exists():
        names=["acquire.py","acquisition.json","wave_clock.py","pulsar_cadence_projection.py","verify_timing.py","RESULTS.md","DERIVATION.md",
               "sightlines.csv","distance.csv","design-transfer.csv","precision.csv","local-density.csv","checks.json",*[name+"-design.npz" for name in PRIMARY]]
        names+=["noise_transfer.py","noise-inputs.json","fixed-noise.csv","clock-control.csv","synthetic-recovery.csv","distance-refinement.csv","metric-identity.json",*[name+"-bands.npz" for name in PRIMARY]]
        retain("seal.json",pack({name:sha(HERE/name) for name in names}),init)
        print("verified",len(names),"files",sha(HERE/"seal.json"))
    elif not init:
        raise ValueError("missing stage documentation")

if __name__=="__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--initialize",action="store_true")
    run(parser.parse_args().initialize)

