"""Bounded public geometry/design-only acquisition. Does not select a residual column."""
import argparse
import hashlib
import io
import json
import urllib.request
from pathlib import Path
import numpy as np

HERE=Path(__file__).resolve().parent
REV="18ab4c010b2e8e09eb81fdb145b296da024659fa"
SOURCES={"J1713+0747":(3087818,"e5cbd5997ef322ae59b1ad6060b703e855ac1b5e"),
         "J0613-0200":(1538178,"d3de02a71f8bfcaf6360ca85bc3344e819ddf5e9")}

def put(name,data):
    dest=HERE/name
    if not dest.exists():
        with dest.open("xb") as stream:
            stream.write(data)
    assert dest.read_bytes()==data

def acquire():
    import pyarrow as pa
    import pyarrow.feather as feather
    report=[]
    noise_receipts=[]
    for name,(size,blob) in SOURCES.items():
        url=f"https://raw.githubusercontent.com/nanograv/discovery/{REV}/data/epta_dr2/{name}.feather"
        with urllib.request.urlopen(url,timeout=35) as response:
            raw=response.read(size+1)
        assert len(raw)==size and hashlib.sha1(f"blob {size}\0".encode()+raw).hexdigest()==blob
        schema=pa.ipc.open_file(pa.BufferReader(raw)).schema
        meta=json.loads(schema.metadata[b"json"])
        assert meta["name"]==name
        columns=sorted((col for col in schema.names if col.startswith("Mmat_")),key=lambda col:int(col.split("_")[-1]))
        assert columns and columns==[f"Mmat_{index}" for index in range(len(columns))]
        subset=feather.read_table(pa.BufferReader(raw),columns=["toas","toaerrs",*columns],use_threads=False)
        toas=subset["toas"].to_numpy()
        sigma=subset["toaerrs"].to_numpy()
        matrix=np.column_stack([subset[col].to_numpy() for col in columns])
        assert np.isfinite(matrix).all() and (sigma>0).all() and np.min(toas)>30000*86400 and np.ptp(toas)>8*365.25*86400
        stream=io.BytesIO()
        np.savez_compressed(stream,toas=toas,sigma=sigma,design=matrix)
        output=stream.getvalue()
        put(name+"-design.npz",output)
        extras=feather.read_table(pa.BufferReader(raw),columns=["freqs","backend_flags"],use_threads=False)
        noise_stream=io.BytesIO()
        np.savez_compressed(noise_stream,freq_mhz=extras["freqs"].to_numpy(),backend=extras["backend_flags"].to_numpy().astype("U"))
        noise=noise_stream.getvalue()
        put(name+"-bands.npz",noise)
        noise_receipts.append(dict(name=name,source_blob=blob,bands_sha256=hashlib.sha256(noise).hexdigest(),
            settings=meta["noisedict"]))
        report.append(dict(name=name,url=url,blob=blob,source_bytes=size,source_sha256=hashlib.sha256(raw).hexdigest(),
            kept_sha256=hashlib.sha256(output).hexdigest(),kept_bytes=len(output),rows=len(toas),cols=len(columns),
            first_mjd=float(min(toas)/86400),last_mjd=float(max(toas)/86400),fitpars=meta.get("fitpars"),residual_column_selected=False))
    put("acquisition.json",(json.dumps(report,sort_keys=True,indent=2)+"\n").encode())
    put("noise-inputs.json",(json.dumps(noise_receipts,sort_keys=True,indent=2)+"\n").encode())

if __name__=="__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--fetch",required=True,action="store_true")
    parser.parse_args()
    acquire()

