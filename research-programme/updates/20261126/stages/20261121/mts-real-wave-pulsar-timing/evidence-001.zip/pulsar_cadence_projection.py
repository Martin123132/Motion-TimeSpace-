"""Noise-weighted transfer of injected waveforms. No measured timing residuals."""
import json
import numpy as np
from scipy.linalg import svd,eigvalsh
from wave_clock import HERE,YEAR,sha

EPOCHS=np.linspace(-30,0,5)
REFERENCE_MJD=60000.


def features(time,omega):
    scaled=(time+15)/15
    powers=np.column_stack((np.ones_like(time),scaled,scaled**2))
    return np.column_stack((np.cos(omega*time)[:,None]*powers,np.sin(omega*time)[:,None]*powers))


def basis(columns):
    norms=np.linalg.norm(columns,axis=0)
    scaled=columns[:,norms>0]/norms[norms>0]
    left,values,_=svd(scaled,full_matrices=False)
    return left[:,values>np.finfo(float).eps*max(scaled.shape)*values[0]]


class Cadence:
    def __init__(self,name,omega,unit=False):
        receipt=next(row for row in json.loads((HERE/"acquisition.json").read_bytes()) if row["name"]==name)
        path=HERE/(name+"-design.npz")
        assert sha(path)==receipt["kept_sha256"]
        with np.load(path,allow_pickle=False) as raw:
            time=raw["toas"]/YEAR-REFERENCE_MJD/365.25
            weights=np.ones(len(time)) if unit else 1/raw["sigma"]
            design=raw["design"]
        assert time.min()>=EPOCHS[0] and time.max()<=0 and np.isfinite(weights).all()
        self.span=np.ptp(time);self.count=len(time)
        self.time=time
        weights/=np.linalg.norm(weights)
        self.weights=weights
        function=features(time,omega)*weights[:,None]
        spin=basis(weights[:,None]*np.polynomial.polynomial.polyvander((time-np.mean(time))/self.span,2))
        full=basis(weights[:,None]*design)
        assert np.linalg.norm(spin-full@(full.T@spin))<1e-8
        self.rank=full.shape[1]
        self.full=full
        def gram(values):
            return values.T@values
        self.raw=gram(function)
        self.spin=gram(function-spin@(spin.T@function))
        self.post=gram(function-full@(full.T@function))
        self.null=np.linalg.norm(full.T@(function-full@(full.T@function)))/np.linalg.norm(function)
        assert self.null<1e-12

    def amplitudes(self,coefs):
        pair=np.stack((np.concatenate((coefs.real,coefs.imag),axis=-1),
                       np.concatenate((-coefs.imag,coefs.real),axis=-1)),axis=-1)
        def covariance(matrix):
            return np.swapaxes(pair,-1,-2)@(matrix@pair)
        def powers(matrix):
            return np.sqrt(np.maximum(0.,np.linalg.eigvalsh(matrix)))
        raw=covariance(self.raw)
        spin=covariance(self.spin)
        post=covariance(self.post)
        return powers(raw),powers(spin),powers(post),pair,raw,post

    def nominal(self,coefs,omega):
        pre,spin,post,pair,raw,projected=self.amplitudes(coefs)
        rates=np.sqrt(np.maximum(0.,eigvalsh(projected,raw)))
        model=features(self.time,omega)@pair*self.weights[:,None]
        after=model-self.full@(self.full.T@model)
        check=svd(after,compute_uv=False)[::-1]
        assert np.allclose(check,post,rtol=1e-7,atol=1e-20)
        return dict(raw_rms_phase_mean_ns=np.sqrt(np.mean(pre**2))*1e9,spin_rms_phase_mean_ns=np.sqrt(np.mean(spin**2))*1e9,
            post_rms_phase_mean_ns=np.sqrt(np.mean(post**2))*1e9,post_min_phase_ns=post[0]*1e9,post_max_phase_ns=post[1]*1e9,
            min_post_to_pre_same_phase=rates[0],max_post_to_pre_same_phase=rates[1],
            rms_transfer=np.linalg.norm(post)/np.linalg.norm(pre))

