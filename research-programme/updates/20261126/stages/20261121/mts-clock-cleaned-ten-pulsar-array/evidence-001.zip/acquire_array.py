"""A bounded, exact tree intersection. Do not select observation residuals."""
from pathlib import Path
import argparse
import csv
import io
import json
import hashlib
import urllib.request
import numpy as np

HERE=Path(__file__).resolve().parent
PILOT=HERE.parent/"mts-real-wave-pulsar-timing-20261121"
SKY=HERE.parent/"mts-solar-differential-acceleration-20261119"/"geometry.csv"
REV="18ab4c010b2e8e09eb81fdb145b296da024659fa"
NAMES=("J0613-0200","J0751+1807","J1012+5307","J1022+1001","J1455-3330","J1600-3053","J1640+2224","J1713+0747","J1738+0333","J1909-3744")
PRIOR=("J0613-0200","J1713+0747")

def encoded(obj):
    return (json.dumps(obj,sort_keys=True,indent=2,allow_nan=False)+"\n").encode()

def put(name,data,init):
    path=HERE/name
    if init and not path.exists():
        with path.open("xb") as stream:
            stream.write(data)
    assert path.read_bytes()==data,name

def fetch():
    import pyarrow as pa
    import pyarrow.feather as feather
    endpoint=f"https://api.github.com/repos/nanograv/discovery/git/trees/{REV}?recursive=1"
    with urllib.request.urlopen(endpoint,timeout=30) as response:
        tree=json.loads(response.read(10_000_000))
    assert not tree["truncated"]
    with SKY.open() as handle:
        sources={row["NAME"] for row in csv.DictReader(handle)}
    lookup={Path(item["path"]).stem:item for item in tree["tree"] if item["path"].startswith("data/epta_dr2/") and item["path"].endswith(".feather") and Path(item["path"]).stem in sources}
    assert tuple(sorted(lookup))==NAMES and sum(item["size"] for item in lookup.values())==18488532
    pilots={row["name"]:row for row in json.loads((PILOT/"acquisition.json").read_bytes())}
    packet=[];noise=[]
    for name in NAMES:
        item=lookup[name]
        url=f"https://raw.githubusercontent.com/nanograv/discovery/{REV}/"+item["path"]
        if name in PRIOR:
            assert pilots[name]["blob"]==item["sha"]
            packet.append(dict(name=name,source=url,blob=item["sha"],bytes=item["size"],folder="pilot",
                design_sha256=pilots[name]["kept_sha256"],timing_residual_selected=False))
            continue
        with urllib.request.urlopen(url,timeout=30) as handle:
            raw=handle.read(item["size"]+1)
        assert len(raw)==item["size"] and hashlib.sha1(f"blob {len(raw)}\0".encode()+raw).hexdigest()==item["sha"]
        schema=pa.ipc.open_file(pa.BufferReader(raw)).schema
        meta=json.loads(schema.metadata[b"json"])
        assert meta["name"]==name
        columns=sorted((col for col in schema.names if col.startswith("Mmat_")),key=lambda col:int(col.split("_")[-1]))
        assert columns==[f"Mmat_{index}" for index in range(len(columns))]
        allowed=["toas","toaerrs","freqs","backend_flags",*columns]
        data=feather.read_table(pa.BufferReader(raw),columns=allowed,use_threads=False)
        assert data.column_names==allowed
        toas=data["toas"].to_numpy(); sigma=data["toaerrs"].to_numpy()
        matrix=np.column_stack([data[col].to_numpy() for col in columns])
        assert np.isfinite(matrix).all() and np.min(sigma)>0 and np.ptp(toas)>365.25*86400
        target=io.BytesIO()
        np.savez_compressed(target,toas=toas,sigma=sigma,design=matrix)
        value=target.getvalue()
        put(name+"-design.npz",value,True)
        packet.append(dict(name=name,source=url,blob=item["sha"],bytes=item["size"],folder="here",design_sha256=hashlib.sha256(value).hexdigest(),
            timing_residual_selected=False))
        target=io.BytesIO()
        np.savez_compressed(target,freq_mhz=data["freqs"].to_numpy(),backend=data["backend_flags"].to_numpy().astype("U"))
        bands=target.getvalue();put(name+"-bands.npz",bands,True)
        noise.append(dict(name=name,source_blob=item["sha"],bands_sha256=hashlib.sha256(bands).hexdigest(),settings=meta["noisedict"]))
    put("sources.json",encoded(packet),True)
    put("noise-inputs.json",encoded(noise),True)

if __name__=="__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--fetch",required=True,action="store_true")
    parser.parse_args()
    fetch()

