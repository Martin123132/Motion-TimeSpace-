"""Resolve the one-in-three alias with all three phases and full-grid quadrature controls."""
from aperture_origin import *
from scipy.interpolate import make_interp_spline
from unittest.mock import patch
from contextlib import nullcontext

def alternate(order,degree,subset=None):
    class Probe:
        def __init__(self,shell,start,unused,requested):
            self.keep=slice(None) if subset is None else slice(subset,None,3)
            pos=shell.r[self.keep]
            self.axis=np.r_[-pos[:8][::-1],pos]
            cells=pos[(pos>.55*CENTER)&(pos<1.45*CENTER)]
            center=(cells[1:]+cells[:-1])/2
            half=np.diff(cells)/2
            node,mass=leggauss(order)
            self.pos=(center[:,None]+half[:,None]*node).ravel()
            self.quad=(half[:,None]*mass).ravel()
        def spline(self,values):
            vals=values[...,self.keep]
            raw=np.concatenate((vals[...,:8][...,::-1],vals),axis=-1)
            return make_interp_spline(self.axis,raw,k=degree,axis=-1)
        def at(self,values):
            return self.spline(values)(self.pos)
    return Probe

def run(seed):
    grid=960
    if seed<0:
        from negative_mesh import signature,prefix,verify_step
        sig=signature(grid)
    else:
        from finer_grid import check
        sig=check()
    samples={}
    for flag in (0,1):
        with task.system(grid,seed,flag) as model:
            for tick in (0,*task.CLOCKS):
                task.guard()
                src=HERE/f"fine960-b{flag}-t{tick}.npz" if seed==1 else prefix(grid,flag,tick)
                rec=task.meta(src.with_suffix(".json"))
                assert rec["sha"]==task.lab.sha(src) and rec["pin" if seed==1 else "receipt"]==sig
                with np.load(src) as bank:
                    state=task.old.Difference(bank["base"],bank["delta"]);clock=float(bank["clock"])
                raw,fields=physical_read(model,state,clock,"off")
                if not tick:
                    initial={key:fields[key] for key in ("space","temporal")}
                    continue
                cases=[("native",None),("full-cubic8",alternate(8,3)),("full-cubic16",alternate(16,3)),("full-linear",alternate(8,1))]
                cases.extend((f"phase{phase}",alternate(8,3,phase)) for phase in range(3))
                for label,window in cases:
                    with patch.object(observer.core.ep,"Window",window) if window else nullcontext():
                        for key in initial:
                            reading=observer.annuli(model,raw,initial[key],fields[key])
                            if label=="native":np.testing.assert_allclose(reading,rec["readings"][key],rtol=2e-13,atol=1e-34)
                            samples[flag,tick,label,key]=reading
    rows=[]
    pins=task.meta(PARENT/"seal.json")["files"]
    for row in task.read(validate(PARENT/f"g640-s{seed}-off-newton-twin1024.csv",pins)):
        key=row["reader"];tick=int(row["tick"]);width=float(row["width"])
        unit=abs(float(row["native_newton"]))*1e-6
        def measure(label):return (samples[0,tick,label,key]-samples[1,tick,label,key])[WIDTHS.index(width)]
        native=measure("native")
        readings={label:(measure(label)-native)/unit for label in ("full-cubic8","full-cubic16","full-linear","phase0","phase1","phase2")}
        phases=[readings[f"phase{idx}"] for idx in range(3)]
        rows.append(dict(seed=seed,tick=tick,width=width,reader=key,**readings,phase_average=sum(phases)/3,
                         phase_range=max(phases)-min(phases),fine_rule_difference=readings["full-cubic16"]-readings["full-cubic8"]))
    put(f"sampling-phases-s{seed}.csv",rows)
    print(seed,[(key,max(abs(row[key]) for row in rows)) for key in ("full-cubic16","full-linear","phase_average","phase_range")],flush=True)
if __name__=="__main__":run(int(sys.argv[1]))
