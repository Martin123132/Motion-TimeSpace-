"""Exterior-independent longitudinal-current projection and scalar constraint test."""
from aperture_origin import *
from independent_constraints import fields as independent_fields
from scipy.integrate import cumulative_simpson, simpson

COEFFICIENTS=np.array([1.,-12/7,5/7])
PROBES=(.15,.225,.30)

@lru_cache(maxsize=8)
def filters(size):
    axis=np.linspace(0.,CENTER*1.3,size+1)
    radii=axis.copy()
    radii[0]=1e-20
    response=np.array([density_kernel(radii,width,1.,32) for width in PROBES])
    mean=np.array([weight(radii,CENTER*width) for width in PROBES])
    combined=COEFFICIENTS@response
    lower=cumulative_simpson(combined*radii**2,x=axis,initial=0.)
    upper=cumulative_simpson((combined/radii**3)[::-1],x=-axis[::-1],initial=0.)[::-1]
    left=(2*radii**3*upper-3*lower/radii**2)/5
    right=6*(radii**3*upper+lower/radii**2)/5
    assert abs(lower[-1])<5e-12 and abs(simpson(COEFFICIENTS@mean*radii**2,x=axis))<5e-12
    return axis,response,mean,left,right

def analytic(size):
    axis,response,mean,left,right=filters(size)
    evaluate=lambda values:float(simpson(values,x=axis))
    exp=np.exp(-axis**2)
    regular=axis**2*exp
    radial=2*axis*(1-axis**2)*exp
    tangent=axis*exp
    expected=evaluate((COEFFICIENTS@response)*regular)
    got=evaluate(left*radial+right*tangent)
    transverse=evaluate(left*tangent+right*tangent*(3-2*axis**2)/6)
    assert abs(expected)>1e-6 and abs(got-expected)<2e-11 and abs(transverse)<1e-11
    return dict(size=size,expected=expected,gradient=got,solenoidal=transverse,
                exterior_potential=evaluate((COEFFICIENTS@response)*axis**2),
                exterior_tide=evaluate((COEFFICIENTS@mean)*axis**2))

def extract(grid,seed,pins):
    saved={}
    for flag in (0,1):
        with task.system(grid,seed,flag) as model:
            for tick in (0,*task.CLOCKS):
                task.guard()
                stem=name(grid,seed,flag,"off",tick)
                with np.load(validate(PARENT/(stem+".npz"),pins)) as packet:
                    state=task.old.Difference(packet["shared"],packet["signed"])
                    clock=float(packet["clock"])
                    previous=packet["ind_H"].copy() if tick else None
                raw=task.lab.rawfield(model,state,clock)
                signed=(independent_fields(model.host,raw)-independent_fields(model.zero,raw.base)).astype(float)
                if tick:np.testing.assert_array_equal(previous,signed[0])
                field=model.shell.initial+raw
                trace,shear=field[4].real,field[5].real
                saved[flag,tick]=dict(ham=signed[0]/2,radial=signed[4],polar=signed[5],
                    trace=trace.delta[1],shear=shear.delta[1],
                    constraint=(-square(trace)/3+3*square(shear)/4).delta[1],
                    kinetic=(-mul(trace,shear)/3+square(shear)/2).delta[1])
    return saved

def test(grid,seed,pins):
    states=extract(grid,seed,pins)
    parent_form=task.meta(task.FORM/"seal.json")["files"]
    with np.load(validate(task.FORM/f"matched-source-history-p32-s{seed}.npz",parent_form)) as bank:
        scales,hubble=bank["b"].copy(),bank["hubble"].copy()
    budgets=task.read(HERE/"aperture-budget.csv")
    data=[]
    cells=(np.arange(grid*3)+.5)/grid
    knots=np.r_[-cells[3::-1],cells]
    for tick in task.CLOCKS:
        summary=next(row for row in budgets if int(row["grid"])==grid and int(row["seed"])==seed and int(row["tick"])==tick and row["order"]=="16")
        unit=float(summary["unit"])
        for size,mode in ((8192,"cubic"),(16384,"cubic"),(8192,"linear")):
            axis,response,mean,jr,jt=filters(size)
            weight3=COEFFICIENTS@mean
            kernel3=COEFFICIENTS@response
            kernel2=response[0]-response[2]
            evaluate=lambda values:float(simpson(values,x=axis))
            initial={}
            change={}
            for key in states[0,0]:
                base=states[0,0][key]-states[1,0][key]
                now=states[0,tick][key]-states[1,tick][key]
                parity=-1 if key in ("radial","polar") else 1
                def spline(array,where):
                    extended=np.r_[parity*array[3::-1],array]
                    if mode=="linear":return np.interp(where,knots,extended)
                    return CubicSpline(knots,extended)(where)
                sample=axis/scales[tick//32]
                initial[key]=spline(base,axis)
                change[key]=spline(now-base,sample)+(spline(base,sample)-initial[key])
            hub=lambda step:hubble[step]/(32*scales[step])
            def hub_change(key):
                return (hub(tick//32)-hub(0))*initial[key]+hub(tick//32)*change[key]
            norm=1024/unit
            longitudinal=-3*norm*evaluate(jr*hub_change("radial")+jt*hub_change("polar"))
            measured=norm*evaluate(weight3*hub_change("shear")+2*kernel3*hub_change("trace"))
            full=norm*evaluate(weight3*change["kinetic"]+kernel3*change["constraint"])
            defect=norm*evaluate(kernel2*change["ham"])
            data.append(dict(grid=grid,seed=seed,tick=tick,samples=size,interpolation=mode,
                half_constraint_defect_ppm=defect,after_constraint_ppm=float(summary["spatial_remainder"])-defect if mode=="cubic" else "",
                projected_current_ppm=longitudinal,measured_leading_kinetic_ppm=measured,
                measured_full_kinetic_ppm=full,leading_minus_current_ppm=measured-longitudinal,
                full_minus_leading_ppm=full-measured))
    return data

if __name__=="__main__":
    task.guard()
    assert task.lab.sha(PARENT/"seal.json")==PIN
    pins=task.meta(PARENT/"seal.json")["files"]
    put("current-controls.csv",[analytic(size) for size in (8192,16384)])
    rows=[]
    for grid,seed in task.RUNS:
        batch=test(grid,seed,pins)
        rows.extend(batch)
        print(grid,seed,next(row for row in batch if row["tick"]==1024 and row["samples"]==16384),flush=True)
    put("current-and-curvature.csv",rows)
