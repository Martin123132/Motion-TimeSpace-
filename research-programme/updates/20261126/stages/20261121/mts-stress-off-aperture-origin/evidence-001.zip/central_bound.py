"""Worst-sign compact scalar weights applied to measured, unmasked central constraints."""
from aperture_origin import *
from independent_constraints import fields as independent_fields
from outer_current import radial_weights

def constants(width):
    nodes,mass=leggauss(64)
    half=CENTER*width
    pos=CENTER+half*nodes
    window=half*mass*weight(pos,half)
    return np.array([(6/5)*np.sum(window/pos**5),np.sum(window/pos**3)/3])

def coefficients(label):
    if label=="difference":return constants(.15)-constants(.30)
    return constants(float(label))

def fixture():
    rows=[]
    axis,kr,kt=radial_weights(16384)
    small=(axis>.001)&(axis<.3)
    rad=axis[small]
    aa,ii=coefficients("difference")
    analytic_r=2*ii*rad**3/5-2*aa*rad**5/7
    analytic_t=6*ii*rad**3/5-3*aa*rad**5/7
    error=max(np.max(abs(analytic_r-kr[small])),np.max(abs(analytic_t-kt[small])))
    assert error<1e-12
    for label in ("0.15","0.3","difference"):
        aa,ii=coefficients(label)
        source=(density_kernel(rad,.15,1.,32)-density_kernel(rad,.30,1.,32)) if label=="difference" else density_kernel(rad,float(label),1.,32)
        direct=max(abs(source-aa*rad**4));assert direct<1e-14
        rows.append(dict(window=label,A=aa,I0=ii,kernel_error=direct,current_difference_control=error))
    return rows

def run(grid,seed):
    assert task.lab.sha(PARENT/"seal.json")==PIN
    pins=task.meta(PARENT/"seal.json")["files"]
    twins=task.read(validate(PARENT/f"g640-s{seed}-off-newton-twin1024.csv",pins))
    unit=abs(float(next(row for row in twins if row["tick"]=="1024" and row["width"]=="0.15")["native_newton"]))*1e-6
    with np.load(validate(task.FORM/f"matched-source-history-p32-s{seed}.npz",task.meta(task.FORM/"seal.json")["files"])) as bank:
        scales,hubble=bank["b"].copy(),bank["hubble"].copy()
    keys=(1/grid,.025,.1,.3)
    accum={}
    shell_bounds={}
    rawrows=[]
    for flag in (0,1):
        with task.system(grid,seed,flag) as model:
            for tick in (0,1024):
                task.guard()
                if (grid,seed) in task.RUNS:
                    path=validate(PARENT/(name(grid,seed,flag,"off",tick)+".npz"),pins);names=("shared","signed")
                elif seed==1:
                    from finer_grid import check
                    path=HERE/f"fine960-b{flag}-t{tick}.npz";cert=task.meta(path.with_suffix(".json"))
                    assert cert["pin"]==check() and cert["sha"]==task.lab.sha(path)
                    names=("base","delta")
                else:
                    from negative_mesh import signature,prefix,verify_step
                    path=prefix(grid,flag,tick);verify_step(path,signature(grid));names=("base","delta")
                with np.load(path) as bank:
                    state=task.old.Difference(bank[names[0]],bank[names[1]])
                    clock=float(bank["clock"])
                    saved=bank["ind_H"].copy() if tick else None
                physical=task.lab.rawfield(model,state,clock)
                full=independent_fields(model.host,physical)
                zero=independent_fields(model.zero,physical.base)
                signed=(full-zero).astype(float)
                if tick:np.testing.assert_array_equal(signed[0],saved)
                rawrows.append(dict(grid=grid,seed=seed,tick=tick,flag=flag,ham=signed[0,0],radial_defect=signed[1,0],polar_defect=signed[2,0],
                               radial_current=signed[4,0],polar_current=signed[5,0]))
                idx=tick//32;hub=hubble[idx]/(32*scales[idx])
                loc=model.shell.r*scales[idx]
                for scope,fields in (("host-and-zero-separately",(full.astype(float),zero.astype(float))),("signed-host",(signed,))):
                    for cut in keys:
                        stop=np.searchsorted(loc,cut)+1
                        maxima=sum(np.max(abs(item[:3,:stop]),axis=1) for item in fields)
                        for label in ("0.15","0.3","difference"):
                            aa,ii=abs(coefficients(label))
                            weights=np.array([aa*cut**5/10,3*abs(hub)*(ii*cut**4/10+aa*cut**6/21),
                                3*abs(hub)*(3*ii*cut**4/10+aa*cut**6/14)])
                            key=(scope,cut,label)
                            accum[key]=accum.get(key,np.zeros(3))+1024*weights*maxima/unit
                            edges=np.r_[0.,loc[loc<cut],cut]
                            endpoint=np.searchsorted(loc,edges[1:])
                            limit=sum(np.maximum(abs(item[:3,endpoint]),abs(item[:3,np.maximum(endpoint-1,0)])) for item in fields)
                            diff4,diff5,diff6=(np.diff(edges**power) for power in (4,5,6))
                            shellweights=np.stack((aa*diff5/10,3*abs(hub)*(ii*diff4/10+aa*diff6/21),
                                    3*abs(hub)*(3*ii*diff4/10+aa*diff6/14)))
                            shell_bounds[key]=shell_bounds.get(key,np.zeros(3))+1024*(shellweights*limit).sum(axis=1)/unit
    rows=[]
    for (scope,cut,label),parts in accum.items():
        rows.append(dict(grid=grid,seed=seed,scope=scope,radius=cut,window=label,ham_bound=parts[0],radial_current_bound=parts[1],
            polar_current_bound=parts[2],total_bound=sum(parts),unit=unit))
    put(f"central-bound-g{grid}-s{seed}.csv",rows);put(f"central-raw-g{grid}-s{seed}.csv",rawrows)
    refined=[]
    for (scope,cut,label),parts in shell_bounds.items():
        assert np.all(parts<=accum[scope,cut,label]*(1+1e-12))
        refined.append(dict(grid=grid,seed=seed,scope=scope,radius=cut,window=label,ham_bound=parts[0],radial_current_bound=parts[1],polar_current_bound=parts[2],total_bound=sum(parts),unit=unit))
    put(f"central-shell-bounds-g{grid}-s{seed}.csv",refined)
    print(grid,seed,[(row["radius"],row["total_bound"]) for row in rows if row["scope"]=="host-and-zero-separately" and row["window"]=="0.15"],flush=True)

if __name__=="__main__":
    put("central-weight-controls.csv",fixture())
    run(*map(int,sys.argv[1:]))
