"""Keep fine integration sites; degrade only the ruler or only the tidal profile."""
from aperture_origin import *
from types import SimpleNamespace

def run(grid,seed):
    assert task.lab.sha(PARENT/"seal.json")==PIN
    pins=task.meta(PARENT/"seal.json")["files"]
    samples={}
    for flag in (0,1):
        with task.system(grid,seed,flag) as model:
            for tick in (0,*task.CLOCKS):
                task.guard()
                if grid==960:
                    from finer_grid import check
                    pin=check()
                    source=HERE/f"fine960-b{flag}-t{tick}.npz"
                    receipt=task.meta(source.with_suffix(".json"))
                    assert receipt["pin"]==pin and receipt["sha"]==task.lab.sha(source)
                else:
                    source=validate(PARENT/(name(grid,seed,flag,"off",tick)+".npz"),pins)
                with np.load(source) as bank:
                    state=task.old.Difference(bank["base" if grid==960 else "shared"],bank["delta" if grid==960 else "signed"])
                    clock=float(bank["clock"])
                raw,fields=physical_read(model,state,clock,"off")
                if tick==0:
                    starts={key:fields[key] for key in ("temporal","space")}
                    continue
                centers=model.shell.r
                sparse=(np.arange(960)+.5)/320
                def spline(pos,arr):
                    return CubicSpline(np.r_[-pos[:8][::-1],pos],np.concatenate((arr[...,:8][...,::-1],arr),axis=-1),axis=-1)
                def project(arr,scheme):
                    if scheme=="point":return spline(sparse,spline(centers,arr)(sparse))(centers)
                    offset=arr[...,:1]
                    antiderivative=spline(centers,arr-offset).antiderivative()
                    faces=np.arange(961)/320
                    primitive=antiderivative(faces)-antiderivative(0.)[...,None]
                    extended=np.concatenate((-primitive[...,1:9][...,::-1],primitive),axis=-1)
                    reconstructed=CubicSpline(np.r_[-faces[1:9][::-1],faces],extended,axis=-1)
                    return offset+reconstructed(centers,1)
                def paired(arr,scheme):
                    return task.old.Difference(project(arr.base,scheme),project(arr.delta,scheme))
                for scheme in ("point","conservative"):
                    def shell(own):
                        return SimpleNamespace(r=centers,dx=model.shell.dx,initial=project(own.initial[:3].real,scheme))
                    ruler=SimpleNamespace(host=shell(model.host),zero=shell(model.zero))
                    for key,initial in starts.items():
                        delta=fields[key]-initial
                        smooth=paired(initial,scheme)
                        smoothed=smooth+paired(delta,scheme)
                        for control,reader,metric,begin,end in (
                                ("native",model,raw,initial,fields[key]),("ruler",ruler,paired(raw[:1].real,scheme),initial,fields[key]),
                                ("field",model,raw,smooth,smoothed),("both",ruler,paired(raw[:1].real,scheme),smooth,smoothed)):
                            samples[flag,tick,key,scheme,control]=observer.annuli(reader,metric,begin,end)
    data=[]
    for row in task.read(validate(PARENT/f"g640-s{seed}-off-newton-twin1024.csv",pins)):
        tick,width,key=int(row["tick"]),float(row["width"]),row["reader"]
        for scheme in ("point","conservative"):
            def get(control):
                return (samples[0,tick,key,scheme,control]-samples[1,tick,key,scheme,control])[WIDTHS.index(width)]
            reference=get("native");unit=abs(float(row["native_newton"]))*1e-6
            ruler,field,both=((get(control)-reference)/unit for control in ("ruler","field","both"))
            data.append(dict(grid=grid,seed=seed,tick=tick,width=width,reader=key,scheme=scheme,ruler_ppm=ruler,
                   field_ppm=field,both_ppm=both,interaction_ppm=both-ruler-field))
    put(f"crossed-sampling-g{grid}-s{seed}.csv",data)
    print(grid,seed,[(row["scheme"],row["ruler_ppm"],row["field_ppm"],row["both_ppm"]) for row in data if row["tick"]==1024 and row["reader"]=="temporal" and row["width"]==.15],flush=True)

if __name__=="__main__":run(*map(int,sys.argv[1:]))
