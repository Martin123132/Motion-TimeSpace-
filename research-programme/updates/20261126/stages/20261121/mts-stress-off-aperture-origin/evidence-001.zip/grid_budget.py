"""Separate common and shape drift, with no new data fit or physical parameter."""
from aperture_origin import *
from scipy.optimize import brentq

def order_from(ratio):
    def law(power):return np.expm1(np.log(2)*power)/(-np.expm1(np.log(2/3)*power))
    if not law(.01)<ratio<law(10.):return ""
    return brentq(lambda power:law(power)-ratio,.01,10.)

def run():
    rows=[];shape=[]
    for seed,prefix in ((1,""),(-1,"negative-")):
        members=task.read(HERE/(prefix+"grid-scores.csv"))
        for item in members:
            coarse,middle,fresh=(float(item[key]) for key in ("n320","n640","n960"))
            ratio=(coarse-middle)/(middle-fresh) if middle!=fresh else 0.
            order=order_from(ratio)
            old=(4*middle-coarse)/3
            newest=(9*fresh-4*middle)/5
            rows.append(dict(seed=seed,tick=item["tick"],width=item["width"],reader=item["reader"],n960=fresh,
                reduction=abs(fresh)/abs(middle) if middle else "",rate_ratio=ratio,effective_order=order,
                intercept_320_640=old,intercept_640_960=newest,intercept_shift=newest-old,finest_20ppm=abs(fresh)<=20))
        for tick in task.CLOCKS:
            for label in ("temporal","space"):
                pair=[next(row for row in members if int(row["tick"])==tick and row["reader"]==label and float(row["width"])==width) for width in WIDTHS]
                key="native_newton" if seed<0 else "native"
                stretch=abs(float(pair[1][key])/float(pair[0][key]))
                for grid in (320,640,960):
                    first,second=(float(item["n"+str(grid)]) for item in pair)
                    shape.append(dict(seed=seed,tick=tick,reader=label,grid=grid,narrow=first,wide_on_narrow_scale=second*stretch,
                                      common=(first+second*stretch)/2,shape=first-second*stretch))
    put("grid-rate-budget.csv",rows);put("grid-common-and-shape.csv",shape)
    for seed in (1,-1):
        temporal=[row for row in rows if row["seed"]==seed and row["reader"]=="temporal"]
        print(seed,[(row["width"],row["n960"],row["effective_order"],row["intercept_640_960"]) for row in temporal if row["tick"]=="1024"])
    return rows,shape
if __name__=="__main__":run()
