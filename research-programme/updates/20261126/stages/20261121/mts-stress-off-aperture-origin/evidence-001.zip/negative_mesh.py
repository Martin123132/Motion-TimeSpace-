"""Second signed formation: measure the outer bracket then predict a withheld finer grid."""
from aperture_origin import *
from stress_switch import switched,guard as inherited_guard

def guard():
    inherited_guard()
    if (HERE/"STOP-REQUESTED").exists():raise RuntimeError("Owner hold")

def declaration():
    guard()
    assert task.lab.sha(PARENT/"seal.json")==PIN
    return {"authority":PIN,"study":task.lab.sha(HERE/"NEGATIVE-GRID.md"),"method":task.lab.sha(Path(__file__))}

def json_put(filename,value):
    task.lab.put(HERE/filename,(json.dumps(value,indent=2,allow_nan=False)+"\n").encode())

def prefix(grid,flag,tick):
    return HERE/f"negative-g{grid}-b{flag}-t{tick}.npz"

def verify_step(path,signature):
    rec=task.meta(path.with_suffix(".json"))
    assert rec["receipt"]==signature and task.lab.sha(path)==rec["sha"]
    return rec

def signature(grid):
    spec=declaration()
    assert task.meta(HERE/"negative-design.json")==spec
    if grid==960:
        frozen=task.meta(HERE/"negative-freeze.json")
        verify_files=frozen["files"]
        for filename in verify_files:validate(HERE/filename,verify_files)
        assert frozen["receipt"]==spec
        return task.lab.sha(HERE/"negative-freeze.json")
    assert grid==320
    return task.lab.sha(HERE/"negative-design.json")

def run(grid,flag):
    sig=signature(grid)
    ticks=(0,*task.CLOCKS)
    with task.system(grid,-1,flag) as model:
        assert len(model.shell.r)==3*grid and flag in (0,1)
        state=np.zeros_like(model.shell.initial)
        step=4096*np.pi/(1024*model.shell.mu)
        raw,start=physical_read(model,state,0.,"off")
        last=-1
        for tick in ticks:
            path=prefix(grid,flag,tick)
            if not path.with_suffix(".json").exists():
                assert not path.exists() and not any(prefix(grid,flag,future).exists() for future in ticks if future>tick)
                break
            verify_step(path,sig);last=tick
        if last==1024:return
        if last>=0:
            with np.load(prefix(grid,flag,last)) as bank:state=task.old.Difference(bank["base"],bank["delta"])
        for tick in ticks:
            if tick<=last:continue
            guard()
            with switched(model,"off"):
                advance=model.time_step(step)
                for count in range(max(0,last),tick):
                    if count%8==0:guard()
                    state=advance(count*step,state)
            raw,forms=physical_read(model,state,tick*step,"off")
            saved=dict(base=state.base,delta=state.delta,radius=model.shell.r,clock=tick*step)
            measured={}
            if tick:
                for key in ("temporal","space"):
                    measured[key]=list(map(float,observer.annuli(model,raw,start[key],forms[key])))
                checks=task.compute(model,state,tick*step)
                for key in ("ind_P","ind_J","ind_H"):saved[key]=checks[key]
            assert model.mass.min_branch>0 and (flag or (model.min_number>0 and model.min_factor>0))
            assert all(np.isfinite(value).all() for value in saved.values())
            stream=io.BytesIO()
            np.savez_compressed(stream,**saved)
            path=prefix(grid,flag,tick)
            task.lab.put(path,stream.getvalue())
            json_put(path.with_suffix(".json").name,dict(receipt=sig,sha=task.lab.sha(path),tick=tick,readings=measured))
            print(grid,flag,tick,flush=True)
            last=tick

def score(grid,row):
    sig=signature(grid)
    tick=int(row["tick"]);width=float(row["width"])
    two=[verify_step(prefix(grid,flag,tick),sig)["readings"][row["reader"]][WIDTHS.index(width)] for flag in (0,1)]
    return (two[0]-two[1]-float(row["newton_twin"]))/(abs(float(row["native_newton"]))*1e-6)

def freeze():
    spec=declaration()
    pins=task.meta(PARENT/"seal.json")["files"]
    base=task.read(validate(PARENT/"g640-s-1-off-newton-twin1024.csv",pins))
    output=[]
    for item in base:
        coarse=score(320,item);fine=float(item["altered_tide_minus_twin_ppm"])
        output.append(dict(tick=item["tick"],width=item["width"],reader=item["reader"],native_newton=item["native_newton"],newton_twin=item["newton_twin"],
                           n320=coarse,n640=fine,n960_constant=fine,n960_linear=fine-(coarse-fine)/3,
                           n960_quadratic=fine-5*(coarse-fine)/27,quadratic_intercept=(4*fine-coarse)/3))
    put("negative-grid-forecast.csv",output)
    names=["negative-grid-forecast.csv","negative-design.json",*[prefix(320,flag,tick).with_suffix(".json").name for flag in (0,1) for tick in (0,*task.CLOCKS)]]
    json_put("negative-freeze.json",dict(receipt=spec,files={filename:task.lab.sha(HERE/filename) for filename in names}))

def grade():
    rows=[]
    for line in task.read(HERE/"negative-grid-forecast.csv"):
        value=score(960,line)
        errs={key:abs(value-float(line["n960_"+key])) for key in ("constant","linear","quadratic")}
        rows.append(dict(**line,n960=value,inside=abs(value)<=20,**{key+"_error":err for key,err in errs.items()},best=min(errs,key=errs.get)))
    put("negative-grid-scores.csv",rows)
    diag=[]
    for grid in (320,960):
        for flag in (0,1):
            for tick in task.CLOCKS:
                path=prefix(grid,flag,tick)
                verify_step(path,signature(grid))
                with np.load(path) as bank:
                    radius=bank["radius"]
                    for key,mask in (("first",radius<1/grid),("core",radius<.3),("bulk",(radius>.6)&(radius<2.1))):
                        pp=np.linalg.norm(bank["ind_P"][mask]);jj=np.linalg.norm(bank["ind_J"][mask])
                        diag.append(dict(grid=grid,tick=tick,flag=flag,region=key,ham_norm=np.linalg.norm(bank["ind_H"][mask]),
                                         momentum_norm=pp,current_norm=jj,ratio=pp/jj if jj else ""))
    put("negative-central-controls.csv",diag)
    print([(r["width"],r["n960"],r["quadratic_error"]) for r in rows if r["tick"]=="1024" and r["reader"]=="temporal"])

if __name__=="__main__":
    if sys.argv[1:]==["all"]:
        json_put("negative-design.json",declaration())
        for flag in (0,1):run(320,flag)
        freeze()
        for flag in (0,1):run(960,flag)
        grade()
    else:raise ValueError("Use all; verified restarts skip completed work.")
