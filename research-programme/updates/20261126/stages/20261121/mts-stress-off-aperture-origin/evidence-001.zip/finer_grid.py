"""Frozen mesh predictions and retained formation evolution on a third grid."""
from aperture_origin import *
from follow_source import switched
from stress_switch import guard as inherited_guard

GRID=960
SEED=1
TICKS=tuple(range(0,1025,128))

def check_hold():
    inherited_guard()
    if (HERE/"STOP-REQUESTED").exists():raise RuntimeError("Owner hold")

def freeze():
    check_hold()
    assert task.lab.sha(PARENT/"seal.json")==PIN
    pins=task.meta(PARENT/"seal.json")["files"]
    tables=[task.read(validate(PARENT/f"g{grid}-s1-off-newton-twin1024.csv",pins)) for grid in (320,640)]
    rows=[]
    for coarse,fine in zip(*tables,strict=True):
        for key in ("width","reader","tick","newton_twin","native_newton"):
            assert coarse[key]==fine[key]
        large,small=(float(record["altered_tide_minus_twin_ppm"]) for record in (coarse,fine))
        rows.append(dict(tick=fine["tick"],width=fine["width"],reader=fine["reader"],native=float(fine["native_newton"]),
            twin=float(fine["newton_twin"]),n320=large,n640=small,n960_constant=small,
            n960_linear=small-(large-small)/3,n960_quadratic=small-5*(large-small)/27,
            quadratic_intercept=(4*small-large)/3))
    put("grid-forecast.csv",rows)
    bind={key:task.lab.sha(HERE/key) for key in ("GRID-TEST.md","grid-forecast.csv","finer_grid.py")}
    manifest=dict(parent=PIN,files=bind)
    task.lab.put(HERE/"grid-freeze.json",(json.dumps(manifest,indent=2)+"\n").encode())

def check():
    check_hold()
    assert task.lab.sha(PARENT/"seal.json")==PIN
    freeze=task.meta(HERE/"grid-freeze.json")
    assert freeze["parent"]==PIN
    for filename in freeze["files"]:validate(HERE/filename,freeze["files"])
    return task.lab.sha(HERE/"grid-freeze.json")

def evolve(flag):
    prediction=check()
    assert flag in (0,1)
    with task.system(GRID,SEED,flag) as model:
        assert len(model.shell.r)==3*GRID and abs(model.shell.dx*GRID-1)<2e-14
        step=4096*np.pi/(1024*model.shell.mu)
        zero=np.zeros_like(model.shell.initial)
        start_state=task.old.Difference(zero.base.copy(),zero.delta.copy())
        assert not start_state.base.any() and not start_state.delta.any()
        _,initial=physical_read(model,start_state,0.,"off")
        state=start_state
        def path(tick):return HERE/f"fine960-b{flag}-t{tick}.npz"
        previous=-1
        for tick in TICKS:
            check_hold()
            if not path(tick).with_suffix(".json").exists():
                assert not path(tick).exists() and not any(path(later).exists() for later in TICKS if later>tick)
                break
            record=task.meta(path(tick).with_suffix(".json"))
            assert record["pin"]==prediction and record["sha"]==task.lab.sha(path(tick))
            previous=tick
        if previous==1024:return
        if previous>=0:
            with np.load(path(previous)) as packet:state=task.old.Difference(packet["base"],packet["delta"])
        with switched(model,"off"):
            advance=model.time_step(step)
            for tick in range(previous+1,1025):
                if tick%8==0:check_hold()
                if tick:state=advance((tick-1)*step,state)
                if tick not in TICKS:continue
                clock=tick*step
                stored=dict(base=state.base,delta=state.delta,radius=model.shell.r,clock=clock)
                assert all(np.isfinite(value).all() for value in stored.values())
                readings={}
                if tick in task.CLOCKS:
                    raw,data=observer.fields(model,GRID,12,state,clock,False)
                    from stress_switch import budget
                    from trial import pair
                    correction=budget(model,state,clock,"off")[0]
                    data["space"]=data["space"]+pair(0*correction,correction)
                    for key in ("temporal","space"):
                        entries=observer.annuli(model,raw,initial[key],data[key])
                        readings[key]=list(map(float,entries))
                    guards=task.compute(model,state,clock)
                    for key in ("ind_H","ind_P","ind_J"):
                        stored[key]=guards[key]
                    assert model.mass.min_branch>0 and (flag or (model.min_number>0 and model.min_factor>0))
                stream=io.BytesIO()
                np.savez_compressed(stream,**stored)
                task.lab.put(path(tick),stream.getvalue())
                cert=dict(tick=tick,pin=prediction,sha=task.lab.sha(path(tick)),readings=readings)
                task.lab.put(path(tick).with_suffix(".json"),(json.dumps(cert,indent=2,allow_nan=False)+"\n").encode())
                print(flag,tick,flush=True)

def grade():
    pin=check()
    rows=[]
    diagnostics=[]
    for item in task.read(HERE/"grid-forecast.csv"):
        tick=int(item["tick"]);key=item["reader"];width=float(item["width"])
        values=[]
        for flag in (0,1):
            path=HERE/f"fine960-b{flag}-t{tick}.npz"
            cert=task.meta(path.with_suffix(".json"))
            assert cert["pin"]==pin and cert["sha"]==task.lab.sha(path)
            values.append(cert["readings"][key][WIDTHS.index(width)])
            if width==.15 and key=="temporal":
                with np.load(path) as stored:
                    for label,mask in (("first",stored["radius"]<1/GRID),("core",stored["radius"]<.3),("bulk",(stored["radius"]>.6)&(stored["radius"]<2.1))):
                        current=np.linalg.norm(stored["ind_J"][mask]);moment=np.linalg.norm(stored["ind_P"][mask])
                        diagnostics.append(dict(tick=tick,flag=flag,region=label,ham_norm=np.linalg.norm(stored["ind_H"][mask]),
                            momentum_norm=moment,current_norm=current,ratio=moment/current if current else ""))
        scale=abs(float(item["native"]))*1e-6
        measured=(values[0]-values[1]-float(item["twin"]))/scale
        err=[abs(measured-float(item["n960_"+mode])) for mode in ("constant","linear","quadratic")]
        rows.append(dict(**item,n960=measured,inside=abs(measured)<=20,constant_error=err[0],linear_error=err[1],quadratic_error=err[2],
            best=("constant","linear","quadratic")[np.argmin(err)]))
    put("grid-scores.csv",rows);put("grid-central-controls.csv",diagnostics)
    print([(item["width"],item["n960"],item["quadratic_error"],item["best"]) for item in rows if item["tick"]=="1024" and item["reader"]=="temporal"])
if __name__=="__main__":
    if sys.argv[1:]==["freeze"]:freeze()
    elif sys.argv[1:]==["grade"]:grade()
    else:evolve(int(sys.argv[1]))
