"""Resample identical stored tidal and metric fields, never re-evolve the coarse model."""
from aperture_origin import *
from types import SimpleNamespace

def scan(grid,seed):
    checkpins=task.meta(PARENT/"seal.json")["files"]
    assert task.lab.sha(PARENT/"seal.json")==PIN
    snapshots={}
    for flag in (0,1):
        with task.system(grid,seed,flag) as model:
            for tick in (0,*task.CLOCKS):
                task.guard()
                if grid==960:
                    from finer_grid import check
                    pin=check()
                    path=HERE/f"fine960-b{flag}-t{tick}.npz"
                    receipt=task.meta(path.with_suffix(".json"))
                    assert receipt["pin"]==pin and receipt["sha"]==task.lab.sha(path)
                else:
                    stem=name(grid,seed,flag,"off",tick)
                    path=validate(PARENT/(stem+".npz"),checkpins)
                    receipt=task.meta(validate(PARENT/(stem+".json"),checkpins))
                with np.load(path) as bank:
                    state=task.old.Difference(bank["base" if grid==960 else "shared"],bank["delta" if grid==960 else "signed"])
                    clock=float(bank["clock"])
                raw,field=physical_read(model,state,clock,"off")
                if tick==0:
                    starts={label:field[label] for label in ("temporal","space")}
                    continue
                for target in (320,grid):
                    def convert(data):
                        if grid==target:return data
                        rad=(np.arange(3*target)+.5)/target
                        if grid==3*target:
                            np.testing.assert_allclose(rad,model.shell.r[1::3],rtol=2e-15,atol=0.)
                            return data[...,1::3]
                        native=model.shell.r
                        knots=np.r_[-native[:8][::-1],native]
                        return CubicSpline(knots,np.concatenate((data[...,:8][...,::-1],data),axis=-1),axis=-1)(rad)
                    def convert_pair(data):
                        return task.old.Difference(convert(data.base),convert(data.delta))
                    def shell(source):
                        return SimpleNamespace(r=(np.arange(3*target)+.5)/target,dx=1/target,initial=convert(source.initial[:3].real))
                    adapter=SimpleNamespace(host=shell(model.host),zero=shell(model.zero)) if target!=grid else model
                    shift=convert_pair(raw[:1].real)
                    for key,initial in starts.items():
                        start=convert_pair(initial)
                        now=start+convert_pair(field[key]-initial)
                        reading=observer.annuli(adapter,shift,start,now)
                        if target==grid:
                            sealed=receipt["readings"][key] if grid==960 else [receipt["readings"][f"{key}-{width}"] for width in WIDTHS]
                            np.testing.assert_allclose(reading,sealed,rtol=2e-13,atol=1e-34)
                        snapshots[flag,tick,target,key]=reading
    data=[]
    for row in task.read(validate(PARENT/f"g640-s{seed}-off-newton-twin1024.csv",checkpins)):
        tick,key,width=int(row["tick"]),row["reader"],float(row["width"])
        def result(target):return (snapshots[0,tick,target,key]-snapshots[1,tick,target,key])[WIDTHS.index(width)]
        value=result(grid);sampled=result(320);unit=1e-6*abs(float(row["native_newton"]))
        data.append(dict(grid=grid,seed=seed,tick=tick,reader=key,width=width,native_grid=value,measured_on320=sampled,
                         sampling_shift_ppm=(sampled-value)/unit))
    put(f"ruler-sampling-g{grid}-s{seed}.csv",data)
    print(grid,seed,"largest isolated measurement drift",max(abs(row["sampling_shift_ppm"]) for row in data),flush=True)

if __name__=="__main__":
    scan(*map(int,sys.argv[1:]))
