"""Direct Einstein-tensor test of the longitudinal Newton limit and retained radial witness."""
from current_projection import filters,COEFFICIENTS
from aperture_origin import *
from scipy.integrate import simpson
import sympy as algebra

def geometry(make,time,place,eps):
    values=np.asarray(make(time,place,eps),dtype=complex)
    base,first,second=values[:4],np.zeros((4,4,4),complex),np.zeros((4,4,4,4),complex)
    for axis,offset in ((0,4),(1,8)):
        first[axis]=np.diag(values[offset:offset+4])
    for left,right,offset in ((0,0,12),(0,1,16),(1,0,16),(1,1,20)):
        second[left,right]=np.diag(values[offset:offset+4])
    inverse=np.diag(1/base)
    ch=(first.transpose(1,0,2)+first.transpose(1,2,0)-first)/2
    def riemann(one,two,three,four):
        principal=(second[two,three,one,four]+second[one,four,two,three]-second[two,four,one,three]-second[one,three,two,four])/2
        return principal+ch[:,two,three]@inverse@ch[:,one,four]-ch[:,two,four]@inverse@ch[:,one,three]
    ric=np.array([[sum(riemann(idx,left,idx,right)/base[idx] for idx in range(4)) for right in range(4)] for left in range(4)])
    mixed=ric.diagonal()/base
    tidal=np.array([riemann(idx,0,idx,0)/base[idx] for idx in (1,2,3)])
    return np.array([ric[0,0]+sum(mixed)/2,mixed[1]-np.mean(mixed[1:]),-tidal[0]+np.mean(tidal),ric[0,1]])

def exact_metric():
    time,place,eps=algebra.symbols("t z e")
    rows=[]
    for mode in ("stress-free","stressed","static-background"):
        scale=1+time/3+time**2/9 if mode!="static-background" else algebra.Integer(1)
        hub=scale.diff(time)/scale
        scalar=(1+time+time**2+time**3/3)/9
        curvature=(scale**2*(scalar.diff(time,2)+3*hub*scalar.diff(time)) if mode=="stress-free" else (1+time+time**2)/7)
        for freq in (1,3):
            shape=algebra.cos(freq*place)
            along=scale**2*(1+2*eps*(curvature-freq**2*scalar)*shape)
            transverse=scale**2*(1+2*eps*curvature*shape)
            metric=algebra.Matrix([-1,along,transverse,transverse])
            operands=[metric,metric.diff(time),metric.diff(place),metric.diff(time,2),metric.diff(time,place),metric.diff(place,2)]
            evaluate=algebra.lambdify((time,place,eps),list(algebra.Matrix.vstack(*operands)),"numpy")
            for instant in (0.,.25,.5):
                step=1e-20j
                density,stress,tide,_=geometry(evaluate,instant,0.,step).imag/step.imag
                potential=geometry(evaluate,instant,np.pi/(2*freq),step).imag[-1]/(step.imag*freq)
                expansion=float(hub.subs(time,instant))
                predicted=-(density-3*expansion*potential)/3+stress
                assert abs(tide-predicted)<1e-13
                if mode=="stress-free":assert abs(stress)<1e-13
                if mode!="static-background":assert abs(tide-(-density/3+stress))>1e-3
                rows.append(dict(mode=mode,k=freq,t=instant,energy=density,anisotropy=stress,current_potential=potential,
                                 tidal=tide,combined=predicted,without_current=-density/3+stress,error=tide-predicted))
    return rows

def evaluate(grid,seed,pins):
    with np.load(validate(task.FORM/f"matched-source-history-p32-s{seed}.npz",task.meta(task.FORM/"seal.json")["files"])) as history:
        scales=history["b"].copy()
    actual={}
    for flag in (0,1):
        with task.system(grid,seed,flag) as model:
            for tick in (0,*task.CLOCKS):
                stem=name(grid,seed,flag,"off",tick)
                with np.load(validate(PARENT/(stem+".npz"),pins)) as packet:
                    state=task.old.Difference(packet["shared"],packet["signed"]);clock=float(packet["clock"])
                raw,field=physical_read(model,state,clock,"off")
                actual[flag,tick]=energy_terms(model,raw,field,clock)
    current=task.read(HERE/"current-and-curvature.csv")
    budget=task.read(HERE/"aperture-budget.csv")
    data=[]
    for tick in task.CLOCKS:
        unit=float(next(row["unit"] for row in budget if int(row["grid"])==grid and int(row["seed"])==seed and int(row["tick"])==tick))
        scale=scales[tick//32]
        cells=(np.arange(grid*3)+.5)/grid
        knots=np.r_[-cells[3::-1],cells]
        for size,mode in ((8192,"cubic"),(16384,"cubic"),(8192,"linear")):
            axis,kernel,mean,_,_=filters(size)
            values={}
            for key in ("spatial","temporal","energy","stress"):
                base=actual[0,0][key]-actual[1,0][key]
                now=actual[0,tick][key]-actual[1,tick][key]
                def interp(field,at):
                    extended=np.r_[field[3::-1],field]
                    return CubicSpline(knots,extended)(at) if mode=="cubic" else np.interp(at,knots,extended)
                inc=interp(now-base,axis/scale)+(interp(base,axis/scale)-interp(base,axis))
                values[key]=1024*simpson((COEFFICIENTS@(kernel if key=="energy" else mean))*inc,x=axis)/unit
            drift=float(next(row["projected_current_ppm"] for row in current if int(row["grid"])==grid and int(row["seed"])==seed and int(row["tick"])==tick and int(row["samples"])==size and row["interpolation"]==mode))
            prediction=values["energy"]+drift+values["stress"]
            data.append(dict(grid=grid,seed=seed,tick=tick,samples=size,interpolation=mode,**values,scalar_current=drift,
                             predicted=prediction,space_minus_scalar=values["spatial"]-prediction,time_minus_scalar=values["temporal"]-prediction))
    return data

if __name__=="__main__":
    put("scalar-metric-controls.csv",exact_metric())
    task.guard()
    assert task.lab.sha(PARENT/"seal.json")==PIN
    pins=task.meta(PARENT/"seal.json")["files"]
    rows=[]
    for grid,seed in task.RUNS:rows.extend(evaluate(grid,seed,pins))
    put("scalar-limit-readings.csv",rows)
    print([(row["grid"],row["seed"],row["time_minus_scalar"]) for row in rows if row["tick"]==1024 and row["samples"]==16384])
