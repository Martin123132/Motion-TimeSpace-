"""Quantify the single exterior longitudinal-current moment in the original two-window contrast."""
from current_projection import extract,filters,COEFFICIENTS
from aperture_origin import *
from scipy.integrate import cumulative_simpson,simpson

IEXACT=CENTER**2*(.30**2-.15**2)/42

@lru_cache(maxsize=4)
def radial_weights(size):
    axis,response,mean,_,_=filters(size)
    scale=axis.copy();scale[0]=1e-20
    pair=response[0]-response[-1]
    inside=cumulative_simpson(pair*scale**2,x=axis,initial=0.)
    outer=cumulative_simpson((pair/scale**3)[::-1],x=-axis[::-1],initial=0.)[::-1]
    assert abs(inside[-1]-IEXACT)<2e-12
    return axis,(2*scale**3*outer-3*inside/scale**2)/5,6*(scale**3*outer+inside/scale**2)/5

def fixture():
    rows=[]
    for size in (8192,16384):
        inner,lft,rt=radial_weights(size)
        radial=lambda axis:2*axis*(1-axis**2)*np.exp(-axis**2)
        polar=lambda axis:axis*np.exp(-axis**2)
        test=lambda axis:axis**2*np.exp(-axis**2)
        _,kern,_,_,_=filters(size)
        actual=simpson((kern[0]-kern[2])*test(inner),x=inner)
        mass=simpson(lft*radial(inner)+rt*polar(inner),x=inner)
        boundary=IEXACT*3*np.exp(-inner[-1]**2)/5
        assert abs(actual-mass-boundary)<1e-11 and abs(boundary)>1e-5
        rows.append(dict(size=size,direct=actual,local=mass,exterior=boundary,error=actual-mass-boundary))
    return rows

def run(grid,seed,pins):
    data=extract(grid,seed,pins)
    current=task.read(HERE/"current-and-curvature.csv")
    previous=task.read(HERE/"aperture-budget.csv")
    with np.load(validate(task.FORM/f"matched-source-history-p32-s{seed}.npz",task.meta(task.FORM/"seal.json")["files"])) as history:
        scales,hubble=history["b"].copy(),history["hubble"].copy()
    cells=(np.arange(3*grid)+.5)/grid
    knots=np.r_[-cells[3::-1],cells]
    rows=[]
    for tick in task.CLOCKS:
        unit=float(next(item["unit"] for item in previous if int(item["grid"])==grid and int(item["seed"])==seed and int(item["tick"])==tick))
        target=next(item for item in previous if int(item["grid"])==grid and int(item["seed"])==seed and int(item["tick"])==tick and item["order"]=="16")
        for size in (8192,16384):
            axis,left,right=radial_weights(size)
            _,response,mean,three_r,three_t=filters(size)
            hub=lambda idx:hubble[idx]/(32*scales[idx])
            def weighted(key,radius):
                signed=lambda when:data[0,when][key]-data[1,when][key]
                initial=signed(0)
                parity=-1 if key in ("radial","polar") else 1
                def at(arr,place):return CubicSpline(knots,np.r_[parity*arr[3::-1],arr])(place)
                scale=scales[tick//32]
                start=at(initial,radius)
                drift=at(signed(tick)-initial,radius/scale)+(at(initial,radius/scale)-start)
                return hub(tick//32)*drift+(hub(tick//32)-hub(0))*start
            radial,polar=(weighted(key,axis) for key in ("radial","polar"))
            norm=-3*1024/unit
            core=norm*simpson(left*radial+right*polar,x=axis)
            bound=abs(norm)*simpson(abs(left*radial)+abs(right*polar),x=axis)
            three=norm*simpson(three_r*radial+three_t*polar,x=axis)
            bound3=abs(norm)*simpson(abs(three_r*radial)+abs(three_t*polar),x=axis)
            reference=next(float(row["projected_current_ppm"]) for row in current if int(row["grid"])==grid and int(row["seed"])==seed and int(row["tick"])==tick and int(row["samples"])==size and row["interpolation"]=="cubic")
            assert abs(reference-three)<1e-11
            measured=1024*simpson((mean[0]-mean[2])*weighted("shear",axis)+2*(response[0]-response[2])*weighted("trace",axis),x=axis)/unit
            for edge in (2.,2.5,2.8):
                ext=np.linspace(axis[-1],edge,1025)
                one,two=weighted("radial",ext),weighted("polar",ext)
                shell=norm*IEXACT*simpson((-3*one+6*two)/(5*ext**2),x=ext)
                shell_abs=abs(norm)*IEXACT*simpson((3*abs(one)+6*abs(two))/(5*ext**2),x=ext)
                known=core+shell;size_bound=bound+shell_abs
                required=(measured-known)/(norm*IEXACT)
                assert abs(known)<=size_bound+1e-12 and abs(three)<=bound3+1e-12
                rows.append(dict(grid=grid,seed=seed,tick=tick,samples=size,edge=edge,unit=unit,
                    local_current_ppm=known,window_core_ppm=core,shell_ppm=shell,local_absolute_bound_ppm=size_bound,
                    three_current_ppm=three,three_absolute_bound_ppm=bound3,leading_shear_plus_trace_ppm=measured,
                    full_kinetic_ppm=float(target["constraint_kinetic"])+float(target["jacobi_kinetic"]),
                    required_exterior_delta_Hc=required,exterior_ppm_per_delta_Hc=norm*IEXACT,
                    possible_nonscalar_or_exterior_ppm=measured-known))
    return rows

if __name__=="__main__":
    task.guard()
    assert task.lab.sha(PARENT/"seal.json")==PIN
    put("exterior-current-controls.csv",fixture())
    pins=task.meta(PARENT/"seal.json")["files"]
    rows=[]
    for grid,seed in task.RUNS:
        batch=run(grid,seed,pins);rows.extend(batch)
        print(grid,seed,batch[-1],flush=True)
    put("two-window-current.csv",rows)
