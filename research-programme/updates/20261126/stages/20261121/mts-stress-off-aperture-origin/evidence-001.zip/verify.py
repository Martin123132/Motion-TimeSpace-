"""Audit inputs, outputs and the prospective finer-grid comparison without re-evolving."""
from aperture_origin import *
from finer_grid import TICKS,check
from current_projection import analytic
from scalar_limit import exact_metric
import re

def verify():
    pin=check()
    pins=task.meta(PARENT/"seal.json")["files"]
    for filename in pins:validate(PARENT/filename,pins)
    assert len(list(HERE.glob("fine960-*.npz")))==18
    for flag in (0,1):
        last=-1.
        for tick in TICKS:
            path=HERE/f"fine960-b{flag}-t{tick}.npz"
            receipt=task.meta(path.with_suffix(".json"))
            assert receipt["pin"]==pin and receipt["sha"]==task.lab.sha(path) and receipt["tick"]==tick
            with np.load(path) as bank:
                assert all(np.isfinite(bank[key]).all() for key in bank.files)
                assert bank["base"].shape==bank["delta"].shape and bank["base"].shape[-1]==2880
                assert np.all(np.diff(bank["radius"])>0)
                assert float(bank["clock"])>last
                last=float(bank["clock"])
                if not tick:assert not np.any(bank["base"]) and not np.any(bank["delta"])
                if tick in task.CLOCKS:assert {"temporal","space"}==set(receipt["readings"]) and {"ind_P","ind_H","ind_J"}<=set(bank.files)
    counts={"aperture-budget.csv":36,"controls.csv":4,"current-controls.csv":2,"scalar-limit-readings.csv":36,
        "scalar-metric-controls.csv":18,"current-and-curvature.csv":36,"grid-scores.csv":16,"grid-forecast.csv":16,
        "grid-central-controls.csv":24,"negative-grid-forecast.csv":16,"negative-grid-scores.csv":16,"negative-central-controls.csv":48,
        "grid-rate-budget.csv":32,"grid-common-and-shape.csv":48,"two-window-current.csv":72,"exterior-current-controls.csv":2,
        "sampling-phases-s1.csv":16,"sampling-phases-s-1.csv":16,"central-weight-controls.csv":3}
    for grid in (320,640,960):
        for seed in (1,-1):
            counts[f"central-bound-g{grid}-s{seed}.csv"]=24
            counts[f"central-shell-bounds-g{grid}-s{seed}.csv"]=24
            counts[f"central-raw-g{grid}-s{seed}.csv"]=4
            core=task.read(HERE/f"central-bound-g{grid}-s{seed}.csv")
            for row in core:
                parts=[float(row[key]) for key in ("ham_bound","radial_current_bound","polar_current_bound")]
                assert min(parts)>=0 and abs(sum(parts)-float(row["total_bound"]))<1e-10*max(1.,sum(parts))
    from negative_mesh import signature, prefix, verify_step
    assert len(list(HERE.glob("negative-g*-t*.npz")))==20
    for grid in (320,960):
        sig=signature(grid)
        for flag in (0,1):
            last=-1.
            for tick in (0,*task.CLOCKS):
                path=prefix(grid,flag,tick)
                rec=verify_step(path,sig)
                assert rec["tick"]==tick
                with np.load(path) as bank:
                    assert all(np.isfinite(bank[key]).all() for key in bank.files)
                    assert bank["base"].shape==bank["delta"].shape and bank["base"].shape[-1]==3*grid
                    assert np.all(np.diff(bank["radius"])>0) and float(bank["clock"])>last
                    last=float(bank["clock"])
                    if not tick:assert not bank["base"].any() and not bank["delta"].any()
                    else:assert {"temporal","space"}==set(rec["readings"]) and {"ind_P","ind_H","ind_J"}<=set(bank.files)
    for grid,seed in (*task.RUNS[:2],(960,1)):
        counts[f"ruler-sampling-g{grid}-s{seed}.csv"]=16
        counts[f"crossed-sampling-g{grid}-s{seed}.csv"]=32
    assert {path.name for path in HERE.glob("*.csv")}==set(counts)
    for filename,expected in counts.items():
        rows=task.read(HERE/filename)
        assert len(rows)==expected and all(None not in row and None not in row.values() for row in rows)
        for row in rows:
            for value in row.values():
                try:number=float(value)
                except ValueError:continue
                assert np.isfinite(number)
    for filename,source in (("controls.csv",controls()),("current-controls.csv",[analytic(size) for size in (8192,16384)]),("scalar-metric-controls.csv",exact_metric())):
        for saved,repeated in zip(task.read(HERE/filename),source,strict=True):
            for key,value in repeated.items():
                if isinstance(value,str):assert value==saved[key]
                else:assert abs(value-float(saved[key]))<=2e-13*max(1.,abs(value))
    scores=task.read(HERE/"grid-scores.csv")+task.read(HERE/"negative-grid-scores.csv")
    predictions=task.read(HERE/"grid-forecast.csv")+task.read(HERE/"negative-grid-forecast.csv")
    for index,(row,forecast) in enumerate(zip(scores,predictions,strict=True)):
        assert all(row[key]==value for key,value in forecast.items())
        negative=index>=16
        tick=int(row["tick"]); width=float(row["width"]); reader=row["reader"]
        two=[]
        for flag in (0,1):
            path=prefix(960,flag,tick) if negative else HERE/f"fine960-b{flag}-t{tick}.npz"
            two.append(task.meta(path.with_suffix(".json"))["readings"][reader][WIDTHS.index(width)])
        base=float(row["native_newton" if negative else "native"])
        twin=float(row["newton_twin" if negative else "twin"])
        assert abs((two[0]-two[1]-twin)/(abs(base)*1e-6)-float(row["n960"]))<1e-10
        assert (row["inside"]=="True")==(abs(float(row["n960"]))<=20)
        for label in ("constant","linear","quadratic"):
            assert abs(abs(float(row["n960"])-float(row["n960_"+label]))-float(row[label+"_error"]))<1e-12
        assert row["best"]==min(("constant","linear","quadratic"),key=lambda key:float(row[key+"_error"]))
    for grid,seed in task.RUNS:
        rows=[row for row in task.read(HERE/"aperture-budget.csv") if int(row["grid"])==grid and int(row["seed"])==seed]
        for row in rows:
            total=sum(float(row[name]) for name in ("ruler","time_vs_space","density_minus_twin","constraint_kinetic","jacobi_kinetic","stress","spatial_remainder"))
            assert abs(float(row["residual"])-total)<1e-6
            assert abs(float(row["narrow_residual"])-float(row["wide_residual"])-total)<1e-6
    from outer_current import fixture
    put("exterior-current-controls.csv",fixture())
    for row in task.read(HERE/"two-window-current.csv"):
        assert abs(float(row["local_current_ppm"]))<=float(row["local_absolute_bound_ppm"])+1e-12
        assert abs(float(row["three_current_ppm"]))<=float(row["three_absolute_bound_ppm"])+1e-12
        required=float(row["required_exterior_delta_Hc"])*float(row["exterior_ppm_per_delta_Hc"])
        assert abs(required+float(row["local_current_ppm"])-float(row["leading_shear_plus_trace_ppm"]))<1e-12
    for path in HERE.glob("*.md"):
        for target in re.findall(r"\[[^\]]*\]\(([^)]+)\)",path.read_text(encoding="utf-8")):
            if not target.startswith("https://"):assert (HERE/target).is_file(),target
    files={path.name:task.lab.sha(path) for path in sorted(HERE.iterdir()) if path.is_file() and path.name!="seal.json"}
    assert not any(path.is_dir() for path in HERE.iterdir())
    task.lab.put(HERE/"seal.json",(json.dumps(dict(parent=PIN,forecast=pin,files=files,rows=counts),indent=2)+"\n").encode())
    print("verified",len(files),"files",sum(counts.values()),"data rows",task.lab.sha(HERE/"seal.json"),flush=True)

if __name__=="__main__":verify()
