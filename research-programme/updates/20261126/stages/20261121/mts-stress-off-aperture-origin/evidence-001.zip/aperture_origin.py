"""Common-ruler versus proper-ruler stress-off tidal budget, from sealed histories."""
from pathlib import Path
import csv
import io
import json
import os
import sys
from functools import lru_cache

HERE = Path(__file__).resolve().parent
PARENT = HERE.parent / "mts-conserved-stress-intervention-20261121"
for key in ("OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS", "NUMEXPR_NUM_THREADS", "BLIS_NUM_THREADS"):
    os.environ[key] = "1"
sys.path.insert(0, str(PARENT))
from follow_source import physical_read, name, task, observer, np
from density_witness import density_kernel, CENTER, weight
from trial import mul, square
from scipy.interpolate import CubicSpline
from numpy.polynomial.legendre import leggauss

PIN = "190ba4f1ac4003b121489e0b2e8fd33dd29ed8bb7172f639f264540592e2d410"
WIDTHS = (.15, .30)

def validate(path, authority):
    assert task.lab.sha(path) == authority[path.name], path
    return path

def put(filename, rows):
    stream = io.StringIO(newline="")
    writer = csv.DictWriter(stream, rows[0].keys(), lineterminator="\n")
    writer.writeheader()
    writer.writerows(rows)
    task.lab.put(HERE / filename, stream.getvalue().encode())

def energy_terms(model, physical, field, clock):
    full = model.shell.initial + physical
    trace, shear = (full[slot].real for slot in (4, 5))
    energy = task.evolve8.sources(model, clock, physical)[0]
    stored = full[17].real
    return {key: value.delta[1].copy() for key, value in dict(energy=energy, reservoir=stored,
            constraint_kinetic=-square(trace)/3+3*square(shear)/4,
            jacobi_kinetic=-mul(trace,shear)/3+square(shear)/2, temporal=field["temporal"],
            spatial=field["space"], stress=field["stress"]).items()}

@lru_cache(maxsize=24)
def weights(grid, scale, order):
    grid_nodes = (np.arange(3*grid)+.5)/grid
    high = CENTER*1.3
    hinges = [CENTER*(1+side*width) for side in (-1,1) for width in WIDTHS]
    points = np.unique(np.r_[0., high, hinges, grid_nodes[grid_nodes<high], scale*grid_nodes[scale*grid_nodes<high]])
    node, mass = leggauss(order)
    mid = (points[:-1]+points[1:])/2
    half = np.diff(points)/2
    radius = (mid[:,None]+half[:,None]*node).ravel()
    measure = (half[:,None]*mass).ravel()
    wind = np.stack([weight(radius,CENTER*width)*measure for width in WIDTHS])
    np.testing.assert_allclose(wind.sum(axis=1), 1., rtol=0, atol=3e-14)
    density = measure*(density_kernel(radius,.15,1.,32)-density_kernel(radius,.30,1.,32))
    return radius,wind,density

def trajectory(values, initial, grid, scale, order, interp):
    radius, wind, density = weights(grid,scale,order)
    grid_nodes = (np.arange(3*grid)+.5)/grid
    knots = np.r_[-grid_nodes[3::-1],grid_nodes]
    def reconstruct(samples,at):
        extended = np.r_[samples[3::-1],samples]
        if interp == "cubic":
            return CubicSpline(knots,extended)(at)
        return np.interp(at,knots,extended)
    change = reconstruct(values-initial, radius/scale)
    drift = reconstruct(initial,radius/scale)-reconstruct(initial,radius)
    return np.r_[wind@(change+drift),density@(change+drift)]*1024

def run(grid,seed,pins):
    result = []
    parent_form = task.meta(task.FORM/"seal.json")["files"]
    with np.load(validate(task.FORM/f"matched-source-history-p32-s{seed}.npz",parent_form)) as bank:
        scales = bank["b"].copy()
    twins = task.read(validate(PARENT/f"g{grid}-s{seed}-off-newton-twin1024.csv",pins))
    states, proper = {}, {}
    for flag in (0,1):
        with task.system(grid,seed,flag) as model:
            for tick in (0,*task.CLOCKS):
                task.guard()
                stem = name(grid,seed,flag,"off",tick)
                with np.load(validate(PARENT/(stem+".npz"),pins)) as packet:
                    state = task.old.Difference(packet["shared"],packet["signed"])
                    clock = float(packet["clock"])
                raw, field = physical_read(model,state,clock,"off")
                states[flag,tick] = energy_terms(model,raw,field,clock)
                if tick==0:
                    initial = field
                    continue
                previous = task.meta(validate(PARENT/(stem+".json"),pins))["readings"]
                for key, label in (("temporal","temporal"),("spatial","space")):
                    observed = observer.annuli(model,raw,initial[label],field[label])
                    old = [previous[f"{label}-{width}"] for width in WIDTHS]
                    np.testing.assert_allclose(observed,old,rtol=2e-13,atol=1e-34)
                    proper[flag,tick,key] = observed
    for tick in task.CLOCKS:
        scale = float(scales[tick//32])
        take = lambda key,now: states[0,now][key]-states[1,now][key]
        for interp,order in (("cubic",8),("cubic",16),("linear",8)):
            curves = {key:trajectory(take(key,tick),take(key,0),grid,scale,order,interp) for key in states[0,0]}
            temporal, spatial = [proper[0,tick,key]-proper[1,tick,key] for key in ("temporal","spatial")]
            records = [next(row for row in twins if int(row["tick"])==tick and float(row["width"])==width and row["reader"]=="temporal") for width in WIDTHS]
            twin = np.array([float(row["newton_twin"]) for row in records])
            normal = abs(float(records[0]["native_newton"]))*1e-6
            delta = lambda arr: arr[0]-arr[1]
            joint = delta(temporal-twin)
            energy = curves["energy"][2]
            density_drift = energy-delta(twin)
            moving_ruler = delta(spatial-curves["spatial"][:2])
            clock_diff = delta(temporal-spatial)
            constraint = curves["constraint_kinetic"][2]
            kinetic = delta(curves["jacobi_kinetic"])
            direct = delta(curves["stress"])
            remainder = delta(curves["spatial"])-energy-constraint-kinetic-direct
            pieces = [density_drift,moving_ruler,clock_diff,constraint,kinetic,direct,remainder]
            assert abs(joint-sum(pieces)) < 1e-6*normal
            result.append(dict(grid=grid,seed=seed,tick=tick,order=order,interpolation=interp,unit=normal,
                    narrow_residual=(temporal[0]-twin[0])/normal,wide_residual=(temporal[1]-twin[1])/normal,
                    residual=joint/normal,poisson_actual=energy/normal,poisson_twin=delta(twin)/normal,
                    stored_surroundings=curves["reservoir"][2]/normal,stored_material=(energy-curves["reservoir"][2])/normal,
                    density_minus_twin=density_drift/normal,ruler=moving_ruler/normal,time_vs_space=clock_diff/normal,
                    constraint_kinetic=constraint/normal,jacobi_kinetic=kinetic/normal,
                    stress=direct/normal,spatial_remainder=remainder/normal,closure=(joint-sum(pieces))/normal))
    return result

def controls():
    rows=[]
    for grid in (320,640):
        centers=(np.arange(3*grid)+.5)/grid
        for scale in (1.,1.00000886):
            zeros=np.zeros_like(centers)
            flat=trajectory(1+zeros,zeros,grid,scale,16,"cubic")
            np.testing.assert_allclose(flat[:2],1024,rtol=0,atol=3e-10)
            initial=centers**2
            measured=trajectory(initial,initial,grid,scale,16,"cubic")
            radius,wind,density=weights(grid,scale,16)
            predicted=1024*(scale**-2-1)*np.r_[wind@(radius**2),density@(radius**2)]
            np.testing.assert_allclose(measured,predicted,rtol=0,atol=1e-12)
            exterior=np.where(centers>2.,np.exp(-centers),0.)
            shell=trajectory(exterior,zeros,grid,scale,16,"linear")
            assert not shell.any()
            rows.append(dict(grid=grid,scale=scale,constant_max=max(abs(flat[:2]-1024)),
                             dilation_error=max(abs(measured-predicted)),exterior=max(abs(shell))))
    return rows

if __name__=="__main__":
    assert task.lab.sha(PARENT/"seal.json")==PIN
    task.guard()
    pins=task.meta(PARENT/"seal.json")["files"]
    put("controls.csv",controls())
    rows=[]
    for grid,seed in task.RUNS:
        batch=run(grid,seed,pins)
        rows.extend(batch)
        print(grid,seed,[(item["residual"],item["density_minus_twin"],item["ruler"],item["spatial_remainder"]) for item in batch if item["tick"]==1024 and item["order"]==16],flush=True)
    assert len(rows)==36 and all(np.isfinite(val) for item in rows for val in item.values() if not isinstance(val,str))
    put("aperture-budget.csv",rows)
