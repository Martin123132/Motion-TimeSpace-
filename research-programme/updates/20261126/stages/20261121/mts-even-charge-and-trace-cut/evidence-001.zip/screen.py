"""Dispersive electron-trace x stress projection, using the sealed metric-stage kernel."""
from pathlib import Path
import sys
import numpy as np
from scipy.integrate import quad
from matching import rule

OLD=Path(__file__).resolve().parent.parent/"mts-motion-pair-metric-transfer-20261121"
sys.path.insert(0,str(OLD))
from transfer import HC,WITNESS,MASS_LIGHT,MASS_FAST,diff_weight
from crossed import born_cm

POLY=np.polynomial.polynomial.polypow([1.,-1.],5)*(-.75)
POLY[1:5]+=2*np.polynomial.polynomial.polypow([1.,-1.],3)

def kernel(argument, mass2):
    """Integral of P(m^2/w)/(w+argument) from m^2 to one; all invariants scaled by cap."""
    argument=np.asarray(argument,dtype=float)
    if mass2==0:
        return -.75*np.log1p(1/argument)
    result=np.empty_like(argument)
    small=argument<.45*mass2
    if np.any(small):
        ratio=argument[small]/mass2
        output=np.zeros_like(ratio)
        for degree in reversed(range(55)):
            moment=0.
            for power,coefficient in enumerate(POLY):
                exponent=degree+power
                moment+=coefficient*((1-mass2**exponent)/exponent if exponent else -np.log(mass2))
            output=moment-ratio*output
        result[small]=output
    if np.any(~small):
        vals=argument[~small]
        integ=np.log1p((1-mass2)/(mass2+vals))
        output=POLY[0]*integ
        for power,coefficient in enumerate(POLY[1:],start=1):
            prev=-np.log(mass2) if power==1 else (1-mass2**(power-1))/(power-1)
            integ=mass2/vals*(prev-integ)
            output+=coefficient*integ
        result[~small]=output
    return result

def projected(squared, mass2, order, sub=(0.,0.)):
    nodes,weights=rule(order)
    angle=1-nodes**2
    weights=weights*2*nodes*(3*angle**2-1)/2
    half=(squared/2)*np.sqrt(1-4*mass2/squared)
    mid=squared/2-mass2
    def amplitude(arg):
        return -arg**3*kernel(arg,mass2)/(48*np.pi**2)+sub[0]*arg**2-sub[1]*arg**3
    offset=half[:,None]*angle
    vals=amplitude(mid[:,None]-offset)+amplitude(mid[:,None]+offset)-2*amplitude(mid)[:,None]
    return 15*(vals@weights)/(4*half**2)

def screen_row(distance,mass,order,sub=(0.,0.)):
    length=distance*WITNESS/HC
    mass2=(mass/WITNESS)**2
    low=2*np.sqrt(mass2)*length
    high=min(length,low+115)
    breaks=np.unique(np.clip(np.r_[low,low+np.array([.01,.2,1,4,15,40]),high],low,high))
    coord,weights=rule(order)
    total=smean=readout=bound_moment=0.
    for left,right in zip(breaks,breaks[1:]):
        scaled=left+(right-left)*coord**2
        squared=(scaled/length)**2
        weight=weights*2*(right-left)*coord*scaled**3*(1-4*mass2/squared)**2.5*diff_weight(scaled)
        total+=sum(weight)
        smean+=weight@squared
        bound_moment+=weight@(squared/(1-4*mass2/squared))
        readout+=weight@projected(squared,mass2,order,sub)
    return np.array([smean,readout,bound_moment])/total

def four_distances(distance,mass,order,sub=(0.,0.)):
    means,values,moments=np.array([screen_row(factor*distance,mass,order,sub) for factor in (1,2,4)]).T
    ratio=(means[2]-means[1])/(means[1]-means[0])
    envelope=90/(48*np.pi**2)*np.abs([ratio,1+ratio,1])@moments
    return ratio,(values[2]-values[1])-ratio*(values[1]-values[0]),envelope

def screen_checks():
    for mass2 in (.002,.13):
        for argument in (.012,.43*mass2,.49*mass2,.2,2.1):
            direct=quad(lambda cut:(1-mass2/cut)**3*(2*mass2/cut-.75*(1-mass2/cut)**2)/(cut+argument),
                        mass2,1.,epsabs=1e-14)[0]
            assert abs(kernel(argument,mass2)-direct)<3e-12
        for squared in (.7,.9):
            basis=np.array([squared])
            base=projected(basis,mass2,50)[0]
            shifted=projected(basis,mass2,50,(-.003,.007))[0]
            assert abs(shifted-base-(-.003+3*(mass2-squared/2)*.007))<2e-13
    from matching import projected_trace,trace_ratio
    angle,weights=rule(32)
    angle=2*angle-1
    for invariant in (1.4,4.,12.,30.):
        mom2=(invariant-1)**2/(4*invariant)
        tval=-2*mom2*(1-angle)
        flip=np.array([born_cm(invariant,-1,point)[0] for point in angle])
        nonflip=np.array([born_cm(invariant,1,point)[1] for point in angle])
        direct=(weights*(1-angle)/2)@(flip*(2+tval)*trace_ratio(tval/25))
        contact=(weights*(1+angle)/2)@nonflip
        assert abs(direct/(-2*mom2/3)-projected_trace(4*mom2,.04))<1e-13
        assert abs(contact/(2*invariant*mom2/3)-1)<2e-14

