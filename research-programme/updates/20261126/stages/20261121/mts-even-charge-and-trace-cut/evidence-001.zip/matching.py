"""Even physical-threshold matching and the separately projected massive trace."""
from functools import lru_cache
import mpmath as mp
import numpy as np
from scipy import constants
from scipy.optimize import brentq
from scipy.special import roots_legendre

ALPHA = constants.alpha
ELECTRON = constants.m_e * constants.c**2 / constants.electron_volt
FZERO = 7 * 4*np.pi*ALPHA / (2160*np.pi**2 * ELECTRON**2)

@lru_cache(maxsize=16)
def rule(order):
    nodes, weights = roots_legendre(order)
    return (nodes+1)/2, weights/2

@lru_cache(maxsize=8)
def triangle_rule(order):
    nodes, weights = rule(order)
    product = nodes[:,None] * (1-nodes[:,None]) * nodes[None,:]
    measure = weights[:,None]*weights[None,:]*(1-nodes[:,None])
    return product.ravel(), (measure*product*(1-4*product)*360/7).ravel()

def trace_ratio(transfer_over_electron2, order=40):
    product, measure = triangle_rule(order)
    return (1/(1-np.asarray(transfer_over_electron2)[...,None]*product)) @ measure

def projected_trace(span, mass_ratio2, order=32):
    """Return signed J=1 flip divided by a_e times m_phi^2; span=D/m_phi^2."""
    nodes, weights = rule(order)
    return (3*weights*nodes**2) @ ((2-span*nodes)*trace_ratio(-span*nodes*mass_ratio2))

def trace_root(mass_ratio2):
    return brentq(lambda span:projected_trace(span,mass_ratio2), 2., 5., xtol=8e-15)

def analytic_ratio(transfer):
    if transfer == 0:
        return mp.mpf(1)
    tau = mp.mpf(transfer)/4
    branch = -mp.asinh(mp.sqrt(-tau))**2 if tau < 0 else mp.asin(mp.sqrt(tau))**2
    triangle = 3*(tau+(tau-1)*branch)/(2*tau**2)
    return (triangle-1)*120/(7*transfer)

def charge_checks():
    with mp.workdps(42):
        weight = mp.mpf(str(2*ALPHA/(3*np.pi)))
        for virtuality in (0, .04, 1., 24.):
            prediction = mp.quad(lambda unit: 6*unit*(1-unit)/(1+virtuality*unit*(1-unit)), [0,1])
            for curvature, ruler, frame, direct in ((0,0,1.7,0),(.8,-.2,.9,0),(-.3,1.,-.7,.05)):
                def inverse_charge(field):
                    mass = mp.exp((curvature-frame)*field**2/2)
                    scale = 9*mp.exp((ruler-frame)*field**2/2)
                    probe = mp.sqrt(virtuality)*scale/9
                    return direct*field**2/2 + 3*weight*mp.quad(
                        lambda unit: unit*(1-unit)*mp.log(scale**2/(mass**2+unit*(1-unit)*probe**2)), [0,1])
                measured = mp.diff(inverse_charge,0,2)
                assert abs(measured-(direct-weight*(curvature-ruler)*prediction)) < 2e-16
            if virtuality > 0:
                xval = mp.mpf(virtuality)
                closed = 6/xval*(1-4/mp.sqrt(xval*(4+xval))*mp.atanh(mp.sqrt(xval/(4+xval))))
                assert abs(closed-prediction)<mp.mpf('1e-36')
        for energy in (4.01,5.,16.,130.):
            def spectral(mass_log):
                ratio=mp.exp(2*mass_log)/energy
                return (1+2*ratio)*mp.sqrt(1-4*ratio)
            expected=-24/(energy**2*mp.sqrt(1-4/energy))
            assert abs(mp.diff(spectral,0)-expected)<1e-12*abs(expected)
        for value in (-16., -4., -.01, 0., .5, 3.):
            assert abs(float(analytic_ratio(value))-trace_ratio(value))<4e-14
    product, measure=triangle_rule(32)
    assert abs(sum(measure)-1)<1e-14 and abs(product@measure-5/49)<2e-15
    assert abs((trace_root(.001)/(8/3)-1)/.001-2/147)<5e-6

