"""Recalculate offline; compare with immutable result fixtures unless explicitly building."""
import csv
import hashlib
import io
import json
from pathlib import Path
import re
import sys
import numpy as np
from scipy import constants
from matching import ALPHA,ELECTRON,FZERO,charge_checks,trace_root,projected_trace
from screen import OLD,HC,WITNESS,MASS_LIGHT,MASS_FAST,four_distances,screen_checks

HERE=Path(__file__).resolve().parent
BASE=HERE.parent
SOURCES={"4917-*.md":"61dc24dd5d6c686589946358f8d488690ebc1ba478616b33757282b9111cab7c",
         "4919-*.md":"47144e184bb1b37a0bb50ae630a5a80020ff5f7c372fe0dc1cef8e7ce79db629",
         "4943-*.md":"a90da0e9ad0457fc3dbdb389d7bf2715cb9d707cbffa094a987b0b0553e257b5",
         "4878-*.md":"f60ee9ddb790b0501b161243ad348a405f0d8c4a55d5029349c544c5e00834b2",
         "MTS-CHARGED-THRESHOLD-AND-GR-TRACE.md":"882e58ac231e49afe4e94c088b814ee8057c0b14ab2a83e52be8a4729d89e562",
         "MTS-EM-TWO-PHOTON-MOTION-PAIR.md":"175724a7417d5b2f14eba1cfc66b1532ed3578ad89bbd2e9af346352c7eea67e"}

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def serial(rows):
    buff=io.StringIO(newline="")
    writer=csv.DictWriter(buff,rows[0].keys(),lineterminator="\n")
    writer.writeheader()
    writer.writerows(rows)
    return buff.getvalue().encode()

def generate():
    assert digest(OLD/"seal.json")=="9707f57d8609a89b080e08b1e5ec731a6cb8d3a82a936425b5f89cb8baefd310"
    for name,value in json.loads((OLD/"seal.json").read_bytes()).items():
        assert digest(OLD/name)==value,name
    for pattern,value in SOURCES.items():
        path,=BASE.glob(pattern)
        assert digest(path)==value,pattern
    charge_checks()
    screen_checks()
    reduced=np.sqrt(constants.hbar*constants.c**5/(8*np.pi*constants.G))/constants.electron_volt
    trace_unit=FZERO/(2*reduced**2)
    stress_unit=8*1.02964392290e57/reduced**4
    roots=[]
    for label,ratio in (("small_mass_limit",0.),("light",MASS_LIGHT/ELECTRON),
                        ("fast",MASS_FAST/ELECTRON),("synthetic_001",.01),("synthetic_02",.2),
                        ("synthetic_equal",1.)):
        span=trace_root(ratio**2)
        total=(2+span+np.sqrt(span*(span+4)))/2
        assert projected_trace(span*.99,ratio**2)>0>projected_trace(span*1.01,ratio**2)
        roots.append(dict(case=label,m_over_electron=ratio,D_zero_over_m2=span,v_zero_over_m2=total,
                          j1_at_D_2_normalized=projected_trace(2,ratio**2),
                          j1_at_D_4_normalized=projected_trace(4,ratio**2)))
    outputs=[]
    for label,mass in (("massless_control",0.),("retained_light",MASS_LIGHT),("retained_fast",MASS_FAST)):
        for dist in (.001,.01,.1):
            coarse=four_distances(dist,mass,32)[1]
            ratio,result,envelope=four_distances(dist,mass,56)
            shape_error=envelope*WITNESS**2/(4*ELECTRON**2)
            shifted=four_distances(dist,mass,56,(-.003,.007))[1]
            assert abs(coarse/result-1)<1e-8 and abs(shifted/result-1)<1e-8
            assert 0<shape_error<abs(result)*1e-11
            approx=-3*np.log(4)/16*3/(128*np.pi**2)*(168/5)/(dist*WITNESS/HC)**2
            if dist==.1:
                assert abs(result/approx-1)<.0003
            outputs.append(dict(case=label,first_m=dist,last_m=dist*8,ratio=ratio,
                four_distance_B_per_signed_trace_unit_lambda_cap_energy2=result,
                relative_quadrature_change=abs(coarse/result-1),
                relative_change_added_polynomials=abs(shifted/result-1),wide_window_asymptote=approx,
                integrated_electron_shape_absolute_error_cap=shape_error,
                strict_EFT_magnitude_cap_eVneg6_per_abs_Zpsi_over_K0=(abs(result)+shape_error)*WITNESS**2*stress_unit*trace_unit))
    with (OLD/"intrinsic-screen.csv").open(newline="") as stream:
        raw=[row for row in csv.DictReader(stream) if float(row["near_m"])==.01]
    assert len(raw)==3
    soft=[dict(pole=row["pole"],direct_factorized_shape=0.,
               original_transfer_per_eta_lambda=float(row["window_average_difference_per_eta_lambda"]),
               deformed_shape_times_MR2_per_lambda_per_kappa=(
                   -2*ALPHA/(3*np.pi)*float(row["window_average_difference_per_eta_lambda"]))) for row in raw]
    scale=dict(electron_mass_eV=ELECTRON,reduced_planck_mass_eV=reduced,F1_zero_eVneg2=FZERO,
               abs_trace_unit_eVneg4=trace_unit,cap_abs_lambda_eVneg4_per_abs_Zpsi_over_K0=stress_unit,
               fractional_form_factor_error_envelope=WITNESS**2/(4*ELECTRON**2),
               direct_soft_MR2_eta_per_unit_Dirac_mass_curvature=-2*ALPHA/(3*np.pi))
    return {"turnover.csv":serial(roots),"screen.csv":serial(outputs),"direct.csv":serial(soft),
            "scales.json":(json.dumps(scale,indent=2)+"\n").encode()}

if __name__=="__main__":
    mode=sys.argv[1:]
    assert mode in ([],["--initialize"])
    fixtures=generate()
    for name,payload in fixtures.items():
        path=HERE/name
        if mode and not path.exists():
            path.write_bytes(payload)
        assert path.read_bytes()==payload,name
    files=sorted([*fixtures,"matching.py","screen.py","replay.py","RESULTS.md","DERIVATION.md"])
    for doc in ("RESULTS.md","DERIVATION.md"):
        for target in re.findall(r"\]\(([^)]+)\)",(HERE/doc).read_text(encoding="utf-8")):
            assert target.startswith("https://") or (HERE/target).is_file(),target
    manifest=(json.dumps({name:digest(HERE/name) for name in files},indent=2)+"\n").encode()
    seal=HERE/"seal.json"
    if mode and not seal.exists():
        seal.write_bytes(manifest)
    assert seal.read_bytes()==manifest
    print(f"Verified {len(files)} sealed files; four-distance controls, threshold and source checks passed; {digest(seal)}")

