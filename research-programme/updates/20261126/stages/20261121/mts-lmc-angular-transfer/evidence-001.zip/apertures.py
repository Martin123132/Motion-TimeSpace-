"""Where the transferred canonical angular momentum resides; no rotation-curve fit."""
from transfer import AZ, HERE, PARENT, PIN, guard, digest, save, np, json
from scipy.linalg import lu_factor, lu_solve
from scipy.special import roots_legendre
from scipy.constants import parsec
from pulse_space import basis, angular, slope

def run():
    assert digest(PARENT/"seal.json")==PIN
    seals=json.loads((PARENT/"seal.json").read_bytes())["files"]
    def verified(name):
        path=PARENT/name
        assert digest(path)==seals[name],name
        return path
    output=[]
    gravity=[]
    geometry=[]
    for case in (0,1):
        for setting,which,num,edge in (("primary",case,64,30.),("radial_basis",case,88,30.),("outer_domain",case+2,64,40.)):
            guard()
            with np.load(verified(f"operators/{which}-{num}.npz")) as bank:
                block,waves,rad,weight,length,number=(bank[key] for key in ("block","waves","rad","weight","length","mass"))
                ground,mu,aw,velocity,sky=(bank[key] for key in ("ground","mu","aw","vel","sky"))
            orders=2+2*np.arange(len(block))
            on_sphere=basis(orders,2,mu)
            ground_angle=ground@basis(orders-2,0,mu).T
            factor=lu_factor(waves.T)
            nodes=np.r_[0.,rad/length,edge]
            assert (len(nodes)-1)%7==0
            faces=nodes[::7]
            edges=np.array([np.hypot(6.,1.5)/length,np.hypot(8.3,1.5)/length,edge])
            cut=[int(np.argmin(abs(faces-value))) for value in edges]
            np.testing.assert_allclose(faces[cut],edges,rtol=1e-13,atol=1e-14)
            halflength=np.diff(faces)/2
            lobatto=(nodes[:8]-faces[0])/halflength[0]-1
            local_weights=2/(7*8*np.polynomial.legendre.legval(lobatto,[0]*7+[1])**2)
            grid=np.arange(len(halflength))[:,None]*7+np.arange(8)[None,:]
            assembled=np.zeros(len(nodes))
            np.add.at(assembled,grid,halflength[:,None]*local_weights)
            np.testing.assert_allclose(assembled[1:-1],weight,rtol=2e-11,atol=1e-15)
            gauss,gweight=roots_legendre(10)
            interp=np.stack([np.prod((gauss[:,None]-np.delete(lobatto,index))/(lobatto[index]-np.delete(lobatto,index)),axis=1) for index in range(8)],axis=1)
            def lift(reduced):
                return np.einsum("lrk,lk->rl",block,reduced.reshape(len(block),-1))
            for path in sorted((PARENT/"states").glob(f"{which}-{num}-*-r192-l24-t16-d1.npz")):
                guard()
                assert not (HERE/"STOP-REQUESTED").exists()
                history=path.name.split("-")[2]
                with np.load(verified("states/"+path.name)) as state:
                    coord,rate=(state[key] for key in ("displacement","velocity"))
                conjugate=lu_solve(factor,rate)
                assert np.linalg.norm(waves.T@conjugate-rate)<1e-10*np.linalg.norm(rate)
                disp,dual=(lift(vector) for vector in (waves@coord,conjugate))
                source=((ground_angle*(disp@on_sphere.T))@(aw[:,None]*on_sphere))/weight[:,None]
                reference=2*(sky@coord)
                radial=rad/length
                for index,at in enumerate(edges[:2]):
                    inner_weight=np.zeros(len(nodes))
                    np.add.at(inner_weight,grid[:cut[index]],halflength[:cut[index],None]*local_weights)
                    interior=inner_weight[1:-1]
                    cosine=1.5/(at*length)
                    harmon=np.array([angular(order,2,cosine) for order in orders])
                    angle_force=np.array([slope(order,2,cosine) for order in orders])*np.sqrt(1-cosine**2)
                    inside=(interior[:,None]*source * np.minimum(radial[:,None]/at,1.)**orders).sum(axis=0)/at**2
                    exterior=((weight-interior)[:,None]*source * (np.minimum(at/radial[:,None],1.)**orders)/radial[:,None]).sum(axis=0)/at
                    common=2*velocity**2/length*(1e13/parsec)/(2*orders+1)
                    ratio=1.5/(6.,8.3)[index]
                    radial_near=common*(-(orders+1)*inside*harmon)
                    radial_far=common*(orders*exterior*harmon)
                    polar_near=-common*inside*angle_force
                    polar_far=-common*exterior*angle_force
                    predicted=ratio*(radial_far.sum()-2*radial_near.sum()/3)
                    actual=reference[3*index+1]
                    high_order_remainder=(polar_near+polar_far-ratio*(radial_far-2*radial_near/3))[1:].sum()
                    assert abs(polar_far[0]-ratio*radial_far[0])<1e-12*abs(polar_far[0])
                    assert abs(polar_near[0]+2*ratio*radial_near[0]/3)<1e-12*abs(polar_near[0])
                    assert abs(actual-predicted-high_order_remainder)<2e-5*abs(actual)
                    geometry.append(dict(case=case,history=history,setting=setting,aperture=("inner","outer")[index],
                                         ratio_z_over_R=ratio,radial_based_polar_real=predicted.real,
                                         actual_polar_real=actual.real,actual_polar_imag=actual.imag,
                                         radial_based_polar_imag=predicted.imag,higher_shape_remainder_real=high_order_remainder.real,
                                         higher_shape_remainder_imag=high_order_remainder.imag,
                                         fractional_real_error=abs((predicted-actual).real/actual.real),
                                         fractional_complex_error=abs(predicted-actual)/abs(actual),
                                         exterior_shape_real_error=abs((polar_far.sum()-ratio*radial_far.sum()).real/polar_far.sum().real)))
                    for component,inner,outer,ref in (
                        ("radial",-(orders+1)*inside*harmon,orders*exterior*harmon,reference[3*index]),
                        ("polar",-inside*angle_force,-exterior*angle_force,reference[3*index+1])):
                        near,far=common@inner,common@outer
                        discrepancy=abs((near+far)-ref)/abs(ref)
                        assert discrepancy<2e-5,(which,history,component,discrepancy)
                        gravity.append(dict(case=case,history=history,setting=setting,aperture=("inner","outer")[index],
                                            north_component=component,interior_real=near.real,exterior_real=far.real,
                                            interior_imag=near.imag,exterior_imag=far.imag,reference_real=ref.real,
                                            complex_rel_closure=discrepancy))
                shell=-AZ*np.sum((disp.conj()*dual).imag,axis=1)
                total=-AZ*np.vdot(coord,rate).imag
                assert abs(shell.sum()/total-1)<1e-10
                def unweight(field):
                    return np.pad(field/np.sqrt(weight[:,None]),((1,1),(0,0)))[grid]
                disp,dual=unweight(disp),unweight(dual)
                node_density=-AZ*np.sum((disp.conj()*dual).imag,axis=2)
                elements=halflength*(node_density@local_weights)
                dgauss,pgauss=(np.einsum("gj,ejl->egl",interp,field) for field in (disp,dual))
                exact_elements=-AZ*halflength*(np.sum((dgauss.conj()*pgauss).imag,axis=2)@gweight)
                assert abs(elements.sum()/total-1)<1e-10
                for index,shell_edge in enumerate(cut):
                    inside=elements[:shell_edge].sum()
                    exact=exact_elements[:shell_edge].sum()
                    output.append(dict(case=case,history=history,setting=setting,aperture=("inner","outer","box")[index],
                                       spherical_kpc=edges[index]*length,inside_per_ground=inside/number,
                                       outside_per_ground=elements[shell_edge:].sum()/number,
                                       signed_fraction=inside/total,polynomial_integral_per_ground=exact/number,
                                       quadrature_change_over_total=abs(exact-inside)/abs(total)))
    assert len(output)==108
    save("apertures.csv",output)
    assert len(gravity)==144
    save("force-origin.csv",gravity)
    assert len(geometry)==72
    save("polar-from-radial.csv",geometry)

if __name__=="__main__":
    run()

