"""Verify the saved work locally; never overwrite an existing receipt."""
import csv
import hashlib
import json
import math
from pathlib import Path

HERE = Path(__file__).resolve().parent

def sha(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream,"sha256").hexdigest()

def rows(name):
    with (HERE/name).open(newline="") as stream:
        return list(csv.DictReader(stream))

def main():
    pin = "14328952cd5b8ed0c9b8d000f9d26f13e86a1fbaae2951c586eccdd010420df2"
    assert sha(HERE.parent/"mts-lmc-live-quadrupole-20261119"/"seal.json")==pin
    counts={}
    for case in (0,1):
        force=rows(f"forces-{case}.csv")
        assert len(force)==96
        assert len({(r["history"],r["model"],r["radius"],r["height"],r["component"]) for r in force})==96
        for row in force:
            low,high,em,ex,total=map(float,(row[key] for key in ("low","high","envelope_min","envelope_max","signed_total")))
            assert low<high and em-1e-12<=total<=ex+1e-12
            assert (row["actual_inside"]=="True")==(low<=total<=high)
            assert (row["any_phase"]=="True")==(em<=high and ex>=low)
            assert (row["any_phase"]=="True")==(row["component"]=="polar" and float(row["radius"])==8.3)
        angles=rows(f"orientation-{case}.csv"); assert len(angles)==12
        for row in angles:
            selected=[r for r in force if (r["model"],r["history"])==(row["model"],row["history"])]
            alpha=float(row["diagnostic_phase_rad"] or 0.)
            actual_loss,best_loss=[],[]
            for r in selected:
                val,real,imag,low,high=(float(r[k]) for k in ("signed_total","wave_real","wave_imag","low","high"))
                rotated=val+(math.cos(alpha)-1)*real-math.sin(alpha)*imag
                for where,score in ((val,actual_loss),(rotated,best_loss)):
                    score.append(max(0,low-where,where-high)/(high-low))
            assert len(selected)==8 and abs(max(actual_loss)-float(row["actual_max_miss_widths"]))<1e-10
            assert abs(max(best_loss)-float(row["least_possible_max_miss_widths"]))<1e-10
        angular=rows(f"angular-{case}.csv"); assert len(angular)==18
        for orbit in {r["history"] for r in angular}:
            group={r["sector"]:r for r in angular if r["history"]==orbit}
            for key in ("angular","spectral","energy","capacity"):
                assert math.isclose(float(group["all"][key]),sum(float(group[label][key]) for label in ("lowest","rest")),rel_tol=1e-12)
        assert len(rows(f"torque-{case}.csv"))==18
    assert len(rows("refinements.csv"))==216 and len(rows("apertures.csv"))==108
    assert len(rows("force-origin.csv"))==144 and len(rows("polar-from-radial.csv"))==72
    for row in rows("polar-from-radial.csv"):
        pred=complex(float(row["radial_based_polar_real"]),float(row["radial_based_polar_imag"]))
        obs=complex(float(row["actual_polar_real"]),float(row["actual_polar_imag"]))
        rem=complex(float(row["higher_shape_remainder_real"]),float(row["higher_shape_remainder_imag"]))
        assert abs(obs-pred-rem)<2e-5*abs(obs)
    for path in HERE.glob("*.csv"):
        table=rows(path.name)
        assert all(None not in row and None not in row.values() for row in table)
        counts[path.name]=len(table)
    target=HERE/"seal.json"
    payload=dict(parent=pin,csv_rows=counts,files={p.name:sha(p) for p in sorted(HERE.iterdir()) if p.is_file() and p!=target})
    if target.exists():
        assert json.loads(target.read_bytes())==payload
    else:
        with target.open("x",encoding="utf-8",newline="\n") as stream:
            json.dump(payload,stream,indent=2,sort_keys=True)
            stream.write("\n")
    print(sum(counts.values()),"verified rows;",sha(target))

if __name__=="__main__":
    main()
