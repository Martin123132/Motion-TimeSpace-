"""Re-evaluate angular transfer on archived alternative discretizations, without new fits."""
import csv
import json
from transfer import HERE, PARENT, PIN, AZ, guard, digest, save, np

def run():
    guard()
    assert digest(PARENT/"seal.json")==PIN
    hashes=json.loads((PARENT/"seal.json").read_bytes())["files"]
    rows=[]
    for case in (0,1):
        with (HERE/f"angular-{case}.csv").open(newline="") as stream:
            reference={(row["history"],row["sector"]):row for row in csv.DictReader(stream)}
        for label,which,count,suffix in (("primary",case,64,"l24-t16-d1"),("radial_basis",case,88,"l24-t16-d1"),
                                        ("radial_source",case,64,"l24-t16-d2"),("time_source",case,64,"l24-t8-d1"),
                                        ("angular_source",case,64,"l16-t16-d1"),("outer_domain",case+2,64,"l24-t16-d1")):
            for history in sorted({key[0] for key in reference}):
                name=f"states/{which}-{count}-{history}-r192-{suffix}.npz"
                path=PARENT/name
                assert digest(path)==hashes[name],name
                with np.load(path) as state:
                    coord,rate,sigma=(state[key] for key in ("displacement","velocity","frequency"))
                    assert np.all(sigma>0)
                    angular=-AZ*(coord.conj()*rate).imag
                    energy=(abs(rate)**2+abs(sigma*coord)**2)/2
                for sector,slc in (("all",slice(None)),("lowest",slice(0,1)),("rest",slice(1,None))):
                    base=reference[history,sector]
                    strength=angular[slc].sum()
                    drift=abs(strength/float(base["angular"])-1)
                    drift_energy=abs(energy[slc].sum()/float(base["energy"])-1)
                    if label=="primary":
                        assert drift<1e-12 and drift_energy<1e-12
                    rows.append(dict(case=case,history=history,variant=label,sector=sector,
                                     angular=strength,energy=energy[slc].sum(),relative_angular_change=drift,
                                     relative_energy_change=drift_energy,same_sign=np.sign(strength)==np.sign(float(base["angular"]))))
    assert len(rows)==216
    save("refinements.csv",rows)

if __name__=="__main__":
    run()

