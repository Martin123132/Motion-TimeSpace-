"""Signed angular momentum, work and sky phase on the retained LMC m=2 branch."""
import csv
import hashlib
import io
import json
import os
import sys
from pathlib import Path

for name in ("OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS", "BLIS_NUM_THREADS", "NUMEXPR_NUM_THREADS"):
    os.environ[name] = "1"

import numpy as np
from scipy.special import spherical_jn, roots_legendre

HERE = Path(__file__).resolve().parent
PARENT = HERE.parent / "mts-lmc-live-quadrupole-20261119"
sys.path.insert(0, str(PARENT))
from quad_evolve import source_map
from quad_io import guard, digest

PIN = "14328952cd5b8ed0c9b8d000f9d26f13e86a1fbaae2951c586eccdd010420df2"
TOL = 2e-5
AZ = 2


def save(name, rows):
    data = io.StringIO(newline="")
    writer = csv.DictWriter(data, fieldnames=list(rows[0]), lineterminator="\n")
    writer.writeheader()
    writer.writerows(rows)
    path = HERE / name
    blob = data.getvalue().encode()
    if path.exists():
        assert path.read_bytes() == blob, name
    else:
        with path.open("xb") as stream:
            stream.write(blob)
    print(name, len(rows), hashlib.sha256(blob).hexdigest(), flush=True)


def fourier(force, times, sigma):
    count = (len(times) - 1) // 4
    elapsed = times - times[0]
    width = elapsed[-1] / count
    assert len(times) == 4 * count + 1 and np.max(abs(np.diff(times) - width / 4)) < 1e-10
    degree = np.arange(5)
    inverse = np.linalg.inv(np.polynomial.legendre.legvander(np.linspace(-1, 1, 5), 4))
    moment = inverse.T @ ((1j**degree[:, None]) * spherical_jn(degree[:, None], sigma * width / 2)) * width
    result = []
    for direction in (1, -1):
        total = np.zeros(len(sigma), dtype=complex)
        kernel = moment if direction == 1 else moment.conj()
        for first in range(0, count, 32):
            stop = min(first + 32, count)
            centers = elapsed[4 * first + 2:4 * stop:4]
            weight = np.exp((direction * 1j) * centers[:, None] * sigma)
            panel = sum(force[4 * first + node:4 * stop + node:4] * kernel[node] for node in range(5))
            total += np.sum(weight * panel, axis=0)
        result.append(total)
    return result


def direct_work(force, times, sigma):
    count = (len(times) - 1) // 4
    step = (times[-1] - times[0]) / count
    nodes, weights = roots_legendre(12)
    nodes, weights = (nodes + 1) / 2, weights / 2
    pin = np.linspace(0, 1, 5)
    def basis(points):
        return np.stack([np.prod((points[..., None] - np.delete(pin, index)) /
                                (pin[index] - np.delete(pin, index)), axis=-1) for index in range(5)], axis=-1)
    sample = basis(nodes)
    def kernels(probes):
        inner = probes[:, None] * nodes
        phase = (probes[:, None] - inner)[:, :, None] * step * sigma
        measure = probes[:, None] * weights * step
        coeff = basis(inner)
        return tuple(-2 * np.einsum("ab,abk,abj->ajk", measure, func, coeff) for func in (np.sin(phase)/sigma, np.cos(phase)))
    grid = np.r_[nodes, 1.]
    disp, rate = kernels(grid)
    cosine, sine = np.cos(grid[:, None] * step * sigma), np.sin(grid[:, None] * step * sigma)
    position = np.zeros(len(sigma), complex)
    speed = position.copy()
    torque = np.zeros(len(sigma))
    work = torque.copy()
    for start in range(0, 4*count, 4):
        panel = force[start:start + 5]
        local = sample @ panel
        path = cosine * position + sine / sigma * speed + np.einsum("ajk,jk->ak", disp, panel)
        velocity = -sigma * sine * position + cosine * speed + np.einsum("ajk,jk->ak", rate, panel)
        torque += 2 * AZ * step * (weights @ (path[:-1].conj() * local).imag)
        work -= 2 * step * (weights @ (velocity[:-1].conj() * local).real)
        position, speed = path[-1], velocity[-1]
    return torque, work


def orientation(rows, fields):
    offsets = np.array([float(row["stationary"])+float(row["direct_satellite"])+float(row["fixed_number_m0"]) for row in rows])
    low, high = (np.array([float(row[key]) for row in rows]) for key in ("low", "high"))
    widths = high-low
    coeffs = np.vstack([np.column_stack([(low-offsets)/widths, -fields.real/widths, fields.imag/widths]),
                        np.column_stack([(offsets-high)/widths, fields.real/widths, -fields.imag/widths]), [0,0,0]])
    angles = [0.]
    for index, (base, coscoef, sincoef) in enumerate(coeffs):
        phase = np.arctan2(sincoef, coscoef)
        angles.extend([phase, phase + np.pi])
        for diff in coeffs[:index] - coeffs[index]:
            amplitude = np.hypot(diff[1], diff[2])
            if amplitude and abs(diff[0]) <= amplitude:
                shift = np.arctan2(diff[2], diff[1])
                delta = np.arccos(np.clip(-diff[0]/amplitude,-1,1))
                angles.extend([shift + delta, shift - delta])
    def loss(points):
        return np.max(coeffs[:,0:1] + coeffs[:,1:2]*np.cos(points) + coeffs[:,2:3]*np.sin(points), axis=0)
    losses = loss(angles)
    best = int(np.argmin(losses))
    sampled = np.min(loss(np.arange(8192)*2*np.pi/8192))
    assert -2e-12 <= sampled - losses[best] <= np.pi/8192 * np.max(np.hypot(coeffs[:,1],coeffs[:,2])) + 2e-12
    combined = offsets + fields.real
    observed = [row["inside"] == "True" for row in rows]
    np.testing.assert_array_equal((low<=combined)&(combined<=high), observed)
    return losses[0], losses[best], float(angles[best] % (2*np.pi)), combined, low, high, offsets


def controls():
    times = np.linspace(0, 2*np.pi, 129)
    sigma = np.ones(1)
    for sign in (-1,1):
        force = np.exp(-sign * 1j * times[:, None])
        plus, minus = fourier(force, times, sigma)
        angular = AZ*(abs(plus)**2-abs(minus)**2)/sigma
        expected = sign * AZ * (2*np.pi)**2
        assert abs(angular[0]/expected-1) < 1e-8
        torque, work = direct_work(force,times,sigma)
        assert abs(torque[0]/expected-1) < 1e-8 and abs(work[0]/(2*np.pi)**2-1) < 1e-8
    radial = np.exp(.67j) * (1 + times[:,None]**2)
    plus, minus = fourier(radial,times,sigma)
    assert abs(abs(plus[0])/abs(minus[0])-1) < 1e-12
    toy = [dict(stationary=0,direct_satellite=0,fixed_number_m0=0,low=.8,high=1.2,inside="True"),
           dict(stationary=0,direct_satellite=0,fixed_number_m0=0,low=.8,high=1.2,inside="False")]
    _, best, *_ = orientation(toy,np.array([1.+0j,-1j]))
    assert abs(best-(.8-1/np.sqrt(2))/.4)<1e-12


def run(case):
    controls()
    guard()
    assert digest(PARENT / "seal.json") == PIN
    hashes = json.loads((PARENT / "seal.json").read_bytes())["files"]
    def verified(name):
        path = PARENT / name
        assert digest(path) == hashes[name], name
        return path
    with verified("combined-force-ledger.csv").open(newline="") as stream:
        ledger = list(csv.DictReader(stream))
    assert len(ledger) == 192
    with np.load(verified(f"operators/{case}-64.npz")) as bank:
        op = {key:bank[key] for key in bank.files}
    sigma = op["freq"]
    assert np.all(sigma > 0)
    tag = ("fine-reference-m2-n256","upper-added-free2-plus-m2-n256")[case]
    angular, sky, phase, torque_checks = [], [], [], []
    mapper = None
    histories = sorted({row["orbit"] for row in ledger if row["tag"] == tag})
    assert len(histories) == 6
    for history in histories:
        guard()
        assert not (HERE/"STOP-REQUESTED").exists()
        with np.load(verified(f"sources/{history}-r192-l24-q28-t16.npz")) as source:
            radius = source["radius"]
            if mapper is None:
                knots = radius.copy()
                mapper = source_map(op, radius, 24)
            np.testing.assert_array_equal(radius, knots)
            time = source["times"] * float(op["vel"])/float(op["length"])
            shell = source["V"]
            force = np.empty((len(time), len(sigma)), complex)
            for first in range(0,len(time),128):
                slab = shell[first:first+128]
                force[first:first+len(slab)] = slab.reshape(len(slab), -1) @ mapper
            del shell, slab
        with np.load(verified(f"states/{case}-64-{history}-r192-l24-t16-d1.npz")) as packet:
            coord, rate = packet["displacement"], packet["velocity"]
            full, first_force, rest = packet["full"], packet["lowest"], packet["remaining"]
            np.testing.assert_array_equal(sigma,packet["frequency"])
        plus, minus = fourier(force,time,sigma)
        energy = (abs(rate)**2 + (sigma*abs(coord))**2)/2
        moment = -AZ*(coord.conj()*rate).imag
        spectral = AZ*(abs(plus)**2 - abs(minus)**2)/sigma
        spectral_energy = abs(plus)**2 + abs(minus)**2
        elapsed = time[-1]-time[0]
        predicted_plus = -2*np.exp(1j*sigma*elapsed)*minus
        predicted_minus = -2*np.exp(-1j*sigma*elapsed)*plus
        complex_error = np.hypot(np.linalg.norm(rate + 1j*sigma*coord - predicted_plus),
                                 np.linalg.norm(rate - 1j*sigma*coord - predicted_minus)) / (2*np.sqrt(energy.sum()))
        assert complex_error < TOL
        for label, selection in (("all",slice(None)),("lowest",slice(0,1)),("rest",slice(1,None))):
            actual = moment[selection].sum()
            capacity = (AZ*energy[selection]/sigma[selection]).sum()
            closure = np.abs((moment-spectral)[selection]).sum()/capacity
            eclosure = np.abs((energy-spectral_energy)[selection]).sum()/energy[selection].sum()
            assert max(closure,eclosure) < TOL and abs(actual) <= capacity*(1+1e-12)
            angular.append(dict(case=case, history=history, sector=label, angular=actual, per_ground=actual/float(op["mass"]),
                                capacity=capacity, signed_share=actual/capacity, energy=energy[selection].sum(),
                                spectral= spectral[selection].sum(), angular_error_over_capacity=closure,
                                energy_relative_error=eclosure, complex_phase_error=complex_error))
        selected = np.array([0,1,len(sigma)//4])
        torque, work = direct_work(force[:,selected],time,sigma[selected])
        for index, mode in enumerate(selected):
            mscale = AZ*energy[mode]/sigma[mode]
            defect = abs(torque[index]-moment[mode])/mscale
            edefect = abs(work[index]-energy[mode])/energy[mode]
            assert max(defect,edefect) < TOL, (mode,defect,edefect)
            torque_checks.append(dict(case=case,history=history,mode=mode,angular=moment[mode],torque_integral=torque[index],
                                      energy=energy[mode],work_integral=work[index],angular_error_over_capacity=defect,
                                      energy_relative_error=edefect))
        components = 2*(op["sky"] @ coord)
        np.testing.assert_allclose(components[[0,1,3,4]].real,full[[0,1,3,4]],rtol=TOL,atol=0)
        np.testing.assert_allclose(full,first_force+rest,rtol=TOL,atol=1e-16)
        for model in ("mts","nfw"):
            rows = [r for r in ledger if (r["tag"],r["orbit"],r["background"]) == (tag,history,model)]
            assert {(float(r["R"]),float(r["z"]),r["component"]) for r in rows} == {
                (radius,height,component) for radius in (6.,8.3) for height in (-1.5,1.5) for component in ("radial","polar")} and len(rows)==8
            fields=[]
            for row in rows:
                component = row["component"]
                slot = (0 if float(row["R"])==6 else 3)+int(component=="polar")
                sign = -1 if component=="polar" and float(row["z"])<0 else 1
                field = sign*components[slot] if model=="mts" else 0j
                assert abs(field.real-(float(row["lowest_m2"])+float(row["remaining_m2"]))) < TOL*max(abs(field),1e-12)
                fields.append(field)
            fields=np.array(fields)
            actual,best,angle,combined,low,high,offsets=orientation(rows,fields)
            phase.append(dict(case=case,history=history,model=model,actual_max_miss_widths=actual,
                              least_possible_max_miss_widths=best,diagnostic_phase_rad=angle if model=="mts" else ""))
            for index,row in enumerate(rows):
                assert abs(combined[index]-float(row["total"])) <= TOL*abs(float(row["total"]))
                envelope = abs(fields[index])
                lo, hi = offsets[index]-envelope,offsets[index]+envelope
                sky.append(dict(case=case,history=history,model=model,radius=row["R"],height=row["z"],component=row["component"],
                                wave_real=fields[index].real,wave_imag=fields[index].imag,signed_total=combined[index],
                                envelope_min=lo,envelope_max=hi,low=low[index],high=high[index],
                                actual_inside=low[index]<=combined[index]<=high[index],any_phase=lo<=high[index] and hi>=low[index]))
        print(case,history,"checked",flush=True)
    for name, rows in (("angular",angular),("forces",sky),("orientation",phase),("torque",torque_checks)):
        save(f"{name}-{case}.csv",rows)


if __name__=="__main__":
    run(int(sys.argv[1]))

