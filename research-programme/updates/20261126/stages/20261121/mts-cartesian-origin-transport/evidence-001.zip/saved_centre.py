from base_origin import *
from chart_origin import from_physical,material_stress
from number_chart import pair

def signed(value):
    return np.asarray(value.delta if isinstance(value,Difference) else value)

def analyse(grid,seed):
    rows=[]
    with environment(grid):
        for flag in (0,1):
            model=(Cold if flag else Wave)(seed,"adm")
            shell=model.shell
            r=shell.r
            s=r**2
            for tick in (0,256,512,768,1024):
                guard()
                state,time=restart(model,grid,seed,tick)
                mapped,aux=model.mass.decode(state)
                raw,geo,bg,_=model.lift.physical(mapped,time)
                h,p=from_physical(shell.initial+raw,bg,aux["ka"],aux["kb"],r)
                physical=raw if flag else model.to_wave(raw)
                obs=shell.incident.external(time)
                m=np.expm1(2*(bg["ell"]-bg["bend"]))/s
                total=material_stress(h,s,m,*sources(model,time,physical))
                external_shear=(1.5*obs[4]-4*obs[5]+obs[6])/s**2
                for group,arr in (("metric",h),("extrinsic",p),("material",total),("external_flat_quartic",(external_shear,))):
                    for idx,coef in enumerate(arr):
                        data=signed(coef)
                        if data.ndim==0:data=np.full_like(r,data)
                        assert np.all(np.isfinite(data))
                        row=dict(grid=grid,seed=seed,flag=flag,tick=tick,sector=group,coef="abcd"[idx] if len(arr)==4 else "d")
                        for cell in (0,1,2,3,5,7,15,31):
                            row[f"cell{cell}"]=float(data[cell])
                        rows.append(row)
    return rows

def main():
    lock()
    rows=[]
    for grid,seed in ((320,1),(640,1),(640,-1)):
        rows.extend(analyse(grid,seed))
    with environment(640):local.table("saved-origin-coefficients.csv",rows)
    for group in ("metric","extrinsic","material","external_flat_quartic"):
        for tick in (0,256,1024):
            print(group,tick,[(row["grid"],row["flag"],row["cell0"],row["cell1"],row["cell7"]) for row in rows if row["coef"]=="d" and row["sector"]==group and row["seed"]==1 and row["tick"]==tick])
if __name__=="__main__":main()
