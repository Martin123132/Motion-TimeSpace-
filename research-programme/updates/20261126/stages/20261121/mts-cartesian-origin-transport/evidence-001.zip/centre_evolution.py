import numpy as np
from chart_origin import Jets, local,environment
from cartesian_ricci import applied

def run(grid,steps,inject):
    r=(np.arange(grid)+.5)/grid;s=r*r
    jeans=Jets(r)
    omega=1.7
    shape=np.array([.25+0*s,0*s,s*s,0*s])
    ric=np.array([-s*s,-4*s,-20*s,-4+0*s])
    constant=np.array([1+0*s,0*s,0*s,0*s])
    mixing=np.array([0*s,1+0*s,0*s,0*s])*inject
    force=omega**2*shape/2-ric
    def exact(time):
        h=shape*np.cos(omega*time)-2*time*mixing+(2/3)*time**3*constant*inject
        p=omega*shape*np.sin(omega*time)/2+mixing-time**2*constant*inject
        return np.stack([h,p])
    def rhs(time,data):
        h,p=data
        jets=tuple(entry for coef in h for entry in (coef,jeans.first_of(coef),jeans.second_of(coef)))
        curvature=np.asarray(applied(s,0,0,0,0,0,jets,1))
        rates=np.stack([-2*p,curvature+np.cos(omega*time)*force])
        return rates
    duration=.03
    dt=duration/steps
    def boundary(data,time):
        data[:,:,-4:]=exact(time)[:,:,-4:]
        return data
    data=exact(0)
    for index in range(steps):
        time=index*dt
        first=rhs(time,data)
        second=rhs(time+dt/2,boundary(data+dt*first/2,time+dt/2))
        third=rhs(time+dt/2,boundary(data+dt*second/2,time+dt/2))
        fourth=rhs(time+dt,boundary(data+dt*third,time+dt))
        data=boundary(data+dt*(first+2*second+2*third+fourth)/6,time+dt)
    end=exact(duration)
    delta=abs(data-end)
    return dict(grid=grid,steps=steps,injected=inject,first_cell=float(delta[:,:,0].max()),central_eighth=float(delta[:,:,:grid//8].max()),
                entire_interior=float(delta[:,:,:-4].max()),central_metric_shear=float(data[0,0,0])),data[1]

def main():
    rows=[]
    for grid,steps in ((32,12),(32,24),(64,24),(64,48)):
        reference,p0=run(grid,steps,0)
        injected,p1=run(grid,steps,1)
        r=(np.arange(grid)+.5)/grid;s=r*r
        p=p1-p0
        ap,bp,cp,dp=[Jets(r).first_of(term) for term in p]
        U=2*ap+p[1]-4*p[2]+2*s*bp-2*s*p[3]
        V=-2*bp-4*cp+4*p[3]
        err=float(max(abs(U[:grid//2]-1).max(),abs(s[:grid//2]*V[:grid//2]).max()))
        for row in (reference,injected):
            row["injected_momentum_error_paired"]=err
            rows.append(row)
    for row in rows:print(row)
    assert all(row["central_eighth"]<5e-7 and row["injected_momentum_error_paired"]<5e-7 for row in rows)
    with environment(640):local.table("manufactured-evolution.csv",rows)
if __name__=="__main__":main()
