import numpy as np
import sympy as sy
import json
from chart_origin import applied, kinetic,environment,local

Q=np.diag([-.5,-.5,1.])
polys=np.array([[.23,.06,-.013],[.11,-.04,.009],[-.14,.12,.015],[.07,-.03,-.02]])
mom=np.array([.08,-.05,.035,.11])

def tensor(vector,coeff):
    quad=Q@vector
    weight=vector@quad
    return (coeff[0]*Q+coeff[1]*(np.outer(vector,quad)+np.outer(quad,vector))
            +coeff[2]*weight*np.eye(3)+coeff[3]*weight*np.outer(vector,vector))

def direct_generator():
    coords=sy.symbols("x:3")
    vector=sy.Matrix(coords)
    quad=sy.diag(-sy.Rational(1,2),-sy.Rational(1,2),1)*vector
    size=vector.dot(vector)
    weight=vector.dot(quad)
    perturb=sy.Symbol("e")
    basis=[sy.diag(-sy.Rational(1,2),-sy.Rational(1,2),1),vector*quad.T+quad*vector.T,weight*sy.eye(3),weight*(vector*vector.T)]
    amp=[sum(sy.Rational(str(val))*size**degree for degree,val in enumerate(row)) for row in polys]
    scalar=1+7*size/100+size**2/100
    metric=scalar*(sy.eye(3)+(sy.Rational(12,100)+3*size/100)*vector*vector.T+perturb*sum((aa*bb for aa,bb in zip(amp,basis)),sy.zeros(3)))
    parts=list(metric)
    parts+= [el.diff(axis) for axis in coords for el in metric]
    parts+= [el.diff(axis,other) for axis in coords for other in coords for el in metric]
    fn=sy.lambdify((*coords,perturb),parts,"numpy",cse=True)
    def evaluate(vector,amount):
        vals=np.asarray(fn(*vector,amount))
        metric=vals[:9].reshape(3,3); d=vals[9:36].reshape(3,3,3); dd=vals[36:].reshape(3,3,3,3)
        inv=np.linalg.inv(metric); di=-np.einsum('ia,kab,bj->kij',inv,d,inv)
        lower=(d.transpose(2,0,1)+d.transpose(2,1,0)-d)/2
        dl=(dd.transpose(0,3,1,2)+dd.transpose(0,3,2,1)-dd)/2
        gamma=np.einsum('ab,bij->aij',inv,lower)
        dg=np.einsum('kab,bij->kaij',di,lower)+np.einsum('ab,kbij->kaij',inv,dl)
        return (np.einsum('kkij->ij',dg)-np.einsum('jkik->ij',dg)+np.einsum('kkl,lij->ij',gamma,gamma)-np.einsum('kjl,lik->ij',gamma,gamma))
    return evaluate

def main():
    ricci=direct_generator(); rows=[]
    for vec in ([0,0,0],[0,0,.29],[.045,-.011,.028],[-.3,.36,.29],[.78,-.35,.19]):
        pos=np.array(vec,dtype=float);size=pos@pos
        amp=polys@[1,size,size**2]; deriv=polys[:,1]+2*size*polys[:,2]
        scalar=1+.07*size+.01*size**2
        m=.12+.03*size; F=1+size*m
        z=(.07+.02*size)/(2*scalar);zs=.01/scalar-2*z**2
        jet=np.stack([amp,deriv,2*polys[:,2]],axis=1).ravel()
        computed=tensor(pos,applied(size,m,.03,0.,z,zs,jet,1/(scalar*F)))
        measured=ricci(pos,1e-20j).imag/1e-20/scalar
        ricerr=float(np.max(abs(computed-measured)))
        metric=scalar*(np.eye(3)+m*np.outer(pos,pos)); kt=-.13;dk=.055
        curv=metric@(kt*np.eye(3)+dk*np.outer(pos,pos))
        def product(amount):
            met=metric+amount*scalar*tensor(pos,amp)
            ext=curv+amount*scalar*tensor(pos,mom)
            mixed=np.linalg.solve(met,ext)
            return np.trace(mixed)*ext-2*ext@mixed
        manual=product(1e-20j).imag/1e-20/scalar+2*kt*tensor(pos,mom)
        check=tensor(pos,kinetic(amp,mom,size,m,kt,dk))
        rows.append(dict(point=vec,ricci=ricerr,kinetic=float(np.max(abs(manual-check)))))
    print(json.dumps(rows,indent=1))
    assert max(max(row["ricci"],row["kinetic"]) for row in rows)<2e-12
    with environment(640):local.manifest("independent-cartesian.json",dict(rows=rows))
if __name__=="__main__":main()
