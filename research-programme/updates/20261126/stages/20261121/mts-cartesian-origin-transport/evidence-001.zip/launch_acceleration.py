from chart_origin import *
from saved_centre import signed

def run(grid,seed):
    rows=[]
    with environment(grid):
        for flag in (0,1):
            model=(Cold if flag else Wave)(seed,"adm")
            initial,clock=restart(model,grid,seed,0)
            shell=model.shell;r=shell.r;s=r**2
            mapped,aux=model.mass.decode(initial)
            raw,geo,bg,_=model.lift.physical(mapped,0.)
            h,p=geometric(model,mapped,aux,0)
            for v in (bg["ell"]-bg["bend"],*(h[k] for k in (0,1,3))):
                assert not np.any(v.base) and not np.any(v.delta)
            g=np.exp(2*bg["bend"]);z=bg["bg"]/(2*r)
            m=0*s
            kt=-aux["kb"];dk=(aux["kb"]-aux["ka"])/s
            matter=material_stress(h,s,m,*sources(model,0.,raw if flag else model.to_wave(raw)))
            product=kinetic(h,p,s,m,kt,dk)
            estimates=[]
            for order in (4,6):
                jet=Jets(r,order)
                curvature=(-2*jet.second_of(h[2])+4*z*jet.first_of(h[2]))/g
                estimates.append(signed(curvature+product[3]+matter[3]))
            step=4096*np.pi/(1024*shell.mu)
            with patch.object(evolve8,"revise",revised):
                rate=(model.rhs if flag else model.nonlinear)(0.,initial)
            slopes=[]
            for eps in (step/32,step/64):
                def pushed(offset):
                    mapped,aux=model.mass.decode(initial+rate*offset)
                    return signed(geometric(model,mapped,aux,offset)[1][3])
                slopes.append((pushed(eps)-pushed(-eps))/(2*eps))
            for tick in (256,512,768,1024):
                state,time=restart(model,grid,seed,tick)
                m1,aux1=model.mass.decode(state)
                h1,p1=geometric(model,m1,aux1,time)
                for cell in (0,1,2,3,7,15):
                    rows.append(dict(grid=grid,seed=seed,flag=flag,cell=cell,tick=tick,clock=time,
                            chart4=estimates[0][cell],chart6=estimates[1][cell],prior_slope32=slopes[0][cell],prior_slope64=slopes[1][cell],
                            actual_p=signed(p1[3]-p[3])[cell],forecast_p=time*slopes[1][cell],actual_h=signed(h1[3]-h[3])[cell],
                            forecast_h=-time**2*slopes[1][cell]))
    return rows

if __name__=="__main__":
    lock();rows=[]
    for grid,seed in ((320,1),(640,1),(640,-1)):rows+=run(grid,seed)
    with environment(640):local.table("launch-to-endpoint.csv",rows)
    for row in rows:
        if row["cell"]==0 and row["tick"]==1024:print(row)
