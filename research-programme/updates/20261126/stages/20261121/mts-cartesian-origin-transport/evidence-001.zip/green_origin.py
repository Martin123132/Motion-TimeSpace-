from base_origin import *
from chart_origin import geometric,material_stress,kinetic
from saved_centre import signed
import local_case as carrier
import mpmath as mp
from functools import lru_cache

@lru_cache(maxsize=6)
def coefficients(flag,seed):
    _,name,_=carrier.launch(1024,flag,seed)
    with np.load(name) as bank,mp.workdps(65):
        nodes=[mp.mpf(float(val))*float(bank["h"]) for val in bank["t"]]
        mat=mp.matrix([[val**degree for degree in range(len(nodes))] for val in nodes])
        coef=[mp.lu_solve(mat,mp.matrix(vec.tolist())) for vec in bank["src"][:,0]]
        residual=max(abs(val) for entries,vec in zip(coef,bank["src"][:,0]) for val in mat*entries-mp.matrix(vec.tolist()))
        assert residual<mp.mpf('1e-60')
        return np.array([[float(each) for each in entries] for entries in coef]),float(bank["h"])

def operator(coef,r,C,bend):
    j=np.arange(coef.shape[1])[:,None]
    u_s=-np.sum(coef[1,:,None]*r**(j-2)/(2*(j+5)),axis=0)
    u_ss=-np.sum((j-2)*coef[1,:,None]*r**(j-4)/(4*(j+5)),axis=0)
    mono_s=-np.sum(coef[0,:,None]*r**j/(2*(j+3)),axis=0)
    mono_ss=-np.sum(j*coef[0,:,None]*r**(j-2)/(4*(j+3)),axis=0)
    den=np.exp(bend/2);g=den**4
    C_s=(4*u_s-C*mono_s)/den
    C_ss=(4*u_ss-C*mono_ss-2*C_s*mono_s)/den
    return (-2*C_ss+8*mono_s/den*C_s)/g

def run(grid,seed,flag):
    with environment(grid):
        model=(Cold if flag else Wave)(seed,"adm");shell=model.shell
        initial,_=restart(model,grid,seed,0)
        mapped,aux=model.mass.decode(initial)
        raw,geo,bg,_=model.lift.physical(mapped,0.)
        h,p=geometric(model,mapped,aux,0.);r=shell.r[:32];s=shell.r**2
        base,edge=coefficients(flag,0);host,extent=coefficients(flag,seed)
        assert all(r<edge) and edge==extent
        values=[]
        for src,C,bend in ((base,h[2].base,bg["bend"].base),(host,h[2].base+h[2].delta,bg["bend"].base+bg["bend"].delta)):
            values.append(operator(src,r,C[:len(r)],bend[:len(r)]))
        diff=values[1]-values[0]
        linear=-(host[1,1]-base[1,1])/(3*r**3)
        boundary=(material_stress(h,s,0*s,*sources(model,0.,raw if flag else model.to_wave(raw)))[3]
                    +kinetic(h,p,s,0*s,-aux["kb"],(aux["kb"]-aux["ka"])/s)[3])
        full=diff+signed(boundary)[:len(r)]
        rows=[]
        for idx in (0,1,2,3,7,15,31):
            rows.append(dict(grid=grid,seed=seed,flag=flag,cell=idx,r=r[idx],first_source_node=.2*float(np.polynomial.legendre.leggauss(12)[0][0]+1)/2,
                          signed_quadrupole_constant=host[1,0]-base[1,0],signed_quadrupole_linear=host[1,1]-base[1,1],
                          analytic_ricci_d=diff[idx],leading_linear_source=linear[idx],kinetic_plus_matter=signed(boundary)[idx],
                          complete_launch=full[idx],physical_r4_term=r[idx]**4*diff[idx]))
        return rows

def main():
    radius=np.array([.0008,.013,.07])
    for power,expect in ((1,-1/(3*radius**3)),(2,np.zeros_like(radius)),(4,np.full_like(radius,4/9))):
        coef=np.zeros((2,6));coef[1,power]=1
        np.testing.assert_allclose(operator(coef,radius,0*radius,0*radius),expect,rtol=5e-15,atol=0.)
    lock();rows=[];summary=[]
    old=core.read(HERE/"launch-to-endpoint.csv")
    for grid,seed in ((320,1),(640,1),(640,-1)):
        for flag in (0,1):
            group=run(grid,seed,flag);rows.extend(group)
            first=group[0]
            prev=next(row for row in old if (int(row["grid"]),int(row["seed"]),int(row["flag"]),int(row["tick"]),int(row["cell"]))==(grid,seed,flag,1024,0))
            summary.append(dict(grid=grid,seed=seed,flag=flag,leading_over_exact=first["leading_linear_source"]/first["analytic_ricci_d"],
                         exact_over_inherited=first["complete_launch"]/float(prev["prior_slope64"]),
                         sampled4_over_exact=float(prev["chart4"])/first["complete_launch"],sampled6_over_exact=float(prev["chart6"])/first["complete_launch"],
                         inherited_predicted_over_final=float(prev["forecast_p"])/float(prev["actual_p"])))
    with environment(640):
        local.table("green-first-element.csv",rows)
        local.table("launch-source-comparison.csv",summary)
    for row in summary:
        assert abs(row["leading_over_exact"]-1)<.002 and 0.69<row["exact_over_inherited"]<.71
        assert row["sampled6_over_exact"]<.10 and abs(row["inherited_predicted_over_final"]-1)<.031
        print(row)
if __name__=="__main__":main()
