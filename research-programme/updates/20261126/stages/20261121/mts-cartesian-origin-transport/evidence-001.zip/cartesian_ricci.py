from functools import lru_cache
import sympy as sy
import numpy as np


@lru_cache(maxsize=1)
def matrix():
    s,m,ms,mss,z,zs=sy.symbols("s m ms mss z zs",real=True)
    F=1+s*m
    Fs=m+s*ms
    Fss=2*ms+s*mss
    ell=z+Fs/(2*F)
    nr0=4*z+8*s*zs-8*s*ell*z-4*ell
    scalar0=2*m-8*z-16*s*zs+8*(ell-3*z)+16*s*ell*z-24*s*z**2
    rr0=-m+4*z+4*s*z**2+scalar0/2
    tan0=(scalar0-rr0)/2
    columns=[]
    for field in range(4):
        for degree in range(3):
            raw=[[sy.S.Zero]*3 for entry in range(4)]
            raw[field][degree]=sy.S.One
            av,bv,cv,dv=raw
            aa,ap,app=av;bb,bp,bpp=bv;cc,cp,cpp=cv;dd,dp,dpp=dv
            rr=aa+s*(2*bb+cc+s*dd)
            rr1=ap+2*bb+cc+s*(2*bp+cp+2*dd+s*dp)
            avg=-aa/2+s*cc;av1=-ap/2+cc+s*cp;av2=-app/2+2*cp+s*cpp
            cross=(aa+s*bb)/2;cross1=(ap+bb+s*bp)/2
            tan=aa/2;tan1=ap/2;tan2=app/2
            L=rr/(2*F);Lp=(rr1-rr*Fs/F)/(2*F)
            nr=2*av1+4*s*av2-4*s*ell*av1-8*s*Lp*z-4*Lp+12*(cross1-ell*cross)
            radial=-(nr-2*L*nr0+((4*L-6*cross)+F*(4*avg+12*tan-6*L))/s)/3
            cross_ric=-F*(av1+2*tan1-2*L*z+(cross-L)/s)
            tangent_ric=-(tan1+2*s*tan2+2*(tan1-cross1)+(4*z-2*ell)*(s*tan1-cross))+(cross-F*L)/s
            scalar=6*radial+3*(F*(4*avg+12*tan)/s-2*(1+2*s*z)*(2*av1+6*cross/s-2*L*(1/s+2*z)))
            rrRic=F*(scalar/3+radial)+rr*rr0
            avgRic=scalar/3-radial/2+avg*tan0
            crossRic=cross_ric+cross*tan0
            tanRic=tangent_ric+tan*tan0
            values=(2*tanRic,2*(crossRic-tanRic)/s,(avgRic+tanRic)/s,(rrRic-avgRic-4*crossRic+tanRic)/s**2)
            column=[sy.factor(sy.cancel(val)) for val in values]
            for val in column:
                assert sy.denom(val).subs(s,0)!=0,(field,degree,val)
            columns.append(column)
    flat=sy.Matrix(columns).T.subs({m:0,ms:0,mss:0,z:0,zs:0})
    target=sy.Matrix([[0,-1,-2*s,1,2*s,0,-1,0,0,-s,0,0],
                      [0,0,2,0,-2,0,0,-2,0,2,0,0],
                      [0,0,0,0,0,0,0,-8,-2*s,4,s,0],
                      [0,0,0,0,0,0,0,0,-2,0,1,0]])
    assert (flat-target).applyfunc(sy.simplify)==sy.zeros(4,12)
    return (s,m,ms,mss,z,zs),sy.Matrix(columns).T


@lru_cache(maxsize=1)
def evaluator():
    symbols,entries=matrix()
    args=sy.symbols("v0:12")
    values=entries*sy.Matrix(args)
    return sy.lambdify((*symbols,*args),list(values),"numpy",cse=True)


def applied(s,m,ms,mss,z,zs,jet,n):
    return tuple(n*val for val in evaluator()(s,m,ms,mss,z,zs,*jet))


if __name__=="__main__":
    symbols,entries=matrix()
    print("regular curvature coefficients",entries.shape,sum(value!=0 for value in entries))
    print(entries)
