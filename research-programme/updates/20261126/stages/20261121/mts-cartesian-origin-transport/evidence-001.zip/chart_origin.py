from base_origin import *
from native import background
from cartesian_ricci import applied
from number_chart import mul,square,pair
from math import factorial


class Jets:
    def __init__(self,r,order=6):
        self.s=r**2
        size=len(r)
        half=order//2
        positions=np.arange(size)
        self.indices=np.clip(positions-half,0,size-order-1)[:,None]+np.arange(order+1)
        nodes=self.s[self.indices]
        unit=np.max(abs(nodes-self.s[:,None]),axis=1)
        offsets=(nodes-self.s[:,None])/unit[:,None]
        powers=np.stack([offsets**deg for deg in range(order+1)],axis=1)
        rhs=np.zeros((size,order+1,2));rhs[:,1,0]=1;rhs[:,2,1]=2
        weights=np.linalg.solve(powers,rhs)
        self.first=weights[:,:,0]/unit[:,None]
        self.second=weights[:,:,1]/unit[:,None]**2

    def apply(self,value,weights):
        if isinstance(value,Difference):return Difference(self.apply(value.base,weights),self.apply(value.delta,weights))
        return np.sum(weights*(value[self.indices]-value[:,None]),axis=1)

    def first_of(self,value):return self.apply(value,self.first)
    def second_of(self,value):return self.apply(value,self.second)


def from_physical(actual,bg,ka,kb,r):
    s=r**2
    F=np.exp(2*(bg["ell"]-bg["bend"]))
    root=np.sqrt(F)
    L,b,v,t=(actual[idx,1].real for idx in range(4))
    tr,shear,cross,tf=(actual[idx,1].real for idx in range(4,8))
    rr=2*F*L;avg=2*b
    h=pack(rr,avg,v,t,s)
    p=pack(F*(tr/3+shear)-ka*rr,tr/3-shear/2-kb*avg,root*cross-kb*v,tf-kb*t,s)
    return h,p


def geometric(model,mapped,aux,time):
    raw,geo,bg,_=model.lift.physical(mapped,time)
    actual=model.shell.initial+raw
    return from_physical(actual,bg,aux["ka"],aux["kb"],model.shell.r)


def decoded(h,p,ell,bend,ka,kb,r):
    F=np.exp(2*(ell-bend));root=np.sqrt(F)
    rr,avg,c,t=unpack(h,r**2);pr,pa,pc,pt=unpack(p,r**2)
    R=(pr+ka*rr)/F;T=pa+kb*avg
    return (rr/(2*F),avg/2,c,t,R+2*T,2*(R-T)/3,(pc+kb*c)/root,pt+kb*t)


def xxt(coeff,s):
    a,b,c,d=coeff
    return (0*a,a+s*b,0*a,2*(b+c+s*d))


def radial(coeff,s):
    a,b,c,d=coeff
    return a+s*(2*b+c+s*d)


def tracecoeff(coeff,s):
    a,b,c,d=coeff
    return 2*b+3*c+s*d


def kinetic(h,p,s,m,kt,dk):
    F=1+s*m
    kr=kt+s*dk
    mk=dk+m*kr
    K=3*kt+s*dk
    tr=tracecoeff(p,s)-m/F*radial(p,s)-kt*tracecoeff(h,s)-(dk-kt*m)/F*radial(h,s)
    xh=xxt(h,s);xp=xxt(p,s)
    result=[(K-2*kt)*pc-2*dk*xc+2*kt**2*hc+2*kt*dk*yc for hc,pc,xc,yc in zip(h,p,xp,xh,strict=True)]
    result[2]+=kt*tr
    result[3]+=mk*tr+2*dk**2*radial(h,s)
    return tuple(result)


def material_stress(h,s,m,energy,stress,sr,cross,tensor):
    F=1+s*m;root=np.sqrt(F)
    pressure=stress/3
    pt0=pressure[0]-sr[0]/2
    pr2=pressure[1]+sr[1]
    angular=pressure[1]-sr[1]/2
    a=2*tensor
    b=2*(root*cross-tensor)/s
    c=(angular+tensor)/s
    d=(1.5*sr[1]-4*cross+tensor+s*m*pr2-4*s*m*cross/(root+1)+1.5*sr[0]*radial(h,s))/s**2
    trace_source=(stress[1]-energy[1])/(2*s)
    common=(stress[0]-energy[0])/2-pt0
    matter=[common*hc-sc for hc,sc in zip(h,(a,b,c,d),strict=True)]
    matter[2]+=trace_source;matter[3]+=m*trace_source
    return tuple(matter)
