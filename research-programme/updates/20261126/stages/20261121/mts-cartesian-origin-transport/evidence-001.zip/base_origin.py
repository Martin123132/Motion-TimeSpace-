from pathlib import Path
import csv
import sys
import json
from contextlib import contextmanager

HERE=Path(__file__).resolve().parent
PREVIOUS=HERE.parent/"mts-polar-momentum-transport-20261121"
sys.path.insert(0,str(PREVIOUS))
import polar_scope as prior
from polar_scope import Cold,Wave,Difference,np,core,local,patch
from trial import sources
from split_curvature import revised
import evolve8


def guard():
    prior.guard()
    if (HERE/"STOP-REQUESTED").exists() or (PREVIOUS/"STOP-REQUESTED").exists():raise RuntimeError("owner hold")


def lock():
    guard()
    seal=PREVIOUS/"seal.json"
    assert core.sha(seal)=="6ee90f4b558ca171b42359b8911c118e2382203876900867e3b97b14886a8b70"
    for key,value in json.loads(seal.read_bytes())["files"].items():assert core.sha(PREVIOUS/key)==value,key
    return prior.locked()


@contextmanager
def environment(grid):
    with prior.workspace(grid),patch.object(local,"HERE",HERE):yield


def restart(model,grid,seed,tick):
    if not tick:return np.zeros_like(model.shell.initial),0.
    name=PREVIOUS/f"split{grid}-s{seed}-off{int(model.shell.flag)}-t{tick}.npz"
    assert json.loads(name.with_suffix(".json").read_bytes())["sha"]==core.sha(name)
    with np.load(name) as bank:
        return Difference(bank["base"],bank["delta"]),tick*(4096*np.pi/(1024*model.shell.mu))


def unpack(coeff,r2):
    lead,mixed,iso,quartic=coeff
    return lead+r2*(2*mixed+iso+r2*quartic),-lead/2+r2*iso,(lead+r2*mixed)/2,lead/2


def pack(rr,avg,cross,tangent,r2):
    return (2*tangent,2*(cross-tangent)/r2,(avg+tangent)/r2,(rr-avg-4*cross+tangent)/r2**2)
