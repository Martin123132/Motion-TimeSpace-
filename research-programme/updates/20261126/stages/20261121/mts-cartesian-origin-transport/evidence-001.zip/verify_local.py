from base_origin import *
from collections import Counter
import local_case as carrier

def main():
    lock()
    names=("base_origin.py","cartesian_ricci.py","chart_origin.py","cartesian_witness.py","centre_evolution.py","saved_centre.py","launch_acceleration.py","green_origin.py","verify_local.py","RESULTS.md","saved-origin-coefficients.csv","launch-to-endpoint.csv","green-first-element.csv","launch-source-comparison.csv","manufactured-evolution.csv","independent-cartesian.json")
    counts={"saved-origin-coefficients.csv":390,"launch-to-endpoint.csv":144,"green-first-element.csv":42,"launch-source-comparison.csv":6,"manufactured-evolution.csv":8}
    assert len(json.loads((HERE/"independent-cartesian.json").read_bytes())["rows"])==5
    for name,number in counts.items():
        records=core.read(HERE/name)
        assert len(records)==number and all(None not in row and all(row.values()) for row in records)
    keys=[(row["grid"],row["seed"],row["flag"]) for row in core.read(HERE/"launch-source-comparison.csv")]
    assert len(set(keys))==6
    assert all("original" not in name for name in names)
    banks=[carrier.launch(1024,flag,seed)[1] for flag in (0,1) for seed in (0,1,-1)]
    seal=dict(previous=core.sha(PREVIOUS/"seal.json"),files={name:core.sha(HERE/name) for name in names},rows=counts,green_inputs={path.name:core.sha(path) for path in banks})
    with environment(640):local.manifest("seal.json",seal)
    print(core.sha(HERE/"seal.json"),len(names),sum(counts.values()))
if __name__=="__main__":main()
