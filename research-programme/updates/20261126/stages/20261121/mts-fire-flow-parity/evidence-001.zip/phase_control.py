import json
import mpmath as mp
from unittest.mock import patch
from parity import original, np, maximum, HOME, EVEN, ODD, key, digest, record
mp.mp.dps = 60


def canonical(state, rotate=False):
    phase = mp.exp(mp.j * mp.mpf('0.71')) if rotate else 1
    values = [mp.mpc(value.item()) * phase for value in state]
    pivot = values[np.argmax(abs(state))]
    unit = mp.conj(pivot) / abs(pivot)
    return np.array([complex(unit * value) for value in values])


def run():
    frozen = json.loads((HOME / 'frozen.json').read_bytes())
    legacy = json.loads((HOME / 'parity-results.json').read_bytes())
    assert legacy['maximum'] > 1e-9 and legacy['frozen'] == digest(HOME / 'frozen.json')
    box = original.Experiment(0, 1)
    initial = box.lab.initial.copy()
    variants = {'canonical': canonical, 'canonical_reversed': lambda state: canonical(state.conj()),
                'canonical_high_phase': lambda state: canonical(state, True),
                'canonical_rounded_phase': lambda state: canonical(np.exp(.71j) * state), 'quarter_turn': lambda state: 1j * state}
    references = {}
    report = {}
    for mode, transform in variants.items():
        original.guard()
        box.lab.initial = {arm: transform(state) for arm, state in initial.items()}
        residuals = {}
        array_errors = {}
        differences = {}
        for arm, state in box.lab.initial.items():
            if mode == 'canonical':
                references[arm] = state.copy()
            reference = references[arm].conj() if mode == 'canonical_reversed' else references[arm]
            if mode != 'quarter_turn':
                array_errors[arm] = maximum(state - reference) / maximum(reference)

        def sink(name, **fields):
            from freeze import SOURCE
            arm = name.split('-')[1]
            norm = {'V', 'V_r', 'r'}
            with np.load(SOURCE / name) as prior:
                for field, measured in fields.items():
                    if mode == 'canonical':
                        references[arm, field] = measured.copy()
                    ref = prior[field] if mode == 'quarter_turn' else references[arm, field]
                    sign = -1 if mode == 'canonical_reversed' and field not in norm else 1
                    residuals[f'{arm}/{field}'] = maximum(measured - sign * ref) / maximum(ref)

        def rows_sink(path, rows, _):
            if not path.name.startswith('single-state'):
                return
            for row in rows:
                lookup = key(row)
                for field in EVEN + ODD:
                    if mode == 'canonical':
                        references[lookup, field] = row[field]
                    reference = legacy['echoes']['forward'][lookup][field] if mode == 'quarter_turn' else references[lookup, field]
                    sign = -1 if mode == 'canonical_reversed' and field in ODD else 1
                    prefix = f"{row['arm']}/{row['method']}/"
                    scale = max(abs(values[field]) for name, values in frozen['expected_reversed'].items() if name.startswith(prefix))
                    residuals[f'{lookup}/{field}'] = abs(row[field] - sign * reference) / scale
                    differences[f'{lookup}/{field}'] = abs(row[field] - sign * legacy['echoes']['forward'][lookup][field]) / scale
        with patch.multiple(original, Experiment=lambda *_: box, packet=sink, table=rows_sink):
            original.calculate(12)
        report[mode] = dict(worst_internal=max(residuals.values()), worst_vs_original_echo=max(differences.values()),
                            internal_errors=residuals, archive_echo_errors=differences, state_errors=array_errors)
        print(mode, report[mode]['worst_internal'], report[mode]['worst_vs_original_echo'], flush=True)
    record('phase-followup.json', dict(failed_receipt=digest(HOME / 'parity-results.json'),
                                      plan=digest(HOME / 'PHASE-CONTROL.md'), comparisons=report))


if __name__ == '__main__':
    run()
