import os
for variable in ('OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS', 'NUMEXPR_NUM_THREADS', 'BLIS_NUM_THREADS'):
    os.environ[variable] = '1'
import sys
import json
from freeze import HOME, SOURCE, digest, record
sys.path.insert(0, str(SOURCE))
from shoot_gr import Metric, propagate, guard, LIGHT, np
from release_fields import Sky, CubicHermiteSpline, CubicSpline


class CurrentMetric(Metric):
    basis = Sky.basis

    def __init__(self, path, gain):
        self.gain = gain / LIGHT**3
        with np.load(path) as fields:
            self.rad = fields['r']
            self.ell = 2 * np.arange(fields['br'].shape[1])
            self.factors = self.ell * (self.ell + 1)
            self.rate = CubicHermiteSpline(self.rad, fields['Vdot'], fields['Vdot_r'], extrapolate=False)
            self.shift = CubicSpline(self.rad, np.stack([fields['br'], fields['bt']], axis=1), extrapolate=False)

    def position(self, label):
        return label.copy()

    def at(self, time, position):
        radius, radial, polar, values, slopes, seconds = self.basis(position)
        rate = self.rate(radius)
        scalar = self.gain * time * (rate @ values)
        gradient = self.gain * time * ((self.rate(radius, 1) @ values) * radial + (rate @ slopes) * polar / radius)
        parallel, transverse = self.shift(radius)
        normal, tangent = parallel @ values, transverse @ slopes
        vector = self.gain * (normal * radial + tangent * polar)
        normal_slope, tangent_slope = self.shift(radius, 1)
        jacobian = self.gain * (np.outer((normal_slope @ values) * radial + (tangent_slope @ slopes) * polar, radial)
            + np.outer(((parallel @ slopes) - tangent) * radial + ((transverse @ seconds) + normal) * polar, polar) / radius)
        inverse = np.exp(2 * scalar)
        shift = inverse * vector
        lapse = np.sqrt(inverse + vector @ shift)
        shift_gradient = inverse * (jacobian + 2 * np.outer(vector, gradient))
        lapse_gradient = ((inverse + vector @ shift) * gradient + jacobian.T @ shift) / lapse
        return lapse, lapse_gradient, inverse, gradient, shift, shift_gradient


def run():
    frozen = json.loads((HOME / 'frozen.json').read_bytes())
    expected = frozen['expected_reversed']
    assert digest(HOME / 'PROTOCOL.md') == frozen['rules']
    result = []
    for arm in ('reset', 'coupled'):
        name = f'current-{arm}-12.npz'
        assert digest(SOURCE / name) == frozen['archive'][name]
        for gain in (2.e7, 1.e7):
            differential = []
            rates = {}
            maximum_miss = 0.
            for sign in (1, -1):
                metric = CurrentMetric(SOURCE / name, sign * gain)
                track = []
                for left, right in ((6., 7.15), (7.15, 8.3), (6., 8.3)):
                    guard()
                    labels = np.array([[left, 1.5], [right, 1.5]])
                    observations, residuals = propagate(metric, 2, labels, True)
                    track.append(observations[-1])
                    maximum_miss = max(maximum_miss, residuals[-1])
                rates[str(sign)] = track + [2 * (track[0] + track[1]) - track[2]]
            numerical = (np.array(rates['1']) - rates['-1']) / (2 * gain)
            for value, label in zip(numerical, ('echo/6.0/7.15', 'echo/7.15/8.3', 'echo/6.0/8.3', 'three/6.0/8.3'), strict=True):
                forward = -expected[f'{arm}/flux/{label}']['current_rate']
                differential.append(dict(link=label, shot=value, forecast=forward, fractional_error=value / forward - 1))
            result.append(dict(arm=arm, gain=gain, raw_log_rates=rates, maximum_miss_kpc=maximum_miss, links=differential))
            print(arm, gain, max(abs(row['fractional_error']) for row in differential), flush=True)
    record('ray-results.json', dict(frozen=digest(HOME / 'frozen.json'), shoots=result))
    assert all(abs(row['fractional_error']) < .005 for item in result for row in item['links'])


if __name__ == '__main__':
    run()
