import os
for variable in ('OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS', 'NUMEXPR_NUM_THREADS', 'BLIS_NUM_THREADS'):
    os.environ[variable] = '1'
import sys
import json
from unittest.mock import patch
from freeze import HOME, SOURCE, EVEN, ODD, key, digest, record
sys.path.insert(0, str(SOURCE))
import absolute_current as original
from absolute_current import np


def maximum(array):
    return float(np.max(np.abs(array)))


def run():
    frozen = json.loads((HOME / 'frozen.json').read_bytes())
    assert digest(HOME / 'PROTOCOL.md') == frozen['rules']
    for name, fingerprint in frozen['archive'].items():
        assert digest(SOURCE / name) == fingerprint, name
    expected = frozen['expected_reversed']
    original.guard()
    box = original.Experiment(0, 1)
    initial = box.lab.initial.copy()
    assert set(initial) == {'reset', 'coupled'}
    controls = {
        'forward': lambda state: state.copy(), 'reversed': np.conjugate,
        'phase': lambda state: np.exp(0.71j) * state,
        'standing': lambda state: state.real.astype(complex),
        'empty': np.zeros_like,
    }
    captures = {}
    reference_current = {}
    fields = ('V', 'V_r', 'Vdot', 'Vdot_r', 'br', 'bt', 'Vdot_operator', 'Vdot_operator_r')
    checks = {}
    echoes = {}
    native_density = {arm: abs(box.obj.sky(state))**2 for arm, state in initial.items()}
    sources = original.direct_current
    def check(label, discrepancy, scale):
        assert scale > 0 and np.isfinite(discrepancy)
        checks[label] = float(discrepancy / scale)

    for mode, transform in controls.items():
        original.guard()
        box.lab.initial = {arm: transform(state) for arm, state in initial.items()}
        for arm, state in box.lab.initial.items():
            density = abs(box.obj.sky(state))**2
            mass = float(np.vdot(state, state).real)
            reference_mass = float(np.vdot(initial[arm], initial[arm]).real)
            if mode == 'standing':
                assert 0 < mass <= reference_mass and maximum(density) > 0
            else:
                check(f'{mode}/{arm}/occupation', abs(mass - (0 if mode == 'empty' else reference_mass)), reference_mass)
                check(f'{mode}/{arm}/density', maximum(density - (0 if mode == 'empty' else native_density[arm])), maximum(native_density[arm]))
        arms = iter(box.lab.initial)
        odd_sign = {'forward': 1, 'reversed': -1, 'phase': 1, 'standing': 0, 'empty': 0}[mode]

        def projected(*args):
            arm = next(arms)
            for component, measured in zip(('radial', 'polar'), args[-2:], strict=True):
                lookup = arm, component
                if mode == 'forward':
                    reference_current[lookup] = measured.copy()
                truth = reference_current[lookup]
                check(f'{mode}/{arm}/current/{component}', maximum(measured - odd_sign * truth), maximum(truth))
            return sources(*args)

        def field_sink(name, **arrays):
            with np.load(SOURCE / name) as saved:
                assert np.array_equal(arrays['r'], saved['r'])
                for field in fields:
                    assert np.isfinite(arrays[field]).all()
                    if mode == 'standing' and field in ('V', 'V_r'):
                        assert maximum(arrays[field]) > 0
                        continue
                    sign = (0 if mode == 'empty' else 1) if field in ('V', 'V_r') else odd_sign
                    check(f'{mode}/{name}/{field}', maximum(arrays[field] - sign * saved[field]), maximum(saved[field]))

        def table_sink(path, rows, _):
            captures[path.name] = rows

        with patch.multiple(original, Experiment=lambda *_: box, packet=field_sink, table=table_sink, direct_current=projected):
            original.calculate(12)
        rows = captures['single-state-echo-12.csv']
        assert len(rows) == 16 and {key(row) for row in rows} == set(expected)
        echoes[mode] = {key(row): {field: row[field] for field in EVEN + ODD} for row in rows}
        for row in rows:
            identifier = key(row)
            group = [values for item, values in expected.items() if item.startswith(f"{row['arm']}/{row['method']}/")]
            for field in EVEN + ODD:
                if mode == 'standing' and field in EVEN:
                    continue
                expected_value = expected[identifier][field] * ((0 if mode == 'empty' else 1) if field in EVEN else -odd_sign)
                check(f'{mode}/{identifier}/{field}', abs(row[field] - expected_value), max(abs(item[field]) for item in group))
        print(mode, 'completed', flush=True)
    box.lab.initial = initial
    record('parity-results.json', dict(echoes=echoes, errors=checks, worst=max(checks, key=checks.get),
                                      maximum=max(checks.values()), frozen=digest(HOME / 'frozen.json')))
    assert max(checks.values()) < 1e-9


if __name__ == '__main__':
    run()
