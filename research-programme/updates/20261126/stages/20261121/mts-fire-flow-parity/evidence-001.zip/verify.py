import json
import math
import sys
from freeze import HOME, SOURCE, ODD, EVEN, forecast, digest, record

FROZEN = '3fb9feeaa7795af59605fadf14127e28f6df80af060c77f309b6221824a4fd39'
PARENT = '671b6c36d09b0e23ac80fc8d4677b6149c1a6783c940f8c1fc84367640f5197b'


def read(path):
    return json.loads(path.read_bytes())


def verify(create=False):
    assert digest(HOME / 'frozen.json') == FROZEN and digest(SOURCE / 'seal.json') == PARENT
    expected = forecast()
    assert expected == read(HOME / 'frozen.json')
    for name, signature in read(SOURCE / 'seal.json').items():
        assert digest(SOURCE / name) == signature
    for path in HOME.glob('*.py'):
        compile(path.read_bytes(), str(path), 'exec')
    parity = read(HOME / 'parity-results.json')
    rays = read(HOME / 'ray-results.json')
    assert rays['frozen'] == parity['frozen'] == FROZEN
    failures = [name for name, error in parity['errors'].items() if error >= 1e-9]
    assert len(parity['errors']) == 576 and len(failures) == 18 and all(name.startswith('phase/') for name in failures)
    assert all(math.isfinite(value) for value in parity['errors'].values())
    for label, prediction in expected['expected_reversed'].items():
        reverse = parity['echoes']['reversed'][label]
        assert all(reverse[field] == prediction[field] for field in EVEN + ODD)
        for mode in ('standing', 'empty'):
            assert all(parity['echoes'][mode][label][field] == 0 for field in ODD)
        assert parity['echoes']['empty'][label]['newton'] == 0
    assert {(item['arm'], item['gain']) for item in rays['shoots']} == {(arm, gain) for arm in ('reset','coupled') for gain in (1e7,2e7)}
    errors = []
    for item in rays['shoots']:
        assert item['maximum_miss_kpc'] < 4e-12 and len(item['links']) == 4
        for index, row in enumerate(item['links']):
            target = -expected['expected_reversed'][f"{item['arm']}/flux/{row['link']}"]['current_rate']
            measured = (item['raw_log_rates']['1'][index]-item['raw_log_rates']['-1'][index]) / (2*item['gain'])
            assert measured == row['shot'] and target == row['forecast']
            errors.append(abs(measured / target - 1))
    assert len(errors) == 16 and max(errors) < .005
    phase = read(HOME / 'phase-followup.json')
    assert phase['failed_receipt'] == digest(HOME / 'parity-results.json') and phase['plan'] == digest(HOME / 'PHASE-CONTROL.md')
    results = phase['comparisons']
    assert all(results[mode]['worst_internal'] < 1e-9 for mode in ('canonical_high_phase', 'canonical_reversed', 'quarter_turn'))
    assert results['canonical_rounded_phase']['worst_internal'] >= 1e-9 and results['canonical']['worst_vs_original_echo'] >= 1e-9
    verdict = dict(flow_reversal='pass', original_uniform_phase='failed', original_exceedances=sorted(failures),
                   canonically_prepared_uniform_phase='pass', rounded_before_canonicalization='failed',
                   ray_comparisons=len(errors), max_ray_relative=max(errors))
    if create:
        record('verdict.json', verdict)
    assert read(HOME / 'verdict.json') == verdict
    hashes = {path.name: digest(path) for path in sorted(HOME.iterdir()) if path.is_file() and path.name != 'seal.json'}
    if create:
        record('seal.json', hashes)
    assert read(HOME / 'seal.json') == hashes
    print('Verified', len(hashes), 'files', digest(HOME / 'seal.json'), 'including the original failed phase control')


if __name__ == '__main__':
    if not __debug__:
        raise RuntimeError('Verification needs assertions enabled')
    verify(sys.argv[1:] == ['--seal'])
