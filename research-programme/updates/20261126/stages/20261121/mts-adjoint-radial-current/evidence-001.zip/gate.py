from bridge import *
from operators import Radial
import flat_checks


def main():
    locked()
    rows=[]
    for cells in (48,96,192):
        mesh=Radial(cells,3.)
        grad=np.stack([mesh.grad(row)[1:-1] for row in np.eye(cells)],axis=1)
        div=np.stack([mesh.back(np.pad(row,(1,1))) for row in np.eye(cells-1)],axis=1)
        adjoint=np.max(abs(grad.T+div))*mesh.h
        assert adjoint<2e-15
        maximum=mesh.h*np.sqrt(mesh.spectrum(6,0)[-1])
        assert maximum*.12<2
        for power in (2,6):
            for degree in (2,4):
                actual=mesh.lap(mesh.r**degree,power)
                exact=degree*(power+degree-1)*mesh.r**(degree-2)
                err=abs(actual-exact)
                if degree==2:assert max(err[:4])<2e-9
                rows.append(dict(cells=cells,power=power,degree=degree,first_error=err[0],
                                 centre_max=max(err[:4]),interior_max=max(err[4:-10]),max_frequency_h=maximum,
                                 adjoint=adjoint))
    with output(),patch.object(flat_checks,"Chart",Radial):
        flat_checks.test()
        flat_checks.physical()
        local.table("origin-polynomials.csv",rows)
    print("origin",rows[-1],flush=True)


if __name__=="__main__":
    main()
