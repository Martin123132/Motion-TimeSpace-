from bridge import *
import math


def numeric(path):
    return core.read(HERE/path)


def run():
    locked()
    assert not list(HERE.rglob("*.partial"))
    freeze=json.loads((HERE/"refinement-freeze.json").read_bytes())
    for name,digest in {**freeze["sources"],**freeze["control_digests"]}.items():assert core.sha(HERE/name)==digest,name
    for control in ("flat-conservation.csv","regular-checks/flat-conservation.csv"):
        assert all(float(row["H_transport"])<2e-13 and float(row["M_transport"])<2e-13 for row in numeric(control))
    assert len(numeric("regular-centre.csv"))==18 and max(float(row["centre_six_abs"]) for row in numeric("regular-centre.csv"))<1e-8
    assert all(float(row["adjoint"])<2e-15 for row in numeric("regular-checks/origin-polynomials.csv"))
    assert math.isclose(float(numeric("regular-checks/tensor-wave.csv")[-1]["speed_error"]),6.78155e-6,rel_tol=1e-5)
    counts=[]
    forecasts=core.read(local.PREVIOUS/"predicted-gravity.csv")
    for grid,seed,steps in ((160,1,512),(320,1,512),(320,-1,512),(320,1,1024),(640,1,1024),(640,-1,1024)):
        tag=f"clock-adm-{grid}-s{seed}" if steps==512 else f"halfstep-{grid}-s{seed}"
        protocol=json.loads((HERE/(tag+"-protocol.json")).read_bytes())
        assert protocol["steps"]==steps and protocol["ppm_gate"]==20 and protocol["source"]=={name:core.sha(HERE/name) for name in protocol["source"]}
        rows=numeric(tag+"-q4.csv")
        keys=set()
        for row in rows:
            tick,width,ch=int(row["tick"]),float(row["width"]),row["channel"]
            ref,=[item for item in forecasts if item["mode"]=="flrw-live" and int(item["seed"])==seed and float(item["fraction"])==tick/steps and float(item["width"])==width]
            assert row["newton"]==ref["newton"] and row["forecast"]==ref["prediction"]
            error=(float(row["measured"])-float(row["forecast"]))/(abs(float(row["newton"]))*1e-6)
            assert abs(error-float(row["residual_ppm"]))<1e-8 and (abs(error)<=20)==(row["inside"]=="True")
            keys.add((tick,width,ch))
        assert keys=={(tick,width,ch) for tick in range(steps//4,steps+1,steps//4) for width in (.15,.30) for ch in ("gauss","ricci")} and len(rows)==16
        for tick in range(steps//4,steps+1,steps//4):
            for flag in (0,1):
                with np.load(HERE/f"{tag}-off{flag}-t{tick}.npz") as bank:
                    assert int(bank["tick"])==tick and bank["signed"].shape==(20,2,3*grid)
                    assert all(np.isfinite(bank[key]).all() for key in bank.files)
        counts.append(sum(row["inside"]=="True" for row in rows))
    assert len(numeric("retained-number-prediction.csv"))==20
    assert len(numeric("retained-finite-shell-number.csv"))==24
    tests=numeric("independent-mesh-forecast.csv")
    assert len(tests)==16
    for row in tests:
        assert (abs(float(row["mesh_forecast_error"]))<=float(row["prospective_precision_ppm"]))==(row["mesh_forecast_pass"]=="True")
    for seed in (1,-1):
        tag=f"clock-adm-320-s{seed}"
        assert len(numeric(tag+"-weak-current.csv"))==72 and len(numeric(tag+"-material-512.csv"))==180
        scores=numeric(tag+"-momentum-mismatch.csv")
        assert len(scores)==15 and all(math.isfinite(float(row["face_relative"])) for row in scores)
        final,=[row for row in scores if row["branch"]=="wave-minus-dust" and row["tick"]=="512"]
        assert float(final["unexplained_fraction"])<.001 and float(final["face_relative"])<2e-8
        checks=numeric(f"halfstep-640-s{seed}-constraints.csv")
        assert len(checks)==54 and all(math.isfinite(float(row["signed_absolute"])) for row in checks)
        mass=numeric(f"halfstep-640-s{seed}-mass-identity-on-slices.csv")
        assert len(mass)==48 and min(float(row["min_U"]) for row in mass)>0
        assert len(numeric(f"halfstep-640-s{seed}-ruler.csv"))==16
    for size in (32,48):
        selected=[row for row in numeric(f"monopole-{size}-both.csv") if row["tick"]=="1024"]
        assert len(selected)==4 and max(abs(float(row["magnitude_ratio"])-1) for row in selected)<.001
        assert max(int(row["cells99"]) for row in selected)==8
    assert len(json.loads((HERE/"spherical-identities.json").read_bytes())["exact"])==5
    assert len(json.loads((HERE/"spherical-inverse.json").read_bytes())["exact"])==3
    assert all(float(row["continuity_with_work"])<1e-12 and float(row["momentum_with_work"])<1e-12
               and float(row["origin"])<1e-8 for row in numeric("spherical-mass-waves.csv"))
    inventory={item.relative_to(HERE).as_posix():core.sha(item) for item in sorted(HERE.rglob("*")) if item.is_file() and item.name!="seal.json"}
    record=dict(parent=core.sha(PARENT/"seal.json"),files=inventory)
    if sys.argv[1:]==["--seal"]:
        with output():local.manifest("seal.json",record)
    else:assert len(sys.argv)==1
    assert json.loads((HERE/"seal.json").read_bytes())==record
    print(len(inventory),"files; tide counts",counts,"/16 per grid and sign;",core.sha(HERE/"seal.json"),flush=True)


if __name__=="__main__":
    run()
