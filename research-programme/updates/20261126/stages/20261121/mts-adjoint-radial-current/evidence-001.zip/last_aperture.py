from clock12 import *
from decimal import getcontext
from ruler import separate


def run(grid,seed,steps):
    locked()
    getcontext().prec=46
    tag=f"clock-adm-{grid}-s{seed}" if steps==512 else f"halfstep-{grid}-s{seed}"
    scores=core.read(HERE/(tag+"-q4.csv"))
    result=[]
    fields=[]
    readings={}
    def system(flag,seed,scheme):
        with patch.object(case.parent.evolve_speed,"launch",case.parent.launch):
            return case.parent.evolve_speed.system(1024,grid,flag,seed,scheme,3)[0]
    with patch.object(case.parent,"system",system):
        for flag in (0,1):
            model=Evolution(1,seed,"adm") if flag else Canonical(seed,"adm")
            radius=model.shell.r
            for tick in range(steps//4,steps+1,steps//4):
                with np.load(HERE/f"{tag}-off{flag}-t{tick}.npz") as bank:
                    actual=Difference(bank["physical_shared"],bank["physical_signed"])
                    clock=tick*float(bank["step"])
                for harmonic in (0,1):
                    profile=actual.delta[0,harmonic].real
                    fields.append(dict(grid=grid,seed=seed,tick=tick,flag=flag,ell=harmonic*2,
                        first_value=profile[0],max_inner=max(abs(profile[radius<.3])),
                        max_inner_cell=np.argmax(abs(profile[radius<.3])),
                        rms_interior=np.linalg.norm(profile[(radius>.6)&(radius<2.1)])/np.sqrt(sum((radius>.6)&(radius<2.1)))))
                signed=separate(model.host,clock,actual)
                control=separate(model.zero,clock,actual.base)
                for key in signed:readings[flag,tick,*key]=signed[key]-control[key]
    for row in scores:
        tick,width,ch=int(row["tick"]),float(row["width"]),row["channel"]
        parts={part:readings[0,tick,width,ch,part]-readings[1,tick,width,ch,part] for part in ("sampled_field","local_jacobian","integrated_distance","full")}
        unit=abs(float(row["newton"]))*1e-6
        full=(parts["full"]-float(row["forecast"]))/unit
        diff=abs(full-float(row["residual_ppm"]))
        result.append(dict(grid=grid,seed=seed,tick=tick,width=width,channel=ch,field_ppm=(parts["sampled_field"]-float(row["forecast"]))/unit,
                    jacobian_ppm=parts["local_jacobian"]/unit,ruler_ppm=parts["integrated_distance"]/unit,
                    full_ppm=full,replay_difference=diff))
        assert diff<.01
    with output():
        local.table(tag+"-ruler.csv",result)
        local.table(tag+"-centre.csv",fields)


if __name__=="__main__":
    run(*map(int,sys.argv[1:]))
