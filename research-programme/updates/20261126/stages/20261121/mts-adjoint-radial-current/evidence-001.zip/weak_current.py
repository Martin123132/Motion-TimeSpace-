from material import *
from scipy.special import eval_legendre


def run(grid,seed):
    locked()
    tag=f"clock-adm-{grid}-s{seed}"
    rows=[]
    def system(flag,seed,scheme):
        with patch.object(case.parent.evolve_speed,"launch",case.parent.launch):
            return case.parent.evolve_speed.system(1024,grid,flag,seed,scheme,3)[0]
    with ExitStack() as stack:
        setup(stack)
        stack.enter_context(patch.object(case.parent,"system",system))
        profiles={}
        for flag in (0,1):
            model=evolve8.Cold(seed,"adm") if flag else evolve8.Wave(seed,"adm")
            for tick in (0,128,512):
                if tick:
                    with np.load(HERE/f"{tag}-off{flag}-t{tick}.npz") as bank:
                        state=Difference(bank["shared"],bank["signed"]); time=tick*float(bank["step"])
                else:state=np.zeros_like(model.shell.initial);time=0.
                values=current(model,state,time)
                for direction in ("radial","polar"):
                    profiles[flag,tick,direction]=np.array([term.delta for term in values["all",direction]])
        for tick in (0,128,512):
            for direction in ("radial","polar"):
                radius=model.lift.mesh.faces[1:] if direction=="radial" else model.shell.r
                unit=(radius-.6)/1.5
                inside=(unit>0)&(unit<1)
                unit=unit[inside]
                wave=profiles[0,tick,direction][:,inside]
                dust=profiles[1,tick,direction][:,inside]
                for branch,triple in (("wave",wave),("dust",dust),("wave-minus-dust",wave-dust)):
                    measured,kj,div=triple
                    defect=measured-kj+div
                    scale=max(np.linalg.norm(arr) for arr in triple)
                    taper=(4*unit*(1-unit))**4
                    spectrum=np.abs(np.fft.rfft(defect*taper,norm="ortho"))**2
                    spectrum[1:(-1 if len(unit)%2==0 else None)]*=2
                    freq=np.fft.rfftfreq(len(unit))
                    for degree in range(4):
                        weight=taper*eval_legendre(degree,2*unit-1)
                        bound=np.linalg.norm(weight)*scale
                        rows.append(dict(grid=grid,seed=seed,tick=tick,direction=direction,branch=branch,degree=degree,
                                         strong=np.linalg.norm(defect)/scale,weak=np.dot(weight,defect)/bound,
                                         high_freq_power_share=np.sum(spectrum[freq>=.125])/np.sum(spectrum),
                                         period_definition="at most eight radial cell spacings"))
        local.table(tag+"-weak-current.csv",rows)


if __name__=="__main__":
    run(int(sys.argv[1]),int(sys.argv[2]))
