from material import *


def evaluate(model,state,time):
    shell=model.shell
    mesh=model.lift.mesh
    rf=mesh.faces
    cold=bool(shell.flag)
    rate=model.rhs(time,state) if cold else model.nonlinear(time,state)
    stored,geo,bg,_=model.lift.physical(state,time)
    change=stored if cold else model.to_wave(stored)
    actual=shell.initial+change
    K=actual[4].real
    ell_dot=-K/3-actual[5].real
    bend_dot=-K/3+actual[5].real/2
    def map_face(operand,apply):
        return pair(apply(operand[0]),apply(operand[1]))
    face=lambda operand:map_face(operand,mesh.face)
    odd=lambda operand:map_face(operand,mesh.odd_face)
    grad=lambda operand:map_face(operand,mesh.grad)
    volume=exp(-actual[0].real-2*actual[1].real)
    radial=mul(face(exp(actual[0].real)),odd(actual[18].real))
    derivative=mul(face(mul(exp(actual[0].real),ell_dot)),odd(actual[18].real))+mul(face(exp(actual[0].real)),odd(rate[18].real))
    for species in range(3 if cold else 2):
        number,potential=actual[8+2*species:10+2*species].real
        ndot,pdot=rate[8+2*species:10+2*species].real
        rest=shell.rho[species]*mul(volume,number)
        dr=shell.rho[species]*mul(volume,ndot-mul(number,ell_dot+2*bend_dot))
        radial+=mul(face(rest),grad(potential))
        derivative+=mul(face(dr),grad(potential))+mul(face(rest),grad(pdot))
    mismatch=0*radial[1,1:]
    if not cold:
        mu=shell.mu
        wave,zeta=actual[14:16]
        zdot=rate[15]+2j*mu*state[15]
        mr=zeta.real+K/(2*mu)
        mi=zeta.imag-model.unit
        mrdot=zdot.real+rate[4].real/(2*mu)
        adot=(mul(rate[14].real,inv(model.initial_number+stored[14].real))-ell_dot-2*bend_dot+
              mul(zdot.imag,inv(model.unit-zeta.imag)))/2
        density=shell.rho[-1]*exp(2*wave.real)
        phase=grad(shell.initial[14].imag)+grad(change[14].imag)
        phase[0]+=mesh.grad(model.remainder)
        ampl=grad(shell.initial[14].real)+grad(change[14].real)
        pairgrad=mul(face(mr),ampl)+mul(face(mi),phase)
        radial-=mul(face(density),pairgrad)/mu
        derivative-=(mul(face(mul(2*adot,density)),pairgrad)+mul(face(density),
             mul(face(mrdot),ampl)+mul(face(zdot.imag),phase)+mul(face(mr),grad(adot))
             +mul(face(mi),mu*grad(zeta.imag))))/mu
        model.bind(actual,change)
        try:
            cell=shell.diff(zeta.imag)
            mismatch=(rf*(odd(mul(density,cell))-mul(face(density),grad(zeta.imag)))[1])[1:]
        finally:
            model.active={};model.elapsed=None
    force=rf*(derivative-mul(face(K),radial))[1]
    _,press,sr,sc,st=sources(model,time,change)
    div=model.lift.divergence(press/3,sr,sc,st,geo,bg)[0]
    profile=current(model,state,time)["all","radial"]
    return [profile[0],profile[0]-profile[1]+profile[2],mismatch,force[1:]+div,div]


def check(grid,seed):
    tag=f"clock-adm-{grid}-s{seed}"
    def system(flag,seed,scheme):
        with patch.object(case.parent.evolve_speed,"launch",case.parent.launch):
            return case.parent.evolve_speed.system(1024,grid,flag,seed,scheme,3)[0]
    outputs=[]
    data={}
    with ExitStack() as stack:
        setup(stack)
        stack.enter_context(patch.object(case.parent,"system",system))
        for flag in (0,1):
            model=evolve8.Cold(seed,"adm") if flag else evolve8.Wave(seed,"adm")
            for tick in (0,128,256,384,512):
                if tick:
                    with np.load(HERE/f"{tag}-off{flag}-t{tick}.npz") as snap:
                        state=Difference(snap["shared"],snap["signed"]);time=tick*float(snap["step"])
                else:state=np.zeros_like(model.shell.initial);time=0.
                result=evaluate(model,state,time)
                for idx,term in enumerate(result):data[flag,tick,idx]=term.delta
        radius=model.lift.mesh.faces[1:]
        select=(radius>.6)&(radius<2.1)
        for tick in (0,128,256,384,512):
            for label in ("wave","dust","wave-minus-dust"):
                def series(idx):
                    wave=data[0,tick,idx][select]
                    dust=data[1,tick,idx][select]
                    return {"wave":wave,"dust":dust,"wave-minus-dust":wave-dust}[label]
                measured,defect,pred,aligned,div=map(series,range(5))
                norm=np.linalg.norm
                unit=max(norm(measured),norm(div))
                outputs.append(dict(grid=grid,seed=seed,tick=tick,branch=label,cell_relative=norm(defect)/unit,
                                    prediction_over_defect=norm(pred)/norm(defect),cosine=np.dot(defect,pred)/(norm(defect)*norm(pred)) if norm(pred) else "",
                                    unexplained_fraction=norm(defect-pred)/norm(defect),face_relative=norm(aligned)/unit,
                                    face_over_old=norm(aligned)/norm(defect)))
        local.table(tag+"-momentum-mismatch.csv",outputs)


if __name__=="__main__":
    locked()
    check(int(sys.argv[1]),int(sys.argv[2]))
