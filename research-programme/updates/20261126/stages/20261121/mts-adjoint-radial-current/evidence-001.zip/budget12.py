from clock12 import *
import clock_budget


if __name__=="__main__":
    locked()
    grid,quarters=map(int,sys.argv[1:])
    with output(),patch.object(clock_budget,"HERE",HERE),patch.object(clock_budget,"sources",pins):
        clock_budget.run("adm",grid,quarters)
