from bridge import *
import argparse
import curved_clock
import lift8,evolve8
from mts_sbp12 import Regular
from contextlib import ExitStack


def pins():
    return {name:core.sha(HERE/name) for name in ("bridge.py","operators.py","mts_sbp12.py","lift8.py","evolve8.py","clock12.py","regular-centre.csv","regular-checks/flat-conservation.csv","PROTOCOL.md")}


def setup(stack):
    stack.enter_context(output())
    stack.enter_context(patch.object(curved_clock,"sources",pins))
    stack.enter_context(patch.object(curved_clock,"Wave",evolve8.Wave))
    stack.enter_context(patch.object(curved_clock,"Cold",evolve8.Cold))
    stack.enter_context(patch.object(lift8,"Radial",Regular))


def main():
    args=argparse.ArgumentParser()
    args.add_argument("grid",type=int,choices=(160,320))
    args.add_argument("seed",type=int,choices=(1,-1))
    args.add_argument("quarters",type=int,choices=(1,4))
    options=args.parse_args()
    locked()
    with ExitStack() as stack:
        setup(stack)
        curved_clock.calculate("adm",options.grid,options.seed,options.quarters)


if __name__=="__main__":
    main()
