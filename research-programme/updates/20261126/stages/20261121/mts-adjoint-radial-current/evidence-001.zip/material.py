from clock12 import *
from number_chart import mul,exp,inv,pair
from trial import sources
from math import sqrt


def current(model,state,time):
    shell=model.shell
    cold=bool(shell.flag)
    stage=model.rhs(time,state) if cold else model.nonlinear(time,state)
    stored,geo,bg,rates=model.lift.physical(state,time)
    change=stored if cold else model.to_wave(stored)
    actual=shell.initial+change
    ell,bend=actual[:2].real
    trace=actual[4].real
    shear=actual[5].real
    ell_dot=-trace/3-shear
    bend_dot=-trace/3+shear/2
    jac=exp(ell)
    volume=exp(-ell-2*bend)
    B=shell.r*np.exp(bend[0])
    jr=mul(jac,actual[18].real)
    jt=B*actual[19,1].real
    radial_rate=mul(jac,stage[18].real+mul(ell_dot,actual[18].real))
    polar_rate=B*(stage[19,1].real+bend_dot[0]*actual[19,1].real)
    banks={"surrounding":(jr,jt,radial_rate,polar_rate)}
    energy,pressure,sr,sc,st=sources(model,time,change)
    obs=shell.incident.external(time)
    empty=pair(0*shell.r)
    stress={"all":(pressure,sr,sc,st),"surrounding":(pair(obs[1],obs[3]),pair(empty[0],obs[4]),obs[5],obs[6])}
    model.bind(actual,change)
    try:
        for species in range(3 if cold else 2):
            number,potential=actual[8+2*species:10+2*species].real
            ndot,pdot=stage[8+2*species:10+2*species].real
            rest=shell.rho[species]*mul(volume,number)
            rdot=shell.rho[species]*mul(volume,ndot-mul(number,ell_dot+2*bend_dot))
            grad=shell.diff(potential)
            jr=jr+mul(rest,grad)
            jt=jt+rest[0]*potential[1]
            radial_rate=radial_rate+mul(rdot,grad)+mul(rest,shell.diff(pdot))
            polar_rate=polar_rate+rdot[0]*potential[1]+rest[0]*pdot[1]
        if not cold:
            mu=shell.mu
            wave,zeta=actual[14:16]
            zdot=stage[15]+2j*mu*state[15]
            mom=zeta.real+trace/(2*mu)
            imag=zeta.imag-model.unit
            mdot=zdot.real+stage[4].real/(2*mu)
            idot=zdot.imag
            adot=(mul(stage[14].real,inv(model.initial_number+stored[14].real))-ell_dot-2*bend_dot
                  +mul(idot,inv(model.unit-zeta.imag)))/2
            phidot=mu*zeta.imag
            grad=shell.diff(wave)
            grad_dot=shell.diff(adot+1j*phidot)
            scale=-shell.rho[-1]*exp(2*wave.real)/mu
            radial=mul(mom,grad.real)+mul(imag,grad.imag)
            polar=mom[0]*wave[1].real+imag[0]*wave[1].imag
            jr=jr+mul(scale,radial)
            jt=jt+scale[0]*polar
            radial_rate=radial_rate+mul(scale,mul(2*adot,radial)+mul(mdot,grad.real)+mul(idot,grad.imag)
                                       +mul(mom,grad_dot.real)+mul(imag,grad_dot.imag))
            polar_rate=polar_rate+scale[0]*(2*adot[0]*polar+mdot[0]*wave[1].real+idot[0]*wave[1].imag
                                           +mom[0]*adot[1]+imag[0]*phidot[1])
    finally:
        model.active={};model.elapsed=None
    banks["all"]=(jr,jt,radial_rate,polar_rate)
    results={}
    mesh=model.lift.mesh
    for group,(radial,polar,dr,dt) in banks.items():
        press,shear,cross,angular=stress[group]
        divr,divt=model.lift.divergence(press/3,shear,cross,angular,geo,bg)
        actual_r=(mesh.faces*mesh.odd_face(dr[1]))[1:]
        trace_r=(mesh.faces*mesh.odd_face(mul(trace,radial)[1]))[1:]
        results[group,"radial"]=(actual_r,trace_r,divr)
        results[group,"polar"]=(dt,trace[0]*polar,divt)
    for direction in ("radial","polar"):
        results["particles",direction]=tuple(full-env for full,env in zip(results["all",direction],results["surrounding",direction],strict=True))
    return results


def run(grid,seed,ticks):
    locked()
    rows=[]
    tag=f"clock-adm-{grid}-s{seed}"
    def system(flag,seed,scheme):
        with patch.object(case.parent.evolve_speed,"launch",case.parent.launch):
            return case.parent.evolve_speed.system(1024,grid,flag,seed,scheme,3)[0]
    with ExitStack() as stack:
        setup(stack)
        stack.enter_context(patch.object(case.parent,"system",system))
        data={}
        for flag in (0,1):
            model=evolve8.Cold(seed,"adm") if flag else evolve8.Wave(seed,"adm")
            for tick in ticks:
                if tick:
                    with np.load(HERE/f"{tag}-off{flag}-t{tick}.npz") as snap:
                        stored=Difference(snap["shared"],snap["signed"])
                        time=tick*float(snap["step"])
                else:stored=np.zeros_like(model.shell.initial);time=0.
                values=current(model,stored,time)
                for (sector,direction),triple in values.items():
                    for member in ("base","delta"):
                        data[flag,tick,sector,direction,member]=np.array([getattr(item,member) for item in triple])
        for tick in ticks:
            for sector in ("all","particles","surrounding"):
                for direction in ("radial","polar"):
                    radius=model.lift.mesh.faces[1:] if direction=="radial" else model.shell.r
                    select=(radius>.6)&(radius<2.1)
                    for member in ("base","delta"):
                        same=tick,sector,direction,member
                        wave=data[(0,*same)]
                        dust=data[(1,*same)]
                        for branch,values in (("wave",wave),("dust",dust),("wave-minus-dust",wave-dust)):
                            measured,kj,div=values[:,select]
                            rms=lambda arr:np.linalg.norm(arr)/sqrt(arr.size)
                            residual=rms(measured-kj+div)
                            scale=max(rms(measured),rms(kj),rms(div))
                            rows.append(dict(grid=grid,seed=seed,tick=tick,sector=sector,direction=direction,member=member,
                                             branch=branch,rate=rms(measured),trace_work=rms(kj),divergence=rms(div),
                                             residual=residual,relative=residual/scale if scale else ""))
        local.table(tag+f"-material-{ticks[-1]}.csv",rows)
    print("material",grid,seed,len(rows),flush=True)


if __name__=="__main__":
    run(int(sys.argv[1]),int(sys.argv[2]),list(map(int,sys.argv[3:])))
