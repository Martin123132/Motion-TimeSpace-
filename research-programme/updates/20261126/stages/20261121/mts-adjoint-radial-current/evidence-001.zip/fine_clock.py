from clock12 import *
from decimal import getcontext
from curved_clock import ref_endpoint,phase_stride,canonical_reader,member_readings
from local import packet,table,manifest,PREVIOUS
from evolve8 import Wave,Cold


def refine_files():
    return dict(pins(),**{name:core.sha(HERE/name) for name in ("advance_saved.py","fine_clock.py","freeze_mesh.py")})


def calculate(scheme,grid,seed,quarters):
    locked()
    getcontext().prec=46
    pin=scope.check_freeze()
    forecast_path=PREVIOUS/"predicted-gravity.csv"
    forecast={(int(row["seed"]),float(row["width"]),float(row["fraction"])):(float(row["newton"]),float(row["prediction"]))
              for row in core.read(forecast_path) if row["mode"]=="flrw-live"}
    tag=f"halfstep-{grid}-s{seed}"
    assert seed==1 and scheme=="adm" and grid in (320,640) and quarters==4
    checks=json.loads((HERE/"refinement-freeze.json").read_bytes())
    assert checks["sources"]==refine_files()
    for filename,digest in checks["control_digests"].items():assert core.sha(HERE/filename)==digest
    local.manifest(tag+"-numerical-prediction.json",dict(freeze=core.sha(HERE/"refinement-freeze.json")))
    manifest(tag+"-protocol.json",dict(prediction=core.sha(forecast_path),source=pins(),previous=pin,steps=1024,quarter=256,
             grid=grid,seed=seed,scheme=scheme,normalization="absolute signed Newton term",ppm_gate=20,channels=["gauss","ricci"],
             priors_changed=False,launch_correction="analytic-minus-discrete fixed offset scaled by local radial metric",
             note="An evolution test. The mixed numerical chart is experimental; use the original detector."))
    def system(flag,seed,scheme):
        with patch.object(case.parent.evolve_speed,"launch",case.parent.launch):
            return case.parent.evolve_speed.system(1024,grid,flag,seed,scheme,3)[0]
    measurements={}
    with patch.object(case.parent,"system",system),patch.object(lift8,"Radial",Regular):
        for flag in (0,1):
            guard()
            model=Cold(seed,scheme) if flag else Wave(seed,scheme)
            total=4096*np.pi/model.shell.mu
            step=total/1024
            advance=model.time_step(step)
            state=np.zeros_like(model.shell.initial)
            start=model.lift.physical(state,0.)[0]
            assert not np.any(start.base) and not np.any(start.delta)
            for tick in range(1,256*quarters+1):
                if tick%8==1:guard()
                state=advance((tick-1)*step,state)
                if tick%256:continue
                assert np.isfinite(state.base).all() and np.isfinite(state.delta).all()
                clock=tick*step
                std=model.lift.physical(state,clock)[0]
                actual=std if flag else model.to_wave(std)
                if not flag:assert model.min_number>0 and model.min_factor>0
                name=f"{tag}-off{flag}-t{tick}.npz"
                packet(name,shared=state.base,signed=state.delta,physical_shared=actual.base,
                       physical_signed=actual.delta,number=std.delta[12 if flag else 14].real,step=step,tick=tick)
                original=ref_endpoint.fixed_tide
                def precise(shell,start,change):
                    return canonical_reader(shell,start,change,original)
                with patch.object(ref_endpoint,"fixed_tide",precise),patch.object(phase_stride,"fixed_tide",precise):
                    host=member_readings(model.host,clock,actual)
                    zero=member_readings(model.zero,clock,actual.base)
                for key in host:
                    measurements[tick,flag,*key]=host[key]-zero[key]
                print(scheme,grid,flag,tick,flush=True)
    rows=[]
    for tick in range(256,quarters*256+1,256):
        for width in (.15,.30):
            ref,pred=forecast[seed,width,tick/1024]
            for channel in ("gauss","ricci"):
                actual=measurements[tick,0,width,channel]-measurements[tick,1,width,channel]
                ppm=(actual-pred)/(1e-6*abs(ref))
                assert np.isfinite(ppm)
                rows.append(dict(scheme=scheme,grid=grid,seed=seed,tick=tick,width=width,channel=channel,
                                 newton=ref,forecast=pred,measured=actual,residual_ppm=ppm,inside=abs(ppm)<=20))
    table(f"{tag}-q{quarters}.csv",rows)
    print("maximum absolute residual ppm",max(abs(row["residual_ppm"]) for row in rows),flush=True)



if __name__=="__main__":
    with output():calculate("adm",int(sys.argv[1]),1,4)
