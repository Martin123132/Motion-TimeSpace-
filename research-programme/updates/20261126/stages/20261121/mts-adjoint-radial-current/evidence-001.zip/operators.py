from bridge import np,Difference
from native import Mesh


class Radial(Mesh):
    first=(1225/1024,-245/3072,49/5120,-5/7168)
    mean=(1225/2048,-245/2048,49/2048,-5/2048)

    def __init__(self,cells,edge):
        super().__init__(cells,edge)
        self.mass2=self.r**2
        self.mass6=self.r**6

    def _centres_to_faces(self,arr,derivative,odd):
        if isinstance(arr,Difference):
            return Difference(self._centres_to_faces(arr.base,derivative,odd),self._centres_to_faces(arr.delta,derivative,odd))
        sign=-1 if odd else 1
        half=len(self.first)
        extended=np.concatenate((sign*arr[:half][::-1],arr,arr[-half:][::-1]))
        count=arr.size+1
        weights=self.first if derivative else self.mean
        out=np.zeros(count,dtype=arr.dtype)
        for index,weight in enumerate(weights):
            right=extended[half+index:half+index+count]
            left=extended[half-1-index:half-1-index+count]
            out+=weight*(right-left if derivative else right+left)
        return out/self.h if derivative else out

    def _faces_to_centres(self,arr,derivative,even):
        if isinstance(arr,Difference):
            return Difference(self._faces_to_centres(arr.base,derivative,even),self._faces_to_centres(arr.delta,derivative,even))
        half=len(self.first)
        left=arr[half-1:0:-1]
        right=arr[-2:-half-1:-1]
        extended=np.concatenate((left if even else 2*arr[0]-left,arr,right if even else 2*arr[-1]-right))
        count=arr.size-1
        weights=self.first if derivative else self.mean
        out=np.zeros(count,dtype=arr.dtype)
        for index,weight in enumerate(weights):
            right=extended[half+index:half+index+count]
            left=extended[half-1-index:half-1-index+count]
            out+=weight*(right-left if derivative else right+left)
        return out/self.h if derivative else out

    def grad(self,arr):return self._centres_to_faces(arr,True,False)
    def face(self,arr):return self._centres_to_faces(arr,False,False)
    def odd_face(self,arr):return self._centres_to_faces(arr,False,True)
    def back(self,arr):return self._faces_to_centres(arr,True,False)
    def even_back(self,arr):return self._faces_to_centres(arr,True,True)
    def centre(self,arr):return self._faces_to_centres(arr,False,True)
    def odd_centre(self,arr):return self._faces_to_centres(arr,False,False)

    def encode(self,ell,bend,tilt_face,tensor):
        mixed=2*self.faces*self.grad(bend)+2*self.face(bend-ell)+3*tilt_face
        polar=-self.r*self.even_back(tilt_face)/2-1.5*self.centre(tilt_face)+ell+bend+tensor
        return ell,ell+2*bend,mixed[1:],polar

    def decode(self,state):
        ell,trace,stored,polar=state
        bend=(trace-ell)/2
        tilt=(self.full(stored)-2*self.faces*self.grad(bend)-2*self.face(bend-ell))/3
        return ell,bend,tilt,polar+self.r*self.even_back(tilt)/2+1.5*self.centre(tilt)-ell-bend

    def spectrum(self,power,angular):
        count=len(self.r)
        grad=np.stack([self.grad(row) for row in np.eye(count)],axis=1)
        mapped=self.faces[:,None]**(power/2)*grad/self.r[None,:]**(power/2)
        return np.linalg.eigvalsh(mapped.T@mapped+np.diag(angular/self.r**power))
