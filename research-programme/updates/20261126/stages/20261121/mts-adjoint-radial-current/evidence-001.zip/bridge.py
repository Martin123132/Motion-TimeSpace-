import sys
from pathlib import Path
HERE=Path(__file__).resolve().parent
PARENT=HERE.parent/"mts-compatible-ricci-transport-20261121"
sys.path.insert(0,str(PARENT))
import local
from local import np,core,scope,case,Difference,guard,patch,Canonical,Evolution
from contextlib import contextmanager
import json


def locked():
    local.locked()
    assert core.sha(PARENT/"seal.json")=="084c82f0b63cd2a33180022cedb1abf8f479a7aa312dbd41b3eb3c7a7ef5cf7e"
    for name,digest in json.loads((PARENT/"seal.json").read_bytes())["files"].items():
        assert core.sha(PARENT/name)==digest,name
    if (HERE/"STOP-REQUESTED").exists(): raise RuntimeError("owner hold")


@contextmanager
def output():
    with patch.object(local,"HERE",HERE):
        yield
