from bridge import *
import gate,flat_checks
from mts_sbp12 import Regular


def main():
    locked()
    redos=[]
    for cells in (48,96,192):
        mesh=Regular(cells,3.)
        for degree in (2,4,6):
            for power in (2,6):
                actual=mesh.lap(mesh.r**degree,power)
                expected=degree*(power+degree-1)*mesh.r**(degree-2)
                err=abs(actual[:6]-expected[:6])
                assert max(err)<1e-8
                redos.append(dict(cells=cells,degree=degree,power=power,centre_six_abs=max(err)))
    folder=HERE/"regular-checks"
    folder.mkdir(exist_ok=True)
    with patch.object(gate,"Radial",Regular),patch.object(gate,"output",lambda:patch.object(local,"HERE",folder)):
        gate.main()
    with output():local.table("regular-centre.csv",redos)


if __name__=="__main__":
    main()
