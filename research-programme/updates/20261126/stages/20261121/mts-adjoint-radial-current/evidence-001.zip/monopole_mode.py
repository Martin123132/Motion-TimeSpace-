from bridge import *
from scipy.linalg import eig


def run(size):
    locked()
    grid=640
    def system(flag,seed,scheme):
        with patch.object(case.parent.evolve_speed,"launch",case.parent.launch):
            return case.parent.evolve_speed.system(1024,grid,flag,seed,scheme,3)[0]
    with patch.object(case.parent,"system",system):
        model=Evolution(1,1,"adm")
    shell=model.shell
    spacing=shell.dx
    slots=[0,1,4,5]
    def scaled(array):
        chosen=np.stack([array[slot,0,:size].real for slot in slots])
        chosen[2:]*=spacing
        return chosen.ravel()
    def vector(field,amplitude):
        shape=field.reshape(4,size)
        shift=np.zeros_like(shell.initial)
        for idx,slot in enumerate(slots):shift.base[slot,0,:size]=amplitude*shape[idx]*(1 if idx<2 else 1/spacing)
        return spacing*scaled(model.rhs(0.,shift).base)
    def symmetric(direction,amp):
        return (vector(direction,amp)-vector(direction,-amp))/(2*amp)
    matrix=np.stack([symmetric(unit,1e-6) for unit in np.eye(4*size)],axis=1)
    probe=np.cos(np.arange(4*size)*.713)
    err=np.linalg.norm(matrix@probe-symmetric(probe,3e-7))/np.linalg.norm(matrix@probe)
    assert err<1e-7,err
    spectrum,left,right=eig(matrix,left=True,right=True)
    localized=[]
    for idx,val in enumerate(spectrum):
        power=np.sum(abs(right[:,idx].reshape(4,size))**2,axis=0)
        if sum(power[:size//2])/sum(power)>.99 and val.imag>=-1e-12:
            localized.append(idx)
    assert localized
    idx=max(localized,key=lambda pos:spectrum[pos].real)
    lam=spectrum[idx]
    mode=right[:,idx]
    lef=left[:,idx]
    power=np.sum(abs(mode.reshape(4,size))**2,axis=0)
    edge=int(np.searchsorted(np.cumsum(power),.99*sum(power)))+1
    assert np.linalg.norm(matrix@mode-lam*mode)<1e-8
    with output():
        local.packet(f"monopole-{size}.npz",matrix=matrix,eigen=spectrum,mode=mode,left=lef,selected=idx)
    rows=[]
    for seed in (1,-1):
        tag=f"halfstep-640-s{seed}"
        for flag in (0,1):
            previous=None
            for tick in (256,512,768,1024):
                file=HERE/f"{tag}-off{flag}-t{tick}.npz"
                if not file.exists():break
                with np.load(file) as snap:
                    value=np.vdot(lef,scaled(snap["physical_signed"]))
                    dt=float(snap["step"])
                if previous is not None:
                    z=lam*dt/spacing
                    form=1+z+z**2/2+z**3/6+z**4/24
                    gain=form**256
                    ratio=value/previous
                    rows.append(dict(size=size,seed=seed,flag=flag,tick=tick,eigen_real=lam.real,eigen_imag=lam.imag,
                                cells99=edge,linear_error=err,actual_gain=abs(ratio),predicted_gain=abs(gain),
                                magnitude_ratio=abs(ratio/gain),phase_difference=np.angle(ratio/gain)))
                previous=value
    complete=all((HERE/f"halfstep-640-s{seed}-off{flag}-t1024.npz").exists() for seed in (1,-1) for flag in (0,1))
    with output():local.table(f"monopole-{size}-"+("both" if complete else "interim")+".csv",rows)
    print(lam,edge,rows[-1],flush=True)


if __name__=="__main__":
    run(int(sys.argv[1]))
