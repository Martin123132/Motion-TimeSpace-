from clock12 import *
import constraint_floor,ref_endpoint,signed_energy
from decimal import getcontext
from readouts import joined
from endpoints import D,pack,prod,exponential


def material_j(shell,delta):
    initial=shell.initial
    def field(index,imag=False):
        values=initial[index].imag if imag else initial[index].real
        changes=delta[index].imag if imag else delta[index].real
        return convert(values)+convert(changes)
    radius=convert(shell.r)
    def derivative(values):
        size=values.shape[-1]
        extended=np.concatenate((values[...,2::-1],values,values[...,:-4:-1]),axis=-1)
        face=sum(D(weight)*(extended[...,3+j:3+j+size+1]-extended[...,2-j:2-j+size+1]) for j,weight in enumerate(shell.weights))/D(shell.dx)
        extended=np.concatenate((-face[...,2:0:-1],face,-face[...,-2:-4:-1]),axis=-1)
        return sum(D(weight)*(extended[...,3+j:3+j+size]+extended[...,2-j:2-j+size]) for j,weight in enumerate(shell.average))
    ell,bend,tilt,_,trace,shear,cross,tensor=[field(index) for index in range(8)]
    normal=exponential(-ell)
    angular=np.exp(-bend[0])/radius
    bend_gradient=convert(shell.ref_geometry[1][1])+derivative(convert(delta[1].real))
    surface=prod(normal,2*bend_gradient+pack(2/radius,6*tilt[1]/radius))
    volume=exponential(-ell-2*bend)
    radial_j,polar_j=field(18),field(19)[1].copy()
    for spec in range(3 if shell.flag else 2):
        number,potential=field(8+2*spec),field(9+2*spec)
        rest=D(float(shell.rho[spec]))*prod(number,volume)
        radial_j+=prod(rest,prod(normal,derivative(potential)))
        polar_j+=rest[0]*potential[1]*angular
    if not shell.flag:
        amplitude,phase=field(14),field(14,True)
        mu=D(float(shell.mu))
        moment_r=field(15)+trace/(2*mu)
        moment_i=field(15,True)-pack(0*radius+1)
        density=D(float(shell.rho[-1]))*exponential(2*amplitude)
        radial_j-=prod(density,prod(normal,prod(moment_r,derivative(amplitude))+prod(moment_i,derivative(phase))))/mu
        polar_j-=density[0]*(moment_r[0]*amplitude[1]+moment_i[0]*phase[1])*angular/mu
    return radial_j[1],polar_j


def fields(shell,shift):
    initial=shell.initial
    phase=initial[14].imag
    def canonical(field):
        converted=joined(field)
        if not shell.flag and isinstance(field,np.ndarray) and field.shape==phase.shape and field.strides==phase.strides and field.ctypes.data==phase.ctypes.data:
            converted[0]=D(float(shell.mu))*joined(initial[13,0].real)
        return converted
    with ExitStack() as stack:
        for module in (sys.modules[__name__],constraint_floor,ref_endpoint,signed_energy):
            stack.enter_context(patch.object(module,"convert",canonical))
        constraints=constraint_floor.components(shell,shift)
        radial,polar=material_j(shell,shift)
        _,energy=signed_energy.density(shell,shift)
    return np.array([constraints[k][1] for k in ("ham","mom_r","mom_theta")]+[2*energy[1],radial,polar])


convert=joined


def check(grid,seed,steps):
    locked()
    getcontext().prec=50
    tag=f"clock-adm-{grid}-s{seed}" if steps==512 else f"halfstep-{grid}-s{seed}"
    result=[]
    profiles={}
    def system(flag,seed,scheme):
        with patch.object(case.parent.evolve_speed,"launch",case.parent.launch):
            return case.parent.evolve_speed.system(1024,grid,flag,seed,scheme,3)[0]
    with patch.object(case.parent,"system",system):
        for flag in (0,1):
            model=Evolution(1,seed,"adm") if flag else Canonical(seed,"adm")
            for tick in (0,steps//4,steps):
                if tick:
                    with np.load(HERE/f"{tag}-off{flag}-t{tick}.npz") as snap:
                        state=Difference(snap["physical_shared"],snap["physical_signed"])
                else:state=np.zeros_like(model.shell.initial)
                data=fields(model.host,state)-fields(model.zero,state.base)
                profiles[flag,tick]=data
    for label in ("wave","dust","wave-minus-dust"):
        def get(tick):
            if label=="wave":return profiles[0,tick]
            if label=="dust":return profiles[1,tick]
            return profiles[0,tick]-profiles[1,tick]
        initial=get(0)
        for tick in (0,steps//4,steps):
            actual=get(tick)
            for region,selected in (("centre",model.shell.r<.30),("interior",(model.shell.r>.6)&(model.shell.r<2.1))):
                for idx,key in enumerate(("ham","mom_r","mom_theta")):
                    rms=lambda array:np.linalg.norm(array[selected].astype(float))/np.sqrt(sum(selected))
                    absolute=rms(actual[idx])
                    change=rms(actual[idx]-initial[idx])
                    source=rms(actual[idx+3])
                    source_change=rms(actual[idx+3]-initial[idx+3])
                    result.append(dict(grid=grid,seed=seed,steps=steps,tick=tick,branch=label,region=region,
                          constraint=key,signed_absolute=absolute,absolute_source=source,
                          signed_drift=change,source_change=source_change,drift_over_change=change/source_change if source_change else ""))
    with output():local.table(tag+"-constraints.csv",result)
    print("independent constraints",grid,steps,len(result),flush=True)


if __name__=="__main__":
    check(*map(int,sys.argv[1:]))
