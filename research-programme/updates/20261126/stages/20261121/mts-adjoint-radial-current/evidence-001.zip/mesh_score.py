from fine_clock import *


def score():
    freeze=json.loads((HERE/"refinement-freeze.json").read_bytes())
    assert freeze["sources"]==refine_files()
    for name,digest in freeze["control_digests"].items():assert core.sha(HERE/name)==digest
    fast=core.read(HERE/"clock-adm-320-s1-q4.csv")
    slow=core.read(HERE/"halfstep-320-s1-q4.csv")
    fine=core.read(HERE/"halfstep-640-s1-q4.csv")
    rows=[]
    for guess in freeze["predictions"]:
        tick,width,channel=guess["tick"],guess["width"],guess["channel"]
        def one(data,time):
            row,=[row for row in data if int(row["tick"])==time and row["width"]==width and row["channel"]==channel]
            return float(row["residual_ppm"])
        original=one(fast,tick)
        control=one(slow,tick*2)
        actual=one(fine,tick*2)
        time_shift=control-original
        corrected=guess["forecast640"]+time_shift
        rows.append(dict(fraction=tick/512,width=width,channel=channel,old320=original,control320=control,
                         clock_shift=time_shift,forecast640=guess["forecast640"],measured640=actual,
                         detector_pass=abs(actual)<=20,mesh_forecast_error=actual-corrected,
                         prospective_precision_ppm=guess["precision_ppm"],mesh_forecast_pass=abs(actual-corrected)<=guess["precision_ppm"]))
    with output():local.table("independent-mesh-forecast.csv",rows)
    return rows


if __name__=="__main__":
    rows=score()
    print("detector",sum(row["detector_pass"] for row in rows),len(rows),"spatial forecast",sum(row["mesh_forecast_pass"] for row in rows),
          "max",max(abs(row["measured640"]) for row in rows),flush=True)
