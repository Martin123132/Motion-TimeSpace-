from clock12 import *
from decimal import getcontext
from curved_clock import phase_stride,ref_endpoint,member_readings,canonical_reader


def run(grid):
    locked()
    getcontext().prec=46
    tag=f"clock-adm-{grid}-s1"
    protocol=json.loads((HERE/(tag+"-protocol.json")).read_bytes())
    assert protocol["source"]==pins()
    quarter=core.read(HERE/(tag+"-q1.csv"))
    names=[f"{tag}-off{flag}-t128.npz" for flag in (0,1)]
    with output():
        local.manifest(f"{tag}-continuation.json",dict(initial={name:core.sha(HERE/name) for name in names},
                       protocol=core.sha(HERE/(tag+"-protocol.json")),program=core.sha(Path(__file__))))
    readings={}
    def system(flag,seed,scheme):
        with patch.object(case.parent.evolve_speed,"launch",case.parent.launch):
            return case.parent.evolve_speed.system(1024,grid,flag,seed,scheme,3)[0]
    with ExitStack() as stack:
        setup(stack)
        stack.enter_context(patch.object(case.parent,"system",system))
        for flag in (0,1):
            model=evolve8.Cold(1,"adm") if flag else evolve8.Wave(1,"adm")
            with np.load(HERE/names[flag]) as snap:
                assert int(snap["tick"])==128
                state=Difference(snap["shared"],snap["signed"])
                step=float(snap["step"])
            assert step==4096*np.pi/model.shell.mu/512
            advance=model.time_step(step)
            for tick in range(129,513):
                if tick%8==1:local.guard()
                state=advance((tick-1)*step,state)
                if tick%128:continue
                clock=tick*step
                std=model.lift.physical(state,clock)[0]
                actual=std if flag else model.to_wave(std)
                assert all(np.isfinite(arr).all() for arr in (state.base,state.delta,actual.base,actual.delta))
                if not flag:assert min(model.min_number,model.min_factor)>0
                local.packet(f"{tag}-off{flag}-t{tick}.npz",shared=state.base,signed=state.delta,
                             physical_shared=actual.base,physical_signed=actual.delta,
                             number=std.delta[12 if flag else 14].real,step=step,tick=tick)
                orig=ref_endpoint.fixed_tide
                def precise(shell,start,change): return canonical_reader(shell,start,change,orig)
                with patch.object(ref_endpoint,"fixed_tide",precise),patch.object(phase_stride,"fixed_tide",precise):
                    signed=member_readings(model.host,clock,actual)
                    zero=member_readings(model.zero,clock,actual.base)
                for key in signed:readings[tick,flag,*key]=signed[key]-zero[key]
                print(grid,flag,tick,flush=True)
    forecast=core.read(local.PREVIOUS/"predicted-gravity.csv")
    for tick in (256,384,512):
        for width in (.15,.30):
            ref,=[row for row in forecast if row["mode"]=="flrw-live" and row["seed"]=="1" and
                  float(row["width"])==width and float(row["fraction"])==tick/512]
            for chan in ("gauss","ricci"):
                measured=readings[tick,0,width,chan]-readings[tick,1,width,chan]
                error=(measured-float(ref["prediction"]))/(abs(float(ref["newton"]))*1e-6)
                quarter.append(dict(scheme="adm",grid=grid,seed=1,tick=tick,width=width,channel=chan,
                    newton=ref["newton"],forecast=ref["prediction"],measured=measured,residual_ppm=error,inside=abs(error)<=20))
    with output():local.table(tag+"-q4.csv",quarter)


if __name__=="__main__":
    run(int(sys.argv[1]))
