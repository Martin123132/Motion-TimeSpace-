from bridge import *
from mts_sbp12 import Regular
from scipy.optimize import brentq
from math import sqrt
import sympy as sy


def curved():
    B,U,v,k,dU,dv,E,p,tan,j=sy.symbols("B U v k dU dv E p tan j")
    K=-k-2*v/B
    mass=B*(1+v**2-U**2)/2
    Enn=(1+v**2-U**2)/B**2+2*(k*v-dU)/B
    Jn=2*(dv-k*U)/B
    C=Enn-E
    Pr=p+C
    geom_nn=-2*dU/B
    geom_t=(1-U**2-B*dU)/B**2
    S=p+2*tan
    kdot=-geom_nn+K*k+p+(E-S)/2
    vdot=-B*geom_t+K*v+B*(tan+(E-S)/2)+v**2/B
    udot=dv-k*U
    drmass=sy.diff(mass,B)*U+sy.diff(mass,U)*dU+sy.diff(mass,v)*dv
    dtmass=sy.diff(mass,B)*v+sy.diff(mass,U)*udot+sy.diff(mass,v)*vdot
    residuals={
        "mass-gradient":drmass-B**2*(U*(E+C)+v*Jn)/2,
        "mass-work":dtmass+B**2*(v*Pr+U*Jn)/2,
        "areal-acceleration":vdot+mass/B**2+B*Pr/2,
        "radial-expansion-rate":kdot-(2*mass/B**3-k**2+p-(E+S)/2-C),
        "normal-momentum":udot-B*Jn/2,
    }
    recovered=(2*drmass/B**2-v*Jn)/U
    arate=(dv-B*Jn/2)/U
    from_mass=(v*vdot-dtmass/B+mass*v/B**2)/U
    residuals.update({"energy-without-projection":recovered-Enn,
                      "radial-expansion-without-projection":arate-k,
                      "inverse-chart-normal-rate":from_mass-udot})
    for name,value in residuals.items():assert sy.simplify(value)==0,name
    radius,charge=sy.symbols("r mass_density",positive=True)
    inside=4*sy.pi*charge*radius**3/3
    newton=-inside/radius**2
    assert sy.diff(inside,radius)==4*sy.pi*charge*radius**2 and sy.simplify(newton+4*sy.pi*charge*radius/3)==0
    return list(residuals)


def flat():
    rng=np.random.default_rng(191121)
    rows=[]
    for cells in (48,96,192):
        mesh=Regular(cells,3.)
        rc,rf=mesh.r,mesh.faces
        def rhs(mass):return rf**2*mesh.grad(mesh.back(mass)/rc**2)
        def energy(mass,rate):
            return mesh.h*(np.sum((rate[1:-1]/rf[1:-1])**2)+np.sum((mesh.back(mass)/rc)**2))/2
        def norm(arr):return np.linalg.norm(arr)
        errors=[]
        for power in (3,5,7,9):
            theory=power*(power-3)*rf**(power-2)
            errors.append(max(abs(rhs(rf**power)[1:7]-theory[1:7])))
        mass=np.r_[0.,rng.normal(size=cells-1),0.]
        velocity=np.r_[0.,rng.normal(size=cells-1),0.]
        current=np.r_[0.,rng.normal(size=cells-1),0.]
        divstress=np.r_[0.,rng.normal(size=cells-1),0.]
        stored=rng.normal(size=cells)
        ext_e=rng.normal(size=cells)
        ext_j=np.r_[0.,rng.normal(size=cells-1),0.]
        edot=-mesh.back(rf**2*current)/rc**2+ext_e
        jdot=-divstress+ext_j
        accel=rhs(mass)+rf**2*(divstress-mesh.grad(stored))/2
        H=2*mesh.back(mass)/rc**2-stored
        Hdot=2*mesh.back(velocity)/rc**2-edot
        M=np.zeros_like(current)
        M[1:-1]=-2*velocity[1:-1]/rf[1:-1]**2-current[1:-1]
        Mdot=-2*accel[1:-1]/rf[1:-1]**2-jdot[1:-1]
        errH=norm(Hdot+mesh.back(rf**2*M)/rc**2+ext_e)/norm(Hdot)
        errM=norm(Mdot+mesh.grad(H)[1:-1]+ext_j[1:-1])/norm(Mdot)
        grad=np.stack([mesh.grad(unit)[1:-1] for unit in np.eye(cells)],axis=1)
        mapped=rf[1:-1,None]*grad/rc[None,:]
        eigen=np.linalg.eigvalsh(mapped@mapped.T)
        assert eigen[0]>0
        k=brentq(lambda z:np.sin(z*3)-z*3*np.cos(z*3),1.45,1.55)
        original=(np.sin(k*rf)-k*rf*np.cos(k*rf))/(2*k**3)
        original[[0,-1]]=0.
        disp=original.copy();speed=0.*disp
        initial=energy(disp,speed)
        duration=1.9/k
        ticks=int(np.ceil(duration/(.10*mesh.h)))
        step=duration/ticks
        for tick in range(ticks):
            speed+=.5*step*rhs(disp);disp+=step*speed;speed+=.5*step*rhs(disp)
        ans=norm(((disp-original*np.cos(k*duration))[1:-1])/rf[1:-1])/norm(original[1:-1]/rf[1:-1])
        rows.append(dict(cells=cells,origin=max(errors),continuity_with_work=errH,momentum_with_work=errM,
                     min_frequency2=eigen[0],max_frequency_h=sqrt(eigen[-1])*mesh.h,
                     independent_mode_speed_error=abs(sqrt(eigen[0])/k-1),timed_profile_error=ans,
                     timed_energy_error=abs(energy(disp,speed)/initial-1)))
        assert max(errors)<1e-8 and max(errH,errM)<1e-12
    assert all(later["timed_profile_error"]<earlier["timed_profile_error"]/3 for earlier,later in zip(rows,rows[1:]))
    return rows


if __name__=="__main__":
    locked()
    ids=curved()
    rows=flat()
    with output():
        local.manifest("spherical-identities.json",dict(exact=ids[:5],scope="spherical off-constraint slice with unspecified material energy and stress"))
        local.manifest("spherical-inverse.json",dict(exact=ids[5:],domain="B positive, U nonzero, retained outward branch U>0"))
        local.table("spherical-mass-waves.csv",rows)
    print(rows[-1],flush=True)
