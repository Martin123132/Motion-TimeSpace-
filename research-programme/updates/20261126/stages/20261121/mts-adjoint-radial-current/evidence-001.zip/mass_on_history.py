from clock12 import *
from native import background
from trial import sources
from number_chart import pair


def trial_state(model,encoded,time):
    shell=model.shell
    stored,geo,bg,rates=model.lift.physical(encoded,time)
    actual=stored if shell.flag else model.to_wave(stored)
    state=shell.initial+actual
    rate=model.rhs(time,encoded) if shell.flag else model.nonlinear(time,encoded)
    trace=state[4,0].real;shear=state[5,0].real
    ka=-trace/3-shear;kb=-trace/3+shear/2
    B=shell.r*np.exp(bg["bend"])
    alpha=bg["scale"]
    rb=shell.r*bg["bg"]
    U=alpha*(1+rb)
    v=B*kb
    w=(v**2-np.expm1(2*(bg["bend"]-bg["ell"]))-alpha**2*rb*(2+rb))/2
    mass=B*w
    energy,press,sr,sc,st=sources(model,time,actual)
    Enn=bg["R"]/2+2*ka*kb+kb**2
    error=Enn-energy[0]
    pr=press[0]/3+sr[0]
    measured=B*(-rate[4,0].real/3+rate[5,0].real/2+kb**2)
    physical=-w/B-B*pr/2
    predicted=physical-B*error/2
    J=2*(1.5*shear*U/B+np.exp(-bg["ell"])*shell.diff(kb))
    Udot=U*(kb-ka)+alpha*shell.r*shell.diff(kb)
    measured_work=v*w+B*(v*measured-U*Udot)
    required_work=-B**2*(v*(pr+error)+U*J)/2
    field_prediction_error=measured-predicted
    return U,{"acceleration":(measured,predicted,field_prediction_error,physical),
              "mass-work":(measured_work,required_work,measured_work-required_work,-B**2*(v*pr+U*J)/2)}


def main(grid,seed,steps):
    locked()
    tag=f"clock-adm-{grid}-s{seed}" if steps==512 else f"halfstep-{grid}-s{seed}"
    rows=[]
    def system(flag,seed,scheme):
        with patch.object(case.parent.evolve_speed,"launch",case.parent.launch):
            return case.parent.evolve_speed.system(1024,grid,flag,seed,scheme,3)[0]
    with ExitStack() as stack:
        setup(stack)
        stack.enter_context(patch.object(case.parent,"system",system))
        for flag in (0,1):
            model=evolve8.Cold(seed,"adm") if flag else evolve8.Wave(seed,"adm")
            radius=model.shell.r
            for tick in (0,steps//4,steps):
                if tick:
                    with np.load(HERE/f"{tag}-off{flag}-t{tick}.npz") as bank:
                        state=Difference(bank["shared"],bank["signed"]);time=tick*float(bank["step"])
                else:state=np.zeros_like(model.shell.initial);time=0.
                U,results=trial_state(model,state,time)
                Umin=min(min(U.base),min(U.base+U.delta))
                assert Umin>0
                for obs,(actual,expected,diff,physical) in results.items():
                    for name,mask in (("core",radius<.3),("bulk",(radius>.6)&(radius<2.1))):
                        for member in ("base","delta"):
                            norm=lambda arr:np.linalg.norm(getattr(arr,member)[mask])/np.sqrt(sum(mask))
                            scale=max(norm(actual),norm(expected))
                            rows.append(dict(grid=grid,seed=seed,steps=steps,flag=flag,tick=tick,observable=obs,region=name,
                                          member=member,min_U=Umin,rate=norm(actual),off_constraint_mismatch=norm(diff),
                                          residual_over_rate=norm(diff)/scale if scale else "",
                                          omitted_energy_constraint=norm(expected-physical)))
        local.table(tag+"-mass-identity-on-slices.csv",rows)


if __name__=="__main__":
    main(*map(int,sys.argv[1:]))
