from fractions import Fraction
from math import prod
from operators import Radial


def interpolation(half):
    radii=[Fraction(2*index+1,2) for index in range(half)]
    origin=[prod(other**2/(other**2-radius**2) for other in radii if other!=radius) for radius in radii]
    first=tuple(float(value/(2*radius)) for value,radius in zip(origin,radii,strict=True))
    mean=tuple(float(value/2) for value in origin)
    return first,mean


class Regular(Radial):
    first,mean=interpolation(6)
