from clock12 import *
from readouts import rms


def check():
    locked()
    outputs=[]
    for grid,seed,steps in ((160,1,512),(320,1,512),(320,-1,512),(320,1,1024),(640,1,1024),(640,-1,1024)):
        tag=f"clock-adm-{grid}-s{seed}" if steps==512 else f"halfstep-{grid}-s{seed}"
        with patch.object(case.parent.evolve_speed,"launch",case.parent.launch):
            host=case.parent.evolve_speed.system(1024,grid,1,seed,"adm",3)[0]
        master=(np.arange(480)+.5)/160
        use=(master>.6)&(master<2.1)
        edges=np.arange(3*grid+1)/grid
        mass=np.diff(edges**3)/3
        ratio=grid//160
        grouped=mass.reshape(-1,ratio)
        coarse=grouped.sum(axis=1)
        with np.load(local.PREVIOUS/f"frozen-current-adm-s{seed}.npz") as prediction:
            for idx,tick in enumerate(range(steps//4,steps+1,steps//4)):
                with np.load(HERE/f"{tag}-off0-t{tick}.npz") as wave,np.load(HERE/f"{tag}-off1-t{tick}.npz") as dust:
                    observed=host.rho[-1]*(wave["number"][0]-dust["number"][0])
                bins=(observed*mass).reshape(-1,ratio).sum(axis=1)/coarse
                coarse_norm=rms(bins[use]);fine=observed.reshape(-1,ratio)[use]
                header=f"window{idx}_charge_"
                proj=prediction[header+"changing"]+(prediction[header+"canonical_launch"]-prediction[header+"launch"])
                diff=bins[use]-proj
                shell=np.cumsum(bins[use]*coarse[use]);forecast=np.cumsum(proj*coarse[use])
                assert abs(np.sum(bins*coarse)-sum(observed*mass))<1e-11*sum(abs(observed*mass))
                outputs.append(dict(grid=grid,seed=seed,tick=tick,steps=steps,
                    cell_average_discrepancy=rms(diff)/coarse_norm,
                    within_bin_variation=rms(fine-bins[use,None])/coarse_norm,
                    partial_enclosed_rms=rms(shell-forecast)/rms(shell),
                    partial_enclosed_outer_relative=(shell[-1]-forecast[-1])/shell[-1]))
    with output():local.table("retained-finite-shell-number.csv",outputs)


if __name__=="__main__":
    check()
