from clock12 import *
from scipy.interpolate import CubicSpline
from readouts import rms


def run():
    locked()
    results=[]
    for grid,seed,steps in ((160,1,512),(320,1,512),(320,-1,512),(320,1,1024),(640,1,1024)):
        tag=f"clock-adm-{grid}-s{seed}" if steps==512 else f"halfstep-{grid}-s{seed}"
        def system(flag,seed,scheme):
            with patch.object(case.parent.evolve_speed,"launch",case.parent.launch):
                return case.parent.evolve_speed.system(1024,grid,flag,seed,scheme,3)[0]
        host=system(1,seed,"adm")
        master=(np.arange(480)+.5)/160
        target=master[(master>.6)&(master<2.1)]
        with np.load(local.PREVIOUS/f"frozen-current-adm-s{seed}.npz") as bank:
            for idx,tick in enumerate(range(steps//4,steps+1,steps//4)):
                header=f"window{idx}_charge_"
                profiles=[]
                for flag in (0,1):
                    with np.load(HERE/f"{tag}-off{flag}-t{tick}.npz") as raw:
                        profiles.append(raw["number"][0])
                native=host.rho[-1]*(profiles[0]-profiles[1])
                linear=np.interp(target,host.r,native)
                cubic=CubicSpline(host.r,native)(target)
                expected=bank[header+"changing"]+(bank[header+"canonical_launch"]-bank[header+"launch"])
                assert expected.shape==linear.shape
                results.append(dict(grid=grid,seed=seed,steps=steps,tick=tick,prediction_key=header,
                            relative=rms(cubic-expected)/rms(cubic),linear_relative=rms(linear-expected)/rms(linear),
                            interpolation_spread=rms(cubic-linear)/rms(cubic)))
    with output():local.table("retained-number-prediction.csv",results)


if __name__=="__main__":
    run()
