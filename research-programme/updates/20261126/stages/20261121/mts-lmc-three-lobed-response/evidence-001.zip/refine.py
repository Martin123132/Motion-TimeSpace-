from sector import *
from quad_io import read
from scipy.special import roots_legendre

def midpoints(model):
    safe()
    path = HERE/f'interior-{model}.npz'
    with np.load(HERE/f'tide-{model}.npz') as saved:
        times,grid = saved['times'],saved['radius']
    stamp,knots,shapes,traj = history(model)
    ticks = (times[1:]+times[:-1])/2
    if path.exists():
        with np.load(path) as saved:
            assert np.array_equal(ticks,saved['times']) and np.array_equal(grid,saved['radius'])
        return
    locations = positions(traj,ticks)
    rule = roots_legendre(32)
    values = np.empty((len(ticks),len(grid),19),complex)
    for idx,location in enumerate(locations):
        if idx%128==0:
            safe()
        first = idx//16
        mix = (ticks[idx]-stamp[first])/(stamp[first+1]-stamp[first])
        assert 0<mix<1
        values[idx] = shell(location,knots,(1-mix)*shapes[first]+mix*shapes[first+1],grid,3,39,rule)
    packet(path.name,times=ticks,radius=grid,source=values)
    print('physical midpoints',model,len(ticks),flush=True)

def fine(case):
    safe()
    full = sector(case,3)
    rows = []
    geometry = ((6.,'radial'),(6.,'polar'),(8.3,'radial'),(8.3,'polar'))
    for keep in (96,128):
        op = reduced(full,keep)
        mapping = None
        for model in MODELS:
            safe()
            with np.load(HERE/f'tide-{model}.npz') as old:
                grid,times = old['radius'],old['times']
                if mapping is None:
                    mapping = drive_map(full,op,grid,39)
                drives = old['source'].reshape(len(times),-1)@mapping
            with np.load(HERE/f'interior-{model}.npz') as plus:
                assert np.array_equal(plus['times'],(times[1:]+times[:-1])/2)
                half = plus['source'].reshape(len(times)-1,-1)@mapping
            both = np.empty((2*len(times)-1,len(op.freq)),complex)
            both[::2],both[1::2] = drives,half
            tau = np.linspace(times[0],times[-1],len(both))*full.bg.vel/full.bg.length
            present,disp,rate = propagate(both,tau,op.freq,op.sky,3)
            at16,_,_ = propagate(drives,tau[::2],op.freq,op.sky,3)
            packet(f'fine-{case}-{keep}-{model}.npz',frequency=op.freq,position=disp,velocity=rate,
                meridian_complex=present,original_time_grid=at16)
            with np.load(HERE/f'state-{case}-{model}.npz') as original:
                old64=original['meridian_complex']
            if keep==128:
                with np.load(HERE/f'fine-{case}-96-{model}.npz') as other:
                    prev32,prev16=other['meridian_complex'],other['original_time_grid']
            for name,coarse,finer in [('time_16_to_32',at16,present),('modal_64_to_current_t16',old64,at16)]+(
                [('modal_96_to_128_t16',prev16,at16),('modal_96_to_128_t32',prev32,present)] if keep==128 else []):
                for idx,(radius,label) in enumerate(geometry):
                    rows.append(dict(model=model,R=radius,component=label,keep=keep,comparison=name,
                        fine_meridian=finer[idx].real,relative_meridian=abs(coarse[idx].real/finer[idx].real-1),
                        absolute_meridian=abs(coarse[idx].real-finer[idx].real),relative_complex=abs(coarse[idx]/finer[idx]-1)))
            print('refined',case,keep,model,flush=True)
    table(f'high-resolution-{case}.csv',rows)

if __name__=='__main__':
    if sys.argv[1:]==['midpoints']:
        for name in MODELS:
            midpoints(name)
    else:
        for case in (0,1):
            fine(case)
