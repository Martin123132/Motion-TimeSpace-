from sources import HERE, PARENT, QUAD, AX, LMC, MODELS, TAGS, PIN, TOL, digest, safe, emit
import csv
import json
import itertools
import sys
import numpy as np

def read(path):
    with path.open(newline='',encoding='utf8') as stream:
        return list(csv.DictReader(stream))

def window(records,key):
    values = [float(row[key]) for row in records]
    assert values and np.isfinite(values).all()
    return [min(values),max(values)]

def audit():
    safe()
    allfiles = {}
    sha = PIN
    for folder,link in ((QUAD,'parent'),(AX,'parent_seal'),(LMC,'parent'),
                         (PARENT/'mts-finite-bar-mean-response-20261119','parent'),
                         (PARENT/'mts-rotating-bar-wave-drive-20261119','parent')):
        assert digest(folder/'seal.json')==sha
        manifest = json.loads((folder/'seal.json').read_bytes())
        allfiles[folder]=manifest['files']
        sha = manifest[link]
    selected = {QUAD:['combined-force-ledger.csv','quad_io.py','quad_evolve.py','incident.py','source_quadrupole.dll'],
        AX:['axis_response.py','axis_operator.py','axis_dual.py','axis_io.py','shell_projection.cpp'],
        LMC:['lmc_field.py','lmc_io.py','sky.py',*(name for name in allfiles[LMC] if name.startswith('source/') and
            (name.endswith('potential.ini') or name.endswith('trajlmc.txt') or '/pot/lmc' in name))]}
    pulse,bar = list(allfiles)[-2:]
    selected[pulse]=['pulse_io.py','pulse_space.py','finite_bar_pulse.py',*(tag+'-state.npz' for tag in TAGS)]
    selected[bar]=['bar_field.py','extra-reference-mean.npz','extra-added-free2-plus-mean.npz']
    for case in (0,1):
        selected[QUAD]+= [f'operators/{case}-64.npz',f'joint-response-grams-{case}.npz',f'joint-even-source-budget-{case}.csv',
            f'complete-angular-test-{case}.csv',f'states/{case}-64-L2M10-r192-l24-t16-d1.npz']
    selected[QUAD].append('sources/L2M10-r192-l24-q28-t16.npz')
    for folder,paths in selected.items():
        for name in paths:
            assert digest(folder/name)==allfiles[folder][name],name
    parent=read(QUAD/'combined-force-ledger.csv')
    all_bands,all_modes,all_budgets,precision,wide,gradient,source,challenges=[],[],[],[],[],[],[],[]
    fine_rows,polys=[],[]
    for case in (0,1):
        def report(prefix):
            return read(HERE/f'{prefix}-{case}.csv')
        bands=report('bands')
        challenges_case=report('complete-bands')
        wide_case=report('outer-domain')
        expected_keys=set(itertools.product(MODELS,(6.,8.3),(-1.5,1.5),('radial','polar'),('mts','nfw')))
        def key(row):
            return (row['model'],float(row['R']),float(row['z']),row['component'],row['background'])
        assert len(bands)==len(challenges_case)==96 and set(map(key,bands))==set(map(key,challenges_case))==expected_keys
        assert len(wide_case)==24
        for row in bands:
            model,radius,height,label,bg=key(row)
            old=next(item for item in parent if item['tag']==TAGS[case] and item['orbit']==model and
                (float(item['R']),float(item['z']),item['component'],item['background'])==(radius,height,label,bg))
            assert (old['low'],old['high'])==(row['low'],row['high']) or tuple(map(float,(old['low'],old['high'])))==tuple(map(float,(row['low'],row['high'])))
            low,high,before,inc,total=map(float,(row['low'],row['high'],row['before'],row['induced_m3'],row['total']))
            assert low<high and before==float(old['total']) and total==before+inc and (low<=total<=high)==(row['inside']=='True')
            sign=-1 if label=='polar' and height<0 else 1
            idx=(2 if radius>6 else 0)+(label=='polar')
            with np.load(HERE/f'fine-{case}-128-{model}.npz') as highres:
                fitted=highres['meridian_complex'][idx].real
            domain=next(item for item in wide_case if (item['model'],float(item['R']),item['component'])==(model,radius,label))
            wide_total=before+(float(domain['wide_meridian'])*sign if bg=='mts' else 0.)
            finer=before+(fitted*sign if bg=='mts' else 0.)
            if bg=='nfw':
                assert inc==0 and finer==wide_total==before
            challenge=next(item for item in challenges_case if key(item)==key(row))
            row.update(case=case,at_fine=finer,fine_decision_agrees=(low<=finer<=high)==(low<=total<=high),
                box_agrees=(low<=wide_total<=high)==(low<=total<=high),challenge_agrees=(challenge['inside']==row['inside']),
                before_inside=(low<=before<=high),gap_fraction=(abs(inc)/min(abs(before-low),abs(before-high))))
        all_bands.extend(bands)
        for target,file in ((all_modes,'modes'),(all_budgets,'complete-budget'),(precision,'refinements'),
            (wide,'outer-domain'),(gradient,'gradient'),(source,'complete-source'),(fine_rows,'high-resolution'),(polys,'polynomial')):
            target.extend(report(file))
        for row in report('complete-budget'):
            minimum,upper,ratio=map(float,(row['free_initial_energy_lower'],row['driven_energy_upper'],row['free_energy_over_driven_ceiling']))
            assert minimum>=0 and upper>0 and abs(minimum/upper-ratio)<2e-12
    assert len(all_budgets)==48 and len(fine_rows)==288 and len(source)==48
    checks={label:window([row for row in fine_rows if int(row['keep'])==128 and row['comparison']==label],'relative_meridian')
            for label in ('time_16_to_32','modal_96_to_128_t32')}
    size={key:window([r for r in all_modes if float(r['R'])==6 and r['component']==key],'meridian') for key in ('radial','polar')}
    counts={}
    for test in ('mts','nfw'):
        counts[test]=[sum(r['inside']=='True' for r in all_bands if (r['case'],r['model'],r['background'])==(case,orbit,test))
            for case in (0,1) for orbit in MODELS]
    inner=[r for r in all_bands if r['background']=='mts' and float(r['R'])==6]
    output=dict(parent_files_checked=sum(map(len,selected.values())),compared=len(all_bands),band_pass_counts=counts,
        changes_primary=sum(r['before_inside']!=(r['inside']=='True') for r in all_bands),
        changes_fine=sum(not r['fine_decision_agrees'] for r in all_bands),changes_box=sum(not r['box_agrees'] for r in all_bands),
        changes_complete=sum(not r['challenge_agrees'] for r in all_bands),northern_inner_increment=size,
        inner_radial_fraction_of_prior_gap=window([r for r in inner if r['component']=='radial'],'gap_fraction'),
        inner_polar_fraction_of_prior_gap=window([r for r in inner if r['component']=='polar'],'gap_fraction'),
        complex_source_control=window(read(HERE/'cartesian.csv'),'relative_shell'),analytic_field=window(polys,'manufactured_relative'),
        independent_density_gradient=window(gradient,'relative'),full_source_tail=window(source,'angular_tail_relative'),
        complete_source_refinement=window(source,'combined_change_relative'),box_change=window(wide,'relative_meridian'),
        primary_refinements={name:window([r for r in precision if r['changed']==name],'relative_meridian') for name in ('modal','time_source','radial_source','angular_source')},
        final_precision=checks,misses_at_final_precision={name:sum(int(r['keep'])==128 and r['comparison']==name and float(r['relative_meridian'])>TOL for r in fine_rows) for name in checks},
        box_misses=sum(float(r['relative_meridian'])>TOL for r in wide),shell_time8_combined_misses=sum(float(r['combined_change_relative'])>TOL for r in source))
    for relax in (False,True):
        close=[r for r in all_budgets if r['free_odd']==str(relax) and int(r['substeps'])==8]
        assert len(close)==12
        output['joint_'+str(relax)]=window(close,'required_over_joint_ceiling')
        output['incoming_'+str(relax)]=window(close,'free_energy_over_driven_ceiling')
        output['coarse_joint_'+str(relax)]=window([r for r in all_budgets if r['free_odd']==str(relax) and int(r['substeps'])==4],'required_over_joint_ceiling')
    ring=read(HERE/'ring-control.csv')
    assert len(ring)==48 and len({(r['case'],r['model'],r['R'],r['component']) for r in ring})==48
    output['ring_amplitudes']={label:window([r for r in ring if r['component']==label],'wave_amplitude') for label in ('radial','polar')}
    output['ring_control']={key:window(ring,key) for key in ('direct_to_wave','native_vs_archive_sat_over_wave','ring128_vs256_over_wave',
        'ring16_vs256_over_wave','live_multipole_to_wave','live_basis_to_wave','live_basis_difference_over_wave',
        'live_multipole_in_wave_phase','live_basis_in_wave_phase')}
    rotation=read(HERE/'rotation-and-high-degree.csv')
    assert len(rotation)==8 and max(float(r['direct_through_degree_71']) for r in rotation)<TOL
    output['degree71_cartesian']=window(rotation,'direct_through_degree_71')
    output['rotation_relative']=window(rotation,'complex_rotation')
    contrasts=read(HERE/'vacuum-null-test.csv')
    assert len(contrasts)==24
    control=read(HERE/'vacuum-analytic-controls.csv')
    assert len(control)==4 and all(float(r[key])<(1e-14) for r in control[:3] for key in ('vertical_relative','radial_relative'))
    assert all(float(control[-1][key])>1e-3 for key in ('vertical_relative','radial_relative'))
    for name in ('Z','K'):
        group=[r for r in contrasts if r['contrast']==name]
        assert len({(r['model'],r['case']) for r in group})==len(group)==12
        output['contrast_'+name]={key:window(group,key) for key in ('wave_amplitude','direct_to_wave','implementation_spread_over_wave',
            'live_multipole_to_wave','live_basis_to_wave','per_quadrature_3sigma','modal_relative','time_relative','wide_meridian_shift_over_complex_amplitude')}
    return output

if __name__=='__main__':
    summary=audit()
    data=(json.dumps(summary,sort_keys=True,indent=2)+'\n').encode()
    if sys.argv[1:]==['--save']:
        emit('validation.json',data)
        assert (HERE/'RESULTS.md').is_file()
        names=sorted(path.name for path in HERE.iterdir() if path.is_file() and path.suffix in {'.md','.py','.cpp','.dll','.cmd','.npz','.csv','.json'} and path.name!='seal.json')
        emit('seal.json',(json.dumps({name:digest(HERE/name) for name in names},sort_keys=True,indent=2)+'\n').encode())
    elif sys.argv[1:]==['--report']:
        print(data.decode())
    else:
        assert not sys.argv[1:] and (HERE/'validation.json').read_bytes()==data
        receipt=json.loads((HERE/'seal.json').read_bytes())
        assert all(digest(HERE/name)==sha for name,sha in receipt.items())
        print('Verified',len(receipt),'files, seal',digest(HERE/'seal.json'),flush=True)
