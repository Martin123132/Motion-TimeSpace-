from pathlib import Path
import csv
import ctypes
import hashlib
import io
import os
import sys

HERE = Path(__file__).resolve().parent
PARENT = HERE.parent
QUAD = PARENT / 'mts-lmc-live-quadrupole-20261119'
sys.path.insert(0, str(QUAD))
from quad_io import AX, LMC, MODELS, TAGS, digest, guard
from incident import PTR, project, potential, history, positions
import numpy as np
from scipy.special import roots_legendre
from pulse_space import basis

TOL = 2e-5
PIN = '14328952cd5b8ed0c9b8d000f9d26f13e86a1fbaae2951c586eccdd010420df2'
library = ctypes.CDLL(str(HERE / 'tesseral.dll'))
integer = ctypes.c_int
library.tesseral.argtypes = [PTR,PTR,PTR,PTR,integer,PTR,PTR,integer,integer,integer,PTR]

def safe():
    guard()
    assert not (HERE / 'STOP-REQUESTED').exists() and not (QUAD / 'STOP-REQUESTED').exists()
    assert digest(QUAD / 'seal.json') == PIN

def emit(name, data):
    safe()
    path = HERE / name
    if path.exists():
        assert digest(path) == hashlib.sha256(data).hexdigest(), name
    else:
        with path.open('xb') as stream:
            stream.write(data)

def table(name, records):
    buffer = io.StringIO(newline='')
    writer = csv.DictWriter(buffer, records[0], lineterminator='\n')
    writer.writeheader()
    writer.writerows(records)
    emit(name, buffer.getvalue().encode())

def packet(name, **parts):
    buffer = io.BytesIO()
    np.savez(buffer, **parts)
    emit(name, buffer.getvalue())

def shell(place, knots, shape, radii, order, top, rule):
    inputs = [np.ascontiguousarray(value,dtype=float) for value in (place,knots,shape,radii,*rule)]
    output = np.empty((len(radii), (top-order)//2+1), dtype=complex)
    status = library.tesseral(*inputs[:4],len(radii),*inputs[4:],len(rule[0]),order,top,output.view(float))
    if status:
        raise ArithmeticError(('shell projection',status,order,top))
    return output

def controls():
    safe()
    rule = roots_legendre(36)
    mu, weights = roots_legendre(96)
    phi = 2*np.pi*(np.arange(192)+.21)/192
    points = np.stack(np.broadcast_arrays(np.sqrt(1-mu**2)[:,None]*np.cos(phi),
        np.sqrt(1-mu**2)[:,None]*np.sin(phi),mu[:,None]),axis=-1)
    radii = np.array([6.,24.,51.,89.])
    records = []
    for model,epoch in ((MODELS[0],0.),('L3M10rad',-3.01953125)):
        stamp,knots,shapes,traj = history(model)
        left = np.clip(np.searchsorted(stamp,epoch)-1,0,len(stamp)-2)
        frac = (epoch-stamp[left])/(stamp[left+1]-stamp[left])
        coeff = (1-frac)*shapes[left]+frac*shapes[left+1]
        place = positions(traj,epoch)
        old = project(place,knots,coeff,radii,24,rule)
        assert np.linalg.norm(old-shell(place,knots,coeff,radii,2,24,rule))/np.linalg.norm(old)<1e-11
        target = shell(place,knots,coeff,radii,3,39,rule)
        harmon = basis(np.arange(3,40,2),3,mu).T*(weights/2)
        for radius,vector in zip(radii,target):
            direct = harmon@((potential(radius*points-place,knots,coeff)*np.exp(-3j*phi)).mean(axis=1))
            relative = np.linalg.norm(vector-direct)/np.linalg.norm(vector)
            records.append(dict(model=model,epoch=epoch,radius=radius,relative_shell=relative))
    table('cartesian.csv',records)
    print('Cartesian control',max(row['relative_shell'] for row in records),flush=True)
    assert max(row['relative_shell'] for row in records)<TOL

def bank(model):
    safe()
    stamp,knots,shapes,traj = history(model)
    sub = 16
    radius = 35*np.sinh(np.linspace(0,np.arcsinh(400/35),193))
    times = np.linspace(stamp[0],0,(len(stamp)-1)*sub+1)
    sites = positions(traj,times)
    rule = roots_legendre(32)
    values = np.empty((len(times),len(radius),19),complex)
    for idx,place in enumerate(sites):
        if idx%64==0:
            safe()
        left = min(idx//sub,len(stamp)-2)
        frac = idx/sub-left
        values[idx] = shell(place,knots,(1-frac)*shapes[left]+frac*shapes[left+1],radius,3,39,rule)
    packet('tide-'+model+'.npz',times=times,radius=radius,source=values)
    print(model,len(times),'epochs saved',flush=True)

if __name__=='__main__':
    if sys.argv[1:] == ['control']:
        controls()
    else:
        for model in sys.argv[1:] or MODELS:
            assert model in MODELS
            bank(model)
