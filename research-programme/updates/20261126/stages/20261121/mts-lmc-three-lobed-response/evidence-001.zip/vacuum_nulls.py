from rings import *
from itertools import product

RADII = np.array([6.,8.3])
HEIGHT = 1.5

def functionals():
    inner,outer=RADII
    cylindrical=np.array([[0.,1.,0.,-(inner/outer)**3],[1.,5*(inner**2-outer**2)/(16*HEIGHT*inner),-(inner/outer)**2,0.]])
    to_cyl=linalg.block_diag(*(np.array([[radius,HEIGHT],[HEIGHT,-radius]])/np.hypot(radius,HEIGHT) for radius in RADII))
    return cylindrical@to_cyl,to_cyl

def algebra():
    weights,rotate=functionals()
    inner,outer=RADII
    def exact(radius,params):
        first,second,third=params
        height=HEIGHT
        radial=-3*first*radius**2-second*(3*radius**2*height**2-5*radius**4/8)-third*(
            3*radius**2*height**4-15*radius**4*height**2/4+21*radius**6/80)
        axial=-2*second*radius**3*height-third*(4*radius**3*height**3-3*radius**5*height/2)
        return np.array([radial,axial])
    cases = ((1+1j,0,0),(0,.03-.1j,0),(.6+.17j,1.1-.21j,0),(0,0,.01+.03j))
    controls=[]
    for idx,params in enumerate(cases):
        cyl=np.concatenate([exact(radius,params) for radius in RADII])
        sky=rotate.T@cyl
        null=weights@sky
        ratio=abs(null)/np.linalg.norm(cyl)
        if idx<3:
            assert max(ratio)<1e-14
        else:
            assert min(ratio)>1e-3
        controls.append(dict(case=idx,vertical_relative=ratio[0],radial_relative=ratio[1]))
    table('vacuum-analytic-controls.csv',controls)
    return weights

def audit():
    safe()
    weights=algebra()
    assert digest(HOST/'seal.json')=='b4108a60a498b169a0c4242bf7f689b3c64722dfccb7641020e99134461b265a'
    rows=[]
    for model in MODELS:
        native,place=satellite(model)
        _,knots,coeff,_=history(model)
        def direct(xyz):
            return native(xyz-place)[:,1:]-native(-place)[0,1:]
        def external(xyz):
            points=np.vstack([xyz,[0,0,0]])
            grav=force(points,place,knots,coeff[-1],.015)
            return grav[:-1]-grav[-1]
        def reduce_ring(fn,count):
            return np.concatenate([harmonic(fn,radius,count) for radius in RADII])
        direct_raw=reduce_ring(direct,256)
        direct_null=weights@direct_raw
        direct_alt=weights@reduce_ring(external,128)
        finite=weights@reduce_ring(direct,16)
        sims={}
        for kind in ('multipole','basis'):
            start=field(paths(model)[kind,'initial'])
            end=field(paths(model)[kind,'final'])
            def diff(xyz):
                return end(xyz)[:,1:]-start(xyz)[:,1:]
            sims[kind]=weights@reduce_ring(diff,256)
        for case in (0,1):
            with np.load(HERE/f'fine-{case}-128-{model}.npz') as state:
                wave_raw=state['meridian_complex']
            with np.load(HERE/f'fine-{case}-96-{model}.npz') as state:
                narrow=state['meridian_complex']
            with np.load(HERE/f'fine-{case}-128-{model}.npz') as state:
                half=state['original_time_grid']
            box_rows=read(HERE/f'outer-domain-{case}.csv')
            ordered=[next(r for r in box_rows if r['model']==model and r['component']==label and float(r['R'])==radius)
                for radius,label in product(RADII,('radial','polar'))]
            with np.load(HERE/f'state-{case}-{model}.npz') as old:
                box_delta=weights@(np.array([float(r['wide_meridian']) for r in ordered])-old['meridian_complex'].real)
            wave=weights@wave_raw
            modal=weights@(narrow-wave_raw)
            time=weights@(half-wave_raw)
            for idx,name in enumerate(('Z','K')):
                amplitude=abs(wave[idx])
                coef=weights[idx]
                assert amplitude>0
                unsigned_direct=abs(coef)@abs(direct_raw)
                unsigned_wave=abs(coef)@abs(wave_raw)
                rows.append(dict(model=model,case=case,contrast=name,wave_cos=wave[idx].real,wave_sin=-wave[idx].imag,
                    wave_amplitude=amplitude,weight_norm=np.linalg.norm(coef),per_quadrature_3sigma=amplitude/(3*np.linalg.norm(coef)),
                    wave_fraction_of_unsigned_sum=amplitude/unsigned_wave,direct_fraction_of_unsigned_sum=abs(direct_null[idx])/unsigned_direct,
                    direct_to_wave=abs(direct_null[idx])/amplitude,direct_16_vs256_over_wave=abs(finite[idx]-direct_null[idx])/amplitude,
                    implementation_spread_over_wave=abs(direct_alt[idx]-direct_null[idx])/amplitude,
                    live_multipole_to_wave=abs(sims['multipole'][idx])/amplitude,live_basis_to_wave=abs(sims['basis'][idx])/amplitude,
                    live_in_wave_phase_multipole=(sims['multipole'][idx]/wave[idx]).real,
                    live_in_wave_phase_basis=(sims['basis'][idx]/wave[idx]).real,
                    live_representation_spread_over_wave=abs(sims['multipole'][idx]-sims['basis'][idx])/amplitude,
                    modal_relative=abs(modal[idx])/amplitude,time_relative=abs(time[idx])/amplitude,
                    wide_meridian_shift_over_complex_amplitude=abs(box_delta[idx])/amplitude))
    assert len(rows)==24
    table('vacuum-null-test.csv',rows)
    for name in ('Z','K'):
        match=[r for r in rows if r['contrast']==name]
        print(name,{key:(min(r[key] for r in match),max(r[key] for r in match)) for key in (
            'wave_amplitude','direct_to_wave','implementation_spread_over_wave','live_multipole_to_wave','live_basis_to_wave',
            'direct_fraction_of_unsigned_sum','per_quadrature_3sigma')})

if __name__=='__main__':
    audit()
