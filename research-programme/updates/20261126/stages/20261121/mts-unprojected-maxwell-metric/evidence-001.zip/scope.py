import csv
import hashlib
import io
import json
import os
from pathlib import Path

for name in ("OPENBLAS_NUM_THREADS","OMP_NUM_THREADS","MKL_NUM_THREADS","NUMEXPR_NUM_THREADS","BLIS_NUM_THREADS"):
    os.environ[name]="1"
import numpy as np

HERE=Path(__file__).resolve().parent
PARENT=HERE.parent/"mts-stress-off-clock-refinement-20261121"
PIN="80a371849377192e1337bf81f8fce6329f0f67fdb569f5fda63c181ba41ca042"
TARGETS=("maxwell-free-tensor-response.csv","maxwell-oblique-current.csv","MAXWELL-STRESS-SOURCE.md","OBLIQUE-CURRENT.md")
WAVES=np.array([[0,0,0],[.5,0,0],[1,0,0],[2,0,0],[2**-.5,0,2**-.5],[.6,0,-.8],[1.2,0,.5],[.36,.48,.8]])
CLOCKS=np.array([0,.01,.02,.04,.08,.25,.75,1.25,2.])
LEVELS={"coarse":(40,18,32,10.,33),"fine":(56,28,48,12.,49)}
ETA=np.diag([-1.,1.,1.,1.])

def guard():
    if any((where/"STOP-REQUESTED").exists() for where in (HERE,PARENT,HERE.parent)):raise RuntimeError("owner hold")

def sha(path):
    with path.open("rb") as stream:return hashlib.file_digest(stream,"sha256").hexdigest()

def put(path,data):
    guard()
    if path.exists():assert path.read_bytes()==data,path
    else:
        with path.open("xb") as stream:stream.write(data)

def json_file(name,value):
    put(HERE/name,(json.dumps(value,indent=2,allow_nan=False)+"\n").encode())

def table(name,rows):
    stream=io.StringIO(newline="")
    writer=csv.DictWriter(stream,rows[0].keys(),lineterminator="\n")
    writer.writeheader();writer.writerows(rows);put(HERE/name,stream.getvalue().encode())

def read(path):
    with path.open(newline="",encoding="utf8") as stream:return list(csv.DictReader(stream))

def packet(name,**fields):
    assert all(np.isfinite(field).all() for field in fields.values())
    stream=io.BytesIO();np.savez_compressed(stream,**fields);put(HERE/name,stream.getvalue())

def freeze():
    guard()
    assert sha(PARENT/"seal.json")==PIN
    manifest=json.loads((PARENT/"seal.json").read_bytes())["files"]
    pins={name:sha(PARENT/name) for name in TARGETS}
    assert all(manifest[name]==digest for name,digest in pins.items())
    json_file("freeze.json",dict(parent=PIN,inputs=pins,design=sha(HERE/"DESIGN.md"),methods=LEVELS,
        waves=WAVES.tolist(),clocks=CLOCKS.tolist(),tide_tol=2e-8,source_tol=5e-8,null_tol=1e-12,early_current_rtol=2e-5))

def lock():
    guard();freeze()
    return sha(HERE/"freeze.json")

if __name__=="__main__":freeze();print("frozen",lock())
