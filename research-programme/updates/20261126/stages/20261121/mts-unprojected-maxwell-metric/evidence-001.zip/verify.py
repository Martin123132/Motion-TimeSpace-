"""Verify stage completeness and evidence; --seal creates, never overwrites, the manifest."""
import csv
import json
import re
import sys
from scope import HERE,PARENT,PIN,CLOCKS,WAVES,sha,guard,json_file,read,np

def verify():
    guard()
    assert sha(PARENT/"seal.json")==PIN
    parent_files=json.loads((PARENT/"seal.json").read_bytes())["files"]
    assert len(parent_files)==232 and all(sha(PARENT/name)==digest for name,digest in parent_files.items())
    anchors={"freeze.json":"4c19ded4bf15ca47f6e526641c79f586fc64bad3af26f87984546355bda914c0",
             "width-freeze.json":"af502adb8c21c41db09fe374716c50c912439b33dcb645c173820fd8a2718c0d",
             "null-freeze.json":"3336b7a3b45a5cf3d05fcb294cb95bd03ca5baca3f6549b5224fb87252bda68a",
             "action-freeze.json":"304c51618ee0ae29450ea48c60c5f5a67769fedd53b9f122bed232711566db3a"}
    assert all(sha(HERE/name)==digest for name,digest in anchors.items())
    def pin(file,items):
        saved=json.loads((HERE/file).read_bytes())
        for key,path in items.items():assert saved[key]==sha(HERE/path),(file,key)
    pin("freeze.json",{"design":"DESIGN.md"})
    pin("width-freeze.json",{"design":"WIDTH-DESIGN.md","method":"width_forecast.py","forecast":"width-forecast.csv"})
    pin("null-freeze.json",{"design":"NULL-DESIGN.md","method":"null_forecast.py","width_method":"width_forecast.py","output":"critical-forecast.csv"})
    pin("action-freeze.json",{"design":"ACTION-MATCHING.md","method":"action_forecast.py","momentum":"wilson.py","forecast":"action-forecast.csv"})
    pin("finite-null-freeze.json",{"design":"FINITE-NULL-DESIGN.md","previous":"finite-aperture-identities.json","metric":"action-freeze.json"})
    assert not any(path.is_dir() or path.suffix not in (".json",".md",".npz",".csv",".py") for path in HERE.iterdir())
    for path in HERE.glob("*.md"):
        for link in re.findall(r"\]\(([^)]+)\)",path.read_text(encoding="utf-8")):
            if not link.startswith(("https:","http:","#")):assert (HERE/link).is_file(),(path,link)
    tables={}
    for path in sorted(HERE.glob("*.csv")):
        with path.open(encoding="utf-8",newline="") as stream:
            parsed=csv.DictReader(stream)
            assert parsed.fieldnames and len(set(parsed.fieldnames))==len(parsed.fieldnames)
            rows=list(parsed)
        assert rows
        for row in rows:
            assert None not in row and None not in row.values()
            assert not any(value.casefold() in {"nan","inf","-inf","infinity","-infinity"} for value in row.values())
        tables[path.stem]=rows
    def size(name,count):
        assert len(tables[name])==count,(name,len(tables[name]),count)
    for name,count in (("physical-validation",504),("critical-metric-tests",126),("signed-forecast-comparisons",1808),
                       ("metric-checks",1008),("frozen-predictions",228),("two-anchor-transfer",180),("finite-double-null",6),
                       ("finite-registration",6),("finite-apertures",3),("action-forecast",108),("width-forecast",126),("critical-forecast",63)):
        size(name,count)
    for name in ("signed-forecast-comparisons","frozen-predictions"):
        assert all(row["inside"]=="True" for row in tables[name])
    coarse_fail=[row for row in tables["metric-checks"] if float(row["einstein"])>=2e-8]
    assert len(coarse_fail)==2 and {row["which"] for row in coarse_fail}=={"light+","light-"}
    assert all((row["level"],row["gauge"],row["time"],row["mode"])==("coarse","synchronous","0.08","3") for row in coarse_fail)
    assert any(row["coarse_inside"]=="False" for row in tables["width-forecast"])
    for row in tables["physical-validation"]:
        for key in ("full_einstein","whole_tensor_gauge_agreement","constraint","individual_dust_newton","light_focusing"):
            assert float(row[key])<2e-8
    assert all(float(row["max_prediction_error"])<2e-8 for row in tables["critical-metric-tests"])
    assert sum(int(row["other_readings"]) for row in tables["two-anchor-transfer"])==3234
    assert all(float(row["max_abs_error"])<(5e-8 if row["channel"]=="stress" else 2e-8) for row in tables["two-anchor-transfer"])
    assert len({(row["sign"],row["channel"]) for row in tables["finite-double-null"]})==6
    assert all(abs(float(row["fine"])-float(row["prediction"]))<float(row["limit"]) for row in tables["finite-double-null"])
    packets=sorted(HERE.glob("*.npz"))
    assert len(packets)==37
    for path in packets:
        with np.load(path,allow_pickle=False) as packet:
            for key in packet.files:
                value=packet[key]
                assert np.isfinite(value).all(),(path,key)
                if key in ("time","times","clocks"):
                    assert (np.diff(value)>0).all()
                    if path.name.startswith("action-moments-"):
                        np.testing.assert_allclose(value[[0,-1]],[-.35,2.35],atol=2e-15,rtol=0)
                    else:assert value[0]==0 and value[-1]==2
    for level in ("coarse","fine","narrow","wide","critical"):
        with np.load(HERE/("increments-harmonic-"+level+".npz")) as harmonic,np.load(HERE/("increments-synchronous-"+level+".npz")) as synchronous:
            assert np.max(abs(harmonic["riemann"][:,:4]-synchronous["riemann"]))<2e-8
    for label in ("half","one","two"):
        for level in ("coarse","fine"):
            key=label+"-"+level
            data="action-tests-"+key;size(data,540)
            assert len({tuple(row[item] for item in ("time","mode","operator","gauge","channel")) for row in tables[data]})==540
            assert all(row["inside"]=="True" for row in tables[data])
            checks="action-consistency-"+key;size(checks,378)
            assert all(float(row[name])<2e-8 for row in tables[checks] for name in ("einstein","conservation","trace","differential_density","curvature_linearity","gauge_error"))
            with np.load(HERE/("action-rulers-"+key+".npz")) as metric:
                np.testing.assert_array_equal(metric["clocks"],CLOCKS)
                np.testing.assert_array_equal(metric["waves"],WAVES[1:])
                assert metric["harmonic"].shape==(9,3,7,4,4,4,4)
                assert np.max(abs(metric["harmonic"]-metric["synchronous"]))<2e-8
    files={path.name:sha(path) for path in sorted(HERE.iterdir()) if path.name!="seal.json"}
    manifest=dict(parent=PIN,prior_files=len(parent_files),freeze_hashes=anchors|{"finite-null-freeze.json":sha(HERE/"finite-null-freeze.json")},
                  packets=len(packets),tables=len(tables),table_rows=sum(map(len,tables.values())),files=files)
    if sys.argv[1:]==["--seal"]:json_file("seal.json",manifest)
    else:assert not sys.argv[1:]
    assert json.loads((HERE/"seal.json").read_bytes())==manifest
    print("verified",len(files),"files,",manifest["table_rows"],"data rows,",len(packets),"numeric packets; seal",sha(HERE/"seal.json"))

if __name__=="__main__":verify()
