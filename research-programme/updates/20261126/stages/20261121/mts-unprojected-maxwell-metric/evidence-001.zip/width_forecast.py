"""Freeze unequal-width evolution forecasts before generating their spacetime sources."""
from scope import HERE,WAVES,CLOCKS,lock,sha,table,json_file,np,guard
from scipy.special import roots_hermitenorm
from functools import lru_cache

WIDTHS={"wide":1.5,"narrow":2/3}
def frame(wave):
    size=np.linalg.norm(wave)
    az=np.array([-wave[1],wave[0],0.])/np.hypot(*wave[:2])
    return wave/size,az,np.cross(wave/size,az)

def dust_density(wave,width):
    def moment(vector):
        per=vector[:2]@vector[:2];vert=vector[2]**2
        return 1-per/4,.5-vert/4,2-per+per**2/16
    term=moment(wave)[0]
    area,vert,fourth=moment(width*wave)
    return (term+np.exp(-(width**2-1)*(wave@wave)/4)*(4-4*area+area*vert+fourth))/2

@lru_cache(maxsize=2)
def grid(order):
    raw,wm=roots_hermitenorm(order);wm=wm/np.sqrt(2*np.pi)
    return np.stack(np.meshgrid(raw,raw,raw,indexing="ij"),axis=-1).reshape(-1,3),np.einsum("i,j,k->ijk",wm,wm,wm).ravel()

def retarded(size,freq,time):
    return time**2/2*np.sinc((size+freq)*time/(2*np.pi))*np.sinc((size-freq)*time/(2*np.pi))

def one(wave,width,order):
    shift,weights=grid(order)
    variance=width**2/(1+width**2)
    size=np.linalg.norm(wave);per=np.hypot(*wave[:2]);vert=wave[2]
    norm=(2*variance)**1.5*np.exp((.25-variance/2)*size**2)*width**-1.5
    xz=-2*variance**3*per**2*vert/width**2
    zz=2*variance*per*(2-4*variance/width**2+variance**2*per**2/width**2)
    onset=4*variance*(width**2-1)/(width**2+1)*per*vert
    assert abs(per*xz+vert*zz-onset)<2e-14
    line,az,trans=frame(wave)
    first=variance*wave+shift/np.sqrt(1+width**2)
    second=wave-first
    lp,lq=np.linalg.norm(first,axis=1),np.linalg.norm(second,axis=1)
    axis=np.array([0.,0.,1.])
    ea=1j*np.cross(first,axis);ep=-width**2*np.cross(second,np.cross(second,axis))
    ba=-1j*np.cross(first,ea)/lp[:,None];bp=-1j*np.cross(second,ep)/lq[:,None]
    def shear(left,right,ruler):
        return -2*((left@ruler)*(right@az)+(right@ruler)*(left@az)).imag
    direct,delayed=shear(ea,ep,trans),shear(ba,bp,trans)
    longitudinal,secondary=shear(ea,ep,line),shear(ba,bp,line)
    cross1=2*(np.cross(ea,bp)@az).real;cross2=2*(np.cross(ep,ba)@az).real
    density=dust_density(wave,width);rows=[]
    for at in CLOCKS:
        cosp,cosq=np.cos(lp*at),np.cos(lq*at)
        sinp,sinq=np.sin(lp*at),np.sin(lq*at)
        shear_tt=norm*weights@(direct*cosp*cosq+delayed*sinp*sinq)
        shear_long=norm*weights@(longitudinal*cosp*cosq+secondary*sinp*sinq)
        current=norm*weights@(cross1*cosp*sinq+cross2*cosq*sinp)
        metric=norm*weights@((direct+delayed)*retarded(size,lp-lq,at)+(direct-delayed)*retarded(size,lp+lq,at))
        tide=shear_tt-size**2*metric/2
        if at==0.:
            assert abs(tide/norm-(per*zz-vert*xz)/size)<2e-13
            assert abs(shear_long/norm-onset/size)<2e-13
            assert abs(norm*weights@(cross1*lq+cross2*lp)-norm*onset)<2e-12
        rows.append(dict(time=at,source_scale=norm,analytic_current_slope=onset,dust_density=density,
            current=current,stress_tt=shear_tt,tide_tt=tide,tide_vector=shear_long,metric_tt=metric,
            normalized_tide=2*tide/density))
    return rows

def prepare():
    clock=lock()
    spec=sha(HERE/"WIDTH-DESIGN.md")
    if not (HERE/"width-freeze.json").exists():
        assert not any((HERE/("source-"+code+".npz")).exists() for code in WIDTHS),"Cannot initialize a prospective forecast after calculation"
    rows=[]
    for code,width in WIDTHS.items():
        for index,wave in enumerate(WAVES[1:]):
            initial=one(wave,width,20);low=one(wave,width,28);high=one(wave,width,36)
            for coarse,first,second in zip(initial,low,high,strict=True):
                defect=max(abs(first[key]-second[key]) for key in ("current","stress_tt","tide_tt","tide_vector","metric_tt"))
                previous=max(abs(coarse[key]-first[key]) for key in ("current","stress_tt","tide_tt","tide_vector","metric_tt"))
                assert defect<5e-8,(code,index,first["time"],defect)
                rows.append(dict(preparation=code,mode=index+1,width=width,coarse_discrepancy=previous,
                    coarse_inside=previous<5e-8,momentum_refinement=defect,**second))
    table("width-forecast.csv",rows)
    json_file("width-freeze.json",dict(parent_design=clock,design=spec,method=sha(HERE/"width_forecast.py"),forecast=sha(HERE/"width-forecast.csv"),
        counts=len(rows),widths=WIDTHS,energy_preserving=True))
    print("frozen unequal-width forecast",sha(HERE/"width-freeze.json"),len(rows))

if __name__=="__main__":prepare()
