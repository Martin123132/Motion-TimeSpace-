"""All metric polarizations driven by the direct action variation in real space."""
from scope import HERE,WAVES,CLOCKS,ETA,LEVELS,guard,lock,np,sha,packet,table,read
from photons import PacketTransform
from spacetime import Evolution
from local_jets import local
from action_forecast import TARGETS,minimal_cov
from wilson import BIVECS,test_metric
from null_forecast import critical
from width_forecast import frame
from scipy.fft import dct
from numpy.polynomial.chebyshev import chebder,chebval
from functools import lru_cache
import json

SPAN=1.35

def inputs(label,level):
    lock()
    frozen=json.loads((HERE/"action-freeze.json").read_bytes())
    assert sha(HERE/"action-forecast.csv")==frozen["forecast"] and sha(HERE/"ACTION-MATCHING.md")==frozen["design"]
    width=critical(np.linalg.norm(WAVES[TARGETS[label]]))
    mesh=PacketTransform(*LEVELS[level][:4])
    count=43 if level=="coarse" else 55
    times=1-SPAN*np.cos(np.arange(count)*np.pi/(count-1));fields=[]
    for at in times:
        guard()
        ea,ba,ep,bp=mesh.field_arrays(at,width)
        tor,pol=np.column_stack((ea,ba)),np.column_stack((ep,bp))
        items=[2*(tor[:,left]*pol[:,right]+pol[:,left]*tor[:,right]) for left in range(6) for right in range(left,6)]
        spectra=mesh.transform[1:]@np.array(items).T
        moment=np.zeros((len(WAVES)-1,6,6),complex)
        coords=np.triu_indices(6)
        moment[:,coords[0],coords[1]]=moment[:,coords[1],coords[0]]=spectra
        fields.append(moment)
    coeff=dct(np.array(fields)[::-1],type=1,axis=0)/(count-1);coeff[[0,-1]]/=2
    packet("action-moments-"+label+"-"+level+".npz",coeff=coeff,times=times,width=width)

@lru_cache(maxsize=1)
def metric_vertices():
    variations=np.zeros((3,len(WAVES)-1,4,4,6,6),complex)
    for wid,wave in enumerate(WAVES[1:]):
        for left in range(4):
            for right in range(left,4):
                test=np.zeros((4,4));test[left,right]=test[right,left]=1.
                factor=(2 if left==right else 1)*ETA[left,left]*ETA[right,right]
                for degree in range(3):
                    coeff=np.einsum("abcd,Aab,Bcd->AB",test_metric(wave,degree,test),BIVECS,BIVECS)
                    variations[degree,wid,left,right]=variations[degree,wid,right,left]=factor*(-1)**degree*coeff
    return variations

class Operators:
    def __init__(self,label,level):
        with np.load(HERE/("action-moments-"+label+"-"+level+".npz")) as saved:raw=saved["coeff"]
        coeffs=[]
        for degree in range(3):
            differentiated=chebder(raw,m=degree,scl=1/SPAN)
            coeffs.append(np.pad(differentiated,((0,degree),(0,0),(0,0),(0,0))))
        direct=np.einsum("okabuv,onkuv->nkab",metric_vertices(),np.array(coeffs),optimize=True)
        lap=coeffs[2]+(WAVES[1:]**2).sum(axis=1)[:,None,None]*raw
        reduced=np.array([[minimal_cov(moment) for moment in term] for term in lap])
        self.coeff=np.stack((direct,reduced,.3*direct-.12*reduced),axis=1)
    def value(self,at,broken=False):
        return chebval((at-1)/SPAN,self.coeff)
    def derivative(self,at):
        return chebval((at-1)/SPAN,chebder(self.coeff,scl=1/SPAN))

def calculate(label,level):
    guard();ops=Operators(label,level);waves=WAVES[1:]
    assert np.max(abs(ops.value(0.)[:,:,0,:]))<2e-8
    indices=(TARGETS[label],4)
    expected={(int(row["mode"]),float(row["time"]),row["operator"]):row for row in read(HERE/"action-forecast.csv") if row["preparation"]==label}
    observables=[];valid=[];gauges=[]
    for gauge in ("harmonic","synchronous"):
        sim=Evolution("fine",gauge,source=ops)
        recorded=[]
        for at in CLOCKS:
            guard()
            metric=sim.metric(at);tensor=ops.value(at)
            riem,geom=local(sim,at,.002,4)
            recorded.append(riem)
            derivative=ops.derivative(at)
            ward=-derivative[:,:,0,:]+np.einsum("ki,skij->skj",1j*waves,tensor[:,:,1:])
            gauge_eta=sim.analytic_jets(at)
            if gauge=="harmonic":
                from spacetime import reverse
                gauge_error=-reverse(gauge_eta[1])[:,:,0,:]+np.einsum("ki,skij->skj",1j*waves,reverse(metric)[:,:,1:])
            else:gauge_error=metric[:,:,0,:]
            for wid,wave in enumerate(waves):
                mode=wid+1;line,az,trans=frame(wave)
                for idx,what in enumerate(("weyl","gravity","mixed")):
                    tide=-riem[idx,wid,0,1:,0,1:]
                    cur=-(geom[idx,wid,0,1:]@az).real
                    vector=(line@tide@az).imag
                    tt=(trans@tide@az).imag
                    measured=dict(stress=(trans@tensor[idx,wid,1:,1:]@az).imag,vector=vector,current=cur,
                                  metric=(trans@metric[idx,wid,1:,1:]@az).imag,tidal=tt)
                    valid.append(dict(preparation=label,level=level,gauge=gauge,time=at,mode=mode,operator=what,
                        conservation=np.max(abs(ward[idx,wid])),einstein=np.max(abs(geom[idx,wid]-tensor[idx,wid])),
                        gauge_error=np.max(abs(gauge_error[idx,wid])),differential_density=abs(tensor[idx,wid,0,0]),
                        trace=abs(np.sum(ETA*tensor[idx,wid])),curvature_linearity=np.max(abs(riem[2,wid]-.3*riem[0,wid]+.12*riem[1,wid]))))
                    if mode not in indices:continue
                    def prediction(key):
                        if what!="mixed":return float(expected[mode,at,what][key])
                        return .3*float(expected[mode,at,"weyl"][key])-.12*float(expected[mode,at,"gravity"][key])
                    for channel,actual in measured.items():
                        forecast=prediction(channel)
                        limit=5e-8 if channel=="stress" else 2e-8
                        observables.append(dict(preparation=label,level=level,gauge=gauge,time=at,mode=mode,operator=what,
                            channel=channel,measured=actual,forecast=forecast,error=abs(actual-forecast),
                            inside=abs(actual-forecast)<=limit))
        gauges.append(np.array(recorded))
    table("action-tests-"+label+"-"+level+".csv",observables)
    table("action-consistency-"+label+"-"+level+".csv",valid)
    mismatch=np.max(abs(gauges[0]-gauges[1]))
    packet("action-rulers-"+label+"-"+level+".npz",clocks=CLOCKS,waves=waves,harmonic=gauges[0],synchronous=gauges[1])
    print(label,level,"discrepancy",mismatch,"observable error",max(row["error"] for row in observables),
        {key:max(row[key] for row in valid) for key in ("einstein","conservation","differential_density","trace")},flush=True)
    assert mismatch<2e-8 and all(row["inside"] for row in observables)
    assert all(max(row[key] for row in valid)<2e-8 for key in ("einstein","conservation","differential_density","trace","curvature_linearity","gauge_error"))

if __name__=="__main__":
    import sys
    for level in sys.argv[1:] or LEVELS:
        for label in TARGETS:
            inputs(label,level);calculate(label,level)
