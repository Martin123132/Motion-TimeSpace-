"""Independent harmonic metric and unit-lapse ADM initial value evolutions."""
from scope import HERE, WAVES, CLOCKS, ETA, guard, lock, np, packet
from scipy.integrate import solve_ivp

class Source:
    def __init__(self,level):
        with np.load(HERE/("source-"+level+".npz")) as data:
            np.testing.assert_array_equal(data["waves"],WAVES)
            self.coeff=data["coefficients"][:,:,1:].copy()
            self.initial=data["tensor"][0,:,1:].copy()
        self.dust=np.zeros_like(self.initial)
        self.dust[:,:,0,0]=self.initial[:,:,0,0]
    def value(self,time,broken=False):
        light=np.polynomial.chebyshev.chebval(time-1,self.coeff)
        if not broken:return np.concatenate((light,self.dust))
        altered=light.copy()
        common=light[:,:,0,1:].mean(axis=0)
        altered[:,:,0,1:]=altered[:,:,1:,0]=common
        return np.concatenate((light,self.dust,altered))

def reverse(tensor):
    trace=np.einsum("ab,...ab->...",ETA,tensor)
    return tensor-ETA*trace[...,None,None]/2

class Evolution:
    def __init__(self,level,gauge,source=None):
        self.gauge=gauge
        self.source=Source(level) if source is None else source
        waves=WAVES[1:]
        self.square=(waves**2).sum(axis=1)[:,None,None]
        self.waves=waves
        energy=self.source.value(0.,gauge=="harmonic")[:,:,0,0]
        if gauge=="harmonic":
            initial=np.zeros((*energy.shape,4,4),complex)
            initial[:,:,0,0]=2*energy/self.square[:,0,0]
        elif gauge=="synchronous":
            initial=np.eye(3)*(energy/self.square[:,0,0])[:,:,None,None]
        else:raise ValueError(gauge)
        state=np.stack((initial,0*initial));self.shape=state.shape
        self.calls=0
        self.solve=solve_ivp(self.rhs,(0.,2.),state.ravel(),method="DOP853",rtol=2e-12,atol=2e-14,
            max_step=.04 if level=="fine" else .07,dense_output=True)
        assert self.solve.success and self.solve.t[-1]==2
    def rhs(self,time,vector):
        self.calls+=1
        if self.calls%64==0:guard()
        first,second=vector.reshape(self.shape)
        tensor=self.source.value(time,self.gauge=="harmonic")
        if self.gauge=="harmonic":
            output=np.stack((second,2*tensor-self.square*first))
        else:
            shear=tensor[:,:,1:,1:];density=tensor[:,:,0,0]
            trace=np.trace(first,axis1=-2,axis2=-1)
            contracted=np.einsum("ki,skij->skj",self.waves,first)
            pair=self.waves[None,:,:,None]*contracted[:,:,None,:]
            outer=self.waves[:,:,None]*self.waves[:,None,:]
            ricci=(self.square*first+outer*trace[:,:,None,None]-pair-pair.swapaxes(-1,-2))/2
            source=shear-np.eye(3)*(np.trace(shear,axis1=-2,axis2=-1)-density)[:,:,None,None]/2
            output=np.stack((-2*second,ricci-source))
        return output.ravel()
    def metric(self,time):
        first=self.solve.sol(time).reshape(self.shape)[0]
        if self.gauge=="harmonic":return reverse(first)
        metric=np.zeros((*first.shape[:2],4,4),complex);metric[:,:,1:,1:]=first
        return metric
    def analytic_jets(self,time):
        state=self.solve.sol(time)
        first,second=state.reshape(self.shape)
        rate=self.rhs(time,state).reshape(self.shape)[1]
        if self.gauge=="harmonic":return reverse(first),reverse(second),reverse(rate)
        outputs=[]
        for tensor in (first,-2*second,-2*rate):
            out=np.zeros((*first.shape[:2],4,4),complex);out[:,:,1:,1:]=tensor
            outputs.append(out)
        return tuple(outputs)

def differentiate(evolution,time,spacing):
    if time<3*spacing:nodes=np.arange(7)
    elif time>2-3*spacing:nodes=np.arange(-6,1)
    else:nodes=np.arange(-3,4)
    jets=np.stack([evolution.metric(time+spacing*node) for node in nodes])
    powers=np.array([nodes.astype(float)**degree for degree in range(7)])
    answers=[]
    for degree,factor in ((1,1.),(2,2.)):
        target=np.eye(7)[degree]*factor
        coeff=np.linalg.solve(powers,target)
        answers.append(np.tensordot(coeff,jets-jets[np.nonzero(nodes==0)[0][0]],axes=1)/spacing**degree)
    return evolution.metric(time),*answers

def curvature(metric,velocity,acceleration):
    shape=metric.shape[:2]
    dder=np.zeros((*shape,4,4,4,4),complex)
    dder[:,:,0,0]=acceleration
    waves=1j*WAVES[1:]
    for left in range(3):
        dder[:,:,0,left+1]=dder[:,:,left+1,0]=waves[:,left,None,None]*velocity
        for right in range(3):
            dder[:,:,left+1,right+1]=(waves[:,left]*waves[:,right])[:,None,None]*metric
    def order(text):return np.einsum("...abcd->..."+text,dder)
    riemann=(order("cabd")+order("acdb")-order("acbd")-order("cadb"))/2
    ricci=np.einsum("ac,...abcd->...bd",ETA,riemann)
    return riemann,reverse(ricci)

def invariant_checks(riemann):
    swap=lambda value,first,second:value.swapaxes(first,second)
    assert np.max(abs(riemann+swap(riemann,-1,-2)))<2e-12
    assert np.max(abs(riemann+swap(riemann,-3,-4)))<2e-12
    assert np.max(abs(riemann-np.einsum("...abcd->...cdab",riemann)))<2e-12
    assert np.max(abs(riemann+np.einsum("...abcd->...acdb",riemann)+np.einsum("...abcd->...adbc",riemann)))<2e-12

def evaluate(level,gauge):
    lock();evolution=Evolution(level,gauge)
    tensors=[];curves=[];finite=[];gauges=[];metric_samples=[];einstein=[];finite_einstein=[];coarse_finite=[]
    for time in CLOCKS:
        guard()
        direct=evolution.analytic_jets(time)
        metric,velocity,acceleration=direct
        riemann,grav=curvature(*direct);invariant_checks(riemann)
        rr,gg=curvature(*differentiate(evolution,time,.002))
        rc,gc=curvature(*differentiate(evolution,time,.004))
        curves.append(riemann);finite.append(rr);coarse_finite.append(rc)
        tensors.append(evolution.source.value(time,gauge=="harmonic"))
        metric_samples.append(metric);einstein.append(grav);finite_einstein.append(gg)
        if gauge=="harmonic":
            gauge_current=-reverse(velocity)[:,:,0,:]+np.einsum("ki,skij->skj",1j*WAVES[1:],reverse(metric)[:,:,1:,:])
        else:
            gauge_current=metric[:,:,0,:]
        gauges.append(gauge_current)
    packet(gauge+"-"+level+".npz",times=CLOCKS,waves=WAVES[1:],source=tensors,riemann=curves,finite=finite,
        coarse_finite=coarse_finite,gauge=gauges,metric=metric_samples,einstein=einstein,finite_einstein=finite_einstein)
    print(gauge,level,evolution.calls,"source evaluations",flush=True)

if __name__=="__main__":
    import sys
    for level in sys.argv[1:] or ("coarse","fine"):
        for gauge in ("harmonic","synchronous"):evaluate(level,gauge)
