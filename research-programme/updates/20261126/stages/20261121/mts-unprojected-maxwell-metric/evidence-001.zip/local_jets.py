"""Independent metric increments around each saved epoch; keep original coarse misses intact."""
from scope import HERE,LEVELS,CLOCKS,WAVES,ETA,guard,lock,np,packet,table
from spacetime import Evolution,reverse,curvature

def increment_metric(evolution,vector):
    value=vector.reshape(evolution.shape)[0]
    if evolution.gauge=="harmonic":return reverse(value)
    metric=np.zeros((*value.shape[:2],4,4),complex)
    metric[:,:,1:,1:]=value
    return metric

def local(evolution,time,spacing,substeps):
    base=evolution.solve.sol(time)
    if time<3*spacing:nodes=np.arange(7)
    elif time>2-3*spacing:nodes=np.arange(-6,1)
    else:nodes=np.arange(-3,4)
    samples={0:np.zeros_like(increment_metric(evolution,base))}
    for direction,count in ((-1,-nodes[0]),(1,nodes[-1])):
        inc=0*base
        step=direction*spacing/substeps
        for pos in range(1,count+1):
            for index in range(substeps):
                elapsed=step*((pos-1)*substeps+index)
                at=time+elapsed
                def evaluate(offset,change):return evolution.rhs(at+offset,base+(inc+change))
                first=evaluate(0.,0.)
                second=evaluate(step/2,step*first/2)
                third=evaluate(step/2,step*second/2)
                fourth=evaluate(step,step*third)
                inc+=step*(first+2*second+2*third+fourth)/6
            samples[direction*pos]=increment_metric(evolution,inc)
    values=np.stack([samples[node] for node in nodes])
    powers=np.array([nodes.astype(float)**degree for degree in range(7)])
    jets=[increment_metric(evolution,base)]
    for degree,factor in ((1,1.),(2,2.)):
        coeff=np.linalg.solve(powers,np.eye(7)[degree]*factor)
        jets.append(np.tensordot(coeff,values,axes=1)/spacing**degree)
    return curvature(*jets)

def calculate(level,gauge):
    lock()
    evolution=Evolution(level,gauge)
    with np.load(HERE/(gauge+"-"+level+".npz")) as source:
        native=source["metric"]
        tensors=source["source"]
        ref=source["riemann"]
        raw=source["finite"]
    results=[];einstein=[];tests=[]
    for index,time in enumerate(CLOCKS):
        guard();np.testing.assert_array_equal(evolution.metric(time),native[index])
        rough,_=local(evolution,time,.004,2)
        fine,geom=local(evolution,time,.002,4)
        for case in range(4):
            for mode in range(len(WAVES)-1):
                def err(field):return np.max(abs(field[case,mode]))
                tests.append(dict(level=level,gauge=gauge,time=time,mode=mode+1,case=case,
                    old_vs_direct=err(raw[index]-ref[index]),new_vs_direct=err(fine-ref[index]),
                    spacing_change=err(fine-rough),full_einstein=err(geom-tensors[index]),
                    current_error=err((geom-tensors[index])[:,:,0,:]),
                    focusing_error=abs(-np.trace(fine[case,mode,0,1:,0,1:])+
                    (tensors[index,case,mode,0,0]+np.trace(tensors[index,case,mode,1:,1:]))/2)))
        results.append(fine);einstein.append(geom)
    table("increments-"+gauge+"-"+level+".csv",tests)
    packet("increments-"+gauge+"-"+level+".npz",riemann=results,einstein=einstein)
    assert all(max(row[key] for row in tests)<2e-8 for key in ("new_vs_direct","spacing_change","full_einstein","current_error","focusing_error"))
    print(gauge,level,"incremental curvature verified",flush=True)

if __name__=="__main__":
    import sys
    for level in sys.argv[1:] or LEVELS:
        for gauge in ("harmonic","synchronous"):calculate(level,gauge)
