"""Recover two synthetic launch readings, then predict other components and later epochs."""
from collections import defaultdict
from scope import HERE,np,read,table,lock

def run():
    lock()
    forecasts=read(HERE/"action-forecast.csv")
    lookup={(row["preparation"],row["mode"],row["time"],row["operator"]):row for row in forecasts}
    assert len(lookup)==len(forecasts)==108
    anchors=(("half","1"),("two","3"))
    def coefficients(label,mode,time,channel):
        return [float(lookup[label,mode,time,operator][channel]) for operator in ("weyl","gravity")]
    system=np.array([coefficients(label,mode,"0.0","tidal") for label,mode in anchors])
    records=[row for path in sorted(HERE.glob("action-tests-*.csv")) for row in read(path)]
    assert len(records)==3240
    def calibration(row):
        return (row["preparation"],row["mode"]) in anchors and row["time"]=="0.0" and row["channel"]=="tidal" and row["level"]=="fine" and row["gauge"]=="harmonic"
    fits=[];groups=defaultdict(list)
    for operator in ("weyl","gravity","mixed"):
        subset=[row for row in records if row["operator"]==operator]
        selected=[row for row in subset if calibration(row)]
        assert len(selected)==2 and len({row["preparation"] for row in selected})==2
        trained={row["preparation"]:float(row["measured"]) for row in selected}
        readings=[trained[label] for label,mode in anchors]
        response=np.linalg.solve(system,readings)
        fits.append(dict(synthetic_case=operator,launch_half=readings[0],launch_two=readings[1],
                         photon=response[0],reduced_gravity=response[1],condition=np.linalg.cond(system)))
        for row in subset:
            if calibration(row):continue
            vector=coefficients(row["preparation"],row["mode"],row["time"],row["channel"])
            weights=np.linalg.solve(system.T,vector)
            prediction=np.dot(weights,readings)
            limit=5e-8 if row["channel"]=="stress" else 2e-8
            error=abs(prediction-float(row["measured"]))
            assert error<limit,(row,error)
            key=tuple(row[name] for name in ("operator","preparation","level","gauge","channel"))
            groups[key].append((error,np.linalg.norm(weights,ord=1)))
    detail=[dict(zip(("case","preparation","level","gauge","channel"),key),other_readings=len(entries),
                 max_abs_error=max(item[0] for item in entries),max_anchor_error_gain=max(item[1] for item in entries)) for key,entries in sorted(groups.items())]
    assert sum(row["other_readings"] for row in detail)==3234
    table("two-anchor-calibration.csv",fits);table("two-anchor-transfer.csv",detail)
    print("other readings 3234; worst abs error",max(row["max_abs_error"] for row in detail),
          "max fine error",max(row["max_abs_error"] for row in detail if row["level"]=="fine"))
    print(fits)
if __name__=="__main__":run()
