"""Gaussian moment derivation of the two equatorial launch responses, with no fitted constants."""
from math import comb
from scope import HERE,np,read,json_file,lock
from wilson import BIVECS,test_metric
import sympy as sp

def derive():
    xx,yy,zz=coordinates=sp.symbols("px py pz",real=True)
    kk,beta,v=sp.symbols("K beta v",positive=True)
    eye=sp.I;axis=sp.Matrix([0,0,1])
    pp=sp.Matrix(coordinates);qq=sp.Matrix([kk,0,0])-pp
    def make(vec,electric):
        zero=sp.zeros(3,1)
        return (electric.col_join(zero),zero.col_join(-eye*vec.cross(electric)),
                (-vec.dot(vec)*electric).col_join(zero))
    tor=make(pp,eye*pp.cross(axis));pol=make(qq,-beta*qq.cross(qq.cross(axis)))
    def product(degree,first,second):
        return 2*sum(comb(degree,split)*(tor[split][first]*pol[degree-split][second]+tor[split][second]*pol[degree-split][first])
                     for split in range(degree+1))
    def average(poly):
        total=0
        for (nx,ny,nz),value in sp.Poly(poly,xx,yy,zz).terms():
            if ny%2 or nz%2:continue
            planar=sum(comb(nx,2*index)*sp.factorial2(2*index-1)*(1-v)**index*(v*kk)**(nx-2*index)
                       for index in range(nx//2+1))
            total+=value*planar*sp.factorial2(ny-1)*sp.factorial2(nz-1)*(1-v)**((ny+nz)//2)
        return sp.factor((total/sp.I).subs(v,beta/(1+beta)))
    nominal=average(-product(0,1,2)-product(0,4,5))
    second=average(-product(2,1,2)-product(2,4,5))
    polarization=np.zeros((4,4));polarization[2,3]=polarization[3,2]=1.
    vertex=0
    for degree in range(3):
        coeff=np.einsum("abcd,Aab,Bcd->AB",test_metric(np.array([1.,0.,0.]),degree,polarization),BIVECS,BIVECS)
        for first,other in zip(*np.nonzero(abs(coeff)>0),strict=True):
            entry=coeff[first,other]
            rational=sp.Rational(str(entry.real))+eye*sp.Rational(str(entry.imag))
            vertex+=(-1)**degree*kk**(2-degree)*rational*product(degree,first,other)
    weyl=average(vertex)
    gravity=sp.factor(second+kk**2*nominal)
    null_square=2*(1-beta**2)/beta
    def critical_form(expr):
        even=sp.factor(expr/kk)
        assert sp.simplify(even-even.subs(kk,-kk))==0
        return sp.factor(even.subs(kk**2,null_square))
    assert critical_form(nominal)==0
    wc,gc=map(critical_form,(weyl,gravity))
    ratio=sp.factor(wc/gc)
    slope=sp.factor(sp.diff(ratio,beta))
    assert slope!=0
    for row in read(HERE/"wilson-launch-vertices.csv"):
        if int(row["mode"])>3:continue
        size,width=float(row["kL"]),float(row["width"])
        variance=width**2/(1+width**2)
        norm=width**-1.5*(2*variance)**1.5*np.exp((.25-variance/2)*size**2)
        params={kk:size,beta:width**2}
        for expr,key in ((nominal,"launch_stress"),(second,"stress_second"),(weyl,"weyl_photon"),(gravity,"curvature_squared")):
            assert abs(float(expr.subs(params))*norm-float(row[key]))<1e-11,(expr,key,row)
    answers={name:str(value) for name,value in dict(minimal=nominal,photon_weyl=weyl,spin2_gravity=gravity,
        null_weyl_over_K=wc,null_gravity_over_K=gc,null_ratio=ratio,ratio_derivative=slope).items()}
    json_file("gaussian-vertex-identities.json",answers);print(answers)
    return answers

if __name__=="__main__":lock();derive()
