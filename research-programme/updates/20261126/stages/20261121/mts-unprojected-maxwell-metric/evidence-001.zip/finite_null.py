"""Test an isolated curvature-photon response and a symmetric registration control."""
from scope import HERE, lock, sha, json_file, table, np
from finite_detector import moments, independent

def ordinary(width, centre):
    shape=1/(1+2*width**2)
    return 2*shape**1.5*np.exp(-shape*centre**2)*shape*centre*((shape*centre)**2-2*shape)

def run():
    lock()
    json_file("finite-null-freeze.json",dict(design=sha(HERE/"FINITE-NULL-DESIGN.md"),
              previous=sha(HERE/"finite-aperture-identities.json"),metric=sha(HERE/"action-freeze.json")))
    shape=1/np.sqrt(2.)
    width=np.sqrt((np.sqrt(2.)-1)/2)
    centre=np.sqrt(2/shape)
    response=4*np.sqrt(2.)*np.exp(-2.)
    rows=[]
    for sign in (1,-1):
        target=np.array([0.,sign*response,0.])
        low=independent(width,sign*centre,26,.002)
        middle=independent(width,sign*centre,36,.002)
        high=independent(width,sign*centre,36,.001)
        for idx,channel in enumerate(("ordinary","weyl","reduced_gravity")):
            tolerance=1e-12 if channel=="ordinary" else 2e-8
            assert max(abs(high[idx]-target[idx]),abs(low[idx]-middle[idx]),abs(high[idx]-middle[idx]))<tolerance
            rows.append(dict(sign=sign,width=width,centre=sign*centre,channel=channel,low=low[idx],middle=middle[idx],
                         fine=high[idx],prediction=target[idx],limit=tolerance))
    table("finite-double-null.csv",rows)
    leak=[]
    for kind,eps in (("shared_translation",.01),("shared_translation",.005),("half_separation",.001),
                     ("half_separation",-.001),("width",.001),("width",-.001)):
        positive=centre+(eps if kind!="width" else 0.)
        negative=-centre+(eps if kind=="shared_translation" else (-eps if kind=="half_separation" else 0.))
        probe_width=width+(eps if kind=="width" else 0.)
        right=moments(probe_width,positive,36,0.)[0]
        left=moments(probe_width,negative,36,0.)[0]
        difference=(right-left)/2
        common=(right+left)/2
        expected=(ordinary(probe_width,positive)-ordinary(probe_width,negative))/2
        assert max(abs(right-ordinary(probe_width,positive)),abs(left-ordinary(probe_width,negative)))<2e-8
        envelope=shape**1.5*np.exp(-2)
        slope=8*envelope*shape**2
        leading={"shared_translation":-10*shape**3*centre*envelope*eps**2,
                 "half_separation":slope*eps,"width":-slope*(4*width/centre)*eps}[kind]
        assert abs(difference/leading-1)<.02
        if kind=="shared_translation":assert abs(common/(slope*eps)-1)<.002
        leak.append(dict(test=kind,offset=eps,right=right,left=left,half_difference=difference,
                         half_sum=common,exact_difference=expected,leading_term=leading))
    ratio=leak[0]["half_difference"]/leak[1]["half_difference"]
    assert abs(ratio-4)<.01
    table("finite-registration.csv",leak)
    print("W=",response,"largest fine error",max(abs(row["fine"]-row["prediction"]) for row in rows),"translation ratio",ratio)

if __name__=="__main__":run()
