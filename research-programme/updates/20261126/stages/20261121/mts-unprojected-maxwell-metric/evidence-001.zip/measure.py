from scope import HERE, PARENT, WAVES, LEVELS, CLOCKS, ETA, guard, lock, np, read, table
from spacetime import curvature

def peak(value):return float(np.max(abs(value)))
def frame(wave):
    line=wave/np.linalg.norm(wave)
    az=np.cross([0.,0.,1.],line);az/=np.linalg.norm(az)
    return line,az,np.cross(line,az)

def algebra():
    rng=np.random.default_rng(70213)
    vec=rng.normal(size=(len(WAVES)-1,4))
    cov=np.column_stack((np.full(len(vec),.73),WAVES[1:]))
    pure=(cov[:,:,None]*vec[:,None,:]+vec[:,:,None]*cov[:,None,:])[None,:,:,:]
    r,ein=curvature(pure,.73j*pure,-.73**2*pure)
    assert peak(r)<2e-14 and peak(ein)<2e-14
    dust=np.zeros_like(pure)
    dust[:,:,0,0]=1
    r,ein=curvature(dust,0*dust,0*dust)
    np.testing.assert_allclose(r[0,:,0,1:,0,1:],WAVES[1:,:,None]*WAVES[1:,None,:]/2,atol=1e-15)

def sources():
    from numpy.polynomial.chebyshev import chebval, chebder
    info=[]
    banks=[]
    for level in LEVELS:
        with np.load(HERE/("source-"+level+".npz")) as saved:
            banks.append(saved["coefficients"])
    for at in np.unique(np.r_[CLOCKS,np.linspace(.023,1.97,21)]):
        refined=[chebval(at-1,bank) for bank in banks]
        for level,bank,source in zip(LEVELS,banks,refined,strict=True):
            rates=chebval(at-1,chebder(bank))
            defect=-rates[:,:,0,:]+np.einsum("ki,skij->skj",1j*WAVES,source[:,:,1:,:])
            diff=source[0]-source[1]
            for index,wave in enumerate(WAVES):
                info.append(dict(level=level,time=at,mode=index,individual_continuity=peak(defect[:,index]),
                    differential_density=abs(diff[index,0,0]),longitudinal_current=abs(wave@diff[index,0,1:]),
                    trace=peak(np.einsum("ab,sab->s",ETA,source[:,index])),coarse_fine=peak(refined[0][:,index]-refined[1][:,index])))
            assert peak(source[:,0,0,0]-1.75)<5e-8 and peak(source[:,0,0,1:])<1e-12 and peak(diff[0])<1e-12
    table("source-checks.csv",info)
    return info

def frozen():
    eq={(float(row["kL"]),float(row["time_over_L"])):row for row in read(PARENT/"maxwell-free-tensor-response.csv") if row["order"]=="28"}
    ob={(round(float(row["kxL"]),10),round(float(row["kzL"]),10),float(row["time_over_L"])):row for row in read(PARENT/"maxwell-oblique-current.csv")}
    assert len(eq)==20 and len(ob)==12
    return eq,ob

def metrics():
    eq,ob=frozen()
    states=[];comparison=[];probes=[];rejections=[];frozen_rows=[]
    for level in LEVELS:
        banks=[]
        for gauge in ("harmonic","synchronous"):
            with np.load(HERE/(gauge+"-"+level+".npz")) as saved:
                banks.append({key:saved[key] for key in saved.files})
        for tid,at in enumerate(CLOCKS):
            for wid,wave in enumerate(WAVES[1:]):
                line,az,trans=frame(wave)
                weq=wave[1]==wave[2]==0
                key=round(float(wave[0]),10),round(float(wave[2]),10),float(at)
                for case in range(4):
                    address=(tid,case,wid)
                    one,two=banks
                    for gauge,bank in zip(("harmonic","synchronous"),banks,strict=True):
                        rr=bank["finite"][address];phys=bank["source"][address]
                        tide=-rr[0,1:,0,1:]
                        trace_expected=-(phys[0,0]+np.trace(phys[1:,1:]))/2
                        newton=-phys[0,0]*np.outer(line,line)/2
                        err=bank["finite_einstein"][address]-phys
                        states.append(dict(level=level,gauge=gauge,which=("light+","light-","dust+","dust-")[case],time=at,mode=wid+1,
                            einstein=peak(err),constraint=peak(err[0]),gauge_residual=peak(bank["gauge"][address]),
                            direct_residual=peak(bank["einstein"][address]-phys),riemann_step=peak(rr-bank["coarse_finite"][address]),
                            ricci_focusing=abs(np.trace(tide)-trace_expected),newton_dust=peak(tide-newton) if case>=2 else "",
                            newton_trace_difference=(np.trace(tide-newton)).real,density=phys[0,0].real))
                    comparison.append(dict(level=level,case=case,time=at,mode=wid+1,
                        riemann=peak(one["finite"][address]-two["finite"][address]),
                        direct_riemann=peak(one["riemann"][address]-two["riemann"][address]),
                        metric=peak(one["metric"][address]-two["metric"][address])))
                for gauge,bank in zip(("harmonic","synchronous"),banks,strict=True):
                    def dif(name,start=0):return bank[name][tid,start,wid]-bank[name][tid,start+1,wid]
                    tide=-dif("finite")[0,1:,0,1:];phys=dif("source");geo=dif("finite_einstein")
                    current=-geo[0,1:]@az
                    tensor=trans@tide@az;vector=line@tide@az
                    stress=phys[1:,1:]
                    metric=trans@dif("metric")[1:,1:]@az
                    probes.append(dict(level=level,gauge=gauge,time=at,mode=wid+1,cross_tide=tensor.imag,
                        cross_stress=(trans@stress@az).imag,vector_tide=vector.imag,vector_stress=(line@stress@az).imag,
                        vector_slip=abs(vector-line@stress@az),geometric_current=current.real,
                        matter_current=(-phys[0,1:]@az).real,phase_error=max(abs(tensor.real),abs(vector.real),abs(current.imag)),
                        tensor_history=metric.imag,newton_density_difference=abs(phys[0,0])))
                    if weq and (float(wave[0]),float(at)) in eq:
                        saved=eq[wave[0],at]
                        for channel,measured,expected,limit in (
                            ("tide",tensor.imag,float(saved["tidal_acceleration_over_i_kappa_ABF"]),2e-8),
                            ("stress",(trans@stress@az).imag,float(saved["stress_over_iABF"]),5e-8),
                            ("metric",metric.imag,float(saved["metric_over_i_kappa_ABF_L2"]),5e-8)):
                            frozen_rows.append(dict(level=level,gauge=gauge,time=at,mode=wid+1,channel=channel,measured=measured,expected=expected,
                                absolute_error=abs(measured-expected),relative_error="",limit=limit,inside=abs(measured-expected)<=limit))
                    if key in ob and wave[1]==0:
                        expected=float(ob[key]["momentum_y_over_ABF"]);measured=current.real
                        delta=abs(measured/expected-1)
                        frozen_rows.append(dict(level=level,gauge=gauge,time=at,mode=wid+1,channel="oblique_geometric_current",measured=measured,
                            expected=expected,absolute_error=abs(measured-expected),relative_error=delta,limit=2e-5,inside=delta<=2e-5))
                    if gauge=="harmonic":
                        other=-dif("finite",4)[0,1:,0,1:]
                        discrepancy=dif("finite_einstein",4)-dif("source",4)
                        rejections.append(dict(level=level,time=at,mode=wid+1,
                            bad_constraint=peak(discrepancy[0]),bad_einstein=peak(discrepancy),
                            bad_gauge=peak(dif("gauge",4)),good_constraint=peak(geo[0]-phys[0]),
                            tensor_change=abs(trans@(other-tide)@az),actual_current=abs(current)))
    for name,rows in (("metric-checks",states),("two-gauge-comparison",comparison),("tidal-modes",probes),
                      ("missing-current-control",rejections),("frozen-predictions",frozen_rows)):
        table(name+".csv",rows)
    return states,comparison,probes,rejections,frozen_rows

def maxkey(array,key):return max(float(row[key]) for row in array if row[key]!="")

def run():
    lock();algebra();raw=sources()
    states,cross,probes,rejections,predictions=metrics()
    for records,keys in ((raw,("individual_continuity","differential_density","coarse_fine")),
                         (states,("einstein","constraint","gauge_residual","riemann_step","newton_dust","ricci_focusing")),
                         (cross,("riemann","metric")),(probes,("vector_slip","phase_error")),
                         (rejections,("bad_constraint","tensor_change"))):
        print({key:maxkey(records,key) for key in keys})
    print("frozen failures",[(row["level"],row["gauge"],row["time"],row["mode"],row["channel"],row["absolute_error"]) for row in predictions if not row["inside"]][:10])
    assert maxkey(raw,"differential_density")<1e-12 and maxkey(raw,"longitudinal_current")<1e-12 and maxkey(raw,"trace")<1e-12
    assert maxkey(raw,"coarse_fine")<5e-8 and maxkey(raw,"individual_continuity")<2e-8
    assert max(maxkey(states,key) for key in ("einstein","constraint","gauge_residual","newton_dust","ricci_focusing","riemann_step"))<2e-8
    assert maxkey(cross,"riemann")<2e-8 and maxkey(cross,"metric")>.1
    assert maxkey(probes,"vector_slip")<2e-8 and maxkey(probes,"phase_error")<2e-8
    assert len(predictions)==228 and all(row["inside"] for row in predictions)
    assert maxkey(rejections,"bad_constraint")>.001 and maxkey(rejections,"bad_gauge")>.001 and maxkey(rejections,"tensor_change")<2e-8
    print("both unprojected evolutions and all nonzero frozen targets passed")

if __name__=="__main__":run()
