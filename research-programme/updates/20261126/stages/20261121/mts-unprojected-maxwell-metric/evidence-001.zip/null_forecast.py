from scope import HERE,WAVES,lock,sha,json_file,table,np
from width_forecast import one

def critical(size):
    return np.sqrt(4/(np.sqrt(size**4+16)+size**2))

def prepare():
    parent=lock()
    if not (HERE/"null-freeze.json").exists():assert not (HERE/"source-critical.npz").exists()
    width=critical(1.)
    rows=[]
    for wid,wave in enumerate(WAVES[1:]):
        lower,higher=one(wave,width,28),one(wave,width,36)
        for first,second in zip(lower,higher,strict=True):
            assert max(abs(first[key]-second[key]) for key in ("current","stress_tt","tide_vector","tide_tt","metric_tt"))<5e-8
            if abs(np.linalg.norm(wave)-1)<1e-13 and second["time"]==0:
                assert abs(second["tide_tt"])<1e-13
            rows.append(dict(mode=wid+1,width=width,**second))
    table("critical-forecast.csv",rows)
    json_file("null-freeze.json",dict(parent=parent,width=width,method=sha(HERE/"null_forecast.py"),design=sha(HERE/"NULL-DESIGN.md"),
        width_method=sha(HERE/"width_forecast.py"),output=sha(HERE/"critical-forecast.csv")))
    print("frozen",sha(HERE/"null-freeze.json"),width)

if __name__=="__main__":prepare()
