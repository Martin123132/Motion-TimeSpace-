"""Score only after the metric solutions exist; never feed a projected forecast into either solver."""
from scope import HERE,WAVES,CLOCKS,LEVELS,PARENT,sha,lock,np,table,read
from width_forecast import dust_density,WIDTHS
from measure import frame,frozen,peak
from numpy.polynomial.chebyshev import chebval,chebder

def run():
    lock();assert sha(HERE/"width-freeze.json")=="af502adb8c21c41db09fe374716c50c912439b33dcb645c173820fd8a2718c0d"
    import json
    assert sha(HERE/"width-forecast.csv")==json.loads((HERE/"width-freeze.json").read_bytes())["forecast"]
    future={(row["preparation"],int(row["mode"]),float(row["time"])):row for row in read(HERE/"width-forecast.csv")}
    eq,ob=frozen();out=[];targets=[];energies=[];checks=[];negative=[]
    for level,width in (("coarse",1.),("fine",1.),*WIDTHS.items()):
        outputs=[]
        for name in ("harmonic","synchronous"):
            with np.load(HERE/(name+"-"+level+".npz")) as data:original={key:data[key] for key in data.files}
            with np.load(HERE/("increments-"+name+"-"+level+".npz")) as data:
                outputs.append((original,data["riemann"],data["einstein"]))
        with np.load(HERE/("source-"+level+".npz")) as saved:
            polynomial=saved["coefficients"]
            for at in np.unique(np.r_[CLOCKS,np.linspace(.023,1.97,21)]):
                field=chebval(at-1,polynomial);der=chebval(at-1,chebder(polynomial))
                continuity=-der[:,:,0,:]+np.einsum("ki,skij->skj",1j*WAVES,field[:,:,1:,:])
                difference=field[0]-field[1]
                energies.append(dict(level=level,time=at,energy_plus=field[0,0,0,0].real,energy_minus=field[1,0,0,0].real,
                    total_energy_error=peak(field[:,0,0,0]-1.75),total_momentum=peak(field[:,0,0,1:]),zero_mode_contrast=peak(difference[0]),
                    density_null=peak(difference[:,0,0]),current_long=peak(np.einsum("ki,ki->k",WAVES,difference[:,0,1:])),
                    continuity=peak(continuity)))
        for tid,at in enumerate(CLOCKS):
            for wid,wave in enumerate(WAVES[1:]):
                mode=wid+1;line,az,trans=frame(wave)
                gauge_agreement=peak(outputs[0][1][tid,:4,wid]-outputs[1][1][tid,:4,wid])
                for gauge,(base,curve,einstein) in zip(("harmonic","synchronous"),outputs,strict=True):
                    tensor=base["source"][tid,:,wid];metric=base["metric"][tid,:,wid]
                    grav=einstein[tid,:,wid];curv=curve[tid,:,wid]
                    tide=-curv[:,0,1:,0,1:]
                    diff=tide[0]-tide[1];source=tensor[0]-tensor[1]
                    cross=trans@diff@az;vector=line@diff@az
                    matter=-source[0,1:]@az;current=-(grav[0,0,1:]-grav[1,0,1:])@az
                    hcross=trans@(metric[0,1:,1:]-metric[1,1:,1:])@az
                    base_dust=-line@tide[2]@line
                    reference=dust_density(wave,width)
                    assert abs(base_dust)>1e-6
                    ratio=cross.imag/base_dust.real
                    out.append(dict(level=level,gauge=gauge,time=at,mode=mode,dust_long=base_dust.real,
                        analytic_dust=reference/2,normalized_cross_tide=ratio,cross_tide=cross.imag,
                        instantaneous_stress=(trans@source[1:,1:]@az).imag,vector_tide=vector.imag,
                        geometric_current=current.real,physical_current=matter.real,metric_tt=hcross.imag))
                    assert peak(tensor[2:4,0,1:])+peak(tensor[2:4,1:,1:])==0
                    identity=np.max(abs(tide[2:4]+reference*np.outer(line,line)/2))
                    constraint=peak(grav[:4,0,:]-tensor[:4,0,:])
                    checks.append(dict(level=level,gauge=gauge,time=at,mode=mode,whole_tensor_gauge_agreement=gauge_agreement,
                        actual_metric_difference=peak(outputs[0][0]["metric"][tid,:4,wid]-outputs[1][0]["metric"][tid,:4,wid]),
                        full_einstein=peak(grav[:4]-tensor[:4]),constraint=constraint,individual_dust_newton=identity,
                        null_density=abs(source[0,0]),phase=max(abs(cross.real),abs(vector.real),abs(current.imag)),
                        slip=abs(vector-line@source[1:,1:]@az),dust_density_error=abs(reference-tensor[2,0,0]),
                        light_focusing=peak(np.trace(tide[:2],axis1=-2,axis2=-1)+tensor[:2,0,0]),
                        plus_minus_scalar_tidal_trace=abs(np.trace(diff))))
                    expected=[]
                    if level in WIDTHS:
                        row=future[level,mode,at]
                        for name,measured,limit in (("tide_tt",cross.imag,2e-8),("tide_vector",vector.imag,2e-8),
                            ("metric_tt",hcross.imag,5e-8),("stress_tt",(trans@source[1:,1:]@az).imag,5e-8),
                            ("current",current.real,2e-8),("normalized_tide",ratio,2e-8/(abs(reference)/2))):
                            expected.append((name,measured,float(row[name]),limit))
                        if at in (.01,.02,.04,.08) and wave[2]!=0:
                            expected.append(("early_relative_current",current.real/float(row["current"]),1.,2e-5))
                    else:
                        idx=(round(wave[0],10),round(wave[2],10),at)
                        if wave[1]==0 and idx in ob:
                            expected.append(("early_relative_current",current.real/float(ob[idx]["momentum_y_over_ABF"]),1.,2e-5))
                        if wave[1]==wave[2]==0 and (wave[0],at) in eq:
                            row=eq[wave[0],at]
                            expected.extend((("tide_tt",cross.imag,float(row["tidal_acceleration_over_i_kappa_ABF"]),2e-8),
                               ("stress_tt",(trans@source[1:,1:]@az).imag,float(row["stress_over_iABF"]),5e-8),
                               ("metric_tt",hcross.imag,float(row["metric_over_i_kappa_ABF_L2"]),5e-8)))
                        if mode==2 and at==0:expected.append(("normalization_16_over_51",ratio,16/51,2e-8))
                    for channel,actual,predicted,limit in expected:
                        inactive=abs(actual-predicted)
                        targets.append(dict(level=level,gauge=gauge,time=at,mode=mode,channel=channel,
                            actual=actual,predicted=predicted,error=inactive,limit=limit,inside=inactive<=limit))
                    if gauge=="harmonic":
                        invalid=(grav[4]-grav[5])-(tensor[4]-tensor[5]);bad=tide[4]-tide[5]
                        negative.append(dict(level=level,time=at,mode=mode,broken_einstein=peak(invalid),
                            broken_momentum_constraint=peak(invalid[0,1:]),tensor_change=abs(trans@(bad-diff)@az),
                            vector_change=abs(line@(bad-diff)@az),removed_current=abs(matter)))
    for name,rows in (("resolved-observables",out),("physical-validation",checks),("signed-forecast-comparisons",targets),
                      ("energy-and-zero-mode",energies),("rejected-current-variant",negative)):
        table(name+".csv",rows)
    def largest(rows,key):return max(row[key] for row in rows)
    print("forecasts",len(targets),"failures",sum(not row["inside"] for row in targets))
    print({key:largest(checks,key) for key in ("whole_tensor_gauge_agreement","full_einstein","constraint","individual_dust_newton","light_focusing")})
    for name in ("density_null","current_long","continuity","total_energy_error"):print(name,largest(energies,name))
    assert len(out)==len(checks)==504 and len(negative)==252 and len(targets)==1808
    assert all(row["inside"] for row in targets)
    for key in ("whole_tensor_gauge_agreement","full_einstein","constraint","individual_dust_newton","light_focusing","slip","dust_density_error","plus_minus_scalar_tidal_trace","phase"):
        assert largest(checks,key)<2e-8,key
    for key in ("density_null","current_long","zero_mode_contrast","total_momentum"):assert largest(energies,key)<1e-12,key
    for key in ("continuity","total_energy_error"):assert largest(energies,key)<2e-8,key
    assert largest(negative,"tensor_change")<2e-8 and largest(negative,"broken_momentum_constraint")>.01
    for level in ("coarse","fine",*WIDTHS):
        rows=[row for row in negative if row["level"]==level and row["mode"]==4]
        assert largest(rows,"broken_momentum_constraint")>.001
    print("all calibrated comparisons verified")

if __name__=="__main__":run()
