"""Independent, retarded coefficient forecasts from free-field momentum integrals."""
from scope import HERE,WAVES,CLOCKS,ETA,sha,lock,np,table,json_file
from width_forecast import frame
from null_forecast import critical
from wilson import source,moments
from scipy.fft import dct
from numpy.polynomial.legendre import leggauss

TARGETS={"half":1,"one":2,"two":3}

def minimal_cov(moment):
    tensor=np.zeros((4,4),complex)
    energy=np.trace(moment)/2
    tensor[0,0]=energy
    cross=moment[:3,3:]
    tensor[0,1:]=tensor[1:,0]=-np.array([cross[1,2]-cross[2,1],cross[2,0]-cross[0,2],cross[0,1]-cross[1,0]])
    tensor[1:,1:]=energy*np.eye(3)-moment[:3,:3]-moment[3:,3:]
    return tensor

def batch(wid,width,order,count):
    wave=WAVES[wid];size=np.linalg.norm(wave);line,az,trans=frame(wave)
    collected=[]
    for at in 1-np.cos(np.arange(count)*np.pi/(count-1)):
        jets=moments(wave,width,order,degree=2,at=at)
        corrected=[ETA@source(jets,wave)@ETA,minimal_cov(jets[2]+size**2*jets[0])]
        collected.append([[ (trans@cov[1:,1:]@az).imag,(line@cov[1:,1:]@az).imag,-(cov[0,1:]@az).real] for cov in corrected])
    coeff=dct(np.array(collected)[::-1],axis=0,type=1)/(count-1)
    coeff[[0,-1]]/=2
    nodes,measure=leggauss(28);rows=[]
    for time in CLOCKS:
        observed=np.polynomial.chebyshev.chebval(time-1,coeff)
        instants=(1+nodes)*time/2
        stresses=np.polynomial.chebyshev.chebval(instants-1,coeff)[:,0]
        metric=stresses@(measure*time*(time-instants)*np.sinc(size*(time-instants)/np.pi))
        for idx,label in enumerate(("weyl","gravity")):
            rows.append(dict(time=time,operator=label,stress=observed[idx,0],vector=observed[idx,1],current=observed[idx,2],
                metric=metric[idx],tidal=observed[idx,0]-size**2*metric[idx]/2))
    return rows

def prepare():
    pin=lock()
    if not (HERE/"action-freeze.json").exists():
        assert not any(HERE.glob("action-moments-*.npz"))
    rows=[]
    for label,index in TARGETS.items():
        width=critical(np.linalg.norm(WAVES[index]))
        for wid in (index,4):
            rough=batch(wid,width,24,29);fine=batch(wid,width,32,39)
            for first,second in zip(rough,fine,strict=True):
                delta=max(abs(first[key]-second[key]) for key in ("stress","vector","current","metric","tidal"))
                assert delta<5e-8,(label,wid,first["time"],delta)
                rows.append(dict(preparation=label,width=width,mode=wid,refinement=delta,**second))
    table("action-forecast.csv",rows)
    json_file("action-freeze.json",dict(parent_design=pin,design=sha(HERE/"ACTION-MATCHING.md"),method=sha(HERE/"action_forecast.py"),
        momentum=sha(HERE/"wilson.py"),forecast=sha(HERE/"action-forecast.csv"),rows=len(rows)))
    print("action history frozen",sha(HERE/"action-freeze.json"),len(rows))

if __name__=="__main__":prepare()
