"""Real, finite-aperture launch tide from one equal-width preparation. No Fourier projection."""
from itertools import product
from math import comb, factorial
from fractions import Fraction
import sympy as sp
from scope import HERE,np,table,json_file,lock
from wilson import project
from photons import radial_jet
from scipy.special import roots_hermitenorm

def response_map():
    mapping=np.zeros((4,4,6,6))
    for first,second in product(range(6),repeat=2):
        unit=np.zeros((6,6));unit[first,second]=1.
        mapping[:,:,first,second]=project(unit)[2,:,:,3]
    return mapping

def polynomials():
    xx,yy,zz=coords=sp.symbols("x y z",real=True)
    def diff(pol,index,power):return pol.diff(coords[index])-power*coords[index]*pol
    def curl(field):
        return sp.Matrix([diff(field[(i+2)%3],(i+1)%3,1)-diff(field[(i+1)%3],(i+2)%3,1) for i in range(3)])
    def lap(poly,power):return sum(diff(diff(poly,idx,power),idx,power) for idx in range(3))
    def free(electric):
        blank=sp.zeros(3,1)
        return (electric.col_join(blank),blank.col_join(-curl(electric)),electric.applyfunc(lambda poly:lap(poly,1)).col_join(blank))
    tor=free(sp.Matrix([-yy,xx,0]));pol=free(sp.Matrix([xx*zz,yy*zz,2-xx**2-yy**2]))
    jets=[sum((comb(n,j)*(tor[j]*pol[n-j].T+pol[n-j]*tor[j].T) for j in range(n+1)),sp.zeros(6,6))*2 for n in range(3)]
    mapping=response_map();photon=0
    for left,right in product(range(4),repeat=2):
        degree=int(left==0)+int(right==0)
        term=sum(sp.Rational(Fraction(mapping[left,right,aa,bb]).limit_denominator(48))*jets[degree][aa,bb]
                 for aa,bb in zip(*np.nonzero(mapping[left,right]),strict=True))
        term=sp.sympify(term)
        for index in (left,right):
            if index:term=diff(term,index-1,2)
        photon+=4*term
    nominal=-jets[0][1,2]-jets[0][4,5]
    reduced=-jets[2][1,2]-jets[2][4,5]-lap(nominal,2)
    return coords,[sp.factor(polynomial) for polynomial in (nominal,photon,reduced)]

def averages():
    coords,laws=polynomials()
    uu=sp.symbols("u",positive=True)
    def average_monomial(power,mean):
        return sum(comb(power,2*j)*sp.factorial2(2*j-1)*((1-uu)/2)**j*mean**(power-2*j) for j in range(power//2+1))
    values=[]
    for law in laws:
        entries=sp.Poly(law,*coords)
        value=sum(scale*average_monomial(xx,sp.sqrt(2*uu))*average_monomial(yy,sp.Integer(0))*average_monomial(zz,sp.Integer(0))
                  for (xx,yy,zz),scale in entries.terms())
        values.append(sp.factor(uu**sp.Rational(3,2)*sp.exp(-2)*value))
    assert values[0]==0
    ratio=sp.factor(values[1]/values[2])
    answers={name:str(value) for name,value in zip(("local_minimal","local_photon","local_gravity"),laws,strict=True)}
    answers.update({name:str(value) for name,value in zip(("minimal","weyl","gravity"),values,strict=True)})
    answers.update(ratio=str(ratio),ratio_derivative=str(sp.factor(sp.diff(ratio,uu))))
    json_file("finite-aperture-identities.json",answers)
    return [sp.lambdify(uu,value,"numpy") for value in values]

def moments(width,centre,order,at):
    nodes,weights=roots_hermitenorm(order)
    mass=np.einsum("i,j,k->ijk",weights,weights,weights).ravel()/(2*np.pi)**1.5
    displacements=np.stack(np.meshgrid(nodes,nodes,nodes,indexing="ij"),axis=-1).reshape(-1,3)
    positions=width*displacements+np.array([centre,0.,0.])
    radius=np.linalg.norm(positions,axis=1);normal=positions/radius[:,None];axis=np.array([0.,0.,1.])
    first,second,grad,hessian,grad_a=radial_jet(radius,at)
    def curl(derivative):return derivative[:,None]*np.cross(normal,axis)
    def two(derivative,curvature):
        adjusted=derivative/radius
        return (curvature-adjusted)[:,None]*normal[:,2:]*normal-(curvature+adjusted)[:,None]*axis
    tor=np.column_stack((curl(grad),-two(first,second)));pol=np.column_stack((two(grad,hessian),curl(grad_a)))
    derivative=displacements/width
    def count(left,right):
        if not (left or right):return mass
        if not left or not right:return mass*derivative[:,max(left,right)-1]
        return mass*(derivative[:,left-1]*derivative[:,right-1]-(left==right)/width**2)
    mapping=response_map()
    terms=np.zeros(3);plain=laplace=0.
    for left in range(4):
        for right in range(left,4):
            weighted=count(left,right)
            contraction=tor.T@(weighted[:,None]*pol)
            correlator=2*(contraction+contraction.T)
            vertex=mapping[left,right]+(mapping[right,left] if left!=right else 0)
            terms[int(left==0)+int(right==0)]+=4*np.sum(vertex*correlator)
            stress=-correlator[1,2]-correlator[4,5]
            if left==right==0:plain=stress
            if left==right!=0:laplace+=stress
    return np.r_[plain,laplace,terms]

def independent(width,centre,order,step):
    lo2,lo,initial,hi,hi2=[moments(width,centre,order,idx*step) for idx in (-2,-1,0,1,2)]
    first=(lo2-8*lo+8*hi-hi2)/(12*step)
    second=(-(lo2-initial)+16*(lo-initial)+16*(hi-initial)-(hi2-initial))/(12*step**2)
    return np.array([initial[0],initial[2]+first[3]+second[4],second[0]-initial[1]])

def run():
    lock();exact=averages();rows=[]
    for width in (.125,.25,.5):
        centre=np.sqrt(2+4*width**2);shape=1/(1+2*width**2)
        predictions=np.array([fn(shape) for fn in exact])
        low=independent(width,centre,18,.002)
        mid=independent(width,centre,26,.002)
        high=independent(width,centre,26,.001)
        norm=np.exp(-2)*shape**1.5
        leakage=4*norm*2*shape*shape
        offset=.0001
        displaced=[moments(width,centre+delta,26,0.)[0] for delta in (-offset,offset)]
        slope=(displaced[1]-displaced[0])/(2*offset)
        assert abs(slope/leakage-1)<1e-7
        assert abs(high[0])<1e-12
        assert max(np.max(abs(high-predictions)),np.max(abs(mid-high)))<2e-8
        rows.append(dict(width=width,centre=centre,minimal=high[0],weyl=high[1],gravity=high[2],analytic_weyl=predictions[1],
            analytic_gravity=predictions[2],coarse_spatial_change=np.max(abs(low-mid)),time_change=np.max(abs(mid-high)),
            derivative=leakage,measured_leakage=slope))
    table("finite-apertures.csv",rows)
    print(rows)

if __name__=="__main__":run()
