"""Two independent flat-metric variations; the pulse is Maxwell-on-shell, the metric probe is not."""
from itertools import product
from math import comb
from scope import HERE,WAVES,ETA,LEVELS,np,table
from width_forecast import grid,frame
from null_forecast import critical
from photons import PacketTransform

BIVECS=np.zeros((6,4,4))
for index,(aa,bb) in enumerate(((0,1),(0,2),(0,3),(2,3),(3,1),(1,2))):
    BIVECS[index,aa,bb],BIVECS[index,bb,aa]=1,-1

def raw(moment):
    return np.einsum("AB,Aij,Bkl->ijkl",moment,BIVECS,BIVECS,optimize=True)

def traceless(curvature):
    ric=np.einsum("ac,abcd->bd",ETA,curvature)
    scalar=np.sum(ric*ETA)
    def cross(left,right):
        return (np.einsum("ac,bd->abcd",left,right)-np.einsum("ad,bc->abcd",left,right)
                -np.einsum("bc,ad->abcd",left,right)+np.einsum("bd,ac->abcd",left,right))
    return curvature-cross(ETA,ric)/2+scalar*cross(ETA,ETA)/12

def project(moment):
    source=raw(moment)
    four=(source+np.einsum("abcd->acdb",source)+np.einsum("abcd->adbc",source))/3
    return traceless(source-four)

def moments(wave,width,order,degree=3,at=0.):
    shift,weights=grid(order);size2=wave@wave
    variance=width**2/(1+width**2)
    norm=width**-1.5*(2*variance)**1.5*np.exp((.25-variance/2)*size2)
    first=variance*wave+shift/np.sqrt(1+width**2);second=wave-first
    axis=np.array([0.,0.,1.])
    def fieldjets(momenta,electric):
        square=-(momenta**2).sum(axis=1)[:,None]
        if at==0.:
            base=np.column_stack((electric,0*electric))
            rate=np.column_stack((0*electric,-1j*np.cross(momenta,electric)))
        else:
            length=np.sqrt(-square)
            magnetic=-1j*np.cross(momenta,electric)*(at*np.sinc(length*at/np.pi))
            evolving=electric*np.cos(length*at)
            base=np.column_stack((evolving,magnetic))
            rate=np.column_stack((1j*np.cross(momenta,magnetic),-1j*np.cross(momenta,evolving)))
        return [(base if index%2==0 else rate)*square**(index//2) for index in range(degree+1)]
    tor=fieldjets(first,1j*np.cross(first,axis))
    pol=fieldjets(second,-width**2*np.cross(second,np.cross(second,axis)))
    jets=[]
    for index in range(degree+1):
        matrix=sum(comb(index,number)*(tor[number].T@(weights[:,None]*pol[index-number])) for number in range(index+1))
        jets.append(2*norm*(matrix+matrix.T))
    return jets

def source(jets,wave,order=0):
    fields=[project(value) for value in jets]
    output=np.zeros((4,4),complex)
    for left,right in product(range(4),repeat=2):
        derivatives=(left==0)+(right==0)
        factor=(1 if left==0 else 1j*wave[left-1])*(1 if right==0 else 1j*wave[right-1])
        output+=4*factor*fields[order+derivatives][:,left,right,:]
    assert np.max(abs(output-output.T))<1e-12
    assert abs(np.sum(ETA*output))<1e-12
    return output

def test_metric(wave,time_derivatives,polarization):
    def coefficient(pair):
        power=sum(index==0 for index in pair)
        if power!=time_derivatives:return 0
        return np.prod([1 if index==0 else -1j*wave[index-1] for index in pair])
    def dder(i,j,a,b):return coefficient((i,j))*polarization[a,b]
    riem=np.zeros((4,4,4,4),complex)
    for a,b,c,d in product(range(4),repeat=4):
        riem[a,b,c,d]=(dder(b,c,a,d)+dder(a,d,b,c)-dder(a,c,b,d)-dder(b,d,a,c))/2
    return traceless(riem)

def physical_moment(transform,wid,at,width):
    ea,ba,ep,bp=transform.field_arrays(at,width)
    tor=np.column_stack((ea,ba));pol=np.column_stack((ep,bp))
    cross=tor.T@(transform.transform[wid,:,None]*pol)
    return 2*(cross+cross.T)

def direct(transform,wid,width,spacing):
    moments_at=[physical_moment(transform,wid,offset*spacing,width) for offset in (-2,-1,0,1,2)]
    lo2,lo,init,hi,hi2=moments_at
    first=(lo2-8*lo+8*hi-hi2)/(12*spacing)
    second=(-(lo2-init)+16*(lo-init)+16*(hi-init)-(hi2-init))/(12*spacing**2)
    line,az,trans=frame(WAVES[wid])
    polarization=np.zeros((4,4));polarization[1:,1:]=np.outer(az,trans)+np.outer(trans,az)
    value=0j
    for order,matrix in enumerate((init,first,second)):
        value+=(-1)**order*np.sum(raw(matrix)*test_metric(WAVES[wid],order,polarization))
    return value

def minimal(moment,trans,az):
    return -trans@(moment[:3,:3]+moment[3:,3:])@az

def run():
    mesh=PacketTransform(*LEVELS["fine"][:4])
    rows=[]
    for wid in (1,2,3,4,5,6,7):
        wave=WAVES[wid];size=np.linalg.norm(wave);line,az,trans=frame(wave)
        for label,width in (("null",critical(size)),("matched",1.)):
            lo=moments(wave,width,4);hi=moments(wave,width,8)
            assert max(np.max(abs(left-right)) for left,right in zip(lo,hi,strict=True))<5e-12
            improvement=source(hi,wave)
            conservation=source(hi,wave,1)[0]+1j*wave@improvement[1:]
            assert np.max(abs(conservation))<5e-12
            weyl=trans@improvement[1:,1:]@az
            raw0=minimal(hi[0],trans,az);raw2=minimal(hi[2],trans,az)
            direct1=direct(mesh,wid,width,.004)
            direct2=direct(mesh,wid,width,.002)
            direct3=direct(mesh,wid,width,.001)
            assert max(abs(weyl-direct3),abs(direct3-direct2))<2e-8,(wid,label,weyl,direct2,direct3)
            assert max(abs(raw0.real),abs(raw2.real),abs(weyl.real))<2e-12
            if label=="null":assert abs(raw0)<1e-13
            assert abs(improvement[0,0])<1e-13 and np.max(abs(improvement[0,1:]))<1e-12
            rows.append(dict(mode=wid,kL=size,width=width,preparation=label,launch_stress=raw0.imag,
                stress_second=raw2.imag,tidal_quadratic_coefficient=(raw2-size**2*raw0).imag/2,
                metric_quartic_coefficient=(raw2-size**2*raw0).imag/12,weyl_photon=weyl.imag,
                curvature_squared=(raw2+size**2*raw0).imag,direct_vertex=direct3.imag,
                vertex_error=abs(weyl-direct3),coarse_change=abs(direct1-direct2),coarse_inside=abs(direct1-direct2)<2e-8,
                spacing_change=abs(direct2-direct3),conservation=np.max(abs(conservation))))
    table("wilson-launch-vertices.csv",rows)
    for row in rows[:6]:print(row["kL"],row["preparation"],row["launch_stress"],row["weyl_photon"],row["curvature_squared"])

if __name__=="__main__":run()
