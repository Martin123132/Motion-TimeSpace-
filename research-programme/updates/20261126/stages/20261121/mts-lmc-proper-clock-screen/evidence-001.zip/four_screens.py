"""Preselected 42.5-kpc screen; train the common-range null on the undriven reference only."""
import numpy as np
from scipy import constants
from scipy.special import roots_legendre
from metric import OpticalMesh,maps,local_state,TAGS,safe

DEPTHS=np.array([20.,35.,42.5,50.])
ORIGINAL=np.array([20.,-70.,0.,50.])/15


def collect(prep,order):
    op=prep["op"];mesh=OpticalMesh(op);eps=prep["eps"]
    nu=1+eps**2*prep["energy"]
    depth=DEPTHS/op["length"]
    impact=8.3/op["length"]
    breaks=np.unique(np.clip(np.r_[0.,depth,np.sqrt(np.maximum(0.,mesh.edge**2-impact**2))],0,depth[-1]))
    nodes,weights=roots_legendre(order)
    half=np.diff(breaks)/2
    height=(breaks[:-1,None]+half[:,None]*(1+nodes)).ravel()
    measures=(half[:,None]*weights).ravel()
    physical=np.zeros(4)
    slope=np.zeros((4,6))
    for begin in range(0,len(height),32):
        safe()
        section=slice(begin,begin+32);pos=height[section]
        ground,grad,element,derivative=maps(mesh,impact,pos)
        base=1j*nu*ground+eps*grad
        quadrature=eps**2*measures[section]
        physical+=((pos[None,:]<depth[:,None])*(pos[None,:]/depth[:,None])**2)@(quadrature*abs(base[:,0])**2)/op["length"]
        def read(row,field):
            return np.einsum("nm,nmh->nh",row,field)
        signals=[]
        for epoch in (-21.,0.):
            motion,vel,accel,theta,rate=local_state(prep,epoch*prep["year"]-eps*pos)
            field=read(element[0],motion)+1j*read(element[1],vel)
            field_z=read(derivative[0],motion)+1j*read(derivative[1],vel)
            dot=read(element[0],vel)+1j*read(element[1],accel)
            induced=1j*nu*field+eps*field_z-eps**2*dot+1j*theta*base-1j*eps**2*rate*ground
            signals.append(2*(base.conj()*induced).real)
        slope+=(pos*np.maximum(0,1-pos/depth[:,None])*quadrature)@((signals[1]-signals[0])/21)
    return physical,slope


def compare(coarse,fine,finite,reference):
    physical=fine[0][0]
    matrix=np.stack((np.ones(4),1/DEPTHS,physical,DEPTHS**2))
    factor=np.linalg.norm(matrix,axis=1)
    target=np.array([0,0,0,ORIGINAL@DEPTHS**2])
    coeff=np.linalg.solve(matrix/factor[:,None],target/factor)
    assert np.max(abs((matrix@coeff-target)/factor))<2e-12
    results=[]
    kms=1000*constants.parsec/1e3/(365.25*86400)
    for case,(geometry,slopes) in enumerate(fine):
        for idx,history in enumerate(TAGS):
            old=float(reference[case,history]["slow_drift"])
            original=ORIGINAL@slopes[:,idx]
            assert abs(original/old-1)<2e-5
            signal=coeff@slopes[:,idx]
            for alt in (coarse[case],finite[case]):
                assert np.max(abs(alt[0]/geometry-1))<2e-5
                assert abs(coeff@alt[1][:,idx]/signal-1)<2e-5
            leakage=coeff@geometry
            assert abs(ORIGINAL@geometry)>0
            results.append(dict(case=case,history=history,weight20=coeff[0],weight35=coeff[1],weight42p5=coeff[2],weight50=coeff[3],
                scaled_condition=np.linalg.cond(matrix/factor[:,None]),geometry_noise_ratio=np.linalg.norm(coeff)/np.linalg.norm(ORIGINAL),
                original_drift=original,four_screen_drift=signal,signal_fraction=signal/original,
                original_common_shift_per_kpc=ORIGINAL@geometry,new_common_shift_per_kpc=leakage,
                relative_common_shift=abs(leakage/(ORIGINAL@geometry)),
                most_sensitive_independent_speed_kms=min(abs(signal/(coeff*geometry)))*kms,
                common_speed_kms_matching_signal=(abs(signal/leakage)*kms if case else "nulled_by_construction")))
    return results

