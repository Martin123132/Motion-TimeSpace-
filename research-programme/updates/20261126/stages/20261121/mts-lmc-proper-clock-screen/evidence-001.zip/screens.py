"""Transfer the actual shell phasors and separate clock errors from moving screens."""
import numpy as np
from itertools import product
from scipy import constants
from scipy.optimize import brentq
from scipy.special import roots_legendre
from metric import Potentials,PathIntegral,local_state,integration,maps,EPOCHS,TAGS,safe


def phasors(prep,case,order,split,degree):
    metric=Potentials(case,prep,degree)
    path=PathIntegral(metric,order,split)
    eps=prep["eps"];op=prep["op"]
    nu=1+eps**2*prep["energy"]
    local_nu=1+eps**2*(prep["energy"]-path.oh)
    height,_,fast=integration(metric.mesh,metric.impact,order,split,2*local_nu/eps)
    basewave=np.exp(2j*eps*path.oh*height)
    measured=np.zeros((len(EPOCHS),6,4),complex)
    diagnostics=[]
    distances=np.array([20.,35.,50.])/op["length"]
    before,pieces=path.clock(distances,-10.5)
    offset=1.23
    original=path.coeff
    old_origin=path.origin
    direct=original[1].copy()
    direct[:,:,0]+=offset
    origin=old_origin[1].copy()
    origin[:,:,0]+=offset
    path.coeff=(original[0]+offset,direct,original[2])
    path.origin=(old_origin[0]+offset,origin,old_origin[2])
    path.oh+=offset
    after,shifted=path.clock(distances,-10.5)
    assert np.allclose(after,before,rtol=0,atol=2e-14)
    assert abs((prep["energy"]+offset-path.oh)-(prep["energy"]-(path.oh-offset)))<1e-13
    stamp=-10.5*prep["year"]-eps*distances[:,None]
    assert np.max(abs(shifted[0][0]-pieces[0][0]-2*offset*stamp))<5e-14
    path.coeff=original
    path.origin=old_origin
    path.oh=old_origin[0].item()
    for epoch in EPOCHS:
        hphase,pieces=path.clock(distances,epoch)
        for idx,tag in enumerate(TAGS):
            for jdx,depth in enumerate((20,35,50)):
                diagnostics.append(dict(case=case,history=tag,epoch_year=epoch,affine_kpc=depth,
                    host_lapse=eps**2*path.oh,energy_minus_host_over_c2=local_nu-1,host_path_phase=hphase[jdx],
                    direct_phase=pieces[0][0][jdx,idx],induced_metric_phase=pieces[1][0][jdx,idx],
                    partial_time_metric_phase=pieces[0][1][jdx,idx]+pieces[1][1][jdx,idx],
                    perturbation_observer_lapse=eps**2*(pieces[0][2][0,idx]+pieces[1][2][0,idx])))
    phases=[path.clock(height,epoch) for epoch in EPOCHS]
    for begin in range(0,len(height),32):
        safe()
        part=slice(begin,begin+32)
        ground,slope,element,derivative=maps(metric.mesh,metric.impact,height[part])
        base=1j*nu*ground+eps*slope
        def read(row,data):
            return np.einsum("nm,nmh->nh",row,data)
        for idx,epoch in enumerate(EPOCHS):
            host,pieces=phases[idx]
            position,velocity,acceleration,theta,rate=local_state(prep,epoch*prep["year"]-eps*height[part])
            field=read(element[0],position)+1j*read(element[1],velocity)
            grad=read(derivative[0],position)+1j*read(derivative[1],velocity)
            dot=read(element[0],velocity)+1j*read(element[1],acceleration)
            induced=2*base*(1j*nu*field+eps*grad-eps**2*dot+1j*theta*base-1j*eps**2*rate*ground)
            weighted=eps**2*fast[part]*np.exp(1j*host[part])
            disturbance=pieces[0][0][part]+pieces[1][0][part]
            measured[idx,:,0]+=weighted@(induced+1j*disturbance*base**2)
            measured[idx,:,1]+=weighted@(base**2)
            measured[idx,:,2]+=weighted@induced
            measured[idx,:,3]+=(eps**2*fast[part]*basewave[part])@induced
    slow_source=[]
    for begin in range(0,len(path.height),40):
        part=path.height[begin:begin+40]
        ground,gradient,*_=maps(metric.mesh,metric.impact,part)
        slow_source.extend((abs(1j*nu*ground+eps*gradient)**2).ravel())
    sensitivity=(eps**2/op["length"])*path.primitive_to(path.height**2*np.array(slow_source),distances)[:,0]/distances**2
    density=np.array(slow_source)
    def convergence(depth):
        return eps**2*(path.primitive_to(path.height*density,depth)[:,0]-path.primitive_to(path.height**2*density,depth)[:,0]/depth)
    delta=1e-4
    numerical=(3*convergence(distances)-4*convergence(distances-delta)+convergence(distances-2*delta))/(2*delta*op["length"])
    assert np.max(abs(numerical/sensitivity-1))<2e-5
    return measured,diagnostics,sensitivity,local_nu


def window_weights(omega):
    spacing=20/3
    angle=omega*spacing
    norm=2*spacing*(1-np.cos(angle))
    return np.array([-1,1+2*np.cos(angle),-1-2*np.cos(angle),1])/norm


def transfer(actual,nominal):
    spacing=20/3
    angle=actual*spacing
    ref=nominal*spacing
    return abs(np.sinc(actual/(2*np.pi))*2*np.sin(angle/2)*(np.cos(angle)-np.cos(ref))/(spacing*(1-np.cos(ref))))


def measure(series,omega,tuned):
    coeff=np.polynomial.polynomial.polyfit((EPOCHS[::2]+10.5)/10.5,series[::2].reshape(3,-1),2)
    def sample(epochs):
        return (np.polynomial.polynomial.polyvander((epochs+10.5)/10.5,2)@coeff).reshape(*epochs.shape,6,4)
    residual=np.max(abs(sample(EPOCHS[1::2])-series[1::2]),axis=0)
    centers=np.linspace(-20.5,-.5,4)
    nodes,weight=roots_legendre(12)
    times=centers[:,None]+nodes/2
    averages=np.einsum("ijhc,ij,j->ihc",sample(times),np.exp(-1j*omega*times),weight/2)
    notch=np.einsum("i,ihc->hc",window_weights(tuned),averages)
    return (averages[-1]-averages[0])/20,notch,residual


def tolerances(omega,strength,target):
    def leak(ratio):
        return strength*transfer(omega*ratio,omega)-abs(target)
    nearest=[]
    for endpoint in (.6,1.4):
        grid=np.linspace(1.,endpoint,201)
        index=next(idx for idx,val in enumerate(grid) if leak(val)>=0)
        lo,hi=sorted(grid[index-1:index+1])
        nearest.append(brentq(leak,lo,hi,xtol=2e-14)-1)
    weights=window_weights(omega)
    centers=np.linspace(-20.5,-.5,4)
    unit=np.sinc(omega/(2*np.pi))*weights*np.exp(-1j*omega*centers)
    sharp=max(abs(np.array(signs)@unit) for signs in product((-1,1),repeat=4))
    radius=abs(target)/(strength*sharp*omega)
    conservative=2/omega*np.arcsin(abs(target)/(2*strength*np.sum(abs(unit))))
    return *nearest,radius*365.25,conservative*365.25


def screen_rows(case,history,slow,deriv):
    coefs=np.array([20.,-70.,50.])/15
    kms=(1000*constants.parsec/1e3)/(365.25*86400)
    return [dict(case=case,history=history,screen_kpc=depth,ground_derivative_per_kpc=value,
        combined_derivative_per_kpc=weight*value,unmodelled_speed_kms_matching_signal=abs(slow/(weight*value))*kms)
        for depth,weight,value in zip((20,35,50),coefs,deriv)]

