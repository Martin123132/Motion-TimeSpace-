"""One-worker deterministic read-only replay by default. --initialize may create missing files only."""
import argparse
import csv
import io
import json
from metric import HERE,PREV,OLD,TAGS,EPOCHS,safe,restore,sha
import numpy as np
from scipy.integrate import solve_ivp,quad
from screens import phasors,measure,window_weights,transfer,tolerances,screen_rows
from four_screens import collect,compare


def controls():
    def exact(size,constant):
        def potential(time,distance):
            return size*(.35+(.23*distance+.41*time-.37*time*distance if not constant else 0.))
        def partial(distance):
            return size*(.41-.37*distance if not constant else 0)
        def rhs(affine,state):
            time,distance,energy=state
            potential_here=potential(time,distance)
            first=-energy/(1+2*potential_here)
            second=energy/np.sqrt(1-4*potential_here**2)
            return [first,second,-partial(distance)*(first**2+second**2)]
        end=1.31; origin=potential(0,0)
        ray=solve_ivp(rhs,[0,end],[0,0,np.sqrt(1+2*origin)],rtol=2e-13,atol=1e-15,method="DOP853")
        assert ray.success
        if constant:
            return abs(ray.y[0,-1]*np.sqrt(1+2*origin)+end)
        approximation=end*(1+origin)-2*quad(lambda dist:potential(-dist,dist)+(end-dist)*partial(dist),0,end)[0]
        return abs(-ray.y[0,-1]-approximation)
    wide=exact(.0008,False);narrow=exact(.0004,False)
    assert 3.95<wide/narrow<4.05 and exact(.001,True)<3e-14
    base=.092
    for freq in np.linspace(.065,.12,50):
        numerical=abs(window_weights(base)@np.exp(1j*freq*np.linspace(-20.5,-.5,4)))*abs(np.sinc(freq/(2*np.pi)))
        assert abs(numerical-transfer(freq,base))<1e-14
    return dict(affine_ode_wide_absolute=wide,affine_ode_half_absolute=narrow,second_order_ratio=wide/narrow,
                constant_clock_absolute=exact(.001,True))


def put(name,data,init):
    path=HERE/name
    if init and not path.exists():
        with path.open("xb") as handle:
            handle.write(data)
    assert path.read_bytes()==data,name


def table(name,rows,init):
    text=io.StringIO(newline="")
    writer=csv.DictWriter(text,rows[0].keys(),lineterminator="\n")
    writer.writeheader()
    writer.writerows(rows)
    put(name,text.getvalue().encode(),init)


def packed(obj):
    return (json.dumps(obj,sort_keys=True,indent=2,allow_nan=False)+"\n").encode()


def check_sources():
    pins=((PREV,"a35a533834070a4bbcb26201da342c3a99e930fa9746c644507efafe896fb871"),
          (OLD,"b0f8435970a6fff414297b5e324b7d039a4012eb08407147f0d7d97174a6edcd"))
    for folder,pin in pins:
        seal=folder/"seal.json"
        assert sha(seal)==pin
        payload=json.loads(seal.read_bytes())
        selected=payload if folder==PREV else {name:payload["files"][name] for name in ("extra-reference-mean.npz","extra-added-free2-plus-mean.npz")}
        for name,digest in selected.items():
            assert sha(folder/name)==digest,name


def run(init):
    safe();check_sources()
    tests=controls()
    with (PREV/"shell-windows.csv").open() as handle:
        reference={(int(row["case"]),row["history"]):row for row in csv.DictReader(handle)}
    assert len(reference)==12
    output=[];rays=[];screens=[];refinements=[]
    geo_coarse=[];geo_fine=[];geo_limited=[]
    for case in (0,1):
        prep=restore(case)
        coarse=phasors(prep,case,10,1,4)
        fine=phasors(prep,case,14,2,8)
        small=restore(case,-64)
        limited=phasors(small,case,14,2,8)
        geo_coarse.append(collect(prep,10))
        geo_fine.append(collect(prep,16))
        geo_limited.append(collect(small,16))
        rays.extend(fine[1])
        raw=2*(prep["eps"]**-2+prep["energy"])*prep["year"]
        omega=2*fine[3]*prep["year"]/prep["eps"]**2
        differences,notched,interpolation=measure(fine[0],omega,omega)
        _,untuned,_=measure(fine[0],omega,raw)
        for idx,tag in enumerate(TAGS):
            old=reference[case,tag]
            slow=float(old["slow_drift"])
            ground=abs(fine[0][-1,idx,1])
            previous=complex(float(old["induced_real"]),float(old["induced_imag"]))
            flat_error=abs(fine[0][-1,idx,3]-previous)/abs(previous)
            assert flat_error<2e-5
            restored=fine[0][-1,idx,0]
            frac,above,jitter,guarantee=tolerances(omega,ground,slow)
            assert abs(transfer((1+frac)*omega,omega)*ground/abs(slow)-1)<2e-10
            assert abs(transfer((1+above)*omega,omega)*ground/abs(slow)-1)<2e-10
            perturb=abs(differences[idx,0])
            notch_total=abs(notched[idx,0]+notched[idx,1])
            total=abs(differences[idx,0]+differences[idx,1])
            record=dict(case=case,history=tag,proper_period_year=2*np.pi/omega,proper_vs_coordinate_fraction=omega/raw-1,
                retained_slow_drift=slow,induced_carrier_slope=perturb,induced_slope_upper=slow+perturb,
                induced_slope_lower=slow-perturb,total_carrier_slope=total,ground_amplitude=ground,
                critical_total_coherence=abs(slow)/total,induced_amplitude=abs(restored),
                induced_complex_change_fraction=abs(restored-previous)/abs(previous),
                induced_ground_path_term=abs(restored-fine[0][-1,idx,2]),
                notch_total_slope=notch_total,notch_at_uncorrected_frequency=abs(untuned[idx,0]+untuned[idx,1]),
                frequency_fraction_low=frac,frequency_fraction_high=above,individual_jitter_days_linear=jitter,
                guaranteed_jitter_days=guarantee,withheld_induced_abs=interpolation[idx,0],
                flat_replay_relative=flat_error)
            output.append(record)
            screens.extend(screen_rows(case,tag,slow,fine[2]))
            for kind,other in (("path-time-and-spatial-quadrature",coarse),("modal-basis",limited)):
                alt,anotch,_=measure(other[0],omega,omega)
                checks=[abs(other[0][-1,idx,0]-restored)/abs(restored),abs(alt[idx,0]-differences[idx,0])/perturb,
                        np.max(abs(other[2]/fine[2]-1)),abs((anotch[idx,0]+anotch[idx,1])-(notched[idx,0]+notched[idx,1]))/abs(slow)]
                refinements.append(dict(case=case,history=tag,comparison=kind,complex_induced_relative=checks[0],
                  complex_slope_relative=checks[1],screen_derivative_relative=checks[2],notch_error_over_target=checks[3],
                  unchanged_20ppm_gate=max(checks)<2e-5))
        print("completed",case,flush=True)
    for name,rows in (("paths.csv",rays),("windows.csv",output),("geometry.csv",screens),("precision.csv",refinements)):
        table(name,rows,init)
    table("four-screens.csv",compare(geo_coarse,geo_fine,geo_limited,reference),init)
    put("geodesic-checks.json",packed(tests),init)
    if (HERE/"RESULTS.md").exists() and (HERE/"DERIVATION.md").exists():
        names=("metric.py","screens.py","four_screens.py","verify_clock.py","paths.csv","windows.csv","geometry.csv","four-screens.csv","precision.csv","geodesic-checks.json","RESULTS.md","DERIVATION.md")
        put("seal.json",packed({name:sha(HERE/name) for name in names}),init)
        print("verified",len(names),"files, seal",sha(HERE/"seal.json"))
    elif not init:
        raise ValueError("missing checkpoint notes")


if __name__=="__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--initialize",action="store_true")
    run(parser.parse_args().initialize)

