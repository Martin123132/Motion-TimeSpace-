"""Private, hash-verified sources for the ordinary feedback calculation."""
import os,sys,hashlib,json,io
from pathlib import Path
for variable in ('OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','OMP_NUM_THREADS','NUMEXPR_NUM_THREADS','BLIS_NUM_THREADS'):
    os.environ[variable]='1'
HERE=Path(__file__).resolve().parent
GAS=HERE.parent/'mts-fire-gas-exchange-20261121'
def digest(path):
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
PARENT='48f68b05cfb7d9fe370074a04836f47452f0c49bdfb6c7413a52640cfb4556fb'
assert digest(GAS/'seal.json')==PARENT
manifest=json.loads((GAS/'seal.json').read_bytes())
def pinned(name):
    path=GAS/name;assert digest(path)==manifest[name],name
    return path
for name in ('gas_stage.py','ancestry.py','material_exchange_bounds.py','live_clock.py','wave_exchange.py','metric_clock.py'):
    pinned(name)
sys.path.insert(0,str(GAS))
from live_clock import np,jf,Radial,green,basis,Launch,roots_legendre,eval_legendre,prior,legvander,table,keep,clocks,records,guard as parent_guard
from types import SimpleNamespace
from metric_clock import clock,clock_gradient
from mts_retarded_launch_io import Evolution,advance
def guard():
    parent_guard();assert not (HERE/'STOP-REQUESTED').exists()
def archive(name,**fields):
    stream=io.BytesIO();np.savez_compressed(stream,**fields);keep(HERE/name,stream.getvalue(),True)
def record(name,data):
    keep(HERE/name,(json.dumps(data,sort_keys=True,indent=2)+'\n').encode(),True)
def saved_mass():
    with np.load(prior('frozen-weights.npz')) as data:
        return (data['fine']*data['launch']).reshape(len(jf.RC),256)
