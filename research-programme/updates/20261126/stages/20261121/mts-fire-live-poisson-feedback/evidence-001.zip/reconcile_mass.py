"""Rebuild both summation orders from identical raw material rather than relaxing the mass check."""
from live_feedback_sources import *
from ancestry import hist,COUNT,PARTS,paths,frames
def run():
    old=np.zeros(COUNT+1);pieces=[old.copy() for _ in range(4)];external=[];count=0
    factor=1e10/frames(590)[0]
    for shard in range(PARTS):
        guard();indices=[];masses=[]
        for p in range(4):
            with np.load(paths(590,p)[0]) as bank:rows=bank[f'b{shard}']
            rr=rows['cell'];mm=rows['m'].astype(float)*factor;indices.append(rr);masses.append(mm)
            pieces[p]+=hist(rr,mm);external.append(mm[rr==COUNT].sum(dtype=np.longdouble));count+=len(rr)
        old+=hist(np.concatenate(indices),np.concatenate(masses))
    with np.load(pinned('gas-ledger.npz')) as gas:assert np.array_equal(gas['raw0'],old)
    for p,m in enumerate(pieces):
        with np.load(HERE/f'thermal-s590-{p}.npz') as bank:assert np.array_equal(m,bank['mass'])
    new=np.sum(pieces,axis=0);exact=float(sum(external,np.longdouble(0)))
    assert count==57075281 and max(abs(new[:-1]-old[:-1]))<5e-13*old[:-1].max()
    record('thermal-mass-reconciliation.json',dict(count=count,old_order_exact=True,new_order_exact=True,
        inner_max_Msun=float(max(abs(new[:-1]-old[:-1]))),outside_Msun=exact,
        outside_old_minus_reference_Msun=float(old[-1]-exact),outside_new_minus_reference_Msun=float(new[-1]-exact),
        outside_order_difference_Msun=float(old[-1]-new[-1]),used_outside_in_tidal_work=False))
if __name__=='__main__':guard();run()
