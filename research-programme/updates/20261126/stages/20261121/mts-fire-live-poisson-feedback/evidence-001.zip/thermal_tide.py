"""First adiabatic pressure contribution to the tidal work, using measured launch internal energies."""
from live_poisson import *
from scipy.constants import parsec,Julian_year

def check_strains():
    rng=np.random.default_rng(270035);rows=[]
    for gamma in (1.4,5/3):
        for tag,A in [('dilation',np.eye(3)),('trace_free',np.diag([1.,-.6,-.4])),('simple_shear',np.array([[0,1.,0],[0,0,0],[0,0,0]])),
                      ('tidal',rng.normal(size=(3,3)))]:
            if tag=='tidal':A=(A+A.T)/2
            exact=(gamma-1)*np.trace(A)**2+np.trace(A@A)
            eps=1e-3
            def test(h):
                f=lambda shift:np.expm1((1-gamma)*np.linalg.slogdet(np.eye(3)+shift*A)[1])/(gamma-1)
                return (f(h)+f(-h))/h**2
            numeric=(4*test(eps/2)-test(eps))/3
            assert abs(numeric-exact)<3e-8*max(abs(exact),1.)
            rows.append(dict(gamma=gamma,shape=tag,analytic=exact,finite_energy=numeric))
    table(HERE/'pressure-strain-controls.csv',rows,True)

def run(steps,order):
    guard();lab=Launch(steps);bg=lab.obj.bg;box=Radial(lab,16);unit=lab.obj.unit_myr;mass=[];energy=[]
    for p in range(4):
        name=f'thermal-s590-{p}';rr=json.loads((HERE/(name+'.json')).read_bytes())
        assert digest(HERE/(name+'.npz'))==rr['packet']
        with np.load(HERE/(name+'.npz')) as a:mass.append(a['mass']);energy.append(a['energy_mass'])
    raw=np.sum(mass,axis=0)
    with np.load(pinned('gas-ledger.npz')) as a:
        proof=json.loads((HERE/'thermal-mass-reconciliation.json').read_bytes())
        assert proof['old_order_exact'] and proof['new_order_exact'] and a['raw0'][-1]-raw[-1]==proof['outside_order_difference_Msun']
        assert np.max(abs(a['raw0'][:-1]-raw[:-1]))<5e-13*raw[:-1].max()
    raw=raw[:-1].reshape(len(jf.RC),256);raw_energy=np.sum(energy,axis=0)[:-1].reshape(raw.shape)
    with np.load(prior('frozen-weights.npz')) as a:tags=a['fine'].reshape(raw.shape)
    last=np.flatnonzero((tags*raw).sum(axis=1)>0)[-1]+1
    masssets={'raw_inner':(raw[:last],raw_energy[:last]),'represented':((raw*tags)[:last],(raw_energy*tags)[:last])}
    radii=jf.RC[:last];rr=radii[:,None]/bg.length
    val,grad,second=green(lab,box,radii/bg.length);pot=val[:,:,0];dr=grad[:,:,0];drr=second[:,:,0]
    ell=box.sell;nodes,ws=roots_legendre(order);mu=(jf.UC[:,None]+nodes*np.diff(jf.ANG)[:,None]/2).ravel();s=np.sqrt(1-mu**2)
    pol,dt=basis(ell,mu);cot=mu/s;lap=ell*(ell+1);dd=-lap[:,None]*pol-cot*dt
    sums={name:np.zeros(7) for name in masssets};maxtrace=0;trace_scale=0
    for i in range(0,last,32):
        guard();sl=slice(i,min(i+32,last));r=rr[sl];u=pot[sl];ur=dr[sl]
        ar=-(ur@pol)*bg.length/unit**2;at=-(u@dt)/r*bg.length/unit**2
        hhrr=(drr[sl]@pol)/unit**2
        hhrt=((ur@dt)/r-(u@dt)/r**2)/unit**2
        hhtt=((ur@pol)/r+(u@dd)/r**2)/unit**2
        hhpp=((ur@pol)/r+(u@dt)*cot/r**2)/unit**2
        tr=hhrr+hhtt+hhpp
        direct=(drr[sl]@pol+2*(ur@pol)/r-(u*lap)@pol/r**2)/unit**2
        maxtrace=max(maxtrace,np.max(abs(tr-direct)));trace_scale=max(trace_scale,np.max(abs(tr)))
        dev=(hhrr-tr/3)**2+(hhtt-tr/3)**2+(hhpp-tr/3)**2+2*hhrt**2
        scalar=[ar**2+at**2,tr**2,dev]
        av=[x.reshape(len(r),256,order)@(ws/2) for x in scalar]
        for name,(mass0,e0) in masssets.items():
            wm=mass0[sl];we=e0[sl]
            sums[name]+=np.array([np.sum(wm*av[0]),np.sum(we*av[1]),np.sum(we*av[2]),wm.sum(),we.sum(),
                np.sum(wm*av[1]),np.sum(wm*av[2])])
    assert maxtrace<1e-9*trace_scale
    rows=[];conversion=(1e6*Julian_year/parsec)**2
    for name,(kin,compression,shear,m,energy,compmass,shearmass) in sums.items():
        for gamma in (1.4,5/3):
            vol=(gamma-1)*(gamma-2/3)*compression*conversion;dev=(gamma-1)*shear*conversion
            positive=vol+dev;ratio=positive/kin
            rows.append(dict(resolution=steps,angular_order=order,material=name,gamma=gamma,outer_kpc=jf.EDGES[last],
                gas_Msun=m,mean_u_kms2=energy/m,pressure_assumption='p_over_rho=(gamma-1)*tabulated_specific_u',
                squared_accel_mass=kin,pressure_shear=dev,pressure_compression=vol,pressure_hessian=positive,
                rate_Myr_minus2=ratio,shear_fraction=dev/positive,quarter_probe_relative_term=.24**2*ratio/12,
                interval_relative_term=clocks()[1]**2*ratio/12,one_percent_Taylor_scale_Myr=np.sqrt(.12/ratio),
                trace_identity_relative=maxtrace/trace_scale))
    table(HERE/f'thermal-tide-{steps}-{order}.csv',rows,True)
    print('adiabatic work',steps,order,flush=True)
if __name__=='__main__':
    check_strains()
    for cfg in ((64,4),(32,4),(64,2)):run(*cfg)
