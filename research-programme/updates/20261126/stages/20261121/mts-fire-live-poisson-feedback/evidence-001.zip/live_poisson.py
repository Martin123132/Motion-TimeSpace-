"""Open-boundary Poisson field of axisymmetric displaced parcels and its launch derivative."""
from live_feedback_sources import *

DEGREES=np.arange(0,65,2)
LIGHT=299792.458
OBSERVER_R=np.hypot([6.,8.3],1.5)
OBSERVER_MU=1.5/OBSERVER_R

def source_grid(lab,targets,spread,angular):
    weights=saved_mass();use=weights.sum(axis=1)>0
    if spread:
        cuts=np.unique(np.r_[jf.EDGES,targets[(targets>0)&(targets<jf.EDGES[-1])]])
        low,high=cuts[:-1],cuts[1:];index=np.searchsorted(jf.EDGES,(low+high)/2)-1
        valid=use[index];index=index[valid];low=low[valid];high=high[valid];nodes,rule=roots_legendre(spread)
        rad=(low[:,None]+(1+nodes)*(high-low)[:,None]/2).ravel()
        fractions=((high-low)[:,None]*rule/(2*np.diff(jf.EDGES)[index,None])).ravel()
        weights=weights[np.repeat(index,spread)]*fractions[:,None]
    else:rad=jf.RC[use];weights=weights[use]
    nodes,rule=roots_legendre(angular);mu=(jf.UC[:,None]+nodes*np.diff(jf.ANG)[:,None]/2).ravel()
    mass=(weights[:,:,None]*rule/2).reshape(len(rad),len(mu))
    assert abs(mass.sum()/saved_mass().sum()-1)<2e-13
    return rad,mu,mass

def acceleration(lab,rad,mu):
    box=Radial(lab,16);bg=lab.obj.bg;results={}
    harmonic,theta=basis(box.sell,mu)
    for arm,vector in lab.initial.items():
        data=SimpleNamespace(obj=lab.obj,initial=dict(zero=vector*0,self=vector),run=lab.run)
        val,grad,_=green(data,box,rad/bg.length)
        unit=-bg.length/lab.obj.unit_myr**2
        results[arm]=(unit*(grad[:,:,0]@harmonic),unit*(val[:,:,0]@theta)/(rad[:,None]/bg.length))
    return results

def analytic(rad,mu,mass,acc,target):
    pol,theta=basis(DEGREES,mu);norm=np.sqrt(2*DEGREES[:,None]+1)
    radial=(mass*acc[0])@(pol/norm).T;angular=(mass*acc[1])@(theta/norm).T
    interior=rad[None,:]<target[:,None]
    scale=1/np.maximum(rad[None,:],target[:,None]);ratio=np.minimum(rad[None,:],target[:,None])*scale
    square=ratio**2;kernel=scale.copy();coeff=np.empty((len(target),len(DEGREES)))
    for index,degree in enumerate(DEGREES):
        first=np.where(interior,degree,-(degree+1))
        coeff[:,index]=-jf.ls.G*((kernel*first)@(radial[:,index]/rad)+kernel@(angular[:,index]/rad))
        kernel*=square
    return coeff

def multipoles(radius,mu,mass,targets):
    """Accumulate exact interior/exterior Green moments in target-separated intervals."""
    assert targets[0]>0 and np.all(np.diff(targets)>0) and np.min(radius)>0
    count=len(targets);group=np.searchsorted(targets,radius)
    lower=np.r_[0.,targets][group];upper=np.r_[targets,np.inf][group]
    wi=mass/upper;wo=mass/radius;qi=(radius/upper)**2;qo=(lower/radius)**2
    ratio=targets[:-1]/targets[1:];res=np.empty((count,len(DEGREES)))
    old=np.ones(len(radius));current=mu.copy()
    for degree in range(DEGREES[-1]+1):
        if degree==0:poly=old
        elif degree==1:poly=current
        else:old,current=current,((2*degree-1)*mu*current-(degree-1)*old)/degree;poly=current
        if degree%2:continue
        inner=np.bincount(group,weights=wi*poly,minlength=count+1)[:-1].copy()
        outer=np.bincount(group,weights=wo*poly,minlength=count+1)[1:].copy()
        forward=ratio**(degree+1);backward=ratio**degree
        for index in range(1,count):inner[index]+=inner[index-1]*forward[index-1]
        for index in range(count-2,-1,-1):outer[index]+=outer[index+1]*backward[index]
        res[:,degree//2]=-jf.ls.G*(inner+outer)
        wi*=qi;wo*=qo
    return res

def quadrature_controls():
    r=np.array([.7,1.1,2.7,5.2]);mu=np.array([.2,.4,.8,.3]);mass=np.array([150.,71.,45.,108.])
    target=np.array([.3,.7,1.,3.,5.2,7.1]);res=multipoles(r,mu,mass,target);expected=np.zeros_like(res)
    for rs,us,weight in zip(r,mu,mass,strict=True):
        expected-=jf.ls.G*weight*(np.minimum(rs,target)[:,None]/np.maximum(rs,target)[:,None])**DEGREES/np.maximum(rs,target)[:,None]*eval_legendre(DEGREES,us)
    error=np.max(abs(res-expected))/np.max(abs(expected));assert error<2e-14
    return float(error)

def run(steps,spread,angular,direct):
    guard();lab=Launch(steps);bg=lab.obj.bg;native=bg.rad*bg.length
    target=np.unique(np.r_[native,OBSERVER_R,700.]);waveid=np.searchsorted(target,native);clockid=np.searchsorted(target,OBSERVER_R)
    eye=eval_legendre(DEGREES,OBSERVER_MU[:,None])
    def readout(coeff):return np.diff(np.sum(coeff[clockid]*eye,axis=1))[0]/LIGHT**2
    rays=legvander(bg.mu,int(DEGREES[-1]))[:,::2].T
    def sky(coeff):return coeff[waveid]@rays/bg.vel**2
    rad,mu,mass=source_grid(lab,target,spread,angular);acc=acceleration(lab,rad,mu);terms={arm:analytic(rad,mu,mass,vector,target) for arm,vector in acc.items()}
    rows=[];out=dict(target_kpc=target,source_Msun=np.array(mass.sum()),wave_radial_index=waveid,clock_radial_index=clockid)
    for arm,co in terms.items():out[arm+'_curvature']=co
    curvs={name:float(readout(co)) for name,co in terms.items()}
    curvs['paired']=curvs['coupled']-curvs['reset']
    for arm,num in curvs.items():rows.append(dict(arm=arm,time_Myr=0.,predicted_curvature=num,inferred_curvature=num,clock_change=0.,relative_error=0.,wave_grid_rms_error=0.,exterior_monopole_change=0.))
    assert max(abs(co[-1,0]) for co in terms.values())<1e-22
    if direct:
        indices=np.nonzero(mass);src=rad[indices[0]];ang=mu[indices[1]];weight=mass[indices]
        sin=np.sqrt(1-ang**2);cyl=src*sin;height=src*ang
        launch=multipoles(src,ang,weight,target)
        expected=jf.coeffs(saved_mass(),target,64)
        static_error=np.max(abs(expected-launch))/np.max(abs(launch));out['static_projection_error']=np.array(static_error)
        assert static_error<3e-6,static_error
        vector={arm:(ar[indices]*sin+at[indices]*ang,ar[indices]*ang-at[indices]*sin) for arm,(ar,at) in acc.items()}
        for t in (.48,.24,.12,.06):
            delta=.5*t*t;measured={}
            for arm,(ac,az) in vector.items():
                guard();xx=cyl+delta*ac;zz=height+delta*az;rr=np.hypot(xx,zz)
                measured[arm]=multipoles(rr,abs(zz)/rr,weight,target)-launch
            measured['paired']=measured['coupled']-measured['reset'];allterms=dict(terms,paired=terms['coupled']-terms['reset'])
            for arm,inc in measured.items():
                ref=allterms[arm];infer=readout(inc)/delta;refsky=sky(ref);tested=sky(inc)/delta
                frac=np.sqrt(np.sum(lab.prob*(tested-refsky)**2)/np.sum(lab.prob*refsky**2))
                rows.append(dict(arm=arm,time_Myr=t,predicted_curvature=curvs[arm],inferred_curvature=infer,clock_change=readout(inc),relative_error=infer/curvs[arm]-1,wave_grid_rms_error=frac,exterior_monopole_change=inc[-1,0]))
                assert abs(inc[-1,0])<1e-8
                if t==.24 and arm!='paired':out[arm+'_finite_quadratic']=inc/delta
    archive(f'fields-{steps}-{spread}-{angular}.npz',**out)
    table(HERE/f'poisson-{steps}-{spread}-{angular}.csv',rows,True)
    print('completed',steps,spread,angular,curvs,flush=True)
if __name__=='__main__':
    print('manufactured relative error',quadrature_controls(),flush=True)
    for cfg in ((64,0,4,True),(32,0,4,False),(64,2,4,False)):
        run(*cfg)
