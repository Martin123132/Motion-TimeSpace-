"""Causal return of the ordinary Poisson potential to the two saved nonlinear wave states."""
from live_poisson import *
from ancestry import hist
from material_exchange_bounds import inputs as exchange_inputs,normalize,allocate,potential

def common_change(lab):
    for name in ('gas-ledger.npz','stellar-ledger.npz','catalog-recovery.npz','catalog-recovery.csv'):
        pinned(name)
    launch,own,s,d,mis,w=exchange_inputs('fine')
    with np.load(pinned('catalog-recovery.npz')) as r:
        c0,c1,amount=r['origin'],r['destination'],r['raw']
        s,d,newmis=normalize(np.maximum(0,s[:-1]-hist(c0,amount)),np.maximum(0,d[:-1]-hist(c1,amount)))
        assert abs(mis-newmis)<1e-4
        retained=np.r_[own+hist(c1,w[c0]*amount)-launch,0.]
    inc,_=allocate(s,d,w,True);total=retained+inc
    expected=float(records(pinned('catalog-recovery.csv'))[0]['inside_rate_Msun_yr'])
    assert abs(total[:-2].sum()/(clocks()[1]*1e6)-expected)<1e-10
    return potential(lab,total)

def free_derivative(lab,state,external):
    obj=lab.obj
    field=external+obj.phi(obj.moment(state))
    return -1j*(obj.bare@state+obj.multiply(field,state)-obj.mu*state)/obj.unit_myr

def jets(lab,arm,drive):
    obj=lab.obj;state=lab.initial[arm];base=lab.run.fields[590]
    first=free_derivative(lab,state,base);unit=obj.unit_myr
    b=-1j*obj.multiply(drive,state)/(6*unit)
    field=base+obj.phi(obj.moment(state))
    jp=-1j*(obj.bare@b+obj.multiply(field,b)-obj.mu*b+obj.multiply(obj.phi(lab.run.sky_cross(obj.sky(state),b)),state))/unit
    c=(jp-.5j*obj.multiply(drive,first)/unit)/4
    grad=clock_gradient(lab,state)*1e-10;gradvel=clock_gradient(lab,first)*1e-10
    clock3=float(np.vdot(grad,b).real);clock4=float(np.vdot(grad,c).real+np.vdot(gradvel,b).real)
    raw=float(np.linalg.norm(b));physical=physicalpart(state,b)
    return b,c,dict(cubic_wave_norm=raw,cubic_without_global_phase=np.linalg.norm(physical),
        quartic_wave_norm=np.linalg.norm(c),cubic_wave_clock=clock3,quartic_wave_clock=clock4)

def physicalpart(state,change):
    return change-state*(np.vdot(state,change)/np.vdot(state,state))

def propagate(lab,solver,arm,external,drive,h,count):
    obj=lab.obj;v=lab.initial[arm].copy();mom=obj.moment(v);worst=0.;nr=np.vdot(v,v).real
    for it in range(count):
        guard();tm=(it+.5)*h
        applied=lab.run.fields[590]+(tm/clocks()[1])*external+.5*(tm**2+h**2/12.)*drive
        v,mom,_,_=advance(obj,solver,v,mom,applied,h/obj.unit_myr)
        worst=max(worst,abs(np.vdot(v,v).real/nr-1))
    assert worst<1e-10
    return v,worst

def run(steps,spread):
    guard();lab=Launch(steps);bg=lab.obj.bg;inc=common_change(lab);wave=legvander(bg.mu,64)[:,::2].T
    with np.load(HERE/f'fields-{steps}-{spread}-4.npz') as packet:
        grid=packet['wave_radial_index'];assert np.allclose(packet['target_kpc'][grid],bg.rad*bg.length,rtol=0,atol=1e-12)
        sky={arm:packet[arm+'_curvature'][grid]@wave/bg.vel**2 for arm in lab.initial}
    cases={'reset_individual':('reset',sky['reset']),'coupled_individual':('coupled',sky['coupled']),
        'coupled_differential':('coupled',sky['coupled']-sky['reset'])}
    predictions={key:jets(lab,arm,drive) for key,(arm,drive) in cases.items()}
    table(HERE/f'frozen-wave-jets-{steps}-{spread}.csv',[dict(case=key,**info) for key,(_,_,info) in predictions.items()],True)
    rows=[]
    for duration,sub in ((.48,8),(.24,8),(.12,8),(.06,8),(.24,16)) if steps==64 and spread==0 else ((.24,8),):
        h=duration/sub;solver=Evolution(lab.obj,h/lab.obj.unit_myr,lab.initial['reset'])
        free={arm:propagate(lab,solver,arm,inc,0.,h,sub)[0] for arm in lab.initial}
        for key,(arm,drive) in cases.items():
            state=lab.initial[arm];v,err=propagate(lab,solver,arm,inc,drive,h,sub);base=free[arm]
            delta=v-base;b,c,info=predictions[key];actual=physicalpart(state,delta)
            pred=physicalpart(state,b)*duration**3;pred4=pred+physicalpart(state,c)*duration**4
            clockchange=float(np.vdot(clock_gradient(lab,base+.5*delta),delta).real)*1e-10
            expected=info['cubic_wave_clock']*duration**3;expected4=expected+info['quartic_wave_clock']*duration**4
            rows.append(dict(case=key,time_Myr=duration,substeps=sub,norm_error=err,
                cubic_wave_norm_measured=np.linalg.norm(delta)/duration**3,
                nonglobal_wave_change=np.linalg.norm(actual),wave_cubic_relative_error=np.linalg.norm(actual-pred)/np.linalg.norm(pred),
                wave_quartic_relative_error=np.linalg.norm(actual-pred4)/np.linalg.norm(pred),
                induced_wave_clock=clockchange,cubic_wave_clock_prediction=expected,quartic_wave_clock_prediction=expected4,
                clock_jet_residual=clockchange-expected4))
    table(HERE/f'wave-return-{steps}-{spread}.csv',rows,True);print('wave feedback',steps,spread,flush=True)
if __name__=='__main__':
    for cfg in ((64,0),(32,0),(64,2)):run(*cfg)
