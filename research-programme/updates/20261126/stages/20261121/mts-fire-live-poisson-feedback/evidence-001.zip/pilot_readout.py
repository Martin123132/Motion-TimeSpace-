"""Matched fixed-position controls for the closed, reciprocal pilot."""
from wave_return import *
def run():
    lab=Launch(64);obj=lab.obj;duration=.24;external=lab.run.fields[590];data=[];paired=[]
    refined='--refined' in sys.argv
    for order,count in (((1,16),) if refined else ((1,4),(1,8),(2,4))):
        h=duration/count;solver=Evolution(obj,h/obj.unit_myr,lab.initial['reset']);pair={}
        for arm,v in lab.initial.items():
            fixed=v.copy();mom=obj.moment(fixed)
            for it in range(count):fixed,mom,_,_=advance(obj,solver,fixed,mom,external,h/obj.unit_myr)
            packet=np.load(HERE/f'closed-{order}-{count}-{arm}.npz')
            moved=packet['endpoint_wave'];delta=moved-fixed
            clk=np.vdot(clock_gradient(lab,fixed+delta*.5),delta).real*1e-10
            record0=records(HERE/f'closed-{order}-{count}-{arm}.csv')[-1]
            ordinary=float(record0['ordinary_clock_change']);curvature=float(record0['launch_clock_curvature'])
            data.append(dict(order=order,steps=count,arm=arm,wave_clock_change=clk,ordinary_clock_change=ordinary,
                nonglobal_wave_change=np.linalg.norm(physicalpart(fixed,delta)),total_clock_change=ordinary+clk,launch_curvature=curvature))
            pair[arm]=np.array([ordinary,clk,curvature],float)
        o,w,c=pair['coupled']-pair['reset']
        paired.append(dict(order=order,steps=count,ordinary_clock_change=o,wave_clock_change=w,total_feedback_clock_change=o+w,
            predicted_ordinary_change=.5*duration**2*c,relative_to_launch_prediction=o/(.5*duration**2*c)-1,
            inferred_ordinary_curvature=2*o/duration**2))
    ending='-refined.csv' if refined else '.csv'
    table(HERE/('control-wave'+ending),data,True);table(HERE/('control-paired'+ending),paired,True)
if __name__=='__main__':guard();run()
