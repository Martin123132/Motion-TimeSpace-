"""Work conjugacy of the actual discretized ordinary-to-wave gravitational interaction."""
from live_poisson import *

def retained_wave_moments(lab):
    bg=lab.obj.bg;leg=legvander(bg.mu,64)[:,::2];states=lab.initial
    fields={arm:lab.obj.sky(v) for arm,v in states.items()}
    densities={arm:abs(v)**2 for arm,v in fields.items()}
    densities['paired']=((fields['coupled']-fields['reset']).conj()*(fields['coupled']+fields['reset'])).real
    rows={name:lab.mesh.mscale*bg.sqrt[:,None]**2*((den*bg.aw)@leg) for name,den in densities.items()}
    for arm,v in states.items():assert abs(rows[arm][:,0].sum()/lab.mesh.mscale/np.vdot(v,v).real-1)<1e-11
    return rows

def conjugate_acc(lab,rad,mu,moments):
    bg=lab.obj.bg;r0=bg.rad*bg.length
    fac=(bg.length/(lab.obj.unit_myr*bg.vel))**2*jf.ls.G
    ratio=np.minimum(rad[:,None],r0)/np.maximum(rad[:,None],r0);kernel=1/(rad[:,None]*np.maximum(rad[:,None],r0))
    small=rad[:,None]<r0;ar=np.empty((len(rad),len(DEGREES)));at=ar.copy()
    for index,deg in enumerate(DEGREES):
        ar[:,index]=(np.where(small,deg,-(deg+1))*kernel)@moments[:,index]
        at[:,index]=kernel@moments[:,index];kernel*=ratio**2
    h,dh=basis(DEGREES,mu);norm=np.sqrt(2*DEGREES[:,None]+1)
    return fac*ar@(h/norm),fac*at@(dh/norm)

def run(steps,spread):
    guard();lab=Launch(steps);bg=lab.obj.bg;native=bg.length*bg.rad
    target=np.unique(np.r_[native,OBSERVER_R,700.]);clockid=np.searchsorted(target,OBSERVER_R);waveid=np.searchsorted(target,native)
    rad,mu,mass=source_grid(lab,target,spread,4);mom=retained_wave_moments(lab);original=acceleration(lab,rad,mu)
    original['paired']=tuple(b-a for a,b in zip(original['reset'],original['coupled'],strict=True))
    conjugate={arm:conjugate_acc(lab,rad,mu,val) for arm,val in mom.items()}
    norm=(lab.obj.unit_myr*bg.vel/bg.length)**2
    def product(left,right):return norm*np.sum(mass*(left[0]*right[0]+left[1]*right[1]))
    results=[];eye=eval_legendre(DEGREES,OBSERVER_MU[:,None])
    for name,aa in [('continuous_FE',original),('conjugate_grid',conjugate)]:
        for source,ac in aa.items():
            coeff=analytic(rad,mu,mass,ac,target)
            clockval=np.diff((coeff[clockid]*eye).sum(axis=1))[0]/LIGHT**2
            diff=tuple(x-y for x,y in zip(conjugate[source],original[source],strict=True))
            eps=np.sqrt(product(diff,diff)/product(original[source],original[source]))
            for arm,test in mom.items():
                transfer=np.sum(test*coeff[waveid]);work=product(ac,conjugate[arm]);continuous=product(ac,original[arm])
                assert abs(transfer+work)<2e-10*abs(work),(source,arm,transfer,work)
                results.append(dict(driver=name,density_source=source,wave_readout=arm,mass_Msun=mass.sum(),
                    matched_energy_curvature=transfer,opposite_force_work=work,continuous_FE_work=continuous,
                    reciprocity_relative_error=(transfer+work)/abs(work),mixed_discretization_relative_error=(transfer+continuous)/abs(continuous),
                    ordinary_clock_curvature=clockval,force_L2_difference_from_FE=eps))
    table(HERE/f'reciprocity-{steps}-{spread}.csv',results,True)
    print('work reciprocity',steps,spread,flush=True)
if __name__=='__main__':
    for cfg in ((64,0),(32,0),(64,2)):run(*cfg)
