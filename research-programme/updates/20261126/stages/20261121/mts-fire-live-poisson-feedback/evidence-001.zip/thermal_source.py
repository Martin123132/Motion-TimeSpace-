"""FIRE launch specific internal energy: exact native-index join, bounded selected-field acquisition."""
from live_feedback_sources import *
from gas_stage import source,paths,PARTS,frames,COUNT
pinned('catalog_links.py')
from catalog_links import fetch_ids
import time,datetime
def collect(part,deadline):
    name=f'thermal-s590-{part}';receipt=HERE/(name+'.json')
    if receipt.exists():
        assert digest(HERE/(name+'.npz'))==json.loads(receipt.read_bytes())['packet'];return
    path,meta=paths(590,part);pinned(f'gas/s590-{part}.json');pinned(f'gas/s590-{part}.npz')
    old=json.loads(meta.read_bytes());ids,traffic=fetch_ids(590,part,deadline)
    guard();assert time.time()<deadline
    remote=source.Remote(old['url'],65536)
    try:
        assert list(remote.id)==old['identity']
        with source.h5py.File(remote,'r') as f:
            d=f['PartType0/InternalEnergy'];assert d.shape==(len(ids),)
            remote.load_field(d);energy=d[:];checksum=hashlib.sha256(memoryview(energy)).hexdigest()
            assert np.isfinite(energy).all() and energy.min()>=0
            energy_bytes=remote.transferred
    finally:remote.close()
    count=0;tot=np.zeros(COUNT+1);mass=tot.copy();factor=1e10/frames(590)[0]
    with np.load(path) as bank:
        for k in range(PARTS):
            idx=np.flatnonzero(ids%PARTS==k);a=bank[f'b{k}'];assert np.array_equal(a['id'],ids[idx])
            raw=a['m'].astype(float)*factor;tot+=np.bincount(a['cell'],weights=raw*energy[idx],minlength=len(tot))
            mass+=np.bincount(a['cell'],weights=raw,minlength=len(tot));count+=len(a)
    assert count==old['total']
    archive(name+'.npz',energy_mass=tot,mass=mass)
    record(name+'.json',dict(url=old['url'],identity=old['identity'],field='PartType0/InternalEnergy',units='(km/s)^2',
        field_hash=checksum,particle_id_hash=old['field_sha256']['ParticleIDs'],count=count,id_network_bytes=traffic,
        energy_network_bytes=energy_bytes,minimum=float(energy.min()),maximum=float(energy.max()),packet=digest(HERE/(name+'.npz'))))
    print('specific gas energy',part,count,flush=True)
if __name__=='__main__':
    end=datetime.datetime.fromisoformat(sys.argv[1]).timestamp();assert time.time()<end<time.time()+14400
    for p in range(4):collect(p,end)
