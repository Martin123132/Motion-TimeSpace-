"""Reconcile the saved independent source, work, evolution, pressure and conservation tests."""
from live_poisson import *
import csv,re,ast
def run():
    baseline=json.loads(pinned('validation.json').read_bytes())['clock_source_launch_curvature']
    direct=records(HERE/'poisson-64-0-4.csv');assert len(direct)==15
    nominal=next(r for r in direct if r['arm']=='paired' and float(r['time_Myr'])==0)
    assert abs(float(nominal['predicted_curvature'])/baseline-1)<1e-10
    fit=[r for r in direct if r['arm']=='paired' and float(r['time_Myr'])>0]
    clock_short=abs(float(fit[-1]['relative_error']));grid_short=float(fit[-1]['wave_grid_rms_error'])
    assert clock_short<1e-4 and grid_short<1e-3 and np.all(np.diff([abs(float(r['relative_error'])) for r in fit])<0)
    for f in HERE.glob('fields-*.npz'):
        with np.load(f) as d:
            assert (np.diff(d['target_kpc'])>0).all() and d['coupled_curvature'].shape==d['reset_curvature'].shape
            assert np.isfinite(d['coupled_curvature']).all() and abs(float(d['source_Msun'])/saved_mass().sum()-1)<1e-12
    maxrecip=0.;differences=[]
    for n,spread in ((64,0),(32,0),(64,2)):
        rr=records(HERE/f'reciprocity-{n}-{spread}.csv');assert len(rr)==18
        maxrecip=max(maxrecip,max(abs(float(r['reciprocity_relative_error'])) for r in rr))
        for r in rr:
            if r['wave_readout']==r['density_source'] and r['driver']=='conjugate_grid':assert float(r['matched_energy_curvature'])<0
            if r['density_source']=='paired' and r['wave_readout']=='paired' and r['driver']=='conjugate_grid':
                differences.append(dict(grid=n,spread=spread,force_L2=float(r['force_L2_difference_from_FE']),clock=float(r['ordinary_clock_curvature'])))
        jets=records(HERE/f'frozen-wave-jets-{n}-{spread}.csv');wave=records(HERE/f'wave-return-{n}-{spread}.csv')
        assert len(jets)==3 and {r['case'] for r in jets}=={r['case'] for r in wave}
        assert all(0<float(r['cubic_without_global_phase'])<=float(r['cubic_wave_norm']) for r in jets)
        assert all(float(r['norm_error'])<1e-10 for r in wave)
    assert maxrecip<2e-10
    motions=[]
    for filename in ('guard-motion-257-193-2.csv','guard-motion-513-385-3.csv'):
        rr=records(HERE/filename);assert len(rr)==12
        end=[r for r in rr if float(r['time_Myr'])==.24]
        assert sorted(int(r['particles']) for r in end)==[460287,1471955]
        motions.append(dict(count=sum(int(r['particles']) for r in end),crossings=sum(int(r['changed_kernel_branch']) for r in end),
            leading=sum(float(r['launch_curvature']) for r in end),effective=sum(float(r['moving_effective_curvature']) for r in end),
            velocity_excess=sum(float(r['velocity_excess_over_stationary']) for r in end)))
    refinement={};wave_budget=[];cross=[]
    for arm in ('reset','coupled'):
        errors=[]
        for order,count in ((1,4),(1,8),(1,16),(2,4)):
            r=records(HERE/f'closed-{order}-{count}-{arm}.csv');last=r[-1]
            assert len(r)==count and all(int(row['step'])==i+1 for i,row in enumerate(r))
            assert all(float(row['norm_error'])<1e-10 and abs(float(row['exterior_monopole_change']))<1e-8 for row in r)
            with np.load(HERE/f'closed-{order}-{count}-{arm}.npz') as pkt:assert np.isfinite(pkt['endpoint_wave']).all()
            if order==1:errors.append(abs(float(last['relative_energy_residual'])))
            if count==16:
                wave_budget.append(float(last['wave_work_residual'])/float(last['ordinary_kinetic']))
            assert all(float(last[k])>0 for k in ('ordinary_kinetic','represented_Msun'))
        assert 0<errors[2]<errors[1]<errors[0]
        refinement[arm]=dict(errors=errors,ratios=[errors[0]/errors[1],errors[1]/errors[2]])
    paired=records(HERE/'control-paired.csv')+records(HERE/'control-paired-refined.csv')
    for r in paired:
        assert abs(float(r['total_feedback_clock_change'])-float(r['ordinary_clock_change'])-float(r['wave_clock_change']))<1e-28
        assert float(r['wave_clock_change'])<0 and abs(float(r['relative_to_launch_prediction']))<.01
    fine=paired[-1];assert int(fine['steps'])==16
    incoming=0;total=0
    for part in range(4):
        name=f'thermal-s590-{part}';meta=json.loads((HERE/(name+'.json')).read_bytes());gas=json.loads(pinned(f'gas/s590-{part}.json').read_bytes())
        assert meta['packet']==digest(HERE/(name+'.npz')) and meta['particle_id_hash']==gas['field_sha256']['ParticleIDs']
        assert meta['identity']==gas['identity'] and meta['url']==gas['url'] and meta['minimum']>=0
        total+=meta['count'];incoming+=meta['id_network_bytes']+meta['energy_network_bytes']
    assert total==57075281
    pressure=[]
    for steps,angular in ((64,4),(64,2),(32,4)):
        rows=records(HERE/f'thermal-tide-{steps}-{angular}.csv');assert len(rows)==4
        for r in rows:
            assert 0<float(r['shear_fraction'])<1 and abs(float(r['pressure_hessian'])/float(r['squared_accel_mass'])/float(r['rate_Myr_minus2'])-1)<1e-11
            assert float(r['trace_identity_relative'])<1e-9
            if r['material']=='represented' and float(r['gamma'])>1.6:pressure.append(float(r['rate_Myr_minus2']))
    controls=records(HERE/'pressure-strain-controls.csv');assert len(controls)==8
    for path in HERE.glob('*.py'):ast.parse(path.read_bytes())
    for path in HERE.glob('*.csv'):
        with path.open(newline='',encoding='utf-8-sig') as st:
            rows=list(csv.reader(st));assert len(rows)>1 and len(set(rows[0]))==len(rows[0]) and all(len(r)==len(rows[0]) for r in rows)
    for path in HERE.glob('*.md'):
        for link in re.findall(r'\]\(([^)\s]+)\)',path.read_text(encoding='utf-8')):
            if '://' not in link and link!='validation.json':assert (path.parent/link).exists(),link
    assert not list(HERE.rglob('*.work')) and not list(HERE.rglob('*.pyc'))
    record('validation.json',dict(parent=PARENT,source_clock_curvature=baseline,short_clock_relative_error=clock_short,
        short_field_rms_error=grid_short,manufactured_poisson_error=quadrature_controls(),max_reciprocity_relative_error=maxrecip,
        paired_source_grid_errors=differences,guard_velocity_controls=motions,energy_refinement=refinement,matched_wave_work_errors_at_16=wave_budget,
        finest_paired_clock_change=float(fine['total_feedback_clock_change']),finest_wave_clock_contribution=float(fine['wave_clock_change']),
        thermal_snapshot_count=total,thermal_network_bytes=incoming,represented_gamma53_tidal_rates=pressure))
    if '--seal' in sys.argv:
        for name in ('RESULTS.md','DERIVATION.md','THERMAL-WORK.md','REPLAY.md','RECIPROCAL-PILOT.md'):assert (HERE/name).exists()
        files={p.relative_to(HERE).as_posix():digest(p) for p in sorted(HERE.rglob('*')) if p.is_file() and p.name!='seal.json'}
        record('seal.json',files);print('sealed',len(files),digest(HERE/'seal.json'))
if __name__=='__main__':guard();run()
