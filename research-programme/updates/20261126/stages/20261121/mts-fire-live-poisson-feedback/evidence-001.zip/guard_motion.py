"""Measured FIRE velocity contribution to the paired ordinary clock source in the saved guard aperture."""
from live_poisson import *
from gas_stage import frames
from moment_io import input_piece
from scipy.constants import parsec, Julian_year

AXIS=frames(600)[4][-1];AXIS=AXIS/np.linalg.norm(AXIS)
BOUNDS=np.r_[4.5,OBSERVER_R,10.25]
class Interpolator:
    def __init__(self,lab,radial,angular):
        self.n=radial;self.nt=angular;self.tables=[]
        bg=lab.obj.bg;theta=np.linspace(0,np.pi/2,angular);mu=np.cos(theta);sin=np.sin(theta)
        box=Radial(lab,16);h,dh=basis(box.sell,mu)
        ph,pd=basis(DEGREES,mu);roots=np.sqrt(2*DEGREES[:,None]+1);ph/=roots;pd/=roots
        scale=-bg.length/lab.obj.unit_myr**2
        for start,finish in zip(BOUNDS[:-1],BOUNDS[1:],strict=True):
            r=np.linspace(start,finish,radial);rs=r[:,None]
            potential,grad,_=green(lab,box,r/bg.length);cols=[]
            def add(ar,at):
                cols.extend([ar*sin+at*mu,ar*mu-at*sin])
            for j in (0,1):
                fac=scale/(lab.obj.unit_myr**j)
                add(fac*(grad[:,:,j]@h),fac*(potential[:,:,j]@dh)/(rs/bg.length))
            kr=np.zeros((len(r),len(mu)));kt=np.zeros_like(kr)
            for p,um,sign in zip(OBSERVER_R,OBSERVER_MU,(-1,1),strict=True):
                term=-sign*jf.ls.G/LIGHT**2*eval_legendre(DEGREES,um)*(np.minimum(rs,p)/np.maximum(rs,p))**DEGREES/np.maximum(rs,p)
                deg=DEGREES if (start+finish)*.5<p else -(DEGREES+1)
                kr+=(term*deg/rs)@ph;kt+=(term/rs)@pd
            add(kr,kt);self.tables.append(np.stack(cols,axis=-1))
    def evaluate(self,pos,wanted):
        z=pos@AXIS;flat=pos-z[:,None]*AXIS;cyl=np.linalg.norm(flat,axis=1)
        radius=np.hypot(cyl,z);group=np.searchsorted(BOUNDS[1:-1],radius)
        assert radius.min()>=BOUNDS[0] and radius.max()<=BOUNDS[-1]
        k=(radius-BOUNDS[group])/(BOUNDS[group+1]-BOUNDS[group])*(self.n-1)
        t=np.arctan2(cyl,abs(z))*((self.nt-1)*2/np.pi)
        i=np.minimum(k.astype(int),self.n-2);j=np.minimum(t.astype(int),self.nt-2)
        k=(k-i)[:,None];t=(t-j)[:,None];val=np.empty((len(z),wanted.stop-wanted.start))
        for g,tab in enumerate(self.tables):
            sel=group==g;ii,jj=i[sel],j[sel];u,v=k[sel],t[sel]
            val[sel]=(1-u)*((1-v)*tab[ii,jj,wanted]+v*tab[ii,jj+1,wanted])+u*((1-v)*tab[ii+1,jj,wanted]+v*tab[ii+1,jj+1,wanted])
        planar=flat/np.maximum(cyl,1e-200)[:,None]
        return [val[:,col,None]*planar+val[:,col+1,None]*np.sign(z)[:,None]*AXIS for col in range(0,val.shape[1],2)],group

def run(nr,na,qorder):
    lab=Launch(64);interp=Interpolator(lab,nr,na);nodes,weights=roots_legendre(qorder);us=(nodes+1)/2;ws=(weights/2)*(1-us)
    hub,scale,_,bulk,_=frames(590);unit=1000*1e6*Julian_year/(1000*parsec)
    weights0=np.load(prior('frozen-weights.npz'))['fine'];result={}
    for phase in (0,4):
        for piece in range(4):
            guard();data,meta=input_piece(590,piece,phase)
            with data:
                pos=data['pos_kpc'];mass=data['mass_Msun'];v=data['velocity_stored'].astype(float)*np.sqrt(scale)-bulk
                header=meta['header'];hubble=.1*hub*np.sqrt(header['Omega0']/scale**3+header['OmegaLambda']+(1-header['Omega0']-header['OmegaLambda'])/scale**2)
                v=(v+pos*hubble)*unit
                for first in range(0,len(pos),60000):
                    sel=slice(first,first+60000);x=pos[sel];vel=v[sel];radius=np.linalg.norm(x,axis=1)
                    mu=np.minimum(1.,np.abs(x@frames(600)[4][-1])/radius)
                    ids=(np.searchsorted(jf.EDGES,radius,side='right')-1)*256+np.minimum((mu*256).astype(int),255)
                    mass0=mass[sel]*weights0[ids]
                    (initial,jerk,gradient),region=interp.evaluate(x,slice(0,6))
                    dot=lambda a,b:np.einsum('ij,ij->i',a,b)
                    arv=dot(initial,gradient);jrv=dot(jerk,gradient)
                    for dt in (-.24,-.12,-.06,.06,.12,.24):
                        (gg,),endgroup=interp.evaluate(x+dt*vel,slice(4,6));changed=region!=endgroup
                        response=np.zeros_like(initial)
                        for frac,weight in zip(us,ws,strict=True):
                            (force,rate),_=interp.evaluate(x+frac*dt*vel,slice(0,4));response+=weight*(force+frac*dt*rate)
                        reduced=2*dot(gg,response);frozen=arv+dt*jrv/3
                        delta=reduced-frozen;observe=dot(gg-gradient,initial)
                        key=(phase,dt);s=result.setdefault(key,np.zeros(10))
                        s+=np.array([len(x),mass0.sum(),np.sum(changed),mass0[changed].sum(),arv@mass0,
                            jrv@mass0,reduced@mass0,delta[changed]@mass0[changed],delta[~changed]@mass0[~changed],observe@mass0])
        print('measured velocity guard',nr,phase,flush=True)
    rows=[]
    for (phase,dt),v in result.items():
        n,m,cross,mc,curv,jerk,dyn,crosst,noncross,readout=v
        assert abs(dyn-(curv+dt*jerk/3+crosst+noncross))<2e-11*max(abs(curv),abs(dyn))
        rows.append(dict(phase=phase,time_Myr=dt,particles=int(n),tagged_Msun=m,changed_kernel_branch=int(cross),
            crossing_tagged_Msun=mc,launch_curvature=curv,field_only_cubic_derivative=jerk,
            moving_effective_curvature=dyn,moving_clock_change=.5*dt**2*dyn,
            velocity_excess_over_stationary=crosst+noncross,crossing_contribution=crosst,
            noncrossing_contribution=noncross,advection_of_readout=readout,other_velocity_terms=crosst+noncross-readout))
    table(HERE/f'guard-motion-{nr}-{na}-{qorder}.csv',rows,True)
if __name__=='__main__':
    for cfg in ((257,193,2),(513,385,3)):run(*cfg)
