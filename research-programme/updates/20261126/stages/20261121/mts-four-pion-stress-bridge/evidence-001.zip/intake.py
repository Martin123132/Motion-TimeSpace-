import sys
import json
import requests

from common import HERE

TABLES={"mark2-total":(22881,20617,1),"mark2-angles":(22881,20618,2),
        **{f"belle-neutral-{index}":(50151,key,index) for index,key in enumerate((43157,43158,43159,43161),1)},
        "tpc-four-charged":(3824,3631,4),"argus-four-mixed":(29853,26104,1)}


def run(online):
    for name,(record,key,number) in TABLES.items():
        file=HERE/(name+".json")
        if online:
            url=f"https://www.hepdata.net/record/data/{record}/{key}/1/"
            with requests.get(url,timeout=(8,20),stream=True) as response:
                response.raise_for_status()
                raw=response.raw.read(160001,decode_content=True)
            assert len(raw)<160001
            data=json.loads(raw)
            assert data["doi"]==f"10.17182/hepdata.{record}.v1/t{number}"
            if file.exists():
                assert json.loads(file.read_bytes())==data
            else:
                file.write_bytes(raw)
        data=json.loads(file.read_bytes())
        assert data["doi"]==f"10.17182/hepdata.{record}.v1/t{number}"
        if name.startswith("belle"):
            assert data["keywords"]["reactions"]==["GAMMA GAMMA --> PI0 PI0"]
        elif name.startswith("mark"):
            assert data["keywords"]["reactions"]==["GAMMA GAMMA --> PI+ PI-"]
        elif name.startswith("argus"):
            assert data["qualifiers"]["RE"][0]["value"]=="GAMMA GAMMA --> PI+ PI- 2PI0"
            assert min(float(row["x"][0]["value"]) for row in data["values"])==.85


if __name__=="__main__":
    run("--acquire" in sys.argv)
