import json
import re
from functools import lru_cache

from common import DECAY,HERE,MASS,NB,alpha,elastic,np,roots_legendre,rows


@lru_cache(None)
def read_wave(energy):
    return complex(model().read(energy**2)[1])


@lru_cache(None)
def model():
    return elastic.Reconstruction()


def amplitudes(energy,angle,channel,switched):
    energy2=energy**2
    velocity=np.sqrt(1-4*MASS**2/energy2)
    massratio=MASS**2/energy2
    loop=-(1+massratio*(-2*np.arctanh(velocity)+1j*np.pi)**2)/(16*np.pi**2)
    if channel=="charged":
        same=(1-velocity**2)/(1-velocity**2*angle**2)+energy2*(loop+3/(48*np.pi**2))/(2*DECAY**2)
        other=velocity**2*(1-angle**2)/(1-velocity**2*angle**2)
    else:
        same=(energy2-MASS**2)*loop/DECAY**2
        other=0.
    if switched:
        same=same+(10/3)*(read_wave(energy)-elastic.born(energy2))*(3*angle**2-1)/2
    return same,other


def angular_bin(lo,hi,zlo,zhi,channel,order,switched):
    nodes,weights=roots_legendre(order)
    energies=(hi+lo+(hi-lo)*nodes)/2
    angles=(zlo+zhi+(zhi-zlo)*nodes)/2
    sums=[]
    for energy in energies:
        same,other=amplitudes(energy,angles,channel,switched)
        angular=weights@np.broadcast_to(abs(same)**2+abs(other)**2,angles.shape)/2
        rate=(1 if channel=="neutral" else 2)*np.pi*alpha**2*NB/energy**2*np.sqrt(1-4*MASS**2/energy**2)
        sums.append(angular*rate)
    return float(weights@sums/2)


def dataset():
    values=[]
    for index in range(1,5):
        table=json.loads((HERE/f"belle-neutral-{index}.json").read_bytes())
        for label in table["qualifiers"]["SQRT(S)"]:
            low,high=map(float,re.fullmatch(r"([.\d]+)-([.\d]+) GeV",label["value"]).groups())
            if high>.8000001:
                continue
            for binrow in table["values"]:
                entry=binrow["y"][label["group"]]
                assert entry["group"]==label["group"]
                if entry["value"]=="-":
                    continue
                stat=entry["errors"][0];sys=entry["errors"][1]
                assert (stat["label"],sys["label"])==("stat","sys")
                values.append(("neutral",low,high,float(binrow["x"][0]["low"]),float(binrow["x"][0]["high"]),
                               float(entry["value"]),float(stat["symerror"]),float(sys["symerror"])))
    table=json.loads((HERE/"mark2-angles.json").read_bytes())
    for binrow in table["values"][:2]:
        low,high=[float(binrow["x"][0][label]) for label in ("low","high")]
        for iz,(label,entry) in enumerate(zip(table["qualifiers"]["ABS(COS(THETA(RF=CM)))"],binrow["y"])):
            assert abs(float(label["value"])-.1*(iz+.5))<2e-10
            values.append(("charged",low,high,iz/10,(iz+1)/10,10*float(entry["value"]),
                           10*float(entry["errors"][0]["symerror"]),None))
    return values


def run():
    results=[]
    for channel,low,high,zlo,zhi,value,stat,sys in dataset():
        control=angular_bin(low,high,zlo,zhi,channel,9,False)
        modelval=angular_bin(low,high,zlo,zhi,channel,9,True)
        check=angular_bin(low,high,zlo,zhi,channel,16,True)
        assert abs(check-modelval)<.012
        results.append(dict(channel=channel,W_lo=low,W_hi=high,z_lo=zlo,z_hi=zhi,
                            observed_nb_per_z=value,stat_nb_per_z=stat,sys_nb_per_z=sys,
                            one_loop=control,replace_D=modelval,model_minus_control=modelval-control,
                            quadrature_change=check-modelval))
    rows("angular-comparison.csv",results)
    summaries=[]
    for channel,low in sorted(set((row["channel"],row["W_lo"]) for row in results)):
        subset=[r for r in results if (r["channel"],r["W_lo"])==(channel,low)]
        total=lambda key:sum((r["z_hi"]-r["z_lo"])*r[key] for r in subset)
        sums={key:total(key) for key in ("observed_nb_per_z","one_loop","replace_D")}
        half=np.array([(r["z_hi"]-r["z_lo"]) for r in subset])
        obs=np.array([r["observed_nb_per_z"] for r in subset])
        def tv(key):
            pred=np.array([r[key] for r in subset])
            return float(np.sum(np.abs(obs/sums["observed_nb_per_z"]-pred/sums[key])*half)/2)
        summaries.append(dict(channel=channel,W_lo=low,W_hi=subset[0]["W_hi"],aperture=max(r["z_hi"] for r in subset),
                              bins=len(subset),observed_nb=sums["observed_nb_per_z"],control_nb=sums["one_loop"],
                              replace_D_nb=sums["replace_D"],shape_TV_control=tv("one_loop"),shape_TV_replace_D=tv("replace_D")))
    rows("aperture-rates.csv",summaries)
    mark=json.loads((HERE/"mark2-total.json").read_bytes())
    for row in summaries:
        if row["channel"]=="charged":
            refs=[float(v["y"][0]["value"]) for v in mark["values"] if row["W_lo"]<float(v["x"][0]["value"])<row["W_hi"]]
            assert abs(row["observed_nb"]/np.mean(refs)-1)<.05
    assert len(summaries)==12
    return dict(rows=len(results),angular_quadrature_max_nb_per_z=max(abs(r["quadrature_change"]) for r in results))
