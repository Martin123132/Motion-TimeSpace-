import csv
import hashlib
import json
import sys
from pathlib import Path

import numpy as np
from scipy.constants import alpha
from scipy.special import roots_legendre

HERE=Path(__file__).resolve().parent
OLD=HERE.parent/"mts-elastic-pion-stress-20261121"
SEAL="457d78b6d8fbf4a7af7a158684339415fa4878afa577638170a7bcea506c3049"
assert hashlib.sha256((OLD/"seal.json").read_bytes()).hexdigest()==SEAL
for filename,digest in json.loads((OLD/"seal.json").read_bytes()).items():
    assert hashlib.sha256((OLD/filename).read_bytes()).hexdigest()==digest
sys.path.insert(0,str(OLD))
import elastic

MASS=elastic.MASS
DECAY=.0924
NB=.1973269804**2*1e7
THRESH=4*MASS


def rows(name,results):
    with (HERE/name).open("w",newline="",encoding="utf8") as stream:
        writer=csv.DictWriter(stream,fieldnames=results[0])
        writer.writeheader()
        writer.writerows(results)


def save(name,result):
    (HERE/name).write_text(json.dumps(result,indent=2,allow_nan=False)+"\n",encoding="utf8")
