from itertools import product
from math import factorial, gamma

from common import DECAY,MASS,THRESH,elastic,np,roots_legendre,rows


PAIRS=((0,1,2,3),(0,2,1,3),(0,3,1,2))
METRIC=np.diag([1.,-1.,-1.,-1.])


def dot(first,second):
    return first[...,0]*second[...,0]-np.sum(first[...,1:]*second[...,1:],axis=-1)


def otimes(first,second):
    return first[...,None]*second[...,None,:]


def tracefree(mat):
    return mat-np.trace(mat,axis1=-2,axis2=-1)[...,None,None]*np.eye(3)/3


def vertices(mom, full=False):
    total=mom.sum(axis=-2)
    contact=[]
    exchanges=[]
    for ia,ib,ic,idp in PAIRS:
        first=mom[...,ia,:]+mom[...,ib,:]
        second=mom[...,ic,:]+mom[...,idp,:]
        bare=-otimes(first,second)-otimes(second,first)
        if full:
            bare+=(dot(first,second)+MASS**2)[...,None,None]*METRIC
        pole=np.zeros_like(bare)
        for leg,other in ((ia,second),(ib,second),(ic,first),(idp,first)):
            ext=mom[...,leg,:]
            virt=total-ext
            term=-otimes(ext,virt)-otimes(virt,ext)
            if full:
                term+=(dot(ext,virt)+MASS**2)[...,None,None]*METRIC
            pole-=((dot(other,other)-MASS**2)/(dot(virt,virt)-MASS**2))[...,None,None]*term
        contact.append(bare/DECAY**2)
        exchanges.append(pole/DECAY**2)
    return np.stack(contact,axis=-3),np.stack(exchanges,axis=-3)


def mass_rule(order):
    raw,weights=roots_legendre(order)
    angle=(raw+1)*np.pi/4
    return np.sin(angle)**2,weights*np.pi/4*np.sin(2*angle)


def events(energy,ma,mb,cos_a,cos_b,phi,mass):
    momentum=np.sqrt((energy**2-(ma+mb)**2)*(energy**2-(ma-mb)**2))/(2*energy)
    def pair(cluster,axis,azimuth,direction):
        boost=np.sqrt(cluster**2+momentum**2)
        rest=np.sqrt(cluster**2/4-mass**2)
        trans=rest*np.sqrt(1-axis**2)
        points=[]
        for sign in (1,-1):
            longitudinal=sign*axis*rest
            points.append(np.stack(np.broadcast_arrays(boost/2+direction*momentum*longitudinal/cluster,
                sign*trans*np.cos(azimuth),sign*trans*np.sin(azimuth),
                direction*momentum/2+boost*longitudinal/cluster),axis=-1))
        return points
    return np.stack(pair(ma,cos_a,0.,1)+pair(mb,cos_b,phi,-1),axis=-2),2*momentum/energy


def controls(mom):
    contact,pole=vertices(mom,True)
    full=contact+pole
    lowered=mom.sum(axis=-2)@METRIC
    ward=np.einsum("...i,...aij->...aj",lowered,full)
    assert np.max(abs(ward))<3e-10
    assert np.max(abs(np.einsum("...i,...aij->...aj",lowered,contact)))>1e-5
    reference=np.zeros_like(full[...,0,1:,1:])
    for leg in range(4):
        ext=mom[...,leg,:]
        virt=mom.sum(axis=-2)-ext
        reference-=2*MASS**2*otimes(ext[...,1:],ext[...,1:])/(DECAY**2*(dot(virt,virt)-MASS**2))[...,None,None]
    projected=tracefree(full[...,1:,1:])
    assert np.max(abs(projected.sum(axis=-3)-tracefree(reference)))<5e-11
    assert np.max(abs(dot(mom,mom)-MASS**2))<2e-14
    assert np.max(abs(mom.sum(axis=-2)[...,1:]))<2e-14
    explicit=0.
    for labels in product(range(3),repeat=4):
        coeff=[labels[ia]==labels[ib] and labels[ic]==labels[idp] for ia,ib,ic,idp in PAIRS]
        combined=np.einsum("a,...aij->...ij",np.array(coeff,dtype=float),projected)
        explicit+=np.sum(combined**2,axis=(-2,-1))
    flavor=6*np.sum(projected**2,axis=(-3,-2,-1))+3*np.sum(projected.sum(axis=-3)**2,axis=(-2,-1))
    assert np.allclose(explicit,flavor,rtol=2e-13,atol=2e-13)
    return np.max(abs(ward))


def integral(energy,order,mass=MASS,volume_only=False):
    nodes,mw=mass_rule(order)
    nangle=max(5,order-2)
    angular,aw=roots_legendre(nangle)
    phases=np.arange(9)*2*np.pi/9
    first,second,phi=[v.ravel() for v in np.meshgrid(angular,angular,phases,indexing="ij")]
    weights=(aw[:,None,None]*aw[None,:,None]*np.ones(len(phases))/(4*len(phases))).ravel()
    excess=energy-4*mass
    volume=0.; tensor=0.
    for node_a,weight_a in zip(nodes,mw):
        ma=2*mass+excess*node_a
        slack=excess*(1-node_a)
        for node_b,weight_b in zip(nodes,mw):
            mb=2*mass+slack*node_b
            relative=np.sqrt((1-((ma+mb)/energy)**2)*(1-((ma-mb)/energy)**2))
            weight=weight_a*weight_b*4*ma*mb*excess*slack*relative*np.sqrt(1-(2*mass/ma)**2)*np.sqrt(1-(2*mass/mb)**2)/((2*np.pi)**2*(8*np.pi)**3)
            volume+=weight
            if volume_only:
                continue
            mom,_=events(energy,ma,mb,first,second,phi,mass)
            contact,pole=vertices(mom)
            mat=tracefree((contact+pole)[...,1:,1:])
            summed=6*np.sum(mat**2,axis=(-3,-2,-1))+3*np.sum(mat.sum(axis=-3)**2,axis=(-2,-1))
            tensor+=weight*(weights@summed)/(5*factorial(4))
    return volume,tensor


def run():
    mom,_=events(.72,.315,.34,np.array([-.4,.21]),np.array([.13,.71]),np.array([.82,2.3]),MASS)
    ward=controls(mom)
    volume=integral(1.,16,0.,True)[0]
    analytic=1/(24*(4*np.pi)**5)
    assert abs(volume/analytic-1)<2e-11
    values=[]
    for energy in (THRESH+.0005,THRESH+.001,THRESH+.002,.57,.60,.65,.70,.75,.8):
        low=integral(energy,6)[1]
        vol,fine=integral(energy,9)
        momentum2=energy**2/4-MASS**2
        two=1.5*np.sqrt(1-(2*MASS/energy)**2)/(8*np.pi)*(8/3)*momentum2**2/5
        stress=abs(elastic.omega(energy**2))*(1-.01*energy**2)
        values.append(dict(W_GeV=energy,excess_GeV=energy-THRESH,phase_volume_GeV4=vol,
            spec4_LO_GeV4=fine,spec2_tree_GeV4=two,spec2_reference_GeV4=two*stress**2,
            rT_LO=np.sqrt(fine/two),rT_mixed=np.sqrt(fine/two)/stress,
            coarser_relative=low/fine-1,threshold_scaled=fine/(energy-THRESH)**5.5))
    rows("stress-norm.csv",values)
    assert max(abs(row["coarser_relative"]) for row in values)<.002
    assert abs(values[1]["threshold_scaled"]/values[0]["threshold_scaled"]-1)<.02
    threshold=(2*np.pi)**(-8)/(2*MASS)**4/8*MASS*(2*np.pi**4.5/gamma(4.5))*(2*MASS)**3.5*(29/704)*(2*MASS)**2/DECAY**4
    extrapolated=2*values[0]["threshold_scaled"]-values[1]["threshold_scaled"]
    assert abs(extrapolated/threshold-1)<3e-5
    return dict(ward=float(ward),phase_volume_relative=volume/analytic-1,threshold_exp=np.log2(values[1]["spec4_LO_GeV4"]/values[0]["spec4_LO_GeV4"]),
                threshold_coefficient_GeVminus1p5=threshold,extrapolated_to_analytic=extrapolated/threshold)


if __name__=="__main__":
    print(run())
