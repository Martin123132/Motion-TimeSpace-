"""Independent scalar closed-loop Hankel test and exterior-lens controls."""
from functools import lru_cache
import numpy as np
from scipy.integrate import quad
from scipy.special import jn_zeros, jv, k0, kve, roots_legendre
from impact import deficit, save, weight, yukawa


@lru_cache(None)
def scalar_bank(order):
    nodes, weights = roots_legendre(order)
    root = (nodes+1)/2
    speed = 1-root**2
    comp = root**2*(2-root**2)
    safe = np.maximum(speed, .09)
    leg = ((3-safe**2)*np.arctanh(safe)-3*safe)/(2*safe**3)
    series = sum(2*idx/((2*idx+1)*(2*idx+3))*speed**(2*idx) for idx in range(1, 10))
    like = comp*np.where(speed < .09, series, leg)
    return 2/np.sqrt(comp), .5*weights*root*speed**4*like


def scalar_r(near, order=240):
    masses, measure = scalar_bank(order)
    return measure@deficit(near*masses)


def closed_remainder(momentum):
    squared = momentum**2
    inv = 1/squared
    angle = np.arcsinh(momentum/2)
    return -inv*((48*inv-24)*angle**2-84+72*np.sqrt(1+4*inv)*angle)/6


def hankel(near, lobes):
    zeros = np.r_[0., jn_zeros(2, lobes)]
    nodes, weights = roots_legendre(16)
    half = np.diff(zeros)/2
    freq = zeros[:-1,None]+(1+nodes)*half[:,None]
    tail = np.sum(half*((jv(2, freq)*closed_remainder(freq/near)/freq)@weights))
    return near**2/2*(1/12-tail)


def scalar_tests():
    masses, measure = scalar_bank(240)
    assert abs(measure.sum()-1/180) < 4e-15
    assert abs(measure@(masses**2)-1/6) < 2e-8
    results = []
    for near in (.2, .6, 1., 2., 4.):
        spectral = scalar_r(near)
        fine = hankel(near, 2000)
        coarse = hankel(near, 1000)
        assert abs(fine/spectral-1) < 4e-6 and abs(fine-coarse)/spectral < 4e-6
        results.append(dict(mb=near, spectral=spectral, hankel_1000=coarse, hankel_2000=fine,
                            relative_difference=fine/spectral-1))
    for mom in (.2,.6,1.,4.,15.,120.):
        expect = measure@(masses**2/(masses**2+mom**2))
        assert abs((1/6-closed_remainder(mom))/mom**2/expect-1) < 2e-8
    assert abs(scalar_r(1.e-4)/(1.e-8/24)-1) < 1.e-4
    ratios=[]
    for near in (20., 80., 320.):
        arg = masses*near
        scaled = .5*arg**2*(kve(2, arg)*np.exp(-(masses-2)*near)
                           -4*kve(2, 2*arg)*np.exp(-(2*masses-2)*near))
        ratios.append((measure@scaled)*16*near**2/np.pi)
    assert abs(ratios[-1]-1) < .03 and np.all(np.diff(np.abs(np.array(ratios)-1))<0)
    return results, ratios


def profiles():
    nodes, weights = roots_legendre(72)
    az = np.pi*(nodes+1)
    quadw = np.outer(weights/2, weights/2)
    out = []
    for mass, rad, near in ((1., .4, 1.), (2.4, .6, 1.1), (.3, .2, 2.)):
        shell = rad*(nodes[:,None]+1)/2
        dx = near-shell*np.cos(az)
        dy = -shell*np.sin(az)
        dist = np.hypot(dx, dy)
        orient = (dx**2-dy**2)/dist**2
        avg = quadw*2*shell/rad
        logratio = np.sum(avg*near**2/dist**2*orient)
        direct = np.sum(avg*near**2/dist**2*orient*yukawa(mass*dist))
        from scipy.special import i1
        predicted = (2*i1(mass*rad)/(mass*rad))*yukawa(mass*near)
        assert abs(logratio-1)<2e-13 and abs(direct/predicted-1)<2e-13
        eval_diff = weight(np.array([mass*.1973269804]), near, rad)[0]
        assert abs(eval_diff-2*i1(mass*rad)/(mass*rad)*(yukawa(mass*near)-yukawa(2*mass*near))) < 1e-12
        out.append(dict(mass=mass, radius=rad, b=near, local_ratio=logratio, disk_yukawa=direct, analytic=predicted))
    return out


def geometry_controls():
    for near in (.4, 1., 3.):
        def potential(val):
            return (-np.log(val)-k0(val))/(2*np.pi)
        step = .0002
        second = (potential(near+step)-2*potential(near)+potential(near-step))/step**2
        first = (potential(near+step)-potential(near-step))/(2*step)
        assert abs(np.pi*near**2*(second-first/near)-deficit(near)) < 5e-7
        integrated = quad(lambda dist: 24*near**2/(dist**2+near**2)**2.5,-np.inf,np.inf)[0]
        assert abs(integrated*near**2-32)<1e-10
        nodes, weights = roots_legendre(64)
        angle = np.pi*(nodes+1)
        az = (weights/2)@np.exp(1j*(near*np.cos(angle)+2*angle))
        assert abs(az+jv(2,near)) < 2e-14
    offset = .3
    def multipole(impact):
        return .5*((impact-offset)**-2+(impact+offset)**-2)
    naive = 4*multipole(2.)-multipole(1.)
    assert abs(naive)>.2
    return naive


if __name__=="__main__":
    rows, ratios = scalar_tests()
    save("scalar-replay.csv", rows)
    save("disk-replay.csv", profiles())
    print("scaled threshold ratios",ratios,"two-source local leakage",geometry_controls())
