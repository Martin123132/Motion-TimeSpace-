"""Regenerate deterministic outputs without starting a numerical worker or writing into earlier stages."""
import csv
import hashlib
import json
import re
import sys
from pathlib import Path
import numpy as np
from impact import HERE, HC, PREV, TH, intervals, save, yukawa
from controls import geometry_controls, profiles, scalar_tests


def run():
    table = intervals(12)
    finer = intervals(18)
    keys = ("elastic_ref", "upper_window_ref", "upper_box_lo", "upper_box_hi")
    change = max(abs(row[key]/fine[key]-1) for row, fine in zip(table, finer) for key in keys)
    assert change < 1e-7
    with (PREV/"matched-gravity.csv").open(encoding="utf8") as stream:
        old = [row for row in csv.DictReader(stream) if row["quantity"] == "constant"]
    assert len(old) == 2
    for key, value in zip(keys, [old[0]["ref_GeVminus2"], old[1]["ref_GeVminus2"],
                                 old[1]["with_shared_norm_lo"], old[1]["with_shared_norm_hi"]]):
        assert abs(table[0][key]-float(value)) < 1e-16
    for row in table[1:]:
        assert row["B_fm"] == 2*row["b_fm"]
        assert (row["two_windows_conditional_lo"]>0) == (row["b_fm"]>=3.)
    binary = HERE.parent/"mts-binary-polarization-rays-20261121"/"conjunction-forecasts.csv"
    with binary.open(encoding="utf8") as stream:
        near_m = float(next(row for row in csv.DictReader(stream) if row["geometry"]=="G4945_00_DD_central")["impact_m"])
    arg = np.sqrt(TH)*near_m*1e15/HC
    log_bound_kernel = (-arg+1.5*np.log(arg)+.5*np.log(np.pi/8)+np.log1p(15/(8*arg)))/np.log(10)
    assert log_bound_kernel < -3.7e23
    moments, ratios = scalar_tests()
    disks = profiles()
    leak = geometry_controls()
    for near in (.1, .7, 3.):
        energies = np.array([.29, .4, .7])
        measure = np.array([-.0003,.00012,.0001])
        one = measure@(1-yukawa(energies*near/HC))
        two = measure@(1-yukawa(2*energies*near/HC))
        predicted = measure@(yukawa(energies*near/HC)-yukawa(2*energies*near/HC))
        for local in (-.003,0.,.0003):
            split_near = -(local+one)/near**2
            split_far = -(local+two)/(2*near)**2
            assert abs(-4*near**2*split_far+near**2*split_near-predicted)<1e-17
    save("transfer-windows.csv", table)
    save("scalar-replay.csv", moments)
    save("disk-replay.csv", disks)
    details = dict(order_12_to_18_max_relative=change, scalar_threshold_ratios=ratios,
                   nonaxisymmetric_point_weight_leakage=leak, pion_threshold_length_fm=HC/np.sqrt(TH),
                   saved_binary_b_m=near_m, asymptotic_log10_U_at_binary_b=log_bound_kernel)
    (HERE/"checks.json").write_bytes((json.dumps(details, indent=2)+"\n").encode())
    for doc in HERE.glob("*.md"):
        for link in re.findall(r"\]\(([^\s)]+)\)", doc.read_text(encoding="utf8")):
            assert link.startswith("https://") or (HERE/link).is_file(), link
    digests = {path.name:hashlib.sha256(path.read_bytes()).hexdigest() for path in sorted(HERE.iterdir())
               if path.is_file() and path.name!="seal.json"}
    seal = HERE/"seal.json"
    if sys.argv[1:] == ["--seal"]:
        with seal.open("x",encoding="utf8",newline="\n") as stream:
            stream.write(json.dumps(digests,indent=2)+"\n")
    else:
        assert not sys.argv[1:] and digests == json.loads(seal.read_bytes())
    print(len(digests), "files verified", hashlib.sha256(seal.read_bytes()).hexdigest())


if __name__=="__main__":
    run()
