"""Check numerical coverage, action matching and byte integrity without network or worker creation."""
import argparse
import json
import math
import re
from base import HERE, ROOT, PREV, PIN, ORBIT_PIN, guard, inputs, sha, read, save

def record(name):
    return json.loads((HERE/name).read_bytes())

def run(write_seal=False):
    guard()
    inputs()
    frozen=record("freeze.json")
    assert frozen["input_orbit"]==ORBIT_PIN and frozen["parent"]==PIN
    for key,name in (("design","DESIGN.md"),("model","base.py"),("predictor","forecast.py"),("conjunction","conjunction-forecasts.csv"),("phase","phase-forecasts.csv")):
        assert sha(HERE/name)==frozen[key]
    assert sha(HERE/"PROFILE-DESIGN.md")==record("profile-freeze.json")["design"]
    assert sha(HERE/"EPOCH-DESIGN.md")==record("dated-design.json")["design_sha256"]
    counts={}
    for path in HERE.glob("*.csv"):
        rows=read(path)
        assert rows and all(None not in row and None not in row.values() for row in rows)
        counts[path.name]=len(rows)
    assert counts=={"catalogue-row.csv":1,"conjunction-forecasts.csv":7,"conjunction-transfer.csv":7,"phase-forecasts.csv":180,
        "orbital-transfer.csv":180,"orbital-shoot-check.csv":9,"paired-shooting.csv":84,"weak-limit.csv":5,"shape-response.csv":9,
        "profile-injections.csv":36,"parkes-catalogue.csv":4,"parkes-headers.csv":4,"dated-transfer.csv":5,
        "epoch-windows.csv":2,"shared-coupling.csv":4}
    rays=read(HERE/"paired-shooting.csv")
    configs={(row["geometry"],row["receiver"]) for row in rays}
    assert len(configs)==7 and len({key for key,receiver in configs})==5
    assert len({(row["geometry"],row["receiver"],row["sign"],row["label"],row["step"]) for row in rays})==84
    assert {row["sign"] for row in rays}=={row["label"] for row in rays}=={"1","-1"}
    assert max(float(row["endpoint"]) for row in rays)<2e-10 and max(float(row["energy"]) for row in rays)<2e-10
    transfer=read(HERE/"conjunction-transfer.csv")
    assert all(abs(float(row["shot"])/float(row["fermat"])-1)<2e-8 for row in transfer)
    limits=read(HERE/"weak-limit.csv")
    assert [float(row["mass_fraction"]) for row in limits]==[1,.5,.25,.125,0]
    assert all(abs(float(row["shoot"])-float(row["split"]))<2e-7 for row in limits)
    assert float(limits[0]["single_step_error"])>2e-7 and abs(float(limits[-1]["true_correction"]))<1e-9
    assert {int(row["true_anomaly_deg"]) for row in read(HERE/"orbital-transfer.csv")}==set(range(0,360,2))
    phases=record("phase-summary.json")
    assert phases["projection_error"]<1e-12 and phases["maximum_shoot_disagreement"]<2e-7
    provenance=record("data-provenance.json")["source_files"]
    assert sha(HERE/"J1537+1155.fits")==provenance["census_profs.tar.gz"]["target_sha256"]
    assert record("profile-inputs.json")["summed_observations"]==6 and record("profile-inputs.json")["subintegrations"]==1
    injections=read(HERE/"profile-injections.csv")
    assert len({(row["harmonics"],row["channels"],row["angle_deg"]) for row in injections})==36
    assert all(float(row["positive"])>0>float(row["negative"]) and float(row["relative_error"])<2e-6 for row in injections)
    inventory=record("parkes-provenance.json")["products"]
    for item in inventory:
        item_path=HERE/item["local"]
        assert sha(item_path)==item["sha256"] and item_path.stat().st_size==item["retained_bytes"]<=item["object_bytes"]
    headers=read(HERE/"parkes-headers.csv")
    assert {row["project"] for row in headers}=={"P499","PX500"} and {row["inspected"] for row in headers}=={item["local"] for item in inventory}
    assert sorted(int(row["stored_rows"]) for row in headers if row["pol"]=="AABBCRCI")==[13,101]
    dated=read(HERE/"dated-transfer.csv")
    assert all(0<float(row["orientation_retained"])<=1 and float(row["quadrature_change_us"])<1e-6 for row in dated)
    for row in read(HERE/"epoch-windows.csv"):
        assert row["exposure_overlaps_half_peak"]=="False"
        native,=[other for other in dated if other["visit"]==row["visit"] and other["native"]=="True"]
        assert math.isclose(float(native["scalar_avg_us"])/float(row["native_peak_us_per_1e15_m2"]),float(row["scalar_average_over_native_peak"]),rel_tol=1e-12)
    matching=record("matching-sources.json")
    assert sha(ROOT/matching["contract"])==matching["sha256"] and matching["assumed_us_over_max_partial"]>1e45
    assert all(row["total_undetermined"]=="True" for row in read(HERE/"shared-coupling.csv"))
    for name in ("RESULTS.md","REPLAY.md"):
        for link in re.findall(r"\]\(([^()]+)\)",(HERE/name).read_text(encoding="utf8")):
            assert link.startswith("https://") or (HERE/link).is_file() or (write_seal and link=="seal.json"),link
    assert not any(path.is_dir() for path in HERE.iterdir())
    files={path.name:sha(path) for path in sorted(HERE.iterdir()) if path.name!="seal.json"}
    manifest=dict(parent=PIN,orbit=ORBIT_PIN,files=files,csv_rows=sum(counts.values()),row_counts=counts)
    if write_seal:
        save("seal.json",manifest)
    assert record("seal.json")==manifest
    print(f"{len(files)} files; {sum(counts.values())} CSV data rows; seal {sha(HERE/'seal.json')}")
if __name__=="__main__":
    parser=argparse.ArgumentParser()
    parser.add_argument("--seal",action="store_true")
    run(parser.parse_args().seal)
