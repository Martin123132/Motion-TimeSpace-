"""Transfer a single action coefficient. Never replace the open QCD term with zero."""
import json
from base import HERE, ROOT, PREV, inputs, read, sha, table, save

def run():
    inputs()
    source = ROOT/"source-intake"/"functional_rg"/"4964"/"CFF_one_LEC_calibration_contract.csv"
    contracts = {row["contract_id"]:row for row in read(source)}
    term = contracts["CFF4964_02_nonQCD_interval"]
    assert term["units"]=="m^2" and term["valid_for_numeric_CFF_claim"]=="False"
    assert "one shared c_IR"==contracts["CFF4964_03_equation_stress"]["numeric_value"]
    low,high = json.loads(term["numeric_value"])
    transfer, = [row for row in read(HERE/"conjunction-transfer.csv") if row["geometry"].endswith("central") and row["receiver"]=="infinity"]
    scale = float(transfer["corrected_s_per_m2"])
    assert low < high < 0 and scale>0
    items = []
    for row in read(PREV/"geometry-decisions.csv"):
        if row["order"]!="12" or row["inside"]!="True":
            continue
        response = float(row["W"])
        items.append(dict(exposure=row["time"],placement=row["sign"],W=response,
                          pulse_seconds_per_m2=scale, pulse_per_normalized_tide_times_inverse_Lsq=scale/response,
                          nonQCD_partial_pulse_low_s=scale*low,nonQCD_partial_pulse_high_s=scale*high,
                          total_undetermined=True))
    assert len(items)==4
    for row in items:
        for trial in (0.,low,high,1e15,-1e15):
            assert abs((row["pulse_per_normalized_tide_times_inverse_Lsq"]*row["W"])*trial-scale*trial) <= 1e-15*abs(scale*trial)
    table("shared-coupling.csv",items)
    save("matching-sources.json",dict(contract=str(source.relative_to(ROOT).as_posix()),sha256=sha(source),
                                    model="c_IR = c_nonQCD + c_QCD^r; same full-index coefficient on both sides",
                                    partial_lag_s=[scale*low,scale*high],lags_are_not_measured=True,
                                    assumed_us_over_max_partial=1e-6/(scale*abs(low))))
if __name__=="__main__":
    run()
