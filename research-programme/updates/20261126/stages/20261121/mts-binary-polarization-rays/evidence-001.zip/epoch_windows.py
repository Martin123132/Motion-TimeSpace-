"""Locate each native exposure against its own precessed orbit, without fitting pulse data."""
from base import HERE, np, read, table
from dated_transfer import elements, weak_geometry, value
from parkes_headers import metadata

def run():
    rows, params = metadata()
    dated = {row["visit"]: row for row in read(HERE/"dated-transfer.csv") if row["native"]=="True"}
    data = []
    for row in rows:
        if row["kind"]!="summed_intensity":
            continue
        reference = dated[row["project"]]
        ephem = params[row["project"]]
        period = value(ephem,"PB")*86400
        day = row["imjd"] + (row["smjd"]+row["start_offset_s"]+row["row0_mid_offset_s"])/86400
        estimate_cycles = (day-value(ephem,"T0"))*86400/period
        mid_phase = float(reference["mid_phase"])
        mid_cycles = round(estimate_cycles-mid_phase) + mid_phase
        trial = mid_cycles
        for _ in range(3):
            trial = mid_cycles + .5*value(ephem,"PBDOT")*trial**2
        mid_elapsed = trial*period
        search = np.linspace(-.5,.5,2049)*period
        _,ecc,ecc_angle,anomaly,omega = elements(ephem,mid_elapsed+search)
        center = search[np.argmax(weak_geometry(ecc,ecc_angle,anomaly,omega)[0])]
        assert abs(elements(ephem,np.array([mid_elapsed]))[0][0]-mid_phase)<1e-9
        def envelope(count):
            offsets = center + np.linspace(-.5,.5,count)*period
            phase,ecc,ecc_angle,anomaly,omega = elements(ephem,mid_elapsed+offsets)
            scalar,_ = weak_geometry(ecc,ecc_angle,anomaly,omega)
            peak = np.argmax(scalar)
            assert 0<peak<count-1
            above = scalar>=scalar[peak]/2
            transitions, = np.nonzero(np.diff(above))
            crossing = []
            for left in transitions:
                weight = (.5*scalar[peak]-scalar[left])/(scalar[left+1]-scalar[left])
                crossing.append((offsets[left]+weight*(offsets[left+1]-offsets[left]))/60)
            assert len(crossing)==2 and crossing[0]<offsets[peak]/60<crossing[1]
            return float(scalar[peak]), float(offsets[peak]/60), crossing
        coarse, fine = envelope(8193), envelope(16385)
        assert abs(coarse[0]/fine[0]-1)<2e-5 and abs(coarse[1]-fine[1])<.08
        assert max(abs(first-second) for first,second in zip(coarse[2],fine[2]))<.005
        half_duration = row["row0_seconds"]/120
        data.append(dict(visit=row["project"],native_peak_us_per_1e15_m2=fine[0],
                         peak_minutes_from_exposure_mid=fine[1], half_peak_begins_minutes_from_mid=fine[2][0],
                         half_peak_ends_minutes_from_mid=fine[2][1],exposure_half_duration_minutes=half_duration,
                         exposure_overlaps_half_peak=fine[2][0]<=half_duration and fine[2][1]>=-half_duration,
                         scalar_average_over_native_peak=float(reference["scalar_avg_us"])/fine[0]))
    table("epoch-windows.csv",data)
if __name__=="__main__":
    run()
