"""Fixed spatial endpoints; return time after subtracting a shared outgoing radial time."""
from functools import lru_cache
from base import np,guard
from scipy.integrate import solve_ivp,solve_bvp
from scipy.optimize import root_scalar
from numpy.polynomial.legendre import leggauss

def radius(angle):return 0. if angle==np.pi/2 else np.cos(angle)
def optics(uu,eta,label):
    small=eta*uu**3
    ratio=(1-8*small)/(1+16*small)
    log_der=label*((-24/(1-8*small)-48/(1+16*small))*eta*uu**2)
    return (ratio if label==1 else 1/ratio),log_der

def shoot(start,end,mu,eta,label,refine=False):
    guard()
    begin,finish=radius(start),radius(end)
    def integrate(jj,record=False):
        ww,_=optics(finish,eta,label)
        initial=-np.sqrt((1/(jj*ww))**2-(1-2*mu*finish)*finish**2/ww)
        def rhs(at,state):
            uu,vel=state[:2];ww,dlog=optics(uu,eta,label);aa=1-2*mu*uu
            accel=-dlog/(jj*ww)**2-(2*uu-6*mu*uu**2-aa*uu**2*dlog)/(2*ww)
            if record:return (vel,accel,jj/(1-jj*ww*vel))
            return (vel,accel)
        init=(finish,initial,0.) if record else (finish,initial)
        result=solve_ivp(rhs,(end,start),init,method="DOP853",rtol=3e-14 if refine else 2e-13,
                         atol=2e-15 if refine else 1.5e-14,max_step=.065 if refine else .13)
        assert result.success and result.t[-1]==start
        return result
    def residual(jj):return integrate(jj).y[0,-1]-begin
    root=root_scalar(residual,x0=1.,x1=1.0001,method="secant",xtol=8e-15,maxiter=15)
    assert root.converged and .95<root.root<1.05
    jj=root.root;sol=integrate(jj,True);uu,vel,times=sol.y
    ww,_=optics(uu,eta,label)
    err=max(abs(vel**2-(1/(jj*ww))**2+(1-2*mu*uu)*uu**2/ww))
    endpoint=abs(uu[-1]-begin)
    assert endpoint<2e-10 and err<2e-10 and min(uu)>=-1e-14 and min(1-2*mu*uu)>0
    return dict(j=jj,arrival=-times[-1],endpoint=endpoint,energy=err)

@lru_cache(None)
def stationary(start,end,mu,mesh=65):
    angles=np.linspace(start,end,mesh)
    def rhs(at,state):return np.array([state[1],3*mu*state[0]**2-state[0]])
    def bc(left,right):return np.array([left[0]-radius(start),right[0]-radius(end)])
    out=solve_bvp(rhs,bc,angles,np.array([np.cos(angles),-np.sin(angles)]),tol=2e-10 if mesh==65 else 2e-11,max_nodes=6000)
    assert out.success
    nodes,weights=leggauss(72 if mesh==65 else 96)
    uu,vel=out.sol(start+(nodes+1)*(end-start)/2)
    constants=1/np.sqrt(vel**2+(1-2*mu*uu)*uu**2)
    uend,vend=out.sol(end)
    jj=1/np.sqrt(vend**2+(1-2*mu*uend)*uend**2)
    assert max(abs(constants-jj))<2e-10
    return float(12*jj*(end-start)*(weights@uu**3)),float(jj)

def paired(start,end,mu,step,refine=False):
    rays={(sgn,mode):shoot(start,end,mu,sgn*step,mode,refine) for sgn in (1,-1) for mode in (1,-1)}
    derivative=sum(sgn*mode*value["arrival"] for (sgn,mode),value in rays.items())/(2*step)
    return derivative,rays
