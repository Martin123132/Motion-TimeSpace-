import csv
import hashlib
import io
import json
import tarfile
from urllib.request import Request,urlopen
from base import HERE,sha,save,put,table,guard

URL="https://zenodo.org/api/records/5347875"
FILES={"MPTA_Census_Out.csv":(94367,"6bc3a5739feb50eb2a78cee845c3c842"),
       "census_profs.tar.gz":(11165896,"a235352a95766d9abffb1c54aa97305b")}
def fetch(url,limit):
    with urlopen(Request(url,headers={"User-Agent":"MTS-research/1.0"}),timeout=35) as stream:data=stream.read(limit+1)
    assert len(data)<=limit
    return data
def run():
    guard();save("profile-freeze.json",dict(design=sha(HERE/"PROFILE-DESIGN.md"),id=5347875,archive_before_inspection=FILES))
    record=json.loads(fetch(URL,300000))
    assert record["metadata"]["license"]["id"]=="cc-by-4.0"
    info={}
    for item in record["files"]:
        name=item["key"];size,md5=FILES[name];assert item["size"]==size and item["checksum"]=="md5:"+md5
        data=fetch(item["links"]["self"],size);assert len(data)==size and hashlib.md5(data).hexdigest()==md5
        info[name]=dict(url=item["links"]["self"],md5=md5,sha256=hashlib.sha256(data).hexdigest(),bytes=size)
        if name.endswith("csv"):
            hits=[row for row in csv.DictReader(io.StringIO(data.decode("utf-8-sig"))) if row["PSRJ"]=="J1537+1155"]
            assert len(hits)==1 and hits[0]["NOBS"]=="6";table("catalogue-row.csv",hits)
        else:
            with tarfile.open(fileobj=io.BytesIO(data),mode="r:gz") as archive:
                entries=[m for m in archive if m.isfile() and "1537+1155" in m.name and not m.name.rsplit("/",1)[-1].startswith("._")]
                assert len(entries)==1,[(x.name,x.size) for x in entries]
                target=entries[0];assert 2880<=target.size<2000000
                profile=archive.extractfile(target).read()
                assert len(profile)==target.size and profile.startswith(b"SIMPLE  =")
                put("J1537+1155.fits",profile)
                info[name].update(member=target.name,target_bytes=len(profile),target_sha256=sha(HERE/"J1537+1155.fits"))
    save("data-provenance.json",dict(record=5347875,doi="10.5281/zenodo.5347875",authors="Spiewak et al.",license="CC BY 4.0",
                              source_files=info,observations_are_summed=True))
    print(info)
if __name__=="__main__":run()
