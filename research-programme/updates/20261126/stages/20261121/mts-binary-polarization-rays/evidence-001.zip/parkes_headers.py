"""Inspect only verified header excerpts and complete intensity children, offline."""
import json
import struct
import warnings
from astropy.io import fits
from astropy.utils.exceptions import AstropyUserWarning
from base import HERE, read, sha, table, guard

def metadata():
    guard()
    provenance = json.loads((HERE / "parkes-provenance.json").read_bytes())
    catalogue = {entry["id"]: entry for entry in read(HERE / "parkes-catalogue.csv")}
    rows, ephemerides = [], {}
    for entry in provenance["products"]:
        path = HERE / entry["local"]
        assert path.stat().st_size == entry["retained_bytes"] and sha(path) == entry["sha256"]
        item = catalogue[entry["catalogue_id"]]
        prefix = path.suffix == ".bin"
        with warnings.catch_warnings():
            if prefix:
                warnings.filterwarnings("ignore", message="File may have been truncated:.*", category=AstropyUserWarning)
            with fits.open(path, memmap=False, lazy_load_hdus=True) as hdus:
                header = hdus[0].header
                assert header["SRC_NAME"] == item["src_name"] == "J1537+1155" and header["TELESCOP"] == "PARKES"
                params = dict(line.split()[:2] for line in hdus["PSRPARAM"].data.field(0))
                visit = item["projid"]
                if visit in ephemerides:
                    assert ephemerides[visit] == params
                ephemerides[visit] = params
                sub = hdus["SUBINT"]
                key = sub.header
                hist = hdus["HISTORY"].data[-1]
                assert int(header["STT_IMJD"]) == int(item["stt_imjd"]) and int(header["STT_SMJD"]) == int(item["stt_smjd"])
                if prefix:
                    assert (key["POL_TYPE"], key["NPOL"]) == ("AABBCRCI", 4)
                    assert sub.columns.names[:3] == ["INDEXVAL", "TSUBINT", "OFFS_SUB"]
                    assert all(sub.columns[name].format == "1D" for name in sub.columns.names[:3])
                    with path.open("rb") as stream:
                        stream.seek(sub.fileinfo()["datLoc"])
                        _, duration, offset = struct.unpack(">3d", stream.read(24))
                else:
                    assert (key["POL_TYPE"], key["NPOL"], key["NAXIS2"], key["NCHAN"]) == ("INTEN", 1, 1, 1)
                    duration, offset = (float(sub.data[name][0]) for name in ("TSUBINT", "OFFS_SUB"))
                assert 0 < duration and 0 < offset
                rows.append(dict(project=visit, product_id=item["id"], parent_id=item["parentid"], backend=header["BACKEND"],
                    kind="raw_prefix" if prefix else "summed_intensity", pol=key["POL_TYPE"], stored_rows=key["NAXIS2"],
                    history_rows=int(hist["NSUB"]), channels=key["NCHAN"], bins=key["NBIN"], history_freq_MHz=float(hist["CTR_FREQ"]),
                    primary_freq_MHz=header["OBSFREQ"], calibration=str(hist["CAL_MTHD"]), be_corr=int(hist["BE_CORR"]),
                    date_obs=header["DATE-OBS"], imjd=header["STT_IMJD"], smjd=header["STT_SMJD"], start_offset_s=header["STT_OFFS"],
                    antenna_x_m=header["ANT_X"], antenna_y_m=header["ANT_Y"], antenna_z_m=header["ANT_Z"],
                    row0_seconds=duration, row0_mid_offset_s=offset, inspected=path.name))
    assert len(rows) == 4 and len(ephemerides) == 2
    for row in rows:
        if row["kind"] == "summed_intensity":
            parent, = [other for other in rows if other["product_id"] == row["parent_id"]]
            assert all(parent[key] == row[key] for key in ("backend", "project", "imjd", "smjd", "start_offset_s"))
    return rows, ephemerides

if __name__ == "__main__":
    table("parkes-headers.csv", metadata()[0])
