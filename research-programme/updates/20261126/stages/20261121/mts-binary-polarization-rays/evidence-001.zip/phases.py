from base import HERE,PERIOD,ECC,C,np,read,table,save,orbit,epochs
from rays import stationary,paired
from scipy.interpolate import CubicSpline
from scipy.optimize import brentq,minimize_scalar
from scipy.integrate import quad

def mean_fraction(true_angle):
    ecc_anomaly=2*np.arctan2(np.sqrt(1-ECC)*np.sin(true_angle/2),np.sqrt(1+ECC)*np.cos(true_angle/2))
    return ((ecc_anomaly-ECC*np.sin(ecc_anomaly))/(2*np.pi))%1
def run():
    results=[];control=[];geometry=epochs()[0]
    for row in read(HERE/"phase-forecasts.csv"):
        deg=int(row["true_anomaly_deg"]);impact,mass,start,vv,rad=orbit(geometry,np.radians(deg))
        grad,jj=stationary(start,np.pi/2,mass/impact)
        physical=grad*mass/(C*impact**2)
        predicted=float(row["flat"])+mass/impact*float(row["bending_slope"])
        results.append(dict(true_anomaly_deg=deg,mean_phase=mean_fraction(np.radians(deg)),b_m=impact,v=vv,
                       weak_s_per_m2=float(row["weak_s_per_m2"]),curved_s_per_m2=physical,
                       historical_continuation=float(row["historical_continuation"]),accel=float(row["los_accel_m_s2"]),
                       remainder=grad-predicted))
        if deg in (0,46,90,150,166,184,226,270,346):
            big,_=paired(start,np.pi/2,mass/impact,1e-5);small,_=paired(start,np.pi/2,mass/impact,5e-6)
            precise=(4*small-big)/3
            assert abs(precise-grad)<2e-7,(deg,precise,grad)
            control.append(dict(true_anomaly_deg=deg,shoot=precise,stationary=grad,absolute_error=abs(precise-grad)))
    table("orbital-transfer.csv",results);table("orbital-shoot-check.csv",control)
    phase=np.array([row["mean_phase"] for row in results])
    amplitude=np.array([row["curved_s_per_m2"]*1e21 for row in results])
    spline=CubicSpline(np.r_[phase,1.],np.r_[amplitude,amplitude[0]],bc_type="periodic")
    peak=minimize_scalar(lambda at:-spline(at),bounds=(.4,.5),method="bounded",options={"xatol":1e-13})
    tmax=peak.x
    assert spline(tmax)>=max(amplitude)-1e-7 and abs(spline(tmax,1))<.01
    half=spline(tmax)/2
    left,right=brentq(lambda at:spline(at)-half,tmax-.2,tmax),brentq(lambda at:spline(at)-half,tmax,tmax+.2)
    def smooth(sec):
        dt=sec/PERIOD
        return spline.integrate(tmax-dt/2,tmax+dt/2)/dt
    def exact_peak(angle):
        impact,mass,start,*_=orbit(geometry,angle)
        return stationary(start,np.pi/2,mass/impact)[0]*mass/(C*impact**2)*1e21
    measured=minimize_scalar(lambda at:-exact_peak(at),bounds=np.radians((160.,173.)),method="bounded")
    exact_time=mean_fraction(measured.x)
    left_angle=brentq(lambda angle:exact_peak(angle)+measured.fun/2,np.radians(130),measured.x)
    right_angle=brentq(lambda angle:exact_peak(angle)+measured.fun/2,measured.x,np.radians(205))
    width_s=(mean_fraction(right_angle)-mean_fraction(left_angle))*PERIOD
    assert abs((right-left)*PERIOD-width_s)<2 and abs((tmax-exact_time)*PERIOD)<2
    weak=np.array([r["weak_s_per_m2"] for r in results]);old=np.array([r["historical_continuation"] for r in results]);acc=np.array([r["accel"] for r in results])
    proj=lambda vec:vec-acc*np.dot(vec,acc)/np.dot(acc,acc)
    quotient=np.linalg.norm(proj(weak)-(2/3)*proj(old))/np.linalg.norm(proj(weak))
    assert quotient<1e-12
    save("phase-summary.json",dict(geometry_reference_only=True,mean_phase_from_periastron_at_peak=exact_time,
            peak_true_anomaly_deg=float(np.degrees(measured.x)),reference_peak_us_per_1e15=-measured.fun,
            half_max_width_minutes=width_s/60,orbit_fraction_above_half=width_s/PERIOD,
            peak_16min_boxcar_us_per_1e15=smooth(960).item(),projection_error=quotient.item(),
            maximum_shoot_disagreement=max(row["absolute_error"] for row in control)))
if __name__=="__main__":run()
