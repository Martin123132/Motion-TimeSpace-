from base import HERE,C,np,guard,epochs,read,table,save,sha
from rays import paired,stationary,shoot
import json
def run():
    guard();cfg=json.loads((HERE/"freeze.json").read_bytes())
    assert cfg["conjunction"]==sha(HERE/"conjunction-forecasts.csv")
    variants={row["geometry_id"]:row for row in epochs()}
    records=[];details=[];scales=[]
    for row in read(HERE/"conjunction-forecasts.csv"):
        key=row["geometry"],row["receiver_z_over_b"]
        start,end,mu,flat,bend,impact,mass=map(float,[row[k] for k in ("start","end","mu","flat","bending_slope","impact_m","mass_m")])
        grad,jj=stationary(start,end,mu);hi,j2=stationary(start,end,mu,129)
        assert abs(hi-grad)<2e-9 and abs(jj-j2)<1e-10
        estimates=[]
        for step in (2e-5,1e-5,5e-6):
            val,results=paired(start,end,mu,step)
            estimates.append(val)
            for (sgn,label),ray in results.items():details.append(dict(geometry=key[0],receiver=key[1],step=step,sign=sgn,label=label,**ray))
        rich=(4*estimates[2]-estimates[1])/3
        coarse=(4*estimates[1]-estimates[0])/3
        assert abs(rich-hi)<2e-7 and abs(rich/hi-1)<2e-8 and abs(rich-coarse)<2e-7,(key,rich,hi)
        split=hi*mass/(C*impact**2);old=float(variants[key[0]]["lag_coefficient_s_per_m2"])
        records.append(dict(geometry=key[0],receiver=key[1],j_gr=j2,flat=flat,fermat=hi,shot=rich,abs_discrepancy=abs(hi-rich),
             shot_refine_change=abs(coarse-rich),gr_minus_weak_ppm=1e6*(hi/flat-1),corrected_s_per_m2=split,
             lag_us_for_1e15_m2=split*1e21,one_us_scale_m2=1e-6/split,archived_s_per_m2=old if key[1]=="infinity" else "not_same_endpoint"))
        if key[0]==next(iter(variants)) and key[1]=="infinity":
            old_error=None
            for frac in (1.,.5,.25,.125,0.):
                response,j=stationary(start,end,frac*mu,129)
                raw,_=paired(start,end,mu*frac,5e-6,True)
                larger,_=paired(start,end,mu*frac,1e-5,True)
                numerical=(4*raw-larger)/3
                correction=response-flat;error=response-(flat+frac*mu*bend)
                assert abs(numerical-response)<2e-7
                if frac:
                    if old_error is not None:assert .20<abs(error/old_error)<.30,(frac,error,old_error)
                    old_error=error
                else:assert abs(correction)<1e-9
                scales.append(dict(mass_fraction=frac,split=response,shoot=numerical,weak=flat,linear_correction=frac*mu*bend,
                                   true_correction=correction,higher_order=error,single_step_error=raw-response))
            a=shoot(start,end,0.,0.,1);b=shoot(start,end,0.,0.,-1)
            assert a["arrival"]==b["arrival"] and abs(a["j"]-1)<1e-13
        print(key,rich,hi,flush=True)
    table("conjunction-transfer.csv",records);table("paired-shooting.csv",details);table("weak-limit.csv",scales)
    save("comparison.json",dict(physical_geometries=5,configurations=len(records),direct_signed_rays=len(details),
         max_endpoint=max(row["endpoint"] for row in details),max_invariant=max(row["energy"] for row in details),
         max_relative=max(abs(row["shot"]/row["fermat"]-1) for row in records)))
if __name__=="__main__":run()
