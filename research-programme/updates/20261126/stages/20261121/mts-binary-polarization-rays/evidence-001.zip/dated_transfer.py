"""Geometry-only placement and polarization averaging; no measured pulse lags."""
import json
from astropy import units as units
from astropy.coordinates import EarthLocation, SkyCoord, solar_system_ephemeris
from astropy.time import Time
from astropy.utils import iers
from base import HERE, C, TSUN, PERIOD, ECC, PERI, np, epochs, table, save
from parkes_headers import metadata

iers.conf.auto_download = False
def value(params, name, default=None):
    return float(str(params.get(name, default)).replace("D", "E"))

def elements(params, elapsed):
    period = value(params, "PB") * 86400
    cycles0 = elapsed / period
    cycles = cycles0 - .5 * value(params, "PBDOT") * cycles0**2
    mean = 2 * np.pi * (cycles % 1.)
    eccentricity = value(params, "ECC", params.get("E"))
    ecc_angle = mean.copy()
    for _ in range(8):
        ecc_angle -= (ecc_angle - eccentricity*np.sin(ecc_angle) - mean)/(1-eccentricity*np.cos(ecc_angle))
    assert np.max(abs(ecc_angle - eccentricity*np.sin(ecc_angle) - mean)) < 2e-14
    anomaly = (2*np.arctan2(np.sqrt(1+eccentricity)*np.sin(ecc_angle/2),
                             np.sqrt(1-eccentricity)*np.cos(ecc_angle/2))) % (2*np.pi)
    advance = np.deg2rad(value(params, "OMDOT"))/(365.25*86400)
    omega = np.deg2rad(value(params, "OM")) + advance*(period + value(params,"PBDOT")*elapsed)*(np.floor(cycles)+anomaly/(2*np.pi))
    return cycles % 1., eccentricity, ecc_angle, anomaly, omega

def weak_geometry(eccentricity, ecc_angle, anomaly, omega):
    central = epochs()[0]
    sine_i = float(central["shapiro_shape_s"])
    cosine_i = np.sqrt(1-sine_i**2)
    radius = float(central["relative_semimajor_axis_m"])*(1-eccentricity*np.cos(ecc_angle))
    latitude = omega + anomaly
    los = sine_i*np.sin(latitude)
    scale = 8*TSUN*float(central["companion_mass_solar"])/radius**2
    scalar = 1e21*scale*(2-los)*(1+los)/(1-los)
    axis = np.cos(latitude) + 1j*cosine_i*np.sin(latitude)
    spin2 = axis**2 / abs(axis)**2
    assert np.max(abs(spin2 - np.exp(2j*np.arctan2(axis.imag,axis.real)))) < 1e-14
    flipped = np.cos(latitude) - 1j*cosine_i*np.sin(latitude)
    rotated = axis*np.exp(.37j)
    assert np.max(abs((flipped/abs(flipped))**2-spin2.conj())) < 1e-14
    assert np.max(abs((rotated/abs(rotated))**2-np.exp(.74j)*spin2)) < 1e-14
    return scalar, scalar*spin2

def average(values):
    assert len(values)%2 == 1
    return (values[0]+values[-1]+4*sum(values[1:-1:2])+2*sum(values[2:-1:2]))/(3*(len(values)-1))

def summarize(phase, scalar, response):
    mean_scalar = average(scalar)
    mean_response = average(response)
    assert np.all(scalar > 0) and abs(mean_response) <= mean_scalar*(1+1e-13)
    return dict(start_phase=float(phase[0]), mid_phase=float(phase[len(phase)//2]), end_phase=float(phase[-1]),
                scalar_low_us=float(min(scalar)), scalar_high_us=float(max(scalar)), scalar_avg_us=float(mean_scalar),
                screen_cos_us=float(mean_response.real), screen_sin_us=float(mean_response.imag),
                screen_norm_us=float(abs(mean_response)), orientation_retained=float(abs(mean_response)/mean_scalar))

def dated(row, params, count):
    site = EarthLocation.from_geocentric(*(row[key] for key in ("antenna_x_m","antenna_y_m","antenna_z_m")), unit=units.m)
    times = np.linspace(-.5,.5,count)*row["row0_seconds"] + row["row0_mid_offset_s"]
    times += row["smjd"]+row["start_offset_s"]
    stamp = Time(row["imjd"],times/86400,format="mjd",scale="utc",location=site)
    pointing = SkyCoord(params["RAJ"],params["DECJ"],unit=(units.hourangle,units.deg),frame="icrs")
    with solar_system_ephemeris.set("builtin"):
        bary = stamp.tdb + stamp.light_travel_time(pointing,kind="barycentric")
    elapsed = (bary-Time(value(params,"T0"),format="mjd",scale="tdb")).to_value(units.s)
    dispersion = 4148.808*value(params,"DM")/row["history_freq_MHz"]**2
    ssb = elapsed - dispersion
    emission = ssb.copy()
    for _ in range(6):
        phase,ecc,ecc_angle,anomaly,omega = elements(params,emission)
        sj = np.sin(omega)*(np.cos(ecc_angle)-ecc) + np.cos(omega)*np.sqrt(1-ecc**2)*np.sin(ecc_angle)
        shape = float(epochs()[0]["shapiro_shape_s"])
        delay = value(params,"A1")*sj + value(params,"GAMMA")*np.sin(ecc_angle) - 2*TSUN*value(params,"M2")*np.log(1-ecc*np.cos(ecc_angle)-shape*sj)
        updated = ssb-delay
        change = np.max(abs(updated-emission))
        emission = updated
    assert change < 2e-6
    phase,ecc,ecc_angle,anomaly,omega = elements(params,emission)
    return summarize(phase,*weak_geometry(ecc,ecc_angle,anomaly,omega))

def reference(count):
    info = json.loads((HERE/"phase-summary.json").read_bytes())
    elapsed = PERIOD*info["mean_phase_from_periastron_at_peak"]+np.linspace(-480,480,count)
    params = dict(PB=PERIOD/86400,PBDOT=0,ECC=ECC,OM=np.degrees(PERI),OMDOT=0)
    phase,ecc,ecc_angle,anomaly,omega = elements(params,elapsed)
    return summarize(phase,*weak_geometry(ecc,ecc_angle,anomaly,omega))

def run():
    records, params = metadata()
    rows = []
    for record in records:
        if record["kind"] != "summed_intensity":
            continue
        for model, ephem in params.items():
            coarse, fine = (dated(record,ephem,count) for count in (33,65))
            quadrature = max(abs(coarse[key]-fine[key]) for key in ("scalar_avg_us","screen_cos_us","screen_sin_us"))
            assert quadrature < 1e-6
            rows.append(dict(visit=record["project"], ephemeris=model, native=model==record["project"],
                             averages="uniform exposure; weak transfer", quadrature_change_us=quadrature,**fine))
    coarse,fine = reference(33),reference(65)
    quadrature = max(abs(coarse[key]-fine[key]) for key in ("scalar_avg_us","screen_cos_us","screen_sin_us"))
    assert quadrature < 1e-6 and abs(fine["scalar_avg_us"]-.5579951) < .0002
    rows.append(dict(visit="reference_16min",ephemeris="fixed_reference",native=False,
                     averages="uniform exposure; weak transfer",quadrature_change_us=quadrature,**fine))
    table("dated-transfer.csv",rows)
    save("dated-design.json",dict(design_sha256=__import__("base").sha(HERE/"EPOCH-DESIGN.md"),
        coefficient_m2=1e15,derived_screen="sky-projected separation; node zero, cos(i) positive; swapping eigenlabels reverses sign",
        assumptions="static-exterior plane; printed folding ephemerides treated as TDB-compatible, UTC from split FITS clock, builtin solar ephemeris, fixed catalogue direction, representative-frequency dispersion; not precision arrival times",
        exposure="duration of single summed child treated as continuous, not individual archive weights; no Parkes polarization amplitudes inspected"))
if __name__=="__main__":
    run()
