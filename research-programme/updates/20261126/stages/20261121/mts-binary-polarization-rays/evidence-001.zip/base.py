import csv
import hashlib
import io
import json
import os
from pathlib import Path
for env in ("OPENBLAS_NUM_THREADS","OMP_NUM_THREADS","MKL_NUM_THREADS","BLIS_NUM_THREADS","NUMEXPR_NUM_THREADS"):os.environ[env]="1"
import numpy as np
HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
PREV=ROOT/"mts-finite-tidal-exposure-20261121"
BANK=ROOT/"source-intake"/"functional_rg"/"4945"
ORBIT=BANK/"PSR_B1534_geometry_reconstruction.csv"
PIN="753c14739aad493237d2d34bc0d1c011c47617913e5801d01b2559b09cdbe190"
ORBIT_PIN="3a06ece4500454765d8b43883941bd48047722a84677aa3f5c445ed67d0204fc"
C=299792458.
TSUN=4.925490947e-6
ECC=.27367752
PERI=np.radians(283.306012)
PERIOD=.420737298879*86400
def sha(path):
    with path.open("rb") as stream:return hashlib.file_digest(stream,"sha256").hexdigest()
def guard():
    if any((root/"STOP-REQUESTED").exists() for root in (HERE,ROOT,PREV)):raise RuntimeError("owner hold")
def inputs():
    guard();assert sha(ORBIT)==ORBIT_PIN and sha(PREV/"seal.json")==PIN
    for name,value in json.loads((PREV/"seal.json").read_bytes())["files"].items():assert sha(PREV/name)==value
def read(path):
    with path.open(newline="",encoding="utf-8-sig") as stream:return list(csv.DictReader(stream))
def put(name,data):
    guard();path=HERE/name
    if path.exists():assert path.read_bytes()==data,name
    else:
        with path.open("xb") as stream:stream.write(data)
def table(name,rows):
    stream=io.StringIO(newline="");writer=csv.DictWriter(stream,rows[0].keys(),lineterminator="\n");writer.writeheader();writer.writerows(rows);put(name,stream.getvalue().encode())
def save(name,record):put(name,(json.dumps(record,indent=2,allow_nan=False)+"\n").encode())
def orbit(row,anomaly):
    shape=float(row["shapiro_shape_s"])
    axis=float(row["relative_semimajor_axis_m"]);radius=axis*(1-ECC**2)/(1+ECC*np.cos(anomaly))
    fraction=shape*np.sin(PERI+anomaly);impact=radius*np.sqrt((1-fraction)*(1+fraction))
    mass=C*TSUN*float(row["companion_mass_solar"])
    return impact,mass,np.arctan2(-radius*fraction,impact),fraction,radius
def epochs():
    rows=read(ORBIT);assert len(rows)==5
    return rows
