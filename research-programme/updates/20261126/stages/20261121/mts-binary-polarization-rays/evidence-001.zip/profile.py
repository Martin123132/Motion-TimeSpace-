"""Real summed shape as a template only; test signed injections, not sky timing residuals."""
import json
from base import HERE,np,read,table,save,sha
from astropy.io import fits
def trimmed(samples,cutoff):
    coeff=np.fft.rfft(samples,axis=-1)
    coeff[...,cutoff+1:]=0.
    phase=2j*np.pi*np.arange(coeff.shape[-1]);size=samples.shape[-1]
    return np.fft.irfft(coeff,n=size),np.fft.irfft(phase*coeff,n=size)
def shift(samples,turns):
    coeff=np.fft.rfft(samples);rotation=np.exp(-2j*np.pi*np.arange(len(coeff))*turns)
    return np.fft.irfft(coeff*rotation,n=len(samples))
def run():
    provenance=json.loads((HERE/"data-provenance.json").read_bytes())
    path=HERE/"J1537+1155.fits";assert sha(path)==provenance["source_files"]["census_profs.tar.gz"]["target_sha256"]
    assert json.loads((HERE/"profile-freeze.json").read_bytes())["design"]==sha(HERE/"PROFILE-DESIGN.md")
    metadata=read(HERE/"catalogue-row.csv")[0]
    with fits.open(path,memmap=False) as hdus:
        hdus.verify("exception");header=hdus[0].header;sub=hdus["SUBINT"];record=sub.data[0];history=hdus["HISTORY"].data
        assert header["SRC_NAME"]=="J1537+1155" and sub.header["POL_TYPE"]=="IQUV"
        assert (len(sub.data),sub.header["NPOL"],sub.header["NCHAN"],sub.header["NBIN"])==(1,4,8,1024)
        assert record["DATA"].shape==(4,8,1024)
        raw=record["DATA"].astype(float)
        scales=record["DAT_SCL"].reshape(4,8,1);offsets=record["DAT_OFFS"].reshape(4,8,1)
        samples=raw*scales+offsets
        valid=np.asarray(record["DAT_WTS"])>0
        assert valid.all() and np.isfinite(samples).all() and (scales!=0).all()
        info=dict(source=header["SRC_NAME"],instrument=header["TELESCOP"],stored_stokes=sub.header["POL_TYPE"],
              feed_basis=header["FD_POLN"],feed_hand=header["FD_HAND"],frequencies_MHz=record["DAT_FREQ"].tolist(),
              archival_weights=record["DAT_WTS"].tolist(),duration_s=float(record["TSUBINT"]),reported_spin_period_s=float(metadata["P0"]),
              summed_observations=int(metadata["NOBS"]),subintegrations=len(sub.data),file_RM=sub.header["RM"],catalogue_RM=float(metadata["RM"]),
              calibration_history={key:int(history[-1][key]) for key in ("PR_CORR","FD_CORR","BE_CORR","RM_CORR","DEDISP")},
              channel_weight_policy="positive weights as mask; equal norm-normalized channel blocks; not inverse variances",
              profile_date_is_not_a_phase_resolved_TOA=True)
    save("profile-inputs.json",info)
    spin=float(metadata["P0"])
    central=next(row for row in read(HERE/"conjunction-transfer.csv") if row["geometry"].endswith("central") and row["receiver"]=="infinity")
    inj=float(central["lag_us_for_1e15_m2"])*1e-6/spin
    rows=[];injections=[]
    for cutoff in (8,16,32):
        channels,rates=trimmed(samples,cutoff)
        for group,indices in (("all",range(8)),("lower",range(4)),("upper",range(4,8))):
            columns=[];projected=[];maps=[]
            for ch in indices:
                inten,stq,stu=channels[:3,ch]
                di,dq,du=rates[:3,ch]
                norm=np.linalg.norm(di)
                design=np.column_stack((np.ones(len(di)),inten-np.mean(inten),di))
                transform,_=np.linalg.qr(design/np.linalg.norm(design,axis=0))
                def remove(array):return array-transform@(transform.T@array)
                block=-np.column_stack((dq,du))/(2*norm)
                columns.append(block);projected.append(remove(block))
                maps.append((ch,transform,norm))
            raw_basis=np.vstack(columns)/np.sqrt(len(maps));basis=np.vstack(projected)/np.sqrt(len(maps))
            raw_eigen=np.linalg.eigvalsh(raw_basis.T@raw_basis)
            eigen,vectors=np.linalg.eigh(basis.T@basis)
            assert eigen[0]>0 and np.all(eigen<=raw_eigen+1e-12)
            minimum_angle=(np.degrees(np.arctan2(vectors[1,0],vectors[0,0]))/2)%90
            rows.append(dict(harmonics=cutoff,channels=group,raw_min=np.sqrt(raw_eigen[0]),raw_max=np.sqrt(raw_eigen[1]),
                     residual_min=np.sqrt(eigen[0]),residual_max=np.sqrt(eigen[1]),minimum_angle_deg_mod90=minimum_angle))
            for angle in (0.,22.5,45.,67.5):
                direction=np.array([np.cos(np.radians(2*angle)),np.sin(np.radians(2*angle))]);template=basis@direction
                estimates=[]
                for sign in (1,-1):
                    delta=sign*inj
                    blocks=[]
                    for ch,transform,norm in maps:
                        inten,stq,stu=channels[:3,ch]
                        linear=direction[0]*stq+direction[1]*stu
                        pplus=(inten+linear)/2;pminus=(inten-linear)/2
                        residual=shift(pplus,delta/2)+shift(pminus,-delta/2)-inten
                        residual+=.003*(inten-inten.mean())+1.5e-4*rates[0,ch]+.007*np.std(inten)
                        blocks.append((residual-transform@(transform.T@residual))/norm)
                    measured=np.concatenate(blocks)/np.sqrt(len(maps))
                    estimate=(template@measured)/(template@template)
                    assert estimate*sign>0
                    estimates.append(estimate)
                recovered=(estimates[0]-estimates[1])/2
                err=abs(recovered/inj-1)
                assert err<2e-6
                injections.append(dict(harmonics=cutoff,channels=group,angle_deg=angle,imposed_turns=inj,positive=estimates[0],
                        negative=estimates[1],odd_recovered=recovered,relative_error=err))
    table("shape-response.csv",rows);table("profile-injections.csv",injections)
    print("shape response",[(row["harmonics"],row["residual_min"],row["residual_max"]) for row in rows if row["channels"]=="all"],
          "max signed injection error",max(row["relative_error"] for row in injections))
if __name__=="__main__":run()
