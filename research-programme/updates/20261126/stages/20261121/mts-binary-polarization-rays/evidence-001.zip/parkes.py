"""Bounded public-archive intake; retain folded products only, inspect a small raw prefix."""
import csv
import io
import json
import re
import hashlib
from urllib.parse import urlencode,urlsplit
from urllib.request import Request,urlopen
from base import HERE,guard,save,put,table,sha

TAP="https://data.csiro.au/psrdavo/tap/sync"
QUERY="SELECT id,projid,src_name,obs_mode,filename,filepath,filesize,date_obs,obsfreq,obs_length,fd_poln,nrcvr,doi,data_collection_id,parentid,stt_imjd,stt_smjd,stt_offs FROM psrda.pulsar_obs WHERE src_name='J1537+1155' AND obs_mode='PSR' ORDER BY id"
def get(url,limit,extra=None):
    request=Request(url,headers={"User-Agent":"MTS-research/1.0",**(extra or {})})
    with urlopen(request,timeout=25) as response:
        size=int(response.headers.get("Content-Length","0"))
        if size>limit:raise ValueError("server did not honour bounded read: "+str(size))
        body=response.read(limit+1)
        if len(body)>limit:raise ValueError("size limit")
        return body,dict(response.headers),response.status
def run():
    guard()
    data,_,_=get(TAP+"?"+urlencode(dict(REQUEST="doQuery",LANG="ADQL",FORMAT="csv",QUERY=QUERY)),24000)
    obs=list(csv.DictReader(io.StringIO(data.decode("utf-8-sig"))))
    assert {row["id"] for row in obs}=={"466297","466384","2404695","2404696"}
    table("parkes-catalogue.csv",obs)
    info=[]
    for ident in ("7177","48332"):
        root=f"https://data.csiro.au/dap/ws/v2/collections/{ident}/data"
        cat=json.loads(get(root,4000000,{"Accept":"application/json"})[0])
        for row in obs:
            if row["data_collection_id"]!=ident:continue
            name=row["filename"]
            item,=[f for f in cat["file"] if f["filename"]==row["filepath"].lstrip("/")]
            size=int(float(row["filesize"]))
            assert int(item["fileSize"])==size
            target=item["link"]["href"];assert target==f"{root}/{item['id']}"
            if name.endswith(".FTp"):
                content,_,_=get(target,size)
                assert len(content)==size
                local=name+".fits";put(local,content)
            else:
                limit=2880*32
                req=Request(target,headers={"Range":"bytes=0-%d"%(limit-1)})
                with urlopen(req,timeout=30) as response:
                    if response.status==206:assert response.headers["content-range"]==f"bytes 0-{limit-1}/{size}"
                    else:assert response.status==200 and int(response.headers["content-length"])==size
                    content=response.read(limit)
                assert len(content)==limit
                local=name+"-header-prefix.bin";put(local,content)
            assert content.startswith(b"SIMPLE  =")
            info.append(dict(filename=name,catalogue_id=row["id"],collection=ident,file_id=item["id"],index=root,
                 license=cat["licence"],doi=row["doi"],object_bytes=size,local=local,retained_bytes=len(content),sha256=sha(HERE/local)))
    save("parkes-provenance.json",dict(tap=TAP,query=QUERY,products=info))
    print([(row["filename"],row["retained_bytes"]) for row in info])
if __name__=="__main__":run()
