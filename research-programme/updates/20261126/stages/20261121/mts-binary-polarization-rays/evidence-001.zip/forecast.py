from base import HERE,ORBIT_PIN,PIN,C,np,epochs,orbit,inputs,table,save,sha
from scipy.integrate import quad
def predicted(start,end):
    left,right=np.sin([start,end])
    delta=right-left
    integral=delta*(1-(right*right+right*left+left*left)/3)
    trig=np.array([[np.cos(angle),np.sin(angle)] for angle in (start,end)])
    aa,bb=np.linalg.solve(trig,-np.array([1+np.sin(angle)**2 for angle in (start,end)]))
    def displacement(at):return 1+np.sin(at)**2+aa*np.cos(at)+bb*np.sin(at)
    slope=2*np.sin(end)*np.cos(end)-aa*np.sin(end)+bb*np.cos(end)
    j1=np.sin(end)*slope+np.cos(end)**3
    first=24*(j1*integral+3*quad(lambda angle:np.cos(angle)**2*displacement(angle),start,end,epsabs=2e-14)[0])
    return 24*integral,first,j1
def run():
    inputs();cases=[]
    for idx,row in enumerate(epochs()):
        at=np.radians(float(row["closest_true_anomaly_deg"]))
        impact,mass,start,frac,radius=orbit(row,at)
        assert abs(impact/float(row["physical_impact_parameter_m"])-1)<1e-12
        for dist in ((8.,32.,0.) if idx==0 else (0.,)):
            end=np.arctan(dist) if dist else np.pi/2
            flat,first,j1=predicted(start,end)
            cases.append(dict(geometry=row["geometry_id"],receiver_z_over_b=str(dist) if dist else "infinity",
                     start=start,end=end,impact_m=impact,mass_m=mass,mu=mass/impact,flat=flat,bending_slope=first,j_slope=j1,
                     weak_transfer=flat*mass/(C*impact**2)))
    table("conjunction-forecasts.csv",cases)
    phases=[]
    for deg in range(0,360,2):
        impact,mass,start,vv,radius=orbit(epochs()[0],np.radians(deg))
        flat,first,j1=predicted(start,np.pi/2)
        old=24*mass/(C*radius**2*(1-vv))
        new=8*mass*(2-vv)*(1+vv)/(C*radius**2*(1-vv))
        acceleration=C**2*mass*vv/radius**2
        assert abs(new/(flat*mass/(C*impact**2))-1)<1e-11
        assert abs(new-2*old/3-8*acceleration/C**3)<1e-35
        phases.append(dict(true_anomaly_deg=deg,impact_m=impact,los_fraction=vv,start=start,mu=mass/impact,
             flat=flat,bending_slope=first,weak_s_per_m2=new,historical_continuation=old,los_accel_m_s2=acceleration))
    table("phase-forecasts.csv",phases)
    save("freeze.json",dict(parent=PIN,input_orbit=ORBIT_PIN,design=sha(HERE/"DESIGN.md"),model=sha(HERE/"base.py"),predictor=sha(HERE/"forecast.py"),
        conjunction=sha(HERE/"conjunction-forecasts.csv"),phase=sha(HERE/"phase-forecasts.csv")))
if __name__=="__main__":run()
