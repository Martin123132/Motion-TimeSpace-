"""Independent all-multipole force readout and angular accuracy check, before band comparison."""
from measure import BOUND,FIRE,HERE,OLD,Elements,check,jf,json,keep,np,pinned,records,roots_legendre,sha,sys,table
from numpy.polynomial.legendre import legvander,legder,legval
from scipy.constants import parsec
from scipy.interpolate import BarycentricInterpolator

class Readout:
    def __init__(self,el,radius,radial_order):
        bg=el.bg
        target=np.hypot(radius,1.5)/bg.length;cosine=1.5/np.hypot(radius,1.5)
        degs=np.arange(0,2*max(bg.orders)+1,2)
        directions,weights=roots_legendre(80)
        assert 2*len(weights)-1>=4*max(bg.orders)
        dirs=(directions+1)/2
        polys=legvander(dirs,degs[-1])
        self.wave=(polys[:,bg.orders]*np.sqrt(2*bg.orders+1)).T
        coefficient=(polys[:,degs]*weights[:,None]/2).T
        zeros=np.eye(1+degs[-1])[:,degs]
        values=legval(cosine,zeros);derivs=legval(cosine,legder(zeros))
        self.kernels=[];self.actions=[];self.indices=[]
        points,weights_r=roots_legendre(radial_order)
        spline=BarycentricInterpolator(el.knots,np.eye(8),rng=271)
        for inner in (True,False):
            lo=el.left if inner else np.maximum(target,el.left)
            hi=np.minimum(target,el.right) if inner else el.right
            pick=hi>lo
            rad=lo[pick,None]+(hi-lo)[pick,None]*(points+1)/2
            self.indices.append(np.flatnonzero(pick));self.actions.append(spline((rad-el.left[pick,None])/el.width[pick,None]))
            gravity=(rad[:,:,None]/target)**degs/target if inner else (target/rad[:,:,None])**degs/rad[:,:,None]
            measure=(hi-lo)[pick,None,None]*weights_r[None,:,None]/2/target*bg.vel**2/bg.length*(1e13/parsec)
            self.kernels.append([((gravity*measure)*factor)@coefficient for factor in
                                 ((-(degs+1) if inner else degs)*values,-np.sqrt(1-cosine**2)*derivs)])
    def __call__(self,nodes):
        total=np.zeros(2)
        for inds,interp,kernels in zip(self.indices,self.actions,self.kernels,strict=True):
            density=abs((interp@nodes[inds])@self.wave)**2
            total+=[np.sum(kernel*density) for kernel in kernels]
        return total

def run(save):
    for name,expected in json.loads((HERE/'measurement-lock.json').read_bytes()).items():assert sha(HERE/name)==expected
    hist=records(HERE/'gradients.csv');previous=records(HERE/'forces.csv');rows=[]
    for branch in ('anchorA','cut1','cut2'):
        check();obj=jf.Assembly(branch);el=Elements(obj.bg)
        funcs={order:[Readout(el,radius,order) for radius in (6.,8.3)] for order in (22,30)}
        def gravity(values,order):return np.concatenate([func(el.nodes(values)) for func in funcs[order]])
        for host in ((branch,'raw_m12i') if branch=='anchorA' else (branch,)):
            raw=host=='raw_m12i';variant='raw_actual' if raw else 'joint'
            for steps in (32,64):
                check()
                section=[row for row in hist if row['host']==host and int(row['steps'])==steps]
                prefix='analog-wave-anchorA' if raw else 'wave-'+branch+'-joint'
                with np.load(pinned(OLD,f'{prefix}-{steps}-572_579_586_590_600.npz')) as old:
                    ref=old['final_ground'] if raw else obj.ground
                    first=old['states'][0]
                with np.load(pinned(FIRE,f'wave-{branch}-{variant}-{steps}.npz')) as data:states=[first,*data['states']]
                ground=ref*float(section[0]['ground_scale']);base=gravity(ground,30)
                for row,state in zip(section,states,strict=True):
                    wave=state*float(row['mass_scale']);full=gravity(wave,30);fine=full-base
                    check_error=max(abs(full-gravity(wave,22)).max(),abs(base-gravity(ground,22)).max())
                    assert check_error<1e-11
                    older=[item for item in previous if all(item[key]==row[key] for key in ('steps','host','epoch'))]
                    assert len(older)==4
                    for index,item in enumerate(older):
                        rows.append(dict(host=host,steps=steps,epoch=row['epoch'],R=item['R'],component=item['component'],
                                ground=base[index],delta=fine[index],native_ground=float(item['native_ground']),native_delta=float(item['native_delta']),
                                previous_ground_change=base[index]-float(item['continuous_ground']),
                                previous_induced_change=fine[index]-float(item['continuous_delta']),radial_refinement=check_error))
                    assert max(np.linalg.norm(fine.reshape(2,2),axis=1))<float(row['prepared_force_upper'])
    assert len(rows)==192
    table(HERE/'full-forces.csv',rows,save)
    lock={name:sha(HERE/name) for name in ('measurement-lock.json','full_force.py','full-forces.csv')}
    keep(HERE/'force-lock.json',(json.dumps(lock,indent=2,sort_keys=True)+'\n').encode(),save)
    print('verified 192 full angular force readouts')
if __name__=='__main__':
    assert sys.argv[1:] in ([],['--save'])
    run(bool(sys.argv[1:]))
