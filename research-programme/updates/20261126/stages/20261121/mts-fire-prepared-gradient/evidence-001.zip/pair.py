"""Close the finite-step kinetic separation budget on two nonlinear archived wave paths."""
from inherit import EARLY
from measure import FIRE,HERE,OLD,check,jf,json,np,pinned,sys,table,keep
from rate import gradient_root
from disk import Evolution

def advance(obj,solver,state,moment,ext,dt):
    midpoint=state;newmom=moment
    for count in range(24):
        phi=obj.phi(.5*(moment+newmom))
        candidate=solver.factor.solve(state-.5j*dt*obj.multiply(ext+phi-solver.pref,midpoint))
        final=2*candidate-state
        error=np.linalg.norm(candidate-midpoint)/np.sqrt(obj.number)
        midpoint=candidate;newmom=obj.moment(final)
        if error<2e-14:return final,newmom,midpoint,obj.phi(.5*(moment+newmom))
    raise ArithmeticError('nonlinear corrector did not converge')

def run(steps,save):
    host='anchorA';track='three';check();obj=jf.Assembly(host);units=obj.bg.vel**2/obj.number
    kinetic=obj.bg.mesh.kinetic(obj.bg.orders,True);ordinary=obj.bare-kinetic
    grad=gradient_root(kinetic,obj.bg.hshape)
    with np.load(pinned(OLD,f'wave-{host}-joint-{steps}-572_579_586_590_600.npz')) as data:initial=data['states'][0]
    with np.load(pinned(FIRE,f'wave-{host}-joint-{steps}.npz')) as data:
        reset={572:initial,**dict(zip(map(int,data['snapshots']),data['states'],strict=True))}
    with np.load(pinned(EARLY,f'state-{host}-{track}-{steps}.npz')) as data:
        inherited=dict(zip(map(int,data['snapshots']),data['states'],strict=True))
    epochs=tuple(reset)
    times=np.loadtxt(pinned(OLD,'snapshot_times.txt'))
    ages={epoch:times[times[:,0]==epoch,3].item()*1000 for epoch in epochs}
    potentials={}
    for epoch in epochs:
        folder=FIRE if epoch==581 else OLD
        with np.load(pinned(folder,f'forcing-{epoch}.npz')) as bank:potentials[epoch]=bank['joint']/obj.bg.vel**2
        assert abs(ages[epoch]-1000*json.loads(pinned(folder,f'mass-{epoch}-0.json').read_bytes())['proper_time_Gyr'])<1e-8
    results=[]
    for lo,hi in zip(epochs,epochs[1:]):
        check()
        pair=[inherited[lo].copy(),reset[lo].copy()]
        duration=(ages[hi]-ages[lo])/obj.unit_myr;count=int(np.ceil(steps*duration));dt=duration/count
        solvers=[Evolution(obj,dt,vec) for vec in pair];moments=[obj.moment(vec) for vec in pair]
        def cov(states):
            left,right=map(grad,states);cross=np.vdot(right,left)
            return cross,units*np.linalg.norm(left*np.exp(-1j*np.angle(cross))-right)**2
        cross,energy=cov(pair);start=energy;totals=np.zeros(3);defect=0.;phase_loss=0.
        for tick in range(count):
            if tick%16==0:check()
            ext=potentials[lo]+((tick+.5)/count)*(potentials[hi]-potentials[lo])
            updates=[advance(obj,solver,state,mom,ext,dt) for solver,state,mom in zip(solvers,pair,moments,strict=True)]
            pair,moments,mids,phis=zip(*updates,strict=True)
            next_cross,after=cov(pair)
            mean_phase=np.conj(cross+next_cross)/(abs(cross)+abs(next_cross))
            assert abs(mean_phase)<1+1e-12
            amp=min(abs(mean_phase),1.);central=mean_phase/abs(mean_phase) if amp else 1.
            phase_loss=max(phase_loss,1-amp)
            offsets=central*(amp+np.array([1j,-1j])*np.sqrt(max(0.,(1-amp)*(1+amp))))
            common_phi=(phis[0]+phis[1])/2;contrast=(phis[0]-phis[1])/2
            parts=np.zeros(3)
            for phase in offsets:
                gap=phase*mids[0]-mids[1];momentum=grad(gap)
                components=(ordinary@gap+obj.multiply(ext,gap),obj.multiply(common_phi,gap),
                            obj.multiply(contrast,phase*mids[0]+mids[1]))
                parts+=units*dt*np.array([np.vdot(momentum,grad(comp)).imag for comp in components])
            closure=after-energy-sum(parts)
            defect=max(defect,abs(closure))
            assert abs(closure)<1e-8,(lo,tick,closure)
            totals+=parts;energy=after;cross=next_cross
        end_errors=[np.linalg.norm(vec-expected)/np.sqrt(obj.number) for vec,expected in zip(pair,(inherited[hi],reset[hi]),strict=True)]
        assert max(end_errors)<1e-8,(lo,hi,end_errors)
        closure=energy-start-sum(totals)
        assert abs(closure)<1e-8
        results.append(dict(host=host,history=track,steps=steps,start=lo,stop=hi,inner_steps=count,
                start_distance=start,end_distance=energy,ordinary=totals[0],common_self=totals[1],density_contrast=totals[2],
                net=energy-start,closure=closure,max_step_defect=defect,max_endpoint_error=max(end_errors),
                max_phase_secant_loss=phase_loss))
        print('closed',steps,lo,hi,'steps',count,'endpoint',max(end_errors),flush=True)
    for first,second in zip(results,results[1:]):assert abs(first['end_distance']-second['start_distance'])<1e-8
    table(HERE/f'paired-balance-{steps}.csv',results,save)
if __name__=='__main__':
    assert sys.argv[1:2] in (['32'],['64']) and sys.argv[2:] in ([],['--save'])
    run(int(sys.argv[1]),bool(sys.argv[2:]))
