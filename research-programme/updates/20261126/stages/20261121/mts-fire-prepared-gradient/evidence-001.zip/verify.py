"""Audit the retained comparisons and byte receipts; no evolution is started."""
from pathlib import Path
import csv
import hashlib
import json
import sys
HOME=Path(__file__).resolve().parent
def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def read(name):
    with (HOME/name).open(newline='',encoding='utf8') as inp:return list(csv.DictReader(inp))
def publish(name,body,save):
    path=HOME/name;raw=(json.dumps(body,indent=2,sort_keys=True)+'\n').encode()
    if save and not path.exists():
        with path.open('xb') as stream:stream.write(raw)
    else:assert path.read_bytes()==raw,name
def validate(save):
    for name in ('measurement-lock.json','force-lock.json'):
        for key,val in json.loads((HOME/name).read_bytes()).items():assert digest(HOME/key)==val
    counts={'gradients':48,'full-forces':192,'forces':192,'sites':288,'comparisons':72,'reflection':144,'timestep':4,
            'inheritance':72,'inheritance-comparison':72,'reset-checks':12,'source-rates':72,'sparse-source-integral':12,
            'paired-balance-32':5,'paired-balance-64':5}
    for stem,count in counts.items():assert len(read(stem+'.csv'))==count
    sols=read('comparisons.csv')
    for row in sols:
        if row['model']=='MTS':
            assert int(row['bands'])==2 and float(row['necessary_over_available'])>1
        else:
            assert row['model']=='static_NFW' and not row['available_kms2']
            assert int(row['bands'])==(2 if row['host']=='anchorA' else 4)
        assert row['host']!='raw_m12i'
    full=read('full-forces.csv');best=read('inheritance-comparison.csv')
    assert all(abs(float(v['native_delta'])-float(v['delta']))<1e-8 for v in full)
    for row in best:
        assert min(float(row[k]) for k in ('ground_required_over_combined','endpoint_required_over_inherited'))>1
        assert int(row['mts_bands'])==2 and int(row['nfw_bands'])==(2 if row['host']=='anchorA' else 4)
    assert all(float(r['min_reflection_breaking_vector'])==0 for r in read('reflection.csv'))
    assert all(r['passes_relative_2e_minus5']=='False' for r in read('sparse-source-integral.csv'))
    assert all(r['passes_original_tolerance']=='False' for r in read('timestep.csv'))
    native=HOME.parent/'mts-fire-581-formation-state-20261120'
    early=HOME.parent/'mts-pre572-wave-preparation-20261120'
    compared=0;miss=0;flips=0
    for host in ('anchorA','cut1','cut2'):
        for folder,kind in ((native,'joint'),(early,'two'),(early,'three')):
            pair=[]
            for steps in (32,64):
                fname=f'bands-{host}-{kind}-{steps}.csv'
                path=folder/fname;manifest=json.loads((folder/'seal.json').read_bytes())['files']
                assert digest(path)==manifest[fname]
                with path.open(newline='') as inp:
                    pair.append({(r['history'],r['model'],r['R'],r['z'],r['component']):r for r in csv.DictReader(inp)})
            assert pair[0].keys()==pair[1].keys() and len(pair[0])==96
            for key,co in pair[0].items():
                fine=pair[1][key];value=float(fine['total'])
                miss+=abs(float(co['total'])-value)>2e-5*abs(value);flips+=co['inside']!=fine['inside'];compared+=1
    assert compared==864 and not miss and not flips
    sums={}
    for steps in (32,64):
        rows=read(f'paired-balance-{steps}.csv')
        assert [int(r['start']) for r in rows]==[572,579,581,586,590]
        assert [int(r['stop']) for r in rows]==[579,581,586,590,600]
        assert max(float(r['max_endpoint_error']) for r in rows)<1e-8
        assert max(float(r['max_step_defect']) for r in rows)<1e-8
        sums[steps]={k:sum(float(r[k]) for r in rows) for k in ('ordinary','common_self','density_contrast','net')}
        defect=sum(sums[steps][k] for k in ('ordinary','common_self','density_contrast'))-sums[steps]['net']
        assert abs(defect)<1e-8
        assert abs(sums[steps]['net']-(float(rows[-1]['end_distance'])-float(rows[0]['start_distance'])))<1e-8
    relative={k:abs(sums[32][k]/v-1) for k,v in sums[64].items()}
    assert all(sums[32][k]*v>0 for k,v in sums[64].items())
    publish('validation.json',dict(counts=counts,paired_original_signed_totals=compared,original_timestep_misses=miss,
           original_band_flips=flips,paired_refinement_relative=relative,paired_totals=sums),save)
    files=sorted([*('PROTOCOL.md DERIVATION.md RESULTS.md measure.py full_force.py score.py inherit.py rate.py pair.py verify.py measurement-lock.json force-lock.json validation.json'.split()),*(key+'.csv' for key in counts)])
    publish('seal.json',{name:digest(HOME/name) for name in files},save)
    print('verified',len(files),'files,',compared,'signed coarse/fine totals; seal',digest(HOME/'seal.json'))
if __name__=='__main__':
    assert sys.argv[1:] in ([],['--save'])
    validate(bool(sys.argv[1:]))
