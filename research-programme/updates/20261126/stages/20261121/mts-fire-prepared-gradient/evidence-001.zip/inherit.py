"""Contrast the same late drive with and without pre-572 wave preparation."""
from measure import Elements,FIRE,HERE,OLD,ROOT,SOURCES,check,jf,np,pinned,records,sys,table
from full_force import Readout

EARLY=ROOT/'mts-pre572-wave-preparation-20261120'
SOURCES[EARLY]='ce9ca0f03916af1fa3bfd449a61e779a74ce3427fae0a3a6bcdf65bc2b6c70ee'

def distance(left,right,metric):
    phase=np.exp(-1j*np.angle(np.vdot(left,right)))
    delta=phase*right-left
    central=np.vdot(delta,delta).real
    return central,central*metric

def shell_checks(el,rules):
    bg=el.bg;radius=bg.rad
    for element,exterior in ((1,False),(-2,True)):
        low=el.left[element];high=el.right[element]
        before=high<min(np.hypot(rad,1.5)/bg.length for rad in (6.,8.3))
        after=low>max(np.hypot(rad,1.5)/bg.length for rad in (6.,8.3))
        assert after if exterior else before
        wave=np.zeros(bg.hshape);wave[:,0]=np.where((radius>low)&(radius<high),(radius-low)*(high-radius),0)*bg.sqrt
        reference=el.nodes(wave.ravel())
        from scipy.constants import parsec
        total=(high-low)**5/30
        mass=np.linalg.norm(el.mass@reference)**2
        assert abs(mass/total-1)<1e-11
        for rad,rule in zip((6.,8.3),rules,strict=True):
            field=rule(reference);scale=bg.vel**2/bg.length*(1e13/parsec)
            expected=-total*scale/(np.hypot(rad,1.5)/bg.length)**2
            assert abs(field[1])<1e-10*abs(expected)
            assert abs(field[0]-(0 if exterior else expected))<1e-10*abs(expected)

def run(save):
    prepared=[];observed=[];checks=[]
    scores=records(HERE/'comparisons.csv')
    for host in ('anchorA','cut1','cut2'):
        check();obj=jf.Assembly(host);el=Elements(obj.bg);number=obj.number
        units=obj.bg.vel**2/(2*number);enclose=el.enclosure*(1+1e-11)
        ground=el.normalize(obj.ground,number)[0]
        ground_emb=el.embed(ground)
        rules=[Readout(el,rad,28) for rad in (6.,8.3)]
        shell_checks(el,rules)
        def field(vec):return np.concatenate([rule(el.nodes(vec)) for rule in rules])
        ground_field=field(ground)
        with np.load(pinned(EARLY,f'ground-{host}.npz')) as pkt:
            entry_ref=el.normalize(pkt['matching'],number)[0]
        for steps in (32,64):
            with np.load(pinned(OLD,f'wave-{host}-joint-{steps}-572_579_586_590_600.npz')) as src:
                first=el.normalize(src['states'][0],number)[0]
            with np.load(pinned(FIRE,f'wave-{host}-joint-{steps}.npz')) as src:
                resets={572:first,**{int(epoch):el.normalize(vec,number)[0] for epoch,vec in zip(src['snapshots'],src['states'],strict=True)}}
            assert set(resets)=={572,579,581,586,590,600}
            reset_check=distance(el.embed(entry_ref),el.embed(first),enclose)[1]*units
            assert reset_check<1e-10
            if steps==64:
                with np.load(pinned(EARLY,f'state-{host}-reset-64.npz')) as replay:
                    for epoch,state in zip(replay['snapshots'],replay['states'],strict=True):
                        leftover=distance(el.embed(el.normalize(state,number)[0]),el.embed(resets[int(epoch)]),enclose)[1]*units
                        assert leftover<1e-10
            for history in ('two','three'):
                tag=f'{host}-{history}-{steps}'
                with np.load(pinned(EARLY,'state-'+tag+'.npz')) as saved:
                    assert set(saved['snapshots'])==set(resets)|({544,558} if history=='three' else {544})
                    inherited={int(epoch):el.normalize(vec,number)[0] for epoch,vec in zip(saved['snapshots'],saved['states'],strict=True)}
                traj=[r for r in scores if r['host']==host and int(r['steps'])==steps and r['model']=='MTS']
                assert len(traj)==6
                for epoch,base in resets.items():
                    current=inherited[epoch];base_emb=el.embed(base);current_emb=el.embed(current)
                    dist,upper=distance(base_emb,current_emb,enclose)
                    whole,whole_upper=distance(ground_emb,current_emb,enclose)
                    effect=field(current)-field(base)
                    if epoch==572:entry=dist
                    prepared.append(dict(host=host,steps=steps,history=history,epoch=epoch,
                          inherited_gradient_kms2=units*dist,inherited_upper_kms2=units*upper,relative_to_entry_squared=dist/entry,
                          combined_gradient_from_final_ground_kms2=units*whole,combined_upper_kms2=units*whole_upper,
                          **dict(zip(('inherited_inner_radial','inherited_inner_polar','inherited_outer_radial','inherited_outer_polar'),effect,strict=True))))
                    if epoch!=600:continue
                    induced=field(current)-ground_field
                    archive=records(pinned(EARLY,'bands-'+tag+'.csv'))
                    counts={}
                    for direct in traj:
                        label=direct['history']
                        for model in ('MTS','static_NFW'):
                            selected=[r for r in archive if r['history']==label and r['model']==model]
                            assert len(selected)==8
                            inside=0
                            for item in selected:
                                index=2*int(float(item['R'])!=6)+int(item['component']=='polar')
                                sign=-1 if index%2 and float(item['z'])<0 else 1
                                correction=sign*induced[index] if model=='MTS' else 0
                                assert abs(float(item['induced'])-correction)<1e-8
                                value=float(item['ground'])+correction
                                flag=float(item['low'])<=value<=float(item['high'])
                                assert flag==(item['inside']=='True');inside+=flag
                            counts[model]=inside
                        observed.append(dict(host=host,steps=steps,early_history=history,direct_history=label,
                            ground_required_over_combined=float(direct['ground_required_kms2'])/(units*whole_upper),
                            endpoint_required_over_inherited=float(direct['endpoint_required_kms2'])/(units*upper),
                            mts_bands=counts['MTS'],nfw_bands=counts['static_NFW']))
                checks.append(dict(host=host,steps=steps,history=history,entry_reset_disagreement_kms2=reset_check))
    assert len(prepared)==72 and len(observed)==72 and len(checks)==12
    for name,data in [('inheritance',prepared),('inheritance-comparison',observed),('reset-checks',checks)]:
        table(HERE/(name+'.csv'),data,save)
    print('verified 12 inherited wave histories, including their matched reset comparison and two spherical controls')
if __name__=='__main__':
    assert sys.argv[1:] in ([],['--save'])
    run(bool(sys.argv[1:]))
