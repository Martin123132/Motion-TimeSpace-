"""Open the two saved locks; compare the force to its host's own bands."""
from collections import defaultdict
from measure import BOUND,CENSUS,FIRE,HERE,check,json,np,pinned,records,sha,sys,table

def lower(gap,base_d,scale,constant,units):
    demand=gap/(scale*constant)
    return units*(demand/(np.sqrt(base_d+demand)+np.sqrt(base_d)))**2

def run(save):
    check()
    for lock in ('measurement-lock.json','force-lock.json'):
        for name,expected in json.loads((HERE/lock).read_bytes()).items():assert sha(HERE/name)==expected
    const=float(json.loads(pinned(BOUND,'sharp-certificate.json').read_bytes())['upper_decimal'])
    from scipy.constants import parsec
    measured=records(HERE/'gradients.csv');force=records(HERE/'full-forces.csv')
    census=records(pinned(CENSUS,'census-limited-forces.csv'))
    detail=[];summary=[];symmetry=[];spreads=[]
    for host in ('anchorA','cut1','cut2','raw_m12i'):
        snapshot=[row for row in measured if row['host']==host and int(row['epoch'])==600]
        coarse,fine=sorted(snapshot,key=lambda row:int(row['steps']))
        asnum=lambda row,key:float(row[key])
        dco,dfi=[asnum(row,'specific_upper') for row in (coarse,fine)]
        spread=abs(dco-dfi)/dfi
        spreads.append(dict(host=host,coarse_kms2=dco,fine_kms2=dfi,relative_difference=spread,
                            passes_original_tolerance=spread<=2e-5))
        if host=='raw_m12i':continue
        for row in (coarse,fine):
            steps=int(row['steps'])
            outcomes=records(pinned(FIRE,f'bands-{host}-joint-{steps}.csv'))
            lookup={(r['host'],float(r['R']),r['component']):r for r in force if int(r['steps'])==steps and int(r['epoch'])==600}
            scale=float(row['velocity_kms'])**2*(1e13/parsec)/float(row['length_kpc'])
            units=float(row['velocity_kms'])**2/(2*float(row['number']))
            group=defaultdict(list)
            assert len(outcomes)==96 and len(set(o['history'] for o in outcomes))==6
            for item in outcomes:
                hist,model=item['history'],item['model']
                radius=float(item['R']);height=float(item['z']);component=item['component']
                source,=[r for r in census if (r['foreground'],r['history'],r['model'],float(r['R']),float(r['z']),r['component'])==
                         (host,hist,model,radius,height,component)]
                lo,hi=float(item['low']),float(item['high'])
                assert (lo,hi)==(float(source['low']),float(source['high']))
                ordinary=float(source['ordinary'])+float(source['direct_LMC'])
                sign=-1 if component=='polar' and height<0 else 1
                native=lookup[host,radius,component]
                if model=='MTS':
                    background=ordinary+sign*float(native['ground']);shift=sign*float(native['delta'])
                    assert abs(float(source['dark'])-sign*float(native['native_ground']))<1e-11
                    assert abs(float(item['induced'])-sign*float(native['native_delta']))<1e-11
                else:
                    assert model=='static_NFW'
                    background=ordinary+float(source['dark']);shift=0.
                end=background+shift
                assert abs(background-float(item['ground']))<1e-8 and abs(end-float(item['total']))<1e-8
                inside=lo<=end<=hi
                assert inside==(item['inside']=='True')
                group[hist,model].append(dict(R=radius,z=height,component=component,ground=background,total=end,lo=lo,hi=hi,inside=inside))
            for (hist,model),items in group.items():
                assert len(items)==8
                limits=[];gaps=[];more=[];post=[]
                for radius in (6.,8.3):
                    north_south=[]
                    for height in (-1.5,1.5):
                        comps=[next(i for i in items if (i['R'],i['z'],i['component'])==(radius,height,component))
                               for component in ('radial','polar')]
                        def gap(key):
                            return np.linalg.norm([np.clip(i[key],i['lo'],i['hi'])-i[key] for i in comps])
                        before,after=gap('ground'),gap('total');gaps.append(before);post.append(after)
                        intervals=[sorted([(i[key]-i['ground'])*(-1 if height<0 and i['component']=='polar' else 1)
                                           for key in ('lo','hi')]) for i in comps]
                        north_south.append(intervals)
                        test=model=='MTS'
                        required=lower(before,float(row['ground_gradient_upper']),scale,const,units) if test else ''
                        extra=lower(after,float(row['wave_gradient_upper']),scale,const,units) if test else ''
                        limits.append(required);more.append(extra)
                        detail.append(dict(host=host,steps=steps,history=hist,model=model,R=radius,z=height,ground_gap=before,
                                      evolved_gap=after,required_from_ground_kms2=required,required_from_endpoint_kms2=extra))
                    minimal=[]
                    for south,north in zip(*north_south,strict=True):
                        minimal.append(max(south[0]-north[1],north[0]-south[1],0)/2)
                    symmetry.append(dict(host=host,steps=steps,history=hist,model=model,R=radius,
                           min_reflection_breaking_vector=np.linalg.norm(minimal)))
                budget=float(row['specific_upper'])
                assert min(gaps)>=0
                required=max(limits) if test else ''
                bridge=max(0,np.sqrt(required)-np.sqrt(budget))**2 if test else ''
                summary.append(dict(host=host,steps=steps,history=hist,model=model,bands=sum(i['inside'] for i in items),
                      worst_ground_gap=max(gaps),worst_endpoint_gap=max(post),ground_required_kms2=required,available_kms2=budget if test else '',
                      necessary_over_available=required/budget if test else '',endpoint_required_kms2=max(more) if test else '',
                      triangle_extra_kms2=bridge,remaining_required_kms2=max(bridge,max(more)) if test else ''))
    assert (len(detail),len(summary),len(symmetry),len(spreads))==(288,72,144,4)
    for name,data in [('sites',detail),('comparisons',summary),('reflection',symmetry),('timestep',spreads)]:
        table(HERE/(name+'.csv'),data,save)
    print('verified 288 paired site comparisons; raw FIRE has no Milky Way score')
if __name__=='__main__':
    assert sys.argv[1:] in ([],['--save'])
    run(bool(sys.argv[1:]))
