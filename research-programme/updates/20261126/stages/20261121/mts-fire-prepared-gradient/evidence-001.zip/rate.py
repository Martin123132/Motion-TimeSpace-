"""Resolve the common-metric terms in the instantaneous gradient-separation rate."""
from inherit import EARLY
from measure import CENSUS,FIRE,HERE,OLD,check,jf,np,pinned,records,sys,table
from scipy.linalg import cholesky_banded

def gradient_root(kinetic,shape):
    radial,orders=shape
    matrix=kinetic.tocsr()
    weights=np.zeros((8,radial,orders))
    for index in range(orders):
        block=matrix[index::orders,index::orders]
        lower=np.zeros((8,radial))
        nzrow,nzcol=block.nonzero()
        assert np.max(abs(nzrow-nzcol))<=7
        for band in range(8):lower[band,:radial-band]=block.diagonal(-band)
        weights[:,:,index]=cholesky_banded(lower,lower=True)
    def transform(vec):
        values=vec.reshape(shape)
        result=weights[0]*values
        for band in range(1,8):result[:-band]+=weights[band,:-band]*values[band:]
        return result.ravel()
    return transform

def run(save):
    out=[];integrals=[]
    previous=records(HERE/'inheritance.csv')
    for host in ('anchorA','cut1','cut2'):
        obj=jf.Assembly(host);check()
        kinetic=obj.bg.mesh.kinetic(obj.bg.orders,True)
        grad=gradient_root(kinetic,obj.bg.hshape)
        ordinary=obj.bare-kinetic
        units=obj.bg.vel**2/obj.number;clock=obj.unit_myr
        sample,=[item for item in records(pinned(CENSUS,'equilibria.csv')) if item['branch']==host]
        share=1-float(sample['fraction'])
        for steps in (32,64):
            with np.load(pinned(OLD,f'wave-{host}-joint-{steps}-572_579_586_590_600.npz')) as data:start=data['states'][0]
            with np.load(pinned(FIRE,f'wave-{host}-joint-{steps}.npz')) as data:
                resets={572:start,**dict(zip(map(int,data['snapshots']),data['states'],strict=True))}
            for track in ('two','three'):
                tag=f'{host}-{track}-{steps}'
                with np.load(pinned(EARLY,'state-'+tag+'.npz')) as data:pair=dict(zip(map(int,data['snapshots']),data['states'],strict=True))
                history=records(pinned(EARLY,'track-'+tag+'.csv'))
                own=[]
                for epoch,base in resets.items():
                    test=pair[epoch];base_grad=grad(base);test_grad=grad(test)
                    phase=np.exp(-1j*np.angle(np.vdot(base_grad,test_grad)));eta=phase*test-base
                    gradient=phase*test_grad-base_grad
                    energy=units*np.vdot(gradient,gradient).real
                    assert abs(units*np.vdot(eta,kinetic@eta).real-energy)<1e-9
                    ref,=[r for r in previous if r['host']==host and r['history']==track and int(r['steps'])==steps and int(r['epoch'])==epoch]
                    assert abs(energy/float(ref['inherited_gradient_kms2'])-1)<2e-5
                    phi_base=obj.phi(obj.moment(base));phi_test=obj.phi(obj.moment(test))
                    with np.load(pinned(FIRE if epoch==581 else OLD,f'forcing-{epoch}.npz')) as source:
                        potential=source['joint']*share/obj.bg.vel**2
                    val=lambda vec:2*units*np.vdot(gradient,grad(vec)).imag/clock
                    terms=[val(ordinary@eta+obj.multiply(potential,eta)),val(obj.multiply(phi_test,eta)),
                           val(obj.multiply(phi_test-phi_base,base))]
                    direct_base=(obj.bare@base)+obj.multiply(potential+phi_base,base)
                    direct_test=(obj.bare@test)+obj.multiply(potential+phi_test,test)
                    direct=val(phase*direct_test-direct_base)
                    assert abs(sum(terms)-direct)<1e-10 and abs(val(eta))+abs(val(base))<1e-10,(tag,epoch,terms,direct,val(eta),val(base))
                    def metric(fst,snd):
                        gg=grad(fst);ss=grad(snd)
                        align=np.exp(-1j*np.angle(np.vdot(gg,ss)))
                        diff=ss*align-gg
                        return units*np.vdot(diff,diff).real
                    def centered(eps):
                        return (metric(base-1j*eps*direct_base,test-1j*eps*direct_test)-
                                metric(base+1j*eps*direct_base,test+1j*eps*direct_test))/(2*eps*clock)
                    fd= (4*centered(.0001)-centered(.0002))/3
                    assert abs(fd-direct)<2e-8
                    rec,=[r for r in history if int(r['snapshot'])==epoch]
                    own.append(dict(host=host,history=track,steps=steps,epoch=epoch,time_Myr=float(rec['time_Gyr'])*1000,
                        native_distance_kms2=energy,total_rate=direct,ordinary_rate=terms[0],shared_self_rate=terms[1],
                        differential_self_rate=terms[2],independent_derivative=fd,
                        absolute_split_defect=abs(direct-sum(terms))))
                out.extend(own)
                dates=np.array([r['time_Myr'] for r in own])
                assert np.all(np.diff(dates)>0)
                net=own[-1]['native_distance_kms2']-own[0]['native_distance_kms2']
                estimates={k:np.trapezoid([r[k] for r in own],x=dates) for k in ('ordinary_rate','shared_self_rate','differential_self_rate')}
                estimated=sum(estimates.values())
                integrals.append(dict(host=host,history=track,steps=steps,measured_change=net,
                    six_snapshot_trapezoid=estimated,residual=estimated-net,
                    passes_relative_2e_minus5=abs(estimated-net)<=2e-5*abs(net),**estimates))
    assert len(out)==72 and len(integrals)==12
    for name,data in [('source-rates',out),('sparse-source-integral',integrals)]:table(HERE/(name+'.csv'),data,save)
    print('verified 72 instantaneous source-rate identities and tested the six-snapshot time integral')
if __name__=='__main__':
    assert sys.argv[1:] in ([],['--save'])
    run(bool(sys.argv[1:]))
