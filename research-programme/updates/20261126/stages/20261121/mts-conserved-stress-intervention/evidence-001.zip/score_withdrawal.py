from follow_source import HERE,observer,task,np,name,lock,table

def evaluate(grid,seed,mode,end):
    lock()
    certificate=task.meta(HERE/"forecast-pin.json")
    for key,digest in certificate["files"].items():assert task.lab.sha(HERE/key)==digest
    native={(int(r["flag"]),int(r["tick"]),float(r["width"]),r["field"]):float(r["value"]) for r in
            task.read(observer.HERE/f"g{grid}-s{seed}-apertures.csv") if r["order"]=="12"}
    forecasts={(int(r["seed"]),float(r["width"]),int(1024*float(r["fraction"]))):r
               for r in task.read(HERE/"stress-withdrawal-forecast.csv") if r["order"]=="28"}
    rho=[];rows=[]
    for tick in task.CLOCKS:
        if tick>end:continue
        read=[]
        for flag in (0,1):
            key=name(grid,seed,flag,mode,tick)
            cert=task.meta(HERE/(key+".json"))
            assert cert["sha"]==task.lab.sha(HERE/(key+".npz")) and cert["tick"]==tick
            read.append(cert["readings"])
            with np.load(HERE/(key+".npz")) as bank:
                for area,idx in (("first",bank["r"]<1/grid),("core",bank["r"]<.3),("bulk",(bank["r"]>.6)&(bank["r"]<2.1))):
                    def norm(tag):return np.linalg.norm(bank[tag][idx])
                    total=norm("ind_J")
                    rho.append(dict(flag=flag,tick=tick,region=area,momentum_norm=norm("ind_P"),current_norm=total,
                                    momentum_over_current=norm("ind_P")/total if total else "",hamiltonian_norm=norm("ind_H"),
                                    temporal_change_norm=norm("temporal_profile"),spatial_change_norm=norm("space_profile"),
                                    raw_reader_difference=np.linalg.norm((bank["temporal_profile"]-bank["space_profile"])[idx])))
        for width in (.15,.3):
            prediction=forecasts[seed,width,tick]
            newton=float(prediction["newton"])
            unit=abs(newton)*1e-6
            gain=2 if mode=="reverse" else 1
            for channel in ("temporal","space","neg_weyl","stress","native_stress"):
                refchannel="stress" if channel=="native_stress" else channel
                old=native[0,tick,width,refchannel]-native[1,tick,width,refchannel] if refchannel!="space" or (0,tick,width,"space") in native else None
                changed=(read[0][f"{channel}-{width}"]-read[1][f"{channel}-{width}"])
                removed=(old-changed)/gain
                eligible=channel in ("temporal","space")
                tt=float(prediction["retained_tt"]);hybrid=float(prediction["hybrid"]);flat=float(prediction["full_flat"])
                rows.append(dict(grid=grid,seed=seed,mode=mode,tick=tick,width=width,reader=channel,native=old,
                         changed=changed,removed_per_gain=removed,removed_ppm=removed/unit,
                         newton=newton,newton_only_ppm=(changed-newton)/unit if eligible else "",
                         retained_tt_ppm=tt/unit if eligible else "",hybrid_ppm=hybrid/unit if eligible else "",
                         flat_ppm=flat/unit if eligible else "",removed_minus_tt_ppm=(removed-tt)/unit if eligible else "",
                         removed_minus_hybrid_ppm=(removed-hybrid)/unit if eligible else "",
                         inside_tt=abs(removed-tt)<=20*unit if eligible else "",inside_hybrid=abs(removed-hybrid)<=20*unit if eligible else "",
                         portion_of_native_excess=removed/(old-newton) if eligible and old!=newton else ""))
    table(f"g{grid}-s{seed}-{mode}-score{end}.csv",rows)
    table(f"g{grid}-s{seed}-{mode}-constraints{end}.csv",rho)
    print(grid,seed,mode,end,[(x["width"],round(x["removed_ppm"],3),round(x["hybrid_ppm"],3),round(x["newton_only_ppm"],3))
                                for x in rows if x["tick"]==end and x["reader"]=="temporal"],flush=True)

if __name__=="__main__":
    import sys
    evaluate(int(sys.argv[1]),int(sys.argv[2]),sys.argv[3],int(sys.argv[4]))

