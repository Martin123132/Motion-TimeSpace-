"""Probe changed endpoint motion by finite differences of actual shear histories."""
from follow_source import HERE,task,np,observer,name,lock,switched,table
def run(grid,seed,mode):
    lock();results={}
    native={(int(r["flag"]),r["field"],float(r["width"])):float(r["value"]) for r in task.read(observer.HERE/f"g{grid}-s{seed}-apertures.csv") if r["order"]=="12" and r["tick"]=="1024"}
    for flag in (0,1):
        with task.system(grid,seed,flag) as model,switched(model,mode):
            for tick in (0,1024):
                key=name(grid,seed,flag,mode,tick)
                assert task.lab.sha(HERE/(key+".npz"))==task.meta(HERE/(key+".json"))["sha"]
                with np.load(HERE/(key+".npz")) as bank:
                    state=task.old.Difference(bank["shared"],bank["signed"]);clock=float(bank["clock"])
                raw,fields=observer.fields(model,grid,12,state,clock,True)
                if tick==0:
                    start=fields
                else:
                    for idx in ("temporal","fd2","fd4"):
                        for width,value in zip((.15,.3),observer.annuli(model,raw,start[idx],fields[idx]),strict=True):
                            results[flag,idx,width]=value
    scores=task.read(HERE/f"g{grid}-s{seed}-{mode}-score1024.csv")
    rows=[]
    for width in (.15,.3):
        reference=next(r for r in scores if float(r["width"])==width and r["reader"]=="temporal" and r["tick"]=="1024")
        unit=abs(float(reference["newton"]))*1e-6
        for idx in ("temporal","fd2","fd4"):
            before=native[0,idx,width]-native[1,idx,width]
            after=results[0,idx,width]-results[1,idx,width]
            effect=(before-after)/(2 if mode=="reverse" else 1)/unit
            if idx=="temporal":
                assert abs(effect-float(reference["removed_ppm"]))<1e-5
            rows.append(dict(width=width,method=idx,before=before,after=after,removed_ppm=effect,hybrid_ppm=reference["hybrid_ppm"],
                             minus_hybrid_ppm=effect-float(reference["hybrid_ppm"]),minus_rhs_ppm=effect-float(reference["removed_ppm"])))
    table(f"g{grid}-s{seed}-{mode}-short-time.csv",rows)
    print("short-time readouts",grid,seed,mode,[(r["width"],r["method"],round(r["minus_rhs_ppm"],4)) for r in rows],flush=True)
if __name__=="__main__":
    import sys
    run(int(sys.argv[1]),int(sys.argv[2]),sys.argv[3])

