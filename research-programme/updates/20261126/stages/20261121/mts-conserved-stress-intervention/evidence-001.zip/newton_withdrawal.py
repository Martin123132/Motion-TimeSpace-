"""Global scalar Poisson response of a conserved stress, without a TT projection."""
from causal_forecast import task,HERE,np,lock,matched,write,table,patch,LEVEL,CENTER,weight,leggauss,legvander,lru_cache

@lru_cache(maxsize=96)
def weights(spacing,nodes,edge,width,scale,order):
    half=CENTER*width
    low,high=(CENTER-half)/scale,(CENTER+half)/scale
    edges=np.unique(np.r_[np.arange(round(edge/spacing)+1)*spacing,low,high])
    mid=(edges[:-1]+edges[1:])/2;span=np.diff(edges)/2
    absc,quad=leggauss(order)
    rad=(mid[:,None]+span[:,None]*absc).ravel()
    measure=(span[:,None]*quad).ravel()
    w,dw,ddw=(scale**(i+1)*weight(scale*rad,half,i) for i in range(3))
    def integral(start,stop,power):
        centre=(stop+start)/2;halfspan=(stop-start)/2
        pts=centre[:,None]+halfspan[:,None]*absc
        return halfspan*((scale*weight(scale*pts,half)/pts**power)@quad)
    inside=(rad>low)&(rad<high)
    outer=np.zeros_like(rad);inner=np.zeros_like(rad)
    outer[rad<=low]=integral(np.array([low]),np.array([high]),5)[0]
    outer[inside]=integral(rad[inside],np.full(np.sum(inside),high),5)
    inner[rad>=high]=1.
    inner[inside]=integral(np.full(np.sum(inside),low),rad[inside],0)
    kernel=-w/3+6*rad**4*outer/5+inner/(5*rad)
    first=-dw/3+24*rad**3*outer/5-w/rad-inner/(5*rad**2)
    second=-ddw/3+72*rad**2*outer/5-dw/rad-4*w/rad**2+2*inner/(5*rad**3)
    vec=np.array((second-5*first/rad+11*kernel/rad**2,12*first/rad-36*kernel/rad**2,12*kernel/rad**2))
    cells=(rad/spacing).astype(int);ne=round(edge/spacing)
    basis=legvander(2*(rad/spacing-cells)-1,len(nodes)-1)@np.linalg.inv(legvander(2*np.array(nodes)-1,len(nodes)-1))
    result=np.zeros((3,ne,len(nodes)))
    for idx in range(3):np.add.at(result[idx],cells,(vec[idx]*measure)[:,None]*basis)
    return result

def manufactured():
    import sympy as sp
    r=sp.symbols("r",positive=True);base=sp.exp(-r*r);phi=r*r*base
    def lap(x):return x.diff(r,2)+2*x.diff(r)/r-6*x/r**2
    def tf(x):return x.diff(r,2)-lap(x)/3
    mixed=(r*base.diff(r)+3*base)/6
    velocity=r*base;tang=(r*velocity.diff(r)+2*velocity)/6
    tests=(("TT",(base,mixed,(r*mixed.diff(r)+3*mixed-base/2)/2),0*base),
           ("vector",(velocity.diff(r),(tang.diff(r)-tang/r+velocity/r)/2,tang/r),0*base),
           ("scalar",(tf(phi),phi.diff(r)/r-phi/r**2,phi/r**2),-tf(lap(phi))/3))
    rows=[]
    nodes=tuple((leggauss(12)[0]+1)/2);radius=.2*(np.arange(60)[:,None]+nodes)
    for label,fields,answer in tests:
        actual=np.array(sp.lambdify(r,fields,"numpy")(radius))
        for width in (.15,.3):
            coef=weights(.2,nodes,12.,width,1.,28)
            direct=np.sum(actual*coef)
            absc,q=leggauss(64);half=CENTER*width;pts=CENTER+half*absc
            target=half*np.sum(q*weight(pts,half)*sp.lambdify(r,answer,"numpy")(pts))
            assert abs(direct-target)<5e-11 and (label!="scalar" or abs(target)>.01)
            rows.append(dict(mode=label,width=width,poisson=direct,analytic=target,absolute=abs(direct-target)))
    table("independent-poisson-controls.csv",rows)

def clock(source,scale,time,stride):
    absc,quad=leggauss(8);nodes=(absc+1)/2;w=quad/2
    vel=acc=0.
    for end in range(stride,len(time),stride):
        beg=end-stride;step=time[end]-time[beg]
        def data(fraction):
            size=scale[beg]+fraction*(scale[end]-scale[beg])
            stress=source[beg]+fraction*(source[end]-source[beg])
            return size,size**2*stress
        factors,drive=data(nodes)
        _,inner=data(nodes[:,None]*nodes)
        at_nodes=vel+step*nodes*(inner@w)
        acc+=step*np.sum(w*at_nodes/factors)
        vel+=step*np.sum(w*drive)
    return acc/(LEVEL*scale[-1]**3)

def run():
    lock();manufactured()
    banks={}
    for seed in (1,-1):
        with np.load(task.FORM/f"matched-source-history-p32-s{seed}.npz") as saved:banks[seed]={k:saved[k] for k in saved.files}
    snapshots=[];project=matched.mechanical.tensor.transverse.project
    def capture(grid,raw):
        idx=len(snapshots);seed=(1,-1)[idx//33];bank=banks[seed]
        row={}
        for width in (.15,.3):
            for edge in (36.,72.,144.):
                for scale in (1.,*[float(bank["b"][i]) for i in (8,16,24,32)]):
                    coef=weights(float(grid.h),tuple(grid.t),edge,width,scale,24)
                    row[width,edge,scale]=np.sum(coef*raw[:,:coef.shape[1]])
        snapshots.append(row)
        return project(grid,raw)
    def replay(name,**items):
        seed=1 if "s1." in name else -1
        for key,item in items.items():np.testing.assert_array_equal(item,banks[seed][key])
    with matched.route(),patch.object(matched.mechanical.tensor.transverse,"project",capture),patch.object(matched.mechanical,"packet",replay),patch.object(matched.mechanical,"table",lambda *args:None):
        matched.mechanical.history(32)
    assert len(snapshots)==66
    reference={(int(r["seed"]),float(r["width"]),float(r["fraction"])):r for r in task.read(HERE/"stress-withdrawal-forecast.csv") if r["order"]=="28"}
    rows=[]
    for seed,bank in banks.items():
        start=0 if seed==1 else 33
        for idx in (8,16,24,32):
            for width in (.15,.3):
                row=reference[seed,width,idx/32]
                unit=abs(float(row["newton"]))*1e-6
                for edge in (36.,72.,144.):
                    for mode in ("flat","expanding"):
                        b=bank["b"][:idx+1] if mode=="expanding" else np.ones(idx+1)
                        times=(np.sqrt(LEVEL)*bank["xi"][:idx+1] if mode=="expanding" else
                               np.sqrt(LEVEL)*matched.core.DURATION*np.arange(idx+1)/32)
                        values=np.array([snapshots[start+i][width,edge,float(b[-1])] for i in range(idx+1)])
                        response=clock(values,b,times,1)
                        rows.append(dict(seed=seed,width=width,fraction=idx/32,outer=edge,clock=mode,poisson=response,
                               ppm=response/unit,two_panel_spread_ppm=(clock(values,b,times,2)-response)/unit,
                               minus_projector_companion_ppm=(response-float(row["scalar"]))/unit))
    table("newton-conserved-source.csv",rows)
    write("poisson-pin.json",dict(source=task.lab.sha(HERE/"newton_withdrawal.py"),plan=task.lab.sha(HERE/"NEWTON-CONTROL.md"),
           controls=task.lab.sha(HERE/"independent-poisson-controls.csv"),values=task.lab.sha(HERE/"newton-conserved-source.csv")))
    print("separate Poisson results",[(r["seed"],r["width"],r["clock"],round(r["ppm"],5),round(r["minus_projector_companion_ppm"],6)) for r in rows if r["outer"]==144 and r["fraction"]==1])
if __name__=="__main__":run()
