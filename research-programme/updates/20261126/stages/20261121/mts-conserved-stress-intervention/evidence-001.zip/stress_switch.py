"""Conserved angular stress interventions, preserving the parent's physical solver."""
import csv
import io
import json
import sys
from contextlib import contextmanager
from pathlib import Path

HERE=Path(__file__).resolve().parent
PARENT=HERE.parent/"mts-curved-tidal-source-20261121"
sys.path.insert(0,str(PARENT))
import time_space_tide as observer
from time_space_tide import np,task
from trial import pair
from unittest.mock import patch

PIN="f4e5d2d3225906666dbad4261215d8ce9f19fbd14c70ff972559064fd2a60815"
MODES={"off":(-1,-1),"reverse":(-2,-2),"material":(-1,0),"environment":(0,-1),"native":(0,0)}

def guard():
    task.guard()
    if (HERE/"STOP-REQUESTED").exists():raise RuntimeError("owner hold")

def freeze():
    guard()
    assert task.lab.sha(PARENT/"seal.json")==PIN
    for name,digest in task.meta(PARENT/"seal.json")["files"].items():
        assert task.lab.sha(PARENT/name)==digest,name
    write("design.json",dict(parent=PIN,design=task.lab.sha(HERE/"DESIGN.md"),switch=task.lab.sha(Path(__file__)),modes=MODES))

def write(name,obj):
    guard()
    task.lab.put(HERE/name,(json.dumps(obj,indent=2,allow_nan=False)+"\n").encode())

def table(name,rows):
    guard()
    out=io.StringIO(newline="")
    writer=csv.DictWriter(out,rows[0],lineterminator="\n")
    writer.writeheader()
    writer.writerows(rows)
    task.lab.put(HERE/name,out.getvalue().encode())

def lock():
    guard()
    spec=task.meta(HERE/"design.json")
    assert spec["parent"]==task.lab.sha(PARENT/"seal.json")==PIN
    assert spec["switch"]==task.lab.sha(Path(__file__)) and spec["design"]==task.lab.sha(HERE/"DESIGN.md")
    return task.lab.sha(HERE/"design.json")

def select(model,time,sources,mode):
    internal,outer=MODES[mode]
    native=(sources[2][1],sources[3],sources[4])
    env=model.shell.incident.external(time)[4:7]
    return tuple(internal*(tot-ext)+outer*ext for tot,ext in zip(native,env,strict=True))

def rates(model,geo,bg,shear,drives):
    normal,cross,tensor=drives
    shell=model.shell
    radius=shell.r
    radial=np.exp(-bg["ell"])
    tangent=np.exp(-bg["bend"])/radius
    curvature=2*radial*(1/radius+bg["bg"])
    blank=0*normal
    div_r,div_t=model.lift.divergence(pair(blank,blank),pair(blank,normal),cross,tensor,geo,bg)
    return {5:-normal,6:-div_r,7:-div_t,17:1.5*shear*normal,
            18:-radial*shell.diff(normal)-1.5*curvature*normal+6*tangent*cross,
            19:-radial*(shell.diff(cross)+3*(1/radius+bg["bg"])*cross)+tangent*(normal/2+2*tensor)}

@contextmanager
def switched(model,mode):
    assert mode in MODES
    if mode=="native":
        yield
        return
    native_sources=task.evolve8.sources
    def revised(own,time,state,change,geo,bg,velocity,result):
        assert own is model
        values=[]
        def capture(*args):
            calculated=native_sources(*args)
            values.append(calculated)
            return calculated
        with patch.object(task.evolve8,"sources",capture):
            output=task.revised(model,time,state,change,geo,bg,velocity,result)
        assert len(values)==1
        drives=select(model,time,values[0],mode)
        for slot,rate in rates(model,geo,bg,model.shell.initial[5,0].real+change[5,0].real,drives).items():
            output[slot,1]+=rate
        return output
    with patch.object(task.evolve8,"revise",revised):yield

@contextmanager
def explicit(model,time,drives):
    incoming=model.shell.incident
    original=incoming.external
    def changed(when):
        assert when==time
        ordinary=original(when)
        return (*ordinary[:4],*(field+extra for field,extra in zip(ordinary[4:],drives,strict=True)))
    with patch.object(incoming,"external",changed):yield

def budget(model,state,time,mode):
    real=task.lab.rawfield(model,state,time)
    source=task.evolve8.sources(model,time,real)
    return select(model,time,source,mode)

def test(grid,seed):
    lock()
    rows=[]
    for flag in (0,1):
        with task.system(grid,seed,flag) as model:
            for tick in (0,512,1024):
                state,time=observer.state_at(grid,seed,flag,tick,12)
                rhs=model.rhs if flag else model.nonlinear
                original=rhs(time,state)
                for mode in ("off","reverse","material","environment"):
                    correction=budget(model,state,time,mode)
                    with explicit(model,time,correction):
                        actual=rhs(time,state)
                        physical=task.lab.rawfield(model,state,time)
                        total=task.evolve8.sources(model,time,physical)
                    with switched(model,mode):
                        formula=rhs(time,state)
                    for key in ("base","delta"):
                        measured=getattr(actual,key)
                        predicted=getattr(formula,key)
                        ref=getattr(original,key)
                        mask=measured!=ref
                        assert not mask[:,0].any()
                        other=mask.copy()
                        other[[5,6,7,17,18,19],1]=False
                        assert not other.any(),np.where(other)
                        assert np.isfinite(predicted).all()
                        for idx in (5,6,7,17,18,19):
                            norm=np.linalg.norm
                            difference=norm((measured-predicted)[idx,1])
                            response=norm((measured-ref)[idx,1])
                            magnitude=norm(measured[idx,1])+norm(ref[idx,1])
                            assert difference<=4e-12*magnitude+2e-10*response+1e-70,(grid,seed,flag,tick,mode,key,idx,difference,response,magnitude)
                            rows.append(dict(flag=flag,tick=tick,mode=mode,part=key,slot=idx,difference=difference,
                                             induced=response,rate_scale=magnitude,relative_to_induced=difference/response if response else ""))
                    if mode=="off":
                        original_sources=task.evolve8.sources(model,time,physical)
                        for orig,net in zip((original_sources[2][1],*original_sources[3:]),(total[2][1],*total[3:]),strict=True):
                            for key in ("base","delta"):
                                assert np.max(abs(getattr(net,key)))<=1e-14*(np.max(abs(getattr(orig,key)))+np.max(abs(getattr(correction[0],key))))+1e-60
    table(f"g{grid}-s{seed}-stress-source-controls.csv",rows)
    print(grid,seed,len(rows),"explicit source comparisons",flush=True)

if __name__=="__main__":
    if sys.argv[1:]==["freeze"]:freeze()
    else:test(*map(int,sys.argv[1:]))

