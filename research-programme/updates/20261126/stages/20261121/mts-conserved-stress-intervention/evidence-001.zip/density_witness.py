"""Exterior-independent radial Newtonian tide from the actual conserved density."""
from follow_source import HERE,task,np,observer,lock,name,table
from numpy.polynomial.legendre import leggauss
from scipy.interpolate import CubicSpline
from scipy.special import gammainc,gamma
from functools import lru_cache

CENTER=observer.core.ep.CENTER
weight=observer.core.ep.weight

def density_kernel(rad,width,scale,order):
    half=CENTER*width
    low,high=(CENTER-half)/scale,(CENTER+half)/scale
    nodes,mass=leggauss(order)
    def integral(start,stop,deg):
        span=(stop-start)/2;mid=(start+stop)/2
        values=mid[:,None]+span[:,None]*nodes
        return span*((scale*weight(scale*values,half)/values**deg)@mass)
    w=scale*weight(scale*rad,half)
    outer=np.zeros_like(rad);inner=np.zeros_like(rad);active=(rad>low)&(rad<high)
    outer[rad<=low]=integral(np.array([low]),np.array([high]),5)[0]
    outer[active]=integral(rad[active],np.full(np.sum(active),high),5)
    inner[rad>=high]=1.
    inner[active]=integral(np.full(np.sum(active),low),rad[active],0)
    return -w/3+6*rad**4*outer/5+inner/(5*rad)

@lru_cache(maxsize=96)
def form(grid,edge,scale,order):
    loc=(np.arange(3*grid)+.5)/grid
    corners=[CENTER*(1+sign*fraction)/scale for fraction in (.15,.3) for sign in (-1,1)]
    ends=np.unique(np.r_[0.,loc[loc<edge],corners,edge])
    span=np.diff(ends)/2;mid=(ends[1:]+ends[:-1])/2
    quad,mass=leggauss(order)
    radius=(mid[:,None]+span[:,None]*quad).ravel();factor=(span[:,None]*mass).ravel()
    left,right=(density_kernel(radius,width,scale,max(24,order)) for width in (.15,.3))
    assert np.all((left-right)[radius>max(corners)]==0)
    return radius,(left-right)*factor,left*factor,right*factor

def project(grid,samples,params,kind):
    radius,contrast,narrow,wide=form(grid,*params)
    nodes=(np.arange(3*grid)+.5)/grid
    if kind=="linear":
        vals=np.interp(radius,np.r_[-nodes[0],nodes],np.r_[samples[0],samples])
    else:
        vals=CubicSpline(np.r_[-nodes[3::-1],nodes],np.r_[samples[3::-1],samples])(radius)
    return [float(np.dot(coef,vals)) for coef in (contrast,narrow,wide)]

def exact():
    output=[]
    for grid in (320,640):
        for order in (8,16):
            rad,delta,_,_=form(grid,2.8,1.,order)
            integration=np.dot(delta,rad**2*np.exp(-rad**2))
            readings=[]
            absc,q=leggauss(64)
            for width in (.15,.3):
                half=CENTER*width;pos=CENTER+half*absc
                tidal=(-pos**2*np.exp(-pos**2)/3+(3/5)*gamma(3.5)*gammainc(3.5,pos**2)/pos**5+np.exp(-pos**2)/10)
                readings.append(np.dot(q,weight(pos,half)*tidal)*half)
            err=abs(integration-(readings[0]-readings[1]))
            assert abs(integration)>1e-6 and err<1e-13
            output.append(dict(grid=grid,order=order,adjoint=integration,analytic=readings[0]-readings[1],absolute=err))
    table("exterior-cancelling-controls.csv",output)

def run(grid,seed,mode):
    lock()
    with np.load(task.FORM/f"matched-source-history-p32-s{seed}.npz") as bank:
        scale=bank["b"].copy()
    frames={}
    for flag in (0,1):
        with task.system(grid,seed,flag) as model:
            for tick in task.CLOCKS:
                original,time=observer.state_at(grid,seed,flag,tick,12)
                key=name(grid,seed,flag,mode,tick)
                assert task.lab.sha(HERE/(key+".npz"))==task.meta(HERE/(key+".json"))["sha"]
                with np.load(HERE/(key+".npz")) as data:
                    revised=task.old.Difference(data["shared"],data["signed"])
                values=[]
                for state in (original,revised):
                    phys=task.lab.rawfield(model,state,time)
                    energy=task.evolve8.sources(model,time,phys)[0][1]
                    reservoir=phys[17,1].real
                    values.append((energy.delta,reservoir.delta))
                total,outer=(a-b for a,b in zip(*values))
                frames[flag,tick]=dict(total=total,reservoir=outer,material=total-outer)
    predicted=task.read(HERE/"newton-conserved-source.csv")
    forecasts=task.read(task.FORM/"matched-gravity-prediction.csv")
    rows=[]
    for tick in task.CLOCKS:
        b=float(scale[tick//32]);fraction=tick/1024
        ref={float(r["width"]):float(r["poisson"]) for r in predicted if int(r["seed"])==seed and float(r["fraction"])==fraction and r["outer"]=="144.0" and r["clock"]=="expanding"}
        unit=abs(next(float(r["matched_newton"]) for r in forecasts if int(r["seed"])==seed and float(r["width"])==.15 and float(r["fraction"])==fraction))*1e-6
        expected=ref[.15]-ref[.3]
        for sector in frames[0,tick]:
            samples=(frames[0,tick][sector]-frames[1,tick][sector])*1024/(2 if mode=="reverse" else 1)
            for interp in ("linear","cubic"):
                for edge in (2.,2.8):
                    for order in (8,16):
                        reading,narrow,wide=project(grid,samples,(edge,b,order),interp)
                        rows.append(dict(grid=grid,seed=seed,mode=mode,tick=tick,sector=sector,interp=interp,outer=edge,order=order,
                                         density_contrast=reading,partial_narrow=narrow,partial_wide=wide,
                                         scalar_forecast=expected if sector=="total" else "",
                                         residual_ppm=(reading-expected)/unit if sector=="total" else "",contrast_ppm=reading/unit,
                                         forecast_ppm=expected/unit,relative=(reading-expected)/abs(expected) if expected and sector=="total" else ""))
    table(f"g{grid}-s{seed}-{mode}-actual-density.csv",rows)
    print(grid,seed,mode,"actual/forecast contrast at end",[(r["sector"],r["contrast_ppm"],r["forecast_ppm"]) for r in rows if r["tick"]==1024 and r["interp"]=="cubic" and r["outer"]==2.8 and r["order"]==16])
if __name__=="__main__":
    import sys
    if sys.argv[1:]==["control"]:exact()
    else:run(int(sys.argv[1]),int(sys.argv[2]),sys.argv[3])

