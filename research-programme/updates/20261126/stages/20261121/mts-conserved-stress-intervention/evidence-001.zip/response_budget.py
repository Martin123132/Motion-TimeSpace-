from stress_switch import HERE,task,table

def report(cases):
    rows=[]
    for grid,seed,mode in cases:
        scores=task.read(HERE/f"g{grid}-s{seed}-{mode}-newton-twin1024.csv")
        control=task.read(HERE/f"g{grid}-s{seed}-{mode}-score1024.csv")
        for data in scores:
            if data["reader"]!="temporal":continue
            tick=int(data["tick"]);width=float(data["width"])
            def get(reader,field):
                return float(next(r[field] for r in control if r["reader"]==reader and int(r["tick"])==tick and float(r["width"])==width))
            unit=abs(float(data["native_newton"]))*1e-6
            tensor=float(data["tt_plus_contact_ppm"])
            poisson=float(data["source_poisson"])/unit
            removed=get("temporal","removed_ppm")
            observed=removed-poisson
            native=get("temporal","native")
            native_excess=(native-float(data["native_newton"]))/unit
            other=native_excess-observed
            denominator=abs(tensor)
            assert denominator>0 and abs(tensor+poisson)>0
            rows.append(dict(grid=grid,sign=seed,mode=mode,tick=tick,width=width,time_removal_ppm=removed,space_removal_ppm=get("space","removed_ppm"),
                             poisson_ppm=poisson,transverse_plus_contact_ppm=tensor,measured_beyond_poisson_ppm=observed,
                             transfer_ratio=observed/tensor,total_transfer_ratio=removed/(tensor+poisson),
                             spatial_reader_shift_fraction=abs(get("space","removed_ppm")-removed)/denominator,
                             native_excess_ppm=native_excess,remaining_after_response_ppm=other))
    table("source-transfer-budget.csv",rows)
    for grid,seed,mode in cases:
        sub=[x for x in rows if (x["grid"],x["sign"],x["mode"])==(grid,seed,mode)]
        print(grid,seed,mode,"source transfer",min(x["transfer_ratio"] for x in sub),max(x["transfer_ratio"] for x in sub),
              "end remainder",[(r["width"],round(r["remaining_after_response_ppm"],4)) for r in sub if r["tick"]==1024])

if __name__=="__main__":
    from verify_campaign import CAMPAIGN
    report(CAMPAIGN)
