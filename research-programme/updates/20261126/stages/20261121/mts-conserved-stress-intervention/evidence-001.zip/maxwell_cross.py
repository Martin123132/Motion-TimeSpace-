from stress_switch import HERE,task,table,np
from itertools import combinations,product
from numpy.polynomial import Polynomial
from numpy.polynomial.legendre import leggauss
import sympy as sp

def vertex():
    axes=sp.symbols("t x y z")
    time,_,__,distance=axes
    metric=sp.diag(-1,1,1,1)
    plus=time**3*distance+2*time*distance**2
    cross=time**2-distance**3
    scale=time**2*distance**2+time*distance**3
    def field(sign):
        tensor=sp.zeros(4)
        tensor[0,1]=1;tensor[3,1]=sign
        return tensor-tensor.T
    forward,reverse=field(1),field(-1)
    rows=[]
    for case in ("plus","cross","linear combination","transverse trace"):
        change=sp.zeros(4)
        if case in ("plus","linear combination"):
            change[1,1]=plus;change[2,2]=-plus
        if case in ("cross","linear combination"):change[1,2]=change[2,1]=cross
        if case=="transverse trace":change[1,1]=change[2,2]=scale
        def riemann(i,j,k,l):
            return (change[i,l].diff(axes[j],axes[k])+change[j,k].diff(axes[i],axes[l])
                    -change[i,k].diff(axes[j],axes[l])-change[j,l].diff(axes[i],axes[k]))/2
        ric=sp.Matrix(4,4,lambda j,l:sum(metric[i,i]*riemann(i,j,i,l) for i in range(4)))
        scalar=sp.trace(metric*ric)
        def weyl(i,j,k,l):
            return (riemann(i,j,k,l)-(metric[i,k]*ric[j,l]-metric[i,l]*ric[j,k]-metric[j,k]*ric[i,l]+metric[j,l]*ric[i,k])/2
                    +scalar*(metric[i,k]*metric[j,l]-metric[i,l]*metric[j,k])/6)
        total=0
        for i,j,k,l in product(range(4),repeat=4):
            coeff=forward[i,j]*reverse[k,l]+reverse[i,j]*forward[k,l]
            if coeff:total+=coeff*weyl(i,j,k,l)
        actual=sp.expand(total)
        expected=4*(-scale.diff(time,2)+scale.diff(distance,2))/3 if case=="transverse trace" else 0
        assert sp.expand(actual-expected)==0
        assert (actual!=0)==(case=="transverse trace")
        rows.append(dict(polarization=case,vertex_per_fg=str(actual),exact_error=0))
    table("maxwell-weyl-vertices.csv",rows)

def packet(centre,width,scale,tilt):
    variable=Polynomial([0,1])
    mask=(1-variable**2)**4*(1+tilt*variable)*scale
    integral=mask.integ()
    def evaluate(points,degree=0):
        unit=(np.asarray(points)-centre)/width
        if degree==-1:return width*(integral(np.clip(unit,-1,1))-integral(-1))
        return np.where(abs(unit)<1,mask.deriv(degree)(unit)/width**degree,0.)
    return evaluate

def pulses():
    forward=packet(0.,1.,1.,.15);backward=packet(.3,.7,.7,-.1)
    nodes,weights=leggauss(20)
    def metric(time,distance,phase):
        lines=((-1.,distance+time),(1.,distance-time),(1.,-1.),(1.,1.),(-1.,-.4),(-1.,1.))
        breaks={-2.,time}
        for (a,b),(c,d) in combinations(lines,2):
            if a!=c:
                pos=(d-b)/(a-c)
                if -2.<pos<time:breaks.add(pos)
        ends=np.array(sorted(breaks))
        span=np.diff(ends)/2;times=(ends[1:]+ends[:-1])[:,None]/2+span[:,None]*nodes
        low=np.maximum.reduce((distance-time+times,times-1,-.4-times))
        high=np.minimum.reduce((distance+time-times,times+1,1.-times))
        space=np.maximum(0.,high-low)/2
        coordinates=(high+low)[:,:,None]/2+space[:,:,None]*nodes
        front=forward(times[:,:,None]-coordinates)
        back=phase*backward(times[:,:,None]+coordinates)
        electric=front+back;magnetic=front-back
        density=(electric**2+magnetic**2)/2
        stress=density-electric**2
        assert np.max(abs(density-(front**2+back**2)))<1e-14
        assert np.max(abs(electric*magnetic-(front**2-back**2)))<1e-14
        return float((span*(weights@(space*(stress@weights)).T)).sum())
    rows=[]
    for distance in (0.,.47):
        for time in (-1.6,-.21,.1,.43,.86,1.6):
            for phase in (1,-1):
                left,right=time-distance,time+distance
                amplitude=-phase*forward(left,-1)*backward(right,-1)
                tide=-phase*(forward(left,1)*backward(right,-1)+2*forward(left)*backward(right)+forward(left,-1)*backward(right,1))/2
                signal=metric(time,distance,phase)
                assert abs(signal-amplitude)<2e-13
                for step in (.002,.001):
                    values=np.array([metric(time+offset*step,distance,phase) for offset in (-2,-1,0,1,2)])
                    observed=np.array([-1.,16,-30,16,-1])@values/(24*step**2)
                    assert abs(observed-tide)<3e-8,(distance,time,tide,observed)
                    rows.append(dict(z=distance,time=time,phase=phase,step=step,retarded_metric=signal,closed_metric=float(amplitude),
                                     differenced_tide=observed,closed_tide=float(tide),absolute_error=abs(observed-tide)))
    assert max(abs(row["closed_tide"]) for row in rows)>.1
    table("maxwell-interference-tides.csv",rows)
    print(len(rows),"compact-pulse controls",max(row["absolute_error"] for row in rows))
if __name__=="__main__":vertex();pulses()
