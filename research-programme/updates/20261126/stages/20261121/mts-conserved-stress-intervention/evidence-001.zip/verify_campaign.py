"""Verify state identity, source controls, matched aperture scores and the private receipt."""
from stress_switch import HERE,PARENT,PIN,task,np,observer,lock,write
from follow_source import TICKS,name
from score_withdrawal import evaluate
from paired_control import run,reversal
import math
import re

CAMPAIGN=((640,1,"off"),(640,1,"reverse"),(640,-1,"off"),(320,1,"off"))

def validate():
    design=lock()
    for root in (PARENT,observer.PARENT,task.FORM):
        for file,digest in task.meta(root/"seal.json")["files"].items():
            assert task.lab.sha(root/file)==digest,file
    for filename,target in task.meta(HERE/"forecast-pin.json")["files"].items():
        assert task.lab.sha(HERE/filename)==target
    proof=task.meta(HERE/"poisson-pin.json")
    for key,path in (("source","newton_withdrawal.py"),("plan","NEWTON-CONTROL.md"),("controls","independent-poisson-controls.csv"),("values","newton-conserved-source.csv")):
        assert task.lab.sha(HERE/path)==proof[key]
    stencils=task.read(HERE/"scalar-vector-tensor-controls.csv")+task.read(HERE/"independent-poisson-controls.csv")
    assert len(stencils)==12 and all(abs(float(r["error"] if "error" in r else r["absolute"]))<5e-11 for r in stencils)
    assert len(task.read(HERE/"cartesian-retarded-controls.csv"))==16
    assert len(task.read(HERE/"exterior-cancelling-controls.csv"))==4
    vertices=task.read(HERE/"maxwell-weyl-vertices.csv")
    assert len(vertices)==4 and all((r["vertex_per_fg"]!="0")==(r["polarization"]=="transverse trace") for r in vertices)
    pulses=task.read(HERE/"maxwell-interference-tides.csv")
    assert len(pulses)==48 and max(float(r["absolute_error"]) for r in pulses)<3e-8
    solved=0
    for grid,seed,mode in CAMPAIGN:
        ctrls=task.read(HERE/f"g{grid}-s{seed}-stress-source-controls.csv")
        assert len(ctrls)==len({(r["flag"],r["tick"],r["mode"],r["part"],r["slot"]) for r in ctrls})==288
        for flag in (0,1):
            for tick in TICKS:
                key=name(grid,seed,flag,mode,tick)
                cert=task.meta(HERE/(key+".json"))
                assert cert["design"]==design and cert["algorithm"]==task.lab.sha(HERE/"follow_source.py")
                assert cert["tick"]==tick and cert["sha"]==task.lab.sha(HERE/(key+".npz"))
                with np.load(HERE/(key+".npz")) as bank:
                    assert all(np.isfinite(bank[name]).all() for name in bank.files)
                    assert len(bank["r"])==3*grid and cert["clock"]==bank["clock"]
                    if tick==0:
                        assert not np.any(bank["shared"]) and not np.any(bank["signed"])
                    if tick in task.CLOCKS:
                        orig,_=observer.state_at(grid,seed,flag,tick,12)
                        for tag,arr in (("base","shared"),("delta","signed")):
                            np.testing.assert_array_equal(bank[arr][:,0],getattr(orig,tag)[:,0])
                        normal=np.linalg.norm(bank["native_stress_profile"])
                        actual=np.linalg.norm(bank["stress_profile"])
                        assert normal>0
                        if mode=="off":assert actual<1e-12*normal
                        if mode=="reverse":assert np.linalg.norm(bank["stress_profile"]+bank["native_stress_profile"])<1e-12*normal
            solved+=1
        evaluate(grid,seed,mode,1024);run(grid,seed,mode,1024)
        if mode=="reverse":reversal(grid,seed,1024)
        scores=task.read(HERE/f"g{grid}-s{seed}-{mode}-score1024.csv")
        assert len(scores)==len({(r["tick"],r["width"],r["reader"]) for r in scores})==40
        for r in scores:
            if r["reader"] not in ("temporal","space"):continue
            assert (r["inside_hybrid"]=="True")==(abs(float(r["removed_minus_hybrid_ppm"]))<=20)
        density=task.read(HERE/f"g{grid}-s{seed}-{mode}-actual-density.csv")
        assert len(density)==96
        contrasts={(r["tick"],r["sector"],r["interp"],r["outer"],r["order"]):float(r["density_contrast"]) for r in density}
        assert len(contrasts)==96
        for (tick,sector,interp,outer,order),value in contrasts.items():
            if sector=="total":
                parts=[contrasts[tick,s,interp,outer,order] for s in ("reservoir","material")]
                assert abs(value-sum(parts))<1e-30+1e-11*sum(map(abs,parts))
            other=contrasts[tick,sector,interp,"2.8",order]
            assert abs(other-value)<1e-32+1e-11*abs(value)
    for mode in ("off","reverse"):
        fd=task.read(HERE/f"g640-s1-{mode}-short-time.csv")
        assert len(fd)==6 and {r["method"] for r in fd}=={"temporal","fd2","fd4"}
    assert solved==8
    from response_budget import report
    report(CAMPAIGN)
    for doc in HERE.glob("*.md"):
        for link in re.findall(r"\[[^\]]*\]\(([^)]+)\)",doc.read_text(encoding="utf-8")):
            if not link.startswith("https://"):assert (HERE/link).is_file(),link
    files={path.name:task.lab.sha(path) for path in sorted(HERE.iterdir()) if path.is_file() and path.name!="seal.json"}
    counts={}
    for filename in files:
        if not filename.endswith(".csv"):continue
        rows=task.read(HERE/filename);counts[filename]=len(rows)
        for row in rows:
            assert None not in row and None not in row.values()
            for value in row.values():
                try:num=float(value)
                except ValueError:continue
                assert math.isfinite(num)
    write("seal.json",dict(parent=PIN,design=design,trajectories=solved,state_packets=len(TICKS)*solved,files=files,rows=counts))
    print("verified",len(files),"files",sum(counts.values()),"data rows",task.lab.sha(HERE/"seal.json"),flush=True)

if __name__=="__main__":validate()
