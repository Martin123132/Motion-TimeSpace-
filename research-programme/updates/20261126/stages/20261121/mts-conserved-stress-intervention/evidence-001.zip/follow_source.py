"""Safe local restart for complete coupled stress-counterfactual trajectories."""
import sys
import io
from time import perf_counter
from stress_switch import HERE,task,np,observer,switched,budget,guard,lock,write,table,MODES
from trial import pair

TICKS=(0,64,128,192,256,320,384,448,512,576,640,704,768,832,896,960,1024)

def name(grid,seed,flag,mode,tick):
    return f"g{grid}-s{seed}-b{flag}-{mode}-t{tick}"

def save(name,fields):
    assert all(np.isfinite(field).all() for field in fields.values())
    stream=io.BytesIO()
    np.savez_compressed(stream,**fields)
    task.lab.put(HERE/name,stream.getvalue())

def physical_read(model,state,time,mode):
    with switched(model,mode):
        raw,data=observer.fields(model,len(model.shell.r)//3,12,state,time,False)
    correction=budget(model,state,time,mode)[0]
    original=data["stress"]
    compensation=pair(0*correction,correction)
    data["space"]=data["space"]+compensation
    data["stress"]=original+compensation
    data["neg_weyl"]=data["temporal"]-data["stress"]/2
    data["native_stress"]=original
    return raw,data

def run(grid,seed,flag,mode,end=1024):
    design=lock()
    assert (grid,seed) in task.RUNS and flag in (0,1) and mode in MODES and mode!="native" and end in TICKS
    verify=HERE/f"g{grid}-s{seed}-stress-source-controls.csv"
    assert len(task.read(verify))==288
    alg=task.lab.sha(HERE/"follow_source.py")
    with task.system(grid,seed,flag) as model:
        step=4096*np.pi/(1024*model.shell.mu)
        prepared,time0=observer.state_at(grid,seed,flag,0,12)
        assert time0==0 and not np.any(prepared.base) and not np.any(prepared.delta)
        _,initial=physical_read(model,prepared,0.,mode)
        state=prepared
        tick0=-1
        for tick in TICKS:
            if tick>end:break
            key=name(grid,seed,flag,mode,tick)
            receipt,path=HERE/(key+".json"),HERE/(key+".npz")
            if not receipt.is_file():
                assert not path.exists(),key
                assert not any((HERE/(name(grid,seed,flag,mode,later)+".json")).exists() for later in TICKS if later>tick)
                break
            data=task.meta(receipt)
            assert data["design"]==design and data["algorithm"]==alg and data["sha"]==task.lab.sha(path)
            tick0=tick
        if tick0==end:return
        if tick0>=0:
            with np.load(HERE/(name(grid,seed,flag,mode,tick0)+".npz")) as bank:
                state=task.old.Difference(bank["shared"],bank["signed"])
        with switched(model,mode):
            advance=model.time_step(step)
            started=perf_counter()
            for tick in range(tick0+1,end+1):
                if tick%8==0:guard()
                if tick:state=advance((tick-1)*step,state)
                if tick not in TICKS:continue
                clock=tick*step
                key=name(grid,seed,flag,mode,tick)
                values=dict(shared=state.base,signed=state.delta,clock=clock,r=model.shell.r)
                measured={}
                if tick in task.CLOCKS:
                    orig,_=observer.state_at(grid,seed,flag,tick,12)
                    for part in ("base","delta"):
                        np.testing.assert_array_equal(getattr(state,part)[:,0],getattr(orig,part)[:,0])
                    raw,data=observer.fields(model,grid,12,state,clock,False)
                    normal=budget(model,state,clock,mode)[0]
                    compensation=pair(0*normal,normal)
                    data["space"]+=compensation
                    data["native_stress"]=data["stress"]
                    data["stress"]=data["stress"]+compensation
                    data["neg_weyl"]=data["temporal"]-data["stress"]/2
                    for field in ("temporal","space","stress","native_stress","neg_weyl"):
                        readings=observer.annuli(model,raw,initial[field],data[field])
                        for width,value in zip((.15,.3),readings,strict=True):measured[f"{field}-{width}"]=float(value)
                        values[field+"_profile"]=(data[field]-initial[field]).delta[1]
                    checks=task.compute(model,state,clock)
                    for field in ("ind_H","ind_P","ind_J"):values[field]=checks[field]
                assert model.mass.min_branch>0 and (flag or (model.min_number>0 and model.min_factor>0))
                save(key+".npz",values)
                write(key+".json",dict(design=design,algorithm=alg,tick=tick,clock=clock,
                                       sha=task.lab.sha(HERE/(key+".npz")),readings=measured))
                print(key,round(perf_counter()-started,1),"seconds",flush=True)
if __name__=="__main__":
    run(*map(int,sys.argv[1:4]),sys.argv[4],*map(int,sys.argv[5:]))

