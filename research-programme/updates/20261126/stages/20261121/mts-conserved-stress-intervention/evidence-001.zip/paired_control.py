from stress_switch import HERE,task,table

def run(grid,seed,mode,end):
    readings=task.read(HERE/f"g{grid}-s{seed}-{mode}-score{end}.csv")
    poisson=task.read(HERE/"newton-conserved-source.csv")
    original=task.read(HERE/"stress-withdrawal-forecast.csv")
    rows=[]
    for record in readings:
        if record["reader"] not in ("temporal","space"):continue
        width=float(record["width"]);frac=int(record["tick"])/1024
        newton=float(record["newton"]);unit=abs(newton)*1e-6
        gain=2 if mode=="reverse" else 1
        raw=float(record["removed_per_gain"])
        select=lambda sample: int(sample["seed"])==seed and float(sample["width"])==width and float(sample["fraction"])==frac
        companion=next(float(row["poisson"]) for row in poisson if select(row) and row["outer"]=="144.0" and row["clock"]=="expanding")
        forecast=next(row for row in original if select(row) and row["order"]=="28")
        predicted=float(forecast["retained_tt"])+float(forecast["moving_contact"])
        twin=newton-gain*companion
        after=float(record["changed"])
        rows.append(dict(grid=grid,seed=seed,mode=mode,tick=record["tick"],width=width,reader=record["reader"],native_newton=newton,
                         source_poisson=companion,newton_twin=twin,measured_native_minus_changed_per_gain=raw,
                         curvature_beyond_poisson=raw-companion,tt_plus_contact=predicted,
                         curvature_beyond_poisson_ppm=(raw-companion)/unit,tt_plus_contact_ppm=predicted/unit,
                         residual_ppm=(raw-companion-predicted)/unit,inside=abs(raw-companion-predicted)<=20*unit,
                         altered_tide_minus_twin_ppm=(after-twin)/unit))
    table(f"g{grid}-s{seed}-{mode}-newton-twin{end}.csv",rows)
    print("Newton twin",grid,seed,mode,"largest discrepancy",max(abs(r["residual_ppm"]) for r in rows),flush=True)

def reversal(grid,seed,end):
    source=task.read(HERE/f"g{grid}-s{seed}-off-score{end}.csv")
    reverse=task.read(HERE/f"g{grid}-s{seed}-reverse-score{end}.csv")
    out=[]
    for left,right in zip(source,reverse,strict=True):
        for key in ("tick","reader","width","native"):assert left[key]==right[key]
        newton=float(left["newton"])
        plus=float(left["native"]);zero=float(left["changed"]);minus=float(right["changed"])
        out.append(dict(tick=left["tick"],width=left["width"],reader=left["reader"],gain_plus=plus,gain_zero=zero,gain_minus=minus,
                        even=plus+minus-2*zero,odd=(plus-minus)/2,even_ppm=(plus+minus-2*zero)/abs(newton)*1e6))
    table(f"g{grid}-s{seed}-signed-feedback{end}.csv",out)
if __name__=="__main__":
    import sys
    grid,seed,end=map(int,(sys.argv[1],sys.argv[2],sys.argv[4]))
    run(grid,seed,sys.argv[3],end)
    if sys.argv[3]=="reverse":reversal(grid,seed,end)
