"""Independent weak-field mechanical forecast; does not read a switched trajectory."""
import sys
from stress_switch import HERE,task,lock,np,write,table
sys.path.insert(0,str(task.FORM))
import matched_prediction as matched
from numpy.polynomial.legendre import leggauss,legvander
from unittest.mock import patch
from functools import lru_cache
from math import fsum
from window import CENTER,weight

LEVEL=1024

@lru_cache(maxsize=64)
def rule(spacing,nodes,width,scale,order):
    half=CENTER*width
    low,high=(CENTER-half)/scale,(CENTER+half)/scale
    ends=np.unique(np.r_[low,np.arange(np.ceil(low/spacing),np.ceil(high/spacing))*spacing,high])
    mid=(ends[1:]+ends[:-1])/2
    length=np.diff(ends)/2
    pts,weights=leggauss(order)
    radius=(mid[:,None]+length[:,None]*pts).ravel()
    quad=(length[:,None]*weights).ravel()
    cells=(radius/spacing).astype(int)
    basis=legvander(2*(radius/spacing-cells)-1,len(nodes)-1)@np.linalg.inv(legvander(2*np.array(nodes)-1,len(nodes)-1))
    weights=[scale**(idx+1)*weight(scale*radius,half,idx) for idx in range(3)]
    return radius,quad,cells,basis,weights

def moments(raw,tt,rule):
    radius,quad,cells,basis,(win,first,second)=rule
    def interp(field):return np.einsum("ij,ij->i",field[cells],basis)
    radial,mixed,angular=map(interp,raw)
    tensor=interp(tt)
    return [np.dot(quad,val) for val in (
        win*radial,win*tensor,(-second+2*first/radius-8*win/radius**2)*radial/3
        -4*first*mixed/radius+8*win*angular/radius**2,
        (second-6*first/radius+6*win/radius**2)*tensor)]

def checks():
    import sympy as sp
    radius=sp.symbols("r",positive=True)
    base=sp.exp(-radius**2)
    def prime(expr):return expr.diff(radius)
    def lap(expr):return prime(prime(expr))+2*prime(expr)/radius-6*expr/radius**2
    def rr(expr):return prime(prime(expr))-lap(expr)/3
    tt=[base,(radius*prime(base)+3*base)/6]
    tt.append((radius*prime(tt[1])+3*tt[1]-tt[0]/2)/2)
    phi=radius**2*base
    scalar=[rr(phi),prime(phi)/radius-phi/radius**2,phi/radius**2]
    velocity=radius*base
    tang=(radius*prime(velocity)+2*velocity)/6
    vector=[prime(velocity),(prime(tang)-tang/radius+velocity/radius)/2,tang/radius]
    nodes=tuple((leggauss(12)[0]+1)/2)
    spacing=.2
    points=spacing*(np.arange(12)[:,None]+nodes)
    rows=[]
    for name,components,kernel in (("TT",tt,prime(prime(base))+6*prime(base)/radius),
                                   ("scalar",scalar,-rr(lap(phi))/3),("vector",vector,0*phi)):
        expr=sp.lambdify(radius,components,"numpy")
        raw=np.array(expr(points))
        for width in (.15,.3):
            weights=rule(spacing,nodes,width,1.,32)
            radial,quad,_,_,(win,_,_)=weights
            value=moments(raw,raw[0] if name=="TT" else 0*raw[0],weights)
            expected=float(np.sum(quad*win*sp.lambdify(radius,kernel,"numpy")(radial)))
            assert abs(value[2]-expected)<1e-10 and (name=="vector" or abs(expected)>.01)
            if name=="TT":assert abs(value[3]-expected)<1e-10
            rows.append(dict(field=name,width=width,weak_C=value[2],direct=expected,error=value[2]-expected))
    table("scalar-vector-tensor-controls.csv",rows)

def run():
    lock()
    checks()
    histories={}
    for seed in (1,-1):
        path=task.FORM/f"matched-source-history-p32-s{seed}.npz"
        assert task.lab.sha(path)==task.meta(task.FORM/"matched-forecast.json")["histories"][str(seed)]
        with np.load(path) as saved:histories[seed]={key:saved[key] for key in saved.files}
    project=matched.mechanical.tensor.transverse.project
    sums=[]
    def capture(grid,raw):
        idx=len(sums)
        seed=(1,-1)[idx//33];tick=idx%33;bank=histories[seed]
        tensor=project(grid,raw)
        np.testing.assert_array_equal(tensor[0],bank["radial"][tick])
        row={}
        for width in (.15,.3):
            for mode,factor in (("flat",1.),("moving",float(bank["b"][tick]))):
                for order in (16,28):
                    row[width,mode,order]=moments(raw,tensor[0],rule(float(grid.h),tuple(grid.t),width,factor,order))
        sums.append(row)
        return tensor
    def archive(name,**items):
        seed=1 if "s1." in name else -1
        for key,item in items.items():np.testing.assert_array_equal(item,histories[seed][key])
    with matched.route(),patch.object(matched.mechanical.tensor.transverse,"project",capture),patch.object(matched.mechanical,"packet",archive),patch.object(matched.mechanical,"table",lambda *args:None):
        matched.mechanical.history(32)
    assert len(sums)==66
    old=task.read(task.FORM/"matched-gravity-prediction.csv")
    op=matched.driven.RadialSpectrum(160,12)
    rows=[];inputs=[]
    for seed,data in histories.items():
        length=len(data["xi"])
        elapsed=np.linspace(0.,np.sqrt(LEVEL)*matched.core.DURATION,length)
        raw=data["radial"];points=op.x/float(data["spacing"]);cell=points.astype(int)
        basis=legvander(2*(points-cell)-1,len(data["local_nodes"])-1)
        inv=np.linalg.inv(legvander(2*data["local_nodes"]-1,len(data["local_nodes"])-1))
        coefficients=np.array([op.spectrum(np.einsum("ijk,ijk->ij",basis,(frame@inv.T)[cell])) for frame in raw])
        for width in (.15,.3):
            sensor=op.aperture(width)
            position=np.zeros_like(coefficients[0]);speed=np.zeros_like(position)
            for idx in range(1,length):
                step=elapsed[idx]-elapsed[idx-1]
                position,speed=matched.driven.affine_step(op.freq,step,position,speed,coefficients[idx-1],coefficients[idx])
                if idx%8:continue
                frac=idx/32
                prior=next(r for r in old if (int(r["seed"]),float(r["width"]),float(r["fraction"]))==(seed,width,frac))
                newton=float(prior["matched_newton"])
                flat_tt=fsum(sensor*((coefficients[idx]-coefficients[0])-op.freq**2*position))/LEVEL
                offset=0 if seed==1 else length
                for order in (16,28):
                    flat=np.array([sums[offset+i][width,"flat",order] for i in range(idx+1)])
                    moving=np.array([sums[offset+i][width,"moving",order] for i in range(idx+1)])
                    scalar=flat[:,2]-flat[:,3]
                    def retard(values,stride):
                        acc=vel=0.
                        for i in range(stride,idx+1,stride):
                            span=elapsed[i]-elapsed[i-stride]
                            acc+=span*vel+span**2*(2*values[i-stride]+values[i])/6
                            vel+=span*(values[i-stride]+values[i])/2
                        return acc/LEVEL
                    memory=retard(scalar,1)
                    contact=((flat[-1,0]-flat[0,0])-(flat[-1,1]-flat[0,1]))/LEVEL
                    moving_contact=((moving[-1,0]-moving[-1,1])/data["b"][idx]**2-(moving[0,0]-moving[0,1]))/LEVEL
                    shifted_tt=float(prior["matched_tt"])
                    rows.append(dict(seed=seed,width=width,fraction=frac,order=order,newton=newton,flat_tt=flat_tt,retained_tt=shifted_tt,
                        contact=contact,moving_contact=moving_contact,scalar=memory,scalar_stride2=retard(scalar,2),
                        full_flat=flat_tt+contact+memory,hybrid=shifted_tt+moving_contact+memory,
                        scalar_ppm=1e6*memory/abs(newton),hybrid_ppm=1e6*(shifted_tt+moving_contact+memory)/abs(newton)))
            for i in range(length):
                for mode in ("flat","moving"):
                    vals=sums[(0 if seed==1 else length)+i][width,mode,28]
                    inputs.append(dict(seed=seed,width=width,tick=i,window=mode,radial=vals[0],tt=vals[1],full_C=vals[2],tt_laplacian=vals[3]))
    table("independent-source-moments.csv",inputs)
    table("stress-withdrawal-forecast.csv",rows)
    files=["causal_forecast.py","FORECAST.md","scalar-vector-tensor-controls.csv","independent-source-moments.csv","stress-withdrawal-forecast.csv"]
    write("forecast-pin.json",dict(files={n:task.lab.sha(HERE/n) for n in files},source=task.lab.sha(task.FORM/"matched-forecast.json"),scope="No switched trajectory opened by this forecast."))
    print("frozen material forecast",[(r["seed"],r["width"],r["scalar_ppm"],r["hybrid_ppm"]) for r in rows if r["order"]==28 and r["fraction"]==1],flush=True)

if __name__=="__main__":run()
