"""Independent Cartesian time evolution for tensor, vector and scalar stress drives."""
from stress_switch import table,np
from scipy.linalg import expm

def solve():
    rows=[]
    for wave in (.65,3.1):
        k=wave*np.array([2.,-1.,2.])/3
        direction=k/wave
        ident=np.eye(3)
        long=np.outer(direction,direction)
        projector=ident-long
        seed=np.array(((.3,.21,-.18),(.21,-.57,.17),(-.18,.17,.27)))
        tensor=projector@seed@projector-projector*np.trace(projector@seed)/2
        radial=direction@seed@direction
        scalar=1.5*radial*(long-ident/3)
        vector=seed-scalar-tensor
        for label,stress in (("tensor",tensor),("vector",vector),("scalar",scalar),("mixed",seed)):
            def state(rate):
                metric=rate[:9].reshape(3,3)
                ric=(-np.outer(k,metric@k)-np.outer(metric@k,k)+wave**2*metric+long*wave**2*np.trace(metric))/2
                return ric
            def deriv(rate):
                ric=state(rate)
                moment=rate[18:21]
                source=rate[22]*stress
                return np.r_[rate[9:18],(-2*ric+2*source+ident*rate[21]).ravel(),
                             -source@k,k@moment,rate[23],0.]
            matrix=np.stack([deriv(col) for col in np.eye(24)],axis=1)
            start=np.zeros(24);start[-2:]=(1.,.34)
            for elapsed in (.067,.81):
                out=expm(matrix*elapsed)@start
                velocity=deriv(out)[9:18].reshape(3,3)/2
                direct=velocity-ident*np.trace(velocity)/3
                tt=projector@stress@projector-projector*np.trace(projector@stress)/2
                memory=elapsed**2/2+.34*elapsed**3/6
                density=-wave**2*(direction@stress@direction)*memory
                weight=np.cos(wave*elapsed)+.34*np.sin(wave*elapsed)/wave
                pred=stress*(1+.34*elapsed)+(weight-1-.34*elapsed)*tt-density*(long-ident/3)/2
                scale=np.linalg.norm(direct);err=np.linalg.norm(direct-pred)
                assert scale>.01 and err<1e-13*scale and abs(out[21]-density)<1e-13
                rows.append(dict(k=wave,sector=label,time=elapsed,density=density,norm=scale,error=err))
    table("cartesian-retarded-controls.csv",rows)
    print(len(rows),"independent time evolutions")
if __name__=="__main__":solve()
