"""Interpolate the isolated radial modes and evaluate scalar/vector derivatives in the meridional plane."""
from geodesic_bank import HERE, np, CubicSpline, CubicHermiteSpline, roots_legendre,eval_legendre,LIGHT

class Sky:
    def __init__(self,path,method='matter'):
        self.path=path
        with np.load(path) as data:
            self.rad=data['r'];self.ell=np.arange(0,133,2);dim=len(self.ell)
            self.factors=self.ell*(self.ell+1)
            self.first=[];self.lap=[]
            for key in ('u','w'):
                self.first.append(CubicHermiteSpline(self.rad,data[key],data[key+'_r']))
                self.lap.append(data[key+'_lap'])
            suffix='' if method=='matter' else '_gr'
            packed=np.stack([data[key+suffix] for key in ('q','p','A','br','bt')],axis=1)
            self.second=(CubicHermiteSpline(self.rad,packed,np.stack([data[key+'_r'] for key in ('q','p','A','br','bt')],axis=1))
                if 'A_r' in data and method=='matter' else CubicSpline(self.rad,packed))
        self.nodes,self.weights=roots_legendre(10)

    def basis(self,position):
        rad=np.hypot(*position);er=position/rad;et=np.array([er[1],-er[0]])
        mu=er[1];sin=er[0];ell=self.ell
        if not self.rad[0]<=rad<=self.rad[-1] or sin<=0:
            raise ValueError('position outside precomputed meridional patch')
        val=eval_legendre(ell,mu)
        theta=ell*(mu*val-eval_legendre(np.maximum(0,ell-1),mu))/sin
        tt=-self.factors*val-mu/sin*theta
        return rad,er,et,val,theta,tt

    def first_field(self,position,hessian=False):
        rad,er,et,val,theta,tt=self.basis(position)
        values=[];grad=[];hess=[]
        for idx,spline in enumerate(self.first):
            coeff=spline(rad);slope=spline(rad,1);size=len(coeff)
            fr=slope@val[:size];ft=coeff@theta[:size]/rad
            values.append(coeff@val[:size]);grad.append(fr*er+ft*et)
            if hessian:
                label=np.argmin(abs(self.rad-rad))
                if abs(self.rad[label]-rad)>1.e-10:
                    raise ValueError('exact local density required for Hessian')
                rr=self.lap[idx][label]@val[:size]-2*fr/rad+(coeff*self.factors[:size])@val[:size]/rad**2
                rt=(slope@theta[:size]-ft)/rad
                theta2=fr/rad+(coeff@tt[:size])/rad**2
                hess.append(rr*np.outer(er,er)+rt*(np.outer(er,et)+np.outer(et,er))+theta2*np.outer(et,et))
        return np.array(values),np.array(grad),np.array(hess)

    def second_field(self,position):
        rad,er,et,val,theta,tt=self.basis(position)
        co=self.second(rad);cp=self.second(rad,1)
        potentials=co[:3]@val
        gradients=np.outer(cp[:3]@val,er)+np.outer(co[:3]@theta/rad,et)
        br=co[3]@val;bt=co[4]@theta
        vector=br*er+bt*et
        directional_r=(cp[3]@val)*er+(cp[4]@theta)*et
        directional_t=((co[3]@theta-bt)*er+(co[4]@tt+br)*et)/rad
        jac=np.outer(directional_r,er)+np.outer(directional_t,et)
        return potentials,gradients,vector,jac

    def integrate(self,start,end,function):
        delta=end-start;length=np.linalg.norm(delta);direction=delta/length
        offset=np.dot(start,direction);impact=np.dot(start,start)-offset**2
        cross=self.rad[self.rad**2>impact]
        cuts=np.r_[0.,length,-offset+np.sqrt(cross**2-impact),-offset-np.sqrt(cross**2-impact)]
        cuts=np.unique(np.clip(cuts,0.,length))
        vals=[]
        for left,right in zip(cuts,cuts[1:]):
            for node,weight in zip(self.nodes,self.weights):
                dis=left+(right-left)*(1+node)/2
                vals.append(function(start+dis*direction,dis/length)*((right-left)*weight/2))
        return np.sum(vals,axis=0)

    def initial(self,position):
        ss,zz=position;vals,grad,hessian=self.first_field(position,True)
        vertical=self.integrate(np.array([ss,0.]),position,lambda x,u:self.first_field(x)[0])
        location=np.column_stack((ss*vals,vertical))
        second,jets,shift,_=self.second_field(position)
        return dict(V=vals,grad=grad,H=hessian,k=location,second=second,jets=jets,shift=shift)
