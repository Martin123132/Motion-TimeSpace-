"""Compare the shrinking free-clock echo with the normal-frame electric Riemann tensor on the same slice."""
from geodesic_bank import HERE,np,Experiment,raw_bank,fields,guard,table,LIGHT,sys
from launch_forecast import Sky,leg,line_data
from types import MethodType

def hessians(box,mass,edges,points,layout,sky):
    radii=np.linalg.norm(points,axis=1)
    host,wave=fields(box,mass,edges,radii,layout,8)
    result={}
    for i,pos in enumerate(points):
        rad,er,et,val,th,tt=sky.basis(pos);hh=[];lap=[]
        for block in (host,wave):
            coeff,slope,source=[part[i] for part in block];size=len(coeff)
            fr=slope@val[:size];ft=coeff@th[:size]/rad
            den=source@val[:size];lap.append(den)
            rr=den-2*fr/rad+(coeff*sky.factors[:size])@val[:size]/rad**2
            rt=(slope@th[:size]-ft)/rad;ta=fr/rad+coeff@tt[:size]/rad**2
            hh.append(rr*np.outer(er,er)+rt*(np.outer(er,et)+np.outer(et,er))+ta*np.outer(et,et))
        result[tuple(pos)]=(np.array(hh),np.array(lap))
    return result

def run(layout,exact=False):
    guard();box=Experiment(0,1);mass,edges=raw_bank(box)
    sky=Sky(HERE/('exact-jets-volume.npz' if exact else f'bank-cross-{layout}-8.npz'))
    controls=[];limits=[]
    widths=(.128,.064,.032,.016,.008,.004,.002,.001,.0005,.00025,.000125)
    if exact:widths+=(.0000625,.00003125,.000015625)
    for center in (6.,8.3):
        pos=np.array([center,1.5]);nr=np.array([1.,0.])
        x0=sky.initial(pos);loc=x0['k'];unit=loc/np.linalg.norm(loc,axis=1)[:,None]
        steps=(8.e-5,4.e-5)
        points=np.array([pos]+[pos+sign*delta*nr/2 for delta in widths for sign in (-1,1)]+
                        [pos+sign*step*uv for step in steps for uv in unit for sign in (-1,1)])
        true=hessians(box,mass,edges,points,layout,sky)
        def actual(self,x,hessian=False):
            val,der,_=Sky.first_field(self,x)
            return val,der,true[tuple(x)][0] if hessian else np.array([])
        sky.first_field=MethodType(actual,sky)
        rad,er,et,basis,angular,second_theta=sky.basis(pos)
        q=sky.second(rad)[0];qr=sky.second(rad,1)[0]
        u,w=x0['V'];den=true[tuple(pos)][1]
        aa=x0['second'][2];jac=sky.second_field(pos)[3]
        qlap=u*den[1]+w*den[0]-3*aa
        rq=qr@basis;tq=q@angular/rad
        qrr=qlap-2*rq/rad+(q*sky.factors)@basis/rad**2
        qrt=(qr@angular-tq)/rad;qtt=rq/rad+q@second_theta/rad**2
        rs,ts=er[0],et[0]
        qss=rs**2*qrr+2*rs*ts*qrt+ts**2*qtt
        grad=x0['grad']
        geometry=6*grad[0,0]*grad[1,0]-2*(grad[0]@grad[1])
        ks=np.column_stack([x0['V']+center*grad[:,0],
                  sky.integrate(np.array([center,0.]),pos,lambda x,t:sky.first_field(x)[1][:,0])])
        tilt=2*sum(ks[i]@true[tuple(pos)][0][1-i,:,0] for i in (0,1))
        for step in steps:
            relocation=sum(np.linalg.norm(loc[i])*(true[tuple(pos+step*unit[i])][0][1-i,0,0]-
                       true[tuple(pos-step*unit[i])][0][1-i,0,0])/(2*step) for i in (0,1))
            mixed=(qss+geometry+aa+jac[0,0]+tilt+relocation)/LIGHT**4
            controls.append(dict(layout=layout,center=center,derivative_kpc=step,
                    directional_lapse_hessian=qss/LIGHT**4,gradient_geometry=geometry/LIGHT**4,metric_time=(aa+jac[0,0])/LIGHT**4,
                    location=relocation/LIGHT**4,physical_tangent=tilt/LIGHT**4,matched_curvature_per_kpc2=mixed))
        for width in widths:
            left,right=pos-width*nr/2,pos+width*nr/2
            obs=[dict(sky.initial(x),cyl=x[0]) for x in (left,right)]
            pa=line_data(sky,left,right);pb=line_data(sky,right,left)
            out,no,delay=leg(*obs,0.,np.zeros(2),pa,'free')
            back,nb,_=leg(*obs[::-1],pa[1],delay,pb,'free')
            tidal=-(sum(out.values())+sum(back.values()))/(2*pa[1]**2*LIGHT**4)
            linear=-(no+nb)/(2*pa[1]**2*LIGHT**2)
            wanted=true[tuple(pos)][0][:,0,0]/LIGHT**2
            limits.append(dict(layout=layout,center=center,width_kpc=width,inferred_curvature=tidal,riemann=mixed,
                               fractional=tidal/mixed-1,newton_u=linear[0],newton_w=linear[1],
                               newton_u_rel=linear[0]/wanted[0]-1,newton_w_rel=linear[1]/wanted[1]-1))
        del sky.first_field
    return controls,limits
if __name__=='__main__':
    exact='--exact' in sys.argv
    inp,limits=run('volume',exact)
    suffix='-exact' if exact else ''
    table(HERE/f'riemann-components{suffix}.csv',inp,True);table(HERE/f'short-arm-limit{suffix}.csv',limits,True)
