"""Simultaneous three-clock echo combinations, chosen to annihilate local launch acceleration, not fitted."""
from geodesic_bank import HERE,np,Experiment,raw_bank,angles,roots_legendre,guard,table,LIGHT
from separation import Sky,evaluate_many,stable_echo
from curvature_limit import hessians

def run(kind,layout):
    sky=Sky(HERE/(f'face-jets-{layout}.npz' if kind=='cross' else f'bank-{kind}-volume-8.npz'))
    box=Experiment(0,1);mass,edges=raw_bank(box)
    start,end,z=6.,8.3,1.5;length=end-start
    face_r=edges[(edges>np.hypot(start,z))&(edges<np.hypot(end,z))]
    faces=np.sqrt((face_r-z)*(face_r+z))
    sets=(.25,.5,.75)
    mids=start+length*np.array(sets)
    if kind=='cross':
        mids=np.r_[mids,(faces[:,None]+np.array([-.00012,.00012,-.00003,.00003,-.0000075,.0000075])).ravel()]
    ss=np.unique(np.r_[start,mids,end]);rr=np.hypot(ss,z)
    cuts=sky.rad[(sky.rad>rr[0])&(sky.rad<rr[-1])]
    knots=np.unique(np.r_[ss,np.sqrt((cuts-z)*(cuts+z))])
    node,rule=roots_legendre(8)
    ray=(knots[:-1,None]+np.diff(knots)[:,None]*(1+node)/2).ravel()
    wt=np.diff(knots)[:,None]*rule/2;points=np.c_[ray,np.full_like(ray,z)]
    vals,grad=evaluate_many(sky,points)
    radii=np.hypot(ray,z);acc=[]
    for first in range(0,len(radii),128):
        r=radii[first:first+128]
        acc.extend(np.sum(angles(z/r,np.arange(0,133,2))[0]*sky.second(r)[:,2],axis=1))
    integ=np.column_stack([vals,grad.reshape(-1,4),((ray-start)[:,None,None]*grad).reshape(-1,4),acc])
    cumulative=np.vstack([np.zeros(11),np.cumsum((integ.reshape(-1,len(node),11)*wt[:,:,None]).sum(axis=1),axis=0)])
    cumul=cumulative[np.searchsorted(knots,ss)];states=[]
    for point,rad in zip(ss,rr):
        pos=np.array([point,z]);v,gr,_=sky.first_field(pos);sec,jets,shift,_=sky.second_field(pos)
        if kind=='cross':
            hess=sky.first_field(pos,True)[2]
        else:
            basis=sky.basis(pos);rb,er,et,pol,theta,tt=basis
            sel=sky.first[0];co=sel(rb);slope=sel(rb,1);size=len(co)
            fr=slope@pol[:size];ft=co@theta[:size]/rb
            rr0=sel(rb,2)@pol[:size];rt=(slope@theta[:size]-ft)/rb
            hh=rr0*np.outer(er,er)+rt*(np.outer(er,et)+np.outer(et,er))+(fr/rb+co@tt[:size]/rb**2)*np.outer(et,et)
            hess=np.stack([hh,hh])
        c=sky.rad[(sky.rad>point)&(sky.rad<rad)]
        zz=np.r_[0.,np.sqrt((c-point)*(c+point)),z]
        t=(zz[:-1,None]+np.diff(zz)[:,None]*(1+node)/2).ravel()
        vv=evaluate_many(sky,np.c_[np.full_like(t,point),t])[0]
        ins=(np.diff(zz)[:,None]*rule/2).ravel()@vv
        states.append(dict(V=v,grad=gr,H=hess,k=np.column_stack([point*v,ins]),second=sec,jets=jets,shift=shift))
    def arm(i,j):
        span=ss[j]-ss[i];val=cumul[j]-cumul[i]
        moment=(val[6:10]-(ss[i]-start)*val[2:6]).reshape(2,2)/span**2
        mixed,launch=stable_echo(states[i],states[j],span,val[:2]/span,val[2:6].reshape(2,2)/span-moment,moment,val[-1]/span,True)
        factor=1 if kind=='cross' else .5
        linear=2*span*(states[i]['grad'][0,0]-states[j]['grad'][0,0])/LIGHT**2
        return np.array([mixed*factor,launch*factor,linear])
    full=arm(0,-1)
    rows=[]
    for idx in range(1,len(ss)-1):
        left=arm(0,idx);right=arm(idx,-1);wleft=length/(ss[idx]-start);wright=length/(end-ss[idx])
        mix=wleft*left+wright*right-full
        reduced=wleft*(left[0]-left[1])+wright*(right[0]-right[1])-(full[0]-full[1])
        rows.append(dict(kind=kind,layout=layout,middle_kpc=ss[idx],left_weight=wleft,right_weight=wright,
                left=left[0],right=right[0],long=full[0],combination=mix[0],symbolically_reduced=reduced,
                acceleration_remainder=mix[1],newton_remainder=mix[2]))
    table(HERE/f'chain-{kind}-{layout}.csv',rows,True)

if __name__=='__main__':
    guard()
    for model in ('volume','radius','smooth-volume','smooth-radius'):
        run('cross',model)
    for kind in ('raw','represented'):
        run(kind,'volume')
