"""Wave-on minus wave-off in one unchanged ordinary foreground, through the first term sensitive to initial current."""
from geodesic_bank import HERE,np,Experiment,roots_legendre,angles,shell_sums,direct_current,packet,table,guard,LIGHT
from crossed_metric import Radial,green
from mts_radial_inputs import shape
from types import SimpleNamespace

def calculate(order):
    box=Experiment(0,1);lab=box.lab;obj=box.obj;bg=box.bg;mesh=Radial(lab,16);el=lab.run.el
    L=bg.length;speed=bg.vel;ell=mesh.sell;angular=ell*(ell+1);norm=2*ell+1
    with np.load(HERE/'bank-cross-volume-8.npz') as common:base=common['r']
    node,rule=roots_legendre(8)
    ss=np.array([6.,7.15,8.3]);cuts=np.unique(np.r_[ss,np.linspace(6.,8.3,45)])
    s=(cuts[:-1,None]+np.diff(cuts)[:,None]*(1+node)/2).ravel();w=(np.diff(cuts)[:,None]*rule/2).ravel()
    positions=np.r_[ss,s];pts=np.hypot(positions,1.5)
    target=np.unique(np.r_[base,pts]);idx=np.searchsorted(target,pts)
    bounds=np.unique(np.r_[0.,el.right*L,target]);nd,wt=roots_legendre(order)
    r=(bounds[:-1,None]+np.diff(bounds)[:,None]*(1+nd)/2).ravel();iw=(np.diff(bounds)[:,None]*wt/2).ravel()
    full=np.r_[r,target];mu,aw=roots_legendre(92);aw/=2
    vals,theta,_=angles(mu,ell);ev=vals[:,:len(bg.orders)]*np.sqrt(2*bg.orders+1)
    der=theta[:,:len(bg.orders)]*np.sqrt(2*bg.orders+1)
    iy=np.searchsorted(el.right,full/L).clip(0,len(el.right)-1)
    psi,psid=shape(el.knots,(full/L-el.left[iy])/el.width[iy])
    view,step,_=angles(1.5/pts,ell)
    tab=[];checks=[]
    for arm,state in lab.initial.items():
        guard()
        nodes=el.nodes(state)
        samples=[]
        for j in range(0,len(full),128):
            sl=slice(j,j+128);y=full[sl,None]/L;ix=iy[sl]
            val=np.einsum('ni,nim->nm',psi[sl],nodes[ix])/y
            grad=(np.einsum('ni,nim->nm',psid[sl],nodes[ix])/el.width[ix,None]-val)/y
            sky=val@ev.T;gr=grad@ev.T;gt=val@der.T/y
            rr=(-speed**3/L**2)*(sky.conj()*gr).imag
            tt=(-speed**3/L**2)*(sky.conj()*gt).imag
            ar=((rr*aw)@vals)*norm;bt=((tt*aw)@theta)*norm
            bt[:,0]=0.;bt[:,1:]/=angular[1:]
            samples.append(np.stack([ar,bt],axis=1))
        bank=np.concatenate(samples);ar,bt=bank[:len(r),0],bank[:len(r),1]
        a,br,btheta,_,_=direct_current(r,iw,target,ell,ar,bt)
        inside=shell_sums(r,target,ell,(iw*r)[:,None]*(ell*ar+angular*bt)/norm)[0]
        outside=shell_sums(r,target,ell,(iw*r)[:,None]*(-(ell+1)*ar+angular*bt)/norm)[1]
        local_source=bank[len(r):,0]
        grad_a=(-(ell+1)*inside+ell*outside)/target[:,None]+local_source
        single=SimpleNamespace(obj=obj,run=lab.run,initial=dict(zero=state*0,prepared=state))
        pot,dp,_=green(single,mesh,target/L)
        v=pot[:,:,0]*speed**2*np.sqrt(norm)
        vr=dp[:,:,0]*speed**2/L*np.sqrt(norm)
        dot_operator=pot[:,:,1]*speed**3/L*np.sqrt(norm)
        dot_operator_r=dp[:,:,1]*speed**3/L**2*np.sqrt(norm)
        packet(f'current-{arm}-{order}.npz',r=target,V=v,V_r=vr,Vdot=a,Vdot_r=grad_a,Vdot_operator=dot_operator,
               Vdot_operator_r=dot_operator_r,br=br,bt=btheta)
        value=(view*v[idx]).sum(axis=1)
        g=(view*vr[idx]).sum(axis=1)*positions/pts+(step*v[idx]).sum(axis=1)*1.5/pts**2
        shift=(view*br[idx]).sum(axis=1)*positions/pts+(step*btheta[idx]).sum(axis=1)*1.5/pts
        for method,aa,ag in (('flux',a,grad_a),('native_time',dot_operator,dot_operator_r)):
            dot=(view*aa[idx]).sum(axis=1)
            ds=(view*ag[idx]).sum(axis=1)*positions/pts+(step*aa[idx]).sum(axis=1)*1.5/pts**2
            results=[]
            for ii,jj in ((0,1),(1,2),(0,2)):
                d=ss[jj]-ss[ii];select=(s>ss[ii])&(s<ss[jj]);integ=w[select]@dot[3:][select]
                c2=2*d*(g[ii]-g[jj])/LIGHT**2
                u=2*d*dot[ii]/LIGHT**3;light=-4*integ/LIGHT**3
                vector=2*(shift[ii]-shift[jj])/LIGHT**3
                accel=d*d*(2*ds[ii]-ds[jj])/LIGHT**3
                out=dict(arm=arm,method=method,start=ss[ii],finish=ss[jj],link='echo',newton=c2,
                         rate_evolution=u,path_time=light,normal_velocity=vector,changing_force=accel,
                         current_rate=u+light+vector+accel)
                tab.append(out);results.append(out)
            combined={k:2*(results[0][k]+results[1][k])-results[2][k] for k in results[0] if k in
                     ('newton','rate_evolution','path_time','normal_velocity','changing_force','current_rate')}
            tab.append(dict(arm=arm,method=method,start=ss[0],finish=ss[-1],link='three',**combined))
        peak=max(np.max(abs(a)),1.e-40)
        checks.append(dict(arm=arm,degree=order,operator_vs_current=np.max(abs(dot_operator-a)),flux_vs_div=np.max(abs(a-inside-outside)),
                     peak_potential_rate=peak,relative_dual=np.max(abs(a-inside-outside))/peak,shift_monopole=np.max(abs(br[:,0]))))
    table(HERE/f'single-state-echo-{order}.csv',tab,True)
    table(HERE/f'single-current-check-{order}.csv',checks,True)
if __name__=='__main__':
    import sys
    calculate(int(sys.argv[1]))
