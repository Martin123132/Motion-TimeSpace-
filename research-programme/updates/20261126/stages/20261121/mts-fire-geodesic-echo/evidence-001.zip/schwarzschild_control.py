"""Known GR without wave, baryons or a numerical spacetime metric: radial geodesic clocks in Schwarzschild."""
from geodesic_bank import HERE,np,table,guard
from launch_forecast import leg
from scipy.integrate import quad_vec
import mpmath as mp

def endpoint(radius):
    potential=-1/radius
    grad=np.array([1/radius**2,0.])
    hessian=np.diag([-2/radius**3,1/radius**3])
    return dict(V=np.full(2,potential),grad=np.tile(grad,(2,1)),H=np.stack([hessian,hessian]),
                k=np.array([[-1.,0.],[-1.,0.]]),second=np.array([0.,.5/radius**2,0.]),jets=np.zeros((3,2)),
                shift=np.zeros(2),cyl=radius)

def shapiro(start,end):
    dist=abs(end-start);normal=np.array([np.sign(end-start),0.])
    mean=quad_vec(lambda p:-1/(start+(end-start)*p),0,1)[0]
    init=quad_vec(lambda p:(1-p)/(start+(end-start)*p)**2,0,1)[0]
    final=quad_vec(lambda p:p/(start+(end-start)*p)**2,0,1)[0]
    return normal,dist,np.full(2,-2*dist*mean),np.tile(2*normal*mean-[2*dist*init,0.],(2,1)),np.tile(-2*normal*mean-[2*dist*final,0.],(2,1)),np.zeros(3)

def forecast():
    inner=endpoint(6.);outer=endpoint(8.3)
    a=shapiro(6.,8.3);b=shapiro(8.3,6.)
    out,no,offset=leg(inner,outer,0.,np.zeros(2),a,'free')
    rev,ni,_=leg(outer,inner,0.,np.zeros(2),b,'free')
    back,nb,_=leg(outer,inner,a[1],offset,b,'free')
    return [(no[0],sum(out.values())/2),(ni[0],sum(rev.values())/2),((no+nb)[0],(sum(out.values())+sum(back.values()))/2)]

def exact(mass):
    mp.mp.dps=44
    radii=[mp.mpf(6),mp.mpf('8.3')]
    def pos(radius,phase):
        return radius*mp.cos(phase)**2
    def time(radius,phase):
        speed=mp.sqrt(2*mass/radius);energy=mp.sqrt(1-speed**2)
        return 2*radius*energy/speed*mp.quad(lambda x:mp.cos(x)**2/(1-2*mass/pos(radius,x)),[0,phase])
    def transfer(emit,rec,start,sign):
        re,rr=radii[emit],radii[rec]
        xe=pos(re,start);te=time(re,start)
        def dt(phase):
            xr=pos(rr,phase)
            return sign*(xr-xe+2*mass*mp.log((xr-2*mass)/(xe-2*mass)))
        guess=(te+abs(rr-re))*mp.sqrt(2*mass/rr)/(2*rr)
        end=mp.findroot(lambda phase:time(rr,phase)-te-dt(phase),guess)
        def lognu(radius,phase):
            speed=mp.sqrt(2*mass/radius)
            return -mp.log(mp.sqrt(1-speed**2)-sign*speed*mp.tan(phase))
        return lognu(re,start)-lognu(rr,end),end
    out,phase=transfer(0,1,0,1)
    rev,_=transfer(1,0,0,-1)
    back,_=transfer(1,0,phase,-1)
    return out,rev,out+back

if __name__=='__main__':
    guard();pred=forecast();rows=[]
    for amount in ('0.004','0.002','0.001','0.0005','0.00025','0.000125'):
        mass=mp.mpf(amount)
        values=exact(mass)
        for label,(linear,second),value in zip(('out','in','echo'),pred,values):
            recovered=(value-mp.mpf(linear)*mass)/mass**2
            rows.append(dict(path=label,mass_kpc=amount,exact_log=float(value),linear=linear,forecast_second=second,
                             measured_second=float(recovered),relative_second=float(recovered/second-1)))
    table(HERE/'exact-schwarzschild.csv',rows,True)
