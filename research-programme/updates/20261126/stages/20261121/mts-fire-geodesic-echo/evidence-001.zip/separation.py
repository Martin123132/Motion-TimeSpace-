"""Distance scan with the same inner clock and explicit sided samples at ordinary source faces."""
from geodesic_bank import HERE,guard,np,Experiment,raw_bank,fields,angles,roots_legendre,table,LIGHT,packet
from launch_forecast import Sky
from curvature_limit import hessians

def stable_echo(inner,outer,d,mean,early,late,abar,parts=False):
    gu=inner['grad'];gv=outer['grad'];u=inner['V'];v=outer['V']
    kh=outer['k']-inner['k']
    def coeff(p):
        grad,loc,h=p['grad'],p['k'],p['H']
        lead=-sum(h[i]@loc[1-i] for i in (0,1))-4*(p['V']@grad[::-1])-p['jets'][0]-p['shift']
        cubic=sum(h[i]@grad[1-i] for i in (0,1))-p['jets'][2]
        return lead,cubic
    li,ji=coeff(inner);lo,jo=coeff(outer)
    cross=lambda a,b:np.sum(a*b[::-1])
    tid=gv-gu; ai=gu[:,0];ao=gv[:,0]
    delay=kh[:,0]/d-.5*d*ao-2*mean
    change=kh[:,1]/d-.5*d*gv[:,1]
    terms=np.array([2*inner['second'][2]-8*np.dot(gu[0],gu[1]),
              2*(lo[0]-li[0])/d+d*(jo[0]-4*ji[0])/3,
              -2*cross(tid[:,0]/d,delay)+4*ai.prod(),
              -2*cross(change,tid[:,1]/d)-2*cross(gu[:,1],gv[:,1]-2*gu[:,1]),
              4*cross(mean,tid[:,0]/d)+4*(cross(late,gv)+cross(early,gu)),
              4*ai.prod(),-4*abar])
    if parts:
        return terms.sum()*d**2/LIGHT**4,2*d*(lo[0]-li[0])/LIGHT**4
    return terms.sum()*d**2/LIGHT**4

def evaluate_many(sky,position):
    r=np.linalg.norm(position,axis=1);ss,zz=position.T
    er=position/r[:,None];et=np.c_[er[:,1],-er[:,0]]
    val,th,_=angles(zz/r,np.arange(0,69,2));out=[];grad=[]
    for spline in sky.first:
        c=spline(r);cr=spline(r,1);size=c.shape[1]
        out.append((c*val[:,:size]).sum(axis=1))
        grad.append((cr*val[:,:size]).sum(axis=1)[:,None]*er+(c*th[:,:size]).sum(axis=1)[:,None]*et/r[:,None])
    return np.stack(out,axis=1),np.stack(grad,axis=1)

def run(layout,extra=None,face_jets=False):
    guard();start=6.;end=8.3;height=1.5
    sky=Sky(HERE/(f'face-jets-{layout}.npz' if face_jets else ('exact-jets-volume.npz' if layout=='volume' else 'bank-cross-radius-8.npz')))
    box=Experiment(0,1);mass,edges=raw_bank(box)
    source=edges[(edges>np.hypot(start,height))&(edges<np.hypot(end,height))]
    faces=np.sqrt(source**2-height**2)
    standard=np.r_[start,np.linspace(start,end,185)[1:],faces-.00012,faces+.00012,start+np.array([.00025,.0005,.001,.002,.004,.008,.016])]
    ss=np.unique(standard if extra is None else np.r_[standard,extra])
    pos=np.c_[ss,np.full_like(ss,height)]
    true=None if layout.startswith('smooth-') else hessians(box,mass,edges,pos,layout,sky)
    n,w=roots_legendre(8)
    def vertical(s):
        rad=sky.rad;last=np.hypot(s,height);cuts=np.r_[0.,np.sqrt(rad[(rad>s)&(rad<last)]**2-s*s),height]
        zz=(cuts[:-1,None]+np.diff(cuts)[:,None]*(n+1)/2).ravel()
        return ((np.diff(cuts)[:,None]*w/2).ravel()@evaluate_many(sky,np.c_[np.full_like(zz,s),zz])[0])
    obs=[]
    for x in pos:
        vals,g,_=sky.first_field(x);sec,jets,b,_=sky.second_field(x)
        hessian=sky.first_field(x,True)[2] if true is None else true[tuple(x)][0]
        obs.append(dict(V=vals,grad=g,H=hessian,k=np.column_stack([x[0]*vals,vertical(x[0])]),second=sec,jets=jets,shift=b))
    cuts=sky.rad[(sky.rad>np.hypot(start,height))&(sky.rad<np.hypot(end,height))]
    cuts=np.unique(np.r_[ss,np.sqrt(cuts**2-height**2)])
    knots=(cuts[:-1,None]+np.diff(cuts)[:,None]*(1+n)/2).ravel();wt=np.diff(cuts)[:,None]*w/2
    pos=np.c_[knots,np.full_like(knots,height)]
    vals,grad=evaluate_many(sky,pos);r=np.hypot(knots,height)
    avec=np.empty(len(r))
    for j in range(0,len(r),256):
        sl=slice(j,j+256)
        avec[sl]=np.sum(sky.second(r[sl])[:,2]*angles(height/r[sl],np.arange(0,133,2))[0],axis=1)
    arrays=np.column_stack([vals,grad.reshape(-1,4),(grad*(knots-start)[:,None,None]).reshape(-1,4),avec])
    cumul=np.vstack([np.zeros(arrays.shape[1]),np.cumsum((arrays.reshape(len(cuts)-1,len(n),-1)*wt[:,:,None]).sum(axis=1),axis=0)])
    rows=[]
    for idx,s in enumerate(ss[1:],1):
        d=s-start;row=cumul[np.searchsorted(cuts,s)]
        mean=row[:2]/d;later=row[6:10].reshape(2,2)/d**2;early=row[2:6].reshape(2,2)/d-later
        echo=stable_echo(obs[0],obs[idx],d,mean,early,later,row[-1]/d)
        newton=2*d*(obs[0]['grad'][:,0]-obs[idx]['grad'][:,0])/LIGHT**2
        rows.append(dict(layout=layout,mirror_s=s,span_kpc=d,host_shell=int(np.searchsorted(edges,np.hypot(s,height))-1),
                   distance_to_radial_face_kpc=np.min(abs(s-faces)),free_echo=echo,linear_host=newton[0],linear_wave=newton[1]))
    return rows

if __name__=='__main__':
    stage=[run(layout) for layout in ('volume','radius')]
    for layout,rows in zip(('volume','radius'),stage):
        table(HERE/f'separation-{layout}.csv',rows,True)
