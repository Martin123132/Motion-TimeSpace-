"""Isolated field and current kernels for a moving endpoint and a meridional light ray."""
from pathlib import Path
import sys,json,io,hashlib
HERE=Path(__file__).resolve().parent
PRE=HERE.parent/'mts-fire-directional-lapse-20261121'
def sha(path):
    with path.open('rb') as handle:
        return hashlib.file_digest(handle,'sha256').hexdigest()
SEAL='b3de88dae7ca047c80bba71d04957085dc3f6c805a5d1a89d0b747ad1587f16c'
assert sha(PRE/'seal.json')==SEAL
pin=json.loads((PRE/'seal.json').read_bytes())
for name in ('directional.py','light_link.py','split_tensor.py'):
    assert sha(PRE/name)==pin[name]
sys.path.insert(0,str(PRE))
from directional import Experiment, np, raw_bank, fields, stress_projection, angles, roots_legendre, OBSERVER_R, LIGHT, table, prior, guard as upstream
from light_link import acceleration_sources, shell_sums, direct_current
from split_tensor import harmonics
from matched_io import keep
from scipy.interpolate import CubicSpline,CubicHermiteSpline
from scipy.special import eval_legendre
def guard():
    upstream()
    assert not (HERE/'STOP-REQUESTED').exists()
def packet(name,**values):
    buf=io.BytesIO()
    np.savez_compressed(buf,**values)
    keep(HERE/name,buf.getvalue(),True)
def save(name,data):
    keep(HERE/name,(json.dumps(data,sort_keys=True,indent=2)+'\n').encode(),True)

def stress_slip(r,iw,points,ell,gm,local):
    angular=ell*(ell+1);slip=np.zeros((len(points),len(ell)));slope=slip.copy();second=slip.copy()
    for term in (0,1):
        coeff=(-1/(2*ell-1) if term==0 else 1/(2*ell+3))
        for side in (0,1):
            exponent=ell+2*term if side==0 else 1-ell-2*term
            source=(exponent*(exponent-2)+angular/2)*gm[:,3]+2*(exponent-1)*gm[:,4]+.5*gm[:,5]
            radial_power=(2*term-2) if side==0 else -2*term
            point_power=2-2*term if side==0 else 2*term
            kernel=shell_sums(r,points,ell,source*(iw*r**(2+radial_power))[:,None])[side]
            contribution=-.75*coeff*kernel*points[:,None]**point_power
            slip+=contribution
            slope+=contribution*(1-exponent)/points[:,None]
            second+=contribution*(1-exponent)*(-exponent)/points[:,None]**2
            face=(exponent*(exponent-2)+angular/2)*local[:,3]+2*(exponent-1)*local[:,4]+.5*local[:,5]
            second-=.75*coeff*(1-exponent)*face*(1 if side==0 else -1)
    return slip,slope,second

def build(kind,order,layout):
    guard();box=Experiment(0,1);mass,edges=raw_bank(box)
    if kind!='cross':
        with np.load(prior('frozen-weights.npz')) as f:
            weight=f['fine'].reshape(-1,256);raw=f['launch'].reshape(weight.shape)
            mass=(raw if kind=='raw' else raw*weight)[:len(edges)-1]
    ell=np.arange(0,133,2);ends=box.lab.run.el.right*box.bg.length
    small=np.unique(np.r_[np.linspace(5.68,8.88,513),6.,8.3,OBSERVER_R,edges,ends])
    points=small[(small>=5.68)&(small<=8.88)]
    cuts=np.unique(np.r_[0.,ends,edges,points])
    node,rule=roots_legendre(order)
    r=(cuts[:-1,None]+np.diff(cuts)[:,None]*(1+node)/2).ravel();iw=(np.diff(cuts)[:,None]*rule/2).ravel()
    tail,tw=roots_legendre(32);tail=(tail+1)/2
    r=np.r_[r,ends[-1]/tail];iw=np.r_[iw,ends[-1]*tw/(2*tail**2)]
    full=np.r_[r,points]
    host,wave=fields(box,mass,edges,full,layout,order)
    if kind!='cross':wave=host
    mu,aw=roots_legendre(144 if order==4 else 160);aw/=2
    def batch(first):
        cut=slice(first,first+144);parts=[[col[cut] for col in block] for block in (host,wave)]
        return stress_projection(full[cut],*parts,mu,aw,ell)
    gm=np.concatenate([batch(first) for first in range(0,len(full),144)])
    accsrc=acceleration_sources(r,[c[:len(r)] for c in host],[c[:len(r)] for c in wave],ell,mu,aw).sum(axis=1)
    A,br,bt,Y,Yr=direct_current(r,iw,points,ell,accsrc[:,0],accsrc[:,1])
    measure=iw*r*r
    def pot(src):return sum(shell_sums(r,points,ell,src*measure[:,None]))
    grad=pot(gm[:len(r),0])
    p_current=(2*ell+1)*gm[len(r):,2]+grad
    p_einstein=-pot(gm[:len(r),1])
    slip_current=-grad+3*Y
    slip_einstein,dz,ddz=stress_slip(r,iw,points,ell,gm[:len(r)],gm[len(r):])
    profile=harmonics(ell,gm[:len(r)])
    aa,bb,dd=profile.transpose(1,0,2);angular=ell*(ell+1)
    ar,btan=3*aa-angular*bb,3*bb-.5*aa-.5*(angular-2)*dd
    norm=2*ell+1
    def gradients(index,first,second):
        near=shell_sums(r,points,index,(iw*r)[:,None]*(second-(index+2)*first))[0]
        far=shell_sums(r,points,index,(iw*r)[:,None]*(second-(1-index)*first))[1]
        return -(near+far)/(2*index+1)
    plus=gradients(ell[1:]-1,((aa+(ell+1)*bb)/norm)[:,1:],((ar+(ell+1)*btan)/norm)[:,1:])
    minus=gradients(ell[1:]+1,((ell*bb-aa)/norm)[:,1:],((ell*btan-ar)/norm)[:,1:])
    mono=gradients(ell[:1]+1,aa[:,:1],ar[:,:1])
    xx=np.column_stack([mono,ell[1:]*plus-(ell[1:]+1)*minus]);yy=np.column_stack([np.zeros(len(points)),plus+minus])
    br_gr=-2*(xx-2*dz/3);bt_gr=-2*(yy-2*slip_einstein/(3*points[:,None]));bt_gr[:,0]=0.
    geom=gm[len(r):,0]*(2*ell+1)
    vals=dict(r=points,q=p_current-slip_current,p=p_current,q_gr=p_einstein-slip_einstein,p_gr=p_einstein,
              A=A,A_gr=(ddz+2*dz/points[:,None]-angular*slip_einstein/points[:,None]**2-geom)/3,
              br=br,bt=bt,br_gr=br_gr,bt_gr=bt_gr,slip=slip_einstein,slip_r=dz,grad_dot=geom)
    for name,block in (('u',host),('w',wave)):
        vals[name]=block[0][len(r):];vals[name+'_r']=block[1][len(r):];vals[name+'_lap']=block[2][len(r):]
    packet(f'bank-{kind}-{layout}-{order}.npz',**vals)
    print(kind,layout,order,len(r),len(points),flush=True)
if __name__=='__main__':
    kind,layout=sys.argv[1:3]
    assert kind in ('cross','raw','represented') and layout in ('volume','radius')
    build(kind,int(sys.argv[3]),layout)
