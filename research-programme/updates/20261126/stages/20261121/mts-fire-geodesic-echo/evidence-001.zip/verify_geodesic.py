import csv
import hashlib
import json
import math
import sys
from pathlib import Path

HOME = Path(__file__).resolve().parent
LIGHT = 299792.458


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def rows(name):
    with (HOME / name).open(newline='') as stream:
        return list(csv.DictReader(stream))


def receipt(name, payload, create):
    path = HOME / name
    data = (json.dumps(payload, sort_keys=True, indent=2, allow_nan=False) + '\n').encode()
    if create and not path.exists():
        with path.open('xb') as stream:
            stream.write(data)
    assert data == path.read_bytes(), name


def verify(create):
    prior = HOME.parent / 'mts-fire-directional-lapse-20261121'
    assert digest(prior / 'seal.json') == 'b3de88dae7ca047c80bba71d04957085dc3f6c805a5d1a89d0b747ad1587f16c'
    for name, signature in json.loads((prior / 'seal.json').read_bytes()).items():
        assert digest(prior / name) == signature, name
    for source in HOME.glob('*.py'):
        compile(source.read_bytes(), str(source), 'exec')
    def echo(kind, method):
        matches = [row for row in rows(f'forecast-{kind}-volume-8-{method}.csv') if row['observer'] == 'free' and row['path'] == 'echo']
        found, = matches
        return float(found['relativistic'])
    def shot(name, field, symmetry):
        data = rows(name)
        assert len(data) == 4 and {(math.copysign(1,float(row['first'])),math.copysign(1,float(row['second']))) for row in data} == {(1,1),(1,-1),(-1,1),(-1,-1)}
        assert max(float(row.get('intersection_max', row.get('residual_kpc'))) for row in data) < 4e-12
        return sum(float(row[field]) / (4 * float(row['first']) * float(row['second']) * LIGHT**4 * symmetry) for row in data)
    primary = echo('cross', 'matter')
    assert primary > 0 and abs(echo('cross', 'gr') / primary - 1) < 1e-9
    ray = {path.name: shot(path.name, 'echo', 1 if 'cross' in path.name else 2) for path in HOME.glob('rays-*-q2.csv')}
    assert len(ray) == 5 and all(abs(value / echo(name.split('-')[1], 'matter') - 1) < .002 for name, value in ray.items())
    def center(layout, kind='cross'):
        result, = [float(row['combination']) for row in rows(f'chain-{kind}-{layout}.csv') if float(row['middle_kpc']) == 7.15]
        return result
    central = center('volume')
    assert central > 0 and center('volume', 'raw') < 0 and center('volume', 'represented') < 0
    assert all(abs(center(layout) / central - 1) < 5e-6 for layout in ('radius', 'smooth-radius', 'smooth-volume'))
    chain = {path.name: shot(path.name, 'chain', 1) for path in HOME.glob('shot-chain-*.csv')}
    assert len(chain) == 2 and all(abs(value / central - 1) < .0012 for value in chain.values())
    jumps = {}
    for layout in ('volume', 'radius'):
        faces = rows(f'jump-{layout}.csv')
        assert len(faces) == 45
        jumps[layout] = math.sqrt(sum(float(row['error'])**2 for row in faces) / sum(float(row['prediction'])**2 for row in faces))
        assert jumps[layout] < 4.2e-9
    small = [float(row['fractional']) for row in rows('short-arm-limit-exact.csv') if float(row['width_kpc']) in (.00025, .0005)]
    assert len(small) == 4 and max(map(abs, small)) < 2e-6
    exact = rows('exact-schwarzschild.csv')
    for path in ('out', 'in', 'echo'):
        errors = [abs(float(row['relative_second'])) for row in sorted(exact, key=lambda row: -float(row['mass_kpc'])) if row['path'] == path]
        assert len(errors) > 2 and all(a > b for a, b in zip(errors, errors[1:])) and errors[-1] < 5e-5
    for order in (8, 12):
        controls = rows(f'single-current-check-{order}.csv')
        assert {row['arm'] for row in controls} == {'reset','coupled'}
        assert all(float(row['relative_dual']) < 1e-13 and float(row['operator_vs_current']) / float(row['peak_potential_rate']) < 1e-6 for row in controls)
    receipt('validation.json', dict(crossed=primary, ray=ray, jumps=jumps, center=central, chain=chain, short_arm=small), create)
    files = {path.name: digest(path) for path in sorted(HOME.iterdir()) if path.is_file() and path.name != 'seal.json'}
    receipt('seal.json', files, create)
    print('Verified', len(files), 'files', digest(HOME / 'seal.json'))


if __name__ == '__main__':
    if not __debug__:
        raise RuntimeError('Verification needs assertions enabled')
    verify(sys.argv[1:] == ['--seal'])
