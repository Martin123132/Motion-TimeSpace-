"""Exact radial jets from the split Green integrals, including the local density term in the divergence derivative."""
from geodesic_bank import HERE,Experiment,np,raw_bank,fields,roots_legendre,OBSERVER_R,angles,shell_sums,direct_current,acceleration_sources,packet,guard,sys

def build(layout='volume',faces=False):
    guard();box=Experiment(0,1);mass,edges=raw_bank(box);ends=box.lab.run.el.right*box.bg.length
    base=layout.removeprefix('smooth-')
    with np.load(HERE/f'bank-cross-{base}-8.npz') as old:oldpoints=old['r']
    widths=np.array([.128,.064,.032,.016,.008,.004,.002,.001,.0005,.00025,.000125,.0000625,.00003125,.000015625])
    ss=np.r_[6.+widths/2,6.-widths/2,8.3+widths/2,8.3-widths/2]
    if faces:
        borders=edges[(edges>np.hypot(6.,1.5))&(edges<np.hypot(8.3,1.5))]
        rings=np.sqrt(borders**2-1.5**2)
        ss=np.r_[ss,np.linspace(6.,8.3,185),6.+widths,(rings[:,None]+np.array([-.00012,.00012,-.00003,.00003,-.0000075,.0000075])).ravel()]
    points=np.unique(np.r_[oldpoints,np.hypot(ss,1.5)])
    ell=np.arange(0,133,2);angular=ell*(ell+1);norm=2*ell+1;coord=points[:,None]
    cuts=np.unique(np.r_[0.,ends,edges,points]);nd,rule=roots_legendre(8)
    r=(cuts[:-1,None]+np.diff(cuts)[:,None]*(1+nd)/2).ravel()
    iw=(np.diff(cuts)[:,None]*rule/2).ravel()
    tail,tw=roots_legendre(32);tail=(tail+1)/2;r=np.r_[r,ends[-1]/tail];iw=np.r_[iw,ends[-1]*tw/(2*tail**2)]
    allx=np.r_[r,points];host,wave=fields(box,mass,edges,allx,base,8)
    if layout.startswith('smooth-'):
        from continuous_host import Conservative
        reconstruction=Conservative(edges,layout)
        host=reconstruction.host(allx)
    mu,weight=roots_legendre(160);weight/=2
    v,d,_=angles(mu,ell);project=weight[:,None]*v
    def gradients(start):
        sl=slice(start,start+144)
        def sky(block):
            size=block[0].shape[1]
            return block[0][sl]@v[:,:size].T,block[1][sl]@v[:,:size].T,block[0][sl]@d[:,:size].T/allx[sl,None]
        u,ur,ut=sky(host);w,wr,wt=sky(wave)
        return np.stack([(ur*wr+ut*wt)@project,(u*w)@project,(ur*w+u*wr)@project],axis=1)
    g=np.concatenate([gradients(j) for j in range(0,len(allx),144)])
    src=acceleration_sources(allx,host,wave,ell,mu,weight).sum(axis=1)
    sr,st=src[:len(r),0],src[:len(r),1]
    A,br,bt,Y,Yr=direct_current(r,iw,points,ell,sr,st)
    def invert(deg,source):
        near,far=shell_sums(r,points,deg,(iw*r*r)[:,None]*source)
        return (-(near+far)/(2*deg+1),((deg+1)*near-deg*far)/(coord*(2*deg+1)))
    plus=invert(ell[1:]-1,((sr+(ell+1)*st)/norm)[:,1:]);minus=invert(ell[1:]+1,((ell*st-sr)/norm)[:,1:])
    mono=invert(ell[:1]+1,sr[:,:1])
    x,xr=[np.column_stack([m,ell[1:]*a-(ell[1:]+1)*b]) for a,b,m in zip(plus,minus,mono)]
    y,yr=[np.column_stack([np.zeros(len(points)),a+b]) for a,b in zip(plus,minus)]
    Ar=src[len(r):,0]+angular*((x-y)/coord**2-yr/coord)
    brr=-4*(xr-A+2*Yr/coord-angular*Y/coord**2)
    btr=-4*(yr-Yr/coord+Y/coord**2);btr[:,0]=0
    near,far=shell_sums(r,points,ell,(iw*r*r)[:,None]*g[:len(r),0])
    G=near+far;Gr=(-(ell+1)*near+ell*far)/coord
    p=norm*g[len(r):,1]+G;pr=norm*g[len(r):,2]+Gr
    vals=dict(r=points,p=p,p_r=pr,q=p+G-3*Y,q_r=pr+Gr-3*Yr,A=A,A_r=Ar,br=br,br_r=brr,bt=bt,bt_r=btr)
    for name,part in (('u',host),('w',wave)):
        for suffix,col in zip(('','_r','_lap'),part):
            vals[name+suffix]=col[len(r):]
    if layout.startswith('smooth-'):
        vals['mass_checks']=np.array([reconstruction.worst_mass,reconstruction.join_error,reconstruction.min_density])
    packet(f'face-jets-{layout}.npz' if faces else 'exact-jets-volume.npz',**vals)
if __name__=='__main__':
    build(sys.argv[1],True) if len(sys.argv)>1 else build()
