"""Conservative nonnegative within-bin controls; interpolate each positive population before differencing."""
from geodesic_bank import np,prior,roots_legendre,shell_sums
from matched_io import jf
from numpy.polynomial.legendre import legvander

class Conservative:
    def __init__(self,edges,layout):
        self.edges=edges
        self.power=3 if layout=='smooth-volume' else 1
        variable=edges**self.power;width=np.diff(variable)
        self.width=width
        with np.load(prior('frozen-weights.npz')) as original:
            tag=original['fine'].reshape(-1,256)
            raw=original['launch'].reshape(tag.shape)[:len(width)]
            rep=raw*tag[:len(width)]
        ell=np.arange(0,65,2);pol=legvander(jf.ANG,65)
        moment=np.ones((256,len(ell)))
        for idx,degree in enumerate(ell[1:],1):
            moment[:,idx]=np.diff(pol[:,degree+1]-pol[:,degree-1])/((2*degree+1)*np.diff(jf.ANG))
        self.worst_mass=0.;self.min_density=np.inf;self.join_error=0.
        parts=[]
        for distribution in (raw,rep):
            avg=distribution/width[:,None]
            slope=np.zeros((len(width)+1,256));wl=(2*width[1:]+width[:-1])[:,None];wr=(width[1:]+2*width[:-1])[:,None]
            use=(avg[:-1]>0)&(avg[1:]>0)
            slope[1:-1]=np.divide(wl+wr,wl/np.where(use,avg[:-1],1)+wr/np.where(use,avg[1:],1),out=np.zeros_like(avg[:-1]),where=use)
            co=np.stack((slope[:-1],6*avg-4*slope[:-1]-2*slope[1:],-6*avg+3*slope[:-1]+3*slope[1:]))
            recovered=width[:,None]*(co[0]+co[1]/2+co[2]/3)
            peak=distribution.max()
            self.worst_mass=max(self.worst_mass,np.max(abs(recovered-distribution))/peak)
            self.join_error=max(self.join_error,np.max(abs(co.sum(axis=0)-slope[1:]))/abs(avg).max())
            tip=np.clip(np.divide(-co[1],2*co[2],out=np.zeros_like(co[1]),where=co[2]!=0),0.,1.)
            self.min_density=min(self.min_density,np.min((co[0]+tip*(co[1]+tip*co[2]))/abs(avg).max()),
                                np.min(co[0]/abs(avg).max()),np.min(co.sum(axis=0)/abs(avg).max()))
            parts.append(co@moment)
        self.co=parts[0]-parts[1]
        assert self.worst_mass<1e-13 and self.min_density>-1.e-13 and self.join_error<1.e-13

    def density(self,rad):
        inside=rad<=self.edges[-1]
        idx=np.clip(np.searchsorted(self.edges,rad)-1,0,len(self.width)-1)
        x=np.clip((rad**self.power-self.edges[idx]**self.power)/self.width[idx],0.,1.)[:,None]
        return (self.co[0,idx]+x*(self.co[1,idx]+x*self.co[2,idx]))*((inside*self.power*rad**(self.power-1))[:,None])

    def host(self,radii):
        targets,order=np.unique(radii,return_inverse=True)
        knots=np.unique(np.r_[self.edges,targets[targets<self.edges[-1]]])
        n,w=roots_legendre(12)
        r=(knots[:-1,None]+np.diff(knots)[:,None]*(1+n)/2).ravel()
        wt=(np.diff(knots)[:,None]*w/2).ravel()
        ell=np.arange(0,65,2);near,far=shell_sums(r,targets,ell,self.density(r)*wt[:,None])
        gravity=jf.ls.G
        val=-gravity*(near+far);grad=gravity*((ell+1)*near-ell*far)/targets[:,None]
        lap=gravity*(2*ell+1)*self.density(targets)/targets[:,None]**2
        return [arr[order] for arr in (val,grad,lap)]
