"""Matched-location, matched-normal release with the derivative of the light travel time for moving endpoints."""
from geodesic_bank import HERE,np,sys,guard,table,LIGHT
from release_fields import Sky

LABELS=np.array([[6.,1.5],[8.3,1.5]])

def crossed(left,right):
    return np.sum(left*right[::-1])

def state(point,time,moving):
    vals,grad,hess,loc=(point[key] for key in ('V','grad','H','k'))
    second,jets,shift=(point[key] for key in ('second','jets','shift'))
    if moving=='free':
        pos=loc-.5*time*time*grad;vel=-time*grad;acc=-grad
        launch=-sum(hess[i]@loc[1-i] for i in range(2))-4*(vals@grad[::-1])-jets[0]-shift
        jerk=sum(hess[i]@grad[1-i] for i in range(2))-jets[2]
        velocity=time*launch+time**3*jerk/6
    else:
        pos=loc.copy() if moving=='rods' else np.zeros_like(loc)
        vel=np.zeros_like(grad);acc=vel.copy()
        velocity=np.array([point['cyl']*time*second[2],0.]) if moving=='rods' else np.zeros(2)
    rate=second[0]+time**2*second[2]/2+crossed(pos,grad)-.5*crossed(vel,vel)
    return pos,vel,acc,velocity,rate

def line_data(sky,start,end):
    delta=end-start;dist=np.linalg.norm(delta);normal=delta/dist
    def sample(x,w):
        vals,grad,_=sky.first_field(x);ss,_,shift,_=sky.second_field(x)
        return np.r_[vals,((1-w)*grad).ravel(),(w*grad).ravel(),ss[2],w*ss[2],normal@shift]
    integrated=sky.integrate(start,end,sample)
    mean=integrated[:2]/dist
    initial=2*np.outer(mean,normal)-2*integrated[2:6].reshape(2,2)
    final=-2*np.outer(mean,normal)-2*integrated[6:10].reshape(2,2)
    return normal,dist,-2*integrated[:2],initial,final,integrated[-3:]

def leg(emit,receive,begin,initial_delay,data,moving):
    n,dist,shapiro,shapiro_emit,shapiro_receive,integrals=data;end=begin+dist
    xe,ve,ae,vxe,re=state(emit,begin,moving)
    xr,vr,ar,vxr,rr=state(receive,end,moving)
    chord=xr-xe
    final_delay=initial_delay+chord@n+shapiro
    dn=(chord-np.outer(chord@n,n))/dist
    vdelta=(vxr-vxe)@n
    arrival=crossed(ar@n,final_delay)-crossed(ae@n,initial_delay)
    bending=crossed(dn,vr-ve)
    gravity_delay=crossed(shapiro_emit,ve)+crossed(shapiro_receive,vr)
    logs=((vr@n).prod()-(ve@n).prod())
    propagation=-2*(begin*integrals[0]+dist*integrals[1])+integrals[2]
    parts=dict(local_rates=rr-re,geodesic_velocity=vdelta,retimed_velocity=arrival,changed_direction=bending,
               shapiro_endpoint=gravity_delay,log_doppler=logs,dynamic_ray=propagation)
    newton=receive['V']-emit['V']+(vr-ve)@n
    return parts,newton,final_delay

def run(kind,layout,order,method):
    guard()
    sky=Sky(HERE/f'bank-{kind}-{layout}-{order}.npz',method)
    obs=[dict(sky.initial(x),cyl=x[0]) for x in LABELS]
    paths=[line_data(sky,*LABELS),line_data(sky,*LABELS[::-1])]
    rows=[]
    for observer in ('free','coordinate','rods'):
        outward,nout,delay=leg(*obs,0.,np.zeros(2),paths[0],observer)
        back,nback,_=leg(*obs[::-1],0.,np.zeros(2),paths[1],observer)
        after,nafter,_=leg(*obs[::-1],paths[0][1],delay,paths[1],observer)
        echo={k:outward[k]+after[k] for k in after}
        for label,item,newton in (('out',outward,nout),('in',back,nback),('echo',echo,nout+nafter)):
            conv=(1 if kind=='cross' else .5)/LIGHT**4
            rows.append(dict(kind=kind,layout=layout,order=order,method=method,observer=observer,path=label,
                             linear_U=newton[0]/LIGHT**2,linear_W=newton[1]/LIGHT**2,
                             **{key:value*conv for key,value in item.items()},relativistic=sum(item.values())*conv))
    table(HERE/f'forecast-{kind}-{layout}-{order}-{method}.csv',rows,True)

if __name__=='__main__':
    run(sys.argv[1],sys.argv[2],int(sys.argv[3]),sys.argv[4])
