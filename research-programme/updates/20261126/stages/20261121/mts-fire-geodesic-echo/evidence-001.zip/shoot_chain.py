"""Countercheck the fixed 2:2:-1 combination with independent geodesic pulse intersections."""
from shoot_gr import HERE,np,Sky,LABELS,Metric,propagate,sys,guard,table,LIGHT
import csv
def run(amp):
    assert (HERE/'chain-cross-volume.csv').exists()
    sky=Sky(HERE/'bank-cross-volume-8.npz','gr')
    middle=LABELS.mean(axis=0);output=[]
    rows=list(csv.DictReader((HERE/f'rays-cross-{amp:g}-q2.csv').read_text().splitlines()))
    for row in rows:
        guard()
        aa,bb=float(row['first']),float(row['second'])
        metric=Metric(sky,aa,bb)
        left,dl=propagate(metric,2,np.stack([LABELS[0],middle]),True)
        right,dr=propagate(metric,2,np.stack([middle,LABELS[1]]),True)
        full=float(row['echo'])
        output.append(dict(first=aa,second=bb,left=left[-1],right=right[-1],long=full,chain=2*(left[-1]+right[-1])-full,
                           intersection_max=max(dl[-1],dr[-1],float(row['residual_kpc']))))
    table(HERE/f'shot-chain-{amp:g}.csv',output,True)
    print(sum(r['chain']/(4*r['first']*r['second']*LIGHT**4) for r in output),flush=True)
if __name__=='__main__':
    run(float(sys.argv[1]))
