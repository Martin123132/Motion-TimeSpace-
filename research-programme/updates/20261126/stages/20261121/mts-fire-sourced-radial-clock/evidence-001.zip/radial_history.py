"""Source the part of the lapse fixed by the matter wave and its Newtonian metric."""
from mts_radial_inputs import *
CORE=('matter','self','cross','ordinary')
OUTER=('outer_self','outer_cross','outer_ordinary')
PROPER=('proper_cross','proper_ordinary')

def kernel_pair(steps):
    with np.load(locked(f'kernel-{steps}.npz')) as pack:common=pack['shared_lapse_SI'].sum(axis=-1)
    with np.load(locked(f'differential-kernel-{steps}.npz')) as pack:diff=pack['differential_lapse_SI'].sum(axis=-1)
    return common,diff

def profile_at_mid(left,right):
    return {key:(value+right[key])/2 for key,value in left.items()}

def evaluate(steps,variant,save):
    lab=Launch(steps);run=lab.run;obj=lab.obj
    order,lmax,method,interior={'main':(12,68,'green',False),'angles':(12,150,'green',False),
        'quadrature':(20,68,'green',False),'native':(12,68,'native',False),'half':(12,68,'green',True)}[variant]
    box=Radial(lab,order,lmax)
    count,dt=run.interval(590,600);solver=Evolution(obj,dt,lab.initial['reset'])
    halfsolver=Evolution(obj,dt/2,lab.initial['reset']) if interior else None
    common,diff=kernel_pair(steps)
    prob=lab.prob.sum(axis=1)
    values={};outputs={};diagnostics=[];quadrows=[]
    counts=(0,count)
    for tag,base in lab.initial.items():
        state=base.copy();profiles={};tangent=np.zeros_like(state);tangent_alt=np.zeros_like(state)
        old,rates=box.sample(state,lab.mesh.ordinary+run.fields[590],method)
        for tick in range(count+1):
            check()
            if tick in counts:
                for comp,(pr,zr) in rates.items():
                    diagnostics.append(dict(steps=steps,variant=variant,arm=tag,tick=tick,component=comp,
                        spatial_SI=pr,slip_SI=zr,time_SI=pr-zr))
            if tick==count:break
            ext=run.external(590,600,tick,count);step=Step(lab,solver,state,ext,dt)
            frac=(tick+1)/count
            next_ext=(1-frac)*run.fields[590]+frac*run.fields[600]
            new,rates=box.sample(step.right,lab.mesh.ordinary+next_ext,method)
            if interior:
                first_ext=run.fields[590]+((tick+.25)/count)*(run.fields[600]-run.fields[590])
                half_step=Step(lab,halfsolver,state,first_ext,dt/2)
                mid,_=box.sample(half_step.right,lab.mesh.ordinary+ext,method)
            else:mid=profile_at_mid(old,new)
            for name,arr in mid.items():profiles.setdefault(name,[]).append(arr)
            shown=sum(mid[name] for name in CORE+OUTER)
            alt=sum(mid[name] for name in PROPER)
            if variant=='main':
                tangent=step.forward(tangent,obj.multiply((shown-prob@shown)[:,None],step.mid))
                tangent_alt=step.forward(tangent_alt,obj.multiply((alt-prob@alt)[:,None],step.mid))
            state=step.right;old=new
        values[tag]={key:np.array(val) for key,val in profiles.items()}
        outputs[tag]=[lab.unit*lab.shell(state,target) for target in (tangent,tangent_alt)]
        error=run.err(state*np.exp(-1j*np.angle(np.vdot(lab.mesh.states[tag],state))),lab.mesh.states[tag])
        assert error<1e-8
        print(steps,variant,tag,'endpoint',error,flush=True)
    pieces={}
    for name in values['reset']:
        lhs=values['coupled'][name];rhs=values['reset'][name]
        mean=(lhs+rhs)/2;difference=lhs-rhs
        pieces[name]=np.array([np.sum(common*mean),np.sum(diff*difference)])
        quadrows.append(dict(steps=steps,variant=variant,component=name,shared_SI=pieces[name][0],
            differential_SI=pieces[name][1],total_SI=pieces[name].sum(),
            max_difference_half_range_Q=np.ptp(difference,axis=1).max()/2))
    subtotal=sum(pieces[name] for name in CORE)
    tail=sum(pieces[name] for name in OUTER);alt=sum(pieces[name] for name in PROPER)
    total=subtotal+tail
    if variant=='main':
        fwd=np.subtract(outputs['coupled'],outputs['reset'])
        for expected,actual in zip((total.sum(),alt.sum()),fwd,strict=True):
            assert abs(expected-actual)<1e-27+abs(expected)*1e-7,(expected,actual)
        archives={f'{tag}_{comp}':value for tag,parts in values.items() for comp,value in parts.items()}
        archives.update(radius_y=obj.bg.rad,tau_edges=np.arange(count+1)*dt)
        arrays(f'profiles-{steps}.npz',archives,save)
    else:fwd=['','']
    prior=records(locked(f'paired-{steps}.csv'))[0]
    new_space=float(prior['conditional_spatial_SI'])+total.sum();new_time=float(prior['conditional_time_SI'])+total.sum()
    changed=0.
    for tag,sign in [('coupled',1),('reset',-1)]:
        changed+=sign*sum(float(row['time_SI']) for row in diagnostics if row['tick']==count and row['arm']==tag and row['component'] in PROPER)
    qrow=dict(steps=steps,variant=variant,interior_shared_SI=subtotal[0],interior_differential_SI=subtotal[1],
        exterior_shared_SI=tail[0],exterior_differential_SI=tail[1],radial_lapse_wave_shift_SI=total.sum(),
        direct_propagation_SI=fwd[0],wave_if_only_differential_SI=total[1]+float(prior['density_state_SI']),
        wave_with_radial_SI=float(prior['density_state_SI'])+total.sum(),spatial_with_radial_SI=new_space,
        time_with_radial_SI=new_time,proper_alternative_wave_increment_SI=alt.sum(),
        proper_alternative_endpoint_increment_SI=changed,direct_alt_propagation_SI=fwd[1],
        spatial_if_fixed_proper_SI=new_space+alt.sum()+changed,time_if_fixed_proper_SI=new_time+alt.sum()+changed)
    for filename,rows in [('drive',quadrows),('matched',[qrow]),('edges',diagnostics)]:
        table(HERE/f'{filename}-{variant}-{steps}.csv',rows,save)

if __name__=='__main__':
    assert sys.argv[1] in ('32','64') and sys.argv[2] in ('main','quadrature','angles','native','half') and sys.argv[3:] in ([],['--save'])
    evaluate(int(sys.argv[1]),sys.argv[2],bool(sys.argv[3:]))
