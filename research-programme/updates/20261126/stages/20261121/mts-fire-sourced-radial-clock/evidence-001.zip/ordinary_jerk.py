"""First ordinary-current dependence at a common launch: mass and gravity through cubic order."""
from ordinary_momentum import Probe
from mts_radial_inputs import *
from scipy.special import betainc

def evaluate(steps,save):
    lab=Launch(steps);obj=lab.obj;probe=Probe(lab,20,padding=.02)
    source=lab.mesh.ordinary+lab.run.fields[590]
    ov,og,rho,jump=probe.measured(source,True)
    mu=obj.bg.mu;degs=probe.ls;rr=probe.r[:,None]
    basis=eval_legendre(degs[:,None],mu)*np.sqrt(2*degs[:,None]+1)
    theta=np.zeros_like(basis)
    for idx,deg in enumerate(degs[1:],1):
        theta[idx]=-np.sqrt(2*deg+1)*deg*(eval_legendre(deg-1,mu)-mu*eval_legendre(deg,mu))/np.sqrt(1-mu**2)
    forces={};rates={};second={};mixed={}
    zero=np.zeros_like(lab.initial['reset'])
    for arm,state in lab.initial.items():
        check();potential=obj.phi(obj.moment(state))
        velocity=-1j*(obj.bare@state+obj.multiply(lab.run.fields[590]+potential,state)-obj.mu*state)
        val,der,curv=probe.heavydifference(zero,state,True)
        _,dot_der,_=probe.heavydifference((state-velocity)/np.sqrt(2),(state+velocity)/np.sqrt(2),True)
        forces[arm]=(-(og+der)@basis,-((ov+val)@theta)/rr)
        rates[arm]=dot_der@basis
        second[arm]=curv@basis
        mixed[arm]=(der@theta)/rr-(val@theta)/rr**2
    gr,gt=[-(forces['coupled'][k]-forces['reset'][k]) for k in range(2)]
    dot_grad=rates['coupled']-rates['reset'];hrr=second['coupled']-second['reset'];hrt=mixed['coupled']-mixed['reset']
    density=np.vstack([rho[:probe.ordinary_count]@basis,jump[probe.ordinary_count:]@basis])
    w=probe.r**2*np.r_[probe.w,np.ones(len(probe.faces))]
    mass=density*(w[:,None]*obj.bg.aw)
    coords=np.clip((probe.r-probe.lo)/(probe.hi-probe.lo),0,1)
    slope=192*coords**2*(1-coords)**2*(1-2*coords)/(probe.hi-probe.lo)
    dd=384*coords*(1-coords)*((1-2*coords)**2-coords*(1-coords))/(probe.hi-probe.lo)**2
    window=(4*coords*(1-coords))**3
    integral=probe.lo**2+probe.lo*(probe.hi-probe.lo)+5/18*(probe.hi-probe.lo)**2
    volume=(16/35)*(probe.hi-probe.lo)*integral
    rows=[];tests=[];jets=[]
    for name,first,secondW,unit in [('mass',slope,dd,lab.mesh.mscale),('gravity',window/volume,slope/volume,lab.unit/lab.mesh.ep)]:
        first=first[:,None];secondW=secondW[:,None];scale=unit/obj.unit_myr**3
        kr=-3*secondW*gr-first*hrr
        kt=-3*first*gt/rr-first*hrt
        for family,vr,vt,vp in [('static',0.,0.,0.),('azimuthal',0.,0.,.8),('meridional',.53*mu,-.28*np.sqrt(1-mu**2),.2)]:
            kinematic=-dot_grad-vr*hrr-vt*hrt
            targets=[]
            for half in (0,1):
                select=probe.bins==half
                geometric=np.sum((-first*dot_grad*mass)[select])*scale
                current=np.sum(((vr*kr+vt*kt)*mass)[select])*scale
                budget=np.sum((abs(mass)*np.hypot(kr,kt))[select])*scale/obj.bg.vel
                targets.append(geometric+current)
                rows.append(dict(steps=steps,half=half+1,observable=name,stream_control=family,field_jerk=geometric,
                    current_jerk=current,net=geometric+current,unknown_jerk_bound_per_kms=budget,
                    minimum_max_meridional_speed_kms_to_cancel=abs(geometric)/budget))
            active=((probe.r>probe.lo)&(probe.r<probe.hi))[:,None]
            coeff=[0,0,0,64,-192,192,-64] if name=='mass' else [-1,0,0,0,35,-84,70,-20]
            cubic=np.zeros_like(mass)
            for arm,sign in [('coupled',1),('reset',-1)]:
                ar,at=forces[arm];width=(probe.hi-probe.lo)[:,None]
                r2=(vt**2+vp**2+rr*ar)/(2*rr)
                r3=(vr*ar+vt*at+rr*sign*kinematic/6-2*vr*r2)/(2*rr)
                z0=coords[:,None];z1=vr/width;z2=r2/width;z3=r3/width
                p0=p1=p2=p3=0.
                for constant in reversed(coeff):
                    p0,p1,p2,p3=(constant+z0*p0,z1*p0+z0*p1,z2*p0+z1*p1+z0*p2,z3*p0+z2*p1+z1*p2+z0*p3)
                cubic+=sign*active*p3*(1. if name=='mass' else 1/integral[:,None])
            for half,target in enumerate(targets):
                observed=6*np.sum((mass*cubic)[probe.bins==half])*scale
                assert abs(observed/target-1)<2e-7,(name,half,observed,target)
                jets.append(dict(steps=steps,half=half+1,observable=name,stream_control=family,
                                 characteristic_taylor=observed,predicted=target,relative_error=observed/target-1))
            for power in (8,9,10):
                dt=2.**-power;change=np.zeros_like(mass)
                for time_sign in (-1,1):
                    step=time_sign*dt
                    for arm,sign in [('coupled',1),('reset',-1)]:
                        ar,at=forces[arm]
                        radial=rr+step*vr+.5*step**2*ar+step**3*sign*kinematic/12
                        distance=np.sqrt(radial**2+(step*vt+.5*step**2*at)**2+(step*vp)**2)
                        phase=np.clip((distance-probe.lo[:,None])/(probe.hi-probe.lo)[:,None],0,1)
                        weight=(4*phase*(1-phase))**3 if name=='mass' else -betainc(4,4,1-phase)/integral[:,None]
                        change+=time_sign*sign*weight
                for half,target in enumerate(targets):
                    observed=3*np.sum((mass*change)[probe.bins==half])/dt**3*scale
                    tests.append(dict(steps=steps,half=half+1,observable=name,stream_control=family,power=power,
                                      characteristic_jerk=observed,predicted=target,relative_error=observed/target-1))
    table(HERE/f'ordinary-jerk-{steps}.csv',rows,save);table(HERE/f'jerk-control-{steps}.csv',tests,save)
    table(HERE/f'jerk-taylor-{steps}.csv',jets,save)
if __name__=='__main__':
    assert sys.argv[1] in ('32','64') and sys.argv[2:] in ([],['--save'])
    evaluate(int(sys.argv[1]),bool(sys.argv[2:]))
