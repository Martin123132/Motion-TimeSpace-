"""Closed-form tests for both radial inverses, nonspherical Newtonian sources and the tail."""
from mts_radial_inputs import *

def evaluate(save):
    lab=Launch(64);rows=[]
    def test(name,found,target,scale):
        error=np.max(abs(found-target))/scale
        assert error<2e-9,(name,error)
        rows.append(dict(control=name,max_scaled_error=error))
    for ord in (12,20):
        box=Radial(lab,ord);radius=box.rad;rr=box.grid[1:];edge=box.inf
        def compare(name,found,target):
            test(f'{ord}: '+name,found,target,max(1e-8,np.max(abs(target))))
        source=(radius/edge)**4;anis=(radius/edge)**2
        pp,zz,dp,dz=box.green(source,anis)
        compare('regular Poisson volume',pp,-(rr**6/7+(edge**6-rr**6)/6)/edge**4)
        compare('trace-free integral',zz,((edge**4-rr**4)/4-rr**2*(edge**2-rr**2)/2)/edge**2)
        compare('normal radial derivative',dp,rr**5/(7*edge**4))
        compare('trace-free radial derivative',dz,-rr*(edge**2-rr**2)/edge**2)
        raw=np.zeros((*radius.shape,len(box.well)),complex);raw[:,:,0]=.7*radius;raw[:,:,1]=.45*radius*(radius/edge)**2
        result=box.sourced_newton(raw)[1:]
        for index,terms in enumerate(([ (.49,0),(.45**2,4)],[(2*.7*.45,2),(.45**2*10/(7*np.sqrt(5)),4)],
                                      [(.45**2*6/7,4)])):
            degree=2*index;answer=np.zeros_like(rr)
            for coeff,power in terms:
                exponent=power+2-degree
                inner=rr**(power+2)/(power+degree+3);outer=rr**degree*(edge**exponent-rr**exponent)/exponent
                answer-=coeff/edge**power*(inner+outer)/(2*degree+1)
            compare(f'open multipole degree {degree}',result[:,index],answer)
        test(f'{ord}: no spurious degree six and above',result[:,3:],0.,np.max(abs(result[:,0])))
        a=.31;b=-.22
        def field(scale,target):return scale*target[...,None]**2,2*scale*target[...,None]
        profiles,rates=box.quadratics(field(a,radius),field(b,radius),field(a,rr),field(b,rr),0.*radius,0.*radius)
        nodes=lab.obj.bg.rad;expected=-18*a*b*nodes**4/20
        compare('proper ordinary source integrated independently',profiles['proper_cross']-profiles['proper_cross'][0],expected-expected[0])
        compare('proper ordinary derivative',rates['proper_cross'][0],-lab.unit*lab.mesh.weights@(-18*a*b*lab.mesh.knots**3/5))
    nodes,weights=roots_legendre(96);x=(1+nodes)/2;weights/=2
    rng=np.random.default_rng(4267);degs=box.sell
    for index in range(3):
        first=rng.normal(size=len(degs))/(1+degs)**2;other=rng.normal(size=len(degs))/(1+degs)**2
        radial=(x[:,None]**(2*degs+3))*(degs+1)*(degs+2)/2
        direct=(weights@radial)@(first*other)/edge**2
        compare(f'independent exterior quadrature {index}',direct,np.sum((degs+1)*first*other)/(4*edge**2))
    table(HERE/'manufactured.csv',rows,save)
if __name__=='__main__':
    assert sys.argv[1:] in ([],['--save'])
    evaluate(bool(sys.argv[1:]))
