"""Verify the signed radial match, variance checks, momentum identities and private seal."""
from mts_radial_inputs import *

def verify(save):
    check()
    for name in manifest:locked(name)
    expected={'PROTOCOL.md','DERIVATION.md','ORDINARY-RESPONSE.md','RESULTS.md','verify.py','mts_radial_inputs.py','manufactured.py',
              'radial_history.py','exterior.py','ordinary_momentum.py','ordinary_kick.py','ordinary_jerk.py','current_reduction.py','validation.json'}
    count=0;outputs={}
    def load(name,n):
        nonlocal count
        name+='.csv';expected.add(name);result=records(HERE/name);count+=len(result)
        assert len(result)==n and all(None not in row and all(value is not None and value.lower() not in ('nan','inf','-inf') for value in row.values()) for row in result),name
        return result
    manufactured=load('manufactured',23)
    assert max(float(row['max_scaled_error']) for row in manufactured)<2e-9
    for steps in (32,64):
        main=None;tests={}
        for version in (['main'] if steps==32 else ['main','quadrature','angles','native','half']):
            key=f'{version}-{steps}'
            drive=load('drive-'+key,9);edges=load('edges-'+key,24);row,=load('matched-'+key,1)
            source=float(row['radial_lapse_wave_shift_SI'])
            correct=sum(float(item['total_SI']) for item in drive if not item['component'].startswith('proper'))
            assert abs(correct/source-1)<1e-11
            if main is None:main=source
            tests[version]=source/main-1
            assert float(row['spatial_with_radial_SI'])>0 and float(row['spatial_if_fixed_proper_SI'])>0
            if version=='main':
                assert abs(float(row['direct_propagation_SI'])/source-1)<1e-8
                assert abs(float(row['direct_alt_propagation_SI'])/float(row['proper_alternative_wave_increment_SI'])-1)<1e-8
                prior,=[line for line in records(parent_file('potentials.csv')) if (line['steps'],line['order'],line['method'],line['arm'])==(str(steps),'28','green','coupled')]
                for label,col in [('spatial','spatial_PN'),('slip','slip_PN'),('time','time_PN')]:
                    probe=sum((1 if item['arm']=='coupled' else -1)*float(item[label+'_SI']) for item in edges if int(item['tick'])>0 and not item['component'].startswith('proper'))
                    assert abs(probe/float(prior[col])-1)<2e-5
        packet=f'profiles-{steps}.npz';expected.add(packet)
        with np.load(HERE/packet) as archive:
            assert len(archive.files)==20
            assert all(np.isfinite(archive[name]).all() for name in archive.files)
        modes=load(f'homogeneous-{steps}',12);tail,=load(f'exterior-{steps}',1)
        assert max(float(r['gain_SI']) for r in modes if r['mode']=='constant')<1e-30
        balance=load(f'ordinary-balance-{steps}',16)
        assert all(float(r['minimum_support_stress_dimensionless'])>0 and abs(float(r['weak_force_moment'])/float(r['relative_force_moment'])-1)<2e-7 for r in balance)
        assert all(abs(float(r['weak_mass_curvature_Msun_per_Myr2'])/float(r['weighted_mass_curvature_Msun_per_Myr2'])-1)<2e-7 for r in balance)
        kicks=load(f'ordinary-kick-{steps}',16)+load(f'ordinary-gravity-{steps}',16)
        assert max(abs(float(r['relative_error'])) for r in kicks if r['power']=='12')<2e-5
        jerk=load(f'ordinary-jerk-{steps}',12);short=load(f'jerk-control-{steps}',36);jets=load(f'jerk-taylor-{steps}',12)
        assert max(abs(float(r['relative_error'])) for r in jets)<2e-7
        limits=load(f'current-reduction-{steps}',8);null=load(f'current-controls-{steps}',8)
        assert min(float(r['gain_reduction']) for r in limits)>1
        for r in null:
            for prefix in ('gradient_current','solenoidal'):
                assert abs(float(r[prefix+'_direct'])/float(r[prefix+'_reduced'])-1)<2e-7
        outputs[str(steps)]=dict(radial_shift_SI=main,variants_relative=tests,max_finite_cubic_relative_at_shortest=
            max(abs(float(r['relative_error'])) for r in short if r['power']=='10'),max_characteristic_jet_relative=max(abs(float(r['relative_error'])) for r in jets))
    receipt=dict(parent_seal=EXPECTED,rows=count,tests=outputs,scope='scalar radial response; conditional ordinary launch, not a live 22 Myr ordinary trajectory')
    keep(HERE/'validation.json',(json.dumps(receipt,indent=2,sort_keys=True)+'\n').encode(),save)
    actual={f.name for f in HERE.iterdir()}-{'seal.json'}
    assert actual==expected,(actual-expected,expected-actual)
    keep(HERE/'seal.json',(json.dumps({name:digest(HERE/name) for name in sorted(expected)},indent=2,sort_keys=True)+'\n').encode(),save)
    print('Verified',count,'rows,',len(expected),'sealed files:',digest(HERE/'seal.json'))
if __name__=='__main__':
    assert sys.argv[1:] in ([],['--save'])
    verify(bool(sys.argv[1:]))
