"""Displace the same foreground by two gravitational accelerations and difference the enclosed weights."""
from ordinary_momentum import Probe
from mts_radial_inputs import *
from scipy.special import betainc

def run(steps,save):
    lab=Launch(steps);p=Probe(lab,22,padding=.02);obj=lab.obj;unit=obj.unit_myr
    source=lab.mesh.ordinary+lab.run.fields[590]
    op,od,rho,jump=p.measured(source,True)
    mu=obj.bg.mu;weights=obj.bg.aw
    basis=eval_legendre(p.ls[:,None],mu)*np.sqrt(2*p.ls[:,None]+1)
    theta=np.zeros_like(basis)
    for idx,deg in enumerate(p.ls[1:],start=1):
        theta[idx]=np.sqrt(2*deg+1)*deg*(eval_legendre(deg-1,mu)-mu*eval_legendre(deg,mu))/np.sqrt(1-mu**2)
    forces={}
    for arm,state in lab.initial.items():
        check()
        val,grad,_=p.heavydifference(np.zeros_like(state),state,True)
        forces[arm]=(-(od+grad)@basis,((op+val)@theta)/p.r[:,None])
    density=np.vstack([rho[:p.ordinary_count]@basis,jump[p.ordinary_count:]@basis])
    w=p.r**2*np.r_[p.w,np.ones(len(p.faces))]
    mass=density*(w[:,None]*weights)
    ref=[row for row in records(HERE/f'ordinary-balance-{steps}.csv') if row['epoch']=='590' and row['r_times_V']=='True' and row['order']=='22']
    results=[];geometry=[]
    rr=p.r[:,None]
    for initial in ('static','stream'):
        vr=0. if initial=='static' else .53*mu
        vt=0. if initial=='static' else -.28*np.sqrt(1-mu**2)
        for power in (6,8,10,12):
            h=2.**-power
            change=np.zeros_like(density)
            field_change=np.zeros_like(density)
            for sign in (-1,1):
                for arm,matched in [('reset',-1),('coupled',1)]:
                    radial,tang=forces[arm]
                    distance=np.hypot(rr+sign*h*vr+.5*h*h*radial,sign*h*vt+.5*h*h*tang)
                    assert np.max(abs(distance-rr))<.02
                    coord=np.clip((distance-p.lo[:,None])/(p.hi-p.lo)[:,None],0,1)
                    change+=matched*(4*coord*(1-coord))**3
                    field_change-=matched*betainc(4,4,1-coord)
            for half in (0,1):
                pick=p.bins==half
                value=np.sum((change*mass)[pick])/h**2*lab.mesh.mscale/unit**2
                expected=float(ref[half]['weighted_mass_curvature_Msun_per_Myr2'])
                results.append(dict(steps=steps,half=half+1,initial=initial,power=power,dt_Myr=h*unit,
                                    finite_curvature_Msun_per_Myr2=value,expected=expected,relative_error=value/expected-1))
                lower,upper=lab.mesh.knots[half:half+2];width=upper-lower
                integral=lower**2+lower*width+5/18*width**2
                volume=(16/35)*width*integral
                acceleration_unit=lab.unit/lab.mesh.ep/unit**2
                numerical=np.sum((field_change*mass)[pick])/h**2/integral*acceleration_unit
                predicted=-float(ref[half]['relative_force_moment'])/volume*acceleration_unit
                geometry.append(dict(steps=steps,half=half+1,initial=initial,power=power,
                                     gravity_curvature_SI_per_Myr2=predicted,kick_SI_per_Myr2=numerical,
                                     relative_error=numerical/predicted-1))
    for row in results:
        if row['power']==12:
            assert abs(row['relative_error'])<2e-5,(steps,row)
    table(HERE/f'ordinary-kick-{steps}.csv',results,save)
    assert all(abs(row['relative_error'])<2e-5 for row in geometry if row['power']==12)
    table(HERE/f'ordinary-gravity-{steps}.csv',geometry,save)

if __name__=='__main__':
    assert sys.argv[1] in ('32','64') and sys.argv[2:] in ([],['--save'])
    run(int(sys.argv[1]),bool(sys.argv[2:]))
