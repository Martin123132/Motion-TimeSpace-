import csv
import json
import re
import sys
from base import HERE,PREV,PIN,digest,check_parent,save,read,np
def run():
    check_parent()
    assert sys.flags.optimize==0
    pins={"freeze":{"design":"DESIGN.md","forecast":"forecast.py","coefficients":"exposure-coefficients.csv","readings":"frozen-exposures.csv","weights":"frozen-weights.json"},
          "geometry-freeze":{"original":"freeze.json","design":"MOVING-NULL-DESIGN.md","method":"design_aperture.py","series":"geometry-series.csv","measurements":"geometry-forecasts.csv"},
          "timing-freeze":{"design":"TIMING-DESIGN.md","geometry":"geometry-freeze.json","method":"timing_forecast.py","predictions":"timing-forecasts.csv"}}
    for item,mapping in pins.items():
        record=json.loads((HERE/(item+".json")).read_bytes())
        for field,name in mapping.items():assert record[field]==digest(HERE/name)
    assert json.loads((HERE/"freeze.json").read_bytes())["parent"]==PIN
    files=sorted(HERE.iterdir());assert all(path.is_file() and path.suffix in (".md",".csv",".json",".py") for path in files)
    for path in HERE.glob("*.md"):
        for link in re.findall(r"\]\(([^)]+)\)",path.read_text(encoding="utf8")):
            if not link.startswith("https:"):assert (HERE/link).is_file()
    counts={}
    for path in HERE.glob("*.csv"):
        with path.open(encoding="utf8",newline="") as stream:
            reader=csv.DictReader(stream);assert len(set(reader.fieldnames))==len(reader.fieldnames);rows=list(reader)
        assert rows and all(None not in row and all(val not in (None,"","NaN","nan","inf","-inf") for val in row.values()) for row in rows)
        counts[path.name]=len(rows)
    assert len(list(HERE.glob("retarded-space*.csv")))==4 and len(list(HERE.glob("geometry-space*.csv")))==2
    for path in HERE.glob("retarded-space*.csv"):assert counts[path.name]==36
    for path in HERE.glob("geometry-space*.csv"):assert counts[path.name]==60
    checks=json.loads((HERE/"assessment.json").read_bytes())
    assert max(checks["time_change"],checks["fine_space"],checks["geometry_refinement"],checks["triple_discrepancy"])<2e-8
    assert checks["kernel_error"]<2e-12 and counts["shell-plane-controls.csv"]==240
    for row in read("geometry-decisions.csv"):
        gate=max(abs(float(row[key])) for key in ("ordinary","D","W_forecast_error"))<2e-8
        assert (row["inside"]=="True")==gate==(row["time"]=="0.12" or (row["time"]=="0.24" and row["order"]=="12"))
    assert counts["geometry-decisions.csv"]==12 and counts["three-window-test.csv"]==6 and counts["timing-sensitivity.csv"]==6
    assert all(abs(float(row["residual"]))<2e-8 for row in read("three-window-test.csv"))
    assert all(float(row["error"])<2e-11 for row in read("fixed-endpoint-delay.csv"))
    optical=json.loads((HERE/"optical-normalization.json").read_bytes())
    assert optical["tangential_abs_derivative"]==24 and optical["empirical_coefficient"] is None
    paths=[next(HERE.parent.glob(prefix+"-*.md")) for prefix in ("4945","4947","4964")]
    manifest=dict(parent=PIN,research_inputs={path.name:digest(path) for path in paths},table_counts=dict(sorted(counts.items())),
                  files={path.name:digest(path) for path in files if path.name!="seal.json"})
    if sys.argv[1:]==["--seal"]:save("seal.json",manifest)
    else:assert not sys.argv[1:]
    assert manifest==json.loads((HERE/"seal.json").read_bytes())
    print(len(manifest["files"]),"files",sum(counts.values()),"CSV rows",digest(HERE/"seal.json"))
if __name__=="__main__":run()
