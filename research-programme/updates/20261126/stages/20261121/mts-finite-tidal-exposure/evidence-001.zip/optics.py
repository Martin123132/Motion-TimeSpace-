"""Compare the full-index parent action's two ray characteristics with its tidal-source normalization."""
from base import HERE,np,table,save
from scipy.integrate import quad
import sympy as sp

def curvature(pos):
    radius=np.linalg.norm(pos);normal=np.array(pos)/radius
    hessian=(np.eye(3)-3*np.outer(normal,normal))/radius**3
    jets=np.zeros((4,4,4,4))
    jets[1:,1:]=-2*hessian[:,:,None,None]*np.eye(4)
    perm=lambda out:np.einsum("abcd->"+out,jets)
    tensor=(perm("cabd")+perm("acdb")-perm("acbd")-perm("cadb"))/2
    assert np.max(abs(np.einsum("ac,abcd->bd",np.diag([-1,1,1,1]),tensor)))<2e-14
    return tensor

def run():
    coupling,tide,omega,wave,a1,a2=sp.symbols("c q omega k a1 a2",real=True)
    action=(omega**2-wave**2)*(a1**2+a2**2)/2+4*coupling*tide*((-2*omega**2-wave**2)*a1**2+(omega**2+2*wave**2)*a2**2)
    speeds=[]
    for amp in (a1,a2):
        eigen=sp.expand(action.diff(amp,2))
        speed2=sp.factor(-eigen.coeff(wave,2)/eigen.coeff(omega,2))
        speeds.append(speed2)
    slopes=[sp.diff(entry,coupling).subs(coupling,0)/tide for entry in speeds]
    assert set(slopes)=={-24,24}
    rows=[]
    for cos_theta in (0.,.2,.5,.8,1.,-.6):
        sine=np.sqrt(1-cos_theta**2)
        ray=np.array([1.,cos_theta,sine,0.])
        screen=np.array([[0.,-sine,cos_theta,0.],[0.,0.,0.,1.]])
        curv=curvature([1.,0.,0.])
        optical=np.einsum("a,ib,c,jd,abcd->ij",ray,screen,ray,screen,curv)
        derivatives=np.linalg.eigvalsh(8*optical)
        assert max(abs(derivatives-24*sine**2*np.array([-1.,1.])))<1e-13
        rows.append(dict(radial_cos=cos_theta,lower=derivatives[0],upper=derivatives[1],primary_2003_magnitude=12*sine**2))
    table("optical-characteristics.csv",rows)
    paths=[]
    for start,end in ((-1.,1.),(-2.,5.),(.5,3.),(-30.,30.)):
        def analytic(at):
            shape=at/np.sqrt(1+at*at)
            return shape-shape**3/3
        ray=np.array([1.,0.,0.,1.])
        screen=np.array([[0.,1.,0.,0.],[0.,0.,1.,0.]])
        def split(at):
            mat=np.einsum("a,ib,c,jd,abcd->ij",ray,screen,ray,screen,curvature([1.,0.,at]))
            eig=np.linalg.eigvalsh(mat)
            return 4*(eig[1]-eig[0])
        predicted=24*(analytic(end)-analytic(start))
        actual,err=quad(split,start,end,epsabs=1e-11,epsrel=1e-12)
        assert abs(actual-predicted)<2e-11
        paths.append(dict(start_over_b=start,end_over_b=end,predicted=predicted,integrated=actual,error=abs(actual-predicted)))
    table("fixed-endpoint-delay.csv",paths)
    save("optical-normalization.json",dict(action="full antisymmetric spacetime indices; coefficient multiplying CFF",speed_squared=[str(v) for v in speeds],
        tangential_abs_derivative=24,retained_old_abs_derivative=12,far_to_far_split_factor=32,empirical_coefficient=None))
if __name__=="__main__":run()
