"""Time-average of three retarded harmonic metric components on translated Gaussian apertures."""
from collections import defaultdict
from functools import lru_cache
from itertools import combinations_with_replacement,product
from math import comb,factorial
import sys
from base import HERE,WIDTH,CENTRE,TIMES,CHANNELS,np,table,save,guard,digest,check_parent
from wilson import ETA,BIVECS,traceless
from scipy.special import roots_hermitenorm,eval_hermitenorm,spherical_in
from numpy.polynomial.legendre import leggauss

PAIRS=list(combinations_with_replacement(range(6),2))
YZ=(2,3); OY=(0,2); OZ=(0,3)
def minimal_components(ind):
    if ind==YZ:return {(1,2):-1.,(4,5):-1.}
    axis=ind[1]-1
    return {((axis+1)%3,3+(axis+2)%3):-1.,((axis+2)%3,3+(axis+1)%3):1.}
@lru_cache(None)
def kernels():
    result=defaultdict(list)
    for ind in (YZ,OY,OZ):
        pol=np.zeros((4,4));pol[ind]=pol[ind[::-1]]=1.
        minimal=minimal_components(ind)
        for pair,amp in minimal.items():
            result["ordinary",ind].append((amp,0,(),PAIRS.index(pair)))
            result["D",ind].append((amp,2,(),PAIRS.index(pair)))
            for axis in range(3):result["D",ind].append((-amp,0,(axis,axis),PAIRS.index(pair)))
        for first,second in combinations_with_replacement(range(4),2):
            def der(a,b,c,d):return pol[c,d] if tuple(sorted((a,b)))==(first,second) else 0.
            riem=np.array([.5*(der(b,c,a,d)+der(a,d,b,c)-der(a,c,b,d)-der(b,d,a,c)) for a,b,c,d in product(range(4),repeat=4)]).reshape(4,4,4,4)
            mapped=ETA[ind[0],ind[0]]*ETA[ind[1],ind[1]]*np.einsum("abcd,iab,jcd->ij",traceless(riem),BIVECS,BIVECS)
            indices=tuple(value-1 for value in (first,second) if value)
            for column,(aa,bb) in enumerate(PAIRS):
                amp=mapped[aa,bb]+(mapped[bb,aa] if aa!=bb else 0.)
                if abs(amp)>1e-14:result["W",ind].append((amp,2-len(indices),indices,column))
    return result

def maxwell(position,time):
    radius=np.linalg.norm(position,axis=1)
    assert min(radius)>1e-4
    normal=position/radius[:,None]
    axis=np.array([0.,0.,1.]);az=np.cross(normal,axis);plane=normal*normal[:,2:3]
    left=radius-time;right=radius+time
    near=[eval_hermitenorm(order,left)*np.exp(-left**2/2) for order in range(7)]
    far=[eval_hermitenorm(order,right)*np.exp(-right**2/2) for order in range(7)]
    gradients=[];poloids=[]
    for degree in range(5):
        sign=(-1)**degree
        scalar=(near[degree]-sign*far[degree])/(2*radius)
        grad=(-near[degree+1]+sign*far[degree+1])/(2*radius)-scalar/radius
        second=(near[degree+2]-sign*far[degree+2])/(2*radius)-2*grad/radius
        adjusted=grad/radius
        gradients.append(grad[:,None]*az)
        poloids.append((second-adjusted)[:,None]*plane-(second+adjusted)[:,None]*axis)
    tor=[np.column_stack((gradients[degree+1],-poloids[degree])) for degree in range(3)]
    pol=[np.column_stack((poloids[degree+1],gradients[degree+2])) for degree in range(3)]
    return tor,pol

def field_product(tor,pol,degree,pair):
    first,second=pair
    return 2*sum(comb(degree,other)*(tor[other][:,first]*pol[degree-other][:,second]+tor[other][:,second]*pol[degree-other][:,first]) for other in range(degree+1))

class Aperture:
    def __init__(self,order,sign,width=WIDTH,centre=CENTRE):
        nodes,weights=roots_hermitenorm(order)
        self.offset=np.stack(np.meshgrid(nodes,nodes,nodes,indexing="ij"),axis=-1).reshape(-1,3)
        self.width=width
        self.pos=self.offset*width+[sign*centre,0.,0.]
        self.mass=np.einsum("i,j,k->ijk",weights,weights,weights).ravel()/(2*np.pi)**1.5
        self.rad=np.sum(self.offset**2,axis=1)**.5
        self.polynomials={}
    def radial(self,distance):
        h=distance/self.width;arg=h*self.rad
        def sph(order):
            if h==0:return np.ones_like(arg)/np.prod(np.arange(1,2*order+2,2))
            return spherical_in(order,arg)/arg**order
        phi=[(h*h/2)**jj*sph(jj) for jj in range(4)]
        chi=[np.cosh(arg)]+[(h*h/2)**jj*sph(jj-1) for jj in range(1,4)]
        values=[]
        for series in ([aa-h*h*bb for aa,bb in zip(chi,phi,strict=True)],[distance*entry for entry in phi]):
            values.append([self.mass*np.exp(-h*h/2)*sum(comb(jj,kk)*(-.5)**(jj-kk)*series[kk] for kk in range(jj+1)) for jj in range(4)])
        return values
    def prefactors(self,indices):
        if indices in self.polynomials:return self.polynomials[indices]
        degree=len(indices)
        power=[indices.count(idx) for idx in range(3)]
        by_order={}
        for pairs in product(*(range(1+value//2) for value in power)):
            term=(-1/self.width)**degree
            for idx,(size,count) in enumerate(zip(power,pairs,strict=True)):
                term=term*factorial(size)/(factorial(count)*factorial(size-2*count))*(2*self.offset[:,idx])**(size-2*count)
            key=degree-sum(pairs);by_order[key]=by_order.get(key,0)+term
        self.polynomials[indices]=by_order
        return by_order
    def point(self,time,distance):
        tor,pol=maxwell(self.pos,time)
        radials=self.radial(distance);cache={};fields={}
        readings=np.zeros((3,2))
        for col,channel in enumerate(CHANNELS):
            for ind,extra,weight in ((YZ,(),1.),(OZ,(1,),-1.),(OY,(2,),-1.)):
                family=int(bool(extra))
                for amp,order,indices,which in kernels()[channel,ind]:
                    key=family,tuple(sorted(indices+extra))
                    if key not in cache:
                        cache[key]=sum(factor*radials[family][jj] for jj,factor in self.prefactors(key[1]).items())
                    if (order,which) not in fields:fields[order,which]=field_product(tor,pol,order,PAIRS[which])
                    readings[col,family]+=weight*amp*(cache[key]@fields[order,which])
        return readings
    def exposure(self,duration,order):
        nodes,weights=leggauss(order);total=np.zeros((3,2))
        for node,weight in zip(nodes,weights,strict=True):
            guard();time=(1+node)*duration/2
            total+=weight/2*self.point(time,duration-time)
        return total
def run(spatial,temporal):
    check_parent()
    import json
    frozen=json.loads((HERE/"freeze.json").read_bytes())
    assert digest(HERE/"frozen-exposures.csv")==frozen["readings"]
    rows=[]
    for sign in (1,-1):
        probe=Aperture(spatial,sign)
        for time in (0.,*TIMES):
            fields=probe.exposure(time,temporal) if time else probe.point(0.,0.)
            for idx,channel in enumerate(CHANNELS):
                rows.append(dict(sign=sign,time=time,channel=channel,metric_spatial=fields[idx,0],metric_momentum=fields[idx,1],tidal_mean=sum(fields[idx])))
        print("completed",sign,spatial,temporal,flush=True)
    table("retarded-space%d-time%d.csv"%(spatial,temporal),rows)

if __name__=="__main__":run(int(sys.argv[1]),int(sys.argv[2]))
