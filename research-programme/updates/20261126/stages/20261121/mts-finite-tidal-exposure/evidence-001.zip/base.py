import csv
import hashlib
import io
import json
import os
import sys
from pathlib import Path
for name in ("OPENBLAS_NUM_THREADS","OMP_NUM_THREADS","MKL_NUM_THREADS","BLIS_NUM_THREADS","NUMEXPR_NUM_THREADS"):
    os.environ[name]="1"
import numpy as np

HERE=Path(__file__).resolve().parent
PREV=HERE.parent/"mts-unprojected-maxwell-metric-20261121"
PIN="89d06e86c622fcdcb8c62d73da552c1c652bd60a34e5ec18c1d6e8548497bb11"
sys.path.insert(0,str(PREV))
TIMES=(.02,.04,.08,.16,.32)
WIDTH=np.sqrt((np.sqrt(2.)-1)/2)
CENTRE=np.sqrt(2*np.sqrt(2.))
CHANNELS=("ordinary","W","D")
def digest(path):
    with path.open("rb") as stream:return hashlib.file_digest(stream,"sha256").hexdigest()
def guard():
    assert not any((root/"STOP-REQUESTED").exists() for root in (HERE,PREV,HERE.parent))
def check_parent():
    guard()
    assert digest(PREV/"seal.json")==PIN
    files=json.loads((PREV/"seal.json").read_bytes())["files"]
    assert len(files)==114 and all(digest(PREV/name)==value for name,value in files.items())
def put(name,data):
    guard()
    path=HERE/name
    if path.exists():assert path.read_bytes()==data,name
    else:
        with path.open("xb") as stream:stream.write(data)
def save(name,data):put(name,(json.dumps(data,indent=2,allow_nan=False)+"\n").encode())
def table(name,rows):
    stream=io.StringIO(newline="")
    writer=csv.DictWriter(stream,rows[0].keys(),lineterminator="\n");writer.writeheader();writer.writerows(rows)
    put(name,stream.getvalue().encode())
def read(name):
    with (HERE/name).open(newline="",encoding="utf-8") as stream:return list(csv.DictReader(stream))
