import json
from itertools import combinations_with_replacement
from base import HERE,WIDTH,CENTRE,TIMES,CHANNELS,np,read,table,save
from retarded import Aperture

def keyed(name,keys):
    rows=read(name);result={tuple(row[key] for key in keys):row for row in rows}
    assert len(result)==len(rows)
    return result
def run():
    keys=("sign","time","channel")
    panels=[keyed("retarded-space%d-time%d.csv"%level,keys) for level in ((16,6),(24,6),(24,10),(32,10))]
    forecasts=keyed("frozen-exposures.csv",("time","channel"))
    assert all(len(panel)==36 and set(panel)==set(panels[0]) for panel in panels)
    rows=[]
    for key in panels[0]:
        sign,time,channel=key
        values=np.array([float(panel[key]["tidal_mean"]) for panel in panels])
        changes=abs(np.diff(values));assert max(changes)<2e-8
        if float(time)==0 and channel=="ordinary":assert abs(values[-1])<1e-12
        mirror=panels[-1][str(-int(sign)),time,channel]
        assert abs(float(mirror["tidal_mean"])+values[-1])<2e-12
        result=dict(sign=sign,time=time,channel=channel,medium_space_change=changes[0],time_change=changes[1],fine_space_change=changes[2],reference=values[-1])
        if float(time)>0:
            for degree in (0,2,4,6,8):
                result["error_order"+str(degree)]=abs(values[-1]-int(sign)*float(forecasts[time,channel]["order"+str(degree)]))
            rows.append(result)
    table("fixed-window-errors.csv",rows)
    weights=json.loads((HERE/"frozen-weights.json").read_bytes())
    mix=[]
    for sign in (1,-1):
        for idx,channel in enumerate(CHANNELS):
            val=sum(weight*float(panels[-1][str(sign),str(time),channel]["tidal_mean"]) for time,weight in zip(weights["times"],weights["weights"],strict=True))
            expected=float(sign)*(idx==1)
            assert abs(val-expected)<2e-8
            mix.append(dict(sign=sign,channel=channel,prediction=expected,measured=val,residual=val-expected))
    table("three-window-test.csv",mix)
    gkeys=("order","time","delta","sign","channel")
    rough,fine=[keyed("geometry-space%d-time%d.csv"%level,gkeys) for level in ((24,8),(32,10))]
    assert set(rough)==set(fine) and len(fine)==60
    worst=max(abs(float(v["tidal_mean"])-float(rough[key]["tidal_mean"])) for key,v in fine.items())
    assert worst<2e-8
    timings=keyed("timing-forecasts.csv",("channel","delta"));geom=keyed("geometry-forecasts.csv",("order","time"))
    scores=[]
    for deg,time in geom:
        for sign in (1,-1):
            measured=[float(fine[deg,time,"0.0",str(sign),channel]["tidal_mean"]) for channel in CHANNELS]
            nuisance=max(abs(measured[0]),abs(measured[2]))
            predicted=float(geom[deg,time]["W"])*sign
            scores.append(dict(order=deg,time=time,sign=sign,ordinary=measured[0],W=measured[1],D=measured[2],W_forecast_error=abs(measured[1]-predicted),
                               nuisance=nuisance,inside=nuisance<2e-8 and abs(measured[1]-predicted)<2e-8))
    table("geometry-decisions.csv",scores)
    met={(row["order"],row["time"]) for row in scores if row["inside"]}
    assert met=={("8","0.12"),("12","0.12"),("12","0.24")}
    slopes=[]
    for sign in (1,-1):
        for channel in CHANNELS:
            ref=lambda delta:float(fine["12","0.24",str(delta),str(sign),channel]["tidal_mean"])
            estimates=[(ref(delta)-ref(-delta))/(2*delta) for delta in (.001,.0005)]
            rich=(4*estimates[1]-estimates[0])/3
            expected=float(timings[channel,"0.0"]["slope"])*sign
            assert abs(rich-expected)<2e-8
            slopes.append(dict(sign=sign,channel=channel,outer=estimates[0],inner=estimates[1],extrapolated=rich,predicted=expected))
    table("timing-sensitivity.csv",slopes)
    controls=[]
    wave=np.array([.7,-1.2,.9]);k=np.linalg.norm(wave)
    for sign in (1,-1):
        probe=Aperture(24,sign)
        phase=np.exp(1j*(probe.pos@wave));window=np.exp(1j*sign*CENTRE*wave[0]-.5*WIDTH**2*k**2)
        for elapsed in (.0,.08,.32):
            pair=probe.radial(elapsed)
            for family in (0,1):
                exact=window*(np.cos(k*elapsed) if family==0 else np.sin(k*elapsed)/k)
                for degree in range(4):
                    for axes in combinations_with_replacement(range(3),degree):
                        coeff=sum(factor*pair[family][jj] for jj,factor in probe.prefactors(axes).items())
                        error=abs(coeff@phase-exact*np.prod([1j*wave[axis] for axis in axes]))
                        assert error<2e-12
                        controls.append(dict(sign=sign,elapsed=elapsed,family=family,axes=str(axes),error=error))
    table("shell-plane-controls.csv",controls)
    save("assessment.json",dict(fine_space=max(row["fine_space_change"] for row in rows),time_change=max(row["time_change"] for row in rows),
         geometry_refinement=worst,conditional_geometry_passes=sorted([list(item) for item in met]),
         triple_discrepancy=max(abs(row["residual"]) for row in mix),kernel_error=max(row["error"] for row in controls),
         duration_leak_in_photon_units=abs(slopes[0]["extrapolated"])/float(geom["12","0.24"]["W"])))
if __name__=="__main__":run()
