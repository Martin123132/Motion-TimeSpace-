"""Implicit-series geometry derived without fitting or accessing the retarded output."""
from functools import lru_cache
from math import comb,factorial
from itertools import product
from base import HERE,CHANNELS,np,table,save,digest,check_parent
from forecast import sp,ring,space,source,metric_term,lap,pairings
basis,uu,hh=ring("u,h",sp.QQ)
WINDOWS=(.12,.24,.32)

@lru_cache(None)
def average(nx,ny,nz):
    if ny%2 or nz%2:return basis.zero
    assert nx%2
    variance=(1-uu)/2
    return pairings(ny)*pairings(nz)*variance**((ny+nz)//2)*sum((comb(nx,2*idx)*pairings(2*idx)*variance**idx*hh**((nx-2*idx-1)//2) for idx in range(nx//2+1)),basis.zero)

def polynomials():
    result={}
    for channel in CHANNELS:
        kernel=space.zero
        for order in range(7):
            degree=2*order
            tide=source(channel,degree,1,2)+kernel
            result[channel,order]=sum((weight*average(*key) for key,weight in tide.items()),basis.zero)/factorial(degree+1)
            if order<6:kernel=lap(kernel)+metric_term(channel,degree)
    return result

def series(poly,us,hs,degree):
    def powers(series,maxdeg):
        out=[np.array([1.])]
        for _ in range(maxdeg):out.append(np.convolve(out[-1],series)[:degree+1])
        return out
    if not poly:return 0.
    up=powers(us,max(key[0] for key in poly))
    hp=powers(hs,max(key[1] for key in poly))
    output=0.
    for (first,second),weight in poly.items():
        values=np.convolve(up[first],hp[second])
        if degree<len(values):output+=float(weight)*values[degree]
    return output

def run():
    check_parent()
    laws=polynomials();initial=1/np.sqrt(2);us=[initial];hs=[2*initial]
    get=lambda poly:series(poly,us,hs,0)
    jac=np.array([[get(laws[key,0].diff(var)) for var in (hh,uu)] for key in ("ordinary","D")])
    assert abs(np.linalg.det(jac)-64*initial)<1e-12
    for order in range(1,7):
        errors=[sum(series(laws[key,jj],us,hs,order-jj) for jj in range(order+1)) for key in ("ordinary","D")]
        dh,du=np.linalg.solve(jac,-np.array(errors));us.append(du);hs.append(dh)
        assert max(abs(sum(series(laws[key,jj],us,hs,order-jj) for jj in range(order+1))) for key in ("ordinary","D"))<1e-9
    table("geometry-series.csv",[dict(power=2*idx,u=val,h=hs[idx]) for idx,val in enumerate(us)])
    rows=[]
    for order,time in product((4,6),WINDOWS):
        uu_value=np.polynomial.polynomial.polyval(time*time,us[:order+1])
        hh_value=np.polynomial.polynomial.polyval(time*time,hs[:order+1])
        width=np.sqrt((1/uu_value-1)/2);centre=np.sqrt(hh_value)/uu_value
        scale=uu_value**1.5*np.sqrt(hh_value)*np.exp(-hh_value/uu_value)
        values={key:scale*sum(time**(2*jj)*series(laws[key,jj],[uu_value],[hh_value],0) for jj in range(order+1)) for key in CHANNELS}
        rows.append(dict(order=2*order,time=time,width=width,centre=centre,**values))
    table("geometry-forecasts.csv",rows)
    save("geometry-freeze.json",dict(original=digest(HERE/"freeze.json"),design=digest(HERE/"MOVING-NULL-DESIGN.md"),
           method=digest(HERE/"design_aperture.py"),series=digest(HERE/"geometry-series.csv"),measurements=digest(HERE/"geometry-forecasts.csv"),
           jacobian=jac.tolist(),determinant=float(np.linalg.det(jac))))
    print("geometry forecasts",rows)
if __name__=="__main__":run()
