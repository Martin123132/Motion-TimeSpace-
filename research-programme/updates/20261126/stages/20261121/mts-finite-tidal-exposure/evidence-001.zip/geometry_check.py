import json
import sys
from base import HERE,CHANNELS,read,table,digest,check_parent
from retarded import Aperture
def run(space,time_order):
    check_parent()
    pins=json.loads((HERE/"geometry-freeze.json").read_bytes())
    assert digest(HERE/"geometry-forecasts.csv")==pins["measurements"]
    timing=json.loads((HERE/"timing-freeze.json").read_bytes())
    assert digest(HERE/"timing-forecasts.csv")==timing["predictions"]
    rows=[]
    for case in read("geometry-forecasts.csv"):
        time=float(case["time"]);degree=int(case["order"])
        dels=(-.001,-.0005,0.,.0005,.001) if degree==12 and time==.24 else (0.,)
        for sign in (1,-1):
            probe=Aperture(space,sign,float(case["width"]),float(case["centre"]))
            for delta in dels:
                values=probe.exposure(time+delta,time_order)
                for idx,channel in enumerate(CHANNELS):
                    rows.append(dict(order=degree,time=time,delta=delta,sign=sign,channel=channel,metric_spatial=values[idx,0],
                                     metric_momentum=values[idx,1],tidal_mean=sum(values[idx])))
        print("finished",degree,time,space,time_order,flush=True)
    table("geometry-space%d-time%d.csv"%(space,time_order),rows)
if __name__=="__main__":run(int(sys.argv[1]),int(sys.argv[2]))
