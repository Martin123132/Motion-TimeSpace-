"""Exact polynomial times Gaussian launch jets; full scalar/vector/tensor curvature readout."""
from functools import lru_cache
from fractions import Fraction
from itertools import product
from math import comb,factorial
from base import HERE,PREV,WIDTH,CENTRE,PIN,TIMES,CHANNELS,np,check_parent,table,save,digest
from wilson import project
import sympy as sp
from sympy.polys.rings import ring
space,xx,yy,zz=ring("x,y,z",sp.QQ)
coords=(xx,yy,zz)
uni,u=ring("u",sp.QQ)
def partial(poly,index,factor=2):return poly.diff(coords[index])-factor*coords[index]*poly
def lap(poly,factor=2):return sum((partial(partial(poly,idx,factor),idx,factor) for idx in range(3)),space.zero)
def curl(fields):return tuple(partial(fields[(idx+2)%3],(idx+1)%3,1)-partial(fields[(idx+1)%3],(idx+2)%3,1) for idx in range(3))
@lru_cache(None)
def initial(which,degree):
    if degree==0:
        e=(-yy,xx,space.zero) if which=="tor" else (xx*zz,yy*zz,2-xx**2-yy**2)
        return e+(space.zero,)*3
    if degree==1:return (space.zero,)*3+tuple(-val for val in curl(initial(which,0)[:3]))
    return tuple(lap(val,1) for val in initial(which,degree-2))
@lru_cache(None)
def moment(degree,left,right):
    return 2*sum((comb(degree,idx)*(initial("tor",idx)[left]*initial("pol",degree-idx)[right]+
                   initial("tor",idx)[right]*initial("pol",degree-idx)[left]) for idx in range(degree+1)),space.zero)
@lru_cache(None)
def terms(first,second):
    result={}
    for left in range(6):
        for right in range(left,6):
            test=np.zeros((6,6));test[left,right]=test[right,left]=1.
            vertices=4*project(test)[first+1,:,:,second+1]
            for ii,jj in product(range(4),repeat=2):
                idx=(int(ii==0)+int(jj==0),tuple(sorted(val-1 for val in (ii,jj) if val)),left,right)
                result[idx]=result.get(idx,0)+Fraction(float(vertices[ii,jj])).limit_denominator(48)
    return [(key,sp.QQ(value.numerator,value.denominator)) for key,value in result.items() if value]
@lru_cache(None)
def source(channel,degree,first,second):
    if channel=="ordinary":return -moment(degree,first,second)-moment(degree,first+3,second+3)
    if channel=="D":return source("ordinary",degree+2,first,second)-lap(source("ordinary",degree,first,second))
    result=space.zero
    for (extra,indices,left,right),weight in terms(first,second):
        value=moment(degree+extra,left,right)
        for idx in indices:value=partial(value,idx)
        result+=value*weight
    return result
def metric_term(channel,degree):
    result=lap(source(channel,degree,1,2))
    for idx in range(3):
        result-=partial(partial(source(channel,degree,idx,2),idx),1)
        result-=partial(partial(source(channel,degree,idx,1),idx),2)
    return result
def pairings(number):
    return factorial(number)//(2**(number//2)*factorial(number//2))
@lru_cache(None)
def gaussian_term(nx,ny,nz):
    if ny%2 or nz%2:return uni.zero
    assert nx%2
    var=(1-u)/2
    return pairings(ny)*pairings(nz)*var**((ny+nz)//2)*sum((comb(nx,2*ii)*pairings(2*ii)*var**ii*(2*u)**((nx-2*ii-1)//2) for ii in range(nx//2+1)),uni.zero)
def run():
    check_parent()
    rows=[];numbers={}
    for channel in CHANNELS:
        kernel=space.zero;coef=[]
        for degree in range(0,9,2):
            tide=source(channel,degree,1,2)+kernel
            polynomial=sum((weight*gaussian_term(*powers) for powers,weight in tide.items()),uni.zero)/factorial(degree+1)
            critical=sp.factor(polynomial.as_expr().subs("u",1/sp.sqrt(2))*sp.exp(-2)/sp.sqrt(2))
            value=float(critical)
            rows.append(dict(channel=channel,power=degree,polynomial=str(polynomial),critical=str(critical),coefficient=value))
            coef.append(value)
            if degree<8:kernel=lap(kernel)+metric_term(channel,degree)
        numbers[channel]=coef
    assert abs(numbers["W"][0]-4*np.sqrt(2)*np.exp(-2))<1e-14
    assert numbers["ordinary"][0]==numbers["D"][0]==0
    table("exposure-coefficients.csv",rows)
    readings=[]
    for time,channel in product(TIMES,CHANNELS):
        partials=np.cumsum(np.array(numbers[channel])*time**np.arange(0,9,2))
        readings.append(dict(time=time,channel=channel,**{"order"+str(2*idx):val for idx,val in enumerate(partials)}))
    table("frozen-exposures.csv",readings)
    matrix=np.array([[sum(numbers[channel][ii]*time**(2*ii) for ii in range(5)) for channel in CHANNELS] for time in (.04,.08,.16)])
    weights=np.linalg.solve(matrix.T,np.array([0.,1.,0.]))
    save("frozen-weights.json",dict(times=[.04,.08,.16],weights=weights.tolist(),condition=np.linalg.cond(matrix).item(),
                                   max_reading_error_gain=np.linalg.norm(weights,1).item()))
    save("freeze.json",dict(parent=PIN,design=digest(HERE/"DESIGN.md"),forecast=digest(HERE/"forecast.py"),
         coefficients=digest(HERE/"exposure-coefficients.csv"),readings=digest(HERE/"frozen-exposures.csv"),weights=digest(HERE/"frozen-weights.json")))
    print("coefficients",numbers,"weights",weights,"condition",np.linalg.cond(matrix),flush=True)
if __name__=="__main__":run()
