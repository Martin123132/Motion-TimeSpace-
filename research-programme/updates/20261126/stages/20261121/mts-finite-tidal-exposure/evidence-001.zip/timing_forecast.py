from base import HERE,CHANNELS,np,read,table,save,digest
from design_aperture import polynomials,series

def run():
    rows=read("geometry-forecasts.csv")
    row=next(row for row in rows if row["order"]=="12" and row["time"]=="0.24")
    time=float(row["time"]);width=float(row["width"]);centre=float(row["centre"])
    shape=1/(1+2*width**2);shift=(shape*centre)**2
    common=shape**1.5*np.sqrt(shift)*np.exp(-shift/shape)
    laws=polynomials()
    results=[]
    for key in CHANNELS:
        values=[common*series(laws[key,idx],[shape],[shift],0) for idx in range(7)]
        for delta in (-.001,-.0005,0.,.0005,.001):
            total=sum(val*(time+delta)**(2*idx) for idx,val in enumerate(values))
            slope=sum(2*idx*val*time**(2*idx-1) for idx,val in enumerate(values) if idx)
            results.append(dict(channel=key,delta=delta,actual_time=time+delta,width=width,centre=centre,forecast=total,slope=slope))
    table("timing-forecasts.csv",results)
    save("timing-freeze.json",dict(design=digest(HERE/"TIMING-DESIGN.md"),geometry=digest(HERE/"geometry-freeze.json"),
         method=digest(HERE/"timing_forecast.py"),predictions=digest(HERE/"timing-forecasts.csv")))
if __name__=="__main__":run()
