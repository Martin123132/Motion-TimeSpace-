"""Independent conserved tensors and regulated two-direction helicity sewing."""
import numpy as np
from scipy.integrate import quad
from scipy.special import eval_jacobi
from phase import form,hdif,rule

def tensor_check():
    metric=np.diag([1.,-1.,-1.,-1.])
    prod=lambda first,second:first@metric@second
    for invariant,mass in ((1.2,1.),(7.,1.),(1.8,0.)):
        energy=np.sqrt(invariant)
        mom=(invariant-mass**2)/(2*energy)
        for radius in (.06,.31,.7,.98):
            angle=1-2*radius
            sine=2*np.sqrt(radius*(1-radius))
            incoming=mom*np.array([1.,0.,0.,1.])
            outgoing=-mom*np.array([1.,sine,0.,angle])
            left=-np.array([energy-mom,0.,0.,-mom])
            right=np.array([energy-mom,-mom*sine,0.,-mom*angle])
            exchange=incoming+outgoing
            transfer=prod(exchange,exchange)
            matter=-np.outer(left,right)-np.outer(right,left)+metric*transfer/2
            assert np.max(np.abs(exchange@metric@matter))<5e-15
            for helicity in (-1,1):
                for gauge in (0.,.271):
                    pol=np.array([0.,1.,1j,0.])/np.sqrt(2)+gauge*incoming
                    other=np.array([0.,angle,-helicity*1j,-sine])/np.sqrt(2)-.61*gauge*outgoing
                    def strength(moment,polar):
                        return np.outer(moment,polar)-np.outer(polar,moment)
                    first,second=strength(incoming,pol),strength(outgoing,other)
                    one=-first@metric@second.T
                    photon=one+one.T+metric*np.sum((metric@first@metric)*second)/2
                    assert np.max(np.abs(exchange@metric@photon))<5e-15
                    assert abs(np.sum(metric*photon))<7e-15
                    value=np.sum((metric@matter@metric)*photon)/transfer
                    expected=invariant*(1-radius)/radius if helicity==1 else 0.
                    assert abs(value-expected)<3e-13*max(1,abs(expected))

def wave_checks():
    for spin in range(1,16):
        moment=quad(lambda rad: ((1-rad)**2*eval_jacobi(spin-1,0,2,1-2*rad)-1)/rad,
                    0,1,epsabs=4e-13)[0]
        assert abs(moment-hdif(spin))<2e-13

def direct_sphere(radius,gap,span_electron,zeta,epsilon,smooth,order):
    cval,sval=np.sqrt(1-radius),np.sqrt(radius)
    azimuth=2*np.pi*(np.arange(2*order)+.5)/(2*order)
    direction=np.exp(1j*azimuth)
    coord,weights=rule(order)
    edge=(1-cval*np.cos(azimuth)/np.sqrt(radius+(cval*np.cos(azimuth))**2))/2
    assert min(edge)>5*epsilon
    def samples():
        if smooth:
            span=np.log1p(edge/epsilon)
            near=epsilon*np.expm1(coord[:,None]*span)
            yield near,weights[:,None]*span*(near+epsilon)
        else:
            yield coord[:,None]*np.ones_like(edge)*epsilon,weights[:,None]*epsilon
            span=np.log(edge/epsilon)
            near=epsilon*np.exp(coord[:,None]*span)
            yield near,weights[:,None]*span*near
    def pole(argument):
        if smooth:
            return 1/(argument+epsilon)+zeta
        return np.where(argument>epsilon,1/argument,0.)+zeta
    result=np.zeros(3,complex)
    for near,measure in samples():
        for side in ("initial","final"):
            base=np.sqrt(1-near)
            tang=np.sqrt(near)*direction
            if side=="initial":
                first,second=base,tang
                overlap=cval*first+sval*second
                opposite=-sval*first+cval*second
                inc,out=near,abs(opposite)**2
            else:
                overlap,opposite=base,-tang
                first,second=cval*overlap-sval*opposite,sval*overlap+cval*opposite
                inc,out=abs(second)**2,near
            keep1,keep2=pole(inc),pole(out)
            flip1=-.5*(gap-inc)*form(inc,span_electron)
            flip2=-.5*(gap-out)*form(out,span_electron)
            same=overlap**2*first.conj()**2*keep1*keep2
            flip=opposite**2*first.conj()**2*keep1*flip2+overlap.conj()**2*second**2*flip1*keep2
            result+=np.array([np.sum(measure*same),np.sum(measure*flip),
                              np.sum(measure*np.ones_like(near))])/len(azimuth)
    assert max(abs(result.imag))<2e-11 and abs(result[2]-1)<3e-11
    return result.real[:2]

