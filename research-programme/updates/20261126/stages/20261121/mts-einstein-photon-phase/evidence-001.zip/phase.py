"""Elastic photon-scalar phase on the retained conserved-source conventions."""
from math import factorial
from pathlib import Path
import json
import sys
import numpy as np
from scipy.special import eval_jacobi

ROOT=Path(__file__).resolve().parent.parent
MATCH=ROOT/"mts-even-charge-and-trace-cut-20261121"
sys.path.insert(0,str(MATCH))
from matching import rule,trace_ratio

SCALES=json.loads((MATCH/"scales.json").read_bytes())
MOMENTS=[]
for power in range(25):
    def simplex(degree):
        return factorial(degree)**2/factorial(2*degree+2)
    MOMENTS.append(360/7*(simplex(power+1)-4*simplex(power+2)))

def form(radii,span_electron):
    if not 0 <= span_electron <= 1:
        raise ValueError("spacelike triangle series only qualified to D/m_e^2=1")
    return np.polynomial.polynomial.polyval(-span_electron*radii,MOMENTS)

def hdif(spin):
    harmonic=lambda degree:sum(1/index for index in range(1,degree+1))
    return -harmonic(spin-1)-harmonic(spin+1)

def diagonal_finite(radius):
    left=1-radius
    if left<.008:
        return -1.5-sum(left**idx*(1/idx+1/(idx+2)) for idx in range(1,12))
    return radius/left+(1+left**-2)*np.log(radius)

def coefficients(gap,span_electron,highest=12):
    if span_electron==0:
        return np.array([-(gap-.75)/2,-1/8])
    nodes,weights=rule(64)
    amplitude=-.5*nodes*(gap-nodes)*trace_ratio(-span_electron*nodes)
    return np.array([(2*spin+1)*(weights*nodes*eval_jacobi(spin-1,2,0,1-2*nodes))@amplitude
                     for spin in range(1,highest+1)])

def amplitudes(radius,gap,span_electron,zeta=0.,highest=12):
    coeff=coefficients(gap,span_electron,highest)
    waves=radius*eval_jacobi(np.arange(len(coeff)),2,0,1-2*radius)
    finite=np.array([hdif(spin) for spin in range(1,len(coeff)+1)])
    flip=-.5*radius*(gap-radius)*form(radius,span_electron)
    keep0=(1-radius)/radius
    keep=keep0+zeta*(1-radius)
    finite_keep=keep0*diagonal_finite(radius)+(1-radius)*(2*zeta*hdif(1)+zeta**2/3)
    finite_flip=2*(coeff*waves)@finite+2*zeta*coeff[0]*radius/3
    phase=(finite_flip-flip*(finite_keep/keep))/keep
    return keep,flip,finite_keep,finite_flip,phase

def bin_moments(low,high):
    def primitives(radius):
        return np.array([radius-2*np.log(radius)-1/radius,
                         np.log(radius)-2*radius+radius**2/2,
                         radius-radius**2+radius**3/3])
    return primitives(high)-primitives(low)

def bin_results(zeta):
    near=bin_moments(.25,.5)
    far=bin_moments(.5,.75)
    near/=near[0]
    far/=far[0]
    powers=np.array([1.,2*zeta,zeta**2])
    return (far@powers)/(near@powers),2*(far[1]-near[1])

def scales(span):
    zeta_unit=SCALES["cap_abs_lambda_eVneg4_per_abs_Zpsi_over_K0"]*SCALES["reduced_planck_mass_eV"]**2*span/2
    stokes_unit=SCALES["abs_trace_unit_eVneg4"]*span**2/(8*np.pi)
    return zeta_unit,stokes_unit

