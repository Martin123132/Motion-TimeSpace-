"""Single-thread offline replay. Normal use checks fixtures without writing."""
import os
for setting in ("OMP_NUM_THREADS","OPENBLAS_NUM_THREADS","MKL_NUM_THREADS"):
    os.environ[setting]="1"

import csv
import hashlib
import io
import json
from pathlib import Path
import re
import sys
import numpy as np
from scipy import constants
from scipy.integrate import quad
from scipy.optimize import brentq
from controls import direct_sphere,tensor_check,wave_checks
from optics import source_checks
from phase import MATCH,SCALES,amplitudes,bin_moments,bin_results,form,scales,trace_ratio

HERE=Path(__file__).resolve().parent

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def serialize(rows):
    buff=io.StringIO(newline="")
    writer=csv.DictWriter(buff,rows[0].keys(),lineterminator="\n")
    writer.writeheader()
    writer.writerows(rows)
    return buff.getvalue().encode()

def calculate():
    assert digest(MATCH/"seal.json")=="05f5453dfbc259237c76310bfb6cd412482035269952903a2780dab91c81e386"
    for name,expected in json.loads((MATCH/"seal.json").read_bytes()).items():
        assert digest(MATCH/name)==expected,name
    tensor_check()
    wave_checks()
    assert max(abs(form(np.array([.1,.42,.87,1.]),1.)-trace_ratio(-np.array([.1,.42,.87,1.]))))<4e-14
    rows=[]
    for radius,gap,span,zeta in ((.25,0.,0.,0.),(.5,.5,0.,0.),(.67,1.2,.3,0.),(.42,.15,.5,.07)):
        keep,flip,diag,mix,answer=amplitudes(radius,gap,span,zeta)
        assert abs(answer-amplitudes(radius,gap,span,zeta,16)[-1])<4e-13
        for reg in ("cut_cone","screened"):
            errors=[]
            for epsilon in (1e-4,1e-7,1e-10):
                same,both=direct_sphere(radius,gap,span,zeta,epsilon,reg=="screened",72)
                log=-np.log(epsilon)
                finite_diag=same-2*log*keep
                finite_mix=both-2*log*flip
                stokes=(both-flip*same/keep)/keep
                changed=((both+2*.813*flip)-flip*(same+2*.813*keep)/keep)/keep
                assert abs(stokes-changed)<2e-13
                err=max(abs(diag-finite_diag),abs(mix-finite_mix),abs(answer-stokes))
                errors.append(err)
                rows.append(dict(r=radius,two_m2_over_D=gap,D_over_electron2=span,zeta=zeta,regulator=reg,
                    epsilon=epsilon,raw_diagonal=same,raw_mixed=both,finite_diagonal=finite_diag,
                    finite_mixed=finite_mix,phase_quadrature=stokes,analytic_phase=answer,max_abs_error=err))
            assert errors[2]<3e-7 and errors[2]<errors[1]<errors[0]
    energy2=1e-6
    zcap,unit=scales(energy2)
    cross=[]
    for label,mass in (("massless_control",0.),("retained_light",1.095668516985692e-33),("retained_fast",9.585761787277403e-25)):
        span=(energy2-mass**2)**2/energy2
        gap=2*mass**2/span
        scale=span/SCALES["electron_mass_eV"]**2
        rho=1-mass**2/energy2
        for radius in (.25,.5,.75):
            gr=amplitudes(radius,gap,0.)[-1]
            assert abs(gr-amplitudes(radius,gap,scale)[-1])<6e-13
            step=1e-5
            slope=(amplitudes(radius,gap,0.,step)[-1]-amplitudes(radius,gap,0.,-step)[-1])/(2*step)
            cross.append(dict(pole=label,energy_eV=.001,r=radius,GR_shape=gr,
                GR_phase_times_sign_ae=rho*unit*gr,linear_excess_at_positive_cap_per_Zpsi_K0_times_sign_ae=rho*unit*slope*zcap,
                matched_same_contact_excess=0.))
    for radius in (.25,.5,.75):
        expected=radius**2*(3-4*radius)/(3*(1-radius))
        assert abs(amplitudes(radius,radius,0.)[-1]-expected)<3e-15
    low=bin_moments(.25,.5)
    high=bin_moments(.5,.75)
    for bounds,moments in (((.25,.5),low),((.5,.75),high)):
        for power,value in enumerate(moments):
            assert abs(quad(lambda x:(1-x)**2*x**(power-2),*bounds)[0]-value)<4e-15
    natural_to_m2=(constants.hbar*constants.c/constants.electron_volt)**2
    xs=energy2/(16*np.pi*SCALES["reduced_planck_mass_eV"]**4)*natural_to_m2
    sky,synthetic=source_checks()
    info=dict(sqrt_v_eV=.001,massless_GR_phase_node_r=brentq(lambda r:amplitudes(r,0,0)[-1],.5,.75),
              massless_GR_phase_unit=unit,dimensionless_contact_cap_per_abs_Zpsi_K0=zcap,
              bin_log_ratio_slope_per_zeta=bin_results(0.)[1],ratio_at_minus_cap_if_kinetic_ratio_one=bin_results(-zcap)[0],
              ratio_at_plus_cap_if_kinetic_ratio_one=bin_results(zcap)[0],GR_inner_bin_cross_section_m2=xs*low[0],
              GR_outer_bin_cross_section_m2=xs*high[0],analytic_column_control_max_relative_error=synthetic)
    return {"regulators.csv":serialize(rows),"phase.csv":serialize(cross),"lmc-columns.csv":serialize(sky),
            "summary.json":(json.dumps(info,indent=2)+"\n").encode()}

if __name__=="__main__":
    mode=sys.argv[1:]
    assert mode in ([],["--initialize"])
    fixtures=calculate()
    for name,data in fixtures.items():
        path=HERE/name
        if mode and not path.exists():
            path.write_bytes(data)
        assert path.read_bytes()==data,name
    docs=["RESULTS.md","SCATTERING.md","SKY.md"]
    for name in docs:
        for link in re.findall(r"\]\(([^)]+)\)",(HERE/name).read_text(encoding="utf8")):
            assert link.startswith("https://") or (HERE/link).is_file(),link
    names=sorted([*fixtures,*docs,"phase.py","controls.py","optics.py","verify.py"])
    receipt=(json.dumps({name:digest(HERE/name) for name in names},indent=2)+"\n").encode()
    seal=HERE/"seal.json"
    if mode and not seal.exists():
        seal.write_bytes(receipt)
    assert seal.read_bytes()==receipt
    print(f"Verified {len(names)} files, 24 regulated convolutions, 12 paired columns; seal {digest(seal)}")

