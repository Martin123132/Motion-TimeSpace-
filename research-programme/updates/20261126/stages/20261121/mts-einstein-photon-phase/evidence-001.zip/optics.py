"""Project only the saved, LMC-induced even axisymmetric rest-mass perturbation."""
import csv
import hashlib
import json
import numpy as np
from scipy import constants
from scipy.special import eval_legendre
from phase import ROOT,SCALES,rule

AXIS=ROOT/"mts-lmc-fixed-occupation-axisymmetric-20261119"
HISTORIES=("L2M10","L2M10first","L2M11","L3M10","L3M10rad","L3M11")
KPC=1000*constants.parsec
SOLAR_GM=1.3271244e20

class Projection:
    def __init__(self,grid,orders,source):
        self.grid=grid
        self.orders=orders
        self.source=source
        self.lagrange=[]
        for first in range(0,len(grid)-1,7):
            knots=grid[first:first+8]
            matrix=knots[:,None]-knots
            np.fill_diagonal(matrix,1.)
            self.lagrange.append(1/matrix.prod(axis=1))

    def integral(self,impact,order,column=False,sphere=False):
        coord,weight=rule(order)
        result=0.
        scale=np.sqrt(2*self.orders+1)
        for elem,first in enumerate(range(0,len(self.grid)-1,7)):
            knots=self.grid[first:first+8]
            splits=np.unique(np.clip([knots[0],impact,knots[-1]],knots[0],knots[-1]))
            for low,high in zip(splits,splits[1:]):
                inside=high<=impact
                if (inside and column) or (not inside and sphere):
                    continue
                if column:
                    left=np.sqrt(max(0.,low**2-impact**2))
                    right=np.sqrt(high**2-impact**2)
                    height=left+(right-left)*coord
                    radii=np.hypot(impact,height)
                    polar=height/radii
                    kernel=2*(right-left)*weight[:,None]/radii[:,None]**2
                    kernel=kernel*scale*eval_legendre(self.orders,polar[:,None])
                elif inside:
                    radii=low+(high-low)*coord
                    kernel=np.zeros((order,len(scale)))
                    kernel[:,0]=(high-low)*weight
                else:
                    radii=low+(high-low)*coord**2
                    polar=np.sqrt((1-impact/radii)*(1+impact/radii))
                    harmonics=eval_legendre(self.orders[1:]-1,polar[:,None])-eval_legendre(self.orders[1:]+1,polar[:,None])
                    kernel=2*(high-low)*(weight*coord)[:,None]*np.column_stack((1-polar,harmonics/scale[1:]))
                diff=radii[:,None]-knots
                with np.errstate(divide="ignore",invalid="ignore"):
                    basis=self.lagrange[elem]/diff
                    basis/=basis.sum(axis=1)[:,None]
                at_node=np.any(diff==0,axis=1)
                basis[at_node]=(diff[at_node]==0).astype(float)
                result+=np.einsum("kl,klh->h",basis.T@kernel,self.source[first:first+8])
        return result

def source_checks():
    seal=AXIS/"seal.json"
    assert hashlib.sha256(seal.read_bytes()).hexdigest()=="a46d251285faaba640cea0288634284d6d3046a9693e934921a28936060c6f70"
    values=json.loads(seal.read_bytes())["files"]
    def saved(name):
        path=AXIS/name
        assert hashlib.sha256(path.read_bytes()).hexdigest()==values[name],name
        return path
    synthetic=synthetic_check()
    rows=[]
    for case in (0,1):
        with np.load(saved(f"operators/{case}-k-100.npz")) as bank:
            radial,orders,length,velocity=(bank[key] for key in ("r","orders","length","velocity"))
        grid=np.r_[0.,radial,30.]
        data=[]
        for history in HISTORIES:
            with np.load(saved(f"states/{case}-{history}-k-100-r320-l40-q36-t16-v16.npz")) as state:
                np.testing.assert_array_equal(radial*length,state["r"])
                data.append(np.pad(radial[:,None]**2*state["delta_rho_multipoles"],((1,1),(0,0))))
        transform=Projection(grid,orders,np.stack(data,axis=-1))
        unit_mass=(velocity*1e3)**2*length*KPC/constants.G
        unit_col=unit_mass/(4*np.pi*(length*KPC)**2)
        cols=[]; derivatives=[]
        for impact in (6/length,8.3/length):
            direct=transform.integral(impact,18,column=True)
            fine=transform.integral(impact,32,column=True)
            step=1e-4*impact
            independent=sum(factor*transform.integral(impact+offset*step,22)
                            for offset,factor in ((-2,1),(-1,-8),(1,8),(2,-1)))/(6*step*impact)
            assert max(abs(direct/fine-1))<2e-7 and max(abs(independent/fine-1))<2e-6
            cols.append(fine*unit_col)
            derivatives.append(abs(independent/fine-1))
        with saved(f"mass-flow-{case}-k-100-r320-l40-q36-t16.csv").open(newline="") as stream:
            mass_rows=list(csv.DictReader(stream))
        ref=np.array([float(next(row["enclosed_delta_msun"] for row in mass_rows
                        if row["model"]==history and float(row["R"])==6.)) for history in HISTORIES])
        mass=transform.integral(np.hypot(6,1.5)/length,24,sphere=True)*unit_mass
        assert max(abs(mass*constants.G/SOLAR_GM/ref-1))<2e-4
        low,high=6/length,8.3/length
        def delay(order):
            nodes,weights=rule(order)
            breaks=np.r_[low,grid[::7][(grid[::7]>low)&(grid[::7]<high)],high]
            tally=0.
            for left,right in zip(breaks,breaks[1:]):
                for point,weight in zip(left+(right-left)*nodes,(right-left)*weights):
                    tally+=weight/point*transform.integral(point,20)
            return tally*4*constants.G*unit_mass/constants.c**3
        gr=delay(8)
        refined=delay(12)
        assert max(abs(gr/refined-1))<2e-7
        hc=constants.hbar*constants.c/constants.electron_volt
        col_to_sec=SCALES["cap_abs_lambda_eVneg4_per_abs_Zpsi_over_K0"]*(constants.c**2/constants.electron_volt)*hc**2*constants.hbar/constants.electron_volt/2
        contact=(cols[0]-cols[1])*col_to_sec
        for idx,history in enumerate(HISTORIES):
            rows.append(dict(preparation=case,history=history,inner_column_kg_m2=cols[0][idx],
                outer_column_kg_m2=cols[1][idx],column_derivative_relative_error=max(x[idx] for x in derivatives),
                delta_GR_seconds_inner_minus_outer=refined[idx],
                delta_contact_seconds_at_positive_cap_per_Zpsi_K0=contact[idx],
                abs_contact_over_GR_at_cap_per_abs_Zpsi_K0=abs(contact[idx]/refined[idx]),
                matched_contact_GR_EFT_difference_seconds=0.))
    return rows,synthetic

def synthetic_check():
    grid=np.linspace(0.,2.,29)
    source=np.zeros((len(grid),2,1))
    source[:,0,0]=grid**2*(1-grid**2/4)**2
    projection=Projection(grid,np.array([0,2]),source)
    errors=[]
    for impact in (.31,1.12,1.76):
        column=projection.integral(impact,24,column=True)[0]
        mass=projection.integral(impact,24)[0]
        length=np.sqrt(4-impact**2)
        errors.extend((abs(column/(length**5/15)-1),abs(mass/((128-length**7)/210)-1)))
    assert max(errors)<2e-12
    return max(errors)

