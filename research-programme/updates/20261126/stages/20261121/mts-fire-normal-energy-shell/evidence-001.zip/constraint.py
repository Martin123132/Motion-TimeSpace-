from normal_shell_io import *

def calculate(save):
    budgets=[];energies=[];checks=[];ambiguities=[];halfrows=[]
    for steps in STEPS:
        for order in (16,28):
            mesh=Wavenet(steps,order);run=mesh.run;bg=run.obj.bg;obj=run.obj
            radius=mesh.x;degs=mesh.ell;ep=mesh.ep;unit=mesh.acc*1e-10;pn=unit*ep
            density={tag:mesh.density(vec) for tag,vec in mesh.states.items()}
            momentrates={tag:obj.phi(run.sky_cross(obj.sky(vec),mesh.rate[tag])) for tag,vec in mesh.states.items()}
            for tag,vec in mesh.states.items():
                step=1.;rate=mesh.rate[tag]
                dif=(obj.phi(obj.moment(vec+step*rate))-obj.phi(obj.moment(vec-step*rate)))/(2*step)
                assert abs(dif-momentrates[tag]).max()<2e-9,(tag,abs(dif-momentrates[tag]).max())
            green={tag:mesh.newton(vec) for tag,vec in mesh.states.items()}
            def dot(left,right):return np.sum(left*right,axis=1)
            def sumfield(left,right,sign=1.):return tuple(x+sign*y for x,y in zip(left,right,strict=True))
            def metric(left,right,angular=1.):
                return dot(left[1],right[1])+angular*dot(left[0]*(degs*(degs+1)),right[0])/radius**2
            def integral(value):return mesh.integ(radius**2*value)
            def jumps(value):return np.diff(value[:3])
            def gradproduct(left,right):return dot(left[0],right[1])
            base_rho,base_kin,base_stress=density['reset']
            for method in ('native','green','green_V_interpolant'):
                weighted=method!='green_V_interpolant'
                ordinary=mesh.potential(mesh.ordinary,weighted)
                pots={tag:mesh.potential(pot) for tag,pot in mesh.pots.items()} if method=='native' else green
                base=pots['reset'];ref=sumfield(base,ordinary)
                for tag,vec in mesh.states.items():
                    check();pot=pots[tag];full=sumfield(pot,ordinary)
                    den,kin,stress=density[tag]
                    mass=integral(den[:,0]);kinetic=integral(kin/2)
                    volume=3*integral(dot(full[0],den))
                    energies.append(dict(steps=steps,order=order,method=method,arm=tag,
                        newton_mass_Msun=sum(mass)*mesh.mscale,proper_volume_canonical_energy_excess_Msun=ep*sum(kinetic)*mesh.mscale,
                        normal_density_excess_integrated_in_coordinate_volume_Msun=ep*sum(kinetic+volume)*mesh.mscale,
                        proper_volume_measure_correction_Msun=-ep*sum(volume)*mesh.mscale,
                        projected_lapse_cancellation=mesh.lift_error[tag]))
                    if tag=='reset':continue
                    diff=sumfield(pot,base,-1);total=sumfield(full,ref)
                    g2=metric(diff,total)
                    cross_o=metric(diff,ordinary)
                    cov=gradproduct(diff,ordinary)+gradproduct(ordinary,diff)+gradproduct(diff,pot)+gradproduct(base,diff)
                    icov=jumps(radius**2*cov)
                    baryon=jumps(radius**2*gradproduct(diff,ordinary))-integral(cross_o)
                    khalf=integral((kin-base_kin)/2)
                    geo=integral(g2)
                    vrho=integral(dot(full[0],den-base_rho)+dot(diff[0],base_rho))
                    direct=khalf+vrho+baryon+.5*geo
                    weak=khalf-.5*geo+icov
                    hkin=mesh.ham_weights@khalf;hgeo=-.5*mesh.ham_weights@geo
                    surface=-mesh.weights@cov[:3]
                    htotal=hkin+hgeo+surface
                    assert abs(htotal-mesh.ham_weights@weak)<1e-12
                    slipint=mesh.integ((stress-base_stress+metric(diff,total,-.5))/radius)
                    slip=mesh.slip_weights@slipint;time=htotal-slip
                    newton=-mesh.weights@diff[1][:3,0]
                    newton_direct=mesh.ham_weights@integral(den[:,0]-base_rho[:,0])
                    e_h=ep*unit*htotal;e_q=pn*time;wfield=pn*(htotal-.5*slip)
                    baryon_shift=-3*mesh.ham_weights@baryon
                    vdot_o=mesh.potential(mesh.extdot)[0]
                    vdot_a=mesh.potential(momentrates[tag])[0];vdot_b=mesh.potential(momentrates['reset'])[0]
                    extrinsic=lambda vo:-1.5*unit*ep**2*(mesh.ham_weights@integral(dot(vdot_a-vdot_b,vdot_a+vdot_b+2*vo)))
                    budgets.append(dict(steps=steps,order=order,method=method,arm=tag,observed_midpoint_kpc=mesh.mid*bg.length,
                        weight_inner=mesh.weights[0],weight_outer=mesh.weights[2],newton_difference=unit*newton,
                        spatial_kinetic=pn*hkin,spatial_geometric_volume=pn*hgeo,spatial_product_surface=pn*surface,
                        spatial_PN=e_h,slip_PN=pn*slip,time_PN=e_q,weyl_PN=wfield,proper_baryon_alternative_shift=pn*baryon_shift,
                        spatial_if_fixed_proper_ordinary=e_h+pn*baryon_shift,time_if_fixed_proper_ordinary=e_q+pn*baryon_shift,
                        slice_rate_term_left=extrinsic(vdot_o),slice_rate_term_static_ordinary=extrinsic(0.),
                        direct_spatial_PN=pn*(mesh.ham_weights@direct),spatial_route_defect=pn*(mesh.ham_weights@(direct-weak)),
                        direct_newton_difference=unit*newton_direct))
                    for index in range(2):
                        halfrows.append(dict(steps=steps,order=order,method=method,arm=tag,half=index+1,
                            heavy_kinetic=khalf[index],V_times_heavy_density=vrho[index],deltaV_times_ordinary_density=baryon[index],
                            half_gradV_squared=geo[index]/2,direct_flux=direct[index],reduced_flux=weak[index],
                            dimensionless_slip_integral=slipint[index]))
                    s_two=2*mesh.lo*slipint.sum()*mesh.acc*ep
                    prior_records=records(retained('matched-einstein-shell.csv'))
                    old,=[r for r in prior_records if r['steps']==str(steps) and int(r['degree'])==30 and
                          r['interpolated']=='radius_times_potential' and r['branch']==tag]
                    if method=='native':assert abs(s_two-float(old['total_difference']))<1e-16
                    checks.append(dict(steps=steps,order=order,method=method,arm=tag,
                        previous_two_edge_slip_relative=s_two/float(old['total_difference'])-1,
                        newton_poisson_relative=(newton-newton_direct)/newton_direct,
                        hamiltonian_forms_relative=(htotal-mesh.ham_weights@direct)/htotal))
                    if method!='green':continue
                    number=obj.number
                    def gain(rho):
                        interval_mass=integral(rho[:,0]);kernel=mesh.ham_weights
                        av=kernel@interval_mass/number
                        variance=kernel**2@interval_mass/number-av**2
                        return 2*number*np.sqrt(variance)
                    ga=gain(den);gb=gain(base_rho)
                    phase=np.clip((radius-mesh.lo)/(mesh.mid-mesh.lo),0,1)
                    bump=(4*phase*(1-phase))**4
                    av=integral(den[:,0]*bump).sum()/number
                    variance=integral(den[:,0]*bump**2).sum()/number-av**2
                    response=2*(mesh.ham_weights@integral(den[:,0]*(bump-av)))/np.sqrt(variance)
                    assert 0<abs(response)<=ga
                    for field,spec in [('spatial',e_h),('time',e_q),('weyl',wfield)]:
                        ambiguities.append(dict(steps=steps,order=order,arm=tag,field=field,
                            conditional_PN=spec,sharp_pair_gain_SI=unit*(ga+gb),sharp_single_gain_SI=unit*ga,
                            necessary_fractional_amplitude_pair=abs(spec)/(unit*(ga+gb)),
                            necessary_fractional_amplitude_single=abs(spec)/(unit*ga),
                            explicit_smooth_single_fraction_to_cancel=-spec/(unit*response),
                            explicit_fraction_over_v2_c2=-spec/(unit*response*ep),v2_c2=ep))
                print('shell',steps,order,method,flush=True)
    for name,rows in [('potentials',budgets),('normal-energy',energies),('flux-halves',halfrows),('routes',checks),('state-freedom',ambiguities)]:
        table(HERE/(name+'.csv'),rows,save)
if __name__=='__main__':
    assert sys.argv[1:] in ([],['--save']);calculate(bool(sys.argv[1:]))
