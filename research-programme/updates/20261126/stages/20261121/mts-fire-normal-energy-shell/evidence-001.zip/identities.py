"""Exact scalar constraint, canonical oscillator, and boundary tests."""
import json
from pathlib import Path
import sys
from functools import lru_cache
import sympy as sym

HERE=Path(__file__).resolve().parent
def ricci_normal():
    coords=sym.symbols('t x y z',real=True);tim,*space=coords
    lam=sym.Function('lam')(*coords);nu=sym.Function('nu')(*coords)
    metric=[-sym.exp(2*nu)]+[sym.exp(2*lam)]*3
    @lru_cache(None)
    def gamma(up,left,right):
        value=0
        if up==left:value+=sym.diff(metric[up],coords[right])
        if up==right:value+=sym.diff(metric[up],coords[left])
        if left==right:value-=sym.diff(metric[left],coords[up])
        return sym.simplify(value/(2*metric[up]))
    def diagonal(left):
        return sum(sym.diff(gamma(index,left,left),coords[index])-sym.diff(gamma(index,left,index),coords[left])+
            sum(gamma(index,left,left)*gamma(other,index,other)-gamma(other,left,index)*gamma(index,left,other) for other in range(4))
            for index in range(4))
    normal=sum(diagonal(index)/metric[index]*(1 if index else -1) for index in range(4))/2
    formula=sym.exp(-2*lam)*(-2*sum(sym.diff(lam,pos,2) for pos in space)-sum(sym.diff(lam,pos)**2 for pos in space))+3*sym.exp(-2*nu)*sym.diff(lam,tim)**2
    assert sym.simplify(normal-formula)==0
    return 'G_nn from spacetime Ricci with time-dependent nonspherical potentials'
def tests():
    checks=[ricci_normal()]
    eps,vel,psi,dens,sub,lap,squares=sym.symbols('e V p D t lap g2',real=True)
    assert sym.expand(sym.diff(sym.exp(-2*eps*vel)*(dens+eps*sub)/sym.exp(-3*eps*vel),eps).subs(eps,0)-(vel*dens+sub))==0
    checks.append('proper-volume and curvature factor for conserved coordinate density')
    x=sym.symbols('r',positive=True);v=sym.Function('V')(x)
    differential=lambda f:sym.diff(f,x,2)+2*sym.diff(f,x)/x
    assert sym.simplify(differential(v*v/2)-v*differential(v)-sym.diff(v,x)**2)==0
    checks.append('Poisson product reduction including the geometric sign')
    mass=sym.symbols('m',positive=True);schwarz=-2*sym.log(1+eps*mass/(2*x))/eps
    first=sym.series(schwarz,eps,0,2).removeO()
    assert sym.simplify(first+mass/x-eps*mass**2/(4*x**2))==0
    assert sym.simplify(differential(mass**2/(4*x*x))-sym.diff(-mass/x,x)**2/2)==0
    checks.append('exact Schwarzschild spatial potential and vanishing vacuum density')
    left,right=sym.symbols('k l',real=True)
    wl=sym.sqrt(1+eps*left**2);wr=sym.sqrt(1+eps*right**2)
    local=(wl*wr+1+eps*left*right)/(2*sym.sqrt(wl*wr))
    assert sym.simplify(sym.diff(local,eps).subs(eps,0)-left*right/2)==0
    assert sym.simplify(local.subs(right,left)-wl)==0
    checks+=['two-wave interference energy has the gradient coefficient, not a Laplacian density','single-mode proper energy equals its positive KG frequency']
    phase=sym.symbols('theta',real=True)
    ar,ai,kr,ki=sym.symbols('a b k h',real=True)
    osc=lambda real,imag:real*sym.cos(phase)+imag*sym.sin(phase)
    q=sym.sqrt(2)*osc(ar-eps*kr/2,ai-eps*ki/2)
    mom=sym.sqrt(2)*osc(ai+eps*ki/2,-ar-eps*kr/2)
    mixed=sym.integrate(sym.diff((q*q+mom*mom)/2,eps).subs(eps,0),(phase,0,2*sym.pi))
    assert sym.simplify(mixed)==0
    checks.append('opposite canonical normal-momentum and field lifts cancel locally after averaging')
    pot,kin,metric=sym.symbols('V K Q',commutative=False)
    hzero=pot+kin
    hnext=metric+pot**2/2+3*(pot*kin+kin*pot)/2-kin**2/2
    square=2*metric+2*pot**2+4*(pot*kin+kin*pot)
    assert sym.expand(2*hnext+hzero**2-square)==0
    assert sym.expand(pot/2-hzero/2+kin/2)==0
    checks+=['noncommuting first-order positive-frequency root','lapse cancels from canonical field lift']
    t=sym.symbols('tau');p=sym.symbols('p')
    dispersion=sym.sqrt(1+eps*p*p)
    assert sym.simplify(sym.series(sym.diff(dispersion,p)/eps,eps,0,2).removeO()-p+eps*p**3/2)==0
    checks.append('relativistic plane-wave group velocity matches the first dispersive current')
    radii=sym.Matrix([2,3,4]);pair=sym.Matrix([[sym.Rational(1,4),sym.Rational(1,16)],[2,4]]).inv()*sym.Matrix([-sym.Rational(1,9),-3])
    weights=sym.Matrix([pair[0],1,pair[1]])
    assert weights.dot(radii)==weights.dot(radii.applyfunc(lambda r:r**-2))==0
    checks.append('a common nonzero three-force probe removes both homogeneous modes')
    return checks
if __name__=='__main__':
    assert sys.argv[1:] in ([],['--save'])
    out=(json.dumps(tests(),indent=2)+'\n').encode();path=HERE/'identities.json'
    if sys.argv[1:] and not path.exists():
        with path.open('xb') as stream:stream.write(out)
    else:assert path.read_bytes()==out
    print('verified independent exact Ricci, carrier and normal-form identities')
