"""Check physical cross-routes, record sensitivity separately and seal local artifacts."""
import math
import sys
from normal_shell_io import HERE, PRIOR, PRIOR_SHA, PARENT, STEPS, check, sha, records, retained, save_json

def verify(save):
    check()
    for name in ('matched-einstein-shell.csv','tested-fields-32.npz','tested-fields-64.npz'):
        retained(name)
    sizes={'potentials':24,'normal-energy':36,'routes':24,'flux-halves':48,'state-freedom':24,
           'smooth-counterexample':24,'retarded-launch':8,'current-check':36,'dispersion-balance':12,'manufactured':12}
    tables={key:records(HERE/(key+'.csv')) for key in sizes}
    assert all(len(tables[key])==count for key,count in sizes.items())
    for rows in tables.values():
        assert all(None not in row and all(value is not None for value in row.values()) for row in rows)
    def pick(key,**filters):
        return [row for row in tables[key] if all(row[col]==str(val) for col,val in filters.items())]
    def one(key,**filters):
        row,=pick(key,**filters)
        return row
    def maxabs(rows,key):return max(abs(float(row[key])) for row in rows)
    assert maxabs(tables['routes'],'hamiltonian_forms_relative')<2e-7
    assert maxabs(pick('routes',method='green'),'hamiltonian_forms_relative')<1e-10
    assert maxabs(pick('routes',method='green'),'newton_poisson_relative')<1e-10
    assert maxabs(pick('routes',method='native'),'previous_two_edge_slip_relative')<2e-11
    assert maxabs(tables['normal-energy'],'projected_lapse_cancellation')<1e-8
    assert maxabs(tables['manufactured'],'error')<1e-12
    tests=__import__('json').loads((HERE/'identities.json').read_bytes())
    assert len(tests)==len(set(tests))==11
    for row in tables['normal-energy']:
        src=float(row['normal_density_excess_integrated_in_coordinate_volume_Msun'])
        measure=float(row['proper_volume_measure_correction_Msun'])
        assert abs(src+measure-float(row['proper_volume_canonical_energy_excess_Msun']))<1e-8
    for row in tables['smooth-counterexample']:
        diag=one('state-freedom',steps=row['steps'],order=row['order'],arm=row['arm'],field=row['field'].split('_')[0])
        actual=float(row['phase_invariant_L2_fraction']);minimum=float(diag['necessary_fractional_amplitude_single'])
        assert 0<minimum<actual<float(diag['v2_c2'])
        assert abs(float(row['relative_cancellation_error']))<1e-10
    fluxerr=maxabs(tables['dispersion-balance'],'closure')
    assert all(abs(float(row['closure']))<5e-11*max(1e-5,abs(float(row['native_volume'])),
               abs(float(row['outer_surface'])+float(row['internal_face_and_trace']))) for row in tables['dispersion-balance'])
    spreads={};current={};n0=None
    for arm in ('coupled','passive'):
        fine=one('potentials',steps=64,order=28,arm=arm,method='green')
        coarse=one('potentials',steps=32,order=28,arm=arm,method='green')
        low=one('potentials',steps=64,order=16,arm=arm,method='green')
        spreads[arm]={key:abs(float(coarse[key])/float(fine[key])-1) for key in ('newton_difference','spatial_PN','time_PN','slip_PN','weyl_PN')}
        assert all(math.copysign(1,float(fine[key]))==math.copysign(1,float(coarse[key])) for key in spreads[arm])
        assert max(abs(float(low[key])/float(fine[key])-1) for key in spreads[arm])<1e-8
        assert abs((float(fine['spatial_PN'])-float(fine['time_PN']))/float(fine['slip_PN'])-1)<1e-12
        current[arm]={}
        for steps in STEPS:
            diff=lambda tag,field:sum(float(row[field]) for row in pick('current-check',steps=steps,order=28,arm=tag))
            surface=diff(arm,'surface_rate')-diff('reset','surface_rate')
            volume=diff(arm,'volume_rate')-diff('reset','volume_rate')
            rate=float(one('retarded-launch',steps=steps,order=28,arm=arm)['total_SI_per_Myr'])
            assert surface*volume>0 and rate>0
            current[arm][str(steps)]={'surface_SI_per_Myr':rate,'native_drives_SI_per_Myr':rate*volume/surface,
                                      'surface_volume_relative_to_surface':abs(volume/surface-1)}
        if arm=='coupled':
            n0=float(fine['weyl_PN'])
            assert n0*(n0+float(fine['proper_baryon_alternative_shift']))<0
    result={'prior_seal_sha256':PRIOR_SHA,'parent_action_sha256':sha(PARENT),'rows':sizes,'exact_identities':len(tests),
            'coarse_to_fine_fractional_changes':spreads,'instantaneous_state_source_only':current,
            'finite_element_dispersion_balance_max_abs_dimensionless':fluxerr,
            'max_component_surface_vs_volume_relative':maxabs(tables['current-check'],'relative_disagreement'),
            'status':'conditional matched scalar shell; no evolved PN state or direct observable'}
    save_json('validation.json',result,save)
    expected={key+'.csv' for key in sizes}|{'constraint.py','identities.py','state_response.py','normal_shell_io.py',
              'controls.py','dispersion.py','verify.py','identities.json','PROTOCOL.md','DERIVATION.md','RESULTS.md','validation.json'}
    found={path.name for path in HERE.iterdir()}
    assert expected==found-{'seal.json'},(expected-found,found-expected)
    save_json('seal.json',{name:sha(HERE/name) for name in sorted(expected)},save)
    print('Checked',sum(sizes.values()),'rows;',len(expected),'sealed files;',sha(HERE/'seal.json'))

if __name__=='__main__':
    assert sys.argv[1:] in ([],['--save'])
    verify(bool(sys.argv[1:]))
