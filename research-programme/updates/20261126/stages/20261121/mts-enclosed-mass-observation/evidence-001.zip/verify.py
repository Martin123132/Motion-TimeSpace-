import csv
import json
import math
import sys
from measure import HOME, PART, PRE, digest, json_out, pin


def rows(name):
    with (HOME/name).open(newline='') as stream:
        return list(csv.DictReader(stream))


def verify(create):
    receipt = json.loads((HOME/'receipt.json').read_bytes())
    pin(PRE/'freeze.json',receipt['model_freeze'])
    pin(HOME/'METHOD.md',receipt['protocol'])
    assert receipt['unchanged_tolerances']==[1e-9,.005]
    assert receipt['observational_residual'] is None and receipt['independent_direction'] is None and not receipt['matched_total_available']
    assert len(receipt['phase_packets'])==24
    for stem, signature in receipt['phase_packets'].items():
        pin(PART/(stem+'.npz'),signature)
    history = rows('raw-baryon-masses.csv')
    secants = rows('raw-baryon-secants.csv')
    currents = rows('raw-baryon-currents.csv')
    targets = rows('physical-targets.csv')
    assert (len(history),len(secants),len(currents),len(targets))==(45,15,90,20)
    def close(one, two):
        assert math.isclose(float(one), float(two), rel_tol=1e-9, abs_tol=1e-12), (one,two)
    for table, groups, outputs in ((history,['epoch'],['mass_Msun']),(secants,[],['left_Msun_yr','right_Msun_yr','centered_Msun_yr']),
                                    (currents,['center_velocity','halfwidth_kpc'],['advective_Msun_yr'])):
        keys = {tuple(row[key] for key in groups) for row in table}
        for group in keys:
            subset = {(row['species'],row['region']):row for row in table if tuple(row[key] for key in groups)==group}
            for region in ('face1','face2','face3','shell1','shell2'):
                for field in outputs:
                    close(subset['gas+stars',region][field], sum(float(subset[phase,region][field]) for phase in ('gas','stars')))
            for species in ('gas','stars','gas+stars'):
                for field in outputs:
                    for index in (1,2):
                        close(subset[species,f'shell{index}'][field],float(subset[species,f'face{index+1}'][field])-float(subset[species,f'face{index}'][field]))
    for row in targets:
        pair, = [other for other in targets if other['arm']==row['arm'] and other['region']==row['region'] and other['direction']!=row['direction']]
        close(row['mass_rate_Msun_yr'],-float(pair['mass_rate_Msun_yr']))
        close(row['opposite_sign_separation_Msun_yr'],2*abs(float(pair['mass_rate_Msun_yr'])))
    names = ('measure.py','verify.py','METHOD.md','SOURCES.md','RESULTS.md','receipt.json','raw-baryon-masses.csv',
             'raw-baryon-secants.csv','raw-baryon-currents.csv','physical-targets.csv')
    manifest = {name:digest(HOME/name) for name in names}
    if create:
        json_out('seal.json',manifest)
    assert manifest==json.loads((HOME/'seal.json').read_bytes())
    print('Verified',len(manifest),'files;',digest(HOME/'seal.json'))


if __name__=='__main__':
    if not __debug__:
        raise RuntimeError('Use assertions for verification')
    verify(sys.argv[1:]==['--seal'])
