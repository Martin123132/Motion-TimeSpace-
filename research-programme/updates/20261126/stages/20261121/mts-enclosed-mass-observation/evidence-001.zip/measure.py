import csv
import hashlib
import io
import json
import os
from pathlib import Path

for key in ('OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','OMP_NUM_THREADS','NUMEXPR_NUM_THREADS','BLIS_NUM_THREADS'):
    os.environ[key] = '1'
import numpy as np

HOME = Path(__file__).resolve().parent
ROOT = HOME.parent
PRE = ROOT/'mts-fire-density-forecast-20261121'
PART = ROOT/'mts-fire-current-moment-20261121'
BANK = ROOT/'mts-fire-joint-baryon-history-20261120'
KPC_TIME = 977.7922216807892
GRAVITY = 4.30091727003628e-6


def digest(path):
    with path.open('rb') as handle:
        return hashlib.file_digest(handle, 'sha256').hexdigest()


def pin(path, expected):
    if digest(path) != expected:
        raise ValueError(f'Unexpected input: {path}')
    return path


def retain(name, data):
    path = HOME/name
    if path.exists():
        if path.read_bytes() != data:
            raise ValueError(f'Conflicting receipt: {path}')
    else:
        with path.open('xb') as handle:
            handle.write(data)


def json_out(name, payload):
    retain(name, (json.dumps(payload, sort_keys=True, indent=2, allow_nan=False)+'\n').encode())


def tab(name, rows):
    buffer = io.StringIO()
    writer = csv.DictWriter(buffer, fieldnames=list(rows[0]), lineterminator='\n')
    writer.writeheader()
    writer.writerows(rows)
    retain(name, buffer.getvalue().encode())


def run():
    freeze = json.loads(pin(PRE/'freeze.json','56e6fe56045146e609bdb80a970949886d0bcf0d49312d8332fe72b068d17776').read_bytes())
    tol = freeze['parity_tolerance']
    assert tol == 1e-9 and freeze['numerical_ceiling'] == .005
    with pin(PRE/'enclosed-forecast.csv', freeze['mass']).open(newline='') as handle:
        forecasts = list(csv.DictReader(handle))
    radii = np.array(sorted({float(row['r_kpc']) for row in forecasts}))
    assert radii.size == 3
    target_rows = []
    for arm in ('reset','coupled'):
        for direction in ('forward','reversed'):
            rows = sorted([row for row in forecasts if row['arm']==arm and row['direction']==direction],key=lambda row:float(row['r_kpc']))
            rates = np.array([float(row['dmass_dt_Msun_Myr'])/1e6 for row in rows])
            for index, rate in enumerate(np.r_[rates,np.diff(rates)]):
                face = index < 3
                target_rows.append(dict(arm=arm,direction=direction,region=('face' if face else 'shell')+str(index+1 if face else index-2),
                    mass_rate_Msun_yr=rate,opposite_sign_separation_Msun_yr=2*abs(rate),
                    sphere_mean_radial_jerk_m_s3=(-GRAVITY*rate/radii[index]**2 * 1.e6 / 3.085677581491367e19 / 31557600 if face else '')))
    tab('physical-targets.csv',target_rows)
    inputs = json.loads(pin(PART/'seal.json','e4b2446f5c018c3de8cb3b4175ff68d581dd984ffe87a56d62219e5d2cadd1d8').read_bytes())
    old = json.loads(pin(BANK/'seal.json','19c78eaa158a766bd409c0a64504788b1346542eccee37c004083a918c480d67').read_bytes())['files']
    checked_meta = {}
    times = np.loadtxt(pin(BANK/'snapshot_times.txt',old['snapshot_times.txt']))
    epochs = (589,590,591)
    time = np.array([times[times[:,0]==epoch,3].item() for epoch in epochs])*1e9
    left, right = np.diff(time)
    frames = []
    for epoch in epochs:
        name = f'{epoch}_coords_DR.txt'
        content = pin(BANK/name,old[name]).read_text().splitlines()
        frames.append(np.fromstring(' '.join(line for line in content if not line.strip().startswith('#')),sep=' '))
    scale = frames[1][1]
    centers = np.array([frame[2:5] for frame in frames])
    trajectory = (right*(centers[1]-centers[0])/left+left*(centers[2]-centers[1])/right)/(left+right)*KPC_TIME*1e6*scale
    bulks = {'catalog':frames[1][5:8], 'trajectory':trajectory}
    bandwidths = (.08,.16,.32)
    assert radii[0]-max(bandwidths)>5.75 and radii[-1]+max(bandwidths)<9.
    components = np.zeros((3,2,3))
    direct_shells = np.zeros((3,2,2))
    flux = np.zeros((2,3,2,3))
    pin(PART/'acquire.py',inputs['acquire.py'])
    for step, epoch in enumerate(epochs):
        for piece in range(4):
            for phase, species in enumerate((0,4)):
                stem = f'inputs/s{epoch}-{piece}-p{species}'
                receipt = json.loads(pin(PART/(stem+'.json'),inputs[stem+'.json']).read_bytes())
                signature = receipt['packet_sha256']
                checked_meta[stem] = signature
                assert receipt['piece']==piece and receipt['url'].endswith(f'snapshot_{epoch}.{piece}.hdf5')
                with np.load(pin(PART/(stem+'.npz'),signature)) as saved:
                    mass = saved['mass_Msun']
                    position = saved['pos_kpc']
                    radius = np.linalg.norm(position,axis=1)
                    assert len(mass)==receipt['shell_count'] and np.all((radius>=5.75)&(radius<9.)&(mass>0))
                    inner = saved['group']//7 < 6
                    groups = saved['group_mass_Msun'].reshape(13,7)
                    below_band = groups[:6].sum()-mass[inner].sum()
                    assert below_band>=0
                    enclosed = np.array([below_band+mass[radius<face].sum() for face in radii])
                    direct = np.array([mass[(radius>=low)&(radius<high)].sum() for low,high in zip(radii[:-1],radii[1:])])
                    assert np.allclose(np.diff(enclosed),direct,rtol=tol,atol=0)
                    components[step,phase] += enclosed
                    direct_shells[step,phase] += direct
                    if epoch!=590:
                        continue
                    header = receipt['header']
                    hub = .1*header['HubbleParam']*np.sqrt(header['Omega0']/scale**3+header['OmegaLambda']+(1-header['Omega0']-header['OmegaLambda'])/scale**2)
                    velocities = saved['velocity_stored'].astype(float)*np.sqrt(scale)
                    for center_index, bulk in enumerate(bulks.values()):
                        radial = np.einsum('ij,ij->i',velocities-bulk+hub*position,position)/radius
                        for width_index,width in enumerate(bandwidths):
                            for face_index,face in enumerate(radii):
                                kernel = np.maximum(1-abs(radius-face)/width,0)/width
                                flux[center_index,width_index,phase,face_index] -= np.sum(mass*radial*kernel)/(KPC_TIME*1e6)
    history, derivative, current = [], [], []
    for species, code in (('gas',0),('stars',1),('gas+stars',None)):
        faces = components.sum(axis=1) if code is None else components[:,code]
        shells = direct_shells.sum(axis=1) if code is None else direct_shells[:,code]
        assert np.allclose(np.diff(faces,axis=1),shells,rtol=tol,atol=0)
        amounts = np.column_stack((faces,shells))
        for region, values in zip(('face1','face2','face3','shell1','shell2'), amounts.T):
            for epoch, value in zip(epochs,values):
                history.append(dict(epoch=epoch,species=species,region=region,mass_Msun=value))
            backward,forward = np.diff(values)/np.diff(time)
            derivative.append(dict(species=species,region=region,left_Msun_yr=backward,right_Msun_yr=forward,
                                   centered_Msun_yr=(right*backward+left*forward)/(left+right)))
        sliced = flux.sum(axis=2) if code is None else flux[:,:,code]
        for center_index,center in enumerate(bulks):
            for width_index,width in enumerate(bandwidths):
                through = sliced[center_index,width_index]
                for region,value in zip(('face1','face2','face3','shell1','shell2'), np.r_[through,np.diff(through)]):
                    current.append(dict(species=species,region=region,center_velocity=center,halfwidth_kpc=width,
                                        advective_Msun_yr=value))
    tab('raw-baryon-masses.csv',history)
    tab('raw-baryon-secants.csv',derivative)
    tab('raw-baryon-currents.csv',current)
    json_out('receipt.json',dict(launch=590,elapsed_yr=[left,right],phase_packets=checked_meta,
                                model_freeze=digest(PRE/'freeze.json'),protocol=digest(HOME/'METHOD.md'),
                                unchanged_tolerances=[tol,freeze['numerical_ceiling']],matched_total_available=False,
                                observational_residual=None,independent_direction=None))


if __name__=='__main__':
    run()
