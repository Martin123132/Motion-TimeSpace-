import json
from pathlib import Path
from inject import run,save,encode
from fields import sha,rows

def verify():
    home=Path(__file__).resolve().parent
    products=('roster.csv','recoveries.csv','tracer-templates.csv','checks.json','sensitivity.json','inputs.json')
    before={name:sha(home/name) for name in products}
    run()
    assert all(sha(home/name)==digest for name,digest in before.items())
    for name,digest in json.loads((home/'inputs.json').read_bytes()).items():
        assert sha(home.parent/name)==digest
    counts=rows(home/'recoveries.csv')
    for prep in ('reset','coupled'):
        for method in ('arrival-level','score-space'):
            subset=[r for r in counts if r['preparation']==prep and r['simulation']==method]
            actual=[r for r in subset if not r['injection'].startswith('5sigma')]
            assert len(actual)==3 and len({(r['positive'],r['negative'],r['unresolved']) for r in actual})==1
        for row in counts:
            assert int(row['count'])==sum(int(row[k]) for k in ('positive','negative','unresolved'))
    seal={name:sha(home/name) for name in (*products,'PROTOCOL.md','RESULTS.md','fields.py','inject.py','verify.py')}
    save('seal.json',encode(seal))
    print('Verified replay, inputs and outputs:',sha(home/'seal.json'))

if __name__=='__main__':
    verify()
