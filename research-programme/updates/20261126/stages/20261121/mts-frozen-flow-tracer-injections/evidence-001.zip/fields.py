import csv
import hashlib
import json
from pathlib import Path

import numpy as np
from scipy.interpolate import CubicHermiteSpline
from numpy.polynomial.legendre import legval, legder

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
FROZEN = ROOT/'mts-fire-density-forecast-20261121'
WAVE = ROOT/'mts-fire-geodesic-echo-20261121'
ORD = ROOT/'mts-enclosed-mass-observation-20261121'
PART = ROOT/'mts-fire-current-moment-20261121'
TEN = ROOT/'mts-clock-cleaned-ten-pulsar-array-20261121'
PILOT = ROOT/'mts-real-wave-pulsar-timing-20261121'
SKY = ROOT/'mts-solar-differential-acceleration-20261119'/'geometry.csv'
SUN = np.array([-8.1, 0., 0.])
G = 4.30091727003628e-6
KM_KPC = 3.085677581491367e16
YEAR = 31557600.
JERK_SI = 1000./KM_KPC**2
SEEN = {}

def sha(path):
    with path.open('rb') as handle:
        return hashlib.file_digest(handle, 'sha256').hexdigest()

def pinned(path, expected):
    observed = sha(path)
    if observed != expected.lower():
        raise ValueError(f'changed input: {path}')
    SEEN[str(path.relative_to(ROOT))] = observed
    return path

def read(path):
    return json.loads(path.read_bytes())

def rows(path):
    with path.open(newline='') as handle:
        return list(csv.DictReader(handle))

def fields():
    pinned(HERE/'PROTOCOL.md','bbfcfb0e5251a986a95f5674f556804e191178d357e07bc2afd871bfcaea24d3')
    freeze = read(pinned(FROZEN/'freeze.json','56e6fe56045146e609bdb80a970949886d0bcf0d49312d8332fe72b068d17776'))
    tol, ceiling = freeze['parity_tolerance'], freeze['numerical_ceiling']
    assert (tol,ceiling)==(1e-9,.005)
    sky = {row['NAME']:row for row in rows(pinned(SKY,'1a1b14f08dbc97e36af23889462c72977b5a76063bdae7a7589a0a7ac182d96b'))}
    archives = {TEN:read(pinned(TEN/'seal.json','5ad55ccc0dc1eb61eefeca85ee61c420fc5f377831339dee286912a83777b347')),
                PILOT:read(pinned(PILOT/'seal.json','392484a48af375de1f0075823d63bed0e66e45c7b1039a2b70c1073296614f8c'))}
    for folder, names in [(TEN,['roster.csv','array_metric.py','acquire_array.py']), (PILOT,['noise_transfer.py','pulsar_cadence_projection.py','wave_clock.py'])]:
        for filename in names+['noise-inputs.json']:
            pinned(folder/filename, archives[folder][filename])
    banks = {}
    for key, signature in freeze['inputs'].items():
        with np.load(pinned(WAVE/key,signature)) as packet:
            radius = packet['r']
            banks[key] = {name:CubicHermiteSpline(radius,packet[name],packet[name+'_r'],axis=0,extrapolate=False)
                          for name in ('V','Vdot','Vdot_operator')}
    roster, positions, dirs = [], [SUN], []
    for item in rows(TEN/'roster.csv'):
        name = item['name']
        src = sky[name]
        lon,lat = np.radians([float(src['GL']),float(src['GB'])])
        axis = np.array([np.cos(lon)*np.cos(lat),np.sin(lon)*np.cos(lat),np.sin(lat)])
        position = SUN+float(src['DIST'])*axis
        rad = np.linalg.norm(position)
        eligible = bool(max(radius.min(),5.75)<rad<min(radius.max(),9.))
        roster.append(dict(name=name,distance_kpc=float(src['DIST']),sigma_distance_kpc=float(src['DIST_ERR']),radius_kpc=rad,
                           usable=eligible,arrivals=int(item['arrivals']),span_year=float(item['span_year'])))
        if eligible:
            positions.append(position)
            dirs.append(axis)
            folder = PILOT if name in ('J0613-0200','J1713+0747') else TEN
            for suffix in ('-design.npz','-bands.npz'):
                pinned(folder/(name+suffix),archives[folder][name+suffix])
    pos, los = np.array(positions),np.array(dirs)
    radial = np.linalg.norm(pos,axis=1)
    planes = np.linalg.norm(pos[:,:2],axis=1)
    unit = pos/radial[:,None]
    faces = np.unique([float(row['r_kpc']) for row in rows(pinned(FROZEN/'enclosed-forecast.csv',freeze['mass']))])
    ord_seal = read(pinned(ORD/'seal.json','bcc6544d5b7a5169f8c148a7e2ce1fe3bd697122c742d24006c8fe431eb38892'))
    receipt = read(pinned(ORD/'receipt.json',ord_seal['receipt.json']))
    points = np.r_[radial,faces]
    mass = np.zeros((3,len(points)))
    for step,epoch in enumerate((589,590,591)):
        for piece in range(4):
            for species in (0,4):
                key = f'inputs/s{epoch}-{piece}-p{species}'
                with np.load(pinned(PART/(key+'.npz'),receipt['phase_packets'][key])) as source:
                    weight = source['mass_Msun']
                    radii = np.linalg.norm(source['pos_kpc'],axis=1)
                    below = source['group_mass_Msun'].reshape(13,7)[:6].sum()-weight[source['group']//7<6].sum()
                    mass[step] += np.array([below+weight[radii<val].sum() for val in points])
    left,right = receipt['elapsed_yr']
    rates = (right*np.diff(mass,axis=0)[0]/left + left*np.diff(mass,axis=0)[1]/right)/(left+right)
    reference = [float(row['centered_Msun_yr']) for row in rows(pinned(ORD/'raw-baryon-secants.csv',ord_seal['raw-baryon-secants.csv']))
                 if row['species']=='gas+stars' and row['region'].startswith('face')]
    assert np.allclose(rates[-3:],reference,rtol=tol,atol=0)
    grav = -G*mass[1,:-3,None]*unit/radial[:,None]**2
    gdot = -G*rates[:-3,None]*unit/radial[:,None]**2 * (KM_KPC/YEAR)
    rotation = np.array([0.,0.,1.])
    omega = np.sqrt(G*mass[1,:-3]/radial**3)
    velocity = omega[:,None]*np.cross(rotation,pos)
    relvel = velocity[1:]-velocity[0]
    dist = np.linalg.norm(pos[1:]-pos[0],axis=1)
    vlos = np.sum(los*relvel,axis=1)
    vperp = relvel-vlos[:,None]*los
    def geom(acc,dot):
        jerk = dot+omega[:,None]*np.cross(rotation,acc)
        return np.sum(los*(jerk[1:]-jerk[0]),axis=1)+3*np.sum(vperp*(acc[1:]-acc[0]),axis=1)/dist
    baryon = JERK_SI*(geom(grav,gdot)-3*vlos*np.sum(vperp*vperp,axis=1)/dist**2)
    def value_gradient(spline,where):
        rad = np.linalg.norm(where)
        versor = where/rad
        mu = versor[-1]
        coeff = np.zeros(69); deriv = coeff.copy()
        coeff[::2] = spline(rad); deriv[::2] = spline(rad,1)
        return legval(mu,coeff), legval(mu,deriv)*versor+legval(mu,legder(coeff))*(rotation-mu*versor)/rad
    signals, checks = {},{}
    for arm in ('reset','coupled'):
        controls = {}
        for order in (12,8):
            bank = banks[f'current-{arm}-{order}.npz']
            for name in ('V','Vdot','Vdot_operator'):
                grad = np.array([value_gradient(bank[name],point)[1] for point in pos])
                if name=='V' and order==12:
                    even = geom(-grad,np.zeros_like(grad))*JERK_SI
                if name!='V':
                    controls[order,name] = -JERK_SI*np.sum(los*(grad[1:]-grad[0]),axis=1)
                if name=='Vdot' and order==12:
                    step = 1e-5
                    fd = np.array([[(value_gradient(bank[name],point+step*axis)[0]-value_gradient(bank[name],point-step*axis)[0])/(2*step)
                                    for axis in np.eye(3)] for point in pos])
                    checks[arm+'_spatial_gradient'] = np.linalg.norm(fd-grad)/np.linalg.norm(grad)
        odd = controls[12,'Vdot']
        for (order,name),test in controls.items():
            checks[f'{arm}_{order}_{name}'] = np.linalg.norm(test-odd)/np.linalg.norm(odd)
        assert np.isfinite(odd).all() and np.linalg.norm(odd)>0
        signals[arm]=(even,odd)
    assert max(checks.values())<ceiling, checks
    return roster,los,baryon,signals,checks
