from fixture import *
import sympy as sp


def vertex(extent,angular,where):
    unit=2*np.pi/extent
    clock,space=np.indices((extent,extent))
    inputs=[np.exp(1j*unit*(clock*time+space*radial)) for time,radial in ((2,0),(-1,angular),(-1,-angular))]
    shear,first,second=inputs
    measured=0j
    hvp=0j
    expected=0
    for axis in (0,1):
        forward=lambda given:np.roll(given,-1,axis=axis)-given
        face=(shear+np.roll(shear,-1,axis=axis))/2 if where=="corners" else shear*np.exp(1j*unit*(axis==0))
        measured-=np.mean(face*forward(first)*forward(second))
        hvp+=np.mean(forward(first)*forward(first.conjugate()))
        expected+=4*np.sin(unit*(1 if axis==0 else angular)/2)**2
    formula=4*(np.cos(unit) if where=="corners" else 1)*np.sin(unit/2)**2-4*np.sin(unit*angular/2)**2
    assert abs(measured-formula)<1e-14 and abs(hvp-expected)<1e-14
    return measured,hvp.real

def main():
    eps=sp.symbols("eps")
    raw=json.loads((PARENT/"frozen-projectors.json").read_bytes())["projectors"]
    with (PARENT/"operator-bank.csv").open() as handle:
        weyl={int(row["transverse"]):int(row["Weyl"]) for row in csv.DictReader(handle)
              if row["temporal"]=="1" and row["metric"]=="TT"}
    rows=[]
    for where, multiplier in (("corners",sp.cos(eps)),("center",1)):
        for bank,details in enumerate(raw,1):
            indices=details["indices"]
            weights=list(map(sp.Rational,details["weights"]))
            contracted=sum(weight*(4*multiplier*sp.sin(eps/2)**2-4*sp.sin(eps*angular/2)**2)
                           for weight,angular in zip(weights,indices))
            leading=sp.expand(sp.series(contracted,eps,0,6).removeO()).coeff(eps,4)
            assert sp.limit(contracted/eps**2,eps,0)==0
            assert leading==({"corners":sp.Rational(1,96),"center":-sp.Rational(1,48)}[where])
            for extent in (8,16,32,64,128):
                result=0.
                normalized=0.
                recovered=0j
                unit=2*np.pi/extent
                _,hvp=vertex(extent,4,where)
                read_normalization=1.73*hvp/(4*(np.sin(unit/2)**2+np.sin(4*unit/2)**2))
                for angular,weight in zip(indices,weights):
                    val,_=vertex(extent,angular,where)
                    vertex_predicted=4*(np.cos(unit) if where=="corners" else 1)*np.sin(unit/2)**2-4*np.sin(unit*angular/2)**2
                    result+=float(weight)*val.real/unit**4
                    normalized+=float(weight)*(1.73*val-read_normalization*vertex_predicted)/unit**4
                    injected=1.73*val-.037*weyl[angular]*unit**4
                    recovered+=float(weight)*(injected-read_normalization*vertex_predicted)/unit**4
                assert abs(normalized)<1e-11 and abs(recovered+.037)<1e-11
                rows.append(dict(metric_sample=where,bank=bank,N=extent,raw_projected=result,
                                 exact_small_momentum=str(leading),calibrated_maxwell=read_normalization,
                                 after_matched_subtraction=normalized.real,injected_recovered=recovered.real))
    table("maxwell-leakage.csv",rows)
    print("Exact Maxwell leakage: +a^2/96 (corners), -a^2/48 (center); both banks.")

if __name__=="__main__":
    main()
