from response import *

def main():
    rows=[]
    for case,links in enumerate(histories()):
        ensemble=[Fermion(links,*flavor) for flavor in FLAVORS]
        glue=gauge_stress(links)
        for mode in range(4):
            target=terms(ensemble,glue,((2,0,"h"),(-1,mode,"A"),(-1,-mode,"A")))
            swapped=terms(ensemble,glue,((2,0,"h"),(-1,-mode,"A"),(-1,mode,"A")))
            bose=max(abs(target[key]-swapped[key]) for key in target)/VOL
            assert bose<2e-10
            for first,second in (("grad","A"),("A","grad"),("grad","grad")):
                values=terms(ensemble,glue,((2,0,"h"),(-1,mode,first),(-1,-mode,second)))
                full=sum(values.values())/VOL
                missing=full-(values["double_contact"]+values["triple_contact"])/VOL
                assert abs(full)<2e-10
                rows.append(dict(configuration=case,n=mode,first=first,second=second,bose=bose,
                                 ward_abs=abs(full),without_contacts_abs=abs(missing)))
    assert max(row["without_contacts_abs"] for row in rows)>1e-5
    table("all-ward-controls.csv",rows)
if __name__=="__main__":
    main()
