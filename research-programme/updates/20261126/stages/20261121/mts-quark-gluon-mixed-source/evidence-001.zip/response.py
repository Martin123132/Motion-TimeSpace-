from fixture import *


def pair_spin(spin, link):
    return np.einsum("ij,tab->tiajb",spin,link).reshape(8,12,12)


class Fermion:
    def __init__(self, links, mass, charge):
        self.mass, self.charge = mass, charge
        self.hops = {}
        for axis in range(4):
            for sign in (1,-1):
                link = links[:,axis] if sign==1 else np.roll(links[:,axis],int(axis==0),axis=0).conj().swapaxes(1,2)
                self.hops[axis,sign] = pair_spin(np.eye(4),link), pair_spin(GAMMA[axis],link)
        self.inverse = np.linalg.inv(self.vertex((),0)[0])
    def vertex(self, waves, mask):
        selected = [wave for index,wave in enumerate(waves) if mask & 1<<index]
        shear = any(kind=="h" for kt, xx, kind in selected)
        power = sum(xx for kt,xx,kind in selected)
        result = np.zeros((32,8,12,8,12),complex)
        onsite = self.mass+4 if not selected else 0
        if onsite:
            result[:,TIME,:,TIME,:] += onsite*IDENT
        for axis in range(4):
            coefficients = []
            for kt,xx,kind in selected:
                value = 1 if kind=="h" else (float(axis==2) if kind=="A" else
                    np.expm1(1j*EPS*(kt if axis==0 else xx if axis==1 else 0)))
                coefficients.append(value*np.exp(1j*EPS*kt*TIME))
            profile = np.prod(coefficients,axis=0) if coefficients else np.ones(8)
            if not np.any(profile):
                continue
            wilson, frame = (ETA[axis],ETA[axis]/2) if shear else (1,1)
            if not wilson and not frame:
                continue
            if shear and len(selected)==1:
                result[:,TIME,:,TIME,:] += (wilson*profile)[:,None,None,None]*IDENT
            for sign in (1,-1):
                site = (TIME+sign*int(axis==0))%8
                ap = np.where((TIME+sign*int(axis==0))!=site,-1.,1.)
                momentum = np.ones(32) if axis==0 else np.exp(1j*sign*MOM[:,axis-1]*(EPS if axis==1 else np.pi))
                strength = (.5*(sign*1j*self.charge)**(len(selected)-int(shear))) * ap
                strength = strength * (profile if sign==1 else np.roll(profile,int(axis==0))*
                                            np.exp(-1j*EPS*power*int(axis==1)))
                unit, gamma = self.hops[axis,sign]
                blocks = (-wilson*unit+sign*frame*gamma)*strength[:,None,None]
                result[:,TIME,:,site,:] += blocks[:,None,:,:]*momentum[None,:,None,None]
        return result.reshape(32,96,96),power
    def measure(self, waves):
        dressed, shifts = {}, {}
        for mask in range(1,8):
            mat, power = self.vertex(waves, mask)
            shifts[mask] = power
            dressed[mask] = np.roll(self.inverse,-4*power,axis=0) @ mat
        def trace(*masks):
            values = 0
            product = None
            for mask in reversed(masks):
                shifted = np.roll(dressed[mask],-4*values,axis=0)
                if product is None:
                    product = shifted
                elif mask==masks[0]:
                    return (np.einsum("bij,bji->",shifted,product)
                            if (values+shifts[mask])%8==0 else 0j)
                else:
                    product = shifted @ product
                values += shifts[mask]
            return np.trace(product,axis1=1,axis2=2).sum() if values%8==0 else 0j
        single = [-trace(bit) for bit in (1,2,4)]
        pairs = [-trace(left|right)+trace(left,right) for left,right in ((2,4),(1,4),(1,2))]
        contact3 = -trace(7)
        contact2 = trace(3,4)+trace(5,2)+trace(6,1)
        triangle = -trace(1,2,4)-trace(1,4,2)
        return np.array(single),np.array(pairs),np.array([triangle,contact2,contact3])


def gauge_stress(links):
    total = 0j
    height = np.exp(2j*EPS*TIME)
    for first,second,density in plaquettes(links):
        face = (height+np.roll(height,-1))/2 if first==0 else height
        total += 32*BETA*(ETA[first]+ETA[second])*np.dot(density,face)
    return total


def terms(fermions, gauge, waves):
    jets = [source.measure(waves) for source in fermions]
    singles,pairs,loops = (sum(entries) for entries in zip(*jets))
    total_h = singles[0]+gauge
    return {"triangle":loops[0],"double_contact":loops[1],"triple_contact":loops[2],
            "quark_shear_pair":-singles[0]*pairs[0], "gluon_shear_pair":-gauge*pairs[0],
            "current_pairs":-np.dot(singles[1:],pairs[1:]),"third_cumulant":total_h*singles[1]*singles[2]}


def run():
    histories_used = histories()
    sums = {}
    parts = []
    controls = []
    gold = {}
    for case,links in enumerate(histories_used):
        fermions = [Fermion(links,*flavor) for flavor in FLAVORS]
        gluon = gauge_stress(links)
        for angular in range(4):
            waves = ((2,0,"h"),(-1,angular,"A"),(-1,-angular,"A"))
            components = terms(fermions,gluon,waves)
            mixed = sum(components.values())/VOL
            for label, reading in components.items():
                parts.append({"configuration":case,"n":angular,"term":label,**fields(reading/VOL)})
            sums[angular] = sums.get(angular,0j) + WEIGHTS[case]*mixed
            gold[case,angular] = mixed
            if case==0 or angular==1:
                swaps = terms(fermions,gluon,(waves[0],waves[2],waves[1]))
                bose = max(abs(swaps[key]-val) for key,val in components.items())/VOL
                assert bose < 2e-10
                for leg in (1,2):
                    replaced = list(waves)
                    replaced[leg] = (*replaced[leg][:2],"grad")
                    ward = sum(terms(fermions,gluon,replaced).values())/VOL
                    assert abs(ward)<2e-10
                    controls.append(dict(configuration=case,n=angular,leg=leg,ward_abs=abs(ward),bose_abs=bose))
        print(f"analytic SU(3) history {case+1}/3",flush=True)
    assert max(abs(row["real"]+1j*row["imag"]) for row in parts if row["term"]=="gluon_shear_pair")>1e-7
    assert max(abs(row["real"]+1j*row["imag"]) for row in parts if row["term"]=="third_cumulant")>1e-11
    table("trace-decomposition.csv",parts)
    table("ward-bose.csv",controls)
    table("analytic-modes.csv",[dict(n=num,**fields(val)) for num,val in sums.items()])
    return gold,sums


if __name__=="__main__":
    run()
