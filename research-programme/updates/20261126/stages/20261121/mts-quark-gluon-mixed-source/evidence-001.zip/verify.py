from fixture import *
import re
import sys
from check import read,main as check


def verify():
    if not __debug__:
        raise RuntimeError("Run with assertions enabled.")
    check()
    inputs=[PARENT/"seal.json",PARENT/"frozen-projectors.json",PARENT/"operator-bank.csv",
            PARENT.parent/"source-intake/functional_rg/4946/QCD_TJJ_dispersion_and_lattice_contract.csv"]
    digest=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
    parent_files=json.loads(inputs[0].read_bytes())
    for path in inputs[1:3]:
        assert digest(path)==parent_files["files"][path.name]
    assert digest(inputs[3])==parent_files["source_contracts"][inputs[3].relative_to(PARENT.parent).as_posix()]
    required={"DESIGN.md","RESULTS.md","DERIVATION.md","MAXWELL.md","REPLAY.md","verify.py","check.py","summary.json",
              "fixture.py","response.py","direct.py","precision.py","real_measure.py","ward_controls.py",
              "flavor.py","maxwell.py","improved.py","transport.py"}
    expected_rows={"analytic-modes":4,"trace-decomposition":84,"ward-bose":12,"all-ward-controls":36,
              "direct-agreement":12,"weighted-readouts":2,"real-partition":6,"finite-gauge":1,
              "three-flavor-difference":8,"maxwell-leakage":20,"improved-maxwell":10,
              "changed-gluon-stress":12,"changed-gluon-banks":2}
    expected_rows.update({f"direct-{idx}":12 for idx in range(3)})
    expected_rows.update({f"precision-{idx}":24 for idx in range(3)})
    required.update(name+".csv" for name in expected_rows)
    files={path.name for path in ROOT.iterdir() if path.name!="seal.json"}
    assert required==files, (required-files,files-required)
    for name,num in expected_rows.items():
        rows=read(name+".csv")
        assert len(rows)==num and all(None not in row and all(item is not None and item!="" for item in row.values()) for row in rows)
    ward=read("all-ward-controls.csv")
    assert len({(r["configuration"],r["n"],r["first"],r["second"]) for r in ward})==36
    assert max(float(r["ward_abs"]) for r in ward)<2e-10 and max(float(r["bose"]) for r in ward)<2e-10
    assert max(float(r["without_contacts_abs"]) for r in ward)>1e-4
    for row in read("improved-maxwell.csv"):
        assert row["corner_fraction"]=="2/3" and float(row["absolute_error"])<1e-12
        if row["bank"]=="1":
            assert abs(float(row["direct_real"]))<1e-12 and float(row["predicted"])==0
    for row in read("changed-gluon-stress.csv")+read("changed-gluon-banks.csv"):
        assert float(row["direct_error"])<2e-7
    for name in required:
        if name.endswith(".md"):
            for link in re.findall(r"\]\(([^)\s]+)\)",(ROOT/name).read_text(encoding="utf-8")):
                if not link.startswith(("https:","#")):
                    assert (ROOT/link).is_file(),(name,link)
        elif name.endswith(".py"):
            compile((ROOT/name).read_bytes(),name,"exec")
    payload=json.dumps(dict(source_sha256={path.relative_to(PARENT.parent).as_posix():digest(path) for path in inputs},
                       files={name:digest(ROOT/name) for name in sorted(required)},csv_rows=sum(expected_rows.values())),
                       indent=2,sort_keys=True)+"\n"
    if sys.argv[1:]==["--seal"]:
        save("seal.json",payload)
    else:
        assert sys.argv[1:]==[] and (ROOT/"seal.json").read_bytes()==payload.encode()
    print("verified",len(required),"files,",sum(expected_rows.values()),"CSV data rows. seal:",digest(ROOT/"seal.json"))

if __name__=="__main__":
    verify()
