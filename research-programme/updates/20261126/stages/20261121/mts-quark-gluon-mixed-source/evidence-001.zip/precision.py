from direct import *

def read_coarse(case, angular, step):
    with (ROOT/f"direct-{case}.csv").open() as handle:
        row, = [row for row in csv.DictReader(handle) if int(row["n"])==angular and row["step"]==str(step)]
    return complex(float(row["real"]),float(row["imag"]))

def rich(large,small,power):
    return small+(small-large)/(2**power-1)

def main():
    for case,history in enumerate(histories()):
        action=CoordinateAction(history)
        rows=[]
        for angular in range(4):
            samples=[read_coarse(case,angular,diff) for diff in (.02,.01)]
            samples += [source_diff(action,angular,diff) for diff in (.005,.0025)]
            order4=[rich(left,right,2) for left,right in zip(samples,samples[1:])]
            order6=[rich(left,right,4) for left,right in zip(order4,order4[1:])]
            for label,value in zip(("0.005","0.0025","fourth_middle","fourth_fine","sixth_middle","sixth_fine"),
                                   samples[-2:]+order4[-2:]+order6):
                rows.append(dict(configuration=case,n=angular,step=label,**fields(value)))
        table(f"precision-{case}.csv",rows)
        print(f"refined direct history {case+1}/3",flush=True)

if __name__=="__main__":
    main()
