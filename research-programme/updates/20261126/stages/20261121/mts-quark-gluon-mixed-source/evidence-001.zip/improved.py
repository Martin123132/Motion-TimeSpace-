from fixture import *
import sympy as sp

def run():
    variable,alpha=sp.symbols("u alpha")
    raw=json.loads((PARENT/"frozen-projectors.json").read_bytes())["projectors"]
    rows=[]
    for bank,details in enumerate(raw,1):
        modes=details["indices"]
        weights=list(map(sp.Rational,details["weights"]))
        moments=[sum(weight*mode**power for weight,mode in zip(weights,modes)) for power in (0,2,4)]
        assert moments==[-sp.Rational(1,16),-sp.Rational(1,16),-sp.Rational(5,16)]
        def source(mode):
            return 2*((1-alpha+alpha*variable)*(1-variable)-1+sp.chebyshevt(mode,variable))
        contracted=sp.expand(sum(weight*source(mode) for weight,mode in zip(weights,modes)))
        slope=sp.diff(contracted,variable,2).subs(variable,1)/8
        assert sp.simplify(slope-(3*alpha-2)/96)==0
        choice,=sp.solve(slope,alpha)
        improved=sp.factor(contracted.subs(alpha,choice))
        expected=0 if bank==1 else (1-variable)**3/20
        assert sp.simplify(improved-expected)==0
        for extent in (10,18,26,40,64):
            clock,space=np.indices((extent,extent))
            unit=2*np.pi/extent
            shear=np.exp(2j*unit*clock)
            measured=0j
            for mode,weight in zip(modes,weights):
                fields=[np.exp(1j*unit*(-clock+sign*mode*space)) for sign in (1,-1)]
                for axis in (0,1):
                    slope1,slope2=(np.roll(field,-1,axis=axis)-field for field in fields)
                    corners=(shear+np.roll(shear,-1,axis=axis))/2
                    midpoint=np.exp(2j*unit*(clock+.5*(axis==0)))
                    effective=(2*corners+midpoint)/3
                    measured-=float(weight)*np.mean(effective*slope1*slope2)/unit**4
            predicted=0. if bank==1 else (1-np.cos(unit))**3/(20*unit**4)
            assert abs(measured-predicted)<1e-12
            rows.append(dict(bank=bank,N=extent,corner_fraction=str(choice),direct_real=measured.real,
                             predicted=predicted,absolute_error=abs(measured-predicted)))
    table("improved-maxwell.csv",rows)
    print("analytic action improvement: first bank exactly null for all momenta; second leaves (1-cos(eps))^3/20 before division.")
if __name__=="__main__":
    run()
