from fixture import *
from itertools import product
from scipy.sparse import bsr_matrix
from scipy.sparse.linalg import splu


COORD = np.array([(tt,xx) for tt in TIME for xx in TIME])
SITE = np.arange(64)
CLOCK, SPACE = COORD.T
AHEAD = np.array([((CLOCK+1)%8)*8+SPACE,CLOCK*8+(SPACE+1)%8,SITE,SITE])
BACK = np.argsort(AHEAD,axis=1)
NEIGH = np.array([SITE,AHEAD[0],BACK[0],AHEAD[1],BACK[1]]).T
SORT = np.argsort(NEIGH,axis=1)
COLS = np.take_along_axis(NEIGH,SORT,axis=1).astype(np.int32).ravel()
PTR = np.arange(0,321,5,dtype=np.int32)
DIAG = np.eye(12)
SPIN = np.array([np.kron(mat,np.eye(3)) for mat in GAMMA])

def parity(perm):
    reached = set()
    cycles = 0
    for origin in range(len(perm)):
        if origin not in reached:
            cycles += 1
            slot = origin
            while slot not in reached:
                reached.add(slot)
                slot=perm[slot]
    return (len(perm)-cycles)%2

def logdet(blocks):
    matrix = bsr_matrix((blocks[SITE[:,None],SORT].reshape(-1,12,12),COLS,PTR),shape=(768,768)).tocsc()
    matrix.eliminate_zeros()
    lu = splu(matrix)
    diagonal = lu.U.diagonal()
    angle = np.angle(diagonal).sum()+np.pi*(parity(lu.perm_r)+parity(lu.perm_c))
    return np.log(abs(diagonal)).sum()+1j*np.angle(np.exp(1j*angle))

class CoordinateAction:
    def __init__(self,history):
        self.links = history[CLOCK]
        self.spincolor = np.empty((64,4,12,12),complex)
        for slot in SITE:
            for axis in range(4):
                self.spincolor[slot,axis]=np.kron(np.eye(4),self.links[slot,axis])
        self.faces = []
        for axis in range(4):
            for other in range(axis+1,4):
                loop = (self.links[:,axis]@self.links[AHEAD[axis],other]@
                        self.links[AHEAD[other],axis].conj().swapaxes(-1,-2)@
                        self.links[:,other].conj().swapaxes(-1,-2))
                self.faces.append((axis,other,1-np.trace(loop,axis1=1,axis2=2).real/3))
        self.zero = self.logs(np.zeros(64),np.zeros((64,4)))
    def logs(self,height,photon):
        raised = np.exp(height[:,None]*np.array(ETA))
        frames = np.exp(height[:,None]*np.array(ETA)/2)
        operators = []
        for mass,charge in FLAVORS:
            forward = []
            backward = []
            for axis in range(4):
                hop = self.spincolor[:,axis]
                ap = np.where((axis==0)&(CLOCK==7),-1.,1.)
                phase = np.exp(1j*charge*photon[:,axis])
                central = -raised[:,axis,None,None]*hop
                skew = frames[:,axis,None,None]*(SPIN[axis]@hop)
                plus = .5*(central+skew)*(ap*phase)[:,None,None]
                adjoint = hop.conj().swapaxes(-1,-2)
                minus = -.5*(raised[:,axis,None,None]*adjoint+frames[:,axis,None,None]*(SPIN[axis]@adjoint))*(ap/phase)[:,None,None]
                forward.append(plus)
                backward.append(minus[BACK[axis]])
            total = 0j
            blocks = np.empty((64,5,12,12),complex)
            blocks[:,1:]=np.stack((forward[0],backward[0],forward[1],backward[1]),axis=1)
            diag = (mass+raised.sum(axis=1))[:,None,None]*DIAG
            for sy,sz in product((1,-1),repeat=2):
                blocks[:,0]=diag+sy*(forward[2]+backward[2])+sz*(forward[3]+backward[3])
                total += logdet(blocks)
            operators.append(total)
        glue = 0j
        for axis,other,density in self.faces:
            face = (height+height[AHEAD[axis]]+height[AHEAD[other]]+height[AHEAD[other][AHEAD[axis]]])/4
            glue += 4*BETA*np.dot(density,np.exp((ETA[axis]+ETA[other])*face))
        return np.array([glue,*operators])
    def ratio(self,height,photon):
        gauge,up,down = self.logs(height,photon)-self.zero
        return np.exp(-gauge+up+down)

def patterns(angular):
    height = np.exp(1j*2*EPS*CLOCK)
    first = np.exp(1j*EPS*(-CLOCK+angular*SPACE))
    second = np.exp(1j*EPS*(-CLOCK-angular*SPACE))
    return height,first,second

def source_diff(action,angular,step):
    height,first,second = patterns(angular)
    total = 0j
    photon = np.zeros((64,4),complex)
    for hh,aa,bb in product((-1,1),repeat=3):
        photon[:,2]=step*(aa*first+bb*second)
        total += hh*aa*bb*action.ratio(step*hh*height,photon)
    return -total/(VOL*8*step**3)

def main():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("case",type=int,choices=range(3))
    args = parser.parse_args()
    action = CoordinateAction(histories()[args.case])
    results = []
    for angular in range(4):
        values = [source_diff(action,angular,step) for step in (.02,.01)]
        final = (4*values[1]-values[0])/3
        for tag,val in zip(("0.02","0.01","extrapolated"),[*values,final]):
            results.append(dict(configuration=args.case,n=angular,step=tag,**fields(val)))
        print(f"direct history {args.case} mode {angular} {final}",flush=True)
    table(f"direct-{args.case}.csv",results)

if __name__=="__main__":
    main()
