import os
for variable in ("OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "OMP_NUM_THREADS", "NUMEXPR_NUM_THREADS"):
    os.environ[variable] = "1"

import csv
import hashlib
import io
import json
from fractions import Fraction
from pathlib import Path

import numpy as np
from scipy.linalg import expm

ROOT = Path(__file__).resolve().parent
PARENT = ROOT.parent / "mts-mixed-current-weyl-extractor-20261121"
EPS = np.pi / 4
VOL = 8 * 8 * 2 * 2
BETA = .62
WEIGHTS = np.array([.2, .3, .5])
FLAVORS = ((.55, 2/3), (.9, -1/3))
ETA = (0, 0, -1, 1)
IDENT = np.eye(12)
TIME = np.arange(8)
MOM = np.array([(xx, yy, zz) for xx in range(8) for yy in range(2) for zz in range(2)])
PAULI = (np.array([[0,1],[1,0]]), np.array([[0,-1j],[1j,0]]), np.diag([1,-1]))
GAMMA = [np.kron(PAULI[0], mat) for mat in PAULI] + [np.kron(PAULI[1], np.eye(2))]
assert all(np.allclose(left @ right + right @ left, 2 * (ii == jj) * np.eye(4))
           for ii,left in enumerate(GAMMA) for jj,right in enumerate(GAMMA))

def saved_banks():
    raw = (PARENT / "frozen-projectors.json").read_bytes()
    assert hashlib.sha256(raw).hexdigest() == "acb38f7efd7966cf34d52beebd7449837d3731219bb196504d91881c9eff78db"
    return [(row["indices"], [float(Fraction(item)) for item in row["weights"]])
            for row in json.loads(raw)["projectors"]]

def histories():
    results = []
    for seed, scale in [(861,.24), (117,.37), (302,.48)]:
        rng = np.random.default_rng(seed)
        def generator():
            raw = rng.normal(size=(3,3)) + 1j*rng.normal(size=(3,3))
            herm = (raw + raw.conj().T)/2
            return herm - np.trace(herm)*np.eye(3)/3
        data = np.empty((8,4,3,3),complex)
        for axis in range(4):
            const, cosine, sine, extra = [generator() for _ in range(4)]
            for slot in TIME:
                angle = EPS * slot
                field = const + .6*cosine*np.cos(angle) + .5*sine*np.sin(angle) + .4*extra*np.cos(2*angle+.4)
                data[slot,axis] = expm(1j*scale*field)
        assert np.max(abs(data @ data.conj().swapaxes(-2,-1)-np.eye(3))) < 3e-14
        assert np.max(abs(np.linalg.det(data)-1)) < 3e-14
        assert np.max(abs(data[:,2]@data[:,3]-data[:,3]@data[:,2])) > .1
        results.append(data)
    return results

def plaquettes(links):
    for first in range(4):
        for second in range(first+1,4):
            ahead1 = np.roll(links[:,second], -int(first==0), axis=0)
            ahead2 = np.roll(links[:,first], -int(second==0), axis=0)
            loop = links[:,first] @ ahead1 @ ahead2.conj().swapaxes(1,2) @ links[:,second].conj().swapaxes(1,2)
            yield first, second, 1-np.trace(loop,axis1=1,axis2=2).real/3

def table(name, rows):
    stream = io.StringIO(newline="")
    writer = csv.DictWriter(stream,fieldnames=list(rows[0]),lineterminator="\n")
    writer.writeheader()
    writer.writerows(rows)
    return save(name,stream.getvalue())

def save(name, content):
    target = ROOT/name
    encoded = content.encode("utf-8")
    if target.exists():
        assert target.read_bytes()==encoded, f"Changed on replay: {name}"
    else:
        with target.open("xb") as out:
            out.write(encoded)

def fields(value):
    return {"real":float(np.real(value)),"imag":float(np.imag(value))}
