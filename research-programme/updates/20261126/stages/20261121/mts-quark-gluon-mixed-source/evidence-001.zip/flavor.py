from fixture import *
from itertools import product
from scipy.sparse import coo_matrix


SHAPE=(5,3,2,2)
COUNT=int(np.prod(SHAPE))
COORD=np.array(list(product(*(range(extent) for extent in SHAPE))))
SITE=np.arange(COUNT)
AHEAD=[]
for axis in range(4):
    step=COORD.copy()
    step[:,axis]=(step[:,axis]+1)%SHAPE[axis]
    AHEAD.append(np.ravel_multi_index(step.T,SHAPE))

def color_field():
    rng=np.random.default_rng(71941)
    data=np.empty((COUNT,4,3,3),complex)
    for site in SITE:
        for axis in range(4):
            trial=rng.normal(size=(3,3))+1j*rng.normal(size=(3,3))
            herm=(trial+trial.conj().T)*.24
            data[site,axis]=expm(1j*(herm-np.trace(herm)*np.eye(3)/3))
    return data

def source_matrices(data):
    clock,space=COORD[:,:2].T
    shear=np.exp(4j*np.pi*clock/5)
    first=np.exp(2j*np.pi*(-clock/5+space/3))
    second=np.exp(2j*np.pi*(-clock/5-space/3))
    wave=(shear,first,second)
    operators={}
    for mask in (0,1,2,4,3,5,6):
        row_ids,col_ids,entries=[],[],[]
        def add(rows,cols,block):
            row_ids.append(np.broadcast_to(rows[:,None,None]*12+np.arange(12)[None,:,None],block.shape).ravel())
            col_ids.append(np.broadcast_to(cols[:,None,None]*12+np.arange(12)[None,None,:],block.shape).ravel())
            entries.append(block.ravel())
        for axis in range(4):
            if mask&6 and axis!=2:
                continue
            profile=np.ones(COUNT,complex)
            for index,field in enumerate(wave):
                if mask & 1<<index:
                    profile*=field
            wilson,frame=(ETA[axis],ETA[axis]/2) if mask&1 else (1,1)
            if not mask&6:
                add(SITE,SITE,(wilson*profile)[:,None,None]*IDENT)
            ap=np.where((axis==0)&(clock==4),-1.,1.)
            for sign in (1,-1):
                link=data[:,axis] if sign==1 else data[:,axis].conj().swapaxes(1,2)
                spin=(-wilson*np.eye(4)+sign*frame*GAMMA[axis])/2
                block=np.einsum("ij,sab->siajb",spin,link).reshape(COUNT,12,12)
                coeff=(sign*1j)**((mask&6).bit_count())*profile*ap
                source,dest=(SITE,AHEAD[axis]) if sign==1 else (AHEAD[axis],SITE)
                add(source,dest,coeff[:,None,None]*block)
        operators[mask]=coo_matrix((np.concatenate(entries),(np.concatenate(row_ids),np.concatenate(col_ids))),
                                    shape=(12*COUNT,12*COUNT)).tocsr()
        operators[mask].eliminate_zeros()
    glue=0j
    for axis in range(4):
        for other in range(axis+1,4):
            loop=data[:,axis]@data[AHEAD[axis],other]@data[AHEAD[other],axis].conj().swapaxes(1,2)@data[:,other].conj().swapaxes(1,2)
            avg=(shear+shear[AHEAD[axis]]+shear[AHEAD[other]]+shear[AHEAD[other][AHEAD[axis]]])/4
            glue+=BETA*(ETA[axis]+ETA[other])*np.dot(1-np.trace(loop,axis1=1,axis2=2).real/3,avg)
    return operators,glue

def contraction(left,right):
    return np.einsum("ij,ji->",left,right)

def jets(inverse,vertices):
    dressed={mask:inverse@vertices[mask] for mask in (1,2,4,3,5,6)}
    singles=np.array([-np.trace(dressed[bit]) for bit in (2,4)])
    pairs=np.array([-np.trace(dressed[1|bit])+contraction(dressed[1],dressed[bit]) for bit in (2,4)])
    return singles,pairs,-np.trace(dressed[1]),-np.trace(dressed[6])+contraction(dressed[2],dressed[4])

def difference_stripped(light,strange,vertices):
    common=light@strange
    shear_strange=strange@vertices[1]
    shear_common=common@vertices[1]
    single=[]
    mixed=[]
    for bit in (2,4):
        current=common@vertices[bit]
        single.append(-np.trace(current))
        mixed.append(-np.trace(common@vertices[1|bit])+contraction(shear_common,light@vertices[bit])
                     +contraction(shear_strange,current))
    return np.array(single),np.array(mixed)

def double_loop(singles,mixed,stress):
    return (-np.dot(singles,mixed[::-1])+stress*singles.prod())/COUNT

def run():
    matrices,gauge=source_matrices(color_field())
    massless=matrices[0].toarray()
    identity=np.eye(massless.shape[0])
    light=np.linalg.inv(massless+.55*identity)
    light_j,light_b,light_h,light_jj=jets(light,matrices)
    rows=[]
    for delta in (0.,.32,.16,.08,.04,.02,.01,.005):
        strange=np.linalg.inv(massless+(.55+delta)*identity)
        strange_j,strange_b,strange_h,strange_jj=jets(strange,matrices)
        numerator_j,numerator_b=difference_stripped(light,strange,matrices)
        direct_j=sum(charge*entry for charge,entry in zip((2/3,-1/3,-1/3),(light_j,light_j,strange_j)))
        direct_b=sum(charge*entry for charge,entry in zip((2/3,-1/3,-1/3),(light_b,light_b,strange_b)))
        stress=gauge+2*light_h+strange_h
        err=max(np.max(abs(direct_j-delta*numerator_j/3)),np.max(abs(direct_b-delta*numerator_b/3)))
        assert err<1e-12
        reduced=double_loop(numerator_j,numerator_b,stress)/9
        direct=double_loop(direct_j,direct_b,stress)
        still_present=-stress*(5*light_jj+strange_jj)/(9*COUNT)
        assert abs(direct-delta**2*reduced)<1e-14
        if delta==0:
            assert max(abs(direct_j))+max(abs(direct_b))<1e-14 and abs(still_present)>1e-7
            leading=reduced
            assert abs(leading)>1e-8 and min(abs(numerator_j))>1e-5
        rows.append(dict(delta_mass=delta,direct_real=direct.real,direct_imag=direct.imag,
                         stripped_real=reduced.real,stripped_imag=reduced.imag,
                         leading_fractional_error=abs(reduced/leading-1),max_source_error=err,
                         same_loop_stress_abs=abs(still_present)))
    assert rows[-1]["leading_fractional_error"] < rows[-2]["leading_fractional_error"] < rows[-3]["leading_fractional_error"]
    table("three-flavor-difference.csv",rows)
    print("nonuniform 4D flavor and stress checks", rows[0], rows[-1],flush=True)

if __name__=="__main__":
    run()
