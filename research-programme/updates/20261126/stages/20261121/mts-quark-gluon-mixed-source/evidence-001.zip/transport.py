from direct import *
from response import Fermion,terms,gauge_stress
from check import read,value,extrapolate

def delta_gluon(links):
    height=np.exp(2j*EPS*TIME)
    total=0j
    for first,second,density in plaquettes(links):
        if first==0:
            midpoint=np.exp(2j*EPS*(TIME+.5))
            total+=32*BETA*ETA[second]*np.dot(density,(midpoint-(height+np.roll(height,-1))/2)/3)
    return total

def direct_change(action,angular,step):
    height,first,second=patterns(angular)
    total=0j
    photon=np.zeros((64,4),complex)
    for hh,aa,bb in product((-1,1),repeat=3):
        shear=step*hh*height
        photon[:,2]=step*(aa*first+bb*second)
        offset=0j
        for axis,other,density in action.faces:
            if axis!=0 or ETA[other]==0:
                continue
            corners=(shear+shear[AHEAD[0]])/2
            mid=step*hh*np.exp(2j*EPS*(CLOCK+.5))
            diff=(mid-corners)/3
            offset+=4*BETA*np.dot(density,np.exp(ETA[other]*corners)*np.expm1(ETA[other]*diff))
        total+=hh*aa*bb*action.ratio(shear,photon)*np.expm1(-offset)
    return -total/(VOL*8*step**3)

def main():
    rows=[]
    total_changes=np.zeros(4,complex)
    direct_totals=np.zeros(4,complex)
    for case,links in enumerate(histories()):
        test=CoordinateAction(links)
        sources=[Fermion(links,*flavor) for flavor in FLAVORS]
        if case==0:
            uncharged=[Fermion(links,FLAVORS[0][0],0.)]
            neutral=terms(uncharged,gauge_stress(links),((2,0,"h"),(-1,1,"A"),(-1,-1,"A")))
            assert max(abs(item) for item in neutral.values())<1e-14
        correction=delta_gluon(links)
        for angular in range(4):
            waves=((2,0,"h"),(-1,angular,"A"),(-1,-angular,"A"))
            jets=[fermion.measure(waves) for fermion in sources]
            singles,pairs,_=(sum(items) for items in zip(*jets))
            covariance=-correction*pairs[0]/VOL
            cumulant=correction*singles[1]*singles[2]/VOL
            predicted=covariance+cumulant
            measured=extrapolate([direct_change(test,angular,step) for step in (.01,.005,.0025)])
            error=abs(predicted-measured)
            assert error<2e-7
            total_changes[angular]+=WEIGHTS[case]*predicted
            direct_totals[angular]+=WEIGHTS[case]*measured
            rows.append(dict(configuration=case,n=angular,delta_real=predicted.real,delta_imag=predicted.imag,
                             covariance_abs=abs(covariance),third_cumulant_abs=abs(cumulant),direct_error=error))
        print("checked changed stress on history",case,flush=True)
    table("changed-gluon-stress.csv",rows)
    original=np.array([value(row) for row in read("analytic-modes.csv")])
    banks=[]
    for bank,(indices,weights) in enumerate(saved_banks(),1):
        def project(vector):
            return np.dot(weights,vector[indices])/EPS**4
        before,delta=project(original),project(total_changes)
        assert abs(delta-project(direct_totals))<2e-7
        banks.append(dict(bank=bank,before_real=before.real,before_imag=before.imag,
                          corrected_real=(before+delta).real,corrected_imag=(before+delta).imag,
                          delta_abs=abs(delta),direct_error=abs(delta-project(direct_totals))))
    table("changed-gluon-banks.csv",banks)

if __name__=="__main__":
    main()
