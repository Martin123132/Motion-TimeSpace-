from fixture import *
from collections import defaultdict

def read(name):
    with (ROOT/name).open(encoding="utf-8",newline="") as handle:
        return list(csv.DictReader(handle))

def value(row):
    return complex(float(row["real"]),float(row["imag"]))

def extrapolate(samples):
    fourth=[(4*b-a)/3 for a,b in zip(samples,samples[1:])]
    return (16*fourth[1]-fourth[0])/15

def main():
    if not __debug__:
        raise RuntimeError("Run with assertions enabled.")
    assert hashlib.sha256((PARENT/"seal.json").read_bytes()).hexdigest()=="de33739c4e144efceef1b1151c9289f7166ccd8779a4c768fb2d195117994a1b"
    components=defaultdict(dict)
    for row in read("trace-decomposition.csv"):
        parts=components[int(row["configuration"]),int(row["n"])]
        assert row["term"] not in parts
        parts[row["term"]]=value(row)
    measured={int(row["n"]):value(row) for row in read("analytic-modes.csv")}
    assert len(components)==12 and all(len(parts)==7 for parts in components.values())
    direct_totals=defaultdict(complex)
    differences=[]
    coarse=[]
    verified=[]
    for case in range(3):
        old={(int(row["n"]),row["step"]):value(row) for row in read(f"direct-{case}.csv")}
        recent={(int(row["n"]),row["step"]):value(row) for row in read(f"precision-{case}.csv")}
        for angular in range(4):
            exact=sum(components[case,angular].values())
            original=old[angular,"extrapolated"]
            fine=recent[angular,"sixth_fine"]
            middle=recent[angular,"sixth_middle"]
            difference=abs(fine-exact)
            assert max(difference,abs(middle-exact),abs(middle-fine))<2e-7
            coarse.append(abs(original-exact))
            differences.append(difference)
            direct_totals[angular]+=WEIGHTS[case]*fine
            verified.append(dict(configuration=case,n=angular,coarse_error=coarse[-1],middle_error=abs(middle-exact),
                                 fine_error=difference,refined_difference=abs(middle-fine)))
    table("direct-agreement.csv",verified)
    banks=[]
    for bank,(indices,weights) in enumerate(saved_banks(),1):
        def project(data):
            return sum(weight*data[idx] for idx,weight in zip(indices,weights))/EPS**4
        full=project(measured)
        direct=project(direct_totals)
        def subset(labels):
            return {idx:sum(WEIGHTS[case]*sum(components[case,idx][key] for key in labels)
                            for case in range(3)) for idx in indices}
        only_triangle=project(subset(["triangle"]))
        no_measure=project(subset(["triangle","double_contact","triple_contact"]))
        assert abs(full-direct)<2e-7 and abs(full-no_measure)>1e-4 and abs(full-only_triangle)>1e-4
        banks.append(dict(bank=bank,real=full.real,imag=full.imag,direct_error=abs(full-direct),
                          omit_measure_error=abs(full-no_measure),triangle_only_error=abs(full-only_triangle)))
    table("weighted-readouts.csv",banks)
    controls=read("ward-bose.csv")
    ward=max(float(row["ward_abs"]) for row in controls)
    bose=max(float(row["bose_abs"]) for row in controls)
    assert len(controls)==12 and max(ward,bose)<2e-10
    orbit=read("real-partition.csv")
    reals={}
    for wave,component in (("cos",measured[0].real),("sin",measured[0].imag)):
        values=[float(row["real_derivative"]) for row in orbit if row["shear"]==wave]
        residual=abs(4*extrapolate(values)-component)
        assert residual<2e-7
        reals[wave]=residual
    finite=read("finite-gauge.csv")[0]
    assert all(float(item)<2e-10 for item in finite.values())
    flavors=read("three-flavor-difference.csv")
    assert len(flavors)==8 and max(float(row["max_source_error"]) for row in flavors)<1e-12
    assert float(flavors[0]["same_loop_stress_abs"])>0.01 and abs(complex(float(flavors[0]["direct_real"]),float(flavors[0]["direct_imag"])))<1e-14
    leakage=read("maxwell-leakage.csv")
    assert len(leakage)==20 and all(abs(float(row["injected_recovered"])+.037)<1e-11 for row in leakage)
    summary=dict(fine_max_abs=max(differences),coarse_max_abs=max(coarse),coarse_failed=sum(diff>=2e-7 for diff in coarse),
                 banks=banks,ward_abs=ward,bose_abs=bose,finite_logdet=finite,explicit_measure_abs=reals,
                 maximum_flavor_error=max(float(row["max_source_error"]) for row in flavors))
    contents=json.dumps(summary,indent=2,allow_nan=False)+"\n"
    save("summary.json",contents)
    print(contents)

if __name__=="__main__":
    main()
