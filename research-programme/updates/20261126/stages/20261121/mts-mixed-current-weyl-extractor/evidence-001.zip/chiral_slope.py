"""Conditional light-mass prediction; no quark ensemble or measured mass extrapolation."""
from base import table,save
from charged_scalar import gram, integrate
from vertices import weights
import numpy as np
import sympy as sy

def run():
    label=sy.symbols("j",integer=True)
    first=sy.symbols("u",positive=True)
    slope=sy.symbols("b0:3")
    inv_mass=sy.symbols("A")
    mass2=first*2**label
    model=inv_mass/mass2+slope[0]+slope[1]*sy.log(mass2)+slope[2]*sy.log(mass2)**2
    stencil=[8,-24,24,-8]
    expected=sy.expand_log(first*sum(weight*model.subs(label,index) for index,weight in enumerate(stencil)),force=True).expand()
    assert sy.simplify(expected-inv_mass)==0
    for degree in range(3):
        assert sum(weight*index**degree for index,weight in enumerate(stencil))==0
    assert sum(sy.Rational(weight,2**idx) for idx,weight in enumerate(stencil))==1
    rows=[]
    for indices in ((0,1,2),(1,2,3)):
        bank=weights(indices)
        for ratio in (.25,.125,.0625,.03125):
            values=[]
            for idx in range(4):
                mass=2**(idx/2)
                val=sum(float(w)*integrate(*gram(node),ratio*mass,mass,1.,32)[0] for node,w in zip(indices,bank))
                values.append(val)
            free=float(np.dot(stencil,values))
            additive=np.array([.031-.019*np.log(2**idx)+.077*np.log(2**idx)**2 for idx in range(4)])
            amended=float(np.dot(stencil,np.asarray(values)+additive))
            assert abs(amended-free)<2e-14 and abs(free-values[0])<2e-14
            rows.append(dict(bank="-".join(map(str,indices)),eps_over_mass=ratio,free_mass_stencil=free,
                             injected_log_quadratic_stencil=amended,zero_momentum_target=1/180))
    table("chiral-stencil-controls.csv",rows)
    save("chiral-design.json",dict(mass_squared_ratios=[1,2,4,8],weights_times_lightest_mass_squared=stencil,
        independent_equal_error_norm=float(np.linalg.norm(stencil)),worst_correlated_absolute_amplification=sum(map(abs,stencil)),
        normalized_prediction="1/180 in (-log Z) full-index positive-sphere curvature, per (e_u-e_d)^2/(4 pi)^2",
        physical_QCD_ensembles_tested=0,local_mass_independent_intercept_determined=False))
if __name__=="__main__":
    run()
