"""Sign bridge for static spatial probes and the previously used physical screen labels."""
import json
import math
import subprocess
import sys
from base import HERE,ROOT,PREVIOUS,INTAKE,sha,table,save
import numpy as np

def run():
    optics=ROOT/"mts-finite-tidal-exposure-20261121"
    original=json.loads(subprocess.check_output([sys.executable,"-B","-c",
        "import json;from optics import curvature;print(json.dumps(curvature([1.,0.,0.]).tolist()))"],
        text=True,cwd=optics,timeout=30))
    tensor=np.asarray(original)
    assert np.array_equal(tensor[0,1:,0,1:],np.diag([-2.,1.,1.]))
    ray=np.array([1.,0.,0.,1.]);screen=np.eye(4)[1:3]
    projections=np.einsum("a,ib,c,jd,abcd->ij",ray,screen,ray,screen,tensor)
    assert np.array_equal(projections,np.diag([-3.,3.]))
    assert 4*(projections[1,1]-projections[0,0])==24
    rows=[]
    for hank in (-2.,3.):
        for factor in (1.,-1.):
            metric=np.diag([factor,1.,1.,1.])
            fluct=np.diag([0.,0.,hank,-hank])
            momentum=np.array([0.,2.,0.,0.])
            tensor1=np.zeros((4,)*4)
            for aa,bb,cc,dd in np.ndindex(tensor1.shape):
                tensor1[aa,bb,cc,dd]=(momentum[aa]*momentum[cc]*fluct[bb,dd]+momentum[bb]*momentum[dd]*fluct[aa,cc]
                    -momentum[bb]*momentum[cc]*fluct[aa,dd]-momentum[aa]*momentum[dd]*fluct[bb,cc])/2
            ric=np.einsum("ac,abcd->bd",metric,tensor1)
            scalar=np.sum(ric*metric)
            field=np.zeros((4,4));field[1,2]=1.;field[2,1]=-1.
            values=(np.einsum("abcd,ab,cd",tensor1,field,field)-
                    2*np.einsum("ac,ab,cb",ric,field,field)+scalar/3*np.sum(field**2))
            assert values==4*hank
            rows.append(dict(metric="positive_euclidean" if factor==1 else "mostly_plus_lorentz",h22=hank,magnetic_CFF=values))
    table("static-wick-check.csv",rows)
    with (INTAKE/"4944"/"visible_CFF_matching_components.csv").open(encoding="utf8",newline="") as stream:
        import csv
        old={row["component_id"]:row for row in csv.DictReader(stream)}
    optical=next(row for row in __import__("csv").DictReader((PREVIOUS/"conjunction-transfer.csv").read_text().splitlines())
                 if row["geometry"].endswith("central") and row["receiver"]=="infinity")
    slope=float(optical["corrected_s_per_m2"])
    lepton=abs(float(old["CFF4944_01_free_leptons"]["coefficient_or_bound_m2"]))
    small=abs(float(old["CFF4944_02_W_spin1"]["coefficient_or_bound_m2"]))+abs(float(old["CFF4944_00_parent"]["coefficient_or_bound_m2"]))
    save("signed-transport.json",dict(euclidean_scalar_times_prefactor="1/180",euclidean_spinor_times_prefactor="-1/90",
         lorentz_scalar_times_prefactor="-1/180",lorentz_spinor_times_prefactor="1/90",
         ray_label="t_perpendicular_minus_t_in_plane, static observer infinity; positive Lorentz action coefficient gives positive K",
         electric_weyl=tensor[0,1:,0,1:].diagonal().tolist(),null_screen=projections.diagonal().tolist(),
         legacy_lepton_register_sign="negative; separate curvature-basis convention",
         retained_K_s_per_m2=slope,known_nonQCD_lag_interval_s_in_this_label=[slope*(lepton-small),slope*(lepton+small)],
         total_QCD_term_fixed=False,unresolved_split_magnitude_affected=False))
if __name__=="__main__":
    run()
