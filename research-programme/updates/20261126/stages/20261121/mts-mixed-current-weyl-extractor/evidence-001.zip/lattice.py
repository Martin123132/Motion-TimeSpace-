"""Exact discrete Fourier sums of source derivatives of a periodic scalar link action."""
import argparse
import json
import math
from fractions import Fraction
from base import HERE,guard,table,save,sha
import numpy as np
from scipy.linalg import cholesky
from charged_scalar import integrate,gram

def modes(size):
    freq=2*np.pi*np.arange(size)/size
    sym=freq[:size//2+1]
    weight=np.full(len(sym),2.);weight[[0,-1]]=1.
    return freq,sym,weight

def bank(size,mass,index,mode):
    guard()
    full,unique,weight=modes(size)
    cosine=np.cos(unique);spectator=4*np.sin(unique/2)**2
    double_weight=weight[:,None]*weight[None,:]
    base=mass**2+spectator[:,None]+spectator[None,:]
    bare=4*np.sin(full/2)**2
    stress=-spectator[:,None]+spectator[None,:]
    photon2=4*np.sin(unique[:,None])**2
    seagull=2*cosine[:,None]
    parts=np.zeros(4)
    xindex=np.arange(size)
    shift=index*mode
    for time in range(size):
        if time%32==0:
            guard()
        def green(time_shift,space_shift):
            momentum=bare[(time+time_shift)%size]+bare[(xindex+space_shift)%size]
            return 1/(momentum[:,None,None]+base[None,:,:])
        origin=green(0,0)*double_weight
        plus=green(-mode,shift)
        other=green(-mode,-shift)
        minus_other=green(mode,shift)
        metric=green(2*mode,0)
        parts[0]+=np.sum(origin*(-seagull))
        parts[1]+=np.sum(origin*photon2*(plus+other))
        parts[2]+=np.sum(origin*(-stress*seagull)*metric)
        parts[3]+=np.sum(origin*(2*stress*photon2)*plus*minus_other)
    return parts/size**4

def direct(size,mass,index,delta):
    full=2*np.pi*np.arange(size)/size
    time,space=np.meshgrid(full,full,indexing="ij")
    profile=np.cos(2*time).ravel()
    left=np.cos(-time+index*space).ravel()
    right=np.cos(-time-index*space).ravel()
    adjacency=np.zeros((size**2,size**2))
    labels=np.arange(size**2).reshape(size,size)
    for axis in (0,1):
        for step in (-1,1):
            adjacency[labels.ravel(),np.roll(labels,step,axis=axis).ravel()]-=1.
    diagonal=np.diag_indices(size**2)
    def functional(metric_sign,first_sign,second_sign):
        met=metric_sign*delta*profile;potential=delta*(first_sign*left+second_sign*right)
        numer=[]
        for yfreq in full:
            for zindex in range(size//2+1):
                mat=adjacency.copy()
                mat[diagonal]=4+mass**2+4*np.exp(-met)*np.sin((yfreq+potential)/2)**2+4*np.exp(met)*np.sin(full[zindex]/2)**2
                factor=cholesky(mat,lower=True,check_finite=False,overwrite_a=True)
                weight=1 if zindex in (0,size//2) else 2
                numer.append(2*weight*sum(np.log(factor.diagonal())))
        return math.fsum(numer)/size**4
    stencil=[first*second*third*functional(first,second,third) for first in (-1,1) for second in (-1,1) for third in (-1,1)]
    return 4*math.fsum(stencil)/(8*delta**3)

def control():
    rows=[]
    for index in (0,1,2,3):
        pieces=bank(8,.8,index,1)
        low=direct(8,.8,index,.04)
        high=direct(8,.8,index,.02)
        coarse_rich=(4*high-low)/3
        finest=direct(8,.8,index,.01)
        rich=(4*finest-high)/3
        assert abs(rich-pieces.sum())<2e-8,(index,rich,pieces.sum())
        rows.append(dict(index=index,exact=pieces.sum(),stencil_low=low,stencil_high=high,stencil_finest=finest,
                         coarse_rich_error=coarse_rich-pieces.sum(),extrapolated=rich,error=rich-pieces.sum()))
    table("direct-logdet.csv",rows)

def run(size,mass,mode):
    eps=2*np.pi*mode/size
    rows=[];summary=[]
    for index in range(4):
        parts=bank(size,mass,index,mode)
        rows.append(dict(index=index,tadpole=parts[0],mixed_photon=parts[1],stress_seagull=parts[2],triangle=parts[3],total=math.fsum(parts)))
    for frozen in json.loads((HERE/"frozen-projectors.json").read_bytes())["projectors"]:
        indices=frozen["indices"];weights=list(map(Fraction,frozen["weights"]))
        raw=sum(float(weight)*rows[index]["total"] for weight,index in zip(weights,indices))
        matched=sum(float(weight)*integrate(*gram(index),eps/mass,1.,1.,32)[0] for weight,index in zip(weights,indices))
        lattice=raw*mass**2*(4*np.pi)**2/eps**4
        summary.append(dict(bank="-".join(map(str,indices)),size=size,am=mass,mL=mass*size,mode=mode,eps_over_m=eps/mass,
                            normalized_coefficient=lattice,continuum_same_momentum=matched,relative_to_matched=lattice/matched-1))
    label=f"{size}-am{mass:.6f}-n{mode}"
    table(f"lattice-terms-{label}.csv",rows);table(f"lattice-readout-{label}.csv",summary)
    print(label,[(row["bank"],row["relative_to_matched"]) for row in summary],flush=True)

if __name__=="__main__":
    parser=argparse.ArgumentParser()
    parser.add_argument("mode",choices=("control","main","volume"))
    args=parser.parse_args()
    if args.mode=="control":
        control()
    elif args.mode=="main":
        for size in (16,24,32,48,64,80,96):
            run(size,24/size,1)
    else:
        for size in (24,48,96):
            run(size,.5,size//24)
