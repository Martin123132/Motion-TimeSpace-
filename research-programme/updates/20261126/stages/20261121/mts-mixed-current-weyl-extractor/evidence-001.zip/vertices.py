"""Linearized source vertices, with covariant A fixed under metric differentiation."""
from base import HERE,inputs,save,sha,table
import sympy as sy

matrix=sy.Matrix
identity=sy.eye(4)
shear=sy.diag(0,0,1,-1)
polar=identity[:,2]
names=("Maxwell","scalar_curvature","Ricci","Weyl","divergence_squared")

def vertices(metric,first,second,left,right):
    total=-first-second
    fp=first*left.T-left*first.T
    fk=second*right.T-right*second.T
    volume=sy.trace(metric)/2
    ric=(total.dot(total)*metric-total*(metric*total).T-metric*total*total.T+2*volume*total*total.T)/2
    contact=fp*fk.T
    scalar_term=-2*sy.trace(ric)*sy.trace(contact)
    ricci_term=-2*sy.trace(ric*contact)
    riemann_term=-4*(fp.T*total).dot(metric*(fk.T*total))
    photon_term=sy.trace(metric*contact)-volume*sy.trace(contact)/2
    def divergence(momentum,strength):
        base=-strength.T*momentum
        change=-volume*base-(volume*strength-metric*strength-strength*metric).T*(momentum+total)
        return base,change
    jp,dp=divergence(first,fp)
    jk,dk=divergence(second,fk)
    eom=2*(dp.dot(jk)+dk.dot(jp)+jp.dot((metric+volume*identity)*jk))
    return matrix([photon_term,scalar_term,ricci_term,riemann_term-2*ricci_term+scalar_term/3,eom])

def momenta(temporal,transverse):
    return matrix([-temporal,transverse,0,0]),matrix([-temporal,-transverse,0,0])

def local_matrix(temporal,transverse,metric=shear):
    first,second=momenta(temporal,transverse)
    return vertices(metric,first,second,polar,polar)

def weights(indices):
    block=matrix.vstack(*(local_matrix(1,index).T for index in indices))
    solution=sy.linsolve((block.T,matrix([0,0,0,1,0])))
    weight=matrix(next(iter(solution)))
    assert block.T*weight==matrix([0,0,0,1,0])
    return weight

def check(first,second,left,right,metric):
    total=-first-second
    result=vertices(metric,first,second,left,right)
    assert result==vertices(metric,second,first,right,left)
    assert vertices(metric,first,second,first,right)==sy.zeros(5,1)
    assert vertices(metric,first,second,left,second)==sy.zeros(5,1)
    gauge=matrix([3,-1,2,1])
    pure=vertices(total*gauge.T+gauge*total.T,first,second,left,right)
    def pinch(momentum,other_pol,polarization,other):
        variation=gauge.dot(momentum)*polarization+gauge.dot(polarization)*total
        quadratic=other.dot(other)*identity-other*other.T
        amp=other_pol.dot(quadratic*variation)
        return matrix([amp,0,0,0,2*other.dot(other)*amp])
    assert pure+pinch(first,right,left,second)+pinch(second,left,right,first)==sy.zeros(5,1)
    return result

def run():
    parent=inputs()
    rows=[]
    for temporal in (1,2):
        for transverse in range(4):
            first,second=momenta(temporal,transverse)
            for kind,metric in (("TT",shear),("conformal",2*identity)):
                line=check(first,second,polar,polar,metric)
                rows.append(dict(temporal=temporal,transverse=transverse,metric=kind,**dict(zip(names,map(str,line)))))
                if kind=="TT":
                    contact=first.dot(second); norm=first.dot(first); qsq=4*temporal**2
                    explicit=matrix([contact,0,-qsq*contact,-4*qsq*temporal**2+2*qsq*contact,-2*norm**2+2*qsq*norm])
                    assert line==explicit
                else:
                    assert line[0]==line[3]==0
    extra=0
    for index in range(1,9):
        first=matrix([index,-2,1,3])
        second=matrix([1,index+1,-1,0])
        metric=matrix(4,4,lambda row,col:(row+col-index)**2-1)
        check(first,second,matrix([1,2,-3,index]),matrix([-1,1,index,2]),metric)
        extra+=1
    full=matrix([[sy.Rational(row[name]) for name in names] for row in rows])
    minimal=[(0,1,2),(1,2,3)]
    assert full.rank()==5
    for subset in minimal:
        pure=matrix.vstack(*(local_matrix(1,index).T for index in subset))
        assert pure.rank()==3 and pure*matrix([4,0,1,0,0])==sy.zeros(3,1)
    table("operator-bank.csv",rows)
    save("frozen-projectors.json",dict(parent=parent,design=sha(HERE/"DESIGN.md"),vertices=sha(HERE/"vertices.py"),
        fixed_q_rank=3,augmented_rank=5,unrestricted_ward_fixtures=extra,projectors=[
            dict(indices=subset,weights=list(map(str,weights(subset)))) for subset in minimal],
        euclidean_scalar_prediction="1/180",mass_charge_units="(e^2/(4 pi)^2)/m^2"))
    print("rank",full.rank(),"projectors",*[list(weights(subset)) for subset in minimal])
if __name__=="__main__":
    run()
