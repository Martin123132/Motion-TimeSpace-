"""A scalar determinant with two photons and a shear; no local curvature coefficient as input."""
import json
from fractions import Fraction
from math import factorial
from base import HERE,guard,sha,table,save
import numpy as np
from numpy.polynomial.legendre import leggauss
from vertices import vertices,matrix,shear,polar

def moment(degree,psq,ksq,qsq,contacts=True):
    beta=Fraction(factorial(degree)**2,factorial(2*degree+1))
    simplex=Fraction(0)
    for first in range(degree+1):
        for second in range(degree-first+1):
            third=degree-first-second
            multi=Fraction(factorial(degree),factorial(first)*factorial(second)*factorial(third))
            integral=Fraction(factorial(first+third)*factorial(second+third)*factorial(first+second),factorial(2*degree+2))
            simplex+=multi*integral*psq**first*ksq**second*qsq**third
    return (2*(psq**degree+ksq**degree)*beta if contacts else 0)-4*simplex

def gram(index):
    return (1+index**2,1+index**2,4)

def renormalized(arg,mass):
    ratio=arg/mass**2
    result=np.empty_like(ratio)
    small=ratio<.05
    series=np.zeros_like(ratio[small])
    for degree in range(20,1,-1):
        series=series*ratio[small]+(-1)**degree/(degree*(degree-1))
    result[small]=mass**2*ratio[small]**2*series
    result[~small]=mass**2*((1+ratio[~small])*np.log1p(ratio[~small])-ratio[~small])
    return result

def integrate(psq,ksq,qsq,epsilon,mass,charge,order):
    nodes,weights=leggauss(order)
    nodes,weights=(1+nodes)/2,weights/2
    first=nodes[:,None]; second=(1-first)*nodes[None,:]; third=1-first-second
    simplex_weights=(1-first)*weights[:,None]*weights[None,:]
    coeff=epsilon**2
    bubbles=2*sum(weights@renormalized(coeff*mom*nodes*(1-nodes),mass) for mom in (psq,ksq))
    triangle=-4*np.sum(simplex_weights*renormalized(coeff*(first*third*psq+second*third*ksq+first*second*qsq),mass))
    return charge**2*np.array([bubbles+triangle,bubbles,triangle])/epsilon**4

def run():
    guard()
    design=json.loads((HERE/"frozen-projectors.json").read_bytes())
    assert sha(HERE/"vertices.py")==design["vertices"]
    rows=[]; powers=[]; missing=[]; previous={}
    for projector in design["projectors"]:
        indices,weights=projector["indices"],[Fraction(val) for val in projector["weights"]]
        name="-".join(map(str,indices))
        summed=lambda degree,contacts:sum(weight*moment(degree,*gram(index),contacts) for index,weight in zip(indices,weights))
        assert summed(1,True)==0
        assert all(moment(0,*gram(index))==2 for index in indices)
        for power in range(2,9):
            exact=Fraction((-1)**power,power*(power-1))*summed(power,True)
            powers.append(dict(bank=name,momentum_power=2*power,coefficient=str(exact)))
        expected=summed(2,True)/2
        assert expected==Fraction(1,180)
        missing.append(dict(bank=name,triangle_only_after_own_subtractions=str(summed(2,False)/2),
                        correct=str(expected),tadpole_required_to_cancel_constant=True))
        for ratio in (.5,.25,.125,.0625,.03125):
            for mass,charge in ((1.,1.),(2.5,-2.)):
                epsilon=ratio*mass
                def project(order):
                    return sum(float(weight)*integrate(*gram(index),epsilon,mass,charge,order) for index,weight in zip(indices,weights))
                coarse=project(16);fine=project(32)
                normalized=fine[0]*mass**2/charge**2
                error=(normalized/float(expected)-1)
                assert max(abs(fine-coarse))*mass**2/charge**2 < 1e-11
                prior=previous.get((name,mass))
                rich=None if prior is None else (4*normalized-prior)/3
                if ratio<=.125:
                    assert .21<abs((normalized-float(expected))/(prior-float(expected)))<.30
                rows.append(dict(bank=name,epsilon_over_m=ratio,mass=mass,charge=charge,raw_coefficient=fine[0],
                                   mass_charge_normalized=normalized,relative_error=error,richardson=rich,
                                   relative_richardson=None if rich is None else rich/float(expected)-1,
                                   quadrature_change=max(abs(fine-coarse)),bubble_projected=fine[1],triangle_projected=fine[2]))
                previous[name,mass]=normalized
                if ratio==.03125:
                    assert abs(rich/float(expected)-1)<1e-4
        assert all(abs(rows[-2*idx-1]["mass_charge_normalized"]-rows[-2*idx-2]["mass_charge_normalized"])<1e-14 for idx in range(5))
    checks=[]
    for temporal,other,transverse in ((-1,-1,0),(-1,-1,3),(-2,1,2),(1,3,2),(3,-2,1),(-1,-3,4)):
        first=matrix([temporal,transverse,0,0]);second=matrix([other,-transverse,0,0])
        op=vertices(shear,first,second,polar,polar)
        coeff=moment(2,int(first.dot(first)),int(second.dot(second)),int((first+second).dot(first+second)))/2
        target=Fraction(op[2])/45+Fraction(op[3])/180-Fraction(op[4])/60
        assert target==coeff
        checks.append(dict(p0=temporal,k0=other,transverse=transverse,determinant=str(coeff),published_basis=str(target)))
    table("continuum-response.csv",rows);table("exact-series.csv",powers);table("contact-removal.csv",missing);table("off-slice-checks.csv",checks)
    print("projected leading terms",missing,"finest",[(row["bank"],row["relative_error"],row["relative_richardson"]) for row in rows if row["epsilon_over_m"]==.03125 and row["mass"]==1])
if __name__=="__main__":
    run()
