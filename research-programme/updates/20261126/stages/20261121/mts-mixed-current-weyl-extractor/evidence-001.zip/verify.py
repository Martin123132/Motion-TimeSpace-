import argparse
import json
import math
import re
from fractions import Fraction
from base import HERE,PIN,inputs,read,save,sha

def record(name):
    return json.loads((HERE/name).read_bytes())
def run(create):
    parent=inputs()
    freeze=record("frozen-projectors.json")
    assert freeze["parent"]==parent and freeze["design"]==sha(HERE/"DESIGN.md") and freeze["vertices"]==sha(HERE/"vertices.py")
    assert freeze["fixed_q_rank"]==3 and freeze["augmented_rank"]==5 and len(read("operator-bank.csv"))==16
    bank_names={"0-1-2","1-2-3"}
    assert [[Fraction(item) for item in bank["weights"]] for bank in freeze["projectors"]]==[
        [Fraction(-1,16),Fraction(1,48),Fraction(-1,48)], [Fraction(-7,96),Fraction(1,60),Fraction(-1,160)]]
    for name,expected in (("exact-series.csv","1/180"),("dirac-series.csv","-1/90")):
        terms=[row for row in read(name) if row["momentum_power"]=="4"]
        assert {row["bank"] for row in terms}==bank_names and all(row["coefficient"]==expected for row in terms)
    scalar=read("continuum-response.csv");spinor=read("dirac-response.csv")
    assert len(scalar)==20 and len(spinor)==10
    assert all(abs(float(row["relative_richardson"]))<5e-6 for row in scalar if row["epsilon_over_m"]=="0.03125")
    assert all(abs(float(row["richardson_relative"]))<6e-5 for row in spinor if row["epsilon_over_m"]=="0.03125")
    assert all(row["correct"]=="1/180" and row["triangle_only_after_own_subtractions"]=="7/180" for row in read("contact-removal.csv"))
    assert len(read("off-slice-checks.csv"))==6 and all(row["determinant"]==row["published_basis"] for row in read("off-slice-checks.csv"))
    direct=read("direct-logdet.csv")
    assert len(direct)==4 and max(abs(float(row["error"])) for row in direct)<2e-8
    assert any(abs(float(row["coarse_rich_error"]))>2e-8 for row in direct)
    lattice=[]
    for path in sorted(HERE.glob("lattice-readout-*.csv")):
        data=read(path.name)
        assert {row["bank"] for row in data}==bank_names
        terms=read(path.name.replace("readout","terms"))
        assert len(terms)==4 and all(math.isclose(sum(float(row[key]) for key in ("tadpole","mixed_photon","stress_seagull","triangle")),float(row["total"]),abs_tol=1e-15) for row in terms)
        lattice.extend(data)
    for bank in bank_names:
        subset=sorted((row for row in lattice if row["bank"]==bank and int(row["mode"])==1 and math.isclose(float(row["mL"]),24)),key=lambda row:int(row["size"]))
        assert [int(row["size"]) for row in subset]==[16,24,32,48,64,80,96,112,128]
        errors=[abs(float(row["relative_to_matched"])) for row in subset]
        assert all(second<first for first,second in zip(errors,errors[1:])) and .05<errors[-1]<.07
        volumes=sorted((row for row in lattice if row["bank"]==bank and row["am"]=="0.5" and math.isclose(float(row["eps_over_m"]),math.pi/6)),key=lambda row:int(row["size"]))
        assert [int(row["size"]) for row in volumes]==[24,48,96]
        assert abs(float(volumes[-1]["relative_to_matched"])-float(volumes[-2]["relative_to_matched"]))<2e-7
    predictions=record("spacing-freeze.json")
    assert predictions["forecast"]==sha(HERE/"spacing-forecast.csv") and predictions["held_out"]==[112,128]
    for size,digest in zip((48,64,80),predictions["inputs"]):
        assert sha(HERE/f"lattice-readout-{size}-am{24/size:.6f}-n1.csv")==digest
    held=read("spacing-test.csv")
    assert len(held)==8
    assert all((abs(float(row["relative_prediction_error"]))<.005)==(row["inside_half_percent"]=="True")==(row["form"]=="a2_and_log") for row in held)
    sign=record("signed-transport.json")
    assert sign["null_screen"]==[-3.,3.] and not sign["total_QCD_term_fixed"] and min(sign["known_nonQCD_lag_interval_s_in_this_label"])>0
    assert record("chiral-design.json")["physical_QCD_ensembles_tested"]==0
    assert all(abs(float(row["free_mass_stencil"])-float(row["injected_log_quadratic_stencil"]))<2e-14 for row in read("chiral-stencil-controls.csv"))
    for path in HERE.glob("*.md"):
        for link in re.findall(r"\]\(([^()]+)\)",path.read_text(encoding="utf8")):
            assert link.startswith("https://") or (HERE/link).is_file(),(path,link)
    assert not any(path.is_dir() for path in HERE.iterdir())
    counts={}
    for path in HERE.glob("*.csv"):
        rows=read(path.name)
        assert rows and all(None not in row and None not in row.values() for row in rows)
        counts[path.name]=len(rows)
    files={path.name:sha(path) for path in sorted(HERE.iterdir()) if path.name!="seal.json"}
    result=dict(parent=PIN,source_contracts=parent,files=files,counts=counts,csv_rows=sum(counts.values()))
    if create:
        save("seal.json",result)
    assert record("seal.json")==result
    print(f"{len(files)} files; {sum(counts.values())} CSV data rows; seal {sha(HERE/'seal.json')}")
if __name__=="__main__":
    parser=argparse.ArgumentParser()
    parser.add_argument("--seal",action="store_true")
    run(parser.parse_args().seal)
