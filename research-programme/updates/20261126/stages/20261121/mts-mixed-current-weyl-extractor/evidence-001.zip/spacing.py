"""Predict two finer lattices from three saved spacings, then test without changing weights."""
import argparse
import json
from base import HERE,read,save,sha,table
from lattice import run
import numpy as np

def get(size):
    return read(f"lattice-readout-{size}-am{24/size:.6f}-n1.csv")
def design(size,logarithmic):
    scale=(24/size)**2
    return [1.,scale,scale*np.log(scale)] if logarithmic else [1.,scale]
def forecast():
    rows=[]
    for basis,indices,logarithmic in (("a2",(64,80),False),("a2_and_log",(48,64,80),True)):
        for col in range(2):
            matrix=np.array([design(size,logarithmic) for size in indices])
            values=[float(get(size)[col]["normalized_coefficient"]) for size in indices]
            solution=np.linalg.solve(matrix,values)
            for target in (112,128):
                rows.append(dict(bank=get(48)[col]["bank"],form=basis,size=target,
                                 coeff_forecast=np.dot(design(target,logarithmic),solution),formal_intercept=solution[0],
                                 training_sizes=";".join(map(str,indices)),condition=np.linalg.cond(matrix)))
    table("spacing-forecast.csv",rows)
    save("spacing-freeze.json",dict(forecast=sha(HERE/"spacing-forecast.csv"),inputs=[sha(HERE/f"lattice-readout-{size}-am{24/size:.6f}-n1.csv") for size in (48,64,80)],
                                   held_out=[112,128],tolerance_relative=.005,
                                   target="predict measured finite-spacing response, not proof of continuum accuracy"))
def test():
    assert json.loads((HERE/"spacing-freeze.json").read_bytes())["forecast"]==sha(HERE/"spacing-forecast.csv")
    for size in (112,128):
        run(size,24/size,1)
    rows=[]
    for row in read("spacing-forecast.csv"):
        observed,=[val for val in get(int(row["size"])) if val["bank"]==row["bank"]]
        actual=float(observed["normalized_coefficient"])
        ratio=float(row["coeff_forecast"])/actual-1
        rows.append(dict(**row,actual=actual,relative_prediction_error=ratio,inside_half_percent=abs(ratio)<.005,
              actual_vs_continuum=float(observed["relative_to_matched"]),
              intercept_vs_infinite_volume_continuum=float(row["formal_intercept"])/float(observed["continuum_same_momentum"])-1))
    table("spacing-test.csv",rows)
    print([(row["form"],row["bank"],row["size"],row["relative_prediction_error"],row["inside_half_percent"]) for row in rows])
if __name__=="__main__":
    parser=argparse.ArgumentParser()
    parser.add_argument("mode",choices=("freeze","test"))
    args=parser.parse_args()
    (forecast if args.mode=="freeze" else test)()
