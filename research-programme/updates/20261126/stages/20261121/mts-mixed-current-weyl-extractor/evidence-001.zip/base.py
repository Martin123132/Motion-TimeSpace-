import csv
import hashlib
import io
import json
import os
from pathlib import Path

for setting in ("OPENBLAS_NUM_THREADS","OMP_NUM_THREADS","MKL_NUM_THREADS","NUMEXPR_NUM_THREADS","BLIS_NUM_THREADS"):
    os.environ[setting]="1"
HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
PREVIOUS=ROOT/"mts-binary-polarization-rays-20261121"
PIN="960bcbd283c5613b29eff078ed5c250416b40a13e865ebe4e6786b6fe2c4cc7c"
INTAKE=ROOT/"source-intake"/"functional_rg"
def sha(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream,"sha256").hexdigest()
def guard():
    if any((path/"STOP-REQUESTED").exists() for path in (ROOT,HERE,PREVIOUS)):
        raise RuntimeError("owner hold")
def inputs():
    guard()
    assert sha(PREVIOUS/"seal.json")==PIN
    for filename,digest in json.loads((PREVIOUS/"seal.json").read_bytes())["files"].items():
        assert sha(PREVIOUS/filename)==digest
    assert sha(INTAKE/"4931"/"0812.4849-source.tar")=="d094ed32127888dd0052e8341d43c83407dbe24c8f2813e3c5f4c49149781438"
    return {str(path.relative_to(ROOT).as_posix()):sha(path) for path in (
        INTAKE/"4946"/"QCD_TJJ_dispersion_and_lattice_contract.csv",INTAKE/"4944"/"visible_CFF_matching_components.csv",
        INTAKE/"4931"/"src-0812.4849"/"ehgravfinal.tex",INTAKE/"4931"/"src-1609.00723"/"SuperluminalityDraftarXiv2.tex",
        ROOT/"mts-finite-tidal-exposure-20261121"/"optics.py")}
def put(name,data):
    guard()
    path=HERE/name
    if path.exists():
        assert path.read_bytes()==data,name
    else:
        with path.open("xb") as stream:
            stream.write(data)
def save(name,record):
    put(name,(json.dumps(record,indent=2,allow_nan=False)+"\n").encode())
def table(name,rows):
    buffer=io.StringIO(newline="")
    writer=csv.DictWriter(buffer,rows[0].keys(),lineterminator="\n")
    writer.writeheader()
    writer.writerows(rows)
    put(name,buffer.getvalue().encode())
def read(name):
    with (HERE/name).open(newline="",encoding="utf8") as stream:
        return list(csv.DictReader(stream))
