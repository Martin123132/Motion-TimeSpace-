"""Massive Dirac determinant from its own photon and shear vertices, not a spin rescaling."""
import json
from fractions import Fraction
from math import factorial
from functools import lru_cache
from base import HERE,guard,table,save
from numpy.polynomial.legendre import leggauss
from vertices import vertices,polar,matrix,shear
import numpy as np
import sympy as sy

alpha,beta=sy.symbols("alpha beta")
def invariant(psq,ksq,dot,xx,yy):
    shift2=xx**2*psq+yy**2*ksq-2*xx*yy*dot
    variance=xx*psq+yy*ksq-shift2
    bdotc=shift2-xx*(psq-dot)+yy*(dot-ksq)-dot
    return variance,bdotc

def simplex(poly):
    return sum(coeff*sy.Rational(factorial(deg1)*factorial(deg2),factorial(2+deg1+deg2))
               for (deg1,deg2),coeff in sy.Poly(poly,alpha,beta).terms())

@lru_cache(None)
def coefficient(degree,psq,ksq,dot):
    variance,bdotc=invariant(psq,ksq,dot,alpha,beta)
    bubble=sy.Rational(factorial(degree)**2,factorial(2*degree+1))*(psq**degree+ksq**degree)
    triangle=simplex((bdotc-variance)*variance**(degree-1))
    return 4*sy.Rational((-1)**degree,degree-1)*(bubble+triangle)

def integrate(index,ratio,order):
    psq=ksq=1+index**2;dot=1-index**2
    nodes,weights=leggauss(order)
    nodes,weights=(nodes+1)/2,weights/2
    xp=nodes[:,None];yp=(1-xp)*nodes[None,:]
    variance,bdotc=invariant(psq,ksq,dot,xp,yp)
    product=(1-xp)*weights[:,None]*weights[None,:]
    single=nodes*(1-nodes)*psq
    return 4*(2*sum(weights*single*np.log1p(single*ratio**2))+
              np.sum(product*(bdotc-variance)*np.log1p(variance*ratio**2)))/ratio**2

def run():
    guard()
    frozen=json.loads((HERE/"frozen-projectors.json").read_bytes())
    rows=[];powers=[]
    for bank in frozen["projectors"]:
        indices=bank["indices"]
        weights=list(map(Fraction,bank["weights"]))
        name="-".join(map(str,indices))
        for degree in range(2,6):
            exact=sum(weight*coefficient(degree,1+index**2,1+index**2,1-index**2) for index,weight in zip(indices,weights))
            powers.append(dict(bank=name,momentum_power=2*degree,coefficient=str(exact)))
            if degree==2:
                assert exact==sy.Rational(-1,90),(name,exact)
        prev=None
        for ratio in (.5,.25,.125,.0625,.03125):
            coarse,fine=(sum(float(weight)*integrate(index,ratio,order) for index,weight in zip(indices,weights)) for order in (16,32))
            assert abs(coarse-fine)<2e-11
            rich=None if prev is None else (4*fine-prev)/3
            if ratio==.03125:
                assert abs(-90*rich-1)<1e-4
            rows.append(dict(bank=name,epsilon_over_m=ratio,normalized=fine,relative_error=-90*fine-1,
                             quadrature_change=coarse-fine,richardson=rich,richardson_relative=None if rich is None else -90*rich-1))
            prev=fine
    for temporal,other,transverse in ((-1,-1,0),(-1,-1,3),(-2,1,2),(1,3,2),(3,-2,1),(-1,-3,4)):
        first=matrix([temporal,transverse,0,0]);second=matrix([other,-transverse,0,0])
        op=vertices(shear,first,second,polar,polar)
        expected=(22*op[2]-2*op[3]-24*op[4])/180
        actual=coefficient(2,int(first.dot(first)),int(second.dot(second)),int(first.dot(second)))
        assert actual==expected,(actual,expected)
    table("dirac-response.csv",rows);table("dirac-series.csv",powers)
    print("Dirac leading coefficients", [row for row in powers if row["momentum_power"]==4],"finest",[row["richardson_relative"] for row in rows if row["epsilon_over_m"]==.03125])
if __name__=="__main__":
    run()
