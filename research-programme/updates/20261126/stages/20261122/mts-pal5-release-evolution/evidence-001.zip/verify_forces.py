from local_release_field import *


def inspect():
    def arrays(data):
        return np.array([[float(row[key]) for key in ("a_R","a_z")] for row in data])
    coarse=rows(HOME/"independent-newton-q8.csv");fine=rows(HOME/"independent-newton-q12.csv");assert len(coarse)==len(fine)==25
    outputs=[]
    for idx in range(5):
        chunk=fine[5*idx:5*idx+5];frac=float(chunk[0]["frac"]);times=float(chunk[0]["time"])
        p=np.array([[float(row["r"]),0,float(row["z"])] for row in chunk])
        actual=arrays(chunk);refs=arrays(coarse[5*idx:5*idx+5])
        versions=[("Newton_q8",refs)]
        for q,deg in ((8,32),(12,20),(12,32),(12,48)):
            patch=LocalField("chart",q,deg)
            versions.append((f"chart_q{q}_n{deg}",patch.force(frac,p)[:,[0,2]]))
        for kind,arr in versions:
            for entry in range(5):
                mode="absolute" if entry==0 else "relative"
                aa,bb=arr[entry],actual[entry]
                if entry: aa,bb=aa-arr[0],bb-actual[0]
                loss=np.linalg.norm(aa-bb)/np.linalg.norm(bb)
                outputs.append(dict(point=idx,time=times,kind=kind,offset=entry,mode=mode,predicted_R=aa[0],true_R=bb[0],predicted_z=aa[1],true_z=bb[1],
                    relative_norm=loss,passes=loss<=.005))
    table("newton-checks.csv",outputs)
    record("newton-checks.json",{kind:dict(count=len(items),misses=sum(not r["passes"] for r in items),worst=max(r["relative_norm"] for r in items))
      for kind in sorted(set(r["kind"] for r in outputs)) if (items:=[r for r in outputs if r["kind"]==kind])})
if __name__=="__main__":inspect()
