from local_release_field import LocalField
from ledger import *
import numpy as np
sys.path.insert(0,str(WORK))
for file in ("forces.py","crossing.py","hist-4-2-A-reset_forward.npz"): pin(WORK,file)
import forces as bank
import crossing
from pal5_tide_io import CONV
assert CONV==bank.CONV
with np.load(pin(WORK,"hist-4-2-A-reset_forward.npz")) as file:
    CENTRE=file["centre"][0].copy();END=float(file["time"][1])
TIMES=np.r_[0.,.015625,.03125,.0625,END*.25,END*.5,END]
CONFIGS={"small10":("small",10,32),"small14":("small",14,32),"chart8":("chart",8,32),
         "chart12":("chart",12,32),"chart48":("chart",12,48),"chart20":("chart",12,20),"wave2":("chart",12,48),"frozen":("chart",12,48)}
def energies(state):
    delta=state[1:,:3]-state[0,:3];speed=state[1:,3:6]-state[0,3:6]
    return (.5*np.sum(speed**2,axis=1)-bank.GM/np.sqrt(np.sum(delta**2,axis=1)+bank.SIZE**2))/CONV**2

class Driven:
    def __init__(self,origin,model,frozen=False):
        self.base=origin;self.model=model;self.frozen=frozen;self.left=origin.left;self.edges=origin.edges
    def components(self,time,xyz,cells=None):
        host,wave=self.base.components(time,xyz,cells)
        if self.model is not None: host=self.model.force(0. if self.frozen else time/self.base.end,xyz)*CONV**2
        return host,wave

def run(label,steps):
    guard();assert max(readj(HOME/"dense-control.json").values())<=.005
    src=None if label=="native" else LocalField(*CONFIGS[label])
    mat=bank.Material();rows_out=[];path=[];ver=[]
    end=3 if label.startswith("small") else 6
    dx,dv,keys=bank.probes();initial=np.zeros((73,8));initial[:,:6]=CENTRE;initial[1:,:3]+=dx;initial[1:,3:6]+=dv;energy0=energies(initial)
    for prep in ("reset","coupled"):
        original=bank.load(2 if label=="wave2" else 4,2,prep)[:1]
        for sign in (("ordinary","forward","reverse") if prep=="reset" else ("forward","reverse")):
            guard();source=bank.make(original,mat,sign)[0]
            field=Driven(source,src,label=="frozen");state=initial.copy()
            for left,right in zip(TIMES[:end],TIMES[1:end+1]):
                events=[];n=max(2,round(steps*(right-left)/.0625))
                state=crossing.advance(field,left,right,state,n,label=="native",events)
                vals=energies(state);work=state[1:,6:]/CONV**2
                coords=state[1:,:3]-state[:1,:3];speed=(state[1:,3:6]-state[:1,3:6])/CONV
                for jj,(shell,axis,side,tan,sgn) in enumerate(keys):
                    rows_out.append(dict(prep=prep,flow=sign,time=right,star=jj,shell=shell,energy=vals[jj],delta_e=vals[jj]-energy0[jj],
                        ordinary_work=work[jj,0],wave_work=work[jj,1],**dict(zip(("x","y","z"),coords[jj])),**dict(zip(("vx","vy","vz"),speed[jj]))))
                path.append(dict(prep=prep,flow=sign,time=right,**dict(zip(("x","y","z","vx","vy","vz"),state[0,:6]))))
                ver.append(dict(prep=prep,flow=sign,time=right,steps=n,native_face_events=len(events),
                    balance_rel=np.linalg.norm(vals-energy0-work.sum(axis=1))/np.linalg.norm(vals-energy0),
                    balance_max_per_binding=max(abs((vals-energy0-work.sum(axis=1))/energy0)),
                    max_abs_dimensionless_coordinate=src.max_coord if src else None))
    table(f"stars-{label}-{steps}.csv",rows_out);table(f"centres-{label}-{steps}.csv",path);table(f"balance-{label}-{steps}.csv",ver)
    print(label,steps,flush=True)
if __name__=="__main__": run(sys.argv[1],int(sys.argv[2]))
