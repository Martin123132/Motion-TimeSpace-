from ledger import *
import numpy as np
from scipy.special import roots_legendre
PREP=ROOT/"mts-flow-formation-inverse-586-20261122"
LOCK="4ae215216dac834ea5d8ae503fea680707af22348044627efb0b507a7c398fcb"

def run():
    assert sha(PREP/"seal.json")==LOCK
    files=readj(PREP/"seal.json")
    for name in ("inverse.py","states-586-280.npz","states-586-140.npz","shells-280.csv","shells-140.csv"):
        assert sha(PREP/name)==files[name]
    sys.path.insert(0,str(PREP))
    from inverse import setup,SHELLS
    lab,_,_,_,shape=setup();el=lab.run.el;bg=lab.obj.bg;length=bg.length
    knots=el.knots;coef=lab.mesh.mscale
    nodes,weights=roots_legendre(16)
    cuts=np.unique(np.r_[0.,el.right,SHELLS/length])
    radius=(cuts[:-1,None]+np.diff(cuts)[:,None]*(nodes+1)/2).ravel();quad=(np.diff(cuts)[:,None]*weights/2).ravel()
    index=np.searchsorted(el.right,radius)
    basis=shape(knots,(radius-el.left[index])/el.width[index])[0]
    assert np.allclose(el.left[1:],el.right[:-1],rtol=0,atol=1e-13)
    mask=(el.right*length>=8.12)&(el.left*length<=8.48)
    packet=dict(left=el.left[mask],right=el.right[mask],knots=knots,length=length,mscale=coef,degrees=bg.orders)
    checks=[]
    for count in (140,280):
        expected=rows(PREP/f"shells-{count}.csv")
        with np.load(PREP/f"states-586-{count}.npz") as original:
            for prep in ("reset","coupled"):
                for sign in ("forward","reverse"):
                    key=prep+"_"+sign;state=original[key];vals=el.nodes(state);packet[f"{key}_{count}"]=vals[mask]
                    radial=np.einsum("ti,til->tl",basis,vals[index])
                    masses=coef*quad*np.sum(abs(radial)**2,axis=1)
                    for i,r in enumerate(SHELLS):
                        row=next(row for row in expected if row["arm"]==prep and row["flow"]==sign and row["epoch"]=="586" and abs(float(row["radius_kpc"])-r)<1e-9)
                        mass=masses[radius<r/length].sum();delta=abs(mass/float(row["enclosed_Msun"])-1);assert delta<1e-9
                        checks.append(dict(state=key,count=count,radius=r,integral=mass,relative=delta))
    buf=io.BytesIO();np.savez_compressed(buf,**packet);save("wave-elements.npz",buf.getvalue());table("wave-normalization.csv",checks)

if __name__=="__main__":run()
