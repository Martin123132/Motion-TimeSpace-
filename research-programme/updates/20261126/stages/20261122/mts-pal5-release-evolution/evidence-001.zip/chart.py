from ledger import *
import numpy as np
from pal5_tide_io import G,SIZE,positions
from poisson_patch import grid
CASE="reset_forward"
plane,height,unused=positions(CASE)
radius0=np.hypot(plane,height)
xb=np.log(np.array([radius0-.095,radius0+.23])/radius0)
yb=np.array([-.057,-np.arcsin(1/32),-.002])
def axis(bounds,nodes):
    return (bounds[0]+bounds[1])/2+np.diff(bounds)[0]*nodes/2
def sites():
    nodes=grid(8)[0];out=[(plane,height)];tags=[(-1,-1,-1)]
    for page in (0,1):
        xx=axis(xb,nodes);yy=axis(yb[page:page+2],nodes)
        for i,x in enumerate(xx):
            for j,y in enumerate(yy):
                if i not in (0,8) and (j!=0 or page!=0) and (j!=8 or page!=1): continue
                tags.append((page,i,j));r=radius0*np.exp(x);out.append((r*np.cos(y),r*np.sin(y)))
    return np.array(out),tags

def boundary(order):
    from sources import integrate,info
    pts,tags=sites();unique,indices=np.unique(pts[1:],return_inverse=True,axis=0)
    loc=np.vstack((pts[0],unique))
    data=integrate(loc,loc,order,info(),shifts=np.array([-.018,0,.018]))
    assert np.isfinite(data).all()
    for snap,vals in zip((586,590),data):
        table(f"chart-{snap}-q{order}.csv",[dict(panel=tag[0],i=tag[1],j=tag[2],relative_phi=value) for tag,value in zip(tags[1:],vals[indices+1]-vals[0])])

if __name__=="__main__": boundary(int(sys.argv[1]))
