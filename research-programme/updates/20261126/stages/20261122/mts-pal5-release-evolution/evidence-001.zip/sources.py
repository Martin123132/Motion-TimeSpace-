from ledger import *
from tensor import prior,material,groups,quadrature,ellipkm1
import numpy as np
from pal5_tide_io import G,SIZE,positions


def info():
    edges,angles,cells,_=prior.io.arrays()
    faces,shells,gain586=groups(edges,angles,cells)
    def budgets(snap):
        blocks=[]
        for part in range(4):
            path=pin(FIRE,f"mass-{snap}-{part}.npz")
            with np.load(path) as archive:
                assert np.array_equal(archive["edges"],edges) and np.array_equal(archive["mu"],angles)
                blocks.append(archive["hist"][:,0].sum(axis=0))
        return np.sum(blocks,axis=0)
    terminal=budgets(600)
    centres=(edges[1:]+edges[:-1])/2;mus=(angles[1:]+angles[:-1])/2
    region=(np.searchsorted(shells,centres,side="right")-1)[:,None]*7+np.searchsorted(faces[1:-1],mus)
    weights=lambda value:np.bincount(region.ravel(),weights=value.ravel(),minlength=gain586.size)
    denom=weights(terminal);results=[];audit=[]
    for snap in (586,590):
        raw=weights(budgets(snap))
        gain=np.divide(raw,denom,out=np.ones_like(raw),where=denom>0).reshape(gain586.shape)
        supported=weights(cells["terminal"]).reshape(gain.shape)>0
        gain=np.where(supported,gain,1.)
        if snap==586: assert np.allclose(gain,gain586,rtol=1e-12,atol=1e-12),np.max(abs(gain-gain586))
        expect=readj(pin(FIRE,f"forcing-{snap}.json"))["joint"]["delta_msun"]
        change=np.sum(cells["terminal"]*(gain.ravel()[region]-1))
        assert abs(change/expect-1)<1e-9 and min(gain.ravel())>=0
        results.append(gain);audit.append(dict(snapshot=snap,source_change_Msun=change,saved_Msun=expect))
    table("source-transfer.csv",audit)
    return faces,shells,np.array(results)


def integrate(points,breaks,order,group,shifts=None,acceleration=False):
    src=prior.source;original=prior.original
    faces,shells,gain=group
    pr,pz=points.T;radius=np.hypot(pr,pz);height=breaks[0,1]
    inner,outer=radius[0]-.6,radius[0]+.6
    assert inner<radius.min() and max(radius)<outer and max(radius)<25
    local=material.density(pr,pz)*gain[:,np.searchsorted(shells,radius,side="right")-1,np.searchsorted(faces[1:-1],abs(pz)/radius)]
    surfaces=np.unique(np.r_[shells,25,30,inner,outer]);extent=160.
    if shifts is None: shifts=np.array([-.15,-.02,-.002,0,.002,.02,.15])
    bounds=np.unique(np.clip(np.r_[0.,extent,np.arange(0,30.1,.75),40,50,65,80,110,src.radknots,src.stars.centres,surfaces,
        (np.unique(breaks[:,0])[:,None]+shifts).ravel(),abs(height)*np.sqrt(1-faces[1:-1]**2)/faces[1:-1],np.sqrt(np.maximum(0,surfaces**2-height**2))],0,extent))
    cyl,wr=quadrature(bounds,order)
    col=original.columns(cyl)*(cyl<30)[:,None];supply=original.supply(cyl);share=supply/np.maximum(1e-25,supply.sum(axis=1))[:,None]
    zbase=np.r_[0.,src.stars.axis[::2],src.stars.H,np.geomspace(.0008,extent,44),extent,(np.unique(abs(breaks[:,1]))[:,None]+shifts).ravel(),4,5,8,12,16,24,40,60,80]
    az,wa=quadrature(np.array([0.,np.pi/2]),32);total=np.zeros((2,len(points)))
    if acceleration:
        from scipy.special import ellipe
        total=np.zeros((2,len(points),2))
    for idx,(dist,wc) in enumerate(zip(cyl,wr)):
        if idx%128==0: guard()
        zcuts=np.unique(np.clip(np.r_[zbase,np.sqrt(np.maximum(0,surfaces**2-dist**2)),dist*faces[1:-1]/np.sqrt(1-faces[1:-1]**2)],0,extent))
        alt,wz=quadrature(zcuts,order)
        stellar=sum(val*original.zshape(k,alt) for k,val in zip(original.ls.S22,col[idx]))
        removed=col[idx].sum()*sum(share[idx,j]*src.starshape(alt,j) for j in range(4))
        centre=src.stars.bmass*(original.ls.old.density("E3",(.67,.29,.27),dist*np.cos(az),dist*np.sin(az),alt[:,None])@(wa*2/np.pi))
        density=src.disk(np.array([dist]),alt)+stellar-removed+centre
        rr=np.hypot(dist,alt);taper=np.clip((30-rr)/5,0,1)
        factors=gain[:,np.searchsorted(shells,rr,side="right")-1,np.searchsorted(faces[1:-1],alt/rr)]
        weighted=wc*dist*wz*density*(1+taper*(factors-1))
        window=wc*dist*wz*((rr>=inner)&(rr<outer))
        for first in range(0,len(points),8):
            select=slice(first,first+8);pp=pr[select,None];zz=pz[select,None];field=0.;vertical=0.
            for signed in (alt,-alt):
                sep=zz-signed;dz=sep**2;high=(pp+dist)**2+dz;low=(pp-dist)**2+dz
                kernel=-2*G/np.sqrt(high);first_kind=ellipkm1(low/high)
                if acceleration:
                    second=ellipe(1-low/high)/low
                    field+=kernel*(first_kind+(pp**2-dist**2-dz)*second)/pp
                    vertical+=2*kernel*sep*second
                else: field=field-4*G*first_kind/np.sqrt(high)
            if acceleration:
                for component,part in enumerate((field,vertical)):
                    total[:,select,component]+=weighted@part.T-local[:,select]*(part@window)
            else: total[:,select]+=weighted@field.T-local[:,select]*(field@window)
    if acceleration:
        total+=(-4*np.pi*G/3*(1-(inner/radius)**3)*local)[:,:,None]*points[None,:,:]
        return total
    total+=local*(-4*np.pi*G*((radius**3-inner**3)/(3*radius)+(outer**2-radius**2)/2))
    return total


def dense(order):
    group=info();old=rows(pin(OLD,"potential-boundary-reset_forward-10.csv"))
    allpoints=np.array([[float(row[key]) for key in ("plane","height")] for row in old])
    mask=np.array([int(row["width"]) in (0,4) for row in old]);points=allpoints[mask]
    values=integrate(points,allpoints,order,group)
    for snap,data in zip((586,590),values):
        table(f"dense-{snap}-q{order}.csv",[dict(i=row["i"],j=row["j"],width=row["width"],plane=row["plane"],height=row["height"],relative_phi=val-data[0]) for row,val in zip((r for r,take in zip(old,mask) if take),data)])

if __name__=="__main__":
    dense(int(sys.argv[1]))
