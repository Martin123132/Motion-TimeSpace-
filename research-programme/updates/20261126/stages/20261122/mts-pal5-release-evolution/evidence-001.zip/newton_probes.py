from local_release_field import *
from sources import integrate,info
from scipy.optimize import brentq

def probes():
    path=[(0.,plane,height)]
    for row in rows(HOME/"centres-chart8-4.csv"):
        t=float(row["time"])
        if row["prep"]=="reset" and row["flow"]=="forward" and t>.1:
            path.append((t,np.hypot(float(row["x"]),float(row["y"])),float(row["z"])))
    a,b=np.array(path[1]),np.array(path[2])
    def gap(frac):
        time,r,z=a+frac*(b-a);return np.arctan2(z,r)-yb[1]
    cross=a+brentq(gap,0,1)*(b-a)
    path.insert(2,tuple(cross))
    return path

def run(order):
    path=probes();delta=np.array([[0,0],[SIZE,0],[-SIZE,0],[0,SIZE],[0,-SIZE]])
    points=np.vstack([np.array([r,z])+delta for time,r,z in path])
    data=integrate(points,points,order,info(),shifts=np.array([-.015,-.002,0,.002,.015]),acceleration=True)
    prior=ROOT/"mts-pal5-joined-flow-586-600-20261122"
    assert sha(prior/"seal.json")=="86d9b1296c253b14a04e475339a9cbf71f84fed201749a234af4892b715576b7"
    name="verdict-4-2.json";assert sha(prior/name)==readj(prior/"seal.json")[name]
    duration=readj(prior/name)["early_Myr"];out=[]
    for jj,(time,r,z) in enumerate(path):
        frac=time/duration;arr=(1-frac)*data[0]+frac*data[1];field=arr[5*jj:5*jj+5]
        for delta_index,((dr,dz),values) in enumerate(zip(delta,field)):
            out.append(dict(point=jj,offset=delta_index,time=time,frac=frac,r=r+dr,z=z+dz,a_R=values[0],a_z=values[1],
                relative_R=values[0]-field[0,0],relative_z=values[1]-field[0,1]))
    table(f"independent-newton-q{order}.csv",out)
if __name__=="__main__":run(int(sys.argv[1]))
