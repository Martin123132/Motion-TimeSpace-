from ledger import *
from pal5_tide_io import G,SIZE
import mpmath as mp

def run():
    mp.mp.dps=60;width=mp.mpf(".72");bare=mp.mpf(".3");prior=mp.mpf(".37");replaced=mp.mpf(".21")
    out=[]
    for aperture in (mp.mpf(".4"),mp.mpf("1"),mp.mpf("2")):
        rho=mp.exp(-aperture**2/(2*width**2))/(2*mp.pi*width**2)**mp.mpf("1.5")
        exact=4*mp.pi*aperture**3*rho*(replaced**2-prior**2)
        for chirp in (mp.mpf("-.58"),mp.mpf(0),mp.mpf(".58")):
            def enclosed(t,w):
                c=mp.cos(w*t);s=mp.sin(w*t)/w
                variance=width**2*(c+chirp*s)**2+(bare/(2*width))**2*s**2
                arg=aperture/mp.sqrt(2*variance)
                return mp.erf(arg)-2/mp.sqrt(mp.pi)*arg*mp.exp(-arg**2)
            for dt in (mp.mpf(".01"),mp.mpf(".005"),mp.mpf(".0025")):
                approx=sum(enclosed(t,replaced)-enclosed(t,prior) for t in (-dt,dt))/dt**2
                rel=float(abs(approx/exact-1));assert rel<.005
                out.append(dict(radius=float(aperture),chirp=float(chirp),time_step=float(dt),curvature=float(approx),surface_prediction=float(exact),relative=rel))
    table("independent-quantum-control.csv",out)
    raw=rows(HOME/"initial-wave-feedback.csv")
    result=[]
    for row in raw:
        if (row["patch"],row["rule"],row["wave_steps"])==("chart","24","280"):
            ap=int(row["aperture"])
            mass=float(row["moving_ball_Msun_Myr2"]);fraction=float(row["fractional_Myr_m2"])
            result.append(dict(aperture=ap,prep=row["prep"],flow=row["flow"],wave_enclosed_mass_curvature_Msun_Myr2=mass,
                wave_fractional_curvature_per_Myr2=fraction,mean_inward_acceleration_curvature_kms2_per_kpc_per_Myr2=G*mass/(ap*SIZE)**2))
    table("weak-field-feedback.csv",result)
if __name__=="__main__":run()
