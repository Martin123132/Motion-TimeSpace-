from pathlib import Path
import csv,hashlib,io,json,os,sys
for key in ("OPENBLAS_NUM_THREADS","MKL_NUM_THREADS","OMP_NUM_THREADS","BLIS_NUM_THREADS","NUMEXPR_NUM_THREADS"): os.environ[key]="1"
HOME=Path(__file__).resolve().parent
ROOT=HOME.parent
OLD=ROOT/"mts-pal5-source-tides-20261122"
GREEN=ROOT/"mts-pal5-positive-source-20261122"
WORK=ROOT/"mts-pal5-interface-work-20261122"
FIRE=ROOT/"mts-fire-joint-baryon-history-20261120"
PINS={OLD:"f8c1f197a9fe0fbe68dcf2b7d03499c1471223e73ed74d5394b6ba8bc20fca3a",GREEN:"c918bbe06f2a0be4785be9cf580dd91b493541fce8b4309d9a7622cc6248baf9",WORK:"e8891d2372d597e163d1f8de482c0884eac39405223b34e7b9d0eee10f7e2723",FIRE:"19c78eaa158a766bd409c0a64504788b1346542eccee37c004083a918c480d67"}

def sha(path):
    with path.open("rb") as stream: return hashlib.file_digest(stream,"sha256").hexdigest()

def pin(folder,name):
    assert sha(folder/"seal.json")==PINS[folder]
    files=json.loads((folder/"seal.json").read_bytes())
    assert sha(folder/name)==files.get("files",files)[name],name
    return folder/name

def guard():
    assert not any((base/"STOP-REQUESTED").exists() for base in (*PINS,HOME,ROOT)),"Owner hold"

def save(name,data):
    path=HOME/name
    if path.exists(): assert path.read_bytes()==data,name
    else:
        with path.open("xb") as stream: stream.write(data)

def record(name,obj): save(name,(json.dumps(obj,sort_keys=True,indent=2,allow_nan=False)+"\n").encode())
def rows(path):
    with path.open() as stream: return list(csv.DictReader(stream))
def table(name,records):
    stream=io.StringIO();writer=csv.DictWriter(stream,list(records[0]),lineterminator="\n");writer.writeheader();writer.writerows(records);save(name,stream.getvalue().encode())
def readj(path): return json.loads(path.read_bytes())
guard()
sys.path.insert(0,str(OLD))
for key in ("pal5_tide_io.py","boundary.py","tensor.py","poisson_patch.py","finite_work.py"): pin(OLD,key)
