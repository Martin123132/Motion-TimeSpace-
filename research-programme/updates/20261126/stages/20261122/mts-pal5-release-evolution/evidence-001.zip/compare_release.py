from ledger import *
import numpy as np

LABELS=("small10-4","small14-4","small14-8","native-4","native-8","chart8-4","chart20-4","chart12-4","chart12-8","chart48-8","wave2-8","frozen-8")
COLUMNS=("energy","delta_e","ordinary_work","wave_work","x","y","z","vx","vy","vz")
arms=("reset","coupled");flows=("forward","reverse")
def load_data(label):
    result={}
    for row in rows(HOME/f"stars-{label}.csv"):
        key=row["prep"],row["flow"],float(row["time"]),int(row["shell"])
        result.setdefault(key,[]).append((int(row["star"]),[float(row[col]) for col in COLUMNS]))
    for key,values in result.items():
        assert [val[0] for val in values]==list(range((key[3]-1)*24,key[3]*24))
        result[key]=np.array([val[1] for val in values]);assert np.isfinite(result[key]).all()
    return result
def err(x,y):
    diff=np.linalg.norm(x-y);den=np.linalg.norm(y)
    if den==0: assert diff==0;return 0.
    return diff/den

def run():
    sets={lab:load_data(lab) for lab in LABELS};summary=[];signed=[]
    tests=[];old="native-8";nom="chart48-8";controls=[]
    for label,bank in sets.items():
        for (arm,flow,time,shell),values in bank.items():
            if label in (nom,old,"frozen-8","small14-8"):
                avg=np.mean(values,axis=0)
                summary.append(dict(label=label,arm=arm,flow=flow,time=time,shell=shell,mean_delta_E=avg[1],mean_ordinary_work=avg[2],
                    mean_wave_work=avg[3],rms_delta_E=np.sqrt(np.mean(values[:,1]**2)),positive=int(sum(values[:,0]>0))))
            if flow=="forward":
                diff=values-bank[arm,"reverse",time,shell]
                signed.append(dict(label=label,arm=arm,time=time,shell=shell,mean_delta_E=np.mean(diff[:,1]),rms_delta_E=np.sqrt(np.mean(diff[:,1]**2)),
                    rms_pos_pc=1000*np.linalg.norm(diff[:,4:7])/np.sqrt(24),rms_speed_kms=np.linalg.norm(diff[:,7:10])/np.sqrt(24)))
    for test,coarse,fine in (("dense_boundary","small10-4","small14-4"),("small_time","small14-4","small14-8"),
           ("chart_to_small","chart48-8","small14-8"),("native_time","native-4","native-8"),("chart_time","chart12-4","chart12-8"),
           ("chart_boundary","chart8-4","chart12-4"),("chart_degree_20_32","chart20-4","chart12-4"),("chart_degree_32_48","chart12-8",nom),
           ("wave_resolution","wave2-8",nom)):
        for key in sets[coarse].keys() & sets[fine].keys():
            arm,flow,time,shell=key
            first,second=(sets[lab][key] for lab in (coarse,fine))
            def check(tag,source,left,right):
                loss=err(left,right)
                tests.append(dict(test=test,arm=arm,flow=flow,time=time,shell=shell,scope=tag,what=source,
                    relative=loss,passes=bool(loss<=.005)))
            for keyid,idx in (("total",1),("ordinary",2),("wave",3)):
                if keyid=="wave" and flow=="ordinary": continue
                check("same_stars",keyid,first[:,idx],second[:,idx])
                check("shell_mean",keyid,first[:,idx].mean(),second[:,idx].mean())
            if flow=="forward":
                fd,sd=(sets[lab][key]-sets[lab][arm,"reverse",time,shell] for lab in (coarse,fine))
                for keyid,idx in (("delta_E",1),("position",slice(4,7)),("velocity",slice(7,10))):
                    check("signed",keyid,fd[:,idx],sd[:,idx])
                check("signed_mean","delta_E",fd[:,1].mean(),sd[:,1].mean())
    for key,values in sets[nom].items():
        arm,flow,time,shell=key
        other=sets[old][key];frozen=sets["frozen-8"][key]
        controls.append(dict(arm=arm,flow=flow,time=time,shell=shell,old_delta_E=other[:,1].mean(),new_delta_E=values[:,1].mean(),
            source_change_frac=values[:,1].mean()/other[:,1].mean()-1,
            evolving_minus_frozen=values[:,1].mean()-frozen[:,1].mean(),rms_change=np.sqrt(np.mean((values[:,1]-other[:,1])**2))))
    table("shell-work.csv",summary);table("sign-separation.csv",signed);table("source-intervention.csv",controls)
    tests.sort(key=lambda row:tuple(row.values())[:7]);table("evolution-refinements.csv",tests)
    groups={}
    for row in tests:
        key=row["test"]+"/"+row["scope"];group=groups.setdefault(key,dict(total=0,misses=0,worst=0.))
        group["total"]+=1;group["misses"]+=int(not row["passes"]);group["worst"]=max(group["worst"],row["relative"])
    record("evolution-verdict.json",groups)
if __name__=="__main__":run()
