from ledger import *
import re
import platform
import numpy as np,scipy
from local_release_field import CONV
from compare_release import LABELS
def verify():
    for base,hashval in PINS.items(): assert sha(base/"seal.json")==hashval
    for base in (OLD,WORK,GREEN):
        for name,val in readj(base/"seal.json").items(): assert sha(base/name)==val,name
    for name in ("PROTOCOL.md","DERIVATION.md","RESULTS.md"):
        assert (HOME/name).is_file()
        for link in re.findall(r"\]\(([^)]+)\)",(HOME/name).read_text(encoding="utf8")):assert (HOME/link).is_file(),link
    checks=rows(HOME/"evolution-refinements.csv");assert len(checks)==4860 and all(row["passes"]=="True" for row in checks)
    direct=rows(HOME/"newton-checks.csv");assert len(direct)==125 and all(row["passes"]=="True" for row in direct)
    assert max(readj(HOME/"dense-control.json").values())<.005
    native_fails=rows(pin(OLD,"source-patch-verification.csv"))
    assert any(row["test"]=="compare_q6-w4-b9-n32" and row["passes"]=="False" for row in native_fails)
    trajectory=[]
    for label in LABELS:
        short=label.startswith("small");samples=3 if short else 6
        pts=rows(HOME/f"stars-{label}.csv");balances=rows(HOME/f"balance-{label}.csv");centres=rows(HOME/f"centres-{label}.csv")
        assert len(pts)==5*72*samples and len(balances)==len(centres)==5*samples
        assert {(v["prep"],v["flow"]) for v in balances}=={("reset","ordinary"),("reset","forward"),("reset","reverse"),("coupled","forward"),("coupled","reverse")}
        assert len(set((row["flow"],row["prep"],row["star"],row["time"]) for row in pts))==len(pts)
        assert all(float(row["balance_rel"])<.005 and float(row["balance_max_per_binding"])<1e-9 for row in balances)
        assert all(abs(float(row["max_abs_dimensionless_coordinate"]))<=1+1e-9 for row in balances if row["max_abs_dimensionless_coordinate"])
        assert all(float(row["wave_work"])==0 for row in pts if row["flow"]=="ordinary")
        trajectory.append(dict(case=label,stars_times_arms=len(pts),worst_work_relative=max(float(row["balance_rel"]) for row in balances),
                          max_initial_binding_fraction_error=max(float(row["balance_max_per_binding"]) for row in balances)))
    assert all(len(rows(HOME/f"dense-{snap}-q14.csv"))==33 for snap in (586,590))
    norms=rows(HOME/"wave-normalization.csv");assert len(norms)==24 and max(float(row["relative"]) for row in norms)<1e-9
    feedback=rows(HOME/"initial-feedback-checks.csv");assert len(feedback)==48 and max(float(row["relative"]) for row in feedback)<.005
    exact=rows(HOME/"independent-quantum-control.csv");assert len(exact)==27 and max(float(row["relative"]) for row in exact)<.005
    wave=rows(HOME/"weak-field-feedback.csv");assert len(wave)==12 and all(float(row["wave_enclosed_mass_curvature_Msun_Myr2"])<0 for row in wave)
    table("work-balance-verification.csv",trajectory)
    record("verification.json",dict(predecessors={base.name:val for base,val in PINS.items()},versions=dict(python=platform.python_version(),numpy=np.__version__,scipy=scipy.__version__),
        cases=list(LABELS),evolution_checks=len(checks),direct_force_checks=len(direct),feedback_checks=len(feedback),quantum_controls=len(exact),
        largest_evolution_change=max(float(row["relative"]) for row in checks),largest_direct_check=max(float(row["relative_norm"]) for row in direct if row["kind"]=="chart_q12_n48"),
        conditional_star_evolution=True,self_consistent_wave_replay=False))
    files=sorted(path for path in HOME.iterdir() if path.name!="seal.json")
    assert all(path.is_file() and path.stat().st_size for path in files)
    for path in files:
        if path.suffix==".csv":
            values=rows(path);assert values and all(None not in row and None not in row.values() for row in values),path
        if path.suffix==".py":compile(path.read_bytes(),str(path),"exec")
    record("seal.json",{path.name:sha(path) for path in files})
    assert all(sha(HOME/name)==val for name,val in readj(HOME/"seal.json").items())
    print(len(files),sha(HOME/"seal.json"))
if __name__=="__main__":verify()
