from native import *
from numpy.polynomial.legendre import legvander,legint,legval,legder
from scipy.interpolate import CubicHermiteSpline
from scipy.optimize import root

class Even:
    def __init__(self,host,products,order):
        folder=BASE if host.snap==572 else EARLY
        hist=None
        for part in range(4):
            with np.load(pin(folder,f"mass-{host.snap}-{part}.npz")) as bank:
                block=bank["hist"][:,1].sum(axis=0);edges=bank["edges"];mu=bank["mu"]
                hist=block if hist is None else hist+block
        self.axis=host.rot[-1]/np.linalg.norm(host.rot[-1])
        dirs,wt=sphere(order)
        pol=legvander(dirs[:,2],12)[:,::2][:,1:]*np.arange(5,26,4)
        rgrid=np.geomspace(.1,600,241)
        disk=[];dslope=[]
        for chunk in np.array_split(rgrid,16):
            native=products.disk((chunk[:,None,None]*dirs).reshape(-1,3)).reshape(len(chunk),len(dirs),4)
            disk.extend((native[:,:,0]*wt)@pol)
            dslope.extend((-np.einsum("raj,aj->ra",native[:,:,1:],dirs)*wt)@pol*chunk[:,None])
        disk=np.array(disk);dslope=np.array(dslope);self.curves=[]
        nodes,weights=roots_legendre(8);half=np.diff(edges)/2
        rq=edges[:-1,None]+half[:,None]*(1+nodes)
        massweight=weights[None,:]*rq**2
        massweight/=massweight.sum(axis=1)[:,None]
        for col,ell in enumerate(range(2,13,2)):
            coeff=np.zeros(ell+1);coeff[-1]=1
            avg=np.diff(legval(mu,legint(coeff)))/np.diff(mu)
            mm=(hist@avg)[:,None]*massweight
            interior=np.r_[0,np.cumsum(np.sum(mm*(rq/100)**ell,axis=1))]
            exterior=np.r_[np.cumsum(np.sum(mm*(rq/100)**(-ell-1),axis=1)[::-1])[::-1],0]
            rad=edges[1:];x=rad/100
            ll=interior[1:]*x**(-ell-1);rr=exterior[1:]*x**ell
            vp=-G/100*(ll+rr);grad=G/100*((ell+1)*ll-ell*rr)
            curve=CubicHermiteSpline(np.log(rad),vp,grad)
            base=curve(np.log(np.minimum(rgrid,500)))
            slope=curve(np.log(np.minimum(rgrid,500)),1)
            outside=rgrid>500
            base[outside]=vp[-1]*(500/rgrid[outside])**(ell+1);slope[outside]=-(ell+1)*base[outside]
            self.curves.append((ell,CubicHermiteSpline(np.log(rgrid),base-disk[:,col],slope-dslope[:,col]),600.,base[-1]-disk[-1,col]))
    eval=WaveAngular.eval

class Smooth:
    def __init__(self,host,order=16):
        self.h=host;self.p=Products(host);self.order=order
        self.mono=self.p.monopoles(order);self.even=Even(host,self.p,order);self.wave=WaveAngular(host)
    def fields(self,points,even=True):
        pos=np.atleast_2d(points);r=np.linalg.norm(pos,axis=1)
        assert r.min()>.1 and r.max()<600.000001
        disk=self.p.base(pos,"disk");halo=self.p.base(pos,"halo")
        full=disk+halo
        sub=self.mono(np.log(r))
        pot,mass=self.h.ordinary.eval(r)
        ordinary=disk.copy();ordinary[:,0]+=pot-sub
        ordinary[:,1:]+=(self.mono(np.log(r),1)/r**2-G*mass/r**3)[:,None]*pos
        if even:ordinary+=self.even.eval(pos)
        wave=ordinary.copy()
        wave+=self.wave.eval(pos);wp,wm=self.h.wave.eval(r);wave[:,0]+=wp;wave[:,1:]-=(G*wm/r**3)[:,None]*pos
        return {"ordinary":ordinary,"wave":wave,"cold":full}
    def target(self,x,branch,frame,K):
        return self.fields(np.atleast_2d(x))[branch][0,1:]+K*x-frame
    def jacobian(self,pos,branch,frame,K,step=.03):
        samples=np.r_[pos+np.eye(3)*step,pos-np.eye(3)*step]
        acc=self.fields(samples)[branch][:,1:]+K*samples-frame
        return ((acc[:3]-acc[3:])/(2*step)).T
def radial_check(smooth):
    result=[];sym=[];counter=[];frames=[]
    kin=read(HERE/"frame-kinematics.csv")
    for res in (12,24,40):
        dirs,wt=sphere(res)
        for radius in (50.,100.,150.,200.,250.,300.,350.,400.,450.,500.):
            pos=radius*dirs;fields=smooth.fields(pos)
            for branch,values in fields.items():
                force=values[:,1:]+smooth.h.cosmic*pos
                inward=-np.einsum("ij,ij->i",force,dirs)
                loc=np.argmin(inward);size=np.linalg.norm(force,axis=1)
                result.append(dict(snap=smooth.h.snap,branch=branch,angular_order=res,r_kpc=radius,
                    min_inward=inward[loc],mean_inward=wt@inward,max_inward=inward.max(),
                    min_force_amplitude=size.min(),optimal_tide_units=inward[loc]/radius))
    dirs,wt=sphere(24)
    for branch in ("ordinary","wave","cold"):
        for aperture in (1.,10.,50.,200.):
            arr=smooth.fields(aperture*dirs)[branch][:,0]
            bulk=-3/aperture*((arr-wt@arr)*wt)@dirs
            frames.append(dict(snap=smooth.h.snap,branch=branch,aperture=aperture,
                bulk_x=bulk[0],bulk_y=bulk[1],bulk_z=bulk[2],magnitude=np.linalg.norm(bulk)))
        local=smooth.fields(np.array([[130.,76.,42.],[-81.,210.,90.],[37.,-198.,-120.]]))[branch]
        pts=np.array([[130.,76.,42.],[-81.,210.,90.],[37.,-198.,-120.]])
        grad=np.array([(smooth.fields(pts+.02*basis)[branch][:,0]-smooth.fields(pts-.02*basis)[branch][:,0])/.04 for basis in np.eye(3)]).T
        sym.append(dict(snap=smooth.h.snap,branch=branch,relative_force_potential_error=np.max(np.linalg.norm(grad+local[:,1:],axis=1)/np.linalg.norm(grad,axis=1))))
    return result,sym,frames
if __name__=="__main__":
    result=[];sym=[];frames=[]
    for snap in SNAPS:
        smooth=Smooth(Center(snap));block,unit,bulk=radial_check(smooth)
        result.extend(block);sym.extend(unit);frames.extend(bulk)
        print(snap,[(r["branch"],round(r["min_inward"],3)) for r in block if r["r_kpc"]==500 and r["angular_order"]==40],unit,flush=True)
    rows("smooth-radial.csv",result);rows("smooth-force-check.csv",sym);rows("aperture-frames.csv",frames)
