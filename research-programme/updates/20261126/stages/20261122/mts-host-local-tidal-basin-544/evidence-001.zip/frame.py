from products import BASE as URL
from fields import *
import requests
def collect():
    times=np.loadtxt(pin(BASE,"snapshot_times.txt"))
    need=sorted({epoch+offset for epoch in SNAPS for offset in (-4,-2,-1,0,1,2,4)})
    records=[]
    for snap in need:
        name=f"{snap}_coords_DR.txt"
        if (EARLY/name).exists():path=pin(EARLY,name)
        elif (BASE/name).exists():path=pin(BASE,name)
        else:
            path=HERE/name
            if not path.exists():
                with requests.get(URL+"potential/10kpc/"+name,stream=True,timeout=(8,25)) as rep:
                    rep.raise_for_status();raw=rep.raw.read(3001)
                assert 180<len(raw)<=3000 and b"center position" in raw
                keep(name,raw)
        vals=np.fromstring(" ".join(line for line in path.read_text().splitlines() if not line.startswith("#")),sep=" ")
        assert vals.size==17
        epoch,=times[times[:,0]==snap]; assert abs(vals[1]-1/(1+epoch[2]))<1e-7
        records.append(dict(snap=snap,url=URL+"potential/10kpc/"+name,sha256=digest(path),a=vals[1],t=epoch[3],
                            **{key:value for key,value in zip(("x","y","z","vx","vy","vz"),vals[2:8])}))
    rows("centres.csv",records)
def evaluate():
    data=read(HERE/"centres.csv")
    arr={int(row["snap"]):np.array([float(row[key]) for key in ("t","a","x","y","z","vx","vy","vz")]) for row in data}
    out=[]
    for snap in SNAPS:
        host=Center(snap);record=arr[snap]
        ah=host.h/10*np.sqrt(.272/host.a**3+.728)
        for width in (1,2,4):
            sample=np.array([arr[snap-width],arr[snap],arr[snap+width]])
            tau=(sample[:,0]-record[0])/.97779222168
            power=np.vander(tau,3,increasing=True)
            pp=np.linalg.solve(power,sample[:,2:5]-record[2:5])
            vv=np.linalg.solve(power,sample[:,5:])
            peculiar=record[1]*pp[1,:]
            acc_pos=record[1]*2*pp[2,:]+2*ah*peculiar
            acc_vel=vv[1,:]+ah*record[5:]
            out.append(dict(snap=snap,width=width,span_Myr=(sample[-1,0]-sample[0,0])*1000,
                     position_velocity_mismatch_kms=np.linalg.norm(peculiar-record[5:]),
                     acceleration_mismatch=np.linalg.norm(acc_pos-acc_vel),
                     **{key:value for key,value in zip(("apx","apy","apz","avx","avy","avz"),np.r_[acc_pos,acc_vel])}))
    rows("frame-kinematics.csv",out)
    print([(r["snap"],r["width"],round(r["acceleration_mismatch"],2)) for r in out])
if __name__=="__main__":collect();evaluate()
