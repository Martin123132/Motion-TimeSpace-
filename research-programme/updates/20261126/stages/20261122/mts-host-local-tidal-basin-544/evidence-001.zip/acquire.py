import hashlib
import json
from pathlib import Path
import requests
import h5py
import io

HERE=Path(__file__).resolve().parent
BASE="https://users.flatironinstitute.org/~mgrudic/fire2_public_release/core/m12i_res7100/"
def keep(name,raw):
    path=HERE/name
    assert not any((p/"STOP-REQUESTED").exists() for p in (HERE,HERE.parent))
    if path.exists():assert path.read_bytes()==raw,name
    else:
        with path.open("xb") as stream:stream.write(raw)
def run():
    out=[]
    for snap in (544,558,572):
        name=f"halo_{snap}.hdf5";url=BASE+"halo/rockstar_dm/catalog_hdf5/"+name
        if (HERE/name).exists():raw=(HERE/name).read_bytes()
        else:
            with requests.get(url,timeout=(8,30),stream=True) as rep:
                rep.raise_for_status();raw=rep.raw.read(9_000_001)
            assert 1_000_000<len(raw)<=9_000_000 and raw[:8]==b"\x89HDF\r\n\x1a\n"
            with h5py.File(io.BytesIO(raw)) as data:assert len(data["mass"])==len(data["position"])
            keep(name,raw)
        out.append(dict(snapshot=snap,url=url,file=name,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()))
    keep("catalogues.json",(json.dumps(out,indent=2)+"\n").encode())
if __name__=="__main__":run()
