from gravity import Center, Model, G, HERE, LAST, SNAPS, pin, read, rows, np
import sys
from scipy.linalg import eigh
from scipy.special import roots_legendre
from scipy.optimize import brentq

sys.path.insert(0,str(LAST))
for filename in ("inputs.py","project.py","capture.py"):
    pin(LAST,filename)
import inputs as donor_io
from project import sheet_measure

def tidal(model):
    distance=np.linalg.norm(model.halos.pos,axis=1)
    limit=min(distance-model.halos.rvir)
    return limit, np.sum(G*model.halos.mass/(2*distance**3))

def radial_ceiling(model,radius):
    limit,curvature=tidal(model)
    assert np.all(radius<limit) and model.K>=0
    return model.central(radius)[0]+curvature*radius**2

def levels(model):
    match=[row for row in read(HERE/"saddle-endpoints.csv") if row["branch"]==model.kind and row["snap"]==str(model.host.snap) and row["channel"]=="embedded"]
    row,=match
    level=float(row["level"])
    assert abs(model.potential(np.array([float(row[k]) for k in "xyz"]))[0]-level)<1e-8
    boundary,=[v for v in read(HERE/"topology-certified.csv") if v["branch"]==model.kind and v["snap"]==row["snap"] and v["channel"]=="embedded" and float(v["shell_kpc"])==250]
    assert float(boundary["sphere_lower"])>level and float(boundary["sphere_lower"])>float(row["path_upper"])
    return level

def trial(radius,cap,count):
    freq=np.arange(1,count+1)*np.pi/cap
    phase=radius[:,None]*freq
    values=np.sin(phase);grad=np.cos(phase)*freq
    width=.3*cap
    coord=np.clip((radius-.7*cap)/width,0,1)
    env=1-coord**3*(10+coord*(-15+6*coord))
    deriv=-30*coord**2*(1-coord)**2/width
    second=-60*coord*(1-coord)*(1-2*coord)/width**2
    return env[:,None]*values,env[:,None]*grad+deriv[:,None]*values,second[:,None]*values+2*deriv[:,None]*grad-env[:,None]*values*freq**2

def witnesses(model,level,cap,kappa,count,order,ell=0):
    assert radial_ceiling(model,cap)<level
    source_edges=np.r_[model.host.radii,model.host.wave.edges]
    edges=np.unique(np.r_[0.,cap,source_edges[(source_edges>0)&(source_edges<cap)],.7*cap,np.linspace(0,cap,2*count+1)])
    nodes,weights=roots_legendre(order);half=np.diff(edges)[:,None]/2
    rad=(edges[:-1,None]+half*(1+nodes)).ravel();wt=(half*weights).ravel()
    values,der,second=trial(rad,cap,count)
    if ell:
        soft=(.1*cap)**2
        regular=(rad/np.sqrt(rad**2+soft))**ell
        ratio=ell*soft/(rad*(rad**2+soft))
        curvature=ratio**2-ratio*(1/rad+2*rad/(rad**2+soft))
        second=regular[:,None]*(second+2*ratio[:,None]*der+curvature[:,None]*values)
        der=regular[:,None]*(der+ratio[:,None]*values)
        values=regular[:,None]*values
    kinetic=.5*kappa**2
    gram=values.T@(wt[:,None]*values)
    eigen,vec=eigh(gram);good=eigen>eigen.max()*1e-9
    orth=vec[:,good]/np.sqrt(eigen[good])
    basis=values@orth;grad=der@orth
    potential=model.central(rad)[0]-.5*model.K*rad**2-level
    potential=potential+kinetic*ell*(ell+1)/rad**2 if ell else potential
    energy,rot=eigh(kinetic*grad.T@(wt[:,None]*grad)+basis.T@((wt*potential)[:,None]*basis))
    good=energy<-1.;energy=energy[good];rot=rot[:,good]
    states=basis@rot
    residual=-kinetic*second@(orth@rot)+(potential[:,None]-energy)*states
    distances=np.linalg.norm(model.halos.pos,axis=1)
    ratio=rad[:,None]/distances
    rms_ceiling=(ratio**2/np.sqrt(5*(1-ratio**2)))@(G*model.halos.mass/distances)
    loss=np.sqrt(wt@(residual**2+(rms_ceiling[:,None]*states)**2))/abs(energy)
    if ell:
        loss=np.sqrt(wt@((abs(residual)+np.sqrt(2*ell+1)*rms_ceiling[:,None]*abs(states))**2))/abs(energy)
    gram=states.T@(wt[:,None]*states)
    if len(gram)==0:return rad,wt,states,loss,1.
    assert np.linalg.norm(gram-np.eye(len(gram)),ord=2)<2e-6
    assert np.abs(states.T@(wt[:,None]*residual)).max()/max(abs(energy))<2e-6
    return rad,wt,states,loss,np.linalg.eigvalsh(gram)[-1]

def classical(bank,seed,model,level,cap,boost):
    epoch=float(bank["a"]); pos=bank["cdm_x"];mom=bank["cdm_p"]
    delta=np.diff(pos); ids=np.arange(len(delta)); outside=cap/(1000*epoch)
    low,high=[np.divide(v-pos[:-1],delta,out=np.zeros_like(delta),where=delta!=0) for v in (-outside,outside)]
    first=np.clip(np.minimum(low,high),0,1);last=np.clip(np.maximum(low,high),0,1)
    last[delta==0]=(abs(pos[:-1][delta==0])<=outside)
    width=last-first;begin=ids+first
    mass=np.diff(bank["cdm_M"])*width*(3*begin**2+3*begin*width+width**2)/(3*ids**2+3*ids+1)
    mass*=seed.coeff["cdm"]*donor_io.C**2/(2*donor_io.G_NUMBER)
    rmax=np.zeros_like(width);smax=np.zeros_like(width)
    for frac in (first,last):
        rx=(pos[:-1]+frac*delta)*1000*epoch
        speed=rx*seed.H(epoch)*donor_io.C/1000+(mom[:-1]+frac*np.diff(mom))*donor_io.C/epoch
        rmax=np.maximum(rmax,abs(rx));smax=np.maximum(smax,abs(speed))
    keep=mass>0
    total=mass.sum()
    ref=sheet_measure(bank,"cdm",cap,epoch,seed)["mass_Msun"]
    assert abs(total/ref-1)<1e-12
    bound=.5*(smax[keep]+boost)**2+radial_ceiling(model,rmax[keep])<level
    return total,mass[keep][bound].sum()

def run():
    core=[];wave=[];spectra=[];dust=[]
    for snap in SNAPS:
        host=Center(snap)
        for branch in ("ordinary","wave","cold"):
            model=Model(host,branch);level=levels(model);limit,_=tidal(model)
            for cap in (25.,50.,75.,100.,120.):
                if cap>=limit:continue
                roof=radial_ceiling(model,cap)
                core.append(dict(snap=snap,branch=branch,radius_kpc=cap,nearest_source_surface_kpc=limit,
                    saddle_level=level,ball_upper=roof,margin_kms2=level-roof))
    rows("connected-core.csv",core)
    host=Center(544);target=donor_io.grids()[-1]
    assert abs(host.wave.total/target-1)<1e-8
    speeds=(0.,np.linalg.norm(host.velocity))
    for scenario,branch in (("heavy","wave"),("cold","cold")):
        model=Model(host,branch);level=levels(model);seed=donor_io.Seed(scenario,"anchorA","heavy")
        cache={}
        for filename in donor_io.filenames(scenario):
            with np.load(donor_io.pin(donor_io.SHEET,filename)) as bank:
                epoch=float(bank["a"]);assert abs(epoch/host.a-1)<1e-6
                if scenario=="heavy":
                    donor=donor_io.Donor(bank["r"],bank["psi"],epoch,seed,32)
                    total=donor.mass(250);r_target=brentq(lambda rad:donor.mass(rad)-target,0.,100.)
                for cap in (50.,100.,120.):
                    if cap>=tidal(model)[0] or radial_ceiling(model,cap)>=level:continue
                    if scenario=="cold":
                        for boost in speeds:
                            enclosed,retained=classical(bank,seed,model,level,cap,boost)
                            dust.append(dict(file=filename,support_kpc=cap,boost_kms=boost,cdm_core_Msun=enclosed,
                                certainly_subthreshold_Msun=retained,fraction=retained/enclosed))
                    else:
                        wave.append(dict(file=filename,support_kpc=cap,core_Msun=donor.mass(cap),
                            core_over_target=donor.mass(cap)/target,target_Msun=target,target_radius_kpc=r_target,
                            allowed_offset_kpc=cap-r_target))
                        if cap>100:continue
                        for count,order in ((64,12),(96,12),(96,18)):
                            key=(cap,count,order,donor.kappa)
                            if key not in cache:cache[key]=witnesses(model,level,cap,donor.kappa,count,order)
                            rad,weight,states,loss,gram=cache[key]
                            amp=donor.field(rad)[0]
                            for boost in speeds:
                                overlap=(weight*amp*np.sinc(boost*rad/(donor.kappa*np.pi)))@states
                                lower=np.maximum(abs(overlap)-loss*np.sqrt(total),0)
                                floor=lower@lower/max(1.,gram)
                                spectra.append(dict(file=filename,support_kpc=cap,basis=count,order=order,
                                    boost_kms=boost,mass_cap_Msun=total,negative_modes=len(loss),
                                    contributing=int(sum(lower>0)),gram_max=gram,witness_Msun=floor,witness_over_target=floor/target))
    rows("formation-core.csv",wave);rows("formation-spectrum.csv",spectra);rows("cold-core.csv",dust)
if __name__=="__main__":run()

