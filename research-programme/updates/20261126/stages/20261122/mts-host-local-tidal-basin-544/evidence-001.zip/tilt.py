from smooth import *
from scipy.optimize import least_squares

def cart(rad,theta,phi):
    return rad*np.array([np.sin(theta)*np.cos(phi),np.sin(theta)*np.sin(phi),np.cos(theta)])
def lookup(smooth,branch,frame):
    direction=-frame/max(np.linalg.norm(frame),1e-20)
    if not np.linalg.norm(frame):return None
    rr=np.geomspace(21.,499.,40)
    force=smooth.fields(rr[:,None]*direction)[branch][:,1:]+smooth.h.cosmic*rr[:,None]*direction-frame
    axial=force@direction
    ids=np.flatnonzero((axial[:-1]<0)&(axial[1:]>=0))
    if not len(ids):return None
    ix=ids[-1]
    ini=[np.log(np.sqrt(rr[ix]*rr[ix+1])),np.arccos(direction[2]),np.arctan2(direction[1],direction[0])]
    shape=lambda q:cart(np.exp(q[0]),q[1],q[2])
    fit=least_squares(lambda q:smooth.target(shape(q),branch,frame,smooth.h.cosmic),ini,
        bounds=((np.log(20),-np.inf,-np.inf),(np.log(499.9),np.inf,np.inf)),xtol=1e-12,ftol=1e-12,gtol=1e-12,max_nfev=50)
    pos=shape(fit.x);err=np.linalg.norm(fit.fun)
    if err>1e-6:return None
    eig=np.linalg.eigvalsh(-smooth.jacobian(pos,branch,frame,smooth.h.cosmic))
    return pos,eig,err
def run():
    frames=read(HERE/"aperture-frames.csv");allkin=read(HERE/"frame-kinematics.csv")
    output=[]
    for snap in SNAPS:
        h=Center(snap);s=Smooth(h)
        for branch in ("ordinary","wave","cold"):
            choices=[("zero",np.zeros(3))]
            for row in frames:
                if row["snap"]==str(snap) and row["branch"]==branch:
                    choices.append(("aperture_"+row["aperture"],np.array([float(row[k]) for k in ("bulk_x","bulk_y","bulk_z")])))
            for row in allkin:
                if row["snap"]==str(snap) and row["width"]=="4":
                    for mode in ("ap","av"):
                        choices.append(("kinematic_unmatched_"+mode,np.array([float(row[mode+k]) for k in "xyz"])))
            for label,vec in choices:
                test=lookup(s,branch,vec)
                out=dict(snap=snap,branch=branch,frame=label,accel_norm=np.linalg.norm(vec),status="not_bracketed_in_20_500",
                    stationary_radius="",x="",y="",z="",hessian_min="",hessian_mid="",hessian_max="",residual="",unstable_time_Myr="")
                if test is not None:
                    pos,ev,err=test
                    out.update(status="index_one" if ev[0]<0<ev[1] else "not_index_one",stationary_radius=np.linalg.norm(pos),
                        x=pos[0],y=pos[1],z=pos[2],hessian_min=ev[0],hessian_mid=ev[1],hessian_max=ev[2],
                        residual=err,unstable_time_Myr=977.79222168/np.sqrt(-ev[0]) if ev[0]<0 else "")
                output.append(out)
    rows("frame-saddles.csv",output)
if __name__=="__main__":run()
