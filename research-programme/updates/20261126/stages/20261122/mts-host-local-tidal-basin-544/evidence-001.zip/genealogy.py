from fields import *
from acquire import BASE as URL
import requests
from collections import Counter
class Ranges(io.RawIOBase):
    def __init__(self):
        self.session=requests.Session()
        self.url=URL+"halo/rockstar_dm/catalog_hdf5/tree.hdf5"
        self.off=0;self.cache={};self.unit=16384
        self.frozen=(HERE/"tree-slices.npz").exists()
        if self.frozen:
            with np.load(HERE/"tree-slices.npz") as data:
                self.size=int(data["size"]);self.etag=str(data["etag"])
                self.cache={int(k):data[k].tobytes() for k in data if k.isdecimal()}
        else:
            self.size=3714704904;self.etag=None
    def tell(self):return self.off
    def seek(self,offset,whence=0):
        self.off=(0,self.off,self.size)[whence]+offset;return self.off
    def readinto(self,buffer):
        size=min(len(buffer),self.size-self.off);done=0
        while done<size:
            index,inside=divmod(self.off,self.unit)
            if index not in self.cache:
                assert not self.frozen and len(self.cache)<640
                first=index*self.unit;end=min(first+self.unit,self.size)-1
                with self.session.get(self.url,headers={"Range":f"bytes={first}-{end}","Accept-Encoding":"identity"},stream=True,timeout=(8,30)) as response:
                    assert response.status_code==206 and response.headers["Content-Range"]==f"bytes {first}-{end}/{self.size}"
                    etag=response.headers["ETag"]
                    assert self.etag in (None,etag)
                    self.etag=etag;raw=response.raw.read(self.unit+1)
                    assert len(raw)==end-first+1
                    self.cache[index]=raw
            block=self.cache[index];count=min(size-done,len(block)-inside)
            buffer[done:done+count]=block[inside:inside+count]
            self.off+=count;done+=count
        return done
    def seal(self):
        arrays={str(k):np.frombuffer(v,dtype=np.uint8) for k,v in self.cache.items()}
        buf=io.BytesIO();np.savez_compressed(buf,size=self.size,etag=self.etag,**arrays)
        if not self.frozen:keep("tree-slices.npz",buf.getvalue())
    def close(self):
        self.session.close();super().close()
def run():
    work={}
    for snap in SNAPS:
        h=Center(snap);external,inner=select(h)
        with h5py.File(HERE/f"halo_{snap}.hdf5") as f:
            for label,idx in (("host",h.host),("embedded",inner[np.argmax(h.bound[inner])]),("external",external[np.argmax(h.bound[external])])):
                work[snap,label]=(int(f["tree.index"][idx]),idx,int(h.ids[idx]))
    out=[]
    with Ranges() as remote:
        with h5py.File(remote) as tree:
            print("keys",[k for k in tree if k in ("descendant.index","snapshot","catalog.index","id","tid")],flush=True)
            for label in ("host","embedded","external"):
                head=work[544,label][0]
                for snap in range(544,573):
                    assert head>=0 and tree["snapshot"][head]==snap
                    idx=int(tree["catalog.index"][head]);child=int(tree["descendant.index"][head])
                    if snap in SNAPS:assert (head,idx)==work[snap,label][:2],(label,snap,head,idx,work[snap,label])
                    out.append(dict(object=label,snapshot=snap,tree_index=head,catalog_index=idx,descendant_index=child,
                        catalogue_id=work[snap,label][2] if snap in SNAPS else ""))
                    head=child
        remote.seal()
        info=dict(url=remote.url,size=remote.size,etag=remote.etag,range_bytes=sum(map(len,remote.cache.values())),read_blocks=len(remote.cache))
    rows("verified-descendants.csv",out);record("tree-provenance.json",info);print(info)
if __name__=="__main__":run()
