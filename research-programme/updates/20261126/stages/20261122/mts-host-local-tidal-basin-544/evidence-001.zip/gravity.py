from fields import *
from scipy.optimize import root
from scipy.special import xlogy

def shape(con):
    return np.log1p(con)-con/(1+con)
class Halos:
    def __init__(self,pos,mass,rvir,scale):
        self.pos=np.asarray(pos);self.mass=np.asarray(mass);self.rvir=np.asarray(rvir);self.scale=np.asarray(scale)
        assert np.all(self.mass>0) and np.all(self.scale>0) and np.all(self.rvir>0)
        self.norm=G*self.mass/shape(self.rvir/self.scale)
    def radial(self,dist,kind):
        inside=dist<self.rvir
        radius=np.maximum(dist,1e-12);coord=radius/self.scale
        if kind=="pot":
            value=-self.norm*(np.log1p(coord)/radius-1/(self.scale+self.rvir))
            return np.where(inside,value,-G*self.mass/radius)
        enclosed=np.where(inside,self.norm*shape(coord),G*self.mass)
        if kind=="enc":return enclosed
        return np.where(inside,self.norm*coord/(1+coord)**2/self.scale,0.)
    def calc(self,points,order=0):
        points=np.atleast_2d(points);diff=points[:,None,:]-self.pos
        dist=np.linalg.norm(diff,axis=-1)
        if order==0:return self.radial(dist,"pot").sum(axis=1)
        r=np.maximum(dist,1e-10);force=self.radial(r,"enc")/r**3
        if order==1:return np.einsum("ij,ijk->ik",force,diff)
        deriv=self.radial(r,"dq")
        return np.eye(3)*force.sum(axis=1)[:,None,None]+np.einsum("ij,ijk,ijl->ikl",(deriv/r**2-3*force)/r**2,diff,diff)
class Model:
    def __init__(self,host,kind,subset="exterior_plus_companion",minimum=1e8,extent=4000,cosmic=None):
        self.host=host;self.kind=kind;self.K=host.cosmic if cosmic is None else cosmic
        ex,inside=select(host,minimum,extent)
        self.comp=inside[np.argmax(host.bound[inside])]
        self.main_ext=ex[np.argmax(host.bound[ex])]
        self.idx=ex if subset=="exterior" else np.r_[ex,self.comp] if subset=="exterior_plus_companion" else np.r_[ex,inside]
        self.halos=Halos(host.pos[self.idx],host.bound[self.idx],host.radius[self.idx],host.scale[self.idx])
        self.zero=self.halos.calc(np.zeros(3))[0];self.grad0=self.halos.calc(np.zeros(3),1)[0]
        central_mass=host.mass[host.host]-host.bound[np.intersect1d(self.idx,inside)].sum()
        assert central_mass>0
        self.dark=Halos(np.zeros((1,3)),np.array([central_mass]),host.radius[[host.host]],host.scale[[host.host]])
    def central(self,radius):
        radius=np.asarray(radius);pot,mass=self.host.ordinary.eval(radius)
        if self.kind=="wave":
            more,term=self.host.wave.eval(radius);pot=pot+more;mass=mass+term
        if self.kind=="cold":
            pot=pot+self.dark.radial(radius[...,None],"pot")[...,0];mass=mass+self.dark.radial(radius[...,None],"enc")[...,0]/G
        return pot,mass
    def potential(self,points):
        pts=np.atleast_2d(points);r=np.linalg.norm(pts,axis=1)
        return self.central(r)[0]-.5*self.K*r*r+self.halos.calc(pts)-self.zero-pts@self.grad0
    def gradient(self,points):
        pts=np.atleast_2d(points);r=np.linalg.norm(pts,axis=1)
        return (G*self.central(r)[1]/np.maximum(r,1e-12)**3-self.K)[:,None]*pts+self.halos.calc(pts,1)-self.grad0
    def hessian(self,point):
        radius=np.linalg.norm(point);delta=radius*1e-5
        mass=self.central(radius)[1];dmdr=(self.central(radius+delta)[1]-self.central(radius-delta)[1])/(2*delta)
        unit=point/radius
        return (G*mass/radius**3-self.K)*np.eye(3)+G*(dmdr/radius**2-3*mass/radius**3)*np.outer(unit,unit)+self.halos.calc(point,2)[0]
    def line_upper(self,dest,count=512):
        arr=np.linspace(0.,1.,count+1)[:,None]*dest
        a,b=arr[:-1],arr[1:]
        rad=np.linalg.norm(arr,axis=1)
        dist=np.linalg.norm(arr[:,None,:]-self.halos.pos,axis=-1)
        up=self.central(rad[1:])[0]-.5*self.K*rad[:-1]**2+self.halos.radial(np.maximum(dist[:-1],dist[1:]),"pot").sum(axis=1)-self.zero+np.maximum(-a@self.grad0,-b@self.grad0)
        sample=self.potential(arr);loc=np.argmax(sample)
        return dict(path_max=sample[loc],path_upper=up.max(),path_peak_radius=rad[loc])
    def saddle(self,idx):
        dest=self.host.pos[idx];norm=np.linalg.norm(dest);direction=dest/norm
        fracs=1-np.geomspace(.001,.85,72)[::-1]
        grad=self.gradient(fracs[:,None]*dest)@direction
        hits=np.flatnonzero((grad[:-1]>0)&(grad[1:]<=0))
        candidates=[]
        for hit in hits:
            fit=root(lambda pos:self.gradient(pos)[0],dest*.5*(fracs[hit]+fracs[hit+1]),jac=self.hessian,tol=1e-10)
            hess=self.hessian(fit.x);eig,axis=np.linalg.eigh(hess)
            if np.linalg.norm(self.gradient(fit.x))<1e-6 and eig[0]<0<eig[1] and np.linalg.norm(fit.x-dest)<.8*norm:
                candidates.append((np.linalg.norm(fit.x-dest),fit.x,eig,axis[:,0]))
        if not candidates:return None
        _,pos,eig,axis=min(candidates,key=lambda v:v[0])
        return pos,eig,axis
    def shell(self,radius,nlat):
        dlat=np.pi/nlat;lon=(np.arange(2*nlat)+.5)*dlat
        covering=2*np.sin(np.sqrt(2)*dlat/4)
        lower=np.inf;upper=np.inf;best=None
        for lat in (np.arange(nlat)+.5)*dlat-np.pi/2:
            points=radius*np.c_[np.cos(lat)*np.cos(lon),np.cos(lat)*np.sin(lon),np.full(len(lon),np.sin(lat))]
            sep=np.linalg.norm(points[:,None,:]-self.halos.pos,axis=-1)
            arc=np.maximum(abs(np.linalg.norm(self.halos.pos,axis=1)-radius),sep-radius*covering)
            offset=self.central(np.asarray(radius))[0]-.5*self.K*radius**2-self.zero
            linear=-points@self.grad0
            low=offset+self.halos.radial(arc,"pot").sum(axis=1)+linear-radius*covering*np.linalg.norm(self.grad0)
            val=offset+self.halos.radial(sep,"pot").sum(axis=1)+linear
            if val.min()<upper:upper=val.min();best=points[np.argmin(val)]
            lower=min(lower,low.min())
        return lower,upper,best

