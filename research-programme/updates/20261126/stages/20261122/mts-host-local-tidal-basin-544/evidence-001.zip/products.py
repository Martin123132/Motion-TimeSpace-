from acquire import BASE,keep,HERE
import hashlib
import requests
import json

def acquire():
    provenance=[]
    for snap in (544,558,572):
        for name in (f"{snap}.bar.none_4.coef_cylsp_DR",f"{snap}.dark.none_4.coef_mul_DR"):
            url=BASE+"potential/10kpc/"+name
            if (HERE/name).exists():data=(HERE/name).read_bytes()
            else:
                with requests.get(url,stream=True,timeout=(8,30)) as reply:
                    reply.raise_for_status();data=reply.raw.read(2_000_001)
                assert len(data)<2_000_001 and data.startswith(b"[Potential]")
                keep(name,data)
            provenance.append(dict(file=name,url=url,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
    keep("field-provenance.json",(json.dumps(provenance,indent=2)+"\n").encode())
if __name__=="__main__":acquire()
