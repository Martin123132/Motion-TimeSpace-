from acquire import HERE,keep
import csv
import io
import json
import hashlib
import os
for key in ("OMP_NUM_THREADS","OPENBLAS_NUM_THREADS","MKL_NUM_THREADS","NUMEXPR_NUM_THREADS"):
    os.environ[key]="1"
import numpy as np
import h5py
from scipy.interpolate import PchipInterpolator
from scipy.special import roots_legendre
from numpy.polynomial.chebyshev import chebvander

ROOT=HERE.parent
BASE=ROOT/"mts-fire-joint-baryon-history-20261120"
EARLY=ROOT/"mts-pre572-wave-preparation-20261120"
LAT=ROOT/"mts-high-latitude-preparation-null-590-20261122"
GAL=ROOT/"mts-preparation-vertical-gravity-590-20261122"
LAST=ROOT/"mts-pre544-open-formation-match-20261122"
PINS={BASE:"19c78eaa158a766bd409c0a64504788b1346542eccee37c004083a918c480d67",
      EARLY:"ce9ca0f03916af1fa3bfd449a61e779a74ce3427fae0a3a6bcdf65bc2b6c70ee",
      LAT:"06e46c345f46f6e927fb493ea4dcfa95acd67f1e56885849189b42f6f35f8c71",
      GAL:"37a872fe0e0c207030ca5c4825940b22be066191dcfd3097d28f3169b104aef7",
      LAST:"0974a9b00d6c887fdeb34d97339bbf5bf1d6a5438d68df22fd031ba6a3652381"}
def digest(path):
    with path.open("rb") as stream:return hashlib.file_digest(stream,"sha256").hexdigest()
def pin(folder,name):
    assert not any((place/"STOP-REQUESTED").exists() for place in (ROOT,HERE,folder))
    assert digest(folder/"seal.json")==PINS[folder]
    idx=json.loads((folder/"seal.json").read_bytes())
    path=folder/name;assert digest(path)==idx.get("files",idx)[name]
    return path
def read(path):
    with path.open() as stream:return list(csv.DictReader(stream))
def rows(name,data):
    out=io.StringIO();writer=csv.DictWriter(out,data[0],lineterminator="\n",extrasaction="raise")
    writer.writeheader();writer.writerows(data);keep(name,out.getvalue().encode())
def record(name,data):keep(name,(json.dumps(data,sort_keys=True,indent=2,allow_nan=False)+"\n").encode())
G=4.30091727003628e-6
SNAPS=(544,558,572)
class Center:
    def __init__(self,snap):
        self.snap=snap
        folder=BASE if snap==572 else EARLY
        coord=np.fromstring(" ".join(line for line in pin(folder,f"{snap}_coords_DR.txt").read_text().splitlines() if not line.lstrip().startswith("#")),sep=" ")
        assert len(coord)==17
        self.h,self.a=coord[:2]
        self.raw=coord[2:5];self.velocity=coord[5:8]
        self.rot=coord[8:].reshape(3,3)
        shell=[];total=[]
        for piece in range(4):
            name=f"mass-{snap}-{piece}"
            with np.load(pin(folder,name+".npz")) as bank:
                edges=bank["edges"];hist=bank["hist"]
                mass=hist[:,0].sum(axis=2)
                assert np.max(abs((mass.sum(axis=1)/bank["apmass"][:,-1])-1))<1e-9
                shell.append(mass)
            meta=json.loads(pin(folder,name+".json").read_bytes())
            total.append(meta["mass_all_Msun"])
            self.time=meta["proper_time_Gyr"]
        self.ordtotal=np.sum(total)
        self.radii=edges;self.bins=np.sum(shell,axis=(0,1));self.ordinary=Shell(edges,self.bins)
        self.actual_baryon_mass=self.bins.sum()
        with np.load(pin(GAL,"launch.npz")) as bank:
            edges,knots,scale=bank["edges"],bank["knots"],bank["mscale"]/bank["length"]
        with np.load(pin(LAT,"native-map.npz")) as bank:ids,root=bank["indices"],bank["sqrt"]
        with np.load(pin(EARLY,"state-anchorA-three-64.npz")) as bank:
            vec=bank["states"][list(bank["snapshots"]).index(snap)]
        native=np.pad(vec.reshape(len(root),-1)/root[:,None],((1,1),(0,0)))[ids]
        nodes,weights=roots_legendre(10);basis=chebvander(nodes,len(knots)-1)@np.linalg.inv(chebvander(2*knots-1,len(knots)-1))
        density=np.sum(abs(np.einsum("ji,eil->ejl",basis,native))**2,axis=2)
        bins=(density@weights)*(np.diff(edges)*.5*scale)
        self.wave=Shell(edges,bins)
        native_mass=scale*float(json.loads(pin(LAT,"native-units.json").read_bytes())["length_kpc"])*np.vdot(vec,vec).real
        assert abs(bins.sum()/native_mass-1)<1e-8
        receipt=next(r for r in json.loads((HERE/"catalogues.json").read_bytes()) if r["snapshot"]==snap)
        file=HERE/receipt["file"];assert digest(file)==receipt["sha256"]
        with h5py.File(file) as bank:
            assert int(bank["snapshot:index"][()])==snap and abs(float(bank["snapshot:scalefactor"][()])-self.a)<1e-6
            def vector(key):return bank[key][:].astype(float)
            delta=vector("position")-self.raw
            box=bank["info:box.length"][()];delta-=box*np.rint(delta/box)
            self.pos=delta*self.a;self.dist=np.linalg.norm(self.pos,axis=1)
            self.mass=vector("mass");self.bound=vector("mass.bound");self.radius=vector("radius")
            self.scale=vector("scale.radius");self.alternate_scale=vector("scale.radius.klypin");self.ids=bank["id"][:];self.low=vector("mass.lowres")
            self.phantom=bank["am.phantom"][:].astype(bool)
            main=np.where((self.dist<5)&~self.phantom)[0];self.host=main[np.argmax(self.mass[main])]
            assert self.dist[self.host]<.5 and self.mass[self.host]>5e11
            hub=bank["cosmology:hubble"][()]/10
            self.lambda_term=hub**2*bank["cosmology:omega_lambda"][()]
            self.cosmic=self.lambda_term-hub**2*.5*bank["cosmology:omega_matter"][()]/self.a**3

class Shell:
    def __init__(self,edges,bins):
        self.edges=edges;self.bins=bins;self.total=bins.sum()
        low,high=edges[:-1],edges[1:]
        volume=(high-low)*(high**2+high*low+low**2)
        self.factor=bins/volume
        self.left=np.r_[0.,np.cumsum(bins)]
        piece=1.5*self.factor*(high-low)*(high+low)
        self.tail=np.r_[np.cumsum(piece[::-1])[::-1],0.]
    def eval(self,r):
        r=np.asarray(r);cell=np.minimum(np.searchsorted(self.edges[1:],r),len(self.bins)-1)
        low=self.edges[cell];high=self.edges[cell+1];loc=np.minimum(r,high)
        m=self.left[cell]+self.factor[cell]*(loc-low)*(loc*loc+loc*low+low*low)
        rest=self.tail[cell+1]+1.5*self.factor[cell]*(high-loc)*(high+loc)
        return -G*(np.divide(m,r,out=np.zeros_like(r,dtype=float),where=r>0)+rest),m

def select(host,minimum=1e8,extent=4000):
    valid=(host.dist<extent)&(host.mass>=minimum)&(host.bound>0)&(host.low<=.01*host.mass)&~host.phantom
    candidates=np.flatnonzero(valid&(host.radius>0)&(host.scale>0))
    candidates=candidates[np.argsort(-host.mass[candidates],kind="stable")]
    external=[];interior=[]
    for idx in candidates:
        if idx==host.host:continue
        front=interior if host.dist[idx]<host.radius[host.host] else external
        if front:
            other=np.array(front)
            if np.any(np.linalg.norm(host.pos[other]-host.pos[idx],axis=1)<host.radius[other]):continue
        front.append(idx)
    return np.array(external,dtype=int),np.array(interior,dtype=int)
if __name__=="__main__":
    for snap in SNAPS:
        host=Center(snap);ext,inner=select(host)
        print(snap,host.dist[host.host],host.ordinary.total,host.ordtotal,host.cosmic,len(ext),len(inner),
              [(host.ids[idx],round(host.dist[idx]),round(host.bound[idx]/1e9,2)) for idx in (*ext[:3],*inner[:3])])
