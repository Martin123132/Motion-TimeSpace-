import ast
import re
from fields import HERE,ROOT,PINS,pin,read,record,digest,json,np
from pathlib import Path

def table(name):return read(HERE/(name+".csv"))
def verify():
    assert __debug__ and not any((p/"STOP-REQUESTED").exists() for p in (HERE,ROOT))
    for path in HERE.glob("*.py"):ast.parse(path.read_text(encoding="utf-8-sig"))
    for folder,sha in PINS.items():assert digest(folder/"seal.json")==sha
    for name in ("field-provenance.json","catalogues.json"):
        for r in json.loads((HERE/name).read_text()):
            file=HERE/r["file"];assert digest(file)==r["sha256"] and file.stat().st_size==r["bytes"]
    chain=table("verified-descendants")
    for name in ("host","embedded","external"):
        series=[r for r in chain if r["object"]==name]
        assert [int(r["snapshot"]) for r in series]==list(range(544,573))
        assert all(a["descendant_index"]==b["tree_index"] for a,b in zip(series,series[1:]))
    fits=table("saddle-endpoints");assert len(fits)==18
    for r in fits:
        assert r["descents"]=="companion / host" and float(r["gradient"])<1e-6
        assert float(r["lambda1"])<0<float(r["lambda2"])<=float(r["lambda3"])
    barriers=[r for r in table("topology-certified") if r["channel"]=="embedded" and float(r["shell_kpc"])==250]
    assert len(barriers)==9 and min(float(r["certified_gap"]) for r in barriers)>0
    for name,key in (("certification-refinement","lower_gap"),("catalogue-controls","lower_gap"),("smooth-radial","min_inward"),("connected-core","margin_kms2")):
        assert all(float(r[key])>0 for r in table(name))
    assert max(float(r["relative_force_potential_error"]) for r in table("smooth-force-check"))<1e-6
    fine=[r for r in table("continuous-boost") if r["order"]=="18"];assert len(fine)==5
    cells=table("continuous-boost-cells");assert len(cells)==640
    for r in fine:
        group=[t for t in cells if t["file"]==r["file"]]
        assert len(group)==128 and all(t["speed_right"]==u["speed_left"] for t,u in zip(group,group[1:]))
        assert float(group[0]["speed_left"])==0 and group[-1]["speed_right"]==r["boost_end"]
        assert min(float(t["whole_cell_bound"]) for t in group)==float(r["all_speeds_bound"])
        assert (sum(float(t["whole_cell_bound"])>1 for t in group)==int(r["certified_cells_above_target"]))
    for r in table("continuous-boost"):
        ref,=[t for t in fine if t["file"]==r["file"]]
        assert (float(r["all_speeds_bound"])>1)==(float(ref["all_speeds_bound"])>1)
        if r["basis"]=="96":assert abs(float(r["all_speeds_bound"])-float(ref["all_speeds_bound"]))<3e-9
    assert len([r for r in fine if float(r["all_speeds_bound"])>1])==2
    spatial=table("formation-core")
    assert len(spatial)==15 and min(float(r["core_over_target"]) for r in spatial)>1
    dust=table("cold-core");assert len(dust)==30 and all(0<float(r["fraction"])<=1 for r in dust)
    controls=json.loads((HERE/"independent-controls.json").read_text())
    assert all(r["conditional_margin_with_exterior_baryons"]>0 for r in controls["refined_barriers"])
    assert all(0<=r["compact_lower"]<r["exact_projected"] for r in controls["box"])
    for doc in HERE.glob("*.md"):
        for addr in re.findall(r"\]\(([^)]+)\)",doc.read_text(encoding="utf-8-sig")):
            if "://" not in addr:assert (doc.parent/addr).is_file(),addr
    record("validation.json",dict(descendant_rows=len(chain),saddles_checked=len(fits),outer_certificates=len(barriers),
        catalogue_alternatives=len(table("catalogue-controls")),smooth_grid_comparisons=len(table("smooth-radial")),
        donor_spatial_comparisons=len(spatial),cold_comparisons=len(dust),speed_intervals=len(cells),
        all_speed_excess_cases=2,all_speed_inconclusive_cases=3,prior_pins={p.name:v for p,v in PINS.items()},
        limitation="Frozen reconstructed potential, co-centred conditional donors; numeric quadratures, not interval arithmetic; no formation or asymptotic escape assignment."))
    assert not (HERE/"__pycache__").exists()
    data={f.name:digest(f) for f in sorted(HERE.iterdir()) if f.is_file() and f.name!="seal.json"}
    record("seal.json",data)
    assert json.loads((HERE/"seal.json").read_bytes())==data
    print("Sealed:",len(data),digest(HERE/"seal.json"))
if __name__=="__main__":verify()

