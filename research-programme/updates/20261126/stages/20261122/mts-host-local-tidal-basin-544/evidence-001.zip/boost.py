from occupation import *
from scipy.special import spherical_jn

def run():
    model=Model(Center(544),"wave");level=levels(model)
    speed=np.linalg.norm(model.host.velocity);target=donor_io.grids()[-1]
    seed=donor_io.Seed("heavy","anchorA","heavy")
    cap=100.;output=[];quadratures={}
    monopole=read(HERE/"formation-spectrum.csv")
    for filename in donor_io.filenames("heavy"):
        with np.load(donor_io.pin(donor_io.SHEET,filename)) as bank:
            donor=donor_io.Donor(bank["r"],bank["psi"],float(bank["a"]),seed,32)
            total=donor.mass(250)
            for count,order in ((64,12),(96,12),(96,18)):
                numerator=0.;gram_max=1.
                for ell in range(5):
                    key=(donor.kappa,count,order,ell)
                    if key not in quadratures:
                        quadratures[key]=witnesses(model,level,cap,donor.kappa,count,order,ell)
                    rad,wt,states,loss,gram=quadratures[key]
                    amp=donor.field(rad)[0]
                    radial=amp*(1j**ell)*np.sqrt(2*ell+1)*spherical_jn(ell,rad*speed/donor.kappa)
                    floor=np.maximum(abs((wt*radial)@states)-np.sqrt(total)*loss,0)
                    added=floor@floor;numerator+=added;gram_max=max(gram_max,gram)
                    result=numerator/(gram_max*target)
                    if ell==0:
                        ref,=[float(r["witness_over_target"]) for r in monopole if r["file"]==filename and float(r["boost_kms"])>0 and float(r["support_kpc"])==cap and int(r["basis"])==count and int(r["order"])==order]
                        assert abs(result-ref)<2e-12
                    output.append(dict(file=filename,support_kpc=cap,boost_kms=speed,basis=count,order=order,ell=ell,
                        negative_ritz=len(loss),contributing=int(sum(floor>0)),new_numerator_over_target=added/target,
                        combined_gram_max=gram_max,cumulative_bound_over_target=result))
    rows("boost-partial-waves.csv",output)
if __name__=="__main__":run()

