from boost import *

def run():
    host=Center(544);model=Model(host,"wave");level=levels(model)
    cap=100.;vmax=np.linalg.norm(host.velocity);vs=np.linspace(0.,vmax,129)
    target=donor_io.grids()[-1];seed=donor_io.Seed("heavy","anchorA","heavy")
    knots=[];out=[];cache={}
    for filename in donor_io.filenames("heavy"):
        with np.load(donor_io.pin(donor_io.SHEET,filename)) as bank:
            donor=donor_io.Donor(bank["r"],bank["psi"],float(bank["a"]),seed,32)
            for count,order in ((64,12),(96,12),(96,18)):
                total=donor.mass(250);square=np.zeros_like(vs);gram_max=1.
                for ell in range(5):
                    key=(count,order,ell,donor.kappa)
                    if key not in cache:
                        rad,wt,states,loss,gram=witnesses(model,level,cap,donor.kappa,count,order,ell)
                        cache[key]=(rad,wt,states,loss,gram)
                    rad,wt,states,loss,gram=cache[key]
                    if not len(loss):continue
                    amp=donor.field(rad)[0]
                    lipschitz=np.sqrt(wt@(abs(amp)*rad)**2/(3*target))/donor.kappa
                    matrix=(wt*amp)[:,None]*states
                    for ids in np.array_split(np.arange(len(vs)),9):
                        kernel=spherical_jn(ell,vs[ids,None]*rad/donor.kappa)*np.sqrt(2*ell+1)
                        floor=np.maximum(abs(kernel@matrix)-np.sqrt(total)*loss,0)
                        square[ids]+=np.sum(floor**2,axis=1)
                    gram_max=max(gram_max,gram)
                unit=np.sqrt(square/(target*gram_max))
                assert np.all(abs(np.diff(unit)) <= lipschitz*np.diff(vs)+1e-10)
                bound=np.maximum((unit[:-1]+unit[1:]-lipschitz*np.diff(vs))/2,0)**2
                out.append(dict(file=filename,basis=count,order=order,boost_start=vs[0],boost_end=vs[-1],
                    cell_count=len(bound),lipschitz_per_kms=lipschitz,minimum_grid_bound=unit.min()**2,
                    all_speeds_bound=bound.min(),worst_cell_left=vs[np.argmin(bound)],
                    certified_cells_above_target=int(sum(bound>1))))
                if count==96 and order==18:
                    knots.extend(dict(file=filename,speed_left=vl,speed_right=vr,left_bound=bl**2,
                        right_bound=br**2,whole_cell_bound=bb) for vl,vr,bl,br,bb in zip(vs,vs[1:],unit,unit[1:],bound))
    rows("continuous-boost.csv",out);rows("continuous-boost-cells.csv",knots)
if __name__=="__main__":run()

