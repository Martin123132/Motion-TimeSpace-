from gravity import *
from scipy.integrate import solve_ivp

def descend(model,saddle,axis,dest):
    obj=model.host
    def leg(pos,which):
        def rhs(_,point):
            gr=model.gradient(point)[0];return -gr/max(np.linalg.norm(gr),1e-10)
        def inner(_,point):return np.linalg.norm(point)-4
        def near(_,point):return np.linalg.norm(point-dest)-2
        def outside(_,point):return 520-np.linalg.norm(point)
        for term in (inner,near,outside):term.terminal=True;term.direction=-1
        event=solve_ivp(rhs,(0,1600),pos,events=[inner,near,outside],max_step=2.5,rtol=2e-7,atol=2e-7)
        index=next((n for n,v in enumerate(event.t_events) if len(v)),None)
        return ("host","companion","outer")[index] if index is not None else "undecided"
    return sorted(leg(saddle+s*.1*axis,s) for s in (-1,1))
def run():
    outputs=[];gates=[];thresholds=[];fits=[]
    for snap in SNAPS:
        h=Center(snap)
        for kind in ("ordinary","wave","cold"):
            model=Model(h,kind)
            for channel,idx in (("embedded",model.comp),("external",model.main_ext)):
                dest=h.pos[idx];line=model.line_upper(dest,1024)
                rootdata=model.saddle(idx)
                base=dict(snap=snap,branch=kind,channel=channel,id=int(h.ids[idx]),mass_Msun=h.bound[idx],centre_kpc=h.dist[idx])
                if rootdata is not None:
                    pos,ev,axis=rootdata
                    ends=descend(model,pos,axis,dest)
                    fits.append(dict(**base,stationary_kpc=np.linalg.norm(pos),x=pos[0],y=pos[1],z=pos[2],
                        gradient=np.linalg.norm(model.gradient(pos)),lambda1=ev[0],lambda2=ev[1],lambda3=ev[2],
                        level=model.potential(pos)[0],descents=" / ".join(ends),**line))
                else:
                    fits.append(dict(**base,stationary_kpc="",x="",y="",z="",gradient="",lambda1="",lambda2="",lambda3="",level="",descents="no stationary bracket",**line))
                radii=(250.,300.,350.,400.,450.,500.) if channel=="embedded" else (500.,650.,850.,1100.)
                for radius in radii:
                    if radius<=h.dist[idx]:continue
                    low,high,site=model.shell(radius,40)
                    gap=low-line["path_upper"]
                    omitted=h.ordtotal-h.ordinary.total
                    cost=G*omitted*(radius**2/(500**2*(500-radius))+h.dist[idx]**2/(2*500**3)) if radius<500 else None
                    output=dict(**base,shell_kpc=radius,sphere_lower=low,sphere_upper=high,path_upper=line["path_upper"],certified_gap=gap,
                        max_uniform_frame_change_kms2_kpc=max(0.,gap)/(radius+h.dist[idx]),max_uniform_potential_error_kms2=max(0.,gap)/2,
                        max_symmetric_tide_kms2_kpc2=2*max(0.,gap)/(radius**2+h.dist[idx]**2),
                        omitted_baryon_cost=cost if cost is not None else "",after_omitted_baryon_lower_gap=gap-cost if cost is not None else "")
                    outputs.append(output)
                    if radius==250 and channel=="embedded":
                        for order,count in ((20,512),(64,2048)):
                            ll,hh,_=model.shell(radius,order);path=model.line_upper(dest,count)
                            gates.append(dict(**base,resolution=order,count=count,lower_gap=ll-path["path_upper"],upper_gap=hh-path["path_max"]))
            for label,cut,rmax,subset,kval in (("lower_mass",3e7,4000,"exterior_plus_companion",h.cosmic),("further",1e8,6000,"exterior_plus_companion",h.cosmic),("all_embedded",1e8,4000,"all",h.cosmic),("lambda",1e8,4000,"exterior_plus_companion",h.lambda_term),("isolated_background",1e8,4000,"exterior_plus_companion",0.)):
                alt=Model(h,kind,subset,cut,rmax,kval);dest=h.pos[alt.comp]
                ll,hh,_=alt.shell(250.,24);path=alt.line_upper(dest,1024);rootdata=alt.saddle(alt.comp)
                thresholds.append(dict(snap=snap,branch=kind,case=label,objects=len(alt.idx),distance=np.linalg.norm(rootdata[0]) if rootdata is not None else "",
                    sphere_kpc=250,lower_gap=ll-path["path_upper"],upper_gap=hh-path["path_max"]))
        print("finished catalogue",snap,flush=True)
    rows("topology-certified.csv",outputs);rows("certification-refinement.csv",gates)
    rows("saddle-endpoints.csv",fits);rows("catalogue-controls.csv",thresholds)
if __name__=="__main__":run()
