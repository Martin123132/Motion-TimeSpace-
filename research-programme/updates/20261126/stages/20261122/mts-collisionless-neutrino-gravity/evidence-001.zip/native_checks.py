from incident import *
from types import SimpleNamespace
def panel(one,two):return np.linalg.norm(one-two)/np.linalg.norm(two)
def sparse(model,boost,inc):
    with np.load(HOME/f'high-{model}-{boost}.npz') as bank:
        split=int(bank['start']);arr=dict(zip(bank['keys'],bank['values'].transpose(2,0,1)));k=bank['k'];idx=bank['indices'];t=bank['eta']
    inc.times=t[:split+1];inc.pre={key:val[:,:split+1] for key,val in arr.items()};inc.k=k
    raw={key:val[:,split:] for key,val in arr.items()};k=k[:,None];h=raw['adotoa'];sig=raw['sigma']
    phi=raw['etak']/k-h*sig/k
    inc.data=SimpleNamespace(eta=t[split:],first=dict(phi=phi,psi=2*raw['phi']-phi),background=dict(a=raw['a'][0]))
    return idx,raw
def main(model):
    inc=Incident(model);data=inc.data;du=data.raw;kk=data.nodes[:,None];h=du['adotoa'];z=(.5*du['dgrho']/kk+du['etak'])/h
    ufa=-3*du['pir']/data.eta+kk*(4*z/3+du['qr']);delta=abs(ufa-du['pirdot'])
    mask=delta<=1e-10*np.max(abs(du['pirdot']),axis=1)[:,None]
    rows=[];result=[];boostpairs={}
    with np.load(HOME/f'massless-{model}.npz') as f:ret=f['F']
    mid=ret[2];ref=du['pir'][:,::4]/4
    for lab,select in [('all',np.ones_like(ref,dtype=bool)),('fluid-identity',mask[:,::4]),('no-fluid-identity',~mask[:,::4])]:
        result.append(dict(model=model,selection=lab,samples=int(select.sum()),complete_legs=int(np.sum(select.all(axis=1))),quadrupole_panel=panel(mid[select],ref[select])))
    table('native-switch-'+model+'.csv',result)
    nodes,wt=roots_laguerre(12);mu=json.loads(ti.parent.pin('radiation-background.json').read_bytes())[model]
    for boost in (16,17):
        idx,raw=sparse(model,boost,inc);k=inc.k[:,None];sig=raw['sigma'];h=raw['adotoa'];a=raw['a'];shift=h*sig/k
        refs=[raw['clxr']/4-shift,raw['qr']/4+sig/3,raw['pir']/4,(2*k*(raw['qr']/4+sig/3)-5*raw['pirdot']/4)/(3*k)]
        state=inc.start(np.inf);flight=inc.flight(np.inf,state)
        send=lambda label,got,want:rows.append(dict(boost=boost,field=label,panel=panel(got,want),worst_leg=float(max(np.linalg.norm(got-want,axis=1)/np.maximum(np.linalg.norm(want,axis=1),1e-80)))))
        for ell,ref in enumerate(refs):
            send(f'self_metric_l{ell}',flight[0,ell],ref[:,::4])
            send(f'retained_metric_l{ell}',ret[ell,idx,::4],ref[:,::4])
        boostpairs[boost]=[ref[:,::4] for ref in refs]
        if boost!=17:continue
        er=raw['grhor_t'];eg=raw['grhog_t'];en=raw['grhonu_t']
        enp=en+raw['gpres']-(eg+er)/3-raw['w_lam']*raw['grhov_t']
        target=(en*raw['clxnu']-3*enp*shift,raw['dgq']-eg*raw['qg']-er*raw['qr']-raw['grhob_t']*raw['vb']-raw['grhov_t']*raw['qde']+enp*sig,raw['dgpi']-eg*raw['pig']-er*raw['pir'])
        sums=np.zeros((3,len(k),len(inc.data.eta[::4])));old=np.zeros_like(sums)
        for ix,q in enumerate(nodes):
            state=inc.start(q);flight=inc.flight(q,state)
            if ix in (0,3):
                eps=.001
                hi=inc.flight(q*np.exp(eps),inc.start(q*np.exp(eps)))
                lo=inc.flight(q*np.exp(-eps),inc.start(q*np.exp(-eps)))
                send('logq_derivative_node'+str(ix),flight[1,:6].reshape(-1,flight.shape[-1]),((hi[0,:6]-lo[0,:6])/(2*eps)).reshape(-1,flight.shape[-1]))
            ep=np.hypot(q,a[0,::4]*inc.mass);thermal=wt[ix]*expit(q)**2*q*mu['massless_limit_coeff']/(a[0,::4]**2*(7*np.pi**4/120))
            factors=thermal*np.array([q**2*ep+np.zeros_like(ep),q**3+np.zeros_like(ep),q**4/ep])[:,None,:]
            sums+=factors*flight[0,:3]
            with np.load(HOME/f'driver-{model}-q12-{ix}.npz') as f:old+=factors*f['low'][:,idx,::4]
        for i,lab in enumerate(('energy','momentum','shear')):
            send('massive_self_metric_'+lab,sums[i],target[i][:,::4]);send('massive_retained_metric_'+lab,old[i],target[i][:,::4])
    for ell,(one,two) in enumerate(zip(boostpairs[16],boostpairs[17])):send('native_boost16_vs17_l'+str(ell),one,two)
    table('independent-incident-'+model+'.csv',rows);print(model,'high angular reference checks complete')
if __name__=='__main__':main(sys.argv[1])
