from nu_io import *
import capture as driver
import diagnostics as diag
from sympy import Dummy
import tempfile,subprocess
NAMES='tau k a adotoa etak sigma phi clxr qr pir pirdot'.split()
def capture(model,func):
    native=diag.native;status=native.obj(native.source(f'runs/{model}/status.json'))
    path=native.SPEC/'runs/projection/a225-w6-d8.npz' if model=='heavy' else native.NATIVE/'runs/backgrounds/cold.npz'
    native.checked(path,status['source_hash'])
    for file in native.engine.inherited.native_hashes():native.checked(file,status['input_hashes'][str(file)])
    pars=native.engine.inherited.params_for(path,background_boost=8.);pars.DoLateRadTruncation=False
    bg=native.engine.camb.get_background(pars);bg.Params.Accuracy.IntTolBoost=6
    with np.load(pin(f'native-{model}.npz')) as ref:
        k=ref['k'];at=ref['eta'];raw=ref['custom'];names=ref['names'].tolist()
    early=np.r_[np.geomspace(.012,.40,41)[:-1],np.linspace(.40,at[0],1537)[:-1]]
    times=np.r_[early,at[::32]];sel=len(early)
    with pin(f'capture-{model}.csv').open() as fp:blocks=list(csv.DictReader(fp))
    values=[];checks=[]
    with patch.object(diag.symbolic,'compile_sympy_to_camb_source_func',return_value=func):
        for block in blocks:
            guard();a,b=int(block['first']),int(block['last'])+1;nodes=k[a:b]
            batch=np.unique(np.r_[nodes,float(block['control']),float(block['hierarchy_cap'])])
            ans=bg.get_time_evolution(batch,times,vars=[Dummy(s) for s in NAMES],lAccuracyBoost=4)[np.searchsorted(batch,nodes)]
            assert np.isfinite(ans).all()
            valid=abs(ans[:,:,1]-nodes[:,None])<1e-12
            assert valid[:,40:].all() and np.all(np.diff(valid.astype(int),axis=1)>=0)
            for key in ('etak','sigma','phi','qr','pir','pirdot'):
                v=ans[:,sel:,NAMES.index(key)];ref=raw[a:b,::32,names.index(key)]
                checks.append(dict(first=a,last=b-1,field=key,relative=np.linalg.norm(v-ref)/np.linalg.norm(ref)))
            values.append(ans[:,:sel+1,2:])
    vals=np.concatenate(values)
    pack('incident-prehistory-'+model+'.npz',k=k,eta=times[:sel+1],keys=NAMES[2:],values=vals)
    table('prehistory-control-'+model+'.csv',checks)
    print(model,'largest overlap deviation',max(r['relative'] for r in checks),flush=True)
if __name__=='__main__':
    if sys.argv[1:2]==['--child']:
        with patch.object(driver,'HERE',HOME),patch.object(driver,'NAMES',NAMES),patch.object(driver,'run',capture),patch.object(driver,'save',save):driver.main()
    else:
        with tempfile.TemporaryDirectory(dir=HOME,prefix='reader-') as tmp:
            subprocess.run([sys.executable,'-B',str(HOME/'prehistory.py'),'--child',tmp,*sys.argv[1:]],check=True)
