from assess import extract,metric
from nu_io import *

def main():
    paths=[];checks=[]
    def test(name,condition):
        assert bool(condition),name
        checks.append(dict(check=name,result='PASS'))
    test('synthetic angular source compared with direct sphere integration',len(read('direction-integral.csv'))==9 and max(float(v['max_error_over_channel_peak']) for v in read('direction-integral.csv'))<1e-11)
    for model in ('cold','heavy'):
        data=read(f'native-switch-{model}.csv')
        test(model+': native approximation identified, not silently used',int(data[1]['complete_legs'])==740 and int(data[2]['complete_legs'])==40)
        native=read(f'independent-incident-{model}.csv')
        test(model+': incident distribution independently measured on sentinels',len(native)==28 and max(float(row['worst_leg']) for row in native if 'retained_metric' in row['field'])<.005)
        direct=read(f'direct-gravity-{model}.csv')
        test(model+': nonlinear source null and superposition',len(direct)==140 and max(float(row['final_fraction']) for row in direct if row['test'] in ('zero vs saved','additivity'))<1e-11)
        stress=read(f'stress-balance-{model}.csv')
        test(model+': collisionless energy and longitudinal momentum at every probe',len(stress)==30 and max(float(row['residual_l2']) for row in stress)<.005)
        test(model+': omitted divergence term increases discrepancy',all(float(row['omission_control_l2'])>float(row['residual_l2']) for row in stress))
        join=read(f'arrival-joins-{model}.csv')
        test(model+': all incident sources and velocity-product join',len(join)==13 and max(float(row[k]) for row in join for k in ('direct','low','bulk'))<.005)
        test(model+': two time origins, separate numerical controls',len(read(f'arrival-gravity-{model}.csv'))==150)
        cons=read(f'matching-constraints-{model}.csv')
        test(model+': stress and Einstein matching constraints at actual launch',len(cons)==24 and max(float(row['scaled_error']) for row in cons)<2e-7)
        matched=read(f'matched-endpoint-{model}.csv')
        test(model+': particle-moment additivity and propagation refinements',len(matched)==240 and max(float(row['final_fraction']) for row in matched if row['test'] in ('sum of low and angular vs all','trace vs coordinate evolution','higher angular order and half time step'))<.005)
        saved=metric(model,'none');main=metric(model)
        for cells in (16,32):
            variants={rule:extract(HOME/f'matched-{model}-{cells}-{rule}-all-trace.npz') for rule in ('normal','coordinate')}
            for subject,arr in {**variants,'change of matching rule':variants['normal']-variants['coordinate']+saved,'in-window source only':main}.items():
                for pos,probe in enumerate(PROBES):
                    for col,name in enumerate(('lapse','weyl')):
                        z=(arr[-1,col,pos]-saved[-1,col,pos])/saved[-1,col,pos]
                        paths.append(dict(model=model,window=cells,case=subject,probe=str(probe),observable=name,fraction=abs(z),parallel=z.real,
                                            crosses_frozen_endpoint_gate=bool(abs(z)>=.005)))
        test(model+': held design reaches all probes with both backgrounds mapped separately',len([row for row in paths if row['model']==model])==80)
    table('decisions.csv',paths);table('validation.csv',checks)
if __name__=='__main__':main()
