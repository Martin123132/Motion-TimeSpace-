from incident import *
from scipy.special import eval_legendre
from scipy.sparse import csr_matrix
from multipoles import coeff
class Project:
    def __init__(self,data):
        modes=Mixed();self.ops=[]
        for coord in PROBES:
            op=ti.sources.Pair(modes,np.array(coord),type('Blank',(),{'first':{}}))
            ids=lambda mag:np.searchsorted(data.shell,np.rint(mag/modes.big.fund**2).astype(int))
            left,right=ids(op.q2),ids(op.p2)
            assert np.allclose(data.nodes[left]**2,op.q2,rtol=2e-14) and np.allclose(data.nodes[right]**2,op.p2,rtol=2e-14)
            k=np.sqrt(op.k2);p=np.r_[np.sqrt(op.p2),np.sqrt(op.q2)]
            h=np.r_[op.kp,op.kq]/(k*p);field=np.r_[right,left];metric=np.r_[left,right]
            phase=np.tile(op.phase,2)
            self.ops.append((op,k,p,h,field,metric,phase))
        self.data=data
    def calculate(self,F,D,q,maximum=16,match_bulk=True):
        data=self.data;times=data.eta[::4];size=len(times);num=len(data.nodes)
        use=lambda key:data.first[key][:,::4]
        phi,psi,pd=map(use,('phi','psi','pd'));G=phi+psi
        mass=json.loads(ti.parent.pin('radiation-background.json').read_bytes())[data.model]['mass_over_temperature']
        v=q/np.hypot(q,mass*data.background['a'][::4]) if np.isfinite(q) else np.ones(size)
        w=(1-q*np.tanh(q/2)) if np.isfinite(q) else -4.
        if match_bulk:vel=use('Vm') if np.isfinite(q) else use('Vr')
        src=np.zeros((5,maximum+1,size),complex);offset=np.zeros((5,size),complex)
        for axis,(op,k,p,h,field,metric,phase) in enumerate(self.ops):
            def mix(weights,first,second):
                weight=np.broadcast_to(weights,p.shape)
                contracted=csr_matrix((phase*weight,(field,metric)),shape=(num,num))@first
                return np.einsum('ij,ij->j',contracted,second)
            sr=src[axis]
            sr[0]+=2*mix(1.,phi,pd)
            sr[1]+=(mix(p*h,G,psi)-k*mix(1.,psi,psi))/(3*v)
            for ell in range(maximum+1):
                leg=eval_legendre(ell,h)
                sr[ell]-=mix(leg,pd,D[ell]+w*F[ell])
                for j in (ell-1,ell+1):
                    if j<0:continue
                    sign=1 if j<ell else -1;beta=(ell if j<ell else ell+1)/(2*ell+1)
                    npart=sign*beta*p*leg;qpart=sign*beta*k*eval_legendre(j,h)-npart
                    d=(2+j*(j+1)-ell*(ell+1))/2
                    sr[ell]+=v*mix(npart,G,F[j])-d*v*mix(qpart,phi,F[j])-mix(qpart,psi,D[j]+(w+d)*F[j])/v
            svel=-1.5*(op.kq*op.kp/op.k2-op.dot/3)
            factor=(2/15)*((1-w/2)/v**2-.5)
            if match_bulk:offset[axis]=-factor*mix(np.tile(svel,2),vel,vel)
        return src,offset
def run(model,nq):
    inc=Incident(model);inc.data.model=model;mapper=Project(inc.data)
    et=inc.data.eta[::4]
    nodes=roots_laguerre(nq)[0] if nq else [np.inf]
    for idx,q in enumerate(nodes):
        guard()
        name=f'driver-{model}-q{nq}-{idx}.npz'
        if (HOME/name).exists():
            raise FileExistsError(name)
        if np.isfinite(q):
            initial=inc.start(q);flight=inc.flight(q,initial);F,D=flight[0],flight[1]
        else:
            with np.load(HOME/f'massless-{model}.npz') as f:F=f['F']
            D=np.zeros_like(F)
        drive,shift=mapper.calculate(F,D,q)
        pack(name,q=q,eta=et,source=drive,C2=shift,low=F[:3],slope=D[:3])
        print(model,nq,idx,'direct collisionless sources frozen',flush=True)
if __name__=='__main__':run(sys.argv[1],int(sys.argv[2]))
