from nu_io import *
import prehistory as low
import diagnostics as diag
import capture as driver
from sympy import Dummy
import tempfile,subprocess
NAMES=low.NAMES+' grhonu_t grhor_t grhog_t grhob_t gpres grhov_t w_lam clxnu dgpi pig dgq qde qg vb etakdot dgrho'.split()
def run(model,func):
    native=diag.native;status=native.obj(native.source(f'runs/{model}/status.json'))
    bgfile=native.SPEC/'runs/projection/a225-w6-d8.npz' if model=='heavy' else native.NATIVE/'runs/backgrounds/cold.npz'
    native.checked(bgfile,status['source_hash'])
    for file in native.engine.inherited.native_hashes():native.checked(file,status['input_hashes'][str(file)])
    pars=native.engine.inherited.params_for(bgfile,background_boost=8.);pars.DoLateRadTruncation=False
    bg=native.engine.camb.get_background(pars);bg.Params.Accuracy.IntTolBoost=6
    with np.load(HOME/f'incident-prehistory-{model}.npz') as f:pre=f['eta'];k=f['k']
    with np.load(pin(f'native-{model}.npz')) as f:full=f['eta']
    times=np.r_[pre[:-1],full[::4]]
    indices=np.unique(np.r_[np.linspace(0,len(k)-1,16).astype(int),[0,12,27,40,41,50,77]])
    with patch.object(diag.symbolic,'compile_sympy_to_camb_source_func',return_value=func):
        for boost in (16,17):
            guard()
            ans=bg.get_time_evolution(k[indices],times,vars=[Dummy(s) for s in NAMES],lAccuracyBoost=boost)
            assert np.isfinite(ans).all() and np.allclose(ans[:,:,1],k[indices,None],rtol=1e-14,atol=0)
            pack(f'high-{model}-{boost}.npz',eta=times,k=k[indices],indices=indices,keys=NAMES[2:],values=ans[:,:,2:],start=len(pre)-1)
            print(model,boost,len(indices),'independent native controls',flush=True)
if __name__=='__main__':
    if sys.argv[1:2]==['--child']:
        def save_readout(name,data):save('high-'+name,data)
        with patch.object(driver,'HERE',HOME),patch.object(driver,'NAMES',NAMES),patch.object(driver,'run',run),patch.object(driver,'save',save_readout):driver.main()
    else:
        with tempfile.TemporaryDirectory(dir=HOME,prefix='reader-high-') as tmp:subprocess.run([sys.executable,'-B',str(HOME/'high_hierarchy.py'),'--child',tmp,*sys.argv[1:]],check=True)
