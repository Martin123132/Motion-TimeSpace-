from nu_io import *
from scipy.special import spherical_jn,roots_laguerre,expit
from scipy.integrate import cumulative_simpson

def weight(times):
    assert len(times)%2==1
    a,b=np.diff(times)[::2],np.diff(times)[1::2];total=a+b;w=np.zeros_like(times)
    w[:-2:2]+=total*(2-b/a)/6;w[1:-1:2]+=total**3/(6*a*b);w[2::2]+=total*(2-a/b)/6
    return w
class Incident:
    def __init__(self,model,limit=28):
        with np.load(HOME/f'incident-prehistory-{model}.npz') as f:
            self.pre=dict(zip(f['keys'],f['values'].transpose(2,0,1)));self.times=f['eta'];self.k=f['k']
        self.data=load_data(model)
        self.mass=json.loads(ti.parent.pin('radiation-background.json').read_bytes())[model]['mass_over_temperature']
        self.limit=limit;self.space=1/64
        arg=np.arange(int(np.max(self.k)*self.times[-1]/self.space)+6)*self.space
        self.lut=[]
        for ell in range(limit+1):
            j=spherical_jn(ell,arg);d=spherical_jn(ell,arg,True);dd=np.zeros_like(j)
            dd[1:]=(ell*(ell+1)/arg[1:]**2-1)*j[1:]-2*d[1:]/arg[1:]
            dd[0]=-1/3 if ell==0 else (2/15 if ell==2 else 0)
            self.lut.append((j,d,dd))
    def start(self,q,skip=0,stride=1):
        f=self.pre;grab=lambda key:f[key][:,skip::stride]
        t=self.times[skip::stride];assert t[-1]==self.times[-1]
        k=self.k[:,None];sigma=grab('sigma');etak=grab('etak')
        phi=etak/k-grab('adotoa')*sigma/k;psi=2*grab('phi')-phi
        a=grab('a')[0];v=q/np.hypot(q,self.mass*a) if np.isfinite(q) else np.ones_like(a);dv=v*(1-v*v)
        def remain(s):
            c=cumulative_simpson(s,x=t,initial=0);return c[-1]-c
        x=k*remain(v);dx=k*remain(dv)
        val=k*(v*phi+psi/v)*weight(t);slope=k*(1-v*v)*(v*phi-psi/v)*weight(t)
        pos=x/self.space;idx=np.floor(pos).astype(int);frac=pos-idx
        weights=[-(frac-1)*(frac-2)*(frac-3)/6,frac*(frac-2)*(frac-3)/2,-frac*(frac-1)*(frac-3)/2,frac*(frac-1)*(frac-2)/6]
        def lookup(arr):return sum(w*arr[idx+i] for i,w in enumerate(weights))
        theta0=grab('clxr')[:,0]/4-etak[:,0]/self.k
        theta1=grab('qr')[:,0]/4+sigma[:,0]/(3*v[0])
        dtheta1=-sigma[:,0]*(1-v[0]**2)/(3*v[0])
        theta2=grab('pir')[:,0]/4
        ini=x[:,0];di=dx[:,0];out=[]
        for ell,(j,d,dd) in enumerate(self.lut):
            d1=lookup(d);d2=lookup(dd);xj=spherical_jn(ell,ini);xd=spherical_jn(ell,ini,True)
            xdd=(ell*(ell+1)/ini**2-1)*xj-2*xd/ini
            xddd=-(2*ell*(ell+1)/ini**3)*xj+(ell*(ell+1)/ini**2-1+2/ini**2)*xd-2*xdd/ini
            coeff=theta0*xj+3*theta1*xd+2.5*theta2*(3*xdd+xj)
            change=(theta0*xd+3*theta1*xdd+2.5*theta2*(3*xddd+xd))*di+3*dtheta1*xd
            out.append([coeff+(val*d1).sum(axis=1),change+(slope*d1+val*dx*d2).sum(axis=1)])
        return np.moveaxis(out,1,0)
    def flight(self,q,state,sub=1):
        data=self.data;t=data.eta;eta=np.interp(np.arange((len(t)-1)*2*sub+1)/(2*sub),np.arange(len(t)),t)
        a=CubicSpline(t,data.background['a'])(eta)
        phi=CubicSpline(t,data.first['phi'],axis=1)(eta);psi=CubicSpline(t,data.first['psi'],axis=1)(eta)
        v=q/np.hypot(q,self.mass*a) if np.isfinite(q) else np.ones_like(a)
        k=self.k;ell=np.arange(state.shape[1])[:,None];lower=k*ell/(2*ell+1);upper=k*(ell+1)/(2*ell+1)
        def rhs(s,i):
            tr=np.zeros_like(s);tr[:,1:]+=lower[1:]*s[:,:-1];tr[:,:-1]-=upper[:-1]*s[:,1:]
            ds=v[i]*tr;dv=v[i]*(1-v[i]**2);ds[1]+=dv*tr[0]
            ds[0,1]+=k*(v[i]*phi[:,i]+psi[:,i]/v[i])/3
            ds[1,1]+=k*(1-v[i]**2)*(v[i]*phi[:,i]-psi[:,i]/v[i])/3
            return ds
        samples=[]
        for i in range(0,len(eta),2):
            if i%(8*sub)==0:
                cur=state.copy();cur[0,0]+=phi[:,i];samples.append(cur)
            if i+1==len(eta):break
            h=eta[i+2]-eta[i];one=rhs(state,i);two=rhs(state+h*one/2,i+1);three=rhs(state+h*two/2,i+1);four=rhs(state+h*three,i+2)
            state=state+h*(one+2*two+2*three+four)/6
        return np.moveaxis(samples,0,-1)
def run(model):
    inc=Incident(model);st=inc.start(np.inf);sol=inc.flight(np.inf,st)
    rr=inc.data.raw;kk=inc.k[:,None];s=rr['sigma'];h=rr['adotoa']
    refs=[inc.data.base['delta_neutrino']/4-h*s/kk,rr['qr']/4+s/3,rr['pir']/4,(2*kk*(rr['qr']/4+s/3)-5*rr['pirdot']/4)/(3*kk)]
    checks=[]
    for ell,ref in enumerate(refs):
        want=ref[:,::4];got=sol[0,ell];diff=got-want
        checks.append(dict(ell=ell,panel=np.linalg.norm(diff)/np.linalg.norm(want),worst_leg=max(np.linalg.norm(diff,axis=1)/np.linalg.norm(want,axis=1))))
    for label,other in [('later-launch',inc.start(np.inf,skip=8)),('half-prehistory-sampling',inc.start(np.inf,stride=2))]:
        checks.append(dict(ell=label,panel=np.linalg.norm(other[0,:18]-st[0,:18])/np.linalg.norm(st[0,:18]),worst_leg=max(np.linalg.norm(other[0,:18]-st[0,:18],axis=0)/np.linalg.norm(st[0,:18],axis=0))))
    table('incident-massless-check-'+model+'.csv',checks)
    pack('massless-'+model+'.npz',F=sol[0,:20],k=inc.k,eta=inc.data.eta[::4])
    print(model,checks,flush=True)
if __name__=='__main__':
    for model in sys.argv[1:]:run(model)
