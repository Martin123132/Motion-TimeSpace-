from pathlib import Path
import csv,hashlib,io,json,sys,os
for name in ('OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','OMP_NUM_THREADS','NUMEXPR_NUM_THREADS','BLIS_NUM_THREADS'):os.environ[name]='1'
sys.dont_write_bytecode=True
HOME=Path(__file__).resolve().parent
PH=HOME.parent/'mts-photon-angular-tail-20261122'
def sha(path):
    with path.open('rb') as fp:return hashlib.file_digest(fp,'sha256').hexdigest()
assert sha(PH/'seal.json')=='f625b5f020408a239e45b61850357979e6ef79548dc82a71ed417f768090b066'
manifest=json.loads((PH/'seal.json').read_bytes());manifest=manifest.get('files',manifest)
def pinph(name):
    path=PH/name;assert sha(path)==manifest[name],name;return path
for name in ('respond_tail.py','incident_tail.py','multipoles.py','tail_io.py','earlier.py'):pinph(name)
sys.path.insert(0,str(PH))
import tail_io as ti
from tail_io import np,patch,PROBES,Mixed,evolve,ExactPair,load_data,pin
from scipy.interpolate import CubicSpline
def guard():
    ti.guard();assert not (HOME/'STOP-REQUESTED').exists()
def save(name,blob):
    guard();path=HOME/name
    if path.exists():assert sha(path)==hashlib.sha256(blob).hexdigest(),name
    else:
        with path.open('xb') as fp:fp.write(blob)
def pack(name,**fields):
    buf=io.BytesIO();np.savez_compressed(buf,**fields);save(name,buf.getvalue())
def table(name,rows):
    buf=io.StringIO();out=csv.DictWriter(buf,rows[0],lineterminator='\n');out.writeheader();out.writerows(rows);save(name,buf.getvalue().encode())
def read(name):
    with (HOME/name).open() as fp:return list(csv.DictReader(fp))
guard()
