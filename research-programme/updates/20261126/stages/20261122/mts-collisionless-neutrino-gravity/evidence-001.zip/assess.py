from nu_io import *

def extract(path):
    with np.load(path) as f:
        assert np.array_equal(f['coord'],PROBES)
        names=f['names'].tolist();arr=f['values']
        assert np.isfinite(arr).all() and np.all(np.diff(f['eta'])>0) and arr.shape[0]==len(f['eta'])
        return np.stack([arr[:,names.index('psi')],(arr[:,names.index('psi')]+arr[:,names.index('phi')])/2],axis=1)

def metric(model,channel='both',nq=12,lim=16,stride=1,ell=18,kind='trace',sub=1):
    return extract(HOME/f'metric-{model}-{nq}-{channel}-{lim}-{stride}-{ell}-{kind}-{sub}.npz')

def rows(model,comparisons,ref,signal):
    out=[]
    for label,val in comparisons.items():
        assert val.shape==ref.shape and np.all(np.abs(ref[-1])>0) and np.all(np.abs(signal[-1])>0)
        for index,name in enumerate(('lapse','weyl')):
            for pos,probe in enumerate(PROBES):
                out.append(dict(model=model,test=label,observable=name,probe=str(probe),reference_abs=abs(ref[-1,index,pos]),
                            delta_real=val[-1,index,pos].real,delta_imag=val[-1,index,pos].imag,
                            final_fraction=abs(val[-1,index,pos]/ref[-1,index,pos]),signed_parallel=(val[-1,index,pos]/ref[-1,index,pos]).real,
                            over_direct_increment=abs(val[-1,index,pos]/signal[-1,index,pos]),window_peak_over_reference_peak=np.max(abs(val[:,index,pos]))/np.max(abs(ref[:,index,pos]))))
    return out

def main_stage(model):
    zero=metric(model,'none');full=metric(model);signal=full-zero
    earlier=extract(pinph(f'solution-{model}-16-trace-1-18-all.npz'))
    massive=metric(model,'massive')-zero;massless=metric(model,'massless')-zero
    comp={'augmented vs saved':full-earlier,'massless only':massless,'massive only':massive,'zero vs saved':zero-earlier,
          'additivity':signal-massive-massless,'source order 8':metric(model,lim=8)-full,'source order 12':metric(model,lim=12)-full,
          'source cadence x2':metric(model,stride=2)-full,'half step':metric(model,sub=2)-full,
          'state order 22':metric(model,ell=22)-full,'conserved minus trace':metric(model,kind='conserved')-full,
          'momentum 18, change of increment':(metric(model,nq=18)-metric(model,'none',nq=18))-signal,
          'massless native 0-2 hybrid':extract(HOME/f'closure-probe-{model}-2.npz')-full,
          'massless native 0-2 plus effective 3 hybrid':extract(HOME/f'closure-probe-{model}-3.npz')-full}
    result=rows(model,comp,earlier,signal)
    table(f'direct-gravity-{model}.csv',result)
    assert np.max(abs(comp['zero vs saved'])/np.max(abs(earlier),axis=0))<2e-12
    assert np.max(abs(comp['additivity'])/np.max(abs(earlier),axis=0))<2e-11
    print(model,[(key,'%.6g'%max(r['final_fraction'] for r in result if r['test']==key)) for key in comp],flush=True)

def incoming(model):
    zero=metric(model);signal=zero-metric(model,'none');output=[];seams=[]
    for idx in range(13):
        with np.load(HOME/f'arrival-source-{model}-{idx}.npz') as f:
            seams.append(dict(model=model,index=idx,q=str(float(f['q'])),low=float(f['join'][0]),bulk=float(f['join'][1]),direct=float(f['join'][2])))
    table(f'arrival-joins-{model}.csv',seams)
    for cells in (16,32):
        def expr(tag,channel):return extract(HOME/f'arrival-response-{model}-{cells}-{tag}-{channel}.npz')
        both=expr('main','both')-zero
        quad=expr('main','quad')-zero
        higher=expr('main','higher')-zero
        comp={'arriving l>=2':both,'arriving l2':quad,'arriving l>=3':higher,'additivity':both-quad-higher,
            'half forcing step':expr('half-step','both')-zero-both,'thinned incident source':expr('thinned-source','both')-zero-both,
            'more angles':expr('more-angles','both')-metric(model,ell=22)-both}
        if cells==16:short=both
        else:comp['32 minus 16 cells']=both-short
        assert np.max(abs(higher[0])/abs(zero[0]))<1e-10
        assert np.max(abs(comp['additivity'])/np.max(abs(zero),axis=0))<5e-11
        result=rows(model,comp,zero,signal)
        for row in result:row['cells']=cells
        output+=result
        print(model,cells,{key:max(r['final_fraction'] for r in result if r['test']==key) for key in comp},flush=True)
    table(f'arrival-gravity-{model}.csv',output)

if __name__=='__main__':
    for model in ('cold','heavy'):(incoming if 'arrival' in sys.argv else main_stage)(model)
