from drivers import Project
from metric import Gravity
from nu_io import *

def run(model):
    data=load_data(model)
    data.model=model
    operator=Project(data)
    raw=data.raw
    kn=data.nodes[:,None]
    shift=raw['sigma']
    dipole=raw['qr']/4+shift/3
    native=[data.base['delta_neutrino']/4-raw['adotoa']*shift/kn,dipole,raw['pir']/4,
            (2*kn*dipole-5*raw['pirdot']/4)/(3*kn)]
    with np.load(HOME/f'massless-{model}.npz') as bank:
        moments=bank['F']
        assert np.array_equal(bank['eta'],data.eta[::4]) and np.array_equal(bank['k'],data.nodes)
    with np.load(HOME/f'driver-{model}-q0-0.npz') as bank:
        base,base_offset=bank['source'],bank['C2']
    for highest in (2,3):
        for ell in range(highest+1):moments[ell]=native[ell][:,::4]
        test,offset=operator.calculate(moments,np.zeros_like(moments),np.inf)
        assert np.array_equal(offset,base_offset)
        gravity=Gravity(model,12)
        existing=gravity.src(data.eta[::4])
        existing[:,0]+=(test-base).transpose(2,1,0)/evolve.UNIT
        gravity.src=CubicSpline(data.eta[::4],existing)
        with patch.object(evolve,'guard',guard):result=gravity.integrate('trace')
        pack(f'closure-probe-{model}-{highest}.npz',eta=data.eta,coord=PROBES,values=result,names=evolve.OBS+['M3','E3'])

if __name__=='__main__':run(sys.argv[1])
