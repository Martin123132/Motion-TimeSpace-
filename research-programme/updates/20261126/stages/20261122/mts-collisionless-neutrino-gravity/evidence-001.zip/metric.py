from nu_io import *
from scipy.special import roots_laguerre,expit
from respond_tail import Response

class Gravity(Response):
    def __init__(self,model,nq,channel='both',limit=16,stride=1,ell=18):
        super().__init__(model,16,ell=ell)
        self.order=nq;self.nodes,wt=roots_laguerre(nq);self.weights=wt*expit(self.nodes)**2*self.nodes
        self.nu_sl=slice(self.nu_sl.start,self.nu_sl.start+(nq+1)*(ell+1));self.rows=self.nu_sl.stop
        if self.offset.shape[0]!=self.rows:
            assert not np.any(self.offset)
            self.offset=np.zeros((self.rows,5),complex)
        self.bkeys+=['clock'];self.back=CubicSpline(self.times,np.column_stack((self.back(self.times),self.times)))
        self.limit=limit;self.channel=channel;terms=[];offsets=[]
        for order,i in [(0,0)]+[(nq,idx) for idx in range(nq)]:
            with np.load(HOME/f'driver-{model}-q{order}-{i}.npz') as f:
                et=f['eta'][::stride];assert np.array_equal(et,self.times[::4*stride])
                yes=channel=='both' or channel==('massless' if not order else 'massive')
                terms.append(f['source'][:,:limit+1,::stride].transpose(2,1,0)*(1 if yes else 0))
                offsets.append(f['C2'][:,::stride].T*(1 if yes else 0))
        self.src=CubicSpline(et,np.stack(terms,axis=1)/evolve.UNIT)
        self.offset2=CubicSpline(et,np.stack(offsets,axis=1)/evolve.UNIT)
    def rhs(self,env,state,kind,variant,observe=False):
        result=super().rhs(env,state,kind,variant,observe)
        if observe:return result
        bg=env[0];t=bg['clock'];cor=self.offset2(t)
        v=np.r_[1,self.nodes/np.hypot(self.nodes,self.metas['mass_over_temperature']*bg['a'])][:,None]
        sub=result[self.nu_sl].reshape(self.order+1,self.lmax+1,-1)
        sub[:,:self.limit+1]+=self.src(t);sub[:,2]-=self.offset2(t,1)
        sub[:,1]-=2*self.kn*v*cor/3;sub[:,3]+=3*self.kn*v*cor/7
        return result

def run(model,which):
    configs={'primary':[(12,'both',16,1,18,'trace',1),(12,'massless',16,1,18,'trace',1),(12,'massive',16,1,18,'trace',1),(12,'none',16,1,18,'trace',1)],
             'checks':[(12,'both',8,1,18,'trace',1),(12,'both',12,1,18,'trace',1),(12,'both',16,2,18,'trace',1),(12,'both',16,1,18,'conserved',1),(12,'both',16,1,18,'trace',2),(12,'both',16,1,22,'trace',1)],
             'thermal':[(18,'both',16,1,18,'trace',1),(18,'none',16,1,18,'trace',1)]}[which]
    for nq,chan,lim,stride,ell,kind,sub in configs:
        guard();solver=Gravity(model,nq,chan,lim,stride,ell)
        with patch.object(evolve,'guard',guard):out=solver.integrate(kind,sub=sub)
        name=f'metric-{model}-{nq}-{chan}-{lim}-{stride}-{ell}-{kind}-{sub}.npz'
        pack(name,coord=PROBES,eta=solver.times,values=out,names=evolve.OBS+['M3','E3'])
        print(name,flush=True)
if __name__=='__main__':run(*sys.argv[1:])
