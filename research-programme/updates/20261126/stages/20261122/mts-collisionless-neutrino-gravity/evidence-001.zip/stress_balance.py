from drivers import Project
from nu_io import *
from scipy.sparse import csr_matrix
from scipy.special import roots_laguerre,expit

def compare(model):
    data=load_data(model);projection=Project(data)
    get=lambda key:data.first[key][:,::4]
    phi,psi,pd=map(get,('phi','psi','pd'));geom=phi+psi
    nleg,nt=phi.shape
    a=data.background['a'][::4]
    meta=json.loads(ti.parent.pin('radiation-background.json').read_bytes())[model]
    out=[]
    for count in (0,12,18):
        nodes,weights=roots_laguerre(count) if count else ([np.inf],[1])
        moments=np.zeros((4,nleg,nt))
        source=np.zeros((2,5,nt),complex)
        bg=lambda name:data.background[name][::4]
        rho=bg('enu') if count else bg('er')
        enthalpy=bg('enm') if count else 4*rho/3
        for index,q in enumerate(nodes):
            with np.load(HOME/f'driver-{model}-q{count}-{index}.npz') as f:
                low=f['low'];s=f['source']
            if count:
                ep=np.hypot(q,meta['mass_over_temperature']*a)
                weight=weights[index]*expit(q)**2*q*meta['massless_limit_coeff']/(a**2*(7*np.pi**4/120))
                energy=weight*q*q*ep;current=weight*q**3;pressure=weight*q**4/ep
            else:energy=current=pressure=4*rho
            moments+=np.array([energy*low[0],current*low[1],pressure*low[0],pressure*low[2]])
            source+=np.array([energy*s[:,0],current*s[:,1]])
        energy,flux,trace,shear=moments
        for seq,(op,k,p,h,field,metric,phase) in enumerate(projection.ops):
            def mix(weight,first,second):
                mat=csr_matrix((phase*np.broadcast_to(weight,p.shape),(field,metric)),shape=(nleg,nleg))
                return np.einsum('it,it->t',mat@first,second)
            qz=k-p*h;qp=k*h-p
            dens=pd
            energy_flux=-2*mix(qp,psi-phi,flux)
            energy_rhs=mix(1.,dens,3*energy+trace)+6*enthalpy*mix(1.,phi,pd)-mix(p,geom,flux)+energy_flux
            momentum_pressure=mix(3*h*qp-qz,phi,shear)
            momentum_rhs=4*mix(h,pd,flux)+mix(p*h,geom,(trace-2*shear)/3)+enthalpy*(mix(p*h,geom,psi)-k*mix(1.,psi,psi))+mix(qz,psi,energy+(trace+shear)/3)-mix(h*qp,psi,shear)+momentum_pressure
            for idx,(name,pred,deleted) in enumerate([('energy',energy_rhs,energy_flux),('longitudinal momentum',momentum_rhs,momentum_pressure)]):
                direct=source[idx,seq]
                diff=direct-pred
                scale=np.linalg.norm(direct)
                out.append(dict(model=model,momentum_nodes=count,probe=str(PROBES[seq]),equation=name,
                    residual_l2=np.linalg.norm(diff)/scale,peak_residual_over_peak=np.max(abs(diff))/np.max(abs(direct)),
                    omission_control_l2=np.linalg.norm(diff+deleted)/scale))
    table(f'stress-balance-{model}.csv',out)
    print(model,[(n,max(r['residual_l2'] for r in out if r['momentum_nodes']==n)) for n in (0,12,18)],flush=True)
if __name__=='__main__':
    for model in sys.argv[1:] or ('cold','heavy'):compare(model)
