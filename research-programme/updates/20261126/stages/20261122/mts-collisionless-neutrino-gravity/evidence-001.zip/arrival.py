from drivers import Project
from incident import Incident
from metric import Gravity
from nu_io import *
from types import SimpleNamespace
from scipy.special import roots_laguerre

def produce(model):
    inc=Incident(model);original=inc.data;ini=inc.times[-33]
    inc.times=inc.times[:-32]
    inc.pre={key:item[:,:-32] for key,item in inc.pre.items()}
    with np.load(HOME/f'arrival-metric-{model}.npz') as bank:
        t=bank['eta'];assert t[0]==ini and t[-1]==original.eta[0] and np.array_equal(bank['k'],inc.k)
        inc.data=SimpleNamespace(model=model,nodes=inc.k,shell=original.shell,eta=t,first={key:bank[key] for key in ('phi','psi','pd','Vr','Vm')},background=dict(a=bank['a'][0]))
    mapper=Project(inc.data);nodes=roots_laguerre(12)[0]
    for index,q in enumerate(np.r_[np.inf,nodes]):
        guard()
        state=inc.start(q);fl=inc.flight(q,state)
        force,offset=mapper.calculate(fl[0],fl[1],q)
        with np.load(HOME/(f'driver-{model}-q12-{index-1}.npz' if index else f'driver-{model}-q0-0.npz')) as joined:
            ref=joined['low'][:,:,0];base=joined['C2'][:,0];src=joined['source'][:,:,0]
            den=lambda val:max(float(np.linalg.norm(val)),1e-300)
            discrepancy=[den(fl[0,:3,:,-1]-ref)/den(ref),den(offset[:,-1]-base)/den(base),den(force[:,:,-1]-src)/den(src)]
        pack(f'arrival-source-{model}-{index}.npz',q=q,eta=t[::4],source=force,C2=offset,a=inc.data.background['a'][::4],join=discrepancy)
        print(model,index,'incident packet',flush=True)

def fly(time,src,boost,speed,k,ell,sub,thin):
    grid=time[::thin];assert grid[-1]==time[-1]
    kernel=CubicSpline(grid,src[:,:,::thin],axis=2)
    x=np.linspace(time[0],time[-1],2*sub*(len(time)-1)+1)
    force=kernel(x).transpose(2,1,0);v=CubicSpline(time,speed)(x)
    deg=np.arange(ell+1)[:,None];left=deg*k/(2*deg+1);right=(deg+1)*k/(2*deg+1)
    state=np.zeros((ell+1,len(k)),complex);state[2]=boost[:,0]
    def rhs(z,j):
        dz=np.zeros_like(z);dz[1:]=left[1:]*z[:-1];dz[:-1]-=right[:-1]*z[1:]
        dz*=v[j];dz[:force.shape[1]]+=force[j];return dz
    for j in range(0,len(x)-1,2):
        h=x[j+2]-x[j];one=rhs(state,j);two=rhs(state+h*one/2,j+1);three=rhs(state+h*two/2,j+1);four=rhs(state+h*three,j+2)
        state+=h*(one+2*two+2*three+four)/6
    state[2]-=boost[:,-1]
    return state

def arrivals(model):
    ev=Gravity(model,12);k=ev.kn
    for ncell in (16,32):
        for tag,ell,sub,thin in [('main',18,1,1),('half-step',18,2,1),('thinned-source',18,1,2),('more-angles',22,1,1)]:
            states=[]
            for i in range(13):
                with np.load(HOME/f'arrival-source-{model}-{i}.npz') as f:
                    select=slice(-4*ncell-1,None);time=f['eta'][select];q=f['q'];a=f['a'][select]
                    speed=q/np.hypot(q,ev.metas['mass_over_temperature']*a) if np.isfinite(q) else np.ones_like(a)
                    states.append(fly(time,f['source'][:,:,select],f['C2'][:,select],speed,k,ell,sub,thin))
            pack(f'arriving-{model}-{ncell}-{tag}.npz',states=states,eta=time[[0,-1]],k=k)
            for channel in (('both','quad','higher') if tag=='main' else ('both',)):
                solver=Gravity(model,12,ell=ell)
                masked=np.array(states)
                masked[:,:2]=0
                if channel=='quad':masked[:,3:]=0
                if channel=='higher':masked[:,2]=0
                solver.offset[solver.nu_sl]=masked.reshape(-1,len(k))/evolve.UNIT
                with patch.object(evolve,'guard',guard):out=solver.integrate('trace')
                pack(f'arrival-response-{model}-{ncell}-{tag}-{channel}.npz',values=out,coord=PROBES,eta=solver.times,names=evolve.OBS+['M3','E3'])
        print(model,ncell,'matched window finished',flush=True)

if __name__=='__main__':
    for model in sys.argv[1:]:
        produce(model);arrivals(model)
