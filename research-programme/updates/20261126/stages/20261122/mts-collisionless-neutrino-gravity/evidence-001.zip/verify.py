from nu_io import *
import ast,re
from zipfile import ZipFile

def validate():
    guard()
    assert not any(name.is_dir() for name in HOME.iterdir())
    for path in HOME.glob('*.py'):ast.parse(path.read_text(),filename=str(path))
    for path in HOME.glob('*.md'):
        for link in re.findall(r'\]\(([^)]+)\)',path.read_text(encoding='utf-8')):
            if not link.startswith('https:'):assert (HOME/link).is_file(),(path.name,link)
    for model in ('cold','heavy'):
        assert len(list(HOME.glob(f'driver-{model}-q*.npz')))==31
        assert len(list(HOME.glob(f'arrival-source-{model}-*.npz')))==13
        assert len(list(HOME.glob(f'matched-{model}-*.npz')))==16
        assert len(list(HOME.glob(f'arrival-response-{model}-*.npz')))==12
        assert len(list(HOME.glob(f'metric-{model}-*.npz')))==12
        for name in (f'sources-{model}.npz',f'native-{model}.npz',f'capture-{model}.csv'):pin(name)
        pinph(f'solution-{model}-16-trace-1-18-all.npz')
    assert len(read('decisions.csv'))==160 and len(read('validation.csv'))==21
    assert all(r['result']=='PASS' for r in read('validation.csv'))
    for path in HOME.glob('*.npz'):
        with ZipFile(path) as fp:assert fp.testzip() is None,path.name
    manifest={path.name:sha(path) for path in sorted(HOME.iterdir()) if path.name!='seal.json'}
    if '--seal' in sys.argv:save('seal.json',(json.dumps({'files':manifest},sort_keys=True,indent=2)+'\n').encode())
    assert json.loads((HOME/'seal.json').read_bytes())['files']==manifest
    print('verified',len(manifest),'files; seal',sha(HOME/'seal.json'))
if __name__=='__main__':validate()
