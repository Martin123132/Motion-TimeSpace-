from drivers import Project
from nu_io import *
from scipy.special import roots_laguerre,expit,eval_legendre,eval_jacobi
from types import SimpleNamespace

def angular():
    output=[]
    rng=np.random.default_rng(64117)
    polar,weights=np.polynomial.legendre.leggauss(48)
    angles=2*np.pi*(np.arange(96)+.31)/96
    directions=np.array(np.broadcast_arrays(np.sqrt(1-polar[:,None]**2)*np.cos(angles),np.sqrt(1-polar[:,None]**2)*np.sin(angles),polar[:,None]))
    mass=json.loads(ti.parent.pin('radiation-background.json').read_bytes())['cold']['mass_over_temperature']
    metric=np.array([.19,-.07]);lapse=np.array([.13,.33]);rate=np.array([.04,-.17]);total=metric+lapse
    field=rng.normal(size=(18,2,1));slope=rng.normal(size=(18,2,1))
    projector=object.__new__(Project)
    for vector in ((.9,.3,.7),(1.3,-.7,-.75),(.35,-.93,1.4)):
        k=1.12;vectors=np.array((vector,[-vector[0],-vector[1],k-vector[2]]))
        lengths=np.linalg.norm(vectors,axis=1);cosines=vectors[:,2]/lengths
        data=SimpleNamespace(eta=np.array([1.]),nodes=lengths,first=dict(phi=metric[:,None],psi=lapse[:,None],pd=rate[:,None]),background=dict(a=np.array([.001])),model='cold')
        projector.data=data
        op=SimpleNamespace(kq=k*vectors[1,2],kp=k*vectors[0,2],k2=k*k,dot=vectors[0]@vectors[1])
        projector.ops=[(op,k,lengths,cosines,np.arange(2),np.array([1,0]),np.ones(2))]
        for q in (np.inf,.12,3.4):
            v=q/np.hypot(q,mass*.001) if np.isfinite(q) else 1.
            w=1-q*np.tanh(q/2) if np.isfinite(q) else -4.
            f=field;dq=slope if np.isfinite(q) else np.zeros_like(slope)
            got=projector.calculate(f,dq,q,match_bulk=False)[0][0,:,0]
            driving=0j*directions[0]
            for idx in (0,1):
                other=1-idx;pn=np.einsum('i,ijk->jk',vectors[idx],directions)
                qn=np.einsum('i,ijk->jk',vectors[other],directions);mu=pn/lengths[idx]
                driving+=2*metric[other]*rate[idx]+1j*((qn+pn)*lapse[other]*lapse[idx]-pn*total[other]*lapse[idx])/v
                for degree in range(len(f)):
                    pol=eval_legendre(degree,mu)
                    grad=(degree+1)*eval_jacobi(degree-1,1,1,mu)/2 if degree else 0.
                    driving+=(-1j)**degree*(2*degree+1)*(-1j*v*total[other]*pn*f[degree,idx,0]*pol+
                        (1j*qn*lapse[other]/v-rate[other])*(dq[degree,idx,0]+w*f[degree,idx,0])*pol+
                        1j*(lapse[other]/v+v*metric[other])*(vectors[other]@vectors[idx]/lengths[idx]-qn*mu)*f[degree,idx,0]*grad)
            direct=np.array([1j**ell*(weights[:,None]*eval_legendre(ell,polar[:,None])*driving).sum()/192 for ell in range(len(got))])
            norm=np.max(abs(got-direct))/max(np.max(abs(direct)),1e-15)
            assert norm<1e-11,(q,got,direct)
            output.append(dict(first_vector=str(vector),q=str(q),max_error_over_channel_peak=norm))
    table('direction-integral.csv',output)

def frame():
    output=[]
    for model in ('cold','heavy'):
        data=load_data(model);et=data.eta[::4];a=data.background['a'][::4]
        meta=json.loads(ti.parent.pin('radiation-background.json').read_bytes())[model]
        with np.load(pin(f'sources-{model}.npz')) as f:target=f['values'][list(f['names']).index('nu_bulk'),:,::4]
        with np.load(HOME/f'driver-{model}-q0-0.npz') as f:massless=-4*data.background['er'][::4]*f['C2']
        for count in (12,18):
            add=np.zeros_like(massless)
            nodes,weights=roots_laguerre(count)
            for idx,q in enumerate(nodes):
                with np.load(HOME/f'driver-{model}-q{count}-{idx}.npz') as f:
                    assert q==f['q'] and np.array_equal(et,f['eta'])
                    coeff=weights[idx]*expit(q)**2*q*meta['massless_limit_coeff']/(a*a*(7*np.pi**4/120))*q**4/np.hypot(q,meta['mass_over_temperature']*a)
                    add-=coeff*f['C2']
            wanted=target-massless
            rel=np.linalg.norm(add-wanted)/np.linalg.norm(wanted)
            worst=max(np.linalg.norm(add-wanted,axis=1)/np.linalg.norm(wanted,axis=1))
            output.append(dict(model=model,nodes=count,massive_error=rel,worst_massive_probe=worst,total_bulk_error=np.linalg.norm(add+massless-target)/np.linalg.norm(target)))
            assert worst<.005
    table('boost-normalization.csv',output)
if __name__=='__main__':angular();frame()
