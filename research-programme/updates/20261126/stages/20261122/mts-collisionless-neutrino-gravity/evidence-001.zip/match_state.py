from metric import Gravity
from assess import extract,metric,rows
from nu_io import *

class Matched(Gravity):
    def __init__(self,model,incident,rule):
        super().__init__(model,12,ell=incident.shape[1]-1)
        bg=dict(zip(self.bkeys,self.back(self.times[0])))
        self.offset[self.nu_sl]=incident.reshape(-1,5)/evolve.UNIT
        nodes=self.nodes
        ep=np.hypot(nodes,self.metas['mass_over_temperature']*bg['a'])
        weight=self.weights*self.metas['massless_limit_coeff']/(bg['a']**2*(7*np.pi**4/120))
        density=4*bg['er']*incident[0,0]+(weight*nodes**2*ep)@incident[1:,0]
        current=4*bg['er']*incident[0,1]+(weight*nodes**3)@incident[1:,1]
        nonnu=bg['et']-bg['er']-bg['enu']
        flux=-current/(2*self.kn)
        numerator=3*bg['h']*flux-density/2
        potential=numerator/(self.kn**2+(2*nonnu if rule=='coordinate' else 0))
        deltae=density+(4*nonnu*potential if rule=='coordinate' else 0)
        offsetX=(deltae-4*bg['et']*potential)/bg['eg']
        offsetY=self.kn*current/bg['eg']
        self.jump=(density,current,potential,flux,offsetX,offsetY,nonnu)
        self.xy=np.stack([offsetX,offsetY])/evolve.UNIT
        assert np.array_equal([self.idx['geom'],self.idx['flux']],[0,1])
    def rhs(self,env,state,kind,variant,observe=False):
        if kind=='conserved':
            state=state.copy();state[:2]+=self.xy
        return super().rhs(env,state,kind,variant,observe)

def run(model):
    output=[];gates=[]
    for cells in (16,32):
        for rule in ('normal','coordinate'):
            def solve(incident,kind,tag,sub=1):
                solver=Matched(model,incident,rule)
                with patch.object(evolve,'guard',guard):arr=solver.integrate(kind,sub=sub)
                dest=f'matched-{model}-{cells}-{rule}-{tag}-{kind}.npz'
                pack(dest,values=arr,eta=solver.times,coord=PROBES,names=evolve.OBS+['M3','E3'],jumps=np.array(solver.jump[:6]))
                return solver,arr,extract(HOME/dest)
            with np.load(HOME/f'arriving-{model}-{cells}-main.npz') as f:main=f['states']
            solver,arr,joined=solve(main,'trace','all')
            _,_,independent=solve(main,'conserved','all')
            only=main.copy();only[:,2:]=0
            _,_,low=solve(only,'trace','low')
            with np.load(HOME/f'arriving-{model}-{cells}-more-angles.npz') as f:long=f['states']
            _,_,refined=solve(long,'trace','refined',sub=2)
            density,current,dp,df,dx,dy,nonnu=solver.jump
            with np.load(HOME/f'metric-{model}-12-both-16-1-18-trace-1.npz') as f:base=f['values'][0]
            delta=arr[0]-base
            bg=dict(zip(solver.bkeys,solver.back(solver.times[0])));k=solver.kn
            actual_density=2*(-k*k*delta[0]+3*bg['h']*delta[3])
            actual_j=-2*k*delta[3]
            for tag,residual,scale in [('constraint potential',delta[0]-dp,np.max(abs(dp))),('constraint expansion',delta[3]-df,np.max(abs(df))),
                    ('other density matching',actual_density-density-(4*nonnu*delta[0] if rule=='coordinate' else 0),np.max(abs(actual_density))+np.max(abs(density))),
                    ('other flux matching',actual_j-current,np.max(abs(current))),
                    ('coordinate density',delta[evolve.OBS.index('X')]-dx,np.max(abs(dx))),
                    ('coordinate flux divergence',delta[evolve.OBS.index('Y')]-dy,np.max(abs(dy)))]:
                err=np.max(abs(residual))/max(scale,1e-90)
                gates.append(dict(model=model,cells=cells,matching=rule,test=tag,scaled_error=err))
                assert err<2e-7,(tag,err)
            baseline=metric(model)
            angular=extract(HOME/f'arrival-response-{model}-{cells}-main-both.npz')
            comp={'all incident vs fixed incoming':joined-baseline,'all incident plus direct vs saved':joined-metric(model,'none'),
                  'density and current only':low-baseline,'trace vs coordinate evolution':joined-independent,
                  'sum of low and angular vs all':(low-baseline)+(angular-baseline)-(joined-baseline),
                  'higher angular order and half time step':refined-joined}
            saved=metric(model,'none')
            net=comp.pop('all incident plus direct vs saved')
            outcome=rows(model,comp,baseline,baseline-saved)
            outcome+=rows(model,{'all incident plus direct vs saved':net},saved,baseline-saved)
            for row in outcome:row.update(cells=cells,matching=rule)
            output+=outcome
    table(f'matching-constraints-{model}.csv',gates)
    table(f'matched-endpoint-{model}.csv',output)
    print(model,'matched and measured',flush=True)
if __name__=='__main__':run(sys.argv[1])
