import prehistory as low
from prehistory import *
NAMES='tau k a adotoa etak sigma phi qr grho gpres dgq grhob_t vb grhog_t qg grhor_t grhov_t qde w_lam grhonu_t'.split()
def run(model,func):
    native=diag.native;status=native.obj(native.source(f'runs/{model}/status.json'))
    path=native.SPEC/'runs/projection/a225-w6-d8.npz' if model=='heavy' else native.NATIVE/'runs/backgrounds/cold.npz'
    native.checked(path,status['source_hash'])
    for file in native.engine.inherited.native_hashes():native.checked(file,status['input_hashes'][str(file)])
    pars=native.engine.inherited.params_for(path,background_boost=8.);pars.DoLateRadTruncation=False
    bg=native.engine.camb.get_background(pars);bg.Params.Accuracy.IntTolBoost=6
    with np.load(HOME/f'incident-prehistory-{model}.npz') as f:t=f['eta'];kn=f['k']
    full=load_data(model)
    fine=np.linspace(t[-33],t[-1],513)
    times=np.r_[t[:-33],fine,full.eta[32::32]]
    with pin(f'capture-{model}.csv').open() as fp:blocks=list(csv.DictReader(fp))
    fields={key:[] for key in ('a','phi','psi','pd','Vm','Vr')}
    with patch.object(diag.symbolic,'compile_sympy_to_camb_source_func',return_value=func):
        for block in blocks:
            guard();first,last=int(block['first']),int(block['last'])+1;nodes=kn[first:last]
            batch=np.unique(np.r_[nodes,float(block['control']),float(block['hierarchy_cap'])])
            out=bg.get_time_evolution(batch,times,vars=[Dummy(name) for name in NAMES],lAccuracyBoost=4)[np.searchsorted(batch,nodes),len(t)-33:len(t)-33+len(fine)]
            assert np.isfinite(out).all() and np.allclose(out[:,:,1],nodes[:,None],rtol=2e-14,atol=0)
            raw=dict(zip(NAMES,out.transpose(2,0,1)));k=nodes[:,None];s=raw['sigma'];h=raw['adotoa'];ent=raw['grho']+raw['gpres']
            phi=raw['etak']/k-h*s/k;psi=2*raw['phi']-phi
            enh=raw['grhonu_t']+raw['gpres']-(raw['grhog_t']+raw['grhor_t'])/3-raw['w_lam']*raw['grhov_t']
            vm=(raw['dgq']-raw['grhob_t']*raw['vb']-raw['grhog_t']*raw['qg']-raw['grhor_t']*raw['qr']-raw['grhov_t']*raw['qde'])/enh+s
            values=(raw['a'],phi,psi,(raw['dgq']+ent*s)/(2*k)-h*psi,vm/k,(.75*raw['qr']+s)/k)
            for key,value in zip(fields,values):fields[key].append(value)
    vals={key:np.concatenate(lst) for key,lst in fields.items()}
    assert np.max(np.ptp(vals['a'],axis=0))<1e-12
    rows=[]
    for key in ('phi','psi','pd','Vm','Vr'):
        diff=vals[key][:,-1]-full.first[key][:,0]
        rows.append(dict(field=key,panel=np.linalg.norm(diff)/np.linalg.norm(full.first[key][:,0])))
    table('arrival-native-join-'+model+'.csv',rows);pack(f'arrival-metric-{model}.npz',eta=fine,k=kn,**vals)
if __name__=='__main__':
    if sys.argv[1:2]==['--child']:
        with patch.object(driver,'HERE',HOME),patch.object(driver,'NAMES',NAMES),patch.object(driver,'run',run),patch.object(driver,'save',lambda name,raw:save('arrival-'+name,raw)):driver.main()
    else:
        with tempfile.TemporaryDirectory(dir=HOME,prefix='reader-arrival-') as tmp:subprocess.run([sys.executable,'-B',str(HOME/'arrival_metric.py'),'--child',tmp,*sys.argv[1:]],check=True)
