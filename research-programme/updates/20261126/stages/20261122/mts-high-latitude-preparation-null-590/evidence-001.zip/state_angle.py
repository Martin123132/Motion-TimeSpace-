from formation_forces import saved,observable
from prediction import HOME,SOURCE,G,Gravity,np,roots_legendre,checked,read,table,live
from numpy.polynomial import legendre as lg
from gd1 import RADIUS,Z
from scipy.special import eval_legendre
from scipy.linalg import eigvalsh

def vectors(obj,order):
    cuts=np.unique(np.r_[obj.edges,RADIUS])
    nodes,weights=roots_legendre(order)
    span=np.diff(cuts)
    radius=(cuts[:-1,None]+(1+nodes)*span[:,None]/2).ravel()
    wr=4*np.pi*(span[:,None]*weights/2).ravel()*radius**2
    return radius,wr
def response(obj,radius,mu):
    ell=obj.ell
    probe=eval_legendre(ell,Z/RADIUS)
    inside=radius<RADIUS
    factor=np.where(inside,radius/RADIUS,RADIUS/radius)
    scale=np.where(inside[:,None],(ell+1)*factor[:,None]**ell,-ell*factor[:,None]**(ell+1))
    return (scale*probe)@lg.legvander(mu,max(ell))[:,::2].T

def domain(obj,mu,wt):
    ell=obj.ell
    probe=eval_legendre(ell,Z/RADIUS)
    pol=lg.legvander(mu,max(ell))[:,::2]
    basis=pol[:,:len(obj.degrees)]*np.sqrt(2*obj.degrees+1)
    assert np.max(abs(basis.T@(wt[:,None]*basis)-np.eye(len(obj.degrees))))<1e-11
    extrema=[]
    for coeff in ((ell+1)*probe,-ell*probe):
        prefix=np.zeros(len(mu))
        for column,weight in enumerate(coeff):
            prefix+=weight*pol[:,column]
            mat=basis.T@((prefix*wt)[:,None]*basis)
            vals=eigvalsh(mat)
            extrema.extend([vals[0],vals[-1]])
    return min(0.,min(extrema))-1e-8,max(0.,max(extrema))+1e-8

def run():
    live()
    with np.load(HOME/'native-map.npz') as archive: idmap=archive['indices'];sqrt=archive['sqrt']
    with np.load(saved('final-states-x4.npz')) as archive:
        line={arm:archive[arm+'_line'] for arm in ('reset','coupled')}
    with np.load(saved('direct-states-x4.npz')) as archive:
        rest={name:archive[name] for name in archive.files}
    def convert(vec):return np.pad(vec.reshape(len(sqrt),-1)/sqrt[:,None],((1,1),(0,0)))[idmap]
    fg={row['foreground']:float(row['equivalent_radial_mass_1e11'])*1e11 for row in read('gd1-forces.csv') if row['state']=='ordinary_only'}
    outcomes=[];tests=[];bands=[]
    for order,angular in [(12,90),(20,120)]:
        mu,wt=roots_legendre(angular);mu=(mu+1)/2;wt/=2
        for arm in line:
            obj=Gravity(arm+'_forward',order,angular)
            radius,wr=vectors(obj,order)
            B=lg.legvander(mu,max(obj.degrees))[:,::2]*np.sqrt(2*obj.degrees+1)
            kernel=response(obj,radius,mu)
            lower,upper=domain(obj,mu,wt)
            def sample(nodes):
                obj.nodes=nodes
                return obj.amplitude(radius)@B.T*np.sqrt(wr[:,None]*wt)
            base=sample(convert(line[arm]));pop=np.sum(abs(base)**2);base/=np.sqrt(pop)
            expectation=np.sum(abs(base)**2*kernel)
            scatter=np.sqrt(np.sum(abs(base)**2*(kernel-expectation)**2))
            independent=observable(obj,order)
            assert abs((pop*expectation)/independent['radial_mass_equivalent']-1)<1e-9
            assert lower<expectation<upper
            coarse=-float(sum(obj.ell+1))
            assert coarse<=lower
            def change_bound(sine,floor):
                return 2*scatter*sine+(expectation-floor)*sine**2
            def signed_check(name,state,real):
                sample_mass=np.sum(abs(state)**2); normalized=state/np.sqrt(sample_mass)
                overlap=np.vdot(base,normalized)
                residual=normalized-overlap*base
                sine=np.linalg.norm(residual)
                assert abs(abs(overlap)**2+sine**2-1)<1e-12
                observed=expectation-np.sum(abs(normalized)**2*kernel)
                positive=change_bound(sine,lower)
                upper_shift=2*scatter*sine+(upper-expectation)*sine**2
                assert -upper_shift-1e-13<=observed<=positive+1e-13
                if real: assert sine<.002 and abs(sample_mass/pop-1)<1e-8
                tests.append(dict(order=order,arm=arm,other=name,sine_angle=sine,
                   signed_decrease_Msun=observed*pop,allowed_decrease_Msun=positive*pop,
                   allowed_increase_Msun=upper_shift*pop))
            for name in ('anchor','cold48','hybrid48'):signed_check(name,sample(convert(rest[arm+'_'+name])),True)
            with np.load(checked(SOURCE,'launch.npz')) as ref:
                signed_check('saved_forward',sample(ref[arm+'_forward']),True)
                signed_check('saved_reverse_control',sample(ref[arm+'_reverse']),False)
            tangent=(kernel-expectation)*base
            compressed=((tangent/np.sqrt(wt))@(wt[:,None]*B))@B.T*np.sqrt(wt)
            compressed-=np.vdot(base,compressed)*base
            compressed/=np.linalg.norm(compressed)
            for sine in (.002,.05):
                signed_check('angular_tangent_'+str(sine),np.sqrt(1-sine**2)*base-sine*compressed,False)
            for foreground,ordinary in fg.items():
                target=(1.48e11-ordinary)/pop
                gap=expectation-target
                assert gap>0
                for name,floor in [('analytic_triangle',coarse),('angular_prefix',lower)]:
                    delta=expectation-floor
                    sine=gap/(scatter+np.sqrt(scatter**2+delta*gap))
                    assert abs(change_bound(sine,floor)-gap)<1e-12
                    outcomes.append(dict(order=order,arm=arm,foreground=foreground,method=name,occupation_Msun=pop,
                          expectation=expectation,variance_root=scatter,operator_lower=floor,operator_upper=upper,
                          required_radial_change_Msun=gap*pop,worst_decrease_at_sine_0p002_Msun=pop*change_bound(.002,floor),
                          required_min_sine=sine,minimum_orthogonal_population=sine**2))
            bands.append(dict(order=order,arm=arm,lower=lower,upper=upper,variance_root=scatter,
                 uncompressed_analytic_lower=coarse))
    table('state-angle-bound.csv',outcomes);table('state-angle-controls.csv',tests);table('angular-operator-bounds.csv',bands)
    for row in outcomes:
        if row['order']==20 and row['method']=='angular_prefix':
            print(row['arm'],row['foreground'],row['required_min_sine'],row['worst_decrease_at_sine_0p002_Msun'])
if __name__=='__main__':run()
