from pathlib import Path
import hashlib
import io
import json
import os
import sys
for name in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','BLIS_NUM_THREADS','NUMEXPR_NUM_THREADS'):os.environ[name]='1'
import numpy as np
HOME=Path(__file__).resolve().parent
ORIGIN=HOME.parent/'mts-flow-formation-inverse-586-20261122'
SOURCE=HOME.parent/'mts-preparation-vertical-gravity-590-20261122'
def pin(root,seal,name):
    manifest=(root/'seal.json').read_bytes()
    assert hashlib.sha256(manifest).hexdigest()==seal
    path=root/name
    assert hashlib.sha256(path.read_bytes()).hexdigest()==json.loads(manifest)[name]
    return path
def run():
    assert not any((folder/'STOP-REQUESTED').exists() for folder in (HOME,HOME.parent,ORIGIN,SOURCE))
    pin(ORIGIN,'4ae215216dac834ea5d8ae503fea680707af22348044627efb0b507a7c398fcb','inverse.py')
    sys.path.insert(0,str(ORIGIN))
    from inverse import setup
    lab,_,_,guard,_=setup();guard();native=lab.run.el
    weights=1/lab.obj.bg.sqrt;indices=native.indices
    def convert(vector):
        return np.pad(vector.reshape(lab.obj.bg.hshape)*weights[:,None],((1,1),(0,0)))[indices]
    with np.load(pin(SOURCE,'37a872fe0e0c207030ca5c4825940b22be066191dcfd3097d28f3169b104aef7','launch.npz')) as saved:
        for arm in ('reset','coupled'):
            start=lab.initial[arm]
            assert np.array_equal(native.nodes(start),saved[arm+'_forward'])
            assert np.max(abs(convert(start)-saved[arm+'_forward']))<=2e-15*np.max(abs(saved[arm+'_forward']))
    buf=io.BytesIO();np.savez_compressed(buf,sqrt=lab.obj.bg.sqrt,indices=indices)
    name=HOME/'native-map.npz'
    if name.exists():assert name.read_bytes()==buf.getvalue()
    else:
        with name.open('xb') as stream:stream.write(buf.getvalue())
    path=HOME/'native-units.json'
    content=(json.dumps(dict(velocity_kms=float(lab.obj.bg.vel),time_Myr=float(lab.obj.unit_myr),
           length_kpc=float(lab.obj.bg.length)),indent=2,sort_keys=True)+'\n').encode()
    if path.exists():assert path.read_bytes()==content
    else:
        with path.open('xb') as stream:stream.write(content)
    print('validated native map',indices.shape,weights.shape)
if __name__=='__main__':run()
