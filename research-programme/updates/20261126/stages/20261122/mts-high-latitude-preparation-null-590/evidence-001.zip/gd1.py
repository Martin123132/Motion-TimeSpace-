from prediction import HOME, MODELS, G, STATES, disk, wave, host, digest, json, live, np, table, record
from scipy.integrate import quad

R=11.9
Z=7.3
RADIUS=np.hypot(R,Z)
TO_KMS_MYR=31557600e6/3.0856775814913673e16
TARGET={'a_R':(-2.5,.1,.2),'a_z':(-1.8,.1,.1),'a_phi':(.2,.1,.1),
        'q_force':(.91,.05,.05),'equivalent_radial_mass_1e11':(1.41,.07,.07)}
def ordinary_halo(model,radius):
    scale=14.; amplitude={'Pouliasis_I':6000.,'Pouliasis_II':9000.}[model]*2.32e7
    x=radius/scale
    assert radius<100
    fraction=x**2.02/(1+x**1.02)
    integral=quad(lambda u:u**1.02*(2.02+u**1.02)/(1+u**1.02)**2,0,x,epsabs=1e-13)[0]
    assert abs(integral/fraction-1)<1e-9
    return G*amplitude*fraction/radius**2
def predictions(foreground,state):
    field=host(3) if foreground=='positive_host' else disk(MODELS[foreground])
    pos=np.array([R]);height=np.array([Z])
    deriv=field(pos,height)[1:,0].copy()
    if state=='published_halo':
        deriv+=ordinary_halo(foreground,RADIUS)*np.array([R,Z])/RADIUS
    elif state in STATES:
        deriv+=wave(state,20,96)(pos,height)[1:,0]
    else: assert state=='ordinary_only'
    radial,vertical=-deriv*TO_KMS_MYR
    ar=(R*radial+Z*vertical)/RADIUS
    alat=(R*vertical-Z*radial)/RADIUS
    assert abs((ar**2+alat**2)/(radial**2+vertical**2)-1)<1e-15
    return dict(a_R=radial,a_z=vertical,a_phi=0.,a_spherical=ar,a_latitude=alat,
        q_force=np.sqrt(Z*radial/(R*vertical)),equivalent_radial_mass_1e11=-ar/TO_KMS_MYR*RADIUS**2/G/1e11)
def run():
    live()
    assert digest(HOME/'freeze.json')=='15e02c4511d0ed8246e01a518563362fb812fe03c21959999b788868f5c99f14'
    assert all(digest(HOME/name)==value for name,value in json.loads((HOME/'freeze.json').read_bytes()).items())
    projections=[]; residuals=[]
    for fg in (*MODELS,'positive_host'):
        group={}
        for state in ('ordinary_only',*STATES,*(('published_halo',) if fg in MODELS else ())):
            pred=predictions(fg,state)
            group[state]=pred
            projections.append(dict(foreground=fg,state=state,**pred))
            for key,(obs,lower,upper) in TARGET.items():
                err=upper if pred[key]>=obs else lower
                residuals.append(dict(foreground=fg,state=state,quantity=key,observed=obs,minus=lower,plus=upper,
                     predicted=pred[key],marginal_error_units=(pred[key]-obs)/err))
        for arm in ('reset','coupled'):
            assert group[arm+'_forward']==group[arm+'_reverse']
        if 'published_halo' in group:
            assert abs(group['published_halo']['a_latitude']-group['ordinary_only']['a_latitude'])<1e-14
    table('gd1-forces.csv',projections);table('gd1-marginals.csv',residuals)
    observed_T=(R*TARGET['a_z'][0]-Z*TARGET['a_R'][0])/RADIUS
    lo=(R*(-1.9)-Z*(-2.3))/RADIUS;hi=(R*(-1.7)-Z*(-2.6))/RADIUS
    info=dict(source='https://arxiv.org/html/2504.07187v1',location=[R,Z,171.1],
              observed_projection_of_medians=observed_T,coordinate_box_not_joint_CI=[lo,hi],
              acceleration_unit='km/s/Myr',kms_per_Myr_per_kms2_per_kpc=TO_KMS_MYR,
              status='Already published point of smallest errors; not a blinded held-out experiment. Cylindrical components, radial mass and flattening reuse the same stream inference; never sum scores.')
    record('gd1-source.json',info)
    for row in projections:
        if row['state'].endswith('_reverse'):continue
        print(row['foreground'],row['state'],*[round(row[key],6) for key in ('a_R','a_z','a_latitude','q_force','equivalent_radial_mass_1e11')])
    print(info)
if __name__=='__main__':run()
