from formation_forces import saved
from prediction import HOME, FIX, checked, read, table, np, live, json
from gd1 import TO_KMS_MYR

def run():
    live()
    units=json.loads((HOME/'native-units.json').read_bytes())
    scaler=units['velocity_kms']**2
    action=scaler*units['time_Myr']
    with np.load(checked(FIX,'drives-1-3.npz')) as arch:
        assert abs(float(arch['kappa'])/TO_KMS_MYR**2/action-1)<1e-7
    with np.load(saved('interventions.npz')) as arch:
        ages=arch['ages'];sources={'anchor':arch['anchor']}
    with np.load(saved('direct-sources.npz')) as arch:
        sources.update({key:arch[key] for key in ('cold48','hybrid48')})
    duration=ages[-1]-ages[0]
    extremes=[];results=[];native=[]
    for key,source in sources.items():
        assert len(source)==len(ages) and np.max(abs(source[[0,-1]]))<1e-12
        half_width=np.array([np.ptp(at)*scaler/2 for at in source])
        upper=np.sum(.5*(half_width[1:]+half_width[:-1])*np.diff(ages))
        for age,span in zip(ages,half_width):extremes.append(dict(source=key,age_Myr=age,external_half_range_kms2=span))
        for row in read('state-angle-bound.csv'):
            if row['order']!='20' or row['method']!='angular_prefix':continue
            floor=np.arcsin(float(row['required_min_sine']))*action
            results.append(dict(source=key,arm=row['arm'],foreground=row['foreground'],duration_Myr=duration,
                      required_total_action_kms2_Myr=floor,external_action_upper_kms2_Myr=upper,
                      required_mean_effective_kms2=floor/duration,external_mean_upper_kms2=upper/duration,
                      needed_mean_induced_kms2=max(0.,floor-upper)/duration))
        for row in read('native-state-angle-bound.csv'):
            if row['order']!='20' or row['method']!='angular_prefix_times_gram':continue
            floor=np.arcsin(float(row['required_min_sine']))*action
            native.append(dict(source=key,arm=row['arm'],foreground=row['foreground'],duration_Myr=duration,
                required_total_action_kms2_Myr=floor,external_action_upper_kms2_Myr=upper,
                required_mean_effective_kms2=floor/duration,external_mean_upper_kms2=upper/duration,
                needed_mean_induced_kms2=max(0.,floor-upper)/duration))
    table('formation-drive-floor.csv',results);table('ordinary-source-oscillation.csv',extremes)
    table('native-drive-floor.csv',native)
    for row in results:
        if row['arm']=='reset' and row['foreground']=='Pouliasis_II':print(row)
if __name__=='__main__':run()
