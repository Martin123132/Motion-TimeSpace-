from pathlib import Path
import csv
import hashlib
import io
import json
import os
import sys

HOME=Path(__file__).resolve().parent
PARENT=HOME.parent/'mts-stellar-drive-wave-response-590-20261122'
PARENT_SEAL='6e42143ea325d8f7a2344357b1e339c14a42cd57b6f845b4f28cec98d81412b1'
def digest(path): return hashlib.sha256(path.read_bytes()).hexdigest()
assert digest(PARENT/'seal.json')==PARENT_SEAL
parent_manifest=json.loads((PARENT/'seal.json').read_bytes())
assert digest(PARENT/'common.py')==parent_manifest['common.py']
sys.path.insert(0,str(PARENT))
from common import np, MODELS, G, Gravity, Stage, STATES, SOURCE, FIX, checked, guard, R_GROUPS, RectBivariateSpline
from scipy.special import roots_legendre
def live():
    guard()
    assert not (HOME/'STOP-REQUESTED').exists()
def keep(name,content):
    path=HOME/name
    if path.exists(): assert path.read_bytes()==content,name
    else:
        with path.open('xb') as dest: dest.write(content)
def table(name,rows):
    buf=io.StringIO()
    dest=csv.DictWriter(buf,rows[0].keys(),lineterminator='\n')
    dest.writeheader();dest.writerows(rows);keep(name,buf.getvalue().encode())
def read(name):
    with (HOME/name).open() as file: return list(csv.DictReader(file))
def record(name,value): keep(name,(json.dumps(value,indent=2,sort_keys=True,allow_nan=False)+'\n').encode())
RADII=np.array([4.,6.,8.178,10.,12.,16.,20.,24.,30.,40.,60.,80.,100.])
ANGLES=np.arange(10.,81.,10.)
UNITS={'A':'(km/s)^2','T':'(km/s)^2','Q':'(km/s)^2','g_lat':'(km/s)^2/kpc'}
def sites():
    radii,angles=np.meshgrid(RADII,ANGLES,indexing='ij')
    return radii.ravel(),angles.ravel()

def disk(parts):
    def evaluate(R,z):
        phi=np.zeros_like(R);dr=phi.copy();dz=phi.copy()
        for mass,scale,height in parts:
            minor=np.hypot(z,height);distance=np.hypot(R,scale+minor)
            gm=G*mass*2.32e7
            phi-=gm/distance;dr+=gm*R/distance**3;dz+=gm*(scale+minor)*z/minor/distance**3
        return np.array((phi,dr,dz))
    return evaluate

def wave(state,order,angular):
    obj=Gravity(state,order,angular)
    norm=json.loads(checked(SOURCE,'occupation.json').read_bytes())[state]
    def evaluate(R,z):
        results,mass=obj.evaluate(R,z)
        assert abs(mass/norm-1)<1e-8
        return results[:,:3].T
    return evaluate

def host(level):
    calc=Stage(level);space=calc.s
    symmetric=np.c_[calc.host[:,::-1],calc.host]
    fit=RectBivariateSpline(space.r,np.r_[-space.mu[::-1],space.mu],symmetric,s=0)
    def evaluate(R,z):
        radius=np.hypot(R,z);mu=z/radius;cs=R/radius
        assert radius.min()>=space.r[0] and radius.max()<=space.r[-1]
        assert max(abs(mu))<=space.mu[-1]
        pot=fit.ev(radius,mu);radial=fit.ev(radius,mu,dx=1);angular=fit.ev(radius,mu,dy=1)/radius
        return np.array((pot,cs*(radial-mu*angular),mu*radial+cs**2*angular))
    return evaluate

def measure(field,radii,angles):
    alpha=np.deg2rad(angles);R=radii*np.cos(alpha);z=radii*np.sin(alpha)
    phi,dr,dz=field(R,z)
    plane=field(radii,np.zeros_like(z))[0]
    A=phi-plane;T=R*dz-z*dr
    return np.array((A,T,T-2*A/np.tan(alpha),-T/radii))

def integrals(field,radii,angles,order):
    nodes,weights=roots_legendre(order)
    alpha=np.deg2rad(angles)
    arcs=alpha[:,None]*(1+nodes)/2
    R=radii[:,None]*np.cos(arcs);z=radii[:,None]*np.sin(arcs)
    _,dr,dz=field(R.ravel(),z.ravel())
    return alpha/2*((R*dz.reshape(R.shape)-z*dr.reshape(R.shape))@weights)

def run():
    live()
    assert digest(HOME/'PROTOCOL.md')=='8f2f72faca5728cc2ff3fcdda4eb884c8723fea786c82d086013feb1dc07af38'
    radii,angles=sites()
    allrows=[];bounds=[];checks=[];comparisons=[]
    with (PARENT/'equal-radius-discrimination.csv').open() as file:
        reference=np.array([float(row['delta_equal_radius_potential']) for row in csv.DictReader(file)
                            if row['grid']=='finer' and row['Zsun_pc']=='0'])
    for grid,order,angular,level in [('fine',12,64,2),('finer',20,96,3)]:
        fields={state:wave(state,order,angular) for state in STATES}
        fields.update({name:disk(parts) for name,parts in MODELS.items()})
        fields['positive_host']=host(level); fields['spherical']=disk([(1000.,0.,3.)])
        cases={}
        for state,field in fields.items():
            live()
            obs=measure(field,radii,angles)
            reflected=measure(field,radii,-angles)
            assert np.max(abs(reflected-obs*np.array([1,-1,-1,-1])[:,None]))<2e-8
            plane=field(radii,np.zeros_like(radii))
            assert np.max(abs(plane[2]))<2e-8
            if state!='positive_host':
                polar=field(np.zeros_like(radii),radii)
                assert np.max(abs(polar[1]))<1e-9
            cases[state]=obs
            for idx,(radius,angle) in enumerate(zip(radii,angles)):
                allrows.append(dict(grid=grid,state=state,r_kpc=radius,latitude_deg=angle,
                               **dict(zip(UNITS,obs[:,idx]))))
            for select in (np.arange(0,len(radii),7),):
                integrated=integrals(field,radii[select],angles[select],100 if state.startswith('Pouliasis') else 42)
                residual=abs(integrated-obs[0,select])
                for idx,err in zip(select,residual):
                    checks.append(dict(grid=grid,state=state,r_kpc=radii[idx],latitude_deg=angles[idx],
                             angular_integral_abs_error=err,potential_at_site=obs[0,idx]))
        assert abs(cases['spherical']).max()<1e-9
        for arm in ('reset','coupled'):
            assert abs(cases[arm+'_forward']-cases[arm+'_reverse']).max()<1e-10
        def quad(R,z):
            return 3*z*z-R*R-z*z,-2*R,4*z
        assert abs(measure(quad,radii,angles)[2]).max()<1e-9
        solar_r=np.hypot(R_GROUPS,.4);solar_ang=np.rad2deg(np.arctan2(.4,R_GROUPS))
        solar=[measure(fields[state],solar_r,solar_ang)[0] for state in ('reset_forward','coupled_forward')]
        assert max(abs((solar[0]-solar[1])/reference-1))<.005
        signal=cases['reset_forward']-cases['coupled_forward']
        first,second=[cases[name] for name in MODELS]
        spread=abs(first-second)
        for idx,(radius,angle) in enumerate(zip(radii,angles)):
            for k,name in enumerate(UNITS):
                amps=[sum(abs(measure(disk([part]),np.array([radius]),np.array([angle]))[k,0]) for part in parts) for parts in MODELS.values()]
                thresholds=[abs(signal[k,idx])/(2*amp) for amp in amps if amp>0]
                triple=[first[k,idx],second[k,idx],cases['positive_host'][k,idx]]
                bounds.append(dict(grid=grid,r_kpc=radius,latitude_deg=angle,observable=name,delta=signal[k,idx],
                           stellar_spread=spread[k,idx],single_site_margin=abs(signal[k,idx])-spread[k,idx],
                           all_three_margin=abs(signal[k,idx])-(max(triple)-min(triple)),
                           within_model_frac_mass_overlap=min(thresholds)))
        if grid=='fine':previous={**cases,'contrast':signal}
        else:
            for label,arr in {**cases,'contrast':signal}.items():
                for k,key in enumerate(UNITS):
                    if label=='spherical':continue
                    rel=abs(previous[label][k]/arr[k]-1)
                    for radius,angle,err in zip(radii,angles,rel):
                        comparisons.append(dict(state=label,observable=key,r_kpc=radius,latitude_deg=angle,
                                  relative_error=err,pass_point005=err<.005))
    table('field-grid.csv',allrows);table('single-site.csv',bounds);table('integrals.csv',checks)
    table('refinement.csv',comparisons)
    assert all(row['pass_point005'] for row in comparisons if row['state']=='contrast')
    record('freeze.json',{name:digest(HOME/name) for name in ('PROTOCOL.md','prediction.py','field-grid.csv','single-site.csv','integrals.csv','refinement.csv')})
    for key in UNITS:
        rows=[row for row in bounds if row['grid']=='finer' and row['observable']==key]
        best=max(rows,key=lambda row:row['single_site_margin'])
        print(key,'positive margins',sum(row['single_site_margin']>0 for row in rows), 
           'best',best['r_kpc'],best['latitude_deg'],best['delta'],best['stellar_spread'], 'maximum',max(abs(row['delta']) for row in rows))
if __name__=='__main__':run()
