from formation_forces import saved
from prediction import HOME, np, read, table, json
import csv

def load(factor):
    with saved(f'action-x{factor}.csv').open() as file:
        return {(row['arm'],row['source']):row for row in csv.DictReader(file)}
def run():
    raw=load(4);coarse=load(2)
    with np.load(saved('interventions.npz')) as arch:duration=np.ptp(arch['ages'])
    units=json.loads((HOME/'native-units.json').read_bytes())
    factor=units['time_Myr']*units['velocity_kms']**2/duration
    out=[]
    for row in read('native-state-angle-bound.csv'):
        if row['order']!='20' or row['method']!='angular_prefix_times_gram':continue
        required=np.arcsin(float(row['required_min_sine']))*factor
        for key,r in raw.items():
            if key[0]!=row['arm'] or key[1]=='line':continue
            total,external,induced=[factor*float(r['action_'+name+'_rad']) for name in ('total','external','self')]
            assert abs(total-float(r['time_mean_total_kms2']))<1e-7
            assert total<external+induced and total/factor>=float(r['measured_angle'])
            ref_error=abs(float(coarse[key]['action_total_rad'])/float(r['action_total_rad'])-1)
            out.append(dict(arm=key[0],foreground=row['foreground'],source=key[1],
                 direct_counted_anchor=(key[1]=='anchor'),time_refinement=ref_error,
                 total_mean_kms2=total,ordinary_mean_kms2=external,induced_mean_kms2=induced,
                 required_total_mean_kms2=required,required_to_actual=required/total))
    table('measured-action-budget.csv',out)
    print(max(row['time_refinement'] for row in out))
if __name__=='__main__':run()
