from prediction import HOME, MODELS, wave, disk, measure, np, table, live
from scipy.optimize import brentq

def run():
    live()
    waves=[wave(arm+'_forward',20,96) for arm in ('reset','coupled')]
    disks=[disk(parts) for parts in MODELS.values()]
    def sample(radius,angles):
        angles=np.atleast_1d(angles);radii=np.full(len(angles),radius,dtype=float)
        vals=[measure(field,radii,angles)[0] for field in waves+disks]
        delta=vals[0]-vals[1];gap=vals[2]-vals[3]
        return delta,gap,abs(delta)-abs(gap)
    grid=np.arange(2.,89.901,.10)
    patches=[]
    for r in (3.75,3.875,4.,4.125,4.25):
        sig,spread,margin=sample(r,grid)
        crossings=np.flatnonzero(spread[:-1]*spread[1:]<0)
        for idx in crossings:
            centre=brentq(lambda a:sample(r,a)[1][0],grid[idx],grid[idx+1])
            if sample(r,centre)[2][0]<=0:continue
            below=grid[(grid<centre)&(margin<0)]
            above=grid[(grid>centre)&(margin<0)]
            if len(below)==0 or len(above)==0:
                continue
            left=brentq(lambda a:sample(r,a)[2][0],below[-1],centre)
            right=brentq(lambda a:sample(r,a)[2][0],centre,above[0])
            patches.append(dict(r_kpc=r,zero_disk_spread_deg=centre,positive_left_deg=left,positive_right_deg=right,width_deg=right-left))
    assert any(row['r_kpc']==4. and row['positive_left_deg']<70.<row['positive_right_deg'] for row in patches)
    table('disk-crossing-window.csv',patches)
    print(patches)
if __name__=='__main__':run()
