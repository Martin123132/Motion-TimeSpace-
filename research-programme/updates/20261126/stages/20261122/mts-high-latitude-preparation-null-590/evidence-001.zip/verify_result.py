from prediction import HOME, PARENT, PARENT_SEAL, UNITS, STATES, MODELS, R_GROUPS, SOURCE, FIX, checked, read, digest, keep, json, np, live
from formation_forces import FORM, FORM_PIN
from origin_trace import EARLY,PIN
from pathlib import Path
import re
import sys

def run():
    live()
    for path,pin in [(PARENT,PARENT_SEAL),(FORM,FORM_PIN),(EARLY,PIN)]:
        assert digest(path/'seal.json')==pin
    for name,expected in json.loads((PARENT/'seal.json').read_bytes()).items():assert digest(PARENT/name)==expected,name
    assert digest(HOME/'freeze.json')=='15e02c4511d0ed8246e01a518563362fb812fe03c21959999b788868f5c99f14'
    for name,expected in json.loads((HOME/'freeze.json').read_bytes()).items():assert digest(HOME/name)==expected,name
    for file in HOME.glob('*.csv'):
        content=read(file.name)
        assert content and all(None not in row and None not in row.values() for row in content),file
    for file in HOME.glob('*.py'):compile(file.read_bytes(),str(file),'exec')
    data=read('refinement.csv')
    assert all(row['pass_point005']=='True' for row in data)
    controls=read('integrals.csv')
    assert all(abs(float(row['angular_integral_abs_error']))<max(1e-8,.005*abs(float(row['potential_at_site']))) for row in controls)
    site=[row for row in read('single-site.csv') if row['grid']=='finer']
    for key,number in [('A',1),('T',0),('g_lat',0),('Q',0)]:
        sub=[row for row in site if row['observable']==key]
        assert len(sub)==104 and sum(float(row['single_site_margin'])>0 for row in sub)==number
    assert all(float(row['all_three_margin'])<0 for row in site)
    obs=read('gd1-forces.csv')
    scalar=lambda fg,arm: next(float(row['equivalent_radial_mass_1e11']) for row in obs if (row['foreground'],row['state'])==(fg,arm))
    assert 1.34<scalar('Pouliasis_I','published_halo')<1.48<scalar('Pouliasis_II','published_halo')
    for name in MODELS:
        assert scalar(name,'ordinary_only')<1.34
        for state in STATES: assert scalar(name,state)>1.48
    form=read('formation-refinement.csv')
    assert len(form)==84 and max(float(row['relative']) for row in form)<.005
    virial=read('virial-and-shell.csv')
    discrete=read('virial-discrete.csv')
    max_error=0.
    for row in virial:
        other=next(item for item in discrete if (item['arm'],item['model'],item['level'])==(row['arm'],row['model'],'3'))
        assert float(row['M14_curvature_Msun_per_Myr2'])>0>float(row['I_curvature_kpc2_per_Myr2'])
        for key,match in [('self_energy_specific','self_energy'),('M14_curvature_Msun_per_Myr2','M14_curvature'),('I_curvature_kpc2_per_Myr2','I_curvature')]:
            max_error=max(max_error,abs(float(row[key])/float(other[match])-1))
    assert max_error<.005
    for path,method in [('state-angle-bound.csv','angular_prefix'),('native-state-angle-bound.csv','angular_prefix_times_gram')]:
        peak=[row for row in read(path) if row['order']=='20' and row['method']==method]
        assert len(peak)==6 and all(float(row['required_min_sine'])>.075 for row in peak if row['foreground'] in MODELS)
        for row in peak:
            old=next(item for item in read(path) if (item['order'],item['method'],item['foreground'],item['arm'])==('12',method,row['foreground'],row['arm']))
            assert abs(float(row['required_min_sine'])/float(old['required_min_sine'])-1)<.005
    acts=read('measured-action-budget.csv')
    assert max(float(row['time_refinement']) for row in acts)<.005
    assert min(float(row['required_to_actual']) for row in acts if row['source']=='anchor' and row['foreground'] in MODELS)>51
    assert max(float(row['phase_free_chord']) for row in read('ground-check.csv'))<1e-12
    early=read('origin-trace.csv')
    diffs=[]
    for row in early:
        if row['steps']!='32':continue
        new=next(item for item in early if (item['steps'],item['route'],item['snapshot'])==('64',row['route'],row['snapshot']))
        diffs.append(abs(float(row['radial_mass_equivalent'])/float(new['radial_mass_equivalent'])-1))
    assert max(diffs)<.005
    for doc in HOME.glob('*.md'):
        for link in re.findall(r'\[[^\]]*\]\(([^)]+)\)',doc.read_text(encoding='utf-8')):
            if not link.startswith('https://'):assert (HOME/link).is_file(),link
    assert all(path.is_file() for path in HOME.iterdir())
    info=dict(geometry_sites=104,reported_formation_refinements=len(form),max_formation_refinement=max(float(row['relative']) for row in form),
              max_analytic_vs_discrete_virial_or_shell_error=max_error,max_origin_trace_refinement=max(diffs),
              parent_files_checked=230,uncertainty='Separate marginal comparisons; no joint likelihood, fit or held-out status asserted.')
    keep('validation.json',(json.dumps(info,sort_keys=True,indent=2)+'\n').encode())
    if '--seal' in sys.argv or (HOME/'seal.json').exists():
        items={p.name:digest(p) for p in sorted(HOME.iterdir()) if p.name!='seal.json'}
        keep('seal.json',(json.dumps(items,sort_keys=True,indent=2)+'\n').encode())
        print(len(items),digest(HOME/'seal.json'))
    print(info)
if __name__=='__main__':run()
