from gd1 import R,Z,RADIUS,TO_KMS_MYR,TARGET
from prediction import HOME, SOURCE, Gravity, MODELS, G, np, roots_legendre, checked, digest, table, read, record, live, json
FORM=HOME.parent/'mts-formation-cold-source-586-590-20261122'
FORM_PIN='bf3223a9ddf5b28656b29c6413679f4bc6d45ea687d1b7075871521dc6bd802a'
def saved(name):
    assert digest(FORM/'seal.json')==FORM_PIN
    path=FORM/name
    assert digest(path)==json.loads((FORM/'seal.json').read_bytes())[name]
    return path
def enclosed(obj,radius,order):
    cut=np.r_[obj.edges[obj.edges<radius],radius];nodes,weights=roots_legendre(order)
    width=np.diff(cut)
    at=(cut[:-1,None]+.5*width[:,None]*(1+nodes)).ravel()
    return 4*np.pi*np.sum(.5*width[:,None]*weights*(at**2*obj.modes(at)[:,0]).reshape(len(width),order))
def observable(obj,order):
    result,occupation=obj.evaluate(np.array([R]),np.array([Z]))
    aR,az=-result[0,1:3]*TO_KMS_MYR
    spherical=(R*aR+Z*az)/RADIUS; polar=(R*az-Z*aR)/RADIUS
    effective=-RADIUS**2/G*spherical/TO_KMS_MYR
    interior=enclosed(obj,RADIUS,order)
    return dict(a_R=aR,a_z=az,a_latitude=polar,radial_mass_equivalent=effective,enclosed_true_Msun=interior,
                nonspherical_equivalent=effective-interior,occupation=occupation)
def run():
    live()
    mass_scale=float(np.load(checked(SOURCE,'launch.npz'))['mscale'])
    with np.load(HOME/'native-map.npz') as mapping: index=mapping['indices'];sqrt=mapping['sqrt']
    results=[];checks=[];required=[]
    measured=[row for row in read('gd1-forces.csv') if row['state']=='ordinary_only']
    for arm in ('reset','coupled'):
        obj=Gravity(arm+'_forward',20,96)
        ref=observable(obj,20)
        states={}
        for factor in (2,4):
            with np.load(saved(f'final-states-x{factor}.npz')) as archive: states['line']=archive[arm+'_line']
            with np.load(saved(f'direct-states-x{factor}.npz')) as archive:
                for scenario in ('anchor','cold48','hybrid48'): states[scenario]=archive[arm+'_'+scenario]
            alternatives={}
            for scenario,state in states.items():
                obj.nodes=np.pad(state.reshape(len(sqrt),-1)/sqrt[:,None],((1,1),(0,0)))[index]
                values=observable(obj,20)
                assert abs(values['occupation']/(mass_scale*np.vdot(state,state).real)-1)<1e-8
                assert abs(values['occupation']/ref['occupation']-1)<1e-8
                alternatives[scenario]=values
                results.append(dict(arm=arm,steps=70*factor,source=scenario,**values))
                if factor==4:
                    for ordinary in measured:
                        bg=float(ordinary['equivalent_radial_mass_1e11'])*1e11
                        total=values['radial_mass_equivalent']+bg
                        required.append(dict(arm=arm,source=scenario,foreground=ordinary['foreground'],
                          total_radial_equivalent=total,required_wave_decrease_to_upper=total-1.48e11,
                          radial_equivalent_above_upper_fraction_of_wave=(total-1.48e11)/values['radial_mass_equivalent'],
                          max_true_enclosed_if_multipoles_held_fixed=1.48e11-bg-values['nonspherical_equivalent']))
            if factor==2:previous=alternatives.copy();continue
            for scenario in states:
                for name in ('a_R','a_z','a_latitude','radial_mass_equivalent','enclosed_true_Msun','nonspherical_equivalent'):
                    old=previous[scenario][name];new=alternatives[scenario][name]
                    checks.append(dict(arm=arm,source=scenario,quantity=name,test='endpoint',coarse=old,fine=new,relative=abs(old/new-1)))
                    if scenario!='line':
                        old-=previous['line'][name];new-=alternatives['line'][name]
                        checks.append(dict(arm=arm,source=scenario,quantity=name,test='correction_from_line',coarse=old,fine=new,relative=abs(old/new-1)))
        results.append(dict(arm=arm,steps=0,source='frozen_590_reference',**ref))
    table('formation-endpoints.csv',results);table('formation-refinement.csv',checks);table('radial-budget.csv',required)
    print('worst refinement',max(row['relative'] for row in checks))
    for arm in ('reset','coupled'):
        rows=[row for row in results if row['arm']==arm and row['steps']==280]; ref=rows[0]
        for row in rows: print(arm,row['source'],round(row['radial_mass_equivalent']/1e9,6),round((row['radial_mass_equivalent']-ref['radial_mass_equivalent'])/1e9,6),round(row['nonspherical_equivalent']/1e9,4))
if __name__=='__main__':run()
