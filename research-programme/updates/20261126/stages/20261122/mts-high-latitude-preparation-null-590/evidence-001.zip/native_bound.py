from state_angle import domain,response
from formation_forces import saved,observable
from prediction import HOME,SOURCE,Gravity,np,roots_legendre,checked,read,table,live
from gd1 import RADIUS
from numpy.polynomial import legendre as lg
from numpy.polynomial.chebyshev import chebvander
from scipy.sparse import csr_matrix

def run():
    live()
    with np.load(HOME/'native-map.npz') as archive:ids=archive['indices'];sqrt=archive['sqrt']
    with np.load(checked(SOURCE,'launch.npz')) as archive:mscale=float(archive['mscale']);length=float(archive['length'])
    outcomes=[];tests=[]
    ordinary={row['foreground']:float(row['equivalent_radial_mass_1e11'])*1e11 for row in read('gd1-forces.csv') if row['state']=='ordinary_only'}
    for order,angular in [(12,90),(20,120)]:
        obj=Gravity('reset_forward',order,angular)
        cuts=np.unique(np.r_[obj.edges,RADIUS]);nodes,weights=roots_legendre(order);span=np.diff(cuts)
        radius=(cuts[:-1,None]+span[:,None]*(1+nodes)/2).ravel()
        wr=(span[:,None]*weights/2/length).ravel()
        ix=np.searchsorted(obj.edges[1:],radius)
        coord=2*(radius-obj.edges[ix])/np.diff(obj.edges)[ix]-1
        basis=chebvander(coord,len(obj.knots)-1)@obj.inverse
        col=ids[ix]-1;valid=(col>=0)&(col<len(sqrt))
        rows=np.broadcast_to(np.arange(len(radius))[:,None],col.shape)[valid]
        radial=csr_matrix((basis[valid]/sqrt[col[valid]]*np.sqrt(wr[rows]),(rows,col[valid])),shape=(len(radius),len(sqrt)))
        gram=(radial.T@radial).toarray()
        cap=np.max(np.sum(abs(gram),axis=1))+1e-10
        eigen=np.linalg.eigvalsh(gram)
        assert 0<eigen[0]<=eigen[-1]<=cap
        mu,wt=roots_legendre(angular);mu=(mu+1)/2;wt/=2
        angular_basis=lg.legvander(mu,max(obj.degrees))[:,::2]*np.sqrt(wt[:,None]*(2*obj.degrees+1))
        kernel=response(obj,radius,mu)
        lower,upper=domain(obj,mu,wt);lower*=cap;upper*=cap
        def apply(vec):
            array=vec.reshape(len(sqrt),-1)
            mapped=(radial@array)@angular_basis.T
            return (radial.T@((kernel*mapped)@angular_basis)).ravel()
        with np.load(saved('final-states-x4.npz')) as archive:
            lines={arm:archive[arm+'_line'] for arm in ('reset','coupled')}
        with np.load(saved('direct-states-x4.npz')) as archive:alternates={name:archive[name] for name in archive.files}
        for arm,vec in lines.items():
            native_mass=mscale*np.vdot(vec,vec).real
            base=vec/np.linalg.norm(vec)
            applied=apply(base);mean=np.vdot(base,applied).real
            sigma=np.linalg.norm(applied-mean*base)
            direct=next(float(row['radial_mass_equivalent']) for row in read('formation-endpoints.csv')
                       if (row['arm'],row['source'],row['steps'])==(arm,'line','280'))
            assert abs(native_mass*mean/direct-1)<1e-8
            for name in ('anchor','cold48','hybrid48'):
                raw=alternates[arm+'_'+name]
                alt=raw/np.linalg.norm(raw);sine=np.linalg.norm(alt-base*np.vdot(base,alt))
                observed=mean-np.vdot(alt,apply(alt)).real
                assert sine<.002 and observed<=2*sigma*sine+(mean-lower)*sine**2
                assert -observed<=2*sigma*sine+(upper-mean)*sine**2
                tests.append(dict(order=order,arm=arm,source=name,native_sine=sine,
                     signed_change_Msun=-observed*native_mass,gram_min=eigen[0],gram_max=eigen[-1],gram_certified_upper=cap))
            for foreground,bary in ordinary.items():
                gap=mean-(1.48e11-bary)/native_mass
                for method,floor in [('angular_prefix_times_gram',lower),('triangle_times_gram',-sum(obj.ell+1)*cap)]:
                    need=gap/(sigma+np.sqrt(sigma**2+(mean-floor)*gap))
                    outcomes.append(dict(order=order,arm=arm,foreground=foreground,method=method,required_min_sine=need,
                         required_change_Msun=gap*native_mass,allowed_change_at_sine_0p002_Msun=(2*sigma*.002+(mean-floor)*.002**2)*native_mass,
                         occupation_native_Msun=native_mass,mean=mean,standard_deviation=sigma,operator_lower=floor))
    table('native-state-angle-bound.csv',outcomes);table('native-state-controls.csv',tests)
    print(outcomes[-6],tests[-1])
if __name__=='__main__':run()
