from formation_forces import observable
from prediction import HOME,SOURCE,Gravity,np,table,read,checked,digest,live,json
EARLY=HOME.parent/'mts-pre572-wave-preparation-20261120'
PIN='ce9ca0f03916af1fa3bfd449a61e779a74ce3427fae0a3a6bcdf65bc2b6c70ee'
def path(name):
    assert digest(EARLY/'seal.json')==PIN
    value=EARLY/name
    assert digest(value)==json.loads((EARLY/'seal.json').read_bytes())['files'][name]
    return value
def run():
    live()
    with np.load(HOME/'native-map.npz') as bank: ids=bank['indices'];sqrt=bank['sqrt']
    with np.load(checked(SOURCE,'launch.npz')) as bank:
        ref={arm:bank[arm+'_forward'] for arm in ('reset','coupled')};mscale=float(bank['mscale'])
    def convert(vec):return np.pad(vec.reshape(len(sqrt),-1)/sqrt[:,None],((1,1),(0,0)))[ids]
    obj=Gravity('reset_forward',20,96)
    output=[]; checks=[]
    with np.load(path('ground-anchorA.npz')) as ground:
        early=ground['early'];matching=ground['matching']
    for route in ('three','two','reset','constant'):
        grids=(32,64) if route in ('two','three') else (64,)
        for level in grids:
            with np.load(path(f'state-anchorA-{route}-{level}.npz')) as bank:
                snaps=bank['snapshots'];states=bank['states']
            if level==64 and route in ('reset','three'):
                arm={'reset':'reset','three':'coupled'}[route]
                assert np.array_equal(convert(states[list(snaps).index(590)]),ref[arm])
            for snap,vec in zip(snaps,states):
                obj.nodes=convert(vec);out=observable(obj,20)
                pop=mscale*np.vdot(vec,vec).real
                assert abs(out['occupation']/pop-1)<1e-8
                output.append(dict(source='anchorA',route=route,steps=level,snapshot=int(snap),**out))
            if route in ('three','two','reset'):
                vec=states[0];g=early if route!='reset' else matching
                overlap=np.vdot(g,vec)/np.sqrt(np.vdot(g,g).real*np.vdot(vec,vec).real)
                chord=np.linalg.norm(vec/np.linalg.norm(vec)-np.exp(1j*np.angle(overlap))*g/np.linalg.norm(g))
                checks.append(dict(route=route,steps=level,initial_snap=snaps[0],ground='early' if route!='reset' else 'matching',phase_free_chord=chord))
    table('origin-trace.csv',output);table('ground-check.csv',checks)
    for row in output:
        if row['steps']==64 and row['route'] in ('three','reset'):
            print(row['route'],row['snapshot'],round(row['radial_mass_equivalent']/1e9,3),round(row['enclosed_true_Msun']/1e9,3))
    print(checks)
if __name__=='__main__':run()
