from evaluate import HERE,PARENT,read,G,table,np,score,take_bins
from tidal import solve
from scipy.integrate import quad

MODELS={
    'Pouliasis_I':[(460.,0.,.30),(1700.,5.30,.25),(1700.,2.60,.8)],
    'Pouliasis_II':[(1600.,4.80,.25),(1700.,2.00,.8)]
}
def vc2(components,radius):
    return sum(G*mass*2.32e7*radius**2/(radius**2+(major+minor)**2)**1.5 for mass,major,minor in components)
def potential(components,radius,height):
    return -sum(G*mass*2.32e7/np.hypot(radius,major+np.hypot(height,minor)) for mass,major,minor in components)
def rise_check(components,radius,height):
    rise=potential(components,radius,height)-potential(components,radius,0.)
    def kz(z):
        return sum(G*mass*2.32e7*(major+np.hypot(z,minor))*z/(np.hypot(z,minor)*np.hypot(radius,major+np.hypot(z,minor))**3) for mass,major,minor in components)
    assert abs(quad(kz,0.,height)[0]-rise)<1e-8
    return rise

def run():
    inputs=read(HERE/'fields.csv')
    bins=take_bins(np.loadtxt(HERE/'figure3-stars.csv',delimiter=',',skiprows=1),np.loadtxt(HERE/'figure3-native.csv',delimiter=',',skiprows=1))
    fields={(r['state'],float(r['R_kpc'])):float(r['phi_rise']) for r in read(PARENT/'field-finer.csv') if r['Z_kpc']=='0.4'}
    radii=sorted({key[1] for key in fields})
    out=[];vertical=[];direct=[]
    for model,components in MODELS.items():
        for arm in ('reset','coupled'):
            records=[r for r in inputs if r['arm']==arm and r['variant']=='nominal' and r['level']=='3' and r['method']=='stars_squared_speed']
            rad,vc,err,wave=np.array([[float(r[k]) for k in ('R_kpc','vc_kms','error','wave_v2')] for r in records]).T
            bary=np.array([np.mean(vc2(components,group[:,0])) for group in bins])
            for j in range(len(rad)):
                direct.append(dict(host=model,arm=arm,bin=j+1,obs=vc[j],ordinary_kms=np.sqrt(bary[j]),host_wave_kms=np.sqrt(bary[j]+wave[j])))
            for scope,mask in [('solar',(np.arange(len(rad))>=1)&(np.arange(len(rad))<=2)),('full',np.ones(len(rad),dtype=bool))]:
                meta=dict(model=model,arm=arm,scope=scope)
                out+=score(rad[mask],vc[mask],err[mask],(rad*bary)[mask],(rad*wave)[mask],meta)
                for eta in (0,1):
                    groups=[bins[j][:,0] for j in np.flatnonzero(mask)]
                    for row in solve(groups,vc[mask],err[mask],(bary+eta*wave)[mask],[(r,.4) for r in radii]):
                        r=row['R_kpc']
                        stellar=rise_check(components,r,.4)
                        total=stellar+eta*fields[arm+'_forward',r]
                        vertical.append(dict(**meta,eta=eta,**row,stellar_rise=stellar,stellar_plus_wave_rise=total,min_total_rise=total+row['added_vertical_infimum']))
    table('alternative-stellar-spheres.csv',out)
    table('alternative-stellar-forces.csv',direct)
    table('alternative-stellar-vertical.csv',vertical)

if __name__=='__main__':
    run()

