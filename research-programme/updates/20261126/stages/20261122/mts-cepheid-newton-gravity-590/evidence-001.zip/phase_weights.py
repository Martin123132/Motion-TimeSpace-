from evaluate import HERE,np,table
from PIL import Image

def runs(indices):
    return [g for g in np.split(indices,np.flatnonzero(np.diff(indices)>1)+1) if len(g)]

def extract():
    im=np.array(Image.open(HERE/'phase-figure6.png').convert('RGB'))
    assert im.shape==(1413,3083,3)
    ticks=[g.mean() for g in runs(np.flatnonzero((im[100:1130,260]<60).all(axis=1))+100)]
    assert len(ticks)==4 and np.ptp(np.diff(ticks))<.1
    step=20/(ticks[1]-ticks[0])
    observations=[]
    for solar,colour,ref,referr in zip([0,10,20],[(31,119,180),(255,127,14),(44,160,44)],[304.8,295.3,305.2],[4.,3.7,3.9]):
        mask=(im==colour).all(2)
        columns=runs(np.flatnonzero(mask[220:1140].sum(axis=0)>70))
        assert len(columns)==12
        group=[]
        for s in range(-3,4):
            xx=columns[s+5]
            mid=int(np.round(xx.mean()))
            yy=np.flatnonzero(mask[260:1140,mid])+260
            assert np.all(np.diff(yy)==1) and yy[0]>260 and yy[-1]<1139
            centroid=(yy[0]+yy[-1])/2
            spread=(yy[-1]-yy[0]+1)/2*step
            yy_mark=np.flatnonzero(mask[260:1140,mid+12])+260
            assert abs(centroid-(yy_mark[0]+yy_mark[-1])/2)<2
            group.append(dict(s=s,R_kpc=8.178+s*.1,Zsun_pc=solar,mean=340-(centroid-ticks[0])*step,
                sigma=spread,pixel_x=mid,pixel_top=int(yy[0]),pixel_bottom=int(yy[-1])))
        prec=1/np.array([d['sigma'] for d in group])**2
        weights=prec/prec.sum()
        rec_mean=weights@[d['mean'] for d in group]
        rec_err=1/np.sqrt(prec.sum())
        agrees=abs(rec_mean-ref)<.17 and abs(rec_err-referr)<.09
        for row,weight in zip(group,weights):
            row.update(figure_only_weight=weight,group_mean=rec_mean,group_error=rec_err,published_mean=ref,published_error=referr,summary_reproduced=bool(agrees))
        observations+=group
    table('phase-weights.csv',observations)
    return observations

def run():
    observations=extract()
    if not all(r['summary_reproduced'] for r in observations):
        print('Figure-only weights do not reproduce Eq. 29. No aggregate weighting authorized.')
if __name__=='__main__':
    run()

