import hashlib
import io
import tarfile
from source import HERE,save
import requests

URL='https://arxiv.org/src/2105.14030'
HASH='95a3ace7762d8d646dccba47abc84ec13b478dfca15ae6dc1c8c291a03142abd'
def run():
    with requests.get(URL,stream=True,timeout=(8,35)) as response:
        response.raise_for_status()
        data=bytearray()
        for part in response.iter_content(65536):
            data.extend(part)
            assert len(data)<12000000
    assert hashlib.sha256(data).hexdigest()==HASH
    with tarfile.open(fileobj=io.BytesIO(data)) as arc:
        assert 'summary_phi400pc' in arc.extractfile('aanda.tex').read().decode()
        save('phase-figure6.png',arc.extractfile('summary_phi400pc.png').read())
if __name__=='__main__':
    run()

