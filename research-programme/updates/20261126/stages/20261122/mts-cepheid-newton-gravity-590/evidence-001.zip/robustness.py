from evaluate import HERE,read,table,np,brentq
from local import G

def least_rise(rad,vc,err,fixed,R,h,mult):
    low=rad*((vc-mult*err)**2-fixed)
    high=rad*((vc+mult*err)**2-fixed)
    cuts=np.r_[0.,rad**3]
    lower=np.r_[0.,low]
    cap=min((high[j]-lower[i])/(cuts[j+1]-cuts[i]) for j in range(len(rad)) for i in range(j+1))
    mass=np.maximum.accumulate(np.maximum(0.,lower-cap*cuts))
    assert max(mass[1:]+cap*rad**3-high)<1e-6
    tip=np.hypot(R,h)
    grid=np.unique(np.r_[R,rad[(rad>R)&(rad<tip)],tip])
    return ((1/grid[:-1]-1/grid[1:])@mass[np.searchsorted(rad,grid[:-1],side='right')]-cap*h**2)

def run():
    nominal=read(HERE/'fields.csv')
    direct=read(HERE/'radial-vertical-tide.csv')
    out=[]
    for row in (r for r in direct if r['scope']=='solar' and r['method']=='native_center'):
        level,arm,rad=int(row['level']),row['arm'],float(row['R_kpc'])
        basearm='reset' if arm=='ordinary' else arm
        variant=row['variant']
        curves=[v for v in nominal if int(v['level'])==level and v['variant']==variant and v['arm']==basearm and v['method']=='native_center' and int(v['bin']) in (2,3)]
        radii,vc,err,bary,wave=np.array([[float(v[k]) for k in ('R_kpc','vc_kms','error','ordinary_v2','wave_v2')] for v in curves]).T
        fixed=bary if arm=='ordinary' else bary+wave
        own=float(row['host_plus_wave'])
        bound=lambda scale:own+least_rise(radii,vc,err,fixed,rad,.4,scale)
        assert abs(bound(1)-float(row['min_total_rise']))<1e-6
        ceiling=307.8
        if bound(0)<=ceiling:n=0.
        else:
            assert bound(30)<ceiling
            n=brentq(lambda scale:bound(scale)-ceiling,0,30)
        out.append(dict(level=level,arm=arm,variant=variant,R_kpc=rad,min_rise_at_1x=bound(1),min_rise_at_2x=bound(2),
            min_velocity_box_multiplier_for_rise_at_most_307p8=n))
    table('vertical-error-sensitivity.csv',out)
    mixes=[]
    for level in (2,3):
        for variant,method in dict.fromkeys((row['variant'],row['method']) for row in nominal):
            rows=[r for r in nominal if int(r['level'])==level and r['variant']==variant and r['method']==method and int(r['bin']) in (2,3)]
            reset=[r for r in rows if r['arm']=='reset']
            inherited=[r for r in rows if r['arm']=='coupled']
            assert len(reset)==len(inherited)==2
            masses=[]
            for data in (reset,inherited):
                rad,v,err,b,w=np.array([[float(r[k]) for k in ('R_kpc','vc_kms','error','ordinary_v2','wave_v2')] for r in data]).T
                masses.append(rad[0]*((v[0]-err[0])**2-b[0]-w[0])-rad[1]*((v[1]+err[1])**2-b[1]-w[1]))
            mixes.append(dict(level=level,variant=variant,method=method,least_required_mass_decrease_over_mixtures_Msun=min(masses)/G))
    table('convex-density-mixtures.csv',mixes)

if __name__=='__main__':
    run()

