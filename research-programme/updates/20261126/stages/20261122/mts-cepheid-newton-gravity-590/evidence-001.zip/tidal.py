from evaluate import HERE, PARENT, digest, manifest, read, take_bins, table, np, guard
from scipy.optimize import linprog, OptimizeWarning
import warnings

def shell_grid(groups):
    sites=np.unique(np.concatenate(groups))
    response=np.array([np.mean((group[:,None]>=sites)/group[:,None],axis=0) for group in groups])
    tide=np.array([np.mean(group**2) for group in groups])
    assert all(left.max()<right.min() for left,right in zip(groups[:-1],groups[1:]))
    return sites,response,tide

def solve(groups,velocity,error,fixed,heights,weights=None):
    sites,response,tidal=shell_grid(groups)
    units=1.e5
    lo=(velocity-error)**2-fixed
    hi=(velocity+error)**2-fixed
    harmonic=1/response[:,0]
    upper=harmonic*hi
    lower=np.r_[0.,harmonic*lo]
    coord=np.r_[0.,harmonic*tidal]
    cap=min((upper[end]-lower[start])/(coord[end+1]-coord[start]) for end in range(len(upper)) for start in range(end+1))
    design=np.c_[units*response,100*tidal]
    matrix=np.vstack((design,-design))/1e4
    target=np.r_[hi,-lo]/1e4
    bounds=[(0,None)]*len(sites)+[(None,None)]
    def opt(cost):
        with warnings.catch_warnings():
            warnings.simplefilter('ignore',OptimizeWarning)
            res=linprog(cost,A_ub=matrix,b_ub=target,bounds=bounds,method='highs',options={'threads':1,'parallel':False})
        assert res.success,res.message
        dual=res.ineqlin.marginals
        assert np.max(matrix@res.x-target)<1e-7 and min(res.x[:-1])>=-1e-8
        reduced=cost-matrix.T@dual
        assert np.max(dual)<=1.e-7 and np.min(reduced[:-1])>=-1.e-7 and abs(reduced[-1])<1.e-7
        assert abs(res.fun-target@dual)<1e-6
        return res
    best=opt(np.r_[np.zeros(len(sites)),-100])
    assert abs(best.x[-1]*100-cap)<1e-6
    result=[]
    for rad,height in heights:
        end=np.hypot(rad,height)
        factor=np.maximum(0.,1/np.maximum(sites,rad)-1/end)
        res=opt(np.r_[units*factor,-100*height**2])
        if all(len(group)==1 for group in groups):
            cuts=np.unique(np.r_[rad,sites[(sites>rad)&(sites<end)],end])
            residual=np.maximum.accumulate(np.maximum(0.,lower-cap*coord))
            inds=np.searchsorted(sites,cuts[:-1],side='right')
            direct=(1/cuts[:-1]-1/cuts[1:])@residual[inds]-cap*height**2
            assert abs(res.fun-direct)<1e-6
        result.append(dict(R_kpc=rad,height=height,max_A_kms2_kpc2=cap,A_at_infimum=100*res.x[-1],
            sphere_at_infimum=units*factor@res.x[:-1],external_at_infimum=-100*height**2*res.x[-1],added_vertical_infimum=res.fun))
    if weights is not None:
        weights=np.asarray(weights)
        assert len(weights)==len(heights) and weights.min()>=0 and abs(weights.sum()-1)<1e-12
        shell_cost=np.zeros(len(sites))
        tide_cost=0.
        for weight,(rad,height) in zip(weights,heights):
            shell_cost+=weight*units*np.maximum(0.,1/np.maximum(sites,rad)-1/np.hypot(rad,height))
            tide_cost-=weight*100*height**2
        res=opt(np.r_[shell_cost,tide_cost])
        assert res.fun+1.e-6>=weights@[r['added_vertical_infimum'] for r in result]
        return res.fun,result
    return result

def run():
    for item in ('measurement.json','foreground.csv','field-finer.csv','field-fine.csv'):
        assert digest(PARENT/item)==manifest[item]
    rows=read(HERE/'fields.csv')
    obs=np.loadtxt(HERE/'cepheids.csv',delimiter=',',skiprows=1)
    bins=take_bins(np.loadtxt(HERE/'figure3-stars.csv',delimiter=',',skiprows=1),np.loadtxt(HERE/'figure3-native.csv',delimiter=',',skiprows=1))
    foreground={(int(row['level']),float(row['R_kpc'])):float(row['positive_direct']) for row in read(PARENT/'foreground.csv') if row['Z_kpc']=='0.4'}
    radii=sorted({key[1] for key in foreground})
    out=[]
    for level in (2,3):
        fields={(row['state'],float(row['R_kpc'])):float(row['phi_rise']) for row in read(PARENT/('field-fine.csv' if level==2 else 'field-finer.csv')) if row['Z_kpc']=='0.4'}
        for variant,method in dict.fromkeys((row['variant'],row['method']) for row in rows if row['method']!='reference_center'):
            guard()
            for arm in ('ordinary','reset','coupled'):
                selected=[r for r in rows if int(r['level'])==level and r['variant']==variant and r['method']==method and r['arm']==('reset' if arm=='ordinary' else arm)]
                arrays=np.array([[float(r[k]) for k in ('R_kpc','vc_kms','error','ordinary_v2','wave_v2')] for r in selected])
                native,vc,error,bary,wave=arrays.T
                fixed=bary if arm=='ordinary' else bary+wave
                for scope,mask in [('solar',abs(obs[:,0]-8.178)<=1),('full',np.ones(len(obs),dtype=bool))]:
                    groups=[bins[i][:,0] if method=='stars_squared_speed' else native[i:i+1] for i in np.flatnonzero(mask)]
                    for record in solve(groups,vc[mask],error[mask],fixed[mask],[(r,.4) for r in radii]):
                        rad=record['R_kpc']
                        term=foreground[level,rad]+(0 if arm=='ordinary' else fields[arm+'_forward',rad])
                        out.append(dict(level=level,variant=variant,method=method,arm=arm,scope=scope,**record,host_plus_wave=term,
                            min_total_rise=record['added_vertical_infimum']+term))
    table('radial-vertical-tide.csv',out)
    print('Saved',len(out),'radial/vertical bounds')

if __name__=='__main__':
    run()

