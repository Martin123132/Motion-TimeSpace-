from evaluate import HERE,PARENT,manifest,digest,read,np,table
from local_phase import cone,score_joint
from source import save
import csv
import json
import sys

def verify():
    assert all(digest(PARENT/name)==sha for name,sha in manifest.items())
    assert digest(HERE/'phase-figure6.png')=='0f5e64907237298cdac49da316da34cb08a5a2bd08a0d3ac6c919a54e98952b7'
    data=read(HERE/'sphere-tests.csv')
    assert len(data)==320 and all((r['eta']=='0.0')==(r['feasible']=='True') for r in data)
    assert len(read(HERE/'figure3-stars.csv'))==903 and len(read(HERE/'signed-shifts.csv'))==108
    assert len(read(HERE/'common-shell-phase-boxes.csv'))==936
    assert all(r['summary_reproduced']=='False' for r in read(HERE/'phase-weights.csv')) and not (HERE/'matched-phase-rise.csv').exists()
    gates=[]
    for file,metric in (('sphere-tests.csv','min_order_slack_1e9Msun'),('distance-sphere.csv','min_order_slack_1e9Msun'),
                          ('radial-vertical-tide.csv','min_total_rise'),('common-shell-phase-boxes.csv','min_vertical_box_multiplier')):
        rows=read(HERE/file)
        ids=[k for k in ('variant','curve','method','arm','model','eta','scope','R_kpc','Zsun_pc','digitization_allowance') if k in rows[0]]
        key=lambda row:tuple(row[k] for k in ids)
        low={key(r):float(r[metric]) for r in rows if r['level']=='2'}
        high={key(r):float(r[metric]) for r in rows if r['level']=='3'}
        assert low.keys()==high.keys() and len(low)==len(rows)//2
        err=max(abs(low[k]/high[k]-1) for k in low)
        assert err<.005
        gates.append(dict(file=file,observable=metric,pairs=len(low),max_relative_error=err))
    radii=np.array([7.88,8.178,8.478])
    groups=[np.array([7.23,7.58]),np.array([8.04,8.56])]
    design,vertical=cone(groups,radii,.4)
    true_tide=-25.
    r_shell=8.177
    mass=2.e4
    full=np.array([2.1e5*np.mean(1/g)+mass*np.mean((g>r_shell)/g)+true_tide*np.mean(g*g) for g in groups])
    top=np.hypot(radii,.4)
    full_z=2.1e5*(1/radii-1/top)+mass*np.maximum(0.,1/np.maximum(radii,r_shell)-1/top)-true_tide*.4**2
    result,_=score_joint(design,vertical,np.sqrt(full),np.full(2,.01),np.zeros(2),np.zeros(3),full_z,np.ones(3),0.)
    assert abs(result)<1e-7
    forced,_=score_joint(design,vertical,np.sqrt(full),np.full(2,.01),np.zeros(2),np.zeros(3),np.full(3,-1.e3),np.ones(3),0.)
    assert forced>100
    table('refinement-audit.csv',gates)
    print('46 upstream hashes intact; signed and ordinary controls, honest phase-weight failure, cross-grid and planted shell/tide controls verified.')

if __name__=='__main__':
    verify()
    if '--seal' in sys.argv:
        files={p.name:digest(p) for p in sorted(HERE.iterdir()) if p.is_file() and p.name!='seal.json'}
        save('seal.json',(json.dumps(files,indent=2,sort_keys=True)+'\n').encode())
        print(len(files),digest(HERE/'seal.json'))

