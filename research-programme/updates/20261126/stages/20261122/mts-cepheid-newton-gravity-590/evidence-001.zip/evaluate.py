import csv
import hashlib
import json
import os
import sys
from pathlib import Path

for var in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','BLIS_NUM_THREADS'):
    os.environ[var]='1'
from source import HERE, table
import numpy as np
from scipy.interpolate import RectBivariateSpline
from scipy.optimize import brentq, linprog, OptimizeWarning
import warnings

PARENT=HERE.parent/'mts-preparation-vertical-gravity-590-20261122'
def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
assert digest(PARENT/'seal.json')=='37a872fe0e0c207030ca5c4825940b22be066191dcfd3097d28f3169b104aef7'
manifest=json.loads((PARENT/'seal.json').read_bytes())
for name in ('green.py','local.py','launch.npz','radial-predictions.csv','rotation-data.csv','occupation.json'):
    assert digest(PARENT/name)==manifest[name]
sys.path.insert(0,str(PARENT))
from green import Gravity
from local import G, FIX, pin, guard, STATES
sys.path.insert(0,str(FIX))
pin(FIX,'mesh_fd.py')
pin(FIX,'finite_io.py')
from mesh_fd import Space

def read(path):
    with path.open() as stream:
        return list(csv.DictReader(stream))

def take_bins(stars,means):
    ordered=stars[stars[:,0].argsort()]
    start=0
    bins=[]
    for rad,vc,rms in means:
        rest=ordered[start:]
        counts=np.arange(1,len(rest)+1)
        allowed=np.flatnonzero(abs(rest[:,0].cumsum()/counts-rad)<.00002)
        assert len(allowed)==1
        count=allowed.item()+1
        group=rest[:count]
        assert abs(np.mean(group[:,1]**2)**.5-rms)<.0001
        bins.append(group)
        start+=count
    assert start==len(ordered)==903
    return bins

def slack(rad,vlow,vhigh,ordinary,wave,strength):
    target=ordinary+strength*wave
    low=rad*vlow**2-target
    high=rad*vhigh**2-target
    witness=np.maximum.accumulate(np.maximum(0.,low))
    end=int(np.argmin(high-witness))
    inner=int(np.argmax(low[:end+1])) if witness[end]>0 else -1
    return float((high-witness)[end]),inner,end

def shared_interval(coeff,rhs):
    low=0.
    high=np.inf
    for coef,limit in zip(coeff,rhs):
        if coef>0:high=min(high,limit/coef)
        elif coef<0:low=max(low,limit/coef)
        elif limit<0:return None
    return (low,high) if high>=low else None

def score(rad,vel,err,ordinary,wave,meta):
    lower=rad*(vel-err)**2
    upper=rad*(vel+err)**2
    delta=lambda vec:np.array([vec[j]-(vec[i] if i>=0 else 0.) for j in range(len(rad)) for i in range(-1,j)])
    room=np.array([upper[j]-(lower[i] if i>=0 else 0.) for j in range(len(rad)) for i in range(-1,j)])
    bounds=shared_interval(delta(wave),room-delta(ordinary))
    scale=shared_interval(-room,-delta(wave+ordinary))
    result=[]
    for eta in (0.,1.):
        gap,inner,outer=slack(rad,vel-err,vel+err,ordinary,wave,eta)
        missing=lambda frac:slack(rad,(vel-err)*(1-frac),(vel+err)*(1+frac),ordinary,wave,eta)[0]
        extra=0. if gap>=0 else brentq(missing,0,.95)
        lower_mass=(lower-ordinary-eta*wave)/G/1e9
        upper_mass=(upper-ordinary-eta*wave)/G/1e9
        mat=np.eye(len(rad))[:-1]-np.eye(len(rad))[1:]
        with warnings.catch_warnings():
            warnings.simplefilter('ignore',OptimizeWarning)
            solver=linprog(np.zeros(len(rad)),A_ub=np.vstack([mat,np.eye(len(rad)),-np.eye(len(rad))]),b_ub=np.r_[np.zeros(len(mat)),upper_mass,-lower_mass],bounds=(0,None),method='highs',options={'threads':1,'parallel':False})
        assert solver.status in (0,2) and solver.success==(gap>=0)
        assert (bounds is not None and bounds[0]<=eta<=bounds[1])==(gap>=0)
        result.append(dict(**meta,eta=eta,feasible=(gap>=0),min_order_slack_1e9Msun=gap/G/1e9,inner_bin=(inner+1 if inner>=0 else 0),
            outer_bin=outer+1,inner_effective_R=(rad[inner] if inner>=0 else ''),outer_effective_R=rad[outer],
            min_free_bin_speed_fraction=extra,eta_min=bounds[0] if bounds else '',eta_max=bounds[1] if bounds else '',
            shared_5pct_for_fixed_wave=bool(scale is not None and scale[0]<=1.05**2 and scale[1]>=.95**2)))
    return result

def run():
    guard()
    obs=np.loadtxt(HERE/'cepheids.csv',delimiter=',',skiprows=1)
    stars=np.loadtxt(HERE/'figure3-stars.csv',delimiter=',',skiprows=1)
    means=np.loadtxt(HERE/'figure3-native.csv',delimiter=',',skiprows=1)
    bins=take_bins(stars,means)
    variants={'nominal':(obs[:,0],np.zeros(len(obs)))}
    shifts=read(HERE/'signed-shifts.csv')
    for variant in dict.fromkeys(row['variant'] for row in shifts):
        data=[row for row in shifts if row['variant']==variant]
        variants[variant]=tuple(np.array([float(row[k]) for row in data]) for k in ('figure_R','shift'))
    anchor=read(PARENT/'radial-predictions.csv')
    old_radii=np.array([float(row['R_kpc']) for row in read(PARENT/'rotation-data.csv')])
    nodes=np.unique(np.r_[stars[:,0],old_radii,*[points for points,_ in variants.values()]])
    def at(values,radii):
        idx=nodes.searchsorted(radii)
        assert np.array_equal(nodes[idx],radii)
        return values[idx]
    waves={}
    checks=[]
    def check(name,error,tol=.005):
        assert np.isfinite(error) and error<=tol,(name,error,tol)
        checks.append(dict(check=name,error=error,tolerance=tol))
    occupation=json.loads((PARENT/'occupation.json').read_bytes())
    for state in STATES:
        guard()
        for order,angular in ((18,90),(24,110)):
            vals,mass=Gravity(state,order,angular).evaluate(nodes,np.zeros_like(nodes))
            check(state+'_mass_'+str(order),abs(mass/occupation[state]-1),1e-8)
            if order==18:
                coarse=vals[:,1]
            else:
                waves[state]=vals[:,1]
                check(state+'_wave_force',max(abs(coarse/vals[:,1]-1)))
    for arm in ('reset','coupled'):
        check(arm+'_parity',max(abs(waves[arm+'_forward']-waves[arm+'_reverse'])),1e-10)
    score_rows=[]
    field_rows=[]
    bin_rows=[]
    point_reference={}
    for level,order in ((2,4),(3,4)):
        guard()
        with np.load(pin(FIX,f'mass-{level}-{order}.npz')) as obj:
            space=Space(obj['rf'],obj['mf'])
            potential=space.poisson(4*np.pi*G*obj['mass'][1])
        ir=np.flatnonzero((space.r>nodes.min()-.55)&(space.r<nodes.max()+.55))
        ia=np.flatnonzero(space.mu<.09)
        sub=potential[np.ix_(ir,ia)]
        spline=RectBivariateSpline(space.r[ir],np.r_[-space.mu[ia][::-1],space.mu[ia]],np.column_stack([sub[:,::-1],sub]),s=0)
        assert space.r[ir[0]]<nodes.min() and nodes.max()<space.r[ir[-1]]
        ordinary=spline.ev(nodes,np.zeros_like(nodes),dx=1)
        if level==2:coarse_o=ordinary
        else:check('all_nodes_ordinary_force',max(abs(coarse_o/ordinary-1)))
        for arm in ('reset','coupled'):
            wave=waves[arm+'_forward']
            old=[row for row in anchor if row['foreground']=='positive' and row['state']==arm+'_forward' and row['level']==str(level) and row['measured']]
            check('old_speed_'+str(level)+arm,max(abs(np.sqrt(old_radii*at(ordinary+wave,old_radii))/[float(row['vc_kms']) for row in old]-1)))
            for variant,(radii,shift) in variants.items():
                positions=['native_center','reference_center'] if variant!='nominal' else ['native_center','stars_squared_speed']
                for method in positions:
                    radial=radii if method=='native_center' else obs[:,0]
                    if method=='stars_squared_speed':
                        radial=np.array([1/np.mean(1/group[:,0]) for group in bins])
                        def components(arr):
                            return np.array([np.mean(group[:,0]*at(arr,group[:,0])) for group in bins])
                        barysq,wavesq=components(ordinary),components(wave)
                    else:
                        barysq,wavesq=radial*at(ordinary,radial),radial*at(wave,radial)
                    speed=obs[:,1]*(1+shift)
                    error=obs[:,2]
                    meta=dict(level=level,arm=arm,variant=variant,method=method)
                    for idx,rad in enumerate(radial):
                        field_rows.append(dict(**meta,bin=idx+1,R_kpc=rad,vc_kms=speed[idx],error=error[idx],ordinary_v2=barysq[idx],wave_v2=wavesq[idx]))
                    for scope,mask in [('solar',abs(obs[:,0]-8.178)<=1),('full',np.ones(len(speed),dtype=bool))]:
                        score_rows+=score(radial[mask],speed[mask],error[mask],(radial*barysq)[mask],(radial*wavesq)[mask],dict(**meta,scope=scope))
                    if variant=='nominal' and method=='native_center':
                        point_reference[level,arm]=barysq+wavesq
                    if method=='stars_squared_speed':
                        for idx,group in enumerate(bins):
                            bin_rows.append(dict(level=level,arm=arm,bin=idx+1,count=len(group),min_R=min(group[:,0]),max_R=max(group[:,0]),
                                mean_R=np.mean(group[:,0]),harmonic_R=radial[idx],bin_minus_center_kms=np.sqrt(barysq[idx]+wavesq[idx])-np.sqrt(point_reference[level,arm][idx])))
    table('fields.csv',field_rows)
    table('sphere-tests.csv',score_rows)
    table('bin-averaging.csv',bin_rows)
    table('checks.csv',checks)
    print('Saved',len(score_rows),'sphere checks and',len(bin_rows),'bin comparisons; controls',len(checks))

if __name__=='__main__':
    run()

