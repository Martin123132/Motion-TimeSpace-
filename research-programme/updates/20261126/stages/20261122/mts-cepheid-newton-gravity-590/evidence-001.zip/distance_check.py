from evaluate import HERE,PARENT,FIX,Space,Gravity,G,guard,pin,read,np,RectBivariateSpline,table,score,slack,brentq
from tidal import solve
import fitz
import tarfile

def extract():
    output={}
    with tarfile.open(HERE/'paper-source.tar.gz') as arc, fitz.open(stream=arc.extractfile('RC_figure_sk_dist_rc.pdf').read()) as doc:
        draws=doc[0].get_drawings()
        box=draws[1]['rect']
        assert np.allclose([draws[i]['rect'].x0 for i in range(2,6)],box.x0+np.arange(4)*4*box.width/14,atol=.0001)
        assert np.allclose([draws[i]['rect'].y0 for i in range(6,10)],box.y1-np.arange(4)*box.height/3,atol=.0001)
        for offset,name in ((13,'full_replay'),(49,'common_SK25'),(85,'common_Feng')):
            bars=draws[offset:offset+12]
            assert all(d['type']=='s' and d['rect'].width==0 and d['rect'].height>0 for d in bars)
            vals=[]
            for draw in bars:
                rect=draw['rect']
                vals.append((6+(rect.x0-box.x0)*14/box.width,150+(box.y1-(rect.y0+rect.y1)/2)*150/box.height,rect.height*75/box.height))
            output[name]=np.array(vals)
        original=np.loadtxt(HERE/'cepheids.csv',delimiter=',',skiprows=1)
        assert np.max(abs(output['full_replay']-original))<.0051
    table('distance-curves.csv',[dict(curve=name,R_kpc=r,vc_kms=v,error_kms=e) for name,arr in output.items() for r,v,e in arr])
    return output

def run():
    curves=extract()
    nodes=np.unique(np.concatenate([arr[:,0] for arr in curves.values()]))
    waves={arm:Gravity(arm+'_forward',24,110).evaluate(nodes,np.zeros_like(nodes))[0][:,1] for arm in ('reset','coupled')}
    previous=read(PARENT/'foreground.csv')
    radii=sorted({float(r['R_kpc']) for r in previous})
    sphere=[]
    tidal=[]
    for level in (2,3):
        guard()
        with np.load(pin(FIX,f'mass-{level}-4.npz')) as data:
            space=Space(data['rf'],data['mf'])
            potential=space.poisson(4*np.pi*G*data['mass'][1])
        ir=np.flatnonzero((space.r>nodes.min()-.55)&(space.r<nodes.max()+.55))
        ia=np.flatnonzero(space.mu<.09)
        part=potential[np.ix_(ir,ia)]
        spline=RectBivariateSpline(space.r[ir],np.r_[-space.mu[ia][::-1],space.mu[ia]],np.column_stack([part[:,::-1],part]),s=0)
        ordinary=spline.ev(nodes,np.zeros_like(nodes),dx=1)
        bg={float(r['R_kpc']):float(r['positive_direct']) for r in previous if r['Z_kpc']=='0.4' and int(r['level'])==level}
        fields={(r['state'],float(r['R_kpc'])):float(r['phi_rise']) for r in read(PARENT/('field-finer.csv' if level==3 else 'field-fine.csv')) if r['Z_kpc']=='0.4'}
        for name,arr in curves.items():
            for scope,mask in [('solar',abs(arr[:,0]-8.178)<=1),('full',np.ones(len(arr),dtype=bool))]:
                rad,vc,err=arr[mask].T
                idx=nodes.searchsorted(rad)
                for arm,acc in waves.items():
                    meta=dict(level=level,curve=name,scope=scope,arm=arm)
                    bary=rad**2*ordinary[idx]
                    wave=rad**2*acc[idx]
                    outputs=score(rad,vc,err,bary,wave,meta)
                    for item in outputs:
                        eta=item['eta']
                        margin=lambda n:slack(rad,vc-n*err,vc+n*err,bary,wave,eta)[0]
                        n=0. if margin(0)>=0 else brentq(margin,0,min(vc/err)*.99)
                        sphere.append(dict(**item,min_joint_box_multiplier=n))
                        if eta==0 and arm=='coupled':
                            continue
                        fixed=(bary+eta*wave)/rad
                        for row in solve([np.array([r]) for r in rad],vc,err,fixed,[(r,.4) for r in radii]):
                            R=row['R_kpc']
                            tidal.append(dict(**meta,eta=eta,**row,min_total_rise=bg[R]+eta*fields[arm+'_forward',R]+row['added_vertical_infimum']))
    table('distance-sphere.csv',sphere)
    table('distance-tide.csv',tidal)
    print('Distance cases',len(sphere),len(tidal))

if __name__=='__main__':
    run()

