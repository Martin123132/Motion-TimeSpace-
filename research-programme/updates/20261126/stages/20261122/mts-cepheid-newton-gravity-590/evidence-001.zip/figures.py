import csv
import tarfile
import fitz
import numpy as np
from source import HERE, table

def center(drawing):
    box = drawing['rect']
    return np.array([(box.x0 + box.x1)/2, (box.y0 + box.y1)/2])

def rows():
    with (HERE/'cepheids.csv').open() as stream:
        return np.array([[float(v) for v in row.values()] for row in csv.DictReader(stream)])

def extracts():
    obs = rows()
    with fitz.open(HERE/'signed-figure.pdf') as doc:
        drawings = doc[0].get_drawings()
        axis = lambda index: drawings[index]['items'][0][1]
        ticks_x = [axis(idx).x for idx in range(112,119)]
        get_x = lambda x: np.interp(x,ticks_x,np.arange(6,20,2))
        for ticks in (ticks_x,[axis(idx).y for idx in range(2,8)],[axis(idx).y for idx in range(119,125)]):
            assert np.ptp(np.diff(ticks)) < .0001
        names = ['U_Huang','U_Wang','R0_PM_minus','R0_PM_plus','Vsolar_minus10','Vsolar_plus10','wedge15','wedge60','wedge180']
        starts = [10,23,36,49,62,75,127,140,153]
        legends = [93,96,99,102,105,108,171,174,177]
        signed = []
        for name,start,legend in zip(names,starts,legends):
            path = drawings[start]
            assert path['color'] == drawings[legend]['color'] and path['dashes']==drawings[legend]['dashes']
            seg = path['items']
            assert len(seg)==11 and all(item[0]=='l' for item in seg)
            points = np.array([list(seg[0][1])] + [list(item[2]) for item in seg])
            markers = np.array([center(d) for d in drawings[start+1:start+13]])
            assert np.max(abs(points-markers)) < .001
            bottom = name.startswith('wedge')
            zero, span = (122,123) if bottom else (4,5)
            radius = get_x(points[:,0])
            shifts = .02*(axis(zero).y-points[:,1])/(axis(zero).y-axis(span).y)
            assert np.max(abs(radius-obs[:,0])) < .20 and np.min(np.diff(radius))>.45
            signed += [dict(variant=name,bin=i+1,table_R=r,figure_R=x,shift=f) for i,(r,x,f) in enumerate(zip(obs[:,0],radius,shifts))]
        table('signed-shifts.csv',signed)
    with tarfile.open(HERE/'paper-source.tar.gz') as arc, fitz.open(stream=arc.extractfile('RC_figure_2_ne.pdf').read()) as doc:
        drawings = doc[0].get_drawings()
        box = drawings[1]['rect']
        def physical(item):
            x,y = center(item)
            return 6+(x-box.x0)*14/box.width,150+(box.y1-y)*150/box.height
        stars=np.array([physical(d) for d in drawings if len(d['items'])==8 and d['color'] and max(abs(value-.5) for value in d['color'])<.003])
        assert len(stars)==903
        measured=np.array([physical(d) for d in drawings[1001:1013]])
        moment=np.array([physical(d) for d in drawings[989:1001]])
        assert np.max(abs(measured-obs[:,:2]))<.0051 and np.max(abs(measured[:,0]-moment[:,0]))<1e-5
        table('figure3-stars.csv',[dict(R_kpc=r,Vphi_kms=v) for r,v in stars])
        table('figure3-native.csv',[dict(R_kpc=r,vc_kms=v,rms_Vphi_kms=t) for (r,v),t in zip(measured,moment[:,1])])
    return stars, measured, moment

if __name__=='__main__':
    stars, observed, moments = extracts()
    for idx in range(9):
        mask = (stars[:,0]>=6+idx)&(stars[:,0]<7+idx)
        print(idx+1,mask.sum(), stars[mask,0].mean()-observed[idx,0],np.median(stars[mask,0])-observed[idx,0], np.mean(stars[mask,1]**2)**.5 - moments[idx,1])

