from pathlib import Path
import csv
import hashlib
import io
import json
import re
import tarfile

import requests

HERE = Path(__file__).resolve().parent
URL = 'https://arxiv.org/src/2512.21780v1'
HASH = '560835aa8f0c219df954c5e94d5c3ec5247ac82c3ef1c5a2569db66f36f2ede1'

def save(name, data):
    path = HERE / name
    if path.exists():
        assert path.read_bytes() == data, name
    else:
        with path.open('xb') as stream:
            stream.write(data)

def table(name, rows):
    buf = io.StringIO()
    writer = csv.DictWriter(buf, list(rows[0]), lineterminator='\n')
    writer.writeheader()
    writer.writerows(rows)
    save(name, buf.getvalue().encode())

def acquire():
    path = HERE / 'paper-source.tar.gz'
    if not path.exists():
        with requests.get(URL, stream=True, timeout=(8,30)) as response:
            response.raise_for_status()
            out = bytearray()
            for chunk in response.iter_content(65536):
                out.extend(chunk)
                assert len(out) < 1000000
        assert hashlib.sha256(out).hexdigest() == HASH
        save(path.name, bytes(out))
    assert hashlib.sha256(path.read_bytes()).hexdigest() == HASH
    with tarfile.open(path) as arc:
        latex = arc.extractfile('Main.tex').read().decode()
        section = next(sec.split(r'\end{table}')[0] for sec in latex.split(r'\begin{table}')[1:] if '6.58' in sec.split(r'\end{table}')[0])
        found = re.findall(r'(\d+\.\d+)\s*&\s*(\d+\.\d+)\s*&\s*(\d+\.\d+)\s*\\\\', section)
        assert len(found) == 12, section
        table('cepheids.csv',[dict(R_kpc=rad,vc_kms=vel,bootstrap_kms=err) for rad,vel,err in found])
        for figure in latex.split(r'\begin{figure}')[1:]:
            part = figure.split(r'\end{figure}')[0]
            if 'wedge' in part.lower() and 'solar' in part.lower():
                print(part[:1800])
                name = re.search(r'\\includegraphics[^{]*\{([^}]+)\}',part).group(1)
                save('signed-figure.pdf',arc.extractfile(name).read())
                return
        raise ValueError('could not identify figure')

if __name__ == '__main__':
    acquire()

