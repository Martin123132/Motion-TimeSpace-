import sys
from tides import np,table,record,load,host,states_back,history,CONV,SIZE,GM,advance,probes,observe,initial
def transform(seg,kind,epoch):
    new=host(seg);fwd=seg.tables['forward'];rev=seg.tables['reverse']
    if kind=='static':
        core=np.zeros(fwd.shape[1:])
        assert np.linalg.norm(fwd[epoch,...,0]-rev[epoch,...,0])<=1e-10*np.linalg.norm(fwd[epoch,...,0])
        core[:,0,:,0]=.5*(fwd[epoch,:,0,:,0]+rev[epoch,:,0,:,0])
        archive=np.broadcast_to(core,fwd.shape)
    else:
        archive=.5*(fwd+rev)
    new.tables={'forward':archive,'reverse':archive}
    return new

def run(factor,step):
    label=f'{factor}-{step}';tides=[];samples=[];probes_out=[];checks=[]
    for arm in ('reset','coupled'):
        original=load(factor,step,arm)
        if arm=='reset':
            base=[host(s) for s in original];shared=states_back(base,'forward');del base
        for kind in ('static','mean'):
            parts=[transform(s,kind,epoch) for s,epoch in zip(original,(-1,0))]
            if kind=='static':
                left,right=parts
                idx=np.searchsorted(left.rad,right.rad);assert np.array_equal(left.rad[idx],right.rad)
                aa=left.tables['forward'][-1,idx,0,:,0];bb=right.tables['forward'][0,:,0,:,0]
                assert np.linalg.norm(aa-bb)<=1e-9*np.linalg.norm(bb)
            states=states_back(parts,'forward');case=arm+'_'+kind;res=history(parts,case,'forward',states,shared)
            tides.extend(res[0]);samples.extend(res[1]);probes_out.extend(res[2]);checks.append(dict(case=case,roundtrip=res[3],
                min_early=parts[0].minr,max_early=parts[0].maxr,min_late=parts[1].minr,max_late=parts[1].maxr))
            print(label,case,res[3],flush=True)
            del parts
        del original
    for name,rows in [('tides',tides),('populations',samples),('probes',probes_out),('orbits',checks)]:table('control-'+name+'-'+label+'.csv',rows)

class Isolated:
    def acc(self,time,points,sign):return np.zeros_like(points)
def isolated():
    xyz,vel,keys=probes();state=(np.vstack([np.zeros(3),xyz]),np.vstack([np.zeros(3),vel]))
    duration=111.158776;period=np.linalg.norm(vel,axis=1)/np.linalg.norm(xyz,axis=1);phase=(duration*period)[:,None]
    target=xyz*np.cos(phase)+vel*np.sin(phase)/period[:,None]
    base=observe(state);rows=[]
    for steps in (480,960,1920):
        result=observe(advance(Isolated(),'forward',state,0,duration,steps,True))
        err=np.max(np.linalg.norm(result[0]-target,axis=1)/base[2]);energy=np.max(abs((result[-1]-base[-1])/base[-1]))
        assert err<.005 and energy<.005 and np.max(result[-1])<0
        rows.append(dict(steps=steps,max_pos_fraction=err,max_energy_fraction=energy))
    assert all(rows[i+1]['max_pos_fraction']<.26*rows[i]['max_pos_fraction'] for i in (0,1))
    table('isolated-check.csv',rows)
if __name__=='__main__':
    isolated()
    for factor,step in ((2,1),(4,1),(4,2)):run(factor,step)
