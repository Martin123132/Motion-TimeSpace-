import csv
from scipy.optimize import brentq
from mass_controls import transform
from tides import HOME,SIZE,GM,np,IDEN,load,host,states_back,one_tide,scalar_jet,tensor,table
def roots(seg,sign,time,state):
    pos,vel=state;rad=np.linalg.norm(pos);acc=seg.acc(time,pos[None,:],sign)[0]
    omega=np.cross(pos,vel)/rad**2;dot=np.cross(pos,acc)/rad**2-2*(pos@vel)*omega/rad**2
    mat=tensor(pos,scalar_jet(seg,time,pos,sign)[0]);effective=mat+(omega@omega)*IDEN-np.outer(omega,omega)
    lam,dirs=np.linalg.eigh(effective);direction=dirs[:,-1]
    if direction@pos<0:direction=-direction
    def full(offset):
        distant=seg.acc(time,pos+offset,sign)
        return distant-acc-np.cross(omega,np.cross(omega,offset))-np.cross(dot,offset)-GM*offset/(np.sum(offset*offset,axis=1)+SIZE**2)[:,None]**1.5
    rows=[];scale=(GM/lam[-1])**(2/3)-SIZE**2 if lam[-1]>0 else None
    for polarity in (1,-1):
        axis=polarity*direction;steps=np.geomspace(.0001,.30,160);force=full(steps[:,None]*axis)@axis
        brackets=np.flatnonzero((force[:-1]<0)&(force[1:]>=0));root='';off='';relative=''
        if force[0]>=0:status='no_restoring_core_along_axis'
        elif not len(brackets):status='no_outward_crossing_to_300pc'
        else:
            idx=brackets[0];distance=brentq(lambda r:(full(np.array([r*axis]))@axis)[0],steps[idx],steps[idx+1],xtol=1e-13)
            projected=full(np.array([distance*axis]))[0];binding=GM*distance/(distance*distance+SIZE**2)**1.5
            assert abs(projected@axis)<1e-7*binding
            root=1000*distance;off=np.linalg.norm(projected)/binding;status='axis_crossing_only'
            if scale and scale>0:relative=distance/np.sqrt(scale)-1
        rows.append(dict(side='outward' if polarity==1 else 'inward',status=status,cross_pc=root,
            linear_pc=1000*np.sqrt(scale) if scale and scale>0 else '',fraction_from_linear=relative,transverse_over_binding=off))
    return rows

def run(native=False):
    if native:
        from native import Material,NativeSegment,jet
        global scalar_jet
        scalar_jet=jet
        material=Material()
    result=[]
    for factor,step in ((2,1),(4,2)):
        label=f'{factor}-{step}'
        for arm in ('reset','coupled'):
            parts=load(factor,step,arm)
            for model in (('ordinary',) if arm=='reset' else ())+('forward','reverse','static','mean'):
                case='ordinary' if model=='ordinary' else arm+'_'+model
                fields=([host(s) for s in parts] if model=='ordinary' else
                      [transform(s,model,idx) for s,idx in zip(parts,(-1,0))] if model in ('static','mean') else parts)
                if native:fields=[NativeSegment(s,material,snaps) for s,snaps in zip(fields,((586,590),(590,600)))]
                sign='reverse' if model=='reverse' else 'forward';states=states_back(fields,sign)
                prefix='native-' if native else ('control-' if model in ('static','mean') else '')
                with (HOME/(prefix+'tides-'+label+'.csv')).open(newline='') as stream:
                    data=[r for r in csv.DictReader(stream) if r['case']==case and r['path']=='own']
                for epoch,row in [('closest',min(data,key=lambda r:float(r['gal_kpc']))),('max_effective_stretch',max(data,key=lambda r:float(r['rotating_lambda']))),('present',data[-1])]:
                    block=0 if row['segment']=='early' else 1;idx=int(row['index']);time=states[block][0][idx]
                    for res in roots(fields[block],sign,time,states[block][1][idx]):
                        result.append(dict(factor=factor,step=step,case=case,epoch=epoch,time=row['time'],**res))
                del fields
            del parts
    table(('native-' if native else '')+'finite-balance.csv',result)
if __name__=='__main__':run('--native' in __import__('sys').argv)
