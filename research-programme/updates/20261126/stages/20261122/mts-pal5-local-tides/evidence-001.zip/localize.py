from tides import load,host,tensor,scalar_jet,states_back,np,table,HOME

def coarsen(segment):
    obj=host(segment);obj.rad=segment.rad[::2];obj.host=segment.host[:,::2]
    obj.tables={s:a[:,::2] for s,a in segment.tables.items()};return obj
def norm(x):return np.linalg.norm(x.reshape(len(x),-1),axis=1)
def run():
    all_stats=[];locations=[]
    for arm in ('reset','coupled'):
        fine=load(4,2,arm);coarse=load(2,1,arm)
        dec=[coarsen(segment) for segment in fine]
        assert all(np.array_equal(a.rad,b.rad) for a,b in zip(dec,coarse))
        high={s:states_back(fine,s) for s in ('forward','reverse')}
        low={s:states_back(coarse,s) for s in ('forward','reverse')}
        for geometry in ('own','shared_forward'):
            components={};times=[];radii=[]
            for name,banks,paths in [('fine',fine,high),('coarse_nodes',dec,high),('coarse_fixedpath',coarse,high),('coarse_ownpath',coarse,low)]:
                hostonly=[host(s) for s in banks];by_sign=[]
                for sign in ('forward','reverse'):
                    pa=paths[sign if geometry=='own' else 'forward'];vals=[];coords=[];stamp=[]
                    prev=0.
                    for seg,empty,(clock,states) in zip(banks,hostonly,pa):
                        for time,(pos,vel) in zip(clock,states):
                            total=tensor(pos,scalar_jet(seg,time,pos,sign)[0]);base=tensor(pos,scalar_jet(empty,time,pos,sign)[0])
                            vals.append([total,base,total-base]);coords.append(np.linalg.norm(pos));stamp.append(prev+time)
                        prev+=seg.end
                    by_sign.append(np.array(vals))
                    if name=='fine' and sign=='forward':radii=coords;times=stamp
                components[name]=by_sign[0]-by_sign[1]
            reference=components['fine'];whole=components['coarse_ownpath']-reference
            budget={'radial_interpolation':components['coarse_nodes']-reference,
                    'remaining_bank':components['coarse_fixedpath']-components['coarse_nodes'],
                    'orbit_path':components['coarse_ownpath']-components['coarse_fixedpath']}
            assert np.max(abs(sum(budget.values())-whole))<1e-15
            assert np.allclose(whole[:,0],whole[:,1]+whole[:,2],rtol=1e-8,atol=1e-15)
            for mechanism,val in [('total_difference',whole),*budget.items()]:
                den=np.linalg.norm(reference[:,0])
                vnorm=norm(val[:,0]);idx=int(vnorm.argmax());all_stats.append(dict(arm=arm,geometry=geometry,mechanism=mechanism,
                  frac_signed_tide=np.linalg.norm(val[:,0])/den,ordinary_contribution=np.linalg.norm(val[:,1])/den,
                  wave_contribution=np.linalg.norm(val[:,2])/den,worst_epoch_Myr=times[idx],forward_radius_kpc=radii[idx],
                  peak_fraction_of_squared_discrepancy=vnorm[idx]**2/sum(vnorm**2) if vnorm.any() else 0))
                for j in np.argsort(-vnorm)[:3]:
                    locations.append(dict(arm=arm,geometry=geometry,mechanism=mechanism,time=times[j],r_kpc=radii[j],
                      delta_norm=vnorm[j],ordinary_norm=norm(val[:,1])[j],wave_norm=norm(val[:,2])[j]))
        del fine,coarse,dec,banks,hostonly
    table('resolution-budget.csv',all_stats);table('resolution-hotspots.csv',locations)
if __name__=='__main__':run()
