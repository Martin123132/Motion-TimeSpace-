import json
import numpy as np
from verify import read,arr,fraction
from tides import HOME,record,table
def validate():
    old=json.loads((HOME/'verification.json').read_bytes());new=json.loads((HOME/'native-verification.json').read_bytes())
    for v in (old,new):assert v['history_checks']==270 and v['balance_checks']==54
    delta=read('native-probes-4-2.csv');cases=sorted(set(r['case'] for r in delta));assert len(cases)==9
    def tags(case):return [(float(r['energy'])>0,int(r['ever']),int(r['returned'])) for r in delta if r['case']==case]
    ref=tags('reset_forward')
    changes={c:sum(a!=b for a,b in zip(ref,tags(c))) for c in cases}
    compare=[]
    for stage in ('','native-'):
        rows=read(stage+'history-convergence.csv')
        for arm in ('reset','coupled'):
            for step in ('4-1','4-2'):
                part=[r for r in rows if r['case']==arm+'_forward-reverse' and r['path']=='own' and r['label']==step]
                compare.append(dict(host=stage or 'resampled',arm=arm,refinement=step,**{r['metric']:float(r['relative']) for r in part}))
    table('host-repair-comparison.csv',compare)
    errors={stage:dict(total=v['history_checks'],failed=len(v['history_fail']),failed_balance=len(v['balance_fails']),failed_pointwise=v['pointwise_fails']) for stage,v in [('original',old),('native',new)]}
    record('decision.json',dict(grids=errors,tag_changes_vs_reset_forward=changes,source_replay=json.loads((HOME/'source-replay.json').read_bytes()),
        face_audit=json.loads((HOME/'native-face-audit.json').read_bytes()),scope='No likelihood, no N-body population or empirical stripping dates; shared classifications refer to matched deterministic probes.'))
    print(errors,changes)
if __name__=='__main__':validate()
