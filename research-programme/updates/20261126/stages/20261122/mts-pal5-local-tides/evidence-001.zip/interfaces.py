import csv
from scipy.optimize import brentq
from native import Material,NativeSegment
from tides import HOME,np,CONV,SIZE,IDEN,advance,states_back,load,table,record
from numpy.polynomial.legendre import legvander

def run():
    mat=Material();faces=mat.right[:-1];out=[]
    for arm in ('reset','coupled'):
        original=load(4,2,arm);parts=[NativeSegment(s,mat,snaps) for s,snaps in zip(original,((586,590),(590,600)))]
        for sign in ('forward','reverse'):
            states=states_back(parts,sign);offset=0.
            for seg,(times,path),bins in zip(parts,states,(96,24)):
                for idx in range(1,len(times)):
                    left,right=times[idx-1:idx+1];before=path[idx-1];after=path[idx]
                    r0,r1=np.linalg.norm(before[0]),np.linalg.norm(after[0])
                    for edge in faces[(faces>min(r0,r1))&(faces<=max(r0,r1))]:
                        def state(time):
                            pos,vel=advance(seg,sign,tuple(s[None,:] for s in before),left,time,seg.steps//bins,False)
                            return pos[0],vel[0]
                        if (np.linalg.norm(state(left)[0])-edge)*(np.linalg.norm(state(right)[0])-edge)>0:raise ValueError('invalid crossing bracket')
                        epoch=brentq(lambda tt:np.linalg.norm(state(tt)[0])-edge,left,right,xtol=1e-11)
                        pos,vel=state(epoch);nrm=pos/np.linalg.norm(pos);vr=vel@nrm;pol=legvander(nrm[2],68).ravel()[::2]
                        traces=[mat.radial(np.array([edge]),seg.snaps,epoch/seg.end,1,side) for side in ('left','right')]
                        dp=(traces[1][0][0]-traces[0][0][0])@pol
                        dacc=-CONV**2*((traces[1][1][0]-traces[0][1][0])@pol)
                        acc=seg.acc(epoch,pos[None,:],sign)[0]
                        assert abs(vr)>1e-5 and np.linalg.norm(pos)>0
                        out.append(dict(arm=arm,sign=sign,segment='early' if bins==96 else 'late',time=epoch+offset,interface_kpc=edge,
                               increasing=int(vr>0),v_radial_kms=vr/CONV,potential_jump_kms2=dp,
                               increasing_radial_acceleration_jump=dacc,relative_to_total_force=abs(dacc)/np.linalg.norm(acc),
                               saltation_Myr_inv=dacc/abs(vr),linear_scale_kick_kms=SIZE*dacc/abs(vr)/CONV))
                offset+=seg.end
        del parts,original
    table('native-face-crossings.csv',out)
    record('native-face-audit.json',dict(bracketed_crossings=len(out),max_abs_potential_jump_kms2=max(abs(r['potential_jump_kms2']) for r in out),
       max_abs_acceleration_jump_fraction=max(r['relative_to_total_force'] for r in out),max_abs_linear_scale_kick_kms=max(abs(r['linear_scale_kick_kms']) for r in out),
       note='Resolved radius brackets of sampled centres, not exhaustive of arbitrarily short excursions. Saltation is a first-order crossing-time sensitivity, not a physical kick to the centre.'))
if __name__=='__main__':run()
