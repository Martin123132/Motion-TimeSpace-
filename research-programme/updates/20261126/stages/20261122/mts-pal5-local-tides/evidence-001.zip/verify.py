import csv
from itertools import combinations_with_replacement
from collections import defaultdict
from tides import HOME,np,SIZE,GM,CONV,MASS,sha,table,record,tensor,IDEN

def read(name):
    with (HOME/name).open(newline='') as stream:return list(csv.DictReader(stream))
def grouped(name,label,variant=''):
    result=defaultdict(list)
    for prefix in (('native-',) if variant else ('','control-')):
        for row in read(prefix+name+'-'+label+'.csv'):result[row['case']].append(row)
    assert len(result)==9
    return result
def arr(rows,keys):
    return np.array([[float(r[k]) for k in keys] for r in rows])
def scalar(rows,k):return arr(rows,[k]).ravel()
def rms(vector):return np.linalg.norm(vector)/np.sqrt(len(vector))
def fraction(first,last):return float(np.linalg.norm(first-last)/np.linalg.norm(last))
def mats(rows,prefix):
    return np.array([[[float(row[prefix+str(min(i,j))+str(max(i,j))]) for j in range(3)] for i in range(3)] for row in rows])
def analytic():
    pos=np.array([3.,4.,1.5]);r=np.linalg.norm(pos);unit=pos/r
    kepler=tensor(pos,[1/r**2,-2/r**3,0.,0.,0.])/CONV**2
    assert np.max(abs(kepler-(3*np.outer(unit,unit)-IDEN)/r**3))<1e-14
    harmonic=tensor(pos,[r,1.,0.,0.,0.])/CONV**2
    assert np.max(abs(harmonic+IDEN))<1e-13
    mu=unit[2]
    quadr=tensor(pos,[2*r*mu**2,2*mu**2,2*r*r*mu,4*r*mu,2*r*r])/CONV**2
    assert np.max(abs(quadr+2*np.outer(IDEN[2],IDEN[2])))<1e-13
def main(variant=''):
    analytic();summ=[];diff=[];points=[];checks=[];counts=[];previous={};ep=[];statusrows=[]
    for label in ('2-1','4-1','4-2'):
        tides=grouped('tides',label,variant);probes=grouped('probes',label,variant);population=grouped('populations',label,variant)
        orbits=grouped('orbits',label,variant);fields={};tags={}
        for case,both in tides.items():
            row=orbits[case][0];assert float(row['roundtrip'])<1e-9 and 2<float(row['min_early'])<float(row['max_early'])<35 and 12<float(row['min_late'])<float(row['max_late'])<29
            for path in ('own','matched_host'):
                part=[r for r in both if r['path']==path];assert len(part)==122
                base=part if path=='own' else [r for r in tides['ordinary'] if r['path']=='own']
                if path=='matched_host':assert max(abs(scalar(part,'gal_kpc')-scalar(base,'gal_kpc')))<1e-10
                for k,values in [('tensor',mats(part,'t')),('finite_chord',mats(part,'chord')),
                                     ('effective',scalar(part,'rotating_lambda')),('radii',scalar(part,'gal_kpc'))]:
                    fields[case,path,k]=values
                if label=='4-2':
                    for epoch,r in [('closest',min(part,key=lambda r:float(r['gal_kpc']))),('strongest',max(part,key=lambda r:float(r['rotating_lambda']))),('present',part[-1])]:
                        ep.append(dict(case=case,path=path,epoch=epoch,**{k:r[k] for k in ('time','gal_kpc','lambda1','rotating_lambda','plummer_pc','point_pc','salpeter_pc','minusmass_pc','plusmass_pc','euler_over_lambda')}))
                    summ.append(dict(case=case,path=path,min_gal_kpc=min(scalar(part,'gal_kpc')),min_balance_pc=min(float(r['plummer_pc']) for r in part if r['plummer_pc']!=''),
                        max_fd=max(scalar(part,'fd_resid')),max_antisym=max(scalar(part,'fd_antisym')),
                        halfsize_max=max(scalar(part,'halfsize_resid')),halfsize_median=np.median(scalar(part,'halfsize_resid')),
                        twosize_max=max(scalar(part,'twosize_resid')),onesided_max=max(scalar(part,'onesided_resid')),
                        halfsize_gt005=int(sum(scalar(part,'halfsize_resid')>.005)),
                        max_euler_over_lambda=max(scalar(part,'euler_over_lambda'))))
            block=probes[case];assert [int(r['probe']) for r in block]==list(range(72))
            for k in (('positions',['dx','dy','dz']),('velocities',['vx','vy','vz']),('energy',['energy'])):fields[case,'own',k[0]]=arr(block,k[1])
            tags[case]=[(r['ever'],r['returned'],float(r['energy'])>0) for r in block]
            for shell in (1,2,3):
                sub=[r for r in block if int(r['shell'])==shell];early=[r for r in population[case] if r['shell']==str(shell)]
                onset=[float(r['first_positive_Myr']) for r in sub if r['first_positive_Myr']]
                if label=='4-2':
                    counts.append(dict(case=case,shell=shell,n=len(sub),ever=sum(int(r['ever']) for r in sub),end=sum(float(r['energy'])>0 for r in sub),
                        returned=sum(int(r['returned']) for r in sub),first_cross=min(onset) if onset else '',
                        median_radius=np.median(scalar(sub,'radius_pc')),max_radius=max(scalar(sub,'radius_pc')),median_energy=np.median(scalar(sub,'energy'))))
        for arm in ('reset','coupled'):
            pair=[('forward','reverse'),('mean','static')]
            for left,right in pair:
                title=arm+'_'+left+'-'+right;left=arm+'_'+left;right=arm+'_'+right
                for path,metrics in [('own',('tensor','finite_chord','effective','positions','velocities','energy')),('matched_host',('tensor','finite_chord','effective'))]:
                    for metric in metrics:
                        aa=fields[left,path,metric];bb=fields[right,path,metric];delta=aa-bb;fields[title,path,metric]=delta
                        if label=='4-2':
                            diff.append(dict(case=title,path=path,metric=metric,norm_relative_to_mean=np.linalg.norm(delta)/np.linalg.norm(.5*(aa+bb)),
                                 rms_native=rms(delta),max_abs_native=np.max(abs(delta))))
                if label=='4-2':
                    for shell in (1,2,3):
                        idx=np.array([r['shell']==str(shell) for r in probes[left]]);subset=np.flatnonzero(idx)
                        shifts=1000*np.linalg.norm(fields[title,'own','positions'][idx],axis=1)
                        deltaE=fields[title,'own','energy'][idx]
                        common=[(float(probes[left][i]['first_positive_Myr']),float(probes[right][i]['first_positive_Myr'])) for i in subset if probes[left][i]['first_positive_Myr'] and probes[right][i]['first_positive_Myr']]
                        statusrows.append(dict(case=title,shell=shell,end_label_changes=sum(tags[left][i][2]!=tags[right][i][2] for i in subset),
                          ever_label_changes=sum(tags[left][i][0]!=tags[right][i][0] for i in subset),
                          returned_label_changes=sum(tags[left][i][1]!=tags[right][i][1] for i in subset),
                          common_first_count=len(common),max_sampled_onset_shift=max((abs(a-b) for a,b in common),default=''),
                          rms_position_split_pc=rms(shifts),max_position_split_pc=max(shifts),rms_delta_energy=rms(deltaE)))
        if previous:
            for key,value in fields.items():
                old=previous[key];err=fraction(old,value)
                checks.append(dict(label=label,case=key[0],path=key[1],metric=key[2],relative=err,passes=bool(err<=.005)))
                if key[2] in ('tensor','finite_chord') and key[0] in tides:
                    local=np.linalg.norm(old-value,axis=(1,2))/np.linalg.norm(value,axis=(1,2))
                    points.append(dict(label=label,case=key[0],path=key[1],metric=key[2],max_relative=max(local),points_over=int(sum(local>.005))))
            for case in tides:
                assert prevtags[case]==tags[case],('category grid sensitivity',case)
        previous=fields;prevtags=tags
    for name,rows in [('tidal-summary',summ),('epochs',ep),('tagged-stars',counts),('signed-differences',diff),('probe-contrasts',statusrows),('history-convergence',checks),('point-convergence',points)]:
        table(variant+name+'.csv',rows)
    crossings=read(variant+'finite-balance.csv');assert len(crossings)==108
    coarse=[r for r in crossings if r['factor']=='2'];fine=[r for r in crossings if r['factor']=='4']
    changes=[]
    for a,b in zip(coarse,fine):
        assert (a['case'],a['epoch'],a['side'])==(b['case'],b['epoch'],b['side'])
        changes.append(dict(case=b['case'],epoch=b['epoch'],side=b['side'],same_status=a['status']==b['status'],
          relative=abs(float(a['cross_pc'])/float(b['cross_pc'])-1) if a['cross_pc'] and b['cross_pc'] else '',
          sampled_epoch_difference=abs(float(a['time'])-float(b['time']))))
    table(variant+'balance-convergence.csv',changes)
    record(variant+'verification.json',dict(total_duration_Myr=111.158776,plummer_size_pc=SIZE*1000,gravitational_parameter_kpc3_Myr2=GM,inputs_mass_msun=MASS,
       analytic_fields=['Kepler','isotropic oscillator','z^2 Cartesian quadrupole'],isolated_max_orbit_error=max(scalar(read('isolated-check.csv'),'max_pos_fraction')),
       numerical_relative_tolerance=.005,history_checks=len(checks),history_fail=[row for row in checks if not row['passes']],
       pointwise_comparisons_total=len(points)*122,pointwise_fails=sum(r['points_over'] for r in points),
       balance_checks=len(changes),balance_fails=[r for r in changes if not r['same_status'] or (r['relative']!='' and r['relative']>.005)],
       max_local_tensor_analytic_fd=max(r['max_fd'] for r in summ),
       tags_same_all_grids=9*72,stages=['2-1','4-1','4-2']))
    if variant and (HOME/'RESULTS.md').exists() and (HOME/'verification.json').exists():
        files={p.name:sha(p) for p in sorted(HOME.iterdir()) if p.is_file() and p.name!='seal.json'}
        record('seal.json',files);print('Sealed',len(files),sha(HOME/'seal.json'))
if __name__=='__main__':main('native-' if '--native' in __import__('sys').argv else '')
