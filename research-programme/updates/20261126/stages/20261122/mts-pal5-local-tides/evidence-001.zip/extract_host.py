import os
for name in ('OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','OMP_NUM_THREADS','NUMEXPR_NUM_THREADS'):os.environ[name]='1'
import sys
import io
import json
import hashlib
from pathlib import Path
import numpy as np
HOME=Path(__file__).resolve().parent
ROOT=HOME.parent
sys.path.insert(0,str(ROOT/'mts-flow-formation-inverse-586-20261122'))
import inverse
def keep(name,data):
    path=HOME/name
    if path.exists():assert path.read_bytes()==data
    else:
        with path.open('xb') as output:output.write(data)
def run():
    assert inverse.sha(Path(inverse.__file__).parent/'seal.json')=='4ae215216dac834ea5d8ae503fea680707af22348044627efb0b507a7c398fcb'
    lab,_,_,_,_=inverse.setup()
    from directional import Radial
    mesh=Radial(lab,16);length=lab.bg.length if hasattr(lab,'bg') else lab.obj.bg.length
    norm=np.sqrt(2*mesh.sell+1)*lab.obj.bg.vel**2
    pack={'left':mesh.el.left*length,'right':mesh.el.right*length,'knots':mesh.el.knots}
    audits=[]
    for snap in (586,590,600):
        nodes=mesh.potential_nodes(lab.mesh.ordinary+lab.run.fields[snap])
        pack['nodes'+str(snap)]=nodes*(length*norm)
        for folder,file,slot in [(ROOT/'mts-pal5-joined-flow-586-600-20261122','early-280-reset.npz',0 if snap==586 else 1)] if snap==586 else (
                [(ROOT/'mts-pal5-joined-flow-586-600-20261122','early-280-reset.npz',1),(inverse.LAST,'potential-72.npz',0)] if snap==590 else [(inverse.LAST,'potential-72.npz',1)]):
            with np.load(folder/file) as src:
                val,slope=mesh.values(nodes,src['radius']/length)
                actual=np.stack([val*norm,slope*norm/length],axis=-1);ref=src['host'][slot]
                rel=np.linalg.norm(actual-ref)/np.linalg.norm(ref);assert rel<1e-12
                audits.append(dict(snap=snap,archive=file,samples=len(val),rel=rel))
    buf=io.BytesIO();np.savez_compressed(buf,**pack);keep('native-ordinary.npz',buf.getvalue())
    keep('source-replay.json',(json.dumps(dict(rows=audits,native_sha256=hashlib.sha256(buf.getvalue()).hexdigest()),indent=2)+'\n').encode())
    print('Native host recovered',len(pack['left']),audits)
if __name__=='__main__':run()
