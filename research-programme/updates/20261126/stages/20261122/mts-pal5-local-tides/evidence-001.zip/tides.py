import csv
import hashlib
import io
import json
import os
import sys
from pathlib import Path
for name in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS'):
    os.environ[name]='1'
import numpy as np
from scipy.constants import parsec
from scipy.special import eval_legendre,eval_jacobi
from scipy.interpolate import CubicHermiteSpline

HOME=Path(__file__).resolve().parent
ROOT=HOME.parent
JOIN=ROOT/'mts-pal5-joined-flow-586-600-20261122'
LATEST=ROOT/'mts-pal5-astrometric-tangent-20261122'
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def verified(home,digest,names=()):
    assert sha(home/'seal.json')==digest
    files=json.loads((home/'seal.json').read_bytes())
    for name in names:assert sha(home/name)==files[name]
    return files
OLD=verified(JOIN,'86d9b1296c253b14a04e475339a9cbf71f84fed201749a234af4892b715576b7',('tracers.py','early.py'))
verified(LATEST,'797fd6892c4dde34909f3bdd1c9381df0753b4531f5aef4366a2d1ca5989b16f',('wave.py','freeze.py','RESULTS.md'))
sys.path.insert(0,str(JOIN))
from tracers import Segment,CONV,PAL,LATE,pinned
from orbit import SUN,VSUN,ROT,icrs
MASS=4297.
GM=(1.3271244e20/(1000*parsec)/1e6)*MASS*CONV**2
SIZE=20.6*np.tan(np.deg2rad(3.21/60))
DEGS=np.arange(0,69,2)
IDEN=np.eye(3)
SIDES=('forward','reverse')
def keep(name,data):
    dest=HOME/name
    if dest.exists():
        if dest.read_bytes()!=data:raise ValueError('changed existing product: '+name)
    else:
        with dest.open('xb') as out:out.write(data)
def table(name,rows):
    buf=io.StringIO(newline='');writer=csv.DictWriter(buf,fieldnames=list(rows[0]),lineterminator='\n');writer.writeheader();writer.writerows(rows);keep(name,buf.getvalue().encode())
def record(name,obj):keep(name,(json.dumps(obj,indent=2,sort_keys=True,allow_nan=False)+'\n').encode())
def initial():
    ra=np.array([229.018]);dec=np.array([-.124]);normal=icrs(ra,dec);east=icrs(ra+90,dec*0);north=np.cross(normal,east)
    return SUN+20.6*(normal@ROT.T),(VSUN+((-58.7*normal+4.74047*20.6*(-2.75*east-2.69*north))@ROT.T))*CONV
def host(segment):
    other=object.__new__(Segment);other.__dict__=dict(segment.__dict__)
    other.tables={k:np.broadcast_to(0.,v.shape) for k,v in segment.tables.items()}
    return other
def load(factor,step,arm):
    early=f'early-{70*factor}-{arm}.npz';late=f'potential-{18*factor}.npz'
    with np.load(pinned(JOIN/early,OLD[early])) as bank:first=Segment(bank,arm,192*factor*step)
    with np.load(pinned(PAL/late,LATE[late])) as bank:last=Segment(bank,arm,192*step)
    return first,last
def states_back(parts,sign):
    state=initial();stages=[]
    for seg,bins in zip(parts[::-1],(24,96)):
        times=np.linspace(0.,seg.end,bins+1);rev=[tuple(x[0].copy() for x in state)]
        for idx in range(bins,0,-1):
            state=advance(seg,sign,state,times[idx],times[idx-1],seg.steps//bins,False)
            rev.append(tuple(x[0].copy() for x in state))
        stages.append((times,rev[::-1]))
    return stages[::-1]
def advance(seg,sign,state,begin,end,nsteps,cluster):
    pos,vel=(a.copy() for a in state)
    def force(time,where):
        acc=seg.acc(time,where,sign)
        if cluster:
            delta=where[1:]-where[0]
            acc[1:]-=GM*delta/(np.sum(delta*delta,axis=1)+SIZE**2)[:,None]**1.5
        return acc
    clock=np.linspace(begin,end,nsteps+1)
    acc=force(begin,pos)
    for a,b in zip(clock[:-1],clock[1:]):
        inc=b-a;vel+=.5*inc*acc;pos+=inc*vel;acc=force(b,pos);vel+=.5*inc*acc
    return pos,vel
def scalar_jet(seg,time,pos,sign):
    rad=np.linalg.norm(pos);dist=seg.rad;idx=np.searchsorted(dist,rad)-1
    assert 0<=idx<len(dist)-1
    sl=slice(idx,idx+2);times=seg.times;tick=int(np.clip(np.searchsorted(times,time)-1,0,len(times)-2))
    tspan=times[tick+1]-times[tick];frac=(time-times[tick])/tspan
    arr=seg.tables[sign];left=arr[tick,sl];right=arr[tick+1,sl]
    wave=(1-frac)**2*(1+2*frac)*left[...,0]+frac**2*(3-2*frac)*right[...,0]+tspan*frac*(1-frac)*((1-frac)*left[...,1]-frac*right[...,1])
    p=time/seg.end;coeff=wave+(1-p)*seg.host[0,sl]+p*seg.host[1,sl]
    spline=CubicHermiteSpline(dist[sl],coeff[...,0],coeff[...,1],axis=0)
    unity=pos/rad;mu=unity[2];leg=eval_legendre(DEGS,mu);dleg=np.zeros(len(leg));ddleg=dleg.copy()
    nz=DEGS[1:];dleg[1:]=(nz+1)/2*eval_jacobi(nz-1,1,1,mu)
    ddleg[1:]=(nz+1)*(nz+2)/4*eval_jacobi(nz-2,2,2,mu)
    value,deriv,second=[spline(rad,nu) for nu in (0,1,2)]
    return [deriv@leg,second@leg,value@dleg,deriv@dleg,value@ddleg],min(rad-dist[idx],dist[idx+1]-rad)
def tensor(pos,jet):
    rad=np.linalg.norm(pos);unit=pos/rad;mu=unit[2];m=IDEN[2]-mu*unit
    uu=np.outer(unit,unit);trans=IDEN-uu;mix=np.outer(m,unit)+np.outer(unit,m)
    pr,prr,pm,prm,pmm=jet
    return -CONV**2*(prr*uu+(pr/rad-mu*pm/rad**2)*trans+(prm/rad-pm/rad**2)*mix+pmm*np.outer(m,m)/rad**2)
def matrix_fields(mat,prefix):return {prefix+str(i)+str(j):mat[i,j] for i in range(3) for j in range(i,3)}
def one_tide(seg,sign,time,pos,vel):
    jet,knot=scalar_jet(seg,time,pos,sign);tidal=tensor(pos,jet);norm=np.linalg.norm(tidal)
    vals,axes=np.linalg.eigh(tidal);rad=np.linalg.norm(pos);acc=seg.acc(time,pos[None,:],sign)[0]
    omega=np.cross(pos,vel)/rad**2;dot=np.cross(pos,acc)/rad**2-2*(pos@vel)/rad**2*omega
    effective=tidal+(omega@omega)*IDEN-np.outer(omega,omega);eigs,dirs=np.linalg.eigh(effective);lam=eigs[-1]
    def radius(mass):
        if lam<=0:return ''
        value=(GM*(mass/MASS)/lam)**(2/3)-SIZE**2
        return 1000*np.sqrt(value) if value>0 else 0.
    directions=IDEN
    def finite(step):
        pp=pos+step*directions;mm=pos-step*directions
        both=seg.acc(time,np.vstack([pp,mm]),sign)
        return ((both[:3]-both[3:])/(2*step)).T
    fd_small=min(.0001,max(knot*.35,1e-8))
    fd=finite(fd_small);full=finite(SIZE);double=finite(2*SIZE)
    offsets=np.vstack([dirs[:,-1],-dirs[:,-1]])*SIZE
    near=seg.acc(time,pos+offsets,sign)-acc
    exp=offsets@tidal.T
    result=dict(gal_kpc=rad,lambda1=vals[-1],lambda2=vals[-2],lambda3=vals[0],
      rotating_lambda=lam,omega=np.linalg.norm(omega),euler=np.linalg.norm(dot),
      euler_over_lambda=np.linalg.norm(dot)/max(abs(lam),1e-30),point_pc=1000*(GM/lam)**(1/3) if lam>0 else '',
      plummer_pc=radius(MASS),minusmass_pc=radius(MASS-98),plusmass_pc=radius(MASS+98),salpeter_pc=radius(16700),
      knot_pc=knot*1000,fd_pc=fd_small*1000,fd_resid=np.linalg.norm(fd-tidal)/norm,
      fd_antisym=np.linalg.norm(fd-fd.T)/norm,halfsize_resid=np.linalg.norm(full-tidal)/norm,
      twosize_resid=np.linalg.norm(double-tidal)/norm,
      onesided_resid=np.linalg.norm(near-exp)/max(np.linalg.norm(exp),1e-30),
      **matrix_fields(tidal,'t'),**matrix_fields(.5*(full+full.T),'chord'))
    return result
def probes():
    points=[];speeds=[];keys=[]
    for shell in (1,2,3):
        r=shell*SIZE;vc=np.sqrt(GM*r**2/(r*r+SIZE**2)**1.5)
        for axis in range(3):
            for polarity in (-1,1):
                for tangent in range(3):
                    if tangent==axis:continue
                    for sign in (-1,1):
                        points.append(r*polarity*IDEN[axis]);speeds.append(vc*sign*IDEN[tangent])
                        keys.append((shell,axis,polarity,tangent,sign))
    return np.array(points),np.array(speeds),keys
def observe(state):
    rel=state[0][1:]-state[0][:1];speed=state[1][1:]-state[1][:1];rad=np.linalg.norm(rel,axis=1)
    energy=.5*np.sum(speed*speed,axis=1)-GM/np.sqrt(rad**2+SIZE**2)
    return rel,speed,rad,energy
def history(parts,case,sign,stages,shared):
    tide=[];samples=[];final=[];x0,v0,keys=probes()
    center=stages[0][1][0];state=(np.vstack([center[0],center[0]+x0]),np.vstack([center[1],center[1]+v0]))
    lastE=observe(state)[-1];ever=np.zeros(len(keys),bool);returned=ever.copy();first=np.full(len(keys),np.nan)
    offset=0.;err=0.
    for segname,seg,back,hostpath in zip(('early','late'),parts,stages,shared):
        times,orbit=back
        for idx,(time,center,common) in enumerate(zip(times,orbit,hostpath[1])):
            for path,reference in [('own',center),('matched_host',common)]:
                tide.append(dict(case=case,segment=segname,index=idx,path=path,time=offset+time,
                                 **one_tide(seg,sign,time,*reference)))
            if idx:
                state=advance(seg,sign,state,times[idx-1],time,seg.steps//(len(times)-1),True)
            err=max(err,max(np.max(abs(value[0]-ref)) for value,ref in zip(state,center)))
            rel,speed,rad,energy=observe(state);positive=energy>0
            first[positive&~ever]=time+offset;returned|=ever&~positive;ever|=positive
            if idx or segname=='early':
                for shell in (1,2,3):
                    select=np.array([k[0]==shell for k in keys])
                    samples.append(dict(case=case,shell=shell,time=time+offset,gal_kpc=np.linalg.norm(center[0]),
                     positive=int(positive[select].sum()),ever=int(ever[select].sum()),returned=int(returned[select].sum()),
                     median_pc=np.median(rad[select])*1000,max_pc=max(rad[select])*1000,
                     median_e=np.median(energy[select])/CONV**2))
            lastE=energy
        offset+=times[-1]
    assert err<1e-9,err
    for idx,(shell,axis,polarity,tangent,signv) in enumerate(keys):
        final.append(dict(case=case,probe=idx,shell=shell,axis=axis,polarity=polarity,tangent=tangent,vel_sign=signv,
            first_positive_Myr=first[idx] if ever[idx] else '',ever=int(ever[idx]),returned=int(returned[idx]),
            radius_pc=rad[idx]*1000,energy=lastE[idx]/CONV**2,**dict(zip(('dx','dy','dz'),rel[idx])),**dict(zip(('vx','vy','vz'),speed[idx]))))
    return tide,samples,final,err
def run(factor,step):
    label=str(factor)+'-'+str(step)
    tides=[];times=[];probes_out=[];checks=[]
    for arm in ('reset','coupled'):
        parts=load(factor,step,arm)
        if arm=='reset':
            base=[host(seg) for seg in parts];shared=states_back(base,'forward')
        for case,sign,fields in ([('ordinary','forward',base)] if arm=='reset' else [])+[(arm+'_'+s,s,parts) for s in SIDES]:
            states=shared if case=='ordinary' else states_back(fields,sign)
            result=history(fields,case,sign,states,shared);tides.extend(result[0]);times.extend(result[1]);probes_out.extend(result[2])
            checks.append(dict(case=case,roundtrip=result[3],min_early=fields[0].minr,max_early=fields[0].maxr,
                               min_late=fields[1].minr,max_late=fields[1].maxr))
            print(label,case,'closed',result[3],flush=True)
        if arm=='reset':del base
        del fields,parts
    for name,rows in [('tides',tides),('populations',times),('probes',probes_out),('orbits',checks)]:table(name+'-'+label+'.csv',rows)
if __name__=='__main__':run(*map(int,sys.argv[1:3]))
