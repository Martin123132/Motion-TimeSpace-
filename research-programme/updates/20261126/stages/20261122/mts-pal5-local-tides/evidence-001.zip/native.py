import json
import sys
import tides
from tides import np,HOME,CONV,DEGS,table,record,sha,IDEN,initial,load,host,states_back,history,Segment
from scipy.special import eval_legendre,eval_jacobi
from numpy.polynomial.legendre import legvander,legder
from mass_controls import transform
OLDJET=tides.scalar_jet

class Material:
    def __init__(self):
        assert sha(HOME/'native-ordinary.npz')==json.loads((HOME/'source-replay.json').read_bytes())['native_sha256']
        with np.load(HOME/'native-ordinary.npz') as bank:
            self.left,self.right=bank['left'],bank['right'];self.width=self.right-self.left
            knots=bank['knots'];design=legvander(2*knots-1,len(knots)-1)
            self.co={}
            for snap in (586,590,600):
                nodes=bank['nodes'+str(snap)];coef=np.einsum('ij,sjl->sil',np.linalg.inv(design),nodes)
                assert np.max(abs(np.einsum('ij,sjl->sil',design,coef)-nodes))/np.max(abs(nodes))<1e-13
                self.co[snap]=[coef,legder(coef,axis=1)*(2/self.width[:,None,None]),
                               legder(coef,2,axis=1)*(2/self.width[:,None,None])**2]
    def radial(self,radii,snaps,frac,order=1,side='left'):
        cell=self.right.searchsorted(radii,side=side).clip(0,len(self.left)-1)
        if min(radii)<=0 or max(radii)>=self.right[-1]:raise ValueError('native radial support')
        coords=2*(radii-self.left[cell])/self.width[cell]-1
        coeffs=self.co[snaps[0]],self.co[snaps[1]]
        r=radii[:,None];out=[]
        basis=legvander(coords,coeffs[0][0].shape[1]-1)
        for deg in range(order+1):
            a,b=coeffs[0][deg],coeffs[1][deg];values=np.einsum('ji,jil->jl',basis[:,:a.shape[1]],(1-frac)*a[cell]+frac*b[cell])
            out.append((values-deg*out[deg-1])/r if deg else values/r)
        return out
    def modal(self,r,snaps,frac,order):
        values=self.radial(r,snaps,frac,order)
        mask=np.isin(r,self.right[:-1]);idx=np.flatnonzero(mask)
        if len(idx):
            second=self.radial(r[idx],snaps,frac,order,'right')
            for i,vector in enumerate(values):vector[idx]=(vector[idx]+second[i])/2
        return values

class NativeSegment(Segment):
    def __init__(self,original,material,snaps):
        self.__dict__.update(original.__dict__);self.host=np.broadcast_to(0.,original.host.shape)
        self.snaps=snaps;self.material=material
    def acc(self,time,positions,sign):
        wave=super().acc(time,positions,sign);rad=np.linalg.norm(positions,axis=1);unit=positions/rad[:,None];mu=unit[:,2]
        val,grad=self.material.modal(rad,self.snaps,time/self.end,1);basis=legvander(mu,68)
        polys=basis[:,DEGS];slope=DEGS*(basis[:,np.maximum(DEGS-1,0)]-mu[:,None]*polys)/(1-mu[:,None]**2)
        radial=np.sum(grad*polys,axis=1);axial=np.sum(val*slope,axis=1)/rad
        return wave-CONV**2*((radial-mu*axial)[:,None]*unit+axial[:,None]*IDEN[2])
def jet(seg,time,pos,sign):
    wave,knot=OLDJET(seg,time,pos,sign);r=np.linalg.norm(pos);mu=pos[2]/r;nonzero=DEGS[1:]
    vals=seg.material.modal(np.array([r]),seg.snaps,time/seg.end,2)
    a,b,c=(v[0] for v in vals);p=eval_legendre(DEGS,mu)
    d=(nonzero+1)/2*eval_jacobi(nonzero-1,1,1,mu)
    dd=(nonzero+1)*(nonzero+2)/4*eval_jacobi(nonzero-2,2,2,mu)
    native=np.array([b@p,c@p,a[1:]@d,b[1:]@d,a[1:]@dd])
    edge=np.min(abs(seg.material.right-r))
    return np.asarray(wave)+native,min(knot,edge)
def check_native(material):
    rows=[]
    for seg,snaps in zip(load(2,1,'reset'),((586,590),(590,600))):
        for idx in (0,1):
            values=material.modal(seg.rad,snaps,idx,1)
            relative=np.linalg.norm(np.stack(values,axis=-1)-seg.host[idx])/np.linalg.norm(seg.host[idx])
            assert relative<1e-12,relative
            rows.append(dict(snap=snaps[idx],relative=relative))
    table('native-interpolant-check.csv',rows)
def run(factor,step):
    tides.scalar_jet=jet;material=Material();check_native(material)
    label=f'{factor}-{step}';outputs=[[],[],[],[]]
    for arm in ('reset','coupled'):
        original=load(factor,step,arm)
        for model in (('ordinary',) if arm=='reset' else ())+('forward','reverse','static','mean'):
            path='ordinary' if model=='ordinary' else arm+'_'+model
            parts=[]
            for seg,epoch,snaps in zip(original,(-1,0),((586,590),(590,600))):
                reduced=host(seg) if model=='ordinary' else transform(seg,model,epoch) if model in ('static','mean') else seg
                parts.append(NativeSegment(reduced,material,snaps))
            sign='reverse' if model=='reverse' else 'forward'
            states=states_back(parts,sign)
            if model=='ordinary':shared=states
            report=history(parts,path,sign,states,shared)
            for idx in range(3):outputs[idx].extend(report[idx])
            outputs[-1].append(dict(case=path,roundtrip=report[3],min_early=parts[0].minr,max_early=parts[0].maxr,min_late=parts[1].minr,max_late=parts[1].maxr))
            print('native',label,path,report[3],flush=True)
            del parts,reduced,seg
        del original
    for name,rows in zip(('tides','populations','probes','orbits'),outputs):table('native-'+name+'-'+label+'.csv',rows)
if __name__=='__main__':
    for factor,step in ((2,1),(4,1),(4,2)):run(factor,step)
