from pathlib import Path
import os,sys,io,json,hashlib,csv
for var in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','BLIS_NUM_THREADS'):os.environ[var]='1'
import numpy as np
HOME=Path(__file__).resolve().parent
PRIOR=HOME.parent/'mts-pal5-pericentre-finite-replay-20261122'
def sha(path):
    with path.open('rb') as fp:return hashlib.file_digest(fp,'sha256').hexdigest()
assert sha(PRIOR/'seal.json')=='5b4554f8eec619a83a27c544c1d061d5e9c2b8e1f1d6ea38d7feaa7e89b892c9'
manifest=json.loads((PRIOR/'seal.json').read_bytes())
def pin(name):
    path=PRIOR/name;assert sha(path)==manifest[name],name;return path
for name in ('models.py','volume_flight.py','volume_mass.py','record_io.py','chart-10-3.npz','host-reset.npz','host-coupled.npz'):pin(name)
sys.path.insert(0,str(PRIOR))
from record_io import old,previous,read
from models import Stars,CONV,G,GM,SCALE
from volume_mass import FV,fvpin
for name in ('finite_wave.py','finite_io.py','mesh_fd.py'):fvpin(name)
sys.path.insert(0,str(FV))
from finite_wave import Space,Kinetic,kick
from mesh_fd import sample
from scipy.interpolate import RectBivariateSpline
def hold():
    old.guard();assert not any((p/'STOP-REQUESTED').exists() for p in (HOME,PRIOR,FV))
def save(name,data):
    hold();path=HOME/name
    if path.exists():assert sha(path)==hashlib.sha256(data).hexdigest(),name
    else:
        with path.open('xb') as fp:fp.write(data)
def packet(name,**arrays):
    buf=io.BytesIO();np.savez_compressed(buf,**arrays);save(name,buf.getvalue())
def table(name,rows):
    buf=io.StringIO();out=csv.DictWriter(buf,rows[0],lineterminator='\n');out.writeheader();out.writerows(rows);save(name,buf.getvalue().encode())
def schema(rows):return {(r['prep'],r['flow'],r['tail']):r for r in rows}
hold()
