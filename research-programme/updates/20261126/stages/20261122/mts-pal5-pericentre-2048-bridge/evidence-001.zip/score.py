from bridge_io import *

def vec(row,stem):return np.array([float(row[stem+'_'+c]) for c in 'xyz'])
def rel(a,b):
    gap=np.linalg.norm(np.asarray(a)-b);norm=np.linalg.norm(b)
    if norm==0:assert gap==0;return 0.
    return float(gap/norm)
def dated(row):
    return int(row['year']) if 'year' in row else round(1e6*float(row['time']))
def main():
    modes=('L2-h32','L2-h16','L3-h32')
    checks=[];series={};fac={};taylor=[]
    def check(which,field,meta,coarse,fine):
        err=rel(coarse,fine)
        checks.append(dict(test=which,observable=field,key='|'.join(map(str,meta)),fraction=err,passed=err<=.005))
    for setup in ('own','cross'):
        predicted={level:schema(read(HOME/f'predicted-L{level}-{setup}.csv')) for level in (2,3)}
        for key,p in predicted[3].items():
            for label in ('A2','B3','incoming','explicit_source','motion'):
                check('coefficient mesh',label,(setup,*key),vec(predicted[2][key],label),vec(p,label))
            if setup=='own':
                for level in (2,3):
                    old=schema(read(pin(f'wave-tide-curvature-{level}-4.csv')))[key]
                    assert rel(vec(predicted[level][key],'A2'),vec(old,'total'))<1e-9
        def impulse(rows,scheme,level):
            for row in rows:
                key=row['prep'],row['flow'],row['tail'];t=float(row['time'])
                p=predicted[level][key];actual=vec(row,'dv');cubic=CONV*t**3/6*vec(p,'A2');addition=CONV*t**4/24*vec(p,'B3');residual=actual-cubic
                taylor.append(dict(scheme=scheme,setup=setup,prep=key[0],site=key[1],tail=key[2],year=round(1e6*t),wave_velocity_kms=np.linalg.norm(actual),cubic_fraction=rel(cubic,actual),quartic_fraction=rel(cubic+addition,actual),residual_fraction=rel(addition,residual),quartic_to_residual=np.linalg.norm(addition)/np.linalg.norm(residual),residual_alignment=float(addition@residual/(np.linalg.norm(addition)*np.linalg.norm(residual)))))
        if setup=='own':
            for end in (64,1024):
                impulse(read(pin(f'stellar-feedback-2-4-32-{end}-4.csv')),f'archive{end}',2)
        for scheme in modes:
            level=int(scheme[1]);tag=scheme+'-'+setup
            for sub in ([4,8] if scheme=='L2-h32' else [4]):
                rows=read(HOME/f'stellar-feedback-{tag}-{sub}.csv')
                assert len(rows)==40
                if sub==4:impulse(rows,scheme,level)
                for row in rows:
                    if dated(row)<=1024:continue
                    key=(setup,row['prep'],row['flow'],row['tail'],dated(row))
                    series[scheme,sub,'impulse',key]=vec(row,'dv')
            for prep in ('reset','coupled'):
                for site in ('forward','reverse'):
                    for row in read(HOME/f'positions-{tag}-{prep}_{site}.csv'):
                        if dated(row)<=1024:continue
                        key=(setup,prep,site,row['tail'],dated(row))
                        series[scheme,4,'fractional density',key]=float(row['fractional_density'])
                        if row['tail'] in ('outer','inner'):series[scheme,4,'full velocity',key]=vec(row,'dv')
    for (scheme,sub,obs,key),val in list(series.items()):
        if scheme=='L2-h32' and sub==4:
            for test,other in [('field time','L2-h16'),('field mesh','L3-h32')]:
                check(test,obs,key,val,series[other,4,obs,key])
            if obs=='impulse':check('stellar step',obs,key,val,series[scheme,8,obs,key])
    configs=[(m,4,'') for m in modes]+[('L2-h32',8,''),('L2-h32',4,'-direct8'),('L2-h32',4,'-direct12')]
    write=[]
    for scheme,sub,suffix in configs:
        streams=[read(HOME/f'passage-contrast-{scheme}-{setup}-{sub}{suffix}.csv') for setup in ('own','cross')]
        assert all(len(v)==60 for v in streams)
        for a,b in zip(*streams,strict=True):
            assert all(a[v]==b[v] for v in ('prep','tail','time','control'))
            key=a['prep'],a['tail'],dated(a),a['control'];parts={}
            for source in ('native','direct'):
                A=float(a[source+'_contrast']);B=float(b[source+'_contrast'])
                parts[source]=np.array([(A-B)/2,(A+B)/2,A])
            parts['change']=parts['direct']-parts['native']
            for source,(flow,site,total) in parts.items():
                unit=key+(source,)
                if key[3]!='live':assert flow==0
                assert abs(flow+site-total)<=1e-14*max(abs(site),abs(flow),abs(total))
                fac[(scheme,sub,suffix),unit]=(flow,site,total)
                write.append(dict(scheme=scheme,substeps=sub,path=suffix or 'chart',prep=key[0],tail=key[1],year=key[2],control=key[3],source=source,fixed_site_wave=flow,fixed_wave_site=site,total=total))
    for (config,key),val in fac.items():
        if config!=configs[0] or key[3]!='live' or key[2]==1024:continue
        for test,first,second in [('work time',0,1),('work mesh',0,2),('work stellar step',0,3),('chart to trajectory',0,5),('source integration',4,5)]:
            for ix,label in enumerate(('fixed-site flow','fixed-wave site','combined work')):
                check(test,label,key,fac[configs[first],key][ix],fac[configs[second],key][ix])
    for row in read(pin('factorial-finite.csv')):
        if row['tag']!='2-4-32-1024' or row['years']!='1024':continue
        src='change' if row['source']=='difference' else row['source']
        value=fac[configs[0],(row['prep'],row['tail'],1024,row['control'],src)]
        for x,name in zip(value,('flow_at_fixed_site','site_at_fixed_flow','total')):
            check('1024 prefix readout',name,(row['prep'],row['tail'],row['control'],src),x,float(row[name]))
    table('checks.csv',checks);table('quartic-test.csv',taylor);table('factorial.csv',write)
    from collections import defaultdict
    grouped=defaultdict(list)
    for row in checks:grouped[(row['test'],row['observable'])].append(row['fraction'])
    table('gate-summary.csv',[dict(test=k[0],observable=k[1],within=sum(x<=.005 for x in vals),count=len(vals),max_fraction=max(vals)) for k,vals in grouped.items()])
    print('gate rows',len(checks),'Taylors',len(taylor),'work rows',len(write),flush=True)

if __name__=='__main__':main()
