from bridge_io import *
from instantaneous import test
def verify():
    test();hold()
    sites=read(previous('sites.csv'));checks=[]
    for step in (16,32):
        for setup in ('own','cross'):
            for first in range(0,12,3):
                chunk=sites[first:first+3];key=chunk[0]['prep']+'_'+chunk[0]['flow']
                tag=f'L2-h{step}-{setup}-{key}'
                with np.load(HOME/f'end-{tag}.npz') as state,np.load(HOME/f'tide-{tag}.npz') as grid,np.load(pin('volume-2-4.npz')) as init:
                    mesh=Space(init['rf'],init['mf']);ir=np.flatnonzero((mesh.r>5.15)&(mesh.r<5.45));im=np.flatnonzero((mesh.mu>.47)&(mesh.mu<.55));ix=np.ix_(ir,im)
                    assert state['clock']==2048*1e-6 and state['dt']==step*1e-6 and state['date']==float(chunk[0]['date'])
                    for n,m in [('common','common'),('dw','response')]:assert np.array_equal(state[n][ix],grid[m][-1])
                    assert len(grid['time'])==1+2048//step and grid['time'][-1]==state['clock']
                    fresh=mesh.poisson(4*np.pi*G*mesh.dr[:,None]*state['net'])
                    assert np.array_equal(fresh,state['dw'])
                    rows=read(HOME/f'positions-{tag}.csv')
                    for row in rows[-3:]:
                        j=next(i for i,x in enumerate(chunk) if x['tail']==row['tail'])
                        calc=(state['dv'][j]-state['dv'][0])/CONV
                        assert np.array_equal(calc,[float(row['dv_'+c]) for c in 'xyz'])
                    checks.append(dict(record=tag,year=2048,potential_from_saved_current='identical',tide_slice='identical',relative_velocity='identical'))
    table('endpoint-verification.csv',checks)
    for name in ['stream-clocks.csv','stream-two-clock-precision.csv','gate-summary.csv','quartic-test.csv','factorial.csv','checks.csv','RESULTS.md','DERIVATION.md','PROTOCOL.md']:
        assert (HOME/name).stat().st_size>100
    contents={path.name:sha(path) for path in sorted(HOME.iterdir()) if path.is_file() and path.name!='seal.json'}
    raw=(json.dumps(contents,sort_keys=True,indent=2)+'\n').encode();save('seal.json',raw)
    assert json.loads((HOME/'seal.json').read_bytes())=={name:sha(HOME/name) for name in contents}
    print(len(contents),'files',sha(HOME/'seal.json'))
if __name__=='__main__':verify()
