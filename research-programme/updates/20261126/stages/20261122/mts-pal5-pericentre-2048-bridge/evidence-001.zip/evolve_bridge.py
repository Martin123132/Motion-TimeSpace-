from bridge_io import *

def run(level,years,crossed,arm=None):
    hold();order=4;step=years*1e-6;count=2048//years
    assert count*years==2048 and 256%years==0
    bank=np.load(pin(f'volume-{level}-{order}.npz'));S=Space(bank['rf'],bank['mf'])
    ir=np.flatnonzero((S.r>5.15)&(S.r<5.45));im=np.flatnonzero((S.mu>.47)&(S.mu<.55));ix=np.ix_(ir,im)
    spline=lambda grid:RectBivariateSpline(S.r[ir],S.mu[im],grid[ix])
    ev=lambda fn,pts:fn.ev(np.linalg.norm(pts,axis=1),abs(pts[:,2])/np.linalg.norm(pts,axis=1))
    dr=S.dr[:,None];weight=dr*S.dm;kappa=float(bank['kappa']);kin=Kinetic(S,kappa,step);phase=-.5j*step*CONV**2/kappa
    configs=read(previous('sites.csv'));tag=f'L{level}-h{years}-'+('cross' if crossed else 'own')
    for ix0 in range(0,len(configs),3):
        part=configs[ix0:ix0+3];prep,siteflow=part[0]['prep'],part[0]['flow'];key=prep+'_'+siteflow
        if arm and prep!=arm:continue
        star=Stars(part,ix0//3,10,3);date=star.date;p0=star.start
        if crossed:
            with np.load(pin(f'cross-launch-{level}-{order}.npz')) as file:p=file[key]
        else:p=bank[key]
        net=np.zeros_like(p.real);delta=np.zeros_like(p)
        mass0=np.sum(weight*abs(p)**2);rho0=ev(spline(abs(p/S.r[:,None])**2),p0)
        solve=lambda mass:S.poisson(4*np.pi*G*dr*mass)
        cold=(bank['old1']-bank['old0'])/star.duration;dchange=(bank['delta1']-bank['delta0'])/star.duration
        base=bank['old0']+cold*date;change=bank['delta0']+dchange*date
        def grav(common,extra,pb,dp,t):
            pn=pb+dp
            native=star.ordinary(pb,t,'native')+sample(spline(common),pb)
            direct=star.ordinary(pn,t,'direct')+sample(spline(common),pn)+sample(spline(extra),pn)
            def cluster(points):
                off=points-points[0];return -GM*off/(SCALE**2+np.sum(off**2,axis=1))[:,None]**1.5
            cl=cluster(pb);return CONV**2*(native+cl),CONV**2*(direct-native+cluster(pn)-cl)
        common=solve(abs(p)**2);extra=0*common;pb=p0.copy();vb=star.v.copy();dp=0*pb;dv=0*vb
        ab,ad=grav(common,extra,pb,dp,0.)
        own_restart=not crossed and level==2 and years==32
        begin=0;commons=[common[ix].copy()];extras=[extra[ix].copy()]
        checks=[];num=[];readouts=[]
        if own_restart:
            check=read(pin(f'complete-restart-check-2-4-32-1024-{key}.csv'))
            assert len(check)==11 and all(row['identical']=='True' for row in check)
            name=f'restart-2-4-32-1024-{key}-32.npz'
            with np.load(pin(name)) as file:
                begin=32;assert file['clock']==begin*step and file['dt']==step and file['date']==date
                p,delta,net,pb,vb,dp,dv,ab,ad=(file[n] for n in ('p','delta','net','pb','vb','dp','dv','ab','ad'))
            with np.load(pin('field-'+name)) as file:common,extra=file['common'],file['dw']
            with np.load(pin(f'tide-2-4-32-1024-{key}.npz')) as file:
                commons=list(file['common']);extras=list(file['response'])
                assert np.array_equal(commons[-1],common[ix]) and np.array_equal(extras[-1],extra[ix])
            one,two=grav(common,extra,pb,dp,begin*step)
            assert np.array_equal(one,ab) and np.array_equal(two,ad)
        for tick in range(begin+1,count+1):
            hold();lo=(tick-1)*step;t=tick*step
            vb+=step*ab/2;dv+=step*ad/2;pb+=step*vb;dp+=step*dv
            p,delta=kick(p,delta,base+cold*lo+common,change+dchange*lo+extra,phase)
            p,delta=kin.radial(p,delta,net);p,delta=kin.angular(p,delta,net);p,delta=kin.radial(p,delta,net)
            common=solve(abs(p)**2);extra=solve(net)
            commons.append(common[ix].copy());extras.append(extra[ix].copy())
            p,delta=kick(p,delta,base+cold*t+common,change+dchange*t+extra,phase)
            ab,ad=grav(common,extra,pb,dp,t);vb+=step*ab/2;dv+=step*ad/2
            if tick*years<1024 or tick*years%256:continue
            direct=(2*(p.conj()*delta).real+abs(delta)**2)
            resid=np.linalg.norm((direct-net)[ix])/np.linalg.norm(net[ix])
            occ=abs(np.sum(weight*abs(p)**2)/mass0-1)
            balance=abs(np.sum(weight*net))/np.sum(weight*abs(net))
            assert max(resid,occ,balance)<1e-8
            num.append(dict(year=tick*years,occupation=occ,net_mass_ratio=balance,current_residual=resid))
            pts=p0+(pb[0]-p0[0]);offset=dp[0];native=spline(abs(p/S.r[:,None])**2)
            frame=-np.sum(sample(native,pts+offset/2)*offset,axis=1)
            different=ev(spline(net/S.r[:,None]**2),pts+offset);curve=2*(different+frame)/t**2/rho0
            for j,row in enumerate(part):
                vec=(dv[j]-dv[0])/CONV
                readouts.append(dict(prep=prep,site=siteflow,tail=row['tail'],year=tick*years,apparent_curvature=curve[j],fractional_density=(different[j]+frame[j])/rho0[j],**{'dv_'+c:v for c,v in zip('xyz',vec)}))
        assert len(commons)==len(extras)==count+1
        if years==32 and level==2 and crossed:
            with np.load(pin(f'tide-2-4-32-1024-cross-{key}.npz')) as f:
                assert np.array_equal(f['response'],extras[:33]) and np.array_equal(f['common'],commons[:33])
        packet(f'tide-{tag}-{key}.npz',r=S.r[ir],mu=S.mu[im],time=np.arange(count+1)*step,common=np.asarray(commons),response=np.asarray(extras))
        if (level,years) in ((2,16),(2,32)):
            packet(f'end-{tag}-{key}.npz',clock=t,date=date,dt=step,p=p,delta=delta,net=net,pb=pb,vb=vb,dp=dp,dv=dv,ab=ab,ad=ad,common=common,dw=extra)
        table(f'budget-{tag}-{key}.csv',num);table(f'positions-{tag}-{key}.csv',readouts)
        print(tag,key,'completed',begin*years,'to',count*years,flush=True)
    bank.close()
if __name__=='__main__':run(int(sys.argv[1]),int(sys.argv[2]),{'own':False,'cross':True}[sys.argv[3]],*sys.argv[4:])
