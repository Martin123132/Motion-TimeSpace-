from bridge_io import *
from scipy.special import ndtri,ndtr

def main():
    field=read(previous('coverage.csv'))
    assert len(field)==4
    out=[]
    for row in field:
        for reference,duration in [('leading-tip drift',1260),('trailing-tip drift',1940),('adopted disruption simulation',5000),('model-inferred duration',6200)]:
            out.append(dict(preparation=row['prep'],site=row['flow'],clock=reference,reference_Myr=duration,paired_field_Myr=row['total_Myr'],flight_Myr=row['star_flight_Myr'],field_percent=100*float(row['total_Myr'])/duration,flight_percent=100*float(row['star_flight_Myr'])/duration))
    table('stream-clocks.csv',out)
    previous('stream_readout.py')
    cat=HOME.parent/'mts-pal5-measured-rrl-20261122'
    assert sha(cat/'seal.json')=='e94eaf7948ea6a477eecd1124486c2df30a70144d092ebd7caf61c4176b35a55'
    path=cat/'kuzma-table4.txt';assert sha(path)==json.loads((cat/'seal.json').read_bytes())[path.name]
    err=np.array([float(line.split()[7]) for line in path.read_text().splitlines() if line.strip() and not line.startswith('#')])
    left,right=np.where(~np.eye(len(err),dtype=bool));assert len(left)==11772
    release=read(old.pin(old.STREAM,'physical-launch-8-2.csv'))
    shifted=read(old.pin(old.STREAM,'loose-witness.csv'))
    check=read(previous('measurement.csv'));out=[]
    for arm in ('reset','coupled'):
        fixed=next(row for row in release if (row['arm'],row['speed'],row['cluster_force'],row['alternative'])==(arm,'escape','True','passage'))
        shift=next(row for row in shifted if (row['arm'],row['grid'])==(arm,'8-2'))
        vals=[]
        for mode,one,two,lag in [('passage',fixed['inner_kms'],fixed['outer_kms'],0),('alternate',shift['delta_inner_kms'],shift['delta_outer_kms'],shift['lag_Myr'])]:
            mahal=np.hypot(float(one)/err[left],float(two)/err[right])
            vals.append(mahal)
            acc=100*ndtr(mahal/2)
            comp=next(row for row in check if row['prep']==arm and row['test']==('pericentre' if mode=='passage' else 'alternative'))
            assert abs(float(comp['median_distinct_pct'])-np.median(acc))<1e-9
            out.append(dict(preparation=arm,case=mode,shared_lag_Myr=lag,assignments=len(mahal),median_pair_accuracy_pct=float(np.median(acc)),best_pair_accuracy_pct=float(acc.max()),median_precision_improvement_for_95pct=float(np.median(2*ndtri(.95)/mahal))))
        bound=np.minimum(*vals)
        out.append(dict(preparation=arm,case='both pairs admissible: upper bound on guaranteed accuracy',shared_lag_Myr='not inferred',assignments=len(bound),median_pair_accuracy_pct=float(np.median(100*ndtr(bound/2))),best_pair_accuracy_pct=float(100*ndtr(bound.max()/2)),median_precision_improvement_for_95pct=float(np.median(2*ndtri(.95)/bound))))
    table('stream-two-clock-precision.csv',out)

if __name__=='__main__':main()
