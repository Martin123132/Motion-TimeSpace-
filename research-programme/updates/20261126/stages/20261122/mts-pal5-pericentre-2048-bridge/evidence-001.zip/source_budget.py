from bridge_io import *
from models import cylindrical
def main():
    rows=read(previous('sites.csv'));report=[]
    t=.000512
    for q in (8,12):
        with np.load(pin(f'trajectory-source-{q}.npz')) as old_bank,np.load(HOME/f'trajectory-source-{q}.npz') as new:
            original=old_bank['forces'];points=new['forces']
            assert np.allclose(old_bank['time'],[0,t,2*t],rtol=0,atol=1e-16) and np.allclose(new['time'],[0,2*t,4*t],rtol=0,atol=1e-16)
            predicted=.375*points[:,0]+.75*points[:,1]-.125*points[:,2]
            for start in range(0,12,3):
                index=start//3;part=rows[start:start+3];star=Stars(part,index,10,3)
                for epoch,a,b in [('start',points[index,0],original[index,0]),('interior',predicted[index],original[index,1]),('join',points[index,1],original[index,2])]:
                    for j in (1,2):
                        av=a[j]-a[0];bv=b[j]-b[0]
                        report.append(dict(q=q,prep=part[0]['prep'],site=part[0]['flow'],tail=part[j]['tail'],epoch=epoch,cylindrical_force_difference=np.linalg.norm(av-bv),fraction_of_relative_cylindrical_force=np.linalg.norm(av-bv)/np.linalg.norm(bv)))
    table('source-independent-epoch.csv',report)
if __name__=='__main__':main()
