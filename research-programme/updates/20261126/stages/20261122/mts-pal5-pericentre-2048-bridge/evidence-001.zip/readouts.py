from bridge_io import *
from types import ModuleType

def adapt(name,replacements):
    path=pin(name+'.py')
    body=path.read_text()
    for before,after in replacements:
        assert body.count(before)==1,(name,before)
        body=body.replace(before,after)
    scope=ModuleType('bridge_'+name)
    scope.__file__=str(path)
    exec(compile(body,str(path), 'exec'),scope.__dict__)
    scope.HERE=HOME
    scope.table=table
    scope.packet=packet
    return scope

epochs='(1024,1280,1536,1792,2048)'
def run(kind,*args):
    if kind=='anchors':
        driver=adapt('trajectory_source',[('cut=np.linspace(0,.001024,3)','cut=np.linspace(0,.002048,3)')])
        for order in args:
            driver.run(int(order))
            print('computed along-path anchors, order',order,flush=True)
        return
    if kind=='impulse':
        driver=adapt('stellar_feedback',[('if tick not in (count//4,count//2,count):continue',f'if round(t*1e6,7) not in {epochs}:continue')])
        driver.orbit(args[0],int(args[1]))
    elif kind=='work':
        driver=adapt('passage_contrast',[('if i not in [(len(ts)-1)*sub//4,(len(ts)-1)*sub//2,(len(ts)-1)*sub]:continue',f'if round(t*1e6,7) not in {epochs}:continue'),('assert np.max(abs(offset))<1e-8','track_offset.append(float(np.max(abs(offset))));assert track_offset[-1]<1e-8')])
        driver.track_offset=[]
        driver.run(args[0],int(args[1]),*(int(s) for s in args[2:]))
        if driver.track_offset:table('displacement-'+'-'.join(args)+'.csv',[dict(max_kpc=max(driver.track_offset),derivative_stencil_kpc=.001)])
    print(kind,args,'finished',flush=True)

if __name__=='__main__':
    for block in ' '.join(sys.argv[1:]).split(';'):
        run(*block.strip().split())
