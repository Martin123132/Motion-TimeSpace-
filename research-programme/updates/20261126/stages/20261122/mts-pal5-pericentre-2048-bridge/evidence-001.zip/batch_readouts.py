from readouts import run
from bridge_io import hold
import sys
from stream_clocks import main as clocks

if __name__=='__main__':
    group=sys.argv[1]
    if group=='alongpath':
        clocks()
        run('anchors','8','12')
        for setup in ('own','cross'):
            tag='L2-h32-'+setup
            for order in ('8','12'):hold();run('work',tag,'4',order)
    if group in ('L2','L3'):
        for scheme in (['L2-h16','L2-h32'] if group=='L2' else ['L3-h32']):
            for setup in ('own','cross'):
                tag=scheme+'-'+setup
                for method in ('impulse','work'):
                    for sub in (['4','8'] if scheme=='L2-h32' else ['4']):
                        hold();run(method,tag,sub)
