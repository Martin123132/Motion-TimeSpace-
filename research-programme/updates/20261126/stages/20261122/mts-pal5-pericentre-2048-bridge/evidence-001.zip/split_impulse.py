from bridge_io import *
from scipy.integrate import simpson

def run(scheme,setup):
    level=int(scheme[1]);tag=scheme+'-'+setup
    pred=schema(read(HOME/f'predicted-L{level}-{setup}.csv'))
    measurements=read(HOME/f'stellar-feedback-{tag}-4.csv');sites=read(previous('sites.csv'));results=[]
    for first in range(0,len(sites),3):
        part=sites[first:first+3];arm,site=part[0]['prep'],part[0]['flow']
        star=Stars(part,first//3,10,3)
        with np.load(HOME/f'tide-{tag}-{arm}_{site}.npz') as bank:
            times=bank['time'];step=times[1];bank_splines=[RectBivariateSpline(bank['r'],bank['mu'],grid) for grid in bank['response']]
        dense=np.arange(4*(len(times)-1)+1)*step/4;fields=[]
        for time in dense:
            centre=min(max(1,int(round(time/step))),len(times)-2);fraction=time/step-centre
            pts=np.vstack((star.start,star.start+time*star.v));weights=(fraction*(fraction-1)/2,1-fraction**2,fraction*(fraction+1)/2)
            force=sum(w*sample(bank_splines[j],pts) for j,w in zip(range(centre-1,centre+2),weights) if w)
            split=force.reshape(2,3,3);fields.append(split-split[:,0:1])
        values=np.array(fields)
        for row in measurements:
            if (row['prep'],row['flow'])!=(arm,site):continue
            t=float(row['time']);stop=int(round(4*t/step))+1
            j=next(i for i,p in enumerate(part) if p['tail']==row['tail'])
            fixed,moved=CONV*simpson(values[:stop,:,j,:],x=dense[:stop],axis=0)
            mat=pred[arm,site,row['tail']]
            def vec(name):return np.array([float(mat[name+'_'+c]) for c in 'xyz'])
            measured=np.array([float(row['dv_'+c]) for c in 'xyz']);scale=np.linalg.norm(measured)
            base=CONV*t**3*vec('A2')/6
            intrinsic=CONV*t**4*(vec('incoming')+vec('explicit_source'))/24;transport=CONV*t**4*vec('motion')/24
            fixed_rem=fixed-base-intrinsic;motion_rem=(moved-fixed)-transport;orbit_rem=measured-moved
            diff=measured-base-intrinsic-transport;assert np.linalg.norm(fixed_rem+motion_rem+orbit_rem-diff)<1e-12*scale
            denominator=diff@diff
            results.append(dict(scheme=scheme,setup=setup,prep=arm,site=site,tail=row['tail'],year=round(t*1e6),relative_fixed_field_remainder=np.linalg.norm(fixed_rem)/scale,relative_transport_remainder=np.linalg.norm(motion_rem)/scale,relative_orbit_and_quadrature=np.linalg.norm(orbit_rem)/scale,fixed_projection=(diff@fixed_rem)/denominator,transport_projection=(diff@motion_rem)/denominator,other_projection=(diff@orbit_rem)/denominator))
    return results

if __name__=='__main__':
    data=[]
    for scheme in ('L2-h32','L2-h16','L3-h32'):
        for setup in ('own','cross'):data.extend(run(scheme,setup))
    table('quartic-error-origin.csv',data)
    print('split',len(data),'finite impulse errors')
