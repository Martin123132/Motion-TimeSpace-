from bridge_io import *
def coefficients(S,kappa,state,V,D,rate):
    dr=S.dr[:,None];dm=S.dm;kr=1/np.diff(S.r)[:,None];ka=((1-S.mf[1:-1]**2)/np.diff(S.mu))[None,:]/S.r[:,None]**2
    def divergence(fr,fa):
        out=np.zeros(state.shape,dtype=np.result_type(fr,fa))
        out[:-1]-=fr/dr[:-1];out[1:]+=fr/dr[1:];out[:,:-1]-=fa/dm[:-1];out[:,1:]+=fa/dm[1:]
        return out
    def kinetic(u):
        hu=.5*kappa*divergence(kr*(u[1:]-u[:-1]),ka*(u[:,1:]-u[:,:-1]))
        hu[0]+=kappa*u[0]/S.dr[0]**2;hu[-1]+=kappa*u[-1]/S.dr[-1]**2
        return hu
    d=CONV**2*(D-D[len(D)//2,0])/kappa
    dd=CONV**2*(rate-rate[len(D)//2,0])/kappa
    v=CONV**2*(V-V[len(V)//2,0])/kappa
    b=-1j*(kinetic(state)+v*state)
    dR=d[1:]-d[:-1];dM=d[:,1:]-d[:,:-1]
    com=np.zeros_like(state)
    com[:-1]-=.5*kappa*kr*dR*state[1:]/dr[:-1];com[1:]+=.5*kappa*kr*dR*state[:-1]/dr[1:]
    com[:,:-1]-=.5*kappa*ka*dM*state[:,1:]/dm[:-1];com[:,1:]+=.5*kappa*ka*dM*state[:,:-1]/dm[1:]
    def edges(l,r,conduct):
        u,w=state[l],state[r];z=u.conj()*w
        db=d[l]-d[r];pairprime=b[l].conj()*w+u.conj()*b[r]
        fixed=-(com[l].conj()*w+u.conj()*com[r])+2j*db*pairprime-db**2*z
        ratepart=1j*(dd[l]-dd[r])*z
        return [kappa*conduct*x for x in (db*z.real,fixed.imag,ratepart.imag)]
    a=edges(np.s_[:-1,:],np.s_[1:,:],kr);bcols=edges(np.s_[:,:-1],np.s_[:,1:],ka)
    return [divergence(fr,fa) for fr,fa in zip(a,bcols)]
def independent(S,kappa,p,V,D,rate):
    dr=S.dr[:,None];dm=S.dm;kr=1/np.diff(S.r)[:,None];ka=(1-S.mf[1:-1]**2)/np.diff(S.mu)/S.r[:,None]**2
    def H(u,pot):
        L=np.zeros_like(u);r=(u[1:]-u[:-1])*kr;m=(u[:,1:]-u[:,:-1])*ka
        L[:-1]+=r/dr[:-1];L[1:]-=r/dr[1:];L[:,:-1]+=m/dm[:-1];L[:,1:]-=m/dm[1:]
        L[0]-=2*u[0]/S.dr[0]**2;L[-1]-=2*u[-1]/S.dr[-1]**2
        return -.5*kappa*L+CONV**2*pot*u/kappa
    def third(W,dot):
        b=-1j*H(p,W);c=-1j*H(b,W)-1j*CONV**2*dot*p/kappa
        def f(l,r,cond):return kappa*cond*(c[l].conj()*p[r]+2*b[l].conj()*b[r]+p[l].conj()*c[r]).imag
        rr=f(np.s_[:-1,:],np.s_[1:,:],kr);mm=f(np.s_[:,:-1],np.s_[:,1:],ka)
        out=np.zeros_like(p.real);out[:-1]-=rr/dr[:-1];out[1:]+=rr/dr[1:];out[:,:-1]-=mm/dm[:-1];out[:,1:]+=mm/dm[1:]
        return out
    return third(V+D,rate)-third(V,0.)
def test():
    from types import SimpleNamespace
    s=SimpleNamespace(r=np.array([.6,1.4,2.9,4.4]),dr=np.array([1.2,.4,2.6,.4]),dm=np.array([.25,.25,.5]),mu=np.array([.125,.375,.75]),mf=np.array([0,.25,.5,1.]))
    rng=np.random.default_rng(227);normal=lambda:rng.normal(size=(4,3))
    p=normal()+1j*normal();V,D,dt=[normal()/CONV**2 for i in range(3)]
    a,b,c=coefficients(s,1.7,p,V,D,dt);twin=coefficients(s,1.7,p.conj(),V,D,dt)
    assert np.allclose(twin[0],a) and np.allclose(twin[1],-b) and np.allclose(twin[2],c)
    assert np.allclose(b+c,independent(s,1.7,p,V,D,dt),rtol=2e-10,atol=1e-10)
    assert all(np.max(abs(w))==0 for w in coefficients(s,1.7,p,V,0*D+1,0*dt+2.))
    assert np.allclose(b,coefficients(s,1.7,p,V+1e5,D,dt)[1],rtol=1e-10,atol=1e-12)
def process(level,cross):
    order=4;records=read(previous('sites.csv'));out=[];tag=f'L{level}-'+('cross' if cross else 'own')
    with np.load(pin(f'volume-{level}-{order}.npz')) as bank:
        S=Space(bank['rf'],bank['mf']);kappa=float(bank['kappa']);dr=S.dr[:,None]
        ir=np.flatnonzero((S.r>5.15)&(S.r<5.45));im=np.flatnonzero((S.mu>.47)&(S.mu<.55))
        def grav(curve):
            pot=S.poisson(4*np.pi*G*dr*curve)
            return RectBivariateSpline(S.r[ir],S.mu[im],pot[np.ix_(ir,im)])
        for i in range(0,len(records),3):
            part=records[i:i+3];arm,site=part[0]['prep'],part[0]['flow'];key=arm+'_'+site
            if cross:
                with np.load(pin(f'cross-launch-{level}-{order}.npz')) as f:p=f[key]
            else:p=bank[key]
            star=Stars(part,i//3,10,3);pos=star.start;velocity=star.v;frac=star.date/star.duration
            V=(1-frac)*bank['old0']+frac*bank['old1']+S.poisson(4*np.pi*G*dr*abs(p)**2)
            Delta=(1-frac)*bank['delta0']+frac*bank['delta1'];rate=(bank['delta1']-bank['delta0'])/star.duration
            n2,n3,j3=coefficients(S,kappa,p,V,Delta,rate)
            for c in (n2,n3,j3):assert abs(np.sum(c*dr*S.dm))/np.sum(abs(c)*dr*S.dm)<1e-10
            f2=grav(n2);step=1e-5
            def diff(vec):return vec-vec[:1]
            def move(h):return diff((sample(f2,pos+h*velocity)-sample(f2,pos-h*velocity))/(2*h))
            val=diff(sample(f2,pos));state=diff(sample(grav(n3),pos));host=diff(sample(grav(j3),pos));motion=3*move(step)
            assert np.linalg.norm(motion-3*move(step/2))<1e-4*np.linalg.norm(motion)
            total=state+host+motion
            for j in (1,2):
                row=dict(prep=arm,flow=site,tail=part[j]['tail'])
                for label,v in [('A2',val),('incoming',state),('explicit_source',host),('motion',motion),('B3',total)]:
                    row.update({label+'_'+c:w for c,w in zip('xyz',v[j])})
                out.append(row)
    table('predicted-'+tag+'.csv',out)
if __name__=='__main__':
    test()
    for level in map(int,sys.argv[1:]):
        for cross in (False,True):process(level,cross)
