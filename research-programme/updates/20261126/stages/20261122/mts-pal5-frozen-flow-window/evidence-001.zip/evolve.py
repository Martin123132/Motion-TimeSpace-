import os
import sys
for key in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','BLIS_NUM_THREADS'):
    os.environ[key]='1'
sys.dont_write_bytecode=True
import hashlib
import io
import json
from pathlib import Path
from types import SimpleNamespace
import numpy as np

HOME=Path(__file__).resolve().parent
ROOT=HOME.parent
SOURCE=ROOT/'mts-fire-directional-lapse-20261121'
PRE=ROOT/'mts-fire-density-forecast-20261121'
def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def put(name,data):
    path=HOME/name
    if path.exists():
        assert path.read_bytes()==data,name
    else:
        with path.open('xb') as handle:
            handle.write(data)

def writejson(name,data):
    put(name,(json.dumps(data,sort_keys=True,indent=2,allow_nan=False)+'\n').encode())

def build(factor):
    assert factor in (1,2,4,8)
    assert digest(PRE/'freeze.json')=='56e6fe56045146e609bdb80a970949886d0bcf0d49312d8332fe72b068d17776'
    assert digest(SOURCE/'seal.json')=='b3de88dae7ca047c80bba71d04957085dc3f6c805a5d1a89d0b747ad1587f16c'
    sys.path.insert(0,str(SOURCE))
    from directional import Radial,green,guard
    from matched_io import Launch,Evolution,advance
    guard()
    lab=Launch(64);run=lab.run;obj=lab.obj;bg=obj.bg
    mesh=Radial(lab,16)
    duration=run.ages[600]-run.ages[590]
    native,dt0=run.interval(590,600)
    count=native*factor;dt=dt0/factor
    radius=np.arange(12.,29.01,.25/factor)
    assert radius[-1]<mesh.inf*bg.length and native==18
    norm=np.sqrt(2*mesh.sell+1)*bg.vel**2
    host=[]
    for snap in (590,600):
        value,grad=mesh.values(mesh.potential_nodes(lab.mesh.ordinary+run.fields[snap]),radius/bg.length)
        host.append(np.stack((value*norm,grad*norm/bg.length),axis=-1))
    packed=dict(radius=radius,duration=duration,host=np.array(host))
    summary=dict(count=count,age_Myr=duration,preparation_span_Myr=run.ages[590]-run.ages[572],
                 axis_end_kpc=mesh.inf*bg.length,method='same 64-step-source states; actual midpoint evolution',
                 freeze=digest(PRE/'freeze.json'),protocol=digest(HOME/'PROTOCOL.md'),launch_sources={},arms={})
    for arm in ('reset','coupled'):
        filename=f'flight-16-{arm}-represented.npz'
        path=SOURCE/filename
        assert digest(path)==json.loads((SOURCE/'seal.json').read_bytes())[filename]
        with np.load(path) as short:
            assert np.array_equal(short['wave'][0],lab.initial[arm])
            summary['short_forward_Myr']=(len(short['wave'])-1)*float(short['dt_Myr'])
        summary['launch_sources'][filename]=digest(path)
        for sign in ('forward','reverse'):
            state=lab.initial[arm].copy()
            if sign=='reverse': state=state.conj()
            initial=state.copy();mom=obj.moment(state)
            solver=Evolution(obj,dt,state)
            bank=[];time=[];normerr=0.
            for tick in range(count+1):
                if not tick%2 or tick==count:
                    guard()
                    ext=run.fields[590]+tick/count*(run.fields[600]-run.fields[590])
                    proxy=SimpleNamespace(obj=obj,run=SimpleNamespace(fields={590:ext}),initial={'zero':state*0,'wave':state})
                    potential,derivative,_=green(proxy,mesh,radius/bg.length)
                    value=potential*norm[None,:,None]
                    grad=derivative*(norm/bg.length)[None,:,None]
                    value[:,:,1]/=obj.unit_myr;grad[:,:,1]/=obj.unit_myr
                    bank.append(np.stack((value,grad),axis=-2))
                    time.append(tick/count*duration)
                if tick<count:
                    state,mom,_,_=advance(obj,solver,state,mom,run.external(590,600,tick,count),dt)
                    normerr=max(normerr,abs(np.vdot(state,state).real/obj.number-1))
            assert normerr<1e-9
            label=arm+'_'+sign
            packed[label]=np.array(bank)
            packed['time']=np.array(time)
            summary['arms'][label]={'occupation_drift':normerr}
            if sign=='forward':
                ref=run.reference[600] if arm=='reset' else lab.raw[600]
                err=np.linalg.norm(state-ref)/np.sqrt(obj.number)
                summary['arms'][label]['archived_endpoint_wave_relative']=err
                if factor==1: assert err<1e-9,err
            print('finished',count,label,flush=True)
        start=packed[arm+'_forward'][0];other=packed[arm+'_reverse'][0]
        for index,parity in [(0,1),(1,-1)]:
            error=np.linalg.norm(start[...,index]-parity*other[...,index])/np.linalg.norm(start[...,index])
            assert error<1e-9
            summary['arms'][arm+'_forward']['launch_parity_'+str(index)]=error
    buf=io.BytesIO();np.savez_compressed(buf,**packed)
    put(f'potential-{count}.npz',buf.getvalue());writejson(f'evolution-{count}.json',summary)
if __name__=='__main__':
    build(int(sys.argv[1]))
