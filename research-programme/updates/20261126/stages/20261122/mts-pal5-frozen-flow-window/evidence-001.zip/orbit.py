import csv
import io
import sys
from evolve import HOME, put, writejson, np
from numpy.polynomial.legendre import legvander
from scipy.interpolate import CubicHermiteSpline

CONV=1/977.7922216807892
ROT=np.array([[-.0548755604162154,-.8734370902348850,-.4838350155487132],
              [.4941094278755837,-.4448296299600112,.7469822444972190],
              [-.8676661490190047,-.1980763734312015,.4559837761750669]])
SUN=np.array([-8.31,0,.02]); VSUN=np.array([11.1,251.3,7.3])
TRACK=np.genfromtxt(HOME/'track.csv',delimiter=',',names=True)
RA0=229.018
def icrs(ra,dec):
    lon,lat=np.radians(ra),np.radians(dec)
    return np.column_stack((np.cos(lon)*np.cos(lat),np.sin(lon)*np.cos(lat),np.sin(lat)))

def anchors(distance):
    ra=np.r_[RA0,TRACK['ra']];dec=np.r_[-.124,TRACK['dec']]
    unit=icrs(ra,dec)
    east=icrs(ra+90,dec*0)
    north=np.cross(unit,east)
    xyz=SUN+distance*(unit@ROT.T)
    vr=-58.7+1.20*(ra-RA0)
    vel=VSUN+(vr[:,None]*unit+4.74047*distance*(-2.296*east-2.257*north))@ROT.T
    return xyz,vel*CONV

def observed(xyz,vel):
    hel=(xyz-SUN)@ROT
    unit=hel/np.linalg.norm(hel,axis=1)[:,None]
    return np.column_stack((np.degrees(np.arctan2(unit[:,1],unit[:,0]))%360,
              np.degrees(np.arcsin(unit[:,2])),np.sum(((vel/CONV-VSUN)@ROT)*unit,axis=1)))

class Field:
    def __init__(self,src,arm):
        self.times=src['time'];self.rad=src['radius'];self.host=src['host']
        self.end=self.times[-1]
        self.fun={}
        for sign in ('forward','reverse'):
            raw=src[arm+'_'+sign];self.fun[sign]=CubicHermiteSpline(self.times,raw[...,0],raw[...,1],axis=0,extrapolate=False)
        self.deg=np.arange(0,69,2)
    def force(self,time,xyz,sign):
        time=np.clip(time,0,self.end)
        if sign=='mean':
            table=(self.fun['forward'](time)+self.fun['reverse'](time))/2
        else: table=self.fun[sign](time)
        table=table+(1-time/self.end)*self.host[0]+(time/self.end)*self.host[1]
        radius=np.linalg.norm(xyz,axis=1);unit=xyz/radius[:,None];mu=unit[:,2]
        assert np.all((radius>self.rad[0])&(radius<self.rad[-1]))
        step=self.rad[1]-self.rad[0]
        idx=np.searchsorted(self.rad,radius)-1
        frac=((radius-self.rad[idx])/step)[:,None]
        va,da=table[idx,:,0],table[idx,:,1];vb,db=table[idx+1,:,0],table[idx+1,:,1]
        term=vb-va
        first=step*da;second=3*term-step*(2*da+db);third=-2*term+step*(da+db)
        pot=va+frac*(first+frac*(second+frac*third))
        slope=(first+frac*(2*second+3*frac*third))/step
        polys=legvander(mu,68)
        angular=self.deg*(polys[:,np.maximum(0,self.deg-1)]-mu[:,None]*polys[:,::2])/(1-mu[:,None]**2)
        axial=(angular*pot).sum(axis=1)/radius
        radial=(polys[:,::2]*slope).sum(axis=1)
        return -CONV**2*((radial-mu*axial)[:,None]*unit+axial[:,None]*[0,0,1])
    def move(self,start,stop,xyz,vel,sign,count):
        times=np.linspace(start,stop,max(1,int(np.ceil(abs(stop-start)/self.end*count)))+1)
        xyz=xyz.copy();vel=vel.copy()
        acc=self.force(times[0],xyz,sign)
        for earlier,later in zip(times[:-1],times[1:]):
            step=later-earlier
            vel+=.5*step*acc;xyz+=step*vel
            acc=self.force(later,xyz,sign);vel+=.5*step*acc
        return xyz,vel

def writecsv(name,rows):
    buf=io.StringIO()
    writer=csv.DictWriter(buf,fieldnames=list(rows[0]),lineterminator='\n')
    writer.writeheader();writer.writerows(rows);put(name,buf.getvalue().encode())

def test(count,nstep):
    slopes=np.zeros(len(TRACK));ra=TRACK['ra']
    for side,degree in ((ra<RA0,1),(ra>=RA0,2)):
        coeff=np.polynomial.Polynomial.fit(ra[side],TRACK['dec'][side],degree,w=1/TRACK['sigma_dec'][side])
        slopes[side]=coeff.deriv()(ra[side])
    results=[];escapes=[];summary=[]
    with np.load(HOME/f'potential-{count}.npz') as src:
        for arm in ('reset','coupled'):
            field=Field(src,arm);end=field.end
            for dist in (20.9,22.05,23.2):
                xyz,vel=anchors(dist)
                init=field.move(end,0,xyz,vel,'mean',nstep)
                back=field.move(0,end,*init,'mean',nstep)
                assert np.max(abs(back[0]-xyz))<1e-9 and np.max(abs(back[1]-vel))<1e-9
                maps=[];sky=[]
                for sign in ('forward','reverse'):
                    coord,speed=field.move(0,end,*init,sign,nstep)
                    coord=coord-coord[:1]+xyz[:1];speed=speed-speed[:1]+vel[:1]
                    maps.append((coord,speed))
                    sky.append(observed(coord,speed)[1:])
                dra,ddec,dvr=(sky[0]-sky[1]).T
                cross=ddec-slopes*dra
                dvfixed=dvr-1.20*dra
                gradient=(ra-ra.mean())@dvfixed/np.sum((ra-ra.mean())**2)
                ratios=cross/TRACK['sigma_dec']
                for idx in range(len(ra)):
                    results.append(dict(arm=arm,dist=dist,ra_deg=ra[idx],sigma_dec_deg=TRACK['sigma_dec'][idx],
                        delta_RA_deg=dra[idx],delta_dec_fixed_RA_deg=cross[idx],ratio=ratios[idx],
                        delta_vlos_fixed_RA_kms=dvfixed[idx],delta_position_pc=1000*np.linalg.norm(maps[0][0][idx+1]-maps[1][0][idx+1])))
                summary.append(dict(arm=arm,dist=dist,max_abs_track_sigma=max(abs(ratios)),diag_track_distance=np.linalg.norm(ratios),
                    gradient_delta_kms_deg=gradient,gradient_sigma=abs(gradient)/.15,max_abs_vlos_kms=max(abs(dvfixed)),
                    max_displacement_pc=max(row['delta_position_pc'] for row in results[-len(ra):])))
                for release in (end/2-10,end/2,end/2+10):
                    for sign in ('forward','reverse'):
                        initial=(init[0][:1],init[1][:1])
                        cluster,clvel=field.move(0,release,*initial,sign,nstep)
                        er=cluster[0]*[1,1,0];er/=np.linalg.norm(er)
                        ephi=np.cross([0,0,1],er)
                        if ephi@clvel[0]<0:ephi=-ephi
                        coeff=np.array([0,-1,1])[:,None]
                        xx,vv=field.move(release,end,cluster+coeff*.060*er,clvel+coeff*CONV*ephi,sign,nstep)
                        obs=observed(xx-xx[:1]+xyz[:1],vv-vv[:1]+vel[:1])
                        for tail,entry in zip(('inner','outer'),obs[1:]-obs[0]):
                            escapes.append(dict(arm=arm,dist=dist,release_Myr=release,flow=sign,tail=tail,
                                      relative_RA_deg=entry[0],relative_dec_deg=entry[1],relative_vlos_kms=entry[2]))
    label=f'{count}-{nstep}'
    writecsv(f'track-{label}.csv',results);writecsv(f'escapes-{label}.csv',escapes);writecsv(f'summary-{label}.csv',summary)
    print(label,summary[1],summary[4],flush=True)

if __name__=='__main__':
    test(int(sys.argv[1]),int(sys.argv[2]))
