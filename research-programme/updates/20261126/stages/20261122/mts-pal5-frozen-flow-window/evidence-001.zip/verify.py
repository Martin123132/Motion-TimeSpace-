import csv
import json
from evolve import HOME, ROOT, digest, np, writejson
from orbit import writecsv

def readrows(prefix,label):
    with (HOME/f'{prefix}-{label}.csv').open(newline='') as handle:
        return list(csv.DictReader(handle))

def signal(rows,name):
    return np.array([float(row[name]) for row in rows])

def checked_run():
    cutoff=.005
    early=ROOT/'mts-pre572-wave-preparation-20261120';past=ROOT/'mts-fire-joint-baryon-history-20261120'
    ledger={}
    def input_file(folder,filename,master):
        assert digest(folder/'seal.json')==master
        path=folder/filename
        ledger[str(path.relative_to(ROOT))]=digest(path)
        manifest=json.loads((folder/'seal.json').read_bytes())
        assert ledger[str(path.relative_to(ROOT))]==manifest.get('files',manifest)[filename]
        return path
    times=np.loadtxt(input_file(past,'snapshot_times.txt','19c78eaa158a766bd409c0a64504788b1346542eccee37c004083a918c480d67'))
    def span(start,stop):
        time=dict(zip(times[:,0].astype(int),times[:,3]))
        return (time[stop]-time[start])*1000
    for folder,manifest,keys in ((early,'ce9ca0f03916af1fa3bfd449a61e779a74ce3427fae0a3a6bcdf65bc2b6c70ee',('state-anchorA-three-64.npz',)),
                                  (ROOT/'mts-fire-581-formation-state-20261120','a468eac90a9e2ec4a840dfbcf1ec23a0c4cc7acc6c17f7d258f229ab44116a1a',('wave-anchorA-joint-64.npz',))):
        for key in keys:
            with np.load(input_file(folder,key,manifest)) as states:
                assert 590 in states['snapshots'] and 600 in states['snapshots']
                if folder==early: assert states['snapshots'][0]==544
    history={key:dict(span_Myr=value,percent_of_1p94_Gyr=100*value/1940,percent_of_5_Gyr=100*value/5000)
             for key,value in [('tested_both_signs_590_600',span(590,600)),('common_forward_only_572_600',span(572,600)),
                               ('inherited_forward_only_544_600',span(544,600))]}
    fine='72-192'
    cols=['relative_RA_deg','relative_dec_deg','relative_vlos_kms']
    errors=[];timing=[]
    for arm in ('reset','coupled'):
        for dist in ('20.9','22.05','23.2'):
            def items(prefix,label):
                return [row for row in readrows(prefix,label) if row['arm']==arm and row['dist']==dist]
            def escaped(label):
                group=items('escapes',label)
                return np.array([[[[float(row[col]) for col in cols] for row in group if row['flow']==sign and row['tail']==tail]
                               for tail in ('inner','outer')] for sign in ('forward','reverse')])
            esc=escaped(fine)
            assert esc.shape==(2,2,3,3)
            for index,col in enumerate(cols):
                for side,tail in enumerate(('inner','outer')):
                    fixed=np.abs(esc[0,side,:,index]-esc[1,side,:,index]).max()
                    spans=np.ptp(esc[:,side,:,index],axis=1)
                    timing.append(dict(arm=arm,distance_kpc=dist,tail=tail,observable=col,
                           max_sign_split=fixed,release_time_span_forward=spans[0],release_time_span_reverse=spans[1],
                           smaller_timing_span_over_largest_flow_split=min(spans)/fixed))
            for low,high in [('18-96','36-96'),('36-96','36-192'),('36-192',fine)]:
                def check(kind,left,right):
                    value=float(np.linalg.norm(left-right)/np.linalg.norm(right))
                    errors.append(dict(arm=arm,distance=dist,coarse=low,fine=high,kind=kind,relative=value,passes=value<cutoff))
                for col in ('delta_dec_fixed_RA_deg','delta_vlos_fixed_RA_kms','delta_position_pc'):
                    check(col,signal(items('track',low),col),signal(items('track',high),col))
                for col in ('gradient_delta_kms_deg',):
                    check(col,signal(items('summary',low),col),signal(items('summary',high),col))
                for idx,col in enumerate(cols):
                    first,second=escaped(low),escaped(high)
                    check(col,(first[0]-first[1])[...,idx],(second[0]-second[1])[...,idx])
    writecsv('refinements-through-72.csv',errors);writecsv('release-time-budget-72.csv',timing)
    writejson('coverage.json',history);writejson('history-provenance.json',ledger)
    final=[row for row in errors if row['fine']==fine]
    oldfailed=[row for row in errors if not row['passes'] and row['fine']=='36-96']
    assert len(oldfailed)==1 and oldfailed[0]['kind']=='relative_vlos_kms'
    assert len(final)==42 and all(row['passes'] for row in final)
    for count in (18,36,72):
        metadata=json.loads((HOME/f'evolution-{count}.json').read_bytes())
        assert digest(HOME/'PROTOCOL.md')==metadata['protocol']
        assert abs(metadata['age_Myr']-span(590,600))<1e-9
        with np.load(HOME/f'potential-{count}.npz') as bank:
            for arm in ('reset','coupled'):
                positive=bank[arm+'_forward'];negative=bank[arm+'_reverse']
                assert np.isfinite(positive).all() and np.isfinite(negative).all()
                assert np.array_equal(positive[0,...,0],negative[0,...,0])
                assert np.array_equal(positive[0,...,1],-negative[0,...,1])
                assert np.linalg.norm(positive[-1,...,0]-negative[-1,...,0])>0
                if count==18: assert metadata['arms'][arm+'_forward']['archived_endpoint_wave_relative']<1e-9
    print('Checks:',len(final),'final failures:',[row for row in final if not row['passes']],'max',max(row['relative'] for row in final),'age contrast:',history,
          'timing range',min(row['smaller_timing_span_over_largest_flow_split'] for row in timing),
          max(row['smaller_timing_span_over_largest_flow_split'] for row in timing))
    if (HOME/'RESULTS.md').exists():
        files=sorted(path for path in HOME.iterdir() if path.is_file() and path.name!='seal.json')
        writejson('seal.json',{path.name:digest(path) for path in files})
        print('Seal',digest(HOME/'seal.json'))

if __name__=='__main__':
    checked_run()
