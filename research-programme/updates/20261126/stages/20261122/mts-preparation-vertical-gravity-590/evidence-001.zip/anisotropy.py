from green import Gravity
from local import *
from scipy.special import roots_legendre

def enclosed(wave,radius):
    cuts=np.unique(np.r_[wave.edges[wave.edges<radius],radius])
    node,wt=roots_legendre(wave.order);half=np.diff(cuts)[:,None]/2
    rr=cuts[:-1,None]+half*(1+node)
    u=wave.amplitude(rr.ravel())
    return 4*np.pi*np.sum(half*wt*rr**2*np.sum(abs(u)**2,axis=1).reshape(rr.shape))
def run():
    radii=np.array([float(r['R_kpc']) for r in read(HERE/'rotation-data.csv')])
    rows=[];contrast=[];bounds=[]
    for stage,order,angular in (('coarse',12,72),('fine',24,110)):
        for state in STATES:
            obj=Gravity(state,order,angular)
            field,_=obj.evaluate(radii,np.zeros_like(radii))
            for radius,item in zip(radii,field):
                mass=enclosed(obj,radius);equatorial=radius**2*item[1]/G
                rows.append(dict(stage=stage,state=state,R_kpc=radius,mass_inside_Msun=mass,plane_equivalent_Msun=equatorial,
                    anisotropic_equivalent_Msun=equatorial-mass,angular_inward_force=G*(equatorial-mass)/radius**2))
    for arm in ('reset','coupled'):
        q=[r for r in rows if r['stage']=='fine' and r['state']==arm+'_forward']
        contrast.append(dict(arm=arm,monopole_increment=q[-1]['mass_inside_Msun']-q[0]['mass_inside_Msun'],
            angular_increment=q[-1]['anisotropic_equivalent_Msun']-q[0]['anisotropic_equivalent_Msun'],
            equatorial_increment=q[-1]['plane_equivalent_Msun']-q[0]['plane_equivalent_Msun']))
    diff=contrast[1]['angular_increment']-contrast[0]['angular_increment']
    for front in ('native','positive','defect'):
        for arm in ('reset','coupled'):
            massrows=[r for r in read(HERE/'spherical-mass-intervals.csv') if r['foreground']==front and r['arm']==arm and r['errors']=='quoted']
            for start,end in ((0,1),(1,2),(2,3),(0,3)):
                a,b=radii[start],radii[end]
                loss=float(massrows[start]['low_mass_Msun'])-float(massrows[end]['high_mass_Msun'])
                lower=max(0.,loss)*G/(a*a+b*b)
                bounds.append(dict(foreground=front,arm=arm,inner=a,outer=b,min_decrease_angular_equivalent_Msun=max(0.,loss),
                    min_max_angular_inward_force_kms2_kpc=lower,min_max_angular_force_m_s2=lower*1e6/3.085677581491367e19,
                    saved_inherited_minus_reset_angular_increment_Msun=diff if (start,end)==(0,3) else ''))
    table('wave-angular-gravity.csv',rows);table('wave-angular-contrast.csv',contrast);table('necessary-angular-force.csv',bounds)
if __name__=='__main__':run()
