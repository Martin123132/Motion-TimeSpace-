from pathlib import Path
from functools import lru_cache
import csv
import hashlib
import io
import json
import os
import sys
for key in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','BLIS_NUM_THREADS','NUMEXPR_NUM_THREADS'):os.environ[key]='1'
import numpy as np
from scipy.special import roots_legendre,eval_legendre
from numpy.polynomial import legendre as lg
HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
ORB=ROOT/'mts-pal5-joined-flow-586-600-20261122'
FORM=ROOT/'mts-flow-formation-inverse-586-20261122'
FIX=ROOT/'mts-pal5-finite-wave-stripping-20261122'
PREV=ROOT/'mts-pal5-astrometric-separation-20261122'
PINS={ORB:'86d9b1296c253b14a04e475339a9cbf71f84fed201749a234af4892b715576b7',FORM:'4ae215216dac834ea5d8ae503fea680707af22348044627efb0b507a7c398fcb',FIX:'4db5e73d0a80bbc234e7d1036b11a99d2965805c6eb42d04f91f4171260aa5e8',PREV:'2a666847fdec6691453833d9d0ce3496d479639cbce0c2884ad2352b074c2361'}
def sha(path):
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
@lru_cache(None)
def pin(folder,name):
    assert sha(folder/'seal.json')==PINS[folder]
    path=folder/name
    assert sha(path)==json.loads((folder/'seal.json').read_bytes())[name],path
    return path
def guard():
    for folder in (HERE,ROOT,*PINS,ROOT/'mts-fire-joint-baryon-history-20261120',ROOT/'mts-pal5-live-wave-coupling-20261122',ROOT/'mts-pal5-interface-work-20261122',ROOT/'mts-pal5-release-evolution-20261122',ROOT/'mts-pal5-source-tides-20261122'):
        assert not (folder/'STOP-REQUESTED').exists(),folder
def store(name,data):
    path=HERE/name
    if path.exists():assert path.read_bytes()==data,name
    else:
        with path.open('xb') as stream:stream.write(data)
def record(name,value):store(name,(json.dumps(value,sort_keys=True,indent=2,allow_nan=False)+'\n').encode())
def table(name,rows):
    buf=io.StringIO();out=csv.DictWriter(buf,list(rows[0]),lineterminator='\n');out.writeheader();out.writerows(rows);store(name,buf.getvalue().encode())
def packet(name,**data):
    buf=io.BytesIO();np.savez_compressed(buf,**data);store(name,buf.getvalue())
def read(path):
    with path.open() as stream:return list(csv.DictReader(stream))
guard()
G=4.30091727003628e-6
R0=8.178
RADII=R0+np.arange(-3,4)*.1
Z=.400
STATES=('reset_forward','reset_reverse','coupled_forward','coupled_reverse')
HEIGHTS=(.1,.2,.4)
def run_nodes():
    pin(PREV,'RESULTS.md');pin(FORM,'inverse.py');sys.path.insert(0,str(FORM))
    from inverse import setup
    lab,*_=setup();el=lab.run.el;length=lab.obj.bg.length;degrees=lab.obj.bg.orders
    outputs=dict(edges=np.r_[el.left,el.right[-1]]*length,knots=el.knots,length=length,mscale=lab.mesh.mscale,degrees=degrees)
    masses={}
    for arm in ('reset','coupled'):
        for sign in ('forward','reverse'):
            wave=lab.initial[arm] if sign=='forward' else lab.initial[arm].conj()
            key=arm+'_'+sign;outputs[key]=el.nodes(wave)
            masses[key]=float(lab.mesh.mscale*np.vdot(wave,wave).real)
    assert max(masses.values())/min(masses.values())-1<1e-9
    packet('launch.npz',**outputs);record('occupation.json',masses)
if __name__=='__main__':run_nodes()
