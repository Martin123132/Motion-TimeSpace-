from anisotropy import enclosed
from green import Gravity
from local import *

def run():
    pin(FORM,'inverse.py');sys.path.insert(0,str(FORM))
    from inverse import setup
    lab,_,_,_,_=setup()
    radii=np.array([float(r['R_kpc']) for r in read(HERE/'rotation-data.csv')])
    late=read(HERE/'wave-angular-gravity.csv');output=[];history=[]
    for nstep in (140,280):
        with np.load(pin(FORM,f'states-586-{nstep}.npz')) as bank:
            for state in STATES:
                obj=Gravity(state,24,110);obj.nodes=lab.run.el.nodes(bank[state])
                acc,mass=obj.evaluate(radii,np.zeros_like(radii));assert abs(mass/(lab.mesh.mscale*lab.obj.number)-1)<1e-8
                before=[];after=[]
                for idx,R in enumerate(radii):
                    current=enclosed(obj,R);equiv=R**2*acc[idx,1]/G
                    saved=next(r for r in late if r['stage']=='fine' and r['state']==state and float(r['R_kpc'])==R)
                    now=np.array([current,equiv-current,equiv])
                    target=np.array([float(saved[k]) for k in ('mass_inside_Msun','anisotropic_equivalent_Msun','plane_equivalent_Msun')])
                    before.append(now);after.append(target)
                    row=dict(steps=nstep,state=state,R_kpc=R)
                    for j,key in enumerate(('enclosed','angular','plane_equivalent')):
                        row[key+'_586']=now[j];row[key+'_590']=target[j];row[key+'_change']=target[j]-now[j]
                    output.append(row)
                before=np.array(before);after=np.array(after)
                change=(after[-1]-after[0])-(before[-1]-before[0]);assert abs(change[0]+change[1]-change[2])<1e-4
                history.append(dict(steps=nstep,state=state,shell_change_Msun=change[0],angular_excursion_change_Msun=change[1],
                    plane_equivalent_shell_change_Msun=change[2],realized_mean_net_shell_rate_Msun_yr=change[0]/(1e6*(lab.run.ages[590]-lab.run.ages[586])),
                    duration_Myr=lab.run.ages[590]-lab.run.ages[586]))
    table('formation-by-radius.csv',output);table('formation-shell.csv',history)
    checks=[]
    for state in STATES:
        coarse,fine=[next(r for r in history if r['steps']==n and r['state']==state) for n in (140,280)]
        for key in ('shell_change_Msun','angular_excursion_change_Msun','plane_equivalent_shell_change_Msun'):
            err=abs(coarse[key]/fine[key]-1)
            checks.append(dict(state=state,quantity=key,relative=err,passes=bool(err<=.005)))
    table('formation-refinements.csv',checks)
if __name__=='__main__':run()
