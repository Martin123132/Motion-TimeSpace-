from green import Gravity
from local import *
from anisotropy import enclosed
from completion import interval,constraints,vertical
import re

def checks():
    class Sphere(Gravity):
        def __init__(self):
            self.edges=np.array([0.,1.,2.]);self.ell=np.array([0,2]);self.degrees=np.array([0]);self.order=24
        def modes(self,rad):return np.column_stack((1.*(rad<1),rad*0))
        def amplitude(self,rad):return (1.*(rad<1))[:,None]
    cyl=np.array([.2,.5,1.1,1.7]);z=np.array([.3,-.1,.2,-.12]);r=np.hypot(cyl,z)
    field,mass=Sphere().evaluate(cyl,z);mt=4*np.pi/3
    assert abs(mass/mt-1)<1e-12
    expected=np.column_stack((np.where(r<1,-G*mt*(3-r*r)/2,-G*mt/r),
        G*mt*cyl*np.where(r<1,1.,r**-3),G*mt*z*np.where(r<1,1.,r**-3),r<1,
        G*mt*np.where(r<1,1.,r**-3*(1-3*(z/r)**2))))
    assert np.max(abs(expected-field))<1e-12
    rbin=np.array([1.,1.4,1.6,2.]);fixed=np.full(4,17.)
    assert np.allclose(vertical(fixed,fixed,rbin,1.3,.7),17*(1/1.3-1/np.hypot(1.3,.7)),atol=1e-13)
    lo,high,where=interval(constraints(np.array([5.,6.]),np.array([5.,6.]),np.array([1.,1.]),np.array([1.,3.])))
    assert lo==0 and high==.5 and where==(0,1)
    assert interval(constraints(np.array([7.,6.]),np.array([7.,6.]),np.array([1.,1.]),np.array([1.,3.])))==(None,None,None)
    froot=ROOT/'mts-fire-density-forecast-20261121'
    freeze=froot/'freeze.json';assert sha(freeze)=='56e6fe56045146e609bdb80a970949886d0bcf0d49312d8332fe72b068d17776'
    shell=froot/'enclosed-forecast.csv';assert sha(shell)==json.loads(freeze.read_bytes())['mass']
    for arm in ('reset','coupled'):
        wave=Gravity(arm+'_forward',24,110)
        for row in read(shell):
            if row['arm']==arm:assert abs(enclosed(wave,float(row['r_kpc']))/float(row['mass_Msun'])-1)<1e-7
    rows=read(HERE/'numerical-checks.csv');assert len(rows)==2177 and all(r['passes']=='True' for r in rows)
    assert len(read(HERE/'field-finer.csv'))==84 and len(read(HERE/'radial-secants.csv'))==180
    anis=read(HERE/'wave-angular-gravity.csv')
    for state in STATES:
        select=lambda name:[float(r['anisotropic_equivalent_Msun']) for r in anis if r['stage']==name and r['state']==state]
        first,last=map(np.asarray,(select('coarse'),select('fine')))
        assert np.all(abs(first/last-1)<.005)
    result=json.loads((HERE/'decision.json').read_bytes())
    assert all(r['minimum_mass_decrease_inner_to_outer_Msun']>8e9 for r in result['fixed_wave_mass_mismatch'])
    repair=json.loads((HERE/'formation-repair.json').read_bytes())
    history=read(HERE/'formation-refinements.csv')
    misses=[r for r in history if r['passes']!='True']
    assert len(history)==12 and len(misses)==1 and misses[0]['state']=='reset_forward'
    assert misses[0]['quantity']=='plane_equivalent_shell_change_Msun' and float(misses[0]['relative'])>.005
    assert repair['comparison_280_to_560']<=.005 and repair['wave_reversal_error']<1e-9
    for r in read(HERE/'necessary-angular-force.csv'):
        if r['foreground']=='positive' and r['inner']=='7.28' and r['outer']=='8.71':
            assert 9e-12<float(r['min_max_angular_force_m_s2'])<1e-11
    source=json.loads((HERE/'measurement.json').read_bytes())
    assert (source['total'],source['total_sd'],source['foreground_including_total_rotation'],source['foreground_sd'])==(301.8,6.,265.,16.)
    feasibility=read(HERE/'spherical-feasibility.csv')
    for row in feasibility:
        if row['foreground']=='positive':
            assert row['can_add_sphere_to_ordinary']=='True'
            assert (row['can_add_sphere_to_both']=='True')==(row['errors']=='plus5pct')
    assert len(read(HERE/'rotation-data.csv'))==4
    for path in HERE.glob('*.py'):compile(path.read_bytes(),str(path),'exec')
    for path in HERE.glob('*.md'):
        for dest in re.findall(r'\]\(([^)]+)\)',path.read_text(encoding='utf-8')):
            if not dest.startswith('https://'):assert (HERE/dest).is_file(),dest
    assert not (HERE/'__pycache__').exists()
def seal(issue):
    guard();checks();files={p.name:sha(p) for p in sorted(HERE.iterdir()) if p.is_file() and p.name!='seal.json'}
    if issue:record('seal.json',files)
    assert json.loads((HERE/'seal.json').read_bytes())==files
    print(len(files),'verified;',sha(HERE/'seal.json'))
if __name__=='__main__':seal(sys.argv[1:]==['--seal'])
