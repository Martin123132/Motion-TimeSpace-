from local import *
from scipy.interpolate import RectBivariateSpline,CubicHermiteSpline
from scipy.special import legendre_p_all

def even_spline(radius,mu,grid):
    ir=np.flatnonzero((radius>7.4)&(radius<8.95))
    ia=np.flatnonzero(mu<.1)
    sub=grid[np.ix_(ir,ia)]
    return RectBivariateSpline(radius[ir],np.r_[-mu[ia][::-1],mu[ia]],np.column_stack((sub[:,::-1],sub)),s=0)
def scalar(spline,R,z):
    r=np.hypot(R,z)
    return spline.ev(r,z/r)
def volume_density(space,mass,R,height):
    edges=space.rf[(space.rf>R)&(space.rf<np.hypot(R,height))]
    m=space.mf[(space.mf>0)&(space.mf<height/np.hypot(R,height))]
    cuts=np.unique(np.r_[0.,np.sqrt((edges-R)*(edges+R)),R*m/np.sqrt(1-m*m),height])
    z=(cuts[1:]+cuts[:-1])/2;r=np.hypot(R,z);mu=z/r
    idx=space.rf.searchsorted(r)-1;j=space.mf.searchsorted(mu)-1
    return 4*np.pi*G*(np.diff(cuts)*(height-z))@(mass[idx,j]/space.vol[idx])
def native_field(material,R,z):
    r=np.atleast_1d(np.hypot(R,z));mu=z/r
    val=material.radial(r,(590,590),0,0)[0]
    return np.sum(val*lg.legvander(mu,68)[:,::2],axis=1)
def run():
    sys.path.insert(0,str(FIX));pin(FIX,'mesh_fd.py');pin(FIX,'finite_io.py')
    from mesh_fd import Space
    from base import geometry
    material,_=geometry()
    rows=[]
    for level,order in ((1,3),(2,4),(3,4)):
        guard()
        with np.load(pin(FIX,f'mass-{level}-{order}.npz')) as src:
            space=Space(src['rf'],src['mf']);mass=src['mass'][1]
        with np.load(pin(FIX,f'drives-{level}-{order}.npz')) as drive:
            assert np.array_equal(space.rf,drive['rf']) and np.array_equal(space.mf,drive['mf'])
            defect=even_spline(space.r,space.mu,drive['delta590'])
        solved=even_spline(space.r,space.mu,space.poisson(4*np.pi*G*mass))
        for R in RADII:
            for height in HEIGHTS:
                z=np.array([0.,height]);rise=lambda x:float(x[1]-x[0])
                native=rise(native_field(material,R,z))
                positive=rise(scalar(solved,R,z))
                repaired=native+rise(scalar(defect,R,z))
                density=volume_density(space,mass,R,height)
                rows.append(dict(level=level,R_kpc=R,Z_kpc=height,ordinary_native=native,positive_direct=positive,
                    native_plus_defect=repaired,positive_density=density,positive_radial_integral=density-positive))
        print('ordinary',level,[r for r in rows if r['level']==level and r['R_kpc']==R0 and r['Z_kpc']==Z],flush=True)
    table('foreground.csv',rows)
def banks():
    output=[]
    for steps in (140,280):
        for arm in ('reset','coupled'):
            with np.load(pin(ORB,f'early-{steps}-{arm}.npz')) as data:
                for sign in ('forward','reverse'):
                    key=f'{arm}_{sign}';values=data[key][-1,...,0]
                    sp=CubicHermiteSpline(data['radius'],values[:,:,0],values[:,:,1],axis=0,extrapolate=False)
                    for R in RADII:
                        for h in HEIGHTS:
                            z=np.array([0.,h]);r=np.hypot(R,z);mu=z/r
                            ang,der=legendre_p_all(68,mu,diff_n=1)[:,::2,:].transpose(0,2,1)
                            phi=np.sum(sp(r)*ang,axis=1);pr=np.sum(sp(r,1)*ang,axis=1);pm=np.sum(sp(r)*der,axis=1)
                            gr=(R/r)*(pr-mu*pm/r);gz=mu*pr+(1-mu**2)*pm/r
                            output.append(dict(steps=steps,state=key,R_kpc=R,Z_kpc=h,phi_rise=phi[1]-phi[0],equatorial_inward_force=gr[0],vertical_force_top=-gz[1]))
    table('field-bank-check.csv',output)
if __name__=='__main__':run();banks()
