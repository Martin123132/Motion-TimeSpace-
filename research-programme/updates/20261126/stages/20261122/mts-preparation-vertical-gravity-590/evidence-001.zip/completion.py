from local import *
from scipy.optimize import brentq,linprog

def constraints(lo,hi,baryon,wave):
    size=len(lo)
    for end in range(size):
        for start in range(-1,end):
            yield end,start,wave[end]-(wave[start] if start>=0 else 0.),hi[end]-baryon[end]-(lo[start]-baryon[start] if start>=0 else 0.)
def interval(pairs):
    low=0.;high=np.inf;active=None
    for end,start,a,b in pairs:
        if a>0 and b/a<high:high=b/a;active=(start,end)
        if a<0:low=max(low,b/a)
        if a==0 and b<0:return None,None,None
    return (low,high,active) if low<=high else (None,None,None)
def envelopes(lo,hi,target):
    lower=np.maximum.accumulate(np.maximum(0.,lo-target))
    upper=np.minimum.accumulate((hi-target)[::-1])[::-1]
    return lower,upper
def vertical(lo,hi,radii,R,height):
    stop=np.hypot(R,height)
    assert radii[0]<R<stop<radii[-1]
    cuts=np.r_[R,radii[(radii>R)&(radii<stop)],stop]
    left=[np.searchsorted(radii,a,side='right')-1 for a in cuts[:-1]]
    weights=np.diff(cuts)/(cuts[1:]*cuts[:-1])
    return np.array([weights@lo[left],weights@hi[np.array(left)+1]])
def read_grid(level,foreground,arm):
    data=read(HERE/'rotation-data.csv')
    radii=np.array([float(r['R_kpc']) for r in data]);obs=np.array([float(r['speed']) for r in data])
    minus=np.array([float(r['lower']) for r in data]);plus=np.array([float(r['upper']) for r in data])
    rows=[r for r in read(HERE/'radial-predictions.csv') if r['state']==arm+'_forward' and r['level']==str(level) and r['foreground']==foreground and r['measured']]
    assert np.array_equal(radii,[float(r['R_kpc']) for r in rows])
    baryon,wave=[radii**2*np.array([float(r[k]) for r in rows]) for k in ('ordinary_inward','wave_inward')]
    return radii,obs,minus,plus,baryon,wave
def run():
    results=[];rays=[];diagnostics=[];shared=[];masses=[]
    corrections={(float(r['R_kpc']),r['state']):float(r['phi_rise']) for r in read(HERE/'field-finer.csv') if r['Z_kpc']=='0.4'}
    foregrounds={(float(r['R_kpc']),r['level']):r for r in read(HERE/'foreground.csv') if r['Z_kpc']=='0.4'}
    for level in (2,3):
        for foreground in ('native','positive','defect'):
            for arm in ('reset','coupled'):
                radii,obs,minus,plus,baryon,wave=read_grid(level,foreground,arm)
                base=dict(level=level,foreground=foreground,arm=arm)
                for label,quoted,fraction in (('central',0,0),('quoted',1,0),('plus1pct',1,.01),('plus2pct',1,.02),('plus5pct',1,.05)):
                    lower=radii*((obs-quoted*minus)*(1-fraction))**2;upper=radii*((obs+quoted*plus)*(1+fraction))**2
                    pairs=list(constraints(lower,upper,baryon,wave))
                    low,high,active=interval(pairs);available=low is not None
                    cap='' if not available else float(high)
                    feasible=lambda eta:bool(available and low<=eta<=high)
                    if available:
                        assert abs(linprog([-1.],A_ub=[[a] for _,_,a,b in pairs],b_ub=[b for _,_,a,b in pairs],bounds=[(0,None)],method='highs',options={'threads':1,'parallel':False}).x[0]-high)<1e-8
                    results.append(dict(**base,errors=label,eta_min=low if available else '',eta_max=cap,can_add_sphere_to_ordinary=feasible(0),can_add_sphere_to_both=feasible(1),
                         limiting_inner=radii[active[0]] if active and active[0]>=0 else '',limiting_outer=radii[active[1]] if active else ''))
                    for eta,tag in [(0.,'no_wave'),(1.,'fixed_wave')]+([(high,'upper_bound')] if available else []):
                        target=baryon+eta*wave
                        lo,hi=envelopes(lower,upper,target)
                        if label in ('central','quoted') and level==3 and tag=='fixed_wave':
                            for idx,rad in enumerate(radii):
                                masses.append(dict(**base,errors=label,R_kpc=rad,low_mass_Msun=(lower[idx]-target[idx])/G,
                                    high_mass_Msun=(upper[idx]-target[idx])/G,monotonic_prefix_min=lo[idx]/G,monotonic_suffix_max=hi[idx]/G))
                        if np.max(lo-hi)>1e-7:continue
                        for R in RADII:
                            bracket=vertical(lo,hi,radii,R,Z)
                            common=foregrounds[R,str(level)][{'native':'ordinary_native','positive':'positive_direct','defect':'native_plus_defect'}[foreground]]
                            static=float(common)+eta*corrections[R,arm+'_forward']
                            rays.append(dict(**base,errors=label,case=tag,eta=eta,R_kpc=R,base_plus_wave=static,
                                 total_lower=static+bracket[0],total_upper=static+bracket[1]))
                target=baryon+wave
                def violations(e):
                    lo,hi=envelopes(radii*((obs-minus)*(1-e))**2,radii*((obs+plus)*(1+e))**2,target)
                    return max(lo-hi)
                smallest=0. if violations(0)<=0 else brentq(violations,0.,.20)
                shared_ineq=[(i,j,-(radii[i]*(obs[i]+plus[i])**2-(radii[j]*(obs[j]-minus[j])**2 if j>=0 else 0.)),
                    -(target[i]-(target[j] if j>=0 else 0.))) for i in range(len(radii)) for j in range(-1,i)]
                zl,zh,_=interval(shared_ineq)
                shared.append(dict(**base,min_shared_scale=(np.sqrt(zl) if zl is not None else ''),max_shared_scale=(np.sqrt(zh) if zh is not None and np.isfinite(zh) else ''),
                    shared_5pct_can_repair=bool(zl is not None and zl<=1.05**2 and zh>=.95**2)))
                mass=(radii*obs**2-target)/G
                diagnostics.append(dict(**base,inner_extra_Msun=mass[0],outer_extra_Msun=mass[-1],endpoint_change_Msun=mass[-1]-mass[0],min_extra_per_bin_speed_fraction_after_quoted=smallest))
    table('spherical-feasibility.csv',results);table('spherical-mass-intervals.csv',masses);table('completion-vertical-envelope.csv',rays)
    table('completion-threshold.csv',diagnostics);table('common-calibration.csv',shared)
if __name__=='__main__':run()
