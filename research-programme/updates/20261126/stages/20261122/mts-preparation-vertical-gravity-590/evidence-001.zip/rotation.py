from green import Gravity
from local import *
from scipy.interpolate import RectBivariateSpline
import re

def acquire():
    import requests,fitz
    url='https://arxiv.org/pdf/2303.12838'
    with requests.get(url,stream=True,timeout=(8,20)) as response:
        response.raise_for_status();raw=bytearray()
        for chunk in response.iter_content(65536):
            raw.extend(chunk);assert len(raw)<5_000_000
    signature=hashlib.sha256(raw).hexdigest()
    assert signature=='48c6a67ec70e094a8e00cc19a5f2e4bec3e1d2b3e4c6fdb951fa4f3dbdd0d718'
    with fitz.open(stream=bytes(raw),filetype='pdf') as doc:s=' '.join(doc[5].get_text().split())
    start=s.index('6.27 231.07');stop=s.index('10.24',start)
    fields=s[start:stop].split();assert len(fields)%5==0
    rows=[]
    for i in range(0,len(fields),5):
        rad,vc,plus,minus,count=fields[i:i+5]
        if abs(float(rad)-R0)<=1:rows.append(dict(R_kpc=float(rad),speed=float(vc),upper=float(plus),lower=float(minus),count=int(count)))
    assert len(rows)==4 and all(r['count']>=1 for r in rows)
    table('rotation-data.csv',rows);record('rotation-source.json',dict(url=url,sha256=signature,page_pdf=6,table=1,bytes=len(raw),cut='all |R-8.178 kpc|<=1 kpc',units='kpc and km/s',doi='10.1093/mnras/stae034'))
def radial():
    sys.path.insert(0,str(FIX));pin(FIX,'mesh_fd.py');pin(FIX,'finite_io.py')
    from mesh_fd import Space
    from base import geometry
    material,_=geometry();data=read(HERE/'rotation-data.csv')
    radii=np.array([float(r['R_kpc']) for r in data]);nodes=np.unique(np.r_[radii,RADII])
    waves={s:Gravity(s,24,110).evaluate(nodes,np.zeros_like(nodes))[0][:,1] for s in STATES}
    assert np.array_equal(waves['reset_forward'],waves['reset_reverse'])
    assert np.array_equal(waves['coupled_forward'],waves['coupled_reverse'])
    lookup={float(r['R_kpc']):r for r in data}
    rows=[];slopes=[]
    for level,order in ((1,3),(2,4),(3,4)):
        guard()
        with np.load(pin(FIX,f'mass-{level}-{order}.npz')) as obj:
            space=Space(obj['rf'],obj['mf']);mass=obj['mass'][1]
        ir=np.flatnonzero((space.r>6.8)&(space.r<9.6));ia=np.flatnonzero(space.mu<.09)
        def force(array):
            sub=array[np.ix_(ir,ia)]
            spline=RectBivariateSpline(space.r[ir],np.r_[-space.mu[ia][::-1],space.mu[ia]],np.column_stack((sub[:,::-1],sub)),s=0)
            return spline.ev(nodes,np.zeros_like(nodes),dx=1)
        positive=force(space.poisson(4*np.pi*G*mass))
        native=material.radial(nodes,(590,590),0.,1)[1]@lg.legvander(0.,68)[0,::2]
        with np.load(pin(FIX,f'drives-{level}-{order}.npz')) as obj:repaired=native+force(obj['delta590'])
        for ordinary_name,ordinary in (('native',native),('positive',positive),('defect',repaired)):
            for state,acc in dict(ordinary=np.zeros_like(nodes),**waves).items():
                speed2=nodes*(ordinary+acc)
                assert min(speed2)>0
                for idx,R in enumerate(nodes):
                    speed=np.sqrt(speed2[idx]);obs=lookup.get(R)
                    rows.append(dict(level=level,foreground=ordinary_name,state=state,R_kpc=R,ordinary_inward=ordinary[idx],wave_inward=acc[idx],
                        vc_kms=speed,measured=float(obs['speed']) if obs else '',model_minus_measured=speed-float(obs['speed']) if obs else ''))
                for start,end in [*zip(radii[:-1],radii[1:]),(radii[0],radii[-1])]:
                    a,b=np.searchsorted(nodes,(start,end));factor=(end**2-start**2)/2
                    s1,s2=lookup[start],lookup[end]
                    lo,hi=float(s1['speed']),float(s2['speed'])
                    central=(hi**2-lo**2)/factor
                    minimum=((hi-float(s2['lower']))**2-(lo+float(s1['upper']))**2)/factor
                    maximum=((hi+float(s2['upper']))**2-(lo-float(s1['lower']))**2)/factor
                    slopes.append(dict(level=level,foreground=ordinary_name,state=state,start=start,end=end,
                        model_curvature=(speed2[b]-speed2[a])/factor,measured_curvature=central,
                        opposing_low=minimum,opposing_high=maximum,wave_curvature=(end*acc[b]-start*acc[a])/factor,
                        relative_speed_ratio_residual=np.sqrt(speed2[b]/speed2[a])/(hi/lo)-1))
    table('radial-predictions.csv',rows);table('radial-secants.csv',slopes)
if __name__=='__main__':
    if sys.argv[1:]==['--acquire']:acquire()
    radial()
