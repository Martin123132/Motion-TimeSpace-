from local import *
from math import sqrt
def index(rows,keys):return {tuple(r[k] for k in keys):r for r in rows}
def run():
    g=[];comparisons=[]
    wavekeys=('state','R_kpc','Z_kpc');bins=[index(read(HERE/f'field-{label}.csv'),wavekeys) for label in ('coarse','fine','finer')]
    wf=bins[-1];f=lambda r,k:float(r[k])
    def add(test,desc,actual,expected,group):
        err=abs(actual-expected)/max(abs(expected),1e-100)
        g.append(dict(test=test,scope=desc,group=group,relative=err,passes=bool(err<=.005)))
    def delta(group,r,h,qty):return f(group['reset_forward',r,h],qty)-f(group['coupled_forward',r,h],qty)
    archived=read(HERE/'field-bank-check.csv');fields=('phi_rise','equatorial_inward_force','vertical_force_top')
    for rr in RADII:
        for zz in HEIGHTS:
            r,h=str(rr),str(zz)
            for st in STATES:
                row=wf[st,r,h];tag=st+'/'+r+'/'+h
                for name in ('integral_force','integral_tide','density_minus_radial'):add(name,tag,f(row,name),f(row,'phi_rise'),'absolute_wave')
                for other in (0,1):
                    for q in (*fields,'density_term','vertical_tide_plane'):add(f'green_level_{other}_{q}',tag,f(bins[other][st,r,h],q),f(row,q),'absolute_wave')
            for name in ('integral_force','integral_tide','density_minus_radial'):add(name,r+'/'+h,delta(wf,r,h,name),delta(wf,r,h,'phi_rise'),'preparation_difference')
            for other in (0,1):
                for q in (*fields,'density_term','vertical_tide_plane'):add(f'green_level_{other}_{q}',r+'/'+h,delta(bins[other],r,h,q),delta(wf,r,h,q),'preparation_difference')
    for steps in ('140','280'):
        bank=index([r for r in archived if r['steps']==steps],wavekeys)
        for rr in RADII:
            for zz in HEIGHTS:
                r,h=str(rr),str(zz)
                for q in fields:
                    add('archived_'+steps+'_'+q,r+'/'+h,delta(bank,r,h,q),delta(wf,r,h,q),'preparation_difference')
                    for st in STATES:add('archived_'+steps+'_'+q,st+'/'+r+'/'+h,f(bank[st,r,h],q),f(wf[st,r,h],q),'absolute_wave')
    host=index(read(HERE/'foreground.csv'),('level','R_kpc','Z_kpc'))
    for rr in RADII:
        for zz in HEIGHTS:
            r,h=str(rr),str(zz)
            target=f(host['3',r,h],'positive_direct')
            for lev in ('1','2','3'):
                for q in ('positive_direct','native_plus_defect'):
                    add('host_'+lev+'_'+q,r+'/'+h,f(host[lev,r,h],q),target,'ordinary_gravity')
    source=json.loads((HERE/'measurement.json').read_bytes())
    total,st=source['total'],source['total_sd'];fore,sf=source['foreground_including_total_rotation'],source['foreground_sd'];sd=np.hypot(st,sf)
    empirical_term=4*np.pi*G*.5*Z**2*(-.0016)*1e9
    for rr in RADII:
        r,h=str(rr),str(Z)
        for state in ('ordinary','reset_forward','coupled_forward'):
            wave=0 if state=='ordinary' else f(wf[state,r,h],'phi_rise')
            density=0 if state=='ordinary' else f(wf[state,r,h],'density_term')
            radial=0 if state=='ordinary' else f(wf[state,r,h],'radial_divergence_term')
            target=(total-fore);pos=f(host['3',r,h],'positive_direct');native=f(host['3',r,h],'ordinary_native')
            comparisons.append(dict(R_kpc=rr,state=state,empirical_background=fore,wave_density=density,wave_full=wave,
                data_density_excess=target,source_conditioned=fore+density,conditioned_minus_data=fore+density-total,
                conditional_error_units=(fore+density-total)/sd,positive_total=pos+wave,native_total=native+wave,
                ordinary_radial_needed_with_empirical_total=empirical_term-radial,
                source_readout_ordinary_radial=f(host['3',r,h],'positive_radial_integral')))
    table('vertical-comparison.csv',comparisons)
    allrad=read(HERE/'radial-predictions.csv');data=read(HERE/'rotation-data.csv')
    profile=[]
    for level in ('2','3'):
        for foreground in ('native','positive','defect'):
            bystate={st:np.array([f(r,'vc_kms') for r in allrad if r['state']==st and r['level']==level and r['foreground']==foreground and r['measured']]) for st in ('reset_forward','coupled_forward')}
            difference=bystate['reset_forward']-bystate['coupled_forward'];mean=(bystate['reset_forward']+bystate['coupled_forward'])/2
            sigma=np.array([(f(r,'upper')+f(r,'lower'))/2 for r in data])
            basis=mean/sigma;vec=difference/sigma;ratio=basis@vec/(basis@basis)
            profile.append(dict(level=level,foreground=foreground,raw_stat_only=np.linalg.norm(vec),common_relative_speed=ratio,
                after_common_scale=np.linalg.norm(vec-ratio*basis),biggest_split_kms=max(abs(difference))))
    table('radial-state-sensitivity.csv',profile)
    rindex=index(allrad,('level','foreground','state','R_kpc'))
    for scope,name in (('speed','vc_kms'),('force','ordinary_inward')):
        for r in [e['R_kpc'] for e in data]:
            for state in ('ordinary','reset_forward','coupled_forward'):
                target=f(rindex['3','positive',state,r],name)
                for level,source_name in (('2','positive'),('3','defect')):
                    add('radial_'+level+source_name,scope+'/'+r+'/'+state,f(rindex[level,source_name,state,r],name),target,'radial_gravity')
            for level,source_name in (('2','positive'),('3','defect')):
                num=lambda lev,so:f(rindex[lev,so,'reset_forward',r],'vc_kms')-f(rindex[lev,so,'coupled_forward',r],'vc_kms')
                if scope=='speed':add('speed_split_'+level+source_name,r,num(level,source_name),num('3','positive'),'preparation_difference')
    table('numerical-checks.csv',g)
    masses=read(HERE/'spherical-mass-intervals.csv')
    massproof=[]
    for arm in ('reset','coupled'):
        q=[r for r in masses if r['arm']==arm and r['errors']=='quoted' and r['foreground']=='positive']
        massproof.append(dict(arm=arm,minimum_mass_decrease_inner_to_outer_Msun=f(q[0],'low_mass_Msun')-f(q[-1],'high_mass_Msun')))
    record('decision.json',dict(source_plus_rotation=fore,total_measurement=total,combined_sigma_if_uncorrelated=sd,covariance_sigma_range=[abs(sf-st),sf+st],
        central_vertical=[r for r in comparisons if r['R_kpc']==R0],fixed_wave_mass_mismatch=massproof,
        radial_state_sensitivity=[r for r in profile if r['level']=='3' and r['foreground']=='positive'][0],
        validation={key:dict(checks=len([r for r in g if r['group']==key]),fails=len([r for r in g if r['group']==key and not r['passes']]),worst=max(r['relative'] for r in g if r['group']==key)) for key in sorted(set(r['group'] for r in g))}))
if __name__=='__main__':run()
