from anisotropy import enclosed
from green import Gravity
from local import *
def run():
    pin(FORM,'inverse.py');sys.path.insert(0,str(FORM))
    from inverse import setup
    lab,Evolution,advance,owner_guard,_=setup()
    obj=lab.obj;run=lab.run;number=obj.number
    steps,dt=run.interval(586,590);assert steps==70
    count=8*steps;dt/=8;start=lab.initial['reset'].copy()
    def march(state,backward):
        step=-dt if backward else dt
        solver=Evolution(obj,step,state);mom=obj.moment(state);worst=0.
        for tick in range(count):
            if tick%16==0:guard();owner_guard()
            drive=run.external(586,590,count-1-tick if backward else tick,count)
            state,mom,_,_=advance(obj,solver,state,mom,drive,step)
            worst=max(worst,abs(np.vdot(state,state).real/number-1))
        assert worst<1e-9
        return state,worst
    state,norm=march(start.copy(),True)
    returned,norm2=march(state.copy(),False)
    inversion=np.linalg.norm(returned-start)/np.sqrt(number);assert inversion<1e-9
    packet('reset-forward-586-560.npz',state=state)
    radii=np.array([7.28,8.71])
    def difference(arm,early):
        wave=Gravity(arm+'_forward',24,110);late,_=wave.evaluate(radii,np.zeros(2))
        wave.nodes=run.el.nodes(early);before,_=wave.evaluate(radii,np.zeros(2))
        return np.diff(radii**2*(late[:,1]-before[:,1])/G)[0]
    last=difference('reset',state)
    fine=next(float(r['plane_equivalent_shell_change_Msun']) for r in read(HERE/'formation-shell.csv') if r['state']=='reset_forward' and r['steps']=='280')
    error=abs(fine/last-1)
    actual={arm:difference(arm,run.reference[586] if arm=='reset' else lab.raw[586]) for arm in ('reset','coupled')}
    record('formation-repair.json',dict(state='reset_forward',steps=count,comparison_280_to_560=error,passes=bool(error<=.005),norm_max=max(norm,norm2),wave_reversal_error=inversion,
        refined_equivalent_shell_change_Msun=last,original_direct_archive_equivalent_shell_change_Msun=actual))
    print('Refined relative change',error,'round trip',inversion,flush=True)
if __name__=='__main__':run()
