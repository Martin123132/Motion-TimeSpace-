from local import *
import requests
import fitz

URL='https://arxiv.org/pdf/2105.14030'
def run():
    with requests.get(URL,stream=True,timeout=(8,25)) as response:
        response.raise_for_status();raw=bytearray()
        for chunk in response.iter_content(65536):
            raw.extend(chunk)
            assert len(raw)<12_000_000
    signature=hashlib.sha256(raw).hexdigest()
    assert signature=='1e2c08858787c27906f31d8782f7fd12695f8902ebc7d86704e88033d909d4ee'
    with fitz.open(stream=bytes(raw),filetype='pdf') as pdf:
        pages=[' '.join(p.get_text().split()) for p in pdf]
    assert '301.8 ± 6.0' in pages[10] and '265.0 ± 16.0' in pages[7]
    assert '8178 pc' in ' '.join(pages)
    text=pages[1];start=text.index('giving ∆ρ');print(text[start:start+105])
    record('measurement.json',dict(url=URL,sha256=signature,bytes=len(raw),source='Widmark et al., A&A 653 A86 (2021), Gaia EDR3 plus spectroscopy',
        measurement_unit='(km/s)^2',height_kpc=.4,R0_kpc=8.178,step_kpc=.1,radial_groups=[-3,-2,-1,0,1,2,3],
        total=301.8,total_sd=6.,foreground_including_total_rotation=265.,foreground_sd=16.,
        convention='Equation 5 and Sec 5.3; use the excess only for the density integral, not the full wave potential.',pages_pdf_one_based=[2,8,11]))
if __name__=='__main__':run()
