from ledger_io import *
from itertools import combinations

def support(values):
    nodes=np.asarray(values,complex)
    candidates=[]
    for x,y in combinations(nodes,2):
        line=y-x
        s=np.clip(-np.real(x.conjugate()*line)/abs(line)**2,0,1) if x!=y else 0.
        closest=x+s*line
        if abs(closest)>0:
            unit=closest/abs(closest)
            candidates.append((np.min(np.real(np.conj(unit)*nodes)),unit))
    best,axis=max(candidates,key=lambda item:item[0])
    return max(0.,best),axis
def main():
    ans=[];ranks=[]
    for model in ('cold','heavy'):
        for cells,rule in ((0,'normal'),(32,'normal'),(32,'coordinate')):
            config=f'{model}-{cells}-{rule}'
            with np.load(HERE/f'state-{config}-original-trace-1-0.npz') as f:base=f['values'][-1]
            obs=lambda a:np.stack((a[1],a[:2].mean(axis=0)))
            base=obs(base)
            targets=[]
            for carrier in ('photon','rel_nu','common'):
                with np.load(HERE/f'prepared-{config}-{carrier}-material-trace-1.npz') as f:result=obs(f['values'][-1])
                targets.append((result-base)/base)
            targets=np.array(targets)
            for col,observable in enumerate(('lapse','Weyl')):
                for i,axis in enumerate(PROBES):
                    lower,unit=support(targets[:,col,i])
                    projected=(np.conj(unit)*targets[:,col,i]).real
                    assert np.min(projected)>=lower-1e-14 or lower==0.
                    ans.append(dict(model=model,cells=cells,matching=rule,probe=str(axis),observable=observable,
                                separating_real=unit.real,separating_imag=unit.imag,photon_projection=projected[0],rel_nu_projection=projected[1],common_projection=projected[2],
                                minimum_certified_fraction=lower,all_convex_combinations_miss_gate=bool(lower>.005)))
            vectors=targets.reshape(3,-1).T
            mat=np.column_stack([vectors[:,idx]-vectors[:,0] for idx in (1,2)])
            stacked=lambda a:np.concatenate((a.real,a.imag),axis=0)
            weights,_,rank,_=np.linalg.lstsq(stacked(mat),-stacked(vectors[:,0]),rcond=None)
            resid=vectors[:,0]+mat@weights
            ranks.append(dict(model=model,cells=cells,matching=rule,rank=rank,minimum_joint_rms_even_allowing_signed_weights=np.sqrt(np.mean(abs(resid)**2))))
    table('convex-certificates.csv',ans);table('affine-family-bound.csv',ranks)
if __name__=='__main__':main()
