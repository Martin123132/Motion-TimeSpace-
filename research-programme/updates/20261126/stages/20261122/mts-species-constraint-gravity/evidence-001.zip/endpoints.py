from ledger_io import *
def run(model):
    results=[];gates=[];inventory=[]
    def addcheck(label,val,limit):
        gates.append(dict(model=model,check=label,largest_error=val,threshold=limit,passed=bool(val<limit)))
    def state(cells,rule,route='original',kind='trace',step=1,legacy=0):
        with np.load(HERE/f'state-{model}-{cells}-{rule}-{route}-{kind}-{step}-{legacy}.npz') as f:return f['values']
    def prepared(cells,rule,carrier,route,step=1):
        with np.load(HERE/f'prepared-{model}-{cells}-{rule}-{carrier}-{route}-{step}.npz') as f:return f['values'],f['parts'],f['unassigned']
    def metric(arr):return np.stack((arr[:,1],arr[:,:2].mean(axis=1)))
    def compare(cells,rule,tag,arr,ref):
        diff=metric(arr)-metric(ref);scale=metric(ref)
        for idx,name in enumerate(('lapse','Weyl')):
            for pos,axis in enumerate(PROBES):
                val=diff[idx,-1,pos]/scale[idx,-1,pos]
                results.append(dict(cells=cells,rule=rule,test=tag,observable=name,probe=str(axis),reference_abs=abs(scale[idx,-1,pos]),
                              change_abs=abs(diff[idx,-1,pos]),change_real=diff[idx,-1,pos].real,change_imag=diff[idx,-1,pos].imag,
                              endpoint_fraction=abs(val),signed_parallel=val.real,peak_over_reference_peak=max(abs(diff[idx,:,pos]))/max(abs(scale[idx,:,pos])),crosses_half_percent=bool(abs(val)>.005)))
    for cells,rule in ((0,'normal'),(32,'normal'),(32,'coordinate')):
        baseline=state(cells,rule);mats=state(cells,'normal','material-trace')
        for tag,arr,ref in [('material vs compensated',mats,baseline),('two material gravity routes',state(cells,'normal','material-algebraic'),mats),
                       ('material half time step',state(cells,'normal','material-trace',step=2),mats),
                       ('material legacy neutrino flux conversion',state(cells,'normal','material-trace',legacy=1),mats)]:
            compare(cells,rule,tag,arr,ref)
        for carrier in ('ghost','anti-ghost','static-ghost','photon','rel_nu','common'):
            fict='ghost' in carrier;route='original' if fict else 'material-trace'
            arr,parts,debt=prepared(cells,rule,carrier,route)
            compare(cells,rule,carrier+' vs compensated',arr,baseline)
            if fict:continue
            alt,_,_=prepared(cells,rule,carrier,'material-algebraic')
            compare(cells,rule,carrier+' two gravity routes',alt,arr)
            if carrier=='common':compare(cells,rule,'common half time step',prepared(cells,rule,carrier,route,step=2)[0],arr)
            for idx,name in enumerate(('energy','longitudinal current')):
                total=parts[:,:,idx].sum(axis=1)+debt[:,idx]
                for p,axis in enumerate(PROBES):
                    scale=np.max(abs(total[:,p]))
                    inventory.append(dict(cells=cells,rule=rule,carrier=carrier,measure=name,probe=str(axis),launch_error=abs(debt[0,idx,p])/scale,
                                          full_error=max(abs(debt[:,idx,p]))/scale))
            init=np.max(abs(arr[0,:2]-baseline[0,:2])/np.maximum(abs(baseline[0,:2]),1e-80))
            addcheck(f'{cells}-{rule}-{carrier} initial potentials coincide',init,1e-10)
    for testname in ('two material gravity routes','material half time step','material legacy neutrino flux conversion','photon two gravity routes','rel_nu two gravity routes','common two gravity routes','common half time step','ghost vs compensated'):
        addcheck(testname,max(r['endpoint_fraction'] for r in results if r['test']==testname),.005)
    addcheck('materially carried energy and current full history',max(r['full_error'] for r in inventory),.005)
    table(f'endpoints-{model}.csv',results);table(f'carrier-constraints-{model}.csv',inventory);table(f'accuracy-{model}.csv',gates)
    print(model,[(r['check'],r['largest_error']) for r in gates if not r['passed']])
if __name__=='__main__':
    for model in ('cold','heavy'):run(model)
