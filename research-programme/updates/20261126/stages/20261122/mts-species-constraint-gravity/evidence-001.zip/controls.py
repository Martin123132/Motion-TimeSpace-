from ledger_io import *
import ast,re
from zipfile import ZipFile
def records(key):
    with (HERE/key).open() as fp:return list(csv.DictReader(fp))
def audit():
    checks=[];negative=[]
    def test(label,condition):
        assert condition,label
        checks.append(dict(test=label,result='PASS'))
    test('unexpanded normal energy and covector flux',len(records('unexpanded-material.csv'))==96 and max(float(r['unexpanded_relative']) for r in records('unexpanded-material.csv'))<1e-7)
    for model in ('cold','heavy'):
        test(model+' full material closures and real carrier refinements',len(records(f'accuracy-{model}.csv'))==18 and all(r['passed']=='True' for r in records(f'accuracy-{model}.csv')))
        ids=records(f'identity-archived-{model}.csv')
        test(model+' independent normal trace and shear inventories',len(ids)==15 and max(float(r[k]) for r in ids for k in ('trace_inventory','shear_inventory','aggregate_X','aggregate_Y'))<1e-9)
        for prefix in ('closure','origin','identity'):
            with (HERE/f'{prefix}-{model}.csv').open('rb') as f:prior=f.read()
            same=[mode for mode in ('archived','rebuilt') if (HERE/f'{prefix}-{mode}-{model}.csv').read_bytes()==prior]
            test(model+' early '+prefix+' output identified (archived or rebuilt)',len(same)>=1)
        for cells,rule in [(0,'normal'),(16,'normal'),(16,'coordinate'),(32,'normal'),(32,'coordinate')]:
            with np.load(HERE/f'state-{model}-{cells}-{rule}-original-trace-1-0.npz') as f:
                old=f['values'][:,:18]
            prev=(f'matched-{model}-{cells}-{rule}-all-trace.npz' if cells else f'metric-{model}-12-both-16-1-18-trace-1.npz')
            with np.load(verified(prev)) as ref:test(model+str(cells)+rule+' all older readouts unchanged',np.array_equal(old,ref['values']))
        for cells in (0,32):
            with np.load(HERE/f'state-{model}-{cells}-normal-material-trace-trace-1-0.npz') as f:
                v=f['values'];t=f['eta']
            components=v[:,18:46].reshape(len(v),7,4,5)[:,:,:2];req=v[:,46:48]
            denom=np.max(abs(req),axis=0)
            for species,index in [('photon',4),('rel_nu',5),('massive_nu',6),('cdm',2),('baryon',3),('slow',0)]+([('heavy',1)] if model=='heavy' else []):
                rem=req-components.sum(axis=1)+components[:,index];fractions=np.max(abs(rem),axis=0)/denom
                for col,name in enumerate(('energy','flux')):
                    for p,axis in enumerate(PROBES):
                        negative.append(dict(model=model,cells=cells,omitted=species,quantity=name,probe=str(axis),peak_fraction=fractions[col,p],crosses_original_gate=bool(fractions[col,p]>.005)))
                if species in ('photon','cdm','baryon','heavy'):
                    test(model+str(cells)+' removing '+species+' matters on at least one measurement',fractions.max()>.005)
            drift=np.max(abs(req-components.sum(axis=1)),axis=0)/denom
            test(model+str(cells)+' material constraint propagation, not algebraic construction',drift.max()<.005)
        stages=records(f'growing-mode-{model}.csv');ctrl=records(f'growing-transfer-controls-{model}.csv')
        test(model+' native growing transfer refinement within 0.5%',len(ctrl)==10 and max(float(r[key]) for r in ctrl for key in ('native_linear_constraint','density_difference','flux_difference'))<.005)
        test(model+' growing-mode obstruction robust to native precision',len(stages)==50 and min(float(r['min_native_joint_fraction']) for r in stages)>.005 and min(float(r['lower_bound_any_real_transfer']) for r in stages)>.005)
    cert=records('convex-certificates.csv')
    for model in ('cold','heavy'):
        for cells,rule in [('0','normal'),('32','normal'),('32','coordinate')]:
            tests=[r for r in cert if (r['model'],r['cells'],r['matching'])==(model,cells,rule)]
            test(model+cells+rule+' positive convex support verified',len(tests)==10 and max(min(float(r[q]) for q in ('photon_projection','rel_nu_projection','common_projection')) for r in tests)>.005)
    table('omit-a-species.csv',negative);table('verification.csv',checks)
def seal():
    guard()
    assert not any(p.is_dir() for p in HERE.iterdir())
    for path in HERE.glob('*.py'):ast.parse(path.read_text(),filename=str(path))
    for path in HERE.glob('*.md'):
        for link in re.findall(r'\]\(([^)]+)\)',path.read_text(encoding='utf-8')):
            if not link.startswith('https:'):assert (HERE/link).is_file(),link
    for path in HERE.glob('*.npz'):
        with ZipFile(path) as f:assert f.testzip() is None,path.name
    manifest={p.name:sha(p) for p in sorted(HERE.iterdir()) if p.name!='seal.json'}
    if '--seal' in sys.argv:save('seal.json',(json.dumps({'files':manifest},sort_keys=True,indent=2)+'\n').encode())
    assert json.loads((HERE/'seal.json').read_bytes())['files']==manifest
    print('verified',len(manifest),'files, seal',sha(HERE/'seal.json'))
if __name__=='__main__':
    audit()
    if '--seal' in sys.argv or '--verify' in sys.argv:seal()
