from ledger_io import *
from species import LABELS
from scipy.integrate import cumulative_simpson
from scipy.interpolate import make_interp_spline

def rot(vec,sine,cosine):
    x,y=vec
    return np.stack((cosine*x-sine*y,sine*x+cosine*y))

def run(model):
    choice='archived' if '--archived' in sys.argv else 'rebuilt'
    with np.load(HERE/f'geometry-{model}.npz') as f:
        time=f['eta'];kn=f['k'];geom=f['values'];fields=f['keys'].tolist();xb,tb=f['background'].transpose(1,0,2)
    with np.load(pin(f'sources-{model}.npz')) as f:
        bg=dict(zip(f['bg_keys'],f['background']))
        prev=dict(zip(f['names'],f['values'].transpose(0,2,1)))
        comparison=[]
        for index,(key,arr) in enumerate(zip(fields,geom[-1])):
            difference=np.linalg.norm(arr-prev[key])/np.linalg.norm(prev[key])
            comparison.append(dict(source=key,relative=difference,agrees_at_2e_minus13=bool(difference<2e-13)))
            assert difference<.005,key
            if choice=='archived':geom[-1,index]=prev[key]
        table('contraction-'+model+'.csv',comparison)
    xb=np.vstack((xb,bg['X0']));tb=np.vstack((tb,bg['T0']))
    eg=bg['eg'][:,None];h=bg['h'][:,None];freq=kn/np.sqrt(3)
    phase=(time-time[0])[:,None]*freq
    sine=np.sin(phase);cosine=np.cos(phase)
    paths=sorted(HERE.glob(f'state-{model}-*.npz'))
    assert len(paths)==15,len(paths)
    rows=[];channels=[];identities=[]
    for path in paths:
        with np.load(path) as f:
            obs=dict(zip(f['keys'],f['values'].transpose(1,0,2)));assert np.array_equal(time,f['eta'])
        phi,psi,pd=map(obs.get,('phi','psi','phidot'))
        us=[];forcings=[];normal=[];errs=[]
        for idx,name in enumerate(LABELS+['aggregate']):
            if name=='aggregate':
                energy,div,trace,stress=map(obs.get,('gravE','gravJ','trace','shear'))
            else:energy,div,trace,stress=[obs[name+':'+q] for q in ('energy','divJ','D','S')]
            x0=xb[idx,:,None];t0=tb[idx,:,None]
            xq,tq,jq,shift,xf,yf=geom[idx]
            u=np.stack((energy/eg-4*x0*phi+xq,(div/eg-jq)/freq))
            tt=trace/eg-4*t0*phi+tq
            collision=(1 if name=='photon' else -1 if name=='baryon' else 0)
            sx=h*tt-t0*pd+xf+collision*obs['collisionX']
            sy=kn**2*(-tt/3+(4*x0-t0)*(psi+phi)/3-t0*phi+2*(stress/eg+shift)/3)+yf+collision*obs['collisionY']
            drive=np.stack((sx,sy/freq))
            def convolve(thin):
                now=time[::thin];force=rot(drive[:,::thin],-sine[::thin],cosine[::thin])
                integral=cumulative_simpson(force,x=now,axis=1,initial=0)
                return rot(integral,sine[::thin],cosine[::thin])
            particular=convolve(1)
            errs.append(particular[:,::2]-convolve(2))
            defect=u-rot(u[:,0:1],sine,cosine)-particular
            us.append(u);forcings.append(particular)
            normal.append(np.stack((energy/eg,div/eg/freq)))
        us=np.array(us);forcing=np.array(forcings);normal=np.array(normal)
        residual=lambda arr:arr[-1]-arr[:-1].sum(axis=0)
        coord=residual(us);raw=residual(normal);bc=coord-raw;trans=rot(raw[:,0:1],sine,cosine)
        defect=us-rot(us.transpose(1,0,2,3)[:,:,0:1],sine,cosine).transpose(1,0,2,3)-forcing
        readout={'initial residual transported':trans,'coordinate conversion':rot(bc[:,0:1],sine,cosine)-bc,'first-order source mismatch':residual(forcing),'aggregate propagation defect':defect[-1]}
        for idx,name in enumerate(LABELS):readout[name+' balance contribution']=-defect[idx]
        assert np.max(np.abs(raw-sum(readout.values())))<3e-12*np.max(abs(normal))
        totalscale=np.max(abs(normal[-1]),axis=1)
        partscale=np.max(np.sum(abs(normal[:-1]),axis=0),axis=1)
        tmpl=path.stem.removeprefix(f'state-{model}-')
        for i,key in enumerate(('energy','longitudinal current')):
            for p,axis in enumerate(PROBES):
                den=totalscale[i,p];sm=partscale[i,p]
                rows.append(dict(run=tmpl,measure=key,probe=str(axis),initial_over_required_peak=abs(raw[i,0,p])/den,
                            final_over_required_peak=abs(raw[i,-1,p])/den,peak_over_required_peak=max(abs(raw[i,:,p]))/den,
                            peak_over_sum_of_species_scale=max(abs(raw[i,:,p]))/sm,
                            generated_over_required_peak=max(abs((raw-trans)[i,:,p]))/den,final_required_abs=abs(normal[-1,i,-1,p]),
                            quadrature_change_over_required_peak=np.max(abs(np.array(errs)[:,i,:,p]))/den))
                for name,value in readout.items():
                    channels.append(dict(run=tmpl,measure=key,probe=str(axis),source=name,peak_over_required_peak=max(abs(value[i,:,p]))/den,final_over_required_peak=abs(value[i,-1,p])/den,endpoint_real=value[i,-1,p].real,endpoint_imag=value[i,-1,p].imag))
        identities.append(dict(run=tmpl,trace_inventory=np.linalg.norm(obs['trace']-sum(obs[n+':D'] for n in LABELS))/np.linalg.norm(obs['trace']),
                                shear_inventory=np.linalg.norm(obs['shear']-sum(obs[n+':S'] for n in LABELS))/np.linalg.norm(obs['shear']),
                                aggregate_X=np.linalg.norm(us[-1,0]-obs['X'])/np.linalg.norm(obs['X']),aggregate_Y=np.linalg.norm(freq*us[-1,1]-obs['Y'])/np.linalg.norm(obs['Y'])))
        if tmpl in ('0-normal-material-trace-trace-1-0','32-normal-material-trace-trace-1-0','0-normal-original-trace-1-0'):
            pack(f'balance-{choice}-{model}-{tmpl}.npz',eta=time,k=kn,coord=PROBES,names=list(readout),terms=np.array(list(readout.values())),residual=raw,required=normal[-1],species=normal[:-1],particular=forcing,coordinate=us)
    table(f'closure-{choice}-{model}.csv',rows);table(f'origin-{choice}-{model}.csv',channels);table(f'identity-{choice}-{model}.csv',identities)
if __name__=='__main__':run(sys.argv[1])
