from ledger_io import *
from scipy.sparse import csr_matrix
from scipy.special import roots_laguerre,expit
from nu_io import ti

def build(model):
    pin(f'native-{model}.npz');pin(f'sources-{model}.npz')
    data=load_data(model);first=data.first;bg=data.background;t=data.eta
    n=len(data.nodes);s=t[::4];k=data.nodes[:,None]
    mass=json.loads(ti.parent.pin('radiation-background.json').read_bytes())[model]
    linear={};err=[]
    for count,label in [(0,'r'),(12,'m')]:
        nodes,weights=roots_laguerre(count) if count else ([np.inf],[1])
        cur=np.zeros((n,len(s)));density=cur.copy();pressure=cur.copy();shear=cur.copy()
        for idx,q in enumerate(nodes):
            with np.load(verified(f'driver-{model}-q{count}-{idx}.npz')) as f:low=f['low']
            if count:
                a=bg['a'][::4];ep=np.hypot(q,mass['mass_over_temperature']*a)
                wt=weights[idx]*expit(q)**2*q*mass['massless_limit_coeff']/(a*a*(7*np.pi**4/120))
                e=wt*q*q*ep;j=wt*q**3;p=wt*q**4/ep
            else:e=j=p=4*bg['er'][::4]
            cur+=j*low[1]/k;density+=e*low[0];pressure+=p*low[0];shear-=p*low[2]
        for key,val in [('flux',cur),('energy',density),('trace',density-pressure),('S',shear)]:
            linear[label+key]=CubicSpline(s,val,axis=1)(t)
    mapper=Project(data);lists=[]
    for op,kn,p,h,field,metric,phase in mapper.ops:
        def mix(w,left,right):
            mat=csr_matrix((phase*np.broadcast_to(w,p.shape),(field,metric)),shape=(n,n))
            return np.einsum('ij,ij->j',mat@left,right)
        kp=kn*p*h
        phi=first['phi'];values={}
        for name,d,v in [('c','Dcdm','Vcdm'),('b','Db','Vb')]:
            vel=first[v]
            values[name+'KE']=bg['e'+name]*mix(p*p-kp,vel,vel)
            values[name+'Jq']=bg['e'+name]*mix(kp,first[d]+3*phi,vel)
        values['gE']=4*bg['eg']*mix(1,phi,first['Dg']-phi)
        values['gJ']=3*bg['eg']*mix(kp,phi,first['Vg'])
        for name,old in [('r',4*bg['er']*first['Vr']/3),('m',bg['enm']*first['Vm'])]:
            values[name+'J']=-mix(kp,phi,linear[name+'flux'])
            values[name+'Jlegacy']=-mix(kp,phi,old)
        lists.append(values)
    pack('products-'+model+'.npz',eta=t,coord=PROBES,keys=list(lists[0]),values=np.stack([list(x.values()) for x in lists]))
if __name__=='__main__':
    for model in sys.argv[1:] or ('cold','heavy'):build(model)
