from species import Inventory,LABELS
from ledger_io import *

class Prepared(Inventory):
    def __init__(self,model,incident,rule,carrier,route):
        super().__init__(model,incident,rule,route)
        self.carrier=carrier;k=self.kn
        b=dict(zip(self.bkeys,self.back(self.times[0])))
        q=dict(zip(self.names,self.drive(self.times[0])))
        initial=np.zeros_like(self.offset)
        targetF=-b['eg']*(self.xy[1]+q['Jq'])/(2*k*k)
        targetPhi=(q['U']-.5*b['eg']*(self.xy[0]-q['Xq'])+3*b['h']*targetF)/(k*k+2*b['et'])
        comp,_=self.terms(b,q,initial,targetPhi)
        self.targetphi=targetPhi;self.targetF=targetF
        self.de=2*(-k*k*targetPhi+3*b['h']*targetF+q['U'])-comp[:,0].sum(axis=0)
        self.dj=-2*k*k*targetF-comp[:,1].sum(axis=0)
        self.xstart=self.de/b['eg'];self.ystart=self.dj/b['eg']
        ep=np.hypot(self.nodes,self.metas['mass_over_temperature']*b['a'])
        wt=self.weights*self.metas['massless_limit_coeff']/(b['a']**2*(7*np.pi**4/120))
        thermal=(wt*self.nodes**2*ep).sum()/3
        ent=np.array([b['sv']**2,b.get('hv',0.)**2,b['ec'],b['eb'],4*b['eg']/3,4*b['er']/3,thermal])
        self.thermal_background_error=abs(thermal/b['enm']-1)
        self.total_enthalpy_error=abs(ent.sum()/(b['et']+b['pt'])-1)
        self.clock_energy=-3*b['h']*self.dj/k**2
        self.comoving=self.de-self.clock_energy
        self.fractions=np.zeros(7)
        if carrier in ('ghost','static-ghost','anti-ghost'):return
        allowed={'photon':[4],'rel_nu':[5],'common':list(range(7))}[carrier]
        self.fractions[allowed]=ent[allowed]/sum(ent[allowed])
        denom=sum(ent[allowed])
        temp=self.de/(3*denom);velocity=self.dj/(k**2*denom)
        self.shared=(temp,velocity)
        if carrier=='common':
            for field in self.labels:
                self.offset[self.idx[field+'f']]+=b[field+'v']*velocity
                self.offset[self.idx[field+'w']]+=3*b[field+'v']*temp-(b['a']*b[field+'m'])**2*b[field+'b']*velocity
            for field in ('c','b'):
                self.offset[self.idx[field+'d']]+=3*temp
                self.offset[self.idx[field+'t']]+=k**2*velocity
        if 4 in allowed:
            self.offset[self.idx['gx']]+=4*temp
            self.offset[self.idx['gj']]+=4*k**2*velocity/3
        nu=self.offset[self.nu_sl].reshape(self.order+1,self.lmax+1,5)
        if 5 in allowed:
            nu[0,0]+=temp;nu[0,1]+=k*velocity/3
        if 6 in allowed:
            nu[1:,0]+=temp;nu[1:,1]+=k*velocity/(3*(self.nodes/ep)[:,None])
        test,_=self.terms(b,q,initial,targetPhi)
        self.allocation=np.max(abs((test-comp)[:,:2]-self.fractions[:,None,None]*np.stack((self.de,self.dj))[None,:,:]),axis=(0,2))/np.max(abs(np.stack((self.de,self.dj))),axis=1)
        assert max(self.allocation)<2e-10,self.allocation
    def ghost(self,b):
        omega=self.kn/np.sqrt(3);dt=b['clock']-self.times[0]
        theta=omega*dt if self.carrier!='static-ghost' else omega*0
        sign=-1 if self.carrier=='anti-ghost' else 1
        return sign*b['eg']*np.stack((np.cos(theta)*self.xstart-np.sin(theta)*self.ystart/omega,
                      np.cos(theta)*self.ystart+np.sin(theta)*omega*self.xstart))
    def rhs(self,env,state,kind,variant,observe=False):
        if self.carrier not in ('ghost','anti-ghost','static-ghost'):
            result=super().rhs(env,state,kind,variant,observe)
            if observe:
                b,q=env
                result[-1]-=b['opacity']*(self.offset[self.idx['gj']]-4*self.offset[self.idx['bt']]/3)
            return result
        b,q=env;base,jac=self.terms(b,q,state,np.zeros(5,complex))
        en,j=self.ghost(b)
        flux=-(base[:,1].sum(axis=0)+j)/(2*self.kn**2)
        phi=(q['U']-.5*(base[:,0].sum(axis=0)+en)+3*b['h']*flux)/(self.kn**2+.5*jac)
        state=state.copy();state[:2]=[phi,flux]
        return super().rhs(env,state,'trace',variant,observe)

def run(model):
    evidence=[];clocks=[]
    for cells,rule in ((0,'normal'),(32,'normal'),(32,'coordinate')):
        if cells:
            with np.load(verified(f'arriving-{model}-{cells}-main.npz')) as f:incident=f['states']
        else:incident=np.zeros((13,19,5),complex)
        for carrier in ('ghost','static-ghost','anti-ghost','photon','rel_nu','common'):
            for route,step in ([('original',1)] if 'ghost' in carrier else [('material-trace',1),('material-algebraic',1)]+([('material-trace',2)] if carrier=='common' else [])):
                obj=Prepared(model,incident,rule,carrier,route)
                with patch.object(evolve,'guard',guard):result=obj.integrate('trace',sub=step)
                values=result[:,:18];fields=result[:,18:46].reshape(len(values),7,4,5)
                debt=result[:,46:48]-fields[:,:,:2].sum(axis=1)
                pack(f'prepared-{model}-{cells}-{rule}-{carrier}-{route}-{step}.npz',eta=obj.times,k=obj.kn,coord=PROBES,values=values,parts=fields,unassigned=debt)
                if carrier=='common' and route=='material-trace' and step==1:
                    evidence.append(dict(model=model,cells=cells,rule=rule,component_energy_assignment=obj.allocation[0],component_flux_assignment=obj.allocation[1],massive_enthalpy_error=obj.thermal_background_error,total_enthalpy_error=obj.total_enthalpy_error))
                    for i,probe in enumerate(PROBES):
                        complex_row=lambda key,v:{key+'_real':v[i].real,key+'_imag':v[i].imag}
                        clocks.append(dict(model=model,cells=cells,rule=rule,probe=str(probe),clock_remaining_over_density=abs(obj.comoving[i]/obj.de[i]),
                                clock_residual_over_sum_scale=abs(obj.comoving[i])/(abs(obj.de[i])+abs(obj.clock_energy[i])),
                                **complex_row('temperature',obj.shared[0]*evolve.UNIT),**complex_row('velocity_potential_Mpc',obj.shared[1]*evolve.UNIT)))
        print(model,cells,rule,'live carriers completed',flush=True)
    table('thermal-allocation-'+model+'.csv',evidence);table('common-clock-'+model+'.csv',clocks)
if __name__=='__main__':run(sys.argv[1])
