from ledger_io import *
from drivers import Project
from scipy.sparse import csr_matrix
from scipy.special import roots_laguerre,expit
from nu_io import ti
from species import LABELS

def run(model):
    data=load_data(model);bg=data.background;first=data.first;t=data.eta;k=data.nodes[:,None]
    n=len(k);eg=bg['eg'];a=bg['a'];masses=json.loads(ti.parent.pin('radiation-background.json').read_bytes())[model]
    zer=np.zeros_like(first['phi']);zbg=0*a;inputs={}
    for tag in LABELS[:2]:
        if tag not in data.scalars:inputs[tag]=(zbg,zbg,zer,zer,zer,zer);continue
        bb,speed,mass=data.scalars[tag];prod=(a*mass)**2;f=first[tag[0]+'f'];dn=first[tag[0]+'n']
        inputs[tag]=[(speed**2+prod*bb**2)/2,2*prod*bb**2-speed**2,speed*dn+prod*bb*f,-2*speed*dn+4*prod*bb*f,speed*f,zer]
    for name,d,v in [('cdm','Dcdm','Vcdm'),('baryon','Db','Vb')]:
        e0=bg['e'+name[0]];e=e0*(first[d]+3*first['phi']);inputs[name]=(e0,e0,e,e,e0*first[v],zer)
    inputs['photon']=(eg,zbg,eg*first['Dg'],zer,eg*first['Vg'],eg*first['Sg'])
    for count,tag in [(0,'rel_nu'),(12,'massive_nu')]:
        nodes,wts=roots_laguerre(count) if count else ([np.inf],[1]);tot=np.zeros((4,n,len(t[::4])))
        for idx,q in enumerate(nodes):
            with np.load(verified(f'driver-{model}-q{count}-{idx}.npz')) as f:low=f['low']
            if count:
                aq=a[::4];ep=np.hypot(q,masses['mass_over_temperature']*aq)
                w=wts[idx]*expit(q)**2*q*masses['massless_limit_coeff']/(aq**2*(7*np.pi**4/120))
                e=w*q*q*ep;cur=w*q**3;pres=w*q**4/ep
            else:e=cur=pres=4*bg['er'][::4]
            tot+=np.stack((e*low[0],(e-pres)*low[0],cur*low[1]/k,-pres*low[2]))
        e0=bg['enu' if count else 'er'];d0=4*e0-3*bg['enm'] if count else zbg
        inputs[tag]=(e0,d0,*CubicSpline(t[::4],tot,axis=2)(t))
    pp=first['phi'];ps=first['psi'];pd=first['pd'];geom=ps+pp
    out=[];bulks=[];mapr=Project(data)
    for op,kn,p,h,field,metric,phase in mapr.ops:
        kp=kn*p*h;dot=kp-p*p
        def mix(w,one,two):
            mat=csr_matrix((phase*np.broadcast_to(w,p.shape),(field,metric)),shape=(n,n))
            return np.einsum('ij,ij->j',mat@one,two)
        pg=mix(1,pp,pp);g2=pg-mix(1,ps,ps)
        svel=-1.5*((kn*kn-kp)*kp/kn**2-dot/3)
        bulks.append(4*bg['er']*mix(svel,first['Vr'],first['Vr'])/3)
        weights=1.5*(h*h-1/3)
        def sources(e0,d0,e,d,flux,stress):
            x0=e0/eg;t0=d0/eg;en=e/eg;tr=d/eg;fl=flux/eg;ss=stress/eg
            x=en-4*x0*pp;xt=tr-4*t0*pp
            xq=4*x0*pg-4*mix(1,pp,en);tq=4*t0*pg-4*mix(1,pp,tr);jq=3*mix(kp,pp,fl)
            shift=-4*mix(weights,pp,ss)
            xf=-2*t0*mix(1,pp,pd)-mix(1,pd,xt)-2*mix(kp,geom,fl)+mix(p*p,geom,fl)
            yf=(mix(kp,geom,x-xt)/3+kn**2*((4*x0-t0)*g2/3-t0*pg)
                +(mix(kp,4*x-xt,geom)+(4*x0-t0)*mix(kp,geom,geom))/3-mix(kp,xt,pp)-t0*mix(kp,geom,pp)+2*kn**2*mix(weights,geom,ss)/3)
            return np.stack([xq,tq,jq,shift,xf,yf])
        group=[sources(*inputs[tag]) for tag in LABELS]
        group.append(sources(bg['et'],bg['et']-3*bg['pt'],eg*first['E'],eg*first['trace'],eg*first['Vtot'],eg*first['S']))
        out.append(group)
    pack(f'geometry-{model}.npz',eta=t,k=np.array([x[1] for x in mapr.ops]),coord=PROBES,groups=LABELS+['aggregate'],bg_keys=['X0','T0'],
         background=np.stack([np.stack([inputs[tag][0]/eg,inputs[tag][1]/eg]) for tag in LABELS]),bulk=bulks,
         keys=['Xq','Tq','Jq','Sshift','Xforce','Yforce'],values=np.array(out).transpose(1,2,3,0))
if __name__=='__main__':run(sys.argv[1])
