from ledger_io import *

LABELS=['slow','heavy','cdm','baryon','photon','rel_nu','massive_nu']
class Inventory(Matched):
    def __init__(self,model,incident,rule,route,legacy=False):
        super().__init__(model,incident,rule if rule=='normal' else 'coordinate')
        self.route=route;self.legacy=legacy
        with np.load(HERE/f'products-{model}.npz') as f:
            assert np.array_equal(f['coord'],PROBES) and np.array_equal(f['eta'],self.times)
            self.aux_names=list(f['keys'])+['rBulk']
            with np.load(HERE/f'geometry-{model}.npz') as geo:
                self.aux=CubicSpline(self.times,np.concatenate((f['values'],geo['bulk'][:,None,:]),axis=1).transpose(2,1,0)/evolve.UNIT)
    def terms(self,b,q,state,phi):
        z=state+self.offset;get=lambda key:z[self.idx[key]]
        t=dict(zip(self.aux_names,self.aux(b['clock'])))
        eg=b['eg'];k2=self.kn**2
        shape=phi.shape;parts=np.zeros((7,4,*shape),complex);jac=0.
        for i,tag in enumerate(self.labels):
            v=b[tag+'v'];potential=(b['a']*b[tag+'m'])**2*b[tag+'b']*get(tag+'f')
            kinetic=v*get(tag+'w')+3*v*v*phi
            parts[i]=[kinetic+potential+q[tag+'energy'],k2*v*get(tag+'f')+q[tag+'J'],
                    -2*kinetic+4*potential+q[tag+'trace'],q[tag+'shear']]
            jac+=3*v*v
        for i,tag in ((2,'c'),(3,'b')):
            rest=b['e'+tag]*(get(tag+'d')+3*phi)+q[tag+'trace']
            parts[i]=[rest+t[tag+'KE'],b['e'+tag]*get(tag+'t')+t[tag+'Jq'],rest,q[tag+'shear']]
            jac+=3*b['e'+tag]
        parts[4]=[eg*(get('gx')+4*phi)+t['gE'],eg*get('gj')+t['gJ'],0*phi,eg*(q['ph_bulk']-z[self.ph_sl.start])]
        jac+=4*eg
        nu=z[self.nu_sl].reshape(self.order+1,self.lmax+1,-1)
        am=self.metas['mass_over_temperature']*b['a'];ep=np.hypot(self.nodes,am)
        wt=self.weights*self.metas['massless_limit_coeff']/(b['a']**2*(7*np.pi**4/120))
        change='legacy' if self.legacy else ''
        bulk=t['rBulk'];er=4*b['er']
        parts[5]=[er*nu[0,0],er*self.kn*nu[0,1]+t['rJ'+change],0*phi,bulk-er*nu[0,2]]
        parts[6]=[(wt*self.nodes**2*ep)@nu[1:,0],self.kn*((wt*self.nodes**3)@nu[1:,1])+t['mJ'+change],
                  (wt*self.nodes**2*am**2/ep)@nu[1:,0],q['nu_bulk']-bulk-(wt*self.nodes**4/ep)@nu[1:,2]]
        return parts,jac
    def rhs(self,env,state,kind,variant,observe=False):
        b,q=env
        material=self.route=='material-algebraic' or (self.route=='material-trace' and kind=='conserved')
        nextkind=kind
        if material:
            base,jac=self.terms(b,q,state,np.zeros(5,complex))
            flux=-base[:,1].sum(axis=0)/(2*self.kn**2)
            phi=(q['U']-.5*base[:,0].sum(axis=0)+3*b['h']*flux)/(self.kn**2+.5*jac)
            state=state.copy();state[:2]=[phi,flux];nextkind='trace'
        result=super().rhs(env,state,nextkind,variant,observe)
        if not observe:return result
        parts,jac=self.terms(b,q,state,result[0])
        phi,psi,_,flux,pd=result[:5]
        gravE=2*(-self.kn**2*phi+3*b['h']*flux+q['U']);gravJ=-2*self.kn**2*flux
        diff=state[self.idx['gj']]-4*state[self.idx['bt']]/3
        return np.vstack((result,parts.reshape(-1,5),gravE,gravJ,-b['opacity']*q['collision_heat'],-b['opacity']*(diff+q['collision_ph'])))
def run(model):
    for cells,match in [(0,'normal'),(16,'normal'),(16,'coordinate'),(32,'normal'),(32,'coordinate')]:
        if cells:
            with np.load(verified(f'arriving-{model}-{cells}-main.npz')) as f:incoming=f['states']
        else:incoming=np.zeros((13,19,5),complex)
        variants=[('original','trace',1,False)]
        if cells==0 or match=='normal' and cells==32:
            variants += [('material-trace','trace',1,False),('material-algebraic','trace',1,False),('material-trace','trace',2,False),
                         ('material-trace','trace',1,True),('original','conserved',1,False)]
        for route,kind,sub,legacy in variants:
            obj=Inventory(model,incoming,match,route,legacy)
            with patch.object(evolve,'guard',guard):values=obj.integrate(kind,sub=sub)
            keys=evolve.OBS+['M3','E3']+[sp+':'+term for sp in LABELS for term in ('energy','divJ','D','S')]+['gravE','gravJ','collisionX','collisionY']
            assert values.shape==(len(obj.times),len(keys),5)
            if route=='original':
                name=f'matched-{model}-{cells}-{match}-all-{kind}.npz' if cells else f'metric-{model}-12-both-16-1-18-{kind}-1.npz'
                with np.load(verified(name)) as old:assert np.array_equal(values[:,:18],old['values'])
            pack(f'state-{model}-{cells}-{match}-{route}-{kind}-{sub}-{int(legacy)}.npz',eta=obj.times,k=obj.kn,coord=PROBES,keys=keys,values=values)
        print(model,cells,match,flush=True)
if __name__=='__main__':run(sys.argv[1])
