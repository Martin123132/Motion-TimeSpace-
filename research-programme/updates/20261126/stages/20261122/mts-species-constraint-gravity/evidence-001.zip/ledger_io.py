from pathlib import Path
import csv,hashlib,io,json,sys,os
for name in ('OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','OMP_NUM_THREADS','NUMEXPR_NUM_THREADS','BLIS_NUM_THREADS'):os.environ[name]='1'
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
NU=HERE.parent/'mts-collisionless-neutrino-gravity-20261122'
def sha(path):
    with path.open('rb') as fp:return hashlib.file_digest(fp,'sha256').hexdigest()
assert sha(NU/'seal.json')=='4e14dc9103096b2568299da35cf669be8fcc1604ecde40163667342ad4bf7d2f'
files=json.loads((NU/'seal.json').read_bytes())['files']
def verified(name):
    path=NU/name;assert sha(path)==files[name];return path
for name in ('nu_io.py','incident.py','drivers.py','metric.py','match_state.py','assess.py'):verified(name)
sys.path.insert(0,str(NU))
from match_state import Gravity,Matched
from drivers import Project
from nu_io import np,CubicSpline,patch,evolve,load_data,PROBES,pin,guard as inherited_guard
def guard():
    inherited_guard();assert __debug__ and not (HERE/'STOP-REQUESTED').exists()
def save(name,raw):
    guard();path=HERE/name
    if path.exists():assert sha(path)==hashlib.sha256(raw).hexdigest(),name
    else:
        with path.open('xb') as fp:fp.write(raw)
def pack(name,**fields):
    buf=io.BytesIO();np.savez_compressed(buf,**fields);save(name,buf.getvalue())
def table(name,rows):
    buf=io.StringIO();out=csv.DictWriter(buf,rows[0],lineterminator='\n');out.writeheader();out.writerows(rows);save(name,buf.getvalue().encode())
