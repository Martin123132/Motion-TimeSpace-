from ledger_io import *
import prehistory as old
from prehistory import driver,diag,Dummy,tempfile,subprocess
NAMES='tau k a adotoa etak sigma phi grho gpres dgrho dgq'.split()

def native_run(model,func):
    native=diag.native
    status=native.obj(native.source(f'runs/{model}/status.json'))
    bgfile=native.SPEC/'runs/projection/a225-w6-d8.npz' if model=='heavy' else native.NATIVE/'runs/backgrounds/cold.npz'
    native.checked(bgfile,status['source_hash'])
    for file in native.engine.inherited.native_hashes():native.checked(file,status['input_hashes'][str(file)])
    pars=native.engine.inherited.params_for(bgfile,background_boost=8.);pars.DoLateRadTruncation=False
    condition=str(pars.scalar_initial_condition)
    assert condition=='initial_adiabatic',condition
    bg=native.engine.camb.get_background(pars);bg.Params.Accuracy.IntTolBoost=6
    with np.load(pin(f'sources-{model}.npz')) as f:k=f['k'];t=f['eta'];data=dict(zip(f['bg_keys'],f['background']))
    with np.load(verified(f'incident-prehistory-{model}.npz')) as f:times=np.r_[f['eta'][:-1:8],t[::4]]
    with patch.object(diag.symbolic,'compile_sympy_to_camb_source_func',return_value=func):
        for boost in (12,16):
            guard();bank=bg.get_time_evolution(k,times,vars=[Dummy(s) for s in NAMES],lAccuracyBoost=boost)
            raw=dict(zip(NAMES,bank[:,-len(t[::4]):].transpose(2,0,1)))
            assert np.max(abs(raw['k']/k[:,None]-1))<1e-13 and np.max(abs(raw['tau']-t[::4]))<1e-9
            h=raw['adotoa'];alpha=raw['sigma']/k[:,None];en=raw['grho']+raw['gpres']
            phi=raw['etak']/k[:,None]-h*alpha;e=raw['dgrho']-3*h*en*alpha;j=k[:,None]*(raw['dgq']+en*raw['sigma'])
            F=-j/(2*k[:,None]**2)
            linear_constraint=2*(-k[:,None]**2*phi+3*h*F)
            jac=3*(data['ec']+data['eb'])+4*data['eg']+3*(data['sv']**2+data.get('hv',0.)**2)
            pack(f'linear-{model}-{boost}.npz',eta=t[::4],k=k,coord=PROBES,condition=condition,density=e,divJ=j,phi=phi,material_density=e-jac[::4]*phi,hamiltonian=linear_constraint)
if __name__=='__main__':
    if sys.argv[1:2]==['--child']:
        with patch.object(driver,'HERE',HERE),patch.object(driver,'NAMES',NAMES),patch.object(driver,'run',native_run),patch.object(driver,'save',save):driver.main()
    else:
        with tempfile.TemporaryDirectory(dir=HERE,prefix='reader-growing-') as temp:subprocess.run([sys.executable,'-B',str(HERE/'growing_native.py'),'--child',temp,*sys.argv[1:]],check=True)
