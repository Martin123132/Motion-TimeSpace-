from ledger_io import *
def run():
    rng=np.random.default_rng(81043);checks=[]
    for trial in range(24):
        take=lambda *dims:rng.uniform(-.5,.5,size=dims or None)
        phi,phi2,dust1,dust2,gam1,gam2,scalar1,scalar2,norm1,momentum2=take(10)
        velocity1,velocity2,phflux1,phflux2,grad1,grad2,nuflux1,nuflux2=take(8,3)
        eb,eg,background,speed,mass=.71,.56,.84,.37,.91
        can1=norm1-3*phi*speed;xf1=gam1-4*phi
        def exact(eps):
            stretch=np.sqrt(1-2*eps*phi-2*eps**2*phi2)
            n=1+eps*dust1+eps**2*dust2
            momentum=eps*velocity1+eps**2*velocity2
            rel=np.sqrt(1+sum(momentum**2)/stretch**2)
            field=background+eps*scalar1+eps**2*scalar2
            grd=eps*grad1+eps**2*grad2
            deriv=(speed+eps*can1+eps**2*momentum2)/stretch**3
            return np.r_[eb*n*rel/stretch**3,eb*n/stretch**3/rel,eb*n*momentum/stretch**3,
                        eg*(1+eps*xf1+eps**2*gam2)/stretch**4,eg*(eps*phflux1+eps**2*phflux2)/stretch**3,
                        .5*(deriv**2+grd@grd/stretch**2+mass**2*field**2),-deriv*grd,stretch*(eps*nuflux1+eps**2*nuflux2)]
        base=dust2+3*phi2+3*phi*dust1+7.5*phi**2
        theoretical=np.r_[eb*(base+.5*(velocity1@velocity1)),eb*(base-.5*(velocity1@velocity1)),eb*(velocity2+(dust1+3*phi)*velocity1),
                        eg*(gam2+4*phi2+4*phi*(gam1-phi)),eg*(phflux2+3*phi*phflux1),
                        speed*(momentum2+3*phi*can1+(3*phi2+7.5*phi**2)*speed)+mass**2*background*scalar2+.5*(norm1**2+grad1@grad1+mass**2*scalar1**2),
                        -speed*grad2-norm1*grad1,nuflux2-phi*nuflux1]
        def even(e):return (exact(e)+exact(-e)-2*exact(0))/(2*e**2)
        estimate=(4*even(.002)-even(.004))/3
        for label,cols in [('dust',slice(0,5)),('photon',slice(5,9)),('field',slice(9,13)),('neutrino flux',slice(13,16))]:
            rel=np.linalg.norm(estimate[cols]-theoretical[cols])/max(np.linalg.norm(theoretical[cols]),1e-15)
            checks.append(dict(trial=trial,matter=label,unexpanded_relative=rel))
            assert rel<1e-7
    table('unexpanded-material.csv',checks)
if __name__=='__main__':run()
