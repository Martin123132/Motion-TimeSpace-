from ledger_io import *
def calc(model):
    a=[];refinements=[]
    for boost in (12,16):
        with np.load(HERE/f'linear-{model}-{boost}.npz') as f:
            mode=np.stack((f['material_density'][:,0],f['divJ'][:,0]))
            tests=np.linalg.norm(f['hamiltonian']-f['density'],axis=1)/np.linalg.norm(f['density'],axis=1)
            wavenumber=f['k']
            assert str(f['condition'])=='initial_adiabatic'
        if boost==12:baseline=mode
        for p,axis in enumerate(PROBES):
            refinements.append(dict(boost=boost,probe=str(axis),native_linear_constraint=tests[p],density_difference=abs((mode[0,p]-baseline[0,p])/mode[0,p]),flux_difference=abs((mode[1,p]-baseline[1,p])/mode[1,p])))
        for cells,rule in [(0,'normal'),(16,'normal'),(16,'coordinate'),(32,'normal'),(32,'coordinate')]:
            with np.load(HERE/f'state-{model}-{cells}-{rule}-original-trace-1-0.npz') as f:
                arr=f['values'][0];species=arr[18:46].reshape(7,4,5);target=arr[46:48]-species[:,:2].sum(axis=0)
            for p,axis in enumerate(PROBES):
                z=target[:,p]/abs(target[:,p]);vec=mode[:,p]/abs(target[:,p])
                amp=np.vdot(vec,z)/np.vdot(vec,vec)
                residual=z-amp*vec
                sine=abs((z[0]*z[1].conjugate()).imag)
                minimum=np.sqrt((1-abs((z[0]*z[1].conjugate()).real))/2)
                _,sing,_=np.linalg.svd(np.column_stack((z.real,z.imag)));assert abs(minimum-sing[1]/np.sqrt(2))<1e-12
                val=np.linalg.norm(residual)/np.sqrt(2)
                assert val>minimum-1e-12
                a.append(dict(model=model,boost=boost,cells=cells,rule=rule,probe=str(axis),sin_relative_phase=sine,
                              lower_bound_any_real_transfer=minimum,min_native_joint_fraction=val,
                              error_in_flux_when_density_matched=abs(z[1]-z[0]*vec[1]/vec[0]),
                              error_in_density_when_flux_matched=abs(z[0]-z[1]*vec[0]/vec[1]),
                              amplitude_real=amp.real,amplitude_imag=amp.imag,passes_half_percent_rms=bool(val<=.005)))
    table(f'growing-mode-{model}.csv',a);table(f'growing-transfer-controls-{model}.csv',refinements)
if __name__=='__main__':
    for model in ('cold','heavy'):calc(model)
