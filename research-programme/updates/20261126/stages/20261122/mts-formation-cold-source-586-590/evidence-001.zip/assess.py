import csv
import json

from sources import G, HOME, ARMS, SHELLS, SNAPS, original, pin, record, sha, tab, np

REGIONS = ('face1', 'face2', 'face3', 'shell1', 'shell2')
PRIMARY = ('line','cold','anchor','hybrid','cold96','hybrid96')
EXTRA = ('cold48','hybrid48')
LIMIT = .005


def rows(name):
    with (HOME / name).open(newline='') as stream:
        return list(csv.DictReader(stream))


def index(name, keys):
    data = rows(name)
    result = {tuple(row[k] for k in keys): row for row in data}
    assert len(result) == len(data)
    return result


def load_json(name):
    return json.loads((HOME/name).read_bytes())


def analyze():
    freeze = load_json('freeze.json')
    actual = load_json('actual-source.json')
    direct = load_json('direct-check.json')
    pin(HOME/'PROTOCOL.md',freeze['method'])
    pin(HOME/'sources.py', freeze['generator'])
    pin(HOME/'freeze.json', actual['freeze'])
    pin(HOME/'freeze.json', direct['primary_freeze'])
    for snap in SNAPS:
        pin(original(f'{snap}.bar.axi_4.coef_cylsp_DR'), freeze['potentials'][str(snap)])
    with np.load(pin(HOME/'frozen-source.npz',freeze['source_sha256'])) as frozen:
        prob = frozen['prob']
    assert abs(prob.sum()-1) < 1e-9
    with np.load(pin(HOME/'interventions.npz',actual['conditions'])) as bank:
        actual589 = bank['anchor'][3]
        bases = {key:bank[key][3] for key in ('cold','cold96')}
    with np.load(pin(HOME/'direct-sources.npz',direct['source'])) as bank:
        bases['cold48'] = bank['cold48'][3]
    def center(field):
        return field - np.sum(prob*field)/prob.sum()
    def inner(first, second):
        return float(np.sum(prob*center(first)*center(second)))
    overlap = []
    for name, value in bases.items():
        power = inner(actual589,actual589)
        mag = np.sqrt(inner(value,value)/power)
        error = np.sqrt(inner(value-actual589,value-actual589)/power)
        overlap.append(dict(source=name, rms_over_counted=mag,
                            spatial_cosine=inner(value,actual589)/(mag*power),
                            rms_error_over_straight_line=error, improvement_percent=100*(1-error)))
    tab('shape-at-589.csv',overlap)
    flux = {}
    ends = {}
    bound = []
    replay_failures = []
    replay = index('flux-replay.csv',('factor','arm','region'))
    for factor in (1,2,4):
        receipt = load_json(f'run-x{factor}.json')
        assert receipt['conditions']==actual['conditions'] and receipt['protocol']==freeze['method']
        pin(HOME/'propagate.py',receipt['script'])
        ends[factor] = index(f'endpoints-x{factor}.csv', ('arm','source'))
        flux[factor] = index(f'currents-x{factor}.csv', ('arm','source','region'))
        assert len(flux[factor]) == 2*len(PRIMARY)*len(REGIONS)
        for row in rows(f'action-x{factor}.csv'):
            measured, total, external, induced = (float(row[key]) for key in
                    ('measured_angle','action_total_rad','action_external_rad','action_self_rad'))
            assert measured <= total*(1+LIMIT)+1e-13
            assert total <= (external+induced)*(1+1e-9)+1e-13
            if factor==4 and row['source']!='line':
                bound.append(float(row['required_fraction']))
        if factor not in (2,4):
            continue
        rec = load_json(f'direct-run-x{factor}.json')
        pin(HOME/'direct_evolution.py',rec['script'])
        pin(HOME/f'run-x{factor}.json',rec['schedule'])
        assert rec['direct_source']==direct['source']
        for key, row in index(f'direct-currents-x{factor}.csv', ('arm','source','region')).items():
            if key[1]=='anchor':
                difference=float(row['flux_Msun_yr'])-float(flux[factor][key]['flux_Msun_yr'])
                check=replay[str(factor),key[0],key[2]]
                assert difference==float(check['archived_rate_difference'])
                if abs(difference)>=1e-9:
                    replay_failures.append(dict(factor=factor,arm=key[0],region=key[2],difference=difference))
                assert abs(float(check['bilinear_residual']))<1e-9 and float(check['same_state_readout_error'])<1e-9
            else:
                flux[factor][key] = row
        for key, row in index(f'direct-endpoints-x{factor}.csv', ('arm','source')).items():
            if key[1]!='anchor':
                ends[factor][key] = row
    verdicts = []
    convergence = []
    def rate(number, key):
        return float(flux[number][key]['flux_Msun_yr'])
    for arm in ARMS:
        for name in PRIMARY+EXTRA:
            low,high = ends[2][arm,name],ends[4][arm,name]
            closer = float(high['distance_forward']) < float(high['distance_reverse'])
            norm = float(high['max_occupation_drift'])
            assert norm < 1e-9 and float(high['max_energy_work_error_kms2'])<.0003
            if name!='line':
                column='distance_from_line' if name in EXTRA else 'angle_from_matched_line'
                change=abs(float(low[column])/float(high[column])-1)
                convergence.append(dict(arm=arm,source=name,quantity=column,relative=change,passes=change<LIMIT))
            matching = []
            for region in REGIONS:
                key = (arm,name,region)
                fine = rate(4,key)
                target = float(flux[4][key]['frozen_forward_Msun_yr'])
                matching.append('F' if fine*target>0 else 'R' if fine*target<0 else '0')
                base = (arm,'line',region)
                if name!='line':
                    delta = fine-rate(4,base)
                    error = abs((rate(2,key)-rate(2,base))-delta)/abs(delta) if delta else float('inf')
                    convergence.append(dict(arm=arm,source=name,quantity=region+'_contrast_to_line',
                                            relative=error,passes=error<LIMIT))
                if region=='shell2':
                    outer = fine
            verdicts.append(dict(arm=arm,source=name,closer_state='forward' if closer else 'reverse',
                    face_and_shell_signs=''.join(matching),outer_shell_Msun_yr=outer,
                    distance_forward=float(high['distance_forward']), distance_reverse=float(high['distance_reverse'])))
    assert len(convergence)==84
    tab('time-refinement.csv',convergence)
    tab('state-and-current-verdicts.csv',verdicts)
    jerks = []
    units_to_si = 1e6 / 3.085677581491367e19 / 31557600
    for name in PRIMARY+EXTRA:
        for idx, region in enumerate(('shell1','shell2')):
            inner, outer = SHELLS[idx:idx+2]
            difference = {}
            for factor in (2,4):
                difference[factor] = rate(factor,('coupled',name,region))-rate(factor,('reset',name,region))
                for arm in ARMS:
                    a = rate(factor,(arm,name,f'face{idx+1}'))
                    b = rate(factor,(arm,name,f'face{idx+2}'))
                    assert abs(rate(factor,(arm,name,region))-(b-a))<1e-12
                    exterior = G*b/outer**2
                    interior = (inner/outer)**2 * G*a/inner**2
                    assert abs((exterior-interior)-G*(b-a)/outer**2)<1e-20
            ref = rate(4,('coupled','line',region))-rate(4,('reset','line',region))
            jerks.append(dict(source=name,shell=region,r_inner_kpc=inner,r_outer_kpc=outer,
                reset_wave_jerk_m_s3=G*rate(4,('reset',name,region))/outer**2*units_to_si,
                inherited_wave_jerk_m_s3=G*rate(4,('coupled',name,region))/outer**2*units_to_si,
                inherited_minus_reset_Msun_yr=difference[4],
                paired_newtonian_jerk_m_s3=G*difference[4]/outer**2*units_to_si,
                source_shift_from_line_fraction=difference[4]/ref-1,
                numerical_refinement_fraction=abs(difference[2]/difference[4]-1)))
    tab('newtonian-shell-jerk.csv',jerks)
    group = rows('direct-quadrature.csv')
    crit = [float(row['q24_change_relative']) for row in group if row['q']=='48']
    assert len(crit)==3 and max(crit)<LIMIT
    assert min(float(row[key]) for row in group for key in ('min_proxy_Msun','min_hybrid_Msun'))>0
    failed = [row for row in convergence if not row['passes']]
    result = dict(time_comparisons=len(convergence), time_failures=failed,
        exact_rate_replay_failures=replay_failures,
        max_time_relative=max(row['relative'] for row in convergence), sign_cases=len(verdicts),
        worst_direct_quadrature_relative=max(crit), analytic_relative=direct['analytic_relative'],
        max_required_action_fraction_original_variants=max(bound),
        max_occupation_drift=max(float(row['max_occupation_drift']) for row in ends[4].values()),
        max_energy_work_error_kms2=max(float(row['max_energy_work_error_kms2']) for row in ends[4].values()))
    record('verdict.json',result)
    print(json.dumps(result),flush=True)
    if (HOME/'RESULTS.md').is_file():
        files = {path.name:sha(path) for path in sorted(HOME.iterdir()) if path.is_file() and path.name!='seal.json'}
        record('seal.json',files)
        print('Sealed',len(files),'files:',sha(HOME/'seal.json'))


if __name__=='__main__':
    analyze()
