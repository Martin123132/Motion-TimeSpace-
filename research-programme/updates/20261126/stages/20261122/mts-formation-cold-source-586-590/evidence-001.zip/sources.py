import os
import sys
for key in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','BLIS_NUM_THREADS'):
    os.environ[key]='1'
sys.dont_write_bytecode=True
import csv
import hashlib
import io
import json
from pathlib import Path
import numpy as np
from numpy.polynomial.legendre import legvander
from scipy.special import roots_legendre,eval_legendre
from scipy.interpolate import RectBivariateSpline

HOME=Path(__file__).resolve().parent
ROOT=HOME.parent
LAST=ROOT/'mts-flow-formation-inverse-586-20261122'
BASE=ROOT/'mts-fire-joint-baryon-history-20261120'
PART=ROOT/'mts-fire-current-moment-20261121'
G=4.30091727003628e-6
SNAPS=tuple(range(586,591))

def sha(path):
    with path.open('rb') as handle:return hashlib.file_digest(handle,'sha256').hexdigest()

def pin(path,digest):
    if sha(path)!=digest:raise ValueError(f'changed source: {path}')
    return path

def manifest(folder,digest):
    value=json.loads(pin(folder/'seal.json',digest).read_bytes())
    return value.get('files',value)

old=manifest(BASE,'19c78eaa158a766bd409c0a64504788b1346542eccee37c004083a918c480d67')
prev=manifest(LAST,'4ae215216dac834ea5d8ae503fea680707af22348044627efb0b507a7c398fcb')
pin(LAST/'inverse.py',prev['inverse.py'])
sys.path.insert(0,str(LAST))
from inverse import setup as parent_setup,chord,ARMS,SHELLS

def keep(name,data):
    path=HOME/name
    if path.exists():
        if path.read_bytes()!=data:raise ValueError(f'conflicting result: {name}')
    else:
        with path.open('xb') as handle:handle.write(data)

def record(name,value):
    keep(name,(json.dumps(value,indent=2,sort_keys=True,allow_nan=False)+'\n').encode())

def packet(name,**arrays):
    buffer=io.BytesIO();np.savez_compressed(buffer,**arrays);keep(name,buffer.getvalue())

def tab(name,rows):
    buf=io.StringIO();writer=csv.DictWriter(buf,fieldnames=rows[0],lineterminator='\n')
    writer.writeheader();writer.writerows(rows);keep(name,buf.getvalue().encode())

def original(name):
    return pin(BASE/name,old[name])

def clock():
    times=np.loadtxt(original('snapshot_times.txt'))
    return np.array([times[times[:,0]==snap,3].item()*1000 for snap in SNAPS])

def geom(jf):
    redges=np.r_[[jf.EDGES[np.argmin(abs(jf.EDGES-cut))] for cut in (0,.5,1,2,3,4,6,8,10,14,20,25,30)],500.]
    muedges=np.array([0,1/32,1/16,1/8,1/4,1/2,3/4,1])
    labels=jf.groups(False)
    assert np.array_equal(labels,((np.searchsorted(redges,jf.RC,side='right')-1)[:,None]*7+
                          np.searchsorted(muedges,jf.UC,side='right')-1))
    return redges,muedges,labels

def projected_mass(edges,mu_edges,degrees,tilt,coeff,q,radial_breaks):
    poly=legvander(mu_edges,degrees[-1]+1)
    windows=np.diff(mu_edges)[:,None]*np.ones((1,len(degrees)))
    windows[:,1:]=np.diff(poly[:,degrees[1:]+1]-poly[:,degrees[1:]-1],axis=0)/(2*degrees[1:]+1)
    rot=eval_legendre(degrees,tilt)
    nonzero=edges[1:]
    face=np.zeros((len(edges),len(degrees)))
    face[1:]=nonzero[:,None]**2*coeff(nonzero,True)
    bounds=np.unique(np.r_[edges,radial_breaks[(radial_breaks>0)&(radial_breaks<edges[-1])]])
    nodes,weights=roots_legendre(q);half=np.diff(bounds)/2
    radii=bounds[:-1,None]+half[:,None]*(1+nodes)
    vals=coeff(radii.ravel(),False).reshape(len(half),q,len(degrees))
    integ=np.add.reduceat(half[:,None]*np.einsum('i,jik->jk',weights,vals),np.searchsorted(bounds,edges[:-1]),axis=0)
    moments=(np.diff(face,axis=0)-degrees*(degrees+1)*integ)*rot/G
    return moments@windows.T

def analytic(edges,mu):
    deg=np.array([0,2]);tilt=.71
    def coeff(x,deriv):
        return np.column_stack((x if deriv else x**2/2,4*x**3 if deriv else x**4))
    calc=projected_mass(edges,mu,deg,tilt,coeff,12,np.array([]))
    iz=np.diff((mu**3-mu)/2)
    expected=(np.diff(edges**3)[:,None]*np.diff(mu)+14/5*np.diff(edges**5)[:,None]*eval_legendre(2,tilt)*iz)/G
    err=np.linalg.norm(calc-expected)/np.linalg.norm(expected);assert err<1e-11
    return err

def orientation(snap):
    lines=original(f'{snap}_coords_DR.txt').read_text().splitlines()
    values=np.fromstring(' '.join(row for row in lines if not row.startswith('#')),sep=' ')
    axis=values[8:].reshape(3,3)[-1];return axis/np.linalg.norm(axis)

def cold(snap,edges,mu_edges,cap,q):
    contents=original(f'{snap}.bar.axi_4.coef_cylsp_DR').read_text().splitlines()
    assert 'symmetry=Axisymmetric' in contents
    at=next(i for i,row in enumerate(contents) if row.startswith('#R('))
    z=np.array(contents[at].split()[1:],float)
    grid=np.loadtxt(contents[at+1:at+26]);rad=grid[:,0];values=grid[:,1:]
    assert min(rad[-1],z[-1])>=edges[-1] and rad[0]==0 and z[0]==0
    spline=RectBivariateSpline(np.log1p(rad),np.log1p(z),values,s=0)
    deg=np.arange(0,cap+1,2)
    mu,weight=roots_legendre(q);mu=(mu+1)/2;weight/=2
    sine=np.sqrt(1-mu**2)
    harmonics=legvander(mu,cap)[:,::2]*((2*deg+1)[None,:]*weight[:,None])
    def coeff(radii,deriv):
        plane=radii[:,None]*sine;height=radii[:,None]*mu
        ab=(np.log1p(plane),np.log1p(height))
        if deriv:sample=spline.ev(*ab,dx=1)*sine/(1+plane)+spline.ev(*ab,dy=1)*mu/(1+height)
        else:sample=spline.ev(*ab)
        return sample@harmonics
    cosine=abs(orientation(snap)@orientation(600))
    return projected_mass(edges,mu_edges,deg,min(cosine,1.),coeff,16 if q==120 else 24,rad)

def prepare(actual=False):
    lab,*_=parent_setup();obj=lab.obj;bg=obj.bg
    import joint_field as jf
    edges,mu_edges,labels=geom(jf)
    endhist=jf.merged(600)[0][:,0].sum(axis=0)
    den=np.bincount(labels.ravel(),weights=endhist.ravel(),minlength=91)
    assert den.min()>0
    with np.load(original('mw-positive-aperture.npz')) as bank:local=bank['high']
    harm=legvander(bg.mu,64)[:,::2]
    def transfer(delta):
        field=jf.coeffs(local*(delta/den)[labels],bg.rad*bg.length,64)@harm.T
        return field/bg.vel**2
    prob=abs(obj.sky(obj.ground))**2*bg.sqrt[:,None]**2*bg.aw/obj.number
    assert abs(prob.sum()-1)<1e-9
    def center(field):return field-np.sum(prob*field)
    def rms(field):return np.sqrt(np.sum(prob*center(field)**2))*bg.vel**2
    ages=clock();fraction=(ages-ages[0])/(ages[-1]-ages[0])
    fields=np.array([lab.run.fields[586],lab.run.fields[590]])
    line=(1-fraction[:,None,None])*fields[0]+fraction[:,None,None]*fields[1]
    def grouped(snap):
        for piece in range(4):
            for suffix in ('npz','json'):original(f'mass-{snap}-{piece}.{suffix}')
        density=jf.merged(snap)[0][:,0].sum(axis=0)
        return np.bincount(labels.ravel(),weights=density.ravel(),minlength=91)
    endpoint=np.array([grouped(586),grouped(590)])
    group_line=(1-fraction[:,None])*endpoint[0]+fraction[:,None]*endpoint[1]
    for index in (0,1):
        ref=fields[index]
        assert np.max(abs(transfer(endpoint[index]-den)-ref))/np.max(abs(ref))<1e-9
    if not actual:
        packages={};checks=[];grad=analytic(edges,mu_edges)
        for cap,q in ((64,120),(64,192),(96,192)):
            bank=np.array([cold(snap,edges,mu_edges,cap,q).ravel() for snap in SNAPS])
            diff=bank-((1-fraction[:,None])*bank[0]+fraction[:,None]*bank[-1])
            details=np.array([center(transfer(row)) for row in diff])
            assert not np.any(details[[0,-1]])
            for idx in range(1,4):
                checks.append(dict(cap=cap,nodes=q,snap=SNAPS[idx],centered_drive_rms_kms2=rms(details[idx]),
                          min_reconstructed_group_Msun=(group_line[idx]+diff[idx]).min(),
                          negative_groups=int(((group_line[idx]+diff[idx])<0).sum())))
            packages[f'cold_{cap}_{q}']=details
        packet('frozen-source.npz',ages=ages,line=line,prob=prob,**packages)
        tab('cold-groups.csv',checks)
        record('freeze.json',dict(source_sha256=sha(HOME/'frozen-source.npz'),method=sha(HOME/'PROTOCOL.md'),
                     generator=sha(HOME/'sources.py'),analytic_gauss_relative=grad,
                     potentials={str(s):sha(original(f'{s}.bar.axi_4.coef_cylsp_DR')) for s in SNAPS}))
        return
    meta=json.loads((HOME/'freeze.json').read_bytes())
    assert meta['method']==sha(HOME/'PROTOCOL.md') and meta['generator']==sha(HOME/'sources.py')
    with np.load(pin(HOME/'frozen-source.npz',meta['source_sha256'])) as pack:
        cold_detail=pack['cold_64_192'];high=pack['cold_96_192'];low=pack['cold_64_120']
        assert np.array_equal(line,pack['line'])
    receipts=manifest(PART,'e4b2446f5c018c3de8cb3b4175ff68d581dd984ffe87a56d62219e5d2cadd1d8')
    particle={};provenance={}
    for snap in (589,590):
        masses=np.zeros(91)
        for piece in range(4):
            for species in (0,4):
                stem=f'inputs/s{snap}-{piece}-p{species}'
                receipt=json.loads(pin(PART/(stem+'.json'),receipts[stem+'.json']).read_bytes())
                provenance[stem]=receipt['packet_sha256']
                assert receipt['snap']==snap and receipt['species']==species and receipt['piece']==piece
                with np.load(pin(PART/(stem+'.npz'),receipt['packet_sha256'])) as pkt:masses+=pkt['group_mass_Msun']
        particle[snap]=masses
    rep_check=np.max(abs(particle[590]-endpoint[1])/endpoint[1])
    assert rep_check<1e-9
    delta=center(transfer(particle[589]-group_line[3]))
    actual_only=np.array([delta*min((age-ages[0])/(ages[3]-ages[0]),(ages[-1]-age)/(ages[-1]-ages[3])) for age in ages])
    def blended(corr):
        reanchor=np.array([corr[3]*min((age-ages[0])/(ages[3]-ages[0]),(ages[-1]-age)/(ages[-1]-ages[3])) for age in ages])
        return actual_only+corr-reanchor
    errors=[]
    for name,test in [('linear',0.*delta),('cold',cold_detail[3]),('higher_harmonics',high[3])]:
        diff=test-delta;projected=obj.multiply(diff,obj.ground)
        projected-=obj.ground*np.vdot(obj.ground,projected).real/obj.number
        errors.append(dict(candidate=name,snapshot=589,error_RMS_kms2=rms(diff),
                           projected_error_kms2=np.linalg.norm(projected)/np.sqrt(obj.number)*bg.vel**2))
    validation=[]
    for idx in range(1,4):
        validation.append(dict(snap=SNAPS[idx],quadrature_relative=rms(low[idx]-cold_detail[idx])/rms(cold_detail[idx]),
                       angular_representation_relative=rms(high[idx]-cold_detail[idx])/rms(cold_detail[idx])))
    for detail in (cold_detail,actual_only,blended(cold_detail),blended(high)):
        assert np.max(abs(detail[[0,-1]]))<1e-12
    assert np.max(abs(blended(cold_detail)[3]-delta))<1e-12
    tab('589-source-comparison.csv',errors);tab('source-refinement.csv',validation)
    packet('interventions.npz',ages=ages,line=line,cold=cold_detail,anchor=actual_only,hybrid=blended(cold_detail),
           hybrid96=blended(high),cold96=high)
    record('actual-source.json',dict(source_hashes=provenance,endpoint_group_error=rep_check,freeze=sha(HOME/'freeze.json'),
                                   conditions=sha(HOME/'interventions.npz')))
if __name__=='__main__':prepare(actual=sys.argv[1:] == ['actual'])
