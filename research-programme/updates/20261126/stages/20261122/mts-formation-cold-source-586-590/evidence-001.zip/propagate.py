import sys
import numpy as np
from sources import HOME,LAST,ARMS,SHELLS,prev,pin,sha,tab,record,packet,parent_setup,chord,G
import json
import csv
from scipy.special import roots_legendre

def make_readout(lab,shape):
    bg=lab.obj.bg;el=lab.run.el
    faces=SHELLS/bg.length
    edges=np.unique(np.r_[0.,el.right,faces]);nodes,weight=roots_legendre(16)
    radii=(edges[:-1,None]+np.diff(edges)[:,None]*(nodes+1)/2).ravel()
    w=(np.diff(edges)[:,None]*weight/2).ravel()
    def base(points):
        idx=np.searchsorted(el.right,points)
        value,slope=shape(el.knots,(points-el.left[idx])/el.width[idx])
        return idx,value,slope/el.width[idx,None]
    idx,interp,_=base(radii);fidx,fi,fd=base(faces)
    def read(state):
        values=el.nodes(state)
        one=np.einsum('ti,til->tl',interp,values[idx])
        mass=lab.mesh.mscale*w*np.sum(abs(one)**2,axis=1)
        field=np.einsum('ti,til->tl',fi,values[fidx])
        deriv=np.einsum('ti,til->tl',fd,values[fidx])
        rate= -lab.mesh.mscale/(lab.obj.unit_myr*1e6)*np.sum((field.conj()*deriv).imag,axis=1)
        return np.array([mass[radii<face].sum() for face in faces]),rate
    return read

def evolve(factor):
    assert factor in (1,2,4,8)
    lab,Evolution,advance,guard,shape=parent_setup()
    obj=lab.obj;run=lab.run;read=make_readout(lab,shape)
    meta=json.loads((HOME/'actual-source.json').read_bytes())
    with np.load(pin(HOME/'interventions.npz',meta['conditions'])) as bank:
        ages=bank['ages'];line=bank['line']
        drives={'line':line,**{key:line+bank[key] for key in ('cold','anchor','hybrid','cold96','hybrid96')}}
    keys=list(drives)
    duration=ages[-1]-ages[0];native=run.interval(586,590)[0]
    counts=np.maximum(1,np.rint(np.diff(ages)/duration*native).astype(int))*factor
    summary=[];currents=[];action=[];archive={};shell_indices=('face1','face2','face3','shell1','shell2')
    angle=lambda x,y:2*np.arcsin(chord(x,y)/2)
    def variance(field,state):
        unit=state/np.linalg.norm(state)
        change=obj.multiply(field,unit)
        return np.linalg.norm(change-unit*np.vdot(unit,change))
    def expect(field,state):return np.vdot(state,obj.multiply(field,state)).real
    with pin(LAST/'shells-280.csv',prev['shells-280.csv']).open() as stream:authority=list(csv.DictReader(stream))
    for arm in ARMS:
        initial=run.reference[586] if arm=='reset' else lab.raw[586]
        turn=lab.initial[arm];reverse=turn.conj()
        actual_mass,frozen=read(turn)
        ref=[row for row in authority if row['epoch']=='590' and row['arm']==arm and row['flow']=='forward']
        assert np.max(abs(frozen-np.array([float(row['influx_Msun_yr']) for row in ref])))<1e-9
        target=np.r_[frozen,np.diff(frozen)]
        states={key:initial.copy() for key in keys};mom={key:obj.moment(initial) for key in keys}
        work=dict.fromkeys(keys,0.);length={key:np.zeros(3) for key in keys}
        drift=dict.fromkeys(keys,0.);worst_gap=dict.fromkeys(keys,0.)
        scale=obj.bg.vel**2/obj.number
        def energy(state,field):return scale*(obj.energy(state)+expect(field,state))
        initial_energy=energy(initial,line[0])
        for segment,count in enumerate(counts):
            dt=(ages[segment+1]-ages[segment])/(count*obj.unit_myr)
            solver=Evolution(obj,dt,initial)
            diff={key:drives[key][segment+1]-drives[key][segment] for key in keys}
            oldexpect={key:expect(diff[key],states[key]) for key in keys}
            for tick in range(count):
                if tick%16==0:guard()
                for key in keys:
                    ext=drives[key][segment]+(tick+.5)/count*diff[key]
                    states[key],mom[key],mid,phi=advance(obj,solver,states[key],mom[key],ext,dt)
                    if key=='line':base_ext=ext;base_phi=phi
                    else:
                        external=ext-base_ext;induced=phi-base_phi
                        length[key]+=dt*np.array([variance(external+induced,mid),variance(external,mid),variance(induced,mid)])
                    now=expect(diff[key],states[key])
                    work[key]+=.5*(oldexpect[key]+now)/count*scale
                    oldexpect[key]=now
                    drift[key]=max(drift[key],abs(np.vdot(states[key],states[key]).real/obj.number-1))
            for key in keys:
                defect=energy(states[key],drives[key][segment+1])-initial_energy-work[key]
                worst_gap[key]=max(worst_gap[key],abs(defect))
            print(factor,arm,'through',587+segment,flush=True)
        for key,state in states.items():
            forward_angle=angle(state,turn);reverse_angle=angle(state,reverse)
            measured=angle(state,states['line']);required=angle(states['line'],reverse)
            gain=length[key]
            assert drift[key]<1e-9 and worst_gap[key]<.0003,(key,drift[key],worst_gap[key])
            archive[arm+'_'+key]=state
            summary.append(dict(arm=arm,source=key,steps=int(sum(counts)),distance_forward=chord(state,turn),
                     distance_reverse=chord(state,reverse),angle_from_matched_line=measured,
                     closer_target='forward' if forward_angle<reverse_angle else 'reverse',
                     fraction_gap_from_line=measured/required,max_occupation_drift=drift[key],
                     work_kms2=work[key],max_energy_work_error_kms2=worst_gap[key]))
            action.append(dict(arm=arm,source=key,measured_angle=measured,target_angle_from_line=required,
                     action_total_rad=gain[0],action_external_rad=gain[1],action_self_rad=gain[2],
                     required_fraction=gain[0]/required,angular_slack=gain[0]-measured,
                     time_mean_total_kms2=gain[0]*obj.unit_myr*obj.bg.vel**2/duration))
            mass,flow=read(state)
            got=np.r_[flow,np.diff(flow)]
            for loc,region in enumerate(shell_indices):
                currents.append(dict(arm=arm,source=key,region=region,flux_Msun_yr=got[loc],
                    frozen_forward_Msun_yr=target[loc],frozen_reverse_Msun_yr=-target[loc],
                    closer_flux='forward' if got[loc]*target[loc]>0 else 'reverse' if got[loc]*target[loc]<0 else 'tie',
                    mass_Msun=np.r_[mass,np.diff(mass)][loc],frozen_mass_Msun=np.r_[actual_mass,np.diff(actual_mass)][loc]))
    packet(f'final-states-x{factor}.npz',**archive);tab(f'endpoints-x{factor}.csv',summary)
    tab(f'currents-x{factor}.csv',currents);tab(f'action-x{factor}.csv',action)
    record(f'run-x{factor}.json',dict(interval_steps=counts.tolist(),conditions=meta['conditions'],script=sha(HOME/'propagate.py'),
                                       protocol=sha(HOME/'PROTOCOL.md')))
if __name__=='__main__':evolve(int(sys.argv[1]))
