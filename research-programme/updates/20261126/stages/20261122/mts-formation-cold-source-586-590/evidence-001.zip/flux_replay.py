import csv

from sources import ARMS, HOME, SHELLS, chord, np, parent_setup, tab
from propagate import make_readout


def run():
    lab, _, _, _, shape = parent_setup()
    read = make_readout(lab,shape)
    rad = SHELLS/lab.obj.bg.length
    mesh = lab.run.el
    idx = np.searchsorted(mesh.right, rad)
    interp, slope = shape(mesh.knots,(rad-mesh.left[idx])/mesh.width[idx])
    slope = slope/mesh.width[idx,None]
    scale = -lab.mesh.mscale/(lab.obj.unit_myr*1e6)
    def surface(state):
        nodes=mesh.nodes(state)[idx]
        return np.einsum('ti,til->tl',interp,nodes),np.einsum('ti,til->tl',slope,nodes)
    def signed(state):
        _, rate = read(state)
        return np.r_[rate,np.diff(rate)]
    def rates(name):
        with (HOME/name).open(newline='') as stream:
            return {(row['arm'],row['region']):float(row['flux_Msun_yr']) for row in csv.DictReader(stream) if row['source']=='anchor'}
    records=[]
    for factor in (2,4):
        first=rates(f'currents-x{factor}.csv')
        second=rates(f'direct-currents-x{factor}.csv')
        with np.load(HOME/f'final-states-x{factor}.npz') as primary,np.load(HOME/f'direct-states-x{factor}.npz') as direct:
            for arm in ARMS:
                old=primary[arm+'_anchor']
                new=direct[arm+'_anchor']
                distance=chord(old,new)
                assert distance < 1e-12
                mean,mean_slope=surface((new+old)*.5)
                delta,delta_slope=surface(new-old)
                cross=scale*np.sum((mean.conj()*delta_slope+delta.conj()*mean_slope).imag,axis=1)
                check=np.r_[cross,np.diff(cross)]
                calc_old,calc_new=signed(old),signed(new)
                for index,region in enumerate(('face1','face2','face3','shell1','shell2')):
                    previous=first[arm,region]
                    repeat=second[arm,region]
                    difference=repeat-previous
                    residual=difference-check[index]
                    same_state=max(abs(calc_old[index]-previous),abs(calc_new[index]-repeat))
                    records.append(dict(factor=factor,arm=arm,region=region,
                        phase_free_state_difference=distance,archived_rate_difference=difference,
                        passes_exact_replay=abs(difference)<1e-9,bilinear_rate_difference=check[index],
                        bilinear_residual=residual,same_state_readout_error=same_state))
    tab('flux-replay.csv',records)
    for key in ('phase_free_state_difference','archived_rate_difference','bilinear_residual','same_state_readout_error'):
        print(key,max(abs(row[key]) for row in records))
    assert max(abs(row['bilinear_residual']) for row in records)<1e-9
    assert max(row['same_state_readout_error'] for row in records)<1e-9


if __name__=='__main__':
    run()
