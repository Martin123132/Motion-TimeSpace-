from sources import HOME,PART,SNAPS,G,pin,original,orientation,geom,parent_setup,clock,record,packet,sha,tab,np,legvander,RectBivariateSpline,roots_legendre
import json

def solid_groups(edges,mu_edges,cosine,q,gradient,radial_breaks):
    sine=np.sqrt(max(0.,1-cosine*cosine))
    nodes,weights=roots_legendre(q)
    def rule(bounds):
        half=np.diff(bounds)*.5
        return (bounds[:-1,None]+half[:,None]*(1+nodes)).ravel(),(half[:,None]*weights).ravel()
    def local(radius,mu,conical):
        radius,mu=np.broadcast_arrays(radius,mu)
        radius=radius.ravel();mu=mu.ravel()
        horizontal=np.sqrt(np.maximum(0.,1-mu**2))
        shift=cosine*mu;spread=sine*horizontal
        coscut=np.clip(np.divide(-shift,spread,out=np.full_like(shift,-1),where=spread>0),-1,1)
        stop=np.arccos(coscut)
        avg=np.zeros_like(radius)
        for lower,upper in [(np.zeros_like(stop),stop),(stop,np.full_like(stop,np.pi))]:
            half=(upper-lower)[:,None]/2
            cosphi=np.cos(lower[:,None]+half*(1+nodes))
            intrinsic=np.clip(shift[:,None]+spread[:,None]*cosphi,-1,1)
            sint=np.sqrt(np.maximum(0.,1-intrinsic**2))
            radial,zgrad=gradient(radius[:,None]*sint,radius[:,None]*abs(intrinsic))
            if conical:
                part=radius[:,None]*(-radial*np.divide(intrinsic,sint,out=np.zeros_like(sint),where=sint>0)+zgrad*np.sign(intrinsic))
                part*=cosine*horizontal[:,None]**2-sine*mu[:,None]*horizontal[:,None]*cosphi
            else:part=radial*sint+zgrad*abs(intrinsic)
            avg+=np.sum(half*weights*part/np.pi,axis=1)
        return avg
    faces=np.zeros((len(edges),7));cones=np.zeros((len(edges)-1,len(mu_edges)))
    for lo,(low,high) in enumerate(zip(mu_edges[:-1],mu_edges[1:])):
        split=np.unique(np.r_[low,[x for x in (sine,cosine) if low<x<high],high])
        mu,rule_mu=rule(split)
        radii=edges[1:]
        faces[1:,lo]=radii**2*(local(radii[:,None],mu[None,:],False).reshape(len(radii),len(mu))@rule_mu)
    for idx,(low,high) in enumerate(zip(edges[:-1],edges[1:])):
        knots=np.unique(np.r_[low,radial_breaks[(radial_breaks>low)&(radial_breaks<high)],high])
        radii,rule_r=rule(knots)
        cones[idx,1:-1]=rule_r@local(radii[:,None],mu_edges[None,1:-1],True).reshape(len(radii),-1)
    return (np.diff(faces,axis=0)+np.diff(cones,axis=1))/G

def build():
    lab,*_=parent_setup();obj=lab.obj;bg=obj.bg
    import joint_field as jf
    edges,mus,labels=geom(jf);ages=clock()
    frac=(ages-ages[0])/(ages[-1]-ages[0])
    def manufactured(r,z):
        return r+r*(z*z-2*r*r),z+z*(4*z*z+r*r)
    tilt=.993
    truth=(np.diff(edges**3)[:,None]*np.diff(mus)+14/5*np.diff(edges**5)[:,None]*((3*tilt**2-1)/2)*np.diff((mus**3-mus)/2))/G
    defect=np.linalg.norm(solid_groups(edges,mus,tilt,32,manufactured,edges)-truth)/np.linalg.norm(truth)
    assert defect<1e-10,defect
    endhist=jf.merged(600)[0][:,0].sum(axis=0)
    den=np.bincount(labels.ravel(),weights=endhist.ravel(),minlength=91)
    with np.load(original('mw-positive-aperture.npz')) as bank:local=bank['high']
    harm=legvander(bg.mu,64)[:,::2]
    freeze=json.loads((HOME/'freeze.json').read_bytes())
    receipt=json.loads((HOME/'actual-source.json').read_bytes())
    with np.load(pin(HOME/'frozen-source.npz',freeze['source_sha256'])) as frozen:
        prob=frozen['prob'];cap64=frozen['cold_64_192']
    with np.load(pin(HOME/'interventions.npz',receipt['conditions'])) as fixed:
        anchor=fixed['anchor']
    endpoint=[]
    for snap in (586,590):
        hist=jf.merged(snap)[0][:,0].sum(axis=0)
        endpoint.append(np.bincount(labels.ravel(),weights=hist.ravel(),minlength=91))
    group_line=(1-frac[:,None])*endpoint[0]+frac[:,None]*endpoint[1]
    counts=np.zeros(91)
    for name,digest in receipt['source_hashes'].items():
        if name.startswith('inputs/s589-'):
            with np.load(pin(PART/(name+'.npz'),digest)) as pack:counts+=pack['group_mass_Msun']
    def rms(value):return np.sqrt(np.sum(prob*(value-np.sum(value*prob))**2))*bg.vel**2
    results=[];bundles={}
    for q in (24,48):
        masses=[]
        for snap in SNAPS:
            lines=original(f'{snap}.bar.axi_4.coef_cylsp_DR').read_text().splitlines()
            off=next(i for i,s in enumerate(lines) if s.startswith('#R('))
            z=np.array(lines[off].split()[1:],float);grid=np.loadtxt(lines[off+1:off+26]);rad=grid[:,0]
            sp=RectBivariateSpline(np.log1p(rad),np.log1p(z),grid[:,1:],s=0)
            def gradient(r,h):
                return sp.ev(np.log1p(r),np.log1p(h),dx=1)/(1+r),sp.ev(np.log1p(r),np.log1p(h),dy=1)/(1+h)
            masses.append(solid_groups(edges,mus,min(1.,abs(orientation(snap)@orientation(600))),q,gradient,rad).ravel())
        bank=np.array(masses);deviations=bank-(1-frac[:,None])*bank[0]-frac[:,None]*bank[-1]
        values=[]
        for delta in deviations:
            pot=(jf.coeffs(local*(delta/den)[labels],bg.rad*bg.length,64)@harm.T)/bg.vel**2
            values.append(pot-np.sum(prob*pot))
        detail=np.array(values);bounds=np.minimum((ages-ages[0])/(ages[3]-ages[0]),(ages[-1]-ages)/(ages[-1]-ages[3]))
        hybrid=anchor+detail-bounds[:,None,None]*detail[3]
        proxy_mass=group_line+deviations
        hybrid_mass=proxy_mass+bounds[:,None]*(counts-group_line[3]-deviations[3])
        assert min(proxy_mass.min(),hybrid_mass.min())>0
        bundles['cold'+str(q)]=detail;bundles['hybrid'+str(q)]=hybrid
        assert not np.any(detail[[0,-1]]) and np.max(abs(hybrid[3]-anchor[3]))<1e-12
        for idx in range(1,4):
            results.append(dict(q=q,snap=SNAPS[idx],source_rms_kms2=rms(detail[idx]),cap64_relative=rms(detail[idx]-cap64[idx])/rms(detail[idx]),
                q24_change_relative=rms(detail[idx]-bundles['cold24'][idx])/rms(detail[idx]),
                min_proxy_Msun=proxy_mass[idx].min(),min_hybrid_Msun=hybrid_mass[idx].min(),
                particle_mismatch_kms2=rms(detail[idx]-anchor[3]) if idx==3 else None))
    assert max(row['q24_change_relative'] for row in results)<.005,results
    tab('direct-quadrature.csv',results);packet('direct-sources.npz',**bundles)
    record('direct-check.json',dict(analytic_relative=defect,source=sha(HOME/'direct-sources.npz'),primary_freeze=sha(HOME/'freeze.json')))
if __name__=='__main__':build()
