import csv
import json
import sys

from sources import ARMS, HOME, chord, np, packet, parent_setup, pin, record, sha, tab
from propagate import make_readout


def run(factor):
    if factor not in (2, 4):
        raise ValueError("Use the saved 140- or 280-step schedule.")
    lab, Evolution, advance, guard, shape = parent_setup()
    obj = lab.obj
    read = make_readout(lab, shape)
    meta = json.loads((HOME / 'actual-source.json').read_bytes())
    control = json.loads((HOME / 'direct-check.json').read_bytes())
    schedule = json.loads((HOME / f'run-x{factor}.json').read_bytes())
    pin(HOME / 'propagate.py', schedule['script'])
    counts = schedule['interval_steps']
    paths = ('cold48', 'hybrid48', 'anchor')
    with np.load(pin(HOME / 'interventions.npz', meta['conditions'])) as bank:
        ages, line, anchor = bank['ages'], bank['line'], bank['anchor']
    with np.load(pin(HOME / 'direct-sources.npz', control['source'])) as bank:
        drives = {name: line + bank[name] for name in paths[:2]}
    drives['anchor'] = line + anchor
    with np.load(HOME / f'final-states-x{factor}.npz') as bank:
        refs = {arm: (bank[arm+'_line'], bank[arm+'_anchor']) for arm in ARMS}
    results, currents, states = [], [], {}
    scale = obj.bg.vel**2 / obj.number
    def expectation(state, field):
        return np.vdot(state, obj.multiply(field, state)).real
    def energy(state, field):
        return scale * (obj.energy(state) + expectation(state, field))
    for arm in ARMS:
        initial = lab.run.reference[586] if arm == 'reset' else lab.raw[586]
        target = lab.initial[arm]
        _, target_flux = read(target)
        frozen = np.r_[target_flux, np.diff(target_flux)]
        for name in paths:
            guard()
            fields = drives[name]
            state = initial.copy()
            moment = obj.moment(state)
            initial_energy = energy(state, fields[0])
            work, worst_gap, drift = 0., 0., 0.
            for segment, count in enumerate(counts):
                dt = np.diff(ages)[segment] / (count * obj.unit_myr)
                solver = Evolution(obj, dt, initial)
                increment = fields[segment+1] - fields[segment]
                old = expectation(state, increment)
                for tick in range(count):
                    if tick % 16 == 0:
                        guard()
                    field = fields[segment] + (tick+.5) / count * increment
                    state, moment, _, _ = advance(obj, solver, state, moment, field, dt)
                    new = expectation(state, increment)
                    work += .5 * (old+new) / count * scale
                    old = new
                    drift = max(drift, abs(np.vdot(state, state).real / obj.number - 1))
                defect = energy(state, fields[segment+1]) - initial_energy - work
                worst_gap = max(worst_gap, abs(defect))
            assert drift < 1e-9 and worst_gap < .0003
            if name == 'anchor':
                assert chord(state, refs[arm][1]) < 1e-12
            states[arm+'_'+name] = state
            results.append(dict(arm=arm, source=name, steps=sum(counts),
                distance_forward=chord(state,target), distance_reverse=chord(state,target.conj()),
                distance_from_line=chord(state,refs[arm][0]), max_occupation_drift=drift,
                work_kms2=work, max_energy_work_error_kms2=worst_gap))
            mass, flux = read(state)
            for region, actual, forecast, enclosed in zip(('face1','face2','face3','shell1','shell2'),
                    np.r_[flux,np.diff(flux)], frozen, np.r_[mass,np.diff(mass)]):
                currents.append(dict(arm=arm, source=name, region=region, flux_Msun_yr=actual,
                    frozen_forward_Msun_yr=forecast, mass_Msun=enclosed))
            print(factor, arm, name, flush=True)
    packet(f'direct-states-x{factor}.npz', **states)
    tab(f'direct-endpoints-x{factor}.csv', results)
    tab(f'direct-currents-x{factor}.csv', currents)
    record(f'direct-run-x{factor}.json', dict(script=sha(HOME/'direct_evolution.py'),
           direct_source=control['source'], schedule=sha(HOME/f'run-x{factor}.json')))


if __name__ == '__main__':
    run(int(sys.argv[1]))
