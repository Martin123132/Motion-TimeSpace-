from tail_io import *
from multipoles import stokes
from scipy.interpolate import CubicSpline
from scipy.integrate import simpson

class Response(Scattering):
    def __init__(self,model,limit,ell=18,channel='all'):
        super().__init__(model,ell=ell)
        with np.load(ROOT/f'direct-{model}.npz') as bank:
            assert np.array_equal(bank['eta'],self.times) and np.array_equal(bank['coord'],PROBES)
            terms=dict(zip(bank['keys'],bank['values']))
        rates=self.back(self.times)[:,self.bkeys.index('opacity')][None,:]
        self.extra=[]
        for l in range(3,limit+1):
            gain={}
            for sp in ('I','E'):
                gain[sp]=sum(terms[f'{sp}{l}:{key}']*(1 if key=='gravity' else rates) for key in ('gravity','loss','gain','rate') if channel=='all' or channel==key)
            self.extra.append((l,gain))
        cols=np.zeros((self.ph_sl.stop-self.ph_sl.start+self.pol_sl.stop-self.pol_sl.start,5,len(self.times)),complex)
        for l,gain in self.extra:
            cols[l-2]+=gain['I']
            cols[ell-1:]+=stokes(l,ell)[:,None,None]*gain['E']
        self.nparent=len(self.names);self.names+=['tail'+str(i) for i in range(len(cols))]
        self.drive=CubicSpline(self.times,np.concatenate((self.drive(self.times),cols.transpose(2,0,1)/evolve.UNIT),axis=1))
    def rhs(self,env,state,kind,variant,observe=False):
        out=super().rhs(env,state,kind,variant,observe)
        if observe:return np.vstack((out,state[self.ph_sl.start+1],.3*(state[self.pol_sl.start+1]+state[self.pol_sl.start+3])))
        out[self.ph_sl.start:self.pol_sl.stop]+=np.stack([env[1][name] for name in self.names[self.nparent:]])
        return out

def run(model):
    labels={};budgets=[];checks=[]
    specs=[(limit,'trace',1,18,'all') for limit in (2,3,4,6,8,12,16)]
    specs.extend([(16,'conserved',1,18,'all'),(16,'trace',2,18,'all'),(16,'trace',1,22,'all')])
    for lim,kind,step,ell,chan in specs:
        guard();ev=Response(model,lim,ell,chan)
        with patch.object(evolve,'guard',guard):out=ev.integrate(kind,sub=step)
        label=f'{lim}-{kind}-{step}-{ell}-{chan}';labels[label]=out
        packet(f'solution-{model}-{label}.npz',eta=ev.times,coord=PROBES,names=evolve.OBS+['M3','E3'],values=out)
    ref=labels['2-trace-1-18-all'];best=labels['16-trace-1-18-all']
    with np.load(pin(f'scatter-{model}-both-trace-same-1-8.npz')) as bk:oldref=bk['values']
    with np.load(pin(f'realized-octupoles-{model}.npz')) as bk:oldhigh=bk['values']
    with np.load(pin(f'retarded-octupole-{model}.npz')) as bk:
        kernel={key:bk[key] for key in ('psi','weyl')};fine=bk['eta']
    for name,cur in labels.items():
        for obs,jj in [('psi',1),('weyl',0)]:
            calc=lambda series:series[:,jj] if jj==1 else (series[:,0]+series[:,1])/2
            target=calc(ref)[-1];forward=calc(cur)[-1]-target
            high=cur[:,-2:]-ref[:,-2:];interp=CubicSpline(ev.times,high)(fine)
            direct=simpson(np.sum(kernel[obs]*interp,axis=1),x=fine,axis=0)
            for ii,coord in enumerate(PROBES):
                checks.append(dict(run=name,model=model,observable=obs,probe=str(coord),final_reference_abs=abs(target[ii]),
                    fractional_change=abs(forward[ii]/target[ii]),signed_parallel=(forward[ii]/target[ii]).real,
                    quadrature_route_difference=abs((direct[ii]-forward[ii])/target[ii]),delta_real=forward[ii].real,delta_imag=forward[ii].imag,
                    angular_convergence_vs16=abs((calc(cur)[-1,ii]-calc(best)[-1,ii])/target[ii])))
        if name.startswith('16-trace-1-18'):
            d=cur[:,-2:]-ref[:,-2:]
            for ii,coord in enumerate(PROBES):
                oldnorm=np.max(np.linalg.norm(ref[:,-2:,ii],axis=1))
                measured=max(np.linalg.norm(d[:,:,ii],axis=1))
                for obs in ('psi','weyl'):
                    mag=np.linalg.norm(kernel[obs][:,:,ii],axis=1);gain=simpson(mag,x=fine)
                    target=abs(ref[-1,1,ii] if obs=='psi' else (ref[-1,0,ii]+ref[-1,1,ii])/2)
                    budgets.append(dict(model=model,observable=obs,probe=str(coord),octupole_change_over_reference=measured/oldnorm,
                        half_percent_required_over_reference=.005*target/gain/oldnorm,envelope_fraction=gain*measured/target))
    for tag,now,prev in [('psi',ref[:,1],oldref[:,1]),('high',ref[:,-2:],oldhigh)]:
        assert np.linalg.norm(now-prev)/np.linalg.norm(prev)<2e-5
    table('endpoint-'+model+'.csv',checks);table('budget-'+model+'.csv',budgets)
    print(model,[row for row in checks if row['run']=='16-trace-1-18-all' and row['probe']==str(PROBES[-1])],flush=True)
if __name__=='__main__':
    for model in sys.argv[1:] or ('cold','heavy'):run(model)
