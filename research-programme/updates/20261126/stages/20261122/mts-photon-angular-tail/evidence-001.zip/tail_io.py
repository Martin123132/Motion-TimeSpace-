from pathlib import Path
import hashlib,json,sys
ROOT=Path(__file__).resolve().parent
EX=ROOT.parent/"mts-exact-wave-gravity-20261122"
def sha(path):
    with path.open("rb") as handle:return hashlib.file_digest(handle,"sha256").hexdigest()
assert sha(EX/"seal.json")=="d01d3f837e97ac82e64e68fd4d72a7de77fb667ddc15e1a683539caad57ee5ba"
files=json.loads((EX/'seal.json').read_bytes())['files']
def pin(key):
    path=EX/key;assert sha(path)==files[key],key
    return path
for name in ('local_io.py','exact_forcing.py','angular.py','scatter_response.py','kernel_checks.py','polar_readout.py','octupole_gain.py'):pin(name)
sys.path.insert(0,str(EX))
import local_io as old
from local_io import np,csv,io,patch,parent,evolve,PROBES,Mixed,sources
from scatter_response import Scattering
from exact_forcing import load_data,ExactPair
sys.path.insert(0,str(ROOT))
def guard():
    old.guard();assert __debug__ and not (ROOT/'STOP-REQUESTED').exists()
def put(name,data):
    guard();path=ROOT/name
    if path.exists():assert sha(path)==hashlib.sha256(data).hexdigest(),name
    else:
        with path.open('xb') as out:out.write(data)
def packet(name,**items):
    buf=io.BytesIO();np.savez_compressed(buf,**items);put(name,buf.getvalue())
def table(name,rows):
    buf=io.StringIO();out=csv.DictWriter(buf,rows[0],lineterminator='\n');out.writeheader();out.writerows(rows);put(name,buf.getvalue().encode())
def record(name,obj):put(name,(json.dumps(obj,indent=2,sort_keys=True,allow_nan=False)+'\n').encode())
