from tail_io import *
from scipy.integrate import simpson
from scipy.interpolate import CubicSpline

def up(ell,spin):
    return ((ell+3)*(ell-1)/(ell+1) if spin else ell+1)/(2*ell+1)
def weight(ell,spin):
    return (2*ell+1)*((ell+2)*(ell+1)/(ell*(ell-1)) if spin else 1.)
def solve(t,k,op,anchor,spin,limit=20,sub=1,first=4,cut=0):
    nd=len(k);state=np.zeros((limit-first+1,nd));deg=np.arange(first,limit+1)[:,None]
    low=k*deg/(2*deg+1);high=k*up(deg,spin);zero=np.zeros((1,nd));out=[];residual=np.zeros(nd)
    ticks=np.interp(np.arange((len(t)-1)*2*sub+1)/(2*sub),np.arange(len(t)),t)
    rates=CubicSpline(t,op)(ticks);starts=CubicSpline(t,anchor,axis=1)(ticks)
    def rhs(s,rate,feed):return low*np.vstack((feed,s[:-1]))-high*np.vstack((s[1:],zero))-rate*s
    leak=k*(limit+1)/(2*limit+3)*np.sqrt(weight(limit+1,spin))
    tailmax=0.
    for ii in range(2*sub*cut,len(ticks)-1,2):
        if ii%(2*sub)==0 and ii>=256*2*sub:out.append(state.copy())
        dt=ticks[ii+2]-ticks[ii];r0,rm,r1=rates[ii:ii+3]
        rmin=min(r0,rm,r1)
        a=rhs(state,r0,starts[:,ii]);s2=state+dt*a/2;b=rhs(s2,rm,starts[:,ii+1])
        s3=state+dt*b/2;c=rhs(s3,rm,starts[:,ii+1]);s4=state+dt*c;d=rhs(s4,r1,starts[:,ii+2])
        env=np.maximum.reduce([abs(state[-1]),abs(s2[-1]),abs(s3[-1]),abs(s4[-1])])
        residual=residual*np.exp(-rmin*dt)+leak*env*(-np.expm1(-rmin*dt))/rmin
        state+=dt*(a+2*b+2*c+d)/6
        if ii>=256*2*sub:tailmax=max(tailmax,residual.max())
    out.append(state.copy());return np.moveaxis(out,0,-1),tailmax

def run(model):
    with np.load(ROOT/f'incident-{model}.npz') as src:
        t=src['eta'];kn=src['k'];raw=dict(zip(src['keys'],np.moveaxis(src['values'],2,0)))
    op=raw['opacity'][0];rows=[];result={}
    for name,spin,low,third,deriv in [('I',0,'pig','octg','octgdot'),('E',2,'E(2)','E(3)','Edot(3)')]:
        measured=(3*kn[:,None]*raw[low]/7-raw[deriv]-op*raw[third])/(kn[:,None]*up(3,spin))
        base,leak=solve(t,kn,op,raw[third],spin)
        result[name]=base[:14]
        ref4=measured[:,256:];common=np.linalg.norm(ref4)
        for tag,alt in [('native_delta4',ref4-base[0]),('halfstep_delta4',solve(t,kn,op,raw[third],spin,limit=14,sub=2)[0][0]-base[0]),
                        ('short_preparation_delta4',solve(t,kn,op,raw[third],spin,limit=12,cut=128)[0][0]-base[0])]:
            rows.append(dict(moment=name,test=tag,value=float(np.linalg.norm(alt)/common)))
        rows.append(dict(moment=name,test='last_slot_weighted_leak_estimate',value=leak))
        rows.append(dict(moment=name,test='max_abs_native4',value=float(abs(ref4).max())))
        rows.append(dict(moment=name,test='homogeneous_prestart_contraction',value=float(np.exp(-simpson(op[:257],x=t[:257])))))
    packet(f'first-tail-{model}.npz',eta=t[256:],k=kn,ells=np.arange(4,18),**result)
    table(f'incident-check-{model}.csv',rows);print(model,rows,flush=True)
if __name__=='__main__':
    for model in sys.argv[1:] or ('cold','heavy'):run(model)
