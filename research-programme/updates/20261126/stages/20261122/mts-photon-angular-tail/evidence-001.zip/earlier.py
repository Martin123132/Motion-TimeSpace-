from tail_io import *
import diagnostics as diag
import capture as builder
import subprocess,tempfile
from sympy import Dummy

NAMES=['tau','k','opacity','pig','octg','octgdot','E(2)','E(3)','Edot(3)']
def capture(model,func):
    native=diag.native;status=native.obj(native.source(f'runs/{model}/status.json'))
    path=native.SPEC/'runs/projection/a225-w6-d8.npz' if model=='heavy' else native.NATIVE/'runs/backgrounds/cold.npz'
    native.checked(path,status['source_hash'])
    for fn in native.engine.inherited.native_hashes():native.checked(fn,status['input_hashes'][str(fn)])
    pars=native.engine.inherited.params_for(path,background_boost=8.);pars.DoLateRadTruncation=False
    bg=native.engine.camb.get_background(pars);bg.Params.Accuracy.IntTolBoost=6
    with np.load(pin(f'native-{model}.npz')) as bank:
        k=bank['k'];tau=bank['eta'];keep=['pig','octg','E(2)']
        ref=bank['custom'][:,:,[bank['names'].tolist().index(s) for s in keep]]
    full=np.r_[tau[0]+np.linspace(-4,0,257)[:-1],tau]
    series=[]
    with pin(f'capture-{model}.csv').open() as handle:blocks=list(csv.DictReader(handle))
    with patch.object(diag.symbolic,'compile_sympy_to_camb_source_func',return_value=func):
        for block in blocks:
            guard();ix=slice(int(block['first']),1+int(block['last']));nodes=k[ix]
            batch=np.unique(np.r_[nodes,float(block['control']),float(block['hierarchy_cap'])])
            vals=bg.get_time_evolution(batch,full,vars=[Dummy(s) for s in NAMES],lAccuracyBoost=4)[np.searchsorted(batch,nodes)]
            assert np.isfinite(vals).all() and np.allclose(vals[:,:,1],nodes[:,None],rtol=2e-14,atol=0)
            series.append(vals[:,:,2:])
    out=np.concatenate(series);keys=NAMES[2:]
    checks=[dict(column=s,relative=np.linalg.norm(out[:,256:,keys.index(s)]-ref[:,:,i])/np.linalg.norm(ref[:,:,i])) for i,s in enumerate(keep)]
    assert max(r['relative'] for r in checks)<2e-5,checks
    packet(f'incident-{model}.npz',eta=full,k=k,keys=keys,values=out);table(f'prior-control-{model}.csv',checks)
    print(model,'preparation and native fourth-moment derivative readouts ready',flush=True)
if __name__=='__main__':
    if sys.argv[1:2]==['--child']:
        with patch.object(builder,'HERE',ROOT),patch.object(builder,'NAMES',NAMES),patch.object(builder,'run',capture),patch.object(builder,'save',put):builder.main()
    else:
        with tempfile.TemporaryDirectory(dir=ROOT,prefix='reader-') as folder:subprocess.run([sys.executable,'-B',str(ROOT/'earlier.py'),'--child',folder,*sys.argv[1:]],check=True)
