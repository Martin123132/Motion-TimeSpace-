from tail_io import *
from incident_tail import up
from scipy.special import eval_legendre
from numpy.polynomial.legendre import Legendre

def coeff(l,j,spin,k,p,cosine):
    assert abs(j-l)==1
    beta=(l/(2*l+1) if j==l-1 else up(l,spin))
    parity=1 if j==l-1 else -1
    w=parity*beta
    pp=w*p*eval_legendre(l,cosine)
    qq=w*k*eval_legendre(j,cosine)-pp
    diff=(2+j*(j+1)-l*(l+1))/2
    return pp+(4-diff)*qq,qq,(3-diff)*qq

def stokes(l,maxg):
    mu,wt=np.polynomial.legendre.leggauss(maxg+l+2)
    shape=Legendre.basis(l).deriv(2)(mu)*(1-mu**2)*(2*l+1)/(l*(l-1))
    return np.array([0. if (jj+l)%2 or jj>l else ((1j**jj)*(-1j)**(l-2)).real*np.dot(wt,shape*eval_legendre(jj,mu))/2 for jj in range(maxg+1)])

def setup(model):
    pin(f'native-{model}.npz');data=load_data(model);kn=data.nodes[:,None]
    with np.load(pin(f'polar-{model}.npz')) as pol:e3=pol['E3']
    with np.load(ROOT/f'first-tail-{model}.npz') as src:
        assert np.array_equal(src['k'],data.nodes) and np.array_equal(src['eta'],data.eta)
        tail={sp:src[sp] for sp in ('I','E')}
    rr=data.raw;f=data.first;data.first={key:f[key] for key in ('G','Vb')}
    data.first.update(rate=f['Db']+3*f['phi']+f['psi'],P=rr['polter'],I1=kn*f['Vg'],I2=rr['pig'],I3=rr['octg'],E2=rr['E(2)'],E3=e3)
    for sp in tail:
        for jj,val in enumerate(tail[sp],4):data.first[f'{sp}{jj}']=val
    return data

def calc(op,limit):
    k=np.sqrt(op.k2);lp=np.sqrt(op.p2);rp=np.sqrt(op.q2);lh=op.kp/(k*lp);rh=op.kq/(k*rp)
    result={};pieces={}
    for spin,sp in ((0,'I'),(2,'E')):
        for l in range(2,limit+1):
            terms={tag:np.zeros_like(op.parts['G'][0][0],dtype=complex) for tag in ('gravity','loss','gain','rate')}
            for j in (l-1,l+1):
                if j<spin:continue
                al=coeff(l,j,spin,k,lp,lh);br=coeff(l,j,spin,k,rp,rh);field=f'{sp}{j}'
                terms['gravity']+=op.product('G',field,al[0],br[0])
                terms['loss']+=op.product('Vb',field,al[1],br[1])
                if l==3 and j==2:terms['gain']+=op.product('Vb','P',al[2],br[2])
            terms['rate']=op.product('rate',f'{sp}{l}',-eval_legendre(l,lh),-eval_legendre(l,rh))
            for key,arr in terms.items():pieces[f'{sp}{l}:{key}']=arr
    return pieces

def run(model):
    data=setup(model);modes=Mixed();rows=[];series=[];opac=data.background['opacity']
    with np.load(pin('angular-'+model+'.npz')) as src:oldterms=dict(zip(src['names'],src['values']))
    for ii in (4,0,1,2,3):
        guard();op=ExactPair(modes,np.array(PROBES[ii]),data);pieces=calc(op,16)
        for sp,key in [('I','L2'),('E','Le')]:
            ref=oldterms[key][ii];rows.append(dict(probe=str(PROBES[ii]),field=sp,quadrupole_relative=np.linalg.norm(ref-pieces[sp+'2:gravity'])/np.linalg.norm(ref)))
        series.append((ii,pieces))
    series.sort(key=lambda row:row[0]);names=list(series[0][1]);vals=np.array([[v[name] for _,v in series] for name in names])
    assert np.isfinite(vals).all() and max(row['quadrupole_relative'] for row in rows)<2e-5
    packet('direct-'+model+'.npz',eta=data.eta,coord=PROBES,keys=names,values=vals);table('angular-replay-'+model+'.csv',rows)
    print(model,'direct angular sources through order 16',flush=True)
if __name__=='__main__':
    for model in sys.argv[1:] or ('cold','heavy'):run(model)
