from tail_io import *
from multipoles import coeff,stokes
from kernel_checks import sphere,tensor,full_collision
from numpy.polynomial.legendre import Legendre
from scipy.special import eval_legendre
from math import factorial

def run():
    s,et,ep,wt=sphere(18);z=s[:,2];rows=[]
    for hz in (-.66,.21,.87):
        k=1.27;plen=.73;h=np.array([np.sqrt(1-hz**2),0.,hz]);p=plen*h;q=np.array([0.,0.,k])-p
        mp=s@h;qn=s@q;pn=s@p;dw=h@q-mp*qn;tz=hz-z*mp;wz=q[2]-z*qn
        tzz=tz**2-.5*(1-mp**2)*(1-z*z);dtzz=-2*mp*wz*tz+mp*dw*(1-z*z)
        for l in range(2,17):
            for j in (l-1,l+1):
                sign=1 if j<l else -1;pj=Legendre.basis(j)
                for spin in (0,2):
                    if j<spin:continue
                    if not spin:
                        a=(2*j+1)*eval_legendre(l,z);H=pj(mp);dH=dw*pj.deriv()(mp)
                    else:
                        a=2*(2*j+1)/(j*(j-1)*(l+1)*(l+2))*Legendre.basis(l).deriv(2)(z)
                        H=pj.deriv(2)(mp)*tzz
                        dH=dw*pj.deriv(3)(mp)*tzz+pj.deriv(2)(mp)*dtzz
                    actual=sign*np.array([wt@(a*((pn+4*qn)*H-dH)),wt@(a*qn*H),wt@(a*(3*qn*H-dH))])
                    target=np.array(coeff(l,j,spin,k,plen,hz))
                    err=max(abs(actual-target));assert err<2e-11,(spin,l,j,actual,target)
                    rows.append(dict(hz=hz,ell=l,incident=j,spin=spin,max_abs=err))
    table('angular-projection.csv',rows)
    s,et,ep,wt=sphere(11);mu=s[:,2];checks=[]
    rng=np.random.default_rng(60421)
    for case,hz in enumerate([-.6,.42,.79]):
        h=np.array([np.sqrt(1-hz**2),0.,hz]);p=.63*h;kv=1.22;q=np.array([0.,0.,kv])-p;beta=q*.27;rate=.23
        inc=np.zeros(len(s));pol=np.zeros((len(s),3,3));amps={}
        for spin in (0,2):
            for j in range(spin,10):
                amps[spin,j]=amp=.4*rng.normal()/(j+1)
                if spin==0:inc+=amp*(2*j+1)*eval_legendre(j,s@h)
                else:pol+=amp*((2*j+1)/(j*(j-1))*Legendre.basis(j).deriv(2)(s@h))[:,None,None]*tensor(s,h)
        def moments(eps):
            iv,qv=full_collision(eps,s,et,ep,wt,beta,inc,pol,rate,True)
            return np.array([[wt@(eval_legendre(l,mu)*iv),
                wt@((1-mu**2)*Legendre.basis(l).deriv(2)(mu)*qv)/((l+1)*(l+2))] for l in range(3,10)])
        base=moments(0);seq=[]
        for eps in (.008,.004):seq.append((moments(eps)+moments(-eps)-2*base)/(2*eps**2))
        actual=(4*seq[1]-seq[0])/3
        for l in range(3,10):
            for idx,sp in enumerate((0,2)):
                expected=-rate*amps[sp,l]*eval_legendre(l,hz)
                for j in (l-1,l+1):
                    sign=1 if j<l else -1
                    _,qq,gb=coeff(l,j,sp,kv,np.linalg.norm(p),hz)
                    expected+=sign*.27*qq*amps.get((sp,j),0.)
                    if l==3 and j==2:
                        ps=-amps[0,2]/10+.6*amps[2,2]
                        expected+=sign*.27*gb*ps*(1 if sp else -1)
                err=abs(actual[l-3,idx]-expected);assert err<3e-8,(case,l,sp,expected,actual[l-3,idx])
                checks.append(dict(case=case,ell=l,spin=sp,analytic=expected,full_kernel=actual[l-3,idx],absolute=err))
    table('boost-check.csv',checks);print(len(rows),'projections;',len(checks),'boosts')
if __name__=='__main__':run()
