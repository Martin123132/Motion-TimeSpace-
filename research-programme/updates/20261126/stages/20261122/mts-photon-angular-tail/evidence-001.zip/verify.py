from pathlib import Path
import csv
import hashlib
import json
import math

ROOT = Path(__file__).resolve().parent


def digest(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def rows(name):
    with (ROOT / name).open(newline="") as handle:
        return list(csv.DictReader(handle))


def main():
    assert __debug__ and not (ROOT / "STOP-REQUESTED").exists()
    parent = ROOT.parent / "mts-exact-wave-gravity-20261122" / "seal.json"
    assert digest(parent) == "d01d3f837e97ac82e64e68fd4d72a7de77fb667ddc15e1a683539caad57ee5ba"
    for name, key, count, limit in [("angular-projection.csv","max_abs",177,2e-11),
                                    ("boost-check.csv","absolute",42,3e-8)]:
        values = rows(name)
        assert len(values) == count and all(abs(float(row[key])) < limit for row in values)
    for model in ("cold", "heavy"):
        checks = rows(f"endpoint-{model}.csv")
        assert len(checks) == len({(row["run"],row["observable"],row["probe"]) for row in checks}) == 100
        selected = [row for row in checks if row["run"] == "16-trace-1-18-all"]
        assert len(selected) == 10 and {row["observable"] for row in selected} == {"psi","weyl"}
        assert len({row["probe"] for row in selected}) == 5
        for row in checks:
            assert row["model"] == model and math.isfinite(float(row["fractional_change"]))
            assert float(row["final_reference_abs"]) > 0
            assert (ROOT / f"solution-{model}-{row['run']}.npz").is_file()
            if row["run"].startswith("16-"):
                assert float(row["fractional_change"]) < .005
                assert float(row["angular_convergence_vs16"]) < 2e-5
                assert float(row["quadrature_route_difference"]) < 2e-5
        native = [row for row in rows(f"incident-check-{model}.csv") if row["test"] == "native_delta4"]
        assert {row["moment"] for row in native} == {"I","E"} and all(float(row["value"]) < 2e-5 for row in native)
    assert not list(ROOT.glob("reader-*")) and not (ROOT / "__pycache__").exists()
    seal = ROOT / "seal.json"
    files = {path.name:digest(path) for path in sorted(ROOT.iterdir()) if path.is_file() and path != seal}
    data = (json.dumps({"files":files}, sort_keys=True, indent=2) + "\n").encode()
    if seal.exists():
        assert seal.read_bytes() == data
    else:
        with seal.open("xb") as handle:
            handle.write(data)
    print(len(files), digest(seal))


if __name__ == "__main__":
    main()
