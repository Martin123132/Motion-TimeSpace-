from run_io import *
from ball import geometry
from numpy.polynomial.legendre import legvander
from projection_check import acc

def ratio(value,target):
    return abs(value/target-1)
def records(file,idx):return {tuple(row[k] for k in idx):row for row in rows(HOME/file)}
def audit():
    target={(r["prep"]+"_"+r["flow"],r["aperture"]):r for r in rows(pin(LAST,"weak-field-feedback.csv"))}
    phys={(r["prep"]+"_"+r["flow"],r["aperture"]):r for r in rows(pin(LAST,"initial-wave-feedback.csv")) if r["patch"]=="chart" and r["wave_steps"]=="280" and r["rule"]=="24"}
    checks=[]
    def gate(group,key,val,limit=.005):
        assert np.isfinite(val)
        checks.append(dict(group=group,case=str(key),error=val,tolerance=limit,passes=bool(val<=limit)))
    glob=("ordinary-q5","ordinary-q9","spherical-4-2","spherical-6-1","spherical-9-1","spherical-12-1")
    with np.load(HOME/"mesh.npz") as b:
        original=[b[f"original{s}"] for s in (586,590)];pol=legvander(b["mu"],68)[:,::2]
    previous=None
    for name in glob:
        with np.load(HOME/(name+".npz")) as b:
            fields=[b["phi"][:,:,k]@pol.T for k in (0,1)]
            if previous is not None:
                for j,(field,old,co) in enumerate(zip(fields,original,previous)):
                    gate("potential_change_"+name,j,np.linalg.norm(field-co)/np.linalg.norm(field-old))
                    gate("whole_potential_"+name,j,np.linalg.norm(field-co)/np.linalg.norm(field))
            previous=fields
            gate("isolated_monopole",name,max(abs(b["probe_phi"][-1,0]*400/(-4.30091727003628e-6*b["mass"])-1)),1e-10)
    best=records("derivatives-spherical-12-1-4-280.csv",("state","aperture"))
    for file in sorted(HOME.glob("derivatives-*.csv")):
        data=records(file.name,("state","aperture"));assert data.keys()==target.keys()
        for k,row in data.items():
            num=float(row["quadratic"]);ref=float(target[k]["wave_enclosed_mass_curvature_Msun_Myr2"])
            gate("global_curvature_vs_frozen_"+file.stem[12:],k,ratio(num,ref))
            gate("global_derivative_refinement_"+file.stem[12:],k,ratio(num,float(best[k]["quadratic"])))
            gate("gauge_invariance",k,abs(float(row["gauge_change"])/num))
            gate("ball_initial_mass",k,ratio(float(row["initial_mass"]),float(phys[k]["wave_mass_Msun"])),1e-9)
    for file in sorted(HOME.glob("paired-*.csv")):
        for r in rows(file):
            gate("resolved_time_limit_"+file.stem[7:],(r["state"],r["aperture"],r["t"]),float(r["relative"]))
            gate("paired_occupation",r["state"],float(r["paired_occupation"]),1e-9)
    for f in sorted(HOME.glob("occupation-*.csv")):
        for r in rows(f):gate("global_occupation",r["state"],max(float(r[k]) for k in ("occupation_old","occupation_new")),1e-9)
    dt=records("evolution-spherical-6-1-8-280.csv",("state","aperture","time"))
    low=records("evolution-spherical-6-1-4-280.csv",("state","aperture","time"))
    for k in dt:gate("62500yr_replay_time_step",k,ratio(float(low[k]["delta"]),float(dt[k]["delta"])))
    lowmass=records("angular-mass-8.csv",("aperture","degree"));allmass=records("angular-mass-12.csv",("aperture","degree"));bands=[]
    for shell in ("1","2","3"):
        vals=[r for (a,b),r in allmass.items() if a==shell]
        last=max(int(r["degree"]) for r in vals if float(r["relative_to_correction"])>.005)
        bands.append(dict(aperture=shell,last_failing_degree=last,first_subsequent_passing_degree=last+2,max_tested_degree=1024))
        for r in vals:
            lo=lowmass[shell,r["degree"]]
            gate("angular_quadrature",(shell,r["degree"]),abs(float(lo["projected_Msun"])-float(r["projected_Msun"]))/abs(float(r["old_effective_Msun"])-float(r["source_Msun"])))
    table("angular-resolution.csv",bands)
    phase=rows(HOME/"resolved-phase-current.csv")
    for row in phase:
        k=(row["state"],row["aperture"]);gate("resolved_phase_current",k,ratio(float(row["phase_readout_Msun_Myr2"]),float(target[k]["wave_enclosed_mass_curvature_Msun_Myr2"])))
    _,_,A=geometry();answer=[];sortedcases=sorted(HOME.glob("resolved-density-n*.csv"));fixed={}
    for file in sortedcases:
        n=int(file.stem.split("-n")[1])
        for row in rows(file):
            k=(row["state"],row["shell"]);val=float(row["fixed_density_step"]);full=float(row["plus_observer_derivative"])
            gate("resolved_kinetic_fixed_n"+str(n),k,float(row["relative"]))
            gate("resolved_kinetic_moving_n"+str(n),k,ratio(full,float(target[k]["wave_enclosed_mass_curvature_Msun_Myr2"])))
            gate("resolved_mass",k,float(row["mass_relative"]));gate("omitted_kernel_per_axis",k,float(row["bessel_l1_tail_bound"]),1e-20)
            fixed[n,k,row["q"],row["time_year"]]=val
            if (n,row["q"],row["time_year"])==(128,"8","0.125"):
                shell=int(k[1]);dt_myr=.125e-6
                answer.append(dict(state=k[0],aperture=shell,resolution_pc=row["h_pc"],fixed_time_year=.125,
                    fixed_delta_Msun=.5*dt_myr**2*val,fixed_density_readout=val,observer_term=float(phys[k]["com_term_Msun_Myr2"]),
                    moving_curvature=full,continuum_prediction=float(target[k]["wave_enclosed_mass_curvature_Msun_Myr2"]),
                    global_projected_curvature=float(best[k]["quadratic"]),mean_inward_g_curvature=4.30091727003628e-6*full/(A*shell)**2))
    for k in target:
        for t in ("0.125","0.0625","0.03125"):
            gate("resolved_mesh",k,ratio(fixed[64,k,"8",t],fixed[128,k,"8",t]))
            gate("resolved_ball_quadrature",k,ratio(fixed[128,k,"4",t],fixed[128,k,"8",t]))
        gate("resolved_step_shortening",k,ratio(fixed[128,k,"8","0.125"],fixed[128,k,"8","0.03125"]))
    table("wave-gravity-readout.csv",answer);table("all-comparisons.csv",checks)
    summary={g:dict(n=len(v),misses=sum(not r["passes"] for r in v),worst=max(r["error"] for r in v)) for g in sorted(set(r["group"] for r in checks)) if (v:=[r for r in checks if r["group"]==g])}
    rec("comparison-summary.json",summary)
if __name__=="__main__":audit()
