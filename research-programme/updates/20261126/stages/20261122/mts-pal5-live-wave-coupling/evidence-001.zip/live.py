from run_io import *
from ball import Ball,geometry
from numpy.polynomial.legendre import legvander

def external(lab,filename):
    bg=lab.obj.bg
    with np.load(HOME/filename) as model:
        assert np.array_equal(bg.rad*bg.length,model["target"])
        polys=legvander(bg.mu,int(model["degrees"][-1]))[:,::2]
        assert np.array_equal(model["degrees"],2*np.arange(bg.orders[-1]+1))
        return [(model["phi"][:,:,k]@polys.T)/bg.vel**2-lab.mesh.ordinary for k in (0,1)]

def run(src,steps,count):
    lab,Evo,advance,_,shape=setup();obj=lab.obj;unit=obj.unit_myr;bg=obj.bg
    ext=external(lab,src+".npz");old=[lab.run.fields[k] for k in (586,590)]
    duration=lab.run.ages[590]-lab.run.ages[586];obs=Ball(lab,shape);centre,vel,A=geometry()
    dacc=np.load(HOME/"centre-force-change.npz")["delta"]/(977.7922216807892**2)
    rotate=np.array([centre[0]/np.hypot(*centre[:2]),centre[1]/np.hypot(*centre[:2])])
    dacc=np.r_[dacc[0]*rotate,dacc[1]]
    masses=[];jets=[];safety=[];armnames=("reset_forward","reset_reverse","coupled_forward","coupled_reverse")
    paths={}
    for label in ("native-8","chart48-8"):
        path=rows(pin(LAST,"centres-"+label+".csv"))
        for row in path:
            paths[label,row["prep"]+"_"+row["flow"],float(row["time"])]=np.array([float(row[col]) for col in ("x","y","z")])
    probes=[.015625,.03125,.0625];rstep=.015625/steps;oldfield=old[0];newfield=ext[0]
    with np.load(pin(PREP,f"states-586-{count}.npz")) as bank:
        def derivative(state,drive,rate):
            ham=lambda vec:obj.bare@vec+obj.multiply(drive+obj.phi(obj.moment(state)),vec)-obj.mu*vec
            first=-1j/unit*ham(state)
            mdot=(2*(obj.sky(state).conj()*obj.sky(first)).real)@obj.wave.weights
            second=-1j/unit*(ham(first)+obj.multiply(rate+obj.phi(mdot),state))
            return first,second
        for key in armnames:
            guard();state=bank[key].copy()
            startmass=np.vdot(state,state).real;assert abs(startmass/obj.number-1)<1e-9
            uo,vo=derivative(state,oldfield,(old[1]-old[0])/duration)
            un,vn=derivative(state,newfield,(ext[1]-ext[0])/duration)
            solver=Evo(obj,rstep/unit,state)
            old_s,new_s=state.copy(),state.copy()
            old_m,new_m=obj.moment(state),obj.moment(state)
            h=1e-4
            for shell in (1,2,3):
                B=obs.operator(centre,A*shell,16)
                def slope(vec):
                    forward=obs.operator(centre+h*vel,A*shell,16);back=obs.operator(centre-h*vel,A*shell,16)
                    return (forward(state,vec)-back(state,vec))/(2*h)
                def translation(epsilon):
                    direc=dacc/np.linalg.norm(dacc)
                    plus=obs.operator(centre+epsilon*direc,A*shell,16);minus=obs.operator(centre-epsilon*direc,A*shell,16)
                    return (plus(state,state)-minus(state,state)).real/(2*epsilon)*np.linalg.norm(dacc)
                cterm=translation(2e-5)
                fixed=2*(B(state,vn-vo)+B(un-uo,un+uo)).real
                moving=4*slope(un-uo).real
                linear=2*B(state,un-uo).real
                ug,vg=derivative(state,newfield+.013,(ext[1]-ext[0])/duration)
                gauge=2*(B(state,vg-vn)+B(ug-un,ug+un)).real+4*slope(ug-un).real
                jets.append(dict(state=key,aperture=shell,initial_mass=B(state,state).real,linear=linear,fixed=fixed,
                   translation_velocity=moving,translation_acceleration=cterm,quadratic=fixed+moving+cterm,
                   centre_derivative_step=abs(cterm-translation(1e-5)),gauge_change=gauge))
            for tick in range(4*steps):
                frac=(tick+.5)*rstep/duration
                for label,values in (("old",old),("new",ext)):
                    drive=values[0]+frac*(values[1]-values[0])
                    if label=="old":old_s,old_m,_,_=advance(obj,solver,old_s,old_m,drive,rstep/unit)
                    else:new_s,new_m,_,_=advance(obj,solver,new_s,new_m,drive,rstep/unit)
                tt=(tick+1)*rstep
                if tt not in probes:continue
                loc1=paths["native-8",key,tt];loc2=paths["chart48-8",key,tt]
                for shell in (1,2,3):
                    B1=obs.operator(loc1,shell*A,16);B2=obs.operator(loc2,shell*A,16)
                    b0=B1(old_s,old_s).real;frame=B2(old_s,old_s).real-b0
                    difference=B2(new_s-old_s,new_s+old_s).real
                    masses.append(dict(state=key,aperture=shell,time=tt,old=b0,new=B2(new_s,new_s).real,
                                       changing_wave=difference,changing_centre=frame,delta=frame+difference))
                dl=np.abs(np.vdot(old_s,new_s));faced=new_s*np.exp(-1j*np.angle(np.vdot(old_s,new_s)))
                safety.append(dict(state=key,time=tt,occupation_old=abs(np.vdot(old_s,old_s).real/startmass-1),
                    occupation_new=abs(np.vdot(new_s,new_s).real/startmass-1),phase_free_distance=np.linalg.norm(faced-old_s)/np.sqrt(startmass)))
    tag=f"{src}-{steps}-{count}"
    table(f"derivatives-{tag}.csv",jets);table(f"evolution-{tag}.csv",masses);table(f"occupation-{tag}.csv",safety)
    print(tag,flush=True)
if __name__=="__main__":run(sys.argv[1],*map(int,sys.argv[2:]))
