from run_io import HOME, PINS, json, np, pin, rec, rows, sha
import re

def main():
    for folder, expected in PINS.items():
        assert sha(folder / "seal.json") == expected
        for name, digest in json.loads((folder / "seal.json").read_bytes()).items():
            assert sha(folder / name) == digest, name
    files = sorted(path for path in HOME.iterdir() if path.name != "seal.json")
    for path in files:
        assert path.is_file() and path.stat().st_size > 0, path
        if path.suffix == ".py":
            compile(path.read_bytes(), str(path), "exec")
        if path.suffix == ".csv":
            records = rows(path)
            assert records and all(None not in record and None not in record.values() for record in records)
        if path.suffix == ".npz":
            with np.load(path, allow_pickle=False) as archive:
                assert archive.files
                for name in archive.files:
                    array = archive[name]
                    assert array.size and (array.dtype.kind not in "fci" or np.isfinite(array).all())
        if path.suffix == ".md":
            for link in re.findall(r"\]\(([^ )]+)\)", path.read_text(encoding="utf8")):
                if not link.startswith(("http://", "https://", "#")):
                    assert (path.parent / link.split("#")[0]).is_file(), link
    for pattern, count in [("angular-mass-*.csv",1539),("resolved-density-*.csv",72),("resolved-phase-current.csv",144),("evolution-*.csv",36),("occupation-*.csv",12),("derivatives-*.csv",12),("wave-gravity-readout.csv",12),("shared-release-dates.csv",72)]:
        matches = list(HOME.glob(pattern))
        assert matches and all(len(rows(path)) == count for path in matches), pattern
    audit = json.loads((HOME/"comparison-summary.json").read_bytes())
    assert audit["62500yr_replay_time_step"]["misses"] == 36
    assert audit["global_curvature_vs_frozen_spherical-12-1-4-280"]["misses"] == 12
    for name in ["resolved_mesh","resolved_ball_quadrature","resolved_step_shortening","resolved_time_limit_spherical-6-1-h20-n4","resolved_kinetic_fixed_n128","resolved_kinetic_moving_n128"]:
        assert audit[name]["misses"] == 0, name
    for record in rows(HOME/"wave-gravity-readout.csv"):
        assert float(record["global_projected_curvature"]) > 0 > float(record["continuum_prediction"])
    results = rows(HOME/"shared-release-dates.csv")
    for grid in ("4-1","4-2"):
        cases = [float(row["max_remaining_fraction"]) for row in results if row["grid"]==grid and row["tails"]=="inner+outer"]
        assert len(cases)==12 and sum(val<.99999 for val in cases)==6 and .6964<min(cases)<.6966
    manifest = {path.name: sha(path) for path in files}
    rec("seal.json",manifest)
    assert all(sha(HOME/name)==digest for name,digest in json.loads((HOME/"seal.json").read_bytes()).items())
    print(len(manifest), sha(HOME/"seal.json"))

if __name__=="__main__":
    main()
