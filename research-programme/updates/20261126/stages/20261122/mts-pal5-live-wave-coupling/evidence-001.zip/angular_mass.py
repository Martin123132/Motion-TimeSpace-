from run_io import *
from ball import geometry
from scipy.special import roots_legendre
from numpy.polynomial.legendre import legvander
def main(q):
    sys.path.insert(0,str(LAST));import sources as parent
    parent.table=lambda name,data:table("gains-check.csv",data)
    faces,shells,gains=parent.info();orig=parent.prior.original;src=parent.prior.source
    pos,vel,A=geometry();dist=np.linalg.norm(pos);mu0=pos[2]/dist
    degrees=2*np.arange(513);p0=legvander(mu0,1024).ravel()[::2]
    n,w=roots_legendre(q);nr,wr=roots_legendre(3*q)
    old=rows(pin(TIDE,"finite-work.csv"));reference=rows(pin(TIDE,"finite-aperture-source.csv"))
    outputs=[]
    for shell in (1,2,3):
        radius=A*shell
        true=float(next(row["ordinary_mass"] for row in reference if row["case"]=="reset_forward" and row["order"]=="24" and int(row["aperture"])==shell))
        native=float(next(row["flux_mass"] for row in old if row["case"]=="reset_forward" and row["field"]=="native" and row["source"]=="ordinary" and row["order"]=="24" and int(row["aperture"])==shell))
        mm=np.zeros(len(degrees));pm=0.
        for r,mw in zip(dist+radius*nr,radius*wr):
            guard();h=(radius**2-(r-dist)**2)/(2*dist*r); cap=(legvander(1.-h*(n+1)/2,1024)[:,::2].T@(w/2))*h
            bounds=np.unique(np.clip(np.r_[0.,1.,faces,src.stars.axis/r,src.stars.H/r,np.cos(np.linspace(0,np.pi/2,1+256)),
                np.sqrt(np.maximum(0,1-(src.radknots/r)**2))],0,1))
            step=np.diff(bounds)[:,None]/2;mu=(bounds[:-1,None]+step*(1+n)).ravel();wt=(step*w).ravel();cyl=r*np.sqrt(1-mu*mu);z=r*mu
            dens=parent.material.density(cyl,z)*gains[0,np.searchsorted(shells,r,side="right")-1,np.searchsorted(faces[1:-1],mu)]
            moment=legvander(mu,1024)[:,::2].T@(dens*wt)
            mm+=2*np.pi*r*r*mw*(2*degrees+1)*moment*p0*cap
            pm+=2*np.pi*r*r*mw*h
        assert abs(pm/(4*np.pi*radius**3/3)-1)<1e-11
        cumulative=np.cumsum(mm)
        for degree,value in zip(degrees,cumulative):
            outputs.append(dict(aperture=shell,degree=degree,projected_Msun=value,source_Msun=true,old_effective_Msun=native,
                mass_difference=value-native,relative_to_correction=abs(value-true)/abs(true-native)))
    table(f"angular-mass-{q}.csv",outputs)
if __name__=="__main__":main(int(sys.argv[1]))
