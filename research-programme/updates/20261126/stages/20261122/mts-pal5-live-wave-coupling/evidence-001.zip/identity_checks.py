from run_io import *
from resolved_step import kernel,propagate
from scipy.special import roots_legendre,eval_legendre
from ball import geometry

def run():
    count=64;h=1.;kappa=2.04;ix=np.arange(count);kx,kz=2*np.pi*np.array([3,5])/count
    theta=kx*ix[:,None]+kz*ix;v=np.cos(theta);dispersion=kappa*(2-np.cos(kx)-np.cos(kz))/h**2
    rows_out=[]
    for t in (.125,.5,2.):
        ker,_=kernel(kappa*t/h**2)
        phase=np.exp(1j*theta);uniform=np.ones_like(phase)
        propagated=propagate(phase,ker,mode="wrap")
        err=np.max(abs(propagated-phase*np.exp(-1j*dispersion*t)))
        null=np.max(abs(abs(propagate(uniform,ker,mode="wrap"))**2-1))
        predicted=-t/kappa*np.sin(t*dispersion)*v
        eps=.001
        densities=[abs(propagate(np.exp(-.5j*t/kappa*sign*eps*v),ker,mode="wrap"))**2 for sign in (1,-1)]
        numerical=(densities[0]-densities[1])/(2*eps)
        delta=np.linalg.norm(numerical-predicted)/np.linalg.norm(predicted);unit=max(abs(np.mean(d)-1) for d in densities)
        assert max(err,null,unit)<1e-12 and delta<1e-5
        rows_out.append(dict(time=t,dispersion_relative=err,uniform_null=null,mass_invariance=unit,first_order_density_relative=delta))
    table("kinetic-manufactured.csv",rows_out)
    with np.load(HOME/"mesh.npz") as mesh:
        mu=mesh["mu"];weights=mesh["weights"];degrees=mesh["degrees"]
    H=eval_legendre(degrees,mu[:,None])*np.sqrt(2*degrees+1);pos,_,_=geometry();mu0=pos[2]/np.linalg.norm(pos)
    out=[]
    for ell in (0,34,68,70,72,92):
        raw=eval_legendre(ell,mu);matrix=H.T@((raw*weights)[:,None]*H)
        size=np.linalg.norm(matrix,2)
        if ell==0: assert np.linalg.norm(matrix-np.eye(len(degrees)))<1e-10
        if ell>68: assert size<1e-10
        if ell<=68: assert size>.01
        out.append(dict(degree=ell,matrix_norm=size,hermitian_defect=np.linalg.norm(matrix-matrix.T),
            local_laplacian_at_unit_radius=-ell*(ell+3)*eval_legendre(ell,mu0)))
    table("angular-multiplication-control.csv",out)
if __name__=="__main__":run()
