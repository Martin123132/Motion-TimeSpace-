from run_io import HOME, ROOT, np, pin, TIDE, rows, sha, table, json

JOIN = ROOT / "mts-pal5-joined-flow-586-600-20261122"
KEYS = ("ra_deg", "dec_deg", "vlos_kms")

def segment(left, right):
    slopes = right - left
    intercept = np.r_[left, -left]
    rates = np.r_[slopes, -slopes]
    locations = [0., 1.]
    for index, speed in enumerate(rates):
        for other in range(index):
            if speed != rates[other]:
                time = (intercept[other] - intercept[index]) / (speed - rates[other])
                if 0. < time < 1.:
                    locations.append(time)
    return min((float(np.max(np.abs(left + time * slopes))), time) for time in locations)

def run():
    assert np.allclose(segment(np.array([1., 0.]), np.array([0., 1.])), (.5, .5))
    assert np.allclose(segment(np.array([-1., 2.]), np.array([1., -2.])), (0., .5))
    assert sha(JOIN / "seal.json") == "86d9b1296c253b14a04e475339a9cbf71f84fed201749a234af4892b715576b7"
    pin(TIDE, "release-time-brackets.csv")
    manifest = json.loads((JOIN / "seal.json").read_bytes())
    outputs = []
    for grid in ("4-1", "4-2"):
        filename = "escapes-" + grid + ".csv"
        assert sha(JOIN / filename) == manifest[filename]
        data = rows(JOIN / filename)
        by_key = {(row["arm"], row["distance"], row["flow"], float(row["release"]), row["tail"]): np.array([float(row[key]) for key in KEYS]) for row in data}
        assert len(by_key) == len(data) == 72
        dates = sorted({key[3] for key in by_key})
        assert len(dates) == 3 and np.allclose(np.diff(dates), [10., 10.])
        for arm, distance in sorted({key[:2] for key in by_key}):
            for injected, opposite in (("forward", "reverse"), ("reverse", "forward")):
                for tails in (("inner",), ("outer",), ("inner", "outer")):
                    def sample(flow, date):
                        return np.concatenate([by_key[arm, distance, flow, date, tail] for tail in tails])
                    differences = [sample(opposite, date) - sample(injected, dates[1]) for date in dates]
                    scales = np.abs(differences[1])
                    assert np.all(scales > 0)
                    normalized = [delta / scales for delta in differences]
                    candidates = []
                    for piece in range(2):
                        cost, fraction = segment(*normalized[piece:piece+2])
                        shift = dates[piece] - dates[1] + fraction * (dates[piece+1] - dates[piece])
                        candidates.append((cost, abs(shift), shift))
                    cost, _, shift = min(candidates)
                    assert 0 <= cost <= 1. + 1e-13 and -10. <= shift <= 10.
                    outputs.append(dict(grid=grid, preparation=arm, distance=distance, injected=injected,
                        tails="+".join(tails), shift_Myr=shift, max_remaining_fraction=cost))
    table("shared-release-dates.csv", outputs)
if __name__ == "__main__":
    run()
