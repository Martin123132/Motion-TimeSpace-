from pathlib import Path
import sys,os,hashlib,json,csv,io
for name in ("OPENBLAS_NUM_THREADS","OMP_NUM_THREADS","MKL_NUM_THREADS","NUMEXPR_NUM_THREADS","BLIS_NUM_THREADS"):os.environ[name]="1"
import numpy as np
HOME=Path(__file__).resolve().parent;ROOT=HOME.parent
PREP=ROOT/"mts-flow-formation-inverse-586-20261122"
LAST=ROOT/"mts-pal5-release-evolution-20261122"
TIDE=ROOT/"mts-pal5-source-tides-20261122"
WORK=ROOT/"mts-pal5-interface-work-20261122"
PINS={PREP:"4ae215216dac834ea5d8ae503fea680707af22348044627efb0b507a7c398fcb",LAST:"f9b37646651579124cc8cf0b744488b84d493e668ca81f6516e361dd06222eb5",TIDE:"f8c1f197a9fe0fbe68dcf2b7d03499c1471223e73ed74d5394b6ba8bc20fca3a",WORK:"e8891d2372d597e163d1f8de482c0884eac39405223b34e7b9d0eee10f7e2723"}
def sha(p):
    with p.open("rb") as st:return hashlib.file_digest(st,"sha256").hexdigest()
def pin(folder,name):
    assert sha(folder/"seal.json")==PINS[folder] and sha(folder/name)==json.loads((folder/"seal.json").read_bytes())[name],name
    return folder/name
def save(name,data):
    path=HOME/name
    if path.exists():assert path.read_bytes()==data,name
    else:
        with path.open("xb") as st:st.write(data)
def rec(name,data):save(name,(json.dumps(data,indent=2,allow_nan=False,sort_keys=True)+"\n").encode())
def table(name,data):
    st=io.StringIO();writer=csv.DictWriter(st,fieldnames=list(data[0]),lineterminator="\n");writer.writeheader();writer.writerows(data);save(name,st.getvalue().encode())
def rows(path):
    with path.open() as f:return list(csv.DictReader(f))
def packet(name,**kwargs):
    st=io.BytesIO();np.savez_compressed(st,**kwargs);save(name,st.getvalue())
def guard():
    assert not any((folder/"STOP-REQUESTED").exists() for folder in (HOME,ROOT,*PINS,ROOT/"mts-fire-joint-baryon-history-20261120")),"Owner hold"
def setup():
    pin(PREP,"inverse.py");sys.path.insert(0,str(PREP));from inverse import setup as start
    return start()
guard()
