from live import *

def paired_step(obj,solver,state,delta,drive,delta_drive,dt):
    moment=obj.moment(state)
    def dm(u,du):return ((obj.sky(du).conj()*obj.sky(2*u+du)).real)@obj.wave.weights
    from matched_io import advance
    end,end_m,mid,phi_o=advance(obj,solver,state,moment,drive,dt)
    midpoint=delta.copy();delta_m=dm(state,delta);dmend=delta_m
    for i in range(40):
        diff_phi=obj.phi(.5*(delta_m+dmend));new_drive=drive+delta_drive+phi_o+diff_phi-solver.pref
        candidate=solver.factor.solve(delta-.5j*dt*(obj.multiply(new_drive,midpoint)+obj.multiply(delta_drive+diff_phi,mid)))
        updated=2*candidate-delta
        err=np.linalg.norm(candidate-midpoint);midpoint=candidate;dmend=dm(end,updated)
        if err<=2e-13*max(np.linalg.norm(candidate),1e-40):break
    else:raise RuntimeError("paired midpoint not converged")
    return end,updated

def run(src,tiny,steps):
    lab,Ev,_,_,shape=setup();obj=lab.obj;bg=obj.bg;unit=obj.unit_myr;obs=Ball(lab,shape)
    old=[lab.run.fields[k] for k in (586,590)];ext=external(lab,src+".npz");diff=[nn-oo for nn,oo in zip(ext,old)]
    dur=lab.run.ages[590]-lab.run.ages[586];ctr,vel,A=geometry()
    with np.load(HOME/"centre-force-change.npz") as b:dacc=b["delta"]/(977.7922216807892**2);oldacc=b["old"]/(977.7922216807892**2)
    project=lambda v:np.r_[v[0]*ctr[:2]/np.linalg.norm(ctr[:2]),v[1]]
    dacc,oldacc=map(project,(dacc,oldacc))
    first=2.**(-tiny);dt=first/steps
    jets=rows(HOME/f"derivatives-{src}-4-280.csv");result=[]
    with np.load(pin(PREP,"states-586-280.npz")) as bank:
        for key in bank.files:
            guard();state=bank[key].copy();delta=state*0;number=np.vdot(state,state).real;solver=Ev(obj,dt/unit,state)
            for step in range(4*steps):
                frac=(step+.5)*dt/dur
                drive=old[0]+frac*(old[1]-old[0]);dd=diff[0]+frac*(diff[1]-diff[0])
                state,delta=paired_step(obj,solver,state,delta,drive,dd,dt/unit)
                if step+1 not in (steps,2*steps,4*steps):continue
                t=(step+1)*dt;loc=ctr+vel*t+.5*oldacc*t*t;dx=.5*dacc*t*t
                for shell in (1,2,3):
                    actual=obs.operator(loc+dx,A*shell,24)(delta,2*state+delta).real
                    frame=obs.operator(loc+.5*dx,A*shell,24,direction=dx)(state,state).real
                    jet=next(row for row in jets if row["state"]==key and int(row["aperture"])==shell)
                    linear=float(jet["linear"]);curvature=float(jet["quadratic"]);measured=2*(actual+frame-linear*t)/t**2
                    result.append(dict(state=key,aperture=shell,t=t,wave=actual,observer=frame,delta=actual+frame,linear=linear,
                        curvature_after_linear=measured,derivative=curvature,relative=abs(measured/curvature-1),
                        paired_occupation=abs(np.vdot(delta,2*state+delta).real)/number))
    table(f"paired-{src}-h{tiny}-n{steps}.csv",result);print(tiny,steps,flush=True)

if __name__=="__main__":run(sys.argv[1],*map(int,sys.argv[2:]))
