from run_io import *
from scipy.special import roots_legendre,eval_legendre
from numpy.polynomial.legendre import legvander

def acc(at,phi,dr,ell):
    r=np.linalg.norm(at);mu=at[1]/r;pol=eval_legendre(ell,mu)
    slope=ell*(eval_legendre(np.maximum(0,ell-1),mu)-mu*pol)/(1-mu**2)
    unit=at/r
    return -unit*(dr@pol)-(np.array([0.,1.])-mu*unit)*(phi@slope)/r

def run():
    from global_newton import green
    ref=rows(pin(LAST,"independent-newton-q12.csv"))[:5];old=ROOT/"mts-pal5-positive-source-20261122"
    assert sha(old/"seal.json")=="c918bbe06f2a0be4785be9cf580dd91b493541fce8b4309d9a7622cc6248baf9"
    nm="native-continuous-forces.csv";assert sha(old/nm)==json.loads((old/"seal.json").read_bytes())[nm]
    centre=next(row for row in rows(old/nm) if row["case"]=="reset_forward" and row["source"]=="full")
    oldvec=np.array([float(centre[k]) for k in ("native_R","native_z")])
    exact=np.array([[float(row[k]) for k in ("a_R","a_z")] for row in ref])
    packet("centre-force-change.npz",delta=exact[0]-oldvec,old=oldvec,direct=exact[0])
    audit=[]
    for order in (5,9):
        with np.load(HOME/f"ordinary-q{order}.npz") as b:
            pts=b["probe"];pred=np.array([acc(at,v[:,0],d[:,0],b["degrees"]) for at,v,d in zip(pts[:5],b["probe_phi"][:5],b["probe_dr"][:5])])
            assert abs(b["probe_phi"][-1,0,0]*400/(-4.30091727003628e-6*b["mass"][0])-1)<1e-12
            for j,(val,target) in enumerate(zip(np.vstack((pred[0],pred[1:]-pred[0])),np.vstack((exact[0],exact[1:]-exact[0])))):
                audit.append(dict(q=order,point=j,radial=val[0],vertical=val[1],true_radial=target[0],true_vertical=target[1],relative=np.linalg.norm(val-target)/np.linalg.norm(target)))
    table("represented-force-vs-source.csv",audit)
    with np.load(HOME/"ordinary-q5.npz") as low,np.load(HOME/"ordinary-q9.npz") as high,np.load(HOME/"mesh.npz") as mesh:
        pol=legvander(mesh["mu"],68)[:,::2]
        matrix=[]
        for j in (0,1):
            aa=low["phi"][:,:,j]@pol.T;bb=high["phi"][:,:,j]@pol.T
            shift=bb-mesh["original"+str((586,590)[j])]
            matrix.append(dict(snap=(586,590)[j],field_relative=np.linalg.norm(aa-bb)/np.linalg.norm(bb),
               change_relative=np.linalg.norm(aa-bb)/np.linalg.norm(shift),maximum_kms2=np.max(abs(aa-bb))))
    table("represented-potential-refinement.csv",matrix)
    rr=np.array([0.,1.,2.,4.]);l=np.array([0,2]);ii=np.zeros((3,2,1));oo=np.zeros_like(ii);radius=1.5;mm=3.;component=np.array([mm,-.9])
    ii[1,:,0]=component*(radius/2)**l;oo[1,:,0]=component*(1/radius)**l/radius
    pot,der,_=green(rr,l,ii,oo,1)
    for ix,dist in enumerate(rr[1:],1):
        value=-component*(min(dist,radius)/max(dist,radius))**l/max(dist,radius)
        grad=value*(l if dist<radius else -l-1)/dist
        assert np.allclose(value,pot[ix,:,0]) and np.allclose(grad,der[ix,:,0])
    print(matrix,audit[-5:],flush=True)
if __name__=="__main__":run()
