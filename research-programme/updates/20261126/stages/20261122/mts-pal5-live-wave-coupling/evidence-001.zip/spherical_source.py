from run_io import *
from global_newton import green
from scipy.special import roots_legendre
from scipy.interpolate import CubicSpline
from numpy.polynomial.legendre import legvander

def main(q,stride):
    sys.path.insert(0,str(LAST))
    import sources as parent
    parent.table=lambda name,data:table("gains-check.csv",data)
    faces,shells,gains=parent.info()
    orig=parent.prior.original;src=parent.prior.source;G=parent.G
    with np.load(HOME/"mesh.npz") as mesh:rbase=mesh["r"];degrees=2*np.arange(int(mesh["degrees"][-1])+1)
    with np.load(HOME/"ordinary-q5.npz") as b:probe=b["probe"]
    targets=np.unique(np.r_[0.,rbase,np.hypot(*probe.T),230.])
    rcuts=np.unique(np.clip(np.r_[targets,src.radknots,src.stars.centres,shells,25,30,160,src.stars.H,160*np.sqrt(2),
        (np.array([*src.radknots,25,30,160])[:,None]/np.sqrt(1-faces[1:-1]**2)).ravel()],0,160*np.sqrt(2)))
    rings,rw=parent.quadrature(rcuts,q);node,wt=roots_legendre(q)
    shape=(len(targets)-1,len(degrees),2);inn=np.zeros(shape);out=np.zeros(shape)
    cg=np.linspace(0.,30.,15001);spline=CubicSpline(cg,orig.columns(cg),axis=0)
    tref=cg[::23]+.00071;tref=tref[tref<=30];ce=orig.columns(tref);error=np.max(abs(spline(tref)-ce),axis=0)/ce.max(axis=0)
    assert max(error)<1e-6,error
    phi,pw=parent.quadrature(np.array([0,np.pi/2]),32);pw*=2/np.pi
    zbreak=np.r_[src.stars.axis[::stride],src.stars.H,np.geomspace(.0004,160,64),160.]
    rbreak=np.unique(np.r_[src.radknots,src.stars.centres,src.stars.bgrid,30.,160.])
    mus=np.unique(np.r_[np.linspace(0,1,21),faces])
    for j,(r,weight) in enumerate(zip(rings,rw)):
        if j%160==0:guard()
        lo=np.sqrt(max(0,1-(160/r)**2));hi=min(1.,160/r)
        if not hi>lo:continue
        splits=np.unique(np.clip(np.r_[lo,hi,mus,zbreak/r,np.sqrt(np.maximum(0,1-(rbreak/r)**2))],lo,hi))
        du=np.diff(splits)[:,None]/2
        mu=(splits[:-1,None]+du*(1+node)).ravel();mw=(du*wt).ravel()
        cyl=r*np.sqrt(1-mu**2);alt=r*mu
        cols=spline(np.minimum(30.,cyl))*(cyl<30)[:,None];donors=orig.supply(cyl);shares=donors/np.maximum(1e-25,donors.sum(axis=1))[:,None]
        density=src.disk(cyl,alt)+sum(v*orig.zshape(k,alt) for k,v in zip(orig.ls.S22,cols.T))-cols.sum(axis=1)*sum(shares[:,k]*src.starshape(alt,k) for k in range(4))
        density+=src.stars.bmass*(orig.ls.old.density("E3",(.67,.29,.27),cyl[:,None]*np.cos(phi),cyl[:,None]*np.sin(phi),alt[:,None])@pw)
        assert min(density)>=0,density.min()
        gain=gains[:,np.searchsorted(shells,r,side="right")-1,np.searchsorted(faces[1:-1],mu)]
        mw*=density*weight*4*np.pi*r*r
        dm=legvander(mu,int(degrees[-1]))[:,::2].T@(mw[:,None]*(1+np.clip((30-r)/5,0,1)*(gain.T-1)))
        cell=targets.searchsorted(r,side="right")-1
        inn[cell]+=(r/targets[cell+1])**degrees[:,None]*dm
        out[cell]+=(targets[cell]/r)**degrees[:,None]*dm/r
    psi,dr,mass=green(targets,degrees,inn,out,G)
    ids=targets.searchsorted(rbase);pid=targets.searchsorted(np.hypot(*probe.T))
    packet(f"spherical-{q}-{stride}.npz",target=rbase,degrees=degrees,phi=psi[ids],dr=dr[ids],probe=probe,probe_phi=psi[pid],probe_dr=dr[pid],mass=mass[-1,0],column_rel=error)
    print(q,stride,len(rings),mass[-1,0],flush=True)
if __name__=="__main__":main(*map(int,sys.argv[1:]))
