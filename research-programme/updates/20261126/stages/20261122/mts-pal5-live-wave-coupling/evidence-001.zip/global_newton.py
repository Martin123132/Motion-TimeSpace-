from run_io import *
from scipy.special import roots_legendre
from numpy.polynomial.legendre import legvander

def main(order):
    for name in ("sources.py","ledger.py"):pin(LAST,name)
    sys.path.insert(0,str(LAST))
    from sources import prior,groups,quadrature,G,positions
    from sources import info as original_info
    import sources
    sources.table=lambda name,data:table("gains-check.csv",data)
    faces,shells,gains=original_info()
    src=prior.source;orig=prior.original
    with np.load(HOME/"mesh.npz") as mesh:rbase=mesh["r"];degrees=2*np.arange(1+int(mesh["degrees"][-1]))
    r0,z0,_=positions("reset_forward");scale=.019235279
    probe=np.array([[r0,z0],[r0+scale,z0],[r0-scale,z0],[r0,z0+scale],[r0,z0-scale],[160.,0],[400.,0]])
    targets=np.unique(np.r_[0,rbase,np.hypot(*probe.T),230.])
    lower,upper=targets[:-1],targets[1:];shape=(len(targets)-1,len(degrees),2)
    inn=np.zeros(shape);out=np.zeros(shape)
    rcuts=np.unique(np.clip(np.r_[0.,np.arange(0.,30.01,.5),35.,40.,50.,65.,80.,110.,160.,
           src.radknots,src.stars.centres,shells,25,30,np.hypot(r0,z0),r0],0,160))
    cyl,wc=quadrature(rcuts,order)
    cols=orig.columns(cyl)*(cyl<30)[:,None];donor=orig.supply(cyl);shares=donor/np.maximum(1e-25,donor.sum(axis=1))[:,None]
    zbase=np.r_[0.,src.stars.axis[::2],src.stars.H,np.geomspace(.0005,160.,75),4,5,8,12,16,24,40,60,80,110,160]
    az,wa=quadrature(np.array([0.,np.pi/2]),32)
    mass0=np.zeros(2);minrho=float("inf")
    for j,(c,w) in enumerate(zip(cyl,wc)):
        if j%64==0:guard()
        breaks=np.unique(np.clip(np.r_[zbase,np.sqrt(np.maximum(0,np.r_[targets,shells,25.,30.]**2-c*c)),c*faces[1:-1]/np.sqrt(1-faces[1:-1]**2)],0,160))
        alt,wz=quadrature(breaks,order)
        raw=src.disk(np.array([c]),alt)+sum(v*orig.zshape(k,alt) for v,k in zip(cols[j],orig.ls.S22))-cols[j].sum()*sum(shares[j,k]*src.starshape(alt,k) for k in range(4))
        raw+=src.stars.bmass*(orig.ls.old.density("E3",(.67,.29,.27),c*np.cos(az),c*np.sin(az),alt[:,None])@(wa*2/np.pi))
        minrho=min(minrho,raw.min());s=np.hypot(c,alt);mu=alt/s
        strength=gains[:,np.searchsorted(shells,s,side="right")-1,np.searchsorted(faces[1:-1],mu)]
        mass=(4*np.pi*c*w*wz*raw)[:,None]*(1+np.clip((30-s)/5,0,1)[:,None]*(strength.T-1))
        mass0+=mass.sum(axis=0);cell=targets.searchsorted(s,side="right")-1
        bins,ix=np.unique(cell,return_index=True);pol=legvander(mu,int(degrees[-1]))[:,::2]
        for block,rat,measure in ((inn,s/upper[cell],mass),(out,lower[cell]/s,mass/s[:,None])):
            power=pol*(rat[:,None]**degrees)
            for snap in (0,1):block[bins,:,snap]+=np.add.reduceat(power*measure[:,snap,None],ix,axis=0)
    assert minrho>=0
    phi,dr,moments=green(targets,degrees,inn,out,G)
    assert np.allclose(mass0,moments[-1,0],rtol=1e-12)
    idx=np.searchsorted(targets,rbase);selected=targets.searchsorted(np.hypot(*probe.T))
    assert np.array_equal(targets[idx],rbase)
    packet(f"ordinary-q{order}.npz",target=rbase,degrees=degrees,phi=phi[idx],dr=dr[idx],probe=probe,
        probe_phi=phi[selected],probe_dr=dr[selected],mass=mass0)
    print(order,mass0,flush=True)

def green(targets,degrees,inside,outside,G):
    lower,upper=targets[:-1],targets[1:];shape=(len(targets),)+inside.shape[1:]
    accumulated=np.zeros(shape);external=np.zeros(shape)
    for k in range(len(lower)):
        fac=(lower[k]/upper[k])**degrees[:,None]
        accumulated[k+1]=accumulated[k]*fac+inside[k]
    for k in reversed(range(len(lower))):
        external[k]=external[k+1]*(lower[k]/upper[k])**degrees[:,None]+outside[k]
    radius=np.where(targets>0,targets,1.)[:,None,None];ell=degrees[:,None]
    return -G*(accumulated/radius+external),G*((ell+1)*accumulated/radius-ell*external)/radius,accumulated
if __name__=="__main__":main(int(sys.argv[1]))
