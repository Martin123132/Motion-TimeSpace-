from run_io import *
from numpy.polynomial.legendre import legvander

def main():
    lab,_,_,_,_=setup();obj=lab.obj;bg=obj.bg
    vel=bg.vel;length=bg.length
    sums={}
    for snap in (586,590):
        total=(lab.mesh.ordinary+lab.run.fields[snap])*vel**2
        sums[f"original{snap}"]=total
    packet("mesh.npz",r=bg.rad*length,mu=bg.mu,weights=bg.aw,degrees=bg.orders,vel=vel,length=length,unit_myr=obj.unit_myr,
        left=lab.run.el.left*length,right=lab.run.el.right*length,number=obj.number,**sums)
    for snap in (586,590):
        projected=legvander(bg.mu,68)[:,::2]
        matrix=projected.T@(bg.aw[:,None]*projected)
        vals=np.linalg.solve(matrix,projected.T@(bg.aw[:,None]*sums[f"original{snap}"].T)).T
        print(snap,'represented projection residual',np.linalg.norm(vals@projected.T-sums[f"original{snap}"])/np.linalg.norm(sums[f"original{snap}"]))
    checks=[]
    for label,vec in (("reset",lab.initial["reset"]),("coupled",lab.initial["coupled"])):
        acted=(obj.bare-lab.mesh.kin)@vec
        ordinary=obj.multiply(lab.mesh.ordinary,vec)
        diff=acted-ordinary
        shift=np.vdot(vec,diff)/np.vdot(vec,vec)
        residual=np.linalg.norm(diff-shift*vec)/np.linalg.norm(ordinary)
        assert abs(shift.imag)<1e-10 and residual<1e-9
        checks.append(dict(arm=label,common_energy_offset=shift.real,residual=residual))
    table("bare-operator-check.csv",checks)
if __name__=="__main__":main()
