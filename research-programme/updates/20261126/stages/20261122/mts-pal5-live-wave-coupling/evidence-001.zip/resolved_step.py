from run_io import *
from ball import geometry
from scipy.special import eval_legendre,jv,roots_legendre,gammaln
from scipy.ndimage import convolve1d
from numpy.polynomial import chebyshev as ch
from numpy.polynomial.legendre import legvander
from functools import lru_cache

def kernel(x):
    for cut in range(2,300):
        if x/(2*cut+4)>=1:continue
        bound=2*np.exp((cut+1)*np.log(x/2)-gammaln(cut+2)+x*x/(4*(cut+2)))/(1-x/(2*cut+4))
        if bound<1e-20:break
    else:raise ValueError(x)
    n=np.abs(np.arange(-cut,cut+1))
    weights=np.exp(-1j*x)*1j**n*jv(n,x)
    assert abs(sum(weights)-1)<5e-14
    return weights,bound

def propagate(arr,ker,mode="constant"):
    return convolve1d(convolve1d(arr,ker,axis=0,mode=mode),ker,axis=1,mode=mode)

def integrate_grid(Rc,scale,n,mid,extent,q):
    h=scale/n;radius=extent*scale;out=np.zeros((2*mid+1,2*mid+1))
    nodes,w=roots_legendre(q)
    offsets=h*np.arange(-extent*n,extent*n+1)
    limits=np.unique(np.r_[offsets,np.sqrt(np.maximum(0,radius**2-offsets**2)),-np.sqrt(np.maximum(0,radius**2-offsets**2))])
    span=np.diff(limits)[:,None]/2;xx=(limits[:-1,None]+span*(1+nodes)).ravel();wx=(span*w).ravel()
    for x,wr in zip(xx,wx):
        b=np.sqrt((radius-x)*(radius+x))
        if b<=0 or wr<=0:continue
        inside=offsets[(offsets>-b)&(offsets<b)]
        cuts=np.r_[-np.pi/2,np.arcsin(inside/b),np.pi/2];step=np.diff(cuts)[:,None]/2
        angle=cuts[:-1,None]+step*(1+nodes);z=b*np.sin(angle);c=np.cos(angle);rr=Rc+x
        width=4*rr*np.arcsin(b*c/(2*np.sqrt(Rc*rr)))
        weights=(wr*step*w*b*c*width).ravel();scaled=z.ravel()/h+mid
        j=np.floor(scaled).astype(int);fy=scaled-j;ir=int(np.floor(x/h+mid));fx=x/h+mid-ir
        vals=np.bincount(j,weights*(1-fy),minlength=out.shape[1])+np.bincount(j+1,weights*fy,minlength=out.shape[1])
        out[ir]+=(1-fx)*vals;out[ir+1]+=fx*vals
    assert abs(out.sum()/(4*np.pi*radius**3/3)-1)<1e-9
    return out

def data(n,tmax):
    for nm in ("local_release_field.py","wave_response.py","small-586-14-32.json","wave-elements.npz"):pin(LAST,nm)
    sys.path.insert(0,str(LAST))
    from local_release_field import LocalField,value
    from wave_response import Density,archived
    xyz,v,scale=geometry();rc=np.hypot(*xyz[:2]);zc=xyz[2];h=scale/n
    with np.load(HOME/"mesh.npz") as m:kappa=float(m["length"]*m["vel"]/977.7922216807892)
    conv=1/977.7922216807892;halo=len(kernel(tmax*kappa/h**2)[0])//2+2;mid=3*n+halo
    step=h*np.arange(-mid,mid+1)
    assert max(abs(step))<4*scale
    R,Z=np.meshgrid(rc+step,zc+step,indexing="ij");tensor_shape=R.shape
    old=archived.Material();patch=LocalField("small",14,32);coeff=np.array(json.loads(pin(LAST,"small-586-14-32.json").read_bytes()))
    dens=Density();keys=[k for k in dens.states if k.endswith("_280")]
    wave=np.zeros((len(keys),R.size),dtype=complex);base=np.zeros((len(keys),R.size));change=np.zeros(R.size)
    join=ROOT/"mts-pal5-joined-flow-586-600-20261122";assert sha(join/"seal.json")=="86d9b1296c253b14a04e475339a9cbf71f84fed201749a234af4892b715576b7"
    co={}
    for prep in ("reset","coupled"):
        name=f"early-280-{prep}.npz";assert sha(join/name)==json.loads((join/"seal.json").read_bytes())[name]
        with np.load(join/name) as b:
            rad=b["radius"];assert abs(b["time"][0])<1e-12
            for sign in ("forward","reverse"):co[prep+"_"+sign]=b[prep+"_"+sign][0,...,0]
    for start in range(0,R.size,512):
        cut=slice(start,start+512);r=R.ravel()[cut];z=Z.ravel()[cut];ds=np.hypot(r,z);mu=z/ds
        pol=legvander(mu,68)[:,::2]
        original=np.sum(old.radial(ds,(586,590),0,0)[0]*pol,axis=1)
        fixed=value(coeff,(r-rc)/patch.scale,(z-zc)/patch.scale)-patch.off[0]*(r-rc)-patch.off[1]*(z-zc)
        change[cut]=(fixed-original)*conv**2
        rr=ds/dens.length;ix=np.searchsorted(dens.right,rr);u=2*(rr-dens.left[ix])/(dens.right[ix]-dens.left[ix])-1
        lift=ch.chebvander(u,len(dens.knots)-1)@dens.inv
        harmonic=pol[:,:len(dens.degrees)]*np.sqrt(2*dens.degrees+1);idx=np.searchsorted(rad,ds)-1
        width=rad[idx+1]-rad[idx];u=(ds-rad[idx])/width
        for jj,key in enumerate(keys):
            wave[jj,cut]=np.sqrt(r*dens.mscale/(4*np.pi*dens.length))/ds*np.einsum("ti,til,tl->t",lift,dens.states[key][ix],harmonic)
            bank=co[key.removesuffix("_280")];low=bank[idx];high=bank[idx+1];weight=u[:,None]
            mode=((1+2*weight)*low[:,:,0]+weight*width[:,None]*low[:,:,1])*(1-weight)**2+((3-2*weight)*high[:,:,0]-(1-weight)*width[:,None]*high[:,:,1])*weight**2
            base[jj,cut]=(original+np.sum(mode*pol,axis=1))*conv**2-kappa*kappa/(8*r*r)
    shape=(len(keys),)+tensor_shape;base=base.reshape(shape);change=change.reshape(tensor_shape)
    return scale,h,R,wave.reshape(shape),base-base[:,mid:mid+1,mid:mid+1],change-change[mid,mid],kappa,keys,mid

def main(n):
    times=np.array([.125,.0625,.03125])*1e-6
    scale,h,R,wave,old,delta,kappa,keys,mid=data(n,max(times))
    output=[];volumes={}
    for q in (4,8):
        for shell in (1,2,3):volumes[q,shell]=integrate_grid(R[mid,mid],scale,n,mid,shell,q)
    predictions=rows(pin(LAST,"initial-wave-feedback.csv"))
    for t in times:
        ker,bound=kernel(kappa*t/h**2)
        kick=np.expm1(-.5j*t/kappa*delta)
        for i,key in enumerate(keys):
            guard()
            before=wave[i]*np.exp(-.5j*t/kappa*old[i]);a=propagate(before,ker);da=propagate(before*kick,ker)
            aligned=(da-a*kick)/(1+kick)
            dmass=(2*(aligned.conj()*a).real+abs(aligned)**2)/R
            for shell in (1,2,3):
                prediction=next(row for row in predictions if row["patch"]=="chart" and row["rule"]=="24" and row["wave_steps"]=="280" and row["prep"]+"_"+row["flow"]+"_280"==key and int(row["aperture"])==shell)
                for q in (4,8):
                    vol=volumes[q,shell]
                    mass=np.sum(abs(wave[i])**2*vol/R);value=2*np.sum(vol*dmass)/t**2
                    observer=float(prediction["com_term_Msun_Myr2"]);direct=float(prediction["fixed_frame_Msun_Myr2"])
                    output.append(dict(state=key.removesuffix("_280"),shell=shell,q=q,h_pc=h*1000,time_year=t*1e6,
                       initial_mass=mass,mass_relative=abs(mass/float(prediction["wave_mass_Msun"])-1),fixed_density_step=value,
                       fixed_target=direct,relative=abs(value/direct-1),plus_observer_derivative=value+observer,
                       bessel_l1_tail_bound=bound,kernel_radius_cells=len(ker)//2))
    table(f"resolved-density-n{n}.csv",output);print(n,max(row["relative"] for row in output),flush=True)
if __name__=="__main__":main(int(sys.argv[1]))
