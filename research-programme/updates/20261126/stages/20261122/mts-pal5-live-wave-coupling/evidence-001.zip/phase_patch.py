from run_io import *
from ball import geometry
from numpy.polynomial import chebyshev as ch
from scipy.special import eval_legendre

def main():
    for nm in ("local_release_field.py","wave_response.py","wave-elements.npz","small-586-14-32.json"):pin(LAST,nm)
    sys.path.insert(0,str(LAST))
    from local_release_field import LocalField,value
    from wave_response import Density,sphere,archived
    centre3,_,A=geometry();R0=np.hypot(*centre3[:2]);centre=np.array([R0,0,centre3[2]])
    conv=1/977.7922216807892
    with np.load(HOME/"mesh.npz") as mesh:kappa=mesh["length"]*mesh["vel"]*conv
    from types import SimpleNamespace
    mat=archived.Material();old=archived.Field(SimpleNamespace(end=88.968349,rad=np.array([2.,35.])),mat,(586,590),"ordinary")
    patch=LocalField("small",14,32);coeff=np.array(json.loads(pin(LAST,"small-586-14-32.json").read_bytes()));density=Density()
    change=patch.force(0,centre[None,:])[0]*conv**2-old.components(0,centre[None,:])[0][0]
    def potential(p):
        r=np.linalg.norm(p,axis=1);mu=p[:,2]/r;cyl=np.hypot(p[:,0],p[:,1]);ur=(cyl-R0)/patch.scale;vz=(p[:,2]-centre[2])/patch.scale
        assert max(abs(ur))<1 and max(abs(vz))<1
        fixed=value(coeff,ur,vz)-patch.off[0]*(cyl-R0)-patch.off[1]*(p[:,2]-centre[2])
        represented=mat.radial(r,(586,590),0,0)[0]
        before=np.sum(represented*eval_legendre(2*np.arange(represented.shape[1]),mu[:,None]),axis=1)
        return (fixed-before)*conv**2+(p-centre)@change
    def amplitude(p):
        r=np.linalg.norm(p,axis=1);mu=p[:,2]/r;rad=r/density.length
        idx=np.searchsorted(density.right,rad);local=2*(rad-density.left[idx])/(density.right[idx]-density.left[idx])-1
        basis=ch.chebvander(local,len(density.knots)-1)@density.inv
        ang=eval_legendre(density.degrees[None,:],mu[:,None])*np.sqrt(2*density.degrees+1)
        return np.stack([np.sqrt(density.mscale/(4*np.pi*density.length))*np.einsum("ti,til,tl->t",basis,nodes[idx],ang)/r for key,nodes in density.states.items() if key.endswith("280")])
    keys=[x.removesuffix("_280") for x in density.states if x.endswith("280")]
    split=np.unique(np.r_[old.edges,density.right*density.length]);out=[]
    for shell in (1,2,3):
        radius=shell*A
        for order in (12,24):
            unit,wa=sphere(radius,centre,split,order);p=centre+radius*unit
            phi=potential(p);ref=amplitude(p)
            guard()
            r=np.linalg.norm(p,axis=1)
            gap=np.min(abs(r[:,None]-split),axis=1)
            for step in (.0005,.00025,.000125):
                stepvec=np.minimum(step,.24*gap);assert stepvec.min()>1e-12
                offset=unit*stepvec[:,None]
                upper,lower=amplitude(p+offset),amplitude(p-offset);dp=potential(p+offset)-phi;dm=potential(p-offset)-phi
                for tau in (-1.,1.):
                    kickp=np.expm1(-1j*tau*dp/kappa);kickm=np.expm1(-1j*tau*dm/kappa)
                    current=kappa/(2*stepvec)*(ref.conj()*(upper*kickp-lower*kickm)).imag/tau
                    mass=-4*np.pi*radius**2*(current@wa)
                    for key,val in zip(keys,mass):
                        out.append(dict(aperture=shell,order=order,stencil_pc=step*1000,kick_Myr=tau,state=key,
                            phase_readout_Msun_Myr2=val,max_unitarity_error=max(np.max(abs(abs(1+kickp)-1)),np.max(abs(abs(1+kickm)-1)))))
    table("resolved-phase-current.csv",out)
if __name__=="__main__":main()
