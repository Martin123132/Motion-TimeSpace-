from local import *
from material_overlap import Readout
from transport import Kinetic

ids=list(range(-52,25,2))
def run(model,trace):
    kinetic=Kinetic(model,2,ids);flow=Readout(model,trace);rows=[]
    with np.load(DIR/f'forward-{model}-{int(trace)}.npz') as f:t=f['eta'];obs=f['obs'];N=f['normal']
    base=obs.copy();past=None;st0=None
    for rep in range(3):
        guard();tt,dx=kinetic.calculate(t,obs,N);st=kinetic.stress(tt,dx)
        if rep==0:
            st0=st;seed_dx=dx.copy()
        t,obs,N,states=flow.evolve(tt,st)
        corr=obs-base
        for i,mode in enumerate(PROBES):
            for idx,tag in enumerate(('phi','psi','weyl','etaF')):
                for case in range(2):
                    arr=corr[:,idx,i,case];ref=base[:,idx,i,case]
                    rows.append(dict(iteration=rep+1,mode=str(mode),case=case,metric=tag,
                                     max_relative=max(abs(arr/ref)),end_relative=abs(arr[-1]/ref[-1]),
                                     delta_max_in_units_signal=(max(abs(obs[:,idx,i,case]-past[:,idx,i,case]))/max(abs(arr))) if rep and max(abs(arr)) else None))
        if rep==0:pack(f'first-correction-{model}-{int(trace)}.npz',eta=t,obs=obs)
        past=obs.copy()
    normal=N[-1][None]+(kinetic.w+4)[:,None,None,None]*kinetic.Z[-1][None,:,:,None]+dx[-1]
    pack(f'coupled-{model}-{int(trace)}.npz',eta=t,obs=obs,nu=N,state=states[-1],keys=flow.keys,stress_t=tt,stress=st,initialStress=st0,
         q=kinetic.q,normalEnd=normal,firstDeltaEnd=seed_dx[-1],deltaEnd=dx[-1],shape=kinetic.Z[-1],k=kinetic.k)
    table(f'iterations-{model}-{int(trace)}.csv',rows)
    if trace:return
    tests=[]
    for time in (1.6,3.2):
        idx=int(np.flatnonzero(kinetic.t==time)[0])
        tr,back=kinetic.calculate(t,past,N,idx,restart=dx[idx]);_,fresh=kinetic.calculate(t,past,N,idx)
        continued=kinetic.stress(tr,back);reset=kinetic.stress(tr,fresh)
        zero_s=np.zeros_like(st);zero_s[idx:]=reset
        for j,mode in enumerate(PROBES):
            for component,key in enumerate(('energy','current','shear','trace')):
                for case in range(2):
                    r=st[idx:,component,j,case];den=max(abs(r))
                    tests.append(dict(start=time,mode=str(mode),case=case,component=key,restart_peak_relative=max(abs(continued[:,component,j,case]-r))/den,
                       reset_peak_relative=max(abs(reset[:,component,j,case]-r))/den,reset_end_fraction=abs(reset[-1,component,j,case]-r[-1])/max(abs(r[-1]),1e-80)))
        pack(f'overlap-{model}-{time:g}.npz',eta=tr,continued=continued,fresh=reset,deltaStart=dx[idx],deltaEnd=back[-1])
    table(f'overlap-check-{model}.csv',tests)
if __name__=='__main__':run(sys.argv[1],bool(int(sys.argv[2])))
