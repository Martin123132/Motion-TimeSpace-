from local import *
import ast
def rows(name):
    with (DIR/name).open() as fp:return list(csv.DictReader(fp))
def audit():
    guard();stats=[]
    def gate(test,count,value,tol):
        assert count>0 and np.isfinite(value) and value<tol,(test,value,tol)
        stats.append(dict(check=test,count=int(count),maximum=float(value),threshold=tol))
    for path in DIR.glob('*.py'):ast.parse(path.read_text(encoding='utf-8'))
    for model in ('cold','heavy'):
        def check(name,col,tol,**filters):
            data=[r for r in rows(name) if all(r[k]==str(v) for k,v in filters.items())]
            gate(name+'/'+str(filters)+'/'+col,len(data),max(float(r[col]) for r in data),tol)
        def inrows(name,test,col,tol):check(name+'-'+model+'.csv',col,tol,test=test)
        for tag in ('39 vs 77 momentum nodes','leading vs 77 momentum nodes','gravity 39 vs 77','leading vs 77 gravity'):
            for key in ('peak','endpoint'):inrows('fine-grid',tag,key,.005)
        for j in ('energy','momentum'):
            check('conservation-'+model+'-s2.csv','max_rel_to_correction',.005,test='all',equation=j)
        for key in ('Ward_residual','Ward_endpoint'):check('ward-check-'+model+'-s2-dense.csv',key,.005)
        check('overlap-check-'+model+'.csv','restart_peak_relative',.005)
        inrows('retarded-overlap','endpoint','worst_moment',.005)
        inrows('microscopic-controls','log momentum derivative','relative',.005)
        inrows('microscopic-controls','zero mass operator','relative',1e-12)
        check('native-linear-check-'+model+'.csv','vs_native',.005)
        for tag in ('q tails','time doubled'):inrows('integration',tag,'end',.005)
        assert any(float(r['end'])>.005 for r in rows('integration-'+model+'.csv') if r['test']=='q coarse')
        assert max(float(r['raw_route_disagreement']) for r in rows('ward-check-'+model+'-s2-dense.csv'))>1
        for trace in (0,1):
            check('iterations-'+model+f'-{trace}.csv','delta_max_in_units_signal',.005,iteration=3)
        with np.load(DIR/f'fine-{model}.npz') as f:
            assert np.isfinite(f['normalEnd']).all() and f['normalEnd'].shape==(77,19,5,2) and np.array_equal(f['q'],2.**(np.arange(-52,25)/4))
            assert np.array_equal(f['k'],np.load(checked(f'forcing-{model}.npz'))['k'])
            w=1-f['q']*np.tanh(f['q']/2)
            total=f['commonN'][None]+(w+4)[:,None,None,None]*f['shape'][None,:,:,None]+f['massLag']
            assert np.array_equal(total,f['normalEnd'])
        for i in range(-52,25):
            with np.load(DIR/f'kin-{model}-s2-q{i}.npz') as f:
                assert f['id']==i and f['incidentEnd'].shape==(27,782) and np.all(np.isfinite(f['slopeEnd']))
    counts=rows('primordial-contrast.csv');assert len(counts)==5*2*4*5*3
    for version in ('exact','finer','independent trace','native transfer'):
        subset=[r for r in counts if r['version']==version and r['clock']=='scale factor' and r['rule']=='separate']
        for panel in ('endpoint Weyl','endpoint pair'):gate('saturated '+version+' '+panel,5,max(float(r['fraction_of_forced']) for r in subset if r['panel']==panel),1e-8)
        assert all(float(r['fraction_of_forced'])>.5 for r in subset if r['panel']=='three pairs')
    assert max(float(r['change_of_residual_vector_over_residual']) for r in rows('contrast-sensitivity.csv'))>.005
    for name in ('common 16/6','common 12/4','finest'):
        data=[r for r in rows('contrast-matched-angular.csv') if r['model']==name]
        gate('matched contrast '+name,len(data),max(float(r['residual_vector_change']) for r in data),.005)
    table('verification.csv',stats)
    assert not any(p.is_dir() for p in DIR.iterdir())
    files_now={p.name:sha(p) for p in sorted(DIR.iterdir()) if p.is_file() and p.name!='seal.json'}
    body={'stage':'momentum-resolved-early-gravity','predecessor_sha256':sha(PRIOR/'seal.json'),'files':files_now}
    if '--verify' in sys.argv:assert json.loads((DIR/'seal.json').read_bytes())==body
    else:save('seal.json',(json.dumps(body,indent=2)+'\n').encode())
    print(len(stats),'groups;',len(files_now),'files;',sha(DIR/'seal.json'))
if __name__=='__main__':audit()
