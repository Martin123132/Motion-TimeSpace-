from local import *
from transport import Kinetic
from material_overlap import Readout

def run(model,stride=2,dense=False):
    ids=list(range(-52,25,2 if stride==2 else 4));kin=Kinetic(model,stride,ids)
    with np.load(DIR/f'forward-{model}-0.npz') as base:t=base['eta'];obs=base['obs'];N=base['normal']
    with np.load(DIR/f'forward-{model}-1.npz') as ref:baseline_trace=ref['obs']
    with np.load(DIR/f'coupled-{model}-0.npz') as f:st=f['stress'];tm=f['stress_t'];target=f['obs']-obs
    with np.load(checked(f'forcing-{model}.npz')) as f:bg=dict(zip(f['bgkeys'],f['background']));k=f['k'][:,None];k2=k*k
    nodes=kin.q;mass=kin.mass;weights=np.full(len(nodes),np.log(nodes[1]/nodes[0]));weights[[0,-1]]/=2
    wt=weights*nodes**2*expit(nodes)*expit(-nodes);w=kin.w+4
    rr=[];residual=[]
    for i,u in enumerate(np.log(t)):
        h=bg['h'][i];a=bg['a'][i];am=a*mass;ep=np.hypot(nodes,am);diff=am**2/(ep+nodes);A=kin.coeff/a**2
        de=np.dot(wt,nodes**2*diff);ds=np.dot(wt,-nodes**3*diff/ep)
        direct=kin.src(u);sw=kin.sw(u)
        eSrc=((wt*nodes**2*ep)@direct[:,0]+np.dot(wt*w,nodes**2*diff)*sw[0])[:,None]
        jSrc=((wt*nodes**3)@direct[:,1])[:,None]
        rE=A*(eSrc+k*de*N[i,1])
        rJ=k*A*(jSrc+k/3*(ds*(N[i,0]-2*N[i,2])+de*obs[i,1]))
        geom=-(rE+3*h*rJ/k2)/(2*k2+3*(bg['et'][i]+bg['pt'][i]))
        flux=-rJ/(2*k2)
        rr.append([t[i]*geom,t[i]**2*flux]);residual.append([rE,rJ])
    if dense:
        with np.load(DIR/f'coupled-{model}-0.npz') as state:
            tm,dx=kin.calculate(t,state['obs'],state['nu'],output=t[::2]);st=kin.stress(tm,dx)
        _,full,_,end=Readout(model).evolve(tm,st)
        target=full-obs
    times,v,nn,end=Readout(model,True).evolve(tm,st,ward=(t,np.asarray(rr)))
    delta=v-baseline_trace
    if dense:
        _,raw,_,_=Readout(model,True).evolve(tm,st);uncorrected=raw-baseline_trace
    else:
        with np.load(DIR/f'coupled-{model}-1.npz') as f:uncorrected=f['obs']-baseline_trace
    rows=[]
    for key,tag in enumerate(('phi','psi','weyl','etaF')):
        for j,mode in enumerate(PROBES):
            for case in range(2):
                r=target[:,key,j,case];ref=max(abs(r));gap=uncorrected[:,key,j,case]-r
                after=delta[:,key,j,case]-r
                rows.append(dict(mode=str(mode),field=tag,case=case,reference_max=ref,raw_route_disagreement=max(abs(gap))/ref,
                                 Ward_residual=max(abs(after))/ref,Ward_endpoint=abs(after[-1])/abs(r[-1]),after_over_raw=max(abs(after))/max(abs(gap))))
    suffix=f'{model}-s{stride}'+('-dense' if dense else '')
    table(f'ward-check-{suffix}.csv',rows)
    payload={'stressClock':tm,'independentTarget':target} if dense else {}
    pack(f'ward-{suffix}.npz',eta=t,obs=v,delta=delta,source=np.array(rr),divergence=np.array(residual),fixedStress=st,**payload)
    print(model,'Ward correction relative error',max(r['Ward_residual'] for r in rows),'before',max(r['raw_route_disagreement'] for r in rows),flush=True)
if __name__=='__main__':run(sys.argv[1],2,'--dense' in sys.argv)
