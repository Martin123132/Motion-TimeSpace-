from local import *
from transport import Kinetic
from packets import environment,incident
from early_source import read_data

def check(model):
    with np.load(DIR/f'coupled-{model}-0.npz') as f:t=f['eta'];obs=f['obs'];N=f['nu'];qold=f['q']
    rows=[];nodes=[];refs={}
    for name,stride,ids in [('adopted',2,range(-52,25,2)),('q coarse',2,range(-52,25,4)),('time doubled',1,range(-52,25,4)),('q tails',2,range(-64,29,2))]:
        kin=Kinetic(model,stride,list(ids));tt,dx=kin.calculate(t,obs,N)
        st=kin.stress(tt,dx);ref=(st if name=='adopted' else refs['q coarse'] if name=='time doubled' else refs['adopted'])
        refs[name]=st
        mask=slice(None,None,max(1,2//stride));delta=st[mask]-ref
        for field,tag in enumerate(('energy','current','shear','trace')):
            for j,mode in enumerate(PROBES):
                for case in range(2):
                    r=ref[:,field,j,case];v=delta[:,field,j,case]
                    rows.append(dict(test=name,field=tag,mode=str(mode),case=case,max_on_peak=max(abs(v))/max(abs(r)),end=abs(v[-1])/abs(r[-1])))
        if name=='adopted':primary=dx
        for i,node in enumerate(ids):
            if node not in (-64,-52,-32,-16,0,8,24,28):continue
            q=kin.q[i];v=q/np.hypot(q,kin.mass*kin.af(np.log(tt[-1])));term=(kin.w[i]+4)*kin.Z[-1,:,:,None]+N[-1]
            nm=lambda x:np.linalg.norm(x,axis=0)
            nodes.append(dict(test=name,id=node,q=q,v_end=v,max_delta_over_same_q_relativistic=max((nm(dx[-1,i])/nm(term)).ravel()),
                              max_delta_over_brightness=max((nm(dx[-1,i])/nm(N[-1])).ravel())))
        if name=='time doubled':
            frac=np.linalg.norm(dx[-1]-primary[-1,::2],axis=1)/np.linalg.norm(dx[-1],axis=1)
            for i,node in enumerate(ids):nodes.append(dict(test='temporal convergence of delta',id=node,q=kin.q[i],v_end=kin.q[i]/np.hypot(kin.q[i],kin.mass*kin.af(np.log(tt[-1]))),
                                            max_delta_over_same_q_relativistic=frac[i].max(),max_delta_over_brightness=np.nan))
        if name=='adopted':
            _,no=kin.calculate(t,obs,N,regular=False)
            st_no=kin.stress(tt,no)
            rows.append(dict(test='origin finite dipole vs zero initial lag',field='joint',mode='all',case='both',
                            max_on_peak=abs(st_no-st).max()/abs(st).max(),end=abs(st_no[-1]-st[-1]).max()/abs(st[-1]).max()))
    table(f'integration-{model}.csv',rows);table(f'slow-bins-{model}.csv',nodes)
    print(model,'integration',[(v,max(r['max_on_peak'] for r in rows if r['test']==v)) for v in dict.fromkeys(r['test'] for r in rows)],flush=True)
def derivative(model):
    inc,proj,ref,K=environment(model,2);orig=inc.mass
    with np.load(DIR/f'base-{model}-s2.npz') as f:S=f['S'];Sw=f['Sw'];low=f['incident']
    rows=[]
    for q in (2.**-13,2.**-8,2.):
        guard();dh=.001
        minus=incident(inc,ref,q*np.exp(-dh))[0,:,:,-1];plus=incident(inc,ref,q*np.exp(dh))[0,:,:,-1]
        with np.load(DIR/f'kin-{model}-s2-q{int(round(4*np.log2(q)))}.npz') as f:D=f['slopeEnd']
        diff=(plus-minus)/(2*dh)
        for l in (0,1,2,3,10):
            rows.append(dict(test='log momentum derivative',q=q,ell=l,relative=np.linalg.norm(diff[l]-D[l])/np.linalg.norm(D[l])))
        if q==2.:continue
        inc.mass=0.;savea=inc.data.background['a'];inc.data.background['a']=savea*0
        F,DF=incident(inc,ref,q);null=proj.calculate(F,DF,q,maximum=18,match_bulk=False)[0]
        want=S+(5-q*np.tanh(q/2))*Sw
        rows.append(dict(test='zero mass operator',q=q,ell='all',relative=np.linalg.norm(null-want)/np.linalg.norm(want)))
        inc.mass=orig;inc.data.background['a']=savea
    table('microscopic-controls-'+model+'.csv',rows);print(model,'derivative',max(r['relative'] for r in rows),flush=True)
if __name__=='__main__':
    if sys.argv[2]=='derivative':derivative(sys.argv[1])
    else:check(sys.argv[1])
