from local import *
from types import SimpleNamespace
from incident import Incident
import time

def environment(model,stride):
    with np.load(checked(f'incident-input-{model}.npz')) as f:
        t=f['eta'][::stride];kn=f['k'];d={key:f[key][:,::stride] for key in ('phi','psi','pd')};ref=f['reference'][:,:,0]
    with np.load(checked(f'forcing-{model}.npz')) as f:
        bg=dict(zip(f['bgkeys'],f['background'][:,::stride]));k=f['k']
    from regular_io import pin
    data=SimpleNamespace(eta=t,model=model,nodes=kn,shell=np.array(json.loads(pin('legs.json').read_bytes())['squared_radii']),first=d,background=bg)
    inc=object.__new__(Incident);inc.data=data;inc.k=kn;inc.mass=json.loads(ti.parent.pin('radiation-background.json').read_bytes())[model]['mass_over_temperature']
    return inc,Project(data),ref,k

def incident(inc,ref,q):
    t=inc.data.eta;kn=inc.k;v=1. if np.isinf(q) else q/np.hypot(q,inc.mass*inc.data.background['a'][0])
    state=np.zeros((2,27,len(kn)))
    for ell in range(len(state[0])):
        state[0,ell]=ref[ell] if ell<3 else (kn*t[0])**ell*(ref[0]+inc.data.first['psi'][:,0])/factorial2(2*ell+1)
    state[0,1]/=v;state[1,1]=-(1-v*v)*state[0,1]
    state[0,0]-=inc.data.first['phi'][:,0]
    return inc.flight(q,state)

def base(model,stride):
    guard();inc,proj,ref,k=environment(model,stride);data=inc.data
    F,D=incident(inc,ref,np.inf);assert np.max(abs(D))==0
    S=proj.calculate(F,D,np.inf,maximum=18,match_bulk=False)[0];Sw=proj.calculate(F,F,np.inf,maximum=18,match_bulk=False)[0]-S
    indices=[0,64//stride,128//stride,192//stride,224//stride,256//stride,288//stride,320//stride]
    direct=np.array([[square(op,F[:,:,j],18,36,28) for op in proj.ops] for j in indices])*(-.5)
    pack(f'base-{model}-s{stride}.npz',eta=data.eta[::4],k=k,S=S,Sw=Sw,sites=indices,Z=direct,incident=F[:3],end=F[:,:,-1])
    print(model,stride,'common-speed bank',flush=True)

def run(model,stride,ids):
    guard();inc,proj,ref,K=environment(model,stride)
    with np.load(DIR/f'base-{model}-s{stride}.npz') as f:
        src=f['S'];der=f['Sw'];low=f['incident'];tt=f['eta']
    for node in ids:
        guard();name=f'kin-{model}-s{stride}-q{node}.npz'
        if (DIR/name).exists():
            with np.load(DIR/name) as b:
                assert b['id']==node and np.array_equal(b['eta'],tt) and np.isfinite(b['directDifference']).all() and b['directDifference'].shape==src.shape
            continue
        now=time.perf_counter();q=2.**(node/4);w=1-q*np.tanh(q/2)
        F,D=incident(inc,ref,q);direct=proj.calculate(F,D,q,maximum=18,match_bulk=False)[0]-src-(w+4)*der
        assert np.isfinite(direct).all() and len(tt)==direct.shape[-1]
        pack(name,id=node,q=q,w=w,k=K,eta=tt,directDifference=direct,lowDifference=F[:3]-low,lowSlope=D[:3],incidentEnd=F[:,:,-1],slopeEnd=D[:,:,-1])
        print(model,stride,node,'seconds',round(time.perf_counter()-now,1),flush=True)
if __name__=='__main__':
    model=sys.argv[1];stride=int(sys.argv[2])
    if sys.argv[3]=='base':base(model,stride)
    else:run(model,stride,list(range(*map(int,sys.argv[3:]))))
