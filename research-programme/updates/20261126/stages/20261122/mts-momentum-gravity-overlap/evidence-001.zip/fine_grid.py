from local import *
from transport import Kinetic
from material_overlap import Readout
def run(model):
    with np.load(DIR/f'coupled-{model}-0.npz') as f:t=f['eta'];obs=f['obs'];N=f['nu']
    with np.load(DIR/f'leading-frozen-{model}.npz') as f:lead=f['stress'];tt=f['eta']
    with np.load(DIR/f'ward-{model}-s2-dense.npz') as f:
        assert np.array_equal(tt,f['stressClock']);ref=f['fixedStress'];standard=f['independentTarget']
    kin=Kinetic(model,2,list(range(-52,25)));_,dx=kin.calculate(t,obs,N,output=tt)
    stress=kin.stress(tt,dx)
    tm,v,Nfull,end=Readout(model).evolve(tt,stress)
    with np.load(DIR/f'forward-{model}-0.npz') as f:baseline=f['obs']
    rows=[]
    def score(tag,keys,pred,target):
        for i,key in enumerate(keys):
            for j,mode in enumerate(PROBES):
                for case in range(2):
                    a=pred[:,i,j,case];b=target[:,i,j,case]
                    rows.append(dict(test=tag,quantity=key,mode=str(mode),case=case,peak=max(abs(a-b))/max(abs(b)),endpoint=abs(a[-1]-b[-1])/abs(b[-1])))
    score('39 vs 77 momentum nodes',('energy','current','shear','trace'),ref,stress)
    score('leading vs 77 momentum nodes',('energy','current','shear','trace'),lead,stress)
    score('gravity 39 vs 77',('phi','psi','weyl','etaF'),standard[:,:4],(v-baseline)[:,:4])
    _,vl,_,_=Readout(model).evolve(tt,lead)
    score('leading vs 77 gravity',('phi','psi','weyl','etaF'),(vl-baseline)[:,:4],(v-baseline)[:,:4])
    table('fine-grid-'+model+'.csv',rows)
    normal=Nfull[-1][None]+(kin.w+4)[:,None,None,None]*kin.Z[-1][None,:,:,None]+dx[-1]
    pack(f'fine-{model}.npz',eta=t,obs=v,normalEnd=normal,q=kin.q,massLag=dx[-1],shape=kin.Z[-1],state=end[-1],keys=Readout(model).keys,k=kin.k,
         stress=stress,stressClock=tt,commonN=Nfull[-1])
    print(model,[(test,max(r['peak'] for r in rows if r['test']==test),max(r['endpoint'] for r in rows if r['test']==test)) for test in dict.fromkeys(r['test'] for r in rows)])
if __name__=='__main__':run(sys.argv[1])
