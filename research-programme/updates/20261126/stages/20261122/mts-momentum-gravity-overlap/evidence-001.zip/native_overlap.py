from local import *
from early_source import read_data
def run(model):
    guard();d=read_data(model);bg=d.background;raw=d.raw
    ids=list(range(-64,29,2));q=2.**(np.array(ids)/4);wt=np.full(len(q),np.log(q[1]/q[0]));wt[[0,-1]]/=2
    Wq=wt*q*q*expit(q)*expit(-q)
    with np.load(DIR/f'base-{model}-s2.npz') as f:t=f['eta'];seed=f['incident']
    sl=slice(None,None,8);a=bg['a'][sl];meta=json.loads(ti.parent.pin('radiation-background.json').read_bytes())[model]
    am=a*meta['mass_over_temperature'];ep=np.hypot(q[:,None],am[None,:]);A=meta['massless_limit_coeff']/(7*np.pi**4/120*a*a)
    ds=0*seed[0];dj=ds.copy();vecE=ds.copy();vecJ=dj.copy()
    for i,node in enumerate(ids):
        with np.load(DIR/f'kin-{model}-s2-q{node}.npz') as f:assert np.array_equal(t,f['eta']);lag=f['lowDifference']
        measure=Wq[i]
        ds+=measure*q[i]**2*ep[i]*lag[0];dj+=measure*q[i]**3*lag[1]
        vecE+=measure*q[i]**2*(am**2/(ep[i]+q[i]))*seed[0]
    Crel=A*(7*np.pi**4/30)
    E=(vecE+ds)*A+seed[0]*Crel
    J=dj*A+seed[1]*Crel
    N0=bg['enu'][sl]*raw['clxnu'][:,sl]-3*bg['h'][sl]*bg['enm'][sl]*raw['sigma'][:,sl]/d.nodes[:,None]
    N1=bg['enm'][sl]*d.first['Vm'][:,sl]*d.nodes[:,None]
    rows=[]
    for field,our,native,control in [('energy',E,N0,E-A*ds),('flux',J,N1,J-A*dj)]:
        for ii in (0,40,80,120,144,160):
            denom=np.linalg.norm(native[:,ii]);err=lambda v:np.linalg.norm(v[:,ii]-native[:,ii])/denom
            rows.append(dict(field=field,time=t[ii],vs_native=err(our),common_speed_vs_native=err(control),change_norm=np.linalg.norm((our-control)[:,ii])/denom))
    table(f'native-linear-check-{model}.csv',rows)
if __name__=='__main__':
    for model in ('cold','heavy'):run(model)
