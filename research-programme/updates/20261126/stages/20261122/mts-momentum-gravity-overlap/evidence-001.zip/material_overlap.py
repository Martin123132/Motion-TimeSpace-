from local import *

class Readout(Flight):
    def __init__(self,model,trace=False):
        for fn in [f'{k}-{model}.npz' for k in ('forcing','radiation','collisionless','origin-v2')]:checked(fn)
        super().__init__(model,18,6,trace,True)
    def metric_add(self,u,stress):
        bg=dict(zip(self.bgkeys,self.bg(u)));k=self.k;kk=k*k;h=bg['h'];sc=sum(bg[t+'v']**2 for t in self.tags)
        jac=3*(bg['ec']+bg['eb']+sc)+4*(bg['eg']+bg['er'])+bg['nuE']
        flux=-stress[1]/(2*kk);phi=(-stress[0]/2+3*h*flux)/(kk+jac/2)
        slip=stress[2]/kk
        dp=0*phi if self.trace else phi;df=0*flux if self.trace else flux;ds=dp+slip
        return bg,phi,flux,slip,dp,df,ds
    def injection(self,u,stress):
        t=np.exp(u);k=self.k;kk=k*k;bg,con,jcon,slip,phi,flux,psi=self.metric_add(u,stress)
        h=bg['h'];ratio=bg['eb']/bg['eg'];rhs=np.zeros((self.n,*phi.shape),complex)
        put=lambda key,val:rhs.__setitem__(self.ix[key],val)
        if self.trace:
            put('geom',-flux-h*psi);put('flux',(bg['hp']-h*h)*psi-kk*slip/3+stress[3]/6)
        for tag in self.tags:
            put(tag+'f',bg[tag+'v']*(psi+3*phi))
            put(tag+'w',(bg['a']*bg[tag+'m'])**2*bg[tag+'b']*(3*phi-psi))
        put('ct',kk*psi);put('W',kk*(4*(phi+psi)/3+ratio*psi));put('B',kk*4*phi/3)
        put('N1',k*(phi+psi)/3)
        return (t*rhs/(self.factors*t**self.power[:,None,None])).transpose(1,0,2)
    def observe(self,u,y,stress):
        t=np.exp(u);state=y.transpose(1,0,2);val=self.jac_rhs(u,state,1.,True)
        bg,con,jcon,slip,phi,flux,psi=self.metric_add(u,stress)
        val[0]+=phi;val[1]+=psi;val[2]+=(phi+psi)/2;val[3]+=t*flux;val[4]+=con;val[5]+=t*jcon;val[6]+=phi;val[11]+=slip
        physical=state*(self.factors*t**self.power[:,None,None]);physical[:2]=[val[0],val[3]/t]
        nu=physical[self.ix['N0']:].copy();nu[0]+=val[0]
        return val,nu,physical
    def evolve(self,times=None,stress=None,step=1,ward=None):
        base=times is None;zero=np.zeros((4,5,2),complex)
        if not base:interp=CubicSpline(np.log(times),stress,axis=0)
        if ward is not None:
            assert self.trace
            extra=CubicSpline(np.log(ward[0]),ward[1],axis=0)
        def get(u):
            if base:return zero
            bg=dict(zip(self.bgkeys,self.bg(u)));v=interp(u)*bg['enu'];v[1]*=self.k;return v
        eye=np.eye(self.n);y=np.stack([self.launch(0,free).T for free in (0,1)],axis=-1)
        if self.trace and not base:
            _,pc,fc,*_=self.metric_add(self.log[0],get(self.log[0]));y[:,0]+=pc;y[:,1]+=fc*self.t[0]
        read=[];states=[];nu=[]
        for i in range(0,len(self.t),step):
            if i%128==0:guard()
            obs,norm,state=self.observe(self.log[i],y,get(self.log[i]));read.append(obs);states.append(state);nu.append(norm)
            if i+step>=len(self.t):break
            dt=self.log[i+step]-self.log[i];u=self.log[i]+dt/3;uend=self.log[i+step]
            first,bfirst=self.matrix(u);last,blast=self.matrix(uend)
            if not base:bfirst=bfirst+self.injection(u,get(u));blast=blast+self.injection(uend,get(uend))
            if ward is not None:
                bfirst[:,:2]+=extra(u).transpose(1,0,2);blast[:,:2]+=extra(uend).transpose(1,0,2)
            upper=np.concatenate((eye-5*dt*first/12,dt*last/12),axis=2);lower=np.concatenate((-3*dt*first/4,eye-dt*last/4),axis=2)
            right=np.concatenate((y+dt*(5*bfirst-blast)/12,y+dt*(3*bfirst+blast)/4),axis=1)
            y=np.linalg.solve(np.concatenate((upper,lower),axis=1),right)[:,self.n:]
        return self.t[::step],np.array(read),np.array(nu),np.array(states)
def run(model,trace):
    obj=Readout(model,trace);t,obs,N,state=obj.evolve()
    with np.load(checked(f'flight-radau-T1-{model}-1-18-{int(trace)}-6.npz')) as f:
        target=f['values'][:,:,:,:2];assert np.max(abs(obs[::16]-target)/np.maximum(abs(target),1e-100))<1e-10
    pack(f'forward-{model}-{int(trace)}.npz',eta=t,obs=obs,normal=N,state=state,keys=obj.keys,k=obj.k[:,0])
if __name__=='__main__':
    for model in sys.argv[1:] or ('cold','heavy'):
        for trace in (False,True):run(model,trace)
