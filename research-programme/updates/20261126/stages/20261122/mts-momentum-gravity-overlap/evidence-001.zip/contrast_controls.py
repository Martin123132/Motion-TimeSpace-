from local import *
from contrast import load_model
def projection(c,h,clock):
    ids=[1024,1152,1280];a=c[1][ids];b=h[1][ids]
    common=np.minimum(a,b) if clock=='scale factor' else c[0][ids]
    signals=[]
    for t,scale,grid,aa,fc in (c,h):
        coords=aa if clock=='scale factor' else grid
        vals=CubicSpline(coords,fc)(common)[:,:2]
        signals.append((vals[:,:,:,0].reshape(6,5),(vals[:,:,:,1]-vals[:,:,:,0]).reshape(6,5)))
    output=[]
    for i in range(5):
        f0,h0=signals[0];f1,h1=signals[1];v=f1[:,i]-f0[:,i];A=np.column_stack([h1[:,i],-h0[:,i]])
        coeff=np.linalg.lstsq(A,-v,rcond=None)[0];rem=v+A@coeff
        output.append((v,rem,coeff,np.linalg.norm(rem)/np.linalg.norm(v)))
    return output
def run():
    rows=[];anchor={}
    for version in ('finer','thin readout','latest start','lower angular order','double time step'):
        sources=[]
        for model in ('cold','heavy'):
            t,a,f,h=load_model(model,'finer')
            if version in ('finer','thin readout'):
                use=np.arange(len(t)) if version=='finer' else np.arange(0,len(t),16)
                grid=t[use];aa=a[use];fc=np.stack([f[use],f[use]+h[use]],axis=-1)
            else:
                config={'latest start':'radau-T1-'+model+'-1-18-0-6','lower angular order':'v2-'+model+'-1-12-0-4','double time step':'radau-T1-'+model+'-2-18-0-6'}[version]
                with np.load(checked('flight-'+config+'.npz')) as old:
                    grid=old['eta'];aa=a[::16];col=4 if version=='latest start' else 0;fc=old['values'][:,:3,:,col:col+2]
                    ok=grid>=.025;grid=grid[ok];fc=fc[ok];aa=aa[ok]
            sources.append((t,a,grid,aa,fc))
        for clock in ('scale factor','conformal time'):
            vals=projection(*sources,clock)
            if version=='finer':anchor[clock]=vals
            for j,((v,rem,coeff,frac),(ref,base,amps,frac0)) in enumerate(zip(vals,anchor[clock])):
                rows.append(dict(version=version,clock=clock,mode=str(PROBES[j]),residual_fraction=frac,original_fraction=frac0,
                                 change_of_residual_vector_over_residual=np.linalg.norm(rem-base)/np.linalg.norm(base),
                                 change_of_forced_difference_over_residual=np.linalg.norm(v-ref)/np.linalg.norm(base),
                                 coefficient_change=np.linalg.norm(coeff-amps)))
    table('contrast-sensitivity.csv',rows)
    print([(v,max(r['change_of_residual_vector_over_residual'] for r in rows if r['version']==v)) for v in dict.fromkeys(r['version'] for r in rows)])
if __name__=='__main__':run()
