from local import *
from material_overlap import Readout
def run(model):
    with np.load(DIR/f'leading-frozen-{model}.npz') as f:tt=f['eta'];pred=f['stress']
    with np.load(DIR/f'ward-{model}-s2-dense.npz') as f:assert np.array_equal(tt,f['stressClock']);st=f['fixedStress'];target=f['independentTarget']
    with np.load(DIR/f'forward-{model}-0.npz') as f:baseline=f['obs']
    t,v,_,_=Readout(model).evolve(tt,pred)
    comp=[]
    def compare(name,delta,ref,labels):
        for i,tag in enumerate(labels):
            for j,mode in enumerate(PROBES):
                for case in range(2):
                    d=delta[:,i,j,case];r=ref[:,i,j,case]
                    comp.append(dict(test=name,quantity=tag,mode=str(mode),case=case,relative_peak=max(abs(d))/max(abs(r)),relative_endpoint=abs(d[-1])/abs(r[-1]),
                                     reference_peak=max(abs(r)),reference_end=abs(r[-1])))
    compare('leading versus exact kinetic correction',pred-st,st,('energy','current','shear','trace'))
    compare('leading versus exact gravity increment',(v-baseline)[:,:4]-target[:,:4],target[:,:4],('phi','psi','weyl','etaF'))
    table('leading-test-'+model+'.csv',comp)
    print(model,[(tag,max(r['relative_peak'] for r in comp if r['test']==tag),max(r['relative_endpoint'] for r in comp if r['test']==tag)) for tag in dict.fromkeys(r['test'] for r in comp)])
if __name__=='__main__':run(sys.argv[1])
