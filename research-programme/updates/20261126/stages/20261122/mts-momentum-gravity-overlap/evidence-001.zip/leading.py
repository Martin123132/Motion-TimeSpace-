from local import *
from packets import environment
from transport import adv,solve_log
from scipy.sparse import csr_matrix
from scipy.special import eval_legendre

def tangent(inc,ref):
    t=inc.data.eta;kk=inc.k;lim=26;ell=np.arange(lim+1)[:,None];low=kk*ell/(2*ell+1);high=kk*(ell+1)/(2*ell+1)
    mid=np.interp(np.arange(2*len(t)-1)/2,np.arange(len(t)),t)
    phi=CubicSpline(t,inc.data.first['phi'],axis=1)(mid);psi=CubicSpline(t,inc.data.first['psi'],axis=1)(mid)
    mass=(inc.mass*CubicSpline(t,inc.data.background['a'])(mid))**2
    state=np.zeros((2,lim+1,len(kk)));state[0,:3]=ref
    for l in range(3,lim+1):state[0,l]=(kk*t[0])**l*(ref[0]+psi[:,0])/factorial2(2*l+1)
    state[0,0]-=phi[:,0];state[1,1]=mass[0]*ref[1]/2
    def rhs(state,i):
        drift=0*state;drift[:,1:]+=low[1:]*state[:,:-1];drift[:,:-1]-=high[:-1]*state[:,1:]
        source=drift.copy();source[1]-=mass[i]*drift[0]/2
        source[0,1]+=kk*(phi[:,i]+psi[:,i])/3
        source[1,1]+=kk*mass[i]*(psi[:,i]-phi[:,i])/6
        return source
    out=[]
    for i in range(0,len(mid),2):
        if i%8==0:
            cp=state.copy();cp[0,0]+=phi[:,i];out.append(cp)
        if i+1==len(mid):break
        dt=mid[i+2]-mid[i];a=rhs(state,i);b=rhs(state+dt*a/2,i+1);c=rhs(state+dt*b/2,i+1);d=rhs(state+dt*c,i+2)
        state+=dt*(a+2*b+2*c+d)/6
    return np.moveaxis(np.array(out),0,-1)
def direct(proj,F,H,b):
    data=proj.data;sel=lambda key:data.first[key][:,::4]
    phi,psi,pd=map(sel,('phi','psi','pd'));g=phi+psi;num=len(data.nodes)
    w=-2.;result=[]
    for op,k,p,h,field,metric,phase in proj.ops:
        def mix(weight,first,second):
            mat=csr_matrix((phase*np.broadcast_to(weight,p.shape),(field,metric)),shape=(num,num))
            return np.einsum('ij,ij->j',mat@first,second)
        curve=np.zeros((19,len(b)),complex);curve[1]+=b*(mix(p*h,g,psi)-k*mix(1.,psi,psi))/6
        for l in range(19):
            leg=eval_legendre(l,h);curve[l]-=(w-2)*mix(leg,pd,H[l])
            for j in (l-1,l+1):
                if j<0:continue
                sign=1 if j<l else -1;beta=(l if j<l else l+1)/(2*l+1)
                pp=sign*beta*p*leg;qq=sign*beta*k*eval_legendre(j,h)-pp
                df=(2+j*(j+1)-l*(l+1))/2
                curve[l]+=mix(pp,g,H[j])-df*mix(qq,phi,H[j])-(w-2+df)*mix(qq,psi,H[j])
                curve[l]-=.5*b*(mix(pp,g,F[j])-df*mix(qq,phi,F[j])+(w+df)*mix(qq,psi,F[j]))
        result.append(curve)
    return np.stack(result,axis=-1).transpose(1,0,2)
def run(model):
    guard();inc,proj,ref,k=environment(model,1);data=inc.data
    t=data.eta[::4];b=(inc.mass*data.background['a'][::4])**2;F,H=tangent(inc,ref)
    sp=CubicSpline(np.log(t),direct(proj,F,H,b))
    with np.load(DIR/f'base-{model}-s1.npz') as store:
        assert np.max(abs(F[:3]-store['incident']))<1e-12
        init_z=store['Z'][0].T
        pol=CubicSpline(np.log(t),store['Sw'].transpose(2,1,0))
    Z=solve_log(lambda u,z:adv(z,k)+pol(u)[None,:,:,None],t,init_z[None,:,:,None])[:,0,:,:,0]
    zpol=CubicSpline(np.log(t),Z)
    with np.load(DIR/f'forward-{model}-0.npz') as store:
        main_t=store['eta'];N=CubicSpline(np.log(main_t),store['normal']);psi=CubicSpline(np.log(main_t),store['obs'][:,1])
    scale=CubicSpline(np.log(data.eta),data.background['a'])
    def dr(u,y):
        B=(inc.mass*scale(u))**2
        predicted=N(u)+2*zpol(u)[:,:,None]
        out=adv(y,k)-.5*B*adv(predicted[None],k)+sp(u)[None,:,:,None]
        out[:,1]+=B*k[:,None]*psi(u)/6
        return out
    with np.load(checked('origin-v2-'+model+'.npz')) as f:o=dict(f.items())
    T=-o['P']/2;p=o['P'];g=o['C']+p;k2=k*k;z0=-.5*T**2*o['pairs']
    seed=np.zeros((1,19,5,2),complex)
    for free in (0,1):
        P=o['psi']+free*p*o['pairs'];M=o['N0']-free*.5*p*o['pairs']+2*z0
        A=k*M/3+k*g*T*o['pairs']/6
        B=k*P/3+k*(g*p/2-p*p)*o['pairs']/3+2*k*p*T*o['pairs']/6
        seed[0,1,:,free]=t[0]*b[0]*(B-A)/6
    tt=main_t[::2];Y=solve_log(dr,tt,seed)[:,0];z=zpol(np.log(tt));a=scale(np.log(tt));big=(inc.mass*a)**2
    meta=json.loads(ti.parent.pin('radiation-background.json').read_bytes())[model]
    base=meta['massless_limit_coeff']/(7*np.pi**4/120)/a**2
    E=Y[:,0]+big[:,None,None]*z[:,0,:,None]
    J=Y[:,1]
    S=-Y[:,2]+big[:,None,None]*z[:,2,:,None]
    D=np.broadcast_to(2*big[:,None,None]*z[:,0,:,None],E.shape)
    pred=np.stack([E,J,S,D],axis=1)*(np.pi**2/6*base/data.background['enu'][::2])[:,None,None,None]
    pack('leading-frozen-'+model+'.npz',eta=tt,k=k,stress=pred,field=Y,firstTangentEnd=H[:,:,-1],source=sp(np.log(t)))
    print(model,'analytic leading prediction frozen',flush=True)
if __name__=='__main__':run(sys.argv[1])
