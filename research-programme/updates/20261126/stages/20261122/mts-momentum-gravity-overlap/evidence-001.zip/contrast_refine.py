from local import *
from contrast_controls import projection
from material_overlap import Readout
class Angular(Readout):
    def __init__(self,model,ln,lp):Flight.__init__(self,model,ln,lp,False,True)
def run():
    config=[('common 18/6',18,6),('common 16/6',16,6),('common 12/4',12,4),('finest',18,6)]
    rows=[];ref={}
    for label,ln,lp in config:
        allmodel=[]
        for model in ('cold','heavy'):
            with np.load(checked('forcing-'+model+'.npz')) as f:a=f['background'][f['bgkeys'].tolist().index('a')]
            if label in ('finest','common 18/6'):
                packet=('fine-'+model if label=='finest' else 'forward-'+model+'-0')+'.npz'
                with np.load(DIR/packet) as f:t=f['eta'];obs=f['obs']
            else:t,obs,_,_=Angular(model,ln,lp).evolve()
            allmodel.append((t,a,t,a,obs[:,:3]))
        for clock in ('scale factor','conformal time'):
            vals=projection(*allmodel,clock)
            if label=='common 18/6':ref[clock]=vals
            for j,((v,r,x,f),(v0,r0,x0,f0)) in enumerate(zip(vals,ref[clock])):
                rows.append(dict(model=label,clock=clock,mode=str(PROBES[j]),residual_fraction=f,
                                 residual_vector_change=np.linalg.norm(r-r0)/np.linalg.norm(r0),forced_vector_change=np.linalg.norm(v-v0)/np.linalg.norm(r0)))
    table('contrast-matched-angular.csv',rows)
    print([(tag,max(r['residual_vector_change'] for r in rows if r['model']==tag)) for tag in dict.fromkeys(r['model'] for r in rows)])
if __name__=='__main__':run()
