from local import *
from scipy.integrate import solve_ivp

def adv(st,k):
    degree=np.arange(st.shape[1])
    arg=(1,st.shape[1]-1,1,1)
    dr=np.zeros_like(st)
    dr[:,1:]+=degree[1:].reshape(arg)/(2*degree[1:]+1).reshape(arg)*st[:,:-1]
    dr[:,:-1]-=(degree[:-1]+1).reshape(arg)/(2*degree[:-1]+1).reshape(arg)*st[:,1:]
    return dr*k[None,None,:,None]

def solve_log(fun,t,state):
    shape=state.shape;scale=max(np.max(abs(state)),1e-12)
    def rhs(u,y):return (np.exp(u)*fun(u,y.reshape(shape))).ravel()
    sol=solve_ivp(rhs,np.log(t[[0,-1]]),state.ravel(),method='DOP853',t_eval=np.log(t),rtol=4e-10,atol=2e-16*scale,max_step=.055)
    assert sol.success and sol.t.size==len(t) and np.isfinite(sol.y).all()
    return sol.y.T.reshape(len(t),*shape)

class Kinetic:
    def __init__(self,model,stride,ids):
        self.model=model;self.stride=stride;self.ids=ids
        with np.load(DIR/f'base-{model}-s{stride}.npz') as f:
            k=self.k=f['k'];self.t=t=f['eta'];u=np.log(t);sw=CubicSpline(u,f['Sw'].transpose(2,1,0))
            self.direct=f['Z'].transpose(0,2,1);self.sites=f['sites']
        def deriv(u,state):return adv(state,k)+sw(u)[None,:,:,None]
        self.Z=solve_log(deriv,t,self.direct[:1,:,:,None])[:,0,:,:,0]
        self.zpol=CubicSpline(u,self.Z);self.sw=sw
        with np.load(checked(f'forcing-{model}.npz')) as f:
            data=dict(zip(f['bgkeys'],f['background']));self.af=CubicSpline(np.log(f['eta']),data['a'])
            self.energy=CubicSpline(np.log(f['eta']),data['enu'])
        meta=json.loads(ti.parent.pin('radiation-background.json').read_bytes())[model]
        self.mass=meta['mass_over_temperature'];self.coeff=meta['massless_limit_coeff']/(7*np.pi**4/120)
        current=[]
        for node in ids:
            with np.load(DIR/f'kin-{model}-s{stride}-q{node}.npz') as f:
                assert np.array_equal(t,f['eta']) and np.array_equal(f['k'],k) and f['q']==2.**(node/4)
                current.append(f['directDifference'].transpose(2,1,0))
        self.q=2.**(np.array(ids)/4);self.w=1-self.q*np.tanh(self.q/2)
        self.src=CubicSpline(u,np.stack(current,axis=1))
    def start(self):
        with np.load(checked('origin-v2-'+self.model+'.npz')) as f:o=dict(f.items())
        p=o['P'];c=o['C'];g=p+c;theta=-p/2;kk=self.k;t=self.t[0]
        x=(self.af(np.log(t))*self.mass/self.q)[:,None,None];v=1/np.hypot(1,x);integ=np.arcsinh(x)/x
        low=np.where(x<.001,-x*x/6+3*x**4/40,integ-1)
        high=(x*x/(np.hypot(1,x)+1)+low)/2
        w=self.w[:,None];pairs=o['pairs'];z0=-.5*theta**2*pairs;z1=-kk*p*theta*pairs/12
        out=[]
        for free in (0,1):
            psi=o['psi']+free*p*pairs;N0=o['N0']-free*.5*p*pairs
            M=N0+(w+4)*z0
            A=kk*M/3+kk*g*theta*pairs/6
            B=kk*psi/3+kk*(g*p/2-p*p)*pairs/3-w*kk*p*theta*pairs/6
            ref=o['N1']+free*kk*p*pairs/6+(w+4)*z1
            assert np.max(abs(A+B-ref)/np.maximum(abs(ref),1e-80))<1e-12
            out.append(t*(low[:,:,0]*A+high[:,:,0]*B))
        return np.stack(out,axis=-1)
    def calculate(self,common_t,obs,normal,start=0,regular=True,restart=None,output=None):
        q=self.q[:,None,None,None];shape=(self.w+4)[:,None,None,None];k=self.k;tt=self.t[start:] if output is None else output
        metric=CubicSpline(np.log(common_t),obs[:,1]);bright=CubicSpline(np.log(common_t),normal)
        initial=np.zeros((len(q),19,5,2),complex)
        if start==0 and regular:initial[:,1]=self.start()
        if restart is not None:initial=restart.copy()
        def rate(u,delta):
            am=self.af(u)*self.mass;ep=np.hypot(q,am);v=q/ep;vm1=-am**2/(ep*(ep+q))
            expected=bright(u)[None]+shape*self.zpol(u)[None,:,:,None]
            dx=v*adv(delta,k)+vm1*adv(expected,k)+self.src(u)[:,:,:,None]
            dx[:,1]+=(-vm1/v)[:,0]*k[None,:,None]*metric(u)[None]/3
            return dx
        return tt,solve_log(rate,tt,initial)
    def stress(self,t,dx,selection=None):
        inds=np.arange(len(self.q)) if selection is None else np.asarray(selection)
        q=self.q[inds];x=np.log(q);weights=(np.r_[x[1]-x[0],x[2:]-x[:-2],x[-1]-x[-2]])/2
        a=self.af(np.log(t));am=a[:,None]*self.mass;ep=np.hypot(q,am);v=q/ep;W=q*expit(q)*expit(-q)
        w=weights*q*W;shape=self.w[inds]+4
        base=self.coeff/(a**2*self.energy(np.log(t)));Z=self.zpol(np.log(t));d=dx[:,inds,:3]
        diff=am**2/(ep+q)
        def integ(kernel,sub,ell):
            main=np.einsum('tn,tnij->tij',kernel*w,d[:,:,ell])
            spectral=np.sum(sub*w*shape,axis=1)
            return base[:,None,None]*(main+spectral[:,None,None]*Z[:,ell,:,None])
        E=integ(q**2*ep,q*q*diff,0)
        J=integ(np.broadcast_to(q**3,ep.shape),np.zeros_like(ep),1)
        S=-integ(q**4/ep,-q**3*diff/ep,2)
        D=integ(q**2*am**2/ep,q**2*am**2/ep,0)
        return np.stack([E,J,S,D],axis=1)
def run(model,stride,start,regular):
    with np.load(DIR/f'forward-{model}-0.npz') as f:t=f['eta'];obs=f['obs'];N=f['normal']
    ids=list(range(-52,25,2));solver=Kinetic(model,stride,ids)
    offset=next(i for i,x in enumerate(solver.t) if abs(x-start)<1e-12)
    times,dx=solver.calculate(t,obs,N,offset,regular)
    suffix=f'{model}-s{stride}-{start:g}-{int(regular)}'
    st=solver.stress(times,dx);coarse=solver.stress(times,dx,np.arange(0,len(ids),2))
    pack('kinetic-'+suffix+'.npz',eta=times,q=solver.q,stress=st,coarse=coarse,fullEnd=dx[-1],diffLow=dx[:,:,:3],Z=solver.zpol(np.log(times)))
    print(suffix,'max normalized stress',abs(st).max(),flush=True)
if __name__=='__main__':run(sys.argv[1],int(sys.argv[2]),float(sys.argv[3]),int(sys.argv[4]))
