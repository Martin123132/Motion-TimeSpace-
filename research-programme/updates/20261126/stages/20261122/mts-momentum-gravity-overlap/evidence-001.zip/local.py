from pathlib import Path
import os,sys,hashlib,io,json,csv
for key in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','BLIS_NUM_THREADS'):os.environ[key]='1'
sys.dont_write_bytecode=True
DIR=Path(__file__).resolve().parent
PRIOR=DIR.parent/'mts-regular-material-start-20261122'
def sha(p):
    with p.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
assert sha(PRIOR/'seal.json')=='82a9ec70a5b0917ca8985667a013a80a3a1e638a53e30760dd6ff7a7c83f939e'
files=json.loads((PRIOR/'seal.json').read_bytes())['files']
def checked(name):
    p=PRIOR/name;assert sha(p)==files[name],name;return p
for name in ('regular_io.py','regular_flow.py','incident_early.py','early_source.py','spectral_start.py','origin.py'):checked(name)
sys.path.insert(0,str(PRIOR))
from regular_io import np,CubicSpline,ti,PROBES,guard as prior_guard
from regular_flow import Flight
from drivers import Project
from spectral_start import square
from scipy.special import expit,factorial2
sys.path.insert(0,str(DIR))
def guard():
    prior_guard();assert __debug__ and not (DIR/'STOP-REQUESTED').exists()
def save(name,data):
    guard();p=DIR/name
    if p.exists():assert sha(p)==hashlib.sha256(data).hexdigest(),name
    else:
        with p.open('xb') as st:st.write(data)
def pack(name,**kwargs):
    buf=io.BytesIO();np.savez_compressed(buf,**kwargs);save(name,buf.getvalue())
def table(name,rows):
    buf=io.StringIO();writer=csv.DictWriter(buf,rows[0],lineterminator='\n');writer.writeheader();writer.writerows(rows);save(name,buf.getvalue().encode())
