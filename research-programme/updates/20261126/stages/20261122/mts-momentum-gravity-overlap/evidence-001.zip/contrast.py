from local import *
def load_model(model,version):
    with np.load(checked('forcing-'+model+'.npz')) as f:t=f['eta'];a=f['background'][f['bgkeys'].tolist().index('a')]
    source={'common':f'forward-{model}-0.npz','exact':f'coupled-{model}-0.npz','independent trace':f'coupled-{model}-1.npz','native transfer':f'coupled-{model}-0.npz','finer':f'fine-{model}.npz'}[version]
    with np.load(DIR/source) as f:assert np.array_equal(t,f['eta']);v=f['obs'][:,:3]
    forced=v[:,:,:,0];control=v[:,:,:,1]-forced
    if version=='native transfer':
        with np.load(checked('linear-output-'+model+'.npz')) as f:
            phi=f['phi'].T;psi=f['psi'].T
        with np.load(checked('origin-v2-'+model+'.npz')) as f:control=np.stack((phi,psi,(phi+psi)/2),axis=1)*f['pairs']
    return t,a,forced,control
def run():
    rows=[];amplitudes=[]
    for version in ('common','exact','independent trace','native transfer','finer'):
        cold=load_model('cold',version);heavy=load_model('heavy',version)
        for clock in ('conformal time','scale factor'):
            ids=np.array([1024,1152,1280])
            assert np.array_equal(cold[0][ids],[1.6,3.2,6.4])
            points=cold[0][ids] if clock=='conformal time' else np.minimum(cold[1][ids],heavy[1][ids])
            vect=[]
            for t,a,f,c in [cold,heavy]:
                grid=t if clock=='conformal time' else a
                assert np.all(np.diff(grid)>0) and points[0]>=grid[0] and points[-1]<=grid[-1]
                vect.append([CubicSpline(grid,arr)(points) for arr in (f,c)])
            for panel,epochs,fields in [('endpoint Weyl',[2],[2]),('endpoint pair',[2],[0,1]),('three Weyl',[0,1,2],[2]),('three pairs',[0,1,2],[0,1])]:
                for j,mode in enumerate(PROBES):
                    vals=[[seq[epochs][:,fields,j].reshape(-1) for seq in arm] for arm in vect];f0,h0=vals[0];f1,h1=vals[1];df=f1-f0
                    for rule,directions in [('fixed',[]),('shared',[h1-h0]),('separate',[h1,-h0])]:
                        remain=df.copy();cond=None;rank=0;sing=[]
                        if directions:
                            matrix=np.column_stack(directions);coef,_,rank,sing=np.linalg.lstsq(matrix,-df,rcond=None)
                            remain+=matrix@coef;cond=sing[0]/sing[-1];scale=np.linalg.norm(df)*np.linalg.norm(matrix)
                            assert np.linalg.norm(matrix.conj().T@remain)<1e-8*scale
                            if panel=='three pairs':
                                amplitudes.append(dict(version=version,clock=clock,mode=str(mode),rule=rule,first_re=coef[0].real,first_im=coef[0].imag,second_re=(coef[1].real if len(coef)>1 else None),second_im=(coef[1].imag if len(coef)>1 else None),smallest=sing[-1],largest=sing[0]))
                        rows.append(dict(version=version,clock=clock,panel=panel,mode=str(mode),rule=rule,components=len(df),rank=rank,condition=cond,
                                         forced_norm=np.linalg.norm(df),residual_norm=np.linalg.norm(remain),fraction_of_forced=np.linalg.norm(remain)/np.linalg.norm(df),fraction_of_cold=np.linalg.norm(remain)/np.linalg.norm(f0)))
    table('primordial-contrast.csv',rows);table('nuisance-certificate.csv',amplitudes)
    for v in ['exact','finer','native transfer','independent trace']:
        select=[r for r in rows if r['version']==v and r['clock']=='scale factor' and r['panel']=='three pairs' and r['rule']=='separate']
        print(v,[(round(100*r['fraction_of_forced'],4),round(100*r['fraction_of_cold'],6)) for r in select])
if __name__=='__main__':run()
