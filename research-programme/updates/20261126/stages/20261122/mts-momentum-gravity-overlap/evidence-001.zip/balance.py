from local import *
from transport import Kinetic
from scipy.integrate import cumulative_simpson

def test(model,stride=2):
    ids=list(range(-52,25,2 if stride==2 else 4))
    kin=Kinetic(model,stride,ids)
    with np.load(DIR/f'coupled-{model}-0.npz') as c:t=c['eta'];obs=c['obs'];N=c['nu']
    tt=t[::2]
    _,delta=kin.calculate(t,obs,N,output=tt)
    st=kin.stress(tt,delta);u=np.log(tt)
    with np.load(checked(f'forcing-{model}.npz')) as c:
        b=dict(zip(c['bgkeys'],c['background'][:,::2]));k=c['k'][None,:,None]
    factor=b['enu']*b['a']**2/kin.coeff
    E,J,S,D=(st*factor[:,None,None,None]).transpose(1,0,2,3)
    q=kin.q;eps=np.hypot(q,kin.mass*b['a'][:,None]);difference=(kin.mass*b['a'][:,None])**2/(eps+q)
    weights=np.full(len(q),np.log(q[1]/q[0]));weights[[0,-1]]/=2
    wt=weights*q*q*expit(-q)*expit(q);w=kin.w+4
    de=(q*q*difference)@wt;ds=(-q**3*difference/eps)@wt
    momentum=np.zeros_like(J);energy=np.zeros_like(E)
    for i,time in enumerate(u):
        direct=kin.src(time);sw=kin.sw(time)
        energy[i]=((wt*q*q*eps[i])@direct[:,0]+np.dot(wt*w,q*q*difference[i])*sw[0])[:,None]
        momentum[i]=((wt*q**3)@direct[:,1])[:,None]
    h=b['h'][:,None,None]
    corrections=[k*de[:,None,None]*N[::2,1],k/3*(ds[:,None,None]*(N[::2,0]-2*N[::2,2])+de[:,None,None]*obs[::2,1])]
    bare=[h*D-k*J+energy,k/3*(E-D+2*S)+momentum]
    rows=[]
    for index,(signal,tag) in enumerate(((E,'energy'),(J,'momentum'))):
        for variant in ('all','omit streaming mismatch','omit quadratic driver'):
            rate=bare[index]+corrections[index]
            if variant=='omit streaming mismatch':rate=bare[index]
            if variant=='omit quadratic driver':rate=rate-[energy,momentum][index]
            pred=signal[0]+cumulative_simpson(rate.real,x=tt,axis=0,initial=0)+1j*cumulative_simpson(rate.imag,x=tt,axis=0,initial=0)
            for j,mode in enumerate(PROBES):
                for case in range(2):
                    den=max(abs(signal[:,j,case]));r=abs(signal[:,j,case]-pred[:,j,case])
                    rows.append(dict(mode=str(mode),case=case,test=variant,equation=tag,max_rel_to_correction=max(r)/den,end_rel_to_correction=r[-1]/den))
    table(f'conservation-{model}-s{stride}.csv',rows)
    print(model,stride,[(v,max(row['max_rel_to_correction'] for row in rows if row['test']==v)) for v in dict.fromkeys(r['test'] for r in rows)])
if __name__=='__main__':test(sys.argv[1],int(sys.argv[2]))
