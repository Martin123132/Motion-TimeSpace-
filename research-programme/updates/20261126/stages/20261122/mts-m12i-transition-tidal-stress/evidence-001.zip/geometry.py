from tidal_stage import *


class Mixed:
    def __init__(self):
        big,windows,self.cuts=get_inputs()
        self.big=big
        short,accepted=screens(big);self.long=~short
        self.output=big.k2<=(big.k[self.long].max()+big.k[short].max())**2+1e-12
        self.windows=windows[:,self.output]
        self.k=big.k;self.vec=big.vec;self.R=big.R;self.src=big.src
        self.out=big.out[:,self.output];self.dst=tuple(self.out);self.weights=big.weights[self.output]
        self.outvec=big.outvec[:,self.output];self.k2=big.k2[self.output]
        self.nonzero=self.k2>0;self.early_screen=accepted[self.output]
        self.safe=np.where(self.nonzero,self.k2,1.)
        self.size=2*(np.max(abs(big.axes[:,self.long]))+np.max(abs(big.axes[:,short])))+3
        self.kr,self.rad=np.unique(big.k,return_inverse=True)
    real=old.Modes.real
    spec=old.Modes.spec
    norm=old.Modes.norm
    def split(self,coeff):
        return (coeff*self.long,coeff*(~self.long))
    def xy(self,pair,size,op=1.):
        return np.array([self.real(op*item,size) for item in pair])
    def project(self,out):
        return (self.windows.conj()@(self.weights*out)).real


def cross(a,b):
    return a[0]*b[1]+a[1]*b[0]


def product_data(m,ds,tm,tw,scalar,size):
    d=m.xy(ds,size)
    kinematic=.5*cross(d,d)
    metric=m.xy(tm,size);weyl=m.xy(tw,size)
    trace=-cross(d,metric)/3
    shear_w=cross(d,weyl)/3
    shear_r=cross(d,metric-weyl)/3
    adv=np.zeros_like(trace)
    qadv=np.zeros_like(trace)
    grad2=np.zeros_like(trace)
    if scalar:
        qs=tuple(m.k**4*field for field in ds)
    for ix,axis in enumerate(m.vec):
        displace=m.xy(ds,size,1j*axis/m.k**2)
        deriv=m.xy(ds,size,1j*axis)
        kinematic-=cross(displace,deriv)
        adv+=cross(displace,m.xy(tm,size,1j*axis))
        if scalar:
            grad2+=cross(deriv,deriv)
            qadv+=cross(displace,m.xy(qs,size,1j*axis))
        for jx in range(ix,3):
            mult=1 if ix==jx else 2
            proj=axis*m.vec[jx]/m.k**2
            sd=m.xy(ds,size,proj)
            kinematic+=.5*mult*cross(sd,sd)
            ww=m.xy(tw,size,proj)
            shear_w-=mult*cross(sd,ww)
            shear_r-=mult*cross(sd,m.xy(tuple(one-two for one,two in zip(tm,tw)),size,proj))
            if scalar:qadv-=mult*cross(sd,m.xy(qs,size,proj))
    if scalar:
        pressure=-.5*cross(d,m.xy(ds,size,-m.k**2))-.25*grad2
        qforce=-2*m.k2*m.spec(pressure)+m.spec(qadv)
    else:qforce=np.zeros(len(m.k2),complex)
    answer=np.array([m.spec(field) for field in (kinematic,adv,trace,shear_w,shear_r)]+[qforce])
    assert abs(answer[:,0]).max()<1e-10
    answer[:,0]=0
    return answer


def project_stress(m,first,second,size):
    result=np.zeros(len(m.k2),complex)
    for ix in range(3):
        fl=m.real(1j*m.vec[ix]*first,size);fs=m.real(1j*m.vec[ix]*second,size)
        for jx in range(ix,3):
            if ix==jx: field=2*fl*fs
            else: field=(fl*m.real(1j*m.vec[jx]*second,size)+fs*m.real(1j*m.vec[jx]*first,size))
            projector=m.outvec[ix]*m.outvec[jx]/m.safe-float(ix==jx)/3
            result+=1.5*(1 if ix==jx else 2)*projector*m.spec(field)
    result[0]=0
    return result


def transfer(m,k,array):
    return PchipInterpolator(np.log(k),array,axis=0,extrapolate=False)(np.log(m.kr))
