from tidal_stage import *

def run():
    guard()
    fixed={"PROTOCOL.md","CHECK-DESIGN.md","EQUATIONS.md","RESULTS.md","native.py","matching.py","geometry.py","evolution.py","refine.py","independent.py","tidal_stage.py","verify.py",
        "transition-stress.npz","era-scale-screen.csv","heldout-cycle.csv","independent-tide.csv","carrier-quadrature.csv","match-times.json","stress-direct-pairs.csv","stress-matching.csv"}
    paired=("canonical-replay","native-replay","mixed-drive","mixed-grid","refined-drive")
    for model in ("heavy","cold"):
        fixed.update(f"{name}-{model}.csv" for name in paired)
        fixed.update(f"{name}-{model}.npz" for name in ("native","integrand","refined-integrand"))
    assert {file.name for file in HERE.iterdir() if file.name!="seal.json"} == fixed
    validations={}
    for model in ("cold","heavy"):
        raw=rows(HERE/f"refined-drive-{model}.csv")
        assert len(raw)==120
        assert all(float(row["sum_pp"])==0 for row in raw if float(row["cut_kpc"])>280.)
        def inner(panels):
            return next(row for row in raw if float(row["a_start"])==.0002251 and int(row["panels"])==panels and row["output"]=="all" and 13<float(row["cut_kpc"])<14)
        def peak(file,field):return max(float(row[field]) for row in rows(HERE/file))
        native=peak(f"native-replay-{model}.csv","relative_rms")
        spatial=peak(f"mixed-grid-{model}.csv","grid_relative")
        assert max(native,spatial)<2e-5
        with np.load(HERE/f"refined-integrand-{model}.npz") as packet1,np.load(HERE/f"integrand-{model}.npz") as packet0:
            for name in ("a","response","baryon_frozen"):
                assert np.isfinite(packet1[name]).all() and np.array_equal(packet0[name],packet1[name][::2])
        sums=[float(inner(p)["sum_pp"]) for p in (16,32,64)]
        locked=float(inner(64)["baryon_no_dynamic_compression_pp"])
        validations[model]=dict(inner_mixed_pp=sums,finest_relative_step_change=abs(sums[-1]-sums[-2])/abs(sums[-1]),locked_inner_pp=locked,native_replay=native,spatial=spatial)
    assert len(rows(HERE/"independent-tide.csv"))==44 and peak("independent-tide.csv","relative")<2e-5
    assert peak("stress-direct-pairs.csv","relative")<2e-5
    held=rows(HERE/"heldout-cycle.csv")
    assert float(held[1]["field_error"])<float(held[0]["field_error"])
    coverage=rows(HERE/"era-scale-screen.csv")
    assert len(coverage)==129 and all(int(row["long_passed"])==0 for row in coverage)
    assert int(coverage[0]["short_passed"])==0
    record("seal.json",dict(files={name:digest(HERE/name) for name in sorted(fixed)},checks=validations,
        prior_seal=digest(PREV/"seal.json"),scope="Measured canonical trace-free stress; early mixed drift is a conditional sensitivity outside common scale screen."))
    check=json.loads((HERE/"seal.json").read_bytes())
    assert all(digest(HERE/name)==hashval for name,hashval in check["files"].items())
    print(len(fixed),digest(HERE/"seal.json"),validations)
if __name__=="__main__":run()
