from matching import *
from evolution import read_native

def forecast(modes, state):
    phase=state["phase"]; times=np.arange(len(phase)-33,len(phase))
    archived=state["c"][:,:times[0]]
    assert max(times-64)<times[0]
    slow=archived[:,times-64];prev=archived[:,times-96]
    weight=simpson(np.eye(33),x=phase[times],axis=0)/(2*np.pi)
    reference=cycle(state,1)
    left,right=weighted(modes,state)
    norm=lambda gram:np.linalg.norm(gram*left[:,None]*right[None,:])
    field=fft_tensor(modes,state,reference)[0]
    lo,hi=state["long"],state["short"]
    records=[]
    for kind,trial in (("carry_two_cycles",slow),("linear_slow_quadrature",3*slow-2*prev)):
        d=(state["mean"][times]*trial).real
        predicted=(d[lo]*weight)@d[hi].T
        tensor=fft_tensor(modes,state,predicted)[0]
        records.append(dict(kind=kind,pair_error=norm(predicted-reference)/norm(reference),field_error=modes.norm(tensor-field)/modes.norm(field)))
    table("heldout-cycle.csv",records)

def signed_controls(modes):
    axes=modes.big.axes.T
    lookup={tuple(v):(idx,False) for idx,v in enumerate(axes)}
    lookup.update({tuple(-v):(idx,True) for idx,v in enumerate(axes) if tuple(-v) not in lookup})
    longvec=np.array([v for v,ref in lookup.items() if modes.long[ref[0]]])
    result=[]
    for model in ("cold","heavy"):
        raw=read_native(model);slot=0
        amplitude=lambda arr: transfer(modes,raw["k"],arr)[modes.rad]*modes.R
        density=amplitude(raw["dens"][-1,:,slot]);metric=modes.k**2*amplitude(raw["psi"][:,slot])
        lens=modes.k**2*amplitude(raw["weyl"][:,slot])
        scalar=model=="heavy"
        grid=product_data(modes,modes.split(density),modes.split(metric),modes.split(lens),scalar,modes.size)
        def coeff(array,keys):
            refs=[lookup[tuple(vec)] for vec in keys]
            vals=array[[ref[0] for ref in refs]]
            return np.where([ref[1] for ref in refs],vals.conj(),vals)
        for probe in ((4,2,1),(9,-2,4),(21,8,1),(-17,-6,8)):
            wave=np.array(probe)
            keep=[tuple(wave-vec) in lookup and not modes.long[lookup[tuple(wave-vec)][0]] for vec in longvec]
            lower=longvec[keep];upper=wave-lower
            q2=np.sum(lower**2,axis=1)*modes.big.fund**2;p2=np.sum(upper**2,axis=1)*modes.big.fund**2
            dot=np.sum(lower*upper,axis=1)*modes.big.fund**2;mu2=dot**2/(q2*p2)
            dl,ds=coeff(density,lower),coeff(density,upper)
            tl,ts=coeff(metric,lower),coeff(metric,upper)
            wl,ws=coeff(lens,lower),coeff(lens,upper)
            prod=dl*ds;tide=dl*ts+ds*tl;weyl=dl*ws+ds*wl
            parts=[prod*(1+dot/q2+dot/p2+mu2),-dot*(dl*ts/q2+ds*tl/p2),-tide/3,
                -(mu2-1/3)*weyl,-(mu2-1/3)*(tide-weyl)]
            if scalar:
                parts.append(-prod*((wave@wave)*modes.big.fund**2*(p2+q2+dot)+(dot/q2+mu2)*p2**2+(dot/p2+mu2)*q2**2))
            idx=np.nonzero((modes.out.T==wave).all(axis=1))[0].item()
            for label,piece,test in zip(("coordinate","advection","trace","weyl","ricci","wave"),parts,grid[:,idx]):
                err=abs(piece.sum()-test)/max(abs(piece.sum()),1e-40)
                assert err<2e-5,(model,probe,label,err)
                result.append(dict(model=model,mode=str(probe),part=label,pairs=len(lower),relative=err))
    table("independent-tide.csv",result)
    for cos2 in (0.,1.):
        assert abs(-1/3-(cos2-1/3)+cos2)<1e-15
    source=np.array([1.,-2.,4.]);first=np.array([.2,.3,.7]);second=np.array([.5,.1,.4])
    gradient=np.diag([0.,0.,1.])
    np.testing.assert_allclose((source+gradient@second)-(source+gradient@first),gradient@(second-first))
    assert not np.any(source-source)

def scale_test(modes):
    bg=old.Background("heavy");cold=old.Background("cold")
    dates=read_native("heavy")["at"]
    output=[]
    for at in dates:
        hub=max(bg.hub(at),cold.hub(at))*at
        def gate(k):
            small=k/(at*bg.mass)
            return (k>hub/np.sqrt(2e-5))&((small/(np.hypot(1,small)+1))**2<2e-5)
        passed=gate(modes.k)
        output.append(dict(a=at,kmin_horizon=hub/np.sqrt(2e-5),kmax_dispersion=at*bg.mass*2*np.sqrt(2e-5)/(1-2e-5),
            long_passed=int((modes.long&passed).sum()),short_passed=int((~modes.long&passed).sum()),output_passed=int(gate(np.sqrt(modes.k2)).sum())))
    table("era-scale-screen.csv",output)

if __name__=="__main__":
    modes,state=raw_modes();forecast(modes,state);signed_controls(modes);scale_test(modes)
