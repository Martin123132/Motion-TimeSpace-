from tidal_stage import *
from seeds import Seed,SPEC,NATIVE,checked,obj,source
import radiation_switch as engine


def dates():
    seed=Seed("heavy","anchorA","heavy")
    phase=np.linspace(-16*np.pi,0,257)
    finish=.00022495
    sol=solve_ivp(lambda t,state:seed.H(np.exp(state))/seed.mass,[0,phase[0]],[np.log(finish)],t_eval=phase[::-1],rtol=1e-13,atol=1e-14,method="DOP853",max_step=np.pi/16)
    assert sol.success
    raw=np.exp(sol.y[0,::-1])
    fluid=np.geomspace(.0002251,.003,129)
    return phase,raw,fluid


def run(model):
    guard();seed=Seed(model,"anchorA","heavy")
    status=obj(source(f"runs/{model}/status.json"))
    for path in engine.inherited.native_hashes():checked(path,status["input_hashes"][str(path)])
    bgfile=SPEC/"runs/projection/a225-w6-d8.npz" if model=="heavy" else NATIVE/"runs/backgrounds/cold.npz"
    checked(bgfile,status["source_hash"])
    params=engine.inherited.params_for(bgfile,background_boost=8.);assert params.DoLateRadTruncation
    params.DoLateRadTruncation=False
    bg=engine.camb.get_background(params);bg.Params.Accuracy.IntTolBoost=6
    phase,raw,fluid=dates()
    stored=np.unique(np.r_[raw,fluid,.0003,.0005,.001])
    with np.load(old.parent(f"hierarchy-{model}.npz")) as archive:
        oldtime=archive["epochs"];oldvalues=archive["values"];names=archive["names"].tolist()
    assert names==engine.camb.model.evolve_names
    requested=np.unique(np.r_[stored,oldtime])
    times=bg.conformal_time(1/requested-1,tol=1e-10)
    blocks=[];nodes=[]
    for file in sorted((SPEC/"runs"/model).glob("chunk-*.npz")):
        with np.load(source(file.relative_to(SPEC).as_posix())) as packet0:all_k=packet0["modes"]
        pick=all_k[np.isin(all_k,seed.k)]
        if not len(pick):continue
        guard()
        batch=np.unique(np.r_[pick,all_k.max()])
        block=bg.get_time_evolution(batch,times,vars=names,lAccuracyBoost=4)
        blocks.extend(block[np.searchsorted(batch,pick)][:,np.searchsorted(requested,stored)])
        nodes.extend(pick)
    order=np.argsort(nodes); k=np.array(nodes)[order];assert np.array_equal(k,seed.k)
    values=np.array(blocks)[order];assert np.isfinite(values).all()
    col=lambda key:values[:,:,names.index(key)]
    scale=col("a");hc=col("H");kk=k[:,None]
    assert np.max(abs(scale/stored-1))<2e-5
    alpha=-hc*col("v_newtonian_cdm")/kk**2
    phi=col("etak")/kk-hc*alpha
    weyl=col("Weyl")/kk**2;psi=2*weyl-phi
    dens=[col("delta_cdm")-3*col("etak")/kk,col("delta_baryon")-3*col("etak")/kk]
    theta=[kk**2*alpha,-hc*col("v_newtonian_baryon")]
    quantities={};pairs=[];raw_idx=np.searchsorted(stored,raw);fluid_idx=np.searchsorted(stored,fluid)
    with np.load(bgfile) as params_bg:
        for label,suffix in (("slow","s"),("heavy","h")):
            if label=="heavy" and model=="cold": continue
            index=raw_idx if label=="heavy" else np.arange(len(stored))
            grid=params_bg["heavy_efold" if label=="heavy" else "efold"]
            ai=scale[:,index];assert np.log(ai).min()>=grid.min() and np.log(ai).max()<=grid.max()
            speed=CubicSpline(grid,params_bg["phidot_"+suffix])(np.log(ai))
            base=CubicSpline(grid,params_bg["phi_"+suffix])(np.log(ai))
            mass=float(params_bg[label+"_mass_mpc"])
            scalar=col("mts_dphi_"+suffix)[:,index]+speed*alpha[:,index]
            normal=col("mts_dphidot_"+suffix)[:,index]+(-3*hc[:,index]*speed-(ai*mass)**2*base)*alpha[:,index]
            canonical=kk*speed*scalar
            reference=col("mts_q_"+suffix)[:,index]+kk*speed**2*alpha[:,index]
            norm=max(np.linalg.norm(reference),1e-90)
            pairs.append(dict(label=label,relative_source_reconstruction=np.linalg.norm(canonical-reference)/norm))
            quantities[label+"_delta_N"]=scalar
            quantities[label+"_normal_N"]=normal
            quantities[label+"_background_phi"]=base[0]
            quantities[label+"_background_speed"]=speed[0]
        if model=="heavy":
            assert (col("mts_averaged_chart")[:,raw_idx]==0).all() and (col("mts_averaged_chart")[:,fluid_idx]==1).all()
            assert np.all(col("mts_match_count")[:,fluid_idx]==1)
            ratio=col("mts_drho_h")/(seed.coeff["wave"]/scale)
            dens.append(ratio-3*col("etak")/kk)
            theta.append(kk*(col("mts_q_h")/(seed.coeff["wave"]/scale)+kk*alpha))
            quantities["native_match_a"]=col("mts_match_a")[:,fluid_idx[0]]
    errors=[]
    for a in (.0003,.0005,.001,.003):
        ref=oldvalues[:,np.where(oldtime==a)[0].item()]
        for name in ("etak","Weyl","delta_cdm","delta_baryon","v_newtonian_cdm","v_newtonian_baryon")+(("mts_drho_h","mts_q_h") if model=="heavy" else ()):
            idx=names.index(name);test=col(name)[:,np.where(stored==a)[0].item()]
            err=np.linalg.norm(test-ref[:,idx])/np.linalg.norm(ref[:,idx])
            errors.append(dict(a=a,column=name,relative_rms=err))
    assert max(r["relative_rms"] for r in errors)<2e-5
    table(f"native-replay-{model}.csv",errors)
    table(f"canonical-replay-{model}.csv",pairs)
    packet(f"native-{model}.npz",k=k,dates=stored,fluid=fluid_idx,raw=raw_idx,carrier_phase=phase,values=values,names=names,phi=phi,psi=psi,weyl=weyl,
           fluid_D=np.array(dens)[:,:,fluid_idx],fluid_theta=np.array(theta)[:,:,fluid_idx],coeff=[seed.coeff[s] for s in seed.fields],mass=seed.mass,
           **quantities)
    print(model,len(stored),pairs,flush=True)


if __name__=="__main__":
    for model in sys.argv[1:] or ("cold","heavy"):run(model)
