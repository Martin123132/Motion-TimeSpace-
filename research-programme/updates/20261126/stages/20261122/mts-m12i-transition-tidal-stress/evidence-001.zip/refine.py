from evolution import *

def refine(model):
    modes=Mixed()
    raw=read_native(model)
    background=old.Background(model)
    background.times=raw["at"]
    species=len(background.species)
    terminal=boundary(modes,background)
    green,labels=green_early(background,modes)
    locked,_=green_early(background,modes,False)
    windows=np.concatenate((modes.windows.conj()*modes.weights,modes.windows.conj()*(modes.weights*modes.early_screen)))
    with np.load(HERE/f"integrand-{model}.npz") as history:
        np.testing.assert_array_equal(history["a"],raw["at"][::4])
        channels=history["channel"]
        shape=(65,)+history["response"].shape[1:]
        full=np.zeros(shape);frozen=np.zeros(shape)
        full[::2]=history["response"];frozen[::2]=history["baryon_frozen"]
    for slot in range(2,128,4):
        guard()
        source=-kernels(modes,raw,slot,modes.size,model)/(background.B*background.hub(background.times[slot]))
        for gates,output,lock in ((green,full,False),(locked,frozen,True)):
            dual=np.einsum("ki,kij->kj",terminal,gates[slot,labels,:,species:])
            if lock:dual[:,1]=0.
            output[slot//2]=(np.einsum("kj,pjk->pk",dual,source)@windows.T).real
    at=raw["at"][::2];result=[]
    for start in (0,16,32,48):
        count=len(at)-1-start
        for panels in (count,count//2,count//4):
            weights=boole(at[start],at[-1],panels,count)
            values=np.einsum("s,spj->pj",weights,full[start:])
            locked_values=np.einsum("s,spj->pj",weights,frozen[start:])
            for idx,cut in enumerate(np.tile(modes.cuts,2)):
                result.append(dict(model=model,a_start=at[start],panels=panels,output="all" if idx<len(modes.cuts) else "previous-screen",cut_kpc=cut,
                       **dict(zip(channels,values[:,idx])),sum_pp=values[:,idx].sum(),baryon_no_dynamic_compression_pp=locked_values[:,idx].sum()))
    previous=rows(HERE/f"mixed-drive-{model}.csv")
    key=lambda row:(float(row["a_start"]),int(row["panels"]),row["output"],float(row["cut_kpc"]))
    lookup={key(row):row for row in result}
    for row in previous:
        for name in (*channels,"sum_pp","baryon_no_dynamic_compression_pp"):
            assert abs(float(row[name])-lookup[key(row)][name])<1e-16
    table(f"refined-drive-{model}.csv",result)
    packet(f"refined-integrand-{model}.npz",a=at,channel=channels,response=full,baryon_frozen=frozen,cut=modes.cuts)
    print(model,"64 panels",flush=True)

if __name__=="__main__":
    for model in ("cold","heavy"):refine(model)
