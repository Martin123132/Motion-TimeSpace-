import hashlib
import io
import json
import os
import sys
import csv
from pathlib import Path

for key in ("OPENBLAS_NUM_THREADS","MKL_NUM_THREADS","NUMEXPR_NUM_THREADS","BLIS_NUM_THREADS","OMP_NUM_THREADS"):
    os.environ[key]="1"
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
PREV=HERE.parent/"mts-m12i-inherited-compression-20261122"
def digest(path):
    with path.open("rb") as stream: return hashlib.file_digest(stream,"sha256").hexdigest()
assert digest(PREV/"seal.json")=="f307f302edeeadbfbfd811b77a4ef015733e67615fa6e11aca9843076f6f5b85"
manifest=json.loads((PREV/"seal.json").read_bytes())["files"]
def prior(name):
    path=PREV/name
    assert digest(path)==manifest[name],name
    return path
for name in ("inputs.py","flow.py","material.py"):
    prior(name)
sys.path.insert(0,str(PREV))
from flow import get_inputs,screens,setup,boole
from inputs import old,np,pinned
from scipy.interpolate import PchipInterpolator,CubicSpline
from scipy.integrate import solve_ivp
def guard():
    old.guard()
    assert not any((folder/"STOP-REQUESTED").exists() for folder in (HERE,PREV))
def put(name,content):
    guard()
    file=HERE/name
    if file.exists():assert file.read_bytes()==content,file
    else:
        with file.open("xb") as out:out.write(content)
def packet(name,**fields):
    out=io.BytesIO();np.savez_compressed(out,**fields);put(name,out.getvalue())
def record(name,obj):
    put(name,(json.dumps(obj,sort_keys=True,indent=2,allow_nan=False)+"\n").encode())
def table(name,rows):
    out=io.StringIO();writer=csv.DictWriter(out,rows[0],lineterminator="\n");writer.writeheader();writer.writerows(rows);put(name,out.getvalue().encode())
def rows(path):
    with path.open(encoding="utf-8") as stream:return list(csv.DictReader(stream))
