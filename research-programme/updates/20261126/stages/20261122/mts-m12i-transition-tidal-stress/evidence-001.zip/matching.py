from geometry import *
from scipy.integrate import simpson


def raw_modes():
    m=Mixed()
    with np.load(HERE/"native-heavy.npz") as bank:
        raw=bank["raw"];at=bank["dates"][raw];mass=float(bank["mass"]);coef=bank["coeff"][-1];k=bank["k"]
        phase=bank["carrier_phase"]
        scale=(at**1.5*mass/np.sqrt(coef))
        d=transfer(m,k,bank["heavy_delta_N"])*scale
        u=transfer(m,k,bank["heavy_normal_N"])*scale/(at*mass)
        mean=scale*(bank["heavy_background_phi"]+1j*bank["heavy_background_speed"]/(at*mass))
        rotated=(d+1j*u)/mean
        assert np.max(abs((mean*rotated).real-d))<1e-11*np.max(abs(d))
        fluid=bank["fluid"];post=bank["dates"][fluid];pidx=0;switch=bank["native_match_a"][0]
        dd=bank["fluid_D"][-1,:,pidx]+3*bank["phi"][:,fluid[pidx]]
        x=transfer(m,k,dd)*.5
        y=-post[pidx]*mass*transfer(m,k,bank["fluid_theta"][-1,:,pidx])/m.kr**2
    which=np.unique(m.rad[m.long]);short=np.unique(m.rad[~m.long])
    return m,dict(at=at,phase=phase,mean=mean,c=rotated,d=d,u=u,x=x,y=y,long=which,short=short,mass=mass,coef=coef,post=post[0],switch=switch)


def cycle(state,cycles,stride=1,field="total"):
    phase=state["phase"];select=np.arange(len(phase)-1-32*cycles,len(phase),stride)
    weight=simpson(np.eye(len(select)),x=phase[select],axis=0)/(cycles*2*np.pi)
    long,short=state["long"],state["short"]
    mean=state["mean"][select];d=state["d"][:,select];f=state["c"][:,select]
    if field=="total":return (d[long]*weight)@d[short].T
    if field=="hermitian":return .5*((f[long]*(weight*abs(mean)**2))@f[short].conj().T).real
    if field=="oscillatory":return .5*((f[long]*(weight*mean**2))@f[short].T).real
    raise ValueError(field)


def weighted(m,state):
    power=np.bincount(m.rad,weights=m.big.weights[m.big.inband]*abs(m.R)**2)
    sigma=np.sqrt(power)*m.kr
    return sigma[state["long"]],sigma[state["short"]]


def fft_tensor(m,state,gram):
    long,short=state["long"],state["short"]
    fl,fs=weighted(m,state)
    left,sigma,right=np.linalg.svd(fl[:,None]*gram*fs[None,:],full_matrices=False)
    rank=int(np.sum(sigma>sigma[0]*1.e-12))
    field=np.zeros(len(m.k2),complex)
    for index in range(rank):
        low=np.zeros(len(m.kr));high=low.copy()
        low[long]=left[:,index]*np.sqrt(sigma[index])/fl
        high[short]=right[index]*np.sqrt(sigma[index])/fs
        field+=project_stress(m,low[m.rad]*m.R,high[m.rad]*m.R,m.size)
    dropped=np.linalg.norm(sigma[rank:])/np.linalg.norm(sigma)
    assert dropped<2e-10
    return field,rank,dropped


def direct_probes(m,state,gram,field):
    look={tuple(v):val for v,val in zip(m.big.axes.T,m.R)}
    for v,val in list(look.items()):look[tuple(-np.array(v))]=np.conj(val)
    length={tuple(v):rad for v,rad in zip(m.big.axes.T,m.rad)}
    for v,rad in list(length.items()):length[tuple(-np.array(v))]=rad
    long={rad:i for i,rad in enumerate(state["long"])};short={rad:i for i,rad in enumerate(state["short"])}
    longkeys=[v for v in look if length[v] in long]
    index={tuple(v):i for i,v in enumerate(m.out.T)}
    checks=[]
    for xyz in ((4,2,1),(9,-2,4),(21,8,1),(-17,-6,8)):
        wave=np.array(xyz);wk=wave@wave
        total=0j;absolute=0.
        for q0 in longkeys:
            q=np.array(q0);p=wave-q;key=tuple(p)
            if key not in length or length[key] not in short:continue
            val=-3*m.big.fund**2*((wave@q)*(wave@p)/wk-(q@p)/3)*look[q0]*look[key]*gram[long[length[q0]],short[length[key]]]
            total+=val;absolute+=abs(val)
        err=abs(total-field[index[xyz]])/max(abs(total),1e-60)
        checks.append(dict(mode=str(xyz),relative=err,condition=absolute/max(abs(total),1e-60)))
    assert max(r["relative"] for r in checks)<2e-5
    return checks


def run():
    m,s=raw_modes();ll,ss=s["long"],s["short"]
    fl,fs=weighted(m,s)
    metric=lambda arr:np.linalg.norm(fl[:,None]*arr*fs[None,:])
    x,y=s["x"],s["y"]
    density=np.outer(x[ll],x[ss]);bulk=np.outer(y[ll],y[ss])
    model=density+bulk
    grams={"post":model,"post-bulk":bulk,"post-density-gradient":density};audit=[]
    for count in (1,2,4,8):
        total=cycle(s,count);positive=cycle(s,count,field="hermitian");osc=cycle(s,count,field="oscillatory")
        assert metric(positive+osc-total)/metric(total)<2e-12
        grams[f"raw-{count}"]=total
        if count==1:grams["raw-1-hermitian"]=positive;grams["raw-1-oscillatory"]=osc
        audit.append(dict(cycles=count,modepair_error_vs_post=metric(total-model)/metric(total),
             quadrature_16_vs_32_per_cycle=metric(total-cycle(s,count,2))/metric(total),
             oscillatory_fraction=metric(osc)/metric(total),bulk_only_error=metric(total-bulk)/metric(total)))
    grams["edge-1-2"]=2*grams["raw-1"]-grams["raw-2"]
    grams["edge-2-4"]=2*grams["raw-2"]-grams["raw-4"]
    grams["edge-4-8"]=2*grams["raw-4"]-grams["raw-8"]
    fields={};ranks={}
    for key,gram in grams.items():
        guard();fields[key],ranks[key],_=fft_tensor(m,s,gram)
    ref=fields["edge-1-2"];factor=s["coef"]/(s["post"]**3*s["mass"]**2)
    result=[]
    for name,field in fields.items():
        proj=m.project(field*factor);reference=m.project(ref*factor)
        for idx,cut in enumerate(m.cuts[:-1]):
            result.append(dict(estimator=name,cut_kpc=cut,rank=ranks[name],field_relative_vs_edge=m.norm(field-ref)/m.norm(ref),
                stress_times_percent_window_Mpc_minus2=proj[idx],signed_difference_from_edge=proj[idx]-reference[idx]))
    table("stress-matching.csv",result);table("carrier-quadrature.csv",audit)
    table("stress-direct-pairs.csv",direct_probes(m,s,grams["edge-1-2"],ref))
    packet("transition-stress.npz",axes=m.out,post=fields["post"]*factor,canonical_edge=ref*factor,bulk=fields["post-bulk"]*factor,
        density_gradient=fields["post-density-gradient"]*factor,canonical_one_cycle=fields["raw-1"]*factor)
    record("match-times.json",dict(pre_end=float(s["at"][-1]),pre_start=float(s["at"][0]),change=float(s["switch"]),post=float(s["post"]),
         max_slow_time_gap=float((s["post"]-s["at"][-1])/s["switch"]),normalization="raw d multiplied by a^(3/2) m / sqrt(C); restored at first post epoch",
         finest_edge_vs_post=m.norm(ref-fields["post"])/m.norm(ref),edge_1_2_vs_2_4=m.norm(ref-fields["edge-2-4"])/m.norm(ref)))


if __name__=="__main__":run()
