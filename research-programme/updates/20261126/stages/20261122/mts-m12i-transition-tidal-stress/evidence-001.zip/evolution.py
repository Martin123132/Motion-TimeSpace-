from geometry import *
import copy


def boundary(m,bg):
    model=bg.model
    _,previous,final,_=setup(model,m.big)
    earlier=(final[:,None,:]@previous[0])[:,0]
    return earlier[m.big.inv[m.output]] if bg.mass else np.broadcast_to(earlier,(len(m.k2),len(earlier[0])))


def green_early(bg,m,baryon=True):
    ns=len(bg.species);width=2*ns
    radial,lookup=np.unique(m.k2,return_inverse=True) if bg.mass else (np.array([0.]),np.zeros(len(m.k2),int))
    def rhs(clock,raw):
        at=np.exp(clock);hub=bg.hub(at)
        matrix=raw.reshape(len(radial),width,width)
        out=np.zeros_like(matrix)
        pull=matrix[:,:,ns:].sum(axis=2) if baryon else matrix[:,:,ns:].sum(axis=2)-matrix[:,:,ns+1]
        out[:,:,:ns]=-pull[:,:,None]*bg.coeff/(2*at*bg.B*hub)
        if bg.mass:out[:,:,ns-1]+=matrix[:,:,-1]*(radial**2/(4*at**2*bg.mass**2*bg.B*hub))[:,None]
        out[:,:,ns:]=-matrix[:,:,:ns]*bg.B/(at**2*hub)
        if not baryon:out[:,:,ns+1]=0
        return out.ravel()
    times=np.log(bg.times)
    sol=solve_ivp(rhs,times[[-1,0]],np.broadcast_to(np.eye(width),(len(radial),width,width)).copy().ravel(),t_eval=times[::-1],method="DOP853",rtol=8e-11,atol=2e-13,max_step=(times[-1]-times[0])/128)
    assert sol.success
    return sol.y.T.reshape(len(times),len(radial),width,width)[::-1],lookup


def kernels(m,raw,slot,size,model):
    nodes=raw["k"];at=raw["at"][slot]
    cf=lambda field:transfer(m,nodes,field)[m.rad]*m.R
    ds=[m.split(cf(row)) for row in raw["dens"][:,:,slot]]
    tm=m.split(m.k**2*cf(raw["psi"][:,slot]))
    tw=m.split(m.k**2*cf(raw["weyl"][:,slot]))
    ns=len(ds)
    parts=[product_data(m,ds[idx],tm,tw,model=="heavy" and idx==ns-1,size) for idx in range(ns)]
    phi_k=-sum(coef*part[0] for coef,part in zip(raw["coeff"],parts))/(2*at)
    result=np.zeros((6,ns,len(m.k2)),complex)
    for idx,part in enumerate(parts):
        result[0,idx]=phi_k
        result[1:5,idx]=part[1:5]
        if model=="heavy" and idx==ns-1:
            result[5,idx]=(m.k2**2*part[0]+part[5])/(4*at**2*raw["mass"]**2)
    return result


def read_native(model):
    with np.load(HERE/f"native-{model}.npz") as data:
        ix=data["fluid"]
        return dict(k=data["k"],at=data["dates"][ix],dens=data["fluid_D"],psi=data["psi"][:,ix],weyl=data["weyl"][:,ix],coeff=data["coeff"],mass=float(data["mass"]))


def run(model):
    m=Mixed();raw=read_native(model)
    bg=old.Background(model);bg.times=raw["at"]
    nt=len(bg.times);ns=len(bg.species)
    terminal=boundary(m,bg)
    clean,labels=green_early(bg,m)
    change,_=green_early(bg,m,False)
    bank=np.concatenate((m.windows.conj()*m.weights,m.windows.conj()*(m.weights*m.early_screen)))
    pieces=("induced_coordinate_gravity","force_gradient_advection","Ricci_trace","Weyl_shear","Ricci_shear","quantum_pressure")
    diagnostics=[];history=[];frozen_history=[]
    order=4
    for slot in range(0,nt,order):
        guard();at=bg.times[slot]
        direct=kernels(m,raw,slot,m.size,model)
        if slot in (0,64,128):
            alternate=kernels(m,raw,slot,m.size+8,model)
            for label,left,right in zip(pieces,direct,alternate):
                err=m.norm(left-right)/max(m.norm(right),1e-70)
                assert err<2e-5,(label,err)
                diagnostics.append(dict(slot=slot,component=label,grid_relative=err))
            del alternate
        source=-direct/(bg.B*bg.hub(at))
        def project(green,locked):
            response=np.einsum("ki,kij->kj",terminal,green[slot,labels,:,ns:])
            if locked:response[:,1]=0.
            total=np.einsum("kj,pjk->pk",response,source)
            return (total@bank.T).real
        history.append(project(clean,False));frozen_history.append(project(change,True))
        if slot%16==0:print(model,slot,"/128",flush=True)
    signal=np.array(history)
    record_rows=[]
    for start in (0,8,16,24):
        length=len(history)-1-start
        for sample in (length,length//2):
            weights=boole(bg.times[start*order],bg.times[-1],sample,length)
            value=np.einsum("s,spj->pj",weights,signal[start:])
            locked=np.einsum("s,spj->pj",weights,np.array(frozen_history)[start:])
            for index,cut in enumerate(np.tile(m.cuts,2)):
                record_rows.append(dict(model=model,a_start=bg.times[start*order],panels=sample,output="all" if index<len(m.cuts) else "previous-screen",cut_kpc=cut,
                    **{key:val for key,val in zip(pieces,value[:,index])},sum_pp=value[:,index].sum(),baryon_no_dynamic_compression_pp=locked[:,index].sum()))
    table(f"mixed-drive-{model}.csv",record_rows);table(f"mixed-grid-{model}.csv",diagnostics)
    packet(f"integrand-{model}.npz",a=bg.times[::order],channel=list(pieces),response=signal,baryon_frozen=np.array(frozen_history),cut=m.cuts)
    print(model,"done",flush=True)


if __name__=="__main__":
    for model in sys.argv[1:] or ("cold","heavy"):run(model)
