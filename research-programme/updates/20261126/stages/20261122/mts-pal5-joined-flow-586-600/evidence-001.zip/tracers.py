import csv
import io
import sys
import json
from early import HERE,PAL,LATE,pinned,sha,np,retain,record

for name in ('orbit.py','evolve.py','track.csv'):
    pinned(PAL/name,LATE[name])
sys.path.insert(0,str(PAL))
from orbit import TRACK,RA0,CONV,anchors,observed,legvander

SIGNS=('forward','reverse')
ARMS=('reset','coupled')
CASES={'early':('signed','mean'),'late':('mean','signed'),'both':('signed','signed')}
DEG=np.arange(0,69,2)

class Segment:
    def __init__(self,bank,arm,steps):
        self.times,self.rad,self.host=bank['time'],bank['radius'],bank['host']
        self.steps,self.end=steps,self.times[-1]
        self.tables={sign:bank[arm+'_'+sign] for sign in SIGNS}
        self.minr,self.maxr=np.inf,0.
    def acc(self,time,positions,sign):
        radii=np.linalg.norm(positions,axis=1);unit=positions/radii[:,None];mu=unit[:,2]
        self.minr=min(self.minr,radii.min());self.maxr=max(self.maxr,radii.max())
        if np.any(radii<=self.rad[0]) or np.any(radii>=self.rad[-1]):
            raise ValueError(f'radius outside evaluated field: {radii.min()}..{radii.max()}, bank {self.rad[[0,-1]]}')
        idx=np.searchsorted(self.rad,radii)-1
        t=min(len(self.times)-2,max(0,int(np.searchsorted(self.times,time)-1)))
        dt=self.times[t+1]-self.times[t];p=(time-self.times[t])/dt
        assert 0<=p<=1+1e-12
        sample=np.r_[idx,idx+1]
        def field(table):
            left,right=table[t,sample],table[t+1,sample]
            return (1-p)**2*(1+2*p)*left[...,0]+p*p*(3-2*p)*right[...,0]+dt*p*(1-p)*((1-p)*left[...,1]-p*right[...,1])
        value=(.5*(field(self.tables['forward'])+field(self.tables['reverse'])) if sign=='mean' else field(self.tables[sign]))
        value+=(1-time/self.end)*self.host[0,sample]+time/self.end*self.host[1,sample]
        left,right=np.split(value,2)
        step=self.rad[idx+1]-self.rad[idx];width=step[:,None]
        frac=((radii-self.rad[idx])/step)[:,None]
        first=width*left[...,1];gap=right[...,0]-left[...,0]
        second=3*gap-width*(2*left[...,1]+right[...,1])
        third=-2*gap+width*(left[...,1]+right[...,1])
        phi=left[...,0]+frac*(first+frac*(second+frac*third))
        slope=(first+frac*(2*second+3*frac*third))/width
        basis=legvander(mu,68)
        angular=DEG*(basis[:,np.maximum(DEG-1,0)]-mu[:,None]*basis[:,::2])/(1-mu[:,None]**2)
        axial=(angular*phi).sum(axis=1)/radii
        radial=(basis[:,::2]*slope).sum(axis=1)
        return -CONV**2*((radial-mu*axial)[:,None]*unit+axial[:,None]*[0,0,1])
    def move(self,start,stop,initial,sign):
        positions,velocity=(val.copy() for val in initial)
        n=max(1,int(np.ceil(abs(stop-start)/self.end*self.steps)))
        times=np.linspace(start,stop,n+1);acc=self.acc(start,positions,sign)
        for first,last in zip(times[:-1],times[1:]):
            step=last-first;velocity+=.5*step*acc;positions+=step*velocity
            acc=self.acc(last,positions,sign);velocity+=.5*step*acc
        return positions,velocity


def csv_out(name,rows):
    buf=io.StringIO();writer=csv.DictWriter(buf,fieldnames=rows[0],lineterminator='\n')
    writer.writeheader();writer.writerows(rows);retain(name,buf.getvalue().encode())


def stage(factor,orbit_factor):
    if factor not in (2,4) or orbit_factor not in (1,2):raise ValueError((factor,orbit_factor))
    early_steps=192*factor*orbit_factor
    late_steps=192*orbit_factor
    late_name=f'potential-{18*factor}.npz'
    outcomes=[];bins=[];escapes=[];checks=[];maps=[]
    ra=TRACK['ra'];slopes=np.zeros(len(ra))
    for side,degree in ((ra<RA0,1),(ra>=RA0,2)):
        fit=np.polynomial.Polynomial.fit(ra[side],TRACK['dec'][side],degree,w=1/TRACK['sigma_dec'][side])
        slopes[side]=fit.deriv()(ra[side])
    for arm in ARMS:
        head=f'early-{70*factor}-{arm}'
        receipt=json.loads((HERE/(head+'.json')).read_bytes())
        with np.load(pinned(HERE/(head+'.npz'),receipt['packet'])) as bank:
            early=Segment(bank,arm,early_steps)
        with np.load(pinned(PAL/late_name,LATE[late_name])) as bank:
            late=Segment(bank,arm,late_steps)
        with pinned(PAL/f'track-{18*factor}-192.csv',LATE[f'track-{18*factor}-192.csv']).open() as stream:
            previous=list(csv.DictReader(stream))
        for distance in (20.9,22.05,23.2):
            final=anchors(distance)
            bridge=late.move(late.end,0,final,'mean')
            initial=early.move(early.end,0,bridge,'mean')
            again=early.move(0,early.end,initial,'mean')
            returned=late.move(0,late.end,again,'mean')
            err=max(abs(val-test).max() for val,test in zip(final,returned))
            assert err<1e-9,err
            extracted={}
            for case,(mode1,mode2) in CASES.items():
                sky=[];xyz=[]
                for sign in SIGNS:
                    start=early.move(0,early.end,initial,sign) if mode1=='signed' else again
                    pos,vel=late.move(0,late.end,start,sign if mode2=='signed' else 'mean')
                    pos=pos-pos[:1]+final[0][:1];vel=vel-vel[:1]+final[1][:1]
                    sky.append(observed(pos,vel)[1:]);xyz.append(pos)
                dra,ddec,dvr=(sky[0]-sky[1]).T
                dec=ddec-slopes*dra;vlos=dvr-1.20*dra
                displacement=np.linalg.norm((xyz[0]-xyz[1])[1:],axis=1)*1000
                ratio=dec/TRACK['sigma_dec'];center=ra-ra.mean();gradient=center@vlos/(center@center)
                for idx in range(len(ra)):
                    bins.append(dict(arm=arm,distance=distance,case=case,ra=ra[idx],dec_deg=dec[idx],
                              vlos_kms=vlos[idx],position_pc=displacement[idx]))
                outcomes.append(dict(arm=arm,distance=distance,case=case,gradient=gradient,
                             gradient_sigma=abs(gradient)/.15,diag_track_sigma=np.linalg.norm(ratio),
                             max_bin_sigma=max(abs(ratio)),max_pc=max(displacement),max_vlos_kms=max(abs(vlos))))
                extracted[case]=(dec,vlos,gradient)
            early_dec,early_vel,early_gradient=extracted['early']
            late_dec,late_vel,late_gradient=extracted['late']
            both_dec,both_vel,both_gradient=extracted['both']
            ref=[row for row in previous if row['arm']==arm and float(row['dist'])==distance]
            assert len(ref)==len(ra) and np.array_equal(ra,[float(row['ra_deg']) for row in ref])
            def residual(actual,expected):return np.linalg.norm(actual-expected)/np.linalg.norm(expected)
            late_dec_err=residual(late_dec,np.array([float(row['delta_dec_fixed_RA_deg']) for row in ref]))
            late_vel_err=residual(late_vel,np.array([float(row['delta_vlos_fixed_RA_kms']) for row in ref]))
            checks.append(dict(arm=arm,distance=distance,orbit_return=err,
                late_replay_dec_relative=late_dec_err,late_replay_vlos_relative=late_vel_err,
                early_late_track_cosine=(early_dec@late_dec)/(np.linalg.norm(early_dec)*np.linalg.norm(late_dec)),
                nonlinear_dec_fraction=residual(early_dec+late_dec,both_dec),
                nonlinear_velocity_fraction=residual(early_vel+late_vel,both_vel),
                gradient_nonlinear=(both_gradient-early_gradient-late_gradient)))
            if orbit_factor==1:assert max(late_dec_err,late_vel_err)<.005
            for release in (early.end/2-10,early.end/2,early.end/2+10):
                for sign in SIGNS:
                    center,velocity=early.move(0,release,(initial[0][:1],initial[1][:1]),sign)
                    radial=center[0]*[1,1,0];radial/=np.linalg.norm(radial)
                    az=np.cross([0,0,1],radial)
                    if az@velocity[0]<0:az=-az
                    offset=np.array([0,-1,1])[:,None]
                    at590=early.move(release,early.end,(center+.060*offset*radial,velocity+CONV*offset*az),sign)
                    pos,speed=late.move(0,late.end,at590,sign)
                    obs=observed(pos-pos[:1]+final[0][:1],speed-speed[:1]+final[1][:1])
                    for tail,entry in zip(('inner','outer'),obs[1:]-obs[0]):
                        escapes.append(dict(arm=arm,distance=distance,flow=sign,release=release,tail=tail,
                                            ra_deg=entry[0],dec_deg=entry[1],vlos_kms=entry[2]))
            print(factor,orbit_factor,arm,distance,flush=True)
        maps.append(dict(arm=arm,early_min=early.minr,early_max=early.maxr,late_min=late.minr,late_max=late.maxr))
    label=f'{factor}-{orbit_factor}'
    for name,rows in [('summary',outcomes),('bins',bins),('checks',checks),('escapes',escapes),('radii',maps)]:
        csv_out(f'{name}-{label}.csv',rows)

if __name__=='__main__':
    stage(int(sys.argv[1]),int(sys.argv[2]))
