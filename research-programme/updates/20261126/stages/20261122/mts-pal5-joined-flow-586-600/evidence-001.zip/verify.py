import csv
import json
import sys
from early import HERE,PAL,LATE,OLD,INVERSE,np,pinned,sha,record
from tracers import csv_out


def rows(name):
    with (HERE/name).open(newline='') as stream:return list(csv.DictReader(stream))


def verify(include_orbit_refinement=True):
    ceilings = []
    timing = []
    pairings=[('2-1','4-1')]
    if include_orbit_refinement and (HERE/'summary-4-2.csv').is_file():
        verify(False)
        pairings.append(('4-1','4-2'))
    final=pairings[-1][-1]
    for low,high in pairings:
        def gate(arm,distance,case,variable,first,second):
            denom=np.linalg.norm(second)
            delta=np.linalg.norm(np.asarray(first)-second)
            err=delta/denom if denom else (0 if not delta else float('inf'))
            ceilings.append(dict(low=low,high=high,arm=arm,distance=distance,case=case,
                                 variable=variable,relative=err,passes=err<.005))
        for arm in ('reset','coupled'):
            for distance in (20.9,22.05,23.2):
                def get(prefix,stage):
                    return [row for row in rows(f'{prefix}-{stage}.csv')
                            if row['arm']==arm and float(row['distance'])==distance]
                for case in ('early','late','both'):
                    for prefix,cols in [('bins',('dec_deg','vlos_kms','position_pc')),('summary',('gradient',))]:
                        def sample(tag,field):
                            data=[row for row in get(prefix,tag) if row['case']==case]
                            assert len(data)==(20 if prefix=='bins' else 1)
                            return np.array([float(row[field]) for row in data])
                        for col in cols:gate(arm,distance,case,col,sample(low,col),sample(high,col))
                def release(tag,col):
                    data=get('escapes',tag)
                    bank={(float(row['release']),row['tail'],row['flow']):float(row[col]) for row in data}
                    times=sorted({key[0] for key in bank});assert len(times)==3 and len(bank)==12
                    return np.array([[[bank[t,tail,sign] for t in times] for sign in ('forward','reverse')]
                                    for tail in ('inner','outer')])
                for col in ('ra_deg','dec_deg','vlos_kms'):
                    first,second=release(low,col),release(high,col)
                    gate(arm,distance,'escape',col,np.diff(first,axis=1),np.diff(second,axis=1))
                    if high==final:
                        for idx,tail in enumerate(('inner','outer')):
                            separation=abs(np.diff(second[idx],axis=0)).max()
                            spans=abs(second[idx,:,0]-second[idx,:,-1])
                            timing.append(dict(arm=arm,distance=distance,tail=tail,observable=col,
                                largest_same_date_split=separation,forward_early_to_late=spans[0],
                                reverse_early_to_late=spans[1],smaller_timing_over_sign=spans.min()/separation))
    for factor in (2,4):
        for arm in ('reset','coupled'):
            base=f'early-{70*factor}-{arm}'
            rec=json.loads((HERE/(base+'.json')).read_bytes())
            pinned(HERE/(base+'.npz'),rec['packet'])
            assert rec['source']==OLD[f'states-586-{70*factor}.npz'] and rec['late']==LATE[f'potential-{18*factor}.npz']
            assert rec['protocol']==sha(HERE/'PROTOCOL.md') and rec['generator']==sha(HERE/'early.py')
            for row in rec['checks'].values():
                assert max(row['endpoint_586'],row['occupation'],*row['relative_590_join'])<1e-9
    summary=rows(f'summary-{final}.csv')
    assert len(summary)==18 and len(timing)==36 and len(ceilings)==90*len(pairings)
    both=[row for row in summary if row['case']=='both']
    old=json.loads(pinned(PAL/'coverage.json',LATE['coverage.json']).read_bytes())
    dur_old=old['tested_both_signs_590_600']['span_Myr']
    with np.load(HERE/'early-280-reset.npz') as bank:early=float(bank['time'][-1])
    duration=dur_old+early
    verdict=dict(duration_Myr=duration,early_Myr=early,late_Myr=dur_old,percent_of_tail_drift=100*duration/1940,
               percent_of_disruption_model=100*duration/5000,comparisons=len(ceilings),
               failures=[row for row in ceilings if not row['passes']],
               min_timing_over_sign=min(row['smaller_timing_over_sign'] for row in timing),
               biggest_pc=max(float(row['max_pc']) for row in both),
               biggest_bin_sigma=max(float(row['max_bin_sigma']) for row in both),
               biggest_diagonal_sigma=max(float(row['diag_track_sigma']) for row in both),
               biggest_gradient_sigma=max(float(row['gradient_sigma']) for row in both))
    csv_out(f'refinement-{final}.csv',ceilings);csv_out(f'timing-{final}.csv',timing)
    record(f'verdict-{final}.json',verdict)
    print(json.dumps(verdict,indent=1))
    if final=='4-2' and (HERE/'RESULTS.md').is_file():
        import importlib.util
        spec=importlib.util.spec_from_file_location('local_tilt',HERE/'tilt.py')
        module=importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        for tag in ('4-1','4-2'):
            module.diagnose(tag)
        files={p.name:sha(p) for p in sorted(HERE.iterdir()) if p.is_file() and p.name!='seal.json'}
        record('seal.json',files);print('Sealed',len(files),sha(HERE/'seal.json'))


if __name__=='__main__':
    verify()
