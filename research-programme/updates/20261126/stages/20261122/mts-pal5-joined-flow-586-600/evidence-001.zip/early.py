import os
import sys
for key in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','BLIS_NUM_THREADS'):
    os.environ[key]='1'
sys.dont_write_bytecode=True
import hashlib
import json
from pathlib import Path
from types import SimpleNamespace
import numpy as np

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
INVERSE=ROOT/'mts-flow-formation-inverse-586-20261122'
PAL=ROOT/'mts-pal5-frozen-flow-window-20261122'

def sha(path):
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()

def pinned(path,digest):
    if sha(path)!=digest:raise ValueError(f'input changed: {path}')
    return path

def sealed(folder,digest):
    return json.loads(pinned(folder/'seal.json',digest).read_bytes())

OLD=sealed(INVERSE,'4ae215216dac834ea5d8ae503fea680707af22348044627efb0b507a7c398fcb')
LATE=sealed(PAL,'5a04b08198e0e77b52e89e375dad68d897be461564ffbd81fe1c598364641e3c')
pinned(INVERSE/'inverse.py',OLD['inverse.py'])
sys.path.insert(0,str(INVERSE))
from inverse import setup

def retain(name,data):
    path=HERE/name
    if path.exists():
        if sha(path)!=hashlib.sha256(data).hexdigest():raise ValueError(f'replay differs: {name}')
    else:
        with path.open('xb') as stream:stream.write(data)

def record(name,body):
    retain(name,(json.dumps(body,indent=2,sort_keys=True,allow_nan=False)+'\n').encode())

def build(factor):
    import io
    if factor not in (2,4):raise ValueError(factor)
    count=70*factor
    ref_name=f'states-586-{count}.npz'
    ref=pinned(INVERSE/ref_name,OLD[ref_name])
    late_file=f'potential-{18*factor}.npz'
    late=pinned(PAL/late_file,LATE[late_file])
    lab,Evolution,advance,guard,_=setup()
    from directional import Radial,green
    run,obj=lab.run,lab.obj
    mesh=Radial(lab,16)
    duration=run.ages[590]-run.ages[586]
    native,dt=run.interval(586,590)
    assert native==70
    dt=-dt/factor
    rad=np.arange(2.,35.01,.25/factor)
    assert rad[-1]<mesh.inf*obj.bg.length
    normalize=np.sqrt(2*mesh.sell+1)*obj.bg.vel**2
    host=[]
    for snap in (586,590):
        val,slope=mesh.values(mesh.potential_nodes(lab.mesh.ordinary+run.fields[snap]),rad/obj.bg.length)
        host.append(np.stack([val*normalize,slope*normalize/obj.bg.length],axis=-1))
    with np.load(ref) as inverse,np.load(late) as after:
        irad=np.searchsorted(rad,after['radius'])
        assert np.array_equal(rad[irad],after['radius'])
        assert np.allclose(host[1][irad],after['host'][0],rtol=1e-12,atol=1e-9)
        for arm in ('reset','coupled'):
            name=f'early-{count}-{arm}'
            bundle=dict(radius=rad,host=np.array(host))
            checks={}
            for sign in ('forward','reverse'):
                label=arm+'_'+sign
                state=lab.initial[arm].copy()
                if sign=='reverse':state=state.conj()
                mom=obj.moment(state);solver=Evolution(obj,dt,state)
                times=[];fields=[];worst=0.
                for tick in range(count+1):
                    if tick%4==0 or tick==count:
                        guard()
                        progress=(count-tick)/count
                        ext=run.fields[586]+progress*(run.fields[590]-run.fields[586])
                        proxy=SimpleNamespace(obj=obj,run=SimpleNamespace(fields={590:ext}),initial={'zero':state*0,'wave':state})
                        potential,slope,_=green(proxy,mesh,rad/obj.bg.length)
                        arr=np.stack([potential*normalize[None,:,None],slope*(normalize/obj.bg.length)[None,:,None]],axis=-2)
                        arr[...,1]/=obj.unit_myr
                        times.append(duration*progress);fields.append(arr)
                    if tick<count:
                        state,mom,_,_=advance(obj,solver,state,mom,run.external(586,590,count-1-tick,count),dt)
                        worst=max(worst,abs(np.vdot(state,state).real/obj.number-1))
                diff=np.linalg.norm(state-inverse[label])/np.sqrt(obj.number)
                join=[]
                for derivative in (0,1):
                    cmp=after[label][0,...,derivative]
                    join.append(float(np.linalg.norm(fields[0][irad,...,derivative]-cmp)/np.linalg.norm(cmp)))
                assert worst<1e-9 and diff<1e-9 and max(join)<1e-9,(worst,diff,join)
                bundle[label]=np.asarray(fields[::-1]);bundle['time']=np.array(times[::-1])
                checks[label]=dict(occupation=worst,endpoint_586=diff,relative_590_join=join)
                print(count,label,'verified 586 and 590', flush=True)
            buf=io.BytesIO();np.savez_compressed(buf,**bundle);retain(name+'.npz',buf.getvalue())
            record(name+'.json',dict(source=sha(ref),late=sha(late),packet=sha(HERE/(name+'.npz')),
                     protocol=sha(HERE/'PROTOCOL.md'),generator=sha(HERE/'early.py'),checks=checks))

if __name__=='__main__':
    build(int(sys.argv[1]))
