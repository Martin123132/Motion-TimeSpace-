from early import HERE, np
from tracers import TRACK,RA0,csv_out
import csv


def diagnose(label):
    results=[]
    sigma=TRACK['sigma_dec']
    basis=(TRACK['ra']-RA0)/sigma
    with (HERE/('bins-'+label+'.csv')).open(newline='') as stream:
        tracks=list(csv.DictReader(stream))
    for arm in ('reset','coupled'):
        for distance in (20.9,22.05,23.2):
            bins=[row for row in tracks if row['arm']==arm and
                  float(row['distance'])==distance and row['case']=='both']
            assert np.array_equal(TRACK['ra'],[float(row['ra']) for row in bins])
            signal=np.array([float(row['dec_deg']) for row in bins])/sigma
            tilt=basis@signal/(basis@basis)
            residual=signal-tilt*basis
            assert abs(residual@basis)<1e-9
            assert abs(np.linalg.norm(signal)**2-tilt**2*(basis@basis)-residual@residual)<1e-9
            results.append(dict(arm=arm,distance=distance,full_diagonal=np.linalg.norm(signal),
                         matching_tilt_deg_per_deg=tilt,residual_diagonal=np.linalg.norm(residual),
                         percent_squared_difference_in_tilt=100*(tilt**2*(basis@basis))/(signal@signal)))
    csv_out(f'tilt-sensitivity-{label}.csv',results)


if __name__=='__main__':
    import sys
    diagnose(sys.argv[1])
