import os
import sys
for key in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','BLIS_NUM_THREADS','NUMEXPR_NUM_THREADS'):
    os.environ[key]='1'
sys.dont_write_bytecode=True
import csv
import hashlib
import io
import json
from pathlib import Path
import numpy as np
from scipy.special import roots_legendre

HOME=Path(__file__).resolve().parent
ROOT=HOME.parent
GRAVITY=4.30091727003628e-6
SHELLS=np.hypot([6.,7.15,8.3],1.5)
ARMS=('reset','coupled')
SIGNS=('forward','reverse')
OLD=ROOT/'mts-fire-directional-lapse-20261121'
FREEZE=ROOT/'mts-fire-density-forecast-20261121'
LAST=ROOT/'mts-pal5-frozen-flow-window-20261122'

def sha(path):
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()

def pin(path,expected):
    if sha(path)!=expected:raise ValueError(f'changed source: {path}')
    return path

def keep(name,data):
    target=HOME/name
    if target.exists():
        if target.read_bytes()!=data:raise ValueError(f'conflicting replay: {name}')
    else:
        with target.open('xb') as file:file.write(data)

def table(name,rows):
    stream=io.StringIO()
    writer=csv.DictWriter(stream,fieldnames=rows[0],lineterminator='\n')
    writer.writeheader();writer.writerows(rows);keep(name,stream.getvalue().encode())

def record(name,value):
    keep(name,(json.dumps(value,indent=2,sort_keys=True,allow_nan=False)+'\n').encode())

def chord(first,second):
    first=first/np.linalg.norm(first);second=second/np.linalg.norm(second)
    phase=np.exp(-1j*np.angle(np.vdot(second,first)))
    return np.linalg.norm(phase*first-second)

def setup():
    freeze=json.loads(pin(FREEZE/'freeze.json','56e6fe56045146e609bdb80a970949886d0bcf0d49312d8332fe72b068d17776').read_bytes())
    pin(FREEZE/'enclosed-forecast.csv',freeze['mass'])
    prev=json.loads(pin(LAST/'seal.json','5a04b08198e0e77b52e89e375dad68d897be461564ffbd81fe1c598364641e3c').read_bytes())
    pin(LAST/'evolution-18.json',prev['evolution-18.json'])
    sources=json.loads(pin(OLD/'seal.json','b3de88dae7ca047c80bba71d04957085dc3f6c805a5d1a89d0b747ad1587f16c').read_bytes())
    sys.path.insert(0,str(OLD))
    from directional import guard
    from matched_io import Launch,Evolution,advance
    from mts_radial_inputs import shape
    guard();lab=Launch(64)
    for arm in ARMS:
        name=f'flight-16-{arm}-represented.npz'
        with np.load(pin(OLD/name,sources[name])) as bank:
            assert np.array_equal(bank['wave'][0],lab.initial[arm])
    return lab,Evolution,advance,guard,shape

def run(factor):
    assert factor in (1,2,4,8)
    lab,Evolution,advance,guard,shape=setup()
    run=lab.run;obj=lab.obj
    native,dt=run.interval(586,590);count=native*factor;dt/=factor
    assert native==70
    duration=run.ages[590]-run.ages[586]
    start=run.fields[586];finish=run.fields[590];diff=finish-start
    number=obj.number;unit=obj.bg.vel**2/number
    old={'reset':run.reference[586],'coupled':lab.raw[586]}
    sample,weight=roots_legendre(16);el=run.el;faces=SHELLS/obj.bg.length
    def basis(points):
        idx=np.searchsorted(el.right,points)
        value,slope=shape(el.knots,(points-el.left[idx])/el.width[idx])
        return idx,value,slope/el.width[idx,None]
    edges=np.unique(np.r_[0.,el.right,faces]);delta=np.diff(edges)
    knots=(edges[:-1,None]+delta[:,None]*(sample+1)/2).ravel()
    measure=(delta[:,None]*weight/2).ravel()
    idx,interp,_=basis(knots);front,interp_face,slope_face=basis(faces)
    def shells(state):
        nodes=el.nodes(state)
        u=np.einsum('ti,til->tl',interp,nodes[idx])
        mass=lab.mesh.mscale*measure*np.sum(abs(u)**2,axis=1)
        value=np.einsum('ti,til->tl',interp_face,nodes[front])
        slope=np.einsum('ti,til->tl',slope_face,nodes[front])
        rate=-lab.mesh.mscale/obj.unit_myr*np.sum((value.conj()*slope).imag,axis=1)
        return np.array([mass[knots<rad].sum() for rad in faces]),rate
    def probability(state):
        raw=abs(obj.sky(state))**2*obj.bg.sqrt[:,None]**2*obj.bg.aw[None,:]
        assert abs(raw.sum()/np.vdot(state,state).real-1)<1e-9
        return raw/raw.sum()
    def travel(initial,backward):
        signed_dt= -dt if backward else dt
        solver=Evolution(obj,signed_dt,initial);state=initial.copy();moment=obj.moment(state)
        old_energy=(obj.energy(state)+np.vdot(state,obj.multiply(finish if backward else start,state)).real)*unit
        incoming=np.vdot(state,obj.multiply(diff,state)).real
        work=0.;drift=0.
        for tick in range(count):
            if tick%16==0:guard()
            index=count-1-tick if backward else tick
            drive=run.external(586,590,index,count)
            state,moment,_,_=advance(obj,solver,state,moment,drive,signed_dt)
            after=np.vdot(state,obj.multiply(diff,state)).real
            work+=(after+incoming)*(.5/count)*(-1 if backward else 1)*unit
            incoming=after
            drift=max(drift,abs(np.vdot(state,state).real/number-1))
        new_energy=(obj.energy(state)+np.vdot(state,obj.multiply(start if backward else finish,state)).real)*unit
        residual=(new_energy-old_energy)-work
        assert drift<1e-9 and abs(residual)<.0003,(drift,residual)
        return state,work,residual,drift
    with (FREEZE/'enclosed-forecast.csv').open() as handle:forecast=list(csv.DictReader(handle))
    physical=[];formation=[];dynamics=[];bank={}
    for arm in ARMS:
        if factor==1:
            replay,_,_,_=travel(old[arm],False)
            error=np.linalg.norm(replay-lab.initial[arm])/np.sqrt(number)
            assert error<1e-9,error
        else:error=None
        for sign in SIGNS:
            launch=lab.initial[arm] if sign=='forward' else lab.initial[arm].conj()
            bank[arm+'_'+sign],undo,rev_err,d1=travel(launch,True)
            required=bank[arm+'_'+sign]
            returned,work,fwd_err,d2=travel(required,False)
            close=np.linalg.norm(returned-launch)/np.sqrt(number)
            assert close<1e-9,(arm,sign,close)
            dynamics.append(dict(arm=arm,flow=sign,roundtrip_raw=close,max_occupation_drift=max(d1,d2),
                      forward_archive_direct=error,backward_work_kms2=undo,forward_work_kms2=work,
                      backward_energy_minus_work_kms2=rev_err,forward_energy_minus_work_kms2=fwd_err))
            for key,arch in old.items():
                distance=chord(required,arch);tv=.5*np.sum(abs(probability(required)-probability(arch)))
                trace=distance*np.sqrt(max(0.,1-distance**2/4))
                assert tv<=trace+1e-9
                if key==arm and factor==1 and sign=='forward':
                    assert np.linalg.norm(arch-required)/np.sqrt(number)<1e-9
                formation.append(dict(arm=arm,flow=sign,archive=key,phase_free_norm=distance,
                        trace_distance=trace,coordinate_mass_TV=tv))
            at_launch=shells(launch);target=[row for row in forecast if row['arm']==arm and row['direction']==('forward' if sign=='forward' else 'reversed')]
            for index,col in enumerate(('mass_Msun','dmass_dt_Msun_Myr')):
                target_values=np.array([float(row[col]) for row in target])
                assert np.allclose([float(row['r_kpc']) for row in target],SHELLS,rtol=1e-14,atol=0)
                rel=np.linalg.norm(at_launch[index]-target_values)/np.linalg.norm(target_values)
                assert rel<.005,(arm,sign,col,rel)
                dynamics[-1][col+'_launch_relative']=rel
            for epoch,state in [(586,required),(590,launch)]:
                mass,rate=shells(state)
                for rad,total,flux in zip(SHELLS,mass,rate):
                    physical.append(dict(arm=arm,flow=sign,epoch=epoch,radius_kpc=rad,enclosed_Msun=total,
                          influx_Msun_yr=flux/1e6,inward_mean_g_kms2_kpc=GRAVITY*total/rad**2))
            print('checked',count,arm,sign,flush=True)
    out=io.BytesIO();np.savez_compressed(out,**bank);keep(f'states-586-{count}.npz',out.getvalue())
    table(f'formation-{count}.csv',formation);table(f'budgets-{count}.csv',dynamics);table(f'shells-{count}.csv',physical)
    record(f'interval-{count}.json',dict(dt_Myr=duration/count,duration_Myr=duration,steps=count,
               protocol=sha(HOME/'PROTOCOL.md'),physical_launch=sha(FREEZE/'freeze.json'),previous=sha(LAST/'seal.json')))
if __name__=='__main__':run(int(sys.argv[1]))
