import json
from pathlib import Path
from inverse import HOME,ROOT,ARMS,SIGNS,chord,np,record,sha
from formation_bounds import rows

def verify():
    verdict=json.loads((HOME/'verdict.json').read_bytes())
    assert verdict['counts']==[70,140,280] and verdict['both_roundtrip'] and not verdict['reverse_in_archived_span']
    assert verdict['observed_physical_sign'] is None and verdict['maximum_final_refinement']<.005
    first=np.array([1.,1.])/np.sqrt(2)
    spectrum=np.array([-.3,.3]);span=.8
    for scalar in (0.,7.):
        shifted=spectrum+scalar
        second=first*np.exp(-1j*shifted*span)
        measured=2*np.arcsin(chord(first,second)/2)
        sigma=np.sqrt(np.mean((shifted-shifted.mean())**2))
        assert abs(measured-sigma*span)<1e-12
    for count in verdict['counts']:
        budgets=rows(f'budgets-{count}.csv');states=np.load(HOME/f'states-586-{count}.npz')
        assert len(budgets)==4 and set(states.files)=={arm+'_'+sign for arm in ARMS for sign in SIGNS}
        assert all(np.isfinite(states[key]).all() for key in states.files)
        for entry in budgets:
            for key in ('roundtrip_raw','max_occupation_drift'):
                assert float(entry[key])<1e-9
            for key in ('mass_Msun_launch_relative','dmass_dt_Msun_Myr_launch_relative'):
                assert float(entry[key])<.005
            if count==70:assert float(entry['forward_archive_direct'])<1e-9
        states.close()
    inputs={}
    for folder,master,filenames in [
        ('mts-fire-581-formation-state-20261120','a468eac90a9e2ec4a840dfbcf1ec23a0c4cc7acc6c17f7d258f229ab44116a1a',['wave-anchorA-joint-64.npz']),
        ('mts-pre572-wave-preparation-20261120','ce9ca0f03916af1fa3bfd449a61e779a74ce3427fae0a3a6bcdf65bc2b6c70ee',['state-anchorA-three-64.npz']),
        ('mts-fire-joint-baryon-history-20261120','19c78eaa158a766bd409c0a64504788b1346542eccee37c004083a918c480d67',['forcing-586.npz','forcing-590.npz','snapshot_times.txt']),
        ('mts-pal5-frozen-flow-window-20261122','5a04b08198e0e77b52e89e375dad68d897be461564ffbd81fe1c598364641e3c',['RESULTS.md','evolution-18.json']),
        ('mts-fire-prepared-gradient-20261121','1e17aec24a8fa2df0d14d3e9bfdccfef18006eb3c4a16fd1597713ce224ace23',['pair.py','paired-balance-64.csv']),
        ('mts-fire-directional-lapse-20261121','b3de88dae7ca047c80bba71d04957085dc3f6c805a5d1a89d0b747ad1587f16c',['flight-16-reset-represented.npz','flight-16-coupled-represented.npz'])]:
        manifest=ROOT/folder/'seal.json'
        assert sha(manifest)==master
        ledger=json.loads(manifest.read_bytes());ledger=ledger.get('files',ledger)
        for name in filenames:
            path=manifest.parent/name
            digest=sha(path)
            assert ledger[name]==digest
            inputs[path.relative_to(ROOT).as_posix()]=digest
    record('source-fingerprints.json',inputs)
    assert (HOME/'RESULTS.md').is_file()
    bundle={item.name:sha(item) for item in sorted(HOME.iterdir()) if item.is_file() and item.name!='seal.json'}
    record('seal.json',bundle)
    print(len(bundle),'files verified. Seal:',sha(HOME/'seal.json'))
if __name__=='__main__':verify()
