from core import HOME,RR,JOIN,OLD,np,sys,saved,guard,pin,projected,heliocentric,spin,read,table,record

def run(factor,orbit):
    label=f"{factor}-{orbit}"
    initial=saved.inputs("measured")
    pos,vel=heliocentric(*initial)
    reference=projected(pos,vel)[0]
    for index,name in enumerate(("distance","pmra","pmdec")):
        assert np.max(abs(reference[1:,index]-saved.col(name)))<5e-12
    assert np.max(abs(reference[:,3]-(-58.7+1.2*(saved.RA-saved.RA0))))<1e-10
    past=read(pin(RR,f"predictions-{label}-central.csv")) if (RR/f"predictions-{label}-central.csv").exists() else []
    output=[];checks=[];individual=[]
    for arm in saved.ARMS:
        guard()
        with np.load(pin(JOIN,f"early-{70*factor}-{arm}.npz")) as bank:early=saved.Segment(bank,arm,192*factor*orbit)
        with np.load(pin(OLD,f"potential-{18*factor}.npz")) as bank:late=saved.Segment(bank,arm,192*orbit)
        mid=late.move(late.end,0.,initial,"mean");birth=early.move(early.end,0.,mid,"mean")
        def evolve(sign):
            guard()
            return late.move(0.,late.end,early.move(0.,early.end,birth,sign),sign)
        recovered=evolve("mean")
        err=max(abs(actual-target).max() for actual,target in zip(recovered,initial))
        assert err<1e-9
        endpoints=[];spins=[];positions=[]
        for sign in saved.SIGNS:
            state=tuple(values-values[:1]+target[:1] for values,target in zip(evolve(sign),initial))
            point,speed=heliocentric(*state)
            endpoints.append(projected(point,speed)[0]);positions.append(point)
            spins.append([spin(point,speed,flag) for flag in (True,False)])
        signal=endpoints[0]-endpoints[1]
        lengths=np.linalg.norm(positions[0]-positions[1],axis=1)*1000
        assert np.max(abs(signal[0]))<1e-11 and max(abs(lengths[0]),np.max(abs(np.asarray(spins)[:,:,0])))<1e-10
        pre={r["id"]:r for r in past if r["arm"]==arm and r["case"]=="measured"}
        velerr=poserr=0.
        for index,row in enumerate(saved.TAIL,1):
            if pre:
                velerr=max(velerr,abs(signal[index,3]-float(pre[row["id"]]["dv_same_star_kms"])))
                poserr=max(poserr,abs(lengths[index]-float(pre[row["id"]]["pc"])))
            result=dict(arm=arm,id=row["id"],primary=row["tail_11p2"],ra=row["ra"],delta_kpc=signal[index,0],
                delta_east_masyr=signal[index,1],delta_north_masyr=signal[index,2],delta_los_kms=signal[index,3],separation_pc=lengths[index])
            for k,kind in enumerate(("rigid","position")):
                for idx,tag in enumerate(("forward","reverse")):
                    for axis,name in enumerate(("d","e","n")):result[f"{kind}_{tag}_{name}"]=spins[idx][k][index,axis]
            output.append(result)
            for sign,values in zip(saved.SIGNS,endpoints):
                difference=values[index]-reference[index]
                individual.append(dict(arm=arm,sign=sign,id=row["id"],primary=row["tail_11p2"],delta_kpc=difference[0],
                    delta_east_masyr=difference[1],delta_north_masyr=difference[2]))
        assert velerr<5e-8 and poserr<5e-6
        checks.append(dict(arm=arm,mean_return=err,archived_targets=len(pre),max_los_replay_error_kms=velerr,max_displacement_replay_error_pc=poserr,early_range=[early.minr,early.maxr],late_range=[late.minr,late.maxr]))
    table(f"astrometry-{label}.csv",output);record(f"controls-{label}.json",checks)
    table(f"endpoints-{label}.csv",individual)
    print(label,checks,flush=True)
if __name__=="__main__":run(*map(int,sys.argv[1:]))
