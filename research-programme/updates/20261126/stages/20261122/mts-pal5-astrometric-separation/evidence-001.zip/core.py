from pathlib import Path
import csv
import hashlib
import io
import json
import os
import sys

HOME = Path(__file__).resolve().parent
ROOT = HOME.parent
RR = ROOT / "mts-pal5-measured-rrl-20261122"
JOIN = ROOT / "mts-pal5-joined-flow-586-600-20261122"
OLD = ROOT / "mts-pal5-frozen-flow-window-20261122"
LAST = ROOT / "mts-pal5-finite-wave-stripping-20261122"
PINS = {RR:"e94eaf7948ea6a477eecd1124486c2df30a70144d092ebd7caf61c4176b35a55",JOIN:"86d9b1296c253b14a04e475339a9cbf71f84fed201749a234af4892b715576b7",OLD:"5a04b08198e0e77b52e89e375dad68d897be461564ffbd81fe1c598364641e3c",LAST:"4db5e73d0a80bbc234e7d1036b11a99d2965805c6eb42d04f91f4171260aa5e8"}
def digest(path):
    with path.open("rb") as handle:return hashlib.file_digest(handle,"sha256").hexdigest()
def pin(folder,name):
    assert digest(folder/"seal.json")==PINS[folder]
    assert digest(folder/name)==json.loads((folder/"seal.json").read_bytes())[name],name
    return folder/name
def guard():
    assert not any((folder/"STOP-REQUESTED").exists() for folder in (HOME,ROOT,*PINS,ROOT/"mts-fire-joint-baryon-history-20261120",ROOT/"mts-pal5-live-wave-coupling-20261122",ROOT/"mts-flow-formation-inverse-586-20261122",ROOT/"mts-pal5-interface-work-20261122",ROOT/"mts-pal5-release-evolution-20261122",ROOT/"mts-pal5-source-tides-20261122"))
def store(name,data):
    path=HOME/name
    if path.exists():assert path.read_bytes()==data,name
    else:
        with path.open("xb") as handle:handle.write(data)
def table(name,rows):
    buffer=io.StringIO()
    writer=csv.DictWriter(buffer,rows[0],lineterminator="\n");writer.writeheader();writer.writerows(rows)
    store(name,buffer.getvalue().encode())
def read(path):
    with path.open() as handle:return list(csv.DictReader(handle))
def record(name,data):
    store(name,(json.dumps(data,sort_keys=True,indent=2,allow_nan=False)+"\n").encode())
for var in ("OPENBLAS_NUM_THREADS","MKL_NUM_THREADS","OMP_NUM_THREADS","NUMEXPR_NUM_THREADS","BLIS_NUM_THREADS"):os.environ[var]="1"
guard()
import numpy as np
for folder, names in {RR:("replay.py","catalogue.py","rrl-input.csv"),JOIN:("early.py","tracers.py"),OLD:("orbit.py","evolve.py","track.csv")}.items():
    for name in names:pin(folder,name)
sys.path.insert(0,str(RR))
import replay as saved
def heliocentric(pos,vel):
    return (pos-saved.SUN)@saved.ROT,(vel/saved.CONV-saved.VSUN)@saved.ROT
def projected(pos,vel):
    radius=np.linalg.norm(pos,axis=1)
    unit=pos/radius[:,None]
    planar=np.hypot(unit[:,0],unit[:,1])
    assert np.all(planar>1e-5)
    east=np.column_stack((-unit[:,1],unit[:,0],np.zeros(len(unit))))/planar[:,None]
    north=np.cross(unit,east)
    dot=lambda basis:(vel*basis).sum(axis=1)
    return np.column_stack((radius,dot(east)/(4.74047*radius),dot(north)/(4.74047*radius),dot(unit))),unit,east,north
def rotated(vec,axis,angle):
    return vec*np.cos(angle)+np.cross(axis,vec)*np.sin(angle)+(1-np.cos(angle))*(vec@axis)[:,None]*axis
def spin(pos,vel,moving=True):
    obs,unit,east,north=projected(pos,vel)
    axis=unit[0]
    dpos=np.cross(axis,pos-pos[0]);dvel=np.cross(axis,vel-vel[0]) if moving else np.zeros_like(vel)
    dd=(dpos*unit).sum(axis=1)
    dn=(dpos-dd[:,None]*unit)/obs[:,0,None]
    da=(dn*east).sum(axis=1)/np.hypot(unit[:,0],unit[:,1])
    deast=np.column_stack((-east[:,1],east[:,0],np.zeros(len(east))))*da[:,None]
    dnorth=np.cross(dn,east)+np.cross(unit,deast)
    components=[((dvel*base+vel*dbase).sum(axis=1)/(4.74047*obs[:,0])-obs[:,index]*dd/obs[:,0]) for index,base,dbase in ((1,east,deast),(2,north,dnorth))]
    analytic=np.column_stack((dd,*components))
    for step in (1e-4,5e-5):
        endpoints=[]
        for sign in (-1,1):
            xp=pos[0]+rotated(pos-pos[0],axis,sign*step)
            vp=vel[0]+rotated(vel-vel[0],axis,sign*step) if moving else vel
            endpoints.append(projected(xp,vp)[0][:,:3])
        derivative=(endpoints[1]-endpoints[0])/(2*step)
        assert np.max(abs(derivative-analytic))<1e-7 and np.max(abs(dd))<1e-12
    return analytic
