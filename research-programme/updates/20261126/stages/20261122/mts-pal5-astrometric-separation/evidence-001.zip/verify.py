from core import HOME,ROOT,RR,JOIN,OLD,LAST,read,record,pin,np,digest,guard
from common import nearest
from math import erf,sqrt
import json
import re
import sys

def run(seal=False):
    guard()
    for name in ("RESULTS.md","DESIGN.md","METHOD.md","COMMON-DIRECTION.md"):
        for link in re.findall(r"\]\(([^)]+)\)",(HOME/name).read_text(encoding="utf-8")):
            if not link.startswith("https://"):assert (HOME/link).is_file(),link
    for path in HOME.glob("*.py"):compile(path.read_bytes(),str(path),"exec")
    assert not (HOME/"__pycache__").exists()
    pin(LAST,"RESULTS.md");pin(OLD,"track.csv");pin(RR,"rrl-input.csv");pin(JOIN,"bins-4-2.csv")
    forward=np.array([[0.,1.],[1.,1.]]);reverse=np.array([[0.,0.],[1.,0.]])
    distance,_,normal=nearest(forward,reverse)
    assert abs(distance-1)<1e-12 and np.max(abs(normal-[0,1]))<1e-12
    assert nearest(np.eye(2),np.eye(2)[::-1])[0]<1e-12
    assert abs(nearest(np.array([[0.,3.],[0.,2.]]),np.array([[0.,0.],[0.,1.]]))[0]-1)<1e-12
    outcomes=read(HOME/"any-classifier-bound.csv")
    assert len(outcomes)==12
    for row in outcomes:
        actual=[float(row["distance_"+f+"_"+r]) for f in ("reset","coupled") for r in ("reset","coupled")]
        known=50*(1+erf(min(actual)/(2*sqrt(2))))
        assert abs(known-float(row["any_rule_worst_case_upper_percent"]))<1e-10
        assert float(row["worst_case_linear_percent"])<=known+1e-10
    max_upper_change=0.
    for mode in ("calibrated","free_offsets"):
        for sample in ("17","18"):
            values=[min(float(r["distance_"+f+"_"+b]) for b in ("reset","coupled") for f in ("reset","coupled")) for r in outcomes if r["mode"]==mode and r["stars"]==sample]
            assert len(values)==3
            max_upper_change=max(max_upper_change,max(values)/min(values)-1)
    assert max_upper_change<.005
    for label in ("2-1","4-1","4-2"):
        controls=json.loads((HOME/f"controls-{label}.json").read_bytes())
        assert len(controls)==2 and all(r["archived_targets"]==18 and r["mean_return"]<1e-9 and r["max_los_replay_error_kms"]<1e-9 and r["max_displacement_replay_error_pc"]<1e-9 for r in controls)
        assert len(read(HOME/f"endpoints-{label}.csv"))==72
    for filename,count in (("refinements.csv",96),("common-refinements.csv",12)):
        rows=read(HOME/filename)
        assert len(rows)==count and all(r["passes"]=="True" and float(r["relative"])<.005 for r in rows)
    files={p.name:digest(p) for p in sorted(HOME.iterdir()) if p.is_file() and p.name!="seal.json"}
    if seal:record("seal.json",files)
    assert json.loads((HOME/"seal.json").read_bytes())==files
    print(len(files),"verified;",digest(HOME/"seal.json"),"closest-pair noise separation refinement",max_upper_change)
if __name__=="__main__":run(sys.argv[1:]==["--seal"])
