from common import HOME,RR,np,read,pin,arrays,residual,SIGNALS,table,record,erf,sqrt
from itertools import product
def accuracy(distance):
    return 50*(1+erf(distance/(2*sqrt(2))))
def bounds():
    catalogue={r["id"]:r for r in read(pin(RR,"rrl-input.csv"))}
    common=read(HOME/"common-observable.csv");results=[]
    for shared in common:
        grid=shared["grid"];size=int(shared["stars"]);mode=shared["mode"]
        rows=read(HOME/f"endpoints-{grid}.csv")
        get=lambda arm,sign:[r for r in rows if r["arm"]==arm and r["sign"]==sign and (size==18 or r["primary"]=="1")]
        base=get("reset","forward"); _,_,cov=arrays(base,catalogue)
        chol=np.linalg.cholesky(cov)
        white=lambda arr:np.linalg.solve(chol,arr.ravel())
        nuis=np.zeros((size,3,3));nuis[:,0,0]=[float(catalogue[r["id"]]["distance"]) for r in base]
        nuis[:,1,1]=nuis[:,2,2]=1
        cols=[white(nuis[:,:,k]) for k in range(3)] if mode=="free_offsets" else []
        vectors={}
        for arm,sign in product(("reset","coupled"),("forward","reverse")):
            selected=get(arm,sign);assert [r["id"] for r in selected]==[r["id"] for r in base]
            values=np.array([[float(r[k]) for k in SIGNALS] for r in selected])
            vectors[arm,sign]=residual(white(values),cols)
        pairs={(a,b):float(np.linalg.norm(vectors[a,"forward"]-vectors[b,"reverse"])) for a,b in product(("reset","coupled"),repeat=2)}
        for arm in ("reset","coupled"):
            ref=shared["reset_distance" if arm=="reset" else "inherited_distance"]
            assert abs(pairs[arm,arm]-float(ref))<1e-12
        closest=min(pairs,key=pairs.get);upper=accuracy(pairs[closest]);lower=float(shared["ideal_min_correct_percent"])
        assert lower<=upper+1e-10
        results.append(dict(grid=grid,stars=size,mode=mode,worst_case_linear_percent=lower,
            any_rule_worst_case_upper_percent=upper,gap_percentage_points=upper-lower,closest_forward=closest[0],closest_reverse=closest[1],
            **{f"distance_{a}_{b}":val for (a,b),val in pairs.items()}))
    table("any-classifier-bound.csv",results)
    ref=[r for r in results if r["grid"]=="4-2" and r["stars"]==17]
    record("classifier-bracket.json",ref)
if __name__=="__main__":bounds()
