import sys
from compare import pinned as check_predictions
from freeze import OLD,HOME,np,table,record,read,sha,inputs,ridge,forecast,MODES,KMS,RA0
import json
assert sha(OLD/'replay.py')==json.loads((OLD/'seal.json').read_bytes())['replay.py']
sys.path.insert(0,str(OLD))
from replay import JOIN,PAL,SEALED,LATE,SIGNS,ARMS,Segment,pinned,icrs,ROT,CONV,SUN,VSUN,observed
CASES=('tangent','measured_rv','measured_rv_pm','historical_rv_measured_pm')
def initial():
    check_predictions()
    stars=[r for r in read(HOME/'frozen-forecasts.csv') if r['mode']=='primary']
    lines=[line.split() for line in (OLD/'kuzma-table4.txt').read_text().splitlines() if line.strip() and not line.startswith('#')]
    cells=[lines[int(r['row'])-1] for r in stars];ra=np.array([float(r['ra']) for r in stars])
    dec=np.array([float(r['target_dec']) for r in stars]);dist=np.array([float(r['dist']) for r in stars])
    ids,train=inputs();modes=ridge(train,ra,'primary');pmra,pmdec=modes[4],modes[6]
    data=np.array([[float(c[idx]) for idx in (0,1,2,4,6)] for c in cells]);assert np.array_equal(data[:,0],ra) and np.array_equal(data[:,1],dec)
    vr=np.array([float(r['vlos']) for r in stars]);legacy=-58.7+1.20*(ra-RA0)
    lon=np.r_[RA0,ra];lat=np.r_[-.124,dec];distance=np.r_[20.6,dist]
    sight=icrs(lon,lat);east=icrs(lon+90,lat*0);north=np.cross(sight,east)
    xyz=SUN+distance[:,None]*(sight@ROT.T)
    states=[]
    for case in CASES:
        vlos=np.r_[-58.7,vr if case=='tangent' else (legacy if case.startswith('historical') else data[:,4])]
        use=case in ('measured_rv_pm','historical_rv_measured_pm')
        local=vlos[:,None]*sight+KMS*distance[:,None]*(np.r_[-2.75,data[:,2] if use else pmra][:,None]*east+np.r_[-2.69,data[:,3] if use else pmdec][:,None]*north)
        speed=(VSUN+local@ROT.T)*CONV
        assert np.max(abs(observed(xyz,speed)-np.column_stack([lon,lat,vlos])))<1e-9
        states.append((xyz,speed))
    return stars,tuple(np.concatenate([s[idx] for s in states]) for idx in range(2))
def run(factor,step):
    stars,final=initial();rows=[];stat=[]
    for arm in ARMS:
        first=f'early-{70*factor}-{arm}.npz';second=f'potential-{18*factor}.npz'
        with np.load(pinned(JOIN/first,SEALED[first])) as bank:early=Segment(bank,arm,192*factor*step)
        with np.load(pinned(PAL/second,LATE[second])) as bank:late=Segment(bank,arm,192*step)
        initial_state=early.move(early.end,0,late.move(late.end,0,final,'mean'),'mean')
        def evolve(sign):return late.move(0,late.end,early.move(0,early.end,initial_state,sign),sign)
        recovered=evolve('mean');roundtrip=max(abs(a-b).max() for a,b in zip(recovered,final))
        assert roundtrip<1e-9
        maps=[evolve(sign) for sign in SIGNS];assert tuple(SIGNS)==('forward','reverse')
        for idx,case in enumerate(CASES):
            width=len(stars)+1;part=slice(idx*width,(idx+1)*width);angular=[];xyz=[]
            for result in maps:
                shifted=[q[part]-q[part][:1]+anchor[part][:1] for q,anchor in zip(result,final)]
                angular.append(observed(*shifted)[1:]);xyz.append(shifted[0][1:])
            delta=angular[0]-angular[1];space=np.linalg.norm(xyz[0]-xyz[1],axis=1)*1000
            for jdx,star in enumerate(stars):
                dra,ddec,dvel=delta[jdx]
                rows.append(dict(arm=arm,case=case,row=star['row'],ra=star['ra'],dra=dra,ddec=ddec,dvel=dvel,
                                 fixed_historical=dvel-1.2*dra,pc=space[jdx]))
        stat.append(dict(arm=arm,roundtrip=roundtrip,early_min=early.minr,early_max=early.maxr,late_min=late.minr,late_max=late.maxr))
        print(factor,step,arm,'verified',roundtrip,flush=True)
    table(f'wave-{factor}-{step}.csv',rows);table(f'wave-control-{factor}-{step}.csv',stat)
if __name__=='__main__':
    for factor,step in [(2,1),(4,1),(4,2)]:run(factor,step)
