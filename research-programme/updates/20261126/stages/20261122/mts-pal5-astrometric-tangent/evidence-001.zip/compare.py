import json
from collections import Counter
from freeze import HOME,OLD,DEG,KMS,RA0,MODES,np,sha,read,record,table,inputs,forecast,ridge,velocity,supported

FROZEN='3d7fdc127d330ddba964016c718cc0078429b836692ac7174e2b51a775a7ed26'
def pinned():
    assert sha(HOME/'forecast-seal.json')==FROZEN
    for name,digest in json.loads((HOME/'forecast-seal.json').read_bytes()).items():
        assert sha(HOME/name)==digest
def num(rows,key):
    return np.array([float(r[key]) for r in rows])
def rms(values):return float(np.mean(values**2)**.5)
def score(rows):
    delta=num(rows,'residual');sigma=num(rows,'sigma_rv')
    return dict(count=len(rows),bias=float(np.mean(delta)),rms=rms(delta),median_abs=float(np.median(abs(delta))),
                median_reported_rv_error=float(np.median(sigma)),rms_reported_rv_error=rms(sigma))
def main():
    pinned()
    obs=[line.split() for line in (OLD/'kuzma-table4.txt').read_text().splitlines() if line.strip() and not line.startswith('#')]
    raw=read(HOME/'frozen-forecasts.csv');ses=read(HOME/'sensitivities.csv')
    sensitivity={int(r['row']):r for r in ses}
    rows=[];scores=[];groups={}
    for r in raw:
        idx=int(r['row']);cells=obs[idx-1]
        assert r['source']==cells[-1] and float(r['ra'])==float(cells[0]) and float(r['target_dec'])==float(cells[1])
        measured,err=map(float,cells[6:8])
        assert np.isfinite(measured) and np.isfinite(err) and err>0
        ra=float(r['ra']);speed=float(r['vlos']);rate=float(r['rate']);dd=float(r['dd'])
        allowed=abs(float(r['along']))>=10
        required=(measured+float(r['radproj']))/rate if allowed else None
        if allowed:assert abs((required-dd)*rate-(measured-speed))<1e-10
        rows.append(dict(row=idx,mode=r['mode'],source=r['source'],arm='leading' if ra<RA0 else 'trailing',
          ra=ra,measured=measured,sigma_rv=err,predicted=speed,residual=speed-measured,dd_predicted=dd,
          required_dd=required if allowed else '',dd_shortfall=required-dd if allowed else '',along=float(r['along']),
          rate=rate,dec_offset=float(r['dec_offset'])))
    primary=[r for r in rows if r['mode']=='primary']
    assert len(primary)==49 and len({r['row'] for r in primary})==49 and len(rows)==49*len(MODES)
    for mode in (*MODES,'historical_exposed'):
        if mode=='historical_exposed':
            items=[dict(r,predicted=-58.7+1.20*(r['ra']-RA0),residual=-58.7+1.20*(r['ra']-RA0)-r['measured']) for r in primary]
        else:items=[r for r in rows if r['mode']==mode]
        for scope,part in [('all',items)]+[(s,[r for r in items if r['source']==s]) for s in sorted({r['source'] for r in items})]+[(a,[r for r in items if r['arm']==a]) for a in ('leading','trailing')]:
            if part:scores.append(dict(mode=mode,scope=scope,**score(part)))
    table('velocity-residuals.csv',rows);table('velocity-scores.csv',scores)
    ids,train=inputs();rr=read(HOME/'rr-cross.csv')
    individual=[r for r in rr if r['mode']=='primary'];geo=[]
    for idx,star in enumerate(individual):
        assert star['id']==ids[idx]
        ra=train[idx:idx+1,0];values=[]
        for jdx in range(len(ids)):
            sub=np.delete(train,jdx,axis=0)
            if not supported(ra,sub[:,0])[0]:continue
            slope=ridge(sub,ra,'primary')[1];_,dec,dist,pmra,pmdec=train[idx,:5]
            val=velocity(ra,np.array([dec]),slope,np.array([dist]),np.array([0.]),np.array([pmra]),np.array([pmdec]))
            values.append(float(val['cross'][0]))
        geo.append(dict(id=ids[idx],ra=ra[0],cross=star['cross'],pm_sigma=star['sigma_cross_pm'],support_count=len(values),
                        cross_delete_min=min(values),cross_delete_max=max(values)))
    table('rr-normal-geometry-sensitivity.csv',geo)
    condition=[]
    for mode in MODES:
        part=[r for r in rr if r['mode']==mode]
        for side,sub in [('all',part),('leading',[r for r in part if float(r['ra'])<RA0]),('trailing',[r for r in part if float(r['ra'])>=RA0])]:
            cross=num(sub,'cross');along=num(sub,'along');z=num(sub,'z_pm')
            condition.append(dict(mode=mode,scope=side,count=len(sub),cross_mean=np.mean(cross),cross_rms=rms(cross),
               cross_pmerr_rms=rms(num(sub,'sigma_cross_pm')),cross_z_rms=rms(z),n2=int(np.sum(abs(z)>2)),along_rms=rms(along)))
    table('transverse-consistency.csv',condition)
    loo=read(HOME/'leave-one-star-out.csv');choice=np.array([r['measured'] for r in primary])
    deletes=[]
    for ident in ids:
        part=[r for r in loo if r['excluded']==ident]
        assert [int(r['row']) for r in part]==[r['row'] for r in primary]
        included=num(part,'supported').astype(bool);v=num(part,'vlos')
        deletes.append(dict(excluded=ident,all_count=len(v),all_rms=rms(v-choice),bracket_count=int(included.sum()),
                        bracket_rms=rms((v-choice)[included]),bracket_central_rms=rms(num(primary,'residual')[included])))
    table('delete-scores.csv',deletes)
    info={}
    for scope,part in [('all',primary),('leading',[r for r in primary if r['arm']=='leading']),('trailing',[r for r in primary if r['arm']=='trailing']),('K22',[r for r in primary if r['source']=='K22'])]:
        idxs=[r['row'] for r in part];sr=[sensitivity[i] for i in idxs]
        valid=[r for r in part if r['required_dd']!='']
        info[scope]=dict(n=len(part),median_random_input_sigma=float(np.median(num(sr,'random_sigma'))),
            rms_random_input_sigma=rms(num(sr,'random_sigma')),rms_distance_sigma=rms(num(sr,'distance_sigma')),rms_pm_sigma=rms(num(sr,'pm_sigma')),
            common_scale_minus_rms=rms(num(sr,'minus2')),common_scale_plus_rms=rms(num(sr,'plus2')),
            delete_range_median=float(np.median(num(sr,'delete_max')-num(sr,'delete_min'))),
            derivative_available=len(valid),derivative_shortfall_median=float(np.median(num(valid,'dd_shortfall'))) if valid else None,
            derivative_shortfall_rms=rms(num(valid,'dd_shortfall')) if valid else None,
            dd_predicted_median=float(np.median(num(valid,'dd_predicted'))) if valid else None,
            dd_required_median=float(np.median(num(valid,'required_dd'))) if valid else None,
            range_ra=[min(r['ra'] for r in part),max(r['ra'] for r in part)],max_abs_dec_offset=max(abs(r['dec_offset']) for r in part))
    record('comparison.json',dict(forecast_seal=FROZEN,summary=info,source_counts=dict(Counter(r['source'] for r in primary)),
                                unique_positions=len({(r['ra'],r['target_dec']) for r in raw if r['mode']=='primary'}),
                                note='Inferred required slopes are observed diagnostics, not forecasts.'))
    print('Orbit-independent tangent check',condition[0]);print('Primary',scores[0]);print('K22',next(r for r in scores if r['mode']=='primary' and r['scope']=='K22'))
if __name__=='__main__':main()
