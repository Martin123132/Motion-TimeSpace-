import json
from compare import pinned as check,main as score,num,rms
from freeze import HOME,OLD,RA0,np,read,sha,record,table,main as freeze
from wave import CASES
def gradient(ra,values):
    offset=ra-np.mean(ra)
    return (offset@values)/(offset@offset)
def main():
    freeze();check();score()
    control=read(HOME/'rr-cross.csv');spec=read(HOME/'velocity-residuals.csv')
    rows=[r for r in spec if r['mode']=='primary']
    assert len({r['row'] for r in rows})==49 and len({r['id'] for r in control})==17
    stats=[];checks=[];previous={};ids=[r['row'] for r in rows]
    for factor,step in ((2,1),(4,1),(4,2)):
        packet=read(HOME/f'wave-{factor}-{step}.csv');assert len(packet)==49*8
        bounds=read(HOME/f'wave-control-{factor}-{step}.csv')
        assert {r['arm'] for r in bounds}=={'reset','coupled'}
        for r in bounds:
            assert float(r['roundtrip'])<1e-9 and 2<float(r['early_min'])<=float(r['early_max'])<35 and 12<float(r['late_min'])<=float(r['late_max'])<29
        current={}
        for arm in ('reset','coupled'):
            for case in CASES:
                subset=[r for r in packet if r['arm']==arm and r['case']==case];assert [r['row'] for r in subset]==ids
                ra=num(subset,'ra');v=num(subset,'dvel');f=num(subset,'fixed_historical');dist=num(subset,'pc')
                grad=gradient(ra,v);fix=gradient(ra,f);keys={key:num(subset,key) for key in ('dvel','fixed_historical','dra','ddec','pc')}
                keys.update(gradient=np.array([grad]),fixed_gradient=np.array([fix]))
                for key,vec in keys.items():
                    name=(arm,case,key)
                    if name in previous:
                        change=float(np.linalg.norm(vec-previous[name])/np.linalg.norm(vec))
                        checks.append(dict(factor=factor,step=step,arm=arm,case=case,quantity=key,relative=change,passes=bool(change<.005)))
                    current[name]=vec
                stats.append(dict(factor=factor,step=step,arm=arm,case=case,raw_gradient=grad,fixed_gradient=fix,
                  mean_signed_kms=np.mean(v),rms_kms=rms(v),max_kms=max(abs(v)),max_space_pc=max(dist)))
        previous=current
    table('wave-refinements.csv',checks);table('wave-scores.csv',stats)
    drift=json.loads((HOME/'drift-validation.json').read_bytes());assert drift['checks']==20
    failures=[r for r in checks if not r['passes']]
    assert len(checks)==112
    record('validation.json',dict(frozen_before_rv=True,forecast_targets=len(ids),primary_training=17,precision_threshold=.005,
       orbit_checks=len(checks),orbit_fails=failures,drift_checks=drift['checks'],drift_fails=drift['failures'],forecast_seal=sha(HOME/'forecast-seal.json')))
    print('Validation: wave and drift failures',len(failures),len(drift['failures']))
    if (HOME/'RESULTS.md').exists():
        files={p.name:sha(p) for p in sorted(HOME.iterdir()) if p.is_file() and p.name!='seal.json'}
        record('seal.json',files);print('Sealed',len(files),sha(HOME/'seal.json'))
if __name__=='__main__':main()
