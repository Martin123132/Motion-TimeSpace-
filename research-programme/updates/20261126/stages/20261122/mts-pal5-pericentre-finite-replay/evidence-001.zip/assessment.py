from record_io import *
from itertools import product
def main():
    checks=[]
    keys=list(product(('reset','coupled'),('forward','reverse')))
    def gate(name,key,time,one,two):
        hi=np.atleast_1d(two).astype(float);lo=np.atleast_1d(one).astype(float)
        err=float(np.linalg.norm(hi-lo)/np.linalg.norm(hi)) if np.any(hi) else float(np.linalg.norm(lo))
        assert np.isfinite(err)
        checks.append(dict(test=name,case=key,time_Myr=time,fraction=err,passed=err<=.005))
    def volume(label,tag,arm,sign):
        return read(HERE/f'fv-{label}-{tag}-{arm}_{sign}.csv')
    for arm,sign in keys:
        for window,tags in [(64,('1-3-4','2-4-4','2-4-8','3-4-4')),(1024,('1-3-8','2-4-8','2-4-16','3-4-8')),(62500,('1-3-8','2-4-8','2-4-16',None))]:
            labels=list(zip(('first spatial','time step'),[(tags[0],tags[1]),(tags[1],tags[2])]))
            if tags[3]:labels.append(('second spatial',(tags[1],tags[3])))
            if window==1024:labels.append(('second time step',('2-4-16','2-4-32')))
            for kind,(low,high) in labels:
                for meas in ('response','orbits'):
                    lo,hi=(volume(meas,t+'-'+str(window),arm,sign) for t in (low,high))
                    for a,b in zip(lo,hi,strict=True):
                        assert (a['time'],a['tail'])==(b['time'],b['tail'])
                        fields={'response':{'density':['finite_curvature']},'orbits':{'energy':['delta_energy'],'velocity':['vel_'+c for c in 'xyz']}}[meas]
                        for label,cols in fields.items():
                            gate('FV '+label+' '+kind,arm+' '+sign+' '+a['tail'],float(a['time']),[a[c] for c in cols],[b[c] for c in cols])
        exact=read(previous('energy-12-4.csv'))
        for r in volume('orbits','2-4-8-64',arm,sign):
            time=float(r['time']);tail=r['tail']
            def e(src):return float(next(x['work_curvature_kms2_Myr2'] for x in exact if (x['prep'],x['flow'],x['tail'],x['source'],x['control'])==(arm,sign,tail,src,'signed')))
            gate('star versus launch energy curvature',arm+' '+sign+' '+tail,time,2*float(r['delta_energy'])/time**2,e('direct')-e('native'))
        for row in volume('response','3-4-4-64',arm,sign):
            case=arm+' '+sign+' '+row['tail'];t=float(row['time'])
            gate('finite density versus launch law',case,t,row['finite_curvature'],row['target'])
            if t==16e-6:gate('FV discrete launch versus continuum',case,0,row['initial_grid_curvature'],row['target'])
        for row in volume('response','2-4-32-1024',arm,sign):
            gate('finite density versus launch law',arm+' '+sign+' '+row['tail'],float(row['time']),row['finite_curvature'],row['target'])
    for row in read(HERE/'launch-9-10-3-16-4.csv'):
        gate('modal launch versus continuum',row['prep']+' '+row['flow']+' '+row['tail'],0,row['curvature'],row['expected'])
    for row in read(HERE/'kick-9-10-3.csv'):
        if row['spacing_kpc']=='0.0003' and row['kick_Myr']=='0.0625':
            gate('phase kick '+row['drive'],row['prep']+' '+row['flow']+' '+row['tail'],float(row['kick_Myr']),row['continuity'],row['target'])
    for label,low,high in [('modal integrator','9-10-3-8-4','9-10-3-16-4'),('modal preparation','9-10-3-8-2','9-10-3-8-4'),('modal source','6-6-2-8-4','9-10-3-8-4')]:
        for a,b in zip(read(HERE/f'stars-{low}.csv'),read(HERE/f'stars-{high}.csv'),strict=True):
            assert (a['prep'],a['flow'],a['tail'],a['control'],a['time'])==(b['prep'],b['flow'],b['tail'],b['control'],b['time'])
            gate(label+' '+a['control']+' stellar energy',a['prep']+' '+a['flow']+' '+a['tail'],float(a['time']),a['delta_energy'],b['delta_energy'])
    for label,low,high in [('spatial','1-3-16-1024-4','2-4-16-1024-4'),('wave steps','2-4-16-1024-4','2-4-32-1024-4'),('stellar steps','2-4-32-1024-2','2-4-32-1024-4')]:
        for a,b in zip(read(HERE/f'stellar-feedback-{low}.csv'),read(HERE/f'stellar-feedback-{high}.csv'),strict=True):
            assert (a['prep'],a['flow'],a['tail'],a['time'])==(b['prep'],b['flow'],b['tail'],b['time'])
            gate('wave-only velocity '+label,a['prep']+' '+a['flow']+' '+a['tail'],float(a['time']),[a['dv_'+c] for c in 'xyz'],[b['dv_'+c] for c in 'xyz'])
    table('checks.csv',checks)
    grouped=[]
    for name,time in sorted({(r['test'],r['time_Myr']) for r in checks}):
        chosen=[r for r in checks if r['test']==name and r['time_Myr']==time]
        grouped.append(dict(test=name,years=time*1e6,passing=sum(r['passed'] for r in chosen),total=len(chosen),max_percent=100*max(r['fraction'] for r in chosen)))
    table('summary.csv',grouped)
    audits=[r for p in sorted(HERE.glob('fv-transport-*.csv')) for r in read(p)]
    print('audited',len(audits),'occupation',max(float(r['occupation_rel']) for r in audits),'conservation',max(abs(float(r['differential_mass_ratio'])) for r in audits),'transport',max(float(r['transport_vs_amplitude']) for r in audits))
    assert all(max(abs(float(r[k])) for k in ('occupation_rel','differential_mass_ratio','transport_vs_amplitude'))<1e-6 for r in audits)
    print('numerical and hypothesis comparisons',len(checks))
    if '--seal' in sys.argv:
        for name in ('RESULTS.md','METHOD.md','summary.csv','PROTOCOL.md'):assert (HERE/name).exists()
        manifest={f.name:digest(f) for f in sorted(HERE.iterdir()) if f.is_file() and f.name!='seal.json'}
        save('seal.json',(json.dumps(manifest,sort_keys=True,indent=2)+'\n').encode())
        assert all(digest(HERE/name)==value for name,value in json.loads((HERE/'seal.json').read_bytes()).items())
        print('sealed',len(manifest),digest(HERE/'seal.json'))
if __name__=='__main__':main()
