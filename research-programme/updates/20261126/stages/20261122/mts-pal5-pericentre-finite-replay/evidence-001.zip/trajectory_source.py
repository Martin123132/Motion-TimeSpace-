from models import *
from unittest.mock import patch
def run(q):
    previous('source_at_sites.py');from source_at_sites import group
    src=old.sources()
    with patch('source_at_sites.table',table):params=group(src)
    data=read(previous('sites.csv'));compiled=[]
    cut=np.linspace(0,.001024,3)
    for first in range(0,len(data),3):
        part=data[first:first+3];star=Stars(part,first//3,10,3)
        probes=np.stack([cylindrical(star.start+t*star.v)[0] for t in cut])
        points=(probes*[1.,-1.]).reshape(-1,2)
        values=src.integrate(points,points,q,params,acceleration=True).reshape(2,3,3,2)
        values[...,1]*=-1
        frac=((star.date+cut)/star.duration)[:,None,None]
        compiled.append(values[0]*(1-frac)+values[1]*frac)
    packet(f'trajectory-source-{q}.npz',time=cut,forces=np.array(compiled))
if __name__=='__main__':
    for arg in sys.argv[1:]:run(int(arg))
