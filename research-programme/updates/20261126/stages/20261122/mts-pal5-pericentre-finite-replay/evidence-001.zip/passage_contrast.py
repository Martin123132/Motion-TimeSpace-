from models import *
from stellar_feedback import sample
from scipy.interpolate import RectBivariateSpline
def run(tag,sub,q=None):
    rows=read(previous('sites.csv'));result=[];values={}
    for first in range(0,len(rows),3):
        part=rows[first:first+3];arm,flow=part[0]['prep'],part[0]['flow'];stars=Stars(part,first//3,10,3)
        if q is not None:
            with np.load(HERE/f'trajectory-source-{q}.npz') as bank:guides=bank['forces'][first//3];end=bank['time'][-1]
            jac=[]
            for row in read(previous('neighbours-q10.csv')):
                if (row['prep'],row['flow'],float(row['step_kpc']))==(arm,flow,.001):
                    jac.append([[float(row['dR_aR']),float(row['dz_aR'])],[float(row['dR_az']),float(row['dz_az'])]])
            assert len(jac)==3
        def host(positions,time,source):
            if q is None or source=='native':return stars.ordinary(positions,time,source)
            f=2*time/end-1
            assert abs(f)<1+1e-10
            anchors=np.einsum('t,tiv->iv',[f*(f-1)/2,1-f*f,f*(f+1)/2],guides)
            point,unit=cylindrical(positions)
            offset=point-cylindrical(stars.start+time*stars.v)[0]
            assert np.max(abs(offset))<1e-8
            value=anchors+np.einsum('imn,in->im',jac,offset)
            return value[:,:1]*unit+value[:,1:]*[0,0,1]
        with np.load(HERE/f'tide-{tag}-{arm}_{flow}.npz') as bank:
            ts=bank['time'];step=ts[1];base=[RectBivariateSpline(bank['r'],bank['mu'],p) for p in bank['common']]
            resp=[RectBivariateSpline(bank['r'],bank['mu'],p) for p in bank['response']]
        dt=step/sub
        for mode in ('ordinary','static_monopole','live'):
            for source in ('native','direct'):
                p=stars.start.copy();v=stars.v.copy()
                def grav(t):
                    ext=host(p,t,source)
                    if mode=='live':
                        centre=min(max(1,int(round(t/step))),len(ts)-2);f=t/step-centre
                        for w,j in zip((f*(f-1)/2,1-f*f,f*(f+1)/2),range(centre-1,centre+2)):
                            if w:
                                ext+=w*sample(base[j],p)
                                if source=='direct':ext+=w*sample(resp[j],p)
                    elif mode=='static_monopole':ext+=stars.fixed(p)
                    off=p-p[0]
                    return CONV**2*(ext-GM*off/(np.sum(off**2,axis=1)+SCALE**2)[:,None]**1.5),ext-ext[0]
                a,tide=grav(0.);power=np.sum((v-v[0])*tide,axis=1);work=0*power
                for i in range(1,(len(ts)-1)*sub+1):
                    t=i*dt;v+=a*dt/2;p+=dt*v;a,tide=grav(t);v+=a*dt/2
                    rate=np.sum((v-v[0])*tide,axis=1);work+=dt/2*(rate+power);power=rate
                    if i not in [(len(ts)-1)*sub//4,(len(ts)-1)*sub//2,(len(ts)-1)*sub]:continue
                    for j in (1,2):values[arm,flow,part[j]['tail'],t,mode,source]=work[j]
    for arm in ('reset','coupled'):
        for tail in ('inner','outer'):
            for t in sorted({key[3] for key in values}):
                for mode in ('ordinary','static_monopole','live'):
                    def contrast(source,case):return values[arm,'forward',tail,t,case,source]-values[arm,'reverse',tail,t,case,source]
                    n=contrast('native',mode);d=contrast('direct',mode);bo=contrast('direct','ordinary')
                    result.append(dict(prep=arm,tail=tail,time=t,control=mode,direct_contrast=d,native_contrast=n,source_change=d-n,relative_change=d/n-1,direct_minus_baryon_control=d-bo))
    suffix='' if q is None else '-direct'+str(q)
    table(f'passage-contrast-{tag}-{sub}{suffix}.csv',result)
if __name__=='__main__':run(sys.argv[1],int(sys.argv[2]),*(int(arg) for arg in sys.argv[3:]))
