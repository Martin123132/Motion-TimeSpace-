from models import *
from scipy.interpolate import RectBivariateSpline
def sample(fn,p):
    r=np.linalg.norm(p,axis=1);er=p/r[:,None];mu=er[:,2];ab=abs(mu)
    assert np.all((r>=fn.get_knots()[0][0])&(r<=fn.get_knots()[0][-1])&(ab>=fn.get_knots()[1][0])&(ab<=fn.get_knots()[1][-1]))
    dp=fn.ev(r,ab,dx=1);dm=fn.ev(r,ab,dy=1)*np.sign(mu)/r
    return -(dp-dm*mu)[:,None]*er-np.c_[0*mu,0*mu,dm]
def orbit(tag,sub):
    data=read(previous('sites.csv'));records=[]
    for first in range(0,len(data),3):
        part=data[first:first+3];arm,sign=part[0]['prep'],part[0]['flow'];key=arm+'_'+sign
        star=Stars(part,first//3,10,3);p=star.start.copy();v=star.v.copy();dx=np.zeros_like(p);dv=np.zeros_like(v)
        with np.load(HERE/f'tide-{tag}-{key}.npz') as bank:
            ts=bank['time'];step=ts[1]-ts[0]
            spl=lambda field:[RectBivariateSpline(bank['r'],bank['mu'],value) for value in bank[field]]
            base=spl('common');response=spl('response')
        def accel(t):
            centre=min(max(1,int(round(t/step))),len(ts)-2)
            ix=np.arange(centre-1,centre+2);f=t/step-centre
            weights=[f*(f-1)/2,1-f*f,f*(f+1)/2]
            def field(array,pts):return sum(w*sample(array[i],pts) for w,i in zip(weights,ix) if w!=0)
            def external(pts):return star.ordinary(pts,t,'direct')+field(base,pts)
            gap=p-p[0];sep=dx-dx[0];den=SCALE**2+np.sum(gap*gap,axis=1)
            cluster=-GM*gap/den[:,None]**1.5
            jac=-GM*(sep-3*gap*np.sum(gap*sep,axis=1)[:,None]/den[:,None])/den[:,None]**1.5
            scale=np.linalg.norm(dx,axis=1)[:,None];unit=dx/np.where(scale,scale,1.)
            eps=2e-5
            grad=(external(p+eps*unit)-external(p-eps*unit))/(2*eps)*scale
            return CONV**2*(external(p)+cluster),CONV**2*(grad+jac+field(response,p+dx))
        acc,ind=accel(0)
        assert not np.any(ind)
        dt=step/sub;count=(len(ts)-1)*sub
        for tick in range(1,count+1):
            t=dt*tick;v+=dt*acc/2;dv+=dt*ind/2;p+=dt*v;dx+=dt*dv
            acc,ind=accel(t);v+=dt*acc/2;dv+=dt*ind/2
            if tick not in (count//4,count//2,count):continue
            dis=dx-dx[0];vel=(dv-dv[0])/CONV
            assert np.max(abs(dx))<1e-12
            s=p-p[0];left=np.sqrt(SCALE**2+np.sum(s*s,axis=1));right=np.sqrt(SCALE**2+np.sum((s+dis)**2,axis=1))
            energy=np.sum((v-v[0])/CONV*vel+.5*vel**2,axis=1)+GM*np.sum((2*s+dis)*dis,axis=1)/(left*right*(left+right))
            for j in (1,2):
                records.append(dict(prep=arm,flow=sign,tail=part[j]['tail'],time=t,wave_only_energy=energy[j],wave_only_velocity_kms=np.linalg.norm(vel[j]),**{'dv_'+ax:val for ax,val in zip('xyz',vel[j])},max_position_linearization_kpc=np.max(abs(dx))))
    table(f'stellar-feedback-{tag}-{sub}.csv',records)
if __name__=='__main__':orbit(sys.argv[1],int(sys.argv[2]))
