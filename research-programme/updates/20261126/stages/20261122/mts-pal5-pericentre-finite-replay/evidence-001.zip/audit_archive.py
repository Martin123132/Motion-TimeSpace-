from record_io import *
def run():
    for name,h in manifest.items():assert digest(OLD/name)==h,name
    checkpoints=sorted(HERE.glob('complete-restart-check-*.csv'));assert len(checkpoints)==4
    for file in checkpoints:
        records=read(file);assert len(records)==11 and all(r['identical']=='True' for r in records)
    summary=read(HERE/'summary.csv')
    assert all(int(r['passing'])==int(r['total']) for r in summary if r['test'].startswith('FV density') and float(r['years'])<=1024)
    entry=lambda label,years:next(r for r in summary if r['test']==label and float(r['years'])==years)
    assert entry('modal launch versus continuum',0)['passing']=='0'
    assert entry('FV discrete launch versus continuum',0)['passing']=='12'
    assert entry('FV density time step',62500)['passing']=='0'
    fact=read(HERE/'factorial-finite-checks.csv'); target=[r for r in fact if r['years']=='1024' and r['observable']=='total' and r['source'] in ('direct','native')]
    assert len(target)==32 and all(r['passed']=='True' for r in target)
    fact=read(HERE/'factorial-finite.csv')
    for tail in ('inner','outer'):
        chosen={r['source']:r for r in fact if r['tag']=='2-4-32-1024-direct12' and r['years']=='1024' and r['prep']=='coupled' and r['tail']==tail and r['control']=='live'}
        assert float(chosen['direct']['total'])<0<float(chosen['native']['total'])
        assert float(chosen['native']['flow_at_fixed_site'])<0 and float(chosen['direct']['flow_at_fixed_site'])<0
    impulse=read(HERE/'wave-impulse.csv')
    assert sum(float(row['relative_to_cubic'])<.005 for row in impulse)==47
    print('predecessor seal and 50 inherited files unchanged; all four full-state restarts identical; checked positive and negative outcomes')
if __name__=='__main__':run()
