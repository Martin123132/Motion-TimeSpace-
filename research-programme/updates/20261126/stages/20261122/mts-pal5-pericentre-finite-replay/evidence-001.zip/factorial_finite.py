from record_io import *
def main():
    rows=[];configs=[('1-3-16-1024','4',''),('2-4-16-1024','4',''),('2-4-32-1024','4',''),('2-4-32-1024','4','-direct8'),('2-4-32-1024','4','-direct12')]
    for tag,sub,extension in configs:
        a,b=(read(HERE/f'passage-contrast-{tag}{cross}-{sub}{extension}.csv') for cross in ('','-cross'))
        for own,flip in zip(a,b,strict=True):
            cols=('prep','tail','control','time');assert all(own[k]==flip[k] for k in cols)
            prepared={}
            for source in ('native','direct'):
                v=float(own[source+'_contrast']);w=float(flip[source+'_contrast'])
                same=(v-w)/2;site=(v+w)/2
                assert abs(v-(same+site))<=1e-15*max(abs(same),abs(site))
                if own['control']!='live':assert same==0
                prepared[source]=(same,site)
            for n,s in enumerate(('native','direct','difference')):
                same,site=prepared[s] if n<2 else np.subtract(prepared['direct'],prepared['native'])
                rows.append(dict(tag=tag+extension,prep=own['prep'],tail=own['tail'],control=own['control'],years=round(1e6*float(own['time'])),source=s,flow_at_fixed_site=same,site_at_fixed_flow=site,total=same+site))
    table('factorial-finite.csv',rows);checks=[]
    for ca,cb in [(0,1),(1,2),(2,4),(3,4)]:
        a,b=(configs[c][0]+configs[c][-1] for c in (ca,cb))
        small=[r for r in rows if r['tag']==a and r['control']=='live'];hi=[r for r in rows if r['tag']==b and r['control']=='live']
        for lo,up in zip(small,hi,strict=True):
            for k in ('flow_at_fixed_site','site_at_fixed_flow','total'):
                relative=abs(lo[k]/up[k]-1)
                checks.append(dict(first=a,second=b,prep=up['prep'],tail=up['tail'],years=up['years'],source=up['source'],observable=k,fraction=relative,passed=relative<=.005))
    table('factorial-finite-checks.csv',checks)
    print('factorial comparisons',len(checks),'outside tolerance',sum(not r['passed'] for r in checks))
if __name__=='__main__':main()
