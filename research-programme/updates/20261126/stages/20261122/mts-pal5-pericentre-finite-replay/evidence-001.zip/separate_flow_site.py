from record_io import *
def run():
    results=[]
    for q in (4,8,12):
        data=read(previous(f'energy-{q}-4.csv'))
        values={(r['prep'],r['flow'],r['tail'],r['source'],r['control']):float(r['work_curvature_kms2_Myr2']) for r in data}
        for arm in ('reset','coupled'):
            for tail in ('inner','outer'):
                for src in ('native','direct'):
                    for model in ('live','ordinary','static_monopole'):
                        def value(sign,site):
                            control=model if model!='live' else ('signed' if site==sign else 'opposite_same_point')
                            return values[arm,site,tail,src,control]
                        aa,ab,ba,bb=[value(s,c) for s,c in [('forward','forward'),('forward','reverse'),('reverse','forward'),('reverse','reverse')]]
                        same=.5*((aa-ba)+(ab-bb))
                        site=.5*((aa-ab)+(ba-bb))
                        assert np.isclose(same+site,aa-bb,rtol=1e-10,atol=1e-18)
                        interaction=aa-ba-ab+bb
                        results.append(dict(order=q,prep=arm,tail=tail,source=src,control=model,total=aa-bb,same_site_flow=same,same_flow_site=site,interaction=interaction,forward_at_forward=aa,forward_at_reverse=ab,reverse_at_forward=ba,reverse_at_reverse=bb))
    table('factorial-launch.csv',results)
    out=[]
    for arm in ('reset','coupled'):
        for tail in ('inner','outer'):
            for q in (4,8,12):
                def record(src):return next(r for r in results if (r['order'],r['prep'],r['tail'],r['source'],r['control'])==(q,arm,tail,src,'live'))
                direct,native=record('direct'),record('native')
                out.append(dict(order=q,prep=arm,tail=tail,**{field:direct[field]-native[field] for field in ('total','same_site_flow','same_flow_site','interaction')}))
    table('factorial-source-effect.csv',out)
if __name__=='__main__':run()
