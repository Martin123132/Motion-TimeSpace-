from pathlib import Path
import csv, hashlib, io, json, os, sys
for name in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','BLIS_NUM_THREADS'): os.environ[name]='1'
import numpy as np
HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
OLD=ROOT/'mts-pal5-pericentre-source-gravity-20261122'
assert hashlib.sha256((OLD/'seal.json').read_bytes()).hexdigest()=='e8e21138552d59c3279075eb8e8936e1594ac9667e778749d6c17c31cf0eb792'
manifest=json.loads((OLD/'seal.json').read_bytes())
def digest(file):
    with file.open('rb') as handle:return hashlib.file_digest(handle,'sha256').hexdigest()
def previous(name):
    path=OLD/name;assert digest(path)==manifest[name];return path
previous('local_stage.py');sys.path.insert(0,str(OLD))
import local_stage as old
def guard():
    old.guard();assert not (HERE/'STOP-REQUESTED').exists()
def save(name,data):
    guard();p=HERE/name
    if p.exists():assert digest(p)==hashlib.sha256(data).hexdigest(),name
    else:
        with p.open('xb') as fp:fp.write(data)
def table(name,rows):
    buf=io.StringIO();writer=csv.DictWriter(buf,rows[0],lineterminator='\n')
    writer.writeheader();writer.writerows(rows);save(name,buf.getvalue().encode())
def packet(name,**data):
    buf=io.BytesIO();np.savez_compressed(buf,**data);save(name,buf.getvalue())
def read(path):
    with path.open() as fp:return list(csv.DictReader(fp))
guard()
