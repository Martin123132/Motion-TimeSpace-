from record_io import *
from unittest.mock import patch
def run(q,degree):
    previous('source_at_sites.py');from source_at_sites import group
    src=old.sources()
    with patch('source_at_sites.table',table):contract=group(src)
    rows=read(previous('sites.csv'))
    nodes=np.sort(.010+.014*np.cos(np.arange(degree+1)*np.pi/degree))
    off=np.stack(np.meshgrid(nodes,nodes,indexing='ij'),axis=-1)
    chart=[]
    for first in range(0,len(rows),3):
        guard()
        centres=np.array([[np.hypot(float(row['pos_x']),float(row['pos_y'])),float(row['pos_z'])] for row in rows[first:first+3]])
        p=(centres[:,None,None,:]+off).reshape(-1,2)
        assert np.max(p[:,1])<0
        p[:,1]*=-1
        breaks=np.unique(np.vstack([p,centres*[1,-1]]),axis=0)
        values=src.integrate(p,breaks,q,contract,acceleration=True)
        values[:,:,1]*=-1
        chart.append(values.reshape(2,3,len(nodes),len(nodes),2))
    packet(f'chart-{q}-{degree}.npz',force=np.array(chart),nodes=nodes)
if __name__=='__main__':
    for tag in sys.argv[1:]:run(*map(int,tag.split('-')))
