from models import *
from numpy.polynomial.legendre import leggauss
def run(q,chartq,degree):
    previous('wave_sites.py');from wave_sites import setup
    lab,_,_,hold,shape=setup();wave=Wave(lab,shape,q);bg=lab.obj.bg
    kappa=bg.vel*bg.length*CONV
    sample,weight=leggauss(4)
    data=read(previous('sites.csv'));reference=read(previous('wave-response-12-4.csv'));out=[]
    with np.load(HERE/'launch-4.npz') as states:
        for first in range(0,len(data),3):
            guard();hold();part=data[first:first+3];arm,sign=part[0]['prep'],part[0]['flow']
            state=states[arm+'_'+sign];stars=Stars(part,first//3,chartq,degree);p0=stars.start
            fraction=stars.date/stars.duration
            delta=wave.drive('direct',fraction)-wave.drive('native',fraction)
            coeff=wave.mesh.potential_nodes(delta)
            knots=np.unique(np.r_[np.arange(5.18,5.401,.00025),wave.el.right*bg.length])
            knots=knots[(knots>=5.18)&(knots<=5.41)]
            val,slope=wave.mesh.values(coeff,knots/bg.length);norm=np.sqrt(2*wave.mesh.sell+1)*bg.vel**2
            fn=CubicHermiteSpline(knots,val*norm,slope*norm/bg.length,axis=0,extrapolate=False)
            def modal(p):
                r=np.linalg.norm(p,axis=1)
                return force(p,fn(r),fn(r,1))
            def actual(p):return stars.ordinary(p,0.,'direct')-stars.ordinary(p,0.,'native')
            rho0=abs(wave.amplitude(p0,state))**2
            expect=np.array([float(row['density_curve_fraction_Myr_m2']) for row in reference[first:first+3]])
            for mode,acc in [('source',actual),('represented',modal)]:
                centre=acc(p0)[0]
                def potential(p,d):
                    return -sum(w/2*np.sum((acc(p+(s+1)*d/2)-centre)*d,axis=1) for s,w in zip(sample,weight))
                for width in (.0006,.0003):
                    dirs=width*np.eye(3)
                    for h in (.015625,.0625):
                        def current(p,axis):
                            amp=wave.amplitude(p,state);dr=dirs[axis]
                            aa,bb=(wave.amplitude(p+u*dr,state) for u in (1.,-1.))
                            angles=[-1j*h*CONV**2*potential(p,step*dr)/kappa for step in (1.,-1.)]
                            shift=aa*np.expm1(angles[0])-bb*np.expm1(angles[1])
                            return kappa*(amp.conj()*shift).imag/(2*width*h)
                        curvature=-sum((current(p0+dr,idx)-current(p0-dr,idx))/(2*width) for idx,dr in enumerate(dirs))/rho0
                        for j,row in enumerate(part):
                            out.append(dict(prep=arm,flow=sign,tail=row['tail'],drive=mode,spacing_kpc=width,kick_Myr=h,continuity=curvature[j],target=expect[j],relative_error=abs(curvature[j]/expect[j]-1)))
    table(f'kick-{q}-{chartq}-{degree}.csv',out)
if __name__=='__main__':run(*map(int,sys.argv[1:]))
