from record_io import *
from unittest.mock import patch
def run(orders):
    previous('source_at_sites.py');from source_at_sites import group
    src=old.sources()
    with patch('source_at_sites.table',table):gains=group(src)
    for name in ('spherical_source.py','global_newton.py','run_io.py','mesh.npz','ordinary-q5.npz'):old.pin(old.WAVE,name)
    sys.path.insert(0,str(old.WAVE));import spherical_source as sphere
    for q in orders:
        ref=old.pin(old.WAVE,f'spherical-{q}-1.npz')
        def keep(name,**values):
            with np.load(ref) as original:
                for key in ('target','degrees'):assert np.array_equal(values[key],original[key])
                for key in ('phi','dr','mass'):
                    assert np.allclose(values[key][...,1],original[key][...,0],rtol=2e-9,atol=1e-8),key
            packet(f'global-{q}.npz',**values)
        with patch.object(src,'info',lambda:gains),patch.object(sphere,'guard',guard),patch.object(sphere,'packet',keep):
            sphere.main(q,1)
if __name__=='__main__':run(list(map(int,sys.argv[1:])))
