from models import *
from volume_mass import FV,fvpin
from scipy.interpolate import RectBivariateSpline
def run(level,order,steps,total,only):
    for name in ('finite_wave.py','mesh_fd.py','finite_io.py'):fvpin(name)
    sys.path.insert(0,str(FV));from finite_wave import Space,Kinetic,kick
    from mesh_fd import sample
    rows=read(previous('sites.csv'));ref=read(previous('wave-response-12-4.csv'))
    bank=np.load(HERE/f'volume-{level}-{order}.npz');S=Space(bank['rf'],bank['mf']);kappa=float(bank['kappa'])
    rr=np.where((S.r>5.15)&(S.r<5.45))[0];mm=np.where((S.mu>.47)&(S.mu<.55))[0]
    idx=np.ix_(rr,mm);times=total*1e-6;dt=times/steps
    crossed=os.environ.get('MTS_CROSSED')=='1'
    orderlabel=f'{level}-{order}-{steps}-{total:g}'+('-cross' if crossed else '');kin=Kinetic(S,kappa,dt)
    dr=S.dr[:,None];dm=S.dm;volume=dr*dm;rad=S.r[:,None]
    def spline(grid):return RectBivariateSpline(S.r[rr],S.mu[mm],grid[idx],kx=3,ky=3,s=0)
    def evaluate(fn,points,dx=0,dy=0):
        r=np.linalg.norm(points,axis=1);mu=abs(points[:,2])/r
        assert min(r)>min(S.r[rr]) and max(r)<max(S.r[rr]) and min(mu)>min(S.mu[mm]) and max(mu)<max(S.mu[mm])
        return fn.ev(r,mu,dx=dx,dy=dy)
    def chain(fn,points,vec):return np.sum(-sample(fn,points)*vec,axis=1)
    for ix in range(0,len(rows),3):
        chunk=rows[ix:ix+3];arm,sign=chunk[0]['prep'],chunk[0]['flow'];key=arm+'_'+sign
        if only not in ('all',key):continue
        star=Stars(chunk,ix//3,10,3);p0=star.start;v0=star.v
        f0=star.date/star.duration
        target=np.array([float(row['density_curve_fraction_Myr_m2']) for row in ref[ix:ix+3]])
        ref_density=np.array([float(row['wave_density']) for row in ref[ix:ix+3]])
        if crossed:
            with np.load(HERE/f'cross-launch-{level}-{order}.npz') as source:
                p,ref_density,target=(source[n] for n in (key,key+'_rho',key+'_expected'))
        else:p=bank[key]
        delta=np.zeros_like(p);net=np.zeros(p.shape)
        dur=star.duration;dold=(bank['old1']-bank['old0'])/dur;ddrive=(bank['delta1']-bank['delta0'])/dur
        orig=bank['old0']+dold*star.date;drive=bank['delta0']+ddrive*star.date
        mass0=np.sum(volume*abs(p)**2);common=S.poisson(4*np.pi*G*dr*abs(p)**2);dw=0*common
        rho0fn=spline(abs(p/rad)**2);rho0=evaluate(rho0fn,p0)
        assert min(rho0)>0 and np.max(abs(rho0/ref_density-1))<.005
        diff=star.ordinary(p0,0,'direct')-star.ordinary(p0,0,'native')
        actual=sample(spline(drive),p0)
        srcerr=np.linalg.norm((actual-actual[0])-(diff-diff[0]),axis=1)/np.maximum(np.linalg.norm(diff-diff[0],axis=1),1e-30)
        fr=CONV**2*np.real(p[:-1].conj()*p[1:])*(drive[:-1]-drive[1:])/np.diff(S.r)[:,None]
        fa=CONV**2*np.real(p[:,:-1].conj()*p[:,1:])*(drive[:,:-1]-drive[:,1:])*(1-S.mf[1:-1]**2)/(np.diff(S.mu)*rad**2)
        ntt=np.zeros_like(net);ntt[:-1]-=fr/dr[:-1];ntt[1:]+=fr/dr[1:]
        ntt[:,:-1]-=fa/dm[:-1];ntt[:,1:]+=fa/dm[1:]
        discrete=(evaluate(spline(ntt/rad**2),p0)+chain(rho0fn,p0,CONV**2*diff[0]))/rho0
        def gravity(ordinary,delta_s,pb,dp,t):
            native=star.ordinary(pb,t,'native')+sample(ordinary,pb)
            pd=pb+dp
            direct=star.ordinary(pd,t,'direct')+sample(ordinary,pd)+sample(delta_s,pd)
            def cluster(points):
                offset=points-points[0];return -GM*offset/(SCALE**2+np.sum(offset**2,axis=1))[:,None]**1.5
            ac=cluster(pb);return CONV**2*(native+ac),CONV**2*(direct-native+cluster(pd)-ac)
        pb,vb=p0.copy(),v0.copy();dp=np.zeros_like(pb);dv=np.zeros_like(vb)
        ab,ad=gravity(spline(common),spline(dw),pb,dp,0)
        audits=[];out=[];orbits=[];phase=-.5j*dt*CONV**2/kappa
        retain=os.environ.get('MTS_SAVE_TIDES')=='1'
        if retain:fields=[common[idx].copy()];responses=[dw[idx].copy()]
        emit=os.environ.get('MTS_CHECKPOINT')=='1'
        verify=os.environ.get('MTS_VERIFY_RESUME')=='1'
        names=('p','delta','net','pb','vb','dp','dv','ab','ad')
        def receipt(at):return f'restart-{orderlabel}-{key}-{at}.npz'
        def payload():return dict(zip(names,(p,delta,net,pb,vb,dp,dv,ab,ad)))
        offset_step=0
        if verify:
            offset_step=steps//2
            with np.load(HERE/receipt(offset_step)) as saved:
                assert float(saved['clock'])==offset_step*dt and float(saved['date'])==star.date
                p,delta,net,pb,vb,dp,dv,ab,ad=[saved[k] for k in names]
            common=S.poisson(4*np.pi*G*dr*abs(p)**2);dw=S.poisson(4*np.pi*G*dr*net)
            with np.load(HERE/('field-'+receipt(offset_step))) as forces:
                for field,expected_field in [(common,forces['common']),(dw,forces['dw'])]:
                    assert np.linalg.norm(field-expected_field)<=1e-12*np.linalg.norm(expected_field)
                common,dw=forces['common'],forces['dw']
            one,two=gravity(spline(common),spline(dw),pb,dp,offset_step*dt)
            assert np.array_equal(one,ab) and np.array_equal(two,ad)
        for tick in range(offset_step+1,steps+1):
            guard();lo=(tick-1)*dt;t=tick*dt
            vb+=dt*ab/2;dv+=dt*ad/2;pb+=dt*vb;dp+=dt*dv
            p,delta=kick(p,delta,orig+dold*lo+common,drive+ddrive*lo+dw,phase)
            p,delta=kin.radial(p,delta,net);p,delta=kin.angular(p,delta,net);p,delta=kin.radial(p,delta,net)
            common=S.poisson(4*np.pi*G*dr*abs(p)**2);dw=S.poisson(4*np.pi*G*dr*net)
            if retain:fields.append(common[idx].copy());responses.append(dw[idx].copy())
            p,delta=kick(p,delta,orig+dold*t+common,drive+ddrive*t+dw,phase)
            ab,ad=gravity(spline(common),spline(dw),pb,dp,t);vb+=dt*ab/2;dv+=dt*ad/2
            if emit and tick in (steps//2,steps):
                packet(receipt(tick),clock=t,date=star.date,dt=dt,**payload())
                packet('field-'+receipt(tick),common=common,dw=dw)
            if tick not in (steps//4,steps//2,steps):continue
            normerr=abs(np.sum(volume*abs(p)**2)/mass0-1);assert normerr<1e-9
            check=np.sum(volume*net)/max(np.sum(volume*abs(net)),1e-200)
            obs=2*(p.conj()*delta).real+abs(delta)**2
            resid=np.linalg.norm((obs-net)[idx])/np.linalg.norm(net[idx])
            audits.append(dict(time=t,occupation_rel=normerr,differential_mass_ratio=check,transport_vs_amplitude=resid,initial_grid_mass_Msun=4*np.pi*mass0))
            points=p0+(pb[0]-p0[0]);offset=dp[0]
            differential=evaluate(spline(net/rad**2),points+offset)
            frame=chain(spline(abs(p/rad)**2),points+offset/2,offset)
            actual_curve=2*(differential+frame)/t**2/rho0
            ee=np.sum((vb-vb[0])*(dv-dv[0]),axis=1)/CONV**2+.5*np.sum((dv-dv[0])**2,axis=1)/CONV**2
            s=pb-pb[0];ds=dp-dp[0];base=np.sqrt(SCALE**2+np.sum(s*s,axis=1));end=np.sqrt(SCALE**2+np.sum((s+ds)**2,axis=1))
            ee+=GM*np.sum((2*s+ds)*ds,axis=1)/(base*end*(base+end))
            for j,row in enumerate(chunk):
                out.append(dict(tail=row['tail'],time=t,native_density=rho0[j],target=target[j],initial_grid_curvature=discrete[j],finite_curvature=actual_curve[j],difference_density_term=2*differential[j]/t**2/rho0[j],motion_term=2*frame[j]/t**2/rho0[j],initial_source_tide_error=srcerr[j],wave_acceleration_change=float(np.linalg.norm(sample(spline(dw),points)[j]))))
                if j:orbits.append(dict(tail=row['tail'],time=t,delta_energy=ee[j],**{'vel_'+ax:v for ax,v in zip('xyz',(dv[j]-dv[0])/CONV)},**{'shift_'+ax:v for ax,v in zip('xyz',ds[j])}))
        if verify:
            replay=[]
            with np.load(HERE/receipt(steps)) as expected:
                for name,array in payload().items():
                    equal=np.array_equal(array,expected[name]);assert equal,(key,name)
                    replay.append(dict(state=key,field=name,from_Myr=offset_step*dt,to_Myr=steps*dt,identical=equal))
            with np.load(HERE/('field-'+receipt(steps))) as expected:
                for name,array in [('common',common),('dw',dw)]:
                    equal=np.array_equal(array,expected[name]);assert equal,(key,name)
                    replay.append(dict(state=key,field=name,from_Myr=offset_step*dt,to_Myr=steps*dt,identical=equal))
            table(f'complete-restart-check-{orderlabel}-{key}.csv',replay)
            continue
        for label,rs in [('transport',audits),('response',out),('orbits',orbits)]:table(f'fv-{label}-{orderlabel}-{key}.csv',rs)
        if retain:packet(f'tide-{orderlabel}-{key}.npz',r=S.r[rr],mu=S.mu[mm],time=np.linspace(0,times,steps+1),common=np.array(fields),response=np.array(responses))
        print(key,orderlabel,'launch ratios',discrete/target,'finite',actual_curve/target,flush=True)
    bank.close()
if __name__=='__main__':run(*map(int,sys.argv[1:4]),float(sys.argv[4]),sys.argv[5])
