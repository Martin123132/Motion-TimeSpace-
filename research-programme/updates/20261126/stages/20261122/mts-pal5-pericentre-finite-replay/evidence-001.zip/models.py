from record_io import *
from scipy.interpolate import CubicHermiteSpline, BarycentricInterpolator
from scipy.special import eval_legendre
from numpy.polynomial.legendre import legvander
from types import SimpleNamespace
G=4.30091727003628e-6
CONV=1/977.7922216807892
GM=G*4297;SCALE=22.05*np.tan(np.deg2rad(3.21/60));ESC=np.sqrt(2*GM/np.hypot(.060,SCALE))
def vcols(data,key):
    return np.array([[float(row[key+'_'+axis]) for axis in 'xyz'] for row in data])
def cylindrical(p):
    r=np.linalg.norm(p[:,:2],axis=1);e=p.copy();e[:,2]=0;e/=r[:,None]
    return np.column_stack((r,p[:,2])),e
def force(p,phi,grad):
    r=np.linalg.norm(p,axis=1);unit=p/r[:,None];mu=unit[:,2]
    degree=np.arange(phi.shape[1])*2;leg=legvander(mu,degree[-1])
    angular=degree*(leg[:,np.maximum(0,degree-1)]-mu[:,None]*leg[:,::2])/(1-mu[:,None]**2)
    az=(phi*angular).sum(axis=1)/r
    return -((grad*leg[:,::2]).sum(axis=1)-mu*az)[:,None]*unit-az[:,None]*[0,0,1]
class Stars:
    def __init__(self,chunk,index,q,degree):
        self.start=vcols(chunk,'pos');self.v=vcols(chunk,'vel')*CONV+np.array([0.,-1.,1.])[:,None]*ESC*CONV*vcols(chunk,'az')
        self.centres=cylindrical(self.start)[0];self.date=float(chunk[0]['date']);self.duration=float(chunk[0]['duration'])
        with np.load(HERE/f'chart-{q}-{degree}.npz') as f:
            self.nodes=f['nodes'];self.values=f['force'][index]
        self.rat=np.array([1/np.prod(x-np.delete(self.nodes,i)) for i,x in enumerate(self.nodes)])
        with np.load(HERE/('host-'+chunk[0]['prep']+'.npz')) as f:
            self.radius=f['rad'];self.host=[CubicHermiteSpline(self.radius,x[...,0],x[...,1],axis=0,extrapolate=False) for x in f['host']]
            static=f['static'];self.static=CubicHermiteSpline(self.radius,static[...,0],static[...,1],axis=0,extrapolate=False)
    def weights(self,x):
        assert np.all(x>=self.nodes[0]) and np.all(x<=self.nodes[-1]),x
        dif=x[:,None]-self.nodes
        exact=(dif==0)
        val=self.rat/np.where(exact,1.,dif);has=exact.any(axis=1)
        val[has]=exact[has];return val/val.sum(axis=1)[:,None]
    def ordinary(self,p,t,source):
        f=(t+self.date)/self.duration;assert 0<=f<=1
        if source=='native':
            r=np.linalg.norm(p,axis=1);a,b=self.host
            result=force(p,(1-f)*a(r)+f*b(r),(1-f)*a(r,1)+f*b(r,1))
        else:
            pos,unit=cylindrical(p);dist=pos-self.centres
            acc=np.einsum('si,sj,sijv->sv',self.weights(dist[:,0]),self.weights(dist[:,1]),(1-f)*self.values[0]+f*self.values[1])
            result=acc[:,:1]*unit+acc[:,1:]*[0,0,1]
        assert np.isfinite(result).all()
        return result
    def fixed(self,p):
        r=np.linalg.norm(p,axis=1);return force(p,self.static(r),self.static(r,1))
    def acceleration(self,p,t,source,control,field):
        a=self.ordinary(p,t,source)
        if control=='live':a+=field(p)
        elif control=='static_monopole':a+=self.fixed(p)
        offset=p-p[:1];a-=GM*offset/(SCALE**2+(offset*offset).sum(axis=1))[:,None]**1.5
        return CONV**2*a
    def energy(self,p,v):
        return ((v-v[0])**2).sum(axis=1)/(2*CONV**2)-GM/np.sqrt(SCALE**2+((p-p[0])**2).sum(axis=1))
class Wave:
    def __init__(self,lab,shape,q):
        from directional import Radial,green
        self.lab=lab;self.bg=lab.obj.bg;self.el=lab.run.el;self.obj=lab.obj;self.shape=shape
        self.mesh=Radial(lab,16);self.green=green
        with np.load(HERE/f'global-{q}.npz') as data:
            assert np.array_equal(data['target'],self.bg.rad*self.bg.length)
            leg=legvander(self.bg.mu,int(data['degrees'][-1]))[:,::2]
            self.fields={'direct':[(data['phi'][:,:,i]@leg.T)/self.bg.vel**2-lab.mesh.ordinary for i in (0,1)],'native':[lab.run.fields[i] for i in (581,586)]}
    def drive(self,source,frac):
        a,b=self.fields[source];return a+frac*(b-a)
    def amplitude(self,p,state):
        r=np.linalg.norm(p,axis=1);rad=r/self.bg.length;el=self.el
        idx=np.searchsorted(el.right,rad);weights=self.shape(el.knots,(rad-el.left[idx])/el.width[idx])[0]
        orders=self.bg.orders
        func=np.einsum('ti,til->tl',weights,el.nodes(state)[idx])
        return np.sqrt(self.lab.mesh.mscale/(4*np.pi*self.bg.length))*np.sum(func*eval_legendre(orders,(p[:,2]/r)[:,None])*np.sqrt(2*orders+1),axis=1)/r
    def potential(self,state,drive):
        mesh=self.mesh;bg=self.bg
        targets=np.arange(5.15,5.431,.0025)
        proxy=SimpleNamespace(obj=self.obj,run=SimpleNamespace(fields={590:drive}),initial={'zero':0*state,'wave':state})
        pot,grad,_=self.green(proxy,mesh,targets/bg.length)
        norm=np.sqrt(2*mesh.sell+1)*bg.vel**2
        interp=CubicHermiteSpline(targets,pot[:,:,0]*norm,grad[:,:,0]*norm/bg.length,axis=0,extrapolate=False)
        def evaluate(p):
            rad=np.linalg.norm(p,axis=1);result=force(p,interp(rad),interp(rad,1));assert np.isfinite(result).all();return result
        return evaluate
    def derivatives(self,state,source,frac,duration):
        obj=self.obj;drive=self.drive(source,frac);mom=obj.moment(state);phi=obj.phi(mom)
        def hamilton(vec):return obj.bare@vec+obj.multiply(drive+phi,vec)-obj.mu*vec
        first=-1j/obj.unit_myr*hamilton(state);mdot=(2*(obj.sky(state).conj()*obj.sky(first)).real)@obj.wave.weights
        a,b=self.fields[source];second=-1j/obj.unit_myr*(hamilton(first)+obj.multiply((b-a)/duration+obj.phi(mdot),state))
        return first,second
