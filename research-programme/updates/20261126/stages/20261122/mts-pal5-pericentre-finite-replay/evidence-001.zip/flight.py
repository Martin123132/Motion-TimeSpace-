from models import *
def run(q,chartq,degree,count,factor):
    previous('wave_sites.py');from wave_sites import setup
    lab,Evo,advance,hold,shape=setup();obj=lab.obj
    wave=Wave(lab,shape,q)
    data=read(previous('sites.csv'));target=read(previous('wave-response-12-4.csv'))
    jets=[];obs=[];laws=[];safety=[]
    tag=f'{q}-{chartq}-{degree}-{count}-{factor}'
    for first in range(0,len(data),3):
        chunk=data[first:first+3];arm,flow=chunk[0]['prep'],chunk[0]['flow'];key=arm+'_'+flow
        star=Stars(chunk,first//3,chartq,degree);p0=star.start;v0=star.v;duration=star.duration;date=star.date
        with np.load(HERE/f'launch-{factor}.npz') as bank:start=bank[key]
        def rho(P,state):return abs(wave.amplitude(P,state))**2
        amplitude=wave.amplitude(p0,start);baseline=abs(amplitude)**2
        ref=np.array([float(r['wave_density']) for r in target[first:first+3]])
        assert np.max(abs(baseline/ref-1))<5e-5
        fraction=date/duration;u,v=wave.derivatives(start,'native',fraction,duration)
        un,vn=wave.derivatives(start,'direct',fraction,duration)
        delta_u=un-u
        def linear_at(p):return 2*(wave.amplitude(p,start).conj()*wave.amplitude(p,delta_u)).real
        linear=linear_at(p0)
        fixed=2*(amplitude.conj()*wave.amplitude(p0,vn-v)+(wave.amplitude(p0,delta_u).conj()*wave.amplitude(p0,un+u))).real
        change=CONV**2*(star.ordinary(p0,0,'direct')[0]-star.ordinary(p0,0,'native')[0])
        step=.0001
        motion=(linear_at(p0+step*v0[0])-linear_at(p0-step*v0[0]))/step
        norm=np.linalg.norm(change);dirn=change/norm
        frame=norm*(rho(p0+step*dirn,start)-rho(p0-step*dirn,start))/(2*step)
        curvature=(fixed+motion+frame)/baseline
        expected=np.array([float(r['density_curve_fraction_Myr_m2']) for r in target[first:first+3]])
        gauge=-1j*obj.multiply(.1+0*wave.fields['direct'][0],start)/obj.unit_myr
        assert max(abs(2*(amplitude.conj()*wave.amplitude(p0,gauge)).real/baseline))<1e-11
        for j,row in enumerate(chunk):jets.append(dict(prep=arm,flow=flow,tail=row['tail'],linear=linear[j]/baseline[j],curvature=curvature[j],expected=expected[j],fixed=fixed[j]/baseline[j],motion=motion[j]/baseline[j],frame=frame[j]/baseline[j],curvature_error=abs(curvature[j]/expected[j]-1)))
        dt=.0625/count;sf=Evo(obj,dt/obj.unit_myr,start)
        states={s:start.copy() for s in wave.fields};mom={s:obj.moment(start) for s in states}
        ctrls=('ordinary','static_monopole','live')
        paths={(s,c):[p0.copy(),v0.copy(),None] for s in states for c in ctrls}
        initial_energy=star.energy(p0,v0)
        baseforce=wave.potential(start,wave.drive('native',fraction))
        for (s,c),(p,vel,_) in paths.items():paths[s,c][2]=star.acceleration(p,0,s,c,baseforce)
        for tick in range(1,count+1):
            hold();guard();t=tick*dt
            for s in states:
                drive=wave.drive(s,(date+t-dt/2)/duration)
                states[s],mom[s],_,_=advance(obj,sf,states[s],mom[s],drive,dt/obj.unit_myr)
                forcefun=wave.potential(states[s],wave.drive(s,(date+t)/duration))
                for c in ctrls:
                    p,vv,before=paths[s,c];vv+=dt*before/2;p+=dt*vv
                    after=star.acceleration(p,t,s,c,forcefun);vv+=dt*after/2;paths[s,c][2]=after
            if tick not in (count//4,count//2,count):continue
            amplitudes={}
            for s in states:
                probes=p0+(paths[s,'live'][0][0]-p0[0])
                amplitudes[s]=wave.amplitude(probes,states[s])
                occ=abs(np.vdot(states[s],states[s]).real/obj.number-1);assert occ<1e-9
                safety.append(dict(prep=arm,flow=flow,source=s,time=t,occupation_error=occ))
            aa,bb=amplitudes['direct'],amplitudes['native']
            diff=((aa-bb).conj()*(aa+bb)).real/baseline
            corrected=2*(diff-linear/baseline*t)/t**2
            for j,row in enumerate(chunk):obs.append(dict(prep=arm,flow=flow,tail=row['tail'],time=t,fractional_density_difference=diff[j],uncorrected_apparent_curve=2*diff[j]/t**2,projected_linear_removed_curve=corrected[j],launch_projected=curvature[j],launch_continuum=expected[j]))
            for c in ctrls:
                pd,vd,_=paths['direct',c];pn,vn_end,_=paths['native',c]
                shift=(pd-pd[0])-(pn-pn[0]);dv=((vd-vd[0])-(vn_end-vn_end[0]))/CONV
                en,ed=star.energy(pn,vn_end),star.energy(pd,vd)
                for j in (1,2):
                    row=dict(prep=arm,flow=flow,tail=chunk[j]['tail'],control=c,time=t,delta_energy=ed[j]-en[j],native_energy=en[j]-initial_energy[j],direct_energy=ed[j]-initial_energy[j])
                    for lab_,vec in [('shift_kpc',shift[j]),('velocity_kms',dv[j])]:row.update({lab_+'_'+ax:val for ax,val in zip('xyz',vec)})
                    laws.append(row)
        print(key,tag,flush=True)
    for label,item in [('launch',jets),('density',obs),('stars',laws),('number',safety)]:table(label+'-'+tag+'.csv',item)
if __name__=='__main__':run(*map(int,sys.argv[1:]))
