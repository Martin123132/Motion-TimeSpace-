from models import *
def run():
    def keys(row):return tuple(row[k] for k in ('prep','flow','tail'))
    def vect(row,k):return np.array([float(row[k+'_'+ax]) for ax in 'xyz'])
    sets=[{keys(row):row for row in read(HERE/f'wave-tide-curvature-{tag}.csv')} for tag in ('1-3','2-4','3-4')]
    out=[];details=[]
    for coord,record in sets[-1].items():
        for k in ('total','monopole','aspherical','inside','outside'):
            vals=[vect(bank[coord],k) for bank in sets]
            details.append(dict(prep=coord[0],flow=coord[1],tail=coord[2],component=k,first_spatial=np.linalg.norm(vals[0]-vals[1])/np.linalg.norm(vals[1]),second_spatial=np.linalg.norm(vals[1]-vals[2])/np.linalg.norm(vals[2])))
    for years in (64,1024):
        packet=[{(*keys(r),float(r['time'])):r for r in read(HERE/f'stellar-feedback-2-4-{steps}-{years}-4.csv')} for steps in (16,32)]
        for identity,r in packet[1].items():
            prep,flow,tail,t=identity;coord=identity[:3]
            actual=vect(r,'dv');other=vect(packet[0][identity],'dv')
            initial=vect(sets[-1][coord],'total')*CONV*t**3/6
            gridmatched=vect(sets[1][coord],'total')*CONV*t**3/6
            records=read(HERE/f'fv-orbits-2-4-32-{years}-{prep}_{flow}.csv')
            full=vect(next(row for row in records if row['tail']==tail and float(row['time'])==t),'vel')
            out.append(dict(prep=prep,flow=flow,tail=tail,years=round(t*1e6),delta_wave_only_kms=np.linalg.norm(actual),total_change_kms=np.linalg.norm(full),wave_to_total=np.linalg.norm(actual)/np.linalg.norm(full),velocity_timestep=np.linalg.norm(other-actual)/np.linalg.norm(actual),relative_to_cubic=np.linalg.norm(initial-actual)/np.linalg.norm(initial),relative_to_own_grid_cubic=np.linalg.norm(gridmatched-actual)/np.linalg.norm(gridmatched)))
    table('tide-resolution.csv',details);table('wave-impulse.csv',out)
if __name__=='__main__':run()
