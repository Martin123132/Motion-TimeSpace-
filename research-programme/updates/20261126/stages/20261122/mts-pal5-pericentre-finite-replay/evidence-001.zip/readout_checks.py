from record_io import *
def main():
    checks=[]
    def put(which,key,time,a,b):
        assert float(b)!=0 and np.isfinite(float(a)+float(b))
        err=abs(float(a)/float(b)-1);checks.append(dict(test=which,case=key,years=time,relative=err,passed=err<=.005,agrees_in_sign=float(a)*float(b)>0))
    for tag0,tag1,test in [('2-4-16-1024-4','3-4-16-1024-4','third spatial mesh'),('1-3-16-1024-4','2-4-16-1024-4','second spatial mesh'),('2-4-16-1024-4','2-4-32-1024-4','halved wave step'),('2-4-32-1024-2','2-4-32-1024-4','halved orbit step'),('2-4-32-1024-4-direct8','2-4-32-1024-4-direct12','along-path direct q8:q12'),('2-4-32-1024-4','2-4-32-1024-4-direct12','chart versus along-path direct')]:
        low,high=(read(HERE/f'passage-contrast-{path}.csv') for path in (tag0,tag1))
        for a,b in zip(low,high,strict=True):
            assert all(a[k]==b[k] for k in ('prep','tail','control','time'))
            for col in ('native_contrast','direct_contrast','source_change'):
                put(test+' '+col,' '.join(b[k] for k in ('prep','tail','control')),round(float(b['time'])*1e6),a[col],b[col])
    old=read(previous('energy-12-4.csv'))
    for row in read(HERE/'passage-contrast-2-4-32-1024-4-direct12.csv'):
        def launch(src):
            def work(flow):return float(next(r['work_curvature_kms2_Myr2'] for r in old if (r['prep'],r['flow'],r['tail'],r['control'],r['source'])==(row['prep'],flow,row['tail'],row['control'] if row['control']!='live' else 'signed',src)))
            return work('forward')-work('reverse')
        t=float(row['time']);key=' '.join(row[k] for k in ('prep','tail','control'))
        for src in ('native','direct'):
            put('own passage work compared with launch '+src,key,round(t*1e6),2*float(row[src+'_contrast'])/t**2,launch(src))
    table('contrast-checks.csv',checks)
    for level,order in [(1,3),(2,4),(3,4)]:
        with np.load(HERE/f'mass-{level}-{order}.npz') as bank, np.load(HERE/'global-9.npz') as glob:
            mass=4*np.pi*np.sum(bank['mass']*np.diff(bank['mf']),axis=(1,2))
            assert np.max(abs(mass/glob['mass']-1))<.005
    impulses=read(HERE/'wave-impulse.csv');assert len(impulses)==48 and all(float(r['velocity_timestep'])<.005 for r in impulses)
    print('contrast comparisons',len(checks),'not within 0.5%:',sum(not r['passed'] for r in checks))
if __name__=='__main__':main()
