from models import *
def run():
    previous('wave_sites.py');from wave_sites import setup,INV,manifest as inventory
    lab,Evolution,advance,hold,shape=setup();obj=lab.obj;bg=obj.bg;host=lab.run;mesh=host.el
    wave=Wave(lab,shape,9)
    duration=host.ages[586]-host.ages[581];count,dt=host.interval(581,586);dt/=4;count*=4
    site=read(previous('sites.csv'));density=read(previous('wave-response-12-4.csv'));original={}
    afile=INV/'states-586-280.npz';assert digest(afile)==inventory[afile.name]
    with np.load(afile) as bank:
        for first in range(0,len(site),3):
            part=site[first:first+3];arm,siteflow=part[0]['prep'],part[0]['flow'];waveflow='reverse' if siteflow=='forward' else 'forward'
            state=bank[arm+'_'+waveflow];moment=obj.moment(state);solver=Evolution(obj,-dt,state)
            end=(1-float(part[0]['date'])/duration)*count
            for tick in range(int(np.ceil(end))):
                guard();hold();portion=min(1,end-tick);step=-dt*portion
                if portion!=1:solver=Evolution(obj,step,state)
                frac=1-(tick+portion/2)/count
                state,moment,_,_=advance(obj,solver,state,moment,host.fields[581]+frac*(host.fields[586]-host.fields[581]),step)
            key=arm+'_'+siteflow
            assert abs(np.vdot(state,state).real/obj.number-1)<1e-9
            pos=vcols(part,'pos');rho=lambda pts:abs(wave.amplitude(pts,state))**2
            directions=np.eye(3)*.00001
            gradient=np.column_stack([(rho(pos+d)-rho(pos-d))/.00002 for d in directions])
            det=read(previous('tides-12-4.csv'));unit=cylindrical(pos)[1];diff=np.zeros_like(pos)
            for j in (1,2):
                r=next(row for row in det if (row['prep'],row['flow'],row['tail'])==(arm,siteflow,part[j]['tail']))
                diff[j]=float(r['source_delta_R'])*unit[j]+float(r['source_delta_z'])*np.array([0,0,1])
            compression=[float(r['compression_Myr_m2']) for r in density[first:first+3]]
            original[key]={'state':state,'rho':rho(pos),'expected':compression-CONV**2*np.sum(gradient*diff,axis=1)/rho(pos)}
    for level,order in ((1,3),(2,4),(3,4)):
        with np.load(HERE/f'volume-{level}-{order}.npz') as vol:
            r=(vol['rf'][1:]+vol['rf'][:-1])/2;mu=(vol['mf'][1:]+vol['mf'][:-1])/2
        basis=legvander(mu,bg.orders[-1])[:,::2];idx=np.searchsorted(mesh.right,r/bg.length)
        weights=shape(mesh.knots,(r/bg.length-mesh.left[idx])/mesh.width[idx])[0]
        output={}
        for key,values in original.items():
            coeff=np.einsum('ri,ril->rl',weights,mesh.nodes(values['state'])[idx])
            output[key]=np.sqrt(lab.mesh.mscale/(4*np.pi*bg.length))*(coeff*np.sqrt(2*bg.orders+1))@basis.T
            output[key+'_rho']=values['rho'];output[key+'_expected']=values['expected']
        packet(f'cross-launch-{level}-{order}.npz',**output)
if __name__=='__main__':run()
