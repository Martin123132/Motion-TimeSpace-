from record_io import *
def run():
    previous('wave_sites.py');from wave_sites import setup,INV,manifest as wave_manifest
    lab,Evolution,advance,hold,shape=setup();host=lab.run;obj=lab.obj
    data=read(previous('sites.csv'));dur=host.ages[586]-host.ages[581]
    for factor in (2,4):
        name=f'states-586-{70*factor}.npz';p=INV/name;assert digest(p)==wave_manifest[name]
        count,dt=host.interval(581,586);dt/=factor;count*=factor;out={}
        with np.load(p) as start:
            for row in data[::3]:
                key=row['prep']+'_'+row['flow'];state=start[key];mom=obj.moment(state)
                solver=Evolution(obj,-dt,state);end=(1-float(row['date'])/dur)*count
                for tick in range(int(np.ceil(end))):
                    hold();guard();portion=min(1.,end-tick);step=-dt*portion
                    if portion!=1:solver=Evolution(obj,step,state)
                    phase=1-(tick+.5*portion)/count
                    drive=host.fields[581]+phase*(host.fields[586]-host.fields[581])
                    state,mom,_,_=advance(obj,solver,state,mom,drive,step)
                assert abs(np.vdot(state,state).real/obj.number-1)<1e-9
                out[key]=state
        packet(f'launch-{factor}.npz',**out)
    for arm in ('reset','coupled'):
        inputs={}
        for leg in ('before','middle'):
            name=f'fine-{leg}-{arm}'
            path=old.STREAM/(name+'.npz')
            receipt=json.loads(old.pin(old.STREAM,name+'.json').read_bytes());assert digest(path)==receipt['packet']
            with np.load(path) as values:
                rad=values['radius'];select=(rad>=5.)&(rad<=5.55);r=rad[select]
                if leg=='before':
                    inputs.update(rad=r,host=values['host'][:,select],duration=values['time'][-1])
                else:
                    assert np.array_equal(r,inputs['rad'])
                    inputs['static']=values[arm+'_forward'][-1,select,:1,:,0]
        packet('host-'+arm+'.npz',**inputs)
if __name__=='__main__':run()
