from models import *
from volume_mass import FV,fvpin
from scipy.interpolate import RectBivariateSpline
def run(level,order):
    fvpin('mesh_fd.py');fvpin('finite_io.py');sys.path.insert(0,str(FV));from mesh_fd import Space,sample
    out=[];records=read(previous('sites.csv'))
    with np.load(HERE/f'volume-{level}-{order}.npz') as bank:
        space=Space(bank['rf'],bank['mf']);dr=space.dr[:,None];dm=space.dm
        ir=np.flatnonzero((space.r>5.15)&(space.r<5.45));im=np.flatnonzero((space.mu>.47)&(space.mu<.55));ix=np.ix_(ir,im)
        for i in range(0,len(records),3):
            part=records[i:i+3];prep,flow=part[0]['prep'],part[0]['flow']
            state=bank[prep+'_'+flow];frac=float(part[0]['date'])/float(part[0]['duration'])
            delta=bank['delta0']*(1-frac)+bank['delta1']*frac
            fluxr=CONV**2*np.real(state[:-1].conj()*state[1:])*(delta[:-1]-delta[1:])/np.diff(space.r)[:,None]
            fluxm=CONV**2*np.real(state[:,:-1].conj()*state[:,1:])*(delta[:,:-1]-delta[:,1:])*(1-space.mf[1:-1]**2)/(space.r[:,None]**2*np.diff(space.mu))
            changes=np.zeros(state.shape);changes[:-1]-=fluxr/dr[:-1];changes[1:]+=fluxr/dr[1:];changes[:,:-1]-=fluxm/dm[:-1];changes[:,1:]+=fluxm/dm[1:]
            assert abs(np.sum(dr*dm*changes))/np.sum(dr*dm*abs(changes))<1e-12
            pts=vcols(part,'pos')
            def tide(ch):
                pot=space.poisson(4*np.pi*G*dr*ch);spline=RectBivariateSpline(space.r[ir],space.mu[im],pot[ix])
                f=sample(spline,pts);return f-f[0]
            full=tide(changes);average=(changes@dm)[:,None];mono=tide(np.broadcast_to(average,changes.shape))
            rest=tide(changes-average)
            assert np.linalg.norm(mono+rest-full)<1e-7*np.linalg.norm(full)
            r0=np.linalg.norm(pts[0]);lower,upper=r0-.10,r0+.10
            weight=np.maximum(0,np.minimum(space.rf[1:],upper)-np.maximum(space.rf[:-1],lower))/space.dr
            inside=tide(changes*weight[:,None]);outside=tide(changes*(1-weight[:,None]))
            assert np.linalg.norm(inside+outside-full)<1e-7*np.linalg.norm(full)
            for j in (1,2):
                row=dict(prep=prep,flow=flow,tail=part[j]['tail'],monopole_parallel_fraction=mono[j]@full[j]/(full[j]@full[j]),outside_parallel_fraction=outside[j]@full[j]/(full[j]@full[j]))
                for k,vec in [('total',full),('monopole',mono),('aspherical',rest),('inside',inside),('outside',outside)]:row.update({k+'_'+ax:value for ax,value in zip('xyz',vec[j])})
                out.append(row)
    table(f'wave-tide-curvature-{level}-{order}.csv',out)
if __name__=='__main__':run(*map(int,sys.argv[1:]))
