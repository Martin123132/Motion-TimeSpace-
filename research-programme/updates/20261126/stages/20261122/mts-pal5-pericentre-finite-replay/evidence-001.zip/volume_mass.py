from record_io import *
from unittest.mock import patch
FV=ROOT/'mts-pal5-finite-wave-stripping-20261122'
assert digest(FV/'seal.json')=='4db5e73d0a80bbc234e7d1036b11a99d2965805c6eb42d04f91f4171260aa5e8'
def fvpin(name):
    assert digest(FV/name)==json.loads((FV/'seal.json').read_bytes())[name]
def faces(level,extra,outer,angular):
    spec=([(0,.012,.001),(.012,.08,.003),(.08,.30,.008),(.30,.478,.004),(.478,.532,.0011),(.532,.64,.003),(.64,1.,.008)] if angular else
          [(0,2,.06),(2,4.8,.08),(4.8,5.17,.018),(5.17,5.42,.005),(5.42,5.8,.018),(5.8,30,.13),(30,100,.7),(100,outer,2.4)])
    base=np.unique(np.r_[0.,outer,extra,[x[0] for x in spec],[x[1] for x in spec]])
    if not angular:
        base=np.unique(np.r_[base,np.arange(5.,5.56,.03125)])
    base=base[(base>=0)&(base<=outer)]
    base=base[np.r_[True,np.diff(base)>1e-7]]
    cuts=[]
    for a,b in zip(base[:-1],base[1:]):
        length=next(h for l,r,h in spec if l<=(a+b)/2<=r)
        cuts.extend(np.linspace(a,b,max(1,int(np.ceil((b-a)*level/length)))+1)[:-1])
    return np.r_[cuts,outer]
def run(level,order):
    previous('source_at_sites.py');from source_at_sites import group
    src=old.sources()
    with patch('source_at_sites.table',table):params=group(src)
    for name in ('finite_io.py','mesh_fd.py','ordinary.py'):fvpin(name)
    sys.path.insert(0,str(FV));import ordinary
    with patch.object(ordinary,'edges',faces),patch.object(ordinary,'packet',packet),patch.object(ordinary,'guard',guard),patch.object(src,'info',lambda:params):ordinary.run(level,order)
if __name__=='__main__':
    for spec in sys.argv[1:]:run(*map(int,spec.split('-')))
