from flow import *


def run(model):
    big,window,cuts=get_inputs()
    inside,accepted=screens(big)
    earlier=~inside
    bg,greens,row,shell=setup(model,big)
    ns=len(bg.species)
    largest=2*max(abs(big.axes[:,earlier]).ravel())
    output=(np.abs(big.out)<=largest).all(axis=0)
    local=object.__new__(old.Modes)
    for attr in ("k","R"):
        setattr(local,attr,getattr(big,attr)[earlier])
    local.vec=big.vec[:,earlier];local.src=tuple(big.axes[:,earlier])
    local.out=big.out[:,output];local.k2=big.k2[output];local.outvec=big.outvec[:,output];local.weights=big.weights[output];local.dst=tuple(local.out)
    selector=shell[output];small=2*largest+3
    mat=matrices(window[:,output],local,accepted[output])
    saved=[];kin={};checks=[]
    for slot,at in enumerate(bg.times):
        guard()
        dual=np.einsum("ki,kij->kj",row,greens[slot])
        dens,theta=bg.fields_at(local,slot)
        mixed=np.zeros(len(local.k2),complex)
        coordinate=np.zeros_like(mixed)
        for idx,label in enumerate(bg.species):
            mass=bg.mass if label=="wave" else 0.
            fl,adv,press,_=old.source_terms(local,small,dens[idx],theta[idx],at,mass)
            if slot in (0,32,64):
                ref=old.source_terms(local,135,dens[idx],theta[idx],at,mass)
                err=max(local.norm(one-two)/max(local.norm(two),1e-50) for one,two in zip((fl,adv,press),ref))
                assert err<2e-5
                checks.append(dict(a=at,species=label,max_relative=err))
                dc,vc,_,_=push(local,dens[idx],theta[idx],small)
                coordinate+=dual[selector,idx]*dc-dual[selector,ns+idx]*at/bg.B*vc
            mixed+=dual[selector,idx]*fl/(at*bg.hub(at))-dual[selector,ns+idx]*(adv+press)/(bg.B*bg.hub(at))
        saved.append((mat@mixed).real)
        if slot in (0,32,64):kin[slot]=(mat@coordinate).real
    result=[]
    for start in (0,32):
        count=64-start
        for panels in (count,count//2):
            term=boole(bg.times[start],.01,panels,count)@saved[start:] + kin[start]-kin[64]
            for idx,cut in enumerate(cuts[:-1]):
                for off,outs in ((0,"nonzero-all"),(len(cuts),"common-screen")):
                    matching=[]
                    for ins in ("all","screened"):
                        with (HERE/f"contribution-{model}-{ins}.csv").open(encoding="utf-8") as stream:
                            match,=[r for r in csv.DictReader(stream) if r["output"]==outs and int(r["panels"])==panels and float(r["a_start"])==bg.times[start] and float(r["cut_kpc"])==cut]
                        matching.append(float(match["compression_drift_pp"]))
                    total,short=matching;long=term[idx+off];mixed=total-short-long
                    result.append(dict(a_start=bg.times[start],cut_kpc=cut,panels=panels,output=outs,
                        long_long_pp=long,long_short_both_orders_pp=mixed,screened_screened_pp=short,total_pp=total))
    table(f"mode-pair-attribution-{model}.csv",result);table(f"long-grid-{model}.csv",checks)


if __name__=="__main__":
    for model in ("cold","heavy"):run(model)
