from material import *
import copy
from scipy.integrate import simpson


def dust():
    old.prior.init_particles()
    old.prior.pin(old.prior.PREV,"early_dynamics.py")
    from early_dynamics import growing
    from initial_file import Initial
    modes=old.Modes()
    bg=old.Background("FIRE")
    bg.times=np.geomspace(.003,.01,65)
    ic=Initial()
    with np.load(pinned("dust-kernel.npz")) as saved:
        invariant=saved["I2"];ga,_,_,_=growing(np.array([ic.a,.01]),ic)
        dates,positions=np.unique(np.r_[ic.a,bg.times,.05],return_inverse=True)
        g,dg,d2,dd2=(field[positions] for field in growing(dates,ic))
        d2,dd2=d2/g[0]**2,dd2/g[0]**2
        g,dg=g/g[0],dg/g[0]
        np.testing.assert_allclose(saved["linear_growth"][1],ga[1]/ga[0],rtol=2e-10)
    at=bg.times[0]
    original=-bg.coeff[0]*g[1]*modes.fire/(2*at)
    groups=source_parts(modes,bg,np.array([g[1]*modes.fire]),np.array([original]),original,at,135)
    exact=bg.coeff[0]*g[1]**2*invariant/(2*at*bg.B*bg.hub(at))
    kernel_error=modes.norm(groups[0,1]-exact)/modes.norm(exact)
    null_error=modes.norm(groups[1:])/modes.norm(exact)
    assert max(kernel_error,null_error)<2e-5,(kernel_error,null_error)
    prop=old.green(bg,modes)[:,0]
    state=lambda index,epoch: np.array([-d2[index],-epoch**2*bg.hub(epoch)*dd2[index]/bg.B])
    forcing=bg.coeff[0]*g[1:-1]**2/(2*bg.times*bg.B*bg.hub(bg.times))
    columns=prop[:,:,1]*forcing[:,None]
    results=[]
    for start in (0,32):
        size=64-start
        initial=prop[start]@state(start+1,bg.times[start])
        target=state(-2,.01)
        for panels in (size,size//2,size//4):
            computed=initial+boole(bg.times[start],.01,panels,size)@columns[start:]
            diff=abs(computed-target)/abs(target)
            assert max(diff)<2e-5
            results.append(dict(a_start=bg.times[start],panels=panels,source_identity=kernel_error,roundoff_null=null_error,density_relative=diff[0],velocity_relative=diff[1]))
    table("dust-control.csv",results)


def common_response(model):
    modes,windows,cuts=get_inputs()
    _,outgate=screens(modes)
    bg,greens,row,shell=setup(model,modes)
    vector=np.einsum("ki,skij->skj",row,greens)
    ns=len(bg.species);clock=np.log(bg.times)
    gain=vector[:,:,ns:].sum(axis=-1)*bg.coeff.sum()/(2*bg.times*bg.hub(bg.times)*bg.B)[:,None]
    results=[];stitch=[]
    newbg=copy.copy(bg)
    newbg.times=np.geomspace(.003,.05,65)
    total=old.green(newbg,modes)[0]
    normal=old.Background(model)
    sign=np.zeros(2*ns);sign[ns-1]=1;sign[0]=-1
    alternate=sign@total - sign@greens[0]
    stitch.append(dict(model=model,independent_composition=max(abs((alternate-vector[0]).ravel()))))
    assert stitch[0]["independent_composition"]<2e-7
    for mask,key in ((modes.k2>0,"nonzero-all"),(outgate,"common-screen")):
        sel=shell[mask]
        for idx,cut in enumerate(cuts[:-1]):
            power=np.bincount(sel,weights=modes.weights[mask]*abs(windows[idx,mask])**2,minlength=gain.shape[1])
            for start in (0,32):
                samples=64-start
                for panels in (samples,samples//2):
                    wt=boole(bg.times[start],.01,panels,samples)
                    fac=gain[start:]
                    coherent=np.sqrt(power@((wt@fac)**2))
                    arbitrary=np.sqrt(np.log(.01/bg.times[start])*(wt@(fac**2@power)))
                    incoming=np.sqrt(np.sum(power[:,None]*vector[start]**2))
                    assert coherent<=arbitrary+1e-10
                    if model=="cold": assert arbitrary<2e-8
                    results.append(dict(cut_kpc=cut,output=key,a_start=bg.times[start],panels=panels,
                          incoming_pp_per_joint_rms=incoming,coherent_pp_per_density_rms=coherent,
                          variable_pp_per_space_time_rms=arbitrary))
    table(f"unknown-input-gains-{model}.csv",results)
    table(f"composition-{model}.csv",stitch)


def linear_check(model):
    old.parent("evolve.py")
    from evolve import advance
    from seeds import Seed
    modes,_,_=get_inputs()
    input_gate,_=screens(modes)
    seed=Seed(model,"anchorA","heavy")
    with np.load(HERE/f"history-{model}.npz") as data:
        full,k,epochs,metric,names=(data[c] for c in ("full","k","epochs","k2psi","species"))
        names=names.tolist()
    results=[]
    counts=np.bincount(np.searchsorted(np.unique(modes.k),modes.k),weights=abs(modes.R)**2*modes.weights[modes.inband])
    kr=np.unique(modes.k)
    for start in (0,32):
        dates=epochs[start:];first=full[:,:,:,start]
        for case in ("poisson","prescribed","prescribed-coarse"):
            states=advance(seed,dates,k,names,first,metric[:,start:],case)
            for idx,name in enumerate(names):
                for vel,channel in enumerate(("density","momentum")):
                    native=full[idx,vel,:,start:]
                    diff=PchipInterpolator(np.log(k),states[idx,vel],axis=0)(np.log(kr))-PchipInterpolator(np.log(k),native,axis=0)(np.log(kr))
                    truth=PchipInterpolator(np.log(k),native,axis=0)(np.log(kr))
                    for mask,selection in ((np.ones(len(kr),bool),"all"),(np.isin(kr,np.unique(modes.k[input_gate])),"screened")):
                        size=np.sqrt((counts[mask]@diff[mask]**2)/(counts[mask]@truth[mask]**2))
                        results.append(dict(model=model,a_start=dates[0],variant=case,input=selection,species=name,channel=channel,final_relative=size[-1],max_relative=max(size)))
    table(f"linear-validity-{model}.csv",results)


if __name__=="__main__":
    dust()
    for model in ("cold","heavy"):
        common_response(model);linear_check(model)
