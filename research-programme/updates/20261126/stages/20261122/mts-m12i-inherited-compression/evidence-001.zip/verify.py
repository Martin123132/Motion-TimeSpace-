from compare import *


def numbers(path,name,**match):
    return np.array([float(r[name]) for r in rows(path,**match) if r[name]])


def run():
    guard()
    names=set("PROTOCOL.md METRIC-TEST.md ADIABATIC-TEST.md EQUATIONS.md RESULTS.md inputs.py history.py flow.py material.py controls.py late_control.py adiabatic.py compare.py verify.py dust-control.csv updated-drift.csv scale-attribution.csv response-comparisons.csv sign-thresholds.csv coverage.json".split())
    names.update("slip.py SLIP-TEST.md pairs.py closure.py corrected-independent-closure.csv".split())
    names.update("frame.py FRAME-TEST.md freely-falling-tube.csv accelerated-wave-equation.csv".split())
    assert max(numbers(HERE/"freely-falling-tube.csv","matched_field_max_relative"))<2e-5
    assert numbers(HERE/"accelerated-wave-equation.csv","wave_equation_relative")[-1]<2e-5
    stats={}
    for model in ("cold","heavy"):
        stats[model]={}
        names.update(f"{stem}-{model}.csv" for stem in ("chart-correction","measured-slip","mode-pair-attribution","long-grid"))
        assert max(numbers(HERE/f"long-grid-{model}.csv","max_relative"))<2e-5
        for part in rows(HERE/f"mode-pair-attribution-{model}.csv"):
            assert abs(float(part["total_pp"])-sum(float(part[key]) for key in ("long_long_pp","long_short_both_orders_pp","screened_screened_pp")))<1e-12
        closed=rows(HERE/"corrected-independent-closure.csv",model=model)
        for start in sorted({r["a_start"] for r in closed}):
            finest=max(int(r["material_panels"]) for r in closed if r["a_start"]==start)
            errors=[abs(float(r["after_rel"])) for r in closed if r["a_start"]==start and int(r["material_panels"])==finest]
            stats[model]["two_route_"+start]=dict(worst=max(errors),within_0p005=sum(v<.005 for v in errors),within_2e_minus_5=sum(v<2e-5 for v in errors),n=len(errors))
        names.update(f"{prefix}-{model}.{ext}" for prefix,ext in (("history","npz"),("endpoint","csv"),("material","csv"),("material-grid","csv"),("force-check","csv"),("unknown-input-gains","csv"),("composition","csv"),("linear-validity","csv"),("adiabatic-mode","csv")))
        with np.load(HERE/f"history-{model}.npz") as data:
            assert np.array_equal(data["epochs"],np.geomspace(.003,.01,65)) and np.isfinite(data["values"]).all()
        assert max(numbers(HERE/f"endpoint-{model}.csv","relative_l2"))<2e-5
        assert max(numbers(HERE/f"composition-{model}.csv","independent_composition"))<2e-7
        for ins in ("all","screened"):
            tag=f"{model}-{ins}"
            names.update((f"compression-{tag}.npz",f"grid-comparison-{tag}.csv",f"contribution-{tag}.csv",f"late-control-{tag}.csv"))
            with np.load(HERE/f"compression-{tag}.npz") as pack:
                for key in ("density","scaled_divergence"):
                    state=pack[key]
                    assert np.isfinite(state).all() and not np.any(state[:,0])
                assert np.all(pack["projected_integrand_pp"][:,[4,9]]==0)
            assert len(rows(HERE/f"contribution-{tag}.csv"))==60
            for key in ("continuity","euler","pressure"):
                assert max(numbers(HERE/f"grid-comparison-{tag}.csv",key))<2e-5
        for key in ("poisson","metric_correction","species_force_correction"):
            assert max(numbers(HERE/f"material-grid-{model}.csv",key))<2e-5
        chunks=rows(HERE/"scale-attribution.csv",model=model)
        assert all(abs(float(r["all_pp"])-sum(float(r[key]) for key in ("common_screen_pp","input_pair_exclusion_at_fixed_output_pp","output_exclusion_with_full_input_pp")))<1e-12 for r in chunks)
        checks=rows(HERE/"response-comparisons.csv",model=model)
        for selector in ("time-","reproduce-late","Euler-vs-with_effective_force_pp-common-screen-32"):
            selected=[r for r in checks if r["test"].startswith(selector)]
            assert selected
            err=max(abs(float(r["difference_pp"])/float(r["first_pp"])) for r in selected)
            stats[model][selector]=dict(maximum_relative=err,within_0p005=bool(err<.005),within_2e_minus_5=bool(err<2e-5))
            if selector!="Euler-vs-with_effective_force_pp-common-screen-32": assert err<.005
        late=rows(HERE/"updated-drift.csv",model=model)
        assert len(late)==8 and all(abs(float(r["conditional_updated_drift_pp"])-float(r["earlier_dynamic_pp"])-float(r["late_reference_pp"]))<1e-12 for r in late)
        assert all(abs(float(r["finer_late_vs_coarser_pp"])/float(r["late_reference_pp"]))<.005 for r in late)
    for key in ("source_identity","density_relative","velocity_relative"):
        assert max(numbers(HERE/"dust-control.csv",key))<2e-5
    assert set(p.name for p in HERE.iterdir())-{"seal.json"}==names
    record("seal.json",dict(files={name:digest(HERE/name) for name in sorted(names)},previous=digest(BASE/"seal.json"),checks=stats))
    print(len(names),"items",digest(HERE/"seal.json"),stats)


if __name__=="__main__":run()
