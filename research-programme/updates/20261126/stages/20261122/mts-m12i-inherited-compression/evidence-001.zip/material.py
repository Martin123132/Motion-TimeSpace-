from flow import *
from scipy.interpolate import PchipInterpolator


def time_derivative(array, clock, points=5):
    result=np.empty_like(array)
    step=clock[1]-clock[0]
    np.testing.assert_allclose(np.diff(clock),step,rtol=1e-12)
    for slot in range(len(clock)):
        first=max(0,min(len(clock)-points,slot-points//2))
        offset=first+np.arange(points)-slot
        weights=np.linalg.solve(np.vstack([offset.astype(float)**power for power in range(points)]),np.eye(points)[1])/step
        result[...,slot]=array[...,first:first+points]@weights
    return result


def transported(modes,history,forces,size):
    real=lambda field:modes.real(field,size)
    density=real(history)
    total=.5*density**2
    adv=[np.zeros_like(density) for _ in forces]
    for index,axis in enumerate(modes.vec):
        disp=real(1j*axis*history/modes.k**2)
        total-=disp*real(1j*axis*history)
        for field,term in zip(forces,adv):
            term+=disp*real(1j*axis*field)
        for other in range(index,3):
            projector=axis*modes.vec[other]/modes.k**2
            shear=real(projector*history)
            mult=1 if index==other else 2
            total+=.5*mult*shear**2
            for field,term in zip(forces,adv):
                term-=mult*shear*real(projector*field)
    coords=modes.spec(total)
    tides=np.stack([modes.spec(term) for term in adv])
    assert abs(coords[0])<2e-14 and abs(tides[:,0]).max()<2e-14
    coords[0]=0;tides[:,0]=0
    return coords,tides


def quantum(modes,history,at,mass,size):
    density=modes.real(history,size)
    square=sum(modes.real(1j*axis*history,size)**2 for axis in modes.vec)
    return -modes.k2*modes.spec(-.5*density*modes.real(-modes.k**2*history,size)-.25*square)/(2*at**2*mass**2)


def source_parts(modes,bg,density,independent,metric,at,size):
    ns=len(bg.species);parts=[]
    poisson=-bg.coeff@density/(2*at)
    for idx,kind in enumerate(bg.species):
        press=modes.k**4*density[idx]/(4*at**2*bg.mass**2) if kind=="wave" else 0.
        background_force=poisson+press
        forces=(background_force,metric-poisson,independent[idx]-metric-press)
        coords,tides=transported(modes,density[idx],forces,size)
        source=quantum(modes,density[idx],at,bg.mass,size) if kind=="wave" else 0.
        parts.append((coords,tides,source))
    phi_kin=-sum(bg.coeff[idx]*part[0] for idx,part in enumerate(parts))/(2*at)
    groups=np.zeros((3,2*ns,len(modes.k2)),complex)
    for idx,(coords,tides,source) in enumerate(parts):
        total=phi_kin+source
        if bg.species[idx]=="wave":
            total=total+modes.k2**2*coords/(4*at**2*bg.mass**2)
        groups[0,ns+idx]=-(total+tides[0])/(bg.B*bg.hub(at))
        groups[1,ns+idx:ns+idx+1]=-tides[1]/(bg.B*bg.hub(at))
        groups[2,ns+idx:ns+idx+1]=-tides[2]/(bg.B*bg.hub(at))
    return groups


def run(model):
    modes,windows,cuts=get_inputs()
    active,allowed=screens(modes)
    bg,greens,row,shell=setup(model,modes)
    matrix=matrices(windows,modes,allowed)
    with np.load(HERE/f"history-{model}.npz") as data:
        native=data["k2psi"]
    clock=np.log(bg.times)
    hub=bg.hub(bg.times)
    deriv=time_derivative(bg.fields[:,1],clock)*hub
    deriv3=time_derivative(bg.fields[:,1],clock,3)*hub
    ident=[];local=[];response=[]
    for slot in range(0,65,2):
        guard()
        at=bg.times[slot]
        density,theta=bg.fields_at(modes,slot)
        density[:,~active]=0
        density_src=lambda field:PchipInterpolator(np.log(bg.nodes),field,axis=-1)(np.log(modes.k))*modes.R*active
        metric=density_src(native[:,slot])
        actual=density_src(deriv[:,:,slot])
        approx=density_src(deriv3[:,:,slot])
        pred=-bg.coeff@density/(2*at)
        norm=lambda field:np.sqrt(np.sum(modes.weights[modes.inband]*abs(field)**2))
        local.append(dict(a=at,lapse_replacement=norm(metric-pred)/norm(metric),velocity_derivative_stencil=norm(actual-approx)/norm(actual),
                          common_cdm_euler_discrepancy=norm(actual[0]-metric)/norm(metric)))
        groups=source_parts(modes,bg,density,actual,metric,at,135)
        if slot in (0,32,64):
            refine=source_parts(modes,bg,density,actual,metric,at,144)
            errs=[modes.norm(small-big)/max(modes.norm(big),1e-50) for small,big in zip(groups,refine)]
            assert max(errs)<2e-5
            ident.append(dict(a=at,poisson=errs[0],metric_correction=errs[1],species_force_correction=errs[2]))
            del refine
        mapped=np.einsum("ki,kij->kj",row,greens[slot])
        response.append([readout(group,mapped,shell,matrix) for group in groups])
        if slot%16==0: print("material",model,slot,flush=True)
    response=np.array(response);result=[]
    for start in (0,16):
        count=32-start
        for panels in (count,count//2,count//4):
            value=np.einsum("s,sjk->jk",boole(bg.times[start*2],bg.times[-1],panels,count),response[start:])
            for group,key in enumerate(("nonzero-all","common-screen")):
                for idx,cut in enumerate(cuts):
                    vals=value[:,group*len(cuts)+idx]
                    result.append(dict(cut_kpc=cut,output=key,a_start=bg.times[2*start],panels=panels,
                        matter_only_pp=vals[0],linear_lapse_correction_pp=vals[1],effective_accel_correction_pp=vals[2],
                        with_native_lapse_pp=vals[:2].sum(),with_effective_force_pp=vals.sum()))
    table("material-"+model+".csv",result);table("material-grid-"+model+".csv",ident);table("force-check-"+model+".csv",local)


if __name__=="__main__":
    for model in sys.argv[1:] or ("cold","heavy"):run(model)
