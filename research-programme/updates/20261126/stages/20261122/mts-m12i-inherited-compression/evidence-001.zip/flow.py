from inputs import *
from kinematic import push


def get_inputs():
    modes=old.Modes()
    with np.load(pinned("material-window.npz")) as data:
        counts=data["counts"]
        windows=100*(counts.cumsum()/counts.sum())[:,None]*(data["basis"]-data["basis"][-1])
        cuts=data["cuts"]
    return modes,windows,cuts


def setup(model,modes):
    bg=old.Background(model)
    late=old.green(bg,modes)[0]
    with np.load(HERE/f"history-{model}.npz") as data:
        bg.times=data["epochs"];bg.nodes=data["k"];bg.fields=data["full"]
    early=old.green(bg,modes)
    ns=len(bg.species)
    select=np.zeros(2*ns);select[-ns-1]=1;select[0]=-1
    row=select@late-select
    shell=modes.inv if bg.mass else np.zeros(len(modes.k2),int)
    return bg,early,row,shell


def screens(modes):
    coupled=old.Background("heavy")
    times=np.geomspace(.003,.05,1025)
    scale=max(float(np.max(times*old.Background(model).hub(times))) for model in ("cold","heavy"))
    mass=coupled.mass
    def pick(k):
        ratio=k/(times[0]*mass)
        return (k>scale/np.sqrt(2e-5)) & ((ratio/(np.sqrt(1+ratio**2)+1))**2<2e-5)
    return pick(modes.k),pick(np.sqrt(modes.k2))


def matrices(windows,modes,mask):
    return np.concatenate((windows.conj()*modes.weights,windows.conj()*(mask*modes.weights)))


def readout(state,row,shell,window):
    mixed=np.zeros(state.shape[-1],complex)
    for index,field in enumerate(state):
        mixed+=row[shell,index]*field
    return (window@mixed).real


def boole(start,end,panels,count):
    assert panels%4==0 and count%panels==0 and count>0
    weights=np.zeros(count+1)
    step=count//panels
    for left in range(0,count,4*step):
        weights[left:left+4*step+1:step]+=np.array([7,32,12,32,7])*2*np.log(end/start)/(45*panels)
    return weights


def run(model,inputs):
    guard()
    modes,windows,cuts=get_inputs()
    ingate,outgate=screens(modes)
    bg,greens,row,shell=setup(model,modes)
    window=matrices(windows,modes,outgate)
    tag=f"{model}-{inputs}"
    ns=len(bg.species)
    active=ingate if inputs=="screened" else np.ones(len(modes.k),bool)
    assert inputs in ("screened","all")
    times=bg.times
    weights=boole(times[0],times[-1],64,64)
    accum=np.zeros((2*ns,len(modes.k2)),complex)
    response=[];checks=[];kin={}
    for slot,at in enumerate(times):
        guard()
        dens,theta=bg.fields_at(modes,slot)
        dens[:,~active]=0;theta[:,~active]=0
        src=np.empty_like(accum)
        pieces=[]
        for idx,label in enumerate(bg.species):
            mass=bg.mass if label=="wave" else 0
            flux,adv,press,_=old.source_terms(modes,135,dens[idx],theta[idx],at,mass)
            if slot in (0,32,64):
                refine=old.source_terms(modes,144,dens[idx],theta[idx],at,mass)
                errs=[modes.norm(one-two)/max(modes.norm(two),1e-50) for one,two in zip((flux,adv,press),refine)]
                assert max(errs)<2e-5
                checks.append(dict(a=at,species=label,continuity=errs[0],euler=errs[1],pressure=errs[2]))
                state=push(modes,dens[idx],theta[idx])
                pieces.append((state[0],-at*state[1]/bg.B))
            src[idx]=flux/(at*bg.hub(at))
            src[ns+idx]=-(adv+press)/(bg.B*bg.hub(at))
        if pieces:
            pushed=old.apply_green(greens[slot],np.stack([piece[0] for piece in pieces]+[piece[1] for piece in pieces]),modes)
            kin[slot]=pushed
        moved=old.apply_green(greens[slot],src,modes)
        accum+=weights[slot]*moved
        response.append(readout(moved,row,shell,window))
        if slot%16==0: print(tag,slot,flush=True)
    assert not np.any(accum[:,0])
    z99=accum+kin[0]-kin[64]
    assert not np.any(z99[:,0]) and np.isfinite(z99).all()
    per_epoch=np.array(response)
    kinetic={slot:readout(state,row,shell,window) for slot,state in kin.items()}
    results=[]
    for start in (0,32):
        count=64-start
        for panels in (count,count//2,count//4):
            ret=boole(times[start],times[-1],panels,count)@per_epoch[start:]
            dyn=ret+kinetic[start]-kinetic[64]
            if start==0 and panels==count:
                np.testing.assert_allclose(readout(z99,row,shell,window),dyn,rtol=1e-10,atol=1e-13)
            for group,mask in enumerate(("nonzero-all","common-screen")):
                for index,cut in enumerate(cuts):
                    pos=index+len(cuts)*group
                    results.append(dict(model=model,input=inputs,output=mask,cut_kpc=cut,a_start=times[start],panels=panels,
                         retarded_pp=ret[pos],early_coordinate_carried_pp=kinetic[start][pos],
                         subtract_z99_coordinate_pp=-kinetic[64][pos],compression_drift_pp=dyn[pos]))
    table("contribution-"+tag+".csv",results)
    table("grid-comparison-"+tag+".csv",checks)
    packet("compression-"+tag+".npz",density=z99[:ns],scaled_divergence=z99[ns:],B=bg.B,epochs=times,projected_integrand_pp=per_epoch,
           cut_kpc=cuts,inmask=active,outmask=outgate,kin_start_pp=kinetic[0],kin_middle_pp=kinetic[32],kin_z99_pp=kinetic[64])
    print(tag,"done",flush=True)


if __name__=="__main__":
    for model in ("cold","heavy"):
        for inputs in ("all","screened"):
            if not sys.argv[1:] or sys.argv[1:]==[model,inputs]:run(model,inputs)
