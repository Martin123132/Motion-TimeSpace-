from flow import *
from readout import embed


def run(model,mask_name):
    modes,window,cuts=get_inputs()
    ingate,outgate=screens(modes)
    if mask_name=="all":
        ingate=np.ones(len(modes.k),bool);outgate=modes.k2>0
    beta=window*outgate*modes.weights
    bg=old.Background(model)
    prop=old.green(bg,modes)
    ns=len(bg.species)
    select=np.zeros(2*ns);select[ns-1]=1;select[0]=-1
    shell=modes.inv if bg.mass else np.zeros(len(modes.k2),int)
    with np.load(pinned("material-window.npz")) as archive: host=archive["basis"][-1]
    scalars=[];end={};launch=0
    for slot in range(0,65,4):
        guard()
        at=bg.times[slot]
        dens,theta=bg.fields_at(modes,slot);dens[:,~ingate]=0;theta[:,~ingate]=0
        matrix=(select@prop[slot])
        mix=np.zeros(len(modes.k2),complex)
        for idx,label in enumerate(bg.species):
            flux,adv,press,_=old.source_terms(modes,135,dens[idx],theta[idx],at,bg.mass if label=="wave" else 0.)
            mix+=matrix[shell,idx]*flux/(at*bg.hub(at))-matrix[shell,ns+idx]*(adv+press)/(bg.hub(at)*bg.B)
            if slot==0:
                mass,vdiv,_,_=push(modes,dens[idx],theta[idx])
                launch+=((matrix[shell,idx]-select[idx])*mass-matrix[shell,ns+idx]*at*vdiv/bg.B)
        scalars.append((beta.conj()@mix).real)
        if slot in (0,64):
            slip=dens[-1]-dens[0];linear=embed(modes,slip)
            slope=(window.conj()@(modes.weights*linear)).real
            host_mean=np.sum(host.conj()*modes.weights*linear).real
            geom=np.zeros(len(modes.k2),complex)
            spatial=modes.real(slip,135)
            for axis,out in zip(modes.vec,modes.outvec):
                disp=modes.real(1j*axis*dens[0]/modes.k**2,135)
                geom+=1j*out*modes.spec(spatial*disp)
            end[slot]=slope*(1-host_mean)+(beta.conj()@geom).real
    coordinate=(beta.conj()@launch).real
    rows=[]
    for panels in (16,8,4):
        particular=boole(.01,.05,panels,16)@scalars
        original=end[64]-end[0]+coordinate+particular
        for idx,cut in enumerate(cuts):
            rows.append(dict(model=model,band=mask_name,cut_kpc=cut,panels=panels,ratio_and_geometry_pp=end[64][idx]-end[0][idx],
                        launch_coordinates_pp=coordinate[idx],generated_late_pp=particular[idx],before_earlier_compression_pp=original[idx]))
    table(f"late-control-{model}-{mask_name}.csv",rows)


if __name__=="__main__":
    for model in ("cold","heavy"):
        for name in ("all","screened"):run(model,name)
