from inputs import *
from seeds import SPEC,NATIVE,source,checked,obj,Seed
import radiation_switch as engine


def run(model):
    guard()
    seed=Seed(model,"anchorA","heavy")
    status=obj(source(f"runs/{model}/status.json"))
    for path in engine.inherited.native_hashes():
        checked(path,status["input_hashes"][str(path)])
    bgpath=SPEC/"runs/projection/a225-w6-d8.npz" if model=="heavy" else NATIVE/"runs/backgrounds/cold.npz"
    params=engine.inherited.params_for(checked(bgpath,status["source_hash"]),background_boost=8.)
    assert params.DoLateRadTruncation
    params.DoLateRadTruncation=False
    background=engine.camb.get_background(params)
    background.Params.Accuracy.IntTolBoost=6
    with np.load(old.parent("hierarchy-"+model+".npz")) as archive:
        old_times,old_k,old_names,stored=[archive[key] for key in ("epochs","k","names","values")]
    at=np.geomspace(.003,.01,65)
    epochs=np.unique(np.r_[old_times,at])
    tau=background.conformal_time(1/epochs-1,tol=1e-10)
    names=engine.camb.model.evolve_names
    assert names==old_names.tolist() and np.array_equal(old_k,seed.k)
    select=np.where((epochs>=.003)&(epochs<=.01))[0]
    assert np.array_equal(epochs[select],at)
    blocks=[]; nodes=[]
    for path in sorted((SPEC/"runs"/model).glob("chunk-*.npz")):
        with np.load(source(path.relative_to(SPEC).as_posix())) as saved:
            ks=saved["modes"]
        active=ks[np.isin(ks,seed.k)]
        if not len(active): continue
        guard()
        batch=np.unique(np.r_[active,ks.max()])
        raw=background.get_time_evolution(batch,tau,vars=names,lAccuracyBoost=4)
        blocks.extend(raw[np.searchsorted(batch,active)][:,select])
        nodes.extend(active)
    order=np.argsort(nodes)
    assert np.array_equal(np.array(nodes)[order],seed.k)
    values=np.array(blocks)[order]
    assert np.isfinite(values).all()
    errors=[]
    for name in ("delta_cdm","delta_baryon","etak","v_newtonian_cdm","v_newtonian_baryon","Weyl")+(("mts_drho_h","mts_q_h","mts_dp_h") if model=="heavy" else ()):
        ix=names.index(name)
        for slot in (0,64):
            ref=stored[:,np.where(old_times==at[slot])[0].item(),ix]
            errors.append(dict(a=at[slot],column=name,relative_l2=np.linalg.norm(values[:,slot,ix]-ref)/np.linalg.norm(ref)))
    assert max(row["relative_l2"] for row in errors)<2e-5,errors
    col=lambda name:values[:,:,names.index(name)]
    scale,expansion=col("a"),col("H")
    assert np.max(abs(scale/at-1))<2e-5 and np.max(abs(expansion/(at*seed.H(at))-1))<2e-5
    wave=seed.k[:,None]
    alpha=-expansion*col("v_newtonian_cdm")/wave**2
    curvature=col("etak")/wave
    psi2=2*col("Weyl")-wave**2*(curvature-expansion*alpha)
    pairs=[(col("delta_cdm")-3*curvature,wave**2*alpha),(col("delta_baryon")-3*curvature,-expansion*col("v_newtonian_baryon"))]
    if model=="heavy":
        assert np.all(col("mts_averaged_chart")==1)
        mean=seed.coeff["wave"]/scale
        pairs.append((col("mts_drho_h")/mean-3*curvature,wave*(col("mts_q_h")/mean+wave*alpha)))
    fields=np.stack([np.stack([dens,velocity*at]) for dens,velocity in pairs])
    fractions=background.get_background_densities(at,vars=["photon","neutrino","nu"])
    table(f"endpoint-{model}.csv",errors)
    packet(f"history-{model}.npz",k=seed.k,epochs=at,full=fields,k2psi=psi2,photon=fractions["photon"],neutrino=fractions["neutrino"],nu=fractions["nu"],
           names=names,values=values,species=list(seed.fields))
    print(model,len(nodes),len(at),max(row["relative_l2"] for row in errors),flush=True)


if __name__=="__main__":
    for model in sys.argv[1:] or ("cold","heavy"): run(model)
