from flow import *


def rows(file,**match):
    with file.open(encoding="utf-8") as stream: data=list(csv.DictReader(stream))
    for key,val in match.items(): data=[r for r in data if r[key]==str(val)]
    return data


def one(data,cut):
    chosen=[r for r in data if float(r["cut_kpc"])==cut]
    assert len(chosen)==1
    return chosen[0]


def run():
    modes,windows,cuts=get_inputs()
    ingate,outgate=screens(modes)
    end={}
    totals=[];split=[];comparisons=[];bounds=[]
    for model in ("cold","heavy"):
        original=rows(pinned("kinematic-material-drift.csv"),model=model)
        early={}
        for start in (.003,np.sqrt(.003*.01)):
            pieces={}
            for ins in ("all","screened"):
                for outs in ("nonzero-all","common-screen"):
                    full=rows(HERE/f"contribution-{model}-{ins}.csv",output=outs)
                    sel=[r for r in full if abs(float(r["a_start"])/start-1)<1e-12]
                    top=max(int(r["panels"]) for r in sel)
                    for cut in cuts[:-1]:
                        peak=one([r for r in sel if int(r["panels"])==top],cut)
                        med=one([r for r in sel if int(r["panels"])==top//2],cut)
                        key="compression_drift_pp"
                        pieces[(cut,ins,outs)]=float(peak[key])
                        comparisons.append(dict(model=model,cut_kpc=cut,a_start=start,test=f"time-{ins}-{outs}",
                            first_pp=float(peak[key]),alternate_pp=float(med[key]),difference_pp=float(med[key])-float(peak[key])))
            for cut in cuts[:-1]:
                a=pieces[(cut,"all","nonzero-all")]
                b=pieces[(cut,"all","common-screen")]
                c=pieces[(cut,"screened","common-screen")]
                split.append(dict(model=model,cut_kpc=cut,a_start=start,all_pp=a,input_pair_exclusion_at_fixed_output_pp=b-c,
                          output_exclusion_with_full_input_pp=a-b,common_screen_pp=c))
            early[start]=pieces
        for cut in cuts[:-1]:
            middle=max(early)
            for ins,outs in (("all","nonzero-all"),("screened","common-screen")):
                selection=rows(HERE/f"late-control-{model}-{ins}.csv")
                late=one([r for r in selection if r["panels"]=="16"],cut)
                check=one([r for r in selection if r["panels"]=="8"],cut)
                raw=float(late["before_earlier_compression_pp"])
                if ins=="all":
                    archived=float(one(original,cut)["conditional_drift_with_transport_pp"])
                    comparisons.append(dict(model=model,cut_kpc=cut,a_start=.01,test="reproduce-late",first_pp=archived,alternate_pp=raw,difference_pp=raw-archived))
                else: archived=raw
                correction=early[.003][(cut,ins,outs)]
                total=archived+correction
                totals.append(dict(model=model,cut_kpc=cut,selection=ins,late_reference_pp=archived,
                           earlier_dynamic_pp=correction,contribution_only_since_midpoint_pp=early[middle][(cut,ins,outs)],
                           conditional_updated_drift_pp=total,finer_late_vs_coarser_pp=raw-float(check["before_earlier_compression_pp"])))
                prim=one(rows(HERE/f"adiabatic-mode-{model}.csv",selection="common-screen" if ins=="screened" else "all-native-covered"),cut)
                gain=one(rows(HERE/f"unknown-input-gains-{model}.csv",output=outs,panels=64),cut)
                bounds.append(dict(model=model,cut_kpc=cut,selection=ins,
                        least_remaining_incoming_rms=abs(total)/float(gain["incoming_pp_per_joint_rms"]),
                        least_variable_common_lapse_density_equiv_rms=abs(total)/float(gain["variable_pp_per_space_time_rms"]) if model=="heavy" else None,
                        least_growing_adiabatic_R2_rms=abs(total)/float(prim["adiabatic_pp_per_primordial_box_rms"]),
                        phase_locked_b_for_cancellation=-total/float(prim["native_pp_per_b"]),
                        abs_effect_for_external_scale_example_pp=float(prim["scale_independent_example_abs_effect_pp"])))
            for key in ("common-screen","nonzero-all"):
                eul=early[.003][(cut,"screened",key)]
                for panels in (16,32):
                    lag=one(rows(HERE/f"material-{model}.csv",output=key,a_start=.003,panels=panels),cut)
                    for col in ("matter_only_pp","with_native_lapse_pp","with_effective_force_pp"):
                        val=float(lag[col])
                        comparisons.append(dict(model=model,cut_kpc=cut,a_start=.003,test=f"Euler-vs-{col}-{key}-{panels}",first_pp=eul,alternate_pp=val,difference_pp=val-eul))
    table("updated-drift.csv",totals);table("scale-attribution.csv",split);table("response-comparisons.csv",comparisons);table("sign-thresholds.csv",bounds)
    record("coverage.json",dict(input_complex_count=len(modes.k),screened_input_complex_count=int(ingate.sum()),nonzero_output_complex_count=len(modes.k2)-1,
           screened_output_complex_count=int(outgate.sum()),screened_k_min=float(np.sqrt(modes.k2[outgate]).min()),screened_k_max=float(np.sqrt(modes.k2[outgate]).max()),
           first_epoch=.003,z_first=1/.003-1,last_early_epoch=.01,last_late_epoch=.05,screen_tolerance=2e-5))


if __name__=="__main__":run()
