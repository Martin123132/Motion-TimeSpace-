from flow import *
from scipy.interpolate import PchipInterpolator


def run(model):
    modes,windows,cuts=get_inputs()
    ingate,outgate=screens(modes)
    bg,greens,row,shell=setup(model,modes)
    start_columns=bg.fields[:,:,:,0]
    late=old.Background(model)
    wave=np.sqrt(modes.k2)
    eligible=(wave>=bg.nodes.min()) & (wave<=bg.nodes.max())
    def interp(field):
        return PchipInterpolator(np.log(bg.nodes),field,axis=-1,extrapolate=False)(np.log(wave[eligible]))
    native0=interp(late.fields[:,0,:,0])
    nativef=interp(late.fields[:,0,:,-1])
    transfer=(nativef[-1]-nativef[0])-(native0[-1]-native0[0])
    early=interp(start_columns)
    initial=np.concatenate((early[:,0],-early[:,1]/bg.B))
    slope=np.einsum("ki,kij->kj",row,greens[0])
    approx=np.einsum("ki,ik->k",slope[shell[eligible]],initial)
    kernel=windows[:,eligible].conj()*modes.weights[eligible]
    result=[]
    for tag,active,output in (("all-native-covered",np.ones(len(modes.k),bool),eligible),("common-screen",ingate,outgate&eligible)):
        real=modes.real(modes.R*active,135)
        fluct=real**2-np.mean(real**2)
        pattern=modes.spec(fluct)
        ref=modes.real(modes.R*active,144)**2
        check=modes.spec(ref-np.mean(ref))
        assert modes.norm(pattern-check)/modes.norm(pattern)<2e-5
        inc=output[eligible]
        local=pattern[eligible]*inc
        response=(kernel@(transfer*local)).real
        alternate=(kernel@(approx*local)).real
        missing_weight=modes.norm(pattern,(modes.k2>0)&~eligible)/modes.norm(pattern)
        for idx,cut in enumerate(cuts[:-1]):
            weights=modes.weights[eligible]*abs(windows[idx,eligible])**2
            gain=np.sqrt(np.sum(weights*(transfer*inc)**2))
            loss=np.sqrt(np.sum(weights*((transfer-approx)*inc)**2))/gain
            result.append(dict(model=model,selection=tag,cut_kpc=cut,native_pp_per_b=response[idx],reduced_pp_per_b=alternate[idx],
                       adiabatic_pp_per_primordial_box_rms=gain,reduced_native_dual_relative=loss,
                       primordial_R1_rms=np.sqrt(np.mean(real**2)),covered_template_R2_rms=modes.norm(pattern,output),
                       frac_template_norm_outside_native_k=missing_weight,
                       scale_independent_example_abs_effect_pp=abs(response[idx])*.6*11.1))
    table(f"adiabatic-mode-{model}.csv",result)


if __name__=="__main__":
    for model in ("cold","heavy"):run(model)
