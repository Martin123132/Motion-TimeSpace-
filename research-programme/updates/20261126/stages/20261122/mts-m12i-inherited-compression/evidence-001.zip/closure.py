from compare import *


def run():
    results=[]
    for model in ("cold","heavy"):
        matter=rows(HERE/f"material-{model}.csv")
        corrections=rows(HERE/f"chart-correction-{model}.csv")
        euler=rows(HERE/f"contribution-{model}-screened.csv")
        for phase in corrections:
            cut=float(phase["cut_kpc"])
            if cut>200:continue
            matches=lambda r: all(r[key]==phase[key] for key in ("cut_kpc","a_start","output"))
            independent,=[r for r in matter if matches(r) and r["panels"]==phase["panels"]]
            baseline=max((r for r in euler if matches(r)),key=lambda r:int(r["panels"]))
            pre=float(independent["with_effective_force_pp"])
            repaired=pre+float(phase["total_chart_correction_pp"])
            original=float(baseline["compression_drift_pp"])
            err=(repaired-original)/original
            results.append(dict(model=model,cut_kpc=cut,a_start=phase["a_start"],output=phase["output"],material_panels=phase["panels"],
                   eulerian_reference_pp=original,before_pp=pre,after_pp=repaired,before_rel=(pre-original)/original,after_rel=err,
                   within_0p005=abs(err)<.005,within_2e_minus_5=abs(err)<2e-5))
    table("corrected-independent-closure.csv",results)


if __name__=="__main__":run()
