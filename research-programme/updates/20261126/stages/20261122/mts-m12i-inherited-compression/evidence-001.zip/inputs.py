import csv
import hashlib
import io
import json
import os
import sys
from pathlib import Path

for key in ("OPENBLAS_NUM_THREADS","OMP_NUM_THREADS","MKL_NUM_THREADS","BLIS_NUM_THREADS","NUMEXPR_NUM_THREADS"):
    os.environ[key]="1"
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
BASE=HERE.parent/"mts-m12i-quadratic-z19-20261122"
def digest(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream,"sha256").hexdigest()
assert digest(BASE/"seal.json")=="bf75f8ae6810757f901b0204cbcaf0897edb39b31175fad333bf29a23eba3c7b"
manifest=json.loads((BASE/"seal.json").read_bytes())["files"]
def pinned(name):
    path=BASE/name
    assert digest(path)==manifest[name],name
    return path
for name in ("common.py","readout.py","kinematic.py"):
    pinned(name)
sys.path.insert(0,str(BASE))
import common as old
from common import np
def guard():
    assert __debug__ and not (HERE/"STOP-REQUESTED").exists()
    old.guard()
def put(name,data):
    guard()
    path=HERE/name
    if path.exists():
        assert path.read_bytes()==data, path
    else:
        with path.open("xb") as stream: stream.write(data)
def packet(name,**fields):
    target=io.BytesIO()
    np.savez_compressed(target,**fields)
    put(name,target.getvalue())
def table(name,rows):
    target=io.StringIO()
    writer=csv.DictWriter(target,rows[0],lineterminator="\n")
    writer.writeheader();writer.writerows(rows);put(name,target.getvalue().encode())
def record(name,doc):
    put(name,(json.dumps(doc,allow_nan=False,sort_keys=True,indent=2)+"\n").encode())
