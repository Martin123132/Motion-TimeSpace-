from material import *


def residuals(modes,density,theta,slip,force_change,size=135):
    real=lambda field:modes.real(field,size)
    number=-real(density)*real(slip)
    velocity=np.zeros_like(number)
    force=np.zeros_like(number)
    with_force=np.any(force_change)
    for idx,axis in enumerate(modes.vec):
        delta_shift=real(1j*axis*slip/modes.k**2)
        shift=real(1j*axis*density/modes.k**2)
        number+=delta_shift*real(1j*axis*density)+shift*real(1j*axis*slip)
        velocity+=delta_shift*real(1j*axis*theta)
        if with_force:force+=shift*real(1j*axis*force_change)
        for jdx in range(idx,3):
            proj=axis*modes.vec[jdx]/modes.k**2
            mult=1 if idx==jdx else 2
            left=real(proj*density);right=real(proj*slip)
            number-=mult*left*right
            velocity-=mult*right*real(proj*theta)
            if with_force:force-=mult*left*real(proj*force_change)
    fields=np.stack([modes.spec(arr) for arr in (number,velocity,force)])
    assert abs(fields[:,0]).max()<1e-12
    fields[:,0]=0
    return fields


def run(model):
    modes,windows,cuts=get_inputs()
    marked,output=screens(modes)
    bg,greens,row,shell=setup(model,modes)
    ns=len(bg.species)
    weights=matrices(windows,modes,output)
    clock=np.log(bg.times);hubs=bg.hub(bg.times)
    radial,index=np.unique(modes.k,return_inverse=True)
    ip=lambda field:PchipInterpolator(np.log(bg.nodes),field,axis=-2)(np.log(radial))
    fields=ip(bg.fields)
    force=time_derivative(fields[:,1],clock)*hubs
    before=ip(time_derivative(bg.fields[:,1],clock)*hubs)
    dnumber=time_derivative(fields[:,0],clock)+fields[:,1]/(bg.times**2*hubs)
    rough=time_derivative(fields[:,0],clock,7)+fields[:,1]/(bg.times**2*hubs)
    scale=fields[:,1]/(bg.times**2*hubs)
    stress=np.zeros_like(dnumber)
    if model=="heavy":
        with np.load(HERE/"history-heavy.npz") as bank:
            labels=bank["names"].tolist();values=bank["values"]
            pressure=values[:,:,labels.index("mts_dp_h")]*values[:,:,labels.index("a")]/bg.coeff[-1]
            stress[-1]=ip(-3*pressure)
    spectrum=modes.R*marked
    project=lambda field:field[index]*spectrum
    source_series=[];slips=[]
    for slot in range(0,65,2):
        guard()
        at=bg.times[slot]
        density,theta=bg.fields_at(modes,slot)
        density*=marked;theta*=marked
        dual=(row[:,None,:]@greens[slot])[:,0]
        current=np.zeros((3,len(windows)*2))
        for idx in range(ns):
            additional=project(force[idx,:,slot]-before[idx,:,slot])
            for tag,slip in (("total",dnumber[idx,:,slot]),("native-pressure",stress[idx,:,slot])):
                if tag=="native-pressure" and not np.any(slip):continue
                number,vel,correction=residuals(modes,density[idx],theta[idx],project(slip),additional if tag=="total" else np.zeros_like(additional))
                mix=dual[shell,idx]*number-dual[shell,ns+idx]*(at/bg.B)*vel
                current[0 if tag=="total" else 1]+=(weights@mix).real
                if tag=="total":current[2]-=(weights@(dual[shell,ns+idx]*correction/(bg.B*hubs[slot]))).real
            norm=lambda f:np.linalg.norm(np.sqrt(modes.weights[modes.inband])*project(f))
            slips.append(dict(model=model,species=bg.species[idx],a=at,relative_continuity_slip=norm(dnumber[idx,:,slot])/norm(scale[idx,:,slot]),
                         relative_supplied_pressure=norm(stress[idx,:,slot])/norm(scale[idx,:,slot]),
                         relative_7_vs_5_stencil=norm(rough[idx,:,slot]-dnumber[idx,:,slot])/norm(scale[idx,:,slot])))
        source_series.append(current)
        if slot%16==0:print("slip",model,slot,flush=True)
    series=np.array(source_series)
    results=[]
    for start in (0,16):
        steps=32-start
        for panels in (steps,steps//2,steps//4):
            vals=np.einsum("s,sijk->ijk",boole(bg.times[2*start],.01,panels,steps),series[start:,:,:,None])[:,:,0]
            for idx,cut in enumerate(np.tile(cuts,2)):
                results.append(dict(a_start=bg.times[2*start],panels=panels,output="nonzero-all" if idx<len(cuts) else "common-screen",
                      cut_kpc=cut,coordinate_slip_pp=vals[0,idx],native_wave_pressure_in_slip_pp=vals[1,idx],
                      residual_beyond_wave_pressure_pp=vals[0,idx]-vals[1,idx],force_interpolation_commutator_pp=vals[2,idx],
                      total_chart_correction_pp=vals[0,idx]+vals[2,idx]))
    table(f"chart-correction-{model}.csv",results);table(f"measured-slip-{model}.csv",slips)


if __name__=="__main__":
    for model in sys.argv[1:] or ("cold","heavy"):run(model)
