from recover import HERE, XY, ZZ, VECTOR, check, packet, record, parent, np
from scipy.fft import rfftn
def ratio(words):
    pair=words.astype(float).reshape(-1,2)/2**32
    u=1.-pair[:,0];v=(pair[:,1]-.5)*1.7156
    x=u-.449871;y=abs(v)+.386595
    quad=x*x+y*(.196*y-.25472*x)
    ok=(quad<.27597)|((quad<=.27846)&(v*v<=-4*u*u*np.log(u)))
    return (v/u)[ok]
def noise(seed):
    rng=np.random.RandomState(seed);needed=256**3;values=np.empty(needed);start=0
    while start<needed:
        check()
        generated=ratio(rng.randint(0,2**32,size=524288,dtype=np.uint32))
        count=min(needed-start,len(generated));values[start:start+count]=generated[:count];start+=count
    return values
def run():
    assert np.random.RandomState(5489).randint(0,2**32,3,dtype=np.uint32).tolist()==[3499211612,581869302,3890346734]
    rng=np.random.RandomState(95064);reference=[]
    import math
    while len(reference)<300:
        u=1.-int(rng.randint(0,2**32,dtype=np.uint32))/2**32
        v=(int(rng.randint(0,2**32,dtype=np.uint32))/2**32-.5)*1.7156
        x=u-.449871;y=abs(v)+.386595;quad=x*x+y*(.196*y-.25472*x)
        if quad<.27597 or (quad<=.27846 and v*v<=-4*u*u*math.log(u)):reference.append(v/u)
    values=noise(95064);assert np.array_equal(reference,values[:len(reference)])
    mu=float(values.mean());rms=float(values.std());values-=mu
    native=rfftn(values.reshape(256,256,256),workers=1)/np.sqrt(len(values));del values
    native=native[np.ix_(XY%256,XY%256,ZZ)]
    shift=np.array([-16,11,-13])/128;phase=sum(vec*(delta+.5/256) for vec,delta in zip(VECTOR,shift))
    wave=native*np.exp(-2j*np.pi*phase)
    packet('seed-realization.npz',whitened=wave,unshifted=native*np.exp(-1j*np.pi*sum(VECTOR)/256))
    record('seed-control.json',dict(seed=95064,mean_before_subtraction=mu,std=rms,scalar_values_checked=len(reference),
        historical_commit='9bb9f8194966d2cded3322f6f0c45235dd673ee0',source_log=str(parent('music_job5252342.txt').name),total=256**3))
if __name__=='__main__':run()
