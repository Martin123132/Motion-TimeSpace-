from recover import *
from scipy.integrate import solve_ivp
def growing(at,ic):
    ini=1e-5
    def ode(loga,y):
        matter=ic.om/(ic.om+ic.ol*np.exp(3*loga));drag=2-1.5*matter
        linear,speed,second,rate=y
        return speed,1.5*matter*linear-drag*speed,rate,1.5*matter*(second-linear**2)-drag*rate
    sol=solve_ivp(ode,(np.log(ini),np.log(max(at))),[ini,ini,-3/7*ini**2,-6/7*ini**2],t_eval=np.log(at),method='DOP853',rtol=1e-12,atol=1e-22)
    assert sol.success
    return sol.y
def run():
    ic=Initial();box=ic.box/(1000*ic.h)
    rows=[];all_ids=[]
    for piece in range(4):
        name=f'early-001-{piece}';at=json.loads(parent(name+'.json').read_bytes())['scale']
        with np.load(parent(name+'.npz')) as saved:ids,pos,vel=(saved[key] for key in ('ids','pos','vel'))
        assert np.all((ids>=ic.starts[1])&(ids<ic.starts[2])) and np.array_equal(ic.ids[ids],ids)
        all_ids.append(ids);grid=8192
        birth=ic.pos[ids].astype(float)/ic.box;unitv=ic.vel[ids].astype(float)*np.sqrt(ic.a)*1000/(ic.box*VFACT)
        q=(np.rint((birth-unitv)*grid-.5)+.5)/grid
        second=unitv-(birth-q);first=(birth-q)-second
        linear,lspeed,quadratic,qspeed=growing([ic.a,at],ic);hub=ic.h*100*np.sqrt(ic.om/at**3+ic.ol)
        assert max(abs(qspeed/(2*quadratic)-lspeed/linear))<1e-4
        for model,disp,rate in [
          ('velocity_as_linear',birth+(linear[1]/linear[0]-1)*unitv,lspeed[1]/linear[0]*unitv),
          ('first_only',q+linear[1]/linear[0]*first,lspeed[1]/linear[0]*first),
          ('first_plus_second',q+linear[1]/linear[0]*first+quadratic[1]/quadratic[0]*second,lspeed[1]/linear[0]*first+qspeed[1]/quadratic[0]*second)]:
            gap=pos.astype(float)/ic.box-disp;dr=box*(gap-np.rint(gap));dv=vel.astype(float)*np.sqrt(at)-box*at*hub*rate
            rms=lambda arr:np.sqrt(np.mean(np.sum(arr**2,axis=1)))
            rows.append(dict(piece=piece,model=model,particles=len(ids),scale=at,D1_growth=linear[1]/linear[0],D2_growth=quadratic[1]/quadratic[0],
                rms_comoving_kpc=1000*rms(dr),p90_comoving_kpc=1000*np.percentile(np.linalg.norm(dr,axis=1),90),rms_velocity_kms=rms(dv)))
    ids=np.concatenate(all_ids)
    assert np.unique(ids).size==len(ids)==137744
    with parent('early-lineage-motion.csv').open() as stream:
        reference=[row for row in csv.DictReader(stream) if row['set']=='fine sample']
    for idx,ref in enumerate(reference):assert abs(rows[3*idx]['rms_comoving_kpc']-1000*float(ref['rms_growing_residual_Mpc']))<.00001
    table('early-dynamics.csv',rows)
if __name__=='__main__':run()
