from recover import *
def run():
    def rows(name):
        with (HERE/name).open(newline='') as stream:return list(csv.DictReader(stream))
    counts=json.loads((HERE/'lattice.json').read_bytes());early=rows('early-dynamics.csv');modes=rows('independent-seed-comparison.csv')
    assert len(counts)==8 and sum(entry['particles'] for entry in counts)==146541875
    assert counts[0]['cell_id_sha256']==counts[1]['cell_id_sha256'] and max(max(entry['max_second_order_cells']) for entry in counts)<.5
    assert sum(entry['particles']*8**(13-entry['level']) for entry in counts if entry['part']!=0)==8192**3
    assert len(early)==12 and sum(int(entry['particles']) for entry in early if entry['model']=='first_plus_second')==137744
    for idx in range(4):
        old,first,both=early[3*idx:3*idx+3];assert int(both['piece'])==idx and float(both['rms_velocity_kms'])<float(old['rms_velocity_kms'])
        assert float(both['rms_comoving_kpc'])<float(old['rms_comoving_kpc'])<float(first['rms_comoving_kpc'])
    for cap in ('0.75','1.5','2.4'):
        band={row['method']:row for row in modes if row['target']=='seed' and row['upper']==cap and row['lower']=='0'}
        assert float(band['native']['corr'])>.99 and float(band['native']['relative_rms'])<float(band['old_density']['relative_rms'])
        assert float(band['native']['relative_rms'])<float(band['old_velocity']['relative_rms'])
        assert abs(float(band['incorrect_shift']['corr']))<.2
    with np.load(HERE/'prepared-modes.npz') as pkt:
        assert all(np.all(np.isfinite(pkt[key])) for key in pkt)
        key=np.column_stack([pkt[axis] for axis in ('nx','ny','nz')]);assert len(np.unique(key,axis=0))==len(key)
        assert np.where(key[:,2]==0,1,2).sum()==145346
        for method in ('native','cell','seed'):
            assert all(method+'_'+name in pkt for name in ('heavy_number','cold_number','phase','heavy_theta','curvature'))
        keys={(int(x),int(y)):i for i,(x,y,z) in enumerate(key) if z==0}
        for method in ('native','seed'):
            for quantity in ('phase','heavy_number'):
                vals=pkt[method+'_'+quantity]
                assert max(abs(vals[i]-vals[keys[-x,-y]].conj()) for (x,y),i in keys.items())<1e-12
    gates=rows('window-gates.csv');dec=json.loads((HERE/'decision.json').read_bytes())
    assert len(gates)==27 and dec['passes_loose']==sum(row['all_loose']=='True' for row in gates) and dec['passes_strict']==sum(row['all_strict']=='True' for row in gates)
    paths=sorted(file for file in HERE.iterdir() if file.is_file() and file.name!='seal.json')
    assert not any(item.is_dir() for item in HERE.iterdir())
    record('seal.json',dict(parent_seal=digest(OLD/'seal.json'),initial_file=seal['cache']['raw-cache/ic_agora_m12i_ref13_rad4-chull.ics'],files={p.name:digest(p) for p in paths}))
    print('Verified',len(paths),'products; seal',digest(HERE/'seal.json'))
if __name__=='__main__':run()
