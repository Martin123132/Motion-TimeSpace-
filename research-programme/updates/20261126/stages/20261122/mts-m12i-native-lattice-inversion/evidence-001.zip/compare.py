from recover import *
from scipy.interpolate import PchipInterpolator
from local_io import pin,SEED
for item in ('music_power.py','trace.py','power-normalization.json','census-check.json','conditional-occupation.csv','conditional-field-gates.csv','direct-fourier.npz','common-phase-conditional.npz'):parent(item)
from music_power import power
from trace import growth
pin(SEED,'seeds.py');sys.path.insert(0,str(SEED))
from seeds import bank
def run():
    with np.load(HERE/'native-modes.npz') as pkt:
        point,cell,measured,probes=(pkt[k] for k in ('point','cell','direct','probes'))
    ic=Initial();box=ic.box/1000/ic.h;hub=ic.h*100*np.sqrt(ic.om/ic.a**3+ic.ol);_,rate=growth(ic.a,ic.om)
    sphys=VFACT/(ic.a*hub*rate/ic.h)
    with np.load(parent('direct-fourier.npz')) as old:
        assert np.array_equal(old['integer_modes'],probes)
        orig=old['field'];d0,lin,second,transport,ed,ev,third,central=measured
        exactvel=-2j*np.pi*(probes.T*orig[1:]).sum(axis=0)/(box*ic.a*hub*rate)
        assert max(abs(ed-orig[0]))<1e-13 and max(abs(ev*sphys-exactvel))<1e-13
        assert np.linalg.norm(central-lin)/np.linalg.norm(lin)<2e-5
    probe_rows=[]
    for i,mode in enumerate(probes):
        norm=abs(ed[i]);split=ev[i]-ed[i];quad=second[i]+transport[i]
        orig_split=ev[i]*sphys-ed[i]
        probe_rows.append(dict(mode=str(mode.tolist()),density_real=ed[i].real,density_imag=ed[i].imag,
            density_momentum_split=abs(orig_split)/norm,speed_convention_abs_over_density=abs(ev[i]*(sphys-1))/norm,
            undeformed_over_density=abs(d0[i])/norm,second_displacement_over_density=abs(second[i])/norm,
            quadratic_advection_over_density=abs(transport[i])/norm,quadratic_over_density=abs(quad)/norm,
            after_quadratic_remaining_over_split=abs(split-(-d0[i]+quad))/abs(split),
            after_cubic_remaining_over_split=abs(split-(-d0[i]+quad+2*third[i]))/abs(split),
            euler_density_error_order2=abs(ed[i]-(d0[i]+lin[i]+quad))/norm))
    table('probe-decomposition.csv',probe_rows)
    heavy,cold,volume=[bank(name) for name in ('late-heavy','late-cold','volume-state')]
    use=(heavy['both_scale_screens_pass']==1)&(cold['both_scale_screens_pass']==1);kn=volume['k_Mpc_inverse'][use]
    with np.load(parent('common-phase-conditional.npz')) as old:
        axes=[old[n] for n in ('nx','ny','nz')];kw=old['k_Mpc'];prior={k:old[k] for k in ('density_curvature','momentum_curvature')}
    cells=(axes[0]%len(XY),axes[1]%len(XY),axes[2]);mult=np.where(axes[2]==0,1,2)
    assert np.sum(mult)==145346 and len(kn)==99 and kn[0]<=min(kw)<=max(kw)<=kn[-1]
    tf=lambda arr:PchipInterpolator(np.log(kn),arr[use])(np.log(kw))
    pk=power(kw);pk0=pk/box**3;window_unit=np.sqrt(2*np.pi**2*tf(volume['primordial_power'])/(kw**3*box**3))
    paired=tf(volume['cold_coordinate_number_contrast']);unit=np.sign(paired)*window_unit/np.sqrt(pk0)
    with np.load(HERE/'seed-realization.npz') as src:pred=src['whitened'][cells]*np.sqrt(pk0);wrong=src['unshifted'][cells]*np.sqrt(pk0)
    pts=point[cells];vol=cell[cells]
    fields=dict(seed=pred,native=pts,cell=vol,old_density=prior['density_curvature']/unit,old_velocity=prior['momentum_curvature']/unit)
    metric=[];windows=[];fo=dict(nx=axes[0],ny=axes[1],nz=axes[2],k_Mpc=kw,box_Mpc=box,a_music=ic.a,a_MTS=.01)
    hd=tf(volume['heavy_coordinate_number_contrast']);ph=tf(volume['heavy_spatial_phase']);local=tf(heavy['delta_cdm_N']-3*heavy['Phi'])
    div=(tf(heavy['theta_cdm_N'])-tf(heavy['heavy_theta_N']))/tf(heavy['H_conformal_Mpc_inverse'])
    theta=tf(heavy['heavy_theta_N']);mass=tf(heavy['test_mass_Mpc_inverse'])
    assert max(abs(theta+kw**2*ph/(.01*mass)))/max(abs(theta))<.005
    for name,value in fields.items():
        if name[:3]!='old':
            curv=value*unit;fo.update({name+'_'+k:curv*v for k,v in dict(curvature=1.,heavy_number=hd,phase=ph,heavy_theta=theta,cold_number=paired).items()})
    packet('prepared-modes.npz',**fo)
    for lower,upper in [(0,.75),(0,1.5),(0,2.4),(.75,1.5),(1.5,2.4)]:
        band=(kw>lower)&(kw<=upper)
        def dot(left,right):
            return np.sum(mult[band]*(left[band].conj()*right[band]).real)
        for name,value in dict(**fields,incorrect_shift=wrong,reversed_sign=-pred,one_cell_translation=pred*np.exp(-2j*np.pi*axes[0]/128)).items():
            for target,ref in [('seed',pred),('native',pts)]:
                metric.append(dict(lower=lower,upper=upper,method=name,target=target,modes=int(sum(mult[band])),
                    corr=dot(value,ref)/np.sqrt(dot(value,value)*dot(ref,ref)),norm_ratio=np.sqrt(dot(value,value)/dot(ref,ref)),
                    relative_rms=np.sqrt(dot(value-ref,value-ref)/dot(ref,ref))))
    table('independent-seed-comparison.csv',metric)
    counts=np.array(json.loads(parent('census-check.json').read_bytes())['counts'])
    frac=counts.cumsum()/counts.sum();grow=growth(.01,ic.om)[0]/growth(ic.a,ic.om)[0]
    dimvec=2*np.pi*np.array(axes)/box
    for grid in (128,192):
        for clock in ('birth','drift99'):
            zone=np.zeros((5,len(kw)),complex)
            for offset in (0,1):
                coeff=.5*np.exp(-1j*np.pi*offset*sum(axes)/grid)/np.prod([np.sinc(ax/grid)**2 for ax in axes],axis=0)
                with np.load(parent(f'raw-cache/window-{clock}-{grid}-{offset}.npz')) as src:
                    for j in range(5):zone[j]+=src[str(j)][cells]*coeff
            basis=(counts[:,None]*zone).cumsum(axis=0)/counts.cumsum()[:,None]
            for limit in (.75,1.5,2.4):
                choose=kw<=limit
                avg=lambda val:np.sum((basis[:,choose].conj()*val[choose]*mult[choose]).real,axis=1)
                for name,field in fields.items():
                    curv=field*unit;hdval=avg(curv*hd);ratio=hdval-avg(field*grow);loc=hdval-avg(curv*local);drift=avg(curv*div)
                    flow=[avg(1j*comp*curv*ph/(.01*mass)*299792.458) for comp in dimvec]
                    for cut in (0,1,2,4):
                        windows.append(dict(grid=grid,clock=clock,kmax=limit,cut=cut,method=name,heavy_delta=hdval[cut],
                            core_weight_change=frac[cut]*(ratio[cut]-ratio[-1]),relative_number=frac[cut]*(loc[cut]-loc[-1]),
                            relative_rate=frac[cut]*(drift[cut]-drift[-1]),vx=flow[0][cut],vy=flow[1][cut],vz=flow[2][cut]))
    table('paired-window-response.csv',windows)
    by={(r['grid'],r['clock'],r['kmax'],r['cut'],r['method']):r for r in windows}
    rel=lambda a,b:abs(a-b)/max(abs(a),abs(b),1e-100)
    gates=[]
    for cap in (.75,1.5,2.4):
        for cut in (0,1,2):
            for key in ('heavy_delta','core_weight_change','relative_rate'):
                val=lambda n,c,m:by[n,c,cap,cut,m][key]
                separate=rel(val(192,'drift99','native'),val(192,'drift99','seed'))
                quadrature=rel(val(192,'drift99','native'),val(192,'drift99','cell'))
                gr=max(rel(val(128,'drift99',m),val(192,'drift99',m)) for m in ('seed','native'))
                timing=max(rel(val(192,'birth',m),val(192,'drift99',m)) for m in ('seed','native'))
                maxerr=max(separate,quadrature,gr,timing)
                gates.append(dict(kmax=cap,cut=cut,quantity=key,native_vs_seed=separate,cell_sensitivity=quadrature,window_mesh=gr,drift_clock=timing,all_loose=maxerr<.005,all_strict=maxerr<2e-5))
    table('window-gates.csv',gates)
    with parent('matched-window-fields.csv').open() as stream:
        for row in csv.DictReader(stream):
            new=by[int(row['grid']),row['clock'],float(row['k_max']),int(row['cut']),'old_'+('velocity' if row['estimator']=='momentum' else 'density')]
            if row['grid']=='192':
                for a,b in [('heavy_delta','heavy_delta'),('core_weight_change','delta_fraction'),('relative_rate','same_metric_relative_rate_per_efold')]:assert abs(new[a]-float(row[b]))<1e-12
    record('decision.json',dict(sphys=sphys,compared_modes=int(sum(mult)),passes_loose=sum(bool(r['all_loose']) for r in gates),
        passes_strict=sum(bool(r['all_strict']) for r in gates),screened_observables=len(gates),galaxy_state_evolved=False,
        phases_from_seed_not_stream=True,published=False))
if __name__=='__main__':run()
