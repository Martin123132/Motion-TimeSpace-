import csv
import sys
from statistics import NormalDist
from field import HERE,np
from observe import anchors,observed,guard,table,release,load_segments,CONV
from orbit import ROT,SUN,VSUN


def rows(name):
    with (HERE/name).open() as stream:return list(csv.DictReader(stream))


def sky(pos,vel):
    sight=(pos-SUN)@ROT
    distance=np.linalg.norm(sight,axis=1)
    direction=sight/distance[:,None]
    east=np.stack((-direction[:,1],direction[:,0],0*distance),axis=1)
    east/=np.linalg.norm(east,axis=1)[:,None]
    north=np.cross(direction,east)
    speed=(vel/CONV-VSUN)@ROT
    transverse=speed-np.sum(speed*direction,axis=1)[:,None]*direction
    pm=np.stack([np.sum(speed*basis,axis=1) for basis in (east,north)],axis=1)/(4.74047*distance[:,None])
    assert np.allclose(np.linalg.norm(transverse,axis=1),np.linalg.norm(pm,axis=1)*4.74047*distance,atol=1e-10)
    scale=np.sum(direction*direction[0],axis=1);assert min(scale)>.95
    tang=np.stack([direction@axis for axis in (east[0],north[0])],axis=1)/scale[:,None]*180/np.pi
    rv=observed(pos,vel)[:,2]
    assert np.allclose(rv,(speed*direction).sum(axis=1),atol=1e-10)
    return {name:val[1:]-val[0] for name,val in [('tangent_deg',tang),('pm_mas_yr',pm),('distance_pc',1000*distance),('vlos_kms',rv)]}


def run(factor,mult):
    tag=f'{factor}-{mult}'
    stamps=rows(f'passages-{tag}.csv');frozen=rows('lag-frozen.csv')
    reference=rows(f'lag-test-{tag}.csv');out=[]
    final=tuple(arr[:1] for arr in anchors(22.05))
    for arm in ('reset','coupled'):
        guard();early,mid,last=load_segments(arm,factor,4,mult)
        calendar={row['flow']:float(row['passage_Myr']) for row in stamps if row['arm']==arm and row['count']=='1'}
        shift=next(float(row['lag_Myr']) for row in frozen if row['arm']==arm)
        ref=next(row for row in reference if row['arm']==arm)
        expected=np.array([float(ref['inner_kms']),float(ref['outer_kms'])])
        initial=final
        for seg in (last,mid,early):initial=seg.move(seg.end,0,initial,'mean')
        states={}
        for sign,lags in [('forward',[0]),('reverse',[0,shift])]:
            dates=[release(early,initial,calendar[sign]+lag,sign) for lag in lags]
            state=tuple(np.concatenate([pair[ind] for pair in dates]) for ind in (0,1))
            for seg in (mid,last):state=seg.move(0,seg.end,state,sign)
            pos,vel=[arr.reshape(len(lags),3,3) for arr in state]
            for ind,lag in enumerate(lags):
                states[(sign,lag)]=sky(pos[ind]-pos[ind,:1]+final[0],vel[ind]-vel[ind,:1]+final[1])
        for lag in (0,shift):
            for name,value in states['forward',0].items():
                delta=value-states['reverse',lag][name];norm=np.linalg.norm(delta)
                if lag==shift and name=='vlos_kms':assert np.allclose(delta,expected,atol=1e-10,rtol=0)
                out.append(dict(arm=arm,alternative='passage' if lag==0 else 'frozen_lag',observable=name,
                    separation=norm,upper_single_coordinate_sigma_for_95pct=norm/(2*NormalDist().inv_cdf(.95)),
                    components='/'.join(f'{part:.14g}' for part in delta.ravel())))
    table(f'other-observables-{tag}.csv',out)


if __name__=='__main__':
    for tag in sys.argv[1:]:run(*(int(part) for part in tag.split('-')))
