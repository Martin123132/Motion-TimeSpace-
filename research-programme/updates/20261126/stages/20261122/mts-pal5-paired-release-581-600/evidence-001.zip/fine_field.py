import io
import json
import sys
from pathlib import Path
import runpy
from types import SimpleNamespace
local=runpy.run_path(str(Path(__file__).with_name('field.py')))
HERE,sha,checkstop,save,np,setup=(local[name] for name in ('HERE','sha','checkstop','save','np','setup'))

LEGS={'before':(581,586,-1,4,2.,35.),'middle':(586,590,-1,4,2.,35.),'late':(590,600,1,2,12.,29.)}


def packet(label,**data):
    stream=io.BytesIO();np.savez_compressed(stream,**data);save(label,stream.getvalue())


def run(arm):
    lab,Evolution,advance,guard,_=setup()
    from directional import Radial,green
    obj,host=lab.obj,lab.run
    mesh=Radial(lab,16);norm=np.sqrt(2*mesh.sell+1)*obj.bg.vel**2
    starts={sign:lab.initial[arm].copy() if sign=='forward' else lab.initial[arm].conj().copy() for sign in ('forward','reverse')}
    bridge={}
    prior_fields={};receipts={}
    for leg in ('middle','before','late'):
        left,right,way,stride,low,high=LEGS[leg]
        duration=host.ages[right]-host.ages[left]
        native,dt=host.interval(left,right);steps=8*native;dt*=way/8
        base=np.arange(low,high+.01,.0625)
        r=np.sort(np.r_[base,base[(base>=3)&(base<21)]+.03125])
        assert r[-1] < mesh.inf*obj.bg.length
        vals=[]
        for snap in (left,right):
            p,g=mesh.values(mesh.potential_nodes(lab.mesh.ordinary+host.fields[snap]),r/obj.bg.length)
            vals.append(np.stack((p*norm,g*norm/obj.bg.length),axis=-1))
        pack=dict(radius=r,host=np.array(vals));logs={}
        for sign in starts:
            guard();checkstop()
            state=bridge[sign].copy() if leg=='before' else starts[sign].copy()
            init=state.copy();moment=obj.moment(state);solver=Evolution(obj,dt,state)
            times=np.linspace(0.,duration,steps//stride+1)
            fields=np.empty((len(times),len(r),len(norm),2,2))
            worst=0.
            for tick in range(steps+1):
                phase=tick if way>0 else steps-tick
                if not tick%stride:
                    guard();checkstop()
                    ext=host.fields[left]+phase/steps*(host.fields[right]-host.fields[left])
                    proxy=SimpleNamespace(obj=obj,run=SimpleNamespace(fields={590:ext}),initial={'zero':0*state,'wave':state})
                    p,g,_=green(proxy,mesh,r/obj.bg.length)
                    fields[phase//stride,:,:,0,:]=p*norm[None,:,None]
                    fields[phase//stride,:,:,1,:]=g*(norm/obj.bg.length)[None,:,None]
                    fields[phase//stride,...,1]/=obj.unit_myr
                if tick<steps:
                    idx=tick if way>0 else steps-tick-1
                    state,moment,_,_=advance(obj,solver,state,moment,host.external(left,right,idx,steps),dt)
                    worst=max(worst,abs(np.vdot(state,state).real/obj.number-1))
            key=arm+'_'+sign
            if leg=='middle':
                bridge[sign]=state.copy()
                prior_fields['586'+sign]=fields[0].copy()
                prior_fields['590'+sign]=fields[-1].copy()
            if leg=='before':
                errors=[np.linalg.norm(fields[-1,...,ind]-prior_fields['586'+sign][...,ind])/np.linalg.norm(prior_fields['586'+sign][...,ind]) for ind in (0,1)]
            elif leg=='late':
                subset=np.searchsorted(prior_fields['rad'],r)
                assert np.array_equal(prior_fields['rad'][subset],r)
                errors=[np.linalg.norm(fields[0,...,ind]-prior_fields['590'+sign][subset,...,ind])/np.linalg.norm(prior_fields['590'+sign][subset,...,ind]) for ind in (0,1)]
            else:errors=[]
            solver=Evolution(obj,-dt,state)
            for tick in range(steps):
                idx=steps-tick-1 if way>0 else tick
                if not tick%16:guard();checkstop()
                state,moment,_,_=advance(obj,solver,state,moment,host.external(left,right,idx,steps),-dt)
            close=np.linalg.norm(state-init)/np.sqrt(obj.number)
            assert max([close,worst]+errors)<1e-9
            pack[key]=fields;pack['time']=times
            logs[sign]=dict(return_norm=close,occupation=worst,join=errors)
            print(leg,arm,sign,'finished',flush=True)
        if leg=='middle':prior_fields['rad']=r
        name=f'fine-{leg}-{arm}.npz'
        packet(name,**pack);del pack,fields
        receipts[leg]=dict(packet=sha(HERE/name),checks=logs,steps=steps)
        save(f'fine-{leg}-{arm}.json',(json.dumps(receipts[leg],indent=2,sort_keys=True)+'\n').encode())


if __name__=='__main__':
    for arm in sys.argv[1:]:run(arm)
