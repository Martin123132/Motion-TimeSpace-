import csv
import json
import math
import sys
from field import HERE,JOIN,manifest,np,pin,save
from observe import Segment,anchors,observed,PAL,LATE,CONV,guard,table
from assess import acc,SIGMAS


def fixed_move(seg,start,stop,state,sign,steps):
    pos,speed=(val.copy() for val in state)
    times=np.linspace(start,stop,steps+1)
    accel=seg.acc(start,pos,sign)
    for left,right in zip(times,times[1:]):
        step=right-left
        speed+=.5*step*accel;pos+=step*speed
        accel=seg.acc(right,pos,sign);speed+=.5*step*accel
    return pos,speed


def run(factor,mult):
    noise_tag=f'{factor}-{mult}'
    with (HERE/f'noise-{noise_tag}.csv').open() as inp:
        guesses={row['arm']:row for row in csv.DictReader(inp) if row['distance_kpc']=='22.05' and row['case']=='both' and float(row['sigma_kms'])==min(SIGMAS)}
    final=tuple(arr[:1] for arr in anchors(22.05))
    slopes=[];witness=[]
    for arm in ('reset','coupled'):
        guard()
        name=f'fields-{factor}-{arm}'
        with np.load(pin(HERE/(name+'.npz'),json.loads((HERE/(name+'.json')).read_bytes())['data'])) as bank:
            early=Segment(bank,arm,round(192*factor*mult*88/70))
        med=f'early-{70*factor}-{arm}.npz';later=f'potential-{18*factor}.npz'
        with np.load(pin(JOIN/med,manifest[med])) as bank:mid=Segment(bank,arm,192*factor*mult)
        with np.load(pin(PAL/later,LATE[later])) as bank:last=Segment(bank,arm,192*mult)
        center_time=early.end/2
        initial=final
        for seg in (last,mid,early):initial=seg.move(seg.end,0,initial,'mean')
        nclock=int(np.ceil(early.steps*.5))
        def readout(date,sign,with_derivative):
            guard()
            xy,vel=fixed_move(early,0,date,initial,sign,nclock)
            radial=xy[0]*[1,1,0];cyl=np.linalg.norm(radial);radial/=cyl
            d_radial=(vel[0]*[1,1,0]-radial*(radial@vel[0]))/cyl
            orient=np.cross([0,0,1],radial)
            sense=np.sign(orient@vel[0])
            assert abs(orient@vel[0])>1e-6
            az=sense*orient;d_az=sense*np.cross([0,0,1],d_radial)
            offset=np.array([0,-1,1])[:,None]
            pos=xy+.060*offset*radial;speed=vel+CONV*offset*az
            accel=early.acc(date,pos,sign)
            src_pos=vel+.060*offset*d_radial-speed
            src_vel=accel[0]+CONV*offset*d_az-accel
            assert max(np.linalg.norm(src_pos[0]),np.linalg.norm(src_vel[0]))<1e-15
            widths=[0,.01,-.01,.005,-.005] if with_derivative else [0]
            state=(np.concatenate([pos+width*src_pos for width in widths]),np.concatenate([speed+width*src_vel for width in widths]))
            state=fixed_move(early,date,early.end,state,sign,nclock)
            for seg in (mid,last):state=seg.move(0,seg.end,state,sign)
            pos,speed=[arr.reshape(len(widths),3,3) for arr in state]
            obs=observed((pos-pos[:,:1]+final[0]).reshape(-1,3),(speed-speed[:,:1]+final[1]).reshape(-1,3)).reshape(len(widths),3,3)
            vlos=obs[:,1:,2]-obs[:,:1,2]
            if with_derivative:return vlos[0],(vlos[1]-vlos[2])/.02,(vlos[3]-vlos[4])/.01
            return vlos[0]
        def odd(vec):return (vec[1]-vec[0])/math.sqrt(2)
        central={}
        for sign in ('forward','reverse'):
            val,wide,narrow=readout(center_time,sign,True)
            span=.025
            numerical=(readout(center_time+span,sign,False)-readout(center_time-span,sign,False))/(2*span)
            rel=lambda vec:np.linalg.norm(vec-narrow)/np.linalg.norm(narrow)
            slopes.append(dict(arm=arm,flow=sign,release_Myr=center_time,inner_kms_per_Myr=narrow[0],outer_kms_per_Myr=narrow[1],pulse_refine=rel(wide),time_difference_relative=rel(numerical)))
            central[sign]=(val,narrow)
        forward=central['forward'][0]
        shift=0.
        pairs=[('same_center',center_time,center_time,forward,central['reverse'][0])]
        for turn in (1,2):
            val,slope=(central['reverse'] if turn==1 else readout(center_time+shift,'reverse',True)[::2])
            if abs(odd(slope))<1e-12:break
            shift=np.clip(shift+odd(forward-val)/odd(slope),-10.,10.)
            rev=readout(center_time+shift,'reverse',False)
            pairs.append((f'tangent_step_{turn}',center_time,center_time+shift,forward,rev))
        fdate=float(guesses[arm]['witness_forward_Myr']);rdate=float(guesses[arm]['witness_reverse_Myr'])
        pairs.append(('linear_witness_directly_evolved',fdate,rdate,readout(fdate,'forward',False),readout(rdate,'reverse',False)))
        for label,ft,rt,fv,rv in pairs:
            difference=fv-rv
            for sig in SIGMAS:
                witness.append(dict(arm=arm,test=label,forward_Myr=ft,reverse_Myr=rt,sigma_kms=sig,
                    inner_delta_kms=difference[0],outer_delta_kms=difference[1],distance_kms=np.linalg.norm(difference),
                    worst_accuracy_upper_pct=acc(np.linalg.norm(difference),sig)))
        print('clock',factor,mult,arm,flush=True)
    table(f'tangent-{noise_tag}.csv',slopes);table(f'witness-{noise_tag}.csv',witness)


if __name__=='__main__':
    for grid in sys.argv[1:]:run(*(int(part) for part in grid.split('-')))
