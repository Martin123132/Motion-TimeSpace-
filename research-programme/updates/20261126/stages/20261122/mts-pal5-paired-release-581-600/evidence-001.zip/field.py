from pathlib import Path
from types import SimpleNamespace
import hashlib
import io
import json
import sys

HERE = Path(__file__).resolve().parent
JOIN = HERE.parent / 'mts-pal5-joined-flow-586-600-20261122'


def sha(path):
    with path.open('rb') as handle:
        return hashlib.file_digest(handle, 'sha256').hexdigest()


def pin(path, expected):
    assert sha(path) == expected, path
    return path


manifest = json.loads(pin(JOIN/'seal.json','86d9b1296c253b14a04e475339a9cbf71f84fed201749a234af4892b715576b7').read_bytes())
pin(JOIN/'early.py',manifest['early.py'])
sys.path.insert(0,str(JOIN))
from early import np, INVERSE, OLD, setup


def save(name, data):
    path = HERE/name
    if path.exists():
        assert sha(path) == hashlib.sha256(data).hexdigest(), name
    else:
        with path.open('xb') as stream:
            stream.write(data)


def checkstop():
    assert not (HERE/'STOP-REQUESTED').exists() and not (HERE.parent/'STOP-REQUESTED').exists()


def build(factor):
    assert factor in (2,4,8)
    checkstop()
    lab, Evolution, advance, guard, _ = setup()
    from directional import Radial, green
    obj, run = lab.obj, lab.run
    native, step = run.interval(581,586)
    count, step = native*factor, step/factor
    assert native == 88
    duration = run.ages[586]-run.ages[581]
    mesh = Radial(lab,16)
    rad = np.arange(2.,35.01,.25/factor)
    assert rad[-1] < mesh.inf*obj.bg.length
    norm = np.sqrt(2*mesh.sell+1)*obj.bg.vel**2
    hosts = []
    for snap in (581,586):
        val, slope = mesh.values(mesh.potential_nodes(lab.mesh.ordinary+run.fields[snap]),rad/obj.bg.length)
        hosts.append(np.stack([val*norm,slope*norm/obj.bg.length],axis=-1))
    ref = f'states-586-{70*factor}.npz'
    for arm in ('reset','coupled'):
        join = f'early-{70*factor}-{arm}.npz'
        with np.load(pin(JOIN/join,manifest[join])) as later:
            ix = np.searchsorted(rad,later['radius'])
            assert np.array_equal(rad[ix],later['radius'])
            host_err = np.linalg.norm(hosts[-1][ix]-later['host'][0])/np.linalg.norm(later['host'][0])
            assert host_err < 1e-9
            data = dict(radius=rad, host=np.asarray(hosts))
            receipt = {}
            archive = run.reference[581] if arm=='reset' else lab.raw[581]
            for sign in ('forward','reverse'):
                label = arm+'_'+sign
                with np.load(pin(INVERSE/ref,OLD[ref])) as start:
                    initial = start[label]
                state = initial.copy()
                moment = obj.moment(state)
                solver = Evolution(obj,-step,state)
                fields, times = [], []
                worst = 0.
                for tick in range(count+1):
                    if tick%4 == 0:
                        checkstop(); guard()
                        frac = (count-tick)/count
                        ext = run.fields[581]+frac*(run.fields[586]-run.fields[581])
                        proxy = SimpleNamespace(obj=obj,run=SimpleNamespace(fields={590:ext}),initial={'zero':0*state,'wave':state})
                        val,slope,_ = green(proxy,mesh,rad/obj.bg.length)
                        frame=np.stack([val*norm[None,:,None],slope*(norm/obj.bg.length)[None,:,None]],axis=-2)
                        frame[...,1] /= obj.unit_myr
                        fields.append(frame); times.append(frac*duration)
                    if tick < count:
                        state,moment,_,_=advance(obj,solver,state,moment,run.external(581,586,count-1-tick,count),-step)
                        worst=max(worst,abs(np.vdot(state,state).real/obj.number-1))
                join_error=[np.linalg.norm(fields[0][ix,...,ind]-later[label][0,...,ind])/np.linalg.norm(later[label][0,...,ind]) for ind in (0,1)]
                data[label]=np.asarray(fields[::-1]);data['time']=np.array(times[::-1]); del fields
                data['state581_'+sign]=state.copy()
                phase=np.angle(np.vdot(archive,state))
                distance=np.linalg.norm(state*np.exp(-1j*phase)-archive)/np.sqrt(obj.number)
                solver=Evolution(obj,step,state)
                for tick in range(count):
                    if tick%16==0: checkstop();guard()
                    state,moment,_,_=advance(obj,solver,state,moment,run.external(581,586,tick,count),step)
                closure=np.linalg.norm(state-initial)/np.sqrt(obj.number)
                assert max([worst,closure,host_err]+join_error)<1e-9
                receipt[label]=dict(occupation=worst,wave_return=closure,host_join=host_err,wave_join=join_error,phase_free_distance_to_own_archive=distance)
                print(factor,label,'wave joined and returned',flush=True)
        stream=io.BytesIO(); np.savez_compressed(stream,**data)
        prefix=f'fields-{factor}-{arm}'
        save(prefix+'.npz',stream.getvalue()); del stream, data
        save(prefix+'.json',(json.dumps(dict(duration_Myr=duration,steps=count,protocol=sha(HERE/'PROTOCOL.md'),code=sha(HERE/'field.py'),data=sha(HERE/(prefix+'.npz')),checks=receipt),indent=2,sort_keys=True)+'\n').encode())


if __name__=='__main__':
    for item in sys.argv[1:]:
        build(int(item))
