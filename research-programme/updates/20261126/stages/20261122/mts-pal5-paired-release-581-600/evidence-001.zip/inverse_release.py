import csv
import sys
from field import HERE,np
from observe import anchors,guard,table,CONV,load_segments


def run(factor,mult):
    tag=f'{factor}-{mult}'
    with (HERE/f'passages-{tag}.csv').open() as stream:clock=list(csv.DictReader(stream))
    with (HERE/'lag-frozen.csv').open() as stream:frozen={row['arm']:float(row['lag_Myr']) for row in csv.DictReader(stream)}
    final=tuple(arr[:1] for arr in anchors(22.05))
    out=[];summaries=[];escape=[]
    for arm in ('reset','coupled'):
        guard();early,mid,last=load_segments(arm,factor,4,mult)
        initial=final
        for seg in (last,mid,early):initial=seg.move(seg.end,0,initial,'mean')
        stamps={row['flow']:float(row['passage_Myr']) for row in clock if row['arm']==arm and row['count']=='1'}
        def at(date,sign):
            pos,vel=early.move(0,date,initial,sign)
            radial=pos[0]*[1,1,0];radial/=np.linalg.norm(radial)
            az=np.cross([0,0,1],radial)
            if az@vel[0]<0:az=-az
            offsets=np.array([0,-1,1])[:,None]
            return (pos+.060*offsets*radial,vel+CONV*offsets*az),radial,az
        def move(state,date,sign,invert=False):
            guard()
            if invert:
                for seg in (last,mid):state=seg.move(seg.end,0,state,sign)
                return early.move(early.end,date,state,sign)
            state=early.move(date,early.end,state,sign)
            for seg in (mid,last):state=seg.move(0,seg.end,state,sign)
            return state
        for case,shift in [('own_passage',0.),('frozen_lag',frozen[arm])]:
            dates={'forward':stamps['forward'],'reverse':stamps['reverse']+shift}
            launches={flow:at(date,flow) for flow,date in dates.items()}
            flights={flow:move(launches[flow][0],date,flow) for flow,date in dates.items()}
            for target,rival in [('forward','reverse'),('reverse','forward')]:
                rival_end=flights[rival];model=flights[target]
                wanted=tuple(dest[:1]+src-src[:1] for dest,src in zip(rival_end,model))
                merged=tuple(np.concatenate((first,second)) for first,second in zip(rival_end,wanted))
                back=move(merged,dates[rival],rival,True)
                direct,needed=[tuple(part[sl] for part in back) for sl in (slice(3),slice(3,None))]
                start,radial,az=launches[rival]
                err=max(abs(orig-replay).max() for orig,replay in zip(start,direct))
                closure=move(needed,dates[rival],rival)
                e2=max(abs(orig-replay).max() for orig,replay in zip(wanted,closure))
                assert max(err,e2)<1e-9
                residuals=[(row[1:]-row[:1])-(col[1:]-col[:1]) for row,col in zip(needed,start)]
                dx,dv=residuals[0]*1000.,residuals[1]/CONV
                dr=.5*(dx[1]-dx[0])@radial
                ds=.5*(dv[1]-dv[0])@az
                signs=np.array([-1,1])[:,None]
                rx=dx-signs*dr*radial
                rv=dv-signs*ds*az
                assert np.isclose(np.sum(dx**2),np.sum(rx**2)+2*dr**2,atol=1e-12)
                assert np.isclose(np.sum(dv**2),np.sum(rv**2)+2*ds**2,atol=1e-14)
                summaries.append(dict(arm=arm,case=case,target=target,rival=rival,adjusted_radius_pc=60+dr,
                    adjusted_tangential_speed_kms=1+ds,required_rms_position_pc=np.linalg.norm(dx)/np.sqrt(2),
                    required_rms_velocity_kms=np.linalg.norm(dv)/np.sqrt(2),restricted_residual_position_pc=np.linalg.norm(rx)/np.sqrt(2),
                    restricted_residual_velocity_kms=np.linalg.norm(rv)/np.sqrt(2),native_roundtrip=err,target_roundtrip=e2))
                for index,tail in enumerate(('inner','outer')):
                    radius_pc=1000*np.linalg.norm(needed[0][index+1]-needed[0][0])
                    speed_kms=np.linalg.norm(needed[1][index+1]-needed[1][0])/CONV
                    point_grav=.00430091727003628
                    escape.append(dict(arm=arm,case=case,target=target,rival=rival,tail=tail,
                        required_radius_pc=radius_pc,required_speed_kms=speed_kms,
                        point_escape_mass_Msun=radius_pc*speed_kms**2/(2*point_grav),
                        escape_kms_at_4297_Msun=np.sqrt(2*point_grav*4297/radius_pc)))
                    out.append(dict(arm=arm,case=case,target=target,rival=rival,tail=tail,launch_date_Myr=dates[rival],
                        dx_pc=dx[index,0],dy_pc=dx[index,1],dz_pc=dx[index,2],dvx_kms=dv[index,0],dvy_kms=dv[index,1],dvz_kms=dv[index,2]))
        print('inverse',tag,arm,flush=True)
    table(f'inverse-state-{tag}.csv',out);table(f'inverse-budget-{tag}.csv',summaries);table(f'escape-surface-{tag}.csv',escape)


if __name__=='__main__':
    for tag in sys.argv[1:]:run(*(int(part) for part in tag.split('-')))
