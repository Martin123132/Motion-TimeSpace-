import json
import sys
from scipy.optimize import brentq
from observe import anchors,observed,guard,table,release,load_segments
from field import HERE,JOIN,manifest,np,pin
from assess import SIGMAS,acc


def passages(seg,initial,sign):
    pos,vel=(part.copy() for part in initial)
    times=np.linspace(0,seg.end,seg.steps+1)
    accel=seg.acc(0,pos,sign)
    roots=[]
    for first,last in zip(times,times[1:]):
        step=last-first
        old,oldv=pos.copy(),vel.copy()
        vel+=.5*step*accel;pos+=step*vel
        accel=seg.acc(last,pos,sign);vel+=.5*step*accel
        if (old*oldv).sum()<0<=(pos*vel).sum():
            diff=pos-old
            linear=step*oldv
            quad=3*diff-step*(2*oldv+vel);cube=step*(vel+oldv)-2*diff
            def orbit(frac):
                return old+frac*(linear+frac*(quad+frac*cube)),(linear+frac*(2*quad+frac*3*cube))/step
            def radial(frac):
                at,speed=orbit(frac)
                return (at*speed).sum()
            frac=brentq(radial,0,1,xtol=1e-14);date=first+frac*step
            at,speed=orbit(frac);force=seg.acc(date,at,sign)
            denom=(speed*speed+at*force).sum()
            assert denom>0 and abs((at*speed).sum())<1e-11
            roots.append((date,np.linalg.norm(at),denom))
    return roots


def run(mult,factor=4):
    final=tuple(arr[:1] for arr in anchors(22.05))
    clocks=[];signals=[];details=[]
    for arm in ('reset','coupled'):
        guard()
        early,mid,last=load_segments(arm,factor,4,mult)
        initial=final
        for seg in (last,mid,early):initial=seg.move(seg.end,0,initial,'mean')
        data={}
        for sign in ('mean','forward','reverse'):
            roots=passages(early,initial,sign);data[sign]=roots
            for idx,values in enumerate(roots or [(None,None,None)]):
                clocks.append(dict(arm=arm,flow=sign,count=len(roots),index=idx,passage_Myr=values[0],radius_kpc=values[1],radial_derivative_kpc2_Myr2=values[2]))
        if not all(len(items)==1 for items in data.values()):continue
        for clock in ('mean','own'):
            valid=[lag for lag in (-10,0,10) if all(0<=data['mean' if clock=='mean' else sign][0][0]+lag<=early.end for sign in ('forward','reverse'))]
            if not valid:continue
            read={}
            for sign in ('forward','reverse'):
                zero=data['mean' if clock=='mean' else sign][0][0]
                trials=[release(early,initial,zero+lag,sign) for lag in valid]
                state=tuple(np.concatenate([pair[field] for pair in trials]) for field in (0,1))
                for seg in (mid,last):state=seg.move(0,seg.end,state,sign)
                pos,vel=[arr.reshape(len(valid),3,3) for arr in state]
                sky=observed((pos-pos[:,:1]+final[0]).reshape(-1,3),(vel-vel[:,:1]+final[1]).reshape(-1,3)).reshape(len(valid),3,3)
                read[sign]=sky[:,1:,2]-sky[:,:1,2]
                for lag,vel in zip(valid,read[sign]):
                    details.append(dict(arm=arm,clock=clock,flow=sign,lag_Myr=lag,date_Myr=zero+lag,
                        inner_kms=vel[0],outer_kms=vel[1]))
            for ind,lag in enumerate(valid):
                diff=read['forward'][ind]-read['reverse'][ind]
                signals.append(dict(arm=arm,clock=clock,lag_Myr=lag,delta_inner_kms=diff[0],delta_outer_kms=diff[1],distance_kms=np.linalg.norm(diff),known_accuracy_best_sigma_pct=acc(np.linalg.norm(diff),min(SIGMAS))))
        print('passage',mult,arm,[(key,[item[0] for item in vals]) for key,vals in data.items()],flush=True)
    table(f'passages-{factor}-{mult}.csv',clocks)
    if signals:table(f'passage-differences-{factor}-{mult}.csv',signals);table(f'passage-means-{factor}-{mult}.csv',details)


if __name__=='__main__':
    for val in sys.argv[1:]:run(*(int(part) for part in val.split(':')))
