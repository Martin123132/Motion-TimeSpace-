import csv
import json
import sys
from observe import anchors,observed,guard,table,release,load_segments
from field import HERE,JOIN,manifest,np,pin
from assess import SIGMAS,acc


def get_rows(file):
    with (HERE/file).open() as handle:return list(csv.DictReader(handle))


def test(factor,mult,calibrate):
    tag=f'{factor}-{mult}'; clocks=get_rows(f'passages-{tag}.csv')
    packed=get_rows(f'passage-means-{tag}.csv')
    frozen={} if calibrate else {row['arm']:float(row['lag_Myr']) for row in get_rows('lag-frozen.csv')}
    start=tuple(arr[:1] for arr in anchors(22.05))
    calibrated=[];checks=[]
    for arm in ('reset','coupled'):
        guard()
        early,mid,last=load_segments(arm,factor,4,mult)
        stamp={row['flow']:float(row['passage_Myr']) for row in clocks if row['arm']==arm and row['count']=='1'}
        basis={row['flow']:np.array([float(row['inner_kms']),float(row['outer_kms'])]) for row in packed if row['arm']==arm and row['clock']=='own' and row['lag_Myr']=='0'}
        original=start
        for seg in (last,mid,early):original=seg.move(seg.end,0,original,'mean')
        def evaluate(lag):
            guard()
            state=release(early,original,stamp['reverse']+lag,'reverse')
            for seg in (mid,last):state=seg.move(0,seg.end,state,'reverse')
            pos,vel=state
            sky=observed(pos-pos[:1]+start[0],vel-vel[:1]+start[1])
            return sky[1:,2]-sky[0,2]
        target=basis['forward']
        if calibrate:
            deriv=(evaluate(.025)-evaluate(-.025))/.05
            lag=np.diff(target-basis['reverse']).item()/np.diff(deriv).item()
            assert abs(lag)<=10
            first=evaluate(lag)
            next_lag=lag+np.diff(target-first).item()/np.diff(deriv).item()
            assert abs(next_lag)<=10
            calibrated.append(dict(arm=arm,lag_Myr=next_lag,reference='4-1 own passage',first_lag_Myr=lag))
            lag=next_lag
        else:lag=frozen[arm]
        actual=evaluate(lag)
        diff=target-actual; sep=np.linalg.norm(diff); old=np.linalg.norm(target-basis['reverse'])
        for sig in SIGMAS:
            checks.append(dict(arm=arm,sigma_kms=sig,lag_Myr=lag,target_date_Myr=stamp['forward'],alternative_date_Myr=stamp['reverse']+lag,
                inner_kms=diff[0],outer_kms=diff[1],unknown_lag_distance_kms=sep,known_passage_distance_kms=old,
                worst_accuracy_upper_pct=acc(sep,sig)))
        print(tag,arm,lag,sep,flush=True)
    if calibrate:table('lag-frozen.csv',calibrated)
    table(f'lag-test-{tag}.csv',checks)


if __name__=='__main__':
    for tag in sys.argv[1:]:
        factor,mult=(int(item) for item in tag.split('-'))
        test(factor,mult,tag=='4-1')
