import csv
import sys
from field import HERE,np
from observe import anchors,observed,CONV,table,load_segments,guard
from assess import acc,SIGMAS

GM=.00430091727003628*4297/1000*CONV**2
SCALE=22.05*np.tan(np.deg2rad(3.21/60))
LABELS=[(speed,force) for speed in ('fixed','escape') for force in (False,True)]
MASK=np.array([force for speed,force in LABELS])[:,None,None]


def records(name):
    with (HERE/name).open() as handle:return list(csv.DictReader(handle))


def quantities(seg,time,pos,vel):
    relative=pos-pos[:,:1]
    speed=vel-vel[:,:1]
    square=(relative*relative).sum(axis=2)
    den=np.sqrt(square+SCALE**2)
    external=seg.acc(time,pos.reshape(-1,3),CURRENT_SIGN).reshape(pos.shape)
    tide=external-external[:,:1]
    acc_total=external-MASK*GM*relative/den[:,:,None]**3
    kin=(speed*speed).sum(axis=2)/2
    binding=(kin-GM/den)/CONV**2
    energy=(kin-MASK[:,:,0]*GM/den)/CONV**2
    power=(speed*tide).sum(axis=2)/CONV**2
    return acc_total,energy,power,binding,np.sqrt(square)


def flight(segments,initial,date,sign):
    global CURRENT_SIGN
    CURRENT_SIGN=sign
    early=segments[0]
    center,velocity=early.move(0,date,initial,sign)
    radial=center[0]*[1,1,0];radial/=np.linalg.norm(radial)
    az=np.cross([0,0,1],radial)
    if az@velocity[0]<0:az=-az
    offsets=np.array([0,-1,1])[:,None]
    pos=np.repeat((center+.060*offsets*radial)[None,:,:],len(LABELS),axis=0)
    vesc=np.sqrt(2*GM/np.hypot(.060,SCALE))
    vel=np.stack([velocity+offsets*az*(vesc if mode=='escape' else CONV) for mode,force in LABELS])
    _,begin,_,initial_binding,radii=quantities(early,date,pos,vel)
    assert np.max(abs(initial_binding[2:,1:]))<1e-10
    work=np.zeros_like(begin);work_abs=work.copy()
    minimum=initial_binding.copy();maximum=initial_binding.copy()
    minr=radii.copy();maxr=radii.copy();negative=work.copy()
    max_res=work.copy()
    for seg,start in zip(segments,(date,0,0)):
        accel,energy,power,binding,rad=quantities(seg,start,pos,vel)
        count=max(1,int(np.ceil(abs(seg.end-start)/seg.end*seg.steps)))
        times=np.linspace(start,seg.end,count+1)
        for tick,(left,right) in enumerate(zip(times,times[1:])):
            if tick%512==0:guard()
            h=right-left;vel+=.5*h*accel;pos+=h*vel
            accel,_,_,_,_=quantities(seg,right,pos,vel)
            vel+=.5*h*accel
            rel_v=vel-vel[:,:1];rel_p=pos-pos[:,:1]
            den=np.sqrt(np.sum(rel_p*rel_p,axis=2)+SCALE**2)
            dacc=accel-accel[:,:1]+MASK*GM*rel_p/den[:,:,None]**3
            after=(rel_v*dacc).sum(axis=2)/CONV**2
            kin=(rel_v*rel_v).sum(axis=2)/2
            energy=(kin-MASK[:,:,0]*GM/den)/CONV**2
            bind=(kin-GM/den)/CONV**2
            negative+=.5*h*((binding<0).astype(float)+(bind<0).astype(float))
            work+=.5*h*(power+after);work_abs+=.5*h*(abs(power)+abs(after))
            power=after;binding=bind
            minimum=np.minimum(minimum,binding);maximum=np.maximum(maximum,binding)
            r=np.linalg.norm(rel_p,axis=2);minr=np.minimum(minr,r);maxr=np.maximum(maxr,r)
            max_res=np.maximum(max_res,abs(energy-begin-work))
    assert np.isfinite(pos).all() and np.isfinite(vel).all()
    return pos,vel,dict(initial=initial_binding,final=binding,minimum=minimum,maximum=maximum,bound_Myr=negative,
                    norm_error=max_res/np.maximum(work_abs,GM/.060/CONV**2),work=work,min_pc=minr*1000,max_pc=maxr*1000)


def run(factor,mult):
    tag=f'{factor}-{mult}';clocks=records(f'passages-{tag}.csv')
    lag={row['arm']:float(row['lag_Myr']) for row in records('lag-frozen.csv')}
    reference=records(f'lag-test-{tag}.csv')
    final=tuple(arr[:1] for arr in anchors(22.05))
    rows=[];checks=[]
    for arm in ('reset','coupled'):
        segments=load_segments(arm,factor,4,mult)
        stamps={row['flow']:float(row['passage_Myr']) for row in clocks if row['arm']==arm and row['count']=='1'}
        init=final
        for seg in reversed(segments):init=seg.move(seg.end,0,init,'mean')
        saved={}
        for sign,shift in [('forward',0.),('reverse',0.),('reverse',lag[arm])]:
            pos,vel,diag=flight(segments,init,stamps[sign]+shift,sign)
            p=pos-pos[:,:1]+final[0];v=vel-vel[:,:1]+final[1]
            sky=observed(p.reshape(-1,3),v.reshape(-1,3)).reshape(len(LABELS),3,3)
            saved[sign,shift]=sky[:,1:,2]-sky[:,:1,2]
            for idx,(speed,force) in enumerate(LABELS):
                for star,tail in enumerate(('inner','outer'),1):
                    checks.append(dict(arm=arm,flow=sign,extra_lag_Myr=shift,speed=speed,cluster_force=force,tail=tail,
                        **{key:values[idx,star] for key,values in diag.items()}))
        for shift in (0.,lag[arm]):
            diff=saved['forward',0.]-saved['reverse',shift]
            ref=next(row for row in reference if row['arm']==arm)
            if shift:assert np.allclose(diff[0],[float(ref['inner_kms']),float(ref['outer_kms'])],atol=1e-9,rtol=0)
            else:assert abs(np.linalg.norm(diff[0])-float(ref['known_passage_distance_kms']))<1e-9
            for idx,(speed,force) in enumerate(LABELS):
                rows.append(dict(arm=arm,alternative='passage' if not shift else 'frozen_lag',speed=speed,cluster_force=force,
                    inner_kms=diff[idx,0],outer_kms=diff[idx,1],distance_kms=np.linalg.norm(diff[idx]),
                    best_error_two_state_accuracy_pct=acc(np.linalg.norm(diff[idx]),min(SIGMAS))))
        print('escape energy',tag,arm,flush=True)
    table(f'physical-launch-{tag}.csv',rows);table(f'cluster-energy-{tag}.csv',checks)


if __name__=='__main__':
    for item in sys.argv[1:]:run(*(int(part) for part in item.split('-')))
