import csv
import hashlib
import json
import math
import sys
from pathlib import Path

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent


def sha(path):
    with path.open('rb') as inp:return hashlib.file_digest(inp,'sha256').hexdigest()


def load(name):return json.loads((HERE/name).read_bytes())


def rows(name):
    with (HERE/name).open() as inp:return list(csv.DictReader(inp))


def store(name,data):
    path=HERE/name
    if path.exists():assert path.read_bytes()==data,name
    else:
        with path.open('xb') as out:out.write(data)


def dist(vec):return math.sqrt(sum(val*val for val in vec))


def compare(a,b,kind):
    sel=lambda tag:rows(f'{kind}-{tag}.csv')
    keys={'lag-test':('arm','sigma_kms'),'passage-differences':('arm','clock','lag_Myr'),
          'other-observables':('arm','alternative','observable'),'inverse-state':('arm','case','target','rival','tail'),
          'physical-launch':('arm','alternative','speed','cluster_force')}
    groups={'lag-test':(('inner_kms','outer_kms'),),'passage-differences':(('delta_inner_kms','delta_outer_kms'),),
            'inverse-state':(('dx_pc','dy_pc','dz_pc'),('dvx_kms','dvy_kms','dvz_kms')),'other-observables':(('components',),),
            'physical-launch':(('inner_kms','outer_kms'),)}
    def keyed(tag):
        data=sel(tag)
        out={tuple(row[key] for key in keys[kind]):row for row in data}
        assert len(out)==len(data)
        return out
    left,right=keyed(a),keyed(b);assert left.keys()==right.keys()
    output=[]
    for key,last in right.items():
        for cols in groups[kind]:
            def extract(row):
                if cols==('components',):return [float(word) for word in row['components'].split('/')]
                return [float(row[col]) for col in cols]
            one,two=extract(left[key]),extract(last)
            delta=dist([old-new for old,new in zip(one,two)])
            relative=delta/dist(two)
            output.append(dict(test=kind,coarse=a,fine=b,case='|'.join(key),fields='/'.join(cols),
                difference=delta,fine_norm=dist(two),fraction=relative,passed=relative<.005))
    return output


def check():
    assert __debug__ and not (HERE/'STOP-REQUESTED').exists()
    entry=ROOT/'mts-pal5-joined-flow-586-600-20261122'
    assert sha(entry/'seal.json')=='86d9b1296c253b14a04e475339a9cbf71f84fed201749a234af4892b715576b7'
    final='8-4-4'
    current=rows(f'controls-{final}.csv')
    assert len(current)==6
    dates={row['segment']:float(row['duration_Myr']) for row in current}
    assert set(dates)=={'581-586','586-590','590-600'}
    assert all(float(row['mean_return'])<1e-9 and 2<float(row['min_kpc'])<float(row['max_kpc'])<35 for row in current)
    duration=sum(dates.values())
    assert abs(sum(dates[key] for key in ('586-590','590-600'))-111.158776)<1e-8
    allchecks=[]
    for arm in ('reset','coupled'):
        for res in (2,4):
            name=f'fields-{res}-{arm}'
            meta=load(name+'.json')
            assert meta['steps']==res*88 and meta['data']==sha(HERE/(name+'.npz'))
            assert meta['code']==sha(HERE/'field.py') and meta['protocol']==sha(HERE/'PROTOCOL.md')
            for check in meta['checks'].values():
                assert max([check['wave_return'],check['occupation'],check['host_join']]+check['wave_join'])<1e-9
        for leg in ('before','middle','late'):
            name=f'fine-{leg}-{arm}'
            meta=load(name+'.json')
            assert meta['packet']==sha(HERE/(name+'.npz'))
            assert meta['steps']==8*{'before':88,'middle':70,'late':18}[leg]
            for check in meta['checks'].values():
                assert max([check['return_norm'],check['occupation']]+check['join'])<1e-9
    for coarse,fine in [('2-2','4-2'),('4-2','8-2')]:
        for kind in ('lag-test','passage-differences','other-observables','inverse-state','physical-launch'):
            allchecks.extend(compare(coarse,fine,kind))
    for kind in ('lag-test','passage-differences','inverse-state','physical-launch'):
        allchecks.extend(compare('4-1','4-2',kind))
    for grid in ('4-1','4-2','8-2'):
        energy=rows(f'cluster-energy-{grid}.csv')
        assert len(energy)==48 and all(float(row['norm_error'])<.005 for row in energy)
        assert all(abs(float(row['initial']))<1e-10 for row in energy if row['speed']=='escape')
        known=rows(f'passages-{grid}.csv')
        model_lag={row['arm']:float(row['lag_Myr']) for row in rows('lag-frozen.csv')}
        passage_times={(row['arm'],row['flow']):float(row['passage_Myr']) for row in known}
        bound_times=[]
        for row in energy:
            if row['speed']!='escape' or row['cluster_force']!='True':continue
            release=passage_times[row['arm'],row['flow']]+float(row['extra_lag_Myr'])
            span=dates['581-586']-release
            orbit_steps=round(192*4*int(grid.split('-')[1])*88/70)
            half_first_step=.5*span/math.ceil(span/dates['581-586']*orbit_steps)
            corrected=float(row['bound_Myr'])-(half_first_step if float(row['initial'])<0 else 0.)
            assert corrected>=-1e-10
            bound_times.append(max(0.,corrected))
        assert len(bound_times)==12 and max(bound_times)<1e-9
        assert len(known)==6 and all(row['count']=='1' and float(row['radial_derivative_kpc2_Myr2'])>0 and 10<float(row['passage_Myr'])<dates['581-586']-10 for row in known)
        witnesses=rows(f'lag-test-{grid}.csv')
        frozen={row['arm']:float(row['lag_Myr']) for row in rows('lag-frozen.csv')}
        assert len(witnesses)==4 and all(float(row['lag_Myr'])==frozen[row['arm']] and abs(float(row['lag_Myr']))<=10 for row in witnesses)
        for row in rows(f'inverse-budget-{grid}.csv'):
            assert max(float(row['native_roundtrip']),float(row['target_roundtrip']))<1e-9
        for row in rows(f'passage-differences-{grid}.csv'):
            assert math.isfinite(float(row['known_accuracy_best_sigma_pct'])) and 50<=float(row['known_accuracy_best_sigma_pct'])<=100
    for row in rows('tangent-4-2.csv'):
        assert max(float(row['pulse_refine']),float(row['time_difference_relative']))<.005
    summary={}
    lags={row['arm']:float(row['lag_Myr']) for row in rows('lag-frozen.csv')}
    loose=rows('loose-witness.csv')
    assert len(loose)==len({(row['arm'],row['grid']) for row in loose})==6
    from statistics import NormalDist
    for row in loose:
        magnitude=math.hypot(float(row['delta_inner_kms']),float(row['delta_outer_kms']))
        assert abs(float(row['lag_Myr'])-lags[row['arm']]/2)<1e-12
        assert abs(magnitude-float(row['distance_kms']))<1e-12
        assert abs(100*NormalDist().cdf(magnitude/.44)-float(row['worst_accuracy_upper_best_error_pct']))<1e-12
    for row in rows('loose-witness-checks.csv'):
        pair={item['grid']:[float(item[key]) for key in ('delta_inner_kms','delta_outer_kms')] for item in loose if item['arm']==row['arm']}
        change=math.dist(pair[row['low']],pair[row['high']])/dist(pair[row['high']])
        assert abs(change-float(row['fraction']))<1e-12 and change<.005 and row['passed']=='True'
    for tag in ('2-1-to-4-1','4-1-to-4-2','4-2-to-4-4','2-4-4-to-4-4','4-4-to-8-4-4'):
        group=rows(f'refine-{tag}.csv')
        assert len(group)==36 and all((float(row['fractional_change'])<.005)==(row['pass_0p005']=='True') for row in group)
        summary[tag]={'max_fraction':max(float(row['fractional_change']) for row in group),'failed':[row for row in group if row['pass_0p005']!='True']}
    import io
    buf=io.StringIO();writer=csv.DictWriter(buf,allchecks[0],lineterminator='\n')
    writer.writeheader();writer.writerows(allchecks);store('passage-and-state-refinements.csv',buf.getvalue().encode())
    obj={'duration_Myr':duration,'trailing_drift_percent':duration/1940*100,'five_Gyr_percent':duration/5000*100,
         'wave_refinements':summary,'local_tangent_max_relative':max(float(row['time_difference_relative']) for row in rows('tangent-4-2.csv')),
         'failed_auxiliary_comparisons':sum(not row['passed'] for row in allchecks),'auxiliary_comparisons':len(allchecks)}
    store('verification.json',(json.dumps(obj,allow_nan=False,sort_keys=True,indent=2)+'\n').encode())
    print('paired Myr',duration,'final primary',summary['4-4-to-8-4-4']['max_fraction'],len(summary['4-4-to-8-4-4']['failed']),'supplementary',obj['failed_auxiliary_comparisons'],'of',len(allchecks))
    if '--seal' in sys.argv:
        assert (HERE/'RESULTS.md').is_file() and not (HERE/'__pycache__').exists()
        files={path.name:sha(path) for path in sorted(HERE.iterdir()) if path.is_file() and path.name!='seal.json'}
        store('seal.json',(json.dumps({'files':files},indent=2,sort_keys=True)+'\n').encode())
        print('sealed',len(files),sha(HERE/'seal.json'))


if __name__=='__main__':check()
