import csv
import json
import math
import sys
from statistics import NormalDist, median
from field import HERE, pin, sha, np, save
from observe import table

CLOCK=HERE.parent/'mts-pal5-shared-clock-20261122'
pin(CLOCK/'shared_clock.py','e4a0aa7f4a9d2c33afee9e355d08d9759ebc9ed852b2a08018aba3176160e201')
sys.path.insert(0,str(CLOCK))
from shared_clock import segments

CAT=HERE.parent/'mts-pal5-measured-rrl-20261122'
cat_manifest=json.loads(pin(CAT/'seal.json','e94eaf7948ea6a477eecd1124486c2df30a70144d092ebd7caf61c4176b35a55').read_bytes())
cat_file=pin(CAT/'kuzma-table4.txt',cat_manifest['kuzma-table4.txt'])
errors=[float(row.split()[7]) for row in cat_file.read_text().splitlines() if row.strip() and not row.startswith('#')]
assert len(errors)==109 and min(errors)>0
SIGMAS=(min(errors),median(errors))


def read(grid):
    with (HERE/f'releases-{grid}.csv').open() as handle:
        raw=list(csv.DictReader(handle))
    vals={(row['arm'],float(row['distance_kpc']),row['case'],row['flow'],float(row['date_from_581_Myr']),row['tail']):row for row in raw}
    assert len(vals)==len(raw)==144
    return vals


def series(vals,key,col):
    dates=sorted({idx[4] for idx in vals})
    return np.array([[[float(vals[(*key,flow,date,tail)][col]) for tail in ('inner','outer')] for date in dates] for flow in ('forward','reverse')])


def acc(delta,sigma):
    return 100*NormalDist().cdf(delta/(2*sigma))


def assess(grid):
    vals=read(grid)
    summary=[];details=[]
    dates=sorted({idx[4] for idx in vals})
    for key in sorted({idx[:3] for idx in vals}):
        arm,distance,case=key
        fwd,rev=series(vals,key,'vlos_kms')
        full=fwd-rev
        sep=np.linalg.norm(full,axis=1)
        sampled=min((np.linalg.norm(first-second),one,two) for one,first in enumerate(fwd) for two,second in enumerate(rev))
        chord,frac1,frac2,start,end=min((*segments(fwd[one],fwd[one+1],rev[two],rev[two+1]),one,two) for one in (0,1) for two in (0,1))
        ds=[dates[start]+frac1*(dates[start+1]-dates[start]),dates[end]+frac2*(dates[end+1]-dates[end])]
        assert chord<=sampled[0]+1e-12
        xyz=np.stack([np.diff(series(vals,key,col),axis=0)[0] for col in ('x_kpc','y_kpc','z_kpc')],axis=-1)
        other=series(vals,(arm,distance,'old_sign_only'),'vlos_kms')
        for ind,date in enumerate(dates):
            common,odd=full[ind].sum()/math.sqrt(2),np.diff(full[ind])[0]/math.sqrt(2)
            assert abs(common**2+odd**2-sep[ind]**2)<1e-14
            details.append(dict(arm=arm,distance_kpc=distance,case=case,date_Myr=date,
                age_Myr=vals[(*key,'forward',date,'inner')]['age_at_600_Myr'],
                inner_split_kms=full[ind,0],outer_split_kms=full[ind,1],
                common_kms=common,difference_kms=odd,separation_kms=sep[ind],
                max_position_pc=1e3*np.linalg.norm(xyz[ind],axis=1).max(),
                early_signed_field_contribution_kms=np.linalg.norm(full[ind]-other[0,ind]+other[1,ind])))
        for sig in SIGMAS:
            summary.append(dict(arm=arm,distance_kpc=distance,case=case,sigma_kms=sig,
                known_center_pct=acc(sep[1],sig),known_best_of_three_pct=acc(max(sep),sig),
                fixed_nodes_worst_accuracy_upper_pct=acc(sampled[0],sig),
                direct_node_forward_Myr=dates[sampled[1]],direct_node_reverse_Myr=dates[sampled[2]],
                interpolated_difference_kms=chord,interpolated_worst_accuracy_upper_pct=acc(chord,sig),
                witness_forward_Myr=ds[0],witness_reverse_Myr=ds[1]))
    table(f'noise-{grid}.csv',summary);table(f'contrast-{grid}.csv',details)


def compare(low,high):
    coarse,fine=read(low),read(high)
    rows=[]
    for key in sorted({idx[:3] for idx in fine}):
        for col in ('ra_deg','dec_deg','vlos_kms'):
            signed=lambda vals: np.diff(series(vals,key,col),axis=0)[0]
            first,last=signed(coarse),signed(fine)
            fraction=np.linalg.norm(first-last)/np.linalg.norm(last)
            rows.append(dict(arm=key[0],distance_kpc=key[1],case=key[2],quantity=col,
                fractional_change=fraction,pass_0p005=bool(fraction<.005)))
    table(f'refine-{low}-to-{high}.csv',rows)
    print(low,high,'failures',sum(not row['pass_0p005'] for row in rows),'max',max(row['fractional_change'] for row in rows))


if __name__=='__main__':
    for grid in sys.argv[1:]:
        if ':' in grid:compare(*grid.split(':'))
        else:assess(grid)
