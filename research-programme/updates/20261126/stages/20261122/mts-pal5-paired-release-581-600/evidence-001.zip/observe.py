import csv
import io
import json
import sys
from field import HERE, JOIN, manifest, pin, sha, save, np, checkstop

pin(JOIN/'tracers.py',manifest['tracers.py'])
from tracers import Segment, anchors, observed, CONV, PAL, LATE
from field import INVERSE


def guard():
    checkstop()
    assert not any((root/'STOP-REQUESTED').exists() for root in (JOIN,PAL,INVERSE))

DIST = (20.9,22.05,23.2)
SIGNS = ('forward','reverse')


def load_segments(arm,factor,base,mult):
    counts=(round(192*base*mult*88/70),192*base*mult,192*mult)
    if factor==8:
        paths=[]
        for leg in ('before','middle','late'):
            name=f'fine-{leg}-{arm}'
            note=json.loads((HERE/(name+'.json')).read_bytes())
            paths.append(pin(HERE/(name+'.npz'),note['packet']))
    else:
        name=f'fields-{factor}-{arm}'
        receipt=json.loads((HERE/(name+'.json')).read_bytes())
        assert receipt['code']==sha(HERE/'field.py') and receipt['protocol']==sha(HERE/'PROTOCOL.md')
        med=f'early-{70*factor}-{arm}.npz';late=f'potential-{18*factor}.npz'
        paths=[pin(HERE/(name+'.npz'),receipt['data']),pin(JOIN/med,manifest[med]),pin(PAL/late,LATE[late])]
    segments=[]
    for path,steps in zip(paths,counts):
        with np.load(path) as bank:segments.append(Segment(bank,arm,steps))
    return segments


def table(name,rows):
    stream=io.StringIO()
    writer=csv.DictWriter(stream,rows[0],lineterminator='\n')
    writer.writeheader();writer.writerows(rows)
    save(name,stream.getvalue().encode())


def release(seg, initial, date, sign):
    center,velocity=seg.move(0,date,initial,sign)
    radial=center*[1,1,0]
    radial=radial/np.linalg.norm(radial,axis=1)[:,None]
    az=np.cross([0,0,1],radial)
    az=np.where((az*velocity).sum(axis=1)[:,None]<0,-az,az)
    offsets=np.array([0,-1,1])[None,:,None]
    pos=(center[:,None,:]+.060*offsets*radial[:,None,:]).reshape(-1,3)
    speed=(velocity[:,None,:]+CONV*offsets*az[:,None,:]).reshape(-1,3)
    return seg.move(date,seg.end,(pos,speed),sign)


def measure(factor, mult, step_factor=None):
    assert factor in (2,4,8) and mult in (1,2,4,8)
    base=step_factor or factor
    assert base in (2,4,8)
    obs=[]; checks=[]
    draws = [anchors(distance) for distance in DIST]
    final=tuple(np.stack([draw[col][0] for draw in draws]) for col in (0,1))
    for arm in ('reset','coupled'):
        checkstop();guard()
        before,middle,last=load_segments(arm,factor,base,mult)
        segments=(before,middle,last)
        state=final
        for seg in reversed(segments):state=seg.move(seg.end,0,state,'mean')
        initial=state
        for seg in segments:state=seg.move(0,seg.end,state,'mean')
        closure=max(abs(one-two).max() for one,two in zip(final,state))
        assert closure<1e-9
        for case in ('both','old_sign_only'):
            for direction in SIGNS:
                checkstop();guard()
                sign=direction if case=='both' else 'mean'
                dates=before.end/2+np.array([-10.,0.,10.])
                releases=[release(before,initial,date,sign) for date in dates]
                state=tuple(np.concatenate([pair[field] for pair in releases]) for field in (0,1))
                for seg in (middle,last):state=seg.move(0,seg.end,state,direction)
                pos,vel=[arr.reshape(3,len(DIST),3,3) for arr in state]
                pos=pos-pos[:,:,:1]+final[0][None,:,None,:]
                vel=vel-vel[:,:,:1]+final[1][None,:,None,:]
                sky=observed(pos.reshape(-1,3),vel.reshape(-1,3)).reshape(pos.shape)
                sky=sky-sky[:,:,:1]
                for ind,date in enumerate(dates):
                    for idx,distance in enumerate(DIST):
                        for tail,component in enumerate(('inner','outer'),1):
                            value=sky[ind,idx,tail];xyz=pos[ind,idx,tail]-pos[ind,idx,0]
                            obs.append(dict(arm=arm,distance_kpc=distance,case=case,flow=direction,
                                date_from_581_Myr=date,age_at_600_Myr=sum(seg.end for seg in segments)-date,
                                tail=component,ra_deg=value[0],dec_deg=value[1],vlos_kms=value[2],
                                x_kpc=xyz[0],y_kpc=xyz[1],z_kpc=xyz[2]))
                print(factor,mult,arm,case,direction,flush=True)
        for tag,seg in zip(('581-586','586-590','590-600'),segments):
            checks.append(dict(arm=arm,segment=tag,min_kpc=seg.minr,max_kpc=seg.maxr,
                duration_Myr=seg.end,mean_return=closure,nsteps=seg.steps))
    tag=f'{factor}-{mult}' if step_factor is None else f'{factor}-{mult}-{base}'
    table(f'releases-{tag}.csv',obs);table(f'controls-{tag}.csv',checks)


if __name__=='__main__':
    for spec in sys.argv[1:]:measure(*(int(part) for part in spec.split('-')))
