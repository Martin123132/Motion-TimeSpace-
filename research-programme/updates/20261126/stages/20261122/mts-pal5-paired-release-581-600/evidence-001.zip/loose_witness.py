from field import np,HERE
from observe import load_segments,anchors,observed,table
from assess import acc,SIGMAS
from escape_control import flight,records


def run():
    output=[];gates=[]
    lag={row['arm']:float(row['lag_Myr'])/2 for row in records('lag-frozen.csv')}
    final=tuple(arr[:1] for arr in anchors(22.05))
    cache={}
    for factor,mult in [(4,1),(4,2),(8,2)]:
        tag=f'{factor}-{mult}'
        clocks=records(f'passages-{tag}.csv')
        for arm in ('reset','coupled'):
            segments=load_segments(arm,factor,4,mult)
            stamps={row['flow']:float(row['passage_Myr']) for row in clocks if row['arm']==arm}
            init=final
            for seg in reversed(segments):init=seg.move(seg.end,0,init,'mean')
            obs=[]
            for sign,shift in [('forward',0.),('reverse',lag[arm])]:
                pos,vel,diagnostics=flight(segments,init,stamps[sign]+shift,sign)
                assert np.max(diagnostics['norm_error'])<.005
                sky=observed(pos[-1]-pos[-1,:1]+final[0],vel[-1]-vel[-1,:1]+final[1])
                obs.append(sky[1:,2]-sky[0,2])
            delta=obs[0]-obs[1];cache[tag,arm]=delta
            output.append(dict(grid=tag,arm=arm,lag_Myr=lag[arm],delta_inner_kms=delta[0],delta_outer_kms=delta[1],
                distance_kms=np.linalg.norm(delta),worst_accuracy_upper_best_error_pct=acc(np.linalg.norm(delta),min(SIGMAS))))
            print(tag,arm,flush=True)
    for low,high in [('4-1','4-2'),('4-2','8-2')]:
        for arm in ('reset','coupled'):
            one,two=cache[low,arm],cache[high,arm];frac=np.linalg.norm(one-two)/np.linalg.norm(two)
            gates.append(dict(low=low,high=high,arm=arm,fraction=frac,passed=bool(frac<.005)))
    table('loose-witness.csv',output);table('loose-witness-checks.csv',gates)


if __name__=='__main__':run()
