import csv
import json
from release_noise import HERE, ROOT, run, save, sha

def verify():
    run()
    source=ROOT/"mts-environmental-tidal-response-586-590-20261122"
    assert sha(source/"seal.json")=="8cf627c64cf174e6be95088daf4c9d9d76f3c061e3b0ca9f71e749ba4de528d9"
    files=json.loads((source/"seal.json").read_bytes())["files"]
    for name in ("STREAM-ANSWER.md","stream-release-recheck.csv","stream-precision-leverage.csv"):
        assert sha(source/name)==files[name]
    with (HERE/"two-tail-velocity.csv").open(newline="") as stream:
        results=list(csv.DictReader(stream))
    keys=lambda row:(row["preparation"],row["distance_kpc"],row["injected"],row["noise"])
    fine={keys(row):row for row in results if row["grid"]=="4-2"}
    coarse={keys(row):row for row in results if row["grid"]=="4-1"}
    assert len(fine)==len(coarse)==24 and fine.keys()==coarse.keys()
    for key,row in fine.items():
        assert float(row["profiled_centre_d"])<=float(row["centre_d"])+1e-13
        assert float(row["maximum_date_known_d"])>=float(row["centre_d"])
        assert float(row["date_revealed_accuracy_ceiling_pct"])<50.274
    diffs=[abs(float(row["date_revealed_accuracy_ceiling_pct"])-float(coarse[key]["date_revealed_accuracy_ceiling_pct"])) for key,row in fine.items()]
    names=("RESULTS.md","release_noise.py","verify.py","two-tail-velocity.csv")
    payload={"files":{name:sha(HERE/name) for name in names},"stream_summary_seal":sha(source/"seal.json"),
        "max_coarse_to_fine_accuracy_change_pp":max(diffs),"rows_checked":len(results)}
    save("seal.json",(json.dumps(payload,sort_keys=True,indent=2)+"\n").encode())
    assert all(sha(HERE/name)==digest for name,digest in json.loads((HERE/"seal.json").read_bytes())["files"].items())
    print("stream sealed",sha(HERE/"seal.json"),"coarse/fine pp",max(diffs))
if __name__=="__main__":
    verify()
