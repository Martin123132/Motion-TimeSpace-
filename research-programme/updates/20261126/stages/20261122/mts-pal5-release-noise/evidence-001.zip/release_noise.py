from pathlib import Path
from statistics import NormalDist, median
from math import dist
import csv
import hashlib
import io
import json

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
JOIN = ROOT / "mts-pal5-joined-flow-586-600-20261122"
CAT = ROOT / "mts-pal5-measured-rrl-20261122"
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def pinned(folder, seal, name):
    assert sha(folder / "seal.json") == seal
    path = folder / name
    assert sha(path) == json.loads((folder / "seal.json").read_bytes())[name]
    return path

def save(name, payload):
    path = HERE / name
    if path.exists():
        assert path.read_bytes() == payload
    else:
        with path.open("xb") as target:
            target.write(payload)

def closest(target, left, right):
    velocity = [end - start for start, end in zip(left, right)]
    denom = sum(val**2 for val in velocity)
    fraction = min(1., max(0., sum((val-start)*speed for val,start,speed in zip(target,left,velocity))/denom)) if denom else 0.
    return dist(target,[val+fraction*speed for val,speed in zip(left,velocity)]), fraction

def run():
    joined = "86d9b1296c253b14a04e475339a9cbf71f84fed201749a234af4892b715576b7"
    catalog = pinned(CAT, "e94eaf7948ea6a477eecd1124486c2df30a70144d092ebd7caf61c4176b35a55","kuzma-table4.txt")
    errors = [float(line.split()[7]) for line in catalog.read_text().splitlines() if line.strip() and not line.startswith("#")]
    assert len(errors) == 109 and min(errors) > 0
    assert closest((2,1),(0,0),(4,0)) == (1.,.5)
    assert closest((2,1),(0,0),(1,0)) == (2**.5,1.)
    verdict = json.loads(pinned(JOIN,joined,"verdict-4-2.json").read_bytes())
    assert not verdict["failures"] and abs(verdict["early_Myr"]+verdict["late_Myr"]-verdict["duration_Myr"]) < 1e-9
    results = []
    for grid in ("4-1","4-2"):
        path = pinned(JOIN,joined,"escapes-"+grid+".csv")
        with path.open(newline="") as stream:
            data = list(csv.DictReader(stream))
        dates = sorted({float(row["release"]) for row in data})
        vals = {(row["arm"],float(row["distance"]),row["flow"],float(row["release"]),row["tail"]): float(row["vlos_kms"]) for row in data}
        assert len(vals) == len(data) == 72 and len(dates) == 3 and all(abs(last-first-10)<1e-8 for first,last in zip(dates,dates[1:]))
        for arm,radius in sorted({pair[:2] for pair in vals}):
            def pair(flow,date):
                return [vals[arm,radius,flow,date,tail] for tail in ("inner","outer")]
            separation = [dist(pair("forward",date),pair("reverse",date)) for date in dates]
            for injected,other in (("forward","reverse"),("reverse","forward")):
                target = pair(injected,dates[1])
                residual,shift = min((resid,dates[part]-dates[1]+10*frac) for part in (0,1)
                    for resid,frac in [closest(target,pair(other,dates[part]),pair(other,dates[part+1]))])
                assert residual <= separation[1]+1e-14
                for noise,sigma in (("best",min(errors)),("median",median(errors))):
                    results.append(dict(grid=grid,preparation=arm,distance_kpc=radius,injected=injected,
                        noise=noise,sigma_kms=sigma,centre_d=separation[1]/sigma,best_common_shift_Myr=shift,
                        profiled_centre_d=residual/sigma,maximum_date_known_d=max(separation)/sigma,
                        date_revealed_accuracy_ceiling_pct=100*NormalDist().cdf(max(separation)/(2*sigma))))
    assert len(results)==48
    out=io.StringIO()
    writer=csv.DictWriter(out,results[0],lineterminator="\n")
    writer.writeheader();writer.writerows(results)
    save("two-tail-velocity.csv",out.getvalue().encode())
    print("duration",verdict["duration_Myr"],"errors",min(errors),median(errors))
    for arm in ("reset","coupled"):
        group=[row for row in results if row["grid"]=="4-2" and row["noise"]=="best" and row["preparation"]==arm]
        nom=[row for row in group if row["distance_kpc"]==22.05]
        print(arm,"max known-time accuracy",max(row["date_revealed_accuracy_ceiling_pct"] for row in group),
              "nominal centre, profile, shift",[(row["centre_d"],row["profiled_centre_d"],row["best_common_shift_Myr"]) for row in nom])
if __name__ == "__main__":
    run()
