from common import *

def start_rate(calc,p):
    space=calc.s
    rate=np.zeros_like(p.real)
    radial=calc.kappa*np.imag(p[:-1].conj()*p[1:])/np.diff(space.r)[:,None]
    rate[:-1]-=radial/space.dr[:-1,None];rate[1:]+=radial/space.dr[1:,None]
    angular=calc.kappa*np.imag(p[:,:-1].conj()*p[:,1:])*(1-space.mf[1:-1]**2)/np.diff(space.mu)/space.r[:,None]**2
    rate[:,:-1]-=angular/space.dm[:-1];rate[:,1:]+=angular/space.dm[1:]
    return calc.measures(calc.grav(rate))

def evolve(calc,kin,model,state,dt,steps,which):
    guard()
    p=calc.wave(state)
    a=np.zeros_like(p);net=np.zeros_like(p.real)
    rho0=abs(p)**2
    norm=np.sum(calc.weights*rho0)
    dphi=calc.drive(model) if model in MODELS else np.zeros_like(net)
    w=calc.grav(rho0);dw=np.zeros_like(w)
    phase=-.5j*dt*CONV**2/calc.kappa
    initial_rate=start_rate(calc,p)
    rows=[];checks=[]
    for step in range(1,steps+1):
        guard()
        p,a=kick(p,a,calc.host+w,dphi+dw,phase)
        p,a=kin.radial(p,a,net)
        p,a=kin.angular(p,a,net)
        p,a=kin.radial(p,a,net)
        rho=abs(p)**2
        w=calc.grav(rho)
        dw=calc.grav(net)
        p,a=kick(p,a,calc.host+w,dphi+dw,phase)
        if step not in which:continue
        direct=2*(p.conj()*a).real+abs(a)**2
        normerr=abs(np.sum(calc.weights*rho)/norm-1)
        massbias=abs(np.sum(calc.weights*net))/max(np.sum(calc.weights*abs(net)),1e-300)
        direct_bias=np.sum(calc.weights*abs(direct-net))/max(np.sum(calc.weights*abs(net)),1e-300)
        assert normerr<1e-9 and massbias<1e-10
        obs=calc.measures(dw)
        control=calc.measures(calc.grav(direct))
        abs_old=calc.measures(calc.grav(rho-rho0))
        obs_err=np.max(abs(control-obs)/np.maximum(abs(obs),1e-250))
        assert np.isfinite(direct_bias) and np.isfinite(obs_err)
        checks.append(dict(step=step,time_Myr=step*dt,normerr=normerr,massbias=massbias,density_crosscheck=direct_bias,
            obs_crosscheck=obs_err))
        for name,val,base,rate in zip(NAMES,obs,abs_old,initial_rate):
            rows.append(dict(step=step,time_Myr=dt*step,observable=name,drive_difference=val,
                baseline_wave_change=base,stellar_wave_change=base+val,common_launch_rate=rate))
    return rows,checks

def run():
    assert sha(HERE/'frozen-curvatures.csv')=='33f93e640a9b1c04294eaa4ec880d97a9d904c9e3bbd6797b7c34eb8f326a427'
    level=int(sys.argv[1]);dt=float(sys.argv[2]);steps=int(sys.argv[3])
    models=list(MODELS) if sys.argv[4]=='both' else [sys.argv[4]]
    states=STATES if sys.argv[5]=='all' else [sys.argv[5]]
    which={1,steps,*[2**i for i in range(12) if 2**i<=steps]}
    calc=Stage(level);kin=Kinetic(calc.s,calc.kappa,dt)
    for model in models:
        assert model in (*MODELS,'equal')
        for state in states:
            assert state in STATES
            stamp=f'{level}-{dt:g}-{steps}-{model}-{state}'
            rows,checks=evolve(calc,kin,model,state,dt,steps,which)
            table('evolution-'+stamp+'.csv',rows)
            table('health-'+stamp+'.csv',checks)
            print(stamp,checks[-1],flush=True)
if __name__=='__main__':run()

