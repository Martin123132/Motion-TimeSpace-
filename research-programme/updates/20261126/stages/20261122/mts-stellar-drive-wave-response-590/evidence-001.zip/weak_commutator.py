from common import HERE, guard, np, table
from weak_flux import Weak, chebder, chebvander, roots_legendre
from numpy.polynomial import Polynomial

def compare(arm, amplified, order, width):
    data = Weak(arm, 80)
    centre = 8.18
    element = np.searchsorted(data.edges, centre) - 1
    if amplified:
        change = 0.12 * sum(data.co[:, element, 0] * chebvander([0.], len(data.co)-1)[0])
        data.co[0, element, 0] += change/2
        data.co[2, element, 0] -= change/2
        data.der = [chebder(data.co, count, axis=0) for count in range(4)]
    window = Polynomial([1., 0., -1.])**5
    def weight(radius, derivative):
        return window.deriv(derivative)((radius-centre)/width)/width**derivative
    cuts = np.unique(np.r_[centre-width, data.edges[(data.edges>centre-width)&(data.edges<centre+width)], centre+width])
    nodes, weights = roots_legendre(order)
    current, independent, scale = 0., 0., 0.
    norm = 1/(2*data.deg+1)
    for left, right in zip(cuts[:-1], cuts[1:]):
        radius = (left+right)/2 + (right-left)*nodes/2
        quadrature = weights*(right-left)/2
        index = np.searchsorted(data.edges, (left+right)/2)-1
        span = data.edges[index+1]-data.edges[index]
        coord = 2*(radius-data.edges[index])/span-1
        amp, slope = [chebvander(coord,len(raw)-1)@raw[:,index,:]*(2/span)**number
                      for number,raw in enumerate(data.der[:2])]
        density = abs(amp)**2
        terms = 2*data.k2*(weight(radius,2)*(abs(slope)**2@norm)
                -.25*weight(radius,4)*(density@norm)
                +weight(radius,1)/radius**3*(density@(norm*data.deg*(data.deg+1))))
        independent += quadrature@terms
        scale += quadrature@abs(terms)
        current += quadrature@(weight(radius,1)*data.fields(radius)[0][:,0])
    face = data.edges[1:-1]
    mask = (face>cuts[0])&(face<cuts[-1])
    stress, jump, _ = data.interfaces()
    surfaces = weight(face[mask],1)@stress[mask,0]-weight(face[mask],2)@jump[mask,0]
    residual = abs((current+surfaces)/independent-1)
    assert residual < 1e-7, (arm,amplified,residual)
    well_conditioned = abs(independent)>1e-5*scale
    omitted = abs(current/independent-1)
    if amplified:
        assert omitted > .005, omitted
    return dict(arm=arm,test='injected_element_bump' if amplified else 'original_wave',order=order,
                width_kpc=width,conditioning_gate=well_conditioned,
                commutator=independent,bulk_flux=current,surface=surfaces,with_surfaces_relative_error=residual,
                without_surfaces_relative_error=omitted,absolute_integrand_scale=scale)

if __name__=='__main__':
    guard()
    rows=[compare(arm,bump,order,width) for arm in ('reset','coupled')
          for bump in (False,True) for order in (24,40) for width in (1.36,4.)]
    assert all(row['conditioning_gate'] for row in rows if row['width_kpc']==4.)
    table('weak-commutator.csv',rows)
