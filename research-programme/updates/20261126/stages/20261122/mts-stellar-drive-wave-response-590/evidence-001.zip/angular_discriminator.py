from common import Gravity, HERE, MODELS, PREV, R_GROUPS, SOURCE, STATES, checked, guard, np, potential, read, table
from scipy.special import roots_legendre

def probe(field, order):
    data=[]
    knots,wt=roots_legendre(order)
    for radius in R_GROUPS:
        top=.4; sphere=np.hypot(radius,top)
        angle=np.arctan2(top,radius); ang=angle*(knots+1)/2
        radial=(radius+sphere)/2+(sphere-radius)*knots/2
        R=np.r_[radius,radius,sphere,sphere*np.cos(ang),radial]
        z=np.r_[top,0.,0.,sphere*np.sin(ang),np.zeros(order)]
        phi,dr,dz=field(R,z)
        torque=R*dz-z*dr
        angle_integral=angle*(wt@torque[3:3+order])/2
        radial_integral=(sphere-radius)*(wt@dr[3+order:])/2
        direct=phi[0]-phi[2]
        via_radial=phi[0]-phi[1]-radial_integral
        assert max(abs(direct-angle_integral),abs(direct-via_radial))<2e-8
        data.append((direct,angle_integral,via_radial,torque[0]))
    return np.array(data)

def run():
    guard()
    profile=[];differences=[]
    figs=read(checked(PREV,'phase-weights.csv'))
    for grid,order,angular in [('fine',12,64),('finer',18,90)]:
        def plummer(R,z):
            fac=(R*R+z*z+4.)**-.5
            return -1e5*fac,1e5*R*fac**3,1e5*z*fac**3
        spherical=probe(plummer,10)
        assert abs(spherical).max()<1e-9
        cases={'spherical_control':spherical}
        for state in STATES:
            obj=Gravity(state,order,angular)
            cases[state]=probe(lambda R,z:obj.evaluate(R,z)[0][:,:3].T,10)
        for name,parts in MODELS.items():
            def disk(R,z):
                dr=np.zeros_like(R);dz=dr.copy()
                from common import G
                for mass,scale,height in parts:
                    h=np.hypot(z,height)
                    inv=2.32e7*(R*R+(scale+h)**2)**-1.5
                    dr+=G*mass*R*inv;dz+=G*mass*(scale+h)*z/h*inv
                return potential(parts,R,z),dr,dz
            cases[name]=probe(disk,10)
        for name,values in cases.items():
            for radius,row in zip(R_GROUPS,values):
                profile.append(dict(grid=grid,field=name,R_kpc=radius,height_kpc=.4,angular_potential=row[0],angular_integral=row[1],vertical_minus_radial=row[2],torque=row[3]))
        for arm in ('reset','coupled'):
            assert abs(cases[arm+'_forward']-cases[arm+'_reverse']).max()<1e-10
        diff=cases['reset_forward']-cases['coupled_forward']
        for height in (0,10,20):
            sig=[float(row['sigma']) for row in figs if int(row['Zsun_pc'])==height]
            for idx,radius in enumerate(R_GROUPS):
                differences.append(dict(grid=grid,Zsun_pc=height,R_kpc=radius,delta_equal_radius_potential=diff[idx,0],delta_torque=diff[idx,3],
                         delta_over_vertical_error=diff[idx,0]/sig[idx],stellar_model_spread=cases['Pouliasis_I'][idx,0]-cases['Pouliasis_II'][idx,0]))
    count=len(differences)//2
    for first,second in zip(differences[:count],differences[count:]):
        for key in ('delta_equal_radius_potential','delta_torque'):
            assert abs(first[key]/second[key]-1)<.005
    table('equal-radius-null.csv',profile);table('equal-radius-discrimination.csv',differences)
    print('max optimistic',max(abs(row['delta_over_vertical_error']) for row in differences),differences[count+3])
if __name__=='__main__':run()
