from common import *
from stress import internal_derivative,second_density
from scipy.sparse import csr_matrix

def overlap(old,new,volume):
    measure=(lambda v:v**3/3) if volume else (lambda v:v)
    old,new=measure(old),measure(new)
    assert abs(old[0]-new[0])+abs(old[-1]/new[-1]-1)<1e-12
    rows=[];cols=[];weights=[]
    for i,(left,right) in enumerate(zip(new[:-1],new[1:])):
        first=max(0,old.searchsorted(left,side='right')-1)
        last=min(len(old)-2,old.searchsorted(right))
        for j in range(first,last+1):
            length=min(right,old[j+1])-max(left,old[j])
            if length>0:
                rows.append(i);cols.append(j)
                weights.append(length/(old[j+1]-old[j] if volume else right-left))
    return csr_matrix((weights,(rows,cols)),shape=(len(new)-1,len(old)-1))

class Smooth(Stage):
    def __init__(self,level):
        dx=.08/2**(level-1);angular=128*2**(level-1)
        with np.load(checked(FIX,'mass-3-4.npz')) as bank:
            old=bank['rf'];oldang=bank['mf'];mass=bank['mass'][1]
        mid=24.
        rad=np.linspace(0.,mid,round(mid/dx)+1)
        at=np.arctan((old[-1]-mid)/mid)
        tail=mid+mid*np.tan(np.linspace(0.,at,int(np.ceil(at*mid/dx))+1))
        rf=np.r_[rad,tail[1:]];rf[-1]=old[-1]
        mf=np.linspace(0.,1.,angular+1)
        s=self.s=Space(rf,mf)
        rm=overlap(old,rf,True);mm=overlap(oldang,mf,False)
        transferred=(mm@(rm@mass).T).T
        assert min(transferred.min(),mass.min())>=-1e-10
        assert abs(np.sum(transferred*s.dm)/np.sum(mass*np.diff(oldang))-1)<1e-12
        self.host=s.poisson(4*np.pi*G*transferred)
        self.R=s.r[:,None]*np.sqrt(1-s.mu**2);self.z=s.r[:,None]*s.mu
        self.rad_subset=np.flatnonzero((s.r>6.4)&(s.r<9.6))
        self.mu_subset=np.flatnonzero(s.mu<.105)
        self.weights=4*np.pi*s.dr[:,None]*s.dm
        self.norms=json.loads((SOURCE/'occupation.json').read_bytes())
        self.h=np.array([1/np.mean(1/group[:,0]) for group in BINS])
        with np.load(checked(FIX,'drives-1-3.npz')) as d:self.kappa=float(d['kappa'])

def run():
    rows=[];tests=[]
    for level in (1,2,3):
        guard();calc=Smooth(level)
        r=calc.s.r[:,None];width=6.
        p=np.broadcast_to(r*np.exp(-.5*(r/width)**2),calc.host.shape).astype(complex)
        exact=p.real**2*calc.kappa**2/width**4*(2*(r/width)**2-3)
        expected=calc.measures(calc.grav(exact));measured=calc.measures(calc.grav(second_density(calc,p,internal_derivative(calc,p))))
        for name,num,ref in zip(NAMES,measured,expected):
            tests.append(dict(level=level,observable=name,manufactured=num,analytic_density=ref,relative_error=abs(num/ref-1)))
        for arm in ('reset','coupled'):
            p=calc.wave(arm+'_forward')
            norm=np.sum(calc.weights*abs(p)**2)
            assert abs(norm/calc.norms[arm+'_forward']-1)<.005
            kinetic=calc.measures(calc.grav(second_density(calc,p,internal_derivative(calc,p))))
            own=calc.measures(calc.grav(calc.curvature(p,calc.grav(abs(p)**2))))
            for model,host in [('original',calc.host),*[(name,potential(parts,calc.R,calc.z)) for name,parts in MODELS.items()]]:
                ordinary=calc.measures(calc.grav(calc.curvature(p,host)))
                launch=calc.measures(calc.grav(abs(p)**2));fg=calc.measures(host)
                diff=calc.measures(calc.grav(calc.curvature(p,host-calc.host)))
                for i,name in enumerate(NAMES):
                    rows.append(dict(level=level,arm=arm,host=model,observable=name,kinetic=kinetic[i],self_gravity=own[i],ordinary=ordinary[i],
                        total=kinetic[i]+own[i]+ordinary[i],relative_drive_curvature=diff[i],wave_readout=launch[i],foreground_readout=fg[i]))
    table('smooth-stress.csv',rows);table('smooth-gaussian.csv',tests)

def window(level,dt,steps,models,states):
    from evolve import evolve
    calc=Smooth(level);kin=Kinetic(calc.s,calc.kappa,dt)
    for model in models:
        for state in states:
            stamp=f'smooth{level}-{dt:g}-{steps}-{model}-{state}'
            rows,checks=evolve(calc,kin,model,state,dt,steps,{1,steps,*[2**i for i in range(12) if 2**i<=steps]})
            table('evolution-'+stamp+'.csv',rows);table('health-'+stamp+'.csv',checks)
            print(stamp,flush=True)
if __name__=='__main__':
    if len(sys.argv)==1:run()
    else:window(int(sys.argv[1]),float(sys.argv[2]),int(sys.argv[3]),MODELS if sys.argv[4]=='both' else [sys.argv[4]],STATES if sys.argv[5]=='all' else [sys.argv[5]])

