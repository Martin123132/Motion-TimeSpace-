from common import HERE, PREV, SOURCE, G, R_GROUPS, checked, np, read, table, take_bins

def radial_bound(target,units):
    values=[(0.,-1,-1)]
    for right in range(len(target)):
        values.append((-target[right]/units[right],-1,right))
        for left in range(right):
            values.append(((target[left]-target[right])/(units[left]+units[right]),left,right))
    return max(values)

def run():
    samples=take_bins(np.loadtxt(checked(PREV,'figure3-stars.csv'),delimiter=',',skiprows=1),
                      np.loadtxt(checked(PREV,'figure3-native.csv'),delimiter=',',skiprows=1))
    radii=[group[:,0] for group in samples]
    harmonic=np.array([1/np.mean(1/group) for group in radii])
    shell=np.array([radii[0].min()/2]+[(before.max()+after.min())/2 for before,after in zip(radii,radii[1:])])
    assert all(a.max()<b.min() for a,b in zip(radii,radii[1:]))
    radial_response=np.array([G*np.mean((group[:,None]>shell)/group[:,None],axis=0) for group in radii])
    vert=G*(1/np.maximum(R_GROUPS[:,None],shell)-1/np.maximum(np.hypot(R_GROUPS,.4)[:,None],shell))
    fields=read(checked(PREV,'fields.csv'));figures=read(checked(PREV,'phase-weights.csv'))
    output=[];shells=[];profile=[]
    for lvl in ('2','3'):
        loft=read(checked(SOURCE,'field-fine.csv' if lvl=='2' else 'field-finer.csv'))
        heights=lambda state: np.array([float(row['phi_rise']) for row in loft if row['Z_kpc']=='0.4' and row['state']==state])
        for arm in ('reset','coupled'):
            assert np.allclose(heights(arm+'_forward'),heights(arm+'_reverse'),rtol=1e-13,atol=0)
        target_z=heights('reset_forward')-heights('coupled_forward')
        for variant in dict.fromkeys(row['variant'] for row in fields if row['method']=='stars_squared_speed'):
            get=lambda arm: [row for row in fields if (row['level'],row['arm'],row['method'],row['variant'])==(lvl,arm,'stars_squared_speed',variant)]
            reset,inherited=get('reset'),get('coupled')
            assert len(reset)==len(inherited)==len(radii)
            target_v=np.array([float(a['wave_v2'])-float(b['wave_v2']) for a,b in zip(reset,inherited)])
            v_width=np.array([2*float(row['vc_kms'])*float(row['error']) for row in reset])
            mass=harmonic*target_v/G; unit=harmonic*v_width/G
            eta,left,right=radial_bound(mass,unit)
            cumulative=np.maximum.accumulate(np.maximum(0.,mass-eta*unit))
            increments=np.diff(np.r_[0.,cumulative])
            assert min(increments)>=0
            displacement=radial_response@increments
            assert abs(max(abs(displacement-target_v)/v_width)-eta)<1e-12
            for index,radius in enumerate(shell):
                shells.append(dict(level=lvl,variant=variant,bin=index+1,inner_shell_kpc=radius,increment_Msun=increments[index],
                     cumulative_Msun=cumulative[index],target_equivalent_Msun=mass[index],
                     target_minus_witness_v2=target_v[index]-displacement[index],v2_unit=v_width[index]))
            for height in (0,10,20):
                error=np.array([float(row['sigma']) for row in figures if int(row['Zsun_pc'])==height])
                predicted=vert@increments
                vertical_error=max(abs(target_z-predicted)/error)
                upper=max(eta,vertical_error)
                output.append(dict(level=lvl,variant=variant,Zsun_pc=height,raw_radial=max(abs(target_v)/v_width),
                     raw_vertical=max(abs(target_z)/error),exact_radial_box=eta,active_inner_bin=left+1,active_outer_bin=right+1,
                     residual_vertical_box=vertical_error,joint_lower=eta,joint_witness_upper=upper,total_shell_Msun=cumulative[-1]))
                for radius,value,actual,scale in zip(R_GROUPS,target_z,predicted,error):
                    profile.append(dict(level=lvl,variant=variant,Zsun_pc=height,R_kpc=radius,wave_difference=value,
                            sphere_rise=actual,residual_over_error=(value-actual)/scale))
    table('preparation-shape-degeneracy.csv',output);table('spherical-witness.csv',shells);table('witness-vertical.csv',profile)
    print([row for row in output if (row['level'],row['variant'],row['Zsun_pc'])==('3','nominal',0)])
    print('all finest joint upper range',min(row['joint_witness_upper'] for row in output if row['level']=='3'),
          max(row['joint_witness_upper'] for row in output if row['level']=='3'))
if __name__=='__main__':run()
