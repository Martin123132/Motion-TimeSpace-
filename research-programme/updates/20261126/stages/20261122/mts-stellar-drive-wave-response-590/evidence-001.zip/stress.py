from common import *
from evolve import start_rate

def internal_derivative(calc,p):
    s=calc.s
    radial=np.diff(p,axis=0)/np.diff(s.r)[:,None]
    lap=np.empty_like(p)
    lap[1:-1]=(radial[1:]-radial[:-1])/s.dr[1:-1,None]
    lap[0]=(radial[0]-2*p[0]/s.dr[0])/s.dr[0]
    lap[-1]=(-2*p[-1]/s.dr[-1]-radial[-1])/s.dr[-1]
    angular=np.diff(p,axis=1)*(1-s.mf[1:-1]**2)/np.diff(s.mu)
    lap[:,:-1]+=angular/(s.dm[:-1]*s.r[:,None]**2)
    lap[:,1:]-=angular/(s.dm[1:]*s.r[:,None]**2)
    return .5j*calc.kappa*lap

def second_density(calc,p,dp):
    s=calc.s
    rate=np.zeros_like(p.real)
    radial=calc.kappa*np.imag(dp[:-1].conj()*p[1:]+p[:-1].conj()*dp[1:])/np.diff(s.r)[:,None]
    rate[:-1]-=radial/s.dr[:-1,None];rate[1:]+=radial/s.dr[1:,None]
    angular=calc.kappa*np.imag(dp[:,:-1].conj()*p[:,1:]+p[:,:-1].conj()*dp[:,1:])*(1-s.mf[1:-1]**2)/np.diff(s.mu)/s.r[:,None]**2
    rate[:,:-1]-=angular/s.dm[:-1];rate[:,1:]+=angular/s.dm[1:]
    return rate

def run():
    out=[]
    for level in (1,2,3):
        calc=Stage(level)
        for arm in ('reset','coupled'):
            guard();p=calc.wave(arm+'_forward')
            kinetic=internal_derivative(calc,p)
            selfphi=calc.grav(abs(p)**2)
            kinetic_rho=second_density(calc,p,kinetic)
            kin=calc.measures(calc.grav(kinetic_rho))
            selfrho=calc.curvature(p,selfphi)
            own=calc.measures(calc.grav(selfrho))
            common_rate=start_rate(calc,p)
            assert np.array_equal(start_rate(calc,p.conj()),-common_rate)
            for model,host in [('original',calc.host),*[(model,potential(parts,calc.R,calc.z)) for model,parts in MODELS.items()]]:
                hostrho=calc.curvature(p,host)
                ext=calc.measures(calc.grav(hostrho))
                fullrho=kinetic_rho+selfrho+hostrho
                full=calc.measures(calc.grav(fullrho))
                direct=second_density(calc,p,kinetic-1j*(CONV**2/calc.kappa)*p*(host+selfphi))
                test=calc.measures(calc.grav(direct))
                err=max(abs(test/full-1))
                assert err<1e-7 and max(abs((kin+own+ext)/full-1))<1e-7
                for name,first,k,s,b,val in zip(NAMES,common_rate,kin,own,ext,full):
                    out.append(dict(level=level,arm=arm,host=model,observable=name,forward_launch_rate=first,
                        kinetic_stress=k,self_gravity=s,ordinary_drive=b,total_curvature=val,cancellation=(abs(k)+abs(s)+abs(b))/abs(val)))
    table('absolute-stress.csv',out)
if __name__=='__main__':run()

