from common import *
from weak_flux import Weak
from scipy.special import gamma,gammainc,gammaincc
from numpy.polynomial import Polynomial

def exact(R,z,kappa):
    width=6.;beta=.29
    r=np.hypot(R,z);mu=z/r
    x=Polynomial([0.,1.]);eye=Polynomial([1.])
    rhs=2*x**2-3
    matter=[rhs+(rhs-4)*beta**2*x**4/5,(2*rhs-12)*beta*x**2+(rhs-4)*beta**2*x**4*(2/7),(rhs-4)*beta**2*x**4*(18/35)]
    phi=np.zeros_like(r);gradient=phi.copy()
    for ell,terms in zip((0,2,4),matter):
        inner=np.zeros_like(r);outer=inner.copy()
        for power,value in enumerate((x**2*terms).coef):
            if value==0:continue
            coef=value*width**2*(kappa/width**2)**2/width**power
            for m,out,fun,pre in [(power+ell,inner,gammainc,r**(-ell)),(power-ell-1,outer,gammaincc,r**(ell+1))]:
                shape=(m+1)/2
                out+=coef*pre*width**(m+1)*gamma(shape)*fun(shape,(r/width)**2)/2
        leg=lg.legval(mu,[0]*ell+[1])
        fac=-4*np.pi*G*leg/(2*ell+1)
        phi+=fac*(inner+outer)/r;gradient+=fac*(-(ell+1)*inner+ell*outer)/r**2
    return phi,gradient

def run():
    rows=[]
    for num in (56,90):
        data=Weak('reset',num);data.gaussian='angular'
        radii=np.array([2.2,4.5,7.29,8.179,18.,36.])
        R=radii*np.sqrt(1-np.linspace(0,.91,len(radii))**2);z=np.sqrt(np.maximum(0.,radii**2-R**2))
        got=data.solve(R,z,16)
        known=exact(R,z,np.sqrt(2*data.k2))
        for name,calc,target in zip(['potential','spherical_radial_gradient'],got,known):
            err=abs(calc/target-1)
            assert err.max()<1e-7
            for s,e in zip(radii,err):rows.append(dict(angular=num,observable=name,r_kpc=s,relative_error=e))
    table('weak-angular-control.csv',rows)
if __name__=='__main__':run()

