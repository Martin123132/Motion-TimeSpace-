from common import *
from numpy.polynomial.chebyshev import chebvander,chebder,chebval
from stress import internal_derivative

def run():
    faces=[];audits=[]
    with np.load(SOURCE/'launch.npz') as obj:
        edges=obj['edges'];knots=obj['knots'];modes=obj['degrees'];width=np.diff(edges)
        scale=(obj['mscale']/(4*np.pi*obj['length']))**.5
        inv=np.linalg.inv(chebvander(2*knots-1,len(knots)-1))
        for state in STATES:
            co=scale*np.einsum('ij,ejl->iel',inv,obj[state])
            dc=chebder(co,axis=0)
            left=chebval(-1.,co);right=chebval(1.,co)
            left_s=2*chebval(-1.,dc)/width[:,None]
            right_s=2*chebval(1.,dc)/width[:,None]
            assert np.allclose(left,scale*obj[state][:,0],rtol=1e-12,atol=1e-8)
            assert np.allclose(right,scale*obj[state][:,-1],rtol=1e-12,atol=1e-8)
            for i,rad in enumerate(edges[1:-1]):
                norm=np.linalg.norm
                amp=norm(right[i]-left[i+1])
                jump=norm(left_s[i+1]-right_s[i])
                typical=(norm(left_s[i+1])+norm(right_s[i]))/2
                faces.append(dict(state=state,R_kpc=rad,amplitude_jump=amp,slope_jump=jump,relative_slope_jump=jump/max(typical,1e-300),
                    local_amplitude=norm(right[i]),typical_slope=typical))
    for level in (1,2,3):
        calc=Stage(level)
        for arm in ('reset','coupled'):
            p=calc.wave(arm+'_forward');dp=internal_derivative(calc,p)
            norm=lambda x,w:(np.sum(w*abs(x)**2))**.5
            local=(calc.s.r>=7)&(calc.s.r<=9)
            audits.append(dict(level=level,arm=arm,kinetic_generator_Myr_inverse=norm(dp,calc.weights)/norm(p,calc.weights),
                solar_kinetic_generator_Myr_inverse=norm(dp[local],calc.weights[local])/norm(p[local],calc.weights[local])))
    table('element-interfaces.csv',faces);table('generator-norm.csv',audits)
if __name__=='__main__':run()

