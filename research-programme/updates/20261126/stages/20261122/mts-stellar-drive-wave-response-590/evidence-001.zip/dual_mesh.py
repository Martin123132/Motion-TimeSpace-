from common import *
from stress import internal_derivative,second_density
from scipy.linalg import eigh_tridiagonal
from scipy.linalg.lapack import zgttrf

class DualSpace(Space):
    def __init__(self,original):
        self.r=original.r.copy();self.mu=original.mu.copy()
        self.rf=np.r_[0.,(self.r[1:]+self.r[:-1])/2,original.rf[-1]]
        self.mf=np.r_[0.,(self.mu[1:]+self.mu[:-1])/2,1.]
        self.dr=np.diff(self.rf);self.dm=np.diff(self.mf)
        self.vol=self.dr*(self.rf[1:]**2+self.rf[:-1]*self.rf[1:]+self.rf[:-1]**2)/3
        self.sq=np.sqrt(self.dm)
        link=(1-self.mf[1:-1]**2)/np.diff(self.mu)
        diagonal=(np.r_[0.,link]+np.r_[link,0.])/self.dm
        eig,vectors=eigh_tridiagonal(diagonal,-link/(self.sq[:-1]*self.sq[1:]),lapack_driver='stev')
        assert abs(eig[0])<2e-6 and min(eig[1:])>0
        eig[0]=0.
        self.ev=eig;self.degree=2*eig/(np.sqrt(1+4*eig)+1)
        self.right=self.sq[:,None]*vectors;self.left=vectors.T/self.sq
        self.rlink=self.rf[1:-1]**2/np.diff(self.r)
        self.sys={}

class NodalKinetic(Kinetic):
    def __init__(self,space,kappa,dt):
        super().__init__(space,kappa,dt)
        lo=-self.kr*self.ks/space.dr[1:];hi=-self.kr*self.ks/space.dr[:-1]
        di=1+self.kr*(np.r_[1/space.r[0],self.ks]+np.r_[self.ks,1/(space.rf[-1]-space.r[-1])])/space.dr
        *self.rad,ok=zgttrf(lo,di,hi);assert ok==0

def initial_dp(calc,p):
    value=internal_derivative(calc,p)
    s=calc.s
    value[0]+=.5j*calc.kappa*p[0]*(2/s.dr[0]-1/s.r[0])/s.dr[0]
    value[-1]+=.5j*calc.kappa*p[-1]*(2/s.dr[-1]-1/(s.rf[-1]-s.r[-1]))/s.dr[-1]
    return value

class Comparison(Stage):
    def __init__(self,level):
        super().__init__(level)
        self.s=DualSpace(self.s)
        self.weights=4*np.pi*self.s.dr[:,None]*self.s.dm

def run():
    rows=[];tests=[]
    for level in (1,2,3):
        guard()
        calc=Comparison(level)
        r=calc.s.r[:,None]
        width=6.
        p=np.broadcast_to(r*np.exp(-.5*(r/width)**2),calc.host.shape).astype(complex)
        exact=p.real**2*calc.kappa**2/width**4*(2*(r/width)**2-3)
        target=calc.measures(calc.grav(exact))
        observed=calc.measures(calc.grav(second_density(calc,p,initial_dp(calc,p))))
        for name,val,ref in zip(NAMES,observed,target):tests.append(dict(level=level,observable=name,error=abs(val/ref-1),value=val,analytic=ref))
        for arm in ('reset','coupled'):
            p=calc.wave(arm+'_forward')
            norm=np.sum(calc.weights*abs(p)**2)
            assert abs(norm/calc.norms[arm+'_forward']-1)<.005
            kin=calc.measures(calc.grav(second_density(calc,p,initial_dp(calc,p))))
            selfterm=calc.measures(calc.grav(calc.curvature(p,calc.grav(abs(p)**2))))
            for model,host in [('original',calc.host),*[(name,potential(parts,calc.R,calc.z)) for name,parts in MODELS.items()]]:
                ext=calc.measures(calc.grav(calc.curvature(p,host)))
                changed=calc.measures(calc.grav(calc.curvature(p,host-calc.host)))
                for name,kinetic,own,ordinary,delta in zip(NAMES,kin,selfterm,ext,changed):
                    rows.append(dict(level=level,arm=arm,host=model,observable=name,kinetic=kinetic,self_gravity=own,ordinary=ordinary,
                        total=kinetic+own+ordinary,relative_drive_curvature=delta,occupation=norm))
    table('dual-gaussian.csv',tests);table('dual-stress.csv',rows)
if __name__=='__main__':run()

