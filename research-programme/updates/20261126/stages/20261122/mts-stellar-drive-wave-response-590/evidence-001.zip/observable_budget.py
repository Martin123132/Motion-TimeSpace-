from assess import BINS, HERE, MODELS, NAMES, PREV, R_GROUPS, SOURCE, checked, endpoint, fine, np, read, rise_check, table, vc2

def run():
    rotation=read(checked(PREV,'fields.csv'))
    vertical=read(checked(PREV,'phase-weights.csv'))
    source=read(checked(SOURCE,'field-finer.csv'))
    rows=[]
    for model,parts in MODELS.items():
        fixed=np.r_[[vc2(parts,group[:,0]).mean() for group in BINS],[rise_check(parts,r,.4) for r in R_GROUPS]]
        vectors={}
        for arm in ('ordinary','reset','coupled'):
            authority='reset' if arm=='ordinary' else arm
            data=[row for row in rotation if (row['level'],row['arm'],row['variant'],row['method'])==('3',authority,'nominal','stars_squared_speed') and row['bin'] in ('2','3')]
            wave=np.r_[[float(row['wave_v2']) for row in data],[float(row['phi_rise']) for row in source if row['state']==authority+'_forward' and row['Z_kpc']=='0.4']]
            values=fixed+wave*(arm!='ordinary')
            for tag in ('launch','forward','reverse'):
                change=np.zeros(9) if tag=='launch' or arm=='ordinary' else np.delete(endpoint(fine,model,arm+'_'+tag,.008)['stellar_wave_change'],2)
                assert min((values+change)[:2])>0
                vectors[(arm,tag)]=np.r_[np.sqrt((values+change)[:2]),(values+change)[2:]]
        for height in (0,10,20):
            groups=[row for row in vertical if row['Zsun_pc']==str(height)]
            obs=np.r_[[float(row['vc_kms']) for row in data],[float(row['mean']) for row in groups]]
            sig=np.r_[[float(row['error']) for row in data],[float(row['sigma']) for row in groups]]
            for tag,first,second in [
                *[('forward_minus_reverse',(arm,'forward'),(arm,'reverse')) for arm in ('ordinary','reset','coupled')],
                *[('inherited_minus_reset',('coupled',state),('reset',state)) for state in ('launch','forward','reverse')],
                *[('wave_minus_ordinary',(arm,'launch'),('ordinary','launch')) for arm in ('reset','coupled')]]:
                left,right=vectors[first],vectors[second]
                for index,name in enumerate(('inner_speed','outer_speed',*NAMES[3:])):
                    rows.append(dict(model=model,Zsun_pc=height,comparison=tag,left_state='/'.join(first),right_state='/'.join(second),
                        observable=name,unit='km/s' if index<2 else '(km/s)^2',observed=obs[index],quoted_error=sig[index],
                        left_prediction=left[index],right_prediction=right[index],difference=left[index]-right[index],
                        difference_in_quoted_errors=(left[index]-right[index])/sig[index]))
    assert all(row['difference']==0 for row in rows if row['left_state']=='ordinary/forward')
    table('observational-scale.csv',rows)
    for tag in ('forward_minus_reverse','inherited_minus_reset','wave_minus_ordinary'):
        for radial in (True,False):
            selected=[abs(row['difference_in_quoted_errors']) for row in rows if row['comparison']==tag and (row['unit']=='km/s')==radial]
            print(tag,'Cepheids' if radial else 'vertical',max(selected))
if __name__=='__main__':run()
