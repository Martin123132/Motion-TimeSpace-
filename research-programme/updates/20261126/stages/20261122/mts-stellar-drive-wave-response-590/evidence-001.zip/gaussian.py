from common import *
from stress import internal_derivative,second_density

def run():
    output=[]
    for level in (1,2,3):
        calc=Stage(level)
        r=calc.s.r[:,None];a=6.
        val=r*np.exp(-.5*(r/a)**2)
        p=np.broadcast_to(val,calc.host.shape).astype(complex)
        exact=p.real**2*calc.kappa**2/a**4*(2*(r/a)**2-3)
        dp=.5j*calc.kappa*p*(r**2/a**4-3/a**2)
        test=calc.measures(calc.grav(exact))
        for choice,deriv in [('finite_volume_laplacian',internal_derivative(calc,p)),('analytic_laplacian',dp)]:
            measured=calc.measures(calc.grav(second_density(calc,p,deriv)))
            for name,num,known in zip(NAMES,measured,test):
                output.append(dict(level=level,method=choice,observable=name,value=num,expected=known,relative_error=abs(num/known-1)))
    table('manufactured-free-wave.csv',output)
if __name__=='__main__':run()

