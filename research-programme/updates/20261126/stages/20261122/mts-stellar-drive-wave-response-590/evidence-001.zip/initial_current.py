from common import HERE, NAMES, SOURCE, checked, guard, np, table
from weak_flux import Weak, chebvander

class FirstCurrent(Weak):
    def fields(self,radius,idx=None):
        if idx is None: idx=np.searchsorted(self.edges[1:],radius)
        span=np.diff(self.edges)[idx]
        coordinate=2*(radius-self.edges[idx])/span-1
        amplitude,slope=[np.einsum('ri,irl->rl',chebvander(coordinate,len(raw)-1),raw[:,idx,:])*(2/span[:,None])**number
                         for number,raw in enumerate(self.der[:2])]
        wave=amplitude@self.B
        factor=np.sqrt(2*self.k2)
        radial=factor*(np.imag(wave.conj()*(slope@self.B))@self.P)
        angular=(factor/radius**2)[:,None]*(np.imag(wave.conj()*(amplitude@self.D))@self.DP)
        return radial,angular

    def interfaces(self):
        zero=np.zeros((len(self.edges)-2,len(self.orders)))
        return zero,zero,zero

def run():
    guard()
    result=[]
    for arm in ('reset','coupled'):
        with np.load(checked(SOURCE,'launch.npz')) as archive:
            assert np.array_equal(archive[arm+'_reverse'],archive[arm+'_forward'].conj())
        last=None
        for grid,order,angular in [('coarse',10,56),('fine',16,80)]:
            field=FirstCurrent(arm,angular)
            forward=field.readout(order,False)
            field.der=[raw.conj() for raw in field.der]
            reverse=field.readout(order,False)
            assert np.max(abs(reverse+forward))<1e-10*max(abs(forward))
            field.der=[raw.real for raw in field.der]
            assert not np.any(field.readout(order,False))
            if last is not None: assert np.max(abs(last/forward-1))<1e-6
            last=forward
            for sign,vector in [('forward',forward),('reverse',reverse)]:
                for name,rate in zip(NAMES,vector):
                    result.append(dict(arm=arm,sign=sign,grid=grid,observable=name,rate_per_Myr=rate))
    table('initial-density-current.csv',result)
if __name__=='__main__':run()
