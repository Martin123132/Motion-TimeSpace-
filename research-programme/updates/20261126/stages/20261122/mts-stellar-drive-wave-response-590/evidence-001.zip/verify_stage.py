from assess import FROZEN, TOL
from common import HERE, PINS, guard, json, read, sha, writer
import re
import sys

def run():
    guard()
    counts={}
    for directory,pin in PINS.items():
        assert sha(directory/'seal.json')==pin
        manifest=json.loads((directory/'seal.json').read_bytes())
        for name,expected in manifest.items():
            assert sha(directory/name)==expected,name
        counts[directory.name]=len(manifest)
    assert sha(HERE/'frozen-curvatures.csv')==FROZEN
    for file in HERE.glob('*.py'):
        compile(file.read_bytes(),str(file),'exec')
    children=list(HERE.iterdir())
    assert all(file.is_file() for file in children)
    for file in HERE.glob('*.csv'):
        rows=read(file)
        assert rows and all(None not in row and None not in row.values() for row in rows),file
    pairs={path.name.removeprefix('evolution-') for path in HERE.glob('evolution-*.csv')}
    assert len(pairs)==86 and pairs=={path.name.removeprefix('health-') for path in HERE.glob('health-*.csv')}
    health=[row for suffix in sorted(pairs) for row in read(HERE/('health-'+suffix))]
    limits=dict(normerr=1e-9,massbias=1e-10,density_crosscheck=1e-9,obs_crosscheck=1e-9)
    errors={key:max(float(row[key]) for row in health) for key in limits}
    assert all(errors[key]<value for key,value in limits.items())
    assert all(float(row['drive_difference'])==0 for row in read(HERE/'evolution-2-3.2e-05-4-equal-reset_forward.csv'))
    exact=read(HERE/'weak-commutator.csv')
    assert len(exact)==16 and all(float(row['with_surfaces_relative_error'])<1e-7 for row in exact)
    assert all(row['conditioning_gate']=='True' for row in exact if row['width_kpc']=='4.0')
    assert all(float(row['without_surfaces_relative_error'])>1 for row in exact if row['test']=='injected_element_bump')
    checks=read(HERE/'refinement-verdict.csv')
    tested={}
    for quantity in ('drive_difference','stellar_wave_change','baseline_wave_change'):
        for family,predicate in [('time',lambda row:row['comparison']=='smooth_time'),
                ('space',lambda row:row['comparison']==('smooth_space' if row['model']=='Pouliasis_I' else 'smooth_space_final'))]:
            subset=[row for row in checks if row['quantity']==quantity and predicate(row)]
            assert len(subset)==80 and all(row['pass_point005']=='True' for row in subset)
            tested[quantity+'/'+family]=max(float(row['relative_error']) for row in subset)
    assert any(row['pass_point005']=='False' for row in checks if row['comparison']=='native_space' and row['quantity']=='stellar_wave_change')
    assert all(float(row['drive_difference'])<0 for row in read(HERE/'joint-finite.csv'))
    rows=read(HERE/'joint-current-and-stress.csv')
    assert len(rows)==48 and all(float(row['forward_box_change'])>0>float(row['reverse_box_change']) for row in rows)
    assert all(float(row['relative_odd'])<TOL for row in rows)
    assert all(float(row['relative_even'])>TOL for row in rows if row['time_Myr']=='0.008')
    sphere=read(HERE/'preparation-shape-degeneracy.csv')
    assert len(sphere)==6 and all(0<float(row['joint_witness_upper'])<.01 and float(row['joint_witness_upper'])==float(row['joint_lower']) for row in sphere)
    torque=read(HERE/'equal-radius-discrimination.csv')
    assert len(torque)==42 and max(abs(float(row['delta_over_vertical_error'])) for row in torque)<.00065
    for report in ('RESULTS.md','REPLAY.md','DESIGN.md','EVOLUTION.md','WEAK-STRESS.md','IDENTIFIABILITY.md'):
        for target in re.findall(r'\[[^\]]*\]\(([^)]+)\)',(HERE/report).read_text(encoding='utf-8')):
            if not target.startswith('https://'): assert (HERE/target).is_file(),target
    receipt=dict(sealed_dependencies=counts,matched_evolutions=len(pairs),evolution_health_maxima=errors,
                 accepted_final_refinement_max_relative=tested,frozen_prediction=FROZEN,all_processes_required_to_exit=True)
    writer('validation.json',(json.dumps(receipt,sort_keys=True,indent=2)+'\n').encode())
    if '--seal' in sys.argv or (HERE/'seal.json').exists():
        items={p.name:sha(p) for p in sorted(HERE.iterdir()) if p.name!='seal.json'}
        writer('seal.json',(json.dumps(items,sort_keys=True,indent=2)+'\n').encode())
        print(len(items),'sealed',sha(HERE/'seal.json'))
    print(json.dumps(receipt))
if __name__=='__main__':run()
