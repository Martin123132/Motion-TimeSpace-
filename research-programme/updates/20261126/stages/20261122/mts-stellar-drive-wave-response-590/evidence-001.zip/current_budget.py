from assess import HERE, MODELS, NAMES, TOL, data_for_lp, endpoint, fine, guard, lp, medium, np, read, relative, table

def rhs_change(vector):
    return np.r_[-vector[:2]/1e4,vector[:2]/1e4,-vector[3:]/100,vector[3:]/100]

def run():
    guard()
    currents=read(HERE/'initial-density-current.csv')
    kinetics=read(HERE/'weak-kinetic.csv')
    gravities=read(HERE/'absolute-stress.csv')
    readouts=[]; balances=[]
    for arm in ('reset','coupled'):
        rates=np.array([float(row['rate_per_Myr']) for row in currents if (row['arm'],row['sign'],row['grid'])==(arm,'forward','fine')])
        kinetic=np.array([float(row['kinetic_curvature']) for row in kinetics if (row['arm'],row['grid'],row['surfaces'])==(arm,'finer','True')])
        for model in MODELS:
            grav=[row for row in gravities if (row['arm'],row['level'],row['host'])==(arm,'3',model)]
            curve=kinetic+np.array([float(row['self_gravity'])+float(row['ordinary_drive']) for row in grav])
            contracts={}
            for height in (0,10,20):
                matrix,initial=data_for_lp(arm,model,height)
                base,dual=lp(matrix,initial)
                contracts[height]=(matrix,initial,base,dual)
            for elapsed in (.001,.002,.004,.008):
                signed=[endpoint(fine,model,arm+'_'+sign,elapsed)['stellar_wave_change'] for sign in ('forward','reverse')]
                half_sum=(signed[0]+signed[1])*.5
                half_difference=(signed[0]-signed[1])*.5
                for index,name in enumerate(NAMES):
                    readouts.append(dict(arm=arm,model=model,time_Myr=elapsed,observable=name,
                        forward_change=signed[0][index],reverse_change=signed[1][index],
                        current_prediction=rates[index]*elapsed,current_odd=half_difference[index],
                        current_relative_error=relative(half_difference[index]/elapsed,rates[index]),
                        abs_curvature_prediction=.5*curve[index]*elapsed**2,even_change=half_sum[index],
                        curvature_relative_error=relative(2*half_sum[index]/elapsed**2,curve[index])))
                for height,(matrix,initial,base,dual) in contracts.items():
                    scores=[lp(matrix,initial+rhs_change(vector))[0]-base for vector in signed]
                    current=rhs_change(rates)@dual
                    acceleration=rhs_change(curve)@dual
                    even=rhs_change(half_sum)@dual
                    odd=rhs_change(half_difference)@dual
                    assert abs(scores[0]-odd-even)<3e-12 and abs(scores[1]+odd-even)<3e-12
                    balances.append(dict(arm=arm,model=model,Zsun_pc=height,time_Myr=elapsed,
                        initial_joint_rate=current,launch_joint_curvature=acceleration,forward_box_change=scores[0],
                        reverse_box_change=scores[1],linear_current_prediction=current*elapsed,
                        measured_odd=odd,relative_odd=relative(odd/elapsed,current),
                        quadratic_even_prediction=.5*acceleration*elapsed**2,measured_even=even,
                        relative_even=relative(2*even/elapsed**2,acceleration)))
    assert all(row['forward_box_change']>0 and row['reverse_box_change']<0 for row in balances)
    table('current-odd-and-even.csv',readouts);table('joint-current-and-stress.csv',balances)
    for group,key in [(readouts,'current_relative_error'),(balances,'relative_odd'),(readouts,'curvature_relative_error'),(balances,'relative_even')]:
        rows=[row[key] for row in group if row['time_Myr']==.008]
        print(key,max(rows),sum(value<TOL for value in rows),'/',len(rows))
if __name__=='__main__':run()
