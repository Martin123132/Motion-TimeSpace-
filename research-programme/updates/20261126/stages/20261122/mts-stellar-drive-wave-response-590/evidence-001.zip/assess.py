from budget import BINS, HERE, MODELS, NAMES, PINS, PREV, R_GROUPS, SOURCE, STATES, checked, cone, guard, lp, np, read, rise_check, sha, table, vc2
import json
from collections import Counter

FROZEN = '33f93e640a9b1c04294eaa4ec880d97a9d904c9e3bbd6797b7c34eb8f326a427'
TOL = .005
coarse, medium, fine = 'smooth2-0.001-8','smooth3-0.001-8','smooth3-0.0005-16'
native = '3-0.001-8'
keys = ('drive_difference','stellar_wave_change','baseline_wave_change')
short = '3-3.2e-05-4'

def endpoint(grid, model, state, elapsed):
    rows=read(HERE/f'evolution-{grid}-{model}-{state}.csv')
    selected=[row for row in rows if float(row['time_Myr'])==elapsed]
    assert [row['observable'] for row in selected]==list(NAMES)
    return {key: np.array([float(row[key]) for row in selected]) for key in keys}

def relative(first, second):
    if second==0:
        return 0. if first==0. else float('inf')
    return abs(first/second-1)

def data_for_lp(arm, model, height):
    design, vertical=cone([group[:,0] for group in BINS],R_GROUPS,.4)
    rotation=[row for row in read(checked(PREV,'fields.csv')) if row['arm']==arm and row['level']=='3' and row['variant']=='nominal'
             and row['method']=='stars_squared_speed' and row['bin'] in ('2','3')]
    assert [row['bin'] for row in rotation]==['2','3']
    wave_vertical=np.array([float(row['phi_rise']) for row in read(checked(SOURCE,'field-finer.csv')) if row['state']==arm+'_forward' and row['Z_kpc']=='0.4'])
    figures=[row for row in read(checked(PREV,'phase-weights.csv')) if int(row['Zsun_pc'])==height]
    means, sigma=np.array([[float(row[key]) for key in ('mean','sigma')] for row in figures]).T
    obs, err, wave=np.array([[float(row[key]) for key in ('vc_kms','error','wave_v2')] for row in rotation]).T
    fixed=wave+np.array([vc2(MODELS[model],group[:,0]).mean() for group in BINS])
    base=wave_vertical+np.array([rise_check(MODELS[model],radius,.4) for radius in R_GROUPS])
    lhs=np.c_[np.vstack((design/1e4,-design/1e4,vertical/100,-vertical/100)),np.r_[np.zeros(4),-(sigma+.16)/100,-(sigma+.16)/100]]
    rhs=np.r_[((obs+err)**2-fixed)/1e4,(fixed-(obs-err)**2)/1e4,(means-base+.16)/100,(base-means+.16)/100]
    return lhs,rhs

def run():
    guard()
    assert sha(HERE/'frozen-curvatures.csv')==FROZEN
    frozen=read(HERE/'frozen-curvatures.csv')
    weak=read(HERE/'weak-kinetic.csv')
    stress=read(HERE/'absolute-stress.csv')
    gaps=read(checked(PREV,'alternative-stellar-spheres.csv'))
    results=[]; comparisons=[]; phase=[]; parity=[]
    for model in MODELS:
        for arm in ('reset','coupled'):
            getcur=lambda lvl: np.array([float(row['delta_second_derivative_per_Myr2']) for row in frozen if row['level']==lvl and row['arm']==arm and row['model']==model])
            curve=getcur('3')
            grav=[row for row in stress if row['level']=='3' and row['arm']==arm and row['host']==model]
            assert [row['observable'] for row in grav]==list(NAMES)
            kinetic=np.array([float(row['kinetic_curvature']) for row in weak if row['grid']=='finer' and row['surfaces']=='True' and row['arm']==arm])
            absolute=kinetic+np.array([float(row['self_gravity'])+float(row['ordinary_drive']) for row in grav])
            gap=-1e9*next(float(row['min_order_slack_1e9Msun']) for row in gaps if row['arm']==arm and row['model']==model and row['scope']=='solar' and row['eta']=='1.0')
            branches={}
            for sign in ('forward','reverse'):
                state=arm+'_'+sign
                branch={grid:endpoint(grid,model,state,.008) for grid in (fine,medium,coarse,native,'2-0.001-8','2-0.0005-16')}
                branches[sign]=branch
                extra='smooth4-0.001-8'
                if model=='Pouliasis_II':
                    branch[extra]=endpoint(extra,model,state,.008)
                short_results=endpoint(short,model,state,.000128)
                for key in keys:
                    for code,first,second in [
                        ('smooth_time',medium,fine),('smooth_space',coarse,medium),
                        ('native_time','2-0.001-8','2-0.0005-16'),('native_space','2-0.001-8',native),
                        ('independent_mesh',native,fine)]+([('smooth_space_final',medium,extra),('native_vs_final',native,extra)] if model=='Pouliasis_II' else []):
                        for name,old,new in zip(NAMES,branch[first][key],branch[second][key]):
                            error=relative(old,new)
                            comparisons.append(dict(model=model,state=state,observable=name,comparison=code,quantity=key,first=old,second=new,relative_error=error,pass_point005=error<TOL))
                for index,name in enumerate(NAMES):
                    direct=branch[fine]['drive_difference'][index]
                    predicted=.5*.008**2*curve[index]
                    ratio=relative(2*short_results['drive_difference'][index]/.000128**2,curve[index])
                    results.append(dict(model=model,state=state,observable=name,source_curvature=curve[index],short_128year_relative_error=ratio,
                        prediction_8000yr=predicted,delta_8000yr=direct,finite_vs_quadratic_relative=relative(direct,predicted),
                        absolute_8000yr=branch[fine]['stellar_wave_change'][index],old_host_8000yr=branch[fine]['baseline_wave_change'][index],
                        initial_mass_discrepancy_Msun=gap if index==2 else '',fraction_removed_due_to_drive=-direct/gap if index==2 else ''))
            for index,name in enumerate(NAMES):
                even=lambda grid: .5*sum(branches[sign][grid]['stellar_wave_change'][index] for sign in branches)
                observed=2*even(fine)/.008**2
                parity.append(dict(model=model,arm=arm,observable=name,weak_launch=absolute[index],finite_even_curvature=observed,
                      time_error=relative(even(medium),even(fine)),space_error=relative(even(coarse),even(medium)),
                      departure_from_launch=relative(observed,absolute[index])))
            for height in (0,10,20):
                lhs,rhs=data_for_lp(arm,model,height)
                start,dual=lp(lhs,rhs)
                for sign,branch in branches.items():
                    for grid in (coarse,medium,fine,native,*([extra] if model=='Pouliasis_II' else [])):
                        costs={}
                        for key in keys:
                            change=branch[grid][key]
                            delta=np.r_[-change[:2]/1e4,change[:2]/1e4,-change[3:]/100,change[3:]/100]
                            cost=delta@dual
                            new,_=lp(lhs,rhs+delta)
                            assert abs((new-start)-cost)<max(3e-12,1e-6*abs(cost)),(cost,new,start)
                            costs[key]=cost
                        assert abs(costs['stellar_wave_change']-costs['baseline_wave_change']-costs['drive_difference'])<1e-15
                        phase.append(dict(model=model,state=arm+'_'+sign,grid=grid,Zsun_pc=height,box_at_start=start,**costs))
    for row in results: assert row['short_128year_relative_error']<TOL
    assert all(row['pass_point005'] for row in comparisons if row['quantity']=='drive_difference' and row['comparison'] in ('native_time','native_space','smooth_time'))
    assert all(row['drive_difference']<0 for row in phase)
    table('finite-verdict.csv',results);table('refinement-verdict.csv',comparisons)
    table('joint-finite.csv',phase);table('sign-even-absolute.csv',parity)
    print('verified',len(results),len(comparisons),len(phase),len(parity))
    for key in keys:
        print(key,Counter((row['comparison'],row['pass_point005']) for row in comparisons if row['quantity']==key))
if __name__=='__main__':run()
