from common import *
checked(PREV,'local_phase.py');checked(PREV,'fields.csv')
checked(SOURCE,'field-finer.csv')
from local_phase import cone
from stellar_sources import vc2,rise_check
from scipy.optimize import linprog,OptimizeWarning
import warnings

def lp(mat,rhs):
    cost=np.r_[np.zeros(mat.shape[1]-1),1.]
    with warnings.catch_warnings():
        warnings.simplefilter('ignore',OptimizeWarning)
        res=linprog(cost,A_ub=mat,b_ub=rhs,bounds=[(0,None)]*(len(cost)-2)+[(None,None),(0,None)],method='highs',options={'threads':1,'parallel':False})
    assert res.success,res.message
    dual=res.ineqlin.marginals
    assert np.max(mat@res.x-rhs)<1e-7 and abs(res.fun-rhs@dual)<1e-7
    return res.fun,dual

def run():
    guard()
    fields=read(PREV/'fields.csv')
    figures=read(PREV/'phase-weights.csv')
    orig=read(PREV/'common-shell-phase-boxes.csv')
    waves=read(SOURCE/'field-finer.csv')
    prediction=read(HERE/'frozen-curvatures.csv')
    design,vert=cone([g[:,0] for g in BINS],R_GROUPS,.4)
    coef=np.vstack((design/1e4,-design/1e4,vert/100,-vert/100))
    out=[]
    for arm in ('ordinary','reset','coupled'):
        rows=[r for r in fields if r['arm']==('reset' if arm=='ordinary' else arm) and r['level']=='3' and r['variant']=='nominal' and r['method']=='stars_squared_speed' and r['bin'] in ('2','3')]
        obs,err,w=np.array([[float(r[k]) for k in ('vc_kms','error','wave_v2')] for r in rows]).T
        if arm=='ordinary':w*=0
        wz=0 if arm=='ordinary' else np.array([float(r['phi_rise']) for r in waves if r['state']==arm+'_forward' and r['Z_kpc']=='0.4'])
        for model,components in MODELS.items():
            fixed=w+np.array([vc2(components,g[:,0]).mean() for g in BINS])
            base=wz+np.array([rise_check(components,r,.4) for r in R_GROUPS])
            for height in (0,10,20):
                means,sig=np.array([[float(r[k]) for k in ('mean','sigma')] for r in figures if int(r['Zsun_pc'])==height]).T
                mat=np.c_[coef,np.r_[np.zeros(4),-(sig+.16)/100,-(sig+.16)/100]]
                rhs=np.r_[((obs+err)**2-fixed)/1e4,(fixed-(obs-err)**2)/1e4,(means-base+.16)/100,(base-means+.16)/100]
                val,dual=lp(mat,rhs)
                previous=next(float(r['min_vertical_box_multiplier']) for r in orig if r['arm']==arm and r['model']==model and r['level']=='3' and r['scope']=='solar' and r['method']=='stars_squared_speed' and int(r['Zsun_pc'])==height and r['digitization_allowance']=='0.16')
                assert abs(val-previous)<1e-7
                for level in (2,3):
                    curve=np.zeros(10) if arm=='ordinary' else np.array([float(r['delta_second_derivative_per_Myr2']) for r in prediction if r['arm']==arm and r['model']==model and r['level']==str(level)])
                    rc=np.r_[-curve[:2],curve[:2],np.zeros(14)]/1e4
                    vz=np.r_[np.zeros(4),-curve[3:],curve[3:]]/100
                    for tag,direction in [('radial',rc),('vertical',vz),('joint',rc+vz)]:
                        deriv=direction@dual
                        for amount in (-.01,.01,.1):
                            changed,_=lp(mat,rhs+amount*direction)
                            assert abs((changed-val)/amount-deriv)<max(abs(deriv)*1e-5,1e-8),(model,arm,height,tag,changed,val,deriv)
                        out.append(dict(level=level,arm=arm,source=model,Zsun_pc=height,component=tag,
                            launch_box_multiplier=val,drive_curvature_box_units_per_Myr2=deriv))
    table('joint-tangent.csv',out)
if __name__=='__main__':run()

