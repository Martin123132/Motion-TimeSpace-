import csv
import hashlib
import io
import json
import math
from pathlib import Path

import requests

HOME=Path(__file__).resolve().parent
VIZ='https://vizier.cfa.harvard.edu/viz-bin/asu-tsv'
FIELDS='DR2Name,RA_ICRS,DE_ICRS,Dist,Memb,Track,Type,DM,pmRA,e_pmRA,pmDE,e_pmDE,ID-PS1'

def sha(path):
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()

def put(name,data):
    path=HOME/name
    if path.exists():
        if hashlib.sha256(data).hexdigest()!=sha(path):raise ValueError(f'conflicting output: {name}')
    else:
        with path.open('xb') as stream:stream.write(data)

def record(name,value):
    put(name,(json.dumps(value,indent=2,sort_keys=True,allow_nan=False)+'\n').encode())

def table(name,rows):
    buf=io.StringIO();writer=csv.DictWriter(buf,fieldnames=rows[0],lineterminator='\n')
    writer.writeheader();writer.writerows(rows);put(name,buf.getvalue().encode())

def fetch(name,url,query,verify):
    file=HOME/name
    if file.exists():
        receipt=json.loads((HOME/(name+'.json')).read_bytes())
        assert receipt['sha256']==sha(file) and receipt['url']==url and receipt['params']==query
        return verify(file.read_text('utf-8'))
    with requests.get(url,params=query,stream=True,timeout=(8,35)) as result:
        result.raise_for_status()
        data=bytearray()
        for block in result.iter_content(65536):
            data.extend(block)
            if len(data)>3_000_000:raise ValueError('outside small table budget')
        body=verify(data.decode('utf-8'))
        put(name,data)
        record(name+'.json',dict(url=url,params=query,request=result.url,sha256=sha(file),bytes=len(data)))
        return body

def viz_rows(text):
    lines=[line for line in text.splitlines() if line and not line.startswith('#')]
    assert len(lines)>3 and lines[2].startswith('---') and '#INFO\tError' not in text
    return [{key:val.strip() for key,val in row.items()} for row in csv.DictReader([lines[0]]+lines[3:],delimiter='\t')]

def catalogue():
    allstars=fetch('rrl-release.tsv',VIZ,{'-source':'J/AJ/158/223/table2','-out':FIELDS,'-out.max':'5000'},viz_rows)
    assert len(allstars)==3300 and len({(row['DR2Name'],row['ID-PS1']) for row in allstars})==3300
    from collections import Counter
    repeated=[key for key,count in Counter(row['DR2Name'] for row in allstars).items() if count>1]
    selected=[];rounded=[]
    for row in allstars:
        if row['Track']!='1':continue
        if float(row['Memb'])==.5:rounded.append(row['DR2Name'])
        if float(row['Memb'])<=.5:continue
        ra,dec=float(row['RA_ICRS']),float(row['DE_ICRS'])
        delta=math.radians(ra-229.018);lat,lat0=map(math.radians,(dec,-.124))
        angle=2*math.asin(math.sqrt(math.sin(.5*(lat-lat0))**2+math.cos(lat)*math.cos(lat0)*math.sin(.5*delta)**2))
        selected.append(dict(id=row['DR2Name'].split()[-1],ra=ra,dec=dec,distance=float(row['Dist']),
            pmra=float(row['pmRA']),pmdec=float(row['pmDE']),err_ra=float(row['e_pmRA']),
            err_dec=float(row['e_pmDE']),prob=float(row['Memb']),kind=row['Type'],ps1_id=row['ID-PS1'],
            angular_arcmin=math.degrees(angle)*60,region='cluster' if math.degrees(angle)*60<=11 else 'tail'))
    print('published sample check:',len(selected),[(group,sum(row['region']==group for row in selected)) for group in ('cluster','tail')],flush=True)
    assert len(selected)==27 and sum(row['region']=='tail' for row in selected)==18
    for row in selected:
        row['tail_11p2']=int(row['angular_arcmin']>11.2)
    assert sum(row['tail_11p2'] for row in selected)==17
    assert len({row['id'] for row in selected})==27
    ids=','.join(sorted(row['id'] for row in selected))
    url='https://gea.esac.esa.int/tap-server/tap/sync'
    query='SELECT source_id,ra,dec,pmra,pmdec,pmra_error,pmdec_error,pmra_pmdec_corr FROM gaiadr2.gaia_source WHERE source_id IN ('+ids+') ORDER BY source_id'
    def validate(text):
        out={row['source_id']:row for row in csv.DictReader(io.StringIO(text))}
        assert set(out)==set(ids.split(','))
        return out
    params={'REQUEST':'doQuery','LANG':'ADQL','FORMAT':'csv','QUERY':query}
    gaia=fetch('gaia-dr2-cov.csv',url,params,validate)
    for row in selected:
        match=gaia[row['id']]
        for var,col,tol in [('ra','ra',1e-6),('dec','dec',1e-6),('pmra','pmra',.0006),('pmdec','pmdec',.0006),
                             ('err_ra','pmra_error',.0006),('err_dec','pmdec_error',.0006)]:
            assert abs(row[var]-float(match[col]))<tol,(row['id'],var)
        row['correlation']=float(match['pmra_pmdec_corr'])
        assert abs(row['correlation'])<1 and min(row['distance'],row['err_ra'],row['err_dec'])>0
    table('rrl-input.csv',sorted(selected,key=lambda row:row['id']))
    record('selection.json',dict(raw=len(allstars),keep=len(selected),duplicate_source_ids=repeated,rounded_at_cut=rounded,
           hashes={n:sha(HOME/n) for n in ('rrl-release.tsv','gaia-dr2-cov.csv','rrl-input.csv','PROTOCOL.md')}))

if __name__=='__main__':
    catalogue()
