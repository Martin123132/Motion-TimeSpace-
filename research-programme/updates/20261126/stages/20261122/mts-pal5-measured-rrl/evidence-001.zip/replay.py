import csv
import json
import os
import sys
for key in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','BLIS_NUM_THREADS'):
    os.environ[key]='1'
sys.dont_write_bytecode=True
from catalogue import HOME, sha, table, record
import numpy as np

JOIN=HOME.parent/'mts-pal5-joined-flow-586-600-20261122'
assert sha(JOIN/'seal.json')=='86d9b1296c253b14a04e475339a9cbf71f84fed201749a234af4892b715576b7'
SEALED=json.loads((JOIN/'seal.json').read_bytes())
for file in ('early.py','tracers.py','PROTOCOL.md'):
    assert sha(JOIN/file)==SEALED[file]
sys.path.insert(0,str(JOIN))
from tracers import Segment,TRACK,RA0,CONV,LATE,PAL,pinned,SIGNS,ARMS
from orbit import ROT,SUN,VSUN,icrs,observed,anchors

CENTRAL=('old','cluster','distance','pm','measured')
VARIATIONS=('system','random_d','pm_first','pm_second')
with (HOME/'rrl-input.csv').open(newline='') as stream:
    TAIL=[r for r in csv.DictReader(stream) if r['region']=='tail']
assert len(TAIL)==18
def col(name):return np.array([float(r[name]) for r in TAIL])
RA=np.r_[RA0,col('ra')]
DEC=np.r_[-.124,col('dec')]
D0,PMRA0,PMDEC0=20.6,-2.75,-2.69

def physical(ra,dec,distance,pmra,pmdec):
    pos=icrs(ra,dec);east=icrs(ra+90,dec*0);north=np.cross(pos,east)
    refvr=-58.7+1.2*(ra-RA0)
    coord=SUN+distance[:,None]*(pos@ROT.T)
    vel=VSUN+(refvr[:,None]*pos+4.74047*distance[:,None]*(pmra[:,None]*east+pmdec[:,None]*north))@ROT.T
    return coord,vel*CONV

def inputs(key,amplitude=0.):
    distance=np.full(len(RA),D0);pmra=np.full(len(RA),PMRA0);pmdec=np.full(len(RA),PMDEC0)
    if key=='old':distance[:]=22.05;pmra[:]=-2.296;pmdec[:]=-2.257
    if key in ('distance','measured')+VARIATIONS:distance[1:]=col('distance')
    if key in ('pm','measured')+VARIATIONS:pmra[1:]=col('pmra');pmdec[1:]=col('pmdec')
    if key=='system':distance*=1+.02*amplitude
    if key=='random_d':distance[1:]*=1+.01*amplitude
    if key=='pm_first':
        pmra[1:]+=amplitude*col('err_ra')
        pmdec[1:]+=amplitude*col('err_dec')*col('correlation')
    if key=='pm_second':pmdec[1:]+=amplitude*col('err_dec')*np.sqrt(1-col('correlation')**2)
    return physical(RA,DEC,distance,pmra,pmdec)

def slope_grid():
    slopes=np.full(len(TAIL),np.nan)
    for half,degree in ((-1,1),(1,2)):
        source=TRACK['ra']<RA0 if half==-1 else TRACK['ra']>=RA0
        support=TRACK['ra'][source]
        use=(RA[1:]>=min(support))&(RA[1:]<=max(support))
        poly=np.polynomial.Polynomial.fit(support,TRACK['dec'][source],degree,w=1/TRACK['sigma_dec'][source])
        slopes[use]=poly.deriv()(RA[1:][use])
    return slopes

def run(factor,ofactor,mode):
    assert factor in (2,4) and ofactor in (1,2) and mode in ('central','errors','half')
    assert sha(HOME/'rrl-input.csv')==json.loads((HOME/'selection.json').read_bytes())['hashes']['rrl-input.csv']
    label=f'{factor}-{ofactor}-{mode}'
    if mode=='central':spec=[(key,0.) for key in CENTRAL]
    else:
        step=.5 if mode=='half' else 1.
        spec=[(key,sign*step) for key in VARIATIONS for sign in (-1,1)]
    values=[];checks=[]
    slopes=slope_grid()
    for arm in ARMS:
        early_name=f'early-{70*factor}-{arm}.npz';late_name=f'potential-{18*factor}.npz'
        with np.load(pinned(JOIN/early_name,SEALED[early_name])) as bank:
            early=Segment(bank,arm,192*factor*ofactor)
        with np.load(pinned(PAL/late_name,LATE[late_name])) as bank:
            late=Segment(bank,arm,192*ofactor)
        records=[inputs(key,amp) for key,amp in spec]
        final=tuple(np.concatenate([pair[idx] for pair in records]) for idx in (0,1))
        bridge=late.move(late.end,0,final,'mean')
        start=early.move(early.end,0,bridge,'mean')
        recover=late.move(0,late.end,early.move(0,early.end,start,'mean'),'mean')
        error=max(abs(a-b).max() for a,b in zip(final,recover))
        assert error<1e-9,error
        maps={sign:late.move(0,late.end,early.move(0,early.end,start,sign),sign) for sign in SIGNS}
        for index,(key,amplitude) in enumerate(spec):
            block=slice(index*len(RA),(index+1)*len(RA));obs=[];xyz=[]
            for sign in SIGNS:
                pos,speed=(val[block] for val in maps[sign])
                pos=pos-pos[:1]+final[0][block][:1];speed=speed-speed[:1]+final[1][block][:1]
                obs.append(observed(pos,speed));xyz.append(pos)
            dra,ddec,dvr=(obs[0]-obs[1])[1:].T
            displacement=np.linalg.norm((xyz[0]-xyz[1])[1:],axis=1)*1000
            for idx,star in enumerate(TAIL):
                values.append(dict(arm=arm,case=key,amplitude=amplitude,id=star['id'],tail_11p2=star['tail_11p2'],
                    ra=RA[idx+1],dec=DEC[idx+1],dRA_deg=dra[idx],ddec_deg=ddec[idx],dv_same_star_kms=dvr[idx],
                    dv_fixed_ra_kms=dvr[idx]-1.2*dra[idx],pc=displacement[idx],
                    ddec_fixed_ra_deg=ddec[idx]-slopes[idx]*dra[idx] if np.isfinite(slopes[idx]) else ''))
        checks.append(dict(arm=arm,mean_return=error,early_min=early.minr,early_max=early.maxr,late_min=late.minr,late_max=late.maxr))
        print(label,arm,checks[-1],flush=True)
    table(f'predictions-{label}.csv',values);table(f'integration-{label}.csv',checks)

if __name__=='__main__':
    run(int(sys.argv[1]),int(sys.argv[2]),sys.argv[3])
