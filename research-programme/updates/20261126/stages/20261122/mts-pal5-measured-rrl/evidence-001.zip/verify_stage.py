import csv
import json
import math
from catalogue import HOME,catalogue,record,sha
from overlap import main as verify_overlap
from evaluate import main as evaluate
from reference_budget import run as evaluate_references
from bracket_budget import evaluate as evaluate_bracket

def run():
    for name in ('rrl-release.tsv','gaia-dr2-cov.csv','kuzma-table4.txt'):
        meta=json.loads((HOME/(name+'.json')).read_bytes())
        assert meta['sha256']==sha(HOME/name) and meta['bytes']==(HOME/name).stat().st_size
    catalogue();verify_overlap();evaluate();evaluate_references();evaluate_bracket()
    gates={name:json.loads((HOME/name).read_bytes()) for name in ('verification.json','reference-verdict.json','slope-verdict.json')}
    assert gates['verification.json']['refinements']==160 and not gates['verification.json']['failures']
    assert gates['reference-verdict.json']['count']==52 and not gates['reference-verdict.json']['failed']
    assert gates['slope-verdict.json']['tests']==48 and not gates['slope-verdict.json']['failures']
    runs=[]
    for path in sorted([*HOME.glob('integration-*.csv'),*HOME.glob('reference-checks-*.csv')]):
        with path.open(newline='') as stream:items=list(csv.DictReader(stream))
        assert {r['arm'] for r in items}=={'reset','coupled'}
        for row in items:
            err=float(row.get('mean_return') or row['round_trip'])
            assert err<1e-9 and 2<float(row['early_min'])<float(row['early_max'])<35
            assert 12<float(row['late_min'])<float(row['late_max'])<29
        runs.append(path.name)
    assert len(runs)==10
    with (HOME/'scores.csv').open(newline='') as stream:scores=list(csv.DictReader(stream))
    assert len(scores)==20
    with (HOME/'velocity-reference-comparison.csv').open(newline='') as stream:rr=list(csv.DictReader(stream))
    assert len(rr)==12
    with (HOME/'overlap.json').open() as stream:overlap=json.load(stream)
    assert overlap['rrl_members']==27 and overlap['table4_rows']==109
    record('final-validation.json',dict(tested_refinements=260,stage_runs=runs,geometry_cases=len(scores),
           scope='conditional signed differences; no observational sign score',
           step_history='full-to-half error sensitivity missed 0.5% for inherited; half-to-quarter within tolerance'))
    if (HOME/'RESULTS.md').is_file():
        files={p.name:sha(p) for p in sorted(HOME.iterdir()) if p.is_file() and p.name!='seal.json'}
        record('seal.json',files);print('Verified',len(files),sha(HOME/'seal.json'))

if __name__=='__main__':
    run()
