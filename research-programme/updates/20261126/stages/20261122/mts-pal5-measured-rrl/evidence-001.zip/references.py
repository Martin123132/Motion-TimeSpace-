import sys
from replay import HOME,JOIN,PAL,SEALED,LATE,ARMS,SIGNS,RA,DEC,RA0,TAIL,CONV,ROT,icrs,inputs,observed,pinned,Segment,np,table,VARIATIONS,D0,PMRA0,PMDEC0

def bulk():
    pos=icrs(RA[:1],DEC[:1])[0];east=icrs(RA[:1]+90,DEC[:1]*0)[0];north=np.cross(pos,east)
    return -58.7*pos+4.74047*D0*(PMRA0*east+PMDEC0*north)

def ref(ra,dec,mode):
    if mode=='flat':return np.full_like(ra,-58.7)
    if mode=='bulk':return icrs(ra,dec)@bulk()
    if mode in ('slope_low','slope_high'):
        return -58.7+({'slope_low':1.05,'slope_high':1.35}[mode])*(ra-RA0)
    if mode=='slope_and_curvature':
        mask=np.array([int(row['tail_11p2'])==1 for row in TAIL])
        x=RA[1:][mask]-RA[1:][mask].mean()
        gradient=x@(icrs(RA[1:][mask],DEC[1:][mask])@bulk())/(x@x)
        return icrs(ra,dec)@bulk()+(1.2-gradient)*(ra-RA0)
    return -58.7+1.20*(ra-RA0)

def run(factor,ofactor,mode):
    names=('slope_low','slope_high','slope_and_curvature') if mode=='bracket' else ('legacy','flat','bulk')
    scenarios=([(name,0.) for name in names] if mode in ('reference','bracket')
              else [(key,frac) for key in VARIATIONS for frac in (-.25,.25)])
    rows=[];conditions=[]
    direction=icrs(RA,DEC)@ROT.T
    for arm in ARMS:
        a=f'early-{70*factor}-{arm}.npz';b=f'potential-{18*factor}.npz'
        with np.load(pinned(JOIN/a,SEALED[a])) as bank:early=Segment(bank,arm,192*factor*ofactor)
        with np.load(pinned(PAL/b,LATE[b])) as bank:late=Segment(bank,arm,192*ofactor)
        starts=[]
        for name,amp in scenarios:
            pos,vel=inputs('measured' if mode in ('reference','bracket') else name,amp)
            add=ref(RA,DEC,name)-ref(RA,DEC,'legacy')
            vel=vel+CONV*add[:,None]*direction
            assert np.max(abs(observed(pos,vel)[:,2]-ref(RA,DEC,name)))<1e-9
            starts.append((pos,vel))
        final=tuple(np.concatenate([pair[idx] for pair in starts]) for idx in (0,1))
        bridge=late.move(late.end,0,final,'mean')
        initial=early.move(early.end,0,bridge,'mean')
        again=late.move(0,late.end,early.move(0,early.end,initial,'mean'),'mean')
        err=max(abs(a-b).max() for a,b in zip(again,final));assert err<1e-9
        signed={sign:late.move(0,late.end,early.move(0,early.end,initial,sign),sign) for sign in SIGNS}
        for idx,(name,amp) in enumerate(scenarios):
            section=slice(idx*len(RA),(idx+1)*len(RA))
            obs=[];tracks=[]
            for sign in SIGNS:
                coord,speed=(value[section] for value in signed[sign])
                coord=coord-coord[:1]+final[0][section][:1]
                speed=speed-speed[:1]+final[1][section][:1]
                obs.append(observed(coord,speed)[1:]);tracks.append(coord[1:])
            left,right=obs
            comparison=left[:,2]-right[:,2]
            compensated=comparison-(ref(left[:,0],left[:,1],name)-ref(right[:,0],right[:,1],name))
            disp=np.linalg.norm(tracks[0]-tracks[1],axis=1)*1000
            for number,star in enumerate(TAIL):
                rows.append(dict(arm=arm,case=name,amplitude=amp,id=star['id'],dv_same_star_kms=comparison[number],
                         dv_fixed_ra_kms=compensated[number],pc=disp[number]))
        conditions.append(dict(arm=arm,round_trip=err,early_min=early.minr,early_max=early.maxr,
                late_min=late.minr,late_max=late.maxr))
        print(mode,factor,ofactor,arm,flush=True)
    label=f'{factor}-{ofactor}-{mode}'
    table('predictions-'+label+'.csv',rows);table('reference-checks-'+label+'.csv',conditions)

if __name__=='__main__':
    run(int(sys.argv[1]),int(sys.argv[2]),sys.argv[3])
