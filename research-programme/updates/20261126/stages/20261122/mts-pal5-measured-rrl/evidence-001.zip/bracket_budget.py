from references import ref
from evaluate import load,CLASSES,trend_weights,column
from replay import HOME,ARMS,RA,DEC,np,table,record

def evaluate():
    result=[];errors=[]
    legacy=load('4-2-reference');fine=load('4-2-bracket');coarse=load('2-1-bracket')
    for arm in ARMS:
        for sample,mask in CLASSES:
            ra,dec=RA[1:][mask],DEC[1:][mask]
            weights=trend_weights(ra)
            for key in ('legacy','flat','bulk','slope_low','slope_high','slope_and_curvature'):
                control=key in ('legacy','flat','bulk')
                vr=ref(ra,dec,key)
                track=legacy if control else fine
                high=track[arm,key,0.]
                signal=column(high,'dv_fixed_ra_kms')[mask]
                if not control:
                    for field in ('dv_fixed_ra_kms','dv_same_star_kms','pc'):
                        val=column(high,field)[mask]
                        old=column(coarse[arm,key,0.],field)[mask]
                        errors.append(dict(arm=arm,sample=sample,case=key,quantity=field,relative=np.linalg.norm(val-old)/np.linalg.norm(val)))
                    old=column(coarse[arm,key,0.],'dv_fixed_ra_kms')[mask]
                    errors.append(dict(arm=arm,sample=sample,case=key,quantity='gradient',relative=abs((weights@old)/(weights@signal)-1)))
                result.append(dict(arm=arm,sample=sample,velocity_reference=key,input_gradient=weights@vr,
                    input_min=vr.min(),input_max=vr.max(),rms_change_from_legacy=np.sqrt(np.mean((vr-ref(ra,dec,'legacy'))**2)),
                    actual_gradient_difference=weights@column(high,'dv_same_star_kms')[mask],
                    compensated_gradient_difference=weights@signal,max_abs_star_velocity_difference=max(abs(signal))))
            if sample=='tail17':
                assert abs(result[-1]['input_gradient']-1.2)<1e-9
    table('slope-bracket.csv',result);table('slope-refinements.csv',errors)
    record('slope-verdict.json',dict(tests=len(errors),failures=[r for r in errors if r['relative']>=.005],
        worst=max(r['relative'] for r in errors)))

if __name__=='__main__':
    evaluate()
