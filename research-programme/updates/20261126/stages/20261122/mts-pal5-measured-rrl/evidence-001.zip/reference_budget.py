from evaluate import load,CLASSES,trend_weights,column
from replay import RA,HOME,ARMS,VARIATIONS,np,table,record

def run():
    data=load('4-2-reference');coarse=load('2-1-reference');old=load('4-2-central')
    quarter=load('4-2-quarter');half=load('4-2-half')
    result=[];conditions=[];local=[]
    for arm in ARMS:
        for group,mask in CLASSES:
            weights=trend_weights(RA[1:][mask])
            for key in ('legacy','flat','bulk'):
                block=data[arm,key,0]
                for column_name in ('dv_same_star_kms','dv_fixed_ra_kms','pc'):
                    signal=column(block,column_name)[mask]
                    baseline=column(coarse[arm,key,0],column_name)[mask]
                    if key=='legacy':
                        assert max(abs(signal-column(old[arm,'measured',0],column_name)[mask]))<1e-9
                    if column_name=='dv_fixed_ra_kms':
                        conditions.append(dict(arm=arm,sample=group,case=key,readout='compensated_gradient',
                              relative=abs((weights@baseline)/(weights@signal)-1)))
                    conditions.append(dict(arm=arm,sample=group,case=key,readout=column_name,
                              relative=np.linalg.norm(baseline-signal)/np.linalg.norm(signal)))
                result.append(dict(arm=arm,sample=group,case=key,
                    gradient_raw=weights@column(block,'dv_same_star_kms')[mask],
                    gradient_reference_removed=weights@column(block,'dv_fixed_ra_kms')[mask],
                    max_pc=max(column(block,'pc')[mask])))
            sigmas={}
            for step,bank in ((.25,quarter),(.5,half)):
                deriv={}
                for key in VARIATIONS:
                    response=(column(bank[arm,key,step],'dv_fixed_ra_kms')-column(bank[arm,key,-step],'dv_fixed_ra_kms'))[mask]/(2*step)
                    deriv[key]=weights@response if key=='system' else np.linalg.norm(weights*response)
                sigmas[step]=np.sqrt(sum(deriv[k]**2 for k in VARIATIONS if k!='system'))
                if step==.25:
                    local.append(dict(arm=arm,sample=group,random_input_sigma=sigmas[step],
                         individual_distance=deriv['random_d'],correlated_pm=np.hypot(deriv['pm_first'],deriv['pm_second']),
                         shared_distance_scale_derivative=deriv['system']))
            conditions.append(dict(arm=arm,sample=group,case='quarter',readout='random_sigma',
                         relative=abs(sigmas[.5]/sigmas[.25]-1)))
    table('velocity-reference-comparison.csv',result)
    table('quarter-budget.csv',local);table('reference-refinements.csv',conditions)
    bad=[row for row in conditions if row['relative']>=.005]
    record('reference-verdict.json',dict(count=len(conditions),failed=bad,worst=max(r['relative'] for r in conditions)))
    print(len(conditions),'comparisons; failures',bad)

if __name__=='__main__':
    run()
