import csv
import math
from collections import Counter
from catalogue import HOME,fetch,record,table


def main():
    def coordinates(text):
        points=[]
        for line in text.splitlines():
            if not line.strip() or line.startswith('#'):continue
            entries=line.split()
            if len(entries)!=11:raise ValueError(entries[:2])
            points.append((float(entries[0]),float(entries[1]),entries[-1]))
        assert len(points)==109
        return points
    points=fetch('kuzma-table4.txt','https://arxiv.org/src/2202.04548v1/anc/Table4_extended_online.txt',{},coordinates)
    with (HOME/'rrl-input.csv').open(newline='') as stream:sample=list(csv.DictReader(stream))
    rows=[]
    for star in sample:
        ra,dec=map(float,(star['ra'],star['dec']))
        sep=[2*math.degrees(math.asin(math.sqrt(math.sin(.5*math.radians(y-dec))**2+
                math.cos(math.radians(y))*math.cos(math.radians(dec))*math.sin(.5*math.radians(x-ra))**2)))*3600 for x,y,_ in points]
        idx=min(range(len(sep)),key=sep.__getitem__)
        rows.append(dict(rrl_id=star['id'],region=star['region'],tail_11p2=star['tail_11p2'],
            nearest_table4_row=idx+1,nearest_arcsec=sep[idx],origin=points[idx][2],within_2s=sum(s<=2 for s in sep),
            within_5s=sum(s<=5 for s in sep)))
    table('cross-identification.csv',rows)
    record('overlap.json',dict(table4_rows=len(points),rrl_members=len(rows),sources=dict(Counter(p[2] for p in points)),
          within_2s=sum(int(r['within_2s']) for r in rows),within_5s=sum(int(r['within_5s']) for r in rows),
          closest_arcsec=min(r['nearest_arcsec'] for r in rows),
          note='Sky-only candidates, no RV values imported; shared literature training persists regardless of object matches.'))

if __name__=='__main__':
    main()
