import csv
import json
from replay import HOME,RA,DEC,D0,PMRA0,PMDEC0,CENTRAL,VARIATIONS,ARMS,TAIL,TRACK,RA0,CONV,ROT,SUN,VSUN,icrs,inputs,anchors,physical,observed,col,np
from catalogue import table,record,sha

GROUP=np.array([int(star['tail_11p2'])==1 for star in TAIL])
CLASSES=(('tail17',GROUP),('literal18',np.ones_like(GROUP)))

def load(label):
    with (HOME/f'predictions-{label}.csv').open(newline='') as stream:data=list(csv.DictReader(stream))
    result={}
    for row in data:
        key=(row['arm'],row['case'],float(row['amplitude']))
        result.setdefault(key,[]).append(row)
    for key,block in result.items():
        assert [row['id'] for row in block]==[row['id'] for row in TAIL]
    return result

def column(rows,name):
    return np.array([float(row[name]) if row[name]!='' else np.nan for row in rows])

def trend_weights(ra):
    offset=ra-ra.mean()
    return offset/(offset@offset)

def reductions(block,mask):
    vr=column(block,'dv_fixed_ra_kms')[mask]
    ra=RA[1:][mask]
    w=trend_weights(ra)
    dx=column(block,'ddec_fixed_ra_deg')[mask]
    keep=np.isfinite(dx);delta=ra[keep]-RA0
    dx=dx[keep]
    tilt=delta@dx/(delta@delta)
    residual=dx-tilt*delta
    jack=[trend_weights(np.delete(ra,i))@np.delete(vr,i) for i in range(len(ra))]
    return dict(tail_count=int(mask.sum()),gradient=float(w@vr),mean_fixed_ra_velocity=vr.mean(),max_velocity=max(abs(vr)),
        maximum_pc=max(column(block,'pc')[mask]),historical_error_fraction=abs(w@vr)/.15,track_supported=len(dx),
        track_rms_deg=np.sqrt(np.mean(dx*dx)),tilt_deg_per_deg=tilt,track_after_tilt_rms_deg=np.sqrt(np.mean(residual*residual)),
        tilt_power_percent=100*(1-residual@residual/(dx@dx)),leave_one_gradient_min=min(jack),leave_one_gradient_max=max(jack))

def frame_test():
    old_ra=np.r_[RA0,TRACK['ra']];old_dec=np.r_[-.124,TRACK['dec']]
    pair=physical(old_ra,old_dec,np.full_like(old_ra,22.05),np.full_like(old_ra,-2.296),np.full_like(old_ra,-2.257))
    assert max(abs(x-y).max() for x,y in zip(pair,anchors(22.05)))<1e-13
    coord,velocity=inputs('measured');ref=observed(coord,velocity)
    assert np.max(abs(ref[:,0]-RA))<1e-9 and np.max(abs(ref[:,1]-DEC))<1e-9
    assert np.max(abs(ref[:,2]-(-58.7+1.2*(RA-RA0))))<1e-9
    dist=np.linalg.norm(coord-SUN,axis=1)
    local=(velocity/CONV-VSUN)@ROT
    east=icrs(RA+90,RA*0);north=np.cross(icrs(RA,DEC),east)
    for basis,truth in ((east,np.r_[PMRA0,col('pmra')]),(north,np.r_[PMDEC0,col('pmdec')])):
        assert np.max(abs(np.sum(local*basis,axis=1)/(4.74047*dist)-truth))<1e-9

def main():
    frame_test()
    central=load('4-2-central')
    summaries=[];uncert=[];deriv=[];refinements=[]
    for arm in ARMS:
        for sample,mask in CLASSES:
            for key in CENTRAL:
                vals=reductions(central[arm,key,0],mask)
                summaries.append(dict(arm=arm,sample=sample,case=key,**vals))
            base=column(central[arm,'measured',0],'dv_fixed_ra_kms')[mask]
            w=trend_weights(RA[1:][mask])
            pooled={}
            for bank,amplitude in [('errors',1.),('half',.5)]:
                source=load('4-2-'+bank)
                output={}
                for key in VARIATIONS:
                    plus=column(source[arm,key,amplitude],'dv_fixed_ra_kms')[mask]
                    minus=column(source[arm,key,-amplitude],'dv_fixed_ra_kms')[mask]
                    response=(plus-minus)/(2*amplitude)
                    curvature=(.5*(plus+minus)-base)/(amplitude**2)
                    output[key]=w@response if key=='system' else np.linalg.norm(w*response)
                    deriv.append(dict(arm=arm,sample=sample,step=amplitude,direction=key,
                        gradient_plus=w@plus,gradient_minus=w@minus,rms_star_response=np.sqrt(np.mean(response**2)),
                        gradient_first_order=output[key],centered_gradient_curvature=w@curvature))
                pooled[amplitude]=output
            full,half=pooled[1.],pooled[.5]
            rand=lambda d:np.sqrt(sum(d[k]**2 for k in VARIATIONS if k!='system'))
            uncert.append(dict(arm=arm,sample=sample,gradient=w@base,random_input_sigma_full=rand(full),
                random_input_sigma_half=rand(half),random_distance=half['random_d'],
                pm_covariance=np.hypot(half['pm_first'],half['pm_second']),shared_scale_derivative=half['system'],
                relative_random_linearization_change=abs(rand(full)/rand(half)-1)))
    for low,high in [('2-1','4-1'),('4-1','4-2')]:
        first,second=load(low+'-central'),load(high+'-central')
        for arm in ARMS:
            for sample,mask in CLASSES:
                for key in CENTRAL:
                    a,b=first[arm,key,0],second[arm,key,0]
                    for name in ('dv_fixed_ra_kms','ddec_fixed_ra_deg','pc','gradient'):
                        if name=='gradient':v,u=[np.array([reductions(block,mask)['gradient']]) for block in (a,b)]
                        else:v,u=[column(block,name)[mask] for block in (a,b)]
                        valid=np.isfinite(u);assert np.array_equal(valid,np.isfinite(v))
                        relative=np.linalg.norm((v-u)[valid])/np.linalg.norm(u[valid])
                        refinements.append(dict(low=low,high=high,arm=arm,sample=sample,case=key,quantity=name,
                                                relative=relative,passes=bool(relative<.005)))
    table('scores.csv',summaries);table('input-uncertainties.csv',uncert);table('input-variations.csv',deriv)
    table('refinements.csv',refinements)
    bad=[row for row in refinements if not row['passes']]
    record('verification.json',dict(refinements=len(refinements),failures=bad,worst=max(r['relative'] for r in refinements),
        protocol=sha(HOME/'PROTOCOL.md'),selection=sha(HOME/'selection.json'),membership=sha(HOME/'MEMBERSHIP-NOTE.md'),
        response=sha(HOME/'replay.py'),measured_versus_fitted='conditional responses; no RV residuals scored'))
    print('Refinements',len(refinements),'failed',bad)

if __name__=='__main__':
    main()
