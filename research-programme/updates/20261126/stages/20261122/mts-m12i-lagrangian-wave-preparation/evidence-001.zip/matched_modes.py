from local_io import *
from initial_file import Initial,CACHE
from trace import growth
from music_power import power,transfer,stored_music
from scipy.interpolate import PchipInterpolator

def run():
    ic=Initial();box=ic.box/(1000*ic.h);target_a=.01
    pin(SEED,"seeds.py");sys.path.insert(0,str(SEED))
    from seeds import bank
    mref=bank("late-heavy");cref=bank("late-cold");volume=bank("volume-state")
    flag=(mref["both_scale_screens_pass"]==1)&(cref["both_scale_screens_pass"]==1)
    kn=volume["k_Mpc_inverse"][flag];assert len(kn)==99 and np.all(np.diff(kn)>0)
    n=np.r_[0:35,-34:0];xx,yy,zz=np.meshgrid(n,n,np.arange(35),indexing="ij")
    kt=2*np.pi/box*np.sqrt(xx**2+yy**2+zz**2)
    ok=(kt>=min(kn))&(kt<=2.4);kw=kt[ok]
    ix,iy,iz=[arr[ok] for arr in (xx,yy,zz)]
    mult=np.where(iz==0,1.,2.);vec=np.stack((ix,iy,iz))*2*np.pi/box
    def tf(col):return PchipInterpolator(np.log(kn),col[flag])(np.log(kw))
    phase=tf(volume["heavy_spatial_phase"]);density=tf(volume["heavy_coordinate_number_contrast"])
    cold=tf(volume["cold_coordinate_number_contrast"])
    local_cold=tf(mref["delta_cdm_N"]-3*mref["Phi"])
    div_cold=tf(mref["theta_cdm_N"]);div_wave=tf(mref["heavy_theta_N"])
    conformal=tf(mref["H_conformal_Mpc_inverse"])
    assert min(cold)*max(cold)>0
    grav_scale=tf(mref["test_mass_Mpc_inverse"])*target_a
    assert max(abs(tf(mref["heavy_theta_N"])+kw**2*phase/grav_scale))/max(abs(tf(mref["heavy_theta_N"])))<.005
    norm_test=power(.702)/transfer(.702)**2*.702**3/(2*np.pi)**3
    assert abs(norm_test/stored_music()["pnorm"]-1)<2e-5
    pk=power(kw);prim=np.sign(cold)*np.sqrt(2*np.pi**2*tf(volume["primordial_power"])/(kw**3*pk))
    initial,f=growth(ic.a,ic.om);target,_=growth(target_a,ic.om);grow=target/initial
    hub=ic.h*100*np.sqrt(ic.om/ic.a**3+ic.ol)
    counts=np.array(stored("census-check.json")["counts"]);p=counts.cumsum()/counts.sum()
    fractions=np.array([float(row["wave_fraction"]) for row in csv.DictReader((HERE/"conditional-occupation.csv").open())])
    def coefficients(prefix,grid):
        bank0={}
        for shift in (0,1):
            tag=f"{prefix}-{grid}-{shift}"
            path=CACHE/(tag+".npz");assert sha(path)==stored(tag+".json")["sha256"]
            window=np.sinc(ix/grid)**2*np.sinc(iy/grid)**2*np.sinc(iz/grid)**2
            align=np.exp(-1j*shift*np.pi*(ix+iy+iz)/grid)/window
            with np.load(path) as src:
                for key in src:
                    values=src[key][ok]*align
                    bank0[key]=bank0.get(key,0)+.5*values
        return bank0
    results=[];checks=[];payload={}
    for grid in (128,192):
        fire=coefficients("mesh",grid)
        velocity=-1j*(vec[0]*fire["vx"]+vec[1]*fire["vy"]+vec[2]*fire["vz"])/(ic.a*hub*f)
        d=fire["density"]
        for maximum in (.75,1.5,2.4):
            use=kw<=maximum
            def inner(left,right):return np.sum(mult[use]*(left[use].conj()*right[use]).real)
            checks.append(dict(grid=grid,k_max=maximum,count=int(sum(mult[use])),
                correlation=inner(d,velocity)/np.sqrt(inner(d,d)*inner(velocity,velocity)),
                density_momentum_rel_rms=np.sqrt(inner(d-velocity,d-velocity)/inner(d,d)),
                measured_over_theory=np.sum(mult[use]*abs(d[use])**2/(pk[use]/box**3))/sum(mult[use]),
                growing_velocity_power_over_density=inner(velocity,velocity)/inner(d,d)))
        for clock in ("birth","drift99"):
            windows=coefficients("window-"+clock,grid)
            pieces=np.stack([windows[str(j)] for j in range(5)])
            basis=(pieces*counts[:,None]).cumsum(axis=0)/counts.cumsum()[:,None]
            for estimator,field in (("density",d),("momentum",velocity)):
                modes=field*prim
                if grid==192 and clock=="drift99":
                    payload[estimator+"_curvature"]=modes;payload[estimator+"_heavy_number"]=modes*density
                    payload[estimator+"_phase"]=modes*phase;payload[estimator+"_paired_cold"]=modes*cold
                for maximum in (.75,1.5,2.4):
                    use=kw<=maximum
                    def avg(value):return ((basis[:,use].conj()*value[None,use]).real*mult[None,use]).sum(axis=1)
                    heavy=avg(modes*density);paired=avg(modes*cold);classical=avg(field*grow)
                    local=avg(modes*local_cold);divdiff=avg(modes*(div_cold-div_wave)/conformal)
                    vx,vy,vz=[avg(1j*comp*modes*phase/grav_scale*299792.458) for comp in vec]
                    sv=heavy-classical
                    for j in (0,1,2,4):
                        change=p[j]*(sv[j]-sv[-1])
                        results.append(dict(grid=grid,clock=clock,estimator=estimator,k_max=maximum,cut=j,
                            heavy_delta=heavy[j],cold_delta=paired[j],fire_linear=classical[j],
                            vx_kms=vx[j],vy_kms=vy[j],vz_kms=vz[j],
                            passive_core_fraction=p[j],delta_fraction=change,required_change=fractions[j]-p[j],
                            same_metric_relative_number=p[j]*((heavy[j]-local[j])-(heavy[-1]-local[-1])),
                            same_metric_relative_rate_per_efold=p[j]*(divdiff[j]-divdiff[-1]),
                            paired_in_place_response=p[j]*((heavy[j]-paired[j])-(heavy[-1]-paired[-1]))))
    table("phase-realization-checks.csv",checks);table("matched-window-fields.csv",results)
    packet("common-phase-conditional.npz",nx=ix,ny=iy,nz=iz,k_Mpc=kw,box_Mpc=box,a_music=ic.a,a_MTS=target_a,**payload)
    record("power-normalization.json",dict(integral_equivalent=norm_test,original_log=stored_music(),mesh_density_gauge="Newtonian cold growing-mode estimate",MTS_density_gauge="coordinate number (includes -3Phi)",clock_growth=grow))
    print(checks[-3:],flush=True)
if __name__=="__main__":run()
