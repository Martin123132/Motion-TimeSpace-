from census import Remote,uri
from local_io import *
from destination import labels
import h5py
def run():
    tags,counts,_,_=labels();ngrid=len(tags)
    total=np.zeros(5,dtype="i8")
    for piece in range(4):
        name=f"birth-000-{piece}"
        if (HERE/(name+".json")).exists():
            doc=stored(name+".json");assert sha(HERE/(name+".npz"))==doc["sha256"];total+=doc["counts"];continue
        with Remote(uri(0,piece),65536) as remote,h5py.File(remote) as file:
            group=file["PartType1"];head=file["Header"].attrs
            assert abs(head["Time"]-.01)<1e-10 and int(head["NumPart_Total"][1])==ngrid
            assert int(head["NumFilesPerSnapshot"])==4
            source={};selected=[];idxs=[]
            mass=group["Masses"];remote.load_field(mass);value=float(mass[0])
            for left in range(0,len(mass),350000):assert np.all(mass[left:left+350000]==value)
            assert abs(value*1e10/head["HubbleParam"]/stored("tags-544-0.json")["mass_Msun"]-1)<1e-9
            remote.spans.clear()
            for key in ("ParticleIDs","Coordinates","Velocities"):
                guard();dataset=group[key];remote.load_field(dataset);dig=hashlib.sha256();kept=[]
                for left in range(0,len(dataset),350000):
                    data=dataset[left:left+350000];dig.update(data.tobytes())
                    if key=="ParticleIDs":
                        assert min(data)>=ngrid and max(data)<2*ngrid
                        sub=tags[data-ngrid]<5;selected.append(sub);idxs.append(data[sub])
                    else:kept.append(data[selected[left//350000]])
                source[key]=dig.hexdigest()
                if key=="Coordinates":pos=np.concatenate(kept)
                if key=="Velocities":vel=np.concatenate(kept)
                remote.spans.clear()
            ids=np.concatenate(idxs);order=np.argsort(ids);ids=ids[order]
            assert np.all(np.diff(ids.astype("i8"))>0)
            record_counts=np.bincount(tags[ids-ngrid],minlength=5)
            packet(name+".npz",ids=ids,pos=pos[order],vel=vel[order])
            doc=dict(source=source,size=len(dataset),url=remote.url,identity=remote.id,transferred=remote.transferred,
                counts=record_counts.tolist(),scale=float(head["Time"]),h=float(head["HubbleParam"]),box=float(head["BoxSize"]),sha256=sha(HERE/(name+".npz")))
            record(name+".json",doc);total+=record_counts;print(name,doc["counts"],flush=True)
    assert np.array_equal(counts,total)
if __name__=="__main__":
    row=stored("lineage-headers.json")[0]
    assert row["snap"]==0 and row["dark"]!=70514272 and not row["count_compatible"]
    print("Rejected slot zero: unequal fine-particle universes; no join or downloads.")
