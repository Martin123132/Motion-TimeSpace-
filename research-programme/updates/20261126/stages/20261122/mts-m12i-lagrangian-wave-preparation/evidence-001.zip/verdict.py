from local_io import *
from destination import required
from initial_file import Initial,CACHE
from scipy.optimize import minimize
def run():
    def read(path):
        with (HERE/path).open() as stream:return list(csv.DictReader(stream))
    ic=Initial();assert sha(ic.path)==stored("initial-complete.json")["sha256"]
    for prefix in ("mesh","window-birth","window-drift99"):
        for size in (128,192):
            for offset in (0,1):
                tag=f"{prefix}-{size}-{offset}";assert sha(CACHE/(tag+".npz"))==stored(tag+".json")["sha256"]
    icids=ic.count[1];assert sum(stored(f"tags-544-{idx}.json")["rows"] for idx in range(4))==icids
    cols=read("conditional-occupation.csv");dec=[]
    for row in cols[:-1]:
        p=float(row["cold_fraction"]);target=float(row["wave_fraction"])
        ratio=target*(1-p)/(p*(1-target))
        rms=float(row["min_rms_weight_change"])
        core,outer=target/p,(1-target)/(1-p)
        assert abs(core/outer/ratio-1)<1e-12 and abs(p*(core-1)**2+(1-p)*(outer-1)**2-rms**2)<1e-12
        dec.append(dict(radius_kpc=float(row["radius_kpc"]),relative_mean_birth_weight_needed=ratio,core_weight=core,other_weight=outer,
            epsilon_min_if_both_density_contrasts_bounded=(np.sqrt(ratio)-1)/(np.sqrt(ratio)+1),
            min_rms=rms,excess_over_passive_Msun=float(row["excess_over_uniform_share_Msun"])))
    table("sharp-passive-bounds.csv",dec)
    for target in (.49,.75,.91):
        prob=np.array([.1,.3,.5,.1]);h=np.array([.05,.2,.5,.95])
        _,value=required(h,prob,target)
        res=minimize(lambda w:prob@(w-1)**2,np.ones(4),method="SLSQP",bounds=[(0,None)]*4,
            constraints=[dict(type="eq",fun=lambda w:prob@w-1),dict(type="eq",fun=lambda w:prob@(h*w)-target)],
            options=dict(ftol=1e-12))
        assert res.success and value is not None and abs(np.sqrt(res.fun)-value)<1e-7
    assert required(h,prob,.98)[1] is None
    metrics=read("matched-window-fields.csv");checks=[]
    def fetch(n,clock,method,k,j):
        return next(row for row in metrics if (row["grid"],row["clock"],row["estimator"],row["k_max"],row["cut"])==(str(n),clock,method,str(k),str(j)))
    for maximum in (.75,1.5,2.4):
        for j in (0,1,2):
            for key in ("heavy_delta","delta_fraction","same_metric_relative_rate_per_efold"):
                val=lambda n,c,m:float(fetch(n,c,m,maximum,j)[key])
                a,b=val(192,"drift99","density"),val(192,"drift99","momentum")
                rel=lambda x,y:abs(x-y)/max(abs(x),abs(y),1e-100)
                diff=rel(a,b)
                mesh=max(rel(val(128,"drift99",m),val(192,"drift99",m)) for m in ("density","momentum"))
                clock=max(rel(val(192,"birth",m),val(192,"drift99",m)) for m in ("density","momentum"))
                checks.append(dict(max_k=maximum,cut=j,test=key,from_density=a,from_momentum=b,estimator_difference=diff,
                    mesh_difference=mesh,drift_clock_sensitivity=clock,all_under_0p005=max(diff,mesh,clock)<.005,
                    all_under_2e5=max(diff,mesh,clock)<2e-5))
    table("conditional-field-gates.csv",checks)
    stats=read("phase-realization-checks.csv")
    err=max(float(row["density_momentum_rel_rms"]) for row in stats)
    assert err>.005
    with np.load(HERE/"common-phase-conditional.npz") as saved:
        assert (saved["k_Mpc"]>=.2925).all() and (saved["k_Mpc"]<=2.4).all()
        for key in saved.files:assert np.all(np.isfinite(saved[key]))
        assert 2*np.count_nonzero(saved["nz"]>0)+np.count_nonzero(saved["nz"]==0)==145346
    spot=read("direct-growing-check.csv")
    record("decision.json",dict(checks=len(checks),loose_pass=sum(row["all_under_0p005"] for row in checks),
        tight_pass=sum(row["all_under_2e5"] for row in checks),excluded_snapshot=0,original_z=ic.redshift,
        actual_host_tracers=stored("census-check.json")["tagged"],unique_wave_restart=False,
        numerical_controls="mass and number accounting, four particle Fourier sums, independent convex optimizer, exact archived radial integrals",
        max_direct_sample_disagreement=max(float(row["actual_relative_disagreement"]) for row in spot)))
if __name__=="__main__":run()
