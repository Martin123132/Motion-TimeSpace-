from local_io import *
from scipy.special import roots_legendre
from numpy.polynomial.legendre import legvander
from scipy.optimize import brentq

def wave_masses(cuts,order):
    env=ROOT/"mts-preparation-vertical-gravity-590-20261122";lat=ROOT/"mts-high-latitude-preparation-null-590-20261122"
    PINS[env]="37a872fe0e0c207030ca5c4825940b22be066191dcfd3097d28f3169b104aef7"
    PINS[lat]="06e46c345f46f6e927fb493ea4dcfa95acd67f1e56885849189b42f6f35f8c71"
    with np.load(pin(env,"launch.npz")) as src:edges,knots,scale=src["edges"],src["knots"],float(src["mscale"]/src["length"])
    with np.load(pin(lat,"native-map.npz")) as src:indices,weights=src["indices"],src["sqrt"]
    with np.load(pin(EARLY,"ground-anchorA.npz")) as src:amp=src["early"].reshape(len(weights),-1)
    nodal=np.pad(amp/weights[:,None],((1,1),(0,0)))[indices]*np.sqrt(scale)
    parts=np.unique(np.r_[edges,cuts]);nodes,weights=roots_legendre(order)
    half=np.diff(parts)[:,None]/2;shell=(parts[:-1,None]+half*(1+nodes)).ravel()
    idx=np.searchsorted(edges[1:],shell);local=2*(shell-edges[idx])/np.diff(edges)[idx]-1
    read=legvander(local,len(knots)-1)@np.linalg.inv(legvander(2*knots-1,len(knots)-1))
    density=np.sum(abs(np.einsum("ri,ril->rl",read,nodal[idx]))**2,axis=1)
    mass=density*(half*weights).ravel()
    return np.array([np.sum(mass[shell<edge]) for edge in cuts]),mass.sum()

def labels():
    counts=stored("tags-544-0.json")
    count=70514272;total=np.full(count,5,dtype="u1")
    cut=np.array(counts["cut_kpc"]);m=counts["mass_Msun"];bygroup=np.zeros(5,dtype=np.int64);seen=0
    for piece in range(4):
        name=f"tags-544-{piece}";doc=stored(name+".json")
        assert doc["cut_kpc"]==counts["cut_kpc"] and doc["mass_Msun"]==m and sha(HERE/(name+".npz"))==doc["sha256"]
        with np.load(HERE/(name+".npz")) as data:
            ids,z=data["ids"],data["zone"]
            assert np.all(np.diff(ids.astype("i8"))>0) and min(ids)>=count and max(ids)<2*count
            key=ids-count;assert np.all(total[key]==5)
            total[key]=z;bygroup+=np.bincount(z,minlength=5)
        seen+=doc["rows"]
    assert seen==count and np.array_equal(np.bincount(total,minlength=6)[:5],bygroup)
    return total,bygroup,cut,m

def required(frac,prob,target):
    h=np.asarray(frac);q=np.asarray(prob);p=q@h
    if target<p:return required(1-h,q,1-target)
    variance=q@(h-p)**2
    if variance<1e-24:return (None,None)
    lower=float((target-p)/np.sqrt(variance))
    if h.max()<target-1e-12:return lower,None
    if abs(target-p)<1e-14:return 0.,0.
    if (1+(target-p)*(h-p)/variance).min()>=0:return lower,lower
    def moment(t):
        w=np.maximum(0,h-t);return (q*w)@(h-target)
    t=brentq(moment,min(h)-100,max(h)-1e-12,xtol=1e-13)
    w=np.maximum(0,h-t);w/=q@w
    assert abs(q@(w*h)-target)<2e-8 and abs(q@w-1)<2e-12
    return lower,float(np.sqrt(q@(w-1)**2))

def run():
    tags,counts,cuts,m=labels()
    mass,whole=wave_masses(cuts,18);other,_=wave_masses(cuts,26)
    assert max(abs(other/mass-1))<2e-12
    assert abs(mass[0]/115840108484.46729-1)<2e-8
    rows=[]
    for idx,(radius,num,wave) in enumerate(zip(cuts,counts.cumsum(),mass)):
        p=num/counts.sum();target=wave/mass[-1]
        row=dict(radius_kpc=radius,particles=int(num),cold_Msun=num*m,wave_Msun=wave,
            cold_fraction=p,wave_fraction=target,wave_over_cold=wave/(num*m),
            min_rms_weight_change=abs(target-p)/np.sqrt(p*(1-p)) if idx<4 else 0.,
            excess_over_uniform_share_Msun=(target-p)*mass[-1])
        rows.append(row)
    table("conditional-occupation.csv",rows)
    record("census-check.json",dict(seen=70514272,tagged=int(counts.sum()),total_wave_Msun=whole,counts=counts.tolist(),state="544 stationary seed, not observed"))
    return rows
if __name__=="__main__":run()
