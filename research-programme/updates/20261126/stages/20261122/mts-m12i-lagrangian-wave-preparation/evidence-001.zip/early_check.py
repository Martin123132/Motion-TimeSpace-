from trace import *
from initial_file import BASE,FILENAME
import requests
def run():
    file="gizmo_parameters.txt-usedvalues"
    if not (HERE/file).exists():
        with requests.get(BASE.split("initial_condition/")[0]+file,timeout=20) as r:
            r.raise_for_status();assert len(r.content)<20000;keep(file,r.content)
    vals=dict(line.split()[:2] for line in (HERE/file).read_text().splitlines() if len(line.split())>=2)
    ic=Initial()
    assert vals["InitCondFile"]=="initial_condition/"+FILENAME and abs(float(vals["TimeBegin"])-ic.a)<2e-9
    assert float(vals["UnitVelocity_in_cm_per_s"])==1e5
    tags,_,_,_=labels();rows=[];known=set();diffs=[]
    for piece in range(4):
        tag=f"early-001-{piece}";doc=stored(tag+".json");assert sha(HERE/(tag+".npz"))==doc["sha256"]
        with np.load(HERE/(tag+".npz")) as bank:ids,pos,vel=bank["ids"],bank["pos"],bank["vel"]
        assert np.array_equal(ic.ids[ids],ids) and len(set(map(int,ids)))==len(ids)
        assert known.isdisjoint(map(int,ids));known.update(map(int,ids))
        epoch=doc["scale"];box=ic.box/(1000*ic.h)
        initial=ic.pos[ids].astype(float)/(1000*ic.h);vv=ic.vel[ids].astype(float)*np.sqrt(ic.a)
        def distance(first,second):
            delta=first-second
            return np.linalg.norm(delta-box*np.rint(delta/box),axis=1)
        final=pos/(1000*ic.h);actual=distance(final,initial)
        guess=linear_motion(ic,vv,epoch)
        predicted=distance(final,initial+guess)
        rng=np.random.default_rng(544+piece);scramble=rng.permutation(len(pos))
        wrong=distance(final,(initial+guess)[scramble])
        host=tags[ids-ic.starts[1]]<5
        for name,use in (("fine sample",np.ones(len(pos),dtype=bool)),("544 host",host)):
            rms=lambda x:float(np.sqrt(np.mean(x[use]**2)))
            rows.append(dict(piece=piece,set=name,n=int(sum(use)),rms_actual_Mpc=rms(actual),rms_growing_residual_Mpc=rms(predicted),
                rms_shuffled_residual_Mpc=rms(wrong),rms_ratio=rms(predicted)/rms(wrong),p90_residual_Mpc=np.quantile(predicted[use],.9)))
            assert rms(predicted)<rms(actual) and rms(predicted)<.1*rms(wrong)
    table("early-lineage-motion.csv",rows)
if __name__=="__main__":run()
