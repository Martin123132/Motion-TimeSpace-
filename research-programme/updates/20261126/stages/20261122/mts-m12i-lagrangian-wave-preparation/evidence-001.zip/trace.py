from initial_file import Initial
from local_io import *
from destination import labels,required,wave_masses
from scipy.integrate import quad

def growth(a,om):
    hub=lambda x:np.sqrt(om/x**3+1-om)
    integ=quad(lambda x:1/(x*hub(x))**3,0.,a,epsabs=1e-18,epsrel=1e-11)[0]
    return hub(a)*integ,-1.5*(om/a**3)/hub(a)**2 + 1/(a*a*hub(a)**3*integ)
def load_host():
    ic=Initial();zone,count,cut,m=labels()
    ids=np.flatnonzero(zone<5)+ic.starts[1]
    assert len(ids)==count.sum() and np.max(ids)<ic.starts[2]
    for start in range(0,ic.total,2000000):
        guard();end=min(ic.total,start+2000000)
        assert np.array_equal(ic.ids[start:end],np.arange(start,end,dtype="u4"))
    pos=ic.pos[ids].astype(float)/(1000*ic.h);vel=ic.vel[ids].astype(float)*np.sqrt(ic.a)
    box=ic.box/(1000*ic.h)
    offset=pos-pos[0];assert np.max(abs(offset))<box*.5,"unwrap before centroid"
    assert np.max(np.ptp(pos,axis=0))<box/2
    return ic,ids,zone[ids-ic.starts[1]],pos,vel,cut
def linear_motion(ic,vel,at):
    initial,f=growth(ic.a,ic.om);end,_=growth(at,ic.om)
    hub=ic.h*100*np.sqrt(ic.om/ic.a**3+ic.ol)
    return (end/initial-1)*vel/(ic.a*hub*f)
def mix(z,pos,cut,actual,box):
    rows=[];ng=len(z);p=np.cumsum(np.bincount(z))/ng
    lower=pos.min(axis=0)
    for cells in (32,64,128,256,512,1024):
        for frac in (0.,.5):
            dx=box/cells
            loc=np.floor((pos-lower)/dx+frac).astype("i4")
            shape=np.max(loc,axis=0)+1
            bins=((loc[:,0]*shape[1]+loc[:,1])*shape[2]+loc[:,2]).astype("i8")
            nums=np.bincount(bins*5+z,minlength=int(np.prod(shape))*5).reshape(-1,5)
            sums=nums.sum(axis=1);use=sums>0
            nums=nums[use];sums=sums[use];prob=sums/ng
            for idx in (0,1,2):
                h=nums[:,:idx+1].sum(axis=1)/sums;target=actual[idx]/actual[-1]
                lb,minrms=required(h,prob,target)
                rows.append(dict(n=cells,shift=frac,bin_Mpc=dx,radius_kpc=cut[idx],cold_fraction=p[idx],target=target,
                    max_bin_fraction=h.max(),rms_conditional=np.sqrt(prob@(h-p[idx])**2),rms_unrestricted_lower=lb,
                    attainable_nonnegative=minrms is not None,min_nonnegative_rms=minrms,within_lipschitz_Mpc=np.sqrt(3)*dx*(prob@(h*(1-h)))))
    table("initial-cell-occupation.csv",rows)
def run():
    ic,ids,z,pos,vel,cut=load_host()
    actual,_=wave_masses(cut,18);center=pos.mean(axis=0);vcenter=vel.mean(axis=0)
    radius=np.linalg.norm(pos-center,axis=1)
    host_axis=np.linalg.eigvalsh(np.cov(pos.T));rows=[]
    for idx,edge in enumerate(cut):
        use=z<=idx;n=use.sum();points=pos[use];speed=vel[use]
        own=points.mean(axis=0);cov=(points-own).T@(points-own)/n
        rad=np.linalg.norm(points-own,axis=1)
        costar=np.quantile(radius,float(n/len(z)),method="inverted_cdf")
        test=radius<=costar
        selected=(test&use).sum()
        assert abs(test.sum()-n)<=2
        dv=speed-vcenter
        ur=np.einsum("ij,ij->i",points-center,dv)/np.maximum(radius[use],1e-20)
        rows.append(dict(radius_kpc=edge,n=int(n),half_mass_extent_Mpc=np.median(rad),r90_Mpc=np.quantile(rad,.9),
            center_x=own[0],center_y=own[1],center_z=own[2],minor_major=np.sqrt(np.linalg.eigvalsh(cov)[0]/np.linalg.eigvalsh(cov)[-1]),
            mean_vx=speed[:,0].mean(),mean_vy=speed[:,1].mean(),mean_vz=speed[:,2].mean(),velocity_rms_kms=np.sqrt(np.mean(np.sum((speed-speed.mean(axis=0))**2,axis=1))),
            mean_relative_radial_peculiar_kms=ur.mean(),equal_count_initial_sphere_Mpc=costar,initial_sphere_recall=selected/n))
    table("traced-initial-shape.csv",rows)
    sample=ids%257==0
    packet("traced-witness.npz",ids=ids[sample].astype("u4"),zone=z[sample],pos_Mpc=pos[sample],vel_kms=vel[sample])
    mix(z,pos,cut,actual,ic.box/(1000*ic.h))
    print("tagged",len(z),"birth extent",rows[0],"all",rows[-1],flush=True)
if __name__=="__main__":run()
