from local_io import *
import h5py
pin(DRIVE,"fire_source.py");sys.path.insert(0,str(DRIVE))
from fire_source import Remote,uri
def run(piece):
    name=f"tags-544-{piece}"
    if (HERE/(name+".json")).exists():
        assert sha(HERE/(name+".npz"))==stored(name+".json")["sha256"];return
    cut,host,rockmass=boundaries();h,a=coord()[:2];c=coord()[2:5]
    meta=json.loads(pin(EARLY,f"mass-544-{piece}.json").read_bytes())
    ids=[];shells=[];sentinel=[];dig={};sample=[]
    with Remote(uri(544,piece),65536) as remote,h5py.File(remote) as file:
        head=file["Header"].attrs
        assert abs(head["Time"]-a)<1e-8 and abs(head["HubbleParam"]-h)<1e-8
        hd=file["PartType1"];coords=hd["Coordinates"];ident=hd["ParticleIDs"]
        mass=float(head["MassTable"][1]);size=len(coords)
        assert size==meta["counts_piece"][1]==len(ident)
        assert size>0 and tuple(meta["server_identity"])==remote.id
        if not mass:
            masses=hd["Masses"];remote.load_field(masses);mass=float(masses[0])
            for start in range(0,size,500000):assert np.all(masses[start:start+500000]==np.float32(mass))
            remote.spans.clear()
        for dataset in (coords,ident):remote.load_field(dataset)
        digc,digi=hashlib.sha256(),hashlib.sha256()
        for start in range(0,size,250000):
            guard()
            raw=coords[start:start+250000];index=ident[start:start+250000]
            digc.update(raw.tobytes());digi.update(index.tobytes())
            offset=raw.astype(float)-c*h;box=float(head["BoxSize"])
            offset=(offset-box*np.rint(offset/box))*a/h
            radii=np.linalg.norm(offset,axis=1);group=np.searchsorted(cut,radii)
            use=group<len(cut)
            ids.append(index[use].astype(np.uint32));shells.append(group[use].astype(np.uint8))
            assert np.max(index)<2**32 and np.min(index)>=0
            if start==0:sentinel=index[:12].tolist()
        summary=dict(url=remote.url,identity=remote.id,transfer=remote.transferred,rows=size,mass_Msun=mass*1e10/h,
           cut_kpc=cut.tolist(),catalog_id=host,catalog_mass_Msun=rockmass,coordinates_hash=digc.hexdigest(),id_hash=digi.hexdigest(),sentinel=sentinel)
    idx=np.concatenate(ids);zones=np.concatenate(shells);sort=np.argsort(idx)
    assert not np.any(np.diff(idx[sort])==0)
    packet(name+".npz",ids=idx[sort],zone=zones[sort])
    summary.update(counts=np.bincount(zones,minlength=5).tolist(),sha256=sha(HERE/(name+".npz")))
    record(name+".json",summary);print(piece,size,summary["counts"],flush=True)
if __name__=="__main__":
    for piece in range(4):run(piece)
