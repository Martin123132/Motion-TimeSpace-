import os
for key in ("OPENBLAS_NUM_THREADS","OMP_NUM_THREADS","MKL_NUM_THREADS","NUMEXPR_NUM_THREADS","BLIS_NUM_THREADS"):os.environ[key]="1"
import csv,hashlib,io,json,sys
from pathlib import Path
import numpy as np
HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
EARLY=ROOT/"mts-pre572-wave-preparation-20261120"
DRIVE=ROOT/"mts-fire-joint-baryon-history-20261120"
CAT=ROOT/"mts-host-local-tidal-basin-544-20261122"
SEED=ROOT/"mts-primordial-patch-infall-20261120"
PINS={EARLY:"ce9ca0f03916af1fa3bfd449a61e779a74ce3427fae0a3a6bcdf65bc2b6c70ee",DRIVE:"19c78eaa158a766bd409c0a64504788b1346542eccee37c004083a918c480d67",CAT:"560bb52df749765f7d3dceacb663845b508380ec00b75b0389914a189f285e40",SEED:"a9f7723564116720ba5bc03333239d8fc0f106a6c2f14ca052f94e822aee2467"}
def guard():
    assert __debug__ and not any((loc/"STOP-REQUESTED").exists() for loc in (HERE,ROOT,*PINS))
def sha(path):
    with path.open("rb") as stream:return hashlib.file_digest(stream,"sha256").hexdigest()
def pin(place,name):
    guard();seal=place/"seal.json";assert sha(seal)==PINS[place];doc=json.loads(seal.read_bytes());path=place/name
    assert sha(path)==doc.get("files",doc)[name];return path
def keep(name,data):
    guard();path=HERE/name
    if path.exists():assert path.read_bytes()==data,path
    else:
        with path.open("xb") as stream:stream.write(data)
def record(name,value):keep(name,(json.dumps(value,indent=2,sort_keys=True,allow_nan=False)+chr(10)).encode())
def packet(name,**fields):
    buf=io.BytesIO();np.savez_compressed(buf,**fields);keep(name,buf.getvalue())
def table(name,rows):
    buf=io.StringIO();wr=csv.DictWriter(buf,rows[0],lineterminator=chr(10));wr.writeheader();wr.writerows(rows);keep(name,buf.getvalue().encode())
def coord():
    text=pin(EARLY,"544_coords_DR.txt").read_text()
    return np.fromstring(" ".join(line for line in text.splitlines() if not line.lstrip().startswith("#")),sep=" ")
def boundaries():
    import h5py
    h,a,*_=coord();center=coord()[2:5]
    with h5py.File(pin(CAT,"halo_544.hdf5")) as cat:
        pos=cat["position"][:]-center;box=cat["info:box.length"][()]
        dist=a*np.linalg.norm(pos-box*np.rint(pos/box),axis=1)
        idx=np.flatnonzero((dist<5)&~cat["am.phantom"][:].astype(bool))
        host=idx[np.argmax(cat["mass"][:][idx])]
        return np.array([np.hypot(11.9,7.3),16.6,50.,100.,float(cat["radius"][host])]),int(cat["id"][host]),float(cat["mass"][host])
def stored(name):return json.loads((HERE/name).read_bytes())
