from initial_file import Initial,CACHE
from local_io import *
from destination import labels
from trace import growth,linear_motion
def run():
    ic=Initial();tags,counts,cuts,_=labels()
    vectors=np.array([[4,1,1],[-6,4,2],[13,-5,3],[17,-14,19]])
    mass_sum=0.;raw=np.zeros((4,len(vectors)),complex);windows=np.zeros((5,len(vectors)),complex)
    for part in (0,1,2):
        lo,hi=ic.starts[part:part+2]
        for start in range(lo,hi,400000):
            guard();end=min(hi,start+400000);pos=ic.pos[start:end].astype(float)/ic.box
            vel=ic.vel[start:end].astype(float)*np.sqrt(ic.a)
            mass=ic.coarse[start-lo:end-lo].astype(float) if part==2 else np.full(end-start,ic.mass[part])
            phase=-2*np.pi*(pos@vectors.T);basis=np.cos(phase)+1j*np.sin(phase)
            raw[0]+=mass@basis;raw[1:]+=(mass[:,None]*vel).T@basis
            mass_sum+=np.sum(mass)
            if part==1:
                zone=tags[start-lo:end-lo]
                for cut in range(5):windows[cut]+=basis[zone==cut].sum(axis=0)
    raw/=mass_sum;windows/=counts[:,None]
    packet("direct-fourier.npz",integer_modes=vectors,field=raw,windows=windows)
    keys=["density","vx","vy","vz"];rows=[]
    for cells in (128,192):
        for prefix,ref,names in (("mesh",raw,keys),("window-birth",windows,list(map(str,range(5))))):
            result=np.zeros_like(ref)
            for offset in (0,1):
                tag=f"{prefix}-{cells}-{offset}";path=CACHE/(tag+".npz")
                assert sha(path)==stored(tag+".json")["sha256"]
                with np.load(path) as bank:
                    for j,(nx,ny,nz) in enumerate(vectors):
                        adjust=np.exp(-1j*np.pi*offset*(nx+ny+nz)/cells)/np.prod(np.sinc(vectors[j]/cells)**2)
                        for ch,key in enumerate(names):result[ch,j]+=.5*adjust*bank[key][nx,ny,nz]
            for ch,key in enumerate(names):
                rows.append(dict(grid=cells,set=prefix,channel=key,relative_l2_four_modes=np.linalg.norm(result[ch]-ref[ch])/np.linalg.norm(ref[ch]),
                    maximum_relative_mode=max(abs(result[ch]-ref[ch])/np.maximum(abs(ref[ch]),1e-24))))
    table("direct-mode-checks.csv",rows)
    vec=2*np.pi/(ic.box/1000/ic.h)*vectors;_,f=growth(ic.a,ic.om)
    vel=-1j*(vec*raw[1:].T).sum(axis=1)/(ic.a*100*ic.h*np.sqrt(ic.om/ic.a**3+ic.ol)*f)
    table("direct-growing-check.csv",[dict(nx=int(n[0]),ny=int(n[1]),nz=int(n[2]),wave_number=np.linalg.norm(k),
          density_abs=abs(d),velocity_est_abs=abs(v),actual_relative_disagreement=abs(v-d)/abs(d)) for n,k,d,v in zip(vectors,vec,raw[0],vel)])
if __name__=="__main__":run()
