from local_io import *
import requests,struct
BASE="https://users.flatironinstitute.org/~mgrudic/fire2_public_release/core/m12i_res7100/initial_condition/"
FILENAME="ic_agora_m12i_ref13_rad4-chull.ics"
CACHE=HERE/"raw-cache"
def get():
    guard();CACHE.mkdir(exist_ok=True)
    for name in ("ic_agora_m12i.conf","ic_agora_m12i_ref12_rad4_points_log.txt","ic_agora_m12i_ref12_rad4_points.txt","ic_agora_m12i.conf_log.txt","music_job5252342.txt"):
        if not (HERE/name).exists():
            with requests.get(BASE+name,timeout=(10,45)) as r:r.raise_for_status();assert len(r.content)<250000;keep(name,r.content)
    with requests.Session() as session:
        url=BASE+FILENAME
        with session.get(url,headers={"Range":"bytes=0-263","Accept-Encoding":"identity"},stream=True,timeout=(10,45)) as r:
            assert r.status_code==206
            size=int(r.headers["Content-Range"].split("/")[1]);tag=r.headers["ETag"];header=r.raw.read(265)
        assert size==4407283216 and len(header)==264
        record("initial-source.json",dict(url=url,size=size,etag=tag,header_sha256=hashlib.sha256(header).hexdigest()))
        dest=CACHE/FILENAME;tmp=CACHE/(FILENAME+".partial")
        if dest.exists():assert dest.stat().st_size==size and sha(dest)==stored("initial-complete.json")["sha256"];return
        block=16*1024**2
        with tmp.open("ab") as out:
            assert out.tell()%block==0 or out.tell()==size
            while out.tell()<size:
                guard();left=out.tell();right=min(size,left+block)-1
                for attempt in range(3):
                    try:
                        with session.get(url,headers={"Range":f"bytes={left}-{right}","If-Match":tag,"Accept-Encoding":"identity"},stream=True,timeout=(10,90)) as r:
                            assert r.status_code==206 and r.headers["ETag"]==tag and r.headers["Content-Range"]==f"bytes {left}-{right}/{size}"
                            raw=r.raw.read(right-left+2);assert len(raw)==right-left+1
                        break
                    except (OSError,requests.RequestException):
                        if attempt==2:raise
                out.write(raw);out.flush()
                if (left//block)%24==0:print("MUSIC bytes",out.tell(),"/",size,flush=True)
        digest=sha(tmp)
        with tmp.open("rb") as stream:assert stream.read(264)==header
        record("initial-complete.json",dict(size=size,sha256=digest))
        assert not dest.exists();tmp.rename(dest)

class Initial:
    def __init__(self):
        self.path=CACHE/FILENAME;doc=stored("initial-complete.json");assert self.path.stat().st_size==doc["size"]
        with self.path.open("rb") as stream:
            head=stream.read(264)
            assert hashlib.sha256(head).hexdigest()==stored("initial-source.json")["header_sha256"]
            self.count=np.array(struct.unpack_from("<6I",head,4))
            self.mass=np.array(struct.unpack_from("<6d",head,28));self.a,self.redshift=struct.unpack_from("<2d",head,76)
            self.box,self.om,self.ol,self.h=struct.unpack_from("<4d",head,132)
            self.total=int(sum(self.count));self.starts=np.r_[0,self.count.cumsum()]
            dims=(self.total*3,self.total*3,self.total,int(sum(self.count[self.mass==0])))
            offsets=[]
            for dim in dims:
                length=struct.unpack("<I",stream.read(4))[0];assert length==4*dim
                offsets.append(stream.tell());stream.seek(length,1);assert stream.read(4)==struct.pack("<I",length)
            self.pos,self.vel=[np.memmap(self.path,mode="r",dtype="<f4",offset=x,shape=(self.total,3)) for x in offsets[:2]]
            self.ids=np.memmap(self.path,mode="r",dtype="<u4",offset=offsets[2],shape=(self.total,))
            self.coarse=np.memmap(self.path,mode="r",dtype="<f4",offset=offsets[3],shape=(dims[3],))
        assert self.count[0]==self.count[1] and self.count[2]>0 and not np.any(self.count[3:])
        assert abs((1+self.redshift)*self.a-1)<1e-12 and abs(self.h-.702)<1e-12
if __name__=="__main__":get()
