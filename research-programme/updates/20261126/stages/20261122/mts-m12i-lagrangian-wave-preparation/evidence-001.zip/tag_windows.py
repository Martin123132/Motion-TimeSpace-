from assignment import CDLL,c_void_p,c_double,c_int,CACHE,rfftn
from trace import *
def run():
    ic,ids,zone,pos,vel,cut=load_host();length=ic.box/(1000*ic.h)
    counts=np.bincount(zone,minlength=5);del ids
    call=CDLL(str(CACHE/"mass_assignment.dll")).assign_tags;call.argtypes=[c_void_p,c_void_p,c_int,c_double,c_int,c_double,c_void_p];call.restype=None
    for clock in ("birth","drift99"):
        if clock=="drift99":pos+=linear_motion(ic,vel,.01)
        for cells,shift in ((128,0.),(128,.5),(192,0.),(192,.5)):
            tag=f"window-{clock}-{cells}-{int(2*shift)}";file=CACHE/(tag+".npz")
            if (HERE/(tag+".json")).exists():
                assert sha(file)==stored(tag+".json")["sha256"];continue
            grid=np.zeros((cells,cells,cells,5))
            for start in range(0,len(pos),1000000):
                stop=min(len(pos),start+1000000);guard()
                call(pos[start:stop].ctypes.data,zone[start:stop].ctypes.data,stop-start,length,cells,shift,grid.ctypes.data)
            total=grid.sum(axis=(0,1,2))
            assert np.max(abs(total/counts-1))<2e-11
            modes=34;indices=np.r_[0:modes+1,cells-modes:cells]
            fields={str(j):rfftn(grid[:,:,:,j],workers=1)[indices][:,indices,:modes+1]/counts[j] for j in range(5)}
            assert not file.exists()
            with file.open("xb") as handle:np.savez_compressed(handle,**fields)
            record(tag+".json",dict(sha256=sha(file),count=counts.tolist(),mean_pos=pos.mean(axis=0).tolist()))
            print(tag,flush=True)
if __name__=="__main__":run()
