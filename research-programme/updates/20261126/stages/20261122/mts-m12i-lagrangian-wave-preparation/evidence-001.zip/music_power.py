from local_io import *
from scipy.integrate import simpson
from scipy.special import spherical_jn
def transfer(k):
    h,om,ob=.702,.272,.0455
    wm=om*h*h;wb=ob*h*h;fb=ob/om;temp=2.726/2.7
    zeq=2.50e4*wm/temp**4;keq=.0746*wm/temp**2
    drag=1291*wm**.251/(1+.659*wm**.828)*(1+.313*wm**-.419*(1+.607*wm**.674)*wb**(.238*wm**.223))
    rd=31500*wb/temp**4/(1+drag);re=31500*wb/temp**4/zeq
    sound=2/(3*keq)*np.sqrt(6/re)*np.log((np.sqrt(1+rd)+np.sqrt(rd+re))/(1+np.sqrt(re)))
    silk=1.6*wb**.52*wm**.73*(1+(10.4*wm)**-.95)
    alpha=((46.9*wm)**.670*(1+(32.1*wm)**-.532))**-fb*((12*wm)**.424*(1+(45*wm)**-.582))**(-fb**3)
    beta=1/(1+.944/(1+(458*wm)**-.708)*((1-fb)**((.395*wm)**-.0266)-1))
    ratio=zeq/(1+drag);root=np.sqrt(1+ratio)
    ab=2.07*keq*sound*(1+rd)**-.75*ratio*(-6*root+(2+3*ratio)*np.log((root+1)/(root-1)))
    bb=.5+fb+(3-2*fb)*np.sqrt((17.2*wm)**2+1)
    x=k*sound;q=k/(13.41*keq);switch=1/(1+(x/5.4)**4)
    def kernel(al,be):
        top=np.log(np.e+1.8*be*q)
        return top/(top+(14.2/al+386/(1+69.9*q**1.08))*q*q)
    cold=switch*kernel(1,beta)+(1-switch)*kernel(alpha,beta)
    sx=x/(1+(8.41*wm**.435/x)**3)**(1/3)
    bary=np.sinc(sx/np.pi)*(kernel(1,1)/(1+(x/5.2)**2)+ab*np.exp(-(k/silk)**1.4)/(1+(bb/x)**3))
    return (1-fb)*cold+fb*bary
def power(k):
    log=stored_music();tilt=.961
    ka=np.exp(np.linspace(-13,11,50001));radius=8/.702
    win=3*spherical_jn(1,ka*radius)/(ka*radius)
    variance=simpson(ka**(3+tilt)*transfer(ka)**2*win**2,x=np.log(ka))/(2*np.pi**2)
    norm=.807**2*log["dplus"]**2/variance
    return norm*k**tilt*transfer(k)**2
def stored_music():
    import re
    log=(HERE/"ic_agora_m12i.conf_log.txt").read_text()
    return {s:float(re.search(r"cosmology/"+s+r"\s*=\s*([\d.eE+-]+)",log)[1]) for s in ("dplus","pnorm","vfact")}

