from census import Remote,uri
from local_io import *
import h5py
def sample_ids(ids):
    bits=ids.astype("u8")
    bits=(bits^(bits>>np.uint64(16)))*np.uint64(0x7feb352d)
    bits&=np.uint64(0xffffffff)
    bits=(bits^(bits>>np.uint64(15)))*np.uint64(0x846ca68b)
    bits&=np.uint64(0xffffffff)
    return ((bits^(bits>>np.uint64(16)))&127)==0
def run():
    ledger=[]
    for snap in (0,1,20,544):
        with Remote(uri(snap,0),32768) as remote,h5py.File(remote) as file:
            hdr=file["Header"].attrs;grp=file["PartType1"]
            count=int(hdr["NumPart_Total"][1])
            ledger.append(dict(snap=snap,scale=float(hdr["Time"]),dark=count,outer=int(hdr["NumPart_Total"][2]),mass_code=float(grp["Masses"][0]),
                examples=grp["ParticleIDs"][:3].tolist(),count_compatible=count==70514272,url=remote.url,identity=remote.id))
    assert [x["count_compatible"] for x in ledger]==[False,True,True,True]
    record("lineage-headers.json",ledger)
    for piece in range(4):
        name=f"early-001-{piece}"
        if (HERE/(name+".json")).exists():
            assert sha(HERE/(name+".npz"))==stored(name+".json")["sha256"];continue
        with Remote(uri(1,piece),65536) as remote,h5py.File(remote) as file:
            grp=file["PartType1"];hdr=file["Header"].attrs
            assert abs(hdr["Time"]-.05)<1e-8 and hdr["NumPart_Total"][1]==70514272
            result={};selected=[]
            length=len(grp["ParticleIDs"]);width=grp["ParticleIDs"].chunks[0]
            bounds=np.linspace(0,length//width,17,dtype=int)
            rng=np.random.default_rng(544001+piece)
            slices=[int(rng.integers(lo,hi))*width for lo,hi in zip(bounds[:-1],bounds[1:])]
            for key in ("ParticleIDs","Coordinates","Velocities"):
                ds=grp[key];kept=[];dig=hashlib.sha256()
                assert ds.chunks[0]==width
                for idx,left in enumerate(slices):
                    remote.spans.clear()
                    for column in range(1 if ds.ndim==1 else 3):
                        address=(left,) if ds.ndim==1 else (left,column)
                        info=ds.id.get_chunk_info_by_coord(address)
                        remote.spans.append((info.byte_offset,remote.range(info.byte_offset,info.size)))
                    values=ds[left:left+width];dig.update(values.tobytes())
                    if key=="ParticleIDs":
                        assert min(values)>=70514272 and max(values)<141028544
                        selected.append(np.arange(len(values))%8==0)
                    kept.append(values[selected[idx]])
                result[key]=np.concatenate(kept);result[key+"_sha"]=dig.hexdigest();remote.spans.clear()
            packet(name+".npz",ids=result["ParticleIDs"],pos=result["Coordinates"],vel=result["Velocities"])
            record(name+".json",dict(sha256=sha(HERE/(name+".npz")),scale=float(hdr["Time"]),all_rows=len(ds),url=remote.url,identity=remote.id,
                sample_window_hashes={k:result[k+"_sha"] for k in ("ParticleIDs","Coordinates","Velocities")},
                window_starts=slices,window_length=int(width),stride=8,bytes_received=remote.transferred))
            print(name,len(result["ParticleIDs"]),flush=True)
if __name__=="__main__":run()
