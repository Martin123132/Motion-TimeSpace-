from env_tide_io import *
from force_functional import Force,draw
from environment_multipoles import angular
from environment_background import setup,forcing,get_count

def run():
    lab,Evolution,_,_=setup();obj=lab.obj;bg=obj.bg
    probe=Force();tide=[]
    for snap in range(586,591):
        with np.load(HERE/f"harmonic-{snap}.npz") as src:
            tide.append(src["coeff"][0,0,:,::2]@angular(bg.mu,np.arange(0,69,2),0).T/bg.vel**2)
    weight=obj.wave.weights
    for factor in (2,4):
        for name in ("line","anchor"):
            ages,ext=forcing(name);counts=get_count(factor)
            for arm in ("reset","coupled"):
                tag=f"tangent-{name}-{factor}-{arm}"
                if (HERE/(tag+".json")).exists():continue
                with np.load(HERE/f"base-{name}-{factor}-{arm}.npz") as bank:states=bank["states"]
                delta=np.zeros_like(states[0]);cursor=0;worst=0.;max_iter=0
                sky_old=obj.sky(states[0]);moment_old=obj.moment(states[0])
                for seg,count in enumerate(counts):
                    dt=np.diff(ages)[seg]/(count*obj.unit_myr)
                    solver=Evolution(obj,dt,states[0])
                    for tick in range(count):
                        if tick%16==0:guard()
                        frac=(tick+.5)/count;cursor+=1
                        sky_new=obj.sky(states[cursor]);moment_new=abs(sky_new)**2@weight
                        u_mid=(sky_old+sky_new)/2
                        potential=ext[seg]+frac*(ext[seg+1]-ext[seg])+obj.phi((moment_old+moment_new)/2)-solver.pref
                        drive=tide[seg]+frac*(tide[seg+1]-tide[seg]);source=drive*u_mid
                        old_sky=obj.sky(delta);old_prod=(sky_old.conj()*old_sky).real
                        mid=delta;trial_sky=old_sky
                        for it in range(20):
                            change=old_prod+(sky_new.conj()*(2*trial_sky-old_sky)).real
                            feedback=obj.phi(change@weight)
                            rhs=potential*trial_sky+source+feedback*u_mid
                            update=solver.factor.solve(delta-.5j*dt*((rhs@weight)*bg.sqrt[:,None]).ravel())
                            err=np.linalg.norm(update-mid)
                            mid=update
                            if err<2e-13*max(np.linalg.norm(update),1e-9):break
                            trial_sky=obj.sky(update)
                        else:raise ArithmeticError("tangent corrector")
                        max_iter=max(max_iter,it+1)
                        delta=2*mid-delta
                        worst=max(worst,abs(np.vdot(states[cursor],delta).real)/obj.number)
                        sky_old,moment_old=sky_new,moment_new
                assert worst<2e-12
                changes=draw(probe,states[-1],delta)
                packet(tag+".npz",delta=delta)
                record(tag+".json",dict(change=changes,norm_tangent=worst,norm=float(np.linalg.norm(delta)),iterations=max_iter))
                print(tag,changes["absolute"],flush=True)
if __name__=="__main__":run()
