from env_tide_io import *
from statistics import NormalDist

def source(folder,digest,name):
    loc=ROOT/folder
    assert sha(loc/"seal.json")==digest
    path=loc/name
    assert sha(path)==json.loads((loc/"seal.json").read_bytes())[name]
    return path

def run():
    join=source("mts-pal5-joined-flow-586-600-20261122","86d9b1296c253b14a04e475339a9cbf71f84fed201749a234af4892b715576b7","verdict-4-2.json")
    singles=source("mts-pal5-source-tides-20261122","f8c1f197a9fe0fbe68dcf2b7d03499c1471223e73ed74d5394b6ba8bc20fca3a","release-time-brackets.csv")
    shared=source("mts-pal5-live-wave-coupling-20261122","e3179448aeee4c8d65d82377cab0f358820d43eb08c00c6935a2045c92cc2314","shared-release-dates.csv")
    astro=source("mts-pal5-astrometric-separation-20261122","2a666847fdec6691453833d9d0ce3496d479639cbce0c2884ad2352b074c2361","any-classifier-bound.csv")
    compare=source("mts-pal5-finite-wave-stripping-20261122","4db5e73d0a80bbc234e7d1036b11a99d2965805c6eb42d04f91f4171260aa5e8","stream-identifiability.csv")
    dates=json.loads(join.read_bytes());duration=dates["early_Myr"]+dates["late_Myr"]
    assert not dates["failures"] and abs(duration-dates["duration_Myr"])<1e-9
    for t,key in [(1940,"percent_of_tail_drift"),(5000,"percent_of_disruption_model")]:
        assert abs(100*duration/t-dates[key])<1e-9
    assert len(read(compare))==6
    sd=NormalDist();rec=[]
    for grid in ("4-1","4-2"):
        for arm,label in (("reset","reset"),("coupled","inherited")):
            one=[r for r in read(singles) if (r["grid"],r["arm"])==(grid,arm)]
            joint=[float(r["max_remaining_fraction"]) for r in read(shared) if
                (r["grid"],r["preparation"],r["tails"])==(grid,arm,"inner+outer")]
            assert len(one)==36 and len(joint)==6
            bracket=sum(r["bracketed"]=="True" for r in one)
            rec.append(dict(grid=grid,preparation=label,bracketed=bracket,tested=len(one),common_shift_min_residual=min(joint),common_shift_max_residual=max(joint)))
    table("stream-release-recheck.csv",rec)
    row=next(r for r in read(astro) if (r["grid"],r["stars"],r["mode"])==("4-2","17","calibrated"))
    cross=min(float(row["distance_reset_coupled"]),float(row["distance_coupled_reset"]))
    assert abs(100*sd.cdf(cross/2)-float(row["any_rule_worst_case_upper_percent"]))<1e-8
    precis=[]
    for state,distance in (("reset",float(row["distance_reset_reset"])),("inherited",float(row["distance_coupled_coupled"])),("unknown: closest opposite pair",cross)):
        precis.append(dict(state=state,whitened_distance=distance,ideal_pair_accuracy=sd.cdf(distance/2),
            necessary_uniform_precision_gain_for_80pct=2*sd.inv_cdf(.8)/distance))
    table("stream-precision-leverage.csv",precis)
    print(rec,precis)
if __name__=="__main__":run()
