from env_tide_io import *
from force_functional import Force,draw
from environment_multipoles import angular
from environment_background import forcing

def run():
    reference=read(pin(PREV,"necessary-penetration.csv"))
    ages,_=forcing("line")
    snapshots=range(586,591);probe=Force(26,96);nominal=Force()
    direct=[];at_probe=[]
    for item in json.loads((HERE/"sources.json").read_bytes()):
        assert sha(HERE/f"halo_{item['snapshot']}.hdf5")==item["sha256"]
    with np.load(HERE/"drivers.npz") as driver:
        for snap in snapshots:
            pos=driver[f"pos_{snap}"];mass=driver[f"mass_{snap}"];rv=driver[f"rvir_{snap}"]
            dist=np.linalg.norm(pos,axis=1);rstar=probe.rstar
            assert np.min(dist-rv)>rstar
            limit=2*np.sum(mass*(rstar/(dist-rstar))**3)
            az=np.linspace(0,2*np.pi,1024,endpoint=False)
            loc=np.stack((11.9*np.cos(az),11.9*np.sin(az),np.full_like(az,7.3)),axis=1)
            diff=pos[None,:,:]-loc[:,None,:]
            acc=((diff/np.linalg.norm(diff,axis=2)[:,:,None]**3-pos[None,:,:]/dist[None,:,None]**3)*mass[None,:,None]).sum(axis=1)
            proxy=-rstar*np.sum(acc*loc,axis=1)
            assert np.max(abs(proxy))<limit
            direct.append(dict(snap=snap,bound_Msun=limit,sampled_min_Msun=np.min(proxy),sampled_max_Msun=np.max(proxy)))
            with np.load(HERE/f"harmonic-{snap}.npz") as bank:
                idx=np.argmin(abs(bank["radii"]-probe.rstar))
                at_probe.append(bank["coeff"][:,:,idx,:])
    table("direct-external-force.csv",direct)
    knots=[]
    for idx in (1,2,3):
        frac=(ages[idx]-ages[0])/(ages[-1]-ages[0])
        chord=(1-frac)*at_probe[0]+frac*at_probe[4]
        knots.append(dict(snap=586+idx,angular_rms_change_from_chord=np.linalg.norm(at_probe[idx]-chord),
            fractional_change=np.linalg.norm(at_probe[idx]-chord)/np.linalg.norm(at_probe[idx])))
    table("source-history-resolution.csv",knots)
    rows=[]
    for name in ("line","anchor"):
        for arm in ("reset","coupled"):
            arrays=[]
            for factor in (2,4):
                tag=f"{name}-{factor}-{arm}"
                ax=json.loads((HERE/f"axial-{tag}.json").read_bytes())
                tangent=json.loads((HERE/f"tangent-{tag}.json").read_bytes())
                bounds=read(HERE/f"bounds-{tag}.csv")
                assert len(bounds)==69 and (bounds[0]["mode"],bounds[0]["parity"])==("0","0")
                with np.load(HERE/f"base-{tag}.npz") as src:
                    assert src["endpoint_error"]<1e-11
                    zero=src["states"][-1]
                with np.load(HERE/f"axial-{tag}.npz") as src, np.load(HERE/f"tangent-{tag}.npz") as tan:
                    plus,minus,delta=src["plus"],src["minus"],tan["delta"]
                    relative_tan_error=np.linalg.norm((plus-minus)/2-delta)/np.linalg.norm(delta)
                    fine=draw(probe,(plus+zero)/2,plus-zero)
                assert ax["drift"]<1e-9 and tangent["norm_tangent"]<2e-12
                assert relative_tan_error<2e-5,relative_tan_error
                assert abs(ax["zero"]/ax["archive"]-1)<2e-10
                for key in ("absolute","mass16"):
                    q=ax["changes"][0][key];qneg=ax["changes"][1][key]
                    assert abs(fine[key]/q-1)<2e-7
                    assert abs((q-qneg)/2/tangent["change"][key]-1)<2e-5
                if factor==4:
                    for bound in bounds:
                        mode,p=int(bound["mode"]),int(bound["parity"])
                        g=probe.dual(zero,mode,p);g0=nominal.dual(zero,mode,p)
                        for key in ("absolute","relative"):
                            assert np.linalg.norm(g[key]-g0[key])<max(1.,np.linalg.norm(g[key]))*2e-6
                residual=sum(float(row["relative"]) for row in bounds[1:])
                abs_residual=sum(float(row["absolute"]) for row in bounds[1:])
                total=abs(tangent["change"]["relative"])+residual+direct[-1]["bound_Msun"]
                arrays.append(np.array([ax["changes"][0]["absolute"],ax["changes"][0]["mass16"],tangent["change"]["relative"],residual,abs_residual]))
                for fg in ("Pouliasis_I","Pouliasis_II"):
                    need=next(float(row["needed_Msun"]) for row in reference if (row["arm"],row["source"],row["order"],row["foreground"])==(arm,name,"20",fg))
                    rows.append(dict(source=name,arm=arm,steps=ax["steps"],foreground=fg,axial_Msun=ax["changes"][0]["absolute"],
                        mass16_Msun=ax["changes"][0]["mass16"],tangent_Msun=tangent["change"]["relative"],omitted_relative_bound_Msun=residual,
                        omitted_absolute_bound_Msun=abs_residual,direct_bound_Msun=direct[-1]["bound_Msun"],required_Msun=need,
                        total_first_order_and_direct_max_fraction=total/need,central_relative_state_error=relative_tan_error))
            assert np.max(abs(arrays[0]/arrays[1]-1))<.005
    table("environmental-verdict.csv",rows)
    print("fraction",max(row["total_first_order_and_direct_max_fraction"] for row in rows),"direct",direct[-1],"chords",knots)
if __name__=="__main__":run()
