from env_tide_io import *
from force_functional import Force, draw
from environment_multipoles import angular
from environment_background import setup, forcing, get_count

def run():
    lab, Evolution, advance, _ = setup()
    obj = lab.obj
    probe = Force()
    tide = []
    for snap in range(586,591):
        with np.load(HERE/f"harmonic-{snap}.npz") as bank:
            assert np.max(abs(bank["radii"] - obj.bg.rad*obj.bg.length)) < 1e-9
            tide.append(bank["coeff"][0,0,:,::2] @ angular(obj.bg.mu,np.arange(0,69,2),0).T / obj.bg.vel**2)
    reference = read(pin(LAT,"formation-endpoints.csv"))
    for factor in (2,4):
        for name in ("line","anchor"):
            ages, ext = forcing(name)
            counts = get_count(factor)
            for arm in ("reset","coupled"):
                tag=f"axial-{name}-{factor}-{arm}"
                with np.load(HERE/f"base-{name}-{factor}-{arm}.npz") as src:
                    initial = src["states"][0]; base = src["states"][-1]
                prev = next(float(row["radial_mass_equivalent"]) for row in reference if
                    (row["arm"],row["source"],int(row["steps"])) == (arm,name,sum(counts)))
                readback=draw(probe,base,base)["absolute"]/2
                assert abs(readback/prev-1)<2e-7,(prev,readback)
                if (HERE/(tag+".json")).exists():continue
                states = [initial.copy(),initial.copy()]
                moments = [obj.moment(state) for state in states]
                drift=0.
                for seg,count in enumerate(counts):
                    dt=np.diff(ages)[seg]/(count*obj.unit_myr)
                    solver=Evolution(obj,dt,initial)
                    for tick in range(count):
                        if tick%16==0:guard()
                        frac=(tick+.5)/count
                        ordinary=ext[seg]+frac*(ext[seg+1]-ext[seg])
                        env=tide[seg]+frac*(tide[seg+1]-tide[seg])
                        for side,sign in enumerate((1,-1)):
                            states[side],moments[side],_,_=advance(obj,solver,states[side],moments[side],ordinary+sign*env,dt)
                            drift=max(drift,abs(np.vdot(states[side],states[side]).real/obj.number-1))
                assert drift<1e-9
                changes=[draw(probe,(base+state)/2,state-base) for state in states]
                packet(tag+".npz",plus=states[0],minus=states[1])
                record(tag+".json",dict(changes=changes,drift=drift,zero=readback,archive=prev,
                    dayspan_myr=ages[-1]-ages[0],steps=int(sum(counts))))
                print(tag,changes[0],flush=True)
if __name__=="__main__":run()
