from env_tide_io import *
from scipy.special import roots_legendre,lpmv,gammaln
from numpy.polynomial.legendre import legvander
G=4.30091727003628e-6
def angular(mu,ell,mode):
    norm=np.sqrt(2*ell+1)*np.exp(.5*(gammaln(ell-mode+1)-gammaln(ell+mode+1)))
    return lpmv(mode,ell,np.asarray(mu)[...,None])*norm
def piece(radii,pos,mass,rvir,scale,order,maxell):
    ell=np.arange(maxell+1);dist=np.linalg.norm(pos,axis=1)
    out=np.zeros((len(radii),len(mass),len(ell)))
    nodes,w=roots_legendre(order)
    for j,(d,gm,rv,rs) in enumerate(zip(dist,G*mass,rvir,scale)):
        outer=np.maximum(radii,d);x=np.minimum(radii,d)/outer
        coeff=-gm/outer[:,None]*x[:,None]**ell
        coeff[:,0]+=gm/d;coeff[:,1]+=gm*radii/d**2
        coeff[radii<d,:2]=0.
        idx=np.flatnonzero(abs(d-radii)<rv)
        if len(idx):
            rr=radii[idx,None];lo=abs(d-rr);hi=np.minimum(d+rr,rv)
            length=(hi-lo)/2;s=lo+length*(1+nodes)
            mu=np.clip((d*d+rr*rr-s*s)/(2*d*rr),-1,1)
            normal=gm/(np.log1p(rv/rs)-rv/(rs+rv))
            shift=gm-normal*(np.log1p(s/rs)-s/(rs+rv))
            corr=np.einsum("ij,ijk->ik",w*length*shift/(2*d*rr),legvander(mu,maxell))
            coeff[idx]+=corr*(2*ell+1)
        out[:,j]=coeff
    return out
def rotate(raw,pos,maxell):
    ell=np.arange(maxell+1);mu=pos[:,2]/np.linalg.norm(pos,axis=1);az=np.arctan2(pos[:,1],pos[:,0])
    cube=np.zeros((maxell+1,2,len(raw),maxell+1))
    for mode in range(maxell+1):
        e=ell[mode:];fac=angular(mu,e,mode)/(2*e+1)
        for side,phase in enumerate((np.cos(mode*az),np.sin(mode*az))):
            if side and not mode:continue
            cube[mode,side,:,mode:]=np.einsum("rjl,jl->rl",raw[:,:,mode:],fac*(phase[:,None]*(np.sqrt(2) if mode else 1)))
    return cube
def analytic(pts,pos,mass,rv,rs):
    dist=np.linalg.norm(pos,axis=1);dd=np.linalg.norm(pts[:,None,:]-pos[None,:,:],axis=-1);gm=G*mass
    norm=gm/(np.log1p(rv/rs)-rv/(rs+rv))
    p=np.where(dd>=rv,-gm/dd,-norm*(np.log1p(dd/rs)/dd-1/(rs+rv)))
    return (p+gm/dist+((pts@pos.T)/dist**3)*gm).sum(axis=-1)
def run():
    with np.load(pin(GAL,"launch.npz")) as z:edges,knots=z["edges"],z["knots"]
    allr=np.r_[0.,(edges[:-1,None]+np.diff(edges)[:,None]*knots[1:]).ravel()]
    rad=allr[1:-1];rec=[]
    with np.load(HERE/"drivers.npz") as bank:
        for snap in range(586,591):
            guard();pos,mass,rv,rs=[bank[f"{k}_{snap}"] for k in ("pos","mass","rvir","scale")]
            raw=piece(rad,pos,mass,rv,rs,72,68);cube=rotate(raw,pos,68)
            with np.errstate(under="ignore"):packet(f"harmonic-{snap}.npz",coeff=cube,radii=rad)
            dist=np.linalg.norm(pos,axis=1)
            hess=np.sum((np.eye(3)-3*pos[:,:,None]*pos[:,None,:]/dist[:,None,None]**2)*(G*mass/dist**3)[:,None,None],axis=0)
            assert abs(np.trace(hess))<1e-12
            rng=np.random.default_rng(586590);dirs=rng.normal(size=(128,3));dirs/=np.linalg.norm(dirs,axis=1)[:,None]
            mu=dirs[:,2];az=np.arctan2(dirs[:,1],dirs[:,0])
            for r in (5.,13.96,16.5,50.,100.,200.,300.):
                idx=np.argmin(abs(rad-r));radius=rad[idx];vals=analytic(radius*dirs,pos,mass,rv,rs)
                pred=np.zeros(len(mu));quad=.5*radius**2*np.einsum("ij,jk,ik->i",dirs,hess,dirs)
                for mode in range(69):
                    ell=np.arange(mode,69)
                    mat=angular(mu,ell,mode)
                    for side,basis in enumerate((np.cos(mode*az),np.sin(mode*az))):
                        pred+=(mat@cube[mode,side,idx,mode:])*basis*(np.sqrt(2) if mode else 1)
                rms=np.sqrt(np.mean(vals**2))
                rec.append(dict(snap=snap,radius=radius,min_external_surface=min(dist-rv),
                    rms_kms2=rms,maximum_absolute_kms2=max(abs(vals)),reconstructed_rms_fraction=np.sqrt(np.mean((pred-vals)**2))/rms,
                    quadrupole_rms_fraction=np.sqrt(np.mean((quad-vals)**2))/rms,
                    hxx=hess[0,0],hxy=hess[0,1],hxz=hess[0,2],hyy=hess[1,1],hyz=hess[1,2],hzz=hess[2,2]))
    table("direct-field-check.csv",rec)
if __name__=="__main__":run()

