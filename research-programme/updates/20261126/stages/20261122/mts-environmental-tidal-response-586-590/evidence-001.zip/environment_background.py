from env_tide_io import *
for file in ("sources.py","propagate.py","direct_evolution.py"):pin(FORM,file)
sys.path.insert(0,str(FORM))
from sources import parent_setup
from scipy.sparse.linalg import norm as sparse_norm
import inspect
def setup():
    lab,Ev,advance,oldguard,_=parent_setup()
    obj=lab.obj;bg=obj.bg
    _,ordinary,bare,_,_=inspect.getmodule(obj.phi).environment("anchorA")
    assert sparse_norm(obj.bare-bare)<1e-9
    assert sparse_norm(obj.bare-(bg.mesh.kinetic(bg.orders,True)+obj.wave.mult(ordinary)))<1e-8
    return lab,Ev,advance,ordinary
def forcing(name):
    with np.load(pin(FORM,"interventions.npz")) as data:
        ages=data["ages"];ext=data["line"]+(data["anchor"] if name=="anchor" else 0.)
    assert name in ("line","anchor")
    return ages,ext
def get_count(factor):
    return np.array(json.loads(pin(FORM,f"run-x{factor}.json").read_bytes())["interval_steps"])
def run():
    lab,Ev,advance,_=setup();obj=lab.obj
    for name in ("line","anchor"):
        ages,ext=forcing(name)
        for factor in (2,4):
            counts=get_count(factor)
            with np.load(pin(FORM,f"final-states-x{factor}.npz")) as end:ref={key:end[key] for key in end.files}
            for arm in ("reset","coupled"):
                tag=f"base-{name}-{factor}-{arm}.npz";initial=lab.run.reference[586] if arm=="reset" else lab.raw[586]
                if (HERE/tag).exists():
                    with np.load(HERE/tag) as bank:
                        assert np.array_equal(bank["states"][0],initial)
                        assert np.linalg.norm(bank["states"][-1]-ref[arm+"_"+name])<1e-11
                    continue
                state=initial.copy();mom=obj.moment(state);states=[state.copy()]
                for seg,count in enumerate(counts):
                    dt=np.diff(ages)[seg]/(count*obj.unit_myr);solver=Ev(obj,dt,initial)
                    diff=ext[seg+1]-ext[seg]
                    for tick in range(count):
                        if not tick%16:guard()
                        external=ext[seg]+(tick+.5)/count*diff
                        state,mom,_,_=advance(obj,solver,state,mom,external,dt);states.append(state.copy())
                error=np.linalg.norm(state-ref[arm+"_"+name])/np.sqrt(obj.number)
                assert error<1e-11
                packet(tag,states=states,endpoint_error=error,counts=counts);print(tag,error,flush=True)
if __name__=="__main__":run()

