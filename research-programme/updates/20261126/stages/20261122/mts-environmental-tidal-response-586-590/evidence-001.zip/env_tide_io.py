import os,sys,json,csv,io,hashlib
from pathlib import Path
for key in ("OMP_NUM_THREADS","OPENBLAS_NUM_THREADS","MKL_NUM_THREADS","BLIS_NUM_THREADS","NUMEXPR_NUM_THREADS"):os.environ[key]="1"
import numpy as np
HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
BASE=ROOT/"mts-fire-joint-baryon-history-20261120"
TIDE=ROOT/"mts-host-local-tidal-basin-544-20261122"
PREV=ROOT/"mts-host-tidal-current-sweep-20261122"
FORM=ROOT/"mts-formation-cold-source-586-590-20261122"
LAT=ROOT/"mts-high-latitude-preparation-null-590-20261122"
GAL=ROOT/"mts-preparation-vertical-gravity-590-20261122"
PINS={BASE:"19c78eaa158a766bd409c0a64504788b1346542eccee37c004083a918c480d67",TIDE:"560bb52df749765f7d3dceacb663845b508380ec00b75b0389914a189f285e40",PREV:"fa2b6b618713a95689b5ad22ad1ec31767e56ac1d7019d992cfeb2a49b200d62",FORM:"bf3223a9ddf5b28656b29c6413679f4bc6d45ea687d1b7075871521dc6bd802a",LAT:"06e46c345f46f6e927fb493ea4dcfa95acd67f1e56885849189b42f6f35f8c71",GAL:"37a872fe0e0c207030ca5c4825940b22be066191dcfd3097d28f3169b104aef7"}
def sha(path):
    with path.open("rb") as stream:return hashlib.file_digest(stream,"sha256").hexdigest()
def guard():
    assert __debug__ and not any((p/"STOP-REQUESTED").exists() for p in (HERE,ROOT,*PINS))
def pin(folder,name):
    guard();index=folder/"seal.json";assert sha(index)==PINS[folder]
    doc=json.loads(index.read_bytes());path=folder/name;assert sha(path)==doc.get("files",doc)[name]
    return path
def keep(name,payload):
    guard();file=HERE/name
    if file.exists():assert file.read_bytes()==payload,name
    else:
        with file.open("xb") as out:out.write(payload)
def record(name,value):keep(name,(json.dumps(value,indent=2,sort_keys=True,allow_nan=False)+"\n").encode())
def packet(name,**values):
    buf=io.BytesIO();np.savez_compressed(buf,**values);keep(name,buf.getvalue())
def table(name,rows):
    buf=io.StringIO();wr=csv.DictWriter(buf,rows[0],lineterminator="\n");wr.writeheader();wr.writerows(rows);keep(name,buf.getvalue().encode())
def read(path):
    with path.open() as handle:return list(csv.DictReader(handle))
def coord(snap):
    lines=pin(BASE,f"{snap}_coords_DR.txt").read_text().splitlines()
    return np.fromstring(" ".join(x for x in lines if not x.startswith("#")),sep=" ")

