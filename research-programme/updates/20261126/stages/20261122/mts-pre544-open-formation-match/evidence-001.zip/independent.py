from capture import *
from scipy.linalg import eigh_tridiagonal
from binding import particles

def box(donor,potential,extent,spacing,wall):
    count=int(np.ceil(extent/spacing));step=extent/count
    pos=step*np.arange(1,count+(wall=="N"))
    kin=.5*(donor.kappa/step)**2
    diagonal=potential(pos)+2*kin
    off=np.full(len(pos)-1,-kin);weights=np.full(len(pos),step)
    if wall=="N":
        off[-1]*=np.sqrt(2);weights[-1]*=.5;diagonal[-1]-=2*kin*step/extent
    amplitude=np.sqrt(weights)*donor.field(pos)[0]
    energies,vectors=eigh_tridiagonal(diagonal,off,select="v",select_range=(float(np.min(potential(pos))-2*kin),0.),
        lapack_driver="stebz")
    principal=abs(vectors.T@amplitude)**2
    assert np.all(energies<0) and sum(principal)<np.vdot(amplitude,amplitude).real
    return dict(wall=wall,spacing_kpc=step,levels=len(energies),negative_mass_Msun=sum(principal),
                total_lumped_Msun=np.vdot(amplitude,amplitude).real,ground_mass_Msun=principal[0])
def run():
    _,_,_,target=grids();waves=[];controls=[];analytic=[]
    for branch in ("heavy","cold"):
        seed=Seed(branch,"anchorA","heavy")
        for filename in filenames(branch):
            with np.load(pin(SHEET,filename)) as bank:
                epoch=float(bank["a"]);radius,potential,_=read_basin(seed,bank)
                system=ActionSystem(seed,bank);field=system.source(epoch)
                for row in particles(system,field,epoch,radius/1000,lambda rr:potential(rr*1000)):
                    species=row["species"]
                    mass=sheet_measure(bank,species,radius,epoch,seed)["mass_Msun"]
                    density=seed.coeff[species]*C**2/(8*np.pi*G_NUMBER)
                    reconstructed=4*np.pi*density*system.target*row["actual_mass_over_target"]
                    assert abs(mass/reconstructed-1)<1e-8
                    controls.append(dict(file=filename,branch=branch,radius_kpc=radius,species=species,
                        negative_Msun=mass*row["particle_energy_negative"],total_Msun=mass,
                        negative_fraction=row["particle_energy_negative"]))
                if branch=="heavy":
                    donor=Donor(bank["r"],bank["psi"],epoch,seed,32,max_radius=radius+20)
                    for step in (2.,1.,.5):
                        for wall in ("D","N"):
                            result=box(donor,potential,radius,step,wall)
                            waves.append(dict(file=filename,**result,mass_over_target=result["negative_mass_Msun"]/target))
                    print(filename,round(waves[-2]["mass_over_target"],3),round(waves[-1]["mass_over_target"],3),flush=True)
    class Reference:
        kappa=1.;step=.01
        def field(self,radius):return np.sqrt(2)*np.sin(np.pi*radius),None
    sample=Reference()
    def square(rad):return -np.ones_like(rad)*12
    for step in (.01,.005):
        data=box(sample,square,1.,step,"D")
        assert data["levels"]==1 and abs(data["negative_mass_Msun"]-1)<1e-12
        analytic.append(dict(step=step,negative_mass=data["negative_mass_Msun"],levels=data["levels"]))
    rows("independent-basin-spectrum.csv",waves);rows("basin-particles.csv",controls);rows("spectral-controls.csv",analytic)
if __name__=="__main__":run()
