from basin import *

def check():
    seed=Seed("heavy","anchorA","heavy");edges,_,_,target=grids()
    data=[];bounds=[]
    for filename in filenames("heavy"):
        with np.load(pin(SHEET,filename)) as bank:
            epoch=float(bank["a"]);mesh=bank["r"];normal=64
            donor=Donor(mesh,bank["psi"],epoch,seed,normal)
            spectral=-donor.freq**2*donor.coef
            count=len(mesh)-1
            values=idst(np.pad(normal*count*spectral,(0,(normal-1)*count)),type=1)
            cut=int(450/donor.step*normal)+8
            second=CubicSpline(np.arange(cut+1)*mesh[1]/normal,np.r_[0j,values[:cut]])
            material=brentq(lambda rad:donor.mass(rad)-target,0,edges[-1],xtol=1e-11)
            for point,radius in (("gd1",RTEST),("100",100.),("200",200.),("wall",edges[-1]),("mass_label",material)):
                nodes,weights=roots_legendre(18)
                pieces=np.linspace(0,radius,int(np.ceil(radius/donor.step))*2+1)
                half=np.diff(pieces)[:,None]/2
                rad=pieces[:-1,None]+half*(1+nodes)
                com=rad/donor.unit
                profile=donor.interp(com);prime=donor.interp(com,1)
                inner=-donor.hubble*(abs(profile)**2+2*com*np.real(profile.conj()*prime))
                dispersion=-donor.kappa/donor.unit**2*np.imag(profile.conj()*second(com))
                mass_rate=KMS_TO_KPC_PER_MYR*donor.pref**2*np.sum(half*weights*(inner+dispersion))
                exact=donor.readout(radius);flux=exact["outward_flux_Msun_Myr"]
                data.append(dict(file=filename,point=point,radius_kpc=radius,bulk_mass_rate_Msun_Myr=mass_rate,
                    outward_flux_Msun_Myr=flux,relative_continuity_error=abs((mass_rate+flux)/flux),
                    derived_constant_number_speed_kms=-mass_rate/(KMS_TO_KPC_PER_MYR*exact["mass_per_kpc"]),
                    spectral_boundary_speed_kms=exact["proper_flow_kms"]))
    rows("bulk-current.csv",data)
    for row in read(HOME/"basin-bound.csv"):
        safe=float(row["witness_over_target"])/(1+int(row["negative_ritz"])*float(row["orthogonality_error"]))
        bounds.append(dict(file=row["file"],support_kpc=row["support_kpc"],basis=row["trial_count"],quadrature=row["quadrature"],
                           gram_adjusted_lower_over_target=safe))
    rows("gram-adjusted-witness.csv",bounds)
    print("largest continuity error",max(row["relative_continuity_error"] for row in data))
if __name__=="__main__":check()
