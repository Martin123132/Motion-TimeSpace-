from inputs import *
import re

def col(data,name):
    return np.array([float(row[name]) for row in data])
def run():
    edges,knots,ground,target=grids()
    apertures=read(HOME/"apertures.csv");projection=read(HOME/"interface-refinement-x8.csv")
    currents=read(HOME/"bulk-current.csv")
    assert len(apertures)==len(currents)==25 and len(projection)==5
    assert all(row["passes_formation_readout"]=="True" for row in projection)
    assert max(col(currents,"relative_continuity_error"))<TOL
    donor_error=read(HOME/"transfer-refinement.csv")
    assert all(max(col(donor_error,key))<TOL for key in ("relative_mass_refinement","interpolation_amplitude_error","interpolation_derivative_error"))
    assert max(abs(col([row for row in apertures if row["point"]=="equal_number"],"mass_Msun")/target-1))<1e-10
    wall=[row for row in apertures if row["point"]=="galactic_wall"]
    assert len(wall)==5 and min(col(wall,"excess_Msun"))>16*target and max(col(wall,"outward_flux_Msun_Myr"))<0
    original=read(HOME/"interface-refinement.csv")
    assert any(row["passes_formation_readout"]=="False" for row in original if row["element_subdivisions"]=="4")
    tail=[row for row in read(HOME/"kinetic-tail.csv") if row["modes"]=="2048"]
    assert max(abs(col([r for r in tail if r["kind"]=="raw"],"kinetic_per_mode_over_predicted")-1))<.005
    assert max(col([r for r in tail if r["kind"]=="lifted"],"kinetic_per_mode_over_predicted"))<TOL
    with np.load(HOME/"open-transfer-x8.npz") as data:
        finer=data["edges_kpc"]
        np.testing.assert_allclose(edges,finer[::8],atol=1e-12,rtol=0)
        np.testing.assert_array_equal(knots,data["knots"])
        for filename in filenames("heavy"):
            amplitudes=data[filename[:-4]]
            assert amplitudes.shape==((len(finer)-1)*(len(knots)-1)+1,) and amplitudes[0]==amplitudes[-1]==0
            trace,derivative=data[filename[:-4]+"_outer_value_and_slope"]
            flux=2000*np.imag(trace.conj()*derivative)*KMS_TO_KPC_PER_MYR
            saved=next(float(r["outward_flux_Msun_Myr"]) for r in wall if r["file"]==filename)
            assert abs(flux/saved-1)<1e-10
    saddles=read(HOME/"physical-saddles.csv")
    assert len(saddles)==10 and all(row["metric_turns"]==row["gauss_turns"]=="1" for row in saddles)
    assert max(abs(col(saddles,"saddle_kpc")-col(saddles,"gauss_saddle_kpc"))/col(saddles,"cell_kpc"))<1
    bound=read(HOME/"gram-adjusted-witness.csv");spectrum=read(HOME/"independent-basin-spectrum.csv")
    assert len(bound)==len(spectrum)==30
    conservative=[];fine=[]
    for filename in filenames("heavy"):
        for cap in ("100.0","200.0"):
            series=col([r for r in bound if r["file"]==filename and r["support_kpc"]==cap and r["basis"]=="96"],"gram_adjusted_lower_over_target")
            assert series.size==2 and abs(series[0]/series[1]-1)<TOL
            conservative.append(min(series))
        series=[r for r in spectrum if r["file"]==filename]
        for wall_type in ("D","N"):
            est=col([r for r in series if r["wall"]==wall_type],"mass_over_target")
            assert est.size==3 and min(est)>max(conservative) and abs(est[-1]/est[-2]-1)<.005
            fine.append(est[-1])
    assert min(conservative)>1 and min(fine)>70
    prefix=read(HOME/"low-energy-cuts.csv")
    for filename in filenames("heavy"):
        rec=[r for r in prefix if r["file"]==filename]
        assert len(rec)==4 and rec[-1]["nearest_count"]==rec[-2]["nearest_count"]
        assert abs(float(rec[-1]["nearest_relative_miss"])-float(rec[-2]["nearest_relative_miss"]))<.0005
        assert float(rec[-1]["nearest_relative_miss"])>.005
    particles=read(HOME/"basin-particles.csv")
    assert len(particles)==20 and all(0<float(r["negative_Msun"])<float(r["total_Msun"]) for r in particles)
    for doc in ("RESULTS.md","METHOD.md","REPLAY.md"):
        for ref in re.findall(r"\]\(([^)]+)\)",(HOME/doc).read_text(encoding="utf8")):
            assert ref.startswith("https://") or (HOME/ref).is_file(),ref
    for file in HOME.glob("*.py"):compile(file.read_bytes(),str(file),"exec")
    assert not any(p.is_dir() for p in HOME.iterdir())
    record("validation.json",dict(donors=10,heavy=5,cold=5,current_checks=len(currents),
        transfer_max_current_error=max(col(projection,"max_aperture_flux_error")),
        true_mass_bulk_current_error=max(col(currents,"relative_continuity_error")),
        physical_saddles=len(saddles),bound_cases=len(bound),independent_spectra=len(spectrum),
        low_energy_refinements=len(prefix),prior_manifest_sha256={folder.name:code for folder,code in PINS.items()},
        limits="Conditional source; near-centre variation unresolved; numerical witness integrations not interval proofs."))
    files={f.name:digest(f) for f in sorted(HOME.iterdir()) if f.name!="seal.json"}
    if (HOME/"seal.json").exists():assert json.loads((HOME/"seal.json").read_bytes())==files
    elif sys.argv[1:]==["--seal"]:record("seal.json",files)
    print(len(files),"files verified;",digest(HOME/"seal.json") if (HOME/"seal.json").exists() else "not sealed")
if __name__=="__main__":run()
