import csv
import hashlib
import io
import json
import os
import sys
from pathlib import Path

for key in ("OPENBLAS_NUM_THREADS","MKL_NUM_THREADS","OMP_NUM_THREADS","NUMEXPR_NUM_THREADS","BLIS_NUM_THREADS"):
    os.environ[key]="1"
sys.dont_write_bytecode=True
import numpy as np
from scipy.fft import dst,idst
from scipy.interpolate import CubicSpline
from scipy.special import roots_legendre
from scipy.constants import G as G_SI, parsec
from scipy.optimize import brentq

HOME=Path(__file__).resolve().parent
ROOT=HOME.parent
SHEET=ROOT/"mts-collisionless-sheet-infall-20261120"
SEED=ROOT/"mts-primordial-patch-infall-20261120"
GAL=ROOT/"mts-preparation-vertical-gravity-590-20261122"
LAST=ROOT/"mts-high-latitude-preparation-null-590-20261122"
EARLY=ROOT/"mts-pre572-wave-preparation-20261120"
ANG=ROOT/"mts-formation-angular-population-20261120"
PINS={SHEET:"c4131a2bb4118b70dafb5cec48ced007e26a885fee58b881c6dfec2c9de940ee",
      SEED:"a9f7723564116720ba5bc03333239d8fc0f106a6c2f14ca052f94e822aee2467",
      GAL:"37a872fe0e0c207030ca5c4825940b22be066191dcfd3097d28f3169b104aef7",
      LAST:"06e46c345f46f6e927fb493ea4dcfa95acd67f1e56885849189b42f6f35f8c71",
      EARLY:"ce9ca0f03916af1fa3bfd449a61e779a74ce3427fae0a3a6bcdf65bc2b6c70ee",
      ANG:"24b330690e00078dc022feadd2524ca35e416a032f90df89b684c8aef07d3a35"}
def digest(path):
    with path.open("rb") as stream:return hashlib.file_digest(stream,"sha256").hexdigest()
def guard():
    assert not any((place/"STOP-REQUESTED").exists() for place in (*PINS,HOME,ROOT))
def pin(folder,name):
    guard()
    manifest=folder/"seal.json"
    assert digest(manifest)==PINS[folder]
    index=json.loads(manifest.read_bytes())
    path=folder/name
    assert digest(path)==index.get("files",index)[name],name
    return path
def save(name,payload):
    guard()
    path=HOME/name
    if path.exists():assert path.read_bytes()==payload,name
    else:
        with path.open("xb") as stream:stream.write(payload)
def rows(name,data):
    dest=io.StringIO();writer=csv.DictWriter(dest,data[0].keys(),lineterminator="\n")
    writer.writeheader();writer.writerows(data);save(name,dest.getvalue().encode())
def record(name,data):
    save(name,(json.dumps(data,sort_keys=True,indent=2,allow_nan=False)+"\n").encode())
def read(path):
    with path.open() as stream:return list(csv.DictReader(stream))
pin(SEED,"seeds.py")
sys.path.insert(0,str(SEED))
from seeds import Seed,C,END,TOL
G_MPC=4.30091727003628e-9
G_NUMBER=G_SI*1.98847e30/(1e6*parsec)/1e6
KMS_TO_KPC_PER_MYR=.001022712165045695
RTEST=np.hypot(11.9,7.3)
def grids():
    with np.load(pin(GAL,"launch.npz")) as bank:
        edges=bank["edges"];knots=bank["knots"];native_scale=float(bank["mscale"]/bank["length"])
        degrees=bank["degrees"]
    with np.load(pin(LAST,"native-map.npz")) as mapping:indices=mapping["indices"];root=mapping["sqrt"]
    with np.load(pin(EARLY,"ground-anchorA.npz")) as source:core=source["early"].reshape(len(root),-1)
    ground=np.pad(core/root[:,None],((1,1),(0,0)))[indices]*np.sqrt(native_scale)
    assert ground.shape==(len(edges)-1,len(knots),len(degrees))
    with np.load(pin(GAL,"launch.npz")) as bank:mass=np.vdot(core,core).real*float(bank["mscale"])
    return edges,knots,ground,mass
def filenames(branch):
    names=sorted(path.name for path in SHEET.glob("restart-"+branch+"-*0.925159-sine-action*.npz") if "epoch" not in path.name)
    assert len(names)==5
    return names

class Donor:
    def __init__(self,mesh,wave,epoch,seed,over,max_radius=500.):
        self.epoch=epoch;self.unit=1000*epoch
        self.hubble=seed.H(epoch)*C/1000
        self.kappa=C/seed.mass*1000
        self.rho=seed.coeff["wave"]*C**2/(8*np.pi*G_NUMBER)
        self.pref=np.sqrt(4*np.pi*self.rho/self.unit)
        n=len(mesh)-1
        self.step=mesh[1]*self.unit
        self.freq=np.arange(1,n)*np.pi/mesh[-1]
        self.coef=dst(mesh[1:-1]*(wave[1:-1]-1),type=1)/n
        internal=idst(np.pad(over*n*self.coef,(0,(over-1)*n)),type=1)
        count=min(len(internal),int(max_radius/self.step*over)+12)
        grid=np.arange(count+1)*mesh[1]/over
        self.interp=CubicSpline(grid,grid+np.r_[0j,internal[:count]])
    def field(self,radius):
        pos=radius/self.unit
        assert np.all((pos>=0)&(pos<=self.interp.x[-1]))
        profile=self.interp(pos);slope=self.interp(pos,1)/self.unit
        phase=self.hubble*radius**2/(2*self.kappa);rotation=self.pref*np.exp(1j*phase)
        return rotation*profile,rotation*(slope+1j*self.hubble*radius/self.kappa*profile)
    def exact(self,radius):
        phase=self.freq*radius/self.unit
        profile=radius/self.unit+np.sin(phase)@self.coef
        slope=(1+np.cos(phase)@(self.freq*self.coef))/self.unit
        rotation=self.pref*np.exp(.5j*self.hubble*radius**2/self.kappa)
        return rotation*profile,rotation*(slope+1j*self.hubble*radius/self.kappa*profile)
    def mass(self,radius,order=12):
        if radius==0:return 0.
        points,weights=roots_legendre(order)
        cells=np.linspace(0,radius,int(np.ceil(radius/self.step))+1)
        half=np.diff(cells)[:,None]/2
        locations=cells[:-1,None]+half*(1+points)
        return np.sum(half*weights*abs(self.field(locations)[0])**2)
    def readout(self,radius):
        amplitude,slope=self.exact(radius)
        linear=abs(amplitude)**2;current=self.kappa*(amplitude.conjugate()*slope).imag
        return dict(radius_kpc=radius,mass_Msun=self.mass(radius),mass_per_kpc=linear,
                    outward_flux_Msun_Myr=current*KMS_TO_KPC_PER_MYR,proper_flow_kms=current/linear,
                    hubble_kms=radius*self.hubble,shell_density_Msun_kpc3=linear/(4*np.pi*radius**2))
