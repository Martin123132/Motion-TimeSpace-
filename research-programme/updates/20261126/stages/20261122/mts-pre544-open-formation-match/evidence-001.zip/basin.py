from project import *
from scipy.linalg import eigh
for filename in ("source.py","sheet.py","variational.py","binding.py"):
    pin(SHEET,filename)
sys.path.insert(0,str(SHEET))
from variational import ActionSystem
from binding import metric_value,hubble

def read_basin(seed,bank):
    system=ActionSystem(seed,bank);epoch=float(bank["a"]);field=system.source(epoch)
    hub,acc=hubble(seed,epoch)
    proper=system.r*epoch
    metric=(C/epoch)**2*field.factor-acc
    maxima=np.flatnonzero((metric[:-1]>0)&(metric[1:]<=0))+1
    cross=np.zeros_like(proper)
    for species,enclosed in system.enclosed.items():
        cross[1:]+=.5*seed.coeff[species]*C**2*(enclosed[1:]-system.r[1:]**3/3)/proper[1:]**3
    cross-=acc
    roots=[]
    for ix in np.flatnonzero((cross[1:-1]>0)&(cross[2:]<=0))+1:
        roots.append(proper[ix]+(proper[ix+1]-proper[ix])*cross[ix]/(cross[ix]-cross[ix+1]))
    assert acc>0 and metric[-1]<0 and len(maxima)>0 and roots
    outer=proper[maxima[-1]]
    def potential(rad):
        val=rad/1000
        return (metric_value(field,system.r,val/epoch)-metric_value(field,system.r,outer/epoch))*C**2-.5*acc*(val**2-outer**2)
    return outer*1000,potential,dict(metric_turns=len(maxima),gauss_turns=len(roots),
        saddle_kpc=1000*outer,gauss_saddle_kpc=1000*roots[-1],cell_kpc=1000*epoch*system.h,
        relative_saddle_difference=abs(outer/roots[-1]-1),central_well_kms2=float(potential(0.)),cosmic_acceleration_kms2_per_Mpc2=acc)

def tag_ledger():
    _,_,_,target=grids()
    well=[];tagged=[]
    aperture={(row["file"],float(row["radius_kpc"])):float(row["mass_Msun"]) for row in read(HOME/"apertures.csv")}
    for filename in filenames("heavy"):
        name=filename[:-4]
        table=read(pin(SHEET,"refined-well-v2-"+name+".csv"))
        modes=read(pin(SHEET,"occupations-"+name+".csv"))
        for row in table:
            if row["count"]!="224":continue
            radius=float(row["radius_kpc"]);wall=row["wall"];mass=aperture[filename,radius]
            states=[v for v in modes if v["wall"]==wall and float(v["radius_kpc"])==radius and v["basis"]=="224"]
            pop=sum(abs(complex(float(v["amplitude_real"]),float(v["amplitude_imag"])))**2 for v in states)
            assert abs(pop-float(row["negative_projection"]))<1e-10
            well.append(dict(file=filename,radius_kpc=radius,wall=wall,total_mass_over_target=mass/target,
                recovered_projection_over_target=mass*pop/target,residual_witness_over_target=mass*float(row["nested_lower_fraction"])/target,
                change_in_mass_integral=mass/(target*float(row["actual_mass_over_target"]))-1))
    for mode in ("fine","matched","split"):
        data=read(pin(SHEET,"tag-wave-"+mode+".csv"))
        for row in data:
            if abs(float(row["a"])-END)>1e-8:continue
            tagged.append(dict(mode=mode,radius_kpc=float(row["kpc"]),initial_epoch=float(data[0]["a"]),
                returned_mass_over_target=float(row["tag_initial_mass_over_target"])*float(row["endpoint_return_fraction"]),
                final_inside_over_target=float(row["tag_initial_mass_over_target"])*float(row["endpoint_inside_fraction"]),
                initial_embedding_error=float(row["initial_embedding_error"])))
    rows("saved-binding.csv",well);rows("returned-tags.csv",tagged)

def survey():
    output=[]
    for branch in ("heavy","cold"):
        seed=Seed(branch,"anchorA","heavy")
        for filename in filenames(branch):
            with np.load(pin(SHEET,filename)) as bank:
                wall,pot,summary=read_basin(seed,bank)
                record=dict(file=filename,branch=branch,**summary)
                for species in ("cdm","baryon"):
                    record[species+"_mass_Msun"]=sheet_measure(bank,species,wall,float(bank["a"]),seed)["mass_Msun"]
                output.append(record)
    rows("physical-saddles.csv",output);tag_ledger()
    for record in output:
        print(record["branch"],round(record["saddle_kpc"],2),round(record["gauss_saddle_kpc"],2),record["metric_turns"])
if __name__=="__main__":survey()
