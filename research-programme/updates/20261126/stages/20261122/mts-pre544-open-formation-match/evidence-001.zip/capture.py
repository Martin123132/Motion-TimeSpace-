from basin import *

def trial(radius,cap,count):
    freq=np.arange(1,count+1)*np.pi/cap
    phase=radius[:,None]*freq
    shape=np.sin(phase);slope=np.cos(phase)*freq
    width=.3*cap
    coord=np.clip((radius-.7*cap)/width,0,1)
    env=1-coord**3*(10+coord*(-15+6*coord))
    deriv=-30*coord**2*(1-coord)**2/width
    second=-60*coord*(1-coord)*(1-2*coord)/width**2
    return (env[:,None]*shape,env[:,None]*slope+deriv[:,None]*shape,
            second[:,None]*shape+2*deriv[:,None]*slope-env[:,None]*shape*freq**2)

def witness(donor,potential,rmax,cap,count,order,total):
    edge=np.unique(np.r_[np.arange(0,cap,donor.step),np.linspace(0,cap,2*count+1),.7*cap,cap])
    nodes,weights=roots_legendre(order);half=np.diff(edge)[:,None]/2
    rad=(edge[:-1,None]+half*(1+nodes)).ravel();wt=(half*weights).ravel()
    amp=donor.field(rad)[0]
    values,der,second=trial(rad,cap,count);potential=potential(rad)
    kinetic=donor.kappa**2/2
    gram=values.T@(wt[:,None]*values)
    evals,vec=eigh(gram);keep=evals>evals.max()*1e-9
    normalize=vec[:,keep]/np.sqrt(evals[keep])
    states=values@normalize;grad=der@normalize
    hm=kinetic*(grad.T@(wt[:,None]*grad))+states.T@((wt*potential)[:,None]*states)
    ener,rotation=eigh(hm);negative=ener<-1
    rotation=rotation[:,negative];ener=ener[negative]
    states=states@rotation
    resid=-kinetic*(second@(normalize@rotation))+(potential[:,None]-ener)*states
    leakage=np.sqrt(wt@abs(resid)**2)/(-ener)
    amplitudes=(wt*amp)@states
    orthogonality=np.max(abs(states.T@(wt[:,None]*states)-np.eye(len(ener))))
    relation=np.max(abs(states.T@(wt[:,None]*resid)))/max(-ener)
    floor=np.maximum(abs(amplitudes)-np.sqrt(total)*leakage,0)
    assert orthogonality<2e-6 and relation<2e-6
    result=dict(support_kpc=cap,trial_count=count,quadrature=order,basin_kpc=rmax,total_mass_Msun=total,
                witness_Msun=floor@floor,contributing_functions=int(sum(floor>0)),negative_ritz=len(ener),
                orthogonality_error=orthogonality,relative_weak_strong_error=relation)
    return result

def run():
    seed=Seed("heavy","anchorA","heavy");_,_,_,target=grids()
    data=[]
    for filename in filenames("heavy"):
        with np.load(pin(SHEET,filename)) as bank:
            rmax,potential,_=read_basin(seed,bank)
            donor=Donor(bank["r"],bank["psi"],END,seed,32,max_radius=rmax+20)
            total=donor.mass(rmax)
            for cap in (100.,200.):
                for count,order in ((64,8),(96,12),(96,18)):
                    result=witness(donor,potential,rmax,cap,count,order,total)
                    data.append(dict(file=filename,**result,witness_over_target=result["witness_Msun"]/target))
        print(filename,[(row["support_kpc"],round(row["witness_over_target"],3),row["contributing_functions"]) for row in data[-6:]],flush=True)
    rows("basin-bound.csv",data)
if __name__=="__main__":run()
