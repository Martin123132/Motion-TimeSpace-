from project import *

def run(factors=(1,2,4),name_out="interface-refinement.csv"):
    edges,knots,ground,target=grids();wall=edges[-1]
    projector=Projector(edges,knots,2.,12)
    def polynomial(rad):
        frac=rad/wall
        return (frac+(.25-.13j)*frac**3), (1+3*(.25-.13j)*frac**2)/wall
    row,sites,_=projector.transfer(polynomial,2000.,ground)
    assert row["relative_l2_error"]<1e-12 and row["relative_derivative_l2_error"]<1e-10
    assert max(abs(s["relative_flux_error"]) for s in sites)<1e-9
    seed=Seed("heavy","anchorA","heavy")
    samples=[];bundle_states={"knots":knots}
    for name in filenames("heavy"):
        with np.load(pin(SHEET,name)) as bank:
            donor=Donor(bank["r"],bank["psi"],END,seed,64)
            for factor in factors:
                finer=np.r_[np.linspace(edges[:-1],edges[1:],factor,endpoint=False).T.ravel(),wall]
                mesh=Projector(finer,knots,donor.step,14)
                coords=(finer[:-1,None]+np.diff(finer)[:,None]*knots).ravel()
                basis,_,cell=projector.evaluate(coords)
                ground_ref=np.einsum("ij,ijk->ik",basis,ground[cell]).reshape(len(finer)-1,len(knots),-1)
                result,local,correction=mesh.transfer(donor.field,donor.kappa,ground_ref)
                if factor==8:
                    bundle_states["edges_kpc"]=finer
                    bundle_states[name[:-4]]=correction
                    bundle_states[name[:-4]+"_outer_value_and_slope"]=np.asarray(donor.exact(wall))
                max_flux=max(abs(rec["relative_flux_error"]) for rec in local)
                max_mass=max(abs(rec["relative_mass_error"]) for rec in local)
                samples.append(dict(file=name,element_subdivisions=factor,field_error=result["relative_l2_error"],
                    derivative_error=result["relative_derivative_l2_error"],max_aperture_flux_error=max_flux,
                    max_aperture_mass_error=max_mass,passes_formation_readout=bool(max([result["relative_l2_error"],
                        result["relative_derivative_l2_error"],max_mass,max_flux])<TOL)))
    rows(name_out,samples)
    if len(bundle_states)>1:
        dest=io.BytesIO();np.savez_compressed(dest,**bundle_states);save("open-transfer-x8.npz",dest.getvalue())
    bundle={k:float(v) for k,v in row.items()}
    bundle["max_polynomial_flux_error"]=max(abs(s["relative_flux_error"]) for s in sites)
    record("manufactured-interface.json",bundle)
    print("worst by level",[(fac,max(s["max_aperture_flux_error"] for s in samples if s["element_subdivisions"]==fac)) for fac in factors])
if __name__=="__main__":
    run()
    run((8,),"interface-refinement-x8.csv")
