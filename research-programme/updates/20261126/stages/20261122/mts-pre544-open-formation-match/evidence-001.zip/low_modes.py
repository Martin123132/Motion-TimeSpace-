from independent import *
def resolve(donor,pot,boundary,spacing,target):
    count=int(np.ceil(boundary/spacing));step=boundary/count
    rad=step*np.arange(1,count);weight=step;kin=.5*(donor.kappa/step)**2
    diag=pot(rad)+2*kin;off=np.full(len(rad)-1,-kin)
    amp=donor.field(rad)[0]*np.sqrt(weight)
    end=8
    while True:
        levels,vectors=eigh_tridiagonal(diag,off,select="i",select_range=(0,end-1),lapack_driver="stebz")
        coeff=vectors.T@amp
        totals=np.cumsum(abs(coeff)**2)
        if totals[-1]>=target or levels[-1]>=0:break
        end*=2
        assert end<=512
    neg=levels<0
    allowed=np.r_[0.,totals[neg]]
    closest=int(np.argmin(abs(allowed-target)))
    ground=coeff[0]*vectors[:,0]
    partition=rad<RTEST
    ground_mass=abs(coeff[0])**2
    inner_mass=lambda component:float(np.sum(abs(component[partition])**2))
    interference=2*np.vdot(ground[partition],(amp-ground)[partition]).real
    assert abs(inner_mass(amp)-inner_mass(ground)-inner_mass(amp-ground)-interference)<1e-10*target
    return dict(mesh_kpc=step,ground_mass_Msun=ground_mass,ground_fraction_of_target=ground_mass/target,
                ground_energy_kms2=levels[0],ground_to_first_gap_kms2=levels[1]-levels[0],
                nearest_count=closest,nearest_mass_Msun=allowed[closest],nearest_relative_miss=abs(allowed[closest]/target-1),
                ground_inner_cell_mass_Msun=inner_mass(ground),complement_inner_cell_mass_Msun=inner_mass(amp-ground),
                inner_cell_interference_Msun=interference,number_of_basis_states_checked=end)
def run():
    seed=Seed("heavy","anchorA","heavy");_,_,_,target=grids();results=[]
    bench={r["file"]:r for r in read(HOME/"independent-basin-spectrum.csv") if r["wall"]=="D" and float(r["spacing_kpc"])<=.5 and float(r["spacing_kpc"])>.49}
    assert len(bench)==5
    for filename in filenames("heavy"):
        with np.load(pin(SHEET,filename)) as bank:
            radius,pot,_=read_basin(seed,bank)
            donor=Donor(bank["r"],bank["psi"],END,seed,32,max_radius=radius+20)
            for step in (.5,.25,.125,.0625):
                row=resolve(donor,pot,radius,step,target)
                results.append(dict(file=filename,**row))
                if step==.5:assert abs(row["ground_mass_Msun"]/float(bench[filename]["ground_mass_Msun"])-1)<1e-9
        print(filename,[(r["nearest_count"],round(r["nearest_relative_miss"],5),round(r["ground_fraction_of_target"],5)) for r in results[-2:]],flush=True)
    rows("low-energy-cuts.csv",results)
if __name__=="__main__":run()
