from project import *
from scipy.optimize import brentq

def run():
    guard()
    edges,knots,ground,target=grids();wall=float(edges[-1])
    angle=next(row for row in read(pin(ANG,"angular-summary.csv")) if row["branch"]=="anchorA")
    assert "M_SUN=1.98847e30" in pin(ANG,"inputs_local.py").read_text()
    named={"gd1_radius":RTEST,"inner_aperture":100.,"outer_aperture":200.,"galactic_wall":wall}
    readouts=[];projections=[];sites=[];tails=[];dust=[];checks=[];native_data={}
    for branch in ("heavy","cold"):
        seed=Seed(branch,"anchorA","heavy")
        for filename in filenames(branch):
            guard()
            with np.load(pin(SHEET,filename)) as bank:
                epoch=float(bank["a"]);mesh=bank["r"]
                assert epoch==END
                if branch=="heavy":
                    wave=bank["psi"];donor=Donor(mesh,wave,epoch,seed,32)
                    assert abs(donor.kappa/float(angle["kappa_kpc_km_s"])-1)<TOL
                    assert abs(donor.rho/float(angle["density_Msun_Mpc3"])-1)<TOL
                    assert abs((4*np.pi*donor.rho*seed.radius**3/3)/target-1)<TOL
                    reference=Donor(mesh,wave,epoch,seed,16)
                    material=brentq(lambda rad:donor.mass(rad)-target,0,wall,xtol=1e-11)
                    for point,radius in {**named,"equal_number":material}.items():
                        result=donor.readout(radius);readouts.append(dict(file=filename,point=point,**result,
                            excess_Msun=result["mass_Msun"]-4*np.pi/3*donor.rho*(radius/donor.unit)**3,
                            newton_force_mass_equiv=result["mass_Msun"]*G_NUMBER/G_MPC))
                        amplitude,slope=donor.exact(radius);fine_amp,fine_slope=donor.field(radius)
                        grid_mass=reference.mass(radius,8);amp_error=abs(fine_amp/amplitude-1)
                        slope_error=abs(fine_slope/slope-1)
                        checks.append(dict(file=filename,point=point,relative_mass_refinement=abs(grid_mass/result["mass_Msun"]-1),
                            interpolation_amplitude_error=amp_error,interpolation_derivative_error=slope_error))
                    for order in (8,16):
                        projector=Projector(edges,knots,donor.step,order)
                        result,local,coeff=projector.transfer(donor.field,donor.kappa,ground)
                        projections.append(dict(file=filename,order=order,**result))
                        assert abs(result["ground_mass"]/target-1)<1e-8
                        if order==16:
                            native_data[filename.split(".npz")[0]]=coeff
                            native_data[filename.split(".npz")[0]+"_wall"]=np.array(donor.exact(wall))
                        for row in local:sites.append(dict(file=filename,order=order,**row))
                    tails.extend(dict(file=filename,**row) for row in kinetic_tail(donor,wall))
                for point,radius in named.items():
                    for species in ("cdm","baryon"):
                        result=sheet_measure(bank,species,radius,epoch,seed)
                        dust.append(dict(file=filename,branch=branch,point=point,radius_kpc=radius,species=species,**result))
    for name,data in (("apertures",readouts),("projection",projections),("projection-sites",sites),
                      ("kinetic-tail",tails),("ordinary-and-cold",dust),("transfer-refinement",checks)):
        rows(name+".csv",data)
    buf=io.BytesIO();np.savez_compressed(buf,**native_data);save("lifted-states.npz",buf.getvalue())
    print("target / native wall:",target,wall)
    for row in readouts:
        if row["point"] in ("equal_number","gd1_radius","galactic_wall"):
            print(row["file"][8:47],row["point"],round(row["radius_kpc"],3),round(row["mass_Msun"]/1e9,4),round(row["proper_flow_kms"],3))
    print("donor sampling errors",*[max(row[key] for row in checks) for key in list(checks[0])[2:]])
    print("projection",[(round(row["relative_l2_error"],6),round(row["relative_derivative_l2_error"],6),round(row["overlap2_shape_only"],6)) for row in projections[1::2]])
    print("tail",[(row["kind"],row["kinetic_per_mode_over_predicted"]) for row in tails if row["modes"]==2048])
if __name__=="__main__":run()
