from stage_io import *
from scipy.special import roots_laguerre, expit

UNIT=1e-14
OBS="phi psi slip F phidot rest trace shear field heavy_energy external_energy external_divJ X Y photonshear nushear".split()

class Evolution:
    def __init__(self,model,stride=1,lmax=8,order=12,metric=False):
        self.model=model
        with np.load(HERE/f"sources-{model}.npz") as bank:
            self.times=bank["eta"]
            self.kn=bank["k"]
            self.names=bank["names"].tolist()
            self.bkeys=bank["bg_keys"].tolist()
            self.back=CubicSpline(self.times[::stride],bank["background"][:,::stride].T)
            vals=bank["values"]
            if metric:
                with np.load(HERE/f"metric-input-{model}.npz") as ctl:
                    assert np.array_equal(ctl['eta'],self.times) and np.array_equal(ctl['coord'],PROBES)
                    for key,row in zip(ctl['names'],ctl['values']):vals[self.names.index(key)]=row
            self.drive=CubicSpline(self.times[::stride],vals[:,:,::stride].transpose(2,0,1)/UNIT)
        self.lmax=lmax; self.order=order
        self.labels=("s","h") if model=="heavy" else ("s",)
        self.metas=json.loads(pin("radiation-background.json").read_bytes())[model]
        self.nodes,weights=roots_laguerre(order)
        self.weights=weights*expit(self.nodes)*self.nodes*expit(self.nodes)
        self.idx={name:ii for ii,name in enumerate(["geom","flux","cd","ct","bd","bt","gx","gj"]+[tag+v for tag in self.labels for v in ("f","w")])}
        start=len(self.idx)
        self.ph_sl=slice(start,start+lmax-1);start+=lmax-1
        self.pol_sl=slice(start,start+lmax+1);start+=lmax+1
        self.nu_sl=slice(start,start+(order+1)*(lmax+1));self.rows=self.nu_sl.stop
        self.degrees=np.arange(2,lmax+1)[:,None]

    def rhs(self,env,state,kind,variant,observe=False):
        b,q=env; named=lambda key:state[self.idx[key]]
        der=np.zeros_like(state);out=lambda key,val:der.__setitem__(self.idx[key],val)
        k=self.kn;k2=k*k; h=b["h"];eg=b["eg"];ec=b["ec"];eb=b["eb"];T0=b["T0"];X0=b["X0"]
        field_shear=sum(q[tag+"shear"] for tag in self.labels)
        phot=state[self.ph_sl];pol=state[self.pol_sl];nu=state[self.nu_sl].reshape(self.order+1,self.lmax+1,-1)
        am=self.metas["mass_over_temperature"]*b["a"]; eps=np.hypot(self.nodes,am)
        thermal=self.weights*self.metas["massless_limit_coeff"]/(b["a"]**2*(7*np.pi**4/120))
        nu_trace=(thermal*self.nodes**2*am**2/eps)@nu[1:,0]
        nu_response=-4*b["er"]*nu[0,2]-(thermal*self.nodes**4/eps)@nu[1:,2]
        reactive=variant!="bulk"
        nus=q["nu_bulk"]+reactive*nu_response;pg=eg*(q["ph_bulk"]-reactive*phot[0])
        extraS=0 if variant not in ("plus","minus") else (1 if variant=="plus" else -1)*eg*q["ph_bulk"]
        S=field_shear+q["cshear"]+q["bshear"]+pg+nus+extraS
        slip=(S-q["Q"])/k2
        matter0=0;matter1=0;sd=0;rest0=0;rest1=0;js=0;he=0
        for tag in self.labels:
            bb=b[tag+"b"];vv=b[tag+"v"];mm=(b["a"]*b[tag+"m"])**2;f=named(tag+"f");w=named(tag+"w")
            base=vv*w+mm*bb*f+q[tag+"energy"]
            matter0+=base;matter1+=3*vv**2
            rest0+=-2*vv*w+4*mm*bb*f+q[tag+"trace"];rest1-=6*vv**2
            js+=k2*vv*f+q[tag+"J"]
            if tag=="h":he=base
        if kind=="trace":
            phi=named("geom");F=named("flux")
        elif kind=="conserved":
            F=-eg*(named("flux")+q["Jq"])/(2*k2)
            phi=(q["U"]-.5*eg*(named("geom")-q["Xq"])+3*h*F)/(k2+2*b["et"])
        elif kind=="self":
            F=-js/(2*k2);phi=(q["U"]-.5*matter0+3*h*F)/(k2+.5*matter1)
        else:
            phi=k*0;F=k*0
        if kind=="fixed":slip=k*0
        psi=phi+slip; pd=-F-h*psi+q["Fq"]
        if kind in ("fixed","slip"):pd=0*phi
        massive=ec*(named("cd")+3*phi)+eb*(named("bd")+3*phi)+q["ctrace"]+q["btrace"]
        D=rest0+rest1*phi+massive+reactive*nu_trace
        T=D/eg-4*T0*phi+q["Tq"]
        en=2*(-k2*phi+3*h*F+q["U"]);divj=-2*k2*F
        X=en/eg-4*X0*phi+q["Xq"];Y=divj/eg-q["Jq"]
        if observe:
            heavy=he+(3*b["hv"]**2*phi if "h" in self.labels else 0)
            return np.array([phi,psi,slip,F,pd,massive,D,S,named(self.labels[-1]+"f"),heavy+0*phi,en-(matter0+matter1*phi),divj-js,X,Y,pg,nus])
        if kind=="trace":
            out("geom",pd)
            out("flux",-3*h*F+(b["hp"]-h*h)*psi+k2*(phi-slip)/3+D/6+q["QR"]-2*q["U"]/3)
        if kind=="conserved":
            out("geom",h*T-T0*pd-Y+q["Xforce"])
            out("flux",k2*((X-T)/3+(4*X0-T0)*(psi+phi)/3-T0*phi+(2/3)*(S/eg+q["Sshift"]))+q["Yforce"])
        for tag in self.labels:
            mass=(b["a"]*b[tag+"m"])**2
            out(tag+"f",named(tag+"w")+b[tag+"v"]*(psi+3*phi)+q[tag+"field"])
            out(tag+"w",-2*h*named(tag+"w")-(k2+mass)*named(tag+"f")+mass*b[tag+"b"]*(3*phi-psi)+q[tag+"moment"])
        for tag in ("c","b"):
            out(tag+"d",-named(tag+"t")+q[tag+"number"])
            out(tag+"t",-h*named(tag+"t")+k2*psi+q[tag+"speed"])
        op=b["opacity"];diff=named("gj")-4*named("bt")/3
        der[self.idx["bt"]]+=op*eg/eb*(diff+q["collision_b"])
        out("gx",-named("gj")+q["ph_energy"]-op*q["collision_heat"])
        out("gj",k2*(named("gx")/3+4*(psi+phi)/3+(2/3)*(pg/eg+q["ph_shift"]))+q["ph_momentum"]-op*(diff+q["collision_ph"]))
        prev=np.vstack((named("gj")/k,phot[:-1]));nxt=np.vstack((phot[1:],0*k))
        ell=self.degrees;P=phot[0]+pol[0]+pol[2]
        dp=k*(ell*prev-(ell+1)*nxt)/(2*ell+1)-op*phot;dp[0]+=op*P/10;der[self.ph_sl]=dp
        deg=np.arange(self.lmax+1)[:,None];zp=np.zeros_like(pol[:1])
        dl=k*(deg*np.vstack((zp,pol[:-1]))-(deg+1)*np.vstack((pol[1:],zp)))/(2*deg+1)-op*pol
        dl[0]+=op*P/2;dl[2]+=op*P/10;der[self.pol_sl]=dl
        speed=np.r_[1,self.nodes/eps][:,None,None];dn=der[self.nu_sl].reshape(nu.shape)
        dn[:,1:]+=speed*k*deg[1:]/(2*deg[1:]+1)*nu[:,:-1]
        dn[:,:-1]-=speed*k*(deg[:-1]+1)/(2*deg[:-1]+1)*nu[:,1:]
        dn[:,0]+=pd;dn[:,1]+=k*psi/(3*speed[:,0])
        return der

    def integrate(self,kind,variant="full",sub=1):
        size=(len(self.times)-1)*sub;times=np.interp(np.arange(size*2+1)/(2*sub),np.arange(len(self.times)),self.times)
        bg=self.back(times);src=self.drive(times)
        env=lambda ii:(dict(zip(self.bkeys,bg[ii])),dict(zip(self.names,src[ii])))
        state=np.zeros((self.rows,len(self.kn)),complex)
        if variant in ('launch_plus','launch_minus'):
            assert kind=='trace'
            state[self.idx['geom']]=(1 if variant=='launch_plus' else -1)*env(0)[1]['Xq']
        if kind=="trace":
            first=self.rhs(env(0),state,"conserved",variant,True)
            state[self.idx["geom"]]=first[0];state[self.idx["flux"]]=first[3]
        traj=[]
        for ii in range(size+1):
            if ii%sub==0:traj.append(self.rhs(env(ii*2),state,kind,variant,True))
            if ii==size:break
            if ii%256==0:guard()
            en=env(ii*2);mid=env(ii*2+1);end=env(ii*2+2)
            dt=times[2*ii+2]-times[2*ii]
            one=self.rhs(en,state,kind,variant);two=self.rhs(mid,state+dt*one/2,kind,variant)
            three=self.rhs(mid,state+dt*two/2,kind,variant);four=self.rhs(end,state+dt*three,kind,variant)
            state+=dt*(one+2*two+2*three+four)/6
        arr=np.array(traj)*UNIT
        assert np.isfinite(arr).all()
        return arr

def run(model):
    for kind,variant,stride,sub,ell,order in (
        ("trace","full",1,1,8,12),("conserved","full",1,1,8,12),("self","full",1,1,8,12),
        ("slip","full",1,1,8,12),("fixed","full",1,1,8,12),("trace","bulk",1,1,8,12),
        ("trace","full",1,2,8,12),("trace","full",2,2,8,12),("trace","full",1,1,12,24),
        ("trace","plus",1,1,8,12),("trace","minus",1,1,8,12)):
        label=f"{model}-{kind}-{variant}-{stride}-{sub}-{ell}-{order}"
        ev=Evolution(model,stride,ell,order)
        arr=ev.integrate(kind,variant,sub)
        packet("nativeclock-"+label+".npz",names=OBS,coord=PROBES,eta=ev.times,values=arr)
        print(label,flush=True)
if __name__=="__main__":
    for model in ("cold","heavy"):
        if '--launch' in sys.argv:
            ev=Evolution(model)
            for variant in ('launch_plus','launch_minus'):
                arr=ev.integrate('trace',variant)
                packet(f'launchclock-{model}-{variant}.npz',names=OBS,coord=PROBES,eta=ev.times,values=arr)
        elif '--metric' in sys.argv:
            ev=Evolution(model,metric=True)
            for kind in ('trace','conserved'):
                arr=ev.integrate(kind)
                packet(f'metricclock-{model}-{kind}.npz',names=OBS,coord=PROBES,eta=ev.times,values=arr)
        else:run(model)
