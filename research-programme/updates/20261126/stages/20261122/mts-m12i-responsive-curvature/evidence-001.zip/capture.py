from stage_io import *
import diagnostics as previous
from diagnostics import native,symbolic,Dummy,patch
import tempfile,subprocess
EXTRA=["opacity","delta_p_b","qgdot","qrdot","vbdot","pigdot","pirdot","E(2)","octg","dopacity","polter"]
NAMES=previous.NAMES+EXTRA
def run(model,func):
    seed=native.Seed(model,"anchorA","heavy")
    file=native.SPEC/"runs/projection/a225-w6-d8.npz" if model=="heavy" else native.NATIVE/"runs/backgrounds/cold.npz"
    status=native.obj(native.source(f"runs/{model}/status.json"));native.checked(file,status["source_hash"])
    for path in native.engine.inherited.native_hashes():native.checked(path,status["input_hashes"][str(path)])
    params=native.engine.inherited.params_for(file,background_boost=8.);params.DoLateRadTruncation=False
    bg=native.engine.camb.get_background(params);bg.Params.Accuracy.IntTolBoost=6
    with np.load(earlier(f"native-{model}.npz")) as src:
        ix=src["raw"];at=src["dates"][ix];nodes=src["k"];names=src["names"].tolist();original=src["values"][:,ix,:]
    eta=bg.conformal_time(1/at-1,tol=1e-10)
    times=np.empty(2*len(eta)-1);times[::2]=eta;times[1::2]=(eta[:-1]+eta[1:])/2
    values=[];keys=[]
    with patch.object(symbolic,"compile_sympy_to_camb_source_func",return_value=func):
        for f in sorted((native.SPEC/"runs"/model).glob("chunk-*.npz")):
            with np.load(native.source(f.relative_to(native.SPEC).as_posix())) as arch:allk=arch["modes"]
            pick=allk[np.isin(allk,nodes)]
            if len(pick)==0:continue
            guard()
            batch=np.unique(np.r_[pick,allk.max()]);arr=bg.get_time_evolution(batch,times,vars=names+[Dummy(s) for s in NAMES],lAccuracyBoost=4)
            values.extend(arr[np.searchsorted(batch,pick)]);keys.extend(pick)
    data=np.array(values)[np.argsort(keys)];base=data[:,:,:len(names)];custom=data[:,:,len(names):]
    assert np.isfinite(data).all()
    tests=[]
    for key in ("etak","Weyl","delta_cdm","delta_baryon","v_photon","pi_photon","mts_drho_s")+(("mts_drho_h","mts_q_h") if model=="heavy" else ()):
        idx=names.index(key);ref=original[:,:,idx]
        tests.append(dict(column=key,relative=np.linalg.norm(ref-base[:,::2,idx])/np.linalg.norm(ref)))
    assert max(r["relative"] for r in tests)<2e-5
    therm=bg.get_background_time_evolution(times,["opacity","x_e","cs2b"],format="dict")
    assert np.max(abs(custom[0,:,NAMES.index("opacity")]/therm["opacity"]-1))<2e-5
    with np.load(file) as source:
        from scipy.interpolate import CubicSpline
        a=custom[0,:,NAMES.index("a")];fields={}
        for key,label,grid in (("s","slow","efold"),("h","heavy","heavy_efold")):
            if model=="cold" and key=="h":continue
            for var in ("phi","phidot"):
                fields[f"{label}_{var}"]=CubicSpline(source[grid],source[var+"_"+key])(np.log(a))
            fields[label+"_mass"]=float(source[label+"_mass_mpc"])
    packet(f"native-{model}.npz",k=nodes,eta=times,names=NAMES,standard=names,custom=custom,base=base,xe=therm["x_e"],cs2b=therm["cs2b"],**fields)
    table(f"prior-replay-{model}.csv",tests)
    print(model,"native capture done",flush=True)
def main():
    if sys.argv[1:2]!=["--child"]:
        with tempfile.TemporaryDirectory(dir=HERE,prefix="reader-") as folder:
            subprocess.run([sys.executable,"-B",str(HERE/"capture.py"),"--child",folder,*sys.argv[1:]],check=True)
        return
    folder=Path(sys.argv[2]).resolve();assert folder.parent==HERE and folder.name.startswith("reader-")
    chain=previous.CHAIN.parent
    drive=next(ch+":" for ch in "VWXYZ" if not Path(ch+":/").exists());subprocess.run(["subst",drive,str(chain)],check=True)
    try:
        prefixes=("libexec/gcc/x86_64-w64-mingw32/14.2.0","lib","bin","lib/gcc/x86_64-w64-mingw32/14.2.0","x86_64-w64-mingw32/lib")
        flags=" ".join(f"-B{drive}/{sub}/" for sub in prefixes)+" "+" ".join(f"-L{drive}/{sub}/" for sub in prefixes[1:] if sub!="bin")
        body="\n".join(f"sources({j}) = {key}" for j,key in enumerate(NAMES,1))
        func=symbolic.compile_source_function_code(body,file_path=str(folder),compiler=drive+"/bin/gfortran.exe",fflags=flags+" -shared -O1",cache=True)
    finally:
        maps=subprocess.check_output(["subst"],text=True).splitlines()
        assert any(row.startswith(drive+"\\:") and Path(row.split("=>",1)[1].strip())==chain for row in maps)
        subprocess.run(["subst",drive,"/D"],check=True)
    save("readout.f90",(folder/"camb_source1.f90").read_bytes())
    for model in sys.argv[3:] or ("cold","heavy"):run(model,func)
if __name__=="__main__":main()
