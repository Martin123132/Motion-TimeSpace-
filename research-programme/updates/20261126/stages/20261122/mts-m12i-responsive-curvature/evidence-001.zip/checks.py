from sources import Data
from evolve import *
from scipy.interpolate import make_interp_spline

def read(label,ev):
    with np.load(HERE/(label+".npz")) as bank:
        assert np.array_equal(bank["eta"],ev.times) and np.array_equal(bank["coord"],PROBES) and bank["names"].tolist()==OBS
        val=bank["values"]
        assert val.shape==(len(ev.times),len(OBS),5) and np.isfinite(val).all()
        return val

def ratio(diff,ref):
    mag=np.linalg.norm(ref)
    if mag==0:return None
    return float(np.linalg.norm(diff)/mag)

def holdout(model):
    data=Data(model);times=data.eta;kn=data.nodes;rows=[]
    for fold in range(2):
        held=np.arange(1+fold,len(kn)-1,2);keep=np.ones(len(kn),bool);keep[held]=False
        f=lambda key:PchipInterpolator(np.log(kn[keep]),data.first[key][keep],axis=0)(np.log(kn[held]))
        phi=f('phi');psi=f('psi');kk=kn[held,None]**2
        bg=data.background;h=bg['h'];eg=bg['eg'];ent=bg['et']+bg['pt']
        der=lambda arr:make_interp_spline(times,arr,k=5,axis=1).derivative()(times)
        F=-der(phi)-h*psi
        energy=(-2*kk*phi+6*h*F)/eg
        tr=energy+6*(der(F)+2*h*F+ent*psi/2-kk*(phi-psi)/3)/eg
        for key,out in [('phi',phi),('psi',psi),('E',energy),('trace',tr),('Vtot',-2*F/eg),('S',kk*(psi-phi)/eg)]:
            target=data.first[key][held];direct=f(key)
            rows.append(dict(model=model,heldout_parity=fold,count=len(held),field=key,direct=ratio(direct-target,target),metric=ratio(out-target,target)))
    return rows

def check():
    rows=[];detail=[];hold=[];zeros=[]
    for model in ('cold','heavy'):
        ev=Evolution(model);ref=read(f'nativeclock-{model}-trace-full-1-1-8-12',ev)
        ctl=read(f'metricclock-{model}-trace',ev)
        alt=read(f'metricclock-{model}-conserved',ev)
        pos=read(f'nativeclock-{model}-trace-plus-1-1-8-12',ev);neg=read(f'nativeclock-{model}-trace-minus-1-1-8-12',ev)
        tests=[('metric_first_dual',alt-ctl,ctl),('representation',ctl-ref,ref),('linearity',(pos+neg)/2-ref,ref)]
        for name,path in [('raw_dual','conserved-full-1-1-8-12'),('scalar_only','self-full-1-1-8-12'),('fixed_curvature','slip-full-1-1-8-12'),('fixed_geometry','fixed-full-1-1-8-12'),('bulk_only','trace-bulk-1-1-8-12'),('halve_step','trace-full-1-2-8-12'),('increase_angular_thermal','trace-full-1-1-12-24'),('extra_shear','trace-plus-1-1-8-12')]:
            tests.append((name,read(f'nativeclock-{model}-'+path,ev)-ref,ref))
        fine=read(f'nativeclock-{model}-trace-full-1-2-8-12',ev)
        tests.append(('coarsen_time_sources',read(f'nativeclock-{model}-trace-full-2-2-8-12',ev)-fine,fine))
        lp=read(f'launchclock-{model}-launch_plus',ev);lm=read(f'launchclock-{model}-launch_minus',ev)
        tests.extend([('launch_density',lp-ref,ref),('launch_linearity',(lp+lm)/2-ref,ref)])
        for name,diff,base in tests:
            for jj,key in enumerate(OBS):
                val=ratio(diff[:,jj],base[:,jj]);norms=[ratio(diff[:,jj,ii],base[:,jj,ii]) for ii in range(5)]
                if val is None:continue
                rows.append(dict(model=model,test=name,field=key,relative_panel=val,max_probe=max(norms),rms_reference=float(np.sqrt(np.mean(abs(base[:,jj])**2)))))
                for probe,result in zip(PROBES,norms):detail.append(dict(model=model,test=name,field=key,probe=str(probe),relative=result))
                if name.endswith('linearity'):assert val<1e-9
        for mode in ('conserved','trace','self','fixed','slip'):
            probe=ev.rhs((dict(zip(ev.bkeys,ev.back(ev.times[0]))),dict(zip(ev.names,ev.drive(ev.times[0])*0))),np.zeros((ev.rows,5),complex),mode,'full')
            assert np.all(probe==0)
            zeros.append(dict(model=model,mode=mode,zero_forcing_max=float(abs(probe).max())))
        hold.extend(holdout(model))
    table('all-comparisons.csv',rows);table('all-per-probe.csv',detail);table('withheld-k.csv',hold);table('zero-drive.csv',zeros)
    for row in rows:
        if row['test'] in ('raw_dual','metric_first_dual','representation','halve_step','coarsen_time_sources','extra_shear') and row['field'] in ('phi','psi','field'):
            print(row['model'],row['test'],row['field'],round(row['relative_panel']*100,6),round(row['max_probe']*100,6))
if __name__=='__main__':check()
