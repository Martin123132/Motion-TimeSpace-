from stage_io import *
pin("tensor_control.py")
from tensor_control import jets

def scalar(point,amp):
    hub=.16;time=np.eye(4)[0];scale=np.exp(hub*point[0])
    phi,psi,phi2,psi2=[jets(point,idx) for idx in range(4)]
    met=np.zeros(4);dg=np.zeros((4,4));ddg=np.zeros((4,4,4))
    for axis in range(4):
        sign=1 if axis else -1
        first,second=(phi,phi2) if axis else (psi,psi2)
        val,grad,hess=[-2*sign*(amp*one+amp**2*two) for one,two in zip(first,second)]
        val+=1;fac=sign*scale**2
        met[axis]=fac*val
        dg[axis]=fac*(grad+2*hub*time*val)
        ddg[axis]=fac*(hess+2*hub*(np.outer(time,grad)+np.outer(grad,time))+4*hub**2*val*np.outer(time,time))
    conn=np.zeros((4,4,4));dc=np.zeros((4,4,4,4))
    for up,one,two in np.ndindex(4,4,4):
        x=int(up==two);y=int(up==one);z=int(one==two)
        conn[up,one,two]=(x*dg[up,one]+y*dg[up,two]-z*dg[one,up])/(2*met[up])
        dc[:,up,one,two]=(x*ddg[up,one]+y*ddg[up,two]-z*ddg[one,up])/(2*met[up])-conn[up,one,two]*dg[up]/met[up]
    ric=0.
    for idx in range(4):
        for link in range(4):
            comp=dc[link,link,idx,idx]-dc[idx,link,idx,link]
            for sub in range(4):
                comp+=conn[link,link,sub]*conn[sub,idx,idx]-conn[link,idx,sub]*conn[sub,idx,link]
            ric+=comp/met[idx]
    return ric*scale**2

def expanded(point):
    hub=.16
    (ph,pg,pp),(ps,sg,ss),(f2,fg,ff),(s2,tg,tt)=[jets(point,idx) for idx in range(4)]
    lp=np.trace(pp[1:,1:]);ls=np.trace(ss[1:,1:]);gp=pg[1:];gs=sg[1:]
    F1=-pg[0]-hub*ps;Fp=-pp[0,0]-hub*sg[0]
    F2=-fg[0]-hub*s2+(ps-2*ph)*pg[0]+1.5*hub*ps**2
    F2p=-ff[0,0]-hub*tg[0]+(sg[0]-2*pg[0])*pg[0]+(ps-2*ph)*pp[0,0]+3*hub*ps*sg[0]
    U=4*ph*lp+1.5*gp@gp+1.5*F1**2
    QR=ps*(Fp-hub*F1)+1.5*hub**2*ps**2-F1**2+(-2*ps*ls-2*gs@gs+2*ph*ls+gs@gs-gp@gs)/3
    return 6*(F2p+3*hub*F2+hub**2*s2+np.trace(2*ff[1:,1:]-tt[1:,1:])/3-QR+2*U/3)

def run():
    rows=[]
    for idx,point in enumerate(np.random.default_rng(281110).normal(size=(12,4))):
        est=[];base=scalar(point,0.)
        for amp in (.008,.004):est.append((scalar(point,amp)+scalar(point,-amp)-2*base)/(2*amp**2))
        value=(4*est[1]-est[0])/3;want=expanded(point);rel=abs(value-want)/max(abs(want),1e-12)
        assert rel<2e-5,(idx,want,value)
        rows.append(dict(point=idx,ricci_direct=value,from_trace_equation=want,relative=rel))
    table('independent-curvature.csv',rows)
if __name__=='__main__':run()
