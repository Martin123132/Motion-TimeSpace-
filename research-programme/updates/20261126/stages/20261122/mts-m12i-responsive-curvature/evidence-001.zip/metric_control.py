from sources import *

def metric_drive(modes,coords,data):
    names=("phi","psi","F","Fp","pd","E","X","T","trace","S","Vtot","G")
    original=data.first
    try:
        data.first={key:original[key] for key in names}
        pair=Pair(modes,np.array(coords),data)
    finally:data.first=original
    baseline=pair.parts
    back=data.background
    h=back["h"];eg=back["eg"];en=back["et"];pr=back["pt"];X0=back["X0"];T0=back["T0"];k2=pair.k2
    parts={}
    for side,kmag in enumerate((pair.q2,pair.p2)):
        unique,indices,inv=np.unique(kmag,return_index=True,return_inverse=True);kk=unique[:,None]
        phi=baseline["phi"][side][indices];psi=baseline["psi"][side][indices]
        pd=make_interp_spline(data.eta,phi,k=5,axis=1).derivative()(data.eta)
        F=-pd-h*psi;Fp=make_interp_spline(data.eta,F,k=5,axis=1).derivative()(data.eta)
        E=(-2*kk*phi+6*h*F)/eg
        pressure=-2*(Fp+2*h*F+(en+pr)*psi/2-kk*(phi-psi)/3)/eg
        tr=E-3*pressure
        vals=dict(phi=phi,psi=psi,F=F,Fp=Fp,pd=pd,E=E,X=E-4*X0*phi,T=tr-4*T0*phi,trace=tr,S=kk*(psi-phi)/eg,Vtot=-2*F/eg,G=phi+psi)
        for name,val in vals.items():parts.setdefault(name,[]).append(val[inv])
    pair.parts=parts
    ph="phi";ps="psi";G="G";p=pair.product;lap=pair.lap;dg=pair.dg;dv=pair.dv;g=pair.grad
    pp=p(ph,ph);ss=p(ps,ps);g2q=pp-ss
    return dict(U=-k2*pp+2*lap(ph,ph)-.5*g(ph,ph)+1.5*p("F","F"),
        Fq=p(ps,"pd")-2*p(ph,"pd")+1.5*h*ss,
        QR=p(ps,"Fp")-h*p(ps,"F")+.75*(en+pr)*ss-p("F","F")+(k2*ss+2*lap(ph,ps)+g(ps,ps)-g(ph,ps))/3,
        Xq=4*X0*pp-4*p(ph,"E"),Tq=4*T0*pp-4*p(ph,"trace"),Jq=3*dv(ph,"Vtot"),Sshift=-4*pair.spin(ph,"S"),
        Xforce=-2*T0*p(ph,"pd")-p("pd","T")-2*dv(G,"Vtot")-lap(G,"Vtot"),
        Yforce=-(dg(G,"X")-dg(G,"T"))/3+k2*((4*X0-T0)*g2q/3-T0*pp)
          -(4*dg("X",G)-dg("T",G)+(4*X0-T0)*dg(G,G))/3+dg("T",ph)+T0*dg(G,ph)+2*k2*pair.spin(G,"S")/3)
def run(model):
    data=Data(model);modes=Mixed();series=[]
    for coord in PROBES:
        guard();series.append(metric_drive(modes,coord,data))
    keys=list(series[0]);values=np.array([[row[key] for row in series] for key in keys]);assert np.isfinite(values).all()
    packet(f"metric-input-{model}.npz",names=keys,values=values,eta=data.eta,coord=PROBES)
if __name__=="__main__":
    for model in ("cold","heavy"):run(model)
