from stage_io import *
import ast
from checks import check
from ricci_check import run as ricci

def verify():
    guard()
    check();ricci()
    rows=list(csv.DictReader((HERE/'all-comparisons.csv').open()))
    def get(model,test,key,which='relative_panel'):
        return float(next(row[which] for row in rows if (row['model'],row['test'],row['field'])==(model,test,key)))
    for model in ('cold','heavy'):
        for key in ('psi','phi','field'):
            assert get(model,'metric_first_dual',key,'max_probe')<2e-5
            assert get(model,'halve_step',key,'max_probe')<2e-5
            assert get(model,'increase_angular_thermal',key)<2e-5
        assert 1e-4<get(model,'raw_dual','phi')
    assert get('cold','raw_dual','phi')>.005>get('heavy','raw_dual','phi')
    assert get('cold','representation','psi')>.005>get('heavy','representation','psi')
    for prefix,nfiles in [('nativeclock-',22),('launchclock-',4),('metricclock-',4)]:assert len(list(HERE.glob(prefix+'*.npz')))==nfiles
    assert not list(HERE.glob('reader-*')) and not list(HERE.glob('response-*.npz'))
    for path in HERE.glob('*.py'):ast.parse(path.read_text(encoding='utf-8'),filename=str(path))
    files={path.name:sha(path) for path in sorted(HERE.iterdir()) if path.is_file() and path.name!='seal.json'}
    record('seal.json',dict(files=files,predecessor=sha(PRE/'seal.json'),probes=PROBES,
        independent_cold_raw_curvature='fails 0.5 percent',scope='conditional mixed-mode perturbations; no stream or halo inference'))
    print(len(files),'verified files',sha(HERE/'seal.json'))
if __name__=='__main__':verify()
