from pathlib import Path
import os,sys,csv,hashlib,io,json
for name in ("OPENBLAS_NUM_THREADS","MKL_NUM_THREADS","OMP_NUM_THREADS","NUMEXPR_NUM_THREADS","BLIS_NUM_THREADS"):os.environ[name]="1"
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
PRE=HERE.parent/"mts-m12i-relativistic-slip-20261122"
def sha(path):
    with path.open("rb") as src:return hashlib.file_digest(src,"sha256").hexdigest()
assert sha(PRE/"seal.json")=="607045e4861451d49bd45e0588dfb63cea5f1ef4ce6dee3c7db80e60637565bf"
manifest=json.loads((PRE/"seal.json").read_bytes())["files"]
def pin(name):
    path=PRE/name
    assert sha(path)==manifest[name],name
    return path
for name in ("common_slip.py","diagnostics.py","canonical_replay.py","pressure_bridge.py","constraint.py","pairs.py"):pin(name)
sys.path.insert(0,str(PRE))
from common_slip import Mixed,transfer,np,guard as inherited,pinned as earlier
from scipy.interpolate import CubicSpline,PchipInterpolator
from scipy.integrate import solve_ivp
sys.path.insert(0,str(HERE))
def guard():
    inherited()
    assert __debug__ and not (HERE/"STOP-REQUESTED").exists()
def save(name,data):
    guard();path=HERE/name
    if path.exists():assert path.read_bytes()==data,name
    else:
        with path.open("xb") as dst:dst.write(data)
def packet(name,**obj):
    buf=io.BytesIO();np.savez_compressed(buf,**obj);save(name,buf.getvalue())
def table(name,items):
    buf=io.StringIO();writer=csv.DictWriter(buf,items[0],lineterminator="\n");writer.writeheader();writer.writerows(items);save(name,buf.getvalue().encode())
def record(name,data):save(name,(json.dumps(data,sort_keys=True,indent=2,allow_nan=False)+"\n").encode())
PROBES=((4,2,1),(9,-2,4),(21,8,1),(-17,-6,8),(29,1,1))
