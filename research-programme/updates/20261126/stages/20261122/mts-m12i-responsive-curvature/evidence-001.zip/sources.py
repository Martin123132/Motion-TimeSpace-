from stage_io import *
from scipy.interpolate import make_interp_spline

class Data:
    def __init__(self,model):
        with np.load(HERE/f"native-{model}.npz") as src:
            self.eta=src["eta"];self.nodes=src["k"];self.raw=raw=dict(zip(src["names"].tolist(),np.moveaxis(src["custom"],2,0)))
            self.base=base=dict(zip(src["standard"].tolist(),np.moveaxis(src["base"],2,0)))
            self.scalars=fields={label:(src[label+"_phi"],src[label+"_phidot"],float(src[label+"_mass"])) for label in (("slow","heavy") if model=="heavy" else ("slow",))}
        kk=self.nodes[:,None];h=raw["adotoa"];s=raw["sigma"];e=raw["grho"];p=raw["gpres"];a=raw["a"];ent=e+p
        alpha=s/kk;phi=raw["etak"]/kk-h*alpha;psi=2*raw["phi"]-phi;F=-(raw["dgq"]+ent*s)/(2*kk);pd=-F-h*psi
        fprime=make_interp_spline(self.eta,F,k=5,axis=1).derivative()(self.eta)
        energy=raw["dgrho"]-3*h*ent*alpha
        pressure=-2*(fprime+2*h*F+ent*psi/2-kk**2*(phi-psi)/3)
        reference=raw["grhog_t"];tr=(energy-3*pressure)/reference
        self.background={key:arr[0] for key,arr in (("a",a),("h",h),("et",e),("pt",p),("ec",raw["grhoc_t"]),("eb",raw["grhob_t"]),("eg",reference),("er",raw["grhor_t"]),
            ("enu",raw["grhonu_t"]),("opacity",raw["opacity"]),("X0",e/reference),("T0",(e-3*p)/reference),("hp",-(e+3*p)/6))}
        self.first=dict(phi=phi,psi=psi,pd=pd,F=F,Fp=fprime,E=energy/reference,trace=tr,
            X=energy/reference-4*e/reference*phi,T=tr-4*(e-3*p)/reference*phi,
            Vtot=(raw["dgq"]+ent*s)/(kk*reference),S=-raw["dgpi"]/reference,G=phi+psi,
            Dcdm=base["delta_cdm"]-3*h*alpha-3*phi,Db=base["delta_baryon"]-3*h*alpha-3*phi,
            Vcdm=s/kk,Vb=(raw["vb"]+s)/kk,Xg=base["delta_photon"]-4*h*alpha-4*phi,Dg=base["delta_photon"]-4*h*alpha,
            Vg=(raw["qg"]+4*s/3)/kk,Sg=-raw["pig"],Vr=(.75*raw["qr"]+s)/kk)
        enh=raw["grhonu_t"]+p-(reference+raw["grhor_t"])/3-raw["w_lam"]*raw["grhov_t"]
        vm=(raw["dgq"]-raw["grhob_t"]*raw["vb"]-reference*raw["qg"]-raw["grhor_t"]*raw["qr"]-raw["grhov_t"]*raw["qde"])/enh+s
        self.first["Vm"]=vm/kk;self.background["enm"]=enh[0]
        for label,(b,bp,mass) in fields.items():
            key=label[0];self.background[key+"b"]=b;self.background[key+"v"]=bp;self.background[key+"m"]=0*b+mass
            f=base["mts_dphi_"+key]+bp*alpha
            n=base["mts_dphidot_"+key]+(-3*h*bp-(a*mass)**2*b)*alpha
            self.first[key+"f"]=f;self.first[key+"n"]=n;self.first[key+"u"]=n-3*bp*phi

class Pair:
    def __init__(self,modes,coord,data):
        self.coord=coord;axes=modes.big.axes.T
        lookup={tuple(ax):(idx,False) for idx,ax in enumerate(axes)}
        for key,(idx,_) in list(lookup.items()):
            rev=tuple(-np.array(key))
            if rev not in lookup:lookup[rev]=(idx,True)
        keys=[np.array(key) for key,entry in lookup.items() if modes.long[entry[0]] and tuple(coord-np.array(key)) in lookup and not modes.long[lookup[tuple(coord-np.array(key))][0]]]
        lo=np.array(keys);hi=coord-lo
        refs=lambda vec:[lookup[tuple(row)] for row in vec]
        da,db=refs(lo),refs(hi)
        def select(arr,marks):
            vals=arr[[entry[0] for entry in marks]]
            return np.where([entry[1] for entry in marks],vals.conj(),vals)
        self.phase=select(modes.R,da)*select(modes.R,db)
        unit=modes.big.fund;lo=lo*unit;hi=hi*unit;wave=coord*unit
        self.k2=wave@wave;self.q2=np.sum(lo**2,axis=1);self.p2=np.sum(hi**2,axis=1)
        self.kq=lo@wave;self.kp=hi@wave;self.dot=np.sum(lo*hi,axis=1)
        self.pair_count=len(lo)
        l,il=np.unique(np.sqrt(self.q2),return_inverse=True);s,ir=np.unique(np.sqrt(self.p2),return_inverse=True)
        self.parts={}
        for key,val in data.first.items():
            func=PchipInterpolator(np.log(data.nodes),val,axis=0,extrapolate=False)
            self.parts[key]=(func(np.log(l))[il],func(np.log(s))[ir])
    def product(self,one,two,ls=1.,sl=1.):
        l,r=self.parts[one];a,b=self.parts[two]
        return np.einsum("q,qt,qt->t",self.phase*ls,l,b)+np.einsum("q,qt,qt->t",self.phase*sl,r,a)
    def dg(self,field,der):return self.product(field,der,-self.kp,-self.kq)
    def dv(self,field,vel):return -self.dg(field,vel)
    def grad(self,left,right):return self.product(left,right,-self.dot,-self.dot)
    def lap(self,field,der):return self.product(field,der,-self.p2,-self.q2)
    def shear(self,left,right):
        coef=-1.5*(self.kq*self.kp/self.k2-self.dot/3)
        return self.product(left,right,coef,coef)
    def spin(self,field,stress):
        return self.product(field,stress,1.5*(self.kp**2/(self.k2*self.p2)-1/3),1.5*(self.kq**2/(self.k2*self.q2)-1/3))
    def spinflow(self,stress,vel):
        return self.product(stress,vel,self.kq*self.dot/self.q2-self.kp/3,self.kp*self.dot/self.p2-self.kq/3)

def make(modes,coord,data,model):
    op=Pair(modes,coord,data);p=op.product;g=op.grad;spin=op.shear;dg=op.dg;dv=op.dv;lap=op.lap;k2=op.k2;back=data.background
    h=back["h"];en=back["et"]+back["pt"];X0=back["X0"];T0=back["T0"]
    ph="phi";ps="psi";G="G"
    pp=p(ph,ph);ss=p(ps,ps);sp=p(ph,ps);g2q=pp-ss
    Q=-k2*(pp+ss)
    qproj=1.5*(op.kp**2/k2-op.p2/3);qswap=1.5*(op.kq**2/k2-op.q2/3)
    Q+=2*(p(ph,ph,-qproj,-qswap)-p(ph,ps,-qproj,-qswap))+spin(ph,ph)-spin(ps,ps)-2*spin(ph,ps)
    U=-k2*pp+2*lap(ph,ph)-.5*g(ph,ph)+1.5*p("F","F")
    Fq=p(ps,"pd")-2*p(ph,"pd")+1.5*h*ss
    qr=p(ps,"Fp")-h*p(ps,"F")+.75*en*ss-p("F","F")+(k2*ss+2*lap(ph,ps)+g(ps,ps)-g(ph,ps))/3
    xq=4*X0*pp-4*p(ph,"E");tq=4*T0*pp-4*p(ph,"trace")
    packet0=dict(U=U,Q=Q,Fq=Fq,QR=qr,Xq=xq,Tq=tq,Jq=3*dv(ph,"Vtot"),Sshift=-4*op.spin(ph,"S"),
        Xforce=-2*T0*p(ph,"pd")-p("pd","T")-2*dv(G,"Vtot")-lap(G,"Vtot"),
        Yforce=-(dg(G,"X")-dg(G,"T"))/3+k2*((4*X0-T0)*g2q/3-T0*pp)
          -(4*dg("X",G)-dg("T",G)+(4*X0-T0)*dg(G,G))/3+dg("T",ph)+T0*dg(G,ph)+2*k2*op.spin(G,"S")/3)
    for tag,den,vel,e0 in (("c","Dcdm","Vcdm",back["ec"]),("b","Db","Vb",back["eb"])):
        packet0[tag+"number"]=-dv(den,vel)-dv(ps,vel)-2*dv(ph,vel)
        packet0[tag+"speed"]=k2*(g(vel,vel)-ss)/2
        packet0[tag+"trace"]=e0*(3*p(ph,den)+7.5*pp-.5*g(vel,vel))
        packet0[tag+"shear"]=e0*spin(vel,vel)
    B1=lambda field:dv(field,"Vg")-4*dv(field,"Vb")/3
    primitive=4*dv(ph,"Vg")-4*(dv("Dg","Vb")+dv(ph,"Vb"))/3-op.spinflow("Sg","Vb")
    packet0.update(collision_ph=primitive+B1("Db")+B1(ps)-B1(ph),
        collision_b=primitive+B1(ps)-B1(ph),
        ph_energy=-2*dv(G,"Vg")-lap(G,"Vg"),
        collision_heat=g("Vb","Vg")-4*g("Vb","Vb")/3,
        ph_momentum=-dg(G,"Xg")/3+4*k2*g2q/3-4*(dg("Xg",G)+dg(G,G))/3+2*k2*op.spin(G,"Sg")/3,
        ph_shift=-4*op.spin(ph,"Sg"),ph_bulk=.75*spin("Vg","Vg"),
        nu_bulk=4*back["er"]*spin("Vr","Vr")/3+back["enm"]*spin("Vm","Vm"))
    K=-ss/2+3*sp+7.5*pp;V=-ss/2-3*sp+1.5*pp
    for label,(base,speed,mass) in data.scalars.items():
        key=label[0];f=key+"f";u=key+"u";n=key+"n";am2=(back["a"]*mass)**2
        normal=3*p(ph,u)+7.5*pp*speed
        packet0[key+"field"]=p(ps,u)+3*p(ph,u)+speed*K
        packet0[key+"moment"]=dg(ps,f)-dg(ph,f)-am2*(p(ps,f)-3*p(ph,f)+base*V)
        packet0[key+"energy"]=speed*normal+.5*(p(n,n)+g(f,f)+am2*p(f,f))
        packet0[key+"trace"]=-2*speed*normal-p(n,n)+g(f,f)+2*am2*p(f,f)
        packet0[key+"J"]=-dg(n,f)
        packet0[key+"shear"]=spin(f,f)
    return packet0,op.pair_count
def run(model):
    data=Data(model);modes=Mixed();series=[];counts=[]
    for const in PROBES:
        guard();src,number=make(modes,np.array(const),data,model)
        series.append(src);counts.append(number)
    keys=list(series[0]);fields=np.array([[rec[key] for rec in series] for key in keys])
    assert np.isfinite(fields).all()
    packet("sources-"+model+".npz",eta=data.eta,coord=PROBES,k=np.linalg.norm(PROBES,axis=1)*modes.big.fund,names=keys,values=fields,counts=counts,
        bg_keys=list(data.background),background=np.array(list(data.background.values())))
    print(model,counts,flush=True)
if __name__=="__main__":
    for model in sys.argv[1:] or ("cold","heavy"):run(model)
