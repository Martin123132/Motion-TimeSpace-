from base import *
def mapping(path,fields):
    with path.open() as st: data=list(csv.DictReader(st))
    out={tuple(row[k] for k in fields):row for row in data}
    assert len(out)==len(data)
    return out
def vector(row,prefix):return np.array([float(row[prefix+"_"+axis]) for axis in "xyz"])
def audit(final,alternatives):
    ps=("state","point");ss=("state","shell","harmonic")
    pref=mapping(HERE/f"points-{final}.csv",ps);sref=mapping(HERE/f"surface-{final}.csv",ss)
    checks=[]
    def gate(test,k,delta,scale):
        error=float(np.linalg.norm(delta)/np.linalg.norm(scale))
        assert np.isfinite(error)
        checks.append(dict(test=test,state=k[0],site=":".join(k[1:]),relative_error=error,pass_005=error<=.005))
    for other in alternatives:
        pts=mapping(HERE/f"points-{other}.csv",ps);sur=mapping(HERE/f"surface-{other}.csv",ss)
        for k,r in pref.items():
            for prefix in ("moving","relative"):
                if k[1]=="centre" and prefix=="relative":continue
                nominal=vector(r,prefix);gate(other+"_"+prefix,k,vector(pts[k],prefix)-nominal,nominal)
        for k,r in sref.items():
            nominal=float(r["radial"]);gate(other+"_radial_modes",k,float(sur[k]["radial"])-nominal,nominal)
    flat=mapping(previous.pin(RELEASE,"weak-field-feedback.csv"),("prep","flow","aperture"))
    for (prep,flow,ap),row in flat.items():
        k=(prep+"_"+flow,ap,"mean");target=-float(row["mean_inward_acceleration_curvature_kms2_per_kpc_per_Myr2"])
        gate("frozen_flux",k,float(sref[k]["radial"])-target,target)
    weak=mapping(HERE/"weak-20-small.csv",ss)
    weaklo=mapping(HERE/"weak-12-small.csv",ss)
    for k,row in sref.items():
        expected=float(weak[k]["interior"]);gate("local_mass_moment_"+k[2],k,float(row["interior"])-expected,expected)
        gate("local_moment_quadrature",k,float(weaklo[k]["interior"])-expected,expected)
    groups={}
    for row in checks:
        group=groups.setdefault(row["test"],dict(total=0,miss=0,worst=0.))
        group["total"]+=1;group["miss"]+=int(not row["pass_005"]);group["worst"]=max(group["worst"],row["relative_error"])
    table("checks-"+final+".csv",checks);rec("scores-"+final+".json",groups)
    for key,val in groups.items():
        print(key,val["miss"],val["total"],round(100*val["worst"],6))
if __name__=="__main__":audit(sys.argv[1],sys.argv[2:])
