from base import *

def probes():
    points=[("centre",CENTER)]
    for shell in range(1,4):
        for name,vec in (("R",(1,0,0)),("z",(0,0,1)),("azimuth",(0,1,0)),("diagonal",(1,1,1))):
            for sign in (-1,1):
                points.append((f"{name}:{sign}:{shell}",CENTER+shell*SIZE*sign*np.array(vec)/np.linalg.norm(vec)))
    return points
def source(order,stellar=False):
    import sources
    sources.table=lambda name,data:table("source-gains.csv",data)
    if stellar:
        with np.load(HERE/"stellar-input.npz") as saved:xyz=saved["pos"]
    else:
        labels,positions=zip(*probes());xyz=np.stack(positions)
    rr=np.hypot(*xyz[:,:2].T)
    p=np.column_stack((rr,xyz[:,2]))
    group=sources.info();opt=np.array([-.015,-.002,0,.002,.015])
    a=sources.integrate(p,p,order,group,shifts=opt,acceleration=True)[0]
    phi=sources.integrate(p,p,order,group,shifts=opt)[0]
    prefix="stars-" if stellar else ""
    packet(f"{prefix}direct-{order}.npz",pos=xyz,acc=np.column_stack((xyz[:,:2]*(a[:,0]/rr)[:,None],a[:,1])),phi=phi)
def compare(order,angular_order,limit,q,stellar=False):
    from response import Evaluate
    lat=Evaluate(order,angular_order,limit,("small",14,32))
    prefix="stars-" if stellar else ""
    with np.load(HERE/f"{prefix}direct-{q}.npz") as bank:
        pos,acc,phi=bank["pos"],bank["acc"],bank["phi"]
    a=acc-lat.old.components(0,pos)[0]/CONV**2
    r=np.linalg.norm(pos,axis=1);old=(lat.mat.radial(r,(586,590),0,0)[0]*lg.legvander(pos[:,2]/r,68)[:,::2]).sum(axis=1)
    delta=phi-old
    def read(points,vals):
        assert np.array_equal(points,pos)
        return vals
    lat.phizero=delta[0];lat.delta0=a[0];lat.potential=lambda p:read(p,delta);lat.acc=lambda p:read(p,a)
    data=lat.evaluate(pos);out=[]
    if stellar:
        with np.load(HERE/"stellar-input.npz") as stars:
            assert np.array_equal(pos,stars["pos"])
            speed,which,meta=stars["velocity"],stars["indices"],stars["keys"]
        for j,key in enumerate(KEYS):
            for i,(vx,ix,tags) in enumerate(zip(speed,which,meta)):
                fixed,moving_frame=data[j,ix]-data[j,0]
                out.append(dict(state=key,star=i,shell=tags[0],axis=tags[1],side=tags[2],tangent=tags[3],sense=tags[4],
                       energy_third=vx@fixed,frame_extra=vx@moving_frame,
                       fixed_x=fixed[0],fixed_y=fixed[1],fixed_z=fixed[2]))
        table(f"stellar-work-{order}-{angular_order}-{limit}-{q}{SUFFIX}.csv",out)
        return
    for j,key in enumerate(KEYS):
        for i,(label,site) in enumerate(probes()):
            assert np.array_equal(site,pos[i]);fix,trans=data[j,i]
            recrow=dict(state=key,point=label)
            for name,values in (("fixed",fix),("translation",trans),("moving",fix+trans),("relative",fix+trans-data[j,0].sum(axis=0))):
                recrow.update({name+"_"+k:v for k,v in zip("xyz",values)})
            out.append(recrow)
    table(f"points-{order}-{angular_order}-{limit}-direct-{q}{SUFFIX}.csv",out)
if __name__=="__main__":
    stellar=sys.argv[1]=="stars"
    values=list(map(int,sys.argv[2:] if stellar else sys.argv[1:]))
    if len(values)==1:source(*values,stellar=stellar)
    else:compare(*values,stellar=stellar)
