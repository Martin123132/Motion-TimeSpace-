from response import *
from wave_response import sphere
import itertools
MOMENTS=(("mean",0,(1,0,0)),("dip_R",1,(1,0,0)),("dip_z",1,(0,0,1)),
         ("quad_R",2,(1,0,0)),("quad_phi",2,(0,1,0)),("quad_z",2,(0,0,1)),("quad_Rz",2,(2**-.5,0,2**-.5)))
def harmonics(normals):
    for name,degree,vector in MOMENTS:
        pole=np.array(vector);cosine=normals@pole
        if degree==0:shape=np.ones_like(cosine);slope=0.
        elif degree==1:shape=cosine;slope=1.
        else:shape=(3*cosine**2-1)/2;slope=3*cosine[:,None]
        yield name,degree,shape,slope*(pole-cosine[:,None]*normals)

def measure(order,muorder,limit,mode,angle):
    patch=("small",14,32) if mode=="small" else ("chart",12,48)
    operator=Evaluate(order,muorder,limit,patch);tag=f"{order}-{muorder}-{limit}-{mode}-{angle}"
    points=[("centre",CENTER)]
    for shell in range(1,4):
        for name,vec in (("R",(1,0,0)),("z",(0,0,1)),("azimuth",(0,1,0)),("diagonal",(1,1,1))):
            for sign in (-1,1):
                direction=np.array(vec)/np.linalg.norm(vec)
                points.append((f"{name}:{sign}:{shell}",CENTER+shell*SIZE*sign*direction))
    values=operator.evaluate(np.stack([v for _,v in points]))
    out=[]
    for state,key in enumerate(KEYS):
        for i,(label,_) in enumerate(points):
            fixed,translation=values[state,i]
            total=fixed+translation
            record=dict(state=key,point=label)
            for name,arr in (("fixed",fixed),("translation",translation),("moving",total),("relative",total-values[state,0].sum(axis=0))):
                record.update({name+"_"+coord:val for coord,val in zip("xyz",arr)})
            out.append(record)
    table(f"points-{tag}.csv",out)
    sums=[]
    for shell in range(1,4):
        uv,weights=sphere(shell*SIZE,CENTER,operator.wave.right,angle)
        pos=CENTER+shell*SIZE*uv
        data=np.concatenate([operator.evaluate(p).sum(axis=2) for p in np.array_split(pos,(len(pos)+127)//128)],axis=1)
        radial=np.einsum("spj,pj->sp",data,uv)
        for name,ell,h,der in harmonics(uv):
            gr=(2*ell+1)*(radial@(weights*h))
            gt=(2*ell+1)*np.einsum("spj,pj,p->s",data,der,weights)/(ell*(ell+1)) if ell else np.zeros_like(gr)
            for key,v,w in zip(KEYS,gr,gt):
                sums.append(dict(state=key,shell=shell,harmonic=name,degree=ell,radial=v,tangential=w,interior=v-ell*w))
    table(f"surface-{tag}.csv",sums)
if __name__=="__main__":measure(int(sys.argv[1]),int(sys.argv[2]),int(sys.argv[3]),sys.argv[4],int(sys.argv[5]))
