from base import *
from moments import Grid
from scipy.interpolate import CubicSpline

def build(order,angular,limit):
    import sources
    sources.table=lambda name,data: table("source-gains.csv",data)
    faces,shells,gains=sources.info();orig=sources.prior.original;src=sources.prior.source
    with np.load(prior("mesh.npz")) as mesh: edges=mesh["right"]
    centre=np.linalg.norm(CENTER)
    edges=np.unique(np.r_[0.,np.geomspace(.001,edges[-1],228),src.stars.centres,src.radknots,1.,25.,30.,160.,160*np.sqrt(2),edges,
                 shells[(shells>0)&(shells<edges[-1])],centre+np.arange(-12,13)*.01])
    edges=edges[(edges>=0)&(edges<=mesh_end())];edges=edges[np.r_[True,np.diff(edges)>1e-9]]
    grid=Grid(edges,order)
    bounds=np.unique(np.r_[0.,1.,np.sin(np.linspace(0,np.pi/2,41)),np.geomspace(.00001,.12,19),faces])
    bounds=bounds[np.r_[True,np.diff(bounds)>1e-13]]
    anglegrid=Grid(bounds,angular);mu=anglegrid.r.ravel();weights=(anglegrid.width[:,None]*anglegrid.w/2).ravel()
    degree=np.arange(0,limit+1,2)
    basis=(lg.legvander(mu,limit)[:,::2]*weights[:,None])*(2*degree+1)
    az,aw=sources.quadrature(np.array([0.,np.pi/2]),32);aw*=2/np.pi
    cg=np.linspace(0.,30.,15001);spline=CubicSpline(cg,orig.columns(cg),axis=0)
    coefficients=np.zeros((*grid.r.shape,len(degree)))
    for idx,r in enumerate(grid.r.ravel()):
        if idx%100==0:guard()
        if r>=160*np.sqrt(2):continue
        cyl=r*np.sqrt(1-mu**2);alt=r*mu
        cols=spline(np.minimum(30.,cyl))*(cyl<30)[:,None];donors=orig.supply(cyl);shares=donors/np.maximum(1e-25,donors.sum(axis=1))[:,None]
        density=src.disk(cyl,alt)+sum(v*orig.zshape(k,alt) for k,v in zip(orig.ls.S22,cols.T))-cols.sum(axis=1)*sum(shares[:,k]*src.starshape(alt,k) for k in range(4))
        density+=src.stars.bmass*(orig.ls.old.density("E3",(.67,.29,.27),cyl[:,None]*np.cos(az),cyl[:,None]*np.sin(az),alt[:,None])@aw)
        gain=gains[0,np.searchsorted(shells,r,side="right")-1,np.searchsorted(faces[1:-1],mu)]
        density*=((cyl<=160)&(alt<=160))*(1+np.clip((30-r)/5,0,1)*(gain-1))
        assert density.min()>=0
        coefficients.reshape(-1,len(degree))[idx]=density@basis
    inside,outside=grid.integrals(degree,grid.r[:,:,None]*coefficients,grid.r[:,:,None]*coefficients)
    phi=-4*np.pi*G*(inside+outside)/(2*degree+1)
    with np.load(prior("spherical-12-1.npz")) as old:
        target=old["probe"];mag=np.hypot(*target.T)
        check=grid.interpolate(phi,mag[:-1])[:,:35]
        ref=old["probe_phi"][:-1,:,0];diff=np.linalg.norm(check-ref)/np.linalg.norm(ref)
        mass=np.sum(4*np.pi*(grid.width[:,None]*grid.w/2)*grid.r**2*coefficients[:,:,0])
        print("mass/change vs q12",mass,mass/old["mass"][0]-1,"potential l<=68",diff,flush=True)
    packet(f"source-{order}-{angular}-{limit}.npz",edges=edges,phi=phi,degree=degree,mass=mass,lower_mode_reference=diff)

def mesh_end():
    with np.load(prior("mesh.npz")) as mesh:return mesh["right"][-1]
if __name__=="__main__":build(*map(int,sys.argv[1:]))
