from scores import *
def main():
    results=[]
    for tabletype,fields,metrics in (("sphere-energy",("state","shell","h_pc"),("energy_fourth","extra_wave_work_fourth")),
                                    ("paired-energy",("state","star_plus","h_pc"),("cluster_energy_fourth","new_wave_work_fourth"))):
        files=["12-15-612-18-small","12-15-612-14-small","12-15-476-14-small","9-12-476-14-small","12-15-612-14-small-wave140","12-15-612-14-chart"]
        packs=[mapping(HERE/(tabletype+"-"+name+".csv"),fields) for name in files]
        for k,row in packs[0].items():
            if k[2]!="0.3":continue
            for name in metrics:
                values=np.array([float(pack[k][name]) for pack in packs]);expected=values[0]
                assert expected!=0
                errors={"source":abs(values[1]/expected-1),"angular":abs(values[2]/values[1]-1),"global_grid":abs(values[3]/values[1]-1),
                      "preparation":abs(values[4]/values[1]-1),"gradient_chart":abs(values[5]/values[1]-1),
                      "gradient_step":abs(float(packs[0][k[:2]+("0.6",)][name])/expected-1)}
                results.append(dict(observable=name,state=k[0],site=k[1],coefficient=expected,
                     supported=max(errors.values())<=.005,worst=max(errors.values()),limiter=max(errors,key=errors.get),errors=json.dumps(errors)))
    table("paired-stellar-verdict.csv",results)
    groups={}
    for row in results:
        group=groups.setdefault(row["observable"],dict(total=0,pass_count=0,worst=0.,minimum=float("inf"),maximum=-float("inf")))
        group["total"]+=1;group["pass_count"]+=int(row["supported"]);group["worst"]=max(group["worst"],row["worst"])
        group["minimum"]=min(group["minimum"],row["coefficient"]);group["maximum"]=max(group["maximum"],row["coefficient"])
    rec("paired-stellar-summary.json",groups)
if __name__=="__main__":main()
