from observe import MOMENTS,harmonics
from base import *
from wave_response import Density,sphere
from local_release_field import LocalField
def calculate(q,chart):
    wave=Density();material,old=geometry()
    field=LocalField("chart",12,48) if chart else LocalField("small",14,32)
    delta0=field.force(0,CENTER[None,:])[0]*CONV**2-old.components(0,CENTER[None,:])[0][0]
    splits=np.unique(np.r_[material.right,wave.right*wave.length])
    indices=[list(wave.states).index(key+"_280") for key in KEYS]
    def score(radius):
        directions,weights=sphere(radius,CENTER,splits,q)
        xyz=CENTER+radius*directions
        rho=wave(xyz)[indices]
        d=field.force(0,xyz)*CONV**2-old.components(0,xyz)[0]-delta0
        fn=np.sum(d*directions,axis=1)
        values=[]
        for name,ell,h,der in harmonics(directions):
            surf=rho@(weights*h*fn)
            volume=rho@(weights*(ell*h*fn+np.sum(der*d,axis=1)))
            values.append((surf,volume))
        return np.array(values)
    out=[];mag=np.linalg.norm(CENTER);degrees=np.array([k[1] for k in MOMENTS])
    for shell in (1,2,3):
        A=shell*SIZE;boundary=score(A)[:,0];vol=np.zeros_like(boundary)
        offsets=abs(splits-mag)/A
        pieces=np.unique(np.r_[0,offsets[(offsets>0)&(offsets<1)],1.])
        nd,wt=gauss(q)
        for lo,hi in zip(pieces[:-1],pieces[1:]):
            for node,weight in zip(nd,wt):
                u=lo+(1+node)*(hi-lo)/2
                vol+=(weight*(hi-lo)/2*u**(degrees+1))[:,None]*score(A*u)[:,1]
        prediction=(4*np.pi*G*(2*degrees+1))[:,None]*(boundary-vol)
        for (name,ell,_),row in zip(MOMENTS,prediction):
            for key,val in zip(KEYS,row):
                out.append(dict(state=key,shell=shell,harmonic=name,degree=ell,interior=val))
    table(f"weak-{q}-"+("chart" if chart else "small")+".csv",out)
if __name__=="__main__":calculate(int(sys.argv[1]),int(sys.argv[2]))
