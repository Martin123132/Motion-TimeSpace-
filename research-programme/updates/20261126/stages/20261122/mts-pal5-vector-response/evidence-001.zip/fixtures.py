from base import *
def run():
    if sys.argv[1]=="wave":
        packet("full-wave"+SUFFIX+".npz",**waves(STEPS));return
    from wave_response import archived
    xyz,velocity,keys=archived.probes()
    with np.load(previous.pin(previous.WORK,"hist-4-2-A-reset_forward.npz")) as original:
        centre=original["centre"][0,:3]
    er=np.r_[centre[:2]/np.hypot(*centre[:2]),0.];ep=np.array([-er[1],er[0],0.])
    rotation=np.stack((er,ep,[0.,0.,1.])).T
    assert np.allclose(centre@rotation,CENTER)
    offsets=xyz@rotation;v=velocity@rotation
    unique,idx=np.unique(offsets,axis=0,return_inverse=True)
    packet("stellar-input.npz",pos=np.vstack((CENTER,CENTER+unique)),indices=idx+1,velocity=v,keys=np.asarray(keys))
if __name__=="__main__":run()
