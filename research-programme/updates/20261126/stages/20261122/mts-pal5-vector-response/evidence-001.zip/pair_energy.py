from scores import *
from response import Evaluate
from wave_response import archived

def derivatives(op,pos,v,h):
    norm=np.linalg.norm(v,axis=1)
    radial=np.linalg.norm(pos,axis=1)
    nearest=np.abs(radial[:,None]-op.wave.right[None,:]).min(axis=1)
    step=np.minimum(h,.2*nearest)
    assert np.min(step)>1e-8
    delta=v*(step/norm)[:,None]
    plus=op.evaluate(pos+delta)[:,:,0]
    minus=op.evaluate(pos-delta)[:,:,0]
    return np.einsum("siq,iq->si",plus-minus,v)*(norm/(2*step))[None,:]
def run(order,angular_order,limit,newton,chart):
    option=("chart",12,48) if chart else ("small",14,32)
    op=Evaluate(order,angular_order,limit,option);mode=option[0]
    with np.load(HERE/"stellar-input.npz") as data:
        pos=data["pos"];which=data["indices"];meta=data["keys"];speed=data["velocity"]
    with np.load(HERE/f"stars-direct-{newton}.npz") as new:
        assert np.array_equal(pos,new["pos"])
        baryon=(new["acc"][which]-new["acc"][0])*CONV**2
    wave={}
    for prep in ("reset","coupled"):
        initial=archived.load(2 if STEPS==140 else 4,2,prep)[:1]
        for flow in ("forward","reverse"):
            _,g=archived.make(initial,op.mat,flow)[0].components(0,pos)
            wave[prep+"_"+flow]=g[which]-g[0]
    dx=pos[which]-pos[0];cluster=-archived.GM*dx/(np.sum(dx**2,axis=1)+archived.SIZE**2)[:,None]**1.5
    starset=mapping(HERE/f"stellar-work-{order}-{angular_order}-{limit}-{newton}{SUFFIX}.csv",("state","star"))
    out=[];summary=[]
    for h_pc in (1.2,.6,.3):
        gradient=derivatives(op,pos[which],speed,.001*h_pc)
        for j,key in enumerate(KEYS):
            difference=np.stack([vector(starset[key,str(i)],"fixed") for i in range(len(which))])
            bext=baryon+wave[key]
            dot=lambda x:np.sum(x*difference,axis=1)
            explicit=3*(dot(cluster+bext)+gradient[j])
            total=explicit+dot(bext)
            assert np.allclose(explicit[::2],explicit[1::2],rtol=1e-10,atol=1e-24)
            for i,tag in enumerate(meta):
                if tag[4]!=1:continue
                out.append(dict(state=key,star_plus=i,star_minus=i-1,shell=tag[0],axis=tag[1],side=tag[2],tangent=tag[3],
                      h_pc=h_pc,gradient_term=3*gradient[j,i],new_wave_work_fourth=explicit[i],existing_force_work_fourth=dot(bext)[i],cluster_energy_fourth=total[i]))
            for sh in (1,2,3):
                mask=meta[:,0]==sh
                summary.append(dict(state=key,shell=sh,h_pc=h_pc,energy_fourth=total[mask].mean(),extra_wave_work_fourth=explicit[mask].mean()))
    tag=f"{order}-{angular_order}-{limit}-{newton}-{mode}{SUFFIX}"
    table("paired-energy-"+tag+".csv",out);table("sphere-energy-"+tag+".csv",summary)
if __name__=="__main__":run(*map(int,sys.argv[1:]))
