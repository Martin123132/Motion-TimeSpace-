from scores import *
import itertools
def audit():
    checks=[]
    def compare(name,k,value,target):
        rel=abs(value-target)/abs(target) if target else (float(0) if value==target else None)
        checks.append(dict(check=name,case=":".join(k),absolute=abs(value-target),relative=rel,passes=abs(value-target)<=.005*abs(target)))
    fields=("state","shell","harmonic","boundary_route");final=mapping(HERE/"matched-12-15-612-small-3.5-28.csv",fields)
    for filename in sorted(HERE.glob("matched-[0-9]*.csv")):
        alt=mapping(filename,fields)
        for k,row in final.items():
            if k[-1]!="potential":continue
            for n in ("radial","tangential"):
                if n=="tangential" and row["degree"]=="0":continue
                compare(filename.stem+"_"+n,k,float(alt[k][n]),float(row[n]))
    for k,row in final.items():
        if k[-1]!="potential":continue
        for n in ("radial","tangential"):
            if n=="tangential" and row["degree"]=="0":continue
            compare("use_boundary_force_instead_"+n,k,float(final[(*k[:-1],"radial_force")][n]),float(row[n]))
    weak=mapping(HERE/"weak-32-small.csv",fields[:3])
    coarse=mapping(HERE/"weak-20-small.csv",fields[:3]);old=mapping(HERE/"surface-12-15-612-small-24.csv",fields[:3])
    for k,row in weak.items():
        target=float(row["interior"])
        compare("weak_20_to_32",k,float(coarse[k]["interior"]),target)
        compare("transfer_interior_identity",k,float(final[(*k,"potential")]["interior"]),target)
        compare("raw_interior_"+k[2],k,float(old[k]["interior"]),target)
    idx=("state","point","method")
    base=mapping(HERE/"lapse-12-15-612-direct-14.csv",idx)
    saved=("12-15-612-direct-14","12-15-612-direct-10","12-15-476-direct-14","9-12-476-direct-14","12-15-612-small-12","12-15-612-chart-12")
    for tag in sorted(saved):
        path=HERE/("lapse-"+tag+".csv")
        alt=mapping(path,idx)
        for k,row in alt.items():
            for n in ("fixed_tidal_lapse","moving_tidal_lapse"):
                target=float(base[(k[0],k[1],"scalar")][n])
                compare(path.stem+"_"+k[2]+"_"+n,k,float(row[n]),target)
                if k[2]!="scalar":
                    compare(path.stem+"_integral_identity_"+k[2]+"_"+n,k,float(row[n]),float(alt[(k[0],k[1],"scalar")][n]))
    table("matched-boundary-and-metric-checks.csv",checks)
    sums={}
    for row in checks:
        g=sums.setdefault(row["check"],dict(total=0,miss=0,worst=0.));g["total"]+=1;g["miss"]+=int(not row["passes"]);g["worst"]=max(g["worst"],row["relative"] or 0.)
    rec("matched-boundary-and-metric-verdict.json",sums)
if __name__=="__main__":audit()
