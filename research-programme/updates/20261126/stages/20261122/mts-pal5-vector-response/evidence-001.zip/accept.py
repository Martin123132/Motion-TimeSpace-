from scores import *
BASE="12-15-612"
def run():
    cases=[];summary={}
    def score(group,k,target,estimates):
        errs={}
        for label,(value,ref) in estimates.items():
            d=float(np.linalg.norm(value-ref));base=float(np.linalg.norm(ref))
            errs[label]=d/base if base else (0. if d==0 else float("inf"))
        assert all(np.isfinite(list(errs.values())))
        passing=max(errs.values())<=.005
        cases.append(dict(observable=group,state=k[0],site=k[1],magnitude=float(np.linalg.norm(target)),supported=passing,
                          peak_relative=max(errs.values()),limiter=max(errs,key=errs.get),details=json.dumps(errs,sort_keys=True)))
        g=summary.setdefault(group,dict(total=0,supported=0,worst=0.))
        g["total"]+=1;g["supported"]+=int(passing);g["worst"]=max(g["worst"],max(errs.values()))
    def sets(fmt,fields):
        keys=[BASE+"-18",BASE+"-14","12-15-476-14","9-12-476-14",BASE+"-14-wave140"]
        return [mapping(HERE/fmt(i),fields) for i in keys]
    def estimates(values):
        end,hi,lo,other,short=values
        return {"direct_14_to_18":(hi,end),"angular_476_to_612":(lo,hi),"global_grid_and_modes":(other,hi),"wave_140_to_280":(short,hi)}
    def pointfile(tag):
        parts=tag.split("-");return "points-"+"-".join(parts[:3]+["direct"]+parts[3:])+".csv"
    points=sets(pointfile,("state","point"))
    for k in points[0]:
        for group in ("fixed","moving","relative","fixed_relative"):
            if k[1]=="centre" and "relative" in group:continue
            vals=[vector(p[k],group) if group!="fixed_relative" else vector(p[k],"fixed")-vector(p[k[0],"centre"],"fixed") for p in points]
            score("probe_"+group,k,vals[0],estimates(vals))
    stars=sets(lambda k:"stellar-work-"+k+".csv",("state","star"))
    for k in stars[0]:
        for group in ("star_vector","individual_work","forward_minus_reverse"):
            if group=="forward_minus_reverse" and not k[0].endswith("forward"):continue
            vals=[]
            for pack in stars:
                row=pack[k]
                val=vector(row,"fixed") if group=="star_vector" else float(row["energy_third"])
                if group=="forward_minus_reverse":val-=float(pack[(k[0].replace("forward","reverse"),k[1])]["energy_third"])
                vals.append(val)
            score(group,k,vals[0],estimates(vals))
    readout=[]
    for key in KEYS:
        for sh in range(1,4):
            vals=[];means=[];maxima=[]
            for pack in stars:
                sel=[float(row["energy_third"]) for (state,i),row in pack.items() if state==key and int(row["shell"])==sh]
                assert len(sel)==24
                vals.append(np.linalg.norm(sel)/np.sqrt(24));means.append(np.mean(sel));maxima.append(max(abs(np.array(sel))))
            assert np.max(abs(np.array(means)))<1e-20
            score("ensemble_work_rms",(key,str(sh)),vals[0],estimates(vals))
            readout.append(dict(state=key,shell=sh,mean=means[0],rms=vals[0],peak_abs=maxima[0],passes=cases[-1]["supported"]))
    table("direct-stellar-summary.csv",readout)
    def lapsefile(tag):return pointfile(tag).replace("points-","lapse-")
    idx=("state","point","method")
    clocks=sets(lapsefile,idx)
    patch=mapping(HERE/"lapse-12-15-612-small-12.csv",idx)
    for k in clocks[0]:
        for name in ("fixed_tidal_lapse","moving_tidal_lapse"):
            vals=[float(c[k][name]) for c in clocks];comp=estimates(vals)
            comp["straight_from_force"]=(float(patch[k[0],k[1],"straight"][name]),vals[0])
            if k[1].startswith("diagonal"):
                comp["different_path"]=(float(patch[k[0],k[1],"bent"][name]),vals[0])
            score(name,k[:2],vals[0],comp)
    table("acceptance-by-observable.csv",cases);rec("acceptance.json",summary)
if __name__=="__main__":run()
