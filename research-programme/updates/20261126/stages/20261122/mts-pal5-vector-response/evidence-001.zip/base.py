from pathlib import Path
import sys, os, json, csv, io, hashlib
for key in ("OPENBLAS_NUM_THREADS","OMP_NUM_THREADS","MKL_NUM_THREADS","NUMEXPR_NUM_THREADS","BLIS_NUM_THREADS"):
    os.environ[key]="1"
import numpy as np
from scipy.special import roots_legendre
from numpy.polynomial import legendre as lg
from functools import lru_cache
HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
LIVE=ROOT/"mts-pal5-live-wave-coupling-20261122"
RELEASE=ROOT/"mts-pal5-release-evolution-20261122"
lock="e3179448aeee4c8d65d82377cab0f358820d43eb08c00c6935a2045c92cc2314"
def digest(path):
    with path.open("rb") as stream: return hashlib.file_digest(stream,"sha256").hexdigest()
assert digest(LIVE/"seal.json")==lock
def prior(name):
    assert digest(LIVE/name)==json.loads((LIVE/"seal.json").read_bytes())[name]
    return LIVE/name
prior("run_io.py"); sys.path.insert(0,str(LIVE))
import run_io as previous
previous.pin(RELEASE,"wave_response.py"); previous.pin(RELEASE,"local_release_field.py")
sys.path.insert(0,str(RELEASE))
from types import SimpleNamespace
G=4.30091727003628e-6
CONV=1/977.7922216807892
with np.load(prior("spherical-12-1.npz")) as saved:
    plane,height=saved["probe"][0]
CENTER=np.array([plane,0.,height]);SIZE=20.6*np.tan(np.deg2rad(3.21/60))
KEYS=("reset_forward","reset_reverse","coupled_forward","coupled_reverse")
def guard():
    previous.guard()
    assert not (HERE/"STOP-REQUESTED").exists()
def write(name,data):
    path=HERE/name
    if path.exists(): assert path.read_bytes()==data,name
    else:
        with path.open("xb") as stream: stream.write(data)
def table(name,records):
    stream=io.StringIO(); writer=csv.DictWriter(stream,list(records[0]),lineterminator="\n"); writer.writeheader();writer.writerows(records);write(name,stream.getvalue().encode())
def packet(name,**arrays):
    stream=io.BytesIO();np.savez_compressed(stream,**arrays);write(name,stream.getvalue())
def rec(name,obj):
    write(name,(json.dumps(obj,sort_keys=True,indent=2,allow_nan=False)+"\n").encode())
gauss=lru_cache(None)(roots_legendre)
def geometry():
    from wave_response import archived
    material=archived.Material()
    field=archived.Field(SimpleNamespace(end=88.968349,rad=np.array([2.,35.])),material,(586,590),"ordinary")
    return material,field
def waves(steps=280):
    previous.pin(previous.PREP,f"states-586-{steps}.npz")
    lab,*_=previous.setup()
    with np.load(previous.PREP/f"states-586-{steps}.npz") as data:
        elements={key:lab.run.el.nodes(data[key]) for key in KEYS}
    with np.load(previous.pin(RELEASE,"wave-elements.npz")) as local:
        scale=float(local["length"]);mask=(lab.run.el.right*scale>=8.12)&(lab.run.el.left*scale<=8.48)
        assert all(np.array_equal(local[f"{key}_{steps}"],v[mask]) for key,v in elements.items())
    return elements
guard()
STEPS=int(os.environ.get("MTS_VECTOR_PREPARATION_STEPS","280"))
assert STEPS in (140,280)
SUFFIX="-wave140" if STEPS==140 else ""
