from base import *
from moments import Grid,controls as power_control
def test():
    grid=Grid(np.r_[0.,np.geomspace(.002,1.,40),1.2,1.5,2.],9)
    r=grid.r.ravel(); rho=np.maximum(1-r*r,0.)**3
    deriv=-6*r*np.maximum(1-r*r,0.)**2
    mu,wt=gauss(16); pol=lg.legvander(mu,4)
    slope=-(np.sqrt(1-mu**2)[:,None])*np.stack([lg.legval(mu,lg.legder(v)) for v in np.eye(5)],axis=1)
    state=[];modes=np.arange(5);proj=wt[:,None]*pol*((2*modes+1)/2)
    for degree,gauge in ((1,0.),(2,0.),(2,7.)):
        ell=degree
        potential=r[:,None]**ell*pol[:,ell]+gauge
        radial=((potential*deriv[:,None])@proj).reshape(*grid.r.shape,-1);zero=np.zeros_like(radial)
        ii,ee=grid.integrals(modes,radial,radial)
        rr=(-modes*(modes+1)/(2*modes+1)*(ii+ee)/grid.r[:,:,None]).reshape(len(r),-1)
        tt=((modes*ii-(modes+1)*ee)/((2*modes+1)*grid.r[:,:,None])).reshape(len(r),-1)
        fixed_r=-rho[:,None]*ell*r[:,None]**(ell-1)*pol[:,ell]+rr@pol.T
        fixed_t=-rho[:,None]*r[:,None]**(ell-1)*slope[:,ell]+tt@slope.T
        I=np.zeros_like(r);E=np.zeros_like(r);u=np.minimum(1.,r)
        for offset,co in enumerate((-6.,12.,-6.)):
            exponent=ell+2*offset
            I+=ell*co*u**(exponent+ell+3)/(exponent+ell+3)
            E+=ell*co*(1-u**(exponent-ell+2))/(exponent-ell+2)
        I/=r**(ell+1);E*=r**ell
        exact_r=(ell*E-(ell+1)*I)/((2*ell+1)*r)
        exact_t=(I+E)/((2*ell+1)*r)
        radial_error=np.max(abs(fixed_r-exact_r[:,None]*pol[:,ell]))
        tangent_error=np.max(abs(fixed_t-exact_t[:,None]*slope[:,ell]))
        exterior=np.max(abs(fixed_r[r>1]-exact_r[r>1,None]*pol[:,ell]))
        state.append(dict(degree=degree,gauge=gauge,radial_error=radial_error,tangent_error=tangent_error,exterior_error=exterior,exterior_signal=np.max(abs(fixed_r[r>1]))))
        if ell==1:
            dpsi=sum(coeff*u**(n+3)/(n+3) for n,coeff in [(0,1),(2,-3),(4,3),(6,-1)])/r**2
            shift_r=(rho-2*dpsi/r)[:,None]*mu
            shift_t=(dpsi/r)[:,None]*slope[:,1]
            assert max(np.max(abs(fixed_r+shift_r)),np.max(abs(fixed_t+shift_t)))<1e-9
    assert max(max(row[k] for k in ("radial_error","tangent_error","exterior_error")) for row in state)<1e-9
    assert all(row["exterior_signal"]>1e6*max(1e-15,row["exterior_error"]) for row in state)
    assert max(power_control())<1e-12
    table("manufactured.csv",state)
if __name__=="__main__": test()
