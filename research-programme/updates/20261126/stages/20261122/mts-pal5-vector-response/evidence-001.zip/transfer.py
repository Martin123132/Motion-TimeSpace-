from observe import *
from wave_response import Density
def run(boundary,q,order,angular_order,limit,boundary_mode):
    patch=("small",14,32) if boundary_mode=="small" else ("chart",12,48)
    operator=Evaluate(order,angular_order,limit,patch)
    wave=Density();resolved=LocalShell(wave)
    degrees=np.array([v[1] for v in MOMENTS]);nonzero=degrees>0
    cut=np.unique(np.r_[0.,1.,2.,3.,boundary,np.abs(resolved.splits-np.linalg.norm(CENTER))/SIZE])
    cut=cut[(cut>=0)&(cut<=boundary)]
    sums_i=[];sums_e=[];nd,wt=gauss(q)
    for lo,hi in zip(cut[:-1],cut[1:]):
        inn=np.zeros((len(degrees),4));ext=inn.copy()
        for node,wgt in zip(nd,wt):
            u=lo+(node+1)*(hi-lo)/2
            ar,bt=resolved.score(u,q)
            inn+=(wgt*(hi-lo)/2*u**(degrees+1))[:,None]*(ar+(degrees+1)[:,None]*bt)
            if lo>=1.:
                ext+=(wgt*(hi-lo)/2*u**(-degrees))[:,None]*(ar-degrees[:,None]*bt)
        sums_i.append(inn);sums_e.append(ext)
    sums_i=np.array(sums_i);sums_e=np.array(sums_e)
    h=degrees[:,None]
    uv,wt=sphere(boundary*SIZE,CENTER,resolved.splits,q);pos=CENTER+boundary*SIZE*uv
    data=np.concatenate([operator.evaluate(block).sum(axis=2) for block in np.array_split(pos,(len(pos)+127)//128)],axis=1)
    radial=np.einsum("spj,pj->sp",data,uv)
    gb=np.array([(2*l+1)*(radial@(wt*poly)) for name,l,poly,der in harmonics(uv)])
    tb=np.array([(2*l+1)*np.einsum("spj,pj,p->s",data,der,wt)/(l*(l+1)) if l else np.zeros(4) for name,l,poly,der in harmonics(uv)])
    ib=sums_i.sum(axis=0)/boundary**(h+1);ab,_=resolved.score(boundary,q)
    fac=4*np.pi*G
    db=fac*(ab-h*ib/boundary)
    tb_alt=np.divide(gb-db,h,out=np.zeros_like(tb),where=h!=0)
    out=[]
    for which,observed in (("potential",tb),("radial_force",tb_alt)):
        eb=(h*ib-(2*h+1)*boundary*observed/fac)/(h+1)
        boundary_external=observed+db/(2*h+1)
        for shell in (1,2,3):
            inside=sums_i[cut[1:]<=shell].sum(axis=0)/shell**(h+1)
            outside=(shell/boundary)**h*eb+shell**h*sums_e[cut[:-1]>=shell].sum(axis=0)
            ar,_=resolved.score(shell,q)
            gr=fac*(ar-h*(h+1)/(2*h+1)*(inside+outside)/shell)
            gt=fac*(h*inside-(h+1)*outside)/((2*h+1)*shell)
            for i,(name,degree,_) in enumerate(MOMENTS):
                for j,key in enumerate(KEYS):
                    ex=boundary_external[i,j]*(shell/boundary)**(degree-1) if degree else 0.
                    out.append(dict(state=key,shell=shell,harmonic=name,degree=degree,boundary_route=which,
                         radial=gr[i,j],tangential=gt[i,j] if degree else 0.,exterior_radial=degree*ex,exterior_tangential=ex,
                         interior=gr[i,j]-degree*gt[i,j],boundary_residual=gb[i,j]-degree*tb[i,j]-db[i,j]))
    table(f"matched-{order}-{angular_order}-{limit}-{boundary_mode}-{boundary:g}-{q}.csv",out)

class LocalShell:
    def __init__(self,wave):
        from local_release_field import LocalField
        self.wave=wave;self.indices=[list(wave.states).index(key+"_280") for key in KEYS]
        self.mat,self.old=geometry();self.field=LocalField("small",14,32)
        self.splits=np.unique(np.r_[self.mat.right,wave.right*wave.length])
        self.origin=self.field.force(0,CENTER[None,:])[0]*CONV**2-self.old.components(0,CENTER[None,:])[0][0]
    def score(self,u,q):
        uv,wt=sphere(u*SIZE,CENTER,self.splits,q);p=CENTER+u*SIZE*uv
        rho=self.wave(p)[self.indices]
        jump=self.field.force(0,p)*CONV**2-self.old.components(0,p)[0]-self.origin
        normal=np.sum(jump*uv,axis=1);aa=[];bb=[]
        for name,ell,h,der in harmonics(uv):
            aa.append((2*ell+1)*(rho@(wt*h*normal)))
            bb.append((2*ell+1)*(rho@(wt*np.sum(jump*der,axis=1)))/(ell*(ell+1)) if ell else np.zeros(4))
        return np.array(aa),np.array(bb)
if __name__=="__main__":run(float(sys.argv[1]),*map(int,sys.argv[2:6]),sys.argv[6])
