from base import *
from scipy.integrate import solve_ivp

def manufactured():
    stiffness=.83
    def cluster(x):return -stiffness*x
    def ext(x,t):return .31+.22*x-.14*np.sin(t)*x
    def coeff(x):return .18+.62*x+.07*x**2
    centre=.23;bulk=-.19;offset=.67;speed=.47
    delta=coeff(centre+offset)-coeff(centre)
    external=ext(centre+offset,0)-ext(centre,0)
    accel=cluster(offset)+external
    third=speed*delta
    pure=3*(accel*delta+speed**2*(.62+.14*(centre+offset)))
    total=pure+external*delta
    results=[]
    for cubic in (-2.,3.):
        for t in (.04,.02,.01,.005):
            entries=[]
            for v in (-speed,speed):
                def eq(time,y):
                    pos=y[:2];vel=y[2:4];dx=y[4:6];dv=y[6:8]
                    new=pos+dx
                    acc=ext(pos,time);acc[1]+=cluster(pos[1]-pos[0])
                    feedback=.5*time*time*coeff(new)+(time**3/6)*cubic*(.14+new**2)
                    dacc=(.22-.14*np.sin(time))*dx+feedback;dacc[1]+=cluster(dx[1]-dx[0])
                    work=((vel[1]+dv[1])-(vel[0]+dv[0]))*(feedback[1]-feedback[0])
                    return np.r_[vel,acc,dv,dacc,work]
                initial=np.r_[centre,centre+offset,bulk,bulk+v,0.,0.,0.,0.,0.]
                answer=solve_ivp(eq,(0,t),initial,rtol=1e-12,atol=1e-24,method="DOP853")
                assert answer.success
                y=answer.y[:,-1];drel=y[5]-y[4];dvel=y[7]-y[6]
                change=(y[3]-y[2]+dvel/2)*dvel+stiffness*(y[1]-y[0]+drel/2)*drel
                entries.append((change,y[-1]))
            a,b=np.array(entries);odd=(b-a)*.5*6/t**3;even=(b+a)*.5*24/t**4
            results.append(dict(cubic=cubic,time=t,energy_third=odd[0],predicted_third=third,energy_fourth=even[0],predicted_energy_fourth=total,
                        wave_work_fourth=even[1],predicted_work_fourth=pure))
    for idx in (2,6):
        for field,expected in (("energy_third","predicted_third"),("energy_fourth","predicted_energy_fourth"),("wave_work_fourth","predicted_work_fourth")):
            a,b=results[idx:idx+2];assert abs((2*b[field]-a[field])/b[expected]-1)<.001
    table("manufactured-stellar-work.csv",results)
if __name__=="__main__":manufactured()
