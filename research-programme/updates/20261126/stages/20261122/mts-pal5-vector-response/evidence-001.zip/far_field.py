from response import *
def run():
    wave=Wave();deg=np.arange(0,69,2);nr,wr=gauss(48);mu,wt=gauss(96);pol=lg.legvander(mu,68)[:,::2]
    radius=(wave.left[:,None]+(wave.right-wave.left)[:,None]*(1+nr)/2).ravel()
    weights=((wave.right-wave.left)[:,None]*wr/2).ravel()
    outer=wave.right[-1]
    lat=Evaluate(12,15,612,("small",14,32))
    with np.load(HERE/"direct-14.npz") as data:acc=(data["acc"][0]-lat.old.components(0,CENTER[None,:])[0][0]/CONV**2)*CONV**2
    az=np.arange(32)*2*np.pi/32
    normals=np.stack(np.broadcast_arrays(np.sqrt(1-mu**2)[:,None]*np.cos(az),np.sqrt(1-mu**2)[:,None]*np.sin(az),mu[:,None]),axis=-1).reshape(-1,3)
    omega=np.repeat(wt/64,32)
    def far(points,coeff):
        r=np.linalg.norm(points,axis=1);unit=points/r[:,None];m=unit[:,2];pv,slope=safe_poly(m,68)
        amp=-G/r[:,None]*(outer/r[:,None])**deg*coeff
        vr=np.sum(-(deg+1)*amp*pv,axis=1)/r;vm=np.sum(amp*slope,axis=1)/r
        return -vr[:,None]*unit-vm[:,None]*(np.array([0,0,1])-m[:,None]*unit)
    rows_out=[]
    for key in KEYS:
        assert np.max(np.abs(wave.nodes[key][-1,-1]))==0
        amp,_=wave.coeff(key,radius);rho=abs(amp@pol[:,:18].T)**2
        moments=2*np.pi*np.sum((weights*radius**2)[:,None]*(radius/outer)[:,None]**deg*(rho@(wt[:,None]*pol)),axis=0)
        mass=moments[0];target=-mass*acc
        for r in (450.,800.):
            for step in (.02,.01):
                unit=acc/np.linalg.norm(acc);p=r*normals
                derivative=(far(p+step*unit,moments)-far(p-step*unit,moments))*np.linalg.norm(acc)/(2*step)
                signal=3*(omega*np.sum(derivative*normals,axis=1))@normals
                inferred=-r**3*signal/(2*G)
                error=np.linalg.norm(inferred-target)/np.linalg.norm(target)
                assert error<1e-7
                rows_out.append(dict(state=key,radius_kpc=r,translation_step_kpc=step,wave_mass_Msun=mass,
                    inertial_dipole=0.,moving_dipole_x=target[0],moving_dipole_z=target[2],recovered_x=inferred[0],recovered_z=inferred[2],relative_error=error))
    table("global-mass-and-dipole.csv",rows_out)
if __name__=="__main__":run()
