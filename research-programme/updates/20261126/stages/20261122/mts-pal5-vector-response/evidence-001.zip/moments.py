from base import np,lg,gauss

class Grid:
    def __init__(self,edges,order):
        self.edges=np.asarray(edges); self.width=np.diff(edges);self.nodes,self.w=gauss(order)
        self.r=(self.edges[:-1,None]+self.width[:,None]*(1+self.nodes)/2)
        self.inverse=np.linalg.inv(lg.legvander(self.nodes,order-1))
        self.order=order

    def interpolate(self,values,radii):
        radii=np.asarray(radii)
        idx=np.clip(np.searchsorted(self.edges,radii,side="right")-1,0,len(self.width)-1)
        assert min(radii)>=self.edges[0] and max(radii)<=self.edges[-1]
        pos=2*(radii-self.edges[idx])/self.width[idx]-1
        basis=lg.legvander(pos,self.order-1)@self.inverse
        return np.einsum("ti,ti...->t...",basis,values[idx])

    def integrals(self,degrees,inner,outer):
        assert inner.shape==outer.shape and inner.shape[:3]==(*self.r.shape,len(degrees))
        ndim=inner.ndim;length=len(degrees);order=self.order;nd,wt=gauss(max(12,order+3))
        alpha=(nd+1)/2; ends=np.r_[-1,self.nodes,1]; left=ends[:-1]; width=np.diff(ends)
        rule=lg.legvander((left[:,None]+width[:,None]*alpha).ravel(),order-1)@self.inverse
        final_i=np.zeros_like(inner);final_e=final_i.copy()
        total_i=[];total_e=[];chunks=32
        for start in range(0,len(self.width),chunks):
            selection=slice(start,start+chunks)
            hi=self.edges[1:][selection,None];lo=self.edges[:-1][selection,None]
            stop=np.concatenate((lo,self.r[selection],hi),axis=1)
            sizes=np.diff(stop)[:,:,None];s=stop[:,:-1,None]+sizes*alpha
            weight=sizes*(wt/2)
            def blocks(value,ratio,power):
                trailing=value.shape[3:];vect=value[selection].reshape(len(stop),order,-1)
                val=(rule@vect).reshape(len(stop),order+1,len(nd),length,-1)
                kern=weight[:,:,:,None]*ratio[:,:,:,None]**power
                return np.einsum("csql,csqlp->cslp",kern,val).reshape(len(stop),order+1,length,*trailing)
            total_i.append(blocks(inner,s/stop[:,1:,None],degrees+1))
            total_e.append(blocks(outer,stop[:,:-1,None]/s,degrees))
        ii=np.concatenate(total_i);ee=np.concatenate(total_e)
        stop=np.column_stack((self.edges[:-1],self.r,self.edges[1:]))
        ratios=stop[:,:-1]/stop[:,1:]
        fi=ratios[:,:,None]**(degrees+1);fe=ratios[:,:,None]**degrees
        index=(...,)+(None,)*(ndim-3);fi=fi[index];fe=fe[index]
        carry=np.zeros(inner.shape[2:])
        for cell in range(len(ii)):
            for j in range(order+1):
                carry=carry*fi[cell,j]+ii[cell,j]
                if j<order: final_i[cell,j]=carry
        carry=np.zeros_like(carry)
        for cell in reversed(range(len(ee))):
            for j in reversed(range(order+1)):
                carry=carry*fe[cell,j]+ee[cell,j]
                if j: final_e[cell,j-1]=carry
        return final_i,final_e

def controls():
    grid=Grid(np.r_[0.,np.geomspace(.002,1.,46)],8)
    ell=np.array([0,2,4,6])
    r=grid.r[:,:,None];power=ell+2
    first,last=grid.integrals(ell,r**power,r**power)
    ti=r**(power+1)/(ell+power+2);te=r**ell*(1-r**(power-ell+1))/(power-ell+1)
    return max(abs(first-ti).ravel()),max(abs(last-te).ravel())
if __name__=="__main__":
    errors=controls();print(errors);assert max(errors)<1e-12
