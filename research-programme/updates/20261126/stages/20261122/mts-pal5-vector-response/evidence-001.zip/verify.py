from base import *
import re
from scores import mapping
def check():
    assert not (HERE/"__pycache__").exists()
    for folder,expected in {LIVE:lock,RELEASE:previous.PINS[RELEASE],previous.PREP:previous.PINS[previous.PREP],previous.WORK:previous.PINS[previous.WORK]}.items():
        assert digest(folder/"seal.json")==expected
        entries=json.loads((folder/"seal.json").read_bytes())
        for name,sig in entries.items():assert digest(folder/name)==sig,name
    for file in HERE.iterdir():
        assert file.is_file() and file.stat().st_size>0,file
        if file.suffix==".py":compile(file.read_bytes(),str(file),"exec")
        if file.suffix==".csv":
            with file.open() as st: reader=list(csv.DictReader(st))
            assert reader and all(None not in row and None not in row.values() for row in reader),file
        if file.suffix==".npz":
            with np.load(file,allow_pickle=False) as archive:
                for key in archive.files:assert np.isfinite(archive[key]).all(),(file,key)
        if file.suffix==".md":
            prose=re.sub(r"```.*?```|`[^`\n]*`","",file.read_text(encoding="utf8"),flags=re.S)
            for link in re.findall(r"\[[^\]\n]+\]\(([^ )]+)\)",prose):
                if not link.startswith(("http://","https://","#")):assert (HERE/link).is_file(),link
    state="12-15-612"
    acc=json.loads((HERE/"acceptance.json").read_bytes())
    for key,number in (("probe_moving",100),("probe_relative",96),("star_vector",288),("individual_work",288),("forward_minus_reverse",144),("ensemble_work_rms",12),("fixed_tidal_lapse",96),("moving_tidal_lapse",96)):
        assert acc[key]["total"]==number and 0<=acc[key]["supported"]<=number
    one=mapping(HERE/f"points-{state}-direct-18.csv",("state","point"));assert len(one)==100
    wave=mapping(HERE/f"stellar-work-{state}-18.csv",("state","star"));assert len(wave)==288
    response=json.loads((HERE/"paired-stellar-summary.json").read_bytes());assert response["energy_fourth"]["total"]==12
    assert len(mapping(HERE/"paired-stellar-verdict.csv",("observable","state","site")))==312
    for name in ("manufactured.csv","manufactured-stellar-work.csv"):
        assert (HERE/name).is_file()
    ver=json.loads((HERE/"matched-boundary-and-metric-verdict.json").read_bytes())
    for k in ("weak_20_to_32","transfer_interior_identity","use_boundary_force_instead_radial","use_boundary_force_instead_tangential"):
        assert ver[k]["miss"]==0,k
    assert ver["raw_interior_dip_R"]["miss"]>0
    audit=json.loads((HERE/f"scores-{state}-small-24.json").read_bytes())
    assert audit["frozen_flux"]["total"]==12 and audit["frozen_flux"]["miss"]==0
    assert acc["star_vector"]["supported"]==288
    assert response["energy_fourth"]["pass_count"]==12 and response["energy_fourth"]["maximum"]<0
    far=mapping(HERE/"global-mass-and-dipole.csv",("state","radius_kpc","translation_step_kpc"))
    assert len(far)==16 and max(float(row["relative_error"]) for row in far.values())<1e-7
    with np.load(HERE/"source-12-15-612.npz") as src,np.load(prior("mesh.npz")) as old:
        assert src["edges"][0]==0 and src["edges"][-1]==old["right"][-1] and src["degree"][-1]==612
    with np.load(HERE/f"response-{state}.npz") as rsp:assert rsp["degree"][-1]==680
    ledger={p.name:digest(p) for p in sorted(HERE.iterdir()) if p.name!="seal.json"}
    rec("seal.json",ledger)
    assert all(digest(HERE/k)==v for k,v in json.loads((HERE/"seal.json").read_bytes()).items())
    print(len(ledger),digest(HERE/"seal.json"))
if __name__=="__main__":check()
