from scores import *
from direct import probes
def audit():
    red="12-15-612";ps=("state","point");stars=("state","star")
    points=mapping(HERE/f"points-{red}-direct-14.csv",ps)
    stellar=mapping(HERE/f"stellar-work-{red}-14.csv",stars)
    checks=[];observables=[]
    def gate(test,k,num,truth):
        diff=float(np.linalg.norm(np.asarray(num)-truth));scale=float(np.linalg.norm(truth))
        assert np.isfinite(diff+scale)
        rel=diff/scale if scale else None
        checks.append(dict(test=test,state=k[0],site=k[1],absolute=diff,scale=scale,relative=rel,passes=diff<=.005*scale))
    for alt in (red+"-direct-10","12-15-476-direct-14","9-12-476-direct-14",red+"-small-24","9-8-204-chart-12"):
        other=mapping(HERE/f"points-{alt}.csv",ps)
        for k,row in points.items():
            for group in ("fixed","moving","relative"):
                if group=="relative" and k[1]=="centre":continue
                gate("point_"+group+"_"+alt,k,vector(other[k],group),vector(row,group))
    for alt in (red+"-10","12-15-476-14","9-12-476-14"):
        other=mapping(HERE/f"stellar-work-{alt}.csv",stars)
        for k,row in stellar.items():
            gate("star_fixed_relative_"+alt,k,vector(other[k],"fixed"),vector(row,"fixed"))
            gate("star_individual_work_"+alt,k,float(other[k]["energy_third"]),float(row["energy_third"]))
            if k[0].endswith("forward"):
                pair=k[0].replace("forward","reverse"),k[1]
                for label in ("energy_third",):
                    gate("signed_pair_"+alt,k,float(other[k][label])-float(other[pair][label]),float(row[label])-float(stellar[pair][label]))
    for key in KEYS:
        for sh in (1,2,3):
            band=[row for (state,_),row in stellar.items() if key==state and int(row["shell"])==sh]
            assert len(band)==24
            coeff=np.array([float(row["energy_third"]) for row in band])
            assert np.max(abs(coeff[::2]+coeff[1::2]))<1e-20
            compare=np.array([float(row["frame_extra"]) for row in band])
            observables.append(dict(state=key,shell=sh,star_count=len(band),mean_third=float(np.mean(coeff)),
                       rms_third=np.linalg.norm(coeff)/np.sqrt(len(coeff)),maximum_abs_third=max(abs(coeff)),
                       double_counted_frame_rms=np.linalg.norm(compare)/np.sqrt(len(coeff))))
    table("stellar-readout.csv",observables);table("direct-checks.csv",checks)
    groups={}
    for row in checks:
        group=groups.setdefault(row["test"],dict(total=0,miss=0,worst=0.))
        group["total"]+=1;group["miss"]+=int(not row["passes"]);group["worst"]=max(group["worst"],row["relative"] or 0.)
    rec("direct-verdict.json",groups)
if __name__=="__main__":audit()
