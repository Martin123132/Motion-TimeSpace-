from direct import probes
from base import *
def run(q):
    import sources
    sources.table=lambda name,data:table("source-gains.csv",data)
    positions=np.stack([p for _,p in probes()])
    with np.load(HERE/"stellar-input.npz") as inp: stars=inp["pos"]
    allp=np.vstack((positions,stars));flat=np.column_stack((np.hypot(*allp[:,:2].T),allp[:,2]))
    distinct,idx=np.unique(flat,axis=0,return_inverse=True)
    order=np.r_[idx[0],np.delete(np.arange(len(distinct)),idx[0])]
    sites=distinct[order];index=np.argsort(order)[idx];assert np.array_equal(sites[index],flat)
    group=sources.info();off=np.array([-.015,-.002,0,.002,.015])
    a=sources.integrate(sites,sites,q,group,shifts=off,acceleration=True)[0][index]
    phi=sources.integrate(sites,sites,q,group,shifts=off)[0][index]
    res=np.column_stack((allp[:,:2]*(a[:,0]/flat[:,0])[:,None],a[:,1]))
    for prefix,part in (("",slice(0,len(positions))),("stars-",slice(len(positions),None))):
        packet(f"{prefix}direct-{q}.npz",pos=allp[part],acc=res[part],phi=phi[part])
if __name__=="__main__":run(int(sys.argv[1]))
