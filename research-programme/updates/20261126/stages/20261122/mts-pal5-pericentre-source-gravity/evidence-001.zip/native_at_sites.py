from local_stage import *
from numpy.polynomial.legendre import legvander
pin(STREAM,'observe.py');pin(STREAM,'field.py');sys.path.insert(0,str(STREAM))
from observe import Segment,CONV
G=4.30091727003628e-6
def main():
    records=rows(HOME/'sites.csv');out=[]
    for arm in ('reset','coupled'):
        receipt=json.loads(pin(STREAM,f'fine-before-{arm}.json').read_bytes())
        path=STREAM/f'fine-before-{arm}.npz';assert sha(path)==receipt['packet']
        with np.load(path) as archive:seg=Segment(archive,arm,1)
        both=seg.tables;zero=np.broadcast_to(np.zeros(1),both['forward'].shape)
        for sign in ('forward','reverse'):
            other='reverse' if sign=='forward' else 'forward'
            part=[row for row in records if row['prep']==arm and row['flow']==sign]
            p=np.array([[float(row['pos_'+ax]) for ax in 'xyz'] for row in part]);rr=np.linalg.norm(p,axis=1);mu=p[:,2]/rr
            R=np.linalg.norm(p[:,:2],axis=1);eR=p.copy();eR[:,2]=0;eR/=R[:,None]
            time=float(part[0]['date']);f=time/seg.end
            seg.tables=both;total=seg.acc(time,p,other)/CONV**2
            seg.tables={'forward':zero};acc=lambda pp:seg.acc(time,pp,'forward')/CONV**2
            native=acc(p)
            assert np.allclose(native,[[float(row['native_'+ax]) for ax in 'xyz'] for row in part],rtol=1e-12)
            opposite=total-native
            idx=np.searchsorted(seg.rad,rr)-1;h=(seg.rad[idx+1]-seg.rad[idx])[:,None];loc=(rr[:,None]-seg.rad[idx,None])/h
            host=(1-f)*seg.host[0]+f*seg.host[1]
            a,b=host[idx],host[idx+1];rise=b[...,0]-a[...,0];u=h*a[...,1];v=3*rise-h*(2*a[...,1]+b[...,1]);w=-2*rise+h*(a[...,1]+b[...,1])
            phi=a[...,0]+loc*(u+loc*(v+loc*w));grad=(u+loc*(2*v+3*loc*w))/h;curv=(2*v+6*loc*w)/h**2
            degree=2*np.arange(phi.shape[1])
            density=np.sum(legvander(mu,degree[-1])[:,::2]*(curv+2*grad/rr[:,None]-degree*(degree+1)*phi/rr[:,None]**2),axis=1)/(4*np.pi*G)
            eps=1e-5
            div=np.zeros(len(p))
            for dim in range(3):
                shift=np.eye(3)[dim]*eps
                div+=(acc(p+shift)[:,dim]-acc(p-shift)[:,dim])/(2*eps)
            assert np.allclose(density,-div/(4*np.pi*G),rtol=1e-5)
            for row,rho,vec,rad in zip(part,density,opposite,eR):
                out.append(dict(prep=arm,flow=sign,tail=row['tail'],rho_native=rho,opposite_R=vec@rad,opposite_z=vec[2]))
    table('native-points.csv',out)
if __name__=='__main__':main()
