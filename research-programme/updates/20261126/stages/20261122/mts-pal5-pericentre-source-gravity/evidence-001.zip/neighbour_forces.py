from source_at_sites import *
def main(orders):
    src=sources();contract=group(src);data=rows(HOME/'sites.csv')
    shifts=np.r_[0.,-.15,-.02,-.002,-.001,.001,.002,.02,.15]
    for order in orders:
        out=[]
        for first in range(0,len(data),3):
            chunk=data[first:first+3]
            sites=np.array([[np.hypot(float(row['pos_x']),float(row['pos_y'])),abs(float(row['pos_z']))] for row in chunk])
            offsets=np.vstack([np.zeros((1,2)),*[step*np.eye(2) for step in (.001,-.001,.002,-.002)]])
            points=(sites[:,None,:]+offsets).reshape(-1,2)
            endpoints=src.integrate(points,sites,order,contract,shifts=shifts,acceleration=True)
            frac=float(chunk[0]['date'])/float(chunk[0]['duration'])
            interpolated=((1-frac)*endpoints[0]+frac*endpoints[1]).reshape(3,len(offsets),2)
            for row,position,force in zip(chunk,sites,interpolated):
                for idx,h in ((1,.001),(5,.002)):
                    columns=((force[idx:idx+2]-force[idx+2:idx+4])/(2*h)).T
                    rho=-(np.trace(columns)+force[0,0]/position[0])/(4*np.pi*src.G)
                    out.append(dict(prep=row['prep'],flow=row['flow'],tail=row['tail'],step_kpc=h,dR_aR=columns[0,0],dz_aR=-columns[0,1],dR_az=-columns[1,0],dz_az=columns[1,1],poisson_density=rho))
        table(f'neighbours-q{order}.csv',out);print(order,'neighbours',flush=True)
if __name__=='__main__':main(list(map(int,sys.argv[1:])))
