from local_stage import *
from scipy.special import ndtr,ndtri
CAT=ROOT/'mts-pal5-measured-rrl-20261122'
def run():
    assert sha(CAT/'seal.json')=='e94eaf7948ea6a477eecd1124486c2df30a70144d092ebd7caf61c4176b35a55'
    path=CAT/'kuzma-table4.txt';assert sha(path)==json.loads((CAT/'seal.json').read_bytes())[path.name]
    errors=np.array([float(line.split()[7]) for line in path.read_text().splitlines() if line.strip() and not line.startswith('#')])
    assert errors.size==109 and np.isclose(np.min(errors),.22) and np.isclose(np.median(errors),1.39)
    left,right=np.where(~np.eye(len(errors),dtype=bool));counts=[]
    marks=rows(pin(STREAM,'loose-witness.csv'));launch=rows(pin(STREAM,'physical-launch-8-2.csv'))
    for arm in ('reset','coupled'):
        ref=next(row for row in launch if (row['arm'],row['speed'],row['cluster_force'],row['alternative'])==(arm,'escape','True','passage'))
        witness=next(row for row in marks if (row['grid'],row['arm'])==('8-2',arm))
        for tag,one,two,lag in [('pericentre',ref['inner_kms'],ref['outer_kms'],0.),('alternative',witness['delta_inner_kms'],witness['delta_outer_kms'],float(witness['lag_Myr']))]:
            diff=np.array([float(one),float(two)]);distance=np.linalg.norm(diff)
            acc=100*ndtr(np.hypot(diff[0]/errors[left],diff[1]/errors[right])/2)
            commonfree=100*ndtr(abs(diff[1]-diff[0])/(2*np.hypot(errors[left],errors[right])))
            assert np.all(commonfree<=acc+1e-10)
            best=float(100*ndtr(distance/(2*errors.min())))
            published=float(ref['best_error_two_state_accuracy_pct'] if tag=='pericentre' else witness['worst_accuracy_upper_best_error_pct'])
            assert abs(best-published)<1e-10
            counts.append(dict(prep=arm,test=tag,shared_lag_Myr=lag,pair_delta_kms=distance,best_same_error_pct=best,median_same_error_pct=100*ndtr(distance/(2*np.median(errors))),equal_error_needed_95_kms=distance/(2*ndtri(.95)),ordered_distinct_error_assignments=len(acc),best_distinct_pct=max(acc),median_distinct_pct=np.median(acc),median_distinct_common_velocity_free_pct=np.median(commonfree)))
    table('measurement.csv',counts)
if __name__=='__main__':run()
