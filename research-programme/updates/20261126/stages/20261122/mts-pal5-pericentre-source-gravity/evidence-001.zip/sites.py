from local_stage import *
pin(STREAM,'observe.py');pin(STREAM,'field.py');sys.path.insert(0,str(STREAM))
from observe import anchors,load_segments,CONV
def main():
    clocks=rows(pin(STREAM,'passages-8-2.csv'));result=[]
    for arm in ('reset','coupled'):
        for leg in ('before','middle','late'):pin(STREAM,f'fine-{leg}-{arm}.json')
        early,mid,late=load_segments(arm,8,4,2)
        start=tuple(val[:1] for val in anchors(22.05))
        for seg in (late,mid,early):start=seg.move(seg.end,0,start,'mean')
        real=early.tables
        for sign in ('forward','reverse'):
            rec=next(row for row in clocks if row['arm']==arm and row['flow']==sign)
            date=float(rec['passage_Myr'])
            early.tables=real
            pos,vel=early.move(0,date,start,sign)
            radial=pos[0]*[1.,1.,0.];radial/=np.linalg.norm(radial);az=np.cross([0,0,1],radial)
            if az@vel[0]<0:az=-az
            points=pos+np.array([0,-1,1])[:,None]*.060*radial
            total=early.acc(date,points,sign)/CONV**2
            zeros=np.broadcast_to(np.zeros(1),real[sign].shape)
            early.tables={sign:zeros}
            ordinary=early.acc(date,points,sign)/CONV**2
            static=np.zeros_like(real[sign][0]);static[:,0,:,0]=mid.tables['forward'][-1,:,0,:,0] if len(mid.rad)==len(early.rad) and np.array_equal(mid.rad,early.rad) else np.nan
            assert np.isfinite(static).all()
            early.tables={sign:np.broadcast_to(static,real[sign].shape)}
            monopole=early.acc(date,points,sign)/CONV**2-ordinary
            early.tables=real
            for idx,tail in enumerate(('centre','inner','outer')):
                row=dict(prep=arm,flow=sign,tail=tail,date=date,duration=early.end,clock_radius=float(rec['radius_kpc']))
                for prefix,vec in [('pos',points[idx]),('vel',vel[0]/CONV),('az',az),('native',ordinary[idx]),('wave',total[idx]-ordinary[idx]),('static',monopole[idx])]:
                    row.update({prefix+'_'+ax:item for ax,item in zip('xyz',vec)})
                result.append(row)
            assert abs(np.linalg.norm(pos)-float(rec['radius_kpc']))<.0001
    table('sites.csv',result)
if __name__=='__main__':main()
