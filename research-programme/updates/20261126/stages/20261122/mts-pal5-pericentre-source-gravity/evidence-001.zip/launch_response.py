from local_stage import *
G=4.30091727003628e-6
CONV=1/977.7922216807892
GM=G*4297;SCALE=22.05*np.tan(np.deg2rad(3.21/60))
ESC=np.sqrt(2*GM/np.hypot(.060,SCALE))
def compute(order,factor):
    sites=rows(HOME/'sites.csv');positive=rows(HOME/f'positive-q{order}.csv')
    waves=rows(HOME/f'wave-{factor}.csv');native=rows(HOME/'native-points.csv')
    key=lambda row:(row['prep'],row['flow'],row['tail'])
    assert all(list(map(key,source))==list(map(key,sites)) for source in (positive,waves,native))
    def get(source,names,first):
        return np.array([[float(row[name]) for name in names] for row in source[first:first+3]])
    def xyz(label,first):return get(sites,[label+'_'+ax for ax in 'xyz'],first)
    forces=[];energy=[];fluid=[]
    for first in range(0,len(sites),3):
        p=xyz('pos',first);R=np.linalg.norm(p[:,:2],axis=1);eR=p.copy();eR[:,2]=0;eR/=R[:,None]
        ephi=np.cross([0.,0.,1.],eR);velocity=xyz('vel',first);u=xyz('az',first)*np.array([0.,-ESC,ESC])[:,None]
        def cyl(field):return np.column_stack(((field*eR).sum(axis=1),field[:,2]))
        def cart(field):return field[:,:1]*eR+field[:,1:]*[0,0,1]
        host=cyl(xyz('native',first));direct=get(positive,['direct_R','direct_z'],first)
        wave=cyl(xyz('wave',first));mono=cyl(xyz('static',first));other=get(native,['opposite_R','opposite_z'],first)
        change=direct-host;rel=change-change[0]
        signed=(wave-other)-(wave-other)[0]
        rho,gr,gz=get(waves,['rho','grad_R','grad_z'],first).T
        normal_rho=get(native,['rho_native'],first)[:,0]
        target_rho=get(positive,['rho_Msun_kpc3'],first)[:,0]
        for idx in range(3):
            prep,flow,tail=key(sites[first+idx])
            base=dict(prep=prep,flow=flow,tail=tail)
            j=rho[idx]*CONV**2*rel[idx]
            compression=4*np.pi*G*CONV**2*(target_rho[idx]-normal_rho[idx])
            advect=-CONV**2*np.dot([gr[idx],gz[idx]],rel[idx])/rho[idx]
            fluid.append(dict(**base,current_R=j[0],current_z=j[1],compression_Myr_m2=compression,advection_Myr_m2=advect,density_curve_fraction_Myr_m2=compression+advect,wave_density=rho[idx],native_ord_density=normal_rho[idx],direct_ord_density=target_rho[idx]))
            if not idx:continue
            direct_tide=direct[idx]-direct[0];host_tide=host[idx]-host[0]
            forces.append(dict(**base,native_R=host_tide[0],native_z=host_tide[1],direct_R=direct_tide[0],direct_z=direct_tide[1],source_delta_R=rel[idx,0],source_delta_z=rel[idx,1],sign_delta_R=signed[idx,0],sign_delta_z=signed[idx,1],source_to_sign=np.linalg.norm(rel[idx])/np.linalg.norm(signed[idx])))
            for source,ordinary in [('direct',direct),('native',host)]:
                for model,extra in [('ordinary',0*wave),('static_monopole',mono),('signed',wave),('opposite_same_point',other)]:
                    external=cart(ordinary+extra)
                    tide=external[idx]-external[0];s=p[idx]-p[0]
                    cluster=-GM*s/(np.dot(s,s)+SCALE**2)**1.5
                    power=CONV*np.dot(u[idx],tide);assert abs(power)<1e-12
                    turn=np.sum((velocity+u)*ephi,axis=1)/R
                    accR=(ordinary+extra)[:,0]
                    bending=np.dot(u[idx],ephi[idx])*(turn[idx]*accR[idx]-turn[0]*accR[0])
                    curvature=CONV**2*(np.dot(tide+cluster,tide)+bending)
                    def power_at(h):
                        points=p+h*CONV*(velocity+u)
                        unit=points.copy();unit[:,2]=0;unit/=np.linalg.norm(unit,axis=1)[:,None]
                        field=unit*accR[:,None]+(ordinary+extra)[:,1:]*[0,0,1]
                        return CONV*np.dot(u[idx]+h*CONV*(tide+cluster),field[idx]-field[0])
                    fd=(power_at(.0001)-power_at(-.0001))/.0002
                    assert abs(fd-curvature)<1e-7*max(abs(curvature),1e-8),(fd,curvature)
                    energy.append(dict(**base,source=source,control=model,work_at_release=power,work_curvature_kms2_Myr2=curvature,tidal_term=CONV**2*np.dot(tide+cluster,tide),turning_term=CONV**2*bending,kinematic_check=fd))
    return forces,energy,fluid
def main():
    for (order,factor) in ((4,4),(8,4),(12,2),(12,4)):
        for label,records in zip(('tides','energy','wave-response'),compute(order,factor)):
            table(f'{label}-{order}-{factor}.csv',records)
if __name__=='__main__':main()
