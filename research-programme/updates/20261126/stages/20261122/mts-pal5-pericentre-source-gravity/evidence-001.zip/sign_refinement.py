from local_stage import *
pin(STREAM,'field.py');pin(STREAM,'observe.py');sys.path.insert(0,str(STREAM))
from observe import Segment,CONV
def run():
    sites=rows(HOME/'sites.csv');out=[]
    for arm in ('reset','coupled'):
        name=f'fields-4-{arm}';note=json.loads(pin(STREAM,name+'.json').read_bytes());p=STREAM/(name+'.npz')
        assert sha(p)==note['data']
        with np.load(p) as bank:segment=Segment(bank,arm,1)
        for sign in ('forward','reverse'):
            other='reverse' if sign=='forward' else 'forward'
            part=[row for row in sites if (row['prep'],row['flow'])==(arm,sign)]
            points=np.array([[float(row['pos_'+ax]) for ax in 'xyz'] for row in part])
            time=float(part[0]['date']);signal=(segment.acc(time,points,sign)-segment.acc(time,points,other))/CONV**2
            for idx in (1,2):
                row=part[idx];unit=points[idx]*[1,1,0];unit/=np.linalg.norm(unit)
                coarse=signal[idx]-signal[0];out.append(dict(prep=arm,flow=sign,tail=row['tail'],sign_R=coarse@unit,sign_z=coarse[2]))
    table('coarse-sign.csv',out)
if __name__=='__main__':run()
