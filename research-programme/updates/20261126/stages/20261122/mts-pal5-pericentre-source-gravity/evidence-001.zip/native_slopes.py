from local_stage import *
pin(STREAM,'observe.py');pin(STREAM,'field.py');sys.path.insert(0,str(STREAM))
from observe import Segment,CONV
def main():
    data=rows(HOME/'sites.csv');out=[]
    for arm in ('reset','coupled'):
        receipt=json.loads(pin(STREAM,f'fine-before-{arm}.json').read_bytes());path=STREAM/f'fine-before-{arm}.npz'
        assert sha(path)==receipt['packet']
        with np.load(path) as archive:seg=Segment(archive,arm,1)
        seg.tables={'forward':np.broadcast_to(np.zeros(1),seg.tables['forward'].shape)}
        for first in range(0,len(data),3):
            part=data[first:first+3]
            if part[0]['prep']!=arm:continue
            pts=np.array([[np.hypot(float(row['pos_x']),float(row['pos_y'])),0.,float(row['pos_z'])] for row in part])
            time=float(part[0]['date'])
            acc=lambda t,points:seg.acc(t,points,'forward')[:,[0,2]]/CONV**2
            rate=(acc(seg.end,pts)-acc(0.,pts))/seg.end
            for h in (.001,.002):
                radial=(acc(time,pts+[h,0.,0.])-acc(time,pts-[h,0.,0.]))/(2*h)
                vert=(acc(time,pts+[0.,0.,h])-acc(time,pts-[0.,0.,h]))/(2*h)
                for idx,row in enumerate(part):out.append(dict(prep=arm,flow=row['flow'],tail=row['tail'],step_kpc=h,dR_aR=radial[idx,0],dz_aR=vert[idx,0],dR_az=radial[idx,1],dz_az=vert[idx,1],rate_R=rate[idx,0],rate_z=rate[idx,1]))
    table('native-slopes.csv',out)
if __name__=='__main__':main()
