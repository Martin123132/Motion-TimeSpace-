from launch_response import *
def main():
    for q in (4,8,12):
        tides=rows(HOME/f'tides-{q}-4.csv')
        energy=rows(HOME/f'energy-{q}-4.csv')
        samples={(row['prep'],row['flow'],row['tail'],row['source'],row['control']):float(row['work_curvature_kms2_Myr2']) for row in energy}
        out=[]
        for t in tides:
            key=tuple(t[k] for k in ('prep','flow','tail'))
            def same(src):return samples[key+(src,'signed')]-samples[key+(src,'opposite_same_point')]
            raw=same('native');new=same('direct')
            correction=2*CONV**2*(float(t['source_delta_R'])*float(t['sign_delta_R'])+float(t['source_delta_z'])*float(t['sign_delta_z']))
            assert np.isclose(new-raw,correction,rtol=1e-7,atol=1e-15)
            out.append(dict(prep=key[0],flow=key[1],tail=key[2],native_contrast=raw,direct_contrast=new,absolute_change=new-raw,exact_cross=correction,fractional_change=new/raw-1))
        table(f'contrast-q{q}.csv',out)
if __name__=='__main__':main()
