from local_stage import *
from scipy.special import eval_legendre
INV=ROOT/'mts-flow-formation-inverse-586-20261122'
assert sha(INV/'seal.json')=='4ae215216dac834ea5d8ae503fea680707af22348044627efb0b507a7c398fcb'
manifest=json.loads((INV/'seal.json').read_bytes())
assert sha(INV/'inverse.py')==manifest['inverse.py']
sys.path.insert(0,str(INV))
from inverse import setup

def run():
    lab,Evolution,advance,hold,shape=setup()
    host=lab.run;obj=lab.obj;el=host.el;bg=obj.bg;orders=bg.orders
    data=rows(HOME/'sites.csv')
    def density(state,plane,height):
        dist=np.hypot(plane,height);mu=height/dist;rad=dist/bg.length
        ix=np.searchsorted(el.right,rad)
        value,grad=shape(el.knots,(rad-el.left[ix])/el.width[ix])
        values=el.nodes(state)[ix]
        raw=np.einsum('ti,til->tl',value,values)
        raw_r=np.einsum('ti,til->tl',grad/el.width[ix,None]/bg.length,values)
        norm=np.sqrt(2*orders+1)
        polys=eval_legendre(orders,mu[:,None])
        deriv=orders*(eval_legendre(np.maximum(0,orders-1),mu[:,None])-mu[:,None]*polys)/(1-mu[:,None]**2)
        amp=(raw*norm*polys).sum(axis=1)/dist
        dr=(raw_r*norm*polys).sum(axis=1)/dist-amp/dist
        dm=(raw*norm*deriv).sum(axis=1)/dist
        scale=lab.mesh.mscale/(4*np.pi*bg.length)
        return np.column_stack([scale*abs(amp)**2,2*scale*(amp.conj()*(plane/dist*(dr-mu/dist*dm))).real,2*scale*(amp.conj()*(mu*dr+(1-mu**2)/dist*dm)).real])
    for factor in (2,4):
        name=f'states-586-{70*factor}.npz'
        assert sha(INV/name)==manifest[name]
        native,dt=host.interval(581,586);dt/=factor;count=native*factor
        out=[]
        with np.load(INV/name) as bank:
            for start in range(0,len(data),3):
                part=data[start:start+3];arm,sign=part[0]['prep'],part[0]['flow']
                state=bank[arm+'_'+sign];mom=obj.moment(state)
                age=float(part[0]['date']);duration=host.ages[586]-host.ages[581]
                assert abs(duration-float(part[0]['duration']))<1e-10
                final=(1-age/duration)*count
                solver=Evolution(obj,-dt,state)
                for tick in range(int(np.ceil(final))):
                    guard();hold()
                    portion=min(1.,final-tick);step=-dt*portion
                    if portion!=1:solver=Evolution(obj,step,state)
                    phase=1-(tick+portion/2)/count
                    drive=host.fields[581]+phase*(host.fields[586]-host.fields[581])
                    if portion==1:assert np.max(abs(drive-host.external(581,586,count-tick-1,count)))<1e-10
                    state,mom,_,_=advance(obj,solver,state,mom,drive,step)
                norm=abs(np.vdot(state,state).real/obj.number-1);assert norm<1e-9
                plane=np.array([np.hypot(float(row['pos_x']),float(row['pos_y'])) for row in part]);height=np.array([float(row['pos_z']) for row in part])
                result=density(state,plane,height);eps=.00001
                for axis in (0,1):
                    off=(eps*(axis==0),eps*(axis==1))
                    fd=(density(state,plane+off[0],height+off[1])[:,0]-density(state,plane-off[0],height-off[1])[:,0])/(2*eps)
                    assert np.allclose(fd,result[:,axis+1],rtol=5e-7,atol=.001),(fd,result)
                for row,(rho,gr,gz) in zip(part,result):out.append(dict(prep=arm,flow=sign,tail=row['tail'],rho=rho,grad_R=gr,grad_z=gz,occupation_error=norm))
        table(f'wave-{factor}.csv',out);print('wave',factor,'done',flush=True)
if __name__=='__main__':run()
