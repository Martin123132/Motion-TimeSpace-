from local_stage import *
from itertools import product
def verify():
    report=[]
    def compare(name,low,high,fields,second=None,only=None):
        left=rows(HOME/low);right=rows(HOME/high)
        if only:left=[r for r in left if only(r,0)];right=[r for r in right if only(r,1)]
        assert len(left)==len(right)>0
        for a,b in zip(left,right):
            ids=['prep','flow','tail','source','control']
            assert all(a.get(k)==b.get(k) for k in ids)
            lo=np.array([float(a[k]) for k in fields]);hi=np.array([float(b[k]) for k in second or fields])
            if not np.any(hi):assert not np.any(lo);continue
            err=float(np.linalg.norm(hi-lo)/np.linalg.norm(hi))
            report.append(dict(check=name,case=':'.join(b[k] for k in ids if k in b),error=err,passed=err<=.005))
    compare('signed wave x4:x8','coarse-sign.csv','tides-12-4.csv',['sign_R','sign_z'],['sign_delta_R','sign_delta_z'])
    for field in ('direct','source_delta'):
        compare(field+' q8:q12','tides-8-4.csv','tides-12-4.csv',[field+'_R',field+'_z'])
    compare('full energy q8:q12','energy-8-4.csv','energy-12-4.csv',['work_curvature_kms2_Myr2'])
    compare('difference energy q8:q12','contrast-q8.csv','contrast-q12.csv',['absolute_change'])
    for coarse in ('8-4','12-2'):
        for cols in (['density_curve_fraction_Myr_m2'],['current_R','current_z']):
            compare(str(cols)+' '+coarse,'wave-response-'+coarse+'.csv','wave-response-12-4.csv',cols)
    compare('jerk temporal/spatial force quadrature','jerk-6.csv','jerk-10.csv',['delta_jerk_R','delta_jerk_phi','delta_jerk_z'],only=lambda r,i:float(r['step_kpc'])==.001)
    compare('jerk spatial difference step','jerk-10.csv','jerk-10.csv',['delta_jerk_R','delta_jerk_phi','delta_jerk_z'],only=lambda r,i:float(r['step_kpc'])==(.002,.001)[i])
    for row in rows(HOME/'poisson-10.csv'):
        if float(row['step_kpc'])!=.001:continue
        for field in ('source_density_error','wave_curvature_error','curl_fraction'):
            err=float(row[field]);report.append(dict(check=field,case=':'.join(row[k] for k in ('prep','flow','tail')),error=err,passed=err<=.005))
    table('checks.csv',report)
    meas=rows(HOME/'measurement.csv')
    assert len(meas)==4 and all(int(r['ordered_distinct_error_assignments'])==109*108 for r in meas)
    durations={}
    for row in rows(pin(STREAM,'controls-8-4-4.csv')):durations.setdefault(row['arm'],[]).append(float(row['duration_Myr']))
    assert all(np.isclose(sum(v),222.840516,rtol=1e-10) for v in durations.values()) and len(durations)==2
    clocks=rows(pin(STREAM,'passages-8-2.csv'))
    times=[]
    for row in clocks:
        if row['flow'] not in ('reverse','forward'):continue
        span=sum(durations[row['arm']])
        times.append(dict(prep=row['arm'],flow=row['flow'],total_Myr=span,star_flight_Myr=span-float(row['passage_Myr']),trailing_tip_fraction=span/1940,leading_tip_fraction=span/1260,model_duration_fraction=span/6200))
    table('coverage.csv',times)
    failures=[r for r in report if not r['passed']]
    print('cases:',len(report),'failures:',len(failures),'max relative discrepancy:',max(r['error'] for r in report),flush=True)
    for row in failures:print(row)
    assert all(np.isfinite(r['error']) for r in report)
    if '--seal' in sys.argv:
        assert (HOME/'RESULTS.md').exists() and (HOME/'DERIVATION.md').exists()
        manifest={p.name:sha(p) for p in sorted(HOME.iterdir()) if p.is_file() and p.name!='seal.json'}
        store('seal.json',(json.dumps(manifest,sort_keys=True,indent=2)+'\n').encode())
        assert all(sha(HOME/k)==v for k,v in json.loads((HOME/'seal.json').read_bytes()).items())
        print(len(manifest),sha(HOME/'seal.json'))
if __name__=='__main__':verify()
