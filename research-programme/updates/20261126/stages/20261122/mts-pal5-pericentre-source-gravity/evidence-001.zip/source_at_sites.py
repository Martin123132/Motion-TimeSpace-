from local_stage import *
from numpy.polynomial.legendre import legvander

def group(src):
    edges,angles,cells,_=src.prior.io.arrays()
    faces,shells,reference=src.groups(edges,angles,cells)
    labels=(np.searchsorted(shells,(edges[1:]+edges[:-1])/2,side='right')-1)[:,None]*7+np.searchsorted(faces[1:-1],(angles[1:]+angles[:-1])/2)
    def totals(values):
        return np.bincount(labels.ravel(),weights=values.ravel(),minlength=reference.size).reshape(reference.shape)
    def census(snap):
        masses=[]
        for part in range(4):
            name=f'mass-{snap}-{part}.npz'
            path=pin(SNAP,name) if snap==581 else src.pin(src.FIRE,name)
            with np.load(path) as bank:
                assert np.array_equal(bank['edges'],edges) and np.array_equal(bank['mu'],angles)
                masses.append(bank['hist'][:,0].sum(axis=0))
        return totals(np.sum(masses,axis=0))
    terminal=census(600); local=totals(cells['terminal']);records=[];gains=[]
    for epoch in (581,586):
        raw=census(epoch)
        assert np.all(terminal[local>0]>0)
        gain=np.where(local>0,np.divide(raw,terminal,out=np.ones_like(raw),where=terminal>0),1)
        assert np.isfinite(gain).all() and gain.min()>=0
        mass=np.sum(local*(gain-1))
        if epoch==586:
            assert np.allclose(gain,reference,atol=1e-12,rtol=1e-12)
            check=json.loads(src.pin(src.FIRE,'forcing-586.json').read_bytes())['joint']['delta_msun']
        else:
            with np.load(pin(SNAP,'forcing-581.npz')) as bank:
                radius=bank['physical_r'][-1]
                angular=legvander(bank['mu'],64)[:,::2]
                coeff=np.linalg.lstsq(angular,bank['joint'][-1],rcond=None)[0]
                occupied=np.any(cells['terminal']>0,axis=1)
                assert radius>max(edges[1:][occupied]) and np.max(abs(angular@coeff-bank['joint'][-1]))<1e-9
                check=-radius*coeff[0]/src.G
        assert abs(mass/check-1)<1e-8,(epoch,mass,check)
        gains.append(gain);records.append(dict(epoch=epoch,delta_mass_Msun=mass,independent_transfer_Msun=check,min_gain=gain.min(),max_gain=gain.max()))
    table('transfer.csv',records)
    return faces,shells,np.array(gains)

def run(orders):
    src=sources();contract=group(src)
    data=rows(HOME/'sites.csv')
    point=np.array([[np.hypot(float(row['pos_x']),float(row['pos_y'])),abs(float(row['pos_z']))] for row in data])
    assert all(float(row['pos_z'])<0 for row in data)
    rad=np.linalg.norm(point,axis=1)
    faces,shells,gain=contract
    density=src.material.density(*point.T)*gain[:,np.searchsorted(shells,rad,side='right')-1,np.searchsorted(faces[1:-1],point[:,1]/rad)]
    for order in orders:
        out=[]
        for start in range(0,len(point),3):
            local=point[start:start+3]
            forces=src.integrate(local,local,order,contract,acceleration=True)
            for idx,row in enumerate(data[start:start+3]):
                frac=float(row['date'])/float(row['duration'])
                values=forces[:,idx]
                acc=(1-frac)*values[0]+frac*values[1]
                out.append(dict(prep=row['prep'],flow=row['flow'],tail=row['tail'],f581_R=values[0,0],f581_z=-values[0,1],f586_R=values[1,0],f586_z=-values[1,1],direct_R=acc[0],direct_z=-acc[1],rho_Msun_kpc3=(1-frac)*density[0,start+idx]+frac*density[1,start+idx]))
        table(f'positive-q{order}.csv',out);print(order,'done',flush=True)
if __name__=='__main__':run([int(v) for v in sys.argv[1:]])
