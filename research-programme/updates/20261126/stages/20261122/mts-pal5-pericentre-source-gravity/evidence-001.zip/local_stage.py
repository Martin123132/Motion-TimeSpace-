import csv,hashlib,io,json,os,sys
from pathlib import Path
for key in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','BLIS_NUM_THREADS','NUMEXPR_NUM_THREADS'): os.environ[key]='1'
import numpy as np
HOME=Path(__file__).resolve().parent
ROOT=HOME.parent
STREAM=ROOT/'mts-pal5-paired-release-581-600-20261122'
SOURCE=ROOT/'mts-pal5-release-evolution-20261122'
WAVE=ROOT/'mts-pal5-live-wave-coupling-20261122'
SNAP=ROOT/'mts-fire-581-formation-state-20261120'
PINS={STREAM:'2773a30a3611c5f7809d3bd0c8b965216225853390b591c82b295c9d5ec6f760',SOURCE:'f9b37646651579124cc8cf0b744488b84d493e668ca81f6516e361dd06222eb5',WAVE:'e3179448aeee4c8d65d82377cab0f358820d43eb08c00c6935a2045c92cc2314',SNAP:'a468eac90a9e2ec4a840dfbcf1ec23a0c4cc7acc6c17f7d258f229ab44116a1a'}
def sha(path):
    with path.open('rb') as inp:return hashlib.file_digest(inp,'sha256').hexdigest()
def pin(base,name):
    assert sha(base/'seal.json')==PINS[base]
    data=json.loads((base/'seal.json').read_bytes()); path=base/name
    assert sha(path)==data.get('files',data)[name],name
    return path
def guard():
    assert not any((path/'STOP-REQUESTED').exists() for path in (*PINS,ROOT,HOME))
def store(name,data):
    guard();path=HOME/name
    if path.exists():assert sha(path)==hashlib.sha256(data).hexdigest(),name
    else:
        with path.open('xb') as stream:stream.write(data)
def table(name,rows):
    out=io.StringIO();writer=csv.DictWriter(out,rows[0],lineterminator='\n');writer.writeheader();writer.writerows(rows);store(name,out.getvalue().encode())
def rows(path):
    with path.open() as stream:return list(csv.DictReader(stream))
def packet(name,**items):
    buf=io.BytesIO();np.savez_compressed(buf,**items);store(name,buf.getvalue())
def sources():
    pin(SOURCE,'sources.py');pin(SOURCE,'ledger.py');sys.path.insert(0,str(SOURCE));import sources as src
    return src
guard()
