from common12 import *
from transport import Kinetic
import time

class Exact:
    def __init__(self,model):
        self.model=model
        self.frozen=load_np(HERE/f'prediction-{model}.npz');self.prior=load_np(parent(f'fine-{model}.npz'))
        self.replay=load_np(HERE/f'high-replay-{model}.npz')
        self.waves=self.prior['k'];self.banks={};self.envs={};self.dynamics={}
        for earlier,label in [(True,'pre'),(False,'next')]:
            bank=load_np(HERE/f'angular-{label}-{model}.npz');self.banks[label]=bank
            self.envs[label]=env(model,earlier,2 if earlier else 1)
            scale,energy,meta=background(model,earlier);self.mass=meta['mass_over_temperature']
            if earlier:
                clock=self.replay['eta'];normal=self.replay['normal'];metric=self.replay['metric'][:,1];shape=self.replay['shape']
            else:
                clock=self.frozen['eta'];normal=self.frozen['normal'];metric=self.frozen['obs'][:,1];shape=self.frozen['shape']
            self.dynamics[label]=(scale,spline(clock,normal),spline(clock,metric),spline(bank['eta'],shape))
        self.limit=self.banks['next']['S'].shape[1]-1
    def initial(self,q):
        instance=object.__new__(Kinetic);instance.q=np.array([q]);instance.w=1-instance.q*np.tanh(instance.q/2)
        instance.k=self.waves;instance.t=self.banks['pre']['eta'];instance.mass=self.mass;instance.af=self.dynamics['pre'][0];instance.model=self.model
        result=np.zeros((1,self.limit+1,len(self.waves),2),complex);result[:,1]=instance.start()
        return result
    def integrate(self,label,q,source,initial):
        bank=self.banks[label];clock=bank['eta'];scale,normal,lapse,shape=self.dynamics[label];incoming=spline(clock,source.transpose(2,1,0))
        spectral=5-q*np.tanh(q/2);waves=self.waves
        def rate(epoch,delta):
            mass=scale(epoch)*self.mass;energy=np.hypot(q,mass);speed=q/energy;slow=-mass**2/(energy*(energy+q))
            reference=normal(epoch)+spectral*shape(epoch)[:,:,None]
            derivative=speed*adv(delta,waves)+slow*adv(reference[None],waves)+incoming(epoch)[None,:,:,None]
            derivative[:,1]+=(-slow/speed)*waves[:,None]*lapse(epoch)/3
            return derivative
        return solve_log(rate,clock,initial)[:,0]
    def run(self,idx):
        guard();name=f'exact-{self.model}-q{idx}.npz';q=2.**(idx/4);waveweight=5-q*np.tanh(q/2)
        if (HERE/name).exists():
            with np.load(HERE/name) as prior:
                assert prior['q']==q and prior['lagEnd'].shape==(self.limit+1,len(self.waves),2) and np.isfinite(prior['lagEnd']).all()
            return
        saved=load_np(parent(f'kin-{self.model}-s2-q{idx}.npz'));which=np.flatnonzero(self.prior['q']==q).item()
        seed=self.initial(q);now=time.perf_counter();errors=[]
        for label in ('pre','next'):
            bank=self.banks[label];inc,projector,ref,waves=self.envs[label];assert np.array_equal(bank['eta'],inc.data.eta[::4])
            if label=='pre':state=regular(inc,ref,self.limit+8,q)
            else:
                state[0,:27]=saved['incidentEnd'];state[1,:27]=saved['slopeEnd']
                seed=lag[-1:,:,:,:].copy()
                seed[0,:19]=self.prior['massLag'][which];seam=seed[0].copy()
            state[0,0]-=inc.data.first['phi'][:,0]
            field,slope=inc.flight(q,state);state=np.stack([field[:,:,-1],slope[:,:,-1]])
            physical=projector.calculate(field,slope,q,maximum=self.limit,match_bulk=False)[0]
            source=physical-bank['S']-waveweight*bank['Sw']
            lag=self.integrate(label,q,source,seed)
            if label=='pre':
                errors.append(np.max(abs(lag[-1,:3]-self.prior['massLag'][which,:3]))/max(np.max(abs(self.prior['massLag'][which,:3])),1e-70))
                prev=physical[:,:3,-1]
            else:errors.append(np.max(abs(physical[:,:3,0]-prev))/max(np.max(abs(prev)),1e-70))
        pack(name,q=q,id=idx,eta=bank['eta'],k=waves,lagEnd=lag[-1],lagLow=lag[:,:3],lagStart=seam,source=source,
             incidentEnd=state[0],slopeEnd=state[1],prior_low_check=errors[0],source_join=errors[1])
        print(self.model,idx,'seconds',round(time.perf_counter()-now,2),flush=True)
if __name__=='__main__':
    exact=Exact(sys.argv[1])
    for node in range(*map(int,sys.argv[2:])):exact.run(node)

