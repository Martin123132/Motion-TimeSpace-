from refined12 import *
from contrast12 import test as contrast_test
import contrast12
def summarize(model):
    suffix=f'{model}-77'
    bank=load_np(HERE/f'angular-next-{model}.npz');packet=load_np(HERE/f'matched-state-{suffix}.npz')
    assert packet['q'].size==77 and np.array_equal(packet['q'],2.**(np.arange(-52,25)/4))
    earlier=load_np(parent(f'fine-{model}.npz'));base=load_np(parent(f'base-{model}-s2.npz'))
    assert np.array_equal(packet['q'],earlier['q']) and np.array_equal(packet['k'],bank['k'])
    rows=[];changes=[]
    for index,node in enumerate(range(-52,25)):
        rec=load_np(HERE/f'matched-{model}-q{node}.npz');source=load_np(parent(f'kin-{model}-s2-q{node}.npz'))
        wt=5-rec['q']*np.tanh(rec['q']/2)
        old=source['directDifference'][:,:3,-1]+base['S'][:,:3,-1]+wt*base['Sw'][:,:3,-1]
        now=rec['source'][:,:3,0]+bank['S'][:,:3,0]+wt*bank['Sw'][:,:3,0]
        assert np.array_equal(rec['lagStart'][:19],earlier['massLag'][index])
        rows.append(dict(id=node,q=rec['q'],largest_low_source_jump_fraction=np.max(abs(now-old))/np.max(abs(old)),largest_incident_replay_change=float(np.max(abs(rec['firstOrderJoinChange'])))))
    table('matched-microscopic-join-'+model+'.csv',rows)
    spectral_weight=1-packet['q']*np.tanh(packet['q']/2)
    physical=packet['commonN'][None]+(spectral_weight+4)[:,None,None,None]*packet['shape'][None,:,:,None]+packet['massLag']
    assert np.array_equal(physical,packet['normalEnd'])
    previous=load_np(HERE/f'matched-state-{model}-39.npz');control=load_np(HERE/f'prediction-{model}.npz')['control']
    score(changes,'independent 39 to 77 full feedback stress',packet['stressClock'],['energy','flux','shear','trace'],previous['stress'],packet['stress'])
    score(changes,'independent 39 to 77 gravity increment',packet['eta'],['phi','psi','Weyl','etaF'],(previous['obs']-control)[:,:4],(packet['obs']-control)[:,:4])
    table('fine-cross-'+model+'.csv',changes)
    rows=[]
    for i,mode in enumerate(PROBES):
        for j,component in enumerate(['phi','psi','Weyl','etaF']):
            for free in (0,1):
                reference=control[:,j,i,free];diff=packet['obs'][:,j,i,free]-reference
                rows.append(dict(mode=str(mode),field=component,free=free,peak_fraction=max(abs(diff))/max(abs(reference)),endpoint_signed_re=(diff[-1]/reference[-1]).real,
                                 endpoint_signed_im=(diff[-1]/reference[-1]).imag,endpoint_fraction=abs(diff[-1]/reference[-1])))
    table('gravity-size-'+model+'.csv',rows)
def final():
    for model in ('cold','heavy'):summarize(model)
    def matched(path):
        if path.name.startswith('state-'):path=path.with_name('matched-'+path.name)
        return load_np(path)
    with patch.object(contrast12,'load_np',matched),patch.object(contrast12,'table',renamed(table)):contrast_test('77')
    print('verified joins, retained restart and independent q convergence; matched-scale-a contrasts saved',flush=True)
if __name__=='__main__':final()

