from exact12 import Exact
from joint12 import *
from angular12 import regular,env
import time

class Refine(Exact):
    def __init__(self,model):
        super().__init__(model)
        self.origins=env(model,True,1)
    def run(self,node):
        guard();name=f'matched-{self.model}-q{node}.npz';q=2.**(node/4)
        if (HERE/name).exists():
            with np.load(HERE/name) as packet:
                assert packet['q']==q and np.isfinite(packet['source']).all()
            return
        old=load_np(HERE/f'exact-{self.model}-q{node}.npz')
        inc,_,ref,_=self.origins
        def end():
            init=regular(inc,ref,self.limit+8,q);init[0,0]-=inc.data.first['phi'][:,0]
            history=inc.flight(q,init)
            return history[:,:,:,-1].copy()
        state=end()
        previous=load_np(parent(f'kin-{self.model}-s2-q{node}.npz'))
        earlier_field=np.stack([previous['incidentEnd'],previous['slopeEnd']])
        start_delta=state[:,:27]-earlier_field
        inc,proj,_,_=self.envs['next'];state[0,0]-=inc.data.first['phi'][:,0]
        field,slope=inc.flight(q,state);bank=self.banks['next'];weight=5-q*np.tanh(q/2)
        source=proj.calculate(field,slope,q,maximum=self.limit,match_bulk=False)[0]-bank['S']-weight*bank['Sw']
        lag=self.integrate('next',q,source,old['lagStart'][None])
        pack(name,id=node,q=q,eta=bank['eta'],k=bank['k'],source=source,lagLow=lag[:,:3],lagEnd=lag[-1],lagStart=old['lagStart'],
             incidentEnd=field[:,:,-1],slopeEnd=slope[:,:,-1],firstOrderJoinChange=start_delta,prior_low_check=old['prior_low_check'],source_join=old['source_join'])
        print('matched',self.model,node,flush=True)
class MatchedPopulation(Population):
    def bin(self,node):return load_np(HERE/f'matched-{self.model}-q{node}.npz')

def renamed(function):
    def write(name,*args,**kwargs):return function('matched-'+name,*args,**kwargs)
    return write

if __name__=='__main__':
    import joint12,cross12,quality12
    model=sys.argv[1]
    if sys.argv[2]=='pack':
        compute=Refine(model)
        for node in range(*map(int,sys.argv[3:])):compute.run(node)
    else:
        step=int(sys.argv[3]);label=f'{model}-{len(range(-52,25,step))}'
        def load_matched(path):
            if path.name==f'state-{label}.npz':path=path.with_name('matched-'+path.name)
            return load_np(path)
        if sys.argv[2]=='gravity':
            with patch.object(joint12,'table',renamed(table)),patch.object(joint12,'pack',renamed(pack)):
                MatchedPopulation(model,range(-52,25,step)).run()
        elif sys.argv[2]=='verify':
            for module,key in [(cross12,'balances'),(quality12,'diagnose')]:
                with patch.object(module,'load_np',load_matched),patch.object(module,'Population',MatchedPopulation),patch.object(module,'table',renamed(table)):
                    getattr(module,key)(model,step)
        else:raise ValueError(sys.argv[2])

