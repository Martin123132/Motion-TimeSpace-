from refined12 import *
def run(model):
    compute=Refine(model);prior=compute.prior;older,proj,ref,waves=compute.envs['pre']
    oldbank=compute.banks['pre'];bank=compute.banks['next'];newinc,mission,_,_=compute.envs['next'];fine,_,initial,_=compute.origins
    for node in range(-51,25,2):
        guard();name=f'matched-{model}-q{node}.npz';q=2.**(node/4);weight=5-q*np.tanh(q/2)
        if (HERE/name).exists():
            with np.load(HERE/name) as archived:assert archived['q']==q and np.isfinite(archived['lagLow']).all()
            continue
        state=regular(older,ref,compute.limit+8,q);state[0,0]-=older.data.first['phi'][:,0]
        field,slope=older.flight(q,state);oldsource=proj.calculate(field,slope,q,maximum=compute.limit,match_bulk=False)[0]
        olddrive=oldsource-oldbank['S']-weight*oldbank['Sw']
        seed=compute.integrate('pre',q,olddrive,compute.initial(q))[-1:].copy()
        which=np.flatnonzero(prior['q']==q).item();oldlag=prior['massLag'][which]
        discrepancy=np.max(abs(seed[0,:3]-oldlag[:3]))/np.max(abs(oldlag[:3]));seed[0,:19]=oldlag
        del field,slope
        state=regular(fine,initial,compute.limit+8,q);state[0,0]-=fine.data.first['phi'][:,0]
        state=fine.flight(q,state)[:,:,:,-1].copy();saved=load_np(parent(f'kin-{model}-s2-q{node}.npz'))
        difference=state[:,:27]-np.stack([saved['incidentEnd'],saved['slopeEnd']]);state[0,0]-=newinc.data.first['phi'][:,0]
        field,slope=newinc.flight(q,state);physical=mission.calculate(field,slope,q,maximum=compute.limit,match_bulk=False)[0]
        jump=np.max(abs(physical[:,:3,0]-oldsource[:,:3,-1]))/np.max(abs(oldsource[:,:3,-1]))
        src=physical-bank['S']-weight*bank['Sw'];lag=compute.integrate('next',q,src,seed)
        pack(name,id=node,q=q,eta=bank['eta'],k=waves,source=src,lagLow=lag[:,:3],lagEnd=lag[-1],lagStart=seed[0],
             incidentEnd=field[:,:,-1],slopeEnd=slope[:,:,-1],firstOrderJoinChange=difference,prior_low_check=discrepancy,source_join=jump)
        print('interlaced',model,node,flush=True)
if __name__=='__main__':run(sys.argv[1])

