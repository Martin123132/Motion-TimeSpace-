from refined12 import *
from cross12 import Trace
from contrast12 import vectors
def native(model,earlier):
    pairs=load_np(checked(f'origin-v2-{model}.npz'))['pairs']
    data=load_np(HERE/f'native-accuracy-{model}.npz')
    raw=dict(zip(data['keys'],data['values'][-1].transpose(2,1,0)));scale=raw['sigma']/data['k'];phi=raw['etak']/data['k']-raw['adotoa']*scale
    want=data['eta']<=6.4 if earlier else data['eta']>=6.4
    return np.stack([phi,2*raw['phi']-phi],axis=1)[want]*pairs
def control():
    banks={'early':{},'late':{}}
    for model in ('cold','heavy'):
        modelpop=MatchedPopulation(model,range(-52,25))
        current=load_np(HERE/f'matched-state-{model}-77.npz');early=modelpop.old
        trace=Trace(model,modelpop.bank['S'].shape[1]-1,modelpop.upper,early);trace.trace=True
        _,independent,_,_=trace.evolve(modelpop.t,current['stress'])
        for tag,packet in [('early',early),('late',current)]:
            before=tag=='early';clock=packet['eta'];scale=background(model,before)[0](np.log(clock));obs=packet['obs'][:,:2]
            if before:
                transfer=load_np(parent(f'coupled-{model}-1.npz'))['obs'][:,:2]
            else:transfer=independent[:,:2]
            banks[tag][model]=(clock,scale,obs,transfer,native(model,before))
    records=[];reference={}
    for variation in ('primary','native growing response','trace forcing and response','trace forcing, native response'):
        data={}
        for tag,models in banks.items():
            markers=[1.6,3.2,6.4] if tag=='early' else [8,10,12.8]
            scale=np.min([np.interp(markers,entry[0],entry[1]) for entry in models.values()],axis=0)
            data[tag]=[]
            for clock,grid,obs,trace,native_resp in models.values():
                force=trace[:,:,:,0] if variation.startswith('trace') else obs[:,:,:,0]
                resp=native_resp if 'native' in variation else (trace[:,:,:,1]-force if variation.startswith('trace') else obs[:,:,:,1]-force)
                data[tag].append([CubicSpline(grid,arr)(scale) for arr in (force,resp)])
        for index,mode in enumerate(PROBES):
            early,design,_=vectors(data['early'],index);late,operator,cold=vectors(data['late'],index)
            weights=np.linalg.lstsq(design,-early,rcond=None)[0]
            residual=late+operator@weights
            if variation=='primary':reference[index]=residual
            records.append(dict(variation=variation,mode=str(mode),remaining_over_forced=np.linalg.norm(residual)/np.linalg.norm(late),relative_vector_change=np.linalg.norm(residual-reference[index])/np.linalg.norm(reference[index])))
    table('forecast-robustness.csv',records)
if __name__=='__main__':control()

