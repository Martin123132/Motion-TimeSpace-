from joint12 import *
class Trace(Extended):
    def launch(self,index,free):
        current=super().launch(index,free).copy()
        obs=self.jac_rhs(self.log[index],current[:,:,None],1.,True)
        current[:2]=obs[4:6,:,0]
        return current

def balances(model,step):
    pop=Population(model,range(-52,25,step));suffix=f'{model}-{len(pop.ids)}'
    saved=load_np(HERE/f'state-{suffix}.npz');forcing=load_np(HERE/f'forcing-{model}.npz')
    bg=dict(zip(forcing['bgkeys'],forcing['background']));clock=pop.pred['eta'];k=pop.k[:,None];k2=k*k
    source=np.array([pop.bin(node)['source'][:,:2,:].transpose(2,1,0) for node in pop.ids])
    direct=spline(pop.t,source.transpose(1,0,2,3));spectral=spline(pop.t,pop.bank['Sw'][:,:2].transpose(2,1,0))
    control=pop.pred['control'];normal=pop.pred['controlNormal'];stress=saved['stress']
    q=pop.q;weights=np.full(len(q),np.log(q[1]/q[0]));weights[[0,-1]]/=2
    measure=weights*q**2*expit(q)*expit(-q);shape=pop.w+4
    boundary=[]
    for index,epoch in enumerate(np.log(clock)):
        scale=bg['a'][index];hubble=bg['h'][index];mass=pop.mass*scale;energy=np.hypot(q,mass);change=mass**2/(energy+q);coef=pop.coeff/scale**2
        Ediff=np.dot(measure,q*q*change);Sdiff=np.dot(measure,-q**3*change/energy)
        terms=direct(epoch)
        eSource=((measure*q*q*energy)@terms[:,0]+np.dot(measure*shape,q*q*change)*spectral(epoch)[0])[:,None]
        jSource=((measure*q**3)@terms[:,1])[:,None]
        rE=coef*(eSource+k*Ediff*normal[index,1]);rJ=k*coef*(jSource+k/3*(Sdiff*(normal[index,0]-2*normal[index,2])+Ediff*control[index,1]))
        phi=-(rE+3*hubble*rJ/k2)/(2*k2+3*(bg['et'][index]+bg['pt'][index]));flux=-rJ/(2*k2)
        boundary.append([clock[index]*phi,clock[index]**2*flux])
    trace=Trace(model,pop.bank['S'].shape[1]-1,pop.upper,pop.old);trace.trace=True
    _,unforced,_,_=trace.evolve();_,raw,_,_=trace.evolve(pop.t,stress);_,with_div,_,_=trace.evolve(pop.t,stress,ward=(clock,np.array(boundary)))
    rows=[];select=slice(None,4);labels=['phi','psi','Weyl','etaF'];reference=(saved['obs']-control)[:,select]
    score(rows,'absolute trace vs constraints',clock,labels,raw[:,select],saved['obs'][:,select])
    score(rows,'unbalanced increment',clock,labels,(raw-unforced)[:,select],reference)
    score(rows,'independent trace increment',clock,labels,(with_div-unforced)[:,select],reference)
    table('trace-'+suffix+'.csv',rows)
    print(suffix,[(tag,max(r['peak'] for r in rows if r['test']==tag)) for tag in dict.fromkeys(r['test'] for r in rows)],flush=True)
if __name__=='__main__':balances(sys.argv[1],int(sys.argv[2]))

