from bridge12 import *
from packets import environment,Incident,Project,factorial2
from types import SimpleNamespace
from transport import adv,solve_log
from leading import csr_matrix,eval_legendre

def env(model,earlier,stride):
    if earlier:return environment(model,stride)
    with np.load(HERE/f'incident-input-{model}.npz') as inp,np.load(HERE/f'forcing-{model}.npz') as src:
        data=SimpleNamespace(eta=inp['eta'][::stride],model=model,nodes=inp['k'],shell=np.array(json.loads(pin('legs.json').read_bytes())['squared_radii']),
                             first={key:inp[key][:,::stride] for key in ('phi','psi','pd')},background=dict(zip(src['bgkeys'],src['background'][:,::stride])))
        inc=object.__new__(Incident);inc.data=data;inc.k=data.nodes
        inc.mass=json.loads(ti.parent.pin('radiation-background.json').read_bytes())[model]['mass_over_temperature']
        return inc,Project(data),inp['reference'][:,:,0],src['k']

def regular(inc,ref,limit,q):
    clock=inc.data.eta[0];speed=1 if np.isinf(q) else q/np.hypot(q,inc.mass*inc.data.background['a'][0])
    state=np.zeros((2,limit+1,len(inc.k)));state[0,:3]=ref
    for degree in range(3,limit+1):
        state[0,degree]=(inc.k*clock)**degree*(ref[0]+inc.data.first['psi'][:,0])/factorial2(2*degree+1)
    state[0,1]/=speed;state[1,1]=-(1-speed**2)*state[0,1]
    return state

def tangent_flight(inc,physical):
    times=inc.data.eta;mid=np.interp(np.arange(2*len(times)-1)/2,np.arange(len(times)),times)
    phi=CubicSpline(times,inc.data.first['phi'],axis=1)(mid);psi=CubicSpline(times,inc.data.first['psi'],axis=1)(mid)
    mass=(inc.mass*CubicSpline(times,inc.data.background['a'])(mid))**2
    degree=np.arange(physical.shape[1])[:,None];low=inc.k*degree/(2*degree+1);high=inc.k*(degree+1)/(2*degree+1)
    state=physical.copy();state[0,0]-=phi[:,0]
    def rate(current,index):
        flow=np.zeros_like(current);flow[:,1:]+=low[1:]*current[:,:-1];flow[:,:-1]-=high[:-1]*current[:,1:]
        flow[1]-=mass[index]*flow[0]/2
        flow[0,1]+=inc.k*(phi[:,index]+psi[:,index])/3;flow[1,1]+=inc.k*mass[index]*(psi[:,index]-phi[:,index])/6
        return flow
    samples=[]
    for index in range(0,len(mid),2):
        if index%8==0:
            sample=state.copy();sample[0,0]+=phi[:,index];samples.append(sample)
        if index+1==len(mid):break
        step=mid[index+2]-mid[index];one=rate(state,index);two=rate(state+step*one/2,index+1)
        three=rate(state+step*two/2,index+1);four=rate(state+step*three,index+2)
        state+=step*(one+2*two+2*three+four)/6
    return np.moveaxis(np.array(samples),0,-1)

def direct_tangent(projector,field,tangent,b,limit):
    data=projector.data;phi,psi,pd=[data.first[key][:,::4] for key in ('phi','psi','pd')]
    total=phi+psi;count=len(data.nodes);weight=-2.;result=[]
    for op,wave,radius,cosine,left,right,phase in projector.ops:
        def mix(coefficient,first,second):
            matrix=csr_matrix((phase*np.broadcast_to(coefficient,radius.shape),(left,right)),shape=(count,count))
            return np.einsum('ij,ij->j',matrix@first,second)
        curve=np.zeros((limit+1,len(b)),complex);curve[1]+=b*(mix(radius*cosine,total,psi)-wave*mix(1.,psi,psi))/6
        for degree in range(limit+1):
            leg=eval_legendre(degree,cosine);curve[degree]-=(weight-2)*mix(leg,pd,tangent[degree])
            for index in (degree-1,degree+1):
                if index<0:continue
                beta=(degree if index<degree else -(degree+1))/(2*degree+1)
                incident=beta*radius*leg;other=beta*wave*eval_legendre(index,cosine)-incident
                gradient=(2+index*(index+1)-degree*(degree+1))/2
                curve[degree]+=mix(incident,total,tangent[index])-gradient*mix(other,phi,tangent[index])-(weight-2+gradient)*mix(other,psi,tangent[index])
                curve[degree]-=.5*b*(mix(incident,total,field[index])-gradient*mix(other,phi,field[index])+(weight+gradient)*mix(other,psi,field[index]))
        result.append(curve)
    return np.array(result)

def calc(model,limit=44):
    guard();earlier,oldproj,ref,waves=env(model,True,2)
    state=regular(earlier,ref,limit+8,np.inf);state[1,1]=(earlier.mass*earlier.data.background['a'][0])**2*ref[1]/2
    nextinc,newproj,_,newwaves=env(model,False,1);assert np.array_equal(waves,newwaves)
    for label,inc,proj in [('pre',earlier,oldproj),('next',nextinc,newproj)]:
        if label=='next':
            with np.load(parent(f'base-{model}-s1.npz')) as base,np.load(parent(f'leading-frozen-{model}.npz')) as leading:
                state[0,:27]=base['end'];state[1,:27]=leading['firstTangentEnd']
        field,tangent=tangent_flight(inc,state);clock=inc.data.eta[::4];mass=(inc.mass*inc.data.background['a'][::4])**2
        base=proj.calculate(field,0*field,np.inf,maximum=limit,match_bulk=False)[0]
        spectral=proj.calculate(field,field,np.inf,maximum=limit,match_bulk=False)[0]-base
        response=direct_tangent(proj,field,tangent,mass,limit)
        pack(f'angular-{label}-{model}.npz',eta=clock,k=waves,S=base,Sw=spectral,sourceT=response,incidentEnd=field[:,:,-1],tangentEnd=tangent[:,:,-1],low=field[:3])
        if label=='next':pack(f'collisionless-{model}.npz',eta=clock,source=base)
        state=np.stack([field[:,:,-1],tangent[:,:,-1]])
    print(model,'directional sources ready',flush=True)
if __name__=='__main__':
    for model in sys.argv[1:] or ('cold','heavy'):calc(model)

