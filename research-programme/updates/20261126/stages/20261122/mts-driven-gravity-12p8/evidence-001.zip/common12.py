from angular12 import *
from material_overlap import Readout
from regular_flow import Flight
import regular_flow

def load_np(path):
    with np.load(path) as src:return dict(src.items())

def moments(array,limit):
    result=np.zeros((limit+1,*array.shape[1:]),dtype=array.dtype)
    count=min(len(array),len(result));result[:count]=array[:count];return result

def spline(clock,field):return CubicSpline(np.log(clock),field)

def make_shape(bank,initial):
    clock=bank['eta'];waves=bank['k'];source=spline(clock,bank['Sw'].transpose(2,1,0))
    return solve_log(lambda epoch,shape:adv(shape,waves)+source(epoch)[None,:,:,None],clock,initial[None,:,:,None])[:,0,:,:,0]

def mass_tangent(bank,clock,normal,psi,shape,initial,scale,mass):
    sample=bank['eta'];waves=bank['k'];source=spline(sample,bank['sourceT'].transpose(2,1,0))
    reference=spline(clock,normal);lapse=spline(clock,psi);spectral=spline(sample,shape)
    def rate(epoch,field):
        mass2=(mass*scale(epoch))**2
        derivative=adv(field,waves)-.5*mass2*adv((reference(epoch)+2*spectral(epoch)[:,:,None])[None],waves)+source(epoch)[None,:,:,None]
        derivative[:,1]+=mass2*waves[:,None]*lapse(epoch)/6
        return derivative
    return solve_log(rate,sample,initial[None])[:,0]

def background(model,old):
    data=load_np(checked(f'forcing-{model}.npz') if old else HERE/f'forcing-{model}.npz')
    bg=dict(zip(data['bgkeys'],data['background']));meta=json.loads(ti.parent.pin('radiation-background.json').read_bytes())[model]
    return spline(data['eta'],bg['a']),spline(data['eta'],bg['enu']),meta

def before(model):
    bank=load_np(HERE/f'angular-pre-{model}.npz');limit=bank['S'].shape[1]-1;clock=bank['eta'];waves=bank['k']
    exact=load_np(parent(f'fine-{model}.npz'));regular=load_np(parent(f'forward-{model}-0.npz'))
    metric=spline(exact['eta'],exact['obs'][:,:2])(np.log(clock))
    phi=spline(clock,metric[:,0]);lapse=spline(clock,metric[:,1])
    initial=moments(regular['normal'][0],limit);initial[0]-=regular['obs'][0,0]
    source=spline(clock,bank['S'].transpose(2,1,0))
    def rate(epoch,current):
        derivative=adv(current,waves)+source(epoch)[None,:,:,None]
        derivative[:,1]+=waves[:,None]*(phi(epoch)+lapse(epoch))/3
        return derivative
    normal=solve_log(rate,clock,initial[None])[:,0];normal[:,0]+=metric[:,0]
    spectral=load_np(parent(f'base-{model}-s2.npz'))['Z'][0].T
    shape=make_shape(bank,moments(spectral,limit))
    leading=load_np(parent(f'leading-frozen-{model}.npz'))
    scale,energy,meta=background(model,True)
    field=mass_tangent(bank,clock,normal,metric[:,1],shape,moments(leading['field'][0],limit),scale,meta['mass_over_temperature'])
    pack(f'high-replay-{model}.npz',eta=clock,normal=normal,shape=shape,tangentEnd=field[-1],metric=metric)
    for calculated,frozen in [(normal[-1],exact['commonN']),(shape[-1],exact['shape']),(field[-1],leading['field'][-1])]:
        assert np.isfinite(calculated).all() and np.isfinite(frozen).all()
    return normal[-1],shape[-1],field[-1]

class Extended(Readout):
    def __init__(self,model,limit,replay,exact):
        save('origin-v2-'+model+'.npz',checked('origin-v2-'+model+'.npz').read_bytes())
        with patch.object(regular_flow,'HOME',HERE):Flight.__init__(self,model,limit,6,False,True)
        physical=np.zeros((self.n,5,2),complex)
        for name,prior in zip(exact['keys'],exact['state']):
            if name in self.ix:physical[self.ix[name]]=prior
        for degree in range(19,limit+1):physical[self.ix['N'+str(degree)]]=replay[degree]
        self.join=physical/(self.factors*self.t[0]**self.power[:,None,None])
    def launch(self,index,free):
        assert index==0
        return self.join[:,:,free]

def prepare(model):
    guard();upperN,upperZ,upperY=before(model);exact=load_np(parent(f'fine-{model}.npz'))
    bank=load_np(HERE/f'angular-next-{model}.npz');clock=bank['eta'];limit=bank['S'].shape[1]-1
    leading=load_np(parent(f'leading-frozen-{model}.npz'));upperZ[:19]=exact['shape'];upperY[:19]=leading['field'][-1]
    flow=Extended(model,limit,upperN,exact);times,obs,normal,states=flow.evolve()
    scale,energy,meta=background(model,False);mass=meta['mass_over_temperature'];mass2=(mass*scale(np.log(clock)))**2
    shape=make_shape(bank,upperZ);field=mass_tangent(bank,times,normal,obs[:,1],shape,upperY,scale,mass)
    bump=mass2[:,None,None];delta=np.stack([field[:,0]+bump*shape[:,0,:,None],field[:,1],-field[:,2]+bump*shape[:,2,:,None],
                       np.broadcast_to(2*bump*shape[:,0,:,None],field[:,0].shape)],axis=1)
    multiplier=meta['massless_limit_coeff']/(7*np.pi**4/120)*np.pi**2/6/(scale(np.log(clock))**2*energy(np.log(clock)))
    delta*=multiplier[:,None,None,None]
    _,predicted,norm_pre,state_pre=flow.evolve(clock,delta)
    pack('prediction-'+model+'.npz',eta=times,k=bank['k'],obs=predicted,control=obs,normal=norm_pre,keys=flow.keys,stateEnd=state_pre[-1],
         stress=delta,stressClock=clock,shape=shape,tangent=field,controlNormal=normal)
    gate=[]
    for kind,arr,target in [('native transfer',None,None),('half step',None,None),('angular truncation',None,None)]:
        if kind=='native transfer':
            data=load_np(HERE/f'output-native-{model}.npz');raw=dict(zip(data['keys'],data['values'].transpose(2,0,1)))
            phi=raw['etak']/data['k'][:,None]-raw['adotoa']*raw['sigma']/data['k'][:,None]
            metric=np.stack([phi.T,(2*raw['phi']-phi).T],axis=1)
            pairs=flow.orig['pairs'];arr=predicted[:,:2,:,[1]][:,:,:,0]-predicted[:,:2,:,[0]][:,:,:,0]
            target=metric*pairs
        elif kind=='angular truncation':
            trial=Extended(model,32,upperN,exact);_,coarse,_,_=trial.evolve(clock,delta)
            arr=coarse[:,:2];target=predicted[:,:2]
        else:
            _,coarse,_,_=flow.evolve(clock,delta,step=2);arr=coarse[:,:2];target=predicted[::2,:2]
        for index,mode in enumerate(PROBES):
            for key in range(2):
                err=np.max(abs(arr[:,key,index]-target[:,key,index]),axis=0)/np.maximum(np.max(abs(target[:,key,index]),axis=0),1e-200)
                gate.append(dict(test=kind,mode=str(mode),metric=['phi','psi'][key],max_fraction=float(np.max(err))))
    table('prediction-check-'+model+'.csv',gate)
    print(model,'prediction frozen',[(kind,max(row['max_fraction'] for row in gate if row['test']==kind)) for kind in dict.fromkeys(row['test'] for row in gate)],flush=True)
if __name__=='__main__':
    for model in sys.argv[1:] or ('cold','heavy'):prepare(model)

