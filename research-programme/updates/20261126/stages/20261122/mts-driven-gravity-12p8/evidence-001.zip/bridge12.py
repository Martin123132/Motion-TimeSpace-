from pathlib import Path
import sys,os,hashlib,io,json,csv
for name in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','BLIS_NUM_THREADS','NUMEXPR_NUM_THREADS'):os.environ[name]='1'
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
LAST=HERE.parent/'mts-momentum-gravity-overlap-20261122'
def sha(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
assert sha(LAST/'seal.json')=='54a21c18fef24f8b2db7bfda446e40001a965b325b9a3e29fc4b7f864a134d79'
hashes=json.loads((LAST/'seal.json').read_bytes())['files']
def parent(name):
    path=LAST/name;assert sha(path)==hashes[name],name;return path
for file in ('local.py','packets.py','material_overlap.py','leading.py','transport.py','retarded.py'):parent(file)
sys.path.insert(0,str(LAST))
from local import PRIOR,checked,np,CubicSpline,PROBES,ti,guard as owner_guard,expit
from regular_io import pin,patch
sys.path.insert(0,str(HERE))
def guard():
    owner_guard();assert not (HERE/'STOP-REQUESTED').exists()
def save(name,data):
    guard();p=HERE/name
    if p.exists():assert sha(p)==hashlib.sha256(data).hexdigest(),name
    else:
        with p.open('xb') as f:f.write(data)
def pack(name,**items):
    buf=io.BytesIO();np.savez_compressed(buf,**items);save(name,buf.getvalue())
def table(name,rows):
    buf=io.StringIO();writer=csv.DictWriter(buf,rows[0],lineterminator='\n');writer.writeheader();writer.writerows(rows);save(name,buf.getvalue().encode())
