from refined12 import *
def run(model):
    pop=MatchedPopulation(model,range(-52,25))
    result=load_np(HERE/f'matched-state-{model}-77.npz');history=load_np(HERE/f'high-replay-{model}.npz')
    wave=pop.k;clock=history['eta'];wall=spline(clock,history['normal'][:,19]);order=18
    seed=np.zeros((1,order+1,len(wave),2),complex)
    def correction(epoch,state):
        dr=adv(state,wave)
        dr[:,order]-=wave[:,None]*(order+1)/(2*order+1)*wall(epoch)
        return dr
    delta=solve_log(correction,clock,seed)[-1,0];actual=history['normal'][-1,:19]-pop.old['commonN']
    rows=[]
    for low,high in ((0,2),(3,9),(10,15),(16,18)):
        for col,mode in enumerate(PROBES):
            sl=slice(low,high+1)
            for free in (0,1):
                target=actual[sl,col,free];diff=delta[sl,col,free]-target
                oldscale=np.linalg.norm(pop.old['commonN'][sl,col,free])
                rows.append(dict(mode=str(mode),free=free,low=low,high=high,wall_over_stored=np.linalg.norm(delta[sl,col,free])/oldscale,
                          unexplained_over_stored=np.linalg.norm(diff)/oldscale,unexplained_over_difference=np.linalg.norm(diff)/max(np.linalg.norm(target),1e-200)))
    table('old-wall-cause-'+model+'.csv',rows)
    launch=pop.flow;factor=launch.factors*launch.t[0]**launch.power[:,None,None]
    start=launch.ix['N0'];launch.join[start:start+order+1]+=delta/factor[start:start+order+1]
    tt,obs,normal,states=launch.evolve(pop.t,result['stress'])
    native=load_np(HERE/f'native-accuracy-{model}.npz');indices=np.flatnonzero(native['eta']>=tt[0])
    raw=dict(zip(native['keys'],native['values'][-1].transpose(2,1,0)[:,indices]));assert np.array_equal(tt,native['eta'][indices])
    phi=raw['etak']/wave-raw['adotoa']*raw['sigma']/wave;psi=2*raw['phi']-phi
    transfer=np.stack([phi,psi,raw['clxr']/4-raw['adotoa']*raw['sigma']/wave,raw['pir']/4],axis=1)*launch.orig['pairs']
    before=result['obs'][:,:,:,1]-result['obs'][:,:,:,0];after=obs[:,:,:,1]-obs[:,:,:,0]
    check=[]
    for index,(key,label) in enumerate(((0,'phi'),(1,'psi'),(6,'neutrino density'),(7,'neutrino shear'))):
        for col,mode in enumerate(PROBES):
            target=transfer[:,index,col];old=before[:,key,col]-target;new=after[:,key,col]-target
            check.append(dict(quantity=label,mode=str(mode),before_peak=max(abs(old))/max(abs(target)),after_peak=max(abs(new))/max(abs(target)),
                              before_endpoint=abs(old[-1]/target[-1]),after_endpoint=abs(new[-1]/target[-1]),
                              endpoint_residual_over_original=abs(new[-1])/max(abs(old[-1]),1e-200),
                              worst_pointwise=max(abs(new/target))))
    table('boundary-repair-transfer-'+model+'.csv',check)
    pack('boundary-response-'+model+'.npz',eta=tt,k=wave,omitted_history=wall(np.log(clock)),history_clock=clock,correction_at_seam=delta,obs=obs,state=states[-1],normalEnd=normal[-1])
    print(model,'radiation endpoints before/after',[(label,max(row['before_endpoint'] for row in check if row['quantity']==label),max(row['after_endpoint'] for row in check if row['quantity']==label)) for label in ('neutrino density','neutrino shear')],flush=True)
if __name__=='__main__':run(sys.argv[1])

