from common12 import *
import ast
def rows(name):
    with (HERE/name).open(encoding='utf-8-sig') as stream:return list(csv.DictReader(stream))
def audit():
    receipts=[]
    def test(label,model,data,column,gate=.005,required=True):
        assert data,(label,model);arr=np.array([float(r[column]) for r in data]);assert np.isfinite(arr).all() and min(arr)>=0
        passed=arr<=gate;receipts.append(dict(model=model,test=label,metric=column,count=len(arr),maximum=arr.max(),ceiling=gate,pass_count=int(passed.sum()),all_pass=bool(passed.all()),expected='required' if required else 'reported separately'))
        if required:assert passed.all(),(label,model,arr.max())
    for model in ('cold','heavy'):
        state=load_np(HERE/f'matched-state-{model}-77.npz');previous=load_np(parent(f'fine-{model}.npz'))
        assert state['eta'][0]==previous['eta'][-1] and state['eta'][-1]==12.8 and np.all(np.diff(state['eta'])>0)
        assert state['normalEnd'].shape==(77,45,5,2) and state['state'].shape==(len(state['keys']),5,2) and np.array_equal(state['q'],previous['q'])
        assert all(np.isfinite(value).all() for value in state.values() if value.dtype.kind in 'cfi')
        assert len(rows('native-seam-'+model+'.csv'))==228
        test('capture seam',model,rows('native-seam-'+model+'.csv'),'launch_norm_relative')
        test('driver seam',model,rows('source-join-'+model+'.csv'),'jump_over_peak')
        test('all 77 microscopic joins',model,rows('matched-microscopic-join-'+model+'.csv'),'largest_low_source_jump_fraction')
        direct=rows(f'matched-checks-{model}-77.csv');full=rows(f'fine-cross-{model}.csv')
        for tag in dict.fromkeys(r['test'] for r in direct+full):
            selected=[r for r in direct+full if r['test']==tag]
            for col in ['peak','endpoint']:test(tag,model,selected,col)
        for tag in ('absolute trace vs constraints','independent trace increment'):
            subset=[r for r in rows(f'matched-trace-{model}-77.csv') if r['test']==tag]
            test(tag,model,subset,'peak');test(tag,model,subset,'endpoint')
        for tag in ('half time density increment','lower angular order increment','half time density full','lower angular order full'):
            subset=[r for r in rows(f'matched-resolution-{model}-77.csv') if r['test']==tag]
            test(tag,model,subset,'peak');test(tag,model,subset,'endpoint')
        test('retarded angular propagation',model,rows(f'matched-line-of-sight-{model}-77.csv'),'relative_norm')
        test('massless grid artifact attribution',model,rows('carrier-attribution-'+model+'.csv'),'peak')
        raw=[r for r in rows(f'checks-{model}-39.csv') if r['test']=='leading metric increment']
        test('raw unmatched prediction',model,raw,'peak',required=False);assert max(float(r['peak']) for r in raw)>.1
        native=rows(f'matched-native-transfer-{model}-77.csv')
        test('native all material channels',model,native,'peak')
        test('native individual endpoints',model,native,'endpoint',required=False)
        test('native pointwise near zero included',model,native,'worst_pointwise',required=False)
        boundary=rows(f'boundary-repair-transfer-{model}.csv')
        test('boundary response endpoint',model,boundary,'after_endpoint',required=False)
        test('independent first-order native flight',model,[r for r in rows(f'native-flight-{model}.csv') if r['test']=='native vs independent flight'],'endpoint')
        test('new photon linear transfer',model,rows(f'acoustic-transfer-{model}.csv'),'peak',required=False)
    for name,col in [('forecast-robustness.csv','relative_vector_change'),('acoustic-contrast.csv','route_change_over_primary_residual')]:
        test(name,'both',rows(name),col,required=False)
    assert len(rows('matched-window-contrast-77.csv'))==15 and len(rows('acoustic-contrast.csv'))==20
    for file in HERE.glob('*.py'):ast.parse(file.read_text())
    table('verification.csv',receipts)
def seal():
    guard();assert (HERE/'RESULTS.md').is_file() and (HERE/'verification.csv').is_file()
    assert not any(path.is_dir() for path in HERE.iterdir())
    index={p.name:sha(p) for p in sorted(HERE.iterdir()) if p.name!='seal.json'}
    save('seal.json',json.dumps({'parent_sha256':sha(LAST/'seal.json'),'files':index},indent=2,sort_keys=True).encode())
    saved=json.loads((HERE/'seal.json').read_bytes())['files']
    assert all(sha(HERE/name)==digest for name,digest in saved.items())
    print('Verified',len(saved),'files; seal',sha(HERE/'seal.json'),flush=True)
if __name__=='__main__':
    audit()
    if '--seal' in sys.argv:seal()

