from joint12 import *
def run(model):
    count=39;old=load_np(HERE/f'state-{model}-{count}.npz');new=load_np(HERE/f'matched-state-{model}-{count}.npz')
    bank=load_np(HERE/f'angular-next-{model}.npz');t=bank['eta'];k=bank['k'];limit=bank['S'].shape[1]-1
    twin=load_np(HERE/f'carrier-{model}.npz')
    early,_,ref,_=env(model,True,1);newinc,projector,_,_=env(model,False,1)
    state=regular(early,ref,limit+8,np.inf);state[0,0]-=early.data.first['phi'][:,0]
    state=early.flight(np.inf,state)[:,:,:,-1].copy()
    state[0,0]-=newinc.data.first['phi'][:,0];field,slope=newinc.flight(np.inf,state)
    zero=projector.calculate(field,slope,np.inf,maximum=limit,match_bulk=False)[0]
    spectral=projector.calculate(field,field,np.inf,maximum=limit,match_bulk=False)[0]-zero
    forcing=spline(t,(twin['S']-zero).transpose(2,1,0));nullshape=twin['Sw']-spectral
    initial=np.zeros((1,limit+1,len(k),1),complex)
    ghost=solve_log(lambda epoch,shape:adv(shape,k)+forcing(epoch)[None,:,:,None],t,initial)[:,0,:,:,0]
    scale,energy,meta=background(model,False)
    coefficient=4*meta['massless_limit_coeff']/(scale(np.log(t))**2*energy(np.log(t)))
    spurious=np.stack([ghost[:,0],ghost[:,1],-ghost[:,2],0*ghost[:,0]],axis=1)*coefficient[:,None,None]
    correction=np.broadcast_to(spurious[:,:,:,None],old['stress'].shape);measured=old['stress']-new['stress']
    pop=Population(model,range(-52,25,2));times,metric,_,_=pop.flow.evolve(t,correction)
    peakrows=[]
    score(peakrows,'carrier forecast vs actual grid stress difference',t,['energy','flux','shear'],correction[:,:3],measured[:,:3])
    score(peakrows,'carrier forecast vs actual grid metric difference',times,['phi','psi','Weyl','etaF'],(metric-pop.pred['control'])[:,:4],(old['obs']-new['obs'])[:,:4])
    table('carrier-attribution-'+model+'.csv',peakrows)
    rows=[]
    for idx in (-52,-32,-8,0,8,16,24):
        raw=pop.bin(idx);matched=load_np(HERE/f'matched-{model}-q{idx}.npz')
        q=float(raw['q']);artifact=(twin['S']-zero)+(5-q*np.tanh(q/2))*nullshape
        expected=raw['source']-matched['source']
        norm=lambda arr:np.linalg.norm(arr[:,:3].ravel())
        rows.append(dict(id=idx,q=q,low_relative_residual=norm(artifact-expected)/norm(expected)))
    table('carrier-by-speed-'+model+'.csv',rows)
    print(model,'carrier attribution peak errors',[(tag,max(row['peak'] for row in peakrows if row['test']==tag)) for tag in dict.fromkeys(row['test'] for row in peakrows)],flush=True)
if __name__=='__main__':run(sys.argv[1])

