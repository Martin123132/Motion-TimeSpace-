from bridge12 import *
from capture_early import driver,diag,Dummy,tempfile,subprocess
READ='tau k adotoa etak sigma phi qr clxr pir'.split()
def capture(model,func):
    guard();native=diag.native;status=native.obj(native.source(f'runs/{model}/status.json'))
    path=native.SPEC/'runs/projection/a225-w6-d8.npz' if model=='heavy' else native.NATIVE/'runs/backgrounds/cold.npz'
    native.checked(path,status['source_hash'])
    for item in native.engine.inherited.native_hashes():native.checked(item,status['input_hashes'][str(item)])
    pars=native.engine.inherited.params_for(path,background_boost=8.);pars.DoLateRadTruncation=False
    engine=native.engine.camb.get_background(pars);engine.Params.Accuracy.IntTolBoost=6
    with np.load(checked(f'forcing-{model}.npz')) as left,np.load(HERE/f'forcing-{model}.npz') as right:
        tt=np.r_[left['eta'],right['eta'][1:]];kk=right['k']
    with pin(f'capture-{model}.csv').open() as fp:last=list(csv.DictReader(fp))[-1]
    batch=np.unique(np.r_[kk,float(last['control']),float(last['hierarchy_cap'])]);runs=[]
    with patch.object(diag.symbolic,'compile_sympy_to_camb_source_func',return_value=func):
        for boost in (4,8,12):
            packet=engine.get_time_evolution(batch,tt,vars=[Dummy(key) for key in READ],lAccuracyBoost=boost)[np.searchsorted(batch,kk)]
            assert np.isfinite(packet).all() and np.allclose(packet[:,:,READ.index('k')],kk[:,None],rtol=1e-13,atol=0);runs.append(packet)
    pack(f'native-accuracy-{model}.npz',eta=tt,k=kk,boost=[4,8,12],keys=READ,values=np.stack(runs))
if __name__=='__main__':
    if sys.argv[1:2]==['--child']:
        with patch.object(driver,'HERE',HERE),patch.object(driver,'NAMES',READ),patch.object(driver,'run',capture),patch.object(driver,'save',lambda name,raw:save('accuracy-'+name,raw)):driver.main()
    else:
        with tempfile.TemporaryDirectory(dir=HERE,prefix='reader-accuracy-') as tmp:subprocess.run([sys.executable,'-B',str(HERE/'native_precision12.py'),'--child',tmp,*sys.argv[1:]],check=True)

