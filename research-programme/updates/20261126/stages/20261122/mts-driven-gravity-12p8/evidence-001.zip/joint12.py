from common12 import *
from transport import Kinetic
from scipy.integrate import simpson,cumulative_simpson
from numpy.polynomial.legendre import legvander

def score(rows,tag,clock,labels,values,target):
    for index,label in enumerate(labels):
        for col,mode in enumerate(PROBES):
            for free in (0,1):
                reference=target[:,index,col,free];delta=values[:,index,col,free]-reference
                rows.append(dict(test=tag,quantity=label,mode=str(mode),free=free,peak=max(abs(delta))/max(max(abs(reference)),1e-200),
                                 endpoint=abs(delta[-1])/max(abs(reference[-1]),1e-200)))

class Population:
    def __init__(self,model,ids):
        self.model=model;self.ids=np.asarray(ids);self.q=2.**(self.ids/4);self.w=1-self.q*np.tanh(self.q/2)
        self.pred=load_np(HERE/f'prediction-{model}.npz');self.bank=load_np(HERE/f'angular-next-{model}.npz')
        self.t=self.bank['eta'];self.k=self.bank['k'];self.af,self.energy,meta=background(model,False)
        self.mass=meta['mass_over_temperature'];self.coeff=meta['massless_limit_coeff']/(7*np.pi**4/120)
        self.zpol=spline(self.t,self.pred['shape']);self.upper=load_np(HERE/f'high-replay-{model}.npz')['normal'][-1]
        self.old=load_np(parent(f'fine-{model}.npz'));self.flow=Extended(model,self.bank['S'].shape[1]-1,self.upper,self.old)
    def bin(self,node):return load_np(HERE/f'exact-{self.model}-q{node}.npz')
    def return_flight(self,common,metric):
        out=[];last=[];paths={};normal=spline(self.pred['eta'],common);lapse=spline(self.pred['eta'],metric[:,1])
        for ids in np.array_split(self.ids,int(np.ceil(len(self.ids)/6))):
            guard();records=[self.bin(node) for node in ids]
            q=2.**(ids[:,None,None,None]/4);weights=5-q*np.tanh(q/2);seeds=np.stack([rec['lagStart'] for rec in records])
            forcing=spline(self.t,np.stack([rec['source'].transpose(2,1,0) for rec in records],axis=1))
            def rate(epoch,state):
                mass=self.mass*self.af(epoch);energy=np.hypot(q,mass);velocity=q/energy;slow=-mass**2/(energy*(energy+q))
                background=normal(epoch)[None]+weights*self.zpol(epoch)[None,:,:,None]
                drift=velocity*adv(state,self.k)+slow*adv(background,self.k)+forcing(epoch)[:,:,:,None]
                drift[:,1]+=(-slow/velocity)[:,0]*self.k[None,:,None]*lapse(epoch)[None]/3
                return drift
            sol=solve_log(rate,self.t,seeds);out.append(sol[:,:,:3].copy());last.append(sol[-1].copy())
            for slot,node in enumerate(ids):
                if node in (-52,-32,0,8,24):paths[int(node)]=sol[:,slot].copy()
        return np.concatenate(out,axis=1),np.concatenate(last),paths
    def run(self):
        readings=[self.bin(node) for node in self.ids]
        assert all(np.array_equal(r['eta'],self.t) and r['q']==value for r,value in zip(readings,self.q))
        low=np.stack([r['lagLow'] for r in readings],axis=1);del readings
        stress=Kinetic.stress(self,self.t,low);tt,metric,normal,state=self.flow.evolve(self.t,stress)
        low,end,paths=self.return_flight(normal,metric)
        corrected=Kinetic.stress(self,self.t,low);tt,final,final_normal,states=self.flow.evolve(self.t,corrected)
        assert np.array_equal(tt,self.pred['eta']);control=self.pred['control'];predicted=self.pred['obs'];rows=[]
        finite=final-control
        obskeys=['phi','psi','Weyl','etaF'];stresskeys=['energy','flux','shear','trace']
        score(rows,'leading stress',self.t,stresskeys,self.pred['stress'],corrected)
        score(rows,'leading metric increment',tt,obskeys,(predicted-control)[:,:4],finite[:,:4])
        score(rows,'feedback stress',self.t,stresskeys,stress,corrected)
        score(rows,'feedback metric increment',tt,obskeys,(metric-control)[:,:4],finite[:,:4])
        if len(self.ids)%2==1:
            coarse=Kinetic.stress(self,self.t,low,np.arange(0,len(self.ids),2))
            score(rows,'momentum grid stress',self.t,stresskeys,coarse,corrected)
            _,coarse_metric,_,_=self.flow.evolve(self.t,coarse)
            score(rows,'momentum grid metric increment',tt,obskeys,(coarse_metric-control)[:,:4],finite[:,:4])
        suffix=f'{self.model}-{len(self.ids)}'
        table(f'checks-{suffix}.csv',rows)
        physical=final_normal[-1][None]+(self.w+4)[:,None,None,None]*self.pred['shape'][-1][None,:,:,None]+end
        pack(f'state-{suffix}.npz',eta=tt,k=self.k,q=self.q,keys=self.flow.keys,state=states[-1],obs=final,commonN=final_normal[-1],
             normalEnd=physical,massLag=end,shape=self.pred['shape'][-1],stress=corrected,stressClock=self.t)
        los=[]
        for node,lag in paths.items():
            rec=self.bin(node);q=rec['q'];clock=self.t;log=np.log(clock);vel=q/np.hypot(q,self.mass*self.af(log));weight=5-q*np.tanh(q/2)
            base=spline(tt,normal)(log);metric_on=spline(tt,metric)(log)
            true=base+weight*self.pred['shape'][:,:,:,None]+lag
            born=(self.bank['S']+weight*self.bank['Sw']+rec['source']).transpose(2,1,0);pull=born[:,:,:,None]+np.zeros_like(true)
            pull[:,1]+=self.k[None,:,None]*(vel[:,None,None]*metric_on[:,0]+metric_on[:,1]/vel[:,None,None])/3
            start=true[0].copy();start[0]-=metric_on[0,0]
            travel=cumulative_simpson(vel,x=clock,initial=0);phase=(travel[-1]-travel)[:,None]*self.k
            degree=np.arange(true.shape[1]);lowdeg=degree[:3,None]
            mu,weight_quad=np.polynomial.legendre.leggauss(96);leg=legvander(mu,degree[-1])
            mat=leg[:,:3,None]*leg[:,None,:]*(weight_quad/2)[:,None,None]
            kernel=((np.exp(-1j*phase[:,:,None]*mu)@mat.reshape(96,-1)).reshape(*phase.shape,3,len(degree))*(1j**lowdeg*(-1j)**degree*(2*degree+1))).real
            pieces=np.einsum('tplj,tjpc->tlpc',kernel,pull)
            answer=np.einsum('plj,jpc->lpc',kernel[0],start)+simpson(pieces,x=clock,axis=0)
            answer[0]+=metric_on[-1,0]
            for col,mode in enumerate(PROBES):
                for free in (0,1):
                    norm=np.linalg.norm(true[-1,:3,col,free])
                    los.append(dict(q=float(q),mode=str(mode),free=free,relative_norm=np.linalg.norm(answer[:,col,free]-true[-1,:3,col,free])/norm))
        table(f'line-of-sight-{suffix}.csv',los)
        print(suffix,[(tag,max(row['peak'] for row in rows if row['test']==tag)) for tag in dict.fromkeys(row['test'] for row in rows)],'sky',max(row['relative_norm'] for row in los),flush=True)
if __name__=='__main__':
    Population(sys.argv[1],range(-52,25,int(sys.argv[2]))).run()

