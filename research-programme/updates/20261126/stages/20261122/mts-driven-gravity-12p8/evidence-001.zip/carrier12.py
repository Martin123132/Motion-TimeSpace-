from common12 import *
from hashlib import sha256
def carrier(model):
    previous=load_np(HERE/f'angular-pre-{model}.npz');current=load_np(HERE/f'angular-next-{model}.npz')
    inc,proj,_,waves=env(model,False,1)
    medium=load_np(parent(f'base-{model}-s2.npz'));fine=load_np(parent(f'base-{model}-s1.npz'))
    state=np.stack((previous['incidentEnd'],previous['tangentEnd']));state[0,:27]=medium['end']
    field,tangent=tangent_flight(inc,state)
    common=proj.calculate(field,0*field,np.inf,maximum=44,match_bulk=False)[0]
    spectral=proj.calculate(field,field,np.inf,maximum=44,match_bulk=False)[0]-common
    ref=direct_tangent(proj,field,tangent,(inc.mass*inc.data.background['a'][::4])**2,44)
    pack(f'carrier-{model}.npz',eta=current['eta'],S=common,Sw=spectral,sourceT=ref,
         dS=common-current['S'],dSw=spectral-current['Sw'],deltaLaunch=medium['end']-fine['end'],end=field[:,:,-1])
    rows=[]
    for index,mode in enumerate(PROBES):
        for degree in range(3):
            scale=max(abs(ref[index,degree]))
            rows.append(dict(mode=str(mode),moment=degree,spurious_massless_over_tangent=max(abs(common[index,degree]-current['S'][index,degree]))/scale,
                             spurious_spectral_over_tangent=max(abs(spectral[index,degree]-current['Sw'][index,degree]))/scale))
    table('carrier-null-'+model+'.csv',rows)
    print(model,'largest common incident disagreement',np.max(abs(medium['end']-fine['end'])),'max ratio to tangent',max(row['spurious_massless_over_tangent'] for row in rows),flush=True)
if __name__=='__main__':
    for model in sys.argv[1:] or ('cold','heavy'):carrier(model)

