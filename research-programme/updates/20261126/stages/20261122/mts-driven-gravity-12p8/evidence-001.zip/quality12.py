from joint12 import *

def diagnose(model,step):
    pop=Population(model,range(-52,25,step));suffix=f'{model}-{len(pop.ids)}';archive=load_np(HERE/f'state-{suffix}.npz')
    rows=[];primary=archive['obs'];stress=archive['stress'];control=pop.pred['control'];clock=archive['eta']
    labels=['phi','psi','Weyl','etaF'];sel=slice(None,4)
    for tag,order,stride in [('half time density',44,2),('lower angular order',32,1)]:
        obj=Extended(model,order,pop.upper,pop.old);tt,coarse,_,_=obj.evolve(pop.t,stress,step=stride)
        _,coarse_base,_,_=obj.evolve(step=stride);proper=primary[::stride];base=control[::stride]
        score(rows,tag+' full',tt,labels,coarse[:,sel],proper[:,sel])
        score(rows,tag+' increment',tt,labels,(coarse-coarse_base)[:,sel],(proper-base)[:,sel])
    table('resolution-'+suffix+'.csv',rows)
    joins=[];scale=lambda diff,ref:np.linalg.norm(diff)/max(np.linalg.norm(ref),1e-200)
    for key,name in enumerate(labels):
        for index,mode in enumerate(PROBES):
            for free in (0,1):
                old=pop.old['obs'][-1,key,index,free];now=primary[0,key,index,free]
                joins.append(dict(test='total metric continuity',quantity=name,mode=str(mode),free=free,fraction=abs(now-old)/max(abs(old),1e-200)))
    for index,rec_id in enumerate(pop.ids):
        record=pop.bin(rec_id);oldslot=np.flatnonzero(pop.old['q']==record['q']).item()
        assert np.array_equal(record['lagStart'][:19],pop.old['massLag'][oldslot])
        joins.append(dict(test='replayed old low lag before pinning',quantity='q '+str(record['q']),mode='all',free='both',fraction=float(record['prior_low_check'])))
        joins.append(dict(test='microscopic source seam',quantity='q '+str(record['q']),mode='all',free='both',fraction=float(record['source_join'])))
    for index,tag in enumerate(pop.old['keys']):
        if tag in ('geom','flux'):continue
        rec=pop.flow.join[pop.flow.ix[tag]]*pop.flow.factors[pop.flow.ix[tag]]*pop.flow.t[0]**pop.flow.power[pop.flow.ix[tag]]
        joins.append(dict(test='material restart roundtrip',quantity=str(tag),mode='all',free='both',fraction=scale(rec-pop.old['state'][index],pop.old['state'][index])))
    table('join-'+suffix+'.csv',joins)
    data=load_np(HERE/f'output-native-{model}.npz');raw=dict(zip(data['keys'],data['values'].transpose(2,0,1)));k=pop.k[:,None]
    bg=dict(zip(pop.flow.bgkeys,pop.flow.bg(np.log(clock)).T));alpha=raw['sigma']/k;phi=raw['etak']/k-bg['h']*alpha;tag=pop.flow.tags[-1]
    native=[phi,2*raw['phi']-phi,raw['clxr']/4-bg['h']*alpha,raw['pir']/4,k*(raw['vb']+raw['sigma']),k*(raw['qg']+4*raw['sigma']/3),raw['mts_dphi_'+tag]+bg[tag+'v']*alpha]
    labels2=['phi','psi','neutrino density','neutrino shear','baryon velocity','photon momentum','scalar']
    observ=primary[:,:,:,1]-primary[:,:,:,0];measure=[]
    for index,label,ref in zip([0,1,6,7,8,9,10],labels2,native):
        tar=ref.T*pop.flow.orig['pairs'];signal=observ[:,index]
        for col,mode in enumerate(PROBES):
            gap=signal[:,col]-tar[:,col]
            measure.append(dict(quantity=label,mode=str(mode),peak=max(abs(gap))/max(abs(tar[:,col])),endpoint=abs(gap[-1]/tar[-1,col]),worst_pointwise=max(abs(gap/tar[:,col]))))
    table('native-transfer-'+suffix+'.csv',measure)
    print(suffix,[(tag,max(r['peak'] for r in rows if r['test']==tag)) for tag in dict.fromkeys(r['test'] for r in rows)],
          'seam',max(r['fraction'] for r in joins if r['test']=='total metric continuity'),'linear',max(r['peak'] for r in measure),flush=True)
if __name__=='__main__':diagnose(sys.argv[1],int(sys.argv[2]))

