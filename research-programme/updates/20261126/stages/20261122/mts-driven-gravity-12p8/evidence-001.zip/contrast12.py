from common12 import *

def banks(model,old,version):
    if old:
        forc=load_np(checked(f'forcing-{model}.npz'));obs=load_np(parent(f'fine-{model}.npz'))['obs']
    else:
        forc=load_np(HERE/f'forcing-{model}.npz')
        if version=='frozen':obs=load_np(HERE/f'prediction-{model}.npz')['obs']
        else:obs=load_np(HERE/f'state-{model}-{version}.npz')['obs']
    times=forc['eta'];scale=dict(zip(forc['bgkeys'],forc['background']))['a'];forced=obs[:,:2,: ,0];response=obs[:,:2,:,1]-forced
    return times,scale,forced,response

def matched(old,version):
    points=[1.6,3.2,6.4] if old else [8,10,12.8]
    banks2=[banks(model,old,version) for model in ('cold','heavy')]
    selected=np.min([np.interp(points,data[0],data[1]) for data in banks2],axis=0);out=[]
    for times,scale,forced,response in banks2:
        assert np.all(np.diff(scale)>0) and min(selected)>=min(scale) and max(selected)<=max(scale)
        out.append([CubicSpline(scale,values)(selected) for values in (forced,response)])
    return selected,out

def vectors(data,index):
    (cold,cold_response),(heavy,heavy_response)=data
    values=(heavy-cold)[:,:,index].ravel()
    design=np.column_stack((heavy_response[:,:,index].ravel(),-cold_response[:,:,index].ravel()))
    return values,design,cold[:,:,index].ravel()

def freeze():
    epoch,data=matched(True,None);coeff=[];rows=[]
    for index,mode in enumerate(PROBES):
        contrast,design,cold=vectors(data,index)
        amps,_,rank,singular=np.linalg.lstsq(design,-contrast,rcond=None)
        assert rank==2 and np.linalg.norm(design.conj().T@(contrast+design@amps))<1e-9*np.linalg.norm(design)*np.linalg.norm(contrast)
        coeff.append(amps);rows.append(dict(mode=str(mode),condition=singular[0]/singular[-1],training_residual_fraction=np.linalg.norm(contrast+design@amps)/np.linalg.norm(contrast)))
    table('early-mode-projection.csv',rows);pack('fixed-early-amplitudes.npz',scale=epoch,coefficients=coeff,coord=PROBES)

def test(version):
    fixed=load_np(HERE/'fixed-early-amplitudes.npz');scale,data=matched(False,version);rows=[]
    for index,mode in enumerate(PROBES):
        contrast,design,cold=vectors(data,index)
        flexible=np.linalg.lstsq(design,-contrast,rcond=None)[0]
        for label,amps in [('no free curvature',np.zeros(2)),('fixed from early epochs',fixed['coefficients'][index]),('free in test window',flexible)]:
            residual=contrast+design@amps
            rows.append(dict(model=version,mode=str(mode),preparation=label,start_scale=scale[0],end_scale=scale[-1],forced_norm=np.linalg.norm(contrast),
                             remaining_norm=np.linalg.norm(residual),remaining_over_forced=np.linalg.norm(residual)/np.linalg.norm(contrast),
                             remaining_over_cold_forced=np.linalg.norm(residual)/np.linalg.norm(cold)))
    table('window-contrast-'+version+'.csv',rows)
if __name__=='__main__':
    if sys.argv[1]=='freeze':freeze()
    else:test(sys.argv[1])

