from common12 import *
from scipy.integrate import simpson
from scipy.special import spherical_jn
from numpy.polynomial.legendre import legvander
def calculate(model):
    raw=load_np(HERE/f'native-accuracy-{model}.npz');t=raw['eta'];k=raw['k'];join=np.flatnonzero(t==6.4).item()
    main=load_np(HERE/f'matched-state-{model}-39.npz');assert np.array_equal(t[join:],main['eta'])
    count=len(k);rows=[];guesses={}
    incident=load_np(checked(f'origin-v2-{model}.npz'))['pairs']
    samples=np.arange(join,len(t),4);local=np.arange(0,len(main['eta']),4)
    mu,weights=np.polynomial.legendre.leggauss(64);leg=legvander(mu,2)
    mat=leg[:,:,None]*leg[:,None,:]*(weights/2)[:,None,None]
    for boost,values in zip(raw['boost'],raw['values']):
        fields=dict(zip(raw['keys'],values.transpose(2,1,0)))
        shift=fields['sigma']/k;phi=fields['etak']/k-fields['adotoa']*shift;psi=2*fields['phi']-phi
        native=np.stack([fields['clxr']/4-fields['adotoa']*shift,fields['qr']/4+fields['sigma']/3,fields['pir']/4],axis=1)
        start=native[0].copy();start[0]-=phi[0]
        output=[]
        for index in samples:
            times=t[:index+1];argument=(times[-1]-times[:,None])*k
            kernel=(np.exp(-1j*argument[0,:,None]*mu)@mat.reshape(len(mu),9)).reshape(count,3,3)*(1j**np.arange(3)[:,None]*(-1j)**np.arange(3)*(2*np.arange(3)+1))
            assert np.max(abs(kernel.imag))<1e-12
            end=np.einsum('klj,jk->lk',kernel.real,start)
            signal=(phi[:index+1]+psi[:index+1])*k
            for degree in range(3):end[degree]+=simpson(signal*spherical_jn(degree,argument,derivative=True),x=times,axis=0)
            end[0]+=phi[index];output.append(end)
        light=np.array(output);guesses[int(boost)]=native[samples]
        physical=(main['obs'][local,:,:,1]-main['obs'][local,:,:,0])/incident
        for compare,left,right in [('native vs independent flight',native[samples],light),
                                 ('MTS solver free mode vs independent flight',physical[:,[6,7]],light[:,[0,2]]),
                                 ('MTS solver free mode vs native',physical[:,[6,7]],native[samples][:,[0,2]]),
                                 ('native vs boost 4',native[samples],guesses[4])]:
            names=['density','flux','shear'] if left.shape[1]==3 else ['density','shear']
            for col,mode in enumerate(PROBES):
                for degree,name in enumerate(names):
                    ref=right[:,degree,col];diff=left[:,degree,col]-ref
                    rows.append(dict(test=compare,boost=boost,mode=str(mode),observable=name,peak=max(abs(diff))/max(abs(ref)),
                                     endpoint=abs(diff[-1]/ref[-1]),absolute_endpoint=abs(diff[-1])))
    table('native-flight-'+model+'.csv',rows)
    for tag in dict.fromkeys(r['test'] for r in rows):
        print(model,tag,[(b,max(r['endpoint'] for r in rows if r['test']==tag and r['boost']==b)) for b in raw['boost']],flush=True)
if __name__=='__main__':
    for model in ('cold','heavy'):calculate(model)

