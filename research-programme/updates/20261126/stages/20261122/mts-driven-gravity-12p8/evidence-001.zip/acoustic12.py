from refined12 import *
from contrast12 import vectors
from cross12 import Trace
from capture_early import diag
from scipy.integrate import simpson

def optical(model):
    native=diag.native;status=native.obj(native.source(f'runs/{model}/status.json'))
    path=native.SPEC/'runs/projection/a225-w6-d8.npz' if model=='heavy' else native.NATIVE/'runs/backgrounds/cold.npz'
    native.checked(path,status['source_hash']);params=native.engine.inherited.params_for(path,background_boost=8.)
    engine=native.engine.camb.get_background(params);clock=np.linspace(12.8,25.6,1025)
    fields=engine.get_background_time_evolution(clock,vars=['opacity'],format='dict');opacity=fields['opacity']
    src=load_np(HERE/f'forcing-{model}.npz');actual=dict(zip(src['bgkeys'],src['background']))['opacity'][-1]
    assert np.isfinite(opacity).all() and np.min(opacity)>0 and abs(opacity[0]/actual-1)<.005
    depth=simpson(opacity,x=clock);coarse=simpson(opacity[::2],x=clock[::2])
    pack(f'opacity-only-{model}.npz',eta=clock,opacity=opacity)
    return dict(model=model,start=clock[0],end=clock[-1],tau=depth,step_relative=abs(depth/coarse-1),join_relative=abs(opacity[0]/actual-1),log10_slab_survival=-depth/np.log(10))

def acoustic(model):
    pop=MatchedPopulation(model,range(-52,25));result=load_np(HERE/f'matched-state-{model}-77.npz');banks=[]
    data=load_np(HERE/f'forcing-{model}.npz');bg=dict(zip(data['bgkeys'],data['background']));src=dict(zip(data['keys'],data['values']))
    k=pop.k;clock=pop.pred['eta'];energy=bg['eg'][:,None,None];ratio=(bg['eb']/bg['eg'])[:,None,None]
    native=load_np(HERE/f'output-native-{model}.npz');raw=dict(zip(native['keys'],native['values'].transpose(2,1,0)))
    expected=np.stack([raw['clxg']-4*bg['h'][:,None]*raw['sigma']/k,raw['qg']+4*raw['sigma']/3],axis=1)*pop.flow.orig['pairs']
    checks=[]
    for label in ('constraints','trace'):
        flow=pop.flow if label=='constraints' else Trace(model,pop.bank['S'].shape[1]-1,pop.upper,pop.old)
        if label=='trace':flow.trace=True
        _,obs,_,state=flow.evolve(pop.t,result['stress'])
        gx=state[:,flow.ix['gx']];slip=state[:,flow.ix['B']];mom=state[:,flow.ix['W']]
        density=gx+4*obs[:,0]+src['gE'][:,:,None]/energy
        curr=(slip+4*(mom-slip)/(3*ratio+4)+src['gJ'][:,:,None]/energy)/k[:,None]
        packet=np.stack([density,curr],axis=1);banks.append(packet)
        compare=packet[:,:,:,1]-packet[:,:,:,0]
        for col,mode in enumerate(PROBES):
            for dim,name in enumerate(('energy','current')):
                ref=expected[:,dim,col];gap=compare[:,dim,col]-ref
                checks.append(dict(route=label,mode=str(mode),quantity=name,peak=max(abs(gap))/max(abs(ref)),endpoint=abs(gap[-1]/ref[-1])))
    table('acoustic-transfer-'+model+'.csv',checks)
    pack(f'acoustic-{model}.npz',eta=clock,scale=bg['a'],k=k,keys=['normal fractional energy','normalized covector flux'],constraints=banks[0],trace=banks[1])
    return clock,bg['a'],banks

def main():
    opacity=[optical(model) for model in ('cold','heavy')];table('optical-depth-slab.csv',opacity)
    data=[acoustic(model) for model in ('cold','heavy')];scales=np.min([np.interp([8,10,12.8],item[0],item[1]) for item in data],axis=0)
    amps=load_np(HERE/'fixed-early-amplitudes.npz')['coefficients'];checks=[];bench={}
    for index,route in enumerate(('constraints','trace')):
        vectors_t=[]
        for time,scale,banks in data:
            chosen=CubicSpline(scale,banks[index])(scales)
            vectors_t.append((chosen[:,:,:,0],chosen[:,:,:,1]-chosen[:,:,:,0]))
        for col,mode in enumerate(PROBES):
            diff,design,cold=vectors(vectors_t,col);best=np.linalg.lstsq(design,-diff,rcond=None)[0]
            for tag,coef in [('fixed from early gravity',amps[col]),('best possible in photon window',best)]:
                residual=diff+design@coef;norm=np.linalg.norm(residual)
                if route=='constraints':bench[(col,tag)]=residual
                checks.append(dict(route=route,mode=str(mode),test=tag,forced_norm=np.linalg.norm(diff),remaining_norm=norm,remaining_over_forced=norm/np.linalg.norm(diff),
                              remaining_over_cold_forced=norm/np.linalg.norm(cold),route_change_over_primary_residual=np.linalg.norm(residual-bench[(col,tag)])/np.linalg.norm(bench[(col,tag)])))
    table('acoustic-contrast.csv',checks);print('optical slab',opacity,flush=True)
if __name__=='__main__':main()

