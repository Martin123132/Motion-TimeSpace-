from pal5_tide_io import *
import continuous_force as prior

POINTS=((.43,.53),(-.33,.26),(.65,-.72))

def run():
    edges,angular,cells,_=prior.io.arrays()
    for case in CASES:
        plane,height,_=positions(case)
        nodes=-np.cos(np.pi*np.arange(5)/4);nodes[2]=0.
        field=[]
        for indx,rad in enumerate(nodes):
            guard()
            for idz,alt in enumerate(nodes):
                values=prior.components(plane+rad*3*SIZE,height+alt*3*SIZE,8,160,edges,angular,cells)[-1]
                field.append(dict(i=indx,j=idz,r=rad,z=alt,a_R=values[0],a_z=values[1]))
            print(case,"row",indx,flush=True)
        table("patch-"+case+".csv",field)
        checks=[]
        for rad,alt in POINTS:
            values=prior.components(plane+rad*3*SIZE,height+alt*3*SIZE,12,160,edges,angular,cells)[-1]
            checks.append(dict(r=rad,z=alt,a_R=values[0],a_z=values[1]))
        table("off-grid-"+case+".csv",checks)

if __name__=="__main__":
    run()
