from pal5_tide_io import *
import continuous_force as prior
from scipy.special import ellipkm1,ellipe
material=prior.material
quadrature=prior.quadrature


def kernel(plane,height,dist,signed):
    dz=height-signed
    low=(plane-dist)**2+dz**2
    high=(plane+dist)**2+dz**2
    first=ellipkm1(low/high)
    second=ellipe(4*plane*dist/high)
    root=np.sqrt(high)
    pot=4*first/root
    third=4*second/(low*root)
    fifth=4*(2*(high+low)*second-low*first)/(3*low**2*high*root)
    linear=(third-low*fifth)/(2*plane)
    quad=(pot-2*low*third+low**2*fifth)/(4*plane**2)
    delta=plane-dist
    xx=delta**2*fifth+2*delta*linear+quad
    yy=2*dist*linear-quad
    return G*np.column_stack((3*xx-third,3*yy-third,3*dz**2*fifth-third,3*dz*(delta*fifth+linear)))


def shell_tide(plane,height,inner,outer):
    radius=np.hypot(plane,height)
    if radius<inner:
        return np.zeros(4)
    axis=np.array([plane,0,height])/radius
    if radius>=outer:
        return entries((G*4*np.pi/3*(outer**3-inner**3)/radius**3)*(3*np.outer(axis,axis)-np.eye(3)))
    fraction=(inner/radius)**3
    return entries(-G*4*np.pi*((1-fraction)*np.eye(3)/3+fraction*np.outer(axis,axis)))


def groups(edges,angular,cells):
    mu_edges=np.array([0,1/32,1/16,1/8,1/4,1/2,3/4,1])
    shells=edges[[np.argmin(abs(edges-r)) for r in (0,.5,1,2,3,4,6,8,10,14,20,25,30)]]
    which=np.searchsorted(shells,(edges[1:]+edges[:-1])/2,side="right")-1
    angle=np.searchsorted(mu_edges[1:-1],(angular[1:]+angular[:-1])/2)
    ratios=np.ones((len(shells),7))
    for rid in range(len(shells)):
        for aid in range(7):
            idx=np.ix_(which==rid,angle==aid)
            mass=cells["terminal"][idx].sum()
            if mass:
                ratios[rid,aid]=cells["transported"][idx].sum()/mass
    return mu_edges,shells,ratios


def integrate(plane,height,order,extent,width,group,stride=4):
    mu_faces,shells,ratios=group
    src=prior.source;original=prior.original
    radius0=np.hypot(plane,height)
    inner,outer=radius0-width,radius0+width
    shell_surfaces=np.unique(np.r_[shells,25,30,inner,outer])
    gain0=ratios[np.searchsorted(shells,radius0)-1,np.searchsorted(mu_faces[1:-1],abs(height)/radius0)]
    rho=material.density(np.array([plane]),np.array([height]))[0]
    assert radius0<25
    local=np.array([rho,0.,rho*(gain0-1)])
    azimuth,azw=quadrature(np.array([0.,np.pi/2]),32)
    shifts=np.array([0.,.0001,.001,.007,.03,.12,.5,1.5,4.])
    cuts=np.unique(np.clip(np.r_[0.,extent,np.arange(0,30.1,.75),40.,50.,65.,80.,110.,160.,220.,
        src.radknots,src.stars.centres,shell_surfaces,plane+shifts,plane-shifts,
        abs(height)*np.sqrt(1-mu_faces[1:-1]**2)/mu_faces[1:-1],np.sqrt(np.maximum(0,shell_surfaces**2-height**2))],0,extent))
    cyl,cylw=quadrature(cuts,order)
    col=original.columns(cyl)*(cyl<30)[:,None]
    donors=original.supply(cyl)
    shares=donors/np.maximum(1e-25,donors.sum(axis=1))[:,None]
    z_base=np.r_[0.,src.stars.axis[::stride],src.stars.H,np.geomspace(.0008,extent,44),extent,
                 abs(height)+shifts,abs(height)-shifts,4.,5.,8.,12.,16.,24.,40.,60.,80.]
    out=np.zeros((3,4))
    for idx,(dist,rad_weight) in enumerate(zip(cyl,cylw)):
        zcuts=np.unique(np.clip(np.r_[z_base,np.sqrt(np.maximum(0,shell_surfaces**2-dist**2)),dist*mu_faces[1:-1]/np.sqrt(1-mu_faces[1:-1]**2)],0,extent))
        alt,weights=quadrature(zcuts,order)
        stellar=sum(value*original.zshape(key,alt) for key,value in zip(original.ls.S22,col[idx]))
        removed=col[idx].sum()*sum(shares[idx,j]*src.starshape(alt,j) for j in range(4))
        centre=src.stars.bmass*(original.ls.old.density("E3",(.67,.29,.27),dist*np.cos(azimuth),dist*np.sin(azimuth),alt[:,None])@(azw*2/np.pi))
        density=src.disk(np.array([dist]),alt)+stellar-removed+centre
        assert density.min()>=0
        radius=np.hypot(dist,alt)
        taper=np.clip((30-radius)/5,0,1)
        gain=ratios[np.searchsorted(shells,radius,side="right")-1,np.searchsorted(mu_faces[1:-1],alt/radius)]
        rem=density[:,None]*np.column_stack((np.ones_like(alt),1-taper,taper*(gain-1)))
        rem-=((radius>=inner)&(radius<outer))[:,None]*local
        field=kernel(plane,height,dist,alt)+kernel(plane,height,dist,-alt)
        out+=rem.T@((dist*rad_weight*weights)[:,None]*field)
    out+=local[:,None]*shell_tide(plane,height,inner,outer)
    return np.vstack((out,out[0]+out[2])),np.r_[local,local[0]+local[2]]


def run():
    edges,ang,cells,_=prior.io.arrays()
    group=groups(edges,ang,cells)
    for case in CASES:
        plane,height,_=positions(case)
        for order,extent,width,stride in ((4,80,.5,8),(8,80,.5,4),(8,160,.5,4),(12,160,.5,2),(12,160,1.,2)):
            guard()
            file=f"tensor-{case}-{order}-{extent}-{width}-{stride}.csv"
            values,rho=integrate(plane,height,order,extent,width,group,stride)
            rows=[dict(case=case,source=key,order=order,extent=extent,ref_shell_width=width,knot_stride=stride,
                **dict(zip(NAMES,vec)),density_Msun_kpc3=den,inferred_density=-sum(vec[:3])/(4*np.pi*G)) for key,vec,den in zip(KEYS,values,rho)]
            table(file,rows)
            print(file,flush=True)


if __name__=="__main__":
    run()
