from pal5_tide_io import *
from scipy.linalg import solve_sylvester
from numpy.polynomial import chebyshev as ch


def grid(degree):
    nodes=-np.cos(np.pi*np.arange(degree+1)/degree)
    nodes[degree//2]=0.
    weights=(-1.)**np.arange(degree+1);weights[[0,-1]]*=.5
    diff=nodes[:,None]-nodes
    matrix=(weights/weights[:,None])/(diff+np.eye(degree+1))
    matrix-=np.diag(matrix.sum(axis=1))
    return nodes,matrix


def interpolate(values,loc):
    base,_=grid(len(values)-1)
    return ch.chebval(loc,np.linalg.solve(ch.chebvander(base,len(base)-1),values))


def solve(nodes,deriv,width,plane,edges,rhs):
    operator=deriv@deriv
    horizontal=operator+width/(plane+width*nodes[:,None])*deriv
    values=np.zeros_like(rhs)
    for side,vector in zip(((0,slice(None)),(-1,slice(None)),(slice(None),0),(slice(None),-1)),edges):
        values[side]=interpolate(np.asarray(vector),nodes)
    mask=np.s_[1:-1,1:-1]
    values[mask]=solve_sylvester(horizontal[mask],operator[mask].T,(rhs-horizontal@values-values@operator.T)[mask])
    inv=np.linalg.inv(ch.chebvander(nodes,len(nodes)-1))
    return inv@values@inv.T


def value(coeff,ur,uz):
    return np.sum((ch.chebvander(ur,coeff.shape[0]-1)@coeff)*ch.chebvander(uz,coeff.shape[1]-1),axis=1)


class PoissonPatch:
    def __init__(self,case,label):
        saved=json.loads((HOME/f"solution-{case}-{label}.json").read_bytes())
        self.plane,self.height,_=positions(case);self.width=saved["width"]*SIZE;self.number=label
        self.offset=np.array(saved["conditioning_force"]);self.coeff=np.array(saved["coeff"])
        self.fr=ch.chebder(self.coeff,axis=0);self.fz=ch.chebder(self.coeff,axis=1)
        self.centre_force=self.components(np.array([0.]),np.array([0.]))[0]

    def components(self,ur,uz):
        assert max(np.max(abs(ur)),np.max(abs(uz)))<1+1e-10
        return self.offset-np.column_stack((value(self.fr,ur,uz),value(self.fz,ur,uz)))/self.width

    def force(self,points):
        cyl=np.hypot(points[:,0],points[:,1])
        acc=self.components((cyl-self.plane)/self.width,(points[:,2]-self.height)/self.width)
        return np.column_stack((points[:,:2]*(acc[:,0]/cyl)[:,None],acc[:,1]))-self.centre_force[[0,0,1]]*np.array([1,0,1])

    def tensor(self):
        at=lambda cf:ch.chebval2d(0,0,cf)
        return np.array([-at(ch.chebder(self.fr,axis=0))/self.width**2,self.centre_force[0]/self.plane,
            -at(ch.chebder(self.fz,axis=1))/self.width**2,-at(ch.chebder(self.fr,axis=1))/self.width**2])


CONFIGS=((10,4,9,32),(10,5,9,32),(10,4,9,20),(10,4,9,12),(10,4,5,32),(6,4,9,32),(10,4,9,48))
LABELS=tuple(f"q{order}-w{width}-b{bsize}-n{degree}" for order,width,bsize,degree in CONFIGS)


def manufactured():
    nodes,deriv=grid(12);ur=nodes[:,None];uz=nodes[None,:]
    plane=8.;width=.09
    val=3*ur**3*uz+ur*uz**2+7*uz**4
    rhs=18*ur*uz+2*ur+84*uz**2+width/(plane+width*ur)*(9*ur**2*uz+uz**2)
    coeff=solve(nodes,deriv,width,plane,(val[0,::3],val[-1,::3],val[::3,0],val[::3,-1]),rhs)
    test=np.linspace(-.93,.78,28);other=test[::-1]
    return max(abs(value(coeff,test,other)-(3*test**3*other+test*other**2+7*other**4)))


def build():
    from tensor import prior,material,groups
    faces,rad,gain=groups(*prior.io.arrays()[:3])
    force=read(pin(GREEN,"continuous-forces.csv")); ledger=[]
    control=manufactured();assert control<1e-10,control
    for case in CASES:
        plane,height,_=positions(case)
        ref=next(row for row in force if row["case"]==case and row["source"]=="full" and int(row["order"])==12)
        offset=np.array([float(ref[key]) for key in ("a_R_kms2_kpc","a_z_kms2_kpc")])
        exact=next(row for row in read(HOME/f"tensor-{case}-12-160-0.5-2.csv") if row["source"]=="full")
        for args,label in zip(CONFIGS,LABELS):
            guard(); order,multiple,bsize,degree=args;width=multiple*SIZE
            inp=read(HOME/f"potential-boundary-{case}-{order}.csv")
            nodes,deriv=grid(degree);radii=plane+width*nodes[:,None];heights=height+width*nodes
            def rho(r,z):
                radius=np.hypot(r,z)
                return material.density(r,z)*(1+np.clip((30-radius)/5,0,1)*(gain[np.searchsorted(rad,radius,side="right")-1,np.searchsorted(faces[1:-1],abs(z)/radius)]-1))
            rhs=width**2*(4*np.pi*G*rho(*np.broadcast_arrays(radii,heights))+offset[0]/radii)
            border=np.full((9,9),np.nan)
            for row in inp:
                if int(row["width"])==multiple:
                    border[int(row["i"]),int(row["j"])]=float(row["relative_phi"])+(float(row["plane"])-plane)*offset[0]+(float(row["height"])-height)*offset[1]
            step=8//(bsize-1)
            coeff=solve(nodes,deriv,width,plane,(border[0,::step],border[-1,::step],border[::step,0],border[::step,-1]),rhs)
            record(f"solution-{case}-{label}.json",dict(width=multiple,conditioning_force=offset.tolist(),coeff=coeff.tolist()))
            patch=PoissonPatch(case,label);tidal=patch.tensor()
            for name,prediction in zip(NAMES,tidal):
                target=float(exact[name])
                ledger.append(dict(case=case,label=label,check=name,prediction=prediction,reference=target,relative=abs(prediction/target-1)))
            for name,prediction,target in zip(("centre_R","centre_z","trace"),(*patch.centre_force,sum(tidal[:3])),(*offset,-4*np.pi*G*float(exact["density_Msun_kpc3"]))):
                ledger.append(dict(case=case,label=label,check=name,prediction=prediction,reference=target,relative=abs(prediction/target-1)))
        print(case,flush=True)
    table("poisson-tide-check.csv",ledger);record("poisson-manufactured.json",dict(max_quartic_error=float(control)))

if __name__=="__main__":
    build()
