import os
for key in ("OMP_NUM_THREADS","OPENBLAS_NUM_THREADS","MKL_NUM_THREADS","NUMEXPR_NUM_THREADS","BLIS_NUM_THREADS"):
    os.environ[key]="1"
import csv
import hashlib
import io
import json
import sys
from pathlib import Path
import numpy as np

HOME=Path(__file__).resolve().parent
ROOT=HOME.parent
GREEN=ROOT/"mts-pal5-positive-source-20261122"
WORK=ROOT/"mts-pal5-interface-work-20261122"
G=4.30091727003628e-6
CONV=1/977.7922216807892
SIZE=20.6*np.tan(np.deg2rad(3.21/60))
MASS=4297.
CASES=("ordinary","reset_forward")
KEYS=("terminal","exterior","increment","full")
NAMES=("RR","pp","zz","Rz")


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def check_source(folder,name,seal):
    assert digest(folder/"seal.json")==seal
    assert digest(folder/name)==json.loads((folder/"seal.json").read_bytes())[name],name
    return folder/name


def pin(folder,name):
    return check_source(folder,name,{GREEN:"c918bbe06f2a0be4785be9cf580dd91b493541fce8b4309d9a7622cc6248baf9",WORK:"e8891d2372d597e163d1f8de482c0884eac39405223b34e7b9d0eee10f7e2723"}[folder])


def guard():
    for folder in (HOME,ROOT,WORK,GREEN,ROOT/"mts-fire-joint-baryon-history-20261120"):
        if (folder/"STOP-REQUESTED").exists():
            raise RuntimeError("Owner hold: "+str(folder))


def keep(name,raw):
    path=HOME/name
    if path.exists():
        assert path.read_bytes()==raw,name
    else:
        with path.open("xb") as stream:
            stream.write(raw)


def table(name,rows):
    stream=io.StringIO()
    writer=csv.DictWriter(stream,fieldnames=list(rows[0]),lineterminator="\n")
    writer.writeheader()
    writer.writerows(rows)
    keep(name,stream.getvalue().encode())


def read(path):
    with path.open() as stream:
        return list(csv.DictReader(stream))


def record(name,data):
    keep(name,(json.dumps(data,sort_keys=True,indent=2,allow_nan=False)+"\n").encode())


def positions(case):
    with np.load(pin(WORK,"hist-4-2-A-"+case+".npz")) as data:
        xyz=data["centre"][0,:3]
    plane=np.hypot(*xyz[:2]);height=xyz[2]
    axes=np.array([[xyz[0]/plane,-xyz[1]/plane,0],[xyz[1]/plane,xyz[0]/plane,0],[0,0,1]])
    return plane,height,axes


def square(values):
    rr,pp,zz,rz=values
    return np.array([[rr,0,rz],[0,pp,0],[rz,0,zz]])


def entries(matrix):
    return matrix[[0,1,2,0],[0,1,2,2]]


guard()
for name in ("experiment.py","gravity.py","cell_green.py","direct_census.py","continuous_force.py"):
    pin(GREEN,name)
sys.path.insert(0,str(GREEN))
