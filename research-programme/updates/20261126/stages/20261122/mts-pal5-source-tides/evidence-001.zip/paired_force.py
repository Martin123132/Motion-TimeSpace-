from tensor import prior,groups,quadrature,material,ellipe,ellipkm1
from pal5_tide_io import *


def ring_force(plane,height,dist,signed):
    sep=height-signed; low=(plane-dist)**2+sep**2; high=(plane+dist)**2+sep**2
    first=ellipkm1(low/high);second=ellipe(4*plane*dist/high)
    factor=-2*G/np.sqrt(high)
    return np.stack((factor*(first+(plane**2-dist**2-sep**2)*second/low)/plane,
                     factor*2*sep*second/low),axis=-1)


def evaluate(plane,height,order,extent,steps,group):
    mu_faces,shells,ratios=group
    centres=np.array([(plane,height)]+[(plane+sx*step,height+sz*step) for step in steps for sx,sz in ((1,0),(-1,0),(0,1),(0,-1))])
    rad=np.hypot(centres[:,0],centres[:,1]);inner,outer=rad[0]-.5,rad[0]+.5
    assert min(rad)>inner and max(rad)<outer
    gains=ratios[np.searchsorted(shells,rad)-1,np.searchsorted(mu_faces[1:-1],abs(centres[:,1])/rad)]
    rho=material.density(*centres.T);local=np.column_stack((rho,0*rho,rho*(gains-1)))
    src=prior.source;original=prior.original
    boundaries=np.unique(np.r_[shells,25,30,inner,outer])
    offsets=np.array([0,.00005,.00025,.001,.004,.02,.12,.5,1.5,4])
    shifts=np.r_[-offsets[:0:-1],offsets]
    cyl_bounds=np.unique(np.clip(np.r_[0.,extent,np.arange(0,30.1,.75),40.,50.,65.,80.,110.,
        src.radknots,src.stars.centres,boundaries,(np.unique(centres[:,0])[:,None]+shifts).ravel(),
        abs(height)*np.sqrt(1-mu_faces[1:-1]**2)/mu_faces[1:-1],np.sqrt(np.maximum(0,boundaries**2-height**2))],0,extent))
    cyl,cylw=quadrature(cyl_bounds,order)
    col=original.columns(cyl)*(cyl<30)[:,None];donors=original.supply(cyl)
    shares=donors/np.maximum(1e-25,donors.sum(axis=1))[:,None]
    zbase=np.r_[0.,src.stars.axis[::2],src.stars.H,np.geomspace(.0008,extent,44),extent,
        (np.unique(abs(centres[:,1]))[:,None]+shifts).ravel(),4.,5.,8.,12.,16.,24.,40.,60.,80.]
    az,aw=quadrature(np.array([0.,np.pi/2]),32)
    out=np.zeros((len(rad),3,2))
    for idx,(dist,wc) in enumerate(zip(cyl,cylw)):
        zcuts=np.unique(np.clip(np.r_[zbase,np.sqrt(np.maximum(0,boundaries**2-dist**2)),dist*mu_faces[1:-1]/np.sqrt(1-mu_faces[1:-1]**2)],0,extent))
        alt,wz=quadrature(zcuts,order)
        stellar=sum(value*original.zshape(key,alt) for key,value in zip(original.ls.S22,col[idx]))
        removed=col[idx].sum()*sum(shares[idx,j]*src.starshape(alt,j) for j in range(4))
        centre=src.stars.bmass*(original.ls.old.density("E3",(.67,.29,.27),dist*np.cos(az),dist*np.sin(az),alt[:,None])@(aw*2/np.pi))
        den=src.disk(np.array([dist]),alt)+stellar-removed+centre
        radius=np.hypot(dist,alt)
        taper=np.clip((30-radius)/5,0,1)
        gain=ratios[np.searchsorted(shells,radius,side="right")-1,np.searchsorted(mu_faces[1:-1],alt/radius)]
        src_den=den[:,None]*np.column_stack((np.ones_like(alt),1-taper,taper*(gain-1)))
        ring=(radius>=inner)&(radius<outer)
        for probe,(pr,pz) in enumerate(centres):
            rem=src_den-ring[:,None]*local[probe]
            kern=ring_force(pr,pz,dist,alt)+ring_force(pr,pz,dist,-alt)
            out[probe]+=rem.T@((wc*dist*wz)[:,None]*kern)
    out-=4*np.pi*G/3*(1-(inner/rad)**3)[:,None,None]*local[:,:,None]*centres[:,None,:]
    out=np.concatenate((out,out[:,0:1]+out[:,2:3]),axis=1)
    rows=[]
    for idx,step in enumerate(steps):
        plus,minus,above,below=out[1+4*idx:5+4*idx]
        dx=(plus-minus)/(2*step);dz=(above-below)/(2*step)
        for j,key in enumerate(KEYS):
            rr,zr=dx[j];rz,zz=dz[j];pp=out[0,j,0]/plane
            rows.append(dict(order=order,step=step,source=key,RR=rr,pp=pp,zz=zz,Rz=rz,zR=zr,fd_density=-(rr+pp+zz)/(4*np.pi*G)))
    return rows


def run():
    edges,ang,cells,_=prior.io.arrays()
    group=groups(edges,ang,cells)
    for case in CASES:
        plane,height,_=positions(case)
        for order in (6,10):
            guard()
            rows=evaluate(plane,height,order,160.,(.004,.002,.001),group)
            name=f"common-grid-fd-{case}-{order}.csv"
            table(name,rows);print(name,flush=True)


if __name__=="__main__":
    run()
