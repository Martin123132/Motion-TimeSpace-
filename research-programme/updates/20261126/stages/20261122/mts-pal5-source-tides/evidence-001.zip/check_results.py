from poisson_patch import LABELS
from pal5_tide_io import *


def verify():
    ledger=read(HOME/"poisson-finite-work.csv");tests=[];summary=[]
    assert len(ledger)==2*3*3*8*6
    lookup={(row["case"],int(row["order"]),int(row["aperture"]),row["field"],row["source"]):row for row in ledger}
    assert len(lookup)==len(ledger)
    fid=LABELS[0]
    def check(case,test,aperture,component,observed,reference):
        observed,reference=float(observed),float(reference)
        assert np.isfinite([observed,reference]).all()
        relative=0. if observed==reference==0 else abs(observed-reference)/abs(reference)
        tests.append(dict(case=case,test=test,aperture=aperture,component=component,relative=relative,passes=relative<=.005))
    for case in CASES:
        for ap in (1,2,3):
            for source in ("ordinary","added","total","ordinary_alone","wave_square","twice_cross"):
                def row(label,order=24):
                    return lookup[case,order,ap,label,source]
                final=row(fid);energy=float(final["energy_curvature"])
                for label in LABELS[1:]:
                    check(case,"compare_"+label,ap,source,row(label)["energy_curvature"],energy)
                for term in ("square","pressure","energy_curvature"):
                    check(case,"aperture_order",ap,source+"_"+term,row(fid,16)[term],final[term])
                if source in ("ordinary","added","total","ordinary_alone"):
                    check(case,"independent_bulk_work",ap,source,final["direct_moment"],energy)
                if source=="ordinary":
                    check(case,"independent_local_mass",ap,source,final["flux_mass"],final["mass_used"])
                summary.append(dict(case=case,aperture=ap,channel=source,source_based=energy,old=float(row("native")["energy_curvature"])))
            def actual(label):
                return float(lookup[case,24,ap,fid,label]["energy_curvature"])
            pressure=float(lookup[case,24,ap,fid,"added"]["pressure"])
            assert np.isclose(actual("total"),actual("ordinary_alone")+actual("twice_cross")+actual("wave_square")+pressure,rtol=1e-12,atol=1e-19)
    for row in read(HOME/"poisson-patch-independent-check.csv"):
        if row["nodes"]==fid:
            for key in ("rel_vector","rel_R","rel_z"):
                check(row["case"],"off_grid",row["r"]+"/"+row["z"],key,1+float(row[key]),1)
    for row in read(HOME/"poisson-tide-check.csv"):
        if row["label"]==fid:
            check(row["case"],"gradient_and_tide",0,row["check"],row["prediction"],row["reference"])
    table("source-patch-verification.csv",tests);table("source-work-comparison.csv",summary)
    counts={key:{"n":len(vals),"misses":sum(not item["passes"] for item in vals),"worst":max(item["relative"] for item in vals)}
      for key in sorted(set(item["test"] for item in tests)) if (vals:=[item for item in tests if item["test"]==key])}
    record("source-patch-verification.json",counts)
    print(json.dumps(counts,indent=1))

if __name__=="__main__":
    verify()
