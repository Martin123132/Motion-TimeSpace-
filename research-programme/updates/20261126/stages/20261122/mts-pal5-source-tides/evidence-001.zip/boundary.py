from tensor import prior,quadrature,groups,material,ellipkm1
from pal5_tide_io import *


def calculate(case,order,group):
    plane,height,_=positions(case)
    nodes=-np.cos(np.pi*np.arange(9)/8);nodes[4]=0.
    positions_list=[(plane,height)]
    tags=[(0,0,0)]
    for width in (4,5):
        for ir,ur in enumerate(nodes):
            for iz,uz in enumerate(nodes):
                if ir in (0,8) or iz in (0,8):
                    positions_list.append((plane+width*SIZE*ur,height+width*SIZE*uz))
                    tags.append((width,ir,iz))
    pts=np.array(positions_list);pr,pz=pts.T
    radius=np.hypot(pr,pz)
    mu_faces,shells,ratios=group
    local=material.density(pr,pz)*ratios[np.searchsorted(shells,radius)-1,np.searchsorted(mu_faces[1:-1],abs(pz)/radius)]
    inner,outer=radius[0]-.6,radius[0]+.6
    assert inner<min(radius) and max(radius)<outer
    surfaces=np.unique(np.r_[shells,25,30,inner,outer]);extent=160.
    src=prior.source;original=prior.original
    shifts=np.array([-.15,-.02,-.002,0,.002,.02,.15])
    cuts=np.unique(np.clip(np.r_[0.,extent,np.arange(0,30.1,.75),40.,50.,65.,80.,110.,
        src.radknots,src.stars.centres,surfaces,(np.unique(pr)[:,None]+shifts).ravel(),
        abs(height)*np.sqrt(1-mu_faces[1:-1]**2)/mu_faces[1:-1],np.sqrt(np.maximum(0,surfaces**2-height**2))],0,extent))
    cyl,cylw=quadrature(cuts,order)
    col=original.columns(cyl)*(cyl<30)[:,None];donors=original.supply(cyl)
    shares=donors/np.maximum(1e-25,donors.sum(axis=1))[:,None]
    zbase=np.r_[0.,src.stars.axis[::2],src.stars.H,np.geomspace(.0008,extent,44),extent,
        (np.unique(abs(pz))[:,None]+shifts).ravel(),4.,5.,8.,12.,16.,24.,40.,60.,80.]
    az,aw=quadrature(np.array([0.,np.pi/2]),32)
    acc=np.zeros(len(pts))
    for idx,(dist,wc) in enumerate(zip(cyl,cylw)):
        zcuts=np.unique(np.clip(np.r_[zbase,np.sqrt(np.maximum(0,surfaces**2-dist**2)),dist*mu_faces[1:-1]/np.sqrt(1-mu_faces[1:-1]**2)],0,extent))
        alt,wz=quadrature(zcuts,order)
        stellar=sum(value*original.zshape(key,alt) for key,value in zip(original.ls.S22,col[idx]))
        removed=col[idx].sum()*sum(shares[idx,j]*src.starshape(alt,j) for j in range(4))
        centre=src.stars.bmass*(original.ls.old.density("E3",(.67,.29,.27),dist*np.cos(az),dist*np.sin(az),alt[:,None])@(aw*2/np.pi))
        base=src.disk(np.array([dist]),alt)+stellar-removed+centre
        rr=np.hypot(dist,alt);taper=np.clip((30-rr)/5,0,1)
        gain=ratios[np.searchsorted(shells,rr,side="right")-1,np.searchsorted(mu_faces[1:-1],alt/rr)]
        matter=wc*dist*wz*base*(1+taper*(gain-1))
        window=wc*dist*wz*((rr>=inner)&(rr<outer))
        for first in range(0,len(pts),8):
            sl=slice(first,first+8)
            pp=pr[sl,None];zz=pz[sl,None]
            field=0
            for signed in (alt,-alt):
                dz=(zz-signed)**2;hi=(pp+dist)**2+dz;lo=(pp-dist)**2+dz
                field=field-4*G*ellipkm1(lo/hi)/np.sqrt(hi)
            acc[sl]+=field@matter-local[sl]*(field@window)
    comp=-4*np.pi*G*((radius**3-inner**3)/(3*radius)+(outer**2-radius**2)/2)
    acc+=local*comp
    rows=[dict(case=case,order=order,width=width,i=ir,j=iz,plane=pp,height=zz,relative_phi=phi-acc[0],absolute_phi=phi)
          for (width,ir,iz),(pp,zz),phi in zip(tags,pts,acc)]
    table(f"potential-boundary-{case}-{order}.csv",rows)


def run():
    edges,ang,cells,_=prior.io.arrays()
    group=groups(edges,ang,cells)
    for case in CASES:
        for order in (6,10):
            guard();calculate(case,order,group);print(case,order,flush=True)


if __name__=="__main__":
    run()
