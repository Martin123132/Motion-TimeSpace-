from pal5_tide_io import *

JOINED=ROOT/"mts-pal5-joined-flow-586-600-20261122"
SEAL="86d9b1296c253b14a04e475339a9cbf71f84fed201749a234af4892b715576b7"


def verify_read(name):
    return read(check_source(JOINED,name,SEAL))


def run():
    outputs=[]
    for grid_id in ("4-1","4-2"):
        events=verify_read(f"escapes-{grid_id}.csv")
        assert len(events)==72
        for arm in ("reset","coupled"):
            for dist in ("20.9","22.05","23.2"):
                for tail in ("inner","outer"):
                    choose=lambda sign:sorted((row for row in events if (row["arm"],row["distance"],row["tail"],row["flow"])==(arm,dist,tail,sign)),key=lambda row:float(row["release"]))
                    for injected,other in (("forward","reverse"),("reverse","forward")):
                        own=choose(injected);opposite=choose(other);times=np.array([float(row["release"]) for row in own])
                        assert len(own)==len(opposite)==3 and all(np.diff(times)==10) and np.array_equal(times,[float(row["release"]) for row in opposite])
                        for component in ("ra_deg","dec_deg","vlos_kms"):
                            target=float(own[1][component]);values=np.array([float(row[component]) for row in opposite])
                            crossings=[]
                            for low,high in ((0,1),(1,2)):
                                if min(values[low],values[high])<=target<=max(values[low],values[high]):
                                    crossings.append(times[low]-times[1]+10*(target-values[low])/(values[high]-values[low]))
                            outputs.append(dict(grid=grid_id,arm=arm,distance=dist,tail=tail,injected=injected,component=component,
                                bracketed=bool(crossings),time_shift_linear_Myr=min(crossings,key=abs) if crossings else None,
                                centre_difference=target-values[1]))
    table("release-time-brackets.csv",outputs)
    rows=[row for row in outputs if row["grid"]=="4-2"]
    assert len(rows)==72
    for lhs,rhs in zip(outputs[:72],rows):
        assert all(lhs[key]==rhs[key] for key in ("arm","distance","tail","injected","component","bracketed"))
    tracks=[row for row in verify_read("summary-4-2.csv") if row["case"]=="both"]
    assert len(tracks)==6
    decision=dict(single_coordinate_brackets=sum(row["bracketed"] for row in rows),tests=len(rows),
       maximum_abs_secant_equivalent_Myr=max(abs(row["time_shift_linear_Myr"]) for row in rows if row["bracketed"]),
       max_velocity_gradient_error_units=max(float(row["gradient_sigma"]) for row in tracks),
       max_single_sky_bin_error_units=max(float(row["max_bin_sigma"]) for row in tracks),
       max_cluster_relative_pc=max(float(row["max_pc"]) for row in tracks),
       minimum_early_late_over_sign=min(float(row["smaller_timing_over_sign"]) for row in verify_read("timing-4-2.csv")),
       fractional_coverage_1940_5000_Myr=[111.158776/duration for duration in (1940,5000)])
    record("stream-decision.json",decision)
    print(decision)

if __name__=="__main__":
    run()
