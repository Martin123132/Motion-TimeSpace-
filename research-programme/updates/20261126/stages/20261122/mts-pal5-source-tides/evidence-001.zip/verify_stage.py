from pal5_tide_io import *
import re


def seal():
    from release_bracket import JOINED,SEAL
    for folder,expected in ((GREEN,"c918bbe06f2a0be4785be9cf580dd91b493541fce8b4309d9a7622cc6248baf9"),(WORK,"e8891d2372d597e163d1f8de482c0884eac39405223b34e7b9d0eee10f7e2723"),(JOINED,SEAL)):
        assert digest(folder/"seal.json")==expected
        for name,hashcode in json.loads((folder/"seal.json").read_bytes()).items():
            assert digest(folder/name)==hashcode,(folder,name)
    for link in re.findall(r"\]\(([^)]+)\)",(HOME/"RESULTS.md").read_text(encoding="utf8")):
        assert link.startswith("https://") or (HOME/link).is_file(),link
    primary=json.loads((HOME/"source-patch-verification.json").read_bytes())
    for name,count in (("independent_local_mass",6),("independent_bulk_work",24),("off_grid",18),("aperture_order",108),("gradient_and_tide",14),("compare_q10-w4-b9-n48",36)):
        assert primary[name]["n"]==count and primary[name]["misses"]==0
    assert sum(row["misses"] for row in primary.values())==8
    checks=json.loads((HOME/"audit.json").read_bytes())
    assert checks["fixed_grid_fd"]["count"]==40 and not checks["fixed_grid_fd"]["misses"]
    assert checks["interpolated_force_flux"]["misses"]==3
    assert len(read(HOME/"release-time-brackets.csv"))==144
    stream=json.loads((HOME/"stream-decision.json").read_bytes())
    assert (stream["single_coordinate_brackets"],stream["tests"])==(68,72)
    assert all(len(read(HOME/f"potential-boundary-{case}-{order}.csv"))==65 for case in CASES for order in (6,10))
    targets=sorted(file for file in HOME.iterdir() if file.name!="seal.json")
    assert all(file.is_file() and file.stat().st_size>0 for file in targets)
    for file in targets:
        if file.suffix==".csv":
            rows=read(file);assert len(rows)>0 and all(None not in row and None not in row.values() for row in rows),file.name
        elif file.suffix==".py":
            compile(file.read_bytes(),str(file),"exec")
    record("seal.json",{file.name:digest(file) for file in targets})
    for name,hashcode in json.loads((HOME/"seal.json").read_bytes()).items():
        assert digest(HOME/name)==hashcode,name
    print(len(targets),digest(HOME/"seal.json"))

if __name__=="__main__":
    seal()
