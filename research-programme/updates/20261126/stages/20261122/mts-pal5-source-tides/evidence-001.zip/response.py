from pal5_tide_io import *


def matrices(case):
    old=np.asarray(json.loads(pin(WORK,"affine-tensors.json").read_bytes())[case])/CONV**2
    _,_,axes=positions(case)
    old=np.stack([axes.T@(value+value.T)@axes/2 for value in old])
    row=read(HOME/f"tensor-{case}-12-160-0.5-2.csv")[-1]
    assert row["source"]=="full"
    new=square([float(row[name]) for name in NAMES])
    return {"native":old,"continuous":np.stack((new,old[1]))}


def moments(shell):
    clip=shell/np.sqrt(1+shell**2)
    return 3*SIZE**2*(np.arcsinh(shell)-clip-clip**3/3)/clip**3,G*MASS/(6*SIZE)*(1+shell**2)**(-1.5)


def response():
    worlds=[];measures=[];comparisons=[];derivations=[]
    old_circular=read(pin(WORK,"early-predicted-4-2-A.csv"));old_cloud=read(pin(WORK,"aperture-predictions.csv"))
    for case in CASES:
        bases=matrices(case)
        for label,pair in bases.items():
            total=np.sum(pair,axis=0)
            for source,tide in zip(("ordinary","added","total"),[*pair,total]):
                eigen=np.linalg.eigvalsh(tide)
                trace=np.trace(tide)
                shear=tide-np.eye(3)*trace/3
                worlds.append(dict(case=case,field=label,source=source,**dict(zip(NAMES,entries(tide))),trace=trace,
                    shear_norm=np.linalg.norm(shear),eigen_min=eigen[0],eigen_mid=eigen[1],eigen_max=eigen[2]))
                for shell in (1,2,3):
                    mean_r2,stress=moments(shell)
                    contract=np.sum(total*tide)
                    linear=(shell*SIZE)**2/3*contract*CONV**2
                    square_term=mean_r2/3*contract*CONV**2
                    press=stress*trace*CONV**2
                    if label=="native":
                        for previous,quantity,key,value in ((old_circular,"shell","linear",linear),(old_cloud,"aperture","full",square_term+press)):
                            saved=float(next(row for row in previous if row["case"]==case and row["source"]==source and int(row[quantity])==shell)[key])
                            assert abs(value-saved)<1e-10*abs(saved) if saved else value==0
                    measures.append(dict(case=case,field=label,source=source,aperture=shell,circular=linear,
                        tensor_square=square_term,pressure=press,cloud=square_term+press))
        for index,key in ((0,"ordinary"),(2,"total")):
            first,second=[pair[index] if index<2 else pair.sum(axis=0) for pair in bases.values()]
            vals,vecs=np.linalg.eigh(first);new,dirs=np.linalg.eigh(second)
            alignment=np.arccos(np.clip(abs(np.sum(dirs*vecs,axis=0)),0,1))*180/np.pi
            comparisons.append(dict(case=case,source=key,Frobenius_change=np.linalg.norm(second-first)/np.linalg.norm(first),
                largest_stretch_axis_tilt_deg=alignment[-1],strongest_compression_tilt_deg=alignment[0],
                min_eigen_rel_change=new[0]/vals[0]-1,max_eigen_rel_change=new[-1]/vals[-1]-1))
        for shell in (1,2,3):
            before,after=[next(row for row in measures if row["field"]==key and row["case"]==case and row["aperture"]==shell and row["source"]=="total") for key in bases]
            derivations.append(dict(case=case,aperture=shell,relative_circular_shift=after["circular"]/before["circular"]-1,
                relative_cloud_shift=after["cloud"]/before["cloud"]-1,square_change=after["tensor_square"]-before["tensor_square"],
                pressure_change=after["pressure"]-before["pressure"],native_cloud=before["cloud"],new_cloud=after["cloud"]))
    table("tidal-tensors.csv",worlds);table("eigen-comparison.csv",comparisons)
    table("affine-work.csv",measures);table("change-in-affine-work.csv",derivations)


if __name__=="__main__":
    response()
