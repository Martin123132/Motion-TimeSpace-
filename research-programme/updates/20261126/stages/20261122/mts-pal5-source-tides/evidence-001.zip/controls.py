from tensor import *
from scipy.special import roots_legendre


def manufactured(order,extent,width,plane,height):
    bound=2.;density0=2.6e6;epsilon=.4
    radius=np.hypot(plane,height);inner,outer=radius-width,radius+width
    scale=G*4*np.pi*density0
    point=np.array([plane,0.,height]);ident=np.eye(3)
    shape=height**2-plane**2/2
    shape_prime=np.array([-plane,0,2*height]);curvature=np.diag([-1.,-1.,2.])
    expected=-scale*ident/3+scale*epsilon/5*(curvature/2-5/(14*bound**2)*(2*ident*shape+radius**2*curvature+2*(np.outer(point,shape_prime)+np.outer(shape_prime,point))))
    rho=density0*(1+epsilon*shape/bound**2)
    points=np.unique(np.r_[0.,radius+np.array([-1.,-width,-.1,-.01,0,.01,.1,width,1.]),bound,extent])
    radii,weights=quadrature(points[(points>=0)&(points<=extent)],order)
    mu0=height/radius
    bounds=np.unique(np.clip(np.r_[0,.2,.5,.8,1,abs(mu0)+np.array([-.1,-.01,-.001,0,.001,.01,.1])],0,1))
    cos,aw=quadrature(bounds,order)
    result=rho*shell_tide(plane,height,inner,outer)
    for rad,weight in zip(radii,weights):
        cyl=rad*np.sqrt(1-cos**2);zstar=rad*cos
        matter=density0*(1+epsilon*(rad/bound)**2*(3*cos*cos-1)/2)*(rad<bound)
        rem=matter-rho*int(inner<rad<outer)
        result+=(weight*rad**2)*(aw*rem)@(kernel(plane,height,cyl,zstar)+kernel(plane,height,cyl,-zstar))
    return np.linalg.norm(square(result)-expected)/np.linalg.norm(expected),max(abs((result-entries(expected))/entries(expected)))


def run():
    rows=[]
    for order in (6,12,24):
        for width in (.25,.5):
            norm,component=manufactured(order,3.,width,.8,-.6)
            rows.append(dict(order=order,width=width,frobenius=norm,max_component=component))
    assert max(row["max_component"] for row in rows if row["order"]==24)<.005
    for plane,source_r,dz in ((4.,3.,1.),(4.,3.999,.007),(.2,30.,9.)):
        pair=kernel(plane,dz,source_r,np.array([0.]))[0]
        offsets=np.array([0,.00001,.0001,.001,.01,.1,.5,1.,np.pi])
        phi,weights=quadrature(offsets,64)
        sep=np.stack((plane-source_r*np.cos(phi),-source_r*np.sin(phi),np.full_like(phi,dz)),axis=1)
        distance=np.linalg.norm(sep,axis=1)
        avg=2*G*((sep.T*(3*weights/distance**5))@sep-np.eye(3)*sum(weights/distance**3))
        exact=entries(avg)
        assert np.linalg.norm(pair-exact)<1e-9*np.linalg.norm(exact)
    table("manufactured-tensors.csv",rows)


if __name__=="__main__":
    run()
