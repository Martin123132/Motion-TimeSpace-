from finite_work import Patch,archived
from response import matrices
from pal5_tide_io import *
from scipy.special import roots_legendre


def run():
    light=299792.458
    fieldlist=archived.load(4,2,"reset")[:1];material=archived.Material()
    rows=[]
    for case in CASES:
        plane,height,_=positions(case);centre=np.array([plane,0,height])
        field=archived.make(fieldlist,material,"ordinary" if case=="ordinary" else "forward")[0]
        base_host,base_wave=field.components(0,centre[None,:])
        patch=Patch(case,5)
        theories=matrices(case)
        for theory in ("native","continuous"):
            ordinary,added=theories[theory]
            for channel,tensor in (("ordinary",ordinary),("total",ordinary+added)):
                eigen,basis=np.linalg.eigh(tensor)
                for idx,axis in enumerate(basis.T):
                    for length_pc in (1.,10.,SIZE*1000):
                        length=length_pc/1000
                        for order in (8,16):
                            nodes,weights=roots_legendre(order);along=length*(nodes+1)/2
                            diffs=[]
                            for sign in (1,-1):
                                pts=centre+sign*along[:,None]*axis
                                host,wave=field.components(0,pts)
                                force=(host-base_host)/CONV**2 if theory=="native" else patch.force(pts)
                                if channel=="total":
                                    force+=(wave-base_wave)/CONV**2
                                diffs.append(force@axis)
                            finite=-length/(2*light**2)*(weights@(diffs[0]-diffs[1]))
                            affine=-length**2/light**2*eigen[idx]
                            rows.append(dict(case=case,field=theory,source=channel,axis_index=idx,length_pc=length_pc,order=order,
                                curvature_per_kpc2=-eigen[idx]/light**2,tidal_affine_rate=affine,finite_gravitational_rate=finite,
                                relative_difference=finite/affine-1))
    table("weak-metric-clock-targets.csv",rows)


if __name__=="__main__":
    run()
