from response import matrices,moments
from pal5_tide_io import *


def choose(rows,**where):
    selected=[row for row in rows if all(row[key]==str(value) for key,value in where.items())]
    assert len(selected)==1,(where,len(selected))
    return selected[0]


def audit():
    checks=[]
    def gate(group,case,source,metric,actual,ref):
        err=abs(actual/ref-1) if ref else (0. if actual==0 else None)
        checks.append(dict(group=group,case=case,source=source,metric=metric,test=actual,reference=ref,relative=err,
                           passes=bool(err is not None and err<.005)))
    for case in CASES:
        regs=((4,80,.5,8),(8,80,.5,4),(8,160,.5,4),(12,160,.5,2),(12,160,1.,2))
        sets=[read(HOME/f"tensor-{case}-{order}-{extent}-{width}-{stride}.csv") for order,extent,width,stride in regs]
        fid=sets[-2]
        paired=read(HOME/f"common-grid-fd-{case}-10.csv")
        raw=read(HOME/f"force-fd-{case}-12-0.001.csv")
        cell=read(HOME/"cell-jacobian.csv")
        for source in KEYS:
            row=choose(fid,source=source)
            for start,stop,name in ((0,1,"low_order"),(1,2,"extent"),(2,3,"final_order"),(3,4,"shell_width")):
                for key in NAMES:
                    gate(name,case,source,key,float(choose(sets[start],source=source)[key]),float(choose(sets[stop],source=source)[key]))
            for dataset,tag in ((paired,"fixed_grid_fd"),(raw,"moving_grid_fd")):
                fd=(choose(dataset,source=source,step=.001) if tag=="fixed_grid_fd" else choose(dataset,source=source))
                for key in (*NAMES,"zR"):
                    gate(tag,case,source,key,float(fd[key]),float(row["Rz" if key=="zR" else key]))
                if source!="exterior":
                    gate(tag+"_poisson",case,source,"G_readout/G",float(fd["fd_density"]),float(row["density_Msun_kpc3"]))
            if source!="exterior":
                den=float(row["density_Msun_kpc3"])
                assert abs(float(row["inferred_density"])/den-1)<1e-8
                target={"terminal":"terminal","increment":"increment","full":"transported"}[source]
                compare=choose(cell,case=case,source=target,step=.0005,order=8)
                exterior=choose(fid,source="exterior")
                for key in NAMES:
                    value=float(compare[key])+(0 if source=="increment" else float(exterior[key]))
                    gate("different_cell_source",case,source,key,value,float(row[key]))
        for fieldset in sets:
            terms=[np.array([float(choose(fieldset,source=source)[key]) for key in NAMES]) for source in KEYS]
            assert np.linalg.norm(terms[0]+terms[2]-terms[3])<1e-9
    for row in read(HOME/"patch-independent-check.csv"):
        for col in ("rel_vector","rel_R","rel_z"):
            gate("offgrid_"+row["nodes"],row["case"],row["r"]+"/"+row["z"],col,1+float(row[col]),1)
    ledger=read(HOME/"finite-work.csv");answers=[]
    for case in CASES:
        for ap in (1,2,3):
            for tag in ("native","patch3","patch5"):
                for source in ("ordinary","added","total","ordinary_alone","wave_square","twice_cross"):
                    kw=dict(case=case,aperture=ap,source=source,field=tag)
                    coarse=choose(ledger,order=16,**kw);fine=choose(ledger,order=24,**kw)
                    for key in ("square","pressure","energy_curvature"):
                        gate("finite_quadrature",case,tag+"_"+source,str(ap)+"_"+key,float(coarse[key]),float(fine[key]))
                    if source in ("ordinary","added","total","ordinary_alone") and tag=="patch5":
                        alt=choose(ledger,case=case,aperture=ap,source=source,order=24,field="patch3")
                        gate("finite_patch_order",case,source,str(ap),float(alt["energy_curvature"]),float(fine["energy_curvature"]))
                        gate("finite_jeans_work",case,source,str(ap),float(fine["direct_moment"]),float(fine["energy_curvature"]))
                    if source=="ordinary" and tag=="patch5":
                        gate("interpolated_force_flux",case,tag,str(ap),float(fine["flux_mass"]),float(fine["mass_used"]))
                def final(key):
                    return choose(ledger,case=case,aperture=ap,source=key,field=tag,order=24)
                value=lambda row:float(row["energy_curvature"])
                total=value(final("total"));host_only=value(final("ordinary_alone"))
                wave_self=value(final("wave_square"));cross=value(final("twice_cross"))
                wave_pressure=float(final("added")["pressure"])
                assert abs(total-host_only-cross-wave_self-wave_pressure)<1e-12*max(1e-12,abs(total))
                if tag in ("native","patch5"):
                    answers.append(dict(case=case,aperture=ap,field=tag,total_work_curvature=total,ordinary_if_alone=host_only,
                        twice_ordinary_wave=cross,wave_square=wave_self,wave_pressure=wave_pressure,ordinary_pressure=final("ordinary")["pressure"]))
    table("numerical-audit.csv",checks);table("finite-work-summary.csv",answers)
    summary={}
    for name in dict.fromkeys(row["group"] for row in checks):
        rows=[row for row in checks if row["group"]==name]
        summary[name]=dict(count=len(rows),misses=sum(not row["passes"] for row in rows),
                           worst=max((row["relative"] for row in rows if row["relative"] is not None),default=None))
    record("audit.json",summary)
    return summary


if __name__=="__main__":
    print(json.dumps(audit(),indent=2))
