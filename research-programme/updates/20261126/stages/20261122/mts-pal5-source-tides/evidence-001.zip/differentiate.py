from pal5_tide_io import *
import continuous_force as prior

def run():
    edges,angular,cells,_=prior.io.arrays()
    saved=read(pin(GREEN,"continuous-forces.csv"))
    for case in CASES:
        plane,height,_=positions(case)
        for order,extent,step in ((8,160,.004),(12,160,.004),(12,160,.002),(12,160,.001)):
            rows=[];guard()
            selected=[0,2,3,4]
            base=np.array([float(next(row for row in saved if row["case"]==case and int(row["order"])==order and int(row["extent_kpc"])==extent and row["source"]==key)["a_R_kms2_kpc"]) for key in KEYS])
            for axis,(offset_r,offset_z) in enumerate(((step,0),(0,step))):
                both=[]
                for sign in (-1,1):
                    values=prior.components(plane+sign*offset_r,height+sign*offset_z,order,extent,edges,angular,cells)
                    both.append(values[selected,:2])
                rows.append((both[1]-both[0])/(2*step))
            measures=[]
            for idx,key in enumerate(KEYS):
                rr,zr=rows[0][idx];rz,zz=rows[1][idx];pp=base[idx]/plane
                measures.append(dict(case=case,order=order,step=step,source=key,RR=rr,pp=pp,zz=zz,Rz=rz,zR=zr,
                                     fd_density=-(rr+zz+pp)/(4*np.pi*G)))
            name=f"force-fd-{case}-{order}-{step}.csv"
            table(name,measures);print(name,flush=True)

if __name__=="__main__":
    run()
