from pal5_tide_io import *
from cell_green import force
from experiment import arrays

def run():
    edges,angles,cells,_=arrays()
    last=np.flatnonzero(cells["terminal"].sum(axis=1)>0)[-1]+1
    edges=edges[:last+1]
    volume=(4*np.pi/3)*np.diff(edges**3)[:,None]*np.diff(angles)
    keys=("terminal","increment","transported")
    density=np.stack([cells[key][:last]/volume for key in keys],axis=-1)
    previous=read(pin(GREEN,"direct-cell-forces.csv"))
    divergence=read(pin(GREEN,"direct-cell-divergence.csv"))
    records=[]
    for case in CASES:
        plane,height,_=positions(case)
        radius=np.hypot(plane,height)
        margin=min(np.min(abs(edges-radius)),radius*np.min(abs(np.sin(np.arccos(abs(height)/radius)-np.arccos(angles)))))
        for order in (4,8):
            base=np.array([float(next(row for row in previous if row["case"]==case and row["source"]==key and int(row["order"])==order)["a_R_kms2_kpc"]) for key in keys])
            for step in ([min(.001,margin/8)] if order==4 else [min(.001,margin/8),min(.001,margin/8)/2]):
                guard()
                shifts=[]
                for offset in ((step,0),(0,step)):
                    plus=force(edges,angles,density,plane+offset[0],height+offset[1],order)
                    minus=force(edges,angles,density,plane-offset[0],height-offset[1],order)
                    shifts.append((plus-minus)/(2*step))
                for idx,key in enumerate(keys):
                    rr,zr=shifts[0][idx];rz,zz=shifts[1][idx];pp=base[idx]/plane
                    before=next(row for row in divergence if row["case"]==case and row["source"]==key and int(row["order"])==order and float(row["step_kpc"])==step)
                    inferred=-(rr+pp+zz)/(4*np.pi*G)
                    assert abs(inferred/float(before["inferred_density"])-1)<1e-9
                    records.append(dict(case=case,source=key,order=order,step=step,RR=rr,pp=pp,zz=zz,Rz=rz,zR=zr,
                                        sampled_density=inferred,cell_density=before["cell_density"]))
        print(case,"cell Jacobian complete",flush=True)
    table("cell-jacobian.csv",records)

if __name__=="__main__":
    run()
