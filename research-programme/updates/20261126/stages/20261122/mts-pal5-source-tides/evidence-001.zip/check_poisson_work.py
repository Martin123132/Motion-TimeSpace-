from finite_work import run
from poisson_patch import PoissonPatch,LABELS

if __name__=="__main__":
    run(lambda case:[PoissonPatch(case,label) for label in LABELS],"poisson-")
