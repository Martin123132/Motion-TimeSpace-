import os
import csv
import hashlib
import io
import json
import sys
from pathlib import Path
for key in ("OPENBLAS_NUM_THREADS","MKL_NUM_THREADS","OMP_NUM_THREADS","BLIS_NUM_THREADS","NUMEXPR_NUM_THREADS"):os.environ[key]="1"
HERE=Path(__file__).resolve().parent
PREV=HERE.parent/"mts-host-local-tidal-basin-544-20261122"
def digest(path):
    with path.open("rb") as handle:return hashlib.file_digest(handle,"sha256").hexdigest()
assert digest(PREV/"seal.json")=="560bb52df749765f7d3dceacb663845b508380ec00b75b0389914a189f285e40"
for source in ("fields.py","gravity.py","acquire.py"):
    assert digest(PREV/source)==json.loads((PREV/"seal.json").read_bytes())[source]
sys.path.insert(0,str(PREV))
from gravity import Model,Center,G
from fields import pin,GAL,LAT,EARLY,BASE,np,read
def guard():
    assert __debug__ and not any((path/"STOP-REQUESTED").exists() for path in (HERE,HERE.parent,PREV,EARLY))
def save(name,raw):
    guard();dst=HERE/name
    if dst.exists():assert dst.read_bytes()==raw,name
    else:
        with dst.open("xb") as stream:stream.write(raw)
def table(name,data):
    dest=io.StringIO();writer=csv.DictWriter(dest,fieldnames=data[0],lineterminator="\n");writer.writeheader();writer.writerows(data);save(name,dest.getvalue().encode())
def report(name,data):save(name,(json.dumps(data,indent=2,sort_keys=True,allow_nan=False)+"\n").encode())
def packet(name,**params):
    dest=io.BytesIO();np.savez_compressed(dest,**params);save(name,dest.getvalue())
def geometry_dirs(order):
    from scipy.special import roots_legendre
    axisdata=np.fromstring(" ".join(line for line in pin(BASE,"600_coords_DR.txt").read_text().splitlines() if not line.lstrip().startswith("#")),sep=" ")
    rotation=axisdata[-9:].reshape(3,3)
    axis=rotation[-1]/np.linalg.norm(rotation[-1]);first=rotation[0]-axis*np.dot(rotation[0],axis);first/=np.linalg.norm(first);second=np.cross(axis,first)
    mu,wt=roots_legendre(order);az=(np.arange(2*order)+.25)*np.pi/order
    norm=np.sqrt(1-mu**2)[:,None,None]
    points=(mu[:,None,None]*axis+norm*(np.cos(az)[:,None]*first+np.sin(az)[:,None]*second)).reshape(-1,3)
    return points,np.repeat(mu,len(az)),np.repeat(wt/(4*order),2*order),axis

