from local import *
import ast
import re
def run():
    guard()
    for file in HERE.glob("*.py"):ast.parse(file.read_text(encoding="utf-8-sig"))
    assert not any(p.is_dir() or p.suffix==".writing" for p in HERE.iterdir())
    gates=[];tableau=[]
    for first,last in ((544,558),(558,572)):
        for steps in (32,64,128,256):
            with np.load(HERE/f"native-{steps}-{first}-{last}.npz") as b:
                assert int(b["count"])==int(b["ticks"][-1])
                if steps<=64:assert float(b["endpoint_error"])==0.
        for steps in (64,128,256):
            data=read(HERE/f"midpoint-{steps}-{first}-{last}.csv")
            assert len(data)==10
            for r in data:
                frac=float(r["fraction"]);absfrac=float(r["abs_step_residual_fraction"])
                assert abs(frac)<=2e-5 and absfrac<=2e-5
                if r["path"]!="fixed":assert float(r["net_in"])<0<float(r["sweep"])
        data=read(HERE/f"midpoint-256-{first}-{last}.csv")
        smaller={(r["surface"],r["path"]):r for r in read(HERE/f"midpoint-128-{first}-{last}.csv")}
        for r in data:
            ref=smaller[r["surface"],r["path"]];scale=float(r["scale"])
            err=max(abs(float(r[k])-float(ref[k]))/scale for k in ("net_in","sweep","direct_Msun"))
            gates.append(dict(first=first,last=last,surface=r["surface"],path=r["path"],time_refinement=err,
                half_percent=bool(err<=.005),strict_2e5=bool(err<=2e-5),midpoint_closure=float(r["fraction"])))
            assert err<=.005
    table("refinement-decisions.csv",gates)
    for r in read(pin(LAT,"gd1-forces.csv")):
        if r["state"] not in ("ordinary_only","published_halo") or r["foreground"]=="positive_host":continue
        val=1e11*float(r["equivalent_radial_mass_1e11"])
        tableau.append(dict(foreground=r["foreground"],state=r["state"],proxy_Msun=val,
            inside_published_radial_interval=bool(1.34e11<=val<=1.48e11),
            change_from_exterior_spherical_shells_Msun=0.))
    table("shell-theorem-controls.csv",tableau)
    assert [x["inside_published_radial_interval"] for x in tableau if x["state"]=="published_halo"]==[True,False]
    geo=read(HERE/"closed-surfaces.csv")
    assert len(geo)==27 and min(min(float(r[k]) for k in ("full_sphere_margin","min_radial_derivative","core_margin")) for r in geo)>0
    limits=read(HERE/"necessary-penetration.csv");assert len(limits)==48
    for r in limits:
        alt,=[s for s in limits if all(s[k]==r[k] for k in ("arm","source","foreground")) and s["order"]!=r["order"]]
        assert max(abs(float(r[k])-float(alt[k])) for k in ("absolute_free","axisym_upper","axisym_lower"))<1e-6
    discrepancies=read(HERE/"balance.csv")
    by={(r["steps"],r["order"],r["first"],r["surface"],r["path"],r["stride"]):r for r in discrepancies}
    angular=[]
    for key,r in by.items():
        if key[:2]!=("64","32") or key[-1]!="1":continue
        alt=by["64","24",*key[2:]]
        angular.append(max(abs(float(r[k])-float(alt[k])) for k in ("total_inflow","sweep","direct_from_exterior"))/float(r["resolution_scale"]))
    assert max(angular)<2e-5
    box=json.loads((HERE/"manufactured.json").read_bytes())
    assert box["radial_plus_tangent_continuity_error"]<1e-10
    report("validation.json",dict(original_exact_segments=4,moving_or_fixed_budgets=60,closed_geometry_cases=len(geo),
        final_rate_half_percent=sum(r["half_percent"] for r in gates),final_rate_strict=sum(r["strict_2e5"] for r in gates),
        decisions=len(gates),max_final_time_relative=max(r["time_refinement"] for r in gates),
        max_final_angular_relative=max(angular),gd1_cases=len(limits)//2,external_preparation_fitted=False))
    for doc in HERE.glob("*.md"):
        for addr in re.findall(r"\]\(([^)]+)\)",doc.read_text(encoding="utf-8-sig")):
            if "://" not in addr:assert (HERE/addr).is_file(),addr
    files={p.name:digest(p) for p in sorted(HERE.iterdir()) if p.is_file() and p.name!="seal.json"}
    report("seal.json",files)
    print(len(files),digest(HERE/"seal.json"))
if __name__=="__main__":run()

