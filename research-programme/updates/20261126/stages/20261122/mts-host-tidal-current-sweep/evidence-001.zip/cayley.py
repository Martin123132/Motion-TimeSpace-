from replay import *
from basis import Basis
import csv
import io
def load_parent(folder,name,anchor):
    path=HERE.parent/folder
    assert sha(path/"seal.json")==anchor
    inventory=json.loads((path/"seal.json").read_bytes())
    assert sha(path/name)==inventory.get("files",inventory)[name]
    return path/name
def write(name,rows):
    tmp=io.StringIO();writer=csv.DictWriter(tmp,rows[0],lineterminator="\n")
    writer.writeheader();writer.writerows(rows);payload=tmp.getvalue().encode()
    dest=HERE/name
    if dest.exists():assert dest.read_bytes()==payload,name
    else:
        with dest.open("xb") as file:file.write(payload)
class Budget:
    def start(self,steps,first,last,count,span,vec):
        self.tag=f"{steps}-{first}-{last}";self.count=count;self.dt=span/count
        with np.load(HERE/"surface-32.npz") as geo:
            mu=geo["mu"];self.weight=geo["weight"]
            self.surfaces={};zero=np.zeros_like(mu)
            for radius in (25.,50.,100.,120.):
                self.surfaces[str(int(radius)),"fixed"]=(zero+radius,zero,zero,zero)
            for name in ("near","middle","deep"):
                ra,rb,ca,cb=[geo[f"{key}_{snap}_wave_{name}"] for key in ("r","c") for snap in (first,last)]
                for path in ("linear","smooth"):self.surfaces[name,path]=(ra,rb-ra,ca,cb-ca)
        src="mts-preparation-vertical-gravity-590-20261122"
        lat="mts-high-latitude-preparation-null-590-20261122"
        hp="06e46c345f46f6e927fb493ea4dcfa95acd67f1e56885849189b42f6f35f8c71"
        with np.load(load_parent(src,"launch.npz","37a872fe0e0c207030ca5c4825940b22be066191dcfd3097d28f3169b104aef7")) as mesh,np.load(load_parent(lat,"native-map.npz",hp)) as bank:
            units=json.loads(load_parent(lat,"native-units.json",hp).read_bytes())
            self.b=Basis(mu,mesh["edges"],mesh["knots"],mesh["degrees"],bank["indices"],bank["sqrt"],float(mesh["length"]),float(mesh["mscale"]),units["time_Myr"])
        self.b.state(vec);self.old=self.at(0.)
        self.totals={key:np.zeros(7) for key in self.surfaces}
        self.maxstep={key:0. for key in self.surfaces}
    def geom(self,key,frac):
        ra,dr,ca,dc=self.surfaces[key]
        w=frac**2*(3-2*frac) if key[1]=="smooth" else frac
        return ra+w*dr,ca+w*dc
    def at(self,frac):
        return {key:self.b.readout(*self.geom(key,frac),self.weight,0.) for key in self.surfaces}
    def step(self,tick,mid,new):
        time=(tick+.5)/self.count
        old_mid=self.at(time)
        self.b.state(mid);current=self.at(time)
        self.b.state(new);new_mid=self.at(time);next_end=self.at((tick+1)/self.count)
        for key in self.surfaces:
            qr,qa=current[key][1:3]*self.dt
            sweep=(self.old[key][0]-old_mid[key][0])+(new_mid[key][0]-next_end[key][0])
            change=self.old[key][0]-next_end[key][0]
            err=-qr-qa+sweep-change
            self.totals[key]+=np.array([change,-qr,-qa,sweep,abs(qr+qa),abs(sweep),abs(err)])
            self.maxstep[key]=max(self.maxstep[key],abs(err))
        self.old=next_end
    def finish(self):
        out=[]
        for (label,path),(change,rad,pol,sweep,absflux,abssweep,totalerr) in self.totals.items():
            norm=max(abs(change),absflux,abssweep,1e-100)
            out.append(dict(surface=label,path=path,direct_Msun=change,radial_in=rad,transverse_in=pol,
                sweep=sweep,net_in=rad+pol,residual=rad+pol+sweep-change,scale=norm,
                fraction=(rad+pol+sweep-change)/norm,abs_step_residual_fraction=totalerr/norm,
                largest_step_error_Msun=self.maxstep[label,path]))
        write("midpoint-"+self.tag+".csv",out);print("matched steps:",self.tag,flush=True)
if __name__=="__main__":
    for level in map(int,sys.argv[1:]):run(level,Budget())

