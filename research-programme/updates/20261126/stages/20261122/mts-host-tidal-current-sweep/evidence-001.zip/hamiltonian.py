from replay import *
def calculate(steps):
    obj=joint.Assembly("anchorA")
    kinetic=obj.bg.mesh.kinetic(obj.bg.orders,True)
    us=fields(obj,(544,558,572))
    for first,last in ((544,558),(558,572)):
        dst=HERE/f"rhs-{steps}-{first}-{last}.npz"
        source=HERE/f"native-{steps}-{first}-{last}.npz"
        if dst.exists():
            with np.load(dst) as bank:assert bank["source_hash"].item()==sha(source)
            continue
        with np.load(source) as bank:vecs=bank["states"];fractions=bank["ticks"]/int(bank["count"])
        dk=[];dp=[];norm_error=0.
        for frac,vec in zip(fractions,vecs):
            guard();assert not (HERE/"STOP-REQUESTED").exists()
            ext=us[first]+frac*(us[last]-us[first])
            term=kinetic@vec
            rest=obj.bare@vec-term+obj.multiply(ext+obj.phi(obj.moment(vec)),vec)-obj.mu*vec
            fac=-1j/obj.unit_myr
            dk.append(fac*term);dp.append(fac*rest)
            norm_error=max(norm_error,abs(np.vdot(vec,dk[-1]+dp[-1]).real)/obj.number)
        assert norm_error<1e-13
        tmp=dst.with_suffix(".writing")
        with tmp.open("xb") as handle:np.savez_compressed(handle,dk=dk,dp=dp,source_hash=sha(source),norm_error=norm_error)
        tmp.rename(dst)
if __name__=="__main__":
    for level in map(int,sys.argv[1:]):calculate(level)

