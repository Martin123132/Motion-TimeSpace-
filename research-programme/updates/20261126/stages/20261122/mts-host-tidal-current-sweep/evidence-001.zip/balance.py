from local import *
from scipy.integrate import simpson
def run():
    out=[]
    for file in sorted(HERE.glob("sample-*.csv")):
        steps,order,first,last=map(int,file.stem.split("-")[1:])
        data=read(file);norm=json.loads((HERE/file.name.replace("sample-","norm-").replace(".csv",".json")).read_bytes())
        for name,path in sorted({(r["surface"],r["path"]) for r in data}):
            selected=[r for r in data if r["surface"]==name and r["path"]==path]
            for stride in (1,2,4):
                rows=[selected[i] for i in np.unique(np.r_[np.arange(0,len(selected),stride),len(selected)-1])]
                def col(k):return np.array([float(r[k]) for r in rows])
                times=col("time_Myr");ext=col("outside_Msun")
                qr,qa,qs=[col(k) for k in ("radial_out_Msun_Myr","transverse_out_Msun_Myr","sweep_in_Msun_Myr")]
                integ=lambda arr:simpson(arr,x=times)
                jrad,jang,sweep=map(integ,(qr,qa,qs));inflow=-(jrad+jang)
                change=ext[0]-ext[-1];pred=inflow+sweep
                size=max(integ(abs(qr+qa)),integ(abs(qs)),abs(change),1e-50)
                out.append(dict(steps=steps,order=order,first=first,last=last,surface=name,path=path,stride=stride,
                    start_exterior_Msun=ext[0],end_exterior_Msun=ext[-1],direct_from_exterior=change,radial_in=-jrad,
                    transverse_in=-jang,total_inflow=inflow,sweep=sweep,predicted=pred,residual=pred-change,
                    resolution_scale=size,frac_residual=(pred-change)/size,raw_inside_change=change+norm["raw_continuum_delta_Msun"],
                    reported_loose=bool(abs(pred-change)<=.005*size),reported_strict=bool(abs(pred-change)<=2e-5*size)))
    table("balance.csv",[r for r in out if r["steps"]<=64])
    extra=[r for r in out if r["steps"]>64]
    if len({r["steps"] for r in extra})==2:table("refined-balance.csv",extra)
if __name__=="__main__":run()

