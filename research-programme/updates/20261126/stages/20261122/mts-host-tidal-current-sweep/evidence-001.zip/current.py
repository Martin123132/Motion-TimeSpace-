from local import *
from scipy.special import roots_legendre
from numpy.polynomial.legendre import legvander,legder,legint
from basis import Basis
class Reader(Basis):
    def __init__(self,mu):
        with np.load(pin(GAL,"launch.npz")) as mesh,np.load(pin(LAT,"native-map.npz")) as bank:
            units=json.loads(pin(LAT,"native-units.json").read_bytes())
            assert abs(float(mesh["length"])-units["length_kpc"])<1e-10
            super().__init__(mu,mesh["edges"],mesh["knots"],mesh["degrees"],bank["indices"],bank["sqrt"],
                float(mesh["length"]),float(mesh["mscale"]),units["time_Myr"])

def result(steps,order,first,last):
    with np.load(HERE/f"surface-{order}.npz") as geo:
        mu=geo["mu"];wt=geo["weight"];surfs={}
        for name in ("near","middle","deep"):
            for path in ("linear","smooth"):
                surfs[(name,path)]=[geo[f"{key}_{snap}_wave_{name}"] for key in ("r","c") for snap in (first,last)]
    rd=Reader(mu)
    with np.load(HERE/f"native-{steps}-{first}-{last}.npz") as bank:
        states=bank["states"];times=bank["ticks"]/int(bank["count"]);span=float(bank["span"])
        if steps<=64:assert float(bank["endpoint_error"])<1e-11
    tab=[];amps=[];ends={}
    for ix,(frac,vec) in enumerate(zip(times,states)):
        if ix%16==0:guard()
        rd.state(vec)
        amps.append((rd.norm,rd.deficit))
        def store(name,path,rad,cr,vel):
            ext,jr,ja,sweep=rd.readout(rad,cr,wt,vel)
            tab.append(dict(tick=ix,time_Myr=frac*span,surface=name,path=path,outside_Msun=ext,
                radial_out_Msun_Myr=jr,transverse_out_Msun_Myr=ja,sweep_in_Msun_Myr=sweep))
        for radius in (25.,50.,100.,120.):
            store(str(int(radius)),"fixed",np.full_like(mu,radius),0.,0.)
        for (name,path),(ra,rb,ca,cb) in surfs.items():
            mix=frac if path=="linear" else frac**2*(3-2*frac)
            slope=1 if path=="linear" else 6*frac*(1-frac)
            store(name,path,ra+mix*(rb-ra),ca+mix*(cb-ca),slope*(rb-ra)/span)
            if path=="linear" and ix in (0,len(states)-1):
                ends[(ix!=0,name)]=[rd.readout(rad,cr,wt,0.)[0] for rad,cr in ((ra,ca),(rb,cb))]
    name=f"{steps}-{order}-{first}-{last}"
    table("sample-"+name+".csv",tab)
    normdiff=amps[-1][0]-amps[0][0];defdiff=amps[-1][1]-amps[0][1]
    extra=[]
    for label in ("near","middle","deep"):
        aa,ab=ends[(False,label)];ba,bb=ends[(True,label)]
        extra.append(dict(surface=label,change_inside_if_total_constant=aa-bb,
            forward_order_sweep=aa-ab,backward_order_sweep=ba-bb,
            fixed_geometry_mass_change_A=aa-ba,fixed_geometry_mass_change_B=ab-bb,
            exact_symmetric_sweep=(aa-ab+ba-bb)/2,exact_symmetric_density=(aa-ba+ab-bb)/2))
    table("endpoints-"+name+".csv",extra)
    report("norm-"+name+".json",dict(native_delta_Msun=normdiff,lobatto_minus_exact_delta_Msun=defdiff,
           raw_continuum_delta_Msun=normdiff-defdiff,initial_lobatto_minus_exact_Msun=amps[0][1],
           initial_native_Msun=amps[0][0],max_relative_native_drift=max(abs(v[0]/amps[0][0]-1) for v in amps)))
if __name__=="__main__":
    for pair in sys.argv[1:]:
        steps,order=map(int,pair.split(":"))
        for first,last in ((544,558),(558,572)):result(steps,order,first,last)

