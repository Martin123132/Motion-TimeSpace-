from gd1_exterior import *
def real_ring(R,mu):
    az=np.arange(1024)*2*np.pi/1024
    side=np.sqrt((1-mu**2)*(1-MU**2))*np.cos(az)
    cosine=np.r_[MU*mu+side,-MU*mu+side]
    return RPROBE**2*np.mean((R*cosine-RPROBE)/(R**2+RPROBE**2-2*R*RPROBE*cosine)**1.5)
def run():
    radii=[float(r["axisym_lower"]) for r in read(HERE/"necessary-penetration.csv") if r["order"]=="20"]
    out=[]
    for R in [min(radii),max(radii),50.,70.,100.]:
        x=RPROBE/R
        vals=az_basis@(factor*x**(ell+1))
        ix=vals.argmax()
        lo=max(0,ix-2);hi=min(len(mu_grid)-1,ix+2)
        from scipy.optimize import minimize_scalar
        opt=minimize_scalar(lambda mu:-real_ring(R,mu),bounds=(mu_grid[lo],mu_grid[hi]),method="bounded",options={"xatol":1e-13})
        direct=max(real_ring(R,float(mu_grid[ix])),-opt.fun)
        lower=max_kernel(R,"axisym_lower");upper=max_kernel(R,"axisym_upper")
        assert lower-1e-12<=direct<=upper+1e-12
        assert max(real_ring(R,mu) for mu in np.linspace(0,1,101))<=upper+1e-12
        assert upper<=max_kernel(R,"inversion_pair")+1e-10
        out.append(dict(radius=R,ring_latitude_cos=opt.x,angular_sum=direct,analytic_lower=lower,analytic_upper=upper))
    table("direct-ring-check.csv",out)
if __name__=="__main__":run()

