from surfaces import *
from current import Reader
from scipy.special import eval_legendre
def certify():
    sheet=read(HERE/"surface-16.csv");out=[]
    for snap in (544,558,572):
        host=Center(snap)
        for branch in ("ordinary","wave","cold"):
            model=Model(host,branch);mass=G*model.halos.mass;dist=np.linalg.norm(model.halos.pos,axis=1)
            for row in (r for r in sheet if r["snap"]==str(snap) and r["branch"]==branch):
                bound=float(row["level"]);rs=float(row["saddle_radius"])
                highest=float(row["max_radius"])
                for rad in np.arange(np.ceil(highest+2),np.ceil(rs)+1,2):
                    edge=np.linspace(20.,rad,1025);lo,hi=edge[:-1],edge[1:]
                    floor=G*model.central(lo)[1]/hi**2-model.K*hi-(1/(dist-hi[:,None])**2-1/dist**2)@mass
                    if min(floor)<=0:continue
                    lower=model.central(rad)[0]-model.K*rad**2/2-mass@(rad**2/(dist**2*(dist-rad)))
                    if lower<=bound:lower=model.shell(rad,56)[0]
                    if lower>bound:break
                else:raise ArithmeticError((snap,branch,row["surface"]))
                assert float(row["core_roof_margin"])>0
                out.append(dict(snap=snap,branch=branch,surface=row["surface"],enclosing_radius=rad,
                    full_sphere_margin=lower-bound,min_radial_derivative=min(floor),core_margin=row["core_roof_margin"]))
    table("closed-surfaces.csv",out)
def analytic():
    dirs,mu,wt,axis=geometry_dirs(32);rd=Reader(mu)
    rad=np.empty(len(rd.root)+2)
    rad[rd.indices]=rd.edges[:-1,None]+np.diff(rd.edges)[:,None]*rd.knots
    assert rad[0]==0 and abs(rad[-1]-rd.edges[-1])<1e-10
    pol=eval_legendre(2,mu);R=64*(1+.12*pol);slope=64*.12*3*mu*(1-mu**2)
    speed=.023*(1-.25*pol)
    amp=1.;iso=1e-4;aniso=.00021;kap=rd.kappa
    taper=np.clip((200.-rad)/70,0.,1.)
    raw=np.zeros((len(rad),len(rd.degrees)),complex)
    raw[:,0]=rad*(amp+1j*iso*rad**2)*taper
    raw[:,1]=1j*aniso*rad**3/np.sqrt(5)*taper
    vec=(raw[1:-1]*rd.root[:,None]).ravel()
    local=iso+aniso*pol
    exact_mass=rd.scale*(wt@(amp**2*R**3/3+local**2*R**7/7))
    exact_r=rd.kappa*rd.scale*(wt@(2*amp*R**3*local))
    exact_ang=-rd.kappa*rd.scale*(wt@(amp*aniso*3*mu*R**2*slope))
    exact_s=rd.scale*(wt@((amp**2*R**2+local**2*R**6)*speed))
    exact_dm=rd.scale*(wt@(-2*amp*kap*iso*R**3))+exact_s
    rd.state(vec);out=rd.readout(R,slope,wt,speed)
    wanted=np.array([exact_mass,exact_r,exact_ang,exact_s])
    got=np.r_[rd.norm-rd.deficit-out[0],out[1:]]
    err=max(abs(got/wanted-1));identity=abs((-out[1]-out[2]+out[3])/exact_dm-1)
    rd.state(vec.conj());other=rd.readout(R,slope,wt,speed)
    parity=np.max(abs(other/out-[1,-1,-1,1]))
    rd.state(vec.real.astype(complex));real=rd.readout(R,slope,wt,speed)
    rd.state(np.zeros_like(vec));empty=rd.readout(R,slope,wt,speed)
    assert err<1e-10 and identity<1e-10 and parity<1e-12
    assert real[1]==real[2]==0 and real[3]>0 and np.array_equal(empty,np.zeros(4))
    report("manufactured.json",dict(relative_readout_error=err,radial_plus_tangent_continuity_error=identity,
        conjugate_relative_error=parity,omitting_transverse_fraction=abs(exact_ang/(exact_r+exact_ang)),empty_readout=list(empty)))
if __name__=="__main__":certify();analytic()

