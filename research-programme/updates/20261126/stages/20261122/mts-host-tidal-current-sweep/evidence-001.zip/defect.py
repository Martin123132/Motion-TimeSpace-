from current import *
from scipy.integrate import simpson
def rate_integrator(rd,vec,dk,dp):
    def angular(field):
        nodal=np.pad(field.reshape(len(rd.root),-1)/rd.root[:,None],((1,1),(0,0)))[rd.indices]
        return (rd.sample@nodal)@rd.basis.T
    field=angular(vec);pairs=[]
    for dot in (dk,dp):
        coeff=rd.fit_density@(2*(field.conj()*angular(dot)).real)
        primitive=-rd.primitive@coeff
        mass=rd.scale*coeff[:,0,:]*np.diff(rd.edges)[:,None]
        tail=np.concatenate([np.cumsum(mass[::-1],axis=0)[::-1],np.zeros((1,len(rd.mu)))])
        pairs.append((primitive,tail))
    def apply(rad,wt):
        cell=np.searchsorted(rd.edges[1:],rad);width=np.diff(rd.edges)[cell]
        vander=legvander(2*(rad-rd.edges[cell])/width-1,15)
        return [wt@(tail[cell+1,rd.mindex]+.5*rd.scale*width*np.einsum("ij,ij->i",vander,primitive[cell,:,rd.mindex])) for primitive,tail in pairs]
    return apply
def run(steps,first,last):
    order=32;tag=f"{steps}-{order}-{first}-{last}"
    source=HERE/f"native-{steps}-{first}-{last}.npz"
    with np.load(HERE/f"rhs-{steps}-{first}-{last}.npz") as bank:
        assert bank["source_hash"].item()==digest(source)
        dk,dp=bank["dk"],bank["dp"]
    with np.load(source) as bank:
        vecs=bank["states"];frac=bank["ticks"]/int(bank["count"]);span=float(bank["span"])
    samples=read(HERE/f"sample-{tag}.csv")
    with np.load(HERE/f"surface-{order}.npz") as geo:
        mu,wt=geo["mu"],geo["weight"];rd=Reader(mu)
        bounds={}
        for rad in (25,50,100,120):
            bounds[str(rad),"fixed"]=(np.full_like(mu,rad),np.full_like(mu,rad))
        for lab in ("near","middle","deep"):
            for path in ("linear","smooth"):
                bounds[lab,path]=(geo[f"r_{first}_wave_{lab}"],geo[f"r_{last}_wave_{lab}"])
    dt=frac*span;calcs={k:[] for k in bounds};out=[]
    for ix,(time,vec,kin,pot) in enumerate(zip(frac,vecs,dk,dp)):
        guard();integrate=rate_integrator(rd,vec,kin,pot)
        for key,(ra,rb) in bounds.items():
            alpha=time if key[1]!="smooth" else time**2*(3-2*time)
            calcs[key].append(integrate(ra+alpha*(rb-ra),wt))
    for (name,path),result in calcs.items():
        vals=np.array(result);data=[r for r in samples if r["surface"]==name and r["path"]==path]
        outward=np.array([float(r["radial_out_Msun_Myr"])+float(r["transverse_out_Msun_Myr"]) for r in data])
        swept=np.array([float(r["sweep_in_Msun_Myr"]) for r in data])
        ext=float(data[-1]["outside_Msun"])-float(data[0]["outside_Msun"])
        for stride in (1,2):
            ids=np.unique(np.r_[np.arange(0,len(dt),stride),len(dt)-1])
            integral=lambda a:simpson(a[ids],x=dt[ids])
            int_kin,int_pot=map(integral,vals.T);int_phys=integral(outward);int_sweep=integral(swept)
            scale=max(integral(abs(outward)),integral(abs(swept)),abs(ext),1e-60)
            remainder=int_kin+int_pot-int_sweep-ext
            out.append(dict(steps=steps,first=first,last=last,surface=name,path=path,stride=stride,scale=scale,
                kinetic_minus_physical_out=int_kin-int_phys,potential_out=int_pot,spatial_defect_out=int_kin+int_pot-int_phys,
                temporal_remainder_out=remainder,physical_residual_out=int_phys-int_sweep-ext,
                separated_kinetic_fraction=(int_kin-int_phys)/scale,separated_potential_fraction=int_pot/scale,
                separated_time_fraction=remainder/scale))
    table("defect-"+tag+".csv",out)
if __name__=="__main__":
    for steps in map(int,sys.argv[1:]):
        for first,last in ((544,558),(558,572)):run(steps,first,last)

