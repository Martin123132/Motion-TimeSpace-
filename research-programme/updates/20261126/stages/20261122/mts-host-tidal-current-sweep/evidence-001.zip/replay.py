import os
import sys
from pathlib import Path
import hashlib
import json
for key in ("OPENBLAS_NUM_THREADS","MKL_NUM_THREADS","OMP_NUM_THREADS","BLIS_NUM_THREADS","NUMEXPR_NUM_THREADS"):os.environ[key]="1"
HERE=Path(__file__).resolve().parent
EARLY=HERE.parent/"mts-pre572-wave-preparation-20261120"
PREV=HERE.parent/"mts-host-local-tidal-basin-544-20261122"
def sha(path):
    with path.open("rb") as file:return hashlib.file_digest(file,"sha256").hexdigest()
assert sha(PREV/"seal.json")=="560bb52df749765f7d3dceacb663845b508380ec00b75b0389914a189f285e40"
assert sha(EARLY/"seal.json")=="ce9ca0f03916af1fa3bfd449a61e779a74ce3427fae0a3a6bcdf65bc2b6c70ee"
sys.path.insert(0,str(EARLY))
from wave_history import joint,fs,np,fields,Evolution,age,guard
def run(steps,observer=None):
    assert steps in (32,64,128,256)
    obj=joint.Assembly("anchorA");knots=(544,558,572);us=fields(obj,knots)
    name=f"state-anchorA-three-{min(steps,64)}.npz"
    assert sha(EARLY/name)==json.loads((EARLY/"seal.json").read_bytes())["files"][name]
    with np.load(EARLY/name) as bank:
        saved=bank["states"][:3];assert tuple(bank["snapshots"][:3])==knots
    vec=saved[0].copy();mom=obj.moment(vec);norm=obj.number
    for ix,(first,last) in enumerate(zip(knots,knots[1:])):
        guard();assert not (HERE/"STOP-REQUESTED").exists()
        dst=HERE/f"native-{steps}-{first}-{last}.npz"
        if dst.exists() and observer is None:
            with np.load(dst) as bank:
                assert bank["source_digest"].item()==sha(EARLY/name)
                assert np.array_equal(vec,bank["states"][0])
                vec=bank["states"][-1];mom=obj.moment(vec)
                if steps<=64:assert np.linalg.norm(vec-saved[ix+1])/np.sqrt(norm)<1e-11
            continue
        start=age(first);span=age(last)-start;count=int(np.ceil(steps*span/obj.unit_myr))
        dt=span/obj.unit_myr/count
        solver=Evolution(obj,dt,vec);pot=us[first];diff=us[last]-pot
        states=[vec.copy()];ticks=[0]
        if observer is not None:observer.start(steps,first,last,count,span,vec)
        for tick in range(count):
            if tick%16==0:
                guard();assert not (HERE/"STOP-REQUESTED").exists()
            ext=pot+(tick+.5)/count*diff
            mid=vec;newmom=mom
            for iteration in range(24):
                local=ext+obj.phi(.5*(mom+newmom))-solver.pref
                updated=solver.factor.solve(vec-.5j*dt*obj.multiply(local,mid))
                new=2*updated-vec;err=np.linalg.norm(updated-mid)/np.sqrt(norm)
                mid=updated;newmom=obj.moment(new)
                if err<2e-14:break
            else:raise ArithmeticError("native step")
            if observer is not None:observer.step(tick,mid,new)
            vec=new;mom=newmom
            if (tick+1)%max(2,steps//32)==0 or tick+1==count:
                states.append(vec.copy());ticks.append(tick+1)
        error=np.linalg.norm(vec-saved[ix+1])/np.sqrt(norm)
        if steps<=64:assert error<1e-11,error
        if observer is not None:
            with np.load(dst) as bank:
                assert np.array_equal(bank["ticks"],ticks) and np.array_equal(bank["states"],states)
            observer.finish();continue
        tmp=dst.with_suffix(".writing")
        with tmp.open("xb") as handle:np.savez_compressed(handle,states=states,ticks=ticks,count=count,span=span,source_digest=sha(EARLY/name),endpoint_error=error)
        tmp.rename(dst)
        print(steps,first,last,count,error,flush=True)
if __name__=="__main__":
    for level in map(int,sys.argv[1:] or (32,64)):run(level)

