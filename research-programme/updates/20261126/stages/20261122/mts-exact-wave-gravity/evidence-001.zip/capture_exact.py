from local_io import *
import capture as driver
import diagnostics as previous
import tempfile, subprocess
from sympy import Dummy

def capture(model,func):
    native=previous.native
    modes,shells,counts=geometry();nodes=modes.big.fund*np.sqrt(shells.astype(float))
    record('legs.json',dict(squared_radii=shells.tolist(),fund_Mpc_inv=modes.big.fund,counts=counts,probes=PROBES))
    status=native.obj(native.source(f'runs/{model}/status.json'))
    file=native.SPEC/"runs/projection/a225-w6-d8.npz" if model=="heavy" else native.NATIVE/"runs/backgrounds/cold.npz"
    native.checked(file,status["source_hash"])
    for path in native.engine.inherited.native_hashes():native.checked(path,status["input_hashes"][str(path)])
    params=native.engine.inherited.params_for(file,background_boost=8.);params.DoLateRadTruncation=False
    bg=native.engine.camb.get_background(params);bg.Params.Accuracy.IntTolBoost=6
    with np.load(pin("native-"+model+".npz")) as src:
        times=src['eta'];names=src['standard'].tolist();custom=src['names'].tolist();oldk=src['k']
        fields={s:src[s] for s in src.files if s.startswith(('heavy_','slow_')) or s in ('xe','cs2b')}
        oldbase=src['base'];oldraw=src['custom']
    assert custom==driver.NAMES
    caps=[]
    for fn in sorted((native.SPEC/'runs'/model).glob('chunk-*.npz')):
        with np.load(native.source(fn.relative_to(native.SPEC).as_posix())) as arch:caps.append(max(arch['modes']))
    caps=np.sort(np.unique(caps));groups=np.searchsorted(caps,nodes);block=24;outputs=[];checks=[]
    with patch.object(previous.symbolic,"compile_sympy_to_camb_source_func",return_value=func):
        for group in np.unique(groups):
            selected=np.flatnonzero(groups==group);cap=caps[group]
            matches=np.flatnonzero(np.searchsorted(caps,oldk)==group)
            assert len(matches);control=matches[len(matches)//2]
            for begin in range(0,len(selected),block):
                guard();ix=selected[begin:begin+block];batch=np.unique(np.r_[nodes[ix],oldk[control],cap])
                out=bg.get_time_evolution(batch,times,vars=names+[Dummy(key) for key in custom],lAccuracyBoost=4)
                assert np.isfinite(out).all()
                got=out[np.searchsorted(batch,oldk[control])]
                worst=0.
                for key in ('etak','Weyl','delta_cdm','delta_baryon','v_photon','pi_photon','mts_drho_h' if model=='heavy' else 'mts_drho_s'):
                    jj=names.index(key);right=oldbase[control,:,jj]
                    worst=max(worst,np.linalg.norm(got[:,jj]-right)/np.linalg.norm(right))
                for key in ('dgq','dgpi','sigma','octg','pirdot','opacity'):
                    jj=custom.index(key);right=oldraw[control,:,jj]
                    worst=max(worst,np.linalg.norm(got[:,len(names)+jj]-right)/np.linalg.norm(right))
                assert worst<2e-5,(model,group,begin,worst)
                take=out[np.searchsorted(batch,nodes[ix])];assert np.allclose(take[:,:,len(names)+custom.index('k')],nodes[ix,None],rtol=1e-13,atol=0)
                outputs.append(take);checks.append(dict(first=int(ix[0]),last=int(ix[-1]),control=float(oldk[control]),hierarchy_cap=cap,max_relative=worst))
    full=np.concatenate(outputs);assert len(full)==len(nodes)
    packet(f'native-{model}.npz',eta=times,k=nodes,names=custom,standard=names,base=full[:,:,:len(names)],custom=full[:,:,len(names):],**fields)
    table(f'capture-{model}.csv',checks)
    print(model,'exact legs and controls complete:',len(nodes),len(checks),flush=True)

def main():
    guard()
    if sys.argv[1:2]!=['--child']:
        with tempfile.TemporaryDirectory(dir=HERE,prefix='reader-') as folder:
            subprocess.run([sys.executable,'-B',str(HERE/'capture_exact.py'),'--child',folder,*sys.argv[1:]],check=True)
        return
    with patch.object(driver,'HERE',HERE),patch.object(driver,'run',capture),patch.object(driver,'save',save):driver.main()
if __name__=='__main__':main()
