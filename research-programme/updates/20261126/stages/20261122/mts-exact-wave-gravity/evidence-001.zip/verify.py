from local_io import *
import ast

def read_csv(key):
    with (HERE/key).open(newline='') as src:return list(csv.DictReader(src))

def verify():
    guard()
    for key in ('sources.py','evolve.py','capture.py','DESIGN.md','RESULTS.md'):pin(key)
    for path in HERE.glob('*.py'):ast.parse(path.read_text(encoding='utf-8'),filename=str(path))
    legs=json.loads((HERE/'legs.json').read_bytes())
    assert len(set(legs['squared_radii']))==782 and legs['counts']==[755,1257,1492,1492,1169]
    assert not any(HERE.glob('reader-*'))
    for model in ('cold','heavy'):
        cap=read_csv(f'capture-{model}.csv')
        assert len(cap)==38 and max(float(r['max_relative']) for r in cap)<2e-5
        assert [ii for r in cap for ii in range(int(r['first']),int(r['last'])+1)]==list(range(782))
        with np.load(HERE/f'native-{model}.npz') as bank:
            times=bank['eta'];kn=bank['k']
            assert np.array_equal(kn,legs['fund_Mpc_inv']*np.sqrt(legs['squared_radii']))
        with np.load(pin(f'native-{model}.npz')) as bank:assert np.array_equal(times,bank['eta'])
        for key in ('sources','metric-input','angular'):
            with np.load(HERE/f'{key}-{model}.npz') as bank:
                assert np.array_equal(bank['coord'],PROBES) and np.array_equal(bank['eta'],times)
                assert np.isfinite(bank['values']).all()
        for key in ('gravity','scatter'):
            checks=read_csv(f'{key}-check-{model}.csv')
            for test in (('dual','metric_projection','halve_step') if key=='gravity' else ('dual','additivity','alternative_launch_linearity','half_step','angular_and_thermal_order')):
                group=[float(r['worst_probe']) for r in checks if r['field'] in ('phi','psi') and r['test']==test]
                assert len(group)==2 and max(group)<2e-5,(model,key,test,group)
        assert max(float(r['relative']) for r in read_csv(f'angular-check-{model}.csv'))<2e-5
        g=read_csv(f'octupole-budget-{model}.csv');assert len(g)==10 and all(float(r['sup_to_endpoint_gain'])>0 for r in g)
        assert max(float(r['relative']) for r in read_csv(f'attained-gain-{model}.csv'))<2e-5
        assert max(float(r['norm_fraction']) for r in read_csv(f'poisson-budget-{model}.csv') if r['component']=='two_route_mismatch')<2e-5
        assert len(list(HERE.glob(f'gravity-{model}-*.npz')))==7 and len(list(HERE.glob(f'scatter-{model}-*.npz')))==8
    assert len(read_csv('kernel-tests.csv'))==24 and max(float(r['abs_error']) for r in read_csv('kernel-tests.csv'))<2e-7
    assert len(read_csv('exchange-tests.csv'))==4 and all(abs(float(r['rest_energy_exchange_residual']))<2e-12 for r in read_csv('exchange-tests.csv'))
    assert max(float(r['max_relative_native']) for r in read_csv('opacity-from-charge.csv'))<2e-5
    sources_docs={str(path.relative_to(HERE.parent)):sha(path) for pattern in ('4947-*.md','5211-*.md') for path in HERE.parent.glob(pattern)}
    assert len(sources_docs)==2
    files={p.name:sha(p) for p in sorted(HERE.iterdir()) if p.is_file() and p.name!='seal.json'}
    record('seal.json',dict(files=files,predecessor=sha(PRE/'seal.json'),action_documents=sources_docs,scope='conditional classical scalar projections, five specified wavevectors on both backgrounds; not an observational test'))
    print(len(files),'files checked',sha(HERE/'seal.json'))
if __name__=='__main__':verify()
