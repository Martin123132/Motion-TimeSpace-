import csv, hashlib, io, json, os, sys
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

HERE=Path(__file__).resolve().parent
PRE=HERE.parent/"mts-m12i-responsive-curvature-20261122"
def sha(path):
    with path.open("rb") as src:return hashlib.file_digest(src,"sha256").hexdigest()
assert sha(PRE/"seal.json")=="bdbcbae132bb99fdc6d99a67c928c88ee788081a31d7e59b26452692a53dc2d8"
manifest=json.loads((PRE/"seal.json").read_bytes())["files"]
def pin(key):
    path=PRE/key;assert sha(path)==manifest[key],key
    return path
for key in ("capture.py","stage_io.py","evolve.py","sources.py","metric_control.py"):pin(key)
sys.path.insert(0,str(PRE))
import stage_io as parent
from stage_io import np,Mixed,PROBES
import sources,evolve,metric_control
sys.path.insert(0,str(HERE))
def guard():
    parent.guard();assert __debug__ and not (HERE/"STOP-REQUESTED").exists()
def save(name,blob):
    guard();path=HERE/name
    if path.exists():
        assert sha(path)==hashlib.sha256(blob).hexdigest(),name
    else:
        with path.open("xb") as dst:dst.write(blob)
def packet(name,**obj):
    buf=io.BytesIO();np.savez_compressed(buf,**obj);save(name,buf.getvalue())
def table(name,rows):
    buf=io.StringIO();wr=csv.DictWriter(buf,rows[0],lineterminator="\n");wr.writeheader();wr.writerows(rows);save(name,buf.getvalue().encode())
def record(name,obj):save(name,(json.dumps(obj,sort_keys=True,indent=2,allow_nan=False)+"\n").encode())
def geometry():
    modes=Mixed();shells=[];counts=[]
    for axis in PROBES:
        op=sources.Pair(modes,np.asarray(axis),SimpleNamespace(first={}))
        radii=np.r_[op.q2,op.p2]/modes.big.fund**2
        assert max(abs(radii-radii.round()))<1e-10
        shells.extend(radii.round().astype(int));counts.append(op.pair_count)
    return modes,np.unique(shells),counts
