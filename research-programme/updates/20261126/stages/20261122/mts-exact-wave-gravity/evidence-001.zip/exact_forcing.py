from local_io import *
from scipy.interpolate import make_interp_spline

class ExactPair(sources.Pair):
    def __init__(self,modes,coord,data):
        super().__init__(modes,coord,SimpleNamespace(first={}))
        def find(r2):
            shell=np.rint(r2/modes.big.fund**2).astype(int)
            pos=np.searchsorted(data.shell,shell)
            assert np.array_equal(data.shell[pos],shell)
            assert np.max(abs(data.nodes[pos]**2/r2-1))<8e-15
            return pos
        left=find(self.q2);right=find(self.p2)
        self.parts={name:(val[left],val[right]) for name,val in data.first.items()}
def load_data(model):
    with patch.object(sources,'HERE',HERE):data=sources.Data(model)
    data.shell=np.array(json.loads((HERE/'legs.json').read_bytes())['squared_radii'])
    assert len(data.nodes)==len(data.shell)==782;return data
def run(model):
    data=load_data(model);modes=Mixed();sources_all=[];geom_all=[];counts=[]
    for axis in PROBES:
        guard()
        with patch.object(sources,'Pair',ExactPair),patch.object(metric_control,'Pair',ExactPair):
            piece,count=sources.make(modes,np.array(axis),data,model)
            alt=metric_control.metric_drive(modes,np.array(axis),data)
        counts.append(count);sources_all.append(piece);geom_all.append(alt)
    for name,values in [('sources',sources_all),('metric-input',geom_all)]:
        keys=list(values[0]);arr=np.array([[row[key] for row in values] for key in keys])
        assert np.isfinite(arr).all()
        packet(f'{name}-{model}.npz',eta=data.eta,coord=PROBES,k=np.linalg.norm(PROBES,axis=1)*modes.big.fund,names=keys,values=arr,counts=counts,bg_keys=list(data.background),background=np.array(list(data.background.values())))
    print(model,'exact forces',counts,flush=True)
if __name__=='__main__':
    for model in sys.argv[1:] or ('cold','heavy'):run(model)
