from local_io import *
from exact_forcing import load_data,ExactPair
from scipy.interpolate import make_interp_spline
from scipy.special import eval_legendre

def angles(order=8):
    mu,w=np.polynomial.legendre.leggauss(order);azimuth=np.arange(2*order)*np.pi/order
    return np.repeat(mu,2*order),np.repeat(np.sqrt(1-mu**2),2*order)*np.tile(np.cos(azimuth),order),np.repeat(w/(4*order),2*order)

def oriented(k,qmag,pmag,kdotp,dot,order):
    mu,nx,weight=angles(order);kp=kdotp/k;hz=np.clip(kp/pmag,-1,1);hx=np.sqrt(1-hz**2)
    mp=hz[:,None]*mu+hx[:,None]*nx
    ndotp=pmag[:,None]*mp;ndotq=k*mu-ndotp
    dw=(dot/pmag)[:,None]-ndotq*mp
    tz=hz[:,None]-mu*mp;wz=(k-kp)[:,None]-mu*ndotq
    tzz=tz**2-(1-mp**2)*(1-mu**2)/2
    dtzz= -2*mp*wz*tz+mp*dw*(1-mu**2)
    avg=lambda arr:arr@weight
    poly=[np.ones_like(mp),mp,(3*mp**2-1)/2,(5*mp**3-3*mp)/2]
    deriv=[0.,1.,3*mp,(15*mp**2-3)/2]
    terms={}
    for ell in (0,1,2):
        for jj in range(4):
            if abs(ell-jj)!=1:continue
            pref=((1j**ell)*(-1j)**(jj+1)).real*(2*jj+1)
            val=eval_legendre(ell,mu)*((ndotp+4*ndotq)*poly[jj]-dw*deriv[jj])
            terms[f'L{ell}{jj}']=pref*avg(val)
    terms['Le3']=-8.75*avg((ndotp+4*ndotq)*mp*tzz-dw*tzz-mp*dtzz)
    terms['Ct3']=-7*avg(eval_legendre(2,mu)*ndotq*poly[3])
    terms['Ce3']=-8.75*avg(ndotq*mp*tzz)
    return terms

def make(op,order):
    k=np.sqrt(op.k2)
    left=oriented(k,np.sqrt(op.q2),np.sqrt(op.p2),op.kp,op.dot,order)
    right=oriented(k,np.sqrt(op.p2),np.sqrt(op.q2),op.kq,op.dot,order)
    def summ(one,two,name):return op.product(one,two,left[name],right[name])
    p=op.product;g=op.grad
    source={}
    for ell in (0,1,2):
        source[f'L{ell}']=sum(summ('G',tag,f'L{ell}{jj}') for jj,tag in enumerate(['Xg','M1','M2','M3']) if abs(jj-ell)==1)
    source['L1']=k*source['L1']+4*op.k2*(p('phi','phi')-p('psi','psi')+.5*p('G','G'))/3
    source['Le']=summ('G','E3','Le3')
    bb=op.shear('Vb','Vb');bv=op.shear('Vb','Vg')
    source['CIkin']=-2*(7*bb+1.5*bv)/15+summ('Vb','M3','Ct3')
    source['CEkin']=(2*bv-4*bb/3)/10+summ('Vb','E3','Ce3')
    source['CIrate']=op.spin('rate','CI1')
    source['CErate']=op.spin('rate','CE1')
    return source

def run(model):
    data=load_data(model);modes=Mixed();rr=data.raw;kn=data.nodes[:,None]
    with np.load(HERE/('polar-'+model+'.npz')) as pol:
        assert np.array_equal(pol['k'],data.nodes) and np.array_equal(pol['eta'],data.eta)
        e3=pol['E3'];edot=pol['E2dot']
    pp=rr['polter'];opac=rr['opacity'];e2=rr['E(2)'];m2=rr['pig'];m3=rr['octg'];m1=kn*data.first['Vg']
    data.first.update(M1=m1,M2=m2,M3=m3,E3=e3,
        rate=data.first['Db']+3*data.first['phi']+data.first['psi'],CI1=pp-m2,CE1=pp-e2)
    rows=[];by_probe=[]
    rel=lambda left,right:float(np.linalg.norm(left-right)/max(np.linalg.norm(right),1e-100))
    for name,measured,want in [('linear_I2',rr['pigdot'],kn*(2*m1-3*m3)/5+opac*(pp-m2)),
                                ('linear_E2',edot,-kn*e3/3+opac*(pp-e2)),
                                ('linear_thomson_source',pp,.1*m2+.6*e2)]:
        rows.append(dict(check=name,probe='all',relative=rel(measured,want)))
    with np.load(HERE/f'sources-{model}.npz') as bank:
        prior=dict(zip(bank['names'],bank['values']))
    for ii,axis in enumerate(PROBES):
        guard();op=ExactPair(modes,np.array(axis),data);out=make(op,8);higher=make(op,10)
        for name in out:rows.append(dict(check='angle_'+name,probe=str(axis),relative=rel(out[name],higher[name])))
        for term,old in [('L0','ph_energy'),('L1','ph_momentum')]:
            rows.append(dict(check='transport_'+term,probe=str(axis),relative=rel(out[term],prior[old][ii])))
        by_probe.append(out)
    bm=-(prior['ph_bulk']+prior['ph_shift'])
    keys=list(by_probe[0]);shape=np.array([[rc[key] for rc in by_probe] for key in keys])
    keys+=['Mboost','Mboostdot'];shape=np.concatenate((shape,bm[None],make_interp_spline(data.eta,bm,k=5,axis=1).derivative()(data.eta)[None]))
    assert np.isfinite(shape).all()
    packet(f'angular-{model}.npz',coord=PROBES,eta=data.eta,names=keys,values=shape)
    table(f'angular-check-{model}.csv',rows)
    print(model,[(row['check'],round(row['relative'],9)) for row in rows if not row['check'].startswith('angle')],flush=True)
if __name__=='__main__':
    for model in sys.argv[1:] or ('cold','heavy'):run(model)
