from local_io import *
from gravity import compare

class Scattering(evolve.Evolution):
    def __init__(self,model,part='both',launch='same',ell=8,order=12):
        with patch.object(evolve,'HERE',HERE):super().__init__(model,lmax=ell,order=order)
        self.part=part;self.launch=launch
        with np.load(HERE/f'angular-{model}.npz') as bank:
            assert np.array_equal(bank['eta'],self.times) and np.array_equal(bank['coord'],PROBES)
            rest=bank['values'];self.names+=bank['names'].tolist()
        self.drive=parent.CubicSpline(self.times,np.concatenate((self.drive(self.times),rest.transpose(2,0,1)/evolve.UNIT),axis=1))
        vals=dict(zip(self.names,self.drive(self.times[0])))
        ci=vals['CIkin']+vals['CIrate'];ce=vals['CEkin']+vals['CErate']
        eqM=(.4*ci+.6*ce)/.3;eqE=(.1*ci+.9*ce)/.3
        self.offset=np.zeros((self.rows,5),complex)
        if launch!='same':
            sign={'equilibrium':1,'opposite':-1}[launch]
            self.offset[self.ph_sl.start]=sign*(eqM-vals['Mboost'])
            self.offset[self.pol_sl.start]=5*sign*eqE;self.offset[self.pol_sl.start+2]=sign*eqE
    def rhs(self,env,state,kind,variant,observe=False):
        b,q=env
        out=super().rhs(env,state+self.offset,kind,variant,observe)
        if observe:return out
        op=b['opacity'];bm=q['Mboost']
        if self.part in ('both','kinetic'):
            inc=op*(q['CIkin']+q['CIrate']-.9*bm)-q['Mboostdot']
            pol=op*(q['CEkin']+q['CErate']+.1*bm)
            out[self.ph_sl.start]+=inc
            out[self.ph_sl.start+1]+=3*self.kn*bm/7
            out[self.pol_sl.start]+=5*pol;out[self.pol_sl.start+2]+=pol
        if self.part in ('both','transport'):
            out[self.ph_sl.start]+=q['L2']
            out[self.pol_sl.start]+=5*q['Le'];out[self.pol_sl.start+2]+=q['Le']
        return out

def run(model):
    rows=[];records={}
    with np.load(HERE/f'gravity-{model}-trace-full-0-1.npz') as old:baseline=old['values']
    for part,kind,launch,sub,ell,nq in [('both','trace','same',1,8,12),('both','conserved','same',1,8,12),('both','trace','same',2,8,12),
        ('both','trace','same',1,12,24),('kinetic','trace','same',1,8,12),('transport','trace','same',1,8,12),
        ('both','trace','equilibrium',1,8,12),('both','trace','opposite',1,8,12)]:
        ev=Scattering(model,part,launch,ell,nq)
        with patch.object(evolve,'guard',guard):arr=ev.integrate(kind,sub=sub)
        label=f'{part}-{kind}-{launch}-{sub}-{ell}'
        packet(f'scatter-{model}-{label}.npz',coord=PROBES,eta=ev.times,names=evolve.OBS,values=arr);records[label]=arr
    ref=records['both-trace-same-1-8'];equil=records['both-trace-equilibrium-1-8'];opposite=records['both-trace-opposite-1-8']
    for key,one,two in [('quadrupole_vs_old',ref,baseline),('transport_vs_old',records['transport-trace-same-1-8'],baseline),
        ('collision_and_representation_vs_old',records['kinetic-trace-same-1-8'],baseline),
        ('additivity',records['kinetic-trace-same-1-8']+records['transport-trace-same-1-8']-baseline,ref),
        ('dual',records['both-conserved-same-1-8'],ref),('half_step',records['both-trace-same-2-8'],ref),
        ('angular_and_thermal_order',records['both-trace-same-1-12'],ref),('alternative_launch',equil,ref),
        ('alternative_launch_linearity',(equil+opposite)/2,ref),('final_launch',equil[-1:],ref[-1:]),('final_vs_old',ref[-1:],baseline[-1:])]:
        compare(rows,model,key,one,two)
    table(f'scatter-check-{model}.csv',rows)
    selected=('quadrupole_vs_old','dual','half_step','final_launch','final_vs_old')
    print(model,[(r['test'],r['field'],float('%.4g'%r['panel'])) for r in rows if r['test'] in selected and r['field'] in ('psi','photonshear')],flush=True)
if __name__=='__main__':
    for model in sys.argv[1:] or ('cold','heavy'):run(model)
