from local_io import *
from scatter_response import Scattering
from octupole_gain import Linear

class ReadConserved(Scattering):
    def rhs(self,env,state,kind,variant,observe=False):
        if not (observe and kind=='conserved'):return super().rhs(env,state,kind,variant,observe)
        rec=super().rhs(env,state,kind,variant,True)
        return np.vstack((state[self.idx['geom']],state[self.idx['flux']],rec))

def run(model):
    ev=ReadConserved(model);arr=ev.integrate('conserved');coordX,coordY=arr[:,0],arr[:,1];old=arr[:,2:]
    times=ev.times;raw=ev.drive(times)*evolve.UNIT;q={key:raw[:,ii] for ii,key in enumerate(ev.names)}
    back=dict(zip(ev.bkeys,ev.back(times).T[:,:,None]));k2=ev.kn**2;h=back['h'];eg=back['eg'];et=back['et']
    F=-eg*(coordY+q['Jq'])/(2*k2)
    phi=(q['U']-.5*eg*(coordX-q['Xq'])+3*h*F)/(k2+2*et)
    norm_density=eg*(coordX-q['Xq'])+4*et*phi
    material=q['cshear']+q['bshear']+sum(q[tag+'shear'] for tag in ev.labels)
    s=material+old[:,14]+old[:,15]
    with np.load(HERE/f'scatter-{model}-both-trace-same-1-8.npz') as src:target=src['values']
    ratios=[];out={}
    for name,mult,ref in [('force',1,target[:,1]),('lensing',.5,(target[:,0]+target[:,1])/2)]:
        terms=dict(normal_density=-norm_density/2,expansion_current=3*h*F,spatial_curvature=q['U'],canonical_plus_dust_shear=mult*material,
            photon_shear=mult*old[:,14],neutrino_shear=mult*old[:,15],quadratic_metric_slip=-mult*q['Q'])
        for key,val in terms.items():out[name+'_'+key]=val
        ref=k2*ref
        for ii,axis in enumerate(PROBES):
            geom=ref[:,ii];norm=np.linalg.norm(geom);total=sum(val[:,ii] for val in terms.values())
            for key,val in terms.items():
                diff=val[:,ii]
                ratios.append(dict(observable=name,probe=str(axis),component=key,norm_fraction=np.linalg.norm(diff)/norm,
                    signed_fraction=np.vdot(geom,diff).real/norm**2))
            delta=total-geom
            ratios.append(dict(observable=name,probe=str(axis),component='two_route_mismatch',norm_fraction=np.linalg.norm(delta)/norm,signed_fraction=np.vdot(geom,delta).real/norm**2))
            assert ratios[-1]['norm_fraction']<2e-5
            delta=terms['normal_density'][:,ii]-geom
            ratios.append(dict(observable=name,probe=str(axis),component='normal_density_alone_minus_target',norm_fraction=np.linalg.norm(delta)/norm,signed_fraction=np.vdot(geom,delta).real/norm**2))
    packet('effective-poisson-'+model+'.npz',coord=PROBES,eta=times,k=ev.kn,raw_x=coordX,raw_y=coordY,**out)
    table('poisson-budget-'+model+'.csv',ratios)

def check_gain(model):
    ev=Scattering(model);lin=Linear(ev)
    with np.load(HERE/f'retarded-octupole-{model}.npz') as archive:
        ts=archive['eta'];row=archive['psi']
    mag=np.linalg.norm(row,axis=1);unit=np.divide(row,mag[:,None,:],out=np.zeros_like(row),where=mag[:,None,:]>0)
    from scipy.integrate import simpson
    pred=simpson(mag,x=ts,axis=0);state=np.zeros((lin.rows,5));b=ev.back(ts)
    for ii in range(len(ts)-1):
        if ii%256==0:guard()
        dt=ts[ii+1]-ts[ii];half=ev.back(.5*(ts[ii]+ts[ii+1]));mid=.5*(unit[ii]+unit[ii+1])
        a=lin.forward(b[ii],state,unit[ii]);c=lin.forward(half,state+dt*a/2,mid);d=lin.forward(half,state+dt*c/2,mid);e=lin.forward(b[ii+1],state+dt*d,unit[ii+1])
        state+=dt*(a+2*c+2*d+e)/6
    first=np.zeros_like(state);weights=lin.reverse(lin.coeff(b[-1]),first,'psi');actual=np.sum(weights*state,axis=0)
    assert max(abs(actual/pred-1))<2e-5
    table('attained-gain-'+model+'.csv',[dict(probe=str(axis),adjoint=bound,direct=val,relative=abs(val/bound-1)) for axis,bound,val in zip(PROBES,pred,actual)])
if __name__=='__main__':
    for model in sys.argv[1:] or ('cold','heavy'):
        run(model);check_gain(model)
