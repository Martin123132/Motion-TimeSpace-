from local_io import *

def norm(diff,ref):
    denom=np.linalg.norm(ref)
    return float(np.linalg.norm(diff)/denom) if denom else None
def compare(rows,model,label,left,right):
    for jj,key in enumerate(evolve.OBS):
        err=left[:,jj]-right[:,jj];ref=right[:,jj];val=norm(err,ref)
        if val is None:continue
        modes=[norm(one,other) for one,other in zip(err.T,ref.T)]
        rows.append(dict(model=model,test=label,field=key,panel=val,worst_probe=max(modes),rms_ref=float(np.sqrt(np.mean(abs(ref)**2)))))
def run(model):
    rows=[];results={}
    for kind,variant,metric,step in [('trace','full',False,1),('conserved','full',False,1),('trace','full',True,1),('conserved','full',True,1),('trace','full',False,2),('slip','full',False,1),('trace','bulk',False,1)]:
        label=f'{kind}-{variant}-{int(metric)}-{step}'
        with patch.object(evolve,'HERE',HERE),patch.object(evolve,'guard',guard): 
            ev=evolve.Evolution(model,metric=metric);out=ev.integrate(kind,variant,step)
        packet(f'gravity-{model}-{label}.npz',eta=ev.times,coord=PROBES,names=evolve.OBS,values=out);results[label]=out
    base=results['trace-full-0-1'];con=results['conserved-full-0-1'];alt=results['trace-full-1-1']
    with np.load(pin(f'nativeclock-{model}-trace-full-1-1-8-12.npz')) as src:
        assert np.array_equal(ev.times,src['eta']);compare(rows,model,'previous_interpolated_minus_exact',src['values'],base)
    for label,left,right in [('dual',con,base),('dual_metric_control',results['conserved-full-1-1'],alt),('metric_projection',alt,base),('halve_step',results['trace-full-0-2'],base),('fixed_curvature',results['slip-full-0-1'],base),('bulk_only',results['trace-bulk-0-1'],base)]:compare(rows,model,label,left,right)
    table('gravity-check-'+model+'.csv',rows)
    for r in rows:
        if r['field']=='phi':print(r,flush=True)
if __name__=='__main__':
    for model in sys.argv[1:] or ('cold','heavy'):run(model)
