from local_io import *
from scatter_response import Scattering
from scipy.integrate import simpson

class ReadHigh(Scattering):
    def rhs(self,env,state,kind,variant,observe=False):
        if observe and kind=='trace':
            return np.array([state[self.ph_sl.start+1],.3*(state[self.pol_sl.start+1]+state[self.pol_sl.start+3])])
        return super().rhs(env,state,kind,variant,observe)

class Linear:
    def __init__(self,ev):
        self.ev=ev;self.idx=ev.idx;self.M=len(ev.idx);self.E=self.M+1;self.lo=self.E+1;self.nl=ev.lmax+1
        self.rows=self.lo+(ev.order+1)*self.nl;self.k=ev.kn
    def coeff(self,bg):
        ev=self.ev;b=dict(zip(ev.bkeys,bg));am=ev.metas['mass_over_temperature']*b['a'];eps=np.hypot(ev.nodes,am)
        thermal=ev.weights*ev.metas['massless_limit_coeff']/(b['a']**2*(7*np.pi**4/120))
        v=np.r_[1.,ev.nodes/eps]; shear=np.r_[-4*b['er'],-thermal*ev.nodes**4/eps]
        trace=np.r_[0.,thermal*ev.nodes**2*am**2/eps]
        return b,v,shear,trace
    def reverse(self,coeff,adj,observable=None):
        b,v,shear,mtrace=coeff;k=self.k;k2=k*k;eg=b['eg'];eb=b['eb'];ec=b['ec'];op=b['opacity'];h=b['h'];ix=self.idx
        deriv=np.zeros_like(adj);nu=deriv[self.lo:].reshape(-1,self.nl,len(k));an=adj[self.lo:].reshape(nu.shape)
        A=lambda name:adj[ix[name]]
        if observable:
            phi=np.ones_like(k);slip={'psi':1.,'weyl':.5}[observable]*phi
            deriv[ix['geom']]=phi
            deriv[self.M]-=slip*eg/k2;nu[:,2]+=shear[:,None]*slip/k2
            return deriv
        flux=A('flux');pd=A('geom')+np.sum(an[:,0],axis=0)
        phi=-h*pd+(b['hp']-h*h)*flux+k2*flux/3
        slip=-h*pd+(b['hp']-h*h)*flux-k2*flux/3
        deriv[ix['flux']]+=-pd-3*h*flux
        dd=flux/6
        phi+=3*(ec+eb)*dd
        nu[:,0]+=mtrace[:,None]*dd
        for tag,coef in [('c',ec),('b',eb)]:
            deriv[ix[tag+'d']]+=coef*dd
            deriv[ix[tag+'t']]+=-A(tag+'d')-h*A(tag+'t')
            psi=k2*A(tag+'t');phi+=psi;slip+=psi
        for tag in self.ev.labels:
            vv=b[tag+'v'];bb=b[tag+'b'];mass=(b['a']*b[tag+'m'])**2
            af=A(tag+'f');aw=A(tag+'w');phi+=-6*vv**2*dd+4*vv*af+2*mass*bb*aw
            slip+=vv*af-mass*bb*aw
            deriv[ix[tag+'f']]+=4*mass*bb*dd-(k2+mass)*aw
            deriv[ix[tag+'w']]+=-2*vv*dd+af-2*h*aw
        aj=A('gj');drag=op*(eg/eb*A('bt')-aj)
        deriv[ix['bt']]-=4*drag/3
        deriv[ix['gj']]+=drag-A('gx')+.4*adj[self.M]
        deriv[ix['gx']]+=k2*aj/3
        phi+=8*k2*aj/3;slip+=4*k2*aj/3
        deriv[self.M]+=-2*k2*aj/3+op*(-.9*adj[self.M]+.1*adj[self.E])
        deriv[self.E]+=op*(.6*adj[self.M]-.4*adj[self.E])
        speed=v[:,None,None]*k;ell=np.arange(self.nl)[:,None]
        nu[:,:-1]+=speed*(ell[1:]/(2*ell[1:]+1))*an[:,1:]
        nu[:,1:]-=speed*((ell[:-1]+1)/(2*ell[:-1]+1))*an[:,:-1]
        psi=np.sum(k*an[:,1]/(3*v[:,None]),axis=0);phi+=psi;slip+=psi
        deriv[ix['geom']]+=phi
        deriv[self.M]-=eg*slip/k2;nu[:,2]+=shear[:,None]*slip/k2
        return deriv
    def forward(self,bg,state,high):
        ev=self.ev
        raw=np.zeros((ev.rows,5),complex);raw[:self.M]=state[:self.M];raw[ev.ph_sl.start]=state[self.M];raw[ev.ph_sl.start+1]=high[0]
        raw[ev.pol_sl.start]=5*state[self.E];raw[ev.pol_sl.start+2]=state[self.E];raw[ev.pol_sl.start+1]=10*high[1]/3
        raw[ev.nu_sl]=state[self.lo:];en=(dict(zip(ev.bkeys,bg)),{key:0 for key in ev.names})
        out=evolve.Evolution.rhs(ev,en,raw,'trace','full')
        return np.vstack((out[:self.M],out[ev.ph_sl.start],(out[ev.pol_sl.start]+out[ev.pol_sl.start+2])/6,out[ev.nu_sl])).real
    def kernel(self,observable,sub):
        ev=self.ev;clock=ev.times;ts=np.interp(np.arange((len(clock)-1)*sub*2+1)/(sub*2),np.arange(len(clock)),clock)
        bg=ev.back(ts);adj=np.zeros((self.rows,5));adj=self.reverse(self.coeff(bg[-1]),adj,observable)
        item=lambda:np.stack((-3*self.k*adj[self.M]/5,-self.k*adj[self.E]/3))
        hist=[item()];p1=self.coeff(bg[-1])
        for ii in range(len(ts)-1,0,-2):
            if ii%512==0:guard()
            pm=self.coeff(bg[ii-1]);p0=self.coeff(bg[ii-2]);dt=ts[ii]-ts[ii-2]
            a=self.reverse(p1,adj);b=self.reverse(pm,adj+dt*a/2);c=self.reverse(pm,adj+dt*b/2);d=self.reverse(p0,adj+dt*c)
            adj+=dt*(a+2*b+2*c+d)/6;p1=p0;hist.append(item())
        return ts[::2],np.array(hist[::-1])

def run(model):
    ev=ReadHigh(model);high=ev.integrate('trace')
    packet('realized-octupoles-'+model+'.npz',eta=ev.times,values=high,names=['intensity_M3','polarization_E3'])
    lin=Linear(ev);rng=np.random.default_rng(281121);left=rng.normal(size=(lin.rows,5));right=rng.normal(size=left.shape)
    test=[]
    for ii in (0,111,245,512):
        back=ev.back(ev.times[ii]);a=np.sum(left*lin.forward(back,right,np.zeros((2,5))),axis=0)
        b=np.sum(lin.reverse(lin.coeff(back),left)*right,axis=0)
        assert np.allclose(a,b,rtol=1e-11,atol=1e-10)
        test.append(dict(index=ii,max_error=float(max(abs(a-b)))))
    with np.load(HERE/f'scatter-{model}-both-trace-same-1-8.npz') as bank:result=bank['values']
    rows=[];waves={};rms=np.max(np.linalg.norm(high,axis=1),axis=0)
    for obs in ('psi','weyl'):
        coarse,one=lin.kernel(obs,1);fine,two=lin.kernel(obs,2)
        weights=simpson(np.linalg.norm(two,axis=1),x=fine,axis=0);slow=simpson(np.linalg.norm(one,axis=1),x=coarse,axis=0)
        assert max(abs(slow/weights-1))<2e-5
        target=abs(result[-1,1] if obs=='psi' else .5*(result[-1,0]+result[-1,1]))
        waves[obs]=two
        assert np.all(target>0) and np.all(rms>0)
        for ii,coord in enumerate(PROBES):
            rows.append(dict(model=model,observable=obs,probe=str(coord),final_abs=target[ii],sup_to_endpoint_gain=weights[ii],
                sup_octupole_needed_for_half_percent=.005*target[ii]/weights[ii],
                realized_octupole_sup=rms[ii],threshold_over_realized=.005*target[ii]/(weights[ii]*rms[ii]),
                relative_gain_refinement=abs(slow[ii]/weights[ii]-1)))
    packet('retarded-octupole-'+model+'.npz',eta=fine,coord=PROBES,**waves)
    table('adjoint-'+model+'.csv',test);table('octupole-budget-'+model+'.csv',rows)
if __name__=='__main__':
    for model in sys.argv[1:] or ('cold','heavy'):run(model)
