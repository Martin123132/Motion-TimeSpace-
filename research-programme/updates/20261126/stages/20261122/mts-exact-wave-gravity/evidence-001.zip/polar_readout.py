from local_io import *
import capture as driver
import diagnostics as previous
import subprocess,tempfile
from sympy import Dummy
READ=["k","tau","pig","E(2)","E(3)","Edot(2)","octg"]
def measure(model,func):
    native=previous.native;status=native.obj(native.source(f'runs/{model}/status.json'))
    file=native.SPEC/"runs/projection/a225-w6-d8.npz" if model=="heavy" else native.NATIVE/"runs/backgrounds/cold.npz"
    native.checked(file,status["source_hash"])
    for path in native.engine.inherited.native_hashes():native.checked(path,status["input_hashes"][str(path)])
    params=native.engine.inherited.params_for(file,background_boost=8.);params.DoLateRadTruncation=False
    bg=native.engine.camb.get_background(params);bg.Params.Accuracy.IntTolBoost=6
    with np.load(HERE/f'native-{model}.npz') as archive:
        times=archive['eta'];kn=archive['k'];names=archive['names'].tolist()
        control=archive['custom'][:,:,[names.index(key) for key in ['pig','E(2)','octg']]]
    with (HERE/f'capture-{model}.csv').open() as src:blocks=list(csv.DictReader(src))
    out=[]
    with patch.object(previous.symbolic,'compile_sympy_to_camb_source_func',return_value=func):
        for block in blocks:
            guard();nodes=kn[int(block['first']):int(block['last'])+1]
            batch=np.unique(np.r_[nodes,float(block['control']),float(block['hierarchy_cap'])])
            current=bg.get_time_evolution(batch,times,vars=[Dummy(key) for key in READ],lAccuracyBoost=4)[np.searchsorted(batch,nodes)]
            out.append(current)
    data=np.concatenate(out);assert np.allclose(data[:,:,0],kn[:,None],rtol=1e-14,atol=0)
    assert np.isfinite(data).all()
    for jj,kk in enumerate([2,3,6]):assert np.linalg.norm(data[:,:,kk]-control[:,:,jj])<2e-5*np.linalg.norm(control[:,:,jj])
    packet('polar-'+model+'.npz',k=kn,eta=times,E3=data[:,:,4],E2dot=data[:,:,5])
    print('polarization octupoles',model,flush=True)
def main():
    if sys.argv[1:2]!=['--child']:
        with tempfile.TemporaryDirectory(dir=HERE,prefix='reader-pol-') as folder:
            subprocess.run([sys.executable,'-B',str(HERE/'polar_readout.py'),'--child',folder,*sys.argv[1:]],check=True)
        return
    with patch.object(driver,'HERE',HERE),patch.object(driver,'NAMES',READ),patch.object(driver,'run',measure),patch.object(driver,'save',lambda name,body:save('polar-'+name,body)):
        driver.main()
if __name__=='__main__':main()
