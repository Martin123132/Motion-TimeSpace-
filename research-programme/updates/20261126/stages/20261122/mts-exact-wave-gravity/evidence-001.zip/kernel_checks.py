from local_io import *
from angular import oriented

def sphere(order):
    mu,wt=np.polynomial.legendre.leggauss(order);az=np.arange(order*2)*np.pi/order
    z=np.repeat(mu,2*order);r=np.sqrt(1-z*z);co=np.tile(np.cos(az),order);si=np.tile(np.sin(az),order)
    return np.c_[r*co,r*si,z],np.c_[z*co,z*si,-r],np.c_[-si,co,0*z],np.repeat(wt/(4*order),2*order)

def tensor(s,h):
    mu=s@h;u=h-mu[:,None]*s;proj=np.eye(3)-np.einsum('si,sj->sij',s,s)
    return np.einsum('si,sj->sij',u,u)-(1-mu**2)[:,None,None]*proj/2

def real_moments(s,h,v1,m2,a3,e2,e3):
    mu=s@h
    intensity=.28+3*(s@v1)-5*m2*(3*mu**2-1)/2+7*a3*(5*mu**3-3*mu)/2
    pol=(7.5*e2+17.5*e3*mu)[:,None,None]*tensor(s,h)
    return intensity,pol

def full_collision(amp,s,et,ep,wt,beta,inc,linear,rate,angular_output=False):
    vel=amp*beta;t=s@vel;gam=1/np.sqrt(1-vel@vel)
    ds=gam*(1-t);intensity=1+amp*inc;H=amp*linear;mu=s@s.T
    D=ds[:,None];Din=ds[None,:];cosrel=1-(1-mu)/(D*Din)
    gain=.75*(1+cosrel**2)@(wt*intensity*ds**2)/ds**3
    a=Din[:,:,None]*s[:,None,:]-gam*(1-mu)[:,:,None]*vel
    gain-=1.5*np.einsum('osi,sij,osj,s->o',a,H,a,wt)/ds**5
    def brightness(axis):
        contact=axis@s.T-(axis@vel)[:,None]*(1-mu)/(1-t[:,None])
        unpol=-.75*contact**2@(wt*intensity)/ds**3
        ell=axis[:,None,:]+((axis@vel)/(1-t))[:,None,None]*s[:,None,:]+contact[:,:,None]*vel/(1-t[None,:,None])
        return unpol+1.5*np.einsum('osi,sij,osj,s->o',ell,H,ell,wt*ds**2)/ds**3
    qin=np.einsum('oi,oij,oj->o',et,H,et)-np.einsum('oi,oij,oj->o',ep,H,ep)
    factor=1+amp*rate;Is=factor*(gain-ds*intensity);Qs=factor*(brightness(et)-brightness(ep)-ds*qin)
    if angular_output:return Is,Qs
    z=s[:,2];return np.array([-wt@((3*z*z-1)*Is)/2,wt@((1-z*z)*Qs)/4])

def run():
    s,et,ep,wt=sphere(9);z=s[:,2];P2=(3*z*z-1)/2;rng=np.random.default_rng(285333);rows=[]
    dyad=lambda a,b:1.5*(a[2]*b[2]-a@b/3)
    for idx in range(9):
        beta=rng.uniform(-.7,.7,3);v1=rng.uniform(-.8,.8,3);h=rng.normal(size=3);h/=np.linalg.norm(h)
        m2,a3,e2,e3,rate=rng.normal(size=5)
        inc,H=real_moments(s,h,v1,m2,a3,e2,e3)
        pp=m2/10+.6*e2;t=s@beta;mu=s@h
        spin=(3*h[2]**2-1)/2
        want=np.array([-2*(7*dyad(beta,beta)+1.5*dyad(beta,v1))/15 -7*a3*wt@(P2*t*((5*mu**3-3*mu)/2))+rate*spin*(pp-m2),
            (2*dyad(beta,v1)-4*dyad(beta,beta)/3)/10+8.75*e3*wt@(t*mu*tensor(s,h)[:,2,2])+rate*spin*(pp-e2)])
        sample=lambda eps:full_collision(eps,s,et,ep,wt,beta,inc,H,rate)
        zero=sample(0.);seq=[]
        for eps in (.008,.004):seq.append((sample(eps)+sample(-eps)-2*zero)/(2*eps**2))
        response=(4*seq[1]-seq[0])/3
        for field,actual,exact in zip(('temperature','polarization'),response,want):
            error=abs(actual-exact);assert error<2e-7,(idx,field,actual,exact)
            rows.append(dict(control='boosted Thomson '+field,case=idx,analytic=exact,independent=actual,abs_error=error))
    for idx in range(6):
        k=.7+.2*idx;plen=.2+.1*idx;hz=-.83+.29*idx
        h=np.array([np.sqrt(1-hz*hz),0,hz]);p=plen*h;q=np.array([0.,0.,k])-p
        ck=oriented(k,np.array([np.linalg.norm(q)]),np.array([plen]),np.array([k*p[2]]),np.array([p@q]),8)['Le3'][0]
        perp=q-(s@q)[:,None]*s;mag=np.linalg.norm(perp,axis=1);axis=np.cross(s,perp)/mag[:,None]
        crossmat=np.array([[[0,-az,ay],[az,0,-ax],[-ay,ax,0]] for ax,ay,az in axis]);second=crossmat@crossmat
        def carried(eps):
            ang=eps*mag;rot=np.eye(3)+np.sin(ang)[:,None,None]*crossmat+(1-np.cos(ang))[:,None,None]*second
            moved=(rot@s[:,:,None])[:,:,0];ht=(moved@h)[:,None,None]*tensor(moved,h)
            return (rot.transpose(0,2,1)@ht@rot)[:,2,2]
        eps=2e-5;dH=(carried(eps)-carried(-eps))/(2*eps)
        actual=-8.75*wt@(((s@p+4*(s@q))*(s@h))*tensor(s,h)[:,2,2]-dH)
        assert abs(actual-ck)<2e-8
        rows.append(dict(control='parallel transported screen',case=idx,analytic=ck,independent=actual,abs_error=abs(actual-ck)))
    table('kernel-tests.csv',rows)
    exchange=[]
    for idx in range(4):
        v=rng.uniform(-.06,.06,3);ds=(1-s@v)/np.sqrt(1-v@v)
        intensity,pol=full_collision(1,s,et,ep,wt,v,ds**(-4)-1,np.zeros((len(s),3,3)),0,True)
        null=max(np.max(abs(intensity)),np.max(abs(pol)));assert null<2e-12
        h=rng.normal(size=3);h/=np.linalg.norm(h)
        inc,H=real_moments(s,h,.1*v,.012,-.015,.004,-.003)
        gain,_=full_collision(1,s,et,ep,wt,v,inc,H,0,True)
        energy=wt@gain;flux=(wt*gain)@s;work=v@flux
        assert abs(energy-work)<2e-12
        exchange.append(dict(case=idx,moving_isotropic_null=null,photon_energy_gain=energy,electron_frame_velocity_dot_photon_momentum_gain=work,rest_energy_exchange_residual=energy-work))
    table('exchange-tests.csv',exchange);print('kernel controls',len(rows),len(exchange))
if __name__=='__main__':run()
