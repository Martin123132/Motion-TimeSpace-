from regular_io import *
from early_source import read_data
for model in ('cold','heavy'):
    data=read_data(model);b=data.background;f=data.first
    with np.load(HOME/f'origin-v2-{model}.npz') as src:theta=-src['P'][0]/2
    rows=[]
    for tag in ('sh' if model=='heavy' else 's'):
        for i in (0,128,256):
            for key,target in [('f',-b[tag+'v'][i]/b['h'][i]*theta),('n',(b[tag+'v'][i]-b[tag+'vN'][i])*theta)]:
                got=f[tag+key][:,i];err=np.max(abs(got-target));ref=np.max(abs(got))
                rows.append(dict(tag=tag,var=key,eta=data.eta[i],native_max=ref,theory=target,max_abs=err,relative=err/ref if ref else None))
    table('scalar-clock-'+model+'.csv',rows)
