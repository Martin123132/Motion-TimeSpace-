from regular_io import *
from early_source import read_data, Fast
from drivers import Project
import angular
from multipoles import calc

def run(model):
    data=read_data(model); p=data.first
    with np.load(HOME/f'polar-{model}.npz') as src:
        assert np.array_equal(src['eta'],data.eta)
        raw=dict(zip(src['keys'],src['values']))
    p.update(M1=data.nodes[:,None]*p['Vg'],M2=raw['pig'],M3=raw['octg'],E3=raw['E(3)'],P=raw['polter'],E2=raw['E(2)'],
             CI1=raw['polter']-raw['pig'],CE1=raw['polter']-raw['E(2)'],rate=p['Db']+3*p['phi']+p['psi'])
    p.update(I1=p['M1'],I2=p['M2'],I3=p['M3'])
    for sp in ('I','E'):
        for degree in range(4,8):
            p[sp+str(degree)]=degree/(2*degree+1)*data.nodes[:,None]/data.background['opacity']*p[sp+str(degree-1)]
    machine=Project(data);rows=[];result=[]
    with np.load(HOME/f'forcing-{model}.npz') as src:prior=dict(zip(src['keys'],src['values']))
    for index,mode in enumerate(machine.ops):
        guard();op=Fast(mode,data);op.parts={'G':[[p['G'][0]]]}
        bank=angular.make(op,8); tail=calc(op,6)
        for spec in ('I','E'):
            for degree in range(3,7):
                pre=spec+str(degree)+':';bank[pre+'net']=tail[pre+'gravity']+data.background['opacity']*sum(tail[pre+tag] for tag in ('rate','loss','gain'))
        for key,want in [('L0','ph_energy'),('L1','ph_momentum')]:
            ref=prior[want][:,index];rows.append(dict(probe=str(PROBES[index]),key=key,relative=np.linalg.norm(bank[key]-ref)/np.linalg.norm(ref)))
        result.append(bank)
    pack(f'radiation-{model}.npz',keys=list(bank),eta=data.eta,values=np.array([list(b.values()) for b in result]).transpose(1,2,0))
    table(f'radiation-check-{model}.csv',rows)
if __name__=='__main__':
    for model in sys.argv[1:] or ['cold','heavy']:run(model)
