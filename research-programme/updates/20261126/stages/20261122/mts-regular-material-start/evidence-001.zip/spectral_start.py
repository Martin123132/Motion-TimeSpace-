from regular_io import *
from types import SimpleNamespace
from incident import Incident
from drivers import Project
from scipy.special import factorial2,eval_legendre,roots_laguerre,expit
from scipy.integrate import solve_ivp

def fetch(model):
    with np.load(HOME/f'incident-input-{model}.npz') as f:
        t=f['eta'];kn=f['k'];ref=f['reference'];d={key:f[key] for key in ('phi','psi','pd')}
    with np.load(HOME/f'forcing-{model}.npz') as f:bg=dict(zip(f['bgkeys'],f['background']))
    data=SimpleNamespace(model=model,nodes=kn,shell=np.array(json.loads(pin('legs.json').read_bytes())['squared_radii']),eta=t,first=d,background=bg)
    inc=object.__new__(Incident);inc.data=data;inc.k=kn;inc.mass=0.
    state=np.zeros((2,27,len(kn)))
    for ell in range(27):state[0,ell]=ref[ell,:,0] if ell<3 else (kn*t[0])**ell*(ref[0,:,0]+d['psi'][:,0])/factorial2(2*ell+1)
    state[0,0]-=d['phi'][:,0]
    F=inc.flight(np.inf,state)[0]
    with np.load(HOME/f'collisionless-{model}.npz') as f:assert np.array_equal(F[:3],f['low'])
    return data,F

def square(op,F,limit,order,azimuth):
    normal,wt=np.polynomial.legendre.leggauss(order)
    mu=normal[None,:,None];nx=np.sqrt(1-mu**2)*np.cos((np.arange(azimuth)+.5)*np.pi/azimuth)
    source,k,p,angle,field,metric,phase=op
    size=source.pair_count
    def wave(sight,values):
        old=np.ones_like(sight);curr=sight
        brightness=values[0,:,None,None]*old-3j*values[1,:,None,None]*curr
        for ell in range(2,len(values)):
            old,curr=curr,((2*ell-1)*sight*curr-(ell-1)*old)/ell
            brightness+=(-1j)**ell*(2*ell+1)*values[ell,:,None,None]*curr
        return brightness
    profile=np.zeros(order,complex)
    for start in range(0,size,48):
        ind=np.arange(start,min(size,start+48));small=angle[ind+size,None,None];large=angle[ind,None,None]
        sight1=small*mu+np.sqrt(np.maximum(0,1-small**2))*nx
        sight2=large*mu-np.sqrt(np.maximum(0,1-large**2))*nx
        value=wave(sight1,F[:,metric[ind]])*wave(sight2,F[:,field[ind]])
        profile+=np.einsum('b,bm->m',2*phase[ind],value.mean(axis=2))
    return np.array([1j**ell*np.dot(wt*eval_legendre(ell,normal),profile)/2 for ell in range(limit+1)])

def run(model):
    data,F=fetch(model);proj=Project(data);t=data.eta[::4];limit=18
    with np.load(HOME/f'collisionless-{model}.npz') as f:source=f['source']
    added=proj.calculate(F,F,np.inf,maximum=limit,match_bulk=False)[0]
    change=added-source
    K=np.array([op[1] for op in proj.ops]);direct=np.array([[square(op,F[:,:,j],limit,36,28) for op in proj.ops] for j in [0,-1]])
    repeat=np.array([square(op,F[:,:,-1],limit,42,32) for op in proj.ops])
    pol=CubicSpline(np.log(t),change,axis=2);deg=np.arange(limit+1)
    ini=-direct[0]/2
    def rate(u,st):
        st=st.reshape(5,-1);drift=0*st
        drift[:,1:]+=K[:,None]*deg[1:]*st[:,:-1]/(2*deg[1:]+1)
        drift[:,:-1]-=K[:,None]*(deg[:-1]+1)*st[:,1:]/(2*deg[:-1]+1)
        return (np.exp(u)*(drift+pol(u))).ravel()
    sol=solve_ivp(rate,np.log(t[[0,-1]]),ini.ravel(),method='DOP853',rtol=2e-11,atol=1e-30)
    assert sol.success
    endpoint=sol.y[:,-1].reshape(5,-1);shape=-direct[-1]/2
    with np.load(HOME/f'restart-radau-T1-{model}-1-18-0-6.npz') as f:
        states=f['values'];keys=f['keys'].tolist();bright=states[[keys.index('N'+str(l)) for l in deg]].copy()
        bright[0]+=states[keys.index('geom')]
    quadrature=[]
    for count in (12,24,32,48):
        nodes,weights=roots_laguerre(count);w=1-nodes*np.tanh(nodes/2)
        normalized=weights*nodes**4*expit(nodes)**2;normalized/=normalized.sum()
        spec=bright[None,:,:,:]+(w[:,None,None,None]+4)*shape.T[None,:,:,None]
        back=np.einsum('n,nlpc->lpc',normalized,spec)
        closure=np.max(np.linalg.norm(back-bright,axis=0)/np.linalg.norm(bright,axis=0))
        quadrature.append(dict(nodes=count,mean_w_plus_four=normalized@(w+4),relative_closure=closure,pass_1e_minus_8=bool(closure<1e-8)))
    table('spectral-quadrature-'+model+'.csv',quadrature)
    rows=[]
    for j,mode in enumerate(PROBES):
        allnorm=np.linalg.norm(shape[j])
        for lo,hi in [(0,3),(3,9),(0,19)]:
            sl=slice(lo,hi);norm=np.linalg.norm(shape[j,sl])
            rows.append(dict(mode=str(mode),ell_min=lo,ell_max=hi-1,direct_vs_transport=np.linalg.norm(shape[j,sl]-endpoint[j,sl])/norm,
                             angular_rule=np.linalg.norm(direct[-1,j,sl]-repeat[j,sl])/(2*norm),norm=norm,all_norm=allnorm))
    table('spectral-check-'+model+'.csv',rows)
    assert closure<1e-8
    assert max(r['angular_rule'] for r in rows)<1e-11 and max(r['direct_vs_transport'] for r in rows if r['ell_min']==0)<.005
    pack('spectral-restart-'+model+'.npz',eta=t[-1],k=K,coord=PROBES,shape=shape.T,brightness=bright,q=nodes,F=spec,closure=closure,transport=endpoint.T,linearIncident=F[:,:,-1],linearK=data.nodes)
    print(model,'spectral moment bands',max(r['direct_vs_transport'] for r in rows),'closure',closure,flush=True)
if __name__=='__main__':run(sys.argv[1])
