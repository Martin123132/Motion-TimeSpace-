from regular_io import *
from capture_early import driver,diag,Dummy,tempfile,subprocess
NAMES='tau k pig polter E(2) E(3) octg'.split()
def run(model,func):
    native=diag.native;status=native.obj(native.source(f'runs/{model}/status.json'))
    path=native.SPEC/'runs/projection/a225-w6-d8.npz' if model=='heavy' else native.NATIVE/'runs/backgrounds/cold.npz'
    native.checked(path,status['source_hash'])
    pars=native.engine.inherited.params_for(path,background_boost=8.);pars.DoLateRadTruncation=False
    bg=native.engine.camb.get_background(pars);bg.Params.Accuracy.IntTolBoost=6
    with pin(f'capture-{model}.csv').open() as fp:blocks=list(csv.DictReader(fp))
    out=[]
    with patch.object(diag.symbolic,'compile_sympy_to_camb_source_func',return_value=func):
        for i,block in enumerate(blocks):
            guard()
            with np.load(HOME/f'linear-{model}-{i:02}.npz') as f:k=f['k'];t=f['eta']
            batch=np.unique(np.r_[k,float(block['control']),float(block['hierarchy_cap'])])
            cur=bg.get_time_evolution(batch,t,vars=[Dummy(key) for key in NAMES],lAccuracyBoost=4)[np.searchsorted(batch,k)]
            assert np.allclose(cur[:,:,1],k[:,None],rtol=2e-13,atol=0) and np.isfinite(cur).all()
            out.append(cur[:,:,2:])
    pack(f'polar-{model}.npz',eta=t,keys=NAMES[2:],values=np.concatenate(out).transpose(2,0,1))
if __name__=='__main__':
    if sys.argv[1:2]==['--child']:
        with patch.object(driver,'HERE',HOME),patch.object(driver,'NAMES',NAMES),patch.object(driver,'run',run),patch.object(driver,'save',lambda n,raw:save('polar-'+n,raw)):driver.main()
    else:
        with tempfile.TemporaryDirectory(dir=HOME,prefix='reader-polar-') as tmp:subprocess.run([sys.executable,'-B',str(HOME/'early_polar.py'),'--child',tmp,*sys.argv[1:]],check=True)
