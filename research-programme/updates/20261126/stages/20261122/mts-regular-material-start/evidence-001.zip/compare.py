from regular_flow import Flight
from regular_io import *

def values(prefix,model,config):
    with np.load(HOME/f'flight-{prefix}{model}-{config}.npz') as f:
        assert np.array_equal(f['coord'],PROBES)
        return f['values']
def run(model):
    main=values('radau-T1-',model,'1-18-0-6')
    with np.load(HOME/f'flight-radau-T1-{model}-1-18-0-6.npz') as f:t=f['eta'];keys=f['keys'].tolist()
    with np.load(HOME/f'origin-v2-{model}.npz') as f:o=dict(f.items())
    ctrl=np.load(HOME/f'native-material-{model}.npz')
    with np.load(HOME/f'linear-output-{model}.npz') as f:
        assert np.array_equal(ctrl['k'],f['k']) and np.allclose(ctrl['phi'],f['phi'],rtol=2e-10,atol=1e-12) and np.allclose(ctrl['psi'],f['psi'],rtol=2e-10,atol=1e-12)
    threshold=.005;summary=[];detail=[]
    def compare(name,input1,input2,channels,grid):
        for bi,key in enumerate(channels):
            for j,coord in enumerate(PROBES):
                sig=input1[:,bi,j];ref=input2[:,bi,j];mask=np.isfinite(sig)&np.isfinite(ref)
                assert mask.any() and (abs(ref[mask])>0).all()
                res=abs(sig[mask]-ref[mask]);err=res/abs(ref[mask]);worst=np.argmax(err)
                summary.append(dict(test=name,field=key,mode=str(coord),first=grid[mask][0],last=grid[mask][-1],samples=len(err),maximum=float(err.max()),at=grid[mask][worst],endpoint=float(err[-1]),max_absolute=res.max(),relative_rms=np.linalg.norm(res)/np.linalg.norm(ref[mask]),pass_max=bool(err.max()<threshold)))
    kk=keys[:3];idx=[0,1,2];ref=main[:,:3,:,0]
    for ic in (1,2):compare('start '+str(ic),main[:,:3,:,2*ic],ref,kk,t)
    for tag,file,config in [('time Radau','radau-T1-','2-18-0-6'),('trace versus constraints','radau-T1-','1-18-1-6'),('thermal stress','radau-T0-','1-18-0-6'),('implicit scheme SDIRK','v2-','1-18-0-6')]:
        compare(tag,values(file,model,config)[:,:3,:,0],ref,kk,t)
    compare('angular truncation',values('v2-',model,'1-12-0-4')[:,:3,:,0],values('v2-',model,'1-18-0-6')[:,:3,:,0],kk,t)
    names=['phi','psi','nuDensity4','nuShear','baryonVelocity','photonMomentum','scalar'];expected=np.stack([ctrl[key][:,::16].T*o['pairs'] for key in names],axis=1)
    pos=[keys.index(key) for key in names];compare('primordial control',main[:,:,:,1][:,pos]-main[:,:,:,0][:,pos],expected,names,t)
    loworder=values('v2-',model,'1-18-0-6')
    compare('superseded SDIRK primordial control',loworder[:,:,:,1][:,pos]-loworder[:,:,:,0][:,pos],expected,names,t)
    old=values('',model,'1-18-0-6')
    for key in ['phi','psi','slip']:
        want=(o['psi']-o['phi'] if key=='slip' else o[key])[None,None,:]
        compare('origin v2 to constrained launch',main[0:1,keys.index(key):keys.index(key)+1,:,0],want,[key],t[:1])
    with np.load(HOME/f'origin-{model}.npz') as rejected:
        compare('rejected projection sign',old[0:1,1:2,:,0],rejected['psi'][None,None,:],['psi'],t[:1])
    assert len(summary)==5*len(set((row['test'],row['field']) for row in summary))
    table('checks-'+model+'.csv',summary)
    for it in [0,16,32,48,64,80]:
        x=main[it,:2,:,0];transfer=expected[it,:2,:]
        for j,mode in enumerate(PROBES):
            forced=x[:,j];reg=transfer[:,j];projection=np.vdot(reg,forced)/np.vdot(reg,reg)
            rem=forced-projection*reg
            assert abs(np.vdot(reg,rem))/(np.linalg.norm(reg)*np.linalg.norm(forced))<1e-13
            detail.append(dict(eta=t[it],mode=str(mode),phi_real=forced[0].real,phi_imag=forced[0].imag,
                       psi_real=forced[1].real,psi_imag=forced[1].imag,
                       best_residual_fraction=np.linalg.norm(rem)/np.linalg.norm(forced),free_control_norm_over_forced=np.linalg.norm(reg)/np.linalg.norm(forced)))
    table('gravity-'+model+'.csv',detail)
    flight=Flight(model,18,6,False,True)
    with np.load(HOME/f'restart-radau-T1-{model}-1-18-0-6.npz') as out:
        assert out['keys'].tolist()==flight.keys and np.array_equal(out['k'],flight.k[:,0]) and out['eta']==t[-1]
        y=out['values']/(flight.factors*t[-1]**flight.power[:,None,None]);obs=flight.jac_rhs(np.log(t[-1]),y,1.,True)
        assert np.all(abs(obs-main[-1])<2e-13*np.maximum(abs(obs),1e-80))
    valid=[r for r in summary if not r['test'].startswith(('rejected','superseded'))]
    assert all(r['pass_max'] for r in valid),[r for r in valid if not r['pass_max']]
    print(model,[(test,round(100*max(row['maximum'] for row in valid if row['test']==test),6),round(100*max(row['endpoint'] for row in valid if row['test']==test),6)) for test in dict.fromkeys(row['test'] for row in valid)],flush=True)
if __name__=='__main__':
    for model in ('cold','heavy'):run(model)
