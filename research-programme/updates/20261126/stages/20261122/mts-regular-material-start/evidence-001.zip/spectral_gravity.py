from regular_io import *
from scipy.special import roots_laguerre,expit
def run(model):
    with np.load(HOME/f'spectral-restart-{model}.npz') as f:shape=f['shape'];k=f['k'];assert f['eta']==6.4
    with np.load(HOME/f'forcing-{model}.npz') as f:bg=dict(zip(f['bgkeys'],f['background'][:,-1]))
    with np.load(HOME/f'flight-radau-T1-{model}-1-18-0-6.npz') as f:metric=f['values'][-1,:2,:,0]
    meta=json.loads(ti.parent.pin('radiation-background.json').read_bytes())[model]
    am=bg['a']*meta['mass_over_temperature'];base=meta['massless_limit_coeff']/(bg['a']**2*(7*np.pi**4/120))
    jac=3*(bg['ec']+bg['eb']+sum(bg[tag+'v']**2 for tag in ('sh' if model=='heavy' else 's')))+4*(bg['eg']+bg['er'])+3*bg['enm']
    banks=[];rows=[]
    for count in (32,48,64):
        q,weights=roots_laguerre(count);ep=np.hypot(q,am);w=1-q*np.tanh(q/2)
        measure=base*weights*q*expit(q)**2*(w+4)
        de=(measure@(q*q*am**2/(ep+q)))*shape[0];dj=0*de
        shear=(measure@(q**3*am**2/(ep*(ep+q))))*shape[2]
        dp=(-de/2+3*bg['h']*(-dj/(2*k*k)))/(k*k+jac/2)
        banks.append(np.array([dp,dp+shear/(k*k)]))
        for j,mode in enumerate(PROBES):rows.append(dict(mode=str(mode),nodes=count,relative_phi=abs(banks[-1][0,j]/metric[0,j]),relative_psi=abs(banks[-1][1,j]/metric[1,j]),relative_longitudinal_current=0.))
    assert np.max(abs((banks[1]-banks[2])/banks[2]))<1e-5
    table('spectral-stress-'+model+'.csv',rows)
if __name__=='__main__':
    for model in ('cold','heavy'):run(model)
