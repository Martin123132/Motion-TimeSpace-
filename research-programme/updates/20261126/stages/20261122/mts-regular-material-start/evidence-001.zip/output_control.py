from early_polar import driver,diag,Dummy,tempfile,subprocess
from regular_io import *
NAMES='tau k a adotoa etak sigma phi'.split()

def run(model,func):
    native=diag.native;status=native.obj(native.source(f'runs/{model}/status.json'))
    path=native.SPEC/'runs/projection/a225-w6-d8.npz' if model=='heavy' else native.NATIVE/'runs/backgrounds/cold.npz'
    native.checked(path,status['source_hash'])
    pars=native.engine.inherited.params_for(path,background_boost=8.);pars.DoLateRadTruncation=False
    bg=native.engine.camb.get_background(pars);bg.Params.Accuracy.IntTolBoost=6
    with np.load(HOME/f'forcing-{model}.npz') as src:k=src['k'];times=src['eta']
    with pin(f'capture-{model}.csv').open() as fp:block=list(csv.DictReader(fp))[-1]
    batch=np.unique(np.r_[k,float(block['control']),float(block['hierarchy_cap'])])
    with patch.object(diag.symbolic,'compile_sympy_to_camb_source_func',return_value=func):
        out=bg.get_time_evolution(batch,times,vars=[Dummy(key) for key in NAMES],lAccuracyBoost=4)[np.searchsorted(batch,k)]
    raw=dict(zip(NAMES,out.transpose(2,0,1)));assert np.allclose(raw['k'],k[:,None],rtol=1e-13,atol=0)
    phi=raw['etak']/k[:,None]-raw['adotoa']*raw['sigma']/k[:,None];psi=2*raw['phi']-phi
    pack(f'linear-output-{model}.npz',eta=times,k=k,phi=phi,psi=psi)
if __name__=='__main__':
    if sys.argv[1:2]==['--child']:
        with patch.object(driver,'HERE',HOME),patch.object(driver,'NAMES',NAMES),patch.object(driver,'run',run),patch.object(driver,'save',lambda n,data:save('control-'+n,data)):driver.main()
    else:
        with tempfile.TemporaryDirectory(dir=HOME,prefix='reader-control-') as tmp:subprocess.run([sys.executable,'-B',str(HOME/'output_control.py'),'--child',tmp,*sys.argv[1:]],check=True)
