from regular_io import *
from incident_tail import up

class Flight:
    def __init__(self,model,limit=18,phot=6,trace=False,thermal=False):
        self.model=model;self.limit=limit;self.phot=phot;self.trace=trace;self.thermal=thermal
        self.tags='sh' if model=='heavy' else 's'
        with np.load(HOME/f'forcing-{model}.npz') as src:
            self.t=src['eta'];self.log=np.log(self.t);self.k=src['k'][:,None];self.qkeys=list(src['keys']);self.bgkeys=list(src['bgkeys'])
            bg=src['background'].T
            if thermal:
                from scipy.special import roots_laguerre,expit
                nodes,weights=roots_laguerre(48)
                content=dict(zip(self.bgkeys,bg.T))
                meta=json.loads(ti.parent.pin('radiation-background.json').read_bytes())[model]
                scale=content['a'];am=scale*meta['mass_over_temperature'];ep=np.hypot(nodes,am[:,None])
                measure=weights*nodes*expit(nodes)**2
                base=meta['massless_limit_coeff']/(scale**2*(7*np.pi**4/120))
                e_therm=base*((ep*nodes**2)@measure)
                j_therm=base*(nodes**3@measure)
                s_therm=base*((nodes**4/ep)@measure)
                assert max(abs(e_therm/(3*content['enm'])-1))<1e-6
                bg=np.column_stack((bg,e_therm,j_therm,s_therm,base*((am[:,None]**2*nodes**2/ep)@measure)))
                self.bgkeys+=['nuE','nuJ','nuS','nuD']
            self.bg=CubicSpline(self.log,bg)
            q=src['values'].transpose(1,0,2)
        with np.load(HOME/f'radiation-{model}.npz') as src:
            assert np.array_equal(self.t,src['eta'])
            q=np.concatenate((q,src['values'].transpose(1,0,2)),axis=1);self.qkeys+=list(src['keys'])
        self.q=CubicSpline(self.log,q)
        with np.load(HOME/f'collisionless-{model}.npz') as src:self.drive=CubicSpline(np.log(src['eta']),src['source'].transpose(2,1,0))
        with np.load(HOME/f'origin-v2-{model}.npz') as src:self.orig={key:src[key] for key in src.files}
        self.keys=['geom','flux','cd','ct','bd','W','B','gx']+[tag+s for tag in self.tags for s in 'fw']+[s+str(i) for s in 'IE' for i in range(2,phot+1)]+['N'+str(i) for i in range(limit+1)]
        self.n=len(self.keys);self.ix={s:i for i,s in enumerate(self.keys)}
        self.probe=np.zeros((self.n,5,self.n+1));self.probe[:,:,:-1]=np.eye(self.n)[:,None,:]
        self.mask=np.zeros(self.n+1);self.mask[-1]=1
        self.power=np.zeros(self.n);self.factors=np.ones((self.n,5,1))
        for name in self.keys:
            degree=int(name[1:]) if name[0] in 'IEN' else 0
            index=self.ix[name];exponent=min(degree,2)
            self.factors[index]=self.k**exponent;self.power[index]=exponent
            if name in ('ct','W','B'):self.factors[index]=self.k**2;self.power[index]=1
            if name=='flux':self.power[index]=-1
    def env(self,u):
        return dict(zip(self.bgkeys,self.bg(u))),dict(zip(self.qkeys,self.q(u))),self.drive(u)
    def jac_rhs(self,u,state,mask,ob=False):
        t=np.exp(u);bg,src,drive=self.env(u);kk=self.k;k2=kk**2
        scale=self.factors*t**self.power[:,None,None]
        z=dict(zip(self.keys,state*scale));force={key:val[:,None]*mask for key,val in src.items()}
        v=lambda name:z[name]
        eb=bg['eb'];eg=bg['eg'];op=bg['opacity'];h=bg['h'];ratio=eb/eg
        bt=(v('W')-v('B'))/(ratio+4/3);gj=v('B')+4*bt/3
        ne=4*bg['er']+bg.get('nuE',3*bg['enm']);nj=4*bg['er']+bg.get('nuJ',3*bg['enm']);ns=4*bg['er']+bg.get('nuS',3*bg['enm'])
        drag=4/(3*ratio)
        energy=eg*v('gx')+force['gE']+ne*v('N0');J=eg*gj+force['gJ']+kk*nj*v('N1')+force['nuJ']
        shear=-eg*(v('I2')+force['ph_shift'])-ns*v('N2');jac=4*eg+ne
        trace0=np.zeros_like(energy)+bg.get('nuD',0.)*v('N0');trace1=bg.get('nuD',0.)
        for tag,vel in [('c',v('ct')),('b',bt)]:
            rest=bg['e'+tag]*v(tag+'d')+force[tag+'trace']
            energy+=rest+force[tag+'KE'];J+=bg['e'+tag]*vel+force[tag+'Jq'];shear+=force[tag+'shear']
            jac+=3*bg['e'+tag];trace0+=rest;trace1+=3*bg['e'+tag]
        for tag in self.tags:
            vel=bg[tag+'v'];pot=(bg['a']*bg[tag+'m'])**2*bg[tag+'b']*v(tag+'f');kin=vel*v(tag+'w')
            energy+=kin+pot+force[tag+'energy'];J+=k2*vel*v(tag+'f')+force[tag+'J'];shear+=force[tag+'shear']
            jac+=3*vel**2;trace0+=-2*kin+4*pot+force[tag+'trace'];trace1-=6*vel**2
        Fcon=-J/(2*k2);con=(force['U']-.5*energy+3*h*Fcon)/(k2+.5*jac)
        phi,F=(z['geom'],z['flux']) if self.trace else (con,Fcon)
        slip=(shear-force['Q'])/k2;psi=phi+slip;pd=-F-h*psi+force['Fq'];D=trace0+trace1*phi
        if ob:return np.stack([phi,psi,(phi+psi)/2,t*F,con,Fcon*t,z['N0']+phi,z['N2'],bt,gj,z[self.tags[-1]+'f'],slip])
        rhs={}
        rhs['geom']=pd;rhs['flux']=-3*h*F+(bg['hp']-h*h)*psi+k2*(phi-slip)/3+D/6+force['QR']-2*force['U']/3
        for tag in self.tags:
            m2=(bg['a']*bg[tag+'m'])**2
            rhs[tag+'f']=v(tag+'w')+bg[tag+'v']*(psi+3*phi)+force[tag+'field']
            rhs[tag+'w']=-2*h*v(tag+'w')-(k2+m2)*v(tag+'f')+m2*bg[tag+'b']*(3*phi-psi)+force[tag+'moment']
        rhs['cd']=-v('ct')+force['cnumber'];rhs['ct']=-h*v('ct')+k2*psi+force['cspeed']
        rhs['bd']=-bt+force['bnumber']
        bfree=-h*bt+k2*psi+force['bspeed']
        gfree=k2*(v('gx')/3+4*(psi+phi)/3-2*v('I2')/3)+force['ph_momentum']
        rhs['gx']=-gj+force['ph_energy']-op*force['collision_heat']
        rhs['W']=gfree+ratio*(bfree+h*bt)+op*(force['collision_b']-force['collision_ph'])
        rhs['B']=gfree-4*bfree/3-op*((1+drag)*v('B')+force['collision_ph']+drag*force['collision_b'])
        zero=np.zeros_like(gj)
        for sp in 'IE':
            for degree in range(2,self.phot+1):
                key=sp+str(degree);nxt=z.get(sp+str(degree+1),zero)
                lower=z.get(sp+str(degree-1),gj/kk if sp=='I' else zero)
                drift=kk*(degree*lower/(2*degree+1)-up(degree,2*(sp=='E'))*nxt)
                if degree==2:
                    source=force['L2' if sp=='I' else 'Le']+op*(.1*v('I2')+.6*v('E2')+force['C'+sp+'kin']+force['C'+sp+'rate'])
                else:source=force[key+':net']
                rhs[key]=drift-op*v(key)+source
        for degree in range(self.limit+1):
            lo=v('N0')+phi+psi if degree==1 else z.get('N'+str(degree-1),zero)
            hi=z.get('N'+str(degree+1),zero)
            rhs['N'+str(degree)]=kk*(degree*lo-(degree+1)*hi)/(2*degree+1)+drive[degree,:,None]*mask
        if not self.trace:rhs['geom']=0*pd;rhs['flux']=0*F
        result=t*np.stack([rhs[key] for key in self.keys])/scale-self.power[:,None,None]*state
        if not self.trace:result[:2]=0
        return result
    def launch(self,index,free):
        t=self.t[index];bg,force,_=self.env(self.log[index]);o=self.orig
        kk=self.k[:,0];p=o['P'];c=o['C'];pairs=o['pairs'];zeta=free*pairs
        phi=o['phi']+c*zeta;psi=o['psi']+p*zeta
        z=np.zeros((self.n,5),complex);setv=lambda key,val:z.__setitem__(self.ix[key],val)
        setv('geom',phi);setv('flux',(o['Fcoef']-p*zeta)/t)
        setv('cd',o['dust']+3*zeta);setv('bd',o['dust']+3*zeta)
        ct=t*(o['tc']+kk**2*p*zeta/2);setv('ct',ct)
        gj=t*(o['gj']+kk**2*2*p*zeta/3)
        bt=(gj+force['collision_b'])*.75
        setv('W',gj+bg['eb']/bg['eg']*bt);setv('B',gj-4*bt/3)
        setv('gx',o['gx']+4*zeta);setv('N0',o['N0']-.5*p*zeta-phi)
        setv('N1',t*(o['N1']+kk*p*zeta/6));setv('N2',t*t*(o['N2']+kk**2*p*zeta/30))
        setv('I2',-force['ph_bulk']-force['ph_shift'])
        theta=o['theta2']+(1+c)*zeta;B=o['B2']-c*zeta
        for tag in self.tags:
            vel=bg[tag+'v'];vn=bg[tag+'vN'];vnn=bg[tag+'vNN'];h=bg['h']
            setv(tag+'f',-vel/h*theta+.125*(vn/h-vel*bg['hp']/h**3)*p*p*pairs)
            setv(tag+'w',(vel-vn)*theta+.125*(vel-2*vn+vnn)*p*p*pairs+1.5*(vel-vn)*c*p*pairs+vel*(3*B+4.5*c*c*pairs))
        y=z/(self.factors[:,:,0]*t**self.power[:,None])
        obs=self.jac_rhs(self.log[index],y[:,:,None],np.ones(1),True)
        y[:2]=obs[4:6,:,0]
        return y
    def matrix(self,u):
        data=self.jac_rhs(u,self.probe,self.mask)
        assert abs(data[:,:,:-1].imag).max()==0
        return data[:,:,:-1].real.transpose(1,0,2),data[:,:,-1].T[:,:,None]
    def flight(self,starts,step,scheme='sdirk'):
        guard();n=self.n;eye=np.eye(n);gamma=1-1/np.sqrt(2)
        y=np.zeros((5,n,2*len(starts)),complex);outs=[];ind=[]
        for i in range(min(starts),len(self.t),step):
            if i%128==0:guard()
            for j,start in enumerate(starts):
                if i==start:
                    for free in (0,1):y[:,:,2*j+free]=self.launch(i,free).T
            if i%16==0:
                val=self.jac_rhs(self.log[i],y.transpose(1,0,2),1.,True)
                for j,start in enumerate(starts):
                    if i<start:val[:,:,2*j:2*j+2]=np.nan
                outs.append(val);ind.append(i)
            if i+step>=len(self.t):break
            dt=self.log[i+step]-self.log[i];w=gamma*dt
            if scheme=='radau':
                first,bfirst=self.matrix(self.log[i]+dt/3);last,blast=self.matrix(self.log[i+step])
                upper=np.concatenate((eye-5*dt*first/12,dt*last/12),axis=2)
                lower=np.concatenate((-3*dt*first/4,eye-dt*last/4),axis=2)
                right=np.concatenate((y+dt*(5*bfirst-blast)/12,y+dt*(3*bfirst+blast)/4),axis=1)
                y=np.linalg.solve(np.concatenate((upper,lower),axis=1),right)[:,n:]
                continue
            mat,b=self.matrix(self.log[i]+w)
            k1=np.linalg.solve(eye-w*mat,mat@y+b)
            mat,b=self.matrix(self.log[i+step]);base=y+(1-gamma)*dt*k1
            y=base+w*np.linalg.solve(eye-w*mat,mat@base+b)
        self.endpoint=y.transpose(1,0,2)*self.factors*self.t[-1]**self.power[:,None,None]
        self.endpoint[:2]=[outs[-1][0],outs[-1][3]/self.t[-1]]
        return np.array(ind),np.array(outs)
def main():
    model=sys.argv[1];step=int(sys.argv[2]);limit=int(sys.argv[3]);trace=bool(int(sys.argv[4]));phot=int(sys.argv[5])
    scheme=sys.argv[6] if len(sys.argv)>6 else 'sdirk';thermal=int(sys.argv[7]) if len(sys.argv)>7 else 0
    assert scheme in ('radau','sdirk')
    flight=Flight(model,limit,phot,trace,thermal);starts=[0,128,256];idx,res=flight.flight(starts,step,scheme)
    for j,start in enumerate(starts):assert np.isfinite(res[idx>=start,:,:,2*j:2*j+2]).all()
    prefix='flight-v2' if scheme=='sdirk' and not thermal else f'flight-{scheme}-T{thermal}'
    if scheme=='radau':
        pack(f'restart-{scheme}-T{thermal}-{model}-{step}-{limit}-{int(trace)}-{phot}.npz',eta=flight.t[-1],starts=flight.t[starts],coord=PROBES,k=flight.k[:,0],
             keys=flight.keys,values=flight.endpoint)
    pack(f'{prefix}-{model}-{step}-{limit}-{int(trace)}-{phot}.npz',eta=flight.t[idx],starts=flight.t[starts],coord=PROBES,
         keys=['phi','psi','weyl','etaF','constraintPhi','constraintEtaF','nuDensity4','nuShear','baryonVelocity','photonMomentum','scalar','slip'],values=res)
    print(model,step,limit,trace,phot,flush=True)
if __name__=='__main__':main()
