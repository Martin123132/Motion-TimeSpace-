from output_control import driver,diag,Dummy,tempfile,subprocess
from regular_io import *
NAMES='tau k adotoa etak sigma phi qg vb pir clxr qde'.split()
def run(model,func):
    native=diag.native;status=native.obj(native.source(f'runs/{model}/status.json'))
    path=native.SPEC/'runs/projection/a225-w6-d8.npz' if model=='heavy' else native.NATIVE/'runs/backgrounds/cold.npz'
    native.checked(path,status['source_hash'])
    pars=native.engine.inherited.params_for(path,background_boost=8.);pars.DoLateRadTruncation=False
    nativebg=native.engine.camb.get_background(pars);nativebg.Params.Accuracy.IntTolBoost=6
    with np.load(HOME/f'forcing-{model}.npz') as src:k=src['k'];times=src['eta'];bg=dict(zip(src['bgkeys'],src['background']))
    with pin(f'capture-{model}.csv').open() as fp:block=list(csv.DictReader(fp))[-1]
    batch=np.unique(np.r_[k,float(block['control']),float(block['hierarchy_cap'])]);tag='h' if model=='heavy' else 's'
    extra=['mts_dphi_'+tag]
    with patch.object(diag.symbolic,'compile_sympy_to_camb_source_func',return_value=func):
        out=nativebg.get_time_evolution(batch,times,vars=extra+[Dummy(key) for key in NAMES],lAccuracyBoost=4)[np.searchsorted(batch,k)]
    raw=dict(zip(extra+NAMES,out.transpose(2,0,1)));assert np.allclose(raw['k'],k[:,None],rtol=1e-13,atol=0)
    kk=k[:,None];alpha=raw['sigma']/kk;phi=raw['etak']/kk-bg['h']*alpha
    keys=dict(nuDensity4=raw['clxr']/4-bg['h']*alpha,nuShear=raw['pir']/4,baryonVelocity=kk*(raw['vb']+raw['sigma']),
              photonMomentum=kk*(raw['qg']+4*raw['sigma']/3),scalar=raw[extra[0]]+bg[tag+'v']*alpha,phi=phi,psi=2*raw['phi']-phi)
    pack(f'native-material-{model}.npz',eta=times,k=k,**keys)
if __name__=='__main__':
    if sys.argv[1:2]==['--child']:
        with patch.object(driver,'HERE',HOME),patch.object(driver,'NAMES',NAMES),patch.object(driver,'run',run),patch.object(driver,'save',lambda n,data:save('material-'+n,data)):driver.main()
    else:
        with tempfile.TemporaryDirectory(dir=HOME,prefix='reader-material-') as tmp:subprocess.run([sys.executable,'-B',str(HOME/'material_control.py'),'--child',tmp,*sys.argv[1:]],check=True)
