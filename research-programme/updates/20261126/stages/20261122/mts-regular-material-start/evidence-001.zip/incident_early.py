from regular_io import *
from types import SimpleNamespace
from incident import Incident
from drivers import Project
from scipy.special import factorial2

def run(model):
    with np.load(HOME/f'incident-input-{model}.npz') as f:
        t=f['eta'];k=f['k'];ref=f['reference'];phi=f['phi'];psi=f['psi'];pd=f['pd']
    with np.load(HOME/f'forcing-{model}.npz') as f:bg=dict(zip(f['bgkeys'],f['background']))
    data=SimpleNamespace(model=model,nodes=k,shell=np.array(json.loads(pin('legs.json').read_bytes())['squared_radii']),eta=t,
                         first=dict(phi=phi,psi=psi,pd=pd),background=bg)
    inc=object.__new__(Incident);inc.data=data;inc.k=k;inc.mass=0.
    st=np.zeros((2,27,len(k)))
    for degree in range(27):
        st[0,degree]=ref[degree,:,0] if degree<3 else (k*t[0])**degree*(ref[0,:,0]+psi[:,0])/factorial2(2*degree+1)
    st[0,0]-=phi[:,0]
    sol=inc.flight(np.inf,st)[0]
    machine=Project(data);drive,_=machine.calculate(sol,sol*0,np.inf,maximum=18,match_bulk=False)
    pack(f'collisionless-{model}.npz',eta=t[::4],source=drive,low=sol[:3])
    rows=[]
    for a,b in ((0,129),(129,225),(225,321)):
        for degree in range(3):
            target=ref[degree,:,4*a:4*b:4];got=sol[degree,:,a:b]
            rows.append(dict(ell=degree,first_eta=t[4*a],last_eta=t[4*(b-1)],relative=np.linalg.norm(got-target)/np.linalg.norm(target)))
    table('incident-replay-'+model+'.csv',rows)
if __name__=='__main__':run(sys.argv[1])
