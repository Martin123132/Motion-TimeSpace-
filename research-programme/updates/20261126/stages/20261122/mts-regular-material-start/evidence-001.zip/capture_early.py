from regular_io import *
import prehistory as old
from prehistory import driver,diag,Dummy,tempfile,subprocess
NAMES='tau k a adotoa etak sigma phi grho gpres dgq dgrho grhoc_t grhob_t grhog_t grhor_t grhonu_t grhov_t w_lam qde vb qg qr pig pir opacity clxc clxb clxg clxr clxnu delta_p_b'.split()
def run(model,func):
    native=diag.native;status=native.obj(native.source(f'runs/{model}/status.json'))
    path=native.SPEC/'runs/projection/a225-w6-d8.npz' if model=='heavy' else native.NATIVE/'runs/backgrounds/cold.npz'
    native.checked(path,status['source_hash'])
    for file in native.engine.inherited.native_hashes():native.checked(file,status['input_hashes'][str(file)])
    pars=native.engine.inherited.params_for(path,background_boost=8.);pars.DoLateRadTruncation=False
    assert str(pars.scalar_initial_condition)=='initial_adiabatic'
    bg=native.engine.camb.get_background(pars);bg.Params.Accuracy.IntTolBoost=6
    with np.load(pin(f'native-{model}.npz')) as f:kn=f['k']
    t=.00625*2**(np.arange(1281)/128)
    with pin(f'capture-{model}.csv').open() as fp:blocks=list(csv.DictReader(fp))
    labels='sh' if model=='heavy' else 's'
    extra=[p+tag for tag in labels for p in ('mts_dphi_','mts_dphidot_')]
    rows=[]
    with patch.object(diag.symbolic,'compile_sympy_to_camb_source_func',return_value=func):
        for ix,block in enumerate(blocks):
            guard();start,end=int(block['first']),int(block['last'])+1;sel=kn[start:end]
            ks=np.unique(np.r_[sel,float(block['control']),float(block['hierarchy_cap'])])
            out=bg.get_time_evolution(ks,t,vars=extra+[Dummy(key) for key in NAMES],lAccuracyBoost=4)[np.searchsorted(ks,sel)]
            raw=dict(zip(extra+NAMES,out.transpose(2,0,1)))
            good=np.isclose(raw['k'],sel[:,None],rtol=1e-13,atol=0)
            assert np.all(np.diff(good.astype(int),axis=1)>=0) and good[:,256:].all() and np.isfinite(out).all()
            rows.append(dict(block=ix,first=start,last=end-1,latest_live=float(t[np.argmax(good,axis=1).max()])))
            pack(f'linear-{model}-{ix:02}.npz',k=sel,begin=start,eta=t,good=good,keys=extra+NAMES,values=out)
            if ix==0:
                scale=raw['a'][-1]
                with np.load(path) as src:
                    fields={}
                    for tag in labels:
                        label='heavy' if tag=='h' else 'slow'
                        grid=src['heavy_efold' if tag=='h' else 'efold']
                        x=np.log(np.maximum(scale,np.exp(grid[0])))
                        for var in ('phi','phidot'):
                            spline=CubicSpline(grid,src[var+'_'+tag]);fields[tag+var]=spline(x)
                            if var=='phidot':fields[tag+'vN']=spline(x,1);fields[tag+'vNN']=spline(x,2)
                        fields[tag+'mass']=src[label+'_mass_mpc']
                pack(f'background-{model}.npz',eta=t,**fields)
    table(f'capture-{model}.csv',rows)
if __name__=='__main__':
    if sys.argv[1:2]==['--child']:
        with patch.object(driver,'HERE',HOME),patch.object(driver,'NAMES',NAMES),patch.object(driver,'run',run),patch.object(driver,'save',save):driver.main()
    else:
        with tempfile.TemporaryDirectory(dir=HOME,prefix='reader-regular-') as tmp:subprocess.run([sys.executable,'-B',str(HOME/'capture_early.py'),'--child',tmp,*sys.argv[1:]],check=True)
