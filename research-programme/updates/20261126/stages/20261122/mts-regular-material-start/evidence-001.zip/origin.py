from regular_io import *
from early_source import Fast
from drivers import Project
from types import SimpleNamespace

def initial(model,free=0.,r_override=None):
    with np.load(HOME/f'forcing-{model}.npz') as f:
        bg=dict(zip(f['bgkeys'],f['background']));kleg=f['nodes'];K=f['k']
    rad=bg['eg'][0]+bg['er'][0]+bg['enu'][0]
    frac=(bg['er'][0]+bg['enu'][0])/rad if r_override is None else r_override
    P=-1/(1.5+.4*frac);C=(1+.4*frac)*P
    blank=np.ones((len(kleg),1));data=SimpleNamespace(nodes=kleg,shell=np.array(json.loads(pin('legs.json').read_bytes())['squared_radii']),
        model=model,eta=np.array([1.]),first=dict(phi=C*blank,psi=P*blank,pd=0*blank,one=blank,V=P*blank/2,X=4*blank,G=(P+C)*blank),background=dict(a=np.ones(1)))
    mapper=Project(data);first=np.zeros((4,len(kleg),1));first[0]=-P/2;first[1,:,0]=kleg*P/6
    drv=mapper.calculate(first,0*first,np.inf,maximum=2,match_bulk=False)[0]
    rows=[]
    for ix,oper in enumerate(mapper.ops):
        op=Fast(oper,data);k=K[ix];k2=k*k
        mix=lambda l,r:op.product(l,r)[0]
        pairs=mix('one','one');p2=mix('psi','psi');c2=mix('phi','phi')
        ql=1.5*(op.kp**2/k2-op.p2/3);qr=1.5*(op.kq**2/k2-op.q2/3)
        Q=-k2*(p2+c2)+2*(op.product('phi','phi',-ql,-qr)-op.product('phi','psi',-ql,-qr))[0]+(op.shear('phi','phi')-op.shear('psi','psi')-2*op.shear('phi','psi'))[0]
        zeta2=free*pairs
        constant=-zeta2-c2+p2/2
        dipole0=k*p2/3+drv[ix,1,0]
        quad0=k*dipole0/5+drv[ix,2,0]/2
        slip0=(4*(1-frac)*op.shear('V','V')[0]-12*frac*quad0-Q)/k2
        lapse=(constant+slip0)/(1.5+.4*frac);phi=constant-lapse/2
        density=-2*lapse+4*p2;nu0=density/4;nu1=dipole0+k*lapse/6;nu2=quad0+k*k*lapse/30
        gx=4*zeta2+8*pairs
        momentum=(-op.dg('G','X')/3-4*(op.dg('X','G')+op.dg('G','G'))/3)[0]+4*k2*(c2-p2)/3
        gj=k2*(gx/3+4*(lapse+phi)/3)+momentum
        tc=k2*(lapse-p2/2)/2
        gnormal=gj+3*op.dv('phi','V')[0]*4/3
        nnormal=4*k*nu1-4*op.dv('phi','V')[0]/3
        j=3*((1-frac)*gnormal+frac*nnormal)
        rows.append(dict(pairs=pairs,zeta2=zeta2,phi=phi,psi=lapse,N0=nu0,N1=nu1,N2=nu2,gx=gx,gj=gj,tc=tc,
               dust=3*zeta2+4.5*pairs,theta2=zeta2+phi+c2,B2=-phi-c2,Fcoef=-lapse+1.5*p2,
               bulk=4*(1-frac)*op.shear('V','V')[0],shearnu=-12*frac*nu2,Q=Q,momentum=j,
               momentum_required=2*k2*(lapse-1.5*p2),P=P,C=C,R=frac))
    return {key:np.array([row[key] for row in rows]) for key in rows[0]}
def checks(model):
    data=initial(model);alt=initial(model,1);K=np.linalg.norm(PROBES,axis=1)*ti.Mixed().big.fund
    rows=[]
    for label,res,scale in [('slip',K*K*(data['psi']-data['phi'])-(data['bulk']+data['shearnu']-data['Q']),K*K*data['psi']),
               ('momentum',data['momentum']-data['momentum_required'],data['momentum_required']),
               ('homogeneous lapse',alt['psi']-data['psi']-data['P']*data['pairs'],data['P']*data['pairs']),
               ('homogeneous curvature',alt['phi']-data['phi']-data['C']*data['pairs'],data['C']*data['pairs'])]:
        for i,axis in enumerate(PROBES):rows.append(dict(test=label,probe=str(axis),relative=abs(res[i]/scale[i])))
    table(f'origin-v2-check-{model}.csv',rows);pack('origin-v2-'+model+'.npz',**data)
    print(model,max(x['relative'] for x in rows),flush=True)
if __name__=='__main__':
    for model in ('cold','heavy'):checks(model)
