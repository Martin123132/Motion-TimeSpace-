from pathlib import Path
import sys,os,hashlib,json,io,csv
for key in ('OMP_NUM_THREADS','MKL_NUM_THREADS','BLIS_NUM_THREADS','OPENBLAS_NUM_THREADS','NUMEXPR_NUM_THREADS'):os.environ[key]='1'
sys.dont_write_bytecode=True
HOME=Path(__file__).resolve().parent
LAST=HOME.parent/'mts-species-constraint-gravity-20261122'
def sha(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
assert sha(LAST/'seal.json')=='70920d9b2c630c10b064f1ecdb45da0b86d0ceb7cf889bce05df9fbd2aa43697'
manifest=json.loads((LAST/'seal.json').read_bytes())['files']
for key in ('ledger_io.py','quadratic.py','species.py','weights.py'):
    assert sha(LAST/key)==manifest[key]
sys.path.insert(0,str(LAST))
from ledger_io import np,CubicSpline,patch,evolve,PROBES,pin,verified,guard as parent_guard
from nu_io import ti
def guard():
    parent_guard();assert __debug__ and not (HOME/'STOP-REQUESTED').exists()
def save(name,raw):
    guard();p=HOME/name
    if p.exists():assert sha(p)==hashlib.sha256(raw).hexdigest(),name
    else:
        with p.open('xb') as f:f.write(raw)
def pack(name,**fields):
    out=io.BytesIO();np.savez_compressed(out,**fields);save(name,out.getvalue())
def table(name,rows):
    out=io.StringIO();wr=csv.DictWriter(out,rows[0],lineterminator='\n');wr.writeheader();wr.writerows(rows);save(name,out.getvalue().encode())
