from regular_io import *
from types import SimpleNamespace
from scipy.sparse import csr_matrix
from scipy.interpolate import make_interp_spline
from drivers import Project
from nu_io import Mixed
sources=ti.sources

class Fast(sources.Pair):
    def __init__(self,operator,data):
        op,self.kn,p,h,self.field,self.metric,self.phase=operator
        for key in ('q2','p2','kq','kp','dot','k2','pair_count'):
            setattr(self,key,getattr(op,key))
        self.data=data;self.n=len(data.nodes)
    def product(self,one,two,ls=1.,sl=1.):
        a=self.data.first[one];b=self.data.first[two]
        weights=np.r_[np.broadcast_to(ls,self.q2.shape),np.broadcast_to(sl,self.q2.shape)]
        mat=csr_matrix((self.phase*weights,(self.field,self.metric)),shape=(self.n,self.n))
        return np.einsum('it,it->t',mat@a,b)

def read_raw(model):
    paths=sorted(HOME.glob(f'linear-{model}-??.npz'))
    with pin(f'capture-{model}.csv').open() as f:assert len(paths)==len(list(csv.DictReader(f)))
    with np.load(paths[0]) as f:names=f['keys'].tolist();t=f['eta']
    with np.load(pin(f'native-{model}.npz')) as f:k=f['k']
    raw={name:np.zeros((len(k),len(t))) for name in names if name not in ('tau','k')}
    for path in paths:
        with np.load(path) as f:
            assert f['good'].all();start=int(f['begin']);idx=slice(start,start+len(f['k']))
            assert np.array_equal(k[idx],f['k']) and np.array_equal(t,f['eta'])
            for key,arr in zip(names,f['values'].transpose(2,0,1)):
                if key in raw:raw[key][idx]=arr
    return t,k,raw

def read_data(model):
    t,k,r=read_raw(model);kk=k[:,None];s=r['sigma'];h=r['adotoa'];eg=r['grhog_t'];er=r['grhor_t'];a=r['a'];e=r['grho'];p=r['gpres'];en=e+p
    alpha=s/kk;phi=r['etak']/kk-h*alpha;psi=2*r['phi']-phi
    F=-(r['dgq']+en*s)/(2*kk);pd=-F-h*psi
    Fp=(make_interp_spline(np.log(t),F*t,k=5,axis=1).derivative()(np.log(t))-F*t)/t**2
    density=r['dgrho']-3*h*en*alpha;pressure=-2*(Fp+2*h*F+en*psi/2-kk**2*(phi-psi)/3)
    trace=(density-3*pressure)/eg
    enh=r['grhonu_t']+p-(eg+er)/3-r['w_lam']*r['grhov_t']
    vm=(r['dgq']-r['grhob_t']*r['vb']-eg*r['qg']-er*r['qr']-r['grhov_t']*r['qde'])/enh+s
    back=dict(a=a[0],h=h[0],et=e[0],pt=p[0],ec=r['grhoc_t'][0],eb=r['grhob_t'][0],eg=eg[0],er=er[0],enu=r['grhonu_t'][0],enm=enh[0],opacity=r['opacity'][0],hp=-(e[0]+3*p[0])/6,T0=((e-3*p)/eg)[0],X0=(e/eg)[0])
    one=dict(phi=phi,psi=psi,F=F,Fp=Fp,pd=pd,G=phi+psi,E=density/eg,trace=trace,X=density/eg-4*e/eg*phi,T=trace-4*(e-3*p)/eg*phi,
             Vtot=(r['dgq']+en*s)/(kk*eg),S=kk**2*(psi-phi)/eg,
             Dcdm=r['clxc']-3*h*alpha-3*phi,Db=r['clxb']-3*h*alpha-3*phi,Vcdm=s/kk,Vb=(r['vb']+s)/kk,
             Dg=r['clxg']-4*h*alpha,Xg=r['clxg']-4*h*alpha-4*phi,Vg=(r['qg']+4*s/3)/kk,Sg=-r['pig'],
             Vr=(.75*r['qr']+s)/kk,Vm=vm/kk)
    scalars={}
    with np.load(HOME/f'background-{model}.npz') as f:
        for tag,label in [('s','slow')]+([('h','heavy')] if model=='heavy' else []):
            bb=f[tag+'phi'];v=f[tag+'phidot'];mass=float(f[tag+'mass'])
            scalars[label]=(bb,v,mass);back.update({tag+'b':bb,tag+'v':v,tag+'m':0*bb+mass,tag+'vN':f[tag+'vN'],tag+'vNN':f[tag+'vNN']})
            norm=r['mts_dphidot_'+tag]+(-3*h*v-(a*mass)**2*bb)*alpha
            one.update({tag+'f':r['mts_dphi_'+tag]+v*alpha,tag+'n':norm,tag+'u':norm-3*v*phi})
    shell=np.array(json.loads(pin('legs.json').read_bytes())['squared_radii'])
    return SimpleNamespace(eta=t,nodes=k,shell=shell,first=one,background=back,scalars=scalars,raw=r,model=model)

def run(model):
    data=read_data(model);bg=data.background;g=data.first;t=data.eta;nodes=data.nodes
    mapper=Project(data);modes=Mixed();allout=[]
    for i,coord in enumerate(PROBES):
        guard();op=Fast(mapper.ops[i],data)
        with patch.object(sources,'Pair',lambda *args:op):
            vals,_=sources.make(modes,np.array(coord),data,model)
        for tag,d,vel in (('c','Dcdm','Vcdm'),('b','Db','Vb')):
            vals[tag+'KE']=bg['e'+tag]*op.grad(vel,vel)
            vals[tag+'Jq']=bg['e'+tag]*(op.dv(d,vel)+3*op.dv('phi',vel))
        vals['gE']=4*bg['eg']*(op.product('phi','Dg')-op.product('phi','phi'));vals['gJ']=3*bg['eg']*op.dv('phi','Vg')
        vals['nuJ']=-4*bg['er']*op.dv('phi','Vr')/3-bg['enm']*op.dv('phi','Vm')
        vals['phiSq']=op.product('phi','phi');vals['psiSq']=op.product('psi','psi')
        allout.append(vals)
    pack(f'forcing-{model}.npz',eta=t,nodes=nodes,k=np.array([o[1] for o in mapper.ops]),coord=PROBES,keys=list(allout[0]),values=np.array([list(x.values()) for x in allout]).transpose(1,2,0),
         bgkeys=list(bg),background=np.array(list(bg.values())))
    r=data.raw;kk=nodes[:,None];sig=r['sigma']
    refs=np.array([r['clxr']/4-r['adotoa']*sig/kk,r['qr']/4+sig/3,r['pir']/4])
    meta=json.loads(ti.parent.pin('radiation-background.json').read_bytes())[model]
    pack(f'incident-input-{model}.npz',eta=t,k=nodes,phi=g['phi'],psi=g['psi'],pd=g['pd'],reference=refs)
    checks=[]
    for j in (0,128,256,384,512,768,1024,1280):
        ratio=lambda z,w:np.linalg.norm(z[:,j]-w[:,j])/max(np.linalg.norm(w[:,j]),1e-200)
        checks.append(dict(eta=t[j],max_k_eta=nodes[-1]*t[j],max_k_per_opacity=nodes[-1]/bg['opacity'][j],
                mass_over_temperature=meta['mass_over_temperature']*bg['a'][j],massive_enthalpy_ratio_error=abs(bg['enm'][j]/(4*bg['enu'][j]/3)-1),
                native_neutrino_density_difference=ratio(r['clxnu']/4-r['adotoa']*sig/kk,refs[0]),
                native_neutrino_velocity_difference=ratio(g['Vm'],g['Vr']),native_photon_baryon_velocity_difference=ratio(.75*g['Vg'],g['Vb']),
                native_scalar_density_fraction=sum(.5*(v[j]**2+(bg['a'][j]*m*b[j])**2) for b,v,m in data.scalars.values())/bg['et'][j]))
    table('regime-'+model+'.csv',checks)
if __name__=='__main__':run(sys.argv[1])
