from common_slip import *

def read(name):
    with (HERE/name).open(encoding="utf-8",newline="") as stream:return list(csv.DictReader(stream))
def obj(name):
    return json.loads((HERE/name).read_bytes())
def largest(name,col,expected):
    rows=read(name)
    assert len(rows)==expected,(name,len(rows),expected)
    return max(float(row[col]) for row in rows)
def run():
    guard()
    highest={}
    for model in ("cold","heavy"):
        check=read(f"native-duplicate-{model}.csv")
        assert len(check)==70
        highest[model+"_native_duplicate"]=max(float(row["relative"]) for row in check)
        assert highest[model+"_native_duplicate"]<2e-5
        assert largest(f"native-replay-{model}.csv","relative",6)<2e-5
    assert largest("linear-constraint.csv","rms_relative",56)<2e-5
    assert largest("geometry-mode-pairs.csv","relative",16)<2e-5
    assert largest("spacetime-check.csv","relative",18)<2e-5
    assert max(float(row["relative"]) for row in read("spatial-refinement.csv"))<2e-5
    assert largest("fine-angular-replay.csv","relative",5)<2e-5 and obj("cold-kinetic-null.json")["zero_stress"]==0.
    bound=obj("kernel-bound.json")
    assert 0<bound["operator_bound"]<1 and all(float(row["max_row_l1"])<=bound["operator_bound"] for row in read("dual-gain.csv"))
    assert max(bound["thermal_rho_vs_native"],bound["thermal_p_vs_native"])<2e-5
    assert max(obj("final-kernel-resolution.json").values())<2e-5
    refined=read("refined-same-time.csv")
    assert len(refined)==12
    for row in refined:
        if row["case"]=="128":assert max(float(row[key]) for key in row if key.startswith("rms_"))<2e-5
        if row["case"]=="bulk_and_density":
            assert float(row["rms_source_Mpc_minus2"])>.005
            assert 2e-5<float(row["rms_slip"])<.005 and 2e-5<float(row["rms_matter_minus_Weyl_gradient_Mpc_minus1"])<.005
    pressure=read("canonical-replay-trace.csv")
    assert len(pressure)==8 and max(float(row["virial_relative"]) for row in pressure if row["state"]=="replay")<2e-5
    assert largest("canonical-replay-accuracy.csv","step_difference",4)<2e-5
    with np.load(HERE/"switch-heavy.npz") as snapshot,np.load(HERE/"driver-000.npz") as initial:
        rel=np.linalg.norm(snapshot["wave_density_gradient"]-initial["source"][0])/np.linalg.norm(initial["source"][0])
        assert rel<2e-5
    dates=[]
    for start in range(0,129,16):
        with np.load(HERE/f"driver-{start:03}.npz") as data:
            assert np.isfinite(data["source"]).all() and np.all(data["source"][:,0]==0)
            dates.extend(data["indices"])
    assert np.array_equal(dates,np.arange(129))
    assert all(sha(Path(path))==value for path,value in obj("readout-provenance.json")["native_routines"].items())
    assert not list(HERE.glob("readout-build-*")) and not (HERE/"native-readout").exists()
    names={name+".py" for name in "angular canonical_replay common_slip constraint continuation defect diagnostics gradient pairs pressure_bridge resolution streaming stress_choice tensor_control verify virial".split()}
    names|={name+".md" for name in "CONTINUATION-DESIGN DERIVATION DESIGN NEXT-EVOLUTION PRESSURE RESULTS VIRIAL-TEST".split()}
    names|={name+".csv" for name in ("averaged-pressure-replay canonical-pressure canonical-replay-accuracy canonical-replay-trace dual-gain fine-angular-replay free-field-stress-control geometry-mode-pairs hydrodynamic-stress-counterfactual independent-transport linear-constraint matching-impact native-duplicate-cold native-duplicate-heavy native-replay-cold native-replay-heavy off-shell-budget pressure-defect-test pressure-filter-sensitivity radiation-norms refined-same-time same-time-stress source-norms spacetime-check spatial-refinement tag-projection virial-contributions virial-pressure-check volterra-refinement").split()}
    names|={name+".json" for name in "clock-check cold-kinetic-null final-kernel-resolution kernel-bound radiation-background readout-provenance".split()}
    names|={name+".npz" for name in "canonical-replay-state continued-stress fine-induced-stress kinetic-response native-moments-cold native-moments-heavy refined-canonical-stress switch-cold switch-heavy".split()}
    names|={f"driver-{idx:03}.npz" for idx in range(0,129,16)}|{"native-readout.f90"}
    actual={item.name for item in HERE.iterdir() if item.name!="seal.json"}
    assert actual==names,(actual-names,names-actual)
    record("seal.json",dict(files={name:sha(HERE/name) for name in sorted(names)},prior_seal=sha(PRE/"seal.json"),verified_native_replay=highest,
                scope="Common metric; classical scalar stress and conditional collisionless response. No halo occupation or observational fit."))
    assert all(sha(HERE/name)==value for name,value in obj("seal.json")["files"].items())
    print(len(names),sha(HERE/"seal.json"),highest)
if __name__=="__main__":run()
