from common_slip import *

class Moments:
    def __init__(self,model):
        self.model=model
        with np.load(HERE/f"native-moments-{model}.npz") as bank:
            self.k=bank["k"];self.at=bank["a"];self.times=bank["tau"];self.fine=bank["fine"]
            self.raw=dict(zip(bank["names"].tolist(),np.moveaxis(bank["custom"],2,0)))
            self.std=dict(zip(bank["standard"].tolist(),np.moveaxis(bank["base"],2,0)))
        with np.load(pinned(f"native-{model}.npz")) as bank:
            self.mass=float(bank["mass"]);self.coeff=bank["coeff"];self.dates=bank["dates"]
            self.slow=bank["slow_delta_N"]
            if model=="heavy":
                self.heavy_pre=bank["heavy_delta_N"][:,-1]
                self.speed=bank["heavy_background_speed"][-1]
        self.kk=self.k[:,None]
        raw=self.raw;hub=raw["adotoa"];sigma=raw["sigma"];total=raw["grho"]+raw["gpres"]
        self.phi=raw["etak"]/self.kk-hub*sigma/self.kk
        self.psi=2*raw["phi"]-self.phi
        hubprime=-(raw["grho"]+3*raw["gpres"])/6
        self.F1=-(raw["etakdot"]-hubprime*sigma-hub*raw["sigmadot"])/self.kk-hub*self.psi
        self.energy=raw["dgrho"]-3*hub*total*sigma/self.kk
        self.current=raw["dgq"]+total*sigma
        self.nu_h=raw["grhonu_t"]+raw["gpres"]-(raw["grhor_t"]+raw["grhog_t"])/3-raw["w_lam"]*raw["grhov_t"]
        assert self.nu_h.min()>0
        self.massive_flow=(raw["dgq"]-raw["grhob_t"]*raw["vb"]-raw["grhog_t"]*raw["qg"]-raw["grhor_t"]*raw["qr"]-raw["grhov_t"]*raw["qde"])/self.nu_h+sigma
    def linear(self):
        raw=self.raw;bank=[];wave=self.kk
        checks=(("momentum",self.F1,-self.current/(2*wave)),("Hamiltonian",wave**2*self.phi,-self.energy/2+3*raw["adotoa"]*self.F1),
            ("slip",wave**2*(self.psi-self.phi),-raw["dgpi"]),("matched_Weyl",raw["phi"],self.std["Weyl"]/wave**2))
        for key,left,right in checks:
            for idx in [0,len(self.fine)-1,*range(len(self.fine),len(self.at))]:
                a=left[:,idx];b=right[:,idx]
                bank.append(dict(model=self.model,epoch=self.at[idx],constraint=key,rms_relative=np.linalg.norm(a-b)/np.linalg.norm(b),
                    max_absolute=np.max(abs(a-b))))
        return bank
    def grad_amplitude(self,modes,idx):
        assert self.model=="heavy"
        rho=self.coeff[-1]/self.at[idx];alpha=self.raw["sigma"][:,idx]/self.k
        delta=self.std["mts_drho_h"][:,idx]/rho-3*self.raw["adotoa"][:,idx]*alpha
        return coefficient(modes,self.k,delta)*np.sqrt(rho)/(2*self.at[idx]*self.mass)
    def bulk_wave(self,modes,idx):
        rho=self.coeff[-1]/self.at[idx]
        moment=self.std["mts_q_h"][:,idx]/rho+self.raw["sigma"][:,idx]
        return coefficient(modes,self.k,self.k*moment)*np.sqrt(rho)/modes.k**2

def quadratic_geometry(modes,phi,psi,expansion,size):
    p=modes.split(phi);s=modes.split(psi);p0=modes.xy(p,size);s0=modes.xy(s,size)
    delta=phi-psi;dif=modes.split(delta)
    value=-modes.k2*modes.spec(cross(p0,p0)+cross(s0,s0))
    geo00=-modes.k2*modes.spec(cross(p0,p0))+2*modes.spec(cross(p0,modes.xy(p,size,-modes.k**2)))+1.5*modes.spec(cross(modes.xy(modes.split(expansion),size),modes.xy(modes.split(expansion),size)))
    for ix,axis in enumerate(modes.vec):
        dp=modes.xy(p,size,1j*axis);ds=modes.xy(s,size,1j*axis)
        geo00-=.5*modes.spec(cross(dp,dp))
        for jx in range(ix,3):
            axial=modes.vec[jx];dpj=dp if jx==ix else modes.xy(p,size,1j*axial);dsj=ds if jx==ix else modes.xy(s,size,1j*axial)
            proj=modes.outvec[ix]*modes.outvec[jx]/modes.safe-float(ix==jx)/3
            terms=2*cross(p0,modes.xy(dif,size,-axis*axial))+cross(dp,dpj)-cross(ds,dsj)-cross(dp,dsj)-cross(ds,dpj)
            value+=1.5*(1 if ix==jx else 2)*proj*modes.spec(terms)
    value[0]=0;geo00[0]=0
    return value,geo00

def channels(modes,bank,idx,size):
    at=bank.at[idx]; raw=bank.raw
    near=int(np.argmin(abs(bank.dates-at)))
    assert abs(bank.dates[near]/at-1)<2e-12
    mode=lambda arr:coefficient(modes,bank.k,arr)
    grad=lambda field:project_stress(modes,*modes.split(field),size)
    rho=lambda name:float(raw[name][0,idx])
    sigma=raw["sigma"][:,idx]
    part={}
    part["metric_Q"],part["metric_Hamiltonian_U"]=quadratic_geometry(modes,mode(bank.phi[:,idx]),mode(bank.psi[:,idx]),mode(bank.F1[:,idx]),size)
    for name,enthalpy,flow in (("cdm",rho("grhoc_t"),sigma),("baryon",rho("grhob_t"),sigma+raw["vb"][:,idx]),
             ("photon",4*rho("grhog_t")/3,sigma+.75*raw["qg"][:,idx]),("massless_nu",4*rho("grhor_t")/3,sigma+.75*raw["qr"][:,idx]),
             ("massive_nu",bank.nu_h[0,idx],bank.massive_flow[:,idx])):
        part[name+"_bulk"]=enthalpy*grad(mode(flow)/modes.k)
    part["slow_field"]=grad(mode(bank.slow[:,near]))
    if bank.model=="heavy":
        if idx==len(bank.fine):
            part["heavy_instantaneous"]=grad(mode(bank.heavy_pre))
        else:
            part["wave_density_gradient"]=grad(bank.grad_amplitude(modes,idx))
            part["wave_bulk"]=grad(bank.bulk_wave(modes,idx))
    part["known_slip_source"]=sum(value for name,value in part.items() if not name.startswith("metric_"))-part["metric_Q"]
    return part

def norms(modes,field):
    return dict(rms_source_Mpc_minus2=modes.norm(field),rms_slip=modes.norm(field/modes.safe),rms_matter_minus_Weyl_gradient_Mpc_minus1=.5*modes.norm(field/np.sqrt(modes.safe)))

def run():
    modes=Mixed();summaries=[];linear=[];replays=[];comparisons=[];frames=[]
    with np.load(pinned("transition-stress.npz")) as inputs:
        np.testing.assert_array_equal(modes.out,inputs["axes"])
        canonical=inputs["canonical_edge"];post=inputs["post"];bulk=inputs["bulk"]
    for model in ("cold","heavy"):
        stored=Moments(model);linear+=stored.linear()
        for idx in [len(stored.fine),0,*range(len(stored.fine)+1,len(stored.at))]:
            guard();part=channels(modes,stored,idx,modes.size)
            if idx==0:
                check=channels(modes,stored,idx,modes.size+8)
                for name,field in part.items():
                    rel=modes.norm(field-check[name])/max(modes.norm(field),1e-210)
                    assert rel<2e-5,(name,rel)
                    replays.append(dict(model=model,channel=name,relative=rel))
                if model=="heavy":
                    r=modes.norm(part["wave_density_gradient"]+part["wave_bulk"]-post)/modes.norm(post)
                    assert r<2e-5,r
                    part["edge_substituted_known_source"]=part["known_slip_source"]+canonical-post
                    part["canonical_edge"]=canonical;part["edge_minus_averaged"]=canonical-post
                    part["edge_minus_bulk_only"]=canonical-bulk
                    for key,other in (("averaged",post),("bulk_only",bulk)):
                        delta=norms(modes,canonical-other)
                        refs=norms(modes,canonical)
                        fractions={tag:delta[tag]/refs[tag] for tag in refs}
                        scene=norms(modes,part["edge_substituted_known_source"])
                        comparisons.append(dict(model=key,source_error=fractions["rms_source_Mpc_minus2"],slip_error=fractions["rms_slip"],
                           gradient_error=fractions["rms_matter_minus_Weyl_gradient_Mpc_minus1"],error_over_known_forcing=delta["rms_slip"]/scene["rms_slip"],native_replay=r))
                packet(f"switch-{model}.npz",axes=modes.out,**part)
            for name,field in part.items():
                metrics=norms(modes,field)
                summaries.append(dict(model=model,a=stored.at[idx],channel=name,**metrics))
                projected=modes.project(field/modes.safe)
                for rcut,value in zip(modes.cuts,projected):
                    frames.append(dict(model=model,a=stored.at[idx],channel=name,cut_kpc=rcut,
                        signed_percent_window_over_k2=value))
    table("linear-constraint.csv",linear);table("source-norms.csv",summaries);table("spatial-refinement.csv",replays)
    table("matching-impact.csv",comparisons);table("tag-projection.csv",frames)
if __name__=="__main__":run()
