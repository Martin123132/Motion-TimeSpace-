from streaming import *

def run():
    modes=Mixed();bank=Moments("heavy");source=driver();time=bank.times[bank.fine];at=bank.at[bank.fine]
    meta=json.loads((HERE/"radiation-background.json").read_bytes())["heavy"]
    wn=np.linspace(0,np.sqrt(modes.k2.max()),129)
    dual=response_rows(wn,time,at,meta,48,("both",))["both"]
    fine=project(modes,source,wn,dual)
    coarse=project(modes,source,wn[::2],dual[::2])
    vals=norms(modes,coarse-fine);norm=norms(modes,fine)
    record("final-kernel-resolution.json",{name:vals[name]/norm[name] for name in norm})
    packet("fine-induced-stress.npz",induced=fine)
    with np.load(HERE/"kinetic-response.npz") as data:
        assert modes.norm(coarse-data["thermal48"])/modes.norm(coarse)<1e-10
if __name__=="__main__":run()
