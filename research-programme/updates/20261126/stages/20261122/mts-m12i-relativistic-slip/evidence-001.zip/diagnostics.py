from common_slip import *
CHAIN=HERE.parent/"condensate-origin-20261003/native-two-field-transfer-20261007/toolchain/mingw64/bin"
assert (CHAIN/"gfortran.exe").is_file()
os.environ["PATH"]=str(CHAIN)+os.pathsep+os.environ["PATH"]
import native
from unittest.mock import patch
from sympy import Dummy
from camb import symbolic
from scipy.optimize import brentq
NAMES="tau a adotoa grho gpres w_lam grhob_t grhor_t grhoc_t grhog_t grhov_t grhonu_t k etak etakdot phi phidot sigma sigmadot dgrho dgq qg qr qde vb dgpi pig pir".split()
def run(model,func):
    guard()
    seed=native.Seed(model,"anchorA","heavy")
    file=native.SPEC/"runs/projection/a225-w6-d8.npz" if model=="heavy" else native.NATIVE/"runs/backgrounds/cold.npz"
    status=native.obj(native.source(f"runs/{model}/status.json"))
    native.checked(file,status["source_hash"])
    for path in native.engine.inherited.native_hashes():native.checked(path,status["input_hashes"][str(path)])
    params=native.engine.inherited.params_for(file,background_boost=8.)
    params.DoLateRadTruncation=False
    bg=native.engine.camb.get_background(params);bg.Params.Accuracy.IntTolBoost=6
    with np.load(pinned(f"native-{model}.npz")) as previous:
        epochs=previous["dates"];fluid=epochs[previous["fluid"]];idx=previous["fluid"][0];saved=previous["values"][:,idx];k=previous["k"]
    tau=lambda at:bg.conformal_time(1/at-1,tol=1e-10)
    fine=np.linspace(tau(fluid[0]),tau(fluid[4]),129)
    extra=np.array([tau(at) for at in (.00022495,.0003,.0005,.001,.003)])
    readtimes=np.r_[fine,extra]; use=np.argsort(readtimes)
    with np.load(native.old.parent(f"hierarchy-{model}.npz")) as past:
        alltime=np.unique(np.r_[readtimes,tau(np.unique(np.r_[epochs,past["epochs"]]))])
    standard=native.engine.camb.model.evolve_names
    dummies=[Dummy(name) for name in NAMES]
    blocks=[];keys=[]
    with patch.object(symbolic,"compile_sympy_to_camb_source_func",return_value=func):
        for savedfile in sorted((native.SPEC/"runs"/model).glob("chunk-*.npz")):
            with np.load(native.source(savedfile.relative_to(native.SPEC).as_posix())) as archive:
                batch=archive["modes"];pick=batch[np.isin(batch,k)]
            if not len(pick):continue
            guard()
            run_k=np.unique(np.r_[pick,batch.max()])
            values=bg.get_time_evolution(run_k,alltime,vars=standard+dummies,lAccuracyBoost=4)
            block=values[np.searchsorted(run_k,pick)][:,np.searchsorted(alltime,readtimes)]
            keys.extend(pick);blocks.extend(block)
    order=np.argsort(keys);full=np.array(blocks)[order];assert np.array_equal(np.array(keys)[order],k)
    base=full[:,:,:len(standard)];custom=full[:,:,len(standard):]
    get=lambda key:custom[:,:,NAMES.index(key)]
    assert np.isfinite(full).all()
    rel=lambda val,ref:float(np.linalg.norm(val-ref)/np.linalg.norm(ref))
    assert rel(get("tau"),np.broadcast_to(readtimes,get("tau").shape))<1e-11
    assert rel(get("k"),np.broadcast_to(k[:,None],get("k").shape))<1e-11
    replay=[]
    for name in ("Weyl","etak","delta_cdm","delta_baryon","pi_photon","mts_drho_h" if model=="heavy" else "mts_drho_s"):
        loc=standard.index(name);replay.append(dict(observable=name,relative=rel(base[:,0,loc],saved[:,loc])))
    assert max(row["relative"] for row in replay)<2e-5
    at=np.r_[[brentq(lambda a:tau(a)-time,fluid[0]*.999,fluid[4]*1.001,xtol=1e-18) for time in fine],.00022495,.0003,.0005,.001,.003]
    filename=f"native-moments-{model}.npz"
    if (HERE/filename).exists():
        comparison=[]
        with np.load(HERE/filename) as original:
            for tag,current in (("base",base),("custom",custom)):
                cols=standard if tag=="base" else NAMES
                for column,name in enumerate(cols):
                    left=current[:,:,column];right=original[tag][:,:,column]
                    err=np.linalg.norm(left-right)/max(np.linalg.norm(right),1e-100)
                    comparison.append(dict(group=tag,column=name,relative=err,max_abs=np.max(abs(left-right)),bitwise=bool(np.array_equal(left,right))))
            for item,arr in (("k",k),("a",at),("tau",readtimes),("fine",np.arange(len(fine))),("standard",standard),("names",NAMES)):
                np.testing.assert_array_equal(original[item],arr)
        assert max(row['relative'] for row in comparison)<2e-5
        if not (HERE/f"native-duplicate-{model}.csv").exists():table(f"native-duplicate-{model}.csv",comparison)
        print(model,"independent replay",max(row['relative'] for row in comparison),flush=True)
        return
    else:
        packet(filename,k=k,a=at,tau=readtimes,fine=np.arange(len(fine)),standard=standard,names=NAMES,base=base,custom=custom)
    table(f"native-replay-{model}.csv",replay)
    print(model,"saved",flush=True)
def main():
    import subprocess
    import tempfile
    if sys.argv[1:2]!=["--readout-child"]:
        with tempfile.TemporaryDirectory(dir=HERE,prefix="readout-build-") as directory:
            subprocess.run([sys.executable,"-B",str(HERE/"diagnostics.py"),"--readout-child",directory,*sys.argv[1:]],check=True)
        return
    folder=Path(sys.argv[2]).resolve()
    assert folder.parent==HERE and folder.name.startswith("readout-build-") and not any(folder.iterdir())
    body="\n".join(f"sources({idx}) = {name}" for idx,name in enumerate(NAMES,1))
    drive=next(letter+":" for letter in "VWXYZ" if not Path(letter+":/").exists())
    subprocess.run(["subst",drive,str(CHAIN.parent)],check=True)
    try:
        prefixes=("libexec/gcc/x86_64-w64-mingw32/14.2.0","lib","bin","lib/gcc/x86_64-w64-mingw32/14.2.0","x86_64-w64-mingw32/lib")
        flags=" ".join(f"-B{drive}/{suffix}/" for suffix in prefixes)+" "+" ".join(f"-L{drive}/{suffix}/" for suffix in prefixes[1:] if suffix!="bin")
        func=symbolic.compile_source_function_code(body,file_path=str(folder),compiler=drive+"/bin/gfortran.exe",fflags=flags+" -shared -O1",cache=True)
    finally:
        mappings=subprocess.check_output(["subst"],text=True).splitlines()
        assert any(row.upper().startswith(drive+"\\:") and Path(row.split("=>",1)[1].strip())==CHAIN.parent for row in mappings)
        subprocess.run(["subst",drive,"/D"],check=True)
    write("native-readout.f90",(folder/"camb_source1.f90").read_bytes())
    record("readout-provenance.json",dict(compiler=sha(CHAIN/"gfortran.exe"),native_routines={str(path):sha(path) for path in native.engine.inherited.native_hashes()}))
    for model in sys.argv[3:] or ("cold","heavy"):run(model,func)
if __name__=="__main__":main()
