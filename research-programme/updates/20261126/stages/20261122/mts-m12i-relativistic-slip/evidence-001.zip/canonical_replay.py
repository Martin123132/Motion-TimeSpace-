from pressure_bridge import *
import native
from scipy.integrate import solve_ivp,cumulative_simpson
from scipy.interpolate import CubicSpline

def block():
    with np.load(pinned("native-heavy.npz")) as src:
        raw=src["raw"];at=src["dates"][raw];mass=float(src["mass"]);k=src["k"];coef=src["coeff"][-1]
        aa=src["values"][0,raw,src["names"].tolist().index("a")];scale=aa**1.5*mass/np.sqrt(coef)
        z=src["heavy_background_phi"]*scale;v=src["heavy_background_speed"]*scale/(aa*mass)
        d=src["heavy_delta_N"]*scale;u=src["heavy_normal_N"]*scale/(aa*mass)
        phi=src["phi"][:,raw];psi=src["psi"][:,raw];hub=src["values"][0,raw,src["names"].tolist().index("H")]
    bg=native.engine.camb.get_background(native.engine.inherited.params_for(native.SPEC/"runs/projection/a225-w6-d8.npz",background_boost=8.))
    tau=bg.conformal_time(1/at-1,tol=1e-10)
    t=cumulative_simpson(mass*aa,x=tau,initial=0)
    return k,aa,mass,t,z,v,d,u,phi,psi,hub
def run():
    k,aa,mass,t,z,v,d,u,phi,psi,hub=block();size=len(k);modes=Mixed()
    he=hub/(mass*aa);spline=CubicSpline(t,np.stack([phi,psi]),axis=2)
    scale=CubicSpline(t,np.log(aa))
    start=np.r_[z[0],v[0],d[:,0],u[:,0]-3*v[0]*phi[:,0]]
    def evolve(clock,state):
        geom,lapse=spline(clock);growth=scale(clock,1);ratio=(k/(mass*np.exp(scale(clock))))**2
        field,speed=state[:2];density,velocity=state[2:2+size],state[2+size:]
        return np.r_[speed+1.5*growth*field,-field-1.5*growth*speed,
                     velocity+1.5*growth*density+speed*(lapse+3*geom),-(1+ratio)*density-1.5*growth*velocity+field*(3*geom-lapse)]
    results=[];species=[];answers={}
    for rate in (24,48):
        sol=solve_ivp(evolve,t[[0,-1]],start,t_eval=t,rtol=2e-12,atol=1e-14,method="DOP853",max_step=2*np.pi/rate)
        assert sol.success
        zz,vv=sol.y[:2];dd=sol.y[2:2+size];uu=sol.y[2+size:]+3*vv*phi
        answers[rate]=(zz,vv,dd,uu)
    packet("canonical-replay-state.npz",k=k,a=aa,proper_phase=t,z=zz,v=vv,d=dd,u=uu)
    norm0=lambda arr:np.linalg.norm(arr)
    for name,idx,archive in (("background_field",0,z),("background_speed",1,v),("delta_field",2,d),("normal_velocity",3,u)):
        fine=answers[48][idx];rough=answers[24][idx]
        species.append(dict(field=name,relative_archive=norm0(fine-archive)/norm0(archive),step_difference=norm0(fine-rough)/norm0(fine)))
    power=modes.big.weights[modes.big.inband]
    norm=lambda arr:np.sqrt(np.sum(power*abs(coefficient(modes,k,arr))**2))
    for centre,count in ((128,4),(128,8),(80,4),(176,4)):
        ix=np.arange(centre-count*16,centre+count*16+1);times=t[ix]
        base=simpson(np.eye(len(ix)),x=times,axis=0);beta=np.pi/(times[-1]-times[0]);arg=beta*(times-(times[-1]+times[0])/2)
        co,sn=np.cos(arg),np.sin(arg);base/=base@co**4
        w=base*co**4;dw=-4*beta*base*co**3*sn;d2=4*beta**2*base*(3*co**2*sn**2-co**4)
        mean=lambda arr,weights=w:arr[...,ix]@weights
        saved_pressure=mean(v*u-z*d)
        for label,(zz,vv,dd,uu) in (("saved",(z,v,d,u)),("replay",answers[48])):
            prod=zz*dd
            pred=(mean(prod,d2)+3*mean(he*prod,dw)+mean((k[:,None]/(aa*mass))**2*prod)+
                  mean(zz*vv*(psi+3*phi),dw)+mean((vv**2-zz**2)*(3*phi-psi)))/2
            target=mean(vv*uu-prod)
            den=mean(vv*uu+prod);rho=(zz**2+vv**2)/2;press=(vv**2-zz**2)/2
            flow=mean(vv*dd/(aa*mass))/mean(rho+press)
            dbar=lambda field:-aa[centre]*mass*mean(field,dw)-3*hub[centre]*mean(field)
            denscom=den-dbar(rho)*flow;com=target-dbar(press)*flow
            ratio=(k/(aa[centre]*mass))**2
            beat=ratio/(1+np.sqrt(1+ratio))**2*denscom
            results.append(dict(centre=centre,cycles=count,state=label,virial_relative=norm(pred-target)/norm(target),
                pressure_change_vs_saved=norm(target-saved_pressure)/norm(saved_pressure),flat_beat_relative=norm(com-beat)/norm(com)))
    table("canonical-replay-accuracy.csv",species);table("canonical-replay-trace.csv",results)
if __name__=="__main__":run()
