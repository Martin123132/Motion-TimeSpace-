import csv
import hashlib
import io
import json
import os
import sys
from pathlib import Path

for name in ("OPENBLAS_NUM_THREADS","MKL_NUM_THREADS","OMP_NUM_THREADS","NUMEXPR_NUM_THREADS","BLIS_NUM_THREADS"):
    os.environ[name]="1"
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
PRE=HERE.parent/"mts-m12i-transition-tidal-stress-20261122"
def sha(path):
    with path.open("rb") as stream:return hashlib.file_digest(stream,"sha256").hexdigest()
assert sha(PRE/"seal.json")=="d901ce4b7077b630775d003ddcc12e12a9afe07502cc089b8e4195859e3c28d3"
manifest=json.loads((PRE/"seal.json").read_bytes())["files"]
def pinned(name):
    path=PRE/name
    assert sha(path)==manifest[name],name
    return path
for name in ("geometry.py","tidal_stage.py","native.py"):pinned(name)
sys.path.insert(0,str(PRE))
from geometry import Mixed,transfer,cross,project_stress,np
from tidal_stage import guard as inherited_guard
def guard():
    inherited_guard()
    assert __debug__ and not any((path/"STOP-REQUESTED").exists() for path in (HERE,HERE.parent))
def write(name,payload):
    guard()
    path=HERE/name
    if path.exists():assert path.read_bytes()==payload,name
    else:
        with path.open("xb") as stream:stream.write(payload)
def packet(name,**fields):
    stream=io.BytesIO();np.savez_compressed(stream,**fields);write(name,stream.getvalue())
def record(name,obj):
    write(name,(json.dumps(obj,sort_keys=True,indent=2,allow_nan=False)+"\n").encode())
def table(name,data):
    out=io.StringIO();writer=csv.DictWriter(out,data[0],lineterminator="\n");writer.writeheader();writer.writerows(data);write(name,out.getvalue().encode())
def coefficient(modes,k,arr):
    return transfer(modes,k,arr)[modes.rad]*modes.R
