from common_slip import *
from scipy.integrate import simpson

def kernel(phase,centre,count,stride,power):
    high=centre+count*16;low=centre-count*16
    locations=np.arange(low,high+1,stride);phase0=phase[centre]
    half=count*np.pi
    angle=(phase[locations]-phase0)*np.pi/(2*half)
    taper=np.cos(angle)**power
    derivative=power*np.pi/(2*half)*np.cos(angle)**(power-1)*np.sin(angle)
    base=simpson(np.eye(len(angle)),x=phase[locations],axis=0)
    weights=base*taper;normal=weights.sum()
    prime=base*derivative/normal
    return locations,weights/normal,prime-prime.sum()*weights/normal

def run():
    modes=Mixed();records=[];converge=[];target={}
    with np.load(pinned("native-heavy.npz")) as bank:
        raw=bank["raw"];at=bank["dates"][raw];mass=float(bank["mass"]);coef=bank["coeff"][-1];k=bank["k"]
        phase=bank["carrier_phase"];scale=at**1.5*mass/np.sqrt(coef)
        field=bank["heavy_background_phi"]*scale;velocity=bank["heavy_background_speed"]*scale/(at*mass)
        d=bank["heavy_delta_N"]*scale;u=bank["heavy_normal_N"]*scale/(at*mass)
        hub=bank["values"][:,raw,bank["names"].tolist().index("H")][0]
    rho=.5*(field**2+velocity**2);press=.5*(velocity**2-field**2)
    energy=field*d+velocity*u;pressure=velocity*u-field*d;current=velocity*d/(at*mass)
    calc=lambda arr:coefficient(modes,k,arr)
    norm=lambda arr:np.sqrt(np.sum(modes.big.weights[modes.big.inband]*abs(arr)**2))
    centre=128
    for count in (2,4,6,8):
        for stride in (1,2):
            for power in (2,4):
                loc,weight,der=kernel(phase,centre,count,stride,power)
                moment=lambda arr:arr[...,loc]@weight
                change=lambda arr:arr[...,loc]@der
                rho0=moment(rho);p0=moment(press);speed=moment(current)/(rho0+p0)
                rho_prime=at[centre]*mass*change(rho)-3*hub[centre]*rho0
                p_prime=at[centre]*mass*change(press)-3*hub[centre]*p0
                den=moment(energy)-rho_prime*speed
                measured=moment(pressure)-p_prime*speed
                ratio=(k/(at[centre]*mass))**2
                beat=ratio/(1+np.sqrt(1+ratio))**2
                expected=beat*den
                fields=[calc(arr) for arr in (measured,expected,measured-expected)]
                target[count,stride,power]=fields
                records.append(dict(cycles=count,samples_per_cycle=32//stride,taper_power=power,a=at[centre],
                    pressure_rms=norm(fields[0]),beat_prediction_relative=norm(fields[2])/norm(fields[0]),
                    no_pressure_relative=1.,pressure_gauge_shift_over_signal=norm(calc(p_prime*speed))/norm(fields[0]),
                    density_gauge_shift_over_density=norm(calc(rho_prime*speed))/norm(calc(den)),background_w=p0/rho0,
                    continuity_fraction=abs(rho_prime+3*hub[centre]*(rho0+p0))/(3*hub[centre]*rho0)))
    ref=target[8,1,4]
    for key,vals in target.items():
        converge.append(dict(cycles=key[0],stride=key[1],taper_power=key[2],pressure_vs_widest=norm(vals[0]-ref[0])/norm(ref[0]),
             discrepancy_vs_widest=norm(vals[2]-ref[2])/norm(ref[0])))
    table("canonical-pressure.csv",records);table("pressure-filter-sensitivity.csv",converge)
    state=__import__("constraint").Moments("heavy")
    checks=[]
    for idx in (0,128,130,131,132,133):
        at=state.at[idx];ratio=(state.k/(at*state.mass))**2
        energy=state.std["mts_drho_h"][:,idx];momentum=state.std["mts_q_h"][:,idx]
        dens=energy+3*state.raw["adotoa"][:,idx]*momentum/state.k
        exact=ratio/(np.sqrt(1+ratio)+1)**2
        pressure=state.std["mts_dp_h"][:,idx]
        for law,c2 in (("beat",exact),("leading_Newtonian",ratio/4)):
            err=np.linalg.norm(pressure-c2*dens)/np.linalg.norm(pressure)
            checks.append(dict(a=at,law=law,native_pressure_relative=err))
    table("averaged-pressure-replay.csv",checks)
if __name__=="__main__":run()
