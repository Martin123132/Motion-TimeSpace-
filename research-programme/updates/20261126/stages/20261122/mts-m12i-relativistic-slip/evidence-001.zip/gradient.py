from constraint import *
import native

def run():
    meta={}
    for model in ("cold","heavy"):
        bank=Moments(model)
        path=native.SPEC/"runs/projection/a225-w6-d8.npz" if model=="heavy" else native.NATIVE/"runs/backgrounds/cold.npz"
        status=native.obj(native.source(f"runs/{model}/status.json"))
        native.checked(path,status["source_hash"])
        bg=native.engine.camb.get_background(native.engine.inherited.params_for(path,background_boost=8.))
        assert bg.Params.nu_mass_eigenstates==1
        meta[model]=dict(mass_over_temperature=float(bg.nu_masses[0]),massless_limit_coeff=float(bg.grhormass[0]),massless_coeff=float(bg.grhornomass))
        assert abs(meta[model]["massless_coeff"]/(bank.raw["grhor_t"][0,0]*bank.raw["a"][0,0]**2)-1)<2e-5
    record("radiation-background.json",meta)
    modes=Mixed();bank=Moments("heavy")
    for start in range(0,len(bank.fine),16):
        fields=[];indices=bank.fine[start:start+16]
        for idx in indices:
            guard()
            mode=bank.grad_amplitude(modes,idx)
            fields.append(project_stress(modes,*modes.split(mode),modes.size))
        packet(f"driver-{start:03}.npz",indices=indices,source=np.array(fields))
    print("129 fixed source slices",flush=True)
if __name__=="__main__":run()
