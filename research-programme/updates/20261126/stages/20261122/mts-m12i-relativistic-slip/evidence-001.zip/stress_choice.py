from constraint import *

def free_wave(mass):
    vec=np.array([[0.,0.,0.],[1.,0.,0.],[0.,1.,1.],[-1.,1.,0.],[0.,-1.,2.]])
    amp=np.array([1.,.12+.05j,.08j,.07-.03j,.04j]);energy=np.hypot(mass,np.linalg.norm(vec,axis=1))
    axes=np.arange(16)*2*np.pi/16
    coord=np.array(np.meshgrid(axes,axes,axes,indexing="ij"))
    clock=.7;phase=np.exp(1j*(np.einsum("sa,aijk->sijk",vec,coord)-(energy-mass)[:,None,None,None]*clock))
    combine=lambda coeff:np.einsum("s,sijk->ijk",amp*coeff,phase)
    env=combine(np.ones(len(vec)));grad=np.array([1j*combine(val) for val in vec.T])
    hess=np.array([[-combine(one*two) for two in vec.T] for one in vec.T])
    speed=-1j*combine(energy)
    dens=abs(env)**2;dn=2*(env.conj()*grad).real
    dnn=2*(grad[:,None]*grad.conj()[None,:]+env.conj()*hess).real
    identity=np.eye(3)[:,:,None,None,None]
    flux=(env.conj()*grad).imag
    adv=flux[:,None]*flux[None,:]/(mass*dens)
    ampstress=dn[:,None]*dn[None,:]/(4*mass*dens)
    hilbert=adv+ampstress-identity*np.trace(dnn,axis1=0,axis2=1)/(4*mass)
    mad=adv+ampstress-dnn/(4*mass)
    exact=np.zeros_like(hilbert)
    for angle in np.arange(16)*2*np.pi/16:
        carrier=np.exp(1j*angle)*np.sqrt(2/mass)
        vg=(carrier*grad).real;timeg=(carrier*speed).real;field=(carrier*env).real
        exact+=(vg[:,None]*vg[None,:]+.5*identity*(timeg**2-(vg**2).sum(axis=0)-(mass*field)**2))/16
    tf=lambda arr:arr-identity*np.trace(arr,axis1=0,axis2=1)/3
    modes=np.array(np.meshgrid(*([np.fft.fftfreq(16)*16]*3),indexing="ij"))
    def divergence(field):
        return np.einsum("bxyz,abxyz->axyz",1j*modes,np.fft.fftn(field,axes=(-1,-2,-3)))
    def err(val,ref):
        return np.linalg.norm(val-ref)/np.linalg.norm(ref)
    measured_div=err(divergence(hilbert),divergence(mad))
    hilbert_tf=err(tf(hilbert),tf(exact));mad_tf=err(tf(mad),tf(exact))
    assert hilbert_tf<1e-11 and measured_div<1e-12 and mad_tf>.1
    return dict(mass=mass,full_hilbert_error=err(hilbert,exact),hilbert_TF_error=hilbert_tf,
                madelung_TF_error=mad_tf,divergence_difference=measured_div)

def run():
    controls=[free_wave(mass) for mass in (10.,20.,40.)]
    assert all(3.8<a["full_hilbert_error"]/b["full_hilbert_error"]<4.2 for a,b in zip(controls,controls[1:]))
    table("free-field-stress-control.csv",controls)
    modes=Mixed();bank=Moments("heavy")
    records=[]
    amp=lambda data:coefficient(modes,bank.k,data)
    norm=lambda vals:np.sqrt(np.sum(modes.big.weights[modes.big.inband]*abs(vals)**2))
    for idx in (0,len(bank.fine)-1,*range(len(bank.fine)+1,len(bank.at))):
        at=bank.at[idx];rho=bank.coeff[-1]/at
        alpha=bank.raw["sigma"][:,idx]/bank.k
        delta=bank.std["mts_drho_h"][:,idx]/rho-3*bank.raw["adotoa"][:,idx]*alpha
        added=rho*amp(delta)/(4*(at*bank.mass)**2)
        observed=amp(bank.psi[:,idx]-bank.phi[:,idx])
        lapse=amp(bank.psi[:,idx])
        records.append(dict(a=at,calculated_extra_slip_rms=norm(added),actual_linear_slip_rms=norm(observed),extra_over_actual_slip=norm(added)/norm(observed),
            extra_over_lapse=norm(added)/norm(lapse),extra_force_over_actual_slip_force=norm(added*modes.k)/norm(observed*modes.k),
            max_native_q_over_am=modes.k.max()/(at*bank.mass)))
    table("hydrodynamic-stress-counterfactual.csv",records)
if __name__=="__main__":run()
