from canonical_replay import block
from constraint import *
from scipy.interpolate import CubicSpline
from scipy.integrate import cumulative_simpson,simpson,solve_ivp
from matching import fft_tensor,weighted

def run():
    k,aa,mass,t,z,v,d,u,phi,psi,hub=block()
    bank=Moments("heavy");modes=Mixed();fine=bank.fine
    import native
    bg=native.engine.camb.get_background(native.engine.inherited.params_for(native.SPEC/"runs/projection/a225-w6-d8.npz",background_boost=8.))
    with np.load(pinned("native-heavy.npz")) as prev:
        eta_pre=bg.conformal_time(1/prev["dates"][prev["raw"]]-1,tol=1e-10)
    eta=np.r_[eta_pre,bank.times[fine]];epochs=np.r_[aa,bank.raw["a"][0,fine]];npre=len(t)
    scale_eta=CubicSpline(eta,epochs)
    phase=mass*(scale_eta.antiderivative()(eta)-scale_eta.antiderivative()(eta[0]))
    assert max(abs((phase[:npre]-t)))<2e-5
    scale=CubicSpline(phase,np.log(epochs))
    geom=CubicSpline(phase,np.concatenate((phi,bank.phi[:,fine]),axis=1),axis=1)
    lapse=CubicSpline(phase,np.concatenate((psi,bank.psi[:,fine]),axis=1),axis=1)
    def evolve(clock,state):
        p=geom(clock);s=lapse(clock);h=scale(clock,1);xi=(k/(mass*np.exp(scale(clock))))**2
        zz,vv=state[:2];dd,yy=np.split(state[2:],2)
        return np.r_[vv+1.5*h*zz,-zz-1.5*h*vv,yy+1.5*h*dd+vv*(s+3*p),-(1+xi)*dd-1.5*h*yy+zz*(3*p-s)]
    long=np.unique(modes.rad[modes.long]);short=np.unique(modes.rad[~modes.long]);context=dict(long=long,short=short)
    targets=(0,64,100);series=[];primary={};states={}
    fine_only="--fine" in sys.argv
    attempts=((0,48),) if fine_only else ((0,32),(0,48),(npre-1,48))
    for launch,rate in attempts:
        first=np.r_[z[launch],v[launch],d[:,launch],u[:,launch]-3*v[launch]*phi[:,launch]]
        sol=solve_ivp(evolve,[phase[launch],phase[-1]],first,method="DOP853",dense_output=True,rtol=3e-12,atol=1e-14,max_step=2*np.pi/rate)
        assert sol.success
        for idx in targets:
            centre=phase[npre+idx];at=bank.at[idx]
            grouping=((4,256),(4,128)) if fine_only else (((4,64),(4,32),(4,16),(2,64)) if launch==0 and rate==48 else ((4,64),))
            for count,points in grouping:
                grid=centre+np.linspace(-count*np.pi,count*np.pi,count*points+1)
                if grid[0]<phase[launch] or grid[-1]>phase[-1]:
                    assert (launch==npre-1 and idx==0)
                    continue
                w=np.cos((grid-centre)/(2*count))**4
                w*=simpson(np.eye(len(grid)),x=grid,axis=0);w/=w.sum()
                dd=transfer(modes,k,sol.sol(grid)[2:2+len(k)])
                gram=(dd[long]*w)@dd[short].T
                field=fft_tensor(modes,context,gram)[0]*bank.coeff[-1]/(at**3*mass**2)
                states[launch,rate,idx,count,points]=field
    if fine_only:
        with np.load(HERE/"continued-stress.npz") as previous:
            for idx in targets:
                ref=states[0,48,idx,4,256];denom=norms(modes,ref)
                for name,other in (("128",states[0,48,idx,4,128]),("64",previous[f"canonical_{idx}"]),
                        ("bulk",previous[f"bulk_{idx}"]),("bulk_and_density",previous[f"bulk_{idx}"]+previous[f"gradient_{idx}"])):
                    delta=norms(modes,other-ref)
                    series.append(dict(case=name,idx=idx,a=bank.at[idx],**{tag:delta[tag]/denom[tag] for tag in denom}))
                primary[f"canonical_{idx}"]=ref
        packet("refined-canonical-stress.npz",axes=modes.out,**primary);table("refined-same-time.csv",series)
        return
    with np.load(pinned("transition-stress.npz")) as inputs:old_edge=inputs["canonical_edge"]
    for idx in targets:
        base=states[0,48,idx,4,64]
        postgrad=project_stress(modes,*modes.split(bank.grad_amplitude(modes,idx)),modes.size)
        bulk=project_stress(modes,*modes.split(bank.bulk_wave(modes,idx)),modes.size)
        for key,trial in list(states.items())+[((-1,0,idx,0,0),postgrad+bulk),((-2,0,idx,0,0),bulk)]+([((-3,0,idx,0,0),old_edge)] if idx==0 else []):
            if key[2]!=idx:continue
            ref=norms(modes,base);delta=norms(modes,trial-base)
            series.append(dict(launch=key[0],steps=key[1],idx=idx,a=bank.at[idx],cycles=key[3],samples=key[4],**{name:delta[name]/ref[name] for name in ref}))
        primary[f"canonical_{idx}"]=base;primary[f"gradient_{idx}"]=postgrad;primary[f"bulk_{idx}"]=bulk
    packet("continued-stress.npz",axes=modes.out,**primary)
    table("same-time-stress.csv",series)
if __name__=="__main__":run()
