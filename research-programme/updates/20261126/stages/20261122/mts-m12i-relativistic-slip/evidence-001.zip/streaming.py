from constraint import *
from scipy.integrate import cumulative_simpson,simpson
from scipy.interpolate import CubicSpline
from scipy.special import expit,roots_laguerre,spherical_jn
from scipy.linalg import solve_triangular

I0=7*np.pi**4/120
def thermal(order):
    nodes,weights=roots_laguerre(order)
    weighted_fermi=weights*expit(nodes)
    log_slope=-nodes*expit(nodes)
    return nodes,weighted_fermi,log_slope

def driver():
    stack=[];indices=[]
    for start in range(0,129,16):
        with np.load(HERE/f"driver-{start:03}.npz") as bank:
            indices.extend(bank["indices"]);stack.append(bank["source"])
    assert np.array_equal(indices,np.arange(129))
    return np.concatenate(stack,axis=0)

def weights(times):
    result=np.zeros((len(times),len(times)))
    for end in range(1,len(times)):
        step=times[1]-times[0]
        if end==1:result[end,:2]=.5*step;continue
        split=end if end%2==0 else end-3
        if split:
            result[end,:split+1]=step*np.r_[1,np.tile([4,2],split//2)[:-1],1]/3
        if split<end:result[end,split:end+1]+=3*step*np.array([1,3,3,1])/8
    assert np.max(abs(result.sum(axis=1)-(times-times[0])))<1e-10
    return result

def response_rows(wn,times,scale,meta,order,selectors=("massless","both")):
    count=len(times);lo,hi=np.tril_indices(count,-1)
    elapsed=times[lo]-times[hi]
    step=weights(times)[lo,hi]
    nodes,wf,slope=thermal(order);mass=meta["mass_over_temperature"]
    eps=np.hypot(nodes[:,None],mass*scale[None,:])
    velocity=nodes[:,None]/eps
    travel=cumulative_simpson(velocity,x=times,initial=0,axis=1)
    ndiff=travel[:,lo]-travel[:,hi]
    profiles=(meta["massless_limit_coeff"]/I0*(nodes**3*slope*wf)[:,None]*eps[:,hi]/eps[:,lo]/scale[lo]**2)
    massless=-4*meta["massless_coeff"]/scale[lo]**2
    histories={key:[] for key in selectors}
    for k in wn:
        guard()
        def slope_by_k(path):
            if k==0:return 2*path/15
            return spherical_jn(2,k*path,derivative=True)/k
        rad=massless*slope_by_k(elapsed)
        if "both" in selectors:
            massive=np.einsum("ij,ij->j",profiles,slope_by_k(ndiff))
        for key in selectors:
            operator=np.eye(count)
            operator[lo,hi]=-step*(rad if key=="massless" else rad+massive)
            unit=np.zeros(count);unit[-1]=1
            dual=solve_triangular(operator.T,unit,lower=False,unit_diagonal=True,check_finite=False)
            dual[-1]-=1
            histories[key].append(dual)
    return {name:np.array(series) for name,series in histories.items()}

def project(modes,source,wn,values):
    radius,idx=np.unique(np.sqrt(modes.k2),return_inverse=True)
    dual=CubicSpline(wn,values,axis=0)(radius)
    total=np.zeros(len(idx),complex)
    for pos in range(0,len(idx),4096):
        chunk=slice(pos,pos+4096)
        total[chunk]=np.einsum("ij,ji->i",dual[idx[chunk]],source[:,chunk])
    total[0]=0
    return total

def run():
    modes=Mixed();state=Moments("heavy");meta=json.loads((HERE/"radiation-background.json").read_bytes())["heavy"]
    raw=driver();checks=[];fields={};terminal=raw[-1];times=state.times[state.fine];scale=state.at[state.fine]
    limit=np.sqrt(modes.k2.max());coeffs=[]
    for label,stride,nwave,nmom in (("base",1,65,32),("time64",2,65,32),("time32",4,65,32),("wave33",1,33,32),("thermal48",1,65,48)):
        wn=np.linspace(0,limit,nwave)
        dual=response_rows(wn,times[::stride],scale[::stride],meta,nmom,("massless","both") if label=="base" else ("both",))
        for component,matrix in dual.items():
            fields[label+"-"+component]=project(modes,raw[::stride],wn,matrix)
            coeffs.append(dict(case=label,radiation=component,max_row_l1=np.max(np.sum(abs(matrix),axis=1))))
    ref=fields["base-both"]
    for key,val in fields.items():
        check=norms(modes,ref-val);baseline=norms(modes,ref)
        checks.append(dict(case=key,**{name:check[name]/baseline[name] for name in baseline}))
    combined=terminal+ref
    physical=[]
    for name,field in (("bare",terminal),("both_induced",ref),("massless_induced",fields["base-massless"]),("screened_at_fixed_curvature",combined)):
        fit=float((modes.weights*field*terminal.conj()/modes.safe**2).real.sum()/(modes.norm(terminal/modes.safe)**2))
        physical.append(dict(field=name,**norms(modes,field),signed_overlap_over_bare_slip=fit))
    nodes,wf,_=thermal(48);eps=np.hypot(nodes[:,None],meta["mass_over_temperature"]*scale)
    rho=meta["massless_limit_coeff"]*(wf*nodes**2)@eps/I0/scale**2
    pressure=meta["massless_limit_coeff"]*(wf*nodes**4)@(1/eps)/(3*I0*scale**2)
    rawrho=state.raw["grhonu_t"][0,state.fine];rawp=state.nu_h[0,state.fine]-rawrho
    zeta=2*(2/15+2/(45*np.sqrt(3)))*(times[-1]-times[0])**2*(meta["massless_coeff"]+meta["massless_limit_coeff"])/scale.min()**2
    record("kernel-bound.json",dict(conformal_duration_Mpc=times[-1]-times[0],start=scale[0],stop=scale[-1],operator_bound=zeta,
        maximum_fraction_of_history_sup=zeta/(1-zeta),thermal_rho_vs_native=float(max(abs(rho/rawrho-1))),thermal_p_vs_native=float(max(abs(pressure/rawp-1)))))
    table("radiation-norms.csv",physical);table("volterra-refinement.csv",checks);table("dual-gain.csv",coeffs)
    packet("kinetic-response.npz",axes=modes.out,terminal=terminal,massless=fields["base-massless"],both=ref,thermal48=fields["thermal48-both"])
    print("kinetic response",physical[-1],flush=True)
if __name__=="__main__":run()
