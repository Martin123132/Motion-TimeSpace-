from constraint import *

def run():
    modes=Mixed();coords=((4,2,1),(9,-2,4),(21,8,1),(-17,-6,8))
    look={tuple(vec):(idx,False) for idx,vec in enumerate(modes.big.axes.T)}
    for key,(idx,_) in list(look.items()):
        reverse=tuple(-np.array(key))
        if reverse not in look:look[reverse]=(idx,True)
    longs=np.array([vec for vec,entry in look.items() if modes.long[entry[0]]])
    def pick(field,keys):
        refs=[look[tuple(vec)] for vec in keys]
        values=field[[row[0] for row in refs]]
        return np.where([row[1] for row in refs],values.conj(),values)
    rows=[]
    for model in ("cold","heavy"):
        bank=Moments(model)
        amp=lambda arr:coefficient(modes,bank.k,arr[:,0])
        phi,psi,flow=map(amp,(bank.phi,bank.psi,bank.F1))
        with np.load(HERE/f"switch-{model}.npz") as outputs:
            for coord in coords:
                wave=np.array(coord);shorts=wave-longs
                use=[tuple(unit) in look and not modes.long[look[tuple(unit)][0]] for unit in shorts]
                low=longs[use];high=shorts[use]
                p,s,f=(pick(arr,low) for arr in (phi,psi,flow))
                z,t,h=(pick(arr,high) for arr in (phi,psi,flow))
                diff=modes.big.fund;vec=wave*diff;low=low*diff;high=high*diff
                k2=vec@vec;pq=(low*high).sum(1)
                contract=lambda one,two:1.5*((one@vec)*(two@vec)/k2-(one*two).sum(1)/3)
                q=-2*k2*(p*z+s*t)-2*(contract(high,high)*p*(z-t)+contract(low,low)*z*(p-s))+2*contract(low,high)*(-p*z+s*t+p*t+s*z)
                u=(-2*k2-2*((low**2+high**2).sum(1))+pq)*p*z+3*f*h
                pos=np.nonzero((modes.out.T==wave).all(axis=1))[0].item()
                for name,terms in (("metric_Q",q),("metric_Hamiltonian_U",u)):
                    target=outputs[name][pos]
                    error=abs(terms.sum()-target)/abs(target)
                    assert error<2e-5
                    rows.append(dict(model=model,mode=str(coord),component=name,pairs=len(low),relative=error))
    table("geometry-mode-pairs.csv",rows)
if __name__=="__main__":run()
