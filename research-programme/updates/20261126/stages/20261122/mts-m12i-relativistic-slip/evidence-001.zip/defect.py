from pressure_bridge import *
import native
from scipy.integrate import cumulative_simpson
from math import factorial

def derivative(array,time,width):
    size=2*width+1;output=np.zeros_like(array)
    for idx in range(len(time)):
        start=min(max(idx-width,0),len(time)-size);sel=np.arange(start,start+size)
        step=np.median(np.diff(time[sel]));x=(time[sel]-time[idx])/step
        target=np.zeros(size);target[1]=1/step
        coeff=np.linalg.solve(np.array([x**order for order in range(size)]),target)
        output[...,idx]=array[...,sel]@coeff
    return output
def run():
    modes=Mixed()
    with np.load(pinned("native-heavy.npz")) as src:
        raw=src["raw"];at=src["dates"][raw];mass=float(src["mass"]);k=src["k"];coef=src["coeff"][-1]
        aa=src["values"][0,raw,src["names"].tolist().index("a")]
        scale=aa**1.5*mass/np.sqrt(coef);phase0=src["carrier_phase"]
        z=src["heavy_background_phi"]*scale;v=src["heavy_background_speed"]*scale/(aa*mass)
        d=src["heavy_delta_N"]*scale;u=src["heavy_normal_N"]*scale/(aa*mass)
        phi=src["phi"][:,raw];psi=src["psi"][:,raw];hub=src["values"][0,raw,src["names"].tolist().index("H")]
    bg=native.engine.camb.get_background(native.engine.inherited.params_for(native.SPEC/"runs/projection/a225-w6-d8.npz",background_boost=8.))
    eta=bg.conformal_time(1/at-1,tol=1e-10);clock=cumulative_simpson(mass*aa,x=eta,initial=0)
    H=hub/(mass*aa);xi=(k[:,None]/(aa*mass))**2
    weight=modes.big.weights[modes.big.inband]
    norm=lambda arr:np.sqrt(np.sum(weight*abs(coefficient(modes,k,arr))**2))
    checks=[];ledger=[]
    for width in (5,6):
        dt=lambda arr:derivative(arr,clock,width)
        rz=dt(z)-v-1.5*H*z;rv=dt(v)+z+1.5*H*v
        physical_u=dt(d)-1.5*H*d-v*psi
        rd=physical_u-u
        ru=dt(u)+(1+xi)*d+1.5*H*u-3*v*dt(phi)+z*psi
        for centre,count in ((128,4),(128,8),(80,4),(176,4)):
            select=np.arange(centre-16*count,centre+16*count+1);t=clock[select]
            base=simpson(np.eye(len(t)),x=t,axis=0);mid=(t[-1]+t[0])/2;beta=np.pi/(t[-1]-t[0])
            ang=(t-mid)*beta;co=np.cos(ang);sn=np.sin(ang);base/=base@co**4
            w=base*co**4;dw=-4*base*beta*co**3*sn;d2=4*base*beta**2*(3*co**2*sn**2-co**4)
            mean=lambda arr,wt=w:arr[...,select]@wt
            measured=2*mean(v*u-z*d)
            bare=mean(z*d,d2)+3*mean(H*z*d,dw)+mean(xi*z*d)+mean(z*v*(psi+3*phi),dw)+mean((v*v-z*z)*(3*phi-psi))
            back=mean(rz*d,dw)+3*mean((rz*v+z*rv)*phi)-mean(rz*physical_u+rv*d)
            perturb=mean(z*rd,dw)-mean(z*ru+v*rd)+mean(rz*rd)
            for name,val in (("same_clock_bare",bare),("background_defect_only",bare+back),("off_shell_accounting",bare+back+perturb)):
                checks.append(dict(derivative_halfwidth=width,centre=centre,cycles=count,case=name,error_over_pressure=norm(val-measured)/norm(measured)))
            for name,val in (("background",back),("perturbation",perturb)):
                ledger.append(dict(halfwidth=width,centre=centre,cycles=count,component=name,relative=norm(val)/norm(measured)))
    table("pressure-defect-test.csv",checks);table("off-shell-budget.csv",ledger)
    record("clock-check.json",dict(length_ratio=float((clock[-1]-clock[0])/(phase0[-1]-phase0[0])),max_step_relative=float(np.max(abs(np.diff(clock)/np.diff(phase0)-1)))))
if __name__=="__main__":run()
