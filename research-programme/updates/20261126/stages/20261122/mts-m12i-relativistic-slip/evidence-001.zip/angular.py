from streaming import *
from scipy.integrate import solve_ivp

def angular(times,scale,source,wavenumber,meta,nmu,nmom):
    mu,weight=np.polynomial.legendre.leggauss(nmu);project=(3*mu**2-1)*weight/4
    q,wf,slope=thermal(nmom)
    driver_spline=CubicSpline(times,source)
    history=CubicSpline(times,scale)
    divisor=wavenumber**2
    def terms(clock,vector):
        at=history(clock);eps=np.hypot(q,at*meta["mass_over_temperature"])
        vel=np.r_[1.,q/eps]
        stress=np.r_[4*meta["massless_coeff"],(meta["massless_limit_coeff"]/I0)*wf*q**4*(-slope)/eps]/at**2
        tensor=stress@(vector.reshape(len(vel),len(mu))@project)
        return tensor,vel
    def rhs(clock,vector):
        force,vel=terms(clock,vector)
        lapse=(driver_spline(clock)+force)/divisor
        return (-1j*wavenumber*mu*(vel[:,None]*vector.reshape(-1,len(mu))+lapse/vel[:,None])).ravel()
    zero=np.zeros((nmom+1)*nmu,complex)
    sol=solve_ivp(rhs,times[[0,-1]],zero,method="DOP853",rtol=2e-10,atol=2e-12,max_step=(times[-1]-times[0])/64)
    assert sol.success
    return terms(times[-1],sol.y[:,-1])[0]

def run():
    state=Moments("heavy");modes=Mixed();meta=json.loads((HERE/"radiation-background.json").read_bytes())
    coords=[(4,2,1),(9,-2,4),(21,8,1),(-17,-6,8),(29,1,1)]
    indices=np.array([np.nonzero((modes.out.T==coord).all(axis=1))[0].item() for coord in coords])
    slices=[]
    for start in range(0,129,16):
        with np.load(HERE/f"driver-{start:03}.npz") as bank:slices.extend(bank["source"][:,indices])
    slices=np.array(slices)
    with np.load(HERE/"kinetic-response.npz") as packet0:
        ref=packet0["both"][indices]
    with np.load(HERE/"fine-induced-stress.npz") as fine:
        refined=fine["induced"][indices]
    wave=np.sqrt(modes.k2[indices]);rows=[];comparisons=[]
    for index,(coord,k) in enumerate(zip(coords,wave)):
        source=slices[:,index];scale=np.max(abs(source));assert scale>0
        answers=[]
        for ang,mom in ((16,24),(32,48)):
            value=scale*angular(state.times[state.fine],state.at[state.fine],source/scale,k,meta["heavy"],ang,mom)
            answers.append(value)
        rows.append(dict(mode=str(coord),k=k,volterra_relative=abs(answers[-1]-ref[index])/abs(answers[-1]),
            angular_refinement=abs(answers[-1]-answers[0])/abs(answers[-1]),stress_abs=abs(answers[-1])))
        comparisons.append(dict(mode=str(coord),relative=abs(answers[-1]-refined[index])/abs(answers[-1]),absolute=abs(answers[-1]-refined[index])))
    cold=Moments("cold");zero=angular(cold.times[cold.fine],cold.at[cold.fine],np.zeros(129),wave[0],meta["cold"],16,24)
    assert zero==0
    table("independent-transport.csv",rows)
    table("fine-angular-replay.csv",comparisons)
    record("cold-kinetic-null.json",dict(zero_stress=float(abs(zero)),reason="paired cold lacks the heavy gradient driver; baseline neutrinos themselves are present"))
if __name__=="__main__":run()
