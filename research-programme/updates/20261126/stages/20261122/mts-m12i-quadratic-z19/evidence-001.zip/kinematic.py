from common import Background, Modes, apply_green, green, guard, np, table
from readout import average
import csv


def push(modes, density, theta, size=135):
    real=lambda field:modes.real(field,size)
    rho=real(density)
    displacement=[real(1j*axis*density/modes.k**2) for axis in modes.vec]
    velocity=[real(-1j*axis*theta/modes.k**2) for axis in modes.vec]
    mass=np.zeros(len(modes.k2),complex)
    divergence=np.zeros_like(mass)
    independent=np.zeros_like(mass)
    expanded=.5*rho**2
    for left, outleft in enumerate(modes.outvec):
        advected=np.zeros_like(rho)
        current=np.zeros_like(mass)
        expanded-=displacement[left]*real(1j*modes.vec[left]*density)
        for right, outright in enumerate(modes.outvec):
            mass-=.5*outleft*outright*modes.spec(displacement[left]*displacement[right])
            current-=1j*outright*modes.spec(displacement[right]*velocity[left])
            longitudinal=modes.vec[left]*modes.vec[right]/modes.k**2
            expanded+=.5*real(-longitudinal*density)**2
            advected-=displacement[right]*real(longitudinal*theta)
        divergence+=1j*outleft*(current-modes.spec(rho*velocity[left]))
        independent+=1j*outleft*modes.spec(advected)
    err_d=modes.norm(mass-modes.spec(expanded))/modes.norm(mass)
    err_v=modes.norm(divergence-independent)/modes.norm(divergence)
    assert err_d<2e-5 and err_v<2e-5 and mass[0]==divergence[0]==0
    return mass,divergence,err_d,err_v


def run():
    modes=Modes()
    with np.load('material-window.npz') as packet:
        basis,counts,cuts=(packet[key] for key in ('basis','counts','cuts'))
    with open('material-transfer.csv',encoding='ascii') as stream:
        transfer=list(csv.DictReader(stream))
    result,tests=[],[]
    weights=counts.cumsum()/counts.sum()
    for model in ('FIRE','cold','heavy'):
        guard()
        bg=Background(model)
        prop=green(bg,modes)[0]
        at=bg.times[0]
        if model=='FIRE':
            with np.load('dust-kernel.npz') as packet:
                growth,deriv,second,rate=(packet[key][1] for key in ('linear_growth','linear_rate','D2','D2_rate'))
                raw_theta=-at*bg.hub(at)*deriv*modes.fire
                mass,theta2,dc,vc=push(modes,growth*modes.fire,raw_theta)
                inertia=packet['I2']
                transported=apply_green(prop,np.stack((mass-second*inertia,-at/bg.B*(theta2+at*bg.hub(at)*rate*inertia))),modes)
                reference=packet['inherited']
                errs=[modes.norm(one-two)/modes.norm(two) for one,two in zip(transported,reference)]
                assert max(errs)<2e-5
                tests.append(dict(model=model,species='dust',density_identity=dc,theta_identity=vc,growing_density=errs[0],growing_scaled_theta=errs[1]))
            continue
        first,theta=bg.fields_at(modes,0)
        data=[push(modes,one,two) for one,two in zip(first,theta)]
        for species,vals in zip(bg.species,data):
            tests.append(dict(model=model,species=species,density_identity=vals[2],theta_identity=vals[3],growing_density=None,growing_scaled_theta=None))
        launch=np.stack([vals[0] for vals in data]+[-at/bg.B*vals[1] for vals in data])
        evolved=apply_green(prop,launch,modes)
        target='wave' if model=='heavy' else 'baryon'
        idx=bg.species.index(target)
        cdm=bg.species.index('cdm')
        shifts=[]
        for state in (launch,evolved):
            mean=average(modes,basis,state[idx]-state[cdm])
            shifts.append(100*weights*(mean-mean[-1]))
        for pos,cut in enumerate(cuts):
            original=[float(row['shift_pp']) for row in transfer if row['model']==model and row['target']==target and float(row['cut_kpc'])==cut]
            assert len(original)==2
            base=original[1]-original[0]
            extra=shifts[1][pos]-shifts[0][pos]
            result.append(dict(model=model,target=target,cut_kpc=cut,generated_chart_drift_pp=base,
                        transport_launch_pp=shifts[0][pos],transport_final_pp=shifts[1][pos],transport_drift_pp=extra,
                        conditional_drift_with_transport_pp=base+extra,conditional_final_share=weights[pos]+(original[1]+shifts[1][pos])/100))
    table('kinematic-material-drift.csv',result)
    table('kinematic-identity-checks.csv',tests)


if __name__=='__main__':
    run()
