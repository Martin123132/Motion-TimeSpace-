from common import *
prior.init_particles()
prior.pin(prior.PREV,'early_dynamics.py')
from early_dynamics import growing
from initial_file import Initial
def run():
    modes=Modes();bg=Background('FIRE');ic=Initial();at=np.r_[ic.a,bg.times]
    g,gp,second,sp=growing(at,ic)
    second,sp=second/g[0]**2,sp/g[0]**2
    gp=gp/g[0];g=g/g[0]
    size=135
    flux,inertia,_,_=source_terms(modes,size,modes.fire,-modes.fire,1,0)
    shifts=[modes.real(1j*axis*modes.fire/modes.k**2,size) for axis in modes.vec]
    trace=modes.real(-modes.fire,size)
    shear=np.zeros_like(trace);transport=np.zeros_like(inertia)
    for left in range(3):
        for right in range(left,3):
            multi=1 if left==right else 2
            deriv=modes.real(-modes.vec[left]*modes.vec[right]*modes.fire/modes.k**2,size)
            shear+=multi*deriv**2
            term=modes.spec(shifts[left]*shifts[right])
            transport-=.5*multi*modes.outvec[left]*modes.outvec[right]*term
    invariant=modes.spec(.5*(trace**2-shear))
    assert abs(invariant[0])<1e-15
    def euler(idx):
        density=-second[idx]*invariant+g[idx]**2*transport
        flow=at[idx]*bg.hub(at[idx])*(sp[idx]*invariant+g[idx]*gp[idx]*inertia)
        return np.stack((density,-at[idx]*flow/bg.B))
    propagators=green(bg,modes)
    inherited=apply_green(propagators[0],euler(1),modes)
    generated=np.zeros_like(inherited);coarse=np.zeros_like(inherited)
    for slot,epoch in enumerate(bg.times):
        velocity=epoch*bg.hub(epoch)*gp[slot+1]
        forcing=np.stack((g[slot+1]*velocity*flux/(epoch*bg.hub(epoch)),-velocity**2*inertia/(bg.hub(epoch)*bg.B)))
        integrand=apply_green(propagators[slot],forcing,modes)
        generated+=quadrature(slot,64)*integrand;coarse+=quadrature(slot,32)*integrand
    full=inherited+generated;target=euler(-1);rows=[]
    for name,select in [('all',modes.k2>0),('original',modes.inband),('long',(modes.k2>0)&(modes.k2<modes.k.min()**2-1e-13)),('short',modes.k2>2.4**2)]:
        for idx,label in enumerate(('density','theta')):
            norm=modes.norm(target[idx],select)
            rows.append(dict(band=name,quantity=label,full_vs_growing=modes.norm(full[idx]-target[idx],select)/norm,
                zero_launch_vs_growing=modes.norm(generated[idx]-target[idx],select)/norm,coarse_time_difference=modes.norm(generated[idx]-coarse[idx],select)/norm))
    table('growing-dust-limit.csv',rows)
    npz('dust-kernel.npz',axes=modes.out,I2=invariant,generated=generated,inherited=inherited,growing=target,linear_growth=g,linear_rate=gp,D2=second,D2_rate=sp,a=at,B=bg.B)
if __name__=='__main__':run()
