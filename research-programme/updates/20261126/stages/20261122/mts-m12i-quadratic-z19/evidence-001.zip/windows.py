from common import *
prior.init_particles();prior.pin(prior.PART,'destination.py')
from trace import load_host,linear_motion
def deposit(frac,groups,counts,size,offset,modes):
    lower=np.floor(frac.min(axis=0)*size-offset).astype(int)
    upper=np.floor(frac.max(axis=0)*size-offset).astype(int)+2
    shape=upper-lower;cells=int(np.prod(shape))
    grid=np.zeros(cells*5)
    for left in range(0,len(frac),200000):
        guard();right=min(len(frac),left+200000);coord=frac[left:right]*size-offset;index=np.floor(coord).astype(int)
        tail=coord-index;key=index-lower;address=((key[:,0]*shape[1]+key[:,1])*shape[2]+key[:,2])*5+groups[left:right]
        for dx in (0,1):
            for dy in (0,1):
                for dz in (0,1):
                    mass=(tail[:,0] if dx else 1-tail[:,0])*(tail[:,1] if dy else 1-tail[:,1])*(tail[:,2] if dz else 1-tail[:,2])
                    shift=5*((dx*shape[1]+dy)*shape[2]+dz)
                    grid+=np.bincount(address+shift,weights=mass,minlength=len(grid))
    grid=grid.reshape(*shape,5)
    np.testing.assert_allclose(grid.sum(axis=(0,1,2)),counts,rtol=2e-13)
    extent=int(np.max(modes.out));xy=np.r_[0:extent+1,-extent:0];zz=np.arange(extent+1)
    mats=[np.exp(-2j*np.pi*np.outer(axis,np.arange(dim)+start+offset)/size) for axis,dim,start in zip((xy,xy,zz),shape,lower)]
    src=tuple(axis%len(xy) if j<2 else axis for j,axis in enumerate(modes.out));out=[]
    correction=np.prod(np.sinc(modes.out/size)**2,axis=0)
    for idx in range(5):
        partial=np.einsum('za,xya->xyz',mats[2],grid[:,:,:,idx],optimize=True)
        partial=np.einsum('by,xyz->xbz',mats[1],partial,optimize=True)
        partial=np.einsum('ax,xbz->abz',mats[0],partial,optimize=True)
        out.append(partial[src]/counts[idx]/correction)
    return np.array(out)
def run():
    modes=Modes();ic,ids,group,pos,vel,cut=load_host();del ids
    pos+=linear_motion(ic,vel,.01);pos/=modes.box;del vel
    counts=np.bincount(group)
    probes=np.array([[4,1,1],[-6,4,2],[13,-5,3],[17,-14,19],[0,0,64],[31,-25,42],[1,0,0]])
    refs=np.zeros((5,len(probes)),complex)
    for left in range(0,len(pos),240000):
        part=slice(left,left+240000);values=np.exp(-2j*np.pi*(pos[part]@probes.T))
        for idx in range(5):refs[idx]+=values[group[part]==idx].sum(axis=0)
    refs/=counts[:,None]
    lookup=[np.flatnonzero(np.all(modes.out==vec[:,None],axis=0)).item() for vec in probes]
    rows=[]
    for size in (192,384,512):
        base=deposit(pos,group,counts,size,0,modes)
        base+=deposit(pos,group,counts,size,.5,modes);base*=.5
        if size==192:
            previous=np.zeros((5,len(modes.k)),complex);idx=(modes.axes[0]%69,modes.axes[1]%69,modes.axes[2])
            for shift in (0,1):
                adjust=.5*np.exp(-1j*np.pi*shift*modes.axes.sum(axis=0)/size)/np.prod(np.sinc(modes.axes/size)**2,axis=0)
                with np.load(prior.pin(prior.PART,f'raw-cache/window-drift99-{size}-{shift}.npz')) as old:
                    for j in range(5):previous[j]+=old[str(j)][idx]*adjust
            assert np.max(abs(previous-base[:,modes.inband]))<1e-11
        for j,vec in enumerate(probes):
            rows.append(dict(grid=size,index=str(list(map(int,vec))),maximum_absolute_window_error=max(abs(base[:,lookup[j]]-refs[:,j])),
                group_l2_relative=np.linalg.norm(base[:,lookup[j]]-refs[:,j])/np.linalg.norm(refs[:,j])))
        basis=(base*counts[:,None]).cumsum(axis=0)/counts.cumsum()[:,None]
        npz(f'window-{size}.npz',counts=counts,cuts=cut,basis=basis)
        print('window',size,'verified',flush=True)
    table('direct-tag-window-check.csv',rows)
if __name__=='__main__':run()
