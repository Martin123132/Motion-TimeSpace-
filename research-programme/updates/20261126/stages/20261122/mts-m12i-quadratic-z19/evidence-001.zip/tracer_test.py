from common import *
from scipy.ndimage import map_coordinates
prior.init_particles();parent('particle_test.py')
from particle_test import xyz
from recover import Initial,sections,FB
def run():
    modes=Modes();ic=Initial()
    assert digest(ic.path)==json.loads(prior.pin(prior.PART,'initial-complete.json').read_bytes())['sha256']
    with np.load(HERE/'dust-kernel.npz') as bank:
        potential=bank['I2'];g,gp,d2,d2p,epochs=[bank[name] for name in ('linear_growth','linear_rate','D2','D2_rate','a')]
    low,high=[(lo,hi) for part,level,lo,hi,mass in sections(ic) if level==7][0];hub=ic.h*100*np.sqrt(ic.om/epochs[-1]**3+ic.ol)
    population={};data=[]
    for piece in range(4):
        with np.load(parent(f'fire-001-{piece}.npz')) as actual,np.load(prior.pin(prior.PART,f'early-001-{piece}.npz')) as dark:
            for label,part,level,ids,pos,vel in [('unrefined',2,7,actual['coarse_ParticleIDs'],actual['coarse_Coordinates'],actual['coarse_Velocities']),('gas',0,13,actual['gas_ParticleIDs'],actual['gas_Coordinates'],actual['gas_Velocities']),('fine dark',1,13,dark['ids'],dark['pos'],dark['vel'])]:
                if part==2:
                    pick=(ids>=low)&(ids<high);ids,pos,vel=ids[pick],pos[pick],vel[pick]
                key,q,first,second=xyz(ic,ids,part,level);basis=second*modes.box/d2[0]
                final=pos.astype(float)/ic.box-q;final=(final-np.rint(final))*modes.box
                change=final-first*g[1]*modes.box-d2[1]*basis
                posres=change-(g[-1]-g[1])*first*modes.box
                velres=vel.astype(float)*np.sqrt(epochs[-1])-epochs[-1]*hub*gp[-1]*first*modes.box
                data.append(dict(piece=piece,species=label,key=key,q=q%1,basis=basis,pos=posres,vel=velres,band=np.zeros_like(basis),repeat=np.zeros_like(basis)))
    denom=np.where(modes.k2>0,modes.k2,1.);phase=np.exp(2j*np.pi*modes.out.sum(axis=0)*(.5+FB*.5*128/8192)/128)
    for axis in range(3):
        coeff=-1j*modes.outvec[axis]*potential/denom
        coarse=modes.real(coeff*phase,256,'dst')[::2,::2,::2].copy()
        for entry in data:
            if entry['species']=='unrefined':
                field=coarse[tuple(entry['key'].T)];entry['band'][:,axis]=field;entry['repeat'][:,axis]=field
        for size,name in [(160,'repeat'),(224,'band')]:
            fine=modes.real(coeff,size,'dst')
            for entry in data:
                if entry['species']!='unrefined':
                    entry[name][:,axis]=map_coordinates(fine,size*entry['q'].T,order=3,mode='grid-wrap')
    rows=[];kernels=[];filtered=[]
    mask=np.zeros((128,)*3,bool)
    coarse_fields={label:np.zeros((3,128,128,128)) for label in ('band','native','measured velocity residual')}
    for row in data:
        species=row['species'];count=len(row['q']);norm=lambda arr:np.sqrt(np.sum(arr**2)/count)
        true=row['basis'];pred=row['band']
        dot=lambda arr,other:(arr*other).sum()/(count*norm(arr)*norm(other))
        kernels.append(dict(shard=row['piece'],species=species,count=count,band_vs_full_correlation=dot(pred,true),
            band_over_native=norm(pred)/norm(true),band_error_over_native=norm(pred-true)/norm(true),
            interpolation_difference=norm(pred-row['repeat'])/norm(pred)))
        for quantity,coefficient,obs,unit in [('displacement',d2[-1]-d2[1],row['pos'],1000),('velocity',d2p[-1]*epochs[-1]*hub,row['vel'],1)]:
            for label,basis in [('linear-only',0.),('sign-reversed',-pred),('band-2LPT',pred),('full-native-2LPT',true)]:
                err=obs-coefficient*basis
                rows.append(dict(shard=row['piece'],species=species,count=count,quantity=quantity,treatment=label,rms=unit*norm(err)))
        if species=='unrefined':
            locations=tuple(row['key'].T);assert not mask[locations].any();mask[locations]=True
            for name,field in [('band',pred),('native',true),('measured velocity residual',row['vel']/(d2p[-1]*epochs[-1]*hub))]:
                for axis in range(3):coarse_fields[name][axis][locations]=field[:,axis]
    assert mask.sum()==2087470
    for key,value in coarse_fields.items():
        coarse_fields[key]=np.stack([rfftn(x)[modes.src]/128**3 for x in value])
    for cap in (.75,1.5,2.4):
        use=modes.k<=cap;mult=np.where(modes.axes[2,use]==0,1.,2.);target=coarse_fields['measured velocity residual'][:,use]
        norm=lambda arr:np.sqrt(np.sum(mult*abs(arr)**2))
        for name,pred in [('linear-only',0.),('sign-reversed',-coarse_fields['band'][:,use]),('band-2LPT',coarse_fields['band'][:,use]),('full-native-2LPT',coarse_fields['native'][:,use])]:
            filtered.append(dict(kmax=cap,treatment=name,ratio_to_linear_velocity_residual=norm(target-pred)/norm(target),error_kms=norm(target-pred)*abs(d2p[-1]*epochs[-1]*hub)))
    table('simulation-residuals.csv',rows);table('simulation-kernel.csv',kernels);table('masked-second-order-velocity.csv',filtered)
    pooled=[]
    for name in ('unrefined','fine dark','gas'):
        for quantity in ('displacement','velocity'):
            for treatment in ('linear-only','sign-reversed','band-2LPT','full-native-2LPT'):
                selected=[row for row in rows if (row['species'],row['quantity'],row['treatment'])==(name,quantity,treatment)]
                pooled.append(dict(species=name,quantity=quantity,treatment=treatment,count=sum(r['count'] for r in selected),
                    rms=np.sqrt(np.average([r['rms']**2 for r in selected],weights=[r['count'] for r in selected]))))
    table('pooled-particle-test.csv',pooled)
if __name__=='__main__':run()
