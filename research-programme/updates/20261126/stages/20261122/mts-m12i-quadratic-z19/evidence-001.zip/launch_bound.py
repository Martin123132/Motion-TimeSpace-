from common import Background, Modes, green, guard, np, solve_ivp, table
import csv


def project(row, subspace, ns):
    result = row.copy()
    if subspace == 'density':
        result[:, ns:] = 0
    elif subspace == 'velocity':
        result[:, :ns] = 0
    elif subspace == 'species-identical':
        for block in (slice(0, ns), slice(ns, None)):
            result[:, block] = row[:, block].mean(axis=1, keepdims=True)
    return result


def run():
    modes = Modes()
    with open('material-transfer.csv',encoding='ascii') as source:
        report = list(csv.DictReader(source))
    with np.load('material-window.npz') as windows:
        basis, counts, cuts = (windows[key] for key in ('basis', 'counts', 'cuts'))
    results, checks = [], []
    for model, target in (('cold', 'baryon'), ('heavy', 'wave')):
        guard()
        bg = Background(model)
        ns = len(bg.species)
        sign = np.zeros(2*ns)
        sign[bg.species.index(target)], sign[bg.species.index('cdm')] = 1., -1.
        transfer = green(bg,modes)[0]
        row = sign @ transfer - sign
        for index in np.unique(np.linspace(0,len(transfer)-1,5,dtype=int)):
            ksquared = modes.shell2[index]
            def rhs(clock, state):
                at=np.exp(clock)
                hub=bg.hub(at)
                field=state.reshape(2*ns,2*ns)
                acceleration=np.repeat((bg.coeff@field[:ns])[None,:],ns,axis=0)/(2*at*hub*bg.B)
                if bg.mass:
                    acceleration[-1]-=ksquared**2*field[ns-1]/(4*at**2*bg.mass**2*hub*bg.B)
                return np.concatenate((field[ns:]*bg.B/(at**2*hub),acceleration)).ravel()
            sol=solve_ivp(rhs,np.log(bg.times[[0,-1]]),np.eye(2*ns).ravel(),method='DOP853',rtol=2e-12,atol=1e-14)
            assert sol.success
            test = sign @ sol.y[:,-1].reshape(2*ns,2*ns) - sign
            error = max(abs(test-row[index]))
            assert error<2e-8
            checks.append(dict(model=model,k_per_Mpc=np.sqrt(ksquared),max_abs_row_error=error))
        for idx, cut in enumerate(cuts[:-1]):
            selected=[item for item in report if item['model']==model and item['target']==target and float(item['cut_kpc'])==cut]
            assert len(selected)==2 and float(selected[0]['a']) < float(selected[1]['a'])
            drift=float(selected[1]['conditional_fraction'])-float(selected[0]['conditional_fraction'])
            window=(basis[idx]-basis[-1])*(counts.cumsum()[idx]/counts.sum())
            for band, use in (('full-generated',modes.k2>0), ('input-band',modes.inband)):
                shell=modes.inv[use] if bg.mass else np.zeros(use.sum(),dtype=int)
                weight=modes.weights[use]
                envelope=window[use]
                norm_by_shell=np.bincount(shell,weights=weight*abs(envelope)**2,minlength=len(transfer))
                for subspace in ('all','density','velocity','species-identical'):
                    channel=project(row,subspace,ns)
                    sensitivity=np.sqrt(norm_by_shell @ np.sum(channel**2,axis=1))
                    analytic_null=model=='cold' and subspace in ('density','species-identical')
                    least=witness=None
                    if analytic_null:
                        assert sensitivity<2e-11
                    else:
                        assert sensitivity>1e-14
                        least=abs(drift)/sensitivity
                        multiplier=-drift/sensitivity**2
                        response=0.
                        norm2=0.
                        for state in range(2*ns):
                            optimal=multiplier*envelope*channel[shell,state]
                            response+=np.sum(weight*(envelope.conj()*row[shell,state]*optimal).real)
                            norm2+=weight @ abs(optimal)**2
                        witness=drift+response
                        assert abs(witness)<1e-12 and abs(np.sqrt(norm2)/least-1)<2e-11
                    results.append(dict(model=model,target=target,cut_kpc=cut,band=band,subspace=subspace,
                        conditional_drift_pp=100*drift,pp_response_per_joint_rms=100*sensitivity,exact_silent=analytic_null,
                        least_joint_dimensionless_rms=least,witness_residual_pp=None if witness is None else 100*witness))
    table('unknown-launch-thresholds.csv',results)
    table('forward-adjoint-check.csv',checks)


if __name__ == '__main__':
    run()
