from common import Background, Modes, guard, np, table


def average(modes, basis, field):
    return (basis.conj() @ (modes.weights * field)).real


def embed(modes, field):
    result = np.zeros(len(modes.k2), complex)
    result[modes.inband] = field
    return result


def material_terms(modes, size, cold, relative, theta_c, theta_diff, theta2_diff, delta_h, current_diff):
    real = lambda field: modes.real(field, size)
    cold_real, relative_real, theta_diff_real = map(real, (cold, relative, theta_diff))
    geometry = np.zeros(len(modes.k2), complex)
    flux_rate = -1j * (modes.outvec * current_diff).sum(axis=0)
    advected = -cold_real * relative_real
    intrinsic = cold_real * theta_diff_real
    for axis, outaxis in zip(modes.vec, modes.outvec):
        displacement = real(1j * axis * cold / modes.k**2)
        velocity_c = real(-1j * axis * theta_c / modes.k**2)
        relative_velocity = real(-1j * axis * theta_diff / modes.k**2)
        geometry += 1j * outaxis * modes.spec(displacement * relative_real)
        advected += displacement * real(1j * axis * relative)
        flux_rate += 1j * outaxis * modes.spec(velocity_c * relative_real - displacement * theta_diff_real)
        intrinsic -= displacement * real(1j * axis * theta_diff)
        intrinsic -= real(1j * axis * delta_h) * relative_velocity
    intrinsic -= real(delta_h) * theta_diff_real
    equivalent = modes.spec(intrinsic) - theta2_diff
    def err(left, right):
        return modes.norm(left-right) / max(modes.norm(left), 1.e-50)
    return geometry, flux_rate, err(geometry, modes.spec(advected)), err(flux_rate, equivalent)


def run():
    modes = Modes()
    with np.load('material-window.npz') as data:
        material, counts, cuts = (data[name] for name in ('basis', 'counts', 'cuts'))
    share = counts.cumsum() / counts.sum()
    patches, fixed, checks = [], [], []
    for model in ('cold', 'heavy'):
        bg = Background(model)
        cold = bg.species.index('cdm')
        target = bg.species.index('wave' if model == 'heavy' else 'baryon')
        with np.load(f'retarded-{model}.npz') as packet:
            assert packet['species'].tolist() == bg.species and np.array_equal(packet['axes'], modes.out)
            second, current, theta2, fixed_field = (packet[key] for key in ('density','number_current','theta','no_induced'))
        for slot in (0,64):
            guard()
            at = bg.times[slot]
            density, theta = bg.fields_at(modes, slot)
            for other in (target,cold):
                label = bg.species[other]
                diff = density[other] - density[cold]
                theta_diff = theta[other] - theta[cold]
                d2 = second[other] - second[cold] if slot else np.zeros_like(second[0])
                t2 = theta2[other] - theta2[cold] if slot else np.zeros_like(theta2[0])
                if slot:
                    flux = current[other] - current[cold]
                else:
                    flux = np.array([modes.spec(modes.real(density[other],135)*modes.real(-1j*axis*theta[other]/modes.k**2,135)
                                     - modes.real(density[cold],135)*modes.real(-1j*axis*theta[cold]/modes.k**2,135)) for axis in modes.vec])
                results = [material_terms(modes,size,density[cold],diff,theta[cold],theta_diff,t2,density[other],flux) for size in (135,144)]
                geometry, rate, geometry_err, rate_err = results[0]
                spatial = max(modes.norm(f-g)/max(modes.norm(f),1.e-50) for f,g in zip(results[0][:2],results[1][:2]))
                assert max(geometry_err,rate_err,spatial)<2.e-5 and geometry[0]==0 and rate[0]==0
                checks.append(dict(model=model,target=label,a=at,product_rule=geometry_err,relative_flux_identity=rate_err,grid=spatial))
                linear, gen, geom, urate, trate = [average(modes,material,field) for field in (embed(modes,diff),d2,geometry,
                                         embed(modes,-theta_diff)/(at*bg.hub(at)),rate/(at*bg.hub(at)))]
                linear_delta = linear-linear[-1]
                denominator = -linear[-1]*linear_delta
                total = share*(1+linear_delta+gen-gen[-1]+geom-geom[-1]+denominator)
                frac_rate = share*((urate-urate[-1])*(1-linear[-1]) + trate-trate[-1] - urate[-1]*linear_delta)
                assert total[-1]==1 and frac_rate[-1]==0
                if other==cold: assert np.array_equal(total,share) and not np.any(frac_rate)
                for idx,cut in enumerate(cuts):
                    patches.append(dict(model=model,target=label,a=at,cut_kpc=cut,labels=int(counts.cumsum()[idx]),cold_share=share[idx],
                        relative_linear=linear[idx],relative_generated=gen[idx],relative_geometry=geom[idx],
                        linear_shift_pp=100*share[idx]*linear_delta[idx],generated_shift_pp=100*share[idx]*(gen[idx]-gen[-1]),
                        geometry_shift_pp=100*share[idx]*(geom[idx]-geom[-1]),denominator_shift_pp=100*share[idx]*denominator[idx],
                        conditional_fraction=total[idx],shift_pp=100*(total[idx]-share[idx]),NR_rate_pp_per_ln_a=100*frac_rate[idx]))
            if slot:
                for size in (192,384,512):
                    with np.load(f'window-{size}.npz') as packet:
                        basis=packet['basis']
                        assert np.array_equal(packet['counts'],counts) and np.array_equal(packet['cuts'],cuts)
                    for idx,label in enumerate(bg.species):
                        div=1j*(modes.outvec*current[idx]).sum(axis=0)
                        first, full, no_grav, long, short, net = [average(modes,basis,field) for field in
                              (embed(modes,density[idx]),second[idx],fixed_field[idx],
                               second[idx]*((~modes.inband)&(modes.k2<2.4**2)),second[idx]*(modes.k2>2.4**2),-div/(at*bg.hub(at)))]
                        for pos,cut in enumerate(cuts):
                            fixed.append(dict(grid=size,model=model,species=label,cut_kpc=cut,linear=first[pos],
                                     generated=full[pos],linear_plus_generated=first[pos]+full[pos],generated_long=long[pos],
                                     generated_inband=full[pos]-long[pos]-short[pos],generated_short=short[pos],
                                     induced_potential_effect=full[pos]-no_grav[pos],quadratic_NR_continuity_per_ln_a=net[pos]))
    table('material-transfer.csv',patches)
    table('material-identities.csv',checks)
    table('fixed-window-response.csv',fixed)


if __name__ == '__main__':
    run()
