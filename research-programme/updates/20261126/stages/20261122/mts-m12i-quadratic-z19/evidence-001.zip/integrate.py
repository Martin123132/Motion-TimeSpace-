from common import *
def run(model):
    modes=Modes();bg=Background(model);ns=len(bg.species)
    ret=green(bg,modes);fixed=green(bg,modes,False)
    states={key:np.zeros((2*ns,len(modes.k2)),complex) for key in ('fine','medium','coarse','no-induced-gravity')}
    grid_rows=[];anchor_rows=[];fluxes=[];short=[]
    with np.load(parent('band-nonlinear-sources.npz')) as prev:
        anchors={key:prev[key] for key in prev.files if key.startswith(model+'-')}
    for slot,at in enumerate(bg.times):
        guard();hub=bg.hub(at);first_density,first_theta=bg.fields_at(modes,slot)
        src=np.empty_like(states['fine'])
        for idx,label in enumerate(bg.species):
            mass=bg.mass if label=='wave' else 0.
            delta,theta=first_density[idx],first_theta[idx]
            flux,adv,stress,moment=source_terms(modes,135,delta,theta,at,mass,slot==64)
            src[idx]=flux/(at*hub);src[ns+idx]=-(adv+stress)/(hub*bg.B)
            if slot==64:fluxes.append(moment)
            if slot in (0,32,64):
                independent=source_terms(modes,144,delta,theta,at,mass)
                for key,small,large in zip(('continuity','advection','pressure_second'),(flux,adv,stress),independent):
                    norm=modes.norm(large)
                    grid_rows.append(dict(species=label,slot=slot,term=key,relative_error=modes.norm(small-large)/norm if norm else 0.))
                    if label==('wave' if model=='heavy' else 'cdm') and slot in (0,64):
                        original=anchors[f'{model}-{at}-{key}']
                        err=np.linalg.norm(small[modes.inband]-original)
                        anchor_rows.append(dict(slot=slot,term=key,relative_error=err/np.linalg.norm(original) if np.any(original) else err))
        propagated=apply_green(ret[slot],src,modes)
        for key,nstep in [('fine',64),('medium',32),('coarse',16)]:
            weight=quadrature(slot,nstep)
            if weight:states[key]+=weight*propagated
        states['no-induced-gravity']+=quadrature(slot,64)*apply_green(fixed[slot],src,modes)
        if slot%16==0:print(model,slot,'/64',flush=True)
    assert all(np.all(state[:,0]==0) and np.isfinite(state).all() for state in states.values())
    out=states['fine'];inband=modes.inband
    safe=np.where(modes.k2>0,modes.k2,1.)
    vtheta=-bg.B/bg.times[-1]*out[ns:]
    jquad=-1j*modes.outvec[None,:,:]*vtheta[:,None,:]/safe+np.array(fluxes)
    for idx in range(ns):
        assert np.max(abs(jquad[idx,:,0]))<1e-15
    zones={'all':modes.k2>=0,'generated-long':(modes.k2<modes.k.min()**2-1e-13)&(modes.k2>0),'original':inband,'generated-short':modes.k2>2.4**2}
    for name,use in zones.items():
        for idx,label in enumerate(bg.species):
            for channel,ind in [('density',idx),('velocity-variable',ns+idx)]:
                norm=modes.norm(out[ind],use)
                short.append(dict(band=name,species=label,channel=channel,quadratic_rms=norm,
                    medium_error=modes.norm(states['medium'][ind]-out[ind],use)/norm,coarse_error=modes.norm(states['coarse'][ind]-out[ind],use)/norm,
                    neglect_induced_gravity=modes.norm(states['no-induced-gravity'][ind]-out[ind],use)/norm))
    table('retarded-checks-'+model+'.csv',short);table('grid-check-'+model+'.csv',grid_rows);table('anchor-check-'+model+'.csv',anchor_rows)
    npz('retarded-'+model+'.npz',axes=modes.out,initially_populated=inband,species=bg.species,density=out[:ns],theta=vtheta,number_current=jquad,
        k2psi=-np.einsum('s,sk->k',bg.coeff,out[:ns])/(2*bg.times[-1]),no_induced=states['no-induced-gravity'],B=bg.B)
if __name__=='__main__':
    for model in sys.argv[1:] or ('cold','heavy'):run(model)
