import os
for name in ('OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','OMP_NUM_THREADS','BLIS_NUM_THREADS','NUMEXPR_NUM_THREADS'):os.environ[name]='1'
import csv,hashlib,io,json,sys
from pathlib import Path
import numpy as np
from scipy.fft import rfftn,irfftn
from scipy.interpolate import PchipInterpolator
from scipy.integrate import solve_ivp
HERE=Path(__file__).resolve().parent
PREV=HERE.parent/'mts-m12i-common-metric-z19-20261122'
def digest(path):
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
assert digest(PREV/'seal.json')=='052c37f2a648ea0b1b0637a6ef7a6e4433894c83430a4177ca2b3d0ce8d0ae72'
manifest=json.loads((PREV/'seal.json').read_bytes())['files']
def parent(name):
    file=PREV/name;assert digest(file)==manifest[name],name
    return file
parent('stage.py');sys.path.insert(0,str(PREV))
import stage as prior
prior.init_seed()
from seeds import Seed
def guard():
    assert not (HERE/'STOP-REQUESTED').exists();prior.guard()
def save(name,data):
    guard();dest=HERE/name
    if dest.exists():assert dest.read_bytes()==data,dest
    else:
        with dest.open('xb') as stream:stream.write(data)
def npz(name,**fields):
    buf=io.BytesIO();np.savez_compressed(buf,**fields);save(name,buf.getvalue())
def table(name,rows):
    buf=io.StringIO();writer=csv.DictWriter(buf,rows[0],lineterminator='\n');writer.writeheader();writer.writerows(rows);save(name,buf.getvalue().encode())
def record(name,fields):save(name,(json.dumps(fields,indent=2,sort_keys=True,allow_nan=False)+'\n').encode())
class Modes:
    def __init__(self):
        with np.load(parent('phase-band.npz')) as source:
            inside=source['k']<=2.4;self.k=source['k'][inside];self.axes=source['axes'][:,inside];self.R=source['R'][inside];self.fire=source['fire'][inside];self.box=float(source['box'])
        self.fund=2*np.pi/self.box;self.vec=self.fund*self.axes;self.src=tuple(self.axes)
        largest=int(np.max(np.abs(self.axes)))*2
        xy=np.r_[0:largest+1,-largest:0];zz=np.arange(largest+1);coords=np.meshgrid(xy,xy,zz,indexing='ij')
        norm=sum(axis**2 for axis in coords);accepted=(norm<=4*np.max(np.sum(self.axes**2,axis=0)))
        self.out=np.array([axis[accepted] for axis in coords]);self.dst=tuple(self.out);self.k2=self.fund**2*norm[accepted]
        shell,self.inv=np.unique(norm[accepted],return_inverse=True);self.shell2=self.fund**2*shell
        self.weights=np.where(self.out[2]==0,1.,2.);self.inband=(self.k2>=self.k.min()**2-1e-13)&(self.k2<=2.4**2)
        assert np.array_equal(self.out[:,self.inband],self.axes) and not np.any(self.out[:,0])
        self.outvec=self.fund*self.out
    def real(self,coeff,size,which='src'):
        grid=np.zeros((size,size,size//2+1),complex);grid[self.src if which=='src' else self.dst]=coeff
        return irfftn(grid,s=(size,)*3,axes=(0,1,2),workers=1)*size**3
    def spec(self,real):
        size=len(real);return rfftn(real,workers=1)[self.dst]/size**3
    def norm(self,arr,pick=None):
        if pick is None:pick=slice(None)
        return np.sqrt(np.sum(self.weights[pick]*abs(arr[...,pick])**2))
def source_terms(modes,size,delta,theta,at,mass,currents=False):
    assert size>2*np.max(abs(modes.out))
    rho=modes.real(delta,size);velsq=np.zeros_like(rho);gradsq=np.zeros_like(rho) if mass else None
    flux=np.zeros(len(modes.k2),complex);moment=[]
    for axis,outax in zip(modes.vec,modes.outvec):
        velocity=modes.real(-1j*axis*theta/modes.k**2,size);velsq+=velocity**2
        part=modes.spec(rho*velocity);flux-=1j*outax*part
        if currents:moment.append(part)
        if mass:gradsq+=modes.real(1j*axis*delta,size)**2
    adv=.5*modes.k2*modes.spec(velsq)
    if mass:
        lap=modes.real(-modes.k**2*delta,size)
        pressure=-modes.k2*modes.spec(-.5*rho*lap-.25*gradsq)/(2*at**2*mass**2)
    else:pressure=np.zeros_like(adv)
    assert flux[0]==adv[0]==pressure[0]==0
    return flux,adv,pressure,moment
class Background:
    def __init__(self,model):
        self.model=model
        if model=='FIRE':
            self.species=['dust'];self.coeff=np.array([3*(70.2/prior.LIGHT)**2*.272]);self.mass=0.
            self.hub=lambda at:70.2/prior.LIGHT*np.sqrt(.272/at**3+.728)
            self.times=np.geomspace(.01,.05,65)
        else:
            seed=Seed(model,'anchorA','heavy');self.mass=seed.mass if model=='heavy' else 0.
            with np.load(parent('transport-'+model+'.npz')) as src:
                self.times=src['epochs'];self.nodes=src['k'];self.fields=src['full'];self.reduced=src['poisson'];self.species=src['species'].tolist()
            self.hub=seed.H;self.coeff=np.array([seed.coeff[label] for label in self.species])
        self.B=self.times[0]**2*self.hub(self.times[0])
    def fields_at(self,modes,slot,reduced=False):
        at=self.times[slot];fitted=self.reduced if reduced else self.fields
        ip=PchipInterpolator(np.log(self.nodes),fitted[:,:,:,slot],axis=-1)(np.log(modes.k))
        return ip[:,0]*modes.R,ip[:,1]*modes.R/at
def green(bg,modes,gravity=True):
    count=len(bg.species);width=2*count
    modesq=modes.shell2 if bg.mass else np.array([0.])
    def rhs(clock,state):
        at=np.exp(clock);hub=bg.hub(at);g=state.reshape(len(modesq),width,width);out=np.empty_like(g)
        pull=np.sum(g[:,:,count:],axis=-1) if gravity else np.zeros(g.shape[:2])
        out[:,:,:count]=-pull[:,:,None]*bg.coeff/(2*at*hub*bg.B)
        if bg.mass:out[:,:,count-1]+=g[:,:,-1]*(modesq**2/(4*at**2*bg.mass**2*hub*bg.B))[:,None]
        out[:,:,count:]=-g[:,:,:count]*(bg.B/(at**2*hub))
        return out.ravel()
    start=np.broadcast_to(np.eye(width),(len(modesq),width,width)).copy()
    clocks=np.log(bg.times[::-1])
    ans=solve_ivp(rhs,clocks[[0,-1]],start.ravel(),t_eval=clocks,rtol=5e-11,atol=1e-13,method='DOP853',max_step=np.log(5)/64)
    assert ans.success
    return np.ascontiguousarray(ans.y.T.reshape(65,len(modesq),width,width)[::-1])
def apply_green(matrix,source,modes):
    if len(matrix)==1:return matrix[0]@source
    result=np.empty_like(source);stride=32000
    for left in range(0,len(modes.k2),stride):
        window=slice(left,left+stride);result[:,window]=np.einsum('nij,jn->in',matrix[modes.inv[window]],source[:,window],optimize=False)
    return result
def quadrature(slot,intervals,weights=(7,32,12,32,7)):
    step=64//intervals
    if slot%step:return 0.
    n=slot//step;index=n%4
    weight=weights[index] if index else weights[0]*(1 if n in (0,intervals) else 2)
    return weight*2/45*np.log(5)/intervals

