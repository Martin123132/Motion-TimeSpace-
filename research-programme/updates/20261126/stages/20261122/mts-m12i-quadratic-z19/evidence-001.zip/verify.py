import csv
from common import Background, Modes, HERE, PREV, digest, guard, np, parent, prior, record


def rows(name):
    with (HERE/name).open(encoding='utf-8') as stream:
        return list(csv.DictReader(stream))


def worst(name, *columns):
    return max(abs(float(row[col])) for row in rows(name) for col in columns if row[col])


def run():
    guard()
    files=set('PROTOCOL.md FINITE-AMPLITUDE.md MATERIAL-TEST.md LAUNCH-TEST.md KINEMATIC-LAUNCH.md RESULTS.md DERIVATION.md common.py integrate.py windows.py material_window.py dust_limit.py finite_amplitude.py tracer_test.py readout.py launch_bound.py kinematic.py verify.py'.split())
    files.update('dust-kernel.npz growing-dust-limit.csv masked-second-order-velocity.csv pooled-particle-test.csv simulation-residuals.csv simulation-kernel.csv direct-tag-window-check.csv material-window-direct.csv material-window.npz fixed-window-response.csv material-identities.csv material-transfer.csv forward-adjoint-check.csv unknown-launch-thresholds.csv kinematic-material-drift.csv kinematic-identity-checks.csv'.split())
    files.update(f'window-{size}.npz' for size in (192,384,512))
    modes=Modes()
    stats={}
    for model in ('cold','heavy'):
        bg=Background(model)
        for prefix in ('retarded-checks','grid-check','anchor-check','nonlinear-invariants','finite-amplitude','even-amplitude-extrapolation'):
            files.add(f'{prefix}-{model}.csv')
        files.add(f'retarded-{model}.npz')
        with np.load(HERE/f'retarded-{model}.npz') as output:
            assert np.array_equal(output['axes'],modes.out) and np.array_equal(output['initially_populated'],modes.inband)
            assert output['species'].tolist()==bg.species
            assert np.isfinite(output['number_current']).all() and abs(output['number_current'][:,:,0]).max()<1e-15
            for key in ('density','theta','no_induced'):
                assert np.isfinite(output[key]).all() and not np.any(output[key][:,0])
            np.testing.assert_allclose(output['k2psi'],-bg.coeff@output['density']/(2*bg.times[-1]),rtol=1e-11,atol=1e-22)
        errors=rows('even-amplitude-extrapolation-'+model+'.csv')
        fine=[float(row['worst_mode_relative']) for row in errors if float(row['smaller_amplitude'])==.1]
        assert len(fine)==3*len(bg.species) and max(fine)<.00002
        raw=[float(row['worst_mode_relative']) for row in rows('finite-amplitude-'+model+'.csv') if float(row['amplitude'])==.1]
        assert .00002<max(raw)<.005
        assert worst('grid-check-'+model+'.csv','relative_error')<2e-5
        assert worst('anchor-check-'+model+'.csv','relative_error')<2e-5
        time=worst('retarded-checks-'+model+'.csv','medium_error','coarse_error')
        assert time<2e-5
        stats[model]={'worst_four_mode_extrapolated':max(fine),'worst_raw_at_0p1':max(raw),'worst_nested_time':time}
    fixed=rows('fixed-window-response.csv')
    assert len(fixed)==75
    subsets={grid:[r for r in fixed if r['grid']==grid] for grid in ('192','384','512')}
    worst_grid=0
    for mid,fine in zip(subsets['384'],subsets['512']):
        assert all(mid[col]==fine[col] for col in ('model','species','cut_kpc'))
        for col in ('linear','generated','quadratic_NR_continuity_per_ln_a'):
            worst_grid=max(worst_grid,abs(float(mid[col])/float(fine[col])-1))
    stats['fixed_mean_grid384_vs512_max_relative']=worst_grid
    assert worst_grid<.005
    assert worst('material-window-direct.csv','max_abs_error')<2e-12
    assert worst('material-identities.csv','product_rule','grid','relative_flux_identity')<2e-5
    assert len(rows('material-transfer.csv'))==40 and len(rows('unknown-launch-thresholds.csv'))==64
    for row in rows('material-transfer.csv'):
        parts=sum(float(row[col]) for col in ('linear_shift_pp','generated_shift_pp','geometry_shift_pp','denominator_shift_pp'))
        assert abs(parts-float(row['shift_pp']))<1e-12
        if row['target']=='cdm': assert float(row['shift_pp'])==0
    for row in rows('unknown-launch-thresholds.csv'):
        if row['exact_silent']=='True':
            assert row['model']=='cold' and not row['least_joint_dimensionless_rms']
        else:
            assert abs(abs(float(row['conditional_drift_pp']))-float(row['pp_response_per_joint_rms'])*float(row['least_joint_dimensionless_rms']))<1e-12
            assert abs(float(row['witness_residual_pp']))<1e-10
    assert worst('forward-adjoint-check.csv','max_abs_row_error')<2e-8
    assert worst('kinematic-identity-checks.csv','density_identity','theta_identity','growing_density','growing_scaled_theta')<2e-5
    assert len(rows('kinematic-material-drift.csv'))==10
    assert worst('growing-dust-limit.csv','full_vs_growing')<2e-5
    pooled=rows('pooled-particle-test.csv')
    for label,count in (('unrefined',2087470),('gas',34436),('fine dark',137744)):
        for channel in ('displacement','velocity'):
            sub={r['treatment']:float(r['rms']) for r in pooled if r['species']==label and r['quantity']==channel and int(r['count'])==count}
            assert sub['full-native-2LPT']<sub['band-2LPT']<sub['linear-only']<sub['sign-reversed']
    for name in ('phase-band.npz','transport-heavy.npz','transport-cold.npz','band-nonlinear-sources.npz','particle_test.py'):
        parent(name)
    assert not (HERE/'__pycache__').exists()
    assert set(p.name for p in HERE.iterdir())-{'seal.json'}==files
    record('seal.json',dict(files={name:digest(HERE/name) for name in sorted(files)},upstream={str(PREV.name):digest(PREV/'seal.json'),**{f.name:sha for f,sha in prior.PINS.items()}},checks=stats))
    print(len(files),'products;',digest(HERE/'seal.json'),stats)


if __name__=='__main__':
    run()
