import csv
import json
from experiment import HOME,ROOT,G,digest,save,record,table,green,np


def rows(name):
    with (HOME/(name+".csv")).open() as stream:
        return list(csv.DictReader(stream))


def only(data,**values):
    matches=[row for row in data if all(row[key]==str(value) for key,value in values.items())]
    assert len(matches)==1,values
    return matches[0]


def vector(row):
    return np.array([float(row[key]) for key in ("a_R_kms2_kpc","a_z_kms2_kpc")])


def audit():
    for table_name in ("inputs.json","census-inputs.json"):
        raw=json.loads((HOME/table_name).read_bytes())
        for name,expected in raw.get("files",raw).items():
            assert digest(ROOT/name)==expected,name
    edges=np.array([0.,.14,1.1,2.7])
    radius=.62
    osc=.4
    uniform=4*np.pi*np.diff(edges**3)/3
    moments=np.stack((uniform,uniform*osc/5),axis=-1)
    potential,slope=green(radius,edges,moments,G)
    scale=-4*np.pi*G*osc/5
    log=np.log(edges[-1]/radius)
    assert abs(slope[0]/(4*np.pi*G*radius/3)-1)<1e-12
    assert abs(potential[1]/(scale*radius**2*(1/5+log))-1)<1e-12
    assert abs(slope[1]/(scale*radius*(2*log-3/5))-1)<1e-12
    assert max(float(row["relative"]) for row in rows("green-controls"))<1e-9
    assert max(float(row["uniform_volume_error"]) for row in rows("volume-controls"))<1e-9
    traces=rows("direct-cell-divergence")
    assert len(traces)==18 and all(float(row["relative"])<.005 for row in traces)
    counts=rows("source-counts");continuous=rows("continuous-source-counts")
    modes=rows("continuous-angular-projection");fluxes=rows("force-flux")
    densities=rows("native-density");green_forces=rows("direct-cell-forces");direct=rows("continuous-forces")
    census_point=rows("continuous-source-points");comparisons=[];details=[]
    for case in ("ordinary","reset_forward"):
        primary=only(continuous,case=case,source="transported",order=24)
        radius=primary["radius_kpc"]
        requested=float(primary["mass_Msun"])
        def exact(key):
            return float(only(fluxes,case=case,radius_kpc=radius,source=key,method="native")["fine_Msun"])
        saved=exact("full")
        assert abs(exact("terminal")+exact("increment")-saved)<1e-8
        bin_mass=float(only(counts,case=case,radius_kpc=radius,source="transported",order=48)["volume_mass_Msun"])
        assert requested>0 and bin_mass>0 and abs(requested/bin_mass-1)<.005
        if case=="ordinary":
            assert saved<0 and exact("terminal")<0 and exact("increment")<0
        else:
            assert saved>0
        for key in ("terminal","increment","transported"):
            count=only(continuous,case=case,source=key,order=12)
            other=only(continuous,case=case,source=key,order=24)
            assert abs(float(count["mass_Msun"])/float(other["mass_Msun"])-1)<.005
            coarse=vector(only(green_forces,case=case,order=4,source=key))
            fine=vector(only(green_forces,case=case,order=8,source=key))
            assert max(abs(coarse/fine-1))<.005
            for cap in (0,32,64,68,128,256):
                vals=[float(only(modes,case=case,order=order,source=key,cap=cap)["continuous_mode_density"]) for order in (6,12)]
                assert abs(vals[0]/vals[1]-1)<.005
        for count in (row for row in counts if row["case"]==case and row["order"]=="48"):
            old=only(counts,case=case,order=24,source=count["source"],radius_kpc=count["radius_kpc"])
            for col in ("volume_mass_Msun","shell_mass_Msun"):
                err=abs(float(old[col])-float(count[col]))
                assert err<=.005*abs(float(count[col])) if float(count[col]) else err==0
        def physical_mode(key,cap):
            return float(only(modes,case=case,order=12,source=key,cap=cap)["continuous_mode_density"])
        full_modes=physical_mode("terminal",68)+physical_mode("increment",64)
        native_point=float(only(densities,case=case,source="full",cap=68)["point_density"])
        uncut_point=float(only(census_point,case=case,source="transported")["continuous_density_Msun_kpc3"])
        details.append(dict(case=case,uncut_continuous_density=uncut_point,continuous_mixed_cap_density=full_modes,native_density=native_point,
            relative_unexplained_density_bias=abs((native_point-full_modes)/(native_point-uncut_point)),
            primary_continuous_Msun=requested,positive_cells_Msun=bin_mass,native_Msun=saved,
            mean_normal_force_change_kms2_kpc=-G*(requested-saved)/float(radius)**2,
            min_rms_change_for_any_nonnegative_mass_kms2_kpc=G*max(0.,-saved)/float(radius)**2))
        for key in ("terminal","tapered_terminal","increment","exterior","full"):
            configurations=[(4,80),(8,80),(8,160),(12,160)]
            vectors=[vector(only(direct,case=case,order=order,extent_kpc=extent,source=key)) for order,extent in configurations]
            for earlier,later,stage in zip(vectors,vectors[1:],("rule_4_to_8","extent_80_to_160","rule_8_to_12")):
                error=max(abs(earlier/later-1))
                comparisons.append(dict(case=case,source=key,change=stage,largest_relative_component=error,passes=bool(error<.005)))
            if key in ("full","increment","terminal"):
                if key=="full":
                    cells_source="transported"
                else:
                    cells_source=key
                cell=vector(only(green_forces,case=case,source=cells_source,order=8))
                if key!="increment":
                    cell+=vector(only(direct,case=case,order=12,extent_kpc=160,source="exterior"))
                error=max(abs(cell/vectors[-1]-1))
                comparisons.append(dict(case=case,source=key,change="cell_vs_continuous",largest_relative_component=error,passes=bool(error<.005)))
    table("force-accuracy.csv",comparisons);table("source-verdict.csv",details)
    summary=dict(cell_divergence_checks=len(traces),worst_cell_divergence_relative=max(float(row["relative"]) for row in traces),
        force_checks=len(comparisons),force_misses=[row for row in comparisons if not row["passes"]],
        analytical_green_controls="uniform monopole, constant quadrupole potential and derivative, l=2 exterior logarithm",
        primary_aperture_kpc=float(radius),mixed_caps=dict(terminal=68,increment=64),no_wave_orbit_replaced=True)
    record("validation.json",summary)
    return summary


if __name__=="__main__":
    print(json.dumps(audit(),indent=2))
