from experiment import HOME,LAST,G,arrays,coefficients,green,np,table,record
from gravity import quadrature
from scipy.special import ellipkm1,ellipe,eval_legendre,eval_jacobi


def rings(plane,height,ring,zring):
    top=(plane+ring)**2+(height-zring)**2
    low=(plane-ring)**2+(height-zring)**2
    modulus=4*plane*ring/top
    first=ellipkm1(low/top)
    base=4/np.sqrt(top)
    cosine=((2-modulus)*first-2*ellipe(modulus))/np.where(modulus>0,modulus,1)
    small=modulus<1e-4
    cosine[small]=(np.pi/16)*modulus[small]*(1+.75*modulus[small])
    return base*first,base*cosine


def split_grid(edges,centre,step,order):
    extra=centre+step*np.array([-4.,-1.,-.25,-.06,-.014,0,.014,.06,.25,1.,4.])
    cuts=np.unique(np.r_[edges,extra[(extra>edges[0])&(extra<edges[-1])]])
    points,weights=quadrature(cuts,order)
    return points,weights,np.searchsorted(edges,points)-1


def force(edges,ang,density,plane,height,order):
    distance=np.hypot(plane,height)
    assert plane>0
    abs_mu=abs(height/distance)
    ri=np.searchsorted(edges,distance)-1
    step=edges[min(max(ri+1,1),len(edges)-1)]-edges[min(max(ri,0),len(edges)-2)]
    mu,wm,ai=split_grid(ang,abs_mu,np.diff(ang).min(),order)
    sine=np.sqrt(1-mu**2)
    jump=density-np.concatenate((density[1:],np.zeros_like(density[:1])),axis=0)
    answer=np.zeros((density.shape[-1],2))
    for start in range(0,len(jump),24):
        values=jump[start:start+24]
        radius=edges[1+start:1+start+len(values),None]
        plane_w=np.zeros((len(values),len(mu)));height_w=np.zeros_like(plane_w)
        for sign in (-1,1):
            axial,cos=rings(plane,height,radius*sine,sign*radius*mu)
            plane_w+=cos*sine
            height_w+=axial*(sign*mu)
        for coord,kernel in enumerate((plane_w,height_w)):
            answer[:,coord]+=np.einsum("ijk,ij->k",values[:,ai,:],kernel*(wm*radius**2))
    radius,wr,ix=split_grid(edges,distance,step,order)
    for start in range(0,len(ang)-2,12):
        mu=ang[1:-1][None,start:start+12];sine=np.sqrt(1-mu**2)
        mass=density[ix,start:start+mu.size,:]-density[ix,start+1:start+mu.size+1,:]
        plane_w=np.zeros((len(radius),mu.size));height_w=np.zeros_like(plane_w)
        for sign in (-1,1):
            axial,cos=rings(plane,height,radius[:,None]*sine,sign*radius[:,None]*mu)
            plane_w-=cos*mu
            height_w+=axial*(sign*sine)
        for coord,kernel in enumerate((plane_w,height_w)):
            answer[:,coord]+=np.einsum("ijk,ij->k",mass,kernel*(wr*radius)[:,None]*sine)
    return -G*answer


def modal_force(plane,height,edges,moments):
    radius=np.hypot(plane,height);mu=height/radius;sine=plane/radius
    degrees=2*np.arange(moments.shape[1])
    value,der=green(radius,edges,moments,G)
    radial=-der@eval_legendre(degrees,mu)
    slope=(degrees[1:]+1)*eval_jacobi(degrees[1:]-1,1,1,mu)/2
    polar=sine*(value[1:]@slope)/radius
    return np.array([sine*radial+mu*polar,mu*radial-sine*polar])


def run():
    edges,ang,cells,_=arrays()
    last=np.flatnonzero(cells["terminal"].sum(axis=1)>0)[-1]+1
    edges=edges[:last+1]
    volume=4*np.pi/3*np.diff(edges**3)[:,None]*np.diff(ang)
    keys=("terminal","increment","transported")
    density=np.stack([cells[key][:last]/volume for key in keys],axis=-1)
    controls=[]
    for plane,height in ((.7,.2),(3.9,-.22)):
        ball_radius=2.;mass=4*np.pi/3*ball_radius**3
        expected=-G*mass*np.array([plane,height])/max(ball_radius,np.hypot(plane,height))**3
        observed=force(np.array([0.,.36,1.14,ball_radius]),np.linspace(0,1,12),np.ones((3,11,1)),plane,height,24)[0]
        err=np.linalg.norm(observed-expected)/np.linalg.norm(expected)
        assert err<1e-9,err
        controls.append(dict(case="uniform",plane=plane,height=height,relative=err))
    rows=[];traces=[]
    for case in ("far","ordinary","reset_forward"):
        if case=="far":
            plane,height=48.,36.
        else:
            with np.load(LAST/("hist-4-2-A-"+case+".npz")) as bank:
                xyz=bank["centre"][0,:3]
            plane,height=np.hypot(*xyz[:2]),xyz[2]
        radial=np.hypot(plane,height);mu=abs(height/radial)
        for order in (4,8):
            base=force(edges,ang,density,plane,height,order)
            for idx,key in enumerate(keys):
                rows.append(dict(case=case,order=order,source=key,R=plane,z=height,a_R_kms2_kpc=base[idx,0],a_z_kms2_kpc=base[idx,1]))
                if case=="far" and order==8:
                    other=modal_force(plane,height,edges,coefficients(cells[key][:last],ang,32))
                    err=np.linalg.norm(other-base[idx])/np.linalg.norm(other)
                    assert err<.005
                    controls.append(dict(case="far_"+key,plane=plane,height=height,relative=err))
            if case=="far":
                continue
            ri=np.searchsorted(edges,radial)-1;ai=np.searchsorted(ang,mu)-1
            margin=min(np.min(abs(edges-radial)),radial*np.min(np.abs(np.sin(np.arccos(mu)-np.arccos(ang)))))
            for step in ([min(.001,margin/8)] if order==4 else [min(.001,margin/8),min(.001,margin/8)/2]):
                trace=base[:,0]/plane
                for idx,offset in enumerate(((step,0),(0,step))):
                    up=force(edges,ang,density,plane+offset[0],height+offset[1],order)
                    down=force(edges,ang,density,plane-offset[0],height-offset[1],order)
                    trace+=(up[:,idx]-down[:,idx])/(2*step)
                for idx,key in enumerate(keys):
                    expected=density[ri,ai,idx]
                    inferred=-trace[idx]/(4*np.pi*G)
                    traces.append(dict(case=case,order=order,step_kpc=step,source=key,inferred_density=inferred,
                                       cell_density=expected,relative=abs(inferred/expected-1),passes=bool(abs(inferred/expected-1)<.005)))
    table("direct-cell-forces.csv",rows);table("direct-cell-divergence.csv",traces);table("green-controls.csv",controls)


if __name__=="__main__":
    run()
