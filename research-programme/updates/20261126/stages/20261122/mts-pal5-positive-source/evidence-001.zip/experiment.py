import os
for variable in ("OPENBLAS_NUM_THREADS","OMP_NUM_THREADS","MKL_NUM_THREADS","NUMEXPR_NUM_THREADS","BLIS_NUM_THREADS"):
    os.environ[variable]="1"
import csv
import hashlib
import io
import json
from functools import lru_cache
from pathlib import Path
import numpy as np
from numpy.polynomial import legendre
from scipy.special import eval_legendre
from gravity import coefficients, green, field_flux, modal_mass, source_weights

HOME=Path(__file__).resolve().parent
ROOT=HOME.parent
LAST=ROOT/"mts-pal5-interface-work-20261122"
TIDES=ROOT/"mts-pal5-local-tides-20261122"
FIRE=ROOT/"mts-fire-joint-baryon-history-20261120"
G=4.30091727003628e-6
HASHES={}


def digest(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream,"sha256").hexdigest()


def pin(folder,name,expected):
    path=folder/name
    assert digest(path)==expected,name
    HASHES[str(path.relative_to(ROOT))]=expected
    return path


def get_manifest(folder,expected):
    manifest=json.loads(pin(folder,"seal.json",expected).read_bytes())
    return manifest.get("files",manifest)


def save(name,data):
    path=HOME/name
    if path.exists():
        assert path.read_bytes()==data,name
    else:
        with path.open("xb") as stream:
            stream.write(data)


def record(name,contents):
    save(name,(json.dumps(contents,sort_keys=True,indent=2,allow_nan=False)+"\n").encode())


def table(name,rows):
    stream=io.StringIO()
    writer=csv.DictWriter(stream,fieldnames=list(rows[0]),lineterminator="\n")
    writer.writeheader()
    writer.writerows(rows)
    save(name,stream.getvalue().encode())


def arrays():
    galaxy=get_manifest(FIRE,"19c78eaa158a766bd409c0a64504788b1346542eccee37c004083a918c480d67")
    def source(name):
        return pin(FIRE,name,galaxy[name])
    with np.load(source("mw-positive-aperture.npz")) as bank:
        local=bank["high"]
        low=bank["low"]
    raw={}
    for snap in (586,600):
        phase=[]
        for piece in range(4):
            stem=f"mass-{snap}-{piece}"
            receipt=json.loads(source(stem+".json").read_bytes())
            path=source(stem+".npz")
            assert digest(path)==receipt["bank_sha256"]
            with np.load(path) as bank:
                edges,angles=bank["edges"],bank["mu"]
                phase.append(bank["hist"][:,0])
        raw[snap]=np.sum(phase,axis=0)
        assert np.min(raw[snap])>=0
    middle=(edges[1:]+edges[:-1])/2
    centre=(angles[1:]+angles[:-1])/2
    cuts=edges[[np.argmin(abs(edges-goal)) for goal in (0,.5,1,2,3,4,6,8,10,14,20,25,30)]]
    groups=(np.searchsorted(cuts,middle,side="right")-1)[:,None]*7+np.searchsorted([0,1/32,1/16,1/8,1/4,1/2,3/4,1],centre,side="right")-1
    budgets=[np.bincount(groups.ravel(),weights=raw[snap].sum(axis=0).ravel()) for snap in (586,600)]
    assert budgets[1].min()>0 and groups.max()==90 and local.min()>=0
    gain=(budgets[0]/budgets[1])[groups]
    change=local*(gain-1)
    expected=json.loads(source("forcing-586.json").read_bytes())["joint"]["delta_msun"]
    assert abs(change.sum()/expected-1)<1e-9
    content=dict(terminal=local,increment=change,transported=local*gain,low=low*gain,gas=raw[586][0],stars=raw[586][1])
    assert np.min(content["transported"])>=0
    moments=coefficients(change,angles,64)
    with np.load(source("forcing-586.npz")) as bank:
        sample=[]
        for index in np.linspace(0,len(bank["physical_r"])-1,20,dtype=int):
            value,_=green(bank["physical_r"][index],edges,moments,G,True)
            reference=bank["joint"][index]
            sample.append(np.max(abs(eval_legendre(2*np.arange(len(value)),bank["mu"][:,None])@value-reference))/max(abs(reference)))
    assert max(sample)<1e-9
    with np.load(source("forcing-600.npz")) as bank:
        assert not bank["joint"].any()
    return edges,angles,content,max(sample)


class Native:
    def __init__(self):
        manifest=get_manifest(TIDES,"bebe1235720092e12940481ff83218fc72a2c3be690335e7bd5188eaeb5e9cf5")
        with np.load(pin(TIDES,"native-ordinary.npz",manifest["native-ordinary.npz"])) as bank:
            self.left,self.right=bank["left"],bank["right"]
            initial,terminal=bank["nodes586"],bank["nodes600"]
            design=legendre.legvander(2*bank["knots"]-1,len(bank["knots"])-1)
            self.banks={}
            for key,nodes in (("terminal",terminal),("increment",initial-terminal),("full",initial)):
                value=np.einsum("ij,cjl->cil",np.linalg.inv(design),nodes)
                scale=2/(self.right-self.left)[:,None,None]
                first=legendre.legder(value,axis=1)*scale
                self.banks[key]=(value,first,legendre.legder(first,axis=1)*scale)
    def field(self,key,radius):
        index=np.searchsorted(self.right,radius)
        coord=2*(radius-self.left[index])/(self.right[index]-self.left[index])-1
        value,first,second=[legendre.legval(coord,coeff[index]) for coeff in self.banks[key]]
        return value/radius,(first-value/radius)/radius,second/radius


def run():
    assert not any((folder/"STOP-REQUESTED").exists() for folder in (ROOT,HOME,LAST,FIRE))
    inputs=get_manifest(LAST,"e8891d2372d597e163d1f8de482c0884eac39405223b34e7b9d0eee10f7e2723")
    for name in ("PROTOCOL.md","experiment.py","gravity.py"):
        HASHES[str((HOME/name).relative_to(ROOT))]=digest(HOME/name)
    with pin(LAST,"ordinary-source-gauss-verdict.csv",inputs["ordinary-source-gauss-verdict.csv"]).open() as stream:
        old=list(csv.DictReader(stream))
    edges,angles,cells,replay=arrays()
    native=Native()
    volume_rows=[];mode_rows=[];flux_rows=[];native_rows=[];point_rows=[];checks=[]
    for case in ("ordinary","reset_forward"):
        name="hist-4-2-A-"+case+".npz"
        with np.load(pin(LAST,name,inputs[name])) as bank:
            xyz=bank["centre"][0,:3]
        distance=np.linalg.norm(xyz);cosine=xyz[2]/distance
        row_index=np.searchsorted(edges,distance)-1
        angle_index=np.searchsorted(angles,abs(cosine))-1
        voxel=4*np.pi/3*np.diff(edges**3)[row_index]*np.diff(angles)[angle_index]
        for kind,grid in cells.items():
            point_rows.append(dict(case=case,source=kind,r_kpc=distance,mu=cosine,voxel_volume_kpc3=voxel,
                                   mass_Msun=grid[row_index,angle_index],density=grid[row_index,angle_index]/voxel))
        degrees=2*np.arange(35)
        for key in native.banks:
            value,_,radial=native.field(key,distance)
            terms=(radial-degrees*(degrees+1)*value/distance**2)*eval_legendre(degrees,cosine)/(4*np.pi*G)
            for cap in (0,32,64,66,68):
                native_rows.append(dict(case=case,source=key,cap=cap,point_density=terms[:cap//2+1].sum()))
        supports=[row for row in old if row["centre"]==case and .019<float(row["probe_kpc"])<.06]
        for ref in supports:
            radius=float(ref["probe_kpc"])
            for order in (24,48):
                volumes,weights,shells=source_weights(edges,angles,distance,cosine,radius,order)
                norm=4*np.pi*radius**3/3
                err=abs(volumes.sum()/norm-1);assert err<1e-9,err
                assert weights.min()>=0 and weights.max()<=1 and shells.min()>=0 and shells.max()<=1
                checks.append(dict(case=case,radius_kpc=radius,order=order,uniform_volume_error=err))
                for kind,grid in cells.items():
                    volume_rows.append(dict(case=case,radius_kpc=radius,order=order,source=kind,volume_mass_Msun=np.sum(weights*grid),
                                            shell_mass_Msun=np.sum(shells*grid)))
            for key in native.banks:
                reps=[]
                for order in (16,32):
                    field=lambda dist:native.field(key,dist)[:2]
                    estimate=field_flux(distance,cosine,radius,native.right,field,68,G,order)
                    reps.append(estimate)
                flux_rows.append(dict(case=case,radius_kpc=radius,source=key,method="native",cap=68,coarse_Msun=reps[0],fine_Msun=reps[1]))
                if key=="full":
                    assert abs(estimate/float(ref["effective_enclosed_Msun"])-1)<.005
        for kind in ("terminal","increment","transported"):
            moments=coefficients(cells[kind],angles,256)
            effective=3*moments[row_index]/(4*np.pi*np.diff(edges**3)[row_index])
            dlist=2*np.arange(len(effective))
            point_modes=np.cumsum((2*dlist+1)*effective*eval_legendre(dlist,cosine))
            for ref in supports:
                radius=float(ref["probe_kpc"])
                mass,shell=modal_mass(edges,moments,distance,cosine,radius,24)
                for cap in (0,32,64,68,128,256):
                    mode_rows.append(dict(case=case,radius_kpc=radius,source=kind,cap=cap,point_density=point_modes[cap//2],
                                          volume_mass_Msun=mass[cap//2],shell_mass_Msun=shell[cap//2]))
                if radius==float(supports[0]["probe_kpc"]):
                    for midpoint,breaks in ((False,edges),(True,(edges[1:]+edges[:-1])/2)):
                        selected=np.ascontiguousarray(moments[:,:33])
                        cached=lru_cache(maxsize=256)(lambda dist:green(dist,edges,selected,G,midpoint))
                        fluxes=[field_flux(distance,cosine,radius,breaks,cached,64,G,order) for order in (12,24)]
                        cached.cache_clear()
                        reference=(shell if midpoint else mass)[32]
                        flux_rows.append(dict(case=case,radius_kpc=radius,source=kind,method="mid_shell" if midpoint else "finite_volume",
                                              cap=64,coarse_Msun=fluxes[0],fine_Msun=fluxes[1]))
                        assert abs(fluxes[1]-reference)<1e-7*max(1.,abs(reference)),(kind,case,fluxes[1],reference)
    for name,rows in (("source-counts.csv",volume_rows),("source-modes.csv",mode_rows),("force-flux.csv",flux_rows),
                      ("native-density.csv",native_rows),("cell-centres.csv",point_rows),("volume-controls.csv",checks)):
        table(name,rows)
    record("inputs.json",dict(files=HASHES,midpoint_archive_replay_relative=replay))


if __name__=="__main__":
    run()
