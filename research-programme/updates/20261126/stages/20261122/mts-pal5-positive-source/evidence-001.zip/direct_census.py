import os
for variable in ("OPENBLAS_NUM_THREADS","OMP_NUM_THREADS","MKL_NUM_THREADS","NUMEXPR_NUM_THREADS"):
    os.environ[variable]="1"
import importlib.util
import sys
from pathlib import Path
stage=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location("positive_checkpoint_io",stage/"experiment.py")
io=importlib.util.module_from_spec(spec)
spec.loader.exec_module(io)
from gravity import quadrature
assert Path(sys.modules["gravity"].__file__).resolve()==stage/"gravity.py"
del sys.modules["gravity"]
from scipy.special import eval_legendre
from numpy.polynomial.legendre import legvander
import numpy as np

model=stage.parent/"mts-extended-bar-fixed-occupation-20261120"
for folder,seal,filename in ((model,"04d68be63540458fe12b4016eb0c1f860321cbef03c662c8521b8f611359453a","signed_potential.py"),
    (stage.parent/"mts-extended-bar-redistribution-20261120","0080729d5848aa70f85f8956a672c086f684c10132d8c36aa9dc7454f9c9c171","long_source.py"),
    (stage.parent/"mts-central-bar-force-bound-20261120","a5253d5a3979a32a3548af7d6c4f256aa015ccaa53e64b640ab3bb43e7d12bd0","bar_inputs.py"),
    (stage.parent/"mts-measured-baryon-gravity-20261120","2049a949d65de9077419a1f1ca183d9b5a09da343a9d7bdcf14fd4622c76128e","measured_source.py"),
    (stage.parent/"mts-foreground-occupation-cross-20261120","6bab4f61015a5b4f85a24e6b91b23639f1ca2225af0228086681fce63537fb2b","state-anchorA.npz")):
    manifest=io.get_manifest(folder,seal)
    io.pin(folder,filename,manifest[filename])
    if filename.endswith("npz"):
        with np.load(folder/filename) as state:
            assert state["fraction"].item()==0.
sys.path.insert(0,str(model))
import signed_potential as original
original.guard()
source=original.census()


def density(radial,height):
    radial,height=np.broadcast_arrays(radial,np.abs(height))
    shape=radial.shape
    radial,height=radial.ravel(),height.ravel()
    totals=[]
    phi,weight=quadrature(np.array([0.,np.pi/2]),32)
    for start in range(0,len(radial),2000):
        cyl=radial[start:start+2000];alt=height[start:start+2000]
        columns=original.columns(cyl)
        donors=original.supply(cyl)
        shares=donors/np.maximum(1e-25,donors.sum(axis=1))[:,None]
        transferred=sum(cols*original.zshape(key,alt) for key,cols in zip(original.ls.S22,columns.T))
        removed=columns.sum(axis=1)*sum(shares[:,index]*source.starshape(alt,index) for index in range(4))
        central=source.stars.bmass*(original.ls.old.density("E3",(.67,.29,.27),cyl[:,None]*np.cos(phi),cyl[:,None]*np.sin(phi),alt[:,None])@(weight*2/np.pi))
        totals.append(source.disk(cyl,alt)+transferred-removed+central)
    total=np.concatenate(totals).reshape(shape)
    assert np.all(np.isfinite(total)) and np.min(total)>=0
    return total


def direct_mass(distance,cosine,aperture,order):
    radius,weight=quadrature(np.array([0.,aperture]),order)
    latitude,lat_weight=quadrature(np.array([-1.,1.]),order)
    azimuth=(np.arange(2*order)+.5)*np.pi/order
    plane=distance*np.sqrt(1-cosine**2);height=distance*cosine
    cross=np.sqrt(1-latitude**2)
    total=0.
    for step,measure in zip(radius,weight):
        transverse=step*cross[:,None]
        cyl=np.hypot(plane+transverse*np.cos(azimuth),transverse*np.sin(azimuth))
        total+=2*np.pi*step**2*measure*(lat_weight@density(cyl,height+step*latitude[:,None]).mean(axis=1))
    return total


def projected_point(distance,cosine,groups,order):
    height_knots=source.stars.axis/distance
    radial_knots=np.unique(np.r_[source.radknots,source.stars.centres])
    tilted=np.sqrt(1-(radial_knots[(radial_knots>0)&(radial_knots<distance)]/distance)**2)
    cuts=np.unique(np.r_[np.linspace(0,1,33),height_knots[(height_knots>0)&(height_knots<1)],tilted,[1/32,1/16,1/8,1/4,1/2,3/4]])
    mu,weight=quadrature(cuts,order)
    law=density(distance*np.sqrt(1-mu**2),distance*mu)
    degrees=2*np.arange(129)
    basis=legvander(mu,256)[:,::2]
    factors=(2*degrees+1)*eval_legendre(degrees,cosine)
    multiplier=groups[np.searchsorted([1/32,1/16,1/8,1/4,1/2,3/4],mu)]
    return {name:np.cumsum(((weight*law*factor)@basis)*factors) for name,factor in
            (("terminal",1.),("increment",multiplier-1),("transported",multiplier))}


def run():
    edges,angles,cells,_=io.arrays()
    modes=[];masses=[];points=[]
    controls=io.get_manifest(io.LAST,"e8891d2372d597e163d1f8de482c0884eac39405223b34e7b9d0eee10f7e2723")
    for case in ("ordinary","reset_forward"):
        name="hist-4-2-A-"+case+".npz"
        with np.load(io.pin(io.LAST,name,controls[name])) as data:
            pos=data["centre"][0,:3]
        distance=np.linalg.norm(pos);cosine=pos[2]/distance;row=np.searchsorted(edges,distance)-1
        cuts=np.array([0,1/32,1/16,1/8,1/4,1/2,3/4,1])
        centres=(angles[:-1]+angles[1:])/2;groups=[]
        for low,high in zip(cuts[:-1],cuts[1:]):
            take=(centres>low)&(centres<high)&(cells["terminal"][row]>0)
            ratios=cells["transported"][row,take]/cells["terminal"][row,take]
            assert len(ratios) and np.ptp(ratios)<1e-12
            groups.append(ratios[0])
        groups=np.asarray(groups)
        gain=groups[np.searchsorted(cuts[1:-1],abs(cosine))]
        local=density(np.array([np.hypot(*pos[:2])]),np.array([pos[-1]]))[0]
        for key,factor in (("terminal",1.),("increment",gain-1),("transported",gain)):
            points.append(dict(case=case,source=key,continuous_density_Msun_kpc3=local*factor,local_gain=gain))
        for order in (6,12):
            for key,series in projected_point(distance,cosine,groups,order).items():
                for cap in (0,32,64,68,128,256):
                    modes.append(dict(case=case,source=key,order=order,cap=cap,continuous_mode_density=series[cap//2]))
        aperture=0.019235279276586803
        assert distance+aperture<25
        assert min(abs(np.arccos(abs(cosine))-np.arccos(cuts)))>np.arcsin(aperture/distance)
        radial_bounds=edges[[np.argmin(abs(edges-r)) for r in (0,.5,1,2,3,4,6,8,10,14,20,25,30)]]
        assert min(abs(radial_bounds-distance))>aperture
        for order in (12,24):
            mass=direct_mass(distance,cosine,aperture,order)
            for key,factor in (("terminal",1.),("increment",gain-1),("transported",gain)):
                masses.append(dict(case=case,source=key,order=order,radius_kpc=aperture,mass_Msun=mass*factor))
    io.table("continuous-source-counts.csv",masses)
    io.table("continuous-source-points.csv",points)
    io.table("continuous-angular-projection.csv",modes)
    io.record("census-inputs.json",io.HASHES)


if __name__=="__main__":
    run()
