import direct_census as material
from direct_census import io,np,source,original,quadrature
from scipy.special import ellipkm1,ellipe,eval_legendre,eval_jacobi


def components(plane,height,order,extent,edges,angular,cells):
    thin=source.stars.axis
    mu_faces=np.array([0,1/32,1/16,1/8,1/4,1/2,3/4,1])
    shells=edges[[np.argmin(abs(edges-r)) for r in (0,.5,1,2,3,4,6,8,10,14,20,25,30)]]
    midr=(edges[1:]+edges[:-1])/2
    midmu=(angular[1:]+angular[:-1])/2
    group=np.searchsorted(mu_faces[1:-1],midmu)
    radial=np.searchsorted(shells,midr,side="right")-1
    ratios=np.ones((len(shells),7))
    for ir in range(len(shells)):
        for ia in range(7):
            ix=np.ix_(radial==ir,group==ia)
            den=np.sum(cells["terminal"][ix])
            if den:
                ratios[ir,ia]=np.sum(cells["transported"][ix])/den
    shell_surfaces=np.unique(np.r_[shells,25.,30.])
    azimuth,azw=quadrature(np.array([0.,np.pi/2]),32)
    shifts=np.array([0,.0001,.001,.007,.03,.12,.5,1.5,4.])
    cyl_bounds=np.unique(np.clip(np.r_[0.,extent,np.arange(0,30.1,.75),40.,50.,65.,80.,110.,160.,220.,
        source.radknots,source.stars.centres,shell_surfaces,plane+shifts,plane-shifts,
        abs(height)*np.sqrt(1-mu_faces[1:-1]**2)/mu_faces[1:-1],
        np.sqrt(np.maximum(0,shell_surfaces**2-height**2))],0,extent))
    cyl,cyl_w=quadrature(cyl_bounds,order)
    extended=original.columns(cyl)*(cyl<30)[:,None]
    donors=original.supply(cyl)
    shares=donors/np.maximum(1e-25,donors.sum(axis=1))[:,None]
    z_base=np.r_[0.,thin[::8],source.stars.H,np.geomspace(.0008,extent,44),extent,
                 abs(height)+shifts,abs(height)-shifts,4.,5.,8.,12.,16.,24.,40.,60.,80.]
    out=np.zeros((4,3))
    for idx,(dist,rad_weight) in enumerate(zip(cyl,cyl_w)):
        zcuts=np.unique(np.clip(np.r_[z_base,np.sqrt(np.maximum(0,shell_surfaces**2-dist**2)),
            dist*mu_faces[1:-1]/np.sqrt(1-mu_faces[1:-1]**2)],0,extent))
        alt,weights=quadrature(zcuts,order)
        stellar=sum(col*original.zshape(key,alt) for key,col in zip(original.ls.S22,extended[idx]))
        removed=extended[idx].sum()*sum(shares[idx,j]*source.starshape(alt,j) for j in range(4))
        centre=source.stars.bmass*(original.ls.old.density("E3",(.67,.29,.27),dist*np.cos(azimuth),dist*np.sin(azimuth),alt[:,None])@(azw*2/np.pi))
        density=source.disk(np.array([dist]),alt)+stellar-removed+centre
        assert density.min()>=0
        radius=np.hypot(dist,alt)
        taper=np.clip((30-radius)/5,0,1)
        gain=ratios[np.searchsorted(shells,radius,side="right")-1,np.searchsorted(mu_faces[1:-1],alt/radius)]
        volume_density=density[:,None]*np.stack((np.ones_like(alt),taper,(1-taper),taper*(gain-1)),axis=1)
        scale=rad_weight*dist*weights
        radial_kernel=np.zeros_like(alt);vertical_kernel=np.zeros_like(alt);potential=np.zeros_like(alt)
        for signed in (alt,-alt):
            separation=height-signed
            low=(plane-dist)**2+separation**2
            high=(plane+dist)**2+separation**2
            first=ellipkm1(low/high);second=ellipe(4*plane*dist/high)
            factor=-2*io.G/np.sqrt(high)
            radial_kernel+=factor*(first+(plane**2-dist**2-separation**2)*second/low)/plane
            vertical_kernel+=factor*2*separation*second/low
            potential+=factor*2*first
        out+=volume_density.T@(scale[:,None]*np.column_stack((radial_kernel,vertical_kernel,potential)))
    assert np.allclose(out[0],out[1]+out[2],rtol=1e-10,atol=1e-10)
    return np.vstack((out,out[0]+out[3]))


def run():
    edges,angular,cells,_=io.arrays()
    keys=("terminal","tapered_terminal","exterior","increment","full")
    native=io.Native()
    rows=[];contrasts=[]
    for case in ("ordinary","reset_forward"):
        with np.load(io.LAST/("hist-4-2-A-"+case+".npz")) as bank:
            xyz=bank["centre"][0,:3]
        plane,height=np.hypot(*xyz[:2]),xyz[2];radius=np.hypot(plane,height)
        direction=height/radius;sine=plane/radius
        orders=2*np.arange(35)
        native_acc={}
        for key in ("terminal","increment","full"):
            value,der,_=native.field(key,radius)
            radial=-der@eval_legendre(orders,direction)
            polar=sine/radius*(value[1:]@((orders[1:]+1)/2*eval_jacobi(orders[1:]-1,1,1,direction)))
            native_acc[key]=np.array([radial*sine+polar*direction,radial*direction-polar*sine])
        for order,extent in ((4,80),(8,80),(8,160),(12,160)):
            values=components(plane,height,order,extent,edges,angular,cells)
            for key,vector in zip(keys,values):
                rows.append(dict(case=case,order=order,extent_kpc=extent,source=key,a_R_kms2_kpc=vector[0],a_z_kms2_kpc=vector[1],phi_kms2=vector[2]))
                if order==12 and key in native_acc:
                    fixed=native_acc[key]
                    contrasts.append(dict(case=case,source=key,native_R=fixed[0],native_z=fixed[1],continuous_R=vector[0],continuous_z=vector[1],
                        relative_norm_difference=np.linalg.norm(vector[:2]-fixed)/np.linalg.norm(vector[:2])))
        print(case,"quadrature complete",flush=True)
    io.table("continuous-forces.csv",rows);io.table("native-continuous-forces.csv",contrasts)


if __name__=="__main__":
    run()
