import numpy as np
from scipy.special import eval_legendre, eval_jacobi, roots_legendre


def quadrature(edges, order, smooth=False):
    nodes, weights = roots_legendre(order)
    if smooth:
        weights = weights * np.cos(np.pi * nodes / 2) * np.pi / 2
        nodes = np.sin(np.pi * nodes / 2)
    widths = np.diff(edges)[:, None] / 2
    return (edges[:-1, None] + widths * (1 + nodes)).ravel(), (widths * weights).ravel()


def coefficients(mass, angles, degree):
    degrees = np.arange(0, degree + 1, 2)
    table = np.polynomial.legendre.legvander(angles, degree+1)
    basis = np.ones((len(angles)-1, len(degrees)))
    basis[:, 1:] = np.diff(table[:, degrees[1:]+1] - table[:, degrees[1:]-1],axis=0) / (np.diff(angles)[:,None]*(2*degrees[1:]+1))
    return mass @ basis


def green(radius, edges, moments, gravity, midpoint=False):
    lower, upper = edges[:-1], edges[1:]
    degree = 2*np.arange(moments.shape[1])
    if midpoint:
        mid = (lower + upper)/2
        kernel = (np.minimum(mid/radius,radius/mid)[:,None]**degree)/np.maximum(mid,radius)[:,None]
        inside = (kernel[mid<radius]*moments[mid<radius]).sum(axis=0)
        outside = (kernel[mid>=radius]*moments[mid>=radius]).sum(axis=0)
    else:
        density = moments * (3/((upper-lower)*(upper**2+upper*lower+lower**2)))[:,None]
        mask = lower < radius
        top = np.minimum(upper[mask],radius)[:,None]
        inner = top**3/radius*(top/radius)**degree*(1-(lower[mask,None]/top)**(degree+3))/(degree+3)
        inside = (density[mask]*inner).sum(axis=0)
        mask = upper > radius
        bottom = np.maximum(lower[mask],radius)[:,None]
        ratio = np.log(upper[mask,None]/bottom)
        power = 2-degree
        factor = np.expm1(ratio*power)/np.where(power!=0,power,1)
        factor[:,power==0]=ratio
        outer = bottom**2*(radius/bottom)**degree*factor
        outside = (density[mask]*outer).sum(axis=0)
    return -gravity*(inside+outside), gravity*((degree+1)*inside-degree*outside)/radius


def radial_breaks(edges, angles, distance, cosine, aperture):
    low, high = distance-aperture, distance+aperture
    delta = np.arccos(np.r_[-angles[:0:-1],angles]) - np.arccos(cosine)
    disc = aperture**2-(distance*np.sin(delta))**2
    allowed = (disc>0) & (np.cos(delta)>0)
    foot = distance*np.cos(delta[allowed])
    extras = np.r_[foot-np.sqrt(disc[allowed]),foot+np.sqrt(disc[allowed]),edges]
    return np.unique(np.r_[low,extras[(extras>low)&(extras<high)],high])


def fractions(radius,distance,cosine,aperture,angles,order):
    half = (aperture**2-(radius-distance)**2)/(4*radius*distance)
    if half <= 0:
        return np.zeros(len(angles)-1)
    alpha = 2*np.arcsin(np.sqrt(half))
    centre = np.arccos(cosine)
    assert alpha < min(centre,np.pi-centre)
    low, high = np.cos(centre+alpha), np.cos(centre-alpha)
    bounds = np.r_[-angles[:0:-1],angles]
    grid, weights = quadrature(np.r_[low,bounds[(bounds>low)&(bounds<high)],high],order,True)
    theta = np.arccos(grid)
    chord = (half-np.sin((theta-centre)/2)**2)/(np.sin(theta)*np.sin(centre))
    covered = (2/np.pi)*np.arcsin(np.sqrt(np.clip(chord,0,1)))
    return np.bincount(np.searchsorted(angles,abs(grid))-1,weights=weights*covered,minlength=len(angles)-1)


def source_weights(edges,angles,distance,cosine,aperture,order):
    radii, weights = quadrature(radial_breaks(edges,angles,distance,cosine,aperture),order,True)
    matrix=np.zeros((len(edges)-1,len(angles)-1))
    for radius,weight in zip(radii,weights):
        index=np.searchsorted(edges,radius)-1
        matrix[index]+=2*np.pi*radius**2*weight*fractions(radius,distance,cosine,aperture,angles,order)
    volume=(4*np.pi/3)*np.diff(edges**3)[:,None]*np.diff(angles)
    shell_weights=np.zeros_like(matrix)
    for index,radius in enumerate((edges[1:]+edges[:-1])/2):
        if abs(radius-distance)<aperture:
            shell_weights[index]=fractions(radius,distance,cosine,aperture,angles,order)/(2*np.diff(angles))
    return matrix, matrix/volume, shell_weights


def cap_average(radius,distance,cosine,aperture,degrees):
    width = (aperture**2-(radius-distance)**2)/(2*radius*distance)
    boundary = 1-width
    average = np.ones(len(degrees))
    nonzero = degrees[1:]
    average[1:] = (1+boundary)/(2*nonzero)*eval_jacobi(nonzero-1,1,1,boundary)
    return width/2*average*eval_legendre(degrees,cosine)*(2*degrees+1)


def modal_mass(edges,moments,distance,cosine,aperture,order):
    degree = 2*np.arange(moments.shape[1])
    lower,upper=distance-aperture,distance+aperture
    radii,weights=quadrature(np.r_[lower,edges[(edges>lower)&(edges<upper)],upper],order)
    volume=np.diff(edges**3)
    result=np.zeros(len(degree));shell=np.zeros_like(result)
    for radius,weight in zip(radii,weights):
        index=np.searchsorted(edges,radius)-1
        result+=3*radius**2*weight/volume[index]*cap_average(radius,distance,cosine,aperture,degree)*moments[index]
    for index,radius in enumerate((edges[:-1]+edges[1:])/2):
        if abs(radius-distance)<aperture:
            shell+=cap_average(radius,distance,cosine,aperture,degree)*moments[index]
    return np.cumsum(result),np.cumsum(shell)


def field_flux(distance,cosine,aperture,breaks,field,degree,gravity,order):
    marks=breaks[(breaks>distance-aperture)&(breaks<distance+aperture)]
    splits=np.r_[-1,((marks-distance)*(marks+distance)-aperture**2)/(2*distance*aperture),1]
    along,weights=quadrature(splits,order)
    azimuth=(np.arange(2*order)+.5)*np.pi/order
    degrees=np.arange(0,degree+1,2)
    mass=0.
    for axis,weight in zip(along,weights):
        normal_z=cosine*axis+np.sqrt((1-cosine**2)*(1-axis**2))*np.cos(azimuth)
        radius=np.sqrt(distance**2+aperture**2+2*distance*aperture*axis)
        mu=(distance*cosine+aperture*normal_z)/radius
        projection=(distance*axis+aperture)/radius
        value,deriv=field(radius)
        basis=eval_legendre(degrees,mu[:,None])
        slope=(degrees[1:]+1)/2*eval_jacobi(degrees[1:]-1,1,1,mu[:,None])
        projected=projection*(basis@deriv)+(normal_z-mu*projection)*(slope@value[1:])/radius
        mass+=weight*projected.mean()/2
    return aperture**2*mass/gravity
