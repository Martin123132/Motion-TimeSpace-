from mesh_fd import *
from wave_response import archived
from local_release_field import LocalField
DURATION=88.968349
def lap_force(surface,pos,direction=None):
    force=sample(surface,pos)
    if direction is None:return force
    r=np.linalg.norm(pos,axis=1);er=pos/r[:,None];mu=er[:,2];m=abs(mu);sg=np.sign(mu);v=(np.array([0,0,1])-mu[:,None]*er)*sg[:,None]/r[:,None]
    dr=np.sum(direction*er,axis=1);dm=np.sum(direction*v,axis=1)
    dep=(direction-dr[:,None]*er)/r[:,None];dv=-(v*dr[:,None]+er*dm[:,None]+m[:,None]*dep)/r[:,None]
    grad=lambda a,b:surface.ev(r,m,dx=a,dy=b)
    rr,rm,mm=grad(2,0),grad(1,1),grad(0,2)
    jac=-(er*(rr*dr+rm*dm)[:,None]+v*(rm*dr+mm*dm)[:,None]+dep*grad(1,0)[:,None]+dv*grad(0,1)[:,None])
    return force,jac
class Fields:
    def __init__(self,history,mode):
        with np.load(history) as data:
            self.t=data["times"]; make=lambda v:RectBivariateSpline(data["r"],data["mu"],v,kx=3,ky=3,s=0)
            self.wave=[make(z) for z in data["wave"]];self.dw=[make(z) for z in data["difference"]]
            self.host=make(data["old"]+data["change"]);self.slope=make(data["slope"])
        self.mode=mode;self.patch=LocalField("small",14,32) if mode=="direct" else None
    def at(self,t,pos,dx):
        idx=int(np.clip(np.searchsorted(self.t,t)-1,0,len(self.t)-3));ix=np.arange(idx,idx+3)
        x=(t-self.t[idx])/(self.t[idx+1]-self.t[idx])
        weights=((x-1)*(x-2)/2,x*(2-x),x*(x-1)/2)
        if self.patch:
            base=self.patch.force(t/DURATION,pos)
            norm=np.linalg.norm(dx,axis=1)
            safe=np.where(norm>0,norm,1.);off=dx/safe[:,None]*.00005
            jac=(self.patch.force(t/DURATION,pos+off)-self.patch.force(t/DURATION,pos-off))*(norm/.0001)[:,None]
        else:
            base,jac=lap_force(self.host,pos,dx);add,da=lap_force(self.slope,pos,dx)
            base+=t*add;jac+=t*da
        live=np.zeros_like(dx)
        for j,weight in zip(ix,weights):
            if abs(weight)<1e-15:continue
            b,d=lap_force(self.wave[j],pos,dx);base+=weight*b;jac+=weight*d
            live+=weight*sample(self.dw[j],pos+dx)
        return base*CONV**2,jac*CONV**2,live*CONV**2
def energies(y):
    pos,vel,dx,dv=y[:,:3],y[:,3:6],y[:,6:9],y[:,9:12]
    x=pos[1:]-pos[0];v=vel[1:]-vel[0];a=dx[1:]-dx[0];b=dv[1:]-dv[0]
    rr=np.sum(x*x,axis=1)+SIZE**2
    term=np.sum(a*(2*x+a),axis=1)/rr
    return (np.sum((v+b/2)*b,axis=1)-archived.GM/np.sqrt(rr)*np.expm1(-.5*np.log1p(term)))/CONV**2
def rhs(fields,t,y):
    pos,vel,dx,dv=y[:,:3],y[:,3:6],y[:,6:9],y[:,9:12]
    old,shift,extra=fields.at(t,pos,dx);out=np.zeros_like(y)
    out[:,:3]=vel;out[:,6:9]=dv;out[:,3:6]=old;out[:,9:12]=shift+extra
    x=pos[1:]-pos[0];a=dx[1:]-dx[0];v=vel[1:]-vel[0];b=dv[1:]-dv[0]
    rr=np.sum(x*x,axis=1)+SIZE**2
    strength=-archived.GM/rr**1.5
    fac=np.expm1(-1.5*np.log1p(np.sum(a*(2*x+a),axis=1)/rr))
    out[1:,3:6]+=strength[:,None]*x
    out[1:,9:12]+=strength[:,None]*(a+(x+a)*fac[:,None])
    out[1:,12]=np.sum((v+b)*(extra[1:]-extra[0]),axis=1)/CONV**2
    out[1:,13]=(np.sum((v+b)*(shift[1:]-shift[0]),axis=1)+np.sum(b*(old[1:]-old[0]),axis=1))/CONV**2
    return out
def run(path,sub,mode,shell=1):
    f=Fields(HOME/path,mode)
    with np.load(pin("stellar-input.npz")) as stars:
        take=slice(24*(shell-1),24*shell);assert shell in (1,2,3) and np.all(stars["keys"][take,0]==shell)
        selected=stars["indices"][take];pos=np.vstack((CENTER,stars["pos"][selected]));v=stars["velocity"][take]
    with np.load(previous.pin(previous.WORK,"hist-4-2-A-reset_forward.npz")) as bank:
        head=bank["centre"][0]
    er=np.r_[head[:2]/np.hypot(*head[:2]),0.];ep=np.array([-er[1],er[0],0.])
    bulk=head[3:]@np.stack((er,ep,[0.,0.,1.])).T
    y=np.zeros((25,14));y[:,:3]=pos;y[:,3:6]=bulk;y[1:,3:6]+=v
    results=[];individual=[]
    for i,(start,end) in enumerate(zip(f.t[:-1],f.t[1:])):
        guard();h=(end-start)/sub
        for j in range(sub):
            t=start+h*j
            a=rhs(f,t,y);b=rhs(f,t+h/2,y+h*a/2);c=rhs(f,t+h/2,y+h*b/2);d=rhs(f,t+h,y+h*c)
            y+=h*(a+2*b+2*c+d)/6
        de=energies(y);odd=(de[1::2]-de[::2])/2;ev=(de[1::2]+de[::2])/2
        live=y[1:,12];other=y[1:,13];mw=np.mean((live[1::2]+live[::2])/2)
        balance=(de-live-other);res=abs(.5*(balance[1::2]+balance[::2])).max()
        pred=np.mean(ev)*24/end**4
        results.append(dict(year=end*1e6,energy_mean=np.mean(ev),fourth_readout=pred,work_fourth=mw*24/end**4,
             odd_rms=np.linalg.norm(odd)/np.sqrt(len(odd)),max_even_balance_over_mean=res/max(abs(np.mean(ev)),1e-300),
             max_paired_displacement_kpc=np.linalg.norm(y[:,6:9],axis=1).max()))
        for k,(raw,a1,a2) in enumerate(zip(de,live,other)):
            individual.append(dict(year=end*1e6,star=k,energy=raw,wave_work=a1,other_work=a2))
    out=path.removeprefix("history-").removesuffix(".npz")+f"-s{sub}-{mode}"+("" if shell==1 else f"-shell{shell}")
    table("stellar-"+out+".csv",results);table("individual-"+out+".csv",individual)
    print(out,results[-1],flush=True)
if __name__=="__main__":run(sys.argv[1],int(sys.argv[2]),sys.argv[3],int(sys.argv[4]) if len(sys.argv)>4 else 1)
