from finite_stars import *
def run(level,order,steps,key,branch):
    path=f"history-{level}-{order}-{steps}-{key}-32-{branch}.npz"
    fields=Fields(HOME/path,"direct")
    with np.load(pin("stellar-input.npz")) as inp:
        pos=np.vstack((CENTER,inp["pos"][inp["indices"][:24]]));v=inp["velocity"][:24]
    zero=np.zeros_like(pos);direc=np.vstack((np.zeros(3),v))
    common=fields.at(0,pos,zero)[0];b=common[1:]-common[0]
    x=pos[1:]-pos[0];cluster=-archived.GM*x/(np.sum(x*x,axis=1)+SIZE**2)[:,None]**1.5
    values=[]
    for spline in fields.dw:
        raw,jv=lap_force(spline,pos,direc);d=raw[1:]-raw[0]
        values.append((np.mean(np.sum(v*jv[1:],axis=1)),np.mean(np.sum(b*d,axis=1)),np.mean(np.sum(cluster*d,axis=1))))
    values=np.array(values);out=[];area=np.zeros(3)
    frozen=[r for r in read(pin("paired-energy-12-15-612-18-small.csv")) if r["state"]==key and r["shell"]=="1" and r["h_pc"]=="0.3"]
    means=lambda name:np.mean([float(r[name]) for r in frozen])
    gf=means("gradient_term");ef=4*means("existing_force_work_fourth");kf=means("cluster_energy_fourth")-gf-ef
    real=read(HOME/path.replace("history-","stellar-").replace(".npz","-s2-direct.csv"))
    nd,w=gauss(3)
    for i,(start,end) in enumerate(zip(fields.t[:-1],fields.t[1:])):
        j=min(i,len(fields.t)-3)
        for t,wt in zip(start+(end-start)*(1+nd)/2,w*(end-start)/2):
            u=(t-fields.t[j])/(fields.t[j+1]-fields.t[j]);weights=np.array([(u-1)*(u-2)/2,u*(2-u),u*(u-1)/2])
            g,ext,cl=weights@values[j:j+3];area+=wt*np.array([t*g,ext,t*cl])
        gradient,external,clust=24/end**4*area*np.array([1,end,1])
        true=float(real[i]["fourth_readout"]);remainder=true-(gradient+external+clust)
        out.append(dict(year=end*1e6,gradient=gradient,external=external,cluster=clust,remainder=remainder,full=true,
                      gradient_departure=gradient-gf,external_departure=external-ef,cluster_departure=clust-kf,
                      total_departure=true-(gf+ef+kf),birth_site_reconstruction_error=abs(remainder/true)))
    table(path.replace("history-","terms-").replace(".npz",".csv"),out)
if __name__=="__main__":run(*map(int,sys.argv[1:4]),*sys.argv[4:])
