from finite_wave import *
def checks():
    out=[]
    for count in (64,128,256):
        s=Space(np.linspace(0,4,count+1),np.linspace(0,1,count//2+1))
        nd,wt=gauss(12);r=s.rf[:-1,None]+s.dr[:,None]*(1+nd)/2
        m=s.mf[:-1,None]+s.dm[:,None]*(1+nd)/2
        for ell in (0,2):
            h=lg.legvander(m.ravel(),ell)[:,-1].reshape(m.shape)@(wt/2)
            source=np.maximum(1-r*r,0)**3*r**ell
            mass=s.dr*((source*r*r)@(wt/2));v=s.poisson(4*np.pi*mass[:,None]*h)
            rr=s.r;u=np.minimum(rr,1.);inside=np.zeros_like(u);ex=np.zeros_like(u)
            for j,coeff in enumerate((1,-3,3,-1)):
                power=ell+2*j;inside+=coeff*u**(ell+power+3)/(ell+power+3);ex+=coeff*(1-u**(power-ell+2))/(power-ell+2)
            ph=-4*np.pi/(2*ell+1)*(rr**(-ell-1)*inside+rr**ell*ex)
            target=ph[:,None]*lg.legvander(s.mu,ell)[:,-1]
            mask=rr>1.5
            out.append(dict(check="isolated_l"+str(ell),grid=count,relative=l2(v-target)/l2(target),exterior_relative=l2(v[mask]-target[mask])/l2(target[mask])))
    assert all(row["relative"]<.005 and row["exterior_relative"]<.005 for row in out if row["grid"]==256)
    s=Space(np.linspace(0,2,65),np.linspace(0,1,41))
    r=s.r[:,None];mu=s.mu;k=1.6;t=.00035
    first=np.sin(np.pi*r/2)*np.ones_like(mu)+0j;diff=np.zeros_like(first)
    kin=Kinetic(s,k,t);net=np.zeros_like(first.real)
    p,a=kin.radial(first,diff,net);p,a=kin.angular(p,a,net);p,a=kin.radial(p,a,net)
    ev=-4*np.sin(np.pi/2*s.dr[0]/2)**2/s.dr[0]**2
    ratio=(1+.25j*k*t/2*ev)/(1-.25j*k*t/2*ev)
    assert l2(p-first*ratio**2)/l2(first)<1e-13 and np.max(abs(net))==0
    old=first*np.exp(.17j*r*mu);change=old*np.expm1(.02j*(r*mu**2+.1*r**2))
    net=2*(old.conj()*change).real+abs(change)**2
    v,b=kin.radial(old,change,net);v,b=kin.angular(v,b,net);v,b=kin.radial(v,b,net)
    exact=2*(v.conj()*b).real+abs(b)**2
    err=l2(exact-net)/l2(exact);assert err<1e-9
    back=Kinetic(s,k,-t);v,b=back.radial(v,b,net);v,b=back.angular(v,b,net);v,b=back.radial(v,b,net)
    assert l2(v-old)/l2(old)<1e-13 and l2(b-change)/l2(change)<1e-13
    aa,bb=kick(old,change,r*mu,mu*r*r,.01j);cc,dd=kick(old,change,r*mu+3,mu*r*r+5,.01j)
    assert l2(aa-cc)/l2(aa)<1e-14 and l2(bb-dd)/l2(bb)<1e-13
    table("analytic-poisson.csv",out);record("analytic-wave.json",dict(cayley_relative=l2(p-first*ratio**2)/l2(first),nontrivial_flux_relative=err,return_relative=l2(b-change)/l2(change)))
if __name__=="__main__":checks()
