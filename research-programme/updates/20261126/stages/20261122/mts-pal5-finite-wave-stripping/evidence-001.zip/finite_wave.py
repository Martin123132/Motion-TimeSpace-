from mesh_fd import *
from scipy.linalg.lapack import zgttrf,zgttrs
from scipy.interpolate import RectBivariateSpline
from types import SimpleNamespace
DURATION=88.968349
class Kinetic:
    def __init__(self,space,kappa,dt):
        self.s=space;self.kappa=kappa;self.dt=dt
        r,m=space.r,space.mu;dr,dm=space.dr,space.dm;rf,mf=space.rf,space.mf
        self.ks=1/np.diff(r);self.km=(1-mf[1:-1]**2)/np.diff(m)
        self.kr=1j*kappa*(dt/2)/4;self.ka=1j*kappa*dt/(4*r[:,None]**2)
        lo=-self.kr*self.ks/dr[1:];hi=-self.kr*self.ks/dr[:-1]
        di=1+self.kr*(np.r_[2/dr[0],self.ks]+np.r_[self.ks,2/dr[-1]])/dr
        *self.rad,success=zgttrf(lo,di,hi);assert success==0
        self.al=-self.ka*self.km/dm[None,1:];upper=-self.ka*self.km/dm[None,:-1]
        self.ad=1+self.ka*(np.r_[0.,self.km]+np.r_[self.km,0.])/dm
        for j in range(1,len(m)):
            self.al[:,j-1]/=self.ad[:,j-1]
            self.ad[:,j]-=self.al[:,j-1]*upper[:,j-1]
        self.up=upper;self.ad=1/self.ad
    def radial(self,p,a,net):
        mids=[]
        for v in (p,a):
            mid,success=zgttrs(*self.rad,v);assert success==0
            mids.append(mid)
        u,d=mids
        flux=self.kappa*self.ks[:,None]*np.imag(u[:-1].conj()*d[1:]+d[:-1].conj()*(u[1:]+d[1:]))
        amount=(self.dt/2)*flux
        net[:-1]-=amount/self.s.dr[:-1,None];net[1:]+=amount/self.s.dr[1:,None]
        return 2*u-p,2*d-a
    def angular(self,p,a,net):
        mids=[]
        for v in (p,a):
            mid=np.array(v,order="F")
            for j in range(1,mid.shape[1]):mid[:,j]-=self.al[:,j-1]*mid[:,j-1]
            mid[:,-1]*=self.ad[:,-1]
            for j in reversed(range(mid.shape[1]-1)):mid[:,j]=(mid[:,j]-self.up[:,j]*mid[:,j+1])*self.ad[:,j]
            mids.append(mid)
        u,d=mids
        flux=self.kappa*self.km/self.s.r[:,None]**2 *np.imag(u[:,:-1].conj()*d[:,1:]+d[:,:-1].conj()*(u[:,1:]+d[:,1:]))
        amt=self.dt*flux;net[:,:-1]-=amt/self.s.dm[:-1];net[:,1:]+=amt/self.s.dm[1:]
        return 2*u-p,2*d-a

def kick(p,a,common,delta,phase):
    mid=(len(common)//2,0)
    inc=np.expm1(phase*(delta-delta[mid]))
    unit=np.exp(phase*(common-common[mid]))
    return unit*p,unit*(a+(p+a)*inc)
def l2(x):return np.linalg.norm(x.ravel())
def run(level,order,steps,key,years,null="physical"):
    guard()
    with np.load(HOME/f"drives-{level}-{order}.npz") as inp:
        s=Space(inp["rf"],inp["mf"]);kappa=float(inp["kappa"]);p=inp[key]
        old=inp["old586"];dold=(inp["old590"]-old)/DURATION
        change=inp["delta586"];dchange=(inp["delta590"]-change)/DURATION
    if null=="equal":change=np.zeros_like(change);dchange=change
    elif null=="empty":p=np.zeros_like(p)
    elif null=="held":dold=np.zeros_like(dold);dchange=np.zeros_like(dchange)
    else:assert null in ("physical","one_way")
    a=np.zeros_like(p);net=np.zeros_like(p.real)
    dt=years*1e-6/steps;kin=Kinetic(s,kappa,dt)
    weights=s.dr[:,None]*s.dm
    norm=np.sum(weights*abs(p)**2)
    rr=np.flatnonzero(abs(s.r-np.linalg.norm(CENTER))<.095)
    mm=np.flatnonzero(abs(s.mu-abs(CENTER[2])/np.linalg.norm(CENTER))<.010)
    idx=np.ix_(rr,mm);makephi=lambda n:s.poisson(4*np.pi*G*s.dr[:,None]*n)
    w=makephi(abs(p)**2);dw=np.zeros_like(w);phase=-.5j*dt*CONV**2/kappa
    oldparts=[w[idx]];parts=[dw[idx]];checks=[]
    for stage in range(1,steps+1):
        guard();lo=dt*(stage-1);hi=dt*stage
        p,a=kick(p,a,old+dold*lo+w,change+dchange*lo+(dw if null!="one_way" else 0.),phase)
        p,a=kin.radial(p,a,net);p,a=kin.angular(p,a,net);p,a=kin.radial(p,a,net)
        w=makephi(abs(p)**2);dw=makephi(net)
        p,a=kick(p,a,old+dold*hi+w,change+dchange*hi+(dw if null!="one_way" else 0.),phase)
        observed=(2*(p.conj()*a).real+abs(a)**2)
        denom=l2(net[idx])
        checks.append(dict(step=stage,time_year=hi*1e6,old_mass_relative=abs(np.sum(weights*abs(p)**2)-norm)/max(norm,1.),
                     difference_mass_signed=np.sum(weights*net)*4*np.pi,
                     difference_conservation=abs(np.sum(weights*net))/max(np.sum(weights*abs(net)),1e-300),
                     current_agreement=l2((observed-net)[idx])/denom if denom else l2(observed[idx]),
                     max_force_potential=np.max(abs(dw[idx]))))
        assert np.isfinite(dw).all() and checks[-1]["old_mass_relative"]<1e-10
        parts.append(dw[idx]);oldparts.append(w[idx])
    tag=f"{level}-{order}-{steps}-{key}-{years:g}-{null}"
    table("continuity-"+tag+".csv",checks)
    packet("history-"+tag+".npz",r=s.r[rr],mu=s.mu[mm],times=np.linspace(0.,dt*steps,steps+1),wave=np.array(oldparts),difference=np.array(parts),old=np.array(old[idx]),change=np.array(change[idx]),slope=(dold+dchange)[idx])
    print(tag,checks[-1],flush=True)
if __name__=="__main__":run(*map(int,sys.argv[1:4]),sys.argv[4],float(sys.argv[5]),*sys.argv[6:])
