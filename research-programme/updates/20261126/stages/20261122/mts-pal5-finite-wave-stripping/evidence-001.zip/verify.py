from finite_io import HOME, VECTOR, manifest, KEYS, np, sha, read, record
import json, re, sys
from urllib.parse import unquote

def verify(seal=False):
    for name, expected in manifest.items():
        assert sha(VECTOR/name)==expected,name
    assert not (HOME/"__pycache__").exists()
    for path in HOME.glob("*.py"):
        compile(path.read_bytes(),str(path),"exec")
    for path in HOME.glob("*.md"):
        for link in re.findall(r"\]\(([^)]+)\)",path.read_text(encoding="utf-8")):
            if not link.startswith("https://"):assert (HOME/unquote(link)).is_file(),link
    for path in HOME.glob("*.csv"):
        rows=read(path)
        assert rows and all(None not in row and all(x is not None for x in row.values()) for row in rows),path
    for path in HOME.glob("*.npz"):
        with np.load(path,allow_pickle=False) as data:
            for name in data.files:assert np.isfinite(data[name]).all(),(path,name)
    for path in HOME.glob("continuity-*.csv"):
        rows=read(path)
        assert max(float(r["old_mass_relative"]) for r in rows)<1e-10
        assert max(float(r["difference_conservation"]) for r in rows)<1e-9
        assert max(float(r["current_agreement"]) for r in rows)<.005
    for null in ("empty","equal"):
        with np.load(HOME/f"history-1-3-8-reset_forward-32-{null}.npz") as data:
            assert not data["difference"].any()
            assert data["wave"].any()==(null=="equal")
        assert all(float(r["energy_mean"])==float(r["odd_rms"])==float(r["work_fourth"])==0 for r in read(HOME/f"stellar-1-3-8-reset_forward-32-{null}-s2-direct.csv"))
    for shell in (1,2,3):
        rows=read(HOME/f"window-measurements-{shell}.csv")
        cells={(r["state"],float(r["year"]),r["quantity"]) for r in rows}
        assert len(cells)==len(rows)==32
        assert all(float(r["energy_mean"])<0 and r["numerics_pass"]=="True" for r in rows)
        gates=read(HOME/f"numerical-gates-{shell}.csv")
        assert len(gates)==160 and all(r["passes"]=="True" for r in gates)
        assert set(KEYS)=={r["state"] for r in rows}
    empirical=json.loads((HOME/"decision.json").read_bytes())
    assert empirical["individual_targets"]==72 and empirical["bracketed"]==68
    assert empirical["largest_gradient_error_units"]<1 and empirical["largest_one_bin_error_units"]<1
    assert empirical["fourth_energy_pass_by_shell_and_year"]==[[4,4,4,0],[4,4,4,4],[4,4,4,4]]
    files={p.name:sha(p) for p in sorted(HOME.iterdir()) if p.is_file() and p.name!="seal.json"}
    if seal:record("seal.json",files)
    assert json.loads((HOME/"seal.json").read_bytes())==files
    print(len(files),"files verified;",sha(HOME/"seal.json"))
if __name__=="__main__":verify(sys.argv[1:]==["--seal"])
