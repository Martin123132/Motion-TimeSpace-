from finite_stars import *
from score_window import calc
def run(shell):
    assert (HOME/"OUTER-FREEZE.md").is_file()
    with (HOME/"window-verdict-1.json").open() as f:prior_result=json.load(f)
    assert prior_result["energy_fourth"]["16"]["physical_pass"]==4
    for key in KEYS:
        for level,steps,sub,mode in ((2,16,2,"direct"),(3,16,2,"direct"),(3,32,2,"direct"),(3,32,2,"fd"),(3,32,4,"direct")):
            guard();import finite_stars
            finite_stars.run(f"history-{level}-4-{steps}-{key}-32-physical.npz",sub,mode,shell)
    calc(shell)
if __name__=="__main__":run(int(sys.argv[1]))
