from pathlib import Path
import hashlib, io,csv,json,sys,os
HOME=Path(__file__).resolve().parent
ROOT=HOME.parent
VECTOR=ROOT/"mts-pal5-vector-response-20261122"
def sha(path):
    with path.open("rb") as fp: return hashlib.file_digest(fp,"sha256").hexdigest()
assert sha(VECTOR/"seal.json")=="b821fd0306260af30922b19c59eab59731c7f7c466b49c82764bffe8a3d36191"
manifest=json.loads((VECTOR/"seal.json").read_bytes())
def pin(name):
    assert sha(VECTOR/name)==manifest[name],name
    return VECTOR/name
pin("base.py");sys.path.insert(0,str(VECTOR))
from base import np,gauss,lg,CONV,G,CENTER,SIZE,KEYS,previous,prior,RELEASE
def guard():
    previous.guard()
    assert not any((p/"STOP-REQUESTED").exists() for p in (HOME,VECTOR))
def save(name,data):
    path=HOME/name
    if path.exists():assert path.read_bytes()==data,name
    else:
        with path.open("xb") as fp:fp.write(data)
def table(name,rows):
    fp=io.StringIO();w=csv.DictWriter(fp,fieldnames=list(rows[0]),lineterminator="\n");w.writeheader();w.writerows(rows);save(name,fp.getvalue().encode())
def record(name,value):save(name,(json.dumps(value,sort_keys=True,indent=2,allow_nan=False)+"\n").encode())
def packet(name,**data):
    fp=io.BytesIO();np.savez_compressed(fp,**data);save(name,fp.getvalue())
def read(path):
    with path.open() as fp:return list(csv.DictReader(fp))
guard()
