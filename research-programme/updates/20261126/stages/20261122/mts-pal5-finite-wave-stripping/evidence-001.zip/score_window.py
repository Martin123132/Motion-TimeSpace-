from finite_stars import *
YEARS=(4.,8.,16.,32.)
def stellar(level,steps,key,sub=2,mode="direct",branch="physical",shell=1):
    return {round(float(r["year"]),8):r for r in read(HOME/f"stellar-{level}-{3 if level==1 else 4}-{steps}-{key}-32-{branch}-s{sub}-{mode}{'' if shell==1 else '-shell'+str(shell)}.csv")}
def calc(shell=1):
    ref=read(pin("paired-stellar-verdict.csv"))
    terms=("energy_fourth","extra_wave_work_fourth")
    pred={(r["state"],r["observable"]):float(r["coefficient"]) for r in ref if r["site"]==str(shell) and r["observable"] in terms}
    with np.load(pin("stellar-input.npz")) as inp:
        selected=inp["indices"][24*(shell-1):24*shell];p=inp["pos"]
    vector=read(pin("stellar-work-12-15-612-18.csv"))
    summary=[];gates=[];injected=[]
    for key in KEYS:
        nominal=stellar(3,32,key,4,shell=shell);same=stellar(3,32,key,shell=shell);half=stellar(3,16,key,shell=shell);mesh=stellar(2,16,key,shell=shell)
        p2=stellar(3,32,key,2,"fd",shell=shell)
        force_ref=np.array([[float(r["fixed_"+component]) for component in "xyz"] for r in vector if r["state"]==key and r["shell"]==str(shell)])
        with np.load(HOME/f"history-3-4-32-{key}-32-physical.npz") as history:
            for year in YEARS:
                j=np.argmin(abs(history["times"]-year*1e-6));assert abs(history["times"][j]*1e6-year)<1e-9
                spl=RectBivariateSpline(history["r"],history["mu"],history["difference"][j]*2/history["times"][j]**2)
                coeff=sample(spl,p);diff=coeff[selected]-coeff[0]
                fr=np.linalg.norm(diff-force_ref)/np.linalg.norm(force_ref)
                each=np.linalg.norm(diff-force_ref,axis=1)/np.linalg.norm(force_ref,axis=1)
                for quantity,metric in zip(terms,("fourth_readout","work_fourth")):
                    v=lambda archive:float(archive[year][metric])
                    target=pred[key,quantity];value=v(nominal)
                    errors={"wave_step":abs(v(half)/v(same)-1),"spatial_grid":abs(v(mesh)/v(half)-1),
                        "stellar_step":abs(v(same)/value-1),"ordinary_readout":abs(v(p2)/v(same)-1),
                        "energy_balance":float(nominal[year]["max_even_balance_over_mean"])}
                    for test,err in errors.items():
                        gates.append(dict(state=key,year=year,quantity=quantity,test=test,error=err,passes=err<=.005))
                    discrepancy=abs(value/target-1)
                    observed=float(nominal[year]["energy_mean"])
                    ratio=observed/float(nominal[year/2]["energy_mean"])
                    summary.append(dict(state=key,year=year,quantity=quantity,energy_mean=observed,coefficient=value,
                             frozen=target,relative_to_frozen=discrepancy,passes_frozen=discrepancy<=.005,numerics_pass=all(a<=.005 for a in errors.values()),
                             worst_refinement=max(errors.values()),doubling_ratio=ratio,log2_energy_ratio=np.log2(ratio),
                             vector_ensemble_vs_initial=fr,worst_individual_vector_vs_initial=max(each),star_vector_passes=sum(each<=.005)))
    for branch in ("empty","equal"):
        data=stellar(1,8,"reset_forward",branch=branch)
        assert all(float(row["energy_mean"])==float(row["fourth_readout"])==float(row["odd_rms"])==float(row["max_paired_displacement_kpc"])==0. for row in data.values())
    table(f"window-measurements-{shell}.csv",summary);table(f"numerical-gates-{shell}.csv",gates)
    output={}
    for k in terms:
        output[k]={}
        for year in YEARS:
            vals=[r for r in summary if r["quantity"]==k and r["year"]==year]
            output[k][str(int(year))]=dict(physical_pass=sum(r["passes_frozen"] for r in vals),numerical_pass=sum(r["numerics_pass"] for r in vals),
                   range_error=[min(r["relative_to_frozen"] for r in vals),max(r["relative_to_frozen"] for r in vals)],
                   worst_refinement=max(r["worst_refinement"] for r in vals),ensemble_exponent=[min(r["log2_energy_ratio"] for r in vals),max(r["log2_energy_ratio"] for r in vals)])
    record(f"window-verdict-{shell}.json",output);print(output["energy_fourth"],flush=True)
if __name__=="__main__":calc(int(sys.argv[1]) if len(sys.argv)>1 else 1)
