from score_window import KEYS, YEARS, HOME, ROOT, sha, read, record, table, stellar
import json

def sealed(folder, name):
    base = ROOT / folder
    expected = json.loads((base / "seal.json").read_bytes())[name]
    assert sha(base / name) == expected
    return read(base / name)

def run():
    joined = "mts-pal5-joined-flow-586-600-20261122"
    tide = "mts-pal5-source-tides-20261122"
    live = "mts-pal5-live-wave-coupling-20261122"
    track = [r for r in sealed(joined,"summary-4-2.csv") if r["case"]=="both"]
    assert len(track)==6
    brackets = sealed(tide,"release-time-brackets.csv")
    shared = sealed(live,"shared-release-dates.csv")
    tilt = sealed(joined,"tilt-sensitivity-4-2.csv")
    comparisons=[]
    for row in track:
        prep,dist=row["arm"],row["distance"]
        pick=lambda rows:[r for r in rows if r.get("arm",r.get("preparation"))==prep and r["distance"]==dist]
        timing=[r for r in pick(brackets) if r["grid"]=="4-2"]
        both=[float(r["max_remaining_fraction"]) for r in pick(shared) if r["grid"]=="4-2" and r["tails"]=="inner+outer"]
        assert len(timing)==12 and len(both)==2 and len(pick(tilt))==1
        for grid in ("4-1","4-2"):
            select={(r["tail"],r["injected"],r["component"]):r["bracketed"] for r in pick(brackets) if r["grid"]==grid}
            if grid=="4-1":coarse=select
            else:assert select==coarse
        ratio=abs(float(row["gradient"])/0.15)
        assert abs(ratio-abs(float(row["gradient_sigma"])))<1e-12
        comparisons.append(dict(preparation=prep,distance_kpc=dist,
            forward_minus_reverse_kms_per_degree=row["gradient"],quoted_error_kms_per_degree=.15,
            separation_over_gradient_error=ratio,one_bin_max_over_error=row["max_bin_sigma"],
            independent_bin_norm=row["diag_track_sigma"],independent_bin_norm_after_tilt=pick(tilt)[0]["residual_diagonal"],
            max_relative_pc=row["max_pc"],single_coordinate_targets=len(timing),
            bracketed_by_opposite_date=sum(r["bracketed"]=="True" for r in timing),
            min_common_date_residual_fraction=min(both),max_common_date_residual_fraction=max(both)))
    table("stream-identifiability.csv",comparisons)
    controls=[]
    for key in KEYS:
        physical=stellar(2,16,key)
        allterms=[read(HOME/f"terms-{level}-4-{steps}-{key}-32-physical.csv") for level,steps in ((2,16),(3,16),(3,32))]
        for year in YEARS:
            control=lambda name:float(stellar(2,16,key,branch=name)[year]["fourth_readout"])/float(physical[year]["fourth_readout"])-1
            terms=[next(r for r in rows if abs(float(r["year"])-year)<1e-8) for rows in allterms]
            fractions=[float(r["gradient_departure"])/float(r["total_departure"]) for r in terms]
            controls.append(dict(state=key,year=year,held_relative=control("held"),one_way_relative=control("one_way"),
                gradient_fraction_coarse=fractions[0],gradient_fraction_time_half=fractions[1],gradient_fraction_fine=fractions[2],
                reconstruction_relative=float(terms[-1]["birth_site_reconstruction_error"])))
    table("controls-and-origin.csv",controls)
    verdicts=[json.loads((HOME/f"window-verdict-{shell}.json").read_bytes()) for shell in (1,2,3)]
    final=[r for r in controls if r["year"]==32]
    record("decision.json",dict(signed_Myr=111.158776,reference_coverage_percent=[111.158776/1940*100,111.158776/5000*100],
        individual_targets=sum(r["single_coordinate_targets"] for r in comparisons),bracketed=sum(r["bracketed_by_opposite_date"] for r in comparisons),
        largest_gradient_error_units=max(r["separation_over_gradient_error"] for r in comparisons),
        largest_one_bin_error_units=max(float(r["one_bin_max_over_error"]) for r in comparisons),
        fourth_energy_pass_by_shell_and_year=[[v["energy_fourth"][str(int(t))]["physical_pass"] for t in YEARS] for v in verdicts],
        energy32_worst_each_shell=[v["energy_fourth"]["32"]["range_error"][1] for v in verdicts],
        worst_numerical_relative=max(r["worst_refinement"] for v in verdicts for rows in v.values() for r in rows.values()),
        gradient_fraction32=[min(r["gradient_fraction_fine"] for r in final),max(r["gradient_fraction_fine"] for r in final)],
        gradient_fraction32_across_refinements=[min(r[s] for r in final for s in ("gradient_fraction_coarse","gradient_fraction_time_half","gradient_fraction_fine")),max(r[s] for r in final for s in ("gradient_fraction_coarse","gradient_fraction_time_half","gradient_fraction_fine"))],
        max_reconstruction_error32=max(r["reconstruction_relative"] for r in final),
        largest_held_relative=max(abs(r["held_relative"]) for r in controls),largest_one_way_relative=max(abs(r["one_way_relative"]) for r in controls),
        worst_fine_ordinary_relative=max(float(r["differential"]) for r in read(HOME/"ordinary-check-3-4.csv"))))
if __name__=="__main__":run()
