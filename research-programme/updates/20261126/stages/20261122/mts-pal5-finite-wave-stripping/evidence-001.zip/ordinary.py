from mesh_fd import *
from scipy.interpolate import CubicSpline
def run(level,order):
    import sources
    sources.table=lambda name,data: table("source-gains.csv",data)
    faces,shells,gains=sources.info();orig=sources.prior.original;src=sources.prior.source
    with np.load(prior("mesh.npz")) as old: path=old["right"]
    rf=edges(level,np.r_[path,shells[1:-1],25.,30.,160.,160*np.sqrt(2)],path[-1],False)
    mf=edges(level,faces,1.,True)
    rn,wt=gauss(order)
    radii=rf[:-1,None]+np.diff(rf)[:,None]*(1+rn)/2
    mu=(mf[:-1,None]+np.diff(mf)[:,None]*(1+rn)/2).ravel()
    az,aw=sources.quadrature(np.array([0.,np.pi/2]),32);aw*=2/np.pi
    cg=np.linspace(0.,30.,15001);spline=CubicSpline(cg,orig.columns(cg),axis=0)
    mass=np.zeros((2,len(rf)-1,len(mf)-1))
    angular=np.searchsorted(faces[1:-1],mu)
    for j,ring in enumerate(radii):
        if j%40==0:guard()
        if ring[0]>160*np.sqrt(2):continue
        for r,w in zip(ring,wt*np.diff(rf)[j]/2):
            cyl=r*np.sqrt(1-mu**2);alt=r*mu
            cols=spline(np.minimum(30.,cyl))*(cyl<30)[:,None];donors=orig.supply(cyl);shares=donors/np.maximum(1e-25,donors.sum(axis=1))[:,None]
            rho=src.disk(cyl,alt)+sum(v*orig.zshape(k,alt) for k,v in zip(orig.ls.S22,cols.T))-cols.sum(axis=1)*sum(shares[:,k]*src.starshape(alt,k) for k in range(4))
            rho+=src.stars.bmass*(orig.ls.old.density("E3",(.67,.29,.27),cyl[:,None]*np.cos(az),cyl[:,None]*np.sin(az),alt[:,None])@aw)
            gain=gains[:,np.searchsorted(shells,r,side="right")-1,angular]
            dens=rho*((cyl<=160)&(alt<=160))*(1+np.clip((30-r)/5,0,1)*(gain-1))
            assert dens.min()>=0
            mass[:,j]+=w*r*r*(dens.reshape(2,-1,order)@(wt/2))
    packet(f"mass-{level}-{order}.npz",rf=rf,mf=mf,mass=mass)
    print("source",level,order,mass.shape,4*np.pi*np.sum(mass*np.diff(mf),axis=(1,2)),flush=True)
if __name__=="__main__": run(*map(int,sys.argv[1:]))
