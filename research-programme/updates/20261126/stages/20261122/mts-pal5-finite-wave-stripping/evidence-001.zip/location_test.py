from finite_stars import *
from base import geometry
def run():
    mat,_=geometry();out=[]
    with np.load(pin("stellar-input.npz")) as bank:
        where=bank["indices"][:24];keys=bank["keys"][:24];v=bank["velocity"][:24];points=bank["pos"][where]
    with np.load(prior("mesh.npz")) as mesh:kappa=float(mesh["vel"]*mesh["length"]*CONV)
    ref=read(pin("paired-energy-12-15-612-18-small.csv"))
    faces=mat.right[:-1];rad=np.linalg.norm(points,axis=1);near=faces[np.argmin(abs(faces[:,None]-rad),axis=0)]
    left,right=[mat.radial(near,(586,590),0.,1,side=s)[1] for s in ("left","right")]
    pol=lg.legvander(points[:,2]/rad,68)[:,::2];jump=((right-left)*pol).sum(axis=1)
    for key in KEYS:
        f=Fields(HOME/f"history-3-4-32-{key}-32-physical.npz","direct")
        slopes=[]
        for spline in f.dw:
            _,effect=lap_force(spline,points,v)
            slopes.append(np.sum(effect*v,axis=1))
        slopes=np.array(slopes);nd,w=gauss(3);budget=np.zeros(len(v))
        for i,(lo,hi) in enumerate(zip(f.t[:-1],f.t[1:])):
            start=min(i,len(f.t)-3)
            for t,wt in zip(lo+(hi-lo)*(nd+1)/2,w*(hi-lo)/2):
                u=(t-f.t[start])/(f.t[start+1]-f.t[start]);basis=[(u-1)*(u-2)/2,u*(2-u),u*(u-1)/2]
                budget+=wt*t*(basis@slopes[start:start+3])
            year=int(round(hi*1e6))
            if year not in (4,8,16,32):continue
            for j in range(1,24,2):
                frozen=next(float(r["gradient_term"]) for r in ref if r["state"]==key and int(r["star_plus"])==j and r["h_pc"]=="0.3")
                val=24*budget[j]/hi**4
                out.append(dict(state=key,year=year,star_plus=j,axis=keys[j,1],side=keys[j,2],tangent=keys[j,3],
                        galactocentric_radius=rad[j],face=near[j],face_distance_pc=1000*abs(rad[j]-near[j]),
                        scale_pc=1000*np.sqrt(kappa*hi),distance_squared_over_kappa_year=(rad[j]-near[j])**2/kappa*1e6,
                        native_radial_potential_slope_jump=jump[j],frozen_gradient=frozen,finite_gradient=val,departure=val-frozen))
    table("gradient-by-release-position.csv",out)
if __name__=="__main__":run()
