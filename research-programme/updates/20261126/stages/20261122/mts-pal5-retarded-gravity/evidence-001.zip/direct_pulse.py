from response import *
from scipy.integrate import simpson

def main():
    years=32;step=32e-6;count=64
    sites=read(previous('sites.csv'));out=[]
    with np.load(pin('volume-2-4.npz')) as bank:
        mesh=Space(bank['rf'],bank['mf']);kap=float(bank['kappa']);kin=Kinetic(mesh,kap,step)
        ir=np.flatnonzero((mesh.r>5.15)&(mesh.r<5.45));im=np.flatnonzero((mesh.mu>.47)&(mesh.mu<.55));ix=np.ix_(ir,im)
        solve=lambda mass:mesh.poisson(4*np.pi*G*mesh.dr[:,None]*mass)
        for first in range(0,12,3):
            part=sites[first:first+3];arm,site=part[0]['prep'],part[0]['flow'];key=arm+'_'+site
            star=Stars(part,first//3,10,3);wave=bank[key];velocity=np.zeros_like(wave);difference_mass=np.zeros_like(wave.real)
            nobs=Observe(mesh.r[ir],mesh.mu[im],star,count,step,1)
            predpath=HERE/f'prediction-L2-h32-own-{key}.npz';before=digest(predpath)
            commonrate=(bank['old1']-bank['old0'])/star.duration;drate=(bank['delta1']-bank['delta0'])/star.duration
            native=bank['old0']+commonrate*star.date;correction=bank['delta0']+drate*star.date
            basepot=solve(abs(wave)**2);induced=np.zeros_like(basepot);phase=-.5j*step*CONV**2/kap
            for tick in range(1,count+1):
                hold();active=tick<=count//2
                for half in range(2):
                    time=(tick-1+half)*step
                    drive=(correction+time*drate if active else 0.)+induced
                    wave,velocity=kick(wave,velocity,native+time*commonrate+basepot,drive,phase)
                    if not half:
                        wave,velocity=kin.radial(wave,velocity,difference_mass)
                        wave,velocity=kin.angular(wave,velocity,difference_mass)
                        wave,velocity=kin.radial(wave,velocity,difference_mass)
                        basepot=solve(abs(wave)**2);induced=solve(difference_mass)
                nobs.add(tick,[induced[ix]])
                if tick==count//2:
                    with np.load(prior(f'tide-L2-h32-own-{key}.npz')) as ref:
                        assert np.array_equal(induced[ix],ref['response'][tick])
            assert np.linalg.norm((2*(wave.conj()*velocity).real+abs(velocity)**2-difference_mass)[ix])/np.linalg.norm(difference_mass[ix])<1e-8
            with np.load(predpath) as predicted:
                early=predicted['forces'][2,::4];total=predicted['forces'][0,::4];times=predicted['time'][::4]
            assert before==digest(predpath)
            actual=nobs.value[0,::4]
            for tag,time_series in [('force',False),('impulse',True)]:
                for frame_index,frame in enumerate(('fixed','moving')):
                    for tail_index,tail in enumerate(('inner','outer')):
                        def end(array):
                            seq=array[:,frame_index,tail_index]
                            return CONV*simpson(seq,x=times,axis=0) if time_series else seq[-1]
                        one,two,all_on=map(end,(early,actual,total))
                        frac=np.linalg.norm(one-two)/np.linalg.norm(two)
                        out.append(dict(prep=arm,site=site,frame=frame,tail=tail,observable=tag,prediction_sha256=before,actual_norm=np.linalg.norm(two),relative_error=frac,passed=frac<=.005,finite_pulse_along_full_linear=float(two@all_on/(all_on@all_on)),never_driven_relative_error=1.))
            print('finite pulse complete',key,flush=True)
    table('independent-pulse.csv',out)
if __name__=='__main__':main()
