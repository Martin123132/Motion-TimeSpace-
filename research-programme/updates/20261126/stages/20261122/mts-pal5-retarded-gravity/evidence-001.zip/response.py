from retarded_io import *
from scipy.linalg.lapack import zgttrs

def centre(values):
    return values-values[len(values)//2,0]

def variation_kick(states,drives,phase):
    base,linear,square,pulse=states
    common,first,second,early=drives
    unit=np.exp(phase*centre(common));lin=phase*centre(first)
    return (unit*base,unit*(linear+lin*base),unit*(square+lin*linear+(phase*centre(second)+.5*lin**2)*base),unit*(pulse+phase*centre(early)*base))

def propagate(kin,states,counts,radial):
    mesh=kin.s
    def half(value):
        if radial:
            result,info=zgttrs(*kin.rad,value);assert info==0
            return result
        result=np.array(value,order='F')
        for col in range(1,result.shape[1]):result[:,col]-=kin.al[:,col-1]*result[:,col-1]
        result[:,-1]*=kin.ad[:,-1]
        for col in reversed(range(result.shape[1]-1)):result[:,col]=(result[:,col]-kin.up[:,col]*result[:,col+1])*kin.ad[:,col]
        return result
    mids=[half(state) for state in states]
    base,linear,square,pulse=mids
    left,right=(np.s_[:-1,:],np.s_[1:,:]) if radial else (np.s_[:,:-1],np.s_[:,1:])
    faces=kin.dt*kin.kappa*(kin.ks[:,None]/2 if radial else kin.km/mesh.r[:,None]**2)
    spacing=mesh.dr[:,None] if radial else np.broadcast_to(mesh.dm,base.shape)
    for k,wave in enumerate((linear,square,pulse)):
        flux=base[left].conj()*wave[right]+wave[left].conj()*base[right]
        if k==1:flux+=linear[left].conj()*linear[right]
        transfer=faces*flux.imag
        counts[k][left]-=transfer/spacing[left];counts[k][right]+=transfer/spacing[right]
    return tuple(2*mid-state for mid,state in zip(mids,states))

def kinetic_step(kin,states,counts):
    for radial in (True,False,True):states=propagate(kin,states,counts,radial)
    return states

class Observe:
    def __init__(self,r,mu,star,count,step,channels):
        self.r=r;self.mu=mu;self.start=star.start;self.velocity=star.v;self.count=count;self.step=step
        self.dense=np.arange(4*count+1)*step/4
        self.value=np.zeros((channels,len(self.dense),2,2,3))
    def add(self,tick,grids):
        indices=np.arange(max(0,4*tick-8),min(4*self.count,4*tick+8)+1)
        unit=indices/4;centres=np.clip(np.rint(unit).astype(int),1,self.count-1);u=unit-centres
        weights=np.select((tick==centres-1,tick==centres,tick==centres+1),(u*(u-1)/2,1-u*u,u*(u+1)/2))
        valid=weights!=0;indices=indices[valid];weights=weights[valid]
        pts=self.start+self.dense[indices,None,None]*self.velocity
        for ch,grid in enumerate(grids):
            spl=RectBivariateSpline(self.r,self.mu,grid)
            fixed=sample(spl,self.start);flight=sample(spl,pts.reshape(-1,3)).reshape(-1,3,3)
            self.value[ch,indices,0]+=weights[:,None,None]*(fixed[1:]-fixed[:1])
            self.value[ch,indices,1]+=weights[:,None,None]*(flight[:,1:]-flight[:,:1])

def run(level,years,setup):
    tag=f'L{level}-h{years}-{setup}';step=years*1e-6;count=2048//years
    sites=read(previous('sites.csv'))
    with np.load(pin(f'volume-{level}-4.npz')) as bank:
        mesh=Space(bank['rf'],bank['mf']);kappa=float(bank['kappa']);kin=Kinetic(mesh,kappa,step)
        ir=np.flatnonzero((mesh.r>5.15)&(mesh.r<5.45));im=np.flatnonzero((mesh.mu>.47)&(mesh.mu<.55));ix=np.ix_(ir,im)
        widths=mesh.dr[:,None];weights=widths*mesh.dm
        solve=lambda density:mesh.poisson(4*np.pi*G*widths*density)
        for start in range(0,12,3):
            hold();part=sites[start:start+3];key=part[0]['prep']+'_'+part[0]['flow'];star=Stars(part,start//3,10,3)
            if setup=='own':wave=bank[key]
            else:
                with np.load(pin(f'cross-launch-{level}-4.npz')) as crossed:wave=crossed[key]
            states=(wave,*(np.zeros_like(wave) for i in range(3)));counts=[np.zeros_like(wave.real) for i in range(3)]
            density0=np.sum(weights*abs(wave)**2);fields=(solve(abs(wave)**2),*(np.zeros_like(wave.real) for i in range(3)))
            commonrate=(bank['old1']-bank['old0'])/star.duration;drate=(bank['delta1']-bank['delta0'])/star.duration
            base=bank['old0']+commonrate*star.date;drive=bank['delta0']+drate*star.date
            observer=Observe(mesh.r[ir],mesh.mu[im],star,count,step,3)
            def potential(time,early):
                change=drive+time*drate
                return (base+time*commonrate+fields[0],change+fields[1],fields[2],(change if early else 0.)+fields[3])
            records=[];snap={}
            for tick in range(1,count+1):
                hold();early=tick<=count//2;phase=-.5j*step*CONV**2/kappa
                states=variation_kick(states,potential((tick-1)*step,early),phase)
                states=kinetic_step(kin,states,counts)
                fields=tuple(solve(z) for z in (abs(states[0])**2,*counts))
                states=variation_kick(states,potential(tick*step,early),phase)
                observer.add(tick,[field[ix] for field in fields[1:]])
                if tick*years%256:continue
                basewave,linear,square,pulse=states
                literal=(2*(basewave.conj()*linear).real,2*(basewave.conj()*square).real+abs(linear)**2,2*(basewave.conj()*pulse).real)
                norm_error=abs(np.sum(weights*abs(basewave)**2)/density0-1)
                for label,net,check in zip(('linear','square','early'),counts,literal):
                    resid=np.linalg.norm((check-net)[ix])/np.linalg.norm(net[ix]);balance=abs(np.sum(weights*net))/np.sum(weights*abs(net))
                    records.append(dict(year=years*tick,which=label,current_identity=resid,net_mass_ratio=balance,base_mass_drift=norm_error))
                    assert max(resid,balance,norm_error)<1e-8,(tag,key,label,resid,balance)
                if tick==count:snap=dict(base=fields[0][ix],linear=fields[1][ix],square=fields[2][ix],density1=counts[0][ix],density2=counts[1][ix])
            packet(f'prediction-{tag}-{key}.npz',time=observer.dense,forces=observer.value,r=mesh.r[ir],mu=mesh.mu[im],**snap)
            table(f'conservation-{tag}-{key}.csv',records);print('saved',tag,key,flush=True)
if __name__=='__main__':
    run(int(sys.argv[1]),int(sys.argv[2]),sys.argv[3])
