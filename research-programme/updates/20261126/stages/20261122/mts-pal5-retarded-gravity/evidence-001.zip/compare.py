from response import *
from scipy.integrate import simpson

def norm(vec):return np.linalg.norm(vec)
def err(test,ref):return norm(test-ref)/norm(ref)
def project(value,ref):return float(np.vdot(value,ref).real/np.vdot(ref,ref).real)

def main():
    output=[];spatial=[];checks=[];stored={};sites=read(previous('sites.csv'))
    configs=[(2,32,'own'),(2,32,'cross'),(2,16,'own'),(3,32,'own')]
    for level,years,setup in configs:
        tag=f'L{level}-h{years}-{setup}'
        stellar=read(prior(f'stellar-feedback-{tag}-4.csv'))
        for first in range(0,12,3):
            part=sites[first:first+3];arm,site=part[0]['prep'],part[0]['flow'];key=arm+'_'+site
            star=Stars(part,first//3,10,3)
            with np.load(HERE/f'prediction-{tag}-{key}.npz') as pred,np.load(prior(f'tide-{tag}-{key}.npz')) as actual:
                r,mu=pred['r'],pred['mu'];assert np.array_equal(r,actual['r']) and np.array_equal(mu,actual['mu'])
                assert np.array_equal(pred['base'],actual['common'][-1]),(tag,key)
                refgrids=actual['response'];full=Observe(r,mu,star,len(refgrids)-1,years*1e-6,1)
                for tick,grid in enumerate(refgrids):full.add(tick,[grid])
                dense=pred['time'];assert np.array_equal(full.dense,dense)
                series=pred['forces'];benchmark=full.value[0]
                patches=[('potential in saved gauge',pred['linear'],pred['square'],refgrids[-1])]
                if level==2:
                    with np.load(prior(f'end-{tag}-{key}.npz')) as end,np.load(pin('volume-2-4.npz')) as init:
                        rc=(init['rf'][:-1]+init['rf'][1:])/2;mc=(init['mf'][:-1]+init['mf'][1:])/2
                        ix=np.ix_(np.flatnonzero((rc>5.15)&(rc<5.45)),np.flatnonzero((mc>.47)&(mc<.55)))
                        datum=end['net'][ix]
                    patches.append(('inertial mass per radial-angular cell coordinate',pred['density1'],pred['density2'],datum))
                for name,l1,l2,data in patches:
                    spatial.append(dict(tag=tag,key=key,observable=name,linear_frac=err(l1,data),relative_second=norm(l2)/norm(data),linear_plus_square_frac=err(l1+l2,data),nonlinear_residual_frac=err(l2,data-l1),residual_alignment=project(l2,data-l1)))
            for row in stellar:
                if (row['prep'],row['flow'])!=(arm,site):continue
                end_year=round(float(row['time'])*1e6);ix=end_year*4//years
                obs=np.array([float(row['dv_'+c]) for c in 'xyz'])
                tail_index=0 if row['tail']=='inner' else 1
                for flight,frame in enumerate(('fixed','moving')):
                    signal=series[:,:,flight,tail_index];full=benchmark[:,flight,tail_index]
                    for method in ('force','impulse'):
                        if method=='force':
                            total=full[ix];linear,second,early=signal[:,ix]
                        else:
                            native=slice(0,ix+1,4)
                            total=CONV*simpson(full[native],x=dense[native],axis=0)
                            linear,second,early=CONV*simpson(signal[:,native],x=dense[native],axis=1)
                        resid=total-linear
                        assert norm(total)>0 and norm(linear)>0
                        if end_year==1024:assert np.array_equal(early,linear)
                        trace=dict(tag=tag,prep=arm,site=site,tail=row['tail'],year=end_year,frame=frame,method=method,finite_norm=norm(total),linear_frac=err(linear,total),second_relative_to_total=norm(second)/norm(total),linear_plus_square_frac=err(linear+second,total),square_residual_frac=err(second,resid) if norm(resid) else '',early_parallel=project(early,linear),late_transverse_fraction=norm((linear-early)-(1-project(early,linear))*linear)/norm(linear),stellar_velocity_error=err(linear,obs) if method=='impulse' and frame=='moving' else '')
                        output.append(trace)
                        if method=='impulse':
                            dense_linear=CONV*simpson(signal[0,:ix+1],x=dense[:ix+1],axis=0)
                            trace['native_vs_dense_impulse']=err(linear,dense_linear)
                        else:trace['native_vs_dense_impulse']=''
                        stored[(tag,arm,site,row['tail'],end_year,frame,method)]=(linear,second,early)
    for k,val in stored.items():
        tag,*rest=k
        if tag!='L2-h32-own':continue
        for test,target in [('time','L2-h16-own'),('mesh','L3-h32-own')]:
            match=stored[(target,*rest)]
            for label,one,two in zip(('linear','square','early'),val,match):
                frac=err(one,two)
                checks.append(dict(refinement=test,channel=label,prep=rest[0],site=rest[1],tail=rest[2],year=rest[3],frame=rest[4],method=rest[5],fraction=frac,passed=frac<=.005))
    table('response-comparisons.csv',output);table('field-patch.csv',spatial);table('refinements.csv',checks)
    print('force and impulse rows',len(output),'patch rows',len(spatial),'refinements',len(checks))
if __name__=='__main__':main()
