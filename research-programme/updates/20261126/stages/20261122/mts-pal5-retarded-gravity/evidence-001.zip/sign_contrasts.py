from compare import *
def main():
    table_rows=[];aggregate=[]
    for setup in ('own','cross'):
        full=read(prior(f'stellar-feedback-L2-h32-{setup}-4.csv'))
        tag='L2-h32-'+setup
        for prep in ('reset','coupled'):
            for site in ('forward','reverse'):
                with np.load(HERE/f'prediction-{tag}-{prep}_{site}.npz') as pred:
                    dense=pred['time'];data=pred['forces'][:,:,1]
                for row in full:
                    if (row['prep'],row['flow'])!=(prep,site):continue
                    tail=row['tail'];selected=0 if tail=='inner' else 1;yr=round(1e6*float(row['time']));idx=yr*4//32
                    results=CONV*simpson(data[:,:idx+1:4,selected],x=dense[:idx+1:4],axis=1)
                    table_rows.append((setup,prep,site,tail,yr,results[0]))
    lookup={row[:-1]:row[-1] for row in table_rows}
    def match_reference(tag):
        entries={}
        for setup in ('own','cross'):
            rows=read(prior(f'stellar-feedback-{tag}-{setup}-4.csv'))
            for row in rows:
                entries[(setup,row['prep'],row['flow'],row['tail'],round(1e6*float(row['time'])))]=np.array([float(row['dv_'+ax]) for ax in 'xyz'])
        return entries
    for tag in ('L2-h32','L2-h16','L3-h32'):
        reference=match_reference(tag)
        for (setup,prep,site,tail,yr),val in lookup.items():
            if setup!='own':continue
            a=('own',prep,site,tail,yr);b=('cross',*a[1:])
            orientation=1 if site=='forward' else -1
            one=orientation*(val-lookup[b]);two=orientation*(reference[a]-reference[b])
            aggregate.append(dict(reference=tag,prep=prep,site=site,tail=tail,year=yr,fixed_site_signed_impulse_kms=norm(two),cancellation_condition=(norm(reference[a])+norm(reference[b]))/norm(two),relative_error=err(one,two),parallel=project(one,two),passed=err(one,two)<=.005))
    table('fixed-site-flow-contrast.csv',aggregate)
if __name__=='__main__':main()
