import csv,hashlib,io,json,os,sys
from pathlib import Path
for name in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','BLIS_NUM_THREADS','NUMEXPR_NUM_THREADS'):os.environ[name]='1'
HERE=Path(__file__).resolve().parent
BRIDGE=HERE.parent/'mts-pal5-pericentre-2048-bridge-20261122'
def digest(path):
    with path.open('rb') as fp:return hashlib.file_digest(fp,'sha256').hexdigest()
assert digest(BRIDGE/'seal.json')=='af5b5ccbfdb0b9c4dd3ec3f9f8fa0ce0438276bd40626dac571aec6e2d094aa1'
files=json.loads((BRIDGE/'seal.json').read_bytes())
def prior(name):
    path=BRIDGE/name;assert digest(path)==files[name],name;return path
prior('bridge_io.py')
sys.path.insert(0,str(BRIDGE))
from bridge_io import previous,pin,Stars,CONV,G,Space,Kinetic,kick,sample,np,RectBivariateSpline,hold as old_hold,read
def hold():
    old_hold();assert not (HERE/'STOP-REQUESTED').exists()
def write(name,data):
    hold();path=HERE/name
    if path.exists():assert digest(path)==hashlib.sha256(data).hexdigest(),name
    else:
        with path.open('xb') as fp:fp.write(data)
def packet(name,**arrays):
    buf=io.BytesIO();np.savez_compressed(buf,**arrays);write(name,buf.getvalue())
def table(name,data):
    buf=io.StringIO();out=csv.DictWriter(buf,data[0],lineterminator='\n');out.writeheader();out.writerows(data);write(name,buf.getvalue().encode())
hold()
