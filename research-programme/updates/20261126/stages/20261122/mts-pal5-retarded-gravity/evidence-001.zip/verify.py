from retarded_io import *
def main():
    hold()
    for level,years,setup in ((2,32,'own'),(2,32,'cross'),(2,16,'own'),(3,32,'own')):
        for arm in ('reset','coupled'):
            for site in ('forward','reverse'):
                name=f'L{level}-h{years}-{setup}-{arm}_{site}'
                rec=read(HERE/f'conservation-{name}.csv')
                assert len(rec)==24 and all(max(float(row[k]) for k in ('current_identity','net_mass_ratio','base_mass_drift'))<1e-8 for row in rec)
                with np.load(HERE/f'prediction-{name}.npz') as check:
                    a=check['forces'];n=2048//years;assert a.shape==(3,4*n+1,2,2,3) and np.isfinite(a).all()
                    assert not np.any(a[:,0]) and np.array_equal(a[0,:2*n+1:4],a[2,:2*n+1:4])
                    assert np.array_equal(check['time'][::4],np.arange(n+1)*years*1e-6) or np.allclose(check['time'][::4],np.arange(n+1)*years*1e-6,rtol=1e-15,atol=0)
    for name,count in [('response-comparisons.csv',640),('refinements.csv',960),('field-patch.csv',28),('fixed-site-flow-contrast.csv',120),('controls.csv',4),('independent-pulse.csv',32)]:
        rows=read(HERE/name);assert len(rows)==count,(name,count,len(rows))
    for row in read(HERE/'independent-pulse.csv'):
        assert digest(HERE/('prediction-L2-h32-own-'+row['prep']+'_'+row['site']+'.npz'))==row['prediction_sha256']
    for name,expected in [('pulse-memory.csv',32),('compensated.csv',32),('compensated-refinement.csv',64)]:
        assert len(read(HERE/name))==expected
    for row in read(HERE/'compensated.csv'):
        key=row['prep']+'_'+row['site']
        assert row['frozen_sha256']==digest(HERE/f'frozen-compensation-L2-h32-own-{key}.npz')
        with np.load(HERE/f'nonlinear-compensated-{key}.npz') as f:
            assert np.array_equal(f['difference'],f['pair'][0]-f['pair'][1])
    assert not (HERE/'__pycache__').exists()
    files={path.name:digest(path) for path in sorted(HERE.iterdir()) if path.is_file() and path.name!='seal.json'}
    write('seal.json',(json.dumps(files,sort_keys=True,indent=2)+'\n').encode())
    assert files=={name:digest(HERE/name) for name in files};print(len(files),digest(HERE/'seal.json'))
if __name__=='__main__':main()
