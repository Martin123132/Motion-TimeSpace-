from compare import *
def main():
    rows=read(HERE/'independent-pulse.csv');sites=read(previous('sites.csv'));out=[]
    for first in range(0,12,3):
        entry=sites[first:first+3];prep,site=entry[0]['prep'],entry[0]['flow'];star=Stars(entry,first//3,10,3)
        with np.load(prior(f'tide-L2-h32-own-{prep}_{site}.npz')) as src:
            reference=Observe(src['r'],src['mu'],star,64,32e-6,1)
            for tick,grid in enumerate(src['response']):reference.add(tick,[grid])
        with np.load(HERE/f'prediction-L2-h32-own-{prep}_{site}.npz') as pred:
            echo=pred['forces'][2,::4];times=pred['time'][::4]
        for row in rows:
            if (row['prep'],row['site'])!=(prep,site):continue
            frame=int(row['frame']=='moving');tail=int(row['tail']=='outer')
            seq=reference.value[0,::4,frame,tail]
            if row['observable']=='force':
                middle=seq[32];held=seq[64];short,full=echo[32,frame,tail],echo[64,frame,tail]
                ideal_fraction=.75;ideal_growth=3.
            else:
                integra=lambda v,n:CONV*simpson(v[:n+1],x=times[:n+1],axis=0)
                middle=integra(seq,32);held=integra(seq,64);short=integra(echo[:,frame,tail],32);full=integra(echo[:,frame,tail],64)
                ideal_fraction=.875;ideal_growth=7.
            finite=float(row['actual_norm']);growth=finite/norm(middle);share=finite/norm(held)
            out.append(dict(prep=prep,site=site,tail=row['tail'],frame=row['frame'],observable=row['observable'],finite_growth_after_off=growth,linear_prediction_growth=norm(full)/norm(short),leading_constant_kernel_growth=ideal_growth,growth_law_relative_error=abs(ideal_growth/growth-1),pulse_to_continuous_force_or_impulse=share,leading_constant_kernel_fraction=ideal_fraction,fraction_law_relative_error=abs(ideal_fraction/share-1)))
    table('pulse-memory.csv',out)
if __name__=='__main__':main()
