from retarded_io import *

def main():
    rows=read(HERE/'response-comparisons.csv');fixed=read(HERE/'fixed-site-flow-contrast.csv')
    refine=read(HERE/'refinements.csv');pulse=read(HERE/'independent-pulse.csv')
    def show(rows,key):
        vals=[float(row[key]) for row in rows if row[key]!='']
        print(key,len(vals),sum(x<=.005 for x in vals),min(vals),max(vals))
    for tag in ('L2-h32-own','L2-h32-cross','L2-h16-own','L3-h32-own'):
        cases=[r for r in rows if r['tag']==tag]
        print(tag)
        for key in ('linear_frac','linear_plus_square_frac','second_relative_to_total','square_residual_frac','stellar_velocity_error','native_vs_dense_impulse'):show(cases,key)
        for kind in ('force','impulse'):
            print(kind);show([r for r in cases if r['year']=='2048' and r['frame']=='fixed' and r['method']==kind],'early_parallel')
    for group in ('time','mesh'):
        for mode in ('linear','square','early'):
            print(group,mode);show([r for r in refine if r['channel']==mode and r['refinement']==group],'fraction')
    for group in ('L2-h32','L2-h16','L3-h32'):
        print('fixed flow difference',group);show([r for r in fixed if r['reference']==group],'relative_error')
    show(pulse,'relative_error')
    for kind in ('force','impulse'):
        mem=[r for r in read(HERE/'pulse-memory.csv') if r['observable']==kind and r['frame']=='fixed']
        show(mem,'finite_growth_after_off');show(mem,'pulse_to_continuous_force_or_impulse')
    for name in ('potential in saved gauge','inertial mass per radial-angular cell coordinate'):
        print(name);block=[r for r in read(HERE/'field-patch.csv') if r['observable']==name]
        for key in ('linear_frac','relative_second','linear_plus_square_frac','nonlinear_residual_frac'):show(block,key)
if __name__=='__main__':main()
