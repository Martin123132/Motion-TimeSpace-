from response import *
from scipy.integrate import simpson

def summarize(arr,times):
    return np.stack((arr[-1],CONV*simpson(arr,x=times,axis=0)))

def freeze(tag):
    for arm in ('reset','coupled'):
        for site in ('forward','reverse'):
            key=arm+'_'+site
            with np.load(HERE/f'prediction-{tag}-{key}.npz') as f:
                times=f['time'][::4];forces=f['forces'][:,::4]
                continuous=summarize(forces[0],times);early=summarize(forces[2],times)
                pair=np.stack((early/3,continuous-early))
                packet(f'frozen-compensation-{tag}-{key}.npz',continuous=continuous,pair=pair,difference=pair[0]-pair[1])

def execute():
    tag='L2-h32-own';years=32;dt=32e-6;sites=read(previous('sites.csv'));out=[]
    names=[arm+'_'+site for arm in ('reset','coupled') for site in ('forward','reverse')]
    pinned={key:digest(HERE/f'frozen-compensation-{tag}-{key}.npz') for key in names}
    with np.load(pin('volume-2-4.npz')) as bank:
        mesh=Space(bank['rf'],bank['mf']);kap=float(bank['kappa']);kin=Kinetic(mesh,kap,dt);phase=-.5j*dt*CONV**2/kap
        solve=lambda n:mesh.poisson(4*np.pi*G*mesh.dr[:,None]*n)
        ir=np.flatnonzero((mesh.r>5.15)&(mesh.r<5.45));im=np.flatnonzero((mesh.mu>.47)&(mesh.mu<.55));ix=np.ix_(ir,im)
        for start in range(0,12,3):
            part=sites[start:start+3];arm,site=part[0]['prep'],part[0]['flow'];key=arm+'_'+site
            star=Stars(part,start//3,10,3);wave=bank[key]
            dbase=(bank['old1']-bank['old0'])/star.duration;dextra=(bank['delta1']-bank['delta0'])/star.duration
            host=bank['old0']+dbase*star.date;extra=bank['delta0']+dextra*star.date
            obs=Observe(mesh.r[ir],mesh.mu[im],star,64,dt,2)
            for ch in range(2):
                wave=bank[key];delta=np.zeros_like(wave);net=np.zeros_like(wave.real)
                common=solve(abs(wave)**2);reaction=np.zeros_like(common)
                record=Observe(mesh.r[ir],mesh.mu[im],star,64,dt,1)
                for tick in range(1,65):
                    hold();gain=([1/3,0] if tick<=32 else [0.,1.])[ch]
                    for half in range(2):
                        time=(tick-1+half)*dt
                        wave,delta=kick(wave,delta,host+dbase*time+common,gain*(extra+dextra*time)+reaction,phase)
                        if not half:
                            wave,delta=kin.radial(wave,delta,net);wave,delta=kin.angular(wave,delta,net);wave,delta=kin.radial(wave,delta,net)
                            common=solve(abs(wave)**2);reaction=solve(net)
                    if ch==1 and tick==32:assert not np.any(delta) and not np.any(reaction)
                    record.add(tick,[reaction[ix]])
                obs.value[ch]=record.value[0]
            frozenpath=HERE/f'frozen-compensation-{tag}-{key}.npz';assert digest(frozenpath)==pinned[key]
            actual=np.stack([summarize(v[::4],obs.dense[::4]) for v in obs.value])
            packet(f'nonlinear-compensated-{key}.npz',pair=actual,difference=actual[0]-actual[1])
            with np.load(frozenpath) as pred:
                pair=pred['pair'];truth=actual[0]-actual[1];estimate=pred['difference'];continuous=pred['continuous']
                for m,method in enumerate(('force','impulse')):
                    for f,frame in enumerate(('fixed','moving')):
                        for j,tail in enumerate(('inner','outer')):
                            where=(m,f,j);ref=truth[where];model=estimate[where];norm=np.linalg.norm;all_on=continuous[where]
                            frac=norm(ref)/norm(all_on);ideal=0 if m==0 else 1/6
                            law=norm(ref-ideal*all_on)/norm(all_on if m==0 else ideal*all_on)
                            proj=(ref@all_on)/(all_on@all_on)
                            out.append(dict(prep=arm,site=site,method=method,frame=frame,tail=tail,frozen_sha256=pinned[key],relative_to_all_on=frac,along_all_on=proj,leading_law_error=law,leading_law_pass=law<=.005,retarded_error=norm(model-ref)/norm(ref),relative_on_all_on_scale=norm(model-ref)/norm(all_on)))
            print('finite A/B complete',key,flush=True)
    table('compensated.csv',out)
def refine():
    rows=[]
    for tag in ('L2-h16-own','L3-h32-own'):
        freeze(tag)
        for key in ('reset_forward','reset_reverse','coupled_forward','coupled_reverse'):
            with np.load(HERE/f'frozen-compensation-{tag}-{key}.npz') as high,np.load(HERE/f'frozen-compensation-L2-h32-own-{key}.npz') as low:
                for m,kind in enumerate(('force','impulse')):
                    for f,frame in enumerate(('fixed','moving')):
                        for j,tail in enumerate(('inner','outer')):
                            idx=m,f,j;one=low['difference'][idx];two=high['difference'][idx]
                            rows.append(dict(reference=tag,key=key,observable=kind,frame=frame,tail=tail,relative_to_small_difference=np.linalg.norm(one-two)/np.linalg.norm(two),relative_to_continuous=np.linalg.norm(one-two)/np.linalg.norm(high['continuous'][idx])))
    table('compensated-refinement.csv',rows)

if __name__=='__main__':
    if sys.argv[1]=='freeze':freeze('L2-h32-own')
    elif sys.argv[1]=='run':execute()
    elif sys.argv[1]=='refine':refine()
    else:raise ValueError('use freeze/run/refine')
