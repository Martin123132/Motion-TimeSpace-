from response import *

def main():
    rg=np.random.default_rng(150231)
    mesh=Space(np.linspace(0,2,14),np.linspace(0,1,11));shape=(len(mesh.r),len(mesh.mu))
    wave=rg.normal(size=shape)+1j*rg.normal(size=shape)
    potential=rg.normal(size=shape);drive=rg.normal(size=shape);step=.006;kappa=.27;kin=Kinetic(mesh,kappa,step);phase=-.5j*step
    solve=lambda n:mesh.poisson(mesh.dr[:,None]*n)
    def full(eps,history):
        p=wave.copy()
        for tick,amp in enumerate(history):
            for half in range(2):
                common=potential+eps*amp*drive+solve(abs(p)**2)
                p*=np.exp(phase*centre(common))
                if not half:
                    delta=np.zeros_like(p);net=np.zeros_like(p.real)
                    p,delta=kin.radial(p,delta,net);p,delta=kin.angular(p,delta,net);p,delta=kin.radial(p,delta,net)
        return p
    def diff(history,part,forcing):
        states=(wave.copy(),*(np.zeros_like(wave) for ix in range(3)));counts=[np.zeros_like(wave.real) for ix in range(3)]
        for tick,amp in enumerate(history):
            for half in range(2):
                fields=[solve(n) for n in (abs(states[0])**2,*counts)]
                states=variation_kick(states,(potential+fields[0],amp*forcing+fields[1],fields[2],part[tick]*forcing+fields[3]),phase)
                if not half:states=kinetic_step(kin,states,counts)
        return states,counts
    def rel(one,two):return np.linalg.norm(one-two)/np.linalg.norm(two)
    hist=np.array([1.,1.,1.,1.]);early=np.array([1.,1.,0.,0.]);late=hist-early
    states,counts=diff(hist,early,drive)
    other,remaining=diff(late,late,drive)
    assert rel(counts[2]+remaining[0],counts[0])<1e-12
    assert rel(states[3]+other[1],states[1])<1e-12
    assert rel(full(0,hist),states[0])<1e-14
    null,nulld=diff(hist,early,np.ones_like(drive))
    assert all(not np.any(z) for z in (*null[1:],*nulld))
    out=[];previous_error=None
    for eps in (.8,.4,.2,.1):
        plus=full(eps,hist);minus=full(-eps,hist)
        nplus=abs(plus)**2;nminus=abs(minus)**2
        one=(nplus-nminus)/(2*eps);two=(nplus+nminus-2*abs(states[0])**2)/(2*eps**2)
        errors=[rel(one,counts[0]),rel(two,counts[1])]
        direct=rel(eps*counts[0]+eps**2*counts[1],nplus-abs(states[0])**2)
        if previous_error is not None:
            assert all(3.5 < a/b < 4.5 for a,b in zip(previous_error,errors)),(previous_error,errors)
        out.append(dict(amplitude=eps,centered_first=errors[0],centered_second=errors[1],second_order_relative_to_finite=direct))
        previous_error=errors
    assert max(errors)<.005
    table('controls.csv',out);print(out[-1])
if __name__=='__main__':main()
