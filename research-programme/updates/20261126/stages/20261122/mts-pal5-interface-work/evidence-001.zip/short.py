import json
import sys
from forces import np,HOME,Material,load,make,probes,GM,SIZE,CONV,read,table,record,sha
from crossing import advance

def norms(points):return np.linalg.norm(points,axis=1)
def steps(field,points):
    rad=norms(points);grids=[field.edges,field.seg.rad];dist=np.min([np.min(abs(rad[:,None]-g[None,:]),axis=1) for g in grids],axis=0)
    eps=np.minimum(.00002,dist*.25)
    if np.any(eps<1e-9):raise ValueError('at radial knot, no unique numerical derivative')
    return eps
def derivative(field,points,directions,step):
    expand=step[:,None]*directions
    plus=field.components(0,points+expand);minus=field.components(0,points-expand)
    return np.array([(a-b)/(2*step[:,None]) for a,b in zip(plus,minus)])
def prediction(field,centre,multiplier):
    pos,velocity,keys=probes();points=pos+centre[:3]
    base=field.components(0.,centre[None,:3]);forces=field.components(0.,points)
    b=np.array([out-init for out,init in zip(forces,base)])
    inside=-GM*pos/(norms(pos)**2+SIZE**2)[:,None]**1.5
    du=derivative(field,points,velocity/norms(velocity)[:,None],steps(field,points)*multiplier)
    component=(np.sum((inside+b.sum(axis=0))*b,axis=2)+norms(velocity)*np.sum(velocity*du,axis=2))/CONV**2
    power=np.sum(velocity*b,axis=2)/CONV**2
    tensor=np.array([derivative(field,centre[None,:3],axis[None,:],steps(field,centre[None,:3])*multiplier)[:,0,:] for axis in np.eye(3)]).transpose(1,0,2)
    c=np.sum(tensor*tensor.sum(axis=0),axis=(1,2))/CONV**2
    plain=np.sum(tensor*tensor,axis=(1,2))/CONV**2
    rows=[]
    for shell in (1,2,3):
        keep=np.array([k[0]==shell for k in keys])
        for idx,name in enumerate(('ordinary','added','total')):
            finite=np.mean(component[idx,keep]) if idx<2 else np.sum(component[:,keep],axis=0).mean()
            rate=power[idx,keep] if idx<2 else power[:,keep].sum(axis=0)
            assert abs(rate.mean())<1e-11*max(1e-10,abs(rate).max())
            scale=(shell*SIZE)**2/3
            rows.append(dict(shell=shell,source=name,initial_mean_power=rate.mean(),finite=finite,
               linear=scale*(c[idx] if idx<2 else c.sum()),diagonal_only=scale*(plain[idx] if idx<2 else plain.sum()),
               min_spatial_derivative_step_pc=multiplier*steps(field,points[keep]).min()*1000))
    return rows

def run(tag,action):
    factor,step,_=tag.split('-');mat=Material();rows=[];test=[];verdict=[]
    if action=='test':
        freeze=json.loads((HOME/('short-freeze-'+tag+'.json')).read_bytes())
        for name,digest in freeze.items():assert sha(HOME/name)==digest
        preds=read('early-predicted-'+tag+'.csv')
    for arm in ('reset','coupled'):
        original=load(int(factor),int(step),arm)[:1]
        for model in (('ordinary',) if arm=='reset' else ())+('forward','reverse','static','mean'):
            case=model if model=='ordinary' else arm+'_'+model
            receipt=json.loads((HOME/('done-'+tag+'-'+case+'.json')).read_bytes())
            archive='hist-'+tag+'-'+case+'.npz';assert sha(HOME/archive)==receipt['products'][archive]
            with np.load(HOME/archive) as data:centre=data['centre'][0]
            field=make(original,mat,model)[0]
            if action=='predict':
                first=prediction(field,centre,1.);half=prediction(field,centre,.5)
                for a,b in zip(first,half):
                    diff=abs(a['finite']-b['finite'])/max(abs(b['finite']),1e-18)
                    assert diff<.005
                    rows.append(dict(case=case,**b,fd_refinement=diff))
            else:
                expected=[r for r in preds if r['case']==case]
                pos,velocity,keys=probes();state=np.zeros((len(pos)+1,8));state[:,:6]=centre
                state[1:,:3]+=pos;state[1:,3:6]+=velocity
                coeffs=[]
                for duration in (.08,.04,.02,.01):
                    events=[];last=advance(field,0.,duration,state,4,True,events)
                    work=last[1:,6:]/CONV**2;values=[]
                    for r in expected:
                        mask=np.array([str(k[0])==r['shell'] for k in keys]);average=work[mask].mean(axis=0)
                        w=dict(ordinary=average[0],added=average[1],total=average.sum())[r['source']]
                        observed=2*w/duration**2;value=float(r['finite']);values.append(observed)
                        test.append(dict(case=case,duration=duration,shell=r['shell'],source=r['source'],mean_work=w,
                           inferred=observed,frozen=value,absolute_error=observed-value,faces=len(events)))
                    coeffs.append(np.array(values))
                for idx,r in enumerate(expected):
                    wanted=float(r['finite']);extrap=[2*b[idx]-a[idx] for a,b in zip(coeffs,coeffs[1:])]
                    miss=(extrap[-1]-wanted)/abs(wanted) if wanted else float(extrap[-1]!=0)
                    linear=float(r['linear'])
                    verdict.append(dict(case=case,shell=r['shell'],source=r['source'],frozen=wanted,linear=linear,
                       linear_rel=(linear-wanted)/abs(wanted) if wanted else 0,richardson=extrap[-1],relative=miss,passes=abs(miss)<.005))
        del original,field
    if action=='predict':
        name='early-predicted-'+tag+'.csv';table(name,rows)
        record('short-freeze-'+tag+'.json',{p:sha(HOME/p) for p in (name,'EARLY-WORK.md','short.py','PROTOCOL.md')})
    else:
        table('early-tested-'+tag+'.csv',test);table('early-verdict-'+tag+'.csv',verdict)
        print(tag,'early Taylor comparison',sum(not r['passes'] for r in verdict),'failed /',len(verdict),flush=True)
if __name__=='__main__':run(sys.argv[1],sys.argv[2])
