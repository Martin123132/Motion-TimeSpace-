import json
import sys
from collections import Counter
from forces import HOME,SOURCE,sha,MANIFEST,read,record,table,np

CASES=('ordinary','reset_forward','reset_reverse','reset_static','reset_mean','coupled_forward','coupled_reverse','coupled_static','coupled_mean')
FIELDS=('dx','dy','dz','vx','vy','vz','end_e','delta_e','host_work','added_work')
PAIR=[(a+'_'+s,a+'_'+t) for a in ('reset','coupled') for s,t in [('forward','reverse'),('mean','static')]]
def vec(rows,key):
    return np.array([float(r[key]) for r in rows])
def packet(tag,case):
    end=tag+'-'+case
    receipt=json.loads((HOME/('done-'+end+'.json')).read_bytes())
    for name,digest in receipt['products'].items():assert sha(HOME/name)==digest
    batch=read('stars-'+end+'.csv');assert [int(r['probe']) for r in batch]==list(range(72))
    with np.load(HOME/('hist-'+end+'.npz')) as saved:
        frames=saved['probes'];clock=saved['time'];centre=saved['centre'];assert frames.shape==(121,72,4) and centre.shape==(121,6)
        assert np.all(np.isfinite(frames)) and np.all(np.diff(clock)>0) and abs(clock[-1]-111.158776)<1e-8
    if receipt['cross_count']:
        events=read('faces-'+end+'.csv');assert len(events)==receipt['cross_count']
        keys=[(r['leg'],int(r['body']),r['face'],int(r['orientation'])) for r in events]
    else:keys=[]
    vector=np.array([vec(batch,s) for s in FIELDS]).T
    assert np.allclose(frames[-1,:,0],vector[:,6],rtol=0,atol=1e-14)
    assert np.max(abs(frames[-1,:,1:3]-vector[:,8:10]))<1e-13
    return batch,frames,clock,vector,receipt,keys
def ratio(aa,bb,tiny=1e-20):
    den=np.linalg.norm(bb)
    return float(np.linalg.norm(aa-bb)/den) if den>tiny else (0. if np.linalg.norm(aa-bb)<tiny else None)
def series(arr):
    return {'position':arr[:,:3],'velocity':arr[:,3:6],'energy':arr[:,6],'net_work':arr[:,8]+arr[:,9],'ordinary_work':arr[:,8],'added_work':arr[:,9]}
def calc(tags,stem):
    earlier={};summaries=[];compare=[];by_shell=[];contrasts=[];faceledger=[];timepairs=[];disagreements=[];audits=[]
    for prefix,filename in [('','native-probes-4-2.csv')]:
        assert sha(SOURCE/filename)==MANIFEST[filename]
        with (SOURCE/filename).open(newline='') as stream:
            import csv
            old=list(csv.DictReader(stream))
    for tag in tags:
        cases={case:packet(tag,case) for case in CASES}
        this={}
        for case,(stars,hist,clock,arr,r,faces) in cases.items():
            this[case]=series(arr)
            assert max([abs(float(x['work_error'])) for x in stars])<1e-5
            flags=np.array([[int(s['end_positive']),int(s['ever_sampled']),int(s['returned_sampled'])] for s in stars])
            original=[s for s in old if s['case']==case]
            original=np.array([[int(float(s['energy'])>0),int(s['ever']),int(s['returned'])] for s in original])
            energy,host,wave=hist[:,:,0],hist[:,:,1],hist[:,:,2]
            diff=energy-energy[:1];mismatch=diff-host-wave
            summaries.append(dict(tag=tag,case=case,centre_return=r['centre_return'],centre_pass=r['centre_return']<1e-9,
                 max_rel_binding_work=r['max_relative_to_initial_binding'],history_work_relative=ratio(host+wave,diff),
                 max_absolute_residual=np.max(abs(mismatch)),samp_label_differences=np.sum(np.any(flags!=original,axis=1)),
                 faces=r['cross_count'],max_face_residual=r['maximum_face_residual'],
                 same_centre_events=all(c['same'] for c in r['centre_crossings']),
                 max_centre_event_time_error=max((c['time_error'] or 0 for c in r['centre_crossings']),default=0.)))
            if not (2<r['coverage'][0][0]<r['coverage'][0][1]<35 and 12<r['coverage'][1][0]<r['coverage'][1][1]<29):raise ValueError(r['coverage'])
            for shell in (1,2,3):
                ix=np.flatnonzero(vec(stars,'shell')==shell);end=energy[-1,ix];e0=energy[0,ix]
                crossings=[];recaptures=[]
                for i in ix:
                    pos=np.flatnonzero(energy[:,i]>0)
                    if len(pos):
                        j=pos[0];crossings.append((clock[j],host[j,i],wave[j,i],-energy[0,i]))
                        neg=np.flatnonzero(energy[j+1:,i]<=0)
                        if len(neg):
                            k=j+1+neg[0];peak=j+int(np.argmax(energy[j:k+1,i]))
                            recaptures.append((host[k,i]-host[peak,i],wave[k,i]-wave[peak,i],energy[k,i]-energy[peak,i]))
                first=np.array(crossings);ret=np.array(recaptures)
                by_shell.append(dict(tag=tag,case=case,shell=shell,n=len(ix),ever=len(first),end=int(sum(end>0)),returned=len(ret),
                    mean_e0=e0.mean(),mean_change=np.mean(end-e0),mean_host_work=np.mean(host[-1,ix]),mean_added_work=np.mean(wave[-1,ix]),
                    mean_first_positive_time=first[:,0].mean() if len(first) else '',first_positive_host_work=first[:,1].mean() if len(first) else '',
                    first_positive_added_work=first[:,2].mean() if len(first) else '',mean_first_binding=first[:,3].mean() if len(first) else '',
                    return_from_peak_host_work=ret[:,0].mean() if len(ret) else '',return_from_peak_added_work=ret[:,1].mean() if len(ret) else ''))
        for a,b in PAIR:
            star_a,ha,_,va,_,_=cases[a];star_b,hb,_,vb,_,_=cases[b]
            key=a+'__'+b;this[key]=series(va-vb)
            et=(ha[:,:,0]-ha[:1,:,0])-(hb[:,:,0]-hb[:1,:,0]);wa=ha[:,:,1]-hb[:,:,1];wb=ha[:,:,2]-hb[:,:,2]
            audits.append(dict(tag=tag,pair=key,delta_work_vs_delta_E=ratio(wa+wb,et),delta_final_work_vs_delta_E=ratio((wa+wb)[-1],et[-1])))
            for shell in (1,2,3):
                idx=np.flatnonzero(vec(star_a,'shell')==shell)
                shifts=1000*np.linalg.norm((va-vb)[idx,:3],axis=1);diffs=[];ranges=[]
                for i in idx:
                    if star_a[i]['first_hi'] and star_b[i]['first_hi']:
                        alo,ahi,blo,bhi=[float(row[k]) for row,k in [(star_a[i],'first_low'),(star_a[i],'first_hi'),(star_b[i],'first_low'),(star_b[i],'first_hi')]]
                        ranges.append((alo-bhi,ahi-blo));diffs.append((alo+ahi-blo-bhi)/2)
                flags=lambda stars,i:(stars[i]['end_positive'],stars[i]['ever'],stars[i]['returns'])
                contrasts.append(dict(tag=tag,pair=key,shell=shell,rms_position_pc=np.mean(shifts**2)**.5,max_position_pc=max(shifts),
                   rms_energy=np.mean(et[-1,idx]**2)**.5,mean_net_work=np.mean(et[-1,idx]),mean_host_contrast=np.mean(wa[-1,idx]),
                   mean_added_contrast=np.mean(wb[-1,idx]),flag_changes=sum(flags(star_a,i)!=flags(star_b,i) for i in idx),
                   first_common=len(diffs),separated_brackets=sum(lo>0 or hi<0 for lo,hi in ranges),
                   max_abs_first_shift_bound=max((max(abs(lo),abs(hi)) for lo,hi in ranges),default='')))
        if earlier:
            for name,metrics in this.items():
                for k,v in metrics.items():
                    err=ratio(earlier[name][k],v)
                    compare.append(dict(tag=tag,case=name,quantity=k,relative=err,passes=err is not None and err<.005))
            for c in CASES:
                eq=Counter(previous_cases[c][-1])==Counter(cases[c][-1])
                faceledger.append(dict(tag=tag,case=c,same_crossing_multiset=eq))
        earlier=this;previous_cases=cases
    for name,rows in [('work-summary',summaries),('work-shells',by_shell),('work-contrasts',contrasts),('work-convergence',compare),
                      ('paired-work-closure',audits),('face-replay',faceledger)]:
        if rows:table(stem+'-'+name+'.csv',rows)
    record(stem+'-verdict.json',dict(tags=tags,checks=len(compare),failed=[r for r in compare if not r['passes']],
        centre_failures=[(r['tag'],r['case'],r['centre_return']) for r in summaries if not r['centre_pass']],
        max_individual_balance=max(float(r['max_rel_binding_work']) for r in summaries),
        worst_paired_history_closure=max(r['delta_work_vs_delta_E'] for r in audits),
        sampled_label_mismatches=int(sum(r['samp_label_differences'] for r in summaries)),face_multiset_misses=[r for r in faceledger if not r['same_crossing_multiset']]))
if __name__=='__main__':calc(sys.argv[2:],sys.argv[1])
