from forces import np,GM,SIZE

def rhs(field,time,state,cells,mass=GM,size=SIZE):
    host,wave=field.components(time,state[:,:3],cells);out=np.zeros_like(state)
    out[:,:3]=state[:,3:6];out[:,3:6]=host+wave
    if len(state)>1:
        dx=state[1:,:3]-state[:1,:3];dv=state[1:,3:6]-state[:1,3:6]
        out[1:,3:6]-=mass*dx/(np.sum(dx*dx,axis=1)+size**2)[:,None]**1.5
        out[1:,6]=np.sum(dv*(host[1:]-host[:1]),axis=1);out[1:,7]=np.sum(dv*(wave[1:]-wave[:1]),axis=1)
    return out
def rk(field,time,state,step,cells,params):
    start=rhs(field,time,state,cells,*params);middle=time+.5*step
    second=rhs(field,middle,state+.5*step*start,cells,*params)
    third=rhs(field,middle,state+.5*step*second,cells,*params)
    end=rhs(field,time+step,state+step*third,cells,*params)
    return state+(step/6)*(start+2*(second+third)+end)

def hits(field,start,end,h,cells):
    pos=start[:,:3];new=end[:,:3];vel=start[:,3:6]*h;vnew=end[:,3:6]*h;dpos=new-pos
    rad=np.linalg.norm(pos,axis=1);limit=np.maximum.reduce([np.linalg.norm(vel/3,axis=1),np.linalg.norm(dpos,axis=1),np.linalg.norm(dpos-vnew/3,axis=1)])+1e-12
    candidates=[]
    for polarity,mask,edges in ((-1,(rad-limit<=field.left[cells])&(cells>0),field.left),
                                (1,(rad+limit>=field.edges[cells])&(cells<len(field.edges)-1),field.edges)):
        for idx in np.flatnonzero(mask):
            edge=edges[cells[idx]];delta=dpos[idx]
            coeffs=np.stack([pos[idx],vel[idx],3*delta-2*vel[idx]-vnew[idx],vel[idx]+vnew[idx]-2*delta])
            polynomial=sum(np.convolve(comp,comp) for comp in coeffs.T)
            polynomial[0]=(rad[idx]-edge)*(rad[idx]+edge)
            for sol in np.roots(polynomial[::-1]):
                if abs(sol.imag)>1e-8 or not 1e-10<sol.real<=1+2e-10:continue
                frac=min(1.,sol.real);derivative=np.polynomial.polynomial.polyval(frac,np.arange(1,7)*polynomial[1:])
                if polarity*derivative>1e-14:
                    candidates.append((frac,idx,polarity,edge))
    return sorted(candidates)

def advance(field,start,finish,state,n,aligned,events,visit=None,params=(GM,SIZE)):
    cells=field.edges.searchsorted(np.linalg.norm(state[:,:3],axis=1))
    for begin,until in zip((clock:=np.linspace(start,finish,n+1))[:-1],clock[1:]):
        time=begin
        for split in range(300):
            h=until-time
            if abs(h)<2e-14:break
            trial=rk(field,time,state,h,cells if aligned else None,params)
            found=hits(field,state,trial,h,cells) if aligned else []
            if not found:
                if aligned:
                    rr=np.linalg.norm(trial[:,:3],axis=1)
                    if np.any(rr<field.left[cells]-2e-11) or np.any(rr>field.edges[cells]+2e-11):raise ValueError('undetected cell exit')
                if visit is not None:visit(time+h,trial)
                state=trial;break
            frac,idx,direction,edge=found[0];dt=frac*h
            for iteration in range(7):
                part=rk(field,time,state,dt,cells,params);position=part[idx,:3]
                radius=np.linalg.norm(position);res=radius-edge;slope=position@part[idx,3:6]/radius
                if abs(res)<8e-14:break
                assert abs(slope)>1e-8
                dt-=res/slope
                if dt/h>1 and dt/h<1+2e-10:dt=h
                assert 0<dt/h<=1+1e-12,(res,slope,dt,h)
            else:raise RuntimeError('face root did not converge')
            endtime=time+dt
            rr=np.linalg.norm(part[:,:3],axis=1)
            hits_now=[(j,pol,face) for f,j,pol,face in found if abs(rr[j]-face)<3e-12 and abs((f-frac)*h)<1e-8]
            assert (idx,direction,edge) in hits_now
            if np.any(rr<field.left[cells]-3e-12) or np.any(rr>field.edges[cells]+3e-12):raise RuntimeError('missed earlier face')
            for body,pol,face in hits_now:
                crossing_speed=part[body,:3]@part[body,3:6]/rr[body]
                assert pol*crossing_speed*np.sign(h)>0
                events.append((endtime,int(body),float(face),int(pol),float(rr[body]-face),float(crossing_speed)))
                cells[body]+=pol
            if visit is not None:visit(endtime,part)
            time=endtime;state=part
        else:raise RuntimeError('substep limit')
    return state
