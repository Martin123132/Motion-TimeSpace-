import json
import sys
from scipy.special import roots_legendre
from short import derivative,steps
from forces import HOME,Material,load,make,GM,SIZE,CONV,np,record,table,sha,read
SOURCES=('ordinary','added','total')
def radial(x,order):
    z,w=roots_legendre(order);r=x*(1+z)/2;prob=w*r**2/(1+r**2)**2.5;prob/=prob.sum()
    variance=GM/(6*SIZE*np.sqrt(1+r*r));psi_prime=GM/SIZE*r/(1+r*r)**1.5
    return r*SIZE,prob,variance,r*psi_prime
def cloud(x,order):
    r,weights,sigma,_=radial(x,order)
    axes=np.r_[np.eye(3),-np.eye(3)]
    pos=np.broadcast_to(r[:,None,None,None]*axes[None,:,None,:],(order,6,6,3)).reshape(-1,3)
    vel=np.broadcast_to(np.sqrt(3*sigma)[:,None,None,None]*axes[None,None,:,:],(order,6,6,3)).reshape(-1,3)
    return np.column_stack([pos,vel,np.zeros((len(vel),2))]),np.repeat(weights/36,36)
def solve_in_affine(tide,initial,h):
    def func(state):
        x=state[:,:3];vel=state[:,3:6];both=x@tide[0].T,x@tide[1].T
        cluster=-GM*x/(np.sum(x*x,axis=1)+SIZE**2)[:,None]**1.5
        return np.column_stack([vel,cluster+both[0]+both[1],np.sum(vel*both[0],axis=1),np.sum(vel*both[1],axis=1)])
    state=initial.copy()
    for i in range(4):
        dt=h/4;one=func(state);two=func(state+dt*one/2);three=func(state+dt*two/2);four=func(state+dt*three)
        state+=dt/6*(one+2*two+2*three+four)
    return state
def predict():
    rows=[];material=Material();matrices={}
    for arm in ('reset','coupled'):
        old=load(4,2,arm)[:1]
        for model in (('ordinary',) if arm=='reset' else ())+('forward','reverse','static','mean'):
            case=model if model=='ordinary' else arm+'_'+model
            with np.load(HOME/('hist-4-2-A-'+case+'.npz')) as bank:pos=bank['centre'][:1,:3]
            field=make(old,material,model)[0]
            tide=np.array([derivative(field,pos,axis[None,:],steps(field,pos)*.5)[:,0] for axis in np.eye(3)]).transpose(1,2,0)
            assert np.linalg.norm(tide-tide.transpose(0,2,1))<1e-7*np.linalg.norm(tide)
            matrices[case]=tide.tolist()
            for aperture in (1,2,3):
                x=float(aperture);y=x/np.sqrt(1+x*x);r2=3*SIZE**2*(np.arcsinh(x)-y-y**3/3)/y**3
                stress=GM/(6*SIZE)*(1+x*x)**(-1.5)
                r,w,sig,vc2=radial(x,32);test_r=w@(r*r);test_stress=w@(sig-vc2/3)
                assert abs(test_r/r2-1)<1e-11 and abs(test_stress/stress-1)<1e-11
                for k,name in enumerate(SOURCES):
                    component=tide[k] if k<2 else tide.sum(axis=0)
                    tensor=r2*np.sum(tide.sum(axis=0)*component)/(3*CONV**2)
                    pressure=stress*np.trace(component)/CONV**2
                    rows.append(dict(case=case,aperture=aperture,source=name,tensor_square=tensor,pressure_trace=pressure,
                                     full=tensor+pressure,rms_radius_pc=1000*np.sqrt(r2)))
        del old,field
    record('affine-tensors.json',matrices);table('aperture-predictions.csv',rows)
    record('aperture-freeze.json',{n:sha(HOME/n) for n in ('aperture-predictions.csv','affine-tensors.json','APERTURE.md','aperture.py')})
def test():
    for name,digest in json.loads((HOME/'aperture-freeze.json').read_bytes()).items():assert sha(HOME/name)==digest
    matrices=json.loads((HOME/'affine-tensors.json').read_bytes());rows=read('aperture-predictions.csv');out=[]
    for case,tensor in matrices.items():
        tide=np.array(tensor)
        for aperture in (1,2,3):
            state,w=cloud(aperture,24)
            moments=[]
            for h in (.04,.02,.01):
                full=solve_in_affine(tide,state,h);values=(w@full[:,6:])*(2/(h*h*CONV**2))
                moments.append(np.r_[values,values.sum()])
            estimate=2*moments[-1]-moments[-2]
            for j,name in enumerate(SOURCES):
                row=next(r for r in rows if r['case']==case and int(r['aperture'])==aperture and r['source']==name)
                value=float(row['full']);err=abs(estimate[j]-value)/abs(value) if value else float(estimate[j]!=0)
                out.append(dict(**row,test=estimate[j],rel_error=err,passes=err<.005))
    table('aperture-test.csv',out);print('Aperture comparisons:',len(out),'worst',max(r['rel_error'] for r in out),flush=True)
if __name__=='__main__':predict() if sys.argv[1]=='predict' else test()
