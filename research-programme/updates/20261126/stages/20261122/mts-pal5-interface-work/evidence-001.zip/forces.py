import csv
import hashlib
import io
import json
import os
import sys
from pathlib import Path
for variable in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS'):os.environ[variable]='1'
HOME=Path(__file__).resolve().parent
SOURCE=HOME.parent/'mts-pal5-local-tides-20261122'
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
assert sha(SOURCE/'seal.json')=='bebe1235720092e12940481ff83218fc72a2c3be690335e7bd5188eaeb5e9cf5'
MANIFEST=json.loads((SOURCE/'seal.json').read_bytes())
for name in ('native.py','tides.py','mass_controls.py','native-ordinary.npz','source-replay.json'):
    assert sha(SOURCE/name)==MANIFEST[name]
sys.path.insert(0,str(SOURCE))
from native import Material,NativeSegment
from mass_controls import transform
from tides import load,initial,probes,observe,CONV,GM,SIZE,np,Segment,host
from scipy.special import legendre_p_all
def keep(name,data):
    path=HOME/name
    if path.exists():
        if path.read_bytes()!=data:raise ValueError('Existing result changed: '+name)
    else:
        with path.open('xb') as output:output.write(data)
def record(name,value):keep(name,(json.dumps(value,sort_keys=True,indent=2,allow_nan=False)+'\n').encode())
def table(name,rows):
    if not rows:raise ValueError('empty table: '+name)
    stream=io.StringIO(newline='');writer=csv.DictWriter(stream,fieldnames=list(rows[0]),lineterminator='\n')
    writer.writeheader();writer.writerows(rows);keep(name,stream.getvalue().encode())
def read(name):
    with (HOME/name).open(newline='') as stream:return list(csv.DictReader(stream))
class Field:
    def __init__(self,seg,mat,snaps,model):
        self.seg,self.mat,self.snaps,self.model=seg,mat,snaps,model
        self.end=seg.end;self.edges=mat.right;self.left=mat.left
        self.empty=model=='ordinary'
        if not self.empty:self.archive=seg.tables['reverse' if model=='reverse' else 'forward']
        self.minr,self.maxr=np.inf,0.
    def components(self,time,xyz,cells=None):
        rad=np.linalg.norm(xyz,axis=1);unit=xyz/rad[:,None];mu=unit[:,2]
        self.minr=min(self.minr,rad.min());self.maxr=max(self.maxr,rad.max())
        grid=self.seg.rad
        if min(rad)<=grid[0] or max(rad)>=grid[-1]:raise ValueError('Outside original wave/ordinary support')
        cell=self.edges.searchsorted(rad) if cells is None else cells
        u=2*(rad-self.left[cell])/self.mat.width[cell]-1
        start,stop=[self.mat.co[s] for s in self.snaps];frac=time/self.end
        if not -1e-12<=frac<=1+1e-12:raise ValueError('Outside source interval')
        base=legendre_p_all(start[0].shape[1]-1,u)[0].T
        host_rad=[]
        for order in (0,1):
            aa,bb=start[order],stop[order];coeff=(1-frac)*aa[cell]+frac*bb[cell]
            value=np.einsum('bi,bil->bl',base[:,:aa.shape[1]],coeff)
            host_rad.append((value if order==0 else value-host_rad[0])/rad[:,None])
        poly,dpoly=legendre_p_all(68,mu,diff_n=1)[:,::2,:].transpose(0,2,1)
        def acc(val,dr):
            radial=np.sum(poly*dr,axis=1);axial=np.sum(dpoly*val,axis=1)/rad
            out=(radial-mu*axial)[:,None]*unit;out[:,2]+=axial
            return -CONV**2*out
        ordinary=acc(*host_rad)
        if self.empty:return ordinary,np.zeros_like(ordinary)
        ridx=grid.searchsorted(rad)-1;width=grid[ridx+1]-grid[ridx];scaled=((rad-grid[ridx])/width)[:,None];h=width[:,None]
        nodes,order=np.unique(np.r_[ridx,ridx+1],return_inverse=True)
        if self.model=='static':value=self.archive[0,nodes,...,0]
        else:
            times=self.seg.times;idx=int(np.clip(times.searchsorted(time)-1,0,len(times)-2));span=times[idx+1]-times[idx];p=(time-times[idx])/span
            aa=self.archive[idx,nodes];bb=self.archive[idx+1,nodes]
            value=(1-p)**2*(1+2*p)*aa[...,0]+p*p*(3-2*p)*bb[...,0]+span*p*(1-p)*((1-p)*aa[...,1]-p*bb[...,1])
        lower,upper=np.split(value[order],2);d0=h*lower[...,1];delta=upper[...,0]-lower[...,0]
        second=3*delta-h*(2*lower[...,1]+upper[...,1]);third=-2*delta+h*(lower[...,1]+upper[...,1])
        val=lower[...,0]+scaled*(d0+scaled*(second+scaled*third))
        dr=(d0+scaled*(2*second+3*scaled*third))/h
        return ordinary,acc(val,dr)

def make(original,material,model):
    result=[]
    for seg,epoch,snaps in zip(original,(-1,0),((586,590),(590,600))):
        base=transform(seg,model,epoch) if model in ('static','mean') else seg
        result.append(Field(base,material,snaps,model))
    return result
