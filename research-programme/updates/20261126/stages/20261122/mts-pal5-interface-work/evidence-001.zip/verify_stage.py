import json
from assess import CASES, packet
from forces import HOME, SOURCE, MANIFEST, np, read, record, sha


def load_json(name):
    return json.loads((HOME / name).read_bytes())


def verify_map(directory, manifest):
    for name, digest in manifest.items():
        assert sha(directory / name) == digest, name


def validate():
    verify_map(SOURCE, MANIFEST)
    for frozen in [*HOME.glob("short-freeze-*.json"), HOME / "aperture-freeze.json"]:
        verify_map(HOME, load_json(frozen.name))
    receipts = sorted(HOME.glob("done-*.json"))
    assert len(receipts) == 63
    for receipt in receipts:
        data = load_json(receipt.name)
        verify_map(HOME, data["inputs"])
        verify_map(HOME, data["products"])
    maximum_face_residual = max(load_json(receipt.name)["maximum_face_residual"] or 0 for receipt in receipts)
    assert maximum_face_residual < 1e-10
    result = dict(receipts=len(receipts), predecessor_files=len(MANIFEST), max_face_residual_kpc=maximum_face_residual)
    for series, expected, misses, centre_misses in (("aligned",156,0,16),("unaligned",78,24,0),("highmass",78,0,8)):
        report = load_json(series+"-verdict.json")
        metrics = read(series+"-work-convergence.csv")
        assert len(metrics) == report["checks"] == expected
        assert all((float(row["relative"]) < .005) == (row["passes"] == "True") for row in metrics)
        assert sum(row["passes"] != "True" for row in metrics) == len(report["failed"]) == misses
        assert not report["face_multiset_misses"] and len(report["centre_failures"]) == centre_misses
        result[series] = dict(refinements=expected, failed_refinements=misses, centre_return_failures=centre_misses)
        if series == "unaligned":
            continue
        kind = report["tags"][-1]
        flags_reference = None
        final_centre = []
        for case in CASES:
            stars, frames, clock, vector, receipt, crossings = packet(kind, case)
            final_centre.append(receipt["centre_return"])
            energy = frames[:, :, 0]
            ever = (energy > 0).any(axis=0)
            end = energy[-1] > 0
            returned = ((np.maximum.accumulate(energy,axis=0) > 0) & (energy <= 0)).any(axis=0)
            flags = np.stack((end, ever, returned), axis=1)
            assert np.array_equal(flags, [[int(row[key]) for key in ("end_positive","ever_sampled","returned_sampled")] for row in stars])
            if case == "ordinary":
                assert not flags.any()
                continue
            if flags_reference is None:
                flags_reference = flags
            assert np.array_equal(flags, flags_reference)
            counts = [flags[[int(row["shell"])==shell for row in stars]].sum(axis=0).tolist() for shell in (1,2,3)]
            expected_end = [0,8,18] if series=="aligned" else [0,0,6]
            expected_ever = [0,12,24] if series=="aligned" else [0,0,6]
            assert [shell[0] for shell in counts] == expected_end and [shell[1] for shell in counts] == expected_ever
        assert max(final_centre)<1e-9
        result[series].update(max_final_centre_return=max(final_centre), positive_ever_returned_by_shell=counts)
        closure = max(float(row["delta_work_vs_delta_E"]) for row in read(series+"-paired-work-closure.csv") if row["tag"]==kind)
        assert closure<.005
        result[series]["final_paired_work_relative"] = closure
    for filename, field in (("early-verdict-4-1-A.csv","relative"),("early-verdict-4-2-A.csv","relative"),("aperture-test.csv","rel_error")):
        rows=read(filename)
        errors=[abs(float(row[field])) for row in rows if row[field] not in ("","None")]
        assert len(rows)==81 and all(row["passes"]=="True" for row in rows) and max(errors)<.005
        result[filename]=dict(checks=len(rows),worst_relative=max(errors))
    diagnostic=read("ordinary-source-gauss-verdict.csv")
    caps=read("source-cap-sensitivity.csv")
    assert len(diagnostic)==14 and all(row["within_tolerance"]=="True" for row in diagnostic)
    for case,sign in (("ordinary",-1),("reset_forward",1)):
        local=[row for row in diagnostic if row["centre"]==case]
        small=min(local,key=lambda row:float(row["probe_kpc"]))
        mass=next(float(row["effective_enclosed_Msun"]) for row in local if .019<float(row["probe_kpc"])<.020)
        modes=next(float(row["represented_density_Msun_kpc3"]) for row in caps if row["case"]==case and row["cap"]=="68")
        assert sign*mass>0 and abs(float(small["effective_density"])/modes-1)<.005
        result[case+"_ordinary_flux_Msun_at_19pc"]=mass
    record("final-validation.json",result)
    assert (HOME/"RESULTS.md").is_file() and not (HOME/"__pycache__").exists()
    manifest={file.name:sha(file) for file in sorted(HOME.iterdir()) if file.is_file() and file.name!="seal.json"}
    record("seal.json",manifest)
    print(len(manifest), sha(HOME/"seal.json"))


if __name__ == "__main__":
    validate()
