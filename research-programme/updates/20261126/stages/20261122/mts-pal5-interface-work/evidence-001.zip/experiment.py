import io
import json
import sys
from forces import HOME,SOURCE,sha,read,table,record,keep,CONV,GM,SIZE,initial,probes,make,load,Material,np
from crossing import advance
FILES=('PROTOCOL.md','forces.py','crossing.py','experiment.py','unit-controls.json')
NAMES=('E','host_work','added_work','radius_pc')
def energies(state,mass,size):
    dx=state[1:,:3]-state[:1,:3];dv=state[1:,3:6]-state[:1,3:6]
    r=np.linalg.norm(dx,axis=1)
    return (.5*np.sum(dv*dv,axis=1)-mass/np.sqrt(r*r+size**2))/CONV**2,r*1000
def integrate(case,branches,tag,aligned,mass_factor=1.,size_factor=1.):
    label=tag+'-'+case;receipt=HOME/('done-'+label+'.json');hashes={f:sha(HOME/f) for f in FILES}
    if receipt.exists():
        saved=json.loads(receipt.read_bytes());assert saved['inputs']==hashes and all(sha(HOME/f)==d for f,d in saved['products'].items())
        return
    params=(GM*mass_factor,SIZE*size_factor);pieces=[];reverse_events=[]
    pos,vel=initial();state=np.zeros((1,8));state[:,:3]=pos;state[:,3:6]=vel;anchor=state.copy()
    for field in reversed(branches):
        events=[];state=advance(field,field.end,0,state,field.seg.steps,aligned,events)
        reverse_events.append(events)
    centre=state.copy();dx,dv,keys=probes()
    dx*=size_factor;dv*=np.sqrt(mass_factor/size_factor)
    ensemble=np.repeat(centre,len(dx)+1,axis=0);ensemble[1:,:3]+=dx;ensemble[1:,3:6]+=dv
    initial_e,_=energies(ensemble,*params)
    reference=initial_e.copy();ledger=[];clock=[];history=[];centretrack=[];offset=0.;peak=np.zeros_like(reference);peak_abs=np.zeros_like(reference)
    first_low=np.full(len(dx),np.nan);first_hi=first_low.copy();returns=np.zeros(len(dx),int)
    ever=np.zeros(len(dx),bool);sampleever=ever.copy();samplereturn=ever.copy();preturn=np.zeros_like(ever)
    previous=initial_e;previous_time=0.;observations=0
    def visit(t,y):
        nonlocal previous,previous_time,observations
        when=offset+t;energy,_=energies(y,*params);work=y[1:,6:].sum(axis=1)/CONV**2
        residual=abs(energy-reference-work);np.maximum(peak_abs,residual,out=peak_abs);np.maximum(peak,residual/abs(reference),out=peak)
        positive=energy>0;fresh=positive&~ever
        first_low[fresh]=previous_time;first_hi[fresh]=when
        returns[:]+=(previous>0)&~positive;ever[:]|=positive;previous=energy;previous_time=when;observations+=1
    def sample(t,y):
        e,r=energies(y,*params);sampleever[:]|=e>0;samplereturn[:]|=sampleever&(e<=0)
        history.append(np.column_stack((e,y[1:,6:]/CONV**2,r)))
        clock.append(t);centretrack.append(y[0,:6].copy())
    sample(0.,ensemble)
    centre_event_pairs=[]
    for part,(field,bins) in enumerate(zip(branches,(96,24))):
        times=np.linspace(0.,field.end,bins+1);events=[]
        for a,b in zip(times[:-1],times[1:]):
            ensemble=advance(field,a,b,ensemble,field.seg.steps//bins,aligned,events,visit,params)
            sample(offset+b,ensemble)
        backward=reverse_events[1-part]
        forward_c=[r for r in events if r[1]==0]
        back=list(reversed(backward))
        pairkeys=[(r[2],r[3]) for r in forward_c]==[(r[2],-r[3]) for r in back]
        centre_event_pairs.append(dict(segment=part,same=pairkeys,count=len(forward_c),time_error=max((abs(a[0]-b[0]) for a,b in zip(forward_c,back)),default=0.) if pairkeys else None))
        for role,packet in [('back',backward),('forward',events)]:
            for tt,body,edge,pol,res,slope in packet:
                ledger.append(dict(leg=role,segment=part,time=offset+tt,body=body,face=edge,orientation=pol,residual=res,speed=slope))
        offset+=field.end
    err=float(np.max(abs(ensemble[0,:6]-anchor[0,:6])))
    e,r=energies(ensemble,*params);stars=[]
    for idx,k in enumerate(keys):
        work=ensemble[idx+1,6:]/CONV**2
        stars.append(dict(probe=idx,shell=k[0],e0=initial_e[idx],end_e=e[idx],delta_e=e[idx]-initial_e[idx],
          host_work=work[0],added_work=work[1],work_error=e[idx]-initial_e[idx]-sum(work),max_rel_binding_error=peak[idx],
          max_abs_work_error=peak_abs[idx],radius_pc=r[idx],ever=int(ever[idx]),returns=returns[idx],
          ever_sampled=int(sampleever[idx]),returned_sampled=int(samplereturn[idx]),end_positive=int(e[idx]>0),
          first_low=first_low[idx] if ever[idx] else '',first_hi=first_hi[idx] if ever[idx] else '',
          **dict(zip(('dx','dy','dz'),ensemble[idx+1,:3]-ensemble[0,:3])),**dict(zip(('vx','vy','vz'),ensemble[idx+1,3:6]-ensemble[0,3:6]))))
    table('stars-'+label+'.csv',stars);buf=io.BytesIO();np.savez_compressed(buf,time=np.array(clock),probes=np.array(history),centre=np.array(centretrack))
    keep('hist-'+label+'.npz',buf.getvalue());products=['stars-'+label+'.csv','hist-'+label+'.npz']
    if ledger:
        table('faces-'+label+'.csv',ledger);products+=['faces-'+label+'.csv']
    report=dict(case=case,tag=tag,aligned=aligned,mass_factor=mass_factor,size_factor=size_factor,inputs=hashes,
       products={p:sha(HOME/p) for p in products},centre_return=err,centre_crossings=centre_event_pairs,accepted_visits=observations,
       maximum_face_residual=max((abs(r['residual']) for r in ledger),default=0.),cross_count=len(ledger),
       coverage=[(s.minr,s.maxr) for s in branches],max_relative_to_initial_binding=float(peak.max()),history_columns=NAMES)
    record(receipt.name,report)
    print(label,'centre',format(err,'.2g'),'work',format(max(peak),'.2g'),'events',len(ledger),flush=True)
def run(factor,step,kind='aligned',arm_pick='all',mass_factor=1.,size_factor=1.):
    assert kind in ('aligned','unresolved');mat=Material()
    tag=f'{factor}-{step}-'+('A' if kind=='aligned' else 'U')
    if mass_factor!=1. or size_factor!=1.:tag+='-m'+format(mass_factor,'.7g')+'s'+format(size_factor,'.7g')
    for arm in ('reset','coupled'):
        if arm_pick not in (arm,'all','pilot'):continue
        original=load(factor,step,arm)
        models=(('ordinary',) if arm=='reset' else ())+('forward','reverse','static','mean')
        for model in models:
            if arm_pick=='pilot' and (arm,model)!=('reset','forward'):continue
            case=model if model=='ordinary' else arm+'_'+model
            integrate(case,make(original,mat,model),tag,kind=='aligned',mass_factor,size_factor)
        del original
if __name__=='__main__':run(int(sys.argv[1]),int(sys.argv[2]),*sys.argv[3:5],*map(float,sys.argv[5:7]))
