from forces import np,GM,SIZE,CONV,load,host,make,Material,NativeSegment,initial,probes,record,transform
from crossing import advance,hits

class StepField:
    edges=np.array([1.,10.]);left=np.array([0.,1.])
    def components(self,time,xyz,cells):
        choice=self.edges.searchsorted(np.linalg.norm(xyz,axis=1)) if cells is None else cells
        force=np.zeros_like(xyz);force[:,0]=np.where(choice==0,.24,-.31)
        return force,force*0

class Uniform:
    edges=np.array([100.]);left=np.array([0.])
    def components(self,time,xyz,cells):
        val=np.broadcast_to(np.array([1e-5,-2e-6,3e-6]),xyz.shape)
        return val,-.4*val

def run():
    events=[];y=np.zeros((1,8));y[0,0]=.7;y[0,3]=.45;field=StepField()
    tc=2*.3/(.45+np.sqrt(.45**2+2*.24*.3));vc=.45+.24*tc;h=1-tc
    expected=[1+vc*h-.5*.31*h*h,vc-.31*h]
    end=advance(field,0.,1.,y,1,True,events)
    assert len(events)==1 and abs(events[0][0]-tc)<1e-12 and np.max(abs(end[0,[0,3]]-expected))<1e-12
    back=advance(field,1.,0.,end,1,True,events);assert len(events)==2 and np.max(abs(back-y))<1e-12
    noevents=advance(field,0.,1.,y,1,False,[])
    start=np.zeros((1,8));start[0,0]=.95;start[0,3]=.4;stop=start.copy();stop[0,3]=-.4
    matches=hits(field,start,stop,1.,np.array([0]))
    assert len(matches)==1 and abs(matches[0][0]-(1-np.sqrt(.5))/2)<1e-12
    dx,dv,_=probes();state=np.zeros((1+len(dx),8));state[1:,:3]=dx;state[1:,3:6]=dv
    final=advance(Uniform(),0,111.158776,state,512,True,[]);rel=final[1:,:3]-final[:1,:3]
    rate=np.linalg.norm(dv,axis=1)/np.linalg.norm(dx,axis=1);phase=(111.158776*rate)[:,None]
    target=dx*np.cos(phase)+(dv/rate[:,None])*np.sin(phase)
    analytic=max(np.linalg.norm(rel-target,axis=1)/np.linalg.norm(dx,axis=1))
    assert analytic<1e-8 and np.max(abs(final[:,6:]))==0
    errors=[];mat=Material()
    for arm in ('reset','coupled'):
        parts=load(2,1,arm)
        for model in ('ordinary','forward','reverse','static','mean'):
            branches=make(parts,mat,model)
            for field,raw,snaps in zip(branches,parts,((586,590),(590,600))):
                baseline=host(raw) if model=='ordinary' else transform(raw,model,-1 if snaps[0]==586 else 0) if model in ('static','mean') else raw
                ref=NativeSegment(baseline,mat,snaps);xyz=initial()[0]+np.array([[.01,0.,0.],[.13,-.09,.15],[-.04,.01,-.02]])
                for p in (0,.287,1.):
                    comp=field.components(field.end*p,xyz);out=ref.acc(field.end*p,xyz,'reverse' if model=='reverse' else 'forward')
                    errors.append(np.linalg.norm(sum(comp)-out)/np.linalg.norm(out))
                    if model=='ordinary':assert not np.any(comp[1])
        del parts,branches,ref,field,raw,baseline
    assert max(errors)<1e-11
    record('unit-controls.json',dict(cross_time=tc,cross_error=abs(events[0][0]-tc),back_error=float(np.max(abs(back-y))),
       unaligned_velocity_error=abs(noevents[0,3]-expected[1]),turn_crossing_detected=True,uniform_work=0.,
       isolated_orbit_relative=analytic,comparison_cases=len(errors),max_parent_force_discrepancy=max(errors)))
if __name__=='__main__':run()
