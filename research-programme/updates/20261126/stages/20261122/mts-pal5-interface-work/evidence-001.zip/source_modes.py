from forces import HOME,GM,CONV,Material,np,read,record,table
from scipy.special import eval_legendre

def run():
    mat=Material();harm=np.arange(0,69,2);samples=[];cumulative=[]
    for case in ('ordinary','reset_forward','reset_reverse','coupled_forward','coupled_reverse'):
        with np.load(HOME/('hist-4-2-A-'+case+'.npz')) as data:pos=data['centre'][0,:3]
        r=np.linalg.norm(pos);mu=pos[2]/r
        vals=mat.modal(np.array([r]),(586,590),0,2);pot,dr,d2r=[field[0] for field in vals]
        scale=eval_legendre(harm,mu)*CONV**2/(4*np.pi*(GM/4297))
        radial=(d2r+2*dr/r)*scale;angular=-harm*(harm+1)*pot*scale/r**2;source=radial+angular
        for i,power in enumerate(harm):
            samples.append(dict(case=case,r_kpc=r,mu=mu,degree=power,radial_density=radial[i],angular_density=angular[i],density=source[i]))
        for cap in (0,2,4,8,16,24,32,48,64,66,68):
            cumulative.append(dict(case=case,cap=cap,represented_density_Msun_kpc3=sum(source[harm<=cap])))
    table('source-modes.csv',samples);table('source-cap-sensitivity.csv',cumulative)
    gauss=read('ordinary-source-gauss-verdict.csv')
    for r in (r for r in cumulative if r['cap']==68 and r['case'] in ('ordinary','reset_forward')):
        direct=next(float(g['point_density']) for g in gauss if g['centre']==r['case'])
        assert abs(direct/r['represented_density_Msun_kpc3']-1)<.005
if __name__=='__main__':run()
