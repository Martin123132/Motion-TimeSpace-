from stage import *
from scipy.integrate import solve_ivp,simpson,cumulative_simpson
from scipy.interpolate import PchipInterpolator
init_seed()
from seeds import Seed
def native(model):
    seed=Seed(model,'anchorA','heavy');came=savedbank(model);epochs=came['epochs'];slots=np.array([np.argmin(abs(epochs-av)) for av in np.geomspace(.01,.05,65)])
    times=epochs[slots];assert max(abs(times/np.geomspace(.01,.05,65)-1))<1e-12
    modes=came['k'];names=came['names'].tolist();values=came['values'][:,slots];col=lambda label:values[:,:,names.index(label)]
    scale=col('a');expansion=col('H');alpha=-expansion*col('v_newtonian_cdm')/modes[:,None]**2
    curvature=col('etak')/modes[:,None];phi=curvature-expansion*alpha
    lapse2=2*col('Weyl')-modes[:,None]**2*phi
    species=list(seed.fields);pairs=[(col('delta_cdm')-3*curvature,modes[:,None]**2*alpha),
        (col('delta_baryon')-3*curvature,-expansion*col('v_newtonian_baryon'))]
    if model=='heavy':
        mean=seed.coeff['wave']/scale
        pairs.append((col('mts_drho_h')/mean-3*curvature,modes[:,None]*(col('mts_q_h')/mean+modes[:,None]*alpha)))
    den=np.stack([pair[0] for pair in pairs]);mom=np.stack([pair[1] for pair in pairs])*times
    assert np.max(abs(scale/times-1))<2e-5 and np.max(abs(expansion/(times*seed.H(times))-1))<2e-5
    return seed,times,modes,species,den,mom,lapse2
def advance(seed,times,modes,species,initial,lapse,variant,refine=1):
    coefficients=np.array([seed.coeff[key] for key in species]);first=initial.copy()
    if variant=='zero-wave-current':first[-1,1]=0
    if variant=='copy-cdm-launch':first[-1]=first[0]
    if variant=='no-baryon-force':coefficients[1]=0
    fixed=variant.startswith('prescribed');step=2 if variant.endswith('coarse') else 1
    if fixed:metric=PchipInterpolator(np.log(times[::step]),lapse[:,::step],axis=1)
    def rhs(clock,raw):
        at=np.exp(clock);hub=seed.H(at);state=raw.reshape(first.shape);out=np.empty_like(state)
        density=state[:,0];gravity=metric(clock) if fixed else -(coefficients@density)/(2*at)
        out[:,0]=-state[:,1]/(at*at*hub);out[:,1]=gravity/hub
        if seed.model=='heavy' and variant!='dust-after-launch':
            out[-1,1]+=modes**4*density[-1]/(4*at**2*seed.mass**2*hub)
        return out.ravel()
    result=solve_ivp(rhs,np.log(times[[0,-1]]),first.ravel(),t_eval=np.log(times),rtol=3e-10/refine,atol=1e-14/refine,method='DOP853',max_step=np.log(5)/(32*refine))
    assert result.success
    return result.y.reshape((*first.shape,len(times)))
def run(model):
    seed,times,modes,species,density,momentum,lapse=native(model)
    panels={'full':np.stack((density,momentum),axis=1)};first=panels['full'][:,:,:,0];coeff=np.array([seed.coeff[name] for name in species])
    for variant in (['poisson','prescribed','prescribed-coarse','no-baryon-force']+(['dust-after-launch','zero-wave-current','copy-cdm-launch'] if model=='heavy' else [])):
        panels[variant]=advance(seed,times,modes,species,first,lapse,variant)
    panels['step-check']=advance(seed,times,modes,species,first,lapse,'poisson',2)
    terms=-coeff[:,None,None]*density/(2*times);ordinary_force=terms.sum(axis=0)
    np.testing.assert_allclose(ordinary_force,-np.einsum('s,skt->kt',coeff,density)/(2*times),rtol=2e-13,atol=2e-16)
    if model=='heavy':
        qterm=modes[:,None]**4*density[-1]/(4*times**2*seed.mass**2)
        differential=momentum[-1]-momentum[0]
        forcing=qterm/seed.H(times)
        src=simpson(forcing,x=np.log(times),axis=1)
        src_coarse=simpson(forcing[:,::2],x=np.log(times[::2]),axis=1)
        slip=differential[:,-1]-differential[:,0]
        packet('metric-free-slip.npz',k=modes,initial=differential[:,0],final=differential[:,-1],measured=slip,pressure_impulse=src,coarse_impulse=src_coarse)
    packet(f'transport-{model}.npz',k=modes,epochs=times,species=species,gravity=lapse,newtonian_terms=terms,H=seed.H(times),**panels)
if __name__=='__main__':
    for model in ('cold','heavy'):run(model)
