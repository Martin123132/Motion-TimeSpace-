from stage import *
from scipy.fft import rfftn,irfftn
from scipy.interpolate import PchipInterpolator
from scipy.ndimage import binary_erosion
init_particles()
from recover import Initial,VFACT,FB,sections
from early_dynamics import growing
init_seed()
from seeds import Seed
GRID=128
def xyz(ic,ids,part,level):
    cells=2**level;offset=.5+({0:1.,1:0.,2:FB}[part])*.5*cells/8192
    birth=ic.pos[ids].astype(float)/ic.box;speed=ic.vel[ids].astype(float)*np.sqrt(ic.a)*1000/(ic.box*VFACT)
    integer=np.rint((birth-speed)*cells-offset);q=(integer+offset)/cells
    second=speed-(birth-q);first=(birth-q)-second
    assert max(np.max(abs(second),axis=0)*cells)<.5
    return integer.astype(int)%cells,q,first,second
def weighted_error(actual,pred):
    dot=lambda first,second:np.vdot(first,second).real
    return np.sqrt(dot(actual-pred,actual-pred)/dot(actual,actual)),dot(actual,pred)/np.sqrt(dot(actual,actual)*dot(pred,pred))
def run():
    ic=Initial();box=ic.box/1000/ic.h;start_a=.01;end_a=read('fire-001-0.json')['a'];parenthash=pin(PART,'initial-complete.json')
    assert sha(ic.path)==json.loads(parenthash.read_bytes())['sha256']
    linear,lspeed,quad,qspeed=growing([ic.a,start_a,end_a],ic)
    gr=linear/linear[0];rate=lspeed/linear[0];gr2=quad/quad[0];rate2=qspeed/quad[0]
    hub=ic.h*100*np.sqrt(ic.om/end_a**3+ic.ol);speedscale=end_a*hub*box
    mask=np.zeros((GRID,)*3,bool);storage={};rows=[];gasids=[];darkids=[];gerr=[];derr=[]
    lower,upper=[(lo,hi) for part,lv,lo,hi,mass in sections(ic) if lv==7][0]
    for label in ('observed','first','second'):
        storage[label]=np.zeros((2,3,GRID,GRID,GRID))
    allcoarse=[]
    for piece in range(4):
        guard();filename=f'fire-001-{piece}.npz';assert sha(HERE/filename)==read(f'fire-001-{piece}.json')['sha256']
        with np.load(HERE/filename) as ds, np.load(pin(PART,f'early-001-{piece}.npz')) as dark:
            for name,part,lv,ids,pos,vel in [
                ('coarse',2,7,ds['coarse_ParticleIDs'],ds['coarse_Coordinates'],ds['coarse_Velocities']),
                ('gas',0,13,ds['gas_ParticleIDs'],ds['gas_Coordinates'],ds['gas_Velocities']),
                ('dark',1,13,dark['ids'],dark['pos'],dark['vel'])]:
                if name=='coarse':
                    allcoarse.append(ids);selected=(ids>=lower)&(ids<upper);ids,pos,vel=ids[selected],pos[selected],vel[selected]
                assert np.all((ids>=ic.starts[part])&(ids<ic.starts[part+1]))
                key,q,one,two=xyz(ic,ids,part,lv);dx=pos.astype(float)/ic.box-q;dx-=np.rint(dx)
                displacement=(dx-one*gr[1]-two*gr2[1])*box
                velocity=vel.astype(float)*np.sqrt(end_a)
                accel1=(gr[2]-gr[1])*one*box;vel1=rate[2]*one*speedscale
                accel2=accel1+(gr2[2]-gr2[1])*two*box;vel2=vel1+rate2[2]*two*speedscale
                res=np.column_stack((displacement-accel2,velocity-vel2))
                if name=='gas':gasids.append(ids);gerr.append(res)
                if name=='dark':darkids.append(ids-ic.starts[1]);derr.append(res)
                rms=lambda arr:np.sqrt((arr*arr).sum(axis=1).mean())
                for model,coords,speed in [('first',accel1,vel1),('second',accel2,vel2)]:
                    rows.append(dict(shard=piece,population=name,model=model,rows=len(q),displacement_rms_Mpc=rms(displacement),
                        rms_residual_ckpc=1000*rms(displacement-coords),rms_residual_kms=rms(velocity-speed)))
                if name=='coarse':
                    triple=tuple(key.T);assert not mask[triple].any();mask[triple]=True
                    for label,fields in [('observed',(displacement,velocity)),('first',(accel1,vel1)),('second',(accel2,vel2))]:
                        for channel,field in enumerate(fields):
                            for axis in range(3):storage[label][channel,axis][triple]=field[:,axis]
    np.testing.assert_array_equal(np.sort(np.concatenate(allcoarse)),np.arange(ic.starts[2],ic.total))
    assert mask.sum()==2087470;table('actual-z19-particles.csv',rows)
    gasids=np.concatenate(gasids);darkids=np.concatenate(darkids)
    assert len(np.unique(gasids))==len(gasids) and len(np.unique(darkids))==len(darkids)
    common,gasloc,darkloc=np.intersect1d(gasids,darkids,assume_unique=True,return_indices=True)
    delta=np.concatenate(gerr)[gasloc]-np.concatenate(derr)[darkloc]
    record('same-cell-gas-dark.json',dict(rows=len(common),gas=len(gasids),dark=len(darkids),relative_trajectory_residual_rms_ckpc=1000*rms(delta[:,:3]) if len(common) else None,
        relative_velocity_residual_rms_kms=rms(delta[:,3:]) if len(common) else None))
    with np.load(HERE/'phase-band.npz') as ds:
        choose=ds['k']<=2.4;kmod=ds['k'][choose];axes=ds['axes'][:,choose];seed=ds['R'][choose];fire=ds['fire'][choose]
    from seed_replay import noise
    from music_power import power
    from scipy.integrate import simpson
    seed_cube=noise(95064);seed_cube-=seed_cube.mean();seed_fft=rfftn(seed_cube.reshape((256,)*3))/np.sqrt(len(seed_cube));del seed_cube
    integer=np.r_[0:64,-64:0];lattice=np.meshgrid(integer,integer,np.arange(65),indexing='ij')
    scale=2*np.pi/box;abs_k=scale*np.sqrt(sum(axis**2 for axis in lattice))
    external_ok=(abs_k>0)&np.all([abs(axis)<64 for axis in lattice],axis=0)
    original=np.zeros_like(abs_k,dtype=complex)
    shift=np.array([-16,11,-13])/128+.5/256
    original[external_ok]=seed_fft[tuple(axis[external_ok] for axis in lattice)]*np.exp(-2j*np.pi*sum(axis[external_ok]*off for axis,off in zip(lattice,shift)))*np.sqrt(power(abs_k[external_ok])/box**3)
    del seed_fft
    address=tuple(axes);wavevec=2*np.pi/box*axes;phase=np.exp(2j*np.pi*axes.sum(axis=0)*(.5+FB*.5*GRID/8192)/GRID)
    np.testing.assert_allclose(original[address],fire,rtol=2e-13,atol=1e-19)
    basis=1j*wavevec/kmod**2*phase;models={'FIRE-seed':(fire*(gr[2]-gr[1]),fire*end_a*hub*rate[2])}
    for model in ('cold','heavy'):
        source=Seed(model,'anchorA','heavy')
        with np.load(HERE/f'transport-{model}.npz') as ds:
            ip=lambda arr:PchipInterpolator(np.log(ds['k']),arr)(np.log(kmod))
            coeff=np.array([source.coeff[s] for s in ds['species']]);coeff/=coeff.sum()
            full=ds['full'];epochs=ds['epochs']
            transfer=simpson(-full[:,1]/(epochs**2*ds['H']),x=np.log(epochs),axis=-1)
            vtransfer=-LIGHT*full[:,1,:,-1]/.05
            models[model+'-all']=(seed*ip(coeff@transfer),seed*ip(coeff@vtransfer))
            for j,label in enumerate(ds['species']):
                models[model+'-'+label]=(seed*ip(transfer[j]),seed*ip(vtransfer[j]))
    eroded=mask.copy()
    for axis in range(3):
        for sign in (-1,1):eroded &= np.roll(mask,sign,axis=axis)
    diagnostics=[];leakage=[]
    allphase=np.exp(2j*np.pi*sum(lattice)*(.5+FB*.5*GRID/8192)/GRID)
    grad=1j*original*allphase/np.where(abs_k>0,abs_k**2,1)
    for maskname,use in [('native',mask),('one-layer-buffer',eroded)]:
        for channel,quantity in enumerate(('displacement_Mpc','velocity_kms')):
            spatial={label:np.stack([rfftn(field[channel,axis]*use)[address]/GRID**3 for axis in range(3)]) for label,field in storage.items()}
            for cap in (.75,1.5,2.4):
                chosen=kmod<=cap;indices=tuple(axis[chosen] for axis in axes);weight=np.sqrt(np.where(axes[2,chosen]==0,1.,2.))
                reference=spatial['observed'][:,chosen]*weight
                outside=external_ok&~((abs_k>=kmod.min())&(abs_k<=cap))
                multiplier=((gr[2]-gr[1]) if channel==0 else end_a*hub*rate[2])
                leaked=np.stack([rfftn(use*irfftn(grad*axis*scale*outside*multiplier,s=(GRID,)*3,axes=(0,1,2)))[indices] for axis in lattice])*weight
                for label in ('first','second',*models):
                    if label in spatial:pred=spatial[label][:,chosen]
                    else:
                        coeff=basis[:,chosen]*models[label][channel][chosen];pred=np.empty_like(coeff)
                        for axis in range(3):
                            cube=np.zeros((GRID,GRID,GRID//2+1),complex);cube[indices]=coeff[axis]
                            real=irfftn(cube,s=(GRID,)*3,axes=(0,1,2))*GRID**3
                            pred[axis]=rfftn(real*use)[indices]/GRID**3
                    filtered=pred*weight
                    rel,cor=weighted_error(reference,filtered)
                    diagnostics.append(dict(mask=maskname,cells=int(use.sum()),kmax=cap,quantity=quantity,model=label,
                        rms_observable=np.linalg.norm(reference),rel_error=rel,correlation=cor,rms_ratio=np.linalg.norm(filtered)/np.linalg.norm(reference)))
                    if label in models:
                        adjusted,corr=weighted_error(reference,filtered+leaked)
                        leakage.append(dict(mask=maskname,kmax=cap,quantity=quantity,model=label,
                            outside_reference_fraction=np.linalg.norm(leaked)/np.linalg.norm(reference),raw_error=rel,with_reference_error=adjusted,correlation=corr))
    table('observed-current-bands.csv',diagnostics);table('outside-band-leakage.csv',leakage)
if __name__=='__main__':run()
