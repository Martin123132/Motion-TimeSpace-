from stage import *
init_seed()
import radiation_switch as engine
from seeds import Seed, SPEC, NATIVE, source, checked, obj
def run(model):
    guard();seed=Seed(model,'anchorA','heavy');status=obj(source('runs/'+model+'/status.json'))
    for path in engine.inherited.native_hashes():checked(path,status['input_hashes'][str(path)])
    path=SPEC/'runs/projection/a225-w6-d8.npz' if model=='heavy' else NATIVE/'runs/backgrounds/cold.npz'
    params=engine.inherited.params_for(checked(path,status['source_hash']),background_boost=8.)
    assert params.DoLateRadTruncation
    params.DoLateRadTruncation=False
    background=engine.camb.get_background(params);background.Params.Accuracy.IntTolBoost=6
    epochs=np.unique(np.r_[engine.late_scales(),np.geomspace(.01,.05,65),.05*np.exp(np.arange(-2,3)*.001)])
    times=background.conformal_time(1/epochs-1,tol=1e-10)
    names=engine.camb.model.evolve_names;groups=[];arrays=[]
    for file in sorted((SPEC/'runs'/model).glob('chunk-*.npz')):
        with np.load(source(file.relative_to(SPEC).as_posix())) as src:
            nums=src['modes'];selected=nums[np.isin(nums,seed.k)]
            if not len(selected):continue
            batch=np.unique(np.r_[selected,nums.max()])
        guard();print(model,len(selected),'from',round(float(selected[0]),4),flush=True)
        block=background.get_time_evolution(batch,times,vars=names,lAccuracyBoost=4)
        arrays.extend(block[np.searchsorted(batch,selected)]);groups.extend(selected)
    order=np.argsort(groups);modes=np.array(groups)[order];assert np.array_equal(modes,seed.k)
    values=np.array(arrays)[order];assert np.isfinite(values).all()
    with np.load(pin(INF,'radiation-full-'+model+'-0.npz')) as ref:
        slots=np.searchsorted(epochs,ref['epochs']);assert np.array_equal(epochs[slots],ref['epochs'])
        checks=[]
        for name in ('delta_cdm','delta_baryon','Weyl','v_newtonian_cdm','etak')+(('mts_drho_h','mts_q_h') if model=='heavy' else ()):
            ind=names.index(name);old=ref['values'][:,:,ind];delta=values[:,slots,ind]-old
            err=np.linalg.norm(delta,axis=0)/np.maximum(np.linalg.norm(old,axis=0),1e-60)
            checks.append(dict(branch=model,column=name,maximum_epoch_rms_relative=float(err.max()),initial=float(err[slots.tolist().index(int(np.where(epochs==.01)[0][0]))])))
    table('hierarchy-replay-'+model+'.csv',checks)
    densities=background.get_background_densities(epochs,vars=['photon','neutrino','nu','cdm','baryon'])
    packet('hierarchy-'+model+'.npz',k=modes,epochs=epochs,names=names,values=values,**densities)
if __name__=='__main__':
    for model in ('cold','heavy'):run(model)

