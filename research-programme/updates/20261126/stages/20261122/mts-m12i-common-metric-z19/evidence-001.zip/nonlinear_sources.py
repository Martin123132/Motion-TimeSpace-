from stage import *
from scipy.fft import rfftn,irfftn
from scipy.interpolate import PchipInterpolator
init_seed()
from seeds import Seed
def evaluate(size,axes,kw,curvature,den,theta,metric,at,mass,sgn):
    address=tuple(axes);box=60/.702;kvec=2*np.pi/box*axes;mult=np.where(axes[2]==0,1,2)
    def real(coeff):
        grid=np.zeros((size,size,size//2+1),complex);grid[address]=coeff
        return irfftn(grid,s=(size,)*3,axes=(0,1,2),workers=1)*size**3
    def spec(field):return rfftn(field,workers=1)[address]/size**3
    density_k=curvature*den*sgn;theta_k=curvature*theta*sgn
    actual=real(density_k);vel_sq=np.zeros_like(actual);flux=np.zeros(len(kw),complex)
    grad_sq=np.zeros_like(actual) if mass else None
    for axis in kvec:
        vel=real(-1j*axis*theta_k/kw**2);vel_sq+=vel*vel
        flux-=1j*axis*spec(actual*vel)
        if mass:grad_sq+=real(1j*axis*density_k)**2
    adv=kw**2*spec(.5*vel_sq)
    newton=sgn*curvature*metric
    zero=np.zeros_like(newton);linear=zero;second=zero;higher=zero
    if mass:
        lap=real(-kw**2*density_k);assert np.min(1+actual)>0
        linear=kw**4*density_k/(4*at**2*mass**2)
        second=-kw**2*spec(-.5*actual*lap-.25*grad_sq)/(2*at**2*mass**2)
        exact=-kw**2*spec(.5*lap/(1+actual)-.25*grad_sq/(1+actual)**2)/(2*at**2*mass**2)
        higher=exact-linear-second
    norm=lambda arr:np.sqrt(mult@(abs(arr)**2))
    res=dict(box_density_min=actual.min(),box_density_max=actual.max(),density_rms=norm(density_k),continuity_quadratic_over_linear=norm(flux)/norm(theta_k),
        velocity_advection_over_gravity=norm(adv/kw)/norm(newton/kw),quantum_linear_over_gravity=norm(linear/kw)/norm(newton/kw),
        quantum_quadratic_over_gravity=norm(second/kw)/norm(newton/kw),quantum_higher_over_gravity=norm(higher/kw)/norm(newton/kw),
        quadratic_acceleration_over_linear=norm((adv+second)/kw)/norm((newton+linear)/kw))
    return res,{'continuity':flux,'advection':adv,'pressure_second':second,'pressure_higher':higher}
def run():
    with np.load(HERE/'phase-band.npz') as phase:
        use=phase['k']<=2.4;axes,kw,R=phase['axes'][:,use],phase['k'][use],phase['R'][use]
    rows=[];repeats=[];bank={}
    for model in ('cold','heavy'):
        seed=Seed(model,'anchorA','heavy')
        with np.load(HERE/f'transport-{model}.npz') as data:
            k=data['k'];ip=lambda arr:PchipInterpolator(np.log(k),arr)(np.log(kw))
            pick=0 if model=='cold' else -1;fields=data['full'][pick];metric=data['gravity']
            for slot,epoch in [(0,.01),(-1,.05)]:
                for grid in (128,160):
                    report,terms=evaluate(grid,axes,kw,R,ip(fields[0,:,slot]),ip(fields[1,:,slot])/epoch,ip(metric[:,slot]),epoch,seed.mass if model=='heavy' else 0,1)
                    rows.append(dict(branch=model,a=epoch,grid=grid,**report))
                    if grid==128:
                        other,negative=evaluate(grid,axes,kw,R,ip(fields[0,:,slot]),ip(fields[1,:,slot])/epoch,ip(metric[:,slot]),epoch,seed.mass if model=='heavy' else 0,-1)
                        for key in ('continuity','advection','pressure_second'):np.testing.assert_array_equal(negative[key],terms[key])
                        baseline=terms
                    else:
                        for key in terms:
                            norm=np.linalg.norm(baseline[key]);res=np.linalg.norm(baseline[key]-terms[key])/norm if norm else 0.
                            repeats.append(dict(branch=model,a=epoch,term=key,relative_grid_change=res))
                        for key,value in terms.items():bank[f'{model}-{epoch}-{key}']=value
    table('nonlinear-source-strength.csv',rows);table('nonlinear-grid-check.csv',repeats)
    packet('band-nonlinear-sources.npz',axes=axes,k=kw,**bank)
if __name__=='__main__':run()
