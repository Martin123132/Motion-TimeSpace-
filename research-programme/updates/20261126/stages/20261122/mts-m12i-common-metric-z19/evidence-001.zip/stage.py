import os
for key in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','BLIS_NUM_THREADS'):os.environ[key]='1'
import csv, hashlib, io, json, sys
from pathlib import Path
import numpy as np
HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
PREV=ROOT/'mts-m12i-native-lattice-inversion-20261122'
PART=ROOT/'mts-m12i-lagrangian-wave-preparation-20261122'
INF=ROOT/'mts-primordial-patch-infall-20261120'
FIRE=ROOT/'mts-fire-joint-baryon-history-20261120'
PINS={PREV:'7380ecef7cdb4f192d4b30d93f3edef4f4031a302c7f6a9e15e3a5d28de9a0b9',PART:'89a7084095576942d4eeebf14b2cf6910e07339cde320ece34c90f35e01f80bb',INF:'a9f7723564116720ba5bc03333239d8fc0f106a6c2f14ca052f94e822aee2467',FIRE:'19c78eaa158a766bd409c0a64504788b1346542eccee37c004083a918c480d67'}
def sha(path):
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
def guard():assert __debug__ and not any((loc/'STOP-REQUESTED').exists() for loc in (ROOT,HERE,*PINS))
def pin(folder,name):
    guard();seal=folder/'seal.json';assert sha(seal)==PINS[folder];doc=json.loads(seal.read_bytes());path=folder/name
    assert sha(path)==doc.get('cache' if name.startswith('raw-cache/') else 'files',doc)[name],path
    return path
def keep(name,raw):
    guard();path=HERE/name
    if path.exists():assert path.read_bytes()==raw,path
    else:
        with path.open('xb') as stream:stream.write(raw)
def record(name,doc):keep(name,(json.dumps(doc,sort_keys=True,allow_nan=False,indent=2)+'\n').encode())
def packet(name,**values):
    buf=io.BytesIO();np.savez_compressed(buf,**values);keep(name,buf.getvalue())
def table(name,rows):
    buf=io.StringIO();writer=csv.DictWriter(buf,rows[0].keys(),lineterminator='\n');writer.writeheader();writer.writerows(rows);keep(name,buf.getvalue().encode())
def read(name):return json.loads((HERE/name).read_bytes())
def savedbank(model):
    with np.load(HERE/f'hierarchy-{model}.npz') as src:return {name:src[name] for name in src}
def init_seed():
    for name in ('seeds.py','radiation_switch.py','native_balance.py','linear_control.py','matched_hierarchy.py','spectral.py'):pin(INF,name)
    sys.path.insert(0,str(INF))
def init_particles():
    for folder,names in [(PREV,('recover.py','early_dynamics.py')),(PART,('local_io.py','initial_file.py','trace.py','music_power.py'))]:
        for name in names:pin(folder,name)
    sys.path.insert(0,str(PREV));sys.path.insert(0,str(PART))
LIGHT=299792.458

