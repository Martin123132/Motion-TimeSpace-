from stage import *
def rows(name):
    with (HERE/name).open(newline='') as stream:return list(csv.DictReader(stream))
def run():
    guard();assert not any(item.is_dir() for item in HERE.iterdir())
    for folder,sha256 in PINS.items():assert sha(folder/'seal.json')==sha256
    controls=rows('actual-z19-particles.csv');reads=[read(f'fire-001-{j}.json') for j in range(4)]
    for idx,doc in enumerate(reads):
        assert sha(HERE/f'fire-001-{idx}.npz')==doc['sha256']
        assert doc['url']==json.loads(pin(PART,f'early-001-{idx}.json').read_bytes())['url']
    assert sum(doc['selection']['coarse']['kept'] for doc in reads)==5513331
    assert sum(doc['selection']['gas']['kept'] for doc in reads)==34436
    for name,total in [('dark',137744),('coarse',2087470),('gas',34436)]:
        assert sum(int(row['rows']) for row in controls if row['population']==name and row['model']=='second')==total
    for model in ('cold','heavy'):
        assert max(float(row['maximum_epoch_rms_relative']) for row in rows(f'hierarchy-replay-{model}.csv'))<2e-5
    with np.load(HERE/'z19-realized-states.npz') as bank:
        assert np.all(np.isfinite(bank['heavy_wave_end'])) and np.isclose(bank['a_end'],.05)
        axes=bank['axes'];mult=np.where(axes[2]==0,1,2);assert sum(mult)==145346
        idx={(int(x),int(y)):i for i,(x,y,z) in enumerate(axes.T) if z==0}
        for key in ('R','heavy_wave_end','heavy_wave_theta_end','cold_cdm_end','cold_k2Psi_end'):
            ref=bank[key];assert max(abs(ref[i]-ref[idx[-x,-y]].conj()) for (x,y),i in idx.items())<1e-12
        for model,species in [('heavy','wave'),('cold','cdm')]:
            actual=np.sqrt(mult@abs(bank[f'{model}_{species}_end'])**2)
            row,=[r for r in rows('finite-band-variance.csv') if (r['branch'],r['species'],r['kmax'])==(model,species,'2.4')]
            assert abs(actual-float(row['rms_final']))<1e-12
    with np.load(HERE/'relative-response.npz') as saved:
        subset=saved['full'][:,:,-1]
        assert np.linalg.norm(subset-saved['native'][:,:,-1])/np.linalg.norm(subset)<2e-5
        np.testing.assert_allclose(subset,(saved['initial-density']+saved['initial-slip']+saved['ordinary-source'])[:,:,-1],rtol=1e-7,atol=1e-12)
    assert max(float(row['relative_error']) for row in rows('relative-source-breakdown.csv') if row['variant']=='full')<2e-5
    assert all(float(row['relative_current_impulse_error'])<2e-5 for row in rows('pressure-current-identity.csv'))
    checks=rows('evolution-controls.csv')
    assert max(float(row['current_difference']) for row in checks if row['variant']=='prescribed')<2e-5
    assert any(float(row['current_difference'])>2e-5 for row in checks if row['variant']=='poisson')
    assert max(float(row['relative_grid_change']) for row in rows('nonlinear-grid-check.csv'))<2e-5
    bands=rows('observed-current-bands.csv');exterior=rows('outside-band-leakage.csv')
    for row in exterior:
        cols=('mask','kmax','quantity','model')
        old,=[other for other in bands if all(other[col]==row[col] for col in cols)]
        assert old['rel_error']==row['raw_error']
    record('decision.json',dict(a_start=.01,a_end=.05,parent_cosmologies=['cold','heavy'],original_modes=145346,extended_modes=1318286,
        acquired_bytes=sum(doc['bytes_received'] for doc in reads),gas_control=34436,zoom_dark_control=137744,native_base_cells=2087470,
        measured_heavy_simulation=False,fitted_galaxy=False,relative_linear_evolution_verified=True,nonlinear_evolution_completed=False))
    files={path.name:sha(path) for path in sorted(HERE.iterdir()) if path.name!='seal.json'}
    record('seal.json',dict(input_seals={folder.name:pinval for folder,pinval in PINS.items()},files=files))
    print(len(files),'verified products;',sha(HERE/'seal.json'))
if __name__=='__main__':run()
