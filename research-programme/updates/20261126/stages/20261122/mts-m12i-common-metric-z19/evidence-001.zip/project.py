from stage import *
from scipy.interpolate import PchipInterpolator
from scipy.fft import rfftn
init_particles()
pin(PREV,'seed_replay.py')
from seed_replay import noise
from music_power import power
init_seed()
from seeds import bank
def source():
    box=60/.702;fund=2*np.pi/box
    bound=int(np.ceil(5/fund));xy=np.r_[0:bound+1,-bound:0];zz=np.arange(bound+1)
    vec=np.meshgrid(xy,xy,zz,indexing='ij');norm=fund*np.sqrt(sum(axis**2 for axis in vec))
    transfer=bank('volume-state');good=bank('late-heavy')['both_scale_screens_pass']*bank('late-cold')['both_scale_screens_pass']>0
    rawk=transfer['k_Mpc_inverse'][good];use=(norm>=min(rawk))&(norm<=max(rawk));kw=norm[use];axes=np.stack([axis[use] for axis in vec])
    values=noise(95064);values-=values.mean()
    output=rfftn(values.reshape(256,256,256),workers=1)/np.sqrt(len(values));del values
    shift=np.array([-16,11,-13])/128+.5/256
    white=output[tuple(axes)]*np.exp(-2j*np.pi*(shift@axes));del output
    interpolate=lambda values:PchipInterpolator(np.log(rawk),values[good])(np.log(kw))
    cold=interpolate(transfer['cold_coordinate_number_contrast'])
    field=np.sign(cold)*white*np.sqrt(2*np.pi**2*interpolate(transfer['primordial_power'])/(kw**3*box**3))
    with np.load(pin(PREV,'prepared-modes.npz')) as orig:
        low=kw<=2.4
        test=np.stack([orig[n] for n in ('nx','ny','nz')]);assert np.array_equal(axes[:,low],test)
        assert np.max(abs(field[low]-orig['seed_curvature']))<1e-13
    packet('phase-band.npz',axes=axes,k=kw,R=field,fire=white*np.sqrt(power(kw)/box**3),box=box)
def stats(left,right,weights):
    dot=lambda first,second:np.sum(weights*(first.conj()*second).real)
    return np.sqrt(dot(left-right,left-right)/dot(right,right)),dot(left,right)/np.sqrt(dot(left,left)*dot(right,right))
def run():
    with np.load(HERE/'phase-band.npz') as full:
        use=full['k']<=2.4;kw=full['k'][use];axes=full['axes'][:,use];curvature=full['R'][use];box=float(full['box'])
    counts=np.array(json.loads(pin(PART,'census-check.json').read_bytes())['counts']);fraction=counts.cumsum()/counts.sum()
    idx=(axes[0]%69,axes[1]%69,axes[2]);multiplicity=np.where(axes[2]==0,1,2);windows={}
    for grid in (128,192):
        accum=np.zeros((5,len(kw)),complex)
        for origin in (0,1):
            mask=.5*np.exp(-1j*np.pi*origin*axes.sum(axis=0)/grid)/np.prod(np.sinc(axes/grid)**2,axis=0)
            with np.load(pin(PART,f'raw-cache/window-drift99-{grid}-{origin}.npz')) as src:
                for j in range(5):accum[j]+=src[str(j)][idx]*mask
        windows[grid]=(accum*counts[:,None]).cumsum(axis=0)/counts.cumsum()[:,None]
    modeweights={};differences=[];responses=[];metricrows=[];launch=[];export={}
    with np.load(pin(PREV,'prepared-modes.npz')) as old:
        curvature_native=old['native_curvature'];oldheavy=old['seed_heavy_number'];oldcold=old['seed_cold_number'];oldphase=old['seed_phase']
    for model in ('cold','heavy'):
        with np.load(HERE/f'transport-{model}.npz') as data:
            modes=data['k'];times=data['epochs'];species=data['species'].tolist();goal=species.index('wave' if model=='heavy' else 'cdm')
            ip=lambda arr:PchipInterpolator(np.log(modes),arr,axis=-1)(np.log(kw))
            exact=data['full'];gravity=data['gravity'];terms=data['newtonian_terms']
            for edge in (0,-1):
                projected_gravity=ip(gravity[:,edge]);denom=curvature*projected_gravity
                for limit in (.75,1.5,2.4):
                    selected=kw<=limit;weight=multiplicity[selected]*abs(denom[selected])**2
                    for label,term in list(zip(species,terms))+[('all-nr',terms.sum(axis=0))]:
                        part=curvature*ip(term[:,edge])
                        diff,cor=stats(part[selected],denom[selected],multiplicity[selected])
                        ratio=sum(weight*(part[selected]/denom[selected]).real)/sum(weight)
                        metricrows.append(dict(branch=model,a=times[edge],kmax=limit,term=label,projection_on_full_force=ratio,relative_rms_difference=diff,correlation=cor))
            new=curvature*ip(exact[goal,0,:,0]);ref=oldheavy if model=='heavy' else oldcold
            diff,cor=stats(new,ref,multiplicity)
            launch.append(dict(branch=model,quantity='number',relative_rms_change=diff,correlation=cor))
            if model=='heavy':
                from seeds import Seed
                seed=Seed(model,'anchorA','heavy')
                canonical_phase=-seed.mass*curvature*ip(exact[goal,1,:,0]/modes**2)
                diff,cor=stats(canonical_phase,oldphase,multiplicity)
                launch.append(dict(branch=model,quantity='spatial phase',relative_rms_change=diff,correlation=cor))
            for var in ('full','poisson','prescribed','prescribed-coarse','step-check','no-baryon-force')+(('dust-after-launch','zero-wave-current','copy-cdm-launch') if model=='heavy' else ()):
                values=data[var];start=ip(values[goal,0,:,0]);end=ip(values[goal,0,:,-1]);velocity=ip(values[goal,1,:,-1])/times[-1]
                ordinary=ip(values[0,0,:,-1]);delta=end-start
                for kmax in (.75,1.5,2.4):
                    sel=kw<=kmax
                    alt=ip(exact[goal,0,:,-1]);velref=ip(exact[goal,1,:,-1])/times[-1]
                    err,cor=stats(curvature[sel]*end[sel],curvature[sel]*alt[sel],multiplicity[sel])
                    verr,vcor=stats(curvature[sel]*velocity[sel],curvature[sel]*velref[sel],multiplicity[sel])
                    differences.append(dict(branch=model,variant=var,kmax=kmax,density_difference=err,current_difference=verr,density_corr=cor,current_corr=vcor))
                    for grid,window in windows.items():
                        for estimator,signal in [('seed',curvature),('native',curvature_native)]:
                            if (grid!=192 or estimator!='seed') and var!='full':continue
                            common=window[:,sel].conj()*signal[None,sel]*multiplicity[sel]
                            average=lambda field:np.sum((common*field[sel]).real,axis=1)
                            d0=average(start);df=average(end);other=average(ordinary);speed=average(velocity)
                            for cut in (0,1,4):
                                responses.append(dict(branch=model,variant=var,grid=grid,source=estimator,kmax=kmax,cut=cut,initial=d0[cut],
                                    final=df[cut],cdm_in_same_metric=other[cut],theta_final_per_Mpc=speed[cut],conditional_share_relative_to_cdm=fraction[cut]*((df-other)[cut]-(df-other)[-1])))
            for ind,name in enumerate(species):
                export[model+'_'+name+'_initial']=curvature*ip(exact[ind,0,:,0]);export[model+'_'+name+'_end']=curvature*ip(exact[ind,0,:,-1]);export[model+'_'+name+'_theta_end']=curvature*ip(exact[ind,1,:,-1])/times[-1]
            export[model+'_k2Psi_end']=curvature*ip(gravity[:,-1])
    table('frozen-patch-response.csv',responses);table('evolution-controls.csv',differences);table('source-budget.csv',metricrows);table('launch-repair.csv',launch)
    packet('z19-realized-states.npz',axes=axes,k=kw,a_start=.01,a_end=.05,R=curvature,**export)
    with np.load(HERE/'metric-free-slip.npz') as data:
        interp=lambda key:PchipInterpolator(np.log(data['k']),data[key])(np.log(kw))
        slip=[]
        for cap in (.75,1.5,2.4):
            sel=kw<=cap
            vals={key:curvature[sel]*interp(key)[sel] for key in ('initial','final','measured','pressure_impulse','coarse_impulse')}
            rms=lambda key:np.sqrt(sum(multiplicity[sel]*abs(vals[key])**2))
            err,cor=stats(vals['pressure_impulse'],vals['measured'],multiplicity[sel])
            err2,_=stats(vals['coarse_impulse'],vals['pressure_impulse'],multiplicity[sel])
            slip.append(dict(kmax=cap,pressure_over_initial_slip=rms('pressure_impulse')/rms('initial'),pressure_error_over_measured_increment=err,pressure_corr=cor,integration_difference=err2))
        table('metric-free-current-check.csv',slip)
if __name__=='__main__':source();run()
