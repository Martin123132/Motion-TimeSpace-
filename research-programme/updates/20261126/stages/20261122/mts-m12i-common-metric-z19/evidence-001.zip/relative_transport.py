from stage import *
from scipy.integrate import simpson,solve_ivp
from scipy.interpolate import PchipInterpolator
from evolve import native
from project import stats
def run():
    seed,times,k,species,den,mom,lapse=native('heavy')
    raw=savedbank('heavy');slots=[np.argmin(abs(raw['epochs']-time)) for time in times]
    col=lambda key:raw['values'][:,slots,raw['names'].tolist().index(key)]
    cdm=col('delta_cdm');actual=np.stack((den[-1]-den[0],mom[-1]-mom[0]))
    compare=savedbank('cold');idx=compare['names'].tolist().index('delta_cdm')
    cold=compare['values'][:,slots,idx];logt=np.log(times);physical_h=col('H')/col('a')
    scale=col('a');mean=seed.coeff['wave']/scale
    source=col('mts_dp_h')/mean;rest=(col('mts_drho_h')+3*col('H')*col('mts_q_h')/k[:,None])/mean
    rate=k[:,None]/(scale*seed.mass);csq=(rate/(np.sqrt(1+rate**2)+1))**2
    poisson_mass=csq*rest
    stress_error=np.linalg.norm(poisson_mass-source)/np.linalg.norm(source)
    assert stress_error<2e-5
    def solve(terms,skip,case='full'):
        forcing=PchipInterpolator(logt[::skip],(cold if case=='swap-source' else cdm)[:,::skip],axis=1)
        bg=PchipInterpolator(logt[::skip],physical_h[:,::skip],axis=1)
        init=actual[:,:,0]*np.array(terms[:2])[:,None]
        def rhs(loga,state):
            at=np.exp(loga);hub=bg(loga);ndiff,current=state.reshape(2,-1)
            ratio=k/(at*seed.mass)
            sound=0 if case=='dust' else (ratio/(np.sqrt(1+ratio**2)+1))**2
            pressure=sound*(ndiff+terms[2]*forcing(loga)+3*hub*current/k**2)
            return np.array([-current/(at**2*hub)-3*pressure,k**2*pressure/hub]).ravel()
        sol=solve_ivp(rhs,logt[[0,-1]],init.ravel(),method='DOP853',t_eval=logt,rtol=2e-11,atol=5e-17,max_step=np.log(5)/128)
        assert sol.success;return sol.y.reshape(2,len(k),len(times))
    runs={name:solve(starts,1) for name,starts in [('full',(1,1,1)),('initial-density',(1,0,0)),('initial-slip',(0,1,0)),('ordinary-source',(0,0,1))]}
    runs['half-sampling']=solve((1,1,1),2);runs['paired-cold-source']=solve((1,1,1),1,'swap-source')
    runs['dust']=solve((1,1,1),1,'dust')
    np.testing.assert_allclose(sum(runs[key] for key in ['initial-density','initial-slip','ordinary-source']),runs['full'],rtol=1e-7,atol=1e-12)
    for variant in ('dust',):
        assert np.allclose(runs[variant][1],actual[1,:,0,None],rtol=1e-14,atol=1e-17)
    flux=k[:,None]**2*source/physical_h
    disp=actual[1,:,-1]-actual[1,:,0];js=simpson(flux,x=logt,axis=1);gforce=simpson(lapse/physical_h,x=logt,axis=1)
    half=simpson(flux[:,::2],x=logt[::2],axis=1);contrast=actual[0,:,-1]-actual[0,:,0]
    denfromflux=simpson(-actual[1]/(times**2*physical_h)-3*source,x=logt,axis=1)
    with np.load(HERE/'phase-band.npz') as phase:
        kw=phase['k'];field=phase['R'];mult=np.where(phase['axes'][2]==0,1,2)
    rows=[];breakdown=[];wider=[]
    for limit in (.75,1.5,2.4,5.):
        use=kw<=limit;wavek,which=np.unique(kw[use],return_inverse=True);weights=np.bincount(which,weights=mult[use]*abs(field[use])**2)
        ip=lambda arr:PchipInterpolator(np.log(k),arr)(np.log(wavek))
        norm=lambda arr:np.sqrt(weights@ip(arr)**2)
        rows.append(dict(kmax=limit,relative_current_impulse_error=norm(disp-js)/norm(disp),residual_over_common_gravity=norm(disp-js)/norm(gforce),
            impulse_coarsening_over_common_gravity=norm(half-js)/norm(gforce),relative_density_integral_error=norm(denfromflux-contrast)/norm(contrast),
            stress_source_direct_relative_rms=stress_error))
        for label,results in runs.items():
            for channel,key in enumerate(('density_difference','momentum_difference')):
                ref=actual[channel,:,-1];value=results[channel,:,-1];dot=lambda x,y:weights@(ip(x)*ip(y))
                breakdown.append(dict(kmax=limit,variant=label,quantity=key,relative_error=norm(value-ref)/norm(ref),
                    norm_over_actual=norm(value)/norm(ref),signed_projection=dot(value,ref)/dot(ref,ref)))
        for branch in ('cold','heavy'):
            with np.load(HERE/f'transport-{branch}.npz') as doc:
                for index,label in enumerate(doc['species']):
                    data=doc['full'][index];dens=ip(data[0,:,-1]);vel=ip(data[1,:,-1])/.05
                    wider.append(dict(kmax=limit,branch=branch,species=label,modes=int(mult[use].sum()),rms_initial=norm(data[0,:,0]),
                        rms_final=np.sqrt(weights@dens**2),rms_speed_kms=LIGHT*np.sqrt(weights@((vel/wavek)**2))))
    table('pressure-current-identity.csv',rows);table('relative-source-breakdown.csv',breakdown);table('finite-band-variance.csv',wider)
    packet('relative-response.npz',k=k,epochs=times,native=actual,pressure=source,cdm_rest=cdm,common_force=lapse,**runs)
if __name__=='__main__':run()
