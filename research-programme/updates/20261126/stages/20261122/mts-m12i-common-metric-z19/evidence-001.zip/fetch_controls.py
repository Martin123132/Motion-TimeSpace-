from stage import *
import h5py
pin(FIRE,'fire_source.py');sys.path.insert(0,str(FIRE))
from fire_source import Remote,uri
def run(piece):
    guard();filename=f'fire-001-{piece}.npz';receipt=f'fire-001-{piece}.json'
    if (HERE/receipt).exists():assert sha(HERE/filename)==read(receipt)['sha256'];return
    meta=json.loads(pin(PART,f'early-001-{piece}.json').read_bytes());payload={};convention={}
    with Remote(uri(1,piece),65536) as remote,h5py.File(remote) as src:
        assert tuple(meta['identity'])==remote.id and meta['url']==remote.url
        head=src['Header'].attrs;assert abs(head['Time']-.05)<1e-8 and head['NumPart_Total'][2]==5513331
        for kind,name in [(2,'coarse'),(0,'gas')]:
            group=src[f'PartType{kind}'];length=len(group['ParticleIDs'])
            if kind==0:
                stride=group['ParticleIDs'].chunks[0];blocks=length//stride
                starts=np.floor(blocks*np.array([.125,.375,.625,.875])).astype(int)*stride
            for key in ('ParticleIDs','Coordinates','Velocities'):
                ds=group[key]
                if kind==2:
                    remote.load_field(ds);value=ds[:];remote.spans.clear()
                else:
                    assert stride==ds.chunks[0]
                    sets=[]
                    for start in starts:
                        nch=1 if ds.ndim==1 else (3+ds.chunks[1]-1)//ds.chunks[1]
                        for col in range(nch):
                            at=(int(start),) if ds.ndim==1 else (int(start),col*ds.chunks[1])
                            chunk=ds.id.get_chunk_info_by_coord(at);remote.spans.append((chunk.byte_offset,remote.range(chunk.byte_offset,chunk.size)))
                        sets.append(ds[start:start+stride:8]);remote.spans.clear()
                    value=np.concatenate(sets)
                payload[name+'_'+key]=value;assert np.isfinite(value).all()
            convention[name]=dict(total_rows=length,kept=len(value),starts=starts.tolist() if kind==0 else [],gas_stride=8 if kind==0 else None)
        assert remote.transferred<100_000_000
        doc=dict(url=remote.url,identity=remote.id,bytes_received=remote.transferred,selection=convention,a=float(head['Time']),box=float(head['BoxSize']),h=float(head['HubbleParam']))
    packet(filename,**payload);doc['sha256']=sha(HERE/filename);record(receipt,doc)
    print('z19',piece,doc['bytes_received'],'bytes',flush=True)
if __name__=='__main__':
    for piece in range(4):run(piece)
