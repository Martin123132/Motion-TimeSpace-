import sys
from wave_history import BRANCHES, fs, HERE, guard, run
from prepare_io import digest

def main(steps):
    assert steps in (32,64)
    control="constant" if steps==32 else "reset"
    for branch in BRANCHES:
        for name,level in (("three",steps),("two",steps),(control,64)):
            guard()
            tag=f"{branch}-{name}-{level}"
            files=["state-"+tag+".npz","entry-"+tag+".json","track-"+tag+".csv"]
            if name!="constant":
                files.append("bands-"+tag+".csv")
            receipt=HERE/("receipt-"+tag+".json")
            if receipt.exists():
                checks=fs.json.loads(receipt.read_bytes())
                assert set(checks)==set(files) and all(digest(HERE/f)==d for f,d in checks.items())
                continue
            run(branch,name,level)
            fs.record(receipt.name,{f:digest(HERE/f) for f in files})

if __name__=="__main__":
    main(int(sys.argv[1]))
