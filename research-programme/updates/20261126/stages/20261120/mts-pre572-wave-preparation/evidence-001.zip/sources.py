from prepare_io import HERE, fs, np, cp, guard, saved, setup

def run():
    guard()
    joint=setup()
    grid=joint.Assembly("anchorA").bg
    radii=grid.rad*grid.length
    leg=joint.legvander(grid.mu,64)[:,::2]
    end=joint.merged(600)[0][:,0].sum(axis=0)
    with np.load(saved("mw-positive-aperture.npz")) as data:
        local=data["high"]
    for snap in (572,544,558):
        bank, _, _, receipts=joint.merged(snap)
        gas,star=bank[:,0]
        delta,holes,missing=joint.transfer(local,gas+star,end,False)
        assert holes==missing==0
        potential=joint.coeffs(delta,radii,64)@leg.T
        if snap==572:
            with np.load(saved("forcing-572.npz")) as data:
                assert np.array_equal(potential,data["joint"])
        else:
            cp.packet(f"input-{snap}.npz",joint=potential,physical_r=radii,mu=grid.mu)
            print(snap,receipts[0]["proper_time_Gyr"],flush=True)
if __name__=="__main__":
    run()
