import sys
from prepare_io import HERE, ROOT, fs, cp, np, guard, saved, setup
joint=setup()
from disk import BRANCHES, CENSUS, Evolution, settle

LATE=(572,579,581,586,590,600)
SITES=joint.parent.SITES
CLOCK=np.loadtxt(saved("snapshot_times.txt"))
def age(snap):
    return float(CLOCK[CLOCK[:,0]==snap,3].item()*1000)
def scale_for(branch):
    rec,=[r for r in joint.parent.read(CENSUS,"equilibria") if r["branch"]==branch]
    return 1-float(rec["fraction"])
def fields(obj,snaps):
    result={}
    for snap in snaps:
        path=HERE/f"input-{snap}.npz" if snap<572 else saved(f"forcing-{snap}.npz")
        with np.load(path) as data:
            assert np.array_equal(data["physical_r"],obj.bg.rad*obj.bg.length) and np.array_equal(data["mu"],obj.bg.mu)
            result[snap]=data["joint"]*scale_for(obj.branch)/obj.bg.vel**2
    return result
def saved_ground(branch):
    with np.load(saved(f"wave-{branch}-joint-64-572_579_586_590_600.npz")) as pkt:
        assert np.max(abs(pkt["states"][0].imag))==0
        return pkt["states"][0].real.copy()
def prepare(branch):
    guard();obj=joint.Assembly(branch)
    inputs=fields(obj,(544,572));ref=saved_ground(branch)
    def eig(pot,field):
        ham=obj.bare+obj.wave.mult(pot)+obj.wave.mult(obj.phi(obj.moment(field)))
        chemical=np.vdot(field,ham@field).real/np.vdot(field,field).real
        return chemical,np.linalg.norm(ham@field-chemical*field)/np.sqrt(obj.number)
    chem,err0=eig(inputs[572],ref)
    assert err0<1e-9
    vec=ref.copy()
    for fraction in (.25,.5,.75,1.):
        pot=inputs[572]+fraction*(inputs[544]-inputs[572])
        obj.wave.bare=obj.bare+obj.wave.mult(pot)
        vec,chem,_,_=settle(obj.wave,vec,chem,obj.number,None)
    mu0,err1=eig(inputs[544],vec)
    assert err1<1e-9 and abs(vec@vec/obj.number-1)<1e-12
    cp.packet(f"ground-{branch}.npz",early=vec,matching=ref,mu_early=mu0,early_residual=err1,matching_residual=err0)
def measures(obj,vec,gmatch,external):
    norm=obj.number;unit=obj.bg.vel**2/norm
    normalized=vec*np.sqrt(norm/np.vdot(vec,vec).real)
    ground=gmatch*np.sqrt(norm/np.vdot(gmatch,gmatch).real)
    mom=obj.moment(normalized);mom_g=obj.moment(ground)
    base=obj.bare+obj.wave.mult(external)
    ham=base+obj.wave.mult(obj.phi(mom_g))
    mu=np.vdot(ground,ham@ground).real/norm
    residual=ham@ground-mu*ground
    aligned=normalized*np.vdot(normalized,ground)/abs(np.vdot(normalized,ground))
    delta=aligned-ground
    onebody=(np.vdot(delta,(ham-mu*obj.identity)@delta).real+2*np.vdot(delta,residual).real)*unit
    charge=mom-mom_g
    bind=-.5*np.sum(charge*(obj.bg.mesh.weight[:,None]*(obj.phi(charge)@obj.wave.weights)))*unit
    excess=(obj.energy(normalized,base)-obj.energy(ground,base))*unit
    assert abs(onebody-excess-bind)<1e-6 and bind>=-1e-8
    floor=fs.json.loads(saved("initial-gap-"+obj.branch+".json").read_bytes())["compensated_floor_kms2"]
    loss=np.linalg.norm(aligned-ground*(ground@aligned/norm))**2/norm
    return dict(I_specific_kms2=excess,B_rho_specific_kms2=bind,one_body_specific_kms2=onebody,
                necessary_specific_kms2=floor,fraction_of_floor=onebody/floor,initial_matching_loss=loss,
                meets_necessary=bool(onebody>=floor))
def shells(obj):
    radius=obj.bg.rad*obj.bg.length; cuts=[]
    for probe in (np.hypot(6.,1.5),np.hypot(8.3,1.5)):
        split=int(np.searchsorted(radius,probe));stop=split*obj.bg.count
        mat=obj.bare[:stop,stop:].tocoo()
        cuts.append((stop,mat.data,mat.row,mat.col+stop,float(radius[split-1]),float(radius[split])))
    return cuts
def flux(vec,cut):
    _,coeff,rows,cols,_,_=cut
    return -2*np.sum(np.conj(vec[rows])*coeff*vec[cols]).imag
def run(branch,variant,steps):
    guard();obj=joint.Assembly(branch);norm=obj.number;units=obj.bg.vel**2/norm
    assert variant in ("two","three","constant","reset") and steps in (32,64,128)
    snaps=(544,572) if variant=="constant" else (LATE if variant=="reset" else (544,)+((558,) if variant=="three" else ())+LATE)
    us=fields(obj,snaps)
    with np.load(HERE/f"ground-{branch}.npz") as bank:early=bank["early"];matched=bank["matching"]
    vec=(matched if variant=="reset" else early).astype(complex)
    if variant=="constant":us[572]=us[544]
    cuts=shells(obj)
    mom=obj.moment(vec);states=[vec.copy()];records=[];handoff=None
    def inner(p,u):
        return np.vdot(u,obj.multiply(p,u)).real
    initial=float(obj.energy(vec)+inner(us[snaps[0]],vec));work=0.
    max_norm=max_work=max_flux=0.
    if variant=="reset":handoff=measures(obj,vec,matched,us[572])
    for first,last in zip(snaps,snaps[1:]):
        pot=us[first];diff=us[last]-pot;duration=(age(last)-age(first))/obj.unit_myr
        count=int(np.ceil(steps*duration));dt=duration/count
        solver=Evolution(obj,dt,vec);before=inner(diff,vec);outward=np.zeros(len(cuts))
        enclosed=np.array([np.vdot(vec[:cut[0]],vec[:cut[0]]).real for cut in cuts])
        for tick in range(count):
            if tick%16==0:guard()
            ext=pot+((tick+.5)/count)*diff
            mid=vec;newmom=mom
            for it in range(24):
                local=ext+obj.phi(.5*(mom+newmom))-solver.pref
                updated=solver.factor.solve(vec-.5j*dt*obj.multiply(local,mid))
                new=2*updated-vec;err=np.linalg.norm(updated-mid)/np.sqrt(norm)
                mid=updated;newmom=obj.moment(new)
                if err<2e-14:break
            else:raise ArithmeticError(("midpoint",branch,variant,first,tick))
            outward+=dt*np.array([flux(mid,cut) for cut in cuts])
            vec=new;mom=newmom;after=inner(diff,vec);work+=(before+after)*.5/count;before=after
            max_norm=max(max_norm,abs(np.vdot(vec,vec).real/norm-1))
            if not (tick+1)%16 or tick+1==count:
                actual=obj.energy(vec)+inner(pot+(tick+1)/count*diff,vec)
                max_work=max(max_work,abs(actual-initial-work)*units)
        current=np.array([np.vdot(vec[:cut[0]],vec[:cut[0]]).real for cut in cuts])
        max_flux=max(max_flux,float(np.max(abs(current-enclosed+outward))/norm))
        shift=obj.forces(mom-obj.reference)
        rec=dict(snapshot=last,time_Gyr=age(last)/1000,steps=count,norm_error=max_norm,
                 work_error_specific_kms2=max_work,closed_flux_error_fraction=max_flux,**dict(zip(SITES,shift)))
        for index,cut in enumerate(cuts):
            rec.update({f"shell{index}_last_in_kpc":cut[-2],f"shell{index}_first_out_kpc":cut[-1],
                f"shell{index}_fraction":current[index]/norm,f"shell{index}_out_fraction_per_Gyr":flux(vec,cut)*1000/(obj.unit_myr*norm)})
        records.append(rec);states.append(vec.copy())
        assert max_norm<1e-10 and max_work<.0003 and max_flux<1e-10,(max_norm,max_work,max_flux)
        if last==572:
            handoff=measures(obj,vec,early if variant=="constant" else matched,us[572])
            for index,cut in enumerate(cuts):
                g=early if variant=="constant" else matched
                handoff[f"shell{index}_redistributed_fraction"]=(current[index]-np.vdot(g[:cut[0]],g[:cut[0]]).real)/norm
                handoff[f"shell{index}_out_fraction_per_Gyr"]=rec[f"shell{index}_out_fraction_per_Gyr"]
    tag=f"{branch}-{variant}-{steps}"
    assert handoff is not None
    if variant=="constant":
        assert max(abs(handoff[k]) for k in ("one_body_specific_kms2","shell0_out_fraction_per_Gyr","shell1_out_fraction_per_Gyr"))<1e-7
    if variant=="reset":
        with np.load(saved(f"wave-{branch}-joint-{steps}.npz")) as packet:
            ref=packet["states"][-1];phase=np.vdot(vec,ref)
            distance=np.linalg.norm(vec*phase/abs(phase)-ref)/np.sqrt(norm)
            assert distance<1e-10
            handoff["endpoint_replay_error"]=distance
    cp.packet("state-"+tag+".npz",states=np.stack(states),snapshots=snaps)
    joint.table("track-"+tag,records);fs.record("entry-"+tag+".json",handoff)
    if variant!="constant":
        bands=[]
        for row in joint.parent.read(CENSUS,"census-limited-forces"):
            if row["foreground"]!=branch:continue
            label=("inner_" if float(row["R"])==6 else "outer_")+row["component"]
            sign=-1 if row["component"]=="polar" and float(row["z"])<0 else 1
            correction=sign*shift[SITES.index(label)] if row["model"]=="MTS" else 0.
            base=sum(float(row[k]) for k in ("ordinary","direct_LMC","dark"));value=base+correction
            low,high=map(float,(row["low"],row["high"]))
            bands.append(dict(model=row["model"],history=row["history"],R=row["R"],z=row["z"],component=row["component"],
                              ground=base,induced=correction,total=value,low=low,high=high,inside=low<=value<=high))
        joint.table("bands-"+tag,bands)
    print(tag,"one-body",handoff["one_body_specific_kms2"],"required",handoff["necessary_specific_kms2"],flush=True)
if __name__=="__main__":
    if sys.argv[1]=="ground":
        for name in sys.argv[2:]:prepare(name)
    else:
        method,level,*names=sys.argv[1:]
        for name in names:run(name,method,int(level))
