import csv
import sys
from collections import Counter
from prepare_io import BASE, PREV, HERE, guard, digest, old_files, prev_files, saved, fs, np
BRANCHES=("anchorA","cut1","cut2")
SITES=("inner_radial","inner_polar","outer_radial","outer_polar","anchor_inward")
TOL=2e-5
def record(name):
    return fs.json.loads((HERE/(name+".json")).read_bytes())
def rows(name):
    with (HERE/(name+".csv")).open(encoding="utf-8-sig",newline="") as stream:
        return list(csv.DictReader(stream))
def read():
    guard()
    for dirpath,inventory in ((BASE,old_files),(PREV,prev_files)):
        for name,expected in inventory.items():assert digest(dirpath/name)==expected
    counts=[];traffic=0
    for snap in (544,558):
        receipts=[record(f"mass-{snap}-{piece}") for piece in range(4)]
        for piece,rec in enumerate(receipts):
            assert (rec["snap"],rec["piece"])==(snap,piece) and digest(HERE/f"mass-{snap}-{piece}.npz")==rec["bank_sha256"]
            traffic+=rec["bytes_received"]
        whole=np.array(receipts[0]["counts_whole"])
        assert np.array_equal(whole,np.sum([rec["counts_piece"] for rec in receipts],axis=0))
        counts.append(int(whole[[0,4]].sum()))
    audit=record("clock-crosscheck-544")
    assert not audit["nominal_scale_gate"] and abs(audit["from_nominal_z"]-audit["header_scale"])<2e-8
    bands={};accuracy=[];mechanics=[]
    for branch in BRANCHES:
        timing=record("timing-"+branch)
        current=rows("current-signature-"+branch)
        assert len(current)==10 and all(abs(float(r["force_slope_per_Myr"])+float(r["conjugate_slope_per_Myr"]))<1e-12 for r in current)
        reset=rows(f"track-{branch}-reset-64")[-1]
        assert 0<timing["trap"]<1 and timing["cap_kms2"]>0 and len(timing["bounds"])==3
        for variant in ("two","three"):
            path=timing["paths"][variant]
            assert not path["excludes_all_monotone_timings"] or (timing["shape_negative"]==1 and timing["entry_loss"]<timing["trap"] and
                  max(timing["entry_kms2"],path["first_exit_work_bound_kms2"])<timing["cap_kms2"])
            tags=[f"{branch}-{variant}-{steps}" for steps in (32,64)]
            entries=[record("entry-"+tag) for tag in tags];tracks=[rows("track-"+tag) for tag in tags]
            with np.load(HERE/f"ground-{branch}.npz") as ground:
                for tag,ent,track in zip(tags,entries,tracks):
                    with np.load(HERE/f"state-{tag}.npz") as pkt:
                        assert np.array_equal(pkt["states"][0],ground["early"])
                        assert list(pkt["snapshots"])==([544]+([558] if variant=="three" else [])+[572,579,581,586,590,600])
                        idx=list(pkt["snapshots"]).index(572)
                        psi=pkt["states"][idx];g=ground["matching"]
                        loss=np.linalg.norm(psi-g*(g@psi/(g@g)))**2/np.vdot(psi,psi).real
                        assert abs(loss-ent["initial_matching_loss"])<1e-10
                        assert abs(ent["I_specific_kms2"]+ent["B_rho_specific_kms2"]-ent["one_body_specific_kms2"])<1e-6
                        assert len(track)==len(pkt["snapshots"])-1 and np.isfinite(pkt["states"]).all()
            lo,hi=entries;fine=tracks[1][-1];coarse=tracks[0][-1]
            assert lo["meets_necessary"]==hi["meets_necessary"]
            stage=dict(branch=branch,path=variant,fraction_of_required=hi["fraction_of_floor"],
                 excitation_kms2=hi["one_body_specific_kms2"],nonlinear_kms2=hi["I_specific_kms2"],density_compensation_kms2=hi["B_rho_specific_kms2"],
                 required_kms2=hi["necessary_specific_kms2"],time_discretization_difference_kms2=abs(lo["one_body_specific_kms2"]-hi["one_body_specific_kms2"]),
                 shell0_out_fraction_per_Gyr=hi["shell0_out_fraction_per_Gyr"],shell0_added_fraction=hi["shell0_redistributed_fraction"],
                 all_timing_exclusion=path["excludes_all_monotone_timings"])
            signed=next(r for r in current if r["path"]==variant and r["probe"]=="inner_radial")
            assert abs(float(signed["odd_quadrature_kms2"])+float(signed["even_deformation_kms2"])-hi["one_body_specific_kms2"])<1e-6
            stage.update(odd_quadrature_kms2=float(signed["odd_quadrature_kms2"]),
                         inherited_minus_reset_inner_radial=float(fine["inner_radial"])-float(reset["inner_radial"]),
                         inherited_minus_reset_inner_polar=float(fine["inner_polar"])-float(reset["inner_polar"]))
            mechanics.append(stage)
            small=sum(abs(float(coarse[k])-float(fine[k]))>TOL*abs(float(fine[k])) for k in SITES)
            comparisons=[rows("bands-"+tag) for tag in tags];assert len(comparisons[0])==len(comparisons[1])==96
            counts_by=Counter();sizes=Counter();miss=flips=0
            for a,b in zip(*comparisons):
                assert all(a[key]==b[key] for key in ("model","history","R","z","component","low","high","ground"))
                for rec in (a,b):
                    total,low,high,base,induced=[float(rec[k]) for k in ("total","low","high","ground","induced")]
                    assert (low<=total<=high)==(rec["inside"]=="True") and abs(base+induced-total)<1e-13
                    if rec["model"]=="static_NFW":assert induced==0
                key=b["history"]+":"+b["model"]
                counts_by[key]+=b["inside"]=="True";sizes[key]+=1
                miss+=abs(float(a["total"])-float(b["total"]))>TOL*abs(float(b["total"]))
                flips+=a["inside"]!=b["inside"]
            assert len(counts_by)==12 and set(sizes.values())=={8}
            bands[tags[1]]=dict(counts_by)
            accuracy.append(dict(branch=branch,path=variant,refinement_fails_total_of_96=miss,refinement_fails_small_of_5=small,
                                 decision_changes=flips,max_closure=max(float(tr[-1]["closed_flux_error_fraction"]) for tr in tracks),
                                 max_norm=max(float(tr[-1]["norm_error"]) for tr in tracks),max_work_kms2=max(float(tr[-1]["work_error_specific_kms2"]) for tr in tracks)))
        assert abs(record("entry-"+branch+"-constant-64")["one_body_specific_kms2"])<1e-7
        assert record("entry-"+branch+"-reset-64")["endpoint_replay_error"]<1e-10
    summary=dict(previous_files=len(old_files)+len(prev_files),particle_instances=counts,bytes_received=traffic,mechanics=mechanics,
                 force_bands=bands,accuracy=accuracy)
    fs.record("validation.json",summary)
    joined=record("joined-barriers");independent=record("joined-independent-check")
    assert joined["closes"] and joined["terminal_force_cap"]<joined["required_force"]
    assert independent["direct_early_upper_kms2"]<joined["early_cap_kms2"]<independent["direct_late_necessary_kms2"]
    assert joined["shape_checks"][1]["loss_cap"]<independent["direct_loss_gate"]
    assert all(check["constrained_negative"]==1 for check in independent["rechecked"])
    receipts=list(HERE.glob("receipt-*.json"));assert len(receipts)==18
    for receipt in receipts:
        files=fs.json.loads(receipt.read_bytes())
        assert all(digest(HERE/name)==expected for name,expected in files.items())
    signatures=[row for branch in BRANCHES for row in rows("current-signature-"+branch)]
    assert len(signatures)==30
    for row in signatures:
        potential=float(row["ordinary_commutator_per_Myr"])+float(row["self_commutator_per_Myr"])
        assert abs(potential+float(row["omitted_complement_per_Myr"]))<1e-10
        assert abs(potential+float(row["kinetic_current_per_Myr"])-float(row["force_slope_per_Myr"]))<1e-10
    exclusions={branch:(joined["closes"] if branch=="anchorA" else all(row["excludes_all_monotone_timings"] for row in record("timing-"+branch)["paths"].values())) for branch in BRANCHES}
    assert all(exclusions.values())
    fs.record("validation-extended.json",dict(rate_independent_both_paths=exclusions,rechecked_receipts=len(receipts),
              force_current_cases=len(signatures),max_kinetic_only_relative=max(float(row["commutator_fraction"]) for row in signatures),
              joined_independent_margin_kms2=independent["direct_late_necessary_kms2"]-independent["direct_early_upper_kms2"]))
    print("Checked all 6 comparisons; 18 nonlinear runs. Source bytes",traffic,flush=True)
    if "--seal" in sys.argv:
        assert all((HERE/key).is_file() for key in ("METHOD.md","RESULTS.md","PREPARATION.md"))
        assert all(path.is_file() for path in HERE.iterdir())
        fs.record("seal.json",{"files":{p.name:digest(p) for p in sorted(HERE.iterdir()) if p.name!="seal.json"}})
        print("sealed",len(record("seal")["files"]),"files",digest(HERE/"seal.json"))
if __name__=="__main__":read()
