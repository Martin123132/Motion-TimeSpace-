import hashlib
import json
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
PREV = ROOT / "mts-fire-581-formation-state-20261120"
BASE = ROOT / "mts-fire-joint-baryon-history-20261120"
def digest(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()
def inventory(path, seal):
    assert digest(path/"seal.json") == seal
    return json.loads((path/"seal.json").read_bytes())["files"]
old_files = inventory(BASE,"19c78eaa158a766bd409c0a64504788b1346542eccee37c004083a918c480d67")
prev_files = inventory(PREV,"a468eac90a9e2ec4a840dfbcf1ec23a0c4cc7acc6c17f7d258f229ab44116a1a")
def saved(name):
    directory, files = (PREV,prev_files) if name in prev_files else (BASE,old_files)
    assert digest(directory/name)==files[name],name
    return directory/name
sys.path.insert(0, str(BASE))
import fire_source as fs
import collect_particles as cp
from fire_source import np
original_guard = fs.guard
def guard():
    original_guard()
    assert not any((location/"STOP-REQUESTED").exists() for location in (BASE, PREV, HERE, ROOT))
def small(name,remote):
    if name=="snapshot_times.txt" and "544:" in " ".join(sys.argv[1:]):
        raw=saved(name).read_bytes()
        times=np.loadtxt(fs.io.BytesIO(raw))
        match=times[:,0]==544
        assert match.sum()==1
        scheduled,redshift=times[match,1:3].ravel()
        reciprocal=1/(1+redshift)
        with fs.Remote(fs.uri(544,0),65536) as record, fs.h5py.File(record,"r") as source:
            hdr=source["Header"].attrs
            head,head_z=float(hdr["Time"]),float(hdr["Redshift"])
        coord=cp.coords(544)[1]
        assert abs(head-coord)<1e-12 and abs(redshift-head_z)<2e-8 and abs(reciprocal-coord)<2e-8
        assert abs(scheduled-coord)>2e-8 and abs(head*(1+head_z)-1)<1e-12
        fs.record("clock-crosscheck-544.json",dict(nominal_scale=scheduled,nominal_z=redshift,from_nominal_z=reciprocal,
            header_scale=head,header_z=head_z,coords_scale=coord,scale_difference=scheduled-coord,
            nominal_scale_gate=False,redshift_scale_gate=True,time_Gyr=times[match,3].item()))
        times[match,1]=reciprocal
        buf=fs.io.BytesIO()
        np.savetxt(buf,times,fmt="%.17g")
        return buf.getvalue()
    if name in old_files:
        return saved(name).read_bytes()
    return fs.fetch_small(name,remote)
fs.HERE=cp.HERE=HERE
fs.guard=cp.guard=guard
cp.fetch_small=small
class Overlay:
    def __truediv__(self,name):
        if name in old_files or name in prev_files:
            return saved(name)
        return HERE/name
def setup():
    import joint_field
    joint_field.HERE=Overlay()
    return joint_field
if __name__=="__main__":
    for item in sys.argv[1:]:
        snap,piece=map(int,item.split(":"))
        assert snap in (544,558) and piece in range(4)
        cp.collect(snap,piece)
