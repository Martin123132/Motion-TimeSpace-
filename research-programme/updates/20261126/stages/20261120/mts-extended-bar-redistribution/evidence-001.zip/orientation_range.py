from annular_force import *
from scipy.special import ellipkm1, ellipe

def extrema(phase, halfwidth, kind):
    offset=0 if kind=="cos" else pi/2
    closeness=abs((phase-offset+pi/2)%pi-pi/2)
    return np.cos(np.minimum(closeness+halfwidth,pi/2)), np.cos(np.maximum(closeness-halfwidth,0))

def bounds(s, key, phi, low, high):
    half=(high-low)/2; mid=(high+low)/2
    exponent = WGP[key][9] if key in WGP else S22[key][4]
    power = 1. if key in WGP else S22[key][5]
    major,minor=(abs(WGP[key][2]),WGP[key][3]) if key in WGP else S22[key][1:3]
    sample,weights=quad([0,pi/2],160)
    mean=angular_weight(key,s,sample)@(2*weights/pi)
    def one(angle_values):
        cl,ch=extrema(angle_values,half,"cos")
        sl,sh=extrema(angle_values,half,"sin")
        def factor(cv,sv):
            return np.exp(-((s*cv/major)**exponent+(s*sv/minor)**exponent)**(power/exponent))
        return np.stack([factor(ch,sh),factor(cl,sl)])
    return (one(phi[:,None]-mid)+one(phi[:,None]+mid))/(2*mean)

def response(s, radius, order, low, high):
    zz=1.5; arm=abs(s-radius); dist=np.hypot(radius,zz)
    cuts=np.unique(np.clip(np.r_[0,.025,.07,.15,.3,.6,1.,1.5,2,3,5,8,12,20,32,52,
                                 zz+np.array([-6.,-1.,-.2,0.,.2,1.,6.])*arm],0,52))
    zs,wz=quad(cuts,order)
    phi,wp=quad(np.unique(np.clip(np.r_[0,.00005,.0005,.005,.025,.1,np.linspace(0,pi,33),
                                        arm/np.sqrt(s*radius)*np.array([.2,1.,5.])],0,pi)),order)
    oldz,oldw=quad(np.unique(np.r_[cuts,census().stars.axis]),max(4,order//2))
    def average(zpos):
        dz=zpos-zz
        lo=(s-radius)**2+dz**2;hi=(s+radius)**2+dz**2
        comp=lo/hi;fac=1/(pi*np.sqrt(hi));second=ellipe(1-comp)
        radial=-fac/radius*(ellipkm1(comp)+(radius**2-s*s-dz*dz)*second/lo)
        vertical=2*fac*dz*second/lo
        return np.array([radius*radial+zz*vertical,zz*radial-radius*vertical])/dist
    profiles=np.stack([census().starshape(oldz,idx) for idx in range(4)])
    sink=((average(oldz)+average(-oldz))*oldw)@profiles.T
    shape_z=np.array([wz*zshape(key,zs) for key in KEYS]).T
    dy2=4*s*radius*np.sin(phi/2)**2
    dr=s-radius-2*s*np.sin(phi/2)**2
    cylindrical=np.zeros((2,len(phi),len(KEYS)))
    for dz in [zs-zz,-zs-zz]:
        inv=(arm**2+dy2[:,None]+dz**2)**(-1.5)
        cylindrical[0]+=dr[:,None]*(inv@shape_z)
        cylindrical[1]+=(inv*dz)@shape_z
    kernels=np.einsum("ij,jpk->ipk",np.array([[radius,zz],[zz,-radius]])/dist,cylindrical)*(wp/pi)[None,:,None]
    candidate_high=[];candidate_low=[]
    for idx,key in enumerate(KEYS):
        floor,ceiling=bounds(s,key,phi,low,high)
        positive=np.maximum(0,kernels[:,:,idx]);negative=np.minimum(0,kernels[:,:,idx])
        candidate_high.append((positive@ceiling+negative@floor).max(axis=1))
        candidate_low.append((negative@ceiling+positive@floor).min(axis=1))
    spans=[]
    for keys in (KEYS,*GROUPS.values()):
        which=[KEYS.index(k) for k in keys]
        best=np.max(np.array(candidate_high)[which],axis=0)[:,None]-sink
        worst=np.min(np.array(candidate_low)[which],axis=0)[:,None]-sink
        spans.append(np.stack([np.minimum(worst,0)@supply(s),np.maximum(best,0)@supply(s)]))
    return G*UNIT*2*pi*s*np.array(spans)

def calculate(order,step):
    guard()
    angles=np.deg2rad(np.linspace(25,33,1+round(8/step)))
    knots=np.unique(np.r_[np.arange(0,16.1,.5),census().stars.knots,census().stars.bgrid,5.8,5.95,5.99,6,6.01,6.05,6.2,8.25,8.29,8.3,8.31,8.35,18,20,24,30])
    records=[];families=[]
    for rad in [6.,8.3]:
        rr,weights=quad(knots,order)
        curves=np.array([response(s,rad,order,angles[:-1],angles[1:]) for s in rr])
        for region,mask in [("whole",np.ones(len(rr),bool)),("outer",(rr>4.5)&(rr<6))]:
            answers=np.einsum("r,rfij->fij",weights[mask],curves[mask])
            for group,answer in zip(("all",*GROUPS),answers):
                for idx,component in enumerate(("radial","polar")):
                    row=dict(R=rad,component=component,region=region,low=answer[0,idx],high=answer[1,idx])
                    if group=="all":records.append(row)
                    families.append(dict(group=group,**row))
    table(f"angle-envelope-{order}-{step:g}",records)
    table(f"family-envelope-{order}-{step:g}",families)
if __name__=="__main__":
    calculate(int(sys.argv[1]),float(sys.argv[2]))
