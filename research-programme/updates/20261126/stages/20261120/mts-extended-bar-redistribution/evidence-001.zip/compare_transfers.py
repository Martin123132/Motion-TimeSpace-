from long_source import *
from scipy.optimize import linprog

def records(name):
    return old.read(HERE,name)
def run(lens_order=12):
    guard()
    budgets=records("positive-transfers")
    prior=old.read(BAR,"full-paired-forces")
    sky=[];lens=[];duals=[];optical=records(f"lens-summary-{lens_order}")
    for plan in budgets:
        group,lit=plan["group"],int(plan["literal"])
        region=plan["region"];scale_factor=float(plan["source_only_multiplier"])
        keys=GROUPS[group]
        calculations=records(("whole-" if region=="whole" else "")+"force-20")
        for row in prior:
            north=next(v for v in calculations if v["group"]==group and int(v["literal"])==lit and v["R"]==row["R"] and v["component"]==row["component"])
            signed=scale_factor*float(north["delta"])*(-1 if row["z"]=="-1.5" and row["component"]=="polar" else 1.)
            total=float(row["total"])+signed
            sky.append(dict(group=group,literal=lit,region=region,multiplier=scale_factor,**{k:row[k] for k in ("occupation","history","frame","model","R","z","component","low","high")},
                            before=row["total"],change=signed,after=total,inside=float(row["low"])<=total<=float(row["high"])))
        for row in optical:
            change=scale_factor*sum(float(row[f"{key}_{lit}_{region}"]) for key in keys)
            lens.append(dict(group=group,literal=lit,region=region,multiplier=scale_factor,**{k:row[k] for k in ("survey","source","centers","total_weight","base")},
                             change_micro_tau=change,after_micro_tau=float(row["base"])+change))
        if region!="whole":continue
        rr=np.unique(np.r_[np.arange(.02,18,.025),census().stars.knots[1:],edges(keys,lit),np.arange(0,6,.1)])
        avail=supply(rr).sum(axis=1)
        matrix=np.column_stack([column(key,lit,rr)/avail for key in keys])
        for donor in ("components","favorable"):
            slopes=records("whole-"+donor+"-20")
            cost=np.array([float(next(r["polar"] for r in slopes if r["R"]=="6.0" and r["key"]==key and int(r["literal"])==lit)) for key in keys])
            solution=linprog(-cost,A_ub=matrix,b_ub=np.ones(len(rr)),bounds=(0,None),method="highs")
            assert solution.success
            dual=np.maximum(0,-solution.ineqlin.marginals)
            for j in range(len(keys)):
                lack=cost[j]+2e-11-(dual@matrix)[j]
                if lack>0:
                    at=np.argmax(matrix[:,j]);dual[at]+=lack/matrix[at,j]
            assert min(dual@matrix-cost)>=0 and dual.sum()+1e-12>=cost@solution.x
            duals.append(dict(group=group,literal=lit,donor=donor,polar_upper=dual.sum(),primal_sampled=cost@solution.x,
                              witnesses=json.dumps([(float(rr[i]),float(dual[i])) for i in np.flatnonzero(dual)]),
                              column_margin=float(min(dual@matrix-cost))))
    table("same-source-signed-forces",sky);table("same-source-depth" if lens_order==12 else f"same-source-depth-{lens_order}",lens);table("population-duals",duals)
    bounds=[]
    for model in ("MTS","NFW"):
        for radius in (6.,8.3):
            for comp in ("radial","polar"):
                needs=[]
                subset=[r for r in prior if r["model"]==model and float(r["R"])==radius and r["component"]==comp]
                for ident in {(r["occupation"],r["history"],r["frame"]) for r in subset}:
                    north,south=sorted([r for r in subset if (r["occupation"],r["history"],r["frame"])==ident],key=lambda r:-float(r["z"]))
                    lower=float(north["low"])-float(north["total"]);upper=float(north["high"])-float(north["total"])
                    other_low=float(south["low"])-float(south["total"]);other_high=float(south["high"])-float(south["total"])
                    if comp=="polar":other_low,other_high=-other_high,-other_low
                    needs.append([max(lower,other_low),min(upper,other_high)])
                arr=np.array(needs)
                bounds.append(dict(model=model,R=radius,component=comp,smallest_lower=arr[:,0].min(),largest_upper=arr[:,1].max(),
                                   largest_lower=arr[:,0].max(),smallest_upper=arr[:,1].min(),nonempty=int(sum(arr[:,0]<=arr[:,1]))))
    table("paired-needed",bounds)
if __name__=="__main__":run(int(sys.argv[1]) if len(sys.argv)>1 else 12)
