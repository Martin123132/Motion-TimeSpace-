from pathlib import Path
import sys
import csv
import json
import hashlib
import io
from functools import lru_cache
from math import pi
HERE = Path(__file__).resolve().parent
BAR = HERE.parent / "mts-central-bar-force-bound-20261120"
sys.dont_write_bytecode = True
sys.path.insert(0, str(BAR))
import bar_inputs as old
from bar_inputs import np, Source, G, UNIT
from scipy.special import roots_legendre
from scipy.optimize import minimize_scalar

def guard():
    old.guard()
    assert old.digest(BAR / "seal.json") == "a5253d5a3979a32a3548af7d6c4f256aa015ccaa53e64b640ab3bb43e7d12bd0"
    assert not (HERE / "STOP-REQUESTED").exists()

def put(name, raw):
    guard()
    dest = HERE / name
    data = raw.encode()
    if dest.exists():
        assert dest.read_bytes() == data, name
    else:
        with dest.open("xb") as stream:
            stream.write(data)

def table(name, records):
    buf = io.StringIO(newline="")
    writer = csv.DictWriter(buf, records[0].keys(), lineterminator="\n")
    writer.writeheader()
    writer.writerows(records)
    put(name + ".csv", buf.getvalue())

@lru_cache(None)
def rule(order):
    return roots_legendre(order)

def quad(edges, order):
    knots = np.unique(edges)
    mid = (knots[1:] + knots[:-1]) / 2
    half = np.diff(knots) / 2
    points, weights = rule(order)
    return (mid[:, None] + half[:, None] * points).ravel(), (half[:, None] * weights).ravel()

WGP = {
    "one": (10.15,28.4,3.05,.68,.09,3.85,.72,3.45,.71,2.27,8.8e9),
    "thin": (10.87,29.1,.82,.23,.20,4.37,.11,3.26,.56,3.98,4e9),
    "super": (9.97,30.,-32.66,1.88,.04,3.36,.76,7.09,2.24,1.67,3.3e9)}
S22 = {"short22": (4.95381575e8,5.36363324,.958522229,.610542494,.969645220,3.05125124,3.19043585,.558255674,16.7310332,3.19575493),
       "long22": (1.74304936e13,.477961423,.266853061,.251516920,1.87882599,.980136710,2.20415408,7.60708626,-27.2907665,1.62966434)}
GROUPS = {"W1": ("one",), "W2": ("thin","super"), "S22": ("short22","long22")}
def height(key):
    return S22[key][3] if key in S22 else WGP[key][4]
def angle(key):
    return np.deg2rad(28. if key in S22 else WGP[key][1])
def zshape(key, altitude):
    thickness = height(key)
    arg = abs(altitude) / thickness
    if key in S22:
        decay = np.exp(-2 * arg)
        return 2 * decay / ((1 + decay)**2 * thickness)
    return np.exp(-arg) / (2 * thickness)
def edges(keys, literal):
    knots = [0,1,2,3,4,4.5,5,6,7,8,10,15,20,30]
    for key in keys:
        if key in WGP:
            outer, sw, inner, iw = WGP[key][5:9]
            knots.extend([outer,inner,outer+literal*sw,inner-literal*iw])
    return np.unique(np.clip(knots, 0, 30))
def raw(key, literal, radius, phi):
    if key in WGP:
        logmass, _, major, minor, _, outer, sw, inner, iw, exponent, _ = WGP[key]
        geom = ((radius * abs(np.cos(phi)) / abs(major))**exponent + (radius * abs(np.sin(phi)) / minor)**exponent)**(1/exponent)
        co = (radius - outer) / sw
        ci = (inner - radius) / iw
        return 10**logmass/(2*pi*abs(major)*minor)*np.exp(-geom - np.where(co>literal,co*co,0.) - np.where(ci>literal,ci*ci,0.))
    norm,major,minor,thick,expo,power,outer,inner,outpow,inpow = S22[key]
    positive = np.maximum(radius, 1e-15)
    geom = ((radius * abs(np.cos(phi)) / major)**expo + (radius * abs(np.sin(phi)) / minor)**expo)**(power/expo)
    with np.errstate(over="ignore"):
        return 2*thick*norm*np.exp(-geom-(positive/outer)**outpow-(inner/positive)**inpow)
def avg(key, literal, radius, order=80):
    phi, weights = quad([0,pi/2],order)
    rr = np.asarray(radius)
    return raw(key,literal,rr[...,None],phi) @ (weights/(pi/2))
@lru_cache(None)
def raw_mass(key,literal,order=80):
    rr, weights = quad(edges([key],literal),order)
    return 2*pi * ((weights*rr) @ avg(key,literal,rr,order))
def scale(key,literal):
    return WGP[key][-1]/raw_mass(key,literal) if key in WGP else 1.
def column(key, literal, radius):
    return scale(key,literal)*avg(key,literal,radius)
@lru_cache(None)
def census():
    return Source()
def supply(radius):
    rr = np.asarray(radius)
    return census().stars.radial(rr.reshape(-1)).reshape((*rr.shape,4))
def budget():
    guard()
    audit, components = [], []
    for group, keys in GROUPS.items():
        for literal in ((1,0) if group != "S22" else (0,)):
            for key in keys:
                mass = raw_mass(key,literal)
                components.append(dict(group=group, component=key, literal=literal, raw_positive_shape_mass=mass, nominal_mass=mass*scale(key,literal),
                                       normalization=scale(key,literal), refined_relative=abs(raw_mass(key,literal,128)/mass-1)))
            breaks = np.unique(np.r_[edges(keys,literal),census().stars.knots,census().stars.bgrid])
            def demand(rr):
                return sum(column(key,literal,rr) for key in keys)
            def ratio(rr):
                return demand(rr)/supply(rr).sum(axis=-1)
            for low,high in [(0.,30.),(4.5,6.)]:
                splits = breaks[(breaks>=low)&(breaks<=high)]
                peaks=[]
                for left,right in zip(splits[:-1],splits[1:]):
                    left=np.nextafter(left,right);right=np.nextafter(right,left)
                    sample = np.linspace(left,right,11)
                    peaks.extend(zip(ratio(sample),sample))
                    for start,end in zip(sample[:-1],sample[1:]):
                        opt=minimize_scalar(lambda x:-ratio(x),bounds=(start,end),method="bounded",options={"xatol":1e-9})
                        peaks.append((-opt.fun,opt.x))
                peak,where=max(peaks)
                rr,ww=quad(splits,48)
                claimed=demand(rr)
                available=supply(rr).sum(axis=-1)
                audit.append(dict(group=group,literal=literal,low=low,high=high,peak_demand_per_supply=peak,witness_kpc=where,ring_demand= float(demand(where)),
                                  ring_supply=float(supply(where).sum()),mass_demand=float(2*pi*(ww*rr)@claimed),mass_supply=float(2*pi*(ww*rr)@available),
                                  definite_positive_excess_quadrature=float(2*pi*(ww*rr)@np.maximum(claimed-available,0)),witness_rules_out_full=peak>1))
    table("component-masses",components);table("mass-budget",audit)
if __name__=="__main__":
    budget()
