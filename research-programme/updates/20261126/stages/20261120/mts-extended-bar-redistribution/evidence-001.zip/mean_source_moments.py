from long_source import *
import math

def moments():
    src=census()
    cut=src.stars.H
    zz,w=quad(src.stars.axis,5)
    old_z=[]
    for j in range(4):
        width=src.tail[j]
        at_cut=src.starshape(cut,j)
        def moment(n):
            tail=at_cut*sum(math.comb(n,k)*cut**(n-k)*math.factorial(k)*width**(k+1) for k in range(n+1))
            return 2*(tail+w@(src.starshape(zz,j)*zz**n))
        old_z.append([moment(n) for n in (0,2,4)])
    out=np.array(old_z)
    assert np.max(abs(out[:,0]-1))<1e-12
    return out
def run():
    guard()
    donor=moments()
    caps=old.read(HERE,"positive-transfers")
    records=[]
    for plan in caps:
        family,lit,region=plan["group"],int(plan["literal"]),plan["region"]
        amp=float(plan["source_only_multiplier"])
        keys=GROUPS[family]
        knots=np.unique(np.r_[edges(keys,lit),census().stars.knots,census().stars.bgrid])
        if region=="outer":knots=knots[(knots>=4.5)&(knots<=6)]
        rr,w=quad(knots,48);w*=2*pi*rr
        supply_r=supply(rr);fraction=supply_r/supply_r.sum(axis=1)[:,None]
        dm2=np.zeros(len(rr));dm4=np.zeros(len(rr))
        for key in keys:
            thick=height(key)
            m2,m4=(2*thick**2,24*thick**4) if key in WGP else (pi**2*thick**2/12,7*pi**4*thick**4/240)
            col=amp*column(key,lit,rr)
            dm2+=col*(m2-fraction@donor[:,1]);dm4+=col*(m4-fraction@donor[:,2])
        q2=w@dm2;q4=w@(dm4-3*rr**2*dm2)
        for axial in [50.,100.,200.]:
            zz,ww=quad(np.unique(np.r_[census().stars.axis,4.,5.,7.,10.,14.,20.,30.,50.,75.,100.]),8)
            subtract=(1/np.sqrt(rr[:,None]**2+(axial-zz)**2)+1/np.sqrt(rr[:,None]**2+(axial+zz)**2)-2/axial)
            old_ker=subtract@(ww[:,None]*np.stack([census().starshape(zz,j) for j in range(4)],axis=1))
            total=np.zeros(len(rr))
            for key in keys:
                new_ker=subtract@(ww*zshape(key,zz))
                total+=amp*column(key,lit,rr)*(new_ker-(fraction*old_ker).sum(axis=1))
            actual=-G*(w@total)
            quad_only=-G*q2/axial**3
            expansion=quad_only-G*q4/axial**5
            records.append(dict(group=family,literal=lit,region=region,multiplier=amp,axis_kpc=axial,delta_monopole_msun=0.,
                                delta_Q2=q2,delta_Q4=q4,actual_potential=actual,quadrupole_prediction=quad_only,through_degree4=expansion,
                                relative_after4=abs(expansion/actual-1)))
    table("mean-source-far-prediction",records)
if __name__=="__main__":run()
