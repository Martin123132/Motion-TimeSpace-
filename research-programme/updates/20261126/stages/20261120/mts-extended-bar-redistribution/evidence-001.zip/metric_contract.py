from compare_transfers import records
from long_source import *
def run():
    prior=old.read(BAR,"full-paired-forces")
    shapes=records("population-duals")
    broad=records("angle-envelope-20-0.25")
    cuts=records("positive-transfers")
    fixed=records("whole-force-20")
    families=[(r["group"],int(r["literal"]),float(r["source_only_multiplier"])) for r in cuts if r["region"]=="whole"]
    results=[]
    for rad in (6.,8.3):
        physical_r=np.hypot(rad,1.5)
        for model in ("MTS","NFW"):
            for comp in ("polar","radial"):
                selected=[r for r in prior if float(r["R"])==rad and r["model"]==model and r["component"]==comp]
                for ident in sorted({(r["occupation"],r["history"],r["frame"]) for r in selected}):
                    north,south=sorted([v for v in selected if (v["occupation"],v["history"],v["frame"])==ident],key=lambda v:-float(v["z"]))
                    a,b=float(north["low"])-float(north["total"]),float(north["high"])-float(north["total"])
                    c,d=float(south["low"])-float(south["total"]),float(south["high"])-float(south["total"])
                    if comp=="polar":c,d=-d,-c
                    lo,hi=(a+c)/2,(b+d)/2
                    ranges=[]
                    for group,lit,amplitude in families:
                        item=next(s for s in fixed if s["R"]==north["R"] and s["component"]==comp and s["group"]==group and s["literal"]==str(lit))
                        shift=amplitude*float(item["delta"])
                        ranges.append((group+"-"+str(lit)+"-source",shift,shift))
                        if rad==6. and comp=="polar":
                            limit=next(float(s["polar_upper"]) for s in shapes if s["group"]==group and s["literal"]==str(lit) and s["donor"]=="favorable")
                            ranges.append((group+"-"+str(lit)+"-free-amplitudes",None,limit))
                    envelope=next(s for s in broad if s["R"]==north["R"] and s["region"]=="whole" and s["component"]==comp)
                    ranges.append(("all-angular-radial-mixtures",float(envelope["low"]),float(envelope["high"])))
                    for name,low,high in ranges:
                        residlo=lo-high
                        residhi=None if low is None else hi-low
                        amin=max(0,residlo,-residhi if residhi is not None else 0)
                        delta_phi=amin*(physical_r if comp=="polar" else 1.)/UNIT
                        results.append(dict(R=rad,model=model,component=comp,occupation=ident[0],history=ident[1],frame=ident[2],policy=name,
                                            parity_relaxed_low=lo,parity_relaxed_high=hi,remaining_low=residlo,remaining_high=residhi,
                                            abs_force_min=amin,min_gradient=delta_phi,min_metric_gradient=2*delta_phi/299792.458**2))
    table("metric-residual-contract",results)
if __name__=="__main__":run()
