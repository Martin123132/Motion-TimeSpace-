from long_source import *

def bound_columns(key,literal,rlo,rhi):
    angles=np.linspace(0,pi/2,257)
    if key in WGP:
        logmass,_,major,minor,_,outer,sw,inner,iw,exponent,_=WGP[key]
        power=1.;norm=scale(key,literal)*10**logmass/(2*pi*abs(major)*minor)
        co=(rlo-outer)/sw;ci=(inner-rhi)/iw
        modifier=np.exp(-np.where(co>literal+1e-10,co*co,0.)-np.where(ci>literal+1e-10,ci*ci,0.))
    else:
        density,major,minor,thick,exponent,power,outer,inner,outpow,inpow=S22[key]
        norm=2*thick*density
        which=rlo if outpow>0 else rhi
        with np.errstate(over="ignore"):
            modifier=np.exp(-(np.maximum(which,1e-15)/outer)**outpow-(inner/np.maximum(rhi,1e-15))**inpow)
    low=((np.maximum(0,np.cos(angles[1:])-1e-15)/abs(major))**exponent+(np.maximum(0,np.sin(angles[:-1])-1e-15)/minor)**exponent)**(1/exponent)
    return norm*modifier*np.exp(-(rlo[:,None]*low)**power).mean(axis=1)*(1+2e-9)

def run():
    records=[]
    for group,keys in GROUPS.items():
        for lit in ([0] if group=="S22" else [0,1]):
            knots=np.unique(np.r_[edges(keys,lit),census().stars.bgrid,census().stars.knots,np.linspace(0,30,12001)])
            left,right=knots[:-1],knots[1:]
            available=np.minimum(supply(left).sum(axis=1),supply(right).sum(axis=1))
            assert available.min()>0
            bounds=sum(bound_columns(key,lit,left,right) for key in keys)
            for region,keep in [("whole",np.ones(len(left),bool)),("outer",(left>=4.5)&(right<=6))]:
                ratio=(bounds/available)[keep].max()
                amplitude=1. if ratio<1 else np.floor(10/ratio)/10
                records.append(dict(group=group,literal=lit,region=region,census_ratio_upper=ratio,source_only_multiplier=amplitude,
                                    minimum_fraction_left=1-ratio*amplitude))
    table("positive-transfers",records)
if __name__=="__main__":run()
