from entry import PHASES, ROOT, WEIGHTS, np, prior, rows, table
from assess import interp
from scipy.integrate import simpson


def native():
    forecast = {(int(row["uniform"]), float(row["radius"]), row["field"]): float(row["second_eta"])
                for row in rows(ROOT / "native-frozen-curvature.csv")}
    ledger = []
    for path in sorted(ROOT.glob("native-*.npz")):
        with np.load(path) as packet:
            trace, radii, eta = (packet[key] for key in ("trace", "radii", "eta"))
            uniform = int("-u1-" in path.name)
            cold = path.name.startswith("native-cold")
            assert np.isfinite(trace).all() and np.all(np.diff(eta) > 0)
            assert np.count_nonzero(trace[0, :, 2]) == 0
            if cold:
                assert not np.any(trace[:, :, 2]) and np.array_equal(trace[:, :, 0], trace[:, :, 1])
            for slot, field in enumerate(("metric", "radial", "polar")):
                difference = trace[:, slot, 2]
                near = 2 * difference[1:5] / eta[1:5, None]**2
                recovered = interp(eta[1:5], near, 0)
                for index, radius in enumerate(radii):
                    nominal = forecast.get((uniform, radius, field))
                    standard = nominal is not None and ("native36" in path.name)
                    target = 0. if cold else nominal
                    absolute = recovered[index] - target if standard else None
                    relative = absolute / target if standard and target else None
                    on, off, delta = trace[-1, slot, :, index]
                    host = trace[-1, 6 if slot == 1 else 5, 2, index]
                    if slot == 2:
                        host *= 1.5/radius
                    ledger.append(dict(packet=path.stem, field=field, radius=radius,
                                       recovered_second_eta=recovered[index], frozen_second_eta=target if standard else None,
                                       relative_discrepancy=relative, within_20ppm=abs(relative)<2e-5 if relative is not None else None,
                                       final_on=on, final_off=off, evolved_difference=delta, host_part=host,
                                       subtraction_residual=(on-off)-delta, first_doubling_ratio= difference[2,index]/difference[1,index] if difference[1,index] else None))
    table("native-probe-results.csv", ledger)


def compact():
    ledger=[]
    for path in sorted(ROOT.glob("*-e*-t*.npz")):
        with np.load(path) as packet:
            trace = packet["trace"]
            assert np.isfinite(trace).all() and trace.shape == (33,3,3,5,11) and packet["complete"].item()
            if path.name.startswith("cold"):
                assert not np.any(trace[:,:,2]) and np.array_equal(trace[:,:,0],trace[:,:,1])
            time, hub = packet["times"], packet["hub"]
            for loc, radius in enumerate(packet["radii"][:4]):
                values = trace[:,:,:,loc,:]
                for phase, label in enumerate(PHASES):
                    piece = values[:,phase,2]
                    change = piece[-1,0] - piece[0,0]
                    drive = simpson(piece[:,8] / hub, x=time)
                    flux = simpson((piece[:,9]+piece[:,10])/hub, x=time)
                    radial = piece[-1,4]
                    ledger.append(dict(packet=path.stem,phase=label,radius=radius,radial=radial,
                        radial_on=values[-1,phase,0,4],radial_off=values[-1,phase,1,4],polar=piece[-1,5],
                        radial_metric=piece[-1,6],polar_metric=piece[-1,7],
                        radial_linearity=values[-1,2,2,4]-WEIGHTS@values[-1,:2,2,4],
                        moment_change=change,volume_plus_surface_integral=flux,weak_source_integral=drive,
                        null_over_visible=values[-1,1,2,4]/values[-1,0,2,4] if values[-1,0,2,4] else None))
    table("compact-probe-results.csv",ledger)


if __name__ == "__main__":
    native()
    compact()
