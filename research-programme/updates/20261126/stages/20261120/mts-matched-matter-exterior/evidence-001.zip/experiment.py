import argparse
import io
from entry import AI,DLOG,PHASES,ROOT,VECTORS,guard,np,put
from mesh import Mesh
from model import Patch
from observables import functions,current,split


def label(model,edge,segments,steps,wall,prep,medium,coll,uniform):
    return f"{model}-L{edge}-e{segments}-t{steps}-{wall}-{prep}-{medium}-{coll}-u{int(uniform)}"


def run(model,edge,segments,steps,wall,prep,medium,coll,uniform):
    name=label(model,edge,segments,steps,wall,prep,medium,coll,uniform)
    dest=ROOT/(name+".npz")
    if dest.exists():
        with np.load(dest) as stored:
            assert stored["complete"].item() and stored["times"][-1]==DLOG and stored["channels"].tolist()==["on","off","difference"]
        return
    guard()
    p=Patch(model,edge,segments,wall,medium,coll,uniform)
    mesh=p.mesh
    state=p.state(prep=prep)
    initial_velocity=state[2].copy()
    assert steps%32==0
    tick=DLOG/steps
    radii=(12.,18.,24.,36.,float(edge))
    time_series=[];ticks=[]
    final_sphere=None
    for step in range(steps+1):
        guard()
        now=DLOG*step/steps
        if step%(steps//32)==0:
            number,speed,src,phi,dn=p.rate(state,now,True)
            m=AI*np.exp(now)
            raw=np.einsum("s,pxsi->pxi",p.p.coeff,dn)
            rr=[]
            for radius in radii:
                output=functions(mesh,src,phi,m,radius)
                seg=split(mesh,radius)
                qdot=(mesh.quad(raw)[...,:seg,:]*(mesh.loc[:seg]**4*mesh.qw)).sum(axis=(-2,-1))
                vol,edgeflux=current(mesh,number,speed,state[1],state[2],p.p.coeff,radius,p.robin)
                rr.append(np.stack([*output.values(),qdot,vol,edgeflux],axis=-1))
            time_series.append(np.stack(rr,axis=-2));ticks.append(now)
            assert np.isfinite(rr).all(),name
            final_sphere=np.stack((number,speed))
        if step<steps:state=p.step(state,now,tick)
    stream=io.BytesIO()
    np.savez_compressed(stream,channels=["on","off","difference"],phases=PHASES,
                        quantities=[*output.keys(),"qdot","volume_current","surface_current"],radii=radii,
                        trace=time_series,times=ticks,rad=mesh.r,initial_velocity=initial_velocity,
                        mono=state[0],density=state[1],velocity=state[2],end_medium=final_sphere,hub=p.p.chart.hc(ticks),
                        source=src,metric=phi,complete=True)
    put(name+".npz",stream.getvalue())
    print(name,flush=True)


def campaign(group):
    base=("matched","matched","live","native36",False)
    tasks=[]
    if group=="anchor":
        for n in (48,64):
            tasks.extend([("heavy",24,n,192,wall,prep,"prescribed","native36",False) for wall,prep in
                          (("wall","wall"),("matched","wall"),("matched","matched"))])
            tasks.append(("heavy",24,n,192,*base))
    elif group=="buffer":
        for edge in (36,48,60,72):
            for h in (.5,.375):tasks.append(("heavy",edge,round(edge/h),192,*base))
    elif group=="fine":
        for edge in (36,48,72):
            tasks.append(("heavy",edge,edge*4,384,*base))
        tasks.extend([("heavy",48,128,384,*base),("heavy",48,192,768,*base)])
    elif group=="controls":
        for n in (96,128):
            tasks.extend([("cold",48,n,192,*base),("heavy",48,n,192,"matched","matched","live","native36",True),
                          ("heavy",48,n,192,"matched","matched","prescribed","native36",False),
                          ("heavy",48,n,192,"wall","wall","live","native36",False)])
        for ext in ("native24","native48"):tasks.append(("heavy",72,192,192,"matched","matched","live",ext,False))
    else:raise ValueError(group)
    for args in tasks:run(*args)


if __name__=="__main__":
    import sys
    for group in sys.argv[1:]:campaign(group)
