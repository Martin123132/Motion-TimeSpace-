import csv
import hashlib
import io
import json
import os
import sys
from pathlib import Path

ROOT=Path(__file__).resolve().parent
PARENT=ROOT.parent/"mts-stratified-current-source-20261120"
PIN="9c757a21f21e85e6effaff392988a3cb9671a3cc8bd28626dba209124949807b"
for variable in ("MKL_NUM_THREADS","NUMEXPR_NUM_THREADS","OMP_NUM_THREADS","OPENBLAS_NUM_THREADS","BLIS_NUM_THREADS"):
    os.environ[variable]="1"
sys.dont_write_bytecode=True

def sha(path):
    with path.open("rb") as stream:return hashlib.file_digest(stream,"sha256").hexdigest()

def guard():
    for place in (ROOT,ROOT.parent,PARENT):assert not (place/"STOP-REQUESTED").exists()

guard()
assert sha(PARENT/"seal.json")==PIN
manifest=json.loads((PARENT/"seal.json").read_bytes())["files"]
def prior(name):
    path=PARENT/name
    assert sha(path)==manifest[name],name
    return path
for key in ("origin.py","local_elements.py","frozen-exterior-vs-interior.csv","exterior-finite-time.csv"):prior(key)
sys.path.insert(0,str(PARENT))
from origin import AI,DLOG,Preparation,np,tests
from scipy.special import spherical_jn
from numpy.polynomial.legendre import Legendre,leggauss
from scipy.sparse import coo_matrix,diags
from scipy.sparse.linalg import factorized,spsolve

def put(name,raw):
    guard()
    path=ROOT/name
    if path.exists():assert path.read_bytes()==raw,name
    else:
        temp=path.with_suffix(path.suffix+".partial")
        with temp.open("xb") as stream:stream.write(raw)
        temp.rename(path)

def table(name,records):
    raw=io.StringIO(newline="")
    w=csv.DictWriter(raw,fieldnames=list(records[0]),lineterminator="\n")
    w.writeheader();w.writerows(records)
    put(name,raw.getvalue().encode("ascii"))

def rows(path):
    with path.open(newline="") as stream:return list(csv.DictReader(stream))

PHASES=("visible","exterior_null","reference")
VECTORS=np.array([[float(r[key]) for key in ("small","reference","large")] for r in rows(prior("frozen-exterior-vs-interior.csv")) if int(r["band"])==20])
assert VECTORS.shape==(3,3)
WEIGHTS=np.linalg.lstsq(VECTORS[:2].T,VECTORS[2],rcond=None)[0]
np.testing.assert_allclose(WEIGHTS@VECTORS[:2],VECTORS[2],rtol=0,atol=5e-15)
