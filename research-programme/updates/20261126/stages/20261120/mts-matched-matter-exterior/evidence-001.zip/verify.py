from entry import PIN,PARENT,ROOT,guard,json,manifest,np,rows,sha,sys
from assess_exterior import compact,native


def validate():
    guard()
    for name,digest in manifest.items():
        assert sha(PARENT/name)==digest,name
    assert len(manifest)==97
    for name,target in (("native-frozen-curvature.csv","5b32ff975d7646bd2ccb57837c71392a7f5eb892dc9c3d634848dbe12b38ccad"),
                        ("native-mode-kernels.csv","285507cb7e7c42ecfc5bece56cc128828342c416394a3c6cb60af4368ed2bacc")):
        assert sha(ROOT/name)==target
    for name in ("compact-probe-results.csv","native-probe-results.csv"):
        assert (ROOT/name).is_file()
    compact()
    native()
    compact_rows=rows(ROOT/"compact-probe-results.csv")
    native_rows=rows(ROOT/"native-probe-results.csv")
    compact_cases={row["packet"] for row in compact_rows}
    native_cases={row["packet"] for row in native_rows}
    assert len(compact_cases)==31 and len(native_cases)==10
    legacy=rows(PARENT/"exterior-finite-time.csv")
    for count in (48,64):
        old=[row for row in legacy if row["uniform"]=="0" and row["elements"]==str(count) and row["sub"]=="1"
             and row["location"]=="exterior" and row["case"]=="exterior_null"]
        end=max(old,key=lambda row:float(row["offset"]))
        got=next(row for row in compact_rows if row["packet"]==f"heavy-L24-e{count}-t192-wall-wall-prescribed-native36-u0"
                 and row["radius"]=="36.0" and row["phase"]=="exterior_null")
        assert abs(float(got["moment_change"])/float(end["wave_difference"])-1)<2e-5
    compact_fine=[row for row in compact_rows if row["packet"] in
        {f"heavy-L{edge}-e{4*edge}-t384-matched-matched-live-native36-u0" for edge in (36,48,72)} and row["radius"]=="36.0"]
    assert len(compact_fine)==9
    for row in compact_fine:
        assert abs(float(row["null_over_visible"])/.0010598232-1)<2e-5
        for field in ("volume_plus_surface_integral","weak_source_integral"):
            assert abs(float(row[field])/float(row["moment_change"])-1)<2e-5
        assert abs(float(row["radial_metric"])/float(row["radial"])-1)<2e-5
    native_fine=[row for row in native_rows if row["packet"]=="native-heavy-L48-n192-u0-t2-native36"]
    assert len(native_fine)==27 and all(row["within_20ppm"]=="True" for row in native_fine)
    checks=[row for row in native_rows if row["radius"]=="1.35307765" and row["field"]=="radial" and row["packet"] in {
        "native-heavy-L36-n144-u0-t1-native36","native-heavy-L48-n192-u0-t2-native36","native-heavy-L72-n288-u0-t1-native36"}]
    assert len(checks)==3
    for row in checks:
        assert 3.99<float(row["first_doubling_ratio"])<4.01 and abs(float(row["evolved_difference"])/1.39862086e-14-1)<2e-5
        assert abs(float(row["host_part"])/(-3.0456055e-16)-1)<2e-5
    dust=rows(ROOT/"manufactured-dust.csv")
    assert any(float(row["phase_outer_relative"])>.99 for row in dust if row["wall"]=="wall")
    exact=[row for row in dust if row["wall"]=="matched" and row["init"]=="discrete"]
    assert exact and all(abs(float(row["phase_outer_relative"]))<2e-5 and abs(float(row["density_error_over_peak"]))<2e-5 for row in exact)
    for path in ROOT.iterdir():
        assert path.is_file() and path.suffix in (".json",".py",".md",".csv",".npz"),path
        if path.suffix==".py":compile(path.read_bytes(),str(path),"exec")
    return dict(files={path.name:sha(path) for path in sorted(ROOT.iterdir()) if path.name!="seal.json"},
                parent_seal=PIN,parent_count=len(manifest),compact_packets=len(compact_cases),native_packets=len(native_cases),
                native_fine_launch_checks=len(native_fine),compact_output_rows=len(compact_rows),native_output_rows=len(native_rows))


if __name__=="__main__":
    report=validate()
    dest=ROOT/"seal.json"
    if sys.argv[1:]==["--seal"]:
        with dest.open("x",encoding="utf8",newline="\n") as stream:
            json.dump(report,stream,indent=2,sort_keys=True)
            stream.write("\n")
    else:
        assert sys.argv[1:]==[] and json.loads(dest.read_bytes())==report
    print(len(report["files"]),"local files;",report["parent_count"],"parent files;",sha(dest))
