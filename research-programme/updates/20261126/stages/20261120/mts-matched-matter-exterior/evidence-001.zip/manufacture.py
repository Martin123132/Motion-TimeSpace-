"""Uniform pressureless multipole with free live density and a known exterior phase."""
from entry import AI,DLOG,ROOT,np,table
from model import Patch
from observables import functions,current
from scipy.integrate import solve_ivp
from scipy.special import beta,betainc


def main():
    rows=[]
    for edge,seg in ((24,48),(36,72),(48,96),(48,128)):
        patch=Patch("cold",edge,seg,uniform=True)
        mesh=patch.mesh
        rad=mesh.r[1:]
        core=6.
        y=np.minimum(rad/core,1.)**2
        form=(rad/core)**2*np.maximum(1-y,0)**6
        inside=core**5/2*beta(3.5,7)*betainc(3.5,7,y)
        outside=(1-y)**7/14
        h=(inside/rad**3+rad**2*outside)/5
        B0=1e-7
        def rates(x,db):
            hub,a=patch.coeff(x)
            return [db[1]/hub,-db[1]+sum(patch.p.coeff)*db[0]/(2*a*hub)]
        final=solve_ivp(rates,(0,DLOG),[0.,B0],method="DOP853",rtol=1e-12,atol=1e-22).y[:,-1]
        for wall in ("matched","wall"):
            patch.robin=wall=="matched"
            for mode in (("continuum","discrete") if patch.robin else ("continuum",)):
                shape=h if mode=="continuum" else mesh.potential(-form)
                mono,ds,vs=patch.state()
                ds=ds[:1];vs=0*vs[:1]
                vs[:,0]=shape*B0
                if not patch.robin:vs[...,-1]=0.
                state=mono,ds,vs
                for tick in range(48):state=patch.step(state,tick*DLOG/48,DLOG/48)
                number,speed,src,phi,dn=patch.rate(state,DLOG,True)
                a=AI*np.exp(DLOG)
                metrics=functions(mesh,src,phi,a,18.)
                shell=rad>=12
                density=state[1][0,0,0];vel=state[2][0,0,0]
                fac=sum(patch.p.coeff)
                P0=-fac*final[0]/(2*a)
                gravity=3*P0*inside[-1]/(5*18.**4)
                vol,bound=current(mesh,number,speed,state[1],state[2],patch.p.coeff,edge,patch.robin)
                want=fac*final[1]*inside[-1]
                rows.append(dict(edge=edge,segments=seg,wall=wall,init=mode,
                                 radial_error=metrics["radial"][0,0]/gravity-1,metric_radial_error=metrics["metric_radial"][0,0]/gravity-1,
                                 phase_outer_relative=np.max(abs(vel[shell]/(final[1]*h[shell])-1)),
                                 density_error_over_peak=np.max(abs(density-final[0]*form))/(final[0]*max(form)),
                                 exterior_density_over_peak=np.max(abs(density[shell]))/(final[0]*max(form)),
                                 flux_balance=(vol[0,0]+bound[0,0])/want-1,surface_share=bound[0,0]/want,
                                 density_norm=final[0],velocity_norm=final[1]))
        print(edge,seg,rows[-3:],flush=True)
    table("manufactured-dust.csv",rows)

if __name__=="__main__":main()
