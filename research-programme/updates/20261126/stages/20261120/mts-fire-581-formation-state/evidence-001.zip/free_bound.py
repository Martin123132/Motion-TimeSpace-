from source_check import NEW, jf, old
import importlib.util

spec = importlib.util.spec_from_file_location("sealed_joint_free_bound", old("energy_gate.py"))
energy_gate = importlib.util.module_from_spec(spec)
spec.loader.exec_module(energy_gate)

class LocalJoint:
    def glob(self, pattern):
        return [path for path in NEW.glob(pattern) if "-joint-" in path.name]

if __name__ == "__main__":
    energy_gate.HERE = LocalJoint()
    energy_gate.table = jf.table
    energy_gate.run()
