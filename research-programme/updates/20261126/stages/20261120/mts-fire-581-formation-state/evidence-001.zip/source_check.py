from local_581 import *
import joint_field as jf
from numpy.polynomial.legendre import legvander

NEW=HERE
class Inputs:
    def __truediv__(self,name):
        path=NEW/name
        return path if path.exists() or name not in manifest else old(name)
inputs=Inputs()
jf.HERE=inputs
def force_path(snap):
    return NEW/"forcing-581.npz" if snap==581 else old(f"forcing-{snap}.npz")
def compare():
    guard()
    bank,mass,quad,pieces=jf.merged(581)
    obj=jf.Assembly("anchorA");bg=obj.bg;rad=bg.rad*bg.length
    harm=legvander(bg.mu,64)[:,::2];fields={}
    for name,component in (("raw_gas",bank[0,0]),("raw_star",bank[1,0]),("raw_total",bank[:,0].sum(axis=0))):
        fields[name]=jf.coeffs(component,rad,64)@harm.T
    assert max(abs(fields["raw_gas"]+fields["raw_star"]-fields["raw_total"]).ravel())<2e-8
    with np.load(old("next-all-phase-forecast-581.npz")) as pred:
        prob=pred["probability"];actual=fields["raw_total"]-np.sum(fields["raw_total"]*prob)
        assert np.array_equal(rad,pred["r_kpc"]) and np.array_equal(bg.mu,pred["mu"])
        g=obj.ground;num=obj.number
        assert abs(prob.sum()-1)<1e-12 and np.max(abs(prob-abs(obj.sky(g))**2*bg.mesh.weight[:,None]*bg.aw/num))<1e-14
        def metrics(field):
            p=obj.multiply(field,g);p-=g*(g@p/num)
            return float(np.sqrt(np.sum(prob*field**2))),float(np.linalg.norm(p)/np.sqrt(num))
        out=[];line=actual-pred["linear"];detail=pred["cold_detail"]-pred["linear"]
        for which in ("linear","cold_detail"):
            err=actual-pred[which];rms,drive=metrics(err)
            assert abs(np.sum(prob*err))<1e-8 and drive<=rms+1e-8
            out.append(dict(frozen_model=which,weighted_RMS_kms2=rms,projected_drive_error_kms2=drive))
        product=np.sum(prob*line*detail);norm=np.sum(prob*detail**2)
        fs.record("held-out-result.json",dict(snapshot=581,forecast_sha256=FORECAST,comparison=out,detail_rms_kms2=metrics(detail)[0],
                   detail_vector_cosine=product/np.sqrt(norm*np.sum(prob*line**2)),gain_in_squared_error_kms4=2*product-norm,
                   fixed_age_Gyr=pieces[0]["proper_time_Gyr"],particle_counts=pieces[0]["counts_whole"],range_bytes=sum(r["bytes_received"] for r in pieces)))
        assert abs((out[0]["weighted_RMS_kms2"]**2-out[1]["weighted_RMS_kms2"]**2)-(2*product-norm))<1e-6
    packet("actual-raw-581.npz",**fields,aperture=cp.AP,apmass=mass,apquad=quad)
    print(out,flush=True)
def transfer():
    assert (NEW/"held-out-result.json").exists();guard()
    bank=jf.merged(581)[0];end=jf.merged(600)[0][:,0];joint=bank[:,0].sum(axis=0);endtotal=end.sum(axis=0)
    obj=jf.Assembly("anchorA");bg=obj.bg;rad=bg.rad*bg.length;harm=legvander(bg.mu,64)[:,::2]
    with np.load(old("mw-positive-aperture.npz")) as data:local=data["high"]
    delta,holes,missing=jf.transfer(local,joint,endtotal,False);assert holes==0 and missing==0
    coeff=jf.coeffs(delta,rad,64);fields={"joint":coeff@harm.T}
    labels=jf.groups(False).ravel();den=np.bincount(labels,weights=endtotal.ravel())
    for name,i in (("gas_transfer",0),("stellar_transfer",1)):
        dm=np.bincount(labels,weights=(bank[i,0]-end[i]).ravel());ratio=np.divide(dm,den,out=np.zeros_like(den),where=den>0)
        fields[name]=jf.coeffs(local*ratio[labels].reshape(local.shape),rad,64)@harm.T
    assert np.max(abs(fields["joint"]-fields["gas_transfer"]-fields["stellar_transfer"]))<1e-7
    with np.load(NEW/"actual-raw-581.npz") as pkt:
        for key in ("raw_gas","raw_star","raw_total"):fields[key]=pkt[key]
    packet("forcing-581.npz",physical_r=rad,mu=bg.mu,**fields)
if __name__=="__main__":compare();transfer()
