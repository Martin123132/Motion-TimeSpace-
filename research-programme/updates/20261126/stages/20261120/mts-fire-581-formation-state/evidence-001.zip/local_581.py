import json
import sys
from pathlib import Path
import hashlib

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
BASE=ROOT/"mts-fire-joint-baryon-history-20261120"
SEAL="19c78eaa158a766bd409c0a64504788b1346542eccee37c004083a918c480d67"
FORECAST="64c78ac56e4d97fd345fe36de8139cd35bf5aad65a9ef16b92e259fca0749629"
def digest(path):
    with path.open("rb") as stream:return hashlib.file_digest(stream,"sha256").hexdigest()
assert digest(BASE/"seal.json")==SEAL
manifest=json.loads((BASE/"seal.json").read_bytes())["files"]
lock=json.loads((BASE/"next-forecast-lock.json").read_bytes())
assert lock["frozen_sha256"]==FORECAST and lock["snapshot"]==581 and not lock["whole_source_seen"]
assert digest(BASE/"next-all-phase-forecast-581.npz")==FORECAST
sys.path.insert(0,str(BASE))
import fire_source as fs
import collect_particles as cp
from fire_source import np
from collect_particles import packet
check_old=fs.guard
def guard():
    check_old()
    assert not any((p/"STOP-REQUESTED").exists() for p in (HERE,BASE,ROOT))
    assert digest(BASE/"seal.json")==SEAL
fs.guard=cp.guard=guard
fs.HERE=cp.HERE=HERE
def old(name):
    assert name in manifest and digest(BASE/name)==manifest[name],name
    return BASE/name
def from_old(name,remote):
    if name in manifest:return old(name).read_bytes()
    raise KeyError(name)
cp.fetch_small=from_old
def acquire(*args):
    for piece in args:
        assert int(piece) in range(4)
        cp.collect(581,int(piece))
if __name__=="__main__":acquire(*sys.argv[1:])
