from collections import Counter
import csv
from local_581 import BASE, HERE, ROOT, FORECAST, digest, fs, guard, json, manifest, np, old

TOL = 2e-5
SITES = ("inner_radial","inner_polar","outer_radial","outer_polar","anchor_inward")
BRANCHES = ("anchorA","cut1","cut2")
def table(name):
    with (HERE/(name+".csv")).open(encoding="utf-8-sig",newline="") as stream:
        return list(csv.DictReader(stream))

def obj(name):
    return json.loads((HERE/(name+".json")).read_bytes())

def run():
    guard()
    for name in manifest:
        old(name)
    assert len(manifest)==244
    replay=ROOT/"mts-lmc-axisymmetric-retarded-replay-20261120"/"replay.json"
    assert digest(replay)=="ac3e29395d6ceeeca6a4dfb52528cf429c000dcdd981ddd14650ed9e95840cbf"
    direct=json.loads(replay.read_bytes())
    assert len(direct["controls"])==12 and len(direct["bands"])==192 and direct["tolerance"]==TOL
    grouped={}
    for row in direct["bands"]:
        assert (row["low"]<=row["total"]<=row["high"])==row["inside"]
        assert row["inside"]==(row["component"]=="polar" and row["R"]==8.3)
        grouped.setdefault((row["ground"],row["history"],row["model"]),[]).append(row["inside"])
    assert len(grouped)==24 and all(len(rows)==8 and sum(rows)==2 for rows in grouped.values())
    verified=obj("held-out-result")
    assert verified["forecast_sha256"]==FORECAST
    pieces=[obj("mass-581-"+str(piece)) for piece in range(4)]
    for piece,receipt in enumerate(pieces):
        assert receipt["piece"]==piece and digest(HERE/f"mass-581-{piece}.npz")==receipt["bank_sha256"]
    assert verified["particle_counts"]==pieces[0]["counts_whole"]==np.sum([rec["counts_piece"] for rec in pieces],axis=0).tolist()
    assert verified["range_bytes"]==sum(rec["bytes_received"] for rec in pieces)
    with np.load(HERE/"actual-raw-581.npz") as raw,np.load(old("next-all-phase-forecast-581.npz")) as pred:
        weights=pred["probability"];potential=raw["raw_total"];target=potential-np.sum(potential*weights)
        assert abs(weights.sum()-1)<1e-12
        for rec in verified["comparison"]:
            expected=np.sqrt(np.sum(weights*(target-pred[rec["frozen_model"]])**2))
            assert abs(expected-rec["weighted_RMS_kms2"])<1e-9
    prior="572_579_586_590_600"
    checked=0;max_norm=max_work=repeat=0.;miss_tot=miss_ind=flips=0
    counts={};raw_errors={}
    for branch in BRANCHES:
        for kind in (("joint","raw_actual","raw_linear","raw_cold_detail","repeat5") if branch=="anchorA" else ("joint",)):
            for steps in ((64,) if kind=="repeat5" else (32,64)):
                tag=f"{branch}-{kind}-{steps}"
                stem=f"analog-wave-anchorA-{steps}" if kind.startswith("raw_") else f"wave-{branch}-joint-{steps}"
                with np.load(old(stem+"-"+prior+".npz")) as previous,np.load(HERE/("wave-"+tag+".npz")) as new:
                    assert np.array_equal(new["states"][0],previous["states"][1])
                    assert np.array_equal(new["snapshots"],[579,586,590,600] if kind=="repeat5" else [579,581,586,590,600])
                    assert np.isfinite(new["states"]).all()
                    if kind=="repeat5":
                        repeat=np.linalg.norm(new["states"][-1]-previous["states"][-1])/np.linalg.norm(previous["states"][-1])
                        assert repeat<1e-10
                rows=table("evolution-"+tag)
                assert int(rows[-1]["snapshot"])==600
                max_norm=max(max_norm,max(float(row["max_number_error"]) for row in rows))
                max_work=max(max_work,max(float(row["max_work_error_kms2"]) for row in rows))
                checked+=1
        coarse=table(f"bands-{branch}-joint-32");fine=table(f"bands-{branch}-joint-64")
        assert len(coarse)==len(fine)==96
        inside=Counter();sizes=Counter()
        for first,second in zip(coarse,fine):
            keys=("model","history","R","z","component","ground","low","high")
            assert all(first[key]==second[key] for key in keys)
            model=second["model"];key=(model,second["history"])
            for rec in (first,second):
                ground,induced,total,low,high=(float(rec[k]) for k in ("ground","induced","total","low","high"))
                assert abs(ground+induced-total)<1e-13 and (low<=total<=high)==(rec["inside"]=="True")
                if model=="static_NFW":assert induced==0
            inside[key]+=int(second["inside"]=="True");sizes[key]+=1
            flips+=first["inside"]!=second["inside"]
            miss_tot+=abs(float(first["total"])-total)>TOL*abs(total)
        assert len(inside)==12 and set(sizes.values())=={8}
        for (model,_),count in inside.items():
            assert count==(2 if model=="MTS" or branch=="anchorA" else 4)
            counts[branch+"_"+model]=count
        first,last=[table(f"evolution-{branch}-joint-{order}")[-1] for order in (32,64)]
        miss_ind+=sum(abs(float(first[k])-float(last[k]))>TOL*abs(float(last[k])) for k in SITES)
        path, gap=obj("inheritance-"+branch),obj("initial-gap-"+branch)
        rows=table("path-direction-bounds-"+branch)
        assert len(rows)==6 and path["force_cap"]<path["necessary_force"]
        assert abs(sum(float(row["certified_kms2"]) for row in rows[1:])-path["path_cost_bound_kms2"])<1e-8
        assert abs(path["cap_specific_kms2"]-path["starting_reference_offset_kms2"]-max(path["entry_cost_bound_kms2"],path["path_cost_bound_kms2"])-1e-5-gap["local_excitation_floor_kms2"])<1e-8
        assert 0<gap["compensated_floor_kms2"]<=gap["local_excitation_floor_kms2"] and gap["negative_inertia"]==1
    for kind in ("raw_linear","raw_cold_detail"):
        obs=table("evolution-anchorA-raw_actual-64")[-1];alt=table("evolution-anchorA-"+kind+"-64")[-1]
        with np.load(HERE/"wave-anchorA-raw_actual-64.npz") as actual,np.load(HERE/f"wave-anchorA-{kind}-64.npz") as pred:
            state=actual["states"][-1];other=pred["states"][-1];overlap=np.vdot(other,state)
            difference=np.linalg.norm(state-other*overlap/abs(overlap))/np.linalg.norm(state)
        raw_errors[kind]={k:float(alt[k])-float(obs[k]) for k in (*SITES,"final_reference_excess_kms2")}
        raw_errors[kind]["phase_aligned_state_fraction"]=float(difference)
    gates=table("energy-reachability")
    assert len(gates)==36 and all(r["fine_certificate"]=="True" and float(r["demand_over_upper"])>1 for r in gates)
    assert checked==13 and max_norm<1e-10 and max_work<.0003 and flips==0
    report=dict(previous_files=len(manifest), direct_comparisons=len(direct["bands"]), exact_579_restarts=checked,
                five_knot_replay_error=repeat,max_number_error=max_norm,max_work_error_kms2=max_work,
                same_band_counts_out_of_eight=counts,terminal_total_refinement_misses_out_of_288=int(miss_tot),
                induced_refinement_misses_out_of_15=int(miss_ind),band_flips=int(flips),
                simulation_prediction_errors_minus_actual=raw_errors, smallest_required_over_free_upper=min(float(r["demand_over_upper"]) for r in gates))
    fs.record("validation.json",report)
    print(json.dumps(report,indent=2),flush=True)
    if "--seal" in __import__("sys").argv:
        assert all((HERE/k).is_file() for k in ("DERIVATION.md","REPLAY.md","RESULTS.md"))
        assert all(path.is_file() for path in HERE.iterdir())
        files={p.name:digest(p) for p in sorted(HERE.iterdir()) if p.name!="seal.json"}
        fs.record("seal.json",{"files":files})
        print("verified",len(files),"files; SHA-256",digest(HERE/"seal.json"))
if __name__=="__main__":
    run()
