from source_check import *
from barrier import ingredients,sparse,splu
from certificate_check import inertia
from disk import CENSUS,BRANCHES

SN=(572,579,581,586,590,600)
PRIOR=ROOT/"mts-fixed-number-disk-assembly-20261120"
def run(branch):
    obj=jf.Assembly(branch);bg=obj.bg;g=obj.ground;num=obj.number;unit=bg.vel**2/num
    read=jf.parent.read
    fg,=[r for r in read(CENSUS,"equilibria") if r["branch"]==branch]
    fields=[]
    for snap in SN:
        with np.load(force_path(snap)) as bank:fields.append(bank["joint"]*(1-float(fg["fraction"]))/bg.vel**2)
    with np.load(old(f"wave-{branch}-joint-64-572_579_586_590_600.npz")) as bank:g0=bank["states"][0].real.copy()
    initial_H=obj.bare+obj.wave.mult(fields[0])
    ci=obj.energy(g0,initial_H)-obj.energy(g,initial_H)
    giang=np.arcsin(np.linalg.norm(g0-(g@g0/num)*g)/np.sqrt(num))
    h,mix,gram,order,gauge,B=ingredients(obj)
    base_quench=float(read(PRIOR,"stationary-"+branch)[0]["excess_at_final"])
    rows=[r for r in read(PRIOR,"extra-work-trials-"+branch) if r["shape_neg"]==r["force_neg"]=="1" and r["enough_direction_margin"]=="True"]
    chosen=max(rows,key=lambda r:float(r["factor"]))
    e=float(chosen["factor"])*base_quench;S=float(chosen["loss"]);eta=.25
    eps=(2*np.sqrt(num*S)+np.sqrt(num)*S)*np.linalg.norm(h@g)
    top=h-.5*(1+1/eta)*num*S*B;cross=np.sqrt(2*(1+eta))*mix
    def pencil(add):
        block=sparse.bmat([[top+add,cross],[cross.T,gram]],format="csr")
        return block[order,:][:,order]
    col=sparse.csc_matrix(gauge[:,None]);P=pencil(0*obj.identity)
    trapneg,_,_=inertia(pencil(-obj.identity*1.00001*(e+eps)/(num*S)),gauge[:,None],np.zeros((1,1)))
    assert trapneg==1
    zero=sparse.bmat([[P,col],[col.T,None]],format="csc");solver=splu(zero)
    records=[]
    def bound(U,label,initial):
        op=obj.wave.mult(U)
        avg=(g@(op@g))/num
        A=op-avg*obj.identity
        source=A@g
        sigma=np.linalg.norm(source)/np.sqrt(num)
        rough=num*(2*np.sqrt(S*(1-S))*sigma+S*max(0.,U.max()-avg))
        rhs=np.r_[np.r_[source,np.zeros(gram.shape[0])][order],0.]
        sol=solver.solve(rhs)
        assert np.linalg.norm(zero@sol-rhs)<1e-8*np.linalg.norm(rhs)
        c0=float(rhs@sol);assert c0>0
        trial=np.sqrt((e+eps)/c0);options=[(rough,0.,0.)]
        for frac in (1.,.65):
            tilt=frac*trial
            if initial and tilt<=1.00001:continue
            mat=pencil(-tilt*A)
            sysmat=sparse.bmat([[mat,col],[col.T,None]],format="csc");solution=splu(sysmat).solve(rhs)
            if np.linalg.norm(sysmat@solution-rhs)>1e-8*np.linalg.norm(rhs):continue
            cap=float(rhs@solution)*1.00002
            if cap<=0:continue
            n,_,_=inertia(mat,np.column_stack((gauge,rhs[:-1])),np.diag([0.,cap]))
            if n==1:options.append(((e+eps)/tilt+tilt*cap,tilt,cap))
        use,t,c=min(options)
        records.append(dict(branch=branch,label=label,rough_kms2=rough*unit,certified_kms2=use*unit,tilt=t,compliance=c,
                            mean_specific_kms2=avg*bg.vel**2,tangent_specific_kms2=sigma*bg.vel**2))
        return use
    enter=bound(-fields[0],"enter",True)
    steps=[bound(hi-lo,f"{s0}_{s1}",False) for lo,hi,s0,s1 in zip(fields[:-1],fields[1:],SN[:-1],SN[1:])]
    floor=(e-ci-max(enter,sum(steps)))*unit-1e-5
    target=min(float(r["required_extra_inward"]) for r in read(PRIOR,"certified-"+branch))
    rec=dict(branch=branch,cap_specific_kms2=e*unit,terminal_overlap_trap=S,initial_grounds_angle_rad=giang,
             initial_ground_loss_gate=np.sin(max(0.,np.arcsin(np.sqrt(S))-giang))**2,starting_reference_offset_kms2=ci*unit,
             entry_cost_bound_kms2=enter*unit,path_cost_bound_kms2=sum(steps)*unit,possible_initial_excitation_floor_kms2=floor,
             force_cap=float(chosen["force_bound"]),necessary_force=target,result="positive_bound" if floor>0 and giang<np.arcsin(np.sqrt(S)) else "inconclusive")
    jf.table("path-direction-bounds-"+branch,records);fs.record("inheritance-"+branch+".json",rec);print(rec,flush=True)
if __name__=="__main__":
    for branch in BRANCHES:run(branch)
