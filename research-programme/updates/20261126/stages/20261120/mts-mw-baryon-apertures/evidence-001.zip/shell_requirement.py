from census_profile import phases
from source_models import *
def run():
    guard();obs=old.LENS.stars;axis=np.unique(np.r_[1.,obs.axis[(obs.axis>1)&(obs.axis<2)],2.])
    vals=obs.local.sum(axis=1)
    stars=1000*np.trapezoid(np.interp(axis,obs.z,vals)+np.interp(-axis,obs.z,vals),axis)
    gas=phases(2.)-phases(1.);bd=1.2*(np.exp(-1/.4)-np.exp(-2/.4));central=stars+gas+bd
    rows=[]
    for row in readfile(HERE/'one-to-two-kpc-contrast.csv'):
        if row['occupation']!='2':continue
        fixed=float(row['d_dark'])+float(row['d_radial'])
        rows.append(dict(material=row['material'],R0_convention=row['R'],halo=row['halo'],local_lian_stars=stars,gas=gas,BD=bd,
                         counted_shell_without_Gum=central,counted_shell_including_max_Gum=central+.11,
                         dark_plus_radial_current=fixed,required_change_central_low=28.4-(central+.11)-fixed,
                         required_change_central_high=28.4-central-fixed,required_change_low_with_margin=25.2-(central+.11)-fixed))
    table('measured-shell-requirement',rows)
if __name__=='__main__':run()
