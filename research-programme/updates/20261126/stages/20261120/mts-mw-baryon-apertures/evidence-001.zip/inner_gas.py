from aperture_io import *
import pymupdf
import numpy as np

def extract():
    path=HERE/'sources/inner-gas.pdf';page=pymupdf.open(path)[10]
    assert 'Fig. 11.' in page.get_text()
    ds=page.get_drawings()
    v=sorted(d['rect'].x0 for d in ds if 138.6<d['rect'].height<138.8 and d['rect'].width==0 and 75<d['rect'].x0<297)
    h=sorted([d['rect'].y0 for d in ds if 220.5<d['rect'].width<220.8 and d['rect'].height==0 and 236<d['rect'].y0<364 and d['color'] and .69<d['color'][0]<.72],reverse=True)
    assert len(v)==9 and len(h)==6
    px=np.polyfit(v,range(9),1);py=np.polyfit(h,np.arange(6)*2,1)
    assert max(abs(np.polyval(px,v)-np.arange(9)))<.003 and max(abs(np.polyval(py,h)-np.arange(6)*2))<.001
    rows=[]
    for idx,d in enumerate(ds):
        box=d['rect'];x=.5*(box.x1+box.x0);y=.5*(box.y1+box.y0);radius=np.polyval(px,x)
        if not (5.15<radius<6.86 and 225<box.y0<box.y1<364 and 3.6<box.width<3.85):continue
        if d['type']=='fs' and d['items'][0][0]=='re' and d['color'][-1]>.87:kind='HI'
        elif d['type']=='s' and len(d['items'])==2 and d['items'][0][0]=='c' and d['color'][0]==1:kind='H2'
        else:continue
        bars=[v['rect'] for v in ds if v['type']=='s' and v['color']==d['color'] and v['rect'].width<.001 and abs(v['rect'].x0-x)<.06 and 225<=v['rect'].y0<y<v['rect'].y1<365]
        assert len(bars)==1,(kind,radius,len(bars))
        bar=bars[0];value=np.polyval(py,y);lower=np.polyval(py,bar.y1);upper=np.polyval(py,bar.y0)
        clipped=abs(bar.y1-h[0])<.01
        assert (clipped and kind=='H2' and 6.79<radius<6.83) or abs((lower+upper)/2-value)<.012
        rows.append(dict(phase=kind,R_kpc=radius,surface_H=value,printed_low='' if clipped else lower,printed_high=upper,clipped_at_zero=clipped,marker_path=idx,bar_x=bar.x0,marker_y=y))
    assert len(rows)==18 and len({round(r['R_kpc'],2) for r in rows})==9
    table('measured-inner-neutral',rows)
    return rows
if __name__=='__main__':extract()
