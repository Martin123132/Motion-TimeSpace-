from vertical_gravity import *
def run():
    frozen();rows=[];bg=pre.background(1);suite=io.readfile(io.HERE/'vertical-gravity.csv')
    for tag in ('archive','count_one','count_split'):
        order=0 if tag=='archive' else 96;ref=f'-ell{order}' if order else ''
        file=io.HERE/f'grounds/{tag}-1-2{ref}.npz' if order else io.LIVE/'grounds/mesh1-occ2.npz'
        with np.load(file) as state:wave=wave_field(bg,state['g'])
        f=native(tag,order);halo=nfw(0)
        fq=io.readfile(io.HERE/f'paired-1{ref}.csv')
        scale=float(next(r['nfw_scale'] for r in fq if r['kind']=='NFW' and r['occupation']=='2' and r['material']==tag))
        for radius in (8.3,8.5):
            for height in (1.,2.):
                for kind in ('MTS','NFW'):
                    record=next(r for r in suite if (r['material'],r['occupation'],float(r['R']),float(r['z']),r['halo'])==(tag,'2',radius,height,kind))
                    expected=float(record['poisson_radial_term'])
                    def integrate(step,order):
                        h,w=roots_legendre(order);zz=(h+1)*height/2
                        def terms(rad):
                            pts=np.column_stack((np.full_like(zz,rad),np.zeros_like(zz),zz))
                            dr=wave(rad,zz)[0] if kind=='MTS' else scale*halo(rad,zz)[0]
                            return np.stack([f(pts)[:,1],dr])
                        derivative=sum(weight*terms(radius+idx*step) for idx,weight in ((-2,1),(-1,-8),(1,8),(2,-1)))/(12*step)
                        return ((derivative+terms(radius)/radius)@w)*(height/2)/(2*np.pi*old.G*1e6)
                    test=integrate(.012,32);fine=integrate(.006,64)
                    residual=expected-fine.sum()
                    rows.append(dict(material=tag,halo=kind,R=radius,z=height,ordinary_divergence=fine[0],dark_divergence=fine[1],force_minus_column=expected,
                                     difference=residual,refine=max(abs(test-fine))))
    io.table('poisson-radial-flux',rows)
if __name__=='__main__':run()
