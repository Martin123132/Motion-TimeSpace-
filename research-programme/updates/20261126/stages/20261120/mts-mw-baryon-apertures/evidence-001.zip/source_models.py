from aperture_io import *
from configparser import ConfigParser
import math
import os
for key in ('OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','OMP_NUM_THREADS','BLIS_NUM_THREADS','NUMEXPR_NUM_THREADS'):os.environ[key]='1'
import numpy as np
from scipy.integrate import quad
from scipy.special import roots_legendre
from functools import lru_cache
sys.path.insert(0,str(ROOT/'mts-lmc-slab-poisson-20261119'))
import slab_fields as old

template=(LIVE/'source/L2M10/fixed-ordinary.ini').read_text()
cfg=ConfigParser();cfg.read_string(template);bulge=cfg['Potential bulge'];disk=cfg['Potential disk']
UNIT_M=232500.;RD=float(disk['scaleRadius']);R0=8.3
def shape(rad):return (1+rad/float(bulge['scaleRadius']))**-float(bulge['beta'])*np.exp(-(rad/float(bulge['outerCutoffRadius']))**2)
central=float(bulge['mass'])*UNIT_M/(4*np.pi*quad(lambda r:r*r*shape(r),0,np.inf)[0])
def bulge_rho(radius,z):return central*shape(np.hypot(radius,z))*1e-9
@lru_cache(maxsize=128)
def bulge_col(radius,height):return 2e3*quad(lambda z:bulge_rho(radius,z),0,height,epsabs=1e-16)[0]
def sech(q):
    x=np.exp(-2*abs(q));return 4*x/(1+x)**2

def designs():
    bs=bulge_col(R0,np.inf);br=bulge_rho(R0,0.)
    def layer(col,rho):return col,col/(4e3*rho)
    return dict(archive=[(float(disk['mass'])*UNIT_M*np.exp(-R0/RD)/(2*np.pi*RD**2)*1e-6,abs(float(disk['scaleHeight'])))],
                count_one=[layer(47.1-bs,.084-br)],count_split=[layer(33.4-bs,.043-br),layer(13.7,.041)])
def materialize():
    rows=[]
    for tag,layers in designs().items():
        chunks=[template.split('[Potential disk]')[0]]
        for i,(col,h) in enumerate(layers):
            mass=2*np.pi*RD**2*np.exp(R0/RD)*col*1e6
            chunks.append(f'[Potential disk{i}]\ntype=Disk\nmass={mass/UNIT_M:.17g}\nscaleRadius={RD:.17g}\nscaleHeight={-h:.17g}\n\n')
            rows.append(dict(tag=tag,component=i,solar_column=col,height_parameter_kpc=h,midplane_density=col/(4000*h),disk_mass_msun=mass))
        if tag!='archive':put(tag+'.ini',''.join(chunks).encode())
    table('frozen-layer-calibrations',rows)
def analytic(tag,r,z,what,component='all'):
    layers=designs()[tag]
    if component=='star' and tag!='count_split':raise ValueError('unspecified stellar share')
    ans=(bulge_rho(r,z) if what=='rho' else bulge_col(r,z)) if component!='gas' else 0.
    for j,(col,h) in enumerate(layers):
        if component=='star' and j>0 or component=='gas' and j==0:continue
        local=col*np.exp((R0-r)/RD)
        ans+=local*(sech(z/(2*h))/(4000*h) if what=='rho' else np.tanh(z/(2*h)))
    return ans
@lru_cache(maxsize=256)
def retained_parts(case,r,z,what):
    stars=old.LENS.stars;surface=stars.radial(np.array([r]))[0]
    thin=np.full(len(surface),old.HEIGHT[0]);thin[0]=old.LENS.profile.heights(r)[0]
    heights=np.stack((thin,np.full(len(thin),old.HEIGHT[1])),axis=1)
    if what=='rho':
        vertical=np.exp(-abs(z)/heights)/(2*heights)*1e-9
        gas=sum(item.surface(r)*sech(z/(2*item.height))/(4*item.height)*1e-9 for item in old.gases())
    else:
        vertical=-np.expm1(-z/heights)*1e-6
        gas=sum(item.surface(r)*np.tanh(z/(2*item.height))*1e-6 for item in old.gases())
    each=surface*np.sum(stars.mix*vertical,axis=1);each[0]*=1+(old.RING if case and 4<r<7 else 0)
    angles,weight=old.rule(48,0,np.pi/2)
    planar=(r*np.cos(angles)/old.AXES[0])**2+(r*np.sin(angles)/old.AXES[1])**2
    def bar(zz):
        return (2/np.pi)*sum(old.LENS.central)/old.BAR_NORM*(old.k0((planar**2+(zz/old.AXES[2])**4)**.25)@weight)
    bar_mass=bar(z)*1e-9 if what=='rho' else 2e-6*quad(bar,0,min(z,25.))[0]
    return sum(each)+bar_mass,gas
def local_comparison():
    materialize();rows=[]
    for rad in (6.,8.2,8.3):
        for key,val,height,reading in [('plane',0.,0.,'rho'),('slab1100',1.1,1.1,'column'),('slab1500',1.5,1.5,'column'),('full',np.inf,np.inf,'column')]:
            for tag in ('archive','reference','added','count_one','count_split'):
                if tag in ('reference','added'):
                    stars,gas=retained_parts(int(tag=='added'),rad,val,reading);answer=stars+gas
                else:answer=analytic(tag,rad,val,reading)
                if rad==8.3:
                    central_val,width={'plane':(.084,.012),'slab1100':(43.8,3.4),'slab1500':(None,None),'full':(47.1,3.4)}[key]
                else:central_val,width=None,None
                rows.append(dict(tag=tag,R=rad,aperture=key,model=answer,census='' if central_val is None else central_val,
                            quoted_width='' if width is None else width,difference_in_published_widths='' if width is None else (answer-central_val)/width))
    for prev in readfile(LIVE/'ordinary-slab.csv'):
        for tag,key in [('archive','archive_total'),('reference','reference'),('added','added')]:
            value=next(r['model'] for r in rows if r['tag']==tag and r['aperture']=='slab1500' and r['R']==float(prev['R']))
            assert abs(value-float(prev[key]))<1e-8
    table('direct-apertures',rows)
    bounds=[]
    for widths in (0,1,2):
        lower=(47.1-3.4*widths-bulge_col(R0,np.inf))/(4000*(.084+.012*widths-bulge_rho(R0,0)))
        upper=(47.1+3.4*widths-bulge_col(R0,np.inf))/(4000*(.084-.012*widths-bulge_rho(R0,0)))
        assert upper<.4
        bounds.append(dict(widths=widths,h_min_kpc=lower,h_max_kpc=upper,archive_h=.4,shape_feasible=False))
    table('normalization-independent-height',bounds)

def sphere(tag,order,zsun,stellar):
    t,w=roots_legendre(order);rad=(t+1)*.05;phi=(np.arange(2*order)+.5)*np.pi/order
    rr=rad[:,None,None];mu=t[None,:,None];s=rr*np.sqrt(1-mu**2)
    R=np.sqrt(R0**2+s**2+2*R0*s*np.cos(phi));zz=zsun+rr*mu
    if tag=='count_split' and stellar:
        rho=analytic(tag,R,zz,'rho','star')
        rho-=1.2*np.exp((R0-R)/RD)*sech(zz/(2*.2))/(4000*.2)
    else:rho=analytic(tag,R,zz,'rho')
    return 1.5/.1**3*np.einsum('i,i,j,ij->',rad**2,w*.05,w,rho.mean(axis=2))
def sphere_test():
    out=[]
    for zsun in (0.,.020,.030):
        for tag in ('archive','count_one','count_split'):
            val=sphere(tag,24,zsun,True);assert abs(sphere(tag,12,zsun,True)-val)<1e-12
            out.append(dict(tag=tag,zsun_pc=round(1000*zsun),kind='stellar_excluding_brown_dwarfs' if tag=='count_split' else 'all_ordinary_upper_limit_on_stars',
                        in_sphere=val,kroupa=.040,kroupa_low=.034,kroupa_high=.052,chabrier=.037,chabrier_low=.031,chabrier_high=.049))
    table('nearby-stars-aperture',out)
if __name__=='__main__':local_comparison();sphere_test()
