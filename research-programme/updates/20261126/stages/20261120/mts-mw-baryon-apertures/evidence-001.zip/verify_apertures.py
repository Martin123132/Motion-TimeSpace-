from vertical_gravity import *
import hashlib,json
from source_models import sphere,retained_parts
from aperture_io import readfile
def run():
    frozen();guard=io.guard;guard()
    before=json.loads((io.LIVE/'seal.json').read_text());assert all(io.digest(io.LIVE/k)==v for k,v in before['files'].items())
    sources=readfile(io.HERE/'source-receipts.csv');assert len(sources)==3
    for r in sources:
        path=io.HERE/r['path'];assert io.digest(path)==r['sha256'] and path.stat().st_size==int(r['bytes'])
    lian=io.ROOT/'mts-population-resolved-gravity-20261119'
    dependency={r['file']:io.digest(lian/r['file']) for r in readfile(lian/'source-receipts.csv')};assert all(dependency[r['file']]==r['sha256'] for r in readfile(lian/'source-receipts.csv'))
    profile=readfile(io.HERE/'local-multiphase-profile.csv');assert all(float(b['central_low'])>float(a['central_high']) for a,b in zip(profile,profile[1:]))
    for r in readfile(io.HERE/'normalization-independent-height.csv'):
        assert 0<float(r['h_min_kpc'])<=float(r['h_max_kpc'])<float(r['archive_h'])
    gas=readfile(io.HERE/'measured-inner-neutral.csv');assert len(gas)==18 and sum(r['clipped_at_zero']=='True' for r in gas)==1
    inner=readfile(io.HERE/'inner-ordinary-inventory.csv')[4];assert abs(float(inner['HI_H2_He'])-9.33)<.015
    results=lambda n:readfile(io.HERE/(n+'.csv'))
    keys=('material','occupation','kind','R','z','component')
    group=lambda arr:{tuple(r[k] for k in keys):r for r in arr if r['material']!='archive'}
    base=group(results('direct-sky-1-ell96'));highest=group(results('direct-sky-1-ell160'));qa=[]
    for n in ('direct-sky-0','direct-sky-1','direct-sky-1-ell64','direct-sky-1-ell160'):
        trial=group(results(n));assert trial.keys()==base.keys()
        d=[];f=[]
        for key,r in trial.items():
            val=float(r['total']);target=float(base[key]['total'])
            assert r['inside']==base[key]['inside'] and abs(val-float(r['source'])-float(r['dark']))<1e-12
            d.append(abs(val-target));f.append(abs((val-target)/target))
        qa.append(dict(control=n,peak_absolute=max(d),peak_relative=max(f),decisions_changed=0,relative_gate=max(f)<2e-5))
    io.table('sky-resolution',qa);assert qa[-1]['relative_gate']
    rave=results('vertical-gravity');check=[];bg=pre.background(1)
    for tag in ('count_one','count_split'):
        f=native(tag,160)
        with np.load(io.HERE/f'grounds/{tag}-1-2-ell160.npz') as state:wave=wave_field(bg,state['g'])
        saved=results('paired-1-ell160')
        scale=float(next(r['nfw_scale'] for r in saved if (r['material'],r['kind'],r['occupation'])==(tag,'NFW','2')))
        for r in (8.3,8.5):
            for z in (1.,2.):
                target=np.array(sphere_field(r,z))
                for col,h in designs()[tag]:target+=disk_force(r,z,h,col*np.exp(R0/RD)*2*pi*RD**2*1e6,180,16)
                for kind,acc in [('MTS',wave(r,np.array([z]))[1][0]),('NFW',scale*nfw(0)(r,z)[1])]:
                    ref=next(v for v in rave if (v['material'],v['halo'],v['occupation'],float(v['R']),float(v['z']))==(tag,kind,'2',r,z))
                    kz=-(acc+target[2])/(2*pi*old.G*1e6);error=kz-float(ref['force_over_2piG'])
                    assert abs(error)<.025 and kz<float(ref['RAVE_equivalent_force'])-float(ref['RAVE_width'])
                    check.append(dict(tag=tag,kind=kind,R=r,z=z,refined_with_Hankel=kz,delta_vs_primary=error))
    io.table('vertical-gravity-refinement',check)
    contrast=results('one-to-two-kpc-contrast')
    for row in contrast:
        if row['material']!='archive':assert float(row['delta_force_equivalent'])<float(row['rectangular_low'])
    flux=results('poisson-radial-flux')
    assert max(abs(float(r['difference'])) for r in flux)<.02 and max(abs(float(r['refine'])) for r in flux)<3e-6
    vertical=results('integrated-wave-control');assert max(abs(float(r[k])) for r in vertical for k in ('radial_error','polar_error'))<1e-7
    hfiles={p.relative_to(io.HERE).as_posix():io.digest(p) for p in sorted(io.HERE.rglob('*')) if p.is_file() and p.name!='seal.json'}
    stamp=dict(parent_sha256=io.digest(io.LIVE/'seal.json'),parent_files_verified=len(before['files']),lian_inputs=dependency,files=hfiles,
               RAVE_reference='https://doi.org/10.1051/0004-6361/201424478',max_high_order_relative_change=qa[-1]['peak_relative'],
               max_RAVE_absolute_control=max(abs(r['delta_vs_primary']) for r in check))
    out=json.dumps(stamp,indent=2,sort_keys=True).encode()+b'\n'
    if '--seal' in sys.argv:io.put('seal.json',out)
    elif (io.HERE/'seal.json').is_file():assert (io.HERE/'seal.json').read_bytes()==out
    print('Verified',len(hfiles),'files;',len(before['files']),'parent files;',qa[-1]['peak_relative'],stamp['max_RAVE_absolute_control'])
if __name__=='__main__':run()
