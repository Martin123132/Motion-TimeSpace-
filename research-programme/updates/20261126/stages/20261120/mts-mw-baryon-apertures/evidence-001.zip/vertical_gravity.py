from matched_sky import *
from source_models import old,analytic,roots_legendre
from independent_disk import disk_force,sphere_field,designs,RD,R0
from math import pi
def wave_field(bg,g):
    sky=(g/bg.sqrt[:,None])@bg.harm.T
    den=(sky**2)@(bg.aw[:,None]*bg.harm)
    source=den/bg.rad[:,None]**2*(bg.vel/bg.length)**2
    return old.Multipoles(bg.rad*bg.length,source,bg.orders,0,bg.mesh.edge*bg.length,.02)
def observations():
    rows=[];checks=[];bg=pre.background(1);sphere=nfw(0)
    for tag in ('archive','count_one','count_split'):
        order=0 if tag=='archive' else 96;ref='' if not order else f'-ell{order}'
        f=native(tag,order);gr=io.readfile(io.HERE/f'stationary-1{ref}.csv')
        paired=io.readfile(io.HERE/f'paired-1{ref}.csv')
        for case in (0,1,2):
            base=next(r for r in gr if r['material']==tag and r['occupation']==str(case))
            gf=io.LIVE/f'grounds/mesh1-occ{case}.npz' if tag=='archive' else io.HERE/f'grounds/{tag}-1-{case}{ref}.npz'
            with np.load(gf) as file:ground=file['g']
            wave=wave_field(bg,ground)
            scale=float(next(r['nfw_scale'] for r in paired if r['kind']=='NFW' and r['material']==tag and r['occupation']==str(case)))
            for r in (6.,8.3,8.5):
                for z in (1.,1.1,1.5,2.):
                    pos=np.array([[r,0,z]]);ordinary=f(pos)[0,3];k=2*pi*old.G*1e6
                    nodes,wts=roots_legendre(24);zs=z*(nodes+1)/2
                    for model,fn,fac in [('MTS',wave,1.),('NFW',sphere,scale)]:
                        radial,dark,*_=fn(r,np.array([z]));dark=float(dark[0])*fac
                        den=fac*fn(r,zs)[3]/(4*pi*old.G)
                        column=z*(wts@den)*1e-6;rho=fac*fn(r,np.array([0.]))[3][0]/(4*pi*old.G)*1e-9
                        rho_b=analytic(tag,r,0.,'rho');sigma_b=analytic(tag,r,z,'column')
                        kz=-(dark+ordinary)/k
                        ref_k,err={1.:(68.5,1.),2.:(96.9,2.2)}.get(z,('','')) if r in (8.3,8.5) else ('','')
                        rows.append(dict(material=tag,occupation=case,halo=model,R=r,z=z,baryonic_column=sigma_b,dark_column=column,total_column=sigma_b+column,
                                    dark_mean_density=column/(2e3*z),midplane_dark=rho,midplane_baryonic=rho_b,force_over_2piG=kz,
                                    poisson_radial_term=kz-column-sigma_b,RAVE_equivalent_force=ref_k,RAVE_width=err,offset_in_quoted_widths='' if not err else (kz-ref_k)/err))
                        if z==1.5 and r in (6.,8.3) and model=='MTS':
                            rr=np.hypot(r,z);ar=UNIT*(radial[0]*r+dark*z)/rr;polar=UNIT*(radial[0]*z-dark*r)/rr
                            code='6' if r==6 else '83'
                            checks.append(dict(tag=tag,occupation=case,R=r,radial_error=ar-float(base['r'+code]),polar_error=polar-float(base['p'+code])))
    assert max(abs(r[k]) for r in checks for k in ('radial_error','polar_error'))<1e-7
    io.table('vertical-gravity',rows);io.table('integrated-wave-control',checks)

def native_check():
    oracle=io.readfile(io.HERE/'independent-disk-forces.csv');rows=[]
    for tag in ('count_one','count_split'):
        for order in (32,64,96):
            f=native(tag,order if order!=32 else 0)
            for item in oracle:
                if item['material']!=tag:continue
                r,z=float(item['R']),float(item['z']);k={'potential':0,'aR':1,'az':3}[item['component']]
                direct=float(item['hankel']);val=f([[r,0,z]])[0,k]
                rows.append(dict(material=tag,R=r,z=z,component=item['component'],order=order,absolute=abs(val-direct),
                            relative=abs(val-direct)/abs(direct) if abs(direct)>1e-7 else '',in_sky_units=abs(val-direct)*UNIT if k else ''))
    io.table('gravity-evaluator-refinement',rows)
if __name__=='__main__':frozen();native_check();observations()
