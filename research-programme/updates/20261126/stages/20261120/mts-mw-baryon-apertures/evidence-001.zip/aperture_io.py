from pathlib import Path
import csv,hashlib,io,sys
import requests
HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
LIVE=ROOT/'mts-live-host-halo-comparison-20261120'
def digest(path):
    with path.open('rb') as src:return hashlib.file_digest(src,'sha256').hexdigest()
def guard():
    assert digest(LIVE/'seal.json')=='b4108a60a498b169a0c4242bf7f689b3c64722dfccb7641020e99134461b265a'
    assert not any((p/'STOP-REQUESTED').exists() for p in (HERE,ROOT,LIVE))
def put(name,contents):
    guard();path=HERE/name;path.parent.mkdir(exist_ok=True,parents=True)
    if path.exists():assert path.read_bytes()==contents,name
    else:
        with path.open('xb') as dest:dest.write(contents)
def table(name,rows):
    buf=io.StringIO(newline='');out=csv.DictWriter(buf,rows[0],lineterminator='\n')
    out.writeheader();out.writerows(rows);put(name+'.csv',buf.getvalue().encode())
def readfile(path):
    with path.open(encoding='utf8',newline='') as src:return list(csv.DictReader(src))
def run():
    guard();sources=[('inventory','1509.05334v1'),('nearby','2507.06052v1'),('inner-gas','1707.00743v1')]
    rows=[]
    for key,version in sources:
        name='sources/'+key+'.pdf';url='https://arxiv.org/pdf/'+version
        if not (HERE/name).exists():
            with requests.get(url,timeout=35,stream=True) as response:
                response.raise_for_status();data=response.raw.read(16_000_001,decode_content=True)
            assert len(data)<=16_000_000 and data.startswith(b'%PDF') and b'%%EOF' in data[-1024:]
            put(name,data)
        rows.append(dict(key=key,url=url,path=name,bytes=(HERE/name).stat().st_size,sha256=digest(HERE/name)))
    table('source-receipts',rows)
if __name__=='__main__':run()
