from source_models import *
from scipy.special import j0,j1
from scipy.integrate import quad
from math import pi
GCODE=1/UNIT_M
def disk_force(radius,z,h,mass,limit,order):
    kg,kw=roots_legendre(order);n=max(4,int(np.ceil(limit*radius/pi)))
    kk=(np.arange(n)[:,None]+(kg+1)/2)*limit/n;ww=np.broadcast_to(kw[None,:]*limit/(2*n),kk.shape).ravel();kk=kk.ravel()
    edge=max(h*39,z+1)
    cuts=np.unique(np.clip(np.r_[-edge,edge,0.,z,h*np.array([-30,-14,-8,-4,-2,2,4,8,14,30]),
                  z+np.r_[-1,-.3,-.1,-.03,-.01,-.003,-.001,.001,.003,.01,.03,.1,.3,1]],-edge,edge))
    zq,zw=roots_legendre(order);nodes=(cuts[:-1,None]+np.diff(cuts)[:,None]*(zq+1)/2).ravel()
    weight=(np.diff(cuts)[:,None]*zw/2).ravel()*sech(nodes/(2*h))/(4*h)
    assert abs(weight.sum()-1)<1e-10
    diff=z-nodes;out=np.zeros(3)
    for start in range(0,len(kk),384):
        ind=slice(start,start+384);kval=kk[ind];common=ww[ind]*GCODE*mass/(1+(kval*RD)**2)**1.5
        att=np.exp(-kval[:,None]*abs(diff));positive=att@weight;odd=att@(np.sign(diff)*weight)
        out+=np.array([-j0(kval*radius)@(common*positive),-j1(kval*radius)@(common*kval*positive),-j0(kval*radius)@(common*kval*odd)])
    return out
def sphere_field(r,z):
    rad=np.hypot(r,z);enclosed=4*np.pi*central*quad(lambda a:a*a*shape(a),0,rad)[0]
    extra=4*np.pi*central*quad(lambda a:a*shape(a),rad,np.inf,epsabs=1e-16)[0]
    return [-GCODE*(enclosed/rad+extra),-GCODE*enclosed*r/rad**3,-GCODE*enclosed*z/rad**3]
def run():
    from matched_sky import native,UNIT,frozen
    frozen();rows=[]
    for tag,layers in designs().items():
        field=native(tag)
        for r,z in [(6.,1.5),(8.3,1.5),(17.58,0.),(8.3,.1),(6.,.3)]:
            aids=[]
            for limit,order in [(100,12),(200,16)]:
                value=np.array(sphere_field(r,z))
                for col,h in layers:value+=disk_force(r,z,h,col*np.exp(R0/RD)*(2*pi*RD**2)*1e6,limit,order)
                aids.append(value)
            high=aids[-1];true=field([[r,0,z]])[0,[0,1,3]]
            for j,key in enumerate(['potential','aR','az']):
                rows.append(dict(material=tag,R=r,z=z,component=key,native=true[j],hankel=high[j],coarse=aids[0][j],quadrature_change=abs(high[j]-aids[0][j]),
                                difference=true[j]-high[j],delta_in_sky_units='' if j==0 else (true[j]-high[j])*UNIT))
    table('independent-disk-forces',rows)
if __name__=='__main__':run()
