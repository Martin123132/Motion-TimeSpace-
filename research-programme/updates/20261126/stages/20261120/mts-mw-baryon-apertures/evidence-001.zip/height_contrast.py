from aperture_io import *
def run():
    guard();source=readfile(HERE/'vertical-gravity.csv');rows=[]
    for lo in source:
        if float(lo['z'])!=1. or float(lo['R']) not in (8.3,8.5):continue
        hi=next(r for r in source if r['z']=='2.0' and all(r[k]==lo[k] for k in ('R','halo','occupation','material')))
        def change(k):return float(hi[k])-float(lo[k])
        delta=change('force_over_2piG');want=96.9-68.5
        assert abs(delta-change('baryonic_column')-change('dark_column')-change('poisson_radial_term'))<1e-9
        rows.append(dict(material=lo['material'],occupation=lo['occupation'],R=lo['R'],halo=lo['halo'],d_baryon=change('baryonic_column'),
                         d_dark=change('dark_column'),d_radial=change('poisson_radial_term'),delta_force_equivalent=delta,
                         observed_difference=want,rectangular_low=want-3.2,rectangular_high=want+3.2,effective_density_shortfall=(want-delta)/2000))
    table('one-to-two-kpc-contrast',rows)
if __name__=='__main__':run()
