from inputs_local import *
from itertools import product
from scipy.linalg import eigvalsh

OLD=ROOT/"source-intake"/"functional_rg"/"5176"
TRANSITION=36.43917542575495
def rows(path):
    with path.open(newline="",encoding="utf-8-sig") as source:return list(csv.DictReader(source))
def run():
    guard();schedule=rows(OLD/"predeclared_seed_schedule.csv")
    assert len(schedule)==12
    report=[];paired=[];hashes=[]
    for seed in schedule:
        index=int(seed["seed_index"]);tag=seed["high_mode_seed"]
        parent_dir=OLD/"seeds"/f"seed_{index:02d}_{tag}"
        assert (parent_dir/"COMPLETE.marker").is_file()
        for family,subfolder in (("old_MTS","MTS_1E_MINUS20_ISOTROPIC_96"),("CDM","CDM_ISOTROPIC_96")):
            folder=parent_dir/"runs"/subfolder
            for sign in ("minus","plus"):
                path=folder/f"phase_{sign}_isolated_initial_state.npz"
                meta=json.loads((folder/f"phase_{sign}_snapshot_metadata.json").read_bytes())
                checksum=parent.sha(path);assert checksum==meta["snapshot_sha256"]
                with np.load(path) as snap:
                    pos=snap["positions_kpc"];vel=snap["velocities_km_s"];res=float(snap["resolved_radius_kpc"][0]);edge=float(snap["edge_radius_kpc"][0])
                assert len(pos)==int(meta["selected_particle_count"]) and res<TRANSITION<edge
                hashes.append(dict(seed=index,phase=sign,family=family,path=str(path.relative_to(OLD)),sha256=checksum))
                r2=np.einsum("ij,ij->i",pos,pos)
                for label,rad in (("transition",TRANSITION),("edge",edge)):
                    selected=r2<=rad**2
                    xyz=pos[selected]-pos[selected].mean(axis=0);speed=vel[selected]-vel[selected].mean(axis=0)
                    angular=np.cross(xyz,speed);net=angular.mean(axis=0)
                    tensor=angular.T@angular/len(angular);spectrum=eigvalsh(tensor)
                    assert spectrum[0]>0 and np.dot(net,net)<=sum(spectrum)
                    identity=np.mean(np.sum(xyz**2,axis=1)*np.sum(speed**2,axis=1)-np.einsum("ij,ij->i",xyz,speed)**2)
                    assert abs(sum(spectrum)/identity-1)<1e-10
                    report.append(dict(seed=index,phase=sign,family=family,aperture=label,radius_kpc=rad,selected=selected.sum(),
                                       orientation_averaged_j_rms=np.sqrt(sum(spectrum)/3),net_j=np.linalg.norm(net),
                                       least_axis_rms=np.sqrt(spectrum[0]),greatest_axis_rms=np.sqrt(spectrum[-1]),
                                       min_to_max_second_moment=spectrum[0]/spectrum[-1]))
    for row in (r for r in report if r["family"]=="old_MTS"):
        match,=[r for r in report if r["family"]=="CDM" and all(r[k]==row[k] for k in ("seed","phase","aperture"))]
        paired.append(dict(seed=row["seed"],phase=row["phase"],aperture=row["aperture"],
                           old_mts=row["orientation_averaged_j_rms"],cold=match["orientation_averaged_j_rms"],
                           relative_difference=row["orientation_averaged_j_rms"]/match["orientation_averaged_j_rms"]-1))
    assert len(report)==96 and len(paired)==48 and len(hashes)==48
    table("paired-old-patch-moments",report);table("paired-old-patch-comparison",paired);table("old-patch-input-hashes",hashes)
if __name__=="__main__":run()
