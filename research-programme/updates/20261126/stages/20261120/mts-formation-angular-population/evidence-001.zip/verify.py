from inputs_local import BRANCHES, CENSUS, HERE, LAST, ROOT, guard, np, parent, put
from collections import defaultdict
import json

def check():
    guard()
    parents = 0
    def dump(name, value):
        put(name,(json.dumps(value,indent=2,sort_keys=True,allow_nan=False)+"\n").encode())
    def read(name):
        return parent.read(HERE,name)
    for folder in (CENSUS,LAST):
        for name, digest in json.loads((folder/"seal.json").read_bytes())["files"].items():
            assert parent.sha(folder/name)==digest,(folder,name)
            parents += 1
    patches = read("old-patch-input-hashes")
    assert len({row["path"] for row in patches})==len(patches)==48
    for row in patches:
        assert parent.sha(ROOT/"source-intake"/"functional_rg"/"5176"/row["path"])==row["sha256"]
    assert len(read("paired-old-patch-moments"))==96 and len(read("matched-current"))==6
    assert len(read("kernel-controls"))==12 and all(abs(float(row["total"])-1)<1e-10 for row in read("kernel-controls"))
    compare_count = 0
    counts = {}
    for branch in BRANCHES:
        for band, level in (("screen","fine"),("screen","coarse"),("finite","fine")):
            tag = "-".join((branch,band,level))
            entries = read("signed-"+tag)
            grouped = defaultdict(list)
            assert len(entries)==192
            for row in entries:
                total, low, high = map(float,(row["predicted"],row["low"],row["high"]))
                assert low<high and np.isfinite(total)
                assert (low<=total<=high)==(row["inside"]=="True")== (row["old_inside"]=="True")
                if row["model"]=="static_NFW":assert float(row["population_change"])==0
                grouped[row["environment"],row["model"],row["history"]].append(row)
            assert len(grouped)==24
            for (env,model,history),group in grouped.items():
                assert len({(row["R"],row["z"],row["component"]) for row in group})==len(group)==8
                count=sum(row["inside"]=="True" for row in group)
                key=" ".join((branch,env,model))
                assert counts.setdefault(key,count)==count
            compare_count+=len(entries)
            with np.load(HERE/("state-"+tag+".npz")) as state:
                assert all(np.isfinite(state[key]).all() for key in state)
                assert float(state["occupation"])>0 and abs(float(state["tail"]))<1e-7
            iterations=read("iterations-"+tag)
            assert float(iterations[-1]["max_change"])<1e-11
            assert max(float(row["number_error"]) for row in iterations)<1e-10
            occ=read("occupations-"+tag)
            assert abs(sum(float(row["fraction"]) for row in occ)-1)<1e-10 and all(float(row["energy_native"])<0 for row in occ)
        shape,=[row for row in read("principal-shape-test") if row["branch"]==branch]
        assert 0<=float(shape["passive_squared_overlap_loss"])<float(shape["min_required"])<=float(shape["max_required"])<1
    lmc=ROOT/"mts-lmc-axisymmetric-retarded-replay-20261120"/"replay.json"
    assert parent.sha(lmc)=="ac3e29395d6ceeeca6a4dfb52528cf429c000dcdd981ddd14650ed9e95840cbf"
    replay=json.loads(lmc.read_bytes())
    assert len(replay["controls"])==12 and len(replay["bands"])==192
    panels=parent.read(ROOT/"mts-axisymmetric-density-shell-readout-20261120","panels")
    assert len(panels)==48 and all((row["passed"],row["tested"])==("2","8") for row in panels)
    assert not [item for item in HERE.iterdir() if not item.is_file() or item.suffix not in (".py",".csv",".npz",".md",".json")]
    dump("validation.json",dict(prior_files=parents,archived_snapshots=len(patches),stationary_signed_rows=compare_count,
                                 stationary_passes_per_history=counts,original_LMC_replay_sha256=parent.sha(lmc),
                                 original_LMC_cases_times_controls_times_domains=len(panels)))
    files={f.name:parent.sha(f) for f in HERE.iterdir() if f.name!="seal.json"}
    dump("seal.json",dict(files=files))
    print(len(files),"verified; seal",parent.sha(HERE/"seal.json"))
if __name__=="__main__":check()
