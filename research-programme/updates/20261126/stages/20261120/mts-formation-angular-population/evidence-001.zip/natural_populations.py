from angular_seed import *
from scipy.linalg import eigh

def unequal(R,heavy,vol,pick,nr,na):
    k=vol["k_Mpc_inverse"][pick];power=vol["primordial_power"][pick];ln=np.log(k)
    weights=np.sqrt(power*(np.r_[0.,np.diff(ln)]+np.r_[np.diff(ln),0.])/2)
    density=vol["heavy_coordinate_number_contrast"][pick]
    phase=vol["heavy_spatial_phase"][pick]
    win=3*jratio(k*R)
    selector=weights*win*vol["heavy_physical_density"][pick]
    selector/=np.linalg.norm(selector)
    node,rw=roots_legendre(nr);rs=R*(1+node)/2;rw=1.5*rw*(rs/R)**2
    ang,aw=roots_legendre(na);poly=legvander(ang,36)
    size=(nr,nr,na);dd,ss,ds=np.zeros((3,*size));rr=rs[:,None]*k
    for level in range(37):
        coef=spherical_jn(level,rr);drows=coef*(density*weights)
        removed=coef-1 if level==0 else (coef-rr*win/3 if level==1 else coef)
        srows=removed*(phase*weights)
        if level==0:
            meanD=drows@selector;meanS=srows@selector
            drows=drows-np.outer(meanD,selector);srows=srows-np.outer(meanS,selector)
        y=(2*level+1)*poly[:,level]
        dd+=(drows@drows.T)[:,:,None]*y
        ss+=(srows@srows.T)[:,:,None]*y
        ds+=(drows@srows.T)[:,:,None]*y
    def equal_zero(spec):
        return np.diag(np.tensordot(spec,(aw[:,None]*poly)@((2*np.arange(37)+1)/2),axes=([2],[0])))
    sv=equal_zero(ss);dv=equal_zero(dd);cross=equal_zero(ds)
    var=sv[:,None,None]+sv[None,:,None]-2*ss
    assert np.min(var)>-1e-14
    first=ds-cross[:,None,None];second=cross[None,:,None]-ds.transpose(1,0,2)
    phase_factor=np.exp(1j*(meanS[None,:]-meanS[:,None]))[:,:,None]
    kernel=np.exp(-.5*var)*phase_factor*((1+meanD[:,None,None]/2+.5j*first)*(1+meanD[None,:,None]/2+.5j*second)+dd/4)
    trace=rw@((1+meanD/2)**2+dv/4);kernel/=trace
    harmon=np.tensordot(kernel,aw[:,None]*poly/2,axes=([2],[0]))
    multiplicities=[];eig=[]
    for level in range(37):
        matrix=harmon[:,:,level]*np.sqrt(rw[:,None]*rw)
        assert np.max(abs(matrix-matrix.conj().T))<1e-13
        values=eigh(matrix,eigvals_only=True)[::-1]
        assert values.min()>-1e-12
        eig.append(values);multiplicities.append((2*level+1)*values.sum())
    return eig,np.array(multiplicities),sv,dv

def run():
    guard()
    heavy,cold,vol=[data(n) for n in ("late-heavy","late-cold","volume-state")]
    screened=(heavy["both_scale_screens_pass"]==1)&(cold["both_scale_screens_pass"]==1)
    original=parent.read(HERE,"angular-summary");old=parent.read(HERE,"total-angular-degree")
    results=[];modes=[];control=[]
    for branch in BRANCHES:
        for band,pick in (("screen",screened),("finite",np.ones(len(screened),bool))):
            opts=dict(branch=branch,band=band,conditioning="one_sigma",amplitude="linear_amplitude")
            same=lambda r:all(r[k]==v for k,v in opts.items())
            src,=[r for r in original if same(r)];R=float(src["R_comoving_Mpc"])
            ref=np.array([float(r["fraction"]) for r in old if same(r)])
            prev={}
            for nr,na in ((12,72),(24,120)):
                eig,occup,_,_=unequal(R,heavy,vol,pick,nr,na)
                defect=np.max(abs(occup-ref[:len(occup)]))
                assert abs(sum(occup)-1)<1e-10 and defect<1e-10,(defect,sum(occup))
                for m in range(9):
                    for par in (0,1):
                        levels=range(m+par,len(eig),2)
                        values=np.sort(np.concatenate([eig[el] for el in levels]))[::-1]
                        mult=1 if m==0 else 2
                        if nr==12:prev[m,par]=values[:10].copy();continue
                        delta=max(abs(values[:10]-prev[m,par]))
                        assert delta<1e-10,delta
                        for rank,value in enumerate(values[:10]):
                            modes.append(dict(branch=branch,band=band,abs_m=m,parity=par,rank=rank,
                                              fraction_per_sign=value,fraction_combined=mult*value))
                        results.append(dict(branch=branch,band=band,abs_m=m,parity=par,sector_fraction=mult*values.sum(),
                                            leading_fraction=mult*values[0],other_fraction=mult*sum(values[1:]),
                                            top10_refinement=delta,angular_trace_error=defect))
                control.append(dict(branch=branch,band=band,nr=nr,na=na,total=sum(occup),max_equal_radius_difference=defect))
    table("natural-eigenvalues",modes);table("radial-purity",results);table("kernel-controls",control)

if __name__=="__main__":run()
