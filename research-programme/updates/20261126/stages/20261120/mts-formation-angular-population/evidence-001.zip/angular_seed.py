from inputs_local import *
from scipy.special import roots_legendre,spherical_jn,eval_legendre
from numpy.polynomial.legendre import legvander

def jratio(x):
    return np.where(abs(x)<.05,1/3-x*x/30+x**4/840-x**6/45360,spherical_jn(1,x)/np.maximum(x,1e-300))
def small_remainder(x):
    return np.where(abs(x)<.05,x**4*(1/120-x*x/5040+x**4/362880),np.sinc(x/np.pi)-1+x*x/6)
def spectrum(column,condition,band,R,order,completion):
    k,p,phase,delta,selector=column
    pick=band
    k,p,phase,delta,selector=[v[pick] for v in column]
    ln=np.log(k);weight=(np.r_[0.,np.diff(ln)]+np.r_[np.diff(ln),0.])*p/2
    sw=weight*phase**2;dw=weight*delta**2;cross=weight*phase*delta
    win=3*jratio(k*R);constraint=selector*win;sd=np.sqrt(weight@constraint**2)
    nodes,angular_weights=roots_legendre(order);radnode,wr=roots_legendre(order//3)
    radii=R*(radnode+1)/2;rad_weights=1.5*wr*(radii/R)**2
    ell=np.arange(41);basis=legvander(nodes,40)*((2*ell+1)/2)*angular_weights[:,None]
    populations=np.zeros(len(ell));norm=0.;lz2=0.;classical=0.;phase_only_lz=0.;peak_transfer=0.
    for rad,rw in zip(radii,rad_weights):
        kr=k*rad;sep=np.sqrt(2*(1-nodes))[:,None]*kr;dx2=sep*sep
        j=jratio(kr);j0=spherical_jn(0,kr)
        coeff=(1-win)**2/3+2*win*(1/3-j)
        rem=small_remainder(sep);var=(-2*rem+dx2*coeff)@sw
        assert var.min()>-1e-12
        cov=(rem+dx2*.5*(win*j-1/3))@cross
        dsq=(dx2/6-rem)@dw
        local_s=weight@(constraint*delta*j0)/sd
        dmean=0 if condition is None else condition*local_s
        dvar=dw.sum()-(0 if condition is None else local_s**2)
        assert dvar>=0
        ref=(1+dmean/2)**2+dvar/4
        tangential=2*rad**2/3*(sw@(k**2*coeff))
        if completion=="phase":
            ref=1.;overlap=np.exp(-.5*var);extra=0.
        elif completion=="log":
            ref=np.exp(dmean+(dvar-dw.sum())/2);overlap=ref*np.exp(-var/2-dsq/4)
            extra=ref*2*rad**2/3*(dw@(k**2/3))/4
        else:
            overlap=np.exp(-.5*var)*(ref+(-dsq+cov**2)/4)
            extra=2*rad**2/3*(dw@(k**2/3))/4
        populations+=rw*(overlap@basis);norm+=rw*ref
        lz2+=rw*(ref*tangential+extra);phase_only_lz+=rw*tangential
        classical+=rw*(1+dmean)*tangential
        peak_transfer+=rw*(1+dmean)
    return populations/norm,lz2/norm,phase_only_lz,classical/peak_transfer

def sector_weights(pop):
    rows=[]
    for m in range(0,len(pop)):
        for parity in (0,1):
            ells=np.arange(m+parity,len(pop),2)
            rows.append((m,parity,(1 if m==0 else 2)*sum(pop[ells]/(2*ells+1))))
    return rows

def run():
    guard();heavy,cold,vol=[data(name) for name in ("late-heavy","late-cold","volume-state")]
    k=vol["k_Mpc_inverse"];power=vol["primordial_power"]
    screened=(heavy["both_scale_screens_pass"]==1)&(cold["both_scale_screens_pass"]==1)
    assert len(k)==399 and screened.sum()==99 and (np.diff(np.where(screened)[0])==1).all()
    for record in (heavy,cold):
        assert np.array_equal(k,record["k_Mpc_inverse"]) and np.array_equal(power,record["curvature_power"])
    mref=cold["test_mass_Mpc_inverse"];mkg=mref[0]/MP_C*hbar/c
    density=heavy["heavy_comoving_number_per_m3"][0]*mkg*MP_C**3/M_SUN
    kappa=hbar/mkg/(1000*parsec*1000)
    hp=heavy["heavy_spatial_phase"];cp=-cold["a"]*mref*cold["theta_cdm_N"]/k**2
    hc=(k,power,hp,vol["heavy_coordinate_number_contrast"],vol["heavy_physical_density"])
    cc=(k,power,cp,vol["cold_coordinate_number_contrast"],vol["cold_physical_density"])
    results=[];sectors=[];multipoles=[]
    for branch,mass in masses().items():
        radius=(3*mass/(4*np.pi*density))**(1/3)
        for band,pick in (("screen",screened),("finite",np.ones(len(k),bool))):
            for condition in (None,1):
                peak="unconditioned" if condition is None else "one_sigma"
                _,_,_,cold_action=spectrum(cc,condition,band=pick,R=radius,order=96,completion="phase")
                for completion in ("phase","linear_amplitude","log"):
                    last=None
                    for order in (96,192):
                        pop,lz2,phase2,_=spectrum(hc,condition,pick,radius,order,completion)
                        assert abs(sum(pop)-1)<1e-10 and min(pop)>-1e-10
                        residual=abs(np.arange(41)@(pop*(np.arange(41)+1))/3-lz2)
                        assert residual<1e-8
                        if last is not None:assert max(abs(pop-last))<1e-10
                        last=pop
                    weights=sector_weights(pop);assert abs(sum(row[2] for row in weights)-1)<1e-10
                    labels=dict(branch=branch,band=band,conditioning=peak,amplitude=completion)
                    for m,par,val in weights:
                        sectors.append(dict(**labels,abs_m=m,parity=("odd" if par else "even"),fraction=val))
                    for degree,value in enumerate(pop):
                        multipoles.append(dict(**labels,degree=degree,fraction=value))
                    by={(m,par):v for m,par,v in weights}
                    results.append(dict(**labels,R_comoving_Mpc=radius,density_Msun_Mpc3=density,kappa_kpc_km_s=kappa,
                                        zero_m_even=by[0,0],one_m_even=by[1,0],odd_reflection=sum(v for m,par,v in weights if par),
                                        excited_angular=1-pop[0],m_nonzero=1-by[0,0]-by[0,1],heavy_m2=lz2,
                                        heavy_flow_jz_rms=np.sqrt(phase2)*kappa,cold_mass_weighted_jz_rms=np.sqrt(cold_action)*kappa,
                                        spectral_moment_abs_error=residual))
    table("angular-summary",results);table("sector-populations",sectors);table("total-angular-degree",multipoles)

if __name__=="__main__":run()
