import csv
import io
import json
import os
import sys
from pathlib import Path

for key in ("OPENBLAS_NUM_THREADS","MKL_NUM_THREADS","OMP_NUM_THREADS","NUMEXPR_NUM_THREADS","BLIS_NUM_THREADS"):
    os.environ[key]="1"
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
LAST=ROOT/"mts-census-lopsided-wave-20261120"
FORM=ROOT/"mts-formation-state-bundle-20261110"
CENSUS=ROOT/"mts-foreground-occupation-cross-20261120"
sys.path.insert(0,str(CENSUS))
import stage_io as parent
from stage_io import np
from scipy.constants import c,hbar,parsec
BRANCHES=("anchorA","cut1","cut2")
MP_C=1e6*parsec
M_SUN=1.98847e30

def guard():
    parent.guard()
    assert not any((d/"STOP-REQUESTED").exists() for d in (HERE,FORM,LAST))
    assert parent.sha(LAST/"seal.json")=="81653dc3cc3eb839a1588fceeca114666f33cd6eddeaffdbef0c575a3ad28f2f"
    assert parent.sha(FORM/"closeout.json")=="18d0046bd803891009fc5256d583470c1fd16fa4f678389eca2b762c3f93e7d5"
    assert parent.sha(CENSUS/"seal.json")=="6bab4f61015a5b4f85a24e6b91b23639f1ca2225af0228086681fce63537fb2b"

def pinned(folder,name):
    guard();path=folder/name
    if folder==FORM:digest=json.loads((FORM/"closeout.json").read_bytes())["artifacts"][name]["sha256"]
    else:digest=json.loads((folder/"seal.json").read_bytes())["files"][name]
    assert parent.sha(path)==digest,name
    return path

def data(name,epoch=.01):
    with np.load(pinned(FORM,name+".npz")) as bank:raw=dict(zip(bank["columns"],bank["values"].T))
    return {key:values[raw["nominal_a"]==epoch] for key,values in raw.items()}

def put(name,raw):
    guard();path=HERE/name
    if path.exists():assert path.read_bytes()==raw,name
    else:
        with path.open("xb") as dest:dest.write(raw)

def table(name,rows):
    buf=io.StringIO(newline="");writer=csv.DictWriter(buf,rows[0],lineterminator="\n")
    writer.writeheader();writer.writerows(rows)
    put(name+".csv",buf.getvalue().encode())

def packet(name,**fields):
    buf=io.BytesIO();np.savez_compressed(buf,**fields);put(name+".npz",buf.getvalue())

def masses():
    pinned(CENSUS,"equilibria.csv")
    return {r["branch"]:float(r["mass_msun"]) for r in parent.read(CENSUS,"equilibria") if r["branch"] in BRANCHES}
