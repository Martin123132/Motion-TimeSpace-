from inputs_local import BRANCHES, CENSUS, HERE, data, guard, np, parent, pinned, table
from scipy.special import roots_legendre, spherical_jn

def evaluate(k, power, phase, contrast, selector, radius, count):
    nodes, weights = roots_legendre(count)
    radius_samples = radius * (1 + nodes) / 2
    volume_weights = weights * 1.5 * (radius_samples / radius)**2
    logk = np.log(k)
    def integrate(values):
        return np.trapezoid(power * values, x=logk, axis=-1)
    window = 3 * spherical_jn(1, k * radius) / (k * radius)
    selector = window * selector
    sigma = np.sqrt(integrate(selector**2))
    kr = np.outer(radius_samples, k)
    density = 1 + integrate(contrast * selector * spherical_jn(0, kr)) / sigma
    assert min(density) > 0
    angular = (1 + window**2) / 3 - 2 * window * spherical_jn(1, kr) / kr
    second = 2 * radius_samples**2 / 3 * integrate((k * phase)**2 * angular)
    return np.sqrt([volume_weights @ second, (volume_weights * density) @ second / (volume_weights @ density)])

def run():
    guard()
    heavy, cold, volume = [data(name) for name in ("late-heavy","late-cold","volume-state")]
    k = volume["k_Mpc_inverse"]
    keep = (heavy["both_scale_screens_pass"] == 1) & (cold["both_scale_screens_pass"] == 1)
    rows, overlaps = [], []
    for branch in BRANCHES:
        record, = [row for row in parent.read(HERE, "angular-summary") if
                   (row["branch"], row["band"], row["conditioning"], row["amplitude"]) ==
                   (branch, "screen", "one_sigma", "linear_amplitude")]
        radius, kappa = [float(record[key]) for key in ("R_comoving_Mpc", "kappa_kpc_km_s")]
        for family, phase in (("heavy", heavy["heavy_spatial_phase"]),
                              ("cold", -cold["a"] * cold["test_mass_Mpc_inverse"] * cold["theta_cdm_N"] / k**2)):
            args = [x[keep] for x in (k, volume["primordial_power"], phase,
                    volume[family + "_coordinate_number_contrast"], volume[family + "_physical_density"])]
            pair = kappa * evaluate(*args, radius, 64)
            np.testing.assert_allclose(pair, kappa * evaluate(*args, radius, 32), rtol=2e-12, atol=0)
            ref = float(record["heavy_flow_jz_rms" if family=="heavy" else "cold_mass_weighted_jz_rms"])
            np.testing.assert_allclose(pair[int(family=="cold")], ref, rtol=2e-12, atol=0)
            rows.append(dict(branch=branch,family=family,volume_jz_rms=pair[0],mass_jz_rms=pair[1]))
        with np.load(pinned(CENSUS, "state-" + branch + ".npz")) as ref:
            ground = ref["ground"] / np.linalg.norm(ref["ground"])
        with np.load(HERE / ("state-"+branch+"-screen-fine.npz")) as state:
            main = state["main"] / np.linalg.norm(state["main"])
        normal = main - (main @ ground) * ground
        need = [float(row["turnover"]) for row in parent.read(HERE,"coherent-rotation-"+branch) if float(row["R"])==6.]
        assert len(need)==6 and 0 <= normal @ normal < min(need)
        overlaps.append(dict(branch=branch,passive_squared_overlap_loss=normal@normal,
                             min_required=min(need),max_required=max(need)))
    table("matched-current", rows)
    table("principal-shape-test", overlaps)

if __name__=="__main__":run()
