from io_local import *
from collections import defaultdict

def run():
    guard()
    folder=ROOT/"mts-axisymmetric-density-shell-readout-20261120"
    pins=json.loads((folder/"inputs.json").read_bytes())
    for path,digest in pins.items():assert parent.sha(ROOT/path)==digest,path
    replay=ROOT/"mts-lmc-axisymmetric-retarded-replay-20261120"/"replay.json"
    assert parent.sha(replay)=="ac3e29395d6ceeeca6a4dfb52528cf429c000dcdd981ddd14650ed9e95840cbf"
    groups=defaultdict(list)
    for row in parent.read(folder,"signed-bands"):
        grp=(row["box"],row["ground"],row["history"],row["model"]);groups[grp].append(row)
    tests=[];results=[]
    for (box,ground,history,model),panel in groups.items():
        assert len(panel)==8
        inside=set();intervals={}
        for row in panel:
            R,z=float(row["R"]),float(row["z"]);component=row["component"]
            base,delta,lo,hi=map(float,[row["frozen"],row["induced"],row["low"],row["high"]])
            assert np.isclose(base+delta,float(row["total"]),atol=1e-13,rtol=0)
            if lo<=base+delta<=hi:inside.add((R,z,component))
            if model!="mts":assert delta==0;continue
            if R!=6 or z<=0:continue
            low,high=sorted(((lo-base)/delta,(hi-base)/delta))
            intervals[component]=(low,high)
            tests.append(dict(box=box,ground=ground,history=history,R=R,z=z,component=component,
                frozen=base,induced=delta,low_band=lo,high_band=hi,amplitude_low=low,amplitude_high=high))
        assert inside=={(8.3,-1.5,"polar"),(8.3,1.5,"polar")}
        if model=="mts":
            r,p=intervals["radial"],intervals["polar"]
            assert r[0]>0>p[1]
            results.append(dict(box=box,ground=ground,history=history,radial_min=r[0],polar_max=p[1],
                                interval_separation=r[0]-p[1],number_inside=len(inside),total=8))
    assert len(results)==24 and len(groups)==48
    table("original-LMC-required-amplitudes",tests);table("original-LMC-sign-test",results)
if __name__=="__main__":run()
