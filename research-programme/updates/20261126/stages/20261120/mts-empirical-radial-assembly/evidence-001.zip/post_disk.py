from io_local import *
from disk import Assembly,Evolution,off_plane,STREAMS,CONVERSION,CENSUS

def run(branch,variant,law,steps):
    guard();clock="reported" if variant.startswith("mw") else "parent"
    tag=f"{branch}-8-{variant}-{clock}-{law}-64"
    with np.load(HERE/f"state-{tag}.npz") as bank:radial=bank["fields"][-1]
    obj=Assembly(branch);bg=obj.bg
    field=np.zeros(bg.hshape,complex);field[:,0]=radial;field=field.ravel()
    ev=Evolution(obj,1/steps,field)
    norm=obj.number;oldE=obj.energy(field);eqE=obj.energy(obj.ground)
    ediff=oldE-eqE
    phi0=obj.phi(obj.moment(field))
    half0=bg.mesh.weight
    dt=1/steps;rows=[];streams=[];saved=[];worst_e=worst_n=0.
    marked={round(t*steps) for t in (0,.25,.5,1,2,3,4)}
    mat=obj.bare+obj.wave.mult(phi0)-obj.mu*obj.identity
    velocity=-1j*(mat@field)
    source_dot=2*np.real(obj.sky(field).conjugate()*obj.sky(velocity))@obj.wave.weights
    phi_dot=obj.phi(source_dot)
    acceleration=-1j*(mat@velocity+obj.multiply(phi_dot,field))
    second_now=2*(abs(obj.sky(velocity))**2+np.real(obj.sky(field).conjugate()*obj.sky(acceleration)))@obj.wave.weights
    dotf=obj.forces(source_dot);ddf=obj.forces(second_now)
    leakage=np.linalg.norm(velocity.reshape(bg.hshape)[:,1:])**2/norm
    expected=np.linalg.norm((obj.drive@field).reshape(bg.hshape)[:,1:])**2/norm
    assert abs(leakage-expected)<1e-13 and abs(dotf[1])<1e-9
    initial=field.copy()
    for iteration in range(4*steps+1):
        t=iteration*dt
        if iteration:
            field,moment,_=ev.advance(field,moment)
        else:moment=obj.moment(field)
        worst_n=max(worst_n,abs(np.vdot(field,field).real/norm-1))
        if iteration%(steps//16):continue
        guard()
        worst_e=max(worst_e,abs(obj.energy(field)-oldE)/ediff)
        assert worst_e<2e-5 and worst_n<1e-10
        shift=obj.forces(moment-obj.reference)
        excitation=np.linalg.norm(field.reshape(bg.hshape)[:,1:])**2/norm
        rows.append(dict(t=t,t_Myr=t*obj.unit_myr,angular_fraction=excitation,max_num=worst_n,max_energy_error=worst_e,
                         delta_vertical=(1.5*shift[0]-6*shift[1])/np.hypot(6,1.5),**dict(zip(parent.SITES,shift))))
        if iteration not in marked:continue
        saved.append(field.copy())
        for name,R,Z,q,qw,r0,z0,target,sw in STREAMS:
            fr,fz=off_plane(bg,moment-obj.reference,R,Z)*CONVERSION
            streams.append(dict(t=t,stream=name,dFR=fr,dFZ=fz,dstrength=q*q*fr+Z/R*fz))
    out=f"{branch}-{variant}-{law}-{steps}"
    table("post-fields-"+out,rows);table("post-stream-"+out,streams)
    packet("post-"+out,fields=np.stack(saved),initial_force_rate=dotf,initial_force_acceleration=ddf,initial_angular_t2=leakage)
    print(out,"vertical min/max",min(r["delta_vertical"] for r in rows),max(r["delta_vertical"] for r in rows),flush=True)
if __name__=="__main__":
    variant,law,steps,*branches=sys.argv[1:]
    for branch in branches:run(branch,variant,law,int(steps))
