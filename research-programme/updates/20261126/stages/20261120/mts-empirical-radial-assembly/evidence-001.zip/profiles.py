from io_local import guard,table,PDF,np
import fitz
from scipy.integrate import trapezoid
EPOCHS=(.015,.6,1.,1.5,2.,2.4)
def run():
    guard()
    with fitz.open(PDF) as doc:
        assert "1304.2391v2" in doc[0].get_text()
        paths=doc[3].get_drawings()
    def majors(ids,vertical):
        coords=[]
        for idx in ids:
            ticks=[w for w in paths[idx]["items"] if w[0]=="l" and 6<abs(w[1]-w[2])<7 and
                   (abs(w[1].x-w[2].x)<.01 if vertical else abs(w[1].y-w[2].y)<.01)]
            coords.append(ticks[-1][1].x if vertical else ticks[-1][1].y)
        return coords
    xx=majors([1,3,5,7,9,11],True)
    yy=[float(w[1].y) for w in paths[23]["items"] if w[0]=="l" and abs(w[1].y-w[2].y)<.01 and 6<abs(w[1]-w[2])<7]
    assert len(yy)==4
    mainx=np.polyfit([0,5,10,15,20,25],xx,1);mainy=np.polyfit([7,8,9,10],yy,1)
    logx=np.polyfit(np.log10([1,5,10]),majors([46,48,50],True),1)
    assert max(abs(np.polyval(mainx,[0,5,10,15,20,25])-xx))<.17
    def curve(ids,log,errors):
        segs=[x for idx in ids for x in paths[idx]["items"]]
        assert all(x[0]=="l" for x in segs)
        points=[segs[0][1]]
        for _,first,last in segs:
            assert abs(first-points[-1])<.02
            assert last.x>=first.x-1e-4
            points.append(last)
        xgroups={}
        for point in points:xgroups.setdefault(point.x,[]).append(point.y)
        points=[fitz.Point(x,float(np.mean(group))) for x,group in xgroups.items()]
        coords=logx if log else mainx
        rad=np.array([(p.x-coords[1])/coords[0] for p in points])
        rad=10**rad if log else np.maximum(rad,0)
        vals=np.array([(p.y-mainy[1])/mainy[0] for p in points])
        allbars=[seg for idx in errors for seg in paths[idx]["items"] if seg[0]=="l" and abs(seg[1].x-seg[2].x)<.04 and abs(seg[1].y-seg[2].y)>.01]
        result=[]
        for point,value in zip(points,vals):
            near=[(p.y-mainy[1])/mainy[0] for _,a,b in allbars if abs(a.x-point.x)<.07 for p in (a,b)]
            result.append((min(near) if near else "",max(near) if near else ""))
        return rad,vals,result
    left=([29],[32],[35],[38],[40,41],[43])
    bars=([30,31],[33,34],[36,37],[39],[42],[44,45])
    right=([67],[70],[72,73],[75],[78],[80])
    rows=[];checks=[];central=[]
    for idx,z in enumerate(EPOCHS):
        a,v,err=curve(left[idx],False,bars[idx]);b,u,_=curve(right[idx],True,[])
        assert np.all(np.diff(a)>0) and np.all(np.diff(b)>0)
        good=(b>1.)&(b<a[-1]-.1)
        diff=abs(u-np.interp(b,a,v));cross=np.max(diff[good])
        nearest=np.min(abs(b[:,None]-a),axis=1)
        same=good&(nearest<.10)&(b<a[-2]-.1)
        assert same.sum()>=10 and max(diff[same])<.04,(z,max(diff[same]))
        for radius,density,limits in zip(a,v,err):
            rows.append(dict(z=z,R_kpc=radius,log10_Msun_kpc2=density,bar_low=limits[0],bar_high=limits[1]))
        def mass(r):
            grid=np.linspace(0,min(r,a[-1]),8193)
            return 2*np.pi*trapezoid(grid*10**np.interp(grid,a,v),grid)
        central.append(mass(2))
        checks.append(dict(z=z,R_max=a[-1],points=len(a),panel_cross_max_dex=cross,
                           same_knot_max_dex=max(diff[same]),same_knot_count=int(same.sum()),full_panel_gate=cross<.04,mass_within_2=mass(2),
                           mass_within_support_or_25=mass(25),paper_mass_25=10**(10.7-.045*z-.13*z*z),
                           aperture_complete=a[-1]>=25,bars=sum(row[0]!="" for row in err)))
    ratio=central[2]/central[-1]
    assert 2.4<ratio<4.1,ratio
    table("profiles",rows);table("digitization-checks",checks)
    print("points",len(rows),"central growth",ratio,flush=True)
if __name__=="__main__":run()
