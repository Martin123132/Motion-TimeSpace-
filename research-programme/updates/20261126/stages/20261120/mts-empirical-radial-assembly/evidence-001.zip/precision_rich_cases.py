from assembly_readouts import *

def run():
    rows=[];streamrows=[]
    sites=[r for r in parent.read(CENSUS,"census-limited-forces") if r["foreground"]=="anchorA"]
    obs=[r for r in parent.read(CENSUS,"stream-observables") if r["branch"]=="anchorA" and r["model"]=="MTS"]
    for law in ("all25","all75"):
        tag=f"anchorA-primary-{law}"
        coarse,mid,fine=[read(f"post-fields-{tag}-{steps}") for steps in (32,64,128)]
        for left,center,right in zip(coarse,mid,fine):
            assert left["t"]==center["t"]==right["t"]
            previous=[];current=[];ratios=[];margin=[];flips=0
            for site in sites:
                radius=float(site["R"]);height=float(site["z"]);component=site["component"]
                key=("inner_" if radius==6 else "outer_")+component
                sign=(-1 if height<0 and component=="polar" else 1)*int(site["model"]=="MTS")
                base=sum(float(site[k]) for k in ("ordinary","dark","direct_LMC"))
                lo,hi=float(site["low"]),float(site["high"])
                old,medium,final=[base+sign*float(state[key]) for state in (left,center,right)]
                previous.append(abs(medium-old)>2e-5*abs(medium));current.append(abs(final-medium)>2e-5*abs(final))
                flips+=int((lo<=medium<=hi)!=(lo<=final<=hi))
                boundary=min(abs(final-lo),abs(final-hi))
                margin.append(boundary);ratios.append(abs(final-medium)/boundary)
            rows.append(dict(law=law,t=right["t"],n=len(sites),failed_32_64=sum(previous),failed_64_128=sum(current),flips_64_128=flips,
                             closest_band_edge=min(margin),max_step_change_over_band_distance=max(ratios)))
        st0,st1=[read(f"post-stream-{tag}-{steps}") for steps in (64,128)]
        for mid,r in zip(st0,st1):
            assert (mid["stream"],mid["t"])==(r["stream"],r["t"])
            ref,=[v for v in obs if v["stream"]==r["stream"]]
            sw=float(ref["strength_width"])
            coarse_strength,fine_strength=[(float(ref["strength"])+float(z["dstrength"])-float(ref["strength_reference"]))/sw for z in (mid,r)]
            streamrows.append(dict(law=law,t=r["t"],stream=r["stream"],widths64=coarse_strength,widths128=fine_strength,
                              difference_in_widths=fine_strength-coarse_strength,classification_change=(abs(coarse_strength)<=1)!=(abs(fine_strength)<=1)))
    table("rich-case-precision",rows);table("rich-case-stream-precision",streamrows)
if __name__=="__main__":run()
