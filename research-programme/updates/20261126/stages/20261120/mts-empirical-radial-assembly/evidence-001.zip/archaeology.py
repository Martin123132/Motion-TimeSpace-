from io_local import *
from scipy.interpolate import PchipInterpolator
from signed_potential import G
import fitz
import re

def run():
    guard();paper=HERE/"Ratcliffe-2509.02691.pdf"
    assert parent.sha(paper)=="55c996c094cec6ce6052d44390f8df4026b2b6753bce2d8f8313cd3f0c0d700f"
    with fitz.open(paper) as doc:
        text=doc[13].get_text().split("Notes.")[0]
        assert "Table A.1." in text
    tokens=re.findall(r"(?m)^(-?\d+(?:\.\d+)?)\s*$",text)
    data=np.array(tokens[-70:],float).reshape(10,7)
    assert np.array_equal(data[:,0],[.05,.25,.5,.75,1.,1.5,2.,2.5,3.,4.])
    assert np.all(np.diff(data[:,1])>0) and np.all(np.diff(data[:,2])<0)
    rows=[dict(z=z,lookback_Gyr=lb,relative_Myr=(data[-1,1]-lb)*1000,stellar_mass_Msun=m*1e10,
               R_present_kpc=r,R_birth_kpc=b,SFR_msun_yr=s,grad_dex_per_kpc=grad) for z,lb,m,r,b,s,grad in data]
    table("MW-table",rows)
    for order in (4,8):
        with np.load(HERE/f"stellar-{order}-primary.npz") as bank:
            r=bank["rad"];base=bank["potential"][0];mass=bank["total"][0];enc=bank["mass_shell"][0]
        assert np.max(abs(base[r>90]/(-G*mass/r[r>90])-1))<1e-13
        phi=PchipInterpolator(r,base,extrapolate=False);massfn=PchipInterpolator(r,enc,extrapolate=False)
        for mode in ("birth","present"):
            col=4 if mode=="birth" else 3
            values=[];inside=[]
            for row in data:
                size=row[col]/data[0,col];weight=row[2]/data[0,2]
                at=r/size;tail=at>r[-1]
                v=phi(np.minimum(at,r[-1]));v[tail]=-G*mass/at[tail]
                values.append((weight/size)*v)
                shell=massfn(np.minimum(at,r[-1]));shell[tail]=mass;inside.append(weight*shell)
            assert np.max(abs(values[0]-base))<1e-9
            packet(f"stellar-{order}-mw{mode}",rad=r,potential=np.array(values),mass_shell=np.array(inside),total=mass*data[:,2]/data[0,2])
if __name__=="__main__":run()
