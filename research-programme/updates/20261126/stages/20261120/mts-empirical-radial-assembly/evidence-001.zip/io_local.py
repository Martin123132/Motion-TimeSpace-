import csv
import hashlib
import io
import json
import os
import sys
from pathlib import Path

for key in ("OPENBLAS_NUM_THREADS","MKL_NUM_THREADS","OMP_NUM_THREADS","NUMEXPR_NUM_THREADS","BLIS_NUM_THREADS"):
    os.environ[key]="1"
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
LAST=ROOT/"mts-fixed-number-disk-assembly-20261120"
sys.path.insert(0,str(LAST))
from disk import parent,np
PDF=HERE/"vanDokkum-1304.2391v2.pdf"
PIN="dacd8618f9075853c3b12b2c3e825e0fd8b92bc8d5988583203a9984ad0ec00e"
def guard():
    from disk import guard as previous
    previous()
    assert not (HERE/"STOP-REQUESTED").exists()
    assert parent.sha(LAST/"seal.json")==PIN and parent.sha(PDF)=="b81a8044774dc5c1fa76df59a69a58829188d878c3f894869943e5345f9f6443"
def put(name,data):
    guard()
    path=HERE/name
    if path.exists():assert path.read_bytes()==data,name
    else:
        with path.open("xb") as out:out.write(data)
def table(name,rows):
    buf=io.StringIO(newline="");w=csv.DictWriter(buf,rows[0],lineterminator="\n")
    w.writeheader();w.writerows(rows)
    put(name+".csv",buf.getvalue().encode())
def packet(name,**fields):
    buf=io.BytesIO();np.savez_compressed(buf,**fields);put(name+".npz",buf.getvalue())
def read(name):return parent.read(HERE,name)
