from io_local import *
from profiles import EPOCHS
from disk import Assembly
from signed_potential import census,columns,supply,ls
from scipy.integrate import quad
from scipy.integrate import solve_ivp
from scipy.interpolate import CubicSpline

def clocks():
    aperture=read("apertures");z=np.array([float(r["z_mean"]) for r in aperture])
    folder=ROOT/"cosmology-lab-handoff-20261020"
    ref=json.loads((folder/"reference-cases.json").read_bytes());case=ref["cases"][1]
    assert case["model"]=="ParentScalar_Lambda_zero" and ref["all_checks_pass"]
    sys.path.insert(0,str(folder))
    import generate_reference as gr
    for path in (gr.OWNER,Path(gr.__file__)):
        assert parent.sha(path)==ref["source_hashes"][str(path)]
    pars=case["parameters"]
    sol=gr.parent.integrate_scalar_backward(case["derived"]["theta"],pars["Omega_m"],case["derived"]["mu"],1.,-5.,True,"final")
    def E(a):return float(np.exp(sol.sol(np.log(a))[2]))
    for pt in case["predictions"]:assert abs(E(1/(1+pt["z"]))/pt["E"]-1)<1e-8
    out=[]
    for idx,red in enumerate(z):
        p={}
        for clock,fn in (("parent",E),("flat",lambda a:np.sqrt(pars["Omega_m"]/a**3+pars["Omega_r"]/a**4+1-pars["Omega_m"]-pars["Omega_r"]))):
            p[clock+"_Myr"]=977792.2216807892/pars["H0_km_s_Mpc"]*quad(lambda a:1/(a*fn(a)),1/(1+z[-1]),1/(1+red),epsabs=1e-12)[0]
        out.append(dict(z=red,**p))
    table("clocks",out)

def ratios(rr,variant):
    ap=read("apertures");gr=read("profiles");profiles=[]
    for i,z in enumerate(EPOCHS):
        rows=[r for r in gr if float(r["z"])==z]
        R=np.array([float(r["R_kpc"]) for r in rows])
        val=np.array([float(r["log10_Msun_kpc2"]) for r in rows])
        fac=float(ap[i]["fig4_over_circular_fig3"])
        profiles.append((R,val+np.log10(fac)))
    out=[np.ones_like(rr)]
    for early,late in zip(profiles[1:],profiles[:-1]):
        R,v=early;R0,v0=late
        edge=min(R[-2],R0[-2])
        width=2. if variant=="narrow" else 1.
        taper=np.clip((edge-rr)/width,0,1)
        if variant=="common":
            edge=min(edge,profiles[-1][0][-2]);taper=np.clip((edge-rr)/width,0,1)
        logratio=np.interp(rr,R,v)-np.interp(rr,R0,v0)
        out.append(out[-1]*10**(taper*logratio))
    return np.array(out)

def ordinary_shells(order,variant):
    guard();c=census();obj=Assembly("anchorA");bg=obj.bg
    wave_r=bg.rad*bg.length
    gr=read("profiles")
    edges=np.unique(np.r_[0.,c.radknots,c.stars.centres,c.stars.bgrid,np.arange(0,31,.5),[float(r["R_kpc"]) for r in gr]])
    rr,wr=ls.quad(edges[(edges>=0)&(edges<=30)],order)
    alt,wz=ls.quad(np.unique(np.r_[0.,c.stars.axis,.01,.03,.06,.1,.2,.4,.8,1.5,3.,4.,5.,6.,8.,12.,16.,24.,40.,60.,80.]),order)
    angle,wa=ls.quad([0.,np.pi/2],24 if order==4 else 36)
    angular_w=wa*2/np.pi
    ratio=ratios(rr,variant)
    tables=[];mass_bins=[];pot=np.zeros((6,len(wave_r)));mass=np.zeros(6);cumulative=np.zeros_like(pot);integrated_e3=0.
    vertical=np.stack([c.starshape(alt,j) for j in range(4)])
    barz=np.stack([ls.zshape(k,alt) for k in ls.S22])
    for start in range(0,len(rr),12):
        sl=slice(start,start+12);cyl=rr[sl]
        initial=supply(cyl);bar=columns(cyl)
        donor=initial*(1-bar.sum(axis=1)/initial.sum(axis=1))[:,None]
        assert np.min(donor)>-1e-5
        stars=donor@vertical+bar@barz
        center=np.zeros_like(stars)
        select=(cyl[:,None]<28)&(alt[None,:]<12)
        rgrid,zgrid=np.broadcast_arrays(cyl[:,None],alt[None,:])
        rmask=rgrid[select,None];zmask=zgrid[select,None]
        center[select]=c.stars.bmass*(ls.old.density("E3",(.67,.29,.27),rmask*np.cos(angle),rmask*np.sin(angle),zmask)@angular_w)
        geom=4*np.pi*(cyl*wr[sl])[:,None]*wz
        integrated_e3+=np.sum(geom*center)
        dm=geom*(stars+center)
        radii=np.hypot(rgrid,zgrid).ravel();sorting=np.argsort(radii);sorted_r=radii[sorting]
        ids=np.searchsorted(sorted_r,wave_r,side="right")
        for e in range(6):
            weights=(dm*ratio[e,sl,None]).ravel()[sorting]
            running=np.r_[0.,np.cumsum(weights)]
            outside=np.r_[np.cumsum((weights/sorted_r)[::-1])[::-1],0.]
            pot[e]-=ls.G*(running[ids]/wave_r+outside[ids])
            cumulative[e]+=running[ids];mass[e]+=running[-1]
    assert abs(integrated_e3/c.stars.bmass-1)<3e-5
    assert np.isfinite(pot).all() and np.max(np.diff(cumulative,axis=1)*-1)<1e-5
    suffix=f"{order}-{variant}"
    packet("stellar-"+suffix,rad=wave_r,potential=pot,mass_shell=cumulative,total=mass,central_component_final=integrated_e3)
    for i,z in enumerate(EPOCHS):
        tables.append(dict(z=z,stellar_mass=mass[i],mass_2=np.interp(2.,wave_r,cumulative[i]),mass_6=np.interp(6.,wave_r,cumulative[i]),
                  mass_8=np.interp(8.3,wave_r,cumulative[i]),mass_18=np.interp(17.58,wave_r,cumulative[i]),
                  phi6_kms2=np.interp(6.,wave_r,pot[i]),phi18_kms2=np.interp(17.58,wave_r,pot[i])))
    table("source-"+suffix,tables);print(suffix,mass[[0,-1]],flush=True)
if __name__=="__main__":
    clocks()
    for arg in sys.argv[1:]:
        order,variant=arg.split("-");ordinary_shells(int(order),variant)
