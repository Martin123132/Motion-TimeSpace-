from io_local import np,read,table,PDF,guard
import fitz

def run():
    guard()
    with fitz.open(PDF) as doc:paths=doc[4].get_drawings()
    xt=[w[1].x for w in paths[10]["items"] if w[0]=="l" and abs(w[1].x-w[2].x)<.01 and 5.5<abs(w[1]-w[2])<6]
    yt=[w[1].y for w in paths[16]["items"] if w[0]=="l" and abs(w[1].y-w[2].y)<.01 and 5.5<abs(w[1]-w[2])<6]
    assert len(xt)==4 and len(yt)==3
    scale,offset=np.polyfit(np.log10([.5,1,5])+10,yt,1)
    sx,bx=np.polyfit(np.arange(4),xt,1)
    def track(idx):
        seg=paths[idx]["items"]
        pts=[seg[0][1]]+[w[2] for w in seg]
        assert len(pts)==6
        return np.array([[(p.x-bx)/sx,10**((p.y-offset)/scale)] for p in pts])
    inside=track(25);outside=track(27)
    assert np.array_equal(inside[:,0],outside[:,0])
    out=[]
    for idx,row in enumerate(read("digitization-checks")):
        z,inner=inside[idx];outer=outside[idx,1]
        assert abs(z-float(row["z"]))<.05
        residual=(inner+outer)/10**(10.7-.045*z-.13*z*z)-1
        assert abs(residual)<.025,(z,residual)
        out.append(dict(z_mean=z,z_label=row["z"],mass_2_projected=inner,mass_outside_2=outer,
                        relative_mass_check=residual,fig4_over_circular_fig3=inner/float(row["mass_within_2"])))
    table("apertures",out)
if __name__=="__main__":run()
