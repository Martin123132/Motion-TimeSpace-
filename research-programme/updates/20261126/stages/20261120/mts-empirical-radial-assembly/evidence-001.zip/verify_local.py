from collections import Counter
from io_local import *
from assembly_readouts import CASES,BRANCHES,CENSUS

def run():
    guard()
    upstream={}
    for folder in (LAST,CENSUS):
        files=json.loads((folder/"seal.json").read_bytes())["files"]
        assert all(parent.sha(folder/k)==v for k,v in files.items())
        upstream[folder.name]=len(files)
    assert parent.sha(HERE/"Ratcliffe-2509.02691.pdf")=="55c996c094cec6ce6052d44390f8df4026b2b6753bce2d8f8313cd3f0c0d700f"
    certs=read("radial-certificates");counts=read("panel-counts");refined=read("post-resolution")
    assert len(certs)==len(list(HERE.glob("state-*.npz")))==len(list(HERE.glob("evolution-*.csv")))==84
    assert len(read("profiles"))==276 and len(read("MW-table"))==10 and len(read("clocks"))==6
    for row in certs:
        hist=read("evolution-"+row["run"])
        residual=float(row["residual_kms2"]);assert residual>=-1e-7
        early,late=hist[0],hist[-1]
        closure=float(late["equilibrium_energy_kms2"])-float(early["equilibrium_energy_kms2"])+residual-float(late["work_kms2"])
        assert abs(closure)<=.0003 and float(row["norm_error"])<1e-9
        assert abs(float(late["shell_work_cross_kms2"])-float(late["extra_radial_field_work_kms2"]))<1e-7
        assert abs(float(early["relative_to_final_sphere_kms2"])+float(late["extra_radial_field_work_kms2"])-residual)<.0003
    assert len(read("original-LMC-sign-test"))==24
    assert len(refined)==18 and len(counts)==216 and len(read("stream-checks"))==504
    assert len(read("site-envelopes"))==1728
    for branch in BRANCHES:
        norm=float(parent.read(LAST,"stationary-"+branch)[0]["number"])
        for variant,law in CASES:
            clock="reported" if variant.startswith("mw") else "parent"
            with np.load(HERE/f"state-{branch}-8-{variant}-{clock}-{law}-64.npz") as pk:field=pk["fields"][-1]
            for steps in (32,64):
                tag=f"{branch}-{variant}-{law}-{steps}"
                with np.load(HERE/f"post-{tag}.npz") as pk:
                    states=pk["fields"].reshape(7,len(field),-1)
                    assert np.array_equal(states[0,:,0],field) and not np.any(states[0,:,1:])
                    assert max(abs(np.sum(abs(states)**2,axis=(1,2))/norm-1))<1e-10
                    assert np.isfinite(pk["initial_force_acceleration"]).all() and pk["initial_angular_t2"]>0
                post=read("post-fields-"+tag)
                assert max(float(r["max_energy_error"]) for r in post)<2e-5
    envelopes=read("site-envelopes")
    for row in envelopes:
        lower,upper=float(row["minimum"]),float(row["maximum"])
        lo,hi=float(row["low"]),float(row["high"]);n=int(row["inside"])
        assert 0<=n<=65 and lower<=upper
        if lower>=lo and upper<=hi:assert n==65
        if upper<lo or lower>hi:assert n==0
        if row["model"]=="static_NFW":assert lower==upper
    for row in counts:
        series=list(map(int,row["counts_by_time"].split()))
        assert len(series)==65 and min(series)==int(row["minimum"]) and max(series)==int(row["maximum"])
    stats=dict(upstream_files=upstream,radial_runs=len(certs),two_dimensional_runs=len(refined)*2,saved_foregrounds=len(BRANCHES),
        certificate_unavailable=[r["run"] for r in certs if r["monotone_exclusion"]=="False"],
        band_decisions_fine=sum(int(r["total_tested"]) for r in refined),totals_outside_step_tolerance=sum(int(r["total_failed"]) for r in refined),
        band_flips=sum(int(r["classification_changes"]) for r in refined),small_terms_outside_step_tolerance=sum(int(r["small_failed"]) for r in refined),
        small_terms_tested=sum(int(r["small_tested"]) for r in refined),max_radial_work_error_kms2=max(float(r["source_identity_error_kms2"]) for r in certs),
        max_radial_number_error=max(float(r["norm_error"]) for r in certs))
    rich=read("rich-case-precision");rich_streams=read("rich-case-stream-precision")
    assert len(rich)==130 and len(rich_streams)==28
    assert all(r["classification_change"]=="False" for r in rich_streams)
    stats.update(two_dimensional_runs=len(refined)*2+2,extra_128_step_comparisons=sum(int(r["n"]) for r in rich),
                 extra_128_step_band_flips=sum(int(r["flips_64_128"]) for r in rich),
                 extra_128_outside_tolerance=sum(int(r["failed_64_128"]) for r in rich))
    refs={}
    for path in [ROOT/"cosmology-lab-handoff-20261020"/"reference-cases.json",ROOT/"cosmology-lab-handoff-20261020"/"generate_reference.py",
                 *(ROOT/"mts-axisymmetric-density-shell-readout-20261120"/n for n in ("inputs.json","signed-bands.csv","conservation.csv","density-shell-forces.csv","force-shares.csv")),
                 ROOT/"mts-lmc-axisymmetric-retarded-replay-20261120"/"replay.json",LAST/"seal.json",CENSUS/"seal.json"]:
        refs[str(path.relative_to(ROOT)).replace(chr(92),"/")]=parent.sha(path)
    stats["source_references"]=refs
    put("validation.json",(json.dumps(stats,indent=2,sort_keys=True)+"\n").encode())
    assert not any(p.is_dir() for p in HERE.iterdir())
    files={p.name:parent.sha(p) for p in sorted(HERE.iterdir()) if p.is_file() and p.name!="seal.json"}
    put("seal.json",(json.dumps(dict(files=files),indent=2,sort_keys=True)+"\n").encode())
    print("verified",len(files),parent.sha(HERE/"seal.json"));print(json.dumps({k:v for k,v in stats.items() if k!="source_references"}))
if __name__=="__main__":run()
