from run_slices import *
from clock_lift import ClockLift

def difference(on,off):
    fields=("n","p","clock","chi","e_other","e_star","j_other","stress","psi","weyl","phi")
    return {**on,**{key:on[key]-off[key] for key in fields}}
def main(model,rate):
    sim=BalancedNative(model,120,120*rate,False,"native36",SPAN*DLOG)
    grid=Element(sim.mesh,120,10 if rate==4 else 12)
    bg={i:native(model,i) for i in (0,1)}
    bg[2]=difference(bg[0],bg[1])
    samples={i:(shape(b,grid.points),shape(b,np.asarray(120.))) for i,b in bg.items()}
    parent=native("heavy",0)
    amp=(2/15)*np.dot(parent["w"],parent["clock"]*parent["k"]**2)
    rows=[]
    for seed in (1,-1,0):
        state=stage_field(sim,model,seed if seed else 1,rate)
        if not seed:state=tuple(np.zeros_like(x) for x in state)
        for use_clock in (False,True):
            for env in (("fixed","volume") if use_clock else ("fixed",)):
                for flag,tag,canon in ((0,"on",model=="heavy"),(1,"off",False),(1,"off_same_lift",model=="heavy"),(2,"direct",model=="heavy")):
                    clock=ClockLift(grid,bg[flag],state,flag,env) if use_clock else None
                    for tensor in ((0,1) if tag in ("on","off_same_lift") and not use_clock else (0,)):
                        study=Slice(sim,grid,bg[flag],samples[flag],state,flag,canon,env,tensor*amp,"matched",clock)
                        for r in PROBES:
                            val=study.tidal(r)
                            phi0=grid.probe(r)[2](clock.vals[0])[0] if clock is not None else 0.
                            rows.append(dict(model=model,rate=rate,seed=seed,clock=int(use_clock),env=env,
                                branch=tag,TT=tensor,radius=r,slice_clock0=phi0,
                                **{key:val[key] for key in ("tide","weyl","cross","stress","scalar3","extrinsic","chi0","Brr0","Brr2")}))
    savecsv(f"{model}-h{rate}-differential.csv",rows);print(model,rate,len(rows),flush=True)
if __name__=="__main__":main(sys.argv[1],int(sys.argv[2]))
