"""Fast phase integral as an independent stress-tensor and fixed-action check."""
from run_slices import *
def primary():
    sim=BalancedNative("heavy",120,600,False,"native36",SPAN*DLOG);grid=Element(sim.mesh,120,12)
    bg=native("heavy",0)
    samples=shape(bg,grid.points),shape(bg,np.asarray(120.))
    alpha=bg["a"]*sim.patch.p.mass
    phases=2*np.pi*np.arange(16)/16
    co=np.cos(phases);si=np.sin(phases)
    rows=[]
    for seed in (1,-1):
        state=stage_field(sim,"heavy",seed,5)
        sol=Slice(sim,grid,bg,samples,state,0,True,"fixed",0.,"matched")
        for r in PROBES[:5]:
            _,__,read=grid.probe(r)
            ref=shape(bg,np.asarray(r));m=material(ref,r,lambda v:read(v)[:2],sol.state,0);j=sim.patch.j
            mono,dr,ddr=read(sol.f0);quad,qdr,qddr=read(sol.f2)
            for tide in (-1.,0.,1.):
                cosine=.5;leg=(3*cosine**2-1)/2;dleg=-3*cosine*np.sqrt(1-cosine**2)
                u=1+mono+tide*leg*quad
                phi_grad=np.array([dr+tide*leg*qdr,tide*dleg*quad/r,0.])
                n=m["n"][j]+tide*leg*m["D"][j]
                grad=np.array([m["g"][j]+tide*leg*m["Dr"][j],tide*dleg*m["D"][j]/r,0.])/n-6*phi_grad/u
                p=np.array([m["p"][j]+tide*leg*m["P"][j],tide*dleg*m["Pt"][j],0.])
                v2=p@p/u**4
                for nu,zeta,key in ((1.,0.,"retained"),(np.sqrt(1+v2),0.,"plane_frequency"),
                        (1.,-1.5*bg["H"]/alpha,"homogeneous_drift"),(.99,.02,"algebra_only")):
                    amplitude=np.sqrt(2*n/(u**6*nu))
                    field=amplitude*co;normal=amplitude*(nu*si+zeta*co)
                    spatial=amplitude*(grad[:,None]*co/(2*alpha)-p[:,None]*si)/u**2
                    energy=.5*np.mean(normal**2+field**2+np.sum(spatial**2,axis=0))
                    current=-u**8*np.mean(normal*spatial,axis=1)
                    stress=spatial@spatial.T/len(co)
                    rest_excess=((nu-1)**2+zeta**2)/(2*nu)
                    expected=n/u**6*(1+rest_excess+(v2+grad@grad/(4*alpha**2*u**4))/(2*nu))
                    j_exp=n*(p-zeta*grad/(2*alpha*nu));s_exp=n*(np.outer(p,p)+np.outer(grad,grad)/(4*alpha**2))/(u**10*nu)
                    energy_err=abs(energy/expected-1)
                    current_err=np.max(abs(current-j_exp))/max(np.abs(j_exp).max(),1e-25)
                    stress_err=np.max(abs(stress-s_exp))/max(np.abs(s_exp).max(),1e-35)
                    assert max(energy_err,current_err,stress_err)<1e-9
                    rows.append(dict(seed=seed,radius=r,tidal_amplitude=tide,quadrature=key,nu=nu,zeta=zeta,
                        phase_energy=v2/2,amplitude_energy=grad@grad/(8*alpha**2*u**4),
                        rest_fractional_excess=rest_excess,current_change_norm=np.linalg.norm(j_exp-n*p),
                        energy_identity=energy_err,current_identity=current_err,stress_identity=stress_err))
    savecsv("real-field-quadratures.csv",rows)
if __name__=="__main__":primary()
