from pathlib import Path
import os,sys,csv,json,hashlib,io
for name in ("OMP_NUM_THREADS","OMP_THREAD_LIMIT","OPENBLAS_NUM_THREADS","MKL_NUM_THREADS","BLIS_NUM_THREADS","NUMEXPR_NUM_THREADS"):os.environ[name]="1"
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
GR=ROOT/"mts-common-metric-formation-tide-20261120"
PIN="2215631e8667963a2e038e1ac53ec9d81fedcdd1b1d3031bc694de10f40db9f1"
def digest(path):
    with path.open("rb") as stream:return hashlib.file_digest(stream,"sha256").hexdigest()
assert digest(GR/"seal.json")==PIN
prior=json.loads((GR/"seal.json").read_bytes())["files"]
def verified(name):
    path=GR/name
    assert digest(path)==prior[name],name
    return path
for name in ("anchor.py","linear.py","cloud_stress.py"):verified(name)
sys.path.insert(0,str(GR))
from anchor import saved,guard as parent_guard,AI,DLOG,SPAN,np
from balanced import BalancedNative
from scipy.special import spherical_jn
def guard():
    parent_guard()
    assert not (HERE/"STOP-REQUESTED").exists()
def write(name,data):
    guard();destination=HERE/name
    if destination.exists():assert destination.read_bytes()==data,name
    else:
        temp=destination.with_suffix(destination.suffix+".partial")
        with temp.open("xb") as stream:stream.write(data)
        temp.rename(destination)
def savecsv(name,rows):
    out=io.StringIO(newline="");writer=csv.DictWriter(out,fieldnames=list(rows[0]),lineterminator="\n")
    writer.writeheader();writer.writerows(rows);write(name,out.getvalue().encode())
def native(model,flag):
    with np.load(verified(model+"-all.npz")) as base:
        weights=base["shear"];coeff=base["coeff"]
    with np.load(verified(f"serial-{model}-b6-off{flag}.npz")) as pack:
        k=pack["k"];field=dict(zip(pack["names"].tolist(),pack["values"][:,-1,:].T))
    a=field["a"];H=field["H"];R=field["R"];S=R+field["P"];eta=field["eta"];sig=field["sigma"]
    ds=field["D"]-3*S*eta
    q=field["Q"]+S*sig
    clock=1.5*q/k/(k**2+1.5*S)
    cmphi=-ds/(2*k**2+3*S)
    phi=eta-H*sig/k;psi=(field["dsigma"]+H*sig)/k
    assert np.max(abs(cmphi-phi-H*clock))<2e-16
    rh=coeff[:,None]/a
    density=np.stack([field["dc"],field["db"]]+([field["mts_drho_h"]/rh[-1]] if model=="heavy" else []))-3*eta
    vel=-np.stack([sig,sig+field["vb"]]+([sig+field["mts_q_h"]/rh[-1]] if model=="heavy" else []))/k+clock
    e_star=ds-np.sum(rh*density,axis=0)
    e_other=e_star+3*(S-rh.sum(axis=0))*cmphi
    j_other=-q/k+S*clock-np.sum(rh*vel,axis=0)
    alpha=AI*np.exp(SPAN*DLOG)
    assert np.max(abs(a/alpha-1))<1e-9
    return dict(k=k,w=weights,rh=coeff/alpha,a=alpha,H=float(np.mean(H)),R=float(np.mean(R)),
            so=float(np.mean(S-rh.sum(axis=0))),n=density,p=vel,clock=clock,chi=-cmphi/2,
            e_other=e_other,e_star=e_star,j_other=j_other,stress=field["Pi"]/k**2,
            psi=psi,weyl=field["W"],phi=phi)
def response(source,r,order=0):
    k=source["k"];z=np.outer(k,np.ravel(r));v=spherical_jn(2,z)
    if order:
        vr=k[:,None]*spherical_jn(2,z,derivative=True)
        if order==1:v=vr
        else:
            rad=np.ravel(r)[None,:]
            with np.errstate(invalid="ignore",divide="ignore"):
                v=(6/rad**2-k[:,None]**2)*v-2*vr/rad
            v[:,rad[0]==0]=(2*k**2/15)[:,None]
    return lambda key:((source[key]*source["w"])@v).reshape((*source[key].shape[:-1],*np.shape(r)))
def stage_field(sim,model,seed,rate):
    path=saved(f"evolved-{model}-L120-h{rate}-t176.npz" if seed==1 else f"collar-{model}-L120-h{rate}--1.npz")
    with np.load(path) as archive:
        assert archive["x"][-1]==SPAN*DLOG
        return tuple(archive[key] for key in ("mono","density","velocity"))
