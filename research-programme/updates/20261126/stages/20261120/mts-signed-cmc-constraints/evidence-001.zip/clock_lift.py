from constraint import *
from scipy.special import spherical_kn
from scipy.sparse.linalg import splu
class ClockLift:
    def __init__(self,grid,bg,state,flag,environment="fixed"):
        self.bg=bg;self.environment=environment
        So=bg["so"];S=So+sum(bg["rh"])
        mu=np.sqrt(1.5*S)
        mono,den,vel=state
        def pad(x):return np.concatenate((np.zeros_like(x[...,:1]),x),axis=-1)
        _,phase=grid.evaluate(pad(mono))[0]
        m0=phase/grid.points
        edge=mono[1,:,grid.size-2]/grid.edge
        mono_v=np.einsum("s,seq->eq",bg["rh"],m0-edge[:,None,None])
        quad_v=np.einsum("s,seq->eq",bg["rh"],grid.evaluate(pad(vel[flag]))[0])
        M=np.einsum("qi,eq,qj->eij",grid.val,grid.points**2*grid.w,grid.val)
        mass=grid.matrix(M,grid.ids,grid.size)
        self.vals=[]
        for ell,J in ((0,mono_v),(2,quad_v)):
            K=grid.scalar[ell,"matched"][0].copy()+mu**2*mass
            impedance=-mu*spherical_kn(ell,mu*grid.edge,derivative=True)/spherical_kn(ell,mu*grid.edge)
            K[-1,-1]+=(impedance-(ell+1)/grid.edge)*grid.edge**2
            active=np.arange(int(ell>0),grid.size);sol=np.zeros(grid.size)
            sol[active]=splu(K[active][:,active].tocsc()).solve(grid.load(-1.5*J)[active])
            self.vals.append(sol)
    def apply(self,m,ref,r,read):
        m=m.copy();ref=ref.copy();bg=self.bg
        T0,S0=read(self.vals[0]);T2,S2=read(self.vals[1])
        m["p"]=m["p"]+S0;m["P"]=m["P"]+S2;m["Pt"]=m["Pt"]+T2/r
        ref["clock_j0"]=bg["so"]*S0
        ref["jr"]=ref["jr"]+bg["so"]*S2;ref["jt"]=ref["jt"]+bg["so"]*T2/r
        if self.environment=="fixed":
            ref["clock_e0"]=3*bg["H"]*bg["so"]*T0
            ref["other"]=ref["other"]+3*bg["H"]*bg["so"]*T2
        return m,ref
