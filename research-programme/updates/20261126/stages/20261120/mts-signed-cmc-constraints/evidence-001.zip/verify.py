from compare import *
from anchor import OLD as HOST,manifest as host_manifest
def audit():
    guard()
    for name in prior:verified(name)
    rejected=json.loads((GR/"seal.json").read_bytes())["rejected"]
    for name,value in rejected.items():assert digest(GR/name)==value
    for name in host_manifest:saved(name)
    native_rows=load("native-cmc-recovery.csv")
    assert len(native_rows)==360 and max(abs(float(r["relative"])) for r in native_rows)<2e-5
    man=load("manufactured.csv")
    assert len(man)==10 and max(abs(float(r["relative_tide_error"])) for r in man)<2e-5
    phases=load("real-field-quadratures.csv")
    assert len(phases)==120 and max(float(r[k]) for r in phases for k in ("energy_identity","current_identity","stress_identity"))<1e-9
    assert all((float(r["nu"])>0 and float(r["rest_fractional_excess"])>=0) for r in phases)
    tides=load("host-wave-tides.csv");proper=load("proper-distance-comparison.csv");paired=load("direct-wave-isolation.csv")
    assert (len(tides),len(proper),len(paired))==(432,120,648)
    for section,keys in ((tides,("tide","weyl","cross","newton","stress")),(proper,("tide","weyl","same_lift","stress_lift")),
                       (paired,("direct","same_lift","full_switch"))):
        assert all(float(r[k])==0 for r in section if r["model"]=="cold" for k in keys)
    for section,total,passes in ((tides,18,10),(proper,10,8)):
        ref={(r["rate"],r["seed"],r["radius"]):r for r in section if r["model"]=="heavy" and r["config"]=="reference"}
        errors=[abs(float(row["tide"])/float(ref["5",sign,r]["tide"])-1) for (rate,sign,r),row in ref.items() if rate=="4"]
        assert len(errors)==total and sum(v<=2e-5 for v in errors)==passes
    for s in ("1","-1"):
        val,=[r for r in proper if (r["model"],r["rate"],r["config"],r["seed"],r["radius"])==("heavy","5","reference",s,"1.35307765")]
        assert -.000365<float(val["relative"])<-.000360
        assert .00015<float(val["same_lift"])/float(val["newton"])-1<.00016
        for r in paired:
            if r["seed"]==s and r["model"]=="heavy" and r["radius"]=="1.35307765":
                assert abs(float(r["subtraction"])/float(r["direct"]))<2e-5
                if r["common_TT_change"]:assert abs(float(r["common_TT_change"])/float(r["direct"]))<2e-5
    for model in ("heavy","cold"):
        for rate in (4,5):
            label=f"{model}-h{rate}"
            rr=load(label+"-sources.csv");assert len(rr)==(351 if model=="heavy" else 324)
            for line in rr:
                pred=float(line["tide"]);weyl=float(line["weyl"]);stress=float(line["stress"])
                assert abs(pred-weyl-stress/2)<1e-22
            assert max(abs(float(r["green_slope_error"])) for r in rr)<3e-18
            if rate==5:
                for key in ("mom_radial_defect","mom_tan_defect"):
                    assert max(abs(float(r[key])) for r in rr)<3e-19
            rrs=load(label+"-ruler.csv")
            assert max(abs(float(r["length_residual"])) for r in rrs)<5e-15
            assert max(abs(float(r["slope_check"])) for r in rrs)<2e-23
            with np.load(HERE/(label+"-slice.npz")) as packet:
                assert len(packet.files)==(29 if model=="heavy" else 20) and len(packet["nodes"])==120*6*rate+1
                for key in packet:assert np.isfinite(packet[key]).all()
    assert not any(p.is_dir() or p.suffix==".partial" for p in HERE.iterdir())
    files={p.name:digest(p) for p in HERE.iterdir() if p.is_file() and p.name!="seal.json"}
    return dict(files=files,source_seal=PIN,source_files=len(prior),source_rejected=len(rejected),host_files=len(host_manifest),
                numerical_csv_rows={p.name:len(load(p.name)) for p in HERE.glob("*.csv")})
if __name__=="__main__":
    receipt=audit();raw=(json.dumps(receipt,indent=2,sort_keys=True)+"\n").encode()
    if sys.argv[1:]==["--seal"]:write("seal.json",raw)
    assert (HERE/"seal.json").read_bytes()==raw
    print(len(receipt["files"]),"local files;",sum(receipt["numerical_csv_rows"].values()),"rows;",digest(HERE/"seal.json"))
