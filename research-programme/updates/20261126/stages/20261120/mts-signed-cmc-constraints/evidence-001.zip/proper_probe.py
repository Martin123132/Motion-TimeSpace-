"""Use a specified ruler on the symmetry axis, not equal coordinate radii."""
from run_slices import *
from clock_lift import ClockLift
from scipy.optimize import brentq

class Ruler:
    def __init__(self,solution):
        self.obj=solution;g=solution.grid
        f=g.evaluate(solution.f0)[0];x=g.evaluate(solution.f2)[0]
        self.fns=(2*f+f*f,2*(1+f)*x)
        self.pre=[g.integral(arr)[0] for arr in self.fns]
    def integral(self,r,num):
        g=self.obj.grid
        el,t,unused=g.probe(r)
        return self.pre[num][el]+(g.prefix_weights([t])@self.fns[num][el]).item()
    def monopole(self,r):
        obj=self.obj;g=obj.grid
        el,t,read=g.probe(r);f,fr,unused=read(obj.f0)
        ref=shape(obj.bg,np.asarray(r))
        m=material(ref,r,lambda v:read(v)[:2],obj.state,obj.flag)
        if obj.clock is not None:m,ref=obj.clock.apply(m,ref,r,lambda v:read(v)[:2])
        B=(obj.pre[el]+(g.prefix_weights([t])@obj.integrand[el]).item())/r**3
        rhs=obj.source(f,fr,m["n"],m["g"],m["p"],B,0,ref)
        u=1+f
        intrinsic=(4/3)*(rhs+3*fr/r)/u**5+4*fr**2/u**6
        extrinsic=-obj.bg["H"]*B/u**6-B**2/(2*u**12)
        stress=m["n"]*m["p"]**2/np.sqrt(1+m["p"]**2/u**4)
        if obj.canonical:
            j=obj.j
            stress[j]=m["n"][j]*(m["p"][j]**2+obj.eps*(m["g"][j]/m["n"][j]-6*fr/u)**2)
        tensor=(2/3)*(obj.rh@stress)/u**10
        return -intrinsic-extrinsic+np.array([tensor,tensor/2])
    def read(self,r):
        obj=self.obj;g=obj.grid
        ri=brentq(lambda p:p-r+self.integral(p,0),r-.002,r+.002,xtol=5e-15)
        f=g.probe(ri)[2](obj.f0)[0]
        shift=-self.integral(ri,1)/(1+f)**2
        def grad(step):return (self.monopole(ri+step)-self.monopole(ri-step))/(2*step)
        low=grad(g.h/400);high=grad(g.h/800)
        derivative=(4*high-low)/3
        values=obj.tidal(ri);ordinary=self.monopole(ri)
        return dict(r0=ri,radial_shift=shift,monopole_tide=ordinary[0],monopole_weyl=ordinary[1],
            at_r0_tide=values["tide"],at_r0_weyl=values["weyl"],ruler_tide=values["tide"]+shift*derivative[0],
            ruler_weyl=values["weyl"]+shift*derivative[1],slope_check=abs(shift*(high-low)).max()/3,
            length_residual=ri-r+self.integral(ri,0))
def main(model,rate):
    sim=BalancedNative(model,120,120*rate,False,"native36",SPAN*DLOG)
    grid=Element(sim.mesh,120,10 if rate==4 else 12)
    bg={i:native(model,i) for i in (0,1)}
    samples={i:(shape(b,grid.points),shape(b,np.asarray(120.))) for i,b in bg.items()}
    amp=(2/15)*sum(native("heavy",0)["w"]*native("heavy",0)["k"]**2*native("heavy",0)["clock"])
    rows=[]
    for seed in (0,1,-1):
        state=stage_field(sim,model,seed if seed else 1,rate)
        if not seed:state=tuple(np.zeros_like(v) for v in state)
        for name,use_clock,tensor in (("reference",False,0),("tensor",False,1),("tilt",True,0)):
            for label,flag,canon in (("on",0,model=="heavy"),("off",1,False),("off_same_lift",1,model=="heavy")):
                clock=ClockLift(grid,bg[flag],state,flag) if use_clock else None
                s=Slice(sim,grid,bg[flag],samples[flag],state,flag,canon,"fixed",tensor*amp,"matched",clock)
                reader=Ruler(s)
                for r in PROBES[:5]:
                    rows.append(dict(model=model,rate=rate,config=name,seed=seed,branch=label,proper_comoving=r,
                        **reader.read(r)))
    savecsv(f"{model}-h{rate}-ruler.csv",rows);print(model,rate,len(rows),flush=True)
if __name__=="__main__":main(sys.argv[1],int(sys.argv[2]))
