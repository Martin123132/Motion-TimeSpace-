from inputs import *
def load(name):
    with (HERE/name).open() as stream:return list(csv.DictReader(stream))
def index(items,keys):
    ans={tuple(row[k] for k in keys):row for row in items}
    assert len(ans)==len(items)
    return ans
def main():
    output=[];sensitivity=[];controls=[];paired=[]
    for model in ("heavy","cold"):
        for rate in (4,5):
            label=f"{model}-h{rate}"
            values=load(label+"-sources.csv")
            raw=index(values,("config","seed","branch","radius"))
            vari=index(load(label+"-differential.csv"),("clock","env","TT","seed","branch","radius"))
            rulers=index(load(label+"-ruler.csv"),("config","seed","branch","proper_comoving"))
            def delta(fetch,field,seed,off="off"):
                return (fetch(seed,"on",field)-fetch("0","on",field))-(fetch(seed,off,field)-fetch("0",off,field))
            for rad in sorted(set(r["radius"] for r in values),key=float):
                for seed in ("1","-1"):
                    ref=lambda seed,branch,key:float(raw["reference",seed,branch,rad][key])
                    newton=delta(ref,"newton_host",seed)
                    for config in sorted(set(r["config"] for r in values)):
                        test=lambda s,b,k:float(raw[config,s,b,rad][k])
                        vals={q:delta(test,q,seed) for q in ("tide","weyl","cross","stress","extrinsic","scalar3","green_slope_error","metric_poly_defect")}
                        output.append(dict(model=model,rate=rate,seed=seed,radius=rad,config=config,**vals,newton=newton,
                             relative=(vals["tide"]/newton-1) if newton else None,ordinary=test(seed,"on","tide"),
                             host=test(seed,"on","tide")-test("0","on","tide"),
                             ordinary_vs_ref=test(seed,"on","tide")-ref(seed,"on","tide")))
                    for clock,env in (("0","fixed"),("1","fixed"),("1","volume")):
                        get=lambda s,b,k:float(vari[clock,env,"0",s,b,rad][k])
                        for field in ("tide","weyl","cross"):
                            direct=get(seed,"direct",field)-get("0","direct",field)
                            same=delta(get,field,seed,"off_same_lift")
                            alloff=delta(get,field,seed)
                            ttcheck=None
                            if clock=="0":
                                with_tt=lambda s,b,k:float(vari[clock,env,"1",s,b,rad][k])
                                ttcheck=delta(with_tt,field,seed,"off_same_lift")-same
                            paired.append(dict(model=model,rate=rate,seed=seed,radius=rad,clock=clock,env=env,field=field,
                                direct=direct,same_lift=same,full_switch=alloff,stress_lift=alloff-same,
                                subtraction=direct-same,common_TT_change=ttcheck))
                    if ("reference",seed,"on",rad) in rulers:
                        for cfg in ("reference","tensor","tilt"):
                            get=lambda s,b,k:float(rulers[cfg,s,b,rad][k])
                            value=delta(get,"ruler_tide",seed);same=delta(get,"ruler_tide",seed,"off_same_lift")
                            sensitivity.append(dict(model=model,rate=rate,seed=seed,radius=rad,config=cfg,tide=value,
                                weyl=delta(get,"ruler_weyl",seed),same_lift=same,stress_lift=value-same,newton=newton,
                                relative=value/newton-1 if newton else None,ref_coordinate=delta(ref,"tide",seed)))
                for flag in ("on","off"):
                    val=raw["reference","0",flag,rad]
                    for k,refkey in (("tide","ref_tide"),("weyl","ref_weyl"),("cross","ref_cross"),("Brr2","native_Brr"),("chi2","native_chi")):
                        pred=float(val[k]);orig=float(val[refkey]);rel=pred/orig-1
                        controls.append(dict(model=model,rate=rate,branch=flag,radius=rad,observable=k,
                            solved=pred,native=orig,relative=rel))
    for name,data in (("host-wave-tides",output),("direct-wave-isolation",paired),("proper-distance-comparison",sensitivity),
                      ("native-cmc-recovery",controls)):savecsv(name+".csv",data)
if __name__=="__main__":main()
