from run_slices import *
import sympy as sy

def manufactured():
    r=sy.symbols("r",positive=True);s=r/8;decay=sy.exp(-s*s)
    f=sy.Rational(1,10**6)*decay;x=sy.Rational(1,2*10**6)*s**2*decay
    b0=sy.Rational(1,10**8)*s*s*decay
    wr=sy.Rational(1,10**8)*r*(1+s*s/2)*decay
    wt=sy.Rational(1,10**8)*r*(sy.Rational(1,2)-s*s/3)*decay
    b=4*(wr.diff(r)-wr/r)/3+4*wt/r
    c=wt.diff(r)+(wr-wt)/r;d=2*wt/r
    j0=b0.diff(r)+3*b0/r;jr=b.diff(r)+(3*b-6*c)/r;jt=c.diff(r)+(3*c-b/2-2*d)/r
    lap=lambda v,ell:v.diff(r,2)+2*v.diff(r)/r-ell*(ell+1)*v/r**2
    names="f fr frr x xr xrr lap0 lap2 b0 b wr wt j0 jr jt".split()
    compiled=sy.lambdify(r,[f,f.diff(r),f.diff(r,2),x,x.diff(r),x.diff(r,2),lap(f,0),lap(x,2),b0,b,wr,wt,j0,jr,jt],"numpy",cse=True)
    at=lambda s:dict(zip(names,compiled(s)))
    R=4e-6;H=np.sqrt(R/3);t=1e-24j
    class Fixture:
        def apply(self,unused,ref,r,read):
            data=at(r);u=1+data["f"]+t*data["x"]
            jj=data["j0"]+t*data["jr"]
            energy=R-4*(data["lap0"]+t*data["lap2"])/u**5-.75*(data["b0"]+t*data["b"])**2/u**12
            n=u**6*np.sqrt(energy**2-jj**2/u**16)/R;p=jj/(R*n)
            assert np.min(n.real)>.8
            z=np.zeros_like(r)
            return dict(n=n.real[None],g=z[None],p=p.real[None],D=(n.imag/t.imag)[None],Dr=z[None],
                      P=(p.imag/t.imag)[None],Pt=(data["jt"]/(R*n.real))[None]),ref
    from types import SimpleNamespace
    from mesh import Mesh
    rows=[]
    for rate in (2,4):
        grid=Element(Mesh(24,rate*24),24,12)
        model=SimpleNamespace(mesh=SimpleNamespace(grid=lambda v:np.pad(v,[(0,0)]*(v.ndim-1)+[(1,0)])),patch=SimpleNamespace(j=0))
        bg=dict(k=np.array([1.]),w=np.array([0.]),H=H,R=R,rh=np.array([R]),so=0.)
        for key in ("clock","chi","e_other","e_star","j_other","stress","psi","weyl","phi","n","p"):bg[key]=np.zeros(1)
        state=(np.zeros((2,1,grid.size-1)),np.zeros((3,1,grid.size-1)),np.zeros((3,1,grid.size-1)))
        fq=shape(bg,grid.points);ed=shape(bg,np.array(24.))
        ed.update(wr=at(24.)["wr"],wt=at(24.)["wt"],chi=at(24.)["x"])
        orig=grid.solve
        grid.solve=lambda ell,field,bound,bc:orig(ell,field,bound,at(24.)["f"] if ell==0 else bc)
        obj=Slice(model,grid,bg,(fq,ed),state,0,False,"fixed",0.,"wall",Fixture())
        target=at(grid.r+1e-50);errors={}
        for val,key in ((obj.f0,"f"),(obj.f2,"x"),(obj.W[0],"wr"),(obj.W[1],"wt")):
            errors[key]=float(np.max(abs(val-target[key]))/np.max(abs(target[key])))
            assert errors[key]<1e-8,(rate,key,errors[key])
        for radius in PROBES[:5]:
            sol=obj.tidal(radius);z=at(radius);u=1+z["f"]+t*z["x"]
            hs=(2/3)*(z["frr"]-z["fr"]/radius)+t*((2/3)*(z["xrr"]-z["xr"]/radius)+2*z["x"]/radius**2)
            k=z["b0"]+t*z["b"]
            e=R-4*(z["lap0"]+t*z["lap2"])/u**5-.75*k**2/u**12
            j=z["j0"]+t*z["jr"]
            tidal=2*hs/u**5-4*(z["fr"]+t*z["xr"])**2/u**6+H*k/u**6+k**2/(2*u**12)+(2/3)*(j/u**8)**2/e
            relative=(sol["tide"]-tidal.imag/t.imag)/(tidal.imag/t.imag)
            assert abs(relative)<2e-5
            rows.append(dict(rate=rate,radius=radius,**errors,relative_tide_error=relative))
    savecsv("manufactured.csv",rows)
def verify_tt():
    r=np.linspace(1,50,641);h=.0003
    b,c,d=tt(r)
    derivative=[(x-y)/(2*h) for x,y in zip(tt(r+h),tt(r-h))]
    radial=derivative[0]+(3*b-6*c)/r
    polar=derivative[1]+(3*c-b/2-2*d)/r
    assert max(np.max(abs(radial)),np.max(abs(polar)))<5e-8
if __name__=="__main__":verify_tt();manufactured()
