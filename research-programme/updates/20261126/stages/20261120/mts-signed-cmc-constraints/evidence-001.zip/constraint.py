from inputs import *
from elements import Element

def shape(native,r):
    at=response(native,r);der=response(native,r,1);d2=response(native,r,2)
    return dict(D=at("n"),Dr=der("n"),V=at("p"),Vr=der("p"),
        other=at("e_other"),star=at("e_star"),jr=der("j_other"),jt=at("j_other")/r,
        chi=at("chi"),chir=der("chi"),wr=der("clock")/2,wt=at("clock")/(2*r),
        ref_b=(2/3)*(d2("clock")-der("clock")/r)+2*at("clock")/r**2,
        stress=(2/3)*(d2("stress")-der("stress")/r)+2*at("stress")/r**2,
        stress_cross=-1.5*(der("stress")/r-at("stress")/r**2),
        geo=-((2/3)*(d2("psi")-der("psi")/r)+2*at("psi")/r**2),
        electric=-((2/3)*(d2("weyl")-der("weyl")/r)+2*at("weyl")/r**2),
        cross=1.5*(der("psi")/r-at("psi")/r**2))
def material(base,r,read,state,flag):
    mono,den,vel=state
    reduced,redr=read(mono)
    loc,grad=read(den);w,wr=read(vel)
    number=1+reduced[0]/r
    dn=(redr[0]-reduced[0]/r)/r;speed=(redr[1]-reduced[1]/r)/r
    return dict(n=number,g=dn,p=speed,D=base["D"]+loc[flag],Dr=base["Dr"]+grad[flag],
                P=base["Vr"]+wr[flag],Pt=(base["V"]+w[flag])/r)
def tt(r):
    t=np.clip((r-12)/24,0,1)
    val=1-t**5*(126+t*(-420+t*(540+t*(-315+70*t))))
    der=-630*t**4*(1-t)**4/24
    second=-2520*t**3*(1-t)**3*(1-2*t)/24**2
    c=(3*val+r*der)/6
    d=(r*(4*der+r*second)/6+3*c-val/2)/2
    return val,c,d
def strain(r,fields):
    wr,wt,dr,dt=fields
    return (4/3)*(dr-wr/r)+4*wt/r,dt+(wr-wt)/r,2*wt/r
class Slice:
    def __init__(self,sim,grid,reference,samples,state,flag,canonical,env,tt_amp,bound,clock=None):
        self.sim=sim;self.grid=grid;self.bg=reference;self.flag=flag;self.canonical=canonical;self.env=env
        self.amp=tt_amp;self.bound=bound
        p=sim.patch;rh=reference["rh"]
        self.rh=rh;self.j=p.j if canonical else None
        self.eps=1/(4*(reference["a"]*p.p.mass)**2) if canonical else 0.
        self.state=tuple(sim.mesh.grid(raw) for raw in state)
        fq,edge=samples;self.clock=clock
        r=grid.points
        m=material(fq,r,grid.evaluate,self.state,flag)
        if clock is not None:m,fq=clock.apply(m,fq,r,grid.evaluate)
        self.m=m;self.fq=fq
        rw=rh[:,None,None]
        self.js0=np.sum(rw*m["n"]*m["p"],axis=0)+fq.get("clock_j0",0)
        jr=np.sum(rw*(m["n"]*m["P"]+m["D"]*m["p"]),axis=0)+fq["jr"]
        jt=np.sum(rw*m["n"]*m["Pt"],axis=0)+fq["jt"]
        integrand=self.js0*r**3
        self.pre,b0=grid.integral(integrand);self.integrand=integrand
        self.b0=b0/r**3
        self.W=grid.momentum(jr,jt,edge["wr"],edge["wt"])
        w,der=grid.evaluate(self.W)
        self.b2,self.c2,self.d2=[v+tt_amp*t for v,t in zip(strain(r,(*w,*der)),tt(r))]
        bc0=0.
        bc2=edge["chi"] if bound=="wall" else edge["chir"]+3*edge["chi"]/grid.edge
        self.f0,self.res0=self.iterate(0,bc0)
        self.f2,self.res2=self.iterate(2,bc2)
    def count(self,t,depth):
        return self.rh.reshape((-1,)+(1,)*depth)*t
    def source(self,chi,chir,n,g,p,b,theta,base):
        u=1+chi;ln=np.log1p(chi)
        W=np.sqrt(1+p*p/u**4)
        wminus=p*p/(u**4*(1+W))
        if self.canonical:
            j=self.j
            grad=g[j]/n[j]-6*chir/u
            wminus[j]=(p[j]**2+self.eps*grad**2)/(2*u**4)
        deficit=n*wminus*np.exp(-6*ln)+(n-1)*np.exp(-6*ln)+np.expm1(-6*ln)
        energy=np.sum(self.count(deficit,chi.ndim),axis=0)
        if self.env=="fixed":energy+=theta*base["other"]
        else:energy+=theta*base["star"]-6*self.bg["so"]*ln
        if "clock_e0" in base:energy+=base["clock_e0"]
        return u**5*energy/4+3*b*b/(16*u**7)
    def hsource(self,ell,x,dx):
        m=self.m
        if ell==0:return self.source(x,dx,m["n"],m["g"],m["p"],self.b0,0,self.fq)
        f,df=self.grid.evaluate(self.f0)
        return self.jet(m,self.fq,f,df,x,dx,self.b0,self.b2)
    def jet(self,m,ref,f,df,x,dx,b0,b2):
        t=1e-24j
        return self.source(f+t*x,df+t*dx,m["n"]+t*m["D"],m["g"]+t*m["Dr"],m["p"]+t*m["P"],
            b0+t*b2,t,ref).imag/t.imag
    def iterate(self,ell,bc):
        arr=np.zeros(self.grid.size)
        for count in range(24):
            rhs=self.hsource(ell,*self.grid.evaluate(arr))
            new=self.grid.solve(ell,rhs,self.bound,bc)
            err=np.max(abs(new-arr));arr=new
            if err<8e-12*max(1e-20,np.max(abs(arr))):break
        else:raise RuntimeError(("elliptic fixed point did not settle",ell,err))
        return arr,(count+1,err)
    def tidal(self,r):
        bg=self.bg;msh=self.grid;el,t,read=msh.probe(r)
        ref=shape(bg,np.asarray(r))
        m=material(ref,r,lambda x:read(x)[:2],self.state,self.flag)
        if self.clock is not None:m,ref=self.clock.apply(m,ref,r,lambda v:read(v)[:2])
        b0=(self.pre[el]+(msh.prefix_weights([t])@self.integrand[el]).item())/r**3
        bv,bd,bdd=read(self.W)
        b,c,d=[v+self.amp*k for v,k in zip(strain(r,(*bv,*bd)),tt(r))]
        f,fr,frr=read(self.f0);x,xr,xrr=read(self.f2)
        rhs0=self.source(f,fr,m["n"],m["g"],m["p"],b0,0,ref)
        rhs2=self.jet(m,ref,f,fr,x,xr,b0,b)
        H=bg["H"];u=1+f;step=1e-24j
        def axial(fpp,xpp):
            h=f+step*x;hr=fr+step*xr
            htf=(2/3)*(fpp-fr/r)+step*((2/3)*(xpp-xr/r)+2*x/r**2)
            strain=b0+step*b
            Ric=-2*htf/(1+h)**5+4*hr**2/(1+h)**6
            ext=-H*strain/(1+h)**6-strain**2/(2*(1+h)**12)
            return Ric.imag/step.imag,ext.imag/step.imag
        rc,ext=axial(-rhs0-2*fr/r,-rhs2-2*xr/r+6*x/r**2)
        alt,unused=axial(frr,xrr)
        n=m["n"]+step*m["D"];p=m["p"]+step*m["P"];h=u+step*x
        W=np.sqrt(1+p**2/h**4)
        stress=n*p*p/W
        cross=m["n"]*m["p"]*m["Pt"]/np.sqrt(1+m["p"]**2/u**4)
        if self.canonical:
            j=self.j
            g=(m["g"][j]+step*m["Dr"][j])/n[j]-6*(fr+step*xr)/h
            stress[j]=n[j]*(p[j]**2+self.eps*g**2)
            cross[j]=m["n"][j]*(m["p"][j]*m["Pt"][j]+self.eps*(m["g"][j]/m["n"][j]-6*fr/u)*(m["D"][j]/m["n"][j]-6*x/u)/r)
        srr=ref["stress"]+(2/3)*((self.rh@stress)/h**10).imag/step.imag
        srcross=ref["stress_cross"]-1.5*(self.rh@cross)/u**10
        rx=-1.5*(-2*(xr/r-x/r**2)/u**5+6*fr*x/r/u**6)
        ex=-1.5*(-H*c/u**6-b0*c/(2*u**12))
        divr=(4/3)*(bdd[0]-bd[0]/r+bv[0]/r**2)+4*(bd[1]/r-bv[1]/r**2)+3*(b-self.amp*tt(r)[0])/r-6*(c-self.amp*tt(r)[1])/r
        divt=bdd[1]+(bd[0]-bd[1])/r-(bv[0]-bv[1])/r**2+(3*(c-self.amp*tt(r)[1])-(b-self.amp*tt(r)[0])/2-2*(d-self.amp*tt(r)[2]))/r
        jr=self.rh@(m["n"]*m["P"]+m["D"]*m["p"])+ref["jr"]
        jt=self.rh@(m["n"]*m["Pt"])+ref["jt"]
        return dict(chi0=f,chi2=x,Brr0=b0,Brr2=b,scalar3=rc,extrinsic=ext,stress=srr,
            tide=-rc-ext+srr,weyl=-rc-ext+srr/2,cross=-rx-ex+srcross,
            metric_poly_defect=alt-rc,poisson_defect=xrr+2*xr/r-6*x/r**2+rhs2,
            mom_radial_defect=divr-jr,mom_tan_defect=divt-jt,
            momentum_r=jr,momentum_t=jt,ref_tide=ref["geo"],ref_weyl=ref["electric"],ref_cross=ref["cross"],
            native_chi=ref["chi"],native_Brr=ref["ref_b"],radial_source=rhs2)
