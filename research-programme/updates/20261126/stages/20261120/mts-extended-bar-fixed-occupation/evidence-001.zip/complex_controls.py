from branch_state import *

def run(mesh, order, occupation):
    wave, ground, chemical, drive, _ = restored(mesh, order, occupation, False)
    bg = wave.bg
    total = ground @ ground
    ground_sky = sky_of(bg, ground)
    ground_moment = ground_sky**2 @ wave.weights
    tangent = wave.fields(ground)[3] - chemical * wave.eye
    ground_error = tangent @ ground
    def source(moment):
        return np.r_[(moment * (bg.sqrt/bg.rad)[:, None]).ravel(), np.zeros(bg.count)]
    def pairing(left, right):
        return left @ bg.glu.solve(right)
    ground_source = source(ground_moment)
    ground_energy = ground @ (wave.bare @ ground) - .5*pairing(ground_source,ground_source)
    trap = read(f"trap-{mesh}-o{occupation}")[0]
    bound = float(trap["b"])
    gap = float(trap["gap"])
    charge = float(trap["neutral_charge_factor"])
    cross = float(trap["mixed_D_per_sqrt_energy"])
    energy = float(trap["source_energy"])
    operator_norm = float(trap["drive_norm"])
    caps = read(f"nonlinear-readouts-{mesh}-o{occupation}")
    generator = np.random.default_rng(20261120)
    rows = []
    for kind in ("smooth", "mixed", "inner_cell"):
        trial = generator.standard_normal((2, *bg.hshape))
        if kind == "smooth":
            trial[:, :, 2:] = 0.
            for field in trial:
                for column in range(2):
                    field[:, column] = np.convolve(field[:, column], np.ones(31)/31, mode="same")*np.exp(-bg.rad/10)
        if kind == "inner_cell":
            trial[:, 1:, :] = 0.
        real, imag = trial.reshape(2, -1)
        real -= ground*(ground@real/total)
        imag -= ground*(ground@imag/total)
        mixed = source((ground_sky*sky_of(bg, real))@wave.weights)
        scale_energy = real@(tangent@real)+imag@(tangent@imag)-2*pairing(mixed,mixed)
        assert scale_energy > 0
        for fraction in (.5, 1., 2.):
            scale = fraction * bound / np.sqrt(scale_energy)
            actual_b = bound*fraction
            ufield, vfield = real*scale, imag*scale
            transverse = ufield@ufield+vfield@vfield
            amplitude = np.sqrt(1-transverse/total)
            field = amplitude*ground+ufield+1j*vfield
            assert abs(np.vdot(field,field).real/total-1)<1e-13
            mixed_source = mixed*scale
            excited_moment = abs(sky_of(bg, ufield+1j*vfield))**2 @ wave.weights
            neutral = source(excited_moment - transverse/total*ground_moment)
            neutral_norm = np.sqrt(pairing(neutral,neutral))
            assert neutral_norm <= charge*transverse and transverse <= actual_b**2/gap
            assert np.sqrt(pairing(mixed_source,mixed_source))<=cross*actual_b
            difference = 2*amplitude*mixed_source+neutral
            actual_source = source(abs(sky_of(bg,field))**2 @ wave.weights)
            exact = np.vdot(field,wave.bare@field).real - .5*pairing(actual_source,actual_source)-ground_energy
            expansion = ufield@(tangent@ufield)+vfield@(tangent@vfield)+2*amplitude*(ufield@ground_error)-transverse/total*(ground@ground_error)-.5*pairing(difference,difference)
            defect = abs(exact-expansion)
            assert defect<1e-11 and abs(exact)>100*defect
            work = abs(2*amplitude*(ufield@(drive@ground))+ufield@(drive@ufield)+vfield@(drive@vfield)-transverse/total*(ground@(drive@ground)))
            assert work<=2*np.sqrt(energy)*actual_b+operator_norm*actual_b**2/gap
            moment_change=2*amplitude*(ground_sky*sky_of(bg,ufield))@wave.weights+excited_moment-transverse/total*ground_moment
            forces=np.einsum("erl,rl->e",wave.rows[:4],moment_change)
            for cap, force in zip(caps,forces):
                assert abs(force)<=float(cap["linear_term"])*fraction+float(cap["quadratic_term"])*fraction**2
            if fraction == 1:
                assert exact>=float(trap["lower"]) and float(trap["lower"])>float(trap["work"])
            rows.append(dict(mesh=mesh,occupation=occupation,kind=kind,fraction=fraction,energy=exact,identity_error=defect,charge_ratio=neutral_norm/(charge*transverse),work=work,polar=forces[1]))
    table(f"complex-controls-{mesh}-o{occupation}",rows)
if __name__=="__main__":
    for mesh,order in [(0,4),(1,8)]:
        for occupation in (0,1):run(mesh,order,occupation)
