from branch_state import *

def run(mesh,order,occupations):
    for occ in occupations:
        wave,g,mu,drive,mass=restored(mesh,order,occ,False);bg=wave.bg
        h0=wave.fields(g)[3]-mu*wave.eye;sky=sky_of(bg,g)
        factor=splu(jacobian(wave,g,mu));drive_g=drive@g
        stem=f"{['coarse','fine'][mesh]}-{mesh}-o{occ}-q{order}"
        with np.load(HERE/f"state-{stem}.npz") as saved:
            x=saved["x"].ravel();y=saved["y_second"].ravel();endpoint=saved["g"].ravel()
        tangent=np.array([float(r["slope"]) for r in read("derivatives-"+stem)[:5]])
        curvature=np.array([float(r["curvature"]) for r in read("derivatives-"+stem)[:5]])
        samples={};deviations={};checks=[]
        for t in (-.25,.25,-.125,.125,-.0625,.0625,1.):
            dx=np.zeros_like(g);dm=0.
            for iteration in range(15):
                added=sky_of(bg,dx);rho=(2*sky*added+added**2)@wave.weights
                shift=wave.mult(self_field(bg,rho))+t*drive
                res=h0@dx+shift@(g+dx)-dm*(g+dx)
                number=g@dx+.5*(dx@dx)
                ratio=np.linalg.norm(res)/(abs(t)*np.linalg.norm(drive_g))
                if ratio<2e-10 and abs(number)<1e-17:break
                step=factor.solve(np.r_[-res,np.zeros(bg.grav.shape[0]),-number])
                dx+=step[:len(g)];dm+=step[-1]
            else:raise ArithmeticError((t,number,ratio))
            samples[t]=np.einsum("erl,rl->e",wave.rows,rho);deviations[t]=dx
            if t==1:
                true=np.linalg.norm((g+dx)-endpoint)/np.linalg.norm(dx)
                assert true<2e-5
        for step in (.25,.125,.0625):
            first=(samples[step]-samples[-step])/(2*step);second=(samples[step]+samples[-step])/step**2
            field_error1=np.linalg.norm((deviations[step]-deviations[-step])/(2*step)-x)/np.linalg.norm(x)
            field_error2=np.linalg.norm((deviations[step]+deviations[-step])/step**2-y)/np.linalg.norm(y)
            for j,label in enumerate(NAMES):
                checks.append(dict(occupation=occ,h=step,component=label,slope_relative=abs(first[j]/tangent[j]-1),
                                   curvature_relative=abs(second[j]/curvature[j]-1),wave_slope=field_error1,wave_curvature=field_error2,
                                   endpoint_independent_relative=true))
        table("increment-"+stem,checks)
        print(stem,field_error1,field_error2,true,flush=True)
if __name__=="__main__":run(int(sys.argv[1]),int(sys.argv[2]),list(map(int,sys.argv[3:])))
