from wave_transfer import *

def run(keep=64):
    suffix="" if keep==64 else f"-k{keep}"
    prior=ls.old.read(BAR,"full-paired-forces")
    stellar=ls.old.read(PARENT,"whole-force-20")
    bounds=[];delta=[]
    halo=prep.ms.nfw(0);outer=-halo(prep.ms.OUTER,0.)[0]
    fixed=ls.old.read(BAR,"states-fine-1")
    prev=ls.old.read(BAR,"lmc-fine-1")
    for occ in [0,1]:
        states=read(f"equilibria-fine-1-o{occ}-q8");sats=read(f"satellite-1-o{occ}-q8-k{keep}")
        for t in (0,1):
            state=next(s for s in states if float(s["t"])==t)
            nfw_scale=float(state["anchor_inward"])/UNIT/outer
            assert t or abs(nfw_scale/float(fixed[occ]["nfw_scale"])-1)<1e-10
            for oldrow in (s for s in prior if int(s["occupation"])==occ):
                mod=oldrow["model"];hist=oldrow["history"];comp=oldrow["component"]
                rad,z=float(oldrow["R"]),float(oldrow["z"])
                key=("inner_" if rad==6 else "outer_")+comp
                sign=-1 if z<0 and comp=="polar" else 1
                old_sat=next(v for v in prev if int(v["occupation"])==occ and v["history"]==hist and v["substeps"]=="16")
                new_sat=next(v for v in sats if v["history"]==hist and v["substeps"]=="16")
                earlier_key=("r" if comp=="radial" else "p")+("6" if rad==6 else "83")
                old_increment=float(old_sat[earlier_key]);new_increment=float(new_sat[key])
                if t and oldrow["frame"]=="site_minus_point" and mod=="MTS" and z>0:
                    delta.append(dict(occupation=occ,history=hist,component=key,old_induced=old_increment,new_induced=new_increment,
                                      change=new_increment-old_increment,relative=new_increment/old_increment-1,
                                      old_inner_mass=old_sat["inner_mass"],new_inner_mass=new_sat["inner_mass"]))
                star=next(float(v["delta"])*.4 for v in stellar if v["group"]=="S22" and float(v["R"])==rad and v["component"]==comp)
                ordinary=float(oldrow["ordinary_before"])+float(oldrow["bar_minus_sphere"])+sign*t*star
                field=sign*float(state[key])
                if mod=="NFW":
                    aR,az,*_=halo(rad,abs(z))
                    field=sign*nfw_scale*prep.projection(aR,az,rad,abs(z))[int(comp=="polar")]
                sat=sign*(new_increment if t else old_increment) if mod=="MTS" else 0.
                direct=float(oldrow["LMC_direct"])
                for policy,val in (("isolated",ordinary+field),("direct_LMC",ordinary+field+direct),("direct_plus_m0",ordinary+field+direct+sat)):
                    lower,upper=float(oldrow["low"]),float(oldrow["high"])
                    if t==0 and policy=="direct_plus_m0":
                        assert abs(val-(float(oldrow["total"])-float(oldrow["rotating_bar_wave"])))<2e-9
                    bounds.append(dict(t=t,occupation=occ,history=hist,model=mod,frame=oldrow["frame"],policy=policy,R=rad,z=z,component=comp,
                                       ordinary=ordinary,stationary_dark=field,satellite_direct=0. if policy=="isolated" else direct,
                                       induced_m0=sat if policy=="direct_plus_m0" else 0.,rotating_wave_included=False,
                                       total=val,low=lower,high=upper,inside=lower<=val<=upper,missing=(lower-val if val<lower else upper-val if val>upper else 0.)))
    table("common-sky"+suffix,bounds);table("changed-satellite"+suffix,delta)
    gaps=[]
    for occ in (0,1):
        for model in ("MTS","NFW"):
            for hist in prep.ms.MODELS:
                for frame in ("site_minus_point","archive_accelerating"):
                    selected=[v for v in bounds if (v["occupation"],v["model"],v["history"],v["frame"],v["policy"],v["t"])==(occ,model,hist,frame,"direct_plus_m0",1)]
                    for rad in (6.,8.3):
                        for comp in ("radial","polar"):
                            sign=-1 if comp=="polar" else 1
                            north,south=sorted([v for v in selected if v["R"]==rad and v["component"]==comp],key=lambda v:-v["z"])
                            lo,hi=north["low"]-north["total"],north["high"]-north["total"]
                            slo,shi=sorted(sign*(south[k]-south["total"]) for k in ("low","high"))
                            gaps.append(dict(occupation=occ,model=model,history=hist,frame=frame,R=rad,component=comp,
                                             even_required_low=(lo+slo)/2,even_required_high=(hi+shi)/2,
                                             if_only_even_low=max(lo,slo),if_only_even_high=min(hi,shi)))
    table("remaining-even-force"+suffix,gaps)
if __name__=="__main__":run(int(sys.argv[1]) if len(sys.argv)>1 else 64)
