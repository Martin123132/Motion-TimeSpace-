from pathlib import Path
import sys
import csv
import io
import json
HERE=Path(__file__).resolve().parent
PARENT=HERE.parent/"mts-extended-bar-redistribution-20261120"
sys.dont_write_bytecode=True
sys.path.insert(0,str(PARENT))
import long_source as ls
from long_source import np, G, UNIT, pi, quad, supply, census, zshape
from numpy.polynomial.legendre import legvander
from scipy.special import ellipkm1,ellipe
BAR=ls.BAR
PIN="0080729d5848aa70f85f8956a672c086f684c10132d8c36aa9dc7454f9c9c171"
def guard():
    ls.guard()
    assert ls.old.digest(PARENT/"seal.json")==PIN and not (HERE/"STOP-REQUESTED").exists()
def write(name,data):
    guard()
    if isinstance(data,str):data=data.encode()
    dest=HERE/name
    if dest.exists():
        assert dest.read_bytes()==data,name
    else:
        with dest.open("xb") as stream:stream.write(data)
def table(name,rows):
    buf=io.StringIO(newline="")
    writer=csv.DictWriter(buf,rows[0].keys(),lineterminator="\n")
    writer.writeheader();writer.writerows(rows)
    write(name+".csv",buf.getvalue())
def packet(name,**values):
    buf=io.BytesIO();np.savez_compressed(buf,**values);write(name+".npz",buf.getvalue())
def read(name):
    return ls.old.read(HERE,name)
def split_edges(extra=()):
    return np.unique(np.clip(np.r_[np.arange(0,30.01,.5),census().stars.bgrid,census().stars.knots,extra],0,30))
def columns(rr):
    return .4*np.stack([ls.avg(key,0,rr,128) for key in ls.S22],axis=-1)
def vertical(zs,mass,share):
    new=np.stack([zshape(key,zs) for key in ls.S22],axis=1)@mass
    donor=np.stack([census().starshape(zs,idx) for idx in range(4)],axis=1)@share
    return new-mass.sum()*donor
def direct(radius,height,order):
    if radius==0:raise ValueError("use saved independent axial reference")
    offsets=np.array([0,.0002,.001,.005,.03,.12,.5,1,2])
    rr,wr=quad(split_edges(np.r_[radius+offsets,radius-offsets]),order)
    mass=columns(rr);shares=supply(rr);shares/=shares.sum(axis=1)[:,None]
    acc=np.zeros(3)
    for s,w,mm,frac in zip(rr,wr,mass,shares):
        if mm.sum()==0:continue
        dz=abs(s-radius)
        edges=np.unique(np.clip(np.r_[0,census().stars.axis,3.5,4,5,6,8,12,16,24,40,60,80,
                                      height+dz*np.array([-4.,-1.,-.25,0,.25,1.,4.])],0,80))
        zs,wz=quad(edges,max(5,order//2))
        den=vertical(zs,mm,frac);coeff=2*pi*s*w*wz*den
        for diff in (zs-height,-zs-height):
            lo=(radius-s)**2+diff**2;hi=(radius+s)**2+diff**2
            first=ellipkm1(lo/hi);second=ellipe(1-lo/hi)
            weight=G*coeff/(pi*np.sqrt(hi))
            acc+=np.array([-2*weight@first,-weight@(first+(radius**2-s*s-diff*diff)*second/lo)/radius,2*weight@(diff*second/lo)])
    return acc
def bank(order):
    guard()
    with np.load(BAR/"ground-fine-1-0.npz") as state:
        probes=state["rad"]*state["length"]
    sites=[(6.,1.5),(8.3,1.5),(17.58,0.),(0.,50.),(0.,100.),(0.,200.)]
    radii=np.unique(np.r_[probes,[np.hypot(r,z) for r,z in sites]])
    degrees=np.arange(0,69,2);size=len(radii)
    interior=np.zeros((size+1,len(degrees)));exterior=np.zeros_like(interior)
    rr,wr=quad(split_edges(radii[radii<30]),order)
    mass=columns(rr);shares=supply(rr);shares/=shares.sum(axis=1)[:,None]
    moments=np.zeros(3)
    for s,w,mm,frac in zip(rr,wr,mass,shares):
        if mm.sum()==0:continue
        shells=radii[(radii>s)&(radii<np.hypot(s,80))]
        edges=np.unique(np.r_[0,census().stars.axis,3.5,4,5,6,8,12,16,24,40,60,80,np.sqrt((shells-s)*(shells+s))])
        zs,wz=quad(edges,order)
        dist=np.hypot(s,zs)
        dm=4*pi*s*w*wz*vertical(zs,mm,frac)
        weighted=dm[:,None]*legvander(zs/dist,68)[:,::2]
        moments+=np.array([dm.sum(),dm@(zs**2-.5*s*s),dm@(zs**4-3*s*s*zs**2+.375*s**4)])
        which=np.searchsorted(radii,dist)
        groups=np.r_[0,np.flatnonzero(np.diff(which))+1];inds=which[groups]
        high=radii[np.minimum(which,size-1)]
        low=radii[np.maximum(which-1,0)]
        inner=weighted*(np.minimum(1,dist/high)[:,None]**degrees)/high[:,None]
        outer=weighted*(np.minimum(1,low/dist)[:,None]**degrees)/dist[:,None]
        interior[inds]+=np.add.reduceat(inner,groups,axis=0)
        exterior[(inds-1)%(size+1)]+=np.add.reduceat(outer,groups,axis=0)
    interior=interior[:-1];exterior=exterior[:-1]
    for idx in range(1,size):
        interior[idx]+=interior[idx-1]*(radii[idx-1]/radii[idx])**(degrees+1)
    for idx in range(size-2,-1,-1):
        exterior[idx]+=exterior[idx+1]*(radii[idx]/radii[idx+1])**degrees
    coeff=-G*(interior+exterior)
    derivative=G*(interior*(degrees+1)-exterior*degrees)/radii[:,None]
    packet(f"signed-bank-{order}",radii=radii,degrees=degrees,coeff=coeff,derivative=derivative,moments=moments)
    rows=[]
    for radius,height in sites:
        dist=np.hypot(radius,height);idx=int(np.searchsorted(radii,dist));mu=height/dist
        polys=legvander([mu],68)[0];harm=polys[::2];av=derivative[idx]@harm
        tilt=0.
        if radius>0:
            dleg=np.r_[0,degrees[1:]*(polys[1::2]-mu*harm[1:])/(1-mu**2)]
            tilt=coeff[idx]@dleg*radius/dist**2
        rows.append(dict(R=radius,z=height,potential=coeff[idx]@harm,radial=-av*UNIT,polar=tilt*UNIT))
    table(f"bank-sites-{order}",rows)
    print(order,moments,flush=True)
if __name__=="__main__":
    for item in sys.argv[1:]:
        if item=="rings":
            rows=[]
            for order in [10,20]:
                for radius,height in [(6.,1.5),(8.3,1.5),(17.58,0.)]:
                    pot,aR,az=direct(radius,height,order);dist=np.hypot(radius,height)
                    rows.append(dict(order=order,R=radius,z=height,potential=pot,radial=UNIT*(aR*radius+az*height)/dist,polar=UNIT*(aR*height-az*radius)/dist))
            table("independent-rings",rows)
        else:bank(int(item))
