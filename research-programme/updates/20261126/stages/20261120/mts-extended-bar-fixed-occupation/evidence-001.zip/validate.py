from branch_state import *
from collections import defaultdict
import hashlib

def relative(first,second):
    return abs(first-second)/abs(second)
def check():
    guard()
    receipts={}
    for root in (PARENT,BAR):
        receipt=json.loads((root/"seal.json").read_bytes())["files"]
        for name,hashed in receipt.items():
            assert ls.old.digest(root/name)==hashed, name
        receipts[root.name]=len(receipt)
    history_hashes=json.loads((cr.AXIS/"seal.json").read_bytes())["files"]
    for hist in prep.ms.MODELS:
        name=cr.name(hist,320,40,36,16)
        assert ls.old.digest(cr.AXIS/name)==history_hashes[name]
    receipts["sealed_LMC_inputs"]=len(prep.ms.MODELS)
    for path in sorted(HERE.glob("*.csv")):
        with path.open(newline="") as stream:
            data=list(csv.reader(stream))
            assert len(data)>1 and len(set(data[0]))==len(data[0]) and all(len(v)==len(data[0]) for v in data),path.name
    with np.load(HERE/"signed-bank-8.npz") as bank:
        moments=bank["moments"].tolist()
        saved=[v for v in ls.old.read(PARENT,"mean-source-far-prediction") if v["group"]=="S22" and v["region"]=="whole"]
        assert abs(moments[0])<1e-4 and max(relative(moments[i],float(saved[0][key])) for i,key in [(1,"delta_Q2"),(2,"delta_Q4")])<2e-5
        for old in saved:
            site=next(r for r in read("bank-sites-8") if float(r["z"])==float(old["axis_kpc"]))
            assert relative(float(site["potential"]),float(old["actual_potential"]))<2e-5
    def out(n):return {r["component"]:float(r["max_absolute"]) for r in read(n)}
    audit=[]
    for occ in (0,1):
        def endpoint(stem):return next(v for v in read("equilibria-"+stem) if float(v["t"])==1)
        coarse,four,eight=[endpoint(f"{level}-o{occ}-q{order}") for level,order in [("coarse-0",4),("fine-1",4),("fine-1",8)]]
        def delta(rec,k):return float(rec["change_"+k])
        def rel4(left,right):return {k:relative(delta(left,k),delta(right,k)) for k in NAMES[:4]}
        def satellite(mesh,order,keep,steps):
            return {s["history"]:np.array([float(s[k]) for k in NAMES[:4]]) for s in read(f"satellite-{mesh}-o{occ}-q{order}-k{keep}") if s["substeps"]==str(steps)}
        def compare(left,right):
            pairs=[(left[key],right[key]) for key in right]
            return dict(absolute=max(float(abs(a-b).max()) for a,b in pairs),relative=max(float(abs((a-b)/b).max()) for a,b in pairs))
        fine= satellite(1,8,96,16)
        tests=read(f"increment-fine-1-o{occ}-q8")
        slopes=max(float(t["slope_relative"]) for t in tests)
        curves=max(float(t["curvature_relative"]) for t in tests)
        assert max(slopes,curves)<2e-5
        ctrl=read(f"complex-controls-1-o{occ}")+read(f"complex-controls-0-o{occ}")
        assert len(ctrl)==18
        caps=out(f"nonlinear-readouts-1-o{occ}")
        for mesh in (0,1):
            trap=read(f"trap-{mesh}-o{occ}")[0]
            assert trap["certified"]=="True" and float(trap["lower"])>1.15*float(trap["work"])
        maxwave=float(eight["relative_N"])
        assert abs(maxwave)<2e-13 and float(eight["stationarity"])<5e-10
        coupled=[v for v in read("remaining-even-force-k96") if v["model"]=="MTS" and int(v["occupation"])==occ and v["R"]=="6.0"]
        pol_gap=min(float(v["even_required_low"]) for v in coupled if v["component"]=="polar")
        rad_gap=min(-float(v["even_required_high"]) for v in coupled if v["component"]=="radial")
        assert caps["inner_polar"]<pol_gap/700 and caps["inner_radial"]<rad_gap/700
        audit.append(dict(occupation=occ,mass_msun=float(eight["mass_msun"]),speed_kms=float(eight["speed"]),wave_change={k:delta(eight,k) for k in NAMES[:4]},source_refinement=rel4(four,eight),
                    angular_refinement=rel4(coarse,four),satellite_timing=compare(satellite(1,8,96,8),fine),satellite_basis_64_to_96=compare(satellite(1,8,64,16),fine),
                    satellite_combined_coarse_to_fine=compare(satellite(0,4,40,16),fine),max_inc_slope=slopes,max_inc_curvature=curves,
                    max_raw_curvature_error=max(float(v["curvature_relative"]) for v in read(f"derivatives-fine-1-o{occ}-q8")),
                    max_complex_identity=max(float(t["identity_error"]) for t in ctrl),nonlinear_caps=caps,remaining_inner_even_polar=pol_gap,remaining_inward_radial=rad_gap))
    panels=defaultdict(list)
    for label in ["common-sky","common-sky-k96"]:
        rows=read(label)
        for row in rows:
            key=tuple(row[k] for k in "t occupation history model frame policy".split())
            panels[(label,)+key].append(row)
    assert len(panels)==576
    for key,subset in panels.items():
        assert len(subset)==8
        if key[-1]=="direct_plus_m0":
            assert {(float(v["R"]),float(v["z"]),v["component"]) for v in subset if v["inside"]=="True"}=={(8.3,1.5,"polar"),(8.3,-1.5,"polar")}
    summary=dict(parents=receipts,signed_moments=moments,total_eight_band_panels_per_readout=len(panels)//2,audit=audit)
    write("audit.json",json.dumps(summary,sort_keys=True,indent=2)+"\n")
    return summary
def inventory():
    return {p.name:ls.old.digest(p) for p in sorted(HERE.iterdir()) if p.is_file() and p.name!="seal.json"}
if __name__=="__main__":
    check()
    if "--seal" in sys.argv:
        write("seal.json",json.dumps(dict(files=inventory()),sort_keys=True,indent=2)+"\n")
    if (HERE/"seal.json").exists():
        assert json.loads((HERE/"seal.json").read_bytes())["files"]==inventory()
        print(len(inventory()),ls.old.digest(HERE/"seal.json"))
