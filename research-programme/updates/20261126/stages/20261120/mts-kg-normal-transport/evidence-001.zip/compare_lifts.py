"""Match signed host, unhosted, pressure on/off and ordinary controls before comparing."""
from owner import *
import math


def read(path):
    with path.open(newline="") as stream:return list(csv.DictReader(stream))


def main():
    rows=[];diagnostics=[]
    for rate in (4,5):
        tangent={(int(row["flag"]),int(row["seed"]),row["config"],float(row["radius"])):float(row["ruler_delta"])
                 for row in read(HOME/f"tangent-h{rate}.csv")}
        absolute={(int(row["flag"]),int(row["seed"]),row["config"],float(row["radius"])):float(row["ruler"])
                  for row in read(HOME/f"coupled-h{rate}.csv")}
        parent={(int(row["seed"]),row["branch"],float(row["proper_comoving"])):float(row["ruler_tide"])
                for row in read(check(f"heavy-h{rate}-ruler.csv")) if row["config"]=="reference"}
        cold={(int(row["seed"]),row["branch"],float(row["proper_comoving"])):float(row["ruler_tide"])
                for row in read(check(f"cold-h{rate}-ruler.csv")) if row["config"]=="reference"}
        retained={(int(row["seed"]),float(row["radius"])):row for row in read(check("proper-distance-comparison.csv"))
                if row["config"]=="reference" and row["model"]=="heavy" and int(row["rate"])==rate}
        for flag,seed,name,radius in tangent:
            delta=tangent[flag,seed,name,radius]
            def val(mode):return absolute[flag,seed,mode,radius]
            original=val("leading")
            assert abs(original-parent[seed,("on","off_same_lift")[flag],radius])<=1e-20*max(1,abs(original))
            real=val(dict(all="coupled",current="current_only",stress_energy="stress_energy_only")[name])-original
            plus=absolute.get((flag,seed,"diagnostic_gain_32",radius))
            minus=absolute.get((flag,seed,"diagnostic_gain_-32",radius))
            diagnostics.append(dict(rate=rate,flag=flag,seed=seed,radius=radius,source=name,tangent=delta,
                          direct=real,direct_minus_tangent=real-delta,
                          gained=(plus-original)/32 if name=="all" else "",
                          central=(plus-minus)/64 if name=="all" and minus is not None else ""))
        for seed,radius in retained:
            if (0,seed,"all",radius) not in tangent:continue
            def host(flag,name):
                return tangent[flag,seed,name,radius]-tangent[flag,0,name,radius]
            old=float(retained[seed,radius]["tide"]);newton=float(retained[seed,radius]["newton"])
            off=absolute[1,seed,"dust_off",radius]-absolute[1,0,"dust_off",radius]
            switch=(absolute[0,seed,"leading",radius]-absolute[0,0,"leading",radius])-off
            assert math.isclose(old,switch,rel_tol=2e-5,abs_tol=0)
            assert cold[seed,"on",radius]==cold[seed,"off",radius] and cold[0,"on",radius]==cold[0,"off",radius]
            total=host(0,"all");current=host(0,"current");energy=host(0,"stress_energy")
            assert abs(total-current-energy)<1e-9*max(abs(total),abs(current),abs(energy))
            rows.append(dict(rate=rate,seed=seed,radius=radius,newton=newton,prior_gr=old,prior_minus_newton=old-newton,
                added_tide=total,from_current=current,from_stress_energy=energy,
                on_off_identical_quadrature_correction=total-host(1,"all"),new_gr=old+total,
                added_over_old=total/old,added_over_prior_difference=total/(old-newton),cold_switch=0.))
    table("paired-host-tides.csv",rows);table("direct-versus-tangent.csv",diagnostics)


if __name__=="__main__":main()
