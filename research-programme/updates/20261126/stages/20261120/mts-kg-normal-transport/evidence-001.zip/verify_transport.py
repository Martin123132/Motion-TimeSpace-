"""Read numerical products and retain failures; seal without overwriting anything."""
from compare_lifts import read
from owner import *
import math
import re


def keyed(filename,keys,column):
    rows=read(HOME/filename)
    mapped={tuple(row[k] for k in keys):float(row[column]) for row in rows}
    assert len(mapped)==len(rows)
    return mapped


def verify():
    assert all(sha(PARENT/name)==digest for name,digest in files.items())
    tolerance=2e-5
    worst_finite=0.;worst_host=0.;worst_hist=0.;raw_violations=0;raw_total=0
    for mesh in (4,5):
        key=("flag","seed","radius")
        direct=keyed(f"finite-increment-h{mesh}.csv",key,"coordinate_increment")
        tangent={tuple(r[k] for k in key):float(r["delta_fixed_coordinate"]) for r in read(HOME/f"tangent-h{mesh}.csv") if r["config"]=="all"}
        assert len(direct)==len(tangent)==18
        for item,value in tangent.items():
            flag,seed,radius=item
            err=abs(direct[item]/value-1)
            worst_finite=max(worst_finite,err)
            if seed!="0":
                ref=(flag,"0",radius)
                err=abs((direct[item]-direct[ref])/(value-tangent[ref])-1)
                worst_host=max(worst_host,err)
        history=read(HOME/f"history-gradient-h{mesh}.csv")
        assert len(history)==80
        worst_hist=max(worst_hist,max(abs(float(r["relative"])) for r in history))
        assert max(float(r["on_peak"]) for r in read(HOME/f"previous-epoch-h{mesh}.csv"))<tolerance
        for row in read(HOME/"direct-versus-tangent.csv"):
            if int(row["rate"])!=mesh or row["source"]!="all":continue
            raw_total+=1
            raw_violations+=abs(float(row["direct"])/float(row["tangent"])-1)>=tolerance
        assert all(float(r["change"])<2e-9 for key0 in range(2) for seed0 in ("0","1","-1")
             for r in [next(row for row in reversed(read(HOME/f"iteration-h{mesh}.csv")) if row["flag"]==str(key0) and row["seed"]==seed0)])
    assert max(worst_hist,worst_finite,worst_host)<tolerance
    values=keyed("paired-host-tides.csv",("rate","seed","radius"),"added_tide")
    mesh_effect=max(abs(val/values["5",seed,radius]-1) for (rate,seed,radius),val in values.items() if rate=="4")
    assert mesh_effect<tolerance and len(values)==12
    real=read(HOME/"independent-real-phase-tensor.csv")
    phase_err=max(abs(float(r["relative"])) for r in real)
    assert len(real)==96 and phase_err<1e-10
    temp=read(HOME/"time-dependent-KG-modes.csv")
    assert len(temp)==12 and all(float(r["max_step_difference"])<tolerance*abs(float(r["initial_time_term"])) for r in temp)
    assert all(float(r["max_residual_including_time_derivative"])<tolerance*abs(float(r["initial_time_term"])) for r in temp if r["initial_drift_order"]=="1")
    packets=read(HOME/"exact-travelling-packets.csv")
    assert len(packets)==9 and all(float(r["next_error"])<=float(r["sixth_order_bound"]) for r in packets)
    for doc in ("RESULTS.md","DERIVATION.md","REPLAY.md"):
        for dest in re.findall(r"\]\(([^)]+)\)",(HOME/doc).read_text(encoding="utf8")):
            assert dest.startswith("https://") or (HOME/dest).exists(),dest
    assert not any(HOME.glob("*.partial")) and not (HOME/"__pycache__").exists()
    rows={p.name:len(read(p)) for p in sorted(HOME.glob("*.csv"))}
    content={p.name:sha(p) for p in sorted(HOME.iterdir()) if p.is_file() and p.name!="seal.json"}
    report=dict(files=content,rows=rows,parent_seal=SEAL,local_files=len(content),parent_files=len(files),
        max_coordinate_increment_disagreement=worst_finite,max_host_coordinate_increment_disagreement=worst_host,
        max_mesh_change_of_proper_increment=mesh_effect,max_weak_history_error=worst_hist,max_real_tensor_error=phase_err,
        unresolved_subtractions=raw_violations,direct_comparisons=raw_total,
        rejected_amplifications={str(i):len(json.loads((HOME/f"rejected-amplifications-h{i}.json").read_bytes())) for i in (4,5)})
    put("seal.json",(json.dumps(report,sort_keys=True,indent=2,allow_nan=False)+"\n").encode())
    print("Verified",len(content),"files;",sum(rows.values()),"rows; host/mesh/weak-history",worst_host,mesh_effect,worst_hist,
          "ordinary subtraction fails",raw_violations,"of",raw_total,"SHA",sha(HOME/"seal.json"))


if __name__=="__main__":verify()
