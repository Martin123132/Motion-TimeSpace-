"""Frozen-spatial next term, finite-increment solve and exact independent KG fixtures."""
from states import *
from normal_graph import homogeneous,normal_data,Sources
from pressure import pressure
from finite_increment import check_increment
from proper_probe import PROBES
from numpy.polynomial.polynomial import polyfit
import mpmath as mp


def spatial_term(obj,graph,mu,mean,radius,step):
    grid=obj.grid
    offset=np.arange(-3,4,dtype=float)
    maps=Sources(grid,dict(wr=2*graph[0],wi=2*(graph[1]+1.5*mean["hubble"]/mu)),obj.fq["other"])
    def derivatives(key):
        data=[maps.at(key,radius+offset_i*step) for offset_i in offset]
        coeff=polyfit(offset,data,6)
        value=data[3]
        radial=coeff[1]/step
        laplacian=2*coeff[2]/step**2+2*radial/radius-Z*6*angular(value)/radius**2
        return value,radial,laplacian
    real,dr,lapr=derivatives("wr");imag,di,lapi=derivatives("wi")
    reference=shape(obj.bg,np.asarray(radius))
    element,position,read=grid.probe(radius)
    matter=material(reference,radius,lambda array:read(array)[:2],obj.state,obj.flag)
    idx=obj.j
    number=jet(matter["n"][idx],matter["D"][idx])
    grad=jet(matter["g"][idx],matter["Dr"][idx])
    momentum=jet(matter["p"][idx],matter["P"][idx])
    sphere,der0,unused=read(obj.f0);angular2,der2,unused=read(obj.f2)
    conformal=1+jet(sphere,angular2)
    gradient_factor=grad/number-4*jet(der0,der2)/conformal
    scale=1/(mu**2*conformal**4)
    lap2_real=real**2-imag**2-scale*(lapr+gradient_factor*dr-2*mu*momentum*di)
    lap2_imag=2*real*imag-scale*(lapi+gradient_factor*di+2*mu*momentum*dr)
    return real/2,imag/2,-lap2_real/8,-lap2_imag/8


def fixtures():
    mp.mp.dps=65
    rows=[]
    for ratio in (".0001",".003",".08"):
        scale=mp.mpf(ratio);freq=[scale,-scale*mp.mpf(".31")]
        for angle in ("0.2","1.7","2.9"):
            rays=[1,mp.mpf(".38")*mp.exp(mp.j*mp.mpf(angle))]
            value=sum(rays)
            dlog=sum(mp.j*k*z for k,z in zip(freq,rays))/value
            ddlog=sum(-k**2*z for k,z in zip(freq,rays))/value-dlog**2
            wreal=dlog.imag**2-ddlog.real-dlog.real**2
            wimag=-ddlog.imag-2*dlog.real*dlog.imag
            leading=(wreal+mp.j*wimag)/2
            fourth=-sum(k**4*z for k,z in zip(freq,rays))/(8*value)
            exact=sum((mp.sqrt(1+k**2)-1)*z for k,z in zip(freq,rays))/value
            bound=sum(abs(z)*k**6 for k,z in zip(freq,rays))/(16*abs(value))
            assert abs(leading-sum(k*k*z for k,z in zip(freq,rays))/(2*value))<mp.mpf("1e-60")
            assert abs(exact-leading-fourth)<=bound
            rows.append(dict(k_over_mass=ratio,phase=angle,frequency=float(exact.real),drift=float(exact.imag),
                             leading_error=float(abs(exact-leading)),next_error=float(abs(exact-leading-fourth)),
                             sixth_order_bound=float(bound)))
    table("exact-travelling-packets.csv",rows)


def main(rate):
    sim=BalancedNative("heavy",120,120*rate,False,"native36",SPAN*DLOG)
    rows=[];finite=[]
    for flag in (0,1):
        bg,pressure0,unused=pressure(flag)
        mu=bg["a"]*sim.patch.p.mass
        mean=homogeneous(bg,bg["rh"][sim.patch.j],mu,pressure0)
        for seed in (0,1,-1):
            state,grid,samples,supply=input_pack(sim,rate,seed,flag,bg,pressure0)
            initial=Slice(sim,grid,bg,samples,state,flag,True,"fixed",0,"matched")
            graph,fields=normal_data(initial,supply,mean)
            for step in range(8):
                hook=Sources(grid,fields,samples[0]["other"])
                updated=Slice(sim,grid,{**bg,"H":mean["hubble"]},samples,state,flag,True,"fixed",0,"matched",hook)
                next_graph,next_fields=normal_data(updated,supply,mean,graph)
                error=max(np.max(abs(next_fields[key]-value))/max(1e-50,np.max(abs(next_fields[key]))) for key,value in fields.items())
                if error<2e-9:break
                fields,graph=next_fields,next_graph
            else:raise ArithmeticError("outer iteration")
            for val in check_increment(initial,hook,mean["change_h"],PROBES[:3]):
                finite.append(dict(flag=flag,seed=seed,**val))
            for radius in PROBES[:3]:
                for width in (.08,.04,.02):
                    a,b,c,d=spatial_term(updated,graph,mu,mean,radius,width)
                    for part,extract in (("sphere",np.real),("quadrupole",angular)):
                        rows.append(dict(flag=flag,seed=seed,radius=radius,width=width,part=part,frequency=extract(a),
                             spatial_drift=extract(b),next_frequency_frozen=extract(c),next_drift_frozen=extract(d)))
            print("independent finite increment",rate,flag,seed,flush=True)
    table(f"finite-increment-h{rate}.csv",finite)
    table(f"next-spatial-h{rate}.csv",rows)
    fixtures()


if __name__=="__main__":main(int(sys.argv[1]))
