"""Differentiate the actual two constraints; solve for the small signal itself."""
from states import np, jet, angular, Z
from constraint import strain
from proper_probe import Ruler
from normal_graph import Sources


def variation(obj, lift, change_h, probes):
    grid=obj.grid
    radius=grid.points
    matter=obj.m
    fields=lift.fields
    hubble=obj.bg["H"]
    shape0, slope0=grid.evaluate(obj.f0)
    shape2, slope2=grid.evaluate(obj.f2)
    conformal=1+jet(shape0,shape2)
    grad=jet(slope0,slope2)
    shear=jet(obj.b0,obj.b2)
    rhs=jet(obj.hsource(0,shape0,slope0),obj.hsource(2,shape2,slope2))
    number=jet(matter["n"],matter["D"])
    momentum=jet(matter["p"],matter["P"])
    gradient=jet(matter["g"],matter["Dr"])
    energy_u=0.; energy_grad=0.; stress_u=0.; stress_grad=0.
    for idx,weight in enumerate(obj.rh):
        mass=weight*number[idx]
        kin=momentum[idx]**2/conformal**4
        if idx==obj.j:
            log_grad=gradient[idx]/number[idx]-6*grad/conformal
            moment=momentum[idx]**2+obj.eps*log_grad**2
            energy_u+=mass*(-6/conformal**7-5*moment/conformal**11+6*obj.eps*log_grad*grad/conformal**12)
            energy_grad=-6*mass*obj.eps*log_grad/conformal**11
            stress_u+=(2/3)*mass*(-10*moment/conformal**11+12*obj.eps*log_grad*grad/conformal**12)
            stress_grad=-8*mass*obj.eps*log_grad/conformal**11
        else:
            gamma=np.sqrt(1+kin)
            energy_u+=mass/conformal**7*(-6*gamma-2*kin/gamma)
            stress_u+=(2/3)*mass*momentum[idx]**2/(gamma*conformal**11)*(-10+2*kin/gamma**2)
    deriv_u=5*rhs/conformal-36*shear**2/(16*conformal**8)+conformal**5*energy_u/4
    deriv_grad=conformal**5*energy_grad/4
    delta_b0=grid.integral(fields["clock_j0"]*radius**3)[1]/radius**3
    delta_w=grid.momentum(fields["jr"],fields["jt"],0.,0.)
    val,slope=grid.evaluate(delta_w)
    delta_b=jet(delta_b0,strain(radius,(*val,*slope))[0])
    explicit=3*shear*delta_b/(8*conformal**7)+conformal**5*jet(fields["clock_e0"],fields["other"])/4
    potential0=np.zeros(grid.size);potential2=potential0.copy()
    for iteration in range(25):
        val0,der0=grid.evaluate(potential0)
        val2,der2=grid.evaluate(potential2)
        du=jet(val0,val2);dr=jet(der0,der2)
        delta_rhs=explicit+deriv_u*du+deriv_grad*dr
        next0=grid.solve(0,delta_rhs.real,"matched",0.)
        next2=grid.solve(2,angular(delta_rhs),"matched",0.)
        residual=max(np.max(abs(n-o))/max(1e-50,np.max(abs(n))) for n,o in ((next0,potential0),(next2,potential2)))
        if residual<1e-10:break
        potential0,potential2=next0,next2
    else:raise RuntimeError(("tangent did not converge",residual))
    htf=-2*rhs/3-2*grad/radius+Z*6*shape2/radius**2
    delta_htf=-2*delta_rhs/3-2*dr/radius+Z*6*val2/radius**2
    delta_tide=(2*delta_htf/conformal**5-10*htf*du/conformal**6-8*grad*dr/conformal**6
                +24*grad**2*du/conformal**7+(change_h*shear+hubble*delta_b)/conformal**6
                -6*hubble*shear*du/conformal**7+shear*delta_b/conformal**12-6*shear**2*du/conformal**13
                +stress_u*du+stress_grad*dr+jet(fields["monostress"],fields["stress"]))
    maps=Sources(grid,dict(monopole=delta_tide.real,tide=angular(delta_tide)),obj.fq["other"])
    base_ruler=Ruler(obj)
    integrands=(2*conformal.real*du.real,2*(du.real*shape2+conformal.real*val2))
    accumulated=[grid.integral(field)[0] for field in integrands]
    results=[]
    for target in probes:
        output=base_ruler.read(target)
        point=output["r0"];shift=output["radial_shift"]
        element,position,read=grid.probe(point)
        radial,first,_=read(obj.f0);u0=1+radial
        x0=read(obj.f2)[0];v0=read(potential0)[0]
        ints=[(data[element]+(grid.prefix_weights([position])@field[element]).item()) for data,field in zip(accumulated,integrands)]
        point_shift=-ints[0]/u0**2
        angular_shift=-(ints[1]+2*u0*x0*point_shift)/u0**2-2*shift*(v0+first*point_shift)/u0
        def ruler_terms(step):
            mono=lambda pos:base_ruler.monopole(pos)[0]
            derivative=(mono(point+step)-mono(point-step))/(2*step)
            second=(mono(point+step)+mono(point-step)-2*mono(point))/step**2
            angular_der=(obj.tidal(point+step)["tide"]-obj.tidal(point-step)["tide"])/(2*step)
            slope=(maps.at("monopole",point+step)-maps.at("monopole",point-step))/(2*step)
            return np.array([point_shift*angular_der,angular_shift*derivative,shift*(slope+point_shift*second)])
        coarse=ruler_terms(grid.h/400);fine=ruler_terms(grid.h/800);ruler=(4*fine-coarse)/3
        coordinate=maps.at("tide",point)
        results.append(dict(radius=target,delta_fixed_coordinate=maps.at("tide",target),at_proper_background=coordinate,
                    delta_r0=point_shift,delta_angular_shift=angular_shift,ruler_shift=sum(ruler),
                    ruler_delta=coordinate+sum(ruler),iteration_residual=residual,
                    derivative_error=max(abs(fine-coarse))/3))
    return results
