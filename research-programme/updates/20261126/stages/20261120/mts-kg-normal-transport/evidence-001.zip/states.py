from owner import *
from inputs import np,AI,DLOG,SPAN,BalancedNative,stage_field,native,response,saved
from constraint import shape,Slice,material,Element
from scipy.interpolate import make_interp_spline
ANG=1e-22
Z=1j*ANG
def jet(base,angular):return base+Z*angular
def angular(val):return np.imag(val)/ANG
def delta_log(val):return np.log1p(val)
def branch_state(sim,rate,sign):
    raw=stage_field(sim,"heavy",sign if sign else 1,rate)
    return raw if sign else tuple(np.zeros_like(arr) for arr in raw)
class Spatial:
    def __init__(self,sim,state,flag):
        m=sim.mesh;j=sim.patch.j
        r=m.r
        density=m.gauges(state[0][0])[0][j]
        phase=m.gauges(state[0][1])[0][j]
        vals=np.stack((density,phase,m.grid(state[1][flag,j]),m.grid(state[2][flag,j])))
        pts=np.r_[-r[24:0:-1],r]
        self.field=make_interp_spline(pts,np.concatenate((vals[:,24:0:-1],vals),axis=1),k=5,axis=1)
    def at(self,r):
        value,first,second=(self.field(r,nu=i) for i in (0,1,2))
        lap=second+2*first/r
        lap[2:]-=6*value[2:]/r**2
        return value,first,lap
def input_pack(sim,rate,sign,flag,bg,P):
    state=branch_state(sim,rate,sign);grid=Element(sim.mesh,120,10 if rate==4 else 12)
    r=grid.points;profile=Spatial(sim,state,flag)
    _,_,lap=profile.at(r)
    j=sim.patch.j
    extra,slope,lapref=sim.operators(r.ravel())
    lnd=lap[2]+((bg["w"]*bg["n"][j])@lapref).reshape(r.shape)
    lphase=lap[3]+((bg["w"]*bg["p"][j])@lapref).reshape(r.shape)
    base=shape(bg,r)
    return state,grid,(base,shape(bg,np.asarray(grid.edge))),dict(ln=jet(lap[0],lnd),lp=jet(lap[1],lphase),P=P,
                spec2=response(bg,r)("spectrace"))
