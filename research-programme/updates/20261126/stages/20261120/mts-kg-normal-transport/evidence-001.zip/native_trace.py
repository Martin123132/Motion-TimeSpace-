"""Reuse original endpoint; sample its physical stress trace on short forward stencils."""
from owner import *
sys.path.insert(0,str(GR))
import switched as native
from switched import np,ctypes
def main(flag):
    model="heavy";boost=6
    _,epochs,_,_,_=native.prepare(model,0)
    origin=native.SPEC/"runs/projection/a225-w6-d8.npz"
    native.checked(origin,native.obj(native.source("runs/heavy/status.json"))["source_hash"])
    params=native.inherited.params_for(origin,background_boost=8.);params.DoLateRadTruncation=False
    bg=native.camb.get_background(params);bg.Params.Accuracy.IntTolBoost=boost;bg.Params.Accuracy.lAccuracyBoost=4
    ob=ctypes.CDLL(str(native.OBSERVER));ptr=ctypes.cast(ob.source_func_,ctypes.c_void_p)
    with np.load(GR/f"serial-heavy-b6-off{flag}.npz") as old:
        t=old["tau"];k=old["k"];archive=old["values"];names=old["names"].tolist()
    with np.load(native.LONG/"heavy-environment.npz") as src:
        x=src["loga"]
    scale=native.AI*np.exp(x[x<=0]);early=epochs[epochs<min(scale)]
    lead=bg.conformal_time(1/np.r_[early,scale[:-1]]-1,tol=1e-10)
    dt=np.arange(1,17)/160.
    eta=np.ascontiguousarray(np.r_[lead,t,t[-1]+dt])
    ctypes.c_int.in_dll(native.lib,"mts_turn_index").value=len(lead)+1
    arr=[];width=len(names)
    for path in sorted((native.SPEC/"runs/heavy").glob("chunk-*.npz")):
        guard()
        with np.load(native.source(path.relative_to(native.SPEC).as_posix())) as group:
            modes=group["modes"][np.isin(group["modes"],k)]
            if not len(modes):continue
            batch=np.unique(np.r_[modes,group["modes"].max()])
        ctypes.c_int.in_dll(native.lib,"mts_remove_pressure").value=flag
        out=np.zeros((len(batch),len(eta),width));ref=lambda n:ctypes.byref(ctypes.c_int(n))
        rc=native.camb.results.CAMB_TimeEvolution(ctypes.byref(bg),ref(len(batch)),batch,ref(len(eta)),eta,ref(width),out,ref(len(native.OBS)),ctypes.byref(ptr))
        assert rc==0 and np.isfinite(out).all()
        seq=out[np.searchsorted(batch,modes),len(lead):]
        np.testing.assert_allclose(seq[:,:len(t)],archive[np.searchsorted(k,modes)],rtol=1e-12,atol=1e-18)
        arr.append(seq[:,len(t)-1:])
    packet(f"trace-heavy-off{flag}.npz",k=k,names=names,dt=np.r_[0.,dt],values=np.concatenate(arr))
if __name__=="__main__":main(int(sys.argv[1]))
