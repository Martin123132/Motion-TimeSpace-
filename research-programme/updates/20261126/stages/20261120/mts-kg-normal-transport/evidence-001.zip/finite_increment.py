"""Finite increments, not finite differencing two already rounded tidal tensors."""
from states import np,jet,angular,Z
from constraint import strain
from normal_graph import Sources
from proper_probe import Ruler


class Pair:
    __array_priority__=1000
    def __init__(self,base,delta=0.):
        self.base=base
        self.delta=delta

    def __add__(self,other):
        other=lift(other)
        return Pair(self.base+other.base,self.delta+other.delta)

    __radd__=__add__

    def __neg__(self):
        return Pair(-self.base,-self.delta)

    def __sub__(self,other):
        return self+(-lift(other))

    def __rsub__(self,other):
        return lift(other)-self

    def __mul__(self,other):
        other=lift(other)
        return Pair(self.base*other.base,self.base*other.delta+self.delta*(other.base+other.delta))

    __rmul__=__mul__

    def __truediv__(self,other):
        other=lift(other)
        quotient=self.base/other.base
        return Pair(quotient,(self.delta-quotient*other.delta)/(other.base+other.delta))

    def __rtruediv__(self,other):
        return lift(other)/self

    def __pow__(self,degree):
        if degree==0:return Pair(1.)
        half=self**(degree//2)
        result=half*half
        return result*self if degree%2 else result

    def sqrt(self):
        root=np.sqrt(self.base)
        return Pair(root,self.delta/(root+np.sqrt(self.base+self.delta)))


def lift(value):
    return value if isinstance(value,Pair) else Pair(value)


def check_increment(base,source,mean_change,probes):
    grid=base.grid;radius=grid.points;matter=base.m
    shape0,grad0=grid.evaluate(base.f0)
    shape2,grad2=grid.evaluate(base.f2)
    mass=jet(matter["n"],matter["D"])
    grad=jet(matter["g"],matter["Dr"])
    phase=jet(matter["p"],matter["P"])
    explicit=source.fields
    extra_momentum=grid.momentum(explicit["jr"],explicit["jt"],0.,0.)
    radial_shear=strain(radius,(*grid.evaluate(extra_momentum)[0],*grid.evaluate(extra_momentum)[1]))[0]
    base_shear=jet(base.b0,base.b2)
    delta_shear=jet(grid.integral(explicit["clock_j0"]*radius**3)[1]/radius**3,radial_shear)
    shear=Pair(base_shear,delta_shear)
    pot0=np.zeros(grid.size);pot2=pot0.copy()
    for iteration in range(25):
        u0,ud0=grid.evaluate(pot0);u2,ud2=grid.evaluate(pot2)
        conformal=Pair(1+jet(shape0,shape2),jet(u0,u2))
        derivative=Pair(jet(grad0,grad2),jet(ud0,ud2))
        excess=Pair(Z*base.fq["other"],jet(explicit["clock_e0"],explicit["other"]))
        stress=Pair(Z*base.fq["stress"],jet(explicit["monostress"],explicit["stress"]))
        for idx,weight in enumerate(base.rh):
            gamma=(1+phase[idx]**2/conformal**4).sqrt()
            if idx==base.j:
                amplitude_grad=grad[idx]/mass[idx]-6*derivative/conformal
                squared=phase[idx]**2+base.eps*amplitude_grad**2
                kinetic=squared/(2*conformal**4)
                anisotropic=squared
            else:
                kinetic=(phase[idx]**2/conformal**4)/(1+gamma)
                anisotropic=phase[idx]**2/gamma
            excess=excess+weight*(mass[idx]*(1+kinetic)/conformal**6-1)
            stress=stress+(2/3)*weight*mass[idx]*anisotropic/conformal**10
        forcing=conformal**5*excess/4+3*shear**2/(16*conformal**7)
        next0=grid.solve(0,forcing.delta.real,"matched",0.)
        next2=grid.solve(2,angular(forcing.delta),"matched",0.)
        error=max(np.max(abs(old-new))/max(1e-55,np.max(abs(new))) for old,new in ((pot0,next0),(pot2,next2)))
        if error<1e-10:break
        pot0,pot2=next0,next2
    else:raise ArithmeticError("finite-increment constraints did not converge")
    angular_shape=Pair(Z*shape2,Z*u2)
    hessian=-2*forcing/3-2*derivative/radius+6*angular_shape/radius**2
    result=(2*hessian/conformal**5-4*derivative**2/conformal**6+Pair(base.bg["H"],mean_change)*shear/conformal**6
            +shear**2/(2*conformal**12)+stress)
    maps=Sources(grid,dict(tide=angular(result.delta)),base.fq["other"])
    return [dict(radius=point,coordinate_increment=maps.at("tide",point),residual=error) for point in probes]
