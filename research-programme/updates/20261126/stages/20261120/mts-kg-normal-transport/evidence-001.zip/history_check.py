"""Rewind the two archived matter histories; do not estimate conjugate data from a force fit."""
from states import *
from scipy.special import spherical_jn
from numpy.polynomial.legendre import leggauss
def rk(sim,state,time,dt):
    shift=lambda change,delta:tuple(val+delta*rhs for val,rhs in zip(state,change))
    a=sim.rates(state,time);b=sim.rates(shift(a,dt/2),time+dt/2)
    c=sim.rates(shift(b,dt/2),time+dt/2);d=sim.rates(shift(c,dt),time+dt)
    return tuple(val+dt*(aa+2*bb+2*cc+dd)/6 for val,aa,bb,cc,dd in zip(state,a,b,c,d))
def read(sim,state,time,r):
    mesh=sim.mesh;p=sim.patch;j=p.j;hub,scale=p.coeff(time)
    val,slope,lap=sim.operators(r)
    ref=sim.ref.solution(time)*sim.ref.weight
    phi=sim.ref.potential(sim.ref.solution(time)[0],time)*sim.ref.weight
    mono,d,v=state
    pm=mesh.solve0(-mesh.lump*(p.p.coeff@mono[0])/(2*scale))
    pq=mesh.potential(np.einsum("s,xsi->xi",p.p.coeff,d)/(2*scale))
    from cloud_stress import sample
    pots=[]
    for pos in r:
        pots.append(jet(sample(mesh,mesh.grid(pm),pos)[0]/pos,sample(mesh,mesh.grid(pq[0]),pos)[0]))
    pot=np.array(pots)+Z*(phi[0]@val)
    raw,der,local_lap=Spatial(sim,state,0).at(r)
    n=jet(1+raw[0],raw[2]+ref[0,0,j]@val);nr=jet(der[0],der[2]+ref[0,0,j]@slope)
    V=jet(raw[1],raw[3]+ref[1,0,j]@val);p=jet(der[1],der[3]+ref[1,0,j]@slope)
    lap_n=jet(local_lap[0],local_lap[2]+ref[0,0,j]@lap)
    lap_v=jet(local_lap[1],local_lap[3]+ref[1,0,j]@lap)
    mu=scale*sim.patch.p.mass
    nu=p*p/2-(lap_n/(2*n)-nr*nr/(4*n**2))/(2*mu**2)
    dilution=-(lap_v+nr*p/n)/(2*mu)
    return np.stack((n,V,pot,nu,dilution))
def main(rate):
    sim=BalancedNative("heavy",120,120*rate,False,"native36",SPAN*DLOG)
    end=SPAN*DLOG;r=np.array([.676538827,1.35307765,2.7061553,6.,12.])
    hub,a=sim.patch.coeff(end);mu=a*sim.patch.p.mass
    result=[];back=[]
    for seed in (1,-1):
        endpoint=branch_state(sim,rate,seed)
        for sub in (1,2):
            dt=DLOG/(176*sub);series=[];state=endpoint
            for step in range(4*sub+1):
                if step%sub==0:series.append(read(sim,state,end-step*dt,r))
                if step<4*sub:state=rk(sim,state,end-step*dt,-dt)
            val=series[0];dn,dv=hub*np.tensordot(np.array([25.,-48.,36.,-16.,3.]),np.array(series)[:,:2]-val[:2],axes=(0,0))/(12*sub*dt)
            from_time=(-(dv+hub*val[1]+val[2]),dn/(2*mu*val[0]))
            for name,v,w in zip(("normal_frequency_excess","normal_drift_minus_background"),val[3:],from_time):
                for ch,func in (("sphere",np.real),("quadrupole",angular)):
                    for rad,sp,tm in zip(r,func(v),func(w)):
                        result.append(dict(rate=rate,seed=seed,substeps=sub,field=name,part=ch,radius=rad,
                                spatial=sp,history=tm,abs_error=tm-sp,relative=tm/sp-1))
            if sub==1:
                for step in range(4,44):state=rk(sim,state,end-step*dt,-dt)
                actual=sim.observe(state,end-44*dt)[6]
                name=f"evolved-heavy-L120-h{rate}-t176.npz" if seed==1 else f"collar-heavy-L120-h{rate}--1.npz"
                with np.load(saved(name)) as data:
                    ix=np.argmin(abs(data["x"]-(end-44*dt)));assert abs(data["x"][ix]-(end-44*dt))<1e-14
                    prev=data["forces"][ix,6] if seed==1 else data["radial"][ix,0]
                for ch in range(3):
                    gap=abs(actual[ch]-prev[ch])
                    back.append(dict(rate=rate,seed=seed,channel=ch,max_abs=np.max(gap),
                            on_peak=np.max(gap)/np.max(abs(prev[ch]))))
    table(f"history-gradient-h{rate}.csv",result);table(f"previous-epoch-h{rate}.csv",back)
if __name__=="__main__":main(int(sys.argv[1]))
