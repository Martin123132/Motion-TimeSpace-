"""Reconstruct real Cauchy data at quadrature nodes and average the actual tensor."""
from states import *
from normal_graph import normal_data,homogeneous,Sources
from pressure import pressure
from scipy.interpolate import BarycentricInterpolator
from proper_probe import PROBES
import mpmath as mp


def main():
    mp.mp.dps=72
    sim=BalancedNative("heavy",120,600,False,"native36",SPAN*DLOG)
    rows=[]
    angles=[(mp.cos(mp.pi*step/8),mp.sin(mp.pi*step/8)) for step in range(16)]
    for flag in (0,1):
        bg,gas_pressure,unused=pressure(flag);mu=bg["a"]*sim.patch.p.mass
        mean=homogeneous(bg,bg["rh"][sim.patch.j],mu,gas_pressure)
        for seed in (1,-1):
            state,grid,samples,supply=input_pack(sim,5,seed,flag,bg,gas_pressure)
            obj=Slice(sim,grid,bg,samples,state,flag,True,"fixed",0,"matched")
            graph,fields=normal_data(obj,supply,mean)
            obj=Slice(sim,grid,{**bg,"H":mean["hubble"]},samples,state,flag,True,"fixed",0,"matched",
                      Sources(grid,fields,samples[0]["other"]))
            graph,fields=normal_data(obj,supply,mean,graph)
            f,fr=grid.evaluate(obj.f0);x,xr=grid.evaluate(obj.f2)
            derivative=BarycentricInterpolator(grid.t,np.eye(len(grid.t)),rng=0).derivative(grid.t)/grid.h
            delta,drift=graph;delta_r=delta@derivative.T
            model=obj.m;idx=obj.j
            for target in PROBES[:3]:
                pos=np.unravel_index(abs(grid.points-target).argmin(),grid.points.shape)
                locate=lambda array:array[pos]
                jets=[jet(1+f,x),jet(fr,xr),jet(model["n"][idx],model["D"][idx]),
                      jet(model["g"][idx],model["Dr"][idx]),jet(model["p"][idx],model["P"][idx]),delta,drift,delta_r]
                params=[(mp.mpf(float(locate(t).real)),mp.mpf(float(locate(angular(t))))) for t in jets]
                radial=mp.mpf(float(grid.points[pos]));p_t=mp.mpf(float(model["Pt"][idx][pos]));rho=mp.mpf(float(obj.rh[idx]))
                def tensor(parameter,which,component):
                    conf,grad_u,numb,grad_n,pvel,delta_v,drift_v,dnu=[a+parameter*b for a,b in params]
                    nu=1+which*delta_v;zeta=which*drift_v
                    grad=(grad_n/numb-6*grad_u/conf-which*dnu/nu)/(2*mu)
                    tilt=(params[2][1]/numb-6*params[0][1]/conf-which*params[5][1]/nu)/(2*mu*radial)
                    pref=rho*numb/nu
                    def one(cs,sn):
                        pi=nu*sn+zeta*cs;pr=grad*cs-pvel*sn;pt=tilt*cs-p_t*sn
                        if component=="energy":return pref*(pi*pi+cs*cs+pr*pr/conf**4)/conf**6
                        if component=="radial_current":return -2*pref*pi*pr
                        if component=="tangent_current":return -2*pref*pi*pt
                        if component=="radial_stress":return (mp.mpf(4)/3)*pref*pr*pr/conf**10
                        return -3*pref*pr*pt/conf**10
                    return mp.fsum(one(cs,sn) for cs,sn in angles)/len(angles)
                for key,component,order in (("clock_e0","energy",0),("other","energy",1),
                        ("clock_j0","radial_current",0),("jr","radial_current",1),("jt","tangent_current",0),
                        ("monostress","radial_stress",0),("stress","radial_stress",1),("stress_cross","cross",0)):
                    diff=lambda value:tensor(value,1,component)-tensor(value,0,component)
                    measured=mp.diff(diff,mp.mpf(0),order)
                    if key=="clock_e0":measured-=mean["excess"]
                    expected=fields[key][pos]
                    rows.append(dict(flag=flag,seed=seed,radius=radial,component=key,graph=expected,phase=float(measured),
                                relative=float((expected-measured)/measured)))
    table("independent-real-phase-tensor.csv",rows)


if __name__=="__main__":main()
