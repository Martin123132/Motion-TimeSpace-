"""Exact second-order KG mode dynamics on the measured homogeneous background."""
from owner import *
import numpy as np
from scipy.interpolate import CubicSpline
from scipy.integrate import solve_ivp


def evolution(times,scale,pressure,kmode,mass,stride,steps,transport):
    alpha=CubicSpline(times[::stride],scale[::stride])
    pbar=CubicSpline(times[::stride],pressure[::stride])
    evals=np.linspace(times[0],times[-1],101)
    def terms(eta):
        am=alpha(eta)*mass
        operator=(kmode**2+.75*pbar(eta))/am**2
        rate=.75*pbar(eta,1)/am**2-2*operator*alpha(eta,1)/alpha(eta)
        root=np.sqrt(1+operator)
        return am,root,rate/(2*root),-rate/(4*am*(1+operator))
    amp=abs(terms(0)[-1])
    def eq(eta,scaled):
        mu,root,slope,unused=terms(eta)
        return 1j*mu*(2*root*scaled+amp*scaled**2)-slope/amp
    initial=1j*terms(0)[-1]/amp if transport else 0j
    solved=solve_ivp(eq,(times[0],times[-1]),[initial],t_eval=evals,method="DOP853",
                rtol=2e-10,atol=1e-12,max_step=(times[-1]-times[0])/steps)
    assert solved.success and len(solved.t)==len(evals)
    return solved.y[0]*amp,terms(evals)[-1],amp


def main():
    mu=float(next(csv.DictReader((HOME/"mean-h5.csv").read_text().splitlines()))["mu"])
    rows=[]
    for flag in (0,1):
        with np.load(HOME/f"trace-heavy-off{flag}.npz") as archive:
            names=archive["names"].tolist();raw=archive["values"];times=archive["dt"];modes=archive["k"]
            scales=raw[:,:,names.index("a")];pressures=raw[:,:,names.index("P")]
            spread=np.max(abs(scales/scales[:1]-1))
        for index,kmode in ((0,0.),(len(modes)//2,modes[len(modes)//2]),(-1,modes[-1])):
            scale=scales[index];pressure=pressures[index]
            for transport in (False,True):
                results=[evolution(times,scale,pressure,kmode,mu/scale[0],stride,steps,transport)
                         for stride,steps in ((1,500),(1,1000),(2,1000))]
                first,second,half=(p[0] for p in results)
                target=results[1][1]
                rows.append(dict(flag=flag,k=kmode,initial_drift_order=int(transport),duration=times[-1],am=mu,
                    max_deviation_from_instant_frequency=max(abs(second)),max_omitting_time_derivative=max(abs(second.imag)),
                    max_residual_including_time_derivative=max(abs(second-1j*target)),initial_time_term=target[0],
                    max_step_difference=max(abs(first-second)),max_history_thinning_difference=max(abs(half-second)),
                    native_scale_relative_spread=spread,identical_native_background_at_1e12=bool(spread<1e-12)))
    table("time-dependent-KG-modes.csv",rows)


if __name__=="__main__":main()
