"""Feed the normal graph through both constraints at fixed occupation and ruler."""
from states import *
from pressure import pressure
from normal_graph import homogeneous, normal_data, Sources
from proper_probe import Ruler, PROBES


class FullRuler(Ruler):
    def monopole(self,radius):
        result=super().monopole(radius)
        clock=self.obj.clock
        if clock is None:return result
        return result+clock.at("monostress",radius)*np.array([1.,.5])


def change_norm(old,new):
    return max(float(np.max(abs(new[key]-val)))/max(1e-50,float(np.max(abs(new[key]))))
               for key,val in old.items())


def main(rate):
    sim=BalancedNative("heavy",120,120*rate,False,"native36",SPAN*DLOG)
    graph_rows=[];slices=[];iterations=[];background=[];rejected=[];linear_rows=[]
    for flag in (0,1):
        reference,gas_pressure,unused=pressure(flag)
        mu=reference["a"]*sim.patch.p.mass
        mean=homogeneous(reference,reference["rh"][sim.patch.j],mu,gas_pressure)
        background.append(dict(flag=flag,mu=mu,reference_H=reference["H"],P=gas_pressure,**mean))
        for seed in (0,1,-1):
            state,grid,samples,supply=input_pack(sim,rate,seed,flag,reference,gas_pressure)
            def solve(lift,mean_change=0.,canon=True):
                return Slice(sim,grid,{**reference,"H":reference["H"]+mean_change},samples,state,flag,canon,"fixed",0,"matched",lift)
            base=solve(None)
            radii=PROBES[:3]
            def save(name,obj):
                reader=FullRuler(obj)
                for radius in radii:
                    r=reader.read(radius);coordinate=obj.tidal(radius)
                    slices.append(dict(flag=flag,seed=seed,config=name,radius=radius,ruler=r["ruler_tide"],
                        coordinate=coordinate["tide"],weyl=r["ruler_weyl"],cross=coordinate["cross"],
                        momentum=coordinate["momentum_r"],source=coordinate["radial_source"],
                        slope_error=r["slope_check"],ruler_error=r["length_residual"]))
            save("leading",base)
            if flag==1:save("dust_off",solve(None,canon=False))
            graph,fields=normal_data(base,supply,mean)
            for step in range(8):
                lift=Sources(grid,fields,samples[0]["other"])
                updated=solve(lift,mean["change_h"])
                graph_new,new_fields=normal_data(updated,supply,mean,graph)
                err=change_norm(fields,new_fields)
                iterations.append(dict(flag=flag,seed=seed,step=step+1,change=err))
                if err<2e-9:break
                graph,fields=graph_new,new_fields
            else:raise ArithmeticError(("unsettled coupling",rate,flag,seed,err))
            save("coupled",updated)
            for name,energy,flux in (("current_only",False,True),("stress_energy_only",True,False)):
                save(name,solve(Sources(grid,fields,samples[0]["other"],energy,flux),mean["change_h"]*energy))
            for gain in (32,-32):
                try:
                    amplified=solve(Sources(grid,fields,samples[0]["other"],gain=gain),gain*mean["change_h"])
                except RuntimeError as exc:
                    if "elliptic fixed point did not settle" not in str(exc):raise
                    rejected.append(dict(flag=flag,seed=seed,gain=gain,reason=str(exc)))
                else:save("diagnostic_gain_"+str(gain),amplified)
            from small_signal import variation
            for unique,energy,flux in (("all",True,True),("current",False,True),("stress_energy",True,False)):
                packet=variation(base,Sources(grid,fields,samples[0]["other"],energy,flux),mean["change_h"]*energy,radii)
                linear_rows.extend(dict(flag=flag,seed=seed,config=unique,**entry) for entry in packet)
            at=Sources(grid,dict(delta=graph[0].real,delta2=angular(graph[0]),drift=graph[1].real,
                drift2=angular(graph[1]),**fields),samples[0]["other"])
            for radius in radii:
                graph_rows.append(dict(flag=flag,seed=seed,radius=radius,**{key:at.at(key,radius) for key in at.fields}))
            print("checked",rate,flag,seed,"outer iterations",step+1,flush=True)
    table(f"coupled-h{rate}.csv",slices)
    table(f"quadratures-h{rate}.csv",graph_rows)
    table(f"iteration-h{rate}.csv",iterations)
    table(f"mean-h{rate}.csv",background)
    table(f"tangent-h{rate}.csv",linear_rows)
    put(f"rejected-amplifications-h{rate}.json",(json.dumps(rejected,indent=2)+"\n").encode())


if __name__=="__main__":main(int(sys.argv[1]))
