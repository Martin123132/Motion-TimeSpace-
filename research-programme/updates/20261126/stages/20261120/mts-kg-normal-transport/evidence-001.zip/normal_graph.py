"""Positive-frequency initial data on the saved Gaussian-normal CMC slice."""
from states import jet, angular, np
from scipy.interpolate import BarycentricInterpolator


def homogeneous(reference, mass_density, mu, pressure):
    hubble = reference["H"]
    delta = 3*pressure/(8*mu**2)
    for iteration in range(6):
        drift = -1.5*hubble/mu
        excess = mass_density*(delta**2+drift**2)/(2*(1+delta))
        change_h = excess/(3*(np.sqrt(reference["H"]**2+excess/3)+reference["H"]))
        hubble = reference["H"]+change_h
        stress = 1.5*mass_density*(2*delta+delta**2+drift**2)/(1+delta)
        delta = (3*pressure+stress)/(8*mu**2)
    return dict(delta=delta, drift=drift, excess=excess, change_h=change_h, hubble=hubble)


def normal_data(obj, supply, mean, previous=None):
    grid, matter = obj.grid, obj.m
    radius = grid.points
    spherical, radial0 = grid.evaluate(obj.f0)
    angular2, radial2 = grid.evaluate(obj.f2)
    conformal = 1+jet(spherical,angular2)
    grad_u = jet(radial0,radial2)
    lap_u = -jet(obj.hsource(0,spherical,radial0),obj.hsource(2,angular2,radial2))
    shear = jet(obj.b0,obj.b2)
    density = jet(matter["n"],matter["D"])
    grad_n = jet(matter["g"],matter["Dr"])
    phase = jet(matter["p"],matter["P"])
    index = obj.j
    number, grad_number, speed = density[index], grad_n[index], phase[index]
    mu = obj.bg["a"]*obj.sim.patch.p.mass
    rho = obj.rh[index]
    epsilon = obj.eps
    stress_energy = np.zeros_like(number)
    for species,weight in enumerate(obj.rh):
        local_volume = np.exp(-6*np.log(conformal))
        contrast = (density[species]-1)*local_volume+np.expm1(-6*np.log(conformal))
        if species==index:
            if previous is None:
                additional = 0.
            else:
                old_delta,old_drift = previous
                additional = (3*old_delta+2*(old_delta**2+old_drift**2))/(1+old_delta)
        else:
            momentum2 = phase[species]**2/conformal**4
            gamma = np.sqrt(1+momentum2)
            additional = momentum2*(1/(1+gamma)+1/gamma)
        stress_energy = stress_energy+weight*(contrast+density[species]*local_volume*additional)
    previous_excess = 0. if previous is None else mean["excess"]
    curvature = ((stress_energy+3*supply["P"]+jet(0,obj.fq["other"] if obj.clock is None else obj.clock.original_other)
                  +jet(0,supply["spec2"])-previous_excess)/4+.75*shear**2/conformal**12)
    log_grad = grad_number/(2*number)-3*grad_u/conformal
    log_lap = (supply["ln"]/number-(grad_number/number)**2)/2-3*(lap_u/conformal-(grad_u/conformal)**2)
    quantum = (log_lap+log_grad**2+2*grad_u*log_grad/conformal)/conformal**4
    delta = (speed**2/conformal**4+(curvature-quantum)/mu**2)/2
    drift = -(3*mean["hubble"]+(supply["lp"]+(grad_number/number-4*grad_u/conformal)*speed)/conformal**4)/(2*mu)
    assert np.all(np.isfinite(delta)) and np.max(abs(delta))<.01 and np.max(abs(drift))<.01
    interpolation = BarycentricInterpolator(grid.t,np.eye(len(grid.t)),rng=0)
    gradient_nu = ((delta @ interpolation.derivative(grid.t).T)/grid.h)/(1+delta)
    gradient_t = angular(delta)/(radius*(1+delta.real))
    old_gradient = 2*log_grad
    old_t = (matter["D"][index]/number.real-6*angular2/conformal.real)/radius
    change_kinetic = (epsilon*(gradient_nu**2-2*old_gradient*gradient_nu)
                      -delta*(speed**2+epsilon*old_gradient**2))/(1+delta)
    amplitude = rho*number/conformal**6
    energy = amplitude*((delta**2+drift**2)/(1+delta)+change_kinetic/conformal**4)/2
    current = -rho*number*drift*(old_gradient-gradient_nu)/(2*mu*(1+delta))
    tangent = -rho*number.real*drift.real*(old_t-gradient_t)/(2*mu*(1+delta.real))
    stress = 2*amplitude*change_kinetic/(3*conformal**4)
    cross_kinetic = (-delta.real*(speed.real*matter["Pt"][index]+epsilon*old_gradient.real*old_t)
                     +epsilon*(-gradient_nu.real*old_t-old_gradient.real*gradient_t+gradient_nu.real*gradient_t))
    cross = -1.5*rho*number.real*cross_kinetic/(conformal.real**10*(1+delta.real))
    fields = dict(clock_e0=energy.real-mean["excess"],other=angular(energy),
                  clock_j0=current.real,jr=angular(current),jt=tangent,
                  stress=angular(stress),stress_cross=cross,monostress=stress.real)
    return (delta,drift),fields


class Sources:
    def __init__(self,grid,fields,original_other,energy=True,flux=True,gain=1.):
        self.original_other = original_other
        self.grid = grid
        self.fields = {key:gain*val*(flux if key in ("clock_j0","jr","jt") else energy) for key,val in fields.items()}
        self.basis = BarycentricInterpolator(grid.t,np.eye(len(grid.t)),rng=0)

    def at(self,key,radius):
        if np.ndim(radius)>0:
            return self.fields[key]
        element,position,unused = self.grid.probe(radius)
        return self.fields[key][element] @ self.basis(position)

    def apply(self,matter,original,radius,read):
        changed = dict(original)
        for key in self.fields:
            if key!="monostress":
                changed[key] = original.get(key,0.)+self.at(key,radius)
        return matter,changed
