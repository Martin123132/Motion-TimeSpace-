from owner import *
from inputs import np,native,response,verified
def pressure(flag):
    with np.load(HOME/f"trace-heavy-off{flag}.npz") as file:
        t=file["dt"];fields=dict(zip(file["names"].tolist(),file["values"].transpose(2,0,1)));k=file["k"][:,None]
    H=fields["H"];a=fields["a"];P=fields["P"];S=fields["R"]+P
    q=fields["Q"]+S*fields["sigma"];psi=(fields["dsigma"]+H*fields["sigma"])/k
    phidot=q/(2*k)-H*psi
    T=1.5*q/k/(k**2+1.5*S);clock=fields["sigma"]/k
    def slope(value,h):
        ix=np.arange(5)*h
        return ((value[:, ix]-value[:,:1])@np.array([-25.,48.,-36.,16.,-3.]))/(12*t[h])
    out=[]
    for stride in (1,2,4):
        h=H[:,0];kcol=k[:,0]
        dP=2*h*P[:,0]+(slope(P,stride)-2*h*P[:,0])
        hp=h*h-S[:,0]/2
        all_newton=slope(q,stride)/kcol+4*h*phidot[:,0]+2*(hp+h*h)*psi[:,0]+2*fields["Pi"][:,0]/3
        cmc=all_newton-(dP-2*h*P[:,0])*T[:,0]
        other=cmc-fields["mts_dp_h"][:,0]
        out.append(3*other)
    bg=native("heavy",flag)
    bg["spectrace"]=out[0]
    bmean=np.mean(P[:,0])
    return bg,bmean,np.stack(out)
def main():
    rows=[]
    for flag in (0,1):
        bg,P,st=pressure(flag)
        for r in (.676538827,1.35307765,2.7061553,6.,12.,18.,24.,36.,48.):
            vals=[]
            for arr in st:vals.append(response({**bg,"spectrace":arr},np.array(r))("spectrace").item())
            rows.append(dict(flag=flag,radius=r,background_P=P,step_00625=vals[0],step_0125=vals[1],step_025=vals[2],
                absolute_spread=np.ptp(vals)))
    table("spectator-pressure.csv",rows)
if __name__=="__main__":main()
