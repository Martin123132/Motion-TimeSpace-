from extended_source import *
def direct(radius,height,order):
    grid=np.r_[ls.edges(ls.S22,0),np.arange(0.,30.5,.5)]
    offsets=np.array([0,.002,.01,.05,.25,.6,1.2])
    rr,wr=quad(np.unique(np.clip(np.r_[grid,radius-offsets,radius+offsets],0,30)),order)
    az=ls.angle("short22");assert az==ls.angle("long22")
    phi,wp=quad(np.unique(np.r_[0.,.0002,.001,.005,.025,.12,az-.03,az,az+.03,.8,pi/2-az,pi/2,pi/2+az,pi-az,pi]),order)
    alpha=pi-az
    total=np.zeros(2)
    for cyl,weight in zip(rr,wr):
        z,wz=quad(np.unique(np.clip(np.r_[0,.02,.1,.3,.7,1.,1.5,2.,3.,5.,9.,18.,40.,80.,
                    height+np.array([-4.,-1.,-.25,0,.25,1.,4.])*abs(cyl-radius)],0,80)),max(4,order//2))
        shape=(cyl-radius)**2+4*cyl*radius*np.sin(phi/2)**2
        kernel=np.zeros((len(phi),len(z)))
        for dz in (z-height,z+height):kernel+=(shape[:,None]+dz**2)**-1.5
        for idx,key in enumerate(ls.S22):
            diff=ls.raw(key,0,cyl,alpha+phi)-ls.raw(key,0,cyl,alpha-phi)
            az_force=(wp*np.sin(phi)*diff) @(kernel @(wz*zshape(key,z)))
            total[idx]+=.4*G*UNIT*cyl**2*weight*az_force
    return total
def run(order):
    rows=[]
    for radius,height in [(6.,1.5),(8.3,1.5),(17.58,0.)]:
        values=direct(radius,height,order)
        rows.append(dict(R=radius,z=height,short=values[0],long=values[1],azimuthal=sum(values)))
    table(f"direct-azimuth-{order}",rows)
if __name__=="__main__":
    for value in sys.argv[1:]:run(int(value))
