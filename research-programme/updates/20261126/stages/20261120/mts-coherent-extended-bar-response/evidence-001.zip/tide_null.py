from ring_test import *
def run():
    table_in=read("ring-inputs-28")
    gal_r=np.array([r for r,z in SITES])
    source=np.array([float(r["potential"]) for r in table_in])/gal_r
    mat=np.vstack([source/source[0],gal_r/gal_r[0]])
    weights=np.r_[1.,np.linalg.solve(mat[:,1:],-mat[:,0])]
    assert np.max(abs(mat@weights))<1e-13
    angular=4*UNIT*np.sin(2*(AXIS-np.deg2rad(28.)))
    short=angular*np.array([float(s["short"]) for s in table_in])/gal_r
    config=dict(w6=weights[0],w83=weights[1],w1758=weights[2],noise_gain=np.linalg.norm(weights),max_condition=np.linalg.cond(mat[:,1:]),short=weights@short,long=weights@(angular*source-short))
    table("tidal-null-weights",[config])
    density=read("ring-satellite");result=[]
    for hist in fixed.prep.ms.MODELS:
        full=np.array([np.mean([float(v["projection"]) for v in density if v["history"]==hist and float(v["R"])==radius]) for radius,z in SITES])
        for occ in (0,1):
            values=read(f"response-new-{occ}-high-extra-m2")
            wv=np.array([next(float(v["cos_coeff"]) for v in values if float(v["R"])==radius and v["component"]=="azimuthal") for radius,z in SITES])
            residual=full@weights;wave=wv@weights
            result.append(dict(occ=occ,history=hist,residual_LMC=residual,MTS_net=residual+wave,static_NFW_net=residual,corrected_MTS=wave,corrected_static=0.))
    table("tidal-null-predictions",result)
if __name__=="__main__":run()
