from compare import *
from ring_test import LMC
from live_control import HOST
def all_hashes(root):
    seal=json.loads((root/"seal.json").read_bytes())["files"]
    for name,sha in seal.items():assert ls.old.digest(root/name)==sha,name
    return len(seal)
def run():
    guard()
    previous={root.name:all_hashes(root) for root in (STATE,fixed.BAR,fixed.PARENT)}
    for p in HERE.glob("*.csv"):
        with p.open(newline="") as stream:data=list(csv.reader(stream))
        assert len(data)>1 and len(set(data[0]))==len(data[0]) and all(len(v)==len(data[0]) for v in data),p
    for p in HERE.glob("*.py"):
        compile(p.read_text(encoding="utf-8"),str(p),"exec")
    for root in (LMC,HOST):
        archive=json.loads((root/"seal.json").read_bytes())["files"]
        if root==HOST:
            selected=["native-build.csv","host-inputs.csv"]+[r["path"] for r in ls.old.read(HOST,"host-inputs")]
        else:
            selected=[]
            for h in fixed.prep.ms.MODELS:
                selected.extend([f"source/{h}/trajlmc.txt",f"source/{h}/potential.ini"])
                import re
                f,=re.findall(r"^\s*0\.0+\s+(pot/lmc\d+\.ini)\s*$",(root/f"source/{h}/potential.ini").read_text().split("[Potential LMC]")[1],re.M)
                selected.append(f"source/{h}/{f}")
        for name in selected:assert ls.old.digest(root/name)==archive[name]
        previous[root.name+":selected"]=len(selected)
    sky=read("forces");assert len(sky)==384 and len(read("panels"))==48 and all(r["only_outer_polar"]=="True" for r in read("panels"))
    for r in sky:
        assert abs(sum(float(r[key]) for key in ("ordinary","dark_mean","direct_LMC","LMC_m0","rotating_wave"))-float(r["total"]))<1e-12
    rates=[];replay_error=0.
    for occ in (0,1):
        for mode in (2,16,32):
            old=ls.old.read(fixed.BAR,f"rotating-fine-{occ}-m{mode}")
            for r in read(f"response-old-{occ}-fine-fine-m{mode}"):
                expected=float(next(v for v in old if v["R"]==r["R"])[r["component"]])
                replay_error=max(replay_error,abs(expected-float(r["central"])))
        for m in MODES:
            r=read(f"exchange-new-{occ}-high-extra-m{m}")[0]
            for k in ("relative_reciprocal","matrix_cross_error"):assert float(r[k])<TOL
            rates.append(r)
    assert replay_error<1e-13
    refinements=read("refinements");good=[float(r["relative"]) for r in refinements if r["compared"] in ("fine","edge") and r["relative"]]
    assert max(good)<TOL
    angular=read("orientation")
    for r in angular:
        assert float(r["minimum_lower"])<=float(r["locked"])<=float(r["maximum_upper"])
        assert abs(float(r["maximum_lower"])) <= float(r["independent_phase_ceiling"])+1e-14
    inputs=[read(f"ring-inputs-{n}") for n in (14,20,28)]
    assert max(abs(float(a["potential"])/float(b["potential"])-1) for a,b in zip(*inputs[1:]))<TOL
    assert max(float(b["relative"]) for b in inputs[-1])<TOL
    sat=read("ring-satellite");live=read("live-halo-projections")
    assert max(abs(float(r[k])) for r in sat for k in ("refinement","derivative_check"))<1e-8
    assert max(abs(float(r["coefficient"])-float(r["potential_form"])) for r in live)<1e-10
    assert len(read("live-halo-contrast"))==24
    cap=[v for v in angular if v["R"]=="6.0" and v["component"]=="polar"]
    def span(values):return [min(values),max(values)]
    ring=read("ring-predictions");hybrid=read("tidal-null-predictions");speeds=read("speed-controls")
    summary=dict(upstream=previous,legacy_replay_max_abs=replay_error,paired_panels=48,full_signed_rows=len(sky),published_tolerance=TOL,
                 fine_refinement=max(good),largest_cross_loss_check=max(float(r["matrix_cross_error"]) for r in rates),
                 largest_raw_relative_work_defect=max(abs(float(r["raw"])/float(r["flux"])-1) for r in rates),
                 polar_orientation_upper=max(float(v["maximum_upper"]) for v in cap),
                 residual_even_polar=min(float(v["even_lo"]) for v in read("signed-gaps") if v["model"]=="MTS" and v["R"]=="6.0" and v["component"]=="polar"),
                 two_ring=span([float(r["corrected_MTS"]) for r in ring if r["diagnostic"]=="two_rings"]),
                 three_ring_tide=span([float(r["corrected_MTS"]) for r in hybrid]),smallest_sample_speed_gap=min(float(r["raw_sample_gap"]) for r in speeds),
                 live_change=span([float(r["final_minus_initial"]) for r in read("live-halo-contrast") if r["diagnostic"]=="tide_cancelled"]))
    put("checks.json",json.dumps(summary,sort_keys=True,indent=2)+"\n")
    files={p.name:ls.old.digest(p) for p in sorted(HERE.iterdir()) if p.is_file() and p.name!="seal.json"}
    if "--seal" in sys.argv:put("seal.json",json.dumps(dict(files=files),sort_keys=True,indent=2)+"\n")
    if (HERE/"seal.json").exists():
        assert json.loads((HERE/"seal.json").read_bytes())["files"]==files
        print(len(files),ls.old.digest(HERE/"seal.json"))
if __name__=="__main__":run()
