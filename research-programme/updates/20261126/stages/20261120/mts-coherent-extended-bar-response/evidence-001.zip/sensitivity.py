from ring_test import *
def run():
    row=read("tidal-null-weights")[0];weights=np.array([float(row[k]) for k in ("w6","w83","w1758")])
    fixed_axis=np.deg2rad(29.4)
    rr=np.array([r for r,z in SITES]);star=[]
    central=Field("extra")
    for radius,z in SITES:
        dist=np.hypot(radius,z);star.append(central.grid([dist],[z/dist],2)[0][0,0])
    star=np.array(star)
    extra=np.array([float(v["potential"]) for v in read("ring-inputs-28")])
    bank=read("tidal-null-predictions");residual=[float(r["residual_LMC"]) for r in bank]
    both=[];geometry=[]
    for occ in (0,1):
        for speed in (31.48,33.29,35.1):
            stem=f"response-new-{occ}-high-extra-m2"+("" if speed==33.29 else f"-speed{speed:.2f}")
            modes=read(stem);coeff=np.array([[float(next(r[k] for r in modes if float(r["R"])==radius and r["component"]=="azimuthal")) for k in ("cos_coeff","sin_coeff")] for radius in rr])
            contrast=weights@coeff[:,0]
            both.append(dict(occ=occ,pattern=speed,contrast=contrast,min_MTS_raw=min(residual)+contrast,max_MTS_raw=max(residual)+contrast,
                             static_min=min(residual),static_max=max(residual),raw_sample_gap=min(residual)+contrast-max(residual)))
            if speed==33.29:
                center_slope=abs(8*UNIT*(weights@(star/rr)))*pi/180
                geometry.append(dict(occ=occ,E3_axis_direct_leak_per_degree=center_slope,
                   common_reference_direct_slope_per_degree=abs(8*UNIT*weights@(star/rr+extra/rr*np.cos(2*(fixed_axis-np.deg2rad(28.)))))*pi/180,
                   E3_direct_leak_absolute_ceiling=abs(4*UNIT*(weights@(star/rr))),
                   E3_axis_alone_can_match_signal=abs(4*UNIT*(weights@(star/rr)))>=abs(contrast),
                   equal_independent_ring_sigma_one_signal=abs(contrast)/np.linalg.norm(weights),
                   noise_note="per even-height ring Fourier coefficient; signal scale, not a detection threshold"))
    table("speed-controls",both);table("geometry-sensitivity",geometry)
if __name__=="__main__":run()
