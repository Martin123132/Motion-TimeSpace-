from ring_test import *
def run():
    old=ls.old.read(fixed.PARENT,"whole-force-20")
    direct=read("direct-azimuth-28");mean=ls.old.read(STATE,"independent-rings")
    checks=[]
    for level in ("coarse","fine","extra"):
        bank=Extended(level)
        for radius,z in SITES:
            summ=bank.at(radius,z,pi-ls.angle("short22"))
            for key in ("radial","polar","azimuthal"):
                if key!="azimuthal" and radius==17.58:continue
                if key=="azimuthal":
                    base=0.;oracle=next(float(v[key]) for v in direct if float(v["R"])==radius)
                else:
                    base=next(float(v[key]) for v in mean if float(v["R"])==radius and v["order"]=="20")
                    oracle=.4*next(float(v["delta"]) for v in old if float(v["R"])==radius and v["component"]==key and v["group"]=="S22")
                val=base+sum(v[key] for v in summ if v["m"])
                checks.append(dict(level=level,R=radius,component=key,harmonic=val,independent=oracle,difference=val-oracle,relative=abs(val/oracle-1)))
    table("source-sky-checks",checks)
if __name__=="__main__":run()
