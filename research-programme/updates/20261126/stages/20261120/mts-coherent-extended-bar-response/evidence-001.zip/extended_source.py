from pathlib import Path
import csv
import hashlib
import io
import json
import sys
HERE=Path(__file__).resolve().parent
STATE=HERE.parent/"mts-extended-bar-fixed-occupation-20261120"
sys.dont_write_bytecode=True
sys.path.insert(0,str(STATE))
import branch_state as fixed
from signed_potential import ls, np, G, UNIT, quad, pi, zshape
import rotating_response as response
from bar_field import Field, angular, slope
from scipy.interpolate import CubicHermiteSpline
def guard():
    fixed.guard()
    assert ls.old.digest(STATE/"seal.json")=="04d68be63540458fe12b4016eb0c1f860321cbef03c662c8521b8f611359453a"
    assert not (HERE/"STOP-REQUESTED").exists()
def put(name,raw):
    guard()
    if isinstance(raw,str): raw=raw.encode()
    path=HERE/name
    if path.exists():assert path.read_bytes()==raw,name
    else:
        with path.open("xb") as stream:stream.write(raw)
def table(name,rows):
    buf=io.StringIO(newline="")
    writer=csv.DictWriter(buf,rows[0].keys(),lineterminator="\n")
    writer.writeheader();writer.writerows(rows);put(name+".csv",buf.getvalue())
def packet(name,**arrays):
    buf=io.BytesIO();np.savez_compressed(buf,**arrays);put(name+".npz",buf.getvalue())
def read(name):return ls.old.read(HERE,name)
class Extended(Field):
    def __init__(self,level):
        with np.load(HERE/f"source-{level}.npz") as rec:
            self.r,self.deg,self.mode,self.val,self.der=[rec[k] for k in ("r","degree","mode","potential","derivative")]
        self.spline=CubicHermiteSpline(self.r,self.val,self.der,axis=0)
SETTINGS={"coarse":(48,250,40),"fine":(68,380,60),"extra":(84,520,80)}
def build(level):
    guard();maximum,nrad,nangle=SETTINGS[level]
    edges=np.unique(np.r_[0.,np.geomspace(.001,90,nrad),ls.edges(ls.S22,0),np.hypot([6.,8.3],1.5),17.58])
    edges=edges[(edges>=0)&(edges<=90)]
    radii,wr=quad(edges,6)
    mu,aw=quad([0,.04,.16,.5,1],max(16,nangle//2))
    phi,pw=quad([0,.025,.18,.7,pi/2],nangle//2)
    angles=np.arange(0,33,2);fourier=pw[:,None]*np.cos(phi[:,None]*angles)*2/pi
    tags=[(ell,mode) for mode in angles for ell in range(mode,maximum+1,2)]
    deg,modes=np.array(tags).T
    harmonics=[np.stack([angular(el,mode,mu)*aw for el in deg[modes==mode]],axis=1) for mode in angles]
    density=np.empty((len(radii),len(tags)))
    for begin in range(0,len(radii),20):
        radius=radii[begin:begin+20,None];cyl=radius*np.sqrt(1-mu*mu);height=radius*mu
        coeff=np.zeros((*cyl.shape,len(angles)))
        for key in ls.S22:
            col=ls.raw(key,0,cyl[:,:,None],phi)
            coeff+=.4*(col@fourier)*zshape(key,height)[:,:,None]*(cyl<30)[:,:,None]
        density[begin:begin+len(radius)]=np.column_stack([coeff[:,:,idx]@harm for idx,harm in enumerate(harmonics)])
    shell=radii.reshape(-1,6)[:,:,None];weights=wr.reshape(-1,6)[:,:,None];rho=density.reshape(len(edges)-1,6,-1)
    inner=np.zeros((len(edges),len(deg)));outer=np.zeros_like(inner)
    for idx,(lo,hi) in enumerate(zip(edges,edges[1:])):
        inner[idx+1]=inner[idx]*(lo/hi)**(deg+1)+(weights[idx]*shell[idx]**2/hi*(shell[idx]/hi)**deg*rho[idx]).sum(axis=0)
    for idx in range(len(edges)-2,-1,-1):
        lo,hi=edges[idx:idx+2]
        outer[idx]=outer[idx+1]*(lo/hi)**deg+(weights[idx]*shell[idx]*(lo/shell[idx])**deg*rho[idx]).sum(axis=0)
    factor=-4*pi*G/(2*deg+1)
    val=factor*(inner+outer);der=np.zeros_like(val);der[1:]=factor*(deg*outer[1:]-(deg+1)*inner[1:])/edges[1:,None]
    rr,rw=quad(ls.edges(ls.S22,0),100)
    mean_col=sum(.4*ls.raw(k,0,rr[:,None],phi)@fourier for k in ls.S22)
    mass=2*pi*(rr*rw)@mean_col[:,0];quad2=2*pi*(rr**3*rw)@mean_col[:,1]
    monopole=-val[-1,0]*edges[-1]/G
    index=np.flatnonzero((deg==2)&(modes==2))[0]
    quadrupole=val[-1,index]*angular(2,2,0.)*edges[-1]**3/(-3*G/8)
    table("moments-"+level,[dict(mass_cyl=mass,mass_sph=monopole,quadrupole_cyl=quad2,quadrupole_sph=quadrupole)])
    assert abs(monopole/mass-1)<2e-5 and abs(quadrupole/quad2-1)<2e-5
    packet("source-"+level,r=edges,degree=deg,mode=modes,potential=val,derivative=der)
    print(level,mass,quad2,flush=True)
if __name__=="__main__":
    for level in sys.argv[1:]:build(level)
