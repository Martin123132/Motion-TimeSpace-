from ring_test import *
HOST=HERE.parent/"mts-live-host-halo-comparison-20261120"
def run():
    guard();native=ls.old.read(HOST,"native-build")[0]
    assert ls.old.digest(Path(native["cache"])/"host.dll")==native["library_sha"]
    from fields import field
    selected=ls.old.read(HOST,"host-inputs");controls=[];score=[]
    kept=read("tidal-null-weights")[0]
    tidal=np.array([float(kept[k]) for k in ("w6","w83","w1758")])
    pair=np.array([float(read("ring-weights")[0][k]) for k in ("inner","outer","anchor")])
    for hist in fixed.prep.ms.MODELS:
        for basis in ("multipole","basis"):
            epochs={}
            for epoch in ("initial","final"):
                row=next(r for r in selected if (r["model"],r["variant"],r["epoch"])==(hist,basis,epoch))
                path=HOST/row["path"];assert ls.old.digest(path)==row["sha256"]
                func=field(path);both=[]
                for radius,z in SITES:
                    sides=[]
                    for height in (z,-z):
                        values=[]
                        for n in (256,512):
                            phi=2*pi*np.arange(n)/n
                            pos=np.column_stack([radius*np.cos(phi),radius*np.sin(phi),np.full(n,height)])
                            ans=func(pos);cos=np.cos(2*(phi-AXIS));sine=np.sin(2*(phi-AXIS))
                            torque=(-np.sin(phi)*ans[:,1]+np.cos(phi)*ans[:,2])*UNIT
                            projection=2*np.mean(cos*torque)
                            independent=-4*UNIT/radius*np.mean(sine*(ans[:,0]-ans[:,0].mean()))
                            values.append((projection,independent))
                        controls.append(dict(history=hist,representation=basis,epoch=epoch,R=radius,z=height,
                            coefficient=values[1][0],potential_form=values[1][1],refinement=values[1][0]-values[0][0]))
                        sides.append(values[1][0])
                    both.append(np.mean(sides))
                epochs[epoch]=np.array(both)
            for name,weights in (("two_rings",pair),("tide_cancelled",tidal)):
                initial=weights@epochs["initial"];final=weights@epochs["final"]
                score.append(dict(history=hist,representation=basis,diagnostic=name,halo_initial=initial,halo_final=final,
                    final_minus_initial=final-initial,scope="archived collisionless host; not this stellar foreground"))
    table("live-halo-projections",controls);table("live-halo-contrast",score)
if __name__=="__main__":run()
