"""Build regular l=2 formation fields and split native metric versus enclosed matter."""
from formation_tide import AI, ROOT, bank, np, prepare, stats, table, top, spherical_jn, leggauss, io, emit, guard
from scipy.integrate import simpson


def main():
    ref, epochs, _, metric, _ = prepare("heavy",0)
    initial = np.where(epochs==AI)[0].item()
    wave_number = ref.k
    volume = bank("volume-state")
    width = np.diff(np.log(wave_number))
    power_weight = .5*(np.r_[width,0]+np.r_[0,width])*volume["primordial_power"][np.isin(volume["k_Mpc_inverse"],wave_number)]
    tide = -wave_number**2*metric[:,initial]*top(wave_number*ref.radius)
    selector = power_weight*tide/np.sqrt(power_weight@tide**2/5)
    r_grid = np.linspace(0,24,3841)
    angles, angular_weights = leggauss(16)
    angular_quad = (3*angles**2-1)/2
    rows, checks = [], []
    for branch in ("heavy","cold"):
        guard()
        seed, times, fields, lapse, _ = prepare(branch,0)
        args = np.outer(r_grid,wave_number)
        bessel0, bessel2 = spherical_jn(0,args), spherical_jn(2,args)
        slope2 = spherical_jn(2,args, derivative=True)*wave_number
        archive = dict(comoving_r_Mpc=r_grid,a=AI,primordial_tide_rms_units=1,scalar_selector_rms_units=2,
                       lapse2=-bessel2@(selector*lapse[:,initial]),dlapse2_dr=-slope2@(selector*lapse[:,initial]))
        for species,(density,theta) in fields.items():
            base = 2*bessel0@(seed.weights*density[:,initial])
            quad = -bessel2@(selector*density[:,initial])
            velocity_potential = bessel2@(selector*theta[:,initial]/wave_number**2)
            velocity_slope = slope2@(selector*theta[:,initial]/wave_number**2)
            for name,field in (("D0",base),("D2",quad),("velocity_potential2_Mpc",velocity_potential),("radial_velocity2",velocity_slope)):
                archive[species+"_"+name] = field
            positive_min = float(np.min(1+base-np.abs(quad)))
            assert positive_min>0 and quad[0]==velocity_slope[0]==velocity_potential[0]==0
            angular_leak = float(np.max(abs((1+base[:,None]+quad[:,None]*angular_quad)@(angular_weights/2)-(1+base))))
            assert angular_leak < 2e-14
            checks.append(dict(branch=branch,species=species,min_density_bound_both_tide_signs=positive_min,angular_number_leak=angular_leak))
            if species == "wave":
                base_phase = -2*AI*seed.mass*(bessel0-1)@(seed.weights*theta[:,initial]/wave_number**2)
                phase = AI*seed.mass*velocity_potential
                background = np.sqrt(1+base)*np.exp(1j*base_phase)
                tangent = background*(quad/(2*(1+base))+1j*phase)
                eps = 1e-4
                trial = lambda strength: np.sqrt(1+base+strength*quad)*np.exp(1j*(base_phase+strength*phase))
                difference = (trial(eps)-trial(-eps))/(2*eps)
                assert np.linalg.norm(difference-tangent)/np.linalg.norm(tangent)<2e-5
                np.testing.assert_allclose(2*np.real(background.conj()*tangent),quad,rtol=2e-13,atol=1e-15)
                archive.update(wave_state0=background,wave_tangent2=tangent,wave_phase2=phase)
        interval = io.BytesIO()
        np.savez_compressed(interval,**archive)
        emit(branch+"-initial-tide.npz",interval.getvalue())
        for scale in (AI,1/11):
            slot = np.argmin(abs(times-scale))
            assert abs(times[slot]-scale)<1e-13
            spectrum = -selector*lapse[:,slot]
            native_source = -wave_number**2*spectrum
            matter_source = -selector*sum(seed.coeff[species]*fields[species][0][:,slot] for species in fields)/(2*scale)
            for edge in (12.,24.,40.):
                at_edge = spherical_jn(2,wave_number*edge)
                slope_edge = spherical_jn(2,wave_number*edge,derivative=True)*wave_number
                exterior_coeff = (slope_edge+3/edge*at_edge)@spectrum/(5*edge)
                for fraction in (.5,1.,2.):
                    radius = ref.radius*fraction
                    exact = np.array([spherical_jn(2,wave_number*radius)@spectrum,
                                      (spherical_jn(2,wave_number*radius,derivative=True)*wave_number)@spectrum])
                    ext = exterior_coeff*np.array([radius**2,2*radius])
                    def integrate(order, density_source):
                        nodes, weights = leggauss(order)
                        inner = radius*(nodes+1)/2
                        outer = radius+(edge-radius)*(nodes+1)/2
                        low = radius/2*(weights*inner**4)@(spherical_jn(2,np.outer(inner,wave_number))@density_source)
                        high = (edge-radius)/2*(weights/outer)@(spherical_jn(2,np.outer(outer,wave_number))@density_source)
                        return np.array([-(low/radius**3+radius**2*high)/5,(3*low/radius**4-2*radius*high)/5])
                    inside, matter = (integrate(128,item) for item in (native_source,matter_source))
                    np.testing.assert_allclose(integrate(96,native_source),inside,rtol=2e-10,atol=2e-17)
                    np.testing.assert_allclose(inside+ext,exact,rtol=2e-10,atol=2e-17)
                    for position,quantity in enumerate(("lapse_l2","radial_gradient_l2")):
                        rows.append(dict(branch=branch,a=scale,wall_Mpc=edge,fraction=fraction,observable=quantity,
                                         native=exact[position],native_inside=inside[position],exterior=ext[position],
                                         vacuum_wall_relative_error=inside[position]/exact[position]-1,
                                         matter_inside=matter[position],matter_plus_native_exterior_fractional_error=(matter[position]+ext[position])/exact[position]-1))
    table("initial-number-checks.csv",checks)
    table("finite-tide-boundary.csv",rows)
    print("Initial number and wave tangent checked; reconstructed",len(rows),"finite metric components.")


if __name__=="__main__":
    main()
