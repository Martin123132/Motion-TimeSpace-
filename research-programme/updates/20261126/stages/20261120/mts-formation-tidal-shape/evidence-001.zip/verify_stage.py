import csv
import hashlib
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
PARENT = ROOT.parent / "mts-primordial-patch-infall-20261120"
PIN = "a9f7723564116720ba5bc03333239d8fc0f106a6c2f14ca052f94e822aee2467"


def digest(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream,"sha256").hexdigest()


def read(name):
    with (ROOT/name).open(newline="") as stream:
        return list(csv.DictReader(stream))


def main():
    assert digest(PARENT/"seal.json")==PIN
    reference = json.loads((PARENT/"seal.json").read_bytes())["files"]
    for name in ("radiation-full-cold-0.npz","radiation-full-heavy-0.npz","seeds.py","native_balance.py","linear_control.py","matched_hierarchy.py","collapse.py","spectral.py"):
        assert digest(PARENT/name)==reference[name]
    cases=read("direct-current-path.csv")
    assert len({(r["a"],r["fraction"],r["model"]) for r in cases})==len(cases)==18
    assert all(r["pass_both"]=="True" and max(abs(float(r[k])) for k in ("shape_relative_error","net_flux_relative_error","half_grid_shape_fractional_shift","worst_endpoint_transfer_relative_norm"))<2e-5 for r in cases)
    for name,count in (("histories.csv",108),("paired-difference.csv",54),("angular-current.csv",12),("finite-monopole-tangent.csv",15),("tide-principal-axes.csv",27),("finite-tide-boundary.csv",72),("tensor-draw-control.csv",24),("initial-number-checks.csv",5)):
        assert len(read(name))==count
    assert all(abs(float(r["direct_tangent_fractional_error"]))<2e-8 for r in read("finite-monopole-tangent.csv"))
    for model in ("heavy","cold"):
        assert (ROOT/(model+"-initial-tide.npz")).is_file()
        assert len(list(ROOT.glob(model+"-chunk-*-vel.npz")))==7
    assert not (ROOT/"__pycache__").exists()
    expected = {p.name:digest(p) for p in sorted(ROOT.iterdir()) if p.is_file() and p.name!="seal.json"}
    assert {"RESULTS.md","DERIVATION.md","REPLAY.md","PROTOCOL.md"}<=expected.keys()
    manifest=dict(files=expected,previous_seal=PIN)
    if sys.argv[1:]==["--seal"]:
        with (ROOT/"seal.json").open("x",encoding="utf8",newline="\n") as stream:
            json.dump(manifest,stream,indent=2,sort_keys=True)
            stream.write("\n")
    else:
        assert json.loads((ROOT/"seal.json").read_bytes())==manifest
    print(len(expected),"local files verified;",len(cases),"paired-branch current cases; parent seal verified.")


if __name__=="__main__":
    main()
