"""Independent fixed-seed Gaussian tensor experiment (sampling check, not an observation)."""
import csv
from formation_tide import AI, ROOT, bank, np, prepare, spherical_jn, table, top
from current_path import build
from scipy.integrate import simpson
from scipy.special import ndtri
from scipy.stats import qmc


def main():
    ref, times, _, lapse, _ = prepare("heavy",0)
    modes = ref.k
    width = np.diff(np.log(modes))
    vol = bank("volume-state")
    weight = .5*(np.r_[width,0]+np.r_[0,width])*vol["primordial_power"][np.isin(vol["k_Mpc_inverse"],modes)]
    tide = -modes**2*lapse[:,np.where(times==AI)[0].item()]*top(modes*ref.radius)
    tide /= np.sqrt(weight@tide**2/5)
    kernel = [tide]
    for model in ("heavy","cold"):
        seed, scale, _, rate, _ = build(model)
        kernel.append(7.5*spherical_jn(2,modes*seed.radius,derivative=True)*simpson(rate,x=np.log(scale),axis=1)/(seed.radius*modes))
    design = np.array(kernel)*np.sqrt(weight/5)
    covariance = design@design.T
    factor = np.linalg.cholesky(covariance)
    basis = np.zeros((5,3,3))
    basis[0]=np.diag([1,-1,0])/np.sqrt(2)
    basis[1]=np.diag([1,1,-2])/np.sqrt(6)
    for index,(i,j) in enumerate(((0,1),(0,2),(1,2)),start=2):
        basis[index,i,j]=basis[index,j,i]=1/np.sqrt(2)
    np.testing.assert_allclose(basis.reshape(5,9)@basis.reshape(5,9).T,np.eye(5),atol=2e-15,rtol=0)
    rows=[]
    with (ROOT/"tide-principal-axes.csv").open() as stream:
        truth = {row["branch"]:row for row in csv.DictReader(stream) if float(row["fraction"])==1 and float(row["a"])>.09}
    for seed_id in (2101,3301,5101,7103,9103,11003,13001,17011):
        sample=qmc.Sobol(15,scramble=True,seed=seed_id).random_base2(14)
        normals=ndtri(sample).reshape(-1,5,3)@factor.T
        matrices=np.einsum("nqt,qij->ntij",normals,basis)*np.sqrt(1.5)
        _,axes=np.linalg.eigh(matrices[:,0])
        vectors=axes[:,:,[0,2]]
        projections=np.einsum("nik,ntij,njk->ntk",vectors,matrices[:,1:],vectors)
        signed=(2/3)*(projections[:,:,1]-projections[:,:,0])
        for target,values in (("heavy",signed[:,0]),("cold",signed[:,1]),("paired_heavy_minus_cold",signed[:,0]-signed[:,1])):
            rows.append(dict(seed=seed_id,model=target,draws=len(values),signed_mean=values.mean(),std=values.std(),
                             positive=np.mean(values>0),theory_positive=float(truth[target]["probability_positive"])))
    table("tensor-draw-control.csv",rows)
    for name, exact in truth.items():
        group=[row for row in rows if row["model"]==name]
        for key, ref_key in (("signed_mean","mean_axis_difference_over_R"),("std","ensemble_std"),("positive","probability_positive")):
            estimates=np.array([row[key] for row in group])
            err=abs(estimates.mean()-float(exact[ref_key]))
            floor=8/np.sum([row["draws"] for row in group])
            assert err<max(floor,8*estimates.std(ddof=1)/np.sqrt(len(group))), (name,key,err)
        print(name,"direct tensor-draw sign fraction",np.mean([row["positive"] for row in group]))


if __name__=="__main__":
    main()
