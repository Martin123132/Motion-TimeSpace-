"""Integrate actual native peculiar velocities; density differences are controls only."""
from formation_tide import AI, PARENT, ROOT, TOL, bank, guard, io, json, np, os, prepare, sha, stats, sys, table, top, window, spherical_jn
from seeds import SPEC, NATIVE, checked, obj, source
from scipy.integrate import simpson, cumulative_simpson
sys.path.insert(0, str(SPEC))
from spectrum_common import camb, inherited


def build(model):
    seed, epochs, fields, _, _ = prepare(model, 0)
    status = obj(source("runs/" + model + "/status.json"))
    for path in inherited.native_hashes():
        checked(path, status["input_hashes"][str(path)])
    origin = SPEC / "runs/projection/a225-w6-d8.npz" if model == "heavy" else NATIVE / "runs/backgrounds/cold.npz"
    checked(origin, status["source_hash"])
    params = inherited.params_for(origin, background_boost=8.)
    params.DoLateRadTruncation = False
    background = camb.get_background(params)
    background.Params.Accuracy.IntTolBoost = 6
    scales = np.exp(np.linspace(np.log(AI), np.log(1/11), 129))
    scales[[0,-1]] = [AI, 1/11]
    earlier = epochs[epochs < AI-1e-8]
    native_times = background.conformal_time(1/np.r_[earlier, scales]-1, tol=1e-10)
    names = ["a","H","etak","v_newtonian_cdm","delta_cdm","mts_drho_h","mts_q_h"]
    groups = []
    for chunk in sorted((SPEC/"runs"/model).glob("chunk-*.npz")):
        with np.load(source(chunk.relative_to(SPEC).as_posix())) as saved:
            selected = saved["modes"][np.isin(saved["modes"], seed.k)]
            if not len(selected):
                continue
            modes = np.unique(np.r_[selected, saved["modes"].max()])
        guard()
        path = ROOT / f"{model}-{chunk.stem}-vel.npz"
        if not path.exists():
            result = background.get_time_evolution(modes, native_times, vars=names, lAccuracyBoost=4)
            values = result[np.searchsorted(modes, selected), len(earlier):, :]
            assert np.isfinite(values).all()
            packet = io.BytesIO()
            np.savez_compressed(packet, modes=selected, scales=scales, values=values, names=np.array(names))
            with path.open("xb") as out:
                out.write(packet.getvalue())
            print(model,chunk.stem,flush=True)
        with np.load(path) as got:
            np.testing.assert_array_equal(got["modes"], selected)
            np.testing.assert_array_equal(got["scales"], scales)
            np.testing.assert_array_equal(got["names"], names)
            groups.append(got["values"])
    values = np.concatenate(groups)
    assert values.shape == (len(seed.k), len(scales), len(names))
    cols = dict(zip(names, values.transpose(2,0,1)))
    wave_number = seed.k[:,None]
    native_scale, hubble = cols["a"], cols["H"]
    np.testing.assert_allclose(native_scale, np.broadcast_to(scales,native_scale.shape), rtol=2e-7,atol=0)
    curvature = cols["etak"] / wave_number
    theta_c = -hubble * cols["v_newtonian_cdm"]
    if model=="heavy":
        mean = seed.coeff["wave"]/native_scale
        density = cols["mts_drho_h"]/mean-3*curvature
        theta = wave_number * cols["mts_q_h"]/mean+theta_c
    else:
        density = cols["delta_cdm"]-3*curvature
        theta = theta_c
    ref = fields["wave" if model=="heavy" else "cdm"]
    ref_slots = [np.argmin(abs(epochs-at)) for at in scales[[0,-1]]]
    reference_errors = []
    for new, old in zip((density,theta), ref):
        for slot, ref_slot in zip((0,-1),ref_slots):
            numerator = np.linalg.norm(new[:,slot]-old[:,ref_slot])
            reference_errors.append(float(numerator/np.linalg.norm(old[:,ref_slot])))
    assert max(reference_errors) < TOL
    return seed, scales, density, theta/hubble, reference_errors


def main():
    assert sha(ROOT/"histories.csv")=="615e653acd45e785bc2d8e09844ac56473db695bfa44b951dfbd21178e04570f"
    ref, epochs, _, lapse, _ = prepare("heavy", 0)
    modes = ref.k
    vol = bank("volume-state")
    widths = np.diff(np.log(modes))
    weight = (np.r_[widths,0]+np.r_[0,widths])*.5*vol["primordial_power"][np.isin(vol["k_Mpc_inverse"],modes)]
    source_tide = -modes**2*lapse[:,np.where(epochs==AI)[0].item()]*top(modes*ref.radius)
    output = []
    for model in ("heavy","cold"):
        guard()
        seed, scales, density, rates, endpoints = build(model)
        for stop in (32,64,128):
            times = np.log(scales[:stop+1])
            integral = simpson(rates[:,:stop+1],x=times,axis=1)
            lesser = simpson(rates[:,:stop+1:2],x=times[::2],axis=1)
            for fraction in (.5, 1., 2.):
                radius = fraction*seed.radius
                slope = spherical_jn(2,modes*radius,derivative=True)
                ball, line = window(modes,radius,80)
                conversion = 7.5*slope/(modes*radius)
                delta = density[:,stop]-density[:,0]
                expected = -conversion*delta
                actual = conversion*integral
                mean = lambda kernel: stats(kernel,source_tide,weight)["per_positive_rms"]
                boundary = -3.75*3/radius*slope/modes*integral
                lateral = 22.5*3/radius**3*line/modes**2*integral
                cap_delta = -3.75*ball*delta
                independent = boundary+lateral
                miss = mean(actual)/mean(expected)-1
                mass_miss = mean(independent)/mean(cap_delta)-1
                output.append(dict(model=model, a=scales[stop], fraction=fraction, material_shape_from_native_current=mean(actual),
                                   material_shape_from_density=mean(expected),shape_relative_error=miss,
                                   half_grid_shape_fractional_shift=mean(conversion*lesser)/mean(actual)-1,
                                   cap_belt_density_change=mean(cap_delta), radial_flux=mean(boundary),lateral_flux=mean(lateral),
                                   net_flux_relative_error=mass_miss,full_mode_shape_error_rms=stats(actual-expected,source_tide,weight)["unconditioned_rms"],
                                   remaining_shape_scatter=stats(actual,source_tide,weight)["remaining_rms"],
                                   spherical_2sigma_mean_D=2*seed.weights@(top(modes*radius)*density[:,stop]),
                                   worst_endpoint_transfer_relative_norm=max(endpoints), pass_both=bool(max(abs(miss),abs(mass_miss))<TOL)))
    table("direct-current-path.csv",output)
    for row in output:
        if row["fraction"] == 1:
            print(row["model"],row["a"],row["material_shape_from_native_current"],row["shape_relative_error"],row["net_flux_relative_error"])
    print("both forecasts within tolerance:",sum(row["pass_both"] for row in output),"/",len(output))


if __name__=="__main__":
    main()
