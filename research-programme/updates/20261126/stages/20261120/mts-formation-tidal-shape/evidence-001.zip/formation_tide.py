"""Predict axisymmetric formation observables from a common primordial tide."""
import csv
import hashlib
import io
import json
import os
import sys
from pathlib import Path

for var in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "NUMEXPR_NUM_THREADS"):
    os.environ[var] = "1"
sys.dont_write_bytecode = True

import numpy as np
from numpy.polynomial.legendre import leggauss
from scipy.special import spherical_jn

ROOT = Path(__file__).resolve().parent
PARENT = ROOT.parent / "mts-primordial-patch-infall-20261120"
PIN = "a9f7723564116720ba5bc03333239d8fc0f106a6c2f14ca052f94e822aee2467"
TOL = 2e-5


def sha(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def guard():
    assert not any((place / "STOP-REQUESTED").exists() for place in (ROOT, ROOT.parent, PARENT))


guard()
assert sha(PARENT / "seal.json") == PIN
parent_files = json.loads((PARENT / "seal.json").read_bytes())["files"]
for name in ("matched_hierarchy.py", "native_balance.py", "linear_control.py", "seeds.py",
             "collapse.py", "spectral.py", "radiation-full-heavy-0.npz", "radiation-full-cold-0.npz"):
    assert sha(PARENT / name) == parent_files[name], name
sys.path.insert(0, str(PARENT))
from matched_hierarchy import prepare, predict
from seeds import bank, top, C, AI
from native_balance import derivative


def emit(name, raw):
    path = ROOT / name
    if "--save" in sys.argv and not path.exists():
        with path.open("xb") as stream:
            stream.write(raw)
    assert path.read_bytes() == raw, name


def table(name, rows):
    output = io.StringIO(newline="")
    writer = csv.DictWriter(output, fieldnames=list(rows[0]), lineterminator="\n")
    writer.writeheader()
    writer.writerows(rows)
    emit(name, output.getvalue().encode("ascii"))


def controls(maximum):
    mu, weights = leggauss(64)
    basis = (3 * mu**2 - 1) / 2
    azimuth = 2 * np.pi * np.arange(96) / 96
    assert abs(weights @ basis) < 1e-14 and abs(weights @ basis**2 / 2 - .2) < 1e-14
    error = 0.
    for direction in (-1., -.37, 0., .63, 1.):
        cosine = mu[:, None] * direction + np.sqrt((1 - mu**2) * (1 - direction**2))[:, None] * np.cos(azimuth)
        for arg in (0., .001, .2, 2., maximum):
            direct = (weights * basis) @ np.cos(arg * cosine).mean(axis=1) / 2
            exact = -spherical_jn(2, arg) * (3 * direction**2 - 1) / 2
            error = max(error, abs(direct - exact))
    assert error < 1e-13
    return error


def window(wave_number, radius, order):
    nodes, weights = leggauss(order)
    radial = (nodes + 1) / 2
    profiles = spherical_jn(2, np.outer(radial * radius, wave_number))
    return (weights * radial**2 * 1.5) @ profiles, (weights * radius / 2) @ profiles


def stats(kernel, source, weight):
    norm = np.sqrt(weight @ source**2 / 5)
    projection = (weight * kernel) @ source / (5 * norm)
    total = np.sqrt(weight @ kernel**2 / 5)
    remainder = kernel - projection * source / norm
    residual = np.sqrt(weight @ remainder**2 / 5)
    assert abs((weight * remainder) @ source / (5 * norm)) <= 2e-13 * max(total, 1e-40)
    assert abs(np.hypot(residual, projection) - total) <= 5e-14 * max(total, 1e-40)
    return dict(per_positive_rms=projection, unconditioned_rms=total, remaining_rms=residual,
                explained_variance=projection**2 / total**2 if total else 0.)


def main():
    guard()
    models = {branch: prepare(branch, 0)[:4] for branch in ("heavy", "cold")}
    ref, epochs, _, lapse = models["heavy"]
    wave_number = ref.k
    vol = bank("volume-state")
    keep = np.isin(vol["k_Mpc_inverse"], wave_number)
    np.testing.assert_array_equal(vol["k_Mpc_inverse"][keep], wave_number)
    widths = np.diff(np.log(wave_number))
    weight = (np.r_[widths, 0] + np.r_[0, widths]) * .5 * vol["primordial_power"][keep]
    initial = np.where(epochs == AI)[0].item()
    source = -wave_number**2 * lapse[:, initial] * top(wave_number * ref.radius)
    tide_sigma = np.sqrt(weight @ source**2 / 5)
    epochs_out = np.array([AI, 1/11, 1/3])
    direct_error = controls(2 * ref.radius * max(wave_number))
    records, budget, kernels = [], [], {}
    for branch, (seed, times, fields, metric) in models.items():
        guard()
        np.testing.assert_array_equal(times, epochs)
        np.testing.assert_array_equal(seed.weights, ref.weights)
        target = "wave" if branch == "heavy" else "cdm"
        density, theta = fields[target]
        reduced = predict(seed, epochs_out)[list(seed.fields).index(target)]
        for number, scale in enumerate(epochs_out):
            slot = np.where(np.isclose(times, scale, rtol=0, atol=2e-14))[0].item()
            for fraction in (.5, 1., 2.):
                radius = seed.radius * fraction
                arg = wave_number * radius
                shell = spherical_jn(2, arg)
                slope = spherical_jn(2, arg, derivative=True)
                ball, unweighted = window(wave_number, radius, 80)
                for actual, expected in zip((ball, unweighted), window(wave_number, radius, 40)):
                    np.testing.assert_allclose(actual, expected, rtol=0, atol=2e-14)
                mono = 2 * seed.weights @ (top(arg) * density[:, slot])
                def terms(dens, velocity):
                    return {
                        "shell_coordinate_density_l2": -5 * dens * shell,
                        "cap_minus_belt_mean_coordinate_density_l2": -3.75 * dens * ball,
                        "axis_minus_equator_material_radius_over_R": -7.5 * (dens - density[:, initial]) * slope / (wave_number * radius),
                        "axis_minus_equator_radial_peculiar_kms": 7.5 * C * velocity * slope / wave_number,
                    }
                baseline = terms(density[:, slot], theta[:, slot])
                approx = terms(reduced[0, :, number], reduced[1, :, number] / scale)
                accelerations = {
                    "axis_minus_equator_radial_gravity_kms2_per_Mpc": 7.5 * C**2 / scale * metric[:, slot] * wave_number * slope,
                    "polar_gravity_at_45deg_kms2_per_Mpc": -7.5 * C**2 / (scale * radius) * metric[:, slot] * shell,
                }
                for label, kernel in {**baseline, **accelerations}.items():
                    summary = stats(kernel, source, weight)
                    kernels[(branch, number, fraction, label)] = kernel
                    reduced_mean = stats(approx[label], source, weight)["per_positive_rms"] if label in approx else None
                    measured = summary["per_positive_rms"]
                    discrepancy = reduced_mean / measured - 1 if reduced_mean is not None and measured else None
                    records.append(dict(branch=branch, scale=scale, radius_Mpc=radius, fraction=fraction, observable=label,
                                        spherical_2sigma_mean_D=mono, **summary, reduced_mean=reduced_mean, reduced_fractional_error=discrepancy))
                if number:
                    coeff = 3. / radius**3
                    dp = derivative(density[:, slot-2:slot+3], np.log(times[slot-2:slot+3])) * scale * seed.H(scale)
                    dw = derivative(density[:, [slot+j for j in (-3,-2,0,2,3)]], np.log(times[[slot+j for j in (-3,-2,0,2,3)]])) * scale * seed.H(scale)
                    boundary = -5 * coeff * radius**2 * theta[:, slot] * slope / wave_number
                    lateral = 30 * coeff * theta[:, slot] * unweighted / wave_number**2
                    total = boundary + lateral
                    identity = 5 * theta[:, slot] * ball
                    np.testing.assert_allclose(total, identity, rtol=2e-8, atol=4e-10)
                    rate = lambda kernel: stats(kernel, source, weight)["per_positive_rms"]
                    actual = rate(-5 * ball * dp)
                    wide = rate(-5 * ball * dw)
                    computed = rate(total)
                    budget.append(dict(branch=branch, scale=scale, fraction=fraction, native_density_rate=actual, radial_boundary=rate(boundary),
                                       lateral_current=rate(lateral), predicted_rate=computed, relative=(computed-actual)/actual,
                                       wide_stencil_relative=(computed-wide)/wide, within_tolerance=bool(abs(computed/actual-1)<TOL)))
    pairs = []
    for (branch, number, fraction, label), kernel in kernels.items():
        if branch != "heavy":
            continue
        cold = kernels[("cold", number, fraction, label)]
        pairs.append(dict(scale=epochs_out[number], fraction=fraction, observable=label, **stats(kernel-cold, source, weight)))
    table("histories.csv", records)
    table("paired-difference.csv", pairs)
    table("angular-current.csv", budget)
    meta = dict(parent_sha256=PIN, radius_Mpc=ref.radius, modes=len(wave_number), k_range_Mpc_inverse=wave_number[[0,-1]].tolist(),
                patch_initial_a=AI, projected_tide_sigma_comoving_Mpc_inverse2=tide_sigma,
                physical_axial_traceless_hessian_rms_Mpc_inverse2=2*tide_sigma/(3*AI**2), direct_angular_error=direct_error,
                histories=len(records),paired=len(pairs),continuity=len(budget),tolerance=TOL)
    emit("checks.json",(json.dumps(meta, indent=2, sort_keys=True, allow_nan=False)+"\n").encode())
    print(meta)
    for row in records:
        if row["scale"]==1/11 and row["fraction"]==1 and row["observable"]=="axis_minus_equator_material_radius_over_R":
            print(row)
    print("current residual range", min(row["relative"] for row in budget), max(row["relative"] for row in budget))


if __name__ == "__main__":
    main()
