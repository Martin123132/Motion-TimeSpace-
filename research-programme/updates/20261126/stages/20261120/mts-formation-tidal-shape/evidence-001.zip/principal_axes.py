"""Average the paired linear deformation over the eigenaxes of the initial tide."""
from formation_tide import AI, ROOT, bank, json, np, prepare, stats, table, top, window, spherical_jn
from current_path import build
from scipy.special import ndtr, stdtr, gamma
from scipy.integrate import simpson, quad
from numpy.polynomial.legendre import leggauss


def principal(response, scatter, order):
    points, weights = leggauss(order)
    angle = (points+1)*np.pi/6
    weights = weights*np.pi/6*1.5*np.sin(3*angle)
    np.testing.assert_allclose(weights.sum(),1,atol=2e-14,rtol=0)
    shape = np.cos(angle)-np.cos(angle+2*np.pi/3)
    expected = np.sqrt(2)*gamma(3)/gamma(2.5)*weights@shape
    expected2 = 5*weights@shape**2
    np.testing.assert_allclose(expected, 4.5*np.sqrt(2/np.pi), rtol=2e-14)
    mean = (2/3)*response*expected
    conditional = 2/np.sqrt(3)*scatter
    spread = np.hypot((2/3)*response*np.sqrt(expected2-expected**2),conditional)
    slope = (2/3)*response*shape/conditional
    probability = weights @ stdtr(5, np.sqrt(5)*slope)
    direct = []
    norm = 2**1.5*gamma(2.5)
    for coefficient in slope:
        probability_at_angle = quad(lambda radial: ndtr(coefficient*radial)*radial**4*np.exp(-radial**2/2)/norm,0,np.inf,
                                    epsabs=1e-14,epsrel=3e-13)[0]
        direct.append(probability_at_angle)
    np.testing.assert_allclose(probability, weights@direct,rtol=0,atol=1e-13)
    return np.array([mean, spread, conditional, probability])


def main():
    ref, times, _, metric, _ = prepare("heavy",0)
    modes = ref.k
    power = bank("volume-state")
    width = np.diff(np.log(modes))
    weights = .5*(np.r_[width,0]+np.r_[0,width])*power["primordial_power"][np.isin(power["k_Mpc_inverse"],modes)]
    source_tide = -modes**2*metric[:,np.where(times==AI)[0].item()]*top(modes*ref.radius)
    rows = []
    by_case = {}
    for branch in ("heavy","cold"):
        seed, scales, _, rate, _ = build(branch)
        for stop in (32,64,128):
            accumulated = simpson(rate[:,:stop+1],x=np.log(scales[:stop+1]),axis=1)
            for fraction in (.5,1.,2.):
                radius = fraction*seed.radius
                kernel = 7.5*spherical_jn(2,modes*radius,derivative=True)*accumulated/(modes*radius)
                by_case[(stop,fraction,branch)] = kernel
    for stop in (32,64,128):
        for fraction in (.5,1.,2.):
            heavy = by_case[(stop,fraction,"heavy")]
            cold = by_case[(stop,fraction,"cold")]
            for label, kernel in (("heavy",heavy),("cold",cold),("paired_heavy_minus_cold",heavy-cold)):
                fixed = stats(kernel,source_tide,weights)
                first = principal(fixed["per_positive_rms"],fixed["remaining_rms"],24)
                second = principal(fixed["per_positive_rms"],fixed["remaining_rms"],40)
                np.testing.assert_allclose(first,second,atol=2e-14,rtol=2e-13)
                rows.append(dict(branch=label,a=scales[stop],fraction=fraction,mean_axis_difference_over_R=second[0],
                                 ensemble_std=second[1],scatter_at_known_full_tide=second[2],probability_positive=second[3],
                                 fixed_axis_mean_per_rms=fixed["per_positive_rms"],fixed_axis_unexplained_rms=fixed["remaining_rms"]))
    table("tide-principal-axes.csv",rows)
    for row in rows:
        if row["fraction"]==1 and row["branch"]=="paired_heavy_minus_cold":
            print(row)


if __name__=="__main__":
    main()
