"""First finite-monopole tangent of continuity and the velocity-potential equation."""
from formation_tide import AI, bank, leggauss, np, prepare, spherical_jn, table, top


def profiles(radius, modes, transfer, degree):
    arg = radius*modes
    bessel = spherical_jn(degree,arg)
    prime = modes*spherical_jn(degree,arg,derivative=True)
    lap = -modes**2*bessel
    return np.array([bessel@transfer, prime@transfer, lap@transfer])


def main():
    ref, times, _, metric, _ = prepare("heavy",0)
    slot = np.where(times==AI)[0].item()
    modes = ref.k
    width = np.diff(np.log(modes))
    vol = bank("volume-state")
    measure = (np.r_[width,0]+np.r_[0,width])*.5*vol["primordial_power"][np.isin(vol["k_Mpc_inverse"],modes)]
    source = -modes**2*metric[:,slot]*top(modes*ref.radius)
    shear = measure*source/np.sqrt(measure@source**2/5)
    angular, weights = leggauss(32)
    legendre = (3*angular**2-1)/2
    gradient = -3*angular*np.sqrt(1-angular**2)
    project = lambda field: 2.5*(weights*legendre)@field
    rows=[]
    for branch in ("heavy","cold"):
        seed, _, fields, lapse, _ = prepare(branch,0)
        for species,(dens,theta) in fields.items():
            quantum = 1/(2*(AI*seed.mass)**2) if species=="wave" else 0.
            for frac in (.5,1.,2.):
                rad = seed.radius*frac
                rho0,grad0,lap0 = profiles(rad,modes,2*seed.weights*dens[:,slot],0)
                rho2,grad2,lap2 = profiles(rad,modes,-shear*dens[:,slot],2)
                _,vel0,div0 = profiles(rad,modes,-2*seed.weights*theta[:,slot]/modes**2,0)
                potential,vel2,div2 = profiles(rad,modes,shear*theta[:,slot]/modes**2,2)
                grav = -profiles(rad,modes,-shear*lapse[:,slot],2)[0]
                number = 1+rho0
                advective = -vel0*vel2
                density_rate = -number*div2-rho2*div0-grad0*vel2-grad2*vel0
                wave_pressure = quantum*(lap2/(2*number)-lap0*rho2/(2*number**2)
                                -grad0*grad2/(2*number**2)+grad0**2*rho2/(2*number**3))
                euler = grav + advective + wave_pressure
                homogeneous_euler = grav+quantum*lap2/2
                def direct(strength):
                    number_total = number+strength*rho2*legendre
                    nrad = grad0+strength*grad2*legendre
                    npolar = strength*rho2*gradient/rad
                    nlap = lap0+strength*lap2*legendre
                    urad = vel0+strength*vel2*legendre
                    upolar = strength*potential*gradient/rad
                    ulap = div0+strength*div2*legendre
                    de = -number_total*ulap-urad*nrad-upolar*npolar
                    root_laplacian = nlap/(2*number_total)-(nrad**2+npolar**2)/(4*number_total**2)
                    ve = -.5*(urad**2+upolar**2)+strength*grav*legendre+quantum*root_laplacian
                    return np.array([project(de),project(ve)])
                eps=3e-4
                numeric=(direct(eps)-direct(-eps))/(2*eps)
                signed=np.array([density_rate,euler])
                error=np.max(abs(numeric/signed-1))
                assert error<2e-8
                rows.append(dict(branch=branch,species=species,fraction=frac,density0_minus_one=rho0,
                        tide_density_rate=density_rate,homogeneous_density_rate=-div2,
                        density_rate_fractional_change=density_rate/(-div2)-1,
                        euler_potential_rate_plus_drag=euler,common_gravity=grav,convective_term=advective,
                        wave_gradient_term=wave_pressure,homogeneous_wave_gradient_term=quantum*lap2/2,
                        euler_fractional_change=euler/homogeneous_euler-1,direct_tangent_fractional_error=error))
    table("finite-monopole-tangent.csv",rows)
    for row in rows:
        if row["fraction"]==1 and (row["species"]=="wave" or (row["branch"]=="cold" and row["species"]=="cdm")):
            print(row)


if __name__=="__main__":
    main()
