from common import *
from transport import potential_data,basis_info,project,interval
from scipy.linalg import eigh
from scipy.special import roots_legendre

def run():
    extent=.137;a=.73;h=.01123;size=48
    nodes=np.arange(64)*h
    factor=.00027*(1+.61*np.sin(65*nodes))
    phi=np.r_[-.0001,-.0001+np.cumsum(.5*factor[:-1]*np.diff(nodes**2))]
    active=3.3e2
    cuts=np.unique(np.r_[0,a*nodes[a*nodes<extent],extent])
    pts,w=roots_legendre(72);half=np.diff(cuts)[:,None]*.5
    rad=(cuts[:-1,None]+half*(1+pts)).ravel();weights=(half*w).ravel()
    vals,coeff=potential_data(a,h,active,phi,factor,extent,size,rad)
    raw=lambda r:phi[np.floor(r/(a*h)).astype(int)]+.5*factor[np.floor(r/(a*h)).astype(int)]*((r/a)**2-(np.floor(r/(a*h))*h)**2)
    direct=C**2*(raw(rad)-raw(extent))-.5*active*(rad**2-extent**2)
    c2=(weights*direct)@np.cos(rad[:,None]*np.arange(2*size+1)*np.pi/extent)/extent
    err_c=np.max(abs(c2-coeff))/np.max(abs(c2))
    extent=1.;kap=1.;hub=1.;count=24
    rad=np.linspace(0,extent,2049)
    freq=np.array([3.2,7.7]);energy=.5*freq**2
    amps=np.array([.8+.2j,-.24+.65j])
    wave=np.sin(rad[:,None]*freq)@amps
    rate=np.sin(rad[:,None]*freq)@(-1j*energy*amps)
    grad=(freq*np.cos(extent*freq))@amps
    norm_dot=2*simpson(np.real(wave.conj()*rate),x=rad)
    fluid_error=abs(norm_dot+np.imag(wave[-1].conjugate()*grad))
    wv,diff,sums,der=basis_info(extent,count)
    q=project(wave,extent,count);dq=project(rate,extent,count)
    inside=2*np.vdot(q[:2],dq[:2]).real
    source=kap*np.imag(np.sum(q[:2].conj()*der[:2]*wave[-1]))
    edge_error=abs(source-inside)/max(abs(source),1e-12)
    scale=np.linspace(-2,3,count)
    perturb=.1*np.exp(-abs(np.arange(count)[:,None]-np.arange(count))/8);pos=np.diag(scale)
    def frame(time,shift):
        vals,vec=eigh(pos+time*perturb+shift*np.eye(count));ampl=np.stack([q@vec,q@vec])
        return dict(a=np.exp(time),states=vec,levels=vals,amps=ampl,count=int(sum(vals<0)),q=np.stack([q,q]),
                    flux=np.zeros(2),norm=np.ones(2),bterm=np.zeros_like(ampl),res=np.zeros_like(ampl),cos=np.zeros(2*count+1))
    from transport import operator_increment
    eps=1e-5
    original=frame(0.,0.);end=frame(eps,0.);begin=frame(-eps,0.)
    bound=lambda f:np.sum(abs(f["amps"][0,:f["count"]])**2)
    direct_rate=(bound(end)-bound(begin))/(2*eps)
    pr_error=abs(direct_rate-operator_increment(original,perturb,original["count"])[0])/max(abs(direct_rate),1e-10)
    cross=interval(original,frame(eps,.5),extent,count)
    assert abs(cross["threshold"][0])>1e-8
    errs=dict(potential_cosine=err_c,aperture_current_absolute=fluid_error,open_Dirichlet_projection=edge_error,
              projector_derivative=pr_error,rank_jump_identity=abs(cross["change_negative"][0]-cross["state"][0]-cross["metric"][0]-cross["threshold"][0]))
    assert max(errs.values())<TOL,errs
    note("analytic-controls.json",errs);print(errs)
if __name__=="__main__":run()

