from common import *
from scipy.special import roots_legendre

CHANNELS=("full","tag100","rest100","tag200","rest200")
OBS=("aperture100","aperture200","gravity_mass100","gravity_mass200","lapse_over_coeff")
def channels(array):
    return np.stack([array[0],array[1],array[0]-array[1],array[2],array[0]-array[2]])
def weights(lab,a,n):
    rad=lab.r[:n]
    result=[]
    for extent in EXTENTS:
        result.append(lab.h*np.clip(.5+(extent/a-rad)/lab.h,0,1))
    for extent in EXTENTS:
        j=int((extent/a)/lab.h)
        result.append(lab.h*extent**3/(a**3*lab.stiffness[j]*lab.square_width[j])*(np.arange(n)<=j))
    fraction=lambda extent:np.clip(((extent/a)**2-rad**2)/lab.square_width[:n],0,1)
    shell=(fraction(.2)-fraction(.1))/(2*a*lab.stiffness[:n])
    result.append(lab.h*np.cumsum(shell[::-1])[::-1])
    return np.asarray(result)
def base(lab,n):
    background=np.zeros((len(CHANNELS),len(OBS),n))
    background[[0,2,4],2:,:]=lab.r[:n]**2
    return background
def score(weights,background,rho):
    return np.einsum("on,con->co",weights,rho[:,None,:]-background)
def observe(lab,state,start_w,end_w,dt,phi,mid,n,counts):
    phase=np.exp(-.5j*lab.seed.mass*dt*phi)
    initial=state*phase[None,:]
    linear=np.array([[1.],[0.],[0.]])
    coeff=dst(initial[:,1:-1]-linear*lab.r[1:-1],type=1,axis=-1)/lab.n
    omega=dt*lab.k**2/(2*lab.seed.mass*mid**2)
    def reconstruct(s,with_force=False):
        v=lab.n*coeff[:,None,:]*np.exp(-1j*s[:,None]*omega)
        def physical(arr,has_ramp):
            vals=np.zeros((3,len(s),n),complex)
            vals[:,:,1:]=idst(arr,type=1,axis=-1)[:,:,:n-1]
            if has_ramp:vals[0]+=lab.r[:n]
            return channels(vals)
        out=physical(v,True)
        if with_force:return out,physical(v*lab.k**2,False)
        return out
    initial_density=abs(channels(initial[:,:n]))**2
    final_density=abs(reconstruct(np.ones(1))[:,0,:])**2
    bg=base(lab,n)
    mean_w=.5*(start_w+end_w)
    geometry=score(end_w-start_w,bg,.5*(initial_density+final_density))
    direct=score(end_w,bg,final_density)-score(start_w,bg,initial_density)
    integrated={}
    for count in counts:
        if count not in quadrature:
            nodes,w=roots_legendre(count);quadrature[count]=(.5*(1+nodes),.5*w)
        nodes,w=quadrature[count]
        value,operator=reconstruct(nodes,True)
        rhs=dt/(lab.seed.mass*mid**2)*np.einsum("t,ctn->cn",w,np.imag(value.conj()*operator))
        integrated[count]=rhs@mean_w.T
    return direct,geometry,integrated,score(start_w,bg,initial_density),score(end_w,bg,final_density)

quadrature={}
def run(level,rate,counts):
    lab,ends,steps=prepare("heavy",level)
    previous=.65;n=int(.2/(previous*lab.h))+5;blocks=[];first=None
    counts=tuple(sorted(counts))
    for target,fixture in ends:
        guard()
        num=int(np.ceil(steps*rate*np.log(target/previous)));delta=np.log(target/previous)/num
        geom=np.zeros((5,5));tot=np.zeros_like(geom);work={num:np.zeros_like(geom) for num in counts};absolute=np.zeros_like(geom)
        start=None
        for index in range(num):
            if index%32==0:guard()
            lo=previous*np.exp(index*delta);hi=target if index+1==num else previous*np.exp((index+1)*delta)
            mid=np.sqrt(lo*hi);dt=np.log(hi/lo)/lab.seed.H(mid)
            field=lab.source(mid)
            state=np.zeros((3,lab.n+1),complex);state[0]=lab.r*lab.psi;state[1:,1:-1]=lab.tags
            diff,move,flows,old,new=observe(lab,state,weights(lab,lo,n),weights(lab,hi,n),dt,field.potential,mid,n,counts)
            if start is None:start=old
            if first is None:first=old
            tot+=diff;geom+=move
            for order in counts:work[order]+=flows[order]
            absolute+=abs(move)+abs(flows[counts[-1]])
            lab.advance(lo,hi)
        ref=read_npz(checked(fixture+".npz"))
        if not level and rate==1:assert np.linalg.norm((lab.psi-ref["psi"])*lab.r)<1e-9
        now=np.zeros((3,n),complex);now[0]=lab.r[:n]*lab.psi[:n];now[1:,1:]=lab.tags[:,:n-1]
        final=score(weights(lab,target,n),base(lab,n),abs(channels(now))**2)
        assert np.max(abs(final-new))<1e-10
        for j,name in enumerate(CHANNELS):
            for k,kind in enumerate(OBS):
                denom=absolute[j,k] or 1
                for order in counts:
                    blocks.append(dict(a0=previous,a1=target,kind=kind,channel=name,order=order,
                        initial=start[j,k],final=final[j,k],kinetic_current=work[order][j,k],
                        moving_window=geom[j,k],absolute_work=absolute[j,k],
                        defect_over_work=(final[j,k]-start[j,k]-geom[j,k]-work[order][j,k])/denom,
                        endpoint_telescope=(final[j,k]-start[j,k]-tot[j,k])/denom))
        previous=target
    table(f"heavy-g{level}-t{rate}-action-current-q{counts[-1]}.csv",blocks)
    print(level,rate,counts,"action current closed",flush=True)
if __name__=="__main__":run(int(sys.argv[1]),int(sys.argv[2]),tuple(map(int,sys.argv[3:])))

