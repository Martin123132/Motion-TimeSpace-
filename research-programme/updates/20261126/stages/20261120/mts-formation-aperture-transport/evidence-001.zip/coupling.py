from common import *

def analytic_density(dens,background,extent,coeff,a):
    lim=512 if extent==.1 else 1024
    observed=simpson(dens[:lim+1],x=NODES[:lim+1])
    excess=observed-(extent/a)**3/3 if background else observed
    return -C**2*coeff*excess/(2*extent**2)

def lapse(dens,background,coeff,a):
    small,large=EXTENTS
    inner=(1/small-1/large)*simpson(dens[:513],x=NODES[:513])
    outer=simpson(dens[512:]*(1/NODES[512:]-1/large),x=NODES[512:])
    return .5*coeff*(inner+outer-((large**2-small**2)/(6*a**3) if background else 0))

def galerkin(dens,homog,coeff,a,h):
    limit=int((.2/a)/h)+1
    rad=np.arange(limit)*h
    vals=CubicSpline(NODES,dens)(a*rad)
    nodal=coeff*h*(a*vals-(rad**2 if homog else 0))
    square=h*(2*rad+h)
    stiff=4*(rad**4*h+2*rad**3*h**2+2*rad**2*h**3+rad*h**4+h**5/5)/square**2
    inc=np.cumsum(nodal)/(2*a*stiff)
    factor=2*inc/square
    primitive=np.r_[0,np.cumsum(inc)]
    g=[];potential=[]
    for extent in EXTENTS:
        pos=extent/a;cell=int(pos/h)
        g.append(-C**2*factor[cell]*pos/a)
        potential.append(primitive[cell]+.5*factor[cell]*(pos**2-rad[cell]**2))
    return np.array([*g,potential[1]-potential[0]])

def analyze(level,rate):
    prefix=f"heavy-g{level}-t{rate}";rows=[];uniform=[]
    for segment in range(6):
        raw=read_npz(HERE/f"{prefix}-samples-{segment}.npz")
        for index in ([0,-1] if segment==0 else [-1]):
            a=raw["a"][index];h=raw["h"][index];coeff=raw["coeff_h"][index]
            waves=raw["field"][index];ref=waves[0]
            complete=lambda dens,bg:np.array([*(analytic_density(dens,bg,b,coeff,a) for b in EXTENTS),lapse(dens,bg,coeff,a)])
            for which in (1,2):
                tag=waves[which];rest=ref-tag
                cross=2*np.real(tag.conj()*rest)
                for method,fn in (("continuous",complete),("metric",lambda dens,bg:galerkin(dens,bg,coeff,a,h))):
                    full=fn(abs(ref)**2,True)
                    pop=fn(abs(tag)**2,False);comp=fn(abs(rest)**2,True);interference=fn(cross,False)
                    assert np.max(abs(full-pop-comp-interference)/np.maximum(1e-17,abs(full)))<1e-10
                    for name,x,y,z,w in zip(("g100_kms2_Mpc","g200_kms2_Mpc","delta_Phi_over_c2"),full,pop,comp,interference):
                        rows.append(dict(a=a,initial_tag_kpc=100*which,method=method,observable=name,full=x,tag=y,complement_minus_background=z,interference=w))
            uniform.extend((a,value) for value in complete(NODES**2/a**3,True))
    assert max(abs(value) for a,value in uniform)<1e-7
    table(prefix+"-source-to-metric.csv",rows)
if __name__=="__main__":
    for g,t in ((0,1),(1,1),(0,2),(1,2)):analyze(g,t)

