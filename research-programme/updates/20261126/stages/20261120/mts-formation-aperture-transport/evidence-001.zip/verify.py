from common import *

def aggregate():
    metrics=[];population=[];force=[]
    for g,t in ((0,1),(1,1),(0,2),(1,2)):
        for model in ("heavy","cold"):
            prefix=f"{model}-g{g}-t{t}"
            receipt=json.loads((HERE/(prefix+"-receipt.json")).read_bytes())
            assert len(receipt)==6 and receipt[-1]["a"]==END
            if g==0 and t==1:assert max(block["sheet_relative_to_predecessor"] for block in receipt)<1e-11
            for kind in ("longitudinal","path"):
                if kind=="path" and (g,t) not in ((0,1),(1,2)):continue
                records=read(prefix+"-"+kind+"-constraint.csv")
                total=[r for r in records if r["species"]=="total"];assert len(total)==6
                phy="physical_current" if kind=="longitudinal" else "physical_transport"
                via="action_current" if kind=="longitudinal" else "metric_transport"
                abs1="physical_abs" if kind=="longitudinal" else "abs_physical"
                abs2="action_abs" if kind=="longitudinal" else "abs_metric"
                entries={}
                for field,rate,den in (("continuum",phy,abs1),("metric",via,abs2),("metric",phy,abs1)):
                    defects=np.array([(float(r[field+"_end"])-float(r[field+"_start"])-float(r[rate]))/float(r[den]) for r in total])
                    entries[field+"_vs_"+rate+"_peak"]=max(abs(defects))
                    if kind=="path" and field=="metric" and rate==via:assert max(abs(defects))<TOL
                metrics.append(dict(model=model,g=g,t=t,method=kind,initial_potential_contrast=float(total[0]["metric_start"])/.65,
                       final_potential_contrast=float(total[-1]["metric_end"])/END,peak_continuum_vs_physical=list(entries.values())[0],
                       peak_metric_vs_action=list(entries.values())[1],peak_metric_vs_physical=list(entries.values())[2]))
            if model=="cold":
                cold=read(prefix+"-particles.csv");assert len(cold)==28
                for r in cold:
                    inside=float(r["inside"]);neg=float(r["negative"])
                    assert -1e-12<=neg<=inside+1e-11 and abs(inside-(1+float(r["entered"])-float(r["left"])))<1e-11
                    if float(r["a"])==END:population.append(dict(g=g,t=t,species=r["species"],kpc=r["kpc"],inside=inside,
                               negative=neg,nonnegative_inside=inside-neg,net_outside=1-inside,change_of_subspace="",rank_jumps="",state_term=""))
        prefix=f"heavy-g{g}-t{t}"
        full=read(prefix+"-basis160-transport.csv");other=read(prefix+"-basis96-transport.csv")
        assert len(full)==len(other)==4
        for x,y in zip(full,other):
            assert (x["kpc"],x["state_kind"])==(y["kpc"],y["state_kind"])
            assert abs(float(x["final_negative"])-float(y["final_negative"]))<TOL
            assert abs(float(x["change_negative"])-sum(float(x[key]) for key in ("state","metric","threshold")))<1e-10
            if x["state_kind"]=="tag":
                inside=float(x["final_inside"]);neg=float(x["final_negative"])
                assert 0.<neg<=inside<=1.
                population.append(dict(g=g,t=t,species="wave",kpc=x["kpc"],inside=inside,negative=neg,
                       nonnegative_inside=inside-neg,net_outside=1-inside,change_of_subspace=x["metric"],rank_jumps=x["threshold"],state_term=x["state"]))
                if (g,t)==(0,1):
                    prev=[r for r in csv.DictReader(checked("tag-wave-split.csv").read_text().splitlines()) if float(r["a"])==END and r["kpc"]==x["kpc"]][0]
                    assert abs(inside-float(prev["endpoint_inside_fraction"]))<TOL and abs(neg-float(prev["endpoint_return_fraction"]))<TOL
        action=read(prefix+"-action-current-q8.csv")
        assert len(action)==300
        used=[abs(float(r["defect_over_work"])) for r in action if r["order"]=="8"]
        assert max(used)<TOL,(g,t,max(used))
        lapse=read(prefix+"-source-to-metric.csv")
        assert len(lapse)==84
        for row in lapse:
            assert abs(float(row["full"])-sum(float(row[k]) for k in ("tag","complement_minus_background","interference")))<1e-8*max(1e-16,abs(float(row["full"])))
        curr=read(prefix+"-current-to-lapse.csv")
        selected=[r for r in curr if r["kind"]=="delta_Phi_over_c2" and r["channel"]=="full"]
        assert len(selected)==6
        abs_work=sum(float(r["absolute_work"]) for r in selected)
        force.append(dict(g=g,t=t,initial=selected[0]["initial"],final=selected[-1]["final"],
              normalized_physical_current_defect=(float(selected[-1]["final"])-float(selected[0]["initial"])-sum(float(r["integrated_physical_source"]) for r in selected))/abs_work,
              max_discrete_current_defect=max(used)))
    table("constraint-summary.csv",metrics);table("population-summary.csv",population);table("metric-transfer-summary.csv",force)

def impulses():
    pre=read("frozen-impulse-matrix.csv");post=read("independent-impulse-test.csv")
    assert len(pre)==252 and len(post)==576
    results=[]
    for model in ("heavy","cold"):
        for at in ("start","end"):
            for level in (0,1):
                frozen=[r for r in pre if r["model"]==model and r["epoch"]==at and int(r["level"])==level and r["species"]=="total"]
                matrix=np.array([float(r["predicted_per_log_a"]) for r in frozen]).reshape(3,3)
                cont=np.array([float(r["continuum_per_log_a"]) for r in frozen]).reshape(3,3)
                assert np.max(abs(matrix-matrix.T))<1e-10 and min(np.linalg.eigvalsh(cont))>0 and cont[0,2]==0==cont[2,0]
                selected=[r for r in post if r["model"]==model and r["epoch"]==at and int(r["level"])==level]
                assert len(selected)==72
                for dt in sorted(set(float(r["logstep"]) for r in selected)):
                    actual=[r for r in selected if float(r["logstep"])==dt]
                    peak=max(abs(float(r["normalized_error"])) for r in actual)
                    nonnull=[abs(float(r["relative_error"])) for r in actual if {int(r["drive"]),int(r["readout"])}!={0,2} and r["relative_error"]]
                    results.append(dict(model=model,epoch=at,level=level,logstep=dt,n=len(actual),max_normalized_error=peak,
                      max_nonnull_relative_error=max(nonnull),passed=sum(abs(float(r["normalized_error"]))<=TOL for r in actual),
                      separated_continuum=0,mesh_normalized_disjoint=matrix[0,2]/np.sqrt(matrix[0,0]*matrix[2,2]),
                      overlapping_normalized=matrix[0,1]/np.sqrt(matrix[0,0]*matrix[1,1])))
    table("impulse-summary.csv",results)

def main():
    for name in FILES:checked(name)
    controls=json.loads((HERE/"analytic-controls.json").read_bytes());assert max(controls.values())<TOL
    aggregate();impulses()
    assert digest(HERE/"frozen-impulse-matrix.csv")=="a62ba28963a52338f5470d2f2c43a42a6741b4648ec4b16368172eb4aa18ba3a"
    assert digest(HERE/"frozen-local-impulses.csv")=="429bba40f53dbdc4c9ac84970585fe1d1fe1cd699476c5b26810022411978e82"
    frozen={(r["model"],r["epoch"],r["level"],r["method"],r["readout"],r["drive"]):float(r["prediction"])
            for r in read("frozen-local-impulses.csv") if r["species"]=="total"}
    result=[]
    for model in ("heavy","cold"):
        for epoch in ("start","end"):
            for level in ("0","1"):
                stems=f"{model}-{epoch}-g{level}-local-impulse-"
                samples=read(stems+"test.csv")+read(stems+"short.csv")
                assert len(samples)==126*(2 if model=="heavy" else 1)
                for method in sorted({r["method"] for r in samples}):
                    for dt in sorted({float(r["logstep"]) for r in samples}):
                        part=[r for r in samples if r["method"]==method and float(r["logstep"])==dt]
                        assert len(part)==18
                        for r in part:assert float(r["prediction"])==frozen[model,epoch,level,method,r["readout"],r["drive"]]
                        null=[r for r in part if {r["drive"],r["readout"]}=={"0","2"}]
                        if method=="local":assert all(float(r["prediction"])==0 for r in null)
                        worst=max(abs(float(r["normalized_error"])) for r in part)
                        if method=="local" and dt<=7.8125e-8:assert worst<TOL
                        result.append(dict(model=model,epoch=epoch,level=level,method=method,logstep=dt,
                              passed=sum(abs(float(r["normalized_error"]))<=TOL for r in part),tested=len(part),
                              peak_normalized_error=worst,peak_disjoint_response=max(abs(float(r["normalized_response"])) for r in null)))
    table("local-impulse-summary.csv",result)
    assert digest(HERE/"frozen-compact-impulses.csv")=="2e1903f29ac5aba50a1c4c45abbd1a7147a4829ff0542c1543a2c84eaf24f527"
    compact={(r["epoch"],r["level"],r["method"],r["readout"],r["drive"]):float(r["prediction"])
             for r in read("frozen-compact-impulses.csv") if r["species"]=="total"}
    trials=[r for at in ("start","end") for g in (0,1) for r in read(f"heavy-{at}-g{g}-local-impulse-compact.csv")]
    assert len(trials)==288 and len(compact)==72
    for r in trials:
        assert float(r["prediction"])==compact[r["epoch"],r["level"],r["method"],r["readout"],r["drive"]]
        assert abs(float(r["normalized_error"]))<=TOL
        if {r["readout"],r["drive"]}=={"0","2"}:assert float(r["prediction"])==0.
    assert not any(p.name=="__pycache__" for p in HERE.iterdir())
    hashes={p.name:digest(p) for p in sorted(HERE.iterdir()) if p.is_file() and p.name!="seal.json"}
    record=dict(parent_sha256=SEAL,parent_file_count=len(FILES),files=hashes)
    if sys.argv[1:]==["seal"]:note("seal.json",record)
    if sys.argv[1:]!=["tables"]:assert json.loads((HERE/"seal.json").read_bytes())==record
    print(len(hashes),"local,",len(FILES),"upstream")
if __name__=="__main__":main()

