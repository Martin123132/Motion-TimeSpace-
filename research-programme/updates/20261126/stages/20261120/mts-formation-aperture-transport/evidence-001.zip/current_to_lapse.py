from common import *
from coupling import analytic_density,lapse

def run(level,rate):
    prefix=f"heavy-g{level}-t{rate}"
    output=[];last=None
    for group in range(6):
        data=read_npz(HERE/f"{prefix}-samples-{group}.npz")
        a=data["a"];coef=data["coeff_h"][0]
        rad=NODES[512:]
        packed=[]
        for i in range(len(a)):
            fields=data["field"][i]
            deriv=CubicSpline(NODES,fields,axis=-1)(rad,1)
            chan=lambda arr:np.stack([arr[0],arr[1],arr[0]-arr[1],arr[2],arr[0]-arr[2]])
            full=chan(fields)
            current=data["kappa"][i]/data["hub"][i]*np.imag(full[:,512:].conj()*chan(deriv))
            edgeflux=current[:,[0,-1]]
            source=np.array([1.,0.,1.,0.,1.])
            low,high=EXTENTS
            rate_lapse=.5*coef*(-simpson(current/rad**2,x=rad,axis=1)+source*(high**2-low**2)/(2*a[i]**3))
            density=abs(full)**2
            current_lapse=np.array([lapse(dens,background,coef,a[i]) for dens,background in zip(density,source)])
            forces=np.array([[analytic_density(dens,bg,b,coef,a[i]) for b in EXTENTS] for dens,bg in zip(density,source)])
            rates=C**2*coef/2*(edgeflux-source[:,None]*(np.array(EXTENTS)/a[i])**3)/(np.array(EXTENTS)**2)
            packed.append((a[i],np.column_stack([forces,current_lapse]),np.column_stack([rates,rate_lapse])))
        if last is not None:packed.insert(0,last)
        last=packed[-1]
        epochs,val,rhs=map(np.array,zip(*packed))
        delta=np.log(epochs[1:]/epochs[:-1])
        steps=(rhs[1:]+rhs[:-1])*delta[:,None,None]/2
        for j,ch in enumerate(("full","tag100","rest100","tag200","rest200")):
            for k,obs in enumerate(("g100_kms2_Mpc","g200_kms2_Mpc","delta_Phi_over_c2")):
                acc=steps[:,j,k].sum();work=abs(steps[:,j,k]).sum()
                output.append(dict(a0=epochs[0],a1=epochs[-1],channel=ch,kind=obs,initial=val[0,j,k],final=val[-1,j,k],
                             integrated_physical_source=acc,absolute_work=work,defect_over_work=(val[-1,j,k]-val[0,j,k]-acc)/work if work else 0.))
    table(prefix+"-current-to-lapse.csv",output)
if __name__=="__main__":
    for level,rate in ((0,1),(1,1),(0,2),(1,2)):run(level,rate)

