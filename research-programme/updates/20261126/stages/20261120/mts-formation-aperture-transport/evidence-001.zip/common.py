import csv
import hashlib
import io
import json
import os
import sys
from pathlib import Path
for name in ("OPENBLAS_NUM_THREADS","OMP_NUM_THREADS","MKL_NUM_THREADS","BLIS_NUM_THREADS","NUMEXPR_NUM_THREADS"):
    os.environ[name]="1"
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
PARENT=HERE.parent/"mts-collisionless-sheet-infall-20261120"
SEAL="c4131a2bb4118b70dafb5cec48ced007e26a885fee58b881c6dfec2c9de940ee"
def digest(path):
    with path.open("rb") as stream:return hashlib.file_digest(stream,"sha256").hexdigest()
assert digest(PARENT/"seal.json")==SEAL
FILES=json.loads((PARENT/"seal.json").read_bytes())["files"]
def checked(name):
    path=PARENT/name
    assert digest(path)==FILES[name],path
    return path
for name in ("source.py","sheet.py","variational.py","binding.py","tagged.py","evolve.py","moments.py"):checked(name)
sys.path.insert(0,str(PARENT))
from source import np,read_npz,init,END,C,TOL
from tagged import Traced,anchors,intersect
from binding import hubble,metric_value,particles,weak_well
from variational import ActionSystem
from scipy.fft import dst,idst,dct
from scipy.interpolate import CubicSpline
from scipy.integrate import simpson
EXTENTS=(.1,.2)
NODES=np.linspace(0,.2,1025)
def guard():
    for path in (HERE,PARENT,HERE.parent):
        if (path/"STOP-REQUESTED").exists():raise RuntimeError("owner hold")
def put(name,raw):
    guard();path=HERE/name
    if path.exists():assert path.read_bytes()==raw,path
    else:
        with path.open("xb") as stream:stream.write(raw)
def save(name,payload):
    stream=io.BytesIO();np.savez_compressed(stream,**payload);put(name+".npz",stream.getvalue())
def note(name,items):put(name,(json.dumps(items,sort_keys=True,indent=2,allow_nan=False)+"\n").encode())
def table(name,rows):
    stream=io.StringIO(newline="")
    writer=csv.DictWriter(stream,rows[0],lineterminator="\n")
    writer.writeheader();writer.writerows(rows);put(name,stream.getvalue().encode())
def read(name):
    with (HERE/name).open(newline="") as stream:return list(csv.DictReader(stream))
def sine_double(vector):
    size=vector.shape[-1]+1
    return idst(np.pad(2*dst(vector,type=1,axis=-1),[(0,0)]*(vector.ndim-1)+[(0,size)]),type=1,axis=-1)
def prepare(model,refine):
    stem,ends,steps=anchors(model,"split")
    meta=json.loads(checked(stem+".json").read_bytes())
    seed,_=init(model,meta["spacing"],meta["box"],"restart")
    state=read_npz(checked(stem+".npz"))
    coarse=Traced(seed,state) if model=="heavy" else ActionSystem(seed,state)
    tags=None
    if model=="heavy":tags=np.stack([coarse.trace(ext*1000,.65)[0] for ext in EXTENTS])
    if refine:
        rad=state["r"];full=np.linspace(0,rad[-1],2*coarse.n+1)
        if model=="heavy":
            newpsi=np.empty(len(full),complex);newpsi[0]=state["psi"][0];newpsi[-1]=1.
            newpsi[1:-1]=1+sine_double(rad[1:-1]*(state["psi"][1:-1]-1))/full[1:-1]
            assert np.max(abs(newpsi[::2]-state["psi"]))<1e-9
            state["psi"]=newpsi
            tags2=sine_double(tags)
            assert np.max(abs(tags2[:,1::2]-tags))<1e-11
            tags=tags2
        state["r"]=full
        lab=Traced(seed,state) if model=="heavy" else ActionSystem(seed,state)
    else:lab=coarse
    if model=="heavy":lab.tags=tags
    return lab,ends,steps
def clock(a,seed):
    hub,acc=hubble(seed,a)
    return hub,acc,C/seed.mass

