from susceptibility import *
from variational import parts
from scipy.special import roots_legendre

def split(x,y,h,n):
    dx=y-x
    lo=np.clip(np.floor(np.minimum(x,y)/h).astype(int),-n,n-1)
    hi=np.maximum(lo,np.clip(np.ceil(np.maximum(x,y)/h).astype(int)-1,-n,n-1))
    counts=1+hi-lo
    ids=np.repeat(np.arange(len(dx)),counts)
    cells=lo[ids]+np.arange(len(ids))-np.repeat(np.cumsum(counts)-counts,counts)
    left=np.divide(cells*h-x[ids],dx[ids],out=np.zeros(len(ids)),where=dx[ids]!=0)
    right=np.divide((cells+1)*h-x[ids],dx[ids],out=np.ones(len(ids)),where=dx[ids]!=0)
    return ids,np.where(cells<0,-cells-1,cells),np.clip(np.minimum(left,right),0,1),np.clip(np.maximum(left,right),0,1)

def elements(lab,key):
    x,p,dm=lab.dust[key]
    ids,cells,f0,f1=split(x[:-1],x[1:],lab.h,lab.n)
    return ids,cells,f0,f1,dm[ids]/(ids**2+ids+1/3),x[ids]+f0*np.diff(x)[ids],x[ids]+f1*np.diff(x)[ids]

def deposit(lab,els,start,end):
    orig,cells,f0,f1,scale,x,y=els
    ix,bin_id,left,right=split(start,end,lab.h,lab.n)
    q=orig[ix]+f0[ix];dq=f1[ix]-f0[ix]
    mid=(left+right)*.5;half=(right-left)*.5
    qmid=q+dq*mid
    norm=scale[ix]*dq*(right-left)
    mu=norm*(qmid**2+(dq*half)**2/3)
    centered=norm*2*qmid*dq*half**2/3
    second=norm*(qmid**2*half**2/3+dq**2*half**4/5)
    delta=end[ix]-start[ix];avg=start[ix]+mid*delta;low=lab.r[bin_id]
    moment=((avg-low)*(avg+low)*mu+2*avg*delta*centered+delta**2*second)/lab.square_width[bin_id]
    assert min(np.min(mu-moment),np.min(moment))>-1e-10
    return np.r_[np.bincount(bin_id,mu-moment,minlength=lab.n),0.]+np.r_[0.,np.bincount(bin_id,moment,minlength=lab.n)]

def matrices(lab,weights,a,extended=False):
    _,_,original,continuum,_=build(lab,a);result={};local={}
    slope=2*np.diff(weights)/lab.square_width
    for key,(x,p,dm) in lab.dust.items():
        _,bins,mu,right,_,_=parts(x,dm,lab.h,lab.n)
        x2=right*lab.square_width[bins]+mu*lab.r[bins]**2
        local[key]=lab.seed.coeff[key]/a**2*((slope[:,bins]*x2)@slope[:,bins].T)
    for scheme in (("fourth","sixth") if extended else (("spectral","local") if lab.psi is not None else ("local",))):
        source=local.copy()
        if scheme in ("local","fourth","sixth") and lab.psi is not None:
            u=lab.r*lab.psi
            links={"local":(1.,),"fourth":(4/3,-1/12),"sixth":(1.5,-.15,1/90)}[scheme]
            wave=np.zeros((len(SHELLS),len(SHELLS)))
            for distance,coef in enumerate(links,1):
                dw=weights[:,distance:]-weights[:,:-distance]
                wave+=coef*((dw*np.real(u[:-distance].conj()*u[distance:]))@dw.T)
            source["wave"]=lab.seed.coeff["wave"]/(a*a*lab.h)*wave
        elif lab.psi is not None:source["wave"]=original["wave"]
        source["total"]=sum(source.values());result[scheme]=source
    return result

def freeze(extended=False):
    rows=[]
    for model in (("heavy",) if extended else ("heavy","cold")):
        for epoch in ("start","end"):
            for level in (0,1):
                seed,state,a=fixture(model,epoch,level);lab=ActionSystem(seed,state);weights=metric_weights(lab)
                for method,source in matrices(lab,weights,a,extended).items():
                    for key,matrix in source.items():
                        if method!="spectral" or key in lab.dust:assert matrix[0,2]==0 and matrix[2,0]==0
                        for j in range(3):
                            for k in range(3):rows.append(dict(model=model,epoch=epoch,level=level,method=method,species=key,readout=j,drive=k,
                                                                  prediction=matrix[j,k]/seed.H(a)))
    file="frozen-compact-impulses.csv" if extended else "frozen-local-impulses.csv"
    table(file,rows);print("frozen",digest(HERE/file),flush=True)

def solve(lab,load,a):
    delta=np.cumsum(load[:-1])/(2*a*lab.stiffness)
    phi=np.r_[-np.cumsum(delta[::-1])[::-1],0.]
    out=[]
    for x,y in SHELLS:
        def read(r):
            i=int(r/lab.h)
            return phi[i]+((r-lab.r[i])*(r+lab.r[i])/lab.square_width[i])*delta[i]
        out.append(a*(read(y)-read(x)))
    return np.array(out)

def experiment(model,epoch,level,short=False,extended=False):
    seed,state,a=fixture(model,epoch,level);lab=ActionSystem(seed,state);W=metric_weights(lab)
    els={key:elements(lab,key) for key in lab.dust};slopes=2*np.diff(W)/lab.square_width;rows=[];checks=[]
    old=lab.source(a)
    mass0=np.zeros(lab.n+1)
    for key,part in els.items():
        load=deposit(lab,part,part[-2],part[-1])
        assert abs(np.sum(load)-sum(lab.dust[key][2]))<1e-9
        mass0+=seed.coeff[key]*(load-lab.base)
    if lab.psi is not None:mass0+=seed.coeff["wave"]*lab.h*lab.r**2*(abs(lab.psi)**2-1)
    checks.append(float(max(abs(solve(lab,mass0,a)-metric(lab,a)))/max(abs(metric(lab,a)))))
    assert checks[-1]<1e-10
    file="frozen-compact-impulses.csv" if extended else "frozen-local-impulses.csv"
    stamp=digest(HERE/file)
    predicted={(r["method"],int(r["readout"]),int(r["drive"])):float(r["prediction"]) for r in read(file)
               if r["model"]==model and r["epoch"]==epoch and int(r["level"])==level and r["species"]=="total"}
    for dl in ((7.8125e-8,1.953125e-8) if extended else ((3.125e-7,7.8125e-8,1.953125e-8) if short else (8e-5,2e-5,5e-6,1.25e-6))):
        obs={}
        for direction in (1,-1):
            end=a*np.exp(direction*dl);mid=np.sqrt(a*end);dt=np.log(end/a)/seed.H(mid)
            field=lab.source(mid)
            local={}
            for key,(x,p,dm) in lab.dust.items():
                ids,cells,f0,f1,scale,l,r=els[key]
                half=p-.5*dt*field.ordered[key]
                delta=np.diff(half)[ids]
                local[key]=(l+dt/mid**2*(half[ids]+f0*delta),r+dt/mid**2*(half[ids]+f1*delta))
            for drive in range(3):
                maxgrad=max(abs(lab.r[1:]*slopes[drive]))
                for speed in (.03,.12):
                    strength=speed*a/(C*maxgrad)
                    positive={}
                    for sign in (1,-1):
                        load=np.zeros(lab.n+1);eps=sign*strength
                        for key,part in els.items():
                            ids,cells,f0,f1,scale,l,r=part;add=dt/mid**2*eps*slopes[drive,cells]
                            density=deposit(lab,part,local[key][0]+add*l,local[key][1]+add*r)
                            load+=seed.coeff[key]*(density-lab.base)
                        for method in (("fourth","sixth") if extended else (("spectral","local") if model=="heavy" else ("local",))):
                            source=load.copy()
                            if lab.psi is not None:
                                u=lab.r*lab.psi*np.exp(1j*seed.mass*(eps*W[drive]-.5*dt*field.potential))
                                ks=lab.k**2 if method=="spectral" else (2*np.sin(lab.k*lab.h/2)/lab.h)**2
                                sine2=np.sin(lab.k*lab.h/2)**2
                                if method=="fourth":ks*=1+sine2/3
                                if method=="sixth":ks*=1+sine2/3+8*sine2**2/45
                                u[1:-1]=lab.r[1:-1]+idst(dst((u-lab.r)[1:-1],type=1)*np.exp(-.5j*ks*dt/(seed.mass*mid**2)),type=1)
                                source+=seed.coeff["wave"]*lab.h*(abs(u)**2-lab.r**2)
                            idx=method,drive,speed
                            if idx not in obs:obs[idx]=np.zeros(3)
                            if short:
                                if sign==1:positive[method]=source
                                else:obs[idx]+=direction*solve(lab,positive[method]-source,end)/(4*dl*strength)
                            else:
                                obs[idx]+=direction*sign*solve(lab,source,end)/(4*dl*strength)
        for (method,drive,speed),value in obs.items():
            for j,measured in enumerate(value):
                pred=predicted[method,j,drive]
                sc=np.sqrt(abs(predicted[method,j,j]*predicted[method,drive,drive]))
                rows.append(dict(model=model,epoch=epoch,level=level,method=method,readout=j,drive=drive,logstep=dl,
                            speed_kms=speed,prediction=pred,measured=measured,normalized_error=(measured-pred)/sc,
                            normalized_response=measured/sc))
    assert digest(HERE/file)==stamp
    filename=f"{model}-{epoch}-g{level}-local-impulse-"+("compact" if extended else "short" if short else "test")+".csv"
    table(filename,rows)
    print(model,epoch,level,"local response checked",flush=True)

if __name__=="__main__":
    if sys.argv[1]=="freeze":freeze("--compact" in sys.argv)
    else:
        for at in ("start","end"):
            for level in (0,1):experiment(sys.argv[1],at,level,"--short" in sys.argv or "--compact" in sys.argv,"--compact" in sys.argv)

