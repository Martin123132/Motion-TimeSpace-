"""Analytical weak wave-response bound and prospective least/most responsive compact phases."""
from origin import AI,ROOT,Preparation,np,rows,sha,table
from scipy.linalg import eigh

AMPLITUDE=1e-6


def forecast():
    output=[];grams=[]
    for band in (16,20):
        p=Preparation("heavy",band,False,"saved")
        r=p.base.rad
        nn,_,grad,lap,_,_,a=p.motion(p.mono,0.)
        number=nn[p.target]
        loggrad=grad[0,p.target]/number
        logcurve=lap[0,p.target]/number-2*loggrad/r-loggrad**2
        test,slope,second,third=p.probes.transpose(1,0,2)
        laptest=second+2*slope/r-6*test/r**2
        radial=third+2*second/r-8*slope/r**2+12*test/r**3+logcurve*slope+loggrad*second
        angular=laptest+loggrad*slope
        weight=number*p.weight
        metric=(test*weight)@test.T
        response=(radial*weight)@radial.T+(angular*6*number*p.base.dr)@angular.T
        np.testing.assert_allclose(response,response.T,rtol=2e-14)
        values,basis=eigh(response,metric)
        lower=(6/16**2)**3
        assert np.min(values)>lower
        np.testing.assert_allclose(basis.T@metric@basis,np.eye(3),rtol=0,atol=1e-13)
        np.testing.assert_allclose(response@basis,(metric@basis)*values,rtol=2e-11,atol=1e-13)
        for left in range(3):
            for right in range(3):
                grams.append(dict(band=band,left=left,right=right,weighted_norm=metric[left,right],weighted_response=response[left,right]))
        for idx,eigen in enumerate(values):
            vec=basis[:,idx].copy()
            if vec[np.argmax(abs(vec))]<0:vec=-vec
            projected=-p.coeff[p.target]*AMPLITUDE*(response@vec)/(4*(a*p.mass)**2)
            output.append(dict(band=band,rank=idx,aperture_half=vec[0],aperture_ref=vec[1],aperture_twice=vec[2],
                               normalized_energy=eigen,analytic_lower_bound=lower,applied_velocity_scale=AMPLITUDE,
                               self_probe_third=vec@projected,half_probe_third=projected[0],ref_probe_third=projected[1],
                               twice_probe_third=projected[2]))
    table("compact-response-matrices.csv",grams)
    table("frozen-compact-bound.csv",output)
    print("bound freeze",sha(ROOT/"frozen-compact-bound.csv"))
    print([(r["rank"],r["normalized_energy"],r["self_probe_third"]) for r in output if r["band"]==20])


if __name__=="__main__":forecast()
