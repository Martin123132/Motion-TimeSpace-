from pathlib import Path
from origin import DLOG,OFFSETS,ROOT,WIDTHS,inputs,np,pinned,rows,table


def tag(model,band,uniform,drive,method,sub):
    return f"{model}-K{band}-{drive}-flat{int(uniform)}-{method}-n{sub}.npz"


def interp(nodes,values,order):
    from math import factorial
    extent=nodes[-1]
    matrix=np.vander(nodes/extent,N=len(nodes),increasing=True).T
    unit=np.zeros(len(nodes))
    unit[order]=factorial(order)/extent**order
    return np.linalg.solve(matrix,unit)@values


def evaluation(fields,durations,idx,slot):
    seq=fields[:,slot,:,idx].sum(axis=1)
    initial=interp(durations[:6],seq[:6],1)
    second=interp(durations[:6],seq[:6],2)
    return initial,second


def main():
    meta={(r["model"],int(r["band"]),int(r["uniform"]),r["drive"],r["case"],float(r["aperture"])):r for r in rows("frozen-weak-source.csv")}
    launch,budgets,controls,timecourse=[],[],[],[]
    for model,band,uniform,drive in inputs():
        with np.load(pinned(model+"-environment.npz")) as env:
            hub=env["hub"][np.flatnonzero(env["loga"]==0).item()]
        for method in ("strong","weak"):
            for sub in (2,4):
                with np.load(ROOT/tag(model,band,uniform,drive,method,sub)) as out:
                    assert tuple(out["scenario"])==("ordinary","balanced","balanced_dust","wave_difference")
                    eta=out["eta"];matter=out["moments"];profile=out["sources"]
                    signed=matter.sum(axis=2)
                    diff=signed[:,3]
                    subtraction=(matter[:,1]-matter[:,2]).sum(axis=1)
                    if model=="cold":assert not np.any(diff) and not np.any(subtraction)
                    for idx,width in enumerate(WIDTHS):
                        key=dict(model=model,band=band,uniform=int(uniform),drive=drive,method=method,sub=sub,aperture=width)
                        for slot,case in enumerate(("ordinary","balanced","balanced_dust")):
                            ref=meta[model,band,int(uniform),drive,"ordinary" if not slot else "balanced",width]
                            first,second=evaluation(matter,eta,idx,slot)
                            current,stress,scale=[float(ref[f]) for f in ("current","stress","component_current_scale")]
                            got=second+hub*first
                            alt=interp(eta[:5],signed[:5,slot,idx],2)+hub*interp(eta[:5],signed[:5,slot,idx],1)
                            launch.append(dict(**key,case=case,frozen_current=current,actual_current=first,
                                               current_error_on_component_scale=(first-current)/scale,
                                               frozen_stress=stress,actual_stress=got,alternate_stress=alt,
                                               stress_error_ppm=1e6*(got/stress-1) if stress else "",
                                               stress_abs_on_hubble_current_scale=abs(got-stress)/(hub*scale),
                                               zero_stress=not bool(stress)))
                        seq=6*diff[1:,idx]/eta[1:]**3
                        cubic=interp(eta[1:5],seq[:4],0)
                        short=interp(eta[1:4],seq[:3],0)
                        wave=float(ref["third_on_minus_off"])
                        budgets.append(dict(**key,third_frozen=wave,third_measured=cubic,
                                            wave_error_ppm=1e6*(cubic/wave-1) if wave else "",
                                            time_extrapolation_shift_ppm=1e6*(short/cubic-1) if cubic else "",
                                            static_null=(not cubic) if not wave else ""))
                        for point in range(1,len(eta)):
                            off=signed[point,2,idx]
                            total=signed[point,1,idx]
                            predicted=wave*eta[point]**3/6
                            extrap=float(ref["current"])*eta[point]+.5*float(ref["second"])*eta[point]**2
                            timecourse.append(dict(**key,offset=OFFSETS[point],eta=eta[point],dust_response=off,
                                                   wave_difference=diff[point,idx],wave_by_subtraction=subtraction[point,idx],
                                                   total_response=total,frozen_pressureless_to_second=extrap,
                                                   frozen_wave_to_third=predicted,wave_error_on_signal=predicted/diff[point,idx]-1 if wave else "",
                                                   wave_fraction_of_signed_total=diff[point,idx]/total if abs(total)>0 else ""))
                    if drive=="saved" and ((not uniform) or band==16):
                        cut="15.97" if band==16 else "19.90"
                        old_name=f"response-{model}-uniform{int(uniform)}-K{cut}-n8-w008.npz"
                        with np.load(pinned(old_name)) as old:
                            saved=old["series"][1,3,[0,4,5]]
                        for slot in range(3):
                            for idx,width in enumerate(WIDTHS):
                                val=saved[slot,idx];done=profile[-1,slot,idx];sc=abs(saved[0,idx])
                                controls.append(dict(**{**key,"aperture":width},case=("ordinary","balanced","balanced_dust")[slot],
                                                     epoch="1",saved=val,measured=done,error_on_ordinary=(done-val)/sc,
                                                     relative_to_saved=done/val-1 if abs(val)>1e-9*sc else ""))
    for name,records in (("launch-flux-stress.csv",launch),("wave-only-onset.csv",budgets),("early-sources.csv",timecourse),("sealed-epoch-replay.csv",controls)):
        table(name,records)
    for item in launch:
        if item["sub"]==4 and item["method"]=="strong" and item["band"]==20 and item["aperture"]==1 and item["drive"]=="saved" and item["case"]=="balanced_dust" and not item["uniform"]:
            print(item)
    for item in budgets:
        if item["sub"]==4 and item["method"]=="strong" and item["band"]==20 and item["aperture"]==1 and item["model"]=="heavy":
            print(item)


if __name__=="__main__":main()
