"""Pre-register when the cubic wave contribution could overtake the quadratic streaming term."""
from origin import AI,DLOG,PREV,ROOT,guard,np,pinned,rows,table,sha
from scipy.integrate import quad
from scipy.interpolate import CubicSpline
from scipy.optimize import brentq


def main():
    guard()
    with np.load(pinned("heavy-environment.npz")) as data:
        hub=CubicSpline(data["loga"],data["hub"],extrapolate=False)
    def eta(time):return quad(lambda x:1/hub(x),0,time,epsabs=2e-12)[0]
    outputs=[]
    for row in rows("frozen-weak-source.csv"):
        if row["model"]!="heavy" or row["uniform"]!="0" or row["case"]!="balanced":continue
        stress=float(row["second"]);wave=float(row["third_on_minus_off"])
        duration=3*abs(stress/wave)
        window=brentq(lambda x:eta(x)-duration,0,64*DLOG)/DLOG if duration<eta(64*DLOG) else ""
        outputs.append(dict(band=row["band"],drive=row["drive"],aperture=row["aperture"],eta_forecast=duration,
                            window_forecast=window,same_sign=stress*wave>0,frozen_stress=stress,frozen_wave=wave))
    table("frozen-wave-streaming-times.csv",outputs)
    print("scale freeze",sha(ROOT/"frozen-wave-streaming-times.csv"))
    for row in outputs:
        if row["band"]=="20":print(row["drive"],row["aperture"],row["eta_forecast"],row["window_forecast"],row["same_sign"])


if __name__=="__main__":main()
