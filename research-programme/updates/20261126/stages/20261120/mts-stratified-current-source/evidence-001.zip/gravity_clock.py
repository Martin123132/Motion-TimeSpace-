"""Read the crossover from total common gravity as well as from the density moment."""
from origin import AI,DLOG,ROOT,Preparation,guard,np,rows,sha,table
from evolution import rates
from scipy.integrate import quad
from scipy.interpolate import CubicSpline
from scipy.optimize import brentq


PIN="047203b1a227a88bad7214047bb14b76bfe29518dc9841fe919c7186385c5dac"


def read(p,state,time):
    base=p.base
    r=base.rad
    density=state[1]@base.value[1]
    selected=[1,2,3]
    source=np.einsum("s,xsr->xr",p.coeff,density[selected])/(2*AI*np.exp(time))
    density_moment=(source*p.weight)@p.probes[:,0].T/p.norm
    radial=[];polar=[]
    for item in source:
        inner=p.chart.cum(item*r**4,"left")
        outer=p.chart.cum(item/r,"right")
        phi=-(inner/r**3+r**2*outer)/5
        acceleration=(-3*inner/r**4+2*r*outer)/5
        radial.append((p.probes[:,1]*(p.weight*acceleration))@np.ones_like(r)/p.norm)
        polar.append(-6*(p.probes[:,0]*(base.dr*phi))@np.ones_like(r)/p.norm)
    return np.stack((density_moment,radial,polar))


def sample(p,method,count):
    base=p.base
    frac=(base.rad/base.edge-.7)/.3
    active=(frac>0)&(frac<1)
    p.cut_r=np.zeros_like(frac)
    p.cut_r[active]=-base.cut[active]*(1-base.cut[active])*(1/frac[active]**2+1/(1-frac[active])**2)/(.3*base.edge)
    state=p.mono.copy(),np.zeros_like(p.launch),p.launch.copy()
    end=2.5*DLOG
    step=end/count
    times=np.arange(count+1)*step
    records=[]
    for idx,now in enumerate(times):
        guard()
        records.append(read(p,state,now))
        if idx==count:break
        def shifted(change,increment):
            return tuple(value+increment*delta for value,delta in zip(state,change))
        one=rates(p,state,now,method)
        two=rates(p,shifted(one,step/2),now+step/2,method)
        three=rates(p,shifted(two,step/2),now+step/2,method)
        four=rates(p,shifted(three,step),now+step,method)
        state=tuple(value+step/6*(a+2*b+2*c+d) for value,a,b,c,d in zip(state,one,two,three,four))
    return times,np.stack(records)


def main():
    assert sha(ROOT/"frozen-wave-streaming-times.csv")==PIN
    tests={(int(r["band"]),r["drive"],float(r["aperture"])):r for r in rows("frozen-wave-streaming-times.csv")}
    summary=[];traces=[]
    for band in (16,20):
        for drive in ("saved","probe"):
            p=Preparation("heavy",band,False,drive)
            for method,count in (("strong",80),("strong",160),("weak",160)):
                times,values=sample(p,method,count)
                for idx,width in enumerate((.5,1.,2.)):
                    row=tests[band,drive,width]
                    eta_star=float(row["eta_forecast"]);xstar=DLOG*float(row["window_forecast"])
                    lo=next(i for i,x in enumerate(times) if x>=xstar/8)
                    for name,signal in (("density",values[:,0,: ,idx]),("force",values[:,1:,:,idx].sum(axis=1))):
                        signed=np.sign(float(row["frozen_wave"])) * signal[:,2] - np.sign(float(row["frozen_stress"])) * signal[:,1]
                        places=np.where((signed[lo:-1]<0)&(signed[lo+1:]>0))[0]+lo
                        assert len(places)==1,(row,name,places)
                        start=places[0]
                        spline=CubicSpline(times,signed,extrapolate=False)
                        root=brentq(spline,times[start],times[start+1],xtol=1e-15)
                        duration=quad(lambda x:1/p.chart.hc(x),0,root)[0]
                        sample_at=CubicSpline(times,signal,axis=0)(root)
                        assert sample_at[1]*float(row["frozen_stress"])>0 and sample_at[2]*float(row["frozen_wave"])>0
                        summary.append(dict(band=band,drive=drive,method=method,steps=count,aperture=width,readout=name,
                                            forecast_eta=eta_star,measured_eta=duration,forecast_window=xstar/DLOG,measured_window=root/DLOG,
                                            bracket_lower=times[start]/DLOG,bracket_upper=times[start+1]/DLOG,
                                            redshift=np.exp(-root)/AI-1,elapsed_error_ppm=(eta_star/duration-1)*1e6,
                                            streaming=sample_at[1],dispersion_difference=sample_at[2],balanced_total=sample_at[0]))
                    for point in range(count+1):
                        val=values[point,:,:,idx]
                        if count==160 and point>0:
                            for channel,case in enumerate(("on","off","wave_only")):
                                actual=val[0,channel]
                                direct=val[1,channel]+val[2,channel]
                                traces.append(dict(band=band,drive=drive,method=method,aperture=width,case=case,
                                                   window=times[point]/DLOG,gravity_moment_from_density=actual,
                                                   radial=val[1,channel],polar=val[2,channel],sum_of_force=direct,
                                                   difference_on_separate_channel_scale=(direct-actual)/max(abs(val[0,1]),abs(val[0,2]),1e-300)))
                print(band,drive,method,count,"complete",flush=True)
    table("measured-wave-streaming-times.csv",summary)
    table("gravity-flux.csv",traces)


if __name__=="__main__":main()
