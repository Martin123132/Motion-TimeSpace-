import json
import sys
from origin import CASES,OFFSETS,PREV,PIN,ROOT,guard,inputs,np,pinned,rows,sealed,sha
from assess import tag


def validate():
    guard()
    assert len(sealed)==198
    for name in sealed:pinned(name)
    frozen={
        "frozen-weak-source.csv":"1102db2669a5a69177630bb7b2f9ac6a8f8ea3069b8a3c29aa434e1a814ead7d",
        "frozen-wave-streaming-times.csv":"047203b1a227a88bad7214047bb14b76bfe29518dc9841fe919c7186385c5dac",
        "frozen-compact-bound.csv":"91299ec701f0886bbe07c9e6a133db8f51a4fbf3b6abf30418b444f65c5b6d29",
        "frozen-exterior-vs-interior.csv":"76a1dddd1cb4610770be934ab3b31446a0555c94ac7d3a62e2c5ec8659b68c2f",
        "frozen-fourth-derivative.csv":"52442f3bf12a037ac7587fe9edbdb25d56749c5b4dbb0531b4b01504b1739d2b"}
    for name,digest in frozen.items():assert sha(ROOT/name)==digest,name
    packs={tag(model,band,flat,drive,method,sub) for model,band,flat,drive in inputs() for method in ("weak","strong") for sub in (2,4)}
    packs.update(tag("heavy",band,False,"compact"+str(rank),method,4) for rank in range(3) for method in ("weak","strong") for band in (16,20))
    assert len(packs)==60 and packs=={p.name for p in ROOT.glob("*.npz")}
    for name in packs:
        with np.load(ROOT/name) as data:
            assert data["parent_seal"].item()==PIN and data["frozen_sha256"].item()==frozen["frozen-weak-source.csv"]
            assert data["parent_solver"].item()==sealed["radial_response.py"]
            np.testing.assert_array_equal(data["epochs"],OFFSETS)
            assert np.all(np.diff(data["eta"])>0) and data["eta"][0]==0
            assert tuple(data["scenario"])==CASES
            assert data["moments"].shape==(9,4,3 if name.startswith("heavy") else 2,3)
            assert np.isfinite(data["moments"]).all() and np.isfinite(data["sources"]).all()
            if name.startswith("cold"):assert not data["moments"][:,3].any()
    products={"compact-bound-tests":48,"compact-response-matrices":18,"early-sources":1152,"exterior-finite-time":432,
              "external-multipole-tests":24,"frozen-compact-bound":6,"frozen-exterior-vs-interior":6,"frozen-fourth-derivative":48,
              "frozen-wave-streaming-times":12,"frozen-weak-source":72,"gravity-flux":11520,"launch-flux-stress":432,
              "local-cell-exterior-repair":24,"measured-wave-streaming-times":72,"quartic-release-checks":54,
              "quartic-symmetric-checks":36,"sealed-epoch-replay":216,"wave-only-onset":144}
    assert {p.stem for p in ROOT.glob("*.csv")}==set(products)
    tables={}
    for label,count in products.items():
        data=rows(label+".csv");tables[label]=data
        assert len(data)==count and all(None not in row and None not in row.values() for row in data),label
        assert all(v.lower() not in ("nan","inf","-inf","infinity") for row in data for v in row.values())
    def worst(records,key):return max(abs(float(r[key])) for r in records if r[key]!="")
    assert worst(tables["launch-flux-stress"],"stress_error_ppm")<20 and worst(tables["launch-flux-stress"],"current_error_on_component_scale")<2e-5
    assert worst(tables["wave-only-onset"],"wave_error_ppm")<20
    assert worst(tables["gravity-flux"],"difference_on_separate_channel_scale")<2e-5
    empirical=tables["measured-wave-streaming-times"]
    assert all(float(r["bracket_lower"])<float(r["measured_window"])<float(r["bracket_upper"]) for r in empirical)
    assert all(abs(float(r["elapsed_error_ppm"]))>20 for r in empirical)
    orig=tables["sealed-epoch-replay"]
    assert worst([r for r in orig if r["method"]=="strong"],"relative_to_saved")<2e-5
    assert worst([r for r in orig if r["method"]=="weak"],"relative_to_saved")>.1
    for row in tables["frozen-compact-bound"]:
        assert float(row["normalized_energy"])>=float(row["analytic_lower_bound"])>0 and float(row["self_probe_third"])<0
    assert worst(tables["compact-bound-tests"],"relative_error_ppm")<20
    for row in tables["frozen-exterior-vs-interior"]:
        assert row["preparation"]!="exterior_null" or abs(float(row["exterior_relative_to_visible"]))<1e-12
        assert float(row["internal_self_moment_third"])<0
    poor=[r for r in tables["external-multipole-tests"] if (r["band"],r["uniform"],r["case"])==("20","0","exterior_null")]
    assert len(poor)==2 and min(abs(float(r["full_error_on_visible"])) for r in poor)>200
    fine=tables["local-cell-exterior-repair"]
    for grid in (20,32,48,64):
        group=[r for r in fine if int(r["elements"])==grid]
        for key in ("exterior_error_on_visible_ppm","boundary_error_on_visible_ppm"):
            assert (worst(group,key)<20)==(grid>=32)
        assert all(float(r["internal_self"])<0 for r in group)
    forward=[r for r in tables["quartic-release-checks"] if r["relative_error_ppm"]]
    assert len(forward)==36 and sum(abs(float(r["relative_error_ppm"]))>20 for r in forward)==18
    symmetric=tables["quartic-symmetric-checks"]
    assert worst(symmetric,"error_ppm")<20
    null=[r for r in symmetric if r["case"]=="exterior_null" and r["location"]!="self"]
    assert all(float(r["frozen"])<0 and float(r["extrapolated"])<0 for r in null)
    late=tables["exterior-finite-time"]
    def signal(grid,case):
        found=[float(r["wave_difference"]) for r in late if r["uniform"]=="0" and int(r["elements"])==grid and r["sub"]=="1"
               and r["case"]==case and r["location"]=="exterior" and float(r["offset"])==OFFSETS[-1]]
        assert len(found)==1
        return found[0]
    ratios=[signal(n,"exterior_null")/signal(n,"visible") for n in (48,64)]
    assert ratios[1]<ratios[0]<0 and abs(ratios[1]/ratios[0]-1)>1
    assert all((ROOT/name).is_file() for name in ("PROTOCOL.md","REPLAY.md","DERIVATION.md","RESULTS.md"))
    for path in ROOT.iterdir():
        assert path.is_file() and path.suffix in (".md",".py",".csv",".json",".npz")
        if path.suffix==".py":compile(path.read_bytes(),str(path),"exec")
    return dict(files={p.name:sha(p) for p in sorted(ROOT.iterdir()) if p.name!="seal.json"},parent_seal=PIN,
                checked_parent_files=len(sealed),early_packets=len(packs),csv_row_counts=products,
                one_sided_nonnull_misses=18,exterior_clock_at_20ppm=False,finite_time_exterior_converged=False,
                symmetric_fourth_checks=len(symmetric),checked_frozen_inputs=frozen)


if __name__=="__main__":
    record=validate()
    path=ROOT/"seal.json"
    if sys.argv[1:]==["--seal"]:
        with path.open("x",encoding="utf-8",newline="\n") as stream:
            json.dump(record,stream,indent=2,sort_keys=True,allow_nan=False);stream.write("\n")
    else:
        assert not sys.argv[1:] and json.loads(path.read_bytes())==record
    print("Verified",len(record["files"]),"local files and",record["checked_parent_files"],"predecessor files; seal",sha(path))
