"""Freeze an exterior-visible phase and a phase in the exterior functional's kernel."""
from origin import ROOT,Preparation,np,rows,sha,table
from scipy.linalg import solve

def main():
    output=[]
    for band in (16,20):
        p=Preparation("heavy",band,False,"probe")
        r=p.base.rad
        number,_,grad,lap,_,_,scale=p.motion(p.mono,0.)
        nn=number[p.target]
        prime=grad[0,p.target]/nn
        curve=lap[0,p.target]/nn-2*prime/r-prime**2
        weight=p.weight*nn
        T,slope,second,third=p.probes.transpose(1,0,2)
        kt=second+2*slope/r-6*T/r**2+prime*slope
        kt_r=third+2*second/r-8*slope/r**2+12*T/r**3+curve*slope+prime*second
        exterior_kt=2*r*prime
        exterior_kt_r=2*(prime+r*curve)
        functional=(kt_r*(weight*exterior_kt_r)).sum(axis=1)+6*(kt*(p.base.dr*nn*exterior_kt)).sum(axis=1)
        metric=(T*weight)@T.T
        stress=(kt_r*weight)@kt_r.T+6*(kt*(p.base.dr*nn))@kt.T
        bright=solve(metric,functional,assume_a="pos")
        bright/=np.sqrt(bright@metric@bright)
        original=np.array([0.,1.,0.])
        dark=original-(original@functional)/(bright@functional)*bright
        dark/=np.sqrt(dark@metric@dark)
        amp=1e-6
        factor=-p.coeff[p.target]*amp/(4*(scale*p.mass)**2)
        for label,vec in (("visible",bright),("exterior_null",dark),("reference",original)):
            exterior=factor*(functional@vec)
            if label=="exterior_null":assert abs(exterior)<1e-12*abs(factor*(functional@bright))
            output.append(dict(band=band,preparation=label,small=vec[0],reference=vec[1],large=vec[2],
                               unit_norm=(vec@metric@vec),exterior_Q_third=exterior,
                               internal_self_moment_third=factor*(vec@stress@vec),
                               exterior_relative_to_visible=exterior/(factor*(functional@bright)),
                               polar_axis_radial_force_third_at_36=-3*exterior/(10*scale*36**4),
                               theta_force_third_at_36_pi_over_4=-1.5*exterior/(10*scale*36**4)))
    table("frozen-exterior-vs-interior.csv",output)
    print(sha(ROOT/"frozen-exterior-vs-interior.csv"))
    for row in output:
        if row["band"]==20: print(row)


if __name__=="__main__":main()
