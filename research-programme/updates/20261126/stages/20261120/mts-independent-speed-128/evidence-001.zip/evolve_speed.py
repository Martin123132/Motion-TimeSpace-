"""Signed full-field run, evaluated at the same physical time, without an H=0 projection at readout."""
from speed_case import *

def launch(level,flag,seed):
    if level==64:
        return (baseline.checked(f"green-q64-off{flag}-s{seed}.npz"),
                baseline.checked(f"green-rhs-off{flag}-s{seed}.npz"),(0.,baseline.boundary(flag)))
    assert level==128
    records=core.read(HERE/f"launch-s{seed}.csv")
    selected=next(row for row in records if int(row["flag"])==flag)
    packet_path=HERE/selected["packet"];src=HERE/selected["source"]
    assert core.sha(packet_path)==selected["packet_sha"] and core.sha(src)==selected["source_sha"]
    return packet_path,src,(0.,float(selected["robin2"]))

def system(level,grid,flag,seed,scheme,edge):
    central=core.central
    packet_path,src,bc=launch(level,flag,seed)
    raw_path=propagate.path
    bank=f"launch-L144-h5-q1-off{flag}-s{seed}.npz"
    assert core.sha(central.PARENT/bank)==central.pins[bank]
    with patch.object(propagate,"path",lambda length,rate,speed,control,host:
                      packet_path if speed==level else raw_path(length,rate,speed,control,host)):
        shell=central.shell_for(144,5,level,flag,seed,0,edge,grid)
    if scheme=="adm":
        original=shell.dynamics
        shell.project=0
        def standard(time,state,details=False):
            result=original(time,state,details)
            if not details:
                change=core.ham(shell,state)
                result[4]+=change
                if not flag:result[15]-=change/(2*shell.mu)
            return result
        shell.dynamics=standard
    elif scheme!="original":raise ValueError(scheme)
    central.configure(shell,"trace6")
    with np.load(src) as data:
        fields=np.array([radial(data["t"],float(data["h"]),source,degree,outer,shell.r,32)
                         for source,degree,outer in zip(data["src"],(0,2),bc)])
    chi,first,second,rhs=fields.transpose(1,0,2)
    inverse=inv(chi+pair(np.ones_like(shell.r)));slope=mul(first,inverse)
    metric=2*pair(np.log1p(chi[0]),chi[1]*inverse[0])
    reference=metric,2*slope,2*(mul(second,inverse)-square(slope))
    initial=shell.initial;shift=metric-initial[0].real
    initial[5]=mul(exp(-3*shift),initial[5]);initial[6:8,1]*=np.exp(-3*shift[0])
    initial[14]-=1.5*shift;initial[18:20,1]*=np.exp(-4*shift[0])
    initial[0]=initial[1]=metric
    baseline.attach(shell,(reference,reference))
    return shell,8*mul(exp(-2.5*metric),rhs)

def calibration():
    frozen();rows=[]
    for scheme in ("original","adm"):
        for flag in (0,1):
            for seed in (0,1,-1):
                guard()
                obj,_=system(64,160,flag,seed,scheme,3)
                old,_,_=baseline.system(160,flag,seed,scheme,3)
                np.testing.assert_array_equal(obj.initial,old.initial)
                change=np.load(REFERENCE/f"{scheme}-n160-p8-L3-off{flag}-s{seed}.npz")["change"][-1]
                at=8*core.DURATION
                law=obj.dynamics(at,obj.initial+change)
                np.testing.assert_array_equal(law,old.dynamics(at,old.initial+change))
                obj,curv=system(128,160,flag,seed,scheme,3)
                raw,_,_=launch(128,flag,seed)
                with np.load(raw) as receipt:
                    np.testing.assert_array_equal(obj.rho,receipt["rho"])
                    assert obj.mu==float(receipt["mu"])
                from constraint_rate import spatial
                start=obj.initial
                h0=core.ham(obj,start)-spatial(obj,start[:4].real)+curv
                defect=obj.dynamics(0.,start,True)["ham"]
                interior=(obj.r>.6)&(obj.r<2.1)
                absolute=np.max(abs((defect-h0)[1,interior]))
                assert absolute<2e-19
                rows.append(dict(scheme=scheme,seed=seed,flag=flag,q64_state_exact=True,q64_final_rhs_exact=True,
                                 q128_H_source_consistency=absolute))
    table("operator-calibration.csv",rows)

def run(scheme,grid,steps,edge,flags):
    frozen()
    assert len(core.read(HERE/"operator-calibration.csv"))==12
    core.ep.getcontext().prec=40
    count=256*steps
    step=core.DURATION*np.sqrt(128)/count
    for flag in flags:
        for seed in (0,1,-1):
            guard()
            name=f"{scheme}-n{grid}-p{steps}-L{edge}-off{flag}-s{seed}"
            shell,_=system(128,grid,flag,seed,scheme,edge)
            advance=core.central.traced.collar.stepper(shell,step)
            delta=np.zeros_like(shell.initial);saved=[];rows=[]
            for tick in range(1,count+1):
                if tick%16==1:guard()
                delta=advance((tick-1)*step,delta)
                if tick%(count//4):continue
                assert np.isfinite(delta).all()
                saved.append(delta.copy())
                with patch.object(core.ep,"fixed_tide",fixed_tide):
                    for width,label,value in core.central.measure(shell,tick*step,delta):
                        rows.append(dict(grid=grid,steps=steps,edge=edge,flag=flag,seed=seed,scheme=scheme,
                            fraction=tick/count,width=width,channel=label,scaled_delta=128*value))
            packet(name+".npz",r=shell.r,change=saved)
            table(name+".csv",rows)
            print("saved",name,flush=True)

if __name__=="__main__":
    if sys.argv[1:]==["calibrate"]:calibration()
    else:run(sys.argv[1],*map(int,sys.argv[2:5]),tuple(map(int,sys.argv[5:])))

