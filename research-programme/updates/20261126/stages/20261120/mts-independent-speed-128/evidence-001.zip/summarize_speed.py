"""Report effect sizes, nulls, leverage and auxiliary controls on fixed frozen normalizations."""
from speed_case import *

def main():
    rows=core.read(HERE/"full-gates.csv")
    end=[r for r in rows if float(r["fraction"])==1]
    def stats(data,names):
        for key in names.split():
            vals=[float(row[key]) for row in data]
            print(key,"signed",min(vals),max(vals),"absolute",min(map(abs,vals)),max(map(abs,vals)))
    stats(rows,"tt_residual_ppm time_ppm space_ppm edge_ppm formulation_shift_ppm readout_split_ppm")
    print("final");stats(end,"newton_only_error_ppm q128_minus_q64_ppm measured_minus_q64_half_excess_ppm")
    print("source");wave=core.read(HERE/"independent-hyperbolic.csv")
    stats([r for r in wave if r["cells_per_mpc"]=="160"],"difference_ppm")
    design=core.read(HERE/"finite-domain-phase-bounds.csv")
    stats([r for r in design if r["cells_per_mpc"]=="160"],"sufficient_q_for_20ppm causal_upper_q")
    print("stride");stride=core.read(HERE/"stride-checks.csv")
    for level in (64,128):
        for count in (124,128,132):
            group=[r for r in stride if (r["q"],r["steps"])==(str(level),str(count))]
            print(level,count,sum(r["within_20ppm"]=="True" for r in group),"of",len(group));stats(group,"error_ppm")
    print("driven");data=core.read(HERE/"driven-variation-bounds.csv")
    for level in (64,128,262144,1048576):
        group=[r for r in data if r["level"]==str(level) and r["cells_per_mpc"]=="160" and r["fraction"]=="1.0"]
        print(level);stats(group,"max_history_ppm material_change_ppm clock_ppm expansion_and_ruler_ppm total_change_ppm")
    vals={(int(r["cells_per_mpc"]),int(r["subdivisions"]),int(r["level"]),int(r["seed"]),float(r["width"]),float(r["fraction"])):float(r["total_change_ppm"]) for r in data}
    for group in ((80,16),(160,32)):
        print("change vs (80,32)",group,max(abs(value-vals[80,32,*key[2:]]) for key,value in vals.items() if key[:2]==group))

if __name__=="__main__":main()

