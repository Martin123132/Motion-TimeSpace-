"""Retarded TT sector with changing Newtonian matter and FLRW clock, separate from frozen prediction."""
from independent_wave import *

def affine_step(freq,step,position,velocity,left,right,left_potential=0.,right_potential=0.):
    angle=freq*step;sinc=np.sinc(angle/np.pi);cosine=np.cos(angle)
    phi2=.5*np.sinc(angle/(2*np.pi))**2
    phi3=np.zeros_like(angle)
    small=abs(angle)<.1;arg=angle[small]**2
    phi3[small]=1/6+arg*(-1/120+arg*(1/5040-arg/362880))
    phi3[~small]=(1-sinc[~small])/angle[~small]**2
    first=left+left_potential*position
    denom=1-step**2*phi3*right_potential
    assert np.min(denom)>.99
    pos=(cosine*position+step*sinc*velocity+step**2*((phi2-phi3)*first+phi3*right))/denom
    last=right+right_potential*pos
    vel=-freq*np.sin(angle)*position+cosine*velocity+step*((sinc-phi2)*first+phi2*last)
    return pos,vel

def checks():
    rows=[]
    for frequency in (0.,.7,42.):
        freq=np.array([frequency])
        for level in (64,128,262144):
            times=np.linspace(0.,1.,18)*np.sqrt(level)/8
            pos=vel=np.array([0.]);alpha=.063/np.sqrt(level)
            for begin,end in zip(times[:-1],times[1:]):
                pos,vel=affine_step(freq,end-begin,pos,vel,1+3*alpha*begin,1+3*alpha*end)
            last=times[-1]
            if not frequency:
                scale=1+alpha*last
                value=float(pos[0]/scale);rate=float(vel[0]/scale-alpha*pos[0]/scale**2)
                error=max(abs(value-last**2/2)/(last**2/2),abs(rate/last-1))
                name="expanding_zero_mode"
            else:
                expected=(1-np.cos(frequency*last))/frequency**2+3*alpha*(last-np.sin(frequency*last)/frequency)/frequency**2
                expected_vel=np.sin(frequency*last)/frequency+3*alpha*(1-np.cos(frequency*last))/frequency**2
                error=max(abs(pos[0]-expected)*frequency**2,abs(vel[0]-expected_vel)*frequency)
                name="affine_forcing"
            assert error<2e-12,(level,frequency,error)
            rows.append(dict(fixture=name,level=level,frequency=frequency,error=error))
    table("driven-analytic.csv",rows)

def advance(op,mode,level,xi,scale,hubble,expansion,source,width):
    static=source[0];sensor=op.aperture(width)
    position=np.zeros_like(static);velocity=np.zeros_like(static)
    for idx in range(1,len(xi)):
        if mode=="flat-clock":
            conformal=np.full(2,core.DURATION/(len(xi)-1))
            step=np.sqrt(level)*conformal[0]
        else:step=np.sqrt(level)*(xi[idx]-xi[idx-1])
        expanding=mode=="flrw-live"
        first,last=(source[idx-1],source[idx]) if mode in ("flrw-live","flat-live") else (static,static)
        if expanding:
            position,velocity=affine_step(op.freq,step,position,velocity,scale[idx-1]*first,scale[idx]*last,
                                        expansion[idx-1]/level,expansion[idx]/level)
        else:position,velocity=affine_step(op.freq,step,position,velocity,first,last)
        if idx%((len(xi)-1)//4):continue
        if expanding:
            current=op.aperture(width,scale[idx])
            local_hubble=hubble[idx]/np.sqrt(level)
            metric=position/scale[idx];rate=velocity/scale[idx]-local_hubble*metric
            forcing=(last-static)+np.expm1(-2*np.log(scale[idx]))*last
            difference=forcing-(op.freq**2*metric+local_hubble*rate)/scale[idx]**2
            response=fsum(current*difference)+fsum((current-sensor)*static)
        else:
            response=fsum(sensor*((last-static)-op.freq**2*position))
        yield idx/(len(xi)-1),response/level

def main():
    frozen();checks();rows=[];budgets=[]
    truth={(int(r["seed"]),float(r["width"]),float(r["fraction"])):abs(float(r["full_newton"]))*1e-6 for r in core.read(HERE/"frozen-q128.csv")}
    for density,subdivisions in ((80,16),(80,32),(160,32)):
        op=RadialSpectrum(density,12)
        for seed in (1,-1):
            with np.load(HERE/f"source-history-p{subdivisions}-s{seed}.npz") as packet:
                xi,scale,hubble,bterm=(packet[name] for name in ("xi","b","hubble","expansion"))
                nodes=packet["local_nodes"];spacing=float(packet["spacing"])
                cell=(op.x/spacing).astype(int)
                basis=legvander(2*(op.x/spacing-cell)-1,len(nodes)-1)
                inverse=np.linalg.inv(legvander(2*nodes-1,len(nodes)-1))
                field=np.array([op.spectrum(np.einsum("ijk,ijk->ij",basis,(raw@inverse.T)[cell])) for raw in packet["radial"]])
            for width in core.family.FRACTIONS:
                for level in (64,128,262144,1048576):
                    values={}
                    for mode in ("flat-clock","flat-conformal","flat-live","flrw-live"):
                        for frac,result in advance(op,mode,level,xi,scale,hubble,bterm,field,width):
                            values[mode,frac]=result
                            ppm=result/truth[seed,width,frac]
                            if mode=="flat-clock":
                                direct=op.increment(field[0],op.aperture(width),np.sqrt(level)*frac*core.DURATION)/level
                                assert abs(ppm-direct/truth[seed,width,frac])<1e-5,(ppm,direct)
                            rows.append(dict(cells_per_mpc=density,subdivisions=subdivisions,seed=seed,width=width,
                                             level=level,mode=mode,fraction=frac,stress_tide=result,stress_ppm=ppm))
                    sensor=op.aperture(width)
                    variation=np.cumsum(abs(np.diff(field,axis=0)),axis=0)
                    for frac in (.25,.5,.75,1.):
                        unit=truth[seed,width,frac]
                        bound=fsum(abs(sensor)*variation[round(subdivisions*frac)-1])/(level*unit)
                        move=(values["flat-live",frac]-values["flat-conformal",frac])/unit
                        assert abs(move)<=bound+1e-6,(move,bound)
                        budgets.append(dict(cells_per_mpc=density,subdivisions=subdivisions,seed=seed,width=width,
                                            level=level,fraction=frac,max_history_ppm=bound,material_change_ppm=move,
                                            clock_ppm=(values["flat-conformal",frac]-values["flat-clock",frac])/unit,
                                            expansion_and_ruler_ppm=(values["flrw-live",frac]-values["flat-live",frac])/unit,
                                            total_change_ppm=(values["flrw-live",frac]-values["flat-clock",frac])/unit))
        print("driven waves",density,subdivisions,flush=True)
    table("driven-material-tides.csv",rows)
    table("driven-variation-bounds.csv",budgets)

if __name__=="__main__":main()

