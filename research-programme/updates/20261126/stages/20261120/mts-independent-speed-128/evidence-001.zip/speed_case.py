"""Local q=128 experiment: retained source, signed clouds, clock and reference geometry."""
import os
for variable in ("OPENBLAS_NUM_THREADS","MKL_NUM_THREADS","OMP_NUM_THREADS","NUMEXPR_NUM_THREADS"):
    os.environ[variable]="1"
import csv
import io
import json
import sys
from pathlib import Path
from unittest.mock import patch
from math import fsum
from types import MethodType
from importlib.util import spec_from_file_location,module_from_spec

HERE=Path(__file__).resolve().parent
REFERENCE=HERE.parent/"mts-reference-geometry-evolution-20261120"
sys.path.insert(0,str(REFERENCE))
import ref_evolve as baseline
from ref_evolve import core,np,radial,pair,inv,mul,exp,square,fixed_tide
from launch_data import states
import propagate
from local_stage import sphere,start_state

assert core.sha(REFERENCE/"seal.json")=="398e2342f01d371e73b22b8ca35eaa102517dccadaae07c0d4aceeb1f43bfb4c"
for folder,files in ((REFERENCE,("ref_metric.py","ref_evolve.py","ref_endpoint.py","independent-newton.csv","all-controls.csv")),
                     (core.HERE,("green.py","core.py")),(core.UP,("tensor_forecast.py","initial-transverse.csv","curved-contrast.csv")),
                     (core.central.PARENT,("launch_data.py","propagate.py","formation-L144-h5-s1.npz","formation-L144-h5-s-1.npz"))):
    register=json.loads((folder/"seal.json").read_bytes())["files"]
    for name in files:assert core.sha(folder/name)==register[name],name

def guard():
    baseline.guard()
    assert not (HERE/"STOP-REQUESTED").exists()

def save(name,data):
    guard()
    path=HERE/name
    if path.exists():assert path.read_bytes()==data,path
    else:
        temporary=path.with_suffix(path.suffix+".partial")
        with temporary.open("xb") as handle:handle.write(data)
        temporary.rename(path)

def table(name,rows):
    buf=io.StringIO(newline="")
    writer=csv.DictWriter(buf,fieldnames=list(rows[0]),lineterminator="\n")
    writer.writeheader();writer.writerows(rows)
    save(name,buf.getvalue().encode())

def packet(name,**items):
    buf=io.BytesIO()
    np.savez_compressed(buf,**items)
    save(name,buf.getvalue())

def load_integrator():
    spec=spec_from_file_location("signed_global_integral",core.HERE/"green.py")
    module=module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

def frozen():
    guard()
    seal=json.loads((HERE/"frozen.json").read_bytes())
    for name,digest in seal["files"].items():assert core.sha(HERE/name)==digest
    assert seal["q"]==128 and seal["ppm_gate"]==20
    return seal

