"""Independent Newton evolution of the global mechanical stress on the retained ordinary-matter clock."""
from speed_case import *
import tensor_forecast as tensor
from detector import clock
from scipy.optimize import brentq
from scipy.special import spherical_jn
from constraint import material

def history(subdivisions):
    frozen()
    sim=core.family.BalancedNative("heavy",144,720,False,"native36",clock.START+.00002)
    trace=clock.Traces("heavy",sim)
    sim.patch.coeff=lambda time:(float(trace.hubble(time-clock.START)),clock.SCALE*np.exp(time-clock.START))
    sim.ref.solution=lambda time:trace.histories(time-clock.START,"normal")
    conformal=np.array([brentq(lambda pos:float(trace.proper(pos))-pos_target,0.,trace.proper.x[-1],xtol=5e-16)
                        if pos_target else 0. for pos_target in np.linspace(0,core.DURATION,subdivisions+1)])
    log=trace.log_time(conformal);ratio=np.exp(log)
    grid=states.Element(sim.mesh,144,12);radius=grid.points
    ref=[core.family.pressure(flag)[0] for flag in (0,1)]
    kval=ref[0]["k"][:,None]
    kernel=spherical_jn(2,kval*radius.ravel());der=kval*spherical_jn(2,kval*radius.ravel(),True)
    def shape(data,mult):
        return ((data*ref[0]["w"])@mult).reshape(-1,*radius.shape)
    bases={}
    for flag in (0,1):
        np.testing.assert_array_equal(ref[0]["k"],ref[flag]["k"])
        np.testing.assert_array_equal(ref[0]["w"],ref[flag]["w"])
        at0=trace.histories(0.,"normal")[:,flag]
        for idx,ell in enumerate(log):
            diff=trace.histories(ell,"normal")[:,flag]-at0
            number=ref[flag]["n"]+diff[0];velocity=ref[flag]["p"]+diff[1]
            bases[flag,idx]=dict(D=shape(number,kernel),Dr=shape(number,der),V=shape(velocity,kernel),Vr=shape(velocity,der))
    result={};launch_tests=[]
    for flag in (0,1):
        sim.patch.wave=not flag
        for seed in (0,1,-1):
            initial=start_state(sim,144,5,seed);change=[np.zeros_like(field) for field in initial]
            all_stress=[]
            for idx,ell in enumerate(log):
                guard()
                state=tuple(left+right for left,right in zip(initial,change))
                values=material(bases[flag,idx],radius,grid.evaluate,tuple(sim.mesh.grid(part) for part in state),flag)
                number,grad,vel=[states.jet(values[a],values[b]) for a,b in (("n","D"),("g","Dr"),("p","P"))]
                density=ref[flag]["rh"][:,None,None]/ratio[idx]
                radial=(2/3)*states.angular((density*number*vel**2).sum(axis=0))
                mixed=(density*values["n"]*values["p"]*values["Pt"]).sum(axis=0)
                if not flag:
                    species=sim.patch.j
                    coeff=density[species]/(4*(ref[flag]["a"]*ratio[idx]*sim.patch.p.mass)**2)
                    radial+=(2/3)*coeff*states.angular(grad[species]**2/number[species])
                    mixed+=coeff*values["g"][species]*values["D"][species]/(values["n"][species]*radius)
                field=np.array((radial,mixed,np.zeros_like(mixed)))
                if idx==0:
                    archive,_=tensor.initial_source(sim,seed,flag)
                    diff=np.max(abs(field-archive))
                    scale=np.max(abs(archive))
                    assert diff<=max(1e-60,scale*2e-13),(seed,flag,diff,scale)
                    launch_tests.append(dict(subdivisions=subdivisions,seed=seed,flag=flag,absolute=diff,scale=scale))
                all_stress.append(field)
                if idx==subdivisions:break
                step=log[idx+1]-ell;stages=[]
                for position,at in enumerate((0.,.5,.5,1.)):
                    state=tuple(base+(inc if position==0 else inc+at*step*prior) for base,inc,prior in
                                zip(initial,change,stages[-1] if stages else change))
                    stages.append(sim.rates(state,clock.START+ell+at*step))
                for inc,(first,mid1,mid2,end) in zip(change,zip(*stages)):
                    inc+=step*(first+2*mid1+2*mid2+end)/6
            result[seed,flag]=np.asarray(all_stress)
    table(f"source-launch-{subdivisions}.csv",launch_tests)
    for seed in (1,-1):
        signed=(result[seed,0]-result[0,0])-(result[seed,1]-result[0,1])
        projected=np.array([tensor.transverse.project(grid,field)[0] for field in signed])
        packet(f"source-history-p{subdivisions}-s{seed}.npz",radial=projected,xi=conformal,b=ratio,hubble=trace.log_time(conformal,1),
               expansion=trace.log_time(conformal,2)+trace.log_time(conformal,1)**2,local_nodes=grid.t,spacing=grid.h)
    print("saved projected actual material histories",subdivisions,flush=True)

if __name__=="__main__":
    for steps in (16,32):history(steps)

