"""Keep the auxiliary changing-matter prediction separate from the registered frozen one."""
from resolve_scores import *

def main():
    frozen()
    data={(int(r["cells_per_mpc"]),int(r["subdivisions"]),int(r["level"]),int(r["seed"]),float(r["width"]),float(r["fraction"]),r["mode"]):
          float(r["stress_ppm"]) for r in core.read(HERE/"driven-material-tides.csv")}
    rows=[]
    for level in (64,128):
        root=REFERENCE if level==64 else HERE
        for scheme in ("adm","original"):
            members=cases(root,scheme,160,8,3)
            for target in core.read(HERE/"frozen-q128.csv"):
                seed,width,frac=int(target["seed"]),float(target["width"]),float(target["fraction"])
                bare=float(target["full_newton"]);norm=abs(bare)*1e-6
                expected=float(target["tt_ppm"] if level==128 else target["prior_q64_TT_ppm"])
                def wave(grid,steps,mode):return data[grid,steps,level,seed,width,frac,mode]
                live=wave(160,32,"flrw-live")
                change=live-wave(160,32,"flat-clock")
                for channel in ("ricci","gauss"):
                    excess=(signed(members,seed,width,frac,channel)-bare)/norm
                    rows.append(dict(q=level,scheme=scheme,seed=seed,width=width,fraction=frac,channel=channel,
                           frozen_error_ppm=excess-expected,direct_live_error_ppm=excess-live,
                           reanchored_live_error_ppm=excess-expected-change,live_minus_frozen_ppm=change,
                           source_time_refinement_ppm=wave(80,32,"flrw-live")-wave(80,16,"flrw-live"),
                           live_space_refinement_ppm=live-wave(80,32,"flrw-live")))
    assert len(rows)==128
    table("auxiliary-live-comparison.csv",rows)
    for level in (64,128):
        subset=[r for r in rows if r["q"]==level]
        for name in ("frozen_error_ppm","direct_live_error_ppm","reanchored_live_error_ppm","source_time_refinement_ppm","live_space_refinement_ppm"):
            print(level,name,max(abs(r[name]) for r in subset))

if __name__=="__main__":main()

