"""Solve fresh Hamiltonian and normal graph at the new speed, using signed saved formation inputs."""
from speed_case import *
from launch_data import inputs,prepare

def main(seeds):
    frozen()
    green=load_integrator()
    sim=sphere(144,5)
    for seed in seeds:
        state=start_state(sim,144,5,seed)
        rows=[]
        for flag in (0,1):
            guard()
            ref,press,_=core.family.pressure(flag)
            grid,shapes,supply=inputs(sim,state,144,5,flag,ref,press)
            green.attach(grid,32)
            with patch.object(core.family,"ResolvingSlice",green.Slice):
                data,obj=prepare(sim,state,grid,shapes,supply,ref,press,128,flag)
            native=baseline.checked(f"green-q64-off{flag}-s{seed}.npz")
            with np.load(native) as last:
                for name,factor in (("n",1.),("v",1/np.sqrt(2)),("rho",.5),("R",.5),("P",.25),("mu",np.sqrt(2)),
                                    ("s0",.25),("e0",.5),("native_stress",.25),("native_cross",.25),("weight",1.)):
                    np.testing.assert_allclose(data[name],factor*last[name],rtol=1e-13,atol=1e-75,err_msg=name)
            packet_name=f"green-128-off{flag}-s{seed}.npz"
            src_name=f"rhs-128-off{flag}-s{seed}.npz"
            packet(packet_name,**data)
            sources=[];bounds=[];errors=[]
            for harmonic,nodal in ((0,obj.f0),(2,obj.f2)):
                _,values,previous,bc=grid.lookup[id(nodal)]
                supplied=shapes[1]["chir"]/128+3*shapes[1]["chi"]/(grid.edge*128) if harmonic else 0.
                np.testing.assert_allclose(bc,supplied,rtol=2e-15,atol=0.)
                source=obj.hsource(harmonic,*values)
                replay=grid.ops[harmonic//2].apply(source,bc)
                error=np.max(abs(replay[0]-values[0]));scale=max(np.max(abs(values[0])),1e-20)
                assert error<8e-12*scale
                sources.append(source);bounds.append(float(bc));errors.append(error)
            packet(src_name,src=sources,t=grid.t,h=grid.h,bc=bounds)
            rows.append(dict(seed=seed,flag=flag,level=128,packet=packet_name,packet_sha=core.sha(HERE/packet_name),
                             source=src_name,source_sha=core.sha(HERE/src_name),monopole_update=errors[0],
                             quadrupole_update=errors[1],mu=data["mu"],H=data["H"],robin2=bounds[1]))
            print("prepared",seed,flag,flush=True)
        table(f"launch-s{seed}.csv",rows)

if __name__=="__main__":main(tuple(map(int,sys.argv[1:])))

