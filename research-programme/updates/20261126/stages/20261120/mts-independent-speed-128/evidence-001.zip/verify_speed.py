"""Recheck actual predictions, controls, field restarts and the local write-once seal."""
from speed_case import *
import resolve_scores
import phase_stride

def main(seal):
    frozen()
    assert core.sha(HERE/"frozen.json")=="47262c452904204996a2c529fe983ad1b8cca955661e93106fa9558d25eb3bfe"
    resolve_scores.main(False);resolve_scores.main(True);phase_stride.assess()
    import live_contrast
    live_contrast.main()
    assert len(list(HERE.glob("*-n*-p*-L*-off*-s*.npz")))==48
    for seed in (0,1,-1):
        for flag in (0,1):
            phase_stride.launch(128,flag,seed)
    assert len(core.read(HERE/"operator-calibration.csv"))==12
    assert len(core.read(HERE/"independent-hyperbolic.csv"))==144
    assert len(core.read(HERE/"regular-wave-controls.csv"))==72
    assert len(core.read(HERE/"finite-domain-phase-bounds.csv"))==16
    assert len(core.read(HERE/"stride-checks.csv"))==480
    assert len(core.read(HERE/"driven-material-tides.csv"))==768
    assert len(core.read(HERE/"driven-variation-bounds.csv"))==192
    assert len(core.read(HERE/"driven-analytic.csv"))==9
    for res in (16,32):
        assert len(core.read(HERE/f"source-launch-{res}.csv"))==6
        for seed in (1,-1):
            with np.load(HERE/f"source-history-p{res}-s{seed}.npz") as record:
                assert record["radial"].shape==(res+1,720,12) and np.isfinite(record["radial"]).all()
                assert np.all(np.diff(record["xi"])>0) and record["xi"][0]==0
    for path in HERE.glob("*.csv"):
        parsed=core.read(path)
        assert parsed and all(None not in row and all(val is not None and val.strip() and val.lower() not in ("nan","inf","-inf")
                                                       for val in row.values()) for row in parsed),path
    assert not list(HERE.glob("*.partial")) and not list(HERE.glob("__pycache__"))
    inventory={path.name:core.sha(path) for path in sorted(HERE.iterdir()) if path.is_file() and path.name!="seal.json"}
    info=dict(files=inventory,previous=core.sha(REFERENCE/"seal.json"),prospective_lock=core.sha(HERE/"frozen.json"),
              total_csv_rows=sum(len(core.read(path)) for path in HERE.glob("*.csv")),
              complete_state_histories=48,joint_passes=sum(row["passed"]=="True" for row in core.read(HERE/"full-gates.csv")))
    raw=(json.dumps(info,indent=2,sort_keys=True)+"\n").encode()
    if seal:save("seal.json",raw)
    assert (HERE/"seal.json").read_bytes()==raw
    print("verified",len(inventory),"files",info["total_csv_rows"],"csv rows",info["joint_passes"],"joint passes",core.sha(HERE/"seal.json"))

if __name__=="__main__":main(sys.argv[1:]==["seal"])

