"""Check resonant and detuned coarse timesteps against resolved fields, including a non-stroboscopic reading."""
from evolve_speed import *
from resolve_scores import cases,signed

def readings(shell,change,time):
    with patch.object(core.ep,"fixed_tide",fixed_tide):
        return {(width,ch):value for width,ch,value in core.central.measure(shell,time,change) if ch in ("ricci","gauss")}

def run(scheme,level):
    frozen();core.ep.getcontext().prec=40
    total_time=core.DURATION*np.sqrt(level)
    counts=(124,128,132)
    root=HERE if level==128 else REFERENCE
    truth=cases(root,scheme,160,8,3)
    rows=[];fast=[]
    for flag in (0,1):
        for seed in (0,1,-1):
            guard()
            shell,_=system(level,160,flag,seed,scheme,3)
            with np.load(root/f"{scheme}-n160-p8-L3-off{flag}-s{seed}.npz") as data:reference=data["change"]
            microtime=np.pi/(4*shell.mu)
            probe=core.central.traced.collar.stepper(shell,microtime/8)
            def offclock(increment):
                for slot in range(8):
                    increment=probe(total_time/2+slot*microtime/8,increment)
                return increment
            other=offclock(reference[1].copy())
            extra=readings(shell,other,total_time/2+microtime)
            for count in counts:
                guard()
                step=total_time/count;advance=core.central.traced.collar.stepper(shell,step)
                shift=np.zeros_like(shell.initial)
                for tick in range(1,count+1):
                    if tick%16==1:guard()
                    shift=advance((tick-1)*step,shift)
                    if tick%(count//4):continue
                    fraction=tick/count;snap=reference[round(4*fraction)-1]
                    def measure(time,phase,trial,ref,out):
                        assert np.isfinite(trial).all()
                        for (width,channel),value in readings(shell,trial,time).items():
                            rows.append(dict(q=level,scheme=scheme,steps=count,flag=flag,seed=seed,fraction=fraction,phase=phase,
                                width=width,channel=channel,scaled_trial=level*value,scaled_reference=out(width,channel)))
                        if not flag:
                            use=(shell.r>.6)&(shell.r<2.1)
                            for name,delta,standard in (
                              ("normal_log_velocity",trial[15]+trial[4].real/(2*shell.mu),ref[15]+ref[4].real/(2*shell.mu)),
                              ("log_envelope",trial[14]-trial[15]/(2j),ref[14]-ref[15]/(2j))):
                                for harmonic in (0,1):
                                    truth_scale=np.linalg.norm(standard[harmonic,use])
                                    error=np.linalg.norm((delta-standard)[harmonic,use])
                                    fast.append(dict(q=level,scheme=scheme,steps=count,seed=seed,fraction=fraction,phase=phase,
                                        field=name,harmonic=2*harmonic,increment_l2=truth_scale,error_l2=error,
                                        cycles_per_step=shell.mu*step/np.pi))
                    measure(tick*step,"saved",shift,snap,lambda width,ch:truth[flag,seed,width,fraction,ch])
                    if fraction==.5:
                        measure(total_time/2+microtime,"quarter_carrier_after_midpoint",offclock(shift.copy()),other,
                                lambda width,ch:level*extra[width,ch])
            print("phase controls",scheme,level,flag,seed,flush=True)
    table(f"stride-members-{scheme}-q{level}.csv",rows);table(f"stride-fields-{scheme}-q{level}.csv",fast)

def assess():
    norms={(int(r["seed"]),float(r["width"]),float(r["fraction"])):abs(float(r["full_newton"]))*1e-6 for r in core.read(HERE/"frozen-q128.csv")}
    results=[]
    for level in (64,128):
        for scheme in ("original","adm"):
            data=core.read(HERE/f"stride-members-{scheme}-q{level}.csv")
            for count in (124,128,132):
                subset=[item for item in data if int(item["steps"])==count]
                for seed in (1,-1):
                    for frac,phase in ((.25,"saved"),(.5,"saved"),(.5,"quarter_carrier_after_midpoint"),(.75,"saved"),(1.,"saved")):
                        for width in core.family.FRACTIONS:
                            for ch in ("gauss","ricci"):
                                group={(int(r["flag"]),int(r["seed"])):r for r in subset if r["phase"]==phase and r["channel"]==ch
                                       and float(r["width"])==width and float(r["fraction"])==frac}
                                assert len(group)==6
                                def value(key):
                                    return fsum(sign*float(group[flag,host][key]) for flag,host,sign in
                                                ((0,seed,1),(0,0,-1),(1,seed,-1),(1,0,1)))
                                denominator=norms[seed,width,frac]
                                error=(value("scaled_trial")-value("scaled_reference"))/denominator
                                results.append(dict(q=level,scheme=scheme,steps=count,seed=seed,width=width,channel=ch,
                                          fraction=frac,phase=phase,error_ppm=error,within_20ppm=abs(error)<=20))
    table("stride-checks.csv",results)
    print("coarse-clock checks",len(results),max(abs(r["error_ppm"]) for r in results))

if __name__=="__main__":
    if sys.argv[1:]==["assess"]:assess()
    else:run(sys.argv[1],int(sys.argv[2]))

