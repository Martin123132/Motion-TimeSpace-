"""Obtain finite-travel and competing forecasts without constructing any q128 metric trajectory."""
from speed_case import *
import tensor_forecast as tensor

def main():
    sim=sphere(144,5);sources={}
    for flag in (0,1):
        for seed in (0,1,-1):
            guard()
            sources[seed,flag],base=tensor.initial_source(sim,seed,flag)
    levels=(64,128,256,1024,4096,16384,65536,262144,1048576)
    raw=[];estimates=[];sensitivity=[]
    archived={(int(row["edge"]),int(row["seed"]),int(row["flag"]),float(row["width"]),float(row["fraction"]),int(row["order"])):float(row["mechanical_TT"]) for row in core.read(core.UP/"initial-transverse.csv")}
    truth={(int(row["seed"]),float(row["width"]),float(row["fraction"])):float(row["full_newton"]) for row in core.read(core.UP/"curved-contrast.csv")}
    values={}
    for edge in (36,72,144):
        grid=base if edge==144 else tensor.transverse.Element(sim.mesh,edge,len(base.t))
        for seed in (1,-1):
            for flag in (0,1):
                guard()
                projected=tensor.transverse.project(grid,(sources[seed,flag]-sources[0,flag])[:,:grid.ne])
                field=tensor.RadialWave(grid,projected[0])
                for width in core.family.FRACTIONS:
                    lap=tensor.transverse.integrate(grid,projected,width,24)
                    for frac in (.25,.5,.75,1.):
                        for level in levels if frac==1 else (64,128):
                            path=core.DURATION*np.sqrt(level)*frac
                            for order in (12,20):
                                delta,unity=tensor.probe(grid,field,width,path,order)
                                assert abs(unity-1)<3e-13
                                val=delta/level
                                if level==64:
                                    assert np.isclose(val,archived[edge,seed,flag,width,frac,order],rtol=2e-13,atol=1e-38)
                                values[level,edge,seed,flag,width,frac,order]=val
                                raw.append(dict(level=level,edge=edge,seed=seed,flag=flag,width=width,fraction=frac,order=order,
                                                path=path,material=val,taylor=path**2*lap/(2*level)))
    table("source-kernels.csv",raw)
    for (seed,width,frac),newton in truth.items():
        unit=abs(newton)*1e-6
        def prediction(level,edge=144,order=20):
            return values[level,edge,seed,0,width,frac,order]-values[level,edge,seed,1,width,frac,order]
        next_term=prediction(128);prior=prediction(64)
        taylor=fsum((1 if row["flag"]==0 else -1)*row["taylor"] for row in raw if
                    (row["level"],row["edge"],row["seed"],row["width"],row["fraction"],row["order"])==(128,144,seed,width,frac,20))
        estimates.append(dict(seed=seed,width=width,fraction=frac,full_newton=newton,transverse=next_term,
                     predicted=newton+next_term,tt_ppm=next_term/unit,prior_q64_TT_ppm=prior/unit,
                     q128_minus_q64_ppm=(next_term-prior)/unit,constant_short_time_ppm=taylor/unit,
                     max_wall_ppm=max(abs(prediction(128,edge)-next_term) for edge in (36,72))/unit,
                     angular_quadrature_ppm=abs(prediction(128,order=12)-next_term)/unit))
        if frac==1:
            for level in levels:
                approx=prediction(level)
                sensitivity.append(dict(seed=seed,width=width,level=level,finite_travel_ppm=approx/unit,
                                      taylor_ppm=taylor/unit,departure_from_taylor_ppm=(approx-taylor)/unit,
                                      vs_half_scaling_from_64_ppm=(approx-prior*64/level)/unit,
                                      wall_spread_ppm=max(abs(prediction(level,edge)-approx) for edge in (36,72))/unit))
    assert len(estimates)==16 and len(sensitivity)==36
    table("frozen-q128.csv",estimates);table("finite-travel-leverage.csv",sensitivity)
    seal=dict(q=128,ppm_gate=20,main_grid=160,main_steps=8,edge=3,
              compare=["pure Newton","Newton plus frozen finite-travel TT","q64 same physical clock"],
              refinements=[[160,4,3],[200,4,3],[160,4,4]],
              files={name:core.sha(HERE/name) for name in ("predict_speed.py","source-kernels.csv","frozen-q128.csv","finite-travel-leverage.csv")})
    save("frozen.json",(json.dumps(seal,indent=2)+"\n").encode())
    print("frozen",core.sha(HERE/"frozen.json"),len(raw),"source integrations",flush=True)

if __name__=="__main__":main()

