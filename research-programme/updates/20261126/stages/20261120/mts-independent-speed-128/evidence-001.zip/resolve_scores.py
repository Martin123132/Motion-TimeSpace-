"""Point-by-point normalized forecasts versus actual full curvatures of both formulations."""
from speed_case import *

def cases(root,scheme,grid,steps,edge,check=True):
    data={}
    for flag in (0,1):
        for seed in (0,1,-1):
            name=f"{scheme}-n{grid}-p{steps}-L{edge}-off{flag}-s{seed}"
            if check:
                with np.load(root/(name+".npz")) as snap:
                    assert snap["change"].shape==(4,20,2,grid*edge) and np.isfinite(snap["change"]).all()
                    np.testing.assert_array_equal(snap["r"],(np.arange(grid*edge)+.5)/grid)
            rows=core.read(root/(name+".csv"))
            assert len(rows)==40
            for row in rows:
                assert (int(row["grid"]),int(row["steps"]),int(row["edge"]),int(row["seed"]),int(row["flag"]),row["scheme"])==(grid,steps,edge,seed,flag,scheme)
                idx=flag,seed,float(row["width"]),float(row["fraction"]),row["channel"]
                assert idx not in data
                data[idx]=float(row["scaled_delta"])
    return data

def signed(data,seed,*index):
    return fsum(sign*data[flag,host,*index] for flag,host,sign in ((0,seed,1),(0,0,-1),(1,seed,-1),(1,0,1)))

def main(complete=True):
    frozen()
    configs=[(160,8,3)]+([(160,4,3),(200,4,3),(160,4,4)] if complete else [])
    all_data={(scheme,config):cases(HERE,scheme,*config) for scheme in ("original","adm") for config in configs}
    before={scheme:cases(REFERENCE,scheme,*configs[0]) for scheme in ("original","adm")}
    rows=[]
    for target in core.read(HERE/"frozen-q128.csv"):
        seed=int(target["seed"]);width=float(target["width"]);frac=float(target["fraction"])
        newton=float(target["full_newton"]);unit=abs(newton)*1e-6
        for scheme in ("original","adm"):
            for channel in ("gauss","ricci"):
                def read(scheme,config,channel):
                    return signed(all_data[scheme,config],seed,width,frac,channel)
                value=read(scheme,configs[0],channel)
                prior=signed(before[scheme],seed,width,frac,channel)
                residual=(value-newton-float(target["transverse"]))/unit
                plain=(value-newton)/unit
                split=(read(scheme,configs[0],"gauss")-read(scheme,configs[0],"ricci"))/unit
                different=(value-read("adm" if scheme=="original" else "original",configs[0],channel))/unit
                speed_delta=(value-prior)/unit
                row=dict(scheme=scheme,seed=seed,width=width,fraction=frac,channel=channel,scaled_tide=value,
                    newton_only_error_ppm=plain,tt_residual_ppm=residual,readout_split_ppm=split,
                    formulation_shift_ppm=different,q128_minus_q64_ppm=speed_delta,forecast_speed_delta_ppm=target["q128_minus_q64_ppm"],
                    measured_minus_q64_half_excess_ppm=plain-.5*(prior-newton)/unit,
                    residual_vs_short_time_ppm=plain-float(target["constant_short_time_ppm"]))
                if complete:
                    low=read(scheme,configs[1],channel)
                    errors=dict(time_ppm=(value-low)/unit,space_ppm=(read(scheme,configs[2],channel)-low)/unit,
                                edge_ppm=(read(scheme,configs[3],channel)-low)/unit)
                    checks=[residual,split,different,*errors.values(),float(target["max_wall_ppm"]),float(target["angular_quadrature_ppm"])]
                    row.update(errors,passed=max(map(abs,checks))<=20)
                rows.append(row)
    assert len(rows)==64
    table("full-gates.csv" if complete else "primary-test.csv",rows)
    for name in ("tt_residual_ppm","newton_only_error_ppm","readout_split_ppm","formulation_shift_ppm","q128_minus_q64_ppm"):
        print(name,max(abs(row[name]) for row in rows))
    if complete: print("passed:",sum(row["passed"] for row in rows),"/ 64")

if __name__=="__main__":main(sys.argv[1:]!=["primary"])

