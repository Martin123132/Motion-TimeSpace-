from entry import *
from kick import Basis,physical_momenta,projected
from budget import predict
from coupled import CoupledMatter,geometry,setup,propagate
from independent import Matter,constraints
from history import SITES as CLOCKS
from solve import RADII
from phase_work import Auditor
from trace_run import Trace
from scipy.integrate import solve_ivp

class Tracer(Trace):
    def sample_sites(self,matter,sol,u,ugrad):
        mesh=matter.mesh;at=lambda val:mesh.points(val,SITES);a=matter.a;hub=matter.H
        self.sites=np.r_[SITES,mesh.edge[-1]];self.factor=at(1+sol["beta"]);self.lapse=np.exp(at(u))
        self.wave=getattr(matter,"coef",0.)
        dust=sol["anis"] if not self.wave else sol["anis"]-self.wave*matter.gradpower/(1+sol["beta"])**4
        dh=sol["expansion"];vp=sol["vprime"];du=ugrad-vp
        geom=(du/mesh.r-.5*vp**2-vp*du)/(a*a*(1+sol["beta"])**4)
        hd=hub*(matter.seed.H(a*np.exp(1e-6))-matter.seed.H(a*np.exp(-1e-6)))/2e-6
        alpha=a*np.exp(u)
        return at(dh),np.stack([at(a*np.expm1(u)*hd),at(-1.5*alpha*dh*(2*hub+dh)),at(alpha*geom),at(-.5*alpha*dust)])

def run(model,epoch,kind,steps,level):
    assert model in ("heavy","cold") and epoch in ("start","end") and kind in ("translated","plain")
    if model=="heavy":seed,state,a0,grid,waves=setup(epoch,3,"balanced")
    else:seed,state,a0=fixture(model,epoch,0);grid=waves=None
    basis=Basis(state,level);coeff=np.zeros_like(basis.r)
    duration=.084 if epoch=="start" else -.084
    times=np.linspace(0.,duration,steps+1)
    calendar=solve_ivp(lambda _,val:val**2*seed.H(float(val[0])),(0.,duration),[a0],rtol=1e-13,atol=1e-15,method="DOP853",max_step=.01,dense_output=True).sol
    tag=f"{model}-{epoch}-{kind}-n{steps}-b{level}"
    energy=Auditor();trace=Tracer()
    frames=[];hours=[];terms=[];fluxes=[];est=[];events=[]
    def frame(at,material,field,stored,endpoint):
        guard();scale=float(calendar(at)[0]);kick=basis.field(stored)
        if field is None:mat=Matter("cold",epoch,.00625,.003125,6,24.,prepared=(seed,material,scale))
        else:mat=CoupledMatter(epoch,seed,material,scale,grid,field)
        physical_momenta(mat,kick);mesh=mat.mesh
        sol=constraints(mat);u,v,slip,up=geometry(mat,sol)
        rest_kick=-scale*np.exp(u)*up
        full=mesh.points(rest_kick,basis.r);full-=basis.r/basis.r[-1]*full[-1];full[0]=full[-1]=0.
        deriv=full if kind=="translated" else np.zeros_like(full)
        rate=basis.field(deriv)
        def generate(ratefield):
            rates={}
            for spec in ("baryon","cdm"):
                rates[spec+"_x"],rates[spec+"_p"]=projected(mat,sol,u,up,spec,kick,ratefield)
            return rates
        rhs=generate(rate)
        if endpoint in ("initial","final"):
            prediction=predict(mat,sol,u,up,rhs,kick,rate)
            est.append(prediction)
            if endpoint=="initial":
                other=basis.field(np.zeros_like(deriv) if kind=="translated" else full)
                opposite=predict(mat,sol,u,up,generate(other),kick,other)
                shift=prediction-opposite if kind=="translated" else opposite-prediction
                note(tag+"-freeze.json",dict(sites=SITES.tolist(),pairs=list(SPANS),native_mass_elements=len(material["cdm_x"])-1,
                    number_kick_coefficients=len(full),span_rate_terms=prediction.tolist(),predicted_change=(duration*shift.sum(axis=1)).tolist(),
                    original_masses=[float(material[sp+"_M"][-1]) for sp in ("baryon","cdm")]))
        h,nonwave=trace.sample_sites(mat,sol,u,up);hours.append(h);terms.append(nonwave)
        if os.environ.get("MTS_STREAM_EVENTS")=="1":
            events.append(dict(**{key:material[key] for key in rhs},**{"rate_"+key:val for key,val in rhs.items()},
                eta=at,a=scale,lapse=np.exp(mesh.points(u,SITES)),b=1+mesh.points(sol["beta"],SITES),s=kick.evaluate(SITES)))
            if os.environ.get("MTS_STREAM_KICK_SAMPLES")=="1":
                selected=np.flatnonzero((basis.edge[:-1]<SITES[-1])&(basis.edge[1:]>SITES[0]))
                events[-1]["kick_sample"]=stored[3*selected[0]:3*selected[-1]+4]
                radial=np.linspace(.002,.50,1993)
                events[-1].update(wide_u=mesh.points(u,radial),wide_v=mesh.points(v,radial))
        kinetic=-scale*(mat.H*np.expm1(u)+np.exp(u)*sol["expansion"])
        rest=mat.rest-mat.bg
        if field is not None:
            q=np.real(mat.zz.conj()*mat.pp);qbg=np.real(field[0,-1].conj()*field[1,-1])/grid.r[-1]**2
            rest=rest+mat.coef*(q-qbg)
        pot=-mesh.primitive(mesh.primitive(.5*scale**2*mesh.r**2*rest)/mesh.r**2,True)
        image={key:mesh.points(val,CLOCKS) for key,val in (("V",v),("slip",slip),("Vkin",kinetic),("N",pot))}
        metric=None
        if grid is not None:
            metric=[mesh.points(col,grid.r) for col in (u,v,np.exp(u-v)*(up-sol["vprime"])/mesh.r)]
            metric[0][-1]=metric[1][-1]=0.
            face=mesh.points(mesh.r**2*np.exp(u-v)*np.imag(mat.zz.conj()*mat.dz)/(scale*seed.mass),RADII)
            fluxes.append(face);image["face"]=face
            energy.snapshot(mat,sol,u,up,image|{"shell":np.diff(mesh.points(mesh.primitive(mesh.r**2*q),RADII))})
        return rhs,deriv,metric,image
    def shift(state,rates,dt):return dict(state,**{key:state[key]+dt*val for key,val in rates.items()})
    for idx,at in enumerate(times):
        rhs,deriv,metric,image=frame(at,state,waves,coeff,"initial" if idx==0 else "final" if idx==steps else "interior")
        frames.append(image)
        if idx==steps:break
        dt=times[idx+1]-at;half=at+dt/2;a=float(calendar(at)[0]);amid=float(calendar(half)[0]);hub=seed.H(amid)
        partial=propagate(grid,waves,a,seed.H(a),seed.mass,*metric,dt/2) if grid is not None else None
        mr,md,mid,_=frame(half,shift(state,rhs,dt/2),partial,coeff+dt/2*deriv,"half")
        if grid is not None:
            abar=(a+4*amid+float(calendar(at+dt)[0]))/6
            trace.segment(grid,waves,abar,hub,seed.mass,mid,dt)
            energy.segment(grid,waves,abar,hub,seed.mass,mid,dt)
            waves=propagate(grid,waves,abar,hub,seed.mass,*mid,dt)
        state=shift(state,mr,dt);coeff=coeff+dt*md
    extra={}
    if grid is not None:
        extra=dict(wave_u=waves,wave_r=grid.r)
        pack(tag+"-energy.npz",integrals=np.stack(energy.segments),**{key:np.stack([row[key] for row in energy.observations]) for key in energy.observations[0]})
    pack(tag+"-restart.npz",kick_r=basis.r,kick=coeff,scale=calendar(times[-1]),**extra,**{key:val for key,val in state.items() if key!="a"})
    pack(tag+".npz",eta=times,r=CLOCKS,a=calendar(times)[0],H=np.array([seed.H(a) for a in calendar(times)[0]]),
        h=np.stack(hours),terms=np.stack(terms),estimate=np.stack(est),wave_terms=np.stack(trace.segments) if trace.segments else np.zeros((steps,1,len(SITES))),
        **{key:np.stack([row[key] for row in frames]) for key in frames[0]})
    if events:
        pack(tag+"-events.npz",**{key:np.stack([row[key] for row in events]) for key in events[0]},
             **{sp+"_m":np.diff(state[sp+"_M"]) for sp in ("baryon","cdm")},
             **{sp+"_c":np.array(seed.coeff[sp]) for sp in ("baryon","cdm")})
    print(tag,"saved",flush=True)
if __name__=="__main__":run(sys.argv[1],sys.argv[2],sys.argv[3],int(sys.argv[4]),int(sys.argv[5]))
