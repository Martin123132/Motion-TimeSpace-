from entry import *
from status_tables import get
from source_budget import spatial_identity

def verify():
    guard();spatial_identity()
    assert all(checksum(LAST/name)==expected for name,expected in FILES.items())
    assert (HERE/"PROTOCOL.md").stat().st_mtime_ns<min(path.stat().st_mtime_ns for path in HERE.glob("*-freeze.json"))
    subset=lambda name:list(csv.DictReader((HERE/name).open(newline="",encoding="utf8")))
    histories=subset("trajectory-gravity.csv");spans=subset("signed-trace-spans.csv");energies=subset("wave-continuity.csv")
    assert len(histories)==12 and len(spans)==48 and len(energies)==6
    metric=peak_metric=0.;stresses=[];book=[];slow=[]
    anchor={(row["tag"],float(row["lo"]),float(row["hi"])):row for row in spans}
    assert len(anchor)==48
    for model in ("cold","heavy"):
        for epoch in ("start","end"):
            n=16 if epoch=="end" else 8
            current=f"{model}-{epoch}-translated-n{n}-b0";plain=f"{model}-{epoch}-plain-n8-b0"
            src=get(current+"-source-budget.json")
            face=get(current+"-face-time.json");raw=np.array([row["relative"] for row in face["spans"]])
            ref=np.array([row["relative"] for row in get(plain+"-face-time.json")["spans"]])
            assert np.max(abs(raw))<np.max(abs(ref))
            book.extend(abs(np.array(src["unassigned_over_norm"])))
            stresses+=list(abs(raw))
            for ix,(i,j) in enumerate(SPANS):
                sr=anchor[current,SITES[i],SITES[j]]
                assert float(sr["error_ppm"])==raw[ix]*1e6
                np.testing.assert_allclose(src["uncompensated_trace"][ix],raw[ix]*src["norm"][ix],rtol=2e-9,atol=1e-28)
        tag=f"{model}-end-translated-n16-b1";spd=get(tag+"-velocity.json")
        assert spd["kick_time_shape"]=="exact"
        peak_metric=max(peak_metric,max(abs(np.array(spd["absolute_metric_error"])/spd["norm"])))
        metric=max(metric,max(abs(np.array(spd["unassigned_over_norm"]))))
        test=get(tag+"-slow.json")
        assert test["flat_null"]["unbalanced"]==[0,0,0,0]
        assert test["analytic_control"]["analytic_wave_error"]<TOL
        final=test["spatial_and_time_trials"][-1]
        assert final["domain_margin"]>0 and final["steps"]>=64 and final["mass_Mpc_inverse"]>0
        assert 0<min(test["fraction_of_uniform_source"])<=max(test["fraction_of_uniform_source"])<1.1
        slow+=list(abs(np.array(test["unbalanced_on_scalar_scale"])))
        for col in ("delta_J","pressure_face_integral","volume_terms","slow_drive"):
            assert np.all(np.isfinite(final[col]))
        np.testing.assert_allclose(np.array(final["delta_J"])+final["pressure_face_integral"]+final["slow_drive"]+final["volume_terms"],final["unbalanced"],atol=1e-29)
        assert np.max(abs(np.array(test["refinement_on_scalar_scale"])[-2:]))<TOL
        assert np.max(abs(np.array(final["time_readout_change"])/final["slow_drive"]))<TOL
        with np.load(HERE/(tag+"-slow-history.npz"),allow_pickle=False) as record:
            assert record["q_and_canonical_excess"].shape==(65,2,1993)
            assert np.all(record["q_and_canonical_excess"][0,0]==0) and np.any(record["q_and_canonical_excess"][-1,0]!=0)
            assert str(record["source_hash"])==final["source_hash"]
            np.testing.assert_allclose(record["momentum_pressure_drive_volume_check"][-1,0]-record["momentum_pressure_drive_volume_check"][0,0],final["delta_J"],rtol=0,atol=0)
    assert len(get("face-sampling-checks.json"))==10
    assert all(row["max_relative"]<TOL for row in get("face-sampling-checks.json"))
    peakenergy=max(float(row["max_wave_excess_energy_ppm"])*1e-6 for row in energies)
    peakcharge=max(float(row["max_wave_charge_ppm"])*1e-6 for row in energies)
    assert peakenergy<TOL and peakcharge<TOL and max(stresses)>TOL and peak_metric>TOL
    assert max(book)<TOL and metric<TOL and max(slow)<TOL
    phys=get("physical-species.json")
    assert len(phys)==4 and max(abs(row["measured_species_fraction_of_cubic"]-1) for row in phys)<TOL
    checks=dict(trajectories=len(histories),reported_spans=len(spans),primary_max_actual_trace=max(stresses),
        primary_max_unassigned_trace=max(book),exact_velocity_max_actual_metric=peak_metric,
        exact_velocity_max_unassigned_metric=metric,retained_slow_max_per_drive=max(slow),
        max_wave_energy=peakenergy,max_wave_charge=peakcharge,threshold=TOL,
        parent_files=len(FILES),parent_seal=PIN)
    files={p.relative_to(HERE).as_posix():checksum(p) for p in sorted(HERE.rglob("*")) if p.is_file() and p.name!="seal.json"}
    assert not any(name.endswith(".pyc") or name.startswith("__pycache__") for name in files)
    record=dict(checks=checks,files=files)
    if sys.argv[1:]==["seal"]:note("seal.json",record)
    assert sys.argv[1:] in ([],["seal"]) and get("seal.json")==record
    print(len(files),"current files;",len(FILES),"parent files; SHA256",checksum(HERE/"seal.json"),checks,flush=True)
if __name__=="__main__":verify()

