from entry import *
from measure import readpack

def sample(tag):
    ev=readpack(tag+"-events.npz");p=readpack(tag+".npz");val=np.zeros((len(ev["eta"]),len(SITES)))
    for species in ("baryon","cdm"):
        for count in range(len(ev["eta"])):
            pos=ev[species+"_x"][count];mom=ev[species+"_p"][count];mass=ev[species+"_m"]
            delta=np.diff(pos);a=ev["a"][count];b=ev["b"][count];nn=ev["lapse"][count]
            for site,r in enumerate(SITES):
                for sign in (-1,1):
                    frac=(sign*r-pos[:-1])/delta
                    idx=np.flatnonzero((frac>=0)&(frac<1))
                    sub=frac[idx];physical=mom[idx]+sub*np.diff(mom)[idx]+sign*ev["s"][count,site]
                    speed2=(physical/(a*b[site]**2))**2
                    weight=mass[idx]*(idx+sub)**2/((idx**2+idx+1/3)*abs(delta[idx]))
                    val[count,site]-=.5*ev[species+"_c"]*nn[site]/(a**2*b[site]**6*r**2)*np.sum(weight*speed2/np.sqrt(1+speed2))
    target=p["terms"][:,3,:]
    error=max(np.max(abs((val-target)/target),axis=0))
    assert error<TOL,(tag,error)
    return dict(tag=tag,checked=val.size,max_relative=error)
if __name__=="__main__":
    tags=sorted(path.name[:-11] for path in HERE.glob("*-events.npz"))
    rows=[sample(tag) for tag in tags]
    note("face-sampling-checks.json",rows)
    print("Matched",sum(row["checked"] for row in rows),"sampled pressure values",max(row["max_relative"] for row in rows))

