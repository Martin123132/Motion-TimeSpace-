from entry import *
from measure import readpack

def get(name):return json.loads((HERE/name).read_bytes())
def dump(name,rows):
    fp=io.StringIO(newline="");writer=csv.DictWriter(fp,fieldnames=list(rows[0]),lineterminator="\n")
    writer.writeheader();writer.writerows(rows);put(name,fp.getvalue().encode())
def run():
    history=[];spans=[];pairs=[];wave=[];refine=[]
    for model in ("cold","heavy"):
        for epoch in ("start","end"):
            for typ,n,b in [("plain",8,0),("translated",8,0)]+([("translated",16,0),("translated",16,1)] if epoch=="end" else []):
                tag=f"{model}-{epoch}-{typ}-n{n}-b{b}"
                frozen=get(tag+"-freeze.json");p=readpack(tag+".npz");re=readpack(tag+"-restart.npz");score=get(tag+"-score.json")
                assert p["eta"][0]==0 and len(p["eta"])==n+1 and np.ptp(p["eta"])==.084
                assert (HERE/(tag+"-freeze.json")).stat().st_mtime_ns<(HERE/(tag+".npz")).stat().st_mtime_ns
                np.testing.assert_allclose(p["estimate"][0],frozen["span_rate_terms"],rtol=0,atol=0)
                assert np.array_equal(frozen["sites"],SITES)
                for i,sp in enumerate(("baryon","cdm")):
                    assert np.all(np.diff(re[sp+"_M"])>0) and re[sp+"_M"][-1]==frozen["original_masses"][i]
                assert all(np.all(np.isfinite(v)) for v in list(p.values())+list(re.values()))
                ar=np.asarray(score["trace"][-4:])
                faces=HERE/(tag+"-face-time.json")
                result=get(faces)["spans"] if faces.exists() else ar
                for ii,(row,(left,right)) in enumerate(zip(result,SPANS)):
                    spans.append(dict(tag=tag,lo=SITES[left],hi=SITES[right],pressure="event-split" if faces.exists() else "sampled",
                        residual=row["measured"]-row["predicted"],scale=row["norm"],error_ppm=1e6*row["relative"],
                        sampled_ppm=1e6*ar[ii]["relative"],without_pressure_sampled_ppm=1e6*ar[ii]["without_pressure"],
                        pressure_gauss_change_ppm=1e6*row["gaussian_refinement"] if faces.exists() else ""))
                history.append(dict(tag=tag,metric_initial_ppm=max(abs(np.array(score["metric_rate"])))*1e6,
                    metric_integrated_ppm=max(abs(np.array(score["integrated_metric"])))*1e6,
                    trace_max_ppm=1e6*max(abs(row["relative"]) for row in result),
                    clock1=score["clock"][0],clock2=score["clock"][1],clock3=score["clock"][2]))
                if model=="heavy":wave.append(dict(tag=tag,max_wave_charge_ppm=max(abs(np.array(score["charge_error"])))*1e6,
                    max_wave_excess_energy_ppm=max(abs(np.array(score["energy_error"])))*1e6))
                if typ!="translated" or b:continue
                base=f"{model}-{epoch}-plain-n8-b0";base_scores=get(base+"-score.json")["trace"][-4:]
                for i,sr in enumerate(ar):
                    measured=sr["absolute"]-base_scores[i]["absolute"];forecast=frozen["predicted_change"][i]
                    pairs.append(dict(tag=tag,lo=sr["left"],hi=sr["right"],measured_sampled_change=measured,
                        frozen_instantaneous_integrated_estimate=forecast,forecast_error_on_base_scale=(measured-forecast)/base_scores[i]["norm"]))
        b0=f"{model}-end-translated-n16-b0";b1=f"{model}-end-translated-n16-b1"
        old=get(b0+"-face-time.json")["spans"];new=get(b1+"-face-time.json")["spans"]
        for i,(o,nw) in enumerate(zip(old,new)):
            scale=o["norm"];left,right=SPANS[i];refine.append(dict(model=model,lo=SITES[left],hi=SITES[right],
                measured_change_over_original_scale=(nw["measured"]-o["measured"])/scale,
                predicted_change_over_original_scale=(nw["predicted"]-o["predicted"])/scale,
                residual_shift_ppm=1e6*(nw["relative"]-o["relative"])))
    dump("trajectory-gravity.csv",history);dump("signed-trace-spans.csv",spans);dump("frozen-shift-test.csv",pairs)
    dump("wave-continuity.csv",wave);dump("kick-basis-test.csv",refine)
if __name__=="__main__":run()

