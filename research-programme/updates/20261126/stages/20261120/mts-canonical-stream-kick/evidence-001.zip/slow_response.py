from entry import *
from measure import readpack
from seeds import SPEC,NATIVE,checked,obj,source
from scipy.interpolate import CubicSpline
from scipy.integrate import solve_ivp,simpson

def table(model):
    status=obj(source("runs/"+model+"/status.json"))
    path=SPEC/"runs/projection/a225-w6-d8.npz" if model=="heavy" else NATIVE/"runs/backgrounds/cold.npz"
    with np.load(checked(path,status["source_hash"])) as data:
        return (status["source_hash"],float(data["slow_mass_mpc"]),
                *(CubicSpline(data["efold"],data[key]) for key in ("phi_s","phidot_s")))

def evolution(tag,stride,cfl,edge,zero=False,manufactured=False):
    p=readpack(tag+".npz");ev=readpack(tag+"-events.npz");model,epoch=tag.split("-")[:2]
    hash_bg,mass,phi_tab,p_tab=table(model)
    T=ev["eta"][-1];ix=np.argsort(ev["eta"]);rad=np.linspace(.002,.50,1993)[::stride];dr=rad[1]-rad[0]
    tpath=ev["eta"][ix];calendar=CubicSpline(tpath,ev["a"][ix])
    clockdata=np.stack([ev["wide_u"][ix,::stride],ev["wide_v"][ix,::stride]],axis=1)
    if zero:clockdata.fill(0)
    if manufactured:
        calendar=CubicSpline(tpath,np.ones(len(tpath)))
        clockdata[:,0,:]=1e-7*np.sinc(32*rad/np.pi);clockdata[:,1,:]=0
        phi_tab=lambda _:0.;p_tab=lambda _:1.;mass=0.
    movie=CubicSpline(tpath,clockdata)
    speed_limit=np.exp(clockdata.sum(axis=1)).max()
    domain_margin=min(SITES[0]-rad[0],rad[-1]-SITES[-1])-abs(T)*speed_limit
    assert domain_margin>0
    initial_a=calendar(0.);phi0=phi_tab(np.log(initial_a));pi0=initial_a**2*p_tab(np.log(initial_a))
    background=solve_ivp(lambda t,y:[y[1]/calendar(t)**2,-calendar(t)**4*mass**2*y[0]],(0,T),[phi0,pi0],
        method="DOP853",rtol=3e-14,atol=[1e-15,1e-20],max_step=abs(T)/8,dense_output=True).sol
    def frame(t):
        u,v=movie(t);a=calendar(t);phi,pi=background(t);W=pi/a**3
        return (a,phi,W,u,v,np.exp(u+3*v)/a**2,a*W*np.expm1(u+3*v),
            a**2*((rad[1:]+rad[:-1])/2)**2*np.exp(.5*((u-v)[1:]+(u-v)[:-1]))/dr,
            -a**4*mass**2*np.exp(u-3*v),-a**4*mass**2*phi*np.expm1(u-3*v))
    area=rad**2*dr
    def ode(state,fr):
        q,d=state;_,_,_,_,_,qmult,qsource,faces,dmult,dsource=fr
        dq=qmult*d+qsource
        flux=faces*np.diff(q);dd=np.empty_like(d)
        dd[1:-1]=np.diff(flux)/area[1:-1]
        dd[0]=2*flux[0]/area[0];dd[-1]=-2*flux[-1]/area[-1]
        dd+=dmult*q+dsource
        if edge=="fixed":dq[[0,-1]]=0.;dd[[0,-1]]=0.
        return np.stack((dq,dd))
    loc=[np.argmin(abs(rad-r)) for r in SITES]
    np.testing.assert_allclose(rad[loc],SITES,rtol=0,atol=2e-14)
    def record(t,state,fr):
        q,d=state;a,phi,W,u,v,*_=fr
        dw=np.exp(3*v)*d/a**3+W*np.expm1(3*v)
        grad=np.gradient(q,dr,edge_order=2)
        anis=grad**2*np.exp(2*v)/a**2
        pot=mass**2*q*(phi+.5*q);kin=dw*(W+.5*dw)+.5*anis
        excess=kin+pot;press=kin-pot
        alpha=a*np.exp(u);ur,vr=np.gradient(np.stack((u,v)),dr,axis=1,edge_order=2)
        expansion=calendar(t,1)/a-movie(t,1)[1];current=-(W+dw)*grad
        tr=[[],[],[],[],[]]
        for il,ir in SPANS:
            left,right=loc[il],loc[ir];section=slice(left,right+1)
            integ=lambda arr:simpson(arr[section],x=rad[section])
            j=.5*(-W*(q[right]-q[left])-integ(dw*grad))
            tr[0].append(j)
            tr[1].append(.5*(alpha[right]*press[right]-alpha[left]*press[left]))
            tr[2].append(.5*a*W**2*np.exp(u[left])*np.expm1(u[right]-u[left]))
            tr[3].append(.5*integ(3*expansion*current+alpha*ur*excess+2*alpha*(1/rad-vr)*anis))
            tr[4].append(.5*integ(current)-j)
        return tr
    steps=int(np.ceil(abs(T)*speed_limit/(dr*cfl)/64))*64;dt=T/steps
    f0=frame(0.);state=np.stack((np.zeros_like(rad),pi0*np.expm1(-3*f0[4])))
    logs=[record(0,state,f0)]
    archive=(not zero and not manufactured and stride==1 and cfl==.325 and edge=="fixed")
    snapshots=[state.copy()] if archive else []
    for n in range(steps):
        mid=frame((n+.5)*dt);end=frame((n+1)*dt)
        k1=ode(state,f0);k2=ode(state+dt/2*k1,mid);k3=ode(state+dt/2*k2,mid);k4=ode(state+dt*k3,end)
        state=state+dt/6*(k1+2*k2+2*k3+k4);f0=end
        if (n+1)%(steps//64)==0:
            logs.append(record((n+1)*dt,state,end))
            if archive:snapshots.append(state.copy())
    assert np.all(np.isfinite(state))
    col=np.asarray(logs);times=np.linspace(0,T,len(col))
    j=col[-1,0]-col[0,0];pressure,drive,small=simpson(col[:,1:4],x=times,axis=0)
    residual=j+pressure+drive+small
    if zero:assert np.count_nonzero(state)==0 and np.count_nonzero(col)==0
    w_end=background(T)[1]/calendar(T)**3
    if archive:
        pack(tag+"-slow-history.npz",r=rad,eta=times,a=calendar(times),background=background(times),
             q_and_canonical_excess=np.stack(snapshots),momentum_pressure_drive_volume_check=col,
             slow_mass=mass,source_hash=hash_bg)
    check=0.
    if manufactured:
        amp=.5e-7*np.array([np.sinc(32*SITES[right]/np.pi)-np.sinc(32*SITES[left]/np.pi) for left,right in SPANS])
        analytic=np.stack((-amp*np.sin(32*T)/32,amp*(np.sin(32*T)/32-T),amp*T))
        check=np.max(abs((np.stack((j,pressure,drive))-analytic)/(amp*T)))
        assert check<TOL,check
    return dict(dr=dr,steps=steps,cfl=cfl,edge=edge,source_hash=hash_bg,domain_margin=domain_margin,analytic_wave_error=check,
        mass_Mpc_inverse=mass,initial_phase_field=phi0,initial_proper_rate=pi0/initial_a**3,
        bg_end_velocity_vs_table=w_end/(p_tab(np.log(calendar(T)))/calendar(T))-1,delta_J=j,pressure_face_integral=pressure,
        slow_drive=drive,volume_terms=small,unbalanced=residual,direct_gradient_integral_difference=col[-1,4],
        time_readout_change=simpson(col[::2,1:4],x=times[::2],axis=0).sum(axis=0)-(pressure+drive+small))
def run(tag):
    config=[(4,.65,"reflect"),(2,.65,"reflect"),(1,.65,"reflect"),(1,.325,"fixed")]
    results=[evolution(tag,*args) for args in config];flat=evolution(tag,4,.65,"reflect",True)
    acoustic=evolution(tag,1,.65,"reflect",manufactured=True)
    final=results[-1];src=json.loads((HERE/(tag+"-source-budget.json")).read_bytes())
    smooth=np.array(src["smooth_forecast"]);norm=np.array(src["norm"]);drive=final["slow_drive"]
    assert min(abs(drive))>0
    note(tag+"-slow.json",dict(tag=tag,spatial_and_time_trials=results,flat_null=flat,analytic_control=acoustic,
        fraction_of_uniform_source=drive/smooth,unbalanced_on_original_scale=final["unbalanced"]/norm,
        unbalanced_on_scalar_scale=final["unbalanced"]/abs(drive),
        refinement_on_scalar_scale=[(row["delta_J"]-final["delta_J"])/abs(drive) for row in results[:-1]]))
    print(tag,"slow fraction",drive/smooth,"current and pressure divided by drive",final["delta_J"]/drive,final["pressure_face_integral"]/drive,
        "balance per drive",final["unbalanced"]/abs(drive),flush=True)
if __name__=="__main__":run(sys.argv[1])
