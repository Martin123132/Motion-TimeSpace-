from entry import *
from measure import readpack
from scipy.special import roots_legendre
from scipy.integrate import simpson

def cubic(start,finish,v0,v1,dt):
    return np.stack((start,dt*v0,3*(finish-start)-dt*(2*v0+v1),2*(start-finish)+dt*(v0+v1)))
def evalpoly(poly,z):return ((poly[3]*z+poly[2])*z+poly[1])*z+poly[0]
def crossing(poly,target):
    rel=poly.copy();rel[0]-=target
    scale=np.max(abs(rel),axis=0)
    roots=[]
    for idx in range(len(scale)):
        co=rel[:,idx]
        if scale[idx]==0:raise ValueError("A material knot stayed on the force site")
        for root in np.polynomial.polynomial.polyroots(co/scale[idx]):
            if abs(root.imag)<1e-9 and 0<root.real<1:roots.append(root.real)
    return roots
def compute(tag,order):
    ev=readpack(tag+"-events.npz");nodes,weights=roots_legendre(order)
    out=np.zeros(len(SITES));jumps=np.zeros(len(SITES),int)
    for base in range(0,len(ev["eta"])-1,2):
        sl=slice(base,base+3);dt=ev["eta"][base+2]-ev["eta"][base]
        def interp(arr,z):
            return (1-z)*(1-2*z)*arr[0]+4*z*(1-z)*arr[1]+z*(2*z-1)*arr[2]
        for spec in ("cdm","baryon"):
            xx=ev[spec+"_x"][sl];pp=ev[spec+"_p"][sl]
            vx=ev["rate_"+spec+"_x"][sl];vp=ev["rate_"+spec+"_p"][sl];mass=ev[spec+"_m"]
            positions=cubic(xx[0],xx[2],vx[0],vx[2],dt)
            momenta=cubic(pp[0],pp[2],vp[0],vp[2],dt)
            hull=np.stack((xx[0],xx[0]+dt*vx[0]/3,xx[2]-dt*vx[2]/3,xx[2]))
            low=hull.min(axis=0);high=hull.max(axis=0)
            for site,r in enumerate(SITES):
                for sign in (-1,1):
                    target=sign*r
                    can=np.flatnonzero((low<=target)&(high>=target))
                    roots=crossing(positions[:,can],target)
                    joins=np.sort(np.r_[0.,roots,1.]);jumps[site]+=len(roots)
                    ids=np.flatnonzero((np.minimum(low[:-1],low[1:])<=target)&(np.maximum(high[:-1],high[1:])>=target))
                    for bot,top in zip(joins[:-1],joins[1:]):
                        if top-bot<1e-15:continue
                        tt=(bot+.5*(top-bot)*(nodes+1))[:,None]
                        x0=evalpoly(positions[:,ids],tt);x1=evalpoly(positions[:,ids+1],tt);width=x1-x0
                        active=((x0<=target)&(x1>target))|((x1<=target)&(x0>target))
                        frac=np.where(active,(target-x0)/np.where(active,width,1),0)
                        dm=np.where(active,mass[ids]*(ids+frac)**2/(ids**2+ids+1/3)/np.where(active,abs(width),1),0.)
                        p0=evalpoly(momenta[:,ids],tt);p1=evalpoly(momenta[:,ids+1],tt)
                        phys=p0+(p1-p0)*frac+sign*interp(ev["s"][sl,site],tt)
                        a=interp(ev["a"][sl],tt);b=interp(ev["b"][sl,site],tt);lapse=interp(ev["lapse"][sl,site],tt)
                        p2=(phys/(a*b**2))**2
                        val=-.5*ev[spec+"_c"]*lapse/(a**2*b**6*r**2)*np.sum(dm*p2/np.sqrt(1+p2),axis=1,keepdims=True)
                        out[site]+=dt*.5*(top-bot)*weights@val[:,0]
    return out,jumps

def run(tag):
    low,counts=compute(tag,8);high,events=compute(tag,16)
    np.testing.assert_array_equal(events,counts)
    p=readpack(tag+".npz");term=simpson(p["terms"],x=np.linspace(0,p["eta"][-1],len(p["h"])),axis=0)
    predicted=np.vstack((term,p["wave_terms"].sum(axis=0)));measured=p["h"][-1]-p["h"][0]
    sample=predicted[3].copy();predicted[3]=high
    spans=[]
    for aa,bb in SPANS:
        real=measured[bb]-measured[aa];terms=predicted[:,bb]-predicted[:,aa];norm=max(abs(real),abs(terms.sum()),max(abs(terms)))
        spans.append(dict(measured=real,predicted=float(terms.sum()),norm=norm,relative=(real-terms.sum())/norm,
                          gaussian_refinement=((high-low)[bb]-(high-low)[aa])/norm))
    note(tag+"-face-time.json",dict(crossings=counts.tolist(),sampled_pressure=sample.tolist(),integrated_pressure=high.tolist(),spans=spans))
    print(tag,"crossings",counts,"event-aware",[row["relative"] for row in spans],flush=True)
if __name__=="__main__":run(sys.argv[1])
