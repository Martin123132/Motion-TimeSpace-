from entry import *
from scipy.special import roots_legendre
from scipy.linalg import solve_banded

class Basis:
    def __init__(self,state,level):
        knots=[np.linspace(0.,24.,7680*2**level+1),np.linspace(0,.00625,9)]
        for spec in ("cdm","baryon"):knots.append(abs(state[spec+"_x"]))
        raw=np.sort(np.concatenate(knots))
        self.edge=raw[np.r_[True,np.diff(raw)>1e-11]]
        self.width=np.diff(self.edge)
        self.r=np.r_[(self.edge[:-1,None]+self.width[:,None]*np.arange(3)/3).ravel(),self.edge[-1]]
    def field(self,values):return Field(self,values)

class Field:
    def __init__(self,basis,values):
        self.basis=basis
        base=values[:-1:3];first=values[1::3]-base
        second=values[2::3]-values[1::3]-first
        third=values[3::3]-values[2::3]-(values[2::3]-values[1::3])-second
        self.poly=base,first-second/2+third/3,(second-third)/2,third/6
    def evaluate(self,rad,derivative=False):
        idx=np.clip(np.searchsorted(self.basis.edge,rad,side="right")-1,0,len(self.basis.width)-1)
        width=self.basis.width[idx];local=3*(rad-self.basis.edge[idx])/width
        base,lin,square,cube=self.poly
        value=((cube[idx]*local+square[idx])*local+lin[idx])*local+base[idx]
        if derivative:return value,(lin[idx]+local*(2*square[idx]+3*local*cube[idx]))*3/width
        return value

def physical_momenta(matter,kick):
    if not np.any(kick.poly[0]) and not any(np.any(col) for col in kick.poly[1:]):return
    val=kick.evaluate(matter.rad)
    nodes,_=roots_legendre(10)
    for spec,part in list(matter.parts.items()):
        addr,weights,old,cm,cp,cusp=part
        pos=matter.lab.dust[spec][0];span=np.diff(pos);core=[]
        for sign in (-1,1):
            first=sign*pos[:-1];last=sign*pos[1:];idx=np.flatnonzero((np.maximum(first,last)>0)&(np.minimum(first,last)<matter.cut))
            step=sign*span[idx];fa=np.clip(-first[idx]/step,0,1);fb=np.clip((matter.cut-first[idx])/step,0,1)
            frac=.5*((fa+fb)[:,None]+abs(fb-fa)[:,None]*nodes)
            core.append(kick.evaluate(np.clip(first[idx,None]+step[:,None]*frac,0,matter.cut)).ravel())
        shift=np.concatenate(core)
        matter.parts[spec]=(addr,weights,old+val[addr],cm,cp+shift,cusp)
        matter.j0+=np.bincount(addr,weights*val[addr],minlength=len(val))
        matter.j0[matter.core]+=matter.iso*(cm@shift)

def projected(matter,sol,clock,uprime,spec,kick,rate):
    mesh=matter.mesh;pos,pi,mass=matter.lab.dust[spec];step=np.diff(pos);rise=np.diff(pi)
    scale=matter.a
    cv,cs=kick.evaluate(mesh.r,True);ct=rate.evaluate(mesh.r)
    v=sol["spatial"];dv=sol["vprime"];potential=np.exp(clock);factor=np.exp(2*v)
    yy=np.broadcast_to(mesh.width[:,None]*mesh.wts/2,(len(mesh.width),len(mesh.wts))).ravel()
    normal=np.zeros_like(pos);force=np.zeros_like(pos);seen=np.zeros_like(mass)
    def deposit(sign,idx,r,weight,cu,sx,sd,en,ev,grad,spgrad):
        frac=(sign*r-pos[idx])/step[idx];physical=pi[idx]+frac*rise[idx]+sign*cu
        p2=(physical/scale)**2*ev;gamma=np.sqrt(1+p2)
        vel=physical/scale*en*ev/gamma
        push=sign*(-scale*en*(gamma*grad+p2/gamma*spgrad)-sd)-vel*sx
        dm=mass[idx]*((idx+frac)**2/(idx**2+idx+1/3))*weight/abs(step[idx])
        size=len(mass);seen[:]+=np.bincount(idx,weights=dm,minlength=size)
        for total,values in ((normal,vel),(force,push)):
            measure=values*dm
            total[:-1]+=np.bincount(idx,weights=(1-frac)*measure,minlength=size)
            total[1:]+=np.bincount(idx,weights=frac*measure,minlength=size)
    for sign in (-1,1):
        first=sign*pos[:-1];last=sign*pos[1:]
        small=np.minimum(first,last);large=np.maximum(first,last)
        begin=np.searchsorted(mesh.r,np.maximum(small,matter.cut));end=np.maximum(begin,np.searchsorted(mesh.r,large))
        for start in range(0,len(step),192):
            chunk=slice(start,start+192);counts=(end-begin)[chunk]
            idx=np.repeat(np.arange(start,start+len(counts)),counts)
            addr=np.arange(len(idx))+np.repeat(begin[chunk]-(np.cumsum(counts)-counts),counts)
            if len(idx):deposit(sign,idx,mesh.r[addr],yy[addr],cv[addr],cs[addr],ct[addr],potential[addr],factor[addr],uprime[addr],dv[addr])
        nodes,wgt=mesh.nodes,mesh.wts
        for bot,top in zip(mesh.edge[:-1],mesh.edge[1:]):
            if bot>=matter.cut:break
            lower=np.maximum(small,bot);upper=np.minimum(large,top);idx=np.flatnonzero(upper>lower)
            half=.5*(upper[idx]-lower[idx]);r=(lower[idx,None]+half[:,None]*(1+nodes)).ravel()
            wt=(half[:,None]*wgt).ravel();ix=np.repeat(idx,len(nodes))
            if len(ix):
                local,slope=kick.evaluate(r,True)
                deposit(sign,ix,r,wt,local,slope,rate.evaluate(r),np.exp(mesh.points(clock,r)),np.exp(2*mesh.points(v,r)),mesh.points(uprime,r),mesh.points(dv,r))
    assert max(abs(seen-mass))/max(mass)<1e-10
    matrix=matter.lab.inertia[spec][0]
    return tuple(np.r_[0.,solve_banded((1,1),matrix,vals[1:-1],check_finite=False),0.] for vals in (normal,force))
