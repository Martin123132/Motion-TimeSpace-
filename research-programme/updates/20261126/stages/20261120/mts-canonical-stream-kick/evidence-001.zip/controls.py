from entry import *
from kick import Basis,projected
from independent import Matter,constraints
from coupled import geometry
from galerkin import projected_rates

def run():
    seed,state,a=fixture("cold","start",0)
    grid=Basis(state,0)
    r=grid.r;sample=np.linspace(.0003,23.999,5003);poly=lambda x:.002*x+.004*x**2-.0001*x**3
    value,slope=grid.field(poly(r)).evaluate(sample,True)
    serr=max(abs(slope-(.002+.008*sample-.0003*sample**2)))
    assert max(abs(value-poly(sample)))<1e-13 and serr<1e-9
    pi=np.array([-.02,.017,-.001]);sign=np.array([-1.,1.,1.]);radius=np.array([.13,.24,.38])
    dt=.028;speed=.4;space=-.17;field=.12;vprime=.003;uprime=-.006
    shift=.03*radius**2*dt;time=.03*radius**2;der=.06*radius*dt
    p=pi+sign*shift;gam=np.sqrt(1+(p*np.exp(space)/speed)**2);vel=p*np.exp(field+2*space)/(speed*gam)
    physical=-sign*speed*np.exp(field)*(gam*uprime+(gam-1/gam)*vprime)
    canon=physical-sign*time-vel*der
    assert max(abs(canon+sign*time+vel*der-physical))<1e-17
    mat=Matter("cold","start",.00625,.003125,6,24.,prepared=(seed,state,a))
    sol=constraints(mat);clock,_,_,up=geometry(mat,sol);zero=grid.field(0*r)
    diffs=[]
    for spec in ("cdm","baryon"):
        old=projected_rates(mat,sol,clock,up,None,spec,"projected-geodesic")
        new=projected(mat,sol,clock,up,spec,zero,zero)
        diffs.append([max(abs(one-two))/max(abs(one)) for one,two in zip(old,new)])
    assert np.max(diffs)<1e-9,diffs
    note("numerical-controls.json",dict(spline_value_max=max(abs(value-poly(sample))),spline_slope_max=serr,
        reconstructed_zero_translation_rhs=diffs,nonzero_canonical_chain_error=max(abs(canon+sign*time+vel*der-physical))))
    print(diffs)
if __name__=="__main__":run()
