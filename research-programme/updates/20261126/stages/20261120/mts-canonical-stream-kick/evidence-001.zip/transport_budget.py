from entry import *
from kick import Field
from measure import readpack
from scipy.interpolate import CubicSpline
from scipy.integrate import simpson
from scipy.special import roots_legendre
from types import SimpleNamespace

def layout(restart):
    edges=restart["kick_r"][::3];ids=np.flatnonzero((edges[:-1]<SITES[-1])&(edges[1:]>SITES[0]))
    pick=slice(3*ids[0],3*ids[-1]+4)
    knots=edges[ids[0]:ids[-1]+2]
    return SimpleNamespace(edge=knots,width=np.diff(knots)),restart["kick"][pick]

def evaluate(tag,order,approx):
    packet=readpack(tag+".npz");ev=readpack(tag+"-events.npz");restart=readpack(tag+"-restart.npz")
    basis,final=layout(restart);tt=ev["eta"];clock=packet["V"]-packet["slip"];rad=packet["r"]
    ix=np.argsort(packet["eta"])
    def frames(v):return CubicSpline(packet["eta"][ix],v[ix],axis=0)(tt)
    lapse=frames(clock);spatial=frames(packet["V"])
    results=np.zeros((len(tt),4))
    for it,at in enumerate(tt):
        if "kick_sample" in ev and not approx:
            values=ev["kick_sample"][it]
            if it==len(tt)-1:np.testing.assert_array_equal(values,final)
        else:values=at/tt[-1]*final
        field=Field(basis,values);saved=ev["s"][it]
        gap=saved-field.evaluate(SITES)
        if "kick_sample" in ev and not approx:assert max(abs(gap))<1e-14
        scale=ev["a"][it];nodes,weights=roots_legendre(order)
        for span,(li,ri) in enumerate(SPANS):
            lower,upper=SITES[[li,ri]]
            for species in ("cdm","baryon"):
                pos=ev[species+"_x"][it];mom=ev[species+"_p"][it];speed=ev["rate_"+species+"_x"][it]
                width=np.diff(pos);mass=ev[species+"_m"];coeff=ev[species+"_c"]
                for sign in (1,-1):
                    xl=sign*pos[:-1];xr=sign*pos[1:]
                    lo=np.maximum(np.minimum(xl,xr),lower);hi=np.minimum(np.maximum(xl,xr),upper)
                    first=np.clip(np.searchsorted(basis.edge,lo,side="right")-1,0,len(basis.width)-1)
                    last=np.clip(np.searchsorted(basis.edge,hi,side="left"),0,len(basis.width))
                    counts=np.where(hi>lo,last-first,0)
                    ids=np.repeat(np.arange(len(mass)),counts)
                    cells=np.arange(len(ids))+np.repeat(first-(np.cumsum(counts)-counts),counts)
                    left=np.maximum(lo[ids],basis.edge[cells]);right=np.minimum(hi[ids],basis.edge[cells+1])
                    mid=(left+right)/2;half=(right-left)/2
                    rr=mid[:,None]+half[:,None]*nodes
                    frac=(sign*rr-pos[ids,None])/width[ids,None]
                    p=mom[ids,None]+np.diff(mom)[ids,None]*frac+sign*(field.evaluate(rr)+np.interp(rr,SITES,gap))
                    u=np.interp(rr,rad,lapse[it]);v=np.interp(rr,rad,spatial[it])
                    physical=np.exp(u+2*v)*p/(scale*np.sqrt(1+(p*np.exp(v)/scale)**2))
                    projected=speed[ids,None]+np.diff(speed)[ids,None]*frac
                    dm=mass[ids,None]*(ids[:,None]+frac)**2/((ids**2+ids+1/3)*abs(width[ids]))[:,None]
                    results[it,span]-=.5*coeff/scale*np.sum(half[:,None]*weights*dm*sign*(projected-physical)/rr**2)
    indices=[int(np.argmin(abs(rad-point))) for point in SITES]
    vt=packet["V"][:,indices];vk=packet["Vkin"][:,indices];ends=packet["eta"]
    delta=vt[-1]-vt[0];expected=simpson(vk,x=ends,axis=0)
    measured=[];norm=[]
    for li,ri in SPANS:
        diff=lambda arr:arr[...,ri]-arr[...,li]
        actual=diff(delta);pred=diff(expected);measured.append(actual-pred)
        norm.append(max(abs(actual),abs(pred),abs(ends[-1]*packet["a"][0]*packet["H"][0]*diff(vt[0]))))
    return np.asarray(measured),np.asarray(norm),simpson(results,x=tt,axis=0),simpson(results[::2],x=tt[::2],axis=0)

def run(tag):
    real,norm,fine,coarse=evaluate(tag,8,False);_,_,rough,_=evaluate(tag,4,False)
    exact="kick_sample" in readpack(tag+"-events.npz") or "-plain-" in tag
    guessed=evaluate(tag,8,True)[2] if exact and "-translated-" in tag else fine
    out=dict(absolute_metric_error=real,norm=norm,transport_forecast=fine,spatial_quadrature_change=fine-rough,
        time_quadrature_change=fine-coarse,kick_time_shape="exact" if exact else "final shape scaled with time, matched at saved radii",
        reconstructed_kick_test=guessed-fine,unassigned_over_norm=(real-fine)/norm)
    note(tag+"-velocity.json",out)
    print(tag,"metric, predicted velocity, remainder ppm",np.array([real,fine,real-fine])*1e6/norm)
if __name__=="__main__":
    for arg in sys.argv[1:]:run(arg)
