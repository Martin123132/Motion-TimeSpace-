from entry import *
from scipy.special import roots_legendre

def predict(matter,sol,clock,ugrad,rates,kick,rate):
    result=np.zeros((len(SPANS),3))
    mesh=matter.mesh;a=matter.a
    for spec,(pos,pi,mass) in matter.lab.dust.items():
        dx=rates[spec+"_x"];dp=rates[spec+"_p"];span=np.diff(pos)
        amp=.5*matter.seed.coeff[spec]/a**3
        for arm,(aa,bb) in enumerate(SPANS):
            lo,hi=SITES[[aa,bb]]
            for sign in (-1,1):
                small=np.minimum(pos[:-1]*sign,pos[1:]*sign);large=np.maximum(pos[:-1]*sign,pos[1:]*sign)
                def diff(idx,r):
                    frac=(sign*r-pos[idx])/span[idx]
                    field=lambda col:mesh.points(col,r.ravel()).reshape(r.shape)
                    cu,cs=kick.evaluate(r,True);ct=rate.evaluate(r)
                    mom=pi[idx]+frac*(pi[idx+1]-pi[idx])+sign*cu
                    v=field(sol["spatial"]);lapse=np.exp(field(clock));vp=field(sol["vprime"])
                    star=(mom*np.exp(v)/a)**2;gamma=np.sqrt(1+star)
                    projected=dx[idx]+frac*(dx[idx+1]-dx[idx])
                    dv=projected-mom*np.exp(2*v)/a*lapse/gamma
                    df=dp[idx]+frac*(dp[idx+1]-dp[idx])+sign*ct+cs*projected+sign*a*lapse*(gamma*field(ugrad)+star/gamma*vp)
                    weight=amp*mass[idx]*(idx+frac)**2/(idx**2+idx+1/3)*np.exp(3*v)/(r**2*abs(span[idx]))
                    return weight*sign*df,weight*mom*(3*vp-2/r)*dv,weight*mom*dv
                left=np.maximum(lo,small);right=np.minimum(hi,large)
                lower=np.clip(np.searchsorted(mesh.edge,left,side="right")-1,0,len(mesh.width)-1)
                upper=np.clip(np.searchsorted(mesh.edge,right,side="left"),0,len(mesh.width))
                count=np.where(right>left,np.maximum(upper-lower,0),0)
                ids=np.repeat(np.arange(len(span)),count)
                bins=np.arange(len(ids))+np.repeat(lower-(np.cumsum(count)-count),count)
                for begin in range(0,len(ids),4500):
                    idx=ids[begin:begin+4500];cell=bins[begin:begin+4500]
                    bot=np.maximum(left[idx],mesh.edge[cell]);top=np.minimum(right[idx],mesh.edge[cell+1]);half=(top-bot)[:,None]/2
                    rad=bot[:,None]+half*(1+mesh.nodes)
                    force,drift,_=diff(idx[:,None],rad)
                    result[arm,:2]+=[np.sum(val*half*mesh.wts) for val in (force,drift)]
                for face,mult in ((lo,1.),(hi,-1.)):
                    idx=np.flatnonzero((small<=face)&(large>face))
                    result[arm,2]+=mult*diff(idx,np.full(len(idx),face))[2].sum()
    return result
