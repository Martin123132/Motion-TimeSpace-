from entry import *
from slow_response import table
from seeds import SPEC,NATIVE,C,source,checked,obj
from scipy.interpolate import CubicSpline

def scales(model,epoch):
    seed,_,a=fixture(model,epoch,0);ln=np.log(a);hub=seed.H(a)
    hash_bg,mass,phi,phip=table(model)
    status=obj(source("runs/"+model+"/status.json"))
    path=SPEC/"runs/projection/a225-w6-d8.npz" if model=="heavy" else NATIVE/"runs/backgrounds/cold.npz"
    with np.load(checked(path,status["source_hash"])) as pack:
        hs=CubicSpline(pack["efold"],np.log(70/C)+.5*np.log(pack["expansion2"]))
        extra=0.
        if model=="heavy":
            lr=CubicSpline(pack["efold"],pack["heavy_logrho_mpc"])(ln)
            ww=CubicSpline(pack["efold"],pack["heavy_w"])(ln)
            extra=np.exp(lr)*(1+ww)-seed.coeff["wave"]/a**3
    from source import OLD,FILES
    name="radiation-full-"+model+"-0.npz"
    with np.load(checked(OLD/name,FILES[name])) as bank:
        stored=bank["epochs"];radi=bank["photon"]+bank["neutrino"]
        assert np.ptp(radi)/np.mean(radi)<TOL
        radiation=4*radi[-1]/(3*a**4)
        scales=stored;neutrinos=bank["nu"]
    with np.load(source("runs/"+model+"/background.npz")) as resolved:
        scales=np.r_[scales,resolved["requested_scale"]];neutrinos=np.r_[neutrinos,resolved["nu"]]
    ix=np.argsort(scales);scales=scales[ix];neutrinos=neutrinos[ix]
    keep=np.r_[True,np.diff(np.log(scales))>1e-8]
    x=np.log(scales[keep]);y=np.log(neutrinos[keep])
    assert x[0]<ln<x[-1]
    spline=CubicSpline(x,y);nu=np.exp(spline(ln))/a**4*(4-spline(ln,1))/3
    dust=sum(seed.coeff.values())/a**3
    total=-2*hub*(seed.H(a*np.exp(1e-6))-seed.H(a*np.exp(-1e-6)))/2e-6-dust
    smooth_derivative=-2*np.exp(2*hs(ln))*hs(ln,1)-dust
    slow=(phip(ln)/a)**2
    physical=slow+nu+radiation+extra
    return dict(model=model,epoch=epoch,a=a,source_hash=hash_bg,slow=slow,massive_neutrinos=nu,
        massless_radiation=radiation,table_heavy_minus_dust=extra,actual_tabulated_enthalpy=total,
        cubic_derivative_check=smooth_derivative,loglinear_H_derivative_difference=total-smooth_derivative,
        components_minus_cubic=physical-smooth_derivative,slow_fraction=slow/total,
        measured_species_fraction_of_cubic=physical/smooth_derivative)

if __name__=="__main__":
    result=[scales(model,epoch) for model in ("cold","heavy") for epoch in ("start","end")]
    note("physical-species.json",result)
    for row in result:print(row["model"],row["epoch"],row["slow_fraction"],row["measured_species_fraction_of_cubic"])

