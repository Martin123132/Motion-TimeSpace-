from entry import *
from assess import links
from scipy.integrate import simpson
from optical import derivative

def readpack(name):
    with np.load(HERE/name,allow_pickle=False) as src:return {key:src[key] for key in src}
def observe(tag):
    p=readpack(tag+".npz");t=p["eta"];h=p["h"];terms=p["terms"]
    dt=t[1]-t[0];timed=np.linspace(t[0],t[-1],len(h));change=h[-1]-h[0]
    nonwave=simpson(terms,x=timed,axis=0);wave=p["wave_terms"].sum(axis=0)
    total=np.vstack((nonwave,wave));expected=total.sum(axis=0)
    coarse=simpson(terms[::2],x=t,axis=0)
    split=[(i,i) for i in range(len(SITES))]+list(SPANS)
    signed=[]
    for left,right in split:
        pick=lambda v:v[...,right]-v[...,left] if right!=left else v[...,left]
        components=pick(total);pred=pick(expected);meas=pick(change)
        norm=max(abs(meas),abs(pred),max(abs(components)))
        signed.append(dict(left=float(SITES[left]),right=float(SITES[right]),measured=meas,predicted=pred,terms=components.tolist(),norm=norm,
            absolute=meas-pred,relative=(meas-pred)/norm,without_pressure=(meas-sum(components[:3]))/norm,
            temporal_quadrature=(pick(coarse-nonwave).sum())/norm,dust_quadrature=pick(coarse-nonwave)[3]/norm))
    idx=[np.argmin(abs(p["r"]-rr)) for rr in (.1,.2,.35)]
    spans=np.diff(p["V"][:,idx],axis=1);vkin=np.diff(p["Vkin"][:,idx],axis=1)
    actual=derivative(t,spans);exp=vkin[0];norm=np.maximum.reduce((abs(exp),abs(actual),abs(p["a"][0]*p["H"][0]*spans[0])))
    vdelta=spans[-1]-spans[0];vpred=simpson(vkin,x=t,axis=0)
    wscale=np.maximum.reduce((abs(vdelta),abs(vpred),abs(np.ptp(t)*p["a"][0]*p["H"][0]*spans[0])))
    opt=links(p)["constraint"].tolist()
    out=dict(tag=tag,trace=signed,initial_material_forecast=(t[-1]*p["estimate"][0].sum(axis=1)).tolist(),
        averaged_material_error=(t[-1]*np.mean(p["estimate"],axis=0).sum(axis=1)).tolist(),
        metric_rate=((actual-exp)/norm).tolist(),integrated_metric=((vdelta-vpred)/wscale).tolist(),clock=opt)
    if tag.startswith("heavy"):
        en=readpack(tag+"-energy.npz");parts=en["integrals"].sum(axis=0)
        net=en["excess"][-1]-en["excess"][0];budget=parts[:3].sum(axis=0)
        escale=np.max(abs(np.vstack((net,budget,parts[:3]))),axis=0)
        qnet=en["shell"][-1]-en["shell"][0];faces=simpson(en["current_face"],x=timed,axis=0)
        qnorm=np.maximum.reduce((abs(faces[:-1]),abs(faces[1:]),abs(qnet),abs(parts[3])))
        out.update(energy_error=((net-budget)/escale).tolist(),energy_terms=parts[:3].tolist(),
            charge_error=((qnet-parts[3])/qnorm).tolist())
    note(tag+"-score.json",out)
    print(tag,"trace spans",[v["relative"] for v in signed[-4:]],"initial metric",out["metric_rate"],flush=True)
    return out
if __name__=="__main__":observe(sys.argv[1])
