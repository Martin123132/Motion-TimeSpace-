import csv
import hashlib
import io
import json
import os
import sys
from pathlib import Path
for name in ("OPENBLAS_NUM_THREADS","MKL_NUM_THREADS","OMP_NUM_THREADS","BLIS_NUM_THREADS","NUMEXPR_NUM_THREADS"):os.environ[name]="1"
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
LAST=HERE.parent/"mts-canonical-wave-metric-20261120"
PIN="1fb1d000a9df74d9059fb186292490e973c5e1ace5b63aa4b5e0a666880e44ef"
def checksum(path):
    with path.open("rb") as fp:return hashlib.file_digest(fp,"sha256").hexdigest()
assert checksum(LAST/"seal.json")==PIN
FILES=json.loads((LAST/"seal.json").read_bytes())["files"]
for name in ("base.py","coupled.py","wave_step.py","phase_work.py","trace_run.py","work.py","assess.py","trace-score.csv","transport-heavy-end.json"):
    assert checksum(LAST/name)==FILES[name]
sys.path.insert(0,str(LAST))
from base import np,TOL,fixture,hold as old_hold
def guard():
    old_hold()
    if (HERE/"STOP-REQUESTED").exists():raise RuntimeError("Owner hold")
def put(name,data):
    guard();path=HERE/name
    if path.exists():assert path.read_bytes()==data,path
    else:
        with path.open("xb") as fp:fp.write(data)
def note(name,obj):put(name,(json.dumps(obj,sort_keys=True,indent=2,allow_nan=False,default=lambda val:val.tolist())+"\n").encode())
def pack(name,**arrays):
    fp=io.BytesIO();np.savez_compressed(fp,**arrays);put(name,fp.getvalue())
SITES=np.array([.10,.125,.165,.20,.275,.325,.35])
SPANS=((0,3),(3,6),(1,2),(4,5))
