"""Repeat the independent all-cold native preparations with the new radial transport."""
from window import *
from cold_control import native,BalancedNative,SPAN,DLOG,Element,shape,Slice,stage_field,response,PROBES,Ruler
from scipy.integrate import simpson

def prepare(flag):
    with np.load(checked(CLOUD,f"trace-cold-off{flag}.npz")) as tr:
        names=tr["names"].tolist();field=dict(zip(names,tr["values"].transpose(2,0,1)));wave=tr["k"][:,None];dt=tr["dt"][1]
    hub=field["H"];pressure=field["P"];enthalpy=field["R"]+pressure;current=field["Q"]+enthalpy*field["sigma"]
    psi=(field["dsigma"]+hub*field["sigma"])/wave;phirate=current/(2*wave)-hub*psi
    slope=lambda arr:((arr[:,:5]-arr[:,:1])@np.array([-25.,48.,-36.,16.,-3.]))/(12*dt)
    shift=(1.5*current/wave/(wave*wave+1.5*enthalpy))[:,0]
    dp=slope(current)/wave[:,0]+(4*hub*phirate+2*(2*hub*hub-enthalpy/2)*psi+2*field["Pi"]/3)[:,0]-(slope(pressure)-2*hub[:,0]*pressure[:,0])*shift
    bg=native("cold",flag);bg["spectrace"]=3*dp
    sim=BalancedNative("cold",120,600,False,"native36",SPAN*DLOG)
    grid=Element(sim.mesh,120,12);sm=(shape(bg,grid.points),shape(bg,np.asarray(120.)));cut=grid.points[:,0]<16
    with np.load(checked(CLOUD,"launch-h5-off0-seed0.npz")) as ref:mu=float(ref["mu"])
    for seed in (0,1,-1):
        state=stage_field(sim,"cold",seed or 1,5)
        if not seed:state=tuple(np.zeros_like(x) for x in state)
        obj=Slice(sim,grid,bg,sm,state,flag,False,"fixed",0,"matched")
        num=np.stack([pair(x,y) for x,y in zip(obj.m["n"],obj.m["D"])])
        mono=grid.evaluate(obj.state[0])[0];phase=grid.evaluate(obj.state[2])[0][flag]
        vel=np.stack([pair(x,y) for x,y in zip(mono[1]/grid.points,sm[0]["V"]+phase)])
        blank=np.zeros_like(num[:1]);blank[:,0]=1
        yield seed,dict(cold_flag=flag,rho=np.r_[obj.rh,0.],t=grid.t,h=grid.h,n=np.concatenate((num,blank))[...,cut,:],
            v=np.concatenate((vel,np.zeros_like(blank)))[...,cut,:],mu=mu,H=bg["H"],P=pressure[:,0].mean(),R=bg["R"],
            e0=sm[0]["other"][cut],s0=response(bg,grid.points)("spectrace")[cut],native_stress=sm[0]["stress"][cut],
            native_cross=sm[0]["stress_cross"][cut],weight=bg["w"],chi=pair(grid.evaluate(obj.f0)[0],grid.evaluate(obj.f2)[0])[...,cut,:],
            b=pair(obj.b0,obj.b2)[...,cut,:],c=obj.c2[cut],d=obj.d2[cut],delta=np.zeros_like(num[0][...,cut,:]),
            drift=np.zeros_like(num[0][...,cut,:]),probes=PROBES[:3],initial_tide=[Ruler(obj).read(r)["ruler_tide"] for r in PROBES[:3]])

def test(method):
    for flag in (0,1):
        rows=[]
        for seed,packet in prepare(flag):
            cls=Stagger if method=="stagger" else Radial
            shell=cls(packet,80,6,1,1,method);start=shell.initial;change=np.zeros_like(start)
            steps=96;dt=DURATION/(2*steps);times=[];windows=[]
            for tick in range(2*steps+1):
                now=tick*dt;state=start+change;one=shell.dynamics(now,state)
                if tick%6==0:
                    safe();times.append(field_tides(shell,now,state,one));windows.append(sample(shell,now,state,one)[1])
                if tick==2*steps:break
                two=shell.dynamics(now+dt/2,start+(change+dt*one/2));three=shell.dynamics(now+dt/2,start+(change+dt*two/2))
                four=shell.dynamics(now+dt,start+(change+dt*three))
                change+=dt*(one+2*two+2*three+four)/6
            points=simpson(np.array(times),dx=6*dt,axis=0);finite=simpson(np.array(windows),dx=6*dt,axis=0)
            for rad,vec in zip(RADII,points.T):rows.append(dict(seed=seed,kind="point",target=rad,ricci=vec[0],gauss=vec[1]))
            for wid,vec in zip(FRACTIONS,finite):rows.append(dict(seed=seed,kind="finite",target=wid,ricci=vec[0],gauss=vec[1]))
        save(f"cold-{method}-off{flag}.csv",rows)
    assert (HERE/f"cold-{method}-off0.csv").read_bytes()==(HERE/f"cold-{method}-off1.csv").read_bytes()
if __name__=="__main__":test(sys.argv[1])
