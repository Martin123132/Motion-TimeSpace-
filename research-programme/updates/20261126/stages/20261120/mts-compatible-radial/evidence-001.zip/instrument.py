"""Independent proper-coordinate and weak-divergence controls for the finite gradiometer."""
from window import *
from scipy.integrate import quad
from scipy.optimize import brentq
import sympy as sy

def test():
    r,t,angle=sy.symbols("r t angle",real=True)
    F=r*(1+(.07+.019*t)*sy.exp(-r**2/4));V=(.017-.006*t)*r**3*sy.exp(-r**2/2)
    normal=F.diff(r);angular=V.diff(r);ell=sy.log(normal);ell2=angular/normal
    bb=.02*sy.exp(-r**2);bq=.013*r**2*sy.exp(-r**2/3);tilt=.008*r**2*sy.exp(-r**2)
    base=lambda y:sy.cos(2.8*y)+.02*y**2
    shape=lambda y:sy.exp(-(y-1.45)**2/.18)
    b0=base(F)+t*shape(F)
    bx=(base(r).diff(r)).subs(r,F)+t*(shape(r).diff(r)).subs(r,F)
    q0=(1+t/3)*shape(F)+bx*V
    jr=.041*r*sy.exp(-r**2);jq=.02*r*sy.cos(r);jt=.027*r*sy.exp(-r**2/2)
    j0=r**2*sy.exp(ell+2*bb)
    a0=r**2*sy.exp(2*bb)*jr;aq=r**2*sy.exp(2*bb)*(jq+2*bq*jr)
    div=a0.diff(r)/j0
    divq=(aq.diff(r)-(ell2+2*bq)*a0.diff(r))/j0-6*(sy.exp(-bb)*jt-tilt*sy.exp(-ell)*jr)/r
    back=sy.lambdify(r,F.subs(t,0),"numpy");aperture=sy.lambdify(r,shape(r)/3,"numpy")
    exact_div=sy.lambdify(r,(-2*(divq-V*div.diff(r)/normal)).subs(t,0),"numpy",cse=True)
    fields=(ell,ell2,bb,bq,tilt,ell.diff(t),ell2.diff(t),b0,q0,b0.diff(t),q0.diff(t),jr,jq,jt)
    fun=sy.lambdify(r,[item.subs(t,0) for item in fields],"numpy",cse=True)
    rows=[]
    for rate in (40,80,120,160):
        with np.load(checked(CLOUD,"launch-h5-off1-seed1.npz")) as pkt:shell=Radial(pkt,rate,6,1,1,"flux")
        arr=fun(shell.r);state=np.zeros_like(shell.initial);rhs=np.zeros_like(state)
        state[0]=pair(*arr[:2]);state[1]=pair(*arr[2:4]);state[2,1]=arr[4];rhs[0]=pair(*arr[5:7])
        for degree in (4,8):
            win=Window(shell,state,rhs,degree)
            value=sum(win.times(pair(*arr[7:9]),pair(*arr[9:11])))
            weak=win.weak_flux(pair(*arr[11:13]),arr[13])
            for idx,fraction in enumerate(FRACTIONS):
                width=CENTER*fraction
                avg=lambda func:quad(lambda y:float(weight(y,width))*func(y),CENTER-width,CENTER+width,epsabs=1e-13)[0]
                expected=avg(aperture)
                exact=avg(lambda y:exact_div(brentq(lambda rr:back(rr)-y,.4,2.3,xtol=1e-14)))
                rows.append(dict(grid=rate,quadrature=degree,width=fraction,weight_error=win.widths[idx,0].sum()-1,
                    observable_relative=value[idx]/expected-1,weak_relative=weak[idx]/exact-1))
    assert max(abs(row[key]) for row in rows if row["grid"]>=80 for key in ("weight_error","observable_relative","weak_relative"))<2e-5
    save("proper-window-controls.csv",rows)

def checker():
    with np.load(checked(CLOUD,"launch-h5-off1-seed1.npz")) as pkt:shell=Stagger(pkt,80,6,1,1,"stagger")
    radii=shell.r; rng=np.random.default_rng(2002)
    field=rng.normal(size=len(radii)); field[:15]=field[-15:]=0
    face=rng.normal(size=len(radii)+1);face[:15]=face[-15:]=0
    grad=shell.toface(field,slope=True);div=shell.tocell(face)
    left=field@div;right=face@grad; defect=abs(left+right)/max(abs(left),abs(right))
    assert defect<1e-13
    nyquist=(-1.)**np.arange(len(field))
    sharp=-shell.diff(nyquist,2)[12:-12]*shell.dx**2*nyquist[12:-12]
    symbol=4*(sum((-1)**j*w for j,w in enumerate(shell.weights)))**2
    assert np.max(abs(sharp-symbol))<4e-14 and symbol>4
    save("staggered-adjoint.csv",[dict(seed=2002,ibp_error=defect,nyquist_eigenvalue=float(sharp.mean()),theory=symbol)])
if __name__=="__main__":test();checker()
