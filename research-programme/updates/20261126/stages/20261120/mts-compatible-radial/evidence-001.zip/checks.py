from release_tables import *

def run():
    point,windows=compute()
    prev=rows(saved("paired-curvatures.csv"))
    report=[]
    def entry(name,scale,value,tol=2e-5):
        report.append(dict(test=name,reference=scale,relative_or_absolute=value,tolerance=tol,passes=abs(value)<tol))
    for geom in ("ricci","gauss"):
        rr=[r for r in point if r["method"]=="original" and r["stride"]==1]
        for row in rr:
            ref=next(float(old["gr"]) for old in prev if old["environment"]=="conserved" and old["history"]=="normal" and old["parent"]=="5" and old["project"]=="1"
                and old["gr_rate"]=="80" and old["gr_steps"]=="192" and old["method"]==geom and int(old["seed"])==row["seed"] and float(old["radius"])==row["radius"])
            entry(f"original-{geom}-seed{row['seed']}-{row['radius']}","archived change",row[geom]/ref-1)
    for seed in (1,-1):
        for radius in RADII:
            keys=dict(method="stagger",native=5,grid=80,project=1,stride=1,seed=seed,radius=radius)
            group=[r for r in point if all(r[k]==v for k,v in keys.items())]
            pairs={(r["steps"],r["edge"]):r for r in group}
            for geom in ("ricci","gauss"):
                for name,left,right in (("time",(192,8),(96,8)),("buffer",(96,6),(96,8))):
                    entry(f"{name}-{geom}-seed{seed}-{radius}","full point change",pairs[left][geom]/pairs[right][geom]-1)
    fine=[row for row in windows if row["stride"]==1 and row["degree"]==8]
    for row in fine:
        tag=f'{row["method"]}-h{row["native"]}-n{row["grid"]}-t{row["steps"]}-p{row["project"]}-w{row["width"]}-s{row["seed"]}'
        entry("curvature-"+tag,"full finite change",row["split_on_tide"])
        entry("weak-"+tag,"small constraint change",row["weak_rel"])
        entry("weak-scaled-"+tag,"full finite change",row["weak_error_on_tide"])
        entry("face-"+tag,"small constraint change",row["face_rel"])
        for other in (v for v in windows if all(v[k]==row[k] for k in ("method","native","grid","steps","project","width","seed"))):
            if (other["degree"],other["stride"]) in ((4,1),(8,2)):
                for field in ("gauss","ricci"):
                    entry(f'integral-{field}-q{other["degree"]}-s{other["stride"]}-'+tag,"full finite change",other[field]/row[field]-1)
    save("checks.csv",report)
    for prefix in ("original-","time-","buffer-","curvature-","weak-scaled-","integral-"):
        group=[abs(r["relative_or_absolute"]) for r in report if r["test"].startswith(prefix)]
        print(prefix,len(group),max(group))
if __name__=="__main__":run()
