from scheme import *
from stagger import Stagger
from fixtures import Empty
checked(CLOUD,"analytic_controls.py")
from analytic_controls import ltb

def test():
    rows=[]
    for method in ("original","flux","stagger"):
        for rate in (40,80):
            for project in (0,1):
                with np.load(checked(CLOUD,"launch-h5-off1-seed1.npz")) as pkt:
                    cls=Stagger if method=="stagger" else Radial
                    shell=cls(pkt,rate,6,1,project,method)
                shell.incident=Empty(shell.r);shell.rho=np.array([1.,0.,0.])
                start=shell.initial.copy();start[:17]=ltb(shell.r,0);start[17:]=0.
                shell.mu=180.;state=start.copy();region=(shell.r>.6)&(shell.r<3.2);step=.002
                for tick in range(13):
                    time=tick*step
                    if tick in (0,12):
                        truth=ltb(shell.r,time)
                        exact=-mul(truth[4],truth[5])/3+square(truth[5])/2
                        info=shell.dynamics(time,state,True)
                        for idx in (0,1):
                            norm=np.max(abs(exact[idx,region]))
                            rows.append(dict(method=method,grid=rate,project=project,time=time,harmonic=idx,
                                direct_rel=np.max(abs(info["tide"][idx,region]-exact[idx,region]))/norm,
                                gauss_rel=np.max(abs(info["tide_first_derivative"][idx,region]-exact[idx,region]))/norm))
                    if tick==12:break
                    one=shell.dynamics(time,state);two=shell.dynamics(time+step/2,state+step*one/2)
                    three=shell.dynamics(time+step/2,state+step*two/2);four=shell.dynamics(time+step,state+step*three)
                    state+=step*(one+2*two+2*three+four)/6
    assert max(row["gauss_rel"] for row in rows if row["grid"]==80)<2e-5
    assert max(row["direct_rel"] for row in rows if row["grid"]==80)<2e-5
    save("exact-evolving-dust.csv",rows)
if __name__=="__main__":test()
