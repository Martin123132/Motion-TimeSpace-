"""Alternative radial discretizations on the retained signed-cloud equations."""
import hashlib
import os
import sys
import csv
import io
import json
from pathlib import Path

HERE=Path(__file__).resolve().parent
PARENT=HERE.parent/"mts-newton-cloud-clock-20261120"
PIN="8d57ec38fd26f371e45321875b3c5aea3b75158ed29291af29111e07b352b831"
def digest(path):
    with path.open("rb") as handle:return hashlib.file_digest(handle,"sha256").hexdigest()
assert digest(PARENT/"seal.json")==PIN
registry=json.loads((PARENT/"seal.json").read_bytes())["files"]
def saved(name):
    path=PARENT/name
    assert digest(path)==registry[name],path
    return path
for name in ("clock_tide.py","constraint_rate.py","subsidiary.py"):saved(name)
sys.path.insert(0,str(PARENT))
from subsidiary import Conserved,checked,CLOUD,np,pair,mul,square,exp,measure,ruler_variation,simpson,RADII,DURATION,guard
from cloud_owner import inv
from tide_rate import field_tides

def safe():
    guard()
    assert not (HERE/"STOP-REQUESTED").exists()

def save(name,rows):
    safe()
    out=io.StringIO(newline="")
    writer=csv.DictWriter(out,fieldnames=list(rows[0]),lineterminator="\n")
    writer.writeheader();writer.writerows(rows);raw=out.getvalue().encode()
    path=HERE/name
    if path.exists():assert path.read_bytes()==raw,name
    else:
        tmp=HERE/(name+".partial")
        with tmp.open("xb") as handle:handle.write(raw)
        tmp.rename(path)

class Radial(Conserved):
    def __init__(self,packet,rate,edge,flag,project,method):
        self.method=method
        self.order=8 if method=="flux8" else 6
        super().__init__(packet,rate,edge,flag,project)

    def extend(self,arr,odd,pad):
        return np.concatenate(((-1 if odd else 1)*arr[...,pad-1::-1],arr,
                               arr[...,:-pad-1:-1]),axis=-1)

    def diff(self,arr,degree=1,odd=False):
        if self.method=="original":return super().diff(arr,degree,odd)
        if degree==2:return self.diff(self.diff(arr,odd=odd),odd=not odd)
        weights=(.75,-.15,1/60) if self.order==6 else (.8,-.2,4/105,-1/280)
        pad=len(weights);count=arr.shape[-1];ext=self.extend(arr,odd,pad)
        return sum(weight*(ext[...,pad+index:pad+index+count]-ext[...,pad-index:pad-index+count])
                   for index,weight in enumerate(weights,1))/self.dx

    def volume_div(self,fr,ft,ell,bend,tilt):
        radius=self.r;weight=radius**2
        value=mul(exp(-ell-2*bend),self.diff(weight*mul(exp(2*bend),fr),odd=True))/weight
        value[1]-=6*(np.exp(-bend[0])*ft-tilt[1]*np.exp(-ell[0])*fr[0])/radius
        return value

    def lap(self,field,ell,bend,tilt):
        if not self.method.startswith("flux"):return super().lap(field,ell,bend,tilt)
        normal=mul(exp(-ell),self.diff(field))
        tangent=np.exp(-bend[0])*field[1]/self.r
        return self.volume_div(normal,tangent,ell,bend,tilt)

    def dynamics(self,time,state,details=False):
        result=super().dynamics(time,state,details)
        if details or not self.method.startswith("flux"):return result
        ell,bend,tilt=state[:3].real;trace,shear=state[4:6].real
        nr=exp(-ell);radius=self.r;ar=np.exp(-bend[0])/radius
        for spec in range(3 if self.flag else 2):
            number,pot=state[8+2*spec:10+2*spec].real
            pr=mul(nr,self.diff(pot));squared=square(pr)
            root=np.sqrt(1+squared[0])
            gamma=pair(root,squared[1]/(2*root))
            fr=mul(number,mul(nr,mul(pr,inv(gamma))))
            ft=number[0]*(ar*np.exp(-bend[0])*pot[1]-tilt[1]*nr[0]*pr[0])/root
            result[8+2*spec]=-self.diff(radius**2*fr,odd=True)/radius**2
            result[8+2*spec,1]+=6*ft/radius
        en,jr,jt=state[17:].real
        inc=self.incident.at(time);p=pair(inc[1],inc[3])/3
        stress=pair(np.zeros_like(radius),inc[4])
        result[17]=mul(trace,en+p)+1.5*mul(shear,stress)-self.volume_div(jr,jt[1],ell,bend,tilt)
        return result

def readings(shell,time,state,one):
    ell,bend,tilt,_,trace,shear=state[:6].real
    info=shell.dynamics(time,state,True)
    ham,actual=measure(shell,state,one,True)
    radial,angular=info["mom_r"],info["mom_theta"][1]
    normal=exp(-ell);curve=mul(normal,2*shell.diff(bend)+pair(2/shell.r,6*tilt[1]/shell.r))
    div=mul(normal,shell.diff(radial,odd=True))+mul(curve,radial)
    div[1]-=6*np.exp(-bend[0])*angular/shell.r
    conservative=(shell.residual_flux(state,radial,angular) if hasattr(shell,"residual_flux")
                  else shell.volume_div(radial,angular,ell,bend,tilt))
    local=mul(2*trace/3+shell.project*shear/2,ham)
    return ham,actual,local,-2*div,-2*conservative
