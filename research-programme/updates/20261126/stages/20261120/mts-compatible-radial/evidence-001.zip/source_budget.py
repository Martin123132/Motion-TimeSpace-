"""Mass-normalized, moving-ruler decomposition of the full secular trace-free tide."""
from window import *

LABELS=("rest_dust","rest_heavy","energy_dust","energy_heavy","stress_dust","stress_heavy",
        "energy_environment","stress_environment","intrinsic","extrinsic")

def sources(shell,time,state,rhs):
    epsilon=1e-19
    real=lambda idx:state[idx].real+1j*epsilon*rhs[idx].real
    imag=lambda idx:state[idx].imag+1j*epsilon*rhs[idx].imag
    ell,bend,tilt,tensor,trace,radial=[real(idx) for idx in range(6)]
    fac=exp(-ell);volume=exp(-ell-2*bend);one=pair(np.ones_like(shell.r))
    out=np.zeros((len(LABELS),2,len(shell.r)),dtype=complex)
    for species in range(3 if shell.flag else 2):
        pos=int(species==2)
        density=shell.rho[species]*mul(real(8+2*species),volume)
        squared=square(mul(fac,shell.diff(real(9+2*species))))
        gam=np.sqrt(1+squared[0]);gamma=pair(gam,squared[1]/(2*gam))
        out[pos]-=density/3
        out[2+pos]-=mul(density,mul(squared,inv(gamma+one)))/3
        out[4+pos]+=2/3*mul(density,mul(squared,inv(gamma)))
    if not shell.flag:
        density=shell.rho[-1]*exp(2*real(14))
        grad=(square(mul(fac,shell.diff(real(14))))+square(mul(fac,shell.diff(imag(14)))))/shell.mu**2
        excess=square(real(15)+trace/(2*shell.mu))+square(imag(15))+grad
        out[1]=-mul(density,one-imag(15))/3
        out[3]=-mul(density,excess)/6
        out[5]=2*mul(density,grad)/3
    out[6]=-real(17)/3
    out[7,1]=shell.incident.bank.at(time)[4]+1j*epsilon*shell.incident.bank.samples(time,1)[4]
    rr=shell.r;bp=shell.diff(bend)
    e0=np.exp(-2*ell[0]);eb=np.exp(-2*bend[0])
    gap=-2*mul(exp(-2*ell),square(bp)+2*bp/rr)
    gap[0]+=2*e0*np.expm1(2*(ell[0]-bend[0]))/rr**2
    gap[1]+=(eb*(8*bend[1]+12*tensor[1])+e0*(4*ell[1]-12*tilt[1]))/rr**2-12*e0*bp[0]*tilt[1]/rr
    out[8]=gap/2;out[9]=square(trace)/9-mul(trace,radial)/3+square(radial)/4
    return out

DETAIL=("dust_phase","heavy_phase","heavy_amplitude","heavy_normal")

def microscopic(shell,state,rhs):
    epsilon=1e-19
    real=lambda idx:state[idx].real+1j*epsilon*rhs[idx].real
    imag=lambda idx:state[idx].imag+1j*epsilon*rhs[idx].imag
    ell,bend,trace=real(0),real(1),real(4)
    factor=exp(-ell); one=pair(np.ones_like(shell.r))
    out=np.zeros((len(DETAIL),2,len(shell.r)),dtype=complex)
    for idx in range(3 if shell.flag else 2):
        density=shell.rho[idx]*mul(real(8+idx*2),exp(-ell-2*bend))
        squared=square(mul(factor,shell.diff(real(9+idx*2))))
        root=np.sqrt(1+squared[0]);gamma=pair(root,squared[1]/(2*root))
        out[int(idx==2)]+=mul(mul(density,squared),2*inv(gamma)/3-inv(gamma+one)/3)
    if not shell.flag:
        density=shell.rho[-1]*exp(2*real(14))
        out[1]=mul(density,square(mul(factor,shell.diff(imag(14)))))/(2*shell.mu**2)
        out[2]=mul(density,square(mul(factor,shell.diff(real(14)))))/(2*shell.mu**2)
        out[3]=-mul(density,square(real(15)+trace/(2*shell.mu))+square(imag(15)))/6
    return out

def run(grid,steps,native=5,detail=0):
    for seed in (0,1,-1):
        for flag in (0,1):
            with np.load(checked(CLOUD,f"launch-h{native}-off{flag}-seed{seed}.npz")) as packet:shell=Stagger(packet,grid,6,flag,1,"stagger")
            start=shell.initial;change=np.zeros_like(start);dt=DURATION/(steps*2)
            values=[]
            for tick in range(2*steps+1):
                now=dt*tick;state=start+change;one=shell.dynamics(now,state)
                if tick%(steps//16)==0:
                    safe();win=Window(shell,state,one,8)
                    parts=microscopic(shell,state,one) if detail else sources(shell,now,state,one)
                    mono,angular=win.at(parts.real).transpose(1,0,2)
                    dm,da=win.at(parts.imag/1e-19).transpose(1,0,2)
                    weights=win.widths
                    values.append(weights[:,0]@da.T+weights[:,1]@dm.T+weights[:,2]@angular.T+weights[:,3]@mono.T)
                if tick==2*steps:break
                two=shell.dynamics(now+dt/2,start+(change+dt*one/2));three=shell.dynamics(now+dt/2,start+(change+dt*two/2))
                four=shell.dynamics(now+dt,start+(change+dt*three))
                change+=dt*(one+2*two+2*three+four)/6
            rows=[]
            for stride in (1,2):
                integ=simpson(np.array(values)[::stride],dx=DURATION*stride/32,axis=0)
                for width,vec in zip(FRACTIONS,integ):
                    rows.append(dict(stride=stride,width=width,**dict(zip(DETAIL if detail else LABELS,vec))))
            prefix="microscopic" if detail else "parts"
            save(f"{prefix}-h{native}-n{grid}-t{steps}-seed{seed}-off{flag}.csv",rows)
            print("parts",grid,steps,native,seed,flag,flush=True)

if __name__=="__main__":run(*map(int,sys.argv[1:]))
