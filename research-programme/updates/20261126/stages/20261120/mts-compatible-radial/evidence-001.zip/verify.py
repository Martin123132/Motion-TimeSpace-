from replay import *
from score import rows
import re

def run():
    safe()
    import clock_tide
    upstream={root.name:pin for root,pin in clock_tide.PINS.items()}
    for folder in clock_tide.PINS:
        for name,fingerprint in clock_tide.files(folder).items():
            assert digest(folder/name)==fingerprint,(folder,name)
    for name,expected in registry.items():assert digest(PARENT/name)==expected,name
    counts={}
    for path in HERE.glob("*.csv"):
        data=rows(path)
        assert data and all(None not in r.values() and None not in r and all(v.strip() and v.lower() not in ("nan","inf","-inf") for v in r.values()) for r in data),path
        counts[path.name]=len(data)
    for args in POINTS:
        res,steps,project,method=args[:4];edge=args[4] if len(args)>4 else 6
        for seed in (0,1,-1):
            for flag in (0,1):assert counts[f"{method}-h5-n{res}-t{steps}-p{project}-L{edge}-seed{seed}-off{flag}.csv"]==6
    for args in WINDOWS:
        res,steps,project,method=args[:4];native=args[4] if len(args)>4 else 5
        for seed in (0,1,-1):
            for flag in (0,1):assert counts[f"window-{method}-h{native}-n{res}-t{steps}-p{project}-seed{seed}-off{flag}.csv"]==8
    assert (HERE/"cold-stagger-off0.csv").read_bytes()==(HERE/"cold-stagger-off1.csv").read_bytes()
    assert counts["cold-stagger-off0.csv"]==15
    assert counts["off-constraint-fixture.csv"]==96 and counts["stagger-fixture.csv"]==24
    assert counts["exact-evolving-dust.csv"]==48 and counts["proper-window-controls.csv"]==16
    values=rows(HERE/"checks.csv")
    for prefix in ("curvature-","weak-scaled-","original-","time-","buffer-","integral-"):
        checks=[r for r in values if r["test"].startswith(prefix)]
        assert checks and all(r["passes"]=="True" for r in checks),prefix
    assert any(r["passes"]=="False" for r in values if r["reference"]=="small constraint change")
    assert any(r["pass_readouts"]=="False" for r in rows(HERE/"point-comparison.csv"))
    assert counts["microscopic-budget.csv"]==8 and counts["frozen-stress-test.csv"]==16
    preds=rows(HERE/"frozen-stress-test.csv")
    for row in preds:
        assert abs(float(row["error_on_stress"]))>2e-5
        if row["frame"]=="falling":
            other=next(v for v in preds if v["frame"]=="eulerian" and all(v[k]==row[k] for k in ("native","seed","width")))
            assert abs(float(row["error_on_stress"]))<abs(float(other["error_on_stress"]))
    assert all(.60<float(r["net_share"])<.75 for r in rows(HERE/"microscopic-budget.csv"))
    assert all(min(float(r["gauss_ppm"]),float(r["ricci_ppm"]))>0 for r in rows(HERE/"frame-and-curvature.csv"))
    for path in HERE.glob("*.py"):compile(path.read_bytes(),str(path),"exec")
    for path in HERE.glob("*.md"):
        for link in re.findall(r"(?<!\w)\[[^\]\n]+\]\(([^)]+)\)",path.read_text(encoding="utf8")):
            assert link.startswith("https://") or (HERE/link).is_file(),(path,link)
    assert not list(HERE.glob("*.partial")) and not (HERE/"__pycache__").exists()
    payload={p.name:digest(p) for p in sorted(HERE.iterdir()) if p.is_file() and p.name!="seal.json"}
    report=dict(files=payload,rows=counts,predecessor=PIN,ancestors=upstream,
                checked_parent_files=len(registry)+sum(len(clock_tide.files(f)) for f in clock_tide.PINS),
                scope="early signed host, local scalar energy/stress and two registered finite apertures",tolerance=2e-5)
    raw=(json.dumps(report,sort_keys=True,indent=2)+"\n").encode()
    path=HERE/"seal.json"
    if path.exists():assert path.read_bytes()==raw
    else:
        with path.open("xb") as stream:stream.write(raw)
    print(len(payload),"local files;",sum(counts.values()),"numeric/check rows;",report["checked_parent_files"],"upstream files;",digest(path))
if __name__=="__main__":run()
