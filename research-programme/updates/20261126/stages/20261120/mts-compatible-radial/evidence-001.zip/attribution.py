from score import *
from source_budget import LABELS

def main():
    result=[];paths=sorted(HERE.glob("parts-h*-seed-1-off1.csv"))
    for path in paths:
        tag=path.name.split("-seed")[0]
        native,grid,steps=map(int,re.findall(r"(?:-h|-n|-t)(\d+)",tag))
        controls=rows(HERE/f"newton-normal-parts-h{native}-t{8 if native==5 else 4}.csv")
        full=rows(HERE/f"newton-windows-h{native}-n{8 if native==5 else 4}.csv")
        for stride in (1,2):
            for width in (.15,.30):
                grid_ref=read_group(f"window-stagger-h{native}-n{grid}-t{steps}-p1",dict(stride=str(stride),width=str(width),quadrature="8"))
                lookup=read_group(tag,dict(stride=str(stride),width=str(width)))
                for seed in (1,-1):
                    local=float(next(row["increment"] for row in controls if int(row["seed"])==seed and float(row["width"])==width))
                    ref=float(next(row["increment"] for row in full if int(row["seed"])==seed and float(row["width"])==width and row["quadrature"]=="16"))
                    each={key:lookup(seed,key) for key in LABELS}
                    including=grid_ref(seed,"gauss")
                    budget=dict(rest_mass=each["rest_dust"]+each["rest_heavy"]-local,
                            kinetic_and_gradient=each["energy_dust"]+each["energy_heavy"],motion_stress=each["stress_dust"]+each["stress_heavy"],
                            other_matter=each["energy_environment"]+each["stress_environment"],
                            geometry=each["intrinsic"]+each["extrinsic"]-(ref-local))
                    error=sum(budget.values())-(including-ref)
                    result.append(dict(native=native,grid=grid,steps=steps,stride=stride,seed=seed,width=width,
                        gr=including,newton=ref,newton_local=local,offset_ppm=(including/ref-1)*1e6,
                        closure_on_tide=error/ref,closure_on_difference=error/(including-ref),
                        **each,**{key+"_ppm":val/ref*1e6 for key,val in budget.items()}))
                    assert abs(error/ref)<2e-5
    assert len(paths)==3
    save("source-attribution.csv",result)
    for row in result:
        if row["grid"]==120 and row["stride"]==1 and row["native"]==5:
            print(row["width"],row["seed"],"budget ppm:",*[round(row[key],4) for key in row if key.endswith("_ppm")],row["closure_on_tide"])
if __name__=="__main__":main()
