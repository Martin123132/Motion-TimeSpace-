"""Integrate the moving proper ruler before differentiating highly cancelling curvature defects."""
from scheme import *
from scipy.interpolate import CubicSpline
from numpy.polynomial.legendre import leggauss
from scipy.special import beta
from scipy.integrate import simpson
from stagger import Stagger

CENTER=RADII[1]
FRACTIONS=(.15,.30)
UNIT=beta(.5,5)

def weight(distance,width,degree=0):
    u=(distance-CENTER)/width
    t=np.maximum(0.,1-u*u)
    if degree==0:return t**4/(width*UNIT)
    if degree==1:return -8*u*t**3/(width**2*UNIT)
    return (-8*t**3+48*u*u*t*t)/(width**3*UNIT)

class Window:
    def __init__(self,shell,state,rhs,nquad):
        self.shell=shell
        support=(shell.r>CENTER*.65)&(shell.r<CENTER*1.35)
        centers=shell.r[support];nodes,weights=leggauss(nquad)
        self.pos=(centers[:,None]+shell.dx*nodes/2).ravel()
        self.quad=np.tile(weights,len(centers))*shell.dx/2
        self.mesh=np.r_[-shell.r[:8][::-1],shell.r]
        ell,bend,tilt=state[:3].real
        radial=exp(ell);vr=mul(radial,rhs[0].real)
        interp=self.spline(np.stack((radial,vr)))
        metric,dmetric=interp(self.pos)
        slope=interp(self.pos,1)[0]
        anti=interp.antiderivative();dist,ddist=anti(self.pos)-anti(0.)[...,None]
        ellp,bp,vv=self.at(np.stack((ell,bend,tilt)))
        de=self.spline(ell)(self.pos,1);db=self.spline(bend)(self.pos,1)
        volume=self.pos**2*np.exp(ellp[0]+2*bp[0])
        volq=ellp[1]+2*bp[1]
        volrate=2/self.pos+de[0]+2*db[0]
        self.widths=[]
        for fraction in FRACTIONS:
            width=CENTER*fraction
            w,wp,wpp=[weight(dist[0],width,i) for i in (0,1,2)]
            normal,angular=metric;length=dist[1]
            first=w*normal;second=wp*normal*length+w*angular
            dfirst=wp*ddist[0]*normal+w*dmetric[0]
            dsecond=wpp*ddist[0]*normal*length+wp*(dmetric[0]*length+normal*ddist[1])+wp*ddist[0]*angular+w*dmetric[1]
            prime=wp*normal**2+w*slope[0]
            secondprime=wpp*normal**2*length+wp*(slope[0]*length+2*normal*angular)+w*slope[1]
            test1=(prime-first*volrate)/volume
            test0=(secondprime-prime*volq-first*(de[1]+2*db[1])-(second-first*volq)*volrate)/volume
            self.widths.append(np.stack((first,second,dfirst,dsecond,test1,test0))*self.quad)
        self.widths=np.array(self.widths)
        self.bend=bp;self.ell=ellp;self.tilt=vv
    def spline(self,values):
        return CubicSpline(self.mesh,np.concatenate((values[...,:8][...,::-1],values),axis=-1),axis=-1)
    def at(self,arr):return self.spline(arr)(self.pos)
    def times(self,tensor,rate):
        mono,quad=self.at(tensor);mrate,qrate=self.at(rate)
        w=self.widths
        return w[:,0]@qrate+w[:,1]@mrate,w[:,2]@quad+w[:,3]@mono
    def weak_flux(self,radial,tangent):
        radial=self.at(radial)
        flux=self.pos**2*mul(exp(2*self.bend),radial)
        tang=(np.exp(-self.bend[0])*self.at(tangent)-self.tilt[1]*np.exp(-self.ell[0])*radial[0])/self.pos
        return 2*(self.widths[:,4]@flux[1]+self.widths[:,5]@flux[0])+12*self.widths[:,0]@tang

def tensors(shell,state,rates):
    perturb=1.e-19
    tang=lambda idx:state[idx].real+1j*perturb*rates[idx].real
    imag=lambda idx:state[idx].imag+1j*perturb*rates[idx].imag
    ell,bend,tilt,tensor,trace,shear=[tang(idx) for idx in range(6)]
    en=tang(17)
    normal=exp(-ell);volume=exp(-ell-2*bend)
    matter=np.zeros_like(en)
    for idx in range(3 if shell.flag else 2):
        number,phase=tang(8+2*idx),tang(9+2*idx)
        psq=square(mul(normal,shell.diff(phase)))
        root=np.sqrt(1+psq[0]);gamma=pair(root,psq[1]/(2*root))
        den=shell.rho[idx]*mul(number,volume)
        en+=mul(den,gamma);matter+=2/3*mul(den,mul(psq,inv(gamma)))
    if not shell.flag:
        den=shell.rho[-1]*exp(2*tang(14));one=pair(np.ones_like(shell.r))
        grad=(square(mul(normal,shell.diff(tang(14))))+square(mul(normal,shell.diff(imag(14)))))/shell.mu**2
        kin=square(tang(15)+trace/(2*shell.mu))+square(imag(15)-one)
        en+=mul(den,one+kin+grad)/2;matter+=2/3*mul(den,grad)
    bp=shell.diff(bend);r=shell.r
    e0=np.exp(-2*ell[0]);eb=np.exp(-2*bend[0])
    gap=-2*mul(exp(-2*ell),square(bp)+2*bp/r)
    gap[0]+=2*e0*np.expm1(2*(ell[0]-bend[0]))/r**2
    gap[1]+=(eb*(8*bend[1]+12*tensor[1])+e0*(4*ell[1]-12*tilt[1]))/r**2-12*e0*bp[0]*tilt[1]/r
    direct=shell.ricci(ell,bend,tilt,tensor)[0]
    gauss=(2*en-2*square(trace)/3+1.5*square(shear))/6-gap/2
    other=matter-mul(trace,shear)/3+square(shear)/2
    return other-direct,other-gauss

def sample(shell,time,state,rhs):
    ham,actual,local,expanded,face=readings(shell,time,state,rhs)
    info=shell.dynamics(time,state,True)
    tides=np.array(tensors(shell,state,rhs))
    incident=shell.incident.bank.at(time)[4]+1j*1e-19*shell.incident.bank.samples(time,1)[4]
    tides[:,1]+=incident
    rows=[]
    for degree in (4,8):
        win=Window(shell,state,rhs,degree)
        value=[]
        for tide in tides:
            fixed,moved=win.times(tide.real,tide.imag/1e-19)
            value.append(fixed+moved)
        fixed,moved=win.times(ham,actual)
        forecast=win.times(ham,local+face)[0]
        weak=win.weak_flux(info["mom_r"],info["mom_theta"][1])+win.times(ham,local)[0]
        value+= [(fixed+moved)/6,(moved+forecast)/6,(moved+weak)/6,moved/6]
        rows.append(np.array(value).T)
    return np.array(rows)

def run(res,steps,project,method,native=5):
    for seed in (0,1,-1):
        for flag in (0,1):
            cls=Stagger if method=="stagger" else Radial
            with np.load(checked(CLOUD,f"launch-h{native}-off{flag}-seed{seed}.npz")) as bank:shell=cls(bank,res,6,flag,project,method)
            start=shell.initial;change=np.zeros_like(start);dt=DURATION/(2*steps);history=[]
            for tick in range(2*steps+1):
                now=tick*dt;state=start+change;one=shell.dynamics(now,state)
                if tick%(steps//16)==0:safe();history.append(sample(shell,now,state,one))
                if tick==2*steps:break
                two=shell.dynamics(now+dt/2,start+(change+dt*one/2))
                three=shell.dynamics(now+dt/2,start+(change+dt*two/2))
                four=shell.dynamics(now+dt,start+(change+dt*three))
                change+=dt*(one+2*two+2*three+four)/6
            rows=[]
            for stride in (1,2):
                vals=simpson(np.array(history)[::stride],dx=DURATION*stride/32,axis=0)
                for degree,windowdata in zip((4,8),vals):
                    for frac,vec in zip(FRACTIONS,windowdata):
                        rows.append(dict(stride=stride,quadrature=degree,width=frac,**dict(zip(("ricci","gauss","defect","face_transport","weak_transport","ruler_defect"),vec))))
            assert np.isfinite(vals).all()
            save(f"window-{method}-h{native}-n{res}-t{steps}-p{project}-seed{seed}-off{flag}.csv",rows)
            print("window",method,res,steps,project,seed,flag,flush=True)

if __name__=="__main__":run(int(sys.argv[1]),int(sys.argv[2]),int(sys.argv[3]),sys.argv[4],*map(int,sys.argv[5:]))
