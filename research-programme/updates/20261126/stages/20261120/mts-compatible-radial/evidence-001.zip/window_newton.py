"""Pass proper-length quadrature nodes through the unchanged Newtonian solver, without writing into its folder."""
from window import *
import clock_tide

def run(grid,steps):
    nodes=[];groups=[]
    for width in FRACTIONS:
        spread=CENTER*width
        left,right=CENTER-spread,CENTER+spread
        mesh=np.arange(0,3,1/grid)
        knots=np.r_[left,mesh[(mesh>left)&(mesh<right)],right]
        half=np.diff(knots)/2;middle=(knots[1:]+knots[:-1])/2
        for degree in (8,16):
            absc,weights=leggauss(degree);radii=(middle[:,None]+half[:,None]*absc).ravel()
            weights=(weights*half[:,None]).ravel()*weight(radii,spread)
            assert abs(sum(weights)-1)<1.e-13
            groups.append((degree,width,radii,weights))
            nodes.extend(radii)
    capture={}
    original_radii,original_output=clock_tide.RADII,clock_tide.output
    try:
        clock_tide.RADII=tuple(sorted(set((*RADII,*nodes))))
        clock_tide.output=lambda name,rows:capture.update({name:rows})
        clock_tide.advance("heavy",grid,"normal",steps)
    finally:
        clock_tide.RADII,clock_tide.output=original_radii,original_output
    name=f"heavy-h{grid}-normal-n{steps}.csv"
    by={(row["seed"],row["channel"],row["radius"]):row for row in capture[name]}
    with saved(name).open() as stream:
        for row in csv.DictReader(stream):
            new=by[int(row["seed"]),row["channel"],float(row["radius"])]
            for key in ("rate_integral","launch","final"):assert float(row[key])==new[key]
    results=[]
    for seed in (1,-1):
        for degree,width,radii,weights in groups:
            def get(key):
                arr=np.array([by[seed,"on",radius][key]-by[seed,"off",radius][key] for radius in radii])
                return weights@arr
            results.append(dict(grid=grid,steps=steps,seed=seed,width=width,quadrature=degree,
                increment=get("rate_integral"),launch=get("launch"),endpoint_check=get("endpoint_change")))
    save(f"newton-windows-h{grid}-n{steps}.csv",results)
if __name__=="__main__":run(*map(int,sys.argv[1:]))
