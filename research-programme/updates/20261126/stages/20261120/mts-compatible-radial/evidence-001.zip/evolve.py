from scheme import *
from stagger import Stagger

def run(rate,steps,project,method,edge=6,native=5):
    safe()
    tag=f"{method}-h{native}-n{rate}-t{steps}-p{project}-L{edge}"
    for seed in (0,1,-1):
        for flag in (0,1):
            with np.load(checked(CLOUD,f"launch-h{native}-off{flag}-seed{seed}.npz")) as packet:
                cls=Stagger if method=="stagger" else Radial
                shell=cls(packet,rate,edge,flag,project,method)
            start=shell.initial;change=np.zeros_like(start);step=DURATION/(2*steps)
            data=[];peak=0.
            for tick in range(2*steps+1):
                now=tick*step;state=start+change
                one=shell.dynamics(now,state)
                if tick%(steps//16)==0:
                    safe()
                    ham,actual,local,flow,flux=readings(shell,now,state,one)
                    def read(val):
                        return np.array(ruler_variation(shell,state[:14].real,one[:14].real,ham,val))
                    observed=read(actual);src=read(local);expanded=read(flow);conservative=read(flux)
                    tides=field_tides(shell,now,state,one)
                    data.append(np.stack((observed[:,1]/6,observed[:,2]/6,src[:,1]/6,expanded[:,1]/6,
                                         conservative[:,1]/6,*tides),axis=-1))
                    peak=max(peak,float(np.max(abs(change))))
                if tick==2*steps:break
                two=shell.dynamics(now+step/2,start+(change+step*one/2))
                three=shell.dynamics(now+step/2,start+(change+step*two/2))
                four=shell.dynamics(now+step,start+(change+step*three))
                change+=step*(one+2*two+2*three+four)/6
            assert np.isfinite(data).all() and np.isfinite(change).all()
            rows=[]
            for stride in (1,2):
                val=simpson(np.array(data)[::stride],dx=DURATION*stride/32,axis=0)
                for idx,radius in enumerate(RADII):
                    rows.append(dict(radius=radius,stride=stride,**dict(zip(("direct","ruler","local","expanded","conservative","ricci","gauss"),val[idx]))))
            save(f"{tag}-seed{seed}-off{flag}.csv",rows)
            print(tag,seed,flag,flush=True)
if __name__=="__main__":run(int(sys.argv[1]),int(sys.argv[2]),int(sys.argv[3]),sys.argv[4],*map(int,sys.argv[5:]))
