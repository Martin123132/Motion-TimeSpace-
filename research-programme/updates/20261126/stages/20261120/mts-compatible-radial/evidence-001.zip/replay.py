from scheme import *
import subprocess

POINTS=((80,96,1,"flux"),(80,96,1,"chain"),(120,96,1,"flux"),(80,96,1,"flux8"),(80,96,0,"flux"),
        (80,96,1,"stagger"),(120,96,1,"stagger"),(80,96,0,"stagger"),(160,96,1,"stagger"),(80,192,1,"stagger",8),
        (80,192,1,"original"),(80,96,1,"stagger",8))
WINDOWS=((80,96,1,"flux"),(120,96,1,"flux"),(80,96,0,"flux"),(160,96,1,"flux"),
         (80,96,0,"stagger"),(120,96,1,"stagger"),(160,96,1,"stagger"),(120,96,0,"stagger"),
         (120,192,1,"stagger"),(120,96,1,"stagger",4),(80,96,1,"original"))

def jobs(mode):
    quick=[("fixtures.py",),("fixtures.py","stagger"),("instrument.py",),("exact_dust.py",),("stress_forecast.py",5,8)]
    if mode=="sample":return quick+[("window.py",120,96,1,"stagger"),("release_tables.py",),("checks.py",)]
    assert mode=="all"
    full=quick+[("cold.py","stagger"),("stress_forecast.py",4,4),("window_newton.py",4,4),("window_newton.py",5,8)]
    full += [("newton_local.py",*params) for params in ((5,8,"normal"),(4,4,"normal"),(5,8,"longitudinal"),(5,8,"archive"))]
    full += [("evolve.py",*params) for params in POINTS]+[("window.py",*params) for params in WINDOWS]
    full += [("source_budget.py",*params) for params in ((120,96,5),(160,96,5),(120,96,4),(120,96,5,1),(120,96,4,1))]
    return full+[("attribution.py",),("release_tables.py",),("checks.py",),("verify.py",)]
if __name__=="__main__":
    for job in jobs(sys.argv[1]):
        safe()
        subprocess.run([sys.executable,"-B",*map(str,job)],cwd=HERE,check=True)
        print("replayed",*job,flush=True)
