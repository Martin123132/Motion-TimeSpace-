from scheme import *
import re

def rows(path):
    with path.open(newline="") as stream:return list(csv.DictReader(stream))

def read_group(tag,criterion):
    vals={}
    for seed in (0,1,-1):
        for flag in (0,1):
            block=rows(HERE/f"{tag}-seed{seed}-off{flag}.csv")
            vals[seed,flag]=next(row for row in block if all(row[key]==value for key,value in criterion.items()))
    return lambda seed,key:(float(vals[seed,0][key])-float(vals[0,0][key]))-(float(vals[seed,1][key])-float(vals[0,1][key]))

def compute(save_results=True):
    outs=[];wout=[]
    grav=rows(saved("signed-increments.csv"))
    for path in sorted(HERE.glob("*-L*-seed-1-off1.csv")):
        tag=path.name.split("-seed")[0]
        method=tag.split("-")[0]
        native,grid,steps,project,edge=map(int,re.findall(r"-(?:h|n|t|p|L)(\d+)",tag))
        for stride in (1,2):
            for radius in RADII:
                diff=read_group(tag,dict(stride=str(stride),radius=str(radius)))
                for seed in (1,-1):
                    ref=float(next(row["rate_integral"] for row in grav if (row["model"],row["history"],int(row["grid"]),int(row["seed"]),float(row["radius"]))==("heavy","normal",native,seed,radius)))
                    dr=diff(seed,"direct");shift=diff(seed,"ruler");local=diff(seed,"local")
                    tr=diff(seed,"conservative" if method in ("flux","flux8","stagger") else "expanded")
                    gauss=diff(seed,"gauss");ricci=diff(seed,"ricci")
                    outs.append(dict(method=method,native=native,grid=grid,steps=steps,project=project,edge=edge,stride=stride,
                        radius=radius,seed=seed,newton=ref,gauss=gauss,ricci=ricci,gauss_offset_ppm=(gauss/ref-1)*1e6,
                        ricci_offset_ppm=(ricci/ref-1)*1e6,split_on_tide=(gauss-ricci)/gauss,
                        constraint_rate=dr+shift,identity_on_tide=(dr+shift-gauss+ricci)/gauss,
                        independent_rel=(local+tr-dr)/(dr+shift),independent_on_tide=(local+tr-dr)/gauss,
                        pass_readouts=abs((gauss-ricci)/gauss)<2e-5,pass_transport=abs((local+tr-dr)/(dr+shift))<2e-5))
    for path in sorted(HERE.glob("window-*-seed-1-off1.csv")):
        tag=path.name.split("-seed")[0]
        method=tag.split("-")[1]
        native,grid,steps,project=map(int,re.findall(r"-(?:h|n|t|p)(\d+)",tag))
        newton=rows(HERE/f"newton-windows-h{native}-n{8 if native==5 else 4}.csv")
        for stride in (1,2):
            for degree in (4,8):
                for width in (.15,.30):
                    diff=read_group(tag,dict(stride=str(stride),quadrature=str(degree),width=str(width)))
                    for seed in (1,-1):
                        ref=float(next(row["increment"] for row in newton if float(row["width"])==width and int(row["seed"])==seed and row["quadrature"]=="16"))
                        gauss,ricci,defect,face,weak,shift=[diff(seed,key) for key in ("gauss","ricci","defect","face_transport","weak_transport","ruler_defect")]
                        wout.append(dict(method=method,native=native,grid=grid,steps=steps,project=project,degree=degree,stride=stride,
                            width=width,seed=seed,newton=ref,gauss=gauss,ricci=ricci,gauss_offset_ppm=(gauss/ref-1)*1e6,
                            ricci_offset_ppm=(ricci/ref-1)*1e6,split_on_tide=(gauss-ricci)/gauss,defect=defect,
                            identity_on_tide=(defect-gauss+ricci)/gauss,face_rel=face/defect-1,weak_rel=weak/defect-1,
                            weak_error_on_tide=(weak-defect)/gauss,ruler=shift))
    if save_results:
        separate=lambda row:row["method"]=="original" or (row["edge"]==8 and row["steps"]==96)
        save("point-comparison.csv",[row for row in outs if not separate(row)])
        save("point-replay-and-buffer.csv",[row for row in outs if separate(row)])
        save("finite-ruler-comparison.csv",wout)
    return outs,wout

if __name__=="__main__":
    point,window=compute("--inspect" not in sys.argv)
    for row in point:
        if row["stride"]==1 and row["radius"]==RADII[1] and row["seed"]==1:
            print(row["method"],row["grid"],row["project"],round(row["ricci_offset_ppm"],2),round(row["gauss_offset_ppm"],2),round(row["independent_rel"],4))
    for row in window:
        if row["stride"]==1 and row["degree"]==8 and row["seed"]==1:
            print("window",row["method"],row["grid"],row["project"],row["width"],round(row["ricci_offset_ppm"],2),round(row["gauss_offset_ppm"],2),round(row["weak_rel"],4))
