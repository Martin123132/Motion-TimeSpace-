from attribution import *
from source_budget import DETAIL

def main():
    points,win=compute()
    attribution=rows(HERE/"source-attribution.csv")
    moments=[];variants=[];forecast=[]
    for native in (4,5):
        steps=8 if native==5 else 4
        model=rows(HERE/f"stress-forecast-h{native}-t{steps}.csv")
        for width in (.15,.30):
            for seed in (1,-1):
                actual=read_group(f"microscopic-h{native}-n120-t96",dict(stride="1",width=str(width)))
                budget=next(r for r in attribution if (int(r["native"]),int(r["grid"]),int(r["seed"]),float(r["width"]),int(r["stride"]))==(native,120,seed,width,1))
                gravity=float(budget["newton"]);effect=float(budget["offset_ppm"])
                terms=np.array([actual(seed,k) for k in DETAIL])
                measured=np.sum(terms)
                relative=measured/gravity
                assert abs(relative-(float(budget["motion_stress_ppm"])+float(budget["kinetic_and_gradient_ppm"]))*1e-6)<2e-8
                moments.append(dict(native=native,width=width,seed=seed,full_offset_ppm=effect,
                    **{k+"_ppm":v/gravity*1e6 for k,v in zip(DETAIL,terms)},net_ppm=relative*1e6,net_share=relative*1e6/effect))
                for frame in ("eulerian","falling"):
                    dd={(int(row["seed"]),int(row["flag"])):row for row in model if float(row["width"])==width and row["frame"]==frame}
                    def diff(key):return (float(dd[seed,0][key])-float(dd[0,0][key]))-(float(dd[seed,1][key])-float(dd[0,1][key]))
                    pred=np.array([diff(k) for k in DETAIL[:3]])
                    forecast.append(dict(native=native,frame=frame,width=width,seed=seed,
                        actual=measured,predicted=diff("net"),predicted_ppm=diff("net")/gravity*1e6,
                        error_on_stress=diff("net")/measured-1,missing_from_full_ppm=effect-diff("net")/gravity*1e6,
                        **{k+"_error_on_stress":err/measured for k,err in zip(DETAIL[:3],pred-terms[:3])},
                        max_normal_shift=max(float(row["peak_estimated_advection"]) for row in dd.values())))
    for row in win:
        if row["degree"]!=8 or row["stride"]!=1:continue
        num=row["newton"]
        for history in (("normal","longitudinal","archive") if row["native"]==5 else ("normal",)):
            if history!="normal":
                data=rows(HERE/f"newton-{history}-parts-h5-t8.csv")
                num=float(next(r["increment"] for r in data if int(r["seed"])==row["seed"] and float(r["width"])==row["width"] and r["kind"]=="total"))
            variants.append(dict(method=row["method"],grid=row["grid"],native=row["native"],steps=row["steps"],project=row["project"],
                seed=row["seed"],width=row["width"],history=history,newton=num,gauss_ppm=(row["gauss"]/num-1)*1e6,ricci_ppm=(row["ricci"]/num-1)*1e6))
    save("microscopic-budget.csv",moments);save("frozen-stress-test.csv",forecast);save("frame-and-curvature.csv",variants)
    for row in forecast:
        if row["native"]==5:print(row["frame"],row["width"],row["seed"],"forecast",row["predicted_ppm"],"relative error",row["error_on_stress"])
if __name__=="__main__":main()
