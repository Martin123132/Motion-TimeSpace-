"""Off-constraint Gaussian radial flow on a nonuniform but intrinsically flat metric."""
from scheme import *
from stagger import Stagger
import sympy as sym

class Empty:
    local=None
    def __init__(self,radius):self.data=np.zeros((7,len(radius)))
    def at(self,time):return self.data.copy()

def test(methods=("original","chain","flux","flux8"),output="off-constraint-fixture.csv"):
    radius,width=sym.symbols("radius width",positive=True)
    bump=sym.exp(-((radius**2-1.353**2)/(2*1.353*width))**2)
    trace=-.51+.04*bump
    quad=.011*radius**2*bump
    shear=.013*radius**2*bump
    volflow=-2*(shear.diff(radius,2)+5*shear.diff(radius)/radius+3*shear/radius**2)
    lap=lambda expr,ell:expr.diff(radius,2)+2*expr.diff(radius)/radius-ell*(ell+1)*expr/radius**2
    analytic=sym.lambdify((radius,width),(trace,quad,shear,volflow+4*lap(trace,0)/3,4*lap(quad,2)/3),"numpy",cse=True)
    rows=[]
    for method in methods:
        for rate in (40,80,120,160):
            with np.load(checked(CLOUD,"launch-h5-off1-seed1.npz")) as pkt:
                cls=Stagger if method=="stagger" else Radial
                shell=cls(pkt,rate,6,1,1,method)
            shell.incident=Empty(shell.r);shell.rho[:]=0
            coord=shell.r;dilate=.065*np.exp(-(coord/1.74)**2)
            physical=coord*(1+dilate);stretch=1+dilate*(1-2*(coord/1.74)**2)
            active=(physical>.6)&(physical<3.)
            for scale in (.20,.08,.04):
                raw=analytic(physical,scale);state=np.zeros_like(shell.initial)
                state[0,0]=np.log(stretch);state[1,0]=np.log1p(dilate)
                state[4]=pair(raw[0],raw[1]);state[5,0]=raw[2]
                ham_exact=2/3*square(state[4].real)-1.5*square(state[5].real)
                divergence=pair(*raw[3:])
                truth=mul(2*state[4].real/3+state[5].real/2,ham_exact)+divergence
                rhs=shell.dynamics(0,state)
                ham,actual,local,flow,flux=readings(shell,0,state,rhs)
                for part in range(2):
                    ref=truth[part,active];norm=np.max(abs(ref))
                    measured=actual[part,active];prediction=(local+(flux if method.startswith("flux") or method=="stagger" else flow))[part,active]
                    rows.append(dict(method=method,grid=rate,width=scale,harmonic=part,geometry=np.max(abs((ham-ham_exact)[part,active])),
                        direct_error=np.max(abs(measured-ref))/norm,propagated_error=np.max(abs(prediction-ref))/norm,
                        compatibility=np.max(abs(prediction-measured))/norm))
    save(output,rows)
    for method in methods:
        for width in (.20,.08,.04):
            for harmonic in (0,1):
                subset=[row for row in rows if (row["method"],row["width"],row["harmonic"])==(method,width,harmonic)]
                assert subset[-1]["direct_error"] < subset[0]["direct_error"] and subset[-1]["propagated_error"] < subset[0]["propagated_error"]
    print("analytic tests:",len(rows))

def faces():
    rows=[]
    for order,method in ((6,"flux"),(8,"flux8")):
        with np.load(checked(CLOUD,"launch-h5-off1-seed1.npz")) as pkt:shell=Radial(pkt,80,6,1,1,method)
        r=shell.r
        weights=np.array((1,-8,37,37,-8,1))/60 if order==6 else np.array((-3,29,-139,533,533,-139,29,-3))/840
        pad=order//2
        for name,arr,parity in (("mass",r**3*np.exp(-r*r/3),True),("scalar",.13+np.cos(13*r),False),
                                ("alternating",(-1.)**np.arange(len(r)),False)):
            ext=shell.extend(arr,parity,pad)
            face=sum(w*ext[index:index+len(r)+1] for index,w in enumerate(weights))
            internal=(r>.2)&(r<5.)
            diff=shell.diff(arr,odd=parity)
            error=np.max(abs(diff[internal]-np.diff(face)[internal]/shell.dx))
            first,last=np.flatnonzero(internal)[[0,-1]]
            balance=shell.dx*diff[first:last+1].sum()-face[last+1]+face[first]
            assert max(abs(balance),error)<1e-12,(method,name,balance,error)
            rows.append(dict(method=method,field=name,face_error=error,balance=balance,peak_gradient=np.max(abs(diff[internal]))))
    save("face-balance.csv",rows)
if __name__=="__main__":
    if "stagger" in sys.argv:test(("stagger",),"stagger-fixture.csv")
    else:test();faces()
