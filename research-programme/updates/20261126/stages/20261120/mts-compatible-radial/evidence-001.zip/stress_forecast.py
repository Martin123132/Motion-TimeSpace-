from window_newton import *
from scipy.special import spherical_jn

def locations(mesh,width,degree=16):
    radius=CENTER;spread=radius*width;left,right=radius-spread,radius+spread
    bounds=np.arange(mesh.segments+1)*mesh.h
    edges=np.r_[left,bounds[(bounds>left)&(bounds<right)],right]
    half=np.diff(edges)/2;mid=(edges[:-1]+edges[1:])/2;pos,weights=leggauss(degree)
    locations=(mid[:,None]+half[:,None]*pos).ravel()
    return locations,(weights*half[:,None]).ravel()*weight(locations,spread)

def radial(mesh,arr,radii):
    ids=(radii/mesh.h).astype(int);x=2*(radii/mesh.h-ids)-1
    mat=np.linalg.inv(clock_tide.legvander(2*mesh.loc[0]/mesh.h-1,mesh.order))
    base=clock_tide.legvander(x,mesh.order)@mat
    slope=clock_tide.legvander(x,mesh.order-1)@clock_tide.legder(mat)*2/mesh.h
    vals=mesh.grid(arr)[...,mesh.elem[ids]]
    return tuple(np.einsum("...ij,ij->...i",vals,w) for w in (base,slope))

def source(sim,state,flag,offset,r):
    mesh=sim.mesh;p=sim.patch;hub,scale=p.coeff(clock_tide.START+offset)
    z,zr=radial(mesh,state[0],r)
    ns=1+z[0]/r;gp=(zr[1]-z[1]/r)/r;gn=(zr[0]-z[0]/r)/r
    quad,qgrad=radial(mesh,state[1][flag],r)
    _,vel_grad=radial(mesh,state[2][flag],r)
    refdens,refvel=sim.ref.solution(clock_tide.START+offset)[:,flag]*sim.ref.weight
    kk=p.k[:,None]
    basis=spherical_jn(2,kk*r);der=kk*spherical_jn(2,kk*r,True)
    qn=quad+refdens@basis;qnprime=qgrad+refdens@der;qvprime=vel_grad+refvel@der
    return ns,gp,gn,qn,qnprime,qvprime

def gravity(sim,state,flag,x,r,reference):
    mesh=sim.mesh;p=sim.patch;hub,scale=p.coeff(clock_tide.START+x)
    reduced=mesh.solve0(-mesh.lump*(p.p.coeff@state[0][0])/(2*scale))
    pot,grad=radial(mesh,reduced,r);mono=(grad-pot/r)/r
    qp=mesh.potential((p.p.coeff@state[1][flag])/(2*scale))
    _,gradient=radial(mesh,qp,r)
    kk=p.k[:,None]
    gradient+=(reference[flag](x)*sim.ref.weight)@(kk*spherical_jn(2,kk*r,True))
    return np.array([mono,gradient])

def evaluate(sim,state,flag,x,r,detector_velocity):
    ns,gp,gn,qn,qnprime,qvprime=source(sim,state,flag,x,r)
    gp=gp-detector_velocity[0];qvprime=qvprime-detector_velocity[1]
    density=sim.patch.p.coeff[:,None]/clock_tide.SCALE*np.exp(-3*x)
    bulk=density*(qn*gp**2+2*ns*gp*qvprime)/2
    amp=0*r
    if not flag:
        j=sim.patch.j;scale=clock_tide.SCALE*np.exp(x);factor=4*(scale*sim.patch.p.mass)**2
        amp=density[j]*(2*gn[j]*qnprime[j]/ns[j]-qn[j]*(gn[j]/ns[j])**2)/(2*factor)
    return np.stack((bulk[:-1].sum(axis=0),bulk[-1],amp))

def run(rate,steps):
    sim=clock_tide.BalancedNative("heavy",120,120*rate,False,"native36",clock_tide.START+.00002)
    traces=clock_tide.Traces("heavy",sim)
    sim.patch.coeff=lambda time:(float(traces.hubble(time-clock_tide.START)),clock_tide.SCALE*np.exp(time-clock_tide.START))
    sim.ref.solution=lambda time: traces.histories(time-clock_tide.START,"normal")
    stop=float(traces.native_stop);dt=stop/steps;rows=[]
    reference=[]
    for flag in (0,1):
        with np.load(checked(clock_tide.NORMAL,f"trace-heavy-off{flag}.npz")) as bank:
            field=dict(zip(bank["names"].tolist(),bank["values"].transpose(2,0,1)))
            scale=field["a"].mean(axis=0);x=np.log(scale/scale[0]);kk=bank["k"][:,None]
            reference.append(CubicSpline(x,((field["dsigma"]+field["H"]*field["sigma"])/kk).T,extrapolate=False))
    for seed in (0,1,-1):
        name=f"evolved-heavy-L120-h{rate}-t176.npz" if seed!=-1 else f"collar-heavy-L120-h{rate}--1.npz"
        with np.load(checked(clock_tide.FORM,name)) as raw:
            base=tuple(raw[key] for key in ("mono","density","velocity"))
        if not seed:base=tuple(np.zeros_like(v) for v in base)
        for flag in (0,1):
            sim.patch.wave=not flag;state=base;increment=tuple(np.zeros_like(v) for v in base)
            samples={width:locations(sim.mesh,width) for width in FRACTIONS}
            speed={width:np.zeros((2,len(values[0]))) for width,values in samples.items()}
            for i in range(steps):
                safe();temp=[];now=i*dt
                for fraction,prior in ((0,None),(.5,0),(.5,1),(1,2)):
                    x=now+fraction*dt
                    state=tuple(b+(d if prior is None else d+fraction*dt*temp[prior][0][j]) for j,(b,d) in enumerate(zip(base,increment)))
                    rhs=sim.rates(state,clock_tide.START+x)
                    forcing={width:-np.exp(x-stop)*gravity(sim,state,flag,x,r*np.exp(-stop),reference)/traces.hubble(x) for width,(r,_) in samples.items()}
                    temp.append((rhs,forcing))
                increment=tuple(d+dt*(temp[0][0][j]+2*temp[1][0][j]+2*temp[2][0][j]+temp[3][0][j])/6 for j,d in enumerate(increment))
                for width in speed:speed[width]+=dt*sum(w*t[1][width] for w,t in zip((1,2,2,1),temp))/6
            final=tuple(b+d for b,d in zip(base,increment))
            for width,(r,weights) in samples.items():
                zero=np.zeros_like(speed[width])
                start=evaluate(sim,base,flag,0,r,zero)
                for frame,curve in (("eulerian",zero),("falling",speed[width])):
                    end=evaluate(sim,final,flag,stop,r*np.exp(-stop),curve)
                    vals=(end-start)@weights
                    rows.append(dict(grid=rate,steps=steps,seed=seed,flag=flag,width=width,frame=frame,
                        dust_phase=vals[0],heavy_phase=vals[1],heavy_amplitude=vals[2],net=vals.sum(),
                        peak_normal_velocity=np.max(abs(curve)),peak_estimated_advection=np.max(abs(curve))*DURATION/2))
            print("stress prediction",rate,seed,flag,flush=True)
    save(f"stress-forecast-h{rate}-t{steps}.csv",rows)

if __name__=="__main__":run(*map(int,sys.argv[1:]))
