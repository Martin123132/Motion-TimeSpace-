"""Adjoint center-to-face / face-to-center derivatives without a Nyquist zero in the Laplacian."""
from scheme import *

class Stagger(Radial):
    weights=(75/64,-25/384,3/640)
    average=(75/128,-25/256,3/256)

    def toface(self,array,odd=False,slope=False):
        ext=self.extend(array,odd,3);count=array.shape[-1]+1
        if slope:
            return sum(w*(ext[...,3+j:3+j+count]-ext[...,2-j:2-j+count])
                       for j,w in enumerate(self.weights))/self.dx
        return sum(w*(ext[...,3+j:3+j+count]+ext[...,2-j:2-j+count]) for j,w in enumerate(self.average))

    def tocell(self,array,odd=True,slope=True):
        sign=-1 if odd else 1
        ext=np.concatenate((sign*array[...,2:0:-1],array,sign*array[...,-2:-4:-1]),axis=-1)
        count=array.shape[-1]-1
        if slope:
            return sum(w*(ext[...,3+j:3+j+count]-ext[...,2-j:2-j+count])
                       for j,w in enumerate(self.weights))/self.dx
        return sum(w*(ext[...,3+j:3+j+count]+ext[...,2-j:2-j+count]) for j,w in enumerate(self.average))

    def diff(self,array,degree=1,odd=False):
        grad=self.toface(array,odd,True)
        return self.tocell(grad,not odd,degree==2)

    @property
    def faces(self):return np.arange(len(self.r)+1)*self.dx

    def lap(self,field,ell,bend,tilt):
        face_flux=self.faces**2*mul(exp(self.toface(2*bend-ell)),self.toface(field,slope=True))
        ans=mul(exp(-ell-2*bend),self.tocell(face_flux))/self.r**2
        ans[1]+=6*tilt[1]*np.exp(-2*ell[0])*self.diff(field[0])/self.r-6*np.exp(-2*bend[0])*field[1]/self.r**2
        return ans

    def dynamics(self,time,state,details=False):
        result=Conserved.dynamics(self,time,state,details)
        if details:return result
        ell,bend,tilt,_,trace,shear=state[:6].real
        ellf=self.toface(ell);nr=exp(-ellf)
        for spec in range(3 if self.flag else 2):
            number,pot=state[8+2*spec:10+2*spec].real
            facepr=mul(nr,self.toface(pot,slope=True))
            psq=square(facepr);root=np.sqrt(1+psq[0]);gamma=pair(root,psq[1]/(2*root))
            fr=mul(self.toface(number),mul(nr,mul(facepr,inv(gamma))))
            centerpr=np.exp(-ell[0])*self.diff(pot[0])
            ft=number[0]*(np.exp(-2*bend[0])*pot[1]/self.r-tilt[1]*np.exp(-ell[0])*centerpr)/np.sqrt(1+centerpr**2)
            result[8+spec*2]=-self.tocell(self.faces**2*fr)/self.r**2
            result[8+spec*2,1]+=6*ft/self.r
        en,jr,jt=state[17:].real
        obs=self.incident.at(time);p=pair(obs[1],obs[3])/3
        outer=exp(-ell-2*bend)
        fr=self.faces**2*mul(exp(self.toface(2*bend)),self.toface(jr,odd=True))
        div=mul(outer,self.tocell(fr))/self.r**2
        div[1]-=6*(np.exp(-bend[0])*jt[1]-tilt[1]*np.exp(-ell[0])*jr[0])/self.r
        result[17]=mul(trace,en+p)+1.5*mul(shear,pair(np.zeros_like(self.r),obs[4]))-div
        return result

    def residual_flux(self,state,radial_defect,tangential):
        ell,bend,tilt,_,trace,shear,cross=state[:7].real
        rf=self.faces; face=self.toface; grad=lambda x:face(x,slope=True)
        ef=face(ell);bf=face(bend);sf=face(shear);nr=exp(-ef)
        radial=rf**2*mul(nr,grad(shear)-2*grad(trace)/3)
        area=rf*pair(np.ones_like(rf),3*face(tilt[1]))+rf**2*grad(bend)
        radial+=3*mul(mul(nr,area),sf)
        radial[1]-=6*rf*np.exp(-bf[0])*face(cross[1])
        jr=face(state[18].real,odd=True)
        vol=exp(-ef-2*bf)
        for spec in range(3 if self.flag else 2):
            number,pot=state[8+2*spec:10+2*spec].real
            jr+=self.rho[spec]*mul(mul(vol,face(number)),mul(nr,grad(pot)))
        if not self.flag:
            log,z=state[14:16]
            rest=self.rho[-1]*exp(2*face(log.real))
            momentum=face(z+trace/(2*self.mu))-1j*pair(np.ones_like(rf))
            jr-=mul(rest,mul(momentum.conj(),mul(nr,grad(log))).real)/self.mu
        radial-=rf**2*jr
        div=mul(exp(-ell-2*bend),self.tocell(mul(exp(2*bf),radial)))/self.r**2
        div[1]-=6*(np.exp(-bend[0])*tangential-tilt[1]*np.exp(-ell[0])*radial_defect[0])/self.r
        return div
