from disk import Assembly,Evolution,BRANCHES,HERE,np,guard,table,packet,sys,off_plane,STREAMS,CONVERSION,parent

def shape(t):
    value=np.clip(t/2,0.,1.)
    return value**2*(3-2*value)

def run(branch,steps):
    guard();obj=Assembly(branch);num=obj.number;dt=1/steps
    with np.load(HERE/("knots-"+branch+".npz")) as bank:vec=bank["fields"][0].astype(complex)
    mom=obj.moment(vec);ev=Evolution(obj,dt,vec)
    energy0=obj.energy(vec)-np.vdot(vec,obj.drive@vec).real
    equilibrium=obj.energy(obj.ground)
    scale=obj.energy(vec)-equilibrium
    records=[];states=[];streams=[];work=0.;max_work_error=0.;max_number_error=0.
    marks={round(t*steps) for t in (0,.25,.5,1.,2.,3.,4.)}
    force_energy=np.vdot(vec,obj.drive@vec).real
    for idx in range(4*steps+1):
        s=shape(idx*dt)
        if idx:
            old=shape((idx-1)*dt)
            angular=((s+old)/2-1)*obj.angular
            before=force_energy;current=mom;mid=vec
            for it in range(16):
                dphi=obj.phi((mom+current)/2)-ev.pref+angular
                improved=ev.factor.solve(vec-.5j*dt*obj.multiply(dphi,mid))
                now=2*improved-vec
                change=np.linalg.norm(improved-mid)/np.sqrt(num)
                mid=improved;current=obj.moment(now)
                if change<2e-14:break
            else:raise ArithmeticError("smooth midpoint")
            vec=now;mom=current
            force_energy=np.vdot(vec,obj.drive@vec).real
            work+=(s-old)*(before+force_energy)/2
        finalE=obj.energy(vec);instant=finalE-(1-s)*force_energy
        max_work_error=max(max_work_error,abs(instant-energy0-work)/scale)
        max_number_error=max(max_number_error,abs(np.vdot(vec,vec).real/num-1))
        assert max_work_error<2e-5 and max_number_error<1e-10
        if idx not in marks:continue
        guard();delta=obj.forces(mom-obj.reference)
        x=vec-(obj.ground@vec/num)*obj.ground
        records.append(dict(t=idx*dt,s=s,work=work,energy=instant,final_excess=finalE-equilibrium,
                          loss=np.vdot(x,x).real/num,max_work_error_over_quench=max_work_error,max_number_error=max_number_error,
                          delta_vertical=(1.5*delta[0]-6*delta[1])/np.hypot(6,1.5),**dict(zip(parent.SITES,delta))))
        states.append(vec.copy())
        for name,R,Z,q,qw,r0,z0,target,sw in STREAMS:
            dfr,dfz=off_plane(obj.bg,mom-obj.reference,R,Z)*CONVERSION
            streams.append(dict(t=idx*dt,stream=name,dFR=dfr,dFZ=dfz,dstrength=q*q*dfr+Z/R*dfz))
    prefix=f"smooth-{branch}-{steps}"
    table(prefix,records);table("stream-"+prefix,streams);packet(prefix,fields=np.stack(states))
    print(prefix,work,records[-1]["final_excess"]/scale,max_work_error,flush=True)
if __name__=="__main__":
    for branch in sys.argv[2:]:run(branch,int(sys.argv[1]))
