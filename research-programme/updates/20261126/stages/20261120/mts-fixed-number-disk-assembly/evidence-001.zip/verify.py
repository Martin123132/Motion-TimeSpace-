from disk import HERE,PRIOR,BRANCHES,CENSUS,np,parent,guard,put
import json
import re

def verify():
    guard()
    upstream=0
    for stage in (PRIOR,CENSUS):
        files=json.loads((stage/"seal.json").read_bytes())["files"]
        for name,digest in files.items():
            assert parent.sha(stage/name)==digest,(stage,name)
            upstream+=1
    for path in HERE.glob("*.md"):
        for link in re.findall(r"\]\(([^)#]+)\)",path.read_text(encoding="utf-8")):
            if link!="validation.json":assert (HERE/link).is_file(),link
    periods=panels=total_rows=small_fail=other_fail=0
    ranges={};refine_count=0
    def record(key,num):
        assert np.isfinite(num)
        pair=ranges.setdefault(key,[num,num]);pair[0]=min(pair[0],num);pair[1]=max(pair[1],num)
    for branch in BRANCHES:
        def read(prefix):return parent.read(HERE,prefix+"-"+branch)
        stat=read("stationary");assert [float(r["s"]) for r in stat]==[0,.25,.5,.75,1]
        n=float(stat[0]["number"]);excess=float(stat[0]["excess_at_final"])
        for label,stepslist in (("motion",(16,32,64,128)),("smooth",(32,64))):
            for steps in stepslist:
                name=f"{label}-{branch}-{steps}";data=parent.read(HERE,name)
                assert [float(r["t"]) for r in data]==[0,.25,.5,1,2,3,4]
                with np.load(HERE/(name+".npz")) as packet:
                    fields=packet["fields"];assert len(fields)==7 and np.isfinite(fields).all()
                    assert np.max(abs(np.sum(abs(fields)**2,axis=1)/n-1))<1e-10
                for r in data:
                    err=float(r["max_excess_energy_err" if label=="motion" else "max_work_error_over_quench"])
                    assert err<2e-5;record("energy_work_relative",err)
                if label=="smooth" and steps==64:
                    record("smooth_remaining_fraction",float(data[-1]["final_excess"])/excess)
                    assert [float(r["s"]) for r in data[-3:]]==[1.,1.,1.]
        source_panel=read("bands")
        assert len(source_panel)==1056
        for r in source_panel:
            val,lo,hi=map(float,(r["total"],r["low"],r["high"]))
            assert lo<hi and (lo<=val<=hi)==(r["inside"]=="True")== (r["coarser_inside"]=="True")
            assert r["total_precision"]=="True"
            if r["model"]=="static_NFW":assert float(r["delta"])==0
        total_rows+=len(source_panel)
        for r in read("pass-counts"):
            count=2 if r["model"]=="MTS" or branch=="anchorA" else 4
            assert int(r["inside"])==count and r["tested"]=="8"
            panels+=1
        fine=read("resolution");small_fail+=sum(r["inside_relative"]=="False" for r in fine);refine_count+=len(fine)
        assert all(r["passes"]=="True" for r in read("curvature-fine")[-2:])
        checks=read("identity-checks");assert len(checks)==19 and all(float(r["coulomb"])<=float(r["jensen"])+1e-14 for r in checks)
        other_fail+=sum(r["lumped_agrees_to_1e10"]=="False" for r in checks)
        assert all(r["lumped_agrees_to_1e10"]=="True" for r in checks[:7])
        sud=read("certified");mono=read("monotone-bound");assert len(sud)==len(mono)==6
        for r in sud:
            assert 0<float(r["loss_trap"])<1 and r["rejected_after_switch"]=="True"
            record("sudden_required_over_allowed",float(r["demand_over_allowance"]))
        for r in mono:
            assert r["unreachable"]=="True" and float(r["energy_cap"])>excess
            drive_upper=(float(r["energy_cap"])+float(r["ground_residual_allowance"]))/float(r["source_tilt"])+float(r["source_tilt"])*float(r["source_cap"])
            assert float(r["source_work_offset"])+drive_upper<float(r["energy_cap"])
            record("monotone_required_over_allowed",float(r["required_over_allowed"]))
            record("monotone_force_upper",float(r["max_extra_inward"]))
        w,=read("extra-work-bound")
        D=float(w["drive_tilt"]);A=float(w["force_tilt"]);E=float(w["energy"]);eps=float(w["residual"])
        c0=excess+float(stat[-1]["dE_ds"])-float(stat[0]["dE_ds"])
        independently=E-c0-(E+eps)/D-D*float(w["drive_compliance_upper"])
        assert abs(independently-float(w["work_lower_bound"]))<1e-13 and independently>0
        assert (E+eps)/A+A*float(w["force_compliance_upper"])<float(w["required_min"])
        record("additional_specific_work_lower",float(w["work_specific"]))
        for r in read("stream-panels"):
            assert abs(float(r["direction_widths"]))<1 and float(r["strength_widths"])< -1
    for r in parent.read(HERE,"radial-work-control"):
        assert abs(float(r["shell_integral"])-float(r["expectation_difference"]))<5e-10
        assert float(r["extra_source_in_actual_run"])==0.
        periods+=1
    assert periods==36
    assert all(float(r["all_state_max_difference"])<1e-12 for r in parent.read(HERE,"readout-order"))
    assert not [p for p in HERE.iterdir() if not p.is_file() or p.suffix not in (".npz",".py",".csv",".md",".json")]
    def save(name,data):
        put(name,(json.dumps(data,sort_keys=True,indent=2,allow_nan=False)+"\n").encode())
    save("validation.json",dict(prior_files_verified=upstream,after_assembly_total_rows=total_rows,pass_panels=panels,
                                induced_refinement_fail=small_fail,induced_refinement_entries=refine_count,
                                lumped_rough_state_fail=other_fail,radial_work_intervals=periods,ranges=ranges))
    files={p.name:parent.sha(p) for p in HERE.iterdir() if p.name!="seal.json"}
    save("seal.json",dict(files=files))
    print(len(files),"stage files",upstream,"prior; seal",parent.sha(HERE/"seal.json"),flush=True)
if __name__=="__main__":verify()
