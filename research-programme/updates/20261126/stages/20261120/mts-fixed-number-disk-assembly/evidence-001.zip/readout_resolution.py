from disk import Assembly,BRANCHES,HERE,np,parent,table,guard

def run():
    guard();obj=Assembly(BRANCHES[0]);bg=obj.bg;output=[]
    numbers={b:float(parent.read(HERE,"stationary-"+b)[0]["number"]) for b in BRANCHES}
    ref=(1.5*obj.wave.rows[0]-6*obj.wave.rows[1])/np.hypot(6,1.5)
    import prepare
    for n in (20,28):
        bank=prepare.rows_for(bg,n)
        rows=(1.5*bank[0]-6*bank[1])/np.hypot(6,1.5)
        raw=((rows-ref)@bg.harm.T)/bg.mesh.weight[:,None]
        blocks=np.einsum("ru,ul,uk,u->rlk",raw,bg.harm,bg.harm,bg.aw,optimize=True)
        bounds=np.linalg.eigvalsh(blocks)
        for b,N in numbers.items():
            output.append(dict(branch=b,order=n,all_state_max_difference=N*np.max(abs(bounds))))
    table("readout-order",output)
if __name__=="__main__":run()
