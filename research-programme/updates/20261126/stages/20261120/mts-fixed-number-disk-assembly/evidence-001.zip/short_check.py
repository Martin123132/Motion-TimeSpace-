from disk import Assembly,Evolution,BRANCHES,HERE,np,parent,table,guard

def run():
    guard();rows=[]
    for branch in BRANCHES:
        obj=Assembly(branch);wave=obj.wave;bg=obj.bg
        with np.load(HERE/("knots-"+branch+".npz")) as data:
            field=data["fields"][0];mu=float(data["mu_s"])
        predicted,dd=obj.curvature(field,mu)
        start=obj.moment(field)
        assert predicted[1]>0
        for divisor in (256,1024,4096,16384):
            dt=1/divisor
            evolution=Evolution(obj,dt,field)
            updated,mom,_=evolution.advance(field.astype(complex),start)
            sky=obj.sky(field);diff=obj.sky(updated-field)
            change=(2*sky*diff.real+abs(diff)**2)@wave.weights
            measured=obj.forces(2*change/dt**2)
            err=max(abs(measured-predicted))/max(abs(predicted))
            inverse=Evolution(obj,-dt,field)
            undo,_,_=inverse.advance(updated,mom)
            back=np.linalg.norm(undo-field)/np.sqrt(obj.number)
            assert back<1e-11
            rows.append(dict(branch=branch,step=dt,relative_force_norm_error=err,reversal=back,
                             **{key+"_dd":float(v) for key,v in zip(parent.SITES,predicted)},
                             **{key+"_observed":float(v) for key,v in zip(parent.SITES,measured)}))
        print(branch,[(r["step"],r["relative_force_norm_error"]) for r in rows[-4:]],flush=True)
    table("initial-curvature",rows)
if __name__=="__main__":run()
