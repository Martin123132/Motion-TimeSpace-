"""Compute the material gravity a second way, from live shell densities alone."""
from current_swap import Mix
from material_force import Chart, integrate, CubicSpline
from native_input import AI, DLOG, ROOT, np, table
from readout import records
from scipy.integrate import simpson, cumulative_simpson
from numpy.polynomial.legendre import leggauss


def compute(model,swapped):
    chart=(Mix if swapped else Chart)(model,24.,16.,6)
    chart.sources,chart.gravity,chart.wall="matter","live","native"
    base=chart.base
    histories=[]
    pts,weights=leggauss(8)
    eps=1e-16
    def measure(t,state):
        u,_,_,_,_,_,scale=chart.view(state,t,1j*eps,1.)
        center=chart.trajectory(t)[0]
        exterior=(center[1,1,-1,-1]+3/base.edge*center[1,0,-1,-1])/(5*base.edge)
        common=state[1][0].real
        np.testing.assert_allclose(common,state[1][1].real,rtol=0,atol=1e-13)
        separation=(state[1][0]-state[1][1]).imag/eps
        half=(common-chart.radii)/2
        near=chart.radii[:,None]+half[:,None]*(1+pts)
        field=[]
        for index,coef in enumerate(chart.coeff):
            source0=coef/(2*scale)*u[index,0].real
            source2=coef/(2*scale)*u[index,1].imag/eps
            mono=CubicSpline(base.rad,source0)
            quad=CubicSpline(base.rad,source2)
            inner0=base.weights_ball@(source0*base.rad**2)+half*((mono(near)*near**2)@weights)
            mono_force=-inner0/common**2
            gradient=-mono(common)-2*mono_force/common
            inner2=base.weights_ball@(source2*base.rad**4)+half*((quad(near)*near**4)@weights)
            outer2=(base.dr-base.weights_ball)@(source2/base.rad)-half*((quad(near)/near)@weights)
            field.extend((gradient*separation,-.9*inner2/common**4,.6*common*outer2))
        field.append(-3*exterior*common)
        histories.append(field)
    frames,state=integrate(chart,1j*eps,1.,64,8*DLOG,observer=measure)
    tag=f"{model}-K15.97-m1-n64-window8-lin-inside-matter"+("-swapped-current" if swapped else "")+"-force"
    with np.load(ROOT/(tag+".npz")) as arch:
        np.testing.assert_array_equal(frames,arch["frames"])
        for element,label in zip(state,("coeff","markers","flux")):np.testing.assert_array_equal(element,arch[label])
        raw=arch["rows"]
        old=(raw[:,0]-raw[:,1])
        gravity_saved=old[:,2:-1].sum(axis=1)
        quantum_saved=old[:,-1]
        times=arch["times"]
    fields=np.array(histories)
    scales=AI*np.exp(times)
    hub=chart.hc(times)
    names=[s+"_"+key for s in chart.species for key in ("sampled_sphere","inside_quadrupole","outside_quadrupole")]+["beyond_box"]
    out=[]
    for window in (4,8):
        span=slice(None,window*8+1)
        h=hub[span];a=scales[span];t=times[span]
        drift=cumulative_simpson(1/(a*h),x=t,initial=0.)
        kernel=a/h*(drift[-1]-drift)
        integrated=simpson(fields[span]*kernel[:,None,None],x=t,axis=0)/chart.radii
        x_saved=simpson(gravity_saved[span]*kernel[:,None],x=t,axis=0)/chart.radii
        diff=np.max(abs(fields[span].sum(axis=1)-gravity_saved[span]),axis=0)/np.max(abs(gravity_saved[span]),axis=0)
        quantum=simpson(quantum_saved[span]*kernel[:,None],x=t,axis=0)/chart.radii
        for i,radius in enumerate(chart.radii):
            row=dict(branch=model,swapped=swapped,window=window,aperture=(.5,1,2)[i],gravity_from_density=sum(integrated[:,i]),
                     saved_gravity=x_saved[i],relative_density_reconstruction_error=sum(integrated[:,i])/x_saved[i]-1,
                     relative_force_timeseries_error=diff[i],gradient_pressure=quantum[i],
                     initial_kick=AI*old[0,1,i]*drift[-1]/radius,
                     measured_shape=(old[window*8,0,i]-old[0,0,i])/radius)
            row.update(dict(zip(names,integrated[:,i])))
            out.append(row)
    table(model+("-swapped" if swapped else "-original")+"-source-attribution.csv",out)
    print(model,swapped,"density gravity vs independent trajectory force (max ppm)",1e6*max(r["relative_force_timeseries_error"] for r in out),flush=True)
    return out


def main():
    data={(model,swap):compute(model,swap) for model in ("cold","heavy") for swap in (False,True)}
    out=[]
    for current,wave_swap,cold_swap in (("original",False,False),("shared_wave",False,True),("shared_cold",True,False),("exchanged",True,True)):
        for wave,cold in zip(data[("heavy",wave_swap)],data[("cold",cold_swap)]):
            assert (wave["window"],wave["aperture"])==(cold["window"],cold["aperture"])
            gap=wave["measured_shape"]-cold["measured_shape"]
            row=dict(currents=current,window=wave["window"],aperture=wave["aperture"],wave_minus_cold=gap)
            for part in ("initial_kick","beyond_box","gradient_pressure"):
                row[part]=wave[part]-cold[part]
            for label,species in (("baryon",("baryon",)),("dark",("wave","cdm"))):
                for region in ("sampled_sphere","inside_quadrupole","outside_quadrupole"):
                    row[label+"_"+region]=sum(wave.get(s+"_"+region,0)-cold.get(s+"_"+region,0) for s in species)
            row["reconstruction_relative_error"]=sum(list(row.values())[4:])/gap-1
            out.append(row)
    table("paired-gravity-decomposition.csv",out)


if __name__=="__main__":main()
