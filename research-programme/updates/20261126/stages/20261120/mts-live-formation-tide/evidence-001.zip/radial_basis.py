from native_input import np
from numpy.polynomial.legendre import leggauss, Legendre
from scipy.special import spherical_jn
from scipy.optimize import brentq


class Basis:
    def __init__(self,edge,band,order,radii):
        self.edge=edge
        self.ells=np.arange(0,order+1,2)
        self.angles,self.weights=leggauss(max(12,2*order+3))
        polys=[Legendre.basis(ell) for ell in self.ells]
        self.harm=np.array([poly(self.angles) for poly in polys])
        self.dharm=np.array([-np.sqrt(1-self.angles**2)*poly.deriv()(self.angles) for poly in polys])
        self.project=self.harm*(2*self.ells[:,None]+1)*self.weights/2
        self.poles=np.array([[poly(mu) for poly in polys] for mu in (1.,0.)])
        borders=np.unique(np.r_[np.linspace(0,edge,int(np.ceil(edge*band/4))+1),radii])
        lo,hi=borders[:-1,None],borders[1:,None]
        nodes,weights=leggauss(5)
        self.rad=rad=np.r_[((lo+hi)/2+nodes*(hi-lo)/2).ravel(),edge]
        self.dr=np.r_[(weights*(hi-lo)/2).ravel(),0.]
        roots=[]
        for ell in self.ells:
            scan=np.arange(.09,edge*band+.11,np.pi/4)
            value=spherical_jn(ell,scan)
            zeros=[brentq(lambda x:spherical_jn(ell,x),scan[j],scan[j+1]) for j in np.where(value[:-1]*value[1:]<0)[0]]
            roots.append(np.array(zeros)/edge)
        self.size=max(map(len,roots))
        self.k=np.ones((len(roots),self.size))
        self.value,self.slope,self.lap=[np.zeros((len(roots),self.size,len(rad))) for _ in range(3)]
        for index,(ell,modes) in enumerate(zip(self.ells,roots)):
            self.k[index,:len(modes)]=modes
            norm=np.sqrt(edge**3/2)*abs(spherical_jn(ell+1,edge*modes))
            self.value[index,:len(modes)]=spherical_jn(ell,np.outer(modes,rad))/norm[:,None]
            self.slope[index,:len(modes)]=spherical_jn(ell,np.outer(modes,rad),derivative=True)*modes[:,None]/norm[:,None]
            self.lap[index,:len(modes)]=-modes[:,None]**2*self.value[index,:len(modes)]
        self.to_coeff=(self.value*(rad**2*self.dr)).transpose(0,2,1).copy()
        self.vacuum_profile=np.array([(rad/edge)**ell for ell in self.ells])
        self.vacuum_profile[0]=0
        self.vacuum_slope=np.array([ell/edge*(rad/edge)**max(ell-1,0) for ell in self.ells])
        self.R=radii
        self.cut=np.ones_like(rad)
        outer=(rad/edge-.7)/.3
        mask=(outer>0)&(outer<1)
        self.cut[mask]=1/(1+np.exp(np.clip(1/(1-outer[mask])-1/outer[mask],-700,700)))
        self.cut[outer>=1]=0
        self.weights_ball=np.array([(rad<radius)*self.dr for radius in radii])

    def synth(self,coeff,basis):
        return np.einsum("...ln,lnr->...lr",coeff,basis)

    def poisson(self,source,derivative=False):
        particular=-source/self.k**2
        outer=self.synth(particular,self.slope[:,:,-1:])[:,0]
        vac=-self.edge*outer/(2*self.ells+1)
        return self.synth(particular,self.slope if derivative else self.value)+vac[:,None]*(self.vacuum_slope if derivative else self.vacuum_profile)
