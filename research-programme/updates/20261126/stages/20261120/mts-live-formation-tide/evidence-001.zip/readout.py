import csv
from native_input import ROOT, DLOG, TOL, np, note, sha, table


def load(name):
    with np.load(ROOT/(name+".npz")) as archive:
        ref=archive["r"]
        frames=archive["frames"]
    if np.iscomplexobj(frames):frames=frames.imag/1e-16
    output=np.stack(((frames[-1,5]-frames[-1,6])/ref,frames[-1,0]-frames[0,0],frames[-1,2]-frames[0,2],
                     frames[-1,3],frames[-1,7],frames[-1,8]))
    return output


def records(name):
    with (ROOT/(name+".csv")).open(newline="") as stream:return list(csv.DictReader(stream))


def finances(model,window,mono,suffix):
    tag=f"{model}-K15.97-m{mono}-n{window*8}-window{window}-lin"+suffix+"-force"
    return [row for row in records(tag) if row["time_quadrature_stride"]=="1"]


def main():
    names=["material_shape","change_ball_D2","change_local_D2","final_lapse2","radial_flux","angular_flux"]
    panels, swaps, scores=[],[],[]
    for model in ("heavy","cold"):
        primary=load(model+"-L24-K16-l6-n32-m1-native-live-lin")
        blank=load(model+"-L24-K16-l6-n32-m0-native-live-lin")
        low=model+"-L24-K12-l4-n16-m1-native-live-"
        high=model+"-L24-K16-l6-n32-m1-native-live-"
        def compare(label,value,target):
            for field,vals,refs in zip(names,value,target):
                for i in range(3):
                    panels.append(dict(branch=model,test=label,quantity=field,aperture=(.5,1,2)[i],measured=vals[i],reference=refs[i],
                                       relative_error=vals[i]/refs[i]-1,within_tolerance=bool(abs(vals[i]/refs[i]-1)<TOL)))
        for code,pair in (("timestep",(model+"-L24-K12-l4-n32-m1-native-live-lin",low+"lin")),
                          ("band",(model+"-L24-K16-l4-n32-m1-native-live-lin",model+"-L24-K12-l4-n32-m1-native-live-lin")),
                          ("angular_tangent",(high+"lin",model+"-L24-K16-l4-n32-m1-native-live-lin")),
                          ("angular_unit_tide",(high+"1",model+"-L24-K16-l4-n32-m1-native-live-1")),
                          ("wall_12_to_24",(low+"lin",model+"-L12-K12-l4-n16-m1-native-live-lin")),
                          ("wall_24_to_36",(model+"-L36-K16-l6-n32-m1-native-live-lin",high+"lin")),
                          ("joint_refinement",(model+"-L24-K20-l6-n48-m1-native-live-lin",high+"lin"))):
            compare(code,load(pair[0]),load(pair[1]))
        for pos,neg,spacing in (("1","-1",1.),(".5","-.5",.5)):
            compare("central_difference_"+pos,(load(high+pos)-load(high+neg))/(2*spacing),primary)
        alt=load(model+"-L24-K20-l6-n48-m1-native-live-lin")-load(model+"-L24-K20-l6-n48-m0-native-live-lin")
        compare("refinement_on_nonlinear_change",alt,primary-blank)
        frozen=[row for row in records("frozen-current-swap") if row["branch"]==model]
        for window in (4,8):
            live=finances(model,window,1,"-inside-matter")
            other=finances(model,window,1,"-inside-matter-swapped-current")
            hom=finances(model,window,0,"-inside-matter") if window==8 else None
            for idx,(first,last) in enumerate(zip(live,other)):
                test=next(row for row in frozen if float(row["radius"])==float(first["radius"]) and int(row["window"])==window)
                response=float(last["measured_shape"])-float(first["measured_shape"])
                ballistic,jerk=float(test["ballistic"]),float(test["jerk_deflection"])
                swaps.append(dict(branch=model,window=window,aperture=(.5,1,2)[idx],original=float(first["measured_shape"]),swapped=float(last["measured_shape"]),
                                  measured_change=response,ballistic_forecast=ballistic,jerk_forecast=jerk,
                                  total_forecast_relative_error=(ballistic+jerk)/response-1,ballistic_only_fraction=ballistic/response,
                                  nonlinear_remainder_relative_error=jerk/(response-ballistic)-1))
                if hom:
                    native=finances(model,4,1,"")[idx]
                    mass=finances(model,4,1,"-inside-matter")[idx]
                    summary=dict(branch=model,aperture=(.5,1,2)[idx],double_window_shape=float(first["measured_shape"]),
                                 initial_motion_share=float(first["initial_velocity_contribution"])/float(first["measured_shape"]),
                                 native_exterior_share=float(first["native_exterior"])/float(first["measured_shape"]),
                                 quantum_share=float(first["wave_gradient"])/float(first["measured_shape"]),
                                 double_finite_over_homogeneous_shape=float(first["measured_shape"])/float(hom[idx]["measured_shape"])-1,
                                 single_matter_interior_over_native_shape=float(mass["measured_shape"])/float(native["measured_shape"])-1)
                    for n,base in zip(names,primary/blank-1):summary["single_finite_over_homogeneous_"+n]=base[idx]
                    scores.append(summary)
    table("resolution-and-finite-tide.csv",panels)
    table("current-swap-tests.csv",swaps)
    table("physical-comparison.csv",scores)
    for row in swaps:
        if row["aperture"]==1 and row["window"]==8:print(row)
    for run in sorted({r["test"] for r in panels}):
        matched=[row for row in panels if row["test"]==run]
        print(run,"worst ppm", max(abs(row["relative_error"]) for row in matched)*1e6)


if __name__=="__main__":main()
