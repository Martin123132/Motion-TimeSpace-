import csv
import hashlib
import json
import sys
from pathlib import Path

import numpy as np

ROOT=Path(__file__).resolve().parent
PREV=ROOT.parent/"mts-formation-tidal-shape-20261120"


def sha(path):
    with path.open("rb") as stream:return hashlib.file_digest(stream,"sha256").hexdigest()


def rows(name):
    with (ROOT/name).open(newline="") as stream:return list(csv.DictReader(stream))


def main():
    previous=sha(PREV/"seal.json")
    assert previous=="543978460b6b32a909cb899991aa6c24ff45093cafafe20b29971e8f3bb5d397"
    upstream=json.loads((PREV/"seal.json").read_bytes())["files"]
    for name,value in upstream.items():assert sha(PREV/name)==value,name
    assert sha(ROOT/"frozen-current-swap.csv")=="c319123bcd4919a9e3b44bb13530d8d5c7b358f97a374d56fa3b4bd0a09aa6f0"
    assert sha(ROOT/"paired-transfer-forecast.csv")=="228ba23c2cced03ae32f7a2f386b7c9f5c54f3a504fe67224f490595a2201c24"
    controlled=rows("resolution-and-finite-tide.csv")
    assert len(controlled)==360
    failed=[r for r in controlled if abs(float(r["relative_error"]))>=2e-5]
    assert all((r["within_tolerance"]=="True")== (abs(float(r["relative_error"]))<2e-5) for r in controlled)
    assert {r["test"] for r in failed}=={"wall_12_to_24","refinement_on_nonlinear_change"}
    for branch in ("heavy","cold"):
        for state in ("lin","1","-1",".5","-.5"):
            assert (ROOT/f"{branch}-L24-K16-l6-n32-m1-native-live-{state}.npz").is_file()
        for add in ("","-swapped-current"):
            tail=f"{branch}-K15.97-m1-n64-window8-lin-inside-matter{add}-force.npz"
            with np.load(ROOT/tail) as pack:
                assert len(pack["times"])==65 and np.isfinite(pack["coeff"]).all()
                assert pack["coeff"].shape[1]==4 and pack["markers"].shape==(2,3)
                assert np.min(pack["frames"][:,9].real)>.5
        for label in ("lin","1","-1"):
            volume=rows(branch+"-volume-q12-n64-"+label+".csv")
            assert max(abs(float(r["relative_material_number_error"])) for r in volume)<2e-11
            assert max(abs(float(r["cap_error_on_current_scale"])) for r in volume if r["cap_error_on_current_scale"])<2e-5
        for cutoff in (16,20):
            raw=rows(f"{branch}-raw-Poisson-frozen1-K{cutoff}.csv")
            assert len(raw)==24 and max(abs(float(r["relative_error"])) for r in raw)<2e-5
    paired=rows("paired-gravity-decomposition.csv")
    assert len(paired)==24 and max(abs(float(row["reconstruction_relative_error"])) for row in paired)<2e-5
    signs={r["currents"]:float(r["wave_minus_cold"]) for r in paired if r["aperture"]=="1" and r["window"]=="8"}
    assert signs["exchanged"]<0<min(signs["shared_cold"],signs["shared_wave"])<signs["original"]
    assert len(rows("current-swap-tests.csv"))==12
    assert len(rows("paired-transfer-forecast.csv"))==144
    checks=json.loads((ROOT/"operator-controls.json").read_bytes())
    assert max(max(r["manufactured_green_relative_by_l"]) for r in checks.values())<2e-5
    for name in ("PROTOCOL.md","DERIVATION.md","REPLAY.md","RESULTS.md"):assert (ROOT/name).is_file()
    assert not any(p.is_dir() or p.suffix not in (".py",".csv",".npz",".md",".json") for p in ROOT.iterdir())
    actual={p.name:sha(p) for p in sorted(ROOT.iterdir()) if p.name!="seal.json"}
    record=dict(files=actual,upstream=previous,checked_upstream_files=len(upstream),reported_failed_controls=len(failed))
    if sys.argv[1:]==["--seal"]:
        with (ROOT/"seal.json").open("x",encoding="utf8",newline="\n") as out:
            json.dump(record,out,indent=2,sort_keys=True);out.write("\n")
    else:assert json.loads((ROOT/"seal.json").read_bytes())==record
    print("Verified",len(actual),"local and",len(upstream),"upstream files;",len(failed),"numerical controls explicitly outside tolerance.")


if __name__=="__main__":main()
