import csv
import hashlib
import io
import json
import os
import sys
from pathlib import Path
for name in ("OMP_NUM_THREADS","OPENBLAS_NUM_THREADS","MKL_NUM_THREADS","NUMEXPR_NUM_THREADS","BLIS_NUM_THREADS"):
    os.environ[name]="1"
sys.dont_write_bytecode=True
import numpy as np
from scipy.interpolate import CubicSpline
ROOT=Path(__file__).resolve().parent
PREV=ROOT.parent/"mts-formation-tidal-shape-20261120"
PIN="543978460b6b32a909cb899991aa6c24ff45093cafafe20b29971e8f3bb5d397"


def sha(path):
    with path.open("rb") as handle:return hashlib.file_digest(handle,"sha256").hexdigest()


def guard():
    assert not any((place/"STOP-REQUESTED").exists() for place in (ROOT,PREV,ROOT.parent))


guard()
assert sha(PREV/"seal.json")==PIN
manifest=json.loads((PREV/"seal.json").read_bytes())["files"]
for name in ("heavy-initial-tide.npz","cold-initial-tide.npz","formation_tide.py","current_path.py","direct-current-path.csv"):
    assert sha(PREV/name)==manifest[name]
sys.path.insert(0,str(PREV))
from formation_tide import prepare, AI, C, bank, top, TOL
from current_path import camb, inherited, SPEC, NATIVE, source, obj, checked

DLOG=np.log((1/11)/AI)/128
END=4*DLOG


def write(name,data):
    guard()
    path=ROOT/name
    if not path.exists():
        with path.open("xb") as handle:handle.write(data)
    else:assert path.read_bytes()==data,name


def packet(name,**fields):
    buffer=io.BytesIO()
    np.savez_compressed(buffer,**fields)
    write(name,buffer.getvalue())


def table(name,rows):
    text=io.StringIO(newline="")
    writer=csv.DictWriter(text,fieldnames=rows[0],lineterminator="\n")
    writer.writeheader()
    writer.writerows(rows)
    write(name,text.getvalue().encode("ascii"))


def note(name,data):
    write(name,(json.dumps(data,indent=2,sort_keys=True,allow_nan=False)+"\n").encode())


def generate(model):
    guard()
    seed,epochs,fields,metric,_=prepare(model,0)
    ref,_,_,lapse,_=prepare("heavy",0)
    slot=np.where(epochs==AI)[0].item()
    modes=seed.k
    width=np.diff(np.log(modes))
    volume=bank("volume-state")
    w=(np.r_[width,0]+np.r_[0,width])*.5*volume["primordial_power"][np.isin(volume["k_Mpc_inverse"],modes)]
    shear=-modes**2*lapse[:,slot]*top(modes*ref.radius)
    b=w*shear/np.sqrt(w@shear**2/5)
    np.testing.assert_array_equal(seed.weights,ref.weights)
    status=obj(source("runs/"+model+"/status.json"))
    for path in inherited.native_hashes():checked(path,status["input_hashes"][str(path)])
    path=SPEC/"runs/projection/a225-w6-d8.npz" if model=="heavy" else NATIVE/"runs/backgrounds/cold.npz"
    checked(path,status["source_hash"])
    params=inherited.params_for(path,background_boost=8.)
    params.DoLateRadTruncation=False
    bg=camb.get_background(params)
    bg.Params.Accuracy.IntTolBoost=6
    loga=DLOG*np.arange(-4,38)/4
    scales=AI*np.exp(loga)
    earlier=epochs[epochs<min(scales)]
    times=bg.conformal_time(1/np.r_[earlier,scales]-1,tol=1e-10)
    names=["a","H","etak","Weyl","v_newtonian_cdm","v_newtonian_baryon","delta_cdm","delta_baryon","mts_drho_h","mts_q_h"]
    blocks=[]
    for chunk in sorted((SPEC/"runs"/model).glob("chunk-*.npz")):
        with np.load(source(chunk.relative_to(SPEC).as_posix())) as old:
            chosen=old["modes"][np.isin(old["modes"],modes)]
            if not len(chosen):continue
            batch=np.unique(np.r_[chosen,old["modes"].max()])
        guard()
        result=bg.get_time_evolution(batch,times,vars=names,lAccuracyBoost=4)
        blocks.append((chosen,result[np.searchsorted(batch,chosen),len(earlier):]))
    np.testing.assert_array_equal(np.concatenate([x[0] for x in blocks]),modes)
    cols=dict(zip(names,np.concatenate([x[1] for x in blocks]).transpose(2,0,1)))
    hub=cols["H"]
    curvature=cols["etak"]/modes[:,None]
    theta_c=-hub*cols["v_newtonian_cdm"]
    potential=2*cols["Weyl"]/modes[:,None]**2-curvature+hub*theta_c/modes[:,None]**2
    density=[cols["delta_cdm"]-3*curvature,cols["delta_baryon"]-3*curvature]
    theta=[theta_c,-hub*cols["v_newtonian_baryon"]]
    if model=="heavy":
        factor=cols["a"]/seed.coeff["wave"]
        density.append(cols["mts_drho_h"]*factor-3*curvature)
        theta.append(modes[:,None]*cols["mts_q_h"]*factor+theta_c)
    for index,(val,vel) in enumerate(fields.values()):
        for actual,expected in ((density[index][:,4],val[:,slot]),(theta[index][:,4],vel[:,slot]),(potential[:,4],metric[:,slot])):
            assert np.linalg.norm(actual-expected)<2e-8*np.linalg.norm(expected)
    packet(model+"-native.npz",k=modes,loga=loga,hub=hub[0],density=density,velocity=-np.array(theta)/modes[None,:,None]**2,
           phi=potential,scalar=2*seed.weights,shear=-b,mass=seed.mass,radius=seed.radius,species=list(fields),
           coeff=[seed.coeff[s] for s in fields])
    print(model,"99 modes, native sources verified",flush=True)


if __name__=="__main__":
    for branch in sys.argv[1:]:generate(branch)
