from direct_gravity import Direct
from native_input import ROOT, PREV, np, note
from scipy.interpolate import CubicSpline
from math import comb


def main():
    out={}
    for model in ("cold","heavy"):
        chart=Direct(model,24.,16.,6)
        base=chart.base
        rad=base.rad
        x=rad/base.edge
        sources=[]
        expected=[]
        for ell in base.ells:
            source=0*x
            for i in range(1,5):
                source+=(-1)**i*comb(4,i)*2*i*(2*ell+2*i+1)*x**(ell+2*i-2)/base.edge**2
            sources.append(source)
            expected.append(x**ell*(1-x**2)**4)
        errors=np.max(abs(chart.direct(sources)-expected),axis=1)/np.max(expected,axis=1)
        assert max(errors)<2e-5
        coeff=chart.initial(1.)
        original=chart.trajectory(0.)[0]
        with np.load(PREV/(model+"-initial-tide.npz")) as old:
            mismatches=[]
            for j,name in enumerate(chart.species):
                for key,live in (("D0",original[0,0,j]),("D2",original[1,0,j]),
                                 ("velocity_potential2_Mpc",original[1,0,chart.count+j]),("radial_velocity2",original[1,1,chart.count+j])):
                    intrinsic=CubicSpline(old["comoving_r_Mpc"],old[name+"_"+key])(rad)
                    mismatches.append(float(np.max(abs(intrinsic-live))/np.max(abs(intrinsic))))
            assert max(mismatches)<2e-5
        z=chart.rates(coeff,0.,1.,1.,True)
        assert np.isfinite(z).all()
        out[model]=dict(manufactured_green_relative_by_l=errors.tolist(),max_saved_seed_discrepancy=max(mismatches))
    note("operator-controls.json",out)
    print(out)


if __name__=="__main__":main()
