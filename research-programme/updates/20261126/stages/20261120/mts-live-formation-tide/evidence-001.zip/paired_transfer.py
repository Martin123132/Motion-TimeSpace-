"""Independent growing and dispersive response to a pure initial phase/current exchange."""
from native_input import ROOT, PREV, AI, DLOG, np, prepare, table
from scipy.special import spherical_jn
from scipy.integrate import solve_ivp
from readout import records


def forecast(model):
    with np.load(ROOT/(model+"-native.npz")) as own,np.load(ROOT/(("cold" if model=="heavy" else "heavy")+"-native.npz")) as other:
        mass=own["mass"];coef=own["coeff"];modes=own["k"];radii=own["radius"]*np.array([.5,1.,2.])
        shear=own["shear"];target=len(coef)-1 if model=="heavy" else 0
        slot=np.where(own["loga"]==0)[0].item()
        delta=other["velocity"][-1 if model=="cold" else 0,:,slot]-own["velocity"][target,:,slot]
    seed=prepare(model,0)[0]
    windows=np.array([4,8,16,32,64,128])
    times=windows*DLOG
    outputs=[]
    for label,grav,gradient in (("drift",False,False),("common_gravity",True,False),("wave_pressure",False,True),("physical",True,True)):
        state0=np.zeros((2,len(coef),len(modes)))
        state0[1,target]=AI*delta
        def rates(time,flat):
            scale=AI*np.exp(time)
            hc=scale*seed.H(scale)
            density,mom=flat.reshape(state0.shape)
            kick=np.zeros_like(mom)
            if grav:kick[:]=(coef@density)/(2*modes**2)
            if gradient and model=="heavy":kick[target]-=modes**2*density[target]/(4*scale*mass**2)
            return (np.stack((modes**2*mom/scale,kick))/hc).ravel()
        result=solve_ivp(rates,[0,times[-1]],state0.ravel(),t_eval=times,method="DOP853",rtol=1e-11,atol=1e-15)
        assert result.success
        density=result.y.reshape((*state0.shape,-1))[0,target]
        for idx,radius in enumerate(radii):
            shape=(1.5/radius*shear*spherical_jn(2,radius*modes,derivative=True)/modes)@density
            for loc,win in enumerate(windows):
                outputs.append(dict(branch=model,window=win,a=AI*np.exp(times[loc]),aperture=(.5,1,2)[idx],
                                    transport=label,shape_change=shape[loc]))
    return outputs


def main():
    rows=forecast("heavy")+forecast("cold")
    table("paired-transfer-forecast.csv",rows)
    observed=records("current-swap-tests")
    checks=[]
    for expected in rows:
        if expected["window"] not in (4,8):continue
        real=next(row for row in observed if row["branch"]==expected["branch"] and int(row["window"])==expected["window"] and float(row["aperture"])==expected["aperture"])
        shape=float(real["measured_change"])
        checks.append(dict(**expected,measured=shape,relative_error=expected["shape_change"]/shape-1))
    table("paired-transfer-early-check.csv",checks)
    for row in checks:
        if row["window"]==8 and row["aperture"]==1 and row["transport"]=="physical":print(row)


if __name__=="__main__":main()
