"""Check restarts, matched experiments, and separate accepted from open tolerances."""
import argparse
from seeds import HERE, ROOT, SPEC, AI, END, C, TOL, Seed, digest, obj, record, checked, source, guard, np, csv
from scipy.interpolate import CubicSpline
from scipy.fft import dst

def records(name):
    with (HERE/name).open(newline="") as stream:
        return list(csv.DictReader(stream))

def result(model,step,n,amp,suffix=""):
    return obj(HERE/f"ind-{model}-anchorA-heavy-dx{step:g}-L24-n{n}-A{amp:g}-v1-end0.9252{suffix}.json")

def validate():
    guard()
    stats={}
    summaries=sorted(p for p in HERE.glob("*-dx*.json"))
    independent=0
    for path in summaries:
        summary=obj(path)
        rows=records(path.with_suffix(".csv").name)
        a=np.array([float(row["a"]) for row in rows])
        assert np.all(np.diff(a)>0) and a[0]==AI
        for key,value in summary["last"].items():
            assert float(rows[-1][key])==value
        cross=summary["first_caustic"]
        assert summary["complete"]==(cross is None)
        if cross:
            assert a[-1] <= cross["estimated_a"] < END
        else:
            assert min(abs(a[-1]-END),abs(a[-1]-1/11))<1e-13
        if summary["turnaround"]:
            assert AI < summary["turnaround"]["a"] <= a[-1]
        if path.name.startswith("ind-"):
            independent+=1
            with np.load(path.with_suffix(".npz")) as state:
                assert float(state["a"])==a[-1]
                for name in state.files:
                    assert np.isfinite(state[name]).all()
                    if name.endswith(("_M","_x")):
                        assert np.all(np.diff(state[name])>0)
        elif summary["model"]=="heavy":
            assert float(rows[-1]["norm_error"])<1e-10
    stats.update(summaries=len(summaries),restart_banks_checked=independent)
    for branch in ("anchorA","cut1","cut2"):
        for selector in ("heavy","cold"):
            for model in ("heavy","cold"):
                path=HERE/f"{model}-{branch}-{selector}-dx0.00625-L24-n512-A1-v1-sq1-end0.9252.json"
                trial=obj(path)
                assert bool(trial["turnaround"])==(model=="cold")
                assert trial["complete"]==(model=="heavy")
    linear={}
    for model in ("heavy","cold"):
        null=result(model,.025,256,0)
        assert null["complete"] and abs(null["last"]["fixed_comoving_mass_ratio"]-1)<1e-9 and abs(null["last"]["peculiar_kms"])<1e-7
        opts=[obj(HERE/f"ind-{model}-anchorA-heavy-dx0.025-L24-n256-A{amp:g}-v1-end0.0909.json")["last"] for amp in (-.001,.001)]
        truth=next(row for row in records("native-linear-control.csv") if row["model"]==model and row["selector"]=="heavy" and abs(float(row["a"])-1/11)<1e-12)
        linear[model]={}
        for field,reference in (("peculiar_kms","predicted_radial_kms"),("fixed_comoving_mass_ratio","linear_predicted_contrast")):
            fd=(opts[1][field]-opts[0][field])/.002
            linear[model][field]=abs(fd/float(truth[reference])-1)
    stats["finite_amplitude_derivative_vs_linear"]=linear
    compensated="-compensated-radiation-off"
    fine=result("heavy",.003125,1024,1,compensated)
    speed=fine["last"]["proper_speed_kms"]
    coarse=result("heavy",.00625,1024,1,compensated)
    assert fine["complete"] and speed>0
    stats["heavy_final_doubled_resolution_relative_speed"]=abs(coarse["last"]["proper_speed_kms"]/speed-1)
    stats["heavy_doubled_time_resolution_relative_speed"]=abs(result("heavy",.00625,512,1,compensated)["last"]["proper_speed_kms"]/coarse["last"]["proper_speed_kms"]-1)
    assert max(stats[key] for key in stats if key.endswith("relative_speed"))<TOL
    origin=Seed("heavy","anchorA")
    with np.load(HERE/"ind-heavy-anchorA-heavy-dx0.003125-L24-n1024-A1-v1-end0.9252-compensated-radiation-off.npz") as state:
        radius=state["r"]; psi=state["psi"]
        coord=fine["last"]["comoving_material_radius_Mpc"]
        integ=CubicSpline(radius,radius**2*abs(psi)**2).integrate(0.,coord)
        stats["spline_material_mass_relative"]=abs(integ/(origin.radius**3/3)-1)
        basis=dst(radius[1:-1]*(psi[1:-1]-1),type=1)/(len(radius)-1)
        k=np.pi*np.arange(1,len(radius)-1)/radius[-1]
        wave=np.sin(k*coord)@basis
        value=1+wave/coord
        deriv=(np.cos(k*coord)@(k*basis))/coord-wave/coord**2
        velocity=C*np.imag(value.conjugate()*deriv)/(abs(value)**2*END*origin.mass)
        stats["independent_peculiar_velocity_relative"]=abs(velocity/fine["last"]["peculiar_kms"]-1)
    assert max(stats["spline_material_mass_relative"],stats["independent_peculiar_velocity_relative"])<TOL
    for model in ("heavy","cold"):
        suffix=compensated if model=="heavy" else "-radiation-off"
        pair=[obj(HERE/f"ind-{model}-anchorA-heavy-dx0.0125-L24-n512-A{amp:g}-v1-end0.0909{suffix}.json")["last"] for amp in (-.001,.001)]
        reference=next(row for row in records("matched-hierarchy-test.csv") if row["model"]==model and row["switch"]=="0" and abs(float(row["a"])-1/11)<1e-12)
        for field,target,error in (("peculiar_kms","velocity","velocity_NR_over_native_minus_one"),("fixed_comoving_mass_ratio","contrast","contrast_NR_over_native_minus_one")):
            predicted=float(reference[target])*(1+float(reference[error]))
            stats["signed_derivative_corrected_"+model+"_"+field]=abs((pair[1][field]-pair[0][field])/(.002*predicted)-1)
        for amp in (1,2):
            fine_trial=result(model,.00625,512,amp,suffix)
            other=result(model,.0125,512,amp,suffix)
            if model=="heavy" and amp==1:continue
            assert not fine_trial["complete"] and fine_trial["first_caustic"]["shell"]==0
            assert abs(fine_trial["turnaround"]["a"]/other["turnaround"]["a"]-1)<TOL
    for amplitude in (1,2):
        sample=[]
        for spacing in (.00625,.003125,.0015625):
            other=obj(HERE/f"heavy-anchorA-heavy-dx{spacing:g}-L24-n512-A{amplitude}-v1-sq1-end0.9252-compensated-radiation-off.json")
            assert other["complete"]==(amplitude==1)
            sample.append(other["turnaround"]["a"] if amplitude==2 else other["last"]["proper_speed_kms"])
        ref=speed if amplitude==1 else result("heavy",.00625,512,2,compensated)["turnaround"]["a"]
        stats[f"closed_vs_spectral_A{amplitude}"]={"raw_fine_relative":abs(sample[-1]/ref-1),"apparent_order":float(np.log2(abs((sample[0]-sample[1])/(sample[1]-sample[2])))),
                                                  "second_order_extrapolated_relative":abs(((4*sample[-1]-sample[-2])/3)/ref-1)}
    swapped=result("heavy",.00625,512,1,"-compensated-swapped-full-cold-IC")
    swapped_dust=result("heavy",.00625,512,1,"-dust-swapped-full-cold-IC")
    dust=result("heavy",.00625,512,1,"-dust-radiation-off")
    assert dust["complete"] and not dust["turnaround"] and dust["last"]["proper_speed_kms"]>0
    assert 0<swapped_dust["turnaround"]["a"]<swapped["turnaround"]["a"]
    assert abs(swapped_dust["turnaround"]["a"]/result("cold",.00625,512,1,"-radiation-off")["turnaround"]["a"]-1)<TOL
    rows=records("constraint-residual.csv")
    assert len(rows)==8 and all(float(row["after_signed_radiation_subtraction"])<TOL for row in rows)
    check=records("matched-hierarchy-test.csv")
    assert len(check)==24 and all(float(row["wide_euler_error"])<TOL for row in check if row["switch"]=="0" and row["wide_euler_error"])
    stats["linear_final"]={row["model"]+row["switch"]:{key:float(row[key]) for key in ("contrast","velocity","contrast_NR_over_native_minus_one","velocity_NR_over_native_minus_one")} for row in check if float(row["a"])==1}
    for model in ("heavy","cold"):
        for switch in (0,1):
            with np.load(HERE/f"radiation-full-{model}-{switch}.npz") as full,np.load(HERE/f"radiation-{model}-{switch}.npz") as sample:
                np.testing.assert_array_equal(full["names"],sample["names"])
                where=np.searchsorted(full["modes"],sample["modes"])
                np.testing.assert_allclose(full["values"][where],sample["values"],rtol=TOL,atol=1e-12)
    return stats


def closure(create=False):
    guard()
    stats=validate()
    if create:record("validation.json",stats)
    assert obj(HERE/"validation.json")==stats
    artifacts={file.name:digest(file) for file in sorted(HERE.iterdir()) if file.is_file() and file.name!="seal.json"}
    predecessors={}
    for model in ("heavy","cold"):
        status=obj(source("runs/"+model+"/status.json"))
        for path,sha in status["input_hashes"].items():
            from pathlib import Path
            target=Path(path)
            checked(target,sha)
            predecessors[target.relative_to(ROOT).as_posix()]=sha
    for folder,file in (("mts-pre572-wave-preparation-20261120","seal.json"),("mts-formation-state-bundle-20261110","closeout.json"),("mts-formation-angular-population-20261120","seal.json"),("condensate-origin-20261003/resolved-matter-spectrum-20261007","results/stage-integrity.json")):
        key=folder+"/"+file;predecessors[key]=digest(ROOT/key)
    content=dict(files=artifacts,inputs=predecessors)
    if create:record("seal.json",content)
    assert obj(HERE/"seal.json")==content
    print("checked",len(artifacts),"local files,",len(predecessors),"source hashes,",stats["summaries"],"trajectories; seal",digest(HERE/"seal.json"))


if __name__=="__main__":
    parser=argparse.ArgumentParser()
    parser.add_argument("--seal",action="store_true")
    parser.add_argument("--test",action="store_true")
    opts=parser.parse_args()
    if opts.test:print(validate())
    else:closure(opts.seal)
