from collapse import *
from scipy.fft import dst,idst
from scipy.interpolate import CubicSpline
from scipy.integrate import cumulative_simpson
from scipy.optimize import brentq

def integ(y,dx):return cumulative_simpson(y,dx=dx,initial=0.)
class Independent:
    def __init__(self,seed,dx,L,A,phase_scale,treatment):
        self.seed=seed;self.n=int(round(L/dx));self.dx=L/self.n;self.L=L
        self.r=r=self.dx*np.arange(self.n+1);self.k2=(np.pi*np.arange(1,self.n)/L)**2
        self.dust={s:Shells(seed,s,r,L,A,phase_scale) for s in ("cdm","baryon")}
        if treatment in ("dust","cold-seed-dust"):
            self.dust["wave"]=Shells(seed,"wave",r,L,A,phase_scale)
        self.target=seed.radius**3/3;self.psi=None;self.max_budget=0.
        if seed.model=="heavy" and "wave" not in self.dust:
            D=seed.transform(r,seed.fields["wave"][0],0)*A*taper(r,L)
            if treatment=="compensated":
                shell=(r>2*L/3)&(r<L)
                dwindow=-1.5*np.pi/L*np.sin(np.pi*(3*r[shell]/L-2))
                D[shell]+=A*r[shell]*dwindow*seed.enclosed(r[shell],seed.fields["wave"][0])/3
            phase=seed.transform(r,seed.phase,0)*A*phase_scale*taper(r,L)
            assert np.min(1+D)>0
            self.psi=np.sqrt(1+D)*np.exp(1j*phase)
            assert self.psi[-1]==1
            self.initial_mass=integ(abs(self.psi)**2*r*r,self.dx)[-1]
        else:
            self.tracer="wave" if "wave" in self.dust else "cdm"
            dust=self.dust[self.tracer];f=CubicSpline(r,dust.M)
            self.q_material=brentq(lambda q:f(q)-self.target,0,2*seed.radius)
        self.integrated_out=0.
    def grav(self,a):
        r=self.r;d=self.dx;seed=self.seed
        weighted=np.zeros_like(r)
        for s,obj in self.dust.items():
            delta=obj.M-obj.x**3/3
            weighted+=seed.coeff[s]*CubicSpline(obj.x,delta)(r)
        if self.psi is not None:
            weighted+=seed.coeff["wave"]*integ((abs(self.psi)**2-1)*r*r,d)
        grad=np.zeros_like(r);grad[1:]=weighted[1:]/(2*a*r[1:]**2)
        func=CubicSpline(r,grad)
        force={s:func(obj.x) for s,obj in self.dust.items()}
        for value in force.values():value[0]=value[-1]=0.
        pot=integ(grad,d);pot-=pot[-1]
        return pot,force
    def kick(self,potential,accel,ht):
        for s,obj in self.dust.items():obj.p-=accel[s]*ht
        if self.psi is not None:self.psi*=np.exp(-1j*self.seed.mass*ht*potential)
    def flux(self,a):
        p=self.psi;der=(25*p[-1]-48*p[-2]+36*p[-3]-16*p[-4]+3*p[-5])/(12*self.dx)
        return self.L**2*np.imag(p[-1].conj()*der)/(self.seed.mass*a*a)
    def step(self,loga,delta):
        r=self.r;a=np.exp(loga+delta/2);dt=delta/self.seed.H(a)
        u,f=self.grav(a);earliest=None
        for s,obj in self.dust.items():
            nx=obj.x+dt*(obj.p-.5*dt*f[s])/a**2
            bad=np.where(np.diff(nx)<=0)[0]
            if bad.size:
                before=np.diff(obj.x)[bad];frac=before/(before-np.diff(nx)[bad]);idx=int(np.argmin(frac))
                event=dict(species=s,shell=int(bad[idx]),estimated_a=float(np.exp(loga+delta*frac[idx])))
                if earliest is None or event["estimated_a"]<earliest["estimated_a"]:earliest=event
        if earliest is not None:return earliest
        self.kick(u,f,dt/2)
        for obj in self.dust.values():obj.x+=dt*obj.p/a**2
        if self.psi is not None:
            f0=self.flux(a)
            w=dst(r[1:-1]*(self.psi[1:-1]-1),type=1,norm="ortho")
            w*=np.exp(-.5j*self.k2*(dt/(a*a*self.seed.mass)))
            self.psi[1:-1]=1+idst(w,type=1,norm="ortho")/r[1:-1]
            self.psi[0]=(15*self.psi[1]-6*self.psi[2]+self.psi[3])/10
            self.integrated_out+=.5*dt*(f0+self.flux(a))
        u,f=self.grav(a);self.kick(u,f,dt/2)
        return None
    def read(self,a):
        r=self.r;R=self.seed.radius
        if self.psi is not None:
            psi=self.psi;dens=abs(psi)**2
            mass=integ(dens*r*r,self.dx);func=CubicSpline(r,mass)
            i=np.searchsorted(mass,self.target)
            pos=brentq(lambda x:func(x)-self.target,r[i-1],r[i],xtol=1e-13)
            der=np.zeros_like(psi);der[2:-2]=(psi[:-4]-8*psi[1:-3]+8*psi[3:-1]-psi[4:])/(12*self.dx)
            der[1]=(psi[1]-8*psi[0]+8*psi[2]-psi[3])/(12*self.dx)
            current=np.imag(psi.conj()*der)/(a*self.seed.mass)
            pec=CubicSpline(r,current)(pos)/CubicSpline(r,dens)(pos)
            lab=(mass[-1]-self.initial_mass+self.integrated_out)/self.target
            self.max_budget=max(self.max_budget,abs(lab))
            maxlink=np.max(abs(np.angle(psi[1:]*psi[:-1].conj()))[r[1:]<2*R])
            fixed=func(R)/self.target
        else:
            obj=self.dust[self.tracer]
            pos=CubicSpline(r,obj.x)(self.q_material)
            pec=CubicSpline(r,obj.p)(self.q_material)/a
            fixed=1+float(CubicSpline(obj.x,obj.M-obj.x**3/3)(R))/self.target
            maxlink=lab=0.
        return dict(a=float(a),material_radius_Mpc=float(a*pos),comoving_material_radius_Mpc=float(pos),
            peculiar_kms=float(C*pec),proper_speed_kms=float(C*(a*self.seed.H(a)*pos+pec)),
            fixed_comoving_mass_ratio=float(fixed),max_inner_link_phase_rad=float(maxlink),
            wall_balance_in_patch_masses=float(lab))
def spectral_run(model,branch,selector,dr=.025,L=24.,steps=256,amp=1.,vel=1.,stop=END,treatment="native",prepared=None):
    seed=Seed(model,branch,selector) if prepared is None else prepared
    assert (seed.model,seed.branch,seed.selector)==(model,branch,selector)
    assert treatment=="native" or (model=="heavy" and treatment in ("dust","cold-seed","cold-seed-dust","compensated"))
    if treatment.startswith("cold-seed"):
        cold=Seed("cold",branch,selector)
        assert np.array_equal(seed.weights,cold.weights)
        seed.fields.update(cold.fields)
        seed.fields["wave"]=cold.fields["cdm"]
        seed.phase=-AI*seed.mass*seed.fields["wave"][1]/seed.k**2
    sphere=Independent(seed,dr,L,amp,vel,treatment)
    epochs=sorted(set([AI,stop]+[a for a in (.04,1/11,.2,1/3,.5,.6,.7,.8,.9) if AI<a<stop]))
    records=[sphere.read(AI)];prev=records[0];turn=None;cross=None;max_phase=0.
    for lo,hi in zip(epochs,epochs[1:]):
        count=int(np.ceil(steps*np.log(hi/lo)));delta=np.log(hi/lo)/count
        for j in range(count):
            if j%128==0:guard()
            loga=np.log(lo)+j*delta
            cross=sphere.step(loga,delta)
            if cross:break
            a=np.exp(loga+delta)
            now=sphere.read(a);max_phase=max(max_phase,now["max_inner_link_phase_rad"])
            if turn is None and prev["proper_speed_kms"]>0>=now["proper_speed_kms"]:
                t=prev["proper_speed_kms"]/(prev["proper_speed_kms"]-now["proper_speed_kms"])
                turn={k:float(prev[k]+t*(now[k]-prev[k])) for k in ("a","material_radius_Mpc")}
            prev=now
        if records[-1]["a"]!=prev["a"]:records.append(prev.copy())
        if cross:break
    tag=f"ind-{model}-{branch}-{selector}-dx{dr:g}-L{L:g}-n{steps}-A{amp:g}-v{vel:g}-end{stop:.4f}"
    if treatment!="native":tag+="-"+treatment
    if prepared is not None:tag+="-"+prepared.preparation
    state={"r":sphere.r,"a":prev["a"]}
    for species,dust in sphere.dust.items():
        for key in ("x","p","M"):state[species+"_"+key]=getattr(dust,key)
    if sphere.psi is not None:state["psi"]=sphere.psi
    packet(tag+".npz",**state)
    summary=dict(model=model,branch=branch,selector=selector,amplitude=amp,velocity_scale=vel,dx=dr,L=L,
        steps_per_loga=steps,turnaround=turn,first_caustic=cross,complete=cross is None,last=prev,
        max_domain_balance_in_patch_masses=float(sphere.max_budget),max_inner_phase_rad=float(max_phase))
    record(tag+".json",summary);table(tag+".csv",records)
    print(tag,turn,cross,prev["proper_speed_kms"],flush=True)
    return summary
if __name__=="__main__":
    model,branch,selector,dx,L,n,*args=sys.argv[1:]
    spectral_run(model,branch,selector,float(dx),float(L),int(n),*map(float,args))
