from collapse import *
def batch(model):
    for branch in ("anchorA","cut1","cut2"):
        for selector in ("heavy","cold"):
            for dr,box,steps in ((.025,24,256),(.0125,24,256),(.0125,24,512),(.00625,24,512)):
                run(model,branch,selector,dr,box,steps)
    for dr,box,steps,amp,vel,exact in ((.0125,40,512,1.,1.,1),(.0125,24,512,1.,0.,1),
              (.0125,24,512,1.,1.,0),(.025,24,256,0.,1.,1)):
        run(model,"anchorA","heavy",dr,box,steps,amp,vel,exact)
if __name__=="__main__":batch(sys.argv[1])
