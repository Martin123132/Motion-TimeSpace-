from seeds import *
from scipy.integrate import solve_ivp

def native(seed):
    model=seed.model;pack=[]
    for path in sorted((SPEC/"runs"/model).glob("chunk-*.npz")):
        key=path.relative_to(SPEC).as_posix()
        with np.load(source(key)) as f:
            pick=np.isin(f["modes"],seed.k)
            if not np.any(pick):continue
            pack.append((f["modes"][pick],f["values"][pick],f["names"].tolist(),f["requested_scale"]))
    k=np.concatenate([r[0] for r in pack]);raw=np.concatenate([r[1] for r in pack]);ix=np.argsort(k)
    k=k[ix,None];raw=raw[ix];names=pack[0][2];epochs=pack[0][3]
    assert np.array_equal(k[:,0],seed.k) and all(r[2]==names and np.array_equal(r[3],epochs) for r in pack)
    col=lambda key:raw[:,:,names.index(key)]
    a=col("a");h=col("H");alpha=-h*col("v_newtonian_cdm")/k**2
    phi=col("etak")/k-h*alpha;psi=2*col("Weyl")/k**2-phi
    data={"cdm":(col("delta_cdm")-3*h*alpha-3*phi,k**2*alpha),
          "baryon":(col("delta_baryon")-3*h*alpha-3*phi,-h*col("v_newtonian_baryon"))}
    if model=="heavy":
        scale=seed.coeff["wave"]/a
        data["wave"]=(col("mts_drho_h")/scale-3*h*alpha-3*phi,k*(col("mts_q_h")/scale+k*alpha))
    start=np.where(epochs==AI)[0].item()
    for species,values in data.items():
        for val,kept in zip(values,seed.fields[species]):
            assert np.allclose(val[:,start],kept,rtol=1e-11,atol=1e-12)
    assert np.max(abs(h[:,start:]/(a[:,start:]*seed.H(a[:,start:]))-1))<TOL
    return epochs,data,psi

def predict(seed,times):
    species=list(seed.fields);k=seed.k
    init=np.array([[D,AI*theta] for D,theta in seed.fields.values()])
    def rate(loga,state):
        a=np.exp(loga);hub=seed.H(a);mat=state.reshape(init.shape)
        dens,p=mat[:,0,:],mat[:,1,:]
        gravity=-sum(seed.coeff[s]*d for s,d in zip(species,dens))/(2*a)
        out=np.empty_like(mat);out[:,0,:]=-p/(a*a*hub);out[:,1,:]=gravity/hub
        if seed.model=="heavy":out[-1,1,:]+=k**4*dens[-1]/(4*a*a*seed.mass**2*hub)
        return out.ravel()
    sol=solve_ivp(rate,np.log([AI,times[-1]]),init.ravel(),t_eval=np.log(times),method="DOP853",rtol=2e-10,atol=1e-12)
    assert sol.success
    return sol.y.reshape((*init.shape,len(times)))
def run():
    rows=[]
    for model in ("heavy","cold"):
        for selector in ("heavy","cold"):
            seed=Seed(model,"anchorA",selector);species="wave" if model=="heavy" else "cdm"
            epochs,comparison,psi=native(seed)
            times=np.array([AI,1/11,1/3,.5,1/1.38,1.])
            assert all(min(abs(epochs-a))<1e-9 for a in times)
            pred=predict(seed,times);which=list(seed.fields).index(species)
            R=seed.radius;k=seed.k
            for j,a in enumerate(times):
                i=abs(epochs-a).argmin()
                truth=tuple(arr[:,i] for arr in comparison[species])
                calc=(pred[which,0,:,j],pred[which,1,:,j]/a)
                m=[];v=[]
                for D,theta in (truth,calc):
                    m.append((seed.weights*D)@top(k*R))
                    v.append(C*(seed.weights*theta/k)@spherical_jn(1,k*R))
                newt=-sum(seed.coeff[s]*comparison[s][0][:,i] for s in seed.fields)/(2*a)
                exact=k**2*psi[:,i]
                frac=np.linalg.norm(seed.weights*(exact-newt))/np.linalg.norm(seed.weights*exact)
                rows.append(dict(model=model,selector=selector,a=a,linear_native_contrast=m[0],linear_predicted_contrast=m[1],
                    contrast_fractional_error=m[1]/m[0]-1,native_radial_kms=v[0],predicted_radial_kms=v[1],velocity_fractional_error=v[1]/v[0]-1,
                    missing_native_metric_source_weighted_relative=frac))
    table("native-linear-control.csv",rows)
if __name__=="__main__":run()
