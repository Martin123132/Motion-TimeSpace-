from spectral import *
def run_group(group):
    if group=="converge":
        for model in ("heavy","cold"):
            for dx,box,steps in ((.025,24.,256),(.0125,24.,512),(.00625,24.,512),(.00625,24.,1024),(.003125,24.,1024),(.0125,40.,512)):
                spectral_run(model,"anchorA","heavy",dx,box,steps)
    elif group=="physics":
        for treatment in ("dust","cold-seed","cold-seed-dust"):
            for dx,n in ((.025,256),(.0125,512)):
                spectral_run("heavy","anchorA","heavy",float(dx),24.,n,treatment=treatment)
        for model in ("heavy","cold"):
            for amp in (-.001,.001):
                spectral_run(model,"anchorA","heavy",.025,24.,256,amp,1.,1/11)
            spectral_run(model,"anchorA","heavy",.025,24.,256,0.,1.,END)
    else:raise ValueError(group)
if __name__=="__main__":run_group(sys.argv[1])
