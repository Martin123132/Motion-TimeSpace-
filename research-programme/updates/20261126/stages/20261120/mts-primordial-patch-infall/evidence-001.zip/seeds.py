import csv
import hashlib
import io
import json
import os
import sys
from pathlib import Path
for key in ("OMP_NUM_THREADS","OPENBLAS_NUM_THREADS","MKL_NUM_THREADS","NUMEXPR_NUM_THREADS","BLIS_NUM_THREADS"):
    os.environ[key]="1"
sys.dont_write_bytecode=True
import numpy as np
from scipy.special import spherical_jn
HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
FORM=ROOT/"mts-formation-state-bundle-20261110"
PATCH=ROOT/"mts-formation-angular-population-20261120"
PREV=ROOT/"mts-pre572-wave-preparation-20261120"
SPEC=ROOT/"condensate-origin-20261003/resolved-matter-spectrum-20261007"
NATIVE=ROOT/"condensate-origin-20261003/native-two-field-transfer-20261007"
C=299792.458
AI=.01
END=.9251591950774056
TOL=2e-5
def guard():
    assert not any((d/"STOP-REQUESTED").exists() for d in (HERE,ROOT,PREV,PATCH,FORM))
def digest(path):
    with path.open("rb") as stream:return hashlib.file_digest(stream,"sha256").hexdigest()
def checked(path,expected):
    assert digest(path)==expected,path
    return path
def obj(path):return json.loads(path.read_bytes())
prior=obj(checked(PREV/"seal.json","ce9ca0f03916af1fa3bfd449a61e779a74ce3427fae0a3a6bcdf65bc2b6c70ee"))["files"]
formation=obj(checked(FORM/"closeout.json","18d0046bd803891009fc5256d583470c1fd16fa4f678389eca2b762c3f93e7d5"))["artifacts"]
patch=obj(checked(PATCH/"seal.json","24b330690e00078dc022feadd2524ca35e416a032f90df89b684c8aef07d3a35"))["files"]
spec=obj(checked(SPEC/"results/stage-integrity.json","83ac0a8b3dd7b017e0d02690b70187be8c5e3513458af6065c3b2da41408e148"))["file_hashes"]
def source(key):return checked(SPEC/key,spec[key])
def save(name,raw):
    guard();p=HERE/name
    if p.exists():assert p.read_bytes()==raw,name
    else:
        with p.open("xb") as stream:stream.write(raw)
def record(name,data):
    save(name,(json.dumps(data,indent=2,sort_keys=True,allow_nan=False)+"\n").encode())
def table(name,rows):
    buf=io.StringIO(newline="");writer=csv.DictWriter(buf,rows[0],lineterminator="\n")
    writer.writeheader();writer.writerows(rows);save(name,buf.getvalue().encode())
def packet(name,**fields):
    buf=io.BytesIO();np.savez_compressed(buf,**fields);save(name,buf.getvalue())
def bank(name):
    filename=name+".npz"
    with np.load(checked(FORM/filename,formation[filename]["sha256"])) as arr:
        col=dict(zip(arr["columns"],arr["values"].T))
        return {k:v[col["nominal_a"]==AI] for k,v in col.items()}
def top(x):
    return np.divide(3*spherical_jn(1,x),x,out=np.ones_like(x),where=x!=0)
class Seed:
    def __init__(self,model,branch,selector="heavy"):
        guard();assert model in ("heavy","cold") and selector in ("heavy","cold")
        with checked(PATCH/"angular-summary.csv",patch["angular-summary.csv"]).open(newline="") as f:
            row,=[r for r in csv.DictReader(f) if (r["branch"],r["band"],r["conditioning"],r["amplitude"])==(branch,"screen","one_sigma","linear_amplitude")]
        self.radius=float(row["R_comoving_Mpc"]);self.model=model;self.branch=branch;self.selector=selector
        heavy,cold,vol=[bank(k) for k in ("late-heavy","late-cold","volume-state")]
        flag=(heavy["both_scale_screens_pass"]==1)&(cold["both_scale_screens_pass"]==1)
        assert flag.sum()==99 and np.all(np.diff(np.where(flag)[0])==1)
        raw=heavy if model=="heavy" else cold
        self.k=k=vol["k_Mpc_inverse"][flag]
        assert np.array_equal(k,raw["k_Mpc_inverse"][flag])
        edges=np.diff(np.log(k));w=.5*(np.r_[edges,0]+np.r_[0,edges])*vol["primordial_power"][flag]
        cond=top(k*self.radius)*vol[selector+"_physical_density"][flag];self.sigma=np.sqrt(w@cond**2)
        self.weights=w*cond/self.sigma
        self.mass=raw["test_mass_Mpc_inverse"][flag][0]
        self.fields={"cdm":(raw["delta_cdm_N"][flag]-3*raw["Phi"][flag],raw["theta_cdm_N"][flag]),
                     "baryon":(raw["delta_baryon_N"][flag]-3*raw["Phi"][flag],raw["theta_baryon_N"][flag])}
        if model=="heavy":
            self.fields["wave"]=(vol["heavy_coordinate_number_contrast"][flag],heavy["heavy_theta_N"][flag])
            self.phase=vol["heavy_spatial_phase"][flag]
            assert np.max(np.abs(self.phase/(-raw["a"][flag]*self.mass*self.fields["wave"][1]/k**2)-1))<1e-10
        status=obj(source("runs/"+model+"/status.json"))
        bg=SPEC/"runs/projection/a225-w6-d8.npz" if model=="heavy" else NATIVE/"runs/backgrounds/cold.npz"
        with np.load(checked(bg,status["source_hash"])) as b:
            self.log_a=b["efold"];self.log_h=np.log(70/C)+.5*np.log(b["expansion2"])
            wave=float(b["matching_density"]) if model=="heavy" else 0.
        with np.load(source("runs/"+model+"/background.npz")) as b:
            self.coeff={s:float(b[s][-1]/b["requested_scale"][-1]) for s in ("cdm","baryon")}
            assert all(abs((b[s][4]/b["requested_scale"][4])/self.coeff[s]-1)<TOL for s in self.coeff)
        if model=="heavy":self.coeff["wave"]=wave
        assert max(abs(raw["H_conformal_Mpc_inverse"][flag]/(AI*self.H(AI))-1))<TOL
    def H(self,a):
        return np.exp(np.interp(np.log(a),self.log_a,self.log_h))
    def transform(self,r,spectrum,order):
        return spherical_jn(order,np.outer(r,self.k))@(self.weights*spectrum)
    def enclosed(self,r,spectrum):
        return top(np.outer(r,self.k))@(self.weights*spectrum)
