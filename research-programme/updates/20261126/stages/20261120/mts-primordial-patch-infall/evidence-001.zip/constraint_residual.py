"""Stress-conservation residual of the archived algebraic radiation replacement."""
from native_balance import Seed, HERE, table, np, derivative


def compare():
    rows=[]
    for model in ("heavy","cold"):
        seed=Seed(model,"anchorA","heavy")
        with np.load(HERE/f"radiation-full-{model}-1.npz") as bank:
            epochs=bank["epochs"]
            modes=bank["modes"][:,None]
            names=bank["names"].tolist()
            values=bank["values"]
            col=lambda key: values[:,:,names.index(key)]
            scale=col("a")
            hub=col("H")
            matter=sum(bank[s]*col("delta_"+s) for s in ("cdm","baryon","nu"))/scale**2
            photon=bank["photon"]/scale**2
            neutrino=bank["neutrino"]/scale**2
            rad_delta=col("delta_neutrino")
            gas_delta=col("delta_photon")
            total=matter+photon*gas_delta+neutrino*rad_delta+col("mts_drho_s")+col("mts_drho_h")
            full=(.5*total/modes+col("etak"))/hub
            partial=(.5*matter/modes+col("etak"))/hub
            momentum=-4*partial/3
            alpha=-hub*col("v_newtonian_cdm")/modes**2
            metric=2*col("Weyl")-modes*col("etak")+modes**2*hub*alpha
            for epoch in (1/11,1/3,.5,1/1.38):
                mid=np.argmin(abs(epochs-epoch))
                slots=mid+np.array([-3,-2,0,2,3])
                def deriv(arr):
                    return hub[:,mid]*derivative(arr[:,slots],np.log(epochs[slots]))
                residual_common=modes[:,0]*(momentum[:,mid]+4*full[:,mid]/3)
                energy=photon[:,mid]*(deriv(gas_delta)+residual_common)+neutrino[:,mid]*(deriv(rad_delta)+residual_common)
                impulse=(photon[:,mid]+neutrino[:,mid])*(deriv(momentum)-modes[:,0]*rad_delta[:,mid]/3)
                predicted=energy/(2*hub[:,mid])+3*impulse/(2*modes[:,0])
                observed=deriv(scale*alpha*modes**2)/scale[:,mid]-metric[:,mid]
                norm=lambda val: np.linalg.norm(seed.weights*val)/np.linalg.norm(seed.weights*metric[:,mid])
                fingerprint=4*(matter/modes**2+col("etak")/modes)
                fingerprint_error=np.max(abs((rad_delta[:,mid]-fingerprint[:,mid])/fingerprint[:,mid]))
                assert fingerprint_error<2e-5
                rows.append(dict(model=model,a=epochs[mid],euler_lapse_residual=norm(observed),
                                 radiation_energy_contribution=norm(energy/(2*hub[:,mid])),
                                 radiation_momentum_contribution=norm(3*impulse/(2*modes[:,0])),
                                 after_signed_radiation_subtraction=norm(observed-predicted),
                                 max_RSA_density_relative=fingerprint_error))
    table("constraint-residual.csv",rows)


if __name__=="__main__":
    compare()
