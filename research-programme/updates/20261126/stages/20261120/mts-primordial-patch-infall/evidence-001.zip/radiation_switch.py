"""Replay the archived perturbation solver, changing only late radiation truncation."""
from native_balance import Seed, SPEC, NATIVE, HERE, checked, source, packet, table, obj, guard, np, sys, derivative

sys.path.insert(0, str(SPEC))
from spectrum_common import inherited, camb, late_scales


def generate(model, full=False):
    seed = Seed(model, "anchorA", "heavy")
    modes = seed.k if full else seed.k[[0, 24, 49, 74, 98]]
    status = obj(source("runs/" + model + "/status.json"))
    for path in inherited.native_hashes():
        checked(path, status["input_hashes"][str(path)])
    path = SPEC / "runs/projection/a225-w6-d8.npz" if model == "heavy" else NATIVE / "runs/backgrounds/cold.npz"
    checked(path, status["source_hash"])
    epochs = late_scales()
    archive = []
    batches = []
    for file in sorted((SPEC / "runs" / model).glob("chunk-*.npz")):
        with np.load(source(file.relative_to(SPEC).as_posix())) as saved:
            pick = np.isin(saved["modes"], modes)
            if pick.any():
                np.testing.assert_array_equal(saved["requested_scale"], epochs)
                archive.extend(zip(saved["modes"][pick], saved["values"][pick]))
                selected = saved["modes"][pick]
                batches.append((selected, np.unique(np.r_[selected, saved["modes"].max()])))
    ordered = sorted(archive, key=lambda pair: pair[0])
    np.testing.assert_array_equal([item[0] for item in ordered], modes)
    original = np.array([item[1] for item in ordered])
    names = camb.model.evolve_names
    for toggle in (True, False):
        guard()
        params = inherited.params_for(path, background_boost=8.)
        assert params.DoLateRadTruncation
        params.DoLateRadTruncation = toggle
        background = camb.get_background(params)
        assert background.Params.DoLateRadTruncation == toggle
        times = background.conformal_time(1/epochs-1, tol=1e-10)
        background.Params.Accuracy.IntTolBoost = 6
        output = []
        for selected, batch in batches:
            guard()
            block = background.get_time_evolution(batch, times, vars=names, lAccuracyBoost=4)
            output.extend(block[np.searchsorted(batch,selected)])
        values = np.array(output)
        assert np.isfinite(values).all()
        if toggle:
            np.testing.assert_allclose(values, original, rtol=2e-5, atol=1e-12)
        rad = background.get_background_densities(epochs, vars=["photon","neutrino","cdm","baryon","nu"])
        label = "-full" if full else ""
        packet(f"radiation{label}-{model}-{int(toggle)}.npz", modes=modes, epochs=epochs, names=names, values=values, **rad)
        print(model, "truncation", toggle, "returned", flush=True)


def analyze():
    rows = []
    for model in ("heavy", "cold"):
        for switch in (1, 0):
            with np.load(HERE / f"radiation-{model}-{switch}.npz") as bank:
                names = bank["names"].tolist()
                epochs, modes = bank["epochs"], bank["modes"]
                for index, mode in enumerate(modes):
                    values = bank["values"][index]
                    col = lambda name: values[:, names.index(name)]
                    expansion = col("H")
                    alpha = -expansion*col("v_newtonian_cdm")/mode**2
                    lapse = 2*col("Weyl")/mode**2 - col("etak")/mode + expansion*alpha
                    ordinary = sum(bank[name]*col("delta_"+name) for name in ("baryon","cdm","nu"))/epochs**2
                    rsa_delta = 4*(ordinary/mode**2 + col("etak")/mode)
                    omega = (bank["photon"]+bank["neutrino"])/(3*epochs**2*expansion**2)
                    for center in (1/11, 1/3, .5, 1/1.38):
                        mid = int(np.argmin(abs(epochs-center)))
                        stencil = np.arange(mid-2,mid+3)
                        accel = derivative((epochs*mode**2*alpha)[stencil],np.log(epochs[stencil]))*expansion[mid]/epochs[mid]
                        metric = mode**2*lapse[mid]
                        fingerprint = rsa_delta[mid] - col("delta_neutrino")[mid]
                        predicted = omega[mid]*col("mts_drho_h")[mid]
                        rows.append(dict(model=model,truncation=switch,k=mode,a=epochs[mid],
                                         euler_minus_lapse_over_lapse=(accel-metric)/metric,
                                         rsa_heavy_omission_over_lapse=predicted/metric,
                                         rsa_neutrino_density_relative=fingerprint/max(abs(rsa_delta[mid]),1e-20),
                                         cdm_volume_contrast=col("delta_cdm")[mid]-3*col("etak")[mid]/mode,
                                         heavy_sync_density=col("mts_drho_h")[mid]))
    table("radiation-switch-test.csv",rows)


if __name__ == "__main__":
    assert sys.argv[1:] in ([], ["--full"])
    for branch in ("heavy","cold"):
        generate(branch, bool(sys.argv[1:]))
    if len(sys.argv)==1:
        analyze()
