"""Use the same primordial realization and matching table in both radiation runs."""
from linear_control import Seed, AI, C, HERE, TOL, table, np, top, spherical_jn, predict
from spectral import spectral_run
from native_balance import derivative


def prepare(model, toggle):
    seed = Seed(model,"anchorA","heavy")
    with np.load(HERE / f"radiation-full-{model}-{toggle}.npz") as raw:
        np.testing.assert_array_equal(raw["modes"],seed.k)
        epochs = raw["epochs"]
        names = raw["names"].tolist()
        values = raw["values"]
        rad = raw["photon"]+raw["neutrino"]
    col = lambda key: values[:,:,names.index(key)]
    scale = col("a")
    hubble = col("H")
    modes = seed.k[:,None]
    alpha = -hubble*col("v_newtonian_cdm")/modes**2
    curvature = col("etak")/modes
    lapse = 2*col("Weyl")/modes**2 - curvature + hubble*alpha
    data = dict(cdm=(col("delta_cdm")-3*curvature,modes**2*alpha),
                baryon=(col("delta_baryon")-3*curvature,-hubble*col("v_newtonian_baryon")))
    if model=="heavy":
        mean = seed.coeff["wave"]/scale
        data["wave"] = col("mts_drho_h")/mean-3*curvature, modes*(col("mts_q_h")/mean+modes*alpha)
    start = np.where(epochs==AI)[0].item()
    for species, (density,velocity) in data.items():
        if toggle:
            for actual, expected in zip((density[:,start],velocity[:,start]),seed.fields[species]):
                np.testing.assert_allclose(actual,expected,rtol=TOL,atol=1e-11)
        seed.fields[species] = density[:,start],velocity[:,start]
    if model=="heavy":
        seed.phase=-AI*seed.mass*data["wave"][1][:,start]/seed.k**2
    seed.preparation="radiation-off" if not toggle else "radiation-on"
    return seed, epochs, data, lapse, rad*col("mts_drho_h")/(3*scale**2*hubble**2)


def norm(seed, array):
    return np.linalg.norm(seed.weights*array)


def compare():
    results=[]
    for model in ("heavy","cold"):
        for switch in (1,0):
            seed, epochs, data, lapse, omitted = prepare(model,switch)
            times = np.array([AI,1/11,1/3,.5,1/1.38,1.])
            target = "wave" if model=="heavy" else "cdm"
            predicted = predict(seed,times)[list(seed.fields).index(target)]
            for index, epoch in enumerate(times):
                location = np.argmin(abs(epochs-epoch))
                assert abs(epochs[location]-epoch)<1e-12
                kernel = seed.weights*top(seed.k*seed.radius)
                current_kernel = C*seed.weights/seed.k*spherical_jn(1,seed.k*seed.radius)
                contrast = kernel@data[target][0][:,location]
                velocity = current_kernel@data[target][1][:,location]
                row = dict(model=model,switch=switch,a=epoch,contrast=contrast,velocity=velocity,
                           contrast_NR_over_native_minus_one=kernel@predicted[0,:,index]/contrast-1,
                           velocity_NR_over_native_minus_one=current_kernel@predicted[1,:,index]/epoch/velocity-1,
                           euler_error="",omission_corrected_error="",wide_euler_error="")
                if 0<index<len(times)-1:
                    metric = seed.k**2*lapse[:,location]
                    for width, label in ((1,"euler_error"),(2,"wide_euler_error")):
                        offsets = [-2,-1,0,1,2] if width==1 else [-3,-2,0,2,3]
                        slots = location+np.array(offsets)
                        growth = derivative(data["cdm"][1][:,slots]*epochs[slots],np.log(epochs[slots]))*seed.H(epoch)
                        row[label] = norm(seed,growth-metric)/norm(seed,metric)
                        if width==2:
                            row["omission_corrected_error"]=norm(seed,growth-metric-omitted[:,location])/norm(seed,metric)
                results.append(row)
    table("matched-hierarchy-test.csv",results)


def collapse():
    for model in ("heavy","cold"):
        seed = prepare(model,0)[0]
        for amplitude in (1.,2.):
            for spacing, steps in ((.0125,512),(.00625,512)):
                spectral_run(model,"anchorA","heavy",spacing,24.,steps,amplitude,
                             treatment="compensated" if model=="heavy" else "native",prepared=seed)


def counterfactuals():
    native = prepare("heavy",0)[0]
    cold = prepare("cold",0)[0]
    np.testing.assert_array_equal(native.weights,cold.weights)
    for spacing,steps in ((.00625,1024),(.003125,1024)):
        spectral_run("heavy","anchorA","heavy",spacing,24.,steps,treatment="compensated",prepared=native)
    spectral_run("heavy","anchorA","heavy",.00625,24.,512,treatment="dust",prepared=native)
    swapped = prepare("heavy",0)[0]
    swapped.fields.update(cold.fields)
    swapped.fields["wave"] = cold.fields["cdm"]
    swapped.phase = -AI*swapped.mass*swapped.fields["wave"][1]/swapped.k**2
    swapped.preparation = "swapped-full-cold-IC"
    for treatment in ("compensated","dust"):
        spectral_run("heavy","anchorA","heavy",.00625,24.,512,treatment=treatment,prepared=swapped)


def volume_check():
    from collapse import run
    for model in ("heavy","cold"):
        seed = prepare(model,0)[0]
        for amplitude in (1.,2.):
            for spacing in (.00625,.003125):
                run(model,"anchorA","heavy",spacing,24.,512,amplitude,prepared=seed,compensate=model=="heavy")
        for amplitude in (-.001,.001):
            spectral_run(model,"anchorA","heavy",.0125,24.,512,amplitude,stop=1/11,
                         treatment="compensated" if model=="heavy" else "native",prepared=seed)


def fine_volume():
    from collapse import run
    seed=prepare("heavy",0)[0]
    for amplitude in (1.,2.):
        run("heavy","anchorA","heavy",.0015625,24.,512,amplitude,prepared=seed,compensate=True)


if __name__=="__main__":
    import sys
    compare()
    if sys.argv[1:]==["--collapse"]:
        collapse()
    if sys.argv[1:]==["--counterfactuals"]:
        counterfactuals()
    if sys.argv[1:]==["--volume"]:
        volume_check()
    if sys.argv[1:]==["--fine-volume"]:
        fine_volume()
