from linear_control import *
def derivative(raw,x):
    delta=x-x[2];scale=max(abs(delta));mat=np.vstack([(delta/scale)**j for j in range(5)])
    weights=np.linalg.solve(mat,np.eye(5)[1]/scale)
    return raw@weights
def run():
    rows=[]
    for model in ("heavy","cold"):
        seed=Seed(model,"anchorA","heavy");epochs,data,psi=native(seed);k=seed.k
        for a0 in (1/11,1/3,.5,1/1.38):
            center=np.argmin(abs(epochs-a0));slots=np.arange(center-2,center+3)
            a=epochs[center];hc=a*seed.H(a);rel=abs(epochs[slots]/a-1)
            assert max(rel)<.005
            for species,(D,theta) in data.items():
                dD=derivative(D[:,slots],np.log(epochs[slots]))
                dp=derivative(theta[:,slots]*epochs[slots],np.log(epochs[slots]))
                true_metric=k**2*psi[:,center]
                nr=(k**4*D[:,center]/(4*a*a*seed.mass**2)) if species=="wave" else np.zeros_like(k)
                rest=np.linalg.norm(seed.weights*(dp*seed.H(a)-true_metric-nr))/np.linalg.norm(seed.weights*true_metric)
                continuous=np.linalg.norm(seed.weights*(dD+theta[:,center]/hc))/np.linalg.norm(seed.weights*dD)
                rows.append(dict(model=model,a=a,species=species,continuity_weighted_fraction=continuous,euler_weighted_fraction=rest,
                                 radial_velocity_kms=C*(seed.weights*theta[:,center]/k)@spherical_jn(1,k*seed.radius)))
    table("native-local-equations.csv",rows)
if __name__=="__main__":run()
