from seeds import *
from scipy.linalg import solve_banded

def taper(r,L):
    u=np.clip(3*r/L-2,0,1)
    return .5*(1+np.cos(np.pi*u))
class Shells:
    def __init__(self,seed,species,edges,L,amplitude,velocity):
        self.x=edges.copy();k=seed.k;D,theta=seed.fields[species];win=taper(edges,L)
        self.M=edges**3/3*(1+amplitude*seed.enclosed(edges,D)*win)
        self.p=AI*amplitude*velocity*seed.transform(edges,theta/k,1)*win
        assert np.all(np.diff(self.M)>0)
    def excess(self,r):
        return np.interp(r**3,self.x**3,self.M-self.x**3/3)
class Sphere:
    def __init__(self,seed,dr,L,amplitude,phase_scale,exact_amp,compensate=False):
        self.seed=seed;self.L=L
        count=int(round(L/dr));self.dx=dx=L/count
        e=self.e=np.arange(count+1)*dx;self.r=r=.5*(e[1:]+e[:-1])
        self.weight=np.diff(e**3)/3;self.sqrtw=np.sqrt(self.weight)
        self.dust={s:Shells(seed,s,e,L,amplitude,phase_scale) for s in ("cdm","baryon")}
        self.target=seed.radius**3/3;self.wave=None
        if seed.model=="heavy":
            D=seed.transform(r,seed.fields["wave"][0],0)*amplitude*taper(r,L)
            if compensate:
                assert exact_amp
                excess=e**3/3*seed.enclosed(e,seed.fields["wave"][0])*amplitude*taper(e,L)
                D=np.diff(excess)/self.weight
            phase=seed.transform(r,seed.phase,0)*amplitude*phase_scale*taper(r,L)
            assert np.min(1+D)>0
            amplitude_field=np.sqrt(1+D) if exact_amp else 1+.5*D
            self.wave=self.sqrtw*amplitude_field*np.exp(1j*(phase-phase[0]))
            coeff=e[1:-1]**2/dx
            self.off=-coeff/(self.sqrtw[:-1]*self.sqrtw[1:])
            self.diag=(np.r_[0,coeff]+np.r_[coeff,0])/self.weight
            self.start_norm=np.vdot(self.wave,self.wave).real
        self.max_norm=self.turn=self.shell_turned=0
    def wave_M(self):
        return np.r_[0,np.cumsum(abs(self.wave)**2)]
    def force(self,a):
        e,r=self.e,self.r
        weighted=sum(self.seed.coeff[s]*obj.excess(e) for s,obj in self.dust.items())
        if self.wave is not None:
            weighted+=self.seed.coeff["wave"]*np.r_[0,np.cumsum(abs(self.wave)**2-self.weight)]
        grad=np.zeros_like(e);grad[1:]=weighted[1:]/(2*a*e[1:]**2)
        shell_force={s:np.interp(obj.x,e,grad) for s,obj in self.dust.items()}
        for accel in shell_force.values():accel[0]=accel[-1]=0
        potential=-np.cumsum((.5*self.dx*(grad[1:]+grad[:-1]))[::-1])[::-1]
        centers=potential+self.dx*(3*grad[:-1]+grad[1:])/8
        return centers,shell_force
    def drift(self,dt,a):
        z=.25j*dt/(self.seed.mass*a*a)
        diag=z*self.diag;link=z*self.off
        rhs=(1-diag)*self.wave
        rhs[:-1]-=link*self.wave[1:];rhs[1:]-=link*self.wave[:-1]
        mat=np.zeros((3,len(diag)),complex)
        mat[1]=1+diag;mat[0,1:]=link;mat[2,:-1]=link
        self.wave=solve_banded((1,1),mat,rhs,overwrite_ab=True,overwrite_b=True,check_finite=False)
    def kick(self,pot,accel,halfdt):
        for s,obj in self.dust.items():obj.p-=halfdt*accel[s]
        if self.wave is not None:self.wave*=np.exp(-1j*self.seed.mass*halfdt*pot)
    def step(self,loga,dlog):
        a=np.exp(loga+.5*dlog);dt=dlog/self.seed.H(a)
        pot,accel=self.force(a);self.kick(pot,accel,.5*dt)
        cross=None
        for s,obj in self.dust.items():
            nx=obj.x+dt*obj.p/a**2;bad=np.where(np.diff(nx)<=0)[0]
            if bad.size:
                j=int(bad[0]);oldgap=obj.x[j+1]-obj.x[j];newgap=nx[j+1]-nx[j]
                progress=oldgap/(oldgap-newgap)
                failure=dict(species=s,shell=j,initial_radius_Mpc=float(self.e[j]),comoving_radius_Mpc=float(obj.x[j]),estimated_a=float(np.exp(loga+progress*dlog)))
                if cross is None or failure["estimated_a"]<cross["estimated_a"]:cross=failure
        if cross:return cross
        for obj in self.dust.values():obj.x+=dt*obj.p/a**2
        if self.wave is not None:self.drift(dt,a)
        pot,accel=self.force(a);self.kick(pot,accel,.5*dt)
        if self.wave is not None:
            err=abs(np.vdot(self.wave,self.wave).real/self.start_norm-1);self.max_norm=max(self.max_norm,err)
            assert self.max_norm<1e-10
        return None
    def readout(self,a):
        R=self.seed.radius;e=self.e
        if self.wave is not None:
            M=self.wave_M();pos=np.interp(self.target,M,e**3)**(1/3)
            psi=self.wave/self.sqrtw
            flux=e[1:-1]**2*np.imag(np.conj(psi[:-1])*psi[1:])/(self.seed.mass*a**2*self.dx)
            probe_flux=np.interp(R,e[1:-1],flux)
            density=abs(psi)**2
            pec=np.interp(pos,e[1:-1],flux)*a/(pos**2*np.interp(pos,self.r,density))
            inside=e[1:-1]<max(2*R,2*pos)
            phase_max=np.max(abs(np.angle(np.conj(psi[:-1])*psi[1:]))[inside])
            fixed=np.interp(R**3,e**3,M)
        else:
            d=self.dust["cdm"];pos=np.interp(self.target,d.M,d.x**3)**(1/3)
            pec=np.interp(pos,d.x,d.p)/a;fixed=R**3/3+d.excess(np.array([R]))[0]
            rho=np.diff(d.M)/(np.diff(d.x**3)/3)
            probe_flux=R**2*np.interp(R,.5*(d.x[:-1]+d.x[1:]),rho)*np.interp(R,d.x,d.p)/a**2
            phase_max=0.
        return dict(a=float(a),material_radius_Mpc=float(a*pos),comoving_material_radius_Mpc=float(pos),
            peculiar_kms=float(C*pec),proper_speed_kms=float(C*(a*self.seed.H(a)*pos+pec)),
            enclosed_mean_contrast=float(3*self.target/pos**3-1),fixed_comoving_mass_ratio=float(fixed/self.target),
            outward_flux_fraction_per_log_a=float(probe_flux/self.target/self.seed.H(a)),inner_max_link_phase_rad=float(phase_max),norm_error=self.max_norm)
def run(model,branch,selector,dr,L,steps,amp=1.,vel=1.,exact=1,stop=END,prepared=None,compensate=False):
    dr,L,amp,vel=map(float,(dr,L,amp,vel))
    seed=Seed(model,branch,selector) if prepared is None else prepared
    assert (model,branch,selector)==(seed.model,seed.branch,seed.selector)
    sphere=Sphere(seed,dr,L,amp,vel,bool(exact),compensate);start=np.log(AI)
    epochs=sorted(set([AI,stop]+[a for a in (.02,.04,.0909090909090909,.15,.2,1/3,.4,.5,.6,.7,.8,.9) if AI<a<stop]))
    records=[sphere.readout(AI)];snap={};cross=None;turn=None;last=records[0]
    for lo,hi in zip(epochs,epochs[1:]):
        count=int(np.ceil(steps*np.log(hi/lo)));delta=np.log(hi/lo)/count
        for j in range(count):
            if j%128==0:guard()
            loga=np.log(lo)+j*delta
            cross=sphere.step(loga,delta)
            if cross:break
            a=np.exp(loga+delta)
            now=sphere.readout(a)
            if turn is None and last["proper_speed_kms"]>0>=now["proper_speed_kms"]:
                frac=last["proper_speed_kms"]/(last["proper_speed_kms"]-now["proper_speed_kms"])
                turn={key:float(last[key]+frac*(now[key]-last[key])) for key in ("a","material_radius_Mpc")}
            last=now
        if cross:
            if records[-1]["a"]!=last["a"]:records.append(last.copy())
            break
        records.append(last.copy())
        if abs(hi-stop)<1e-10 or np.isclose(hi,1/11):
            for s,dust in sphere.dust.items():
                snap[f"x_{s}_{hi:.6f}"]=dust.x.copy();snap[f"p_{s}_{hi:.6f}"]=dust.p.copy()
            if sphere.wave is not None:snap[f"wave_{hi:.6f}"]=sphere.wave.copy()
    tag=f"{model}-{branch}-{selector}-dx{dr:g}-L{L:g}-n{steps}-A{amp:g}-v{vel:g}-sq{exact}-end{stop:.4f}"
    if compensate:tag+="-compensated"
    if prepared is not None:tag+="-"+prepared.preparation
    if snap:
        packet(tag+".npz",edges=sphere.e,**snap)
    table(tag+".csv",records)
    summary=dict(model=model,branch=branch,selector=selector,amplitude=amp,velocity_scale=vel,exact_density=bool(exact),
      dx=dr,L=L,steps_per_loga=steps,turnaround=turn,first_caustic=cross,last=last,
      complete=cross is None,material_target_comoving_Mpc=seed.radius,condition_sigma=seed.sigma)
    record(tag+".json",summary)
    print(tag,"turn",turn,"caustic",cross,"last v",last["proper_speed_kms"],flush=True)
    return summary
if __name__=="__main__":
    model,branch,selector,dx,L,steps,*extra=sys.argv[1:]
    run(model,branch,selector,float(dx),float(L),int(steps),*[float(v) if i!=2 else int(v) for i,v in enumerate(extra)])
