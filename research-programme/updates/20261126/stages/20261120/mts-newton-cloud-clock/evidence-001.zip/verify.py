from compare import *
import re

def main():
    guard()
    for folder in PINS:
        for name,digest in files(folder).items():assert sha(folder/name)==digest,(folder,name)
    for script in HOME.glob("*.py"):
        compile(script.read_bytes(),str(script),"exec")
    for name in ("DERIVATION.md","RESULTS.md","REPLAY.md"):
        for link in re.findall(r"(?<!\w)\[[^\]\n]+\]\(([^)]+)\)",(HOME/name).read_text(encoding="utf8")):
            assert link.startswith("https://") or (HOME/link).is_file(),link
    assert not (HOME/"__pycache__").exists() and not list(HOME.glob("*.partial"))
    expected={(model,grid,history,4) for model in ("heavy","cold") for grid in (4,5) for history in ("normal","longitudinal","archive")}
    expected.update({("heavy",5,history,8) for history in ("normal","longitudinal","archive")})
    expected.add(("heavy",5,"archive",2))
    for model,grid,history,steps in expected:
        name=f"{model}-h{grid}-{history}-n{steps}.csv"
        data=groups(name)
        assert len(read(HOME/name))==len(data)==(18 if history=="archive" else 12)
        for seed in (1,-1):
            for radius in RADII:
                assert (subtract(data,seed,radius,"rate_integral")==0)==(model=="cold")
    assert len(read(HOME/"signed-increments.csv"))==72
    assert len(read(HOME/"signed-shells.csv"))==28
    assert len(read(HOME/"matched-current-projection.csv"))==60
    checks=read(HOME/"constraint-diagnosis.csv")
    assert len(checks)==18 and 0<sum(r["pass_20ppm_on_split"]=="True" for r in checks)<18
    assert max(abs(float(r["on_total_integral"])) for r in checks)<2e-5
    assert len(read(HOME/"manufactured-checks.csv"))==6 and len(read(HOME/"constraint-manufactured.csv"))==4
    for grid in (80,120):
        data=read(HOME/f"subsidiary-n{grid}-t192-p1.csv")
        assert len(data)==12 and any(abs(float(row["relative"]))>2e-5 for row in data)
    counts={}
    for path in HOME.glob("*.csv"):
        rows=read(path)
        assert rows and all(None not in row and None not in row.values() for row in rows),path
        assert not any(v.strip().lower() in ("nan","inf","-inf") for row in rows for v in row.values())
        counts[path.name]=len(rows)
    registry={path.name:sha(path) for path in sorted(HOME.iterdir()) if path.is_file() and path.name!="seal.json"}
    audit=dict(files=registry,rows=counts,parents={folder.name:pin for folder,pin in PINS.items()},verified_inputs=sum(len(files(folder)) for folder in PINS))
    raw=(json.dumps(audit,indent=2,sort_keys=True)+"\n").encode()
    seal=HOME/"seal.json"
    if seal.exists():assert seal.read_bytes()==raw
    else:
        with seal.open("xb") as stream:stream.write(raw)
    print(len(registry),"files;",sum(counts.values()),"rows;",audit["verified_inputs"],"unchanged upstream files;",sha(seal))
if __name__=="__main__":main()
