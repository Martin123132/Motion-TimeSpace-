"""Predict the Hamiltonian constraint's evolution from the ADM momentum defect, before reading the tides."""
from constraint_rate import *

def quantities(shell,time,state,rhs):
    ham,actual=measure(shell,state,rhs,True)
    ell,bend,tilt,_,trace,shear=state[:6].real
    info=shell.dynamics(time,state,True)
    normal=exp(-ell);curve=mul(normal,2*shell.diff(bend)+pair(2/shell.r,6*tilt[1]/shell.r))
    radial,angular=info["mom_r"],info["mom_theta"][1]
    div=mul(normal,shell.diff(radial,odd=True))+mul(curve,radial)
    div[1]-=6*np.exp(-bend[0])*angular/shell.r
    dilution=mul(2*trace/3+shell.project*shear/2,ham)
    return ham,actual,dilution,-2*div

def checks():
    class Empty:
        local=None
        def __init__(self,radius):self.data=np.zeros((7,len(radius)))
        def at(self,time):return self.data.copy()
    rows=[]
    for project in (0,1):
        with np.load(checked(CLOUD,"launch-h5-off1-seed1.npz")) as pkt:
            shell=Conserved(pkt,80,6,1,project)
        shell.incident=Empty(shell.r);shell.rho[:]=0.
        radius=shell.r;state=np.zeros_like(shell.initial)
        k0,a,b,c=-.51,.017,.013,.00061
        trace=pair(k0+a*radius**2,c*radius**4);shear=pair(b*radius**2)
        state[4]=trace;state[5]=shear
        dstate=shell.dynamics(0,state)
        ham,actual,local,flow=quantities(shell,0,state,dstate)
        expected_den=2*square(trace)/3-1.5*square(shear)
        expected_flow=pair(np.full_like(radius,8*a-30*b),56*c*radius**2/3)
        truth=mul(2*trace/3+project*shear/2,expected_den)+expected_flow
        region=(radius>.5)&(radius<4)
        for harmonic in (0,1):
            peak=np.max(np.abs(truth[harmonic,region]))
            residual=np.max(abs(actual[harmonic,region]-truth[harmonic,region]))/peak
            rate=np.max(abs((flow+local-truth)[harmonic,region]))/peak
            assert max(residual,rate)<2e-5,(residual,rate)
            rows.append(dict(project=project,harmonic=harmonic,direct_rel=residual,subsidiary_rel=rate))
    output("constraint-manufactured.csv",rows)

def main(res,steps,project):
    results={};step=DURATION/(2*steps)
    for flag in (0,1):
        for seed in (0,1,-1):
            with np.load(checked(CLOUD,f"launch-h5-off{flag}-seed{seed}.npz")) as packet:
                shell=Conserved(packet,res,6,flag,project)
            start=shell.initial;change=np.zeros_like(start);values=[]
            for tick in range(2*steps+1):
                time=tick*step;state=start+change;one=shell.dynamics(time,state)
                if tick%(steps//16)==0:
                    guard()
                    ham,actual,local,flow=quantities(shell,time,state,one)
                    def readout(field):
                        return np.array(ruler_variation(shell,state[:14].real,one[:14].real,ham,field))
                    full=readout(actual);dil=readout(local);div=readout(flow)
                    values.append(np.stack((full[:,1],full[:,2],dil[:,1],div[:,1]),axis=-1)/6)
                if tick==2*steps:break
                two=shell.dynamics(time+step/2,start+(change+step*one/2))
                three=shell.dynamics(time+step/2,start+(change+step*two/2))
                four=shell.dynamics(time+step,start+(change+step*three))
                change+=step*(one+2*two+2*three+four)/6
            results[flag,seed]=np.array(values)
            print("subsidiary",res,steps,project,flag,seed,flush=True)
    rows=[]
    for seed in (1,-1):
        series=(results[0,seed]-results[0,0])-(results[1,seed]-results[1,0])
        for stride in (1,2):
            ints=simpson(series[::stride],dx=DURATION/32*stride,axis=0)
            for radius,(observed,ruler,local,momentum) in zip(RADII,ints):
                truth=observed+ruler; forecast=local+momentum+ruler
                rows.append(dict(grid=res,steps=steps,project=project,seed=seed,radius=radius,stride=stride,
                    direct=truth,proper_ruler=ruler,local=local,momentum_divergence=momentum,predicted=forecast,
                    residual=truth-forecast,relative=forecast/truth-1))
    output(f"subsidiary-n{res}-t{steps}-p{project}.csv",rows)

if __name__=="__main__":
    if sys.argv[1]=="check":checks()
    else:main(*map(int,sys.argv[1:]))
