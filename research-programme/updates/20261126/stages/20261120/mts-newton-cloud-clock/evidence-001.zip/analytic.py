"""Known polynomial Poisson field and independent continuity projection, including the finite outer face."""
from launch_flux import *
from mesh import Mesh
from types import SimpleNamespace

def checks():
    records=[]
    edge=6.
    mesh=Mesh(edge,24)
    kernel=Kernel(mesh)
    nodes=leggauss(10)[0]/2+.5
    h=mesh.h
    grid=SimpleNamespace(t=nodes,h=h,ne=mesh.segments)
    projection=Projection(grid,16)
    coord=h*(np.arange(grid.ne)[:,None]+grid.t)
    for radius in RADII:
        op=kernel.rows(radius)
        for power in (2,4):
            src=mesh.r[1:]**power
            expected=lambda r: -r**power/3+1.2*r**power/(power+5)+(edge**power-r**power)/5/power
            slope=radius**(power-1)*(-power/3+1.2*power/(power+5)-.2)
            amplitude=float(op[0]@src); derivative=float(op[1]@src)
            assert abs(amplitude/expected(radius)-1)<3e-13 and abs(derivative/slope-1)<3e-11
            growth=1.37
            law=((growth-3)*amplitude-radius*derivative)
            check=lambda x:np.exp((growth-3)*x)*expected(radius*np.exp(-x))
            step=2e-5
            fd=(check(-2*step)-8*check(-step)+8*check(step)-check(2*step))/(12*step)
            assert abs(law/fd-1)<2e-10
            radial=coord**(power+1);angular=.37*radial
            projected=projection.apply((radial,angular),radius,edge)
            exact_flux=(-(power+3)+6*.37)*expected(radius)
            assert abs(sum(projected[:3])/exact_flux-1)<2e-12
            records.append(dict(radius=radius,power=power,static_rel=amplitude/expected(radius)-1,
                gradient_rel=derivative/slope-1,proper_rate_rel=law/fd-1,flux_rel=sum(projected[:3])/exact_flux-1))
    output("manufactured-checks.csv",records)
if __name__=="__main__":checks()
