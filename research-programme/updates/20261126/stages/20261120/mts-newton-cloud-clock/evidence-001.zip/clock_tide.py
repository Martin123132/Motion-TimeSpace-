"""Advance the saved signed Newtonian preparations and differentiate their physical tidal observable."""
import csv
import functools
import hashlib
import io
import json
import os
import sys
from pathlib import Path

for variable in ("OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "OMP_NUM_THREADS", "NUMEXPR_NUM_THREADS"):
    os.environ[variable] = "1"
sys.dont_write_bytecode = True
import numpy as np
from numpy.polynomial.legendre import leggauss, legvander, legder, legval
from scipy.integrate import quad
from scipy.interpolate import CubicSpline
from scipy.optimize import brentq

HOME = Path(__file__).resolve().parent
ROOT = HOME.parent
CLOUD = ROOT / "mts-kg-cloud-propagation-20261120"
SLICES = ROOT / "mts-signed-cmc-constraints-20261120"
FORM = ROOT / "mts-transmitted-formation-tide-20261120"
NORMAL = ROOT / "mts-kg-normal-transport-20261120"
PINS = {CLOUD: "09e51511de68eecd69bbc77a805a170c5af910b796cbf2f12f4b4cdb35338d71",
        SLICES: "2352e526baaf93f519cf5e8d5a6ea74e28bd6285dfa644b37c91c4556df152b9",
        FORM: "17ac8f0f3501b0de8c32b8cb9cf5c47c4bb2435c5f3409eda0e0478467252878",
        NORMAL: "d623f08bda8ded048011c3cab48b1fbc6ffe88ddbfa65dbbab0ec798f9621a7c"}

def sha(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()

@functools.cache
def files(folder):
    assert sha(folder/"seal.json") == PINS[folder]
    return json.loads((folder/"seal.json").read_bytes())["files"]

@functools.cache
def checked(folder, name):
    path = folder/name
    assert sha(path) == files(folder)[name], path
    return path

def output(name, rows):
    stream = io.StringIO(newline="")
    writer = csv.DictWriter(stream, fieldnames=list(rows[0]), lineterminator="\n")
    writer.writeheader()
    writer.writerows(rows)
    data = stream.getvalue().encode("utf8")
    path = HOME/name
    if path.exists():
        assert path.read_bytes() == data, path
    else:
        with path.open("xb") as handle:
            handle.write(data)

for name in ("balanced.py", "campaign.py"):
    checked(FORM, name)
sys.path.insert(0, str(FORM))
from balanced import BalancedNative
from campaign import AI, DLOG, SPAN, guard

START = DLOG*SPAN
RADII = (.676538827, 1.35307765, 2.7061553)
with np.load(checked(CLOUD, "launch-h5-off0-seed1.npz")) as prep:
    SCALE = float(prep["a"])
    DURATION = 4*np.pi/float(prep["mu"])
assert abs(AI*np.exp(START)/SCALE-1) < 1e-12

class Kernel:
    def __init__(self, mesh, order=12):
        self.mesh = mesh
        local = mesh.loc[0]*2/mesh.h-1
        self.basis = np.linalg.inv(legvander(local, mesh.order))
        self.nodes, self.weights = leggauss(order)
        self.outer = np.zeros_like(mesh.loc)
        self.inside = np.zeros_like(mesh.loc)
        for power, arr in ((4, self.inside), (-1, self.outer)):
            points = mesh.loc[:, :1] + (self.nodes+1)*mesh.h/2
            arr[:] = (points**power * self.weights * mesh.h/2) @ (legvander(self.nodes, mesh.order)@self.basis)
    def segment(self, index, lower, upper, power):
        mesh = self.mesh
        points = (upper+lower)/2 + self.nodes*(upper-lower)/2
        basis = legvander((points/mesh.h-index)*2-1, mesh.order)@self.basis
        return ((upper-lower)/2 * self.weights * points**power)@basis
    @functools.lru_cache(maxsize=160)
    def rows(self, radius):
        mesh = self.mesh
        index = int(radius/mesh.h)
        left, right = self.inside.copy(), self.outer.copy()
        left[index:] = 0
        right[:index+1] = 0
        left[index] = self.segment(index, index*mesh.h, radius, 4)
        right[index] = self.segment(index, radius, (index+1)*mesh.h, -1)
        value, slope = np.zeros_like(left), np.zeros_like(left)
        point = 2*(radius/mesh.h-index)-1
        value[index] = legvander([point], mesh.order)[0]@self.basis
        slope[index] = legval(point, legder(self.basis), tensor=True)*2/mesh.h
        inside, outside, local, grad = (mesh.gather(arr)[1:] for arr in (left,right,value,slope))
        return np.stack((-local/3 + 1.2*inside/radius**5 + .2*outside,
                         -grad/3 + local/radius - 6*inside/radius**6,
                         -local/3, 1.2*inside/radius**5, .2*outside))

class Traces:
    def __init__(self, model, sim):
        self.banks = []
        self.sim = sim
        for flag in (0, 1):
            with np.load(checked(NORMAL if model=="heavy" else CLOUD, f"trace-{model}-off{flag}.npz")) as archive:
                fields = dict(zip(archive["names"].tolist(), archive["values"].transpose(2,0,1)))
                time, wave = archive["dt"], archive["k"][:,None]
                np.testing.assert_array_equal(wave[:,0], sim.patch.k)
            scale = fields["a"]; sigma = fields["sigma"]; hub = fields["H"]; enthalpy = fields["R"]+fields["P"]
            qnew = fields["Q"]+enthalpy*sigma
            initial_shift = (sigma/wave - 1.5*qnew/wave/(wave**2+1.5*enthalpy))[:, :1]
            shift = sigma/wave - initial_shift*(scale[:, :1]/scale)
            mass = sim.patch.p.coeff[-1]/scale
            den = [fields["dc"],fields["db"]]; vel = [sigma, sigma+fields["vb"]]
            if model=="heavy":
                den.append(fields["mts_drho_h"]/mass); vel.append(sigma+fields["mts_q_h"]/mass)
            data = np.stack((np.array(den)-3*fields["eta"], -np.array(vel)/wave, np.broadcast_to(shift, np.shape(vel))),axis=1)
            background = scale.mean(axis=0)
            relative = np.log(background/background[0])
            self.banks.append(CubicSpline(relative, data.transpose(3,1,0,2),extrapolate=False))
            if not flag:
                self.hubble = CubicSpline(relative,hub.mean(axis=0),extrapolate=False)
                self.top = relative[-1]
                self.proper = CubicSpline(time,background/background[0]).antiderivative()
                self.log_time = CubicSpline(time,relative)
                self.native_stop = self.log_time(brentq(lambda eta:self.proper(eta)-DURATION,0,time[-1]))
            else:
                assert abs(relative[-1]/self.top-1)<1e-8
    def histories(self, elapsed, lift):
        left, right = (bank(elapsed) for bank in self.banks)
        def dv(data):
            den, vel, shift = data
            return np.stack((den, vel+shift if lift=="normal" else vel))
        live, control = dv(left),dv(right)
        return np.stack((live,control,live-control),axis=1)

def advance(model, rate, timeline, steps, seed_list=(1,-1), shells=False):
    guard()
    sim = BalancedNative(model,120,120*rate,False,"native36",START+.00002)
    traces = Traces(model,sim)
    archived_coeff = sim.patch.coeff
    if timeline == "archive":
        end = brentq(lambda dx:quad(lambda offset:np.exp(offset)/archived_coeff(START+offset)[0],0,dx)[0]-DURATION,0,.00002,xtol=1e-17)
    else:
        end = float(traces.native_stop)
        sim.patch.coeff = lambda time:(float(traces.hubble(time-START)),SCALE*np.exp(time-START))
        sim.ref.solution = lambda time: traces.histories(time-START,timeline)
    kernel = Kernel(sim.mesh); dt=end/steps; weight = sim.patch.p.coeff/SCALE
    results = []
    cuts = (2.7061553,6.,12.,24.,36.,72.)
    shell_results = []
    for seed in seed_list:
        fname = f"evolved-{model}-L120-h{rate}-t176.npz" if seed==1 else f"collar-{model}-L120-h{rate}--1.npz"
        with np.load(checked(FORM,fname)) as archive:
            assert archive["x"][-1]==START
            original = tuple(archive[key] for key in ("mono","density","velocity"))
        def deriv(state, offset, flag):
            sim.patch.wave = model=="heavy" and not (flag==1 and timeline!="archive")
            return sim.rates(state,START+offset)
        def source(state, channel):
            return weight @ state[1][channel]
        def readout(source_now, offset):
            return np.array([np.exp(-3*offset)*(kernel.rows(radius*np.exp(-offset))[0]@source_now) for radius in RADII])
        def terms(value, derivative, offset):
            pieces=[]
            for radius in RADII:
                rr=radius*np.exp(-offset)
                operator=kernel.rows(rr);fac=np.exp(-3*offset)
                pieces.append(fac*np.r_[operator[2:]@derivative,-3*(operator[0]@value),-rr*(operator[1]@value)])
            regions=[]
            if shells:
                outside=[pieces[1][2]]+[np.exp(-3*offset)*(kernel.rows(cut)[4]@derivative) for cut in cuts]+[0.]
                regions=np.subtract(outside[:-1],outside[1:])
            return np.r_[np.array(pieces).ravel(),regions]
        per_channel=[]
        for flag in ((0,1,2) if timeline=="archive" else (0,1)):
            state = original; increments=[np.zeros_like(arr) for arr in original]
            integrated=np.zeros(len(RADII)*5+(len(cuts)+1 if shells else 0)); initial=readout(source(state,flag),0)
            for tick in range(steps):
                guard()
                now=tick*dt; temp=[]
                for fraction, previous in ((0,None),(.5,0),(.5,1),(1,2)):
                    state=tuple(base+(inc if previous is None else inc+fraction*dt*temp[previous][0][index])
                                for index,(base,inc) in enumerate(zip(original,increments)))
                    rates=deriv(state,now+fraction*dt,flag)
                    temp.append((rates, terms(source(state,flag),source(rates,flag),now+fraction*dt)))
                for index,increment in enumerate(increments):
                    increment+=dt*(temp[0][0][index]+2*temp[1][0][index]+2*temp[2][0][index]+temp[3][0][index])/6
                integrated+=dt*(temp[0][1]+2*temp[1][1]+2*temp[2][1]+temp[3][1])/6
            final=readout(source(tuple(a+b for a,b in zip(original,increments)),flag),end)
            per_channel.append((initial,final,integrated))
        for name,(initial,final,raw) in zip(("on","off","ondiff"),per_channel):
            amounts=raw[:len(RADII)*5].reshape(len(RADII),5)
            if shells:
                assert abs(raw[len(RADII)*5:].sum()/amounts[1,2]-1)<2e-9
                for lower,upper,amount in zip((RADII[1],*cuts),(*cuts,120.),raw[len(RADII)*5:]):
                    shell_results.append(dict(model=model,grid=rate,history=timeline,steps=steps,seed=seed,channel=name,
                        lower_at_launch=lower,upper=upper,integral=amount))
            for index,radius in enumerate(RADII):
                results.append(dict(model=model,grid=rate,history=timeline,steps=steps,seed=seed,radius=radius,channel=name,
                    log_elapsed=end,launch=initial[index],final=final[index],endpoint_change=final[index]-initial[index],
                    source_local=amounts[index,0],source_inner=amounts[index,1],source_exterior=amounts[index,2],
                    dilution=amounts[index,3],ruler=amounts[index,4],rate_integral=amounts[index].sum()))
        print(model,rate,timeline,steps,seed,flush=True)
    output(f"{model}-h{rate}-{timeline}-n{steps}.csv",results)
    if shells:output(f"exterior-h{rate}-{timeline}-n{steps}.csv",shell_results)

if __name__=="__main__":
    advance(sys.argv[1],int(sys.argv[2]),sys.argv[3],int(sys.argv[4]),shells="--shells" in sys.argv[5:])
