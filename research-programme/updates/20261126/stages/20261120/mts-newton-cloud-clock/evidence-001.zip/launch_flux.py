"""Full 120 Mpc instantaneous rest-current projection of the signed CMC data."""
from clock_tide import *
for name in ("states.py","pressure.py","normal_graph.py","coupled_readout.py"):
    checked(NORMAL,name)
sys.path.insert(0,str(NORMAL))
from coupled_readout import pressure,homogeneous,input_pack,Slice,normal_data,Sources,change_norm,jet,angular

def currents(sim,rate,flag,seed):
    ref,press,_=pressure(flag)
    state,grid,samples,supply=input_pack(sim,rate,seed,flag,ref,press)
    obj=Slice(sim,grid,ref,samples,state,flag,not flag,"fixed",0,"matched")
    delta=np.zeros_like(grid.points,dtype=complex)
    if not flag:
        mean=homogeneous(ref,ref["rh"][sim.patch.j],ref["a"]*sim.patch.p.mass,press)
        graph,fields=normal_data(obj,supply,mean)
        for iteration in range(8):
            lift=Sources(grid,fields,samples[0]["other"])
            obj=Slice(sim,grid,{**ref,"H":mean["hubble"]},samples,state,flag,True,"fixed",0,"matched",lift)
            new_graph,next_fields=normal_data(obj,supply,mean,graph)
            if change_norm(fields,next_fields)<2e-9:break
            graph,fields=new_graph,next_fields
        else:raise RuntimeError("unsettled")
        delta=graph[0]
    chi=jet(grid.evaluate(obj.f0)[0],grid.evaluate(obj.f2)[0])
    number=jet(obj.m["n"],obj.m["D"])
    speed=jet(obj.m["p"],obj.m["P"])
    with np.load(checked(CLOUD,f"launch-h{rate}-off{flag}-seed{seed}.npz")) as pkt:
        count=len(pkt["r"])
        np.testing.assert_array_equal(np.stack([grid.evaluate(arr)[0] for arr in (obj.f0,obj.f2)])[:,:count],pkt["chi"])
        np.testing.assert_array_equal(np.stack((delta.real,angular(delta)))[:,:count],pkt["delta"])
        np.testing.assert_array_equal(obj.m["n"][:,:count],pkt["n"][:,0])
        np.testing.assert_array_equal(obj.m["P"][:,:count],pkt["slope"][:,1])
    logg=-4*np.log1p(chi)
    loggamma=.5*np.log1p(np.exp(logg)*speed**2)
    if not flag:loggamma[-1]=np.log1p(delta)
    excess=np.expm1(logg-loggamma)
    radial=angular(number*speed*excess)
    tangential=number.real*obj.m["Pt"]*excess.real
    return grid, ref["rh"][:,None,None,None]*np.stack((radial,tangential),axis=1),excess,speed,obj.m["Pt"]

class Projection:
    def __init__(self,grid,order):
        self.grid=grid
        self.basis=np.linalg.inv(legvander(2*grid.t-1,len(grid.t)-1))
        self.nodes,self.weights=leggauss(order)
    def value(self,data,radius,side="right",der=False):
        grid=self.grid
        index=min(int(radius/grid.h),grid.ne-1)
        if side=="left":index=min(int(np.ceil(radius/grid.h))-1,grid.ne-1)
        basis=legder(self.basis)*2/grid.h if der else self.basis
        return data[...,index,:]@legval(2*(radius/grid.h-index)-1,basis)
    def integral(self,data,lower,upper,power):
        grid=self.grid
        nodes=np.arange(grid.ne+1)*grid.h
        edges=np.r_[lower,nodes[(nodes>lower+1e-13)&(nodes<upper-1e-13)],upper]
        mid=(edges[1:]+edges[:-1])/2;half=np.diff(edges)/2
        index=(mid/grid.h).astype(int)
        points=mid[:,None]+half[:,None]*self.nodes
        basis=legvander(2*(points/grid.h-index[:,None])-1,len(grid.t)-1)@self.basis
        return np.einsum("...ej,ekj,ek->...",data[...,index,:],basis,points**power*self.weights*half[:,None])
    def apply(self,flux,radius,edge):
        radial,tangent=flux
        fr=self.value(radial,radius);ft=self.value(tangent,radius)
        loc=(self.value(radial,radius,der=True)+(2*fr-6*ft)/radius)/3
        inner=-radius**4*fr+self.integral(2*radial+6*tangent,0,radius,3)
        wall=-self.value(radial,edge,"left")/edge
        outer=fr/radius+wall+self.integral(-3*radial+6*tangent,radius,edge,-2)
        return np.array((loc,1.2*inner/radius**5,.2*outer,.2*wall))

def main(rate):
    sim=BalancedNative("heavy",120,rate*120,False,"native36",START)
    packets={};diagnostics=[]
    for flag in (0,1):
        for seed in (0,1,-1):
            grid,flux,excess,speed,tangential=currents(sim,rate,flag,seed)
            packets[flag,seed]=flux
            read=Projection(grid,18)
            for radius in RADII:
                for species in range(len(flux)):
                    term1=read.value(excess[species].real,radius,der=True)*read.value(tangential[species],radius)
                    term2=read.value(angular(excess[species]),radius)*read.value(speed[species].real,radius)/radius
                    diagnostics.append(dict(grid=rate,flag=flag,seed=seed,radius=radius,species=species,
                        radial_factor_gradient=term1,angular_factor_gradient=term2,flat_curl=term1-term2))
            print("mapped",rate,flag,seed,flush=True)
    rows=[]
    for seed in (1,-1):
        change=(packets[0,seed]-packets[0,0])-(packets[1,seed]-packets[1,0])
        for order in (10,18):
            read=Projection(grid,order)
            for radius in RADII:
                for edge in (8,16,36,72,120):
                    for species,flux in enumerate(change):
                        loc,inner,outer,wall=read.apply(flux,radius,edge)
                        rows.append(dict(grid=rate,seed=seed,order=order,radius=radius,edge=edge,species=species,
                            local=loc,inner=inner,outer=outer,wall_in_outer=wall,rate=loc+inner+outer,
                            launch_rate_times_duration=(loc+inner+outer)*DURATION))
    output(f"actual-current-h{rate}.csv",rows)
    output(f"flat-curl-h{rate}.csv",diagnostics)

if __name__=="__main__":main(int(sys.argv[1]))
