from compare import *

def main():
    gr=read(checked(CLOUD,"evolution-balance.csv"))
    endpoint=read(checked(CLOUD,"constraint-transport.csv"))
    records=[]; zones=[]
    for density,project in ((80,0),(80,1),(120,1)):
        if density==80:
            direct=read(HOME/f"constraint-rate-n80-t192-p{project}.csv")
        else:
            direct=read(HOME/"subsidiary-n120-t192-p1.csv")
        for row in direct:
            if row["stride"]!="1":continue
            conditions=dict(parent="5",steps="192",rate=str(density),project=str(project),seed=row["seed"],radius=row["radius"])
            select=lambda item:all(item[key]==value for key,value in conditions.items())
            rates={item["method"]:float(item["integrated_tide_change"]) for item in gr if select(item) and item["environment"]=="conserved" and item["rule"]=="full"}
            old={item["cycles"]:float(item["host_switch"]) for item in endpoint if select(item) and item["field"]=="ham"}
            assert set(rates)=={"gauss","ricci"} and set(old)=={"0.0","2.0"}
            measured=rates["gauss"]-rates["ricci"]
            independent=float(row.get("delta_ham_over_six",row.get("direct")))
            relative=independent/measured-1
            records.append(dict(**conditions,curvature_split=measured,direct_hamiltonian=independent,error_on_split=relative,
                on_total_integral=(independent-measured)/rates["gauss"],pass_20ppm_on_split=abs(relative)<2e-5,
                raw_endpoint_estimate=(old["2.0"]-old["0.0"])/6))
    for rate,steps in ((4,4),(5,8)):
        table=read(HOME/f"exterior-h{rate}-normal-n{steps}.csv")
        for seed in ("1","-1"):
            branches={(row["upper"],row["channel"]):float(row["integral"]) for row in table if row["seed"]==seed}
            targets=groups(f"heavy-h{rate}-normal-n{steps}.csv")
            original=subtract(targets,int(seed),RADII[1],"source_exterior")
            total=subtract(targets,int(seed),RADII[1],"rate_integral")
            shares=[]
            for row in table:
                if row["seed"]!=seed or row["channel"]!="on":continue
                value=branches[row["upper"],"on"]-branches[row["upper"],"off"]
                zones.append(dict(grid=rate,seed=seed,lower_at_launch=row["lower_at_launch"],upper=row["upper"],
                    source=value,on_exterior=value/original,on_total=value/total))
                shares.append(value)
            assert len(shares)==7 and abs(sum(shares)/original-1)<2e-5
    output("constraint-diagnosis.csv",records)
    output("signed-shells.csv",zones)
if __name__=="__main__":main()
