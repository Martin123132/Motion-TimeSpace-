"""Differentiate the scalar Hamiltonian defect directly, before subtracting the large endpoint curvatures."""
from clock_tide import *
for name in ("cloud_owner.py","incident.py","cloud_evolve.py","polar_cloud.py","surroundings.py","graph_response.py","tide_rate.py"):
    checked(CLOUD,name)
sys.path.insert(0,str(CLOUD))
from surroundings import Conserved
from cloud_owner import pair, mul, exp, square
from graph_response import ruler_variation
from scipy.integrate import simpson

def spatial(shell,geo):
    ell,bend,tilt,tensor=geo[:4]
    radius=shell.r
    first=shell.diff(ell)
    height=2*shell.diff(bend);height[1]+=6*tilt[1]/radius
    gradient=2*shell.diff(bend,2);gradient[1]+=6*(shell.diff(tilt)[1]-tilt[1]/radius)/radius
    warp=np.exp(-2*ell[0]);angular=np.exp(-2*bend[0])
    wall=pair(2*warp*np.expm1(2*(ell[0]-bend[0])),
              angular*(8*bend[1]+12*tensor[1]+12*ell[1])+4*warp*ell[1])/radius**2
    return wall + mul(exp(-2*ell),-2*gradient+4*first/radius+2*mul(first,height)-6*height/radius-1.5*square(height))

def measure(shell,state,rates,raw=False):
    scale=1.e-19
    tangent=lambda index:state[index].real+1j*scale*rates[index].real
    geo=[tangent(index) for index in range(8)]
    trace,shear=geo[4:6]
    inverse=exp(-geo[0]);vol=exp(-geo[0]-2*geo[1]);energy=tangent(17)
    unit=pair(np.ones_like(shell.r))
    for spec in range(3 if shell.flag else 2):
        number,phase=tangent(8+spec*2),tangent(9+spec*2)
        squared=square(mul(inverse,shell.diff(phase)))
        root=np.sqrt(1+squared[0]);gamma=pair(root,squared[1]/(2*root))
        energy+=shell.rho[spec]*mul(number,mul(vol,gamma))
    if not shell.flag:
        def imag(index):return state[index].imag+1j*scale*rates[index].imag
        lin=tangent(14);phase=imag(14)
        amp=exp(2*lin);moment=tangent(15)+trace/(2*shell.mu)
        gradient=mul(square(inverse),square(shell.diff(lin))+square(shell.diff(phase)))/shell.mu**2
        energy+=shell.rho[-1]*mul(amp,unit+square(moment)+square(imag(15)-unit)+gradient)/2
    ham=spatial(shell,geo)+2/3*square(trace)-1.5*square(shear)-2*energy
    if raw:return ham.real,ham.imag/scale
    read=ruler_variation(shell,state[:14].real,rates[:14].real,ham.real,ham.imag/scale)
    return np.array([row[-1] for row in read])/6

def main(res,steps,project):
    all_rates={}
    for flag in (0,1):
        for seed in (0,1,-1):
            with np.load(checked(CLOUD,f"launch-h5-off{flag}-seed{seed}.npz")) as launch:shell=Conserved(launch,res,6,flag,project)
            start=shell.initial;change=np.zeros_like(start)
            step=DURATION/(2*steps);values=[]
            for tick in range(2*steps+1):
                time=step*tick;state=start+change
                first=shell.dynamics(time,state)
                if tick%(steps//16)==0:
                    guard()
                    values.append(measure(shell,state,first))
                if tick==2*steps:break
                second=shell.dynamics(time+step/2,start+(change+step*first/2))
                third=shell.dynamics(time+step/2,start+(change+step*second/2))
                fourth=shell.dynamics(time+step,start+(change+step*third))
                change+=step*(first+2*second+2*third+fourth)/6
            all_rates[flag,seed]=np.array(values)
            print("constraint rate",res,steps,project,flag,seed,flush=True)
    rows=[]
    for seed in (1,-1):
        diff=(all_rates[0,seed]-all_rates[0,0])-(all_rates[1,seed]-all_rates[1,0])
        for stride in (1,2):
            val=simpson(diff[::stride],dx=DURATION/32*stride,axis=0)
            for index,radius in enumerate(RADII):
                rows.append(dict(grid=res,steps=steps,project=project,seed=seed,radius=radius,stride=stride,
                    start_rate=diff[0,index],end_rate=diff[-1,index],delta_ham_over_six=val[index]))
    output(f"constraint-rate-n{res}-t{steps}-p{project}.csv",rows)
if __name__=="__main__":main(*map(int, sys.argv[1:]))
