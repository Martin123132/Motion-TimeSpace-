"""Compare source-resolved evolution, keeping every previously tested curvature readout."""
from clock_tide import *

def read(path):
    with path.open(newline="") as stream:return list(csv.DictReader(stream))

def groups(name):
    rows=read(HOME/name)
    return {(int(row["seed"]),float(row["radius"]),row["channel"]): row for row in rows}

def subtract(data,seed,radius,field):
    return float(data[seed,radius,"on"][field])-float(data[seed,radius,"off"][field])

def main():
    gr=read(checked(CLOUD,"evolution-balance.csv"))
    launch=read(checked(SLICES,"proper-distance-comparison.csv"))
    results=[]; differences=[]; gates=[]; maps=[]
    fields=("launch","endpoint_change","rate_integral","source_local","source_inner","source_exterior","dilution","ruler")
    for model in ("heavy","cold"):
        for rate in (4,5):
            for convention in ("archive","longitudinal","normal"):
                base=groups(f"{model}-h{rate}-{convention}-n4.csv")
                high=groups(f"{model}-h5-{convention}-n8.csv") if model=="heavy" and rate==5 else None
                for seed in (1,-1):
                    for radius in RADII:
                        diff={key:subtract(base,seed,radius,key) for key in fields}
                        for channel in ("on","off"):
                            rr=base[seed,radius,channel]
                            assert abs(float(rr["endpoint_change"])/float(rr["rate_integral"])-1)<2e-5
                        original=next(row for row in launch if row["config"]=="reference" and (row["model"],int(row["rate"]),int(row["seed"]),float(row["radius"]))==(model,rate,seed,radius))
                        if model=="cold":
                            assert all(val==0 for val in diff.values()) and not float(original["newton"])
                            if convention=="archive":
                                assert float(base[seed,radius,"ondiff"]["rate_integral"])==0
                        else:
                            assert abs(diff["launch"]/float(original["newton"])-1)<2e-5
                            gates.append(dict(grid=rate,history=convention,seed=seed,radius=radius,
                                endpoint_rel=diff["endpoint_change"]/diff["rate_integral"]-1,
                                budget_rel=sum(diff[key] for key in fields[3:])/diff["rate_integral"]-1,
                                doubled_steps_rel=(subtract(high,seed,radius,"rate_integral")/diff["rate_integral"]-1 if high else ""),
                                direct_difference_rel=(float(base[seed,radius,"ondiff"]["rate_integral"])/diff["rate_integral"]-1 if convention=="archive" else "")))
                        results.append(dict(model=model,grid=rate,history=convention,seed=seed,radius=radius,**diff))
                        if model!="heavy":continue
                        for row in gr:
                            if row["rule"]!="full" or (int(row["seed"]),float(row["radius"]),int(row["parent"]))!=(seed,radius,rate):continue
                            measured=float(row["integrated_tide_change"])
                            differences.append(dict(history=convention,parent=rate,seed=seed,radius=radius,environment=row["environment"],
                                gr_rate=row["rate"],gr_steps=row["steps"],project=row["project"],method=row["method"],newton=diff["rate_integral"],gr=measured,
                                residual=measured-diff["rate_integral"],relative=measured/diff["rate_integral"]-1))
    for rate in (4,5):
        current=read(HOME/f"actual-current-h{rate}.csv")
        for edge in (8,16,36,72,120):
            for seed in (1,-1):
                for radius in RADII:
                    sel=[row for row in current if (int(row["seed"]),float(row["radius"]),int(row["edge"]))==(seed,radius,edge)]
                    scaled=[sum(float(row["launch_rate_times_duration"]) for row in sel if int(row["order"])==order) for order in (10,18)]
                    assert len(sel)==6 and abs(scaled[0]/scaled[1]-1)<2e-5
                    newton=next(row["rate_integral"] for row in results if (row["model"],row["grid"],row["history"],row["seed"],row["radius"])==("heavy",rate,"normal",seed,radius))
                    maps.append(dict(grid=rate,seed=seed,radius=radius,edge=edge,projected_rate_times_duration=scaled[1],relative_to_increment=scaled[1]/newton,
                                     quadrature_rel=scaled[0]/scaled[1]-1))
    assert all(abs(float(val))<2e-5 for row in gates for key,val in row.items() if key.endswith("_rel") and val!="")
    output("signed-increments.csv",results)
    output("paired-curvatures.csv",differences)
    output("integration-checks.csv",gates)
    output("matched-current-projection.csv",maps)
    for seed in (1,-1):
        rad=RADII[1]
        filtered=[row for row in differences if (row["seed"],row["radius"],row["history"],row["parent"],row["environment"])==(seed,rad,"normal",5,"conserved")]
        center=next(row for row in filtered if (row["method"],row["gr_rate"],row["gr_steps"],row["project"])==("gauss","80","192","1"))
        subset=[row["relative"]*1e6 for row in filtered if row["project"]=="1"]
        print(seed,center["newton"],center["gr"],center["relative"]*1e6,"ppm; constrained range",min(subset),max(subset),
              "all",min(row["relative"]*1e6 for row in filtered),max(row["relative"]*1e6 for row in filtered))
if __name__=="__main__":main()
