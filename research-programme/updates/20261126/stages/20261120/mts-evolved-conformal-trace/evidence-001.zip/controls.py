"""An expanding inhomogeneous exact dust spacetime in quadrupole-deformed coordinates."""
from readout import *
from types import SimpleNamespace
import sympy as sy


def run():
    rr,time=sy.symbols("r time",positive=True)
    label=rr**3/sy.Integer(2000)
    mass=2*rr**3/9
    areal=rr*(8+time+rr**2/300)**sy.Rational(2,3)
    slope=areal.diff(rr)
    radial=-slope.diff(time)/slope
    transverse=-areal.diff(time)/areal
    trace=radial+2*transverse
    shear=radial-trace/3
    energy=2*mass.diff(rr)/(areal**2*slope)
    ell=sy.log(slope)
    bend=sy.log(areal/rr)
    e2=label*slope.diff(rr)/slope+label.diff(rr)
    b2=label*slope/areal
    vals=((ell/6+bend/3,e2/6+b2/3),(ell-bend,e2-b2),(0,rr*slope**2*label/areal**2),
          (0,0),(trace,trace.diff(rr)*label),(shear,shear.diff(rr)*label),(energy,energy.diff(rr)*label))
    expr=[]
    for degree in (0,1,2):
        for base,harm in vals:
            expr.extend([sy.diff(sy.sympify(field),rr,degree) for field in (base,harm)])
    evaluate=sy.lambdify((rr,time),expr,"numpy",cse=True)
    shell=SimpleNamespace(r=np.arange(400)/40+3.,left=3.,dx=1/40,flag=1,rho=np.zeros(3),mu=1.)
    gate=Samples(shell,6.,9.,6)
    def parameters(now):
        arrays=np.array([np.broadcast_to(raw,gate.points.shape) for raw in evaluate(gate.points,now)]).reshape(3,7,2,-1)
        data=np.zeros((3,17,2,len(gate.points)))
        data[:,:7]=arrays
        return list(data)
    controls=[]
    def check(label,measured,expected,tol):
        ratio=abs(measured-expected)/max(abs(expected),1e-30)
        assert ratio<tol,(label,ratio)
        controls.append(dict(test=label,measured=float(measured),expected=float(expected),relative=float(ratio),tolerance=tol))
    first,last=parameters(0.),parameters(.7)
    start,finish=gate.apply(first),gate.apply(last)
    for label,vec in (("launch",start),("evolved",finish),("time difference",finish-start)):
        rhs=fsum(vec[:5]);metric=vec[6]-vec[5]
        check("LTB strong "+label,rhs,metric,5e-10)
        check("LTB weak "+label,rhs,vec[8]-vec[7],5e-10)
    shift=[b-a for a,b in zip(first,last)]
    pts,wts=leggauss(8)
    integration=sum(wt*gate.apply([a+((pt+1)/2+1e-20j)*dx for a,dx in zip(first,shift)]).imag/2e-20 for pt,wt in zip(pts,wts))
    check("directional derivative source sum",fsum(integration[:5]),fsum((finish-start)[:5]),2e-10)
    for power in (2,-3,4):
        rad=gate.points
        parts=[np.zeros_like(val) for val in first]
        parts[0][0,1]=rad**float(power)
        parts[1][0,1]=power*rad**float(power-1)
        parts[2][0,1]=power*(power-1)*rad**float(power-2)
        parts[0][6,1]=-4*(power*(power+1)-6)*rad**float(power-2)
        physical=gate.apply(parts)
        expected=(power+3)*gate.high**(power-2)
        if expected:check("solid harmonic trace r^"+str(power),physical[6],-.8*expected,2e-14)
        else:assert max(abs(physical[5:7]))<1e-17
        assert abs(physical[6]-physical[5]-sum(physical[:5]))<1e-10
    table("exact-controls.csv",controls)
    print("exact fixtures",max(row["relative"] for row in controls))


if __name__=="__main__":run()
