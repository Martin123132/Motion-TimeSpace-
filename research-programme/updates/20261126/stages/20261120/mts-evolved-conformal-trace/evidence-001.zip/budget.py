"""Keep source projections, coordinate traces and preparation sensitivity separate."""
from tidal_compare import evaluate
from compare import analyze, selections, NORMS, HERE, checked, read, table


CASES = (
    ("continued80", 80, 32, 4, 7), ("continued160", 160, 32, 4, 7),
    ("continued320", 320, 32, 4, 7), ("continued640", 640, 32, 4, 7),
    ("time320", 320, 32, 9, 7), ("wall320", 320, 32, 4, 8),
    ("q16res160", 160, 16, 4, 7), ("q16res320", 320, 16, 4, 7))


def run():
    source = {(int(row["seed"]), float(row["width"]), float(row["fraction"])):float(row["newton"])
              for row in read(checked("exterior-bound.csv")) if row["case"] == "preferred"}
    launch = {(int(row["q"]), int(row["seed"]), float(row["fraction"])): float(row["expected"])
              for row in read(HERE/"raychaudhuri-frozen-predictions.csv") if float(row["radius"]) == 120.}
    results = []
    for name, grid, level, steps, padding in CASES:
        sections = selections(160, 40, level, 4, 5)[:-1]+[(grid, level, steps, padding, 119., 120.)]
        geometry = analyze(name, sections, 1)
        tides = evaluate(name, sections)
        for metric, tide in zip(geometry, tides, strict=True):
            key = tuple(metric[col] for col in ("seed", "width", "fraction"))
            assert key == tuple(tide[col] for col in ("seed", "width", "fraction"))
            unit = abs(NORMS[key])*1e-6
            results.append(dict(case=name, seed=key[0], width=key[1], fraction=key[2],
                far_ppm=metric["boundary_outer_ppm"], far_forecast_error_ppm=metric["boundary_outer_ppm"]-launch[level,key[0],key[2]]/unit,
                trace_weak_gap_ppm=metric["weak_minus_source_ppm"], trace_strong_gap_ppm=metric["surface_minus_source_ppm"],
                physical_tide_ppm=tide["predicted"]/unit, physical_energy_error_ppm=tide["residual_ppm"],
                physical_newton_error_ppm=(tide["predicted"]-source[key])/unit, physical_join_ppm=tide["join_ppm"]))
    table("refined-budget.csv", results)
    for name,*_ in CASES:
        rows=[row for row in results if row["case"]==name]
        print(name,*(round(max(abs(row[field]) for row in rows),4) for field in
            ("far_forecast_error_ppm","trace_weak_gap_ppm","trace_strong_gap_ppm","physical_energy_error_ppm","physical_newton_error_ppm","physical_join_ppm")))
        row=next(row for row in rows if (row["seed"],row["width"],row["fraction"])==(1,.15,1.))
        print("positive final boundary",row["far_ppm"])


if __name__ == "__main__":
    run()
