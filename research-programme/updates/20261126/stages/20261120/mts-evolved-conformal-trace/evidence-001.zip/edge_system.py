"""Evaluate the original full-domain initial data only on the last two Mpc."""
from trace_campaign import *
from scipy.interpolate import BarycentricInterpolator
from incident import Incident
from surroundings import LocalSource
from states import native,response


def local(grid,level,flag,seed,padding):
    from balance import pair,mul,exp
    assert padding in (5,6)
    left=118.
    radius=(np.arange(round(left*grid),120*grid)+.5)/grid
    obj=object.__new__(collar.ContinuedEnd if padding==6 else collar.Annulus)
    obj.mu=0.
    obj.dx=1/grid;obj.r=radius;obj.left=left
    obj.flag=flag;obj.project=1;obj.method="stagger";obj.order=6
    eta=1/np.sqrt(level)
    def interpolation(packet):
        cell=(radius/float(packet["h"])).astype(int)
        point=radius/float(packet["h"])-cell
        basis=BarycentricInterpolator(packet["t"],np.eye(len(packet["t"])),rng=0)(point)
        def at(raw,anchored=True):
            selected=raw[...,cell,:]
            if not anchored:return np.einsum("...ij,ij->...i",selected,basis)
            origin=selected[...,:1]
            return origin[...,0]+np.einsum("...ij,ij->...i",selected-origin,basis)
        return at
    with np.load(checked(f"full-q1-off{flag}-s{seed}.npz")) as p:
        at=interpolation(p)
        bank=Incident(p,radius,flag,lambda raw:at(raw,False))
    with np.load(checked(f"full-q{level}-off{flag}-s{seed}.npz")) as packet:
        at=interpolation(packet)
        obj.rho=packet["rho"];obj.mu=float(packet["mu"])
        init=np.zeros((20,2,len(radius)),complex)
        addlog=lambda data:pair(np.log1p(data[0]),data[1]/(1+data[0]))
        logu=addlog(at(packet["chi"]))
        init[0]=init[1]=2*logu
        init[4,0]=-3*float(packet["H"])
        init[5]=mul(at(packet["b"]),exp(-6*logu))
        init[6,1]=at(packet["c"])*np.exp(-6*logu[0])
        init[7,1]=at(packet["d"])*np.exp(-6*logu[0])
        for idx in range(3):
            init[8+2*idx]=at(packet["n"][idx])
            init[9+2*idx]=at(packet["v"][idx])
        delta=at(packet["delta"])
        init[14]=(addlog(init[12].real-pair(np.ones_like(radius)))-addlog(delta))/2-3*logu+1j*obj.mu*init[13]
        init[15]=at(packet["drift"])-init[4]/(2*obj.mu)-1j*delta
        obj.incident=LocalSource(collar.family.ScaledBank(bank,eta))
        obs=bank.at(0.)
        init[17]=eta**2*pair(obs[0],obs[2])
        bg=native("heavy",flag)
        vol_to_frame=np.exp(-4*init[0,0].real)
        init[18,1]=eta**3*(vol_to_frame*response(bg,radius,1)("j_other"))
        init[19,1]=eta**3*(vol_to_frame*response(bg,radius)("j_other")/radius)
        obj.initial=init
    return obj


def check():
    rows=[]
    for seed in (0,1,-1):
        for flag in (0,1):
            old=collar.system(40,32,flag,seed,6)
            new=local(40,32,flag,seed,6)
            np.testing.assert_array_equal(new.r,old.r)
            np.testing.assert_allclose(new.initial,old.initial,rtol=5e-13,atol=2e-32)
            time=DURATION*.417*np.sqrt(32)
            np.testing.assert_allclose(new.incident.bank.at(time),old.incident.bank.at(time),rtol=1e-12,atol=1e-30)
            err=np.max(abs(old.dynamics(time,old.initial)-new.dynamics(time,new.initial)))
            rows.append(dict(seed=seed,flag=flag,initial=np.max(abs(new.initial-old.initial)),rhs=err))
    table("local-constructor-check.csv",rows)


if __name__=="__main__":check()
