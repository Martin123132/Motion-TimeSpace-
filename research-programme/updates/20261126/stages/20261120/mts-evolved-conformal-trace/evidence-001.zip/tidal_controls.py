"""Independent spherical spacetime, non-comoving momentum and curvature controls."""
from tidal import *
from types import SimpleNamespace
import sympy as sy


def run():
    rr,time=sy.symbols("r t",positive=True)
    mass=2*rr**3/9
    areal=rr*(8+time+rr**2/300)**sy.Rational(2,3)
    slope=areal.diff(rr)
    kr=-slope.diff(time)/slope
    kt=-areal.diff(time)/areal
    trace=kr+2*kt
    shear=kr-trace/3
    energy=2*mass.diff(rr)/(areal**2*slope)
    xi=rr**3/2000
    ell=sy.log(slope)
    bend=sy.log(areal/rr)
    ell2=xi*slope.diff(rr)/slope+xi.diff(rr)
    bend2=xi*slope/areal
    active={0:((ell+2*bend)/6,(ell2+2*bend2)/6),1:(ell-bend,ell2-bend2),
            2:(0,rr*slope**2*xi/areal**2),4:(trace,xi*trace.diff(rr)),5:(shear,xi*shear.diff(rr)),
            6:(energy,xi*energy.diff(rr)),17:(0,(kr-kt)*slope*xi/areal)}
    shell=SimpleNamespace(r=np.arange(400)/40+3.,left=3.,dx=1/40,flag=1,rho=np.zeros(3),mu=1.)
    gate=WeakTide(shell,6.,9.,6)
    def panel(active,t):
        fields=list(active)
        expression=[sy.diff(sy.sympify(term),rr,degree) for degree in range(3) for name in fields for term in active[name]]
        routine=sy.lambdify((rr,time),expression,"numpy",cse=True)
        arr=np.array([np.broadcast_to(raw,gate.points.shape) for raw in routine(gate.points,t)]).reshape(3,len(fields),2,-1)
        full=np.zeros((3,20,2,len(gate.points)))
        for idx,name in enumerate(fields):full[:,name]=arr[:,idx]
        return gate.apply(full)
    tests=[]
    def check(tag,values,scale=None):
        obs=fsum(values[:-1]);ref=values[-1]
        error=abs(obs-ref)/(abs(ref) if scale is None else scale)
        assert error<1e-9,(tag,error)
        tests.append(dict(test=tag,metric_current=obs,density=ref,denominator=abs(ref) if scale is None else scale,relative=error))
    first=panel(active,0.)
    end=panel(active,.7)
    check("inhomogeneous dust",first)
    check("evolved dust",end)
    assert abs(end[-1]-first[-1])<1e-12*abs(first[-1])
    check("conserved comoving dust null change",end-first,abs(first[-1]))
    kval=sy.Rational(3,10);harm=rr**3/300
    active={4:(kval,harm),6:(kval**2/3,2*kval*harm/3),19:(0,-2*harm/(3*rr))}
    check("normal current",panel(active,0))
    profile=rr**4/3000
    active={0:(0,profile),6:(0,-4*(profile.diff(rr,2)+2*profile.diff(rr)/rr-6*profile/rr**2))}
    check("potential tidal curvature",panel(active,0))
    table("tidal-exact.csv",tests)
    print("exact weak tide:",max(row["relative"] for row in tests))


if __name__=="__main__":run()
