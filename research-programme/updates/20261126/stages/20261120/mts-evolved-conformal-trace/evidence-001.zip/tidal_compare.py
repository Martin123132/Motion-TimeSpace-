from compare import *
from tidal import LABELS
from functools import lru_cache


@lru_cache(maxsize=None)
def dataset(grid,qnum,res,pad,fine):
    rows=[]
    for flag in (0,1):
        for host in (0,1,-1):
            stem=tag(grid,qnum,res,pad,flag,host)
            rows+=read(HERE/f"tidal-{stem}-fine{fine}.csv")
    return {(int(row["flag"]),int(row["seed"]),float(row["lower"]),float(row["upper"]),float(row["fraction"])):row for row in rows}


def evaluate(name,sections,save=True,fine=1):
    pieces=[];total=[]
    for seed in (-1,1):
        for frac in (.25,.5,.75,1.):
            values=[]
            for grid,level,res,pad,lo,hi in sections:
                data=dataset(grid,level,res,pad,fine)
                vals={col:signed(data,seed,lo,hi,frac,col) for col in LABELS}
                vals["predicted"]=fsum(vals[c] for c in LABELS[:-1])
                vals["gap"]=vals["predicted"]-vals["energy"]
                pieces.append(dict(case=name,seed=seed,fraction=frac,lower=lo,upper=hi,**vals))
                values.append(vals)
            for width in (.15,.30):
                norm=NORMS[seed,width,frac]
                den=abs(norm)*1e-6
                vals={col:fsum(v[col] for v in values) for col in LABELS}
                join=fsum(values[idx][pre+"_face_high"]+values[idx+1][pre+"_face_low"] for idx in range(len(values)-1) for pre in ("ricci","extrinsic"))
                predicted=fsum(vals[col] for col in LABELS[:-1])-join
                total.append(dict(case=name,seed=seed,fraction=frac,width=width,full_tide=norm,energy=vals["energy"],predicted=predicted,
                                  residual_ppm=(predicted-vals["energy"])/den,join_ppm=join/den,
                                  absolute_local_ppm=sum(abs(v["gap"]) for v in values)/den,
                                  **{col+"_ppm":vals[col]/den for col in LABELS}))
    if save:
        table(f"electric-pieces-{name}-fine{fine}.csv",pieces)
        table(f"electric-total-{name}-fine{fine}.csv",total)
    return total


if __name__=="__main__":
    for name,conf in (("primary",(160,40,32,4,6)),("lower-q",(160,40,16,4,6)),("wall",(160,40,32,4,5)),
                      ("coarse",(120,20,32,4,6))):
        rows=evaluate(name,selections(*conf))
        print(name,"max electric gap (ppm):",max(abs(row["residual_ppm"]) for row in rows))
