if __name__=="__main__":
    import sys
    from trace_campaign import run
    run(*map(int,sys.argv[1:]))
