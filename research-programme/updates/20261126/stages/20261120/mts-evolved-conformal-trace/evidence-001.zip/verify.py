"""Verify finite tests and all file digests, without treating an open physics gate as a pass."""
import itertools
import re
from trace_campaign import HERE, LAST, sha, read, keep, json, registry, checked, np, sys, guard, table


def check():
    guard()
    for name in registry:
        checked(name)
    configs = ((120,32,4,3),(160,16,4,3),(160,32,4,3),(20,32,4,5),(20,32,4,6),
               (40,16,4,5),(40,16,4,6),(40,32,4,5),(40,32,4,6),(80,32,4,7),(160,32,4,7),
               (320,32,4,7),(640,32,4,7),(320,32,9,7),(320,32,4,8),(160,16,4,7),(320,16,4,7))
    stems = {f"n{grid}-q{level}-t{steps}-p{pad}-off{flag}-s{seed}"
             for grid,level,steps,pad in configs for flag,seed in itertools.product((0,1),(-1,0,1))}
    assert {path.stem for path in HERE.glob("*.npz")} == stems
    for stem in stems:
        with np.load(HERE/(stem+".npz"),allow_pickle=False) as packet:
            radius, change = packet["radius"], packet["change"]
            assert np.all(np.diff(radius)>0) and change.shape==(4,22,2,len(radius)) and np.isfinite(change).all()
        for name in ("trace","tidal"):
            data=read(HERE/f"{name}-{stem}-fine1.csv")
            assert {float(row["fraction"]) for row in data}=={.25,.5,.75,1.}
    rows=read(HERE/"refined-budget.csv")
    assert len(rows)==128 and len({(row["case"],row["seed"],row["width"],row["fraction"]) for row in rows})==128
    gates=[]
    def gate(label,maximum,limit,units):
        assert np.isfinite(maximum)
        gates.append(dict(test=label,maximum=maximum,limit=limit,units=units,within_limit=maximum<=limit))
    for case in sorted({row["case"] for row in rows}):
        selection=[row for row in rows if row["case"]==case]
        assert len(selection)==16
        for field in ("far_forecast_error_ppm","trace_weak_gap_ppm","trace_strong_gap_ppm","physical_energy_error_ppm","physical_newton_error_ppm"):
            gate(case+":"+field,max(abs(float(row[field])) for row in selection),20.,"ppm of full changing Newton tide")
    for filename in ("exact-controls.csv","tidal-exact.csv"):
        vals=read(HERE/filename)
        for row in vals:
            gate(row["test"],float(row["relative"]),float(row.get("tolerance",1e-9)),"relative")
    preparation=read(HERE/"formation-h4-controls.csv")
    assert len(preparation)==6*15 and all(float(row["max_abs"])==0 for row in preparation)
    contrast=read(HERE/"formation-grid-contrast.csv")
    assert len(contrast)==112
    for radius in (6.,119.,120.):
        part=[row for row in contrast if float(row["radius"])==radius]
        gate("native formation grid, radius "+str(radius),max(abs(float(row["h4_minus_h5_ppm"])) for row in part),20.,"ppm; narrow aperture")
    table("gate-ledger.csv",gates)
    assert not list(HERE.glob("*.partial"))
    files={p.name:sha(p) for p in sorted(HERE.iterdir()) if p.is_file() and p.name!="seal.json"}
    summary=dict(parent=sha(LAST/"seal.json"),snapshots=len(stems),csv_rows=sum(len(read(HERE/key)) for key in files if key.endswith(".csv")),files=files)
    data=(json.dumps(summary,indent=2,sort_keys=True)+"\n").encode()
    if "--seal" in sys.argv:keep("seal.json",data)
    assert (HERE/"seal.json").read_bytes()==data
    print(len(files),summary["csv_rows"],sha(HERE/"seal.json"))


if __name__=="__main__":
    check()
