from readout import *
from functools import lru_cache

NORMS={(int(row["seed"]),float(row["width"]),float(row["fraction"])):float(row["full_tide"])
       for row in read(checked("exterior-bound.csv")) if row["case"]=="preferred"}


@lru_cache(maxsize=None)
def load_panel(grid,qnum,res,pad,fine):
    records=[]
    for flag in (0,1):
        for host in (0,1,-1):
            name="trace-"+tag(grid,qnum,res,pad,flag,host)+f"-fine{fine}.csv"
            records+=read(HERE/name)
    return {(int(r["flag"]),int(r["seed"]),float(r["lower"]),float(r["upper"]),float(r["fraction"])):r for r in records}


def signed(data,seed,low,high,frac,column):
    return fsum((1 if host else -1)*(1 if not flag else -1)*float(data[flag,host,low,high,frac][column])
                for host in (0,seed) for flag in (0,1))


def analyze(name,sections,fine=0,save=True):
    individual=[];sums=[]
    for seed in (-1,1):
        for frac in (.25,.5,.75,1.):
            pieces=[]
            for grid,level,res,pad,low,high in sections:
                dat=load_panel(grid,level,res,pad,fine)
                vals={key:signed(dat,seed,low,high,frac,key) for key in (*COLS,"clock_part","metric_evolution")}
                vals["metric"]=vals["outer"]-vals["inner"]
                vals["weak_metric"]=vals["weak_outer"]-vals["weak_inner"]
                vals["source"]=fsum(vals[col] for col in TERMS)
                vals["gap"]=vals["metric"]-vals["source"]
                vals["weak_gap"]=vals["weak_metric"]-vals["source"]
                pieces.append(vals)
                individual.append(dict(case=name,fine=fine,seed=seed,fraction=frac,lower=low,upper=high,**vals))
            for width in (.15,.30):
                norm=NORMS[seed,width,frac]
                source=fsum(p["source"] for p in pieces)
                metric=pieces[-1]["outer"]-pieces[0]["inner"]
                weak=pieces[-1]["weak_outer"]-pieces[0]["weak_inner"]
                join=fsum(right["inner"]-left["outer"] for left,right in zip(pieces,pieces[1:]))
                weak_join=fsum(right["weak_inner"]-left["weak_outer"] for left,right in zip(pieces,pieces[1:]))
                denom=abs(norm)*1e-6
                row=dict(case=name,fine=fine,seed=seed,width=width,fraction=frac,denom=norm,metric=metric,weak_metric=weak,
                         source=source,surface_minus_source_ppm=(metric-source)/denom,weak_minus_source_ppm=(weak-source)/denom,
                         join_ppm=join/denom,weak_join_ppm=weak_join/denom,
                         absolute_piece_gaps_ppm=sum(abs(p["gap"]) for p in pieces)/denom,
                         boundary_inner_ppm=pieces[0]["inner"]/denom,boundary_outer_ppm=pieces[-1]["outer"]/denom,
                         **{col+"_ppm":fsum(p[col] for p in pieces)/denom for col in TERMS})
                sums.append(row)
    if save:
        table(f"pieces-{name}-fine{fine}.csv",individual)
        table(f"total-{name}-fine{fine}.csv",sums)
    return sums


def selections(inner,outer,qnum,steps,end):
    return [(inner,qnum,steps,3,6.,15.),*((outer,qnum,steps,5,a,b) for a,b in ((15.,24.),(24.,48.),(48.,72.),(72.,96.),(96.,119.))),
            (outer,qnum,steps,end,119.,120.)]


if __name__=="__main__":
    for name,conf in (("primary",(160,40,32,4,6)),("lower-q",(160,40,16,4,6)),("coarse-wall",(120,20,32,4,5)),
                      ("wall",(160,40,32,4,5))):
        for fine in (0,1):
            rows=analyze(name,selections(*conf),fine)
            print(name,fine,"max direct / weak gaps ppm:",*[max(abs(row[key]) for row in rows) for key in ("surface_minus_source_ppm","weak_minus_source_ppm")])
