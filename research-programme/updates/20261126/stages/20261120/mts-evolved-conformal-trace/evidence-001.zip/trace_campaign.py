"""Record proper-clock increments without modifying the sealed normal-energy stage."""
import csv
import hashlib
import io
import json
import os
import sys
from pathlib import Path

for key in ("OPENBLAS_NUM_THREADS","MKL_NUM_THREADS","OMP_NUM_THREADS","NUMEXPR_NUM_THREADS"):
    os.environ[key]="1"
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
LAST=HERE.parent/"mts-normal-energy-boundary-20261120"


def sha(path):
    with path.open("rb") as stream:return hashlib.file_digest(stream,"sha256").hexdigest()


assert sha(LAST/"seal.json")=="8daeba50e27fc63709c9fa075bb54910a4c43cb904a04f6a34826b02eeb920ea"
registry=json.loads((LAST/"seal.json").read_bytes())["files"]


def checked(name):
    assert sha(LAST/name)==registry[name],name
    return LAST/name


for filename in ("collar.py","balance.py","outer-inputs.csv","exterior-bound.csv","launch-constraint-trace-pairs.csv"):
    checked(filename)
sys.path.insert(0,str(LAST))
import collar
from balance import np,read,DURATION


def guard():
    collar.guard()
    assert not (HERE/"STOP-REQUESTED").exists()


def keep(name,data):
    guard()
    path=HERE/name
    if path.exists():assert path.read_bytes()==data,path
    else:
        tmp=path.with_suffix(path.suffix+".partial")
        with tmp.open("xb") as stream:stream.write(data)
        tmp.rename(path)


def table(name,rows):
    stream=io.StringIO(newline="")
    writer=csv.DictWriter(stream,fieldnames=list(rows[0]),lineterminator="\n")
    writer.writeheader();writer.writerows(rows)
    keep(name,stream.getvalue().encode())


def tag(grid,level,steps,pad,flag,seed):
    return f"n{grid}-q{level}-t{steps}-p{pad}-off{flag}-s{seed}"


def get_shell(grid,level,flag,seed,pad):
    if pad in (7,8):
        from edge_system import local
        return local(grid,level,flag,seed,6 if pad==7 else 5)
    return collar.system(grid,level,flag,seed,pad)


class Passive:
    def __init__(self,shell):
        self.shell=shell
        self.flag=shell.flag
        self.mu=shell.mu
        self.initial=np.concatenate((shell.initial,0*shell.initial[:2]))
    def dynamics(self,time,state):
        physical=self.shell.dynamics(time,state[:20])
        return np.concatenate((physical,-state[4:5].real/6,-1.5*state[5:6].real))


def run(grid,level,res,pad,flag):
    count=2*level*res
    step=DURATION*np.sqrt(level)/count
    for seed in (0,1,-1):
        guard()
        shell=get_shell(grid,level,flag,seed,pad)
        obj=Passive(shell)
        advance=collar.stepper(obj,step)
        shift=np.zeros_like(obj.initial)
        packets=[]
        for idx in range(count):
            if idx%16==0:guard()
            shift=advance(idx*step,shift)
            if (idx+1)%(count//4)==0:packets.append(shift.copy())
        assert np.isfinite(packets).all()
        buf=io.BytesIO()
        np.savez_compressed(buf,radius=shell.r,change=np.array(packets))
        name=tag(grid,level,res,pad,flag,seed)
        keep(name+".npz",buf.getvalue())
        print(name,"safe",flush=True)


if __name__=="__main__":run(*map(int,sys.argv[1:]))
