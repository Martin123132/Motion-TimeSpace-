"""Independent earlier h4 formation history, with the same signed host, mass and local clock."""
from edge_prediction import *
from types import SimpleNamespace
from balance import family


def make(native):
    sim=family.BalancedNative("heavy",120,120*native,False,"native36",family.SPAN*family.DLOG)
    records=[];receipts=[]
    for flag in (0,1):
        ref,press,_=family.pressure(flag)
        for seed in (0,1,-1):
            original,grid,shapes,supply0=family.input_pack(sim,native,seed,flag,ref,press)
            for level in (1,16,32):
                guard()
                eta=1/np.sqrt(level)
                bg={**ref,"H":ref["H"]*eta,"R":ref["R"]*eta**2,"rh":ref["rh"]*eta**2}
                stub=SimpleNamespace(mesh=sim.mesh,patch=SimpleNamespace(j=sim.patch.j,p=SimpleNamespace(mass=sim.patch.p.mass/eta)))
                state=[original[0].copy(),original[1],eta*original[2]]
                state[0][1]*=eta
                shape=tuple({key:val*eta**family.POWERS[key] for key,val in group.items()} for group in shapes)
                supply={**supply0,"P":press*eta**4,"lp":supply0["lp"]*eta,"spec2":supply0["spec2"]*eta**4}
                obj=family.ResolvingSlice(stub,grid,bg,shape,state,flag,not flag,"fixed",0,"matched")
                hub=bg["H"];mu=bg["a"]*stub.patch.p.mass
                if not flag:
                    mean=family.homogeneous(bg,bg["rh"][sim.patch.j],mu,press*eta**4)
                    hub=mean["hubble"];graph,aux=family.normal_data(obj,supply,mean)
                    for iteration in range(8):
                        hook=family.Sources(grid,aux,shape[0]["other"])
                        obj=family.ResolvingSlice(stub,grid,{**bg,"H":hub},shape,state,flag,True,"fixed",0,"matched",hook)
                        next_graph,new=family.normal_data(obj,supply,mean,graph)
                        if family.change_norm(aux,new)<2e-9:break
                        graph,aux=next_graph,new
                    else:raise RuntimeError("fixed graph not converged")
                    delta,drift=(pair(v.real,family.angular(v)) for v in graph)
                else:delta=drift=pair(np.zeros_like(grid.points),np.zeros_like(grid.points))
                mono=grid.evaluate(obj.state[0])[0]
                higher=shape[0]["V"]+grid.evaluate(obj.state[2])[0][flag]
                packet=dict(t=grid.t,h=grid.h,n=np.stack([pair(a,b) for a,b in zip(obj.m["n"],obj.m["D"])]),
                            v=np.stack([pair(a,b) for a,b in zip(mono[1]/grid.points,higher)]),
                            chi=pair(grid.evaluate(obj.f0)[0],grid.evaluate(obj.f2)[0]),b=pair(obj.b0,obj.b2),
                            delta=delta,drift=drift,rho=bg["rh"],mu=mu,H=hub,P=press*eta**4,R=bg["R"],
                            e0=shape[0]["other"],s0=supply["spec2"])
                if level==1:
                    path=family.checked(family.CLOUD,f"launch-h{native}-off{flag}-seed{seed}.npz")
                    with np.load(path) as old:
                        for key,val in packet.items():
                            overlap=val[..., :round(16/grid.h),:] if np.shape(val)[-2:]==grid.points.shape else val
                            supplied=old[key]
                            peak=np.max(abs(supplied))
                            err=np.max(abs(overlap-supplied))
                            np.testing.assert_array_equal(overlap,supplied,err_msg=key)
                            receipts.append(dict(seed=seed,flag=flag,input=path.name,sha256=sha(path),field=key,max_abs=err,peak=peak))
                if level==1:continue
                for radius in (6.,15.,119.,119.8,119.95,119.99,120.):
                    vec=np.array(launch(packet,radius,flag))
                    for frac in (.25,.5,.75,1.):
                        time=frac*DURATION*np.sqrt(level)
                        mod=np.expm1(np.log(scale_table()[frac])*5/6)
                        vals=vec*level*np.r_[mod,(1+mod)*time,np.ones(5)*(1+mod)*time**2/2]
                        records.append(dict(q=level,seed=seed,flag=flag,radius=radius,fraction=frac,total=fsum(vals)))
    table(f"formation-h{native}-controls.csv",receipts)
    table(f"formation-h{native}-frozen.csv",records)
    paired=[]
    for row in read(HERE/"raychaudhuri-frozen-predictions.csv"):
        level,seed=int(row["q"]),int(row["seed"])
        radius,frac=float(row["radius"]),float(row["fraction"])
        match=[r for r in records if (r["q"],r["radius"],r["fraction"])==(level,radius,frac) and r["seed"] in (0,seed)]
        assert len(match)==4
        pred=fsum((1 if r["seed"] else -1)*(1 if not r["flag"] else -1)*r["total"] for r in match)
        paired.append(dict(q=level,seed=seed,radius=radius,fraction=frac,h4=pred,h5=float(row["expected"]),
                           h4_minus_h5_ppm=(pred-float(row["expected"]))/abs(NORMS[seed,.15,frac])*1e6))
    table("formation-grid-contrast.csv",paired)
    for row in paired:
        if row["q"]==32 and row["seed"]==1 and row["fraction"]==1:print(row["radius"],row["h4_minus_h5_ppm"])


if __name__=="__main__":make(4)
