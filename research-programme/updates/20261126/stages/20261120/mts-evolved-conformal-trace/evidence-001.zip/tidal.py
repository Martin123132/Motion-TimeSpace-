"""Curved-space angular divergence of the actual trace-free tide, with constraints and stress."""
from readout import *


LABELS=("ricci_face_low","ricci_face_high","ricci_interior","extrinsic_face_low","extrinsic_face_high",
        "extrinsic_interior","normal_current","shear_trace_gradient","shear_square_gradient","volume_mix","energy")


def tensor_terms(shell,rad,values,first,second):
    logpsi,shape,tilt,tensor,trace,shear,env=values[:7]
    sp,hp,vp,tp,kp=first[:5]
    first_ell=2*sp+2*hp/3
    first_bend=2*sp-hp/3
    ell=2*logpsi+2*shape/3
    bend=2*logpsi-shape/3
    bend2=2*second[0]-second[1]/3
    ef=exp(-2*ell)
    bf=np.exp(-2*bend[0])
    er=np.exp(-ell[0]);br=np.exp(-bend[0])
    volume=exp(6*logpsi)
    nr=2*bend2-2*mul(first_ell,first_bend)-2*first_ell/rad
    nr[1]+=6*(vp[1]-first_ell[0]*tilt[1])/rad
    common=mul(ef,nr)
    common[0]+=2*ef[0]*np.expm1(2*shape[0])/rad**2
    common[1]+=(ef[0]*(4*ell[1]-6*tilt[1])+bf*(8*bend[1]+12*tensor[1]-6*ell[1]))/rad**2
    ric_b=-common/3
    ric_c=-er*br*((first_bend[1]+tp[1]-ell[1]*first_bend[0])/rad+(tilt[1]-ell[1])/rad**2)
    ric_d=-ef[0]*(second[3,1]/2+(tp[1]-vp[1])/rad+(2*first_bend[0]-first_ell[0])*(tp[1]/2-tilt[1]/rad))
    ric_d+=(ef[0]*tilt[1]-bf*ell[1])/rad**2
    cross,angular,incident=values[17:20]
    def weak(rb,rc,rd):
        transport=np.exp(3*bend[0])*rc
        bulk=-.6*(3*transport+volume[0]*(-rb[1]/2-2*rd-1.5*rb[0]*ell[1]))/rad
        return .6*transport,bulk
    ri,rbulk=weak(-ric_b,-ric_c,-ric_d)
    ex,xbulk=weak(-mul(trace,shear)/3,-trace[0]*cross[1]/3,-trace[0]*angular[1]/3)
    unit=pair(np.ones_like(rad),np.zeros_like(rad))
    density=env.copy()
    jt=incident[1].copy()
    for species in range(3 if shell.flag else 2):
        num,pot=values[7+2*species:9+2*species]
        rest=shell.rho[species]*mul(num,exp(-6*logpsi))
        pr=mul(exp(-ell),first[8+2*species])
        density+=mul(rest,root(unit+square(pr)))
        jt+=rest[0]*pot[1]*br/rad
    if not shell.flag:
        logwave,zreal,phase,zi=values[13:17]
        rest=shell.rho[-1]*exp(2*logwave)
        real=zreal+trace/(2*shell.mu)
        imag=zi-unit
        grads=mul(ef,square(first[13])+square(first[15]))/shell.mu**2
        density+=mul(rest,unit+square(real)+square(imag)+grads)/2
        jt-=rest[0]*(real[0]*logwave[1]+imag[0]*phase[1])*br/(rad*shell.mu)
    currents=-volume[0]*trace[0]*jt/(5*br)
    sheark=-volume[0]*(cross[1]*er*kp[0]/br-shear[0]*trace[1]/(2*rad))/5
    shears=-.15*volume[0]*square(shear)[1]/rad
    mixing=volume[1]*density[0]/(5*rad)
    measured=mul(volume,density)[1]/(5*rad)
    return ri,rbulk,ex,xbulk,currents,sheark,shears,mixing,measured


class WeakTide(Samples):
    def splines(self,grid,spline):
        anchor=grid[...,:1]
        fit=make_interp_spline(self.shell.r,grid-anchor,k=spline,axis=-1)
        return [fit(self.points)+anchor,fit(self.points,1),fit(self.points,2)[:4]]
    def apply(self,coeffs):
        ri,rb,ex,xb,*other=tensor_terms(self.shell,self.points,*coeffs)
        integral=lambda field:self.weights@field[:-2]
        return np.r_[ri[-2],-ri[-1],integral(rb),ex[-2],-ex[-1],integral(xb),[integral(t) for t in other]]


def extra(arr,shift=False):
    return np.concatenate((fields(arr,shift),arr[[6,7,19]].real))


def run(grid,level,res,pad,flag,seed,fine):
    stem=tag(grid,level,res,pad,flag,seed)
    shell=get_shell(grid,level,flag,seed,pad)
    ranges={3:((6.,15.),(6.,12.)),5:((15.,24.),(24.,48.),(48.,72.),(72.,96.),(96.,119.),(119.,120.)),6:((119.,120.),),7:((119.,120.),),8:((119.,120.),)}[pad]
    with np.load(HERE/(stem+".npz")) as packet:shifts=packet["change"]
    first=extra(shell.initial)
    eps=1e-20
    normal=scale_table();rows=[]
    nodes,weights=leggauss(3 if fine else 2)
    for low,high in ranges:
        gate=WeakTide(shell,low,high,6 if fine else 4)
        base=gate.splines(first,5 if fine else 3)
        initial=gate.apply(base)
        for frac,change in zip(np.arange(1,5)/4,shifts):
            diff=gate.splines(extra(change,True),5 if fine else 3)
            increment=sum(wt*gate.apply([a+((node+1)/2+1j*eps)*d for a,d in zip(base,diff)]).imag/(2*eps) for node,wt in zip(nodes,weights))
            result=level*(normal[frac]*increment+(normal[frac]-1)*initial)
            rows.append(dict(grid=grid,q=level,seed=seed,flag=flag,pad=pad,fraction=frac,lower=low,upper=high,refined=fine,
                             **dict(zip(LABELS,result))))
    table(f"tidal-{stem}-fine{fine}.csv",rows)


if __name__=="__main__":
    grid,level,res,pad,fine=map(int,sys.argv[1:])
    for flag in (0,1):
        for seed in (0,1,-1):run(grid,level,res,pad,flag,seed,fine)
