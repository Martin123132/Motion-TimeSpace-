"""Finite change in the independent constraint source and metric surface combinations."""
from trace_campaign import *
from scipy.interpolate import make_interp_spline
from numpy.polynomial.legendre import leggauss
from math import fsum


def pair(base,quad):
    return np.stack((base,quad))


def mul(left,right):
    return pair(left[0]*right[0],left[0]*right[1]+left[1]*right[0])


def exp(field):
    base=np.exp(field[0])
    return pair(base,base*field[1])


def square(field):
    return pair(field[0]**2,2*field[0]*field[1])


def root(field):
    base=np.sqrt(field[0])
    return pair(base,field[1]/(2*base))


def fields(state,shift=False):
    return np.array([state[20].real if shift else (state[0].real+2*state[1].real)/6,
                     state[21].real if shift else state[0].real-state[1].real,
                     *(state[idx].real for idx in (2,3,4,5,17,8,9,10,11,12,13,14,15)),
                     state[14].imag,state[15].imag])


TERMS=("normal_energy","expansion","shear","shape_ricci","laplacian_correction")


def source(shell,rad,values,slopes,second):
    logpsi,shape,tilt,tensor,trace,shear,env=values[:7]
    slog,hprime,vprime=slopes[:3]
    ell=2*shape/3
    bend=-shape/3
    d_ell=2*hprime/3
    d_bend=-hprime/3
    d2_bend=-second[1]/3
    psi=exp(logpsi)
    normal=exp(-2*logpsi-ell)
    unit=pair(np.ones_like(rad),np.zeros_like(rad))
    density=env.copy()
    for idx in range(3 if shell.flag else 2):
        number=values[7+2*idx]
        speed=mul(normal,slopes[8+2*idx])
        density+=shell.rho[idx]*mul(mul(number,exp(-6*logpsi)),root(unit+square(speed)))
    if not shell.flag:
        logwave,zreal,phase,zi=values[13:17]
        kin=square(zreal+trace/(2*shell.mu))+square(zi-unit)
        grad=(square(mul(normal,slopes[13]))+square(mul(normal,slopes[15])))/shell.mu**2
        density+=shell.rho[-1]/2*mul(exp(2*logwave),unit+kin+grad)
    ef=exp(-2*ell)
    bf=np.exp(-2*bend[0])
    curvature=mul(ef,-4*d2_bend+4*mul(d_ell,d_bend)+4*d_ell/rad-6*square(d_bend)-12*d_bend/rad)
    curvature[0]+=2*ef[0]*np.expm1(2*(ell[0]-bend[0]))/rad**2
    curvature[1]+=(ef[0]*(4*ell[1]-24*tilt[1])+bf*(8*bend[1]+12*tensor[1]+12*ell[1]))/rad**2
    curvature[1]+=ef[0]*((12*d_ell[0]-36*d_bend[0])*tilt[1]-12*vprime[1])/rad
    dpsi=mul(psi,slog)
    flat_radial=mul(psi,second[0]+square(slog))+2*dpsi/rad
    correction=mul(pair(np.expm1(-2*ell[0]),ef[1]),flat_radial)+mul(ef,mul(2*d_bend-d_ell,dpsi))
    correction[1]+=(-6*np.expm1(-2*bend[0])*psi[1]/rad**2+6*ef[0]*tilt[1]*dpsi[0]/rad)
    scale=exp(5*logpsi)
    terms=np.stack((mul(scale,density)[1],-mul(scale,square(trace))[1]/3,
                    .75*mul(scale,square(shear))[1],-.5*mul(psi,curvature)[1],4*correction[1]))
    return terms,psi[1],dpsi[1]


class Samples:
    def __init__(self,shell,low,high,order):
        self.shell=shell
        dx=shell.dx
        self.low=low
        self.high=high
        nodes,weights=leggauss(order)
        self.faces=np.arange(round((low-shell.left)/dx),round((high-shell.left)/dx)+1)*dx+shell.left
        self.rad=(self.faces[:-1,None]+(1+nodes[None,:])*dx/2).ravel()
        self.weights=np.tile(weights,len(self.faces)-1)*dx/2
        self.points=np.r_[self.rad,low,high]
        self.order=order
    def splines(self,grid,spline):
        f=make_interp_spline(self.shell.r,grid,k=spline,axis=-1)
        return [f(self.points),f(self.points,1),f(self.points,2)[:2]]
    def apply(self,coeffs):
        terms,quad,der=source(self.shell,self.points,*coeffs)
        strong=-.8*(der[-2:]/self.points[-2:]+3*quad[-2:]/self.points[-2:]**2)
        values=terms[:,:-2]@(self.weights/(5*self.rad))
        weak=[]
        for cut,side in ((self.low,-1),(self.high,1)):
            width=.2
            select=self.rad<cut+width if side==-1 else self.rad>cut-width
            pos=self.rad[select]
            test=1+side*(pos-cut)/width
            grad=der[:-2][select]
            potential=quad[:-2][select]
            local=terms[:,:-2][:,select].sum(axis=0)
            slope=side*(self.weights[select]@(pos**2*grad*side/width+6*potential*test-pos**2*local*test/4))/cut**2
            weak.append(-.8*(slope/cut+3*quad[-2 if side==-1 else -1]/cut**2))
        return np.r_[values,strong,weak]


COLS=(*TERMS,"inner","outer","weak_inner","weak_outer")


def compute(grid,level,res,pad,flag,seed,fine=0):
    stem=tag(grid,level,res,pad,flag,seed)
    shell=get_shell(grid,level,flag,seed,pad)
    if pad==3:ranges=((6.,15.),(6.,12.))
    elif pad==5:ranges=((15.,24.),(24.,48.),(48.,72.),(72.,96.),(96.,119.),(119.,120.))
    elif pad in (6,7,8):ranges=((119.,120.),)
    else:ranges=((5.,6.),)
    fraction=np.arange(1,5)/4
    normal=scale_table()
    rows=[]
    with np.load(HERE/(stem+".npz")) as archive:
        shifts=archive["change"]
        np.testing.assert_array_equal(shell.r,archive["radius"])
    start=fields(shell.initial)
    eps=1e-20
    nodes,weights=leggauss(3 if fine else 2)
    for low,high in ranges:
        gate=Samples(shell,low,high,6 if fine else 4)
        before=gate.splines(start,5 if fine else 3)
        initial=gate.apply(before)
        for frac,shift in zip(fraction,shifts):
            delta=gate.splines(fields(shift,True),5 if fine else 3)
            change=np.zeros_like(initial)
            for node,wt in zip(nodes,weights):
                swept=[base+((node+1)/2+1j*eps)*part for base,part in zip(before,delta)]
                change+=wt/2*gate.apply(swept).imag/eps
            modifier=np.expm1(np.log(normal[frac])*5/6)
            total=level*((1+modifier)*change+modifier*initial)
            rows.append(dict(grid=grid,q=level,res=res,pad=pad,seed=seed,flag=flag,lower=low,upper=high,fraction=frac,refined=fine,
                             **dict(zip(COLS,total)),metric_evolution=level*(change[6]-change[5]),
                             clock_part=level*modifier*(initial[6]-initial[5]),static_metric=level*(initial[6]-initial[5]),
                             shape_roundoff=np.max(abs(shift[21].real-(shift[0].real-shift[1].real)))))
    table(f"trace-{stem}-fine{fine}.csv",rows)


def scale_table():
    if not hasattr(scale_table,"stored"):
        factor=collar.timescale()
        scale_table.stored={frac:factor(frac) for frac in np.arange(1,5)/4}
    return scale_table.stored


if __name__=="__main__":
    grid,level,res,pad=map(int,sys.argv[1:5])
    fine=int(sys.argv[5]) if len(sys.argv)>5 else 0
    for flag in (0,1):
        for seed in (0,1,-1):compute(grid,level,res,pad,flag,seed,fine)
