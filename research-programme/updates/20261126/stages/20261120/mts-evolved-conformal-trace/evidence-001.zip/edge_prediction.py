"""Frozen local acceleration prediction for the outer trace, directly on the original Gauss packets."""
from compare import *
from numpy.polynomial.legendre import legder,legvander,legval


def launch(packet,radius,flag):
    nodes=packet["t"];h=float(packet["h"]);n=len(nodes)
    elem=min(round(120/h)-1,int(radius/h))
    point=2*(radius/h-elem)-1+2e-20j/h
    basis=np.linalg.inv(legvander(2*nodes-1,n-1))
    interp=legval(point,basis)
    deriv=legval(point,legder(basis))*2/h
    def at(key,grad=False):
        native=packet[key][...,elem,:]
        base=native[...,:1]
        return ((native-base)@(deriv if grad else interp))+(0 if grad else base[...,0])
    one=np.array([1.,0.])
    psi=one+at("chi");logpsi=pair(np.log(psi[0]),psi[1]/psi[0])
    inv=exp(-2*logpsi);trace=-3*float(packet["H"])
    shear=mul(at("b"),exp(-6*logpsi))
    rho=packet["rho"];mu=float(packet["mu"])
    src=np.array([float(packet["R"])-sum(rho)+3*float(packet["P"]),at("e0")+at("s0")])
    terms=[src,0*src,0*src]
    num=at("n");speed=at("v",True)
    for idx in range(3 if flag else 2):
        momentum=square(mul(inv,speed[idx]))
        gamma=root(one+momentum)
        recip=pair(1/gamma[0],-gamma[1]/gamma[0]**2)
        terms[1]+=rho[idx]*mul(mul(num[idx],exp(-6*logpsi)),gamma+mul(momentum,recip))
    if not flag:
        den=one+at("delta")
        inverse=pair(1/den[0],-den[1]/den[0]**2)
        rest=rho[-1]*mul(exp(-6*logpsi),mul(num[-1],inverse))
        terms[2]=mul(rest,2*(square(at("drift"))+square(den))-one)
    acceleration=[-psi*trace**2/36,-mul(psi,square(shear))/4,*[-mul(psi,term)/12 for term in terms]]
    def surface(field):
        return -.8*(field[1].imag/1e-20/radius+3*field[1].real/radius**2)
    return list(map(surface,[psi,-trace*psi/6,*acceleration]))


def compute():
    labels=("static","initial_slope","homogeneous","shear","env","dust","wave")
    records=[];ledger=[]
    scale=scale_table()
    for level in (16,32):
        for flag in (0,1):
            for seed in (0,1,-1):
                with np.load(checked(f"full-q{level}-off{flag}-s{seed}.npz")) as packet:
                    for radius in (6.,15.,119.,119.8,119.95,119.99,120.):
                        vec=np.array(launch(packet,radius,flag))
                        for frac in (.25,.5,.75,1.):
                            time=frac*DURATION*np.sqrt(level)
                            modifier=np.expm1(np.log(scale[frac])*5/6)
                            values=vec*level*np.r_[modifier,(1+modifier)*time,np.ones(5)*(1+modifier)*time**2/2]
                            records.append(dict(q=level,flag=flag,seed=seed,radius=radius,fraction=frac,**dict(zip(labels,values))))
        for seed in (-1,1):
            for frac in (.25,.5,.75,1.):
                for radius in (6.,15.,119.,119.8,119.95,119.99,120.):
                    pick=[row for row in records if row["q"]==level and row["seed"] in (0,seed) and row["fraction"]==frac and row["radius"]==radius]
                    vals=[fsum((1 if row["seed"] else -1)*(1 if not row["flag"] else -1)*row[col] for row in pick) for col in labels]
                    ledger.append(dict(q=level,seed=seed,fraction=frac,radius=radius,expected=fsum(vals),**dict(zip(labels,vals))))
    table("raychaudhuri-launch.csv",records);table("raychaudhuri-frozen-predictions.csv",ledger)
    for row in ledger:
        if row["q"]==32 and row["seed"]==1 and row["fraction"]==1:
            denom=abs(NORMS[1,.15,1])*1e-6
            print(row["radius"],"predicted ppm",row["expected"]/denom)


if __name__=="__main__":compute()
