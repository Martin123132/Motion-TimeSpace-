"""Symmetric physical pulses after freezing the unforced high-resolution current prediction."""
from evolution import Local
from inputs import *
from wave_current import EPOCHS

def run(level,refinement):
    stem=f"bond-current-g{level}-t{refinement}"
    forecasts=read(stem+".csv")
    stamp=digest(HERE/(stem+".csv"))
    note(stem+"-before-finite.json",dict(prediction_hash=stamp,nominal_kms=.12,refinement=refinement,level=level))
    outputs=[]
    for sign in (-1,1):
        lab=Local("heavy",level,False,sign,.12)
        prior=0.;items=[]
        for end in EPOCHS:
            count=round((end-prior)*4000*refinement)
            for step in range(count):
                guard()
                lab.advance(lab.initial*np.exp(prior+(end-prior)*step/count),lab.initial*np.exp(prior+(end-prior)*(step+1)/count))
            vals=lab.read_metric(lab.initial*np.exp(end));wave=lab.readout()["wave"]
            items.extend((end,site,vals[site],wave[site],lab.unit) for site in range(3));prior=end
        outputs.append(items)
        del lab
    rows=[]
    for low,high,row in zip(*outputs,forecasts,strict=True):
        end,site=low[:2]
        assert (end,site)==tuple(high[:2])==(float(row["elapsed"]),int(row["shell"]))
        assert low[-1]==high[-1]==float(row["unit"])
        scale=2*low[-1]*float(row["common_scale"])
        value=(high[2]-low[2])/scale
        wave=(high[3]-low[3])/scale
        rows.append(dict(level=level,refinement=refinement,elapsed=end,shell=site,measured=value,wave=wave,
            forecast=float(row["total"]),forward_error=value-float(row["total"]),current_error=wave-float(row["bond_current"])))
    assert digest(HERE/(stem+".csv"))==stamp
    table(stem+"-opposite-pulses.csv",rows);print(stem,max(abs(row["forward_error"]) for row in rows),flush=True)
if __name__=="__main__":run(int(sys.argv[1]),int(sys.argv[2]))

