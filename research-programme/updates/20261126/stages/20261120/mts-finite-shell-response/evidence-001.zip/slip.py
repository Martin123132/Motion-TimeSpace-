"""Trace-free common-metric source on two formed snapshots, not a closure or halo fit."""
from inputs import *
from local_impulse import split
from scipy.interpolate import make_interp_spline
from scipy.integrate import quad
from scipy.special import roots_legendre

INNER,MIDDLE,OUTER=.1,.2,.35
FIRST=MIDDLE**2-INNER**2
SECOND=OUTER**2-MIDDLE**2

def integrate_readout(radius,source_weight):
    triangular=np.where(radius<MIDDLE,(radius**2-INNER**2)/FIRST,(OUTER**2-radius**2)/SECOND)
    result=.5*FIRST*np.dot(triangular,source_weight)
    middle=.5*np.dot(np.maximum(MIDDLE**2-radius**2,0.),source_weight)
    outer=.5*np.dot(OUTER**2-radius**2,source_weight)
    boundary_check=FIRST*(outer-middle)/SECOND-middle
    assert abs(result-boundary_check)<1e-12*max(abs(result),1e-30)
    return float(result)

def electrovac():
    import sympy as algebra
    rad,mass,charge,metric_coupling=algebra.symbols("r M Q k",real=True,nonzero=True)
    moment=(mass**2-charge**2)/4;scale=1+mass/rad+moment/rad**2
    relative=1-moment/rad**2
    grad=-scale.diff(rad)/scale
    tension=-2*charge**2/(rad**4*scale**2)
    lhs=(relative.diff(rad)/(rad*scale**4)).diff(rad)
    check=algebra.factor(lhs+relative*(2*grad**2+metric_coupling*tension)/(rad*scale**4))
    assert algebra.simplify(check.subs(metric_coupling,1))==0
    assert algebra.solve(check,metric_coupling)==[1]
    assert algebra.factor((2*grad**2+tension)-2*(mass**2-charge**2)/(rad**4*scale))==0
    results=[]
    for value in (0.,.6,1.):
        mv=.028;qv=value*mv
        def packet(point):
            denom=1+mv/point+(mv**2-qv**2)/(4*point**2)
            ff=1-(mv**2-qv**2)/(4*point**2)
            vv=(mv+(mv**2-qv**2)/(2*point))/(point**2*denom)
            return denom,ff,vv
        def flux(point):
            denom,_,_=packet(point)
            return (mv**2-qv**2)/(2*point**4*denom**4)
        def source(point):
            denom,ff,vv=packet(point)
            return -ff*(2*vv**2-2*qv**2/(point**4*denom**2))/(point*denom**4)
        exact=flux(OUTER)-flux(INNER);quadrature=quad(source,INNER,OUTER,epsabs=3e-13)[0]
        error=abs(exact-quadrature)
        assert error<1e-11
        results.append(dict(charge_over_mass=value,flux_diff=exact,integrated_source=quadrature,error=error))
    table("tracefree-electrovac-controls.csv",results)

def spectrum(rad,psi,sites):
    base=dst(rad[1:-1]*(psi[1:-1]-1),type=1)/(len(rad)-1)
    modes=np.arange(1,len(rad)-1)*np.pi/rad[-1]
    result=np.empty(len(sites),complex)
    for start in range(0,len(sites),48):
        selected=sites[start:start+48];phase=selected[:,None]*modes
        result[start:start+len(selected)]=(np.cos(phase)@(modes*base)-(np.sin(phase)@base)/selected)/selected
    return result

def run():
    results=[]
    for model in ("cold","heavy"):
        for epoch in ("start","end"):
            _,native,_=fixture(model,epoch,0)
            for level in (0,1,2):
                guard()
                seed,state,scalefactor=fixture(model,epoch,level);lab=ActionSystem(seed,state);field=lab.source(scalefactor)
                grid=lab.r
                for order in (6,10):
                    pts,wts=roots_legendre(order)
                    lower=grid[round(INNER/lab.h):round(OUTER/lab.h)]
                    rad=(lower[:,None]+(pts+1)*lab.h/2).ravel()
                    measure=np.tile(wts*lab.h/2,len(lower))/rad
                    geometry=integrate_readout(rad,2*field.acceleration(rad)**2*measure)
                    wave=other_wave=0.
                    if lab.psi is not None:
                        gradient=spectrum(native["r"],native["psi"],rad)
                        factor=seed.coeff["wave"]/(scalefactor**3*seed.mass**2)
                        wave=integrate_readout(rad,factor*abs(gradient)**2*measure)
                        until=round(.4/lab.h)+2
                        localpsi=make_interp_spline(grid[:until],lab.psi[:until],k=5)
                        other_wave=integrate_readout(rad,factor*abs(localpsi(rad,nu=1))**2*measure)
                    sheets={}
                    for species,(coords,momenta,masses) in lab.dust.items():
                        indices,bins,left,right=split(coords[:-1],coords[1:],lab.h,lab.n)
                        mask=(bins>=round(INNER/lab.h))&(bins<round(OUTER/lab.h))
                        indices,left,right=indices[mask],left[mask],right[mask]
                        half=(right-left)/2;frac=(left+right)[:,None]/2+half[:,None]*pts
                        xpos=abs(coords[indices,None]+np.diff(coords)[indices,None]*frac)
                        momentum=momenta[indices,None]+np.diff(momenta)[indices,None]*frac
                        mass_q=(masses[indices]/(indices**2+indices+1/3)*half)[:,None]*(indices[:,None]+frac)**2*wts
                        sheets[species]=integrate_readout(xpos.ravel(),(seed.coeff[species]*mass_q*momentum**2/(scalefactor*xpos)**3).ravel())
                    scale=abs(field.potential[round(MIDDLE/lab.h)]-field.potential[round(INNER/lab.h)])
                    total=geometry+wave+sum(sheets.values())
                    assert min(geometry,*sheets.values())>0 and (wave>0)==(model=="heavy")
                    results.append(dict(model=model,epoch=epoch,a=scalefactor,level=level,order=order,
                        geometry=geometry,wave=wave,independent_wave_spline=other_wave,**sheets,
                        contrast_V_minus_U=total,lapse_span=scale,ratio_to_newtonian_span=total/scale))
    table("formed-tracefree-source.csv",results);print("Trace-free source",len(results),"cases",flush=True)
if __name__=="__main__":electrovac();run()

