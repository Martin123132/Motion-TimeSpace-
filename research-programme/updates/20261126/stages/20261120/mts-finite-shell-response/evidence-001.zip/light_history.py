"""Short dense conformal-time metric history after the measured matter-response endpoint."""
from evolution import Local
from wave_current import EPOCHS
from inputs import *
from scipy.integrate import solve_ivp

def clock(seed,initial):
    return solve_ivp(lambda _,val:val**2*seed.H(float(val[0])),(0.,.084),[initial],
        method="DOP853",dense_output=True,rtol=1e-13,atol=1e-15,max_step=.01).sol

def run(model,level,substeps,mode):
    tangent=mode=="tangent";sign={"tangent":0,"positive":1,"negative":-1,"weakpositive":1,"weaknegative":-1}[mode]
    guard()
    if not tangent:
        forecast=HERE/f"clock-{model}-g{level}-n{substeps}-tangent.npz"
        assert forecast.is_file()
    native_unit=float(read(model+"-g0-t2-prediction-to0.004.csv")[0]["unit"])
    lab=Local(model,level,tangent,sign,.03 if mode.startswith("weak") else .12)
    prior=0.;origin=lab.initial
    for end in EPOCHS:
        count=round(8000*(end-prior))
        for step in range(count):
            guard();lab.advance(origin*np.exp(prior+(end-prior)*step/count),origin*np.exp(prior+(end-prior)*(step+1)/count))
        prior=end
    end=origin*np.exp(.004)
    rt=clock(lab.seed,end);times=np.linspace(0.,.084,substeps+1)
    scales=rt(times)[0];cut=round(.375/lab.lab.h)+2
    rad=lab.lab.r[:cut];fields=[];derivs=[]
    for index,a in enumerate(scales):
        guard()
        if index:lab.advance(scales[index-1],a)
        phi=lab.potentials(sum(lab.by.values()),a)[0][:cut].copy()
        fields.append(phi-phi[-1])
        if tangent:
            deriv=lab.potentials(sum(lab.dby.values()),a)[0][:cut].copy()
            derivs.append((deriv-deriv[-1])*native_unit/lab.unit)
    buffer=io.BytesIO()
    np.savez_compressed(buffer,r=rad,eta=times,a=scales,conformal_h=np.array([a*lab.seed.H(a) for a in scales]),
        potential=fields,variation=derivs,native_unit=native_unit,local_unit=lab.unit)
    target=f"clock-{model}-g{level}-n{substeps}-{mode}.npz"
    put(target,buffer.getvalue())
    print(target,digest(HERE/target),flush=True)

if __name__=="__main__":run(sys.argv[1],int(sys.argv[2]),int(sys.argv[3]),sys.argv[4])

