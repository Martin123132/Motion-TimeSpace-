"""Two equal comoving paths, one receiver: time-gradient, force-integral and pulse-spacing readouts."""
from inputs import *
from scipy.special import roots_legendre

ARRIVAL=.082
def ray(times,rad,fields,conformal_h,low,high,arrival=ARRIVAL):
    travel=(high-low)/2
    emission=arrival-travel
    assert times[0]<emission<arrival<times[-1]
    raw=np.r_[0.,travel,times-emission,high-rad,rad-low]
    knots=np.unique(np.clip(raw,0.,travel))
    left,right=knots[:-1],knots[1:]
    points,weights=roots_legendre(4)
    nodes=(.5*(right+left)[:,None]+.5*(right-left)[:,None]*points).ravel()
    integration=(.5*(right-left)[:,None]*weights).ravel()
    def sample(at,pos):
        index=np.clip(np.searchsorted(times,at,side="right")-1,0,len(times)-2)
        cell=np.clip(np.searchsorted(rad,pos,side="right")-1,0,len(rad)-2)
        interval=times[index+1]-times[index]
        fraction=(at-times[index])/interval
        denominator=(rad[cell+1]-rad[cell])*(rad[cell+1]+rad[cell])
        shape=(pos-rad[cell])*(pos+rad[cell])/denominator
        base=fields[index,cell]*(1-shape)+fields[index,cell+1]*shape
        nxt=fields[index+1,cell]*(1-shape)+fields[index+1,cell+1]*shape
        gradient=2*pos*((fields[index,cell+1]-fields[index,cell])*(1-fraction)
                    +(fields[index+1,cell+1]-fields[index+1,cell])*fraction)/denominator
        return base*(1-fraction)+nxt*fraction,(nxt-base)/interval,gradient
    phi_hi,time_hi,grad_hi=sample(emission+nodes,high-nodes)
    phi_lo,time_lo,grad_lo=sample(emission+nodes,low+nodes)
    endpoint=sample(emission,high)[0]-sample(emission,low)[0]
    delay=2*integration@(phi_hi-phi_lo)
    evolving=2*integration@(time_hi-time_lo)
    expansion=np.interp(emission,times,conformal_h)*delay
    force=2*integration@(grad_hi+grad_lo)
    return dict(endpoint=float(endpoint),evolving=float(evolving),expansion=float(expansion),
                emission_delay_Mpc=float(delay),received=float(endpoint+evolving+expansion),
                force_form=float(force-endpoint+expansion))

def controls():
    rad=np.linspace(0.,.375,61);times=np.linspace(0.,.084,17);history=rad[None,:]*0+times[:,None]
    slope,rate,hub=1.8,-3.7,.25
    field=(slope+rate*history)*rad[None,:]**2
    record=[]
    for low,high in SHELLS:
        travel=(high-low)/2;emission=ARRIVAL-travel;delta=high**2-low**2
        want=delta*((slope+rate*emission)*(1+hub*travel)+rate*travel+hub*rate*travel**2/3)
        for kind,potential,target in (("quadratic",field,want),("with-common-shift",field+13*history,want),
                                        ("homogeneous",13*history,0.)):
            row=ray(times,rad,potential,np.full(len(times),hub),low,high)
            residual=max(abs(row["received"]-target),abs(row["force_form"]-target))
            assert residual<2e-14
            record.append(dict(kind=kind,low=low,high=high,target=target,error=residual))
    return record

def run():
    table("clock-manufactured-controls.csv",controls());rows=[];checks=[]
    for model in ("heavy","cold"):
        native=freeze_data(model,0)
        for level in (0,1):
            modes=("tangent","positive","negative") if level==0 else ("tangent",)
            group={}
            for mode in modes:
                with np.load(HERE/f"clock-{model}-g{level}-n16-{mode}.npz",allow_pickle=False) as data:
                    rad,times,hub=data["r"],data["eta"],data["conformal_h"]
                    common_epsilon=float(data["native_unit"])
                    for source in (("potential","variation") if mode=="tangent" else ("potential",)):
                        fields=data[source]
                        for site,(low,high) in enumerate(SHELLS):
                            norm=.004*common_epsilon*np.sqrt(native[site,site]*native[0,0])/float(data["a"][0])
                            output=ray(times,rad,fields,hub,low,high)
                            coarse=ray(times[::2],rad,fields[::2],hub[::2],low,high)
                            spacing=.0001
                            def travel(offset):return ray(times,rad,fields,hub,low,high,ARRIVAL+offset)["emission_delay_Mpc"]
                            by_pulses=(travel(spacing)-travel(-spacing))/(2*spacing)+output["endpoint"]+output["expansion"]
                            group[mode,source,site]=(output["received"],norm)
                            rows.append(dict(model=model,level=level,mode=mode,field=source,shell=site,
                                **output,pulse_form=by_pulses,coarse_time=coarse["received"],pulse_scale=norm))
            if level==0:
                for site in range(3):
                    predicted,norm=group["tangent","variation",site]
                    measured=(group["positive","potential",site][0]-group["negative","potential",site][0])/2
                    checks.append(dict(model=model,shell=site,prediction=predicted,measured=measured,
                                  defect_on_drive_scale=(measured-predicted)/norm))
    table("metric-light-transfer.csv",rows);table("light-opposite-pulse-checks.csv",checks)
    print("Analytic controls and clock transfers",len(rows),checks,flush=True)
if __name__=="__main__":run()

