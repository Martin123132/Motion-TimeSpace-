import csv
import io
import json
import os
import sys
from pathlib import Path
for name in ("OPENBLAS_NUM_THREADS","OMP_NUM_THREADS","MKL_NUM_THREADS","BLIS_NUM_THREADS","NUMEXPR_NUM_THREADS"):
    os.environ[name]="1"
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
PREV=HERE.parent/"mts-formation-aperture-transport-20261120"
import hashlib
def digest(path):
    with path.open("rb") as stream:return hashlib.file_digest(stream,"sha256").hexdigest()
SEAL="f8304a1b9216d759c6deab40dd07603a325f31a5ed1139ab271485e516cbe484"
assert digest(PREV/"seal.json")==SEAL
FILES=json.loads((PREV/"seal.json").read_bytes())["files"]
def checked(name):
    path=PREV/name
    assert digest(path)==FILES[name],path
    return path
for name in ("common.py","susceptibility.py","local_impulse.py","collect.py","momentum_constraint.py"):checked(name)
sys.path.insert(0,str(PREV))
from susceptibility import fixture as saved_fixture,metric_weights,SHELLS,metric
from common import sine_double
from common import np,ActionSystem,END,C,TOL,dst,idst,read_npz
from scipy.special import roots_legendre
from math import fsum

def guard():
    for root in (HERE,PREV,HERE.parent):
        if (root/"STOP-REQUESTED").exists():raise RuntimeError("owner hold")
def put(name,body):
    guard();path=HERE/name
    if path.exists():assert path.read_bytes()==body,path
    else:
        with path.open("xb") as stream:stream.write(body)
def note(name,items):put(name,(json.dumps(items,sort_keys=True,indent=2,allow_nan=False)+"\n").encode())
def table(name,rows):
    stream=io.StringIO(newline="")
    writer=csv.DictWriter(stream,rows[0],lineterminator="\n");writer.writeheader();writer.writerows(rows);put(name,stream.getvalue().encode())
def read(name):
    with (HERE/name).open(newline="") as stream:return list(csv.DictReader(stream))
def fixture(model,epoch,level):
    assert 0<=level<=3
    seed,state,a=saved_fixture(model,epoch,min(1,level))
    for _ in range(1,level):
        rad=state["r"]
        doubled=np.linspace(0.,rad[-1],len(rad)*2-1)
        if "psi" in state:
            original=state["psi"]
            psi=np.ones(len(doubled),complex)
            psi[0]=original[0]
            psi[1:-1]+=sine_double(rad[1:-1]*(original[1:-1]-1))/doubled[1:-1]
            assert max(abs(psi[::2]-original))<1e-9
            state["psi"]=psi
        state["r"]=doubled
    return seed,state,a

def freeze_data(model,level,lab=None,a=None):
    if level>1:
        from local_impulse import matrices
        method="sixth" if model=="heavy" else "local"
        return matrices(lab,metric_weights(lab),a,extended=model=="heavy")[method]["total"]/lab.seed.H(a)
    name="frozen-compact-impulses.csv" if model=="heavy" else "frozen-local-impulses.csv"
    with checked(name).open(newline="") as stream:prior=list(csv.DictReader(stream))
    method="sixth" if model=="heavy" else "local"
    return np.array([float(row["prediction"]) for row in prior if row["model"]==model and row["epoch"]=="start" and row["level"]==str(level)
        and row["method"]==method and row["species"]=="total"]).reshape(3,3)

