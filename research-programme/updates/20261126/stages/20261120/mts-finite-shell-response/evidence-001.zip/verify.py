"""Check the whole local comparison; make a write-once manifest only after all tests."""
from inputs import *
from itertools import product
from scipy.integrate import quad
from scipy.constants import parsec,Julian_year

def peak(rows,field):
    return max(abs(float(row[field])) for row in rows)

def run():
    guard()
    assert all(digest(PREV/name)==expected for name,expected in FILES.items())
    assert not list(HERE.glob("**/__pycache__")) and not list(HERE.glob("**/*.pyc"))
    paired=read("paired-forward-tests.csv")
    key=lambda row:(row["model"],int(row["g"]),int(row["t"]),float(row["logtime"]),int(row["readout"]),row["species"],float(row["speed"]))
    epochs=(.00025,.0005,.001,.002,.004)
    expected={(model,grid,rate,at,site,species,speed) for model in ("heavy","cold") for grid,rate,at,site,species,speed in product(
        (0,1),(1,2),epochs,range(3),("cdm","baryon","wave","total") if model=="heavy" else ("cdm","baryon","total"),(.03,.12))}
    assert {key(row) for row in paired}==expected and len(paired)==len(expected)
    for model,grid,rate in product(("cold","heavy"),(0,1),(1,2)):
        stem=f"{model}-g{grid}-t{rate}-"
        pred=HERE/(stem+"prediction-to0.004.csv")
        seal=HERE/(stem+"prediction-to0.004-freeze.json")
        assert digest(pred)==json.loads(seal.read_bytes())["predictions"]
        assert all(seal.stat().st_mtime_ns<=(HERE/(stem+label+"-to0.004.csv")).stat().st_mtime_ns for label in ("zero","plus","minus","weakplus","weakminus"))
    maximum=peak(paired,"discrepancy");balance=peak(paired,"source_defect")
    assert maximum<TOL and balance<TOL
    diag=[row for path in HERE.glob("*-to0.004-checks.json") for row in json.loads(path.read_bytes())]
    assert len(diag)==48*6
    residuals={name:peak(diag,name) for name in ("mass_over_target","varied_mass_over_target","mass_flux_over_target","max_impulse_defect")}
    residuals["endpoint_transport"]=max(abs(value) for row in diag for value in row["transported_defect"].values())
    assert max(residuals.values())<TOL
    old=read("native-comparison.csv");assert len(old)==60
    waves=[];refined=[]
    for grid in range(4):
        data=read(f"bond-current-g{grid}-t2.csv")
        assert len(data)==15 and {(float(row["elapsed"]),int(row["shell"])) for row in data}==set(product(epochs,range(3)))
        assert max(abs(float(row["original_phase_current"])+float(row["metric_induced_current"])-float(row["bond_current"])) for row in data)<1e-12
        waves+=data
        if grid in (2,3):
            stem=f"bond-current-g{grid}-t2"
            assert json.loads((HERE/(stem+"-before-finite.json")).read_bytes())["prediction_hash"]==digest(HERE/(stem+".csv"))
            probe=read(stem+"-opposite-pulses.csv")
            assert len(probe)==15 and max(peak(probe,"forward_error"),peak(probe,"current_error"))<TOL
            refined+=probe
        else:
            prediction={(float(row["logtime"]),int(row["readout"])):float(row["prediction"]) for row in paired if row["model"]=="heavy" and row["t"]=="2" and row["g"]==str(grid) and row["species"]=="total"}
            assert max(abs(float(row["native_total"])-prediction[float(row["elapsed"]),int(row["shell"])]) for row in data)<1e-9
    assert max(peak(waves,"endpoint_error"),peak(waves,"quadrature_error"))<TOL
    contact=[float(row["total"]) for row in waves if int(row["shell"])==2 and float(row["elapsed"])==.004]
    assert len(contact)==4 and max(contact)<-TOL and abs(contact[2]-contact[3])<TOL
    assert abs(contact[1]-contact[2])>TOL
    fulltime=read("bond-current-g3-t1.csv")
    fine={float(row["elapsed"]):float(row["total"]) for row in waves if row["level"]=="3" and row["shell"]=="2"}
    time_defect=max(abs(float(row["total"])-fine[float(row["elapsed"])]) for row in fulltime if row["shell"]=="2")
    assert time_defect<TOL
    controls=json.loads((HERE/"analytic-controls.json").read_bytes())
    assert max(controls["stream"].values())<1e-9 and controls["wave_bond_orientation_error"]<1e-12
    optical=read("metric-light-transfer.csv");opposite=read("light-opposite-pulse-checks.csv");weak=read("light-weak-pulse-checks.csv")
    finer=read("light-finer-grids.csv")
    assert len(optical)==36 and len(opposite)==len(weak)==6 and len(finer)==12
    assert len(read("clock-manufactured-controls.csv"))==9 and peak(read("clock-manufactured-controls.csv"),"error")<2e-14
    entries=[row for row in optical if row["field"]=="variation"]
    force_def=max(abs(float(row["received"])-float(row["force_form"]))/float(row["pulse_scale"]) for row in entries)
    assert force_def<TOL
    misses=[(row["model"],int(row["shell"])) for row in opposite if abs(float(row["defect_on_drive_scale"]))>=TOL]
    assert misses==[("cold",0)] and peak(weak,"error_on_drive_scale")<TOL
    arrival={}
    for path in sorted(HERE.glob("arrival-*.csv")):
        packet=read(path.name)
        prediction=json.loads(path.with_name(path.stem+"-forecast.json").read_bytes())
        assert len(packet)==2*int(packet[0]["substeps"])
        for species in ("cdm","baryon"):
            track=[row for row in packet if row["species"]==species]
            assert float(track[-1]["forecast"])==prediction["eta_until_touch_mpc"][species]
            for row in track:
                assert (row["contact"]!="")==(float(row["in_C_mass"])>0)
                if not row["contact"]:assert abs(float(row["tagged_dD"]))<1e-23
            if species=="cdm":arrival[path.stem]=track[-1]
    assert len(arrival)==6
    positive=arrival["arrival-cold-g0-n8-s1"];negative=arrival["arrival-cold-g0-n8-s-1"]
    central=arrival["arrival-cold-g0-n8-s0"]
    assert float(negative["contact"])<float(central["contact"])<float(positive["contact"])
    assert not arrival["arrival-heavy-g0-n8-s0"]["contact"]
    difference=lambda name:.5*(float(positive[name])-float(negative[name]))
    captured=difference("tagged_dD")/difference("total_dD")
    assert abs(1-captured)<TOL
    stress=read("formed-tracefree-source.csv")
    assert len(stress)==24 and len(read("tracefree-electrovac-controls.csv"))==3
    assert peak(read("tracefree-electrovac-controls.csv"),"error")<1e-12
    stress_lookup={(row["model"],row["epoch"],int(row["level"]),int(row["order"])):row for row in stress}
    slip_checks=[]
    for model,epoch in product(("cold","heavy"),("start","end")):
        sample=lambda grid,order:float(stress_lookup[model,epoch,grid,order]["contrast_V_minus_U"])
        result=stress_lookup[model,epoch,2,10];value=sample(2,10)
        assert min(float(result[key]) for key in ("geometry","cdm","baryon","lapse_span"))>0
        assert (float(result["wave"])>0)==(model=="heavy")
        assert abs(sum(float(result[key]) for key in ("geometry","cdm","baryon","wave"))/value-1)<1e-14
        slip_checks.extend([abs(sample(1,10)/value-1),abs(sample(2,6)/value-1),abs(float(result["independent_wave_spline"])-float(result["wave"]))/value])
    assert max(slip_checks)<TOL
    times={}
    for model in ("heavy","cold"):
        seed,_,start=fixture(model,"start",0)
        times[model]=quad(lambda delta:1/seed.H(start*np.exp(delta)),0,.004)[0]*parsec*1e6/(1e3*C*Julian_year*1e6)
    return dict(parent_files=len(FILES),paired_predictions=len(paired),delta_time_myr=times,max_pulse_error=maximum,max_current_budget_error=balance,
        conservation=residuals,native_original_controls=len(old),higher_grid_pulse_error=peak(refined,"forward_error"),separated_common_scale=contact,
        finest_two_absolute_change=abs(contact[-1]-contact[-2]),finest_mesh_time_check=time_defect,max_bond_quadrature_change=peak(waves,"quadrature_error"),
        max_bond_vs_density=peak(waves,"endpoint_error"),light_force_integral_error=force_def,light_strong_misses=misses,
        light_strong_max=peak(opposite,"defect_on_drive_scale"),light_weak_max=peak(weak,"error_on_drive_scale"),
        cold_tagged_arrival_eta_mpc=float(central["contact"]),post_contact_tagged_fraction=captured,stress_max_comparison=max(slip_checks))
if __name__=="__main__":
    assert sys.argv[1:] in ([],["seal"])
    result=run();note("validation.json",result)
    seal=HERE/"seal.json"
    files={p.relative_to(HERE).as_posix():digest(p) for p in sorted(HERE.rglob("*")) if p.is_file() and p!=seal}
    if sys.argv[1:]==["seal"]:note("seal.json",dict(files=files,parent=SEAL))
    assert json.loads(seal.read_bytes())==dict(files=files,parent=SEAL)
    print(len(files),"files;",len(FILES),"parent files;",digest(seal),flush=True)

