"""Original shared-momentum dust and spectral-wave control at matched impulse and epochs."""
from inputs import *
from susceptibility import build
from wave_current import EPOCHS

def run():
    rows=[]
    for model in ("heavy","cold"):
        for level in (0,1):
            seed,state,a=fixture(model,"start",level)
            lab=ActionSystem(seed,state)
            weights,displacements,response,_,_=build(lab,a)
            diag=freeze_data(model,0)
            unit=.12*a/(C*max(abs(2*lab.r[1:]*np.diff(weights[0])/lab.square_width)))
            states=[]
            for sign in (-1,0,1):
                _,copy,_=fixture(model,"start",level)
                full=ActionSystem(seed,copy)
                for species,(_,p,_) in full.dust.items():p+=sign*unit*displacements[species][0]
                if full.psi is not None:full.psi*=np.exp(1j*seed.mass*sign*unit*weights[0])
                states.append(full)
            prior=0.
            for end in EPOCHS:
                guard();steps=round(8000*(end-prior))
                for count in range(steps):
                    low=a*np.exp(prior+(end-prior)*count/steps)
                    high=a*np.exp(prior+(end-prior)*(count+1)/steps)
                    for full in states:full.advance(low,high)
                force=np.stack([metric(full,high) for full in states])
                fin=(force[2]-force[0])/(2*unit)
                for site in range(3):
                    scale=np.sqrt(diag[site,site]*diag[0,0])
                    rows.append(dict(model=model,level=level,elapsed=end,shell=site,zero=force[1,site],
                        normalized=fin[site]/(end*scale),metric_per_unit=fin[site],
                        analytic_initial_response=sum(response.values())[site,0]/(seed.H(a)*scale)))
                prior=end
    table("native-comparison.csv",rows)
    print("Matched original controls",len(rows),flush=True)
if __name__=="__main__":run()

