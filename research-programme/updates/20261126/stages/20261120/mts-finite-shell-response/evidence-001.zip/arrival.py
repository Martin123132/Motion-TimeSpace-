"""Predict when a mass label originally inside the impulse first enters the distant shell."""
from light_history import Local,EPOCHS,clock
from inputs import *

RADIUS=.25

def ballistic(st,a):
    soon=np.inf
    for pos,mom in ((st.xl,st.pl),(st.xr,st.pr)):
        coord=pos[st.tag];vel=mom[st.tag]/a
        for direction in (-1.,1.):
            good=direction*vel>0
            if np.any(good):soon=min(soon,float(np.min((RADIUS-direction*coord[good])/(direction*vel[good]))))
    return soon

def crossing(st):
    candidate=np.inf
    for before,after in ((st.startl,st.xl),(st.startr,st.xr)):
        for sign in (-1.,1.):
            start=before*sign;end=after*sign
            select=st.tag&(start<RADIUS)&(end>=RADIUS)
            if np.any(select):candidate=min(candidate,float(np.min((RADIUS-start[select])/(end[select]-start[select]))))
    return candidate

def run(model,level,steps,sign):
    lab=Local(model,level,False,sign);a0=lab.initial
    prior=0.
    for end in EPOCHS:
        count=round((end-prior)*8000)
        for step in range(count):
            guard();lab.advance(a0*np.exp(prior+(end-prior)*step/count),a0*np.exp(prior+(end-prior)*(step+1)/count))
        prior=end
    first_a=a0*np.exp(.004);times=np.linspace(0.,.084,steps+1)
    scales=clock(lab.seed,first_a)(times)[0]
    stem=f"arrival-{model}-g{level}-n{steps}-s{sign}"
    control=lab.diagnostics(first_a)
    shot={-1:"minus",0:"zero",1:"plus"}[sign]
    reference=json.loads((HERE/f"{model}-g{level}-t2-{shot}-to0.004-checks.json").read_bytes())[-1]
    assert max(abs(np.array(reference["metric"])-control["metric"]))<1e-17
    forecast={key:ballistic(st,first_a) for key,st in lab.dust.items()}
    assert all(st.extent()<RADIUS for st in lab.dust.values()) and all(np.isfinite(list(forecast.values())))
    note(stem+"-forecast.json",dict(eta_until_touch_mpc=forecast,extent=control["max_A_tag_mpc"],sign=sign))
    actual={key:None for key in lab.dust}
    origin={key:val.copy() for key,val in lab.direct.items()};rows=[]
    for index in range(1,len(times)):
        guard();lab.advance(scales[index-1],scales[index])
        for key,st in lab.dust.items():
            dist=st.extent();outside=st.tag&(st.cells*lab.lab.h>=RADIUS)
            mass=float(np.sum(st.mu[outside]))
            if dist>RADIUS and actual[key] is None:
                fraction=crossing(st);assert 0<=fraction<=1
                actual[key]=times[index-1]+fraction*(times[index]-times[index-1])
            rows.append(dict(model=model,level=level,substeps=steps,sign=sign,species=key,eta=times[index],
                forecast=forecast[key],contact=actual[key],tag_max=dist,in_C_mass=mass,
                tagged_dD=(lab.direct[key][2]-origin[key][2]),total_dD=lab.read_metric(scales[index])[2]-reference["metric"][2],
                unit=lab.unit))
    table(stem+".csv",rows);print(stem,forecast,actual,flush=True)
if __name__=="__main__":run(sys.argv[1],int(sys.argv[2]),int(sys.argv[3]),int(sys.argv[4]))

