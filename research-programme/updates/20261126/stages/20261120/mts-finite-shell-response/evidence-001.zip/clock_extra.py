from clock_transfer import *

def extract(filename,field):
    with np.load(HERE/filename,allow_pickle=False) as data:
        rad,times,hub,values=data["r"],data["eta"],data["conformal_h"],data[field]
        return [ray(times,rad,values,hub,*shell) for shell in SHELLS]

def run():
    forecasts=read("metric-light-transfer.csv")
    weak=[];finer=[]
    for model in ("cold","heavy"):
        positive=extract(f"clock-{model}-g0-n16-weakpositive.npz","potential")
        negative=extract(f"clock-{model}-g0-n16-weaknegative.npz","potential")
        for site in range(3):
            reference,=[row for row in forecasts if row["model"]==model and row["field"]=="variation" and row["level"]=="0" and row["shell"]==str(site)]
            estimate=2*(positive[site]["received"]-negative[site]["received"])
            weak.append(dict(model=model,shell=site,nominal_speed=.03,rescaled_to_nominal=.12,
                predicted=float(reference["received"]),rescaled_finite=estimate,
                error_on_drive_scale=(estimate-float(reference["received"]))/float(reference["pulse_scale"])))
    for level in (2,3):
        path=f"clock-heavy-g{level}-n16-tangent.npz"
        for field in ("potential","variation"):
            for site,record in enumerate(extract(path,field)):
                finer.append(dict(level=level,model="heavy",field=field,shell=site,**record))
    table("light-weak-pulse-checks.csv",weak);table("light-finer-grids.csv",finer)
    print(weak,flush=True)
if __name__=="__main__":run()

