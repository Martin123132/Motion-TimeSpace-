from inputs import *
def study(model,g,t,stop=.004):
    prefix=f"{model}-g{g}-t{t}-"
    suffix=f"-to{stop:g}"
    get=lambda mode:read(prefix+mode+suffix+".csv")
    seal=json.loads((HERE/(prefix+"prediction"+suffix+"-freeze.json")).read_bytes())
    assert seal["predictions"]==digest(HERE/(prefix+"prediction"+suffix+".csv"))
    rows=get("prediction");zero=get("zero");new=[]
    data=[(speed,get(s1),get(s2)) for speed,s1,s2 in ((.12,"plus","minus"),(.03,"weakplus","weakminus"))]
    for i,r in enumerate(rows):
        key=("logtime","readout","species")
        assert all(r[k]==zero[i][k] for k in key)
        assert abs(float(r["metric"])-float(zero[i]["metric"]))<1e-15
        dt=float(r["logtime"])
        if not dt:continue
        scale=float(r["diagonal_scale"])*dt
        pred=float(r["tangent"])/scale
        for vel,plus,minus in data:
            pos=plus[i];neg=minus[i];assert all(pos[k]==neg[k]==r[k] for k in key)
            normal=2*float(pos["unit"])*scale
            val=(float(pos["metric"])-float(neg["metric"]))/normal
            observed=(float(pos["transport"])-float(neg["transport"]))/normal
            direct=(float(pos["directly_driven_stream_transport"])-float(neg["directly_driven_stream_transport"]))/normal
            new.append(dict(model=model,g=g,t=t,logtime=dt,readout=int(r["readout"]),species=r["species"],speed=vel,prediction=pred,
                    measured=val,discrepancy=val-pred,from_current=observed,source_defect=val-observed,initially_pushed_streams=direct))
    return new
if __name__=="__main__":
    rows=[]
    for model in ("heavy","cold"):
        for g,t in ((0,1),(1,1),(0,2),(1,2)):rows.extend(study(model,g,t))
    table("paired-forward-tests.csv",rows)
    for model in ("heavy","cold"):
        for g,t in ((0,1),(1,1),(0,2),(1,2)):
            sel=[x for x in rows if x["species"]=="total" and x["model"]==model and x["g"]==g and x["t"]==t]
            print(model,g,t,max(abs(x["discrepancy"]) for x in sel),max(abs(x["source_defect"]) for x in sel))

