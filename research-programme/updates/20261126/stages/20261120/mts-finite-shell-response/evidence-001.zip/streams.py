from inputs import *
from local_impulse import split
from copy import copy

class Streams:
    def __init__(self,lab,key,tangent):
        x,p,dm=lab.dust[key];self.lab=lab;self.key=key;self.tangent=tangent
        self.ids=np.arange(len(dm));self.scale=dm/(self.ids**2+self.ids+1/3)
        self.ql=np.zeros(len(dm));self.qr=np.ones(len(dm))
        self.xl=x[:-1].copy();self.xr=x[1:].copy();self.pl=p[:-1].copy();self.pr=p[1:].copy()
        self.tag=np.zeros(len(dm),bool);self.mass0=np.sum(dm);self.impulse=0.;self.work=0.
        if tangent:
            for k in ("ql","qr","xl","xr","pl","pr"):setattr(self,"d"+k,np.zeros(len(dm)))
        self.cut()
    def cut(self,path=None):
        h=self.lab.h;n=self.lab.n
        ix,bin_id,first,last=split(self.xl,self.xr,h,n)
        assert len(ix)<5_000_000,"segment capacity; save a shorter run"
        width=self.qr-self.ql
        def lerp(lo,hi,f):
            return np.where(f==1,hi[ix],lo[ix]+f*(hi[ix]-lo[ix]))
        q1=lerp(self.ql,self.qr,first);q2=lerp(self.ql,self.qr,last)
        good=q1<q2
        ix=ix[good];cells=bin_id[good];first=first[good];last=last[good];q1=q1[good];q2=q2[good]
        oldcells=self.cells[ix] if path is not None else None
        result={}
        for suffix,fraction,q in (("l",first,q1),("r",last,q2)):
            xp=lerp(self.xl,self.xr,fraction)
            internal=(fraction>0)&(fraction<1)
            xp[internal]=np.rint(xp[internal]/h)*h
            result["x"+suffix]=xp;result["q"+suffix]=q;result["p"+suffix]=lerp(self.pl,self.pr,fraction)
            if path is not None:result["start"+suffix]=lerp(path[0],path[1],fraction)
            if self.tangent:
                dpos=lerp(self.dxl,self.dxr,fraction)
                df=np.divide(-dpos,self.xr[ix]-self.xl[ix],out=np.zeros(len(ix)),where=internal)
                result["dx"+suffix]=np.where(internal,0.,dpos)
                result["dq"+suffix]=lerp(self.dql,self.dqr,fraction)+df*width[ix]
                result["dp"+suffix]=lerp(self.dpl,self.dpr,fraction)+df*(self.pr[ix]-self.pl[ix])
                if path is not None:result["dstart"+suffix]=lerp(path[2],path[3],fraction)+df*(path[1][ix]-path[0][ix])
        self.cells=cells;self.ids=self.ids[ix];self.tag=self.tag[ix]
        for name,val in result.items():setattr(self,name,val)
        self.oldcells=oldcells
        a=self.ql;b=self.qr;self.Q=self.ids+.5*(a+b);self.U=.5*(b-a)
        self.scale2=self.scale[self.ids]*(b-a)
        den=self.Q**2+self.U**2/3;self.mu=self.scale2*den
        self.m1=self.scale2*2*self.Q*self.U/3
        self.m2=self.scale2*(self.Q**2/3+self.U**2/5)
        if self.tangent:
            dq=.5*(self.dql+self.dqr);du=.5*(self.dqr-self.dql);norm=self.scale[self.ids]*2*du
            self.dmu=norm*den+self.scale2*(2*self.Q*dq+2*self.U*du/3)
            self.dm1=norm*2*self.Q*self.U/3+self.scale2*2*(dq*self.U+self.Q*du)/3
            self.dm2=norm*(self.Q**2/3+self.U**2/5)+self.scale2*(2*self.Q*dq/3+2*self.U*du/5)
    def measure(self):
        lab=self.lab;cells=self.cells;mid=.5*(self.xl+self.xr);half=.5*(self.xr-self.xl);low=lab.r[cells]
        centered=(mid-low)*(mid+low)
        right=(self.mu*centered+2*mid*half*self.m1+half**2*self.m2)/lab.square_width[cells]
        add=lambda whole,offset:np.r_[np.bincount(cells,weights=whole-offset,minlength=lab.n),0.]+np.r_[0.,np.bincount(cells,weights=offset,minlength=lab.n)]
        out=add(self.mu,right)
        if not self.tangent:return out,None
        dx=.5*(self.dxl+self.dxr);dy=.5*(self.dxr-self.dxl)
        dr=(self.dmu*centered+2*self.mu*mid*dx+2*(dx*half+mid*dy)*self.m1+2*mid*half*self.dm1+2*half*dy*self.m2+half**2*self.dm2)/lab.square_width[cells]
        return out,add(self.dmu,dr)
    def kick(self,factor,dfactor,delta):
        cells=self.cells;sl=factor[cells]
        fl=self.xl*sl;fr=self.xr*sl
        fl[self.xl==0]=0.;fr[self.xr==self.lab.L]=0.
        amount=delta*.5*((self.mu-self.m1)*fl+(self.mu+self.m1)*fr)
        self.impulse+=np.sum(amount);self.work+=np.sum(abs(amount))
        self.pl=self.pl+delta*fl;self.pr=self.pr+delta*fr
        if self.tangent:
            ds=dfactor[cells]
            dl=self.dxl*sl+self.xl*ds;dr=self.dxr*sl+self.xr*ds
            dl[self.xl==0]=0.;dr[self.xr==self.lab.L]=0.
            self.dpl+=delta*dl;self.dpr+=delta*dr
    def momentum(self):return .5*np.sum((self.mu-self.m1)*self.pl+(self.mu+self.m1)*self.pr)
    def drift(self,delta):
        path=(self.xl,self.xr)
        self.xl=self.xl+delta*self.pl;self.xr=self.xr+delta*self.pr
        if self.tangent:
            path+=self.dxl,self.dxr
            self.dxl=self.dxl+delta*self.dpl;self.dxr=self.dxr+delta*self.dpr
        assert max(np.max(abs(self.xl)),np.max(abs(self.xr)))<=self.lab.L+1e-12
        self.cut(path)
    def transported(self,weights):
        old=self.oldcells;new=self.cells
        chosen=np.minimum(old,new)<=round(.35/self.lab.h)
        chosen&=np.maximum(old,new)>=round(.1/self.lab.h)
        pick=np.flatnonzero(chosen)
        before=old[pick];after=new[pick];idx=self.lab.r;sw=self.lab.square_width
        mu=self.mu[pick];m1=self.m1[pick];m2=self.m2[pick];tags=self.tag[pick]
        lo=self.startl[pick];hi=self.startr[pick];pl=self.xl[pick];pr=self.xr[pick]
        x=.5*(lo+hi);y=.5*(hi-lo);z=.5*(pl+pr);v=.5*(pr-pl)
        def partial(cell,x,y):
            return (mu*(x-idx[cell])*(x+idx[cell])+2*x*y*m1+y*y*m2)/sw[cell]
        strip0=partial(before,x,y);strip1=partial(after,z,v)
        dweight=np.diff(weights,axis=1)
        same=before==after
        dist=(mu*(z-x)*(z+x)+2*(z*v-x*y)*m1+(v-y)*(v+y)*m2)/sw[before]
        value=mu*(weights[:,after]-weights[:,before])+dweight[:,after]*strip1-dweight[:,before]*strip0
        value[:,same]=dweight[:,before[same]]*dist[same]
        return value.sum(axis=1),value[:,tags].sum(axis=1)
    def extent(self):
        r=np.maximum(abs(self.xl[self.tag]),abs(self.xr[self.tag]))
        return max(r,default=0.)

