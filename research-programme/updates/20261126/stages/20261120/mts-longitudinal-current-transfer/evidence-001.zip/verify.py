"""Read-only by default. Seal only after numerical gates and replay."""
import csv
import hashlib
import json
import sys
from pathlib import Path

HOME = Path(__file__).resolve().parent


def digest(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream,"sha256").hexdigest()


def read(name):
    with (HOME/name).open(newline="") as stream:
        return list(csv.DictReader(stream))


component = read("component-integrals.csv")
paired = read("matched-differences.csv")
controls = read("controls.csv")
assert {(int(row["seed"]),int(row["flag"]),float(row["width"]),float(row["fraction"])) for row in component} == {
    (sign,flag,width,part/8) for sign in (-1,1) for flag in (0,1) for width in (.15,.30) for part in range(9)}
assert len(component)==72 and len(paired)==32 and len(controls)==2
assert {(int(row["seed"]),float(row["width"]),float(row["fraction"])) for row in paired} == {
    (sign,width,part/8) for sign in (-1,1) for width in (.15,.30) for part in range(1,9)}
assert max(abs(float(row["reconstruction_ppm"])) for row in paired)<20
assert max(abs(float(row["continuum_exterior_error_ppm"])) for row in paired)<20
assert max(abs(float(row["exterior_relative"])) for row in controls)<1e-10
names=("RESULTS.md","current_transfer.py","verify.py","component-integrals.csv","matched-differences.csv","controls.csv")
record=dict(files={name:digest(HOME/name) for name in names},rows=dict(branch=72,contrast=32,analytic=2))
seal=HOME/"seal.json"
if sys.argv[1:]==["--seal"] and not seal.exists():
    with seal.open("xb") as stream:
        stream.write((json.dumps(record,sort_keys=True,indent=2)+"\n").encode())
else:
    assert sys.argv[1:] in ([],["--seal"])
assert json.loads(seal.read_bytes())==record
print(digest(seal), "verified",len(record["files"]),"files")
