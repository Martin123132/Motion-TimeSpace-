"""Fixed proper-clock test of the longitudinal tidal current using saved matter states."""
import csv
import hashlib
import io
import json
import os
import sys
from pathlib import Path

for variable in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "NUMEXPR_NUM_THREADS"):
    os.environ[variable] = "1"
sys.dont_write_bytecode = True
HOME = Path(__file__).resolve().parent
ROOT = HOME.parent
FAMILY = ROOT / "mts-matched-speed-family-20261120"
CLOCK = ROOT / "mts-newton-cloud-clock-20261120"
LAST = ROOT / "mts-late-tide-refinement-20261120"


def digest(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


assert digest(LAST / "seal.json") == "d45b046512700d79c3c2945f376883890eecb52743a05a5b15aeeb3dca265e1c"
assert digest(FAMILY / "seal.json") == "f462610a670f37c2b10cec2ae3660d5736533fbd0d5b8cd7f231a8f485c84f35"
assert digest(CLOCK / "clock_tide.py") == "f62114868c8834a1ff5dcf52f4d054668e9d494f69eb9c727c3a5d5db4da1559"
registry = json.loads((FAMILY / "seal.json").read_bytes())["files"]
for name in ("newton_history.py", "family.py", "newton-time-h5.csv"):
    assert digest(FAMILY / name) == registry[name]
sys.path[:0] = [str(FAMILY), str(CLOCK)]
import newton_history as saved
import clock_tide as clock
from numpy import array, exp
import numpy as np
from scipy.integrate import simpson
from scipy.optimize import brentq


def guard():
    saved.guard()
    assert not (HOME / "STOP-REQUESTED").exists()


def dump(name, rows):
    buf = io.StringIO(newline="")
    writer = csv.DictWriter(buf, fieldnames=list(rows[0]), lineterminator="\n")
    writer.writeheader()
    writer.writerows(rows)
    path = HOME / name
    data = buf.getvalue().encode()
    if path.exists():
        assert path.read_bytes() == data, path
    else:
        with path.open("xb") as handle:
            handle.write(data)


def dual_terms(mesh, row, radial, angular, edge):
    dual = mesh.quad(row / mesh.m)
    radial_term = np.sum((dual @ mesh.der.T) * mesh.radw * radial)
    angular_term = 6 * np.sum(dual * mesh.qw * angular)
    boundary = -mesh.edge**2 * dual[-1, -1] * edge
    return array([radial_term, angular_term, boundary])


def flux(sim, state, time, flag, matter):
    mesh = sim.mesh
    mono, density, phase = state
    contrast = mesh.gauges(mono[0])[0]
    speed = mesh.gauges(mono[1])[1]
    incident_d, incident_v, incident_slope, _ = sim.data(time)
    number = 1 + contrast[:, mesh.elem]
    drift = speed[:, mesh.elem]
    wave_phase = mesh.quad(phase[flag])
    induced_radial = number * (wave_phase @ mesh.der.T) + drift * mesh.quad(density[flag])
    incident_radial = contrast[:, mesh.elem] * incident_slope[flag][:, mesh.elem] + drift * incident_d[flag][:, mesh.elem]
    induced_angular = number * wave_phase
    incident_angular = contrast[:, mesh.elem] * incident_v[flag][:, mesh.elem]
    induced_edge = -(3 / mesh.edge) * number[:, -1, -1] * phase[flag, :, -1] + speed[:, -1] * density[flag, :, -1]
    return [(np.einsum("s,sij->ij", matter, radial), np.einsum("s,sij->ij", matter, angular), matter @ edge)
            for radial, angular, edge in ((induced_radial, induced_angular, induced_edge),
                                          (incident_radial, incident_angular, incident_radial[:, -1, -1]))]


def exterior(mesh, radial, angular, edge, cut):
    idx = int(round(cut / mesh.h))
    assert mesh.loc[idx, 0] == cut
    radius = mesh.loc[idx:]
    left, right = radial[idx - 1, -1], radial[idx, 0]
    return array([(left + right) / (10 * cut), -edge / (5 * mesh.edge),
                  np.sum(mesh.qw * (-3 * radial[idx:] / radius**2 + 6 * angular[idx:] / radius**3)) / 5,
                  (right - left) / (10 * cut)])


def controls(mesh, kernel):
    cut = 6.
    radius = mesh.loc
    field = mesh.r[1:]**2
    row = kernel.rows(1.35)[0]
    controls = []
    for label, radial, angular, density_rate in (
            ("radial_outflow", radius**3, 0 * radius, -5 * field),
            ("angular_only", 0 * radius, radius**4, 6 * field)):
        answer = row @ density_rate
        result = sum(dual_terms(mesh, row, radial, angular, radial[-1,-1]))
        assert abs(result - answer) < 1e-10 * abs(answer)
        shell = exterior(mesh, radial, angular, radial[-1,-1], cut)
        predicted = kernel.rows(cut)[4] @ density_rate
        assert abs(sum(shell[:3]) - predicted) < 1e-10 * abs(predicted)
        controls.append(dict(control=label, aperture_relative=abs(result/answer-1),
                             exterior_relative=abs(sum(shell[:3])/predicted-1)))
    return controls


KEYS = ("induced_radial", "induced_angular", "induced_edge", "incident_radial", "incident_angular",
        "incident_edge", "dilution", "ruler", "exterior_dual_rate", "cut_flux", "far_flux",
        "exterior_bulk", "half_flux_jump", "exterior_dilution")


def run():
    guard()
    ref = {}
    with (FAMILY / "newton-time-h5.csv").open() as stream:
        for row in csv.DictReader(stream):
            ref[int(row["seed"]), int(row["flag"]), float(row["width"]), float(row["fraction"])] = float(row["integral_total"])
    sim = saved.BalancedNative("heavy",120,600,False,"native36",clock.START+.00002)
    mesh = sim.mesh
    traces = clock.Traces("heavy", sim)
    sim.patch.coeff = lambda time: (float(traces.hubble(time-clock.START)), clock.SCALE*exp(time-clock.START))
    sim.ref.solution = lambda time: traces.histories(time-clock.START, "normal")
    kernel = clock.Kernel(mesh)
    tests = controls(mesh, kernel)
    matter = sim.patch.p.coeff/clock.SCALE
    fraction = np.arange(33)/32
    clocks = [brentq(lambda value:float(traces.proper(value))-frac*saved.DURATION, 0., traces.proper.x[-1], xtol=5e-16) if frac else 0. for frac in fraction]
    offsets = traces.log_time(clocks)
    clock_rates = traces.log_time(clocks, 1)/traces.proper(clocks, 1)
    targets = saved.windows(5)
    matrices = []
    for offset in offsets:
        pairs = []
        for points, weights in targets:
            radii = points*exp(-offset)
            kernels = array([kernel.rows(float(radius))[:2] for radius in radii])
            pairs.append((weights @ kernels[:,0], (weights*radii) @ kernels[:,1]))
        matrices.append(pairs)
    external = kernel.rows(6.)[4]
    records, contrasts = [], []
    by_key = {}
    for seed in (1,-1):
        name = "evolved-heavy-L120-h5-t176.npz" if seed==1 else "collar-heavy-L120-h5--1.npz"
        with np.load(clock.checked(clock.FORM, name)) as archive:
            initial = tuple(archive[key] for key in ("mono","density","velocity"))
        for flag in (0,1):
            sim.patch.wave = not flag
            summed = [np.zeros_like(comp) for comp in initial]
            profile = []
            for idx,(offset,rate) in enumerate(zip(offsets,clock_rates)):
                guard()
                time = clock.START+offset
                state = tuple(start+inc for start,inc in zip(initial,summed))
                number = matter @ state[1][flag]
                currents = flux(sim,state,time,flag,matter)
                total_current = [sum(parts) for parts in zip(*currents)]
                factor = rate*exp(-3*offset)
                hub = sim.patch.coeff(time)[0]
                far = sum(dual_terms(mesh,external,*total_current))
                shells = exterior(mesh,*total_current,6.)
                samples = []
                for row, gradient in matrices[idx]:
                    terms = np.r_[dual_terms(mesh,row,*currents[0]),dual_terms(mesh,row,*currents[1])]/hub
                    samples.append(factor*np.r_[terms,-3*(row@number),-gradient@number,
                                                far/hub,shells/hub,-3*(external@number)])
                profile.append(samples)
                if idx%4==0:
                    vals = simpson(array(profile),dx=saved.DURATION/32,axis=0) if idx else np.zeros_like(samples)
                    for width, result in zip(saved.FRACTIONS,vals):
                        key = (seed,flag,width,fraction[idx])
                        by_key[key] = result
                        records.append(dict(seed=seed,flag=flag,width=width,fraction=fraction[idx],
                                            **dict(zip(KEYS,result)), reconstruction=sum(result[:8]), reference=ref[key]))
                if idx==32:
                    break
                step = offsets[idx+1]-offset
                slopes = [sim.rates(state,time)]
                for prop in (.5,.5,1.):
                    mid = tuple(start+(inc+prop*step*slope) for start,inc,slope in zip(initial,summed,slopes[-1]))
                    slopes.append(sim.rates(mid,time+prop*step))
                for inc,derivs in zip(summed,zip(*slopes)):
                    inc += step*(derivs[0]+2*derivs[1]+2*derivs[2]+derivs[3])/6
    assert len(ref) == len(records) == len(by_key) == 72
    for record in records:
        assert abs(record["reference"] - record["reconstruction"]) <= 20e-6 * abs(record["reference"])
    for seed in (1,-1):
        for width in saved.FRACTIONS:
            for frac in fraction[4::4]:
                left,right=(seed,0,width,frac),(seed,1,width,frac)
                values=by_key[left]-by_key[right]
                reference=ref[left]-ref[right]
                error=(sum(values[:8])-reference)/abs(reference)*1e6
                assert abs(error)<20, (left,error)
                contrasts.append(dict(seed=seed,width=width,fraction=frac,reference=reference,
                                      **dict(zip(KEYS,values)),reconstruction_ppm=error,
                                      exterior_net=(values[8]+values[13])/reference,
                                      continuum_exterior_error_ppm=(sum(values[9:12])-values[8])/abs(reference)*1e6))
    assert max(abs(row["continuum_exterior_error_ppm"]) for row in contrasts) < 20
    dump("controls.csv",tests)
    dump("component-integrals.csv",records)
    dump("matched-differences.csv",contrasts)
    print(f"{len(records)} histories/readouts; {len(contrasts)} nonzero paired increments; "
          f"max residual {max(abs(row['reconstruction_ppm']) for row in contrasts):.6g} ppm",flush=True)


if __name__ == "__main__":
    run()
