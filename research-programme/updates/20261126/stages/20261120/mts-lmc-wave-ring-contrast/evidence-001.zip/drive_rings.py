from ring_operator import *
from functools import lru_cache
@lru_cache(maxsize=1)
def pins():return json.loads((QUAD/"seal.json").read_bytes())["files"]
def bank(history,complete):
    path=f"complete/{history}.npz" if complete else f"sources/{history}-r192-l24-q28-t16.npz"
    assert ls.old.digest(QUAD/path)==pins()[path]
    with np.load(QUAD/path) as source:return source["radius"],source["times"],source["quad" if complete else "V"]
def projection_map(op,points,degrees):
    modes=op["modes"];nl=len(op["ell"]);nr=len(op["rad"]);q=op["block"];rank=q.shape[-1]
    beyond=op["rad"]>points[-1]
    assert not np.any(op["wave"][beyond]) and op["rad"].min()>points[0]
    inter=CubicSpline(points,np.eye(len(points)),axis=0)(np.minimum(op["rad"],points[-1]));inter[beyond]=0.
    inc=basis(degrees,2,op["mu"]);ym=basis(op["ell"],2,op["mu"])
    mapped=[]
    for idx in range(nl):
        weight=op["wave"]@((op["aw"]*ym[:,idx])[:,None]*inc)*op["root"][:,None]/op["vel"]**2
        mapped.append((inter.T@(weight[:,:,None]*q[idx,:,None,:]).reshape(nr,-1)).reshape(len(points)*len(degrees),rank))
    return np.column_stack(mapped)@modes
def pair(src,mapping):
    storage=src.reshape(len(src),-1)
    return np.ascontiguousarray(storage.real)@mapping+1j*(np.ascontiguousarray(storage.imag)@mapping)
def transfer(time,drive,sigma,op,start):
    tau=time*op["vel"]/op["length"];dt=tau[-1]-tau[0]
    def one(field):return integrate(2*field,tau,sigma)[-1]
    zr,zi=one(drive.real),one(drive.imag)
    pos=zr.real+1j*zi.real;velocity=(zr.imag+1j*zi.imag)*sigma
    delta=-2*drive[0]/sigma**2;idx=np.where(time<=time[0]+.0625+1e-10)[0]
    rate=-2*CubicSpline(tau[idx],drive[idx],axis=0)(tau[0],1)/sigma**2
    return np.stack([pos,velocity,delta*np.cos(sigma*dt)+rate*np.sin(sigma*dt)/sigma,
                         -delta*sigma*np.sin(sigma*dt)+rate*np.cos(sigma*dt)])
def sites(pos,op):
    fields=(op["sky"]@pos).reshape(3,3)*[1,1,1j]
    alt=(op["green"]@pos).reshape(3,3)*[1,1,1j]
    return 2*fields.real,2*(np.exp(2j*AXIS)*fields).real,2*abs(fields-alt)
def run(occ,keep,era="new",targets=()):
    guard();tag=f"{era}-{occ}-k{keep}"
    with np.load(HERE/f"operator-{tag}.npz") as f:op={k:f[k] for k in f.files}
    sigma=op["sigma"];maps={};names=fixed.prep.ms.MODELS if not targets else targets
    for hist in names:
        guard();signals={};records=[];checks=[]
        def calc(group,r,t,v,degrees,space=1):
            key=(group,space);top=len(degrees);rs=r[::space]
            if key not in maps:maps[key]=projection_map(op,rs,degrees)
            return pair(v[:,::space,:],maps[key])
        for complete in (False,True):
            radius,time,values=bank(hist,complete)
            if complete:
                high=calc("high",radius,time,values[:,:,12:],np.arange(26,71,2))
                low=calc("low2",radius,time,values[:,:,:12],np.arange(2,25,2))
                signals["high8"]=transfer(time,high,sigma,op,0);signals["high4"]=transfer(time[::2],high[::2],sigma,op,0)
                signals["otherlow8"]=transfer(time,low,sigma,op,0)
                del high,low
            else:
                low=calc("low",radius,time,values,np.arange(2,25,2))
                signals["low16"]=transfer(time,low,sigma,op,0);signals["low8"]=transfer(time[::2],low[::2],sigma,op,0)
                thin=calc("low",radius,time,values,np.arange(2,25,2),2)
                signals["thin16"]=transfer(time,thin,sigma,op,0);del thin
                samples=[0,1,2,3,4,5,6,7]
                packet(f"forcing-control-{tag}-{hist}",time=time,source=low[:,samples],sigma=sigma[samples],vel=op["vel"],length=op["length"])
                del low
            del values
        variants=dict(primary=signals["low16"]+signals["high8"],low_only=signals["low16"],
                      time_half=signals["low8"]+signals["high4"],radial_half=signals["thin16"]+signals["high8"],
                      complete8=signals["otherlow8"]+signals["high8"],low8=signals["low8"])
        for label,data in variants.items():
            for initial in ("zero","equilibrium_slope"):
                pos=data[0] if initial=="zero" else data[0]+data[2]
                site,cos,err=sites(pos,op)
                for idx,(cyl,z) in enumerate(SITES):
                    for j,component in enumerate(("radial","polar","azimuthal")):
                        records.append(dict(history=hist,variant=label,initial=initial,R=cyl,z=z,component=component,meridian=site[idx,j],
                                            bar_axis_cosine=cos[idx,j],independent_green_absolute=err[idx,j]))
        best=variants["primary"];q=op["block"]
        field=np.einsum("lrk,lk->rl",q,(op["modes"]@best[0]).reshape(len(q),-1))
        moment=op["wave"]*((field/op["root"][:,None])@basis(op["ell"],2,op["mu"]).T)
        density=(moment@(op["aw"][:,None]*basis(op["ell"],2,op["mu"])))/(op["rad"][:,None]/op["length"])**2
        packet(f"state-{tag}-{hist}",rho2=density,rad=op["rad"],orders=op["ell"],pos=best[0],velocity=best[1],seed_pos=best[2],seed_velocity=best[3],low_only_pos=signals["low16"][0],low_only_vel=signals["low16"][1],sigma=sigma)
        table(f"response-{tag}-{hist}",records)
        print(tag,hist,[(r["R"],r["bar_axis_cosine"]) for r in records[:9] if r["component"]=="azimuthal"],flush=True)
if __name__=="__main__":run(int(sys.argv[1]),int(sys.argv[2]),sys.argv[3],sys.argv[4:])
