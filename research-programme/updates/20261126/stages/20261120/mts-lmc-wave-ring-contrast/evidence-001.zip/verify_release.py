import ast
import csv
import hashlib
import json
import sys
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parent
PARENT = ROOT.parent
PREVIOUS = PARENT / "mts-coherent-extended-bar-response-20261120"
AXIS = PARENT / "mts-lmc-fixed-occupation-axisymmetric-20261119"
QUAD = PARENT / "mts-lmc-live-quadrupole-20261119"
HOST = PARENT / "mts-live-host-halo-comparison-20261120"
HISTORIES = ("L2M10","L2M10first","L2M11","L3M10","L3M10rad","L3M11")
TOL = 2e-5

def sha(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()

def rows(path):
    with path.open(newline="", encoding="utf-8") as stream:
        reader = csv.DictReader(stream)
        assert reader.fieldnames and len(reader.fieldnames) == len(set(reader.fieldnames)), path
        data = list(reader)
    assert data and all(None not in row and None not in row.values() for row in data), path
    return data

def pinned(folder, names=None):
    inventory = json.loads((folder/"seal.json").read_bytes())["files"]
    keys = list(inventory) if names is None else list(names)
    assert all(sha(folder/key) == inventory[key] for key in keys), folder
    return len(keys)

def span(data):
    return [min(data), max(data)]

def save(name, obj):
    content = (json.dumps(obj, sort_keys=True, indent=2, allow_nan=False)+"\n").encode()
    path = ROOT/name
    if path.exists():
        assert path.read_bytes() == content, path
    else:
        with path.open("xb") as stream:
            stream.write(content)

def run():
    import numpy as np
    assert sha(PREVIOUS/"seal.json") == "9be91621de20ee5630d865f409d3ca87f992a889718482d63a1c5ebe5e23c014"
    assert sha(AXIS/"seal.json") == "a46d251285faaba640cea0288634284d6d3046a9693e934921a28936060c6f70"
    assert sha(QUAD/"seal.json") == "14328952cd5b8ed0c9b8d000f9d26f13e86a1fbaae2951c586eccdd010420df2"
    previous = pinned(PREVIOUS)
    sources = pinned(AXIS,[f"shell-{h}-r320-l40-q36-t16.npz" for h in HISTORIES])
    satellite = pinned(QUAD,[s for h in HISTORIES for s in (f"complete/{h}.npz",f"sources/{h}-r192-l24-q28-t16.npz")]+["operators/1-64.npz"]+[f"states/1-64-{h}-r192-l24-t16-d1.npz" for h in ("L2M10first","L3M11")])
    native = pinned(HOST,["host-inputs.csv","native-build.csv","common-forces.csv","signed-forces.csv"]+[r["path"] for r in rows(HOST/"host-inputs.csv")])
    original = PARENT/"mts-lmc-axisymmetric-retarded-replay-20261120"/"replay.json"
    assert sha(original) == "ac3e29395d6ceeeca6a4dfb52528cf429c000dcdd981ddd14650ed9e95840cbf"
    original_data = json.loads(original.read_bytes())
    assert len(original_data["controls"])==12 and len(original_data["bands"])==192
    for path in ROOT.glob("*.py"):
        ast.parse(path.read_text(encoding="utf-8"))
    for path in ROOT.glob("*.csv"):
        rows(path)
    read = lambda name: rows(ROOT/(name+".csv"))
    signed = read("fixed-sky")
    assert len(signed)==768 and all((float(r["low"])<=float(r["total"])<=float(r["high"]))==(r["inside"]=="True") for r in signed)
    assert all(abs(float(r["with_bar_m0_direct"])+float(r["satellite_m2"])-float(r["total"]))<1e-13 for r in signed)
    assert all(int(r["count"])==2 for r in read("fixed-panels"))
    rings = [r for r in read("fixed-rings") if r["contrast"]=="tide"]
    assert len(rings)==24 and all(float(r["bar_wave"])>0 and float(r["corrected_MTS"])<0 and float(r["corrected_static"])==0 for r in rings)
    assert all(abs(float(r["raw_MTS"])-float(r["direct_LMC"])-float(r["LMC_wave"])-float(r["bar_wave"]))<1e-14 for r in rings)
    checks = []; counts = {}; refinements = []; ranges = {}; cases = set()
    for idx in range(12):
        tag=f"{idx}-k64"
        panels=read("matched-panels-"+tag); axis=read("matched-axis-only-"+tag)
        meta=read(f"host-ground-{idx}")[0]; cases.add((meta["history"],meta["representation"]))
        assert abs(float(meta["residual_dark"]))<1e-10 and float(meta["stationarity"])<1e-10
        assert len(axis)==32 and len(panels)==20
        for row in panels:
            counts.setdefault(row["model"],set()).add(int(row["count"]))
        for policy in {r["initial"] for r in axis}:
            for frame in {r["frame"] for r in axis}:
                sample=[r for r in axis if (r["initial"],r["frame"])==(policy,frame)]
                assert len(sample)==8 and len({(r["R"],r["z"],r["component"]) for r in sample})==8
                counts.setdefault("MTS_m0_only",set()).add(sum(r["inside"]=="True" for r in sample))
                assert all((float(r["low"])<=float(r["total"])<=float(r["high"]))==(r["inside"]=="True") for r in sample)
                if policy=="zero" and frame=="archive_accelerating":
                    for row in sample:
                        if float(row["z"])>0:
                            ranges.setdefault(row["R"]+"_"+row["component"],[]).append(float(row["induced_m0"]))
        with np.load(ROOT/("matched-axis-density-"+tag+".npz")) as signal:
            density=signal["delta_density"]; assert density.shape==signal["displacement"].shape
            assert np.all(np.isfinite(density)) and np.max(abs(density))>0
            ground,displacement=signal["ground"],signal["displacement"]
            number=abs(2*np.sum(ground*displacement)/np.sum(ground**2))
            assert number<1e-12
            for row in axis:
                part=(0 if row["R"]=="6.0" else 2)+int(row["component"]=="polar")
                expected=signal["induced_north" if row["initial"]=="zero" else "induced_north_equilibrium_slope"][part]
                if float(row["z"])<0 and row["component"]=="polar":expected=-expected
                assert abs(expected-float(row["induced_m0"]))<1e-14
                assert abs(float(row["frozen"])+expected-float(row["total"]))<1e-14
            controls=read("matched-axis-control-"+tag)[0]
            density_error=float(controls["max_density_error"]); time_error=float(controls["max_time_absolute"])
            timestep_relative=float(np.max(abs(signal["induced_north_half_time"]/signal["induced_north"]-1)))
            checks.append((number,density_error,time_error,timestep_relative))
            if idx in (0,11):
                with np.load(ROOT/f"matched-axis-density-{idx}-k88.npz") as fine:
                    refinements.append(float(np.max(abs(fine["induced_north"]/signal["induced_north"]-1))))
    assert len(cases)==12 and len(set(h for h,rep in cases))==6
    assert counts["MTS_m0_only"]==counts["frozen_MTS"]=={6} and counts["outer_matched_static_NFW"]=={4}
    assert max(v[1] for v in checks)<1e-11
    pre=[r for occ in (0,1) for r in read(f"prehistory-{occ}")]
    assert len(pre)==24 and all(float(r["necessary_over_one_way"])>1 for r in pre)
    for occ in (0,1):
        for row in read(f"separation-checks-{occ}"):
            assert abs(float(row["remainder_check"]))<1e-12 and float(row["relative_field_check"])<1e-10
    for row in read("quadrature-control"):
        assert max(float(row[k]) for k in ("position_relative","velocity_relative"))<2e-10
    assert max(float(r["relative"]) for r in read("refinements") if r["contrast"]=="tide")<TOL
    zero=[r for r in rings if r["initial"]=="zero"]
    results=dict(previous_files=previous,axis_inputs=sources,quadrupole_inputs=satellite,host_inputs=native,
        original_replay_rows=len(original_data["bands"]),native_sky_counts={k:sorted(v) for k,v in counts.items()},
        matched_m0_north_ranges={k:span(v) for k,v in ranges.items()},max_change_in_N_fraction=max(v[0] for v in checks),
        independent_density_force_max_abs=max(v[1] for v in checks),axis_half_time_max_relative=max(v[3] for v in checks),
        axis_two_basis_spot_checks=refinements,tolerance=TOL,axis_all_time_within_target=max(v[3] for v in checks)<=TOL,
        axis_both_basis_checks_within_target=max(refinements)<=TOL,
        ring_corrected=span([float(r["corrected_MTS"]) for r in zero]),ring_only_min_energy_factor=min(float(r["necessary_over_one_way"]) for r in pre if r["case"]=="ring_only"),
        large_box_relative=max(float(r["relative"]) for r in read("box-refinement") if r["contrast"]=="tide"))
    assert not list(ROOT.glob("__pycache__")) and not (ROOT/"STOP-REQUESTED").exists()
    save("checks.json",results)
    if "--seal" in sys.argv or (ROOT/"seal.json").exists():
        inventory={p.name:sha(p) for p in sorted(ROOT.iterdir()) if p.is_file() and p.name!="seal.json"}
        if "--seal" in sys.argv:save("seal.json",dict(files=inventory))
        assert inventory==json.loads((ROOT/"seal.json").read_bytes())["files"]
        print("Verified",len(inventory),"files",sha(ROOT/"seal.json"))
    else:print(json.dumps(results,indent=2))
if __name__=="__main__":run()
