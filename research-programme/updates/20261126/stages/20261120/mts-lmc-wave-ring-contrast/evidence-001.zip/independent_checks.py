from drive_rings import *
from fold_ring_results import vector,correction,modes
from scipy.special import roots_legendre
from numpy.polynomial.legendre import legvander
def run():
    rows=[];green=[];envelope=[];wide=[]
    for hist in fixed.prep.ms.MODELS:
        for occ in (0,1):
            tag=f"new-{occ}-k88";primary=read(f"response-{tag}-{hist}")
            enlarged=read(f"response-wide-{occ}-k88-{hist}")
            for initial in ("zero","equilibrium_slope"):
                for label in ("two","tide"):
                    weights=vector(label)
                    ref=correction(modes(primary,"primary",initial),weights)
                    ctrl=correction(modes(enlarged,"primary",initial),weights)
                    wide.append(dict(occ=occ,history=hist,initial=initial,contrast=label,primary=ref,large_box=ctrl,absolute=abs(ref-ctrl),relative=abs(ctrl/ref-1)))
            with np.load(HERE/f"forcing-control-{tag}-{hist}.npz") as saved,np.load(HERE/f"state-{tag}-{hist}.npz") as state:
                sigma=saved["sigma"];tau=saved["time"]*saved["vel"]/saved["length"]
                force=saved["source"];n=len(sigma);nodes,weights=roots_legendre(18)
                lagrange=legvander(nodes,4)@np.linalg.inv(legvander(np.linspace(-1,1,5),4))
                ids=4*np.arange((len(tau)-1)//4);half=(tau[4]-tau[0])/2
                at=tau[ids,None]+half*(nodes[None,:]+1)
                interp=np.einsum("ij,bjk->bik",lagrange,force[ids[:,None]+np.arange(5)])
                phase=(tau[-1]-at[:,:,None])*sigma
                pos=-2*half*np.einsum("j,bjk,bjk->k",weights,np.sin(phase),interp)/sigma
                vel=-2*half*np.einsum("j,bjk,bjk->k",weights,np.cos(phase),interp)
                error=max(abs(pos-state["low_only_pos"][:n]));relative=np.linalg.norm(pos-state["low_only_pos"][:n])/np.linalg.norm(pos)
                verr=np.linalg.norm(vel-state["low_only_vel"][:n])/np.linalg.norm(vel)
                assert max(relative,verr)<2e-10
                rows.append(dict(history=hist,occ=occ,n=n,defect=error,position_relative=relative,velocity_relative=verr))
            for r in modes(primary,"primary","zero"):
                if r["component"]=="azimuthal":green.append(dict(history=hist,occ=occ,R=r["R"],green_error=r["independent_green_absolute"]))
    oldchecks=[]
    for hist in ("L2M10first","L3M11"):
        with np.load(QUAD/"operators/1-64.npz") as op,np.load(QUAD/f"states/1-64-{hist}-r192-l24-t16-d1.npz") as soil:
            amp=(op["sky"]@soil["displacement"])*[1,1,1j,1,1,1j]
            var=modes(read(f"response-old-1-k64-{hist}"),"low_only","zero")[:6]
            for r,measured,coefficient in zip(var,2*amp.real,2*(np.exp(2j*AXIS)*amp).real):
                oldchecks.append(dict(history=hist,R=r["R"],component=r["component"],meridian=measured,meridian_difference=float(r["meridian"])-measured,
                                      cosine=coefficient,cosine_difference=float(r["bar_axis_cosine"])-coefficient))
    for name,data in (("quadrature-control",rows),("independent-density",green),("box-refinement",wide),("old-complex-replay",oldchecks)):table(name,data)
if __name__=="__main__":run()
