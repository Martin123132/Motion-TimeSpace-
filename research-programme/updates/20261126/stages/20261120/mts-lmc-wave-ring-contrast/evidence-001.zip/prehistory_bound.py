from drive_rings import *
from fold_ring_results import vector
def run(occ):
    tag=f"new-{occ}-k88";gates=read("free-state-gate")
    with np.load(HERE/f"operator-{tag}.npz") as data:op={k:data[k] for k in data.files}
    bg=fixed.prep.ms.Wave(1).bg;phys=bar.physical(occ,False);orders=op["ell"];mu=op["mu"];ang=basis(orders,2,mu)
    proj=projection(ang,bg.aw,ang);n=bg.count
    ham=bg.mesh.kinetic(orders,True)+blocks(local(phys["hamiltonian"]-phys["energy"]/bg.vel**2,proj,n,n))
    mix=full_column(blocks(local(phys["wave"]/bg.rad[:,None],proj,n,n)),n)
    lap=bg.mesh.kinetic(orders,False);joint=sp.bmat([[ham,np.sqrt(2)*mix],[np.sqrt(2)*mix.T,lap]],format="csc");factor=splu(joint)
    rows=[]
    for hist in fixed.prep.ms.MODELS:
        field=np.zeros((len(bg.rad),n),complex)
        for complete in (False,True):
            radii,time,v=bank(hist,complete)
            deg=np.arange(26,71,2) if complete else np.arange(2,25,2)
            val=CubicSpline(radii,v[0,:,12:] if complete else v[0],axis=0)(op["rad"])
            field+=np.einsum("ry,yl,rl,y,yb,r->rb",op["wave"],basis(deg,2,mu),val,bg.aw,ang,bg.sqrt/bg.vel**2,optimize=True);del v
        f=field.ravel();rhs=np.zeros((joint.shape[0],2));rhs[:len(f)]=-2*np.column_stack([f.real,f.imag])
        x=factor.solve(rhs);assert np.linalg.norm(joint@x-rhs)/np.linalg.norm(rhs)<1e-8
        static=-np.vdot(f,x[:len(f),0]+1j*x[:len(f),1]).real
        ftilde=np.einsum("rl,lrk->lk",field,op["block"]).ravel()@op["modes"]
        reduced=2*sum(abs(ftilde/op["sigma"])**2);assert static>0 and reduced<=static*(1+1e-8)
        for case in ("ring_only","unchanged_meridian_radial_polar"):
            r=next(r for r in gates if (r["history"],int(r["occ"]),r["case"])==(hist,occ,case))
            minimum=float(r["minimum_free_energy"]);tv=np.sqrt(minimum/static)-1
            rows.append(dict(occ=occ,history=hist,case=case,initial_static_energy=static,reduced_energy=reduced,one_way_max_free_energy=4*static,
                        necessary_free_energy=minimum,necessary_over_one_way=minimum/(4*static),minimum_relative_source_variation=tv,
                        min_weighted_pattern_travel_rad=max(0,(tv-1)/2),max_ring_uncertainty=np.sqrt(32*static*float(r["readout_gram"])),
                        shift_to_zero=float(r["required_shift"])))
    table(f"prehistory-{occ}",rows)
if __name__=="__main__":
    for occ in map(int,sys.argv[1:]):run(occ)
