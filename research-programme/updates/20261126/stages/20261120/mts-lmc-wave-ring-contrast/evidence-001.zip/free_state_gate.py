from fold_ring_results import *
def run():
    out=[];tests=[]
    fixed_rings=read("fixed-rings")
    for occ in (0,1):
        tag=f"new-{occ}-k88"
        with np.load(HERE/f"operator-{tag}.npz") as op:
            gram=op["gram"];sky=op["sky"];sigma=op["sigma"];unit=op["length"]/op["vel"]
        angular=np.array([2,5,8]);mer=[0,1,3,4];weights=vector("tide")
        ref=weights@sky[angular];constraints=sky[mer];s=np.sin(2*AXIS);c=np.cos(2*AXIS)
        chi=weights@gram[np.ix_(angular,angular)]@weights
        cross=gram[np.ix_(mer,angular)]@weights;project=linalg.solve(gram[np.ix_(mer,mer)],cross,assume_a="pos")
        loss=cross@project;schur=chi-loss
        assert chi>schur>0
        for h in fixed.prep.ms.MODELS:
            with np.load(HERE/f"state-{tag}-{h}.npz") as state,np.load(HERE/f"forcing-control-{tag}-{h}.npz") as src:
                pos=state["pos"];vel=state["velocity"];seed=state["seed_pos"];seedvel=state["seed_velocity"]
                elapsed=np.ptp(src["time"])/unit
            energy=lambda x,v:.5*sum(abs(sigma*x)**2+abs(v)**2)
            forced=energy(pos,vel);alternative=energy(seed,seedvel)
            want=-float(next(r["corrected_MTS"] for r in fixed_rings if (int(r["occ"]),r["history"],r["initial"],r["contrast"])==(occ,h,"zero","tide")))
            for label,eff,con in (("ring_only",chi,False),("unchanged_meridian_radial_polar",c*c*chi+s*s*schur,True)):
                minimum=want**2/(8*eff)
                x=-want/(2*eff)*(s*(ref-(project@constraints if con else 0))+1j*c*ref)/sigma**2
                gain=2*(1j*np.exp(2j*AXIS)*(ref@x)).real
                initial=x*np.cos(sigma*elapsed);initial_velocity=x*sigma*np.sin(sigma*elapsed)
                reconstruct=initial*np.cos(sigma*elapsed)+initial_velocity*np.sin(sigma*elapsed)/sigma
                force_mer=max(abs(2*(constraints@x).real))
                assert abs(gain/want-1)<1e-7 and abs(energy(initial,initial_velocity)/minimum-1)<1e-7 and np.linalg.norm(x-reconstruct)/np.linalg.norm(x)<1e-12
                if con:assert force_mer<1e-10
                out.append(dict(occ=occ,history=h,case=label,required_shift=want,minimum_free_energy=minimum,forced_energy=forced,equilibrium_seed_energy=alternative,
                        minimum_over_forced=minimum/forced,minimum_over_seed=minimum/alternative,readout_gram=eff,witness_meridian_max=force_mer,force_recovery=gain))
    table("free-state-gate",out)
if __name__=="__main__":run()
