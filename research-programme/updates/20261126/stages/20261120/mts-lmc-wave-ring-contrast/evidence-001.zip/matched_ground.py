from host_inputs import *
from scipy.sparse.linalg import splu
from fields import paths
def run():
    guard();wave=common_wave.Wave(1);bg=wave.bg;stored=np.load(HOST/"grounds/mesh1-occ2.npz")
    initial=stored["g"].ravel();mu0=float(stored["mu"]);stored.close()
    reference=next(r for r in ls.old.read(HOST,"grounds-1") if r["occupation"]=="2")
    mass_unit=float(reference["mass_msun"])/float(reference["norm"])
    location=bg.rad[:,None]*bg.length
    positions=np.stack(np.broadcast_arrays(-location*np.sqrt(1-bg.mu**2),np.zeros((1,len(bg.mu))),location*bg.mu),axis=2).reshape(-1,3)
    native=common_wave.materials(fixed.prep.ms.MODELS[0])(positions)[:,0].reshape(len(bg.rad),-1)/bg.vel**2
    table0=[r for r in read("host-calibration") if r["points"]=="256"]
    for idx,row in enumerate(table0):
        dark=float(row["dark"]);g=initial.copy();mu=mu0
        independent=common_wave.materials(row["history"])(positions)[:,0].reshape(native.shape)/bg.vel**2
        assert np.max(abs(independent-native))<1e-12
        for step in range(12):
            sky,moment,src,total=wave.fields(g)
            h=total-mu*wave.eye;res=h@g;con=(wave.rows[-1]*moment).sum()-dark
            if np.linalg.norm(res)<1e-10 and abs(con)<1e-12:break
            mixed=full_column(wave.mult(sky/bg.rad[:,None]),bg.count)
            last=2*np.einsum("rl,ul,ru,u,uk->rk",wave.rows[-1],bg.harm,sky,bg.aw,bg.harm,optimize=True)/bg.sqrt[:,None]
            jac=sp.bmat([[h,mixed,-sp.csc_matrix(g[:,None])],[2*mixed.T,bg.grav,None],[sp.csc_matrix(last.reshape(1,-1)),None,sp.csc_matrix((1,1))]],format="csc")
            delta=splu(jac).solve(np.r_[-res,np.zeros(bg.grav.shape[0]),-con])
            g+=delta[:g.size];mu+=delta[-1]
        else:raise ValueError(("stationary constraint",idx,np.linalg.norm(res),con))
        sat_mass=g@g*mass_unit
        phi=fixed.self_field(bg,moment)
        assert abs((g@initial)/np.sqrt((g@g)*(initial@initial)))>.98
        packet(f"host-ground-{idx}",wave=sky,hamiltonian=native+phi,energy=mu*bg.vel**2,vel=bg.vel,mass=sat_mass,occupation=g@g)
        packet(f"host-field-{idx}",g=g)
        table(f"host-ground-{idx}",[dict(case=idx,history=row["history"],representation=row["representation"],initial_total_speed=row["total_speed"],frozen_mass=sat_mass,
                    matched_dark=dark,residual_dark=con,stationarity=np.linalg.norm(res),steps=step)])
if __name__=="__main__":run()
