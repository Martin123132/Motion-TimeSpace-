from drive_rings import *
from fold_ring_results import vector
def run(occ):
    tag=f"new-{occ}-k88"
    with np.load(HERE/f"operator-{tag}.npz") as saved:op={k:saved[k] for k in saved.files}
    sigma=op["sigma"];weights=vector("tide");sector=op["ell"];mu=op["mu"]
    ang=basis(sector,2,mu);w=op["aw"];basis2=ang[:,0]
    tidal_shape=(op["wave"]@((w*basis2)[:,None]*ang))*(op["rad"]**2*op["root"]/op["vel"]**2)[:,None]
    q=op["block"];modal=(np.einsum("rl,lrk->lk",tidal_shape,q).ravel())@op["modes"]
    readout=weights@op["sky"][[2,5,8]]
    scale=op["length"]/op["vel"]*.9777922216807892
    def observe(x):return 2*(1j*np.exp(2j*AXIS)*(readout@x)).real
    physical_factor=4*np.sqrt(15/8)*UNIT
    response_length=(readout@(modal/sigma**2))*4/physical_factor
    kernel=[]
    for t in np.linspace(0,2,201):
        value=4*(readout@(modal*np.sin(sigma*t/scale)/sigma))/(physical_factor*scale)
        kernel.append(dict(occ=occ,delay_Gyr=t,length_per_Gyr=value,static_response_length_kpc=response_length))
    table(f"tidal-kernel-{occ}",kernel)
    p=bar.physical(occ,False);bg=fixed.prep.ms.Wave(1).bg;proj=projection(ang,w,ang)
    ham=bg.mesh.kinetic(sector,True)+blocks(local(p["hamiltonian"]-p["energy"]/p["vel"]**2,proj,bg.count,bg.count))
    mix=full_column(blocks(local(op["wave"]/bg.rad[:,None],proj,bg.count,bg.count)),bg.count)
    lap=bg.mesh.kinetic(sector,False)
    rws,unused=projections(bg,sector,splu(lap),mix)
    full=sp.bmat([[ham,np.sqrt(2)*mix],[np.sqrt(2)*mix.T,lap]],format="csc");fac=splu(full);n=ham.shape[0]
    rrmap={};rows=[];tests=[]
    for hist in fixed.prep.ms.MODELS:
        guard()
        with np.load(HERE/f"taylor-{hist}.npz") as packet0:time,tide=packet0["t"],packet0["coefficient"]
        drive=tide[:,None]*modal;uniform=transfer(time,drive,sigma,op,0)
        end=np.zeros_like(tidal_shape,dtype=complex)
        subtraction=None
        for complete in (False,True):
            rr,epochs,v=bank(hist,complete)
            assert np.array_equal(epochs,time[::2] if complete else time)
            degrees=np.arange(26,71,2) if complete else np.arange(2,25,2)
            chunk=v[:,:,12:] if complete else v
            inter=CubicSpline(rr,chunk[-1],axis=0)(op["rad"])
            end+=np.einsum("ry,yl,rl,y,yb,r->rb",op["wave"],basis(degrees,2,mu),inter,w,ang,op["root"]/op["vel"]**2,optimize=True)
            if not complete:
                chunk[:,:,0]-=tide[:,None]*rr[None,:]**2
                if "low" not in rrmap:rrmap["low"]=projection_map(op,rr,degrees)
                subtraction=transfer(epochs,pair(chunk,rrmap["low"]),sigma,op,0)
            del chunk,v
        with np.load(HERE/f"state-{tag}-{hist}.npz") as state:
            original=state["pos"];vel=state["velocity"];lowonly=state["low_only_pos"]
            start=state["seed_pos"]
        projected=(np.einsum("rl,lrk->lk",end,q).ravel())@op["modes"]
        def exact_static(body):
            rhs=np.zeros((full.shape[0],2));rhs[:n]=-2*np.column_stack([body.real.ravel(),body.imag.ravel()])
            answer=fac.solve(rhs);assert np.linalg.norm(full@answer-rhs)/np.linalg.norm(rhs)<1e-8
            pot=(rws[[2,5,8]]@answer[:n]);return weights@(2*(1j*np.exp(2j*AXIS)*(pot[:,0]+1j*pot[:,1])).real)
        total_static=exact_static(end)
        tide_static=exact_static(tidal_shape*tide[-1])
        direct_tidal_slope=physical_factor*(np.exp(2j*AXIS)*tide[-1]).imag
        predicted_length=tide_static/direct_tidal_slope
        tests.append(dict(history=hist,full_minus_modal_static=total_static-observe(-2*projected/sigma**2),length_check=predicted_length-response_length,
                          remainder_check=observe(subtraction[0]+original-lowonly)-observe(original-uniform[0]),
                          relative_field_check=np.linalg.norm(subtraction[0]-lowonly+uniform[0])/np.linalg.norm(original)))
        for init in ("zero","equilibrium_slope"):
            pos=original if init=="zero" else original+start
            tile=uniform[0] if init=="zero" else uniform[0]+uniform[2]
            total=observe(pos);tidal=observe(tile)
            rows.append(dict(occ=occ,history=hist,initial=init,total=total,uniform_tide=tidal,nonuniform=total-tidal,static_full=total_static,
                        static_uniform=tide_static,static_nonuniform=total_static-tide_static,finite_history_minus_static=total-total_static,
                        temporal_change_of_uniform=tidal-tide_static,temporal_change_of_nonuniform=total-tidal-total_static+tide_static,
                        direct_uniform_slope=direct_tidal_slope,static_length=response_length))
    table(f"source-separation-{occ}",rows);table(f"separation-checks-{occ}",tests)
if __name__=="__main__":
    for occ in map(int,sys.argv[1:]):run(occ)
