from ring_operator import *
from fields import field,paths
import common_wave
HOST=common_wave.HERE
def run():
    guard();data=[]
    for name in fixed.prep.ms.MODELS:
        source=common_wave.materials(name)
        for representation in ("multipole","basis"):
            halo=field(paths(name)[representation,"initial"])
            for points in (128,256):
                az=2*np.pi*np.arange(points)/points
                direction=np.column_stack([np.cos(az),np.sin(az),np.zeros(points)])
                radius=17.58;site=radius*direction
                mean=lambda model:-np.mean((model(site)[:,1:]*direction).sum(axis=1))
                ordinary=mean(source);dark=mean(halo)
                data.append(dict(history=name,representation=representation,points=points,dark=dark*UNIT,ordinary=ordinary*UNIT,total_speed=np.sqrt(radius*(dark+ordinary))))
    table("host-calibration",data)
if __name__=="__main__":run()
