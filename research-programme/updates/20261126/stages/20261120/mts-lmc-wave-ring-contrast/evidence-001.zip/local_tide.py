from ring_operator import *
from lmc_field import history,positions,potential
from math import factorial
from numpy.polynomial import Legendre,Polynomial
def radial_jets(vals,rr,dist,ell):
    ids=np.clip(np.searchsorted(rr,dist)-1,0,len(rr)-2);steps=np.arange(len(dist))
    n=len(rr);lo=rr[ids];width=np.log(rr[ids+1]/lo);t=np.log(dist/lo)/width
    a=vals[steps,ids];b=width*vals[steps,ids+n];end=vals[steps,ids+1]
    d=b+width*vals[steps,ids+1+n]-2*(end-a);c=end-a-b-d
    ans=np.stack([a+t*(b+t*(c+t*d)),(b+t*(2*c+3*d*t))/width,(2*c+6*d*t)/width**2])
    for small in (True,False):
        use=(dist<rr[0]) if small else (dist>rr[-1])
        if not np.any(use):continue
        if small:
            value=vals[use,0];grad=vals[use,n];powers=(ell,ell+2)
            coeffs=(value*(1+ell/2)-grad/2,(grad-ell*value)/2);anchor=rr[0]
        else:
            value=vals[use,n-1];grad=vals[use,2*n-1];powers=(-ell-1,-ell-2)
            coeffs=((ell+2)*value+grad,-(ell+1)*value-grad);anchor=rr[-1]
        scaled=[v*(dist[use]/anchor)**p for p,v in zip(powers,coeffs)]
        for j in range(3):ans[j,use]=sum(p**j*v for p,v in zip(powers,scaled))
    return ans
def coefficient(xyz,rr,profiles):
    dist=np.linalg.norm(xyz,axis=1);x,y,z=xyz.T;minus=x-1j*y;plus=x+1j*y;beta=minus/dist**2
    val=np.zeros(len(x),complex);second=val.copy()
    for ell in range(7):
        base=ell*(ell+1)
        for m in range(ell+1):
            norm=(-1)**m*np.sqrt((2*ell+1)*factorial(ell-m)/factorial(ell+m))
            polynomial=Legendre.basis(ell).deriv(m).convert(kind=Polynomial).coef*norm
            for direction in ((1,-1) if m else (1,)):
                field=(profiles[:,:,base+m]-direction*1j*profiles[:,:,base-m])/np.sqrt(2) if m else profiles[:,:,base]
                f0,f1,f2=radial_jets(field,rr,dist,ell)
                coord=plus if direction==1 else minus
                b0=coord**m;b1=2*m*coord**(m-1) if m and direction==1 else 0.
                b2=2*m*(m-1)*coord**(m-2) if m>=2 and direction==1 else 0.
                for j,constant in enumerate(polynomial):
                    if constant==0:continue
                    k=-(j+m);factor=constant*z**j*dist**k
                    val+=factor*b0*f0
                    second+=factor*(b0*beta**2*(.5*f2+(k-1)*f1+.5*k*(k-2)*f0)+b1*beta*(f1+k*f0)+b2*f0)
    return val,second/(4*np.sqrt(15/8))
def run(model):
    guard();stamps,rr,data,tr=history(model)
    t=np.linspace(stamps[0],0,(len(stamps)-1)*16+1);p=positions(tr,t)
    left=np.minimum(np.arange(len(t))//16,len(stamps)-2);w=(np.arange(len(t))/16-left)[:,None,None]
    root=fixed.prep.ms.MODELS
    out=[];checks=[]
    for begin in range(0,len(t),128):
        select=slice(begin,begin+128);ids=left[select];mix=w[select];raw=(1-mix)*data[ids]+mix*data[ids+1]
        val,coeff=coefficient(-p[select],rr,raw);out.extend(coeff)
        for idx in [0,len(ids)-1]:
            centre=-p[begin+idx];h=raw[idx]
            def cartesian(step):
                eye=np.eye(3)[:2]*step
                xy=np.array([centre+dx+dy for dx in eye[[0]] for dy in [eye[1],-eye[1]]]+[centre-eye[0]+eye[1],centre-eye[0]-eye[1]])
                cross=potential(xy,rr,h)@np.array([1.,-1.,-1.,1.])/(4*step**2)
                diag=(potential(centre+eye,rr,h)+potential(centre-eye,rr,h))@np.array([1.,-1.])/step**2
                return (diag-2j*cross)/(8*np.sqrt(15/8))
            finite=cartesian(.02);coarse=cartesian(.04)
            checks.append(dict(epoch=t[begin+idx],potential_error=abs(val[idx]-potential(centre,rr,h))/max(abs(val[idx]),1.),
                         analytic_abs=abs(coeff[idx]),finite_abs_error=abs((4*finite-coarse)/3-coeff[idx]),raw_fine_error=abs(finite-coeff[idx])))
    packet("taylor-"+model,t=t,coefficient=np.asarray(out))
    table("taylor-tests-"+model,checks)
    print(model,max(r["potential_error"] for r in checks),max(r["finite_abs_error"] for r in checks),flush=True)
if __name__=="__main__":
    for h in (sys.argv[1:] or fixed.prep.ms.MODELS):run(h)
