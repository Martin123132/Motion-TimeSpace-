"""Proper-time dust and spatial principal-symbol tests of the centre stencil."""
from common import *
from regular import Regular,configure,check
from origin_modes import spatial,select,validate
import dust_control


def primary_projection(size,cells,ell):
    size_op=size*(1 if not ell else 3)
    mat=np.eye(size_op)
    stencil=Regular(cells)
    if ell==0:
        mat[:cells,:cells]=stencil.order2
    else:
        Q0,Q2,Q4=(getattr(stencil,"order"+str(k)) for k in (0,2,4))
        coefs=((Q4,2*(Q2-Q4),.5*Q4-2*Q2+1.5*Q0),
               (0*Q2,Q2,Q0-Q2),(0*Q0,0*Q0,Q0))
        for left in range(3):
            for right in range(3):
                mat[left*size:left*size+cells,right*size:right*size+cells]=coefs[left][right]
    return mat


def main():
    check()
    records=[]
    for size in (32,48,72):
        for ell,op in zip((0,2),spatial(size)):
            for cells in (0,6,8,10):
                mat=primary_projection(size,cells,ell)@op if cells else op
                vals=np.linalg.eigvals(mat).astype(complex)
                speed=np.sqrt(vals)[np.argmax(np.sqrt(vals).real)]
                records.append(dict(domain_cells=size,ell=ell,central_cells=cells,max_growth_h=speed.real,imag_h=speed.imag))
    table("stencil-growth.csv",records)
    original=dust_control.system
    try:
        records=[]
        for cells in (6,8):
            def patched(*args):
                shell=original(*args);configure(shell,f"cart{cells}");return shell
            dust_control.system=patched
            for grid in (120,160):
                for level in (4,32):
                    for row in dust_control.run(grid,level):records.append(dict(cells=cells,**row))
        table("regular-dust.csv",records)
    finally:dust_control.system=original
    print("dust",[(key,max(abs(row[key]) for row in records)) for key in ("error_ppm","gauge_leak_ppm")])


if __name__=="__main__":main()
