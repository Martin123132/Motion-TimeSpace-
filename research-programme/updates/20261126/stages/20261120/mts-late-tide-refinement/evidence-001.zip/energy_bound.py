"""Finite-aperture stress bounds that do not assume a slow source."""
from common import *
upstream("stress_projection.py")
import stress_projection as stage
from numpy.polynomial import Polynomial
from math import pi,sqrt
from window import UNIT


def ruler(width,order):
    half=CENTER*width;nodes,mass=leggauss(order);radius=CENTER+half*nodes
    poly=Polynomial([1,0,-1])**4
    values=[poly.deriv(idx)(nodes)/(UNIT*half**(1+idx)) for idx in range(4)]
    field=values[0]/radius**2
    prime=values[1]/radius**2-2*values[0]/radius**3
    double=values[2]/radius**2-4*values[1]/radius**3+6*values[0]/radius**4
    triple=values[3]/radius**2-6*values[2]/radius**3+18*values[1]/radius**4-24*values[0]/radius**5
    test=0.
    grad=0.
    norm=0.
    harmonic_area=4*pi/5
    for ell,share in zip((0,2,4),(1/5,2/7,18/35)):
        eig=ell*(ell+1)
        lap=double+2*prime/radius-eig*field/radius**2
        d_lap=triple+2*double/radius-(2+eig)*prime/radius**2+2*eig*field/radius**3
        work=field-half**2*lap
        d_work=prime-half**2*d_lap
        pref=half*(2/3)*share/harmonic_area
        test+=pref*np.dot(mass,radius**2*d_work**2+eig*work**2)
        grad+=pref*np.dot(mass,radius**2*prime**2+eig*field**2)
        norm+=pref*np.dot(mass,radius**2*field**2)
    direct=half*np.dot(mass,(2/3)*radius**2*prime**2+8*field**2)/harmonic_area
    assert abs(grad/direct-1)<1e-14
    return sqrt(test/(8*pi*half**3)),sqrt(grad),sqrt(norm)


def main():
    from family import BalancedNative,SPAN,DLOG
    sim=BalancedNative("heavy",120,600,False,"native36",SPAN*DLOG)
    fields={}
    for seed in (0,1,-1):
        for flag in (0,1):fields[seed,flag],grid=stage.source(sim,seed,flag)
    refs={(int(row["seed"]),float(row["width"])):float(row["newton"]) for row in rows(upstream("paired-speed-check.csv"))}
    output=[]
    for seed in (1,-1):
        raw=fields[seed,0]-fields[0,0]-fields[seed,1]+fields[0,1]
        tensor_norm=np.sqrt(np.sum(np.array([1.5,12.,12.])[:,None,None]*raw**2,axis=0))
        measure=grid.points**2*grid.w
        one=sqrt(4*pi*(4*pi/5))*np.sum(measure*tensor_norm)
        two=sqrt((4*pi/5)*np.sum(measure*tensor_norm**2))
        for width in FRACTIONS:
            first=ruler(width,64);second=ruler(width,128)
            np.testing.assert_allclose(first,second,rtol=3e-13,atol=0)
            transfer=1e6/abs(refs[seed,width])*DURATION
            output.append(dict(seed=seed,width=width,launch_L1_ceiling=one,launch_L2=two,
                L1_fast_coefficient_ppm=transfer*one*first[0],L2_fast_coefficient_ppm=transfer*two*first[1],
                launch_slow_frozen_coefficient_ppm=2*transfer*two*first[2]/DURATION))
    tests=[]
    for index in (0,1,4,16):
        phase=pi/2+2*pi*index
        nodes,weights=leggauss(192)
        time=(nodes+1)/2
        exact=-np.sin(phase)/(2*phase)
        numeric=-np.dot(weights/2,np.sin(phase*(1-time))*np.cos(phase*time))/phase
        assert abs(numeric/exact-1)<5e-13
        tests.append(dict(phase=phase,q=phase**2,measured=numeric,derived=exact,scaled=numeric*phase))
    table("fast-stress-bounds.csv",output);table("fast-source-controls.csv",tests)
    print("rough-source finite-energy and resonant source controls passed")


if __name__=="__main__":main()
