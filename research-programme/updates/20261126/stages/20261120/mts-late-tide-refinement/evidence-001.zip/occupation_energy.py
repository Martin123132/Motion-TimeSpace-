"""Close the mechanical stress budget for finite-mass Schroedinger-Poisson data."""
from common import *
from math import pi,sqrt
from scipy.special import erf


FILES={"mts-wave-state-20261107/result.json":"e44e79ca5e4c928d0b3b5969a433c569683b045b737ebd69810ad9d5b9f73c52",
    "mts-wave-state-20261107/wave.cjs":"e381f5441194169080588585b9e755379fa2ae6e311a8d5d18b3e44c2a58250d",
    "MTS-HEAVY-BATH-COUNTERFLOW-AND-GALACTIC-STRESS.md":"d78faf07c70739eee12ec1dd72731ccfe2d91c83c094b2bcfe8b21cf4038b6bc"}


def main():
    for name,mark in FILES.items():assert digest(HERE.parent/name)==mark
    stored=json.loads((HERE.parent/"mts-wave-state-20261107/result.json").read_bytes())
    examples=[]
    for case in stored["states"]:
        for row in case:
            kinetic=row["kineticEnergy"];grav=row["gravEnergy"];total=kinetic+grav
            assert abs(row["mass"]-1)<1e-10
            eigen_error=abs(row["energy"]-kinetic-2*grav)
            assert eigen_error<3e-8
            coefficient=sqrt(2)
            assert grav>=-coefficient*sqrt(kinetic)
            tight=((coefficient+sqrt(coefficient**2+4*total))/2)**2
            cap=2*(total+1)
            assert 0<kinetic<=tight<=cap
            examples.append(dict(ell=row["ell"],box=row["box"],spacing=row["step"],mass_eV=stored["massEV"],
                eigenvalue=row["energy"],kinetic=kinetic,self_potential=grav,total_specific=total,eigen_identity_error=eigen_error,
                isolated_kinetic_ceiling=tight,impulse_form_zero_force_ceiling=cap,actual_trace_stress_per_mass=2*kinetic,
                isolated_trace_ceiling_per_mass=2*tight,units="squared Bohr speed"))
    controls=[]
    nodes,weights=leggauss(128)
    for mass in (.25,2.):
        for width in (.6,1.7):
            for phase in (0.,2.1):
                radius=(nodes+1)*6*width
                density=mass*np.exp(-(radius/width)**2)/(pi**1.5*width**3)
                measure=4*pi*radius**2*weights*6*width
                kinetic=.5*measure@(density*(radius**2/width**4+phase**2))
                grav=-.5*mass*measure@(density*erf(radius/width)/radius)
                k_exact=mass*(1.5/width**2+phase**2)/2
                w_exact=-mass**2/(sqrt(2*pi)*width)
                assert max(abs(kinetic/k_exact-1),abs(grav/w_exact-1))<2e-13
                assert grav>=-sqrt(2)*mass**1.5*sqrt(kinetic)
                impulse=1.3
                free_before=k_exact/mass
                free_after=(1.5/width**2+(phase+impulse)**2)/2
                free_ceiling=2*(sqrt(free_before)+impulse)**2
                assert free_after<=free_ceiling
                controls.append(dict(mass=mass,width=width,phase=phase,gaussian_K=kinetic,gaussian_W=grav,K_exact=k_exact,W_exact=w_exact,
                    free_uniform_impulse=impulse,free_final_energy_per_mass=free_after,free_force_work_ceiling=free_ceiling))
    table("isolated-state-energy-ceilings.csv",examples);table("occupation-energy-controls.csv",controls)
    print("six saved stationary states and eight independent checks",examples[2],examples[-1])


if __name__=="__main__":main()
