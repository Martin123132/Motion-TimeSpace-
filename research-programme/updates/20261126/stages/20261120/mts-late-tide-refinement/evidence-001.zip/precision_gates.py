from common import *


def index(name):
    return {(row["seed"],row["width"],row["fraction"],row["channel"]):float(row["finite_minus_integrated_ppm"]) for row in rows(HERE/name)}


def main():
    high=index("endpoint-check-trace6-n160-q32-p1-d40.csv")
    low=index("endpoint-check-trace6-n160-q16-p1-d40.csv")
    check=index("endpoint-check-trace6-n160-q32-p1-d32.csv")
    coarse=index("endpoint-check-trace6-n120-q32-p1-d40.csv")
    assert high.keys()==low.keys()==coarse.keys()==check.keys() and len(high)==64
    ledger=[]
    for name,items in (("high",high),("low",low),("coarser grid",coarse),("32 vs 40 digits",{key:high[key]-check[key] for key in high})):
        worst=max(abs(val) for val in items.values())
        ledger.append(dict(test=name,worst_ppm=worst,tolerance_ppm=20,within=worst<=20))
    samples=[]
    for row in rows(HERE/"forecast-trace6-n160-q32-p1-trace6-n160-q16-p1.csv"):
        key=tuple(row[col] for col in ("seed","width","fraction","channel"))
        measured=float(row["curvature_affine_ppm"])+2*high[key]-low[key]
        gap=measured-float(row["mechanical_ppm"])
        samples.append(dict(seed=key[0],width=key[1],fraction=key[2],channel=key[3],mechanical_ppm=row["mechanical_ppm"],
            integrated_curvature_ppm=row["curvature_affine_ppm"],finite_curvature_ppm=measured,residual_ppm=gap,within=abs(gap)<=20))
    worst=max(abs(row["residual_ppm"]) for row in samples)
    ledger.append(dict(test="finite endpoint vs mechanical extrapolation",worst_ppm=worst,tolerance_ppm=20,within=worst<=20))
    table("finite-forecast.csv",samples);table("precision-gates.csv",ledger);print(ledger)


if __name__=="__main__":main()
