"""Smooth only metric shear accelerations; preserve Raychaudhuri and matter exactly."""
from common import np
from regular import Regular
from types import MethodType


class FixedTrace(Regular):
    def correct(self,state,evolution):
        stop=self.size
        ell,bend,tilt,tensor=state[:4,:,:stop].real
        rate_ell,rate_bend,rate_v,rate_t=evolution[:4,:,:stop].real
        trace,shear,cross,tan=evolution[4:8,:,:stop].real
        frozen_trace=trace.copy()
        ell_acc=-trace/3-shear;bend_acc=-trace/3+shear/2
        factor=np.exp(ell[0]-bend[0]);spin=state[6,1,:stop].real
        radial=np.exp(2*ell[0]);angle=np.exp(2*bend[0])
        radial_d=2*radial*rate_ell[0];angle_d=2*angle*rate_bend[0]
        radial_dd=2*radial*(ell_acc[0]+2*rate_ell[0]**2)
        angle_dd=2*angle*(bend_acc[0]+2*rate_bend[0]**2)
        xx=radial_dd*ell[1]+2*radial_d*rate_ell[1]+radial*ell_acc[1]
        yy=angle_dd*bend[1]+2*angle_d*rate_bend[1]+angle*bend_acc[1]
        vv=angle_dd*tilt[1]+2*angle_d*rate_v[1]-2*angle*factor*(cross[1]+(rate_ell[0]-rate_bend[0])*spin)
        tt=angle_dd*tensor[1]+2*angle_d*rate_t[1]-2*angle*tan[1]
        delta=self.put(radial_dd-angle_dd,2)-4*(radial*rate_ell[0]**2-angle*rate_bend[0]**2)
        bend0=(-radial*trace[0]-delta/2)/(2*radial+angle)
        ell0=-trace[0]-2*bend0
        rr2=2*radial*(ell0+2*rate_ell[0]**2);aa2=2*angle*(bend0+2*rate_bend[0]**2)
        flat=self.put(tt,0);mixed=self.put(vv-tt,2)+flat
        delta=self.put(xx-yy-2*vv+tt/2,4)+2*mixed-flat/2
        residual=delta-rr2*ell[1]+aa2*bend[1]-2*(radial_d*rate_ell[1]-angle_d*rate_bend[1])
        bend2=(-radial*trace[1]-residual)/(2*radial+angle)
        ell2=-trace[1]-2*bend2
        shear[:]=(2/3)*(np.array([bend0,bend2])-np.array([ell0,ell2]))
        cross[1]=-(mixed-aa2*tilt[1]-2*angle_d*rate_v[1])/(2*angle*factor)-(rate_ell[0]-rate_bend[0])*spin
        tan[1]=-(flat-aa2*tensor[1]-2*angle_d*rate_t[1])/(2*angle)
        assert np.array_equal(frozen_trace,trace)


def install(shell,cells):
    if cells not in (6,8):raise ValueError(cells)
    stencil=FixedTrace(cells);original=shell.dynamics
    def dynamics(self,time,state,details=False):
        result=original(time,state,details)
        if not details:stencil.correct(state,result)
        return result
    shell.dynamics=MethodType(dynamics,shell)
