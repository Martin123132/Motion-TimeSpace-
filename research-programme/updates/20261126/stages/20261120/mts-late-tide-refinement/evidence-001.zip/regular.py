"""A centre-only regular Cartesian tensor stencil, applied to metric accelerations."""
from common import *
from types import MethodType


class Regular:
    def __init__(self,size,degree=6):
        self.size=size
        nodes=(np.arange(size)+.5)/size
        for order in (0,2,4):
            space=np.column_stack([nodes**power for power in range(order,degree+1,2)])
            orthogonal=np.linalg.qr(nodes[:,None]*space)[0]
            matrix=(orthogonal@orthogonal.T)*nodes[None,:]/nodes[:,None]
            setattr(self,f"order{order}",matrix)

    def put(self,field,order):
        return getattr(self,f"order{order}")@field

    def correct(self,state,evolution):
        stop=self.size
        ell,bend,tilt,tensor=state[:4,:,:stop].real
        primary=evolution[:4,:,:stop].real
        radial_rate,bend_rate,tilt_rate,tensor_rate=primary
        trace_dot,shear_dot,cross_dot,tan_dot=evolution[4:8,:,:stop].real
        cross=state[6,1,:stop].real
        ell_acc=-trace_dot/3-shear_dot;bend_acc=-trace_dot/3+shear_dot/2
        factor=np.exp(ell[0]-bend[0])
        tilt_acc=-2*factor*(cross_dot[1]+(radial_rate[0]-bend_rate[0])*cross)
        tensor_acc=-2*tan_dot[1]
        radial=np.exp(2*ell[0]);angle=np.exp(2*bend[0])
        radial_d=2*radial*radial_rate[0];angle_d=2*angle*bend_rate[0]
        radial_dd=2*radial*(ell_acc[0]+2*radial_rate[0]**2)
        angle_dd=2*angle*(bend_acc[0]+2*bend_rate[0]**2)
        xx=radial_dd*ell[1]+2*radial_d*radial_rate[1]+radial*ell_acc[1]
        yy=angle_dd*bend[1]+2*angle_d*bend_rate[1]+angle*bend_acc[1]
        vv=angle_dd*tilt[1]+2*angle_d*tilt_rate[1]+angle*tilt_acc
        tt=angle_dd*tensor[1]+2*angle_d*tensor_rate[1]+angle*tensor_acc
        scalar=self.put(radial_dd+2*angle_dd,0);shear=self.put(radial_dd-angle_dd,2)
        rr2=(scalar+2*shear)/3;aa2=(scalar-shear)/3
        ell0=rr2/(2*radial)-2*radial_rate[0]**2
        bend0=aa2/(2*angle)-2*bend_rate[0]**2
        trace2=self.put(xx+2*yy,2)
        angular2=self.put(tt,0)
        mixed=self.put(vv-tt,2)+angular2
        diff=self.put(xx-yy-2*vv+tt/2,4)+2*mixed-angular2/2
        ell2=((trace2+2*diff)/3-rr2*ell[1]-2*radial_d*radial_rate[1])/radial
        bend2=((trace2-diff)/3-aa2*bend[1]-2*angle_d*bend_rate[1])/angle
        fixed_ell=np.array([ell0,ell2]);fixed_bend=np.array([bend0,bend2])
        trace_dot[:]=-(fixed_ell+2*fixed_bend)
        shear_dot[:]=(2/3)*(fixed_bend-fixed_ell)
        tilt_acc=(mixed-aa2*tilt[1]-2*angle_d*tilt_rate[1])/angle
        tensor_acc=(angular2-aa2*tensor[1]-2*angle_d*tensor_rate[1])/angle
        cross_dot[1]=-tilt_acc/(2*factor)-(radial_rate[0]-bend_rate[0])*cross
        tan_dot[1]=-tensor_acc/2


def configure(shell,name):
    if name.startswith("trace"):
        from trace_stencil import install
        return install(shell,int(name[5:]))
    if not name.startswith("cart"):raise ValueError(name)
    size=int(name[4:])
    if size not in (6,8,10):raise ValueError(size)
    closure=Regular(size)
    old=shell.dynamics
    def dynamics(self,time,state,details=False):
        result=old(time,state,details)
        if not details:closure.correct(state,result)
        return result
    shell.dynamics=MethodType(dynamics,shell)


def check():
    for size in (6,8,10):
        stencil=Regular(size)
        radius=(np.arange(size)+.5)/size
        for order in (0,2,4):
            for power in range(order,7,2):
                field=radius**power
                assert np.max(abs(stencil.put(field,order)-field))<3e-14
    print("Cartesian regular polynomials preserved")


if __name__=="__main__":check()
