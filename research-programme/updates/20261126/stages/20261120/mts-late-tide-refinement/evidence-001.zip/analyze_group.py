"""One serial analysis pass on complete saved branches."""
from common import *
from read_path import examine
from origin_modes import inspect
from late_comparison import build


def analyze(group):
    paths=sorted(HERE.glob(group+"-off*-s*.npz"))
    assert len(paths)==6 and len(list(HERE.glob(group+"-off*-s*.csv")))==6,group
    first=[];second=[]
    for path in paths:
        parts,core=examine(path)
        first+=parts;second+=core
    assert len(first)==576 and len(second)==480
    table("path-"+group+".csv",first);table("core-"+group+".csv",second)
    inspect(group)
    out,budgets=build(group)
    table("compared-"+group+".csv",out);table("budget-"+group+".csv",budgets)
    print(group, "complete", flush=True)


if __name__=="__main__":
    for group in sys.argv[1:]:analyze(group)
