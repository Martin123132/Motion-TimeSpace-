"""Independent finite endpoint evaluator; high precision spatial curvature and a finite secant for the proper ruler."""
from common import *
from decimal import Decimal,getcontext
from math import fsum

D=Decimal.from_float
convert=np.frompyfunc(lambda value:D(float(value)),1,1)


def pack(value,harm=None):
    return np.stack((value,0*value if harm is None else harm))


def prod(left,right):
    return pack(left[0]*right[0],left[0]*right[1]+left[1]*right[0])


def exponential(field):
    value=np.exp(field[0])
    return pack(value,value*field[1])


def square(field):return prod(field,field)


def fixed_tide(shell,start,change):
    def coord(idx,imag=False):
        field=start[idx].imag if imag else start[idx].real
        result=convert(field)
        if change is not None:result+=convert(change[idx].imag if imag else change[idx].real)
        return result
    radius=convert(shell.r);dx=D(shell.dx);mu=D(shell.mu)
    ell,bend,tilt,angular,trace,shear=(coord(i) for i in range(6))
    def diff(data,degree=1):
        padded=np.concatenate((data[...,2::-1],data,data[...,:-4:-1]),axis=-1)
        count=len(radius)+1
        face=sum(D(w)*(padded[...,3+j:3+j+count]-padded[...,2-j:2-j+count]) for j,w in enumerate(shell.weights))/dx
        ext=np.concatenate((-face[...,2:0:-1],face,-face[...,-2:-4:-1]),axis=-1)
        count-=1
        if degree==2:
            return sum(D(w)*(ext[...,3+j:3+j+count]-ext[...,2-j:2-j+count]) for j,w in enumerate(shell.weights))/dx
        return sum(D(w)*(ext[...,3+j:3+j+count]+ext[...,2-j:2-j+count]) for j,w in enumerate(shell.average))
    density=coord(17);material=0*density;unit=pack(0*radius+1)
    normal=exponential(-ell);volume=exponential(-ell-2*bend)
    for idx in range(3 if shell.flag else 2):
        rest=D(shell.rho[idx])*prod(coord(8+2*idx),volume)
        speed=square(prod(normal,diff(coord(9+2*idx))))
        root=np.sqrt(1+speed[0]);gamma=pack(root,speed[1]/(2*root))
        reciprocal=pack(1/root,-gamma[1]/(root**2))
        density+=prod(rest,gamma)
        material+=2*prod(rest,prod(speed,reciprocal))/3
    if not shell.flag:
        amplitude=coord(14);phase=coord(14,True)
        rest=D(shell.rho[-1])*exponential(2*amplitude)
        grad=(square(prod(normal,diff(amplitude)))+square(prod(normal,diff(phase))))/(mu**2)
        kin=square(coord(15)+trace/(2*mu))+square(coord(15,True)-unit)
        density+=prod(rest,unit+kin+grad)/2
        material+=2*prod(rest,grad)/3
    deriv=diff(bend);ed=diff(ell)
    inv=exponential(-2*ell);ev=np.exp(-2*bend[0])
    curvature_gap=-2*prod(inv,square(deriv)+2*deriv/radius)
    monopole=2*inv[0]*(np.exp(2*(ell[0]-bend[0]))-1)/radius**2
    curvature_gap[0]+=monopole
    curvature_gap[1]+=(ev*(8*bend[1]+12*angular[1])+inv[0]*(4*ell[1]-12*tilt[1]))/radius**2-12*inv[0]*deriv[0]*tilt[1]/radius
    normal_ric=2*diff(bend,2)-2*prod(ed,deriv)-2*ed/radius
    normal_ric[1]+=6*(diff(tilt[1])-ed[0]*tilt[1])/radius
    direct=prod(inv,normal_ric);direct[0]+=monopole
    direct[1]+=(inv[0]*(4*ell[1]-6*tilt[1])+ev*(8*bend[1]+12*angular[1]-6*ell[1]))/radius**2
    extra=material-prod(trace,shear)/3+square(shear)/2
    gauss=(2*density-2*square(trace)/3+3*square(shear)/2)/6-curvature_gap/2
    return np.stack((extra+direct/3,extra-gauss))


def secant(*terms):
    base=1.;delta=0.
    for nominal,shift in terms:
        delta=delta*nominal+(base+delta)*shift
        base=base*nominal
    return delta


def group(stem,precision=40):
    import re
    scheme,grid,level,splits=re.fullmatch(r"(\w+)-n(\d+)-q(\d+)-p(\d+)",stem).groups()
    grid,level,splits=map(int,(grid,level,splits));getcontext().prec=precision
    products=[]
    for flag in (0,1):
        for seed in (0,1,-1):
            guard();name=stem+f"-off{flag}-s{seed}"
            shell=shell_for(grid,level,flag,seed)
            start=shell.initial
            zero=fixed_tide(shell,start,None)
            inc0=convert(shell.incident.bank.at(0.)[4]);zero[:,1]+=inc0
            metric0=exp(start[0].real)
            win=Window(shell,start,np.zeros_like(start),8)
            def optical(field):
                spline=win.spline(field);anti=spline.antiderivative()
                return spline(win.pos),anti(win.pos)-anti(0.)[:,None]
            metric,length=optical(metric0)
            base=win.at(zero.astype(float))
            nodes,weights=leggauss(8)
            with np.load(HERE/(name+".npz")) as source:changes=source["change"]
            for idx,change in enumerate(changes):
                fraction=(idx+1)/8;time=fraction*DURATION*np.sqrt(level)
                after=fixed_tide(shell,start,change)
                after[:,1]+=convert(shell.incident.bank.at(time)[4])
                delta=win.at((after-zero).astype(float))
                dr=change[0].real
                m0=metric0[0]*np.expm1(dr[0])
                dmetric,dist=optical(family.pair(m0,metric0[1]*np.expm1(dr[0])+(metric0[0]+m0)*dr[1]))
                for wi,width in enumerate(FRACTIONS):
                    half=CENTER*width
                    original=weight(length[0],half)
                    initial_der=weight(length[0],half,1)
                    dw=sum(wt*weight(length[0]+.5*(node+1)*dist[0],half,1) for node,wt in zip(nodes,weights))*dist[0]/2
                    dprime=sum(wt*weight(length[0]+.5*(node+1)*dist[0],half,2) for node,wt in zip(nodes,weights))*dist[0]/2
                    for ch,channel in enumerate(("ricci","gauss")):
                        cover=list(zip(metric,dmetric));field=list(zip(base[ch],delta[ch]))
                        effect=secant((original,dw),cover[0],field[1])+secant((original,dw),cover[1],field[0])
                        effect+=secant((initial_der,dprime),cover[0],(length[1],dist[1]),field[0])
                        products.append(dict(group=stem,grid=grid,level=level,flag=flag,seed=seed,width=width,fraction=fraction,channel=channel,
                            precision=precision,endpoint=fsum(win.quad*effect)))
    table(f"finite-endpoints-{stem}-d{precision}.csv",products)
    norms={(int(row["seed"]),float(row["width"])):float(row["newton"]) for row in rows(upstream("paired-speed-check.csv"))}
    original={(int(row["flag"]),int(row["seed"]),float(row["width"]),float(row["fraction"])):row for path in HERE.glob(stem+"-off*-s*.csv") for row in rows(path)}
    direct={(row["flag"],row["seed"],row["width"],row["fraction"],row["channel"]):row["endpoint"] for row in products}
    summaries=[]
    for (seed,width),norm in norms.items():
        for fraction in np.arange(1,9)/8:
            for channel in ("gauss","ricci"):
                branch=lambda f,s:direct[f,s,width,fraction,channel]-float(original[f,s,width,fraction][channel])
                difference=fsum((branch(0,seed),-branch(1,seed),-branch(0,0),branch(1,0)))
                summaries.append(dict(group=stem,seed=seed,width=width,fraction=fraction,channel=channel,precision=precision,
                    finite_minus_integrated_ppm=1e6*level*difference/norm))
    table(f"endpoint-check-{stem}-d{precision}.csv",summaries)
    print(stem,precision,"max finite endpoint difference",max(abs(row["finite_minus_integrated_ppm"]) for row in summaries),flush=True)


if __name__=="__main__":group(sys.argv[1],int(sys.argv[2]) if len(sys.argv)>2 else 40)
