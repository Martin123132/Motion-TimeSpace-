"""Selected numerical comparisons including strict gates; not a claim about global gravity."""
from common import *
from math import fsum


def load(name):return rows(HERE/name)


def summarize():
    groups=["original-n120-q32-p1","original-n120-q32-p2","original-n160-q32-p1","original-n160-q16-p1",
        "cart6-n120-q32-p1","cart6-n160-q32-p1","cart6-n160-q16-p1","cart8-n160-q32-p1",
        "trace6-n120-q32-p1","trace6-n160-q32-p1","trace6-n160-q16-p1"]
    verdict=[]
    def gate(name,item,tolerance,note):
        verdict.append(dict(test=name,worst=item,tolerance=tolerance,within=abs(item)<=tolerance,meaning=note))
    for group in groups:
        data=load("compared-"+group+".csv")
        assert len(data)==64
        budget=load("budget-"+group+".csv")
        gate(group+" compensated source sum",max(abs(float(row["sum_budget_ppm"])) for row in budget),20,"ppm of Newton change")
        gate(group+" outer summation",max(abs(float(row["fallback_order_ppm"])) for row in data),20,"simple vs compensated branch sum, ppm")
        paired={(row["seed"],row["width"],row["fraction"],row["channel"]):row for row in data}
        differences=[abs(float(row["excess_ppm"])-float(paired[seed,width,frac,"ricci"]["excess_ppm"])) for (seed,width,frac,channel),row in paired.items() if channel=="gauss"]
        gate(group+" curvature readouts",max(differences),20,"Gauss vs Ricci, ppm")
        gate(group+" endpoint vs tangent",max(abs(float(row["endpoint_drift_ppm"])) for row in data),20,"raw endpoint subtraction vs rate integral, ppm")
    files=sorted(HERE.glob("difference-*.csv"))
    for path in files:
        final=[row for row in rows(path) if float(row["cut"])==.3]
        for key in ("raw_curvature_difference_ppm","unexplained_ppm","total_tide_difference_ppm"):
            gate(path.stem+" "+key,max(abs(float(row[key])) for row in final),20,"ppm over eight proper-time samples, both widths, signs and readouts")
    for path in sorted(HERE.glob("forecast-*.csv")):
        items=rows(path)
        gate(path.stem,max(abs(float(row["unexplained_ppm"])) for row in items),20,"two-speed curvature intercept vs mechanical forecast; finite speeds, not infinity")
    for name in ("regular-dust.csv","trace-preserving-dust.csv"):
        items=load(name)
        for key in ("error_ppm","gauge_leak_ppm"):gate(name+" "+key,max(abs(float(row[key])) for row in items),20,"relative to exact nonzero LTB monopole change")
    for scheme in ("original","cart6","trace6","trace8"):
        items=[row for row in load("radiative-vacuum.csv") if row["scheme"]==scheme]
        for key in ("window_error_ppm","core_metric_error_ppm"):gate(scheme+" vacuum radiation "+key,max(abs(float(row[key])) for row in items),20,"analytic finite-time wave, not gauge-only")
    data=load("causal-frozen-stress.csv")
    reference={(row["seed"],row["width"],row["level"]):float(row["causal_ppm"]) for row in data if row["edge"]=="120" and row["order"]=="20"}
    gate("frozen causal wave domain and quadrature",max(abs(float(row["causal_ppm"])-reference[row["seed"],row["width"],row["level"]]) for row in data),20,"ppm of Newton change, all retarded light paths")
    gate("frozen vs exact causal short interval",max(abs(float(row["causal_ppm"])-float(row["taylor_ppm"])) for row in data if int(row["level"])<=32),20,"ppm of Newton change, travel expansion only")
    gate("energy-positive independent causal evolution",max(abs(float(row["discrepancy_ppm"])) for row in load("physical-wave-propagation.csv")),20,"ppm of Newton change relative to translated radial wave")
    table("acceptance-and-failures.csv",verdict)
    print("failed gates")
    for row in verdict:
        if not row["within"]:print(row["test"],format(row["worst"],".5g"))
    return verdict


if __name__=="__main__":summarize()
