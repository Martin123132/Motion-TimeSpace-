"""Endpoint stress in the same positive tidal-acceleration sign convention as the parent."""
from common import *
from numpy.polynomial import Polynomial
from math import pi,sqrt
from window import UNIT
from energy_bound import ruler


def kernel(width,order):
    nodes,weights=leggauss(order)
    half=CENTER*width;radius=CENTER+half*nodes
    poly=Polynomial([1.,0.,-1.])**4
    val,first,second=(poly.deriv(i)(nodes)/(UNIT*half**(i+1)) for i in range(3))
    shape=val/radius**2
    dr=first/radius**2-2*val/radius**3
    ddr=second/radius**2-4*first/radius**3+6*val/radius**4
    work=0.
    for ell,share in zip((0,2,4),(1/5,2/7,18/35)):
        lap=ddr+2*dr/radius-ell*(ell+1)*shape/radius**2
        work+=half*(2/3)*share/(4*pi/5)*np.dot(weights,radius**2*(shape-half**2*lap)**2)
    return sqrt(work/(8*pi*half**3))


def main():
    lookup={(row["seed"],row["width"]):float(row["newton"]) for row in rows(upstream("paired-speed-check.csv"))}
    output=[]
    for row in rows(HERE/"fast-stress-bounds.csv"):
        width=float(row["width"])
        factor=kernel(width,64)
        assert abs(kernel(width,128)/factor-1)<3e-13
        mass=float(row["launch_L1_ceiling"])
        norm=abs(lookup[row["seed"],row["width"]])
        coefficient=2*mass*1e6/norm*factor
        output.append(dict(seed=row["seed"],width=width,metric_fast_ppm=row["L1_fast_coefficient_ppm"],
            contact_fast_ppm=coefficient,positive_contact_kernel=factor,meaning="multiply by endpoint-average L1/launch ceiling divided by q"))
    table("time-dependent-contact.csv",output)


if __name__=="__main__":main()
