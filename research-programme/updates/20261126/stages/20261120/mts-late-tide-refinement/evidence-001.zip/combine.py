"""Compare time refinements, grids, central path and the frozen stress at matched q."""
from common import *


def index(group):
    return {(int(row["seed"]),float(row["width"]),float(row["fraction"]),row["channel"]):row
            for row in rows(HERE/f"compared-{group}.csv")}


def compare(first,second):
    left=index(first);right=index(second);assert left.keys()==right.keys()
    signs=[]
    for key,row in left.items():
        other=right[key]
        raw=float(other["curvature_ppm"])-float(row["curvature_ppm"])
        total=float(other["excess_ppm"])-float(row["excess_ppm"])
        for cut in (.1,.3,.7):
            central=float(other["central_curve_"+str(cut)])-float(row["central_curve_"+str(cut)])
            center_tide=float(other["central_tide_"+str(cut)])-float(row["central_tide_"+str(cut)])
            signs.append(dict(seed=key[0],width=key[1],fraction=key[2],channel=key[3],cut=cut,reference=first,variant=second,
                raw_curvature_difference_ppm=raw,central_prediction_ppm=central,unexplained_ppm=raw-central,
                total_tide_difference_ppm=total,unexplained_tide_ppm=total-center_tide))
    table("difference-"+first+"-"+second+".csv",signs)
    last=[row for row in signs if row["fraction"]==1 and row["cut"]==.3]
    print(first,second,"max full: raw / after central path:",*(max(abs(row[k]) for row in last) for k in ("raw_curvature_difference_ppm","unexplained_ppm")))


def mechanical(upper,lower):
    high=index(upper)
    if lower=="saved":
        saved=rows(upstream("time-curvature.csv"))
        low={(int(row["seed"]),float(row["width"]),float(row["fraction"]),"gauss"):row for row in saved if float(row["level"])==16}
    else:low=index(lower)
    predictions={(int(row["seed"]),float(row["width"])):float(row["forecast_ppm"]) for row in rows(upstream("mechanical-stress-forecast.csv")) if row["edge"]=="120" and row["order"]=="24"}
    results=[]
    for key in high.keys()&low.keys():
        seed,width,fraction,channel=key
        linear=2*float(high[key]["curvature_ppm"])-float(low[key]["curvature_ppm"])
        expected=predictions[seed,width]*fraction**2
        results.append(dict(seed=seed,width=width,fraction=fraction,channel=channel,upper=upper,lower=lower,
            curvature_affine_ppm=linear,mechanical_ppm=expected,unexplained_ppm=linear-expected,within_original_gate=abs(linear-expected)<=20))
    results.sort(key=lambda row:(row["seed"],row["width"],row["channel"],row["fraction"]))
    table("forecast-"+upper+"-"+lower+".csv",results)
    print(upper,lower,"max material residual",max(abs(row["unexplained_ppm"]) for row in results))


if __name__=="__main__":
    (compare if sys.argv[1]=="compare" else mechanical)(*sys.argv[2:4])
