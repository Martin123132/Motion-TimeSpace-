"""Matched proper-time collocation, compensated branch integrals and diagnostic state snapshots."""
from common import *
from math import fsum


def tag(grid,level,splits,flag,seed,scheme):
    return f"{scheme}-n{grid}-q{level}-p{splits}-off{flag}-s{seed}"


def run(grid,level,splits,flag,seed,scheme="original"):
    guard()
    stem=tag(grid,level,splits,flag,seed,scheme)
    shell=shell_for(grid,level,flag,seed)
    if scheme!="original":
        from regular import configure
        configure(shell,scheme)
    start=shell.initial
    degree=18 if splits==1 else 12
    panels=2*level*splits
    span=DURATION*np.sqrt(level)/panels
    times,plain,spin=kernels(degree,span,2*shell.mu)
    result=[];changes=[];parts=[];frows=[]
    total_change=np.zeros_like(start)
    for index in range(panels):
        guard()
        delta=np.zeros((degree+1,*start.shape),dtype=complex)
        for sweep in range(5):
            values=[];rates=[];source=[]
            for node,within in enumerate(times):
                time=index*span+within
                state=start+(total_change+delta[node])
                physical=shell.dynamics(time,state)
                if sweep==4:
                    value,rate=family.sample(shell,time,state,physical)
                    rates.append(rate)
                    if node==0 and index==0:
                        initial_rate=rate.copy();initial_value=value.copy()
                    if node==degree and (index+1)%(panels//8)==0:
                        endpoint=value.copy()
                else:source.append(physical)
            if sweep==4:
                parts.append(np.einsum("t,tij->ij",plain[-1],rates))
                total_change+=delta[-1]
                if (index+1)%(panels//8)==0:
                    changes.append(total_change.copy())
                    integrated=np.array([[fsum(chunk[j,k] for chunk in parts) for k in range(len(family.TERM))] for j in range(len(FRACTIONS))])
                    for idx,width in enumerate(FRACTIONS):
                        result.append(dict(seed=seed,flag=flag,grid=grid,level=level,splits=splits,scheme=scheme,width=width,
                            fraction=(1+index)/panels,first_gauss=initial_rate[idx,0],first_ricci=initial_rate[idx,1],
                            last_gauss=rates[-1][idx,0],last_ricci=rates[-1][idx,1],
                            endpoint_gauss=endpoint[idx,0]-initial_value[idx,0],endpoint_ricci=endpoint[idx,1]-initial_value[idx,1],**dict(zip(family.TERM,integrated[idx]))))
                break
            source=np.asarray(source)
            if not flag:
                source[:,14]-=shell.mu*delta[:,15]
                source[:,15]-=2j*shell.mu*delta[:,15]
            delta=apply_kernel(plain,source)
            if not flag:
                correction=apply_kernel(spin-plain,source[:,15])
                delta[:,14]+=correction/(2j);delta[:,15]+=correction
    assert np.isfinite(changes).all() and np.isfinite(integrated).all()
    packet(stem+".npz",change=np.array(changes),radius=shell.r)
    table(stem+".csv",result)
    print(stem,"complete",flush=True)


if __name__=="__main__":
    grid,level,splits=map(int,sys.argv[1:4])
    scheme=sys.argv[4] if len(sys.argv)>4 else "original"
    for flag in (0,1):
        for seed in (0,1,-1):
            run(grid,level,splits,flag,seed,scheme)
