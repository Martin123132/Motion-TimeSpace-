"""Pair four physical branches before comparing the local curvature acceleration."""
from common import *
from math import fsum
import re


def dictionary(items):
    return {(int(row["seed"]),int(row["flag"]),float(row["width"]),float(row["fraction"])):row for row in items}


def branch_values(data,seed,width,fraction,metric):
    return [float(data[seed,0,width,fraction][metric]),-float(data[seed,1,width,fraction][metric]),
            -float(data[0,0,width,fraction][metric]),float(data[0,1,width,fraction][metric])]


def build(group,paths=True):
    match=re.fullmatch(r"(\w+)-n(\d+)-q(\d+)-p(\d+)",group)
    scheme=match.group(1)
    grid,level,splits=map(int,match.groups()[1:])
    old=dictionary([row for flag in (0,1) for seed in (0,1,-1) for row in rows(upstream(f"times-exp-h5-n120-q{level}-d18-p1-k4-off{flag}-s{seed}.csv"))])
    actual=dictionary([row for path in sorted(HERE.glob(group+"-off*-s*.csv")) for row in rows(path)])
    assert len(actual)==96
    newton=dictionary(rows(upstream("newton-time-h5.csv")))
    norms={};out=[];partition=[]
    if paths:
        raw=rows(HERE/("path-"+group+".csv"))
        split={(cut,channel):dictionary([row for row in raw if float(row["cut"])==cut and row["channel"]==channel]) for cut in (.10,.30,.70) for channel in ("gauss","ricci")}
    for seed in (1,-1):
        for width in FRACTIONS:
            norm=float(newton[seed,0,width,1.]["integral_total"])-float(newton[seed,1,width,1.]["integral_total"])
            def ppm(amount):return amount*1e6/norm
            for fraction in np.arange(1,9)/8:
                def paired(data,key):
                    return fsum(branch_values(data,seed,width,fraction,key))
                def scalar(data,key):return level*paired(data,key)
                new=fraction*DURATION
                impulse=float(newton[seed,0,width,fraction]["integral_total"])-float(newton[seed,1,width,fraction]["integral_total"])
                launch_newton=float(newton[seed,0,width,0.]["rate_total"])-float(newton[seed,1,width,0.]["rate_total"])
                for channel in ("gauss","ricci"):
                    total=scalar(actual,channel)
                    excess=ppm(total-impulse)
                    launch=ppm(new*(np.sqrt(level)*scalar(actual,"first_"+channel)-launch_newton))
                    quant=dict(group=group,grid=grid,level=level,seed=seed,width=width,channel=channel,fraction=fraction,
                        excess_ppm=excess,curvature_ppm=excess-launch,refine_ppm=ppm(total-scalar(old,channel)),
                        fallback_order_ppm=ppm(level*sum(branch_values(actual,seed,width,fraction,channel))-total),
                        endpoint_drift_ppm=ppm(scalar(actual,"endpoint_"+channel)-total))
                    if paths:
                        for cut in (.10,.30,.70):
                            item=split[cut,channel]
                            quant["central_curve_"+str(cut)]=ppm(scalar(item,"curved_part"))
                            quant["central_tide_"+str(cut)]=ppm(scalar(item,"delta"))
                    out.append(quant)
                total=scalar(actual,"gauss")
                components={key:scalar(actual,key) for key in family.LABELS}
                partition.append(dict(seed=seed,width=width,fraction=fraction,group=group,
                    sum_budget_ppm=ppm(fsum(components.values())-total),
                    rest_refine_ppm=ppm(fsum(components[key]-scalar(old,key) for key in ("rest_dust","rest_heavy"))),
                    geometry_refine_ppm=ppm(fsum(components[key]-scalar(old,key) for key in ("intrinsic","extrinsic"))),
                    explicit_refine_ppm=ppm(fsum(components[key]-scalar(old,key) for key in family.LABELS if key not in ("rest_dust","rest_heavy","intrinsic","extrinsic")))))
    return out,partition


if __name__=="__main__":
    group=sys.argv[1]
    out,budget=build(group,"--early" not in sys.argv)
    if "--early" not in sys.argv:
        table("compared-"+group+".csv",out);table("budget-"+group+".csv",budget)
    for row in out:
        if row["channel"]=="gauss" and row["width"]==.15 and row["fraction"]==1.:print(row)
