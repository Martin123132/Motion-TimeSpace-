"""Confirm the centre treatment does not introduce a new matter model or expansion history."""
from common import *
from regular import configure
import dust_control


def main():
    records=[];checks=[]
    for grid in (120,160):
        for flag in (0,1):
            for seed in (0,1,-1):
                shell=shell_for(grid,32,flag,seed)
                pristine=shell_for(grid,32,flag,seed)
                configure(shell,"trace6")
                change_file=HERE/f"original-n{grid}-q32-p1-off{flag}-s{seed}.npz"
                with np.load(change_file) as bank:changes=bank["change"]
                for index in (0,5,7):
                    state=pristine.initial+changes[index]
                    time=(index+1)/8*DURATION*np.sqrt(32)
                    left=pristine.dynamics(time,state)
                    right=shell.dynamics(time,state)
                    assert np.array_equal(left[:5],right[:5]) and np.array_equal(left[8:],right[8:])
                    assert np.array_equal(left[...,6:],right[...,6:])
                    checks.append(dict(grid=grid,seed=seed,flag=flag,fraction=(index+1)/8,changed=np.count_nonzero(left!=right),
                        trace_difference=np.max(abs(left[4]-right[4])),matter_difference=np.max(abs(left[8:]-right[8:])),exterior_difference=np.max(abs(left[...,6:]-right[...,6:]))))
    original=dust_control.system
    try:
        for name in ("trace6","trace8"):
            def patched(*args):
                shell=original(*args);configure(shell,name);return shell
            dust_control.system=patched
            for grid in (120,160):
                for level in (4,32):
                    for row in dust_control.run(grid,level):records.append(dict(scheme=name,**row))
    finally:dust_control.system=original
    table("unchanged-matter.csv",checks);table("trace-preserving-dust.csv",records)
    for key in ("error_ppm","gauge_leak_ppm"):print(key,max(abs(row[key]) for row in records))


if __name__=="__main__":main()
