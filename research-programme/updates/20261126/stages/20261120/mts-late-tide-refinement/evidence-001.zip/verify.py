"""Integrity and coverage, including failures; no evolution and no reliance on a green count alone."""
import ast
import csv
import hashlib
import json
import math
import re
import sys
from pathlib import Path

HERE=Path(__file__).resolve().parent
PREV=HERE.parent/"mts-matched-speed-family-20261120"
PIN="f462610a670f37c2b10cec2ae3660d5736533fbd0d5b8cd7f231a8f485c84f35"


def digest(path):
    with path.open("rb") as stream:return hashlib.file_digest(stream,"sha256").hexdigest()


def records(path):
    with path.open(newline="") as stream:items=list(csv.DictReader(stream))
    assert items and all(None not in row and None not in row.values() for row in items)
    return items


def verify():
    assert digest(PREV/"seal.json")==PIN
    upstream=json.loads((PREV/"seal.json").read_bytes())["files"]
    for name,mark in upstream.items():assert digest(PREV/name)==mark,name
    assert not list(HERE.glob("*.partial")) and not (HERE/"__pycache__").exists()
    for path in HERE.glob("*.py"):ast.parse(path.read_bytes(),filename=str(path))
    packets=list(HERE.glob("*-off*-s*.npz"))
    groups={path.stem.split("-off")[0] for path in packets}
    assert len(groups)==11 and len(packets)==66
    for group in groups:
        actual={}
        for seed in (0,1,-1):
            for flag in (0,1):
                prefix=group+f"-off{flag}-s{seed}"
                assert (HERE/(prefix+".npz")).is_file()
                items=records(HERE/(prefix+".csv"));assert len(items)==16
                for row in items:
                    assert int(row["seed"])==seed and int(row["flag"])==flag
                    actual[seed,flag,float(row["width"]),float(row["fraction"])]=row
        assert len(actual)==96
        assert set(key[-1] for key in actual)=={idx/8 for idx in range(1,9)}
        assert set(key[-2] for key in actual)=={.15,.3}
        for prefix,count in (("compared",64),("budget",32),("modes",60),("path",576),("core",480)):
            assert len(records(HERE/(prefix+"-"+group+".csv")))==count,group
    eig=records(HERE/"origin-eigenvalues.csv")
    assert len(eig)==6 and all(float(row["local_rhs_error"])<1e-9 and float(row["left_in_12"])>.99 for row in eig)
    moment=records(HERE/"growing-mode-constraints.csv")
    assert len(moment)==8
    assert all(max(float(row[key]) for key in ("hamiltonian_scaled","radial_momentum_scaled","polar_momentum_scaled"))>1e-3 for row in moment)
    original=records(HERE/"modes-original-n160-q32-p1.csv")
    observed=[float(row["recurrence_relative"]) for row in original if row["seed"]!="0" and row["end_fraction"]=="1.0"]
    assert len(observed)==8 and max(observed)<.001
    paths=records(HERE/"difference-original-n120-q32-p1-original-n160-q32-p1.csv")
    last=[row for row in paths if row["fraction"]=="1.0" and row["cut"]=="0.1"]
    assert len(last)==8 and max(abs(float(row["unexplained_ppm"])/float(row["raw_curvature_difference_ppm"])) for row in last)<.001
    unchanged=records(HERE/"unchanged-matter.csv")
    assert len(unchanged)==36
    assert all(float(row[key])==0 for row in unchanged for key in ("matter_difference","trace_difference","exterior_difference"))
    raw=records(HERE/"causal-frozen-stress.csv")
    assert len(raw)==360 and all(abs(float(row["causal_ppm"]))<=float(row["absolute_bound_ppm"]) for row in raw)
    assert max(float(row["max_abs_error"]) for row in records(HERE/"causal-controls.csv"))<1e-8
    assert max(abs(float(row["discrepancy_ppm"])) for row in records(HERE/"physical-wave-propagation.csv"))<1
    assert max(abs(float(row["relative"])) for row in records(HERE/"physical-wave-controls.csv"))<2e-5
    assert max(abs(float(row["scaled"])+.5) for row in records(HERE/"fast-source-controls.csv"))<1e-12
    frozen={(row["seed"],row["width"]):float(row["coefficient_ppm"]) for row in records(HERE/"causal-bound.csv") if row["edge"]=="120"}
    rough=records(HERE/"fast-stress-bounds.csv")
    assert all(abs(float(row["launch_slow_frozen_coefficient_ppm"])/frozen[row["seed"],row["width"]]-1)<1e-12 for row in rough)
    historical=records(HERE/"isolated-state-energy-ceilings.csv")
    assert len(historical)==6 and {row["ell"] for row in historical}=={"0","1"}
    assert all(0<float(row["kinetic"])<=float(row["isolated_kinetic_ceiling"])<=float(row["impulse_form_zero_force_ceiling"]) for row in historical)
    assert len(records(HERE/"occupation-energy-controls.csv"))==8
    endpoints=records(HERE/"time-dependent-contact.csv")
    assert len(endpoints)==4 and all(float(row["contact_fast_ppm"])>0 for row in endpoints)
    for prefix,count in (("finite-endpoints-",192),("endpoint-check-",64)):
        products=list(HERE.glob(prefix+"*-d*.csv"))
        assert len(products)==4 and all(len(records(path))==count for path in products)
    precision=records(HERE/"precision-gates.csv")
    assert len(precision)==5 and all(row["within"]=="True" and float(row["worst_ppm"])<=20 for row in precision)
    tests=records(HERE/"acceptance-and-failures.csv")
    assert all((row["within"]=="True")==(abs(float(row["worst"]))<=float(row["tolerance"])) for row in tests)
    assert any(row["within"]=="False" and "original-n160-q32" in row["test"] for row in tests)
    print("files and physical tests checked; failures retained:",sum(row["within"]=="False" for row in tests),"/",len(tests))
    target=HERE/"seal.json"
    files={path.name:digest(path) for path in sorted(HERE.iterdir()) if path.is_file() and path!=target}
    sizes={}
    for name in files:
        if not name.endswith(".csv"):continue
        data=records(HERE/name);sizes[name]=len(data)
        for row in data:
            for item in row.values():
                try:number=float(item)
                except ValueError:continue
                assert math.isfinite(number),(name,item)
    result=dict(previous=PIN,upstream_count=len(upstream),files=files,csv_rows=sizes)
    if sys.argv[1:]==["seal"]:
        with target.open("x",encoding="utf-8",newline="\n") as stream:json.dump(result,stream,indent=2);stream.write("\n")
    else:
        assert not sys.argv[1:]
        if target.exists():assert json.loads(target.read_bytes())==result
    print(len(files),"files",sum(sizes.values()),"rows",len(upstream),"upstream",digest(target) if target.exists() else "not sealed")


if __name__=="__main__":verify()
