"""Exact finite change in the window due solely to changing distance through the central path."""
from common import *
from math import fsum
import re


def path_delta(tide,win,metric,dist,shift):
    normal,angular=metric
    radial,polar=dist
    mono,quad=win.at(tide)
    shift0,shift2=shift
    nodes,weights=leggauss(6)
    rows=[]
    for width in FRACTIONS:
        half=CENTER*width
        integral=0.
        for node,coef in zip((nodes+1)/2,weights/2):
            displacement=radial-(1-node)*shift0
            polar_length=polar-(1-node)*shift2
            prime=weight(displacement,half,1)
            double=weight(displacement,half,2)
            integral+=coef*np.dot(win.quad,shift0*(prime*(normal*quad+angular*mono)+double*normal*polar_length*mono)+shift2*prime*normal*mono)
        rows.append(integral)
    return rows


def examine(path):
    match=re.fullmatch(r"(\w+)-n(\d+)-q(\d+)-p(\d+)-off(\d+)-s(-?\d+)",path.stem)
    assert match,path
    scheme=match.group(1)
    grid,level,splits,flag,seed=map(int,match.groups()[1:])
    shell=shell_for(grid,level,flag,seed)
    if scheme!="original":
        from regular import configure
        configure(shell,scheme)
    time_scale=DURATION*np.sqrt(level)
    start=shell.initial;initial_metric=exp(start[0].real)
    header=dict(scheme=scheme,grid=grid,level=level,splits=splits,flag=flag,seed=seed)
    shifts=[];core=[];budgets=[]
    with np.load(path) as data:
        np.testing.assert_array_equal(data["radius"],shell.r)
        changes=data["change"]
    for idx,change in enumerate(changes):
        fraction=(idx+1)/8;state=start+change
        time=time_scale*fraction
        rhs=shell.dynamics(time,state)
        win=Window(shell,state,rhs,8)
        metric_grid=exp(state[0].real)
        interp=win.spline(metric_grid)
        metric=interp(win.pos)
        anti=interp.antiderivative()
        distance=anti(win.pos)-anti(0.)[:,None]
        ell_change=change[0].real
        change_metric=family.pair(initial_metric[0]*np.expm1(ell_change[0]),initial_metric[1]*np.expm1(ell_change[0])+metric_grid[0]*ell_change[1])
        anti_change=win.spline(change_metric).antiderivative()
        if idx==0:
            tangent=shell.dynamics(0.,start)
            original=Window(shell,start,tangent,8)
            orig_interp=original.spline(initial_metric)
            anti_orig=orig_interp.antiderivative()
            orig_dist=anti_orig(original.pos)-anti_orig(0.)[:,None]
            orig_tide=tensors(shell,start,tangent)
            launch_time=original.spline(mul(initial_metric,tangent[0].real)).antiderivative()
            source=shell.incident.bank.at(0)[4]
        tides=tensors(shell,state,rhs)
        for channel,field,launch in zip(("ricci","gauss"),tides,orig_tide):
            tide=field.real.copy();tide[1]+=shell.incident.bank.at(time)[4]
            launch=launch.real.copy();launch[1]+=source
            for cut in (.10,.30,.70):
                displacement=anti_change(cut)-anti_change(0.)
                raw=path_delta(tide,win,metric,distance,displacement)
                length_rate=launch_time(cut)-launch_time(0.)
                mono,quad=original.at(launch)
                norm,ang=orig_interp(original.pos)
                for width,increment in zip(FRACTIONS,raw):
                    prime=weight(orig_dist[0],CENTER*width,1)
                    second=weight(orig_dist[0],CENTER*width,2)
                    launch_rate=np.dot(original.quad,length_rate[0]*(prime*(norm*quad+ang*mono)+second*norm*orig_dist[1]*mono)+length_rate[1]*prime*norm*mono)
                    shifts.append(dict(**header,fraction=fraction,channel=channel,width=width,cut=cut,delta=increment,
                        launch_rate=launch_rate,curved_part=increment-time*launch_rate,length0=displacement[0],length2=displacement[1]))
        details=shell.dynamics(time,state,True)
        for lower,upper in ((0,.1),(.1,.3),(.3,.7),(.7,2.0),(2.,5.9)):
            select=(shell.r>=lower)&(shell.r<upper)
            for harmonic in (0,1):
                index=(harmonic,select)
                mode=(state[0,harmonic].real-state[1,harmonic].real)
                regular=(mode if not harmonic else state[2,harmonic].real-state[3,harmonic].real)
                core.append(dict(**header,fraction=fraction,lower=lower,upper=upper,ell=2*harmonic,
                    shape_origin=regular[0],peak_shape=max(abs(regular[select])),peak_ham=max(abs(details["ham"][index])),
                    peak_shear=max(abs(state[5].real[index])),peak_log_radial=max(abs(change[0].real[index]))))
    return shifts,core


if __name__=="__main__":
    group=sys.argv[1]
    first=[];second=[]
    for path in sorted(HERE.glob(group+"-off*-s*.npz")):
        left,right=examine(path);first+=left;second+=right
    assert len(first)==6*8*2*2*3 and len(second)==6*8*5*2
    table("path-"+group+".csv",first);table("core-"+group+".csv",second)
