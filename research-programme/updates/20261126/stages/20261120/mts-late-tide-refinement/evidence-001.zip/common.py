"""Checked inputs and local write-once outputs. No changes to upstream snapshots."""
import csv
import hashlib
import io
import json
import os
import sys
from pathlib import Path

HERE=Path(__file__).resolve().parent
PREV=HERE.parent/"mts-matched-speed-family-20261120"
PIN="f462610a670f37c2b10cec2ae3660d5736533fbd0d5b8cd7f231a8f485c84f35"
for key in ("OMP_NUM_THREADS","MKL_NUM_THREADS","OPENBLAS_NUM_THREADS","NUMEXPR_NUM_THREADS"):os.environ[key]="1"


def digest(path):
    with path.open("rb") as stream:return hashlib.file_digest(stream,"sha256").hexdigest()


assert digest(PREV/"seal.json")==PIN
registry=json.loads((PREV/"seal.json").read_bytes())["files"]


def upstream(name):
    path=PREV/name
    assert digest(path)==registry[name],path
    return path


for name in ("family.py","speed_collocation.py","curvature_test.py","dust_control.py"):upstream(name)
sys.path.insert(0,str(PREV))
import family
from family import DURATION,FRACTIONS,Window,tensors,sources,np
from predict import kernels,apply_kernel
from window import weight,CENTER,exp,mul,leggauss


def guard():
    family.guard()
    assert not (HERE/"STOP-REQUESTED").exists()


def rows(path):
    with path.open(newline="") as stream:return list(csv.DictReader(stream))


def keep(name,data):
    guard()
    path=HERE/name
    if path.exists():assert path.read_bytes()==data,path
    else:
        partial=path.with_suffix(path.suffix+".partial")
        with partial.open("xb") as stream:stream.write(data)
        partial.rename(path)


def table(name,records):
    stream=io.StringIO(newline="")
    writer=csv.DictWriter(stream,fieldnames=tuple(records[0]),lineterminator="\n")
    writer.writeheader();writer.writerows(records)
    keep(name,stream.getvalue().encode())


def packet(name,**data):
    stream=io.BytesIO()
    np.savez_compressed(stream,**data)
    keep(name,stream.getvalue())


def shell_for(grid,level,flag,seed):
    upstream(family.packet_name(5,level,flag,seed))
    return family.system(5,grid,level,flag,seed)
