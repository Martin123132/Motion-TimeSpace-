"""Independent Hamiltonian and momentum constraints on the predicted growing eigenvectors."""
from common import *
from origin_modes import spatial,select,Vacuum


def main():
    rows_out=[]
    for grid in (120,160):
        shell=shell_for(grid,32,1,1)
        shell.rho=np.zeros(3);shell.incident.bank=Vacuum(len(shell.r))
        size=48
        for ell,op in zip((0,2),spatial(size)):
            growth,left,right=select(op)
            radial,mixed,angular=(right,np.zeros(size),np.zeros(size)) if not ell else right.reshape(3,-1)
            tangent=np.zeros_like(shell.initial)
            harmonic=int(ell>0)
            tangent[0,harmonic,:size]=2*radial/3;tangent[1,harmonic,:size]=-radial/3
            tangent[2,1,:size]=mixed;tangent[3,1,:size]=angular
            tangent[5,harmonic,:size]=-2*radial*growth/(3*shell.dx)
            tangent[6,1,:size]=-mixed*growth/(2*shell.dx);tangent[7,1,:size]=-angular*growth/(2*shell.dx)
            for amplit in (1e-5,1e-6):
                high=shell.dynamics(0,tangent*amplit,True);low=shell.dynamics(0,-tangent*amplit,True)
                test=lambda key:np.max(abs((high[key]-low[key])[:,:12]))*shell.dx**2/(2*amplit)
                rows_out.append(dict(grid=grid,ell=ell,amplitude=amplit,growth_in_cell_units=growth,
                    hamiltonian_scaled=test("ham"),radial_momentum_scaled=test("mom_r"),polar_momentum_scaled=test("mom_theta")))
    table("growing-mode-constraints.csv",rows_out)
    print(rows_out[1], rows_out[3])


if __name__=="__main__":main()
