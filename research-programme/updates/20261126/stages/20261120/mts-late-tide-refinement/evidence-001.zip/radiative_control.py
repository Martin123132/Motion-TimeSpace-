"""An actual regular radiative TT quadrupole on vacuum, not just a coordinate quadrupole."""
from common import *
from origin_modes import Vacuum
from regular import configure
from scipy.special import spherical_jn


def fixture(grid,level,scheme,wave_number):
    shell=shell_for(grid,level,1,1)
    if scheme!="original":configure(shell,scheme)
    shell.rho=np.zeros(3);shell.incident.bank=Vacuum(len(shell.r))
    arg=wave_number*shell.r
    radial=15*spherical_jn(2,arg)/arg**2
    first=-15*spherical_jn(3,arg)/arg
    second=15*(spherical_jn(4,arg)-spherical_jn(3,arg)/arg)
    mixed=(first+3*radial)/6
    tensor=((second+4*first)/6+3*mixed-radial/2)/2
    start=np.zeros_like(shell.initial)
    start[0,1]=radial/2;start[1,1]=-radial/4;start[2,1]=mixed;start[3,1]=tensor
    delta=np.zeros_like(start);duration=DURATION*np.sqrt(level)
    steps=48;step=duration/steps;results=[];orig={}
    for tick in range(steps+1):
        time=tick*step;state=start+delta
        one=shell.dynamics(time,state)
        if tick in (0,steps//2,steps):
            win=Window(shell,state,one,12)
            for channel,tidal in zip(("ricci","gauss"),tensors(shell,state,one)):
                factors=win.at(tidal.real);values=win.widths[:,0]@factors[1]+win.widths[:,1]@factors[0]
                if tick==0:
                    orig[channel]=values
                else:
                    for idx,width in enumerate(FRACTIONS):
                        half=CENTER*width;nodes,weights=leggauss(64)
                        refpos=wave_number*(CENTER+half*nodes)
                        radial_average=half*np.dot(weights,weight(CENTER+half*nodes,half)*15*spherical_jn(2,refpos)/refpos**2)
                        ref=wave_number**2*np.sin(wave_number*time/2)**2*radial_average
                        change=values[idx]-orig[channel][idx]
                        expected=-2*np.sin(wave_number*time/2)**2*radial/2
                        core=shell.r<.1
                        results.append(dict(grid=grid,level=level,scheme=scheme,k=wave_number,fraction=tick/steps,width=width,
                            channel=channel,expected_change=ref,recovered=change,window_error_ppm=1e6*(change/ref-1),
                            core_metric_error_ppm=1e6*np.max(abs(delta[0,1,core].real-expected[core]))/np.max(abs(expected[core]))))
        if tick==steps:break
        two=shell.dynamics(time+step/2,start+(delta+step*one/2))
        three=shell.dynamics(time+step/2,start+(delta+step*two/2))
        four=shell.dynamics(time+step,start+(delta+step*three))
        delta+=step*(one+2*two+2*three+four)/6
    return results


def main():
    result=[]
    for scheme in ("original","cart6","trace6","trace8"):
        for grid in (120,160):
            for k in (.9,2.2):
                result+=fixture(grid,32,scheme,k)
    table("radiative-vacuum.csv",result)
    for scheme in ("original","cart6","trace6","trace8"):
        chosen=[row for row in result if row["scheme"]==scheme]
        print(scheme,max(abs(row["window_error_ppm"]) for row in chosen), max(row["core_metric_error_ppm"] for row in chosen))


if __name__=="__main__":main()
