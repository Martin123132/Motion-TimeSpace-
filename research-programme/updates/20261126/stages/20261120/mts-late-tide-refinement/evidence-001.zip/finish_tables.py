from common import *
from combine import compare,mechanical
from summary_tables import summarize


def main():
    for first,second in (
        ("original-n120-q32-p1","original-n120-q32-p2"),
        ("original-n120-q32-p1","original-n160-q32-p1"),
        ("cart6-n120-q32-p1","cart6-n160-q32-p1"),
        ("cart6-n160-q32-p1","cart8-n160-q32-p1"),
        ("trace6-n120-q32-p1","trace6-n160-q32-p1"),
        ("cart6-n160-q32-p1","trace6-n160-q32-p1"),
        ("cart6-n160-q16-p1","trace6-n160-q16-p1"),
        ("cart8-n160-q32-p1","trace6-n160-q32-p1")):
        compare(first,second)
    for first,second in (
        ("original-n120-q32-p1","saved"),("original-n160-q32-p1","original-n160-q16-p1"),
        ("cart6-n160-q32-p1","cart6-n160-q16-p1"),("trace6-n160-q32-p1","trace6-n160-q16-p1")):
        mechanical(first,second)
    summarize()


if __name__=="__main__":main()
