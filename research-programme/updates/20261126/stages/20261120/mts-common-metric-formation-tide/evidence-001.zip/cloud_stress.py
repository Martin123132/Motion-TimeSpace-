"""Proper shear of the retained matter, conditional on its saved weak-field state."""
from anchor import *
from balanced import BalancedNative
from scipy.interpolate import BarycentricInterpolator
from scipy.constants import c,parsec

def sample(mesh,raw,radius):
    at=radius/mesh.h
    indices={min(mesh.segments-1,int(at))}
    if abs(at-round(at))<1e-11 and 0<round(at)<mesh.segments:indices={round(at)-1,round(at)}
    values=[];derivatives=[]
    for slot in sorted(indices):
        nodes=mesh.elem[slot]
        poly=BarycentricInterpolator(mesh.r[nodes],raw[...,nodes],axis=-1,rng=0)
        values.append(poly(radius));derivatives.append(poly.derivative(radius))
    return np.mean(values,axis=0),np.mean(derivatives,axis=0)

def read_model(model,rate):
    stop=SPAN*DLOG
    sim=BalancedNative(model,120,rate*120,False,"native36",stop)
    mesh=sim.mesh;p=sim.patch
    hub,scale=p.coeff(stop)
    rh=p.p.coeff/scale
    eps=np.zeros_like(rh)
    if p.wave:eps[p.j]=1/(2*scale*p.p.mass)**2
    reference=sim.ref.solution(stop)*sim.ref.weight
    results=[];controls=[]
    physical=c**2/(scale*1e6*parsec)**2
    for sign in (1,-1):
        filename=(f"evolved-{model}-L120-h{rate}-t176.npz" if sign==1 else f"collar-{model}-L120-h{rate}--1.npz")
        with np.load(saved(filename)) as archive:
            assert archive["x"][-1]==stop
            mono,d,w=(archive[key] for key in ("mono","density","velocity"))
            retain=archive["forces"][-1,6] if sign==1 else archive["radial"][-1,0]
        metric=sim.observe((mono,d,w),stop)
        assert np.allclose(retain,metric[6],rtol=1e-7,atol=1e-24)
        for idx,radius in enumerate(sim.obs[:7]):
            raw,slope=sample(mesh,mesh.grid(mono),radius)
            number=1+raw[0]/radius
            grad=(slope[0]-raw[0]/radius)/radius
            speed=(slope[1]-raw[1]/radius)/radius
            assert number.min()>.5
            base,prime,_=sim.operators(np.array([radius]))
            dint,dprime=sample(mesh,mesh.grid(d),radius)
            wint,wprime=sample(mesh,mesh.grid(w),radius)
            den,vel=(reference@base)[...,0]+np.stack((dint,wint))
            dr,dv=(reference@prime)[...,0]+np.stack((dprime,wprime))
            tn=-(2/3)*(dint@rh)/2-2*metric[6,:,idx]/radius-6*metric[5,:,idx]/radius**2
            for ch in (0,1):
                phase=[den[ch]*speed**2+2*number*speed*dv[ch],number*speed*vel[ch]/radius]
                amplitude=[2*grad*dr[ch]/number-grad**2*den[ch]/number**2,grad*den[ch]/(number*radius)]
                for side in (0,1):
                    angular=(2/3,-1.5)[side]
                    stream=.5*angular*(rh@phase[side])
                    wave=.5*angular*((rh*eps)@amplitude[side])
                    rho=den[ch];density_r=dr[ch]
                    theta=(0.,np.pi/4)[side]
                    er=np.array([np.sin(theta),0.,np.cos(theta)])
                    et=np.array([np.cos(theta),0.,-np.sin(theta)])
                    Y=(3*np.cos(theta)**2-1)/2;Yt=-3*np.sin(theta)*np.cos(theta)
                    def independent(t):
                        local=number+t*rho*Y
                        g=(grad+t*density_r*Y)[:,None]*er+(t*rho*Yt/radius)[:,None]*et
                        v=(speed+t*dv[ch]*Y)[:,None]*er+(t*vel[ch]*Yt/radius)[:,None]*et
                        amp=g/np.sqrt(local)[:,None]
                        flow=np.sqrt(local)[:,None]*v
                        stress=((rh*eps)[:,None]*amp).T@amp+(rh[:,None]*flow).T@flow
                        stress-=np.eye(3)*np.trace(stress)/3
                        return er@stress@(er if side==0 else et)/2
                    direct=independent(1e-25j).imag/1e-25
                    err=abs(direct-stream-wave)/max(abs(stream)+abs(wave),1e-45)
                    assert err<2e-9
                    coord=("axial_rr_tf","meridional_rtheta")[side]
                    result=dict(model=model,rate=rate,seed=sign,branch=("on","off")[ch],radius=radius,component=coord,
                        phase=stream,gradient_on_same_fields=wave,ricci_matter=(stream+(wave if ch==0 else 0)),
                        ricci_si_sminus2=(stream+(wave if ch==0 else 0))*physical,
                        newton_host_tide=tn[ch] if side==0 else None,cartesian_norm_error=err)
                    results.append(result)
            for side in (0,1):
                on,off=results[-4+side],results[-2+side]
                dstream=.5*(2/3*(rh@(den[2]*speed**2+2*number*speed*dv[2])) if side==0 else -1.5*(rh@(number*speed*vel[2]/radius)))
                expected=on["phase"]-off["phase"]
                norm=max(abs(on["phase"]),abs(off["phase"]),1e-45)
                assert abs(dstream-expected)/norm<1e-11
                if model=="cold":assert on["gradient_on_same_fields"]==0 and dstream==0 and tn[2]==0
                controls.append(dict(model=model,rate=rate,seed=sign,radius=radius,component=on["component"],
                          stream_change=dstream,explicit_gradient=on["gradient_on_same_fields"],
                          total_change=dstream+on["gradient_on_same_fields"],newton_host_change=tn[2] if side==0 else None,
                          streaming_subtraction_on_peak=abs(dstream-expected)/norm))
    return results,controls
def main():
    results=[];controls=[]
    for model in ("heavy","cold"):
        for rate in (4,5):
            raw,test=read_model(model,rate);results+=raw;controls+=test
    table("cloud-stress.csv",results);table("cloud-difference.csv",controls)
if __name__=="__main__":main()
