"""Change only the retained heavy pressure after recording the common launch state."""
from pathlib import Path
import ctypes,os,sys,json,hashlib
for variable in ("OPENBLAS_NUM_THREADS","OMP_NUM_THREADS","OMP_THREAD_LIMIT","MKL_NUM_THREADS","BLIS_NUM_THREADS","NUMEXPR_NUM_THREADS"):os.environ[variable]="1"
here=Path(__file__).resolve().parent
original=here.parent/"condensate-origin-20261003/native-heavy-matching-20261007/native/camb/cambdll.dll"
variant=here/"native-serial-switch.dll"
receipt=json.loads((here/"native-serial-inputs.json").read_bytes())
for path,key in ((original,"original"),(variant,"variant")):
    assert hashlib.sha256(path.read_bytes()).hexdigest()==receipt[key]
comparing="MTS_COMPARE_DLL" in os.environ
if comparing:
    variant=Path(os.environ["MTS_COMPARE_DLL"])
    assert hashlib.sha256(variant.read_bytes()).hexdigest()==os.environ["MTS_COMPARE_SHA"]
real_load=ctypes.LibraryLoader.LoadLibrary
def choose(loader,name):
    if Path(name).resolve()==original:return real_load(loader,str(variant))
    return real_load(loader,name)
ctypes.LibraryLoader.LoadLibrary=choose
try:
    from native_source import *
finally:
    ctypes.LibraryLoader.LoadLibrary=real_load
lib=camb.baseconfig.camblib
camb.config.ThreadNum=1
assert Path(lib._name).resolve()==variant
def collect(model,boost,flag):
    _,epochs,_,_,_=prepare(model,0)
    inputs=obj(source("runs/"+model+"/status.json"))
    origin=SPEC/"runs/projection/a225-w6-d8.npz" if model=="heavy" else NATIVE/"runs/backgrounds/cold.npz"
    checked(origin,inputs["source_hash"])
    params=inherited.params_for(origin,background_boost=8.)
    params.DoLateRadTruncation=False
    bg=camb.get_background(params)
    bg.Params.Accuracy.IntTolBoost=boost
    bg.Params.Accuracy.lAccuracyBoost=4
    oblib=ctypes.CDLL(str(OBSERVER))
    ptr=ctypes.cast(oblib.source_func_,ctypes.c_void_p)
    index=ctypes.c_int.in_dll(lib,"mts_turn_index")
    switch=ctypes.c_int.in_dll(lib,"mts_remove_pressure")
    with np.load(LONG/(model+"-environment.npz")) as hist:
        k=hist["k"];x=hist["loga"]
    keep=np.flatnonzero((x>=0)&(x<=SPAN*DLOG+1e-10))
    scales=AI*np.exp(x[:keep[-1]+2])
    early=epochs[epochs<min(scales)]
    grid=bg.conformal_time(1/np.r_[early,scales]-1,tol=1e-10)
    first=len(early)+keep[0]
    tiny=np.array([.0625,.125,.25,.5,1.,2.])
    eta=np.ascontiguousarray(np.insert(grid,first+1,grid[first]+tiny))
    assert np.all(np.diff(eta)>0)
    index.value=int(first+1)
    names=camb.model.evolve_names+OBS
    width=len(names)
    all_chunks=[]
    for path in sorted((SPEC/"runs"/model).glob("chunk-*.npz")):
        guard()
        with np.load(source(path.relative_to(SPEC).as_posix())) as old:
            modes=old["modes"][np.isin(old["modes"],k)]
            if not len(modes):continue
            batch=np.unique(np.r_[modes,old["modes"].max()])
        switch.value=flag
        data=np.zeros((len(batch),len(eta),width))
        ref=lambda value:ctypes.byref(ctypes.c_int(value))
        code=camb.results.CAMB_TimeEvolution(ctypes.byref(bg),ref(len(batch)),batch,ref(len(eta)),eta,ref(width),data,ref(len(OBS)),ctypes.byref(ptr))
        assert code==0 and np.isfinite(data).all()
        selected=data[np.searchsorted(batch,modes),first:-1].copy()
        if model=="heavy":
            dp=selected[:,:,names.index("mts_dp_h")]
            assert np.all(dp[:,0]!=0) and (np.all(dp[:,1:]==0) if flag else np.all(dp!=0)), (path.name,first,index.value,switch.value,dp[:, :4].tolist(),np.sum(dp!=0,axis=1).tolist())
        all_chunks.append(selected)
    label=f"serial-{model}-b{boost}-off{flag}.npz"
    product=dict(k=k,tau=eta[first:-1],names=names,values=np.concatenate(all_chunks),boost=boost)
    if comparing:
        with np.load(HERE/label) as cache:
            for key,value in product.items():np.testing.assert_array_equal(value,cache[key])
    else:packet(label,**product)
if __name__=="__main__":
    model,boost,flag=sys.argv[1:]
    collect(model,int(boost),int(flag))
