from anchor import *
from scipy.special import spherical_jn
from scipy.constants import c, parsec
from stage import ROOT as LONG

RADII=(.676538827,1.35307765,2.7061553,6.,12.,18.,24.,36.,48.)
def decode(model):
    with np.load(HERE/(model+"-all.npz")) as arch:
        k=arch["k"][:,None];x=arch["x"];eta_time=arch["eta"]
        named=arch["keys"].tolist();values=arch["values"].transpose(2,0,1)
        standard=dict(zip(named[:-30],values[:-30]));ob=dict(zip(named[-30:],values[-30:]))
        coeff=arch["coeff"];weight=arch["shear"];scalar=arch["scalar"]
    a=ob["a"];H=ob["H"];S=ob["R"]+ob["P"]
    alpha=ob["sigma"]/k
    spatial=ob["eta"]-H*alpha
    lapse=(ob["dsigma"]+H*ob["sigma"])/k
    dst=ob["D"]-3*S*ob["eta"]
    vel=ob["Q"]+S*ob["sigma"]
    source=-(dst+3*H*vel/k)/(2*k**2+3*S)
    slip=ob["Pi"]/k**2
    dd=np.stack([ob["dc"],ob["db"]]+([standard["mts_drho_h"]*a/coeff[-1]] if model=="heavy" else []))-3*ob["eta"]
    vv=-np.stack([ob["sigma"],ob["sigma"]+ob["vb"]]+([ob["sigma"]+standard["mts_q_h"]*a/coeff[-1]] if model=="heavy" else []))/k
    with np.load(LONG/(model+"-environment.npz")) as hist:
        ix=np.searchsorted(hist["loga"],x)
        np.testing.assert_array_equal(hist["loga"][ix],x)
        for current,then in ((dd,hist["density"][:,:,ix]),(vv,hist["velocity"][:,:,ix]),
                             (lapse,hist["phi"][:,ix])):
            assert np.max(np.abs(then-current)/np.maximum(1e-25,np.max(abs(then),axis=-1,keepdims=True)))<3e-6
    md=np.einsum("s,skt->kt",coeff,dd)/a
    current=-np.einsum("s,skt->kt",coeff,vv)*k/a
    pressure=(standard["mts_dp_h"]*a/coeff[-1] if model=="heavy" else np.zeros_like(k*x))
    return dict(k=k,x=x,tau=eta_time,coeff=coeff,weight=weight,scalar=scalar,a=a,H=H,S=S,
                phi=spatial,psi=lapse,weyl=ob["W"],computed=source,slip=slip,ds=dst,qn=vel,md=md,mq=current,
                d=dd,v=vv,pressure=pressure,obs=ob,standard=standard)

def project(z,field,radius):
    k=z["k"][:,0]
    tab=z["weight"][:,None]*field
    b=spherical_jn(2,k*radius);s=k*spherical_jn(2,k*radius,derivative=True)
    curvature=-2*s/radius+(6/radius**2-k*k)*b
    return dict(potential=b@tab,radial=-s@tab,polar=1.5*b@tab/radius,
                axial_tf=-(curvature+k*k*b/3)@tab)

def main():
    budgets=[];checks=[]
    for model in ("heavy","cold"):
        z=decode(model);k=z["k"];H=z["H"];a=z["a"];S=z["S"];src=z["computed"];p=z["obs"]
        matter=-z["md"]/(2*k**2)
        den=2*k**2+3*S
        pieces={"newton_matter":matter,"other_energy":-(z["ds"]-z["md"])/den,
                "volume_feedback":-3*S*matter/den,"matter_momentum":-3*H*z["mq"]/(k*den),
                "other_momentum":-3*H*(z["qn"]-z["mq"])/(k*den),"stress_slip":-z["slip"]}
        direct=z["psi"];physical=z["phi"]
        for name,test,expected in (("curvature",src,physical),("lapse",src-z["slip"],direct),
                        ("weyl",src-z["slip"]/2,p["W"]),("hamiltonian_sync",-(p["D"]+3*H*p["Q"]/k)/(2*k**2),physical),
                        ("energy_split",sum(pieces.values()),direct),("std_weyl",z["standard"]["Weyl"]/k**2,p["W"])):
            err=test-expected
            checks.append(dict(model=model,identity=name,samples=err.size,max_abs=np.max(abs(err)),
                on_mode_peak=np.max(np.max(abs(err),axis=1)/np.max(abs(expected),axis=1))))
        for radius in RADII:
            terms={key:project(z,val,radius) for key,val in {**pieces,"lapse":direct,"curvature":physical,
                    "weyl":p["W"],"lapse_minus_newton":direct-matter,"lapse_minus_weyl":-z["slip"]/2}.items()}
            for idx,x in enumerate(z["x"]):
                for field in terms["lapse"]:
                    budgets.append(dict(model=model,epoch=x/DLOG,radius=radius,quantity=field,
                        **{key:arr[field][idx] for key,arr in terms.items()}))
    table("native-constraint-checks.csv",checks);table("native-tidal-budget.csv",budgets)
if __name__=="__main__":main()
