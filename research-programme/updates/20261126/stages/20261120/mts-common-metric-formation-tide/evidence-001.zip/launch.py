"""Differentiate the trace equation at a matched pressure switch, before reading its output."""
from linear import *
from native_source import SPEC
def predict():
    rows=[]
    with np.load(SPEC/"runs/projection/a225-w6-d8.npz") as data:mass=float(data["heavy_mass_mpc"])
    for model in ("heavy","cold"):
        z=decode(model);k=z["k"];initial=lambda name:z[name][:,:1]
        if model=="heavy":
            H=initial("H");a=initial("a")
            u=k/(a*mass)
            sound=(u/(1+np.sqrt(1+u*u)))**2;Rh=z["coeff"][-1]/a
            v=z["v"][-1,:,:1]
            B=z["d"][-1,:,:1]+3*initial("phi")-3*H*v
            Bdot=(k*k+1.5*initial("S"))*v+1.5*initial("qn")/k
            second=Rh*sound*B/2
            third=Rh*sound*(Bdot-(4+2/np.sqrt(1+u*u))*H*B)/2
        else:second=third=np.zeros_like(k)
        for r in RADII:
            A=project(z,second,r);B3=project(z,third,r)
            for quantity in A:
                rows.append(dict(model=model,radius=r,quantity=quantity,second=A[quantity][0],third=B3[quantity][0]))
    table("launch-coefficients.csv",rows)
def inspect():
    def parse(name):
        with (HERE/name).open() as stream:return list(csv.DictReader(stream))
    lookup={(r["model"],r["radius"],r["quantity"]):r for r in parse("launch-coefficients.csv")}
    rows=[]
    for model in ("heavy","cold"):
        items=parse("pressure-switch-response.csv")
        for boost in ((6,7) if model=="heavy" else (6,)):
            for key,ref in lookup.items():
                if key[0]!=model:continue
                vals={float(r["dt"]):r for r in items if (r["model"],r["radius"],r["quantity"])==key and int(r["boost"])==boost}
                A,B=float(ref["second"]),float(ref["third"])
                for t in (.0625,.125,.25,.5):
                    def values(time):
                        speed=float(vals[time]["phidot"])
                        return speed/time,2*(speed-time*A)/time**2
                    one,two=values(t);next_one,next_two=values(2*t)
                    acc=2*one-next_one;jerk=2*two-next_two
                    phi=float(vals[t]["phi"])
                    rel=lambda difference,base:difference/base if base else None
                    rows.append(dict(model=model,boost=boost,radius=key[1],quantity=key[2],dt=t,
                        curvature_richardson=acc,jerk_richardson=jerk,curvature_relative=rel(acc-A,A),
                        jerk_relative=rel(jerk-B,B),raw_quadratic_fraction=rel(phi-.5*A*t*t,.5*A*t*t),
                        cubic_remainder_fraction=rel(phi-.5*A*t*t-B*t**3/6,.5*A*t*t)))
    table("launch-recovery.csv",rows)
if __name__=="__main__":predict();inspect()
