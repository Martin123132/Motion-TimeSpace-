"""Matched-state full-hierarchy pressure ablation; compare to Newtonian propagation."""
from linear import *
from native_source import SPEC
from balanced import BalancedNative
def case(model,boost):
    z=decode(model)
    fields=[];raw=[]
    for flag in (0,1):
        with np.load(HERE/f"serial-{model}-b{boost}-off{flag}.npz") as pack:
            names=pack["names"].tolist();array=pack["values"];tau=pack["tau"]
            np.testing.assert_array_equal(pack["k"],z["k"][:,0])
            raw.append(array)
            fields.append(dict(zip(names,array.transpose(2,0,1))))
    np.testing.assert_array_equal(raw[0][:,0,:],raw[1][:,0,:])
    if model=="cold":np.testing.assert_array_equal(raw[0],raw[1])
    keep=np.r_[0,7:len(tau)]
    np.testing.assert_array_equal(tau[keep],z["tau"])
    on,off=fields;k=z["k"];H=on["H"];S=on["R"]+on["P"];a=on["a"]
    for key in ("a","H","R","P"):np.testing.assert_array_equal(on[key],off[key])
    diff=lambda name:on[name]-off[name]
    slip=diff("Pi")/k**2
    delta=diff("eta")-H*diff("sigma")/k
    lapse=(diff("dsigma")+H*diff("sigma"))/k
    weyl=diff("W")
    con=-(diff("D")+3*H*diff("Q")/k)/(2*k**2)
    dq=diff("Q")+S*diff("sigma")
    dot=dq/(2*k)-H*lapse
    alt=diff("dW")+diff("dPi")/(2*k**2)
    den=2*k**2+3*S
    cmd=on["Rc"]*(diff("dc")-3*diff("eta"))+on["Rb"]*(diff("db")-3*diff("eta"))
    cmq=(on["Rc"]+on["Rb"])*diff("sigma")+on["Rb"]*diff("vb")
    mass=float(np.load(SPEC/"runs/projection/a225-w6-d8.npz")["heavy_mass_mpc"])
    if model=="heavy":
        Rh=z["coeff"][-1]/a
        cmd+=diff("mts_drho_h")-3*Rh*diff("eta")
        cmq+=diff("mts_q_h")+Rh*diff("sigma")
        ratio=k/(a*mass)
        rest=on["mts_drho_h"]/Rh+3*H*on["mts_q_h"]/(Rh*k)
        dp=Rh*(ratio/(1+np.sqrt(1+ratio**2)))**2*rest
        assert np.max(abs(dp/on["mts_dp_h"]-1))<2e-15
        A=dp[:,:1]/2
        AN=Rh[:,:1]*k**2*(on["mts_drho_h"][:,:1]/Rh[:,:1]-3*on["eta"][:,:1])/(8*(a[:,:1]*mass)**2)
    else:A=AN=np.zeros_like(k)
    matter=-(cmd+3*H*cmq/k)/den
    other=-((diff("D")-3*S*diff("eta")-cmd)+3*H*(dq-cmq)/k)/den
    sim=BalancedNative(model,120,480,False,"native36",SPAN*DLOG)
    from scipy.interpolate import CubicSpline
    times=CubicSpline(z["tau"],z["x"])(tau);times[keep]=z["x"]
    newton=np.stack([sim.ref.potential(sim.ref.solution(time)[0],time)[2] for time in times],axis=1)
    t=tau-tau[0]
    assert np.array_equal(t[1:7],[.0625,.125,.25,.5,1.,2.])
    tests=[]
    def record(name,err,ref):
        absolute=np.max(abs(err));scale=np.max(abs(ref))
        tests.append(dict(model=model,boost=boost,name=name,max_abs=absolute,max_on_global_peak=(absolute/scale if scale else None)))
    record("on_replays_original_phi",(on["eta"]-H*on["sigma"]/k)[:,keep]-z["phi"],z["phi"])
    record("launch_state_identical",raw[0][:,0]-raw[1][:,0],raw[0][:,0])
    record("delta_constraint_on_response",delta-con,delta)
    record("live_spectators_close",delta-matter-other,delta)
    record("delta_lapse_slip",delta-slip-lapse,delta)
    record("delta_weyl",delta-slip/2-weyl,delta)
    record("delta_momentum",alt-dot,dot)
    record("pressure_law_launch",A-on["mts_dp_h"][:,:1]/2,A)
    sample=[]
    for radius in RADII:
        vals={key:project(z,value,radius) for key,value in dict(phi=delta,lapse=lapse,weyl=weyl,matter=matter,
                    nonmatter=other,phidot=dot,newton=newton,onset=A,newton_onset=AN,slip=slip).items()}
        for physical in vals["phi"]:
            for epoch,dt in enumerate(t):
                row={name:pv[physical][0 if name.endswith("onset") else epoch] for name,pv in vals.items()}
                sample.append(dict(model=model,boost=boost,radius=radius,quantity=physical,dt=dt,**row))
    return sample,tests
def main():
    rows=[];checks=[]
    for model,boost in (("heavy",6),("cold",6),("heavy",7)):
        vals,tests=case(model,boost);rows+=vals;checks+=tests
    table("pressure-switch-response.csv",rows);table("pressure-switch-checks.csv",checks)
if __name__=="__main__":main()
