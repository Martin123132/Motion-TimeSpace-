"""Expose the model's original synchronous stress and compare the original native outputs."""
from anchor import *
from native_input import SPEC,NATIVE,camb,prepare,inherited,source,checked,obj
from stage import ROOT as LONG
import ctypes
OBSERVER=POST/"mts-metric-feedback-20261107/observer.dll"
OBS="R P D Q Pi sigma dsigma eta deta W dW dPi Rc Rb Rg Rr Rnu Rsc dpb dc db dg dr dnu qg qr vb a H tau".split()
assert sha(OBSERVER)=="f48d1af0ec462b331f976e4c2e0895532d0ed43291ec7d28e5d7980d9ae57286"
def capture(model):
    seed,epochs,_,_,_=prepare(model,0)
    status=obj(source("runs/"+model+"/status.json"))
    for path in inherited.native_hashes():checked(path,status["input_hashes"][str(path)])
    origin=SPEC/"runs/projection/a225-w6-d8.npz" if model=="heavy" else NATIVE/"runs/backgrounds/cold.npz"
    checked(origin,status["source_hash"])
    params=inherited.params_for(origin,background_boost=8.)
    params.DoLateRadTruncation=False
    bg=camb.get_background(params)
    bg.Params.Accuracy.IntTolBoost=6;bg.Params.Accuracy.lAccuracyBoost=4
    lib=ctypes.CDLL(str(OBSERVER));ptr=ctypes.cast(lib.source_func_,ctypes.c_void_p)
    keys=camb.model.evolve_names
    count=len(keys)+len(OBS)
    with np.load(LONG/(model+"-environment.npz")) as data:
        modes=data["k"];loga=data["loga"];coeff=data["coeff"];shear=data["shear"];scalar=data["scalar"]
    keep=np.flatnonzero((loga>=0)&(loga<=SPAN*DLOG+1e-10))
    scale=AI*np.exp(loga[:keep[-1]+2])
    early=epochs[epochs<min(scale)]
    eta=np.ascontiguousarray(bg.conformal_time(1/np.r_[early,scale]-1,tol=1e-10))
    pieces=[]
    for path in sorted((SPEC/"runs"/model).glob("chunk-*.npz")):
        guard()
        with np.load(source(path.relative_to(SPEC).as_posix())) as old:
            chosen=old["modes"][np.isin(old["modes"],modes)]
            if not len(chosen):continue
            batch=np.unique(np.r_[chosen,old["modes"].max()])
        name=f"{model}-{path.stem}.npz"
        if not (HERE/name).exists():
            output=np.zeros((len(batch),len(eta),count))
            ref=lambda value:ctypes.byref(ctypes.c_int(value))
            rc=camb.results.CAMB_TimeEvolution(ctypes.byref(bg),ref(len(batch)),batch,ref(len(eta)),eta,ref(count),
                   output,ref(len(OBS)),ctypes.byref(ptr))
            assert rc==0 and np.isfinite(output).all()
            packet(name,modes=chosen,val=output[np.searchsorted(batch,chosen)][:,len(early)+keep],x=loga[keep],eta=eta[len(early)+keep])
            print(model,path.stem,flush=True)
        with np.load(HERE/name) as d:
            np.testing.assert_array_equal(d["modes"],chosen)
            pieces.append((chosen,d["val"]))
    np.testing.assert_array_equal(np.concatenate([key for key,val in pieces]),modes)
    packet(model+"-all.npz",k=modes,x=loga[keep],eta=eta[len(early)+keep],values=np.concatenate([v for key,v in pieces]),
           keys=keys+OBS,coeff=coeff,shear=shear,scalar=scalar)
if __name__=="__main__":
    for model in sys.argv[1:]:capture(model)
