"""Validate control identity, actual comparisons and provenance; seal existing evidence."""
from anchor import *
from collections import Counter
def rows(name):
    with (HERE/name).open() as stream:
        data=list(csv.DictReader(stream))
    assert data and all(None not in row and None not in row.values() for row in data)
    return data
def audit():
    for name in manifest:saved(name)
    assert len(manifest)==99
    control={}
    for model,boost in (("heavy",6),("cold",6),("heavy",7)):
        guard()
        with np.load(HERE/f"serial-{model}-b{boost}-off0.npz") as on,np.load(HERE/f"serial-{model}-b{boost}-off1.npz") as off:
            k=on["k"];t=on["tau"];names=on["names"].tolist()
            assert np.array_equal(k,off["k"]) and np.array_equal(t,off["tau"]) and names==off["names"].tolist()
            before=on["values"];after=off["values"]
            assert len(np.unique(k))==99 and len(np.unique(t))==39 and before.shape==after.shape==(99,39,72)
            assert np.isfinite(before).all() and np.isfinite(after).all()
            assert np.array_equal(before[:,0],after[:,0])
            if model=="cold":np.testing.assert_array_equal(before,after)
            else:
                pressure=names.index("mts_dp_h")
                assert np.all(before[:,:,pressure]!=0) and np.all(after[:,1:,pressure]==0)
    for line in rows("native-constraint-checks.csv"):assert float(line["on_mode_peak"])<2e-5
    for line in rows("pressure-switch-checks.csv"):
        assert abs(float(line["max_on_global_peak"] or 0))<2e-5
    rv=rows("pressure-switch-response.csv")
    endpoints=[r for r in rv if r["model"]=="heavy" and r["boost"]=="6" and float(r["dt"])>109 and r["quantity"] in ("radial","polar")]
    assert len(endpoints)==18
    gaps=[float(r["lapse"])/float(r["newton"])-1 for r in endpoints]
    assert sum(abs(g)<=2e-5 for g in gaps)==4 and min(gaps)<-.002
    for r in endpoints:
        other,=[s for s in rv if s["boost"]=="7" and all(s[k]==r[k] for k in ("radius","dt","quantity"))]
        assert abs(float(other["lapse"])/float(r["lapse"])-1)<3e-8
    test=[r for r in rows("launch-recovery.csv") if r["model"]=="heavy" and r["dt"]=="0.0625"]
    assert len(test)==72 and all(abs(float(r["curvature_relative"]))<2e-5 for r in test)
    assert sum(abs(float(r["jerk_relative"]))<2e-5 for r in test)==37
    for r in test:
        if r["quantity"]=="radial" and r["radius"]=="1.35307765":assert abs(float(r["jerk_relative"]))<7e-6
    currents=rows("cloud-mass-current.csv")
    for r in currents:
        val=float(r["mass_flux_projection"]);delta=float(r["projection_difference"])
        if r["model"]=="cold" and r["channel"]=="delta":assert val==delta==0
        else:assert abs(delta/val)<8e-10
    tensor=rows("cloud-stress.csv")
    assert max(float(r["cartesian_norm_error"]) for r in tensor)<2e-9
    sols=rows("cloud-difference.csv")
    for seed in ("1","-1"):
        pts=sorted((r for r in sols if (r["model"],r["seed"],r["component"],r["radius"])==("heavy",seed,"axial_rr_tf","1.35307765")),key=lambda r:r["rate"])
        assert len(pts)==2 and abs(float(pts[0]["total_change"])/float(pts[1]["total_change"])-1)<2e-5
        assert -1.6e-4<float(pts[1]["total_change"])/float(pts[1]["newton_host_change"])<-1.5e-4
    counts={p.name:len(rows(p.name)) for p in HERE.glob("*.csv")}
    assert counts=={"launch-coefficients.csv":72,"launch-recovery.csv":432,"pressure-switch-response.csv":4212,
      "pressure-switch-checks.csv":24,"native-tidal-budget.csv":2376,"native-constraint-checks.csv":12,
      "cloud-stress.csv":224,"cloud-difference.csv":112,"cloud-mass-current.csv":144}
    rejected={"native-switch-inputs.json","native-switch.dll","switch-heavy-b6-off0.npz"}
    files={p.name:sha(p) for p in HERE.iterdir() if p.is_file() and p.name!="seal.json"}
    assert not any(p.is_dir() or p.suffix==".partial" for p in HERE.iterdir())
    assert rejected<=files.keys()
    return dict(files={k:v for k,v in files.items() if k not in rejected},rejected={k:files[k] for k in rejected},csv_rows=counts,
                parent_seal=PIN,parent_files=len(manifest))
if __name__=="__main__":
    data=audit();receipt=(json.dumps(data,sort_keys=True,indent=2)+"\n").encode();name="seal.json"
    if sys.argv[1:]==["--seal"]:put(name,receipt)
    assert (HERE/name).read_bytes()==receipt
    print(len(data["files"]),"accepted files;",len(data["rejected"]),"quarantined;",len(manifest),"parent files;",sha(HERE/name))
