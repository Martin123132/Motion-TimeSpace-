from pathlib import Path
import csv,hashlib,io,json,os,sys
HERE=Path(__file__).resolve().parent
POST=HERE.parent
OLD=POST/"mts-transmitted-formation-tide-20261120"
PIN="17ac8f0f3501b0de8c32b8cb9cf5c47c4bb2435c5f3409eda0e0478467252878"
def sha(path):
    with path.open("rb") as f:return hashlib.file_digest(f,"sha256").hexdigest()
assert sha(OLD/"seal.json")==PIN
manifest=json.loads((OLD/"seal.json").read_bytes())["files"]
def saved(name):
    p=OLD/name;assert sha(p)==manifest[name],name
    return p
saved("campaign.py")
sys.path.insert(0,str(OLD))
from campaign import AI,DLOG,SPAN,np,guard as prior_guard
def guard():
    prior_guard();assert not (HERE/"STOP-REQUESTED").exists()
guard()
def put(name,raw):
    guard()
    path=HERE/name
    if path.exists():assert path.read_bytes()==raw,name
    else:
        partial=path.with_suffix(path.suffix+".partial")
        with partial.open("xb") as stream:stream.write(raw)
        partial.rename(path)
def packet(name,**data):
    mem=io.BytesIO();np.savez_compressed(mem,**data);put(name,mem.getvalue())
def table(name,data):
    stream=io.StringIO(newline="")
    writer=csv.DictWriter(stream,fieldnames=list(data[0]),lineterminator="\n");writer.writeheader();writer.writerows(data)
    put(name,stream.getvalue().encode("ascii"))
