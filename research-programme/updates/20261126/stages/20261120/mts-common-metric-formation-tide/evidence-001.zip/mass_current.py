"""Longitudinal projection of the physical (density-weighted) excess mass flux."""
from cloud_stress import *
from numpy.polynomial.legendre import leggauss
def sources(sim,state,rules,stop):
    from scipy.special import spherical_jn
    m=sim.mesh;p=sim.patch
    inds,t,w=rules
    r=m.h*(inds[:,None]+t)
    ip=BarycentricInterpolator(m.loc[0]/m.h,np.eye(m.order+1),rng=0)
    vals=ip(t);der=ip.derivative(t)/m.h
    def evaluate(field,mat):
        local=m.grid(field)[...,m.elem[inds]]
        return np.einsum("...ei,eqi->...eq",local,mat)
    mono,d,wave=state
    reduced=evaluate(mono,vals)/r
    slope=(evaluate(mono,der)-reduced)/r
    contrast=reduced[0];speed=slope[1]
    density,vel=sim.ref.solution(stop)*sim.ref.weight
    kr=np.outer(p.k,r.ravel())
    kernel=spherical_jn(2,kr)
    def profile(f,mat):return (f@mat).reshape(*f.shape[:-1],*r.shape)
    zero=profile(density,kernel)
    phase=profile(vel,kernel)
    phir=profile(vel,spherical_jn(2,kr,derivative=True)*p.k[:,None])
    local=evaluate(wave,vals)
    grad=evaluate(wave,der)
    rh=p.p.coeff/(AI*np.exp(stop))
    def summed(values):return np.einsum("s,cseq->ceq",rh,values)
    jrad=summed((1+contrast)*grad+contrast*phir+speed*(zero+evaluate(d,vals)))
    jtan=summed(((1+contrast)*local+contrast*phase)/r)
    return r,jrad,jtan
def rule(m,edge,order,probe=None):
    gauss,weights=leggauss(order)
    bounds=np.arange(int(edge/m.h)+1)*m.h
    if probe is not None:bounds=np.unique(np.r_[bounds,probe])
    lo,hi=bounds[:-1,None],bounds[1:,None]
    mid=(lo+hi)/2;half=(hi-lo)/2
    index=np.floor(mid[:,0]/m.h).astype(int)
    return index,(mid+half*gauss)/m.h-index[:,None],half*weights
def weak(sim,state,edge,stop,order=10):
    m=sim.mesh;indices,t,w=rule(m,edge,order)
    r,jrad,jtan=sources(sim,state,(indices,t,w),stop)
    ip=BarycentricInterpolator(m.loc[0]/m.h,np.eye(m.order+1),rng=0)
    local=(jrad*r**2*w)@(ip.derivative(t[0])/m.h)+(6*r*jtan*w)@ip(t[0])
    values=np.zeros((3,m.segments,m.order+1));values[:,indices]=local
    return m.solve2(m.gather(values)[:,1:].T).T
def kernel(r,pr,jr,jt):
    return np.where(r<pr,(r/pr)**3*(2*jr+6*jt), (pr/r)**2*(-3*jr+6*jt))/5
def pair(model,rate):
    stop=SPAN*DLOG
    sim=BalancedNative(model,120,120*rate,False,"native36",stop);m=sim.mesh
    results=[]
    for sign in (1,-1):
        path=saved(f"evolved-{model}-L120-h{rate}-t176.npz" if sign==1 else f"collar-{model}-L120-h{rate}--1.npz")
        with np.load(path) as data:state=tuple(data[key] for key in ("mono","density","velocity"))
        for edge in (96,120):
            field=weak(sim,state,edge,stop)
            for pr in sim.obs[:3]:
                coords=rule(m,edge,10,pr);r,jr,jt=sources(sim,state,coords,stop)
                v=np.sum(kernel(r,pr,jr,jt)*coords[2],axis=(-1,-2))
                fe=sample(m,m.grid(field),pr)[0]
                naive=sample(m,m.grid(state[2]),pr)[0]@(sim.patch.p.coeff/(AI*np.exp(stop)))
                assert abs(v[0]-v[1]-v[2])/max(abs(v[0]),1e-38)<1e-11
                if model=="cold":assert v[2]==fe[2]==0
                for channel,label in enumerate(("on","off","delta")):
                    results.append(dict(model=model,rate=rate,seed=sign,edge=edge,radius=pr,channel=label,
                            mass_flux_projection=v[channel],galerkin=fe[channel],bare_phase=naive[channel],
                            momentum_metric_rate=-v[channel]/2,projection_difference=fe[channel]-v[channel]))
    return results
def control():
    m=BalancedNative("cold",120,480,False,"native36",SPAN*DLOG).mesh
    for pr in (1.35307765,12.,48.):
        _,t,w=rule(m,120,12,pr);idx=rule(m,120,12,pr)[0]
        r=(idx[:,None]+t)*m.h
        smooth=lambda s:s**2*(1-(s/120)**2)**3
        prime=2*r*(1-(r/120)**2)**3-6*r**3/120**2*(1-(r/120)**2)**2
        assert abs((kernel(r,pr,prime,smooth(r)/r)*w).sum()/smooth(pr)-1)<1e-11
        assert abs((kernel(r,pr,6*smooth(r)/r**2,prime/r)*w).sum())<1e-11
def main():
    control();rows=[]
    for model in ("heavy","cold"):
        for rate in (4,5):rows.extend(pair(model,rate))
    table("cloud-mass-current.csv",rows)
if __name__=="__main__":main()
