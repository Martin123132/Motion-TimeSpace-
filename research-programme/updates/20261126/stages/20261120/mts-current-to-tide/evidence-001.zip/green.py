"""Independent continuum radial Green propagator for the longitudinal l=2 current."""
from transfer import *
from scipy.special import roots_legendre


class Green:
    def __init__(self,grid,order):
        self.grid=grid
        self.powers=np.array([-4.,-2.,1.,3.])
        system=np.array([[1.,-3.,.75,0.],[-1.,1.,0.,1.],[0.,0.,-2.,6.],[0.,4.,.5,-2.]])
        vals,vec=np.linalg.eig(system)
        ids=np.argsort(vals)
        np.testing.assert_allclose(vals[ids],self.powers,rtol=0,atol=1e-13)
        self.vec=vec[:,ids].real
        self.inverse=np.linalg.inv(self.vec)
        self.nodes,self.weights=roots_legendre(order)
        self.basis=BarycentricInterpolator(grid.t,np.eye(len(grid.t)),rng=0)
        self.cache={}

    def weights_for(self,power,lo,hi):
        relative=(hi-lo)*self.nodes/2+(hi+lo)/2
        mat=self.basis(relative)
        grid=self.grid
        locations=grid.h*(np.arange(grid.ne)[:,None]+relative)
        return ((hi-lo)*grid.h/2)*(locations**power*self.weights)@mat

    def moment(self,data,power,outward):
        grid=self.grid
        key=(power,outward)
        if key not in self.cache:
            whole=self.weights_for(power,0.,1.)
            partial=np.stack([self.weights_for(power,0.,node) if outward else self.weights_for(power,node,1.) for node in grid.t],axis=1)
            self.cache[key]=(whole,partial)
        whole,partial=self.cache[key]
        mass=np.einsum("er,er->e",whole,data)
        local=np.einsum("enr,er->en",partial,data)
        if outward:
            return np.r_[0.,np.cumsum(mass[:-1])][:,None]+local,np.sum(mass)
        return -(np.r_[np.cumsum(mass[:0:-1])[::-1],0.][:,None]+local),0.

    def solve(self,current,wall=(0.,0.)):
        grid=self.grid
        radius=grid.points
        base,radial,polar=current
        monopole=self.moment(base,3,True)[0]/radius**3
        modes=[];caps=[]
        for idx,power in enumerate(self.powers):
            projection=self.inverse[idx,2]*radial+self.inverse[idx,3]*polar
            primitive,cap=self.moment(projection,1-power,power<0)
            modes.append(radius**power*primitive)
            caps.append(grid.edge**power*cap)
        correction=np.linalg.solve(self.vec[:2,2:],np.asarray(wall)-self.vec[:2]@caps)
        for idx in (2,3):
            modes[idx]+=correction[idx-2]*(radius/grid.edge)**self.powers[idx]
        output=np.einsum("ij,jer->ier",self.vec,modes)
        return monopole,output[2]/radius,output[3]/radius,2*output[1]/radius


def leading(obj,supply):
    number,gradient,momentum=material(obj)
    index=obj.j
    mu=obj.bg["a"]*obj.sim.patch.p.mass
    ref,_,_=pressure(0)
    nu0=-(3*ref["H"]+supply["lp"]+(gradient[index]/number[index])*momentum[index])/(2*mu)
    prefactor=-obj.rh[index]*number[index]*nu0/(2*mu)
    radial=prefactor*gradient[index]/number[index]
    polar=prefactor.real*angular(number[index])/(number[index].real*obj.grid.points)
    return np.array([radial.real,angular(radial),polar])


def main(seed):
    guard()
    sim=BalancedNative("heavy",120,600,False,"native36",SPAN*DLOG)
    obj,graph,supply,fields,shell=build(sim,seed)
    grid=obj.grid
    exact=current(obj,graph,fields)
    newton=leading(obj,supply)
    times,plain,_=kernels(40,DURATION,2*shell.mu)
    rows=[];checks=[]
    for quadrature in (24,48):
        solver=Green(grid,quadrature)
        r=grid.points;gauss=np.exp(-r**2/9)
        scaled=r**2/9
        curr=np.array([(5*r-2*r**3/9)*gauss,4/3*gauss*(-28*r/9+44*r**3/81-8*r**5/729),
                       4/3*gauss*(4*scaled**2-14*scaled)/r])
        truth=(r**2*gauss,*strain(r,(2*r*(1-scaled)*gauss,r*gauss,(2-10*scaled+4*scaled**2)*gauss,(1-2*scaled)*gauss)))
        region=(r>.5)&(r<7)
        gravity=solver.solve(curr)
        wall=solver.solve(curr*0.,(2*grid.edge,grid.edge))
        for i in range(4):
            error=np.max(abs(gravity[i][region]-truth[i][region]))/np.max(abs(truth[i][region]))
            assert error<2e-8,error
            assert np.max(abs(wall[i]-[0,4,2,2][i]))<2e-9
        for method,source in (("green",exact),("green-leading",newton),("fe-leading",newton)):
            if quadrature==24 and method!="green":
                continue
            shear=solver.solve(source) if method.startswith("green") else longitudinal(grid,source)
            other=longitudinal(grid,source)
            err=[np.max(abs((a-b)[region]))/max(1e-280,np.max(abs(b[region]))) for a,b in zip(shear,other)]
            change,dgrad,drhs,_=geometry(obj,source,shear)
            normal=normal_change(obj,supply,graph,shear,change,dgrad,drhs)
            tangent=field_tangent(obj,graph,shell,shear,change,*normal)
            values=response(shell,tangent,256,times,plain[-1])
            checks.append(dict(seed=seed,order=quadrature,method=method,**dict(zip(("mono","rr","cross","angular"),err))))
            for width,parts in zip(FRACTIONS,values):
                rows.append(dict(seed=seed,order=quadrature,method=method,width=width,rest=sum(parts[:3]),geometry=sum(parts[3:])))
            print("green check",seed,quadrature,method,err,flush=True)
    save(f"green-seed{seed}.csv",rows)
    save(f"green-fields-seed{seed}.csv",checks)


if __name__=="__main__":
    main(int(sys.argv[1]))
