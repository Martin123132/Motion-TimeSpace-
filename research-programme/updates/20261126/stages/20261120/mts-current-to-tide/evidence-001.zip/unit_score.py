from assess import read
from transfer import HERE,save


def main():
    values={}
    for seed in (0,1,-1):
        for row in read(HERE/f"compensated-seed{seed}.csv"):
            values[seed,int(row["lower"]),float(row["width"])]=float(row["rest"])+float(row["geometry"])
    scores=[]
    for row in read(HERE/"forecast-test.csv"):
        if float(row["gain"])!=256:
            continue
        seed=int(row["seed"]);width=float(row["width"]);target=float(row["predicted_ppm"])
        for lower in (0,-1):
            actual=(values[seed,lower,width]-values[0,lower,width])*1e6/float(row["newton"])
            scores.append(dict(seed=seed,width=width,upper=1,lower=lower,unit_switch_ppm=actual,predicted_ppm=target,
                               error_ppm=actual-target,relative_error=actual/target-1,passes=abs(actual/target-1)<2e-5))
            print(seed,width,lower,actual,actual-target)
    save("compensated-switch-test.csv",scores)


if __name__=="__main__":
    main()
