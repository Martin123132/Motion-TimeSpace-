from assess import read
from transfer import HERE,save


def main():
    all_rows={}
    for seed in (0,1,-1):
        for row in read(HERE/f"green-seed{seed}.csv"):
            key=seed,int(row["order"]),row["method"],float(row["width"])
            assert key not in all_rows
            all_rows[key]=float(row["rest"])+float(row["geometry"])
    result=[]
    for row in read(HERE/"forecast-test.csv"):
        if float(row["gain"])!=256:
            continue
        seed=int(row["seed"]);width=float(row["width"]);base=float(row["predicted_ppm"])
        for order,method in ((24,"green"),(48,"green"),(48,"green-leading"),(48,"fe-leading")):
            prediction=(all_rows[seed,order,method,width]-all_rows[0,order,method,width])*1e6/float(row["newton"])
            result.append(dict(seed=seed,width=width,order=order,method=method,predicted_ppm=prediction,
                    full_fe_tangent_ppm=base,error_ppm=prediction-base,relative_error=prediction/base-1,
                    matches_full_channel=abs(prediction/base-1)<2e-5))
            print(seed,width,order,method,prediction,prediction-base)
    save("source-to-tide-cross-check.csv",result)


if __name__=="__main__":
    main()
