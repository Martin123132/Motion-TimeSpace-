from assess import read
from transfer import HERE,np,save
from predict import pinned


def run():
    controls={};fields={}
    for seed in (0,1,-1):
        for row in read(HERE/f"switch-control-seed{seed}.csv"):
            controls[seed,float(row["width"]),int(row["upper"]),int(row["lower"])]=float(row["rest"])+float(row["geometry"])
        for row in read(HERE/f"secant-error-seed{seed}.csv"):
            fields[seed,float(row["width"]),int(row["upper"]),int(row["lower"]),row["field"]]=float(row["rest"])+float(row["geometry"])
    base=read(HERE/"forecast-test.csv")
    result=[]
    for row in base:
        if row["gain"]!="256.0" and row["gain"]!="256":
            continue
        seed=int(row["seed"]);width=float(row["width"]);scale=1e6/float(row["newton"]);expected=float(row["predicted_ppm"])
        for hi,lo in ((1,0),(1,-1),(64,-64),(1024,-1024)):
            net=(controls[seed,width,hi,lo]-controls[0,width,hi,lo])*scale
            contributions={key:(fields[seed,width,hi,lo,key]-fields[0,width,hi,lo,key])*scale for key in ("all","shear","metric","matter")}
            result.append(dict(seed=seed,width=width,upper=hi,lower=lo,nonlinear_ppm=net,tangent_ppm=expected,
                delta_ppm=net-expected,predicted_delta_ppm=contributions["all"],
                unattributed_ppm=net-expected-contributions["all"],
                shear_error_ppm=contributions["shear"],metric_error_ppm=contributions["metric"],matter_error_ppm=contributions["matter"],
                old_forward_ppm=row["switched_ppm"],pass_on_channel=abs(net/expected-1)<2e-5))
    assert len(result)==16
    save("switch-diagnosis.csv",result)
    for row in result:
        print(row["seed"],row["width"],row["upper"],row["lower"],*(round(row[key],7) for key in ("delta_ppm","shear_error_ppm","metric_error_ppm","matter_error_ppm","unattributed_ppm")))


if __name__=="__main__":
    run()
