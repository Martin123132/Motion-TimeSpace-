"""Validate the independent source transfers, keep failed comparisons, and pin all local evidence."""
import ast
import math
import re
from assess import read
from transfer import HERE,PRIOR,PIN,digest,json,registry


def main():
    assert all(digest(PRIOR/name)==value for name,value in registry.items())
    for name,value in json.loads((HERE/"predictions.json").read_bytes()).items():
        assert digest(HERE/name)==value,name
    counts={"controls.csv":23,"forecast-test.csv":12,"where-the-current-acts.csv":40,"switch-diagnosis.csv":16,
            "source-to-tide-cross-check.csv":16,"compensated-switch-test.csv":8,"weak-source-test.csv":4}
    for seed in (0,1,-1):
        for prefix,count in (("raw",22),("fields",9),("switch-control",8),("secant-error",32),("green",8),
                             ("green-fields",4),("weak",12),("weak-fields",6),("compensated",4)):
            counts[f"{prefix}-seed{seed}.csv"]=count
    assert {path.name for path in HERE.glob("*.csv")}==set(counts)
    for name,count in counts.items():
        rows=read(HERE/name)
        assert len(rows)==count and all(None not in row and all(v and v.lower() not in ("inf","nan","-inf") for v in row.values()) for row in rows),name
    assert all(row["passed"]=="True" for row in read(HERE/"controls.csv"))
    assert all(row["pass_tide"]=="True" and row["pass_component"]=="False" for row in read(HERE/"forecast-test.csv"))
    for row in read(HERE/"where-the-current-acts.csv"):
        if row["source"]=="sum_minus_all":
            assert abs(float(row["net_ppm"]))<3e-6
    for row in read(HERE/"switch-diagnosis.csv"):
        if row["lower"]=="0":
            assert abs(float(row["delta_ppm"])-float(row["shear_error_ppm"]))<1.8e-4
            assert row["pass_on_channel"]=="False"
        if row["upper"]=="1024":
            assert row["pass_on_channel"]=="True"
    for row in read(HERE/"source-to-tide-cross-check.csv"):
        if row["method"]=="green":
            assert abs(float(row["error_ppm"]))<1e-6 and row["matches_full_channel"]=="True"
        else:
            assert row["matches_full_channel"]=="False"
    unit=read(HERE/"compensated-switch-test.csv")
    assert sum(row["passes"]=="True" for row in unit if row["lower"]=="0")==2
    assert all(row["passes"]=="True" for row in unit if row["lower"]=="-1")
    assert all(abs(float(row["error_ppm"]))<3.4e-6 and row["passes"]=="True" for row in read(HERE/"weak-source-test.csv"))
    for path in HERE.glob("*.md"):
        for link in re.findall(r"\]\(([^)]+)\)",path.read_text(encoding="utf8")):
            assert (HERE/link).is_file(),link
    assert not list(HERE.glob("*.partial")) and not (HERE/"__pycache__").exists()
    for source in HERE.glob("*.py"):
        ast.parse(source.read_text(encoding="utf8"))
    files={path.name:digest(path) for path in sorted(HERE.iterdir()) if path.is_file() and path.name!="seal.json"}
    result={"files":files,"source_stage":PIN,"source_file_count":len(registry),"csv_counts":counts}
    target=HERE/"seal.json"
    if target.exists():
        assert json.loads(target.read_bytes())==result
    else:
        with target.open("x",encoding="utf8",newline="\n") as stream:
            stream.write(json.dumps(result,indent=2)+"\n")
    print("Verified",len(files),"files,",sum(counts.values()),"data/check rows,",len(registry),"upstream files;",digest(target))


if __name__=="__main__":
    main()
