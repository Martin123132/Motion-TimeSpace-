from assess import read
from transfer import HERE,save


def main():
    data={}
    for seed in (0,1,-1):
        for row in read(HERE/f"weak-seed{seed}.csv"):
            data[seed,row["source"],float(row["width"])]=float(row["rest"])+float(row["geometry"])
    sources=("leading","normalization","metric_gradient","normal_gradient","drift","corrected")
    scored=[]
    for row in read(HERE/"forecast-test.csv"):
        if float(row["gain"])!=256:
            continue
        seed=int(row["seed"]);width=float(row["width"])
        fit=float(row["predicted_ppm"])
        vals={key:(data[seed,key,width]-data[0,key,width])*1e6/float(row["newton"]) for key in sources}
        summed=sum(vals[key] for key in sources[:-1])
        scored.append(dict(seed=seed,width=width,exact_tangent_ppm=fit,**vals,
            additive_error_ppm=summed-vals["corrected"],error_ppm=vals["corrected"]-fit,
            relative_error=vals["corrected"]/fit-1,passes=abs(vals["corrected"]/fit-1)<2e-5))
        print(seed,width,*(round(vals[key],8) for key in sources),"residual",round(vals["corrected"]-fit,8),"superposition",round(summed-vals["corrected"],8))
    save("weak-source-test.csv",scored)


if __name__=="__main__":
    main()
