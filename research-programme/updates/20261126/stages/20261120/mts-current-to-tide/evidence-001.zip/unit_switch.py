"""Independent nonlinear unit switch with compensated longitudinal shear, including the Hamiltonian re-solve."""
from switch_control import FunctionType,make_packet,Sources
from green import *


def compute(seed):
    guard()
    sim=BalancedNative("heavy",120,600,False,"native36",SPAN*DLOG)
    ref,press,unused=pressure(0)
    inputs=input_pack(sim,5,seed,0,ref,press)
    state,grid,samples,supply=inputs
    solver=Green(grid,48)
    args=(sim,*inputs,ref,press,0,"momentum")
    anchors={}
    def compensated(*values):
        base=Slice(*values)
        if len(values)<11:
            return base
        clock=values[-1]
        hub=base.bg["H"]
        if hub not in anchors:
            anchors[hub]=Slice(*values[:-1])
        ordinary=anchors[hub]
        current=np.array([clock.fields[name] for name in ("clock_j0","jr","jt")])
        extra=solver.solve(current)
        for name,part in zip(("b0","b2","c2","d2"),extra):
            setattr(base,name,getattr(ordinary,name)+part)
        boundary=samples[1]["chir"]+3*samples[1]["chi"]/grid.edge
        base.f0,base.res0=base.iterate(0,0.)
        base.f2,base.res2=base.iterate(2,boundary)
        return base
    readings={}
    for gain in (0,1,-1):
        def source(*inputs,**kwargs):
            return Sources(*inputs,**kwargs,gain=gain)
        runner=FunctionType(make_packet.__code__,dict(make_packet.__globals__,Slice=compensated,Sources=source))
        packet,count,error=runner(*args)
        assert error<2e-9 and anchors
        shell=Stagger(packet,120,6,0,1,"stagger")
        shell.incident.bank=LaunchStress(shell.incident.bank)
        times,plain,_=kernels(40,DURATION,2*shell.mu)
        readings[gain]=rates(shell,shell.initial,times)
    rows=[]
    for lo in (0,-1):
        amounts=np.einsum("t,twc->wc",plain[-1],(readings[1]-readings[lo])/(1-lo))
        for width,parts in zip(FRACTIONS,amounts):
            rows.append(dict(seed=seed,width=width,lower=lo,upper=1,rest=sum(parts[:3]),geometry=sum(parts[3:])))
    save(f"compensated-seed{seed}.csv",rows)
    with np.load(checked(CLOUD,f"launch-h5-off1-seed{seed}.npz")) as packet:
        cold=Stagger(packet,120,6,1,1,"stagger")
    cold.incident.bank=LaunchStress(cold.incident.bank)
    value=response(cold,np.zeros_like(cold.initial),256.,times,plain[-1])
    assert np.all(value==0.)
    print("finite source unit switch and dust null",seed,count,error,flush=True)


if __name__=="__main__":
    compute(int(sys.argv[1]))
