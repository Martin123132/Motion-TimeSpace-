"""After forecast: reproduce and stress-test the previous nonlinear switch with symmetric control gains."""
from types import FunctionType
from transfer import *
from constraint_input import make_packet
from normal_graph import Sources


def packet_at(gain,args):
    def source(*inputs,**kwargs):
        return Sources(*inputs,**kwargs,gain=gain)
    runner=FunctionType(make_packet.__code__,dict(make_packet.__globals__,Sources=source))
    return runner(*args)[0]


def run(seed):
    sim=BalancedNative("heavy",120,600,False,"native36",SPAN*DLOG)
    obj,graph,supply,fields,base=build(sim,seed)
    ref,press,unused=pressure(0)
    inputs=input_pack(sim,5,seed,0,ref,press)
    args=(sim,*inputs,ref,press,0,"momentum")
    times,plain,_=kernels(40,DURATION,2*base.mu)
    metric=current(obj,graph,fields)
    shear=longitudinal(obj.grid,metric)
    change,dgrad,drhs,_=geometry(obj,metric,shear)
    normal=normal_change(obj,supply,graph,shear,change,dgrad,drhs)
    tangent=field_tangent(obj,graph,base,shear,change,*normal)
    rates_by_gain={};states={}
    for gain in (0,1,-1,64,-64,1024,-1024):
        guard()
        pkt=packet_at(gain,args)
        shell=Stagger(pkt,120,6,0,1,"stagger")
        shell.incident.bank=LaunchStress(shell.incident.bank)
        rates_by_gain[gain]=rates(shell,shell.initial,times)
        states[gain]=shell.initial
    rows=[];tangents=[]
    for upper,lower in ((1,0),(1,-1),(64,-64),(1024,-1024)):
        raw=np.einsum("t,twc->wc",plain[-1],(rates_by_gain[upper]-rates_by_gain[lower])/(upper-lower))
        for width,parts in zip(FRACTIONS,raw):
            rows.append(dict(seed=seed,width=width,upper=upper,lower=lower,rest=sum(parts[:3]),geometry=sum(parts[3:])))
        delta=(states[upper]-states[lower])/(upper-lower)
        for name,slots in (("all",tuple(range(20))),("shear",(5,6,7)),("metric",(0,1,2,3)),("matter",(14,15,17,18,19))):
            region=(base.r>.6)&(base.r<2.1)
            error=np.zeros_like(delta)
            error[list(slots)]=delta[list(slots)]-tangent[list(slots)]
            change=response(base,error,1024.,times,plain[-1])
            for width,parts in zip(FRACTIONS,change):
                tangents.append(dict(seed=seed,width=width,upper=upper,lower=lower,field=name,
                    max_tangent=np.max(abs(tangent[list(slots)][...,region])),
                    max_secant_error=np.max(abs(error[...,region])),rest=sum(parts[:3]),geometry=sum(parts[3:])))
    save(f"switch-control-seed{seed}.csv",rows)
    save(f"secant-error-seed{seed}.csv",tangents)
    print("finished separate-preparation controls",seed,flush=True)


if __name__=="__main__":
    run(int(sys.argv[1]))
