"""Compare predictions with source switches only after saving and fingerprinting all raw forecasts."""
from transfer import HERE,PRIOR,digest,registry,json,csv,np,save


def read(path):
    with path.open(newline="") as stream:
        return list(csv.DictReader(stream))


def assess():
    names=["PREDICTION.md","transfer.py",*(f"raw-seed{seed}.csv" for seed in (0,1,-1))]
    receipt={name:digest(HERE/name) for name in names}
    hashfile=HERE/"predictions.json"
    if hashfile.exists():
        assert json.loads(hashfile.read_bytes())==receipt
    else:
        with hashfile.open("x") as stream:
            json.dump(receipt,stream,indent=2)
    assert digest(PRIOR/"constraint-channels.csv")==registry["constraint-channels.csv"]
    benchmark=read(PRIOR/"constraint-channels.csv")
    from predict import pinned
    ref=read(pinned("newton-windows-h5-n8.csv"))
    indices={}
    for seed in (0,1,-1):
        records=read(HERE/f"raw-seed{seed}.csv")
        for row in records:
            key=(seed,row["channel"],float(row["gain"]),float(row["width"]))
            assert key not in indices
            indices[key]=row
    assert len(indices)==66
    components=("compression","flux","mass_ruler","intrinsic","extrinsic","geometry_ruler")
    output=[];mechanisms=[]
    for seed in (1,-1):
        for width in (.15,.30):
            label=next(row for row in benchmark if int(row["seed"])==seed and row["constraint_channels"]=="momentum" and float(row["width"])==width)
            target=float(label["change_from_neither_ppm"])
            newton=float(next(row["increment"] for row in ref if (int(row["seed"]),float(row["width"]),row["quadrature"])==(seed,width,"16")))
            scale=1e6/newton
            def response(channel,gain):
                return np.asarray([scale*(float(indices[seed,channel,gain,width][name])-float(indices[0,channel,gain,width][name])) for name in components])
            for gain in (64,256,1024):
                parts=response("all",gain)
                predicted=sum(parts)
                output.append(dict(seed=seed,width=width,gain=gain,newton=newton,predicted_ppm=predicted,switched_ppm=target,
                    error_ppm=predicted-target,relative_error=(predicted-target)/target,pass_tide=abs(predicted-target)<20,
                    pass_component=abs(predicted/target-1)<2e-5,**dict(zip(components,parts))))
            for kind,channels in (("spatial",("deep","detector","outer","distant","remote")),
                                  ("harmonic",("monopole","quad_radial","quad_angular"))):
                subtotal=np.zeros(6)
                for channel in channels:
                    parts=response(channel,256)
                    subtotal+=parts
                    mechanisms.append(dict(seed=seed,width=width,partition=kind,source=channel,net_ppm=sum(parts),**dict(zip(components,parts))))
                diff=subtotal-response("all",256)
                mechanisms.append(dict(seed=seed,width=width,partition=kind,source="sum_minus_all",net_ppm=sum(diff),**dict(zip(components,diff))))
    save("forecast-test.csv",output)
    save("where-the-current-acts.csv",mechanisms)
    for row in output:
        if row["gain"]==256:
            print("forecast",row["seed"],row["width"],row["predicted_ppm"],row["switched_ppm"],row["error_ppm"])
    for channel in ("deep","detector","outer","distant","remote","monopole","quad_radial","quad_angular","sum_minus_all"):
        print(channel,[round(float(row["net_ppm"]),7) for row in mechanisms if row["source"]==channel])


if __name__=="__main__":
    assess()
