"""First subleading gravitational and quantum contributions to the current from weak inputs alone."""
from green import *
from constraint import shape


def sources(obj,supply):
    grid=obj.grid
    number,gradient,momentum=material(obj)
    index=obj.j
    radius=grid.points
    mu=obj.bg["a"]*obj.sim.patch.p.mass
    ref,_,_=pressure(0)
    masspert=sum(weight*(item-1) for weight,item in zip(obj.rh,number))+jet(0,obj.fq["other"])
    boundary=shape(ref,np.asarray(grid.edge))
    wall=boundary["chir"]+3*boundary["chi"]/grid.edge
    mono=grid.solve(0,masspert.real/4,"matched",0.)
    quad=grid.solve(2,angular(masspert)/4,"matched",wall)
    values,slopes=zip(*(grid.evaluate(ell) for ell in (mono,quad)))
    conformal,grad_chi=jet(*values),jet(*slopes)
    number,vel,loggrad=number[index],momentum[index],gradient[index]/number[index]
    phase_lap=supply["lp"]+loggrad*vel
    drift=-(3*ref["H"]+phase_lap)/(2*mu)
    correction=(4*conformal*phase_lap+4*grad_chi*vel)/(2*mu)
    quantum=supply["ln"]/(2*number)-loggrad**2/4
    normal=(vel**2-quantum/mu**2)/2
    deriv=BarycentricInterpolator(grid.t,np.eye(len(grid.t)),rng=0).derivative(grid.t).T
    grad_nu=(normal@deriv)/grid.h
    amplitude=-obj.rh[index]*number/(2*mu)
    log_t=angular(number)/(radius*number.real)
    def combine(rfield,tfield):
        val=amplitude*rfield
        return np.asarray([val.real,angular(val),amplitude.real*tfield])
    result={"leading":combine(drift*loggrad,drift.real*log_t),
        "normalization":combine(-normal*drift*loggrad,-normal.real*drift.real*log_t),
        "metric_gradient":combine(-6*drift*grad_chi,-6*drift.real*angular(conformal)/radius),
        "normal_gradient":combine(-drift*grad_nu,-drift.real*angular(normal)/radius),
        "drift":combine(correction*loggrad,correction.real*log_t)}
    result["corrected"]=sum(result.values())
    return result


def run(seed):
    sim=BalancedNative("heavy",120,600,False,"native36",SPAN*DLOG)
    obj,graph,supply,fields,shell=build(sim,seed)
    src=sources(obj,supply)
    exact=current(obj,graph,fields)
    times,plain,_=kernels(40,DURATION,2*shell.mu)
    operator=Green(obj.grid,48)
    rows=[];errors=[]
    for name,field in src.items():
        guard()
        shear=operator.solve(field)
        change,dgrad,drhs,_=geometry(obj,field,shear)
        normal=normal_change(obj,supply,graph,shear,change,dgrad,drhs)
        tangent=field_tangent(obj,graph,shell,shear,change,*normal)
        values=response(shell,tangent,256,times,plain[-1])
        for width,parts in zip(FRACTIONS,values):
            rows.append(dict(seed=seed,source=name,width=width,rest=sum(parts[:3]),geometry=sum(parts[3:])))
        if name in ("leading","corrected"):
            for idx,kind in enumerate(("mono","radial","angular")):
                denom=np.max(abs(exact[idx]))
                errors.append(dict(seed=seed,source=name,current=kind,source_peak=denom,
                    absolute_error=np.max(abs(field[idx]-exact[idx])),relative_error=np.max(abs(field[idx]-exact[idx]))/max(1e-280,denom)))
    save(f"weak-seed{seed}.csv",rows)
    save(f"weak-fields-seed{seed}.csv",errors)


if __name__=="__main__":
    run(int(sys.argv[1]))
