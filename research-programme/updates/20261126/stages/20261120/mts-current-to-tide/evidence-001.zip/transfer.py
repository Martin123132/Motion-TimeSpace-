"""Global linear constraints on one fixed preparation; neither observable nor comparison is read."""
import csv
import hashlib
import io
import json
import os
import sys
from pathlib import Path

for setting in ("OPENBLAS_NUM_THREADS","MKL_NUM_THREADS","OMP_NUM_THREADS","NUMEXPR_NUM_THREADS"):
    os.environ[setting]="1"
HERE=Path(__file__).resolve().parent
PRIOR=HERE.parent/"mts-source-geometry-remainder-20261120"
PIN="0ecb658bad37536be2f895f78cd8a8ba64e776b1a2585b1fa6bb2a6e086d4e16"


def digest(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream,"sha256").hexdigest()


assert digest(PRIOR/"seal.json")==PIN
registry=json.loads((PRIOR/"seal.json").read_bytes())["files"]
for name in ("predict.py","constraint_input.py"):
    assert digest(PRIOR/name)==registry[name]
sys.path.insert(0,str(PRIOR))
from constraint_input import (Stagger,LaunchStress,checked,CLOUD,BalancedNative,SPAN,DLOG,
                             input_pack,Slice,angular,pressure,homogeneous,normal_data,pair,np,
                             kernels,FRACTIONS,DURATION,readout,safe)
from states import jet
from constraint import strain
from scipy.interpolate import BarycentricInterpolator
from scipy.sparse.linalg import splu
from window import Window, exp, inv, mul, CENTER


def guard():
    safe()
    assert not (HERE/"STOP-REQUESTED").exists()


def save(name,records):
    guard()
    stream=io.StringIO(newline="")
    writer=csv.DictWriter(stream,fieldnames=tuple(records[0]),lineterminator="\n")
    writer.writeheader()
    writer.writerows(records)
    path=HERE/name
    encoded=stream.getvalue().encode()
    if path.exists():
        assert path.read_bytes()==encoded,path
    else:
        temp=HERE/(name+".partial")
        with temp.open("xb") as handle:
            handle.write(encoded)
        temp.rename(path)


def grid_fields(obj):
    grid=obj.grid
    mono,md=grid.evaluate(obj.f0)
    quad,qd=grid.evaluate(obj.f2)
    return (1+jet(mono,quad),jet(md,qd),jet(obj.b0,obj.b2),
            jet(obj.hsource(0,mono,md),obj.hsource(2,quad,qd)))


def build(sim,seed):
    ref,press,unused=pressure(0)
    state,grid,samples,supply=input_pack(sim,5,seed,0,ref,press)
    mu=ref["a"]*sim.patch.p.mass
    mean=homogeneous(ref,ref["rh"][sim.patch.j],mu,press)
    obj=Slice(sim,grid,{**ref,"H":mean["hubble"]},samples,state,0,True,"fixed",0,"matched")
    graph,fields=normal_data(obj,supply,mean)
    for count in range(8):
        new,fields=normal_data(obj,supply,mean,graph)
        residual=max(np.max(abs(val-old))/max(np.max(abs(val)),1e-280) for val,old in zip(new,graph))
        graph=new
        if residual<2e-14:
            break
    else:
        raise RuntimeError("positive-frequency graph did not converge")
    cut=grid.points[:,0]<16
    mono=grid.evaluate(obj.state[0])[0]
    phase=samples[0]["V"]+grid.evaluate(obj.state[2])[0][0]
    split=lambda field:pair(field.real,angular(field))
    packet=dict(t=grid.t,h=grid.h,chi=pair(grid.evaluate(obj.f0)[0],grid.evaluate(obj.f2)[0])[...,cut,:],
        n=np.stack([pair(first,second) for first,second in zip(obj.m["n"],obj.m["D"])])[...,cut,:],
        v=np.stack([pair(first,second) for first,second in zip(mono[1]/grid.points,phase)])[...,cut,:],
        b=pair(obj.b0,obj.b2)[...,cut,:],c=obj.c2[cut],d=obj.d2[cut],
        delta=split(graph[0])[...,cut,:],drift=split(graph[1])[...,cut,:],
        rho=ref["rh"],mu=mu,H=mean["hubble"],P=press,R=ref["R"],weight=ref["w"],
        e0=samples[0]["other"][cut],s0=supply["spec2"][cut],native_stress=samples[0]["stress"][cut],
        native_cross=samples[0]["stress_cross"][cut],initial_tide=None,probes=())
    shell=Stagger(packet,120,6,0,1,"stagger")
    shell.incident.bank=LaunchStress(shell.incident.bank)
    return obj,graph,supply,fields,shell


def material(obj):
    data=obj.m
    return (jet(data["n"],data["D"]),jet(data["g"],data["Dr"]),jet(data["p"],data["P"]))


def current(obj,graph,check):
    grid=obj.grid
    conformal,radial,_,_=grid_fields(obj)
    number,gradient,momentum=material(obj)
    index=obj.j
    normal,drift=graph
    mu=obj.bg["a"]*obj.sim.patch.p.mass
    deriv=BarycentricInterpolator(grid.t,np.eye(len(grid.t)),rng=0).derivative(grid.t).T
    logamp_r=(gradient[index]/number[index]-6*radial/conformal-((normal@deriv)/grid.h)/(1+normal))/2
    logamp_t=(angular(number[index])/number[index].real-6*angular(conformal)/conformal.real-angular(normal)/(1+normal.real))/(2*grid.points)
    amplitude=-obj.rh[index]*number[index]*drift/(mu*(1+normal))
    extra=amplitude*logamp_r
    result=np.asarray([extra.real,angular(extra),amplitude.real*logamp_t])
    for actual,key in zip(result,("clock_j0","jr","jt")):
        assert np.max(abs(actual-check[key]))<2e-13*max(1e-290,np.max(abs(actual))),key
    return result


def smooth(radius,lo,hi):
    value=np.clip((radius-lo)/(hi-lo),0.,1.)
    return value**3*(10+value*(-15+6*value))


def masks(grid):
    radius=grid.points
    transitions=[smooth(radius,*limits) for limits in ((.80,.90),(1.80,2.),(6.,8.),(16.,20.))]
    spatial=dict(zip(("deep","detector","outer","distant","remote"),[1-transitions[0],
                 *(a-b for a,b in zip(transitions[:-1],transitions[1:])),transitions[-1]]))
    assert np.max(abs(sum(spatial.values())-1))<1e-14 and min(v.min() for v in spatial.values())>=0
    return dict(all=1.,**spatial,monopole=np.array([1.,0.,0.])[:,None,None],
                quad_radial=np.array([0.,1.,0.])[:,None,None],quad_angular=np.array([0.,0.,1.])[:,None,None])


def longitudinal(grid,current):
    mono,radial,angular_current=current
    spherical=grid.integral(mono*grid.points**3)[1]/grid.points**3
    vector=grid.momentum(radial,angular_current,0.,0.)
    val,der=grid.evaluate(vector)
    return (spherical,*strain(grid.points,(*val,*der)))


def geometry(obj,current,shear):
    grid=obj.grid
    conformal,radial,base,rhs=grid_fields(obj)
    number,gradient,momentum=material(obj)
    shear_change=jet(shear[0],shear[1])
    energy=0.
    gradient_energy=0.
    for index,weight in enumerate(obj.rh):
        mass=weight*number[index]
        if index==obj.j:
            grad=gradient[index]/number[index]-6*radial/conformal
            moment=momentum[index]**2+obj.eps*grad**2
            energy+=mass*(-6/conformal**7-5*moment/conformal**11+6*obj.eps*grad*radial/conformal**12)
            gradient_energy-=6*mass*obj.eps*grad/conformal**11
        else:
            squared=momentum[index]**2/conformal**4
            gamma=np.sqrt(1+squared)
            energy+=mass*(-6*gamma-2*squared/gamma)/conformal**7
    feedback=5*rhs/conformal-36*base**2/(16*conformal**8)+conformal**5*energy/4
    gradient_feedback=conformal**5*gradient_energy/4
    source=3*base*shear_change/(8*conformal**7)
    measure=grid.points**2*grid.w
    correction=grid.matrix(np.einsum("qi,eq,qj->eij",grid.val,measure*feedback.real,grid.val)
        +np.einsum("qi,eq,qj->eij",grid.val,measure*gradient_feedback.real,grid.der),grid.ids,grid.size)
    vals=[];ders=[];residual=0.
    for harmonic in (0,2):
        stiff,active,_=grid.scalar[harmonic,"matched"]
        stencil=(stiff-correction)[active][:,active].tocsc()
        forcing=source.real if harmonic==0 else angular(source)+angular(feedback)*vals[0]+angular(gradient_feedback)*ders[0]
        load=grid.load(forcing)[active]
        answer=splu(stencil).solve(load)
        defect=np.max(abs(stencil@answer-load))
        condition_scale=np.max(abs(stencil)@abs(answer))+np.max(abs(load))
        residual=max(residual,defect/max(1e-290,condition_scale))
        potential=np.zeros(grid.size)
        potential[active]=answer
        value,slope=grid.evaluate(potential)
        vals.append(value);ders.append(slope)
    assert residual<5e-12,residual
    change,dgrad=jet(*vals),jet(*ders)
    drhs=source+feedback*change+gradient_feedback*dgrad
    return change,dgrad,drhs,residual


def normal_change(obj,supply,graph,shear,change,dgrad,drhs):
    conformal,radial,base,rhs=grid_fields(obj)
    number,gradient,momentum=material(obj)
    index=obj.j
    mu=obj.bg["a"]*obj.sim.patch.p.mass
    freq,drift=graph
    grad=radial/conformal
    gradshift=(dgrad-grad*change)/conformal
    frac=change/conformal
    ln_grad=gradient[index]/(2*number[index])-3*grad
    ln_lap=(supply["ln"]/number[index]-(gradient[index]/number[index])**2)/2+3*(rhs/conformal+grad**2)
    quantum=(ln_lap+ln_grad**2+2*grad*ln_grad)/conformal**4
    dquantum=(3*(drhs/conformal-rhs/conformal*frac+2*grad*gradshift)
              -6*ln_grad*gradshift+2*gradshift*ln_grad-6*grad*gradshift)/conformal**4-4*quantum*frac
    phase_rate=(supply["lp"]+(gradient[index]/number[index]-4*grad)*momentum[index])/conformal**4
    ddrift=(4*momentum[index]*gradshift/conformal**4+4*phase_rate*frac)/(2*mu)
    stress=0.
    for species,weight in enumerate(obj.rh):
        density=weight*number[species]/conformal**6
        if index==species:
            addition=(3*freq+2*(freq**2+drift**2))/(1+freq)
            coeff=density*(3+4*freq-addition)/(1+freq)
            stress+=density*(4*drift*ddrift/(1+freq)-6*(1+addition)*frac)
        else:
            psq=momentum[species]**2/conformal**4
            gamma=np.sqrt(1+psq)
            stress+=density*(-2*(2+1/gamma**2)*psq/gamma-6*(2*gamma-1/gamma))*frac
    dcurve=stress/4+1.5*base*jet(shear[0],shear[1])/conformal**12-9*base**2*frac/conformal**12
    dfreq=(-2*momentum[index]**2*frac/conformal**4+(dcurve-dquantum)/(2*mu**2))/(1-coeff/(8*mu**2))
    return dfreq,ddrift


def interpolate(grid,shell,field):
    index=(shell.r/grid.h).astype(int)
    local=shell.r/grid.h-index
    mat=BarycentricInterpolator(grid.t,np.eye(len(grid.t)),rng=0)(local)
    raw=field[...,index,:]
    anchor=raw[...,:1]
    return anchor[...,0]+np.einsum("...ij,ij->...i",raw-anchor,mat)


def field_tangent(obj,graph,shell,shear,change,dfreq,ddrift):
    grid=obj.grid
    at=lambda x:interpolate(grid,shell,x)
    split=lambda field:pair(field.real,angular(field))
    state=shell.initial
    conformal=exp(state[0].real/2)
    delta_log=mul(at(split(change)),inv(conformal))
    freq=at(split(graph[0]))+pair(np.ones_like(shell.r))
    shiftnormal=at(split(dfreq))
    tangent=np.zeros_like(state)
    tangent[0]=tangent[1]=2*delta_log
    tangent[5]=mul(at(pair(*shear[:2])),exp(-3*state[0].real))-6*mul(state[5].real,delta_log)
    for slot,channel in ((6,2),(7,3)):
        tangent[slot,1]=at(shear[channel])*np.exp(-3*state[0,0].real)-6*state[slot,1].real*delta_log[0]
    tangent[14]=-3*delta_log-.5*mul(shiftnormal,inv(freq))
    tangent[15]=at(split(ddrift))-1j*shiftnormal
    for slot in (18,19):
        tangent[slot,1]=-4*tangent[0,0]*state[slot,1]
    number_residual=2*tangent[14].real+tangent[0].real+2*tangent[1].real+mul(shiftnormal,inv(freq))
    assert np.max(abs(number_residual))<2e-13*max(1e-280,np.max(abs(tangent[14])),np.max(abs(tangent[0])))
    return tangent


def rates(shell,initial,times):
    launch=shell.dynamics(0.,initial)
    results=[]
    for time in times:
        advance=time*launch
        oscillation=np.expm1(2j*shell.mu*time)/(2j*shell.mu)
        advance[14]+=(oscillation-time)*launch[15]/(2j)
        advance[15]=oscillation*launch[15]
        fields=initial+advance
        value,error=readout(shell,fields,shell.dynamics(time,fields))
        assert error<1e-10
        results.append(value)
    return np.asarray(results)


def response(shell,tangent,gain,times,weights):
    plus=rates(shell,shell.initial+gain*tangent,times)
    minus=rates(shell,shell.initial-gain*tangent,times)
    return np.einsum("t,twc->wc",weights,(plus-minus)/(2*gain))


def main(seed):
    sim=BalancedNative("heavy",120,600,False,"native36",SPAN*DLOG)
    obj,graph,supply,fields,shell=build(sim,seed)
    grid=obj.grid
    physical=current(obj,graph,fields)
    times,plain,_=kernels(40,DURATION,2*shell.mu)
    zero=longitudinal(grid,physical*0)
    assert all(not np.any(val) for val in zero)
    window=Window(shell,shell.initial,shell.dynamics(0.,shell.initial),8)
    lengths=window.spline(exp(shell.initial[0].real)).antiderivative()
    bounds=lengths(np.array([.9,1.8]))-lengths(0.)[:,None]
    assert bounds[0,0]+abs(bounds[1,0])<.7*CENTER and bounds[0,1]-abs(bounds[1,1])>1.3*CENTER
    records=[];summaries=[]
    for tag,mask in masks(grid).items():
        guard()
        shear=longitudinal(grid,physical*mask)
        change,dgrad,drhs,residual=geometry(obj,physical*mask,shear)
        dnu,ddrift=normal_change(obj,supply,graph,shear,change,dgrad,drhs)
        tangent=field_tangent(obj,graph,shell,shear,change,dnu,ddrift)
        summaries.append(dict(seed=seed,channel=tag,metric_peak=np.max(abs(tangent[0])),shear_peak=np.max(abs(tangent[5:8])),
            heavy_log_peak=np.max(abs(tangent[14])),normal_peak=np.max(abs(tangent[15])),ham_residual=residual))
        for gain in ((64.,256.,1024.) if tag=="all" else (256.,)):
            values=response(shell,tangent,gain,times,plain[-1])
            for width,parts in zip(FRACTIONS,values):
                records.append(dict(seed=seed,channel=tag,gain=gain,width=width,**dict(zip(
                    ("compression","flux","mass_ruler","intrinsic","extrinsic","geometry_ruler"),parts))))
        print(seed,tag,"done",flush=True)
    save(f"raw-seed{seed}.csv",records)
    save(f"fields-seed{seed}.csv",summaries)


if __name__=="__main__":
    main(int(sys.argv[1]))
