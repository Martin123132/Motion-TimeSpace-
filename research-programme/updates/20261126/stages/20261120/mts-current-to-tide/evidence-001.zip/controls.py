"""Independent polynomial/Gaussian solutions and proper-ruler tangent checks."""
from transfer import (np, strain, longitudinal, build, BalancedNative,SPAN,DLOG,
    masks,geometry,normal_change,field_tangent,kernels,response,save,DURATION,guard)
from elements import Element


def main():
    findings=[]
    for resolution in (4,5):
        guard()
        sim=BalancedNative("heavy",120,120*resolution,False,"native36",SPAN*DLOG)
        grid=Element(sim.mesh,120,12)
        radius=grid.points
        coeff=1/9
        scaled=coeff*radius**2
        weight=np.exp(-scaled)
        phi_rr=weight*(2-10*scaled+4*scaled**2)
        radial=2*radius*(1-scaled)*weight
        tangent=radius*weight
        tangent_r=weight*(1-2*scaled)
        lap=(4*scaled**2-14*scaled)*weight
        dlap=weight*(-28*coeff*radius+44*coeff**2*radius**3-8*coeff**3*radius**5)
        current=np.array([(5*radius-2*coeff*radius**3)*weight,4*dlap/3,4*lap/(3*radius)])
        exact=(radius**2*weight,*strain(radius,(radial,tangent,phi_rr,tangent_r)))
        test=longitudinal(grid,current)
        domain=(radius>.5)&(radius<7.)
        for name,value,truth in zip(("monopole","quadrupole_rr","quadrupole_cross","quadrupole_angular"),test,exact):
            error=np.max(abs((value-truth)[domain]))/np.max(abs(truth[domain]))
            findings.append(dict(mesh=resolution,test="gaussian_"+name,error=error,tolerance=2e-5,passed=error<2e-5))
        zero=np.zeros_like(radius)
        vector=grid.momentum(zero,zero,2*grid.edge,grid.edge)
        value,derivative=grid.evaluate(vector)
        for name,actual,target in zip(("rr","cross","angular"),strain(radius,(*value,*derivative)),(4.,2.,2.)):
            error=np.max(abs(actual[domain]-target))/target
            findings.append(dict(mesh=resolution,test="boundary_"+name,error=error,tolerance=2e-5,passed=error<2e-5))
        entries=masks(grid)
        total=sum(np.array(longitudinal(grid,current*entries[key])) for key in ("deep","detector","outer","distant","remote"))
        for name,actual,target in zip(("mono","rr","cross","angular"),total,test):
            error=np.max(abs(actual[domain]-target[domain]))/np.max(abs(target[domain]))
            findings.append(dict(mesh=resolution,test="partition_"+name,error=error,tolerance=2e-5,passed=error<2e-5))
    obj,graph,supply,fields,shell=build(sim,1)
    zeros=np.zeros((3,*grid.points.shape))
    shear=longitudinal(obj.grid,zeros)
    change,dgrad,drhs,_=geometry(obj,zeros,shear)
    normals=normal_change(obj,supply,graph,shear,change,dgrad,drhs)
    null=field_tangent(obj,graph,shell,shear,change,*normals)
    times,weights,_=kernels(40,DURATION,2*shell.mu)
    cold=response(shell,null,256,times,weights[-1])
    assert not np.any(null) and not np.any(cold)
    findings.append(dict(mesh=5,test="zero_insertion",error=0.,tolerance=0.,passed=True))
    save("controls.csv",findings)
    print([(row["test"],float(row["error"])) for row in findings if row["mesh"]==5],flush=True)
    assert all(row["passed"] for row in findings),[row for row in findings if not row["passed"]]


if __name__=="__main__":
    main()
