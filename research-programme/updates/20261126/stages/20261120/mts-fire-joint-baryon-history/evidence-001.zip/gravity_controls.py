from joint_field import *
from scipy.special import ellipk
from scipy.integrate import trapezoid

def spherical_checks(snaps):
    ages={};summary=[];variation=[]
    radial=RC[:,None];angle=UC[None,:];sr=radial*np.sqrt(1-angle**2);sz=radial*angle
    with np.load(HERE/"mw-positive-aperture.npz") as p:local=p["high"]
    end=merged(600)[0][:,0].sum(axis=0)
    for snap in snaps:
        banks,masses,quad,recs=merged(snap);joint=banks[:,0].sum(axis=0);ages[snap]=recs[0]["proper_time_Gyr"]
        assert abs(joint.sum()/masses[:,-1].sum()-1)<1e-10
        sub,_,_=transfer(local,joint,end,False)
        comp=np.minimum(banks[0,0],banks[1,0])*.2
        swapped=(banks[0,0]-comp)+(banks[1,0]+comp)
        diff,_,_=transfer(local,swapped,end,False)
        assert np.sum(abs(diff-sub))<.02
        cs=np.array([np.hypot(6,1.5),np.hypot(8.3,1.5),17.58,30.,70.])
        coeff=coeffs(joint,cs,64)
        for index,(dist,mu) in enumerate(zip(cs,[1.5/cs[0],1.5/cs[1],0.,.65,.5])):
            r=dist*np.sqrt(1-mu**2);z=dist*mu
            direct=0.
            for side in (-1,1):
                spacing=(r+sr)**2+(z-side*sz)**2
                direct-=ls.G/np.pi*np.sum(joint*ellipk(4*r*sr/spacing)/np.sqrt(spacing))
            leg=legvander(mu,64)[0,::2]
            v64=coeff[index]@leg;v32=coeff[index,:17]@leg[:17]
            exact_shell=-ls.G*np.sum(joint.sum(axis=1)/np.maximum(RC,dist))
            assert abs(exact_shell/coeff[index,0]-1)<1e-11
            summary.append(dict(snapshot=snap,r_kpc=dist,mu=mu,direct_mid_ring=direct,potential_l64=v64,potential_l32=v32,
                   rel_ring_l64=v64/direct-1,rel_l32_l64=v32/v64-1,transfer_conversion_L1_Msun=np.sum(abs(diff-sub))))
    bg=Assembly("anchorA").bg;weight=bg.mesh.weight;model=Assembly("anchorA");u=model.ground
    probability=abs(model.sky(u))**2*weight[:,None]*bg.aw[None,:]/model.number
    assert abs(probability.sum()-1)<1e-12
    deg=np.arange(0,65,2);target=bg.rad*bg.length
    moments=probability@legvander(bg.mu,64)[:,::2];lp=legvander(ANG,65);ma=np.ones((len(UC),len(deg)))
    for ix,d in enumerate(deg[1:],1):ma[:,ix]=np.diff(lp[:,d+1]-lp[:,d-1])/((2*d+1)*np.diff(ANG))
    potential=np.empty((len(RC),len(deg)))
    for i,r in enumerate(RC):
        kernel=np.minimum(target/r,r/target)[:,None]**deg/np.maximum(target,r)[:,None]
        potential[i]=-ls.G*np.sum(moments*kernel,axis=0)
    wave_at_cells=potential@ma.T
    for snap in snaps:
        joint=merged(snap)[0][:,0].sum(axis=0)
        delta,_,_=transfer(local,joint,end,False)
        swapped=float(np.sum(delta*wave_at_cells))
        with np.load(HERE/f"forcing-{snap}.npz") as data:direct=float(np.sum(probability*data["joint"]))
        assert abs(swapped-direct)<1e-8
        variation.append(dict(snapshot=snap,wave_samples_source_kms2=direct,source_samples_wave_kms2=swapped,
                  discrepancy_kms2=abs(direct-swapped)))
    tag="_".join(map(str,snaps));table("gravity-cross-"+tag,summary);table("reciprocity-"+tag,variation)
if __name__=="__main__":spherical_checks(tuple(map(int,sys.argv[1:])) or TIMES)
