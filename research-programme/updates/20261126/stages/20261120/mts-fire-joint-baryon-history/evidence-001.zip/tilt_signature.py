from joint_field import *
from scipy.special import eval_legendre

def signature(snaps):
    out=[]
    for snap in snaps:
        bank,mass,exact,recs=merged(snap)
        tilt=np.radians(axis_tilt(snap))
        for degree in (2,4,8,16):
            avg=np.diff(legvander(ANG,degree+1)[:,degree+1]-legvander(ANG,degree-1)[:,degree-1])/((2*degree+1)*np.diff(ANG))
            extrema=np.polynomial.legendre.Legendre.basis(degree).deriv().roots()
            left=eval_legendre(degree,ANG[:-1]);right=eval_legendre(degree,ANG[1:])
            lower=np.minimum(left,right);upper=np.maximum(left,right)
            for v in extrema[(extrema>0)&(extrema<1)]:
                index=np.searchsorted(ANG,v)-1;val=eval_legendre(degree,v)
                lower[index]=min(lower[index],val);upper[index]=max(upper[index],val)
            leg=eval_legendre(degree,np.cos(tilt))
            for rad in (2.,6.,8.3,17.58,30.):
                i=abs(EDGES-rad).argmin();massangular=bank[:,:,:i,:].sum(axis=(0,2))
                total=massangular[0].sum()
                assert abs(total/massangular[1].sum()-1)<1e-12
                fixed,moving=massangular@avg/total
                low=massangular@lower/total;high=massangular@upper/total
                interval=[low[0]-max(leg*low[1],leg*high[1]),high[0]-min(leg*low[1],leg*high[1])]
                out.append(dict(snapshot=snap,r_cut_kpc=EDGES[i],degree=degree,tilt_deg=np.degrees(tilt),axisymmetric_rotation_factor=leg,
                            fixed_moment=fixed,intrinsic_moment=moving,predicted_if_axisymmetric=leg*moving,
                            departure=fixed-leg*moving,lower=interval[0],upper=interval[1],excludes_pure_tilt=not(interval[0]<=0<=interval[1])))
    table("tilt-"+("_".join(map(str,snaps))),out)
if __name__=="__main__":signature(tuple(map(int,sys.argv[1:])) or TIMES)
