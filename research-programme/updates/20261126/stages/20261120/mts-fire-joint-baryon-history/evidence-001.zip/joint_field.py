from collect_particles import *
sys.path.insert(0,str(ROOT/"mts-fixed-number-disk-assembly-20261120"))
from disk import Assembly, parent, CENSUS, BRANCHES
from signed_potential import census,columns,supply,ls
from numpy.polynomial.legendre import legvander
from scipy.special import roots_legendre
import csv

TIMES=(572,586,600)
RC=(EDGES[:-1]+EDGES[1:])*.5
UC=(ANG[:-1]+ANG[1:])*.5
def axis_tilt(snap):
    axis=coords(snap)[-1][-1];last=coords(600)[-1][-1]
    return float(np.degrees(np.arctan2(np.linalg.norm(np.cross(axis,last)),abs(axis@last))))
def table(name,rows):
    mem=io.StringIO(newline="");writer=csv.DictWriter(mem,rows[0],lineterminator="\n");writer.writeheader();writer.writerows(rows);put(name+".csv",mem.getvalue().encode())
def merged(snap):
    bank=0.;pieces=[];mass=0.;quad=0.
    for piece in range(4):
        tag=f"mass-{snap}-{piece}";raw=(HERE/(tag+".npz")).read_bytes();rec=json.loads((HERE/(tag+".json")).read_bytes())
        assert sha(raw)==rec["bank_sha256"] and (snap,piece)==(rec["snap"],rec["piece"]);pieces.append(rec)
        with np.load(io.BytesIO(raw)) as data:
            assert np.array_equal(data["edges"],EDGES) and np.array_equal(data["mu"],ANG)
            bank=bank+data["hist"];mass=mass+data["apmass"];quad=quad+data["apquad"]
    assert np.array_equal(sum(np.array(p["counts_piece"]) for p in pieces),pieces[0]["counts_whole"])
    assert all(p["counts_whole"]==pieces[0]["counts_whole"] for p in pieces)
    return bank,mass,quad,pieces
def local_hist(order):
    src=census();phis,wphi=ls.quad([0,np.pi/2],24);wphi*=2/np.pi
    radii=np.unique(np.r_[np.linspace(0,30,6001),src.radknots,src.stars.bgrid])
    pos=radii[(radii>=0)&(radii<=30)]
    bar=columns(pos);don=supply(pos)
    shares=don/np.maximum(1e-25,don.sum(axis=1))[:,None]
    roots,weights=roots_legendre(order)
    result=np.zeros((len(RC),len(UC)));centralmass=0.;totalmass=0.
    for first in range(0,np.searchsorted(RC,31.),32):
        sl=slice(first,first+32)
        for radial_node,rad_weight in zip(roots,weights):
            rr=RC[sl,None]+radial_node*.5*np.diff(EDGES)[sl,None]
            for az_node,az_weight in zip(roots,weights):
                mu=UC+az_node*.5*np.diff(ANG);R=rr*np.sqrt(1-mu**2);z=rr*mu
                cold=src.disk(R,z)
                bb=[np.interp(R,pos,elem) for elem in bar.T];total_bar=sum(bb)
                reshaped=sum(v*ls.zshape(key,z) for key,v in zip(ls.S22,bb))-total_bar*sum(np.interp(R,pos,elem)*src.starshape(z,index) for index,elem in enumerate(shares.T))
                center=np.zeros_like(z);mask=(R<20)&(z<9)
                rsel=R[mask,None];zsel=z[mask,None]
                center[mask]=src.stars.bmass*(ls.old.density("E3",(.67,.29,.27),rsel*np.cos(phis),rsel*np.sin(phis),zsel)@wphi)
                dm=np.pi*rr**2*np.diff(EDGES)[sl,None]*np.diff(ANG)*rad_weight*az_weight
                density=cold+reshaped+center
                assert np.isfinite(density).all() and density.min()>-1e-7
                taper=np.clip((30-rr)/5,0,1)
                result[sl]+=dm*density*taper
                centralmass+=np.sum(dm*center);totalmass+=np.sum(dm*density*taper)
    assert abs(centralmass/src.stars.bmass-1)<5e-4
    return result
def groups(coarse):
    edges=[0,1,2,4,8,14,25,30] if coarse else [0,.5,1,2,3,4,6,8,10,14,20,25,30]
    mu=[0,1/16,1/4,1/2,1] if coarse else [0,1/32,1/16,1/8,1/4,1/2,3/4,1]
    redges=[EDGES[abs(EDGES-r).argmin()] for r in edges]
    rid=np.clip(np.searchsorted(redges,RC,side="right")-1,0,len(redges)-1)
    aid=np.searchsorted(mu,UC,side="right")-1
    return rid[:,None]*(len(mu)-1)+aid
def transfer(local,raw,end,coarse):
    codes=groups(coarse);bins=codes.ravel()
    now=np.bincount(bins,weights=raw.ravel());ref=np.bincount(bins,weights=end.ravel())
    gain=np.divide(now,ref,out=np.ones_like(now),where=ref>0)
    assert gain.min()>=0
    return local*(gain[codes]-1),np.count_nonzero(ref==0),local[ref[codes]==0].sum()
def coeffs(hist,grid,cap):
    degrees=np.arange(0,cap+1,2)
    leg=legvander(ANG,cap+1)
    mean=np.ones((len(UC),len(degrees)))
    for index,degree in enumerate(degrees[1:],1):
        mean[:,index]=np.diff(leg[:,degree+1]-leg[:,degree-1])/((2*degree+1)*np.diff(ANG))
    moment=hist@mean
    out=np.empty((len(grid),len(degrees)))
    for idx,radius in enumerate(grid):
        ratio=np.minimum(RC/radius,radius/RC);pot=1/np.maximum(radius,RC)
        out[idx]=np.sum(moment*(pot[:,None]*ratio[:,None]**degrees),axis=0)
    return -ls.G*out
def build(snaps=TIMES):
    obj=Assembly("anchorA");bg=obj.bg
    positions=bg.rad*bg.length;mu=bg.mu
    degrees=2*np.arange(33);harm=legvander(mu,64)[:,degrees]
    banks={};rows=[];phases=[]
    for snap in snaps:
        bank,mass,quad,pieces=merged(snap);banks[snap]=bank
        for index,radius in enumerate(AP):
            for j,name in enumerate(("gas","star")):
                rows.append(dict(snapshot=snap,R_kpc=radius,phase=name,mass_msun=mass[j,index],P2_mass=quad[j,index],
                                 cos2_mean=(quad[j,index]/mass[j,index]*2+1)/3,
                                 tilt_deg=axis_tilt(snap),time_Gyr=pieces[0]["proper_time_Gyr"]))
    tag="_".join(map(str,snaps));table("apertures-"+tag,rows)
    localpath=HERE/"mw-positive-aperture.npz"
    if not localpath.exists():
        packet(localpath.name,low=local_hist(1),high=local_hist(2))
    with np.load(localpath) as data:local=data["high"];low=data["low"]
    end=banks[600][:,0].sum(axis=0)
    for snap in snaps:
        gas,star=banks[snap][:,0];joint=gas+star
        profiles={};diagnostics={}
        for name,source,ref,coarse,weights in (("joint",joint,end,False,local),("coarse",joint,end,True,local),("quadrature",joint,end,False,low),
            ("rotating",banks[snap][:,1].sum(axis=0),end,False,local)):
            delta,holes,missing=transfer(weights,source,ref,coarse)
            if snap==600:assert not np.any(delta)
            coefficients=coeffs(delta,positions,64)
            profiles[name]=coefficients@harm.T
            if name=="joint":profiles["monopole"]=np.broadcast_to(coefficients[:,:1],profiles[name].shape).copy()
            diagnostics[name]=dict(empty_endpoint_cells=int(holes),local_missing_mass=float(missing),delta_msun=float(delta.sum()),
                    max_abs_delta_phi=float(np.max(abs(profiles[name]))))
        labels=groups(False).ravel();den=np.bincount(labels,weights=end.ravel())
        for phase,src,old in (("gas_transfer",gas,banks[600][0,0]),("stellar_transfer",star,banks[600][1,0])):
            dmass=np.bincount(labels,weights=(src-old).ravel())
            ratio=np.divide(dmass,den,out=np.zeros_like(den),where=den>0)
            change=local*ratio[labels].reshape(local.shape)
            profiles[phase]=coeffs(change,positions,64)@harm.T
        assert np.max(abs(profiles["joint"]-profiles["gas_transfer"]-profiles["stellar_transfer"]))<1e-7
        for name,profile in (("gas",gas),("star",star),("total",joint),("r250",joint*(RC<250)[:,None])):
            coeff=coeffs(profile,positions,64)
            profiles["raw_"+name]=coeff@harm.T
        assert np.max(abs(profiles["raw_total"]-profiles["raw_gas"]-profiles["raw_star"]))<2e-8
        packet(f"forcing-{snap}.npz",physical_r=positions,mu=mu,**profiles)
        record(f"forcing-{snap}.json",diagnostics)
    print("source",tag,"retained tapered local mass",local.sum(),"relative quadrature mass",low.sum()/local.sum()-1,flush=True)
if __name__=="__main__":build(tuple(map(int,sys.argv[1:])) or TIMES)
