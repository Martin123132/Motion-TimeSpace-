from collections import defaultdict
from joint_field import *
def read(stem):return parent.read(HERE,stem)
def score():
    group=[];refine=[];deficits=[];paths=sorted(HERE.glob("bands-*.csv"))
    for path in paths:
        tag=path.stem[6:];rows=read(path.stem)
        assert len(rows)==96
        partitions=defaultdict(list)
        for r in rows:
            total,base,delta,lo,hi=(float(r[n]) for n in ("total","ground","induced","low","high"))
            assert abs(total-base-delta)<1e-12 and (lo<=total<=hi)==(r["inside"]=="True")
            if r["model"]=="static_NFW":assert delta==0
            need=lo-base if base<lo else hi-base if base>hi else 0.
            if r["model"]=="MTS" and need:
                deficits.append(dict(tag=tag,component=r["component"],R=r["R"],z=r["z"],history=r["history"],
                                     required_change=need,wave_change=delta,closed_fraction=delta/need))
            partitions[r["model"],r["history"]].append(r)
        for (model,history),panel in partitions.items():
            assert len({(r["R"],r["z"],r["component"]) for r in panel})==8
            group.append(dict(tag=tag,model=model,history=history,inside=sum(r["inside"]=="True" for r in panel),n=8,
                    nearest_band_edge=min(min(abs(float(r["total"])-float(r[x])) for x in ("low","high")) for r in panel)))
        branch,kind,steps,snaplist=tag.split("-")
        controls=[("time",branch,kind,str(int(steps)//2),snaplist),
              ("partition",branch,"coarse",steps,snaplist),("quadrature",branch,"quadrature",steps,snaplist),
              ("frame",branch,"rotating",steps,snaplist),("empirical_cadence",branch,kind,steps,"572_586_600")]
        for name,b,k,s,sn in controls:
            compared=f"{b}-{k}-{s}-{sn}"
            if (name not in ("time","empirical_cadence") and kind!="joint") or compared==tag or not (HERE/f"bands-{compared}.csv").exists():continue
            bad=flips=small_bad=0;max_total=max_small=0.;controls_read=read("bands-"+compared)
            for fine,old in zip(rows,controls_read,strict=True):
                assert all(fine[key]==old[key] for key in ("history","model","R","z","component","low","high"))
                if fine["model"]!="MTS":continue
                val=float(fine["total"]);change=abs(val-float(old["total"]))
                bad+=int(change>2e-5*abs(val));flips+=int(fine["inside"]!=old["inside"])
                small=float(fine["induced"]);small_bad+=int(abs(small-float(old["induced"]))>2e-5*abs(small))
                max_total=max(max_total,change/abs(val));max_small=max(max_small,abs(small-float(old["induced"])))
            refine.append(dict(tag=tag,comparison=compared,control=name,tested_MTS=48,outside_relative=bad,induced_outside_relative=small_bad,
                       changed_decisions=flips,max_total_relative=max_total,max_induced_abs=max_small))
    assert group and refine;table("scores",group);table("refinement",refine);table("signed-deficits",deficits)
if __name__=="__main__":score()
