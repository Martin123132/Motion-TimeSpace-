from score_mesh import *

FULL=(572,579,586,590,600)
def run():
    guard();inventory=json.loads((PRIOR/"seal.json").read_bytes())["files"]
    assert all(parent.sha(PRIOR/name)==digest for name,digest in inventory.items())
    clock=np.loadtxt(io.BytesIO((HERE/"snapshot_times.txt").read_bytes()))
    norm={r["branch"]:float(r["number"]) for r in parent.read(CENSUS,"equilibria")}
    scopes={};bytes_used=0;particles=0
    for snap in FULL:
        hist,ap,quad,pieces=merged(snap)
        for piece,rec in enumerate(pieces):
            assert rec["url"]==uri(snap,piece) and len(rec["fields_sha256"])==2
            assert rec["counts_piece"][3]==rec["counts_piece"][5]==0
            assert abs(rec["a"]-clock[clock[:,0]==snap,1].item())<1e-6
            for species in (0,4):particles+=rec["counts_piece"][species]
            bytes_used+=rec["bytes_received"]
        with np.load(HERE/f"forcing-{snap}.npz") as data:
            for key in ("raw_gas","raw_star","raw_total","joint","coarse","rotating","quadrature"):
                assert np.isfinite(data[key]).all()
            assert np.max(abs(data["raw_gas"]+data["raw_star"]-data["raw_total"]))<2e-8
            assert np.max(abs(data["gas_transfer"]+data["stellar_transfer"]-data["joint"]))<1e-7
            if snap==600:assert not data["joint"].any()
    with np.load(HERE/"mw-positive-aperture.npz") as pk:
        assert pk["high"].min()>=0 and abs(pk["low"].sum()/pk["high"].sum()-1)<.001
    with np.load(HERE/"forcing-600.npz") as pk:
        bg=Assembly("anchorA").bg;unit=bg.vel**2;prob=bg.aw
        for cutoff in (250,500):
            raw=pk["raw_r250" if cutoff==250 else "raw_total"]
            assert (raw@prob<0).all()
        difference=pk["raw_total"]-pk["raw_r250"];mean=difference@prob
        scopes["endpoint_250_vs_500_monopole_span_kms2"]=np.ptp(mean).item()
        scopes["endpoint_250_vs_500_max_nonspherical_kms2"]=np.max(abs(difference-mean[:,None])).item()
    assert len(read("independent-cadence"))==14 and len(read("published-cold-cadence"))==145
    matrix=set();max_n=max_e=0.;counts=[]
    for path in HERE.glob("wave-*.npz"):
        tag=path.stem.removeprefix("wave-");branch,kind,step,sn=tag.split("-")
        snaps=tuple(map(int,sn.split("_")));matrix.add((branch,kind,int(step),snaps));history=read("evolution-"+tag)
        assert [int(r["snapshot"]) for r in history]==list(snaps[1:])
        with np.load(path) as data:
            assert len(data["states"])==len(snaps) and float(data["stationary_res"])<1.1e-10
            assert max(abs(np.sum(abs(data["states"])**2,axis=1)/norm[branch]-1))<1e-10
        for row in history:
            max_n=max(max_n,float(row["norm_error"]));max_e=max(max_e,float(row["work_closure_kms2"]))
            if kind=="joint":
                assert abs(float(row["star_work_kms2"])+float(row["gas_work_kms2"])-float(row["work_kms2"]))<1e-9
        assert float(history[-1]["energy_relative_final_ground_kms2"])>=-1e-7
        assert len(read("bands-"+tag))==96 and len(read("streams-"+tag))==4
    assert all((b,"joint",s,sn) in matrix for b in BRANCHES for s in (32,64) for sn in (TIMES,FULL))
    assert all(("anchorA",kind,64,sn) in matrix for kind in ("monopole","rotating","coarse","quadrature") for sn in (TIMES,FULL))
    assert max_n<1e-10 and max_e<.0003
    analog=[]
    for snaps in (TIMES,FULL):
        sn="_".join(map(str,snaps))
        for st in (32,64):
            tag=f"anchorA-{st}-{sn}";track=read("analog-evolution-"+tag)
            assert [int(r["snapshot"]) for r in track]==list(snaps[1:])
            assert max(float(r["norm_error"]) for r in track)<1e-10 and max(float(r["work_closure_kms2"]) for r in track)<.0003
            with np.load(HERE/f"analog-wave-{tag}.npz") as data:
                assert abs(np.vdot(data["final_ground"],data["final_ground"]).real/norm["anchorA"]-1)<1e-10
            analog.append(tag)
    for r in read("scores"):
        assert int(r["n"])==8
        if r["model"]=="static_NFW":assert int(r["inside"])==(2 if r["tag"].startswith("anchorA-") else 4)
    gates=read("energy-reachability");assert len(gates)==6*len(matrix)
    for r in gates:
        if r["fine_certificate"]=="True":
            assert float(r["demand_over_upper"])>1 and float(r["terminal_loss"])>=0
        if r["broad_certificate"]=="True":assert float(r["energy_to_first_possible_hit_kms2"])>0
    null=read("evolution-anchorA-conversion_null-64-572_586_600")[-1]
    assert max(abs(float(null[key])) for key in parent.SITES)<1e-9
    for snap in ("579","590"):
        assert sha((HERE/f"frozen-source-{snap}.npz").read_bytes())==json.loads((HERE/"forecast-lock.json").read_bytes())[snap]
    lock=json.loads((HERE/"next-forecast-lock.json").read_bytes());pick=lock["snapshot"]
    assert not lock["whole_source_seen"] and pick not in FULL
    assert sha((HERE/f"next-all-phase-forecast-{pick}.npz").read_bytes())==lock["frozen_sha256"]
    for r in read("reciprocity-572_579_586_590_600"):assert float(r["discrepancy_kms2"])<1e-8
    for r in read("gravity-cross-572_579_586_590_600"):assert abs(float(r["rel_ring_l64"]))<2e-5
    scopes.update(external_HDF_range_bytes=bytes_used,gas_and_star_particle_instances=particles,independent_simulations=1,full_snapshots=len(FULL),unique_snapshot_files=4*len(FULL),
            previous_sealed_files=len(inventory),fixed_number_runs=len(matrix),untransferred_simulation_runs=analog,max_n_error=max_n,max_work_error_kms2=max_e,
            same_frame_force_decisions=len(matrix)*96,source_timestamps_Myr=[round(1000*clock[clock[:,0]==k,3].item(),6) for k in FULL])
    record("validation.json",scopes)
    files={p.name:parent.sha(p) for p in sorted(HERE.iterdir()) if p.is_file() and p.name!="seal.json"}
    assert not any(p.is_dir() for p in HERE.iterdir())
    record("seal.json",{"files":files});print("checked",len(files),parent.sha(HERE/"seal.json"),json.dumps(scopes))
if __name__=="__main__":run()
