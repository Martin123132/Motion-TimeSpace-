from joint_field import *
from scipy.interpolate import RectBivariateSpline

def cold_series():
    clocks=np.loadtxt(io.BytesIO(fetch_small("snapshot_times.txt","snapshot_times.txt")))
    positions=np.array([[6,1.5],[8.3,1.5],[17.58,0],[8.4,16.8],[12.5,6.675],[0,40.]])
    dataset=[]
    for snap in range(572,601):
        name=f"{snap}.bar.axi_4.coef_cylsp_DR";raw=fetch_small(name,"potential/10kpc/"+name)
        text=raw.decode().splitlines();assert "symmetry=Axisymmetric" in text and "#Phi" in text
        axis=next(i for i,el in enumerate(text) if el.startswith("#R("))
        z=np.array(text[axis].split()[1:],float);mat=np.loadtxt(text[axis+1:axis+1+25]);r=mat[:,0];phi=mat[:,1:]
        assert len(z)==len(r)==25 and np.isfinite(phi).all() and np.all(phi<0) and r[0]==0 and z[0]==0
        spline=RectBivariateSpline(np.log1p(r),np.log1p(z),phi,s=0)
        assert abs(spline(np.log1p(r),np.log1p(z))-phi).max()<1e-7
        value=spline.ev(np.log1p(positions[:,0]),np.log1p(positions[:,1]))
        diff=value[:-1]-value[-1]
        time=clocks[clocks[:,0]==snap,3].item()
        dataset.append((snap,time,diff))
    obs=[]
    epochs=np.array([x[1] for x in dataset]);sample=np.array([v for _,_,v in dataset]);co=np.array([0,14,28])
    for index,(snap,t,diff) in enumerate(dataset):
        for j,(R,Z) in enumerate(positions[:-1]):
            interp=np.interp(t,epochs[co],sample[co,j])
            obs.append(dict(snapshot=snap,proper_time_Gyr=t,R=R,z=Z,star_cold_difference_kms2=diff[j],coarse_interpolation_kms2=interp,
                        error_kms2=diff[j]-interp))
    table("published-cold-cadence",obs)
if __name__=="__main__":cold_series()
