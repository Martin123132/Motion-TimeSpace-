import os
for key in ("OPENBLAS_NUM_THREADS","MKL_NUM_THREADS","OMP_NUM_THREADS","NUMEXPR_NUM_THREADS","BLIS_NUM_THREADS"):
    os.environ[key]="1"
import bisect
import hashlib
import io
import json
import sys
from collections import OrderedDict
from pathlib import Path
import h5py
import numpy as np
import requests

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
PRIOR=ROOT/"mts-empirical-radial-assembly-20261120"
PIN="175bd0964070ff73bdb622c9e4afc030b56c746fe18d67dcf80e7cbc744a41d7"
BASE="https://users.flatironinstitute.org/~mgrudic/fire2_public_release/core/m12i_res7100/"
def sha(data):return hashlib.sha256(data).hexdigest()
def guard():
    assert not (HERE/"STOP-REQUESTED").exists()
    assert sha((PRIOR/"seal.json").read_bytes())==PIN
def put(name,data):
    guard();path=HERE/name
    if path.exists():assert path.read_bytes()==data,path
    else:
        with path.open("xb") as out:out.write(data)
def record(name,obj):put(name,(json.dumps(obj,indent=2,sort_keys=True)+"\n").encode())
def fetch_small(name,remote):
    guard();path=HERE/name
    if path.exists():return path.read_bytes()
    with requests.get(BASE+remote,timeout=(8,25),stream=True) as response:
        response.raise_for_status();data=response.raw.read(500001,decode_content=True)
    assert 0<len(data)<500001
    put(name,data);return data

class Remote(io.RawIOBase):
    def __init__(self,url,block=262144):
        self.session=requests.Session();self.url=url;self.pos=0;self.block=block
        self.cache=OrderedDict();self.transferred=0;self.calls=0
        self.id=None;self.spans=[]
        raw=self.range(0,8)
        assert raw==b"\x89HDF\r\n\x1a\n"
    def range(self,start,count):
        for attempt in range(3):
            try:
                with self.session.get(self.url,headers={"Range":f"bytes={start}-{start+count-1}","Accept-Encoding":"identity"},stream=True,timeout=(8,45)) as rep:
                    assert rep.status_code==206,(rep.status_code,start,count)
                    cr=rep.headers["Content-Range"];sp,size=cr.split("/")
                    assert sp==f"bytes {start}-{start+count-1}",cr
                    identity=(int(size),rep.headers.get("ETag"),rep.headers.get("Last-Modified"))
                    if self.id is None:self.id=identity
                    assert self.id==identity
                    self.size=self.id[0];raw=rep.raw.read(count+1)
                    assert len(raw)==count
                    self.transferred+=count;self.calls+=1
                    assert self.transferred<480_000_000,("per-piece transfer guard",self.transferred)
                    return raw
            except (requests.RequestException,OSError) as exc:
                if attempt==2:raise
    def tell(self):return self.pos
    def seek(self,offset,whence=0):
        self.pos=(0,self.pos,self.size)[whence]+offset;return self.pos
    def readinto(self,out):
        length=min(len(out),self.size-self.pos);done=0
        while done<length:
            span=next(((start,buf) for start,buf in self.spans if start<=self.pos<start+len(buf)),None)
            if span is not None:
                start,buf=span;local=self.pos-start;take=min(length-done,len(buf)-local)
                out[done:done+take]=memoryview(buf)[local:local+take];done+=take;self.pos+=take
                continue
            index,local=divmod(self.pos,self.block)
            if index not in self.cache:
                start=index*self.block
                self.cache[index]=self.range(start,min(self.block,self.size-start))
                if len(self.cache)>20:self.cache.popitem(last=False)
            buf=self.cache[index];self.cache.move_to_end(index)
            take=min(length-done,len(buf)-local)
            out[done:done+take]=buf[local:local+take];done+=take;self.pos+=take
        return done
    def load_field(self,dataset):
        guard();dim=dataset.shape
        first=dataset.id.get_chunk_info_by_coord(tuple(0 for n in dim))
        last=dataset.id.get_chunk_info_by_coord(tuple(n-1 for n in dim))
        begin=first.byte_offset;end=last.byte_offset+last.size
        assert 0<end-begin<325_000_000
        result=bytearray(end-begin);stride=8*1024*1024
        for left in range(begin,end,stride):
            count=min(end-left,stride);data=self.range(left,count)
            result[left-begin:left-begin+count]=data
        self.spans.append((begin,result))
    def close(self):self.spans.clear();self.cache.clear();self.session.close();super().close()
    def inspect(self):
        with h5py.File(self,"r") as data:
            head=data["Header"].attrs
            print({k:np.asarray(head[k]).tolist() for k in head if k in ("BoxSize","Time","HubbleParam","MassTable","NumFilesPerSnapshot","NumPart_ThisFile","NumPart_Total") or "Unit" in k})
            for part in ("PartType0","PartType4"):
                for key in ("Coordinates","Masses"):
                    field=data[part+"/"+key]
                    print(field.name,field.shape,field.dtype,field.chunks,field.compression,field.id.get_storage_size(),field.id.get_offset())
                    if field.chunks:
                        print("chunk0",field.id.get_chunk_info(0),"last",field.id.get_chunk_info(field.id.get_num_chunks()-1))
        print("traffic",self.transferred,self.calls,self.id)
def uri(snap,piece):return BASE+f"output/snapdir_{snap:03d}/snapshot_{snap:03d}.{piece}.hdf5"

if __name__=="__main__":
    guard();remote=Remote(uri(int(sys.argv[1]),int(sys.argv[2])))
    try:remote.inspect()
    finally:remote.close()
