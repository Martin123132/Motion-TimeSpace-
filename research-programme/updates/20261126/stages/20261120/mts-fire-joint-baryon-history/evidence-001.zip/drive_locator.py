from cadence import *
from scipy.special import eval_legendre

def locate():
    obj=Assembly("anchorA");bg=obj.bg;field=obj.ground;number=obj.number
    rad=bg.rad[:,None]*bg.length;mu=bg.mu[None,:]
    R=rad*np.sqrt(1-mu**2);z=rad*abs(mu)
    deg=np.arange(0,min(65,2*len(bg.mu)),2)
    harm=legvander(bg.mu,int(deg[-1]))[:,deg]
    while np.max(abs((harm.T@(bg.aw[:,None]*harm))*(2*deg+1)-np.eye(len(deg))))>1e-9:
        deg=deg[:-1];harm=harm[:,:-1]
    assert deg[-1]>=16
    moments=[];ages=[];times=np.loadtxt(io.BytesIO((HERE/"snapshot_times.txt").read_bytes()))
    for snap in range(572,601):
        text=(HERE/f"{snap}.bar.axi_4.coef_cylsp_DR").read_text().splitlines()
        at=next(i for i,t in enumerate(text) if t.startswith("#R("));zz=np.array(text[at].split()[1:],float)
        matrix=np.loadtxt(text[at+1:at+26]);rr=matrix[:,0];full=matrix[:,1:]
        assert R.max()<=rr[-1] and z.max()<=zz[-1]
        sp=RectBivariateSpline(np.log1p(rr),np.log1p(zz),full,s=0)
        pot=sp.ev(np.log1p(R),np.log1p(z))
        intrinsic=(pot*bg.aw)@harm*(2*deg+1)
        coeff=intrinsic*eval_legendre(deg,np.cos(np.deg2rad(axis_tilt(snap))))
        moments.append(coeff@harm.T)
        ages.append(times[times[:,0]==snap,3].item())
    rows=[]
    for knots in ((572,586,600),(572,579,586,590,600)):
        for snap in range(knots[0],knots[-1]+1):
            if snap in knots:continue
            i=snap-572;left,right=next((a,b) for a,b in zip(knots[:-1],knots[1:]) if a<snap<b)
            lo,hi=left-572,right-572
            w=(ages[i]-ages[lo])/(ages[hi]-ages[lo]);miss=moments[i]-(1-w)*moments[lo]-w*moments[hi]
            shadow=obj.multiply(miss,field);mean=float(field@shadow/number);shadow-=mean*field
            drive=np.linalg.norm(shadow)/np.sqrt(number)
            massprob=abs(obj.sky(field))**2*bg.mesh.weight[:,None]*bg.aw/number
            rms=np.sqrt(np.sum(massprob*(miss-mean)**2))
            assert drive<=rms+1e-8 and drive>0 and abs(shadow@field)<1e-8
            rows.append(dict(history="_".join(map(str,knots)),snapshot=snap,left=left,right=right,time_Gyr=ages[i],cold_projected_drive_kms2=drive,
                   variance_bound_kms2=rms,mean_removed_kms2=mean))
    table("next-source-locator",rows)
    candidates=[r for r in rows if r["history"]=="572_579_586_590_600"]
    selected=max(candidates,key=lambda r:r["cold_projected_drive_kms2"])
    snap=selected["snapshot"];left=selected["left"];right=selected["right"]
    assert not list(HERE.glob(f"mass-{snap}-*.json"))
    lo,hi=left-572,right-572;j=snap-572;frac=(ages[j]-ages[lo])/(ages[hi]-ages[lo])
    with np.load(HERE/f"forcing-{left}.npz") as low,np.load(HERE/f"forcing-{right}.npz") as high:
        baseline=(1-frac)*low["raw_total"]+frac*high["raw_total"]
    correction=moments[j]-(1-frac)*moments[lo]-frac*moments[hi]
    prob=abs(obj.sky(field))**2*bg.mesh.weight[:,None]*bg.aw/number
    baseline-=np.sum(prob*baseline);correction-=np.sum(prob*correction)
    packet(f"next-all-phase-forecast-{snap}.npz",linear=baseline,cold_detail=baseline+correction,probability=prob,r_kpc=bg.rad*bg.length,mu=bg.mu)
    record("next-forecast-lock.json",dict(snapshot=snap,left=left,right=right,fraction=frac,whole_source_seen=False,
          frozen_sha256=sha((HERE/f"next-all-phase-forecast-{snap}.npz").read_bytes()),selection="maximum five-knot cold-source tangent norm; no force-band input",
          target="gauge-centered raw 500 kpc all-temperature gas+stellar potential, in fixed terminal axis, weighted RMS field and projected tangent norms; test BOTH"))
if __name__=="__main__":locate()
