from joint_field import *

def forecast():
    clocks=np.loadtxt(io.BytesIO((HERE/"snapshot_times.txt").read_bytes()))
    get=lambda snap:clocks[clocks[:,0]==snap,3].item()
    for target,left,right in ((579,572,586),(590,586,600)):
        alpha=(get(target)-get(left))/(get(right)-get(left));pred={}
        assert 0<alpha<1
        with np.load(HERE/f"forcing-{left}.npz") as low,np.load(HERE/f"forcing-{right}.npz") as high:
            for key in ("joint","monopole","gas_transfer","stellar_transfer","raw_total","raw_gas","raw_star"):
                pred[key]=(1-alpha)*low[key]+alpha*high[key]
        packet(f"frozen-source-{target}.npz",left=left,right=right,frac=alpha,**pred)
    record("forecast-lock.json",{str(s):sha((HERE/f"frozen-source-{s}.npz").read_bytes()) for s in (579,590)})
def compare():
    assert (HERE/"forecast-lock.json").is_file()
    rows=[];obj=Assembly("anchorA");bg=obj.bg
    probability=abs(obj.sky(obj.ground))**2*bg.mesh.weight[:,None]*bg.aw[None,:]/obj.number
    for snap,digest in json.loads((HERE/"forecast-lock.json").read_bytes()).items():
        assert sha((HERE/f"frozen-source-{snap}.npz").read_bytes())==digest
        with np.load(HERE/f"frozen-source-{snap}.npz") as pred,np.load(HERE/f"forcing-{snap}.npz") as actual:
            for key in ("joint","monopole","gas_transfer","stellar_transfer","raw_total","raw_gas","raw_star"):
                miss=actual[key]-pred[key]
                center=lambda arr:arr-np.sum(arr*probability)
                rms=lambda arr:float(np.sqrt(np.sum(probability*center(arr)**2)))
                rows.append(dict(snapshot=snap,source=key,expected_rms=rms(pred[key]),actual_rms=rms(actual[key]),miss_rms_kms2=rms(miss),
                           signed_shift_in_fixed_gauge_kms2=np.sum(probability*miss),max_abs_miss_kms2=np.max(abs(miss))))
    table("independent-cadence",rows)
if __name__=="__main__":
    if sys.argv[1]=="freeze":forecast()
    elif sys.argv[1]=="check":compare()
    else:raise ValueError(sys.argv[1])
