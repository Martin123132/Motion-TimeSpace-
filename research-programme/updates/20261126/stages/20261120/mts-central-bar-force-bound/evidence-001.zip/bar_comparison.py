from primary_wave import *
def cumulative_rotations():
    rows=[];checks=[]
    for occ in range(3):
        for R in (6.,8.3,17.58):
            table_row=dict(occupation=occ,R=R)
            for setting in ('broad','fine'):
                records=[next(v for v in read(HERE,f'rotating-{setting}-{occ}-m{m}') if float(v['R'])==R) for m in range(2,33,2)]
                for key in ('radial','polar','azimuthal','polar_ceiling'):table_row[setting+'_'+key]=sum(float(r[key]) for r in records)
                if setting=='fine':
                    for m,v in zip(range(2,33,2),records):
                        coarse=next(row for row in read(HERE,f'rotating-broad-{occ}-m{m}') if float(row['R'])==R)
                        for key in ('radial','polar','azimuthal'):
                            value=float(v[key]);dv=abs(value-float(coarse[key]))
                            checks.append(dict(occupation=occ,m=m,R=R,key=key,value=value,absolute=dv,
                                    relative='' if abs(value)<1e-20 else dv/abs(value),within_relative='' if abs(value)<1e-20 else dv<=2e-5*abs(value),
                                    green_difference='' if key=='azimuthal' else value-float(v['green_'+key])))
            rows.append(table_row)
    table('coherent-harmonic-sums',rows);table('coherent-harmonic-checks',checks);return rows

def run():
    freeze();rot=cumulative_rotations();rows=[];summ=[];angles=[];timing=[];outer=[]
    common=read(HERE,'geometry-forces')
    source={(v['R'],v['component']):float(v['change']) for v in common if v['model']=='E3' and v['sample']=='all'}
    old_az=read(ROOT/'mts-lmc-tidal-history-20261119','present-sky')
    halo=prep.ms.nfw(0)
    lmc=read(HERE,'lmc-fine-1');lmcc=read(HERE,'lmc-coarse-0')
    for occ in range(3):
        gr=read(HERE,'states-fine-1')[occ];cg=read(HERE,'states-coarse-0')[occ]
        controls=read(PREV,f'fine-mesh1-k64-occ{occ}-bands')
        for h in prep.ms.MODELS:
            filt=lambda data,n:next(v for v in data if v['history']==h and int(v['occupation'])==occ and int(v['substeps'])==n)
            fine=filt(lmc,16);broad=filt(lmcc,16);slow=filt(lmc,8)
            for key in ('r6','p6','r83','p83'):
                val=float(fine[key])
                for flag,ctl in [('time',slow),('space',broad)]:
                    dv=abs(val-float(ctl[key]));timing.append(dict(occupation=occ,history=h,key=key,check=flag,absolute=dv,relative=dv/abs(val),within=dv<=2e-5*abs(val)))
            for model in ('MTS','NFW'):
                for frame in ('site_minus_point','archive_accelerating'):
                    sub=[]
                    for v in controls:
                        if (v['history'],v['frame'],v['model'])!=(h,frame,model):continue
                        R,z,k=float(v['R']),float(v['z']),v['component'];sgn=-1 if z<0 and k=='polar' else 1
                        row=next(a for a in rot if a['occupation']==occ and a['R']==R)
                        base=float(v['ordinary']);bar=sgn*source[str(R),k];direct=float(v['direct'])
                        tag=('r' if k=='radial' else 'p')+('6' if R==6 else '83')
                        if model=='MTS':
                            dark=sgn*float(gr[tag]);coarsed=sgn*float(cg[tag])
                            sat=sgn*float(fine[tag]);coarses=sgn*float(broad[tag])
                            rotating=sgn*row['fine_'+k];coarser=sgn*row['broad_'+k]
                        else:
                            grr,gz,*_=halo(R,abs(z));pr=prep.projection(grr,gz,R,abs(z))[int(k=='polar')]
                            dark=sgn*float(gr['nfw_scale'])*pr;coarsed=sgn*float(cg['nfw_scale'])*pr
                            sat=rotating=coarses=coarser=0.
                        total=base+bar+direct+dark+sat+rotating
                        coarse=base+bar+direct+coarsed+coarses+coarser
                        lo,hi=float(v['low']),float(v['high'])
                        sub.append(dict(occupation=occ,history=h,frame=frame,model=model,R=R,z=z,component=k,ordinary_before=base,bar_minus_sphere=bar,
                                        dark_mean=dark,LMC_direct=direct,LMC_axis_wave=sat,rotating_bar_wave=rotating,total=total,
                                        previous_total=v['total'],low=lo,high=hi,inside=lo<=total<=hi,coarse=coarse,coarse_inside=lo<=coarse<=hi))
                    assert len(sub)==8
                    rows+=sub;summ.append(dict(occupation=occ,history=h,frame=frame,model=model,inside=sum(q['inside'] for q in sub),
                          unchanged=all(q['inside']==q['coarse_inside'] for q in sub),max_abs=max(abs(q['total']-q['coarse']) for q in sub)))
                for v in old_az:
                    if v['model']!=h or v['tag']!=old_az[0]['tag'] or v['background']!='mts' or v['component']!='azimuthal':continue
                    R=float(v['R']);d=float(v['direct']);ordinary=source[str(R),'azimuthal']
                    r=next(a for a in rot if a['occupation']==occ and a['R']==R)
                    wave=r['fine_azimuthal'] if model=='MTS' else 0.
                    angles.append(dict(occupation=occ,history=h,R=R,z=v['z'],model=model,frame='site_minus_point',bar=ordinary,LMC_direct=d,bar_wave=wave,
                                       prediction=ordinary+wave+d,label='no azimuthal measurement band in retained ledger'))
        for kind in ('MTS','NFW'):
            probe=prep.ms.OUTER;bank=Field('extra');mean_rad=next(row['radial'] for row in bank.at(probe,0.,pi-np.deg2rad(29.4)) if row['m']==0)
            full=next(float(v['bar']) for v in common if v['model']=='E3' and v['sample']=='all' and float(v['R'])==probe and v['component']=='radial')
            barwave=next(v['fine_radial'] for v in rot if v['occupation']==occ and v['R']==probe) if kind=='MTS' else 0.
            speed=float(gr['outer_speed']);proxy=np.sqrt(speed**2-(full-mean_rad+barwave)*probe/UNIT)
            outer.append(dict(occupation=occ,model=kind,mean_speed=speed,bar_meridian_force_speed_proxy=proxy,
                           meridian_minus_mean_ordinary=full-mean_rad,bar_wave_radial=barwave))
    table('full-paired-forces',rows);table('full-paired-scores',summ);table('LMC-refinements',timing);table('outer-calibration',outer);table('azimuthal-forecast',angles)

if __name__=='__main__':run()
