from bar_inputs import *
def cells(R,z,left,right,t0,t1,h0,h1):
    xpos=np.minimum.reduce([left*t0,right*t0,left*t1,right*t1])
    xhi=np.maximum.reduce([left*t0,right*t0,left*t1,right*t1])
    alow=(R-right)**2+2*R*left*(1-t1);ahigh=(R-left)**2+2*R*right*(1-t0)
    lo=np.minimum((h0-z)**2,(h1-z)**2);lo=np.where((h0<=z)&(h1>=z),0.,lo)
    hi=np.maximum((h0-z)**2,(h1-z)**2)
    def upper(n,dlo,dhi):return n*np.where(n>=0,dlo**-1.5,dhi**-1.5)
    minus=upper(z*xhi-R*h0,alow+lo,ahigh+hi)
    plus=upper(z*xhi+R*h1,alow+(h0+z)**2,ahigh+(h1+z)**2)
    return (minus+plus)/(2*np.hypot(R,z))
def exact_flat(R,z,s,sym):
    near=((R-s)**2+z*z)**-1.5
    return z*s/np.hypot(R,z)*(near if sym=='any_azimuth' else .5*(near-((R+s)**2+z*z)**-1.5))
def run():
    freeze();stars=Source().stars;results=[];threshold=[]
    domain=[4.+j/8 for j in range(13)];requirements=read(HERE,'stellar-leverage-required');totals=read(HERE,'all-inner-stars-ceiling')
    for R in (6.,8.3):
        z=1.5;rr=np.hypot(R,z)
        for step,nt,nh in ((.05,32,48),(.025,64,96)):
            hh=np.unique(np.r_[np.linspace(0,3,nh+1),np.linspace(3,8,nh//4+1),np.linspace(8,18,8)]);h0=hh[:-1];h1=hh[1:]
            tt=np.linspace(0,1,nt+1)[:,None]
            bins=np.unique(np.r_[stars.bgrid,stars.centres[stars.centres<=5.5],domain])
            acc={k:np.zeros(3) for k in ('any_azimuth','half_turn')}
            for low,high in zip(bins,bins[1:]):
                cut=np.linspace(low,high,max(1,int(np.ceil((high-low)/step)))+1)
                for a,b in zip(cut,cut[1:]):
                    s,w=rule(a,b,4);dm=2*pi*1e6*s*w*(stars.raw_sigma(s)@stars.factors)
                    front=cells(R,z,a,b,tt[:-1],tt[1:],h0,h1)
                    back=cells(R,z,a,b,-tt[1:],-tt[:-1],h0,h1)
                    tail=z*b/rr/((R-b)**2+(hh[-1]-z)**2)**1.5
                    for sym,kern in [('any_azimuth',front),('half_turn',.5*(front+back))]:
                        ceil=max(kern.max(),tail,0)*G*UNIT
                        wit=G*UNIT*(dm@exact_flat(R,z,s,sym))
                        assert ceil*dm.sum()+1e-14>=wit
                        acc[sym]+=np.array([dm.sum(),ceil*dm.sum(),wit])
                if high not in domain:continue
                for sym,(mass,limit,aligned) in acc.items():
                    control=next(v for v in totals if float(v['R'])==R and float(v['cut'])==high and v['symmetry']==sym)
                    assert abs(mass/float(control['stellar_mass'])-1)<1e-12
                    original=float(control['old_inner_direct'])
                    results.append(dict(R=R,cut=high,symmetry=sym,step=step,mass=mass,old_direct=original,
                             upper=min(limit,float(control['max_even']))+1e-10,aligned_plane=aligned,max_gain=min(limit,float(control['max_even']))-original+1e-10))
                    if step!=.025:continue
                    for model in ('MTS','NFW'):
                        previous=next(v for v in requirements if float(v['R'])==R and float(v['cut'])==high and v['symmetry']==sym and v['model']==model)
                        need=float(previous['maximum_increase'])+float(previous['if_saved_dark_held_remaining'])
                        threshold.append(dict(R=R,cut=high,symmetry=sym,model=model,least_needed_gain=need,
                              remaining_even_after_most_generous=need-results[-1]['max_gain'],aligned_plane_gain=aligned-original,
                              single_component_cannot_reach=need>results[-1]['max_gain']))
    table('vertical-azimuth-kernel-enclosure',results);table('radial-support-threshold',threshold)
if __name__=='__main__':run()
