from pathlib import Path
import os
import sys
import csv
import hashlib
import io
import json
for key in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','BLIS_NUM_THREADS'):os.environ[key]='1'
HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
PREV=ROOT/'mts-measured-baryon-gravity-20261120'
sys.path.insert(0,str(PREV))
import prepare_field as prep
from measured_source import np,Source,digest
from scipy.special import roots_legendre,k0,beta
from math import pi
G=prep.old.G
UNIT=prep.ms.UNIT
PIN='2049a949d65de9077419a1f1ca183d9b5a09da343a9d7bdcf14fd4622c76128e'
GEOMETRIES=(
    ('all','E3',.67,.29,.27,29.4),('all','G1',1.18,.49,.42,30.7),('all','E2',.66,.27,.25,32.4),
    ('inner_lon','G1',1.26,.42,.40,29.2),('inner_lon','E2',.77,.24,.24,31.6),('inner_lon','E3',.71,.25,.27,27.7),
    ('inner_lon_lat','G1',1.08,.39,.37,27.8),('inner_lon_lat','E2',.68,.23,.25,31.2),('inner_lon_lat','E3',.68,.25,.28,28.1))
def guard():
    assert digest(PREV/'seal.json')==PIN and not any((p/'STOP-REQUESTED').exists() for p in (PREV,ROOT,HERE))
def put(name,raw):
    guard();path=HERE/name
    if path.exists():assert path.read_bytes()==raw,name
    else:
        with path.open('xb') as target:target.write(raw)
def table(name,rows):
    buf=io.StringIO(newline='');out=csv.DictWriter(buf,rows[0],lineterminator='\n');out.writeheader();out.writerows(rows);put(name+'.csv',buf.getvalue().encode())
def read(root,name):
    with (root/(name+'.csv')).open(newline='',encoding='utf8') as src:return list(csv.DictReader(src))
def quadgrid(edges,order):
    return prep.intervals(np.asarray(edges),order)
def rule(low,high,order):
    return quadgrid([low,high],order)
def norm(kind,axes):
    return np.prod(axes)*{'G1':(2*pi)**1.5,'E2':8*pi,'E3':3*pi*pi/4*beta(.25,1.5)}[kind]
def density(kind,axes,x,y,z):
    planar=(x/axes[0])**2+(y/axes[1])**2;vertical=(z/axes[2])**2
    if kind=='G1':return np.exp(-.5*(planar+vertical))/norm(kind,axes)
    if kind=='E2':return np.exp(-np.sqrt(planar+vertical))/norm(kind,axes)
    return k0((planar**2+vertical**2)**.25)/norm(kind,axes)
def freeze():
    guard();data=dict(parent=PIN,protocol=digest(HERE/'PROTOCOL.md'),inputs=digest(HERE/'bar_inputs.py'),
        source='https://arxiv.org/pdf/1303.6430',tables=[1,3],geometries=GEOMETRIES,central_species_msun=list(prep.old.LENS.central))
    put('input-lock.json',(json.dumps(data,indent=2)+'\n').encode())
if __name__=='__main__':freeze()
