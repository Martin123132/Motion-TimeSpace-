from primary_wave import *
from scipy.integrate import simpson
from scipy.interpolate import CubicSpline
from functools import lru_cache
import importlib.util
loc=ROOT/'mts-rotating-bar-wave-drive-20261119'
spec=importlib.util.spec_from_file_location('sealed_outgoing',loc/'outgoing.py')
out=importlib.util.module_from_spec(spec);spec.loader.exec_module(out)
from bar_field import angular,slope
from mts_bar_radial import numerov,tail_factor
TAIL=lru_cache(maxsize=1024)(tail_factor)
CONFIG={'broad':(8,112,40.),'fine':(12,192,48.),'edge':(12,192,60.)}
def rotate(occ,setting,mode,frequency=33.29):
    guard();bank=Field('extra')
    with np.load(HERE/f'ground-fine-1-{occ}.npz') as pk:physical={k:pk[k] for k in ('rad','wave','hamiltonian','energy','edge','vel','length','mass','aw')};physical['mu']=pk['angular']
    length,vel=float(physical['length']),float(physical['vel'])
    physical['drive']=bank.grid(physical['rad']*length,physical['mu'],mode)[0]/vel**2
    channels,perunit,outer=CONFIG[setting];step=1/perunit;grid=np.arange(round(outer*perunit)+1)*step
    omega=mode*length/vel*frequency
    orders,pot,mix,drive,energy,monopole=out.prepare(physical,channels,grid,omega,mode)
    assert energy+omega>0 and energy-omega<0 and monopole>0
    size=3*channels;pos=slice(0,channels);neg=slice(channels,2*channels);grav=slice(2*channels,size)
    diag=np.arange(channels);centrif=orders*(orders+1)/np.maximum(grid[:,None],step)**2
    def coeff(idx):
        mat=np.zeros((size,size));barrier=centrif[idx]
        mat[pos,pos]=2*pot[idx];mat[neg,neg]=2*pot[idx]
        mat[diag,diag]+=barrier-2*(energy+omega)
        mat[diag+channels,diag+channels]+=barrier-2*(energy-omega)
        mat[diag+2*channels,diag+2*channels]=barrier
        mat[pos,grav]=2*mix[idx];mat[neg,grav]=2*mix[idx];mat[grav,pos]=mix[idx];mat[grav,neg]=mix[idx]
        return mat
    tails=[TAIL(int(el),en,monopole,outer,step) for en in (energy+omega,energy-omega) for el in orders]
    ratio,der=np.array(tails).T;assert min(der[pos].imag)>0 and max(abs(der[neg].imag))<1e-14
    forcing=np.column_stack((2*drive,2*drive,0*drive))
    sol=numerov(grid,coeff,forcing,np.r_[ratio,((outer-step)/outer)**orders])
    flux=np.sum(abs(sol[-1,pos])**2*der[pos].imag)
    work=2*simpson(np.sum((sol[:,pos]+sol[:,neg]).conj()*drive,axis=1).imag,x=grid)
    probes=out.evaluate(grid,sol,orders,physical,frequency,'new-'+str(occ),'MTS',mode)
    source=CubicSpline(grid,np.einsum('rij,rj->ri',mix,sol[:,pos]+sol[:,neg]),axis=0)
    rows=[]
    for row in probes:
        radius=float(row['R']);height=1.5 if radius!=17.58 else 0.;dist=np.hypot(radius,height);at=dist/length
        zz,ww=quadgrid(np.unique(np.r_[grid,at]),4)
        kernel=np.where(zz[:,None]<at,(zz[:,None]/at)**(orders+1),(at/zz[:,None])**orders)
        terms=ww[:,None]*source(zz)*kernel;inner=terms[zz<at].sum(0);exterior=terms[zz>at].sum(0)
        mu=height/dist;harm=np.array([angular(int(el),mode,mu) for el in orders]);dmu=np.array([slope(int(el),mode,mu) for el in orders])
        phase=2*np.exp(mode*1j*(pi-np.deg2rad(29.4)));scale=vel**2/length*UNIT
        polar=(-(inner+exterior)/(2*orders+1))@dmu*(radius/dist)/at*scale
        radial=-(((orders+1)*inner-orders*exterior)/(2*orders+1))@harm/at*scale
        rows.append(dict(occupation=occ,setting=setting,m=mode,R=radius,pattern=frequency,
                        polar=row['measured_polar'],radial=row['measured_radial'],azimuthal=row['measured_azimuthal'],polar_ceiling=row['max_polar'],
                        green_polar=(phase*polar).real,green_radial=(phase*radial).real,
                        flux=flux,work=work,relative_balance=abs(flux-work)/max(flux,1e-200),energy_open_kms2=(energy+omega)*vel**2))
    table(f'rotating-{setting}-{occ}-m{mode}',rows)
    return rows
if __name__=='__main__':
    for arg in sys.argv[1:]:
        setting,occ,mode=arg.split(':')
        result=rotate(int(occ),setting,int(mode));print(arg,result[0]['polar'],result[0]['relative_balance'],flush=True)
