from bar_inputs import *
from bar_field import Field
import common_response as cr
def arrayfile(name,**fields):
    buff=io.BytesIO();np.savez_compressed(buff,**fields);put(name+'.npz',buff.getvalue())
def mean_field(level,mesh):
    src=Source();grav,wave,oracle=prep.restored(src,level,mesh);bg=wave.bg;bank=Field('extra')
    radii=bg.rad*bg.length;mean=bank.grid(radii,bg.mu,0)[0]
    wave.bare=wave.bare+wave.mult((mean-grav.central.value(radii)[:,None])/bg.vel**2)
    outer=prep.ms.OUTER;dr=bank.grid(np.array([outer]),np.array([0.]),0)[1][0,0]
    wave.ordinary_outer+=(dr-grav.central.value(outer,1))*UNIT
    ordinary=grav.sky(radii,bg.mu,2*bg.orders[-1])+mean-grav.central.value(radii)[:,None]
    return src,grav,wave,oracle,bank,ordinary
def solve(level,mesh):
    freeze();src,grav,wave,oracle,bank,ordinary=mean_field(level,mesh);bg=wave.bg
    prefix=f'{level}-{mesh}';rows=[];phys_mass=read(prep.ms.pre.MASS.parent,prep.ms.pre.MASS.stem)
    for occ in range(3):
        norm=prep.ms.pre.background(min(occ,1)).mass
        with np.load(PREV/f'{level}-mesh{mesh}-occ{occ}.npz') as pk:g=pk['g'].ravel()
        g,mu,stats=wave.solve(g,norm,anchor=occ==2)
        mass=float(phys_mass[min(occ,1)]['dark_mass'])*stats['norm']/norm
        g=g.reshape(bg.hshape);sky=(g/bg.sqrt[:,None])@bg.harm.T
        moments=sky**2@(bg.aw[:,None]*bg.harm)
        phi=bg.field((moments*(bg.sqrt/bg.rad)[:,None]).ravel())
        ham=ordinary/bg.vel**2+(phi[:-bg.count].reshape(bg.hshape)/(bg.sqrt*bg.rad)[:,None])@bg.harm.T
        halo=prep.ms.nfw(0);scale=(stats['outer_speed']**2/prep.ms.OUTER-wave.ordinary_outer/UNIT)/(-halo(prep.ms.OUTER,0.)[0])
        arrayfile(f'ground-{prefix}-{occ}',g=g,mu=mu,rad=bg.rad,weights=bg.mesh.weight,wave=sky,hamiltonian=ham,
                  energy=mu*bg.vel**2,edge=bg.mesh.edge,length=bg.length,vel=bg.vel,mass=stats['norm'],mass_msun=mass,
                  aw=bg.aw,angular=bg.mu,orders=bg.orders)
        rows.append(dict(occupation=occ,mass_msun=mass,nfw_scale=scale,ordinary_outer=wave.ordinary_outer,**stats))
    table('states-'+prefix,rows)
def evolve(level,mesh,keep):
    freeze();src,grav,wave,oracle,bank,ordinary=mean_field(level,mesh);bg=wave.bg;rows=[]
    pins=json.loads((cr.AXIS/'seal.json').read_bytes())['files']
    for occ in range(3):
        with np.load(HERE/f'ground-{level}-{mesh}-{occ}.npz') as pk:
            g=pk['g'];mu=float(pk['mu']);mass=float(pk['mass_msun'])
        op,err=cr.operators(wave,g.ravel(),mu,keep);kernel=None
        for history in prep.ms.MODELS:
            guard();name=cr.name(history,320,40,36,16)
            assert digest(cr.AXIS/name)==pins[name]
            with np.load(cr.AXIS/name) as pk:time,radii,vals=[pk[k] for k in ('time','radius','V')]
            if kernel is None:kernel=cr.source_map(op,radii,40);knots=radii
            assert np.array_equal(radii,knots)
            force=(vals.reshape(len(time),-1)@kernel)@op['u'];del vals
            for stride in (2,1):
                amp=cr.integrate(force[::stride],(time*bg.vel/bg.length)[::stride],op['sigma'])[-1].real
                x=np.einsum('lrk,lk->rl',op['block'],(op['u']@amp).reshape(bg.count,-1))
                sky=(g/bg.sqrt[:,None])@bg.harm.T;xs=(x/bg.sqrt[:,None])@bg.harm.T
                rho=(2*sky*xs)@(bg.aw[:,None]*bg.harm)/bg.rad[:,None]**2
                through=bg.sky_forces((rho*(bg.rad*bg.sqrt)[:,None]).ravel())[:,[1,0,2]].ravel();direct=op['sky']@amp
                diff=max(abs(through-direct));net=2*(x*g).sum()/(g*g).sum()
                assert diff<1e-11 and abs(net)<1e-11
                dm=(bg.mesh.inner[0]@(rho[:,0]*bg.rad**2))*mass/(g*g).sum()
                if stride==1:arrayfile(f'lmc-{level}-{mesh}-{occ}-{history}',x=x,rho=rho)
                rows.append(dict(occupation=occ,history=history,substeps=16//stride,inner_mass=dm,number_fraction=net,readout_diff=diff,
                                 **dict(zip(('r6','p6','r83','p83'),direct[[0,1,3,4]]))))
    table(f'lmc-{level}-{mesh}',rows)
if __name__=='__main__':
    level,mesh=sys.argv[1],int(sys.argv[2])
    if len(sys.argv)==3:solve(level,mesh)
    else:evolve(level,mesh,int(sys.argv[3]))
