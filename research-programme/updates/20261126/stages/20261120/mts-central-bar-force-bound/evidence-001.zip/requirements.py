from bar_inputs import *

def assess():
    freeze();upper=read(HERE,'central-ring-certificates');direct=read(HERE,'geometry-forces')
    bounds=[];scores=[];numerics=[]
    for occ in (0,1,2):
        rows=read(PREV,f'fine-mesh1-k64-occ{occ}-bands')
        for history in prep.ms.MODELS:
            for frame in ('site_minus_point','archive_accelerating'):
                for R in (6.,8.3):
                    for model in ('MTS','NFW'):
                        def pair(component):
                            sel=[v for v in rows if (v['history'],v['frame'],v['R'],v['model'],v['component'])==(history,frame,str(R),model,component)]
                            assert len(sel)==2
                            return sorted(sel,key=lambda v:-float(v['z']))
                        north,south=pair('polar')
                        def need(v):
                            return np.array([float(v['low']),float(v['high'])])-float(v['ordinary'])-float(v['direct'])
                        n,s=need(north),-need(south)[::-1]
                        parity=np.array([max(n[0],s[0]),min(n[1],s[1])]);even=(n+s)/2
                        predicted=.5*sum(mult*(float(v['stationary_dark'])+float(v['induced'])) for v,mult in ((north,1),(south,-1)))
                        for cert in upper:
                            if cert['sub']!='8192' or cert['R']!=str(R):continue
                            ceiling=float(cert['force_ceiling'])
                            bounds.append(dict(occupation=occ,history=history,frame=frame,R=R,halo=model,symmetry=cert['symmetry'],
                                paired_lower_for_even=even[0],paired_upper_for_even=even[1],if_even_only_lower=parity[0],
                                central_upper=ceiling,min_other_even_polar=even[0]-ceiling,saved_dark=predicted,
                                min_shortfall_holding_dark=even[0]-ceiling-predicted))
                        for shape in direct:
                            if shape['R']!=str(R) or shape['component'] not in ('polar','radial'):continue
                            group,component=shape['sample'],shape['component'];change=float(shape['change'])
                            for v in pair(component):
                                shift=change*(-1 if component=='polar' and float(v['z'])<0 else 1)
                                value=float(v['total'])+shift
                                scores.append(dict(occupation=occ,history=history,frame=frame,R=R,z=v['z'],component=component,
                                        halo=model,sample=group,shape=shape['model'],direct_shift=shift,frozen_dark_total=value,
                                        low=v['low'],high=v['high'],inside=float(v['low'])<=value<=float(v['high'])))
    for v in read(HERE,'independent-checks'):
        ans=float(v['selected']);ref=float(v['control']);delta=abs(ans-ref)
        numerics.append(dict(**v,absolute=delta,relative='' if abs(ans)<1e-12 else delta/abs(ans),within_relative='' if abs(ans)<1e-12 else delta<=2e-5*abs(ans)))
    table('exterior-signed-requirements',bounds);table('geometry-only-paired-bands',scores);table('direct-refinements',numerics)
if __name__=='__main__':assess()
