from bar_inputs import *
from fractions import Fraction
from math import isqrt

def run():
    freeze();stars=Source().stars
    radii=[Fraction.from_float(float(x)) for x in stars.bgrid]
    cols=[sum(Fraction.from_float(float(u)) for u in row) for row in stars.bcentral]
    assert min(cols)>=0 and radii[-1]==4
    grid=8192;scale=10**17;pi_upper=Fraction(355,113)
    factor=2*pi_upper*10**6*Fraction.from_float(float(G))*Fraction.from_float(float(UNIT))
    rows=[]
    for radius in (Fraction(6),Fraction(83,10)):
        z=Fraction(3,2);rr=radius**2+z*z
        rlow=Fraction(isqrt(int(rr*10**32)),10**16);assert rlow**2<=rr
        ceiling=[0,0]
        for ra,rb,sa,sb in zip(radii,radii[1:],cols,cols[1:]):
            step=(rb-ra)/grid;grad=(sb-sa)/grid
            for i in range(grid):
                left=ra+i*step;s=left+step;y=sa+i*grad
                mass_without_twopi=step*(left*(y+grad/2)+step*(y/2+grad/3))
                weight=factor*z/rlow*mass_without_twopi*s
                near=1/(radius-s)**3;far=1/(radius+s)**3
                for j,kernel in enumerate((near,(near-far)/2)):
                    term=weight*kernel*scale
                    ceiling[j]+=-(-term.numerator//term.denominator)
        for name,c in zip(('any_azimuth','half_turn'),ceiling):
            rows.append(dict(R=float(radius),symmetry=name,subdivisions=grid,upper_integer=c,denominator=scale,force_upper=c/scale))
    table('exact-rounded-upper',rows)
if __name__=='__main__':run()
