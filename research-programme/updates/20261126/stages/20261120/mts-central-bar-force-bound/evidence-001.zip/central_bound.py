from bar_inputs import *

def enclosure(stars,R,z,sub):
    rr=np.hypot(R,z);out=[]
    for symmetry in ('any_azimuth','half_turn'):
        low=0.;high=0.;mass=0.;witness=0.
        def kernel(s):
            near=(R-s)**-3
            horiz=near if symmetry=='any_azimuth' else .5*(near-(R+s)**-3)
            return G*UNIT*z/rr*s*horiz
        for a,b in zip(stars.bgrid[:-1],stars.bgrid[1:]):
            grid=np.linspace(a,b,sub+1);s,w=quadgrid(grid,3)
            dm=2*pi*1e6*w*s*stars.bulge_sigma(s).sum(axis=1);piece=dm.reshape(-1,3).sum(axis=1)
            low+=piece@kernel(grid[:-1]);high+=piece@kernel(grid[1:]);mass+=sum(piece)
            near=((R-s)**2+z*z)**-1.5;far=((R+s)**2+z*z)**-1.5
            witness+=G*UNIT*z/rr*(dm@(s*(near if symmetry=='any_azimuth' else .5*(near-far))))
        assert abs(mass/stars.bmass-1)<1e-12 and witness<high
        out.append(dict(R=R,z=z,sub=sub,symmetry=symmetry,central_mass=mass,integral_lower=low,force_ceiling=high,
                        in_plane_aligned_witness=witness))
    return out

def test():
    freeze();stars=Source().stars;out=[];sample=[]
    for R in (6.,8.3):
        for n in (128,1024,8192):out+=enclosure(stars,R,1.5,n)
        z=1.5;rr=np.hypot(R,z)
        for s in (.5,1.5,2.5,3.5,4.):
            angles=np.linspace(0,pi,161)[:,None];h=np.r_[0,np.geomspace(.001,100,150)][None,:];x=s*np.cos(angles)
            def point(x,h):
                return (z*x-R*h)/(rr*(R*R+s*s-2*R*x+(z-h)**2)**1.5)
            avg=(point(x,h)+point(x,-h))/2;pair=(avg+(point(-x,h)+point(-x,-h))/2)/2
            for label,arr,maximum in [('any_azimuth',avg,z*s/rr/(R-s)**3),('half_turn',pair,.5*z*s/rr*((R-s)**-3-(R+s)**-3))]:
                assert np.max(arr)<=maximum
                sample.append(dict(R=R,annulus=s,symmetry=label,sampled_max=np.max(arr),analytic_ceiling=maximum))
    table('central-ring-certificates',out);table('kernel-spot-checks',sample)
if __name__=='__main__':test()
