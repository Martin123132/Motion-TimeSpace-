from bar_inputs import *
from bar_field import Field
from scipy.special import gammainc
SITES=((6.,1.5),(8.3,1.5),(17.58,0.),(8.5,1.),(8.5,2.))

def ray_acc(R,z,model,axes,angle,order,mass):
    dist=np.hypot(R,z);phase=pi-angle
    centre=np.array([R*np.cos(phase),R*np.sin(phase),z]);radial=centre/dist
    az=np.array([-np.sin(phase),np.cos(phase),0.]);polar=np.cross(-radial,az)
    theta,weight=quadgrid([0,.015,.045,.11,.24,.5,1.,1.6,2.3,pi],order)
    azi=np.arange(8*order)*2*pi/(8*order);around=np.cos(azi)[:,None]*polar+np.sin(azi)[:,None]*az
    total=np.zeros(4)
    for t,wgt in zip(theta,weight):
        impact=dist*np.sin(t);near=dist*np.cos(t);begin=np.arcsinh(-near/impact);end=np.arcsinh((80-near)/impact)
        coord,w=quadgrid(np.linspace(begin,end,max(2,int(np.ceil((end-begin)/.7))+1)),order)
        travel=near+impact*np.sinh(coord);w*=impact*np.cosh(coord)
        dirs=-radial*np.cos(t)+around*np.sin(t)
        pos=centre+travel[None,:,None]*dirs[:,None,:]
        rho=density(model,axes,*pos.transpose(2,0,1));coeff=wgt*np.sin(t)*2*pi/len(azi)
        total[0]-=coeff*(rho@(w*travel)).sum()
        total[1:]+=coeff*((rho@w)@dirs)
    return G*mass*np.r_[total[0],UNIT*np.array([radial,polar,az])@total[1:]]

def ellipsoid(R,z,model,axes,angle,order,mass):
    t,w=rule(0,1,order);axes=np.array(axes);tau=t**-2-1
    denom=axes**2+tau[:,None];delta=np.prod(denom,axis=1)**.5
    phase=pi-angle;xyz=np.array([R*np.cos(phase),R*np.sin(phase),z])
    m=np.sqrt(np.sum(xyz**2/denom,axis=1))
    rho=np.exp(-m*m/2) if model=='G1' else np.exp(-m)
    factor=pi*G*mass*np.prod(axes)/norm(model,axes)
    wt=2*w/t**3/delta;pot=-2*factor*(wt@(rho if model=='G1' else (1+m)*rho))
    force=-2*factor*xyz*((wt*rho)@(1/denom))
    rad=xyz/np.hypot(R,z);az=np.array([-np.sin(phase),np.cos(phase),0]);polar=np.cross(-rad,az)
    return np.r_[pot,UNIT*np.array([rad,polar,az])@force]

def fractions(model,axes,order):
    mu,w=rule(0,1,order);phi,aw=rule(0,pi/2,order);aw/=pi/2
    fac=((1-mu**2)**2+mu**4)**.25 if model=='E3' else np.ones_like(mu)
    measure=w/fac**3;measure/=sum(measure)
    rr=np.sqrt(1-mu[:,None]**2)*np.sqrt((axes[0]*np.cos(phi))**2+(axes[1]*np.sin(phi))**2)/fac[:,None]
    tab=[]
    for r in (.5,1.5,2.5,3.5,4.,6.,8.3):
        limit=r/rr
        if model=='G1':cdf=gammainc(1.5,limit**2/2)
        elif model=='E2':cdf=gammainc(3,limit)
        else:
            u,wu=rule(0,1,48);cap=np.minimum(limit,48);v=cap[:,:,None]*u**2
            cdf=4/pi*cap*((v**2*k0(v))@(wu*u))
        tab.append((r,measure@cdf@aw))
    return tab

def conserved(R,z,stars,axes,angle,order):
    ss,ws=quadgrid(stars.bgrid,order);zs,wz=quadgrid([0,.05,.15,.35,.65,1.,2.,4.,8.,16.,32.],order)
    angle_phi,wp=rule(0,pi/2,order);wp=wp/(pi/2)
    rr=np.hypot(R,z);az=0.;native=np.zeros(4)
    obs=np.array([R,0,z]);target=np.array([[R/rr,0,z/rr],[z/rr,0,-R/rr],[0,1.,0]])
    for s,sw in zip(ss,ws):
        dm=sw*2*pi*s*1e6*stars.bulge_sigma(s).sum()
        weight=density('E3',axes,s*np.cos(angle_phi)[:,None],s*np.sin(angle_phi)[:,None],zs)*wp[:,None]*wz
        weight/=weight.sum()
        for side in (1,-1):
            for half in (0,pi):
                phi=side*angle_phi+half+angle
                for sign in (-1,1):
                    x=s*np.cos(phi)[:,None]-R;y=s*np.sin(phi)[:,None];v=sign*zs-z
                    dist=np.sqrt(x*x+y*y+v*v)
                    vec=np.array([np.sum(weight*a/dist**3) for a in (x,y,v)])
                    native+=G*dm/8*np.r_[-np.sum(weight/dist),UNIT*target@vec]
    return native

def main():
    freeze();src=Source();mass=src.stars.bmass;bank=Field('extra');assert abs(bank.mass/mass-1)<1e-11
    res=[];profiles=[];checks=[]
    keys=('potential','radial','polar','azimuthal')
    for tag,model,a,b,c,deg in GEOMETRIES:
        axes=(a,b,c);angle=np.deg2rad(deg)
        for r,f in fractions(model,axes,48):
            profiles.append(dict(sample=tag,model=model,R=r,inside_fraction=f,total_mass=mass))
        for R,z in SITES:
            v=ray_acc(R,z,model,axes,angle,14,mass)
            if model in ('G1','E2'):val=ellipsoid(R,z,model,axes,angle,112,mass);method='ellipsoid'
            else:val=ray_acc(R,z,model,axes,angle,20,mass);method='ray20'
            for key,item,control in zip(keys,val,v):
                checks.append(dict(sample=tag,model=model,R=R,z=z,component=key,method=method,selected=item,control=control))
            if tag=='all' and model=='E3':
                harmonics=bank.at(R,z,pi-angle)
                for j,key in enumerate(keys):
                    checks.append(dict(sample=tag,model=model,R=R,z=z,component=key,method='independent_harmonics',selected=val[j],control=sum(h[key] for h in harmonics)))
            rr=np.hypot(R,z);oldfield=G*mass*np.array([-1/rr,-UNIT/rr**2,0,0])
            for key,item,oldv in zip(keys,val,oldfield):
                res.append(dict(sample=tag,model=model,R=R,z=z,component=key,spherical=oldv,bar=item,change=item-oldv))
    for R,z in SITES:
        oldv=G*mass*np.array([-1/np.hypot(R,z),-UNIT/(R*R+z*z),0.,0.])
        vals=[conserved(R,z,src.stars,GEOMETRIES[0][2:5],np.deg2rad(GEOMETRIES[0][-1]),o) for o in (10,20)]
        for j,key in enumerate(keys):
            checks.append(dict(sample='rings_fixed',model='E3',R=R,z=z,component=key,method='conditional20',selected=vals[1][j],control=vals[0][j]))
            res.append(dict(sample='rings_fixed',model='E3',R=R,z=z,component=key,spherical=oldv[j],bar=vals[1][j],change=vals[1][j]-oldv[j]))
    table('geometry-forces',res);table('independent-checks',checks);table('geometry-mass-fractions',profiles)
if __name__=='__main__':main()
