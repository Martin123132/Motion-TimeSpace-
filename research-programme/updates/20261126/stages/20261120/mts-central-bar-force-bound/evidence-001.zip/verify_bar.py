from bar_forces import ray_acc,ellipsoid
from bar_inputs import *
from scipy.special import erf
from bar_comparison import run as compare

def inventory():
    guard();freeze()
    for base,fp in [(PREV,None),(ROOT/'mts-rotating-bar-wave-drive-20261119','bar-extra.npz')]:
        data=json.loads((base/'seal.json').read_bytes())['files']
        if fp:assert digest(base/fp)==data[fp]
        else:assert len(data)==84 and all(digest(base/n)==v for n,v in data.items())
    axis=ROOT/'mts-lmc-fixed-occupation-axisymmetric-20261119';files=json.loads((axis/'seal.json').read_bytes())['files']
    matched=[name for name in files if name.startswith('shell-') and name.endswith('-r320-l40-q36-t16.npz')]
    assert len(matched)==6 and all(digest(axis/name)==files[name] for name in matched)
def checks():
    inventory();mass=sum(prep.old.LENS.central);assert abs(Source().stars.bmass/mass-1)<1e-12
    for R,z in ((1.4,.6),(6.,1.5)):
        rad=np.hypot(R,z);axes=[.9]*3;frac=erf(rad/np.sqrt(2)/axes[0])-np.sqrt(2/pi)*rad/axes[0]*np.exp(-rad**2/2/axes[0]**2)
        expected=-G*mass*frac/rad**2*UNIT
        for fn,order in [(ray_acc,14),(ellipsoid,40)]:
            val=fn(R,z,'G1',axes,.39,order,mass)
            assert abs(val[1]/expected-1)<2e-5 and max(abs(val[2:]))<abs(expected)*1e-9
    numerical=read(HERE,'direct-refinements')
    assert len(numerical)==220 and all(v['within_relative']!='False' for v in numerical)
    cert=read(HERE,'exact-rounded-upper')
    vals={(v['R'],v['symmetry']):int(v['upper_integer'])/int(v['denominator']) for v in cert}
    assert .06968<vals['6.0','any_azimuth']<.06969 and .03098<vals['6.0','half_turn']<.031
    for v in read(HERE,'central-ring-certificates'):
        if v['sub']=='8192':assert float(v['in_plane_aligned_witness'])<float(v['force_ceiling'])<=vals[v['R'],v['symmetry']]
    support=read(HERE,'radial-support-threshold')
    assert len(support)==104 and all(float(v['remaining_even_after_most_generous'])>0 for v in support if v['R']=='6.0' and v['cut']=='4.5' and v['symmetry']=='half_turn')
    for occ in range(3):
        ground=read(HERE,'states-fine-1')[occ]
        assert float(ground['stationarity'])<5e-10 and (abs(float(ground['relative_number_change']))<1e-11 if occ<2 else abs(float(ground['outer_speed'])-224.03)<1e-7)
        with np.load(HERE/f'ground-fine-1-{occ}.npz') as pk:
            g=pk['g'];weight=pk['weights'];r=pk['rad'];assert abs((g*g).sum()/float(ground['norm'])-1)<1e-13
        for h in prep.ms.MODELS:
            with np.load(HERE/f'lmc-fine-1-{occ}-{h}.npz') as pk:
                net=weight@(pk['rho'][:,0]*r*r)/(g*g).sum();overlap=2*(g*pk['x']).sum()/(g*g).sum()
                assert max(abs(net),abs(overlap))<1e-12
        for m in range(2,33,2):
            probes=read(HERE,f'rotating-fine-{occ}-m{m}')
            assert len(probes)==3 and all(float(v['energy_open_kms2'])>0 and float(v['flux'])>0 and float(v['relative_balance'])<2e-5 and
                    max(abs(float(v[k])-float(v['green_'+k])) for k in ('radial','polar'))<1e-9 for v in probes)
        core=read(HERE,f'rotating-fine-{occ}-m2');far=read(HERE,f'rotating-edge-{occ}-m2')
        assert max(abs(float(v[k])-float(w[k])) for v,w in zip(core,far) for k in ('radial','polar'))<2e-8
    compare();rows=read(HERE,'full-paired-forces');summary=read(HERE,'full-paired-scores')
    assert len(rows)==576 and len(summary)==72 and all(v['unchanged']=='True' and v['inside']=='2' for v in summary)
    for v in rows:
        ans=sum(float(v[k]) for k in ('ordinary_before','bar_minus_sphere','dark_mean','LMC_direct','LMC_axis_wave','rotating_bar_wave'))
        assert abs(ans-float(v['total']))<1e-12 and (float(v['low'])<=ans<=float(v['high']))==(v['inside']=='True')
        assert (v['R']=='8.3' and v['component']=='polar')==(v['inside']=='True')
        if v['model']=='NFW':assert float(v['rotating_bar_wave'])==float(v['LMC_axis_wave'])==0
    return dict(old_stage_files=84,forcing_banks=6,direct_shape_variants=10,stationary_packets=6,LMC_packets=36,primary_signed_checks=len(rows),
                max_total_refinement=max(float(v['max_abs']) for v in summary),original_relative_tolerance=2e-5)

if __name__=='__main__':
    info=checks();files={f.name:digest(f) for f in sorted(HERE.iterdir()) if f.is_file() and f.name!='seal.json'}
    ledger=dict(checks=info,files=files)
    if sys.argv[1:]==['seal']:put('seal.json',(json.dumps(ledger,indent=2,sort_keys=True)+'\n').encode())
    else:assert not sys.argv[1:]
    assert json.loads((HERE/'seal.json').read_bytes())==ledger
    print(len(files),'files verified;',digest(HERE/'seal.json'),flush=True)
