from bar_inputs import *
from scipy.special import ellipk,ellipe

def old_disk_slice(stars,src,R,z,start,stop,order):
    edges=np.unique(np.r_[start,stop,stars.knots[(stars.knots>start)&(stars.knots<stop)],stars.bgrid[(stars.bgrid>start)&(stars.bgrid<stop)]])
    ss,sw=quadgrid(edges,order);zz,w=quadgrid(np.unique(np.r_[stars.axis,4.,6.,9.,15.,28.,48.]),4)
    zs=np.r_[zz,-zz];wts=np.tile(w,2);delta=z-zs;rad=np.hypot(R,z)
    profiles=np.array([src.starshape(zs,j) for j in range(4)])
    gr=0.;gz=0.
    for begin in range(0,len(ss),24):
        s=ss[begin:begin+24,None]
        density=stars.radial(s[:,0])@profiles
        den=(R+s)**2+delta**2;small=(R-s)**2+delta**2;par=4*R*s/den
        coeff=s*sw[begin:begin+24,None]*wts*density/np.sqrt(den)
        first=ellipk(par);second=ellipe(par)
        gr-=2*G/R*np.sum(coeff*(first+(R**2-s**2-delta**2)*second/small))
        gz-=4*G*np.sum(coeff*delta*second/small)
    return UNIT*(gr*z-gz*R)/rad

def span_bounds(stars,R,z,a,b,splits,sym):
    nodes=np.linspace(a,b,splits+1)
    cols=stars.raw_sigma(nodes)@stars.factors
    x=nodes[:-1];dx=np.diff(nodes);left=cols[:-1];right=cols[1:]
    dm=2*pi*1e6*dx*(x*(left+right)/2+dx*(left+2*right)/6)
    def kern(s):
        near=(R-s)**-3
        horiz=near if sym=='any_azimuth' else .5*(near-(R+s)**-3)
        return G*UNIT*z/np.hypot(R,z)*s*horiz
    return np.array([dm.sum(),dm@kern(nodes[:-1]),dm@kern(nodes[1:])])

def run():
    freeze();src=Source();stars=src.stars;rows=[];envelope=[]
    cuts=np.r_[4.,np.arange(4.125,5.501,.125)]
    for R in (6.,8.3):
        z=1.5;before=0.
        edges=np.unique(np.r_[stars.bgrid,stars.centres[stars.centres<=cuts[-1]],cuts]);data={}
        for lo,hi in zip(edges[:-1],edges[1:]):
            wide=old_disk_slice(stars,src,R,z,lo,hi,10);fine=old_disk_slice(stars,src,R,z,lo,hi,20)
            assert abs(wide-fine)<1e-8,(R,lo,hi,wide,fine)
            before+=fine
            for sym in ('any_azimuth','half_turn'):
                vals=span_bounds(stars,R,z,lo,hi,2048,sym)
                data[sym]=data.get(sym,np.zeros(3))+vals
                if hi not in cuts:continue
                mass,low,high=data[sym]
                rows.append(dict(R=R,cut=hi,symmetry=sym,stellar_mass=mass,max_integral_lower=low,max_even=high,old_inner_direct=before,
                                 max_increase=high-before))
    requirements=read(HERE,'exterior-signed-requirements')
    for certified in rows:
        for model in ('MTS','NFW'):
            sample=[r for r in requirements if float(r['R'])==certified['R'] and r['halo']==model and r['symmetry']==certified['symmetry']]
            premin=min(float(v['paired_lower_for_even']) for v in sample)
            need=min(float(v['paired_lower_for_even'])-float(v['saved_dark']) for v in sample)
            envelope.append(dict(R=certified['R'],cut=certified['cut'],model=model,symmetry=certified['symmetry'],maximum_increase=certified['max_increase'],
                                minimum_other_than_stars_gas_direct=premin-certified['max_increase'],if_saved_dark_held_remaining=need-certified['max_increase']))
    table('all-inner-stars-ceiling',rows);table('stellar-leverage-required',envelope)
if __name__=='__main__':run()
