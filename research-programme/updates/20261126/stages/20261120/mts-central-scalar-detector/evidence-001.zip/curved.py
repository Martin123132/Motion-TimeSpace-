"""Finite endpoint Jacobi and local material-stress measurements on the extended preparation."""
import sys
from decimal import getcontext
from math import fsum

from detector import HERE, PARENT, digest, family, guard, json, np, pins, table
from propagate import DURATION, shell_for, traced
from regular import configure
import endpoints as ep

LATE = HERE.parent/"mts-late-tide-refinement-20261120"
assert ep.HERE == LATE
assert digest(LATE/"seal.json") == "d45b046512700d79c3c2945f376883890eecb52743a05a5b15aeeb3dca265e1c"
for filename in ("endpoints.py","trace_stencil.py","regular.py"):
    assert digest(LATE/filename)==json.loads((LATE/"seal.json").read_bytes())["files"][filename]
for filename in ("propagate.py","launch_data.py"):
    assert digest(PARENT/filename)==pins[filename]


def measure(shell, epoch, change):
    start = shell.initial
    def components(time, diff):
        field = start if diff is None else start+diff
        tide = ep.fixed_tide(shell,start,diff)
        stress = family.sources(shell,time,field,np.zeros_like(field)).real
        field_stress = ep.convert(stress[[4,5,7]])
        tide[:,1] += field_stress[2,1]
        return np.concatenate((tide,field_stress))

    zero = components(0,None)
    after = components(epoch,change)
    window = ep.Window(shell,start,np.zeros_like(start),8)
    def optical(field):
        spline=window.spline(field)
        anti=spline.antiderivative()
        return spline(window.pos),anti(window.pos)-anti(0.)[:,None]

    metric0=ep.exp(start[0].real)
    metric,length=optical(metric0)
    dr=change[0].real
    m0=metric0[0]*np.expm1(dr[0])
    dmetric,dist=optical(family.pair(m0,metric0[1]*np.expm1(dr[0])+(metric0[0]+m0)*dr[1]))
    base=window.at(zero.astype(float))
    delta=window.at((after-zero).astype(float))
    nodes,weights=ep.leggauss(8)
    for width in family.FRACTIONS:
        half=ep.CENTER*width
        original=ep.weight(length[0],half)
        deriv=ep.weight(length[0],half,1)
        def shift(degree):
            return sum(wt*ep.weight(length[0]+.5*(node+1)*dist[0],half,degree)
                       for node,wt in zip(nodes,weights))*dist[0]/2
        dw,dt=shift(1),shift(2)
        for index,name in enumerate(("ricci","gauss","stress_dust","stress_heavy","stress_incident")):
            field=list(zip(base[index],delta[index]))
            cover=list(zip(metric,dmetric))
            effect=ep.secant((original,dw),cover[0],field[1])+ep.secant((original,dw),cover[1],field[0])
            effect+=ep.secant((deriv,dt),cover[0],(length[1],dist[1]),field[0])
            yield width,name,fsum(window.quad*effect)


def run(grid,steps,edge):
    getcontext().prec=40
    level=64
    for flag in (0,1):
        for seed in (0,1,-1):
            guard()
            for speed in (1,level):
                name=f"launch-L144-h5-q{speed}-off{flag}-s{seed}.npz"
                assert digest(PARENT/name)==pins[name]
            shell=shell_for(144,5,level,flag,seed,0,edge,grid)
            assert shell.faces[0]==0 and shell.faces[-1]==edge
            configure(shell,"trace6")
            count=2*level*steps
            dt=DURATION*np.sqrt(level)/count
            advance=traced.collar.stepper(shell,dt)
            change=np.zeros_like(shell.initial)
            rows=[]
            for idx in range(count):
                if idx%16==0:guard()
                change=advance(idx*dt,change)
                if (idx+1)%(count//4)==0:
                    assert np.isfinite(change).all()
                    fraction=(idx+1)/count
                    for width,label,value in measure(shell,(idx+1)*dt,change):
                        rows.append(dict(grid=grid,steps=steps,edge=edge,seed=seed,flag=flag,width=width,
                                         fraction=fraction,term=label,scaled_delta=level*value))
            table(f"central-n{grid}-p{steps}-L{edge}-off{flag}-s{seed}.csv",rows)
            print("saved",grid,steps,edge,flag,seed,flush=True)


if __name__=="__main__":
    run(*map(int,sys.argv[1:]))
