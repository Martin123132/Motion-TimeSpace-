"""Fixed proper-aperture Jacobi readout of the matched extended Newtonian formation."""
import csv
import hashlib
import json
import sys
from math import fsum
from pathlib import Path

HERE = Path(__file__).resolve().parent
PARENT = HERE.parent / "mts-exterior-incident-transfer-20261120"
PIN = "562bfccd88a761835ccdc8d1b05f781b0f1012b35e872cd52ac199d3f6e3e6be"


def digest(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


assert digest(PARENT/"seal.json") == PIN
pins = json.loads((PARENT/"seal.json").read_bytes())["files"]
for filename in ("local_stage.py", "formation-L144-h5-s1.npz", "formation-L144-h5-s-1.npz",
                 "prospective-members.csv", "prospective-q64.csv", "newton-L144-h5.csv"):
    assert digest(PARENT/filename) == pins[filename]
sys.path.insert(0, str(PARENT))
from local_stage import DURATION, family, guard as parent_guard, np, read, start_state
from balance import clock
from mesh import Mesh
from newton_history import windows
from scipy.optimize import brentq


def guard():
    parent_guard()
    assert not (HERE/"STOP-REQUESTED").exists()


def table(name, rows):
    import io
    stream = io.StringIO(newline="")
    writer = csv.DictWriter(stream, fieldnames=rows[0], lineterminator="\n")
    writer.writeheader()
    writer.writerows(rows)
    path = HERE/name
    content = stream.getvalue().encode()
    if path.exists():
        assert path.read_bytes() == content
    else:
        with path.open("xb") as handle:
            handle.write(content)


def aperture(kernel, targets, offset):
    return np.array([sum(weight*kernel.rows(float(radius*np.exp(-offset)))[0]
                         for radius, weight in zip(points, weights, strict=True))
                     for points, weights in targets])


def evolve(steps):
    sim = family.BalancedNative("heavy", 144, 720, False, "native36", clock.START+.00002)
    trace = clock.Traces("heavy", sim)
    sim.patch.coeff = lambda time: (float(trace.hubble(time-clock.START)), clock.SCALE*np.exp(time-clock.START))
    sim.ref.solution = lambda time: trace.histories(time-clock.START, "normal")
    offsets = trace.log_time([brentq(lambda time: float(trace.proper(time))-frac*DURATION,
                              0, trace.proper.x[-1], xtol=5e-16) if frac else 0. for frac in np.arange(steps+1)/steps])
    full = clock.Kernel(sim.mesh)
    inside = clock.Kernel(Mesh(6,30))
    np.testing.assert_array_equal(sim.mesh.r[:inside.mesh.size+1], inside.mesh.r)
    targets = windows(5)
    for points, weights in targets:
        assert max(points)<6 and abs(weights.sum()-1)<2e-15
    filters = {}
    for idx in range(0,steps+1,steps//4):
        filters[idx] = [(aperture(kernel,targets,offsets[idx])) for kernel in (full,inside)]
    beyond = full.rows(120.)[4]
    shell = full.rows(6.)[4]-beyond
    weight = sim.patch.p.coeff/clock.SCALE
    rows = {}
    for seed in (0,1,-1):
        start = start_state(sim,144,5,seed)
        for flag in (0,1):
            sim.patch.wave = not flag
            change = [np.zeros_like(arr) for arr in start]
            source = weight@start[1][flag]
            for idx, offset in enumerate(offsets):
                guard()
                if idx and idx in filters:
                    delta = (np.exp(-3*offset)*(weight@change[1][flag])
                             +np.expm1(-3*offset)*source)
                    for wi,width in enumerate((.15,.30)):
                        results = []
                        for axis, size in enumerate((sim.mesh.size,inside.mesh.size)):
                            now, old = filters[idx][axis][wi], filters[0][axis][wi]
                            results.append(fsum((now@delta[:size], (now-old)@source[:size])))
                        rows[seed,flag,idx/steps,width] = np.array([*results, beyond@delta,shell@delta])
                if idx==steps:
                    break
                step = offsets[idx+1]-offset
                slopes = []
                for stage, at in enumerate((0.,.5,.5,1.)):
                    state = tuple(base+(inc if stage==0 else inc+at*step*der)
                                  for base,inc,der in zip(start,change,slopes[-1] if stage else change,strict=True))
                    slopes.append(sim.rates(state, clock.START+offset+at*step))
                for inc, (first,second,third,last) in zip(change,zip(*slopes,strict=True),strict=True):
                    inc += step*(first+2*second+2*third+last)/6
    return rows


def main():
    low, high = (evolve(count) for count in (16,32))
    members = read(PARENT/"prospective-members.csv")
    facts = {}
    for row in members:
        key = tuple(float(row[label]) for label in ("seed","flag","fraction","left","right","steps"))
        assert key not in facts
        facts[key] = float(row["predicted"])
    branch, contrasts = [], []
    for seed in (1,-1):
        for frac in (.25,.5,.75,1.):
            for width in (.15,.30):
                def member(bank, flag):
                    return bank[seed,flag,frac,width]-bank[0,flag,frac,width]
                actual = member(high,0)-member(high,1)
                small = member(low,0)-member(low,1)
                for left in (5.,5.25):
                    for right in (120.5,121.):
                        for steps in (4,9):
                            predicted = []
                            for flag in (0,1):
                                whole,inner,tail,measured = member(high,flag)
                                remote = facts[seed,flag,frac,left,right,steps]
                                assembled = fsum((inner,tail,remote))
                                predicted.append(assembled)
                                branch.append(dict(seed=seed,flag=flag,fraction=frac,width=width,left=left,right=right,
                                    remote_steps=steps,full=whole,inner=inner,tail=tail,measured_band=measured,
                                    predicted_band=remote,assembled=assembled,member_ppm=(assembled-whole)/abs(whole)*1e6))
                            norm = abs(actual[0])
                            difference = fsum((predicted[0],-predicted[1]))
                            contrasts.append(dict(seed=seed,fraction=frac,width=width,left=left,right=right,remote_steps=steps,
                                full_newton=actual[0],full_predicted=difference,inner=actual[1],beyond120=actual[2],
                                measured_band=actual[3],band_fraction=actual[3]/actual[0],error_ppm=(difference-actual[0])/norm*1e6,
                                partition_ppm=(fsum(actual[1:])-actual[0])/norm*1e6,
                                time_shift_ppm=(actual[0]-small[0])/norm*1e6))
    assert len(branch)==256 and len(contrasts)==128
    table("branch-detector.csv",branch)
    table("signed-detector.csv",contrasts)
    for group,keys in ((branch,("member_ppm",)),(contrasts,("band_fraction","error_ppm","partition_ppm","time_shift_ppm"))):
        for key in keys:
            data=np.array([row[key] for row in group])
            print(key,min(data),max(data),flush=True)
    for key in ("error_ppm","partition_ppm","time_shift_ppm"):
        assert max(abs(row[key]) for row in contrasts)<20


if __name__=="__main__":
    main()
