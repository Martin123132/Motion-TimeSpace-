"""Verify exact saved record coverage, objective gates, static inputs and a write-once seal."""
import csv
import json
import math
import sys

from detector import HERE, PIN, digest, read


def verify():
    expected={"branch-detector.csv":256,"signed-detector.csv":128,"curved-members.csv":64,
              "curved-contrast.csv":32,"transverse-test.csv":32,"initial-transverse.csv":192,
              "manufactured-relative-acceleration.csv":4}
    for grid,steps,edge in ((120,4,3),(160,4,3),(160,8,3),(160,4,4)):
        for flag in (0,1):
            for seed in (0,1,-1):
                name=f"central-n{grid}-p{steps}-L{edge}-off{flag}-s{seed}.csv"
                expected[name]=40
                rows=read(HERE/name)
                assert {(float(row["width"]),float(row["fraction"]),row["term"]) for row in rows}=={
                    (width,frac,field) for width in (.15,.3) for frac in (.25,.5,.75,1.)
                    for field in ("ricci","gauss","stress_dust","stress_heavy","stress_incident")}
                assert all(math.isfinite(float(row["scaled_delta"])) for row in rows)
    assert {p.name for p in HERE.glob("*.csv")}==set(expected)
    for name,count in expected.items():
        rows=read(HERE/name)
        assert len(rows)==count and all(None not in row and None not in row.values() for row in rows)
    rows=read(HERE/"transverse-test.csv")
    assert {(int(r["seed"]),float(r["width"]),float(r["fraction"]),r["channel"]) for r in rows}=={
        (seed,width,frac,ch) for seed in (1,-1) for width in (.15,.3) for frac in (.25,.5,.75,1.) for ch in ("ricci","gauss")}
    assert all((abs(float(r["remaining_ppm"]))<=20)==(r["forecast_pass"]=="True") for r in rows)
    assert sum(r["controls_pass"]=="True" and r["forecast_pass"]=="True" for r in rows)==24
    assert sum(r["forecast_pass"]=="True" for r in rows)==28
    assert all((r["controls_pass"]=="True")==(float(r["width"])==.3 or float(r["fraction"])<=.5) for r in rows)
    assert all(abs(float(r["error_ppm"]))<1.056 and -.055<float(r["band_fraction"])<-.052 for r in read(HERE/"signed-detector.csv"))
    assert not any(HERE.glob("*.partial")) and not (HERE/"__pycache__").exists()
    files={p.name:digest(p) for p in sorted(HERE.iterdir()) if p.is_file() and p.name!="seal.json"}
    receipt={"parent":PIN,"csv_rows":sum(expected.values()),"files":files}
    path=HERE/"seal.json"
    if sys.argv[1:]==["seal"] and not path.exists():
        with path.open("x",encoding="utf8",newline="\n") as out:
            out.write(json.dumps(receipt,sort_keys=True,indent=2)+"\n")
    assert json.loads(path.read_bytes())==receipt
    print(len(files),"files;",sum(expected.values()),"data rows;",digest(path))


if __name__=="__main__":verify()
