"""Compare the two local curvature constructions; keep all absolute branch increments."""
import csv
from math import fsum

from detector import HERE, read, table

GROUPS=((120,4,3),(160,4,3),(160,8,3),(160,4,4))
CHANNELS=("ricci","gauss","stress_dust","stress_heavy","stress_incident")


def load_case(grid,time_order,outer):
    cases={}
    for flag in (0,1):
        for seed in (0,1,-1):
            packet=read(HERE/f"central-n{grid}-p{time_order}-L{outer}-off{flag}-s{seed}.csv")
            assert len(packet)==40
            for row in packet:
                assert (int(row["seed"]),int(row["flag"]),int(row["edge"]),int(row["grid"]),int(row["steps"]))==(seed,flag,outer,grid,time_order)
                key=(seed,flag,float(row["width"]),float(row["fraction"]),row["term"])
                assert key not in cases
                cases[key]=float(row["scaled_delta"])
    return cases


def assess():
    cases={params:load_case(*params) for params in GROUPS}
    sources=read(HERE/"signed-detector.csv")
    individual=read(HERE/"branch-detector.csv")
    report=[];branches=[]
    def chosen(row):
        return (float(row["left"]),float(row["right"]),int(row["remote_steps"]))==(5.,120.5,9)
    def branch(key,seed,flag,width,frac,ch):
        data=cases[key]
        return fsum((data[seed,flag,width,frac,ch],-data[0,flag,width,frac,ch]))
    for row in filter(chosen,individual):
        seed,flag,width,frac=int(row["seed"]),int(row["flag"]),float(row["width"]),float(row["fraction"])
        target=float(row["assembled"])
        reference=float(row["full"])
        for channel in ("ricci","gauss"):
            value=branch((160,8,3),seed,flag,width,frac,channel)
            branches.append(dict(seed=seed,flag=flag,width=width,fraction=frac,channel=channel,newton=reference,
                           longitudinal=target,curved=value,curved_minus_scalar_ppm=(value-target)/abs(reference)*1e6))
    for row in filter(chosen,sources):
        seed,width,frac=int(row["seed"]),float(row["width"]),float(row["fraction"])
        target=float(row["full_predicted"])
        reference=float(row["full_newton"])
        scale=abs(reference)*1e-6
        def signed(params,ch):
            return fsum((branch(params,seed,0,width,frac,ch),-branch(params,seed,1,width,frac,ch)))
        preferred=(160,8,3)
        for channel,other in (("ricci","gauss"),("gauss","ricci")):
            actual=signed(preferred,channel)
            selected=signed((160,4,3),channel)
            error=(actual-target)/scale
            controls=dict(grid_shift_ppm=(selected-signed((120,4,3),channel))/scale,
                          edge_shift_ppm=(selected-signed((160,4,4),channel))/scale,
                          time_shift_ppm=(actual-selected)/scale,
                          readout_split_ppm=(actual-signed(preferred,other))/scale)
            stresses={label:signed(preferred,label)/scale for label in CHANNELS[2:]}
            report.append(dict(seed=seed,width=width,fraction=frac,channel=channel,full_newton=reference,
                               longitudinal=target,curved=actual,curved_minus_scalar_ppm=error,**controls,**stresses,
                               controls_pass=max(map(abs,controls.values()))<=20,scalar_matches=abs(error)<=20))
    assert len(branches)==64 and len(report)==32
    table("curved-members.csv",branches);table("curved-contrast.csv",report)
    for frac in (.25,.5,.75,1.):
        group=[r for r in report if r["fraction"]==frac]
        print(frac,"controls",sum(r["controls_pass"] for r in group),"match",sum(r["scalar_matches"] for r in group))
        for key in ("curved_minus_scalar_ppm","grid_shift_ppm","edge_shift_ppm","time_shift_ppm","readout_split_ppm","stress_dust","stress_heavy","stress_incident"):
            print(key,min(r[key] for r in group),max(r[key] for r in group))


if __name__=="__main__":assess()
