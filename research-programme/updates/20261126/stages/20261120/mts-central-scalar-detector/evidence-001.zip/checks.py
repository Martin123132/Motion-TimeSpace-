"""Independent Cartesian free-space Green-function control and saved-evidence checks."""
import csv
import json
from collections import Counter
from pathlib import Path

from detector import HERE, Mesh, clock, digest, np, read, table, windows
from numpy.polynomial.legendre import leggauss


def control():
    mesh=Mesh(144,720)
    radius=mesh.r[1:]
    def source(x):
        return np.where((x>=6)&(x<=12),x*(x-6)**2*(12-x)**2,0.)
    amplitude=6**5/150
    field=source(radius)
    kernel=clock.Kernel(mesh)
    cos_theta,wm=leggauss(24)
    nodes,weights=leggauss(30)
    radii=9+3*nodes
    angle=2*np.pi*np.arange(48)/48
    sin_theta=np.sqrt(1-cos_theta**2)
    z=radii[:,None,None]*cos_theta[None,:,None]
    x=radii[:,None,None]*sin_theta[None,:,None]*np.cos(angle)
    quadrature=(3*weights*radii**2*source(radii))[:,None,None]*(wm*(3*cos_theta**2-1)/2)[None,:,None]/(-4*48)
    def potential(px,pz):
        return np.sum(quadrature/np.sqrt(radii[:,None,None]**2+px**2+pz**2-2*px*x-2*pz*z))
    output=[]
    for width,(points,mass) in zip((.15,.30),windows(5),strict=True):
        analytic=np.array([amplitude,-amplitude/2])
        for axis,expected in enumerate(analytic):
            step=.025
            measured=0.
            for coord,wt in zip(points,mass,strict=True):
                if axis==0:
                    left,right=potential(0,coord-step),potential(0,coord+step)
                else:
                    left,right=potential(-step,coord),potential(step,coord)
                measured-=wt*(left-2*potential(0,coord)+right)/step**2
            relative=abs(measured/expected-1)
            assert relative<2e-5
            output.append(dict(width=width,axis=("axial","transverse")[axis],expected=expected,computed=measured,relative=relative))
        assert max(abs(kernel.rows(pos)[0]@field/amplitude-1) for pos in points)<2e-12
    table("manufactured-relative-acceleration.csv",output)


def evidence():
    original=HERE.parent/"mts-lmc-fixed-occupation-axisymmetric-20261119"
    replay=HERE.parent/"mts-lmc-axisymmetric-retarded-replay-20261120"
    assert digest(original/"seal.json")=="a46d251285faaba640cea0288634284d6d3046a9693e934921a28936060c6f70"
    sealed=json.loads((original/"seal.json").read_bytes())
    assert digest(replay/"replay.json")=="ac3e29395d6ceeeca6a4dfb52528cf429c000dcdd981ddd14650ed9e95840cbf"
    rows=read(original/"final-force-comparison.csv")
    assert len(rows)==192
    counts=Counter()
    for row in rows:
        inside=float(row["low"])<=float(row["combined"])<=float(row["high"])
        assert inside==(row["inside"]=="True")== (float(row["R"])==8.3 and row["component"]=="polar")
        counts[row["tag"],row["history"],row["background"]]+=inside
    assert len(counts)==24 and set(counts.values())=={2}
    assert digest(original/"final-force-comparison.csv") in json.dumps(sealed)
    print("verified both models on all 192 saved LMC bands")


if __name__=="__main__":
    control();evidence()
