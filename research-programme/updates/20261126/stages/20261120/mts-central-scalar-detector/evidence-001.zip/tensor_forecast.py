"""Retarded mechanical transverse-stress forecast from independently saved formation initial data."""
from detector import HERE, PARENT, digest, family, guard, np, pins, read, start_state, table
from local_stage import sphere
from launch_data import inputs
import stress_projection as transverse
from causal_stress import RadialWave, probe
from states import jet


def initial_source(sim,seed,flag):
    state=start_state(sim,144,5,seed)
    ref,press,_=family.pressure(flag)
    grid,shapes,_=inputs(sim,state,144,5,flag,ref,press)
    data=transverse.material(shapes[0],grid.points,grid.evaluate,tuple(sim.mesh.grid(part) for part in state),flag)
    number,grad,speed=[jet(data[left],data[right]) for left,right in (("n","D"),("g","Dr"),("p","P"))]
    rho=ref["rh"][:,None,None]
    radial=(2/3)*family.angular((rho*number*speed**2).sum(axis=0))
    mixed=(rho*data["n"]*data["p"]*data["Pt"]).sum(axis=0)
    if not flag:
        idx=sim.patch.j
        factor=ref["rh"][idx]/(4*(ref["a"]*sim.patch.p.mass)**2)
        radial+=(2/3)*factor*family.angular(grad[idx]**2/number[idx])
        mixed+=factor*data["g"][idx]*data["D"][idx]/(data["n"][idx]*grid.points)
    return np.array([radial,mixed,np.zeros_like(mixed)]),grid


def create():
    sim=sphere(144,5)
    fields={}
    for flag in (0,1):
        for seed in (0,1,-1):
            guard()
            fields[seed,flag],base=initial_source(sim,seed,flag)
    rows=[]
    for edge in (36,72,144):
        grid=base if edge==144 else transverse.Element(sim.mesh,edge,len(base.t))
        for seed in (1,-1):
            for flag in (0,1):
                guard()
                raw=(fields[seed,flag]-fields[0,flag])[:,:grid.ne]
                projected=transverse.project(grid,raw)
                radial=RadialWave(grid,projected[0])
                for width in family.FRACTIONS:
                    lap=transverse.integrate(grid,projected,width,24)
                    for frac in (.25,.5,.75,1.):
                        travel=family.DURATION*8*frac
                        for order in (12,20):
                            delta,unity=probe(grid,radial,width,travel,order)
                            assert abs(unity-1)<2e-13
                            rows.append(dict(edge=edge,seed=seed,flag=flag,width=width,fraction=frac,order=order,
                                             mechanical_TT=delta/64,taylor=travel**2*lap/128))
    table("initial-transverse.csv",rows)


def score():
    raw=read(HERE/"initial-transverse.csv")
    data={(int(r["edge"]),int(r["seed"]),int(r["flag"]),float(r["width"]),float(r["fraction"]),int(r["order"])):float(r["mechanical_TT"]) for r in raw}
    assert len(data)==192
    output=[]
    for row in read(HERE/"curved-contrast.csv"):
        seed,width,frac=int(row["seed"]),float(row["width"]),float(row["fraction"])
        def field(edge,order):
            return data[edge,seed,0,width,frac,order]-data[edge,seed,1,width,frac,order]
        pred=field(144,20)
        norm=abs(float(row["full_newton"]))*1e-6
        left=float(row["curved_minus_scalar_ppm"])-pred/norm
        output.append(dict(seed=seed,width=width,fraction=frac,channel=row["channel"],tt=pred,tt_ppm=pred/norm,
                           radius_spread_ppm=max(abs(field(edge,20)-pred) for edge in (36,72))/norm,
                           order_shift_ppm=(field(144,12)-pred)/norm,raw_ppm=row["curved_minus_scalar_ppm"],
                           remaining_ppm=left,controls_pass=row["controls_pass"],forecast_pass=abs(left)<=20))
    table("transverse-test.csv",output)
    for frac in (.25,.5,.75,1.):
        selected=[r for r in output if r["fraction"]==frac]
        print(frac,"pass",sum(r["forecast_pass"] for r in selected),*(tuple(round(fn(r[k] for r in selected),4) for fn in (min,max))
            for k in ("tt_ppm","remaining_ppm","radius_spread_ppm","order_shift_ppm")))


if __name__=="__main__":
    import sys
    if sys.argv[1:]==["source"]:create()
    elif sys.argv[1:]==["score"]:score()
    else:raise ValueError("choose source or score")
