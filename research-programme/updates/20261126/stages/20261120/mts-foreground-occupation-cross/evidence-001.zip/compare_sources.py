from collections import defaultdict
from stage_io import *

def index(rows,key):
    data={key(r):r for r in rows}
    assert len(data)==len(rows)
    return data
def collect():
    guard()
    er=index(read(HERE,"equilibria"),lambda r:r["branch"])
    common=[r for r in read(EXT,"common-sky-k96") if r["t"]=="1" and r["frame"]=="archive_accelerating" and r["policy"]=="direct_plus_m0"]
    bare=[r for r in read(BHOST,"common-forces") if r["frame"]=="archive_accelerating" and r["branch"]=="evolved_wave"]
    key=lambda r:(r["R"],r["z"],r["component"])
    ext=index(common,lambda r:(int(r["occupation"]),r["history"],r["model"],*key(r)))
    sim=index(bare,lambda r:(int(r["occupation"]),r["model"],*key(r)))
    grid=[key(r) for r in common if r["occupation"]=="0" and r["history"]==SERIES[0] and r["model"]=="MTS"]
    assert len(grid)==8 and len(set(grid))==8
    hi_b=read(BHOST,"grounds-1")
    states={label:index(read(HERE,f"history-{label}-k64"),lambda r:(r["history"],r["component"])) for label in er if not label.startswith("tangent")}
    signed=[];split=[];bounded=[];targets=[]
    def make(fg,nr,history,site,bary,stat,axis,direct,lo,hi,model):
        total=bary+stat+axis+direct
        return dict(foreground=fg,occupation=nr,history=history,R=site[0],z=site[1],component=site[2],model=model,ordinary=bary,dark=stat,wave_m0=axis,direct_LMC=direct,total=total,low=lo,high=hi,inside=lo<=total<=hi)
    for idx in range(12):
        meta=read(LAST,f"host-ground-{idx}")[0];hist=meta["history"];rep=meta["representation"]
        host_rows=index([r for r in read(LAST,f"matched-axis-only-{idx}-k64") if r["frame"]=="archive_accelerating" and r["initial"]=="zero"],key)
        low="low"+str(idx)
        assert abs(float(meta["frozen_mass"])/float(er[low]["mass_msun"])-1)<1e-9
        for site in grid:
            radius,z,cmp=site;sgn=-1 if float(z)<0 and cmp=="polar" else 1
            col=("inner_" if radius=="6.0" else "outer_")+cmp
            data=host_rows[site];ref=ext[0,hist,"MTS",*site];simrow=sim[0,hist,*site]
            stara=float(ref["ordinary"]);starb=float(simrow["ordinary"]);d=float(ref["satellite_direct"])
            lo,hi=float(ref["low"]),float(ref["high"])
            assert d==float(simrow["direct_in_frame"]) and (lo,hi)==(float(data["low"]),float(data["high"]))
            shape=float(ext[0,hist,"NFW",*site]["stationary_dark"])/float(read(EXT,"equilibria-fine-1-o0-q8")[-1]["anchor_inward"])
            for occ in (0,1):
                ref=ext[occ,hist,"MTS",*site];simrow=sim[occ,hist,*site];nfw=ext[occ,hist,"NFW",*site]
                corners=dict(AH=(stara,float(ref["stationary_dark"]),float(ref["induced_m0"]),float(nfw["stationary_dark"])),
                             BH=(starb,float(simrow["ground"]),float(simrow["induced"]),shape*float(hi_b[occ]["outer_wave"])),
                             AL=(stara,sgn*float(er[low][col]),sgn*float(states[low][hist,col]["induced"]),shape*float(er[low]["anchor_inward"])),
                             BL=(starb,float(data["frozen"])-starb-d,float(data["induced_m0"]),shape*float(meta["matched_dark"])))
                for model in ("MTS","static_NFW"):
                    fields={}
                    for cell,(bary,dark,sat,nfwval) in corners.items():
                        row=make(cell[0],cell[1],hist,site,bary,dark if model=="MTS" else nfwval,sat if model=="MTS" else 0.,d,lo,hi,model)
                        row.update(case=idx,representation=rep,high_occupation=occ)
                        signed.append(row);fields[cell]=row
                    assert abs(fields["BL"]["total"]-float(data["total" if model=="MTS" else "static_NFW"]))<1e-11
                    assert abs(fields["AH"]["total"]-float(ext[occ,hist,"MTS" if model=="MTS" else "NFW",*site]["total"]))<1e-11
                    def decompose(key):
                        ah,bh,al,bl=[fields[v][key] for v in ("AH","BH","AL","BL")]
                        return .5*(bh-ah+bl-al),.5*(al-ah+bl-bh),bl-bh-al+ah
                    direct=starb-stara;reshape,number,interaction=decompose("dark")
                    drive=fields["BL"]["wave_m0"]-fields["AH"]["wave_m0"]
                    delta=fields["BL"]["total"]-fields["AH"]["total"]
                    assert abs(direct+reshape+number+drive-delta)<1e-12
                    split.append(dict(case=idx,representation=rep,high_occupation=occ,model=model,history=hist,R=radius,z=z,component=cmp,
                                  direct_ordinary_change=direct,stationary_foreground_change=reshape,stationary_occupation_change=number,
                                  interaction_already_allocated=interaction,foreground_at_high_N=fields["BH"]["dark"]-fields["AH"]["dark"],
                                  foreground_at_low_N=fields["BL"]["dark"]-fields["AL"]["dark"],induced_change=drive,total_change=delta))
            if rep!="multipole":continue
            for label in ("anchorA","cut1","cut2","anchorB"):
                state=er[label];frac=float(state["fraction"]);bary=stara+frac*(starb-stara)
                for model in ("MTS","static_NFW"):
                    dark=sgn*float(state[col]) if model=="MTS" else shape*float(state["anchor_inward"])
                    sat=sgn*float(states[label][hist,col]["induced"]) if model=="MTS" else 0.
                    row=make(label,"outer224.03",hist,site,bary,dark,sat,d,lo,hi,model);row["fraction"]=frac;bounded.append(row)
                    if label=="anchorB" and model=="MTS":assert abs(row["total"]-float(sim[2,hist,*site]["total"]))<1e-7
    for width in (1,2):
        for hist in SERIES:
            def need(label):
                north,south=sorted([r for r in bounded if r["model"]=="MTS" and r["foreground"]==label and r["history"]==hist and r["R"]=="6.0" and r["component"]=="polar"],key=lambda r:-float(r["z"]))
                minimum=.5*(north["low"]-south["high"])
                ordcomp=.5*(north["ordinary"]-south["ordinary"])
                head=.5*(north["direct_LMC"]-south["direct_LMC"])
                return minimum,ordcomp,head,.5*(north["dark"]+north["wave_m0"]-south["dark"]-south["wave_m0"])
            lim,ba,dd,_=need("anchorA");_,bb,_,_=need("anchorB");assert bb>ba
            _,bm,_,dark=need(f"cut{width}")
            fmin=(lim-ba-dd)/(bb-ba);bound=lim-bm-dd
            targets.append(dict(width=width,history=hist,required_even_total=lim,largest_ordinary=bm,direct_satellite=dd,
                           required_other_even_over_whole_interval=bound,spherical_min_native_fraction=fmin,
                           actual_endpoint_wave=dark,endpoint_shortfall=bound-dark))
    table("crossed-forces",signed);table("force-attribution",split);table("census-limited-forces",bounded);table("polar-floor",targets)
    scores=[]
    for subset in (signed,bounded):
        panels=defaultdict(list)
        ids=["foreground","occupation","model","history"]+(["case","representation","high_occupation"] if subset is signed else [])
        for row in subset:panels[tuple(row[k] for k in ids)].append(row)
        for group,values in panels.items():
            assert len(values)==8
            record=dict(zip(ids,group))
            scores.append(dict(case=record.get("case",""),representation=record.get("representation",""),high_occupation=record.get("high_occupation",""),
                           foreground=record["foreground"],occupation=record["occupation"],model=record["model"],history=record["history"],
                           count=sum(r["inside"] for r in values),misses=";".join(r["R"]+"/"+r["z"]+"/"+r["component"] for r in values if not r["inside"])))
    table("panels",scores)
if __name__=="__main__":collect()
