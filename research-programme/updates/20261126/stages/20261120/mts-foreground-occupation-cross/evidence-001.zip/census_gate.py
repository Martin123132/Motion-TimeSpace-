from stage_io import *
from scipy.integrate import quad
from signed_potential import census,supply

def source_value(radius,height):
    stars=census().stars
    alpha=np.deg2rad(29.4)
    central=lambda z:stars.bmass*ls.old.density("E3",(.67,.29,.27),radius*np.cos(alpha),radius*np.sin(alpha),z)
    frac=supply(np.array([radius]))[0];frac=frac/frac.sum()
    heights=height!=0
    value=census().disk(np.array(radius),np.array(height),column=heights)
    value=value if heights else value*1e-9
    factor=1e-6 if heights else 1e-9
    central_part=2*quad(central,0,height,epsabs=1e-8)[0] if heights else central(0)
    donor=sum(frac[j]*census().starshape(np.array(height),j,column=heights) for j in range(4))
    extra=0.
    for key in ls.S22:
        new=ls.raw(key,0,radius,-ls.angle(key))
        vertical=np.tanh(height/ls.height(key)) if heights else ls.zshape(key,0.)
        extra+=.4*(new*vertical-ls.avg(key,0,np.array(radius),128)*donor)
    return float(value+factor*(central_part+extra))
def run():
    archive=[r for r in read(AP,"direct-apertures") if r["tag"]=="archive" and r["R"]=="8.3" and r["census"]]
    rows=[];bounds=[]
    for width in (1,2):
        low,high=0.,1.
        for row in archive:
            height={"plane":0.,"slab1100":1.1,"full":100.}[row["aperture"]]
            lhs=source_value(8.3,height);rhs=float(row["model"])
            obs=float(row["census"]);sigma=float(row["quoted_width"]);slope=rhs-lhs
            a,b=sorted([(obs-width*sigma-lhs)/slope,(obs+width*sigma-lhs)/slope])
            low=max(low,a);high=min(high,b)
            rows.append(dict(width=width,test=row["aperture"],measured_source=lhs,native_source=rhs,census=obs,quoted_width=sigma,allowed_low=a,allowed_high=b))
        assert 0==low<high<1
        key=next(r["test"] for r in rows if r["width"]==width and abs(r["allowed_high"]-high)<1e-12)
        bounds.append(dict(width=width,low=low,high=high,limiting=key))
    table("census",rows);table("fractions",bounds)
if __name__=="__main__":run()
