from itertools import product
from math import atan2,degrees,hypot,sqrt
from stage_io import *

HEIGHT=1.5
def direction(radius,ar,polar):
    return degrees(atan2(polar,-ar))
def q2(radius,ar,polar):
    numerator=(radius*ar+HEIGHT*polar)*HEIGHT/radius
    denominator=HEIGHT*ar-radius*polar
    return (numerator,denominator)
def box(records,f):
    comp={}
    for key in ("radial","polar"):
        sites=[s for s in records if s["component"]==key]
        lower=[];upper=[]
        for zval in ("1.5","-1.5"):
            pair={s["foreground"]:s for s in sites if s["z"]==zval}
            a,b=pair["anchorA"],pair["anchorB"]
            direct=float(a["direct_LMC"]);assert direct==float(b["direct_LMC"])
            reference=float(a["ordinary"])*(1-f)+float(b["ordinary"])*f+direct
            sign=-1 if key=="polar" and zval.startswith("-") else 1
            interval=sorted([sign*(float(a[k])-reference) for k in ("low","high")])
            lower.append(interval[0]);upper.append(interval[1])
        comp[key]=(.5*sum(lower),.5*sum(upper))
    return comp
def run():
    data=[r for r in read(HERE,"census-limited-forces") if r["model"]=="MTS"]
    results=[];scored=[]
    for height_ratio,axis_ratio in product((.15,.25),(.65,1.,1.2)):
        radius=HEIGHT/height_ratio
        cylindrical=-1.;vertical=cylindrical*height_ratio/(axis_ratio**2)
        ar=(radius*cylindrical+HEIGHT*vertical)/hypot(radius,HEIGHT);pol=(HEIGHT*cylindrical-radius*vertical)/hypot(radius,HEIGHT)
        top,bottom=q2(radius,ar,pol);assert abs(top/bottom-axis_ratio**2)<1e-14
    for band in read(HERE,"fractions"):
        fmax=float(band["high"])
        for hist,rstr in product(SERIES,("6.0","8.3")):
            radius=float(rstr)
            records=[r for r in data if (r["history"],r["R"])==(hist,rstr)]
            points=[]
            for f in (0.,fmax):
                b=box(records,f)
                for ar,polar in product(b["radial"],b["polar"]):
                    assert ar<0
                    top,bottom=q2(radius,ar,polar)
                    points.append((direction(radius,ar,polar),top,bottom,f,ar,polar))
            low,high=min(v[0] for v in points),max(v[0] for v in points)
            down=all(v[1]<0 and v[2]<0 for v in points)
            ratios=[sqrt(v[1]/v[2]) for v in points] if down else []
            results.append(dict(width=band["width"],history=hist,R=radius,lowest_angle_deg=low,highest_angle_deg=high,
                                finite_positive_q=down,q_min=min(ratios) if down else "",q_max=max(ratios) if down else "",
                                min_angle_fraction=min(points)[3],max_angle_fraction=max(points)[3],spherical_permitted=low<=0<=high))
            for f in np.linspace(0,fmax,33):
                b=box(records,float(f))
                for ar,polar in product(b["radial"],b["polar"]):
                    ang=direction(radius,ar,polar);assert low-1e-12<=ang<=high+1e-12
                    if down:
                        top,bottom=q2(radius,ar,polar);assert min(ratios)-1e-12<=sqrt(top/bottom)<=max(ratios)+1e-12
            for label in ["anchorA",f"cut{band['width']}"]:
                sample=[r for r in records if r["foreground"]==label and r["z"]=="1.5"]
                force={r["component"]:float(r["dark"])+float(r["wave_m0"]) for r in sample}
                ang=direction(radius,force["radial"],force["polar"]);top,bottom=q2(radius,force["radial"],force["polar"])
                f=float(sample[0]["fraction"]);fixed=box(records,f)
                angles=[direction(radius,rad,pol) for rad,pol in product(fixed["radial"],fixed["polar"])]
                scored.append(dict(width=band["width"],history=hist,R=radius,branch=label,wave_angle_deg=ang,wave_local_q=sqrt(top/bottom),
                                   min_at_fixed_fraction=min(angles),max_at_fixed_fraction=max(angles),angle_deficit_deg=max(0,min(angles)-ang,ang-max(angles)),
                                   spherical_angle_deg=0.,spherical_deficit_deg=max(0,min(angles),-max(angles))))
    table("direction-envelope",results);table("direction-predictions",scored)
if __name__=="__main__":run()
