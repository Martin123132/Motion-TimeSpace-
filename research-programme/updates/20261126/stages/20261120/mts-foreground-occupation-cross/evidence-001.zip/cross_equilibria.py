from stage_io import *

def factor(wave,g,mu):
    return splu(jacobian(wave,g,mu))
def responses(wave,g,mu,change):
    solve=factor(wave,g,mu);bg=wave.bg
    rhs=np.zeros((g.size+bg.grav.shape[0]+1,2))
    rhs[:g.size,0]=-(change@g);rhs[-1,1]=.5
    solutions=solve.solve(rhs)
    angular=sky_of(bg,g);terms=[]
    for col in (0,1):
        dx=solutions[:g.size,col]
        assert abs(2*g@dx-col)<1e-9
        moment=(2*angular*sky_of(bg,dx))@wave.weights
        terms.append(np.einsum("erl,rl->e",wave.rows,moment))
    return terms
def settle(wave,g,mu,number,outer):
    for step in range(14):
        bg=wave.bg;sky,moment,src,ham=wave.fields(g)
        forces=np.einsum("erl,rl->e",wave.rows,moment)
        resid=ham@g-mu*g
        loss=.5*(g@g-number) if outer is None else forces[-1]-outer
        if np.linalg.norm(resid)<1e-10 and abs(loss)<1e-12:return g,mu,forces,step
        matrix=jacobian(wave,g,mu)
        if outer is not None:
            last=2*np.einsum("rl,ul,ru,u,uk->rk",wave.rows[-1],bg.harm,sky,bg.aw,bg.harm,optimize=True)/bg.sqrt[:,None]
            row=sparse.csc_matrix(np.r_[last.ravel(),np.zeros(bg.grav.shape[0]+1)][None,:])
            matrix=sparse.vstack([matrix[:-1],row],format="csc")
        delta=splu(matrix).solve(np.r_[-resid,np.zeros(bg.grav.shape[0]),-loss])
        g=g+delta[:len(g)];mu+=delta[-1]
    raise RuntimeError("stationary or anchor residual did not converge")
def run():
    guard();wave,initial,chemical,_,mass=restored(1,8,0,True);bg=wave.bg
    native=common_wave.Wave(1);assert np.array_equal(bg.rad,native.bg.rad) and np.array_equal(bg.orders,native.bg.orders)
    original=wave.bare;change=native.bare-original
    startnorm=initial@initial;factor_mass=mass/startnorm
    ordinary_a,ordinary_b=inputs();slope=ordinary_b-ordinary_a
    cuts=read(HERE,"fractions")
    cases=[]
    for idx in range(12):
        with np.load(LAST/f"host-field-{idx}.npz") as data:norm=np.sum(data["g"]**2)
        cases.append((f"low{idx}",0.,norm,None))
    cases.extend([("anchorA",0.,None,None),("anchorB",1.,None,None)])
    for i,row in enumerate(cuts):cases.append((f"cut{i+1}",float(row["high"]),None,None))
    mid=float(cuts[0]["high"])
    cases.extend([("tangent_minus",mid-.0005,None,None),("tangent_plus",mid+.0005,None,None)])
    rows=[];derivs=[];reference=initial
    for label,frac,number,_ in cases:
        guard();wave.bare=original+frac*change
        ordinary=ordinary_a+frac*slope
        dark=None if number is not None else 224.03**2/17.58*UNIT-ordinary
        g,mu,values,steps=settle(wave,initial,chemical,number,dark)
        independent,_=diagnostics(wave,g)
        overlap=float((g@reference)/np.sqrt((g@g)*startnorm))
        assert overlap>.9 and max(abs(values-independent))<1e-10
        if label=="anchorB":
            assert abs((g@g)*factor_mass/float(read(BHOST,"grounds-1")[2]["mass_msun"])-1)<1e-9
        rows.append(dict(branch=label,fraction=frac,mass_msun=(g@g)*factor_mass,number=g@g,mu=mu,steps=steps,
                    residual=np.linalg.norm(wave.fields(g)[3]@g-mu*g),overlap=overlap,
                    speed=np.sqrt((ordinary+values[-1])*17.58/UNIT),**dict(zip(SITES,values))))
        if not label.startswith("tangent"):
            packet("state-"+label,ground=g,chemical=mu,number=g@g,fraction=frac)
        if label.startswith("cut") or label.startswith("anchor"):
            left,right=responses(wave,g,mu,change)
            dnumber=-(slope+left[-1])/right[-1]
            for idx,key in enumerate(SITES):
                derivs.append(dict(branch=label,component=key,dark_dfrac_fixedN=left[idx],dark_dN=right[idx],
                              dN_dfrac_fixedspeed=dnumber,dark_dfrac_fixedspeed=left[idx]+right[idx]*dnumber))
        print(label,"stationary",flush=True)
    table("equilibria",rows);table("calibration-tangent",derivs)
    by={r["branch"]:r for r in rows};controls=[]
    for r in derivs:
        if r["branch"]!="cut1":continue
        key=r["component"];num=(by["tangent_plus"][key]-by["tangent_minus"][key])/.001
        exact=r["dark_dfrac_fixedspeed"];err=abs(num/exact-1)
        assert err<2e-5,(key,err)
        controls.append(dict(component=key,tangent=exact,finite_difference=num,relative_error=err))
    table("tangent-checks",controls)
if __name__=="__main__":run()
