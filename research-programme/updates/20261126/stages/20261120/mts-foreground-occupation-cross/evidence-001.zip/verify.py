from stage_io import *
import ast
from collections import Counter,defaultdict
from math import hypot,sqrt

def pinned(folder,pin,names):
    assert sha(folder/"seal.json")==pin
    files=json.loads((folder/"seal.json").read_bytes())["files"]
    if names is None:names=files
    for name in names:assert sha(folder/name)==files[name],name
    return len(names)
def verify():
    guard()
    archives={
        LAST.name:pinned(LAST,"13039baa8a9fb0a8bbc1b2b16fb60cafcb47af67a143981595c68185fa6d7ecc",None),
        EXT.name:pinned(EXT,"04d68be63540458fe12b4016eb0c1f860321cbef03c662c8521b8f611359453a",["common-sky-k96.csv","state-fine-1-o0-q8.npz","equilibria-fine-1-o0-q8.csv","branch_state.py","wave_transfer.py","signed_potential.py","new_satellite.py"]),
        AP.name:pinned(AP,"6a97d405f60bc068baa14a141a29e0367ca0204bae21bd04b46c8595c04802ac",["direct-apertures.csv","source-receipts.csv","sources/inventory.pdf"]),
        BHOST.name:pinned(BHOST,"b4108a60a498b169a0c4242bf7f689b3c64722dfccb7641020e99134461b265a",["common-forces.csv","grounds-1.csv","common_wave.py"]+[f"source/{h}/fixed-ordinary.ini" for h in SERIES]),
        cr.AXIS.name:pinned(cr.AXIS,"a46d251285faaba640cea0288634284d6d3046a9693e934921a28936060c6f70",[cr.name(h,320,40,36,16) for h in SERIES]),
        "rotation":pinned(ROOT/"mts-calibrated-disk-wave-20261119","9cd7c6a1e2c1380a4df35f7edea8ad2adc4c853c67b8e380bce1203c9d373329",["rotation.csv"])}
    for path in HERE.glob("*.py"):ast.parse(path.read_text(encoding="utf-8"))
    for path in HERE.glob("*.csv"):
        with path.open(newline="",encoding="utf-8") as src:
            rows=list(csv.reader(src))
        assert len(rows)>1 and len(set(rows[0]))==len(rows[0]) and all(len(r)==len(rows[0]) for r in rows)
        assert not any(v.lower() in ("nan","inf","-inf") for r in rows[1:] for v in r)
    query=lambda name:read(HERE,name)
    cross=query("crossed-forces");assert len(cross)==12*2*4*8*2
    census=query("census-limited-forces");assert len(census)==4*6*8*2
    spread=query("anchor-width-forces");assert len(spread)==6*6*8*2
    for r in cross+census+spread:
        assert (float(r["low"])<=float(r["total"])<=float(r["high"]))==(r["inside"]=="True")
    for r in cross+census:
        assert abs(float(r["total"])-sum(float(r[k]) for k in ("ordinary","dark","wave_m0","direct_LMC")))<1e-12
    grouped=defaultdict(list)
    for r in cross:grouped[tuple(r[k] for k in ("case","history","representation","high_occupation","R","z","component","model"))].append(r)
    attrib=query("force-attribution")
    for r in attrib:
        group=grouped[tuple(r[k] for k in ("case","history","representation","high_occupation","R","z","component","model"))]
        vals={(q["foreground"],q["occupation"]):q for q in group};assert len(group)==len(vals)==4
        assert len(set(x["direct_LMC"] for x in group))==1
        delta=float(vals["B","L"]["total"])-float(vals["A","H"]["total"])
        assert abs(sum(float(r[k]) for k in ("direct_ordinary_change","stationary_foreground_change","stationary_occupation_change","induced_change"))-delta)<1e-12
    tchecks=query("tangent-checks");assert max(float(r["relative_error"]) for r in tchecks)<2e-5
    for r in query("stream-observables"):
        z,radius,fr,fz=map(float,(r["Z"],r["R"],r["FR_kms_Myr"],r["FZ_kms_Myr"]))
        assert abs(sqrt(z/radius*fr/fz)-float(r["q_total"]))<1e-12
        ispal=r["stream"]=="Pal5"
        assert (radius,z)==((8.4,16.8) if ispal else (12.5,6.675))
        q,cr0,cz0=(.94,.80,1.82) if ispal else (.95,2.51,1.47)
        assert abs(q*q*(fr+cr0)+z/radius*(fz+cz0)-float(r["strength"]))<1e-12
    for row in query("pal5-shell-budget"):
        ceiling,asym,term,actual=map(float,(row[k] for k in ("spherical_empty_shell_ceiling","combined_asphericity","shell_penalty","strength")))
        assert abs(ceiling+asym-term-actual)<1e-11 and term>0
    width=query("joint-shell-width")
    assert 1<float(width[1]["rectangular_factor"])<2 and abs(float(width[1]["ceiling_minus_Pal5_lower"]))<1e-10
    assert any(float(r["actual_minus_threshold"])>0 for r in query("pal5-shell-budget") if r["widths"]=="2")
    for label in ("cut1","cut2","anchorA"):
        for branch in ("lower","upper"):
            sel=[r for r in query("anchor-width-streams") if r["branch"]==f"{label}_{branch}"]
            assert len(sel)==4 and all(abs(float(r["q_width_residual"]))<1 for r in sel)
    for state in query("equilibria")+query("anchor-width-equilibria"):
        label=state["branch"]
        if label.startswith("tangent"):continue
        with np.load(HERE/("state-"+label+".npz")) as pk:
            measured=float(np.sum(pk["ground"]**2))
            assert abs(measured/float(state["number"])-1)<1e-12
    controls=[];basis=[]
    for path in sorted(HERE.glob("history-*-k64.csv")):
        data=read(HERE,path.stem);controls.extend(data);other=path.with_name(path.name.replace("-k64","-k88"))
        if other.exists():
            fine=read(HERE,other.stem);assert len(data)==len(fine)
            for coarse,test in zip(data,fine):
                assert (coarse["component"],coarse["history"])==(test["component"],test["history"])
                basis.append(abs(float(test["induced"])/float(coarse["induced"])-1))
    flags=[r for r in controls if float(r["time_relative"])>2e-5]
    assert len(controls)==(12+24+36)*4 and max(abs(float(r["number_fraction"])) for r in controls)<1e-12
    assert max(float(r["readout_error"]) for r in controls)<1e-10
    assert max(basis)<2e-5
    failures=[dict(branch=r["branch"],history=r["history"],component=r["component"],relative=float(r["time_relative"]),
                       absolute=abs(float(r["induced"])-float(r["half_time"]))) for r in flags]
    for flag in failures:
        near=census if "_" not in flag["branch"] else spread
        sample=[r for r in near if r.get("branch",r.get("foreground"))==flag["branch"] and r["history"]==flag["history"] and r["model"]=="MTS"
                and ("inner_" if r["R"]=="6.0" else "outer_")+r["component"]==flag["component"]]
        assert len(sample)==2
        assert all(min(abs(float(r["total"])-float(r[k])) for k in ("low","high"))>flag["absolute"] for r in sample)
    stat=defaultdict(set)
    for r in query("anchor-width-panels"):stat[r["branch"]+"_"+r["model"]].add(int(r["count"]))
    results=dict(verified_inputs=archives,factorial_rows=len(cross),calibrated_rows=len(census),anchor_uncertainty_rows=len(spread),
                 host_histories=list(SERIES),time_checks=len(controls),time_relative_flags=failures,largest_basis_relative=max(basis),
                 largest_direct_wave_readout_error=max(float(r["readout_error"]) for r in controls),
                 largest_fractional_number_error=max(abs(float(r["number_fraction"])) for r in controls),
                 stream_numerical_relative=max(float(r[k]) for r in query("stream-accuracy") for k in ("wave_force_rel","stellar_force_rel","known_sky_relative")),
                 width_panel_counts={k:sorted(v) for k,v in stat.items()})
    assert results["stream_numerical_relative"]<2e-5
    put("checks.json",json.dumps(results,indent=2,sort_keys=True,allow_nan=False)+"\n")
    assert not (HERE/"__pycache__").exists()
    if "--seal" in sys.argv or (HERE/"seal.json").exists():
        files={p.name:sha(p) for p in sorted(HERE.iterdir()) if p.is_file() and p.name!="seal.json"}
        if "--seal" in sys.argv:put("seal.json",json.dumps(dict(files=files),indent=2,sort_keys=True)+"\n")
        assert files==json.loads((HERE/"seal.json").read_bytes())["files"]
        print("Verified",len(files),"files:",sha(HERE/"seal.json"))
    else:print(json.dumps(results,indent=2))
if __name__=="__main__":verify()
