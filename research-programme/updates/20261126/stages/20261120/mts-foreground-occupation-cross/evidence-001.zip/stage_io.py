from pathlib import Path
import os
import sys
import csv
import io
import json
import hashlib

for name in ("OPENBLAS_NUM_THREADS","OMP_NUM_THREADS","MKL_NUM_THREADS","NUMEXPR_NUM_THREADS","BLIS_NUM_THREADS"):
    os.environ[name]="1"
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
LAST=ROOT/"mts-lmc-wave-ring-contrast-20261120"
EXT=ROOT/"mts-extended-bar-fixed-occupation-20261120"
AP=ROOT/"mts-mw-baryon-apertures-20261120"
sys.path.insert(0,str(LAST))
import host_inputs as host
from branch_state import restored,diagnostics,jacobian,sky_of,ls,cr
from scipy.sparse.linalg import splu
from scipy import sparse
from host_inputs import np, common_wave
BHOST=host.HOST
SERIES=host.fixed.prep.ms.MODELS
UNIT=host.UNIT
SITES=("inner_radial","inner_polar","outer_radial","outer_polar","anchor_inward")
def sha(path):
    with path.open("rb") as stream:return hashlib.file_digest(stream,"sha256").hexdigest()
def guard():
    host.guard()
    assert not (HERE/"STOP-REQUESTED").exists()
    assert sha(LAST/"seal.json")=="13039baa8a9fb0a8bbc1b2b16fb60cafcb47af67a143981595c68185fa6d7ecc"
def put(name,raw):
    guard()
    if isinstance(raw,str):raw=raw.encode()
    path=HERE/name
    if path.exists():assert path.read_bytes()==raw,name
    else:
        with path.open("xb") as stream:stream.write(raw)
def table(name,records):
    buf=io.StringIO(newline="");writer=csv.DictWriter(buf,list(records[0]),lineterminator="\n")
    writer.writeheader();writer.writerows(records);put(name+".csv",buf.getvalue())
def read(folder,name):
    with (folder/(name+".csv")).open(newline="",encoding="utf-8") as stream:return list(csv.DictReader(stream))
def packet(name,**arrays):
    buf=io.BytesIO();np.savez_compressed(buf,**arrays);put(name+".npz",buf.getvalue())
def inputs():
    aq=read(EXT,"equilibria-fine-1-o0-q8")[-1]
    assert float(aq["t"])==1
    ordinary_a=float(aq["speed"])**2/17.58*UNIT-float(aq["anchor_inward"])
    ordinary_b=float(read(LAST,"host-calibration")[0]["ordinary"])
    return ordinary_a,ordinary_b
