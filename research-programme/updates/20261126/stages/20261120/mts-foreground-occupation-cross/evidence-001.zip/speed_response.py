from cross_equilibria import settle,factor
from stage_io import *
from stream_check import STREAMS,CONVERSION,wave_eval

def run():
    wave,_,_,_,_=restored(1,8,0,True);bg=wave.bg;original=wave.bare;change=common_wave.Wave(1).bare-original
    oa,ob=inputs();data=read(HERE,"stream-observables")
    near=read(HERE,"census-limited-forces");vel=224.03;outer=17.58;dv=.05
    states={r["branch"]:r for r in read(HERE,"equilibria")}
    slopes=[];comparisons=[]
    for label in ("anchorA","cut1","cut2"):
        state=states[label];frac=float(state["fraction"]);norm=float(state["number"])
        with np.load(HERE/f"state-{label}.npz") as saved:g=saved["ground"];mu=float(saved["chemical"])
        wave.bare=original+frac*change;ordinary=oa+frac*(ob-oa)
        solve=factor(wave,g,mu);rhs=np.zeros(g.size+bg.grav.shape[0]+1);rhs[-1]=.5
        dg=solve.solve(rhs)[:g.size]
        assert abs(2*g@dg-1)<1e-9
        dm=2*sky_of(bg,g)*sky_of(bg,dg)@wave.weights
        da=np.einsum("erl,rl->e",wave.rows,dm)
        douter=2*vel/outer*UNIT;dn=douter/da[-1];dark_at_outer=float(state["anchor_inward"])
        def change_at(R,Z):
            return .5*(wave_eval(bg,g+dg,R,Z)-wave_eval(bg,g-dg,R,Z))*dn
        contrast={}
        stored=[]
        for sign in (-1,1):
            sub=vel+sign*dv
            gx,mux,force,_=settle(wave,g,mu,None,sub**2/outer*UNIT-ordinary)
            stored.append((gx,force))
        for name,R,Z,qref,wq,zeroR,zeroZ,ref,width in STREAMS:
            fm=change_at(R,Z)*CONVERSION
            finite=(wave_eval(bg,stored[1][0],R,Z)-wave_eval(bg,stored[0][0],R,Z))*CONVERSION/(2*dv)
            unit=np.array([qref**2,Z/R])
            for model in ("MTS","static_NFW"):
                row=next(r for r in data if (r["stream"],r["branch"],r["model"])==(name,label,model))
                pred=float(row["strength"])
                if model=="MTS":
                    derivative=unit@fm;fd=unit@finite
                else:
                    darkforce=np.array([float(row["FR_kms_Myr"])-float(row["bary_FR"]),float(row["FZ_kms_Myr"])-float(row["bary_FZ"])])
                    derivative=unit@darkforce*douter/dark_at_outer;fd=derivative
                contrast[model,name]=(pred,ref-width,ref+width,derivative)
                slopes.append(dict(branch=label,model=model,probe=name,observable="published_strength",prediction=pred,
                    derivative_per_kms=derivative,finite_per_kms=fd,relative_error=abs(fd/derivative-1),
                    low=ref-width,high=ref+width,needed_speed_direction=int(np.sign((np.clip(pred,ref-width,ref+width)-pred)/derivative))))
        for site,key in enumerate(("inner_radial","outer_radial")):
            radius=(6.,8.3)[site]
            for model in ("MTS","static_NFW"):
                samples=[r for r in near if (r["foreground"],r["component"],r["z"],r["model"])==(label,"radial","1.5",model) and float(r["R"])==radius]
                raw=samples[0];pred=float(raw["ordinary"])+float(raw["dark"])
                assert all(abs(float(row["ordinary"])+float(row["dark"])-pred)<1e-12 for row in samples)
                lo=float(raw["low"]);hi=float(raw["high"])
                if model=="MTS":
                    derivative=da[2*site]*dn;fd=(stored[1][1][2*site]-stored[0][1][2*site])/(2*dv)
                else:
                    derivative=float(raw["dark"])*douter/dark_at_outer;fd=derivative
                slopes.append(dict(branch=label,model=model,probe=key,observable="stationary_northern_radial",prediction=pred,
                     derivative_per_kms=derivative,finite_per_kms=fd,relative_error=abs(fd/derivative-1),low=lo,high=hi,
                     needed_speed_direction=int(np.sign((np.clip(pred,lo,hi)-pred)/derivative))))
                for name,*_ in STREAMS:
                    s,lower,upper,ds=contrast[model,name]
                    local_shift=sorted([(lo-pred)/derivative,(hi-pred)/derivative])
                    remote_shift=sorted([(lower-s)/ds,(upper-s)/ds])
                    comparisons.append(dict(branch=label,model=model,radial=key,stream=name,local_slope=derivative,stream_slope=ds,
                          local_tangent_low=local_shift[0],local_tangent_high=local_shift[1],stream_tangent_low=remote_shift[0],stream_tangent_high=remote_shift[1],
                          tangent_intersection=max(local_shift[0],remote_shift[0])<=min(local_shift[1],remote_shift[1])))
    assert max(row["relative_error"] for row in slopes)<2e-5
    table("speed-derivatives",slopes);table("speed-compatibility",comparisons)
if __name__=="__main__":run()
