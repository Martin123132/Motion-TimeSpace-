from stage_io import *

def run(keep,labels):
    wave,_,_,_,_=restored(1,8,0,True);bg=wave.bg
    original=wave.bare;change=common_wave.Wave(1).bare-original
    pins=json.loads((cr.AXIS/"seal.json").read_bytes())["files"]
    for label in labels:
        guard()
        with np.load(HERE/("state-"+label+".npz")) as saved:
            g=saved["ground"];mu=float(saved["chemical"]);frac=float(saved["fraction"])
        wave.bare=original+frac*change
        assert np.linalg.norm(wave.fields(g)[3]@g-mu*g)<1e-10
        op,projection=cr.operators(wave,g,mu,keep)
        assert min(op["sigma"])>0
        results=[];mapping=None
        source_list=SERIES if not label.startswith("low") else [read(LAST,"host-ground-"+label[3:])[0]["history"]]
        for history in source_list:
            name=cr.name(history,320,40,36,16)
            assert sha(cr.AXIS/name)==pins[name]
            with np.load(cr.AXIS/name) as src:
                rad=src["radius"];time=src["time"];force=src["V"]
            if mapping is None:
                mapping=cr.source_map(op,rad,40)@op["u"];ref=rad
            assert np.array_equal(ref,rad)
            drive=force.reshape(len(time),-1)@mapping;del force
            tau=time*bg.vel/bg.length; sigma=op["sigma"]
            coord=cr.integrate(drive,tau,sigma)[-1].real
            other=cr.integrate(drive[::2],tau[::2],sigma)[-1].real
            selected=[0,1,3,4];sky=(op["sky"]@coord)[selected]
            x=np.einsum("lrk,lk->rl",op["block"],(op["u"]@coord).reshape(bg.count,-1)).ravel()
            moments=2*sky_of(bg,g)*sky_of(bg,x)@wave.weights
            exact=bg.sky_forces((moments*(bg.sqrt/bg.rad)[:,None]).ravel())[:,[1,0]].ravel()
            num=2*g@x/(g@g);abs_error=max(abs(exact-sky))
            assert abs(num)<1e-11 and abs_error<1e-10
            for component,value,compare in zip(SITES,sky,(op["sky"]@other)[selected]):
                results.append(dict(branch=label,history=history,component=component,induced=value,half_time=compare,time_relative=abs(compare/value-1),
                                    number_fraction=num,readout_error=abs_error,projection_error=projection,lowest_sigma=min(sigma)))
        table(f"history-{label}-k{keep}",results);print(label,keep,"complete",flush=True)
if __name__=="__main__":run(int(sys.argv[1]),sys.argv[2:])
