from stage_io import *
from cross_equilibria import settle
from stream_check import STREAMS,CONVERSION,wave_eval
from scipy.optimize import brentq

def run():
    guard()
    source=ROOT/"mts-calibrated-disk-wave-20261119"
    prior=next(r for r in read(source,"rotation") if (r["case"],r["model"],r["role"])==("main","mts","calibration"))
    radius,central,width=map(float,[prior["R_kpc"],prior["V_obs"],prior["sigma_boot"]])
    assert (radius,central,width)==(17.58,224.03,1.91)
    wave,_,_,_,_=restored(1,8,0,True);bg=wave.bg;original=wave.bare;change=common_wave.Wave(1).bare-original
    oa,ob=inputs();data=read(HERE,"stream-observables");stream=[];eq=[]
    sphere=host.fixed.prep.ms.nfw(0);nfwouter=-sphere(radius,0)[0]*UNIT
    for label in ("anchorA","cut1","cut2"):
        with np.load(HERE/f"state-{label}.npz") as saved:g=saved["ground"];mu=float(saved["chemical"]);frac=float(saved["fraction"])
        wave.bare=original+frac*change;ordinary=oa+(ob-oa)*frac
        for extreme,speed in (("lower",central-width),("upper",central+width)):
            dark=speed**2/radius*UNIT-ordinary
            field,chem,force,steps=settle(wave,g,mu,None,dark)
            tag=label+"_"+extreme
            packet("state-"+tag,ground=field,chemical=chem,number=field@field,fraction=frac)
            eq.append(dict(branch=tag,source=label,speed=speed,fraction=frac,number=field@field,**dict(zip(SITES,force))))
            for name,R,Z,ref,qwidth,cR,cZ,target,w in STREAMS:
                raw=next(r for r in data if (r["branch"],r["stream"])==(label,name))
                bary=np.array([float(raw["bary_FR"]),float(raw["bary_FZ"])])
                for model,acc in (("MTS",wave_eval(bg,field,R,Z)),("static_NFW",np.array(sphere(R,Z)[:2])*dark/nfwouter)):
                    fr,fz=bary+acc*CONVERSION;q=np.sqrt(Z/R*fr/fz);s=ref**2*(fr+cR)+(Z/R)*(fz+cZ)
                    stream.append(dict(branch=tag,stream=name,model=model,speed=speed,q=q,q_width_residual=(q-ref)/qwidth,
                                      strength=s,strength_width_residual=(s-target)/w))
    table("anchor-width-equilibria",eq);table("anchor-width-streams",stream)
    slopes=read(HERE,"census");shell=read(HERE,"pal5-shell-budget")
    a0=next(r for r in shell if r["branch"]=="anchorA");b0=next(r for r in shell if r["branch"]=="anchorB")
    _,R,Z,q,_,_,_,target,scale=STREAMS[0];rp=np.hypot(R,Z);coeff=(q**2*R+Z**2/R)/rp*(radius/rp)**2
    def bounds(w):
        lo,hi=0.,1.
        for r in [x for x in slopes if x["width"]=="1"]:
            a,b,o,sw=map(float,[r[k] for k in ("measured_source","native_source","census","quoted_width")])
            left,right=sorted([(o-w*sw-a)/(b-a),(o+w*sw-a)/(b-a)])
            lo=max(lo,left);hi=min(hi,right)
        return lo,hi
    def best(w):
        low,high=bounds(w);assert low<=high
        def margin(f):
            base=float(a0["spherical_empty_shell_ceiling"])*(1-f)+float(b0["spherical_empty_shell_ceiling"])*f
            capacity=base+coeff*(central**2-(central-w*width)**2)/radius*CONVERSION
            return capacity-(target-w*scale)
        return max((margin(f),f) for f in (low,high))
    minimum=brentq(lambda w:best(w)[0],1.,2.)
    table("joint-shell-width",[dict(rectangular_factor=w,minimum_speed=central-w*width,fraction_at_ceiling=best(w)[1],
         ceiling_minus_Pal5_lower=best(w)[0],shell_test_possible=best(w)[0]>=-1e-12) for w in (1.,minimum,2.)])
if __name__=="__main__":run()
