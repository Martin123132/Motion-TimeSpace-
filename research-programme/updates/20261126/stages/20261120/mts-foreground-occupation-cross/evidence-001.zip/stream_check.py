from stage_io import *
from signed_potential import census,direct
import primary_wave
from scipy.interpolate import BarycentricInterpolator
from numpy.polynomial.legendre import legvander

STREAMS=(("Pal5",8.4,16.8,.94,.05,.80,1.82,-.2,.6),("GD1",12.5,6.675,.95,.04,2.51,1.47,-.05,.3))
CONVERSION=31557600e6/3.0856775814913673e16

def ordinary(radius,height,order):
    source=census();rr=np.hypot(radius,height)
    full=primary_wave.prep.rings(source,radius,height,order,True)[:2]
    point=primary_wave.G*source.stars.bmass*np.array([radius,height])/rr**3
    central=primary_wave.Field("extra")
    def pot(R,Z):
        rad=np.hypot(R,Z);return central.grid(np.array([rad]),np.array([Z/rad]),0)[0][0,0]
    def gradient(step):
        return -np.array([(pot(radius+step,height)-pot(radius-step,height))/(2*step),(pot(radius,height+step)-pot(radius,height-step))/(2*step)])
    central_force=(4*gradient(.001)-gradient(.002))/3
    adjusted=direct(radius,height,order)[1:]
    return full+point+central_force+adjusted

def wave_eval(bg,g,radius,height):
    coefficients=sky_of(bg,g)**2@(bg.aw[:,None]*bg.harm)
    src=(coefficients*(bg.sqrt/bg.rad)[:,None]).ravel()
    u=bg.field(src).reshape(-1,bg.count)/np.sqrt(bg.mesh.radial_weight)[:,None]
    grid=np.r_[0.,bg.mesh.gravity_radius];u=np.vstack([np.zeros(bg.count),u])
    at=np.hypot(radius,height)/bg.length;mu=height/np.hypot(radius,height);s=radius/np.hypot(radius,height)
    cell=np.searchsorted(grid[::7],at)-1;ids=7*cell+np.arange(8)
    spline=BarycentricInterpolator(grid[ids],u[ids],rng=271)
    value=spline(at)/at;derivative=(spline.derivative(at)-value)/at
    allharm=legvander(mu,int(bg.orders[-1]))[0];harm=allharm[bg.orders]*np.sqrt(2*bg.orders+1)
    dh=np.zeros_like(harm);ell=bg.orders[1:]
    dh[1:]=np.sqrt(2*ell+1)*ell*(allharm[ell-1]-mu*allharm[ell])/(1-mu**2)
    radial=-derivative@harm;polar=s*(value@dh)/at
    return np.array([s*radial+mu*polar,mu*radial-s*polar])*bg.vel**2/bg.length

def run():
    guard();wave,_,_,_,_=restored(1,8,0,True);bg=wave.bg;native=common_wave.materials(SERIES[0])
    sphere=host.fixed.prep.ms.nfw(0);outer=-sphere(17.58,0.)[0]*UNIT
    eq={r["branch"]:r for r in read(HERE,"equilibria")};result=[];controls=[]
    for name,R,Z,ref,spread,zeroR,zeroZ,target,width in STREAMS:
        oa=ordinary(R,Z,18);coarse=ordinary(R,Z,12)
        ob=native([[R,0.,Z]])[0,[1,3]]
        assert np.all(oa<0) and np.all(ob<0)
        for label in ("anchorA","cut1","cut2","anchorB"):
            row=eq[label];f=float(row["fraction"]);bary=(1-f)*oa+f*ob
            with np.load(HERE/f"state-{label}.npz") as data:g=data["ground"]
            w=wave_eval(bg,g,R,Z);independent=host.fixed.prep.vg.wave_field(bg,g.reshape(bg.hshape))
            remote=np.array(independent(R,np.array([Z]))[:2]).ravel()
            inner=wave_eval(bg,g,6.,1.5);project=host.fixed.prep.projection(*inner,6.,1.5)
            controls.append(dict(stream=name,branch=label,stellar_force_rel=max(abs(coarse/oa-1)),wave_force_rel=max(abs(remote/w-1)),
                           known_sky_relative=max(abs(project/np.array([float(row[k]) for k in SITES[:2]])-1))))
            for model,dark in (("MTS",w),("static_NFW",np.array(sphere(R,Z)[:2])*float(row["anchor_inward"])/outer)):
                fr,fz=(bary+dark)*CONVERSION
                q=np.sqrt(Z/R*fr/fz)
                size=ref**2*(fr+zeroR)+Z/R*(fz+zeroZ)
                result.append(dict(stream=name,R=R,Z=Z,branch=label,model=model,FR_kms_Myr=fr,FZ_kms_Myr=fz,
                                    bary_FR=bary[0]*CONVERSION,bary_FZ=bary[1]*CONVERSION,q_total=q,q_reference=ref,q_width=spread,
                                    q_distance_widths=(q-ref)/spread,strength=size,strength_reference=target,strength_width=width,
                                    strength_distance_widths=(size-target)/width))
    table("stream-accuracy",controls);table("stream-observables",result)
if __name__=="__main__":run()
