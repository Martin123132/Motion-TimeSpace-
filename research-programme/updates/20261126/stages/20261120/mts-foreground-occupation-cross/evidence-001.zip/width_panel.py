from stage_io import *

def run():
    guard();models=("MTS","static_NFW")
    base=read(HERE,"census-limited-forces");states=read(HERE,"anchor-width-equilibria")
    ref={r["branch"]:r for r in read(HERE,"equilibria")};data=[];scores=[]
    for state in states:
        tag=state["branch"];parent=state["source"]
        controls={(r["history"],r["component"]):float(r["induced"]) for r in read(HERE,f"history-{tag}-k64")}
        for model in models:
            for hist in SERIES:
                rows=[r for r in base if (r["foreground"],r["model"],r["history"])==(parent,model,hist)]
                subset=[]
                for r in rows:
                    comp=r["component"];key=("inner_" if r["R"]=="6.0" else "outer_")+comp
                    parity=-1 if r["z"].startswith("-") and comp=="polar" else 1
                    if model=="MTS":
                        dark=parity*float(state[key]);wave=parity*controls[hist,key]
                    else:
                        dark=float(r["dark"])*float(state["anchor_inward"])/float(ref[parent]["anchor_inward"]);wave=0.
                    total=float(r["ordinary"])+float(r["direct_LMC"])+dark+wave
                    lo,hi=float(r["low"]),float(r["high"]);check=lo<=total<=hi
                    record=dict(branch=tag,speed=state["speed"],history=hist,model=model,R=r["R"],z=r["z"],component=comp,total=total,low=lo,high=hi,inside=check,dark=dark,wave=wave)
                    data.append(record);subset.append(record)
                assert len(subset)==8
                scores.append(dict(branch=tag,history=hist,model=model,count=sum(v["inside"] for v in subset)))
    table("anchor-width-forces",data);table("anchor-width-panels",scores)
if __name__=="__main__":run()
