from collections import Counter
from scope import *


def audit():
    locked()
    frozen=check_freeze()
    assert frozen=="e112db8bf1ab3cc32b74162b2a65e6c984481794a585f12d39e9724616b9bfdb"
    assert not list(HERE.rglob("*.partial"))
    checks=Counter()
    names=set()
    required={(scheme,seed,flag,count,count) for scheme in SCHEMES for seed in SIGNS for flag in (0,1) for count in (128,512)}
    required|={("original",1,flag,16384,4096) for flag in (0,1)}
    if (HERE/"original-s1-off0-n32768-t256.npz.json").exists():
        required|={("original",1,flag,32768,8192) for flag in (0,1)}
    for scheme,seed,flag,count,last in sorted(required):
        stride=min(256,count//4)
        elapsed=-1
        for tick in range(stride,last+1,stride):
            name=f"{scheme}-s{seed}-off{flag}-n{count}-t{tick}.npz"
            receipt=json.loads((HERE/(name+".json")).read_bytes())
            assert receipt["tick"]==tick and receipt["freeze"]==frozen and receipt["sha"]==core.sha(HERE/name)
            with np.load(HERE/name) as bank:
                times=bank["times"]
                assert len(times)>1 and np.all(np.diff(times)>0)
                assert times[0]==(0 if elapsed<0 else elapsed)
                elapsed=times[-1]
                assert elapsed==tick*float(bank["step"])
                assert np.allclose(elapsed,4096*tick*np.pi/(count*float(bank["mu"])),rtol=4e-15,atol=0)
                assert bank["signed"].shape==bank["shared"].shape==(20,2,480)
                assert np.all(np.isfinite(bank["signed"])) and np.all(np.isfinite(bank["shared"]))
            names.add(name+".json")
            checks["restart_packets"]+=1
        checks["complete_trajectories"]+=1
    assert {p.name for p in HERE.glob("*.npz.json")}==names
    tides=core.read(HERE/"all-tides.csv")
    unique={(r["scheme"],int(r["seed"]),int(r["steps"]),float(r["fraction"]),float(r["width"]),r["channel"]) for r in tides}
    want={(s,seed,steps,quarter/4,width,ch) for s,seed,flag,steps,last in required for quarter in range(1,1+4*last//steps) for width in (.15,.30) for ch in ("gauss","ricci")}
    assert unique==want and len(tides)==len(want)
    for r in tides:
        assert (abs(float(r["live_ppm"]))<=20)==(r["within_prediction_gate"]=="True")
    checks["gravity_comparisons"]=len(tides)
    mat=core.read(HERE/"all-matter.csv")
    assert len(mat)==len(want)//2 and all(float(r["relative"])>=0 and float(r["signal"])>0 for r in mat)
    checks["matter_comparisons"]=len(mat)
    for name, columns in (("resolution.csv",("relative","rms")),("surrounding-work.csv",("relative_balance","relative_gross")),
                          ("source-transfer.csv",("relative","signal")),("amplitude-transport.csv",("explained_projection","residual_rms_relative"))):
        cells=core.read(HERE/name)
        assert cells and all(np.isfinite(float(row[col])) for row in cells for col in columns)
        checks[name]=len(cells)
    checks["primary_prediction_passes"]=sum(r["within_prediction_gate"]=="True" for r in tides)
    for grid in (80,320):
        folder=HERE/f"space-{grid}"
        actual={p.name for p in folder.glob("*.npz.json")}
        expected=set()
        for scheme in SCHEMES:
            band=core.read(HERE/f"space-{grid}-{scheme}.csv")
            assert len(band)==16 and len({(r["fraction"],r["width"],r["channel"]) for r in band})==16
            for flag in (0,1):
                for tick in (128,256,384,512):
                    name=f"{scheme}-s1-off{flag}-n512-t{tick}.npz"
                    cert=json.loads((folder/(name+".json")).read_bytes())
                    assert cert["tick"]==tick and cert["freeze"]==frozen and core.sha(folder/name)==cert["sha"]
                    with np.load(folder/name) as bank:
                        assert bank["signed"].shape==(20,2,3*grid) and np.all(np.isfinite(bank["signed"]))
                    expected.add(name+".json")
        assert actual==expected
        checks["separate_spatial_trajectories"]+=4
        checks["separate_spatial_comparisons"]+=32
    compatibility=core.read(HERE/"constraint-floor.csv")
    assert len(compatibility)==64 and all((float(r["half_separation_ppm"])<=20)==(r["common_target_possible"]=="True") for r in compatibility)
    for r in core.read(HERE/"ruler-decomposition.csv"):
        whole=float(r["full_error_ppm"])
        summed=sum(float(r[k]) for k in ("field_minus_prediction_ppm","same_local_metric_ppm","integrated_distance_ppm"))
        assert abs(whole-summed)<.001+abs(whole)*1e-12
    for grid in (160,320):
        for scheme in SCHEMES:
            for size in ((24,40) if scheme=="original" else (24,)):
                with np.load(HERE/f"mode-{grid}-{scheme}-{size}.npz") as bank:
                    matrix,vals,mode=bank["matrix"],bank["eigen"],bank["dominant"]
                    growth=vals[vals.real.argmax()]
                    assert np.linalg.norm(matrix@mode-growth*mode)<1e-10
                checks["centre_eigensystems"]+=1
    witness=core.read(HERE/"flat-identity-witness.csv")
    assert len(witness)==2 and all(float(r["existing_H_rate"])>.01 and float(r["composed_H_rate"])<1e-12 and float(r["initial_constraint"])<1e-12 for r in witness)
    for row in core.read(HERE/"full-constraint-launch-derivative.csv"):
        assert float(row["full_constraint_rate"])>.01 and float(row["derivative_relative_difference"])<1e-8
    for name in ("flat-manufactured.csv","work-precision.csv","centre-mode-constraints.csv","admissible-launch-witness.csv"):
        assert core.read(HERE/name),name
    print(dict(checks),flush=True)
    return dict(checks)


def main():
    checks=audit()
    files={path.relative_to(HERE).as_posix():core.sha(path) for path in sorted(HERE.rglob("*")) if path.is_file() and path.name!="seal.json"}
    if sys.argv[1:]==["--seal"]:
        record("seal.json",dict(previous=core.sha(LAST/"seal.json"),freeze=check_freeze(),checks=checks,files=files))
    else:
        assert not sys.argv[1:]
    seal=json.loads((HERE/"seal.json").read_bytes())
    assert seal["files"]==files and seal["checks"]==checks
    print("Verified",len(files),core.sha(HERE/"seal.json"),flush=True)


if __name__=="__main__":
    main()
