from scope import *
from endpoints import D
from readouts import joined,rms
from source_terms import RadialOperators
from transport import coefficients
from scipy.integrate import simpson


def history(scheme,seed,count,target):
    model=Canonical(seed,scheme)
    mu=float(model.shell.mu)
    op=RadialOperators(model.shell.r,model.shell.dx)
    use=(model.shell.r>.6)&(model.shell.r<2.1)
    rho=float(model.shell.rho[-1])
    saved=[]
    stride=min(256,count//4)
    for tick in range(0,target+1,stride):
        if tick:
            name=f"{scheme}-s{seed}-off0-n{count}-t{tick}.npz"
            assert core.sha(HERE/name)==json.loads((HERE/(name+".json")).read_bytes())["sha"]
            with np.load(HERE/name) as data:
                delta=model.to_wave(Difference(data["shared"],data["signed"]))
                time=tick*float(data["step"])
        else:
            delta=np.zeros_like(model.shell.initial)
            time=0.
        members=[]
        for shell,shift in ((model.zero,delta.base),(model.host,delta)):
            def at(idx):
                return joined(shell.initial[idx,0].real)+joined(shift[idx,0].real)
            ell,bend,amp=at(0),at(1),at(14)
            gradient=op.cell(op.face(amp,True),False)
            lap=np.exp(-ell-2*bend)*op.cell(op.face_square*np.exp(op.face(2*bend-ell))*op.face(amp,True))/op.radius**2
            forcing=(lap+np.exp(-2*ell)*gradient**2)/D(mu)
            members.append((ell,bend,amp,forcing))
        saved.append((time,members))
    result={}
    from endpoints import convert
    for variant in ("evolving","launch_only"):
        member_results=[]
        for member in (0,1):
            velocity=np.zeros_like(model.shell.r,dtype=complex)
            integrated=np.zeros_like(model.shell.r)
            fluxes=[]
            phases=[]
            for idx,(now,members) in enumerate(saved):
                ell,bend,amp,force=members[member]
                if idx:
                    before=saved[idx-1][1][member][3]
                    if variant=="launch_only":
                        before=force=saved[0][1][member][3]
                    dt=now-saved[idx-1][0]
                    phase,first,second=coefficients(2*mu,float(dt))
                    left,right=before.astype(float),force.astype(float)
                    velocity=phase*velocity+first*left+second*right
                    integrated+=.5*dt*(left+right)
                potential=(integrated-velocity.real)/(2*mu)
                phases.append(potential[use])
                fluxes.append(rho*op.strong(ell,bend,amp,convert(potential))[use].astype(float))
            member_results.append((np.asarray(phases),np.asarray(fluxes)))
        now=np.array([time for time,_ in saved])
        phase,rate=[host-zero for zero,host in zip(*member_results,strict=True)]
        result[variant]={"phase":phase[-1],"rate":rate[-1],"charge":simpson(rate,x=now,axis=0)}
    return result


def main():
    getcontext().prec=46
    results=[]
    for scheme in SCHEMES:
        for seed in SIGNS:
            for steps,target in ((512,128),(512,512),(16384,4096)):
                name=f"read-{scheme}-s{seed}-n{steps}-t{target}.npz"
                if not (HERE/name).is_file():
                    continue
                with np.load(HERE/name) as bank:
                    measured={key:bank[key] for key in ("phase","charge","rate")}
                part=history(scheme,seed,steps,target)
                for key,actual in measured.items():
                    for variant in part:
                        pred=part[variant][key]
                        results.append(dict(scheme=scheme,seed=seed,steps=steps,fraction=target/steps,observable=key,
                                            driver=variant,explained_projection=pred@actual/(actual@actual),
                                            residual_rms_relative=rms(actual-pred)/rms(actual),driver_rms=rms(pred)))
    rows("amplitude-transport.csv",results)


if __name__=="__main__":
    main()
