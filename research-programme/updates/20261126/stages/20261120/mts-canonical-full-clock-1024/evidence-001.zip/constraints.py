from scope import *
import constraint_floor


def main():
    getcontext().prec=46
    outputs=[]
    for grid in (160,320):
        for scheme in SCHEMES:
            with patch.object(case.parent.evolve_speed,"launch",case.parent.launch):
                shell=case.parent.evolve_speed.system(1024,grid,1,0,scheme,3)[0]
            size=24
            with np.load(HERE/f"mode-{grid}-{scheme}-{size}.npz") as bank:
                eigen=bank["dominant"]
                assert np.max(abs(eigen.imag))<1e-12
                vector=eigen.real.reshape(8,size)
            affine=np.zeros_like(vector)
            affine[:4]=np.array([1.,-.5,1.,1.])[:,None]
            for label,direction in (("centre_eigenmode",vector),("constant_regular_shear",affine)):
                v=direction/max(abs(direction).ravel())
                shift=np.zeros_like(shell.initial)
                shift[:4,1,:size]=v[:4]
                shift[4:8,1,:size]=v[4:]/shell.dx
                previous=None
                for amplitude in (1e-6,1e-7):
                    plus=constraint_floor.components(shell,amplitude*shift)
                    minus=constraint_floor.components(shell,-amplitude*shift)
                    numbers={key:float(np.max(abs((plus[key]-minus[key])[1,:10].astype(float)))*shell.dx**2/(2*amplitude))
                             for key in ("ham","mom_r","mom_theta")}
                    if previous is not None:
                        for key in numbers:
                            assert abs(numbers[key]-previous[key])<=2e-12*max(1,numbers[key])
                    previous=numbers
                    outputs.append(dict(grid=grid,scheme=scheme,field=label,amplitude=amplitude,**numbers))
    rows("centre-mode-constraints.csv",outputs)
    print(outputs[12:15])


if __name__=="__main__":
    main()
