from scope import *
from endpoints import D,convert
from source_terms import RadialOperators
from readouts import joined,rms
from scipy.integrate import simpson


def check(scheme,seed,count,target):
    times=[]
    by={}
    for flag in (0,1):
        model=Evolution(1,seed,scheme) if flag else Canonical(seed,scheme)
        shell=model.shell
        select=(shell.r>.6)&(shell.r<2.1)
        op=RadialOperators(shell.r,shell.dx)
        stride=min(256,count//4)
        for tick in range(0,target+1,stride):
            if tick:
                name=f"{scheme}-s{seed}-off{flag}-n{count}-t{tick}.npz"
                info=json.loads((HERE/(name+".json")).read_bytes())
                assert core.sha(HERE/name)==info["sha"]
                with np.load(HERE/name) as bank:
                    stored=Difference(bank["shared"],bank["signed"])
                    time=tick*float(bank["step"])
            else:
                stored=np.zeros_like(shell.initial)
                time=0.
            if not flag:times.append(time)
            physical=stored if flag else model.to_wave(stored)
            rhs=model.rhs(time,physical)
            p=shell.incident.at(time)[1]
            signed=[]
            for member in (0,1):
                cv=joined if member else lambda field:convert(field.base)
                def initial(idx):
                    return cv(shell.initial[idx,0].real)
                def at(idx):
                    return initial(idx)+cv(physical[idx,0].real)
                ell,bend=at(0),at(1)
                volume=np.exp(ell+2*bend)
                volume0=np.exp(initial(0)+2*initial(1))
                energy=at(17)
                begin=volume0*initial(17)
                work=volume*at(4)*cv(p)/3
                flux=-op.cell(op.face_square*np.exp(op.face(2*bend))*op.face(at(18)))/op.radius**2
                temporal=volume*(cv(rhs[17,0].real)+(cv(rhs[0,0].real)+2*cv(rhs[1,0].real))*energy)
                signed.append(np.array([(volume*energy-begin)[select],work[select],flux[select],temporal[select]]))
            by[tick,flag]=signed[1]-signed[0]
    measured=np.array([(by[tick,0]-by[tick,1]).astype(float) for tick in range(0,target+1,stride)])
    stored,work,flux,temporal=measured.transpose(1,0,2)
    summed=work+flux
    effort=simpson(summed,x=times,axis=0)
    direct=simpson(temporal,x=times,axis=0)
    norm=rms(stored[-1])
    return dict(scheme=scheme,seed=seed,steps=count,fraction=target/count,panels=len(times)-1,energy=norm,
        physical_terms_vs_stored=rms(effort-stored[-1])/norm,native_rates_vs_stored=rms(direct-stored[-1])/norm,
        physical_vs_native_integral=rms(effort-direct)/norm,
        instantaneous_relative=rms(temporal-summed)/rms(summed))


def main():
    getcontext().prec=55
    rows_out=[check(scheme,seed,512,512) for scheme in SCHEMES for seed in SIGNS]
    rows_out.append(check("original",1,16384,4096))
    rows("work-precision.csv",rows_out)
    print(rows_out[-1])


if __name__=="__main__":
    main()
