from scope import *
import constraint_floor


def main():
    getcontext().prec=50
    model=Evolution(1,1,"original")
    h=model.shell.dx
    rows_out=[]
    with np.load(HERE/"admissible-launch-witness.npz") as bank:
        for inner in (0,8):
            vec=bank[f"field_from_cell{inner}"].reshape(8,40)
            expected=bank[f"rate_constraints{inner}"]
            first=bank[f"initial_constraints{inner}"]
            for amplitude in (1e-6,1e-7):
                for dt in (h*1e-4,h*2e-4):
                    slopes=[]
                    for sign in (1,-1):
                        shift=np.zeros_like(model.shell.initial)
                        shift.base[:4,1,:40]=sign*amplitude*vec[:4]
                        shift.base[4:8,1,:40]=sign*amplitude*vec[4:]/h
                        rate=model.rhs(0.,shift).base
                        end=constraint_floor.components(model.zero,shift.base+dt*rate)
                        begin=constraint_floor.components(model.zero,shift.base-dt*rate)
                        slopes.append(np.concatenate([((end[key]-begin[key])[1,:48]).astype(float) for key in ("ham","mom_r","mom_theta")])/(2*dt))
                    full=h**3*(slopes[0]-slopes[1])/(2*amplitude)
                    diff=np.linalg.norm(full-expected)/np.linalg.norm(expected)
                    rows_out.append(dict(first_cell=inner,amplitude=amplitude,delta_t_in_cells=dt/h,
                        constraint_initial=np.linalg.norm(first),full_constraint_rate=np.linalg.norm(full),
                        frozen_geometric_rate=np.linalg.norm(expected),derivative_relative_difference=diff))
    rows("full-constraint-launch-derivative.csv",rows_out)
    print(rows_out[-1])


if __name__=="__main__":
    main()
