from scope import *
from math import fsum
from readouts import joined
from read_clock import canonical_reader
import ref_endpoint
import argparse


def separate(shell,time,shift):
    central=core.central
    ep=core.ep
    family=central.family
    start=shell.initial
    inc=shift.base+shift.delta if isinstance(shift,Difference) else shift
    def components(at,change,saved):
        full=start if change is None else start+change
        with patch.object(ref_endpoint,"convert",joined):
            tide=canonical_reader(shell,start,saved,ref_endpoint.fixed_tide)
        stress=family.sources(shell,at,full,np.zeros_like(full))
        tide[:,1]+=ep.convert(stress[7,1].real)
        return tide
    old=components(0.,None,None)
    new=components(time,inc,shift)
    win=ep.Window(shell,start,np.zeros_like(start),8)
    def optical(field):
        spline=win.spline(field)
        primitive=spline.antiderivative()
        return spline(win.pos),primitive(win.pos)-primitive(0.)[:,None]
    metric0=ep.exp(start[0].real)
    jac,distance=optical(metric0)
    dr=inc[0].real
    dm0=metric0[0]*np.expm1(dr[0])
    dj,dd=optical(family.pair(dm0,metric0[1]*np.expm1(dr[0])+(metric0[0]+dm0)*dr[1]))
    base=win.at(old.astype(float))
    delta=win.at((new-old).astype(float))
    nodes,weights=ep.leggauss(8)
    out={}
    for width in (.15,.30):
        half=ep.CENTER*width
        original=ep.weight(distance[0],half)
        deriv=ep.weight(distance[0],half,1)
        def wt(degree):
            return sum(w*ep.weight(distance[0]+.5*(node+1)*dd[0],half,degree) for node,w in zip(nodes,weights))*dd[0]/2
        dw,dt=wt(1),wt(2)
        def change(field,jump,path):
            cover=list(zip(jac,dj*jump))
            first=list(zip(base[field],delta[field]))
            return (ep.secant((original,path*dw),cover[0],first[1])+ep.secant((original,path*dw),cover[1],first[0])
                 +ep.secant((deriv,path*dt),cover[0],(distance[1],path*dd[1]),first[0]))
        integrate=lambda x:1024*fsum(win.quad*x)
        for field,ch in enumerate(("ricci","gauss")):
            fixed=change(field,0,0)
            metric=change(field,1,0)
            all_fields=change(field,1,1)
            for name,term in (("sampled_field",fixed),("local_jacobian",metric-fixed),("integrated_distance",all_fields-metric),("full",all_fields)):
                out[width,ch,name]=integrate(term)
    return out


def main():
    locked()
    getcontext().prec=46
    predicted={(float(r["width"]),float(r["fraction"])):(float(r["newton"]),float(r["prediction"])) for r in core.read(HERE/"predicted-gravity.csv")
               if r["seed"]=="1" and r["mode"]=="flrw-live"}
    result=[]
    for grid in (160,320):
        scheme="original"
        folder=HERE if grid==160 else HERE/f"space-{grid}"
        def system(flag,seed,scheme):
            with patch.object(case.parent.evolve_speed,"launch",case.parent.launch):
                return case.parent.evolve_speed.system(1024,grid,flag,seed,scheme,3)[0]
        group={}
        with patch.object(case.parent,"system",system):
            for flag in (0,1):
                model=Evolution(1,1,scheme) if flag else Canonical(1,scheme)
                for tick in (128,256,384,512):
                    name=f"{scheme}-s1-off{flag}-n512-t{tick}.npz"
                    assert core.sha(folder/name)==json.loads((folder/(name+".json")).read_bytes())["sha"]
                    with np.load(folder/name) as bank:
                        state=Difference(bank["shared"],bank["signed"])
                        time=tick*float(bank["step"])
                    actual=state if flag else model.to_wave(state)
                    control=separate(model.zero,time,actual.base)
                    signed=separate(model.host,time,actual)
                    for key in signed:
                        group[tick,flag,*key]=signed[key]-control[key]
        for fraction in (.25,.5,.75,1.):
            tick=round(512*fraction)
            if grid==160:
                archive=core.read(HERE/f"read-{scheme}-s1-n512-t{tick}-gravity.csv")
            else:
                archive=core.read(HERE/f"space-{grid}-{scheme}.csv")
            for width in (.15,.30):
                newton,pred=predicted[width,fraction]
                unit=abs(newton)*1e-6
                for ch in ("ricci","gauss"):
                    pieces={key:group[tick,0,width,ch,key]-group[tick,1,width,ch,key] for key in ("sampled_field","local_jacobian","integrated_distance","full")}
                    ref,=[r for r in archive if r["channel"]==ch and float(r["fraction"])==fraction and float(r["width"])==width]
                    closure=abs(sum(pieces[key] for key in ("sampled_field","local_jacobian","integrated_distance"))-pieces["full"])/unit
                    replay=abs(float(ref["tide"])-pieces["full"])/unit
                    assert replay<=.001+abs(pieces["full"]/unit)*1e-12,(grid,tick,ch,replay)
                    assert closure<=.001+abs(pieces["full"]/unit)*1e-12,(grid,tick,ch,closure)
                    result.append(dict(grid=grid,fraction=fraction,width=width,channel=ch,full_error_ppm=(pieces["full"]-pred)/unit,
                        field_minus_prediction_ppm=(pieces["sampled_field"]-pred)/unit,same_local_metric_ppm=pieces["local_jacobian"]/unit,
                        integrated_distance_ppm=pieces["integrated_distance"]/unit,closure_ppm=closure,replay_ppm=replay))
    rows("ruler-decomposition.csv",result)
    print("decomposition",result[-1],flush=True)


if __name__=="__main__":
    main()
