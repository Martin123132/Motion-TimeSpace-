from scope import *


def main():
    group={}
    for row in core.read(HERE/"all-tides.csv"):
        if row["steps"]=="512":
            group.setdefault((160,row["scheme"],int(row["seed"]),float(row["fraction"]),float(row["width"])),{})[row["channel"]]=float(row["live_ppm"])
    for name in sorted(HERE.glob("space-*-*.csv")):
        for row in core.read(name):
            group.setdefault((int(row["grid"]),row["scheme"],1,float(row["fraction"]),float(row["width"])),{})[row["channel"]]=float(row["live_ppm"])
    results=[]
    for (grid,scheme,seed,fraction,width),pair in sorted(group.items()):
        gauss,ricci=pair["gauss"],pair["ricci"]
        floor=abs(gauss-ricci)/2
        lower=max(gauss,ricci)-20
        upper=min(gauss,ricci)+20
        results.append(dict(cells_per_mpc=grid,scheme=scheme,seed=seed,fraction=fraction,width=width,gauss_ppm=gauss,ricci_ppm=ricci,
                            predicted_common_error_ppm=(gauss+ricci)/2,half_separation_ppm=floor,
                            h_projection_ppm=6*(gauss-ricci),common_target_possible=lower<=upper,
                            correction_lower_ppm=lower,correction_upper_ppm=upper,
                            fixed_prediction_passes=lower<=0<=upper))
        assert (floor<=20)==(lower<=upper)
    rows("constraint-floor.csv",results)
    for grid in (80,160,320):
        group=[r for r in results if r["cells_per_mpc"]==grid and r["seed"]==1 and r["fraction"]==1]
        if group:
            print(grid,[(r["scheme"],r["width"],round(r["predicted_common_error_ppm"],3),round(r["half_separation_ppm"],3)) for r in group])


if __name__=="__main__":
    main()
