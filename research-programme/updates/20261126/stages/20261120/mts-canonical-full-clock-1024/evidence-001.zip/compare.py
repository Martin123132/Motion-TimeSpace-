from scope import *
from readouts import rms


def main():
    materials=[]
    tides=[]
    profiles=[]
    for scheme in SCHEMES:
        for seed in SIGNS:
            for quarter in range(1,5):
                group={}
                for count in (128,512,16384,32768):
                    name=f"read-{scheme}-s{seed}-n{count}-t{count*quarter//4}"
                    if not (HERE/(name+".npz")).exists():
                        continue
                    materials+=core.read(HERE/(name+"-matter.csv"))
                    subset=core.read(HERE/(name+"-gravity.csv"))
                    tides+=subset
                    group[count]=(name,subset)
                for trial,reference in ((128,512),(128,16384),(512,16384),(16384,32768),(512,32768)):
                    if trial not in group or reference not in group:
                        continue
                    first,second=[group[count][0] for count in (trial,reference)]
                    with np.load(HERE/(first+".npz")) as coarse,np.load(HERE/(second+".npz")) as fine:
                        np.testing.assert_array_equal(coarse["r"],fine["r"])
                        for key in ("charge","rate","phase","total","ham","mom_r","mom_theta","normal_momentum","excitation_momentum","log_velocity"):
                            cfield=coarse[key]
                            ffield=fine[key]
                            for ell,(left,right) in enumerate(zip(np.atleast_2d(cfield),np.atleast_2d(ffield),strict=True)):
                                if key=="mom_theta" and not ell:
                                    continue
                                norm=rms(right)
                                diff=rms(left-right)
                                profiles.append(dict(scheme=scheme,seed=seed,fraction=quarter/4,trial=trial,reference=reference,
                                    observable=key,ell=2*ell,rms=norm,difference=diff,relative=diff/norm))
    lookup={(r["scheme"],r["seed"],r["fraction"],r["steps"],r["width"],r["channel"]):r for r in tides}
    newton={(r["seed"],r["fraction"],r["width"]):float(r["newton"]) for r in core.read(HERE/"predicted-gravity.csv")}
    for (scheme,seed,frac,steps,width,ch),r in lookup.items():
        unit=abs(newton[seed,frac,width])*1e-6
        for key,other in (("readout",(scheme,seed,frac,steps,width,("gauss" if ch=="ricci" else "ricci"))),
                          ("form",("original" if scheme=="adm" else "adm",seed,frac,steps,width,ch)),
                          ("vs128",(scheme,seed,frac,"128",width,ch)),("vs512",(scheme,seed,frac,"512",width,ch)),
                          ("vs_resolved",(scheme,seed,frac,"16384",width,ch)),("vs_finer",(scheme,seed,frac,"32768",width,ch))):
            r[key+"_ppm"]=(float(r["tide"])-float(lookup[other]["tide"]))/unit if other in lookup else ""
        r["within_prediction_gate"]=abs(float(r["live_ppm"]))<=20
    rows("all-matter.csv",materials)
    rows("all-tides.csv",tides)
    rows("resolution.csv",profiles)


if __name__=="__main__":
    main()
