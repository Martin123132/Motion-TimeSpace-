from scope import *
import argparse
from endpoints import D, convert
import ref_endpoint
import phase_stride
from readouts import fields, incremental, joined, member_readings, rms, with_number
from source_terms import RadialOperators, profile
from judge import momenta


def canonical_reader(shell, start, change, original):
    base = ref_endpoint.convert
    phase = start[14].imag
    def replace(value):
        raw = base(value)
        if not shell.flag and isinstance(value,np.ndarray) and value.shape==phase.shape and value.strides==phase.strides and value.ctypes.data==phase.ctypes.data:
            raw[0] = D(float(shell.mu))*base(start[13,0].real)
        return raw
    with patch.object(ref_endpoint,"convert",replace):
        return original(shell,start,change)


def observation(scheme,seed,steps,end,forecast):
    digest = check_freeze()
    getcontext().prec = 46
    table = {}
    probes = {}
    archive = {}
    velocities = {}
    for flag in (0,1):
        model = Evolution(1,seed,scheme) if flag else Canonical(seed,scheme)
        zero,host=model.zero,model.host
        name=f"{scheme}-s{seed}-off{flag}-n{steps}-t{end}.npz"
        cert=json.loads((HERE/(name+".json")).read_bytes())
        assert cert["freeze"] == digest and cert["tick"]==end and core.sha(HERE/name)==cert["sha"]
        with np.load(HERE/name) as result:
            value=Difference(result["shared"],result["signed"])
            time=float(result["step"])*end
            assert result["end"]==end
        physical=value if flag else model.to_wave(value)
        if not flag:
            for quantity,array in momenta(model.shell.initial,physical,host.mu).items():
                velocities[quantity]=array[:,(host.r>.6)&(host.r<2.1)]
        slot=12 if flag else 14
        number=(value[slot].real)
        radii=host.r
        use=(radii>.6)&(radii<2.1)
        rho=D(float(host.rho[-1]))
        op=RadialOperators(radii,host.dx)
        if flag:
            rate=profile(host,physical,op)["dust"]-profile(zero,physical.base,op)["dust"]
            phase=convert(value.delta[13,0,use].real)
        else:
            def angular(shell,inc):
                def at(index):
                    return joined(shell.initial[index,0].real)+joined(inc[index,0].real)
                phase=joined(shell.initial[13,0].real)+joined(inc[14,0].imag)/D(float(shell.mu))
                return op.strong(at(0),at(1),at(14),phase)
            rate=angular(host,physical)-angular(zero,physical.base)
            phase=convert(value.delta[14,0,use].imag)/D(float(host.mu))
        archive["charge",flag]=rho*convert(number.delta[0,use])
        archive["rate",flag]=rho*rate[use]
        archive["phase",flag]=phase
        for shell,shift,ref in ((host,physical,number),(zero,physical.base,number.base)):
            source=fields(shell,np.zeros_like(shell.initial))
            diag=incremental(shell,shift,source)
            if not flag:
                diag=with_number(shell,shift,ref,diag)
            for key in ("total","ham","mom_r","mom_theta"):
                namekey=key,flag
                if shell is host:
                    archive[namekey]=diag[key][:,use]
                else:
                    archive[namekey]-=diag[key][:,use]
        original=ref_endpoint.fixed_tide
        for view in (("archived",) if flag else ("archived","canonical")):
            def read(shell,start,change):
                return canonical_reader(shell,start,change,original)
            active=read if view=="canonical" else original
            with patch.object(ref_endpoint,"fixed_tide",active),patch.object(phase_stride,"fixed_tide",active):
                off=member_readings(zero,time,physical.base)
                on=member_readings(host,time,physical)
            for key in on:
                table[flag,view,*key]=on[key]-off[key]
                if flag:
                    table[flag,"canonical",*key]=table[flag,view,*key]
    fraction=end/steps
    outputs={key:(archive[key,0]-archive[key,1]).astype(float) for key,flag in archive if flag==0}
    outputs.update(velocities)
    for flag in (0,1):
        outputs[f"phase_{flag}"]=archive["phase",flag].astype(float)
    gravity=[]
    tests=[]
    idx=round(4*fraction)-1
    assert (idx+1)/4==fraction
    with np.load(HERE/f"frozen-current-{scheme}-s{seed}.npz") as pred:
        for key in ("charge","rate"):
            actual=outputs[key]
            prefix=f"window{idx}_{key}_"
            expected=pred[prefix+"changing"]+(pred[prefix+"canonical_launch"]-pred[prefix+"launch"])
            tests.append(dict(scheme=scheme,seed=seed,steps=steps,fraction=fraction,observable=key,signal=rms(actual),
                              difference=rms(actual-expected),relative=rms(actual-expected)/rms(actual)))
    for width in (.15,.3):
        blank=forecast[seed,width,fraction,"flat-clock"]
        live=forecast[seed,width,fraction,"flrw-live"]
        for channel in ("gauss","ricci"):
            def val(view):
                return table[0,view,width,channel]-table[1,view,width,channel]
            tide=val("canonical")
            unit=abs(live[0])*1e-6
            gravity.append(dict(scheme=scheme,seed=seed,steps=steps,fraction=fraction,width=width,channel=channel,tide=tide,
                              newton_ppm=(tide-live[0])/unit,frozen_ppm=(tide-blank[1])/unit,
                              live_ppm=(tide-live[1])/unit,reader_effect_ppm=(tide-val("archived"))/unit))
    prefix=f"read-{scheme}-s{seed}-n{steps}-t{end}"
    pack(prefix+".npz",r=radii[use],**outputs)
    rows(prefix+"-matter.csv",tests)
    rows(prefix+"-gravity.csv",gravity)
    print(prefix,"live gravity ppm",max(abs(row["live_ppm"]) for row in gravity),
          "charge forecast",tests[0]["relative"],flush=True)


def main():
    cli=argparse.ArgumentParser()
    cli.add_argument("steps",type=int,nargs="+")
    args=cli.parse_args()
    forecast={(int(row["seed"]),float(row["width"]),float(row["fraction"]),row["mode"]):(float(row["newton"]),float(row["prediction"]))
              for row in core.read(HERE/"predicted-gravity.csv")}
    for steps in args.steps:
        for scheme,seed in ((scheme,seed) for scheme in SCHEMES for seed in SIGNS):
            for end in range(steps//4,steps+1,steps//4):
                prefix=f"read-{scheme}-s{seed}-n{steps}-t{end}"
                needed=[HERE/f"{scheme}-s{seed}-off{flag}-n{steps}-t{end}.npz.json" for flag in (0,1)]
                if all(path.is_file() for path in needed) and not (HERE/(prefix+"-gravity.csv")).exists():
                    observation(scheme,seed,steps,end,forecast)


if __name__=="__main__":
    main()
