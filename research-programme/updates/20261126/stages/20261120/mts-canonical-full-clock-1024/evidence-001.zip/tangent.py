from scope import *
from scipy.linalg import svd
import constraint_floor


def main():
    getcontext().prec=46
    size=40
    grid=160
    with patch.object(case.parent.evolve_speed,"launch",case.parent.launch):
        shell=case.parent.evolve_speed.system(1024,grid,1,0,"original",3)[0]
    with np.load(HERE/"mode-160-original-40.npz") as bank:
        operator,le,ri=bank["matrix"],bank["left"].real,bank["dominant"].real
    def point(vec):
        change=np.zeros_like(shell.initial)
        values=vec.reshape(8,size)
        change[:4,1,:size]=values[:4]
        change[4:8,1,:size]=values[4:]/shell.dx
        return change
    keys=("ham","mom_r","mom_theta")
    kept=size+8
    def check(vec,decimal=False):
        change=point(vec)
        if decimal:
            snapshots=[constraint_floor.components(shell,mult*change) for mult in (1,-1)]
        else:
            snapshots=[shell.dynamics(0.,shell.initial+mult*change,True) for mult in (1,-1)]
        return np.concatenate([.5*shell.dx**2*(snapshots[0][key]-snapshots[1][key])[1,:kept].astype(float) for key in keys])
    columns=np.zeros((3*kept,8*size))
    for idx in range(8*size):
        if not idx%16:guard()
        trial=np.zeros(8*size)
        trial[idx]=1.
        columns[:,idx]=check(trial)
    probe=check(ri,True)
    difference=np.linalg.norm(columns@ri-probe)/np.linalg.norm(probe)
    assert difference<1e-9,difference
    results=[]
    witnesses={}
    radii=np.tile(np.arange(size)+.5,8)
    for inner in (0,8):
        active=(radii>=inner)&(radii<size-8)
        weights=radii[active]
        basis=columns[:,active]/weights
        _,singular,vh=svd(basis,full_matrices=True)
        scale=singular[0]
        target=le[active]/weights
        for rtol in (1e-10,1e-12,1e-13):
            rank=np.count_nonzero(singular>rtol*scale)
            kernel=vh[rank:].T
            maxvec=kernel@(kernel.T@target)
            norm=np.linalg.norm(maxvec)
            assert norm>0
            vec=np.zeros(8*size)
            vec[active]=maxvec/(norm*weights)
            now=check(vec,True)
            rate=check(operator@vec,True)
            ratio=norm/np.linalg.norm(target)
            results.append(dict(first_cell=inner,last_cell=size-9,tolerance=rtol,rank=rank,nullity=kernel.shape[1],norm=norm,
                coupling_relative_to_same_support=ratio,absolute_left_overlap=abs(le@vec),initial_constraint=np.linalg.norm(now),
                constraint_rate_in_cell_time=np.linalg.norm(rate),matrix_vs_decimal_on_eigenvector=difference))
            if rtol==1e-12:
                witnesses[f"field_from_cell{inner}"]=vec
                witnesses[f"initial_constraints{inner}"]=now
                witnesses[f"rate_constraints{inner}"]=rate
            assert abs(norm-abs(le@vec))<5e-14
    rows("admissible-launch-witness.csv",results)
    pack("admissible-launch-witness.npz",constraints=columns,radii=radii,**witnesses)
    print(results[4],flush=True)


if __name__=="__main__":
    main()
