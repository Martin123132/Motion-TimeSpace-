from scope import *
from functools import lru_cache
from scipy.integrate import simpson
from readouts import rms


@lru_cache(maxsize=128)
def coefficients(omega,step):
    import mpmath as mp
    with mp.workdps(55):
        arg = 1j*mp.mpf(omega)*mp.mpf(step)
        first = mp.expm1(arg)/arg
        second = (first-1)/arg
        return complex(mp.exp(arg)),complex(step*(first-second)),complex(step*second)


def propagate(times,force,omega):
    velocity=np.zeros_like(force[0],dtype=complex)
    for left,right,before,after in zip(times[:-1],times[1:],force[:-1],force[1:],strict=True):
        phase,a,b=coefficients(float(omega),float(right-left))
        velocity=phase*velocity+a*before+b*after
    return velocity


def fixture():
    import mpmath as mp
    records=[]
    with mp.workdps(55):
        for turns in (0.27, 17., 1024.):
            omega=2*np.pi*turns
            ends=np.linspace(0,1,33)
            f=(.37+.19j)+(-.15+.4j)*ends
            true=(.37+.19j)*mp.expm1(1j*omega)/(1j*omega)+(-.15+.4j)*(mp.expm1(1j*omega)/(1j*omega)-1)/(1j*omega)
            true_int=(true-(.37+.19j)-(-.15+.4j)/2)/(1j*omega)
            actual=propagate(ends,f,omega)
            integral=(np.trapezoid(f.real,ends)-actual.real)/omega
            assert abs(actual-complex(true))<2e-14 and abs(integral-float(true_int.imag))<2e-14
            records.append(dict(turns=turns,velocity_error=abs(actual-complex(true)),phase_error=abs(integral-float(true_int.imag))))
    rows("affine-controls.csv",records)


def source(scheme,seed,count,target,flag):
    read=[]
    stride=min(256,count//4)
    last=None
    for tick in range(stride,target+1,stride):
        name=f"{scheme}-s{seed}-off{flag}-n{count}-t{tick}.npz"
        assert core.sha(HERE/name)==json.loads((HERE/(name+".json")).read_bytes())["sha"]
        with np.load(HERE/name) as bank:
            current=[bank[key] for key in ("times","drive","charge_rate")]
            if last is not None:
                for before,after in zip(last,current,strict=True):
                    np.testing.assert_array_equal(before,after[0])
            read.append([values[1:] if last is not None else values for values in current])
            last=[values[-1] for values in current]
    return [np.concatenate(column) for column in zip(*read,strict=True)]


def main():
    fixture()
    results=[]
    for scheme in SCHEMES:
        for seed in SIGNS:
            model=Canonical(seed,scheme)
            use=(model.shell.r>.6)&(model.shell.r<2.1)
            omega=2*model.shell.mu
            launch=model.shell.initial.delta[15,0,use].imag
            for coarse,fine in ((128,512),(128,16384),(512,16384)):
                for quarter in range(1,5):
                    target=fine*quarter//4
                    prefix=f"read-{scheme}-s{seed}-n{fine}-t{target}"
                    if not (HERE/(prefix+".npz")).exists():
                        continue
                    with np.load(HERE/(prefix+".npz")) as bank:
                        actual={key:bank[key] for key in ("phase","charge","rate")}
                    tm,wave,wrate=source(scheme,seed,coarse,coarse*quarter//4,0)
                    tc,cold,crate=source(scheme,seed,coarse,coarse*quarter//4,1)
                    np.testing.assert_array_equal(tm,tc)
                    for approximation in ("constant","linear"):
                        wf=wave if approximation=="linear" else np.broadcast_to(wave[0],wave.shape)
                        cf=cold if approximation=="linear" else np.broadcast_to(cold[0],cold.shape)
                        forcing=wf.real+omega*(launch-cf.real)
                        phase=(np.trapezoid(forcing,x=tm,axis=0)-propagate(tm,wf,omega).real)/omega
                        key="phase"
                        results.append(dict(scheme=scheme,seed=seed,input_steps=coarse,target_steps=fine,
                               fraction=quarter/4,observable=key,method=approximation,signal=rms(actual[key]),
                               relative=rms(phase-actual[key])/rms(actual[key])))
                    derivative=wrate-crate
                    for method,charge in (("linear-flux",np.trapezoid(derivative,x=tm,axis=0)),("quadratic-flux",simpson(derivative,x=tm,axis=0))):
                        results.append(dict(scheme=scheme,seed=seed,input_steps=coarse,target_steps=fine,
                               fraction=quarter/4,observable="charge",method=method,signal=rms(actual["charge"]),
                               relative=rms(charge-actual["charge"])/rms(actual["charge"])))
    rows("source-transfer.csv",results)


if __name__=="__main__":
    main()
