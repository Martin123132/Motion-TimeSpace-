import csv
import io
import json
import os
import sys
from decimal import getcontext
from pathlib import Path
from unittest.mock import patch

HERE = Path(__file__).resolve().parent
LAST = HERE.parent / "mts-host-secant-evolution-20261120"
SPEED = HERE.parent / "mts-independent-speed-128-20261120"
sys.path.insert(0, str(LAST))
import case
from case import Difference, core, np
from canonical import Canonical
from coupled import Evolution

TURNS = (1024, 2048, 3072, 4096)
SCHEMES = ("original", "adm")
SIGNS = (1, -1)


def guard():
    case.guard()
    if (HERE / "STOP-REQUESTED").exists():
        raise RuntimeError("Owner hold")


def locked():
    guard()
    assert core.sha(LAST / "seal.json") == "3003c00c87119c41dab0a4ea401ff4729540ad154b2be3e8cbd51b3fe8edab2f"
    for name, digest in json.loads((LAST / "seal.json").read_bytes())["files"].items():
        assert core.sha(LAST / name) == digest, name
    case.checked()


def write(name, raw):
    guard()
    path = HERE / name
    if path.exists():
        assert path.read_bytes() == raw, name
        return
    temporary = path.with_name(path.name + ".partial")
    with temporary.open("xb") as stream:
        stream.write(raw)
        stream.flush()
        os.fsync(stream.fileno())
    temporary.rename(path)


def pack(name, **data):
    stream = io.BytesIO()
    np.savez_compressed(stream, **data)
    write(name, stream.getvalue())


def rows(name, data):
    stream = io.StringIO(newline="")
    writer = csv.DictWriter(stream, fieldnames=list(data[0]), lineterminator="\n")
    writer.writeheader()
    writer.writerows(data)
    write(name, stream.getvalue().encode())


def record(name, obj):
    write(name, (json.dumps(obj, indent=2, allow_nan=False) + "\n").encode())


def check_freeze():
    manifest = json.loads((HERE / "freeze.json").read_bytes())
    for name, digest in manifest["files"].items():
        assert core.sha(HERE / name) == digest, name
    return core.sha(HERE / "freeze.json")
