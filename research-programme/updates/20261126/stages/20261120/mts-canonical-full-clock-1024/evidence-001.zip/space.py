from scope import *
from functools import partial
import argparse
import phase_stride
import ref_endpoint
import worker
from read_clock import canonical_reader
from readouts import member_readings


def main():
    cli=argparse.ArgumentParser()
    cli.add_argument("grid",type=int,choices=(80,240,320))
    cli.add_argument("scheme",choices=SCHEMES)
    args=cli.parse_args()
    grid,scheme=args.grid,args.scheme
    locked()
    digest=check_freeze()
    folder=HERE/f"space-{grid}"
    folder.mkdir(exist_ok=True)
    def system(flag,seed,scheme):
        with patch.object(case.parent.evolve_speed,"launch",case.parent.launch):
            return case.parent.evolve_speed.system(1024,grid,flag,seed,scheme,3)[0]
    def send_packet(name,**values):
        pack(folder.name+"/"+name,**values)
    def send_record(name,obj):
        record(folder.name+"/"+name,obj)
    forecast={(int(row["seed"]),float(row["width"]),float(row["fraction"])):(float(row["newton"]),float(row["prediction"]))
              for row in core.read(HERE/"predicted-gravity.csv") if row["mode"]=="flrw-live"}
    findings=[]
    steps=512
    seed=1
    with patch.object(case.parent,"system",system),patch.object(worker,"HERE",folder),patch.object(worker,"pack",send_packet),patch.object(worker,"record",send_record):
        for flag in (0,1):
            worker.evolve(scheme,seed,flag,steps,steps)
        value={}
        for flag in (0,1):
            model=Evolution(1,seed,scheme) if flag else Canonical(seed,scheme)
            for tick in range(128,513,128):
                name=f"{scheme}-s{seed}-off{flag}-n512-t{tick}.npz"
                receipt=json.loads((folder/(name+".json")).read_bytes())
                assert receipt["freeze"]==digest and receipt["tick"]==tick and core.sha(folder/name)==receipt["sha"]
                with np.load(folder/name) as bank:
                    stored=Difference(bank["shared"],bank["signed"])
                    assert stored.shape[-1]==3*grid
                    clock=tick*float(bank["step"])
                physical=stored if flag else model.to_wave(stored)
                original=ref_endpoint.fixed_tide
                def precise(shell,start,change):
                    return canonical_reader(shell,start,change,original)
                with patch.object(ref_endpoint,"fixed_tide",precise),patch.object(phase_stride,"fixed_tide",precise):
                    raw=member_readings(model.host,clock,physical)
                    zero=member_readings(model.zero,clock,physical.base)
                for key in raw:
                    value[tick,flag,*key]=raw[key]-zero[key]
        for tick in range(128,513,128):
            for width in (.15,.30):
                ref,pred=forecast[seed,width,tick/512]
                for channel in ("gauss","ricci"):
                    tide=value[tick,0,width,channel]-value[tick,1,width,channel]
                    findings.append(dict(grid=grid,scheme=scheme,fraction=tick/512,width=width,channel=channel,tide=tide,
                        live_ppm=(tide-pred)/(abs(ref)*1e-6),newton_ppm=(tide-ref)/(abs(ref)*1e-6)))
    rows(f"space-{grid}-{scheme}.csv",findings)
    print("space",grid,scheme,"maximum",max(abs(r["live_ppm"]) for r in findings),flush=True)


if __name__=="__main__":
    main()
