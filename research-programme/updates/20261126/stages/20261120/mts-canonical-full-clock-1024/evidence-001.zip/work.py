from scope import *
from endpoints import convert
from readouts import joined,rms
from scipy.integrate import simpson


def work(scheme,seed,count,target):
    accum={}
    for flag in (0,1):
        model=Evolution(1,seed,scheme) if flag else Canonical(seed,scheme)
        shell=model.shell
        signed=[]
        times=[]
        stride=min(256,count//4)
        start=shell.initial
        use=(shell.r>.6)&(shell.r<2.1)
        for tick in range(0,target+1,stride):
            if tick:
                name=f"{scheme}-s{seed}-off{flag}-n{count}-t{tick}.npz"
                assert core.sha(HERE/name)==json.loads((HERE/(name+".json")).read_bytes())["sha"]
                with np.load(HERE/name) as data:
                    shift=Difference(data["shared"],data["signed"])
                    time=tick*float(data["step"])
            else:
                shift=np.zeros_like(start)
                time=0.
            state=start+shift
            trace=state[4,0].real
            ell,bend=state[0,0].real,state[1,0].real
            volume=np.exp(ell+2*bend)
            pressure=shell.incident.at(time)[1]/3
            radial_current=state[18,0].real
            section=shell.faces**2*np.exp(shell.toface(2*bend))*shell.toface(radial_current,odd=True)
            source=volume*trace*pressure
            flux=-shell.tocell(section)/shell.r**2
            vol0=np.exp(start[0,0].real+2*start[1,0].real)
            logratio=shift[0,0].real+2*shift[1,0].real
            stored=vol0*(np.expm1(logratio)*start[17,0].real+np.exp(logratio)*shift[17,0].real)
            signed.append([obj.delta[use] for obj in (stored,source,flux)])
            times.append(time)
        accum[flag]=np.asarray(signed)
    actual,stress,flux=(accum[0]-accum[1]).transpose(1,0,2)
    full=[]
    for label,func in (("trapezoid",np.trapezoid),("parabolic",simpson)):
        pressure_work,transport=(func(value,x=times,axis=0) for value in (stress,flux))
        total=pressure_work+transport
        error=rms(actual[-1]-total)
        full.append(dict(scheme=scheme,seed=seed,steps=count,fraction=target/count,panels=len(times)-1,method=label,
                         energy=rms(actual[-1]),work=rms(pressure_work),transport=rms(transport),residual=error,
                         relative_balance=error/rms(actual[-1]),relative_gross=error/(rms(pressure_work)+rms(transport))))
    return full


def main():
    results=[]
    getcontext().prec=46
    for scheme in SCHEMES:
        for seed in SIGNS:
            for count,target in ((128,128),(512,512),(16384,4096)):
                name=f"read-{scheme}-s{seed}-n{count}-t{target}.npz"
                if (HERE/name).exists():
                    results+=work(scheme,seed,count,target)
    rows("surrounding-work.csv",results)


if __name__=="__main__":
    main()
