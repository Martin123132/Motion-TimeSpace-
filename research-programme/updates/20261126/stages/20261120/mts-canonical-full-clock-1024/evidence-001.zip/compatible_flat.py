from scope import *
from scipy.linalg import svd
from readouts import rms
import sympy as sym


def geometric_rates(momentum):
    trace,shear,cross,tensor=momentum
    return np.array([-trace/3-shear,-trace/3+shear/2,-2*cross,-2*tensor])


def inverse_rates(metric):
    ell,bend,tilt,tensor=metric
    return np.array([-ell-2*bend,2*(bend-ell)/3,-tilt/2,-tensor/2])


def momentum(shell,extrinsic):
    trace,shear,cross,tensor=extrinsic
    radial=shell.diff(shear-2*trace/3)+(3*shear-6*cross)/shell.r
    polar=shell.diff(cross)+(3*cross-shear/2-2*tensor-2*trace/3)/shell.r
    section=shell.faces**2*shell.toface(shear-2*trace/3,slope=True)+shell.faces*shell.toface(3*shear-6*cross)
    return radial,polar,section


def scalar(shell,metric):
    ell,bend,tilt,tensor=metric
    rad=shell.r
    legacy=-4*shell.diff(bend,2)+(4*shell.diff(ell)-12*shell.diff(bend)-12*shell.diff(tilt))/rad+(16*ell+8*bend+12*tensor-24*tilt)/rad**2
    radial,polar,section=momentum(shell,inverse_rates(metric))
    def divergence(face):
        return -2*(shell.tocell(face)/rad**2-6*polar/rad)
    collocated=divergence(shell.faces**2*shell.toface(radial,odd=True))
    staggered=divergence(section)
    return legacy,collocated,staggered


def main():
    from stagger import Stagger
    getcontext().prec=46
    shell=case.parent.system(1,0,"original")
    import constraint_floor
    shell.initial=np.zeros_like(shell.initial)
    shell.rho=np.zeros_like(shell.rho)
    shell.ref_geometry=tuple(tuple(np.zeros_like(shell.r)[None,:].repeat(2,axis=0) for _ in range(3)) for _ in range(2))
    def identity(sample):
        geometry=geometric_rates(sample)
        old,col,stg=scalar(shell,geometry)
        radial,polar,face=momentum(shell,sample)
        return old,col,stg,radial,polar,face
    size=40
    points=np.arange(len(shell.r))
    inside=(points>=8)&(points<32)
    cols=np.array([(np.eye(4)[i,:,None]*(points==k)) for i in range(4) for k in points[inside]])/shell.dx
    def matrices(method):
        arrays=[identity(vec) for vec in cols]
        def stacked(pair):
            old,col,stg,radial,polar,face=pair
            if method=="legacy":
                return np.r_[radial[:48],polar[:48]]*shell.dx**2
            safe=face[1:49]/shell.faces[1:49]**2
            return np.r_[safe,polar[:48]]*shell.dx**2
        coeff=np.stack([stacked(obj) for obj in arrays],axis=1)
        _,sv,vh=svd(coeff,full_matrices=True)
        rank=np.count_nonzero(sv>1e-12*sv[0])
        kernel=vh[rank:].T
        leak=np.stack([obj[0][:48] for obj in arrays],axis=1)*shell.dx**3
        _,_,worst=svd(leak@kernel,full_matrices=False)
        witness=np.einsum("i,ijk->jk",kernel@worst[0],cols)
        return witness,rank,kernel.shape[1]
    tests=[]
    for name in ("legacy","staggered"):
        witness,rank,nullity=matrices(name)
        old,col,stg,radial,polar,face=identity(witness)
        delta=np.zeros_like(shell.initial)
        delta[4:8,1]=witness
        geo=np.zeros_like(delta)
        geo[:4,1]=geometric_rates(witness)
        real=constraint_floor.components(shell,delta)
        real_rate=constraint_floor.components(shell,geo)
        scalar_rate=real_rate["ham"][1].astype(float)
        err=max(np.max(abs(shell.dx**3*(scalar_rate-old))),np.max(abs(shell.dx**2*(real["mom_r"][1].astype(float)-radial))),
                np.max(abs(shell.dx**2*(real["mom_theta"][1].astype(float)-polar))))
        assert err<1e-11,err
        tracked=(radial if name=="legacy" else face[1:]/shell.faces[1:]**2)
        init=np.linalg.norm(np.r_[tracked,polar])*shell.dx**2
        compatible=np.linalg.norm(col if name=="legacy" else stg)*shell.dx**3
        oldnorm=np.linalg.norm(old)*shell.dx**3
        assert init<1e-11 and compatible<1e-10 and oldnorm>1e-4
        tests.append(dict(momentum_layout=name,rank=rank,nullity=nullity,initial_constraint=init,
                          existing_H_rate=oldnorm,composed_H_rate=compatible,independent_state_error=err))
    rows("flat-identity-witness.csv",tests)
    radius=sym.symbols("r",positive=True)
    tensor=sym.exp(-radius**2)
    tilt=tensor+radius**2*sym.exp(-.6*radius**2)/3
    shear=2*tilt-tensor/2+radius**4*sym.exp(-.8*radius**2)/5
    trace=radius**2*sym.exp(-.5*radius**2)/7
    ell,bend=(trace+2*shear)/3,(trace-shear)/3
    exact=-4*sym.diff(bend,radius,2)+(4*sym.diff(ell,radius)-12*sym.diff(bend,radius)-12*sym.diff(tilt,radius))/radius+(16*ell+8*bend+12*tensor-24*tilt)/radius**2
    formula=sym.lambdify(radius,[ell,bend,tilt,tensor,sym.simplify(sym.expand(exact))],"numpy")
    samples=[]
    for cells in (20,40,80,160):
        grid=Stagger.__new__(Stagger)
        grid.dx=1/cells
        grid.r=(np.arange(3*cells)+.5)/cells
        vals=formula(grid.r)
        use=grid.r<1.6
        bulk=(grid.r>.32)&use
        legacy,col,stg=scalar(grid,vals[:4])
        alt=(-1.)**np.arange(len(grid.r));none=alt*0
        checker=scalar(grid,(none,alt,none,none))
        for label,field,check in zip(("existing","collocated","staggered"),(legacy,col,stg),checker,strict=True):
            error=field-vals[-1]
            samples.append(dict(cells_per_mpc=cells,operator=label,weighted_relative=rms((grid.r*error)[use])/rms((grid.r*vals[-1])[use]),
                bulk_max_absolute=max(abs(error[bulk])),centre_absolute=abs(error[0]),
                nyquist_strength_vs_existing=rms(check[bulk])/rms(checker[0][bulk])))
    rows("flat-manufactured.csv",samples)
    print(tests,samples[-3:],flush=True)


if __name__=="__main__":
    main()
