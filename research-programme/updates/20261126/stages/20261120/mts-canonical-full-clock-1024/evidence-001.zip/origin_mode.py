from scope import *
from scipy.linalg import eig
import argparse


def main():
    cli=argparse.ArgumentParser()
    cli.add_argument("grid",type=int)
    cli.add_argument("scheme",choices=SCHEMES)
    cli.add_argument("size",type=int)
    args=cli.parse_args()
    grid,scheme,size=args.grid,args.scheme,args.size
    def system(flag,seed,scheme):
        with patch.object(case.parent.evolve_speed,"launch",case.parent.launch):
            return case.parent.evolve_speed.system(1024,grid,flag,seed,scheme,3)[0]
    with patch.object(case.parent,"system",system):
        model=Evolution(1,1,scheme)
    h=model.shell.dx
    def scaled(field):
        return np.vstack((field[:4,1,:size].real,h*field[4:8,1,:size].real)).ravel()
    state=np.zeros_like(model.shell.initial)
    nominal=model.rhs(0.,state)
    matrix=np.empty((8*size,8*size))
    def evaluate(vec):
        shift=np.zeros_like(model.shell.initial)
        physical=vec.reshape(8,size).copy()
        physical[4:]/=h
        shift.base[:8,1,:size]=physical
        return h*scaled(model.rhs(0.,shift).base-nominal.base)
    for column in range(8*size):
        if not column%16:guard()
        vector=np.zeros(8*size)
        vector[column]=1.
        matrix[:,column]=evaluate(vector)
    test=np.sin(np.arange(8*size)*1.272)
    linear=np.linalg.norm(evaluate(test*1e-5)-1e-5*(matrix@test))/np.linalg.norm(evaluate(test*1e-5))
    assert linear<1e-10,linear
    eigen,left,right=eig(matrix,left=True,right=True)
    idx=np.argmax(eigen.real)
    lam=eigen[idx]
    mode=right[:,idx]
    lmode=left[:,idx]
    residual=np.linalg.norm(matrix@mode-lam*mode)/np.linalg.norm(mode)
    assert residual<1e-10
    cond=np.linalg.norm(mode)*np.linalg.norm(lmode)/abs(np.vdot(lmode,mode))
    sections=mode.reshape(8,size)
    width=np.cumsum(np.sum(abs(sections)**2,axis=0))
    inside=np.searchsorted(width,.99*width[-1])+1
    folder=HERE if grid==160 else HERE/f"space-{grid}"
    records=[]
    for flag in (0,1):
        last=None
        for tick in (128,256,384,512):
            name=f"{scheme}-s1-off{flag}-n512-t{tick}.npz"
            assert core.sha(folder/name)==json.loads((folder/(name+".json")).read_bytes())["sha"]
            with np.load(folder/name) as bank:
                vec=scaled(bank["signed"])
                signal=np.vdot(lmode,vec)
                now=tick*float(bank["step"])
                firstcell=abs(bank["signed"][0,1,0])
                select=(np.arange(bank["signed"].shape[-1])+.5)/grid
                detector=max(abs(bank["signed"][0,1,(select>.65)&(select<1.6)]))
            if last is not None:
                previous,at=last
                gain=abs(signal/previous)
                expected=float(np.exp(lam.real*(now-at)/h))
                records.append(dict(grid=grid,scheme=scheme,cells=size,flag=flag,last_fraction=tick/512,lambda_real=lam.real,
                    lambda_imag=lam.imag,condition=cond,eigen_residual=residual,linear_test=linear,mode_99_cells=inside,
                    observed_gain=gain,frozen_gain=expected,relative_gain_error=abs(gain/expected-1),
                    inferred_dimensionless_rate=np.log(gain)*h/(now-at),inner_quad=firstcell,interior_quad=detector))
            last=signal,now
    stem=f"mode-{grid}-{scheme}-{size}"
    pack(stem+".npz",matrix=matrix,eigen=eigen,dominant=mode,left=lmode)
    rows(stem+".csv",records)
    print(stem,lam,"support",inside,"last",records[-1],flush=True)


if __name__=="__main__":
    main()
