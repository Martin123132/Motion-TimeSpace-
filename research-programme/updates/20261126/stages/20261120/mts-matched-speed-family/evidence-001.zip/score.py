"""Separate a physical-speed scaling check, the independent Newton reference, and refinement errors."""
from family import *
from math import fsum


def read(path):
    with path.open(newline="") as stream:
        return list(csv.DictReader(stream))


def compute(tag,required=False):
    pathlist=sorted(HERE.glob(tag+"-off*-s*.csv"))
    if len(pathlist)!=6:
        if required:
            raise ValueError(tag)
        return []
    lookup={}
    for path in pathlist:
        for row in read(path):
            if row.get("stride","1")!="1":
                continue
            key=int(row["seed"]),int(row["flag"]),float(row["width"])
            assert key not in lookup
            lookup[key]=row
    assert len(lookup)==12
    native=int(row["native"]);grid=int(row["grid"]);level=float(row["level"])
    newton=read(pinned(f"newton-windows-h{native}-n{8 if native==5 else 4}.csv"))
    local=read(pinned(f"newton-normal-parts-h{native}-t{8 if native==5 else 4}.csv"))
    result=[]
    for seed in (1,-1):
        for width in FRACTIONS:
            ref=next(record for record in newton if int(record["seed"])==seed and float(record["width"])==width and record["quadrature"]=="16")
            restref=float(next(record["increment"] for record in local if int(record["seed"])==seed and float(record["width"])==width))
            normalized=float(ref["increment"]);start=float(ref["launch"])
            def paired(key):
                def val(host,flag):
                    return float(lookup[host,flag,width][key])
                return level*fsum((val(seed,0),-val(0,0),-val(seed,1),val(0,1)))
            fmt=lambda amount:1e6*amount/normalized
            gr,ricci=paired("gauss"),paired("ricci")
            parts={key:paired(key) for key in LABELS}
            result.append(dict(tag=tag,native=native,grid=grid,level=level,seed=seed,width=width,newton=normalized,
                gr=gr,ricci=ricci,excess_ppm=fmt(gr-normalized),ricci_excess_ppm=fmt(ricci-normalized),readout_split_ppm=fmt(ricci-gr),
                endpoint_minus_integral_ppm=fmt(paired("endpoint_gauss")-gr),initial_gr=paired("initial_gauss"),initial_newton=start,
                initial_error_ppm=(paired("initial_gauss")/start-1)*1e6,first_impulse_over_newton=paired("first_rate")*DURATION*np.sqrt(level)/normalized,
                last_impulse_over_newton=paired("last_rate")*DURATION*np.sqrt(level)/normalized,
                rest_ppm=fmt(parts["rest_dust"]+parts["rest_heavy"]-restref),
                geometry_ppm=fmt(parts["intrinsic"]+parts["extrinsic"]-(normalized-restref)),
                motion_ppm=fmt(sum(parts[key] for key in ("energy_dust","energy_heavy","stress_dust","stress_heavy"))),
                environment_ppm=fmt(parts["energy_environment"]+parts["stress_environment"]),
                budget_closure_ppm=fmt(sum(parts.values())-gr)))
    return result


def stage(write=False):
    results=[]
    for pattern in ("run-*-off1-s-1.csv","exp-*-off1-s-1.csv"):
        for path in sorted(HERE.glob(pattern)):
            results.extend(compute(path.name.split("-off")[0]))
    grids={}
    for row in results:
        tag=row["tag"]
        key=(tag.split("-q")[0],tag.split("-q")[1].split("-",1)[1],row["seed"],row["width"])
        grids.setdefault(key,{})[row["level"]]=row
    trends=[]
    for (method,integration,seed,width),data in grids.items():
        if not all(q in data for q in (1,2,4,8,25/8)):
            continue
        for channel in ("excess_ppm","ricci_excess_ppm","rest_ppm","geometry_ppm","motion_ppm","environment_ppm","initial_error_ppm"):
            values={q:r[channel] for q,r in data.items()}
            one,two,four,eight=(values[q] for q in (1,2,4,8))
            diff=four-eight
            extrap=2*eight-four
            predict=eight-(four+(four-two)/2)
            offcycle=values[25/8]-(four+(two-four)*((8/25-.25)/.25))
            trends.append(dict(method=method,integration=integration,seed=seed,width=width,channel=channel,E1=one,E2=two,E4=four,E8=eight,
                fixed_coefficient_error8=eight-one/8,affine_forecast_error8=predict,offcycle_interpolation_error=offcycle,
                factor=(two-four)/diff if diff else "undefined",intercept24=2*four-two,intercept48=extrap,
                within_20ppm=abs(extrap)<20))
    if write:
        assert trends
        save("paired-speed-check.csv",results)
        save("limiting-trends.csv",trends)
    for row in sorted(results,key=lambda item:(item["grid"],item["tag"][:3],item["level"])):
        if row["seed"]==1 and row["width"]==.15:
            print(row["tag"],*(round(row[key],4) for key in ("excess_ppm","ricci_excess_ppm","initial_error_ppm","rest_ppm","geometry_ppm","motion_ppm","environment_ppm")))
    return results,trends


if __name__=="__main__":
    stage("save" in sys.argv[1:])
