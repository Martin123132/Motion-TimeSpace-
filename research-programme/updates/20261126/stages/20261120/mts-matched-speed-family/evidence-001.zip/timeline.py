from speed_collocation import run,make
import sys


if __name__=="__main__":
    if sys.argv[1]=="extended":
        make(5,(16.,32.),"-extended")
        levels=(16.,32.)
    else:
        levels=tuple(map(float,sys.argv[1:]))
    for level in levels:
        for flag in (0,1):
            for seed in (0,1,-1):
                run(5,120,level,18,flag,seed,partials=True)
