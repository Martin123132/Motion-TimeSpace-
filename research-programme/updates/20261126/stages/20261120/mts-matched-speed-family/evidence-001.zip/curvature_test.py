"""Compare the mechanical forecast to curvature without inferring a stress coefficient."""
from score import read,fsum,save,TAG,HERE,FRACTIONS,DURATION,np,guard


def main():
    guard()
    forecast={(int(row["seed"]),float(row["width"])):float(row["forecast_ppm"]) for row in read(HERE/"mechanical-stress-forecast.csv") if row["order"]=="24" and row["edge"]=="120"}
    clock={(int(row["seed"]),int(row["flag"]),float(row["width"]),float(row["fraction"])):row for row in read(HERE/"newton-time-h5.csv")}
    rows=[];limits=[]
    for level in (2,4,8,16,32):
        paths=list(HERE.glob(f"times-exp-h5-n120-q{TAG(level)}-d18-p1-k4-off*-s*.csv"))
        assert len(paths)==6
        observed={(int(row["seed"]),int(row["flag"]),float(row["width"]),float(row["fraction"])):row for path in paths for row in read(path)}
        fractions=sorted({key[-1] for key in observed})
        for seed in (1,-1):
            for width in FRACTIONS:
                def pair(source,fraction,key):
                    return fsum([float(source[seed,0,width,fraction][key]),-float(source[seed,1,width,fraction][key])])
                norm=pair(clock,1.,"integral_total")
                for fraction in fractions:
                    def effect(key):
                        return level*fsum([pair(observed,fraction,key),-float(observed[0,0,width,fraction][key]),float(observed[0,1,width,fraction][key])])
                    start=(effect("first_rate")*np.sqrt(level)-pair(clock,0.,"rate_total"))*fraction*DURATION
                    excess=effect("gauss")-pair(clock,fraction,"integral_total")
                    curvature=(excess-start)*1e6/norm
                    guess=forecast[seed,width]*fraction**2
                    rows.append(dict(level=level,seed=seed,width=width,fraction=fraction,excess_ppm=excess*1e6/norm,
                        launch_ppm=start*1e6/norm,curvature_ppm=curvature,mechanical_forecast_ppm=guess,remaining_ppm=curvature-guess))
    lookup={(row["level"],row["seed"],row["width"],row["fraction"]):row for row in rows}
    for (level,seed,width,fraction),row in lookup.items():
        partner=lookup.get((level//2,seed,width,fraction))
        if not partner:continue
        curvature=2*row["curvature_ppm"]-partner["curvature_ppm"]
        limits.append(dict(upper_level=level,seed=seed,width=width,fraction=fraction,
            affine_curvature_ppm=curvature,launch_affine_ppm=2*row["launch_ppm"]-partner["launch_ppm"],
            mechanical_ppm=row["mechanical_forecast_ppm"],residual_ppm=curvature-row["mechanical_forecast_ppm"]))
    save("time-curvature.csv",rows);save("stress-versus-curvature.csv",limits)
    for row in limits:
        if row["fraction"]==1 and row["upper_level"]==32:print(row)


if __name__=="__main__":
    main()
