"""Independent Newtonian clock and exact Poisson source on fixed proper-time samples."""
from family import *
import clock_tide as clk
from window import weight,leggauss,CENTER
from scipy.optimize import brentq


def windows(native):
    targets=[]
    for width in FRACTIONS:
        half=CENTER*width
        knots=np.arange(0,3,1/native)
        knots=np.r_[CENTER-half,knots[(knots>CENTER-half)&(knots<CENTER+half)],CENTER+half]
        center=(knots[:-1]+knots[1:])/2;radius=np.diff(knots)/2
        nodes,weights=leggauss(16)
        points=(center[:,None]+radius[:,None]*nodes).ravel()
        targets.append((points,(weights*radius[:,None]).ravel()*weight(points,half)))
    return targets


def run(native=5):
    guard()
    sim=BalancedNative("heavy",120,120*native,False,"native36",clk.START+.00002)
    traces=clk.Traces("heavy",sim)
    sim.patch.coeff=lambda time:(float(traces.hubble(time-clk.START)),clk.SCALE*np.exp(time-clk.START))
    sim.ref.solution=lambda time:traces.histories(time-clk.START,"normal")
    spatial=clk.Kernel(sim.mesh);targets=windows(native);fractions=np.arange(33)/32
    clocks=[brentq(lambda time:float(traces.proper(time))-fraction*DURATION,0.,traces.proper.x[-1],xtol=5e-16) if fraction else 0. for fraction in fractions]
    logtimes=traces.log_time(clocks)
    lograte=traces.log_time(clocks,1)/traces.proper(clocks,1)
    matter=sim.patch.p.coeff/clk.SCALE
    matrices=[]
    for offset in logtimes:
        arr=[]
        for radii,weights in targets:
            radius=radii*np.exp(-offset)
            table=np.array([spatial.rows(float(r)) for r in radius])
            arr.append(np.stack([weights@table[:,0],(weights*radius)@table[:,1],*(weights@table[:,k] for k in (2,3,4))])*np.exp(-3*offset))
        matrices.append(arr)
    rows=[]
    for seed in (1,-1):
        name=f"evolved-heavy-L120-h{native}-t176.npz" if seed==1 else f"collar-heavy-L120-h{native}--1.npz"
        with np.load(checked(clk.FORM,name)) as arch:
            original=tuple(arch[name] for name in ("mono","density","velocity"))
        for flag in (0,1):
            sim.patch.wave=not flag
            summed=[np.zeros_like(comp) for comp in original]
            records=[]
            for idx,(fraction,offset,rate) in enumerate(zip(fractions,logtimes,lograte)):
                state=tuple(start+inc for start,inc in zip(original,summed))
                change=sim.rates(state,clk.START+offset)
                number=matter@state[1][flag];dnumber=matter@change[1][flag]
                observables=[]
                for matrix in matrices[idx]:
                    total,gradient,local,inner,outer=matrix
                    response=np.array([local@dnumber,inner@dnumber,outer@dnumber,-3*(total@number),-gradient@number])*rate
                    observables.append(np.r_[sum(response),response])
                records.append(observables)
                if idx==len(logtimes)-1:
                    break
                step=logtimes[idx+1]-offset
                slopes=[change]
                for prop in (.5,.5,1.):
                    mid=tuple(start+(inc+prop*step*slope) for start,inc,slope in zip(original,summed,slopes[-1]))
                    slopes.append(sim.rates(mid,clk.START+offset+prop*step))
                for inc,derivs in zip(summed,zip(*slopes)):
                    inc+=step*(derivs[0]+2*derivs[1]+2*derivs[2]+derivs[3])/6
            values=np.asarray(records)
            for idx in (0,4,8,12,16,20,24,28,32):
                integrals=simpson(values[:idx+1],dx=DURATION/32,axis=0) if idx else np.zeros_like(values[0])
                for width,raw,integrated in zip(FRACTIONS,values[idx],integrals):
                    row=dict(native=native,seed=seed,flag=flag,width=width,fraction=fractions[idx])
                    for pos,label in enumerate(("total","local_source","inner_source","outer_source","dilution","ruler")):
                        row["rate_"+label]=raw[pos];row["integral_"+label]=integrated[pos]
                    rows.append(row)
    save(f"newton-time-h{native}.csv",rows)


if __name__=="__main__":
    run(*map(int,sys.argv[1:]))
