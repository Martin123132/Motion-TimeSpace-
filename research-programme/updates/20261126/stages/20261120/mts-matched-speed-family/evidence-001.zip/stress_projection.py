"""Free-space mechanical TT forecast; finite exterior/regulator and manufactured checks."""
from family import *
from elements import Element
from constraint import strain,material
from window import weight,CENTER,leggauss
from scipy.interpolate import BarycentricInterpolator


def read(path):
    with path.open(newline="") as stream:
        return list(csv.DictReader(stream))


def project(mesh,tensor):
    radius=mesh.points
    measure=radius**2*mesh.w/2
    radial,mixed,angular_stress=tensor
    weighted=lambda data,basis:(measure*data)@basis
    right_r=2*weighted(radial,mesh.der)+weighted((12*mixed-2*radial)/radius,mesh.val)
    right_t=12*weighted(mixed,mesh.der)+weighted((6*radial-12*mixed+24*angular_stress)/radius,mesh.val)
    assemble=lambda data:np.bincount(mesh.ids.ravel(),weights=data.ravel(),minlength=mesh.size)
    right=np.r_[assemble(right_r),assemble(right_t)]
    solution=np.zeros_like(right)
    solution[mesh.vi]=mesh.vec_lu.solve(right[mesh.vi])
    val,der=mesh.evaluate(solution.reshape(2,-1))
    return tensor-np.asarray(strain(radius,(*val,*der)))


def integrate(grid,fields,width,order):
    half=CENTER*width
    nodes,weights=leggauss(order)
    bound=np.r_[CENTER-half,np.arange(grid.ne+1)*grid.h,CENTER+half]
    knots=np.unique(bound[(bound>=CENTER-half)&(bound<=CENTER+half)])
    span=np.diff(knots)/2
    pos=((knots[:-1]+span)[:,None]+span[:,None]*nodes).ravel()
    mass=(span[:,None]*weights).ravel()
    cells=(pos/grid.h).astype(int)
    poly=BarycentricInterpolator(grid.t,np.eye(len(grid.t)),rng=0)(pos/grid.h-cells)
    radial,mixed=(np.einsum("nq,nq->n",field[cells],poly) for field in fields[:2])
    win,prime,double=(weight(pos,half,degree) for degree in range(3))
    return np.dot(mass,radial*(double-2*prime/pos-10*win/pos**2)+mixed*24*win/pos**2)


def source(sim,seed,flag):
    ref,press,unused=pressure(flag)
    state,grid,shapes,extra=input_pack(sim,5,seed,flag,ref,press)
    data=material(shapes[0],grid.points,grid.evaluate,tuple(sim.mesh.grid(part) for part in state),flag)
    number,grad,speed=[jet(data[left],data[right]) for left,right in (("n","D"),("g","Dr"),("p","P"))]
    rho=ref["rh"][:,None,None]
    radial=(2/3)*angular((rho*number*speed**2).sum(axis=0))
    mixed=(rho*data["n"]*data["p"]*data["Pt"]).sum(axis=0)
    if not flag:
        idx=sim.patch.j
        eps=1/(4*(ref["a"]*sim.patch.p.mass)**2)
        radial+=(2/3)*eps*ref["rh"][idx]*angular(grad[idx]**2/number[idx])
        mixed+=eps*ref["rh"][idx]*data["g"][idx]*data["D"][idx]/(data["n"][idx]*grid.points)
    return np.array([radial,mixed,np.zeros_like(mixed)]),grid


def main():
    guard()
    sim=BalancedNative("heavy",120,600,False,"native36",SPAN*DLOG)
    inputs={}
    for seed in (0,1,-1):
        for flag in (0,1):
            inputs[seed,flag],base=source(sim,seed,flag)
    newton=read(pinned("newton-windows-h5-n8.csv"))
    rows=[];tests=[]
    for edge in (36,72,120):
        grid=base if edge==120 else Element(sim.mesh,edge,len(base.t))
        radius=grid.points
        gaussian=np.exp(-radius**2)
        radial=gaussian
        mixed=(3-2*radius**2)*gaussian/6
        ang=(3*mixed-radial/2+(-10*radius**2+4*radius**4)*gaussian/6)/2
        tensor=np.array((radial,mixed,ang))
        trans=project(grid,tensor)
        vec=radius**3*gaussian
        dv=(3*radius**2-2*radius**4)*gaussian
        longitudinal=np.array(strain(radius,(vec,vec/3,dv,dv/3)))
        remainder=project(grid,longitudinal)
        for width in FRACTIONS:
            nodes,mass=leggauss(64)
            pos=CENTER+nodes*CENTER*width
            target=mass@(weight(pos,CENTER*width)*(4*pos**2-14)*np.exp(-pos**2))*CENTER*width
            direct=integrate(grid,trans,width,24)
            longitudinal_rel=abs(integrate(grid,remainder,width,24)/integrate(grid,longitudinal,width,24))
            tests.append(dict(edge=edge,width=width,transverse_rel=abs(direct/target-1),longitudinal_rel=longitudinal_rel))
        for seed in (1,-1):
            raw=(inputs[seed,0]-inputs[0,0])-(inputs[seed,1]-inputs[0,1])
            projected=project(grid,raw[:,:grid.ne])
            for width in FRACTIONS:
                norm=float(next(row["increment"] for row in newton if int(row["seed"])==seed and float(row["width"])==width and row["quadrature"]=="16"))
                for order in (14,24):
                    tide=integrate(grid,projected,width,order)
                    rows.append(dict(edge=edge,seed=seed,width=width,order=order,laplacian_ttrr=tide,forecast_ppm=tide*DURATION**2/(2*norm)*1e6))
    save("projection-controls.csv",tests)
    save("mechanical-stress-forecast.csv",rows)
    print("checks",max(x["transverse_rel"] for x in tests),max(x["longitudinal_rel"] for x in tests))
    print([round(row["forecast_ppm"],5) for row in rows if row["edge"]==120 and row["order"]==24])


if __name__=="__main__":
    main()
