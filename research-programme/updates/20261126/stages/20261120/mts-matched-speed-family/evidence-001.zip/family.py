"""Globally constrained, fixed-SI local speed family. No likelihoods or sky data."""
import csv
import hashlib
import io
import json
import os
import sys
from pathlib import Path
from types import SimpleNamespace

for key in ("OMP_NUM_THREADS","OPENBLAS_NUM_THREADS","MKL_NUM_THREADS","NUMEXPR_NUM_THREADS"):
    os.environ[key]="1"

HERE=Path(__file__).resolve().parent
PREV=HERE.parent/"mts-current-to-tide-20261120"
PIN="c673f1c54a01df92113e5a9366370ad5e3a3ef696a935aad66b5342de4c0fd39"


def digest(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream,"sha256").hexdigest()


assert digest(PREV/"seal.json")==PIN
previous=json.loads((PREV/"seal.json").read_bytes())["files"]
assert digest(PREV/"transfer.py")==previous["transfer.py"]
sys.path.insert(0,str(PREV))
from transfer import (CLOUD,checked,Stagger,normal_data,homogeneous,Slice,input_pack,
    BalancedNative,pressure,DLOG,SPAN,angular,pair,np,DURATION,FRACTIONS,Window,safe)
from normal_graph import Sources
from coupled_readout import change_norm
from states import jet
from window import tensors,simpson
from source_budget import sources,LABELS
from predict import pinned

LEVELS=(1.,2.,4.,8.,25/8)
TAG=lambda value:format(float(value),".5g").replace(".","p")
POWERS={"D":0,"Dr":0,"V":1,"Vr":1,"other":2,"star":2,"jr":3,"jt":3,
        "chi":2,"chir":2,"wr":3,"wt":3,"ref_b":3,"stress":4,"stress_cross":4,
        "geo":2,"electric":2,"cross":2}
TERM=("gauss","ricci",*LABELS)


def guard():
    safe()
    assert not (HERE/"STOP-REQUESTED").exists()


def keep(name,data):
    guard()
    path=HERE/name
    if path.exists():
        assert path.read_bytes()==data,name
    else:
        pending=HERE/(name+".partial")
        with pending.open("xb") as handle:
            handle.write(data)
        pending.rename(path)


def save(name,rows):
    stream=io.StringIO(newline="")
    writer=csv.DictWriter(stream,fieldnames=tuple(rows[0]),lineterminator="\n")
    writer.writeheader()
    writer.writerows(rows)
    keep(name,stream.getvalue().encode())


def packet_name(native,level,flag,seed):
    return f"launch-h{native}-q{TAG(level)}-off{flag}-s{seed}.npz"


class ResolvingSlice(Slice):
    repairs=0
    def iterate(self,ell,bc):
        try:
            return super().iterate(ell,bc)
        except RuntimeError as exc:
            if "elliptic fixed point did not settle" not in str(exc):
                raise
        type(self).repairs+=1
        potential=np.zeros(self.grid.size)
        last=np.zeros_like(self.grid.points)
        for count in range(24):
            rhs=self.hsource(ell,*self.grid.evaluate(potential))
            increment=self.grid.solve(ell,rhs-last,self.bound,bc if count==0 else 0.)
            potential+=increment
            last=rhs
            error=np.max(abs(increment))
            if error<8e-12*max(1e-20,np.max(abs(potential))):
                return potential,(count+1,error)
        raise RuntimeError(("incremental constraint",ell,error))


def make(native,levels=LEVELS,receipt=""):
    sim=BalancedNative("heavy",120,120*native,False,"native36",SPAN*DLOG)
    rows=[]
    for flag in (0,1):
        ref,press,_=pressure(flag)
        for seed in (0,1,-1):
            guard()
            base,grid,shapes,initial=input_pack(sim,native,seed,flag,ref,press)
            contrast=None
            for level in levels:
                ResolvingSlice.repairs=0
                eta=1/np.sqrt(level)
                bg={**ref,"H":ref["H"]*eta,"R":ref["R"]*eta**2,"rh":ref["rh"]*eta**2}
                pbar=press*eta**4
                scaled=SimpleNamespace(mesh=sim.mesh,patch=SimpleNamespace(j=sim.patch.j,p=SimpleNamespace(mass=sim.patch.p.mass/eta)))
                mu=bg["a"]*scaled.patch.p.mass
                state=[base[0].copy(),base[1],eta*base[2]]
                state[0][1]*=eta
                assert all(set(item)==set(POWERS) for item in shapes)
                shape=tuple({key:val*eta**POWERS[key] for key,val in group.items()} for group in shapes)
                supply={**initial,"P":pbar,"lp":initial["lp"]*eta,"spec2":initial["spec2"]*eta**4}
                obj=ResolvingSlice(scaled,grid,bg,shape,state,flag,not flag,"fixed",0,"matched")
                hub=bg["H"]
                strengths=(0.,0.,0.);errs=(0.,0.,0.);rate=0.
                if not flag:
                    mean=homogeneous(bg,bg["rh"][sim.patch.j],mu,pbar)
                    hub=mean["hubble"];graph,fields=normal_data(obj,supply,mean)
                    for iteration in range(8):
                        hook=Sources(grid,fields,shape[0]["other"])
                        obj=ResolvingSlice(scaled,grid,{**bg,"H":hub},shape,state,flag,True,"fixed",0,"matched",hook)
                        new,newfields=normal_data(obj,supply,mean,graph)
                        rate=change_norm(fields,newfields)
                        if rate<2e-9:
                            break
                        graph,fields=new,newfields
                    else:
                        raise RuntimeError("normal graph")
                    delta,drift=(pair(value.real,angular(value)) for value in graph)
                    curr=np.array([newfields[key] for key in ("clock_j0","jr","jt")])/eta**5
                    if contrast is None:
                        item=sim.patch.j
                        number=jet(obj.m["n"][item],obj.m["D"][item])
                        grad=jet(obj.m["g"][item],obj.m["Dr"][item])/number
                        phase=jet(obj.m["p"][item],obj.m["P"][item])/eta
                        physical_mu=mu*eta
                        prefactor=bg["rh"][item]/eta**2*number*(3*ref["H"]+initial["lp"]+grad*phase)/(4*physical_mu**2)
                        raw=prefactor*grad
                        contrast=np.array([raw.real,angular(raw),prefactor.real*angular(number)/(grid.points*number.real)])
                    strengths=tuple(np.max(abs(curr),axis=(1,2)))
                    errs=tuple(np.max(abs(curr-contrast),axis=(1,2))/np.maximum(1e-280,np.max(abs(contrast),axis=(1,2)))) if seed else (0.,*tuple(np.max(abs(curr[1:]-contrast[1:]),axis=(1,2))/np.max(abs(contrast[1:]),axis=(1,2))))
                else:
                    delta=drift=pair(np.zeros_like(grid.points))
                mono=grid.evaluate(obj.state[0])[0]
                higher=shape[0]["V"]+grid.evaluate(obj.state[2])[0][flag]
                cut=grid.points[:,0]<16
                packet=dict(t=grid.t,h=grid.h,n=np.stack([pair(u,v) for u,v in zip(obj.m["n"],obj.m["D"])])[...,cut,:],
                    v=np.stack([pair(u,v) for u,v in zip(mono[1]/grid.points,higher)])[...,cut,:],
                    chi=pair(grid.evaluate(obj.f0)[0],grid.evaluate(obj.f2)[0])[...,cut,:],
                    b=pair(obj.b0,obj.b2)[...,cut,:],c=obj.c2[cut],d=obj.d2[cut],delta=delta[...,cut,:],drift=drift[...,cut,:],
                    rho=bg["rh"],mu=mu,H=hub,P=pbar,R=bg["R"],weight=ref["w"],e0=shape[0]["other"][cut],s0=supply["spec2"][cut],
                    native_stress=shape[0]["stress"][cut],native_cross=shape[0]["stress_cross"][cut],probes=np.array([]),initial_tide=np.array([]))
                with np.load(checked(CLOUD,f"launch-h{native}-off{flag}-seed{seed}.npz")) as prior:
                    for name in ("n","t","h","weight"):
                        np.testing.assert_array_equal(packet[name],prior[name])
                    for name in ("v","rho","mu","e0","s0","native_stress","native_cross","P"):
                        power={"v":1,"rho":2,"mu":-1,"e0":2,"s0":4,"native_stress":4,"native_cross":4,"P":4}[name]
                        peak=np.max(abs(prior[name]))
                        assert np.max(abs(packet[name]/eta**power-prior[name]))<=2e-14*peak,(name,seed,level)
                    if level==1:
                        for name in set(packet)-{"probes","initial_tide"}:
                            np.testing.assert_array_equal(packet[name],prior[name],err_msg=name)
                stream=io.BytesIO();np.savez_compressed(stream,**packet)
                keep(packet_name(native,level,flag,seed),stream.getvalue())
                rows.append(dict(native=native,level=level,eta=eta,flag=flag,seed=seed,mu=mu,H=hub,duration=DURATION/eta,
                    cycles=mu*DURATION/(eta*2*np.pi),graph_error=rate,incremental_scalar=ResolvingSlice.repairs,current0=strengths[0],current_r=strengths[1],current_t=strengths[2],
                    weak_err0=errs[0],weak_err_r=errs[1],weak_err_t=errs[2]))
            print("constrained family",native,flag,seed,flush=True)
    save(f"family-h{native}{receipt}.csv",rows)


class ScaledBank:
    def __init__(self,bank,eta):
        self.bank=bank
        self.eta=eta
        self.scales=eta**np.array([2.,4.,2.,4.,4.,4.,4.])[:,None]
    def at(self,time):
        return self.scales*self.bank.at(self.eta*time)
    def samples(self,time,degree):
        physical=self.eta*time
        return self.scales*self.eta**degree*self.bank.samples(physical,degree)


def system(native,grid,level,flag,seed):
    eta=1/np.sqrt(level)
    with np.load(checked(CLOUD,f"launch-h{native}-off{flag}-seed{seed}.npz")) as saved:
        base=Stagger(saved,grid,6,flag,1,"stagger")
    with np.load(HERE/packet_name(native,level,flag,seed)) as saved:
        shell=Stagger(saved,grid,6,flag,1,"stagger")
    shell.incident.bank=ScaledBank(base.incident.bank,eta)
    shell.initial[17]=eta**2*base.initial[17]
    shell.initial[18:20]*=eta**3
    if level==1:
        np.testing.assert_array_equal(shell.initial,base.initial)
        np.testing.assert_array_equal(shell.dynamics(DURATION*.314,shell.initial),base.dynamics(DURATION*.314,base.initial))
    return shell


def sample(shell,time,state,tangent):
    win=Window(shell,state,tangent,8)
    individual=sources(shell,time,state,tangent)
    ricci,gauss=tensors(shell,state,tangent)
    incident=shell.incident.bank.at(time)[4]+1j*1e-19*shell.incident.bank.samples(time,1)[4]
    gauss[1]+=incident
    ricci[1]+=incident
    fields=np.stack((gauss,ricci,*individual))
    mono,angularpart=win.at(fields.real).transpose(1,0,2)
    dm,da=win.at(fields.imag/1e-19).transpose(1,0,2)
    weight=win.widths
    value=weight[:,0]@angularpart.T+weight[:,1]@mono.T
    rate=weight[:,0]@da.T+weight[:,1]@dm.T+weight[:,2]@angularpart.T+weight[:,3]@mono.T
    return value,rate


def evolve(native,grid,level,steps,flag,seed):
    guard()
    shell=system(native,grid,level,flag,seed)
    eta=1/np.sqrt(level)
    count=round(steps*level*2)
    assert abs(count-steps*level*2)<1e-11 and steps%16==0
    dt=(DURATION/eta)/count
    start=shell.initial;change=np.zeros_like(start);history=[]
    for tick in range(count+1):
        time=tick*dt;state=start+change;one=shell.dynamics(time,state)
        if tick%(steps//16)==0:
            guard();val,rate=sample(shell,time,state,one)
            if not tick:
                initial=val
            history.append(rate)
        if tick==count:
            break
        two=shell.dynamics(time+dt/2,start+(change+dt*one/2))
        three=shell.dynamics(time+dt/2,start+(change+dt*two/2))
        four=shell.dynamics(time+dt,start+(change+dt*three))
        change+=dt*(one+2*two+2*three+four)/6
    rates=np.array(history)
    assert np.all(np.isfinite(rates))
    result=[]
    for stride in (1,2):
        integral=simpson(rates[::stride],dx=dt*(steps//16)*stride,axis=0)
        for width,parts,initials,finals,rfirst,rlast in zip(FRACTIONS,integral,initial,val,rates[0],rates[-1]):
            result.append(dict(native=native,grid=grid,steps=steps,level=level,flag=flag,seed=seed,width=width,stride=stride,
                initial_gauss=initials[0],initial_ricci=initials[1],endpoint_gauss=finals[0]-initials[0],
                first_rate= rfirst[0],last_rate=rlast[0],**dict(zip(TERM,parts))))
    name=f"run-h{native}-n{grid}-q{TAG(level)}-t{steps}-off{flag}-s{seed}.csv"
    save(name,result)
    print(name,"closed",flush=True)


def batch(native,grid,steps,levels):
    for level in levels:
        for flag in (0,1):
            for seed in (0,1,-1):
                evolve(native,grid,level,steps,flag,seed)


if __name__=="__main__":
    if sys.argv[1] in ("prepare","extend"):
        make(int(sys.argv[2]),tuple(map(float,sys.argv[3:])) or LEVELS,"-extended" if sys.argv[1]=="extend" else "")
    else:
        batch(*map(int,sys.argv[2:5]),tuple(map(float,sys.argv[5:])))
