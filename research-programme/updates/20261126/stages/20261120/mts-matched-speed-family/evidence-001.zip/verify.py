"""Check completed packets, predecessor hashes, numerical comparisons and the scoped stage seal."""
import ast
import csv
import hashlib
import json
import math
import sys
from pathlib import Path

HERE=Path(__file__).resolve().parent
PREV=HERE.parent/"mts-current-to-tide-20261120"
PIN="c673f1c54a01df92113e5a9366370ad5e3a3ef696a935aad66b5342de4c0fd39"


def digest(path):
    with path.open("rb") as stream:return hashlib.file_digest(stream,"sha256").hexdigest()


def rows(path):
    with path.open(newline="") as stream:
        table=list(csv.DictReader(stream))
    assert table and all(None not in row and None not in row.values() for row in table),path
    return table


def main():
    assert digest(PREV/"seal.json")==PIN
    pins=json.loads((PREV/"seal.json").read_bytes())["files"]
    for file,value in pins.items():assert digest(PREV/file)==value,file
    assert not list(HERE.glob("*.partial")) and not (HERE/"__pycache__").exists()
    for path in HERE.glob("*.py"):ast.parse(path.read_bytes(),filename=str(path))
    for pattern,count in (("launch-*.npz",42),("run-*.csv",30),("exp-*.csv",72),("times-exp-*.csv",30)):
        assert len(list(HERE.glob(pattern)))==count,pattern
    family=rows(HERE/"family-h5.csv")+rows(HERE/"family-h5-extended.csv")
    assert len({(row["level"],row["flag"],row["seed"]) for row in family})==42
    signed=[row for row in family if row["seed"]!="0" and row["flag"]=="0"]
    print("max q times normalized current error",max(float(row["level"])*float(row[key]) for row in signed for key in ("weak_err0","weak_err_r","weak_err_t")))
    paired=rows(HERE/"paired-speed-check.csv");assert len(paired)==68
    lookup={(row["tag"].split("-")[0],int(row["grid"]),float(row["level"]),int(row["seed"]),float(row["width"])):row for row in paired}
    assert len(lookup)==68
    for metric in ("excess_ppm","ricci_excess_ppm"):
        worst_time=max(abs(float(row[metric])-float(lookup["exp",120,level,seed,width][metric])) for (method,grid,level,seed,width),row in lookup.items() if method=="run")
        worst_space=max(abs(float(row[metric])-float(lookup["exp",120,level,seed,width][metric])) for (method,grid,level,seed,width),row in lookup.items() if grid==160)
        print(metric,"time / space (original 5)",worst_time,worst_space)
        assert max(worst_time,worst_space)<20
    original=HERE.parent/"mts-compatible-radial-20261120"
    name="finite-ruler-comparison.csv"
    assert digest(original/name)==json.loads((original/"seal.json").read_bytes())["files"][name]
    control=[row for row in rows(original/name) if row["method"]=="stagger" and row["native"]=="5" and row["degree"]=="8" and row["stride"]=="1" and row["steps"]=="96" and row["project"]=="1" and ("exp",int(row["grid"]),1,int(row["seed"]),float(row["width"])) in lookup]
    assert len(control)>=4
    max_diff=max(abs(float(row[key])-float(lookup["exp",int(row["grid"]),1,int(row["seed"]),float(row["width"])][dest])) for row in control for key,dest in (("gauss_offset_ppm","excess_ppm"),("ricci_offset_ppm","ricci_excess_ppm")))
    assert max_diff<20
    print("archived q1 discrepancy ppm",max_diff,"source sum error ppm",max(abs(float(row["budget_closure_ppm"])) for row in paired))
    dust=rows(HERE/"exact-dust-check.csv");assert len(dust)==48 and all(abs(float(row[key]))<20 for row in dust for key in ("error_ppm","gauge_leak_ppm"))
    proj=rows(HERE/"projection-controls.csv");assert len(proj)==6 and all(abs(float(row[key]))<2e-5 for row in proj for key in ("transverse_rel","longitudinal_rel"))
    forecasts=rows(HERE/"mechanical-stress-forecast.csv")
    widths={(row["seed"],row["width"]) for row in forecasts};assert len(widths)==4
    for seed,width in widths:
        vals=[float(row["forecast_ppm"]) for row in forecasts if (row["seed"],row["width"])==(seed,width)]
        assert len(vals)==6 and max(vals)-min(vals)<.01
    limits=rows(HERE/"stress-versus-curvature.csv")
    mid=[abs(float(row["residual_ppm"])) for row in limits if row["upper_level"] in ("4","8","16")]
    last=[abs(float(row["residual_ppm"])) for row in limits if row["upper_level"]=="32" and row["fraction"]=="1.0"]
    assert len(last)==4 and min(last)>20 and max(mid)<20
    print("material residual through 16",max(mid),"q32 full duration",min(last),max(last))
    seal=HERE/"seal.json"
    files={path.name:digest(path) for path in sorted(HERE.iterdir()) if path.is_file() and path!=seal}
    counts={name:len(rows(HERE/name)) for name in files if name.endswith(".csv")}
    for name in counts:
        for row in rows(HERE/name):
            for value in row.values():
                try:number=float(value)
                except ValueError:continue
                assert math.isfinite(number),(name,value)
    receipt=dict(previous_seal=PIN,previous_files=len(pins),files=files,rows=counts)
    if sys.argv[1:]==["seal"]:
        with seal.open("x",encoding="utf-8",newline="\n") as stream:json.dump(receipt,stream,indent=2);stream.write("\n")
    else:
        assert not sys.argv[1:]
        if seal.exists():assert json.loads(seal.read_bytes())==receipt
    print(len(files),"files",sum(counts.values()),"rows",len(pins),"upstream",digest(seal) if seal.exists() else "not sealed")


if __name__=="__main__":
    main()
