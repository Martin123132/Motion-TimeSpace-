"""Independent finite-width exact marginal LTB tide at the same physical times."""
from family import *
from window import weight,CENTER,leggauss
from scipy.optimize import brentq
checked(CLOUD,"analytic_controls.py")
from analytic_controls import ltb


class EmptyBank:
    def __init__(self,radius):
        self.zero=np.zeros((7,len(radius)))
    def at(self,time):
        return self.zero.copy()
    def samples(self,time,degree):
        return self.zero.copy()


def exact(time,fraction):
    nodes,weights=leggauss(64)
    half=CENTER*fraction
    pos=CENTER+half*nodes
    def scale(radius):
        return ((8+time+.5*np.exp(-radius**2/4))/8)**(2/3)
    radii=np.array([brentq(lambda r:r*scale(r)-value,0,3,xtol=6e-16) for value in pos])
    age=8+time+.5*np.exp(-radii**2/4)
    deriv=scale(radii)*(1-radii**2*np.exp(-radii**2/4)/(6*age))
    mass=radii**3/288
    tide=2*mass/pos**3-2*radii**2/(288*pos**2*deriv)
    return half*np.dot(weights,weight(pos,half)*tide)


def run(grid,level):
    shell=system(5,grid,1.,1,1)
    eta=1/np.sqrt(level)
    shell.rho=np.array([eta**2,0.,0.])
    shell.incident.bank=EmptyBank(shell.r)
    initial=np.zeros_like(shell.initial)
    initial[:17]=ltb(shell.r,0)
    initial[4:8]*=eta
    delta=np.zeros_like(initial)
    duration=DURATION/eta
    steps=32
    dt=duration/steps
    init={};rows=[]
    for tick in range(steps+1):
        time=tick*dt
        state=initial+delta
        first=shell.dynamics(time,state)
        if tick in (0,steps//2,steps):
            win=Window(shell,state,first,12)
            for channel,tensor in zip(("ricci","gauss"),tensors(shell,state,first)):
                mono,quad=win.at(tensor.real)
                values=win.widths[:,0]@mono/eta**2
                pure=(win.widths[:,0]@quad+win.widths[:,1]@mono)/eta**2
                for width,value,quadrupole in zip(FRACTIONS,values,pure):
                    ref=exact(time*eta,width)
                    if not tick:
                        init[channel,width]=(value,quadrupole,ref)
                        continue
                    start,null,old=init[channel,width]
                    denom=ref-old
                    rows.append(dict(grid=grid,level=level,fraction=tick/steps,channel=channel,width=width,
                        ref_change=denom,observed_change=value-start,error_ppm=((value-start)/denom-1)*1e6,
                        gauge_leak_ppm=(quadrupole-null)/denom*1e6))
        if tick==steps:break
        second=shell.dynamics(time+dt/2,initial+(delta+dt*first/2))
        third=shell.dynamics(time+dt/2,initial+(delta+dt*second/2))
        fourth=shell.dynamics(time+dt,initial+(delta+dt*third))
        delta+=dt*(first+2*second+2*third+fourth)/6
    return rows


if __name__=="__main__":
    rows=[row for grid in (120,160) for level in (1,4,32) for row in run(grid,level)]
    save("exact-dust-check.csv",rows)
    for key in ("error_ppm","gauge_leak_ppm"):print(key,max(abs(row[key]) for row in rows))
