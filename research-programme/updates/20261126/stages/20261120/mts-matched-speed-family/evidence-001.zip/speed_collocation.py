"""Second full evolution: causal exponential source integration at fixed physical time."""
from family import *
from predict import kernels,apply_kernel


def run(native,grid,level,degree,flag,seed,panels_per_cycle=1,depth=4,partials=False):
    guard()
    shell=system(native,grid,level,flag,seed)
    eta=1/np.sqrt(level)
    panels=int(np.ceil(2*level*panels_per_cycle))
    span=DURATION/(eta*panels)
    times,kernel,spin=kernels(degree,span,2*shell.mu)
    initial=shell.initial
    total_change=np.zeros_like(initial)
    integrated=np.zeros((len(FRACTIONS),len(TERM)))
    first_order=None
    snapshots=[]
    for index in range(panels):
        guard()
        increment=np.zeros((degree+1,*initial.shape),dtype=complex)
        for sweep in range(depth+1):
            source=np.empty_like(increment)
            if sweep==depth:
                observed=[]
            for node,within in enumerate(times):
                time=index*span+within
                state=initial+(total_change+increment[node])
                physical=shell.dynamics(time,state)
                if sweep==depth:
                    value,rate=sample(shell,time,state,physical)
                    observed.append(rate)
                    if index==node==0:
                        first_order=rate
                        before=value
                else:
                    source[node]=physical
            if sweep==depth:
                integrated+=np.einsum("t,tij->ij",kernel[-1],observed)
                total_change+=increment[-1]
                if partials and (8*(index+1))%panels==0:
                    for width,accum,endpoint_rate,launch_rate in zip(FRACTIONS,integrated,rate,first_order):
                        snapshots.append(dict(level=level,grid=grid,degree=degree,depth=depth,seed=seed,flag=flag,
                            width=width,fraction=(index+1)/panels,first_rate=launch_rate[0],last_rate=endpoint_rate[0],**dict(zip(TERM,accum))))
                break
            if not flag:
                source[:,14]-=shell.mu*increment[:,15]
                source[:,15]-=2j*shell.mu*increment[:,15]
            increment=apply_kernel(kernel,source)
            if not flag:
                correction=apply_kernel(spin-kernel,source[:,15])
                increment[:,14]+=correction/(2j)
                increment[:,15]+=correction
    rows=[]
    assert np.all(np.isfinite(integrated))
    for width,parts,initials,finals,dfirst,dlast in zip(FRACTIONS,integrated,before,value,first_order,rate):
        rows.append(dict(native=native,grid=grid,level=level,flag=flag,seed=seed,width=width,degree=degree,panels=panels,depth=depth,
                    initial_gauss=initials[0],initial_ricci=initials[1],endpoint_gauss=finals[0]-initials[0],
                    first_rate=dfirst[0],last_rate=dlast[0],**dict(zip(TERM,parts))))
    name=f"exp-h{native}-n{grid}-q{TAG(level)}-d{degree}-p{panels_per_cycle}-k{depth}-off{flag}-s{seed}.csv"
    save(name,rows)
    if partials:
        save("times-"+name,snapshots)
    print(name,"closed",flush=True)


def batch(native,grid,degree,levels):
    for level in levels:
        for flag in (0,1):
            for seed in (0,1,-1):
                run(native,grid,level,degree,flag,seed)


if __name__=="__main__":
    batch(*map(int,sys.argv[1:4]),tuple(map(float,sys.argv[4:])))
