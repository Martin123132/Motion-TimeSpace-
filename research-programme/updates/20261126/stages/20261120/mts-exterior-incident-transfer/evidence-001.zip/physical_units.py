"""What a physical one-kpc axial separation would read from the native scalar exterior alone."""
from local_stage import *
from scipy.constants import c,parsec,Julian_year
from scipy.interpolate import CubicSpline
from scipy.optimize import brentq
from balance import clock
from math import fsum


def run():
    data=read(HERE/"native-absolute-weyl.csv")
    unit=c**2*(1e3*parsec)/(1e6*parsec)**2
    result=[];clocks=[]
    for flag in (0,1):
        with np.load(clock.checked(clock.NORMAL,f"trace-heavy-off{flag}.npz")) as source:
            index=source["names"].tolist().index("a")
            scale=source["values"][:,:,index].mean(axis=0)
            time=source["dt"]
        proper=CubicSpline(time,scale/scale[0]).antiderivative()
        for frac in (.25,.5,.75,1.):
            old=float(next(row["conformal_offset"] for row in data if int(row["flag"])==flag and float(row["fraction"])==frac))
            replay=brentq(lambda value:float(proper(value)-proper(0.))-frac*DURATION,0.,time[-1],xtol=5e-16)
            clocks.append(dict(flag=flag,fraction=frac,own_elapsed_years=float(proper(old)-proper(0.))*scale[0]*(1e6*parsec)/c/Julian_year,
                               matched_elapsed_years=frac*DURATION*clock.SCALE*(1e6*parsec)/c/Julian_year,
                               conformal_difference=replay-old))
    for radius in (6.,119.,120.,144.,168.):
        for frac in (0.,.25,.5,.75,1.):
            part={int(row["flag"]):row for row in data if row["field"]=="saved" and float(row["radius"])==radius and float(row["fraction"])==frac}
            for label,weights in (("wave",(1,0)),("cold",(0,1)),("wave_minus_cold",(1,-1))):
                axial=fsum(coef*float(part[flag]["axial"]) for flag,coef in enumerate(weights))*unit
                shift=fsum(coef*float(part[flag]["axial_change"]) for flag,coef in enumerate(weights))*unit
                result.append(dict(radius_comoving_Mpc=radius,proper_fraction=frac,branch=label,
                    axial_m_s2_per_proper_kpc=axial,each_transverse_m_s2_per_proper_kpc=-axial/2,
                    axial_change_m_s2_per_proper_kpc=shift))
    table("native-clock-replay.csv",clocks);table("native-weyl-physical.csv",result)


if __name__=="__main__":run()
