"""Two-sided propagation across the old interface with no wall condition at that radius."""
from launch_data import path
from local_stage import *
from edge_system import Incident,LocalSource,BarycentricInterpolator
from balance import pair,mul,exp
from readout import Samples, fields, scale_table, COLS, leggauss
from tidal import WeakTide, extra, LABELS


PATCHES={
    "near":(4.75,15.5,160,((6.,15.),)),
    "middle":(14.,121.,40,((15.,119.),)),
    "inner":(118.,121.,160,((119.,120.),)),
    "outer":(119.25,123.,80,((120.,122.),)),
    "fine":(118.,121.,320,((119.,120.),)),
    "outerfine":(119.25,123.,160,((120.,122.),)),
    "whole":(4.5,123.,80,((6.,15.),(15.,48.),(48.,96.),(96.,119.),(119.,120.))),
    "cut":(118.,120.,320,((119.,120.),))}


def shell_for(edge,rate,level,flag,seed,left,right,grid,continued=False):
    radius=(np.arange(round(left*grid),round(right*grid))+.5)/grid
    obj=object.__new__(traced.collar.ContinuedEnd if continued else traced.collar.Annulus)
    obj.dx=1/grid;obj.r=radius;obj.left=left;obj.flag=flag;obj.project=1;obj.method="stagger";obj.order=6
    eta=1/np.sqrt(level)
    def packet_at(speed):
        return traced.checked(f"full-q{speed}-off{flag}-s{seed}.npz") if (edge,rate)==(120,5) else path(edge,rate,speed,flag,seed)
    def interpolation(packet):
        cell=np.floor(radius/float(packet["h"])).astype(int)
        point=radius/float(packet["h"])-cell
        basis=BarycentricInterpolator(packet["t"],np.eye(len(packet["t"])),rng=0)(point)
        def at(raw,anchored=True):
            selected=raw[...,cell,:]
            if not anchored:return np.einsum("...ij,ij->...i",selected,basis)
            base=selected[...,:1]
            return base[...,0]+np.einsum("...ij,ij->...i",selected-base,basis)
        return at
    with np.load(packet_at(1)) as packet:
        at=interpolation(packet)
        bank=Incident(packet,radius,flag,lambda raw:at(raw,False))
    with np.load(packet_at(level)) as packet:
        at=interpolation(packet)
        obj.rho=packet["rho"];obj.mu=float(packet["mu"])
        init=np.zeros((20,2,len(radius)),complex)
        def logpert(data):return pair(np.log1p(data[0]),data[1]/(1+data[0]))
        logu=logpert(at(packet["chi"]))
        init[0]=init[1]=2*logu;init[4,0]=-3*float(packet["H"])
        init[5]=mul(at(packet["b"]),exp(-6*logu))
        init[6,1]=at(packet["c"])*np.exp(-6*logu[0]);init[7,1]=at(packet["d"])*np.exp(-6*logu[0])
        for species in range(3):
            init[8+2*species]=at(packet["n"][species]);init[9+2*species]=at(packet["v"][species])
        delta=at(packet["delta"])
        init[14]=(logpert(init[12].real-pair(np.ones_like(radius)))-logpert(delta))/2-3*logu+1j*obj.mu*init[13]
        init[15]=at(packet["drift"])-init[4]/(2*obj.mu)-1j*delta
        obj.incident=LocalSource(family.ScaledBank(bank,eta))
        obs=bank.at(0.)
        init[17]=eta**2*pair(obs[0],obs[2])
        bg=states.native("heavy",flag)
        vol_to_frame=np.exp(-4*init[0,0].real)
        init[18,1]=eta**3*vol_to_frame*states.response(bg,radius,1)("j_other")
        init[19,1]=eta**3*vol_to_frame*states.response(bg,radius)("j_other")/radius
    obj.initial=init
    return obj


def evolve(shell,level,steps):
    count=2*level*steps
    step=DURATION*np.sqrt(level)/count
    obj=traced.Passive(shell)
    advance=traced.collar.stepper(obj,step)
    shift=np.zeros_like(obj.initial);snap=[]
    for idx in range(count):
        if idx%16==0:guard()
        shift=advance(idx*step,shift)
        if (idx+1)%(count//4)==0:snap.append(shift.copy())
    assert np.isfinite(snap).all()
    return np.asarray(snap)


def inspect_response(shell,changes,level,ranges):
    normal=scale_table()
    rows=[];nodes,weights=leggauss(3)
    for low,high in ranges:
        for name,operator,view,labels in (("trace",Samples,fields,COLS),("electric",WeakTide,extra,LABELS)):
            gate=operator(shell,low,high,6)
            base=gate.splines(view(shell.initial),5)
            initial=gate.apply(base)
            for (frac,scale),change in zip(normal.items(),changes,strict=True):
                diff=gate.splines(view(change,True),5)
                inc=sum(wt*gate.apply([old+((node+1)/2+1e-20j)*val for old,val in zip(base,diff)]).imag/2e-20 for node,wt in zip(nodes,weights))
                mod=np.expm1(np.log(scale)*5/6) if name=="trace" else scale-1
                result=level*((1+mod)*inc+mod*initial)
                for key,val in zip(labels,result,strict=True):
                    rows.append(dict(lower=low,upper=high,fraction=frac,channel=name,term=key,value=val))
    return rows


def run(edge,rate,level,tag,steps=4):
    left,right,grid,ranges=PATCHES[tag]
    for flag in (0,1):
        for seed in (0,1,-1):
            guard()
            stem=f"L{edge}-h{rate}-q{level}-{tag}-t{steps}-off{flag}-s{seed}"
            shell=shell_for(edge,rate,level,flag,seed,left,right,grid,tag=="cut")
            checkpoint=HERE/("state-"+stem+".npz")
            if not checkpoint.exists():pack(checkpoint.name,r=shell.r,change=evolve(shell,level,steps))
            with np.load(checkpoint) as saved_state:
                np.testing.assert_array_equal(saved_state["r"],shell.r)
                snap=saved_state["change"]
                assert snap.shape==(4,22,2,len(shell.r)) and np.isfinite(snap).all()
            table("response-"+stem+".csv",inspect_response(shell,snap,level,ranges))
    print("crossed interface",edge,rate,level,tag,steps,flush=True)


if __name__=="__main__":
    edge,rate,level=map(int,sys.argv[1:4])
    for tag in sys.argv[4:]:
        label,_,steps=tag.partition(":")
        run(edge,rate,level,label,int(steps or 4))
