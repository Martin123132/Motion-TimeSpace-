"""Frozen prospective same-clock speed test; no changes to the fitted or numerical target."""
from local_stage import *
from launch_data import run as launch
from assess import indexed,material,signed,LABELS,NORMS,fsum
from propagate import shell_for,PATCHES,inspect_response,WeakTide,extra,leggauss,scale_table
from layer import read_layer


def guard_frozen():
    for filename,expected in (("layer.py","e4763ddb0abe4a1813826c16e388e763e3b3515ef6aeff8a650d158e99b7e582"),
        ("propagate.py","3411f77544e2bd3c3ebcbff9e7f2597a4191a887810711fa0e2657d9eb8fbff4"),
        ("newton-L144-h5.csv","d950056e4fb7dc3cebbafb71c1b4ef9b1aa8fa50e9e5d974e20fd45a0b2bd18d"),
        ("two-remote-faces.csv","37855bdd1b03d1971f474a11956d510b254a310b20a7ecb28c48d975df2df009")):
        assert sha(HERE/filename)==expected,filename


def inner_nine():
    output=[]
    left,right,grid,_=PATCHES["near"]
    for flag in (0,1):
        for seed in (0,1,-1):
            guard()
            shell=shell_for(144,5,64,flag,seed,left,right,grid)
            with np.load(HERE/f"state-L144-h5-q64-near-t9-off{flag}-s{seed}.npz") as snap:
                np.testing.assert_array_equal(snap["r"],shell.r)
                states=snap["change"]
            for low,high in ((5.,5.5),(5.25,5.75)):
                gates=[WeakTide(shell,a,b,6) for a,b in ((high,6.),(low,high))]
                base=[gate.splines(extra(shell.initial),5) for gate in gates]
                initial=read_layer(*gates,*base,inward=True)
                for (frac,normal),state in zip(scale_table().items(),states,strict=True):
                    diff=[gate.splines(extra(state,True),5) for gate in gates]
                    inc=np.zeros(3)
                    for node,wt in zip(*leggauss(3)):
                        sweep=[[a+((node+1)/2+1e-20j)*d for a,d in zip(first,change)] for first,change in zip(base,diff)]
                        inc+=wt*read_layer(*gates,*sweep,inward=True).imag/2e-20
                    mod=np.r_[np.expm1(np.log(normal)*5/6),normal-1,normal-1]
                    val=64*((1+mod)*inc+mod*initial)
                    output.append(dict(seed=seed,flag=flag,b=low,c=high,fraction=frac,scalar=val[0],physical=val[1],by_parts=val[2]))
    table("remote-L144-h5-q64-near-nine.csv",output)


def score():
    guard_frozen();rows=[];individual=[]
    newt=material(144,5)
    for steps in (4,9):
        inner=read(HERE/("remote-L144-h5-q64-near"+("-nine" if steps==9 else "")+".csv"))
        outer=read(HERE/"remote-L144-h5-q64-outer.csv")
        patches=[indexed(144,5,64,region,steps if region=="near" else 4) for region in ("near","middle","inner")]
        for frac in (.25,.5,.75,1.):
            for left in (5.,5.25):
                for right in (120.5,121.):
                    def face(data,bound):
                        return {(int(row["seed"]),int(row["flag"])):float(row["by_parts"]) for row in data if float(row["fraction"])==frac and float(row["b"])==bound}
                    first,last=face(inner,left),face(outer,right)
                    def actual(host,flag):return fsum(val for (s,f,t,a,b),val in newt.items() if (s,f,t)==(host,flag,frac) and 6<=a<b<=120)
                    def record(host,flag,patch,term):return patches[patch][host,flag,frac,"electric",term]
                    for seed in (1,-1):
                        for flag in (0,1):
                            ref=actual(seed,flag)-actual(0,flag)
                            pred=fsum((first[seed,flag],-first[0,flag],-last[seed,flag],last[0,flag],
                                *(record(seed,flag,patch,key)-record(0,flag,patch,key) for patch in range(3) for key in LABELS if "face" not in key and key!="energy")))
                            individual.append(dict(seed=seed,flag=flag,fraction=frac,left=left,right=right,steps=steps,
                                predicted=pred,newton=ref,relative=(pred-ref)/abs(ref)))
                        expected=signed(actual,seed)
                        energy=fsum(signed(lambda host,flag:record(host,flag,patch,"energy"),seed) for patch in range(3))
                        result=fsum((signed(lambda host,flag:first[host,flag],seed),-signed(lambda host,flag:last[host,flag],seed),
                            *(signed(lambda host,flag:record(host,flag,patch,key),seed) for patch in range(3) for key in LABELS if "face" not in key and key!="energy")))
                        for width in (.15,.30):
                            norm=abs(NORMS[seed,width,frac])*1e-6
                            rows.append(dict(seed=seed,width=width,fraction=frac,left=left,right=right,steps=steps,
                                full_scale=norm*1e6,predicted=result,energy=energy,newton=expected,
                                newton_error=(result-expected)/norm,energy_error=(result-energy)/norm))
    previous={(r["seed"],r["width"],r["fraction"],r["left"],r["right"]):r for r in rows if r["steps"]==4}
    for row in rows:
        old=previous[row["seed"],row["width"],row["fraction"],row["left"],row["right"]]
        row["time_shift"]=(row["predicted"]-old["predicted"])/row["full_scale"]*1e6
        row["passed"]=max(abs(row[key]) for key in ("newton_error","energy_error","time_shift"))<=20
    table("prospective-q64.csv",rows);table("prospective-members.csv",individual)
    print("frozen cases",len(rows),"passed",sum(r["passed"] for r in rows),
          *(max(abs(row[key]) for row in rows) for key in ("newton_error","energy_error","time_shift")))


if __name__=="__main__":
    guard_frozen()
    if sys.argv[1:]==["launch"]:launch(144,5,(64,),"-q64")
    elif sys.argv[1:]==["score"]:inner_nine();score()
    else:raise ValueError("launch or score required")
