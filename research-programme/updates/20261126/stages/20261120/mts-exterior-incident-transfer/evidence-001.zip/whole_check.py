"""Compare one unbroken evolution over the entire measurement interval with the annular calculation."""
from assess import *


def run():
    data={}
    for flag in (0,1):
        for seed in (0,1,-1):
            for row in read(HERE/f"response-L144-h5-q32-whole-t4-off{flag}-s{seed}.csv"):
                if row["channel"]!="electric":continue
                data[seed,flag,float(row["fraction"]),float(row["lower"]),row["term"]]=float(row["value"])
    original=read(HERE/"remote-transfer.csv")
    collar=read(HERE/"remote-L144-h5-q32-outer.csv")
    single=read(HERE/"budget-L144-h5-q32-inner-outer-t4.csv")
    rows=[]
    for seed in (-1,1):
        for frac in (.25,.5,.75,1.):
            for width in (.15,.30):
                unit=abs(NORMS[seed,width,frac])*1e-6
                def term(rad,key):
                    return signed(lambda host,flag:data[host,flag,frac,rad,key],seed)/unit
                slabs=(6.,15.,48.,96.,119.)
                energy=fsum(term(rad,"energy") for rad in slabs)
                interior=fsum(term(rad,key) for rad in slabs for key in LABELS if "face" not in key and key!="energy")
                near=term(6.,"ricci_face_low")+term(6.,"extrinsic_face_low")
                far=-term(119.,"ricci_face_high")-term(119.,"extrinsic_face_high")
                source=next(float(row["newton"]) for row in single if (int(row["seed"]),float(row["fraction"]),float(row["width"]))==(seed,frac,width))
                for b in (120.5,121.):
                    sel={(int(row["seed"]),int(row["flag"])):float(row["by_parts"]) for row in collar if float(row["fraction"])==frac and float(row["b"])==b}
                    remote=signed(lambda host,flag:sel[host,flag],seed)/unit
                    prediction=near-remote+interior
                    earlier=next(row for row in original if row["case"]=="L144-h5-q32-inner-outer-t4" and (int(row["seed"]),float(row["fraction"]),float(row["width"]),float(row["b"]))==(seed,frac,width,b))
                    rows.append(dict(seed=seed,width=width,fraction=frac,witness=b,source=source,energy=energy,prediction=prediction,
                        whole_minus_newton=prediction-source,whole_minus_energy=prediction-energy,
                        whole_minus_patches=prediction-float(earlier["remote_prediction"]),remote_minus_face=remote-far))
    table("whole-domain-check.csv",rows)
    print("Unbroken domain, ppm",*(max(abs(row[key]) for row in rows) for key in ("whole_minus_newton","whole_minus_energy","whole_minus_patches","remote_minus_face")))


if __name__=="__main__":run()
