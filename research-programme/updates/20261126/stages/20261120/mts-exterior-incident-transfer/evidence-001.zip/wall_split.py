"""Hold the evolution end fixed while changing formation, then remove only that evolution end."""
from propagate import *
from assess import signed
from compare import NORMS


def run():
    from edge_system import local
    controls=[];old={}
    for seed in (0,1,-1):
        for flag in (0,1):
            baseline=local(320,32,flag,seed,6)
            here=shell_for(120,5,32,flag,seed,118.,120.,320,True)
            np.testing.assert_array_equal(baseline.r,here.r)
            for name,source,replica in (("state",baseline.initial,here.initial),("generator",baseline.dynamics(0.,baseline.initial),here.dynamics(0.,here.initial))):
                relative=np.max(abs(source-replica))/np.max(abs(source))
                assert relative<2e-14
                controls.append(dict(seed=seed,flag=flag,input=name,relative=relative))
            for channel,kind in (("trace","trace"),("electric","tidal")):
                filename=f"{kind}-n320-q32-t4-p7-off{flag}-s{seed}-fine1.csv"
                assert sha(PREV/filename)==registry[filename]
                for row in read(PREV/filename):
                    flux=float(row["outer"]) if channel=="trace" else -float(row["ricci_face_high"])-float(row["extrinsic_face_high"])
                    old[seed,flag,float(row["fraction"]),channel]=flux
    table("old-patch-constructor.csv",controls)
    rows=[]
    for seed in (-1,1):
        for frac in (.25,.5,.75,1.):
            for width in (.15,.30):
                unit=abs(NORMS[seed,width,frac])*1e-6
                for channel in ("trace","electric"):
                    def flux(host,flag,tag):
                        if tag=="original":return old[host,flag,frac,channel]
                        raw=read(HERE/f"response-L144-h5-q32-{tag}-t4-off{flag}-s{host}.csv")
                        vals={row["term"]:float(row["value"]) for row in raw if float(row["fraction"])==frac and row["channel"]==channel}
                        return vals["outer"] if channel=="trace" else -vals["ricci_face_high"]-vals["extrinsic_face_high"]
                    earlier,cut,through=[signed(lambda host,flag:flux(host,flag,tag),seed)/unit for tag in ("original","cut","fine")]
                    rows.append(dict(seed=seed,width=width,fraction=frac,field=channel,both_ends_at_120=earlier,
                        formation_only_extended=cut,both_extended=through,formation_change=cut-earlier,evolution_end_change=through-cut))
    table("wall-factorization.csv",rows)


if __name__=="__main__":run()
