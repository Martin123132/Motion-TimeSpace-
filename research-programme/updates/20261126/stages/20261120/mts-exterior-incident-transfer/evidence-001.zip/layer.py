"""Recover both point fluxes at the old interface without sampling the metric there."""
from propagate import *
from readout import source
from tidal import tensor_terms
from types import SimpleNamespace
from scipy.integrate import quad
from scipy.special import spherical_jn


def read_layer(left,right,first,second,inward=False):
    b,c=right.low,right.high
    assert (left.low==c if inward else left.high==b)
    den=(c-b)*(c**4+c**3*b+c**2*b**2+c*b**3+b**4)
    def fields_at(gate,data,window):
        points=gate.points
        vals,grad,curv=data
        rhs,quad_mode,_=source(gate.shell,points,vals[:17],grad[:17],curv[:2])
        ri,rb,ex,xb,cur,shear,ss,mix,energy=tensor_terms(gate.shell,points,*data)
        if window:
            t=(points-b)/(c-b)
            survival=(1-t)**2*(1+2*t)
            weight=6*t*(1-t)/(c-b)
            derivative=6*(1-2*t)/(c-b)**2
            scalar_weight=(c-points)*(c**4+c**3*points+c**2*points**2+c*points**3+points**4)/den
            if inward:
                survival=t**2*(3-2*t)
                scalar_weight=(points-b)*(points**4+points**3*b+points**2*b**2+points*b**3+b**4)/den
        else:
            survival=scalar_weight=np.ones_like(points)
            weight=derivative=np.zeros_like(points)
        logpsi,shape,tilt,tensor=vals[:4]
        ell,bend=2*logpsi+2*shape/3,2*logpsi-shape/3
        ellp,bendp=2*grad[0]+2*grad[1]/3,2*grad[0]-grad[1]/3
        factor=.6*np.exp(2*bend[0]-ell[0])/points
        by_parts=factor*(-(derivative+weight*(2*bendp[0]-ellp[0]-1/points))*(bend[1]+tensor[1])
                      +weight*(-ell[1]*bendp[0]+(tilt[1]-ell[1])/points))
        integral=lambda arr:gate.weights@arr[:-2]
        scalar=(1 if inward else -1)*integral(scalar_weight*rhs.sum(axis=0)/(5*points))
        if window:scalar-=4*(c**3*quad_mode[-1]-b**3*quad_mode[-2])/den
        lift=integral(survival*(energy-(rb+xb+cur+shear+ss+mix)))
        if inward:lift=-lift
        return np.array((scalar,lift+integral(weight*(ri+ex)),lift+integral(by_parts+weight*ex)))
    return fields_at(left,first,False)+fields_at(right,second,True)


def physical(edge,rate,level,tag):
    left,right,grid,_=PATCHES[tag];rows=[]
    inward=tag in ("near","whole")
    for flag in (0,1):
        for seed in (0,1,-1):
            shell=shell_for(edge,rate,level,flag,seed,left,right,grid)
            with np.load(HERE/f"state-L{edge}-h{rate}-q{level}-{tag}-t4-off{flag}-s{seed}.npz") as retained:
                np.testing.assert_array_equal(retained["r"],shell.r)
                snaps=retained["change"]
            for b,c in (((5.,5.5),(5.25,5.75)) if inward else ((121.,122.),(120.5,121.))):
                ranges=((c,6.),(b,c)) if inward else ((120.,b),(b,c))
                gates=[WeakTide(shell,low,high,6) for low,high in ranges]
                def calc(data):
                    return read_layer(*gates,*data,inward=inward)
                before=[gate.splines(extra(shell.initial),5) for gate in gates]
                initial=calc(before)
                for (frac,normal),snap in zip(scale_table().items(),snaps,strict=True):
                    diff=[gate.splines(extra(snap,True),5) for gate in gates]
                    inc=np.zeros(3)
                    for node,wt in zip(*leggauss(3)):
                        swept=[[arr+((node+1)/2+1e-20j)*shift for arr,shift in zip(base,change)] for base,change in zip(before,diff)]
                        inc+=wt*calc(swept).imag/2e-20
                    mod=np.r_[np.expm1(np.log(normal)*5/6),normal-1,normal-1]
                    values=level*((1+mod)*inc+mod*initial)
                    rows.append(dict(seed=seed,flag=flag,fraction=frac,b=b,c=c,scalar=values[0],physical=values[1],by_parts=values[2]))
    table(f"remote-L{edge}-h{rate}-q{level}-{tag}.csv",rows)


def fixtures():
    shell=SimpleNamespace(r=np.arange(400)/40+3.,left=3.,dx=1/40,flag=1,rho=np.zeros(3),mu=1.)
    gates=[WeakTide(shell,low,high,6) for low,high in ((6.,7.),(7.,8.))]
    checks=[];inverse_checks=[]
    for power in (-3,2,4):
        data=[]
        for gate in gates:
            pts=gate.points
            vals=np.zeros((20,2,len(pts)));grad=vals.copy();curv=vals[:4].copy()
            vals[0,1]=pts**float(power);grad[0,1]=power*pts**float(power-1)
            curv[0,1]=power*(power-1)*pts**float(power-2)
            vals[6,1]=-4*(power*(power+1)-6)*pts**float(power-2)
            data.append((vals,grad,curv))
        result=read_layer(*gates,*data)
        expected=np.array([-.8*(power+3),1.2*(power-1),1.2*(power-1)])*6.**(power-2)
        error=np.max(abs(result-expected))/max(abs(expected))
        assert error<1e-12,(power,error)
        checks.append(dict(test="two exterior witnesses, power "+str(power),error=error,scale="max analytic absolute flux"))
        inner_exact=np.array([-.8*(power+3),1.2*(power-1),1.2*(power-1)])*8.**(power-2)
        inner_err=np.max(abs(read_layer(gates[1],gates[0],data[1],data[0],inward=True)-inner_exact))/max(abs(inner_exact))
        assert inner_err<1e-12
        inverse_checks.append(dict(test="inner witnesses, power "+str(power),relative=inner_err))
    import sympy as sy
    rr,tt=sy.symbols("r t",positive=True)
    areal=rr*(8+tt+rr**2/300)**sy.Rational(2,3)
    slope=areal.diff(rr);xi=rr**3/2000
    kr=-slope.diff(tt)/slope;kt=-areal.diff(tt)/areal
    trace=kr+2*kt;shear=kr-trace/3
    energy=2*(2*rr**3/9).diff(rr)/(areal**2*slope)
    ell=sy.log(slope);bend=sy.log(areal/rr)
    ell2=xi*ell.diff(rr)+xi.diff(rr);bend2=xi*slope/areal
    cross=(kr-kt)*slope*xi/areal
    fields={0:((ell+2*bend)/6,(ell2+2*bend2)/6),1:(ell-bend,ell2-bend2),
            2:(0,rr*slope**2*xi/areal**2),4:(trace,xi*trace.diff(rr)),5:(shear,xi*shear.diff(rr)),
            6:(energy,xi*energy.diff(rr)),17:(0,cross)}
    expr=[sy.diff(sy.sympify(term),rr,order) for order in range(3) for group in fields.values() for term in group]
    sample=sy.lambdify((rr,tt),expr,"numpy",cse=True)
    quad_field=sy.exp(fields[0][0])*fields[0][1]
    exact=sy.lambdify((rr,tt),(-4*(quad_field.diff(rr)/rr+3*quad_field/rr**2)/5,-sy.exp(3*bend)*trace*cross/5),"numpy",cse=True)
    for instant in (0.,.7):
        data=[]
        for gate in gates:
            blocks=np.array([np.broadcast_to(val,gate.points.shape) for val in sample(gate.points,instant)]).reshape(3,len(fields),2,-1)
            full=np.zeros((3,20,2,len(gate.points)))
            for ind,key in enumerate(fields):full[:,key]=blocks[:,ind]
            data.append(full)
        scalar,physical=exact(6.,instant)
        relative=np.max(abs(read_layer(*gates,*data)/[scalar,physical,physical]-1))
        assert relative<1e-9,relative
        checks.append(dict(test="exact curved-coordinate dust "+str(instant),error=relative,scale="each analytic point flux"))
        inner_scalar,inner_flux=exact(8.,instant)
        inner_err=np.max(abs(read_layer(gates[1],gates[0],data[1],data[0],inward=True)/[inner_scalar,inner_flux,inner_flux]-1))
        assert inner_err<1e-9
        inverse_checks.append(dict(test="inner witnesses, exact dust "+str(instant),relative=inner_err))
    for z in (.3,1.,4.,20.,72.):
        cut=max(z,32.)
        head=quad(lambda x:spherical_jn(2,x)/x,z,cut,epsabs=2e-14,epsrel=2e-14)[0]
        one=quad(lambda x:3/x**4-1/x**2,cut,np.inf,weight="sin",wvar=1.,epsabs=9e-15,limlst=400)[0]
        two=quad(lambda x:-3/x**3,cut,np.inf,weight="cos",wvar=1.,epsabs=9e-15,limlst=400)[0]
        error=abs(head+one+two-spherical_jn(1,z)/z)
        assert error<1e-12,(z,error)
        checks.append(dict(test="infinite Fourier exterior "+str(z),error=error,scale="absolute dimensionless kernel"))
    table("remote-fixtures.csv",checks)
    table("inner-fixtures.csv",inverse_checks)


if __name__=="__main__":
    if len(sys.argv)==1:fixtures()
    else:physical(*map(int,sys.argv[1:4]),sys.argv[4])
