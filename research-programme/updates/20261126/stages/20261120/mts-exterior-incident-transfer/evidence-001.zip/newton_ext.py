"""Normal-clock Newton evolution and an independently integrated exterior on the extended parents."""
from local_stage import *
from balance import clock,brentq
from compare import NORMS
from numpy.polynomial.legendre import legvander


def run(edge,rate):
    sim=family.BalancedNative("heavy",edge,edge*rate,False,"native36",clock.START+.00002)
    trace=clock.Traces("heavy",sim)
    sim.patch.coeff=lambda time:(float(trace.hubble(time-clock.START)),clock.SCALE*np.exp(time-clock.START))
    sim.ref.solution=lambda time:trace.histories(time-clock.START,"normal")
    mesh=sim.mesh;kernel=clock.Kernel(mesh)
    radii=sorted({6.,15.,119.,120.,min(122.,edge),min(144.,edge),float(edge)})
    weights={rad:(kernel.rows(rad)[4] if rad!=edge else np.zeros(mesh.size)) for rad in radii}
    masses=sim.patch.p.coeff/clock.SCALE;fractions=np.arange(33)/32
    offsets=trace.log_time([brentq(lambda val:float(trace.proper(val))-frac*DURATION,0.,trace.proper.x[-1],xtol=5e-16) if frac else 0. for frac in fractions])
    deltas={};records=[];norms=[]
    for seed in (0,1,-1):
        start=start_state(sim,edge,rate,seed)
        for flag in (0,1):
            sim.patch.wave=not flag
            summed=[np.zeros_like(comp) for comp in start]
            for idx,offset in enumerate(offsets):
                guard()
                state=tuple(original+inc for original,inc in zip(start,summed))
                if idx and idx%8==0:
                    gain=np.exp(-3*offset)*(masses@summed[1][flag])+np.expm1(-3*offset)*(masses@start[1][flag])
                    deltas[seed,flag,fractions[idx]]=gain
                    for low,high in zip(radii,radii[1:]):
                        records.append(dict(seed=seed,flag=flag,fraction=fractions[idx],lower=low,upper=high,
                            moment=(weights[low]-weights[high])@gain))
                if idx==32:break
                step=offsets[idx+1]-offset
                slopes=[sim.rates(state,clock.START+offset)]
                for prop in (.5,.5,1.):
                    mid=tuple(original+(inc+prop*step*slope) for original,inc,slope in zip(start,summed,slopes[-1]))
                    slopes.append(sim.rates(mid,clock.START+offset+prop*step))
                for inc,derivs in zip(summed,zip(*slopes)):inc+=step*(derivs[0]+2*derivs[1]+2*derivs[2]+derivs[3])/6
    table(f"newton-L{edge}-h{rate}.csv",records)
    if edge>120:
        basis=legvander(kernel.nodes,mesh.order)@kernel.basis
        radii_gl=mesh.loc[:,:1]+(kernel.nodes+1)*mesh.h/2
        for seed in (1,-1):
            for frac in fractions[8::8]:
                field=(deltas[seed,0,frac]-deltas[0,0,frac])-(deltas[seed,1,frac]-deltas[0,1,frac])
                value=mesh.grid(field)[mesh.elem]@basis.T
                for left in (120.,144.):
                    if left>=edge:continue
                    mask=radii_gl[:,0]>left
                    rad=radii_gl[mask];data=value[mask]
                    integral=((data/rad)@kernel.weights).sum()*mesh.h/10
                    square=((data**2*rad**2)@kernel.weights).sum()*mesh.h/2
                    upper=np.sqrt(square*(left**-3-edge**-3)/3)/5
                    np.testing.assert_allclose(integral,(weights[left]-weights[edge])@field,rtol=1e-8,atol=1e-34)
                    assert abs(integral)<=upper*(1+1e-12)
                    norms.append(dict(seed=seed,fraction=frac,left=left,right=edge,moment=integral,bound=upper,
                        measured_norm=np.sqrt(square),required_unseen_norm=5*np.sqrt(3*edge**3)*20e-6*abs(NORMS[seed,.15,frac])))
        table(f"tail-norm-L{edge}-h{rate}.csv",norms)
    print("Newton independent source",edge,rate,flush=True)


if __name__=="__main__":run(*map(int,sys.argv[1:]))
