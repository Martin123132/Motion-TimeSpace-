"""Evidence matrix for individual branches, crossed boundaries, old wall and convergence."""
from assess import *
from scipy.special import spherical_jn


BASE=((144,4,16),(144,4,32),(144,5,16),(144,5,32),(168,4,16),(168,4,32))


def summarize():
    other_checks()
    cases=[(*case,"inner","outer",4) for case in BASE]+[(144,4,32,"fine","outerfine",4),(144,4,32,"inner","outer",9)]
    ledger=[];both=[];all_budgets={};summary=[];boundary_rows=[]
    def gate(case,key,maximum):
        ledger.append(dict(case=case,test=key,maximum_ppm=maximum,limit_ppm=20.,pass_20ppm=maximum<=20.))
    for edge,rate,level,inner,outer,steps in cases:
        tag=f"L{edge}-h{rate}-q{level}-{inner}-{outer}-t{steps}"
        ordinary=run(edge,rate,level,inner,outer,steps)
        witness=read(HERE/f"remote-L{edge}-h{rate}-q{level}-{outer}.csv")
        members=read(HERE/f"members-{tag}.csv")
        for seed in (1,-1):
            for frac in (.25,.5,.75,1.):
                for flag in (0,1):
                    pairrows={int(row["seed"]):row for row in members if float(row["fraction"])==frac and int(row["flag"])==flag}
                    fields={key:float(pairrows[seed][key])-float(pairrows[0][key]) for key in ("energy","transmitted","newton","determinant_face","curvature_face")}
                    relevant={int(row["seed"]):row for row in witness if (int(row["flag"]),float(row["fraction"]),float(row["b"]))==(flag,frac,121.)}
                    remote=float(relevant[seed]["by_parts"])-float(relevant[0]["by_parts"])
                    point=float(pairrows[seed]["exterior_curvature"])-float(pairrows[0]["exterior_curvature"])
                    remote_prediction=fields["transmitted"]+point-remote
                    both.append(dict(case=tag,seed=seed,flag=flag,fraction=frac,**fields,remote_prediction=remote_prediction,
                        remote_vs_energy_relative=(remote_prediction-fields["energy"])/abs(fields["energy"]),
                        remote_vs_newton_relative=(remote_prediction-fields["newton"])/abs(fields["newton"])))
        for row in ordinary:
            seed,frac,width=row["seed"],row["fraction"],row["width"]
            for b in (120.5,121.):
                by_member={(int(item["seed"]),int(item["flag"])):item for item in witness
                           if float(item["fraction"])==frac and float(item["b"])==b}
                remote={key:signed(lambda host,flag:float(by_member[host,flag][key]),seed)/row["unit"]
                        for key in ("scalar","physical","by_parts")}
                answer=row["transmitted"]+row["exterior_curvature"]-remote["by_parts"]
                boundary_rows.append(dict(case=tag,seed=seed,width=width,fraction=frac,b=b,
                   scalar_error=remote["scalar"]-row["determinant_face"],physical_error=remote["by_parts"]-row["curvature_face"],
                   independent_derivative_error=remote["by_parts"]-remote["physical"],remote_prediction=answer,
                   remote_newton_error=answer-row["newton"],remote_energy_error=answer-row["energy"]))
        case_rows=[row for row in boundary_rows if row["case"]==tag]
        for field in ("scalar_error","physical_error","independent_derivative_error","remote_newton_error","remote_energy_error"):
            gate(tag,field,max(abs(row[field]) for row in case_rows))
        for field in ("forecast_error","direct_minus_newton","internal_join"):
            gate(tag,field,max(abs(row[field]) for row in ordinary))
        all_budgets[tag]=ordinary
        row=next(row for row in ordinary if (row["seed"],row["width"],row["fraction"])==(1,.15,1.))
        summary.append(dict(case=tag,positive_final_trace_ppm=row["determinant_face"],newton_ppm=row["newton"],far_curvature_ppm=row["curvature_face"],
            max_physical_newton_ppm=max(abs(entry["remote_newton_error"]) for entry in case_rows),
            max_physical_energy_ppm=max(abs(entry["remote_energy_error"]) for entry in case_rows),
            max_scalar_transfer_ppm=max(abs(entry["scalar_error"]) for entry in case_rows)))
    for first,second in ((cases[1],cases[3]),(cases[1],cases[5]),(cases[1],cases[-2]),(cases[1],cases[-1]),(cases[0],cases[2]),(cases[0],cases[4])):
        def ident(case):return "L{}-h{}-q{}-{}-{}-t{}".format(*case)
        names=(ident(first),ident(second))
        series=[{(row["seed"],row["width"],row["fraction"],row["b"]):row for row in boundary_rows if row["case"]==name} for name in names]
        assert series[0].keys()==series[1].keys()
        for field in ("remote_prediction","remote_newton_error"):
            gate(" vs ".join(names),field,max(abs(series[0][key][field]-series[1][key][field]) for key in series[0]))
    old=read(PREV/"refined-budget.csv")
    for case in ("continued640","q16res320"):
        gate("old wall retained:"+case,"physical_newton_error_ppm",max(abs(float(row["physical_newton_error_ppm"])) for row in old if row["case"]==case))
    tails=[]
    for edge,rate in ((144,4),(144,5),(168,4)):
        for row in read(HERE/f"tail-norm-L{edge}-h{rate}.csv"):
            seed,frac=int(row["seed"]),float(row["fraction"])
            for width in (.15,.30):
                unit=abs(NORMS[seed,width,frac])*1e-6
                tails.append(dict(edge=edge,rate=rate,seed=seed,fraction=frac,width=width,left=float(row["left"]),
                    signed_ppm=float(row["moment"])/unit,envelope_ppm=float(row["bound"])/unit,
                    unresolved_tail_sufficient_L2=5*np.sqrt(3*edge**3)*20*unit))
    table("paired-branches.csv",both);table("remote-transfer.csv",boundary_rows)
    table("refinement-summary.csv",summary);table("gate-ledger.csv",ledger);table("finite-tail-bounds.csv",tails)
    for row in summary:print(row)


if __name__=="__main__":summarize()
