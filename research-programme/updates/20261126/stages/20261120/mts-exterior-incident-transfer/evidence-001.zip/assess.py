"""Compare the exterior-transmitted conormal against interior metric and independent Newton evolution."""
from local_stage import *
from functools import lru_cache
from math import fsum
from readout import TERMS
from tidal import LABELS
from compare import NORMS


@lru_cache(maxsize=None)
def indexed(edge,rate,level,tag,steps):
    result={}
    for flag in (0,1):
        for seed in (0,1,-1):
            rows=read(HERE/f"response-L{edge}-h{rate}-q{level}-{tag}-t{steps}-off{flag}-s{seed}.csv")
            for row in rows:
                key=(seed,flag,float(row["fraction"]),row["channel"],row["term"])
                assert key not in result
                result[key]=float(row["value"])
    return result


@lru_cache(maxsize=None)
def material(edge,rate):
    return {(int(row["seed"]),int(row["flag"]),float(row["fraction"]),float(row["lower"]),float(row["upper"])):float(row["moment"])
            for row in read(HERE/f"newton-L{edge}-h{rate}.csv")}


def signed(fn,seed):
    return fsum((1 if host else -1)*(1 if not flag else -1)*fn(host,flag) for host in (0,seed) for flag in (0,1))


def run(edge,rate,level,inner="inner",outer="outer",steps=4):
    out=[];members=[];forecast=read(HERE/f"forecast-L{edge}-h{rate}.csv")
    dat=[indexed(edge,rate,level,label,steps if idx==2 else 4) for idx,label in enumerate(("near","middle",inner,outer))]
    for frac in (.25,.5,.75,1.):
        pred={(int(row["seed"]),int(row["flag"])):float(row["prediction"]) for row in forecast if int(row["q"])==level and float(row["radius"])==120. and float(row["fraction"])==frac}
        def values(fetch,newton,frozen):
            def electric(patch,col):return fetch(patch,"electric",col)
            def conormal(patch,site):
                return (1 if site=="low" else -1)*fsum(electric(patch,kind+"_face_"+site) for kind in ("ricci","extrinsic"))
            def bulk(patch):return fsum(electric(patch,col) for col in LABELS if "face" not in col and col!="energy")
            trace120=fetch(2,"trace","outer")
            trace122=fetch(3,"trace","outer")
            exterior_trace=trace122-fsum(fetch(3,"trace",term) for term in TERMS)
            boundary=conormal(3,"high")+electric(3,"energy")-bulk(3)
            left=conormal(2,"high")
            interior=conormal(0,"low")+fsum(bulk(patch) for patch in range(3))
            energy=fsum(electric(patch,"energy") for patch in range(3))
            return dict(determinant_face=trace120,determinant_forecast=frozen,exterior_scalar=exterior_trace,
                scalar_transfer_error=exterior_trace-trace120,forecast_error=trace120-frozen,
                curvature_face=left,exterior_curvature=boundary,curvature_transfer_error=boundary-left,
                interior_predicted=interior-left,transmitted=interior-boundary,energy=energy,newton=newton,
                transmitted_minus_energy=(interior-boundary)-energy,transmitted_minus_newton=(interior-boundary)-newton,
                direct_minus_newton=(interior-left)-newton,energy_minus_newton=energy-newton,
                internal_join=conormal(1,"low")-conormal(0,"high")+conormal(2,"low")-conormal(1,"high"))
        def newton(host,flag):
            masses=material(edge,rate)
            return fsum(val for (seed,kind,fraction,lower,upper),val in masses.items() if (seed,kind,fraction)==(host,flag,frac) and 6<=lower<upper<=120)
        for seed in (0,1,-1):
            for flag in (0,1):
                result=values(lambda num,ch,term:dat[num][seed,flag,frac,ch,term],newton(seed,flag),pred[seed,flag])
                members.append(dict(seed=seed,flag=flag,fraction=frac,**result))
        for seed in (-1,1):
            result=values(lambda num,ch,term:signed(lambda host,flag:dat[num][host,flag,frac,ch,term],seed),
                         signed(newton,seed),signed(lambda host,flag:pred[host,flag],seed))
            for width in (.15,.30):
                unit=abs(NORMS[seed,width,frac])*1e-6
                out.append(dict(seed=seed,width=width,fraction=frac,unit=unit,**{col:val/unit for col,val in result.items()}))
    suffix=f"L{edge}-h{rate}-q{level}-{inner}-{outer}-t{steps}"
    table(f"budget-{suffix}.csv",out);table(f"members-{suffix}.csv",members)
    print(suffix,*(round(max(abs(row[key]) for row in out),6) for key in ("forecast_error","scalar_transfer_error","curvature_transfer_error","transmitted_minus_energy","transmitted_minus_newton","direct_minus_newton","energy_minus_newton")),flush=True)
    return out


def other_checks():
    base=material(120,5)
    original=read(traced.checked("newton-rings-extended.csv"))
    checks=[]
    for (seed,flag,frac,low,high),delta in base.items():
        if not seed:
            assert delta==0
            continue
        previous=fsum(float(row["physical_moment"]) for row in original if
            (int(row["seed"]),int(row["flag"]),float(row["fraction"]))==(seed,flag,frac) and low<=float(row["lower"])<float(row["upper"])<=high)
        checks.append(dict(seed=seed,flag=flag,fraction=frac,lower=low,upper=high,original=previous,repeat=delta,
            error_ppm=(previous-delta)/(abs(NORMS[seed,.15,frac])*1e-6)))
    assert max(abs(row["error_ppm"]) for row in checks)<.01
    table("newton-replay-check.csv",checks)
    rows=[]
    for edge,rate in ((120,5),(144,4),(144,5),(168,4)):
        data=read(HERE/f"static-L{edge}-h{rate}.csv")
        for level in (1,16,32):
            for seed in (-1,1):
                for radius in (6.,119.,120.):
                    selection={(int(row["seed"]),int(row["flag"])):row for row in data if float(row["radius"])==radius and int(row["q"])==level}
                    derived={col:signed(lambda host,flag:float(selection[host,flag][col]),seed) for col in
                             ("incident","exterior_source","exterior_prediction","metric_left","metric_right")}
                    assert derived["incident"]==0
                    rows.append(dict(edge=edge,rate=rate,q=level,seed=seed,radius=radius,**derived,
                        face_error=derived["metric_left"]-derived["exterior_prediction"]))
    table("static-transfer-check.csv",rows)


if __name__=="__main__":
    if len(sys.argv)==1:other_checks()
    else:
        run(*map(int,sys.argv[1:4]),*(sys.argv[4:6]),**({"steps":int(sys.argv[6])} if len(sys.argv)>6 else {}))
