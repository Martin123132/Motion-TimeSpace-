"""Require saved preparations, numerical coverage, independent readouts and unchanged source receipts."""
from local_stage import *
from report_data import BASE
from propagate import PATCHES


def run():
    guard()
    for name,digest in registry.items():assert sha(PREV/name)==digest,name
    states_expected={(edge,rate,level,label,4) for edge,rate,level in BASE for label in ("near","middle","inner","outer")}
    states_expected.update(((144,4,32,"fine",4),(144,4,32,"outerfine",4),(144,4,32,"inner",9),
                            (144,5,32,"whole",4),(144,5,32,"fine",4),(144,5,32,"cut",4)))
    states_expected.update((144,5,64,tag,steps) for tag,steps in (("near",4),("near",9),("middle",4),("inner",4),("outer",4)))
    stems=set()
    for edge,rate,level,label,steps in states_expected:
        left,right,grid,ranges=PATCHES[label]
        for flag in (0,1):
            for seed in (0,1,-1):
                stem=f"L{edge}-h{rate}-q{level}-{label}-t{steps}-off{flag}-s{seed}"
                stems.add(stem)
                with np.load(HERE/f"state-{stem}.npz",allow_pickle=False) as pkt:
                    np.testing.assert_array_equal(pkt["r"],(np.arange(round(left*grid),round(right*grid))+.5)/grid)
                    arr=pkt["change"]
                    assert arr.shape==(4,22,2,len(pkt["r"])) and np.isfinite(arr).all()
                data=read(HERE/f"response-{stem}.csv")
                assert len(data)==len(ranges)*4*20
                keys={(row["channel"],row["term"],row["fraction"],row["lower"],row["upper"]) for row in data}
                assert len(keys)==len(data) and all(np.isfinite(float(row["value"])) for row in data)
    assert {item.stem[6:] for item in HERE.glob("state-*.npz")}==stems
    pins=[]
    for edge,rate in ((120,5),(144,4),(144,5),(168,4)):
        for seed in (-1,1):
            fname=formation(edge,rate,seed)
            pins.append(dict(kind="formation",file=str(fname.relative_to(HERE.parent)),sha256=sha(fname)))
            with np.load(fname) as pkt:
                np.testing.assert_array_equal(TIMES,pkt["x"])
                assert all(np.isfinite(pkt[key]).all() for key in ("mono","density","velocity"))
        for name,numer in (("static",54),("forecast",144),("newton",None)):
            data=read(HERE/f"{name}-L{edge}-h{rate}.csv")
            assert len(data)==(numer if numer is not None else 24*len({(row["lower"],row["upper"]) for row in data}))
    for row in read(HERE/"native-sources.csv"):
        assert sha(HERE.parent/row["source"])==row["sha256"]
        pins.append(dict(kind="native normal clock",file=row["source"],sha256=row["sha256"]))
    table("input-receipts.csv",pins)
    assert len(read(HERE/"remote-transfer.csv"))==8*32 and len(read(HERE/"whole-domain-check.csv"))==32
    assert len(read(HERE/"paired-branches.csv"))==8*16 and len(read(HERE/"wall-factorization.csv"))==32
    assert len(read(HERE/"native-weyl-check.csv"))==5*3*2*2
    for row in read(HERE/"gate-ledger.csv"):
        assert (float(row["maximum_ppm"])<=float(row["limit_ppm"]))==(row["pass_20ppm"]=="True")
    assert len(read(HERE/"remote-fixtures.csv"))==10
    assert len(read(HERE/"inner-fixtures.csv"))==5 and len(read(HERE/"two-remote-faces.csv"))==448
    assert len(read(HERE/"whole-minus-patch-components.csv"))==48
    rows=read(HERE/"prospective-q64.csv")
    assert len(rows)==128
    from itertools import product
    selectors=("seed","width","fraction","left","right","steps")
    expected=set(product((-1,1),(.15,.30),(.25,.5,.75,1.),(5.,5.25),(120.5,121.),(4,9)))
    assert {tuple(float(row[key]) for key in selectors) for row in rows}==expected
    for row in rows:
        assert (max(abs(float(row[key])) for key in ("newton_error","energy_error","time_shift"))<=20)==(row["passed"]=="True")
        for error,reference in (("newton_error","newton"),("energy_error","energy")):
            reproduced=(float(row["predicted"])-float(row[reference]))/float(row["full_scale"])*1e6
            np.testing.assert_allclose(float(row[error]),reproduced,rtol=4e-15,atol=1e-12)
    assert len(read(HERE/"native-weyl-physical.csv"))==75 and len(read(HERE/"native-clock-replay.csv"))==8
    assert len(read(HERE/"prospective-members.csv"))==128
    from q64 import guard_frozen
    guard_frozen()
    assert not list(HERE.glob("*.partial")) and not (HERE/"__pycache__").exists()
    files={path.name:sha(path) for path in sorted(HERE.iterdir()) if path.is_file() and path.name!="seal.json"}
    for name in ("DERIVATION.md","RESULTS.md","REPLAY.md","DESIGN.md","whole-domain-check.csv","finite-tail-bounds.csv","native-absolute-weyl.csv"):
        assert name in files
    total=sum(len(read(HERE/key)) for key in files if key.endswith(".csv"))
    data=(json.dumps(dict(parent=sha(PREV/"seal.json"),histories=len(stems),csv_rows=total,files=files),sort_keys=True,indent=2)+"\n").encode()
    if "--seal" in sys.argv:put("seal.json",data)
    assert data==(HERE/"seal.json").read_bytes()
    print(len(files),"files;",total,"CSV rows;",len(stems),"histories;",sha(HERE/"seal.json"))


if __name__=="__main__":run()
