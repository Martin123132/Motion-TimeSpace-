"""Test both boundary reconstructions without angular target density from the intervening 6–120 Mpc."""
from assess import *
from report_data import BASE


def run():
    source=read(HERE/"remote-transfer.csv");whole=read(HERE/"whole-domain-check.csv")
    result=[]
    for edge,rate,level,tag in [(*case,"near") for case in BASE]+[(144,5,32,"whole")]:
        direct={}
        for flag in (0,1):
            for host in (0,1,-1):
                for row in read(HERE/f"response-L{edge}-h{rate}-q{level}-{tag}-t4-off{flag}-s{host}.csv"):
                    if float(row["lower"])==6. and row["channel"]=="electric" and row["term"] in ("ricci_face_low","extrinsic_face_low"):
                        direct[host,flag,float(row["fraction"]),row["term"]]=float(row["value"])
        witness=read(HERE/f"remote-L{edge}-h{rate}-q{level}-{tag}.csv")
        original=f"L{edge}-h{rate}-q{level}-inner-outer-t4"
        for seed in (-1,1):
            for frac in (.25,.5,.75,1.):
                for width in (.15,.30):
                    unit=abs(NORMS[seed,width,frac])*1e-6
                    prior=signed(lambda host,flag:fsum(direct[host,flag,frac,term] for term in ("ricci_face_low","extrinsic_face_low")),seed)/unit
                    sources=[row for row in (whole if tag=="whole" else source) if (tag=="whole" or row["case"]==original)
                             and (int(row["seed"]),float(row["fraction"]),float(row["width"]))==(seed,frac,width)]
                    for left in (5.,5.25):
                        chosen={(int(row["seed"]),int(row["flag"])):row for row in witness if float(row["fraction"])==frac and float(row["b"])==left}
                        new=signed(lambda host,flag:float(chosen[host,flag]["by_parts"]),seed)/unit
                        plain=signed(lambda host,flag:float(chosen[host,flag]["physical"]),seed)/unit
                        for row in sources:
                            key="whole_minus_newton" if tag=="whole" else "remote_newton_error"
                            energy="whole_minus_energy" if tag=="whole" else "remote_energy_error"
                            result.append(dict(edge=edge,rate=rate,q=level,mesh=tag,seed=seed,fraction=frac,width=width,
                                inner_witness=left,outer_witness=row["witness" if tag=="whole" else "b"],
                                near_face_shift=new-prior,near_integration_parts=new-plain,earlier_error=float(row[key]),
                                predicted_minus_newton=float(row[key])+new-prior,predicted_minus_energy=float(row[energy])+new-prior))
    table("two-remote-faces.csv",result)
    for case in sorted({(row["edge"],row["rate"],row["q"],row["mesh"]) for row in result}):
        group=[row for row in result if (row["edge"],row["rate"],row["q"],row["mesh"])==case]
        print(case,*(max(abs(row[key]) for row in group) for key in ("near_integration_parts","near_face_shift","predicted_minus_newton","predicted_minus_energy")))


if __name__=="__main__":run()
