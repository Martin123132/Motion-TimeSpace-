"""Extend the original RK formation at its unchanged physical resolution, seed and times."""
from local_stage import *


def run(edge,rate,seed):
    guard()
    path=formation(edge,rate,seed)
    if path.exists():
        with np.load(path) as packet:
            assert packet["x"][-1]==TIMES[-1] and np.isfinite(packet["density"]).all()
        return
    sim=sphere(edge,rate)
    initial=sim.init()
    state=(seed*initial[0],*initial[1:])
    reference=sphere(120,rate).init()
    for longer,old in zip(initial,reference):
        np.testing.assert_allclose(longer[...,:old.shape[-1]],old,rtol=1e-13,atol=2e-17)
    for begin,end in zip(TIMES,TIMES[1:]):
        count=max(8,int(round((end-begin)/(family.DLOG/176))))
        step=(end-begin)/count
        for tick in range(count):
            if tick%16==0:guard()
            time=begin+tick*step
            def move(rate,dt):return tuple(val+dt*delta for val,delta in zip(state,rate))
            first=sim.rates(state,time)
            second=sim.rates(move(first,step/2),time+step/2)
            third=sim.rates(move(second,step/2),time+step/2)
            fourth=sim.rates(move(third,step),time+step)
            state=tuple(val+step/6*(one+2*two+2*three+four) for val,one,two,three,four in zip(state,first,second,third,fourth))
    assert all(np.isfinite(field).all() for field in state)
    pack(path.name,x=TIMES,mono=state[0],density=state[1],velocity=state[2])
    print(path.name,sha(path),flush=True)


if __name__=="__main__":
    for config in sys.argv[1:]:run(*map(int,config.split(":")))
