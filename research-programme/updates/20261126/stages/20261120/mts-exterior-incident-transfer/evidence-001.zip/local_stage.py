"""Local receipt, write-once outputs and the previous sealed family."""
import csv
import hashlib
import io
import json
import os
import sys
from pathlib import Path

HERE=Path(__file__).resolve().parent
PREV=HERE.parent/"mts-evolved-conformal-trace-20261120"
for variable in ("OMP_NUM_THREADS","MKL_NUM_THREADS","OPENBLAS_NUM_THREADS","NUMEXPR_NUM_THREADS","BLIS_NUM_THREADS"):
    os.environ[variable]="1"
sys.dont_write_bytecode=True


def sha(path):
    with path.open("rb") as handle:return hashlib.file_digest(handle,"sha256").hexdigest()


assert sha(PREV/"seal.json")=="b52f96426af08d5d0456e8b7715dc19e0b4bf891e68a20e019029ea3158b6ae3"
registry=json.loads((PREV/"seal.json").read_bytes())["files"]
for name in ("trace_campaign.py","edge_system.py","readout.py","edge_prediction.py","tidal.py","compare.py","formation-grid-contrast.csv","refined-budget.csv"):
    assert sha(PREV/name)==registry[name]
sys.path.insert(0,str(PREV))
import readout as metric_readout
import trace_campaign as traced
sys.path.insert(0,str(PREV))
import edge_prediction
import tidal as metric_tide
from balance import family,np,DURATION
import states
from retarded import TIMES
from anchor import saved
sys.path.insert(0,str(HERE))


def guard():
    traced.guard()
    assert not (HERE/"STOP-REQUESTED").exists()


def put(name,content):
    guard()
    target=HERE/name
    if target.exists():assert target.read_bytes()==content,name
    else:
        partial=target.with_suffix(target.suffix+".partial")
        with partial.open("xb") as handle:handle.write(content)
        partial.rename(target)


def pack(name,**values):
    result=io.BytesIO()
    np.savez_compressed(result,**values)
    put(name,result.getvalue())


def table(name,rows):
    stream=io.StringIO(newline="")
    writer=csv.DictWriter(stream,fieldnames=tuple(rows[0]),lineterminator="\n")
    writer.writeheader();writer.writerows(rows)
    put(name,stream.getvalue().encode())


def read(path):
    with path.open(newline="") as handle:return list(csv.DictReader(handle))


def sphere(edge,rate):
    return family.BalancedNative("heavy",edge,edge*rate,False,"native36",family.SPAN*family.DLOG)


def formation(edge,rate,seed):
    if edge==120 or (edge,rate,seed)==(144,4,1):
        return saved(f"evolved-heavy-L{edge}-h{rate}-t176.npz" if seed==1 else f"collar-heavy-L{edge}-h{rate}--1.npz")
    return HERE/f"formation-L{edge}-h{rate}-s{seed}.npz"


def start_state(sim,edge,rate,seed):
    if not seed:return tuple(np.zeros_like(field) for field in sim.init())
    with np.load(formation(edge,rate,seed),allow_pickle=False) as packet:
        assert packet["x"][-1]==TIMES[-1]
        return tuple(packet[key] for key in ("mono","density","velocity"))
