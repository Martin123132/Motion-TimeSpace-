"""Regular exterior Weyl coefficient for the actual native scalar modes, in geometric Mpc units."""
from local_stage import *
from balance import clock,brentq
from scipy.interpolate import CubicSpline
from scipy.special import spherical_jn
from math import fsum


def run():
    trace=clock.Traces("heavy",sphere(120,4))
    output=[];pins=[];phase_checks=[]
    for flag in (0,1):
        filename=clock.checked(clock.NORMAL,f"trace-heavy-off{flag}.npz")
        with np.load(filename) as packet:
            names=packet["names"].tolist()
            data=dict(zip(names,packet["values"].transpose(2,0,1)))
            times=packet["dt"];wave=packet["k"][:,None]
        bg=states.native("heavy",flag)
        np.testing.assert_array_equal(wave[:,0],bg["k"])
        pins.append(dict(branch=flag,source=str(filename.relative_to(HERE.parent)),sha256=sha(filename),modes=len(wave),epochs=len(times)))
        hub=data["H"];den=data["D"];momentum=data["Q"];stress=data["Pi"]
        bank={"saved":data["W"],"metric":(data["eta"]+data["dsigma"]/wave)/2,
              "matter":-(den+3*hub*momentum/wave+stress)/(2*wave**2)}
        scale=data["a"].mean(axis=0)
        logratio=np.log(scale/scale[0])
        for radius in (6.,119.,120.,144.,168.):
            arg=wave[:,0]*radius
            kernel=bg["w"]*wave[:,0]*spherical_jn(1,arg)/radius/5
            direct=bg["w"]*(wave[:,0]*spherical_jn(2,arg,True)/radius+3*spherical_jn(2,arg)/radius**2)/5
            err=np.max(abs(direct-kernel))/np.max(abs(kernel))
            assert err<1e-12
            phase_checks.append(dict(flag=flag,radius=radius,mixed_kernel_relative=err))
            for name,transfer in bank.items():
                initial=transfer[:,0]
                increments=transfer-initial[:,None]
                curve=CubicSpline(times,increments,axis=-1,extrapolate=False)
                angular=CubicSpline(times,logratio,extrapolate=False)
                for frac in (0.,.25,.5,.75,1.):
                    time=brentq(lambda val:float(trace.proper(val))-frac*DURATION,0.,trace.proper.x[-1],xtol=5e-16) if frac else 0.
                    drift=curve(time)
                    delta=(drift+np.expm1(-2*angular(time))*(initial+drift))/scale[0]**2
                    first=-2*fsum(kernel*initial)/scale[0]**2
                    shift=-2*fsum(kernel*delta)
                    output.append(dict(flag=flag,radius=radius,fraction=frac,field=name,conformal_offset=time,
                                axial_launch=first,axial_change=shift,axial=first+shift,transverse=-(first+shift)/2))
    table("native-absolute-weyl.csv",output);table("native-sources.csv",pins);table("native-mode-controls.csv",phase_checks)
    compare=[]
    for radius in (6.,119.,120.,144.,168.):
        for flag in (0,1,2):
            def value(frac,field,key):
                if flag==2:
                    return fsum((1-2*row["flag"])*row[key] for row in output if (row["fraction"],row["radius"],row["field"])==(frac,radius,field))
                return next(row[key] for row in output if (row["fraction"],row["radius"],row["field"],row["flag"])==(frac,radius,field,flag))
            for key in ("axial","axial_change"):
                denominator=max(abs(value(frac,"saved",key)) for frac in (.25,.5,.75,1.))
                for name in ("metric","matter"):
                    diff=max(abs(value(frac,name,key)-value(frac,"saved",key)) for frac in (.25,.5,.75,1.))
                    compare.append(dict(radius=radius,branch=flag,quantity=key,prediction=name,peak=denominator,absolute=diff,ppm=1e6*diff/denominator))
    table("native-weyl-check.csv",compare)


if __name__=="__main__":run()
