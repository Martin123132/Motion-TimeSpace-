"""Decompose unbroken-minus-patched predictions at fixed external boundary and same preparation."""
from assess import *


def run():
    whole={}
    for flag in (0,1):
        for seed in (0,1,-1):
            for row in read(HERE/f"response-L144-h5-q32-whole-t4-off{flag}-s{seed}.csv"):
                if row["channel"]=="electric":whole[seed,flag,float(row["fraction"]),float(row["lower"]),row["term"]]=float(row["value"])
    old={name:indexed(144,5,32,name,4) for name in ("near","middle","inner")}
    signed_rows=[]
    for seed in (-1,1):
        for frac in (.25,.5,.75,1.):
            for width in (.15,.30):
                scale=abs(NORMS[seed,width,frac])*1e-6
                for name,sections in (("near",(6.,)),("middle",(15.,48.,96.)),("inner",(119.,))):
                    def difference(key):
                        pos=sections[:1] if key.endswith("_low") else sections[-1:] if key.endswith("_high") else sections
                        return signed(lambda host,flag:fsum(whole[host,flag,frac,loc,key] for loc in pos)-old[name][host,flag,frac,"electric",key],seed)/scale
                    result={key:difference(key) for key in LABELS}
                    combined=fsum(result[key] for key in LABELS[:-1])
                    bulk=fsum(result[key] for key in LABELS[:-1] if "face" not in key)
                    signed_rows.append(dict(seed=seed,fraction=frac,width=width,patch=name,bulk=bulk,
                        local_predicted=combined,local_residual=combined-result["energy"],**result))
    table("whole-minus-patch-components.csv",signed_rows)
    for row in signed_rows:
        if row["seed"]==-1 and row["fraction"]==1 and row["width"]==.3:
            print(row["patch"],*[round(row[key],3) for key in ("local_residual","ricci_face_low","ricci_face_high","ricci_interior","extrinsic_interior","bulk")])


if __name__=="__main__":run()
