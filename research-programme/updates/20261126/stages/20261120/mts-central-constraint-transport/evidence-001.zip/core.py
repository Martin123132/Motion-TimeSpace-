"""Unchanged preparation; an alternative ADM trace derived on the same truncated angular system."""
import csv
import hashlib
import io
import json
import sys
from pathlib import Path
from types import MethodType

HERE=Path(__file__).resolve().parent
UP=HERE.parent/"mts-central-scalar-detector-20261120"


def sha(path):
    with path.open("rb") as stream:return hashlib.file_digest(stream,"sha256").hexdigest()


assert sha(UP/"seal.json")=="f8cb080156d523433dc302e2c84d671792b02b71b389aa0485b9686bd974a588"
registry=json.loads((UP/"seal.json").read_bytes())["files"]
for key in ("curved.py","detector.py","curved-contrast.csv","curved-members.csv","transverse-test.csv"):
    assert sha(UP/key)==registry[key]
sys.path.insert(0,str(UP))
import curved as central
from curved import DURATION, family, ep, np
from constraint_rate import measure,spatial,pair,mul,exp,square
from scipy.integrate import simpson


def guard():
    central.guard()
    assert not (HERE/"STOP-REQUESTED").exists()


def put(name,data):
    guard()
    path=HERE/name
    if path.exists():assert path.read_bytes()==data,path
    else:
        tmp=path.with_suffix(path.suffix+".partial")
        with tmp.open("xb") as stream:stream.write(data)
        tmp.rename(path)


def table(name,rows):
    stream=io.StringIO(newline="")
    writer=csv.DictWriter(stream,fieldnames=tuple(rows[0]),lineterminator="\n")
    writer.writeheader();writer.writerows(rows)
    put(name,stream.getvalue().encode())


def read(path):
    with path.open(newline="") as stream:return list(csv.DictReader(stream))


def ham(shell,state):
    ell,bend,_,_,trace,radial=state[:6].real
    invr=exp(-ell);volume=exp(-ell-2*bend)
    energy=state[17].real.copy()
    unit=pair(np.ones_like(shell.r))
    for spec in range(3 if shell.flag else 2):
        dens,phase=state[8+2*spec:10+2*spec].real
        speed=square(mul(invr,shell.diff(phase)))
        root=np.sqrt(1+speed[0])
        energy+=shell.rho[spec]*mul(dens,mul(volume,pair(root,speed[1]/(2*root))))
    if not shell.flag:
        wave,zeta=state[14:16]
        grad=mul(square(invr),square(shell.diff(wave.real))+square(shell.diff(wave.imag)))/shell.mu**2
        energy+=shell.rho[-1]*mul(exp(2*wave.real),unit+square(zeta.real+trace/(2*shell.mu))+square(zeta.imag-unit)+grad)/2
    return spatial(shell,state[:4].real)+2*square(trace)/3-1.5*square(radial)-2*energy


def system(grid,flag,seed,scheme,edge=3):
    for level in (1,64):
        filename=f"launch-L144-h5-q{level}-off{flag}-s{seed}.npz"
        assert sha(central.PARENT/filename)==central.pins[filename]
    if scheme.startswith(("lifted-","green-")):
        from unittest.mock import patch
        import propagate
        prefix="green" if scheme.startswith("green-") else "lift-x2"
        receipt=next(r for r in read(HERE/f"{prefix}-s{seed}-receipt.csv") if int(r["flag"])==flag)
        new=HERE/receipt["file"]
        assert sha(new)==receipt["sha256"]
        previous=propagate.path
        with patch.object(propagate,"path",lambda edge,rate,speed,flag,seed:
                          new if speed==64 else previous(edge,rate,speed,flag,seed)):
            shell=central.shell_for(144,5,64,flag,seed,0,edge,grid)
        scheme=scheme.split("-",1)[1]
    else:
        shell=central.shell_for(144,5,64,flag,seed,0,edge,grid)
    if scheme=="adm":
        shell.project=0
        old=shell.dynamics
        def standard(self,time,state,details=False):
            result=old(time,state,details)
            if not details:
                correction=ham(self,state)
                result[4]+=correction
                if not self.flag:result[15]-=correction/(2*self.mu)
            return result
        shell.dynamics=MethodType(standard,shell)
    elif scheme!="original":raise ValueError(scheme)
    central.configure(shell,"trace6")
    return shell


def path_defect(shell,increment,points=3):
    result=0.
    for node,weight in zip(*np.polynomial.legendre.leggauss(points)):
        state=shell.initial+((node+1)/2)*increment
        defect,variation=measure(shell,state,increment,True)
        window=ep.Window(shell,state,increment,8)
        fixed,moved=window.times(defect,variation)
        result=result+weight*np.stack((fixed,moved),axis=-1)/12
    return result


def transport(shell,time,state):
    rates=shell.dynamics(time,state)
    defect,variation=measure(shell,state,rates,True)
    info=shell.dynamics(time,state,True)
    window=ep.Window(shell,state,rates,8)
    fixed,moved=window.times(defect,variation)
    trace,shear=state[4:6].real
    factor=(2*trace/3+shear/2) if shell.project else 2*trace
    local=window.times(defect,mul(factor,defect))[0]
    flux=window.weak_flux(info["mom_r"],info["mom_theta"][1])
    return np.stack((fixed,moved,local,flux),axis=-1)/6


def run(scheme,grid,steps,flag):
    ep.getcontext().prec=40
    count=128*steps
    dt=DURATION*8/count
    for seed in (0,1,-1):
        guard()
        shell=system(grid,flag,seed,scheme)
        advance=central.traced.collar.stepper(shell,dt)
        shift=np.zeros_like(shell.initial)
        saved=[];rates=[];records=[]
        for tick in range(count+1):
            if tick%16==0:guard()
            rates.append(transport(shell,tick*dt,shell.initial+shift))
            if tick and tick%(count//4)==0:
                saved.append(shift.copy())
                jac={(width,channel):val for width,channel,val in central.measure(shell,tick*dt,shift)}
                defect=path_defect(shell,shift)
                two=path_defect(shell,shift,2)
                for stride in (1,2,4):
                    terms=simpson(np.array(rates[::stride]),dx=dt*stride,axis=0)
                    for wi,width in enumerate(family.FRACTIONS):
                        fixed,moved,local,flux=64*terms[wi]
                        records.append(dict(seed=seed,flag=flag,grid=grid,steps=steps,scheme=scheme,fraction=tick/count,
                            width=width,stride=stride,ricci=64*jac[width,"ricci"],gauss=64*jac[width,"gauss"],
                            fixed_path=64*defect[wi,0],ruler_path=64*defect[wi,1],path_quad_error=64*sum(defect[wi]-two[wi]),
                            fixed_time=fixed,ruler_time=moved,homogeneous=local,momentum=flux))
            if tick<count:shift=advance(tick*dt,shift)
        assert np.isfinite(saved).all()
        stem=f"{scheme}-n{grid}-p{steps}-off{flag}-s{seed}"
        stream=io.BytesIO()
        np.savez_compressed(stream,r=shell.r,change=saved)
        put(stem+".npz",stream.getvalue())
        table(stem+".csv",records)
        print(stem,"saved",flush=True)


if __name__=="__main__":run(sys.argv[1],*map(int,sys.argv[2:]))
