"""Separate the physical source contract, the weak scalar solve, and detector resampling at launch."""
from representation import *
from math import fsum


def run(variant):
    material={};metric={};stagger={}
    for seed in (0,1,-1):
        for flag in (0,1):
            guard()
            key=seed,flag
            model=Native(flag,seed,variant)
            material[key]=model
            prefix={"original":"lift-x1","lifted":"lift-x2","green":"green"}[variant]
            with np.load(HERE/f"{prefix}-rhs-off{flag}-s{seed}.npz") as arch:
                vals=arch["src"][...,:round(3.2/model.h),:]
                assert float(arch["h"])==model.h
                basis=np.linalg.inv(legvander(2*arch["t"]-1,11))
            coef=(vals-vals[...,:1])@basis.T
            coef[...,0]+=vals[...,0]
            model.coeff["rhs"]=[coef]
            shell=system(160,flag,seed,"original" if variant=="original" else variant+"-original")
            state=shell.initial
            defect,_=measure(shell,state,np.zeros_like(state),True)
            info=shell.dynamics(0.,state,True)
            nr=exp(-state[0].real);trace,shear=state[4:6].real
            delta=mul(nr,shell.diff(shear)-2*shell.diff(trace)/3-shell.diff(shear-2*trace/3))
            stagger[key]=np.stack((defect[1],info["mom_r"][1]+delta[1],info["mom_theta"][1]))
    output=[];members=[]
    for width in family.FRACTIONS:
        half=ep.CENTER*width;lo,hi=ep.CENTER-half,ep.CENTER+half
        for frac in (.25,.5,.75,1.):
            path=8*DURATION*frac
            for mode in ("original","adm"):
                lower,upper=(lo-path,hi+path) if mode=="adm" else (lo,hi)
                faces=np.arange(1,round(3/model.h))*model.h
                inds=np.where((faces>lower)&(faces<upper))[0]
                face=faces[inds]
                bounds=np.r_[shell.r,faces,lower,upper,lo,hi,lo+path,hi-path]
                cuts=np.unique(bounds[(bounds>=lower)&(bounds<=upper)])
                for order in (8,14):
                    pts,weights=leggauss(order)
                    sizes=np.diff(cuts)/2
                    radius=(cuts[:-1,None]+sizes[:,None]*(1+pts)).ravel()
                    norm=(sizes[:,None]*weights).ravel()
                    operator=constraint_weights(radius,width,path,mode,order)*norm
                    tracew=constraint_weights(face,width,path,mode,order)[0]
                    inputs={};jumps={}
                    for key,model in material.items():
                        _,get,psi=model.metric(radius)
                        invpsi=exp(-5*pair(np.log(psi[0]),psi[1]/psi[0]))
                        exact_rhs=8*mul(invpsi,get("rhs"))[1]
                        ricci,others=model.fields(radius)
                        delta,jump=model.jumps(face,inds+1)
                        inputs[key]=np.stack((exact_rhs+others,ricci-exact_rhs))
                        jumps[key]=delta
                    for seed in (1,-1):
                        def contrast(fields):
                            return (fields[seed,0]-fields[0,0])-(fields[seed,1]-fields[0,1])
                        contract,regular=contrast(inputs)
                        jump=contrast(jumps)
                        hamilton,mr,tangent=CubicSpline(shell.r,contrast(stagger),axis=-1)(radius)
                        parts=dict(source_contract=operator[0]@contract,
                                   bulk_poisson=operator[0]@regular,face_poisson=tracew@jump,
                                   grid_H=operator[0]@hamilton,grid_M=operator[1]@mr+operator[2]@tangent)
                        output.append(dict(variant=variant,mode=mode,seed=seed,width=width,fraction=frac,order=order,
                                           **{key:64*val/6 for key,val in parts.items()}))
    table(f"launch-contributions-{variant}.csv",output)


def assess():
    truth={(int(r["seed"]),float(r["width"]),float(r["fraction"])):abs(float(r["full_newton"]))*1e-6 for r in read(UP/"curved-contrast.csv")}
    output=[]
    for variant in ("original","lifted","green"):
        data=read(HERE/f"launch-contributions-{variant}.csv")
        for mode in ("original","adm"):
            name=mode if variant=="original" else variant+"-"+mode
            measured={(int(r["seed"]),float(r["width"]),float(r["fraction"])):float(r["observed_ppm"]) for r in read(HERE/f"budget-{name}-n160-p8.csv") if r["stride"]=="1"}
            for row in data:
                if row["mode"]!=mode:continue
                seed,width,frac=int(row["seed"]),float(row["width"]),float(row["fraction"])
                scale=truth[seed,width,frac];obs=measured[seed,width,frac]
                parts={key:float(row[key])/scale for key in ("source_contract","bulk_poisson","face_poisson","grid_H","grid_M")}
                weak=fsum((parts["bulk_poisson"],parts["face_poisson"]))
                resample=parts["grid_H"]-(weak+parts["source_contract"])
                forecast=fsum((parts["grid_H"],parts["grid_M"]))
                output.append(dict(variant=variant,mode=mode,seed=seed,width=width,fraction=frac,order=row["order"],observed=obs,
                                  predicted=forecast,error=forecast-obs,weak_poisson=weak,sampling=resample,**parts))
    table("source-of-split.csv",output)


if __name__=="__main__":
    if sys.argv[1:]==["assess"]:assess()
    else:run(sys.argv[1])
