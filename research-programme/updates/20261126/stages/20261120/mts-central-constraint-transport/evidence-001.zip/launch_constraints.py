"""Flat ADM constraint propagation from the initial state alone, by a compact adjoint wave kernel."""
from core import *
from scipy.interpolate import CubicSpline
from scipy.special import spherical_jn


def weights(shell,width,path,order,extra=()):
    half=ep.CENTER*width
    lo,hi=ep.CENTER-half,ep.CENTER+half
    cells=np.r_[shell.r,lo,hi,lo+path,lo-path,hi+path,hi-path,extra]
    cuts=np.unique(cells[(cells>=lo-path)&(cells<=hi+path)])
    nodes,gl=np.polynomial.legendre.leggauss(order)
    dr=np.diff(cuts)/2
    radius=(cuts[:-1,None]+(1+nodes)*dr[:,None]).ravel()
    weights=(gl*dr[:,None]).ravel()
    return radius,wave_weights(radius,width,path,order)*weights


def wave_weights(radius,width,path,order):
    half=ep.CENTER*width
    lo,hi=ep.CENTER-half,ep.CENTER+half
    nodes,gl=np.polynomial.legendre.leggauss(order)
    r=radius[:,None]
    left=np.maximum(-1.,(lo-r)/path)
    right=np.minimum(1.,(hi-r)/path)
    span=np.maximum(0.,right-left)/2
    u=left+(1+nodes)*span
    s=r+path*u
    v=1-path**2*(1-u**2)/(2*r*s)
    vt=-(1-u**2)*(2*path/s-path**2*u/s**2)/(2*r)
    vr=(1-v)*(1/r+1/s)
    poly=(3*v**2-1)/2
    source=ep.weight(s,half)/s**2
    ds=ep.weight(s,half,1)/s**2-2*source/s
    base=s/r*source*poly
    time=u/r*(source+s*ds)*poly+s/r*source*3*v*vt
    radial=((source+s*ds)/r-s*source/r**2)*poly+s/r*source*3*v*vr
    integrate=lambda field:np.asarray((field@(gl/2))*span[:,0])
    initial=ep.weight(radius,half)/radius**2
    return np.stack((radius**2*(integrate(base+path*time)-initial),
                       2*radius**2*path*integrate(radial),12*radius*path*integrate(base)))


def main():
    fixture=[];results=[]
    shell=system(160,1,0,"adm")
    for width in family.FRACTIONS:
        for frac in (.25,.5,.75,1.):
            path=DURATION*8*frac
            for order in (8,14):
                radius,op=weights(shell,width,path,order)
                for freq in (.8,7.,17.):
                    field=spherical_jn(2,freq*radius)
                    src=ep.weight(radius,ep.CENTER*width)*field
                    rad=np.linspace(ep.CENTER*(1-width),ep.CENTER*(1+width),1001)
                    ref=simpson(ep.weight(rad,ep.CENTER*width)*spherical_jn(2,freq*rad),x=rad)
                    direct=op[0]@field
                    flow=op[1]@(freq*spherical_jn(2,freq*radius,True))+op[2]@(field/radius)
                    for case,value,truth in (("cos",direct,-2*np.sin(path*freq/2)**2*ref),
                                             ("sin",flow,2*freq*np.sin(path*freq)*ref)):
                        err=value/truth-1
                        assert abs(err)<2e-5,(case,truth,value)
                        fixture.append(dict(width=width,fraction=frac,order=order,k=freq,case=case,relative=err))
                for flag in (0,1):
                    for seed in (0,1,-1):
                        guard()
                        key=flag,seed
                        if key not in cache:
                            centre=system(160,flag,seed,"adm")
                            state=centre.initial
                            defect,_=measure(centre,state,np.zeros_like(state),True)
                            info=centre.dynamics(0.,state,True)
                            mr=info["mom_r"].copy()
                            trace,shear=state[4:6].real
                            nr=exp(-state[0].real)
                            separated=mul(nr,centre.diff(shear)-2*centre.diff(trace)/3-centre.diff(shear-2*trace/3))
                            assert np.all(trace[0]==trace[0,0]) and np.all(trace[1]==0.)
                            cache[key]=CubicSpline(centre.r,np.stack((defect[1],mr[1],info["mom_theta"][1],
                                                                      separated[1])),axis=-1)
                        defect,radial,polar,diff=cache[key](radius)
                        results.append(dict(width=width,fraction=frac,order=order,seed=seed,flag=flag,
                             launch_H=64/6*(op[0]@defect),
                             launch_M=64/6*(op[1]@radial+op[2]@polar),shift_M=64/6*(op[1]@diff)))
    table("adjoint-analytic.csv",fixture);table("adjoint-members.csv",results)


def compare():
    data=read(HERE/"adjoint-members.csv")
    ref=read(HERE/"budget-adm-n160-p8.csv")
    curves=read(UP/"curved-contrast.csv")
    out=[]
    for row in ref:
        if int(row["stride"])!=1:continue
        seed=int(row["seed"]);width=float(row["width"]);fraction=float(row["fraction"])
        norm=abs(float(next(r["full_newton"] for r in curves if int(r["seed"])==seed and float(r["width"])==width and float(r["fraction"])==fraction)))*1e-6
        for order in (8,14):
            relevant={(int(r["flag"]),int(r["seed"])):r for r in data if float(r["width"])==width and float(r["fraction"])==fraction and int(r["order"])==order}
            def signed(name):
                return (float(relevant[0,seed][name])-float(relevant[0,0][name])-float(relevant[1,seed][name])+float(relevant[1,0][name]))/norm
            initial=signed("launch_H");momentum=signed("launch_M");swap=signed("shift_M")
            total=initial+momentum+swap
            out.append(dict(seed=seed,width=width,fraction=fraction,order=order,initial_H_ppm=initial,
                         initial_M_ppm=momentum,derivative_noise_ppm=swap,flat_prediction_ppm=total,
                         fixed_path_ppm=row["fixed_path"],proper_total_ppm=row["observed_ppm"],
                         flat_minus_fixed_ppm=total-float(row["fixed_path"]),flat_minus_proper_ppm=total-float(row["observed_ppm"])))
    table("launch-only-wave-test.csv",out)


cache={}
if __name__=="__main__":
    if sys.argv[1:]==["source"]:main()
    elif sys.argv[1:]==["compare"]:compare()
    else:raise ValueError("source or compare")
