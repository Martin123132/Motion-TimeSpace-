"""Check every saved quartet, receipt, parent replay, and the signed physical gates."""
from core import *
from math import fsum,isfinite


def verify():
    for name,value in registry.items():
        assert sha(UP/name)==value,name
    observed={}
    for variant in ("original","lifted","green"):
        for method in ("original","adm"):
            tag=method if variant=="original" else variant+"-"+method
            data=read(HERE/f"budget-{tag}-n160-p8.csv")
            assert len(data)==48 and max(abs(float(r["path_error"])) for r in data)<.08
            primary=[r for r in data if r["stride"]=="1"]
            assert len(primary)==16 and max(abs(float(r["transport_error"])) for r in primary)<1.4
            observed[tag]=max(abs(float(r["observed_ppm"])) for r in primary)
            all_fields={}
            for flag in (0,1):
                for seed in (0,1,-1):
                    stem=f"{tag}-n160-p8-off{flag}-s{seed}"
                    with np.load(HERE/(stem+".npz"),allow_pickle=False) as packet:
                        assert packet["change"].shape==(4,20,2,480) and np.isfinite(packet["change"]).all()
                        np.testing.assert_array_equal(packet["r"],(np.arange(480)+.5)/160)
                    rows=read(HERE/(stem+".csv"))
                    assert {(float(r["width"]),float(r["fraction"]),int(r["stride"])) for r in rows}=={
                        (w,t,step) for w in (.15,.30) for t in (.25,.5,.75,1.) for step in (1,2,4)} and len(rows)==24
                    if tag=="original":
                        old=read(UP/f"central-n160-p8-L3-off{flag}-s{seed}.csv")
                        for r in rows:
                            for field in ("ricci","gauss"):
                                truth=next(c for c in old if c["width"]==r["width"] and c["fraction"]==r["fraction"] and c["term"]==field)
                                assert float(r[field])==float(truth["scaled_delta"])
                    all_fields[seed,flag]={ (r["width"],r["fraction"]):r for r in rows if r["stride"]=="1"}
            for row in primary:
                key=row["width"],row["fraction"];seed=int(row["seed"])
                def signed(channel):
                    return fsum(float(all_fields[s,f][key][channel])*v for s,f,v in ((seed,0,1),(0,0,-1),(seed,1,-1),(0,1,1)))
                prior=next(r for r in read(UP/"curved-contrast.csv") if r["seed"]==row["seed"] and (r["width"],r["fraction"])==key)
                denom=abs(float(prior["full_newton"]))*1e-6
                assert abs((signed("gauss")-signed("ricci"))/denom-float(row["observed_ppm"]))<1e-9
    assert 29<observed["original"]<30 and 450<observed["adm"]<460
    assert observed["lifted-adm"]>3000 and observed["lifted-original"]>60
    assert observed["green-original"]<4 and 200<observed["green-adm"]<230
    for seed in (0,1,-1):
        for variant in ("green","lift-x2","lift-x1"):
            checks=read(HERE/f"{variant}-s{seed}-receipt.csv")
            for row in checks:
                base=central.PARENT if variant=="lift-x1" else HERE
                assert sha(base/row["file"])==row["sha256"]
                if "phase_error" in row:assert max(float(row[k]) for k in ("phase_error","mono_error","density_error"))<2e-12
        for flag in (0,1):
            for variant in ("lift-x1","lift-x2","green"):
                with np.load(HERE/f"{variant}-rhs-off{flag}-s{seed}.npz") as pkt:
                    assert pkt["src"].shape==(2,1440 if variant=="lift-x2" else 720,12) and np.isfinite(pkt["src"]).all()
    assert len(read(HERE/"frozen-versus-evolved.csv"))==64
    assert max(abs(float(r["error_ppm"])) for r in read(HERE/"frozen-versus-evolved.csv"))<5.1
    for r in read(HERE/"green-analytic.csv"):assert float(r["max_relative"])<1e-12
    assert max(abs(float(r["error_ppm"])) for r in read(HERE/"exact-dust.csv"))<.32
    assert max(abs(float(r["gauge_ppm"])) for r in read(HERE/"exact-dust.csv"))<.44
    assert max(abs(float(r["relative"])) for r in read(HERE/"adjoint-analytic.csv"))<2e-5
    sources=read(HERE/"source-of-split.csv")
    assert len(sources)==192 and all(abs(float(r["predicted"])-float(r["grid_H"])-float(r["grid_M"]))<1e-9 for r in sources)
    assert len(read(HERE/"curvature-versus-arithmetic.csv"))==96
    gate=read(HERE/"green-detector-gates.csv")
    assert len(gate)==32
    for row in gate:
        assert (row["passed"]=="True")==(max(abs(float(row[key])) for key in
                             ("time_ppm","space_ppm","boundary_ppm","readout_ppm","tt_error"))<=20)
    inventory={}
    for path in HERE.glob("*.csv"):
        data=read(path)
        assert data and all(None not in row and None not in row.values() for row in data),path
        for row in data:
            for entry in row.values():
                try:value=float(entry)
                except ValueError:continue
                assert isfinite(value),path
        inventory[path.name]=len(data)
    assert not list(HERE.glob("*.partial")) and not (HERE/"__pycache__").exists()
    files={p.name:sha(p) for p in sorted(HERE.iterdir()) if p.is_file() and p.name!="seal.json"}
    seal=dict(parent=sha(UP/"seal.json"),files=files,csv_rows=inventory)
    path=HERE/"seal.json"
    if sys.argv[1:]==["seal"] and not path.exists():
        put("seal.json",(json.dumps(seal,sort_keys=True,indent=2)+"\n").encode())
    assert json.loads(path.read_bytes())==seal
    print(len(files),"files;",sum(inventory.values()),"CSV rows;",sum(r["passed"]=="True" for r in gate),"/32 Green detector gates;",sha(path))


if __name__=="__main__":verify()
