"""Finite curved endpoints only for independent accuracy checks on the original-mesh Green preparation."""
from core import *


def run(grid,steps,edge,flag):
    ep.getcontext().prec=40
    dt=8*DURATION/(128*steps)
    rows=[]
    for seed in (0,1,-1):
        guard()
        shell=system(grid,flag,seed,"green-original",edge)
        advance=central.traced.collar.stepper(shell,dt)
        shift=np.zeros_like(shell.initial)
        for tick in range(128*steps):
            if tick%16==0:guard()
            shift=advance(tick*dt,shift)
            if (tick+1)%(32*steps)==0:
                assert np.isfinite(shift).all()
                for width,label,val in central.measure(shell,(tick+1)*dt,shift):
                    if label in ("gauss","ricci"):
                        rows.append(dict(seed=seed,flag=flag,grid=grid,steps=steps,edge=edge,width=width,
                                    channel=label,fraction=(tick+1)/(128*steps),delta=64*val))
    table(f"mesh-n{grid}-p{steps}-L{edge}-off{flag}.csv",rows)
    print("mesh control",grid,steps,edge,flag,flush=True)


def assess():
    configs=((160,4,3),(200,4,3),(160,4,4))
    references=read(HERE/"tides-green-original-n160-p8.csv")
    prior=read(UP/"curved-contrast.csv")
    adj=read(HERE/"budget-green-original-n160-p8.csv")
    group={}
    for grid,steps,edge in configs:
        members=read(HERE/f"mesh-n{grid}-p{steps}-L{edge}-off0.csv")+read(HERE/f"mesh-n{grid}-p{steps}-L{edge}-off1.csv")
        group[grid,steps,edge]={(int(r["flag"]),int(r["seed"]),float(r["width"]),float(r["fraction"]),r["channel"]):float(r["delta"]) for r in members}
    rows=[]
    from math import fsum
    for r in references:
        seed,width,frac,ch=int(r["seed"]),float(r["width"]),float(r["fraction"]),r["channel"]
        def contrast(config):
            data=group[config]
            return fsum(v*data[fl,host,width,frac,ch] for fl,host,v in ((0,seed,1),(0,0,-1),(1,seed,-1),(1,0,1)))
        truth=next(row for row in prior if int(row["seed"])==seed and float(row["width"])==width and float(row["fraction"])==frac and row["channel"]==ch)
        split=float(next(row["observed_ppm"] for row in adj if int(row["seed"])==seed and float(row["width"])==width and float(row["fraction"])==frac and row["stride"]=="1"))
        scale=abs(float(truth["full_newton"]))*1e-6
        control=contrast(configs[0])
        errors=dict(time_ppm=(float(r["curved"])-control)/scale,space_ppm=(contrast(configs[1])-control)/scale,
                    boundary_ppm=(contrast(configs[2])-control)/scale,readout_ppm=split,tt_error=float(r["after_TT_ppm"]))
        rows.append(dict(seed=seed,width=width,fraction=frac,channel=ch,**errors,passed=max(map(abs,errors.values()))<=20))
    table("green-detector-gates.csv",rows)


if __name__=="__main__":
    if sys.argv[1:]==["assess"]:assess()
    else:run(*map(int,sys.argv[1:]))
