"""Independent constraint and stress comparisons; retain the sign of every contrast."""
from math import fsum
from core import *


def facts(scheme,grid,steps):
    out={}
    for flag in (0,1):
        for seed in (0,1,-1):
            for row in read(HERE/f"{scheme}-n{grid}-p{steps}-off{flag}-s{seed}.csv"):
                key=flag,seed,float(row["width"]),float(row["fraction"]),int(row["stride"])
                assert key not in out
                out[key]=row
    assert len(out)==144
    return out


def value(data,seed,position,term):
    return fsum(coeff*float(data[flag,host,*position][term]) for flag,host,coeff in (
                (0,seed,1),(1,seed,-1),(0,0,-1),(1,0,1)))


def score(scheme,grid,steps):
    inputs=facts(scheme,grid,steps)
    reference=read(UP/"curved-contrast.csv")
    tensor={(int(r["seed"]),float(r["width"]),float(r["fraction"])):float(r["tt"]) for r in read(UP/"transverse-test.csv")}
    rows=[];increments=[]
    for row in reference:
        seed,width,frac=int(row["seed"]),float(row["width"]),float(row["fraction"])
        channel=row["channel"]
        norm=abs(float(row["full_newton"]))*1e-6
        pos=width,frac,1
        direct=value(inputs,seed,pos,channel)
        increments.append(dict(seed=seed,width=width,fraction=frac,channel=channel,scheme=scheme,
                           curved=direct,previous=float(row["curved"]),delta_previous_ppm=(direct-float(row["curved"]))/norm,
                           scalar_ppm=(direct-float(row["longitudinal"]))/norm,
                           after_TT_ppm=(direct-float(row["longitudinal"])-tensor[seed,width,frac])/norm))
        if channel!="gauss":continue
        split=fsum((direct,-value(inputs,seed,pos,"ricci")))
        for stride in (1,2,4):
            pos=width,frac,stride
            parts={key:value(inputs,seed,pos,key)/norm for key in ("fixed_path","ruler_path","path_quad_error",
                                              "fixed_time","ruler_time","homogeneous","momentum")}
            change=parts["fixed_path"]+parts["ruler_path"]
            transported=parts["homogeneous"]+parts["momentum"]+parts["ruler_time"]
            observed=split/norm
            rows.append(dict(seed=seed,width=width,fraction=frac,stride=stride,observed_ppm=observed,
                             path_ppm=change,path_error=change-observed,
                             time_error=parts["fixed_time"]+parts["ruler_time"]-observed,
                             transport_ppm=transported,transport_error=transported-observed,**parts))
    assert len(rows)==48 and len(increments)==32
    table(f"budget-{scheme}-n{grid}-p{steps}.csv",rows)
    table(f"tides-{scheme}-n{grid}-p{steps}.csv",increments)
    chosen=[r for r in rows if r["stride"]==1]
    print(scheme,grid,steps,"original difference",max(abs(r["delta_previous_ppm"]) for r in increments))
    for name in ("observed_ppm","path_error","time_error","transport_error","ruler_time","momentum","homogeneous"):
        print(name,max(abs(r[name]) for r in chosen))


def impulse():
    rates={(int(r["grid"]),r["scheme"],int(r["flag"]),int(r["seed"]),float(r["width"]),r["channel"]):r for r in read(HERE/"untuned-launch-impulses.csv")}
    truth={(int(r["seed"]),float(r["width"]),float(r["fraction"]),r["channel"]):r for r in read(UP/"curved-contrast.csv")}
    tensor={(int(r["seed"]),float(r["width"]),float(r["fraction"])):float(r["tt"]) for r in read(UP/"transverse-test.csv")}
    rows=[]
    for scheme in ("original","adm"):
        for row in read(HERE/f"tides-{scheme}-n160-p8.csv"):
            seed,width,frac,ch=int(row["seed"]),float(row["width"]),float(row["fraction"]),row["channel"]
            control=truth[seed,width,frac,ch]
            norm=abs(float(control["full_newton"]))*1e-6
            def shift(grid):
                def field(key):
                    return fsum(coeff*float(rates[grid,scheme,flag,host,width,ch][key]) for flag,host,coeff in (
                        (0,seed,1),(1,seed,-1),(0,0,-1),(1,0,1)))
                return frac*(field("full_clock_curved_impulse")-field("full_clock_newton_impulse"))
            bare=(float(row["curved"])-float(control["full_newton"])-tensor[seed,width,frac])/norm
            offset=shift(160)/norm
            rows.append(dict(scheme=scheme,seed=seed,width=width,fraction=frac,channel=ch,raw_newton_TT_ppm=bare,
                             launch_ppm=offset,after_initial_rate_ppm=bare-offset,launch_grid_spread_ppm=max(
                             abs(shift(grid)/norm-offset) for grid in (120,200))))
    table("forecast-with-launch.csv",rows)


if __name__=="__main__":
    if sys.argv[1:]==["impulse"]:impulse()
    else:score(sys.argv[1],*map(int,sys.argv[2:]))
