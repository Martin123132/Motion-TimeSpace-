"""Integral Hamiltonian inverse with the existing global Robin condition and iterated parent graph."""
from core import *
from local_stage import sphere,start_state
from launch_data import inputs,prepare
from numpy.polynomial.legendre import leggauss,legvander
from scipy.interpolate import BarycentricInterpolator
from unittest.mock import patch


def prefix(terms):
    total=0.;lost=0.;result=[0.]
    for term in terms:
        adjusted=term-lost
        new=total+adjusted
        lost=(new-total)-adjusted
        total=new
        result.append(new)
    return np.array(result)


class Integral:
    def __init__(self,grid,ell,order):
        self.ell=ell;self.radius=grid.points;self.edge=grid.edge
        def quadrature(start,end,power):
            nodes,wts=leggauss(order)
            mid=(start+end)/2;half=(end-start)/2
            point=mid[:,None]+half[:,None]*nodes
            basis=legvander(point*2-1,len(grid.t)-1)@grid.gqinv
            coord=(np.arange(grid.ne)[:,None,None]+point)*grid.h
            return np.einsum("etk,tk,tkj->etj",coord**power,half[:,None]*grid.h*wts,basis)
        zeros=np.zeros_like(grid.t);ones=np.ones_like(grid.t)
        self.before=quadrature(zeros,grid.t,ell+2)
        self.after=quadrature(grid.t,ones,1-ell)
        self.inside=quadrature(np.array([0.]),np.array([1.]),ell+2)[:,0]
        self.outside=quadrature(np.array([0.]),np.array([1.]),1-ell)[:,0]

    def apply(self,src,bc):
        ell=self.ell;r=self.radius
        low=prefix(np.sum(self.inside*src,axis=1))[:-1,None]+np.einsum("etj,ej->et",self.before,src)
        high=prefix(np.sum(self.outside*src,axis=1)[::-1])[-2::-1,None]+np.einsum("etj,ej->et",self.after,src)
        high+=bc*self.edge**(1-ell)
        interior=low/r**(ell+1);exterior=r**ell*high
        return np.stack(((interior+exterior)/(2*ell+1),
                         (-(ell+1)*interior+ell*exterior)/((2*ell+1)*r)))


def attach(grid,order):
    original=grid.evaluate
    grid.lookup={}
    grid.ops=[Integral(grid,ell,order) for ell in (0,2)]
    def evaluate(nodal):
        hit=grid.lookup.get(id(nodal))
        return hit[1] if hit is not None and hit[0] is nodal else original(nodal)
    grid.evaluate=evaluate


class Slice(family.ResolvingSlice):
    def iterate(self,ell,bc):
        integ=self.grid.ops[ell//2]
        value=np.zeros((2,*self.grid.points.shape))
        for count in range(40):
            source=self.hsource(ell,*value)
            following=integ.apply(source,bc)
            err=np.max(abs(following[0]-value[0]))
            scale=max(1e-20,np.max(abs(following[0])))
            value=following
            if err<8e-12*scale:break
        else:raise ArithmeticError(("integral iteration did not settle",ell,err,scale))
        old=self.grid
        coords=(old.r[old.ids[0]]/old.h)
        to_nodes=BarycentricInterpolator(old.t,np.eye(len(old.t)),rng=0)(coords)
        nodal=value[0]@to_nodes.T
        marker=np.r_[nodal[:,:-1].ravel(),nodal[-1,-1]]
        old.lookup[id(marker)]=(marker,value,source,bc)
        return marker,(count+1,err)


def known(grid):
    rows=[]
    for ell in (0,2):
        ratio=grid.points/grid.edge
        polynomial=.7*ratio**ell+ratio**(ell+2)-.31*ratio**(ell+4)
        slope=(.7*ell*ratio**(ell-1)+(ell+2)*ratio**(ell+1)-.31*(ell+4)*ratio**(ell+3))/grid.edge
        src=(-2*(2*ell+3)*ratio**ell+.31*4*(2*ell+5)*ratio**(ell+2))/grid.edge**2
        robin=(.7*ell+(ell+2)-.31*(ell+4)+(ell+1)*(.7+1-.31))/grid.edge
        direct=grid.ops[ell//2].apply(src,robin)
        for degree,truth in enumerate((polynomial,slope)):
            error=np.max(abs(direct[degree]-truth))/np.max(abs(truth))
            assert error<5e-12,(ell,degree,error)
            rows.append(dict(ell=ell,derivative=degree,max_relative=error))
    return rows


def run(seed):
    base=sphere(144,5)
    raw=start_state(base,144,5,seed)
    records=[]
    for flag in (0,1):
        guard()
        bg,press,_=family.pressure(flag)
        grid,samples,supply=inputs(base,raw,144,5,flag,bg,press)
        attach(grid,32)
        table("green-analytic.csv",known(grid))
        with patch.object(family,"ResolvingSlice",Slice):
            packet,obj=prepare(base,raw,grid,samples,supply,bg,press,64,flag)
        name=f"green-q64-off{flag}-s{seed}.npz"
        stream=io.BytesIO()
        np.savez_compressed(stream,**packet)
        put(name,stream.getvalue())
        sources=[]
        for ell,nodal in ((0,obj.f0),(2,obj.f2)):
            _,current,previous,bc=grid.lookup[id(nodal)]
            repeated=obj.hsource(ell,*current)
            sources.append(repeated)
            inverse=grid.ops[ell//2].apply(repeated,bc)
            error=np.max(abs(inverse[0]-current[0]))
            records.append(dict(seed=seed,flag=flag,ell=ell,max_abs_chi=np.max(abs(current[0])),
                          fixed_error=error,derivative_error=np.max(abs(inverse[1]-current[1])),file=name,sha256=sha(HERE/name)))
        buf=io.BytesIO()
        np.savez_compressed(buf,src=np.array(sources),t=grid.t,h=grid.h)
        put(f"green-rhs-off{flag}-s{seed}.npz",buf.getvalue())
        old=central.PARENT/f"launch-L144-h5-q64-off{flag}-s{seed}.npz"
        with np.load(old) as packet0:
            for key in ("mu","H","rho","P","R","n","v","s0","e0","weight","native_stress","native_cross"):
                np.testing.assert_array_equal(packet[key],packet0[key],err_msg=key)
        print("integral",seed,flag,"source, phase and background unchanged",flush=True)
    table(f"green-s{seed}-receipt.csv",records)


if __name__=="__main__":run(int(sys.argv[1]))
