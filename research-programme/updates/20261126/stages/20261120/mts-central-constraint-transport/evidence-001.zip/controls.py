"""Controlled dust, KG variable transformation and analytically propagating constraint violations."""
from core import *
from dust_control import EmptyBank,exact,ltb
from scipy.special import spherical_jn


def install_vacuum_bank(shell):
    shell.incident.bank=EmptyBank(shell.r)
    shell.rho=np.array([1.,0.,0.])


def offshell(scheme):
    shell=system(160,1,0,scheme)
    install_vacuum_bank(shell)
    radius=shell.r
    use=(radius>.8)&(radius<1.9)
    order=7.
    dt=.04/48
    output=[]
    for amplitude in (1e-5,1e-6):
        state=np.zeros_like(shell.initial)
        base=.2*spherical_jn(0,order*radius)
        quadr=.2*spherical_jn(2,order*radius)
        density=amplitude*pair(1+base,quadr)
        state[8]=density
        rate=shell.dynamics(0.,state)
        dtime=1e-5
        minus=shell.dynamics(0.,state-dtime*rate,True)
        plus=shell.dynamics(0.,state+dtime*rate,True)
        dr=(plus["mom_r"]-minus["mom_r"])/(2*dtime)
        dtheta=(plus["mom_theta"][1]-minus["mom_theta"][1])/(2*dtime)
        if scheme=="adm":
            radial=amplitude*.2*order*np.array([spherical_jn(n,order*radius,True) for n in (0,2)])
            angular=density[1]/radius
        else:
            radial=density/radius
            angular=-density[1]/(2*radius)
        radial_err=np.max(abs((radial-dr)[:,use]))/np.max(abs(radial[:,use]))
        angular_err=np.max(abs(angular[use]-dtheta[use]))/np.max(abs(angular[use]))
        assert max(radial_err,angular_err)<2e-5,(scheme,radial_err,angular_err)
        shell.initial=state
        update=central.traced.collar.stepper(shell,dt)
        delta=np.zeros_like(state)
        for idx in range(48):
            delta=update(idx*dt,delta)
            if (idx+1) not in (12,24,48):continue
            duration=(idx+1)*dt
            direct=ham(shell,state+delta)-ham(shell,state)
            if scheme=="adm":
                forecast=-2*amplitude*np.stack((base,quadr))*(np.cos(order*duration)-1)
            else:
                deriv=-2*amplitude*.2*order*np.array([spherical_jn(n,order*radius,True) for n in (0,2)])
                forecast=duration**2/2*(deriv/radius-2*np.array([1.,4.])[:,None]*density/radius**2)
            for harmonic in (0,1):
                peak=np.max(abs(forecast[harmonic,use]))
                error=np.max(abs((direct-forecast)[harmonic,use]))/peak
                output.append(dict(scheme=scheme,amplitude=amplitude,duration=duration,harmonic=2*harmonic,
                                       radial_rate_relative=radial_err,angular_rate_relative=angular_err,history_relative=error))
    return output


def dust(scheme):
    shell=system(160,1,0,scheme)
    install_vacuum_bank(shell)
    shell.rho/=64
    initial=np.zeros_like(shell.initial)
    initial[:17]=ltb(shell.r,0)
    initial[4:8]/=8
    shell.initial=initial
    duration=DURATION*8
    dt=duration/64
    advance=central.traced.collar.stepper(shell,dt)
    change=np.zeros_like(initial);start={};rows=[]
    for idx in range(65):
        if idx in (0,32,64):
            time=dt*idx;state=initial+change
            rates=shell.dynamics(time,state)
            window=ep.Window(shell,state,rates,12)
            for name,tide in zip(("ricci","gauss"),family.tensors(shell,state,rates)):
                mono,quad=window.at(tide.real)
                for wi,width in enumerate(family.FRACTIONS):
                    val=window.widths[wi,0]@mono*64
                    angular=(window.widths[wi,0]@quad+window.widths[wi,1]@mono)*64
                    ref=exact(time/8,width)
                    if not idx:start[name,width]=val,angular,ref
                    else:
                        old,leak,expected=start[name,width]
                        rows.append(dict(scheme=scheme,width=width,channel=name,fraction=idx/64,
                            error_ppm=((val-old)/(ref-expected)-1)*1e6,gauge_ppm=(angular-leak)/(ref-expected)*1e6))
        if idx<64:change=advance(idx*dt,change)
    return rows


def main():
    controls=[];truth=[]
    for scheme in ("original","adm"):
        controls+=offshell(scheme);truth+=dust(scheme)
    table("off-constraint-fixture.csv",controls);table("exact-dust.csv",truth)
    waves=[]
    for seed in (0,1,-1):
        old=system(160,0,seed,"original");new=system(160,0,seed,"adm")
        state=old.initial
        np.testing.assert_array_equal(state,new.initial)
        lhs=old.dynamics(0,state);rhs=new.dynamics(0,state)
        hamilton=ham(old,state)
        for name,error,scale in (
            ("trace",rhs[4]-lhs[4]-hamilton,np.max(abs(lhs[4]))),
            ("KG_physical_momentum",(rhs[15]-lhs[15])+(rhs[4]-lhs[4])/(2*old.mu),np.max(abs(lhs[15])))):
            ratio=np.max(abs(error))/scale;assert ratio<1e-12
            waves.append(dict(seed=seed,quantity=name,max_relative=ratio))
        np.testing.assert_array_equal(lhs[8:15],rhs[8:15])
        np.testing.assert_array_equal(lhs[16:],rhs[16:])
    table("wave-trace-change.csv",waves)
    print("ADM finite fixture",max(row["history_relative"] for row in controls if row["scheme"]=="adm"),
          "exact dust",max(abs(row["error_ppm"]) for row in truth),"gauge",max(abs(row["gauge_ppm"]) for row in truth))


if __name__=="__main__":main()
