"""Forecast both formulations' split from only the newly prepared data before evolving them."""
from representation import constraint_weights,leggauss,CubicSpline
from core import *


def main(variant="lifted"):
    assert variant in ("lifted","green")
    sources={}
    for seed in (0,1,-1):
        for flag in (0,1):
            shell=system(160,flag,seed,variant+"-original")
            state=shell.initial
            defect,_=measure(shell,state,np.zeros_like(state),True)
            info=shell.dynamics(0.,state,True)
            nr=exp(-state[0].real);trace,shear=state[4:6].real
            delta=mul(nr,shell.diff(shear)-2*shell.diff(trace)/3-shell.diff(shear-2*trace/3))
            sources[seed,flag]=np.stack((defect[1],info["mom_r"][1]+delta[1],info["mom_theta"][1]))
    rows=[]
    for seed in (1,-1):
        signed=(sources[seed,0]-sources[0,0])-(sources[seed,1]-sources[0,1])
        spline=CubicSpline(shell.r,signed,axis=-1)
        for width in family.FRACTIONS:
            lo,hi=ep.CENTER*(1-width),ep.CENTER*(1+width)
            for frac in (.25,.5,.75,1.):
                path=DURATION*8*frac
                for scheme in ("adm","original"):
                    low,high=(lo-path,hi+path) if scheme=="adm" else (lo,hi)
                    nodes,gl=leggauss(14)
                    points=np.r_[shell.r,np.arange(30)*.1,lo,hi,lo-path,hi+path,lo+path,hi-path]
                    cuts=np.unique(points[(points>=low)&(points<=high)])
                    span=np.diff(cuts)/2
                    r=(cuts[:-1,None]+span[:,None]*(1+nodes)).ravel()
                    hamilton,mr,polar=constraint_weights(r,width,path,scheme,14)*spline(r)*(span[:,None]*gl).ravel()
                    rows.append(dict(seed=seed,width=width,fraction=frac,scheme=scheme,
                                     predicted_H=64*sum(hamilton)/6,predicted_M=64*sum(mr+polar)/6))
    name="frozen-lift-forecast.csv" if variant=="lifted" else "frozen-green-forecast.csv"
    table(name,rows)
    print("forecast receipt",sha(HERE/name))


if __name__=="__main__":main(*sys.argv[1:])
