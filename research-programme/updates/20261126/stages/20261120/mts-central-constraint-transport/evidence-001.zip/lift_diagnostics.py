"""Measure absolute fixed-point and input-transfer error; a tiny monopole is not a usable relative norm."""
from lift import *


def main():
    base=sphere(144,5)
    raw=start_state(base,144,5,0)
    fine=Mesh(144,1440)
    grid=states.Element(fine,144,12)
    initial=prolong(base.mesh,fine,raw)
    new=SimpleNamespace(mesh=fine,patch=base.patch)
    output=[]
    for flag in (0,1):
        bg,press,_=family.pressure(flag)
        pos=grid.points
        _,_,fourier=base.operators(pos.ravel())
        idx=base.patch.j
        supply=dict(ln=states.jet(np.zeros_like(pos),((bg["w"]*bg["n"][idx])@fourier).reshape(pos.shape)),
                    lp=states.jet(np.zeros_like(pos),((bg["w"]*bg["p"][idx])@fourier).reshape(pos.shape)),P=press,
                    spec2=states.response(bg,pos)("spectrace"))
        shape=(states.shape(bg,pos),states.shape(bg,np.asarray(144.)))
        packet,obj=prepare(new,initial,grid,shape,supply,bg,press,64,flag)
        with np.load(HERE/f"lift-x2-q64-off{flag}-s0.npz") as saved:
            for key,item in packet.items():np.testing.assert_array_equal(item,saved[key])
        for ell,nodal in ((0,obj.f0),(2,obj.f2)):
            rhs=obj.hsource(ell,*grid.evaluate(nodal))
            bc=0. if ell==0 else (shape[1]["chir"]+3*shape[1]["chi"]/144)/64
            projected=grid.solve(ell,rhs,"matched",bc)
            err=np.max(abs(projected-nodal));scale=np.max(abs(nodal))
            output.append(dict(flag=flag,ell=ell,max_abs_chi=scale,change_abs=err,
                               relative=err/max(scale,1e-280)))
    table("lift-zero-host-scale.csv",output)


if __name__=="__main__":main()
