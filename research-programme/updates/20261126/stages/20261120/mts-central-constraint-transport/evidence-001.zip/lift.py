"""Globally re-embed the same prepared fields on half-size elliptic elements, not a new formation."""
from types import SimpleNamespace
from core import *
from detector import Mesh,start_state
from local_stage import sphere,states
from launch_data import prepare
from scipy.interpolate import BarycentricInterpolator


def prolong(old,fine,raw):
    radius=fine.r[1:]
    index=np.minimum(np.floor(radius/old.h).astype(int),old.segments-1)
    local=radius/old.h-index
    basis=BarycentricInterpolator(old.loc[0]/old.h,np.eye(old.order+1),rng=0)(local)
    output=[]
    for item in raw:
        nodal=old.grid(item)[...,old.elem[index]]
        anchor=nodal[...,:1]
        output.append(anchor[...,0]+np.einsum("...ij,ij->...i",nodal-anchor,basis))
    return tuple(output)


def proof(old,new,raw,refined):
    nodes=np.array([.137,.497,.829])
    r=((np.arange(old.segments)[:,None]+nodes)*old.h).ravel()
    def samples(mesh,field):
        cell=np.floor(r/mesh.h).astype(int)
        nodal=mesh.grid(field)[...,mesh.elem[cell]]
        basis=BarycentricInterpolator(mesh.loc[0]/mesh.h,np.eye(mesh.order+1),rng=0)(r/mesh.h-cell)
        return nodal[...,0]+np.einsum("...ij,ij->...i",nodal-nodal[...,:1],basis)
    errors=[]
    for first,last in zip(raw,refined):
        lhs=samples(old,first);rhs=samples(new,last)
        errors.append(np.max(abs(lhs-rhs))/max(1e-290,np.max(abs(lhs))))
    assert max(errors)<2e-12,errors
    return errors


def run(seed,refine=2):
    from local_stage import sha as parent_sha
    old=sphere(144,5)
    raw=start_state(old,144,5,seed)
    fine=Mesh(144,720*refine)
    grid=states.Element(fine,144,12)
    new=SimpleNamespace(mesh=fine,patch=old.patch)
    initial=prolong(old.mesh,fine,raw) if refine>1 else raw
    errs=proof(old.mesh,fine,raw,initial)
    records=[]
    for flag in (0,1):
        guard()
        bg,press,_=family.pressure(flag)
        profile=states.Spatial(old,raw,flag)
        _,_,lap=profile.at(grid.points)
        _,_,fourier=old.operators(grid.points.ravel())
        idx=old.patch.j
        density=lap[2]+((bg["w"]*bg["n"][idx])@fourier).reshape(grid.points.shape)
        phase=lap[3]+((bg["w"]*bg["p"][idx])@fourier).reshape(grid.points.shape)
        shape=(states.shape(bg,grid.points),states.shape(bg,np.asarray(float(144))))
        supply=dict(ln=states.jet(lap[0],density),lp=states.jet(lap[1],phase),P=press,spec2=states.response(bg,grid.points)("spectrace"))
        packet,obj=prepare(new,initial,grid,shape,supply,bg,press,64,flag)
        original=central.PARENT/f"launch-L144-h5-q64-off{flag}-s{seed}.npz"
        assert parent_sha(original)==central.pins[original.name]
        with np.load(original) as previous:
            for name in ("mu","H","P","R","weight","rho"):
                np.testing.assert_array_equal(previous[name],packet[name])
            if refine==1:
                for name,field in packet.items():np.testing.assert_array_equal(previous[name],field,err_msg=name)
        name=f"lift-x{refine}-q64-off{flag}-s{seed}.npz"
        if refine>1:
            stream=io.BytesIO()
            np.savez_compressed(stream,**packet)
            put(name,stream.getvalue())
        chi,gradient=grid.evaluate(obj.f2)
        value=0.;sources=[];quality=[]
        for ell,nodal in ((0,obj.f0),(2,obj.f2)):
            rhs=obj.hsource(ell,*grid.evaluate(nodal))
            sources.append(rhs)
            bc=0. if ell==0 else (shape[1]["chir"]+3*shape[1]["chi"]/144)/64
            projected=grid.solve(ell,rhs,"matched",bc)
            value=max(value,np.max(abs(projected-nodal))/max(1e-280,np.max(abs(nodal))))
            quality.append(dict(ell=ell,change_abs=np.max(abs(projected-nodal)),scale=np.max(abs(nodal))))
        buf=io.BytesIO()
        np.savez_compressed(buf,src=np.array(sources),t=grid.t,h=grid.h)
        put(f"lift-x{refine}-rhs-off{flag}-s{seed}.npz",buf.getvalue())
        table(f"linear-check-x{refine}-off{flag}-s{seed}.csv",quality)
        records.append(dict(seed=seed,flag=flag,refinement=refine,mono_error=errs[0],density_error=errs[1],phase_error=errs[2],
                            fixed_point_relative=value,file=name if refine>1 else original.name,
                            sha256=sha(HERE/name) if refine>1 else sha(original)))
        print("re-embedded",refine,seed,flag,"fixed point",value,flush=True)
    table(f"lift-x{refine}-s{seed}-receipt.csv",records)


if __name__=="__main__":run(*map(int,sys.argv[1:]))
