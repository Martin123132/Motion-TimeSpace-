"""Publish paired uncertainty and forecast ledgers, including failures."""
from core import *
from math import fsum


def run():
    parent={(int(r["seed"]),float(r["width"]),float(r["fraction"]),r["channel"]):r for r in read(UP/"curved-contrast.csv")}
    tt={(int(r["seed"]),float(r["width"]),float(r["fraction"])):float(r["tt"]) for r in read(UP/"transverse-test.csv")}
    rows=[];frozen=[]
    for variant in ("original","lifted","green"):
        groups={};modes={}
        for method in ("original","adm"):
            name=method if variant=="original" else variant+"-"+method
            groups[method]={(int(r["seed"]),float(r["width"]),float(r["fraction"]),r["channel"]):r for r in read(HERE/f"tides-{name}-n160-p8.csv")}
            modes[method]={(int(r["seed"]),float(r["width"]),float(r["fraction"])):float(r["observed_ppm"]) for r in read(HERE/f"budget-{name}-n160-p8.csv") if r["stride"]=="1"}
        if variant!="original":
            src="frozen-lift-forecast.csv" if variant=="lifted" else "frozen-green-forecast.csv"
            expected="eec46f4f93526f487bcd10812c79b9a04e94d9902b0cfdd291cd3067282a0e00" if variant=="lifted" else "7813cacfa0364856bf79ceac44aefac00c6019bf8cded218d856e2bdd65dffc2"
            assert sha(HERE/src)==expected
            for r in read(HERE/src):
                key=(int(r["seed"]),float(r["width"]),float(r["fraction"]))
                norm=abs(float(parent[*key,"gauss"]["full_newton"]))*1e-6
                prediction=fsum((float(r["predicted_H"]),float(r["predicted_M"])))/norm
                observed=modes[r["scheme"]][key]
                frozen.append(dict(variant=variant,method=r["scheme"],seed=key[0],width=key[1],fraction=key[2],
                                 predicted=prediction,observed=observed,error_ppm=prediction-observed))
        for key,ref in parent.items():
            seed,width,fraction,ch=key
            truth=float(ref["full_newton"]);norm=abs(truth)*1e-6
            formed=(float(groups["adm"][key]["curved"])-float(groups["original"][key]["curved"]))/norm
            for method in ("original","adm"):
                row=groups[method][key]
                physical=float(row["curved"])
                old_reference=float(row["after_TT_ppm"])
                direct=(physical-truth-tt[seed,width,fraction])/norm
                split=modes[method][seed,width,fraction]
                rows.append(dict(variant=variant,method=method,seed=seed,width=width,fraction=fraction,channel=ch,
                         difference_two_formulations_ppm=formed,gauss_minus_ricci_ppm=split,curved=physical,newton=truth,
                         error_hybrid_TT_ppm=old_reference,error_newton_TT_ppm=direct,
                         TT_and_split_pass=max(abs(split),abs(old_reference))<=20,
                         also_formulation_agrees=max(abs(split),abs(old_reference),abs(formed))<=20))
    table("formulations-compared.csv",rows);table("frozen-versus-evolved.csv",frozen)
    for variant in ("original","lifted","green"):
        for method in ("original","adm"):
            select=[r for r in rows if r["variant"]==variant and r["method"]==method]
            print(variant,method,"gated",sum(r["TT_and_split_pass"] for r in select),
                  "also same-form answer",sum(r["also_formulation_agrees"] for r in select),
                  *(round(max(abs(row[k]) for row in select),4) for k in ("gauss_minus_ricci_ppm","error_hybrid_TT_ppm","difference_two_formulations_ppm")))
    for var in ("lifted","green"):
        for mode in ("original","adm"):
            print("prospective",var,mode,max(abs(row["error_ppm"]) for row in frozen if row["variant"]==var and row["method"]==mode))


if __name__=="__main__":run()
