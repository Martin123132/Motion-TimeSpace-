"""Localize the launch constraint to weak bulk, interelement jumps and resampling."""
from core import *
from launch_constraints import wave_weights
from numpy.polynomial.legendre import legvander,legder,leggauss
from cloud_owner import inv
from scipy.interpolate import CubicSpline


def constraint_weights(radius,width,path,scheme,order):
    if scheme=="adm":return wave_weights(radius,width,path,order)
    half=ep.CENTER*width
    weight,first,second=(ep.weight(radius,half,deg) for deg in (0,1,2))
    one=-first/radius+5*weight/radius**2
    deriv=-second/radius+6*first/radius**2-10*weight/radius**3
    twice=-deriv/radius+5*one/radius**2
    electric=path**2*one/2+path**4*twice/24
    flux=path*weight+path**3*one/6
    slope=path*first+path**3*deriv/6
    return np.stack((electric,2*(slope-2*flux/radius),12*flux/radius))


class Native:
    def __init__(self,flag,seed,variant="original"):
        if variant=="original":
            stem=central.PARENT/f"launch-L144-h5-q64-off{flag}-s{seed}.npz"
            assert sha(stem)==central.pins[stem.name]
        else:
            root={"lifted":"lift-x2","green":"green"}[variant]
            receipt=next(r for r in read(HERE/f"{root}-s{seed}-receipt.csv") if int(r["flag"])==flag)
            stem=HERE/receipt["file"]
            assert sha(stem)==receipt["sha256"]
        with np.load(stem) as packet:
            self.flag=flag
            self.h=float(packet["h"])
            basis=np.linalg.inv(legvander(2*packet["t"]-1,11))
            self.coeff={}
            for key in ("n","v","chi","b","drift","delta","e0"):
                raw=packet[key][...,:round(3.2/self.h),:].astype(np.longdouble)
                coeff=(raw-raw[...,:1])@basis.T
                coeff[...,0]+=raw[...,0]
                self.coeff[key]=[coeff]
                for degree in (1,2):
                    self.coeff[key].append(legder(coeff,degree,axis=-1)*(2/self.h)**degree)
            self.rho=packet["rho"].astype(np.longdouble);self.mu=float(packet["mu"])
            self.hub=float(packet["H"]);self.other=float(packet["R"]-packet["rho"].sum())

    def metric(self,radius,cell=None):
        rad=np.asarray(radius,dtype=np.longdouble)
        if cell is None:cell=np.floor(rad/self.h).astype(int)
        basis=legvander(2*(rad/self.h-cell)-1,11)
        def at(key,degree=0):
            coeff=self.coeff[key][degree]
            return np.einsum("...ij,ij->...i",coeff[...,cell,:],basis[:,:coeff.shape[-1]])
        psi=at("chi")+pair(np.ones_like(rad))
        return rad,at,psi

    def fields(self,radius):
        rad,at,psi=self.metric(radius)
        grad=at("chi",1)
        lap=at("chi",2)+2*grad/rad
        lap[1]-=6*psi[1]/rad**2
        metric=inv(psi)
        logpsi=pair(np.log(psi[0]),psi[1]/psi[0])
        curv=-8*mul(exp(-5*logpsi),lap)
        shear=mul(exp(-6*logpsi),at("b"))
        volume=exp(-6*logpsi);normal=exp(-2*logpsi)
        en=pair(np.full_like(rad,self.other),at("e0"))
        unit=pair(np.ones_like(rad))
        number=at("n");vel=at("v",1)
        for idx in range(3 if self.flag else 2):
            sq=square(mul(normal,vel[idx]));root=np.sqrt(1+sq[0])
            en+=self.rho[idx]*mul(mul(number[idx],volume),pair(root,sq[1]/(2*root)))
        if not self.flag:
            denom=at("delta")+unit
            density=mul(mul(number[2],inv(denom)),volume)
            gradlog=(mul(at("n",1)[2],inv(number[2]))-mul(at("delta",1),inv(denom)))/2-3*mul(grad,metric)
            energy=unit+square(at("drift"))+square(denom)+mul(square(normal),square(gradlog)/self.mu**2+square(vel[2]))
            en+=self.rho[-1]*mul(density,energy)/2
        noncurve=-1.5*square(shear)-2*en
        return np.stack((curv[1],noncurve[1]))

    def jumps(self,radius,cell):
        _,left,first=self.metric(radius,cell-1)
        _,right,last=self.metric(radius,cell)
        psi=(first+last)/2
        logpsi=pair(np.log(psi[0]),psi[1]/psi[0])
        jump=right("chi",1)-left("chi",1)
        return -8*mul(exp(-5*logpsi),jump)[1],np.maximum(abs(right("chi")-left("chi"))[0],abs(right("chi")-left("chi"))[1])


def main():
    materials={};splines={}
    for seed in (0,1,-1):
        for flag in (0,1):
            guard()
            key=seed,flag
            materials[key]=Native(flag,seed)
            shell=system(160,flag,seed,"original")
            state=shell.initial
            constraint=ham(shell,state)[1]
            curvature=spatial(shell,state[:4].real)[1]
            info=shell.dynamics(0.,state,True)
            separated=mul(exp(-state[0].real),shell.diff(state[5].real)-2*shell.diff(state[4].real)/3-shell.diff(state[5].real-2*state[4].real/3))
            splines[key]=CubicSpline(shell.r,np.stack((curvature,constraint-curvature,
                            info["mom_r"][1]+separated[1],info["mom_theta"][1])),axis=-1)
    rows=[];control=[]
    for width in family.FRACTIONS:
        half=ep.CENTER*width;lo,hi=ep.CENTER-half,ep.CENTER+half
        for frac in (.25,.5,.75,1.):
            path=DURATION*8*frac
            faces=np.arange(1,15)*.2
            for scheme in ("original","adm"):
                lower,upper=(lo-path,hi+path) if scheme=="adm" else (lo,hi)
                points=np.r_[lower,upper,lo,hi,lo+path,hi-path,faces,shell.r]
                cuts=np.unique(points[(points>=lower)&(points<=upper)])
                face_index=np.flatnonzero((faces>lower)&(faces<upper))
                face=faces[face_index]
                for order in (8,14):
                    nodes,weights=leggauss(order)
                    span=np.diff(cuts)/2
                    radius=(cuts[:-1,None]+span[:,None]*(1+nodes)).ravel()
                    op=constraint_weights(radius,width,path,scheme,order)*(span[:,None]*weights).ravel()
                    trace=constraint_weights(face,width,path,scheme,order)[0]
                    if scheme=="original":
                        for power in (2,4,6):
                            held=ep.weight(radius,half)*(span[:,None]*weights).ravel()*radius**power
                            factor=(power+4)*path**2/(2*radius**2)+(power+4)*(power+2)*path**4/(24*radius**4)
                            rhs=held@factor
                            err=abs((op[0]@radius**power)/rhs-1)
                            assert err<2e-7
                            control.append(dict(width=width,fraction=frac,order=order,power=power,relative=err))
                    for key,material in materials.items():
                        guard()
                        native,source=material.fields(radius)
                        jump,value_jump=material.jumps(face,face_index+1)
                        stagger,rest,flow,polar=splines[key](radius)
                        parts={"curvature_stagger":op[0]@stagger,"regular_source_stagger":op[0]@rest,
                               "curvature_bulk":op[0]@native,"curvature_faces":trace@jump,
                               "regular_source_native":op[0]@source,"transport_M":op[1]@flow+op[2]@polar}
                        rows.append(dict(seed=key[0],flag=key[1],scheme=scheme,width=width,fraction=frac,order=order,
                                       max_chi_value_jump=max(value_jump),**{k:float(64*v/6) for k,v in parts.items()}))
    table("native-weak-members.csv",rows);table("adjoint-polynomial.csv",control)


def compare():
    data=read(HERE/"native-weak-members.csv")
    rows=[]
    for scheme in ("original","adm"):
        for record in read(HERE/f"budget-{scheme}-n160-p8.csv"):
            if record["stride"]!="1":continue
            seed,width,frac=int(record["seed"]),float(record["width"]),float(record["fraction"])
            truth=next(r for r in read(UP/"curved-contrast.csv") if int(r["seed"])==seed and float(r["width"])==width and float(r["fraction"])==frac)
            norm=abs(float(truth["full_newton"]))*1e-6
            for order in (8,14):
                group={(int(r["seed"]),int(r["flag"])):r for r in data if r["scheme"]==scheme and float(r["width"])==width
                       and float(r["fraction"])==frac and int(r["order"])==order}
                def signed(term):
                    from math import fsum
                    return fsum(v*float(group[key][term]) for key,v in (((seed,0),1),((seed,1),-1),((0,0),-1),((0,1),1)))/norm
                keys=("curvature_stagger","regular_source_stagger","curvature_bulk","curvature_faces","regular_source_native","transport_M")
                parts={k:signed(k) for k in keys}
                native=sum(parts[k] for k in keys[2:5])
                measured=float(record["observed_ppm"])
                expected=sum(parts[k] for k in ("curvature_stagger","regular_source_stagger","transport_M"))
                rows.append(dict(scheme=scheme,seed=seed,width=width,fraction=frac,order=order,observed_ppm=measured,
                                  stagger_launch_prediction=expected,forecast_error=expected-measured,native_H_launch=native,
                                  curvature_resampling=parts["curvature_stagger"]-parts["curvature_bulk"]-parts["curvature_faces"],
                                  source_resampling=parts["regular_source_stagger"]-parts["regular_source_native"],**parts))
    table("where-the-defect-enters.csv",rows)


if __name__=="__main__":main();compare()
