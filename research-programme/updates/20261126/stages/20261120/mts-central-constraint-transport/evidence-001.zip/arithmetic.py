"""Separate arithmetic on a fixed mesh from the representation of the launch curvature."""
from representation import *
from math import fsum


def main():
    ep.getcontext().prec=40
    reference={(int(r["seed"]),float(r["width"]),float(r["fraction"])):abs(float(r["full_newton"]))*1e-6 for r in read(UP/"curved-contrast.csv")}
    rows=[]
    for variant in ("original","lifted","green"):
        cache={}
        for seed in (0,1,-1):
            for flag in (0,1):
                shell=system(160,flag,seed,"original" if variant=="original" else variant+"-original")
                state=shell.initial
                hbase,_=measure(shell,state,np.zeros_like(state),True)
                direct,gauss=ep.fixed_tide(shell,state,None)
                high=((gauss[1]-direct[1])*6).astype(float)
                model=Native(flag,seed,variant)
                prefix={"original":"lift-x1","lifted":"lift-x2","green":"green"}[variant]
                with np.load(HERE/f"{prefix}-rhs-off{flag}-s{seed}.npz") as source:
                    vals=source["src"][...,:round(3.2/model.h),:]
                    basis=np.linalg.inv(legvander(2*source["t"]-1,11))
                coeff=(vals-vals[...,:1])@basis.T
                coeff[...,0]+=vals[...,0]
                model.coeff["rhs"]=[coeff]
                _,at,psi=model.metric(shell.r)
                curv=8*mul(exp(-5*pair(np.log(psi[0]),psi[1]/psi[0])),at("rhs"))[1]
                others=ham(shell,state)[1]-spatial(shell,state[:4].real)[1]
                _,accurate_others=model.fields(shell.r)
                info=shell.dynamics(0.,state,True)
                trace,shear=state[4:6].real;nr=exp(-state[0].real)
                sep=mul(nr,shell.diff(shear)-2*shell.diff(trace)/3-shell.diff(shear-2*trace/3))
                cache[seed,flag]=np.stack((hbase[1],high,curv+others,curv+accurate_others,info["mom_r"][1]+sep[1],info["mom_theta"][1]))
        for seed in (1,-1):
            difference=(cache[seed,0]-cache[0,0])-(cache[seed,1]-cache[0,1])
            spline=CubicSpline(shell.r,difference,axis=-1)
            for width in family.FRACTIONS:
                lo,hi=ep.CENTER*(1-width),ep.CENTER*(1+width)
                for frac in (.25,.5,.75,1.):
                    path=frac*8*DURATION
                    for scheme in ("original","adm"):
                        low,high=(lo-path,hi+path) if scheme=="adm" else (lo,hi)
                        bound=np.r_[shell.r,np.arange(30)*model.h,lo,hi,lo-path,hi+path,lo+path,hi-path]
                        cuts=np.unique(bound[(bound>=low)&(bound<=high)])
                        sizes=np.diff(cuts)/2;nodes,weights=leggauss(14)
                        radius=(cuts[:-1,None]+sizes[:,None]*(1+nodes)).ravel()
                        op=constraint_weights(radius,width,path,scheme,14)*(sizes[:,None]*weights).ravel()
                        fields=spline(radius)
                        factor=(64/6)/reference[seed,width,frac]
                        flow=factor*(op[1]@fields[4]+op[2]@fields[5])
                        vals=[flow+factor*fsum(op[0]*field) for field in fields[:4]]
                        rows.append(dict(seed=seed,width=width,fraction=frac,variant=variant,scheme=scheme,
                                    float_stencil=vals[0],decimal_stencil=vals[1],arithmetic_delta=vals[1]-vals[0],
                                    analytic_R_only=vals[2],analytic_R_and_matter=vals[3],flow=flow))
    table("curvature-versus-arithmetic.csv",rows)


if __name__=="__main__":main()
