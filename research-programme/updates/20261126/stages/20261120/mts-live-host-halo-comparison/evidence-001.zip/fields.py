from host_io import *
from native_build import CACHE
from functools import lru_cache
import ctypes as ct
import numpy as np
from scipy.special import roots_legendre
from lmc_field import UNIT,history
pointer=np.ctypeslib.ndpointer(np.float64,flags='C_CONTIGUOUS')
runtime=os.add_dll_directory(str(CACHE/'Library'/'bin'))
lib=ct.CDLL(str(CACHE/'host.dll'));lib.fieldError.restype=ct.c_char_p
lib.loadField.argtypes=[ct.c_char_p]
lib.evaluateField.argtypes=[ct.c_int,ct.c_int,pointer,pointer]
@lru_cache(maxsize=None)
def field(path):
    handle=lib.loadField(os.fsencode(path))
    if handle<0:raise RuntimeError(lib.fieldError().decode(errors='replace'))
    def evaluate(points):
        points=np.ascontiguousarray(np.atleast_2d(points),dtype=float);out=np.empty((len(points),4))
        if lib.evaluateField(handle,len(points),points,out):raise RuntimeError(lib.fieldError().decode(errors='replace'))
        return out
    return evaluate
PROBES=np.array([[-r,0.,z] for r in (6.,8.3) for z in (1.5,-1.5)])
OUTER=17.58
PLANES=np.stack([np.column_stack((PROBES[:,0],np.zeros(4),PROBES[:,2])),
                 np.column_stack((-PROBES[:,2],np.zeros(4),PROBES[:,0]))],axis=1)/np.linalg.norm(PROBES,axis=1)[:,None,None]
def project(v):return np.einsum('pij,pj->pi',PLANES,np.broadcast_to(v,(4,3)))*UNIT
def paths(model):
    rows=[r for r in read(HERE/'host-inputs.csv') if r['model']==model]
    return {(r['variant'],r['epoch']):HERE/r['path'] for r in rows}
def materials(model):
    data=(OLD/'source'/model/'potential.ini').read_text().split('[Potential accel]')[0]
    put('source/'+model+'/fixed-ordinary.ini',data.encode())
    return field(HERE/'source'/model/'fixed-ordinary.ini')
def satellite(model):
    mapping=paths(model);last=mapping['multipole','final'].name.replace('mwhalo','lmc')
    return field(OLD/'source'/model/'pot'/last),history(model)[-1][-1,1:4]
def aperture(evaluate,radius,order=10):
    mu,weights=roots_legendre(order);az=2*np.pi*(np.arange(2*order)+.25)/(2*order)
    sine=np.sqrt(1-mu**2)
    xyz=np.stack(np.broadcast_arrays(sine[:,None]*np.cos(az),sine[:,None]*np.sin(az),mu[:,None]),axis=2).reshape(-1,3)
    val=evaluate(radius*xyz)[:,0].reshape(order,-1)
    val-=val.mean()
    return -1.5/radius*np.einsum('ij,ijk,i->k',val,xyz.reshape(order,-1,3),weights)/(2*order)
