from common_wave import *
from compare_host import LABELS
from tidal_contrasts import weights
import zlib

def inventory():
    return {p.relative_to(HERE).as_posix():digest(p) for p in sorted(HERE.rglob('*')) if p.is_file() and p.name!='seal.json'}
def source_receipts():
    prior=json.loads((PRE/'seal.json').read_text());prior_files=prior['files']
    assert all(digest(PRE/k)==v for k,v in prior_files.items())
    packets=read(HERE/'host-inputs.csv');assert len(packets)==len(set(r['path'] for r in packets))==24
    assert all(digest(HERE/r['path'])==r['sha256'] and zlib.crc32((HERE/r['path']).read_bytes())==int(r['crc32'],16) for r in packets)
    parent=json.loads((AXIS/'seal.json').read_text())['files'];external={}
    for model in MODELS:
        n=f'shell-{model}-r320-l40-q36-t16.npz';assert digest(AXIS/n)==parent[n];external[n]=parent[n]
        assert (HERE/f'source/{model}/fixed-ordinary.ini').read_bytes()==(HERE/f'source/{MODELS[0]}/fixed-ordinary.ini').read_bytes()
    for folder in (PRE,AXIS,SLAB,OLD,GAS):external[folder.name+'/seal.json']=digest(folder/'seal.json')
    build=read(HERE/'native-build.csv')[0];cache=Path(build['cache']);assert digest(cache/'host.dll')==build['library_sha'] and digest(cache/'source.zip')==build['zip_sha'] and digest(cache/'gsl.tar.bz2')==build['gsl_sha']
    return len(prior_files),external
def verify():
    guard();prior,external=source_receipts();rows=[];dens=[];keys=('r6','p6','r83','p83')
    def data(mesh,occ,keep):
        return {(r['model'],r['initial'],r['substeps']):r for r in read(HERE/f'response-{mesh}-{occ}-{keep}.csv')}
    sky=read(HERE/'common-forces.csv')
    assert len(sky)==3*6*2*3*8
    for idx in range(0,len(sky),8):
        group=sky[idx:idx+8]
        assert all(abs(float(r['total'])-sum(float(r[k]) for k in ('ground','ordinary','direct_in_frame','induced')))<2e-14 and (r['inside']=='True')==(float(r['low'])<=float(r['total'])<=float(r['high'])) for r in group)
    for occ in range(3):
        central=data(1,occ,64);b=pre.background(1)
        with np.load(HERE/f'grounds/mesh1-occ{occ}.npz') as pk:g=pk['g']
        ground_norm=np.sum(g*g);gsky=(g/b.sqrt[:,None])@b.harm.T
        for model in MODELS:
            with np.load(HERE/f'responses/1-{occ}-64-{model}.npz') as pk:
                x=pk['real_displacement'];xs=(x/b.sqrt[:,None])@b.harm.T;rho=pk['density_multipoles'];unit=float(pk['mass_unit_msun'])
                assert np.allclose(rho,(2*gsky*xs@(b.aw[:,None]*b.harm))/b.rad[:,None]**2,atol=2e-13,rtol=1e-12)
                mass=(rho[:,0]*b.rad**2*b.mesh.weight)*unit;net=mass.sum();enclosed=[(rho[:,0]*b.rad**2*wt).sum()*unit for wt in b.mesh.inner]
                assert abs(net)/(unit*ground_norm)<1e-12 and abs(enclosed[0]/(unit*ground_norm)-float(central[model,'zero','16']['mass_fraction_inside6']))<1e-13
                dens.append(dict(occupation=occ,model=model,inside6_msun=enclosed[0],inside83_msun=enclosed[1],outside6_msun=net-enclosed[0],net_msun=net,number_error_fraction=net/(ground_norm*unit)))
        for mesh,keep,stride,tag in [(0,40,16,'coarse_angular_and_radial_basis'),(1,64,8,'half_source_substeps'),(1,88,16,'larger_trial_basis'),(3,64,16,'larger_radial_box')]:
            candidate=data(mesh,occ,keep);old_gr=read(HERE/'grounds-1.csv')[occ];new_gr=read(HERE/f'grounds-{mesh}.csv')[occ]
            for model in MODELS:
                for initial,branch in [('zero','evolved_wave'),('adiabatic','initial_equilibrium')]:
                    for k,base,other in zip(keys,[float(central[model,initial,'16'][k]) for k in keys],[float(candidate[model,initial,str(stride)][k]) for k in keys]):
                        rad,component=(6. if k.endswith('6') else 8.3),('radial' if k.startswith('r') else 'polar')
                        trials=[r for r in sky if (r['occupation'],r['model'],r['branch'],float(r['R']),r['component'])==(str(occ),model,branch,rad,component)]
                        assert len(trials)==4
                        delta=other-base+float(new_gr[k])-float(old_gr[k]);switch=0;gap=np.inf
                        for r in trials:
                            val=float(r['total']);lo=float(r['low']);hi=float(r['high']);gap=min(gap,abs(val-lo),abs(val-hi))
                            test=val+delta*(-1 if float(r['z'])<0 and component=='polar' else 1)
                            switch+=((lo<=val<=hi)!=(lo<=test<=hi))
                        rows.append(dict(occupation=occ,history=model,initial=initial,component=k,test=tag,delta_induced=other-base,relative=abs(other-base)/max(abs(base),1e-30),delta_total_north=delta,closest_original_edge=gap,changed_band_decisions=switch))
    table('density-redistribution',dens);table('independent-refinements',rows)
    ordinary=read(HERE/'ordinary-slab.csv');assert len(ordinary)==2
    native=read(HERE/'vertical-compression.csv')
    ctr=read(HERE/'common-compression.csv')
    def value(records,**pick):
        return [r for r in records if all(r[k]==v for k,v in pick.items())]
    for radius in ('6.0','8.3'):
        for model in MODELS:
            for form in ('multipole','basis'):
                pick=dict(R=radius,model=model,foreground='simulation',frame='material_full',representation=form)
                init,=value(native,branch='frozen_host',**pick);final,=value(native,branch='live_host',**pick)
                assert float(init['low'])<float(init['K'])<float(final['K'])<float(final['high'])
        for r in value(ctr,R=radius,occupation='2',branch='evolved_wave'):assert r['inside']=='True'
    status=dict(prior_files=prior,inputs=external,source_bytes=sum(int(r['local_bytes']) for r in read(HERE/'host-inputs.csv')),primary_sky_rows=len(sky),primary_density_states=len(dens),
                refinement_changes=sum(r['changed_band_decisions'] for r in rows),max_abs_density_net_fraction=max(abs(r['number_error_fraction']) for r in dens),
                subspace='linear even m=0, fixed occupation about each prepared state',original_relative_tolerance=2e-5)
    path=HERE/'seal.json';encoded=json.dumps({**status,'files':inventory()},indent=2,sort_keys=True).encode()+b'\n'
    if '--seal' in sys.argv:put('seal.json',encoded)
    elif path.exists():assert path.read_bytes()==encoded
    print('verified',len(inventory()),'files;',status['refinement_changes'],'individual decision changes;',status['max_abs_density_net_fraction'],'net fraction')
if __name__=='__main__':verify()
