from pathlib import Path
import os,sys,io,csv,json,hashlib
for setting in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','BLIS_NUM_THREADS'):
    os.environ[setting]='1'
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
PRE=ROOT/'mts-fixed-number-annular-preparation-20261119'
SLAB=ROOT/'mts-lmc-slab-poisson-20261119'
GAS=ROOT/'mts-lmc-gas-history-correction-20261119'
OLD=ROOT/'mts-lmc-tidal-history-20261119'
sys.path.insert(0,str(OLD))
from lmc_io import MODELS,read
def digest(path):
    with path.open('rb') as fd:return hashlib.file_digest(fd,'sha256').hexdigest()
def guard():
    assert digest(PRE/'seal.json')=='34ffcd4296e5a57cc65d00ef4f4b7abead710c2ac4068a230087f75e0e04903b'
    assert not any((folder/'STOP-REQUESTED').exists() for folder in (ROOT,HERE,PRE,GAS,OLD))
def put(name,raw):
    guard();dest=HERE/name;dest.parent.mkdir(exist_ok=True,parents=True)
    if dest.exists():assert dest.read_bytes()==raw,name
    else:
        with dest.open('xb') as fd:fd.write(raw)
def table(name,rows):
    buf=io.StringIO(newline='');out=csv.DictWriter(buf,rows[0],lineterminator='\n')
    out.writeheader();out.writerows(rows);put(name+'.csv',buf.getvalue().encode())
