from response_scores import *
from slab_fields import nfw
from field_controls import outer
def run():
    guard();halo=nfw(0);source=materials(MODELS[0])
    acceleration=224.03**2/OUTER;scale=(acceleration-outer(source))/(-halo(OUTER,0.)[0])
    assert scale>0 and abs(np.sqrt((outer(source)-scale*halo(OUTER,0.)[0])*OUTER)-224.03)<1e-10
    reference=read(HERE/'common-forces.csv');rows=[];totals=[];info=[]
    sites=[(p[0],p[2],k) for p in PROBES for k in LABELS]
    data=[]
    for p in PROBES:
        radial,vertical,*_=halo(-p[0],p[2]);data.append([-radial,0,vertical])
    dark=scale*project(np.array(data)).ravel()
    for model in MODELS:
        for frame in ('archive_accelerating','material_full'):
            checks=[r for r in reference if (r['occupation'],r['model'],r['frame'],r['branch'])==('2',model,frame,'evolved_wave')]
            assert len(checks)==8 and [(float(r['R']),float(r['z']),r['component']) for r in checks]==[(-xx,zz,k) for xx,zz,k in sites]
            total=np.array([float(r['ordinary'])+float(r['direct_in_frame']) for r in checks])+dark
            lo,hi=np.array([[float(r['low']),float(r['high'])] for r in checks]).T
            for row,value,halo_acc in zip(checks,total,dark):
                rows.append(dict(model=model,frame=frame,R=row['R'],z=row['z'],component=row['component'],NFW=halo_acc,total=value,low=row['low'],high=row['high'],inside=float(row['low'])<=value<=float(row['high'])))
            sol,w=control_row(total.reshape(4,2),lo,hi)
            totals.append(dict(model=model,frame=frame,scale_vs_old=scale,scale_radius_kpc=16.,outer_speed=224.03,inside=np.sum((lo<=total)&(total<=hi)),slack=sol[-1],K6=weights(6.)@total,K83=weights(8.3)@total))
        for kind in ('multipole','basis'):
            fs=paths(model)
            for when in ('initial','final'):
                vc=np.sqrt(OUTER*(outer(source)+outer(field(fs[kind,when]))))
                info.append(dict(model=model,kind=kind,epoch=when,speed_azimuthal_mean=vc))
    table('same-anchor-nfw',rows);table('same-anchor-nfw-summary',totals);table('published-host-outer-speeds',info)
if __name__=='__main__':run()
