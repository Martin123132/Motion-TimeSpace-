from fields import *
from field_controls import outer
from scipy.optimize import linprog
from configparser import ConfigParser
sys.path.insert(0,str(SLAB))
from slab_fields import nfw
from tidal_contrasts import ROWS,weights,bounds
from feasibility import bands

LABELS=('radial','polar')
SCALE=PLANES[:,:,[0,2]].reshape(8,2)
def control_row(v,lo,hi):
    total=v.reshape(-1);columns=np.vstack([SCALE,-SCALE])
    ans=linprog([0.,0.,1.],A_ub=np.column_stack([columns,-np.ones(16)]),b_ub=np.r_[hi-total,total-lo],bounds=[(None,None),(None,None),(0,None)],method='highs')
    assert ans.success
    resid=total+SCALE@ans.x[:2]
    assert abs(ans.x[-1]-max(0.,max(resid-hi),max(lo-resid)))<2e-9
    w=-ans.ineqlin.marginals[:8]+ans.ineqlin.marginals[8:]
    proof=w@total-(np.maximum(w,0)@hi+np.minimum(w,0)@lo)
    assert max(abs(w@SCALE))<1e-8 and np.sum(abs(w))<=1+1e-8 and abs(proof-ans.x[-1])<1e-8
    return ans.x,w

def run():
    guard();indices=[(float(-r[0]),r[2],k) for r in PROBES for k in LABELS];assert tuple(ROWS)==tuple(indices)
    bands0=bands();lo,hi=np.array([bands0[r,'ar' if k=='radial' else 'atheta','north' if z>0 else 'south'][3:5] for r,z,k in indices]).T
    def source(level):
        return {(row['model'],row['kind'],row['epoch'],row['measure']):np.array([float(row[k]) for k in ('ax','ay','az')]) for row in read(HERE/f'body-{level}.csv')}
    bulk=source('check'); earlier=source('main')
    tests=[];tides=[];witness=[];spatial=[];book=[];apertures=[];frames=[];response=[]
    def assay(model,variant,case,branch,frame,sky):
        common=dict(model=model,representation=variant,foreground=case,branch=branch,frame=frame)
        flat=sky.ravel();assert len(flat)==8 and np.all(np.isfinite(flat))
        for idx,(radius,z,component) in enumerate(indices):
            val=flat[idx];tests.append(dict(**common,R=radius,z=z,component=component,predicted=val,low=lo[idx],high=hi[idx],inside=bool(lo[idx]<=val<=hi[idx]),gap=max(0.,val-hi[idx],lo[idx]-val)))
        pair=[]
        for radius in (6.,8.3):
            w=weights(radius);value=w@flat;lb,ub=bounds(w,lo,hi)
            tides.append(dict(**common,R=radius,K=value,low=lb,high=ub,deficit=max(0.,lb-value),excess=max(0.,value-ub)));pair.append([lb-value,ub-value])
        sol,proof=control_row(sky,lo,hi)
        witness.append(dict(**common,minimum_uniform_frame_slack=sol[-1],dual_witness=';'.join(map(str,proof)),inner_minus_outer_tide_gap=pair[0][0]-pair[1][1],number_inside=np.sum((flat>=lo)&(flat<=hi))))
    for model in MODELS:
        guard();packs=paths(model);mat=materials(model)
        cfg=ConfigParser();cfg.read(HERE/'source'/model/'fixed-ordinary.ini');bulge=float(cfg['Potential bulge']['mass']);disk=float(cfg['Potential disk']['mass'])
        assert [float(cfg['Potential disk'][k]) for k in ('scaleradius','scaleheight')]==[3.,-.4]
        assert [float(cfg['Potential bulge'][k]) for k in ('scaleradius','outercutoffradius','gamma','beta')]==[.2,1.8,0,1.8]
        def ave(kind,epoch,key):
            if key=='sim':return (disk*bulk[model,kind,epoch,'sim_disk']+bulge*bulk[model,kind,epoch,'sim_bulge'])/(bulge+disk)
            return bulk[model,kind,epoch,key]
        def record(variant,epoch,cosm,proj):
            for radius in (6.,8.3):
                book.append(dict(model=model,representation=variant,epoch=epoch,component=cosm,R=radius,K=weights(radius)@proj.ravel()))
        sat,center=satellite(model);sv=sat(PROBES-center)[:,1:];sat0=sat(-center)[0,1:];star=mat(PROBES)[:,1:]
        noninertial=np.loadtxt(OLD/'source'/model/'accel.txt')[-1];assert noninertial[0]==0
        prior=OLD/'source'/model/'potential_mw_now.ini'
        put('source/'+model+'/present-native.ini',prior.read_bytes())
        now=field(HERE/'source'/model/'present-native.ini')
        control=field(packs['multipole','final'])(PROBES)[:,1:]+star
        assert max(abs((now(PROBES)[:,1:]-control).ravel()))<1e-7
        initial_stars=project(star);direct=project(sv-sat0)
        prior_sat=[row for row in read(OLD/'present-sky.csv') if (row['model'],row['tag'],row['background'])==(model,'fine-reference-m2-n256','nfw') and row['component'] in LABELS]
        oracle={(float(r['R']),float(r['z']),r['component']):float(r['direct']) for r in prior_sat}
        spatial.append(dict(model=model,satellite_native_minus_old_max=np.max(abs(direct.ravel()-[oracle[k] for k in indices])),observer_forcing_x=noninertial[1],observer_forcing_y=noninertial[2],observer_forcing_z=noninertial[3],combined_published_file_max=np.max(abs(now(PROBES)[:,1:]-control))))
        controls={}
        for case,key in enumerate(('reference','added')):
            records=read(GAS/f'outputs/sky-{case}-{model}-{32 if model=="L2M11" else 16}.csv')
            saved={(r['background'],r['frame'],float(r['R']),float(r['z']),r['component']):r for r in records}
            for bg,frame in ((b,f) for b in ('mts','nfw') for f in ('site_minus_point','site_minus_material_planar')):
                given=[saved[(bg,frame,*i)] for i in indices]
                assert [float(r['low']) for r in given]==lo.tolist() and [float(r['high']) for r in given]==hi.tolist()
                assay(model,'retained',key,bg,frame,np.array([float(r['corrected']) for r in given]).reshape(4,2))
            halo=nfw(case);vec=[]
            for point in PROBES:
                radial,vertical,*_=halo(-point[0],point[2]);vec.append([-radial,0.,vertical])
            vec=np.array(vec);scale=-halo(OUTER,0.)[0]
            static=[r for r in read(ROOT/'mts-lmc-live-quadrupole-20261119'/'combined-force-ledger.csv') if (r['orbit'],r['background'])==(model,'nfw') and r['tag'].startswith('fine-' if case==0 else 'upper-')]
            vals={(float(r['R']),float(r['z']),r['component']):float(r['stationary']) for r in static}
            ord_sky=np.array([vals[i] for i in indices]).reshape(4,2)-project(vec)
            controls[key]=(ord_sky,vec,scale)
            satmean=ave('satellite','final',key)
            for frame,ref in [('point',sat0),('material_full',satmean),('material_planar',np.r_[satmean[:2],sat0[2]])]:
                assay(model,'native_common',key,'static_nfw',frame,ord_sky+project(vec+sv-ref))
        for kind in ('multipole','basis'):
            q={e:field(packs[kind,e]) for e in ('initial','final')}
            h={e:f(PROBES)[:,1:] for e,f in q.items()}
            aperture_offsets={}
            for epoch,call in q.items():
                for radius in (.025,.05,.1,.2,.4,.8):
                    small=aperture(call,radius,10);fine=aperture(call,radius,18)
                    if kind=='basis':assert max(abs(small-fine))<1e-7
                    aperture_offsets[epoch,radius]=fine
                    apertures.append(dict(model=model,representation=kind,epoch=epoch,aperture_kpc=radius,ax=fine[0],ay=fine[1],az=fine[2],quadrature_max=max(abs(small-fine))*UNIT))
                record(kind,epoch,'host_halo',project(h[epoch]))
            record(kind,'final','ordinary_sim',initial_stars);record(kind,'final','direct_satellite',project(sv))
            record(kind,'change','host_only',project(h['final']-h['initial']))
            for epoch in ('initial','final'):
                body=ave(kind,epoch,'sim')+ave('satellite','final','sim')
                raw=star+h[epoch]+sv
                for frame,val in [('archive_accelerating',raw+noninertial[1:]),('material_full',raw-body),
                                   ('site_minus_0.1kpc',raw-aperture_offsets[epoch,.1]-sat0),('site_minus_0.4kpc',raw-aperture_offsets[epoch,.4]-sat0)]:
                    assay(model,kind,'simulation','frozen_host' if epoch=='initial' else 'live_host',frame,project(val))
            exp0=outer(q['initial']);exp1=outer(q['final'])
            assert min(exp0,exp1)>0
            for case,(ordinary,halo,anchor) in controls.items():
                ratio=anchor/exp0
                dH=h['final']-h['initial']
                states=[('delta_on_static',halo+dH,1.,-1.),('calibrated_frozen_host',ratio*h['initial'],0.,ratio),
                        ('calibrated_live_host',ratio*h['final'],ratio,0.)]
                response.append(dict(model=model,representation=kind,case=case,outer_inward_initial=exp0*UNIT,outer_inward_final=exp1*UNIT,retained_halo=anchor*UNIT,initial_scaling=ratio,predicted_outer_drift=ratio*(exp1-exp0)*UNIT))
                for label,v,final,ini in states:
                    mean=final*ave(kind,'final',case)+ini*ave(kind,'initial',case)
                    satmean=ave('satellite','final',case)
                    refs={'material_full':mean+satmean}
                    for rad in (.1,.4):
                        offset=final*aperture_offsets['final',rad]+ini*aperture_offsets['initial',rad]+sat0
                        refs[f'site_minus_{rad}kpc']=offset
                        refs[f'material_planar_{rad}kpc']=np.r_[(mean+satmean)[:2],offset[2]]
                    for frame,ref in refs.items():
                        assay(model,kind,case,label,frame,ordinary+project(v+sv-ref))
    for key,vec in bulk.items():
        frames.append(dict(model=key[0],kind=key[1],epoch=key[2],measure=key[3],main_to_check=max(abs(vec-earlier[key]))*UNIT))
    for name,data in [('signed-forces',tests),('vertical-compression',tides),('uniform-frame-certificate',witness),('source-separation',book),('native-controls',spatial),('central-sensitivity',apertures),('outer-anchors',response),('body-refinement',frames)]:
        table(name,data)
if __name__=='__main__':run()
