from fields import *
sys.path.insert(0,str(SLAB))
from slab_fields import RING,MASS
from ordinary_measure import components,quadrature
from scipy.integrate import quad
from lmc_field import snapshot

def sim_components(order):
    rad,wr=quadrature(np.r_[0.,np.arange(.5,14.,.5),16.,20.,26.,36.,50.,70.,100.],order)
    zz,wz=quadrature([0,.1,.4,1.,2.,4.,8.,16.,30.],order)
    tail=np.exp(-zz/.4);dz=tail/(.4*(1+tail)**2)
    disk=(wr*rad/9*np.exp(-rad/3))[:,None]*(2*wz*dz)
    yield 'sim_disk',*tuple(np.broadcast_to(x,disk.shape).ravel() for x in (rad[:,None],zz,disk))
    cut,wt=quadrature(np.r_[0.,.005,.02,.08,.2,.5,1.,2.,4.,8.,15.],order)
    func=lambda r:r**2*(1+r/.2)**-1.8*np.exp(-(r/1.8)**2)
    mass=wt*func(cut)/quad(func,0.,np.inf,epsabs=1e-14)[0]
    mu,aw=quadrature([0.,1.],order*4)
    yield 'sim_bulge',(cut[:,None]*np.sqrt(1-mu**2)).ravel(),(cut[:,None]*mu).ravel(),(mass[:,None]*aw).ravel()

def stencil(coord,edges,order):
    nodes= -np.cos((np.arange(order)+.5)/order*np.pi)
    width=np.diff(edges)
    idx=np.clip(np.searchsorted(edges,coord)-1,0,len(width)-1)
    assert min(coord)>=edges[0] and max(coord)<=edges[-1]
    x=2*(coord-edges[idx])/width[idx]-1
    dif=x[:,None]-nodes[None,:]
    close=abs(dif)<1e-13
    inv=(-1.)**np.arange(order)*np.sin((np.arange(order)+.5)*np.pi/order)
    weights=inv/np.where(close,1.,dif)
    hit=close.any(axis=1);weights[hit]=close[hit].astype(float)
    weights/=weights.sum(axis=1)[:,None]
    return idx[:,None]*order+np.arange(order),weights,(edges[:-1,None]+width[:,None]*(nodes[None,:]+1)/2).ravel()
def weights(order):
    rules={'coarse':(5,5,3,4),'main':(8,8,6,6),'check':(10,10,8,8)}
    nq,nr,nt,cuts=rules[order]
    grid,_=snapshot(paths(MODELS[0])['multipole','initial'])
    redges=np.unique(np.r_[np.arange(-36,np.log(grid[0]),.45),np.log(grid),np.log(5000.)])
    tedges=np.linspace(0.,np.pi/2,cuts+1)
    total=np.zeros((4,(len(redges)-1)*nr*(len(tedges)-1)*nt))
    import itertools
    for name,cyl,z,mass in itertools.chain(components(nq),sim_components(nq)):
        jj,ww,rr=stencil(np.log(np.hypot(cyl,z)),redges,nr);kk,vv,tt=stencil(np.arctan2(z,cyl),tedges,nt)
        val=np.zeros(total.shape[1])
        for a in range(nr):
            index=jj[:,a]*len(tt);coef=ww[:,a]*mass
            for b in range(nt):
                val+=np.bincount(index+kk[:,b],coef*vv[:,b],minlength=len(val))
        assert abs(val.sum()-mass.sum())<1e-10*mass.sum()
        if name=='sim_disk':total[2]+=val
        elif name=='sim_bulge':total[3]+=val
        elif name in ('ring_thin','ring_thick'):total[1]+=RING*val
        else:total[:2]+=val
    masses=total.sum(axis=1)
    assert max(abs(masses[2:]-1.))<2e-6
    for i in range(2):
        row=read(MASS)[i];reference=float(row['total_gravitating_mass'])-float(row['dark_mass'])
        assert abs(masses[i]/reference-1)<2e-5
    total/=masses[:,None]
    rr,tt=np.meshgrid(np.exp(rr),tt,indexing='ij');mask=np.max(abs(total),axis=0)>0
    return (rr*np.cos(tt)).ravel()[mask],(rr*np.sin(tt)).ravel()[mask],total[:,mask]
def average(evaluate,measure,order,center=None):
    cyl,z,weight=measure;total=np.zeros((len(weight),3));center=np.zeros(3) if center is None else center
    phi=(np.arange(order)+.321)*2*np.pi/order
    for i in range(0,len(cyl),500):
        sl=slice(i,i+500)
        xyz=np.stack(np.broadcast_arrays(cyl[sl,None]*np.cos(phi),cyl[sl,None]*np.sin(phi),z[sl,None]),axis=-1)
        field=evaluate(xyz.reshape(-1,3)-center)[:,1:]
        xyz[:,:,2]*=-1
        both=(field+evaluate(xyz.reshape(-1,3)-center)[:,1:])*.5
        total+=weight[:,sl]@both.reshape(len(xyz),order,3).mean(axis=1)
    return total
def run(level):
    guard();weight=weights(level);rows=[]
    for model in MODELS:
        guard()
        def record(label,epoch,arr):
            for idx,key in enumerate(('reference','added','sim_disk','sim_bulge')):
                rows.append(dict(model=model,kind=label,epoch=epoch,measure=key,ax=arr[idx,0],ay=arr[idx,1],az=arr[idx,2]))
        for (variant,epoch),path in paths(model).items():
            record(variant,epoch,average(field(path),weight,8 if level=='coarse' else 12))
        sat,center=satellite(model)
        record('satellite','final',average(sat,weight,{'coarse':16,'main':24,'check':36}[level],center))
        print(level,model,flush=True)
    table('body-'+level,rows)
if __name__=='__main__':run(sys.argv[1])
