from host_io import *
import re,struct,zipfile,zlib,time
import requests

def run():
    guard();meta=json.loads((OLD/'archive-receipt.json').read_text());size=meta['archive_bytes'];url=meta['url']
    tail=(OLD/'archive-central-directory.bin').read_bytes();offset=size-len(tail)
    eocd=struct.unpack_from('<4s4H2IH',tail,tail.rfind(b'PK\x05\x06'))
    assert offset==eocd[-2]
    zipdir=zipfile.ZipFile(io.BytesIO(tail));rows=[]
    with requests.Session() as client:
        for model in MODELS:
            ends=[]
            for variant,source,prefix in [('multipole','potential.ini','pot'),('basis','potential_bse.ini','pot_bse')]:
                cfg=(OLD/'source'/model/source).read_text()
                tracks=re.findall(r'^\s*([-\d.]+)\s+('+prefix+r'/mwhalo\d+\.ini)\s*$',cfg,re.M)
                assert tracks and float(tracks[0][0])<0 and float(tracks[-1][0])==0
                ends.append([stamp for stamp,_ in [tracks[0],tracks[-1]]])
                for mark,(stamp,file) in zip(('initial','final'),(tracks[0],tracks[-1])):
                    name=model+'/'+file;entry=zipdir.getinfo(name);begin=offset+entry.header_offset
                    stop=begin+30+len(name)+len(entry.extra)+entry.compress_size+128
                    dest='source/'+name
                    if not (HERE/dest).exists():
                        for attempt in range(3):
                            guard()
                            try:
                                with client.get(url+f'?mtsrange={begin}-{stop}',headers={'Range':f'bytes={begin}-{stop}','Accept-Encoding':'identity'},stream=True,timeout=25) as res:
                                    assert res.status_code==206 and res.headers.get('Content-Range')==f'bytes {begin}-{stop}/{size}',(res.status_code,res.headers.get('Content-Range'))
                                    data=res.raw.read(stop-begin+2);assert len(data)==stop-begin+1
                                break
                            except (requests.RequestException,AssertionError):
                                if attempt==2:raise
                                time.sleep(2)
                        assert data[:4]==b'PK\x03\x04'
                        nlen,xlen=struct.unpack_from('<HH',data,26);assert data[30:30+nlen].decode()==name
                        start=30+nlen+xlen;assert entry.compress_type==8
                        raw=zlib.decompress(data[start:start+entry.compress_size],-15)
                        assert len(raw)==entry.file_size and zlib.crc32(raw)==entry.CRC
                        put(dest,raw)
                    raw=(HERE/dest).read_bytes();assert len(raw)==entry.file_size and zlib.crc32(raw)==entry.CRC
                    rows.append(dict(model=model,epoch=mark,time=stamp,variant=variant,path=dest,local_bytes=len(raw),range_start=begin,range_end=stop,crc32=f'{entry.CRC:08x}',sha256=digest(HERE/dest)))
            assert ends[0]==ends[1]
            print(model,'verified',flush=True)
    table('host-inputs',rows)
if __name__=='__main__':run()
