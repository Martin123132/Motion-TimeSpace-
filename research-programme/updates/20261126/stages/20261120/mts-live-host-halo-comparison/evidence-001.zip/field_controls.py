from fields import *
from lmc_field import harmonic,snapshot,potential
from scipy.special import eval_gegenbauer
def basis_values(path,xyz):
    config=path.read_text().split('Coefficients')[0]
    assert 'eta=1\n' in config and 'r0=50\n' in config
    coef=np.loadtxt(path.read_text().split('#radius')[1].splitlines()[1:])[:,1:]
    assert coef.shape==(21,49)
    rad=np.linalg.norm(xyz,axis=1);s=rad/50.;xi=(s-1)/(s+1)
    mu=xyz[:,2]/rad;phi=np.arctan2(xyz[:,1],xyz[:,0]);v=np.zeros(len(rad))
    for ell in range(7):
        wave=np.stack([eval_gegenbauer(n,2*ell+1.5,xi) for n in range(21)],axis=1)
        block=wave@coef[:,ell**2:(ell+1)**2]
        term=block[:,ell]*harmonic(ell,0,mu,phi).real
        for m in range(1,ell+1):
            harm=harmonic(ell,m,mu,phi)
            term+=np.sqrt(2)*(harm.real*block[:,ell+m]+harm.imag*block[:,ell-m])
        v-=term*s**ell/(50*(1+s)**(2*ell+1))
    return v
def derivative(function,points,step=.002):
    return np.stack([(function(points+2*step*axis)-8*function(points+step*axis)+8*function(points-step*axis)-function(points-2*step*axis))/(12*step) for axis in np.eye(3)],axis=1)
def outer(evaluate):
    phi=(np.arange(24)+.3)*2*np.pi/24
    unit=np.column_stack([np.cos(phi),np.sin(phi),np.zeros_like(phi)])
    return -np.mean(np.sum(evaluate(OUTER*unit)[:,1:]*unit,axis=1))
def compare():
    guard();rows=[]
    points=np.vstack([PROBES,[4.,3.,-2.],[-10.,2.,1.],[OUTER,0.,0.]])
    for model in MODELS:
        for (variant,epoch),path in paths(model).items():
            fun=field(path);vals=fun(points)
            if variant=='multipole':
                knots,coeff=snapshot(path)
                interp=lambda pt:potential(pt,knots,coeff)
                ar=float(np.max(abs(fun(knots[:,None]*np.array([[1.,.0,0.]]))[:,0]-interp(knots[:,None]*np.array([[1.,0.,0.]])))))
            else:interp=lambda pt:basis_values(path,pt);ar=0.
            grad=derivative(lambda v:fun(v)[:,0],points)
            own=derivative(interp,points)
            err=np.max(abs(grad-vals[:,1:]))*UNIT;scale=np.max(abs(vals[:,1:]))*UNIT
            assert err<2e-5*scale
            discrepancy=max(abs(interp(points)-vals[:,0]))
            if variant=='basis':
                assert discrepancy<1e-6 and np.max(abs(own-vals[:,1:]))*UNIT<1e-8
            rows.append(dict(model=model,epoch=epoch,representation=variant,native_analytic_vs_FD_max=err,separate_readout_potential_max=discrepancy,separate_readout_force_max=np.max(abs(own-vals[:,1:]))*UNIT,aligned_knots_potential_max=ar))
    table('field-validation',rows)
if __name__=='__main__':compare()
