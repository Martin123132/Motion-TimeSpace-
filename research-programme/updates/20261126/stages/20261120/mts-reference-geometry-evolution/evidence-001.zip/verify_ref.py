"""Verify the published numbers, joint decisions, and complete write-once restart inventory."""
from ref_evolve import *
from analyze_ref import evaluate

def main(seal):
    guard()
    assert core.sha(HERE/"frozen-transport.csv")=="1c523fe41a1f818e921050df387c67403b029503805d8f883e24c7b0fdbb07fe"
    freeze=[r for r in core.read(checked("curvature-versus-arithmetic.csv")) if r["variant"]=="green"]
    rows=core.read(HERE/"frozen-transport.csv")
    assert len(rows)==len(freeze)==32
    assert rows==[{key:r[key] for key in rows[0]} for r in freeze]
    assert not list(HERE.glob("*.partial"))
    assert len(list(HERE.glob("*.npz")))==48
    evaluate(False);evaluate(True)
    from newton_signal import main as compare_newton
    compare_newton()
    final=core.read(HERE/"all-controls.csv")
    for scheme in ("original","adm"):
        old=core.read(checked(f"budget-green-{scheme}-n160-p8.csv"))
        for row in core.read(HERE/f"crossed-{scheme}.csv"):
            if row["evolution"]!=row["endpoint"]:continue
            seed,width=row["seed"],row["width"]
            if row["evolution"]=="sampled":
                target=next(item["observed_ppm"] for item in old if (item["seed"],item["width"],item["fraction"],item["stride"])==(seed,width,"1.0","1"))
            else:
                target=next(item["curvature_split_ppm"] for item in final if (item["seed"],item["width"],item["fraction"],item["scheme"])==(seed,width,"1.0",scheme))
            assert abs(float(row["split_ppm"])-float(target))<1e-6
    for path in HERE.glob("*.csv"):
        material=core.read(path)
        assert material and all(None not in row and all(value is not None and value.strip() for value in row.values()) for row in material),path
    assert len(core.read(HERE/"dust-control.csv"))==16 and len(core.read(HERE/"scalar-disturbance.csv"))==15
    manifest={path.name:core.sha(path) for path in sorted(HERE.iterdir()) if path.is_file() and path.name!="seal.json"}
    obj=dict(files=manifest,predecessor=core.sha(PREV/"seal.json"),csv_rows=sum(len(core.read(path)) for path in HERE.glob("*.csv")),
             full_state_packets=len(list(HERE.glob("*.npz"))),main_and_refinement_comparisons=len(final),
             passed=sum(row["passed"]=="True" for row in final))
    blob=(json.dumps(obj,indent=2,sort_keys=True)+"\n").encode()
    if seal:save("seal.json",blob)
    assert (HERE/"seal.json").read_bytes()==blob
    print("verified",len(manifest),"files",obj["csv_rows"],"rows",obj["full_state_packets"],"histories",core.sha(HERE/"seal.json"))

if __name__=="__main__":main(sys.argv[1:]==["seal"])

