"""Factor the change at the main resolution into evolution and readout without altering either."""
from ref_evolve import *
from math import fsum

def run(scheme):
    core.ep.getcontext().prec=40
    rows=[]
    data={}
    for flag in (0,1):
        for seed in (0,1,-1):
            fixed,_,_=system(160,flag,seed,scheme)
            original=core.system(160,flag,seed,"green-"+scheme)
            original.ref_geometry=fixed.ref_geometry
            for operator,shell,name in (("sampled",original,checked(f"green-{scheme}-n160-p8-off{flag}-s{seed}.npz")),
                                         ("reference",fixed,HERE/f"{scheme}-n160-p8-L3-off{flag}-s{seed}.npz")):
                with np.load(name) as packet:final=packet["change"][-1]
                for reader,readout in (("reference",fixed_tide),("sampled",core.ep.fixed_tide)):
                    guard()
                    with patch.object(core.ep,"fixed_tide",readout):
                        for width,channel,value in core.central.measure(shell,8*core.DURATION,final):
                            if channel in ("ricci","gauss"):
                                data[flag,seed,width,channel,operator,reader]=64*value
    target=core.read(core.UP/"curved-contrast.csv")
    for row in target:
        if row["channel"]!="gauss" or float(row["fraction"])!=1:continue
        seed,width=int(row["seed"]),float(row["width"])
        for operator in ("sampled","reference"):
            for reader in ("sampled","reference"):
                def contrast(channel):
                    return fsum(sign*data[flag,host,width,channel,operator,reader] for flag,host,sign in ((0,seed,1),(0,0,-1),(1,seed,-1),(1,0,1)))
                split=(contrast("gauss")-contrast("ricci"))/(abs(float(row["full_newton"]))*1e-6)
                rows.append(dict(scheme=scheme,seed=seed,width=width,evolution=operator,endpoint=reader,split_ppm=split))
    table(f"crossed-{scheme}.csv",rows)

if __name__=="__main__":run(sys.argv[1])

