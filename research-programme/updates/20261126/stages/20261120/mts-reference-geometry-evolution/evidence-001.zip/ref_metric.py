"""Reference metric on the evolution grid from the full regular/Robin inverse."""
import sys
import io
import csv
import json
from pathlib import Path
from functools import lru_cache
from numpy.polynomial.legendre import leggauss, legvander
import numpy as np

HERE = Path(__file__).resolve().parent
PREV = HERE.parent/"mts-central-constraint-transport-20261120"
sys.path.insert(0, str(PREV))
import core
from cloud_owner import inv, pair, mul, exp, square
from launch_data import states

def prefix(values):
    result = [0.]
    lost = 0.
    for term in values:
        adjusted = term-lost
        following = result[-1]+adjusted
        lost = (following-result[-1])-adjusted
        result.append(following)
    return np.asarray(result)

assert core.sha(PREV/"seal.json") == "da46cb1269e12b7aaa93bce593df48e7cf3208e02a4e4e10b9ab65c9230b55b4"
pins = json.loads((PREV/"seal.json").read_bytes())["files"]

def guard():
    core.guard()
    if (HERE/"STOP-REQUESTED").exists():
        raise RuntimeError("Owner requested stop")

def checked(name):
    path = PREV/name
    assert core.sha(path) == pins[name], path
    return path

def save(name, data):
    guard()
    path = HERE/name
    if path.exists():
        assert path.read_bytes() == data, path
    else:
        pending = path.with_suffix(path.suffix+".partial")
        with pending.open("xb") as stream:
            stream.write(data)
        pending.rename(path)

def table(name, rows):
    buffer = io.StringIO(newline="")
    writer = csv.DictWriter(buffer, list(rows[0]), lineterminator="\n")
    writer.writeheader()
    writer.writerows(rows)
    save(name,buffer.getvalue().encode())

def radial(nodes, spacing, source, harmonic, robin, radii, order):
    count, size = source.shape
    cell = np.floor(radii/spacing).astype(int).clip(0,count-1)
    assert np.all((radii>0)&(radii<=count*spacing))
    local = radii/spacing-cell
    inverse = np.linalg.inv(legvander(2*nodes-1,size-1))
    coeff = (source-source[:,:1])@inverse.T
    coeff[:,0] += source[:,0]
    rule, weights = leggauss(order)
    def integrate(index, first, last, power):
        half = (last-first)/2
        points = (last+first)[:,None]/2 + half[:,None]*rule
        value = np.einsum("ijk,ik->ij",legvander(2*points-1,size-1),coeff[index])
        coord = (index[:,None]+points)*spacing
        return ((coord**power*value)@weights)*half*spacing
    index = np.arange(count)
    zero, one = np.zeros(count), np.ones(count)
    inside = prefix(integrate(index,zero,one,harmonic+2))[cell]
    outside = prefix(integrate(index,zero,one,1-harmonic)[::-1])[count-cell-1]
    inside += integrate(cell,local*0,local,harmonic+2)
    outside += integrate(cell,local,local*0+1,1-harmonic)
    outside += robin*(count*spacing)**(1-harmonic)
    inner = inside/radii**(harmonic+1)
    outer = outside*radii**harmonic
    value = (inner+outer)/(2*harmonic+1)
    first = (-(harmonic+1)*inner+harmonic*outer)/((2*harmonic+1)*radii)
    density = np.einsum("ij,ij->i",legvander(2*local-1,size-1),coeff[cell])
    second = -density-2*first/radii+harmonic*(harmonic+1)*value/radii**2
    return np.stack((value,first,second,density))

@lru_cache(maxsize=2)
def boundary(flag):
    fields = states.shape(core.family.pressure(flag)[0],np.asarray(144.))
    return (fields["chir"]+3*fields["chi"]/144)/64

def sample(flag,seed,radii,order=32):
    with np.load(checked(f"green-rhs-off{flag}-s{seed}.npz")) as inputs:
        values = np.array([radial(inputs["t"],float(inputs["h"]),source,harmonic,robin,radii,order)
                           for source,harmonic,robin in zip(inputs["src"],(0,2),(0.,boundary(flag)))])
    chi,first,second,source = values.transpose(1,0,2)
    inverse = inv(chi+pair(np.ones_like(radii)))
    slope = mul(first,inverse)
    reference = 2*pair(np.log1p(chi[0]),chi[1]*inverse[0])
    return (reference,2*slope,2*(mul(second,inverse)-square(slope))),8*mul(exp(-2.5*reference),source)

