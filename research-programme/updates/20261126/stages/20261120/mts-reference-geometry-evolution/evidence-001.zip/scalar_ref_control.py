"""A radially inhomogeneous scalar disturbance with analytic continuum curvature at both endpoints."""
from ref_evolve import *
from scipy.special import spherical_jn
from dust_control import EmptyBank

def mode(radius,k,scale):
    angular=np.array([0,2])[:,None]
    value=scale*spherical_jn(angular,k*radius)
    first=k*scale*spherical_jn(angular,k*radius,True)
    second=-k*k*value-2*first/radius+angular*(angular+1)*value/radius**2
    return np.stack((value,first,second))

def metric(mode_values):
    chi,first,second=mode_values
    inverse=inv(chi+pair(np.ones_like(chi[0])))
    tangent=mul(first,inverse)
    return 2*pair(np.log1p(chi[0]),chi[1]*inverse[0]),2*tangent,2*(mul(second,inverse)-square(tangent))

def main():
    core.ep.getcontext().prec=40
    rows=[]
    for scheme in ("original","adm"):
        shell=core.system(160,1,0,scheme)
        shell.incident.bank=EmptyBank(shell.r)
        shell.initial[:]=0.;shell.rho*=0
        base=mode(shell.r,6.,.023)
        bump=mode(shell.r,3.5,.014)
        ref=metric(base)
        shell.initial[0]=shell.initial[1]=ref[0]
        attach(shell,(ref,ref))
        inner=(shell.r>.55)&(shell.r<2.2)
        for fraction in (0.,.35,1.):
            held=shell.initial.copy()
            current=metric(base+fraction*bump)[0]
            held[0]=held[1]=current
            independent=8*mul(exp(-2.5*current),6**2*base[0]+3.5**2*fraction*bump[0])
            info=shell.dynamics(0.,held,True)
            direct,gauss=fixed_tide(shell,shell.initial,held-shell.initial)
            monitor=6*(gauss-direct).astype(float)
            results=[info["ham"],monitor]
            if scheme=="adm":
                results.append(shell.dynamics(0.,held)[4].real)
            for name,measured in zip(("spatial_evolution","finite_endpoint","adm_acceleration"),results):
                err=np.max(abs((measured-independent)[:,inner]))/np.max(abs(independent[:,inner]))
                assert err<1e-9,(scheme,fraction,name,err)
                rows.append(dict(scheme=scheme,fraction=fraction,quantity=name,relative_error=err))
    table("scalar-disturbance.csv",rows)

if __name__=="__main__":main()

