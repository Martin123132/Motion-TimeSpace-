"""Evolve the unaltered parent equations with a differentiable geometric launch reference."""
import os
for variable in ("OPENBLAS_NUM_THREADS","OMP_NUM_THREADS","MKL_NUM_THREADS","NUMEXPR_NUM_THREADS"):
    os.environ[variable]="1"
from unittest.mock import patch
from ref_metric import *
from ref_endpoint import fixed_tide

def attach(shell, refs):
    shell.ref_geometry = refs
    diff = shell.diff
    evolution = shell.dynamics
    active = {}
    def address(array):
        return array.__array_interface__["data"][0]
    def corrected(array,degree=1,odd=False):
        entry = active.get(address(array)) if array.dtype==np.float64 and not odd else None
        if entry is not None:
            for shape,strides,reference in entry:
                if array.shape==shape and array.strides==strides:
                    return diff(array-reference[0],degree)+reference[degree]
        return diff(array,degree,odd)
    def right(time,state,details=False):
        assert not active
        try:
            for slot,reference in enumerate(refs):
                field=state[slot].real
                for component in (None,0,1):
                    view=field if component is None else field[component]
                    basis=reference if component is None else tuple(item[component] for item in reference)
                    active.setdefault(address(view),[]).append((view.shape,view.strides,basis))
            return evolution(time,state,details)
        finally:
            active.clear()
    shell.diff=corrected
    shell.dynamics=right

def system(grid,flag,seed,scheme,edge=3):
    shell=core.system(grid,flag,seed,"green-"+scheme,edge)
    reference,expected=sample(flag,seed,shell.r)
    start=shell.initial
    shift=reference[0]-start[0].real
    start[5]=mul(exp(-3*shift),start[5])
    start[6:8,1]*=np.exp(-3*shift[0])
    start[14]-=1.5*shift
    start[18:20,1]*=np.exp(-4*shift[0])
    start[0]=start[1]=reference[0]
    attach(shell,(reference,reference))
    return shell,expected,float(np.max(abs(shift)))

def run(grid,steps,edge,scheme,flags):
    core.ep.getcontext().prec=40
    count=128*steps
    step=8*core.DURATION/count
    for flag in flags:
        for seed in (0,1,-1):
            guard()
            stem=f"{scheme}-n{grid}-p{steps}-L{edge}-off{flag}-s{seed}"
            shell,expected,shift=system(grid,flag,seed,scheme,edge)
            advance=core.central.traced.collar.stepper(shell,step)
            change=np.zeros_like(shell.initial)
            history=[];rows=[]
            for tick in range(1,count+1):
                if tick%16==1:guard()
                change=advance((tick-1)*step,change)
                if tick%(count//4):continue
                assert np.isfinite(change).all()
                history.append(change.copy())
                with patch.object(core.ep,"fixed_tide",fixed_tide):
                    for width,label,value in core.central.measure(shell,tick*step,change):
                        rows.append(dict(grid=grid,steps=steps,edge=edge,flag=flag,seed=seed,scheme=scheme,
                                         fraction=tick/count,width=width,channel=label,scaled_delta=64*value,
                                         max_initial_logmetric_change=shift))
            stream=io.BytesIO()
            np.savez_compressed(stream,r=shell.r,change=history)
            save(stem+".npz",stream.getvalue())
            table(stem+".csv",rows)
            print("saved",stem,flush=True)

if __name__=="__main__":
    run(*map(int,sys.argv[1:4]),sys.argv[4],tuple(map(int,sys.argv[5:])))

