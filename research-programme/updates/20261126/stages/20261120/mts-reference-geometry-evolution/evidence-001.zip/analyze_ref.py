"""Assemble complete matched comparisons without treating detector channels as independent evidence."""
from ref_evolve import *
from math import fsum

def key(row):
    return int(row["seed"]),float(row["width"]),float(row["fraction"]),row["channel"]

def cases(scheme,grid,steps,edge):
    group={}
    for flag in (0,1):
        for seed in (0,1,-1):
            name=f"{scheme}-n{grid}-p{steps}-L{edge}-off{flag}-s{seed}"
            with np.load(HERE/(name+".npz")) as restart:
                assert restart["change"].shape==(4,20,2,grid*edge) and np.isfinite(restart["change"]).all()
                assert np.array_equal(restart["r"],(np.arange(grid*edge)+.5)/grid)
            raw=core.read(HERE/(name+".csv"))
            assert len(raw)==40
            for row in raw:
                assert (int(row["flag"]),int(row["seed"]),int(row["steps"]),int(row["grid"]),int(row["edge"]),row["scheme"])==(flag,seed,steps,grid,edge,scheme)
                term=(flag,*key(row))
                assert term not in group
                group[term]=float(row["scaled_delta"])
    return {(seed,width,frac,channel):fsum(sign*group[flag,host,width,frac,channel]
           for flag,host,sign in ((0,seed,1),(0,0,-1),(1,seed,-1),(1,0,1)))
           for flag,seed,width,frac,channel in group if flag==0 and seed!=0}

def evaluate(with_refine):
    configs=[(160,8,3)]
    if with_refine:configs += [(160,4,3),(200,4,3),(160,4,4)]
    groups={(scheme,config):cases(scheme,*config) for scheme in ("original","adm") for config in configs}
    forecasts={(row["scheme"],int(row["seed"]),float(row["width"]),float(row["fraction"])):float(row["analytic_R_only"])
               for row in core.read(HERE/"frozen-transport.csv")}
    target=core.read(core.UP/"curved-contrast.csv")
    transverse={key(row):float(row["tt"]) for row in core.read(core.UP/"transverse-test.csv")}
    rows=[]
    for scheme in ("original","adm"):
        current=groups[scheme,configs[0]]
        other=groups["adm" if scheme=="original" else "original",configs[0]]
        for row in target:
            idx=key(row);seed,width,frac,channel=idx
            unit=abs(float(row["full_newton"]))*1e-6
            norm=current[idx]
            amplitude=(norm-float(row["longitudinal"])-transverse[idx])/unit
            split=(current[seed,width,frac,"gauss"]-current[seed,width,frac,"ricci"])/unit
            form=(norm-other[idx])/unit
            residual=split-forecasts[scheme,seed,width,frac]
            record=dict(scheme=scheme,seed=seed,width=width,fraction=frac,channel=channel,curved=norm,tt_error_ppm=amplitude,
                        curvature_split_ppm=split,cross_formulation_ppm=form,split_minus_forecast_ppm=residual)
            if with_refine:
                coarse,fine,far=[groups[scheme,config][idx] for config in configs[1:]]
                checks=dict(time_ppm=(norm-coarse)/unit,space_ppm=(fine-coarse)/unit,edge_ppm=(far-coarse)/unit)
                record.update(checks,passed=max(map(abs,(amplitude,split,form,*checks.values())))<=20)
            rows.append(record)
    assert len(rows)==64
    table("all-controls.csv" if with_refine else "primary-comparison.csv",rows)
    for name in ("tt_error_ppm","curvature_split_ppm","cross_formulation_ppm","split_minus_forecast_ppm"):
        print(name,max(abs(row[name]) for row in rows))
    if with_refine: print("passed",sum(row["passed"] for row in rows),len(rows))

if __name__=="__main__":evaluate(sys.argv[1:]==["all"])

