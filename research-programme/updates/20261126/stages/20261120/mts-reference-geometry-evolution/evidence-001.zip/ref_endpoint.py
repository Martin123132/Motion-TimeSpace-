"""Independent decimal endpoint with the continuous reference and the discrete metric change."""
from ref_metric import core, np
from endpoints import D,convert,pack,prod,exponential,square

def fixed_tide(shell,start,change):
    def coord(idx,imag=False):
        field=start[idx].imag if imag else start[idx].real
        result=convert(field)
        if change is not None:result+=convert(change[idx].imag if imag else change[idx].real)
        return result
    radius=convert(shell.r);dx=D(shell.dx);mu=D(shell.mu)
    ell,bend,tilt,angular,trace,shear=(coord(i) for i in range(6))
    def diff(data,degree=1):
        padded=np.concatenate((data[...,2::-1],data,data[...,:-4:-1]),axis=-1)
        count=len(radius)+1
        face=sum(D(w)*(padded[...,3+j:3+j+count]-padded[...,2-j:2-j+count]) for j,w in enumerate(shell.weights))/dx
        ext=np.concatenate((-face[...,2:0:-1],face,-face[...,-2:-4:-1]),axis=-1)
        count-=1
        if degree==2:
            return sum(D(w)*(ext[...,3+j:3+j+count]-ext[...,2-j:2-j+count]) for j,w in enumerate(shell.weights))/dx
        return sum(D(w)*(ext[...,3+j:3+j+count]+ext[...,2-j:2-j+count]) for j,w in enumerate(shell.average))
    density=coord(17);material=0*density;unit=pack(0*radius+1)
    normal=exponential(-ell);volume=exponential(-ell-2*bend)
    for idx in range(3 if shell.flag else 2):
        rest=D(shell.rho[idx])*prod(coord(8+2*idx),volume)
        speed=square(prod(normal,diff(coord(9+2*idx))))
        root=np.sqrt(1+speed[0]);gamma=pack(root,speed[1]/(2*root))
        reciprocal=pack(1/root,-gamma[1]/(root**2))
        density+=prod(rest,gamma)
        material+=2*prod(rest,prod(speed,reciprocal))/3
    if not shell.flag:
        amplitude=coord(14);phase=coord(14,True)
        rest=D(shell.rho[-1])*exponential(2*amplitude)
        grad=(square(prod(normal,diff(amplitude)))+square(prod(normal,diff(phase))))/(mu**2)
        kin=square(coord(15)+trace/(2*mu))+square(coord(15,True)-unit)
        density+=prod(rest,unit+kin+grad)/2
        material+=2*prod(rest,grad)/3
    def metric_derivative(slot,degree):
        base,first,second=shell.ref_geometry[slot]
        field=ell if slot==0 else bend
        return diff(field-convert(base),degree)+convert(first if degree==1 else second)
    deriv=metric_derivative(1,1);ed=metric_derivative(0,1)
    inv=exponential(-2*ell);ev=np.exp(-2*bend[0])
    curvature_gap=-2*prod(inv,square(deriv)+2*deriv/radius)
    monopole=2*inv[0]*(np.exp(2*(ell[0]-bend[0]))-1)/radius**2
    curvature_gap[0]+=monopole
    curvature_gap[1]+=(ev*(8*bend[1]+12*angular[1])+inv[0]*(4*ell[1]-12*tilt[1]))/radius**2-12*inv[0]*deriv[0]*tilt[1]/radius
    normal_ric=2*metric_derivative(1,2)-2*prod(ed,deriv)-2*ed/radius
    normal_ric[1]+=6*(diff(tilt[1])-ed[0]*tilt[1])/radius
    direct=prod(inv,normal_ric);direct[0]+=monopole
    direct[1]+=(inv[0]*(4*ell[1]-6*tilt[1])+ev*(8*bend[1]+12*angular[1]-6*ell[1]))/radius**2
    extra=material-prod(trace,shear)/3+square(shear)/2
    gauss=(2*density-2*square(trace)/3+3*square(shear)/2)/6-curvature_gap/2
    return np.stack((extra+direct/3,extra-gauss))
