"""Controls independent of the target signed response; freeze the predecessor forecasts."""
from ref_evolve import *
from dust_control import EmptyBank,exact,ltb
from math import fsum

def known():
    length=4.
    spacing=.2
    nodes=(leggauss(12)[0]+1)/2
    sourcepos=(np.arange(20)[:,None]+nodes)*spacing/length
    radius=np.r_[.0002,.003,.025,.1999,.2,.202,1.005,1.212,3.9,4.]
    actual=radius/length
    rows=[]
    for harmonic in (0,2):
        amplitudes=(.7,1.,-.31)
        powers=np.arange(harmonic,harmonic+5,2)
        source=sum(-amp*(degree*(degree+1)-harmonic*(harmonic+1))*sourcepos**(degree-2)/length**2 for amp,degree in zip(amplitudes,powers))
        robin=sum(amp*(degree+harmonic+1)/length for amp,degree in zip(amplitudes,powers))
        for order in (32,64):
            calculated=radial(nodes,spacing,source,harmonic,robin,radius,order)
            for degree in (0,1,2):
                target=sum(amp*np.prod(np.arange(power-degree+1,power+1),dtype=float)*actual**(power-degree)/length**degree for amp,power in zip(amplitudes,powers))
                error=max(abs(calculated[degree]-target))/max(abs(target))
                assert error<3e-11,(harmonic,degree,error)
                rows.append(dict(harmonic=harmonic,derivative=degree,order=order,relative=error))
    table("analytic-multipoles.csv",rows)

def freeze():
    forecast=core.read(checked("curvature-versus-arithmetic.csv"))
    table("frozen-transport.csv",[{key:row[key] for key in ("seed","width","fraction","scheme","analytic_R_only")}
                                  for row in forecast if row["variant"]=="green"])

def dust_geometry(radius):
    import sympy as sy
    coord=sy.Symbol("r",positive=True)
    age=8+sy.exp(-coord**2/4)/2
    area=coord*(age/8)**sy.Rational(2,3)
    normal=area.diff(coord)
    ell,bend=sy.log(normal),sy.log(area/coord)
    move=coord**3*sy.exp(-coord**2/3)/10
    twist=coord**2*sy.exp(-coord**2/2)/30
    fields=((ell,ell.diff(coord)*move+move.diff(coord)),(bend,normal*move/area-3*twist))
    result=[]
    for components in fields:
        function=sy.lambdify(coord,[part.diff(coord,degree) for degree in (0,1,2) for part in components],"numpy",cse=True)
        result.append(np.array(function(radius)).reshape(3,2,-1))
    return result

def dust(scheme):
    core.ep.getcontext().prec=40
    shell=core.system(160,1,0,scheme)
    shell.incident.bank=EmptyBank(shell.r)
    shell.rho=np.array([1/64,0.,0.])
    shell.initial[:]=0.
    shell.initial[:17]=ltb(shell.r,0.)
    shell.initial[4:8]/=8
    reference=dust_geometry(shell.r)
    for slot,fields in enumerate(reference):
        np.testing.assert_allclose(fields[0],shell.initial[slot].real,atol=2e-15,rtol=2e-14)
        fields[0]=shell.initial[slot].real.copy()
    attach(shell,reference)
    dt=core.DURATION*8/64
    advance=core.central.traced.collar.stepper(shell,dt)
    change=np.zeros_like(shell.initial);start={};rows=[]
    for tick in range(65):
        if tick in (0,32,64):
            state=shell.initial+change;epoch=tick*dt
            win=core.ep.Window(shell,state,np.zeros_like(state),12)
            tides=fixed_tide(shell,shell.initial,change).astype(float)
            for channel,field in zip(("ricci","gauss"),tides):
                mono,quad=win.at(field)
                for idx,width in enumerate(core.family.FRACTIONS):
                    val=64*(win.widths[idx,0]@mono)
                    angular=64*(win.widths[idx,0]@quad+win.widths[idx,1]@mono)
                    target=exact(epoch/8,width)
                    if not tick:start[channel,width]=val,angular,target;continue
                    st,sg,truth=start[channel,width]
                    error=((val-st)/(target-truth)-1)*1e6
                    gauge=(angular-sg)/(target-truth)*1e6
                    assert max(abs(error),abs(gauge))<20,(channel,error,gauge)
                    rows.append(dict(scheme=scheme,width=width,fraction=tick/64,channel=channel,error_ppm=error,gauge_ppm=gauge))
        if tick<64:change=advance(epoch if tick in (0,32) else tick*dt,change)
    return rows

def physical():
    rows=[]
    for flag in (0,1):
        for seed in (0,1,-1):
            shell,curv,delta=system(160,flag,seed,"original")
            mode=core.system(160,flag,seed,"green-original")
            start=shell.initial
            center=(shell.r>.6)&(shell.r<2.1)
            rhs0=mode.dynamics(0.,start)
            rhs1=shell.dynamics(0.,start)
            native=core.ham(mode,start)-core.spatial(mode,start[:4].real)+curv
            actual=shell.dynamics(0.,start,True)["ham"]
            delta_h=max(abs((actual-native)[1,center]))
            assert delta_h < 2e-19,delta_h
            ref64,target64=sample(flag,seed,shell.r,64)
            relative=max(np.max(abs(a-b))/max(np.max(abs(a)),1e-200) for a,b in zip(ref64,shell.ref_geometry[0]))
            assert relative < 1e-9,relative
            with np.load(checked(f"green-q64-off{flag}-s{seed}.npz")) as packet:
                positions=(np.arange(15)[:,None]+packet["t"])*packet["h"]
                sampled=sample(flag,seed,positions.ravel())[0][0].reshape(2,*positions.shape)
                cached=packet["chi"][:,:15]
                log=2*np.array([np.log1p(cached[0]),cached[1]/(1+cached[0])])
                archive=np.max(abs(sampled-log))/max(np.max(abs(log)),1e-200)
                assert archive<1e-10,archive
            rows.append(dict(flag=flag,seed=seed,log_shift=delta,mid_domain_H_absolute=delta_h,
                             quadrature_relative=relative,archive_relative=archive,change_to_shear_rhs=np.max(abs(rhs0[5]-rhs1[5]))))
    table("physical-reference.csv",rows)

if __name__=="__main__":
    freeze();known();physical()
    table("dust-control.csv",dust("original")+dust("adm"))
    print("multipoles, archived launch, analytic trace and two dust evolutions passed")

