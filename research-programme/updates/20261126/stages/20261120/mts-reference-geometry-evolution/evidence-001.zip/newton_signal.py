"""Contrast the uncorrected Newton tide and the retarded material-stress prediction."""
from analyze_ref import *

def main():
    material={key(row):float(row["tt"]) for row in core.read(core.UP/"transverse-test.csv")}
    curved=core.read(core.UP/"curved-contrast.csv")
    rows=[]
    for scheme in ("original","adm"):
        values=cases(scheme,160,8,3)
        for row in curved:
            idx=key(row);seed,width,frac,channel=idx
            newton=float(row["full_newton"]);unit=abs(newton)*1e-6
            longitudinal=float(row["longitudinal"])
            discrepancy=(values[idx]-newton)/unit
            prediction=material[idx]/unit
            rows.append(dict(scheme=scheme,seed=seed,width=width,fraction=frac,channel=channel,
                             curved_minus_newton_ppm=discrepancy,mechanical_transverse_ppm=prediction,
                             minus_newton_and_transverse_ppm=discrepancy-prediction,
                             longitudinal_minus_full_newton_ppm=(longitudinal-newton)/unit))
    table("independent-newton.csv",rows)
    final=[row for row in rows if row["fraction"]==1.]
    for name in ("curved_minus_newton_ppm","mechanical_transverse_ppm","minus_newton_and_transverse_ppm","longitudinal_minus_full_newton_ppm"):
        vals=[row[name] for row in final];print(name,min(vals),max(vals))

if __name__=="__main__":main()

