from source import np,note,C
from binding import weak_well,particles
from variational import Metric,parts
from types import SimpleNamespace

def test():
    length=.4;extent=.1;scale=.015;kappa=2.;expansion=70.
    size=2048
    grid=np.linspace(0,length,size+1);step=grid[1]
    seed=SimpleNamespace(mass=C/kappa,log_a=np.array([-.1,0.,.1]),log_h=-np.array([-.1,0.,.1])+np.log(expansion/C),H=lambda a:expansion/(a*C))
    wave=np.exp(-grid**2/(2*scale**2)-.5j*expansion*grid**2/kappa)*(np.sqrt(.35)+1j*np.sqrt(.65/1.5)*(1.5-grid**2/scale**2))
    fade=np.clip((grid-2*extent)/extent,0,1);fade=fade**3*(10+fade*(-15+6*fade))
    wave=(1-fade)*wave+fade
    lab=SimpleNamespace(r=grid,L=length,h=step,n=size,psi=wave,seed=seed,target=1.,square_width=np.diff(grid**2),
                        stiffness=4*np.diff(grid**5)/(5*np.diff(grid**2)**2))
    omega=kappa/scale**2
    volume=np.diff(grid**3)/3
    _,bins,mass,right,*_=parts(grid,volume,step,size)
    load=np.r_[np.bincount(bins,mass-right),0.]+np.r_[0.,np.bincount(bins,right)]
    field=Metric(lab,1.,6*(omega/C)**2*load,{})
    exact=1.5*kappa*omega-.5*(extent*omega)**2
    populations=[]
    rows,pot=weak_well(lab,field,1.,extent,96,12,8,populations,nested=True)
    stats={}
    for row in rows:
        pop=[p for p in populations if p["wall"]==row["wall"]]
        error=max(abs(pop[0]["aperture_fraction"]-.35),abs(pop[1]["aperture_fraction"]-.65))
        assert error<1e-7 and abs(row["ground_energy_kms2"]/exact-1)<1e-9
        assert .99<row["nested_lower_fraction"]<=1+1e-10
        stats[row["wall"]]=dict(fractions_error=error,energy_relative=abs(row["ground_energy_kms2"]/exact-1),
                                 certified_fraction=row["nested_lower_fraction"])
    lab.dust={"dust":[grid,np.zeros_like(grid),volume]}
    points=particles(lab,field,1.,extent,pot)
    p=points[0]
    expected=(omega**2/(omega**2+expansion**2))**1.5
    deep=((omega**2*extent**2-1e4)/((omega**2+expansion**2)*extent**2))**1.5
    assert abs(p["particle_energy_negative"]-expected)<1e-10 and abs(p["particle_energy_deep"]-deep)<1e-10
    stats["classical"]=dict(negative_error=p["particle_energy_negative"]-expected,deep_error=p["particle_energy_deep"]-deep)
    return stats
if __name__=="__main__":
    stats=test();note("binding-checks.json",stats);print(stats)
