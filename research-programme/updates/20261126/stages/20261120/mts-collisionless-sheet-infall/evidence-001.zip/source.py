import os
import sys
import json
import csv
import io
from pathlib import Path
for key in ("OMP_NUM_THREADS","OPENBLAS_NUM_THREADS","MKL_NUM_THREADS","BLIS_NUM_THREADS","NUMEXPR_NUM_THREADS"):
    os.environ[key]="1"
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
OLD=HERE.parent/"mts-primordial-patch-infall-20261120"
sys.path.insert(0,str(OLD))
from seeds import digest, checked, obj, C, END, AI, TOL, np
from matched_hierarchy import prepare
from spectral import Independent
PIN="a9f7723564116720ba5bc03333239d8fc0f106a6c2f14ca052f94e822aee2467"
FILES=obj(checked(OLD/"seal.json",PIN))["files"]
for script in ("seeds.py","matched_hierarchy.py","spectral.py","collapse.py","linear_control.py","native_balance.py"):
    checked(OLD/script,FILES[script])

def guard():
    assert not any((directory/"STOP-REQUESTED").exists() for directory in (HERE,OLD,HERE.parent))
def write(name,content):
    guard()
    path=HERE/name
    if path.exists():assert path.read_bytes()==content,path
    else:
        with path.open("xb") as stream:stream.write(content)
def note(name,data):
    write(name,(json.dumps(data,sort_keys=True,indent=2,allow_nan=False)+"\n").encode())
def packet(name,**items):
    buffer=io.BytesIO();np.savez_compressed(buffer,**items);write(name,buffer.getvalue())
def table(name,rows):
    if not rows:raise ValueError(name)
    content=io.StringIO(newline="")
    writer=csv.DictWriter(content,rows[0].keys(),lineterminator="\n")
    writer.writeheader();writer.writerows(rows);write(name,content.getvalue().encode())
def read_npz(path):
    with np.load(path) as bank:return {key:bank[key] for key in bank.files}
def old_tag(model,spacing):
    option="-compensated" if model=="heavy" else ""
    return f"ind-{model}-anchorA-heavy-dx{spacing:g}-L24-n512-A2-v1-end0.9252{option}-radiation-off"
def init(model,spacing,box,method):
    guard()
    inputs=f"radiation-full-{model}-0.npz"
    checked(OLD/inputs,FILES[inputs])
    seed=prepare(model,0)[0]
    if method=="restart" and box==24 and spacing in (.0125,.00625):
        tag=old_tag(model,spacing)
        state=read_npz(checked(OLD/(tag+".npz"),FILES[tag+".npz"]))
        meta=obj(checked(OLD/(tag+".json"),FILES[tag+".json"]))
        assert float(state["a"])==meta["last"]["a"]<meta["first_caustic"]["estimated_a"]
        return seed,state
    tag=f"initial-{method}-{model}-d{spacing:g}-L{box:g}"
    path=HERE/(tag+".npz")
    if path.exists():return seed,read_npz(path)
    sphere=Independent(seed,spacing,box,2.,1.,"compensated" if model=="heavy" else "native")
    stop=.5 if model=="heavy" else 1/3
    epochs=sorted({AI,.04,1/11,.2,1/3,stop,*([.6] if model=="heavy" and method=="restart" else []),*([.5] if model=="cold" and method=="restart" else [])})
    last=AI
    for left,right in zip(epochs,epochs[1:]):
        count=int(np.ceil(512*np.log(right/left)));delta=np.log(right/left)/count
        for index in range(count):
            if index%64==0:guard()
            loga=np.log(left)+index*delta
            crossing=sphere.step(loga,delta)
            if crossing:break
            last=np.exp(loga+delta)
        if crossing:break
    assert (crossing is not None)==(method=="restart")
    state={"r":sphere.r,"a":last}
    for species,sheet in sphere.dust.items():
        for key in ("x","p","M"):state[species+"_"+key]=getattr(sheet,key)
    if sphere.psi is not None:state["psi"]=sphere.psi
    packet(path.name,**state)
    return seed,state
