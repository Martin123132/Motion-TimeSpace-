from source import init,HERE,read_npz,np,table
from variational import ActionSystem
from weak_operator import rates
from moments import moments,WIDTHS

def run(model):
    seed,_=init(model,.00625,24.,"restart")
    start=.6 if model=="heavy" else .4
    stop=start+.002
    tag=f"restart-{model}-h0.00625-n2048-L24-to{start:.6f}-sine-action"
    state=read_npz(HERE/(tag+".npz"))
    results=[]
    for steps in (16,32,64,128,256):
        lab=ActionSystem(seed,state);dt=np.log(stop/start)/steps
        def values(a):
            field=lab.source(a);vals=moments(lab,a,field)
            data={key:np.array([value[:,0],value[:,1],value[:,3]]).T for key,value in vals.items() if key!="wave"}
            if model=="heavy":
                _,mom,kin,grav=rates(lab,field,a);data["wave"]=np.array([mom,kin,grav]).T
            return data
        x0=values(start);prev=x0
        total={key:np.zeros(3) for key in prev};absolute={key:np.zeros(3) for key in prev}
        for idx in range(steps):
            a0=start*np.exp(idx*dt);a1=start*np.exp((idx+1)*dt)
            lab.advance(a0,a1);current=values(a1)
            for key in prev:
                old=prev[key][:,1:]/seed.H(a0);new=current[key][:,1:]/seed.H(a1)
                total[key]+=dt/2*(old+new).sum(axis=1)
                absolute[key]+=dt/2*(abs(old)+abs(new)).sum(axis=1)
            prev=current
        for key in prev:
            err=(prev[key][:,0]-x0[key][:,0]-total[key])/absolute[key]
            for idx,b in enumerate(WIDTHS[:,0]):
                results.append(dict(model=model,start=start,end=stop,steps=steps,species=key,width=b,defect=err[idx]))
    table("local-momentum-"+model+".csv",results)
if __name__=="__main__":
    for which in ("heavy","cold"):run(which)
