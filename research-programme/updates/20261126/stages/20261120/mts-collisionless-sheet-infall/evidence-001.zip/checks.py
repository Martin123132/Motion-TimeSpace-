from source import HERE, note, init, read_npz, C
from variational import np, parts, assemble_mass, Metric, ActionSystem
from sheet import deposit,local_streams,Field
from scipy.integrate import quad

def enclosed_test(x,dm,radius):
    total=0.
    for j,weight in enumerate(dm):
        delta=x[j+1]-x[j]
        cuts=[0.,1.]
        if delta:
            cuts.extend(point for edge in (-radius,radius) if 0<(point:=(edge-x[j])/delta)<1)
        cuts=sorted(cuts)
        for left,right in zip(cuts,cuts[1:]):
            if abs(x[j]+.5*(left+right)*delta)<radius:
                total+=quad(lambda para:weight*3*(j+para)**2/(3*j**2+3*j+1),left,right)[0]
    return total

def manufactured():
    x=np.array([0.,.67,-.45,.31,.95,1.])
    p=np.array([0.,.31,-.12,-.37,.29,0.]);dm=np.diff(np.arange(6.)**3)/3
    r=np.linspace(0,1,81);h=r[1];target=.4
    both=deposit(x,dm,h,len(r)-1)
    exact=np.array([enclosed_test(x,dm,rad) for rad in r])
    discrete=np.r_[0.,np.cumsum(both)]
    assert max(abs(discrete-exact))<2e-13
    idx,bins,mass,high,low,last=parts(x,dm,h,len(r)-1)
    np.testing.assert_allclose(np.bincount(bins,mass,minlength=len(r)-1),both,rtol=1e-13,atol=1e-14)
    count,density,velocity,disp=local_streams(x,p,dm,target,1.,1.)
    assert count==5 and disp>0
    eps=1e-6
    dr=(enclosed_test(x,dm,target+eps)-enclosed_test(x,dm,target-eps))/(2*eps)
    dt=(enclosed_test(x+eps*p,dm,target)-enclosed_test(x-eps*p,dm,target))/(2*eps)
    assert abs(dr/target**2/density-1)<1e-8 and abs(dt/(-target**2*density*velocity)-1)<1e-8
    system=type("TestGrid",(),{})()
    system.r=r;system.n=len(r)-1;system.h=h
    system.square_width=np.diff(r**2);system.stiffness=4*np.diff(r**5)/(5*system.square_width**2)
    vol=np.diff(r**3)/3
    _,bins,mass,high,*_=parts(r,vol,h,len(vol))
    load=np.r_[np.bincount(bins,mass-high),0.]+np.r_[0.,np.bincount(bins,high)]
    a=.59;metric=Metric(system,a,load,{})
    truth=(r*r-1)/(12*a)
    np.testing.assert_allclose(metric.potential,truth,atol=2e-14)
    query=np.r_[-.70123,-.06789,.10345,.68901]
    np.testing.assert_allclose(metric.acceleration(query),query/(6*a),atol=2e-13)
    volume=Field(r,vol,a)
    np.testing.assert_allclose(volume.potential,truth,atol=2e-14)
    np.testing.assert_allclose(volume.acceleration(query),query/(6*a),atol=2e-13)
    null=deposit(r,vol,h,len(vol))
    np.testing.assert_allclose(null,vol,atol=2e-15)
    return dict(fold_mass_max_absolute=max(abs(discrete-exact)),fold_streams=count,fold_density_fraction=dr/(target**2*density)-1,
                fold_flux_fraction=dt/(-target**2*density*velocity)-1,constant_source_max_error=max(abs(metric.potential-truth)))

def action_test():
    seed,_=init("heavy",.00625,24.,"restart")
    state=read_npz(HERE/"restart-heavy-h0.00625-n2048-L24-to0.600000-sine-action.npz")
    a=float(state["a"]);sys=ActionSystem(seed,state)
    x,p,dm=sys.dust["cdm"];start=x.copy();initial=sys.psi.copy()
    q=np.arange(len(x))*sys.h
    direction=q*np.exp(-(q/.9)**2)*np.cos(2*q);direction[-1]=0.
    taper=np.exp(-(sys.r/.11)**2);second=np.exp(-(sys.r/.36)**2)
    amplitude=sys.h*sys.r**2*abs(sys.psi)**2
    shape=taper-second*(amplitude@taper)/(amplitude@second)
    tangent=amplitude*shape;assert abs(sum(tangent))<1e-12
    base=sys.source(a)
    gravity=np.dot(base.derivative["cdm"],direction)
    expected_x=seed.coeff["cdm"]*gravity
    expected_wave=seed.coeff["wave"]*np.dot(base.potential,tangent)
    tests={}
    for eps in (1e-5,3e-6):
        x[:]=start+eps*direction;plus=sys.source(a)
        x[:]=start-eps*direction;minus=sys.source(a)
        dust=(plus.energy-minus.energy)/(2*eps)
        cross_wave=seed.coeff["wave"]*tangent@((plus.potential-minus.potential)/(2*eps))
        x[:]=start
        sys.psi[:]=initial*np.sqrt(1+eps*shape);plus=sys.source(a)
        sys.psi[:]=initial*np.sqrt(1-eps*shape);minus=sys.source(a)
        wave=(plus.energy-minus.energy)/(2*eps)
        cross_dust=seed.coeff["cdm"]*direction@((plus.derivative["cdm"]-minus.derivative["cdm"])/(2*eps))
        sys.psi[:]=initial
        err=[abs(dust/expected_x-1),abs(wave/expected_wave-1),abs(cross_wave/cross_dust-1)]
        assert max(err)<2e-5,err
        tests[str(eps)]=dict(dust=err[0],fixed_number_wave=err[1],mixed_reciprocity=err[2])
    mat,diag,off=sys.inertia["cdm"];acc=base.ordered["cdm"]
    prod=diag*acc;prod[:-1]+=off*acc[1:];prod[1:]+=off*acc[:-1]
    assert np.linalg.norm((prod-base.derivative["cdm"])[1:-1])/np.linalg.norm(prod[1:-1])<1e-13
    return tests
if __name__=="__main__":
    result=dict(analytic=manufactured(),variations=action_test())
    note("action-and-fold-checks.json",result);print(result)
