import argparse
from source import init, END, C, note, packet, table, guard, np
from sheet import System
from moments import moments,readout,WIDTHS

def split_state(state,factor):
    if factor==1:return state
    assert factor in (2,4)
    state=state.copy()
    for key in ("cdm","baryon"):
        old_mass=state[key+"_M"];old=np.arange(len(old_mass))
        labels=np.arange(factor*(len(old_mass)-1)+1)/factor
        for name in ("x","p"):
            state[key+"_"+name]=np.interp(labels,old,state[key+"_"+name])
        state[key+"_M"]=np.interp(labels**3,old.astype(float)**3,old_mass)
    return state

def run(model,spacing,steps,box=24.,method="restart",stop=END,mass_method="sine",action=False,continued=None,split=1,keep_knots=False):
    seed,state=init(model,spacing,box,method)
    if continued:
        from source import read_npz,HERE,obj
        state=read_npz(HERE/(continued+".npz"));parent=obj(HERE/(continued+".json"))
        assert parent["model"]==model and parent["spacing"]==spacing and parent["box"]==box
        assert float(state["a"])==parent["end"]
    else:state=split_state(state,split)
    start=float(state["a"]);assert start<stop
    if action:
        from variational import ActionSystem
        sys=ActionSystem(seed,state,mass_method)
    else:sys=System(seed,state,mass_method)
    tag=f"{method}-{model}-h{spacing:g}-n{steps}-L{box:g}-to{stop:.6f}"+("-sine" if mass_method=="sine" else "")
    if action:tag+="-action"
    if split!=1:tag+=f"-sheet{split}"
    if continued:tag+=f"-from{start:.6f}"
    epochs=sorted(set([start,stop]+[x for x in (.335,.34,.35,.4,.45,.50,.535,.54,.55,.56,.57,.58,.6,.65,.7,.75,.8,.85,.9) if start<x<stop]))
    if method=="overlap":
        from source import old_tag,obj,checked,FILES,OLD
        prior=old_tag(model,spacing)+".json";aa=obj(checked(OLD/prior,FILES[prior]))["last"]["a"]
        if start<aa<stop:epochs=sorted(set(epochs+[aa]))
    history=[];probes=[];budget=[];signals=[];events={}
    def read(a):
        field=sys.source(a)
        vals,rows=readout(sys,a,field)
        history.append(vals);probes.extend(rows)
    read(start)
    for lo,hi in zip(epochs,epochs[1:]):
        count=int(np.ceil(steps*np.log(hi/lo)))
        dtlog=np.log(hi/lo)/count
        before=moments(sys,lo,sys.source(lo));last=before;la=lo
        total={key:np.zeros((3,3)) for key in before}
        absolute={key:np.zeros((3,3)) for key in before}
        for i in range(count):
            if i%64==0:guard()
            a0=lo*np.exp(i*dtlog);a1=hi if i+1==count else lo*np.exp((i+1)*dtlog)
            sys.advance(a0,a1)
            for key,(x,p,mass) in sys.dust.items():
                if key not in events and np.any(x<0):events[key]=[a0,a1]
            if (i+1)%max(1,steps//1024)==0 or i+1==count:
                current=moments(sys,a1,sys.source(a1))
                delta=np.log(a1/la)/2
                for key,body in current.items():
                    values=body[:,1:]/seed.H(a1);old=last[key][:,1:]/seed.H(la)
                    total[key]+=delta*(old+values)
                    absolute[key]+=delta*(abs(old)+abs(values))
                last=current;la=a1
        for key in before:
            change=last[key][:,0]-before[key][:,0]
            for j,b in enumerate(WIDTHS[:,0]):
                stress,force,interpolated=total[key][j]
                denom=max(absolute[key][j,0]+absolute[key][j,1],1e-40)
                budget.append(dict(a0=lo,a1=hi,species=key,width=b,delta_moment=change[j],
                                   stress=stress,force=force,interpolated_force=interpolated,
                                   integral_abs_stress=absolute[key][j,0],integral_abs_force=absolute[key][j,1],
                                   signed_defect_over_work=(change[j]-stress-force)/denom,
                                   interpolated_defect_over_work=(change[j]-stress-interpolated)/denom))
        read(hi)
        if keep_knots and hi in (.55,.65,.7,.75,.8,.85,.9) and hi!=stop:
            checkpoint=tag+f"-epoch{hi:.4f}"
            packet(checkpoint+".npz",**sys.state(hi))
            note(checkpoint+".json",dict(model=model,spacing=spacing,steps=steps,box=box,start=start,
                                        end=hi,source_run=tag,last=history[-1]))
    packet(tag+".npz",**sys.state(stop))
    table(tag+"-history.csv",history);table(tag+"-apertures.csv",probes);table(tag+"-balance.csv",budget)
    note(tag+".json",dict(model=model,spacing=spacing,steps=steps,box=box,start=start,end=stop,origin_events=events,last=history[-1]))
    print(tag,"events",events,"radius",round(history[-1]["material_radius_Mpc"],6),"max travel cells",round(sys.maxtravel,4),flush=True)
if __name__=="__main__":
    parser=argparse.ArgumentParser()
    parser.add_argument("model",choices=["heavy","cold"])
    parser.add_argument("--spacing",type=float,default=.00625)
    parser.add_argument("--steps",type=int,default=1024)
    parser.add_argument("--box",type=float,default=24.)
    parser.add_argument("--method",choices=["overlap","restart"],default="restart")
    parser.add_argument("--stop",type=float,default=END)
    parser.add_argument("--mass-method",choices=["sine","cubic"],default="sine")
    parser.add_argument("--action",action="store_true")
    parser.add_argument("--continued")
    parser.add_argument("--split",type=int,default=1)
    parser.add_argument("--keep-knots",action="store_true")
    args=parser.parse_args();run(**vars(args))
