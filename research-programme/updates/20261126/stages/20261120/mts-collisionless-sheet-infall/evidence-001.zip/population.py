from source import HERE,read_npz,init,obj,table
from binding import weak_well,ActionSystem,System
import sys

def extract(tag):
    meta=obj(HERE/(tag+".json"));a=meta["end"]
    seed,_=init(meta["model"],meta["spacing"],meta["box"],"restart")
    state=read_npz(HERE/(tag+".npz"))
    lab=ActionSystem(seed,state) if "-action" in tag else System(seed,state)
    field=lab.source(a);populations=[];checks=[]
    for extent in (.1,.2):
        for count,order,factor in ((96,12,8),(160,12,12),(224,16,16)):
            block,_=weak_well(lab,field,a,extent,count,order,factor,populations,nested=True)
            checks.extend(block)
    if populations:table("occupations-"+tag+".csv",populations)
    table("refined-well-v2-"+tag+".csv",checks)
    print("matrix elements recoverable:",tag,flush=True)
if __name__=="__main__":
    for tag in sys.argv[1:]:extract(tag)
