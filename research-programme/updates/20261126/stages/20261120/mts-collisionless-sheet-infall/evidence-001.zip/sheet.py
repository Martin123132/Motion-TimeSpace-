from source import np, C
from scipy.fft import dst, idst, dct
from scipy.integrate import cumulative_simpson, simpson
from scipy.interpolate import CubicSpline
from scipy.optimize import brentq

def deposit(x,mass,h,n):
    dx=np.diff(x)
    lo=np.floor(np.minimum(x[:-1],x[1:])/h).astype(int)
    hi=np.ceil(np.maximum(x[:-1],x[1:])/h).astype(int)-1
    lo=np.clip(lo,-n,n-1);hi=np.maximum(lo,np.clip(hi,-n,n-1))
    count=hi-lo+1
    source=np.repeat(np.arange(len(dx)),count)
    cell=lo[source]+np.arange(len(source))-np.repeat(np.cumsum(count)-count,count)
    slope=dx[source]
    first=np.divide(cell*h-x[source],slope,out=np.zeros_like(slope),where=slope!=0)
    last=np.divide((cell+1)*h-x[source],slope,out=np.ones_like(slope),where=slope!=0)
    left=np.clip(np.minimum(first,last),0,1)
    right=np.clip(np.maximum(first,last),0,1)
    dq=right-left
    low=source+left
    frac=dq*(3*low**2+3*low*dq+dq*dq)/(3.*source**2+3*source+1)
    positive=np.where(cell<0,-cell-1,cell)
    return np.bincount(positive,weights=mass[source]*frac,minlength=n)

def local_streams(x,p,mass,radius,a,h):
    slope=np.diff(x)
    weights=[];vel=[]
    for orientation in (1,-1):
        u=np.divide(orientation*radius-x[:-1],slope,out=np.full_like(slope,-2.),where=slope!=0)
        pick=np.flatnonzero((u>=0)&(u<1))
        den=mass[pick]*3*(pick+u[pick])**2/((3.*pick**2+3*pick+1)*abs(slope[pick])*radius**2)
        weights.extend(den);vel.extend(orientation*(p[pick]+u[pick]*np.diff(p)[pick])/a)
    weights=np.array(weights);vel=np.array(vel)
    if not weights.size:return 0,0.,0.,0.
    mean=np.average(vel,weights=weights)
    return len(weights),weights.sum(),mean,np.average((vel-mean)**2,weights=weights)

class Field:
    def __init__(self,grid,cell_excess,a):
        self.h=grid[1];self.r=grid
        self.volume=np.diff(grid**3)/3
        self.left=np.r_[0.,np.cumsum(cell_excess)[:-1]]
        self.slope=cell_excess/(3*self.volume)
        self.mean=1/(2*a)
        low,high=grid[:-1],grid[1:]
        inverse=np.divide(self.h,low*high,out=np.zeros_like(low),where=low!=0)
        segments=(self.left*inverse+self.slope*(.5*self.h*(low+high)-low**3*inverse))*self.mean
        self.potential=np.r_[-np.cumsum(segments[::-1])[::-1],0.]
    def acceleration(self,position):
        rr=np.abs(position)
        which=np.minimum((rr/self.h).astype(int),len(self.left)-1)
        low=self.r[which]
        enclosed=self.left[which]+self.slope[which]*(rr-low)*(rr*rr+rr*low+low*low)
        return self.mean*np.sign(position)*np.divide(enclosed,rr*rr,out=np.zeros_like(rr),where=rr!=0)

class System:
    def __init__(self,seed,state,mass_method="sine"):
        self.seed=seed;self.r=state["r"];self.h=self.r[1];self.L=self.r[-1]
        self.n=len(self.r)-1;self.target=seed.radius**3/3
        self.dust={key:[state[key+"_x"].copy(),state[key+"_p"].copy(),np.diff(state[key+"_M"])] for key in ("cdm","baryon")}
        self.psi=state.get("psi")
        if self.psi is not None:self.psi=self.psi.copy()
        self.k=np.pi*np.arange(1,self.n)/self.L
        self.flux_weight=2*self.L*(-1.)**np.arange(1,self.n)/self.k
        self.mass_method=mass_method
        assert mass_method in ("sine","cubic")
        self.integrated_out=0.;self.maxmass=0.;self.maxtravel=0.
        self.volume=np.diff(self.r**3)/3
        self.start_mass=self.wave_excess()[-1] if self.psi is not None else 0.
    def wave_excess(self):
        weighted=self.r*self.psi
        if self.mass_method=="cubic":
            extend=np.r_[-weighted[1],weighted,2*self.L-weighted[-2]]
            center=(-extend[:-3]+9*extend[1:-2]+9*extend[2:-1]-extend[3:])/16
        else:
            coeff=dst(weighted[1:-1]-self.r[1:-1],type=1)
            center=(self.r[:-1]+.5*self.h)+idst(np.pad(2*coeff,(0,self.n)),type=1)[::2]
        ends=abs(weighted)**2-self.r**2
        excess=self.h/6*(ends[:-1]+ends[1:]+4*(abs(center)**2-(self.r[:-1]+.5*self.h)**2))
        return np.r_[0.,np.cumsum(excess)]
    def source(self,a):
        cell=np.zeros(self.n); self.enclosed={}
        for species,(x,p,mass) in self.dust.items():
            assert np.max(abs(x))<=self.L+1e-10
            placed=deposit(x,mass,self.h,self.n)
            self.maxmass=max(self.maxmass,abs(placed.sum()-mass.sum())/self.target)
            self.enclosed[species]=np.r_[0.,np.cumsum(placed)]
            cell+=self.seed.coeff[species]*(placed-self.volume)
        if self.psi is not None:
            excess=self.wave_excess()
            self.enclosed["wave"]=self.r**3/3+excess
            cell+=self.seed.coeff["wave"]*np.diff(excess)
        return Field(self.r,cell,a)
    def kick(self,field,dt):
        for x,p,mass in self.dust.values():
            force=field.acceleration(x);force[0]=force[-1]=0.
            p-=dt*force
        if self.psi is not None:self.psi*=np.exp(-1j*self.seed.mass*dt*field.potential)
    def advance(self,a0,a1):
        mid=np.sqrt(a0*a1)
        dt=np.log(a1/a0)/self.seed.H(mid)
        field=self.source(mid)
        self.kick(field,.5*dt)
        for x,p,mass in self.dust.values():
            move=dt*p/mid**2;x+=move
            self.maxtravel=max(self.maxtravel,np.max(abs(move))/self.h)
        if self.psi is not None:
            before=dst(self.r[1:-1]*(self.psi[1:-1]-1),type=1,norm="backward")/self.n
            after=before*np.exp(-.5j*self.k**2*dt/(self.seed.mass*mid**2))
            self.integrated_out+=self.flux_weight@(after-before).real
            self.psi[1:-1]=1+idst(after*self.n,type=1)/self.r[1:-1]
            self.psi[0]=1+self.k@after
        field=self.source(mid)
        self.kick(field,.5*dt)
    def wave_gradient(self):
        coeff=dst(self.r[1:-1]*(self.psi[1:-1]-1),type=1)/self.n
        radial_der=dct(np.r_[0.,.5*self.k*coeff,0.],type=1)
        deriv=np.r_[0j,(radial_der[1:]-(self.psi[1:]-1))/self.r[1:]]
        high=np.sum(abs(coeff[self.k>2*self.k[-1]/3])**2)/max(np.sum(abs(coeff)**2),1e-60)
        return deriv,high
    def state(self,a):
        state=dict(r=self.r,a=a)
        for name,(x,p,mass) in self.dust.items():
            state[name+"_x"]=x;state[name+"_p"]=p;state[name+"_M"]=np.r_[0.,np.cumsum(mass)]
        if self.psi is not None:state["psi"]=self.psi
        return state
