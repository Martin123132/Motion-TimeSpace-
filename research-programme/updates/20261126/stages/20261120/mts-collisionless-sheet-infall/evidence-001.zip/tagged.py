from source import HERE,init,obj,read_npz,guard,table,packet,np,END
from binding import basis,weak_well,hubble,particles
from variational import ActionSystem
from sheet import dst,idst,CubicSpline
import sys

class Traced(ActionSystem):
    def trace(self,name,a):
        extent=float(name)/1000
        bank={};field=self.source(a)
        weak_well(self,field,a,extent,160,12,12,capture=bank)
        radial=a*self.r[1:-1];inside=radial<extent
        projected=np.zeros(self.n-1,complex)
        _,matrix=basis(radial[inside],extent,160,"D")
        kappa=299792.458/self.seed.mass;hub=hubble(self.seed,a)[0]
        projected[inside]=np.sqrt(a)*np.exp(-.5j*hub*radial[inside]**2/kappa)*(matrix@(bank["coeffs"]@bank["amplitudes"]))
        return projected,np.vdot(bank["amplitudes"],bank["amplitudes"]).real
    def advance(self,left,right):
        self.mid=np.sqrt(left*right);self.first=True
        super().advance(left,right)
    def kick(self,field,half):
        self.tags*=np.exp(-1j*self.seed.mass*half*field.potential[1:-1])
        if self.first:
            coeff=dst(self.tags,type=1,axis=-1)
            self.tags=idst(coeff*np.exp(-1j*self.k**2*half/(self.seed.mass*self.mid**2)),type=1,axis=-1)
            self.first=False
        super().kick(field,half)

def tag_projection(sys,a,extent,which):
    bank={};field=sys.source(a)
    weak_well(sys,field,a,extent,160,12,12,capture=bank)
    rad=bank["radius"];hub=hubble(sys.seed,a)[0];kappa=299792.458/sys.seed.mass
    high=12;nn=high*sys.n
    coeff=dst(sys.tags[which],type=1)/sys.n
    curve=idst(nn*np.pad(coeff,(0,(high-1)*sys.n)),type=1)
    n=min(len(curve),int(np.ceil(extent/(a*sys.h/high)))+8)
    grid=np.arange(n+1)*(sys.h/high)
    local=CubicSpline(grid,np.r_[0j,curve[:n]])(rad/a)*np.exp(.5j*hub*rad**2/kappa)/np.sqrt(a)
    tag=bank["eigen"].T@(bank["weight"]*local)
    whole=bank["amplitudes"];rest=whole-tag
    norm=lambda vect:np.vdot(vect,vect).real
    cross=2*np.vdot(tag,rest).real
    return dict(tagged_negative=norm(tag),total_negative=norm(whole),complement_negative=norm(rest),
                interference=cross,coherent_sum_error=abs(norm(whole)-norm(tag)-norm(rest)-cross)/sys.target,
                tagged_inside=bank["weight"]@abs(local)**2)

def intersect(first,last,mass):
    accumulated=0.
    for j,initial in first.items():
        if j not in last:continue
        for x,y in initial:
            for l,r in last[j]:
                lo=max(x,l);hi=min(y,r)
                if hi<=lo:continue
                start=j+lo;width=hi-lo
                accumulated+=mass[j]*width*(3*start**2+3*start*width+width**2)/(3*j**2+3*j+1)
    return accumulated

def anchors(model,mode):
    if mode=="split":
        stem=f"restart-{model}-h0.00625-n2048-L24-to{END:.6f}-sine-action-sheet2"
        return stem+"-epoch0.6500", [(a,stem+f"-epoch{a:.4f}") for a in (.7,.75,.8,.85,.9)]+[(END,stem)],2048
    elif mode in ("fine","matched"):
        start=.6 if model=="heavy" else .4
        dx=.003125 if mode=="fine" else .00625
        steps=4096 if mode=="fine" else 2048
        stem=f"restart-{model}-h{dx:g}-n2048-L24-to{start:.6f}-sine-action"
        end=f"restart-{model}-h{dx:g}-n{steps}-L24-to{END:.6f}-sine-action-from{start:.6f}"
        return stem,[(END,end)],steps
    raise ValueError(mode)

def run(model,mode):
    initial_tag,checkpoints,steps=anchors(model,mode)
    meta=obj(HERE/(initial_tag+".json"))
    start=meta["end"];seed,_=init(model,meta["spacing"],meta["box"],"restart")
    sys=Traced(seed,read_npz(HERE/(initial_tag+".npz")))
    extents=(.1,.2)
    traces=[];cold=[]
    def capture_sheets(lab,a,extent):
        field=lab.source(a);_,pot=weak_well(lab,field,a,extent,48,8,4)
        labels={};observed=particles(lab,field,a,extent,pot,labels=labels)
        masses={row["species"]:row["actual_mass_over_target"]*lab.target*row["particle_energy_negative"] for row in observed}
        return labels,masses
    initial=[capture_sheets(sys,start,b) for b in extents]
    if model=="heavy":
        tagged=[sys.trace(extent*1000,start) for extent in extents]
        sys.tags=np.stack([v for v,m in tagged])
        tagmass=sys.h*np.sum(abs(sys.tags)**2,axis=-1)
        projmass=np.array([m for v,m in tagged])
    previous=start
    def record(lab,a,wave_error,geometry_error,do_cold=True):
        for which,ext in enumerate(extents):
            if model=="heavy":
                vals=tag_projection(lab,a,ext,which);nowmass=lab.h*np.vdot(lab.tags[which],lab.tags[which]).real
                traces.append(dict(a=a,kpc=ext*1000,tag_initial_mass_over_target=tagmass[which]/lab.target,
                    initial_embedding_error=tagmass[which]/projmass[which]-1,
                    norm_defect=nowmass/tagmass[which]-1,endpoint_return_fraction=vals["tagged_negative"]/tagmass[which],
                    endpoint_inside_fraction=vals["tagged_inside"]/tagmass[which],projection_over_actual=vals["tagged_negative"]/vals["total_negative"],
                    interference_over_actual=vals["interference"]/vals["total_negative"],complement_over_actual=vals["complement_negative"]/vals["total_negative"],
                    coherent_sum_error=vals["coherent_sum_error"],untagged_wave_replay_error=wave_error,dust_xp_replay_error=geometry_error))
            if do_cold:
                previous_labels,previous_masses=initial[which]
                labels,masses=capture_sheets(lab,a,ext)
                for key,(x,p,dm) in lab.dust.items():
                    stayed=intersect(previous_labels[key],labels[key],dm)
                    cold.append(dict(a=a,kpc=ext*1000,species=key,return_fraction=stayed/previous_masses[key],
                                     share_of_final_negative=stayed/masses[key],initial_negative_over_target=previous_masses[key]/lab.target,
                                     final_negative_over_target=masses[key]/lab.target))
    record(sys,start,0.,0.)
    for target,tag in checkpoints:
        guard()
        saved=read_npz(HERE/(tag+".npz"));assert abs(target-float(saved["a"]))<1e-13
        ref=ActionSystem(seed,saved)
        if model=="heavy":
            knots=sorted([previous,target]+[a for a in (.65,.7,.75,.8,.85,.9) if previous<a<target])
            for lo,hi in zip(knots,knots[1:]):
                count=int(np.ceil(steps*np.log(hi/lo)));delta=np.log(hi/lo)/count
                for i in range(count):
                    if i%64==0:guard()
                    sys.advance(lo*np.exp(i*delta),hi if i+1==count else lo*np.exp((i+1)*delta))
            err=np.linalg.norm((sys.psi-ref.psi)*sys.r)/np.linalg.norm(ref.psi*sys.r)
            dust=max(np.linalg.norm(sys.dust[key][i]-ref.dust[key][i])/max(np.linalg.norm(ref.dust[key][i]),1e-20)
                     for key in sys.dust for i in (0,1))
            record(sys,target,err,dust)
        else:record(ref,target,0.,0.)
        previous=target
    if traces:
        table(f"tag-wave-{mode}.csv",traces)
        packet(f"tag-wave-{mode}.npz",u=sys.tags,r=sys.r,a=previous,initial_a=start,initial_mass=tagmass)
    table(f"tag-particles-{model}-{mode}.csv",cold)
    print(model,mode,"completed",flush=True)
if __name__=="__main__":run(*sys.argv[1:])
