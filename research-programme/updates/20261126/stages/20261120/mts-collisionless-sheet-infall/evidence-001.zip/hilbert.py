"""Cycle-averaged radial Hilbert anisotropy and coherent fast tidal trace on the saved slice."""
from source import HERE,OLD,read_npz,obj,init,np,table,C
from binding import ActionSystem,System,particles
from sheet import dst,idst,dct,CubicSpline
from scipy.special import roots_legendre
from scipy.constants import parsec
import sys

def read(tag):
    meta=obj(HERE/(tag+".json"));a=meta["end"]
    seed,_=init(meta["model"],meta["spacing"],meta["box"],"restart")
    lab=ActionSystem(seed,read_npz(HERE/(tag+".npz"))) if "-action" in tag else System(seed,read_npz(HERE/(tag+".npz")))
    rows=[]
    for extent in (.025,.05,.1,.2):
        for order,over in ((8,4),(12,8),(16,16)):
            nodes,weights=roots_legendre(order)
            cuts=np.r_[lab.r[lab.r<extent/a],extent/a];half=np.diff(cuts)[:,None]/2
            rad=(cuts[:-1,None]+half*(1+nodes)).ravel()
            wt=(half*weights).ravel()
            mean_scale=(C/(1000*parsec))**2
            if lab.psi is not None:
                coeff=dst(lab.r[1:-1]*(lab.psi[1:-1]-1),type=1)/lab.n
                nn=lab.n*over;extended=np.pad(coeff,(0,nn-lab.n))
                sample=np.r_[0j,idst(nn*extended,type=1),0j]
                derivative=dct(np.r_[0j,.5*(np.arange(1,nn)*np.pi/lab.L)*extended,0j],type=1)
                size=min(nn,int(np.ceil(rad.max()*over/lab.h))+8)
                grid=np.arange(size+1)*lab.h/over
                wave=rad+CubicSpline(grid,sample[:size+1])(rad)
                grad=1+CubicSpline(grid,derivative[:size+1])(rad)-wave/rad
                mass=wt@abs(wave)**2;doublephase=wt@(wave**2)
                anisotropy=(wt@abs(grad)**2)/((seed.mass*a)**2*mass)
                coherence=abs(doublephase)/mass
                mean=seed.coeff["wave"]*mean_scale*1.5*mass/extent**3
                rows.append(dict(a=a,kpc=extent*1000,species="wave",order=order,mass_over_target=mass/lab.target,
                                 anisotropy_over_rest=anisotropy,coherence=coherence,
                                 coherent_trace_amplitude_s2=3*mean*coherence,mean_trace_s2=mean,
                                 coefficient_real=doublephase.real/mass,coefficient_imag=doublephase.imag/mass))
            for key,(x,p,dm) in lab.dust.items():
                total=0.;stress=0.;radius=extent/a
                ids=np.flatnonzero((np.minimum(x[:-1],x[1:])<radius)&(np.maximum(x[:-1],x[1:])>-radius))
                direction=np.diff(x)[ids]
                first=np.divide(-radius-x[ids],direction,out=np.zeros_like(direction),where=direction!=0)
                last=np.divide(radius-x[ids],direction,out=np.ones_like(direction),where=direction!=0)
                l=np.clip(np.minimum(first,last),0,1);u=np.clip(np.maximum(first,last),0,1)
                hh=(u-l)[:,None]/2;f=l[:,None]+hh*(1+nodes)
                measure=hh*weights*dm[ids,None]*3*(ids[:,None]+f)**2/(3*ids[:,None]**2+3*ids[:,None]+1)
                vel=(p[ids,None]+f*np.diff(p)[ids,None])/a
                total=measure.sum();stress=(measure*vel**2).sum()
                rows.append(dict(a=a,kpc=extent*1000,species=key,order=order,mass_over_target=total/lab.target,
                                 anisotropy_over_rest=stress/total,coherence="",coherent_trace_amplitude_s2="",
                                 mean_trace_s2=seed.coeff[key]*mean_scale*1.5*total/extent**3,
                                 coefficient_real="",coefficient_imag=""))
    table("hilbert-"+tag+".csv",rows)

if __name__=="__main__":
    for name in sys.argv[1:]:read(name)
