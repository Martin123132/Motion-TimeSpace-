"""Check the stage's saved states, per-branch physical controls and immutable replay ledger."""
from source import HERE, OLD, END, PIN, FILES, TOL, checked, digest, guard, note, np, obj, read_npz, table
from lmc_margins import audit
import csv
import sys

def rows(name):
    with (HERE/name).open(newline="",encoding="utf-8") as stream:
        return list(csv.DictReader(stream))

def verify():
    guard()
    assert audit()["closest_to_changing_under_tested_extension"]["margin_over_observed_change"] > 22000
    checked(OLD/"seal.json",PIN)
    for name,expected in FILES.items():checked(OLD/name,expected)
    analytic=obj(HERE/"action-and-fold-checks.json")
    assert analytic["analytic"]["fold_streams"]==5
    assert max(abs(value) for key,value in analytic["analytic"].items() if key!="fold_streams")<TOL
    assert all(max(rec.values())<TOL for rec in analytic["variations"].values())
    theory=obj(HERE/"binding-checks.json")
    assert all(theory[key]["certified_fraction"]>1-TOL for key in ("D","N"))
    summary=[]
    finals=[path for path in sorted(HERE.glob("restart-*-to0.925159-sine-action*.json")) if "-epoch" not in path.name]
    assert len(finals)==10
    for path in finals:
        tag=path.stem
        data=obj(path);model=data["model"];last=data["last"]
        state=read_npz(path.with_suffix(".npz"))
        assert data["end"]==float(state["a"])==END and all(np.isfinite(value).all() for value in state.values())
        assert all((np.diff(state[key+"_M"])>0).all() and last[key+"_reversed_labels"]>0 for key in ("cdm","baryon"))
        assert 0<=last["dust_misplaced_mass_over_patch"]<TOL
        if model=="heavy":assert abs(last["wave_budget_defect_over_patch"])<TOL
        classic=rows("particle-energy-r2-"+tag+".csv")
        hilbert=rows("hilbert-"+tag+".csv")
        for extent in (100.,200.):
            at=[row for row in classic if float(row["radius_kpc"])==extent]
            assert len(at)==2 and all(0<=float(row["particle_energy_negative"])<=1+1e-12 for row in at)
            species={row["species"]:float(row["particle_energy_negative"]) for row in at}
            measure=[row for row in hilbert if float(row["kpc"])==extent and row["order"]=="16"]
            assert len(measure)==len(species)+(model=="heavy")
            assert all(0<=float(row["anisotropy_over_rest"])<.01 and float(row["mean_trace_s2"])>0 for row in measure)
            base=dict(tag=tag,branch=model,radius_kpc=extent,material_radius_kpc=1000*last["material_radius_Mpc"],
                      cdm_negative=species["cdm"],baryon_negative=species["baryon"])
            if model=="heavy":
                well=rows("refined-well-v2-"+tag+".csv")
                pops=rows("occupations-"+tag+".csv")
                for wall in ("D","N"):
                    select=lambda row:float(row["radius_kpc"])==extent and row["wall"]==wall
                    result,=[row for row in well if select(row) and row["count"]=="224"]
                    modes=[row for row in pops if select(row) and row["basis"]=="224"]
                    projected=float(result["negative_projection"])
                    assert len(modes)==int(result["negative_levels"]) and 0<float(result["nested_lower_fraction"])<=projected<=1+1e-12
                    assert abs(sum(abs(complex(float(row["amplitude_real"]),float(row["amplitude_imag"])))**2 for row in modes)-projected)<1e-10
                    mom,=[row for row in measure if row["species"]=="wave"]
                    summary.append(dict(**base,wall=wall,wave_negative=projected,negative_witness=result["nested_lower_fraction"],
                                ground=modes[0]["aperture_fraction"],wave_anisotropy=mom["anisotropy_over_rest"],coherence=mom["coherence"]))
            else:summary.append(dict(**base,wall="",wave_negative="",negative_witness="",ground="",wave_anisotropy="",coherence=""))
    assert len(summary)==30
    table("score-summary.csv",summary)
    for model in ("heavy","cold"):
        local=[abs(float(row["defect"])) for row in rows("local-momentum-"+model+".csv") if row["steps"]=="256"]
        assert local and max(local)<TOL
    for mode in ("matched","fine","split"):
        traces=rows("tag-wave-"+mode+".csv")
        assert len(traces)==(14 if mode=="split" else 4)
        for row in traces:
            assert max(abs(float(row[key])) for key in ("norm_defect","coherent_sum_error","untagged_wave_replay_error","dust_xp_replay_error"))<1e-10
            assert 0<=float(row["endpoint_return_fraction"])<=float(row["endpoint_inside_fraction"])+TOL
        for model in ("heavy","cold"):
            classical=rows("tag-particles-"+model+"-"+mode+".csv")
            assert len(classical)==2*len(traces)
            assert all(0<=float(row["return_fraction"])<=1+1e-10 for row in classical)
        if mode=="split":assert float(traces[0]["a"])==.65 and float(classical[0]["a"])==.65
    assert len(rows("hilbert-cycle-check.csv"))==4 and all(max(abs(float(v)) for k,v in row.items() if k!="kpc")<TOL for row in rows("hilbert-cycle-check.csv"))
    assert not (HERE/"__pycache__").exists()
    files={p.name:digest(p) for p in sorted(HERE.iterdir()) if p.is_file() and p.name!="seal.json"}
    record=dict(predecessor_sha256=PIN,upstream_files_verified=len(FILES),final_snapshots=len(finals),score_rows=len(summary),files=files)
    if sys.argv[1:]==["seal"]:note("seal.json",record)
    assert obj(HERE/"seal.json")==record
    print(f"{len(files)} local files, {len(FILES)} predecessor files; seal {digest(HERE/'seal.json')}")

if __name__=="__main__":verify()
