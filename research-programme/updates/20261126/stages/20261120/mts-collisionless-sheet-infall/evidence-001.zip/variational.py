"""Common radial finite-element metric and its adjoint forces on wave and sheets."""
from sheet import System, np
from scipy.linalg import solve_banded

def integrals(label,first,last,dm):
    mid=(first+last)/2
    half=(last-first)/2
    base=label+mid
    scale=dm*(last-first)/(label*label+label+1/3)
    weight=scale*(base**2+half**2/3)
    centered=scale*(2*base*half**2/3)
    second=scale*(base**2*half**2/3+half**4/5)
    return weight,mid*weight+centered,mid*mid*weight+2*mid*centered+second

def parts(x,dm,h,n):
    diff=np.diff(x)
    lo=np.clip(np.floor(np.minimum(x[:-1],x[1:])/h).astype(int),-n,n-1)
    hi=np.maximum(lo,np.clip(np.ceil(np.maximum(x[:-1],x[1:])/h).astype(int)-1,-n,n-1))
    counts=1+hi-lo
    ids=np.repeat(np.arange(len(diff)),counts)
    cell=lo[ids]+np.arange(len(ids))-np.repeat(np.cumsum(counts)-counts,counts)
    slope=diff[ids]
    first=np.divide(cell*h-x[ids],slope,out=np.zeros_like(slope),where=slope!=0)
    last=np.divide((cell+1)*h-x[ids],slope,out=np.ones_like(slope),where=slope!=0)
    lower=np.clip(np.minimum(first,last),0,1)
    upper=np.clip(np.maximum(first,last),0,1)
    mu,one,two=integrals(ids,lower,upper,dm[ids])
    bin_id=np.where(cell<0,-cell-1,cell)
    low=bin_id*h
    denom=h*(2*low+h)
    xpos=x[ids]
    right=((xpos-low)*(xpos+low)*mu+2*xpos*slope*one+slope*slope*two)/denom
    left_moment=xpos*(mu-one)+slope*(one-two)
    right_moment=xpos*one+slope*two
    return ids,bin_id,mu,right,left_moment,right_moment

def assemble_mass(dm):
    labels=np.arange(len(dm))
    mass,one,two=integrals(labels,0.,1.,dm)
    diag=np.r_[mass-2*one+two,0.]+np.r_[0.,two]
    off=one-two
    mat=np.zeros((3,len(dm)-1))
    mat[1]=diag[1:-1]
    mat[0,1:]=off[1:-1];mat[2,:-1]=off[1:-1]
    return mat,diag,off

class Metric:
    def __init__(self,system,a,load,parts_by_species):
        self.h=system.h;self.n=system.n
        self.load=load
        increments=np.cumsum(load[:-1])/(2*a*system.stiffness)
        self.potential=np.r_[-np.cumsum(increments[::-1])[::-1],0.]
        self.factor=2*increments/system.square_width
        self.ordered={}
        self.derivative={}
        for key,(ids,bin_id,mu,right,low,high) in parts_by_species.items():
            n=len(system.dust[key][0])-1
            first=np.bincount(ids,weights=low*self.factor[bin_id],minlength=n)
            last=np.bincount(ids,weights=high*self.factor[bin_id],minlength=n)
            full=np.r_[first,0.]+np.r_[0.,last]
            self.derivative[key]=full
            self.ordered[key]=np.r_[0.,solve_banded((1,1),system.inertia[key][0],full[1:-1],check_finite=False),0.]
        self.energy=-a*np.dot(system.stiffness,increments**2)
    def acceleration(self,x):
        rad=np.abs(x);idx=np.clip((rad/self.h).astype(int),0,self.n-1)
        return self.factor[idx]*x

class ActionSystem(System):
    def __init__(self,seed,state,mass_method="sine"):
        super().__init__(seed,state,mass_method)
        low=self.r[:-1]
        self.square_width=self.h*(2*low+self.h)
        self.stiffness=4*(low**4*self.h+2*low**3*self.h**2+2*low**2*self.h**3+low*self.h**4+self.h**5/5)/self.square_width**2
        homogeneous=parts(self.r,self.volume,self.h,self.n)
        _,bins,mass,right,_,_=homogeneous
        self.base=self.load_vector(bins,mass,right)
        self.inertia={key:assemble_mass(item[2]) for key,item in self.dust.items()}
    def load_vector(self,bins,mass,right):
        return np.r_[np.bincount(bins,weights=mass-right,minlength=self.n),0.]+np.r_[0.,np.bincount(bins,weights=right,minlength=self.n)]
    def source(self,a):
        loads=np.zeros(self.n+1);by={};self.enclosed={}
        for key,(x,p,dm) in self.dust.items():
            assert np.max(np.abs(x))<=self.L+1e-10
            part=parts(x,dm,self.h,self.n);by[key]=part
            _,bins,mass,right,_,_=part
            nodal=self.load_vector(bins,mass,right)
            placed=np.bincount(bins,weights=mass,minlength=self.n)
            self.maxmass=max(self.maxmass,abs(placed.sum()-dm.sum())/self.target)
            self.enclosed[key]=np.r_[0.,np.cumsum(placed)]
            loads+=self.seed.coeff[key]*(nodal-self.base)
        if self.psi is not None:
            loads+=self.seed.coeff["wave"]*self.h*self.r**2*(abs(self.psi)**2-1)
            self.enclosed["wave"]=self.r**3/3+self.wave_excess()
        return Metric(self,a,loads,by)
    def kick(self,field,dt):
        for key,(x,p,dm) in self.dust.items():p-=dt*field.ordered[key]
        if self.psi is not None:self.psi*=np.exp(-1j*self.seed.mass*dt*field.potential)
