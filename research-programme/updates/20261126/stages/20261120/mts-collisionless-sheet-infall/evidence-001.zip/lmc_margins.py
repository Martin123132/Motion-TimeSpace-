"""Check the numerical margin of each original signed LMC force-band decision."""
from pathlib import Path
import csv
import hashlib
import json
import math

ROOT = Path(__file__).resolve().parent
BANK = ROOT.parent/"mts-lmc-fixed-occupation-axisymmetric-20261119"
SEAL = "a46d251285faaba640cea0288634284d6d3046a9693e934921a28936060c6f70"

def audit():
    seal = (BANK/"seal.json").read_bytes()
    assert hashlib.sha256(seal).hexdigest()==SEAL
    references = json.loads(seal)["files"]
    def load(name):
        raw = (BANK/name).read_bytes()
        assert hashlib.sha256(raw).hexdigest()==references[name]
        return list(csv.DictReader(raw.decode().splitlines()))
    index = lambda row, history: (row["tag"],row[history],row["R"],row["component"])
    edges = {index(row,"model"):row for row in load("edge-comparison.csv")}
    counts = {}
    locations = {}
    worst = None
    data = load("final-force-comparison.csv")
    assert len(edges)==48 and len(data)==192
    for row in data:
        edge = edges[index(row,"history")]
        sign = -1 if row["component"]=="polar" and float(row["z"])<0 else 1
        wave = row["background"]=="mts"
        before = float(row["combined"])
        delta = sign*(float(edge["extended"])-float(edge["reference"])) if wave else 0
        assert math.isclose(float(row["axis_response"]),sign*float(edge["reference"]) if wave else 0,abs_tol=1e-12)
        low,high = float(row["low"]),float(row["high"])
        def margin(force):
            return min(force-low,high-force)
        gap = margin(before)
        assert ((gap>=0)==(row["inside"]=="True")== (margin(before+delta)>=0))
        key=(row["tag"],row["history"],row["background"])
        counts[key]=counts.get(key,0)+int(gap>=0)
        if gap>=0:locations.setdefault(key,set()).add((float(row["R"]),float(row["z"]),row["component"]))
        if delta:
            ratio=abs(gap/delta)
            if worst is None or ratio<worst["margin_over_observed_change"]:
                worst=dict(ground=row["tag"],history=row["history"],R_kpc=float(row["R"]),z_kpc=float(row["z"]),
                           component=row["component"],margin_in_force_units=gap,change_in_force_units=delta,
                           margin_over_observed_change=ratio)
    assert len(counts)==24 and set(counts.values())=={2}
    assert all(value=={(8.3,1.5,"polar"),(8.3,-1.5,"polar")} for value in locations.values())
    return dict(signed_components=len(data),pairings=len(counts),passed_per_pair=2,closest_to_changing_under_tested_extension=worst)

if __name__=="__main__":print(json.dumps(audit(),indent=2))
