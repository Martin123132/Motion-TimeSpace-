from sheet import np, C, local_streams, simpson
from scipy.special import roots_legendre

WIDTHS=np.array([.1,.3,.6])[:,None]
POINTS,WEIGHTS=roots_legendre(4)
POINTS=(1+POINTS)/2
WEIGHTS=WEIGHTS/2

def window(r):
    scaled=(r[None,:]/WIDTHS)**2
    exp=np.exp(-.5*scaled)
    return r*exp,(1-scaled)*exp,exp*(-scaled**2+10*scaled-15)/WIDTHS**2

def moments(system,a,field,gradient=None):
    result={}
    for key,(x,p,dm) in system.dust.items():
        low=np.minimum(x[:-1],x[1:]);high=np.maximum(x[:-1],x[1:])
        ids=np.flatnonzero((low<6)&(high>-6))
        u=POINTS[None,:];label=ids[:,None]+u
        weight=(dm[ids,None]*WEIGHTS*(3*label**2)/(3*ids[:,None]**2+3*ids[:,None]+1)).ravel()
        node=x[ids,None]+u*np.diff(x)[ids,None];position=node.ravel()
        mom=(p[ids,None]+u*np.diff(p)[ids,None]).ravel()
        phi,der,_=window(position)
        gravity=field.acceleration(position)
        endpoint=field.ordered[key] if hasattr(field,"ordered") else field.acceleration(x)
        endpoint[0]=endpoint[-1]=0.
        interp=(endpoint[ids,None]+u*np.diff(endpoint)[ids,None]).ravel()
        result[key]=np.array([phi@(weight*mom),der@(weight*(mom/a)**2),
                              -phi@(weight*gravity),-phi@(weight*interp)]).T
    if system.psi is not None:
        r=system.r;psi=system.psi
        prime=system.wave_gradient()[0] if gradient is None else gradient
        phi,der,lap=window(r);factor=system.seed.mass
        integ=lambda val:simpson(val*r**2,dx=system.h,axis=-1)
        inertia=integ(phi*(psi.conj()*prime).imag/factor)
        stress=integ(der*abs(prime)**2-.25*lap*abs(psi)**2)/(a*factor)**2
        gravity=integ(-phi*abs(psi)**2*field.acceleration(r))
        result["wave"]=np.array([inertia,stress,gravity,gravity]).T
    return result

def readout(sys,a,field):
    target="wave" if sys.psi is not None else "cdm"
    enclosed=sys.enclosed[target]
    assert np.min(np.diff(enclosed))>=-1e-11
    quantile=np.interp(sys.target,enclosed,sys.r**3)**(1/3)
    vals=dict(a=float(a),material_radius_Mpc=float(a*quantile),maximum_travel_per_step_cells=sys.maxtravel,
              dust_misplaced_mass_over_patch=sys.maxmass)
    for key,(x,p,dm) in sys.dust.items():
        vals[key+"_reversed_labels"]=int(np.sum(np.diff(x)<0))
        vals[key+"_through_origin"]=int(np.sum(x<0))
    gradient=None
    if sys.psi is None:
        _,_,velocity,_=local_streams(*sys.dust["cdm"],quantile,a,sys.h)
    else:
        gradient,high=sys.wave_gradient()
        dens=abs(sys.psi)**2
        current=(sys.psi.conj()*gradient).imag/(a*sys.seed.mass)
        velocity=np.interp(quantile,sys.r,current)/np.interp(quantile,sys.r,dens)
        vals.update(wave_high_frequency_fraction=high,wall_out_over_patch=sys.integrated_out/sys.target,
                    wave_budget_defect_over_patch=(sys.wave_excess()[-1]-sys.start_mass+sys.integrated_out)/sys.target)
    vals["proper_speed_kms"]=C*(a*sys.seed.H(a)*quantile+velocity)
    rows=[]
    for kpc in (25,50,100):
        rad=kpc/1000/a
        for species,(x,p,dm) in sys.dust.items():
            nstreams,density,mean,variance=local_streams(x,p,dm,rad,a,sys.h)
            rows.append(dict(a=a,kpc=kpc,species=species,streams=nstreams,density=density,
                             peculiar_kms=C*mean,dispersion_kms=C*np.sqrt(variance),
                             enclosed_over_target=np.interp(rad**3,sys.r**3,sys.enclosed[species])/sys.target))
        if sys.psi is not None:
            rows.append(dict(a=a,kpc=kpc,species="wave",streams="",density=np.interp(rad,sys.r,dens),
                             peculiar_kms=C*np.interp(rad,sys.r,current)/np.interp(rad,sys.r,dens),dispersion_kms="",
                             enclosed_over_target=np.interp(rad**3,sys.r**3,sys.enclosed["wave"])/sys.target))
    return vals,rows
