from source import HERE,init,read_npz,table,obj,guard,C,np
from variational import ActionSystem
from sheet import System,dst,idst,CubicSpline
from scipy.linalg import eigh
from scipy.special import roots_legendre
from scipy.optimize import brentq
from functools import lru_cache

def metric_value(field,grid,position):
    rr=np.asarray(abs(position));cell=np.minimum((rr/grid[1]).astype(int),len(grid)-2)
    low=grid[cell];offset=rr-low
    if hasattr(field,"factor"):
        return field.potential[cell]+.5*field.factor[cell]*offset*(rr+low)
    inv=np.divide(offset,low*rr,out=np.zeros_like(rr),where=low!=0)
    return field.potential[cell]+field.mean*(field.left[cell]*inv+field.slope[cell]*(.5*offset*(rr+low)-low**3*inv))

@lru_cache(maxsize=None)
def frequencies(count,wall):
    if wall=="D":return np.pi*np.arange(1,count+1)
    assert wall=="N"
    roots=[brentq(lambda u:u*np.cos(u)-np.sin(u),i*np.pi,(i+.5)*np.pi,xtol=1e-14) for i in range(1,count)]
    return np.r_[0.,roots]

def basis(radius,extent,count,wall):
    roots=frequencies(count,wall)
    norm=np.sqrt(extent*.5*(1-np.sinc(2*roots/np.pi)))
    if wall=="N":norm[0]=1
    vals=np.sin(radius[:,None]*roots/extent)/norm
    if wall=="N":vals[:,0]=np.sqrt(3/extent**3)*radius
    return roots/extent,vals

def hubble(seed,a):
    idx=np.clip(np.searchsorted(seed.log_a,np.log(a))-1,0,len(seed.log_a)-2)
    slope=(seed.log_h[idx+1]-seed.log_h[idx])/(seed.log_a[idx+1]-seed.log_a[idx])
    hub=seed.H(a)*C
    return hub,hub**2*(1+slope)

def weak_well(system,field,a,extent,count,order,oversample,populations=None,nested=False,capture=None):
    hub,accel=hubble(system.seed,a)
    kappa=C/system.seed.mass
    origin=metric_value(field,system.r,extent/a)
    def pot(rad):
        return (metric_value(field,system.r,rad/a)-origin)*C**2-.5*accel*(rad*rad-extent*extent)
    pieces=np.unique(np.r_[np.linspace(0,extent,2*count+1),a*system.r[a*system.r<extent],extent])
    gl,weights=roots_legendre(order)
    half=np.diff(pieces)[:,None]/2
    rad=(pieces[:-1,None]+half*(1+gl)).ravel()
    weight=(half*weights).ravel()
    potential=pot(rad)
    if system.psi is not None:
        mesh=system.r;full=dst(mesh[1:-1]*(system.psi[1:-1]-1),type=1)
        count_pad=(oversample-1)*system.n
        finer=idst(np.pad(oversample*full,(0,count_pad)),type=1)
        index=min(len(finer)+1,int(np.ceil(extent/a/(system.h/oversample)))+8)
        fine_r=np.arange(index+1)*(system.h/oversample)
        physical=rad/a+CubicSpline(fine_r,np.r_[0j,finer[:index]])(rad/a)
        physical*=np.exp(.5j*hub*rad**2/kappa)/np.sqrt(a)
        mass=float(weight@abs(physical)**2)
        vector=physical/np.sqrt(mass)
    rows=[]
    for wall in ("D","N"):
        wave_number,bmat=basis(rad,extent,count,wall)
        kinetic=.5*(kappa*wave_number)**2
        gram=bmat.T@(weight[:,None]*bmat)
        assert np.max(abs(gram-np.eye(count)))<2e-10
        mat=bmat.T@((potential*weight)[:,None]*bmat)
        levels,states=eigh(mat+np.diag(kinetic))
        pivots=np.argmax(abs(states),axis=0)
        states*=np.sign(states[pivots,np.arange(count)])
        selected=levels< -5000
        lowest=levels[0]
        test=dict(radius_kpc=extent*1000,count=count,order=order,wall=wall,ground_energy_kms2=lowest,
                  negative_levels=int(sum(levels<0)),deep_levels=int(sum(selected)),central_depth_kms2=pot(0.))
        if system.psi is not None:
            amplitudes=states.T@(bmat.T@(weight*vector))
            if capture is not None and wall=="D":
                chosen=levels<0
                capture.update(radius=rad,weight=weight,eigen=bmat@states[:,chosen],coeffs=states[:,chosen],
                               amplitudes=amplitudes[chosen]*np.sqrt(mass),mass=mass)
            squared=abs(amplitudes)**2
            assert squared.sum()<=1+1e-9
            eigen=bmat@states[:,selected]
            res=potential[:,None]*eigen - bmat@(mat@states[:,selected])
            residuals=np.sqrt(weight@abs(res)**2)
            leakage=np.sqrt(np.sum((residuals/levels[selected])**2))
            lower=max(0.,np.sqrt(squared[selected].sum())-leakage)**2
            if nested:
                bounds=np.maximum(0,np.sqrt(np.cumsum(squared[selected]))-np.sqrt(np.cumsum((residuals/levels[selected])**2)))**2
                test["nested_lower_fraction"]=max(bounds,default=0.)
                test["witness_dimensions"]=int(1+np.argmax(bounds)) if bounds.size else 0
            if populations is not None:
                for index in np.flatnonzero(levels<0):
                    populations.append(dict(a=a,radius_kpc=extent*1000,wall=wall,basis=count,mode_index=index,
                                            energy_kms2=levels[index],amplitude_real=amplitudes[index].real,
                                            amplitude_imag=amplitudes[index].imag,aperture_fraction=squared[index],
                                            mass_over_primordial_target=squared[index]*mass/system.target))
            test.update(actual_mass_over_target=mass/system.target,represented_fraction=squared.sum(),
                        negative_projection=squared[levels<0].sum(),deep_projection=squared[selected].sum(),
                        positive_leakage_bound=leakage,bound_negative_fraction=lower,
                        bound_negative_mass_over_target=lower*mass/system.target)
        rows.append(test)
    return rows,pot

def cuts_below(energies,threshold):
    start,mid,end=energies-threshold
    quad=2*(start+end-2*mid);linear=end-start-quad
    cuts=[0.,1.]
    if abs(quad)<1e-10*max(1,abs(linear)):
        if abs(linear)>1e-15:cuts.append(-start/linear)
    else:
        disc=linear**2-4*quad*start
        if disc>=0:
            safe=-.5*(linear+np.copysign(np.sqrt(disc),linear))
            if safe!=0:cuts.extend([safe/quad,start/safe])
    knots=sorted({u for u in cuts if 0<=u<=1})
    return [(l,r) for l,r in zip(knots,knots[1:]) if start+(l+r)/2*(linear+(l+r)/2*quad)<0]

def particles(sys,field,a,extent,pot,labels=None):
    assert hasattr(field,"factor")
    hub=hubble(sys.seed,a)[0]
    records=[]
    for key,(x,p,dm) in sys.dust.items():
        total=neg=deep=0.
        if labels is not None:labels[key]={}
        for j in np.flatnonzero((np.minimum(x[:-1],x[1:])<extent/a)&(np.maximum(x[:-1],x[1:])>-extent/a)):
            left,right=x[j],x[j+1]
            div=right-left
            low=max(min(left,right),-extent/a);high=min(max(left,right),extent/a)
            if div==0:knots=[0.,1.]
            else:
                nodes=np.r_[low,sys.h*np.arange(int(np.floor(low/sys.h))+1,int(np.ceil(high/sys.h))),high]
                knots=np.unique(np.clip((nodes-left)/div,0,1))
            for first,last in zip(knots,knots[1:]):
                if last<=first:continue
                frac=np.array([first,(first+last)/2,last])
                signed=a*(left+frac*div)
                vel=hub*signed+C*(p[j]+frac*(p[j+1]-p[j]))/a
                energy=.5*vel**2+pot(abs(signed))
                def mass(u,v):
                    begin=j+first+u*(last-first);width=(v-u)*(last-first)
                    return dm[j]*width*(3*begin**2+3*begin*width+width**2)/(3*j*j+3*j+1)
                total+=mass(0.,1.)
                negative=cuts_below(energy,0.)
                neg+=sum(mass(l,r) for l,r in negative)
                if labels is not None and negative:
                    labels[key].setdefault(int(j),[]).extend((first+l*(last-first),first+r*(last-first)) for l,r in negative)
                deep+=sum(mass(l,r) for l,r in cuts_below(energy,-5000.))
        records.append(dict(radius_kpc=extent*1000,species=key,actual_mass_over_target=total/sys.target,
                            particle_energy_negative=neg/total,particle_energy_deep=deep/total))
    return records

def analyze(tag,settings=((48,8,4),(96,12,8)),classical=True):
    guard();meta=obj(HERE/(tag+".json"));a=meta["end"];seed,state=init(meta["model"],meta["spacing"],meta["box"],"restart")
    bank=read_npz(HERE/(tag+".npz"))
    sys=ActionSystem(seed,bank) if "-action" in tag else System(seed,bank)
    field=sys.source(a);rows=[];parts=[]
    for extent in (.1,.2):
        for count,order,over in settings:
            block,pot=weak_well(sys,field,a,extent,count,order,over)
            rows.extend(block)
        if classical and hasattr(field,"factor"):
            parts.extend(particles(sys,field,a,extent,pot))
    table("well-r2-"+tag+".csv",rows)
    if parts:table("particle-energy-r2-"+tag+".csv",parts)
    print(tag,"well evaluated",flush=True)

if __name__=="__main__":
    import sys
    for tag in sys.argv[1:]:analyze(tag)
