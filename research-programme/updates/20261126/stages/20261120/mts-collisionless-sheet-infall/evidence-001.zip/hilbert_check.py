"""Recover the rapid Ricci harmonic from the real canonical field on one folded state."""
from source import HERE, init, read_npz, table, np
from sheet import CubicSpline, idst, dst
from scipy.integrate import simpson
from scipy.constants import parsec
import csv

def check():
    tag = "restart-heavy-h0.00625-n2048-L24-to0.925159-sine-action-sheet2"
    state = read_npz(HERE / (tag + ".npz"))
    seed, _ = init("heavy", .00625, 24, "restart")
    records = list(csv.DictReader((HERE / ("hilbert-" + tag + ".csv")).open()))
    grid = state["r"]
    psi = state["psi"]
    scale = float(state["a"])
    num = len(grid) - 1
    extra = 16
    coeff = dst((grid * (psi-1))[1:-1], type=1)/num
    fine = np.linspace(0, grid[-1], extra*num+1)
    transformed = fine + np.r_[0j,idst(num*extra*np.pad(coeff,(0,num*(extra-1))),type=1),0j]
    interp = CubicSpline(fine[:2049], transformed[:2049])
    angles = np.arange(32)*2*np.pi/32
    rows = []
    for record in records:
        if record["species"] != "wave" or record["order"] != "16": continue
        extent = float(record["kpc"])/1000
        rad = np.linspace(0, extent/scale, 4097)
        envelope = interp(rad)
        proper_grad = interp(rad,1) - np.divide(envelope,rad,out=interp(rad,1).copy(),where=rad!=0)
        phase = np.exp(-1j*angles[:,None])
        displacement = np.real(phase*envelope)
        velocity = np.imag(phase*envelope)
        energy = simpson(velocity**2+displacement**2,x=rad,axis=1)
        active = simpson(4*velocity**2-2*displacement**2,x=rad,axis=1)/energy
        component = 2*np.mean((active-1)*np.exp(2j*angles))/(-3)
        gradient_stress = 2*np.mean(simpson(np.real(phase*proper_grad)**2,x=rad,axis=1)/energy)/(scale*seed.mass)**2
        reference = complex(float(record["coefficient_real"]),float(record["coefficient_imag"]))
        mean_trace = seed.coeff["wave"]*(299792.458/(1000*parsec))**2*1.5*energy.mean()/extent**3
        errors = dict(mean_error=abs(active.mean()-1),complex_error=abs(component-reference),
                      gradient_relative=abs(gradient_stress/float(record["anisotropy_over_rest"])-1),
                      mean_trace_relative=abs(mean_trace/float(record["mean_trace_s2"])-1))
        assert max(errors.values()) < 2e-5,errors
        rows.append(dict(kpc=record["kpc"],**errors))
    assert len(rows)==4
    table("hilbert-cycle-check.csv",rows)

if __name__=="__main__":check()
