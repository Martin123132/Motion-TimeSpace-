from campaign import AI,HERE,digest,np,table
from entry import Preparation,leggauss,spherical_jn
from model import collar

SHELLS=((38,42),(42,48),(48,60),(60,66))
def sample(lower,upper,order):
    edges=np.arange(lower,upper+.5,.5)
    unit,weights=leggauss(order)
    return (edges[:-1,None]+.25*(1+unit)).ravel(),np.tile(weights*.25,len(edges)-1)

def add(*terms):
    out={}
    for weight,raw in terms:
        for key,val in raw.items():out[key]=out.get(key,0.)+weight*val
    return out

def deriv(raw,modes):
    out={}
    for (order,degree),coef in raw.items():
        def push(key,value):out[key]=out.get(key,0.)+value
        if degree:push((order,degree-1),degree*coef)
        if order==0:push((1,degree),coef)
        else:
            push((1,degree-1),-2*coef);push((0,degree-2),6*coef);push((0,degree),-modes**2*coef)
    return out

def shift(raw,index):
    return {(order,degree+index):value for (order,degree),value in raw.items()}

def lap(raw,modes):
    first=deriv(raw,modes)
    return add((1.,deriv(first,modes)),(2.,shift(first,-1)),(-6.,shift(raw,-2)))

def value(raw,radius,modes):
    arg=radius[:,None]*modes
    basis=(spherical_jn(2,arg),modes*spherical_jn(2,arg,derivative=True))
    return sum(coef*radius[:,None]**degree*basis[order] for (order,degree),coef in raw.items())

def calculate(model,order):
    prep=Preparation(model,20,False,"probe")
    k=prep.chart.modes
    raw=prep.chart.fourier(0.)[:len(prep.coeff)]
    scalar=raw*prep.chart.selectors[0]
    tide=raw*prep.chart.selectors[1]
    r,w=sample(0,36,order)
    mu=(w*r**2*collar(r,"native36")[0])@(spherical_jn(0,r[:,None]*k)@(prep.coeff@scalar))/(2*AI)
    trans={(1,-2):1.}
    wave=lap(trans,k)
    composite=add((3*k**4,trans),(-2*k**2,wave),(1.,lap(wave,k)))
    eps=1/(4*(AI*prep.mass)**2) if model=="heavy" else 0.
    out=[]
    for lower,upper in SHELLS:
        r,w=sample(lower,upper,order)
        tide_d=(w/r)@value(trans,r,k)@tide.T
        ordinary=mu*(prep.coeff@tide_d)
        diff=-eps*mu*prep.coeff[prep.target]*((w/r)@value(composite,r,k)@tide[prep.target])
        out.append(dict(model=model,lower=lower,upper=upper,monopole_mu=mu,ordinary_second=ordinary,
                        wave_fourth=diff,radial_fourth_at_12=2*12*diff/(10*AI),polar_fourth_at_12=-1.5*12*diff/(10*AI)))
    return out

if __name__=="__main__":
    records=[]
    for model in ("heavy","cold"):
        check=calculate(model,6);fine=calculate(model,10)
        for coarse,actual in zip(check,fine):
            for key in ("monopole_mu","ordinary_second","wave_fourth"):
                assert abs(actual[key]-coarse[key])<=3e-10*abs(actual[key])
        records+=fine
    table("frozen-shell-law.csv",records)
    print(digest(HERE/"frozen-shell-law.csv"))
