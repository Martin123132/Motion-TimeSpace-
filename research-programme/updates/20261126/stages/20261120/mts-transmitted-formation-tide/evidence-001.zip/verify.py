from campaign import AI,BASE,DLOG,HERE,SEAL,SPAN,digest,files,guard,json,np,sys
from entry import rows
from retarded import RINGS,TIMES
from seed_scores import RANGE


def exactly(values,**kwargs):
    found=[row for row in values if all(row[key]==str(value) for key,value in kwargs.items())]
    assert len(found)==1,(kwargs,len(found))
    return found[0]

def validate():
    guard()
    assert digest(BASE/"seal.json")==SEAL and len(files)==60
    assert all(digest(BASE/name)==value for name,value in files.items())
    for name,value in (("frozen-shell-law.csv","6195d9341ad96bba288a0d9c1bb399230c82bb8d5079de2a83f71b0448de6003"),
                       ("retarded-shell-prediction.csv","13f21c52a8d6d8d09ae0ada3e0649021434421126f81a68efdfb9614a632a7a5"),
                       ("frozen-sign-reversal.csv","7ccfefef8ce58af02e8a8e8bf333b2d9484b0c1680837444cd2e59cd8b8d66b0")):
        assert digest(HERE/name)==value
    tables={p.stem:rows(p) for p in HERE.glob("*.csv")}
    for table in tables.values():
        assert table and all(None not in r and None not in r.values() for r in table)
    assert len(tables["signed-state-results"])==2*2*(len(TIMES)-1)*3*(9+10+10)
    assert len(tables["frozen-sign-reversal"])==2*len(TIMES)*3*(9+20)
    frozen={(r["model"],r["probe"],r["field"],r["channel"],float(r["x"])):r for r in tables["frozen-sign-reversal"]}
    for r in tables["signed-state-results"]:
        when=TIMES[np.argmin(abs(TIMES/DLOG-float(r["epoch"])))]
        match=frozen[r["model"],r["probe"],r["field"],r["channel"],when]
        assert float(r["second_order"])==float(match["overdensity" if r["sign"]=="1" else "underdensity"])
        if r["model"]=="cold" and r["channel"]=="difference":
            assert not float(r["physical"]) and not float(r["second_order"])
    coldzero=0;cases=0
    for path in sorted(HERE.glob("*.npz")):
        with np.load(path) as archive:
            for field in archive.files:
                raw=archive[field]
                if raw.dtype.kind in "fci":assert np.isfinite(raw).all(),(path.name,field)
            if "complete" in archive:
                assert archive["complete"].item() and archive["x"][-1]==SPAN*DLOG
                start=archive["seed"].item()
                parent=BASE/start if start in files else HERE/start
                assert digest(parent)==archive["seed_sha"].item()
                if archive["port"].item()!="free":
                    which=path.name.split("-")[2]
                    assert archive["port_source"].item()==digest(HERE/f"{archive['model'].item()}-L96-{which}-free.npz")
            if path.name.startswith("evolved-"):
                assert archive["prediction"].item()==digest(HERE/"retarded-shell-prediction.csv")
                np.testing.assert_array_equal(archive["x"],TIMES)
                if "-cold-" in path.name:
                    vals=archive["integrated"]
                    assert not np.any(vals[:,2]) and np.array_equal(vals[:,0],vals[:,1])
                    coldzero+=1
            cases+=1
    assert cases>=55 and coldzero>=4
    for model,ch in (("heavy","difference"),("cold","on")):
        subset=[r for r in tables["signed-state-results"] if r["epoch"]=="8.0" and r["model"]==model and r["channel"]==ch]
        for sign in (1,-1):
            for fld in ("radial","polar"):
                target=exactly(subset,field=fld,probe=1.35307765,sign=sign)
                assert abs(float(target["quadratic_relative"]))<.08*abs(float(target["linear_relative"]))
            q=exactly(subset,field="shell",probe="36-96",sign=sign)
            assert abs(float(q["quadratic_relative"]))<2e-5
    for r in tables["elliptic-shell-check"]:
        assert abs(float(r["normalized_to_shell"] or 0))<2e-5
    art=tables["constant-gradient-control"]
    assert len(art)==24 and all(not float(r["initial_spurious_second"]) for r in art if r["operator"]=="balanced")
    assert all(float(r["initial_spurious_second"]) for r in art if r["operator"]=="raw")
    start=tables["balanced-startup-checks"]
    raw=tables["startup-checks"]
    for lower in (42,48):
        criteria=dict(model="heavy",edge=96,rate=4,lower=lower,field="wave_fourth")
        assert abs(float(exactly(start,**criteria)["early_relative"]))<2e-5
        assert abs(float(exactly(raw,**criteria)["early_relative"]))>1
    assert any(abs(float(r["early_relative"]))>2e-5 for r in start if r["field"]=="wave_fourth" and r["early_relative"])
    transfer=tables["force-decomposition"]
    for field in ("radial","polar"):
        for model,ch in (("cold","on"),("heavy","difference")):
            row=exactly(transfer,model=model,steps=176,case=f"{model}-L36-t176-full",epoch=8.,radius=36.,field=field,channel=ch)
            assert abs(float(row["corrected_on_host_scale"]))<.001
    rel=tables["retarded-vs-live"]
    for lower,upper in ((42,48),(48,60),(60,66),(48,72),(72,96)):
        ref=exactly(rel,model="heavy",edge=120,rate=4,steps=176,lower=lower,upper=upper,channel="difference",epoch=8.)
        assert abs(float(ref["relative"]))<2e-5
    bad=exactly(rel,model="heavy",edge=120,rate=4,steps=176,lower=36,upper=96,channel="difference",epoch=8.)
    assert abs(float(bad["relative"]))>.7
    for r in tables["physical-relative-acceleration"]:
        assert float(r["tidal_zz_s_minus2"])==-2*float(r["tidal_xx_s_minus2"]) and r["tidal_yy_s_minus2"]==r["tidal_xx_s_minus2"]
    for r in tables["independent-resolution"]:
        if r["model"]=="heavy" and r["sign"]=="-1" and r["probe"]=="1.35307765" and r["epoch"]=="8.0" and r["channel"]=="difference":
            assert abs(float(r["forecast_relative"]))<.002 and abs(float(r["numerical_relative"]))<2e-5
    for name in ("PROTOCOL.md","DERIVATION.md","COLLAR-TEST.md","SECOND-VARIATION.md","RESULTS.md","REPLAY.md"):
        assert (HERE/name).is_file()
    for path in HERE.iterdir():
        assert path.is_file() and path.suffix in (".py",".npz",".csv",".md",".json"),path
        if path.suffix==".py":compile(path.read_bytes(),str(path),"exec")
    return dict(files={p.name:digest(p) for p in sorted(HERE.iterdir()) if p.name!="seal.json"},
                pinned_parent=SEAL,parent_files=len(files),numerical_packets=cases,csv_rows={k:len(v) for k,v in tables.items()})

if __name__=="__main__":
    result=validate()
    seal=HERE/"seal.json"
    if sys.argv[1:]==["--seal"]:
        with seal.open("x",encoding="utf8",newline="\n") as stream:
            json.dump(result,stream,indent=2,sort_keys=True);stream.write("\n")
    else:assert sys.argv[1:]==[] and json.loads(seal.read_bytes())==result
    print("Verified",len(result["files"]),"local files,",result["numerical_packets"],"packets,",result["parent_files"],"parent files; seal",digest(seal))
