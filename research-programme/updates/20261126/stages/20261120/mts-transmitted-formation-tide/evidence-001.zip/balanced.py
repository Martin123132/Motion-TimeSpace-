"""Evaluate the same weak perturbation equations in excess-density variables."""
from campaign import np
from native_run import Native


class BalancedNative(Native):
    def rates(self,state,time):
        p=self.patch;m=self.mesh
        mono,d,w=state
        hub,a=p.coeff(time)
        md,num,u=m.monopole(mono,p.p.coeff,p.j,p.p.mass,hub,a,p.wave)
        contrast=m.grid(mono[0]/m.r[1:])
        contrast[...,0]=np.einsum("si,i->s",m.grid(mono[0])[...,m.elem[0]],m.der[0])
        den,phase,vprime,dlap=self.data(time)
        src=np.einsum("s,xsi->xi",p.p.coeff,d)/(2*a)
        phi=m.potential(src)
        dn=m.div_flux(num,u,d,w,True)
        current=contrast[:,m.elem]*vprime[...,m.elem]+u[:,m.elem]*den[...,m.elem]
        extra=m.gather((m.radw*current)@m.der+6*m.qw*contrast[:,m.elem]*phase[...,m.elem])[...,1:]
        extra[...,-1]-=m.edge**2*current[...,-1,-1]
        dn+=extra/m.m
        vr=-hub*w-phi[:,None,:]-m.gather(m.radw*u[:,m.elem]*(m.quad(w)@m.der.T+vprime[...,m.elem]))[...,1:]/m.m
        if p.wave:
            j=p.j
            nn=num[j]
            local=contrast[j,m.elem]
            ngrad=((local-local[:,:1])@m.der.T)/nn[m.elem]
            loc=d[[0,2],j].copy();loc[1]+=d[1,j]
            native=den[[0,2],j].copy();native[1]+=den[1,j]
            lap=dlap[[0,2],j,1:].copy();lap[1]+=dlap[1,j,1:]
            flux=native[:,m.elem]*ngrad
            added=m.gather((m.radw*flux)@m.der)[...,1:]
            added[...,-1]-=m.edge**2*flux[...,-1,-1]
            q=-m.stiffness_apply(nn,loc/nn[1:],True)/nn[1:]-(contrast[j,1:]/nn[1:])*lap+added/(nn[1:]*m.m)
            vr[[0,2],j]+=q/(4*(a*p.p.mass)**2)
        return md,dn/hub,vr/hub
