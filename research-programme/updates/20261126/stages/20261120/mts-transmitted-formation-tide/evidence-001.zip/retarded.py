"""Far-environment response from the native cosmological state and the enclosed launch mass."""
from campaign import AI,DLOG,HERE,SPAN,digest,guard,np,pack,table
from model import Patch
from native_run import Reference
from shell_forecast import SHELLS,lap,sample,value
from entry import rows
from scipy.integrate import solve_ivp

RINGS=(*SHELLS,(36,48),(48,72),(72,96),(36,96))
ORDER=3
TIMES=np.unique(np.r_[0.,.000125,.00025,.0005,.001,.002,.004,.008,DLOG*np.arange(4,4*SPAN+1)/4])

def kernels(modes,degree):
    k0=[];k1=[]
    forms=[{(1,-2):1.}]
    for index in range(2*ORDER+1):forms.append(lap(forms[-1],modes))
    for lo,hi in RINGS:
        r,weights=sample(lo,hi,degree);weights=weights/r
        integrated=np.stack([weights@value(item,r,modes) for item in forms])
        k0.append(integrated[::2])
        k1.append(integrated[1::2]-integrated[::2]*modes**2)
    return np.array(k0).transpose(1,0,2),np.array(k1).transpose(1,0,2)

def predict(model):
    guard()
    p=Patch(model,36,72)
    ref=Reference(p,DLOG*SPAN)
    ref0,ref1=kernels(p.k,8)
    low0,low1=kernels(p.k,6)
    for high,low in ((ref0,low0),(ref1,low1)):
        assert np.max(np.linalg.norm(high-low,axis=-1)/np.linalg.norm(high,axis=-1))<3e-10
    mu=float(next(row["monopole_mu"] for row in rows(HERE/"frozen-shell-law.csv") if row["model"]==model))
    shape=(2,ORDER+1,ORDER+1,3,p.count,len(RINGS))
    def unpack(raw):return raw[2:].reshape(shape)
    def rhs(time,raw):
        hub,a=p.coeff(time)
        mass,speed=raw[:2]
        den,vel=ref.solution(time)*ref.weight
        base=mass/(2*a)*np.einsum("jlk,csk->jcsl",ref0,den)-speed*np.einsum("jlk,csk->jcsl",ref1,vel)
        field,first=unpack(raw)
        accel=np.broadcast_to(np.einsum("s,ijcsl->ijcl",p.p.coeff,field)[:,:,:,None,:]/(2*a),first.shape).copy()
        accel-=hub*first
        accel[0]+=base
        if p.wave:
            for order in range(1,ORDER+1):
                forcing=-field[order-1,1:ORDER+2-order,0,p.j]/(4*(a*p.p.mass)**2)
                accel[order,:ORDER+1-order,0,p.j]+=forcing
                accel[order,:ORDER+1-order,2,p.j]+=forcing
        return np.r_[p.p.coeff.sum()*speed,mass/(2*a)-hub*speed,np.stack((first,accel)).ravel()]/hub
    initial=np.r_[2*AI*mu,0.,np.zeros(shape).ravel()]
    sol=solve_ivp(rhs,(0,DLOG*SPAN),initial,method="DOP853",rtol=2e-12,atol=1e-47,t_eval=TIMES,max_step=DLOG/8)
    assert sol.success and np.isfinite(sol.y).all()
    evolved=sol.y[2:].reshape((*shape,-1))[0,:,0]
    sums=np.einsum("s,ocslx->oclx",p.p.coeff,evolved)
    assert model!="cold" or not np.any(sums[:,2])
    pack("retarded-"+model+".npz",x=sol.t,mu=mu,mass=sol.y[0],u=sol.y[1],terms=sums,shells=RINGS,k=p.k)
    return sums

if __name__=="__main__":
    result=[]
    for model in ("heavy","cold"):
        sums=predict(model)
        for ring,(lower,upper) in enumerate(RINGS):
            for tick,time in enumerate(TIMES):
                for channel,key in enumerate(("on","off","difference")):
                    terms=sums[:,channel,ring,tick]
                    result.append(dict(model=model,lower=lower,upper=upper,x=time,channel=key,base=terms[0],
                                       first=terms[1],second=terms[2],third=terms[3],total=sum(terms)))
    table("retarded-shell-prediction.csv",result)
    print(digest(HERE/"retarded-shell-prediction.csv"),flush=True)
