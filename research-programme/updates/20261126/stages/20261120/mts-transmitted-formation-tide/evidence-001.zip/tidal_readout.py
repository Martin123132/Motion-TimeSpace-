from campaign import AI,DLOG,HERE,SPAN,np,table
from outer_history import RINGS,name
from scipy.constants import c,parsec

def main():
    results=[]
    for model in ("heavy","cold"):
        with np.load(HERE/name(model,120,4,176)) as data,np.load(HERE/f"retarded-{model}.npz") as pred:
            sources=data["integrated"].sum(axis=2)
            for tick,x in enumerate(data["x"][1:],1):
                scale=AI*np.exp(x)
                for loc,(lo,hi) in enumerate(RINGS):
                    for ch,key in enumerate(("on","off","difference")):
                        for kind,source in (("live",sources[tick,ch,loc]),("far_law",pred["terms"][:,ch,loc,tick].sum())):
                            zz=c**2*source/(5*scale**3*(1e6*parsec)**2)
                            xx=-zz/2
                            assert xx+xx+zz==0.
                            results.append(dict(model=model,channel=key,from_source=kind,epoch=x/DLOG,z=1/scale-1,
                                                lower_Mpc=lo,upper_Mpc=hi,tidal_zz_s_minus2=zz,
                                                tidal_xx_s_minus2=xx,tidal_yy_s_minus2=xx,axial_per_physical_kpc_m_s2=zz*(1e3*parsec)))
    table("physical-relative-acceleration.csv",results)

if __name__=="__main__":main()
