"""Restart the native two-control calculation and transmit independently measured boundary data."""
import csv
import hashlib
import io
import json
import os
import sys
from pathlib import Path

HERE=Path(__file__).resolve().parent
BASE=HERE.parent/"mts-matched-matter-exterior-20261120"
SEAL="0e2808c6fe15694b74433e74bf0936257ecc654f6f5e0bd1a74a07c232f19b81"
def digest(path):
    with path.open("rb") as stream:return hashlib.file_digest(stream,"sha256").hexdigest()
assert digest(BASE/"seal.json")==SEAL
files=json.loads((BASE/"seal.json").read_bytes())["files"]
for key in ("entry.py","mesh.py","model.py","native_forecast.py","native_run.py"):
    assert digest(BASE/key)==files[key],key
sys.path.insert(0,str(BASE))
from entry import AI,DLOG,guard as parent_guard,np
from native_run import EARLY,Native,Reference
from scipy.integrate import solve_ivp
from scipy.interpolate import CubicSpline

CUTS=(36,48,72)
SPAN=8
NAMES=("mono","density","velocity")
def guard():
    parent_guard()
    assert not (HERE/"STOP-REQUESTED").exists()
def put(name,data):
    guard()
    path=HERE/name
    if path.exists():assert path.read_bytes()==data,name
    else:
        partial=path.with_suffix(path.suffix+".partial")
        with partial.open("xb") as stream:stream.write(data)
        partial.rename(path)
def pack(name,**fields):
    stream=io.BytesIO()
    np.savez_compressed(stream,**fields)
    put(name,stream.getvalue())
def table(name,records):
    stream=io.StringIO(newline="")
    writer=csv.DictWriter(stream,fieldnames=list(records[0]),lineterminator="\n")
    writer.writeheader();writer.writerows(records)
    put(name,stream.getvalue().encode("ascii"))
def path_for(model,edge,steps,port):
    return HERE/f"{model}-L{edge}-t{steps}-{port}.npz"


def reference(p,initial):
    ref=Reference.__new__(Reference)
    ref.p=p;ref.k=p.k;ref.weight=p.p.chart.selectors[1];ref.stop=DLOG*SPAN
    assert p.p.chart.times.min()<=0 and p.p.chart.times.max()>ref.stop
    def rhs(time,raw):
        den,vel=raw.reshape(initial.shape)
        hub,a=p.coeff(time)
        force=-vel-ref.potential(den,time)[:,None,:]/hub
        if p.wave:
            force[[0,2],p.j]-=p.k**2*np.stack((den[0,p.j],den[1,p.j]+den[2,p.j]))/(4*(a*p.p.mass)**2*hub)
        return np.stack((vel*p.k**2/hub,force)).ravel()
    solution=solve_ivp(rhs,(DLOG,ref.stop),initial.ravel(),method="DOP853",rtol=3e-13,atol=1e-21,max_step=DLOG/12,dense_output=True)
    assert solution.success
    ref.solution=lambda t:solution.sol(t).reshape(initial.shape)
    return ref


def initialize(branch,model,edge):
    start_name=f"native-{model}-L{edge}-n{4*edge}-u0-t1-native36.npz"
    if start_name in files:
        source=BASE/start_name
        assert digest(source)==files[start_name]
    else:
        source=HERE/("new-start-"+start_name)
        if not source.exists():
            data=branch.run(epochs=EARLY)
            pack(source.name,**data)
    with np.load(source) as packet:
        assert np.array_equal(packet["modes"],branch.patch.k) and packet["epochs"][-1]==DLOG
        state=tuple(packet[key] for key in NAMES)
        ref_initial=packet["ref_end"]
        np.testing.assert_allclose(branch.ref.solution(DLOG),ref_initial,atol=1e-22,rtol=1e-11)
        np.testing.assert_allclose(branch.observe(state,DLOG),packet["trace"][-1],atol=1e-28,rtol=2e-10)
    branch.ref=reference(branch.patch,ref_initial)
    branch.cache.clear()
    return state,source


class Ports:
    def __init__(self,model,edge,size,steps,kind):
        self.kind=kind
        self.path=path_for(model,96,steps,"free")
        with np.load(self.path) as data:
            index=list(data["cuts"]).index(edge)
            times=data["port_times"]
            self.curves={key:CubicSpline(times,data["port_"+key][:,index],axis=0,extrapolate=False)
                         for key in ("outside","zero",*NAMES)}
            self.start=tuple(data["start_"+key][...,:size] for key in NAMES)
        self.edge=edge

    def apply_state(self,state,time):
        if self.kind=="full":
            return tuple(np.concatenate((field[...,:-1],self.curves[key](time)[...,None]),axis=-1)
                         for key,field in zip(NAMES,state))
        return state

    def rhs(self,branch,state,time):
        state=self.apply_state(state,time)
        fields=branch.rates(state,time)
        if self.kind!="restrict":
            hub,a=branch.patch.coeff(time)
            radius=branch.mesh.r[1:]
            fields[2][:]+=self.curves["outside"](time)[:,None,None]*radius**2/(10*a*hub)
            fields[0][1]+=self.curves["zero"](time)*radius/(2*a*hub)
        if self.kind=="full":
            for key,field in zip(NAMES,fields):
                field[...,-1]=self.curves[key](time,1)
        return fields


def run(model,edge,steps=176,kind="free"):
    guard()
    dest=path_for(model,edge,steps,kind)
    if dest.exists():
        with np.load(dest) as data:
            assert data["complete"].item() and data["x"][-1]==SPAN*DLOG and np.isfinite(data["trace"]).all()
        return
    branch=Native(model,edge,4*edge,False,"native36")
    p=branch.patch;mesh=branch.mesh
    state,seed=initialize(branch,model,edge)
    ports=None if kind=="free" else Ports(model,edge,mesh.size,steps,kind)
    if ports is not None:state=ports.start
    retained={key:value.copy() for key,value in zip(NAMES,state)}
    rhs=branch.rates if ports is None else lambda st,time:ports.rhs(branch,st,time)
    cuts=[cut for cut in CUTS if cut<=edge]
    boundaries=[np.where(mesh.r==cut)[0].item()-1 for cut in cuts]
    region=[]
    for cut in cuts:
        il=int(round(cut/mesh.h))
        local=np.zeros_like(mesh.loc);local[il:]=mesh.qw/mesh.loc[il:]
        q2=mesh.gather(local)[1:]
        local[il:]=mesh.qw
        region.append((q2,mesh.gather(local)[1:]))
    q2,q0=np.stack(region).transpose(1,0,2)
    x=[];traces=[];port_times=[]
    series={key:[] for key in ("outside","zero",*NAMES)}
    def snapshot(st,time,tick):
        if tick%(steps//4)==0:
            x.append(time);traces.append(branch.observe(st,time))
        if tick%4==0:
            port_times.append(time)
            source=np.einsum("s,xsi->xi",p.p.coeff,st[1])
            series["outside"].append((source@q2.T).T)
            series["zero"].append(q0@(p.p.coeff@st[0][0]))
            for key,val in zip(NAMES,st):
                series[key].append(np.moveaxis(val[...,boundaries],-1,0))
    assert steps%16==0
    step=DLOG/steps
    end_tick=(SPAN-1)*steps
    for tick in range(end_tick+1):
        now=DLOG*(1+tick/steps)
        if ports is not None:state=ports.apply_state(state,now)
        snapshot(state,now,tick)
        if tick==end_tick:break
        if tick%32==0:guard()
        def shift(rate,scale):return tuple(v+scale*d for v,d in zip(state,rate))
        mid=DLOG*(1+(tick+.5)/steps)
        later=DLOG*(1+(tick+1)/steps)
        one=rhs(state,now)
        two=rhs(shift(one,step/2),mid)
        three=rhs(shift(two,step/2),mid)
        four=rhs(shift(three,step),later)
        state=tuple(v+step/6*(d1+2*d2+2*d3+d4) for v,d1,d2,d3,d4 in zip(state,one,two,three,four))
    assert np.isfinite(traces).all()
    if model=="cold":
        assert not np.any(np.asarray(traces)[:,:,2]) and np.array_equal(np.asarray(traces)[:,:,0],np.asarray(traces)[:,:,1])
    pack(dest.name,**{"start_"+key:val for key,val in retained.items()},**dict(zip(NAMES,state)),
         **{"port_"+key:vals for key,vals in series.items()},port_times=port_times,cuts=cuts,radii=branch.obs,x=x,trace=traces,
         model=model,seed=seed.name,seed_sha=digest(seed),port=kind,port_source=digest(ports.path) if ports is not None else "",
         k=p.k,final_reference=branch.ref.solution(SPAN*DLOG),complete=True)
    print(dest.name,flush=True)


if __name__=="__main__":
    for task in sys.argv[1:]:
        model,edge,steps,kind=task.split(":")
        run(model,int(edge),int(steps),kind)
