from campaign import HERE,np,table
from native_run import Native
from balanced import BalancedNative
from entry import rows
from shell_forecast import SHELLS
from scipy.integrate import quad

def main():
    recorded=[]
    for rate in (2,4,8):
        for tag,solver in (("raw",Native),("balanced",BalancedNative)):
            sim=solver("heavy",72,72*rate,False,"native36")
            state=sim.init();p=sim.patch;m=sim.mesh
            stationary,motion,_=m.gauges(state[0][0])
            num=1+stationary
            _,u,_=m.gauges(state[0][1])
            hub,_=p.coeff(0)
            dv=sim.rates(state,0)[2][2]*hub
            dd=m.div_flux(num,u,np.zeros_like(dv),dv,True)
            source=p.p.coeff@dd
            output=("balanced-" if tag=="balanced" else "")+f"startup-heavy-L72-h{rate}.npz"
            with np.load(HERE/output) as data:
                measured=data["series"][1,2].sum(axis=0)
                eta=data["eta"][1]
            forecast=rows(HERE/"frozen-shell-law.csv")
            for pos,(lo,hi) in enumerate(SHELLS):
                mask=np.zeros_like(m.loc)
                mask[lo*rate:hi*rate]=m.qw/m.loc[lo*rate:hi*rate]
                second=(m.quad(source)*mask).sum()
                target=float(forecast[pos]["wave_fourth"])
                expected=eta**4*target/24
                artifact=eta**2*second/2
                recorded.append(dict(rate=rate,operator=tag,lower=lo,upper=hi,initial_spurious_second=second,
                    first_measured=measured[pos],physical_quartic=expected,artificial_quadratic=artifact,
                    defect_after_both=(measured[pos]-expected-artifact)/max(abs(expected),abs(artifact))))
    table("constant-gradient-control.csv",recorded)
if __name__=="__main__":main()
