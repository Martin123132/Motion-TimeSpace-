from campaign import AI,HERE,digest,guard,np,pack,table,sys
from balanced import BalancedNative
from entry import rows
from native_run import Native
from shell_forecast import SHELLS
from scipy.integrate import quad
from math import factorial
from assess import interp

FROZEN="6195d9341ad96bba288a0d9c1bb399230c82bb8d5079de2a83f71b0448de6003"
OFF=np.array([0,.000125,.00025,.0005,.001,.002,.004,.008])
CASES=(("heavy",72,2),("heavy",72,4),("heavy",96,4),("heavy",72,8),("cold",72,4),("cold",96,4))
def trial(model,edge,rate,balanced=False):
    prefix="balanced-" if balanced else ""
    filename=f"{prefix}startup-{model}-L{edge}-h{rate}.npz"
    if (HERE/filename).exists():return
    sim=(BalancedNative if balanced else Native)(model,edge,edge*rate,False,"native36")
    mesh=sim.mesh
    shells=[]
    for lower,upper in SHELLS:
        mask=np.zeros_like(mesh.loc)
        left,right=int(lower*rate),int(upper*rate)
        mask[left:right]=mesh.qw/mesh.loc[left:right]
        shells.append(mesh.gather(mask)[1:])
    probes=np.stack(shells)
    state=sim.init()
    series=[]
    eta=[]
    for index,target in enumerate(OFF):
        if index:
            start=OFF[index-1]
            steps=max(8,int(np.ceil((target-start)/.00005)))
            step=(target-start)/steps
            for tick in range(steps):
                guard()
                now=start+tick*step
                def shift(rate,span):return tuple(val+span*dv for val,dv in zip(state,rate))
                one=sim.rates(state,now)
                two=sim.rates(shift(one,step/2),now+step/2)
                three=sim.rates(shift(two,step/2),now+step/2)
                four=sim.rates(shift(three,step),now+step)
                state=tuple(v+step*(d1+2*d2+2*d3+d4)/6 for v,d1,d2,d3,d4 in zip(state,one,two,three,four))
        series.append((state[1]@probes.T)*sim.patch.p.coeff[:,None])
        eta.append(quad(lambda t:1/sim.patch.coeff(t)[0],0,target)[0])
    assert np.isfinite(series).all() and (model!="cold" or not np.any(np.asarray(series)[:,2]))
    pack(filename,series=series,eta=eta,x=OFF,shells=SHELLS)
def score(balanced=False):
    prefix="balanced-" if balanced else ""
    targets={(r["model"],int(r["lower"])):r for r in rows(HERE/"frozen-shell-law.csv")}
    ledger=[];epochs=[]
    for model,edge,rate in CASES:
        with np.load(HERE/f"{prefix}startup-{model}-L{edge}-h{rate}.npz") as data:
            eta=data["eta"];series=data["series"].sum(axis=2)
        for idx,(lower,upper) in enumerate(SHELLS):
            t=targets[model,lower]
            for channel,power,field in ((1,2,"ordinary_second"),(2,4,"wave_fourth")):
                val=series[:,channel,idx]
                scaled=factorial(power)*val[1:]/eta[1:]**power
                estimate=interp(eta[1:5],scaled[:4],0)
                later=interp(eta[3:7],scaled[2:6],0)
                target=float(t[field])
                for pos in range(1,len(eta)):
                    epochs.append(dict(model=model,edge=edge,rate=rate,lower=lower,upper=upper,channel=channel,power=power,
                                       eta=eta[pos],integral=val[pos],normalized=scaled[pos-1],formal=target))
                ledger.append(dict(model=model,edge=edge,rate=rate,lower=lower,upper=upper,field=field,forecast=target,
                                   early_estimate=estimate,later_estimate=later,early_relative=estimate/target-1 if target else None,
                                   later_relative=later/target-1 if target else None,
                                   early_ratio=val[2]/val[1] if val[1] else None))
    table(prefix+"startup-checks.csv",ledger)
    table(prefix+"startup-scales.csv",epochs)
if __name__=="__main__":
    assert digest(HERE/"frozen-shell-law.csv")==FROZEN
    assert sys.argv[1:] in ([],["--balanced"])
    for args in CASES:trial(*args,balanced=bool(sys.argv[1:]))
    score(bool(sys.argv[1:]))
