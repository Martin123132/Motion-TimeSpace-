"""Measure the predicted shell source independently with live radial and quadrupolar fields."""
from campaign import AI,DLOG,HERE,NAMES,SPAN,digest,guard,np,pack,table,sys
from retarded import RINGS,TIMES
from entry import rows
from balanced import BalancedNative
from scipy.integrate import quad

FROZEN="13f21c52a8d6d8d09ae0ada3e0649021434421126f81a68efdfb9614a632a7a5"
CASES=(("heavy",96,4,176),("heavy",72,4,176),("heavy",120,4,176),("cold",96,4,176),("cold",120,4,176),
       ("heavy",96,5,176),("heavy",96,4,352))
def name(model,edge,rate,steps):
    return f"evolved-{model}-L{edge}-h{rate}-t{steps}.npz"
def trial(model,edge,rate,steps):
    guard()
    assert digest(HERE/"retarded-shell-prediction.csv")==FROZEN
    path=HERE/name(model,edge,rate,steps)
    if path.exists():
        with np.load(path) as previous:assert previous["x"][-1]==SPAN*DLOG and previous["prediction"].item()==FROZEN
        return
    sim=BalancedNative(model,edge,edge*rate,False,"native36",SPAN*DLOG)
    mesh=sim.mesh
    probes=[];faces=[];radii=[]
    rings=[(lo,hi) for lo,hi in RINGS if hi<=edge]
    for lower,upper in rings:
        mask=np.zeros_like(mesh.loc);start,stop=lower*rate,upper*rate
        mask[start:stop]=mesh.qw/mesh.loc[start:stop]
        probes.append(mesh.gather(mask)[1:])
    for radius in sorted({num for segment in rings for num in segment}):
        radii.append(radius)
        faces.append(np.where(mesh.r==radius)[0].item())
    probes=np.stack(probes)
    state=sim.init()
    currents=[];values=[];radial=[];etas=[]
    for idx,target in enumerate(TIMES):
        if idx:
            start=TIMES[idx-1]
            count=max(8,int(round((target-start)/(DLOG/steps))))
            step=(target-start)/count
            for tick in range(count):
                if tick%16==0:guard()
                now=start+step*tick
                def shift(rate,dt):return tuple(v+dt*dv for v,dv in zip(state,rate))
                k1=sim.rates(state,now)
                k2=sim.rates(shift(k1,step/2),now+step/2)
                k3=sim.rates(shift(k2,step/2),now+step/2)
                k4=sim.rates(shift(k3,step),now+step)
                state=tuple(v+step/6*(a+2*b+2*c+d) for v,a,b,c,d in zip(state,k1,k2,k3,k4))
        values.append((state[1]@probes.T)*sim.patch.p.coeff[:,None])
        _,flow,_=mesh.gauges(state[0][1])
        currents.append(-flow[:,faces]*np.square(radii))
        radial.append(sim.observe(state,target))
        etas.append(quad(lambda t:1/sim.patch.coeff(t)[0],0,target)[0])
    assert np.isfinite(values).all() and (model!="cold" or not np.any(np.asarray(values)[:,2]))
    pack(path.name,x=TIMES,eta=etas,probe=sim.obs,shells=rings,radii=radii,minus_r2_velocity=currents,
         integrated=values,forces=radial,prediction=FROZEN,**dict(zip(NAMES,state)))
    print(path.name,flush=True)

def score():
    ledger=[];flows=[]
    for model,edge,rate,steps in CASES:
        with np.load(HERE/f"retarded-{model}.npz") as data:
            pred=data["terms"];speed=data["u"]
        with np.load(HERE/name(model,edge,rate,steps)) as data:
            fields=data["integrated"].sum(axis=2)
            x=data["x"];eta=data["eta"]
            for slot,(lo,hi) in enumerate(data["shells"]):
                index=RINGS.index((lo,hi))
                for tick in range(1,len(x)):
                    for ch,key in enumerate(("on","off","difference")):
                        terms=pred[:,ch,index,tick]
                        actual=fields[tick,ch,slot]
                        ledger.append(dict(model=model,edge=edge,rate=rate,steps=steps,lower=lo,upper=hi,channel=key,
                                           epoch=x[tick]/DLOG,eta=eta[tick],measured=actual,predicted=sum(terms),
                                           first_only=terms[0]+terms[1],last_order=terms[-1],
                                           relative=(sum(terms)-actual)/actual if actual else None))
            for tick in range(1,len(x)):
                for pos,r in enumerate(data["radii"]):
                    for species,result in enumerate(data["minus_r2_velocity"][tick,:,pos]):
                        flows.append(dict(model=model,edge=edge,rate=rate,steps=steps,epoch=x[tick]/DLOG,r=r,
                                          species=species,inflow=result,forecast=speed[tick],relative=result/speed[tick]-1))
    table("retarded-vs-live.csv",ledger)
    table("monopole-transport.csv",flows)

if __name__=="__main__":
    if sys.argv[1:]==["score"]:score()
    else:
        for token in sys.argv[1:]:trial(*CASES[int(token)])
