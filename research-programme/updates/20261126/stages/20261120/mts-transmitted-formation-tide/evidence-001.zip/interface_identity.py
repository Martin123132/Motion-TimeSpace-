from campaign import AI,BASE,DLOG,HERE,NAMES,Ports,SPAN,guard,np,path_for,table
from native_run import Native,Reference

def delta_current(sim,st,time,wanted):
    m=sim.mesh
    p=sim.patch
    _,actual,_=m.gauges(st[0][1])
    ref=sim.data(time)[0][:,:,-1]
    deposited=(wanted-actual[:,-1])*(st[1][...,-1]+ref)
    local=np.zeros((*deposited.shape,m.segments,m.order+1))
    local[...,-1,:]=deposited[...,None]*(m.qw[-1]*m.edge**2)*m.der[-1]
    return m.gather(local)[...,1:]/(m.m*p.coeff(time)[0])

def check():
    ledger=[]
    for model in ("heavy","cold"):
        wide=Native(model,96,384,False,"native36",SPAN*DLOG)
        cut=Native(model,36,144,False,"native36",SPAN*DLOG)
        cut.ref=wide.ref
        ports=Ports(model,36,cut.mesh.size,176,"full")
        with np.load(path_for(model,96,176,"free")) as data:
            for time,prefix in ((DLOG,"start_"),(SPAN*DLOG,"")):
                state=tuple(data[prefix+key] for key in NAMES)
                take=tuple(raw[...,:cut.mesh.size] for raw in state)
                for key,raw in zip(NAMES,take):
                    np.testing.assert_allclose(ports.curves[key](time),raw[...,-1],rtol=2e-14,atol=1e-25)
                wide_rate=wide.rates(state,time)
                limited=ports.rhs(cut,take,time)
                _,flow,_=wide.mesh.gauges(state[0][1])
                change=delta_current(cut,take,time,flow[:,cut.mesh.size])
                for label,ch in (("on",0),("off",1),("difference",2)):
                    comp=wide_rate[1][ch,:,:cut.mesh.size-1]
                    raw=limited[1][ch,:,:-1]-comp
                    after=raw+change[ch,:,:-1]
                    peak=np.max(abs(comp[:,-cut.mesh.order:]))
                    ledger.append(dict(model=model,epoch=time/DLOG,channel=label,
                                       face_velocity_error=np.max(abs(cut.mesh.gauges(take[0][1])[1][:,-1]-flow[:,cut.mesh.size])),
                                       initial_error=np.max(abs(raw)),after_flux=np.max(abs(after)),
                                       common_error=np.max(abs(raw[:,:-cut.mesh.order])),local_rate_peak=peak,
                                       relative_flux_remainder=np.max(abs(after))/peak if peak else None))
    table("interface-generator-identity.csv",ledger)
if __name__=="__main__":check()
