from campaign import HERE,DLOG,SPAN,digest,np,sys,table
from collar_response import GROUPS,filename,run
from outer_history import RINGS,TIMES,name

FROZEN=None
RANGE=(*RINGS,(36,38))
CHANNEL=("on","off","difference")
def read(path):
    with np.load(HERE/path) as data:return {key:data[key] for key in data.files}

def cube(data,key):
    if key=="polar":return 1.5*data["metric"]/data["radii"]
    return data[key]

def freeze():
    ledger=[]
    for model in ("heavy","cold"):
        quad=read(f"quadratic-{model}-L120-h4.npz")
        grid=read(filename(model,120,4,"tangent"))
        for field in ("shell","radial","polar"):
            values=quad[field] if field!="polar" else 1.5*quad["metric"]/grid["radii"]
            for idx,time in enumerate(TIMES):
                for ch,label in enumerate(CHANNEL):
                    for j,(first,second) in enumerate(values[idx,:2,ch].T):
                        probe=(str(RANGE[j][0])+"-"+str(RANGE[j][1])) if field=="shell" else grid["radii"][j]
                        ledger.append(dict(model=model,field=field,probe=probe,channel=label,x=time,first=first,
                                           quadratic=second,overdensity=first+second,underdensity=-first+second))
    table("frozen-sign-reversal.csv",ledger)
    print(digest(HERE/"frozen-sign-reversal.csv"))
def score():
    ledger=[];source=[];independent=[]
    for model in ("heavy","cold"):
        quad=read(f"quadratic-{model}-L120-h4.npz")
        tan=read(filename(model,120,4,"tangent"))
        qty=len(tan["radii"])
        positive=read(name(model,120,4,176))
        negative=read(filename(model,120,4,"-1"))
        plus=read(filename(model,120,4,"0.25"))
        minus=read(filename(model,120,4,"-0.25"))
        for field in ("shell","radial","polar"):
            waves=quad[field] if field!="polar" else 1.5*quad["metric"]/tan["radii"]
            groups=cube(tan,field)
            fdpos=cube(plus,field)[:,0]
            fdneg=cube(minus,field)[:,0]
            targets=cube(negative,field)[:,0]
            if field=="shell":
                series=positive["integrated"].sum(axis=2)
                origin=np.concatenate((series,(series[:,:,4]-series[:,:,0]-series[:,:,1])[:,:,None]),axis=2)
            elif field=="radial":origin=positive["forces"][:,6]
            else:origin=1.5*positive["forces"][:,5]/positive["probe"]
            for tick,time in enumerate(TIMES[1:],1):
                for ch,label in enumerate(CHANNEL):
                    for pos in range(waves.shape[-1]):
                        probe=(str(RANGE[pos][0])+"-"+str(RANGE[pos][1])) if field=="shell" else tan["radii"][pos]
                        key=tick,ch,pos
                        first,second=waves[tick,:,ch,pos]
                        parts=groups[tick,:,ch,pos]
                        common=dict(model=model,field=field,probe=probe,channel=label,epoch=time/DLOG)
                        fd1=(fdpos[key]-fdneg[key])/.5
                        fd2=(fdpos[key]+fdneg[key])/.125
                        independent.append(dict(**common,first=first,independent_first=parts[0],centered_first=fd1,
                                                second=second,centered_second=fd2,
                                                even_sign_full=(origin[key]+targets[key])/2,odd_sign_full=(origin[key]-targets[key])/2))
                        source.append(dict(**common,**dict(zip(GROUPS,parts)),split_residual=parts[1:].sum()-parts[0]))
                        for sign,true in ((1,origin[key]),(-1,targets[key])):
                            pt1=sign*first;pt2=pt1+second
                            ledger.append(dict(**common,sign=sign,physical=true,linear=pt1,second_order=pt2,
                                               linear_relative=(pt1-true)/true if true else None,
                                               quadratic_relative=(pt2-true)/true if true else None,
                                               improved=abs(pt2-true)<abs(pt1-true) if true else None))
    table("signed-state-results.csv",ledger)
    table("separate-drives.csv",source)
    table("coefficient-crosschecks.csv",independent)
if __name__=="__main__":
    if sys.argv[1:]==["freeze"]:freeze()
    elif len(sys.argv)==3 and sys.argv[1]=="open":
        assert digest(HERE/"frozen-sign-reversal.csv")==sys.argv[2]
        for model in ("heavy","cold"):run(model,120,4,"-1")
        score()
    elif sys.argv[1:]==["score"]:score()
    else:raise ValueError("freeze, open DIGEST, or score")
