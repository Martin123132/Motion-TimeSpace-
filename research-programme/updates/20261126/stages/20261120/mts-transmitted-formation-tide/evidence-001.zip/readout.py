from campaign import AI,DLOG,HERE,SPAN,digest,np,path_for,table
from mesh import Mesh

LABELS=("on","off","difference")
def contents(path):
    with np.load(path) as data:return {key:data[key] for key in data.files}
def totals(data,r,field):
    place=list(data["radii"]).index(r)
    trace=data["trace"]
    if field=="radial":
        return trace[:,1,:,place],trace[:,6,:,place],trace[:,4,:,place]
    return trace[:,2,:,place],1.5*trace[:,5,:,place]/r,1.5*trace[:,3,:,place]/r
def ext(data,cut):
    which=list(data["cuts"]).index(cut)
    index=np.round((data["x"]-DLOG)/(data["port_times"][1]-DLOG)).astype(int)
    np.testing.assert_allclose(data["x"],data["port_times"][index],atol=1e-15,rtol=0)
    return data["port_outside"][index,which]
def norm(value,scale):
    return value/scale if scale else None
def response(model,steps,target_path,paths):
    ref=contents(target_path)
    records=[]
    for path in paths:
        data=contents(path)
        edge=int(data["radii"][-1])
        if path.name.split("-")[1]=="L36":edge=36
        np.testing.assert_array_equal(ref["x"],data["x"])
        scale=(AI*np.exp(ref["x"]))[:,None]
        outside=ext(ref,edge)
        for radius in ref["radii"]:
            if radius>edge or radius not in data["radii"]:continue
            for field,factor in (("radial",2),("polar",-1.5)):
                truth,host,uniform=totals(ref,radius,field)
                raw,inner,common=totals(data,radius,field)
                direct=factor*radius*outside/(10*scale)
                interior_error=inner-(host-direct)
                for idx,time in enumerate(data["x"]):
                    for channel,label in enumerate(LABELS):
                        num=idx,channel
                        records.append(dict(model=model,steps=steps,case=path.stem,epoch=time/DLOG,
                            radius=radius,field=field,channel=label,wide_force=truth[num],wide_host=host[num],
                            wide_reference=uniform[num],inside_only=inner[num],outer_source=direct[num],
                            inside_difference=interior_error[num],raw_error=raw[num]-truth[num],
                            with_shell_error=raw[num]+direct[num]-truth[num],
                            reference_difference=common[num]-uniform[num],
                            raw_on_host_scale=norm(inner[num]-host[num],host[num]),
                            corrected_on_host_scale=norm(interior_error[num],host[num]),
                            raw_on_total_scale=norm(raw[num]-truth[num],truth[num])))
    return records

def independent():
    from entry import Preparation
    ledger=[]
    for model in ("heavy","cold"):
        p=Preparation(model,20,False,"probe")
        wide=contents(path_for(model,96,176,"free"))
        m=Mesh(96,384);cut=Mesh(36,144)
        for where,key,idx in (("initial","start_density",0),("final","density",-1)):
            dens=wide[key]
            source=(p.coeff@dens)/(2*AI*np.exp(wide["x"][idx]))
            large=m.potential(source)
            small=cut.potential(source[...,:cut.size])
            coeff=-ext(wide,36)[idx]/(10*AI*np.exp(wide["x"][idx]))
            for ch,label in enumerate(LABELS):
                correction=coeff[ch]*cut.r[1:]**2
                diff=large[ch,:cut.size]-small[ch]
                defect=np.max(np.abs(diff-correction))
                ledger.append(dict(model=model,endpoint=where,channel=label,max_abs=defect,
                                   harmonic_peak=np.max(abs(correction)),full_metric_peak=np.max(abs(large[ch])),
                                   normalized_to_shell=norm(defect,np.max(abs(correction))),
                                   normalized_to_metric=norm(defect,np.max(abs(large[ch])))))
    table("elliptic-shell-check.csv",ledger)

if __name__=="__main__":
    records=[]
    for model in ("heavy","cold"):
        for steps in (176,352):
            target=path_for(model,96,steps,"free")
            if not target.exists():continue
            paths=sorted(p for p in HERE.glob(f"{model}-L*-t{steps}-*.npz") if p!=target)
            records+=response(model,steps,target,paths)
    table("force-decomposition.csv",records)
    independent()
