from seed_scores import CHANNEL,RANGE,filename,name,read
from campaign import DLOG,HERE,np,table
from retarded import TIMES

def full(model,edge,rate,steps,sign,field):
    if sign==-1:
        data=read(filename(model,edge,rate,"-1"))
        result=data[field][:,0] if field!="polar" else 1.5*data["metric"][:,0]/data["radii"]
        return result,data["radii"]
    data=read(name(model,edge,rate,steps))
    if field=="shell":
        seq=data["integrated"].sum(axis=2)
        return np.concatenate((seq,(seq[:,:,4]-seq[:,:,0]-seq[:,:,1])[:,:,None]),axis=2),data["probe"]
    return (data["forces"][:,6] if field=="radial" else 1.5*data["forces"][:,5]/data["probe"]),data["probe"]

def main():
    results=[]
    for model in ("heavy","cold"):
        quad=read(f"quadratic-{model}-L120-h4.npz")
        for sign in (1,-1):
            for field in ("radial","polar","shell"):
                base,radii=full(model,120,4,176,sign,field)
                tensor=quad[field] if field!="polar" else 1.5*quad["metric"]/radii
                probes=list(RANGE) if field=="shell" else list(radii)
                alternatives=[(120,5,176)]
                if sign==1:alternatives.append((144,4,176))
                for edge,rate,steps in alternatives:
                    series,others=full(model,edge,rate,steps,sign,field)
                    for idx,probe in enumerate(probes):
                        if field!="shell" and probe not in others:continue
                        pos=idx if field=="shell" else list(others).index(probe)
                        for tick,time in enumerate(TIMES[1:],1):
                            for ch,key in enumerate(CHANNEL):
                                true=series[tick,ch,pos];same=base[tick,ch,idx]
                                linear,quadterm=tensor[tick,:,ch,idx]
                                pred=sign*linear+quadterm
                                results.append(dict(model=model,sign=sign,alternative_edge=edge,alternative_rate=rate,
                                    field=field,probe=f"{probe[0]}-{probe[1]}" if field=="shell" else probe,
                                    channel=key,epoch=time/DLOG,base=same,alternative=true,frozen=pred,
                                    numerical_relative=(true-same)/same if same else None,
                                    forecast_relative=(pred-true)/true if true else None))
    table("independent-resolution.csv",results)

if __name__=="__main__":main()
