from optical import evaluate
from solve import HERE, RADII, contrast, guard, json, np, rows, table, TOL

CONFIGS=(("start",1,8,"geodesic"),("start",1,8,"newton"),("end",1,8,"geodesic"),
         ("start",2,16,"geodesic"),("end",2,8,"geodesic"))

def run():
    guard()
    rates=[];links=[];origins=[]
    for epoch,labels,steps,scheme in CONFIGS:
        tag=f"cold-{epoch}-labels{labels}-n{steps}-projected-{scheme}-rc0.00625"
        path=HERE/("live-"+tag+".npz")
        forecast=json.loads((HERE/(tag+"-before.json")).read_bytes())
        with np.load(path,allow_pickle=False) as packet:
            times=packet["eta"]
            assert np.all(np.diff(times)>0) and len(times)==steps+1
            assert abs(np.ptp(times)-forecast["interval_conformal_mpc"])<1e-15
            snap=0 if epoch=="start" else -1
            sample=np.interp(RADII,packet["r"],packet["Vkin"][snap])
            np.testing.assert_array_equal(forecast["rate_at_sites"],sample)
        optical,kin=evaluate(path)
        for row in kin:
            row.update(labels=labels,steps=steps,scheme=scheme,
                       difference=row["measured"]-row["predicted"],within_target=abs(row["residual"])<=TOL)
        rates+=kin;links+=optical
    for path in sorted(HERE.glob("before-evolution-heavy-*-regular.json")):
        item=json.loads(path.read_bytes());epoch=path.name.split("-")[3]
        reference=float(rows(HERE/f"constraint-heavy-{epoch}.csv")[-1]["frozen_prediction"])
        result=contrast(item["slip"]);rel=result/reference-1
        origins.append(dict(source=path.name,epoch=epoch,value=result,reference=reference,
                            relative_difference=rel,within_target=abs(rel)<=TOL))
    assert len(origins)==8 and len(rates)==20 and len(links)==15
    table("regular-origin-static.csv",origins)
    table("live-material-kinematics.csv",rates)
    table("live-material-links.csv",links)
    for row in rates:
        if row["field"]=="V":
            print(row["epoch"],row["labels"],row["scheme"],row["arm"],format(row["residual"],".6g"))
if __name__=="__main__":run()
