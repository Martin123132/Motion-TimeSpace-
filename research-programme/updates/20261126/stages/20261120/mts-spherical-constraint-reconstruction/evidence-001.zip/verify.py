from records import HERE, PARENT, FILES, PIN, TOL, digest, guard, json, note, np, rows, sys
from solve import contrast, RADII

def gather(pattern):
    return [entry for path in sorted(HERE.glob(pattern)) for entry in rows(path)]
def peak(data,column):
    return max(abs(float(row[column])) for row in data)
def validate():
    guard()
    assert len(FILES)==175 and all(digest(PARENT/name)==ref for name,ref in FILES.items())
    snapshots=[];matching=[]
    for model in ("cold","heavy"):
        for epoch in ("start","end"):
            key=f"{model}-{epoch}"
            samples=rows(HERE/f"constraint-{key}.csv")
            assert [(int(row["level"]),int(row["order"])) for row in samples]==[(0,4),(0,6),(1,6),(2,6),(2,8)]
            stored,=[float(row["contrast_V_minus_U"]) for row in rows(PARENT/"formed-tracefree-source.csv")
                     if (row["model"],row["epoch"],row["level"],row["order"])==(model,epoch,"2","10")]
            rec=samples[-1]
            assert float(rec["frozen_prediction"])==stored>0 and float(rec["cusp_8piG_energy_r2"])>0
            direct=float(rec["compensated_slip"])/stored-1
            assert abs(direct)<TOL
            edges=rows(HERE/f"boundaries-{key}.csv")
            assert len(edges)==(7 if model=="heavy" else 6) and peak(edges,"direct_flux_ratio")<TOL
            shifts=rows(HERE/f"lapse-matching-{key}.csv")
            assert [int(float(row["multiplier"])) for row in shifts]==[-1,0,1]
            matching.append(max(abs(float(row["compensated_slip"])/float(shifts[1]["compensated_slip"])-1) for row in shifts))
            snapshots.append(direct)
    assert max(matching)<TOL
    controls=rows(HERE/"analytic-controls.csv")
    assert {row["case"] for row in controls}=={"RN-0","RN-0.6","RN-1","FLRW","expanding-current"}
    assert max(peak(controls,key) for key in controls[0] if key!="case")<1e-13
    mass=gather("mass-*.csv");assert len(mass)==26 and peak(mass,"current_test_error")<TOL
    for path in HERE.glob("history-*.npz"):
        freeze=json.loads((HERE/path.name.replace("history-","before-evolution-").replace(".npz",".json")).read_bytes())
        with np.load(path,allow_pickle=False) as packet:
            assert all(np.isfinite(packet[key]).all() for key in packet)
            edge=int(np.argmin(abs(packet["eta"])))
            assert packet["eta"][edge]==0 and np.all(np.diff(packet["eta"])>0)
            for field,forecast in (("V","V"),("slip","slip"),("Nkin","newtonian_Vdot"),("Vkin","Vdot")):
                np.testing.assert_array_equal(np.interp(RADII,packet["r"],packet[field][edge]),freeze[forecast])
    origins=rows(HERE/"regular-origin-static.csv")
    assert len(origins)==8 and all(row["within_target"]=="True" and abs(float(row["relative_difference"]))<TOL for row in origins)
    original=rows(HERE/"metric-time-closure.csv")
    assert len(original)==76
    coarse=[r for r in original if r["history"]=="history-heavy-end-g0-n8-rc0.00625-L24-balanced" and r["field"]=="V"]
    repaired=[r for r in original if r["model"]=="heavy" and "-g2-" in r["history"] and r["field"]=="V"]
    assert len(coarse)==2 and peak(coarse,"residual")>0.1 and len(repaired)==4 and peak(repaired,"residual")<TOL
    rates=rows(HERE/"live-material-kinematics.csv");assert len(rates)==20
    for row in rates:
        assert (abs(float(row["residual"]))<=TOL)==(row["within_target"]=="True")
    rel=[r for r in rates if r["scheme"]=="geodesic" and r["field"]=="V"]
    ctr=[r for r in rates if r["scheme"]=="newton" and r["field"]=="V"]
    assert len(rel)==8 and len(ctr)==2 and peak(ctr,"residual")>TOL
    flux=rows(HERE/"scalar-canonical-flux.csv")
    assert len({(r["epoch"],r["lift"],r["arm"]) for r in flux})==len(flux)==8 and peak(flux,"closure")<TOL
    light=rows(HERE/"propagated-light-links.csv");live=rows(HERE/"live-material-links.csv")
    pulses=rows(HERE/"pulse-spacing-check.csv");analytic=rows(HERE/"optical-controls.csv")
    assert (len(light),len(live),len(pulses),len(analytic))==(111,15,36,6)
    for row in light+live:
        parts=sum(float(row[key]) for key in ("emitter","integrated","expansion"))
        assert abs(float(row["received"])-parts)<1e-19
    assert peak(pulses,"error")<1e-16 and peak(analytic,"error")<1e-16
    return dict(snapshot_max_relative=max(map(abs,snapshots)),regular_origin_snapshot_max_relative=peak(origins,"relative_difference"),
        varied_slope_max_relative=max(matching),mass_max_relative=peak(mass,"max_mass_rel"),mass_error_on_current=peak(mass,"current_test_error"),
        raw_wave_native_max=peak(coarse,"residual"),wave_fine_max=peak(repaired,"residual"),
        cold_geodesic_rate_max=peak(rel,"residual"),cold_geodesic_pass_count=sum(r["within_target"]=="True" for r in rel),
        cold_geodesic_rate_count=len(rel),cold_matched_newton_max=peak(ctr,"residual"),
        canonical_wave_flux_error=peak(flux,"closure"),pulse_jacobian_abs_error=peak(pulses,"error"))
if __name__=="__main__":
    assert sys.argv[1:] in ([],["seal"])
    summary=validate()
    seal=HERE/"seal.json"
    if sys.argv[1:]==["seal"]:note("validation.json",summary)
    assert summary==json.loads((HERE/"validation.json").read_bytes())
    assert not any(HERE.rglob("__pycache__"))
    manifest={p.relative_to(HERE).as_posix():digest(p) for p in sorted(HERE.rglob("*")) if p.is_file() and p!=seal}
    result=dict(files=manifest,parent_sha256=PIN)
    if sys.argv[1:]==["seal"]:note("seal.json",result)
    assert json.loads(seal.read_bytes())==result
    print(len(manifest),"stage and",len(FILES),"parent files verified;",digest(seal))
    print(json.dumps(summary,indent=2))
