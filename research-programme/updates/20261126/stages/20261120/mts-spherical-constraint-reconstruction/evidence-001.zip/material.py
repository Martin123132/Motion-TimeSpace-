from independent import *
from scipy.integrate import solve_ivp

def subdivide(state,fineness):
    new=dict(state)
    for key in ("baryon","cdm"):
        xpos,momentum,masses=(state[key+suffix] for suffix in ("_x","_p","_M"))
        elements=np.repeat(np.arange(len(xpos)-1),fineness)
        frac=np.tile(np.arange(fineness)/fineness,len(xpos)-1)
        new[key+"_x"]=np.r_[xpos[elements]+frac*np.diff(xpos)[elements],xpos[-1]]
        new[key+"_p"]=np.r_[momentum[elements]+frac*np.diff(momentum)[elements],momentum[-1]]
        partial=frac*(elements**2+elements*frac+frac**2/3)/(elements**2+elements+1/3)
        new[key+"_M"]=np.r_[masses[elements]+partial*np.diff(masses)[elements],masses[-1]]
        assert np.array_equal(new[key+"_M"][::fineness],masses)
    return new

def newtonian(matter):
    mesh=matter.mesh
    grad=mesh.primitive(.5*matter.a**2*mesh.r**2*(matter.rest-matter.bg))/mesh.r**2
    return -mesh.primitive(grad,True),grad
def prepare(epoch,sub,cut):
    seed,saved,scale=fixture("cold",epoch,0);state=subdivide(saved,sub)
    matter=Matter("cold",epoch,cut,.003125,6,24.,prepared=(seed,state,scale));mesh=matter.mesh
    solved=constraints(matter);delta=flux_lapse(matter,solved)
    space=solved["spatial"];lapse=space-delta
    weight=np.exp(4*space-delta)*(2*solved["vprime"]**2+scale**2*(1+solved["beta"])**4*solved["anis"])/mesh.r
    lapsegrad=solved["vprime"]+mesh.r*np.exp(-4*space+delta)*mesh.primitive(weight,True)
    newton,ngrad=newtonian(matter)
    kin=-scale*(seed.H(scale)*np.expm1(lapse)+np.exp(lapse)*solved["expansion"])
    primary=np.diff(mesh.points(kin,RADII));span=np.diff(mesh.points(space,RADII))
    norm=np.maximum(abs(primary),scale*seed.H(scale)*abs(span))
    controls={}
    eulerian=np.zeros_like(mesh.r)
    for key,(addresses,loads,mom,_,_,_) in matter.parts.items():
        metric=space[addresses];clock=lapse[addresses];gamma=np.sqrt(1+(mom*np.exp(metric)/scale)**2)
        correction=mom/scale*np.expm1(clock+2*metric-np.log(gamma))
        eulerian+=np.bincount(addresses,loads*correction,minlength=len(mesh.r))
    velocity_prediction=-.5*scale**2*np.diff(mesh.points(mesh.primitive(eulerian),RADII))
    for key in ("cdm","baryon"):
        xpos,momentum=state[key+"_x"],state[key+"_p"]
        position=abs(xpos);orientation=np.sign(xpos)
        vmetric=mesh.points(space,position);uclock=mesh.points(lapse,position)
        dv=orientation*mesh.points(solved["vprime"],position);du=orientation*mesh.points(lapsegrad,position)
        dn=orientation*mesh.points(ngrad,position)
        pstar2=(momentum*np.exp(vmetric)/scale)**2
        lorentz=np.sqrt(1+pstar2)
        velocity=momentum/scale
        pnewton=-scale*dn
        relative_velocity=velocity*np.expm1(uclock+2*vmetric-np.log(lorentz))
        pgeo=-scale*np.exp(uclock)*(lorentz*du+pstar2*dv/lorentz)
        for vector in (pnewton,pgeo,relative_velocity):vector[[0,-1]]=0.
        controls[key]=(velocity,relative_velocity,pnewton,pgeo)
    return seed,state,scale,controls,primary,norm,velocity_prediction

def run(epoch,sub,cut):
    seed,state,a,force,pred,normal,correction=prepare(epoch,sub,cut)
    stamp=f"material-cold-{epoch}-labels{sub}-core{cut:g}"
    note(stamp+"-freeze.json",dict(predicted_gr_rate=pred.tolist(),direct_velocity_correction=correction.tolist(),scale=normal.tolist(),
             rule="minimal common-metric mass-shell Hamiltonian; no coefficient fitted"))
    records=[]
    for scheme in ("newton","velocity","geodesic"):
        for step in (.012,.006,.003):
            endpoints=[]
            for sign in (-1,1):
                guard();eta=step*sign
                anew=solve_ivp(lambda _,val:val**2*seed.H(float(val[0])),(0.,eta),[a],rtol=1e-13,atol=1e-15).y[0,-1]
                changed=dict(state,a=anew)
                for key,(velocity,delta,pnewton,pgeo) in force.items():
                    changed[key+"_x"]=state[key+"_x"]+eta*(velocity if scheme=="newton" else velocity+delta)
                    changed[key+"_p"]=state[key+"_p"]+eta*(pgeo if scheme=="geodesic" else pnewton)
                matter=Matter("cold",epoch,cut,.003125,6,24.,prepared=(seed,changed,anew))
                result=constraints(matter)
                endpoints.append(np.diff(matter.mesh.points(result["spatial"],RADII)))
            val=(endpoints[1]-endpoints[0])/(2*step)
            for arm in (0,1):records.append(dict(epoch=epoch,labels=sub,core=cut,scheme=scheme,step=step,arm=arm,
                predicted=pred[arm],measured=val[arm],normalizer=normal[arm],residual=(val[arm]-pred[arm])/normal[arm],
                predicted_velocity_change=correction[arm]))
    table(stamp+".csv",records)
    for row in records:
        if row["step"]==.003:print(row["scheme"],row["arm"],row["residual"],flush=True)
if __name__=="__main__":run(sys.argv[1],int(sys.argv[2]),float(sys.argv[3]))

