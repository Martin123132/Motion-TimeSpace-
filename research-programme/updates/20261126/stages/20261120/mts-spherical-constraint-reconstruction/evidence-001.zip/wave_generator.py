from records import *
from inputs import dst

def evaluate(epoch,level,order):
    seed,state,scale=fixture("heavy",epoch,level)
    lab=ActionSystem(seed,state);field=lab.source(scale);rad=lab.r;num=lab.n
    coeff=dst(rad[1:-1]*(lab.psi[1:-1]-1),type=1)/num
    kinetic=-.5j*lab.k**2/(seed.mass*scale)*coeff
    interaction=-1j*scale*seed.mass*dst(field.potential[1:-1]*rad[1:-1]*lab.psi[1:-1],type=1)/num
    nodes,wts=roots_legendre(order);sites=(rad[:round(.35/lab.h),None]+(nodes+1)*lab.h/2).ravel()
    weights=np.tile(wts*lab.h/2,round(.35/lab.h))
    kinetic_source=[];kick_source=[];flux=[]
    for start in range(0,len(sites),32):
        points=sites[start:start+32]
        phase=points[:,None]*lab.k
        basis=np.sin(phase);wave=points+basis@coeff;deriv=1+np.cos(phase)@(lab.k*coeff)
        kinetic_source.extend(2*np.real(wave.conj()*(basis@kinetic)))
        kick_source.extend(2*np.real(wave.conj()*(basis@interaction)))
        flux.extend(np.imag(wave.conj()*deriv)/(seed.mass*scale))
    factor=.5*seed.coeff["wave"]/scale
    out=[]
    origin=1+np.dot(lab.k,coeff)
    for idx,(low,high) in enumerate(((.1,.2),(.2,.35))):
        window=np.maximum(1/np.maximum(low,sites)-1/high,0.)
        gradient=np.where((sites>low)&(sites<high),-1/sites**2,0.)
        free=factor*np.dot(weights*window,kinetic_source)
        local_current=factor*np.dot(weights*gradient,flux)
        kick=factor*np.dot(weights*window,kick_source)
        out.append(dict(epoch=epoch,level=level,order=order,arm=idx,stored_origin_difference=abs(lab.psi[0]-origin),
                        free_density=free,from_current=local_current,free_minus_current=free-local_current,
                        projected_kick=kick,analytic_extra_rate=(free-local_current)+kick))
    return out

def run():
    records=[]
    for epoch in ("start","end"):
        for level in (0,1,2,3):
            for order in (6,10):records+=evaluate(epoch,level,order)
    table("instantaneous-wave-generator.csv",records)
    print("Generator checks",len(records),flush=True)
if __name__=="__main__":run()

