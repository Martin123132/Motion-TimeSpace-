from records import *
from scipy.interpolate import RectBivariateSpline,CubicSpline
from scipy.special import roots_legendre

ARMS=((.10,.20),(.15,.30),(.25,.35))

class Movie:
    def __init__(self,packet,choice,thin=1,radial_thin=1):
        self.times=times=packet["eta"][::thin]
        radius=packet["r"][::radial_thin]
        self.hubble=CubicSpline(times,(packet["a"]*packet["H"])[::thin])
        raw=packet["N"] if choice=="newton" else packet["V"]
        space=raw[::thin,::radial_thin]
        lapse=space if choice!="constraint" else space-packet["slip"][::thin,::radial_thin]
        self.sum=RectBivariateSpline(times,radius,space+lapse)
        self.normal=RectBivariateSpline(times,radius,lapse)
    def path(self,mid,length,direction,arrival,steps):
        interval=length/steps
        radius=lambda progress:mid+direction*progress
        def rates(progress,lag):
            eta=arrival-progress+lag;position=radius(progress)
            metric=self.sum.ev(eta,position).item()
            gradient=self.sum.ev(eta,position,dx=1).item()
            return -np.expm1(-metric),np.exp(-metric)*gradient
        lag=0.;jacobian=0.
        for count in range(steps):
            here=count*interval;middle=here+interval/2
            first,firstjac=rates(here,lag)
            half,halfjac=rates(middle,lag+interval*first/2)
            other,otherjac=rates(middle,lag+interval*half/2)
            last,lastjac=rates(here+interval,lag+interval*other)
            lag+=interval/6*(first+2*half+2*other+last)
            jacobian+=interval/6*(firstjac+2*halfjac+2*otherjac+lastjac)
        emission=arrival-length+lag
        assert self.times[0]<emission<arrival<self.times[-1]
        return lag,jacobian,self.normal.ev(emission,radius(length)).item()
    def link(self,low,high,steps=128,margin=.002):
        mid=(low+high)/2;length=(high-low)/2;arrival=self.times[-1]-margin
        left,lj,ln=self.path(mid,length,-1,arrival,steps)
        right,rj,rn=self.path(mid,length,1,arrival,steps)
        common=arrival-length;difference=right-left
        hub=self.hubble(common+(.5*(left+right)))
        return dict(received=rn-ln+rj-lj+hub*difference,emitter=rn-ln,
            integrated=rj-lj,expansion=hub*difference,delay_Mpc=difference)
def derivative(times,values):
    delta=times[1]-times[0]
    return (-25*values[0]+48*values[1]-36*values[2]+16*values[3]-3*values[4])/(12*delta)
def evaluate(path,extra=False):
    with np.load(path,allow_pickle=False) as data:
        packet={key:data[key] for key in data.files}
    parts=path.stem.split("-");model,epoch=parts[1:3]
    idx=np.array([np.argmin(abs(packet["r"]-radius)) for radius in (.1,.2,.35)])
    order=slice(None) if epoch=="start" else slice(None,None,-1)
    kin=[]
    for field,expected in (("V","Vkin"),("N","Nkin")):
        spans=np.diff(packet[field][order][:,idx],axis=1)
        pred=np.diff(packet[expected][order][0,idx])
        times=packet["eta"][order]
        fine=derivative(times,spans)
        coarse=derivative(times[::2],spans[::2])
        for site in range(2):
            norm=max(abs(pred[site]),abs(fine[site]),abs(packet["a"][order][0]*packet["H"][order][0]*spans[0,site]))
            kin.append(dict(history=path.stem,model=model,epoch=epoch,field=field,arm=site,predicted=pred[site],
                    measured=fine[site],scale=norm,residual=(fine[site]-pred[site])/norm,stencil_delta=(fine[site]-coarse[site])/norm))
    results=[]
    configurations=[(1,1,128),(1,1,256),(2,1,128),(1,2,128)] if extra else [(1,1,128)]
    for thin,rthin,steps in configurations:
        movies={label:Movie(packet,label,thin,rthin) for label in ("constraint","common","newton")}
        for site,(low,high) in enumerate(ARMS):
            sets={label:movie.link(low,high,steps) for label,movie in movies.items()}
            full=sets["constraint"]
            results.append(dict(history=path.stem,model=model,epoch=epoch,arm=site,time_stride=thin,space_stride=rthin,steps=steps,
                **full,newton=sets["newton"]["received"],common=sets["common"]["received"],
                relativistic_change=full["received"]-sets["newton"]["received"],
                slip_change=full["received"]-sets["common"]["received"]))
    return results,kin

def run():
    records=[];kin=[]
    for path in sorted(HERE.glob("history-*.npz")):
        guard()
        values,rates=evaluate(path,"-g1-n8-rc0.00625-L24-balanced" in path.stem)
        records+=values;kin+=rates
    table("propagated-light-links.csv",records);table("metric-time-closure.csv",kin)
    print("Optical readouts",len(records),"kinematic tests",len(kin),flush=True)
if __name__=="__main__":run()

