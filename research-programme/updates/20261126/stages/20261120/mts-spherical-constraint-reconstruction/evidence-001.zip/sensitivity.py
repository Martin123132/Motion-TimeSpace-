from independent import *

def decomposed(matter,source):
    mesh=matter.mesh;rad=mesh.r;factor=1+source["beta"];scale=matter.a
    rest=matter.rest-matter.bg
    rates=source["expansion"]
    geometric=.5*source["vprime"]**2
    pieces=dict(newtonian=.5*scale**2*rest,
        proper_volume=.5*scale**2*factor**4*matter.rest*np.expm1(-6*np.log(factor)),
        energy=.5*scale**2*factor**4*(source["energy"]-rest-matter.rest*np.expm1(-6*np.log(factor))),
        spatial_weight=.5*scale**2*np.expm1(4*np.log(factor))*rest,
        expansion=-1.5*scale**2*factor**4*rates*(rates+2*matter.H),geometric=geometric)
    spans={}
    for key,term in pieces.items():
        derivative=mesh.primitive(rad**2*term)/rad**2
        potential=-mesh.primitive(derivative,True)
        values=mesh.points(potential,RADII)
        spans[key]=values[1]-values[0]
    spans["closure"]=sum(spans.values())-np.diff(mesh.points(source["spatial"],RADII))[0]
    return spans

def run(model,epoch):
    meta=[];massrows=[];parts=[];edges=[]
    options=[("reference",.00625,24.,"box","balanced"),("smaller-core",.003125,24.,"box","balanced"),
             ("smallest-core",.0015625,24.,"box","balanced"),("larger-core",.0125,24.,"box","balanced"),
             ("12-Mpc-box",.00625,12.,"box","balanced"),("monopole-exterior",.00625,24.,"tail","balanced")]
    if model=="heavy":options.append(("coordinate-lift",.00625,24.,"box","coordinate"))
    for label,core,box,edge,lift in options:
        number,matter,source,normal=solve_case(model,epoch,1,6,core,box,edge,lift,True)
        mesh=matter.mesh
        exact=flux_lapse(matter,source)
        slip=contrast(mesh.points(exact,RADII))
        number.update(variant=label,independent_flux_slip=slip,direct_flux_ratio=number["compensated_slip"]/slip-1)
        meta.append(number)
        check=mass_check(matter,source)
        massrows.append(dict(variant=label,model=model,epoch=epoch,**{key:val for key,val in check.items() if not isinstance(val,list)}))
        parts.append(dict(variant=label,model=model,epoch=epoch,**decomposed(matter,source)))
        if label=="reference":
            potential_span=number["newtonian_metric_span"]
            for sign in (-1.,0.,1.):
                extra=sign*2*potential_span**2/(RADII[1]**2-RADII[0]**2)*box
                offset=0.
                field=flux_lapse(matter,source,extra,offset)
                vals=mesh.points(field,RADII)
                edges.append(dict(model=model,epoch=epoch,test="quadratic-boundary-variation",multiplier=sign,
                    gradient_at_edge=extra,compensated_slip=contrast(vals),inner_slip=vals[1]-vals[0],
                    max_abs_slip=max(abs(field))))
    table(f"boundaries-{model}-{epoch}.csv",meta);table(f"mass-{model}-{epoch}.csv",massrows)
    table(f"spatial-corrections-{model}-{epoch}.csv",parts);table(f"lapse-matching-{model}-{epoch}.csv",edges)
    print(model,epoch,meta[0]["direct_flux_ratio"],massrows[0],parts[0],flush=True)
if __name__=="__main__":run(*sys.argv[1:])

