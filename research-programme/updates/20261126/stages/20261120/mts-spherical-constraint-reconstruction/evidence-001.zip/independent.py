from solve import *
from types import SimpleNamespace

def flux_lapse(matter,data,slope_extra=0.,offset=0.):
    mesh=matter.mesh;rad=mesh.r
    geometry=2*data["vprime"]**2
    grav=np.exp(4*data["spatial"])
    weight=grav*(geometry+matter.a**2*(1+data["beta"])**4*data["anis"])/rad
    edge_value=np.expm1(offset)
    edge_flux=np.exp(4*data["vedge"]+offset)*slope_extra/mesh.edge[-1]
    varied=np.full_like(rad,edge_value)
    for _ in range(30):
        flux=edge_flux+mesh.primitive((1+varied)*weight,True)
        updated=edge_value-mesh.primitive(rad*flux/grav,True)
        if max(abs(updated-varied))<1e-22:
            return -np.log1p(updated)
        varied=updated
    raise ArithmeticError("Exact lapse-flux solve")

def mass_check(matter,data):
    mesh=matter.mesh;rad=mesh.r;scale=matter.a;factor=1+data["beta"]
    area=scale*factor**2*rad
    tilt=2*rad*data["gradient"]/factor
    theta=data["expansion"];hub=matter.H
    left=.5*area*(theta*(theta+2*hub)*area**2-tilt*(2+tilt))
    energy=.5*area**2*data["energy"]*(scale*factor**2*(1+tilt))
    flow=.5*area**3*(hub+theta)*data["current"]
    radii=np.array([.10,.20,.35,1.,4.,12.])
    radii=radii[radii<=mesh.edge[-1]]
    center=mesh.points(left,radii)
    integrated=mesh.points(mesh.primitive(energy+flow),radii)
    current=mesh.points(mesh.primitive(flow),radii)
    residual=center-integrated
    return dict(max_mass_rel=float(max(abs(residual)/np.maximum(abs(center),1e-30))),
        current_test_error=float(max(abs(residual[:3]))/max(abs(current[:3]))),
        omitted_current_relative=float(max(abs(current[:3])/abs(center[:3]))),
        mass_at_three=center[:3].tolist(),current_at_three=current[:3].tolist())

def controls():
    from panels import Panels
    checks=[]
    for ratio in (0.,.6,1.):
        mesh=Panels(np.linspace(.1,1.,301),8);rad=mesh.r;mass=.024;charge=ratio*mass
        def solution(point):
            term=(mass**2-charge**2)/(4*point**2);scale=1+mass/point+term
            beta=np.sqrt(scale)-1
            spatial=-np.log(scale);normal=np.log1p(-term)+spatial
            derivative=-(mass/point+2*term)/(2*point*np.sqrt(scale))
            return beta,derivative,spatial,normal,(2*term/point)/(1-term)
        def sources(beta,gradient,lift):
            energy=charge**2/(rad*(1+beta)**2)**4
            return energy,np.zeros_like(rad),-2*energy
        fixture=SimpleNamespace(mesh=mesh,a=1.,H=0.,sources=sources)
        left=solution(mesh.edge[0]);right=solution(mesh.edge[-1]);truth=solution(rad)
        data=constraints(fixture,inner_flux=mesh.edge[0]**2*left[1],fixed_beta=right[0])
        clock,_,_=lapse(fixture,data,right[4],right[3]-right[2])
        flux=flux_lapse(fixture,data,right[4],right[3]-right[2])
        checks.append(dict(case=f"RN-{ratio:g}",spatial_error=max(abs(data["spatial"]-truth[2])),
            normal_expansion_error=max(abs(data["expansion"])),lapse_error=max(abs(clock-truth[3])),
            slip_error=max(abs(flux-(truth[2]-truth[3])))))
    import sympy as sym
    radius=sym.symbols("radius",real=True,positive=True)
    for amplitude in (0.,1.):
        mesh=Panels(np.linspace(0,1,163),8);rad=mesh.r
        hub=.08;shape=1-radius**2
        factor=1+amplitude*.004*shape**4
        spatial=-2*sym.log(factor);normal=spatial-amplitude*.0003*shape**5
        expansion=hub+amplitude*.0004*shape**3
        ricci=-8*(factor.diff(radius,2)+2*factor.diff(radius)/radius)/factor**5
        energy=ricci/2+3*(expansion**2-hub**2);current=2*expansion.diff(radius)
        anis=(spatial.diff(radius,2)-normal.diff(radius,2)-(spatial-normal).diff(radius)/radius+spatial.diff(radius)**2-normal.diff(radius)**2-2*normal.diff(radius)*spatial.diff(radius))/factor**4
        evaluate=lambda value:np.broadcast_to(sym.lambdify(radius,value,"numpy")(rad),rad.shape)
        sources=tuple(evaluate(expr) for expr in (energy,current,anis))
        fixture=SimpleNamespace(mesh=mesh,a=1.,H=hub,sources=lambda *_:sources)
        data=constraints(fixture)
        clock,_,_=lapse(fixture,data)
        checks.append(dict(case="expanding-current" if amplitude else "FLRW",
            spatial_error=max(abs(data["spatial"]-evaluate(spatial))),
            normal_expansion_error=max(abs(data["expansion"]-evaluate(expansion-hub))),
            lapse_error=max(abs(clock-evaluate(normal))),
            slip_error=max(abs(flux_lapse(fixture,data)-evaluate(spatial-normal)))))
    assert max(max(list(item.values())[1:]) for item in checks)<1e-11,checks
    table("analytic-controls.csv",checks)
    print(checks)
if __name__=="__main__":controls()

