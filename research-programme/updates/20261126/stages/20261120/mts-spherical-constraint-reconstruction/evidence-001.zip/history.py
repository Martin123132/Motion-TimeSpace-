from independent import *
from scipy.integrate import solve_ivp

SITES=np.linspace(.095,.355,1041)
DURATION=.084

def snapshot(model,epoch,seed,state,scale,cut,box,lift,level):
    regular=lift.endswith("-regular")
    matter=Matter(model,epoch,cut,.003125,6,box,2,prepared=(seed,state,scale),regular=regular)
    mesh=matter.mesh
    source=constraints(matter,lift.removesuffix("-regular"))
    delta=flux_lapse(matter,source)
    space=source["spatial"]
    lapse=space-delta
    normal_dot=-scale*(matter.H*np.expm1(lapse)+np.exp(lapse)*source["expansion"])
    newton=-mesh.primitive(mesh.primitive(.5*scale**2*mesh.r**2*(matter.rest-matter.bg))/mesh.r**2,True)
    j0=-.5*mesh.primitive(matter.j0,True)
    newton_dot=-scale*(matter.H*newton+j0)
    return {key:mesh.points(values,SITES) for key,values in (("V",space),("slip",delta),("Vkin",normal_dot),("N",newton),("Nkin",newton_dot))}
def run(model,epoch,level,steps,core=.00625,box=24.,lift="balanced"):
    seed,state,scale=fixture(model,epoch,level);lab=ActionSystem(seed,state)
    label=f"{model}-{epoch}-g{level}-n{steps}-rc{core:g}-L{box:g}-{lift}"
    direction=1 if epoch=="start" else -1
    times=np.linspace(0.,direction*DURATION,steps+1)
    scales=solve_ivp(lambda eta,val:val**2*seed.H(float(val[0])),(0.,times[-1]),[scale],t_eval=times,
        method="DOP853",rtol=1e-13,atol=1e-15,max_step=.015).y[0]
    assert min(scales)>=np.exp(seed.log_a[0]) and max(scales)<=np.exp(seed.log_a[-1])
    snapshots=[]
    for idx,at in enumerate(scales):
        guard()
        if idx:lab.advance(scales[idx-1],at)
        moved=dict(state,a=np.array(at))
        for species,(xpos,momentum,mass) in lab.dust.items():
            moved[species+"_x"]=xpos;moved[species+"_p"]=momentum
        if lab.psi is not None:moved["psi"]=lab.psi
        value=snapshot(model,epoch,seed,moved,at,core,box,lift,level)
        if idx==0:
            sample=lambda field:np.interp(RADII,SITES,value[field])
            note("before-evolution-"+label+".json",dict(a=at,eta_direction=direction,
                radii=RADII.tolist(),Vdot=sample("Vkin").tolist(),newtonian_Vdot=sample("Nkin").tolist(),
                V=sample("V").tolist(),slip=sample("slip").tolist()))
        snapshots.append(value)
    order=np.argsort(times)
    book={key:np.stack([frame[key] for frame in snapshots])[order] for key in snapshots[0]}
    buf=io.BytesIO()
    np.savez_compressed(buf,r=SITES,eta=times[order],a=scales[order],H=np.array([seed.H(at) for at in scales[order]]),**book)
    put("history-"+label+".npz",buf.getvalue());print(label,"link history saved",flush=True)
if __name__=="__main__":
    run(sys.argv[1],sys.argv[2],int(sys.argv[3]),int(sys.argv[4]),*(float(arg) for arg in sys.argv[5:7]),*sys.argv[7:])

