from optical import *
from scipy.integrate import quad

def run():
    times=np.linspace(0,.084,9);rad=np.linspace(.095,.355,1041);expansion=.14
    scales=np.exp(expansion*times)
    tests=[]
    for kind in ("static-expanding","homogeneous-evolving"):
        if kind=="static-expanding":
            spatial=lambda point:.18*point**2-.004
            lapse=lambda point:-.07*point**2+.001
            V=np.broadcast_to(spatial(rad),(9,len(rad)))
            U=np.broadcast_to(lapse(rad),(9,len(rad)))
        else:
            V=times[:,None]**2/10+np.zeros((9,len(rad)))
            U=-V/2
        packet=dict(r=rad,eta=times,a=scales,H=expansion/scales,N=V,V=V,slip=V-U)
        movie=Movie(packet,"constraint")
        for low,high in ARMS:
            mid=(low+high)/2
            result=movie.link(low,high)
            if kind=="static-expanding":
                index=lambda point:np.exp(-spatial(point)-lapse(point))
                delay=quad(index,low,mid)[0]-quad(index,mid,high)[0]
                expected=lapse(high)-lapse(low)+expansion*delay
            else:expected=0.
            defect=abs(result["received"]-expected)
            assert defect<3e-13
            tests.append(dict(case=kind,inner=low,expected=expected,computed=result["received"],error=defect))
    table("optical-controls.csv",tests)
    checks=[]
    for path in sorted(HERE.glob("history-*-g1-n8-rc0.00625-L24-*.npz")):
        with np.load(path,allow_pickle=False) as bank:packet=dict(bank)
        movie=Movie(packet,"constraint")
        for low,high in ARMS:
            mid=(low+high)/2;length=(high-low)/2;arrival=movie.times[-1]-.002
            for side in (-1,1):
                lag,rates,lapse=movie.path(mid,length,side,arrival,128)
                half=.00002
                late=movie.path(mid,length,side,arrival+half,128)[0]
                early=movie.path(mid,length,side,arrival-half,128)[0]
                paired=np.log1p((late-early)/(2*half))
                checks.append(dict(history=path.stem,low=low,side=side,jacobian=rates,from_two_pulses=paired,error=paired-rates))
    table("pulse-spacing-check.csv",checks)
    print("Optical controls",len(checks),max(abs(row["error"]) for row in checks))
if __name__=="__main__":run()

