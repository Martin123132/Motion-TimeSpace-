from records import *
from scipy.linalg import solve_banded

def projected_rates(matter,source,normal,normal_grad,newton_grad,species,scheme):
    mesh=matter.mesh;grid=mesh.edge;scale=matter.a
    pos,momentum,mass=matter.lab.dust[species]
    diff=np.diff(pos);rise=np.diff(momentum)
    left_force=np.zeros_like(pos);right_force=np.zeros_like(pos);seen=np.zeros_like(mass)
    sample,weight=roots_legendre(6)
    for orient in (-1,1):
        first=pos[:-1]*orient;last=pos[1:]*orient
        low=np.maximum(np.minimum(first,last),0.);high=np.maximum(np.maximum(first,last),0.)
        cell0=np.clip(np.searchsorted(grid,low,side="right")-1,0,len(grid)-2)
        cell1=np.clip(np.searchsorted(grid,high,side="left"),0,len(grid)-1)
        count=np.where(high>low,np.maximum(cell1-cell0,0),0)
        elements=np.repeat(np.arange(len(diff)),count)
        bins=np.arange(len(elements))+np.repeat(cell0-(np.cumsum(count)-count),count)
        for start in range(0,len(elements),3500):
            idx=elements[start:start+3500];cell=bins[start:start+3500]
            begin=np.maximum(grid[cell],low[idx]);finish=np.minimum(grid[cell+1],high[idx])
            half=.5*(finish-begin)
            radii=(begin+half)[:,None]+half[:,None]*sample
            frac=(orient*radii-pos[idx,None])/diff[idx,None]
            mom=momentum[idx,None]+rise[idx,None]*frac
            dm=mass[idx,None]*(idx[:,None]+frac)**2/(idx[:,None]**2+idx[:,None]+1/3)*weight*half[:,None]/abs(diff[idx,None])
            if scheme=="projected-geodesic":
                field=lambda values:mesh.points(values,radii.ravel()).reshape(radii.shape)
                spatial=field(source["spatial"]);lapse=field(normal);star2=(mom*np.exp(spatial)/scale)**2
                gamma=np.sqrt(1+star2)
                speed=mom/scale*np.exp(lapse+2*spatial)/gamma
                kick=-scale*np.exp(lapse)*orient*(gamma*field(normal_grad)+star2/gamma*field(source["vprime"]))
            else:
                speed=mom/scale;kick=-scale*orient*mesh.points(newton_grad,radii.ravel()).reshape(radii.shape)
            np.add.at(seen,idx,dm.sum(axis=1))
            for vec,acc in ((speed,left_force),(kick,right_force)):
                np.add.at(acc,idx,(dm*(1-frac)*vec).sum(axis=1))
                np.add.at(acc,idx+1,(dm*frac*vec).sum(axis=1))
    assert max(abs(seen-mass))/max(mass)<1e-11
    inertia=matter.lab.inertia[species][0]
    return tuple(np.r_[0.,solve_banded((1,1),inertia,values[1:-1],check_finite=False),0.] for values in (left_force,right_force))

