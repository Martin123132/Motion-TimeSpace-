from independent import *

def run():
    output=[]
    for epoch in ("start","end"):
        for lift in ("balanced","coordinate"):
            matter=Matter("heavy",epoch,.00625,.003125,8,24.,3,regular=True);mesh=matter.mesh
            source=constraints(matter,lift=lift);delta=flux_lapse(matter,source)
            clock=source["spatial"]-delta;lapse=np.exp(clock)
            factor=1+source["beta"];loggrad=source["gradient"]/factor
            weight=np.exp(4*source["spatial"]-delta)*(2*source["vprime"]**2+matter.a**2*factor**4*source["anis"])/mesh.r
            ugrad=source["vprime"]+mesh.r*np.exp(-4*source["spatial"]+delta)*mesh.primitive(weight,True)
            lab=matter.lab;spline=wave_spline(lab.r,lab.psi,3,True)
            psi=matter.psi;gradient=matter.grad;second=spline(mesh.r,nu=2)
            z=psi;prime=gradient;momentum=psi
            if lift=="balanced":
                z=psi/factor**3;momentum=psi*factor**3
                prime=(gradient-3*loggrad*psi)/factor**3
                second=(second-6*loggrad*gradient+(12*loggrad**2-3*(source["source"]-2*source["gradient"]/mesh.r)/factor)*psi)/factor**3
            mass=matter.seed.mass;scale=matter.a;hub=matter.H
            zdot=1.5*scale*hub*z+1j*scale*mass*(z-lapse*momentum/factor**6)
            slow=1j*lapse*factor**2/(scale*mass)*(second+(2/mesh.r+2*loggrad+ugrad)*prime)
            pdot=-1.5*scale*hub*momentum+1j*scale*mass*(momentum-lapse*factor**6*z)+slow
            qdot=(zdot.conj()*momentum+z.conj()*pdot).real
            reduced=(z.conj()*slow).real
            flux=mesh.r**2*lapse*factor**2*np.imag(z.conj()*prime)/(scale*mass)
            nr=mesh.r**2*np.imag(psi.conj()*gradient)/(scale*mass)
            flux_at=mesh.points(flux,RADII)
            for arm,(low,high) in enumerate(zip(RADII[:-1],RADII[1:])):
                occupied=np.diff(mesh.points(mesh.primitive(mesh.r**2*qdot),np.array([low,high])))[0]
                reduced_rate=np.diff(mesh.points(mesh.primitive(mesh.r**2*reduced),np.array([low,high])))[0]
                target=flux_at[arm]-flux_at[arm+1]
                norm=max(abs(flux_at[arm]),abs(flux_at[arm+1]),abs(target))
                delta_massrate=-.5*matter.seed.coeff["wave"]/scale*np.diff(mesh.points(mesh.primitive((flux-nr)/mesh.r**2),np.array([low,high])))[0]
                output.append(dict(epoch=epoch,lift=lift,arm=arm,canonical_time_rate=occupied,
                    boundary_rate=target,normalizer=norm,closure=(occupied-target)/norm,
                    fast_terms_cancel=(occupied-reduced_rate)/norm,metric_rate_change_from_transport=delta_massrate))
    table("scalar-canonical-flux.csv",output)
    print("Canonical KG current max error",max(abs(row["closure"]) for row in output),flush=True)
if __name__=="__main__":run()

