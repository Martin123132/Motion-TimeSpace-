from material import *
from history import SITES,DURATION
from galerkin import projected_rates

def fields(epoch,seed,state,scale,scheme,cut,need_output):
    matter=Matter("cold",epoch,cut,.003125,6,24.,prepared=(seed,state,scale))
    mesh=matter.mesh;source=constraints(matter)
    space=source["spatial"];delta=flux_lapse(matter,source);lapse=space-delta
    zsource=np.exp(4*space-delta)*(2*source["vprime"]**2+scale**2*(1+source["beta"])**4*source["anis"])/mesh.r
    ugrad=source["vprime"]+mesh.r*np.exp(-4*space+delta)*mesh.primitive(zsource,True)
    newton,ngrad=newtonian(matter)
    rhs={}
    for species in ("baryon","cdm"):
        coords=state[species+"_x"];mom=state[species+"_p"];radius=abs(coords)
        if scheme.startswith("projected-"):
            dx,dp=projected_rates(matter,source,lapse,ugrad,ngrad,species,scheme)
        elif scheme=="geodesic":
            potential=mesh.points(space,radius);time=mesh.points(lapse,radius)
            p2=(mom*np.exp(potential)/scale)**2
            gamma=np.sqrt(1+p2)
            dx=mom/scale*np.exp(time+2*potential)/gamma
            dp=-scale*np.exp(time)*np.sign(coords)*(gamma*mesh.points(ugrad,radius)+p2/gamma*mesh.points(source["vprime"],radius))
        else:
            dx=mom/scale;dp=-scale*np.sign(coords)*mesh.points(ngrad,radius)
        dx[[0,-1]]=0.;dp[[0,-1]]=0.
        rhs[species+"_x"]=dx;rhs[species+"_p"]=dp
    output=None
    if need_output:
        kin=-scale*(matter.H*np.expm1(lapse)+np.exp(lapse)*source["expansion"])
        newkin=-scale*(matter.H*newton-.5*mesh.primitive(matter.j0,True))
        output={key:mesh.points(value,SITES) for key,value in (("V",space),("slip",delta),("Vkin",kin),("N",newton),("Nkin",newkin))}
    return rhs,output

def run(epoch,labels,steps,scheme,cut):
    assert scheme in ("geodesic","newton","projected-geodesic","projected-newton")
    seed,original,scale=fixture("cold",epoch,0);state=subdivide(original,labels)
    times=np.linspace(0.,DURATION if epoch=="start" else -DURATION,steps+1)
    clock=solve_ivp(lambda _,val:val**2*seed.H(float(val[0])),(0.,times[-1]),[scale],
        method="DOP853",rtol=1e-13,atol=1e-15,max_step=.015,dense_output=True).sol
    scales=clock(times)[0];frames=[]
    label=f"cold-{epoch}-labels{labels}-n{steps}-{scheme}-rc{cut:g}"
    for idx,at in enumerate(times):
        guard()
        rhs,frame=fields(epoch,seed,state,scales[idx],scheme,cut,True)
        if not idx:
            predicted=np.interp(RADII,SITES,frame["Vkin"])
            note(label+"-before.json",dict(interval_conformal_mpc=DURATION,rate_at_sites=predicted.tolist(),scheme=scheme))
        frames.append(frame)
        if idx==steps:break
        delta=times[idx+1]-at
        midpoint=dict(state)
        for key,velocity in rhs.items():midpoint[key]=state[key]+delta*velocity/2
        mid_rhs,_=fields(epoch,seed,midpoint,float(clock(at+delta/2)[0]),scheme,cut,False)
        for key,velocity in mid_rhs.items():state[key]=state[key]+delta*velocity
    order=np.argsort(times)
    book={key:np.stack([frame[key] for frame in frames])[order] for key in frames[0]}
    buf=io.BytesIO()
    np.savez_compressed(buf,r=SITES,eta=times[order],a=scales[order],H=np.array([seed.H(at) for at in scales[order]]),**book)
    put("live-"+label+".npz",buf.getvalue());print(label,flush=True)
if __name__=="__main__":run(sys.argv[1],int(sys.argv[2]),int(sys.argv[3]),sys.argv[4],float(sys.argv[5]))

