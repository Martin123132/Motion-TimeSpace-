from matter import *
from scipy.interpolate import CubicSpline

RADII=np.array([.1,.2,.35])
WEIGHT=(RADII[1]**2-RADII[0]**2)/(RADII[2]**2-RADII[1]**2)
def contrast(values):return WEIGHT*(values[2]-values[1])-(values[1]-values[0])

def constraints(matter,lift="balanced",exterior="box",flow=True,inner_flux=0.,fixed_beta=None):
    mesh=matter.mesh;rad=mesh.r;scale=matter.a;hub=matter.H
    beta=np.zeros_like(rad);gradient=np.zeros_like(rad)
    for iteration in range(30):
        guard()
        energy,current,anis=matter.sources(beta,gradient,lift)
        departure=-.5*mesh.primitive(current,True) if flow else np.zeros_like(rad)
        source=scale**2*(1+beta)**5*(.75*departure*(2*hub+departure)-.25*energy)
        flux=inner_flux+mesh.primitive(rad**2*source)
        newgradient=flux/rad**2
        slope_edge=(inner_flux+mesh.primitive(rad**2*source,edges=True)[-1])/mesh.edge[-1]**2
        beta_edge=0. if exterior=="box" else -slope_edge*mesh.edge[-1]
        if fixed_beta is not None:beta_edge=fixed_beta
        updated=beta_edge-mesh.primitive(newgradient,True)
        defect=max(abs(updated-beta))
        beta,gradient=updated,newgradient
        if defect<2e-19 and iteration>=3:break
    else:raise ArithmeticError(("Hamiltonian iteration",defect))
    energy,current,anis=matter.sources(beta,gradient,lift)
    departure=-.5*mesh.primitive(current,True) if flow else np.zeros_like(rad)
    source=scale**2*(1+beta)**5*(.75*departure*(2*hub+departure)-.25*energy)
    factor=1+beta;spatial=-2*np.log1p(beta)
    vedge=-2*np.log1p(beta_edge);vprime=-2*gradient/factor
    return dict(beta=beta,gradient=gradient,vedge=vedge,vprime_edge=-2*slope_edge/(1+beta_edge),
        spatial=spatial,vprime=vprime,source=source,expansion=departure,current=current,energy=energy,anis=anis,
        iterations=iteration+1,defect=defect)

def lapse(matter,data,slope_extra=0.,offset=0.):
    mesh=matter.mesh;rad=mesh.r;scale=matter.a;beta=data["beta"];factor=1+beta
    gradient=data["gradient"];vprime=data["vprime"]
    coefficient=(-2*data["source"]/factor+6*gradient/(factor*rad)+6*(gradient/factor)**2-scale**2*factor**4*data["anis"])/rad
    outer=data["vedge"]+offset
    nedge=np.expm1(outer)
    slope=(1+nedge)*(data["vprime_edge"]+slope_extra)/mesh.edge[-1]
    lapse_minus_one=np.zeros_like(rad);scaled_slope=np.zeros_like(rad)
    for iteration in range(30):
        force=(1+lapse_minus_one)*coefficient-2*vprime*scaled_slope
        new_slope=slope-mesh.primitive(force,True)
        updated=nedge-mesh.primitive(rad*new_slope,True)
        defect=max(abs(updated-lapse_minus_one))
        lapse_minus_one,scaled_slope=updated,new_slope
        if defect<2e-19 and iteration>=3:break
    else:raise ArithmeticError(("direct lapse iteration",defect))
    return np.log1p(lapse_minus_one),iteration+1,defect

def solve_case(model,epoch,level,order,cut=.00625,outer=24.,exterior="box",lift="balanced",details=False):
    fixture=Matter(model,epoch,cut,.00625/2**level,order,outer)
    mesh=fixture.mesh;source=constraints(fixture,lift,exterior)
    normal,iterations,defect=lapse(fixture,source)
    space=source["spatial"];diff=space-normal
    radii=RADII
    values=mesh.points(diff,radii)
    three=contrast(values)
    energy=source["energy"];departure=source["expansion"]
    rates=mesh.points(departure,radii)
    target,=[float(row["contrast_V_minus_U"]) for row in rows(PARENT/"formed-tracefree-source.csv") if row["model"]==model and row["epoch"]==epoch and row["order"]=="10" and row["level"]=="2"]
    number=dict(model=model,epoch=epoch,a=fixture.a,level=level,order=order,core=cut,outer=outer,exterior=exterior,lift=lift,
        compensated_slip=three,frozen_prediction=target,relative_difference=(three-target)/target,
        inner_slip=values[1]-values[0],outer_slip=values[2]-values[1],
        newtonian_metric_span=mesh.points(space,radii)[1]-mesh.points(space,radii)[0],
        H_normal_minus_H_at_100_kpc=rates[0],H_normal_minus_H_at_200_kpc=rates[1],H_normal_minus_H_at_350_kpc=rates[2],
        hubble=fixture.H,h_iterations=source["iterations"],lapse_iterations=iterations,h_defect=source["defect"],lapse_defect=defect,
        cusp_8piG_energy_r2=sum(value[-1] for value in fixture.parts.values()),panels=len(mesh.width))
    return (number,fixture,source,normal) if details else number

if __name__=="__main__":
    model,epoch=sys.argv[1:3];values=[]
    for level,order in ((0,4),(0,6),(1,6),(2,6),(2,8)):
        value=solve_case(model,epoch,level,order)
        print(model,epoch,level,order,value["compensated_slip"],value["relative_difference"],flush=True)
        values.append(value)
    table(f"constraint-{model}-{epoch}.csv",values)

