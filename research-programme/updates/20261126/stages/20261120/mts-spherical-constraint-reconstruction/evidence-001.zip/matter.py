from panels import *
from scipy.interpolate import make_interp_spline
from inputs import dst

def dust_lift(xpos,momentum,mass,sites,cut,coefficient):
    indices=np.arange(len(mass));span=np.diff(xpos);change=np.diff(momentum)
    assert np.all(span!=0) and np.all(mass>0)
    density=mass*coefficient/(indices**2+indices+1/3)
    points,weights=roots_legendre(10)
    locations=[];loads=[];mom=[];core_mass=[];core_p=[]
    for side in (-1,1):
        start=side*xpos[:-1];stop=side*xpos[1:]
        minimum=np.minimum(start,stop);maximum=np.maximum(start,stop)
        low=np.searchsorted(sites,np.maximum(minimum,cut),side="left")
        high=np.maximum(low,np.searchsorted(sites,maximum,side="left"))
        count=high-low
        elements=np.repeat(indices,count)
        addresses=np.arange(len(elements))+np.repeat(low-(np.cumsum(count)-count),count)
        fraction=(sites[addresses]-start[elements])/(side*span[elements])
        locations.append(addresses)
        loads.append(density[elements]*(elements+fraction)**2/(abs(span[elements])*sites[addresses]**2))
        mom.append(side*(momentum[elements]+fraction*change[elements]))
        chosen=(maximum>0)&(minimum<cut)
        ids=indices[chosen]
        fa=np.clip(-start[ids]/(side*span[ids]),0,1)
        fb=np.clip((cut-start[ids])/(side*span[ids]),0,1)
        half=abs(fb-fa)/2
        frac=.5*(fa+fb)[:,None]+half[:,None]*points
        core_mass.append((density[ids,None]*(ids[:,None]+frac)**2*half[:,None]*weights).ravel()/(cut**3/3))
        core_p.append((side*(momentum[ids,None]+change[ids,None]*frac)).ravel())
    crossing=np.flatnonzero(xpos[:-1]*xpos[1:]<0)
    frac=-xpos[crossing]/span[crossing]
    cusp=float(2*np.sum(density[crossing]*(crossing+frac)**2/abs(span[crossing])))
    return np.concatenate(locations),np.concatenate(loads),np.concatenate(mom),np.concatenate(core_mass),np.concatenate(core_p),cusp

def wave_spline(rad,psi,doubles,regular=False):
    perturb=rad[1:-1]*(psi[1:-1]-1)
    origin=psi[0]
    if regular:
        modes=np.arange(1,len(rad)-1)*np.pi/rad[-1]
        origin=1+np.dot(modes,dst(perturb,type=1)/(len(rad)-1))
    for _ in range(doubles):perturb=sine_double(perturb)
    full=np.linspace(0,rad[-1],len(perturb)+2)
    expanded=np.r_[origin,1+perturb/full[1:-1],1.]
    reflected=np.r_[-full[5:0:-1],full]
    values=np.r_[expanded[5:0:-1],expanded]
    return make_interp_spline(reflected,values,k=5)

class Matter:
    def __init__(self,model,epoch,cut=.00625,h=.00625,order=6,outer=24.,doubles=2,prepared=None,regular=False):
        seed,state,self.a=fixture(model,epoch,0) if prepared is None else prepared;self.seed=seed
        self.H=float(seed.H(self.a));self.cut=cut
        lab=ActionSystem(seed,state);self.lab=lab
        self.mesh=mesh=grid(lab.dust,cut,h,order,outer)
        self.rad=sites=mesh.r;self.core=sites<cut
        self.iso=(sites[self.core]/cut)**2
        self.parts={key:dust_lift(xpos,momentum,mass,sites,cut,seed.coeff[key]/self.a**3) for key,(xpos,momentum,mass) in lab.dust.items()}
        self.rest=np.zeros_like(sites);self.j0=np.zeros_like(sites)
        for addresses,loads,mom,coremass,corep,_ in self.parts.values():
            self.rest+=np.bincount(addresses,loads,minlength=len(sites))
            self.j0+=np.bincount(addresses,loads*mom,minlength=len(sites))
            self.rest[self.core]+=sum(coremass)
            self.j0[self.core]+=self.iso*np.dot(coremass,corep)
        if lab.psi is not None:
            spline=wave_spline(lab.r,lab.psi,doubles,regular)
            self.psi=spline(sites);self.grad=spline(sites,nu=1)
            self.wave=seed.coeff["wave"]/self.a**3
            self.amp=abs(self.psi)**2
            self.rest+=self.wave*self.amp
            self.j0+=self.wave*np.imag(self.psi.conj()*self.grad)/seed.mass
        else:self.wave=0.
        self.bg=sum(seed.coeff.values())/self.a**3
        self.smooth_background=3*self.H**2-self.bg
    def sources(self,beta,grad_beta,lift="balanced"):
        radius=self.rad;scale=self.a;factor=1+beta
        correction=np.zeros_like(radius);anisotropy=np.zeros_like(radius)
        for addresses,loads,mom,coremass,corep,_ in self.parts.values():
            vel2=(mom/(scale*factor[addresses]**2))**2
            gamma=np.sqrt(1+vel2)
            correction+=np.bincount(addresses,loads*vel2/(gamma+1),minlength=len(radius))
            anisotropy+=np.bincount(addresses,loads*vel2/gamma,minlength=len(radius))
            vel2=(corep[None,:]/(scale*factor[self.core,None]**2))**2
            gamma=np.sqrt(1+vel2)
            correction[self.core]+=(vel2/(1+gamma))@coremass
            anisotropy[self.core]+=self.iso*((vel2/gamma)@coremass)
        inv6=factor**-6
        excess=(self.rest-self.bg)+self.rest*np.expm1(-6*np.log1p(beta))+inv6*correction
        anisotropy*=inv6
        if self.wave:
            if lift=="balanced":
                gradient=(self.grad-3*grad_beta*self.psi/factor)/factor**3
            elif lift=="coordinate":
                gradient=self.grad
                excess+=.5*self.wave*self.amp*np.expm1(-6*np.log1p(beta))**2
            else:raise ValueError(lift)
            wave_pressure=self.wave*abs(gradient/(self.seed.mass*scale*factor**2))**2
            excess+=.5*wave_pressure;anisotropy+=wave_pressure
        return excess,self.j0*inv6,anisotropy

