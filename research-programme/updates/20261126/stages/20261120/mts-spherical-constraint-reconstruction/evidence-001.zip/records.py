from pathlib import Path
import csv
import hashlib
import io
import json
import os
import sys

for name in ("OPENBLAS_NUM_THREADS","OMP_NUM_THREADS","MKL_NUM_THREADS","BLIS_NUM_THREADS","NUMEXPR_NUM_THREADS"):
    os.environ[name]="1"
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
PARENT=HERE.parent/"mts-finite-shell-response-20261120"
PIN="916d7b674e15dc2d940630983ef7ae7ab8cd878297e320155971e195beca0c5a"
def digest(path):
    with path.open("rb") as stream:return hashlib.file_digest(stream,"sha256").hexdigest()
assert digest(PARENT/"seal.json")==PIN
FILES=json.loads((PARENT/"seal.json").read_bytes())["files"]
for name in ("inputs.py","slip.py","formed-tracefree-source.csv"):
    assert digest(PARENT/name)==FILES[name]
sys.path.insert(0,str(PARENT))
from inputs import fixture,ActionSystem,TOL,np
from common import sine_double
from scipy.special import roots_legendre
def guard():
    if any((root/"STOP-REQUESTED").exists() for root in (HERE,HERE.parent,PARENT)):
        raise RuntimeError("Owner hold")
def put(name,data):
    guard();path=HERE/name
    if path.exists():assert path.read_bytes()==data,path
    else:
        with path.open("xb") as stream:stream.write(data)
def table(name,rows):
    stream=io.StringIO(newline="");writer=csv.DictWriter(stream,rows[0],lineterminator="\n")
    writer.writeheader();writer.writerows(rows);put(name,stream.getvalue().encode())
def note(name,record):put(name,(json.dumps(record,sort_keys=True,indent=2,allow_nan=False)+"\n").encode())
def rows(path):
    with path.open(newline="") as stream:return list(csv.DictReader(stream))

