import csv
import hashlib
import io
import json
import os
import sys
from pathlib import Path
for var in ("OMP_NUM_THREADS","OPENBLAS_NUM_THREADS","MKL_NUM_THREADS","NUMEXPR_NUM_THREADS","BLIS_NUM_THREADS"):
    os.environ[var]="1"
sys.dont_write_bytecode=True
import numpy as np
ROOT=Path(__file__).resolve().parent
OLD=ROOT.parent/"mts-live-formation-tide-20261120"
PIN="ce72f5b227bcd122eca3c66e6104181dc2af46eb6546ac4f0b8d3c21baa440a8"


def sha(path):
    with path.open("rb") as stream:return hashlib.file_digest(stream,"sha256").hexdigest()


assert sha(OLD/"seal.json")==PIN
sealed=json.loads((OLD/"seal.json").read_bytes())["files"]


def previous(name):
    path=OLD/name
    assert sha(path)==sealed[name],name
    return path


for name in ("native_input.py","evolve.py","radial_basis.py","current_swap.py","material_force.py","material_volume.py","source_gravity.py","direct_gravity.py","paired-transfer-forecast.csv"):
    previous(name)
sys.path.insert(0,str(OLD))
from native_input import AI, DLOG, prepare, camb, inherited, SPEC, NATIVE, source, obj, checked


def guard():
    assert not any((folder/"STOP-REQUESTED").exists() for folder in (ROOT,ROOT.parent,OLD))


def output(name,data):
    guard()
    path=ROOT/name
    if path.exists():assert path.read_bytes()==data,name
    else:
        temp=path.with_name(path.name+".partial")
        with temp.open("xb") as stream:stream.write(data)
        temp.rename(path)


def note(name,data):
    output(name,(json.dumps(data,indent=2,sort_keys=True,allow_nan=False)+"\n").encode())


def packet(name,**fields):
    raw=io.BytesIO()
    np.savez_compressed(raw,**fields)
    output(name,raw.getvalue())


def table(name,rows):
    raw=io.StringIO(newline="")
    wr=csv.DictWriter(raw,fieldnames=list(rows[0]),lineterminator="\n")
    wr.writeheader();wr.writerows(rows)
    output(name,raw.getvalue().encode("ascii"))


def rows(path):
    with path.open(newline="") as stream:return list(csv.DictReader(stream))


def acquire(model,extension=False):
    guard()
    parent_input=ROOT/(model+"-environment.npz") if extension else previous(model+"-native.npz")
    if extension:
        assert sha(ROOT/"frozen-crossover.csv")=="0a37e934b8228fee8f03ea9c3f0b519fec9ed316346e03656eb8d2c88b739380"
    with np.load(parent_input) as archive:
        old={name:archive[name] for name in archive.files}
    seed,epochs,_,_,_=prepare(model,0)
    status=obj(source("runs/"+model+"/status.json"))
    for path in inherited.native_hashes():checked(path,status["input_hashes"][str(path)])
    origin=SPEC/"runs/projection/a225-w6-d8.npz" if model=="heavy" else NATIVE/"runs/backgrounds/cold.npz"
    checked(origin,status["source_hash"])
    params=inherited.params_for(origin,background_boost=8.)
    params.DoLateRadTruncation=False
    bg=camb.get_background(params)
    bg.Params.Accuracy.IntTolBoost=6
    modes=old["k"]
    loga=DLOG*np.arange(-4,298 if extension else 266)/4
    scales=AI*np.exp(loga)
    earlier=epochs[epochs<min(scales)]
    times=bg.conformal_time(1/np.r_[earlier,scales]-1,tol=1e-10)
    names=["a","H","etak","Weyl","v_newtonian_cdm","v_newtonian_baryon","delta_cdm","delta_baryon","mts_drho_h","mts_q_h"]
    blocks=[]
    for chunk in sorted((SPEC/"runs"/model).glob("chunk-*.npz")):
        guard()
        with np.load(source(chunk.relative_to(SPEC).as_posix())) as part:
            selected=part["modes"][np.isin(part["modes"],modes)]
            if not len(selected):continue
            batch=np.unique(np.r_[selected,part["modes"].max()])
        data=bg.get_time_evolution(batch,times,vars=names,lAccuracyBoost=4)
        blocks.append((selected,data[np.searchsorted(batch,selected),len(earlier):]))
    np.testing.assert_array_equal(np.concatenate([block[0] for block in blocks]),modes)
    col=dict(zip(names,np.concatenate([block[1] for block in blocks]).transpose(2,0,1)))
    hub=col["H"]
    curvature=col["etak"]/modes[:,None]
    theta=-hub*col["v_newtonian_cdm"]
    phi=2*col["Weyl"]/modes[:,None]**2-curvature+hub*theta/modes[:,None]**2
    density=[col["delta_cdm"]-3*curvature,col["delta_baryon"]-3*curvature]
    velocities=[theta,-hub*col["v_newtonian_baryon"]]
    if model=="heavy":
        factor=col["a"]/seed.coeff["wave"]
        density.append(col["mts_drho_h"]*factor-3*curvature)
        velocities.append(modes[:,None]*col["mts_q_h"]*factor+theta)
    fields=dict(density=np.array(density),velocity=-np.array(velocities)/modes[None,:,None]**2,phi=phi,hub=hub[0])
    width=len(old["loga"])
    np.testing.assert_array_equal(loga[:width],old["loga"])
    audit={}
    for name,raw in fields.items():
        delta=raw[...,:width]-old[name]
        scale=np.max(abs(old[name]),axis=-1,keepdims=True)
        audit[name]=float(np.max(abs(delta)/np.maximum(scale,1e-30)))
        assert audit[name]<2e-8,(name,audit[name])
        raw[...,:width]=old[name]
    suffix="-holdout" if extension else ""
    packet(model+suffix+"-environment.npz",**{key:value for key,value in old.items() if key not in (*fields,"loga")},loga=loga,**fields)
    note(model+suffix+"-overlap.json",dict(previous_input=sha(parent_input),common_epochs=width,new_epochs=len(loga)-width,
         maximum_difference_on_each_mode_scale=audit,end_a=float(scales[-1]),native_truncation=False,mode_count=len(modes)))
    print(model,audit,flush=True)


if __name__=="__main__":
    for model in sys.argv[1:]:
        if model!="--holdout":acquire(model,"--holdout" in sys.argv)
