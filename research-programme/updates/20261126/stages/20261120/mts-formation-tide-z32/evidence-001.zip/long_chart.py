from stage import AI, DLOG, ROOT, np
from direct_gravity import Direct
from evolve import Chart
from scipy.special import spherical_jn
from scipy.interpolate import CubicSpline


class LongChart(Direct):
    def __init__(self,model,method="spectral",edge=24.,band=16.,degree=6,extension=False):
        super().__init__(model,edge,band,degree)
        self.method=method
        self.sources,self.gravity,self.wall="matter","live","native"
        self.freeze=method=="fixed"
        self.environment=ROOT/(model+("-holdout" if extension else "")+"-environment.npz")
        with np.load(self.environment) as arch:
            self.times=arch["loga"]
            self.hc=CubicSpline(self.times,arch["hub"],extrapolate=False)
            self.modes=arch["k"]
            self.selectors=[arch["scalar"],arch["shear"]]
            spectra=np.concatenate((arch["density"],arch["velocity"],arch["phi"][None]))
            matter=-np.einsum("s,skt->kt",arch["coeff"],arch["density"])/(2*AI*np.exp(self.times)*self.modes[:,None]**2)
            self.fourier=CubicSpline(self.times,spectra,axis=-1,extrapolate=False)
            self.shift_fourier=CubicSpline(self.times,matter-arch["phi"],axis=-1,extrapolate=False)
        self.ops=[]
        for ell in (0,2):
            val=spherical_jn(ell,np.outer(self.base.rad,self.modes))
            slope=spherical_jn(ell,np.outer(self.base.rad,self.modes),derivative=True)*self.modes
            self.ops.append((val,slope,-self.modes**2*val))
        self.cache={}
        self.block(8)
        self.first=self.trajectory(8*DLOG)[0]

    def block(self,unit):
        lo=np.searchsorted(self.times,unit*DLOG-1e-12)-1
        hi=np.searchsorted(self.times,(unit+8)*DLOG+1e-12)+1
        times=self.times[lo:hi]
        assert len(times)>=34 and times[0]<unit*DLOG and times[-1]>(unit+8)*DLOG
        def project(raw,change):
            values=[];shifts=[]
            for index,(ops,weight) in enumerate(zip(self.ops,self.selectors)):
                spec=raw*weight[None,:,None]
                grid=np.array([operator@spec for operator in ops])
                shift=ops[0]@(weight[:,None]*change)
                if index==0:
                    grid[0,self.count:]-=grid[0,self.count:,-1:].copy()
                    shift-=shift[-1:].copy()
                else:
                    harmonic=((ops[1][-1]+3/self.base.edge*ops[0][-1])@(weight[:,None]*change))/(5*self.base.edge)
                    shift-=self.base.rad[:,None]**2*harmonic
                values.append(grid);shifts.append(shift)
            return np.array(values),np.array(shifts)
        y,g=project(self.fourier(times),self.shift_fourier(times))
        dy,dg=project(self.fourier(times[[0,-1]],1),self.shift_fourier(times[[0,-1]],1))
        self.curve=CubicSpline(times,y,axis=-1,bc_type=((1,dy[...,0]),(1,dy[...,1])),extrapolate=False)
        self.matter_shift=CubicSpline(times,g,axis=-1,bc_type=((1,dg[...,0]),(1,dg[...,1])),extrapolate=False)
        self.cache={}

    def view(self,state,time,amp,mono):
        return (Chart.view if self.method=="spectral" else Direct.view)(self,state,time,amp,mono)
