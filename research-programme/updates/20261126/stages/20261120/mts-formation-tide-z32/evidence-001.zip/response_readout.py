"""Compare the independently evolved spherical-plus-quadrupole response with four native paths."""
from stage import ROOT,np,rows,table


def main():
    targets = {(r["branch"],int(r["window"]),float(r["aperture"])): r
               for r in rows(ROOT/"frozen-prediction-tests.csv") if r["forecast_law"]=="physical"}
    tests, compensation, attribution = [], [], []
    for model in ("heavy","cold"):
        for window in (16,32,64):
            def archive(uniform,band,sub):
                return np.load(ROOT/f"response-{model}-uniform{uniform}-K{band:.2f}-n{sub}-w{window:03d}.npz")
            with archive(0,15.97,8) as main, archive(0,19.90,8) as wide, archive(0,15.97,16) as fine, archive(1,15.97,8) as homogeneous:
                fields = main["fields"].tolist()
                cases = main["scenarios"].tolist()
                assert fields==["shape","cap_mass","cap_flux","local_source","poisson","partial_velocity"]
                for item in (main,wide,fine,homogeneous):
                    assert item["scenarios"].tolist()==cases and np.isfinite(item["series"]).all()
                    np.testing.assert_array_equal(item["series"][-1,fields.index("cap_flux")],item["cone"])
                    if model=="cold":
                        np.testing.assert_array_equal(item["series"][:,:,0],item["series"][:,:,2])
                base, hi, halfstep = [item["series"][-1].swapaxes(0,1) for item in (main,wide,fine)]
                for index,radius in enumerate((0.5,1.,2.)):
                    ref = targets[model,window,radius]
                    measured = float(ref["measured"])
                    for scenario, matrix in enumerate(base):
                        shape, cap, flux, source, potential, _ = matrix[:,index]
                        tests.append(dict(model=model,window=window,aperture=radius,scenario=cases[scenario],
                                          independent_shape=shape,paired_shape=measured,ratio_to_paired=shape/measured,
                                          higher_cutoff_shift_on_paired=(hi[scenario,0,index]-shape)/measured,
                                          half_step_shift_on_paired=(halfstep[scenario,0,index]-shape)/measured,
                                          relative_cap_flux_difference=(cap-flux)/max(abs(cap),abs(flux)),
                                          homogeneous_forecast_error=float(ref["relative_error"])))
                    for label, item in (("stratified",main),("uniform",homogeneous)):
                        actual = item["series"][-1].swapaxes(0,1)
                        for scenario in (4,5):
                            compensation.append(dict(model=model,foreground=label,window=window,aperture=radius,
                                                     case=cases[scenario],initial_current_rms_fraction=float(item["current_residual_rms_fraction"]),
                                                     potential=actual[scenario,4,index],uncompensated_potential=actual[0,4,index],
                                                     ratio=actual[scenario,4,index]/actual[0,4,index],
                                                     local_density_source=actual[scenario,3,index]))
                    full,no_g,no_d,passive = base[:4,0,index]
                    interaction = full-no_g-no_d+passive
                    attribution.append(dict(model=model,window=window,aperture=radius,passive=passive,
                                            gravity_only_increment=no_d-passive,dispersion_only_increment=no_g-passive,
                                            interaction=interaction,total_shape=full))
    table("independent-response-tests.csv",tests)
    table("balanced-finite-responses.csv",compensation)
    table("response-force-switches.csv",attribution)
    for row in tests:
        if row["scenario"]=="physical" and row["window"]==64 and row["aperture"]==1:print(row)


if __name__=="__main__":main()
