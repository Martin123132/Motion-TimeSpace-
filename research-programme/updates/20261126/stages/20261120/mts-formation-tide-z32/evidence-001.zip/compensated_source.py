"""Local Taylor prediction and mode evolution with a balanced initial matter current."""
import sys
from stage import AI, DLOG, ROOT, np, rows, sha, table
from scipy.integrate import quad, solve_ivp
from scipy.interpolate import CubicSpline
from scipy.special import spherical_jn


OFFSETS = (0.000125,0.00025,0.0005,0.001,0.002,0.004,0.008)
APERTURES = (0.5,0.75,1.,1.5,2.)
FACTORS = (0.5,1.,2.)


def setup(model):
    other = "cold" if model=="heavy" else "heavy"
    with np.load(ROOT/(model+"-environment.npz")) as own, np.load(ROOT/(other+"-environment.npz")) as donor:
        slot = np.flatnonzero(own["loga"]==0).item()
        target = -1 if model=="heavy" else 0
        np.testing.assert_array_equal(own["k"], donor["k"])
        wavenumber, coefficients = own["k"], own["coeff"]
        amplitude = own["shear"]*(donor["velocity"][0 if model=="heavy" else -1,:,slot]-own["velocity"][target,:,slot])
        hub = CubicSpline(own["loga"],own["hub"],extrapolate=False)
        radius = np.outer(np.array(APERTURES)*float(own["radius"]), wavenumber)
        readout = {"potential": spherical_jn(2,radius),
                   "radial_acceleration": -spherical_jn(2,radius,derivative=True)*wavenumber}
        return wavenumber, float(own["mass"]), coefficients[target], coefficients.sum(), amplitude, hub, readout


def forecast():
    modes, mass, coeff, _, amplitude, hub, ops = setup("heavy")
    predictions = []
    for factor in FACTORS:
        third = coeff*modes**4*amplitude/(8*AI**3*(factor*mass)**2)
        for offset in OFFSETS:
            duration = quad(lambda time: 1/float(hub(time)),0,offset)[0]
            for name, operator in ops.items():
                leading = operator@third * duration**3/6
                for index, aperture in enumerate(APERTURES):
                    predictions.append(dict(mass_factor=factor,offset=offset,conformal_interval=duration,aperture=aperture,
                                            field=name,third_derivative=(operator@third)[index],cubic=leading[index],
                                            quartic=leading[index]*(1-2.5*hub(0)*duration)))
    table("balanced-frozen-source.csv",predictions)
    print("freeze",sha(ROOT/"balanced-frozen-source.csv"))


def solve(model,factor,offsets,refine):
    modes, mass, target, total, amplitude, hub, ops = setup(model)
    start_hub = hub(0)
    initial = np.zeros((4,len(modes)))
    initial[3] = 1
    def rhs(time,flat):
        summed, momentum, density, velocity = flat.reshape(initial.shape)
        scale = AI*np.exp(time)
        local_hub = hub(time)
        dispersion = modes**4/(4*(factor*mass*scale)**2) if factor else 0.
        return np.stack((start_hub/local_hub*momentum,
                         -momentum+(total*summed/(2*scale)-dispersion*density)/(start_hub*local_hub),
                         start_hub/local_hub*velocity,
                         -velocity+(target*summed/(2*scale)-dispersion*density)/(start_hub*local_hub))).ravel()
    state = initial.ravel()
    start = 0.
    samples = []
    for stop in offsets:
        result = solve_ivp(rhs,(start,stop),state,method="DOP853",rtol=2e-12 if refine else 2e-10,
                           atol=1e-23 if refine else 1e-21,max_step=min((stop-start)/(4 if refine else 2),.025))
        assert result.success
        state = result.y[:,-1]
        summed = state.reshape(initial.shape)[0]
        if not factor: assert not summed.any() and not state.reshape(initial.shape)[1].any()
        potential = -target*amplitude*summed/(2*AI*np.exp(stop)*start_hub)
        samples.append({name: op@potential for name,op in ops.items()})
        start = stop
    return samples


def check(pin):
    assert len(pin)==64 and sha(ROOT/"balanced-frozen-source.csv")==pin
    predictions = {(float(row["mass_factor"]),float(row["offset"]),row["field"],float(row["aperture"])):row
                   for row in rows(ROOT/"balanced-frozen-source.csv")}
    checks = []
    late = []
    epochs = (*OFFSETS,8*DLOG,32*DLOG,64*DLOG)
    for model, factor in [("heavy",value) for value in FACTORS]+[("heavy",0),("cold",0)]:
        samples = solve(model,factor,epochs,False)
        control = solve(model,factor,epochs,True)
        for idx,offset in enumerate(epochs):
            for field,vector in samples[idx].items():
                for column, aperture in enumerate(APERTURES):
                    got = vector[column]
                    if factor and offset in OFFSETS:
                        row = predictions[factor,offset,field,aperture]
                        approx = float(row["quartic"])
                        prev = predictions[factor,epochs[idx-1],field,aperture] if idx else None
                        power = (np.log(abs(got/samples[idx-1][field][column]))/
                                 np.log(float(row["conformal_interval"])/float(prev["conformal_interval"]))) if prev else ""
                        checks.append(dict(model=model,mass_factor=factor,offset=offset,field=field,aperture=aperture,
                                           measured=got,cubic_error_ppm=1e6*(float(row["cubic"])/got-1),
                                           quartic_error_ppm=1e6*(approx/got-1),observed_power=power,
                                           refinement_ppm=1e6*(control[idx][field][column]/got-1),
                                           within_20ppm=abs(approx/got-1)<=2e-5))
                    else:
                        if not factor: assert got==control[idx][field][column]==0.
                        late.append(dict(model=model,mass_factor=factor,offset=offset,field=field,aperture=aperture,
                                         measured=got,refined=control[idx][field][column]))
    assert len(checks)==len(predictions)
    table("balanced-source-tests.csv",checks)
    table("balanced-source-extensions-and-dust-nulls.csv",late)
    for row in checks:
        if row["mass_factor"]==row["aperture"]==1 and row["field"]=="potential":print(row)


if __name__=="__main__":
    if sys.argv[1:]==["freeze"]:forecast()
    else:
        assert len(sys.argv)==3 and sys.argv[1]=="test"
        check(sys.argv[2])
