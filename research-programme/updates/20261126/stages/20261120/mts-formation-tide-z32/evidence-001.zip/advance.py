import argparse
from stage import AI,DLOG,ROOT,guard,np,packet,previous,sha
from long_chart import LongChart
from material_volume import Surface
from evolve import step_add
from scipy.interpolate import CubicSpline
from numpy.polynomial.legendre import leggauss

EPS=1e-16


def old_tag(model,case):
    label="lin" if case=="swap" else case
    return model+"-K15.97-m1-n64-window8-"+label+"-inside-matter"+("-swapped-current" if case=="swap" else "")+"-force.npz"


def initialize(chart,case,surface):
    original=previous(old_tag(chart.model,case))
    with np.load(original) as packet0:
        state=tuple(packet0[key] for key in ("coeff","markers","flux"))
        frame=packet0["frames"][-1]
    label="lin" if case=="swap" else case
    with np.load(previous(chart.model+"-volume-q12-n64-"+label+".npz")) as arch:
        caps=arch["final_surface"]
        np.testing.assert_array_equal(surface.nodes,arch["nodes"])
    if label=="lin":
        monopole=state[1][0].real
        dq=(state[1][0]-state[1][1]).imag*(2/3)
        reconstructed=monopole[:,None]+1j*dq[:,None]*(3*surface.nodes**2-1)/2
        if case=="lin":
            np.testing.assert_allclose(caps.imag/EPS,reconstructed.imag/EPS,rtol=2e-5,atol=2e-12)
        else:
            np.testing.assert_allclose(caps.real,np.broadcast_to(monopole[:,None],caps.shape),rtol=2e-13,atol=0)
            caps=reconstructed
    return state,caps,np.zeros(3,dtype=caps.dtype),frame,sha(original)


def shell_forces(chart,state,t,amp):
    base=chart.base
    density,derivative,lap,_,_,_,scale=chart.view(state,t,amp,1.)
    edge=base.edge; r=base.rad; radius=chart.radii
    center=chart.trajectory(t)[0]
    exterior=(center[1,1,-1,-1]+3/edge*center[1,0,-1,-1])/(5*edge)
    pos=state[1][0].real
    split=(state[1][0]-state[1][1]).imag/EPS
    assert np.max(abs(state[1][0].real-state[1][1].real))<1e-12
    nodes,w=leggauss(8)
    half=(pos-radius)/2
    points=radius[:,None]+half[:,None]*(1+nodes)
    fields=[]
    for index,coeff in enumerate(chart.coeff):
        isotropic=density[index,0].real*coeff/(2*scale)
        quad=density[index,1].imag/EPS*coeff/(2*scale)
        iso=CubicSpline(r,isotropic);fun=CubicSpline(r,quad)
        inside0=base.weights_ball@(isotropic*r**2)+half*((iso(points)*points**2)@w)
        slope=-iso(pos)+2*inside0/pos**3
        inside=base.weights_ball@(quad*r**4)+half*((fun(points)*points**4)@w)
        outside=(base.dr-base.weights_ball)@(quad/r)-half*((fun(points)/points)@w)
        fields.extend((slope*split,-.9*inside/pos**4,.6*pos*outside))
    fields.append(-3*exterior*pos)
    pressure=np.zeros_like(pos)
    if chart.effect:
        index=chart.target
        number=1+density[index,0].real
        grad=derivative[index,0].real
        lap0=lap[index,0].real
        dn=density[index,1].imag/EPS
        weight=1/(4*(scale*chart.mass)**2)
        q0=weight*(lap0/number-.5*(grad/number)**2)
        q2=weight*(lap[index,1].imag/EPS/number-lap0*dn/number**2-grad*(derivative[index,1].imag/EPS)/number**2+grad**2*dn/number**3)
        pressure=1.5*CubicSpline(r,q2)(pos,1)+split*CubicSpline(r,q0)(pos,2)
    fields.append(pressure)
    vel=base.poles@derivative[chart.count+chart.target]
    speeds=[]
    for line,pts in zip(vel,state[1]):
        curve=CubicSpline(r,line)
        speeds.append(curve(pts.real).imag/EPS+pts.imag/EPS*curve(pts.real,1).real)
    fields.append(speeds[0]-speeds[1])
    return np.array(fields)


def tag(model,case,method,sub,unit):
    return f"{model}-{case}-{method}-n{sub}-w{unit:03d}.npz"


def run(model,case,method,sub,begin,end):
    guard()
    assert begin>=8 and end<=72 and begin%8==end%8==0 and end>begin
    extension=end>64
    if extension:
        assert begin==64 and sha(ROOT/"frozen-crossover.csv")=="0a37e934b8228fee8f03ea9c3f0b519fec9ed316346e03656eb8d2c88b739380"
    chart=LongChart(model,method,extension=extension)
    surface=Surface(chart,12)
    amp=1j*EPS if case in ("lin","swap") else float(case)
    if begin==8:
        state,caps,integral,initial_frame,origin=initialize(chart,case,surface)
    else:
        sourcepath=ROOT/tag(model,case,method,8 if extension else sub,begin)
        with np.load(sourcepath) as old:
            state=tuple(old[name] for name in ("coeff","markers","flux"))
            caps,integral=old["caps"],old["cone"][-1]
            initial_frame=old["frames"][-1]
        origin=sha(sourcepath)
    for unit in range(begin,end,8):
        chart.block(unit)
        name=tag(model,case,method,sub,unit+8)
        path=ROOT/name
        if path.exists():
            with np.load(path) as old:
                assert old["restart_sha256"].item()==origin
                state=tuple(old[k] for k in ("coeff","markers","flux"))
                caps,integral=old["caps"],old["cone"][-1]
                initial_frame=old["frames"][-1]
            origin=sha(path)
            continue
        count=8*sub
        step=DLOG/sub
        now=unit*DLOG
        frames=[];masses=[];cones=[];forces=[];times=[]
        def field(st,cap,t):
            rates=chart.rates(st,t,amp,1.)
            sr,cr=surface.calculate(st,t,amp,cap)
            return rates,sr,cr
        for idx in range(count+1):
            guard()
            now=(unit+idx/sub)*DLOG
            if idx%sub==0 or extension:
                read=chart.rates(state,now,amp,1.,True)
                mass=surface.calculate(state,now,amp,caps,True)
                assert np.isfinite(read).all() and np.isfinite(mass).all()
                if idx==0:
                    for component in (lambda v:v.real,lambda v:v.imag/EPS):
                        lhs,rhs=component(read[:9]),component(initial_frame[:9])
                        np.testing.assert_allclose(lhs,rhs,rtol=2e-5,atol=1e-14)
                frames.append(read);masses.append(mass);cones.append(integral.copy());times.append(now)
                if np.iscomplexobj(caps):forces.append(shell_forces(chart,state,now,amp))
            if idx==count:break
            one,s1,c1=field(state,caps,now)
            two,s2,c2=field(step_add(state,one,step/2),caps+s1*step/2,now+step/2)
            three,s3,c3=field(step_add(state,two,step/2),caps+s2*step/2,now+step/2)
            four,s4,c4=field(step_add(state,three,step),caps+s3*step,now+step)
            state=tuple(a+step/6*(b+2*c+2*d+e) for a,b,c,d,e in zip(state,one,two,three,four))
            caps=caps+step/6*(s1+2*s2+2*s3+s4);integral=integral+step/6*(c1+2*c2+2*c3+c4)
        packet(name,coeff=state[0],markers=state[1],flux=state[2],caps=caps,cone=cones,masses=masses,forces=forces,
               times=times,radii=chart.radii,frames=frames,restart_sha256=origin,environment_sha256=sha(chart.environment))
        initial_frame=frames[-1];origin=sha(path)
        print(name,"a",AI*np.exp(now),"min density",read[9,0].real,flush=True)


if __name__=="__main__":
    parser=argparse.ArgumentParser()
    parser.add_argument("model")
    parser.add_argument("cases")
    parser.add_argument("--method",choices=["spectral","direct","fixed"],default="spectral")
    parser.add_argument("--sub",type=int,default=8)
    parser.add_argument("--begin",type=int,default=8)
    parser.add_argument("--end",type=int,default=64)
    args=parser.parse_args()
    for case in args.cases.split(","):run(args.model,case,args.method,args.sub,args.begin,args.end)
