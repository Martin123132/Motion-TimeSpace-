"""Use uncompacted, component-by-component canonical momenta to check the common potential."""
from stage import AI,DLOG,ROOT,np,rows,table
from compensated_source import APERTURES,FACTORS,setup
from scipy.integrate import solve_ivp


def canonical(model,factor):
    modes, mass, _, _, amplitude, hub, ops = setup(model)
    with np.load(ROOT/(model+"-environment.npz")) as env:
        coeff = env["coeff"]
    target, partner = (-1,0) if model=="heavy" else (0,1)
    hub0 = hub(0)
    initial = np.zeros((2,len(coeff),len(modes)))
    initial[1,target] = 1.
    initial[1,partner] = -coeff[target]/coeff[partner]
    epochs = DLOG*np.array((8.,32.,64.))
    def rhs(time,flat):
        density, canonical_speed = flat.reshape(initial.shape)
        scale_ratio = np.exp(time)
        local_hub = hub(time)
        source = (coeff@density)/(2*AI*hub0*local_hub)
        drive = np.broadcast_to(source,canonical_speed.shape).copy()
        if factor:
            drive[target] -= modes**4*density[target]/(4*AI**2*scale_ratio*(mass*factor)**2*hub0*local_hub)
        return np.stack((hub0/(scale_ratio*local_hub)*canonical_speed,drive)).ravel()
    result = solve_ivp(rhs,(0,epochs[-1]),initial.ravel(),t_eval=epochs,method="DOP853",
                       max_step=.006,atol=2e-16,rtol=3e-13)
    assert result.success
    density = result.y.reshape((*initial.shape,len(epochs)))[0]
    summand = coeff[:,None,None]*density
    potential = -summand.sum(axis=0)*amplitude[:,None]/(2*AI*np.exp(epochs)*hub0)
    singles = -(summand*amplitude[None,:,None])/(2*AI*np.exp(epochs)*hub0)
    return epochs, {name:op@potential for name,op in ops.items()}, {
        name:np.sum(abs(np.einsum("ak,skt->sat",op,singles)),axis=0) for name,op in ops.items()}


def main():
    data = {(row["model"],float(row["mass_factor"]),float(row["offset"]),float(row["aperture"]),row["field"]):float(row["measured"])
            for row in rows(ROOT/"balanced-source-extensions-and-dust-nulls.csv")}
    checks = []
    for model,factor in [("heavy",item) for item in FACTORS]+[("heavy",0),("cold",0)]:
        epochs, outputs, scales = canonical(model,factor)
        for field,array in outputs.items():
            for index,aperture in enumerate(APERTURES):
                for slot,time in enumerate(epochs):
                    target = data[model,factor,time,aperture,field]
                    measured = array[index,slot]
                    scale = abs(target) if factor else scales[field][index,slot]
                    assert scale>0 and abs((measured-target)/scale)<2e-5
                    checks.append(dict(model=model,mass_factor=factor,window=(8,32,64)[slot],field=field,aperture=aperture,
                                       aggregate=target,separate_species=measured,error_fraction=(measured-target)/scale,
                                       error_denominator="absolute induced signal" if factor else "sum of absolute component fields"))
    table("balanced-independent-species.csv",checks)
    print("canonical",len(checks),"worst relative error",max(abs(row["error_fraction"]) for row in checks))


if __name__=="__main__":main()
