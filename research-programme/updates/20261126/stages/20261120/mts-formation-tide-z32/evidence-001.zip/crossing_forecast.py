from stage import AI, DLOG, ROOT, np, previous, sha, table
from scipy.interpolate import CubicSpline


def pack(model):
    with np.load(ROOT/(model+"-swap-spectral-n8-w064.npz")) as last:
        t=last["times"]
        radii=last["radii"]
        speed=last["forces"][:,-1]/radii
        force=last["forces"][:,:-1].sum(axis=1)/radii
        shape=(last["markers"][0]-last["markers"][1]).imag/(1e-16*radii)
    with np.load(ROOT/(model+"-environment.npz")) as env:
        hub=CubicSpline(env["loga"],env["hub"],extrapolate=False)
    h=hub(t);hx=hub(t,1)/h; dh=hub(t,2)/h-hx**2
    first=speed/h[:,None]
    second=force/h[:,None]**2-(1+hx[:,None])*first
    dforce=(3*force[-1]-4*force[-2]+force[-3])/(2*DLOG)
    third=(dforce-2*hx[-1]*force[-1])/h[-1]**2-dh[-1]*first[-1]-(1+hx[-1])*second[-1]
    return np.stack((shape,first[-1],second[-1]/2,third/6))


def main():
    coeff=pack("heavy")-pack("cold")
    rows=[]
    for j,ap in enumerate((.5,1,2)):
        for degree in (1,2,3):
            solutions=np.polynomial.Polynomial(coeff[:degree+1,j]).roots()
            allowed=[x.real for x in solutions if abs(x.imag)<1e-12 and 0<x.real<=DLOG*32]
            assert allowed,(ap,degree)
            delta=min(allowed)
            rows.append(dict(aperture=ap,order=degree,window=64+delta/DLOG,a=AI*np.exp(64*DLOG+delta),
                             redshift=1/(AI*np.exp(64*DLOG+delta))-1,gap=coeff[0,j],slope=coeff[1,j],
                             curvature=2*coeff[2,j],third_derivative=6*coeff[3,j]))
    table("frozen-crossover.csv",rows)
    print(sha(ROOT/"frozen-crossover.csv"))
    for row in rows:
        if row["order"]==3:print(row)


if __name__=="__main__":main()
