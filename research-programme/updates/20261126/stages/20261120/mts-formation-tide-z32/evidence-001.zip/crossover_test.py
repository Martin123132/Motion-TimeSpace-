"""Test the signed root on new epochs without modifying the frozen forecast."""
from stage import AI, DLOG, ROOT, np, rows, sha, table
from scipy.interpolate import CubicHermiteSpline, CubicSpline
from scipy.optimize import brentq


FORECAST = "0a37e934b8228fee8f03ea9c3f0b519fec9ed316346e03656eb8d2c88b739380"
APERTURES = (0.5, 1., 2.)


def path(model, case, method, sub):
    name = f"{model}-{case}-{method}-n{sub}-w072.npz"
    env = ROOT / (model + "-holdout-environment.npz")
    restart = ROOT / f"{model}-{case}-{method}-n8-w064.npz"
    with np.load(ROOT/name) as data, np.load(env) as native, np.load(restart) as parent:
        assert str(data["restart_sha256"]) == sha(restart) and str(data["environment_sha256"]) == sha(env)
        np.testing.assert_array_equal(data["radii"], parent["radii"])
        times = data["times"]
        np.testing.assert_allclose(times/DLOG, 64+np.arange(8*sub+1)/sub, rtol=0, atol=3e-14)
        hub = CubicSpline(native["loga"], native["hub"], extrapolate=False)(times)
        radius = data["radii"]
        frames = data["frames"]
        form = (frames[:,5]-frames[:,6]).imag / (1e-16*radius)
        speed = data["forces"][:,-1] / (hub[:,None]*radius)
        marker = (data["markers"][0]-data["markers"][1]).imag / (1e-16*radius)
        np.testing.assert_allclose(form[-1], marker, rtol=1e-12, atol=0)
        return times, form, speed


def interpolants(case, method, sub):
    heavy = path("heavy",case,method,sub)
    cold = path("cold",case,method,sub)
    np.testing.assert_array_equal(heavy[0],cold[0])
    times = heavy[0]
    return times, [CubicHermiteSpline(times, form, rate, axis=0, extrapolate=False)
                   for _, form, rate in (heavy, cold)]


def roots(method, sub):
    times, pair = interpolants("swap",method,sub)
    found = []
    for index in range(3):
        gap = CubicHermiteSpline(times, (pair[0](times)-pair[1](times))[:,index],
                                (pair[0](times,1)-pair[1](times,1))[:,index], extrapolate=False)
        candidates = gap.roots(extrapolate=False)
        assert len(candidates) == 1 and times[0] < candidates[0] < times[-1]
        signs = gap(times)
        brackets = np.flatnonzero((signs[:-1]<0)&(signs[1:]>0))
        assert len(brackets) == 1
        left, right = times[brackets[0]:brackets[0]+2]
        root = brentq(gap,left,right,xtol=1e-15)
        assert abs(root-candidates[0])<2e-14 and gap(root,1)>0
        straight = left - gap(left)*(right-left)/(gap(right)-gap(left))
        found.append((root,left,right,straight,gap(root,1)))
    return np.array(found)


def main():
    assert sha(ROOT/"frozen-crossover.csv") == FORECAST
    forecast = rows(ROOT/"frozen-crossover.csv")
    measured = roots("spectral",8)
    finer = roots("spectral",16)
    independent = roots("fixed",8)
    _, native = interpolants("lin","spectral",8)
    _, swapped = interpolants("swap","spectral",8)
    tests, shares = [], []
    for index, aperture in enumerate(APERTURES):
        actual,left,right,linear,slope = measured[index]
        elapsed = actual-64*DLOG
        for row in [item for item in forecast if float(item["aperture"])==aperture]:
            forecast_time = float(row["window"])*DLOG
            error = (forecast_time-actual)/elapsed
            tests.append(dict(aperture=aperture,order=row["order"],forecast_window=row["window"],
                              bracket_from=left/DLOG,bracket_to=right/DLOG,measured_window=actual/DLOG,
                              fine_window=finer[index,0]/DLOG,raw_poisson_window=independent[index,0]/DLOG,
                              measured_redshift=np.exp(-actual)/AI-1,gap_slope=slope,
                              elapsed_error_ppm=1e6*error,within_20ppm=abs(error)<=2e-5,
                              linear_interpolation_shift_ppm=1e6*(linear-actual)/elapsed,
                              half_step_shift_ppm=1e6*(finer[index,0]-actual)/elapsed,
                              raw_poisson_shift_ppm=1e6*(independent[index,0]-actual)/elapsed))
        for point, time in (("before",64*DLOG),("crossing",actual),("after",72*DLOG)):
            wave, cold = [curve(time)[index] for curve in native]
            changed_wave, changed_cold = [curve(time)[index] for curve in swapped]
            gap = wave-cold
            exchanged = changed_wave-changed_cold
            motion = ((wave-changed_wave)+(changed_cold-cold))/2
            remaining = ((wave-changed_cold)+(changed_wave-cold))/2
            assert gap>0 and abs(motion+remaining-gap)<1e-15 and abs(remaining-motion-exchanged)<1e-15
            if point=="crossing": assert abs(exchanged)<1e-14
            shares.append(dict(aperture=aperture,point=point,window=time/DLOG,wave=wave,cold=cold,
                               wave_with_cold_velocity=changed_wave,cold_with_wave_velocity=changed_cold,
                               native_gap=gap,exchanged_gap=exchanged,native_motion_share=motion/gap,
                               remaining_share=remaining/gap))
    table("heldout-crossings.csv",tests)
    table("paired-attribution.csv",shares)
    for row in tests:
        if row["order"]=="3":print(row)


if __name__ == "__main__":
    main()
