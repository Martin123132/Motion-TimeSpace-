from stage import ROOT,rows,table


def main():
    lookup = {(r["branch"],r["case"],r["window"],r["aperture"]):r for r in rows(ROOT/"force-accounts.csv")}
    output = []
    for currents, wave, cold in (("original","lin","lin"),("shared_wave","lin","swap"),("shared_cold","swap","lin"),("exchanged","swap","swap")):
        for window in ("16","32","64"):
            for aperture in ("0.5","1","2"):
                left = lookup["heavy",wave,window,aperture]
                right = lookup["cold",cold,window,aperture]
                def diff(*keys):
                    assert all(right[key] or key in ("wave_inside","wave_outside","wave_sampled") for key in keys)
                    return sum(float(left[key])-float(right[key] or 0) for key in keys)
                terms = {key:diff(key) for key in ("initial_motion","early_gravity_not_exterior")}
                terms["exterior"] = diff("early_exterior","exterior")
                terms["wave_gradient"] = diff("early_gradient","wave_gradient")
                for region in ("inside","outside","sampled"):
                    terms["late_dark_"+region]=diff("cdm_"+region,"wave_"+region)
                    terms["late_baryon_"+region]=diff("baryon_"+region)
                measured = diff("shape")
                total = sum(terms.values())
                output.append(dict(currents=currents,window=window,aperture=aperture,gap=measured,**terms,
                                   reconstructed=total,error_on_gap=(total-measured)/measured))
    table("paired-source-ledger.csv",output)
    for row in output:
        if row["currents"] in ("shared_wave","shared_cold") and row["window"]=="64" and row["aperture"]=="1":print(row)


if __name__=="__main__":main()
