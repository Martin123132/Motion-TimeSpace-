"""Read-only lineage, numerical gates, and file integrity for the complete formation release."""
import json
import sys
from stage import DLOG,ROOT,OLD,PIN,np,previous,rows,sha,sealed,guard
from advance import old_tag,tag
from crossover_test import FORECAST


def validate():
    guard()
    for name in sealed: previous(name)
    older = OLD.parent/"mts-formation-tidal-shape-20261120"
    parent_seal = json.loads((OLD/"seal.json").read_bytes())
    assert sha(older/"seal.json")==parent_seal["upstream"]
    ancestors = json.loads((older/"seal.json").read_bytes())["files"]
    for name,pin in ancestors.items(): assert sha(older/name)==pin,name
    assert sha(previous("paired-transfer-forecast.csv"))=="228ba23c2cced03ae32f7a2f386b7c9f5c54f3a504fe67224f490595a2201c24"
    assert sha(ROOT/"balanced-frozen-source.csv")=="cdcb144b4d5315b4c32574c89dfe2ceca51e066ae87b75217c08fa95d7aa5944"
    assert sha(ROOT/"frozen-crossover.csv")==FORECAST
    assert parent_seal["reported_failed_controls"]==6
    visited = set()
    for model in ("heavy","cold"):
        parent = previous(model+"-native.npz")
        for suffix,added in (("",228),("-holdout",32)):
            new = ROOT/(model+suffix+"-environment.npz")
            meta = json.loads((ROOT/(model+suffix+"-overlap.json")).read_bytes())
            assert meta["previous_input"]==sha(parent) and meta["new_epochs"]==added
            assert meta["mode_count"]==99 and max(meta["maximum_difference_on_each_mode_scale"].values())==0
            with np.load(new) as broad,np.load(parent) as narrow:
                width=len(narrow["loga"])
                assert meta["common_epochs"]==width and len(broad["loga"])==width+added
                for key in narrow.files:
                    temporal=key in ("phi","velocity","density","hub","loga")
                    np.testing.assert_array_equal(broad[key][...,:width] if temporal else broad[key],narrow[key])
            visited.add(new.name)
            parent=new
        for case,method in [(c,"spectral") for c in ("1","-1","lin","swap")]+[(c,"fixed") for c in ("lin","swap")]:
            source = previous(old_tag(model,case))
            for win in range(16,73,8):
                if win==72 and not (case=="swap" or case=="lin" and method=="spectral"):continue
                subdivisions = (8,16) if win==72 and case=="swap" and method=="spectral" else (8,)
                for sub in subdivisions:
                    dest=ROOT/tag(model,case,method,sub,win)
                    with np.load(dest) as out,np.load(source) as pre:
                        assert out["restart_sha256"].item()==sha(source)
                        assert out["environment_sha256"].item()==sha(ROOT/(model+("-holdout" if win==72 else "")+"-environment.npz"))
                        count=8*(sub if win==72 else 1)
                        np.testing.assert_allclose(out["times"]/DLOG, win-8+np.arange(count+1)*8/count,rtol=0,atol=4e-14)
                        for field in ("coeff","caps","cone","frames","markers","masses","forces","flux"):
                            assert np.isfinite(out[field]).all(),(dest,field)
                        assert np.min(out["frames"][:,9].real)>.5
                        first,prior=out["frames"][0,:9],pre["frames"][-1,:9]
                        np.testing.assert_allclose(first.real,prior.real,rtol=2e-5,atol=1e-14)
                        np.testing.assert_allclose(first.imag/1e-16,prior.imag/1e-16,rtol=2e-5,atol=1e-14)
                        if win!=16:np.testing.assert_array_equal(out["cone"][0],pre["cone"][-1])
                    visited.add(dest.name)
                source=ROOT/tag(model,case,method,8,win)
        for uniform,band,sub in ((0,15.97,8),(0,15.97,16),(0,19.90,8),(1,15.97,8)):
            last=None
            for win in range(8,65,8):
                path=ROOT/f"response-{model}-uniform{uniform}-K{band:.2f}-n{sub}-w{win:03d}.npz"
                with np.load(path) as data:
                    block=data["series"]
                    assert block.shape==(9,6,6,3) and np.isfinite(block).all() and data["minimum_number"]>.5
                    np.testing.assert_array_equal(data["cone"],block[-1,2])
                    if last is not None:np.testing.assert_allclose(block[0],last,rtol=2e-5,atol=1e-16)
                    last=block[-1]
                visited.add(path.name)
    assert visited=={p.name for p in ROOT.glob("*.npz")} and len(visited)==160
    def read(name):return rows(ROOT/(name+".csv"))
    def worst(seq,key):return max(abs(float(r[key])) for r in seq)
    physical=[r for r in read("independent-response-tests") if r["scenario"]=="physical"]
    assert len(physical)==18 and max(abs(float(r["ratio_to_paired"])-1) for r in physical)<2e-5
    assert worst(physical,"higher_cutoff_shift_on_paired")<2e-5 and worst(physical,"relative_cap_flux_difference")<2e-5
    assert worst(read("independent-comparisons"),"relative")<2e-5
    assert worst(read("paired-source-ledger"),"error_on_gap")<2e-5
    budget=read("material-balance")
    assert worst([r for r in budget if r["part"]!="spherical"],"mismatch_on_cap_signal")<2e-5
    assert worst([r for r in budget if r["part"]=="spherical"],"mismatch_over_initial")<2e-10
    full=[r for r in read("frozen-prediction-tests") if r["forecast_law"]=="physical"]
    passed=lambda seq:sum(r["within_20ppm"]=="True" for r in seq)
    assert len(full)==18 and passed(full)==2
    root=[r for r in read("heldout-crossings") if int(r["order"])==3]
    assert len(root)==3 and passed(root)==1
    for row in root:
        for method in ("measured_window","fine_window","raw_poisson_window"):
            assert float(row["bracket_from"])<float(row[method])<float(row["bracket_to"])
    assert all(abs(float(r["raw_poisson_shift_ppm"]))>20 for r in root)
    local=read("balanced-source-tests")
    assert len(local)==210 and passed(local)==146 and worst(local,"refinement_ppm")<20
    assert passed([r for r in local if float(r["offset"])<=.0005])==90
    assert worst(read("balanced-independent-species"),"error_fraction")<2e-5
    null=[r for r in read("balanced-source-extensions-and-dust-nulls") if float(r["mass_factor"])==0]
    assert len(null)==200 and all(float(r["measured"])==float(r["refined"])==0 for r in null)
    for key in ("RESULTS.md","DERIVATION.md","REPLAY.md","PROTOCOL.md"):assert (ROOT/key).is_file()
    for path in ROOT.iterdir():
        assert path.is_file() and path.suffix in (".md",".py",".json",".npz",".csv"),path
        if path.suffix==".py":compile(path.read_bytes(),str(path),"exec")
    files={p.name:sha(p) for p in sorted(ROOT.iterdir()) if p.name!="seal.json"}
    return dict(files=files,predecessor_sha256=PIN,verified_predecessor=len(sealed),verified_ancestors=len(ancestors),
                physical_packets=len(visited),inherited_numerical_misses=6,homogeneous_shape_forecasts_within_20ppm="2/18",
                heldout_cubic_elapsed_within_20ppm="1/3",heldout_independent_poisson_elapsed_within_20ppm="0/3",
                balanced_quartic_within_20ppm="146/210",separate_species_checks=150)


if __name__=="__main__":
    record=validate()
    destination=ROOT/"seal.json"
    if sys.argv[1:]==["--seal"]:
        with destination.open("x",encoding="utf8",newline="\n") as stream:
            json.dump(record,stream,indent=2,sort_keys=True,allow_nan=False);stream.write("\n")
    else:
        assert not sys.argv[1:] and json.loads(destination.read_bytes())==record
    print("Verified",len(record["files"]),"local files,",record["verified_predecessor"],"+",record["verified_ancestors"],
          "ancestors; seal",sha(destination))
