from stage import AI,DLOG,ROOT,OLD,np,previous,rows,table
from scipy.integrate import cumulative_simpson, simpson
from scipy.interpolate import CubicSpline


def joined(model,case,method="spectral",sub=8):
    paths=[ROOT/f"{model}-{case}-{method}-n{sub}-w{unit:03d}.npz" for unit in range(16,65,8)]
    result={}
    for key in ("frames","times","cone","masses","forces"):
        values=[]
        for path in paths:
            with np.load(path) as data:values.append(data[key][int(bool(values)):])
        result[key]=np.concatenate(values)
    result["r"]=np.load(paths[-1])["radii"]
    return result


def component(array):
    return array.imag/1e-16 if np.iscomplexobj(array) else array.real


def shape(data):
    frame=component(data["frames"])
    return (frame[:,5]-frame[:,6])/data["r"]


def bound(k):
    return previous(k)


def summarize():
    runs={(model,case):joined(model,case) for model in ("heavy","cold") for case in ("lin","swap","1","-1")}
    predicted=rows(previous("paired-transfer-forecast.csv"))
    swap=[];physical=[];balance=[];controls=[];gaps=[];force=[]
    for key,data in runs.items():
        model,case=key
        series=shape(data)
        tangent=case in ("lin","swap")
        amp=1 if case in ("lin","swap") else float(case)
        mass=data["masses"];cone=data["cone"]
        m0=mass[0,0].real+mass[0,1].real
        ref=runs[(model,"lin")]
        old_name=model+"-K15.97-m1-n64-window8-"+("lin" if tangent else case)+"-inside-matter"+("-swapped-current" if case=="swap" else "")+"-force.npz"
        with np.load(previous(old_name)) as arch:
            start=component(arch["frames"][0])
            early=arch["rows"][:,0]-arch["rows"][:,1]
            early_t=arch["times"]
        for idx in (8,24,56):
            window=idx+8
            frame=component(data["frames"][idx])
            for j,r in enumerate(data["r"]):
                net=amp*(frame[0,j]-start[0,j])
                current=amp*(frame[7,j]+frame[8,j])
                physical.append(dict(branch=model,case=case,window=window,aperture=(.5,1,2)[j],shape=series[idx,j],
                    ball_change=net,radial_plus_lateral=current,mass_error_on_quadrupole_drive=(current-net)/net,local_D2=frame[2,j],lapse2=frame[3,j],
                    min_density=float(data["frames"][idx,9,0].real)))
                for label,extract in ([("spherical",lambda v:v.real),("tangent",lambda v:v.imag/1e-16)] if tangent else [("finite",lambda v:v.real)]):
                    second=extract(mass[idx]-mass[0])
                    whole=second[0,j]+second[1,j]
                    moved=second[2,j]+second[3,j]
                    flown=extract(cone[idx,j]-cone[0,j])
                    normal=max(abs(moved),abs(flown))
                    balance.append(dict(branch=model,case=case,part=label,window=window,aperture=(.5,1,2)[j],
                                        material_number_change_over_initial=whole/m0[j],cap_change_over_initial=moved/m0[j],
                                        lateral_current_over_initial=flown/m0[j],mismatch_over_initial=(moved-flown)/m0[j],
                                        mismatch_on_cap_signal=(moved-flown)/normal if normal>1e-10*m0[j] else None))
            if not tangent:continue
            with np.load(ROOT/(model+"-environment.npz")) as arch:
                hc=CubicSpline(arch["loga"],arch["hub"])
            parts=[early_t,data["times"][:idx+1]]
            drifts=[];hubs=[];scales=[];offset=0.
            for t in parts:
                h=hc(t);a=AI*np.exp(t)
                J=cumulative_simpson(1/(a*h),x=t,initial=0)+offset
                drifts.append(J);hubs.append(h);scales.append(a);offset=J[-1]
            kernel=[(a/h)*(offset-J) for a,h,J in zip(scales,hubs,drifts)]
            radius=data["r"]
            e=simpson(early[:,2:] *kernel[0][:,None,None],x=early_t,axis=0)/radius
            late=simpson(data["forces"][:idx+1,:-1]*kernel[1][:,None,None],x=parts[1],axis=0)/radius
            names=[sp+"_"+reg for sp in (("cdm","baryon","wave") if model=="heavy" else ("cdm","baryon")) for reg in ("sampled","inside","outside")]+["exterior","wave_gradient"]
            kick=AI*early[0,1]*offset/radius
            predicted_shape=kick+e.sum(axis=0)+late.sum(axis=0)
            for j in range(3):
                row=dict(branch=model,case=case,window=window,aperture=(.5,1,2)[j],shape=series[idx,j],initial_motion=kick[j],
                         early_gravity_not_exterior=e[:-2,j].sum(),early_exterior=e[-2,j],early_gradient=e[-1,j],
                         independent_force_relative_error=predicted_shape[j]/series[idx,j]-1)
                row.update(dict(zip(names,late[:,j])))
                force.append(row)
        if tangent:
            fc=joined(model,case,"fixed")
            for idx in (8,24,56):
                for j in range(3):
                    for name,first,last in (("shape",series,shape(fc)),("ball_change",component(data["frames"][:,0])-start[0],component(fc["frames"][:,0])-start[0]),
                                            ("lapse",component(data["frames"][:,3]),component(fc["frames"][:,3]))):
                        controls.append(dict(test="fixed_core_raw_poisson",branch=model,case=case,window=idx+8,aperture=(.5,1,2)[j],
                                             quantity=name,relative=last[idx,j]/first[idx,j]-1))
    for model in ("heavy","cold"):
        org=shape(runs[(model,"lin")]);changed=shape(runs[(model,"swap")])
        plus=shape(runs[(model,"1")]);minus=shape(runs[(model,"-1")])
        for idx in (8,24,56):
            for j in range(3):
                aperture=(.5,1,2)[j]
                controls.append(dict(test="centered_unit_tides",branch=model,case="lin",window=idx+8,aperture=aperture,quantity="shape",
                                     relative=.5*(plus[idx,j]-minus[idx,j])/org[idx,j]-1))
                target=changed[idx,j]-org[idx,j]
                for entry in predicted:
                    if (entry["branch"],int(entry["window"]),float(entry["aperture"]))!=(model,idx+8,aperture):continue
                    forecast=float(entry["shape_change"])
                    swap.append(dict(branch=model,window=idx+8,aperture=aperture,forecast_law=entry["transport"],
                                     predicted=forecast,measured=target,relative_error=forecast/target-1,within_20ppm=abs(forecast/target-1)<2e-5))
    for label,wh,ch in (("original","lin","lin"),("shared_wave","lin","swap"),("shared_cold","swap","lin"),("exchanged","swap","swap")):
        for idx in range(57):
            for j in range(3):
                heavy=shape(runs[("heavy",wh)])[idx,j];cold=shape(runs[("cold",ch)])[idx,j]
                raw=shape(runs[("heavy","lin")])[idx,j]-shape(runs[("cold","lin")])[idx,j]
                gaps.append(dict(currents=label,window=idx+8,a=AI*np.exp((idx+8)*DLOG),aperture=(.5,1,2)[j],wave=heavy,cold=cold,
                                 difference=heavy-cold,gap_fraction=(heavy-cold)/raw))
    for name,values in (("signed-gaps",gaps),("frozen-prediction-tests",swap),("trajectory",physical),("material-balance",balance),
                        ("force-accounts",force),("independent-comparisons",controls)):table(name+".csv",values)
    for row in gaps:
        if row["window"]==64 and row["aperture"]==1:print(row)


if __name__=="__main__":summarize()
