"""Validate the source, actual tested combinations, expected failures and immutable local receipt."""
from balance import *


CONFIGS=((160,32,2,1),(160,32,4,1),(120,32,4,1),(160,16,4,1),(160,32,4,2),(160,32,8,1),
         (160,32,4,3),(120,32,4,3),(160,16,4,3),(20,32,4,5),(40,32,4,5),(40,16,4,5),
         (40,32,4,6),(40,16,4,6),(20,32,4,6),(160,32,9,3),(40,32,9,6),(40,32,9,5))


def check(sealing):
    expected=set()
    number=0
    for grid,level,res,pad in CONFIGS:
        for flag in (0,1):
            tag=f"n{grid}-q{level}-t{res}-p{pad}-off{flag}.csv"
            name="collar-"+tag
            expected.add(name)
            raw=read(HOME/name)
            indices={(row["sector"],int(row["seed"]),float(row["fraction"]),float(row["upper"]),int(row["stride"])) for row in raw}
            bounds={1:(5.75,6.),2:(5.75,6.),3:(5.75,6.,12.,15.),5:(15.,24.,48.,72.,96.,119.,120.),6:(120.,)}[pad]
            assert indices=={(sector,seed,frac,bound,stride) for seed in (0,1,-1) for frac in (.25,.5,.75,1.)
                             for sector in ("dust","wave","environment") for bound in bounds for stride in (1,2)}
            assert len(raw)==len(indices)
            number+=len(raw)
            if pad>=3:
                name="exterior-"+tag
                expected.add(name)
                raw=read(HOME/name)
                number+=len(raw)
                assert len(raw)==36*(2 if pad==3 else len(bounds))
    assert set(path.name for path in HOME.glob("collar-*.csv"))=={name for name in expected if name.startswith("collar-")}
    assert set(path.name for path in HOME.glob("exterior-n*.csv"))=={name for name in expected if name.startswith("exterior-")}
    receipts=read(HOME/"outer-inputs.csv")
    assert len(receipts)==18
    for row in receipts:
        assert int(row["equal_fields"])==22 and int(row["cells"])==600 and float(row["cell_width"])==.2
        assert digest(HOME/row["file"])==row["sha256"]
        assert digest(upstream(row["overlap"]))==row["input_sha256"]
    for grid,level in ((160,32),(120,32),(160,16)):
        for flag in (0,1):
            for seed in (0,1,-1):
                checked(BASE,f"trace6-n{grid}-q{level}-p1-off{flag}-s{seed}.npz",FILES)
    for name in NEWFILES:checked(NEWTON,name,NEWFILES)
    gates=read(HOME/"gates.csv")
    assert len(gates)>=22 and sum(row["within"]=="False" for row in gates)==2
    assert all((abs(float(row["worst_ppm"]))<=20)==(row["within"]=="True")== (row["expected_within"]=="True") for row in gates)
    assert len(read(HOME/"manufactured.csv"))==13
    stat=read(HOME/"launch-constraint-trace-pairs.csv")
    assert len(stat)==72
    weak=[row for row in stat if row["side"].startswith("weak")]
    assert max(abs(float(row["relative_to_static_ppm"])) for row in weak)<=20
    assert max(abs(float(row["relative_to_static_ppm"])) for row in stat)>20
    analytic=read(HOME/"harmonic-controls.csv")
    assert len(analytic)==3 and all(abs(float(row["source_integral"])-float(row["surface_difference"]))<=1e-8 for row in analytic)
    assert not list(HOME.glob("*.partial")) and not (HOME/"__pycache__").exists()
    paths=sorted(path for path in HOME.iterdir() if path.is_file() and path.name!="seal.json")
    result=dict(files={path.name:digest(path) for path in paths},rows=sum(len(read(path)) for path in paths if path.suffix==".csv"),
                collar_rows=number,configs=len(CONFIGS),verified_original_histories=18,verified_extended_launches=18)
    seal=HOME/"seal.json"
    if sealing and not seal.exists():
        with seal.open("x",encoding="utf-8",newline="\n") as stream:stream.write(json.dumps(result,sort_keys=True,indent=2)+"\n")
    assert json.loads(seal.read_bytes())==result
    print(digest(seal),len(paths),"files,",result["rows"],"CSV rows; all receipts verified")


if __name__=="__main__":check(sys.argv[1:]==["--seal"])
