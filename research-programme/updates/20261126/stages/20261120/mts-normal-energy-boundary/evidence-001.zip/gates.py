"""Keep the original failure and use the same proper-time, 20-ppm gates throughout."""
from balance import *
from math import fsum


def run():
    rows=read(HOME/"paired-energy.csv")
    tal={ (row["tag"],int(row["grid"]),int(row["q"]),int(row["seed"]),float(row["width"]),float(row["fraction"]),
           float(row["upper"]),int(row["stride"]),row["sector"]):row for row in rows}
    assert len(rows)==len(tal)
    budget=read(HOME/"exterior-bound.csv")
    total={(row["case"],int(row["seed"]),float(row["width"]),float(row["fraction"])):row for row in budget}
    cases=("preferred","reflect","coarse-reflect","coarse","lower_speed","time9")
    assert set(total)=={(case,seed,width,frac) for case in cases for seed in (-1,1) for width in (.15,.30) for frac in (.25,.5,.75,1.)}
    gates=[]
    def gate(label,values,expected=True):
        peak=max(abs(val) for val in values)
        actual=peak<=20
        gates.append(dict(test=label,worst_ppm=peak,tolerance_ppm=20,within=actual,expected_within=expected))
        assert actual==expected,label
    def sample(tag,upper,sector="total",grid=160,level=32):
        return {(seed,width,frac):tal[tag,grid,level,seed,width,frac,upper,1,sector]
                for seed in (-1,1) for width in (.15,.30) for frac in (.25,.5,.75,1.)}
    def contrast(name,left,right,column):
        gate(name,[(float(row[column])-float(right[key][column]))/abs(float(row["newton_change"]))*1e6 for key,row in left.items()])
    wall=sample("saved-wall",6.)
    gate("reflected 6 Mpc physical flux versus Newton (negative control)",[float(row["face_gap_ppm"]) for row in wall.values()],False)
    gate("old wall full annulus energy conservation (negative control)",[float(row["energy_residual_ppm"]) for row in wall.values()],False)
    for level in (16,32):
        native=sample("saved-wall",5.75,level=level)
        buffered=sample("t4-p1",5.75,level=level)
        contrast(f"independent evolution versus archived interior face q{level}",native,buffered,"face")
        contrast(f"independent evolution versus archived interior energy q{level}",native,buffered,"window_change")
        actual=sample("t4-p1",6.,level=level)
        gate(f"transmitted 6 Mpc face versus Newton q{level}",[float(row["face_gap_ppm"]) for row in actual.values()])
        gate(f"transmitted annulus energy budget q{level}",[float(row["energy_residual_ppm"]) for row in actual.values()])
    for tag in ("t2-p1","t8-p1","t4-p2","t4-p3","t9-p3"):
        contrast("6 Mpc face versus t4-p1: "+tag,sample(tag,6.),sample("t4-p1",6.),"face")
    for case in cases:
        group=[row for key,row in total.items() if key[0]==case]
        for item in group:
            signed=abs(float(item["difference_ppm"]))
            assert signed<=float(item["triangle_ppm"])+1e-6
            assert float(item["triangle_ppm"])<=float(item["member_quarters_ppm"])+1e-6
        gate(f"entire 6--120 Mpc exterior, separate member/quarter bound: {case}",[float(row["member_quarters_ppm"]) for row in group])
    for case in ("reflect","coarse","time9"):
        gate("full moment versus preferred: "+case,[1e6*abs(float(total[case,*key[1:]]["normal"])-float(row["normal"]))/abs(float(row["full_tide"]))
              for key,row in total.items() if key[0]=="preferred"])
    dump("gates.csv",gates)
    for row in gates:print(row["test"],format(row["worst_ppm"],".6g"),row["within"])


if __name__=="__main__":run()
