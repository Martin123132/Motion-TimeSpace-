"""Continue the globally sourced initial slice through an interior 6-Mpc surface."""
from balance import *
from math import factorial
from scipy.interpolate import CubicSpline


class Annulus(family.Stagger):
    @property
    def faces(self):
        return self.left+np.arange(self.r.size+1)*self.dx


class ContinuedEnd(Annulus):
    def outer(self,array,count):
        slope=(array[...,-1:]-array[...,-5:-4])/4
        return array[...,-1:]+slope*np.arange(1,count+1)

    def extend(self,array,odd,pad):
        return np.concatenate(((-1 if odd else 1)*array[...,pad-1::-1],array,self.outer(array,pad)),axis=-1)

    def tocell(self,array,odd=True,slope=True):
        ext=np.concatenate(((-1 if odd else 1)*array[...,2:0:-1],array,self.outer(array,2)),axis=-1)
        count=array.shape[-1]-1
        if slope:
            return sum(weight*(ext[...,3+idx:3+idx+count]-ext[...,2-idx:2-idx+count])
                       for idx,weight in enumerate(self.weights))/self.dx
        return sum(weight*(ext[...,3+idx:3+idx+count]+ext[...,2-idx:2-idx+count])
                   for idx,weight in enumerate(self.average))


def system(grid,level,flag,seed,padding):
    eta=1/np.sqrt(level)
    left,right={1:(4.75,6.35),2:(4.50,6.65),3:(4.75,15.50),4:(4.50,15.75),5:(13.,120.),6:(118.,120.)}[padding]
    if padding<5:
        original=family.checked(family.CLOUD,f"launch-h5-off{flag}-seed{seed}.npz")
        scaled=upstream(family.packet_name(5,level,flag,seed))
    else:
        receipts={row["file"]:row["sha256"] for row in read(HOME/"outer-inputs.csv")}
        original=checked(HOME,f"full-q1-off{flag}-s{seed}.npz",receipts)
        scaled=checked(HOME,f"full-q{level}-off{flag}-s{seed}.npz",receipts)
    with np.load(original) as packet:
        base=family.Stagger(packet,grid,right,flag,1,"stagger")
    with np.load(scaled) as packet:
        shell=family.Stagger(packet,grid,right,flag,1,"stagger")
    section=slice(round(left*grid),None)
    shell.initial[17]=eta**2*base.initial[17]
    shell.initial[18:20]*=eta**3
    shell.initial=shell.initial[...,section].copy()
    shell.r=shell.r[section].copy()
    raw=base.incident.bank.samples
    base.incident.bank.samples=CubicSpline.construct_fast(np.ascontiguousarray(raw.c[...,section]),raw.x,axis=0)
    shell.incident.bank=family.ScaledBank(base.incident.bank,eta)
    shell.__class__=ContinuedEnd if padding==6 else Annulus
    shell.left=left
    assert abs(shell.faces[-1]-right)<1e-12
    return shell


def phi(order,argument):
    if abs(argument)<.01:
        return sum(argument**idx/factorial(order+idx) for idx in range(14))
    return (np.exp(argument)-sum(argument**idx/factorial(idx) for idx in range(order)))/argument**order


def coefficients(argument):
    first,second,third=(phi(idx,argument) for idx in (1,2,3))
    return (np.exp(argument),np.exp(argument/2),phi(1,argument/2)/2,
            first-3*second+4*third,2*second-4*third,-second+4*third)


def stepper(shell,step):
    zero=coefficients(0.)
    rates=coefficients(2j*shell.mu*step)
    initial=shell.initial
    def operation(slot,state):
        result=zero[slot]*state
        if not shell.flag:
            rest=(rates[slot]-zero[slot])*state[15]
            result[14]+=rest/(2j)
            result[15]+=rest
        return result
    def nonlinear(time,shift):
        slope=shell.dynamics(time,initial+shift)
        if not shell.flag:
            slope[14]-=shell.mu*shift[15]
            slope[15]-=2j*shell.mu*shift[15]
        return slope
    def advance(time,shift):
        first=nonlinear(time,shift)
        half=operation(1,shift)
        mid1=half+step*operation(2,first)
        second=nonlinear(time+step/2,mid1)
        mid2=half+step*operation(2,second)
        third=nonlinear(time+step/2,mid2)
        end=operation(1,mid1)+step*operation(2,2*third-first)
        fourth=nonlinear(time+step,end)
        return operation(0,shift)+step*(operation(3,first)+operation(4,second+third)+operation(5,fourth))
    return advance


def incoming(shell,source,lower,upper):
    start,stop=(round((value-shell.left)/shell.dx) for value in (lower,upper))
    loc=slice(start,stop)
    phi_cell=1/(5*shell.r[loc]**3)
    flux,angular,workp,works=source
    face=effective(flux)
    if isinstance(shell,ContinuedEnd):
        extended=np.r_[-flux[2:0:-1],flux,shell.outer(flux,2)]
        face=sum(weight*sum(extended[2+offset:2+offset+len(flux)] for offset in range(-order,order+1))
                 for order,weight in enumerate(shell.weights))
    return np.r_[phi_cell[0]*face[start],-phi_cell[-1]*face[stop],np.diff(phi_cell)@face[start+1:stop],
                 [shell.dx*(phi_cell@group[loc]) for group in (angular,workp,works)],
                 flux[stop]/(5*upper**3),flux[start]/(5*lower**3)]


def run(grid,level,resolution,padding,flag,stop=1.):
    steps=2*level*resolution
    span=DURATION*np.sqrt(level)
    step=span/steps
    number=int(round(stop*steps))
    fac=timescale()
    dilute=np.array([fac(idx/steps) for idx in range(number+1)])
    tag=f"n{grid}-q{level}-t{resolution}-p{padding}-off{flag}"
    reports=[]
    moments=[]
    for seed in (0,1,-1):
        guard()
        shell=system(grid,level,flag,seed,padding)
        initial=shell.initial
        shift=np.zeros_like(initial)
        advance=stepper(shell,step)
        profiles={(5.,5.75):[],(5.,6.):[]}
        if padding>=3:profiles.update({(6.,12.):[],(6.,15.):[]})
        if padding==5:profiles={key:[] for key in ((14.,15.),(15.,24.),(24.,48.),(48.,72.),(72.,96.),(96.,119.),(119.,120.))}
        if padding==6:profiles={(119.,120.):[]}
        en0=initial_energy(shell,initial)
        for idx in range(number+1):
            if idx%16==0:
                guard()
                assert not (HOME/"STOP-REQUESTED").exists()
            time=idx*step
            groups=fields(shell,time,initial+shift)
            for (lower,upper),profile in profiles.items():
                profile.append(np.array([incoming(shell,src,lower,upper) for src in groups]))
            if idx%(steps//4)==0 and idx:
                delta=mass_change(shell,initial,shift)
                for (lower,upper),profile in profiles.items():
                    left,right=(round((value-shell.left)/shell.dx) for value in (lower,upper))
                    endpoint=(delta[:,left:right]/(5*shell.r[left:right])).sum(axis=1)*shell.dx
                    if (padding>=3 and lower==6.) or padding>=5:
                        original=(en0[:,left:right]/(5*shell.r[left:right])).sum(axis=1)*shell.dx
                        for species,sector in enumerate(("environment","dust","wave")):
                            moments.append(dict(grid=grid,q=level,flag=flag,seed=seed,fraction=idx/steps,lower=lower,upper=upper,
                                                sector=sector,change=level*endpoint[species],launch=level*original[species],
                                                with_expansion=level*(dilute[idx]*endpoint[species]+(dilute[idx]-1)*original[species])))
                    block=np.array(profile)
                    for stride in (1,2):
                        integral=simpson(block[::stride],dx=step*stride,axis=0)
                        cut=simpson(block[::stride,:,6]*dilute[:idx+1:stride,None],dx=step*stride,axis=0)
                        for species,sector in enumerate(("environment","dust","wave")):
                            reports.append(dict(grid=grid,q=level,flag=flag,seed=seed,lower=lower,upper=upper,
                                                fraction=idx/steps,stride=stride,sector=sector,endpoint=level*endpoint[species],
                                                **dict(zip(LABELS,level*integral[species])),newton_scaled_face=level*cut[species]))
            if idx!=number:shift=advance(time,shift)
        assert np.isfinite(shift).all()
        print(tag,seed,"done",flush=True)
    if reports:dump(f"collar-{tag}"+("" if stop==1. else f"-f{stop}")+".csv",reports)
    if moments:dump(f"exterior-{tag}.csv",moments)


def initial_energy(shell,state):
    ell,bend=state[:2].real
    volume=exp(ell+2*bend)
    energy=mul(volume,state[17].real)
    dust=0*energy
    for species in range(3 if shell.flag else 2):
        number,pot=state[8+2*species:10+2*species].real
        dust+=shell.rho[species]*mul(number,gamma(mul(exp(-ell),shell.diff(pot))))
    wave=0*energy
    if not shell.flag:
        logwave,zval=state[14:16]
        mom=zval+state[4].real/(2*shell.mu)-1j*pair(np.ones_like(shell.r))
        grad=mul(exp(-ell),shell.diff(logwave))
        norm=pair(np.ones_like(shell.r))+mul(mom.conj(),mom).real+mul(grad.conj(),grad).real/shell.mu**2
        wave=shell.rho[-1]/2*mul(exp(ell+2*bend+2*logwave.real),norm)
    return np.array([energy[1],dust[1],wave[1]])


if __name__=="__main__":run(*map(int,sys.argv[1:6]),*map(float,sys.argv[6:]))
