"""Normal-energy conservation on the finite common-metric patch; local, read-only inputs."""
import csv
import hashlib
import io
import json
import os
import sys
from pathlib import Path

for variable in ("OMP_NUM_THREADS","OPENBLAS_NUM_THREADS","MKL_NUM_THREADS","NUMEXPR_NUM_THREADS"):
    os.environ[variable]="1"
sys.dont_write_bytecode=True
HOME=Path(__file__).resolve().parent
BASE=HOME.parent/"mts-late-tide-refinement-20261120"
NEWTON=HOME.parent/"mts-longitudinal-current-transfer-20261120"


def digest(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream,"sha256").hexdigest()


def registry(directory,pin):
    assert digest(directory/"seal.json")==pin
    return json.loads((directory/"seal.json").read_bytes())["files"]


FILES=registry(BASE,"d45b046512700d79c3c2945f376883890eecb52743a05a5b15aeeb3dca265e1c")
NEWFILES=registry(NEWTON,"745c54b36a194733ac18d33c2c5b0a2311d17cc314b42b192946a98850cb2245")


def checked(directory,name,index):
    path=directory/name
    assert digest(path)==index[name],path
    return path


for name in ("common.py","regular.py","trace_stencil.py"):
    checked(BASE,name,FILES)
sys.path.insert(0,str(BASE))
from common import shell_for,family,DURATION,guard,upstream,np
from regular import configure
from scipy.integrate import simpson
from scipy.optimize import brentq
import clock_tide as clock


def dump(name,rows):
    assert rows
    buffer=io.StringIO(newline="")
    writer=csv.DictWriter(buffer,fieldnames=list(rows[0]),lineterminator="\n")
    writer.writeheader()
    writer.writerows(rows)
    path=HOME/name
    content=buffer.getvalue().encode()
    if path.exists(): assert path.read_bytes()==content,path
    else:
        with path.open("xb") as stream:stream.write(content)


def read(path):
    with path.open(newline="") as stream:return list(csv.DictReader(stream))


def pair(base,harm=None):
    return np.stack((base,np.zeros_like(base) if harm is None else harm))


def mul(left,right):
    return pair(left[0]*right[0],left[0]*right[1]+left[1]*right[0])


def inverse(field):
    return pair(1/field[0],-field[1]/field[0]**2)


def exp(field):
    base=np.exp(field[0])
    return pair(base,base*field[1])


def em1(field):
    return pair(np.expm1(field[0]),np.exp(field[0])*field[1])


def square(field):
    return mul(field,field)


def gamma(momentum):
    root=np.sqrt(1+momentum[0]**2)
    return pair(root,momentum[0]*momentum[1]/root)


def mass_change(shell,start,delta):
    ell0,bend0=start[:2].real
    dell,dbend=delta[:2].real
    vol0=ell0+2*bend0
    dvol=dell+2*dbend
    def deriv(group,part):
        raw=start[group].real if part=="real" else start[group].imag
        shift=delta[group].real if part=="real" else delta[group].imag
        before=mul(exp(-ell0),shell.diff(raw))
        increment=mul(exp(-ell0-dell),shell.diff(shift))+mul(em1(-dell),before)
        return before,increment
    env=mul(exp(vol0+dvol),delta[17].real)+mul(exp(vol0),mul(em1(dvol),start[17].real))
    dust=0*env
    for species in range(3 if shell.flag else 2):
        idx=8+2*species
        before,increment=deriv(idx+1,"real")
        first,last=gamma(before),gamma(before+increment)
        dg=mul(mul(2*before+increment,increment),inverse(first+last))
        dust+=shell.rho[species]*(mul(delta[idx].real,last)+mul(start[idx].real,dg))
    wave=0*env
    if not shell.flag:
        factor=vol0+2*start[14].real
        dfactor=dvol+2*delta[14].real
        normal=start[15].real+start[4].real/(2*shell.mu)
        dnormal=delta[15].real+delta[4].real/(2*shell.mu)
        imag=start[15].imag-pair(np.ones_like(shell.r))
        dimag=delta[15].imag
        before=pair(np.ones_like(shell.r))+square(normal)+square(imag)
        change=mul(2*normal+dnormal,dnormal)+mul(2*imag+dimag,dimag)
        for part in ("real","imag"):
            grad,dgrad=deriv(14,part)
            before+=square(grad)/shell.mu**2
            change+=mul(2*grad+dgrad,dgrad)/shell.mu**2
        wave=shell.rho[-1]/2*(mul(exp(factor+dfactor),change)+mul(exp(factor),mul(em1(dfactor),before)))
    return np.array([env[1],dust[1],wave[1]])


def fields(shell,time,state):
    ell,bend,tilt,_,trace,shear=state[:6].real
    volume=exp(ell+2*bend)
    face=shell.toface
    eface,bface=face(ell),face(bend)
    surface=exp(2*bface)
    unit=pair(np.ones_like(shell.r))
    zero=0*unit
    bank=shell.incident.bank.at(time)
    def make(radial,tangent,mono_current,pressure,anisotropy):
        flux=shell.faces**2*mul(surface,radial)[1]
        angle=6*shell.r*volume[0]*(np.exp(-bend[0])*tangent-tilt[1]*np.exp(-ell[0])*mono_current)
        workp=shell.r**2*mul(volume,mul(trace,pressure))[1]
        works=shell.r**2*1.5*mul(volume,mul(shear,anisotropy))[1]
        return [flux,angle,workp,works]
    env=make(face(state[18].real,odd=True),state[19,1].real,state[18,0].real,
             pair(bank[1],bank[3])/3,pair(0*shell.r,bank[4]))
    dust=[0*value for value in env]
    for species in range(3 if shell.flag else 2):
        number,potential=state[8+2*species:10+2*species].real
        rest=shell.rho[species]*mul(number,inverse(volume))
        momentum=mul(exp(-ell),shell.diff(potential))
        radial=shell.rho[species]*mul(mul(face(number),exp(-2*eface-2*bface)),face(potential,slope=True))
        pressure=mul(rest,mul(square(momentum),inverse(gamma(momentum))))/3
        terms=make(radial,rest[0]*potential[1]*np.exp(-bend[0])/shell.r,
                   rest[0]*momentum[0],pressure,2*pressure)
        dust=[old+val for old,val in zip(dust,terms)]
    wave=[0*value for value in env]
    if not shell.flag:
        logwave,zval=state[14:16]
        mom=zval+trace/(2*shell.mu)-1j*unit
        grad=mul(exp(-ell),shell.diff(logwave))
        rest=shell.rho[-1]*exp(2*logwave.real)
        restf=shell.rho[-1]*exp(2*face(logwave.real))
        facegrad=mul(exp(-eface),face(logwave,slope=True))
        radial=-mul(restf,mul(face(mom).conj(),facegrad).real)/shell.mu
        mono=-rest[0]*np.real(mom[0].conj()*grad[0])/shell.mu
        tangent=-rest[0]*np.real(mom[0].conj()*logwave[1])*np.exp(-bend[0])/(shell.r*shell.mu)
        kinetic=mul(grad.conj(),grad).real/shell.mu**2
        kin_time=square(zval.real+trace/(2*shell.mu))+square(zval.imag)-2*zval.imag
        wave=make(radial,tangent,mono,mul(rest,kin_time-kinetic/3)/2,2*mul(rest,kinetic)/3)
    return (env,dust,wave)


def effective(raw):
    pad=np.r_[-raw[2:0:-1],raw,-raw[-2:-4:-1]]
    count=len(raw)
    return sum(weight*sum(pad[2+offset:2+offset+count] for offset in range(-order,order+1))
               for order,weight in enumerate((75/64,-25/384,3/640)))


LABELS=("enter","leave","bulk","angular","pressure","shear","physical_upper","physical_lower")


def budget(shell,source,lower,upper):
    start,stop=(int(round(value/shell.dx)) for value in (lower,upper))
    loc=slice(start,stop)
    phi=1/(5*shell.r[loc]**3)
    flux,angular,workp,works=source
    face=effective(flux)
    return np.r_[phi[0]*face[start],-phi[-1]*face[stop],np.diff(phi)@face[start+1:stop],
                 [shell.dx*(phi@group[loc]) for group in (angular,workp,works)],
                 flux[stop]/(5*upper**3),flux[start]/(5*lower**3)]


def timescale():
    sim=family.BalancedNative("heavy",120,600,False,"native36",clock.START+.00002)
    tr=clock.Traces("heavy",sim)
    def factor(frac):
        proper=float(frac)*DURATION
        eta=brentq(lambda value:tr.proper(value)-proper,0.,tr.proper.x[-1],xtol=5e-16) if frac else 0.
        return np.exp(-3*tr.log_time(eta))
    return factor


def run():
    fractions=np.arange(9)/8
    timescale_fn=timescale()
    dilute=np.array([timescale_fn(frac) for frac in fractions])
    table=[]
    for grid,level in ((120,32),(160,16),(160,32)):
        for flag in (0,1):
            for seed in (0,1,-1):
                guard()
                shell=shell_for(grid,level,flag,seed)
                configure(shell,"trace6")
                name=f"trace6-n{grid}-q{level}-p1-off{flag}-s{seed}.npz"
                with np.load(checked(BASE,name,FILES)) as packet:
                    shifts=packet["change"]
                    np.testing.assert_array_equal(shell.r,packet["radius"])
                initial=shell.initial
                step=DURATION*np.sqrt(level)/8
                for tick,frac in enumerate(fractions):
                    time=tick*step
                    shift=shifts[tick-1] if tick else np.zeros_like(initial)
                    state=initial+shift
                    change=mass_change(shell,initial,shift)
                    currents=fields(shell,time,state)
                    if tick==0:
                        profiles={}
                    for lower,upper in ((5.,6.),(5.,5.75)):
                        left,right=round(lower*grid),round(upper*grid)
                        vals=np.array([budget(shell,src,lower,upper) for src in currents])
                        profile=profiles.setdefault((lower,upper),[])
                        profile.append(vals)
                        if tick%2:continue
                        endpoint=(change[:,left:right]/(5*shell.r[left:right])).sum(axis=1)*shell.dx
                        for stride in ((1,2) if tick%4==0 and tick else (1,)):
                            integral=simpson(np.array(profile)[::stride],dx=step*stride,axis=0) if tick else 0*vals
                            cut=simpson(np.array(profile)[::stride,:,6]*dilute[:tick+1:stride,None],dx=step*stride,axis=0) if tick else 0*vals[:,6]
                            for idx,sector in enumerate(("environment","dust","wave")):
                                table.append(dict(grid=grid,q=level,flag=flag,seed=seed,lower=lower,upper=upper,
                                                  fraction=frac,stride=stride,sector=sector,endpoint=level*endpoint[idx],
                                                  **dict(zip(LABELS,level*integral[idx])),newton_scaled_face=level*cut[idx]))
        print("saved readouts",grid,level,flush=True)
    dump("history-budget.csv",table)


if __name__=="__main__":run()
