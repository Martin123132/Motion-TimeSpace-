"""Triangle bound on the finite exterior readouts, including rather than hiding closure error."""
from score import *
from functools import lru_cache


@lru_cache(maxsize=None)
def load_pair(kind,grid,level,pad,resolution):
    records=[]
    for flag in (0,1):
        records+=read(HOME/f"{kind}-n{grid}-q{level}-t{resolution}-p{pad}-off{flag}.csv")
    return {(int(row["seed"]),int(row["flag"]),float(row["fraction"]),float(row["lower"]),float(row["upper"]),row["sector"]):row
            for row in records if int(row.get("stride",1))==1}


def evaluate(save=True,cases=()):
    current=read(HOME/"newton-finite-flux.csv")
    norm={(int(row["seed"]),float(row["width"]),float(row["fraction"])):row
          for row in read(checked(NEWTON,"matched-differences.csv",NEWFILES))}
    components=("near_face","far_face","radial_interior","angular","pressure","shear","launch_dilution","closure")
    by_shell=[]
    totals=[]
    regions=((6.,15.),(15.,24.),(24.,48.),(48.,72.),(72.,96.),(96.,119.),(119.,120.))
    for label,inner,outer,level,edge,resolution in (("preferred",160,40,32,6,4),("reflect",160,40,32,5,4),
                                         ("coarse-reflect",120,20,32,5,4),("coarse",120,20,32,6,4),
                                         ("lower_speed",160,40,16,6,4),("time9",160,40,32,6,9)):
        if cases and label not in cases:continue
        for seed in (-1,1):
            cumulative=None
            previous=None
            previous_independent=None
            bound_from_members=0.
            for frac in (.25,.5,.75,1.):
                terms=[]
                checked_terms=[]
                endpoints=[]
                for lower,upper in regions:
                    grid,pad=(inner,3) if lower==6. else (outer,edge if upper==120 else 5)
                    raw=load_pair("collar",grid,level,pad,resolution)
                    energy=load_pair("exterior",grid,level,pad,resolution)
                    def signed(source,key):
                        return fsum((1 if host else -1)*(1 if flag==0 else -1)*float(source[host,flag,frac,lower,upper,sector][key])
                                    for host in (0,seed) for flag in (0,1) for sector in ("dust","wave","environment"))
                    nr=[row for row in current if float(row["fraction"])==frac and int(row["seed"])==seed
                        and float(row["lower"])>=lower and float(row["upper"])<=upper]
                    assert len(nr)==(4 if lower==6 else 2)
                    scale=float(nr[0]["scale"])
                    def ref(key,condition=lambda row:True):
                        return fsum((1 if row["flag"]=="0" else -1)*float(row[key]) for row in nr if condition(row))
                    near=signed(raw,"physical_lower")
                    far=-signed(raw,"physical_upper")
                    bulk=fsum(signed(raw,key) for key in ("enter","leave","bulk"))-near-far
                    drel=signed(energy,"with_expansion")
                    nphysical=scale*ref("change")+ref("dilution")
                    delta=drel-nphysical
                    calc=scale*np.array([near-ref("enter",lambda row:float(row["lower"])==lower),
                                         far-ref("leave",lambda row:float(row["upper"])==upper),
                                         bulk-ref("bulk"),signed(raw,"angular")-ref("angle"),
                                         signed(raw,"pressure"),signed(raw,"shear")])
                    launch=drel-scale*signed(energy,"change")-ref("dilution")
                    error=np.r_[calc,launch,delta-fsum([*calc,launch])]
                    gr_errors=[]
                    for host in (0,seed):
                        for flag in (0,1):
                            for sector in ("dust","wave","environment"):
                                record=raw[host,flag,frac,lower,upper,sector]
                                gr_errors.append(scale*(float(record["endpoint"])-fsum(float(record[key]) for key in LABELS[:6])))
                    newton_errors=[scale*(float(rec["change"])-fsum(float(rec[key]) for key in ("enter","leave","bulk","angle")))
                                   for rec in sorted(nr,key=lambda rec:(int(rec["flag"]),float(rec["lower"])))]
                    independent=np.r_[calc,launch,gr_errors,newton_errors]
                    assert abs(error[-1])<=sum(abs(independent[7:]))+1e-29
                    checked_terms.extend(independent.tolist())
                    terms.append(error)
                    endpoints.append((drel,nphysical))
                    by_shell.append(dict(case=label,seed=seed,fraction=frac,lower=lower,upper=upper,normal=drel,newton=nphysical,
                                         **dict(zip(components,error)),triangle=sum(abs(error)),
                                         separate_gr_closure=sum(map(abs,gr_errors)),separate_newton_closure=sum(map(abs,newton_errors))))
                terms=np.array(terms)
                normref=norm[seed,.15,frac]
                drel,nphysical=np.sum(endpoints,axis=0)
                assert abs(nphysical-float(normref["reference"])*float(normref["exterior_net"])) <= 2e-5*abs(float(normref["reference"]))
                if previous is None:
                    previous=0*terms
                    cumulative=0.
                    previous_independent=np.zeros(len(checked_terms))
                cumulative+=sum(abs((terms-previous).ravel()))
                previous=terms
                independent=np.array(checked_terms)
                bound_from_members+=np.sum(abs(independent-previous_independent))
                previous_independent=independent
                for width in (.15,.30):
                    full=float(norm[seed,width,frac]["reference"])
                    multiplier=1e6/abs(full)
                    totals.append(dict(case=label,seed=seed,width=width,fraction=frac,normal=drel,newton=nphysical,full_tide=full,
                                       exterior_share=drel/full,difference_ppm=(drel-nphysical)*multiplier,
                                       triangle_ppm=sum(abs(terms.ravel()))*multiplier,
                                       quarter_variation_ppm=cumulative*multiplier,
                                       member_bound_ppm=sum(abs(independent))*multiplier,
                                       member_quarters_ppm=bound_from_members*multiplier,
                                       **{key+"_absolute_ppm":sum(abs(terms[:,idx]))*multiplier for idx,key in enumerate(components)}))
    if save:
        dump("exterior-by-shell.csv",by_shell)
        dump("exterior-bound.csv",totals)
    for key in ("preferred","reflect","coarse-reflect","coarse","lower_speed","time9"):
        rows=[row for row in totals if row["case"]==key]
        if not rows:continue
        print(key,"peak |signed| / triangle / time-block variation (ppm):",
              *[format(max(abs(row[name]) for row in rows),".7g") for name in ("difference_ppm","triangle_ppm","quarter_variation_ppm","member_quarters_ppm")])
    return totals


if __name__=="__main__":evaluate("--dry" not in sys.argv)
