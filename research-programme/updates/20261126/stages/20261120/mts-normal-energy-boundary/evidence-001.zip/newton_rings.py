"""The same saved cold/wave trajectory, now read through finite exterior-moment kernels."""
from balance import *
import newton_history as native


def run():
    sim=family.BalancedNative("heavy",120,600,False,"native36",clock.START+.00002)
    trace=clock.Traces("heavy",sim)
    sim.patch.coeff=lambda time:(float(trace.hubble(time-clock.START)),clock.SCALE*np.exp(time-clock.START))
    sim.ref.solution=lambda time:trace.histories(time-clock.START,"normal")
    kernel=clock.Kernel(sim.mesh)
    extended=sys.argv[1:]==["--extended"]
    radii=(6.,12.,14.,15.,24.,48.,72.,96.,119.,120.) if extended else (6.,12.,15.,24.,48.,72.,120.)
    rows={rad:kernel.rows(rad)[4] if rad!=120 else 0*kernel.rows(6.)[4] for rad in radii}
    mass=sim.patch.p.coeff/clock.SCALE
    fractions=np.arange(33)/32
    physical=[brentq(lambda val:float(trace.proper(val))-frac*DURATION,0.,trace.proper.x[-1],xtol=5e-16) if frac else 0. for frac in fractions]
    offsets=trace.log_time(physical)
    records=[]
    for seed in (1,-1):
        name="evolved-heavy-L120-h5-t176.npz" if seed==1 else "collar-heavy-L120-h5--1.npz"
        with np.load(clock.checked(clock.FORM,name)) as pack:
            start=tuple(pack[key] for key in ("mono","density","velocity"))
        for flag in (0,1):
            sim.patch.wave=not flag
            summed=[np.zeros_like(comp) for comp in start]
            for idx,offset in enumerate(offsets):
                guard()
                state=tuple(original+inc for original,inc in zip(start,summed))
                if idx%4==0:
                    gain=np.exp(-3*offset)*(mass@summed[1][flag])+np.expm1(-3*offset)*(mass@start[1][flag])
                    for low,high in zip(radii,radii[1:]):
                        records.append(dict(seed=seed,flag=flag,fraction=fractions[idx],lower=low,upper=high,physical_moment=(rows[low]-rows[high])@gain))
                if idx==32:break
                step=offsets[idx+1]-offset
                slopes=[sim.rates(state,clock.START+offset)]
                for prop in (.5,.5,1.):
                    mid=tuple(original+(inc+prop*step*slope) for original,inc,slope in zip(start,summed,slopes[-1]))
                    slopes.append(sim.rates(mid,clock.START+offset+prop*step))
                for inc,derivs in zip(summed,zip(*slopes)):
                    inc+=step*(derivs[0]+2*derivs[1]+2*derivs[2]+derivs[3])/6
    dump("newton-rings-extended.csv" if extended else "newton-rings.csv",records)


if __name__=="__main__": run()
