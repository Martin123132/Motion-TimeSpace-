"""Unfitted radial and angular mass-current reference on the identical annuli and clock."""
from balance import *
checked(NEWTON,"current_transfer.py",NEWFILES)
sys.path.insert(0,str(NEWTON))
from current_transfer import flux


def run():
    fresh=family.BalancedNative("heavy",120,600,False,"native36",clock.START+.00002)
    trace=clock.Traces("heavy",fresh)
    fresh.patch.coeff=lambda time:(float(trace.hubble(time-clock.START)),clock.SCALE*np.exp(time-clock.START))
    fresh.ref.solution=lambda time:trace.histories(time-clock.START,"normal")
    mesh=fresh.mesh
    kernel=clock.Kernel(mesh)
    ends=(6.,12.,15.,24.,48.,72.,96.,119.,120.)
    rows={cut:kernel.rows(cut)[4] if cut!=120. else 0*kernel.rows(6.)[4] for cut in ends}
    matter=fresh.patch.p.coeff/clock.SCALE
    fractions=np.arange(33)/32
    physical=[brentq(lambda val:float(trace.proper(val))-frac*DURATION,0.,trace.proper.x[-1],xtol=5e-16) if frac else 0. for frac in fractions]
    offsets=trace.log_time(physical)
    clock_rates=trace.log_time(physical,1)/trace.proper(physical,1)
    records=[]
    for seed in (1,-1):
        name="evolved-heavy-L120-h5-t176.npz" if seed==1 else "collar-heavy-L120-h5--1.npz"
        with np.load(clock.checked(clock.FORM,name)) as pack:
            initial=tuple(pack[key] for key in ("mono","density","velocity"))
        for flag in (0,1):
            fresh.patch.wave=not flag
            summed=[np.zeros_like(comp) for comp in initial]
            histories={}
            for idx,offset in enumerate(offsets):
                guard()
                state=tuple(start+inc for start,inc in zip(initial,summed))
                time=clock.START+offset
                radial,angular,edge=(sum(parts) for parts in zip(*flux(fresh,state,time,flag,matter)))
                factor=clock_rates[idx]/fresh.patch.coeff(time)[0]
                def face(cut):
                    element=round(cut/mesh.h)
                    val=edge if cut==120. else (radial[element-1,-1]+radial[element,0])/2
                    return val/(5*cut)
                for lo,hi in zip(ends,ends[1:]):
                    elements=slice(round(lo/mesh.h),round(hi/mesh.h))
                    rr=mesh.loc[elements]
                    values=factor*np.array([face(lo),-face(hi),-.6*np.sum(mesh.qw*radial[elements]/rr**2),
                                            1.2*np.sum(mesh.qw*angular[elements]/rr**3)])
                    history=histories.setdefault((lo,hi),[])
                    history.append(values)
                    if idx and idx%8==0:
                        integral=simpson(np.array(history),dx=DURATION/32,axis=0)
                        matrix=rows[lo]-rows[hi]
                        shift=matrix@(matter@summed[1][flag])
                        launch=matrix@(matter@initial[1][flag])
                        records.append(dict(seed=seed,flag=flag,lower=lo,upper=hi,fraction=fractions[idx],
                                            **dict(zip(("enter","leave","bulk","angle"),integral)),change=shift,launch=launch,
                                            dilution=np.expm1(-3*offset)*launch,scale=np.exp(-3*offset)))
                if idx==32:break
                step=offsets[idx+1]-offset
                slopes=[fresh.rates(state,time)]
                for prop in (.5,.5,1.):
                    mid=tuple(original+(inc+prop*step*slope) for original,inc,slope in zip(initial,summed,slopes[-1]))
                    slopes.append(fresh.rates(mid,time+prop*step))
                for inc,derivs in zip(summed,zip(*slopes)):
                    inc+=step*(derivs[0]+2*derivs[1]+2*derivs[2]+derivs[3])/6
    dump("newton-finite-flux.csv",records)


if __name__=="__main__":run()
