"""Signed double differences: always compare like clocks, apertures, signs and stages."""
from balance import *
from math import fsum
import re


def keyed(rows):
    groups={}
    for row in rows:
        key=(int(row["grid"]),int(row["q"]),int(row["flag"]),int(row["seed"]),
             float(row["fraction"]),float(row["upper"]),int(row["stride"]),row["sector"])
        assert key not in groups
        groups[key]=row
    return groups


def summaries(tag,data):
    new={ (int(row["seed"]),float(row["width"]),float(row["fraction"])):row
         for row in read(checked(NEWTON,"matched-differences.csv",NEWFILES))}
    out=[]
    for grid,level in sorted({key[:2] for key in data}):
        for frac,upper,stride in sorted({key[4:7] for key in data if key[:2]==(grid,level) and key[4]}):
            for seed in (-1,1):
                nrow=new[seed,.15,frac]
                for kind in ("environment","matter","total"):
                    sectors=(("environment",) if kind=="environment" else ("dust","wave") if kind=="matter" else ("environment","dust","wave"))
                    def difference(name):
                        return fsum((1 if flag==0 else -1)*(1 if host else -1)*float(data[grid,level,flag,host,frac,upper,stride,spec][name])
                                    for flag in (0,1) for host in (seed,0) for spec in sectors)
                    numerator=difference("newton_scaled_face")
                    total_work=difference("pressure")+difference("shear")
                    endpoint=difference("endpoint")
                    error=fsum(difference(key) for key in LABELS[:6])-endpoint
                    for width in (.15,.3):
                        nrow=new[seed,width,frac]
                        norm=abs(float(nrow["reference"]))
                        ref=float(nrow["cut_flux"])
                        out.append(dict(tag=tag,grid=grid,q=level,seed=seed,width=width,fraction=frac,upper=upper,stride=stride,sector=kind,
                                        newton_change=float(nrow["reference"]),window_change=endpoint,energy_residual_ppm=error/norm*1e6,
                                        stress_work_ppm=total_work/norm*1e6,face=numerator,newton_cut_flux=ref if upper==6. else "",
                                        face_gap_ppm=(numerator-ref)/norm*1e6 if upper==6. and kind=="total" else ""))
    return out


def score(save):
    archive=summaries("saved-wall",keyed(read(HOME/"history-budget.csv")))
    collar=[]
    for path in sorted(HOME.glob("collar-*-off0.csv")):
        mode=path.name.replace("off0","off1")
        if not (HOME/mode).exists():continue
        tag=re.search(r"-(t\d+-p\d+)-",path.name)[1]
        collar+=summaries(tag,keyed(read(path)+read(HOME/mode)))
    rows=archive+collar
    if save:dump("paired-energy.csv",rows)
    for row in rows:
        if (row["width"],row["fraction"],row["stride"],row["sector"],row["seed"],row["upper"])==(.15,1.,1,"total",1,6.):
            print(row["tag"],row["grid"],row["q"],"face gap / energy residual / stress work (ppm):",
                  *[format(row[key],".7g") for key in ("face_gap_ppm","energy_residual_ppm","stress_work_ppm")])
    return rows


if __name__=="__main__":score(sys.argv[1:]==["--save"])
