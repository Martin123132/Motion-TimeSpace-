"""Export the rest of the existing 120-Mpc constrained solution without changing its equations."""
from balance import *
from types import SimpleNamespace


def filename(level,flag,seed):
    return f"full-q{level}-off{flag}-s{seed}.npz"


def build():
    sim=family.BalancedNative("heavy",120,600,False,"native36",family.SPAN*family.DLOG)
    receipts=[]
    for flag in (0,1):
        ref,press,_=family.pressure(flag)
        for seed in (0,1,-1):
            base,grid,shapes,initial=family.input_pack(sim,5,seed,flag,ref,press)
            for level in (1,16,32):
                guard()
                eta=1/np.sqrt(level)
                bg={**ref,"H":ref["H"]*eta,"R":ref["R"]*eta**2,"rh":ref["rh"]*eta**2}
                pbar=press*eta**4
                scaled=SimpleNamespace(mesh=sim.mesh,patch=SimpleNamespace(j=sim.patch.j,p=SimpleNamespace(mass=sim.patch.p.mass/eta)))
                state=[base[0].copy(),base[1],eta*base[2]]
                state[0][1]*=eta
                shape=tuple({key:value*eta**family.POWERS[key] for key,value in group.items()} for group in shapes)
                supply={**initial,"P":pbar,"lp":initial["lp"]*eta,"spec2":initial["spec2"]*eta**4}
                obj=family.ResolvingSlice(scaled,grid,bg,shape,state,flag,not flag,"fixed",0,"matched")
                hub=bg["H"]
                mu=bg["a"]*scaled.patch.p.mass
                if not flag:
                    mean=family.homogeneous(bg,bg["rh"][sim.patch.j],mu,pbar)
                    hub=mean["hubble"]
                    graph,fields=family.normal_data(obj,supply,mean)
                    for iteration in range(8):
                        hook=family.Sources(grid,fields,shape[0]["other"])
                        obj=family.ResolvingSlice(scaled,grid,{**bg,"H":hub},shape,state,flag,True,"fixed",0,"matched",hook)
                        new,newfields=family.normal_data(obj,supply,mean,graph)
                        if family.change_norm(fields,newfields)<2e-9:break
                        graph,fields=new,newfields
                    else:raise RuntimeError("normal graph")
                    delta,drift=(pair(value.real,family.angular(value)) for value in graph)
                else:delta=drift=pair(np.zeros_like(grid.points))
                mono=grid.evaluate(obj.state[0])[0]
                higher=shape[0]["V"]+grid.evaluate(obj.state[2])[0][flag]
                packet=dict(t=grid.t,h=grid.h,n=np.stack([pair(num,den) for num,den in zip(obj.m["n"],obj.m["D"])]),
                            v=np.stack([pair(speed,quad) for speed,quad in zip(mono[1]/grid.points,higher)]),
                            chi=pair(grid.evaluate(obj.f0)[0],grid.evaluate(obj.f2)[0]),b=pair(obj.b0,obj.b2),
                            c=obj.c2,d=obj.d2,delta=delta,drift=drift,rho=bg["rh"],mu=mu,H=hub,P=pbar,R=bg["R"],
                            weight=ref["w"],e0=shape[0]["other"],s0=supply["spec2"],
                            native_stress=shape[0]["stress"],native_cross=shape[0]["stress_cross"],probes=np.array([]),initial_tide=np.array([]))
                prior=upstream(family.packet_name(5,level,flag,seed))
                with np.load(prior) as old:
                    assert set(old.files)==set(packet)
                    for key,val in packet.items():
                        section=val[..., :80,:] if np.shape(val)[-2:]==grid.points.shape else val
                        np.testing.assert_array_equal(section,old[key],err_msg=key)
                path=HOME/filename(level,flag,seed)
                buffer=io.BytesIO()
                np.savez_compressed(buffer,**packet)
                data=buffer.getvalue()
                if path.exists():assert path.read_bytes()==data
                else:
                    with path.open("xb") as stream:stream.write(data)
                receipts.append(dict(file=path.name,sha256=digest(path),overlap=prior.name,input_sha256=digest(prior),equal_fields=len(packet),
                                     cells=len(grid.points),cell_width=grid.h))
            print("full initial overlap verified",flag,seed,flush=True)
    dump("outer-inputs.csv",receipts)


if __name__=="__main__":build()
