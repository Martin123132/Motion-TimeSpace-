"""Compare the scalar-constraint surface trace with independent physical launch stress-energy."""
from balance import *
from math import fsum
import re
from numpy.polynomial.legendre import legder,legval,legvander


def run():
    receipts=read(HOME/"outer-inputs.csv")
    records=[]
    for row in receipts:
        name=row["file"]
        with np.load(HOME/name) as src:
            level,flag,seed=map(int,re.fullmatch(r"full-q(\d+)-off(\d+)-s(-?\d+)\.npz",name).groups())
            nodes=src["t"]
            size=len(nodes)
            h=float(src["h"])
            pts=(np.arange(600)[:,None]+nodes)*h
            local=2*nodes-1
            basis=np.linalg.inv(legvander(local,size-1))
            grad=legval(local,legder(basis)).T*2/h
            edge=legvander([-1.,1.],size-1)@basis
            derivative=legval(np.array([-1.,1.]),legder(basis)).T*2/h
            roots,weights=np.polynomial.legendre.leggauss(size)
            np.testing.assert_allclose(roots,local,rtol=0,atol=5e-14)
            ground=src["chi"][0]
            angular=src["chi"][1]
            psi=pair(1+ground,angular)
            metric=pair(6*np.log1p(ground),6*angular/(1+ground))
            one=pair(np.ones_like(ground))
            invpsi=inverse(psi)
            efac=mul(invpsi,invpsi)
            density=pair(np.zeros_like(ground)+float(src["R"])-sum(src["rho"]),src["e0"])
            for species in range(3 if flag else 2):
                vel=mul(efac,src["v"][species]@grad.T)
                density+=src["rho"][species]*mul(exp(-metric),mul(src["n"][species],gamma(vel)))
            if not flag:
                mu=float(src["mu"])
                particle=src["n"][-1]
                den=src["delta"]+one
                log=pair(np.log(particle[0]/den[0]),particle[1]/particle[0]-den[1]/den[0])/2-metric/2
                realgrad=mul(efac,log@grad.T)/mu
                phasegrad=mul(efac,src["v"][-1]@grad.T)
                kin=square(src["drift"])+square(den)
                density+=src["rho"][-1]*mul(exp(2*log),(one+kin+square(realgrad)+square(phasegrad)))/2
            shear=mul(src["b"],exp(-metric))
            eff=mul(exp(metric*5/6),density-3*float(src["H"])**2*one+.75*square(shear))[1]
            driven=mul(exp(metric),density)[1]
            def trace(cut,side):
                ind=round(cut/h)
                left=ind==600 or side.endswith("left")
                cell=ind-1 if left else ind
                col=angular[cell]
                which=int(left)
                slope=col@derivative[which]
                if side.startswith("weak"):
                    test=nodes if left else 1-nodes
                    sign=1 if left else -1
                    radius=pts[cell]
                    integrand=radius**2*(col@grad.T)*(sign/h)+6*col*test-radius**2*eff[cell]*test/4
                    slope=sign*h*(integrand@weights)/(2*cut**2)
                return slope/cut+3*(col@edge[which])/cut**2
            for low,high in ((6.,15.),(15.,120.),(6.,120.)):
                cells=slice(round(low/h),round(high/h))
                mass=level*h/10*np.sum(weights*eff[cells]/pts[cells])
                normal=level*h/10*np.sum(weights*driven[cells]/pts[cells])
                for side in ("left","right","weak-left","weak-right"):
                    surface=-4*level/5*(trace(high,side)-trace(low,side))
                    records.append(dict(q=level,flag=flag,seed=seed,lower=low,upper=high,side=side,
                                        curvature_surface=surface,effective_source=mass,normal_source=normal))
    dump("launch-constraint-weak-and-strong.csv",records)
    dump("launch-constraint.csv",[row for row in records if not row["side"].startswith("weak")])
    contrasts=[]
    for level in (1,16,32):
        for seed in (-1,1):
            for low,high in ((6.,15.),(15.,120.),(6.,120.)):
                for side in ("left","right","weak-left","weak-right"):
                    subset=[row for row in records if row["q"]==level and row["seed"] in (0,seed) and
                            (row["lower"],row["upper"],row["side"])==(low,high,side)]
                    assert len(subset)==4
                    def val(key):
                        return fsum((1 if row["seed"] else -1)*(1 if not row["flag"] else -1)*row[key] for row in subset)
                    surface=val("curvature_surface")
                    source=val("effective_source")
                    contrasts.append(dict(q=level,seed=seed,lower=low,upper=high,side=side,surface=surface,
                                          source=source,normal=val("normal_source"),relative_to_static_ppm=(surface/source-1)*1e6))
    dump("launch-constraint-trace-pairs.csv",contrasts)
    dump("launch-constraint-pairs.csv",[row for row in contrasts if not row["side"].startswith("weak")])
    analytic=[]
    for power in (2,-3,4):
        lo,hi=6.,120.
        factor=power*(power+1)-6
        exact=-4/5*(power+3)*(hi**(power-2)-lo**(power-2))
        source=0. if factor==0 else -4*factor/5*(hi**(power-2)-lo**(power-2))/(power-2)
        assert abs(exact-source)<=5e-14*max(abs(exact),1.)
        analytic.append(dict(power=power,surface_difference=exact,source_integral=source,
                             outer_trace=(power+3)*hi**(power-2)))
    dump("harmonic-controls.csv",analytic)
    print("worst static source-relative residual, ppm:",max(abs(item["relative_to_static_ppm"]) for item in contrasts))


if __name__=="__main__":run()
