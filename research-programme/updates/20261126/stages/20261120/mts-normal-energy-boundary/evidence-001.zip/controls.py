"""Analytic propagation and matter fixtures distinct from the cosmological trajectory."""
from collar import *
from types import SimpleNamespace
from scipy.special import spherical_jn


def run():
    result=[]
    class Manufactured(Annulus):
        def __init__(self,grid):
            self.left=4.
            self.dx=1/grid
            self.r=(np.arange(4*grid)+.5)*self.dx+self.left
            self.flag=0
            self.rho=np.array([0.,0.,1.])
            self.mu=3.
            self.incident=SimpleNamespace(bank=SimpleNamespace(at=lambda time:np.zeros((7,len(self.r)))))
    def add(name,value,target,tolerance):
        ratio=abs(value-target)/abs(target)
        result.append(dict(test=name,measured=float(value),expected=float(target),relative=float(ratio),tolerance=tolerance))
        assert ratio<tolerance,(name,ratio)
    for grid in (120,160):
        shell=Manufactured(grid)
        radius=shell.r
        wave=1.3
        freq=np.hypot(shell.mu,wave)-shell.mu
        amp=spherical_jn(2,wave*radius)
        def state(time):
            field=np.zeros((20,2,len(radius)),complex)
            field[14,1]=amp*np.exp(-1j*freq*time)
            field[15,1]=-1j*freq*field[14,1]/shell.mu
            return field
        time=.7
        st=state(time)
        identity=fields(shell,time,st)[2]
        vals=incoming(shell,identity,5.,7.)
        inside=(radius>5.)&(radius<7.)
        actual=-(2+freq/shell.mu)*freq*np.sin(freq*time)*shell.dx*np.sum(amp[inside]/(5*radius[inside]))
        add("spherical KG energy rate "+str(grid),sum(vals[:6]),actual,1e-8)
        exact=spherical_jn(2,wave*7.,derivative=True)*wave*(-np.sin(freq*time))/(shell.mu*5*7.)
        add("outward KG flux "+str(grid),vals[6],exact,1e-10)
        start=state(0)
        delta=mass_change(shell,start,st-start)[2]
        expected=(2+freq/shell.mu)*amp*(np.cos(freq*time)-1)
        add("finite KG density "+str(grid),float(np.linalg.norm(delta[inside])),float(np.linalg.norm(expected[inside])),1e-12)
        flux=shell.faces**5
        cutoff=round((6.-shell.left)/shell.dx)
        add("face primitive "+str(grid),effective(flux)[cutoff+1]-effective(flux)[cutoff],shell.dx*shell.tocell(flux)[cutoff],1e-11)
        add("odd-ghost endpoint factor "+str(grid),effective(flux)[-1]/flux[-1],sum(shell.weights),1e-13)
        expansion=.012
        st[:]=0
        st[0,0]=st[1,0]=expansion*time
        st[4,0]=-3*expansion
        shell.incident.bank.at=lambda now:np.stack((0*radius,0*radius,0*radius,amp*np.exp(-4*expansion*now),0*radius,0*radius,0*radius))
        st[17,1]=amp*np.exp(-4*expansion*time)
        values=incoming(shell,fields(shell,time,st)[0],5.,7.)
        target=-expansion*np.exp(-expansion*time)*shell.dx*np.sum(amp[inside]/(5*radius[inside]))
        add("expanding radiation work "+str(grid),sum(values[:6]),target,1e-12)
    mu=.8
    decay=-.3
    drive=.24
    omega=1.17
    class Oscillator:
        initial=np.zeros((20,2,1),complex)
        flag=0
        def dynamics(self,time,state):
            answer=0*state
            answer[14]=self.mu*state[15]
            answer[15]=(2j*self.mu+decay)*state[15]+drive*np.exp(1j*omega*time)
            return answer
    shell=Oscillator()
    shell.mu=mu
    lam=2j*mu+decay
    final=1.3
    end=drive*(np.exp(1j*omega*final)-np.exp(lam*final))/(1j*omega-lam)
    displacement=mu*drive*(np.expm1(1j*omega*final)/(1j*omega)-np.expm1(lam*final)/lam)/(1j*omega-lam)
    errors=[]
    for count in (8,16,32):
        arr=0*shell.initial
        advance=stepper(shell,final/count)
        for idx in range(count):arr=advance(idx*final/count,arr)
        errors.append(max(abs(arr[14,0,0]/displacement-1),abs(arr[15,0,0]/end-1)))
    assert min(np.array(errors[:-1])/errors[1:])>14 and errors[-1]<1e-7,errors
    result.append(dict(test="ETD forced oscillator 32 steps",measured=float(errors[-1]),expected=0.,relative="",tolerance=1e-7))
    dump("manufactured.csv",result)
    print(len(result),"manufactured controls; ETD errors",errors)


if __name__=="__main__":run()
