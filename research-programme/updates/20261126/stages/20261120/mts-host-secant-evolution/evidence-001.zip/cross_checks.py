from math import isclose
from case import HERE,PRIOR,checked,core,np,table
from readouts import COUNTS,rms
from new_clock import frozen
from phase_prediction import TURNS

def compare():
    checked()
    frozen()
    fields=[]
    ownership=[]
    projected=[]
    for scheme in ("original","adm"):
        for seed in (1,-1):
            wave=lambda mode:np.load(HERE/f"{mode}profiles-{scheme}-off0-s{seed}.npz")
            with wave("number-") as new,wave("") as old,np.load(HERE/f"profiles-{scheme}-off1-s{seed}.npz") as cold,np.load(HERE/f"frozen-current-{scheme}-s{seed}.npz") as predictions:
                for name in ("charge","total","ham","mom_r","mom_theta"):
                    def subtract(first,second):
                        return (first[name]-second[name])+(first[name+"_tail"]-second[name+"_tail"])
                    def within(bank,index,ell):
                        arr,tail=bank[name],bank[name+"_tail"]
                        return (arr[index,ell]-arr[-1,ell])+(tail[index,ell]-tail[-1,ell])
                    reference=subtract(new,cold)
                    diff=subtract(new,old)
                    for idx,count in enumerate(COUNTS):
                        for harmonic in ((1,) if name=="mom_theta" else (0,1)):
                            scale=rms(reference[-1,harmonic])
                            w,c=within(new,idx,harmonic),within(cold,idx,harmonic)
                            fields.append(dict(scheme=scheme,seed=seed,steps=count,ell=2*harmonic,quantity=name,
                                new_minus_old_rms=rms(diff[idx,harmonic]),ref_rms=scale,chart_difference_fraction=rms(diff[idx,harmonic])/scale,
                                wave_clock_error=rms(w),cold_clock_error=rms(c),combined_clock_error=rms(w-c)))
                for win,turns in enumerate(TURNS):
                    for view in ("rate","charge"):
                        fetch=lambda label:predictions[f"window{win}_{view}_{label}"]
                        original,canon,evolved=map(fetch,("launch","canonical_launch","changing"))
                        ownership.append(dict(scheme=scheme,seed=seed,turns=turns,observable=view,launch_rms=rms(original),
                              canonical_rms=rms(canon),conversion_difference_rms=rms(original-canon),changing_forecast_rms=rms(evolved),
                              conversion_over_evolved=rms(original-canon)/rms(evolved),canonical_over_original=rms(canon)/rms(original)))
            for prefix in ("","number-"):
                data=core.read(HERE/(prefix+"matched-tide-scores.csv"))
                for count in COUNTS:
                    for width in (.15,.30):
                        values=[row for row in data if row["scheme"]==scheme and int(row["seed"])==seed and float(row["width"])==width and int(row["steps"])==(1 if count==264 else count)]
                        assert len(values)==2 and {row["channel"] for row in values}=={"ricci","gauss"}
                        key="reference" if count==264 else "trial"
                        tidal_split=(float(values[0][key])-float(values[1][key]))/float(values[0]["newton"])*1e6
                        projected.append(dict(chart=prefix or "wave",scheme=scheme,seed=seed,count=count,width=width,absolute_projected_H_over_six_ppm=abs(tidal_split)))
    table("cross-chart-and-branch-errors.csv",fields)
    table("phase-storage-effect.csv",ownership)
    table("short-clock-projected-constraint.csv",projected)

if __name__=="__main__":
    compare()
