import csv
import io
import json
import sys
from pathlib import Path

HERE=Path(__file__).resolve().parent
PRIOR=HERE.parent/"mts-carrier-qualification-1024-20261120"
sys.path.insert(0,str(PRIOR))
import local_case as parent
from local_case import core,np
from finite_pair import Difference

def guard():
    parent.guard()
    if (HERE/"STOP-REQUESTED").exists():
        raise RuntimeError("owner hold")

def checked():
    guard()
    path=PRIOR/"seal.json"
    assert core.sha(path)=="f1a7c4534f3d029e7004efcbe623d1a78706248e2d004a83cde47bb6a5d1dd96"
    for name,digest in json.loads(path.read_bytes())["files"].items():
        assert core.sha(PRIOR/name)==digest
    parent.verified()

def save(name,raw):
    guard()
    path=HERE/name
    if path.exists():
        assert path.read_bytes()==raw,path
        return
    tmp=path.with_suffix(path.suffix+".partial")
    with tmp.open("xb") as handle:
        handle.write(raw)
    tmp.rename(path)

def packet(name,**fields):
    stream=io.BytesIO()
    np.savez_compressed(stream,**fields)
    save(name,stream.getvalue())

def table(name,rows):
    stream=io.StringIO(newline="")
    writer=csv.DictWriter(stream,fieldnames=list(rows[0]),lineterminator="\n")
    writer.writeheader()
    writer.writerows(rows)
    save(name,stream.getvalue().encode())

def split(zero,host):
    return Difference(zero,host-zero)
