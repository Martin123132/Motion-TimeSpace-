from decimal import getcontext
import mpmath as mp
from case import HERE,checked,core,guard,np,packet,parent,table
from coupled import Evolution
from number_chart import NumberChart
from phase_prediction import TURNS,cold
from new_clock import frozen
from source_terms import D,RadialOperators
from endpoints import convert
from readouts import joined,rms

def coefficient(turns,time,mu,integrated):
    from decimal import Decimal
    with mp.workdps(65):
        om=2j*mp.mpf(float(mu))
        t=mp.mpf(float(time))
        val=(mp.expm1(om*t)/om-t)/om**2 if integrated else mp.expm1(om*t)/om**2
        return Decimal(mp.nstr(val.real,55)),Decimal(mp.nstr(val.imag,55))

def solve(scheme,seed):
    getcontext().prec=46
    w,c=NumberChart(seed,scheme),Evolution(1,seed,scheme)
    ws,cs=w.shell.initial,c.shell.initial
    wr=w.nonlinear(0.,np.zeros_like(ws))
    op=RadialOperators(w.shell.r,w.shell.dx)
    mu=D(float(w.shell.mu))
    rho=D(float(w.shell.rho[-1]))
    use=(w.shell.r>.6)&(w.shell.r<2.1)
    data={}
    for host in (0,seed):
        def at(start,slot,imag=False):
            value=start[slot,0].imag if imag else start[slot,0].real
            return joined(value) if host else convert(value.base)
        el,bend,amp,p=at(ws,0),at(ws,1),at(ws,14),at(ws,14,True)/mu
        phi_c,elc,nc=at(cs,13),at(cs,0),at(cs,12)
        K,Kdot=at(ws,4),at(wr,4)
        zr,zi=at(ws,15),at(ws,15,True)
        deriv=lambda f:op.cell(op.face(f,True),False)
        inv=np.exp(-el)
        uw,uc=inv*deriv(p),np.exp(-elc)*deriv(phi_c)
        gamma=np.sqrt(1+uc**2)
        dc=-uc**2/(1+gamma)
        lap=np.exp(-el-2*bend)*op.cell(op.face_square*np.exp(op.face(2*bend-el))*op.face(amp,True))/op.radius**2
        terms=dict(amplitude=(lap+(inv*deriv(amp))**2)/(2*mu**2),curvature=-(Kdot/2-K**2/4)/(2*mu**2),
                   transformed_velocity=-(zr**2-zi**2)/2,kinetic_state=(uc-uw)*(uc+uw)/2,
                   dust_relativistic=-dc**2/2)
        blank=0*el
        wave=lambda vel:op.strong(el,bend,amp,vel)
        cold_dd=cold(op,nc,elc,phi_c,blank,blank,dc)[1]
        rdot,idot=at(wr,15),at(wr,15,True)
        for win,turns in enumerate(TURNS):
            tm=turns*np.pi/w.shell.mu
            t=D(float(tm))
            for observable in ("rate","charge"):
                isint=observable=="charge"
                er,ei=coefficient(turns,tm,w.shell.mu,isint)
                fac=t*t/2 if isint else t
                values={key:fac*wave(field) for key,field in terms.items()}
                values["shared_dust_phase_operator"]=fac*(wave(dc)-cold_dd)
                values["carrier"]=wave(rdot*ei+idot*er)
                for key,val in values.items():
                    data[host,win,observable,key]=(rho*val)[use]
    output=[]
    packet_fields={}
    keys=tuple(values)
    with np.load(HERE/f"frozen-current-{scheme}-s{seed}.npz") as pack:
        for win,turns in enumerate(TURNS):
            for obs in ("rate","charge"):
                target=pack[f"window{win}_{obs}_phase"]-pack[f"window{win}_{obs}_launch"]
                sub={key:(data[seed,win,obs,key]-data[0,win,obs,key]).astype(float) for key in keys}
                close=rms(sum(sub.values())-target)/rms(target)
                for name,value in sub.items():
                    packet_fields[f"w{win}_{obs}_{name}"]=value
                    output.append(dict(scheme=scheme,seed=seed,turns=turns,observable=obs,term=name,target_rms=rms(target),component_rms=rms(value),
                        rms_ratio=rms(value)/rms(target),projection=value@target/(target@target),relative_closure_error=close))
    packet(f"phase-parts-{scheme}-s{seed}.npz",**packet_fields)
    return output

if __name__=="__main__":
    frozen()
    checked()
    rows=[]
    for scheme in ("original","adm"):
        for seed in (1,-1):
            guard()
            rows+=solve(scheme,seed)
    table("physical-phase-drivers.csv",rows)
    print("closure and amplitude projection",max(r["relative_closure_error"] for r in rows),[(r["projection"],r["observable"],r["turns"]) for r in rows if r["term"]=="amplitude" and r["seed"]==1 and r["scheme"]=="original"])
