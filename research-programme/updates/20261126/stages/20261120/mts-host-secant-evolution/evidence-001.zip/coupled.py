from copy import copy
from unittest.mock import patch
from functools import lru_cache
import sys
from case import Difference,core,guard,np,parent,split
from finite_pair import ArrayConstruction
import trace_stencil
from trace_stencil import FixedTrace
from stagger import Stagger

def addr(field):
    return field.__array_interface__["data"][0],field.shape,field.strides,field.dtype.str

class Source:
    def __init__(self,zero,host):
        self.zero=zero.bank
        self.host=host.bank
        self.local=None

    @lru_cache(maxsize=2)
    def external(self,time):
        return tuple(split(zero,host) for zero,host in zip(self.zero.at(time),self.host.at(time),strict=True))

    def at(self,time):
        rows=list(self.external(time))
        if self.local is not None:
            rows[0],rows[2]=self.local
        return rows

class Evolution:
    def __init__(self,flag,seed,scheme):
        zero=parent.system(flag,0,scheme)
        host=parent.system(flag,seed,scheme)
        self.zero,self.host=zero,host
        assert zero.mu==host.mu and np.array_equal(zero.rho,host.rho)
        shell=copy(zero)
        self.shell=shell
        self.scheme=scheme
        shell.initial=split(zero.initial,host.initial)
        shell.incident=Source(zero.incident,host.incident)
        self.stencil=FixedTrace(6)
        self.original_diff=type(shell).diff
        self.original_face=type(shell).toface
        shell.toface=self.face
        shell.diff=self.diff
        self.active={}
        self.origin={}
        self.precomputed={}
        self.elapsed={}
        self.shapes=[]
        for slot in range(20):
            for component in (None,0,1):
                for kind in ("whole","real","imag"):
                    spec=slot,component,kind
                    field=self.view(shell.initial,spec)
                    self.shapes.append(spec)
                    self.origin[spec]=field
        self.reference=tuple(tuple(split(a,b) for a,b in zip(za,ha,strict=True)) for za,ha in zip(zero.ref_geometry,host.ref_geometry,strict=True))

    @staticmethod
    def view(state,spec):
        slot,component,kind=spec
        raw=state[slot] if component is None else state[slot,component]
        return raw if kind=="whole" else getattr(raw,kind)

    def bind(self,state,shift):
        self.active={addr(self.view(state,spec).base):spec for spec in self.shapes}
        self.elapsed=shift

    def linear(self,op,field,params):
        if op=="diff":
            return self.original_diff(self.shell,field,*params)
        return self.original_face(self.shell,field,*params)

    def apply(self,op,field,params):
        spec=self.active.get(addr(field.base)) if isinstance(field,Difference) else None
        if spec is None:
            return self.linear(op,field,params)
        key=op,spec,params
        if key not in self.precomputed:
            slot,component,kind=spec
            if op=="diff" and slot in (0,1) and kind=="real" and not params[1]:
                ref=self.reference[slot][params[0]]
                self.precomputed[key]=ref if component is None else ref[component]
            else:
                self.precomputed[key]=self.linear(op,self.origin[spec],params)
        return self.precomputed[key]+self.linear(op,self.view(self.elapsed,spec),params)

    def diff(self,field,degree=1,odd=False):
        return self.apply("diff",field,(degree,odd))

    def face(self,field,odd=False,slope=False):
        return self.apply("face",field,(odd,slope)) if slope else self.original_face(self.shell,field,odd,slope)

    def rhs(self,time,shift):
        shell=self.shell
        state=shell.initial+shift
        self.bind(state,shift)
        try:
            out=Stagger.dynamics(shell,time,state)
            if self.scheme=="adm":
                correction=core.ham(shell,state)
                out[4]+=correction
                if not shell.flag:
                    out[15]-=correction/(2*shell.mu)
            with patch.object(trace_stencil,"np",ArrayConstruction()):
                self.stencil.correct(state,out)
            return out
        finally:
            self.active={}
            self.elapsed=None

    def time_step(self,step):
        coeff=core.central.traced.collar.coefficients
        zero=coeff(0.)
        fast=coeff(2j*self.shell.mu*step)
        def apply(idx,field):
            result=zero[idx]*field
            if not self.shell.flag:
                rest=(fast[idx]-zero[idx])*field[15]
                result[14]+=rest/(2j)
                result[15]+=rest
            return result
        def nonlinear(time,shift):
            result=self.rhs(time,shift)
            if not self.shell.flag:
                result[14]-=self.shell.mu*shift[15]
                result[15]-=2j*self.shell.mu*shift[15]
            return result
        def advance(time,shift):
            first=nonlinear(time,shift)
            half=apply(1,shift)
            mid=half+step*apply(2,first)
            second=nonlinear(time+step/2,mid)
            other=half+step*apply(2,second)
            third=nonlinear(time+step/2,other)
            end=apply(1,mid)+step*apply(2,2*third-first)
            fourth=nonlinear(time+step,end)
            return apply(0,shift)+step*(apply(3,first)+apply(4,second+third)+apply(5,fourth))
        return advance
