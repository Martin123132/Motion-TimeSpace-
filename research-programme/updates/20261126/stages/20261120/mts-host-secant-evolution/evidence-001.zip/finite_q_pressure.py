from decimal import getcontext
from unittest.mock import patch
from case import HERE,checked,core,guard,np,parent,table
from endpoints import D,convert
from source_terms import RadialOperators
from newton_pressure import weight

def launch(level,seed):
    if level!=1024:
        return parent.evolve_speed.system(level,320,0,seed,"original",3)[0]
    with patch.object(parent.evolve_speed,"launch",parent.launch):
        return parent.evolve_speed.system(level,320,0,seed,"original",3)[0]

def coefficient(level,seed):
    sh=launch(level,seed)
    op=RadialOperators(sh.r,sh.dx)
    ell,bend,amp,zi=(convert(val) for val in (sh.initial[0,0].real,sh.initial[1,0].real,sh.initial[14,0].real,sh.initial[15,0].imag))
    number=convert(sh.initial[12,0].real)
    a=np.frompyfunc(lambda v:v.ln(),1,1)(number)/2
    M2=D(float(sh.mu))**2/level
    gf=op.face(a,True)
    gc=op.cell(gf,False)
    div=lambda source:op.cell(op.face_square*source)/op.radius**2
    lap=div(gf)
    from_amplitude=lambda var:div(op.face(var,True))+2*gc*op.cell(op.face(var,True),False)
    sources=dict(metric_operator=div(op.face(2*bend-ell)*gf)-(ell+2*bend)*lap-2*ell*gc**2,
        volume_in_amplitude=from_amplitude(-(ell+2*bend)/2),frequency_in_amplitude=from_amplitude(zi/2))
    remainder=from_amplitude(amp-a+(ell+2*bend)/2-zi/2)
    out={}
    for width in (.15,.30):
        wr,dw,_=weight(sh.r,core.ep.CENTER,core.ep.CENTER*width)
        for label,kernel in (("potential_rate",wr),("velocity_rate",-dw)):
            project=lambda val:float(np.sum(convert(kernel)*val)/(D(float(wr.sum()))*2*M2))
            out[width,label]=[level*project(v) for v in (*sources.values(),remainder)]
    return out

def main():
    checked()
    getcontext().prec=46
    values={}
    for level in (64,128):
        for seed in (0,1,-1):
            guard()
            values[level,seed]=coefficient(level,seed)
    authority=core.read(HERE/"mechanical-pressure-limit.csv")
    rows=[]
    for row in authority:
        target=int(row["q"])
        seed=int(row["seed"])
        key=float(row["width"]),row["observable"]
        raw=float(row["q_scaled_slow_amplitude"])-float(row["flat_log_limit"])
        for source in (64,128):
            if source==target:
                continue
            terms=(np.array(values[source,seed][key])-values[source,0][key])/target
            estimate=sum(terms[:3])
            scale=abs(float(row["native_weak"]))
            rows.append(dict(source_q=source,target_q=target,seed=seed,width=key[0],observable=key[1],measured_finite_q=raw,
                predicted_first_order=estimate,metric_operator=terms[0],volume_amplitude=terms[1],normal_frequency=terms[2],
                source_representation_remainder=terms[3],error_fraction_of_finite_q=(estimate-raw)/abs(raw),error_fraction_of_native=(estimate-raw)/scale))
    table("finite-geometry-coefficient.csv",rows)
    print([(target,max(abs(row["error_fraction_of_finite_q"]) for row in rows if row["target_q"]==target)) for target in (64,128,1024)])

if __name__=="__main__":
    main()
