from math import fsum
import mpmath as mp
from case import HERE,Difference,checked,core,guard,np,table
from coupled import Evolution

def operations():
    rows=[]
    with mp.workdps(90):
        for magnitude in (1e-25,-1e-11,.24):
            first,second=Difference(np.array([1.31]),np.array([magnitude])),Difference(np.array([.83]),np.array([2*magnitude]))
            for name,fun in (("product",lambda a,b,m:a*b),("quotient",lambda a,b,m:a/b),("square",lambda a,b,m:a**2),
                             ("exp",lambda a,b,m:m.exp(a*b)),("root",lambda a,b,m:m.sqrt(a/b))):
                value=fun(first,second,np).delta[0]
                xa,xb=mp.mpf(1.31),mp.mpf(.83)
                exact=float(fun(xa+mp.mpf(magnitude),xb+2*mp.mpf(magnitude),mp)-fun(xa,xb,mp))
                assert np.isclose(value,exact,rtol=2e-14,atol=1e-50),(name,exact,value)
                rows.append(dict(test=name,magnitude=magnitude,measured=value,expected=exact))
    table("algebra-checks.csv",rows)

def controls():
    rows=[]
    for scheme in ("original","adm"):
        for flag in (0,1):
            for seed in (0,1,-1):
                guard()
                evo=Evolution(flag,seed,scheme)
                shell=evo.shell
                for test in ("launch","manufactured"):
                    shift=np.zeros_like(shell.initial)
                    if test=="manufactured":
                        for index in range(20):
                            phase=np.sin(shell.r*(1+.11*index))+.23*np.cos(3*shell.r)
                            direction=np.array([phase,.45*phase])
                            amplitude=(3e-5 if index not in (17,18,19) else 1e-12)
                            if index in (14,15):
                                direction=direction*(1+.3j)
                            shift.base[index]=amplitude*direction
                            if seed:
                                shift.delta[index]=amplitude*direction*.27*seed
                    expect0=evo.zero.dynamics(0.,evo.zero.initial+shift.base)
                    expect1=evo.host.dynamics(0.,evo.host.initial+shift.base+shift.delta)
                    got=evo.rhs(0.,shift)
                    reconstructed=got.base+got.delta
                    if seed==0:
                        np.testing.assert_array_equal(got.delta,np.zeros_like(got.delta))
                    for part,actual,reference in (("base",got.base,expect0),("host",reconstructed,expect1),("finite_offset",got.delta,expect1-expect0)):
                        for index in range(20):
                            absolute=np.max(abs(actual[index]-reference[index]))
                            scale=np.max(abs(reference[index]))
                            limit=3e-9*scale+8e-13
                            assert absolute<=limit,(scheme,flag,seed,test,part,index,absolute,scale)
                            if part=="base" and test=="launch":
                                np.testing.assert_array_equal(actual[index],reference[index])
                            rows.append(dict(scheme=scheme,flag=flag,seed=seed,state=test,view=part,slot=index,absolute_error=absolute,reference_peak=scale,absolute_bound=limit))
    table("rhs-controls.csv",rows)
    print("checked",len(rows),"slot comparisons")

if __name__=="__main__":
    checked()
    operations()
    controls()
