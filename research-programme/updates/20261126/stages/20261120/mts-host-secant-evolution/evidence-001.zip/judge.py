from decimal import getcontext
from unittest.mock import patch
import sys
from case import HERE,PRIOR,Difference,checked,core,guard,np,packet,parent,split,table
from readouts import rms,member_readings,fields,incremental,with_number
from source_terms import RadialOperators,profile,D
from new_clock import COUNTS,frozen
from phase_prediction import MODELS,TURNS
from carrier_readings import minus_one
import detector

def newton():
    from math import fsum
    rows=[]
    with patch.object(detector,"DURATION",core.DURATION*25.625/4096):
        low,high=detector.evolve(4),detector.evolve(8)
    for seed in (1,-1):
        for width in (.15,.30):
            def value(bank):
                return fsum(sign*float(bank[host,flag,1.,width][0]) for flag,host,sign in ((0,seed,1),(0,0,-1),(1,seed,-1),(1,0,1)))
            ref=value(high)
            rows.append(dict(seed=seed,width=width,newton=ref,subdivision_change_ppm=1e6*(value(low)-ref)/abs(ref)))
    table("long-clock-newton.csv",rows)

def momenta(start,change,mu):
    mul,exp=parent.prior.mul,parent.prior.exp
    vel=start[15]+start[4].real/(2*mu)
    dv=change[15]+change[4].real/(2*mu)
    unit=parent.prior.pair(np.ones_like(vel.base[0]))
    def calc(rest):
        return mul(exp(start[14]),mul(minus_one(change[14]),vel-1j*rest*unit)+mul(exp(change[14]),dv)).delta
    return dict(normal_momentum=calc(1),excitation_momentum=calc(0),log_velocity=dv.delta)

def score_scheme(scheme):
    checked()
    frozen()
    getcontext().prec=46
    tol_rows=[]
    profiles=[]
    tides=[]
    momentum_rows=[]
    for win,turns in enumerate(TURNS):
        counts=(1,132,264) if win==0 else COUNTS
        for seed in (1,-1):
            evidence={}
            for flag in (0,1):
                zero,host=(parent.system(flag,s,scheme) for s in (0,seed))
                assert np.array_equal(zero.rho,host.rho)
                rho=D(float(host.rho[-1]))
                use=(host.r>.6)&(host.r<2.1)
                op=RadialOperators(host.r,host.dx)
                zz,hz=(fields(sh,np.zeros_like(sh.initial)) for sh in (zero,host))
                ref_state=split(zero.initial,host.initial)
                for count in counts:
                    guard()
                    prefix="extended-" if win else ("" if flag else "number-")
                    with np.load(HERE/f"{prefix}{scheme}-off{flag}-s{seed}-n{count}.npz") as bank:
                        common,off=bank["common"],bank["signed"]
                        number0,dnumber=(bank["common_number"],bank["signed_number"]) if win or not flag else (common[12].real,off[12].real)
                        time=float(bank["time"])
                        np.testing.assert_allclose(time,turns*np.pi/host.mu,rtol=2e-15)
                    shift=Difference(common,off)
                    zp,hp=profile(zero,common,op),profile(host,shift,op)
                    name="dust" if flag else "wave"
                    evidence[count,flag,"rate"]=rho*(hp[name]-zp[name])[use]
                    evidence[count,flag,"charge"]=rho*core.ep.convert(dnumber[0,use])
                    if not flag:
                        for name,values in momenta(ref_state,shift,host.mu).items():
                            evidence[count,flag,name]=values[:,use]
                    if win:
                        if flag:
                            lower=incremental(zero,common,zz)
                            upper=incremental(host,shift,hz)
                        else:
                            lower=with_number(zero,common,number0,incremental(zero,common,zz))
                            upper=with_number(host,shift,Difference(number0,dnumber),incremental(host,shift,hz))
                        for name in ("total","ham","mom_r","mom_theta"):
                            evidence[count,flag,name]=(upper[name]-lower[name])[:,use]
                        tz,th=member_readings(zero,time,common),member_readings(host,time,shift)
                        for key in tz:
                            evidence[count,flag,*key]=th[key]-tz[key]
            norm=lambda arr:rms(arr.astype(complex) if np.iscomplexobj(arr) else arr.astype(float))
            last=counts[-1]
            with np.load(HERE/f"frozen-current-{scheme}-s{seed}.npz") as prediction:
                for name in ("rate","charge"):
                    actual=(evidence[last,0,name]-evidence[last,1,name]).astype(float)
                    packet(f"actual-w{win}-{scheme}-s{seed}-{name}.npz",radial=actual,turns=turns,reference_steps=last)
                    ref=norm(actual)
                    for label in MODELS:
                        pred=prediction[f"window{win}_{name}_{label}"]
                        rel=norm(pred-actual)/ref
                        tol_rows.append(dict(scheme=scheme,seed=seed,turns=turns,observable=name,model=label,actual_rms=ref,
                            predicted_rms=norm(pred),error_rms=norm(pred-actual),relative_error=rel,below_one_percent=rel<.01))
            for count in counts[:-1]:
                for name in ("normal_momentum","excitation_momentum","log_velocity"):
                    for harmonic in (0,1):
                        ref=evidence[last,0,name][harmonic]
                        delta=evidence[count,0,name][harmonic]-ref
                        momentum_rows.append(dict(seed=seed,scheme=scheme,turns=turns,steps=count,quantity=name,ell=2*harmonic,relative=norm(delta)/norm(ref),ref_rms=norm(ref),error_rms=norm(delta)))
                for name in (("charge","rate","total","ham","mom_r","mom_theta") if win else ("charge","rate")):
                    full=evidence[last,0,name]-evidence[last,1,name]
                    trial=evidence[count,0,name]-evidence[count,1,name]
                    if name in ("charge","rate"):
                        full,trial=full[None,:],trial[None,:]
                    for harmonic,ref in enumerate(full):
                        if name=="mom_theta" and not harmonic:
                            continue
                        error=norm(trial[harmonic]-ref)
                        profiles.append(dict(scheme=scheme,seed=seed,turns=turns,steps=count,observable=name,ell=2*harmonic,truth_rms=norm(ref),error_rms=error,relative=error/norm(ref)))
            if win:
                for count in counts:
                    for width in (.15,.30):
                        for ch in ("ricci","gauss"):
                            value=evidence[count,0,width,ch]-evidence[count,1,width,ch]
                            tides.append(dict(scheme=scheme,seed=seed,count=count,width=width,channel=ch,tidal_change=value))
    table(f"forecast-scores-{scheme}.csv",tol_rows)
    table(f"paired-resolution-{scheme}.csv",profiles)
    table(f"physical-momenta-{scheme}.csv",momentum_rows)
    table(f"long-clock-tides-{scheme}.csv",tides)
    print(scheme,[(q,max(row["relative_error"] for row in tol_rows if row["observable"]==q and row["model"]=="changing")) for q in ("charge","rate")])

def tide_gates():
    ng={(int(r["seed"]),float(r["width"])):abs(float(r["newton"])) for r in core.read(HERE/"long-clock-newton.csv")}
    values={}
    for scheme in ("original","adm"):
        for row in core.read(HERE/f"long-clock-tides-{scheme}.csv"):
            values[scheme,int(row["seed"]),int(row["count"]),float(row["width"]),row["channel"]]=float(row["tidal_change"])
    rows=[]
    for (scheme,seed,count,width,ch),value in values.items():
        unit=ng[seed,width]*1e-6
        error=(value-values[scheme,seed,820,width,ch])/unit
        cross=(value-values["adm" if scheme=="original" else "original",seed,count,width,ch])/unit
        split=(value-values[scheme,seed,count,width,"ricci" if ch=="gauss" else "gauss"])/unit
        rows.append(dict(scheme=scheme,seed=seed,count=count,width=width,channel=ch,clock_ppm=error,formulation_ppm=cross,readout_ppm=split,
                         joint_tidal_screen=max(abs(error),abs(cross),abs(split))<=20))
    table("extended-tide-gates.csv",rows)
    print("long clock gates",sum(r["joint_tidal_screen"] for r in rows),len(rows))

if __name__=="__main__":
    if sys.argv[1]=="newton":
        newton()
    elif sys.argv[1]=="gates":
        tide_gates()
    else:
        score_scheme(sys.argv[1])
