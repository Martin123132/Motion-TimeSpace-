from decimal import getcontext
import sys
from case import HERE,Difference,checked,core,guard,np,packet,parent,table
from new_clock import frozen
from number_chart import NumberChart
from endpoints import D,convert
from readouts import joined,rms
from source_terms import RadialOperators,profile

class Canonical(NumberChart):
    def __init__(self,seed,scheme):
        super().__init__(seed,scheme)
        getcontext().prec=46
        mu=D(float(self.shell.mu))
        def residual(shell):
            phi=shell.initial[14,0].imag
            canonical=shell.initial[13,0].real
            np.testing.assert_array_equal(phi,shell.mu*canonical)
            return mu*convert(canonical)-convert(phi)
        za,ha=residual(self.zero),residual(self.host)
        self.remainder=Difference(za.astype(float),(ha-za).astype(float))
        assert np.max(abs(self.remainder.base))<1e-48
        self.corrections={}
        self.used=set()

    def apply(self,op,field,params):
        spec=self.active.get((field.base.__array_interface__["data"][0],field.base.shape,field.base.strides,field.base.dtype.str)) if isinstance(field,Difference) else None
        value=super().apply(op,field,params)
        if spec is None or spec[0]!=14 or spec[2]=="real" or spec[1]==1:
            return value
        if not (op=="face" and params==(False,True) or op=="diff" and params==(1,False)):
            raise ValueError((op,spec,params))
        self.used.add((op,spec[2]))
        key=op,spec,params
        if key not in self.corrections:
            correction=self.linear(op,self.remainder,params)
            if spec[2]=="whole":
                correction=1j*correction
            if spec[1] is None:
                correction=np.stack((correction,np.zeros_like(correction)))
            self.corrections[key]=correction
        return value+self.corrections[key]

def run(scheme):
    checked()
    frozen()
    getcontext().prec=46
    rows=[]
    for seed in (1,-1):
        model=Canonical(seed,scheme)
        zero=parent.system(1,0,scheme)
        host=parent.system(1,seed,scheme)
        for actual,control in ((model.zero,zero),(model.host,host)):
            np.testing.assert_array_equal(actual.initial[13,0].real,control.initial[13,0].real)
        rho=D(float(host.rho[-1]))
        mu=D(float(host.mu))
        op=RadialOperators(host.r,host.dx)
        use=(host.r>.6)&(host.r<2.1)
        time=25.625*np.pi/host.mu
        with np.load(HERE/f"frozen-current-{scheme}-s{seed}.npz") as pred:
            for count in (410,820):
                step=time/count
                advance=model.time_step(step)
                shift=np.zeros_like(model.shell.initial)
                for tick in range(count):
                    if not tick%8:
                        guard()
                    shift=advance(tick*time/count,shift)
                physical=model.to_wave(shift)
                assert {("face","whole"),("diff","whole")}<=model.used
                packet(f"canonical-{scheme}-s{seed}-n{count}.npz",common=physical.base,signed=physical.delta,
                    common_number=shift.base[14].real,signed_number=shift.delta[14].real)
                with np.load(HERE/f"extended-{scheme}-off1-s{seed}-n{count}.npz") as cold:
                    c0,dc=cold["common"],cold["signed"]
                    charge=rho*(convert(shift.delta[14,0].real)-convert(cold["signed_number"][0]))
                dust=profile(host,Difference(c0,dc),op)["dust"]-profile(zero,c0,op)["dust"]
                def strong(shell,inc):
                    def at(index):
                        return joined(shell.initial[index,0].real)+joined(inc[index,0].real)
                    potential=joined(shell.initial[13,0].real)+joined(inc[14,0].imag)/mu
                    return op.strong(at(0),at(1),at(14),potential)
                rate=rho*(strong(model.host,physical)-strong(model.zero,physical.base)-dust)
                for obs,array in (("rate",rate),("charge",charge)):
                    arr=array[use].astype(float)
                    forecast=lambda k:pred[f"window1_{obs}_{k}"]
                    base=forecast("changing")
                    corrected=base+forecast("canonical_launch")-forecast("launch")
                    with np.load(HERE/f"actual-w1-{scheme}-s{seed}-{obs}.npz") as archive:
                        stored=archive["radial"]
                    packet(f"canonical-readout-{scheme}-s{seed}-n{count}-{obs}.npz",radial=arr)
                    projected=corrected-base
                    rows.append(dict(scheme=scheme,seed=seed,count=count,observable=obs,actual_rms=rms(arr),
                        old_forecast_relative=rms(base-arr)/rms(arr),canonical_forecast_relative=rms(corrected-arr)/rms(arr),
                        rerun_shift_over_old=rms(arr-stored)/rms(stored),predicted_shift_over_old=rms(projected)/rms(stored),
                        shift_error_over_old=rms((arr-stored)-projected)/rms(stored)))
                print("canonical",scheme,seed,count,flush=True)
    table(f"canonical-tests-{scheme}.csv",rows)

if __name__=="__main__":
    run(sys.argv[1])
