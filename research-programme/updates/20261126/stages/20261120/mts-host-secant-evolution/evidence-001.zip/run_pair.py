import sys
from case import HERE,checked,core,guard,np,packet
from coupled import Evolution

def run(scheme,counts):
    checked()
    assert len(core.read(HERE/"rhs-controls.csv"))==1440
    assert len(core.read(HERE/"algebra-checks.csv"))==15
    for flag in (0,1):
        for seed in (1,-1):
            guard()
            evo=Evolution(flag,seed,scheme)
            time=8.25*np.pi/evo.shell.mu
            for count in counts:
                assert count in (1,4,33,66,132,264)
                advance=evo.time_step(time/count)
                shift=np.zeros_like(evo.shell.initial)
                for idx in range(count):
                    if not idx%8:
                        guard()
                    shift=advance(idx*(time/count),shift)
                assert np.isfinite(shift.base).all() and np.isfinite(shift.delta).all()
                packet(f"{scheme}-off{flag}-s{seed}-n{count}.npz",r=evo.shell.r,time=time,common=shift.base,signed=shift.delta)
                print(scheme,flag,seed,count,flush=True)

if __name__=="__main__":
    run(sys.argv[1],tuple(map(int,sys.argv[2:])))
