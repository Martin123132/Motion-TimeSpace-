from decimal import getcontext
from case import HERE,checked,core,guard,np,table
from canonical import Canonical
from number_chart import NumberChart
from readouts import joined,rms
from source_terms import D,RadialOperators
from endpoints import convert

def main():
    checked()
    rows=[]
    getcontext().prec=46
    for seed in (1,-1):
        for scheme in ("original","adm"):
            guard()
            regular=NumberChart(seed,scheme)
            repaired=Canonical(seed,scheme)
            shell=repaired.shell
            null=np.zeros_like(shell.initial)
            new=repaired.nonlinear(0.,null).delta[14,0].real
            old=regular.nonlinear(0.,null).delta[14,0].real
            use=(shell.r>.6)&(shell.r<2.1)
            op=RadialOperators(shell.r,shell.dx)
            rem=convert(repaired.remainder.delta)
            face=op.face(rem,True)
            comp={"diff":op.cell(face,False),"face":face}
            for key,ref in comp.items():
                rep=next(value for (name,spec,params),value in repaired.corrections.items() if name==key and spec==(14,None,"whole"))
                vals=rep.delta[0].imag
                exact=ref.astype(float)
                sl=slice(10,-10)
                error=rms((vals-exact)[sl])/rms(exact[sl])
                assert error<1e-14
                rows.append(dict(seed=seed,scheme=scheme,quantity=key,relative_error=error))
            def target(sh):
                a,b,u=(convert(sh.initial[idx,0].real) for idx in (0,1,14))
                mu=D(float(sh.mu))
                physical=convert(sh.initial[13,0].real)
                rounded=convert(sh.initial[14,0].imag)/mu
                return op.strong(a,b,u,physical-rounded)
            exact=(target(repaired.host)-target(repaired.zero))[use].astype(float)
            err=rms((new-old)[use]-exact)/rms(exact)
            rows.append(dict(seed=seed,scheme=scheme,quantity="operator_response_to_phase_repair",relative_error=err))
    table("canonical-gradient-controls.csv",rows)
    print(max(r["relative_error"] for r in rows))

if __name__=="__main__":
    main()
