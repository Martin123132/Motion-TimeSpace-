from decimal import getcontext
from math import fsum
from case import HERE,Difference,checked,core,guard,np,parent,table
from readouts import COUNTS,joined,rms
from endpoints import D,convert

class RadialOperators:
    def __init__(self,r,h,high=True):
        self.high=high
        self.radius=convert(r) if high else r
        self.step=D(float(h)) if high else h
        face=np.arange(r.size+1)*h
        self.face_square=(convert(face) if high else face)**2
        w=(75/64,-25/384,3/640)
        avg=(75/128,-25/256,3/256)
        self.weights=tuple(map(D,w)) if high else w
        self.average=tuple(map(D,avg)) if high else avg

    def face(self,value,slope=False):
        n=len(value)+1
        ext=np.concatenate((value[2::-1],value,value[:-4:-1]))
        if slope:
            return sum(a*(ext[3+j:3+j+n]-ext[2-j:2-j+n]) for j,a in enumerate(self.weights))/self.step
        return sum(a*(ext[3+j:3+j+n]+ext[2-j:2-j+n]) for j,a in enumerate(self.average))

    def cell(self,value,slope=True):
        n=len(value)-1
        ext=np.concatenate((-value[2:0:-1],value,-value[-2:-4:-1]))
        if slope:
            return sum(a*(ext[3+j:3+j+n]-ext[2-j:2-j+n]) for j,a in enumerate(self.weights))/self.step
        return sum(a*(ext[3+j:3+j+n]+ext[2-j:2-j+n]) for j,a in enumerate(self.average))

    def flux(self,number,ell,potential,frequency=None):
        inverse=np.exp(-self.face(ell))
        momentum=self.face(potential,True)
        mass_shell=np.sqrt(1+(inverse*momentum)**2)
        factor=mass_shell if frequency is None else self.face(frequency)
        flux=self.face_square*self.face(number)*inverse**2*momentum/factor
        return -self.cell(flux)/self.radius**2

    def strong(self,ell,bend,amp,potential):
        slope=self.face(potential,True)
        metric=np.exp(self.face(2*bend-ell))
        div=self.cell(self.face_square*metric*slope)/self.radius**2
        advective=2*np.exp(2*bend-ell)*self.cell(self.face(amp,True),False)*self.cell(slope,False)
        return -np.exp(2*amp)*(div+advective)

def fixture():
    rows=[]
    for cells in (8,16,32,64):
        r=(np.arange(3*cells)+.5)/cells
        op=RadialOperators(r,1/cells,False)
        amp=.05*np.exp(-r*r)
        pot=.17*np.exp(-.7*r*r)
        ell=.01*np.exp(-.4*r*r)
        bend=.007*np.exp(-r*r)
        grad=-1.4*r*pot
        curv=(-1.4+1.96*r*r)*pot
        full=-np.exp(2*amp+2*bend-ell)*(curv+(2/r-4*r*bend+.8*r*ell-4*r*amp)*grad)
        num=np.exp(ell+2*bend+2*amp)
        wave=op.strong(ell,bend,amp,pot)
        face=op.flux(num,ell,pot,np.ones_like(r))
        select=(r>.70)&(r<2.05)
        errs=dict(wave_relative=rms((wave-full)[select])/rms(full[select]),flux_relative=rms((face-full)[select])/rms(full[select]),product_defect=rms((wave-face)[select])/rms(full[select]))
        rows.append(dict(cells_per_mpc=cells,**errs))
    for previous,current in zip(rows,rows[1:]):
        for key in errs:
            assert previous[key]/current[key]>25,(previous,current,key)
    table("current-spatial-fixture.csv",rows)

def profile(shell,shift,op):
    def at(idx,imaginary=False):
        select=lambda value:value.imag if imaginary else value.real
        return joined(select(shell.initial[idx,0]))+joined(select(shift[idx,0]))
    ell=at(0)
    if shell.flag:
        return {"dust":op.flux(at(12),ell,at(13))}
    bend,amp,frequency=at(1),at(14),1-at(15,True)
    potential=at(14,True)/D(float(shell.mu))
    number=np.exp(ell+2*bend+2*amp)*frequency
    wave=op.strong(ell,bend,amp,potential)
    face=op.flux(number,ell,potential,frequency)
    dust=op.flux(number,ell,potential)
    return dict(wave=wave,product=wave-face,frequency=face-dust,wave_as_dust=dust)

def main():
    checked()
    getcontext().prec=46
    fixture()
    rows=[]
    for scheme in ("original","adm"):
        for seed in (1,-1):
            members={}
            for flag in (0,1):
                zero,host=(parent.system(flag,s,scheme) for s in (0,seed))
                op=RadialOperators(host.r,host.dx)
                rho=D(float(host.rho[-1]))
                assert rho==D(float(zero.rho[-1]))
                use=(host.r>.6)&(host.r<2.1)
                for count in (0,1,132,264):
                    if count:
                        name=("number-" if not flag else "")+f"{scheme}-off{flag}-s{seed}-n{count}.npz"
                        with np.load(HERE/name) as bank:
                            common=bank["common"]
                            diff=bank["signed"]
                    else:
                        common=np.zeros_like(host.initial)
                        diff=np.zeros_like(host.initial)
                    zs=profile(zero,common,op)
                    hs=profile(host,Difference(common,diff),op)
                    for key in zs:
                        members[count,key]=(hs[key][use]-zs[key][use])*rho
            for count in (0,1,132,264):
                total=(members[count,"wave"]-members[count,"dust"]).astype(float)
                comps={key:members[count,key].astype(float) for key in ("product","frequency")}
                comps["state"]=(members[count,"wave_as_dust"]-members[count,"dust"]).astype(float)
                scale=rms(total)
                assert scale>0
                defect=rms(total-sum(comps.values()))
                assert defect<2e-14*max(scale,*map(rms,comps.values()))
                def contrib(key,field):
                    return dict(scheme=scheme,seed=seed,steps=count,term=key,total_rms=scale,term_rms=rms(field),
                        rms_ratio=rms(field)/scale,projection=field@total/(total@total),closure_rms=defect)
                rows.extend(contrib(key,field) for key,field in comps.items())
                rows.append(contrib("wave_before_cold_subtraction",members[count,"wave"].astype(float)))
                rows.append(contrib("dust_before_subtraction",members[count,"dust"].astype(float)))
    table("monopole-current-sources.csv",rows)
    print([(key,min(r["projection"] for r in rows if r["term"]==key),max(r["projection"] for r in rows if r["term"]==key)) for key in ("product","frequency","state")])

if __name__=="__main__":
    main()
