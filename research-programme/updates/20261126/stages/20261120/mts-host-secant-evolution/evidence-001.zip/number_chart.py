from case import HERE,PRIOR,Difference,checked,core,guard,np,packet,parent,table
from coupled import Evolution
from finite_pair import base,offset
from carrier_readings import minus_one

pair,mul,inv,exp,square=parent.prior.pair,parent.prior.mul,parent.prior.inv,parent.prior.exp,parent.prior.square

def log_one(field):
    return pair(np.log1p(field[0]),field[1]/(1+field[0]))

class NumberChart(Evolution):
    def __init__(self,seed,scheme):
        super().__init__(0,seed,scheme)
        initial=self.shell.initial
        self.unit=pair(np.ones_like(self.shell.r))
        self.vfactor=self.unit-initial[15].imag
        self.initial_number=mul(exp(initial[0].real+2*initial[1].real+2*initial[14].real),self.vfactor)
        self.inverse_initial=inv(self.initial_number)
        self.inverse_v=inv(self.vfactor)
        self.min_number=np.inf
        self.min_factor=np.inf

    def to_wave(self,stored):
        dratio=mul(stored[14].real,self.inverse_initial)
        dv=mul(stored[15].imag,self.inverse_v)
        for arr,name in ((dratio[0],"min_number"),(-dv[0],"min_factor")):
            lower=1+min(np.min(arr.base),np.min(arr.base+arr.delta))
            if lower<=0:
                raise ValueError("nonpositive "+name)
            setattr(self,name,min(getattr(self,name),lower))
        du=(log_one(dratio)-stored[0].real-2*stored[1].real-log_one(-dv))/2
        change=stored.copy()
        change[14]=du+1j*stored[14].imag
        return change

    def to_number(self,physical):
        dlog=physical[0].real+2*physical[1].real+2*physical[14].real
        dv=mul(physical[15].imag,self.inverse_v)
        dn=mul(self.initial_number,minus_one(dlog)-mul(exp(dlog),dv))
        stored=physical.copy()
        stored[14]=dn+1j*physical[14].imag
        return stored

    def nonlinear(self,time,stored):
        shell=self.shell
        shift=self.to_wave(stored)
        out=self.rhs(time,shift)
        state=shell.initial+shift
        self.bind(state,shift)
        try:
            ell,bend,tilt=state[:3].real
            wave,zeta=state[14:16]
            grad=mul(exp(-ell),self.diff(wave))
            spatial=shell.lap(wave,ell,bend,tilt)+square(grad)
            prefactor=mul(self.initial_number+stored[14].real,inv(self.unit-zeta.imag))
            charge_rate=-mul(prefactor,spatial.imag)/shell.mu
            out[14]=charge_rate+1j*shell.mu*shell.initial[15].imag
            out[15]=2j*shell.mu*shell.initial[15]+(spatial-out[4].real/2+square(state[4].real)/4)/shell.mu-shell.mu*square(zeta)
            return out
        finally:
            self.active={}
            self.elapsed=None

    def time_step(self,step):
        coeff=core.central.traced.collar.coefficients
        zero=coeff(0.)
        fast=coeff(2j*self.shell.mu*step)
        def apply(idx,arr):
            result=zero[idx]*arr
            rest=(fast[idx]-zero[idx])*arr[15]
            result[14]+=1j*(rest/(2j)).imag
            result[15]+=rest
            return result
        def advance(time,shift):
            first=self.nonlinear(time,shift)
            half=apply(1,shift)
            mid=half+step*apply(2,first)
            second=self.nonlinear(time+step/2,mid)
            other=half+step*apply(2,second)
            third=self.nonlinear(time+step/2,other)
            end=apply(1,mid)+step*apply(2,2*third-first)
            fourth=self.nonlinear(time+step,end)
            return apply(0,shift)+step*(apply(3,first)+apply(4,second+third)+apply(5,fourth))
        return advance

def calibrate():
    checked()
    rows=[]
    for scheme in ("original","adm"):
        for seed in (0,1,-1):
            model=NumberChart(seed,scheme)
            start=model.shell.initial
            for test in ("launch","matched","finite"):
                wave=np.zeros_like(start)
                if test=="matched":
                    if seed:
                        with np.load(HERE/f"{scheme}-off0-s{seed}-n132.npz") as bank:
                            wave=Difference(bank["common"],bank["signed"])
                elif test=="finite":
                    phase=np.cos(model.shell.r*1.7)
                    for idx in (0,1,4,14,15):
                        wave.base[idx]=pair(phase*.003,phase*.001)
                        wave.delta[idx]=pair(phase*.0003,-phase*.0001)*seed
                    wave.base[14:16]*=1+.3j
                    wave.delta[14:16]*=1+.4j
                stored=model.to_number(wave)
                inverse=model.to_wave(stored)
                for label in ("base","delta"):
                    a,b=getattr(inverse,label),getattr(wave,label)
                    np.testing.assert_allclose(a,b,rtol=2e-13,atol=3e-18)
                old=model.rhs(0.,wave)
                result=model.nonlinear(0.,stored)
                result[15]+=2j*model.shell.mu*stored[15]
                result[14]+=1j*model.shell.mu*stored[15].imag
                state=start+wave
                recovered=(mul(result[14].real,inv(model.initial_number+stored[14].real))-result[0].real-2*result[1].real+
                    mul(result[15].imag,inv(model.unit-state[15].imag)))/2+1j*result[14].imag
                result[14]=recovered
                for label in ("base","delta"):
                    cur,ref=getattr(result,label),getattr(old,label)
                    scale=np.max(abs(ref),axis=(1,2))
                    err=np.max(abs(cur-ref),axis=(1,2))
                    assert np.all(err<2e-12*scale+3e-15),(scheme,seed,test,label,err)
                    rows.append(dict(scheme=scheme,seed=seed,state=test,member=label,amplitude_error=err[14],velocity_error=err[15],
                                     inverse_error=np.max(abs(getattr(inverse,label)-getattr(wave,label)))))
    table("number-chart-rhs-controls.csv",rows)
    print("checked chart conjugacy",len(rows))

def run(scheme):
    checked()
    assert len(core.read(HERE/"number-chart-rhs-controls.csv"))==36
    for seed in (1,-1):
        model=NumberChart(seed,scheme)
        time=8.25*np.pi/model.shell.mu
        for count in (1,4,33,66,132,264):
            advance=model.time_step(time/count)
            shift=np.zeros_like(model.shell.initial)
            for idx in range(count):
                if not idx%8:
                    guard()
                shift=advance(idx*(time/count),shift)
            physical=model.to_wave(shift)
            packet(f"number-{scheme}-off0-s{seed}-n{count}.npz",r=model.shell.r,time=time,common=physical.base,signed=physical.delta,
                common_number=shift.base[14].real,signed_number=shift.delta[14].real,
                min_relative_number=model.min_number,min_relative_factor=model.min_factor)
            print("number",scheme,seed,count,flush=True)

if __name__=="__main__":
    import sys
    if sys.argv[1]=="check":
        calibrate()
    else:
        run(sys.argv[1])
