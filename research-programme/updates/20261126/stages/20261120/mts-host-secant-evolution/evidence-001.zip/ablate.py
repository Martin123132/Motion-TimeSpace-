from case import HERE,core,np,table
from readouts import rms
from phase_prediction import TURNS

def main():
    rows=[]
    for scheme in ("original","adm"):
        for seed in (1,-1):
            with np.load(HERE/f"frozen-current-{scheme}-s{seed}.npz") as pred,np.load(HERE/f"phase-parts-{scheme}-s{seed}.npz") as parts:
                for win,turns in enumerate(TURNS):
                    for obs in ("rate","charge"):
                        with np.load(HERE/f"actual-w{win}-{scheme}-s{seed}-{obs}.npz") as truth:
                            actual=truth["radial"]
                        field=lambda name:pred[f"window{win}_{obs}_{name}"]
                        term=lambda name:parts[f"w{win}_{obs}_{name}"]
                        primary=field("changing")
                        alternatives=dict(full=primary,no_amplitude=primary-term("amplitude"),opposite_amplitude=primary-2*term("amplitude"),
                            no_carrier=primary-term("carrier"),replace_rounded_launch_only=primary+field("canonical_launch")-field("launch"))
                        for label,value in alternatives.items():
                            error=rms(value-actual)/rms(actual)
                            rows.append(dict(scheme=scheme,seed=seed,turns=turns,observable=obs,alternative=label,error_fraction=error,
                                below_one_percent=error<.01))
    table("physics-ablation.csv",rows)
    for name in alternatives:
        print(name,[(obs,max(r["error_fraction"] for r in rows if r["turns"]==25.625 and r["observable"]==obs and r["alternative"]==name)) for obs in ("rate","charge")])

if __name__=="__main__":
    main()
