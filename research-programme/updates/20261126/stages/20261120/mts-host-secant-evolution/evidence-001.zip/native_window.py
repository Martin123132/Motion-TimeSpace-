from numpy.polynomial.legendre import legfit,legder,legval,leggauss
from case import HERE,checked,core,np,parent,table
from newton_pressure import weight

def probe(seed):
    sim=parent.prior.sphere(144,5)
    mesh=sim.mesh
    state=parent.prior.start_state(sim,144,5,seed)
    j=sim.patch.j
    density=state[0][0,j]
    r=mesh.r[1:]
    values=mesh.grid(density/(1+np.sqrt(1+density/r)))
    M=core.family.pressure(0)[0]["a"]*sim.patch.p.mass
    gx,gw=leggauss(20)
    out={}
    for width in (.15,.3):
        centre=core.ep.CENTER
        half=centre*width
        for division in (1,2,4,8):
            numerator=np.zeros(2)
            denominator=0
            for element in mesh.elem:
                positions=mesh.r[element]
                left,right=positions[0],positions[-1]
                if right<centre-half or left>centre+half:
                    continue
                stretch=2/(right-left)
                local=(positions-left)*stretch-1
                amplitudes=legfit(local,values[element],len(element)-1)
                for piece in range(division):
                    a=left+(right-left)*piece/division
                    size=(right-left)/division
                    nodes=a+size*(local+1)/2
                    amp=legval((nodes-left)*stretch-1,amplitudes)
                    root=nodes+amp
                    W,dW,_=weight(nodes,centre,half)
                    denominator+=mesh.qw@W/division
                    actual=a+size*(gx+1)/2
                    gradient=legval((actual-left)*stretch-1,legder(amplitudes))*stretch
                    for k,target in enumerate((W,-dW)):
                        test=legfit(local,target/root,len(element)-1)
                        numerator[k]-=gw@(gradient*legval(gx,legder(test)))/(2*M**2)
            for idx,measure in enumerate(("potential_rate","velocity_rate")):
                out[width,division,measure]=numerator[idx]/denominator
    return out

def main():
    checked()
    target={(int(r["seed"]),float(r["width"]),r["observable"]):r for r in core.read(HERE/"mechanical-pressure-limit.csv") if r["q"]=="1024"}
    rows=[]
    zero=probe(0)
    for seed in (1,-1):
        for key,value in probe(seed).items():
            width,division,measure=key
            anchor=target[seed,width,measure]
            weak=float(anchor["native_weak"])
            lumped=float(anchor["native_lumped"])
            ans=value-zero[key]
            if division==1:
                assert abs(ans-lumped)<=1e-10*abs(weak),(key,ans,lumped)
            rows.append(dict(seed=seed,width=width,observable=measure,detector_subdivision=division,native_weak=weak,native_original=lumped,
                interpolated_test=ans,relative_to_weak=(ans-weak)/abs(weak),relative_to_original=(ans-lumped)/abs(weak)))
    table("native-window-interpolation.csv",rows)
    print([(n,max(abs(r["relative_to_weak"]) for r in rows if r["detector_subdivision"]==n)) for n in (1,2,4,8)])

if __name__=="__main__":
    main()
