import json
from itertools import product
from math import fsum,isclose
from pathlib import Path
import sys
from case import HERE,PRIOR,checked,core,guard,np,save
from new_clock import COUNTS as EXT,frozen
from readouts import COUNTS
from number_chart import NumberChart

def content(name):
    return core.read(HERE/name)

def run(seal=False):
    checked()
    frozen()
    expected={}
    for scheme in ("original","adm"):
        for seed in (1,-1):
            for flag in (0,1):
                for prefix,counts in (("",COUNTS),("number-",() if flag else COUNTS),("extended-",EXT)):
                    for count in counts:
                        name=f"{prefix}{scheme}-off{flag}-s{seed}-n{count}.npz"
                        with np.load(HERE/name) as bank:
                            assert np.array_equal(bank["r"],(np.arange(480)+.5)/160)
                            for field in ("common","signed"):
                                assert bank[field].shape==(20,2,480) and np.isfinite(bank[field]).all()
                            if seed==-1:
                                other=f"{prefix}{scheme}-off{flag}-s1-n{count}.npz"
                                with np.load(HERE/other) as plus:
                                    np.testing.assert_array_equal(bank["common"],plus["common"])
                            expected[name]=True
    assert len(expected)==104
    for scheme,seed,count in product(("original","adm"),(1,-1),(410,820)):
        name=f"canonical-{scheme}-s{seed}-n{count}.npz"
        with np.load(HERE/name) as bank:
            assert all(bank[k].shape==(20,2,480) and np.isfinite(bank[k]).all() for k in ("common","signed"))
            assert all(bank[k].shape==(2,480) and np.isfinite(bank[k]).all() for k in ("common_number","signed_number"))
        expected[name]=True
    for pref in ("","number-"):
        scores=content(pref+"matched-tide-scores.csv")
        assert len(scores)==80
        for row in scores:
            err=(float(row["trial"])-float(row["reference"]))/float(row["newton"])*1e6
            assert isclose(err,float(row["error_ppm"]),rel_tol=3e-15)
            assert (abs(err)<=20)==(row["within_tide_gate"]=="True")
        for row in content(pref+"signed-field-scores.csv"):
            scale=float(row["ref_rms"])
            if scale:
                assert isclose(float(row["relative"]),float(row["error_rms"])/scale,rel_tol=3e-15)
    gate=content("extended-tide-gates.csv")
    assert len(gate)==64 and len({tuple(r[k] for k in ("scheme","seed","count","width","channel")) for r in gate})==64
    for r in gate:
        assert (r["joint_tidal_screen"]=="True")== (max(abs(float(r[k])) for k in ("clock_ppm","formulation_ppm","readout_ppm"))<=20)
    for scheme in ("original","adm"):
        scores=content(f"forecast-scores-{scheme}.csv")
        assert len(scores)==32 and len({tuple(row[k] for k in ("seed","turns","model","observable")) for row in scores})==32
        for row in scores:
            assert isclose(float(row["relative_error"]),float(row["error_rms"])/float(row["actual_rms"]),rel_tol=2e-15)
            assert (row["below_one_percent"]=="True")==(float(row["relative_error"])<.01)
            win=0 if row["turns"]=="8.25" else 1
            with np.load(HERE/f"frozen-current-{scheme}-s{row['seed']}.npz") as forecast,np.load(HERE/f"actual-w{win}-{scheme}-s{row['seed']}-{row['observable']}.npz") as truth:
                delta=forecast[f"window{win}_{row['observable']}_{row['model']}"]-truth["radial"]
                assert isclose(np.linalg.norm(delta)/np.linalg.norm(truth["radial"]),float(row["relative_error"]),rel_tol=3e-15)
        for row in content(f"canonical-tests-{scheme}.csv"):
            seed,obs,count=row["seed"],row["observable"],row["count"]
            with np.load(HERE/f"frozen-current-{scheme}-s{seed}.npz") as forecast,np.load(HERE/f"canonical-readout-{scheme}-s{seed}-n{count}-{obs}.npz") as truth:
                value=lambda k:forecast[f"window1_{obs}_{k}"]
                diff=value("changing")+value("canonical_launch")-value("launch")-truth["radial"]
                assert isclose(np.linalg.norm(diff)/np.linalg.norm(truth["radial"]),float(row["canonical_forecast_relative"]),rel_tol=3e-15)
        for row in content(f"paired-resolution-{scheme}.csv"):
            assert isclose(float(row["relative"]),float(row["error_rms"])/float(row["truth_rms"]),rel_tol=2e-15)
    for key,count in (("rhs-controls.csv",1440),("algebra-checks.csv",15),("number-chart-rhs-controls.csv",36),("phase-forecast-controls.csv",13),
                      ("current-spatial-fixture.csv",4),("monopole-current-sources.csv",80),("prepared-state-current-split.csv",48),
                      ("physical-phase-drivers.csv",112),("mechanical-pressure-limit.csv",24),("native-window-interpolation.csv",32),
                      ("physics-ablation.csv",80),("canonical-gradient-controls.csv",12),("finite-geometry-coefficient.csv",32)):
        assert len(content(key))==count,(key,len(content(key)))
    for row in content("rhs-controls.csv"):
        assert float(row["absolute_error"])<=float(row["absolute_bound"])
    for row in content("physics-ablation.csv"):
        assert (row["below_one_percent"]=="True")==(float(row["error_fraction"])<.01)
    guard()
    pair=NumberChart(1,"original")
    state=np.zeros_like(pair.shell.initial)
    time=25.625*np.pi/pair.shell.mu
    step=time/3
    advance=pair.time_step(step)
    for tick in range(3):
        state=advance(tick*time/3,state)
    with np.load(HERE/"extended-original-off0-s1-n3.npz") as archived:
        physical=pair.to_wave(state)
        for name,field in (("common",physical.base),("signed",physical.delta),("signed_number",state.delta[14].real)):
            np.testing.assert_array_equal(archived[name],field)
    files={file.name:core.sha(file) for file in sorted(HERE.iterdir()) if file.is_file() and file.name!="seal.json"}
    assert not any(name.endswith(".partial") for name in files)
    csv_rows=sum(len(content(name)) for name in files if name.endswith(".csv"))
    record=dict(q=1024,prior=core.sha(PRIOR/"seal.json"),freeze=core.sha(HERE/"current-freeze.json"),files=files,trajectories=len(expected),csv_rows=csv_rows)
    if seal:
        save("seal.json",(json.dumps(record,indent=2)+"\n").encode())
    assert json.loads((HERE/"seal.json").read_bytes())==record
    print("verified",core.sha(HERE/"seal.json"),len(files),"files",csv_rows,"rows",len(expected),"paired trajectories")

if __name__=="__main__":
    run(sys.argv[1:]==["seal"])
