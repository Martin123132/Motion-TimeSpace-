import json
import sys
from case import HERE,checked,core,guard,np,packet
from coupled import Evolution
from number_chart import NumberChart

COUNTS=(3,205,410,820)
def frozen():
    pin=HERE/"current-freeze.json"
    assert core.sha(pin)=="66845197e73d507ebb08348f92d75c142955428ebce191537de8af62b1acb4ad"
    for name,digest in json.loads(pin.read_bytes())["files"].items():
        assert core.sha(HERE/name)==digest,name

def run(scheme):
    checked()
    frozen()
    for flag in (0,1):
        for seed in (1,-1):
            evo=Evolution(1,seed,scheme) if flag else NumberChart(seed,scheme)
            time=25.625*np.pi/evo.shell.mu
            for count in COUNTS:
                advance=evo.time_step(time/count)
                stored=np.zeros_like(evo.shell.initial)
                for idx in range(count):
                    if not idx%8:
                        guard()
                    stored=advance(idx*time/count,stored)
                actual=stored if flag else evo.to_wave(stored)
                if not flag:
                    assert evo.min_number>0 and evo.min_factor>0
                assert np.isfinite(actual.base).all() and np.isfinite(actual.delta).all()
                idx=12 if flag else 14
                packet(f"extended-{scheme}-off{flag}-s{seed}-n{count}.npz",r=evo.shell.r,time=time,common=actual.base,signed=actual.delta,
                    common_number=stored.base[idx].real,signed_number=stored.delta[idx].real)
                print("new clock",scheme,flag,seed,count,flush=True)

if __name__=="__main__":
    run(sys.argv[1])
