import json
from decimal import getcontext
import mpmath as mp
from case import HERE,Difference,checked,core,guard,np,parent,packet,save,table
from coupled import Evolution
from number_chart import NumberChart
from readouts import joined,rms
from source_terms import D,RadialOperators
from endpoints import convert

TURNS=(8.25,25.625)
MODELS=("launch","phase","changing","canonical_launch")

def exponents(time,mu):
    def decimal(value):
        from decimal import Decimal
        return Decimal(mp.nstr(value,52))
    with mp.workdps(60):
        dt=mp.mpf(float(time))
        arg=2j*mp.mpf(float(mu))
        comp=arg*dt
        first=mp.expm1(comp)-comp
        second=first-comp**2/2
        now=first/arg**2
        integral=second/arg**3
        return [(decimal(z.real),decimal(z.imag)) for z in (now,integral)]

def wave(op,ell,bend,amp,pot,dell,dbend,du,dp):
    fp=op.face(pot,True)
    gu=op.cell(op.face(amp,True),False)
    gp=op.cell(fp,False)
    metric=np.exp(op.face(2*bend-ell))
    base=op.strong(ell,bend,amp,pot)
    kinetic=op.cell(op.face_square*metric*(op.face(dp,True)+op.face(2*dbend-dell)*fp))/op.radius**2
    skew=(2*dbend-dell)*gu*gp+op.cell(op.face(du,True),False)*gp+gu*op.cell(op.face(dp,True),False)
    return base,2*du*base-np.exp(2*amp)*(kinetic+2*np.exp(2*bend-ell)*skew)

def cold(op,number,ell,pot,dn,dell,dp):
    pop=op.face(number)
    norm=np.exp(-op.face(ell))
    speed=norm*op.face(pot,True)
    gamma=np.sqrt(1+speed**2)
    de=-op.face(dell)
    var=(op.face(dn)+pop*de)*norm*speed/gamma+pop*norm*(speed*de+norm*op.face(dp,True))/gamma**3
    return op.flux(number,ell,pot),-op.cell(op.face_square*var)/op.radius**2

def predict(scheme,seed):
    raw={}
    checks=[]
    for flag in (0,1):
        evo=Evolution(1,seed,scheme) if flag else NumberChart(seed,scheme)
        base=evo.shell.initial
        change=np.zeros_like(base)
        rates=evo.rhs(0.,change) if flag else evo.nonlinear(0.,change)
        mu=D(evo.shell.mu)
        op=RadialOperators(evo.shell.r,evo.shell.dx)
        rho=D(float(evo.shell.rho[-1]))
        use=(evo.shell.r>.6)&(evo.shell.r<2.1)
        for host in (0,seed):
            def part(field):
                return joined(field) if host else convert(field.base)
            def at(s,i,imag=False):
                return part(s[i,0].imag if imag else s[i,0].real)
            ell,bend=at(base,0),at(base,1)
            dt_ell,dt_bend=at(rates,0),at(rates,1)
            number=at(base,12)
            canonical=at(base,13)
            for turns in TURNS:
                duration=turns*np.pi/evo.shell.mu
                t=D(duration)
                ex=exponents(duration,evo.shell.mu)
                for view,lead,(er,ei) in zip(("rate","charge"),(t,t*t/2),ex,strict=True):
                    initial_multiplier=1 if view=="rate" else t
                    identity=0*ell
                    if flag:
                        phase=lead*at(rates,13)
                        initial,only=cold(op,number,ell,canonical,identity,identity,phase)
                        _,moving=cold(op,number,ell,canonical,lead*at(rates,12),lead*dt_ell,phase)
                        canon=initial
                    else:
                        amp=at(base,14)
                        pot=at(base,14,True)/mu
                        rd,idot=at(rates,15),at(rates,15,True)
                        phase=lead*at(base,15,True)+rd*ei+idot*er
                        du=lead*(at(base,4)/2+mu*at(base,15))+mu*(rd*er-idot*ei)
                        initial,only=wave(op,ell,bend,amp,pot,identity,identity,identity,phase)
                        _,moving=wave(op,ell,bend,amp,pot,lead*dt_ell,lead*dt_bend,du,phase)
                        canon=op.strong(ell,bend,amp,canonical)
                    for label,value in zip(MODELS,(initial_multiplier*initial,initial_multiplier*initial+only,initial_multiplier*initial+moving,initial_multiplier*canon),strict=True):
                        raw[turns,view,label,flag,host]=rho*value[use]
                if flag==0 and turns==TURNS[0]:
                    cold_shell=parent.system(1,host,scheme)
                    canonical_difference=canonical-convert(cold_shell.initial[13,0].real)
                    phase_difference=pot-canonical
                    checks.append(dict(scheme=scheme,seed=seed,member=host,
                        canonical_wave_minus_cold_max=max(abs(canonical_difference.astype(float))),
                        rounded_phase_minus_canonical_max=max(abs(phase_difference.astype(float))),
                        rounded_phase_gradient_max=max(abs(op.face(phase_difference,True).astype(float)))))
    output={}
    for ti,turns in enumerate(TURNS):
        for view in ("rate","charge"):
            for label in MODELS:
                value=lambda f,s:raw[turns,view,label,f,s]
                out=(value(0,seed)-value(0,0))-(value(1,seed)-value(1,0))
                output[f"window{ti}_{view}_{label}"]=out.astype(float)
    packet(f"frozen-current-{scheme}-s{seed}.npz",**output)
    return checks

def main():
    checked()
    getcontext().prec=46
    rows=[]
    for scheme in ("original","adm"):
        for seed in (1,-1):
            guard()
            rows.extend(predict(scheme,seed))
    table("phase-ownership.csv",rows)
    paths=("PHASE-TEST.md","phase_prediction.py","source_terms.py","coupled.py","number_chart.py",*(f"frozen-current-{s}-s{n}.npz" for s in ("original","adm") for n in (1,-1)))
    save("current-freeze.json",(json.dumps(dict(turns=TURNS,files={n:core.sha(HERE/n) for n in paths}),indent=2)+"\n").encode())
    print("frozen",core.sha(HERE/"current-freeze.json"))

if __name__=="__main__":
    main()
