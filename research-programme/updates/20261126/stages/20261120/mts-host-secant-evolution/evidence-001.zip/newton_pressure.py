from decimal import getcontext
from unittest.mock import patch
from numpy.polynomial.legendre import legfit,legval,legder,leggauss
from case import HERE,checked,core,np,parent,guard,table
from source_terms import D,RadialOperators
from endpoints import convert

def weight(r,centre,half):
    x=(r-centre)/half
    basis=np.maximum(1-x*x,0)
    wr=basis**6
    dw=-12*x*basis**5/half
    dd=(-12*basis**5+120*x*x*basis**4)/half**2
    return wr,dw,dd

def curved(level,rate,seed):
    if level==1024:
        with patch.object(parent.evolve_speed,"launch",parent.launch):
            shell=parent.evolve_speed.system(level,rate,0,seed,"original",3)[0]
    else:
        shell=parent.evolve_speed.system(level,rate,0,seed,"original",3)[0]
    op=RadialOperators(shell.r,shell.dx)
    ell,bend,u=(convert(shell.initial[idx,0].real) for idx in (0,1,14))
    nu=convert(shell.initial[12,0].real)
    uflat=np.frompyfunc(lambda value:value.ln(),1,1)(nu)/2
    def law(amp,ell,bend):
        lap=np.exp(-ell-2*bend)*op.cell(op.face_square*np.exp(op.face(2*bend-ell))*op.face(amp,True))/op.radius**2
        grad=np.exp(-ell)*op.cell(op.face(amp,True),False)
        return level*(lap+grad**2)/(2*D(float(shell.mu))**2)
    physical=law(u,ell,bend).astype(float)
    limit=law(uflat,0*ell,0*bend).astype(float)
    out={}
    for width in (.15,.30):
        W,dW,_=weight(shell.r,core.ep.CENTER,core.ep.CENTER*width)
        for kind,kernel in (("potential_rate",W),("velocity_rate",-dW)):
            out[width,kind]=np.array([kernel@f/W.sum() for f in (physical,limit)])
    return out

def native(seed):
    sim=parent.prior.sphere(144,5)
    state=parent.prior.start_state(sim,144,5,seed)
    p=sim.patch
    mesh=sim.mesh
    ref=core.family.pressure(0)[0]
    M=ref["a"]*p.p.mass
    hub=ref["H"]
    go=lambda wave:mesh.monopole(state[0],p.p.coeff,p.j,p.p.mass,hub,ref["a"],wave)
    on,n,_=go(True)
    off=go(False)[0]
    r=mesh.r[1:]
    number=n[p.j,1:]
    root=np.sqrt(number)
    A=state[0][0,p.j]/(1+root)
    stiffness=-mesh.stiff0@A/(2*M**2*mesh.lump*r*root)
    toggled=hub*(on[1,p.j]-off[1,p.j])/r
    allA=mesh.grid(A)
    control={}
    for width in (.15,.30):
        centre=core.ep.CENTER
        half=centre*width
        W,dW,_=weight(r,centre,half)
        assert np.sum(mesh.lump*W)>0
        quad={}
        for order in (20,40):
            gx,gw=leggauss(order)
            vals=np.zeros(3)
            for cell in mesh.elem:
                nodes=mesh.r[cell]
                a,b=nodes[0],nodes[-1]
                left,right=max(a,centre-half),min(b,centre+half)
                if left>=right:
                    continue
                scale=2/(b-a)
                locations=(gx+1)*(right-left)/2+left
                weights=gw*(right-left)/2
                coeff=legfit((nodes-a)*scale-1,allA[cell],len(nodes)-1)
                pos=(locations-a)*scale-1
                amp=legval(pos,coeff)
                slope=legval(pos,legder(coeff))*scale
                normal=locations+amp
                wr,dr,dd=weight(locations,centre,half)
                vals[0]+=weights@wr
                for idx,window,gradient in ((1,wr,dr),(2,-dr,-dd)):
                    vals[idx]-=weights@(slope*(gradient/normal-window*(1+slope)/normal**2))/(2*M**2)
            quad[order]=vals[1:]/vals[0]
        for idx,(kind,kernel) in enumerate((("potential_rate",W),("velocity_rate",-dW))):
            project=lambda field:(mesh.lump*kernel)@field/(mesh.lump@W)
            control[width,kind]=np.array([quad[40][idx],quad[20][idx],project(stiffness),project(toggled)])
    return control

def main():
    getcontext().prec=46
    checked()
    rows=[]
    archives={seed:native(seed) for seed in (0,1,-1)}
    for level in (64,128,1024):
        guard()
        states={(rate,seed):curved(level,rate,seed) for rate in (160,320) for seed in (0,1,-1)}
        for seed in (1,-1):
            for key,raw in archives[seed].items():
                ref,low,lumped,toggle=raw-archives[0][key]
                physical,flat=states[320,seed][key]-states[320,0][key]
                coarse,flat_low=states[160,seed][key]-states[160,0][key]
                assert ref and abs(low-ref)<3e-11*abs(ref)
                rows.append(dict(q=level,seed=seed,width=key[0],observable=key[1],q_scaled_slow_amplitude=physical,flat_log_limit=flat,
                        native_weak=ref,native_quadrature_relative=abs(low-ref)/abs(ref),native_lumped=lumped,native_wave_switch=toggle,
                        native_switch_minus_stiffness_relative=(toggle-lumped)/abs(ref),relative_to_weak=(physical-ref)/abs(ref),
                        curved_minus_flat_relative=(physical-flat)/abs(ref),flat_minus_native_relative=(flat-ref)/abs(ref),
                        grid_shift_relative=(physical-coarse)/abs(ref),native_lumped_minus_weak_relative=(lumped-ref)/abs(ref)))
    table("mechanical-pressure-limit.csv",rows)
    print([(q,max(abs(r["relative_to_weak"]) for r in rows if r["q"]==q),max(abs(r["curved_minus_flat_relative"]) for r in rows if r["q"]==q)) for q in (64,128,1024)])

if __name__=="__main__":
    main()
