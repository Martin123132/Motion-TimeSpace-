from contextlib import ExitStack
from decimal import getcontext
from math import fsum
from unittest.mock import patch
from case import HERE,PRIOR,Difference,checked,core,guard,np,packet,parent,table
import signed_energy
import constraint_floor
import ref_endpoint
from endpoints import convert,pack,prod,exponential
from phase_stride import readings

COUNTS=(1,4,33,66,132,264)

def joined(field):
    if isinstance(field,Difference):
        return convert(field.base)+convert(field.delta)
    return convert(field)

def fields(shell,shift):
    with ExitStack() as stack:
        for module in (signed_energy,constraint_floor,ref_endpoint):
            stack.enter_context(patch.object(module,"convert",joined))
        heavy,total=signed_energy.density(shell,shift)
        residual=constraint_floor.components(shell,shift)
        def coordinate(index,imag=False):
            part=lambda item:item.imag if imag else item.real
            return joined(part(shell.initial[index]))+joined(part(shift[index]))
        ell,bend=coordinate(0),coordinate(1)
        rho=convert(shell.rho[-1]).item() if isinstance(shell.rho[-1],np.ndarray) else convert(shell.rho[-1])
        if shell.flag:
            charge=coordinate(12)
        else:
            unit=pack(0*ell[0]+1)
            charge=prod(exponential(ell+2*bend+2*coordinate(14)),unit-coordinate(15,True))
        inverse_volume=exponential(-ell-2*bend)
        heavy_rest=rho*prod(charge,inverse_volume)
        return dict(heavy=heavy,total=total,rest=heavy_rest,nonrest=heavy-heavy_rest,other=total-heavy,
                    charge=rho*charge,inverse_volume=inverse_volume,**residual)

def incremental(shell,shift,launch):
    state=fields(shell,shift)
    result={k:v-launch[k] for k,v in state.items() if k!="inverse_volume"}
    result["charge_change_term"]=prod(result["charge"],state["inverse_volume"])
    result["volume_change_term"]=prod(launch["charge"],state["inverse_volume"]-launch["inverse_volume"])
    err=(result["rest"]-result["charge_change_term"]-result["volume_change_term"]).astype(float)
    assert np.max(abs(err))<1e-47
    return result

def member_readings(shell,full_time,shift):
    if isinstance(shift,Difference):
        summed=shift.base+shift.delta
        def projected(shell,start,delta):
            return ref_endpoint.fixed_tide(shell,start,shift if delta is not None else None)
        with patch.object(ref_endpoint,"convert",joined),patch.object(core.ep,"fixed_tide",projected):
            return {(width,ch):1024*v for width,ch,v in core.central.measure(shell,full_time,summed) if ch in ("gauss","ricci")}
    return {k:1024*v for k,v in readings(shell,shift,full_time).items()}

def with_number(shell,shift,change,raw):
    def at(index):
        return joined(shell.initial[index].real)+joined(shift[index].real)
    inverse_volume=exponential(-at(0)-2*at(1))
    new_charge=convert(shell.rho[-1])*joined(change)
    new_term=prod(new_charge,inverse_volume)
    rest=new_term+raw["volume_change_term"]
    raw["amplitude_total"]=raw["total"]
    raw["amplitude_charge"]=raw["charge"]
    raw["charge"],raw["charge_change_term"],raw["rest"]=new_charge,new_term,rest
    raw["heavy"]=rest+raw["nonrest"]
    raw["total"]=raw["heavy"]+raw["other"]
    return raw

def measure_scheme(scheme,number=False):
    checked()
    getcontext().prec=46
    rows=[]
    prefix="number-" if number else ""
    for flag in ((0,) if number else (0,1)):
        zero=parent.system(flag,0,scheme)
        zlaunch=fields(zero,np.zeros_like(zero.initial))
        common_cache={}
        for seed in (1,-1):
            host=parent.system(flag,seed,scheme)
            hlaunch=fields(host,np.zeros_like(host.initial))
            use=(host.r>.6)&(host.r<2.1)
            archive={}
            for count in COUNTS:
                guard()
                with np.load(HERE/f"{prefix}{scheme}-off{flag}-s{seed}-n{count}.npz") as bank:
                    common,offset=bank["common"],bank["signed"]
                    if number:
                        common_n,delta_n=bank["common_number"],bank["signed_number"]
                        assert bank["min_relative_number"]>0 and bank["min_relative_factor"]>0
                    time=float(bank["time"])
                    assert np.array_equal(bank["r"],host.r) and common.shape==offset.shape==(20,2,480)
                if count not in common_cache:
                    increments=incremental(zero,common,zlaunch)
                    if number:
                        increments=with_number(zero,common,common_n,increments)
                    tides=member_readings(zero,time,common)
                    common_cache[count]=common,increments,tides
                saved,zero_fields,zero_tides=common_cache[count]
                np.testing.assert_array_equal(saved,common)
                shift=Difference(common,offset)
                hi=incremental(host,shift,hlaunch)
                if number:
                    hi=with_number(host,shift,Difference(common_n,delta_n),hi)
                for key in zero_fields:
                    contrast=(hi[key]-zero_fields[key])[:,use]
                    high=contrast.astype(float)
                    archive.setdefault(key,[]).append(high)
                    archive.setdefault(key+"_tail",[]).append((contrast-convert(high)).astype(float))
                for (width,ch),value in member_readings(host,time,shift).items():
                    rows.append(dict(scheme=scheme,flag=flag,seed=seed,count=count,width=width,channel=ch,host=value,zero=zero_tides[width,ch],contrast=value-zero_tides[width,ch]))
            packet(f"{prefix}profiles-{scheme}-off{flag}-s{seed}.npz",r=host.r[use],counts=COUNTS,**archive)
    table(f"{prefix}tides-{scheme}.csv",rows)
    print("read",prefix,scheme)

def rms(field):
    return np.linalg.norm(field)/np.sqrt(field.size)

def assess(number=False):
    prefix="number-" if number else ""
    old_tides=core.read(PRIOR/"matched-clock-tides.csv")
    norms={(int(row["seed"]),float(row["width"])):abs(float(row["early_newton"])) for row in old_tides}
    tide_scores=[]
    scores=[]
    projections=[]
    residual_keys=("ham","mom_r","mom_theta")
    for scheme in ("original","adm"):
        raw=core.read(HERE/f"tides-{scheme}.csv")
        if number:
            raw=[r for r in raw if int(r["flag"])==1]+core.read(HERE/f"number-tides-{scheme}.csv")
        group={(int(row["flag"]),int(row["seed"]),int(row["count"]),float(row["width"]),row["channel"]):float(row["contrast"]) for row in raw}
        for seed in (1,-1):
            for width in (.15,.30):
                for channel in ("gauss","ricci"):
                    def tide(count):
                        return group[0,seed,count,width,channel]-group[1,seed,count,width,channel]
                    for count in COUNTS[:-1]:
                        diff=tide(count)-tide(264)
                        old=next(row for row in old_tides if row["scheme"]==scheme and int(row["seed"])==seed and float(row["width"])==width and row["channel"]==channel and int(row["steps"])==1)
                        error=1e6*diff/norms[seed,width]
                        compare_old=1e6*(tide(132)-float(old["reference"]))/norms[seed,width]
                        tide_scores.append(dict(scheme=scheme,seed=seed,width=width,channel=channel,steps=count,reference=tide(264),trial=tide(count),
                            newton=norms[seed,width],error_ppm=error,secant_132_minus_old_132_ppm=compare_old,within_tide_gate=abs(error)<=20))
            with np.load(HERE/f"{prefix}profiles-{scheme}-off0-s{seed}.npz") as w,np.load(HERE/f"profiles-{scheme}-off1-s{seed}.npz") as c:
                assert np.array_equal(w["r"],c["r"])
                signals={k:(w[k]-c[k])+(w[k+"_tail"]-c[k+"_tail"]) for k in c if k not in ("counts","r") and not k.endswith("_tail")}
                for idx,count in enumerate(COUNTS[:-1]):
                    for name,series in signals.items():
                        for ell in ((1,) if name=="mom_theta" else (0,1)):
                            ref=series[-1,ell]
                            error=rms(series[idx,ell]-ref)
                            scale=rms(ref)
                            scores.append(dict(scheme=scheme,seed=seed,steps=count,quantity=name,ell=2*ell,error_rms=error,ref_rms=scale,relative=error/scale if scale else ""))
                    for harmonic in (0,1):
                        err=lambda name:signals[name][idx,harmonic]-signals[name][-1,harmonic]
                        total=err("total")
                        norm=total@total
                        components=[err(name) for name in ("charge_change_term","volume_change_term","nonrest","other")]
                        close=rms(total-sum(components))
                        projections.append(dict(scheme=scheme,seed=seed,steps=count,ell=2*harmonic,total_rms=rms(total),closure_rms=close,**{name:field@total/norm if norm else 0 for name,field in zip(("charge","volume","nonrest","other"),components,strict=True)}))
    table(prefix+"matched-tide-scores.csv",tide_scores)
    table(prefix+"signed-field-scores.csv",scores)
    table(prefix+"energy-error-decomposition.csv",projections)
    print("max tide error",max(abs(r["error_ppm"]) for r in tide_scores))
    for n in COUNTS[:-1]:
        print(n,[(ell,max(r["relative"] for r in scores if r["steps"]==n and r["quantity"]=="total" and r["ell"]==ell)) for ell in (0,2)])

if __name__=="__main__":
    import sys
    if sys.argv[1]=="assess":
        assess("number" in sys.argv)
    else:
        measure_scheme(sys.argv[1],"number" in sys.argv)
