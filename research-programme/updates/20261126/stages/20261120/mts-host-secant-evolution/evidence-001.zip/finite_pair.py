import numpy as np

class Difference:
    __array_priority__=10000

    def __init__(self,base,delta):
        self.base=base
        self.delta=delta

    def __getitem__(self,key):
        return Difference(self.base[key],self.delta[key])

    def __setitem__(self,key,value):
        self.base[key]=base(value)
        self.delta[key]=offset(value)

    def __len__(self):
        return len(self.base)

    @property
    def real(self):
        return Difference(self.base.real,self.delta.real)

    @property
    def imag(self):
        return Difference(self.base.imag,self.delta.imag)

    @property
    def shape(self):
        return self.base.shape

    def copy(self):
        return Difference(self.base.copy(),self.delta.copy())

    def conj(self):
        return Difference(self.base.conj(),self.delta.conj())

    def __neg__(self):
        return Difference(-self.base,-self.delta)

    def __add__(self,other):
        return Difference(self.base+base(other), self.delta+shaped_offset(other))

    __radd__=__add__

    def __sub__(self,other):
        return Difference(self.base-base(other), self.delta-offset(other))

    def __rsub__(self,other):
        return Difference(other-self.base,-self.delta)

    def __mul__(self,other):
        if isinstance(other,Difference):
            return Difference(self.base*other.base,self.delta*other.base+(self.base+self.delta)*other.delta)
        return Difference(self.base*other,self.delta*other)

    __rmul__=__mul__

    def __truediv__(self,other):
        if isinstance(other,Difference):
            quotient=self.base/other.base
            return Difference(quotient,(self.delta-quotient*other.delta)/(other.base+other.delta))
        return Difference(self.base/other,self.delta/other)

    def __rtruediv__(self,other):
        quotient=other/self.base
        return Difference(quotient,-quotient*self.delta/(self.base+self.delta))

    def __pow__(self,exponent):
        if exponent==2:
            return Difference(self.base**2,self.delta*(2*self.base+self.delta))
        raise ValueError(exponent)

    def __array_ufunc__(self,ufunc,method,*args,**kwargs):
        if kwargs or method!="__call__":
            raise ValueError((ufunc,method,kwargs))
        if ufunc in (np.add,np.subtract,np.multiply,np.divide):
            names={np.add:("__add__","__radd__"),np.subtract:("__sub__","__rsub__"),np.multiply:("__mul__","__rmul__"),np.divide:("__truediv__","__rtruediv__")}[ufunc]
            if isinstance(args[0],Difference):
                return getattr(args[0],names[0])(args[1])
            return getattr(args[1],names[1])(args[0])
        if ufunc in (np.exp,np.expm1):
            common=np.exp(self.base)
            return Difference(ufunc(self.base),common*np.expm1(self.delta))
        if ufunc==np.sqrt:
            common=np.sqrt(self.base)
            return Difference(common,self.delta/(common+np.sqrt(self.base+self.delta)))
        if ufunc==np.log1p:
            return Difference(np.log1p(self.base),np.log1p(self.delta/(1+self.base)))
        if ufunc==np.matmul and not isinstance(args[0],Difference):
            return Difference(args[0]@self.base,args[0]@self.delta)
        if ufunc==np.conjugate:
            return self.conj()
        if ufunc==np.negative:
            return -self
        raise NotImplementedError(ufunc)

    def __array_function__(self,fn,types,args,kwargs):
        if fn in (np.zeros_like,np.ones_like):
            return Difference(fn(self.base,**kwargs),np.zeros_like(self.delta,**kwargs))
        if fn in (np.stack,np.concatenate):
            values=args[0]
            return Difference(fn([base(v) for v in values],*args[1:],**kwargs),fn([shaped_offset(v) for v in values],*args[1:],**kwargs))
        if fn is np.broadcast_arrays:
            return [Difference(a,b) for a,b in zip(fn(*map(base,args),**kwargs),fn(*map(shaped_offset,args),**kwargs),strict=True)]
        if fn is np.array_equal:
            return np.array_equal(base(args[0]),base(args[1])) and np.array_equal(shaped_offset(args[0]),shaped_offset(args[1]))
        if fn in (np.real,np.imag):
            return self.real if fn is np.real else self.imag
        raise NotImplementedError(fn)

def base(value):
    return value.base if isinstance(value,Difference) else value

def offset(value):
    return value.delta if isinstance(value,Difference) else 0

def shaped_offset(value):
    return value.delta if isinstance(value,Difference) else np.zeros_like(value)

class ArrayConstruction:
    def __getattr__(self,name):
        return getattr(np,name)

    def array(self,sequence,*args,**kwargs):
        if any(isinstance(item,Difference) for item in sequence):
            return Difference(np.array([base(item) for item in sequence],*args,**kwargs),np.array([shaped_offset(item) for item in sequence],*args,**kwargs))
        return np.array(sequence,*args,**kwargs)
