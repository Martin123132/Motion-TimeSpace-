import mpmath as mp
from case import checked,core,np,parent,table
from new_clock import frozen
from phase_prediction import TURNS,exponents,cold,wave
from source_terms import RadialOperators
from readouts import rms

def main():
    checked()
    frozen()
    rows=[]
    grids=48
    r=(np.arange(144)+.5)/grids
    op=RadialOperators(r,1/grids,False)
    shape=np.exp(-r*r)
    origin=[.2*shape,.14*shape**2,.3*shape**.5,.23*shape]
    direction=[.1*shape,.2*shape,-.09*shape**2,.14*shape]
    def test(kind,first,delta):
        if kind=="wave":
            direct=lambda vals:op.strong(*vals)
            actual,slope=wave(op,*first,*delta)
        else:
            direct=lambda vals:op.flux(*vals)
            actual,slope=cold(op,*first,*delta)
        np.testing.assert_allclose(direct(first),actual,rtol=0,atol=0)
        use=(r>.65)&(r<2.1)
        errors=[]
        for eps in (.02,.01,.005):
            upper=direct([a+eps*b for a,b in zip(first,delta,strict=True)])
            lower=direct([a-eps*b for a,b in zip(first,delta,strict=True)])
            err=rms(((upper-lower)/(2*eps)-slope)[use])/rms(slope[use])
            errors.append(err)
            rows.append(dict(fixture=kind,step=eps,error=err))
        assert errors[0]>3.8*errors[1] and errors[1]>3.8*errors[2]
    test("wave",origin,direction)
    test("dust",[1+origin[2],origin[0],origin[3]],[direction[2],direction[0],direction[3]])
    with mp.workdps(65):
        for turns in TURNS:
            mu=55062.210548790536
            t=turns*np.pi/mu
            rates=exponents(t,mu)
            arg=2j*mp.mpf(mu)
            points=[mp.mpf(t)*n/40 for n in range(41)]
            for index,num in enumerate(rates):
                actual=mp.mpc(mp.mpf(str(num[0])),mp.mpf(str(num[1])))
                integral=mp.quad(lambda u:(mp.mpf(t)-u)**index*mp.expm1(arg*u)/arg,points)
                rel=float(abs((actual-integral)/integral))
                assert rel<1e-47
                rows.append(dict(fixture="oscillator_"+str(index),step=turns,error=rel))
    for s in (0,1,-1):
        w=parent.system(0,s,"original")
        c=parent.system(1,s,"original")
        np.testing.assert_array_equal(w.initial[13,0],c.initial[13,0])
        np.testing.assert_array_equal(w.initial[14,0].imag,w.mu*w.initial[13,0].real)
        rows.append(dict(fixture="exact_launch_identity",step=s,error=0.))
    table("phase-forecast-controls.csv",rows)
    print(len(rows),"forecast and ownership controls")

if __name__=="__main__":
    main()
