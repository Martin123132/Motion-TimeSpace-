from decimal import getcontext
from case import HERE,Difference,checked,guard,np,parent,table
from readouts import joined,rms
from source_terms import D,RadialOperators

def primitives(shell,shift):
    def at(idx,imaginary=False):
        section=lambda v:v.imag if imaginary else v.real
        return joined(section(shell.initial[idx,0]))+joined(section(shift[idx,0]))
    ell=at(0)
    if shell.flag:
        return at(12),ell,at(13)
    return np.exp(ell+2*at(1)+2*at(14))*(1-at(15,True)),ell,at(14,True)/D(float(shell.mu))

def flux_parts(op,cloud,cold):
    def face(state):
        number,ell,pot=state
        light=np.exp(-op.face(ell))
        number=op.face(number)
        derivative=op.face(pot,True)
        u=light*derivative
        gamma=np.sqrt(1+u**2)
        return number,light,derivative,u,gamma,u/gamma,number*light
    left,right=face(cloud),face(cold)
    number,light,derivative,u,gamma,velocity,area=[(a+b)/2 for a,b in zip(left,right,strict=True)]
    dv=(gamma-u*(left[3]+right[3])/(left[4]+right[4]))/(left[4]*right[4])
    def returned(faceflux):
        return -op.cell(op.face_square*faceflux)/op.radius**2
    terms=dict(number=returned(velocity*light*op.face(cloud[0]-cold[0])),
               metric=returned((velocity*number+area*dv*derivative)*(left[1]-right[1])),
               phase=returned(area*dv*light*op.face(cloud[2]-cold[2],True)))
    actual=op.flux(*cloud)-op.flux(*cold)
    return actual,terms

def main():
    checked()
    getcontext().prec=46
    rows=[]
    for scheme in ("original","adm"):
        for seed in (1,-1):
            shells={(f,s):parent.system(f,s,scheme) for f in (0,1) for s in (0,seed)}
            shell=shells[0,0]
            op=RadialOperators(shell.r,shell.dx)
            rho=D(float(shell.rho[-1]))
            use=(shell.r>.6)&(shell.r<2.1)
            for count in (0,1,132,264):
                guard()
                material={}
                for flag in (0,1):
                    if count:
                        prefix="" if flag else "number-"
                        with np.load(HERE/f"{prefix}{scheme}-off{flag}-s{seed}-n{count}.npz") as bank:
                            common=bank["common"]
                            diff=bank["signed"]
                    else:
                        common=np.zeros_like(shell.initial)
                        diff=np.zeros_like(common)
                    for current,shift in ((0,common),(seed,Difference(common,diff))):
                        material[flag,current]=primitives(shells[flag,current],shift)
                zer,background=flux_parts(op,material[0,0],material[1,0])
                end,host=flux_parts(op,material[0,seed],material[1,seed])
                target=(rho*(end-zer)[use]).astype(float)
                net={k:(rho*(host[k]-background[k])[use]).astype(float) for k in host}
                scale=rms(target)
                closing=rms(sum(net.values())-target)
                assert closing<2e-14*max(scale,*map(rms,net.values()))
                for key,value in net.items():
                    rows.append(dict(scheme=scheme,seed=seed,steps=count,source=key,total_state_rms=scale,component_rms=rms(value),
                                   ratio=rms(value)/scale,projection=value@target/(target@target),closure_rms=closing))
    table("prepared-state-current-split.csv",rows)
    print([(key,min(row["projection"] for row in rows if row["source"]==key),max(row["projection"] for row in rows if row["source"]==key)) for key in ("number","metric","phase")])

if __name__=="__main__":
    main()
