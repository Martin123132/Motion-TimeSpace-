from paired_readout import read,table,ms,np

def main():
    out=[]
    for row in read('even-dark-requirement'):
        if row['component']!='polar':continue
        radius=float(row['R']);height=1.5;r=np.hypot(radius,height);mu=height/r
        factor=r*r/(radius*ms.UNIT)
        require=np.array([float(row[k]) for k in ('even_dark_low','even_dark_high')])
        actual=float(row['actual_dark'])
        grad=factor*require;equiv=grad/(3*mu)
        assert np.allclose(3*mu*equiv*(radius/r)/r*ms.UNIT,require,rtol=1e-14)
        out.append(dict(occupation=row['occupation'],history=row['history'],frame=row['frame'],R=radius,z=height,
                    mu=mu,angular_potential_slope_low_kms2=grad[0],angular_potential_slope_high_kms2=grad[1],actual_slope_kms2=actual*factor,
                    pure_quadrupole_equivalent_low_kms2=equiv[0],pure_quadrupole_equivalent_high_kms2=equiv[1],
                    spherical_allowed=row['zero_permitted']))
    table('angular-potential-requirement',out)

if __name__=='__main__':main()
