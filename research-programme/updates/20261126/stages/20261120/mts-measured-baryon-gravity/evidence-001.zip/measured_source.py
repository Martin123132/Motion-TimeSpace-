from pathlib import Path
import csv
import hashlib
import io
import json
import os
import sys

for key in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','BLIS_NUM_THREADS'):
    os.environ[key]='1'
HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
OBS=ROOT/'mts-mw-baryon-apertures-20261120'
sys.path.insert(0,str(OBS))
from source_models import np,old
from census_profile import GAS_PHASES
from scipy.special import erf
from scipy.integrate import cumulative_trapezoid

def digest(path):
    with path.open('rb') as src:return hashlib.file_digest(src,'sha256').hexdigest()

def guard():
    assert not any((folder/'STOP-REQUESTED').exists() for folder in (HERE,ROOT,OBS))
    assert digest(OBS/'seal.json')=='6a97d405f60bc068baa14a141a29e0367ca0204bae21bd04b46c8595c04802ac'
    parents=json.loads((OBS/'seal.json').read_bytes())['files']
    assert digest(OBS/'measured-inner-neutral.csv')==parents['measured-inner-neutral.csv']

def put(name,data):
    path=HERE/name
    if path.exists():
        assert path.read_bytes()==data,name
    else:
        with path.open('xb') as target:target.write(data)

def table(name,rows):
    buf=io.StringIO(newline='')
    writer=csv.DictWriter(buf,rows[0],lineterminator='\n');writer.writeheader();writer.writerows(rows)
    put(name+'.csv',buf.getvalue().encode())

class Source:
    def __init__(self):
        guard();self.stars=stars=old.LENS.stars
        self.radgas={item.name:item for item in old.gases()}
        with (OBS/'measured-inner-neutral.csv').open() as src:records=list(csv.DictReader(src))
        self.points={kind:np.array([(float(row['R_kpc']),1.4*float(row['surface_H'])) for row in records if row['phase']==kind]).T for kind in ('HI','H2')}
        self.hi=sum(phase[1] for phase in GAS_PHASES if phase[0].startswith('HI_'))
        self.tail=np.array([.5/np.log(np.interp(stars.H-.5,stars.axis,col)/col[-1]) for col in stars.fold.T])
        assert np.all(self.tail>0)
        self.cum=cumulative_trapezoid(stars.fold,stars.axis,initial=0,axis=0)
        self.area=self.cum[-1]+self.tail*stars.fold[-1]
        self.radknots=np.unique(np.r_[0.,stars.knots,stars.bgrid,*[np.r_[loc[0]-1,loc,8.3] for loc,_ in self.points.values()]])
    def reference_gas(self,name,radius):
        model=self.radgas[name]
        return (1. if name=='H2' else self.hi)*model.surface(radius)/model.surface(8.3)
    def gas_column(self,name,radius):
        radius=np.asarray(radius);loc,col=self.points[name];base=self.reference_gas(name,radius)
        left=np.clip(radius-loc[0]+1,0,1);right=np.clip((8.3-radius)/(8.3-loc[-1]),0,1)
        return np.where(radius<loc[0],base*(1+left*(col[0]/self.reference_gas(name,loc[0])-1)),
              np.where(radius>loc[-1],base*(1+right*(col[-1]/self.reference_gas(name,loc[-1])-1)),np.interp(radius,loc,col)))
    def starshape(self,altitude,j,column=False,cut=False):
        stars=self.stars;axis=stars.axis;values=stars.fold[:,j];z=np.abs(altitude)
        width=self.tail[j];excess=np.maximum(z-stars.H,0.);area=self.cum[-1,j] if cut else self.area[j]
        if not column:
            return np.interp(z,axis,values)*np.where(z<=stars.H,1.,0. if cut else np.exp(-excess/width))/(2*area)
        idx=np.clip(np.searchsorted(axis,z,side='right')-1,0,len(axis)-2)
        delta=np.minimum(z,stars.H)-axis[idx]
        integral=self.cum[idx,j]+delta*(values[idx]+.5*delta*np.diff(values)[idx]/np.diff(axis)[idx])
        return (integral+(0. if cut else width*values[-1]*(-np.expm1(-excess/width))))/area
    def disk(self,radius,altitude,column=False,cut=False):
        radius,altitude=np.asarray(radius),np.abs(altitude)
        stars=self.stars;out=0.
        for j in range(4):
            col=(np.interp(radius,stars.centres,stars.data[:,j])*np.exp(-np.maximum(radius-16.5,0)/2.1)*(radius<=30)*stars.factors[j]
                 -np.interp(radius,stars.bgrid,stars.bcentral[:,j],right=0.))
            out=out+col*self.starshape(altitude,j,column,cut)
            if j==0:bd=col*1.2/(stars.radial(8.3)[0]*1e-6)
        hi=self.gas_column('HI',radius)
        for name,local_col,height,kind in GAS_PHASES:
            col=(self.gas_column('H2',radius) if name=='H2' else (local_col/self.hi*hi if name.startswith('HI_') else
                 local_col/self.hi*self.reference_gas('HI',radius)))
            ratio=altitude/height
            if kind=='gaussian':profile=erf(ratio) if column else np.exp(-ratio**2)/(np.sqrt(np.pi)*height)
            else:profile=-np.expm1(-ratio) if column else np.exp(-ratio)/(2*height)
            out+=col*profile
        out+=bd*(-np.expm1(-altitude/.4) if column else np.exp(-altitude/.4)/.8)
        return out if column else out*1e6

if __name__=='__main__':
    source=Source()
    for name,(radii,cols) in source.points.items():
        assert max(abs(source.gas_column(name,radii)-cols))<1e-12
        assert np.isclose(source.gas_column(name,8.3),source.reference_gas(name,8.3))
    assert max(abs(source.starshape(1e3,j,True)-1.) for j in range(4))<1e-13
    files={name:digest(HERE/name) for name in ('PROTOCOL.md','measured_source.py')}
    put('source-freeze.json',(json.dumps(dict(files=files,parent=digest(OBS/'seal.json'),tail_heights_kpc=list(source.tail),tail_fractions=list(source.tail*source.stars.fold[-1]/source.area)),indent=2)+'\n').encode())
