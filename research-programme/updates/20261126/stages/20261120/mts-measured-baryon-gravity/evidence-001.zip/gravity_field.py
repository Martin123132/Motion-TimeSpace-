from measured_source import *
from numpy.polynomial.legendre import legvander
from scipy.special import roots_legendre,ellipk,ellipe
from scipy.interpolate import CubicHermiteSpline
from math import pi

def intervals(edges,order):
    nodes,weights=roots_legendre(order)
    half=np.diff(edges)/2
    return (edges[:-1,None]+half[:,None]*(1+nodes)).ravel(),(half[:,None]*weights).ravel()

class Central:
    def __init__(self,source):
        stars=source.stars
        edges=np.unique(np.r_[np.linspace(0,4,2001),stars.bgrid])
        radii,wt=intervals(edges,16);dm=4*pi*radii**2*wt*stars.bulge_density(radii)
        mass=np.r_[0,np.cumsum(dm.reshape(-1,16).sum(1))]
        shell=np.r_[np.cumsum((dm/radii).reshape(-1,16).sum(1)[::-1])[::-1],0.]
        assert abs(mass[-1]/stars.bmass-1)<2e-6
        self.mass=stars.bmass;ratio=self.mass/mass[-1];mass*=ratio;shell*=ratio
        den=np.maximum(edges,1e-25)
        self.phi=CubicHermiteSpline(edges,-old.G*(mass/den+shell),old.G*mass/den**2)
    def value(self,rad,der=0):
        den=np.maximum(rad,1e-25)
        return np.where(rad<4,self.phi(np.minimum(rad,4.),der),old.G*self.mass/den**(1+der)*(1 if der else -1))

class Gravity:
    def __init__(self,src,degree,q,dr):
        guard();self.source=src;self.central=Central(src);self.degree=degree
        self.orders=ords=np.arange(0,degree+1,2);self.norm=np.sqrt(2*ords+1)
        mu,wt=intervals(np.array([0.,1.]),q)
        sky=legvander(mu,degree)[:,::2]*self.norm
        edges=np.unique(np.r_[.001,np.arange(.01,32.,dr),np.geomspace(32,900,500),src.radknots[src.radknots>0]])
        density=np.empty((len(edges),len(ords)))
        for start in range(0,len(edges),24):
            rr=edges[start:start+24,None]
            rho=src.disk(rr*np.sqrt(1-mu**2),rr*mu)
            density[start:start+24]=4*pi*old.G*((rho*wt)@sky)
        self.bank=old.Multipoles(edges,density,ords,0,910.,dr)
    def sky(self,r,mu,cut=None):
        assert min(r)>0 and max(r)<910
        degrees=self.orders if cut is None else self.orders[self.orders<=cut]
        harm=legvander(mu,int(degrees[-1]))[:,::2]*self.norm[:len(degrees)]
        return self.bank.gravity(r)[:,:len(degrees)]@harm.T+self.central.value(r)[:,None]
    def field(self,r,z):
        r,z=np.broadcast_arrays(r,np.atleast_1d(z));rad=np.hypot(r,z);mu=z/rad
        allharm=legvander(mu,self.degree);harm=allharm[:,::2]*self.norm
        deriv=np.zeros_like(harm);deriv[:,1:]=(allharm[:,1:-1:2]-mu[:,None]*allharm[:,2::2])*(self.orders[1:]*self.norm[1:])/(1-mu[:,None]**2)
        vals=self.bank.gravity(rad);pot=(vals*harm).sum(1)+self.central.value(rad)
        ds=(self.bank.gravity(rad,1)*harm).sum(1)+self.central.value(rad,1)
        tilt=(vals*deriv).sum(1)/rad
        return -(ds-mu*tilt)*r/rad,-mu*ds-(1-mu**2)*tilt,pot
    def force_sky(self,r,z):
        gr,gz,pot=self.field(r,z);rad=np.hypot(r,z)
        return old.UNIT*np.array([(gr*r+gz*z)/rad,(gr*z-gz*r)/rad]).reshape(2,-1)

def rings(src,rad,height,order,split=False):
    assert rad>4 and height>=0
    offsets=np.array([0,.0001,.001,.01,.04,.12,.35,1.,2.5])
    radii=np.unique(np.r_[src.radknots,np.arange(0,22,.5),[25,30,36,45,60,80,110,150,220],rad+offsets,rad-offsets])
    vert=np.unique(np.r_[[0.],np.geomspace(.005,50,54),height+offsets,(height-offsets)[height-offsets>0],src.stars.H])
    if split:vert=np.unique(np.r_[vert,src.stars.axis])
    positive,weightz=intervals(vert,order);rs,wr=intervals(radii[radii>=0],order)
    zs=np.r_[positive,-positive];wz=np.tile(weightz,2);dz=height-zs
    summed=np.zeros(3)
    for start in range(0,len(rs),16):
        rr=rs[start:start+16,None];measure=wr[start:start+16,None]*rr*wz*src.disk(rr,zs)
        d2=(rad+rr)**2+dz**2;small=(rad-rr)**2+dz**2;par=4*rad*rr/d2
        from scipy.special import ellipkm1
        kval=ellipkm1(small/d2);evals=ellipe(par)
        coeff=measure/np.sqrt(d2)
        summed+=np.array([(-2/rad*coeff*(kval+(rad**2-rr**2-dz**2)/small*evals)).sum(),
                          (-4*coeff*dz/small*evals).sum(),(-4*coeff*kval).sum()])*old.G
    rr=np.hypot(rad,height)
    return summed-old.G*src.stars.bmass*np.array([rad/rr**3,height/rr**3,1/rr])

SITES=((6.,1.5),(8.3,1.5),(17.58,0.),(8.5,1.),(8.5,2.))
if __name__=='__main__':
    source=Source();rows=[]
    for order in (12,24):
        for r,z in SITES:
            gr,gz,pot=rings(source,r,z,order)
            rows.append(dict(method='rings',resolution=order,R=r,z=z,aR=gr,az=gz,potential=pot))
    table('independent-ring-force',rows)
