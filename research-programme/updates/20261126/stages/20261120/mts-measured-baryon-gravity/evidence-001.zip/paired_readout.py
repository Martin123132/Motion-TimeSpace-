from history_wave import *
from itertools import product

def read(name):return ms.io.readfile(HERE/(name+'.csv'))

def collect():
    frozen();check=[];summary=[];physical=[];solar=[];columns=[];phase=[];requirements=[]
    src=Source()
    for radius in (6.,8.2,8.3,8.5):
        for height in (0.,.3,1.,1.1,1.5,2.,100.):
            columns.append(dict(R=radius,z=height,rho_plane_msun_pc3=src.disk(radius,0.)*1e-9,full_tail=src.disk(radius,height,True),
                                truncate_renormalize=src.disk(radius,height,True,True)))
    tests=('r6','p6','r83','p83');bg=ms.pre.background(1);conversion=2*pi*old.G*1e6
    for occ in range(3):
        broad=read(f'coarse-mesh0-k40-occ{occ}-evolution')
        fine=read(f'fine-mesh1-k64-occ{occ}-evolution')
        scores=read(f'fine-mesh1-k64-occ{occ}-bands')
        coarse=read(f'coarse-mesh0-k40-occ{occ}-bands')
        assert len(scores)==len(coarse)==192
        heights=[row for row in read('fine-mesh1-heights') if row['occupation']==str(occ)]
        with np.load(HERE/f'fine-mesh1-occ{occ}.npz') as pk:g=pk['g'];mass=float(pk['mass_msun'])
        sky=(g/bg.sqrt[:,None])@bg.harm.T
        for h in ms.MODELS:
            primary=next(row for row in fine if row['history']==h and row['substeps']=='16')
            with np.load(HERE/f'fine-mesh1-k64-occ{occ}-{h}.npz') as pk:
                x=pk['x'];density=pk['density']
            alt=(2*sky*((x/bg.sqrt[:,None])@bg.harm.T))@(bg.aw[:,None]*bg.harm)/bg.rad[:,None]**2
            assert np.max(abs(alt-density))<2e-12
            unit=mass/(g*g).sum()
            shell=density[:,0]*bg.rad**2*unit
            net=bg.mesh.weight@shell
            assert abs(net/mass)<1e-12
            for j,which in enumerate(('inner6_msun','inner83_msun')):
                dm=bg.mesh.inner[j]@shell;exterior=(bg.mesh.weight-bg.mesh.inner[j])@shell
                assert abs(dm/float(primary[which])-1)<1e-11 and abs(dm+exterior)/abs(dm)<1e-11
                physical.append(dict(occupation=occ,history=h,sphere_kpc=bg.mesh.probes[j]*bg.length,inside_msun=dm,
                                  exterior_msun=exterior,net_msun=net,net_fraction=net/mass))
            for label,data,steps in [('space_basis_field',broad,'16'),('time',fine,'8')]:
                ctl=next(row for row in data if row['history']==h and row['substeps']==steps)
                for key in tests:
                    val=float(primary[key]);oldval=float(ctl[key]);delta=abs(val-oldval)
                    check.append(dict(occupation=occ,history=h,control=label,key=key,primary=val,control_value=oldval,
                                  absolute=delta,relative=delta/abs(val),within_inherited=delta<=2e-5*abs(val)))
            for label,model in product(('site_minus_point','archive_accelerating'),('MTS','NFW')):
                sub=[row for row in scores if (row['frame'],row['model'],row['history'])==(label,model,h)]
                oldrows=[row for row in coarse if (row['frame'],row['model'],row['history'])==(label,model,h)]
                assert len(sub)==len(oldrows)==8
                for row,ctrl in zip(sub,oldrows):
                    assert all(row[k]==ctrl[k] for k in ('history','R','z','component','low','high','inside'))
                    total=sum(float(row[k]) for k in ('ordinary','stationary_dark','direct','induced'))
                    assert abs(total-float(row['total']))<1e-14 and (row['inside']=='True')==(float(row['low'])<=total<=float(row['high']))
                    if model=='NFW':assert float(row['induced'])==0
                group=lambda c:[r for r in sub if r['component']==c]
                summary.append(dict(occupation=occ,history=h,frame=label,model=model,inside=sum(r['inside']=='True' for r in sub),
                                    before=sum(r['before_inside']=='True' for r in sub),radial_in=sum(r['inside']=='True' for r in group('radial')),
                                    polar_in=sum(r['inside']=='True' for r in group('polar')),
                                    max_total_refinement=max(abs(float(r['total'])-float(v['total'])) for r,v in zip(sub,oldrows))))
                if label=='site_minus_point' and model=='MTS':
                    for row in sub:
                        if row['z']!='1.5':continue
                        original=float(row['total'])-float(row['induced']);gap=np.clip(original,float(row['low']),float(row['high']))-original
                        phase.append(dict(occupation=occ,history=h,R=row['R'],component=row['component'],need_to_nearest_band=gap,
                                          actual_response=row['induced'],fraction_filled='' if gap==0 else float(row['induced'])/gap))
                if model=='MTS':
                    for r,comp in product(('6.0','8.3'),('radial','polar')):
                        north,south=sorted([row for row in sub if row['R']==r and row['component']==comp],key=lambda a:-float(a['z']))
                        def interval(row):
                            foreground=float(row['ordinary'])+float(row['direct']);return np.array([float(row['low']),float(row['high'])])-foreground
                        first,second=interval(north),interval(south)
                        if comp=='polar':second=-second[::-1]
                        lo=max(first[0],second[0]);hi=min(first[1],second[1]);actual=float(north['stationary_dark'])+float(north['induced'])
                        requirements.append(dict(occupation=occ,history=h,frame=label,R=r,component=comp,even_dark_low=lo,even_dark_high=hi,
                                            compatible_pair=lo<=hi,zero_permitted=lo<=0<=hi,actual_dark=actual,actual_inside=lo<=actual<=hi))
            tide=old.Multipoles(bg.rad*bg.length,density*(bg.vel/bg.length)**2,bg.orders,0,bg.mesh.edge*bg.length,.02)
            for r,tag in ((6.,'6'),(8.3,'83')):
                gr,gz,*_=tide(r,np.array([1.5]));skyforce=projection(gr[0],gz[0],r,1.5)
                assert max(abs(skyforce-np.array([float(primary['r'+tag]),float(primary['p'+tag])])))<2e-8
            sat,centre=cr.satellite(h)
            for obs in heights:
                z=float(obs['z']);r=float(obs['R'])
                endpoints=np.array([[-r,0,z],[-r,0,-z]])
                north,south=sat(endpoints-centre)[:,3]
                direct=(south-north)/(2*conversion)
                induced=-tide(r,np.array([z]))[1][0]/conversion if obs['model']=='MTS' else 0.
                stationary=float(obs['force_equivalent'])
                solar.append(dict(occupation=occ,history=h,R=r,z=z,model=obs['model'],stationary=stationary,
                                  satellite_compression=direct,induced_compression=induced,sum=stationary+direct+induced,observed=obs['RAVE']))
    for name,rows in [('counted-shape',columns),('refinement',check),('band-summary',summary),('independent-mass-flow',physical),
                      ('signed-gap-fractions',phase),('solar-evolved-compression',solar),('even-dark-requirement',requirements)]:table(name,rows)

if __name__=='__main__':collect()
