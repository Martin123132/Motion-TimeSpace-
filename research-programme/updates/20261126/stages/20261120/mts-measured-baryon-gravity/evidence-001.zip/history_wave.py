from prepare_field import *
import common_response as cr

def evolve(level,mesh,keep,occ):
    frozen();prefix=f'{level}-mesh{mesh}';src=Source()
    gravity,wave,_=restored(src,level,mesh);bg=wave.bg
    with np.load(HERE/f'{prefix}-occ{occ}.npz') as pk:
        g=pk['g'];mu=float(pk['mu']);mass=float(pk['mass_msun'])
        assert np.array_equal(pk['orders'],bg.orders) and np.array_equal(pk['radius_kpc'],bg.rad*bg.length)
    assert np.linalg.norm(wave.fields(g.ravel())[-1]@g.ravel()-mu*g.ravel())<5e-10
    op,err=cr.operators(wave,g.ravel(),mu,keep);sigma=op['sigma']
    assert digest(cr.AXIS/'seal.json')=='a46d251285faaba640cea0288634284d6d3046a9693e934921a28936060c6f70'
    pins=json.loads((cr.AXIS/'seal.json').read_bytes())['files']
    prev=ms.io.readfile(ROOT/'mts-lmc-tidal-history-20261119'/'present-sky.csv')
    acc=ms.io.readfile(ms.io.LIVE/'common-forces.csv')
    stat=[row for row in ms.io.readfile(HERE/f'{prefix}-signed.csv') if int(row['occupation'])==occ]
    wave_sky=(g/bg.sqrt[:,None])@bg.harm.T;kernel=None;norm=(g*g).sum();rows=[];scores=[]
    for loop,history in enumerate(ms.MODELS):
        guard();filename=cr.name(history,320,40,36,16)
        assert digest(cr.AXIS/filename)==pins[filename]
        with np.load(cr.AXIS/filename) as bank:
            time=bank['time'];v=bank['V'];radii=bank['radius']
        if kernel is None:
            kernel=cr.source_map(op,radii,40);old_radii=radii
        assert np.array_equal(old_radii,radii)
        force=(v.reshape(len(time),-1)@kernel)@op['u'];del v
        tau=time*bg.vel/bg.length
        for stride in (2,1):
            amplitude=cr.integrate(force[::stride],tau[::stride],sigma)[-1].real
            expected=op['sky']@amplitude
            x=np.einsum('lrk,lk->rl',op['block'],(op['u']@amplitude).reshape(bg.count,-1))
            density=((2*wave_sky*((x/bg.sqrt[:,None])@bg.harm.T))@(bg.aw[:,None]*bg.harm))/bg.rad[:,None]**2
            through=bg.sky_forces((density*(bg.rad*bg.sqrt)[:,None]).ravel())[:,[1,0,2]].ravel()
            fraction=2*(g*x).sum()/norm
            assert abs(fraction)<1e-10 and max(abs(through-expected))<1e-11
            massfrac=lambda mask:2*((bg.mesh.inner[mask]/bg.mesh.weight)@(g*x).sum(1))/norm
            native=expected[[0,1,3,4]]
            rows.append(dict(history=history,substeps=16//stride,number_fraction=fraction,total_from_density=bg.mesh.weight@(bg.rad**2*density[:,0])/norm,
                         mass_msun=mass,inner6_msun=massfrac(0)*mass,inner83_msun=massfrac(1)*mass,min_sigma=min(sigma),
                         tangent_error=err,density_readout_error=max(abs(through-expected)),**dict(zip(('r6','p6','r83','p83'),native))))
            assert abs(rows[-1]['total_from_density']-fraction)<1e-12
            if stride!=1:continue
            packet(f'{prefix}-k{keep}-occ{occ}-{history}.npz',x=x,density=density,r=bg.rad,orders=bg.orders)
            point={(a['R'],a['z'],a['component']):float(a['direct']) for a in prev if a['model']==history and a['background']=='mts' and a['tag']==prev[0]['tag'] and a['component'] in ('radial','polar')}
            frame={(a['R'],a['z'],a['component']):float(a['direct_in_frame']) for a in acc if a['model']==history and a['occupation']=='0' and a['branch']=='frozen_wave' and a['frame']=='archive_accelerating'}
            assert len(point)==len(frame)==8
            for s in stat:
                key=(s['R'],s['z'],s['component'])
                index=(0 if key[0]=='6.0' else 2)+(key[2]=='polar')
                dv=native[index]*(-1 if float(key[1])<0 and key[2]=='polar' else 1)
                if s['model']=='NFW':dv=0.
                for label,direct in [('site_minus_point',point[key]),('archive_accelerating',frame[key])]:
                    before=float(s['total'])+direct;after=before+dv
                    lo,hi=float(s['low']),float(s['high'])
                    scores.append(dict(history=history,occupation=occ,model=s['model'],frame=label,R=key[0],z=key[1],component=key[2],
                            ordinary=s['ordinary'],stationary_dark=s['dark'],direct=direct,induced=dv,total=after,low=lo,high=hi,
                            before_inside=lo<=before<=hi,inside=lo<=after<=hi))
        print(level,mesh,keep,occ,history,flush=True)
    table(f'{prefix}-k{keep}-occ{occ}-evolution',rows)
    table(f'{prefix}-k{keep}-occ{occ}-bands',scores)
if __name__=='__main__':
    evolve(sys.argv[1],*map(int,sys.argv[2:]))
