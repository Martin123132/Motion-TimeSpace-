from gravity_field import *
import matched_sky as ms
import vertical_gravity as vg

def frozen():
    guard();record=json.loads((HERE/'source-freeze.json').read_bytes())
    assert all(digest(HERE/name)==v for name,v in record['files'].items())

def exact_sites(source):
    frozen();rows=[]
    for order in (8,16):
        for radius,height in SITES:
            val=rings(source,radius,height,order,True)
            rows.append(dict(order=order,R=radius,z=height,aR=val[0],az=val[1],potential=val[2]))
    table('ring-knots-resolved',rows)

def restored(source,level,mesh):
    degree,order,spacing={'coarse':(192,896,.03),'fine':(384,1792,.018)}[level]
    gravity=Gravity(source,degree,order,spacing)
    wave=ms.Wave(mesh);bg=wave.bg
    r=bg.rad*bg.length
    potential=gravity.sky(r,bg.mu,2*bg.orders[-1])
    assert np.allclose(bg.harm.T@(bg.aw[:,None]*bg.harm),np.eye(len(bg.orders)),atol=1e-12)
    wave.bare=bg.mesh.kinetic(bg.orders,True)+wave.mult(potential/bg.vel**2)
    oracle={(float(row['R']),float(row['z'])):np.array([float(row[k]) for k in ('aR','az','potential')])
            for row in ms.io.readfile(HERE/'ring-knots-resolved.csv') if row['order']=='16'}
    wave.ordinary_outer=-oracle[ms.OUTER,0][0]*ms.UNIT
    return gravity,wave,oracle

def packet(name,**vals):
    buf=io.BytesIO();np.savez_compressed(buf,**vals);put(name,buf.getvalue())

def projection(aR,az,r,z):
    return ms.UNIT*np.array([aR*r+az*z,aR*z-az*r])/np.hypot(r,z)

def run(level,mesh):
    frozen();src=Source();grav,wave,oracle=restored(src,level,mesh);bg=wave.bg
    prefix=f'{level}-mesh{mesh}';ground=[];rows=[];vertical=[];controls=[]
    lowhigh=ms.bands()
    for (r,z),vals in oracle.items():
        est=grav.field(r,z)
        for j,key in enumerate(('aR','az','potential')):
            controls.append(dict(R=r,z=z,key=key,rings=vals[j],multipole=est[j][0],absolute=abs(est[j][0]-vals[j]),
                relative='' if abs(vals[j])<1e-9 else abs(est[j][0]/vals[j]-1)))
    halo=ms.nfw(0);target={k:int(k) for k in range(3)}
    for occ in target:
        n=ms.pre.background(min(occ,1)).mass;trail='-ell96' if mesh==1 else ''
        with np.load(OBS/f'grounds/count_split-{mesh}-{occ}{trail}.npz') as pk:
            assert np.array_equal(pk['r'],bg.rad) and np.array_equal(pk['orders'],bg.orders)
            g,mu,stats=wave.solve(pk['g'].ravel(),n,anchor=occ==2)
        scale=(stats['outer_speed']**2/ms.OUTER-wave.ordinary_outer/ms.UNIT)/(-halo(ms.OUTER,0.)[0])
        assert scale>0 and (abs(stats['relative_number_change'])<1e-11 if occ!=2 else abs(stats['outer_speed']-224.03)<1e-8)
        mass=float(ms.io.readfile(ms.pre.MASS)[min(occ,1)]['dark_mass'])*stats['norm']/n
        ground.append(dict(occupation=occ,mass_msun=mass,nfw_scale=scale,**stats))
        packet(f'{prefix}-occ{occ}.npz',g=g.reshape(bg.hshape),mu=mu,radius_kpc=bg.rad*bg.length,orders=bg.orders,mass_msun=mass)
        dark=vg.wave_field(bg,g.reshape(bg.hshape));wknots=bg.rad*bg.length
        for radius in (6.,8.3):
            aR,az,_=oracle[radius,1.5];native=projection(aR,az,radius,1.5)
            tag='6' if radius==6 else '83'
            for kind,field,fac in [('MTS',dark,1.),('NFW',halo,scale)]:
                inward,down,*_=field(radius,np.array([1.5]));signal=projection(inward[0],down[0],radius,1.5)*fac
                if kind=='MTS':assert max(abs(signal-[stats['r'+tag],stats['p'+tag]]))<1e-7
                for z in (1.5,-1.5):
                    for j,comp in enumerate(('radial','polar')):
                        sign=1 if j==0 or z>0 else -1
                        lo,hi=lowhigh[radius,('ar','atheta')[j],('north' if z>0 else 'south')][3:5]
                        total=sign*(native[j]+signal[j])
                        rows.append(dict(occupation=occ,model=kind,R=radius,z=z,component=comp,ordinary=sign*native[j],
                                         dark=sign*signal[j],total=total,low=lo,high=hi,inside=lo<=total<=hi))
        radius=8.5
        for z in (1.,2.):
            for kind,fn,fac in [('MTS',dark,1.),('NFW',halo,scale)]:
                zs,weights=intervals(np.linspace(0,z,int(12*z)+1),5)
                ordinary=src.disk(radius,z,True)
                dk=fac*fn(radius,zs)[3]
                col=2e-6*weights@dk/(4*pi*old.G)
                down=fac*fn(radius,np.array([z]))[1][0]
                equiv=-(oracle[radius,z][1]+down)/(2*pi*old.G*1e6)
                resid=equiv-ordinary-col
                def radial(rr):
                    return grav.field(rr,zs)[0]+fac*fn(rr,zs)[0]
                checks=[]
                for step in (.016,.008):
                    deriv=(-radial(radius+2*step)+8*radial(radius+step)-8*radial(radius-step)+radial(radius-2*step))/(12*step)
                    checks.append(weights@(deriv+radial(radius)/radius)/(2*pi*old.G*1e6))
                vertical.append(dict(occupation=occ,model=kind,R=radius,z=z,baryon_column=ordinary,dark_column=col,
                                force_equivalent=equiv,radial_from_difference=resid,radial_from_divergence=checks[1],
                                radial_step_change=checks[1]-checks[0],identity_defect=resid-checks[1],RAVE={1.:68.5,2.:96.9}[z]))
    for key,data in [('stationary',ground),('signed',rows),('heights',vertical),('force-check',controls)]:table(prefix+'-'+key,data)
    print(prefix,'done',flush=True)

if __name__=='__main__':
    if sys.argv[1:] == ['rings']:exact_sites(Source())
    else:run(sys.argv[1],int(sys.argv[2]))
