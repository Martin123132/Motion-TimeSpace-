"""Open the older evolved comparison only after sealing raw initial-value predictions."""
from predict import LOCAL, PRIOR, FIELDS, digest, pinned, save, np, json, csv


def rows(path):
    with path.open(newline="") as stream:
        return list(csv.DictReader(stream))


def forecast(name):
    return {(int(row["layer"]), float(row["width"]), int(row["seed"]), int(row["flag"])): row
            for row in rows(LOCAL / name)}


def main():
    inputs = ["PREDICTION.md", "predict.py", "forecast-heavy-24.csv", "forecast-heavy-40.csv", "forecast-cold-24.csv"]
    frozen = {name: digest(LOCAL/name) for name in inputs}
    receipt = LOCAL/"forecast-hashes.json"
    if receipt.exists():
        assert json.loads(receipt.read_bytes()) == frozen
    else:
        with receipt.open("x") as stream:
            json.dump(frozen, stream, indent=2)
    cold = forecast(inputs[-1])
    assert len(cold) == 60
    for (layer, width, seed, flag), record in cold.items():
        assert all(record[key] == cold[layer, width, seed, 1-flag][key] for key in (*FIELDS,"chain_error"))
    local = rows(pinned("newton-normal-parts-h5-t8.csv"))
    total = rows(pinned("newton-windows-h5-n8.csv"))
    observed = rows(pinned("source-attribution.csv"))
    references = {(int(row["seed"]),float(row["width"])):row for row in observed
                  if (row["native"],row["grid"],row["steps"],row["stride"]) == ("5","120","96","1")}
    assert len(references) == 4
    scores = []
    for order in (24,40):
        predictions = forecast(f"forecast-heavy-{order}.csv")
        assert len(predictions) == 60
        for layer in range(5):
            for (seed,width), row in references.items():
                def increment(key):
                    def item(host,flag):
                        return float(predictions[layer,width,host,flag][key])
                    return (item(seed,0)-item(0,0))-(item(seed,1)-item(0,1))
                parts = [increment(key) for key in FIELDS]
                newton = float(next(case['increment'] for case in total if int(case["seed"])==seed and float(case["width"])==width and case["quadrature"]=="16"))
                rest = float(next(case['increment'] for case in local if int(case["seed"])==seed and float(case["width"])==width))
                assert newton==float(row['newton']) and rest==float(row['newton_local'])
                scale = 1e6/newton
                mass = (sum(parts[:3])-rest)*scale
                geom = (sum(parts[3:])-(newton-rest))*scale
                measured_mass, measured_geom = (float(row[key]) for key in ("rest_mass_ppm","geometry_ppm"))
                actual = measured_mass+measured_geom
                mismatch = mass+geom-actual
                scores.append(dict(order=order,layer=layer,seed=seed,width=width,newton=newton,
                    rest_ppm=mass,geometry_ppm=geom,remainder_ppm=mass+geom,
                    measured_rest_ppm=measured_mass,measured_geometry_ppm=measured_geom,measured_remainder_ppm=actual,
                    error_ppm=mismatch,relative_error=mismatch/actual,
                    same_sign=(mass+geom)*actual>0,pass_on_tide=abs(mismatch)<20,
                    pass_on_remainder=abs(mismatch/actual)<2e-5,**dict(zip(FIELDS,parts))))
    save("remainder-test.csv",scores)
    for layer in range(5):
        group=[row for row in scores if row['order']==40 and row['layer']==layer]
        compare=[row for row in scores if row['order']==24 and row['layer']==layer]
        delta=[abs(first['remainder_ppm']-second['remainder_ppm']) for first,second in zip(group,compare)]
        print(layer, "net", [round(row["remainder_ppm"],5) for row in group], "error ppm", [round(row["error_ppm"],5) for row in group], "grid spread", max(delta))
    print("layer 4 absolute rest and geometry mismatch (ppm of tide):",
          [(round(row['rest_ppm']-row['measured_rest_ppm'],5),round(row['geometry_ppm']-row['measured_geometry_ppm'],5)) for row in group])
    print("all-cold switch identical at all five orders on both detectors")
    assert len(scores)==40


if __name__=="__main__":
    main()
