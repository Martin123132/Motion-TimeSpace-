"""Posterior scoring of gravitational source-channel deletions; not rival physical models."""
from compare import rows, LOCAL, pinned, save, difference


def main():
    response=rows(LOCAL/"constraint-raw.csv")
    first=rows(LOCAL/"remainder-test.csv")
    inputs=rows(pinned("newton-windows-h5-n8.csv"))
    records=[]
    for seed in (1,-1):
        for width in (.15,.30):
            scale=1e6/float(next(row["increment"] for row in inputs if int(row["seed"])==seed and row["quadrature"]=="16" and float(row["width"])==width))
            target=next(row for row in first if row["order"]=="40" and row["layer"]=="1" and int(row["seed"])==seed and float(row["width"])==width)
            numbers={}
            for label in ("neither","momentum","energy","both"):
                group=[row for row in response if row["source"] in (label,"dust")]
                numbers[label]=(difference(group,seed,width,"rest")+difference(group,seed,width,"geometry"))*scale-1e6
            assert abs(numbers["both"]-float(target["remainder_ppm"]))<.003
            for label,value in numbers.items():
                records.append(dict(seed=seed,width=width,constraint_channels=label,predicted_ppm=value,
                    change_from_neither_ppm=value-numbers["neither"],deviation_from_both_ppm=value-numbers["both"],
                    error_vs_evolved_ppm=value-float(target["measured_remainder_ppm"])))
            interaction=numbers["both"]-numbers["energy"]-numbers["momentum"]+numbers["neither"]
            print(seed,width,"both",numbers["both"],"changes from neither",
                  {key:round(val-numbers["neither"],6) for key,val in numbers.items()},"mixed",interaction)
    assert len(response)==30 and len(records)==16
    save("constraint-channels.csv",records)


if __name__=="__main__":
    main()
