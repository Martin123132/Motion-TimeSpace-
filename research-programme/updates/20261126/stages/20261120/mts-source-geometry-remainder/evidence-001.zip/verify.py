"""Read-only verification after initial sealing; scientific failures are preserved."""
import ast
import math
from score import rows
from predict import LOCAL, PRIOR, PIN, manifest, digest, json, np, pinned

EXPECTED = {"forecast-heavy-24.csv":60,"forecast-heavy-40.csv":60,"forecast-cold-24.csv":60,
    "first-return-groups.csv":84,"first-return-effects.csv":28,"remainder-test.csv":40,
    "environment-raw.csv":12,"combined-tide.csv":20,"transfer-raw.csv":120,"transfer-tests.csv":40,
    "constraint-raw.csv":30,"constraint-channels.csv":16}


def main():
    assert all(digest(PRIOR/name)==value for name,value in manifest.items())
    assert set(path.name for path in LOCAL.glob("*.csv"))==set(EXPECTED)
    assert not list(LOCAL.glob("*.partial"))
    for source in LOCAL.glob("*.py"):
        ast.parse(source.read_text())
    for name,count in EXPECTED.items():
        values=rows(LOCAL/name)
        assert len(values)==count and all(None not in row and all(val and val.lower() not in ("inf","nan","-inf") for val in row.values()) for row in values)
    hashes=json.loads((LOCAL/"forecast-hashes.json").read_bytes())
    assert all(digest(LOCAL/name)==value for name,value in hashes.items())
    for name in ("forecast-heavy-24.csv","forecast-heavy-40.csv","forecast-cold-24.csv","transfer-raw.csv"):
        assert all(0<=float(row["chain_error"])<1e-10 for row in rows(LOCAL/name))
    data=rows(LOCAL/"remainder-test.csv")
    for row in data:
        mismatch=float(row["error_ppm"])
        measured=float(row["measured_remainder_ppm"])
        assert math.isclose(mismatch,float(row["remainder_ppm"])-measured,abs_tol=1e-12)
        assert (abs(mismatch)<20)==(row["pass_on_tide"]=="True")
        assert (abs(mismatch/measured)<2e-5)==(row["pass_on_remainder"]=="True")
        if row["layer"]=="0":
            assert row["pass_on_tide"]=="False"
        if row["layer"]=="1":
            assert row["pass_on_tide"]=="True" and row["pass_on_remainder"]=="False"
        if row["layer"]=="4":
            assert row["pass_on_remainder"]=="True" and abs(mismatch)<.00087
    transfers=rows(LOCAL/"transfer-tests.csv")
    assert all(abs(float(row["relative_error"]))<2e-5 and abs(float(row["error_ppm"]))<.00108 for row in transfers if row["layer"]=="4")
    constraints=rows(LOCAL/"constraint-raw.csv")
    assert len([row for row in constraints if row["archive_arrays_checked"]=="20"])==12
    assert all(float(row["source_rel_change"])<2e-9 for row in constraints)
    source=rows(LOCAL/"constraint-channels.csv")
    assert all(28<float(row["change_from_neither_ppm"])<32 for row in source if row["constraint_channels"]=="momentum")
    complete=[row for row in rows(LOCAL/"combined-tide.csv") if row["layer"]=="4"]
    assert len(complete)==4 and all(.72<abs(float(row["error_ppm"]))<.82 for row in complete)
    assert any(row["pass_readouts"]=="False" for row in rows(pinned("point-comparison.csv")))
    assert any(row["pass_transport"]=="False" for row in rows(pinned("point-comparison.csv")))
    for name in ("DERIVATION.md","PREDICTION.md","RESULTS.md","REPLAY.md"):
        import re
        for link in re.findall(r"\]\(([^)]+)\)",(LOCAL/name).read_text(encoding="utf8")):
            assert (LOCAL/link).is_file(),link
    artifacts={p.name:digest(p) for p in sorted(LOCAL.iterdir()) if p.is_file() and p.name!="seal.json"}
    output={"prior_sha256":PIN,"prior_files_verified":len(manifest),"row_counts":EXPECTED,"files":artifacts}
    target=LOCAL/"seal.json"
    if target.exists():
        assert json.loads(target.read_bytes())==output
    else:
        with target.open("x",encoding="utf8",newline="\n") as stream:
            stream.write(json.dumps(output,indent=2)+"\n")
    print("sealed",len(artifacts),"files;",sum(EXPECTED.values()),"rows;",len(manifest),"predecessor files verified;",digest(target))


if __name__=="__main__":
    main()
