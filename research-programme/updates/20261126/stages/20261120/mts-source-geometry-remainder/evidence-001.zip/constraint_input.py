"""Reconstruct the forecast from both global initial constraints, not the archived Einstein tide."""
from predict import (Stagger, CLOUD, checked, DURATION, LaunchStress, FRACTIONS, kernels, np,
                     pair, readout, save, safe)
from states import BalancedNative, SPAN, DLOG, input_pack, Slice, angular
from pressure import pressure
from normal_graph import homogeneous, normal_data, Sources
from coupled_readout import change_norm


def make_packet(sim, state, grid, samples, supply, ref, press, flag, kind):
    mu=ref["a"]*sim.patch.p.mass
    obj=Slice(sim,grid,ref,samples,state,flag,not flag,"fixed",0,"matched")
    hub=ref["H"]
    count=0
    err=0.
    if not flag:
        mean=homogeneous(ref,ref["rh"][sim.patch.j],mu,press)
        hub=mean["hubble"]
        graph,fields=normal_data(obj,supply,mean)
        for count in range(1,9):
            hook=Sources(grid,fields,samples[0]["other"],energy=kind in ("both","energy"),flux=kind in ("both","momentum"))
            obj=Slice(sim,grid,{**ref,"H":hub},samples,state,flag,True,"fixed",0,"matched",hook)
            new,newfields=normal_data(obj,supply,mean,graph)
            err=change_norm(fields,newfields)
            if err<2e-9:
                break
            graph,fields=new,newfields
        else:
            raise RuntimeError("normal initial constraint iteration did not converge")
        delta,drift=[pair(field.real,angular(field)) for field in graph]
    else:
        delta=drift=pair(np.zeros_like(grid.points))
    cut=grid.points[:,0]<16
    mono=grid.evaluate(obj.state[0])[0]
    higher=samples[0]["V"]+grid.evaluate(obj.state[2])[0][flag]
    packet=dict(t=grid.t,h=grid.h,chi=pair(grid.evaluate(obj.f0)[0],grid.evaluate(obj.f2)[0])[...,cut,:],
        n=np.stack([pair(first,second) for first,second in zip(obj.m["n"],obj.m["D"])])[...,cut,:],
        v=np.stack([pair(first,second) for first,second in zip(mono[1]/grid.points,higher)])[...,cut,:],
        b=pair(obj.b0,obj.b2)[...,cut,:],c=obj.c2[cut],d=obj.d2[cut],delta=delta[...,cut,:],drift=drift[...,cut,:],
        rho=ref["rh"],mu=mu,H=hub,P=press,R=ref["R"],weight=ref["w"],
        e0=samples[0]["other"][cut],s0=supply["spec2"][cut],native_stress=samples[0]["stress"][cut],
        native_cross=samples[0]["stress_cross"][cut],initial_tide=None,probes=())
    return packet,count,err


def launch_prediction(packet,flag):
    shell=Stagger(packet,120,6,flag,1,"stagger")
    shell.incident.bank=LaunchStress(shell.incident.bank)
    state=shell.initial
    launch=shell.dynamics(0.,state)
    times,plain,rotating=kernels(40,DURATION,2*shell.mu)
    result=[]
    for moment in times:
        inc=launch*moment
        if not flag:
            oscillation=np.expm1(2j*shell.mu*moment)/(2j*shell.mu)
            inc[14]+=(oscillation-moment)*launch[15]/(2j)
            inc[15]=oscillation*launch[15]
        probe=state+inc
        value,error=readout(shell,probe,shell.dynamics(moment,probe))
        assert error<1e-10
        result.append(value)
    return np.einsum("t,tij->ij",plain[-1],result)


def main():
    records=[]
    sim=BalancedNative("heavy",120,600,False,"native36",SPAN*DLOG)
    for flag in (0,1):
        ref,press,unused=pressure(flag)
        for seed in (0,1,-1):
            safe()
            state,grid,samples,supply=input_pack(sim,5,seed,flag,ref,press)
            for kind in (("both","energy","momentum","neither") if not flag else ("dust",)):
                packet,count,error=make_packet(sim,state,grid,samples,supply,ref,press,flag,kind)
                amounts=launch_prediction(packet,flag)
                count_checked=0
                if kind in ("both","dust"):
                    with np.load(checked(CLOUD,f"launch-h5-off{flag}-seed{seed}.npz")) as previous:
                        for key in set(packet)-{"initial_tide","probes"}:
                            np.testing.assert_array_equal(packet[key],previous[key],err_msg=key)
                            count_checked+=1
                for width,terms in zip(FRACTIONS,amounts):
                    records.append(dict(seed=seed,flag=flag,source=kind,width=width,rest=sum(terms[:3]),
                                        geometry=sum(terms[3:]),iterations=count,source_rel_change=error,archive_arrays_checked=count_checked))
                print("global constraint",flag,seed,kind,count,error,"verified launch arrays",count_checked,flush=True)
    save("constraint-raw.csv",records)


if __name__=="__main__":
    main()
