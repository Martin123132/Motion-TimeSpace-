"""External stress frozen; incoming energy and momentum obey their local conservation equations."""
from predict import (checked,CLOUD,Stagger,LaunchStress,np,kernels,DURATION,Window,FRACTIONS,save,safe)


def main():
    rows=[]
    for seed in (0,1,-1):
        for flag in (0,1):
            safe()
            with np.load(checked(CLOUD,f"launch-h5-off{flag}-seed{seed}.npz")) as packet:
                shell=Stagger(packet,120,6,flag,1,"stagger")
            shell.incident.bank=LaunchStress(shell.incident.bank)
            initial=shell.initial
            launch=shell.dynamics(0.,initial)
            times,plain,rotating=kernels(40,DURATION,2*shell.mu)
            readings=[]
            for moment in times:
                change=moment*launch
                if not flag:
                    rotating_normal=np.expm1(2j*shell.mu*moment)/(2j*shell.mu)
                    change[14]+=(rotating_normal-moment)*launch[15]/(2j)
                    change[15]=rotating_normal*launch[15]
                fields=initial+change
                rate=shell.dynamics(moment,fields)
                environment=-fields[17].real/3
                environment[1]+=shell.incident.bank.data[4]
                fixed,moved=Window(shell,fields,rate,8).times(environment,-rate[17].real/3)
                readings.append(fixed+moved)
            for width,prediction in zip(FRACTIONS,plain[-1]@np.asarray(readings)):
                rows.append(dict(seed=seed,flag=flag,width=width,predicted=prediction))
    save("environment-raw.csv",rows)


if __name__=="__main__":
    main()
