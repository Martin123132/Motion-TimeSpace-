"""Fixed-occupation wave current and finite-ruler source forecast from a constrained launch."""
import csv
import hashlib
import io
import json
import os
import sys
from pathlib import Path

for setting in ("OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS", "NUMEXPR_NUM_THREADS"):
    os.environ[setting] = "1"
LOCAL = Path(__file__).resolve().parent
PRIOR = LOCAL.parent / "mts-compatible-radial-20261120"
PIN = "62a9e652affa553c98e58537d68ac762fb3030b112d8548f71840433f99245b2"


def digest(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


assert digest(PRIOR / "seal.json") == PIN
manifest = json.loads((PRIOR / "seal.json").read_bytes())["files"]


def pinned(name):
    path = PRIOR / name
    assert digest(path) == manifest[name], name
    return path


for filename in ("scheme.py", "window.py", "stagger.py"):
    pinned(filename)
sys.path.insert(0, str(PRIOR))
from window import Stagger, Window, checked, CLOUD, DURATION, FRACTIONS, np, pair, mul, exp, square, safe
from scipy.special import roots_legendre
from numpy.polynomial.chebyshev import chebvander

FIELDS = ("rest_compression", "rest_flux", "rest_ruler", "intrinsic", "extrinsic", "geometry_ruler")


def save(name, records):
    assert records and all(None not in row.values() for row in records)
    stream = io.StringIO(newline="")
    writer = csv.DictWriter(stream, fieldnames=tuple(records[0]), lineterminator="\n")
    writer.writeheader()
    writer.writerows(records)
    target = LOCAL / name
    data = stream.getvalue().encode()
    if target.exists():
        assert target.read_bytes() == data, target
    else:
        with (LOCAL / (name + ".partial")).open("xb") as out:
            out.write(data)
        (LOCAL / (name + ".partial")).rename(target)


class LaunchStress:
    def __init__(self, source):
        self.data = source.at(0.).copy()

    def at(self, unused_time):
        return self.data.copy()


def kernels(order, duration, frequency):
    nodes = (1 - np.cos(np.pi * np.arange(order + 1) / order)) / 2
    inverse = np.linalg.solve(chebvander(2 * nodes - 1, order), np.eye(order + 1))
    abscissa, weights = roots_legendre(order + 32)
    plain = np.empty((order + 1, order + 1))
    rotating = np.empty_like(plain, dtype=complex)
    for index, upper in enumerate(nodes):
        sample = upper * (abscissa + 1) / 2
        interp = chebvander(2 * sample - 1, order) @ inverse
        measure = weights * duration * upper / 2
        plain[index] = measure @ interp
        rotating[index] = (measure * np.exp(1j * frequency * duration * (upper - sample))) @ interp
    time = duration * nodes
    assert np.max(abs(plain.sum(axis=1) - time)) < 2e-14 * duration
    for power in range(3):
        reference = np.expm1(1j * frequency * time) / (1j * frequency)
        for degree in range(1, power + 1):
            reference = (degree * reference - time**degree) / (1j * frequency)
        scale = duration**(power + 1)
        assert np.max(abs(rotating @ time**power - reference)) < 3e-13 * scale
    return time, plain, rotating


def apply_kernel(matrix, values):
    return (matrix @ values.reshape(len(values), -1)).reshape(values.shape)


def geometry(shell, ell, bend, tilt, tensor, trace, shear):
    radius = shell.r
    grad = shell.diff(bend)
    nrad = np.exp(-2 * ell[0])
    nang = np.exp(-2 * bend[0])
    area = -mul(exp(-2 * ell), square(grad) + 2 * grad / radius)
    area[0] += nrad * np.expm1(2 * (ell[0] - bend[0])) / radius**2
    area[1] += (nang * (4*bend[1] + 6*tensor[1]) + nrad * (2*ell[1] - 6*tilt[1])) / radius**2
    area[1] -= 6*nrad*grad[0]*tilt[1]/radius
    return area, square(trace / 3 - shear / 2)


def readout(shell, state, rate):
    ell, bend, tilt, tensor, trace, shear = state[:6].real
    volume = exp(-ell - 2*bend)
    rest = np.zeros_like(ell)
    transport = np.zeros_like(ell)
    for species in range(3 if shell.flag else 2):
        index = 8 + 2*species
        rest += shell.rho[species] * mul(volume, state[index].real)
        transport += shell.rho[species] * mul(volume, rate[index].real)
    error = 0.
    if not shell.flag:
        logwave, normal = state[14:16]
        amp = shell.rho[-1] * exp(2*logwave.real)
        unit = pair(np.ones_like(shell.r))
        wave = mul(amp, unit - normal.imag)
        div = (shell.lap(logwave, ell, bend, tilt) + square(mul(exp(-ell), shell.diff(logwave)))).imag/shell.mu
        rest += wave
        transport -= mul(amp, div)
        explicit = 2*mul(wave, rate[14].real) - mul(amp, rate[15].imag)
        conserved = mul(trace, wave) - mul(amp, div)
        domain = (shell.r > .65) & (shell.r < 2.1)
        scale = np.max(abs(explicit[:, domain]), axis=1)
        error = np.max(np.max(abs((explicit-conserved)[:, domain]), axis=1) / np.maximum(scale, 1e-280))
    instrument = Window(shell, state, rate, 8)
    perturb = 1e-19
    area, extrinsic = geometry(shell, *(state[:6].real + 1j*perturb*rate[:6].real))
    curvature, motion = instrument.times(area.real, area.imag/perturb)
    extr, expansion = instrument.times(extrinsic.real, extrinsic.imag/perturb)
    compression, ruler = instrument.times(-rest/3, -mul(trace, rest)/3)
    flux = instrument.times(-rest/3, -transport/3)[0]
    return np.asarray([compression, flux, ruler, curvature, extr, motion+expansion]).T, float(error)


def calculation(shell, order, depth):
    safe()
    shell.incident.bank = LaunchStress(shell.incident.bank)
    time, plain, rotating = kernels(order, DURATION, 2*shell.mu)
    initial = shell.initial
    increment = np.zeros((len(time), *initial.shape), dtype=complex)
    results = []
    for layer in range(depth + 1):
        force = np.empty_like(increment)
        values = []
        worst = 0.
        for index, moment in enumerate(time):
            state = initial + increment[index]
            tangent = shell.dynamics(moment, state)
            observed, discrepancy = readout(shell, state, tangent)
            values.append(observed)
            worst = max(worst, discrepancy)
            force[index] = tangent
        quantities = np.einsum("t,tij->ij", plain[-1], values)
        assert np.all(np.isfinite(quantities)) and worst < 1e-10, (layer, worst)
        results.append((quantities, worst))
        if layer != depth:
            safe()
            if not shell.flag:
                force[:, 14] -= shell.mu * increment[:, 15]
                force[:, 15] -= 2j * shell.mu * increment[:, 15]
            increment = apply_kernel(plain, force)
            if not shell.flag:
                extra = apply_kernel(rotating - plain, force[:, 15])
                increment[:, 14] += extra / (2j)
                increment[:, 15] += extra
    return results


def run(order, cold=False):
    if cold:
        pinned("cold.py")
        from cold import prepare
    records = []
    for flag in (0, 1):
        if cold:
            configurations = prepare(flag)
        else:
            configurations = ((seed, np.load(checked(CLOUD, f"launch-h5-off{flag}-seed{seed}.npz"))) for seed in (0, 1, -1))
        for seed, packet in configurations:
            try:
                shell = Stagger(packet, 120, 6, 1 if cold else flag, 1, "stagger")
            finally:
                if hasattr(packet, "close"):
                    packet.close()
            for layer, (amounts, worst) in enumerate(calculation(shell, order, 4)):
                for width, measured in zip(FRACTIONS, amounts):
                    records.append(dict(order=order, seed=seed, flag=flag, layer=layer, width=width,
                                        **dict(zip(FIELDS, measured)), chain_error=worst))
            print("initial source forecast", "cold" if cold else "heavy", order, seed, flag, flush=True)
    save(f"forecast-{'cold' if cold else 'heavy'}-{order}.csv", records)


if __name__ == "__main__":
    run(int(sys.argv[1]), "cold" in sys.argv[2:])
