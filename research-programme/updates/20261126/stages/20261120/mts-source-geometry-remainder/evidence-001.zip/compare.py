"""Compare frozen source forecasts; keep controls and limitations separate."""
from score import rows
from predict import LOCAL, pinned, np, save, FIELDS


def difference(group,seed,width,field):
    selected={(int(row["seed"]),int(row["flag"])):float(row[field]) for row in group if float(row["width"])==width}
    assert len(selected)==6
    return (selected[seed,0]-selected[0,0])-(selected[seed,1]-selected[0,1])


def main():
    reference=rows(pinned("source-attribution.csv"))
    falling=rows(pinned("frozen-stress-test.csv"))
    replay=rows(LOCAL/"remainder-test.csv")
    cases=rows(LOCAL/"first-return-groups.csv")
    environment=rows(LOCAL/"environment-raw.csv")
    raw_transfer=rows(LOCAL/"transfer-raw.csv")
    effects=[];full=[];transfers=[]
    for target in reference:
        if target["stride"]!="1":
            continue
        native,grid,seed=map(int,(target["native"],target["grid"],target["seed"]))
        width=float(target["width"])
        scale=1e6/float(target["newton"])
        if (native,grid)!=(5,120):
            for layer in (0,1,2,3,4):
                part=[row for row in raw_transfer if (int(row["native"]),int(row["grid"]),int(row["layer"]))==(native,grid,layer)]
                actual=float(target["rest_mass_ppm"])+float(target["geometry_ppm"])
                forecast=sum(difference(part,seed,width,key) for key in FIELDS)*scale-1e6
                transfers.append(dict(native=native,grid=grid,seed=seed,width=width,layer=layer,predicted_ppm=forecast,
                                      measured_ppm=actual,error_ppm=forecast-actual,relative_error=forecast/actual-1))
            continue
        increments={}
        for label in ("launch","metric","extrinsic","dust","wave","surroundings","all"):
            subset=[row for row in cases if row["group"]==label]
            increments[label]=np.array([difference(subset,seed,width,key) for key in ("rest","geometry")])*scale
        contributions={key:value-increments["launch"] for key,value in increments.items() if key!="launch"}
        contributions["interaction"]=contributions["all"]-sum(contributions[key] for key in ("metric","extrinsic","dust","wave","surroundings"))
        for key,values in contributions.items():
            effects.append(dict(seed=seed,width=width,channel=key,rest_increment_ppm=values[0],geometry_increment_ppm=values[1],net_increment_ppm=sum(values)))
        model=float(next(row["predicted_ppm"] for row in falling if row["native"]=="5" and row["frame"]=="falling" and int(row["seed"])==seed and float(row["width"])==width))
        other=difference(environment,seed,width,"predicted")*scale
        for layer in (0,1,2,3,4):
            item=next(row for row in replay if (row["order"],int(row["layer"]),float(row["width"]),int(row["seed"]))==("40",layer,width,seed))
            remainder=float(item["remainder_ppm"])
            if layer==1:
                assert abs(sum(increments["all"])-1e6-remainder)<.003
            predicted=remainder+other+model
            measured=float(target["offset_ppm"])
            full.append(dict(seed=seed,width=width,layer=layer,rest_geometry_ppm=remainder,
                             newton_wave_and_dust_ppm=model,launch_environment_ppm=other,measured_environment_ppm=float(target["other_matter_ppm"]),
                             predicted_excess_ppm=predicted,measured_excess_ppm=measured,error_ppm=predicted-measured,
                             relative_excess_error=(predicted-measured)/measured))
    assert len(effects)==28 and len(full)==20 and len(transfers)==40
    save("first-return-effects.csv",effects)
    save("combined-tide.csv",full)
    save("transfer-tests.csv",transfers)
    for label in ("metric","extrinsic","dust","wave","surroundings","interaction","all"):
        print(label,[round(row["net_increment_ppm"],3) for row in effects if row["channel"]==label])
    for layer in (1,4):
        print("complete source",layer,[(round(row["predicted_excess_ppm"],4),round(row["error_ppm"],4)) for row in full if row["layer"]==layer])
        print("transfer maximum error",layer,max(abs(row["error_ppm"]) for row in transfers if row["layer"]==layer))
    print("surroundings (forecast, actual)",[(row["launch_environment_ppm"],row["measured_environment_ppm"]) for row in full if row["layer"]==4])


if __name__=="__main__":
    main()
