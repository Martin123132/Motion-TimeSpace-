"""Transfer the unmodified source expansion to both other saved component-resolution tests."""
from predict import Stagger, CLOUD, checked, np, FRACTIONS, FIELDS, save, calculation


def main():
    rows=[]
    for native,grid in ((4,120),(5,160)):
        for seed in (0,1,-1):
            for flag in (0,1):
                with np.load(checked(CLOUD,f"launch-h{native}-off{flag}-seed{seed}.npz")) as packet:
                    shell=Stagger(packet,grid,6,flag,1,"stagger")
                for layer,(amounts,error) in enumerate(calculation(shell,40,4)):
                    for width,result in zip(FRACTIONS,amounts):
                        rows.append(dict(native=native,grid=grid,layer=layer,width=width,seed=seed,flag=flag,
                                         **dict(zip(FIELDS,result)),chain_error=error))
                print("transfer",native,grid,seed,flag,flush=True)
    save("transfer-raw.csv",rows)


if __name__=="__main__":
    main()
