"""Closed first variation around the prepared launch: no trajectory or fitting."""
from predict import (Stagger, Window, LaunchStress, safe, checked, CLOUD, FRACTIONS, DURATION,
                     kernels, np, geometry, readout, save)


GROUPS = {"launch": (), "metric": tuple(range(4)), "extrinsic": tuple(range(4,8)),
          "dust": tuple(range(8,14)), "wave": (14,15), "surroundings": (17,18,19),
          "all": tuple(range(20))}


def controls(shell):
    radius = shell.r
    ell = np.stack((.04*np.exp(-radius**2/3), .003*radius**2*np.exp(-radius**2/2)))
    bend = np.stack((.02*np.cos(radius), .012*radius**2/(1+radius**2)))
    bendprime = np.stack((-.02*np.sin(radius), .024*radius/(1+radius**2)**2))
    trace = np.stack((.12*np.exp(-radius),.02*radius**2*np.exp(-radius)))
    shear = .2*bend
    area, extr = geometry(shell,ell,bend,ell*0,bend*0,trace,shear)
    def literal(amplitude):
        lograd, logarea, slope, kval, sig = (field[0]+amplitude*field[1] for field in (ell,bend,bendprime,trace,shear))
        gaussian = np.exp(-2*logarea)*(1+6*amplitude*bend[1])/radius**2
        mean = 2*np.exp(-lograd)*(1/radius+slope)
        return np.stack((gaussian-mean**2/4,(kval/3-sig/2)**2))
    inside = (radius>.65)&(radius<2.1)
    mono=literal(0)
    quad=literal(1j*1e-20).imag/1e-20
    for harmonic, expected in enumerate((mono,quad)):
        got=np.stack((area[harmonic],extr[harmonic]))
        discrepancy=np.max(abs(got[:,inside]-expected[:,inside]),axis=1)/np.max(abs(expected[:,inside]),axis=1)
        assert np.all(discrepancy<2e-8),discrepancy
        print("sphere geometry control",harmonic,discrepancy)


def main():
    records=[]
    for flag in (0,1):
        for seed in (0,1,-1):
            safe()
            with np.load(checked(CLOUD, f"launch-h5-off{flag}-seed{seed}.npz")) as packet:
                shell=Stagger(packet,120,6,flag,1,"stagger")
            if seed==0 and flag==0:
                controls(shell)
            shell.incident.bank=LaunchStress(shell.incident.bank)
            initial=shell.initial
            launch=shell.dynamics(0.,initial)
            time,plain,rotating=kernels(40,DURATION,2*shell.mu)
            for label, indices in GROUPS.items():
                values=[]
                for moment in time:
                    advance=launch*moment
                    if not flag:
                        response=np.expm1(2j*shell.mu*moment)/(2j*shell.mu)
                        advance[14]+=(response-moment)*launch[15]/(2j)
                        advance[15]=response*launch[15]
                    state=initial.copy()
                    if indices:
                        state[list(indices)]+=advance[list(indices)]
                    measured,error=readout(shell,state,shell.dynamics(moment,state))
                    assert error<1e-10
                    values.append(measured)
                integrated=np.einsum("t,tij->ij",plain[-1],values)
                for width,terms in zip(FRACTIONS,integrated):
                    records.append(dict(seed=seed,flag=flag,width=width,group=label,
                                        rest=sum(terms[:3]),geometry=sum(terms[3:])))
            print("closed launch source split",seed,flag,flush=True)
    save("first-return-groups.csv",records)


if __name__=="__main__":
    main()
