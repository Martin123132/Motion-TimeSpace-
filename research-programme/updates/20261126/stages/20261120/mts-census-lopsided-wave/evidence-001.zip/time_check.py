from coupled_response import *
from scipy import linalg

def run():
    history="L2M11";folder=ROOT/"mts-lmc-ordinary-centre-recoil-20261119"
    assert parent.sha(folder/"seal.json")=="0c76b4493090e03b0afcd95ae1f886d34e590022217e5114ddca6ce2ef787bcf"
    mid=folder/"time-midpoints-L2M11.npz"
    assert parent.sha(mid)==json.loads((folder/"seal.json").read_bytes())["files"][mid.name]
    results=[]
    for branch in BRANCHES:
        guard()
        with np.load(HERE/f"modes-{branch}-64.npz") as inp:op=dict(inp)
        with np.load(HERE/"ordinary-8.npz") as inp: grid=inp["grid"];bmass,measure=material(inp,op["fraction"])
        row,=[r for r in records(CENSUS,"equilibria") if r["branch"]==branch]
        gamma=float(row["mass_msun"])/bmass
        sigma,meter,number,unit,vel,length=[op[key] for key in ("sigma","meter","number","unit","vel","length")]
        beta=sigma*meter
        ev,rot=linalg.eigh(np.diag(sigma**2)+gamma*number*np.outer(beta,beta),driver="evd")
        def driver(path):
            with np.load(path) as data:
                raw=data["raw"];grad=data["grad"];time=data["time"]
            raw[:,:,0]+=grad[:,None]*grid/np.sqrt(6)
            external=np.einsum("trl,rl->t",raw,measure,optimize=True)/unit
            return time,((2*raw.reshape(len(time),-1)@op["mapping"]+external[:,None]*(number*meter))*sigma)@rot
        coarse,even=driver(bank(history));odd,insert=driver(mid)
        assert np.array_equal(odd,(coarse[:-1]+coarse[1:])/2)
        time=np.empty(len(coarse)+len(odd));time[::2]=coarse;time[1::2]=odd
        force=np.empty((len(time),len(ev)),complex);force[::2]=even;force[1::2]=insert
        def end(src,t):
            pos,_=solve(src,t*vel/length,np.sqrt(ev))
            mode=(pos[-1]@rot.T)/sigma
            return 1000*length*(mode@meter),2*op["probes"]@mode
        original,probes=end(even,coarse);fine,check=end(force,time)
        before,=[r for r in records(HERE,f"center-{branch}-64") if r["history"]==history]
        ref=complex(float(before["centroid_x_pc"]),-float(before["centroid_y_pc"]))
        assert abs(original-ref)<1e-8
        results.append(dict(history=history,branch=branch,coarse_pc=abs(original),fine_pc=abs(fine),
                       vector_relative_change=abs(original/fine-1),force_relative_norm=np.linalg.norm(probes-check)/np.linalg.norm(check),
                       force_absolute_change=max(abs(check-probes)),refined_source_sha256=parent.sha(mid)))
    table("time-16-32",results)

if __name__=="__main__":run()
