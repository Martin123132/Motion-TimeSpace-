import csv
import io
import json
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
CENSUS = ROOT / "mts-foreground-occupation-cross-20261120"
DIPOLE = ROOT / "mts-lmc-differential-centroid-20261119"
sys.dont_write_bytecode = True
sys.path.insert(0, str(CENSUS))
import stage_io as parent
from stage_io import np, ls, UNIT, SERIES
import ring_operator as ro
sys.path.insert(0, str(DIPOLE))
from centroid_run import mapping, solve
import dipole_operator as dip

BRANCHES = ("anchorA","cut1","cut2")
PROBES = ((6.,1.5),(8.3,1.5),(8.4,16.8),(12.5,6.675))
seals = {}
for stage, digest in ((CENSUS,"6bab4f61015a5b4f85a24e6b91b23639f1ca2225af0228086681fce63537fb2b"),(DIPOLE,"962ef822e53f01ebffda859b980242a7dc44e552682569796526c0987977e86b")):
    assert parent.sha(stage/"seal.json")==digest
    seals[stage]=json.loads((stage/"seal.json").read_bytes())["files"]

def guard():
    parent.guard()
    dip.guard()
    assert not (HERE/"STOP-REQUESTED").exists()

def pinned(stage,name):
    guard()
    path=stage/name
    assert parent.sha(path)==seals[stage][name],name
    return path

def table(name,rows):
    stream=io.StringIO(newline="")
    writer=csv.DictWriter(stream,rows[0],lineterminator="\n")
    writer.writeheader()
    writer.writerows(rows)
    put(name+".csv",stream.getvalue().encode())

def packet(name,**arrays):
    stream=io.BytesIO()
    np.savez_compressed(stream,**arrays)
    put(name+".npz",stream.getvalue())

def put(name,data):
    guard()
    path=HERE/name
    if path.exists():
        assert path.read_bytes()==data,name
    else:
        with path.open("xb") as dest: dest.write(data)

def bank(history):
    return pinned(DIPOLE,f"incident/{history}-192-25-28-16.npz")
