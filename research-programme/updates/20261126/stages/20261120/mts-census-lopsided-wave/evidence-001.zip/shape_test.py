from census_io import *
from stream_check import wave_eval
from fields import satellite,field,paths
from itertools import product

def harmonic(force,R,n):
    angle=2*np.pi*np.arange(n)/n
    def site(z):
        return np.column_stack((-R*np.cos(angle),-R*np.sin(angle),np.full(n,z)))
    difference=force(site(1.5))[:,3]-force(site(-1.5))[:,3]
    return np.mean(difference*(np.cos(angle)+1j*np.sin(angle)))*UNIT

def vertical(cols,R,key):
    return (1.5*float(cols["radial"][key])-R*float(cols["polar"][key]))/np.hypot(R,1.5)

def run(refinement=False):
    guard()
    bg=parent.common_wave.Wave(1).bg; normalization=[]; spectral=[]; comparisons=[]
    host_seal="b4108a60a498b169a0c4242bf7f689b3c64722dfccb7641020e99134461b265a"
    assert parent.sha(parent.BHOST/"seal.json")==host_seal
    index=parent.read(parent.BHOST,"host-inputs")
    force_inputs={}
    for history in SERIES:
        sat,place=satellite(history)
        forces={"direct_LMC":lambda site:sat(site-place)}
        for kind in ("multipole","basis"):
            for endpoint in ("initial","final"):
                path=paths(history)[kind,endpoint]
                ref,=[r for r in index if (r["model"],r["epoch"],r["variant"])==(history,endpoint,kind)]
                assert parent.sha(path)==ref["sha256"]
                forces[f"live_{kind}_{endpoint}"]=field(path)
        for label,force in forces.items():
            for radius in (6.,8.3):
                primary=harmonic(force,radius,128);other=harmonic(force,radius,256)
                assert abs(primary-other)<1e-12
                spectral.append(dict(history=history,field=label,R=radius,cosine=other.real,sine=other.imag,
                                     angular_refinement=abs(primary-other)))
                force_inputs[history,label,radius]=other
    for branch in BRANCHES:
        with np.load(pinned(CENSUS,"state-"+branch+".npz")) as p:g=p["ground"]
        with np.load(HERE/f"modes-{branch}-64.npz") as p:
            packed=p["rigid"].reshape(-1,3);length=float(p["length"])
        numeric=[];discrete=[]
        for col,radius in enumerate((6.,8.3)):
            def gradient(step):
                return (wave_eval(bg,g,radius+step,1.5)[1]-wave_eval(bg,g,radius-step,1.5)[1])*UNIT/(2*step)
            first=(4*gradient(.02)-gradient(.04))/3
            second=(4*gradient(.01)-gradient(.02))/3
            slope=-2*(1.5*packed[col,0]-radius*packed[col,1])/np.hypot(radius,1.5)/length
            numeric.append(first);discrete.append(slope)
            normalization.append(dict(branch=branch,R=radius,stationary_gradient=first,refined_gradient=second,
                                      exact_translation_readout=slope,gradient_fractional_change=abs(first/second-1),
                                      representation_difference=abs(first/slope-1)))
        ratio=numeric[0]/numeric[1];mesh_ratio=discrete[0]/discrete[1]
        for keep in ((88,) if refinement else (40,64)):
            signed=parent.read(HERE,f"signed-{branch}-{keep}")
            for history in SERIES:
                near=[]
                for radius in (6.,8.3):
                    cols={r["component"]:r for r in signed if (r["model"],r["history"],float(r["R"]),r["z"])==("MTS",history,radius,"1.5")}
                    near.append([vertical(cols,radius,key) for key in ("wave_m1","translated_profile","deformation","material_shift")])
                near=np.array(near)
                shape,rigid,nonrigid,shift=near[0]-ratio*near[1]
                assert abs(shift)<1e-15 and abs(shape-rigid-nonrigid)<1e-15
                assert abs(near[0,1]-mesh_ratio*near[1,1])<1e-15
                def signal(label):
                    return (force_inputs[history,label,6.]-ratio*force_inputs[history,label,8.3]).real
                main=dict(history=history,branch=branch,keep=keep,inner_weight=1.,outer_weight=-ratio,
                          native_rigid_ratio=mesh_ratio,dark_m1=shape,rigid_leakage=rigid,dark_deformation=nonrigid,
                          inner_wave=near[0,0],outer_wave=near[1,0],direct_LMC=signal("direct_LMC"),
                          total=shape+signal("direct_LMC"),static_reference=signal("direct_LMC"))
                for label in ("basis","multipole"):
                    main[label+"_live_final"]=signal("live_"+label+"_final")
                    main[label+"_live_change"]=main[label+"_live_final"]-signal("live_"+label+"_initial")
                comparisons.append(main)
    table("shape-normalization",normalization);table("source-harmonics",spectral)
    table("shape-predictions-88" if refinement else "shape-predictions",comparisons)

if __name__=="__main__":run(sys.argv[1:]==["--refine"])
