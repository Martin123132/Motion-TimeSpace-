from census_io import *
from scipy.special import roots_legendre
from scipy.interpolate import CubicSpline
from centroid_source import project
from lmc_field import history as get_history,positions

def vertical(radius,rval,rprime):
    height=1.5;dist=np.hypot(radius,height);mu=height/dist;degree=np.arange(1,2*len(rval),2)
    harmon=ro.basis(degree,1,[mu])[0];der=np.array([ro.slope(ell,1,mu) for ell in degree])
    return 2*UNIT*(mu*(rprime@harmon)+(1-mu**2)*(rval@der)/dist)

def run():
    guard()
    weights={r["branch"]:-float(r["outer_weight"]) for r in parent.read(HERE,"shape-predictions-88")}
    native={(r["history"],float(r["R"])):complex(float(r["cosine"]),-float(r["sine"])) for r in parent.read(HERE,"source-harmonics") if r["field"]=="direct_LMC"}
    out=[];panels=[]
    for history in SERIES:
        stamp,knots,forms,traj=get_history(history)
        with np.load(bank(history)) as p:interp=CubicSpline(p["radius"],p["raw"][-1],axis=0)
        values=[]
        for radius,_ in PROBES[:2]:
            rad=np.hypot(radius,1.5);steps=np.array([-.02,-.01,-.005,0.,.005,.01,.02])
            field=project(positions(traj,0.),knots,forms[-1],rad+steps,65,roots_legendre(48))
            a=(field[-1]-field[0])/.04;b=(field[-2]-field[1])/.02;c=(field[-3]-field[2])/.01
            small=vertical(radius,field[3],(4*c-b)/3)
            wide=vertical(radius,field[3],(4*b-a)/3)
            low=vertical(radius,interp(rad),interp(rad,1))
            exact=native[history,radius]
            values.append(np.array([exact,low,small,wide]))
            out.append(dict(history=history,R=radius,native_cos=exact.real,native_sin=-exact.imag,
                           bank_cos=low.real,bank_sin=-low.imag,resolved_cos=small.real,resolved_sin=-small.imag,
                           step_change=abs(small-wide),native_vs_resolved=abs(exact-small)))
        for branch,ratio in weights.items():
            exact,low,small,wide=values[0]-ratio*values[1]
            panels.append(dict(history=history,branch=branch,native=exact.real,bank=low.real,resolved=small.real,
                               native_vs_resolved=abs(exact.real-small.real),step_change=abs(small.real-wide.real)))
    table("direct-vertical-harmonic",out);table("direct-shape-control",panels)

if __name__=="__main__":run()
