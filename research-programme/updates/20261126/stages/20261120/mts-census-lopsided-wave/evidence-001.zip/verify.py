from census_io import *
import hashlib
import math
from collections import Counter

def read(name):
    return parent.read(HERE,name)

def check():
    guard();details={}
    near_terms=[];energies=[];thresholds=[];streams=[];coefficients=[];sources=read("source-angle-radius")
    assert len({(r["branch"],r["history"],r["time"]) for r in sources})==54
    details["max_source_refinement_over_true_relative_force_at_three_snapshots"]=max(float(r["relative_change"]) for r in sources)
    details["source_refinements_above_relative_2e-5"]=sum(float(r["relative_change"])>2e-5 for r in sources)
    details["source_finest_mass_quadrature_above_relative_2e-5"]=sum(float(r["high_quadrature_change"])>2e-5 for r in sources)
    high=read("shape-predictions-88")
    lower=[r for r in read("shape-predictions") if r["keep"]=="64"]
    assert len(high)==len(lower)==18
    refinements=read("time-16-32")
    assert len(refinements)==3 and {r["branch"] for r in refinements}==set(BRANCHES)
    assert all(max(float(r[k]) for k in ("vector_relative_change","force_relative_norm"))<2e-5 for r in refinements)
    details["max_refined_time_vector_change_L2M11"]=max(float(r["vector_relative_change"]) for r in refinements)
    for prior,r in zip(lower,high):
        assert (r["history"],r["branch"])==(prior["history"],prior["branch"])
        coefficients.append(abs(float(r["dark_m1"])/float(prior["dark_m1"])-1))
        assert abs(float(r["rigid_leakage"]))<2e-9 and float(r["dark_m1"])<0
    details["max_64_to_88_shape_relative"]=max(coefficients)
    assert max(coefficients)<2e-5
    direct=read("direct-shape-control")
    exact={(r["branch"],r["history"]):r for r in high}
    assert len(direct)==len(exact)==18
    details["max_direct_model_difference_over_shape"]=max(float(r["native_vs_resolved"])/abs(float(exact[r["branch"],r["history"]]["dark_m1"])) for r in direct)
    details["dark_shape_range"]=[func(float(r["dark_m1"]) for r in high) for func in (min,max)]
    for branch in BRANCHES:
        for keep in (40,64,88):
            data=read(f"signed-{branch}-{keep}");integrity=read(f"checks-{branch}-{keep}")
            assert len(data)==96 and len({tuple(r[k] for k in ("history","model","R","z","component")) for r in data})==96
            for row in data:
                total,lo,hi=[float(row[k]) for k in ("total","low","high")]
                assert (row["inside"]=="True")== (lo<=total<=hi)
                assert row["original_inside"]==row["inside"]
                base,shift,wave=[float(row[k]) for k in ("base_site_minus_point","material_shift","wave_m1")]
                assert abs(total-base-shift-wave)<1e-14
                if row["model"]=="static_NFW":assert wave==float(row["deformation"])==0
                if keep==64 and row["model"]=="MTS":near_terms.append(abs(wave+shift))
            for r in integrity:
                assert all(float(r[k])<2e-5 for k in ("uniform_mode_error","direct_wave_force_error_over_relative_peak",
                             "baryon_order_error_over_relative_peak","material_equation_error_over_peak","physical_internal_error_over_peak"))
        score=Counter((r["history"],r["model"]) for r in data if r["inside"]=="True")
        details["counts_"+branch]={model:sorted({score[h,model] for h in SERIES}) for model in ("MTS","static_NFW")}
        for r in read("vertical-energy-"+branch):
            if r["model"]=="MTS":
                energies.append(float(r["minimum_over_driven"]));assert float(r["free_energy_defect"])<1e-10
                assert np.isclose(float(r["minimum_potential"])/(float(r["driven_potential"])+float(r["driven_kinetic"])),energies[-1])
            else:assert not r["minimum_over_driven"]
        data=read("stream-dynamic-"+branch);assert len(data)==48
        for r in data:
            assert all(math.isfinite(float(r[k])) for k in ("q_min","q_max","strength_min","strength_max"))
            if r["azimuths"]=="256":streams.append(r)
        for r in read("stream-"+branch+"-64"):
            if r["model"]=="MTS":thresholds.append(float(r["delta_strength_in_printed_widths"]))
        for h in SERIES:
            with np.load(HERE/f"endpoint-{branch}-{h}-64.npz") as p:
                assert np.isfinite(p["mode"]).all() and np.isfinite(p["velocity"]).all()
    details["largest_absolute_material_increment_relative_to_point"]=max(near_terms)
    details["energy_lower_bound_over_actual_range"]=[min(energies),max(energies)]
    details["additional_free_energy_necessary_over_driven_range"]=[max(0.,math.sqrt(v)-1.)**2 for v in (min(energies),max(energies))]
    assert len(energies)==18
    details["max_off_plane_dipole_strength_shift_over_printed_width"]=max(thresholds)
    for stream in ("Pal5","GD1"):
        for model in ("MTS","static_NFW"):
            subset=[r for r in streams if (r["stream"],r["model"])==(stream,model)]
            details[stream+"_"+model+"_nearest_strength_in_widths"]=min(float(r["nearest_strength_in_widths"]) for r in subset)
            details[stream+"_"+model+"_max_q_offset_from_band"]=max(max(0.,float(r["q_low"])-float(r["q_min"]),float(r["q_max"])-float(r["q_high"])) for r in subset)
    put("validation.json",(json.dumps(details,sort_keys=True,indent=2)+"\n").encode())
    for stage,files in seals.items():
        for name,expected in files.items():
            assert parent.sha(stage/name)==expected,(stage,name)
    files={p.name:parent.sha(p) for p in sorted(HERE.iterdir()) if p.is_file() and p.name!="seal.json"}
    assert not list(HERE.glob("__pycache__"))
    put("seal.json",(json.dumps({"files":files},indent=2,sort_keys=True)+"\n").encode())
    print(len(files),"stage files verified;",sum(map(len,seals.values())),"parent files verified; seal",parent.sha(HERE/"seal.json"))

if __name__=="__main__":check()
