from census_io import *
from scipy import linalg

def records(folder,name):
    if folder in seals:pinned(folder,name+".csv")
    return parent.read(folder,name)

def material(bankdata,fraction):
    left=("measured_disk","bar_transfer","E3")
    mass=sum(bankdata["mom_"+key][0] for key in left)*(1-fraction)+fraction*bankdata["mom_native"][0]
    response=((1-fraction)*sum(bankdata[key] for key in left)+fraction*bankdata["native"])/mass
    return mass,response

def run(branch,keep):
    guard()
    with np.load(HERE/f"modes-{branch}-{keep}.npz") as p:op=dict(p)
    with np.load(HERE/"ordinary-8.npz") as p: grid=p["grid"];bmass,measure=material(p,op["fraction"])
    with np.load(HERE/"ordinary-4.npz") as p: _,coarse=material(p,op["fraction"])
    row,=[r for r in records(CENSUS,"equilibria") if r["branch"]==branch]
    fraction=float(row["mass_msun"])/bmass
    sigma,meter,number,unit,vel,length=[op[key] for key in ("sigma","meter","number","unit","vel","length")]
    beta=sigma*meter;stiffness=np.diag(sigma**2)+fraction*number*np.outer(beta,beta)
    ev,rot=linalg.eigh(stiffness,driver="evd");freq=np.sqrt(ev)
    assert ev.min()>0 and abs(number*meter@meter-1)<2e-5
    grad_drive=2*(-grid/np.sqrt(6))@op["mapping"].reshape(len(grid),13,-1)[:,0]
    uniform_error=np.linalg.norm(grad_drive-number*meter/unit)/np.linalg.norm(number*meter/unit)
    assert uniform_error<2e-5,uniform_error
    assert abs(measure[:,0]@(-grid/np.sqrt(6))+1)<1e-10
    bands=[r for r in records(CENSUS,"census-limited-forces") if r["foreground"]==branch]
    direct={(r["history"],r["R"],r["z"],r["component"]):float(r["satellite_direct"]) for r in
            records(parent.EXT,"common-sky-k96") if (r["t"],r["occupation"],r["policy"],r["frame"],r["model"])==("1","0","direct_plus_m0","site_minus_point","MTS")}
    stream_refs=[r for r in records(CENSUS,"stream-observables") if r["branch"]==branch]
    outcomes=[];profiles=[];endpoints=[];checks=[]
    for history in SERIES:
        guard()
        with np.load(bank(history)) as p:
            raw=p["raw"];gradient=p["grad"];time=p["time"]
            assert np.array_equal(p["radius"],grid)
        raw[:,:,0]+=gradient[:,None]*grid/np.sqrt(6)
        different=np.einsum("trl,rl->t",raw,measure,optimize=True)/unit
        drive=2*raw.reshape(len(time),-1)@op["mapping"]
        independent=np.einsum("trl,rl->t",raw,op["wire"],optimize=True)/unit
        bary_coarse=np.einsum("trl,rl->t",raw,coarse,optimize=True)/unit
        del raw
        external=-(drive@meter)
        tau=time*vel/length
        def response(stride):
            forcing=drive[::stride]+different[::stride,None]*(number*meter)
            pos,speed=solve((forcing*sigma)@rot,tau[::stride],freq)
            coord=(pos@rot.T)/sigma;centroid=coord@meter
            velocity=((speed[-1]@rot.T)/sigma)@meter
            restore=-(coord@(meter*sigma**2));physical=coord@op["bary"]
            reaction=-fraction*restore
            equation=-((pos*ev)@rot.T/sigma)@meter-forcing[::4]@meter
            test=external[::4*stride]-different[::4*stride]+(1+fraction)*physical
            return coord[-1],centroid,velocity,reaction,restore,physical,float(np.max(abs(test-equation))/max(abs(equation)))
        mode,center,speed,reaction,restore,physical,moment_error=response(1)
        coarse_mode,coarse_center,*_=response(2)
        modes=(2*op["probes"]@mode).reshape(-1,3)
        translated=(2*op["rigid"]*center[-1]).reshape(-1,3)
        smaller=(2*op["probes"]@coarse_mode).reshape(-1,3)
        ref_acc=(different[-1]+reaction[-1])*unit*UNIT
        control_acc=different[-1]*unit*UNIT
        driving_scale=max(abs(independent-different))
        checks.append(dict(history=history,branch=branch,keep=keep,uniform_mode_error=uniform_error,
                           direct_wave_force_error_over_relative_peak=max(abs(independent-external))/driving_scale,
                           baryon_order_error_over_relative_peak=max(abs(different-bary_coarse))/driving_scale,
                           material_equation_error_over_peak=moment_error,physical_internal_error_over_peak=max(abs(restore-physical))/max(abs(restore)),
                           center_time_relative=abs(coarse_center[-1]/center[-1]-1),max_time_force_absolute=max(abs(smaller-modes).ravel()),
                           force_time_relative_norm=np.linalg.norm(smaller-modes)/np.linalg.norm(modes)))
        endpoints.append(dict(history=history,branch=branch,keep=keep,wave_mass=float(row["mass_msun"]),ordinary_mass=bmass,
                            centroid_x_pc=1000*length*center[-1].real,centroid_y_pc=-1000*length*center[-1].imag,
                            centroid_pc=1000*length*abs(center[-1]),peak_pc=1000*length*max(abs(center)),velocity_kms=abs(speed)*vel,
                            relative_external=abs(independent[-1]-different[-1])*unit,point_external=abs(gradient[-1]),
                            restoring=abs(restore[-1])*unit,ordinary_reaction=abs(reaction[-1])*unit))
        for r in bands:
            if r["history"]!=history:continue
            live=r["model"]=="MTS";polar=r["component"]=="polar";R=float(r["R"]);Z=float(r["z"])
            idx=int(R!=6.);col=int(polar);parity=-1 if polar and Z<0 else 1
            proj=(Z if polar else R)/np.hypot(R,Z)
            dpoint=direct[history,r["R"],r["z"],r["component"]]
            base=float(r["total"])-float(r["direct_LMC"])+dpoint
            wave=-parity*modes[idx,col].real if live else 0.
            shift=proj*(ref_acc if live else control_acc).real
            rigid=-parity*translated[idx,col].real if live else 0.
            total=base+wave+shift
            lo,hi=float(r["low"]),float(r["high"])
            outcomes.append(dict(history=history,branch=branch,model=r["model"],R=R,z=Z,component=r["component"],
                                 base_site_minus_point=base,wave_m1=wave,translated_profile=rigid,deformation=wave-rigid,
                                 material_shift=shift,archive_to_point=dpoint-float(r["direct_LMC"]),total=total,
                                 low=lo,high=hi,original_inside=r["inside"],inside=lo<=total<=hi))
        for idx,(R,Z) in enumerate(PROBES[2:],2):
            stream=("Pal5","GD1")[idx-2];rad=np.hypot(R,Z)
            for row_stream in (r for r in stream_refs if r["stream"]==stream):
                live=row_stream["model"]=="MTS"
                radial,polar,azi=modes[idx] if live else np.zeros(3,complex)
                cyl=(R*radial+Z*polar)/rad-(ref_acc if live else control_acc)
                vert=(Z*radial-R*polar)/rad
                qref=float(row_stream["q_reference"])
                strength=(qref**2*cyl+Z/R*vert)*3.15576
                profiles.append(dict(history=history,branch=branch,stream=stream,model=row_stream["model"],
                                     wave_only_radial_bound=abs(radial),wave_only_polar_bound=abs(polar),
                                     wave_only_azimuthal_bound=abs(azi),material_cyl_bound=abs(cyl),vertical_bound=abs(vert),
                                     delta_strength_bound_kms_Myr=abs(strength),
                                     delta_strength_in_printed_widths=abs(strength)/float(row_stream["strength_width"])))
        print(branch,keep,history,"integrated",flush=True)
    assert len(outcomes)==96 and len(profiles)==24 and len(checks)==6
    for fname,rows in (("signed",outcomes),("stream",profiles),("center",endpoints),("checks",checks)):
        table(f"{fname}-{branch}-{keep}",rows)

if __name__=="__main__":
    for branch in sys.argv[2:]:run(branch,int(sys.argv[1]))
