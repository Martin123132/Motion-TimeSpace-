"""Conserve the incident material on the local metric while prescribing its measured spatial stress."""
from polar_cloud import *
from states import response,native
from scipy.integrate import simpson
from tide_rate import field_tides


class LocalSource:
    def __init__(self,bank):
        self.bank=bank;self.local=None
    def at(self,time):
        data=self.bank.at(time)
        if self.local is not None:
            data[0]=self.local[0].real;data[2]=self.local[1].real
        return data
    def samples(self,time,degree):return self.bank.samples(time,degree)


class Conserved(Polar):
    def __init__(self,pkt,rate,edge,flag,project):
        super().__init__(pkt,rate,edge,flag,project)
        bank=self.incident
        init=np.zeros((3,2,len(self.r)),dtype=complex)
        obs=bank.at(0.)
        init[0]=pair(obs[0],obs[2])
        bg=native("cold" if "cold_flag" in pkt else "heavy",int(pkt["cold_flag"]) if "cold_flag" in pkt else flag)
        vol_to_frame=np.exp(-4*self.initial[0,0].real)
        init[1,1]=vol_to_frame*response(bg,self.r,1)("j_other")
        init[2,1]=vol_to_frame*response(bg,self.r)("j_other")/self.r
        self.initial=np.concatenate((self.initial,init),axis=0)
        self.incident=LocalSource(bank)

    def dynamics(self,time,state,details=False):
        self.incident.local=state[17].real
        value=super().dynamics(time,state,details)
        ell,bend,tilt,metric_tensor,trace,radial,cross,tensor=state[:8].real
        en,jr,jt=state[17:].real
        vol=exp(-ell-2*bend);nr=exp(-ell);ar=np.exp(-bend[0])/self.r
        rows=self.incident.at(time);p=pair(rows[1],rows[3])/3
        sr=pair(np.zeros_like(self.r),rows[4]);sc,st=rows[5:7]
        ksurf=mul(nr,2*self.diff(bend)+pair(2/self.r,6*tilt[1]/self.r))
        if details:
            jrad=jr.copy();jang=jt[1].copy()
            for idx in range(3 if self.flag else 2):
                number,potential=state[8+2*idx:10+2*idx].real
                rest=self.rho[idx]*mul(number,vol);pr=mul(nr,self.diff(potential))
                jrad+=mul(rest,pr);jang+=rest[0]*potential[1]*ar
            if not self.flag:
                logwave,z=state[14:16]
                mom=z+trace/(2*self.mu)-1j*pair(np.ones_like(self.r))
                rest=self.rho[-1]*exp(2*logwave.real)
                jrad-=mul(rest,mul(mom.conj(),mul(nr,self.diff(logwave))).real)/self.mu
                jang-=rest[0]*np.real(mom[0].conj()*logwave[1])*ar/self.mu
            normal=mul(nr,self.diff(radial-2*trace/3))+1.5*mul(ksurf,radial)-jrad
            normal[1]-=6*ar*cross[1]
            tangent=(nr[0]*(self.diff(cross[1])+3*(1/self.r+self.diff(bend[0]))*cross[1])
                    +ar*(-radial[1]/2-2*tensor[1]-1.5*radial[0]*ell[1]-2*trace[1]/3)-jang)
            value["mom_r"]=normal;value["mom_theta"]=pair(np.zeros_like(tangent),tangent)
            return value
        divergence=mul(nr,self.diff(jr,odd=True))+mul(ksurf,jr)
        divergence[1]-=6*ar*jt[1]
        value[17]=mul(trace,en+p)+1.5*mul(radial,sr)-divergence
        force=mul(nr,self.diff(p+sr))+1.5*mul(ksurf,sr)
        force[1]-=6*ar*sc
        value[18]=mul(4*trace/3+radial,jr)-force
        value[19,1]=(4*trace[0]/3-radial[0]/2)*jt[1]-(nr[0]*(self.diff(sc)+3*(1/self.r+self.diff(bend[0]))*sc)
                             +ar*(p[1]-sr[1]/2-2*st))
        return value


def main(rate,steps,project,parent):
    result=[];integrals=[]
    for flag in (0,1):
        for seed in (0,1,-1):
            with np.load(HERE/f"launch-h{parent}-off{flag}-seed{seed}.npz") as packet:shell=Conserved(packet,rate,6,flag,project)
            start=shell.initial;change=np.zeros_like(start);dt=2*np.pi/(steps*shell.mu);rates=[]
            for step in range(2*steps+1):
                time=step*dt;state=start+change
                first=shell.dynamics(time,state)
                if step%(steps//16)==0:
                    guard();rates.append(field_tides(shell,time,state,first))
                if step in (0,steps//4,steps,2*steps):
                    data=shell.dynamics(time,state,True)
                    ext=shell.incident.bank.at(time)
                    data["incident_energy_change"]=state[17].real-pair(ext[0],ext[2])
                    data["active_energy"]=state[17].real
                    for radius,_,__,vals in shell.read(state,data):
                        row=dict(seed=seed,flag=flag,radius=radius,cycles=step/steps)
                        for key,val in vals.items():
                            if key.startswith(("gap","exact")):continue
                            row[key]=val.real
                        result.append(row)
                if step==2*steps:break
                second=shell.dynamics(time+dt/2,start+(change+dt*first/2))
                third=shell.dynamics(time+dt/2,start+(change+dt*second/2))
                fourth=shell.dynamics(time+dt,start+(change+dt*third))
                change+=dt*(first+2*second+2*third+fourth)/6
            for label,stride in (("full",1),("half",2)):
                integ=simpson(np.array(rates)[::stride],dx=steps/16*dt*stride,axis=0)
                for idx,r in enumerate(shell.probes):
                    integrals.append(dict(seed=seed,flag=flag,radius=r,rule=label,ricci=integ[0,idx],gauss=integ[1,idx]))
            print("conserved",parent,rate,project,flag,seed,flush=True)
    table(f"conserved-h{parent}-n{rate}-t{steps}-adm{project}.csv",result)
    table(f"conserved-integrals-h{parent}-n{rate}-t{steps}-adm{project}.csv",integrals)


if __name__=="__main__":main(*map(int,sys.argv[1:]))
