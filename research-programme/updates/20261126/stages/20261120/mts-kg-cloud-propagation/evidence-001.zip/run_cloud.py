from cloud_evolve import *
import argparse
from forcing_law import predict,propagate

def run(parent,flag,seed,rate,edge,steps,frozen=False):
    with np.load(HERE/f"launch-h{parent}-off{flag}-seed{seed}.npz") as pkt:
        shell=Shell(pkt,rate,edge,flag)
    start=shell.initial;change=np.zeros_like(start);cycles=(0,.125,.25,.375,.5,.75,1.,1.375,1.75,2.)
    wanted={round(t*steps):t for t in cycles}
    dt=2*np.pi/(shell.mu*steps)
    rows=[];forecasts=[]
    law=predict(shell,start) if not flag and not frozen else None
    if law is not None:
        pack(f"forecast-h{parent}-seed{seed}-n{rate}-L{edge}.npz",r=shell.r,**law)
    for count in range(2*steps+1):
        elapsed=count*dt
        state=start+change
        if count in wanted:
            guard()
            info=shell.dynamics(elapsed,state,True,frozen)
            if law is not None:
                packet=dict(error=info["exact"]-info["graph"],forecast=propagate(law,elapsed,"forcing"),
                    unchanged_operator=propagate(law,elapsed,"changing_wave"))
                for key in ("forcing","changing_operator","changing_curvature","changing_wave","spectator"):packet[key]=law[key]
                for target,pos,shift,data in shell.read(state,packet):
                    rr=dict(cycles=wanted[count],radius=target)
                    for key,val in data.items():
                        rr[key+"_real"]=float(val.real);rr[key+"_imag"]=float(val.imag)
                    forecasts.append(rr)
            for target,pos,shift,data in shell.read(state,info):
                row=dict(cycles=wanted[count],proper_over_a=elapsed,radius=target,r0=pos,shift=shift)
                for key,value in data.items():
                    if key.startswith(("graph","exact")):
                        if flag:continue
                        row[key+"_drift"]=value.real;row[key+"_freq"]=-value.imag
                    else:row[key]=float(value.real)
                rows.append(row)
            if count==0:
                initial_error=[row["tide_quad"]-expected for row,expected in zip(rows,shell.init_tide)]
                print("initial tide differences",np.format_float_scientific(max(abs(v) for v in initial_error)),flush=True)
        if count==2*steps:break
        rhs=lambda off,inc:shell.dynamics(elapsed+off,start+(change+inc),frozen=frozen)
        first=rhs(0,0)
        second=rhs(dt/2,first*dt/2)
        third=rhs(dt/2,second*dt/2)
        fourth=rhs(dt,third*dt)
        change+=dt/6*(first+2*second+2*third+fourth)
        if not np.isfinite(change).all():raise ArithmeticError(("nonfinite",count))
    name=f"h{parent}-off{flag}-seed{seed}-n{rate}-L{edge}-t{steps}-f{int(frozen)}"
    table(name+".csv",rows)
    if law is not None:table("response-"+name+".csv",forecasts)
    pack(name+".npz",delta=change,r=shell.r,mu=shell.mu,dt=dt)
    print("saved",name,flush=True)

if __name__=="__main__":
    a=argparse.ArgumentParser()
    for name in ("parent","flag","seed","rate","edge","steps"):a.add_argument(name,type=int)
    a.add_argument("--frozen",action="store_true")
    run(**vars(a.parse_args()))
