"""Holomorphic real-component graph equations and an independent ruler variation."""
from forcing_law import *


def real_repr(state):
    return np.concatenate((state[:14].real,state[14:15].real,state[14:15].imag))


def ratio(real,imag,base_r,base_i):
    denom=inv(square(base_r)+square(base_i))
    return mul(mul(real,base_r)+mul(imag,base_i),denom),mul(mul(imag,base_r)-mul(real,base_i),denom)


def graph_rhs(shell,time,state,error_r,error_i):
    ell,bend,tilt,tensor,trace,radial,cross,tangential=state[:8]
    comp_r,comp_i=state[14:16]
    rr=shell.r;mu=shell.mu
    er,sp,den,pres,srr,src,stt=shell.incident.at(time)
    active=pair(er+sp,den+pres).astype(state.dtype)
    srad=pair(np.zeros_like(rr),srr).astype(state.dtype)
    soff=src.astype(state.dtype)
    volinv=exp(-ell-2*bend);radinv=exp(-ell)
    result=np.zeros_like(state)
    for j in range(2):
        number,potential=state[8+2*j:10+2*j]
        pn=mul(radinv,shell.diff(potential));pt=potential[1]*np.exp(-bend[0])/rr
        psq=square(pn);root=np.sqrt(1+psq[0]);W=pair(root,psq[1]/(2*root))
        rest=mul(number,volinv)*shell.rho[j]
        active+=mul(rest,W+mul(psq,inv(W)))
        srad+=2/3*mul(mul(rest,psq),inv(W));soff+=rest[0]*pn[0]*pt/root
        flux=mul(mul(number,radinv),mul(pn,inv(W)))
        af=number[0]*(pt*np.exp(-bend[0])-tilt[1]*np.exp(-ell[0])*pn[0])/root
        result[8+2*j]=-shell.diff(flux,odd=True)-2*flux/rr
        result[8+2*j,1]+=6*af/rr
        result[9+2*j]=-mul(psq,inv(W+pair(np.ones_like(rr))))
    del_r=shell.lap(comp_r,ell,bend,tilt);del_i=shell.lap(comp_i,ell,bend,tilt)
    bre,bim=ratio(del_r,del_i,comp_r,comp_i)
    rate_r=trace/(2*mu)-bim/(2*mu**2)+error_r
    amplitude=shell.rho[-1]*(square(comp_r)+square(comp_i))
    c_base=square(trace)/3+1.5*square(radial)+active/2
    dk=c_base+amplitude/2
    one=pair(np.ones_like(rr))
    for unused in range(4):
        rate_i=(bre-dk/2+square(trace)/4)/(2*mu**2)+error_i
        dk=c_base+mul(amplitude,2*(square(rate_r)+square(rate_i-one))-one)/2
    result[14]=mu*(mul(rate_r,comp_r)-mul(rate_i,comp_i))
    result[15]=mu*(mul(rate_r,comp_i)+mul(rate_i,comp_r))
    for field in (comp_r,comp_i):
        normal=mul(radinv,shell.diff(field))/mu
        polar=field[1]*np.exp(-bend[0])/(mu*rr)
        srad+=(2/3)*shell.rho[-1]*square(normal)
        soff+=shell.rho[-1]*normal[0]*polar
    ric,rc,rt,scalar=shell.ricci(ell,bend,tilt,tensor)
    result[0]=-trace/3-radial;result[1]=-trace/3+radial/2
    result[2,1]=-2*np.exp(ell[0]-bend[0])*cross[1];result[3]=-2*tangential
    result[4]=dk;result[5]=ric+mul(trace,radial)-srad
    result[6,1]=rc+(trace[0]-1.5*radial[0])*cross[1]-soff
    result[7,1]=rt+trace[0]*tangential[1]-stt
    tide=-ric-mul(trace,radial)/3+square(radial)/2+srad
    return result,tide


def ruler_variation(shell,state,dstate,tide,dtide):
    nodes=np.r_[-shell.r[:8][::-1],shell.r]
    def spline(val):return CubicSpline(nodes,np.concatenate((val[...,:8][...,::-1],val),axis=-1),axis=-1)
    scale=exp(state[0])
    metric=spline(scale);delta_metric=spline(mul(scale,dstate[0]))
    lengths=metric.antiderivative();dlens=delta_metric.antiderivative()
    curve=spline(tide);dcurve=spline(dtide)
    out=[]
    for target in shell.probes:
        pos=brentq(lambda t:(lengths(t)-lengths(0.))[0]-target,target-.02,target+.02)
        l0,l2=metric(pos);s=-(lengths(pos)-lengths(0.))[1]/l0
        delta_len=dlens(pos)-dlens(0.)
        dr=-delta_len[0]/l0
        dshift=-(delta_len[1]+l2*dr+s*(delta_metric(pos)[0]+metric(pos,1)[0]*dr))/l0
        direct=dcurve(pos)[1]
        moved=dr*curve(pos,1)[1]+dshift*curve(pos,1)[0]+s*(dcurve(pos,1)[0]+dr*curve(pos,2)[0])
        out.append((target,direct,moved,direct+moved))
    return out
