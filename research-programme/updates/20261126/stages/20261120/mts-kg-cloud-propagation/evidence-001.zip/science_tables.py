from cloud_owner import *
from functools import lru_cache

@lru_cache(maxsize=None)
def read(name):
    with (HERE/name).open(newline="") as stream:return list(csv.DictReader(stream))
def find(name,rad):
    return [r for r in read(name) if float(r["radius"])==rad]
def obs(name,rad,key):
    return np.array([float(r[key]) for r in find(name,rad)])
def complex_obs(name,rad,key):
    return obs(name,rad,key+"_real")+1j*obs(name,rad,key+"_imag")
def panel(parent,flag,seed,rate,edge,steps,frozen=0):
    return f"h{parent}-off{flag}-seed{seed}-n{rate}-L{edge}-t{steps}-f{frozen}.csv"
def magnitude(arr):return float(np.max(abs(arr)))
def fractional(a,b):return magnitude(a-b)/max(1e-80,magnitude(b))


def main():
    rows=[];signed=[];forecast=[];tests=[];ablate=[]
    probes=(.676538827,1.35307765,2.7061553)
    configs=((4,80,6,192),(5,40,6,96),(5,80,6,96),(5,80,6,192),(5,80,8,192),(5,120,6,192),(5,80,6,384))
    for parent,rate,edge,steps in configs:
        for seed in (0,1,-1):
            for r in probes:
                name=panel(parent,0,seed,rate,edge,steps)
                resp="response-"+name
                for part in ("sphere","quad"):
                    measured=complex_obs(resp,r,"error_"+part)
                    predicted=complex_obs(resp,r,"forecast_"+part)
                    stationary=complex_obs(resp,r,"unchanged_operator_"+part)
                    gdrift=obs(name,r,"graph_"+part+"_drift")
                    gfreq=obs(name,r,"graph_"+part+"_freq")
                    values=find(name,r)
                    ii=int(np.argmax(abs(measured)))
                    forecast.append(dict(parent=parent,rate=rate,edge=edge,steps=steps,seed=seed,radius=r,part=part,
                           peak=magnitude(measured),cycle_at_peak=values[ii]["cycles"],max_drift=magnitude(measured.real),
                           max_frequency=magnitude(measured.imag),predicted_error_on_peak=fractional(predicted,measured),
                           dropping_metric_rate_on_peak=fractional(stationary,measured),terminal_error=abs(measured[-1]-predicted[-1]),
                           peak_drift_on_graph=magnitude(measured.real)/max(1e-80,magnitude(gdrift)),
                           peak_freq_on_graph=magnitude(measured.imag)/max(1e-80,magnitude(gfreq))))
                    if (parent,rate,edge,steps)==(5,80,6,192):
                        alt=panel(parent,0,seed,rate,edge,steps,1)
                        d=obs(name,r,"exact_"+part+"_drift")-obs(alt,r,"exact_"+part+"_drift")
                        f=obs(name,r,"exact_"+part+"_freq")-obs(alt,r,"exact_"+part+"_freq")
                        ablate.append(dict(seed=seed,radius=r,part=part,max_dynamic_minus_frozen_drift=magnitude(d),
                             max_dynamic_minus_frozen_frequency=magnitude(f),forcing=abs(complex_obs(resp,r,"forcing_"+part)[0]),
                             spatial_operator_rate=abs(complex_obs(resp,r,"changing_operator_"+part)[0]),
                             curvature_rate=abs(complex_obs(resp,r,"changing_curvature_"+part)[0]),
                             spectator_part=abs(complex_obs(resp,r,"spectator_"+part)[0])))
                if not seed:continue
                def value(flag,sign,key):
                    return obs(panel(parent,flag,sign,rate,edge,steps),r,key)
                host=lambda flag,key:value(flag,seed,key)-value(flag,0,key)
                switched=host(0,"tide_quad")-host(1,"tide_quad")
                hamiltonian=host(0,"ham_quad")-host(1,"ham_quad")
                for row,val,ham in zip(find(name,r),switched,hamiltonian):
                    signed.append(dict(parent=parent,rate=rate,edge=edge,steps=steps,seed=seed,radius=r,
                                    cycles=row["cycles"],host_switch=val,change_since_start=val-switched[0],constraint=ham))
                for flag in (0,1):
                    v=host(flag,"tide_quad");c=host(flag,"ham_quad")
                    rows.append(dict(parent=parent,rate=rate,edge=edge,steps=steps,seed=seed,radius=r,flag=flag,
                                host_at_start=v[0],host_at_end=v[-1],evolution=v[-1]-v[0],
                                initial_hamiltonian=c[0],final_hamiltonian=c[-1]))
    for seed in (0,1,-1):
        for r in probes:
            for label,config,ref in (("radial40_80",(5,40,6,96),(5,80,6,96)),("radial80_120",(5,80,6,192),(5,120,6,192)),
                 ("time96_192",(5,80,6,96),(5,80,6,192)),("time192_384",(5,80,6,192),(5,80,6,384)),
                 ("buffer6_8",(5,80,6,192),(5,80,8,192)),("native4_5",(4,80,6,192),(5,80,6,192))):
                def dataset(c,part):
                    parent,rate,edge,steps=c
                    return complex_obs("response-"+panel(parent,0,seed,rate,edge,steps),r,"error_"+part)
                def total(c):
                    sel=[x["host_switch"] for x in signed if (x["parent"],x["rate"],x["edge"],x["steps"])==c and x["seed"]==seed and x["radius"]==r]
                    return np.array(sel)
                for quantity,a,b in [("graph_"+part,dataset(config,part),dataset(ref,part)) for part in ("sphere","quad")]+(
                    [("signed_tide",total(config),total(ref)),("signed_evolution",total(config)-total(config)[0],total(ref)-total(ref)[0])] if seed else []):
                    delta=fractional(a,b)
                    tests.append(dict(seed=seed,radius=r,test=label,quantity=quantity,max_abs=magnitude(a-b),on_peak=delta,
                                pass_20ppm=delta<=2e-5))
    for name,data in (("signed-tides",signed),("host-forces",rows),("graph-forecast",forecast),("geometry-ablation",ablate),("resolution",tests)):
        table(name+".csv",data)


if __name__=="__main__":main()
