from cloud_owner import *
from scipy.interpolate import CubicSpline
from scipy.special import spherical_jn


class Incident:
    def __init__(self,packet,radius,flag,interpolate):
        trace=(HERE/f"trace-cold-off{int(packet['cold_flag'])}.npz") if "cold_flag" in packet else source(f"trace-heavy-off{flag}.npz")
        with np.load(trace) as bank:
            time=bank["dt"];wave=bank["k"][:,None]
            field=dict(zip(bank["names"].tolist(),bank["values"].transpose(2,0,1)))
        a=field["a"];h=field["H"];p=field["P"];energy=field["R"];enthalpy=energy+p
        deriv=lambda v:CubicSpline(time,v,axis=-1)(time,1)
        current=field["Q"]+enthalpy*field["sigma"]
        psi=(field["dsigma"]+h*field["sigma"])/wave
        alpha=field["sigma"]/wave
        offset=alpha[:,0]-(1.5*current/wave/(wave**2+1.5*enthalpy))[:,0]
        dp_new=deriv(current)/wave+4*h*(current/(2*wave)-h*psi)+2*(2*h*h-enthalpy/2)*psi+2*field["Pi"]/3
        dp_sync=dp_new-(deriv(p)-2*h*p)*alpha
        spectator_d=field["D"]-field["Rc"]*field["dc"]-field["Rb"]*field["db"]-field["mts_drho_h"]
        spectator_p=dp_sync-field["mts_dp_h"]
        dispersal=(a[:,:1]/a)**2
        shift=offset[:,None]*a[:,:1]/a
        mass_sum=packet["rho"].sum()*a[:,:1]/a
        eb=energy-mass_sum
        sx=(spectator_d+(deriv(eb)-2*h*eb)*shift)*dispersal
        sp=3*(spectator_p+(deriv(p)-2*h*p)*shift)*dispersal
        weighted=packet["weight"][:,None]
        arg=wave*radius
        bessel=spherical_jn(2,arg)
        radial=wave*spherical_jn(2,arg,derivative=True)
        radial2=(6/radius**2-wave**2)*bessel-2*radial/radius
        stress=(field["Pi"]/wave**2)*dispersal
        proj=lambda value,kernel:(value*weighted).T@kernel
        def anchored(array,initial):return initial+(array-array[:1])
        dense=[(eb*dispersal).mean(axis=0)[:,None]*np.ones_like(radius),
               (3*p*dispersal).mean(axis=0)[:,None]*np.ones_like(radius),
               anchored(proj(sx,bessel),interpolate(packet["e0"])),
               anchored(proj(sp,bessel),interpolate(packet["s0"])),
               anchored(proj(stress,(2/3)*(radial2-radial/radius)+2*bessel/radius**2),interpolate(packet["native_stress"])),
               anchored(proj(stress,radial/radius-bessel/radius**2),interpolate(packet["native_cross"])/(-1.5)),
               proj(stress,bessel/radius**2)]
        dense[0]=anchored(dense[0],float(packet["R"]-packet["rho"].sum()))
        dense[1]=anchored(dense[1],3*float(packet["P"]))
        ratio=np.mean(a/a[:,:1],axis=0)
        proper=CubicSpline(time,ratio).antiderivative()(time)
        self.samples=CubicSpline(proper,np.stack(dense,axis=1),axis=0)
    def at(self,elapsed):return self.samples(elapsed)
