from science_tables import *
import re


def combined(block,seed,field):
    idx={(int(r["seed"]),int(r["flag"])):float(r[field]) for r in block}
    return (idx[seed,0]-idx[0,0])-(idx[seed,1]-idx[0,1])


def main():
    rows=[];constraints=[];tides=[]
    for pattern,mode in (("tidal-integral-h*.csv","prescribed"),("conserved-integrals-h*.csv","conserved")):
        for path in sorted(HERE.glob(pattern)):
            parent,rate,steps,project=map(int,re.findall(r"\d+",path.name))
            for radius in (.676538827,1.35307765,2.7061553):
                rr=find(path.name,radius)
                for rule in ("full","half"):
                    for method in ("ricci","gauss"):
                        array=[r for r in rr if r["rule"]==rule and r.get("method",method)==method]
                        for seed in (1,-1):
                            delta=combined(array,seed,"integral" if mode=="prescribed" else method)
                            rows.append(dict(environment=mode,parent=parent,rate=rate,steps=steps,project=project,
                                             radius=radius,rule=rule,method=method,seed=seed,integrated_tide_change=delta))
    for path in sorted(HERE.glob("conserved-h*.csv")):
        parent,rate,steps,project=map(int,re.findall(r"\d+",path.name))
        for radius in (.676538827,1.35307765,2.7061553):
            rr=find(path.name,radius)
            for cycle in (0.,2.):
                subset=[r for r in rr if float(r["cycles"])==cycle]
                for seed in (1,-1):
                    for name in ("ham","mom_r","mom_theta","incident_energy_change"):
                        val=combined(subset,seed,name+"_quad")
                        constraints.append(dict(parent=parent,rate=rate,steps=steps,project=project,seed=seed,radius=radius,
                                            cycles=cycle,field=name,host_switch=val))
                    tides.append(dict(parent=parent,rate=rate,steps=steps,project=project,seed=seed,radius=radius,
                                  cycles=cycle,ricci=combined(subset,seed,"tide_quad"),gauss=combined(subset,seed,"tide_first_derivative_quad")))
    table("evolution-balance.csv",rows);table("constraint-transport.csv",constraints);table("conserved-tides.csv",tides)

if __name__=="__main__":main()
