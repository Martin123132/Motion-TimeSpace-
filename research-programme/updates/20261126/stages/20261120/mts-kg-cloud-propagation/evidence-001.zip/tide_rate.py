"""Integrate the rate of the observable rather than subtracting two final curvatures."""
from polar_cloud import *
from graph_response import ruler_variation
from scipy.integrate import simpson


def field_tides(shell,time,state,rhs):
    perturb=1e-19
    arr=state[:14].real+1j*perturb*rhs[:14].real
    ell,bend,tilt,tensor,trace,radial=arr[:6]
    logreal=state[14].real+1j*perturb*rhs[14].real
    logimag=state[14].imag+1j*perturb*rhs[14].imag
    zen=state[15].real+1j*perturb*rhs[15].real;zim=state[15].imag+1j*perturb*rhs[15].imag
    incident=shell.incident.at(time)+1j*perturb*shell.incident.samples(time,1)
    energy=pair(incident[0],incident[2]);sr=pair(np.zeros_like(shell.r),incident[4])
    if len(state)==20:energy=state[17].real+1j*perturb*rhs[17].real
    one=pair(np.ones_like(shell.r));volume=exp(-ell-2*bend);normal=exp(-ell)
    for j in range(3 if shell.flag else 2):
        number,pot=arr[8+2*j:10+2*j]
        g2=square(mul(normal,shell.diff(pot)));root=np.sqrt(1+g2[0]);gamma=pair(root,g2[1]/(2*root))
        mass=shell.rho[j]*mul(number,volume)
        energy+=mul(mass,gamma);sr+=(2/3)*mul(mass,mul(g2,inv(gamma)))
    if not shell.flag:
        mass=shell.rho[-1]*exp(2*logreal)
        kin=square(zen+trace/(2*shell.mu))+square(zim-one)
        grad=(square(mul(normal,shell.diff(logreal)))+square(mul(normal,shell.diff(logimag))))/shell.mu**2
        energy+=mul(mass,one+kin+grad)/2;sr+=2/3*mul(mass,grad)
    ric0=shell.ricci(ell,bend,tilt,tensor)[0]
    e0=np.exp(-2*ell[0]);eb=np.exp(-2*bend[0]);bp=shell.diff(bend);r=shell.r;v=tilt[1]
    spatial=-2*mul(exp(-2*ell),square(bp)+2*bp/r)
    spatial[0]+=2*e0*np.expm1(2*(ell[0]-bend[0]))/r**2
    spatial[1]+=(eb*(8*bend[1]+12*tensor[1])+e0*(4*ell[1]-12*v))/r**2-12*e0*bp[0]*v/r
    gauss=((2*energy-2/3*square(trace)+1.5*square(radial))/3-spatial)/2
    result=[]
    for ric in (ric0,gauss):
        tide=sr-mul(trace,radial)/3+square(radial)/2-ric
        result.append([v[-1] for v in ruler_variation(shell,arr.real,rhs[:14].real,tide.real,tide.imag/perturb)])
    return result


def main(rate,steps,project,parent):
    rows=[]
    for seed in (0,1,-1):
        for flag in (0,1):
            with np.load(HERE/f"launch-h{parent}-off{flag}-seed{seed}.npz") as pkt:
                solver=Polar(pkt,rate,6,flag,project)
            start=solver.initial;change=np.zeros_like(start);dt=2*np.pi/(steps*solver.mu);sample=[]
            for step in range(2*steps+1):
                time=step*dt;state=start+change
                first=solver.dynamics(time,state)
                if step%(steps//16)==0:
                    guard();sample.append(field_tides(solver,time,state,first))
                if step==2*steps:break
                second=solver.dynamics(time+dt/2,start+(change+dt*first/2))
                third=solver.dynamics(time+dt/2,start+(change+dt*second/2))
                fourth=solver.dynamics(time+dt,start+(change+dt*third))
                change+=dt*(first+2*second+2*third+fourth)/6
            sample=np.array(sample)
            for rule,stride in (("full",1),("half",2),("quarter",4)):
                integrated=simpson(sample[::stride],dx=steps/16*dt*stride,axis=0)
                for k,label in enumerate(("ricci","gauss")):
                    for j,rad in enumerate(solver.probes):
                        rows.append(dict(seed=seed,flag=flag,radius=rad,method=label,rule=rule,
                            launch_rate=sample[0,k,j],final_rate=sample[-1,k,j],integral=integrated[k,j]))
            print("rate integral",parent,rate,steps,project,seed,flag,flush=True)
    table(f"tidal-integral-h{parent}-n{rate}-t{steps}-adm{project}.csv",rows)

if __name__=="__main__":main(*map(int,sys.argv[1:]))
