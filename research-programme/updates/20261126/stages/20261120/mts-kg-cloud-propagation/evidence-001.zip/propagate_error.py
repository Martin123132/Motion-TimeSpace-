from graph_response import *
import argparse
from scipy.interpolate import CubicSpline


def main(parent,seed,rate,steps,edge=6):
    with np.load(HERE/f"launch-h{parent}-off0-seed{seed}.npz") as packet:
        shell=Shell(packet,rate,edge,0)
    state=shell.initial;law=predict(shell,state);initial=real_repr(state)
    change=np.zeros_like(state);partials=np.zeros((2,)+initial.shape)
    dt=2*np.pi/(shell.mu*steps)
    wanted={round(t*steps) for t in (0,.125,.25,.375,.5,.75,1,1.375,1.75,2)}
    rows=[];parity=[]
    def rates(time,full,partials,observing=False):
        rhs,data=shell.dynamics(time,full,"both")
        base=real_repr(full)
        error=data["exact"]-data["graph"]
        homogeneous=mul(exp(law["omega"]*time),law["initial"])
        integrated=propagate(law,time,"forcing")
        changes=[];drc=[]
        for idx,target in enumerate((homogeneous,integrated)):
            direction=error-target
            perturbed=base+1j*partials[idx]
            reduced,tidal=graph_rhs(shell,time,perturbed,error.real+1j*direction.real,error.imag+1j*direction.imag)
            changes.append(reduced.imag)
            if observing:
                drc.append(ruler_variation(shell,base,partials[idx],tidal.real,tidal.imag))
                reference=real_repr(rhs);domain=(shell.r>.5)&(shell.r<4.)
                delta=(reduced.real-reference)[...,domain]
                parity.append(dict(cycles=time*shell.mu/(2*np.pi),kind=idx,max_geometry=np.max(abs(delta[:8])),
                            max_dust=np.max(abs(delta[8:14])),max_scalar=np.max(abs(delta[14:])),
                            tide=np.max(abs(tidal.real-data["tide"])[...,domain])))
        if observing:return drc
        return rhs,np.asarray(changes)
    for step in range(2*steps+1):
        time=step*dt
        if step in wanted:
            guard()
            output=rates(time,state+change,partials,True)
            for name,arr in zip(("instant_matched","transport_forecast"),output):
                for target,value,ruler,full in arr:
                    rows.append(dict(cycles=step/steps,mode=name,radius=target,coordinate=value,ruler=ruler,total=full))
        if step==2*steps:break
        first,one=rates(time,state+change,partials)
        second,two=rates(time+dt/2,state+(change+dt/2*first),partials+dt/2*one)
        third,three=rates(time+dt/2,state+(change+dt/2*second),partials+dt/2*two)
        fourth,four=rates(time+dt,state+(change+dt*third),partials+dt*three)
        change+=dt/6*(first+2*second+2*third+fourth)
        partials+=dt/6*(one+2*two+2*three+four)
    name=f"h{parent}-seed{seed}-n{rate}-L{edge}-t{steps}"
    path=HERE/f"h{parent}-off0-seed{seed}-n{rate}-L{edge}-t{steps}-f0.npz"
    with np.load(path) as saved:np.testing.assert_array_equal(change,saved["delta"])
    table("error-tide-"+name+".csv",rows);table("real-equations-"+name+".csv",parity)
    pack("error-state-"+name+".npz",sensitivity=partials)
    print("two closure transports",name,flush=True)

if __name__=="__main__":main(*map(int,sys.argv[1:]))
