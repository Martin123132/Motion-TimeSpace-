from cloud_owner import *
from states import BalancedNative,SPAN,DLOG,input_pack,Slice,angular
from pressure import pressure
from normal_graph import homogeneous,normal_data,Sources
from coupled_readout import FullRuler
from proper_probe import PROBES


def main(rate):
    sim=BalancedNative("heavy",120,120*rate,False,"native36",SPAN*DLOG)
    for flag in (0,1):
        ref,press,unused=pressure(flag);mu=ref["a"]*sim.patch.p.mass
        mean=homogeneous(ref,ref["rh"][sim.patch.j],mu,press)
        for seed in (0,1,-1):
            state,grid,samples,supply=input_pack(sim,rate,seed,flag,ref,press)
            obj=Slice(sim,grid,ref,samples,state,flag,not flag,"fixed",0,"matched")
            hub=ref["H"]
            if flag==0:
                hub=mean["hubble"];graph,fields=normal_data(obj,supply,mean)
                for count in range(8):
                    hook=Sources(grid,fields,samples[0]["other"])
                    obj=Slice(sim,grid,{**ref,"H":hub},samples,state,flag,True,"fixed",0,"matched",hook)
                    new_graph,new=normal_data(obj,supply,mean,graph)
                    err=max(np.max(abs(new[key]-value))/max(1e-50,np.max(abs(new[key]))) for key,value in fields.items())
                    if err<2e-9:break
                    graph,fields=new_graph,new
                else:raise ValueError("outer solve")
                delta,drift=[pair(val.real,angular(val)) for val in graph]
            else:
                delta=drift=pair(np.zeros_like(grid.points))
            mono=grid.evaluate(obj.state[0])[0];qvel=grid.evaluate(obj.state[2])[0][flag]
            phases=np.stack([pair(first,second) for first,second in zip(mono[1]/grid.points,samples[0]["V"]+qvel)])
            potentials=pair(grid.evaluate(obj.f0)[0],grid.evaluate(obj.f2)[0])
            numbers=np.stack([pair(a,b) for a,b in zip(obj.m["n"],obj.m["D"])])
            slopes=np.stack([pair(a,b) for a,b in zip(obj.m["p"],obj.m["P"])])
            ruler=FullRuler(obj);readouts=[ruler.read(r) for r in PROBES[:3]]
            cutoff=grid.points[:,0]<16
            arrays=dict(r=grid.points[cutoff],t=grid.t,h=grid.h,n=numbers[...,cutoff,:],
                v=phases[...,cutoff,:],slope=slopes[...,cutoff,:],chi=potentials[...,cutoff,:],
                b=pair(obj.b0,obj.b2)[...,cutoff,:],c=obj.c2[cutoff],d=obj.d2[cutoff],
                delta=delta[...,cutoff,:],drift=drift[...,cutoff,:],
                rho=ref["rh"],mu=mu,H=hub,a=ref["a"],R=ref["R"],P=press,k=ref["k"],weight=ref["w"],
                e0=samples[0]["other"][cutoff],s0=supply["spec2"][cutoff],
                native_stress=samples[0]["stress"][cutoff],native_cross=samples[0]["stress_cross"][cutoff],
                probes=PROBES[:3],initial_tide=[item["ruler_tide"] for item in readouts],
                initial_monopole=[item["monopole_tide"] for item in readouts])
            pack(f"launch-h{rate}-off{flag}-seed{seed}.npz",**arrays)
        print("geometry and momenta",rate,flag,flush=True)


if __name__=="__main__":main(int(sys.argv[1]))
