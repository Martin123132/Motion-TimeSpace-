from science_tables import *
from replay_cloud import jobs
import re


def verify():
    assert all(sha(PREV/name)==expected for name,expected in catalog.items())
    prevseal=json.loads((PREV/"seal.json").read_bytes())
    cdir=HERE.parent/"mts-signed-cmc-constraints-20261120"
    assert sha(cdir/"seal.json")==prevseal["parent_seal"]
    parent=json.loads((cdir/"seal.json").read_bytes())["files"]
    assert all(sha(cdir/name)==expected for name,expected in parent.items())
    for p in HERE.glob("*.npz"):
        with np.load(p,allow_pickle=False) as packet:
            for key in packet.files:
                arr=packet[key]
                if arr.dtype.kind in "fc":assert np.isfinite(arr).all(),(p.name,key)
    counts={}
    for p in HERE.glob("*.csv"):
        rows=read(p.name);assert rows and all(None not in r and None not in r.values() for r in rows),p.name
        assert not any(str(v).lower() in ("nan","-inf","inf") for row in rows for v in row.values()),p.name
        counts[p.name]=len(rows)
    for cfg in jobs("all"):
        if cfg[0]=="run_cloud.py":
            _,h,flag,seed,n,L,t,*extra=cfg
            name=panel(h,flag,seed,n,L,t,int(bool(extra)))
            assert counts[name]==30 and (HERE/name.replace(".csv",".npz")).exists()
            if not (flag or extra):assert counts["response-"+name]==30
        if cfg[0]=="polar_cloud.py":
            _,seed,n,t,flag,a=cfg
            assert counts[f"polar-h5-seed{seed}-n{n}-t{t}-off{flag}-adm{a}.csv"]==30
    assert (HERE/"cold-control-off0.csv").read_bytes()==(HERE/"cold-control-off1.csv").read_bytes()
    assert counts["cold-control-off0.csv"]==45
    with np.load(HERE/"trace-cold-off0.npz") as a,np.load(HERE/"trace-cold-off1.npz") as b:
        for key in a.files:np.testing.assert_array_equal(a[key],b[key])
    tol=2e-5;center=1.35307765
    wave=[r for r in find("log-forecast-accuracy.csv",center) if int(r["seed"]) and r["rate"]=="80" and r["steps"]=="384"]
    assert len(wave)==4 and all(float(r["full_error_on_peak"])<tol and float(r["fixed_metric_error"])>.8 for r in wave)
    sphere=next(r for r in find("log-forecast-accuracy.csv",center) if r["seed"]=="0" and r["part"]=="sphere" and r["steps"]=="384")
    assert float(sphere["full_error_on_peak"])>tol
    checks=[r for r in find("secular-precision.csv",center)]
    assert len(checks)==14
    for r in checks:
        if r["test"] in ("environment","radial_refinement","time_refinement","time_integral"):assert r["pass_20ppm"]=="True",r
        if r["test"] in ("native_refinement","curvature_readout"):assert r["pass_20ppm"]=="False",r
    for r in read("exact-incident-stress.csv"):
        if int(r["rate"])>=40:assert max(float(r[k]) for k in ("state_error_on_peak","rate_error_on_peak"))<tol
    for r in read("exact-ltb.csv"):
        if int(r["rate"])>=40:assert float(r["max_tide_error_on_peak"])<tol
    flux=[abs(float(r["relative"])) for r in find("symplectic-current.csv",center) if r["seed"]!="0" and r["rate"]=="80"]
    assert len(flux)==4 and max(flux)<tol
    zero=next(r for r in find("symplectic-current.csv",center) if r["seed"]=="0" and r["part"]=="sphere" and r["rate"]=="80")
    assert abs(float(zero["delta_number"]))<1e-16
    for method in ("instant_matched","transport_forecast"):
        vals=[r for r in find("closure-tidal-change.csv",center) if r["mode"]==method and r["rate"]=="80" and r["steps"]=="384"]
        assert len(vals)==20 and max(abs(float(r["on_host_switch"])) for r in vals)<2e-12
    assert any(r["pass_20ppm"]=="False" for r in find("closure-tidal-precision.csv",center))
    assert counts["rejected-finite-original-seed1.csv"]>0
    fit=find("amplified-family-check.csv",center);assert len(fit)==4 and all(float(r["peak_disagreement"])<.01 for r in fit)
    assert all(float(r["on_peak"])==0 for r in read("resolution.csv") if r["test"]=="buffer6_8")
    for row in read("constraint-transport.csv"):
        if row["field"]=="incident_energy_change" and row["cycles"]=="0.0":assert float(row["host_switch"])==0.
    for doc in ("DERIVATION.md","RESULTS.md","REPLAY.md"):
        for ref in re.findall(r"\]\(([^)]+)\)",(HERE/doc).read_text(encoding="utf8")):
            assert ref.startswith("https://") or (HERE/ref).is_file(),ref
    assert not list(HERE.glob("*.partial")) and not (HERE/"__pycache__").exists()
    registry={p.name:sha(p) for p in sorted(HERE.iterdir()) if p.is_file() and p.name!="seal.json"}
    out=dict(files=registry,rows=counts,predecessor=PIN,parent_files=len(catalog),grandparent_files=len(parent),
        verified_numeric_rows=sum(counts.values()),fixed_tolerance=tol,scope="signed initial preparations, two proper-time carrier cycles, first angular variation")
    put("seal.json",(json.dumps(out,sort_keys=True,indent=2,allow_nan=False)+"\n").encode())
    print("Sealed",len(registry),"files and",sum(counts.values()),"numeric rows; unchanged parents",len(catalog),len(parent),
          "SHA256",sha(HERE/"seal.json"))


if __name__=="__main__":verify()
