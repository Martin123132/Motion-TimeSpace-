"""Independent log-amplitude/phase and rest-subtracted momentum evolution."""
from cloud_evolve import *
from scipy.interpolate import BarycentricInterpolator


class Polar(Shell):
    def __init__(self,packet,rate,edge,flag,project):
        super().__init__(packet,rate,edge,flag)
        self.project=project
        el=(self.r/float(packet["h"])).astype(int);p=self.r/float(packet["h"])-el
        basis=BarycentricInterpolator(packet["t"],np.eye(len(packet["t"])),rng=0)(p)
        def at(raw):
            arr=raw[...,el,:];origin=arr[...,:1]
            return origin[...,0]+np.einsum("...ij,ij->...i",arr-origin,basis)
        def logpair(v):return pair(np.log1p(v[0]),v[1]/(1+v[0]))
        state=self.initial
        logu=logpair(at(packet["chi"]));state[0]=state[1]=2*logu
        for j,number in enumerate(packet["n"]):
            state[8+2*j]=at(number);state[9+2*j]=at(packet["v"][j])
        state[5]=mul(at(packet["b"]),exp(-6*logu))
        state[6,1]=at(packet["c"])*np.exp(-6*logu[0])
        state[7,1]=at(packet["d"])*np.exp(-6*logu[0])
        unit=pair(np.ones_like(self.r));delta=at(packet["delta"])
        state[14]=(logpair(at(packet["n"][-1])-unit)-logpair(delta))/2-3*logu+1j*self.mu*state[13]
        state[15]=at(packet["drift"])-state[4]/(2*self.mu)-1j*delta
        self.reference_initial_tide=packet["initial_tide"]

    def dynamics(self,time,state,details=False):
        ell,bend,tilt,tensor,trace,radial,cross,tangential=state[:8].real
        r=self.r;mu=self.mu
        er,ps,dens,press,other_r,other_c,other_t=self.incident.at(time)
        energy=pair(er,dens);active=energy+pair(ps,press)
        sr=pair(np.zeros_like(r),other_r);sc=other_c.copy()
        result=np.zeros_like(state);invr=exp(-ell);vol=exp(-ell-2*bend);one=pair(np.ones_like(r))
        for j in range(3 if self.flag else 2):
            number,pot=state[8+2*j:10+2*j].real
            pn=mul(invr,self.diff(pot));pt=pot[1]*np.exp(-bend[0])/r
            psq=square(pn);root=np.sqrt(1+psq[0]);W=pair(root,psq[1]/(2*root))
            proper=self.rho[j]*mul(number,vol);kin=mul(psq,inv(W))
            energy+=mul(proper,W);active+=mul(proper,W+kin);sr+=2/3*mul(proper,kin)
            sc+=proper[0]*pn[0]*pt/root
            fr=mul(mul(number,invr),mul(pn,inv(W)))
            ft=number[0]*(pt*np.exp(-bend[0])-tilt[1]*np.exp(-ell[0])*pn[0])/root
            result[8+2*j]=-self.diff(fr,odd=True)-2*fr/r
            result[8+2*j,1]+=6*ft/r
            result[9+2*j]=-mul(psq,inv(W+one))
        logwave,z=state[14:16]
        vel=z+trace/(2*mu)
        grad=mul(invr,self.diff(logwave))
        spatial=self.lap(logwave,ell,bend,tilt)+square(grad)
        if not self.flag:
            proper=self.rho[-1]*exp(2*logwave.real)
            norm=norm2(vel-1j*one)
            energy+=mul(proper,norm+one+norm2(grad)/mu**2)/2
            active+=mul(proper,2*norm-one);sr+=2/3*mul(proper,norm2(grad))/mu**2
            sc+=proper[0]*np.real(grad[0].conj()*logwave[1])*np.exp(-bend[0])/(mu**2*r)
        dk=square(trace)/3+1.5*square(radial)+active/2
        curvature=dk/2-square(trace)/4
        zg=1j*(spatial-curvature)/(2*mu**2)
        if not self.flag:
            result[14]=trace/2+mu*z
            result[15]=2j*mu*(z-zg)-mu*square(z)
        ric,rc,rt,scalar=self.ricci(ell,bend,tilt,tensor)
        e0=np.exp(-2*ell[0]);eb=np.exp(-2*bend[0]);bp=self.diff(bend)
        angular=tilt[1]
        gap=-2*mul(exp(-2*ell),square(bp)+2*bp/r)
        gap[0]+=2*e0*np.expm1(2*(ell[0]-bend[0]))/r**2
        gap[1]+=(eb*(8*bend[1]+12*tensor[1])+e0*(4*ell[1]-12*angular))/r**2-12*e0*bp[0]*angular/r
        ric_h=((2*energy-(2/3)*square(trace)+1.5*square(radial))/3-gap)/2
        result[0]=-trace/3-radial;result[1]=-trace/3+radial/2
        result[2,1]=-2*np.exp(ell[0]-bend[0])*cross[1];result[3]=-2*tangential;result[4]=dk
        result[5]=(ric_h if self.project else ric)+mul(trace,radial)-sr
        result[6,1]=rc+(trace[0]-1.5*radial[0])*cross[1]-sc
        result[7,1]=rt+trace[0]*tangential[1]-other_t
        if not details:return result
        extrinsic=-mul(trace,radial)/3+square(radial)/2+sr
        return dict(tide=extrinsic-ric,tide_first_derivative=extrinsic-ric_h,gap=z-zg,exact=vel,
                ham=scalar+2/3*square(trace)-1.5*square(radial)-2*energy)


def main(seed,rate,steps,flag,project,parent=5):
    with np.load(HERE/f"launch-h{parent}-off{flag}-seed{seed}.npz") as packet:
        shell=Polar(packet,rate,6,flag,project)
    start=shell.initial;change=np.zeros_like(start);dt=2*np.pi/(shell.mu*steps)
    selected={int(v*steps) for v in (0,.125,.25,.375,.5,.75,1.,1.375,1.75,2.)}
    rows=[]
    for st in range(2*steps+1):
        time=st*dt;state=start+change
        if st in selected:
            guard()
            for radius,_,__,dat in shell.read(state,shell.dynamics(time,state,True)):
                row=dict(cycles=st/steps,radius=radius)
                for key,val in dat.items():
                    row[key+"_real"]=val.real
                    if key.startswith(("exact","gap")):row[key+"_imag"]=val.imag
                rows.append(row)
        if st==2*steps:break
        first=shell.dynamics(time,state)
        second=shell.dynamics(time+dt/2,start+(change+dt/2*first))
        third=shell.dynamics(time+dt/2,start+(change+dt/2*second))
        fourth=shell.dynamics(time+dt,start+(change+dt*third))
        change+=dt*(first+2*(second+third)+fourth)/6
    table(f"polar-h{parent}-seed{seed}-n{rate}-t{steps}-off{flag}-adm{project}.csv",rows)
    print("polar",seed,rate,steps,flag,project,flush=True)


if __name__=="__main__":main(*map(int,sys.argv[1:]))
