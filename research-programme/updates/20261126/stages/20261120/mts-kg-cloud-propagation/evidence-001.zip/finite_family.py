from graph_response import *
from science_tables import find


def main(seed,mode):
    parent=5;rate=80;steps=192
    with np.load(HERE/f"launch-h5-off0-seed{seed}.npz") as pkt:shell=Shell(pkt,rate,6,0)
    start=shell.initial;reduced0=real_repr(start);law=predict(shell,start)
    gains=[-2e9,-2e8,2e8,2e9] if mode in ("original","local") else [-2e6,-2e5,2e5,2e6]
    fraction=np.clip((shell.r-3.5)/1.5,0,1)
    window=1-fraction**3*(10-15*fraction+6*fraction**2) if mode=="local" else np.ones_like(shell.r)
    offsets=np.zeros((len(gains),)+reduced0.shape);delta=np.zeros_like(start)
    dt=2*np.pi/(shell.mu*steps);rows=[]
    def evaluate(time,full,offsets,observing=False):
        rhs,info=shell.dynamics(time,full,"both");nominal=info["exact"]-info["graph"]
        remainder=nominal-mul(exp(law["omega"]*time),law["initial"])
        outputs=[]
        for gain,offset in zip(gains,offsets):
            perturb=nominal+gain*remainder*window
            field=reduced0+offset
            answer,tide=graph_rhs(shell,time,field,perturb.real,perturb.imag)
            if observing:
                outputs.append([row[3]["tide_quad"].real for row in shell.read(field,dict(tide=tide))])
            else:outputs.append(answer)
        return rhs,np.array(outputs)
    for i in range(2*steps+1):
        t=i*dt
        if i in (0,steps//4,steps,2*steps):
            _,vals=evaluate(t,start+delta,offsets,True)
            for j,gain in enumerate(gains[:2]):
                d=(vals[-j-1]-vals[j])/(-2*gain)
                for r,v in zip(shell.probes,d):
                    prior=[float(row["total"]) for row in find(f"error-tide-h5-seed{seed}-n80-L6-t192.csv",r)
                           if row["mode"]=="instant_matched" and float(row["cycles"])==i/steps]
                    assert len(prior)==1
                    rows.append(dict(seed=seed,radius=r,cycles=i/steps,diagnostic_gain=-gain,finite=v,tangent=prior[0],difference=v-prior[0]))
        if i==2*steps:break
        first,one=evaluate(t,start+delta,offsets)
        second,two=evaluate(t+dt/2,start+(delta+dt*first/2),offsets+dt*one/2)
        third,three=evaluate(t+dt/2,start+(delta+dt*second/2),offsets+dt*two/2)
        fourth,four=evaluate(t+dt,start+(delta+dt*third),offsets+dt*three)
        offsets+=dt*(one+2*two+2*three+four)/6;delta+=dt*(first+2*second+2*third+fourth)/6
        if not np.isfinite(offsets).all():
            issues=[]
            for idx,gain in enumerate(gains):
                bad=~np.all(np.isfinite(offsets[idx]),axis=(0,1))
                if np.any(bad):issues.append(dict(step=i+1,gain=gain,first_nonfinite_radius=float(shell.r[bad][0]),last_nonfinite_radius=float(shell.r[bad][-1])))
            table(f"rejected-finite-{mode}-seed{seed}.csv",issues)
            print("rejected finite gain group",mode,seed,issues,flush=True);return
    table(f"finite-family-{mode}-seed{seed}.csv",rows);print("finite family",mode,seed,flush=True)

if __name__=="__main__":main(int(sys.argv[1]),sys.argv[2])
