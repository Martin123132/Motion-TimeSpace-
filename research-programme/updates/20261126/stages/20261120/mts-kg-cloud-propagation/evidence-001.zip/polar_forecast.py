from polar_cloud import *
from forcing_law import propagate


def at_launch(shell,state):
    rhs=shell.dynamics(0.,state);obs=shell.dynamics(0.,state,True)
    ell,bend,tilt,_,trace,radial=state[:6].real
    dl,db,dv,_,dk,ds=rhs[:6].real
    logwave,z=state[14:16];lograte,dz=rhs[14:16];mu=shell.mu;r=shell.r
    grad=shell.diff(logwave);invr=exp(-ell);gr=mul(invr,grad)
    btotal=shell.lap(logwave,ell,bend,tilt)+square(gr)
    radial_part=mul(exp(-2*ell),shell.diff(logwave,2)+2*grad/r+mul(shell.diff(2*bend-ell),grad))
    op=-2*mul(dl,radial_part+square(gr))+mul(exp(-2*ell),mul(shell.diff(2*db-dl),grad))
    op[1]+=12*db[0]*np.exp(-2*bend[0])*logwave[1]/r**2+6*np.exp(-2*ell[0])*(dv[1]-2*tilt[1]*dl[0])*grad[0]/r
    moving=shell.lap(lograte,ell,bend,tilt)+2*mul(gr,mul(invr,shell.diff(lograte)))
    incident=shell.incident.samples(0.,1)
    spec=pair(incident[0]+incident[1],incident[2]+incident[3])
    act=spec.copy()
    volume=exp(-ell-2*bend)
    for j in range(2):
        n,pot=state[8+2*j:10+2*j].real;dn,dpot=rhs[8+2*j:10+2*j].real
        pr=mul(invr,shell.diff(pot));dpr=mul(invr,shell.diff(dpot))-mul(dl,pr)
        w0=np.sqrt(1+square(pr)[0]);w=pair(w0,square(pr)[1]/(2*w0))
        before=shell.rho[j]*mul(volume,n)
        after=shell.rho[j]*mul(volume,dn-mul(dl+2*db,n))
        act+=mul(after,2*w-inv(w))+mul(before,mul(2*pair(np.ones_like(r))+inv(square(w)),mul(mul(pr,dpr),inv(w))))
    density=shell.rho[-1]*exp(2*logwave.real)
    mom=z+trace/(2*mu)-1j*pair(np.ones_like(r))
    act+=mul(density,2*mul(lograte.real,2*norm2(mom)-pair(np.ones_like(r)))+4*mul(mom.conj(),dz+dk/(2*mu)).real)
    dc=(2/3*mul(trace,dk)+3*mul(radial,ds)+act/2-mul(trace,dk))/2
    zg=1j*(btotal-dk/2+square(trace)/4)/(2*mu**2)
    omega=2j*mu*pair(np.ones_like(r))-2*mu*zg
    wave=-mu*square(zg)-1j*moving/(2*mu**2)
    bulk=-1j*mul(trace,btotal)/(3*mu**2)
    return dict(omega=omega,initial=z-zg,forcing=wave+1j*(dc-op)/(2*mu**2),fixed=wave,bulk=wave+bulk,
                shear=-1j*op/(2*mu**2)-bulk)


def main(seed,rate,steps):
    with np.load(HERE/f"launch-h5-off0-seed{seed}.npz") as pkt:
        shell=Polar(pkt,rate,6,0,0)
    start=shell.initial;law=at_launch(shell,start)
    pack(f"frozen-log-law-seed{seed}-n{rate}.npz",**law)
    change=np.zeros_like(start);dt=2*np.pi/(shell.mu*steps)
    rows=[]
    for step in range(2*steps+1):
        time=step*dt;state=start+change
        first=shell.dynamics(time,state)
        if step%(steps//16)==0:
            guard()
            data={k:propagate(law,time,k) for k in ("forcing","fixed","bulk")}
            data["observed"]=shell.dynamics(time,state,True)["gap"]
            for radius,_,__,vals in shell.read(state,data):
                row=dict(seed=seed,rate=rate,steps=steps,radius=radius,cycles=step/steps)
                for key,val in vals.items():
                    row[key+"_real"]=val.real;row[key+"_imag"]=val.imag
                rows.append(row)
        if step==2*steps:break
        second=shell.dynamics(time+dt/2,start+(change+dt/2*first))
        third=shell.dynamics(time+dt/2,start+(change+dt/2*second))
        fourth=shell.dynamics(time+dt,start+(change+dt*third))
        change+=dt*(first+2*second+2*third+fourth)/6
    table(f"log-law-seed{seed}-n{rate}-t{steps}.csv",rows)
    print("independent log forecast",seed,rate,steps,flush=True)

if __name__=="__main__":main(*map(int,sys.argv[1:]))
