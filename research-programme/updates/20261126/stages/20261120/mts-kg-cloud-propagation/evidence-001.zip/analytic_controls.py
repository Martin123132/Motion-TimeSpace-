from cloud_evolve import *
from scipy.special import spherical_jn


class Empty:
    def __init__(self,size):self.zero=np.zeros((7,size))
    def at(self,time):return self.zero.copy()


def ltb(radius,time):
    import sympy as sym
    global evaluate
    if "evaluate" not in globals():
        r,t=sym.symbols("r t",real=True)
        age=8+t+sym.Rational(1,2)*sym.exp(-r**2/4)
        mass=r**3*sym.Rational(2,9)/64
        areal=r*(age/8)**sym.Rational(2,3);radial=areal.diff(r)
        bend=sym.log(areal/r);ell=sym.log(radial)
        kr=-radial.diff(t)/radial;kt=-areal.diff(t)/areal
        trace=kr+2*kt;shear=kr-trace/3;energy=2*mass.diff(r)/(areal**2*radial)
        coord=r**3*sym.exp(-r**2/3)/10
        twist=r**2*sym.exp(-r**2/2)/30
        n=energy*radial*(areal/r)**2
        expressions=[ell,ell.diff(r)*coord+coord.diff(r),bend,areal.diff(r)*coord/areal-3*twist,
             r*(radial**2*coord/areal**2+twist.diff(r)),2*twist,trace,trace.diff(r)*coord,shear,shear.diff(r)*coord,
             (kr-kt)*radial*coord/areal,n,n.diff(r)*coord+n*(coord.diff(r)+2*coord/r-6*twist)]
        evaluate=sym.lambdify((r,t),expressions,"numpy",cse=True)
    vals=[np.broadcast_to(x,radius.shape) for x in evaluate(radius,time)]
    arr=np.zeros((17,2,len(radius)),dtype=complex)
    for idx,i0,i2 in ((0,0,1),(1,2,3),(4,6,7),(5,8,9),(8,11,12)):
        arr[idx]=pair(vals[i0],vals[i2])
    arr[2,1]=vals[4];arr[3,1]=vals[5];arr[6,1]=vals[10]
    arr[14,0]=1.
    return arr


def main():
    rows=[]
    for rate in (20,40,80):
        s=Shell.__new__(Shell);s.dx=1/rate;s.r=(np.arange(rate*6)+.5)/rate
        s.flag=1;s.mu=180.;s.rho=np.array([1.,0.,0.]);s.incident=Empty(len(s.r))
        s.ops=np.array([[-1,9,-45,0,45,-9,1],[2,-27,270,-490,270,-27,2]],dtype=float)
        s.ops[0]/=60*s.dx;s.ops[1]/=180*s.dx**2
        initial=ltb(s.r,0);field=initial.copy();step=.002
        active=(s.r>.6)&(s.r<3.2)
        for count in range(13):
            time=count*step
            if count in (0,6,12):
                truth=ltb(s.r,time)
                exact=-(mul(truth[4],truth[5])/3)+square(truth[5])/2
                info=s.dynamics(time,field,True)
                for idx in (0,1):
                    rows.append(dict(rate=rate,time=time,part=idx,
                        max_tide_error_on_peak=np.max(abs(info["tide"][idx]-exact[idx])[active])/np.max(abs(exact[idx])[active]),
                        max_hamiltonian=np.max(abs(info["ham"][idx,active])),
                        max_metric_error=np.max(abs(field[:4,idx]-truth[:4,idx])[:,active]),
                        max_shear_error=np.max(abs(field[4:8,idx]-truth[4:8,idx])[:,active])))
            if count==12:break
            rhs=lambda y:s.dynamics(time,y)
            first=rhs(field);second=rhs(field+step*first/2)
            third=rhs(field+step*second/2);fourth=rhs(field+step*third)
            field+=step*(first+2*second+2*third+fourth)/6
    table("exact-ltb.csv",rows)


if __name__=="__main__":main()
