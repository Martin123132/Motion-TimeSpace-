"""A serial replay. No detached jobs and no overwrite of saved results."""
from cloud_owner import *
import subprocess


def jobs(mode):
    if mode=="representative":
        return [("prepare.py",5),("run_cloud.py",5,0,1,40,6,48),("run_cloud.py",5,0,-1,80,6,192),
            ("analytic_controls.py",),("conservation_fixture.py",),("cold_control.py","run",1),
            ("propagate_error.py",5,1,80,192),("polar_forecast.py",-1,80,384),
            ("surroundings.py",80,192,1,5),("tide_rate.py",80,192,0,5)]
    assert mode=="all"
    seq=[("prepare.py",4),("prepare.py",5),("run_cloud.py",5,0,1,40,6,48)]
    for seed in (0,1,-1):
        for flag in (0,1):
            for parent,n,L,t in ((4,80,6,192),(5,40,6,96),(5,80,6,96),(5,80,6,192),(5,80,8,192),(5,120,6,192),(5,80,6,384)):
                seq.append(("run_cloud.py",parent,flag,seed,n,L,t))
            if not flag:seq.append(("run_cloud.py",5,flag,seed,80,6,192,"--frozen"))
            for adm in (0,1):
                for n,t in ((40,96),(80,192),(120,192)):
                    seq.append(("polar_cloud.py",seed,n,t,flag,adm))
        for n,t in ((40,96),(80,192),(120,192),(80,384)):
            seq.extend((("propagate_error.py",5,seed,n,t),("polar_forecast.py",seed,n,t)))
        seq.append(("finite_family.py",seed,"local"))
    seq.extend((("finite_family.py",1,"original"),("analytic_controls.py",),("conservation_fixture.py",)))
    for flag in (0,1):seq.extend((("cold_control.py","trace",flag),("cold_control.py","run",flag)))
    for n,t,adm,parent in ((40,96,0,5),(80,192,0,5),(120,192,0,5),(80,192,1,5),(120,192,1,5),(80,192,0,4)):
        seq.append(("tide_rate.py",n,t,adm,parent))
    for n,t,adm,parent in ((40,96,0,5),(80,192,0,5),(120,192,0,5),(80,192,1,5),(120,192,1,5),(80,384,1,5),(80,192,0,4),(80,192,1,4)):
        seq.append(("surroundings.py",n,t,adm,parent))
    seq.extend((("science_tables.py",),("closure_tables.py",),("current_check.py",),("balance_tables.py",),("limits.py",),("verify_cloud.py",)))
    return seq


if __name__=="__main__":
    for group in jobs(sys.argv[1]):
        guard()
        args=[sys.executable,"-B",*map(str,group)]
        subprocess.run(args,cwd=HERE,check=True)
        print("compared"," ".join(map(str,group)),flush=True)
