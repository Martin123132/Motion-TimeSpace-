from cloud_evolve import *


def predict(shell,state):
    rhs=shell.dynamics(0.,state)
    data=shell.dynamics(0.,state,True)
    ell,bend,tilt,_,trace,radial=state[:6].real
    dl,db,dv,_,dk,ds=rhs[:6].real
    wave,slow=state[14:16];vel=rhs[14]
    lap=shell.lap(wave,ell,bend,tilt)
    radial_part=mul(exp(-2*ell),shell.diff(wave,2)+2*shell.diff(wave)/shell.r+mul(shell.diff(2*bend-ell),shell.diff(wave)))
    dl_operator=-2*mul(dl,radial_part)+mul(exp(-2*ell),mul(shell.diff(2*db-dl),shell.diff(wave)))
    dl_operator[1]+=12*db[0]*np.exp(-2*bend[0])*wave[1]/shell.r**2
    dl_operator[1]+=6*np.exp(-2*ell[0])*(dv[1]-2*tilt[1]*dl[0])*shell.diff(wave[0])/shell.r
    mu=shell.mu
    inverse=inv(wave)
    quotient=mul(lap,inverse)
    operator=mul(dl_operator,inverse)
    moving=mul(shell.lap(vel,ell,bend,tilt)-mul(quotient,vel),inverse)
    spec=shell.incident.samples(0.,1)
    surroundings=pair(spec[0]+spec[1],spec[2]+spec[3])
    active_rate=surroundings.copy()
    volume=exp(-ell-2*bend)
    for j in range(2):
        number,potential=state[8+2*j:10+2*j].real
        nrate,prate=rhs[8+2*j:10+2*j].real
        pn=mul(exp(-ell),shell.diff(potential))
        pn_rate=mul(exp(-ell),shell.diff(prate))-mul(dl,pn)
        g0=np.sqrt(1+square(pn)[0]);gamma=pair(g0,square(pn)[1]/(2*g0))
        g_rate=mul(mul(pn,pn_rate),inv(gamma))
        rest=shell.rho[j]*mul(volume,number)
        rest_rate=shell.rho[j]*mul(volume,nrate-mul(dl+2*db,number))
        active_rate+=mul(rest_rate,2*gamma-inv(gamma))+mul(rest,mul(2*pair(np.ones_like(shell.r))+inv(square(gamma)),g_rate))
    momentum=slow-1j*wave
    active_rate+=shell.rho[-1]*(4*mul(momentum.conj(),rhs[15]-1j*vel).real-2*mul(wave.conj(),vel).real)
    ddk=(2/3)*mul(trace,dk)+3*mul(radial,ds)+active_rate/2
    curvature_rate=(ddk-mul(trace,dk))/2
    graph=data["graph"]
    nonuniform=graph-trace/(2*mu)
    frozen=-mu*square(nonuniform)-1j*moving/(2*mu**2)
    spatial=-1j*operator/(2*mu**2)
    curvature=1j*curvature_rate/(2*mu**2)
    forcing=frozen+spatial+curvature
    omega=2j*mu*pair(np.ones_like(shell.r))+trace-2*mu*graph
    initial=data["exact"]-graph
    return dict(omega=omega,initial=initial,forcing=forcing,changing_operator=spatial,
                changing_curvature=curvature,changing_wave=frozen,
                spectator=1j*surroundings/(8*mu**2),dBdt=operator+moving,dCdt=curvature_rate)


def propagate(law,time,which):
    omega=law["omega"];phase=exp(omega*time)
    return mul(phase,law["initial"])+mul(mul(phase-pair(np.ones_like(phase[0])),inv(omega)),law[which])
