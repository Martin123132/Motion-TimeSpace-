from surroundings import *
from scipy.special import spherical_jn


class Acoustic:
    def __init__(self,radius,alpha):
        self.r=radius;self.k=1.7;self.coef=alpha;self.cs2=1/3
        self.omega=self.k*np.sqrt(self.cs2-2*alpha*self.k**2/3)
        self.F=spherical_jn(2,self.k*radius);self.dr=self.k*spherical_jn(2,self.k*radius,True)
        self.drr=-2*self.dr/radius+(6/radius**2-self.k**2)*self.F
    def at(self,time):
        r=self.r;F=self.F;dr=self.dr;drr=self.drr
        base=np.zeros((7,len(r)))
        base[0]=.08;base[1]=.08
        phase=np.cos(self.omega*time)
        base[2]=F*phase;base[3]=3*self.cs2*F*phase
        base[4]=self.coef*((2/3)*(drr-dr/r)+2*F/r**2)*phase
        base[5]=self.coef*(dr/r-F/r**2)*phase
        base[6]=self.coef*F/r**2*phase
        return base
    def truth(self,time):
        rate=self.omega*np.sin(self.omega*time)
        return np.stack((pair(np.full(len(self.r),.08),self.F*np.cos(self.omega*time)),
                         pair(np.zeros_like(self.r),-rate*self.dr/self.k**2),
                         pair(np.zeros_like(self.r),-rate*self.F/(self.r*self.k**2))))


def main():
    rows=[]
    for rate in (20,40,80):
        for alpha in (0.,.04):
            obj=Conserved.__new__(Conserved);obj.dx=1/rate;obj.r=(np.arange(6*rate)+.5)/rate
            obj.project=False;obj.mu=1720.;obj.flag=1;obj.rho=np.zeros(3)
            obj.ops=np.array([[-1,9,-45,0,45,-9,1],[2,-27,270,-490,270,-27,2]],dtype=float)
            obj.ops[0]/=60*obj.dx;obj.ops[1]/=180*obj.dx**2
            fixture=Acoustic(obj.r,alpha);obj.incident=LocalSource(fixture)
            state=np.zeros((20,2,len(obj.r)),dtype=complex);initial_time=.23
            state[17:]=fixture.truth(initial_time)
            region=(obj.r>.60)&(obj.r<3.2);ds=.002
            rates=[]
            for ix in range(21):
                t=initial_time+ix*ds
                first=obj.dynamics(t,state)[17:]
                if ix in (0,20):
                    truth=fixture.truth(t);ref=fixture.truth(t+1e-5)-fixture.truth(t-1e-5)
                    for ch in range(3):
                        difference=state[17+ch,1]-truth[ch,1]
                        deriv=ref[ch,1]/2e-5
                        rows.append(dict(rate=rate,stress_coefficient=alpha,step=ix,component=ch,
                            state_error_on_peak=magnitude(difference[region])/magnitude(truth[ch,1,region]),
                            rate_error_on_peak=magnitude((first[ch,1]-deriv)[region])/magnitude(deriv[region])))
                if ix==20:break
                def call(inc,off):
                    copy=state.copy();copy[17:]+=inc
                    return obj.dynamics(t+off,copy)[17:]
                b=call(ds*first/2,ds/2);c=call(ds*b/2,ds/2);d=call(ds*c,ds)
                state[17:]+=ds/6*(first+2*b+2*c+d)
    table("exact-incident-stress.csv",rows)


if __name__=="__main__":
    from science_tables import magnitude
    main()
