from cloud_owner import *
if __name__=="__main__" and sys.argv[1]=="trace":
    sys.path.insert(0,str(HERE.parent/"mts-common-metric-formation-tide-20261120"))
    import switched
from states import BalancedNative,SPAN,DLOG,Element,shape,Slice,stage_field,native
from inputs import verified,response,GR
from proper_probe import Ruler,PROBES
from polar_cloud import Polar


def trace(flag):
    import ctypes
    sys.path.insert(0,str(GR))
    import switched as run
    _,epochs,_,_,_=run.prepare("cold",0)
    origin=run.NATIVE/"runs/backgrounds/cold.npz"
    run.checked(origin,run.obj(run.source("runs/cold/status.json"))["source_hash"])
    params=run.inherited.params_for(origin,background_boost=8.);params.DoLateRadTruncation=False
    bg=run.camb.get_background(params);bg.Params.Accuracy.IntTolBoost=6;bg.Params.Accuracy.lAccuracyBoost=4
    observer=ctypes.CDLL(str(run.OBSERVER));ptr=ctypes.cast(observer.source_func_,ctypes.c_void_p)
    with np.load(verified(f"serial-cold-b6-off{flag}.npz")) as previous:
        t=previous["tau"];modes=previous["k"];reference=previous["values"];names=previous["names"].tolist()
    with np.load(run.LONG/"cold-environment.npz") as old:x=old["loga"]
    a=run.AI*np.exp(x[x<=0]);early=epochs[epochs<min(a)]
    lead=bg.conformal_time(1/np.r_[early,a[:-1]]-1,tol=1e-10)
    dt=np.arange(1,17)/160.;eta=np.ascontiguousarray(np.r_[lead,t,t[-1]+dt])
    ctypes.c_int.in_dll(run.lib,"mts_turn_index").value=len(lead)+1
    chunks=[];width=len(names)
    for path in sorted((run.SPEC/"runs/cold").glob("chunk-*.npz")):
        guard()
        with np.load(run.source(path.relative_to(run.SPEC).as_posix())) as group:
            keep=group["modes"][np.isin(group["modes"],modes)]
            if not len(keep):continue
            batch=np.unique(np.r_[keep,group["modes"].max()])
        ctypes.c_int.in_dll(run.lib,"mts_remove_pressure").value=flag
        out=np.zeros((len(batch),len(eta),width))
        ref=lambda v:ctypes.byref(ctypes.c_int(v))
        rc=run.camb.results.CAMB_TimeEvolution(ctypes.byref(bg),ref(len(batch)),batch,ref(len(eta)),eta,ref(width),out,ref(len(run.OBS)),ctypes.byref(ptr))
        assert rc==0 and np.isfinite(out).all()
        seq=out[np.searchsorted(batch,keep),len(lead):]
        np.testing.assert_allclose(seq[:,:len(t)],reference[np.searchsorted(modes,keep)],rtol=1e-12,atol=1e-18)
        chunks.append(seq[:,len(t)-1:])
    pack(f"trace-cold-off{flag}.npz",dt=np.r_[0.,dt],k=modes,names=names,values=np.concatenate(chunks))


def exercise(flag):
    with np.load(HERE/f"trace-cold-off{flag}.npz") as tr:
        names=tr["names"].tolist();field=dict(zip(names,tr["values"].transpose(2,0,1)));k=tr["k"][:,None];dt=tr["dt"][1]
    h=field["H"];p=field["P"];S=field["R"]+p;q=field["Q"]+S*field["sigma"]
    psi=(field["dsigma"]+h*field["sigma"])/k;phi=q/(2*k)-h*psi
    slope=lambda arr:((arr[:,:5]-arr[:,:1])@np.array([-25.,48.,-36.,16.,-3.]))/(12*dt)
    shift=(1.5*q/k/(k*k+1.5*S))[:,0]
    dp=slope(q)/k[:,0]+(4*h*phi+2*(2*h*h-S/2)*psi+2*field["Pi"]/3)[:,0]-(slope(p)-(2*h*p)[:,0])*shift
    bg=native("cold",flag);bg["spectrace"]=3*dp
    sim=BalancedNative("cold",120,600,False,"native36",SPAN*DLOG)
    grid=Element(sim.mesh,120,12);sm=(shape(bg,grid.points),shape(bg,np.asarray(120.)));cut=grid.points[:,0]<16
    with np.load(HERE/"launch-h5-off0-seed0.npz") as ref:mu=float(ref["mu"])
    rows=[]
    for seed in (0,1,-1):
        state=stage_field(sim,"cold",seed if seed else 1,5)
        if not seed:state=tuple(np.zeros_like(x) for x in state)
        obj=Slice(sim,grid,bg,sm,state,flag,False,"fixed",0,"matched");m=obj.m
        number=np.stack([pair(x,y) for x,y in zip(m["n"],m["D"])])
        mono=grid.evaluate(obj.state[0])[0];qp=grid.evaluate(obj.state[2])[0][flag]
        phase=np.stack([pair(x,y) for x,y in zip(mono[1]/grid.points,sm[0]["V"]+qp)])
        blank=np.zeros_like(number[:1]);blank[:,0]=1
        pkt=dict(cold_flag=flag,rho=np.r_[obj.rh,0.],t=grid.t,h=grid.h,n=np.concatenate((number,blank))[...,cut,:],
            v=np.concatenate((phase,np.zeros_like(blank)))[...,cut,:],mu=mu,H=bg["H"],P=p[:,0].mean(),R=bg["R"],
            e0=sm[0]["other"][cut],s0=response(bg,grid.points)("spectrace")[cut],native_stress=sm[0]["stress"][cut],
            native_cross=sm[0]["stress_cross"][cut],weight=bg["w"],chi=pair(grid.evaluate(obj.f0)[0],grid.evaluate(obj.f2)[0])[...,cut,:],
            b=pair(obj.b0,obj.b2)[...,cut,:],c=obj.c2[cut],d=obj.d2[cut],delta=np.zeros_like(number[0][...,cut,:]),
            drift=np.zeros_like(number[0][...,cut,:]),probes=PROBES[:3],initial_tide=[Ruler(obj).read(r)["ruler_tide"] for r in PROBES[:3]])
        shell=Polar(pkt,80,6,1,0);local=shell.initial;change=np.zeros_like(local);step=2*np.pi/(mu*192)
        for ix in range(385):
            time=ix*step
            if ix in (0,48,96,192,384):
                for radius,_,__,d in shell.read(local+change,shell.dynamics(time,local+change,True)):
                    rows.append(dict(seed=seed,radius=radius,cycles=ix/192,tide=d["tide_quad"].real,
                        constraint=d["ham_quad"].real,gauss=d["tide_first_derivative_quad"].real))
            if ix==384:break
            one=shell.dynamics(time,local+change)
            two=shell.dynamics(time+step/2,local+(change+step*one/2))
            three=shell.dynamics(time+step/2,local+(change+step*two/2))
            four=shell.dynamics(time+step,local+(change+step*three))
            change+=step/6*(one+2*two+2*three+four)
        print("cold",flag,seed,flush=True)
    table(f"cold-control-off{flag}.csv",rows)


if __name__=="__main__":
    flag=int(sys.argv[2])
    (trace if sys.argv[1]=="trace" else exercise)(flag)
