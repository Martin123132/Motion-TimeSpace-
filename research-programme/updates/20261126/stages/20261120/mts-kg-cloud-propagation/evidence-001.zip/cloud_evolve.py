from cloud_owner import *
from incident import Incident
from scipy.interpolate import BarycentricInterpolator,CubicSpline
from scipy.optimize import brentq


class Shell:
    def __init__(self,packet,rate,edge,flag):
        self.dx=1/rate;self.r=(np.arange(int(edge*rate))+.5)/rate
        self.mu=float(packet["mu"]);self.rho=packet["rho"];self.flag=flag
        element=(self.r/float(packet["h"])).astype(int)
        position=self.r/float(packet["h"])-element
        coeff=BarycentricInterpolator(packet["t"],np.eye(len(packet["t"])),rng=0)(position)
        def extract(arr):
            return np.einsum("...ij,ij->...i",arr[...,element,:],coeff)
        self.incident=Incident(packet,self.r,flag,extract)
        chi=extract(packet["chi"])
        logu=pair(np.log1p(chi[0]),chi[1]/(1+chi[0]))
        shape=(17,2,len(self.r))
        state=np.zeros(shape,dtype=np.complex128)
        state[0]=state[1]=2*logu
        state[4,0]=-3*float(packet["H"])
        state[5]=mul(extract(packet["b"]),exp(-6*logu))
        state[6,1]=extract(packet["c"])*np.exp(-6*logu[0])
        state[7,1]=extract(packet["d"])*np.exp(-6*logu[0])
        number=extract(packet["n"]);velocity=extract(packet["v"])
        for j in range(3):
            state[8+2*j]=number[j];state[9+2*j]=velocity[j]
        delta=extract(packet["delta"]);drift=extract(packet["drift"])
        amp=mul(number[-1],exp(-6*logu))
        nu=delta+pair(np.ones_like(self.r))
        amp=mul(amp,inv(nu))
        root=pair(np.sqrt(amp[0]),amp[1]/(2*np.sqrt(amp[0])))
        state[14]=mul(root,exp(1j*self.mu*velocity[-1]))
        state[15]=mul(drift-1j*delta,state[14])
        self.initial=state;self.probes=packet["probes"]
        self.init_tide=packet["initial_tide"]
        self.ops=np.array([[-1,9,-45,0,45,-9,1],[2,-27,270,-490,270,-27,2]],dtype=float)
        self.ops[0]/=60*self.dx;self.ops[1]/=180*self.dx**2

    def diff(self,arr,degree=1,odd=False):
        ext=np.concatenate(((-1 if odd else 1)*arr[...,2::-1],arr,arr[...,:-4:-1]),axis=-1)
        coeff=self.ops[degree-1]
        return sum(c*(ext[...,j:j+len(self.r)]-arr) for j,c in enumerate(coeff) if j!=3)

    def ricci(self,ell,bend,tilt,tensor):
        radius=self.r
        l0,l2=ell;b0,b2=bend
        lb=self.diff(ell);bb=self.diff(bend);bdd=self.diff(bend,2)
        v=tilt[1];v1=self.diff(v);t=tensor[1];td=self.diff(t);tdd=self.diff(t,2)
        e0=np.exp(-2*l0);eb=np.exp(-2*b0)
        nr=2*bdd-2*mul(lb,bb)-2*lb/radius
        nr[1]+=6*(v1-lb[0]*v)/radius
        common=mul(exp(-2*ell),nr)
        common[0]+=2*e0*np.expm1(2*(l0-b0))/radius**2
        common[1]+=(e0*(4*l2-6*v)+eb*(8*b2+12*t-6*l2))/radius**2
        radial=-common/3
        cross=-np.exp(-l0-b0)*((bb[1]+td-l2*bb[0])/radius+(v-l2)/radius**2)
        angle=-e0*(tdd/2+(td-v1)/radius+(2*bb[0]-lb[0])*(td/2-v/radius))+(e0*v-eb*l2)/radius**2
        sphere_k=mul(exp(-ell),2*bb+pair(2/radius,6*v/radius))
        area_curve=pair(2*eb/radius**2,eb*(8*b2+12*t)/radius**2)
        scalar=6*radial+3*(area_curve-square(sphere_k)/2)
        return radial,cross,angle,scalar

    def lap(self,field,ell,bend,tilt):
        derivative=self.diff(field)
        volume_inv=exp(-ell-2*bend)
        lap=mul(exp(-2*ell),self.diff(field,2)+2*derivative/self.r+mul(self.diff(2*bend-ell),derivative))
        lap[1]+=-6*np.exp(-2*bend[0])*field[1]/self.r**2+6*np.exp(-2*ell[0])*tilt[1]*derivative[0]/self.r
        return lap

    def dynamics(self,time,state,details=False,frozen=False):
        geo=state[:8].real
        ell,bend,tilt,tensor,trace,radial,cross,tangent=geo
        result=np.zeros_like(state)
        volinv=exp(-ell-2*bend);radinv=exp(-ell);anginv=np.exp(-bend[0])/self.r
        er,ps,dens,press,other_r,other_c,other_t=self.incident.at(time)
        energy=pair(er,dens);active=energy+pair(ps,press)
        stress=pair(np.zeros_like(self.r),other_r)
        mixed=other_c.copy()
        for j in range(3 if self.flag else 2):
            number,potential=state[8+2*j:10+2*j].real
            pn=mul(radinv,self.diff(potential));pt=potential[1]*anginv
            psq=square(pn)
            gamma0=np.sqrt(1+psq[0]);gamma=pair(gamma0,psq[1]/(2*gamma0))
            rest=mul(number,volinv)*self.rho[j]
            energy+=mul(rest,gamma)
            active+=mul(rest,gamma+mul(psq,inv(gamma)))
            stress+=2/3*mul(mul(rest,psq),inv(gamma))
            mixed+=rest[0]*pn[0]*pt/gamma0
            flux=mul(mul(number,radinv),mul(pn,inv(gamma)))
            angular_flux=number[0]*(pt*np.exp(-bend[0])-tilt[1]*np.exp(-ell[0])*pn[0])/gamma0
            result[8+2*j]=-self.diff(flux,odd=True)-2*flux/self.r
            result[8+2*j,1]+=6*angular_flux/self.r
            result[9+2*j]=-mul(psq,inv(gamma+pair(np.ones_like(self.r))))
        wave,slow=state[14:16]
        momentum=slow-1j*wave
        lap=self.lap(wave,ell,bend,tilt)
        if not self.flag:
            normal=mul(radinv,self.diff(wave))/self.mu
            polar=wave[1]*anginv/self.mu
            coeff=self.rho[-1]
            energy+=coeff*(norm2(momentum)+norm2(wave)+norm2(normal))/2
            active+=coeff*(2*norm2(momentum)-norm2(wave))
            stress+=2/3*coeff*norm2(normal)
            mixed+=coeff*np.real(np.conj(normal[0])*polar)
            result[14]=self.mu*slow
            result[15]=2j*self.mu*slow+mul(trace,momentum)+lap/self.mu
        curvature,ricci_c,ricci_t,scalar=self.ricci(ell,bend,tilt,tensor)
        trace_dot=square(trace)/3+1.5*square(radial)+active/2
        result[0]=-trace/3-radial;result[1]=-trace/3+radial/2
        result[2,1]=-2*np.exp(ell[0]-bend[0])*cross[1]
        result[3]=-2*tangent
        result[4]=trace_dot
        result[5]=curvature+mul(trace,radial)-stress
        result[6,1]=ricci_c+(trace[0]-1.5*radial[0])*cross[1]-mixed
        result[7,1]=ricci_t+trace[0]*tangent[1]-other_t
        if frozen:result[:14]=0.
        if details:
            tide=-curvature-mul(trace,radial)/3+square(radial)/2+stress
            ham=scalar+(2/3)*square(trace)-1.5*square(radial)-2*energy
            graph=mul(lap,inv(wave))
            correction=(trace_dot/2-square(trace)/4-graph)/(2*self.mu**2)
            predicted=trace/(2*self.mu)-1j*correction
            exact=mul(slow,inv(wave))
            area=-mul(wave.conj(),momentum).imag
            fields=dict(tide=tide,stress=stress,ricci=curvature,ham=ham,graph=predicted,exact=exact,
                        area=mul(area,exp(ell+2*bend)),trace=trace,shear=radial)
            return (result,fields) if details=="both" else fields
        return result

    def read(self,state,values):
        rad=self.r
        ell=state[0].real
        nodes=np.r_[-rad[:8][::-1],rad]
        def spline(val):
            return CubicSpline(nodes,np.concatenate((val[...,:8][...,::-1],val),axis=-1),axis=-1)
        axis=spline(exp(ell)).antiderivative()
        root=axis(0.)
        fields={key:spline(val) for key,val in values.items()}
        rows=[]
        for target in self.probes:
            pos=brentq(lambda point:(axis(point)-root)[0]-target,target-.02,target+.02,xtol=2e-15)
            shift=-(axis(pos)-root)[1]/axis(pos,1)[0]
            data={}
            for key,sp in fields.items():
                val=sp(pos)
                for part,num in (("sphere",val[0]),("quad",val[1]+shift*sp(pos,1)[0])):
                    data[key+"_"+part]=num
            rows.append((target,pos,shift,data))
        return rows
