from science_tables import *
from forcing_law import *
from scipy.interpolate import CubicSpline


def inspect(shell,base,change=None):
    state=base if change is None else base+change
    ell,bend,tilt=state[:3].real;wave,slow=state[14:16];mu=shell.mu
    raw=mul(wave.conj(),slow-1j*wave)
    factor=exp(ell+2*bend)
    number=-mul(factor,raw).imag
    derivative=shell.diff(wave)
    radial=mul(exp(2*bend-ell),mul(wave.conj(),derivative).imag)/mu
    ang=(np.exp(ell[0])*np.imag(wave[0].conj()*wave[1])/shell.r
         -tilt[1]*np.exp(2*bend[0]-ell[0])*np.imag(wave[0].conj()*derivative[0]))/mu
    full,info=shell.dynamics(0,state,"both")
    number_rate=-mul(factor,mul(full[0].real+2*full[1].real,raw)+mul(full[14].conj(),slow-1j*wave)
                     +mul(wave.conj(),full[15]-1j*full[14])).imag
    if change is not None:
        u,w=base[14:16];du,dw=change[14:16]
        dlog=(change[0]+2*change[1]).real
        dm=pair(np.expm1(dlog[0]),np.exp(dlog[0])*dlog[1])
        d_raw=mul(du.conj(),w-1j*u)+mul(wave.conj(),dw-1j*du)
        number=-mul(exp((base[0]+2*base[1]).real),d_raw+mul(dm,raw)).imag
    return number,number_rate,radial,ang


def main():
    rows=[];origins=[]
    for rate,steps in ((40,96),(80,192),(120,192)):
        for seed in (0,1,-1):
            with np.load(HERE/f"launch-h5-off0-seed{seed}.npz") as packet:shell=Shell(packet,rate,6,0)
            name=panel(5,0,seed,rate,6,steps)
            with np.load(HERE/name.replace(".csv",".npz")) as saved:change=saved["delta"];duration=2*steps*saved["dt"]
            r=shell.r;nodes=np.r_[-r[:8][::-1],r]
            def make(arr,odd=False):
                return CubicSpline(nodes,np.concatenate(((-1 if odd else 1)*arr[...,:8][...,::-1],arr),axis=-1),axis=-1)
            def integrand(arr,odd=False):
                sp=make(arr,odd).antiderivative()
                return lambda pos:sp(pos)-sp(0.)
            info=[]
            for inc in (None,change):
                number,nrate,radial,ang=inspect(shell,shell.initial,inc)
                info.append((integrand(number*r**2),integrand(nrate*r**2),make(radial,True),integrand(ang*r)))
            law=predict(shell,shell.initial)
            scalar=shell.initial[14];trace=shell.initial[4].real;ell,bend,v=shell.initial[:3].real
            B=mul(shell.lap(scalar,ell,bend,v),inv(scalar))
            bulk=-1j*mul(trace,B)/(3*shell.mu**2)
            shear=law["changing_operator"]-bulk
            sub=dict(**law,bulk_only=law["changing_wave"]+bulk,all_but_shear=law["forcing"]-shear)
            for rad in shell.probes:
                samples=find(name,rad)
                for part,idx in (("sphere",0),("quad",1)):
                    est=[]
                    for number,der,fr,ft in info:
                        est.append(-rad**2*fr(rad)[idx]+(6*ft(rad) if idx else 0.))
                    diff=info[1][0](rad)[idx]
                    integrated=duration*(est[0]+est[1])/2
                    rows.append(dict(rate=rate,steps=steps,seed=seed,radius=rad,part=part,delta_number=diff,
                          from_boundary_and_angular_flux=integrated,relative=abs(diff-integrated)/max(1e-70,abs(diff)),
                          initial_rate_error=abs(est[0]-info[0][1](rad)[idx])/max(1e-70,abs(est[0]))))
                    if seed==0 and idx==0:continue
                    measured=complex_obs("response-"+name,rad,"error_"+part)
                    errors={}
                    for term in ("bulk_only","all_but_shear","forcing"):
                        terms=[]
                        for row in samples:
                            field=make(propagate(sub,float(row["proper_over_a"]),term))
                            pos=float(row["r0"]);shift=float(row["shift"])
                            terms.append(field(pos)[idx]+(shift*field(pos,1)[0] if idx else 0.))
                        errors[term]=fractional(np.array(terms),measured)
                    origins.append(dict(rate=rate,seed=seed,radius=rad,part=part,**errors))
    table("symplectic-current.csv",rows);table("expansion-versus-shear.csv",origins)

if __name__=="__main__":main()
