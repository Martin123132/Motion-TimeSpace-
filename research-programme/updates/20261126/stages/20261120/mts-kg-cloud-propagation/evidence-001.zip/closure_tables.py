from science_tables import *


def main():
    transfer=[];refinement=[];geometry=[];fg=[]
    for rate,steps in ((40,96),(80,192),(120,192),(80,384)):
        for seed in (1,-1):
            for radius in (.676538827,1.35307765,2.7061553):
                for mode in ("instant_matched","transport_forecast"):
                    def series(sign):
                        name=f"error-tide-h5-seed{sign}-n{rate}-L6-t{steps}.csv"
                        return np.array([float(row["total"]) for row in find(name,radius) if row["mode"]==mode])
                    delta=series(seed)-series(0)
                    ref=[row for row in read("signed-tides.csv") if row["seed"]==str(seed) and row["parent"]=="5" and
                         int(row["rate"])==rate and row["edge"]=="6" and int(row["steps"])==steps and float(row["radius"])==radius]
                    assert len(ref)==len(delta)
                    for row,val in zip(ref,delta):
                        transfer.append(dict(rate=rate,steps=steps,seed=seed,radius=radius,mode=mode,cycles=row["cycles"],
                            tide_change=val,on_host_switch=val/float(row["host_switch"])))
    for seed in (1,-1):
        for radius in (.676538827,1.35307765,2.7061553):
            for mode in ("instant_matched","transport_forecast"):
                def value(rate,steps):return np.array([r["tide_change"] for r in transfer if
                    (r["rate"],r["steps"],r["seed"],r["radius"],r["mode"])==(rate,steps,seed,radius,mode)])
                b=value(80,192)
                for label,a in (("space40_time96",value(40,96)),("space120",value(120,192)),("time384",value(80,384))):
                    refinement.append(dict(seed=seed,radius=radius,mode=mode,test=label,peak=magnitude(a),
                        delta=magnitude(b-a),relative=fractional(b,a),pass_20ppm=fractional(b,a)<2e-5))
    for rate,steps in ((40,96),(80,192),(120,192)):
        for seed in (1,-1):
            for radius in (.676538827,1.35307765,2.7061553):
                for project in (0,1):
                    def path(flag,s):return f"polar-h5-seed{s}-n{rate}-t{steps}-off{flag}-adm{project}.csv"
                    for key in ("tide","tide_first_derivative"):
                        def host(flag):return obs(path(flag,seed),radius,key+"_quad_real")-obs(path(flag,0),radius,key+"_quad_real")
                        switched=host(0)-host(1)
                        geometry.append(dict(rate=rate,steps=steps,seed=seed,radius=radius,
                            project=project,readout=key,launch=switched[0],end=switched[-1],change=switched[-1]-switched[0]))
                    for part in ("sphere","quad"):
                        source=complex_obs("response-"+panel(5,0,seed,rate,6,steps),radius,"error_"+part)
                        predicted=complex_obs("response-"+panel(5,0,seed,rate,6,steps),radius,"forecast_"+part)
                        sign=complex_obs(path(0,seed),radius,"gap_"+part)
                        fg.append(dict(rate=rate,steps=steps,seed=seed,radius=radius,project=project,part=part,
                            log_peak=magnitude(sign),cartesian_disagreement=fractional(source,sign),
                            cartesian_prediction_on_log=fractional(predicted,sign)))
    for nm,data in (("closure-tidal-change",transfer),("closure-tidal-precision",refinement),("gauss-versus-ricci",geometry),("independent-log-graph",fg)):
        table(nm+".csv",data)


if __name__=="__main__":main()
