from science_tables import *


def main():
    laws=[];precision=[];gain=[]
    for path in sorted(HERE.glob("log-law-seed*.csv")):
        rows=read(path.name);meta={k:rows[0][k] for k in ("rate","steps","seed")}
        for rad in (.676538827,1.35307765,2.7061553):
            for part in ("sphere","quad"):
                actual=complex_obs(path.name,rad,"observed_"+part)
                full=complex_obs(path.name,rad,"forcing_"+part)
                fixed=complex_obs(path.name,rad,"fixed_"+part)
                bulk=complex_obs(path.name,rad,"bulk_"+part)
                laws.append(dict(**meta,radius=rad,part=part,peak=magnitude(actual),
                    max_full_error=magnitude(actual-full),full_error_on_peak=fractional(full,actual),
                    fixed_metric_error=fractional(fixed,actual),isotropic_metric_error=fractional(bulk,actual),
                    pass_20ppm=fractional(full,actual)<=2e-5))
    for radius in (.676538827,1.35307765,2.7061553):
        for seed in (1,-1):
            choices=[r for r in read("evolution-balance.csv") if float(r["radius"])==radius and int(r["seed"])==seed]
            def val(env,p,n,t,adm,rule,readout):
                [row]=[r for r in choices if (r["environment"],int(r["parent"]),int(r["rate"]),int(r["steps"]),
                           int(r["project"]),r["rule"],r["method"])==(env,p,n,t,adm,rule,readout)]
                return float(row["integrated_tide_change"])
            base=("conserved",5,80,192,1,"full","gauss");ref=val(*base)
            for tag,idx,value in (("radial_refinement",2,120),("time_refinement",3,384),("native_refinement",1,4),
                        ("environment",0,"prescribed"),("unconstrained_shear",4,0),("curvature_readout",6,"ricci"),("time_integral",5,"half")):
                cmp=list(base);cmp[idx]=value
                alt=val(*cmp);gap=abs(alt/ref-1)
                precision.append(dict(radius=radius,seed=seed,test=tag,reference=ref,alternate=alt,relative=gap,pass_20ppm=gap<=2e-5))
            for big in (2e8,2e9):
                def arr(sign,key):
                    return np.array([float(r[key]) for r in find(f"finite-family-local-seed{sign}.csv",radius)
                                    if float(r["diagnostic_gain"])==big])
                measured=arr(seed,"finite")-arr(0,"finite");tangent=arr(seed,"tangent")-arr(0,"tangent")
                gain.append(dict(radius=radius,seed=seed,gain=big,terminal=measured[-1],tangent=tangent[-1],peak_disagreement=fractional(measured,tangent)))
    table("log-forecast-accuracy.csv",laws);table("secular-precision.csv",precision);table("amplified-family-check.csv",gain)


if __name__=="__main__":main()
