import sys
from unittest.mock import patch
from local_case import core, guard, np, packet, prior, system, table, verified
from phase_stride import readings

def run(scheme):
    verified()
    core.ep.getcontext().prec = 40
    assert scheme in ("original","adm")
    for flag in (0,1):
        for seed in (0,1,-1):
            guard()
            shell = system(flag,seed,scheme)
            duration = 8.25*np.pi/shell.mu
            fraction = duration/(core.DURATION*32)
            np.testing.assert_allclose(fraction,8.25/4096,rtol=3e-15)
            rows = []
            history = []
            counts = (1,4,33,66,132)
            for count in counts:
                step = duration/count
                advance = core.central.traced.collar.stepper(shell,step)
                delta = np.zeros_like(shell.initial)
                for tick in range(count):
                    if not tick%16:
                        guard()
                    delta = advance(tick*step, delta)
                assert np.isfinite(delta).all()
                history.append(delta)
                for (width,channel),value in readings(shell,delta,duration).items():
                    rows.append(dict(steps=count,flag=flag,seed=seed,scheme=scheme,fraction=fraction,time=duration,width=width,channel=channel,scaled_tide=1024*value))
            stem = f"{scheme}-off{flag}-s{seed}"
            packet(stem+".npz", steps=counts,r=shell.r,delta=history,time=duration)
            table(stem+".csv",rows)
            print(stem,flush=True)

if __name__ == "__main__":
    run(sys.argv[1])
