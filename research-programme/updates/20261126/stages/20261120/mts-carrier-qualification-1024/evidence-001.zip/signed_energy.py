from decimal import getcontext
from itertools import product
from local_case import HERE,guard,np,system,table,verified
from endpoints import D,convert,pack,prod,exponential,square

def density(shell,delta):
    start=shell.initial
    def at(index,imaginary=False):
        base=start[index].imag if imaginary else start[index].real
        change=delta[index].imag if imaginary else delta[index].real
        return convert(base)+convert(change)
    def diff(arr):
        count=arr.shape[-1]
        mirror=np.concatenate((arr[...,2::-1],arr,arr[...,:-4:-1]),axis=-1)
        faces=sum(D(weight)*(mirror[...,3+j:4+j+count]-mirror[...,2-j:3-j+count]) for j,weight in enumerate(shell.weights))/D(shell.dx)
        mirror=np.concatenate((-faces[...,2:0:-1],faces,-faces[...,-2:-4:-1]),axis=-1)
        return sum(D(weight)*(mirror[...,3+j:3+j+count]+mirror[...,2-j:2-j+count]) for j,weight in enumerate(shell.average))
    ell,bend=at(0),at(1)
    unit=pack(0*ell[0]+1)
    volume=exponential(-ell-2*bend)
    normal=exponential(-ell)
    total=at(17)
    for spec in range(3 if shell.flag else 2):
        number,phase=at(8+2*spec),at(9+2*spec)
        speed=square(prod(normal,diff(phase)))
        root=np.sqrt(1+speed[0])
        piece=D(float(shell.rho[spec]))*prod(volume,prod(number,pack(root,speed[1]/(2*root))))
        total+=piece
    if not shell.flag:
        amplitude,phase,velocity,velocity_i=at(14),at(14,True),at(15),at(15,True)
        mu=D(float(shell.mu))
        grad=prod(square(normal),square(diff(amplitude))+square(diff(phase)))/mu**2
        piece=D(float(shell.rho[-1]))/2*prod(exponential(2*amplitude),unit+square(velocity+at(4)/(2*mu))+square(velocity_i-unit)+grad)
        total+=piece
    return np.stack((piece,total))

def main():
    verified()
    getcontext().prec=46
    rows=[]
    for scheme in ("original","adm"):
        profiles={}
        for flag,seed in product((0,1),(0,1,-1)):
            guard()
            shell=system(flag,seed,scheme)
            use=(shell.r>.6)&(shell.r<2.1)
            launch=density(shell,np.zeros_like(shell.initial))[:,:,use]
            with np.load(HERE/f"{scheme}-off{flag}-s{seed}.npz") as bank:
                for count,delta in zip(bank["steps"],bank["delta"],strict=True):
                    profiles[flag,seed,count]=density(shell,delta)[:,:,use]-launch
        for seed in (1,-1):
            def contrast(count):
                return ((profiles[0,seed,count]-profiles[0,0,count])-(profiles[1,seed,count]-profiles[1,0,count]))
            ref=contrast(132)
            for count in (1,4,33,66):
                error=contrast(count)-ref
                for label,field in enumerate(("heavy_energy","total_energy")):
                    for slot in (0,1):
                        norm=lambda arr: np.linalg.norm(arr[label,slot].astype(float))/np.sqrt(arr.shape[-1])
                        absolute,scale=norm(error),norm(ref)
                        rows.append(dict(scheme=scheme,seed=seed,quantity=field,ell=2*slot,steps=count,reference_steps=132,reference_rms=scale,error_rms=absolute,relative=absolute/scale if scale else ""))
    table("decimal-signed-energy.csv",rows)
    print(len(rows),"signed energy comparisons; cancelled before conversion to binary64")

if __name__=="__main__":
    main()
