from local_case import HERE,core,guard,np,prior,system,table,verified
from carrier_readings import cross,energy,length_change,minus_one

pair,mul,exp=prior.pair,prior.mul,prior.exp

def changes(shell,delta):
    values=energy(shell,delta)
    if shell.flag:
        return values
    ell=shell.initial[0].real
    dell=delta[0].real
    wave,zeta=shell.initial[14:16]
    dwave,dzeta=delta[14:16]
    velocity=zeta+shell.initial[4].real/(2*shell.mu)
    dvel=dzeta+delta[4].real/(2*shell.mu)
    values["rest_subtracted_wave_momentum"]=mul(exp(wave),mul(minus_one(dwave),velocity)+mul(exp(dwave),dvel))
    values["normal_log_velocity"]=dvel
    initial_grad=shell.diff(wave.real)+1j*shell.diff(wave.imag)
    change_grad=shell.diff(dwave.real)+1j*shell.diff(dwave.imag)
    grad=mul(exp(-ell),initial_grad)/shell.mu
    dgrad=mul(exp(-ell),mul(minus_one(-dell),initial_grad)+mul(exp(-dell),change_grad))/shell.mu
    kinetic=cross(velocity,velocity)+cross(grad,grad)
    dk=length_change(velocity,dvel)+length_change(grad,dgrad)
    density=shell.rho[-1]*exp(2*wave.real)
    density_ratio=exp(2*dwave.real)
    excess=mul(density,mul(minus_one(2*dwave.real),kinetic)+mul(density_ratio,dk))/2
    rest_charge=mul(density,mul(minus_one(2*dwave.real),pair(np.ones_like(shell.r))-zeta.imag)-mul(density_ratio,dzeta.imag))
    np.testing.assert_allclose(values["heavy_energy"],rest_charge+excess,rtol=1e-13,atol=1e-62)
    values["energy_above_charge"]=excess
    return values

def run():
    verified()
    output=[]
    for scheme in ("original","adm"):
        profiles={}
        for flag in (0,1):
            for seed in (0,1,-1):
                guard()
                shell=system(flag,seed,scheme)
                with np.load(HERE/f"{scheme}-off{flag}-s{seed}.npz") as bank:
                    for count,delta in zip(bank["steps"],bank["delta"],strict=True):
                        for name,val in changes(shell,delta).items():
                            profiles[flag,seed,name,count]=val[:,(shell.r>.6)&(shell.r<2.1)]
        for name in ("normal_wave_momentum","rest_subtracted_wave_momentum","normal_log_velocity","energy_above_charge","heavy_energy","total_energy"):
            for seed in (1,-1):
                def contrast(count):
                    val=profiles[0,seed,name,count]-profiles[0,0,name,count]
                    if name in ("heavy_energy","total_energy"):
                        val=val-(profiles[1,seed,name,count]-profiles[1,0,name,count])
                    return val
                ref=contrast(132)
                for count in (1,4,33,66):
                    diff=contrast(count)-ref
                    for ell in (0,1):
                        denominator=np.linalg.norm(ref[ell])/np.sqrt(ref.shape[1])
                        err=np.linalg.norm(diff[ell])/np.sqrt(ref.shape[1])
                        output.append(dict(scheme=scheme,seed=seed,quantity=name,ell=ell*2,steps=count,reference_steps=132,
                            matched_dust_subtracted=name in ("heavy_energy","total_energy"),reference_rms=denominator,error_rms=err,relative=err/denominator if denominator else ""))
    table("excitation-and-energy.csv",output)
    print(len(output),"signed excitation and energy comparisons")

if __name__=="__main__":
    run()
