import csv
import io
import json
import sys
from pathlib import Path
from unittest.mock import patch

HERE = Path(__file__).resolve().parent
PRIOR = HERE.parent / "mts-independent-speed-128-20261120"
sys.path.insert(0, str(PRIOR))
import speed_case as prior
import evolve_speed
from speed_case import core, np
from launch_data import inputs, prepare

def guard():
    prior.guard()
    if (HERE / "STOP-REQUESTED").exists():
        raise RuntimeError("owner stop")

def verified():
    guard()
    seal = PRIOR / "seal.json"
    assert core.sha(seal) == "30c453a9aecb635f2f74d6863dce04089c53b077240eae3c228ddb3cc1b1b8c6"
    files = json.loads(seal.read_bytes())["files"]
    for name in ("evolve_speed.py", "speed_case.py", "prepare_speed.py", "frozen-q128.csv", "phase_stride.py", *(f"launch-s{seed}.csv" for seed in (0,1,-1))):
        assert core.sha(PRIOR / name) == files[name]
    prior.frozen()

def save(name, content):
    guard()
    path = HERE / name
    if path.exists():
        assert path.read_bytes() == content, path
        return
    temporary = path.with_suffix(path.suffix + ".partial")
    with temporary.open("xb") as stream:
        stream.write(content)
    temporary.rename(path)

def packet(name, **fields):
    stream = io.BytesIO()
    np.savez_compressed(stream, **fields)
    save(name, stream.getvalue())

def table(name, rows):
    stream = io.StringIO(newline="")
    writer = csv.DictWriter(stream, fieldnames=list(rows[0]), lineterminator="\n")
    writer.writeheader()
    writer.writerows(rows)
    save(name, stream.getvalue().encode())

def prepare_all():
    verified()
    green = prior.load_integrator()
    sim = prior.sphere(144, 5)
    rows = []
    for seed in (0, 1, -1):
        state = prior.start_state(sim, 144, 5, seed)
        for flag in (0, 1):
            guard()
            ref, pressure, _ = core.family.pressure(flag)
            grid, shapes, supply = inputs(sim, state, 144, 5, flag, ref, pressure)
            green.attach(grid, 32)
            with patch.object(core.family, "ResolvingSlice", green.Slice):
                data, obj = prepare(sim, state, grid, shapes, supply, ref, pressure, 1024, flag)
            previous, _, _ = evolve_speed.launch(128, flag, seed)
            with np.load(previous) as old:
                for field, power in (("n",0),("v",-.5),("rho",-1),("R",-1),("P",-2),("mu",.5),("s0",-2),("e0",-1),("native_stress",-2),("native_cross",-2),("weight",0)):
                    np.testing.assert_allclose(data[field], 8.0**power * old[field], rtol=1e-13, atol=1e-75, err_msg=field)
            sources, bounds, errors = [], [], []
            for degree, nodal in ((0,obj.f0), (2,obj.f2)):
                _, values, _, boundary = grid.lookup[id(nodal)]
                expected = (shapes[1]["chir"] + 3*shapes[1]["chi"]/grid.edge)/1024 if degree else 0.
                np.testing.assert_allclose(boundary, expected, rtol=2e-15, atol=0.)
                source = obj.hsource(degree, *values)
                error = np.max(abs(grid.ops[degree//2].apply(source, boundary)[0]-values[0]))/max(1e-20, np.max(abs(values[0])))
                assert error < 8e-12
                errors.append(error)
                sources.append(source)
                bounds.append(float(boundary))
            bank = f"launch-off{flag}-s{seed}.npz"
            rhs = f"green-rhs-off{flag}-s{seed}.npz"
            packet(bank, **data)
            packet(rhs, src=sources, bc=bounds, t=grid.t, h=grid.h)
            rows.append(dict(seed=seed,flag=flag,bank=bank,source=rhs,bank_sha=core.sha(HERE/bank),source_sha=core.sha(HERE/rhs),boundary=bounds[1],rel_update_max=max(errors)))
    table("launches.csv",rows)
    print("six independent launches checked")

def launch(level, flag, seed):
    assert level == 1024
    entry = next(row for row in core.read(HERE/"launches.csv") if (int(row["flag"]),int(row["seed"]))==(flag,seed))
    bank, rhs = HERE/entry["bank"], HERE/entry["source"]
    assert core.sha(bank)==entry["bank_sha"] and core.sha(rhs)==entry["source_sha"]
    return bank, rhs, (0.,float(entry["boundary"]))

def system(flag, seed, scheme):
    with patch.object(evolve_speed, "launch", launch):
        return evolve_speed.system(1024,160,flag,seed,scheme,3)[0]

if __name__ == "__main__":
    prepare_all()
