from decimal import getcontext
from local_case import HERE,core,guard,np,prior,system,table,verified
from endpoints import D,convert,pack,prod,exponential

def components(shell,delta):
    initial=shell.initial
    def field(index,imag=False):
        values=initial[index].imag if imag else initial[index].real
        changes=delta[index].imag if imag else delta[index].real
        return convert(values)+convert(changes)
    radius=convert(shell.r)
    def derivative(values):
        size=values.shape[-1]
        extended=np.concatenate((values[...,2::-1],values,values[...,:-4:-1]),axis=-1)
        face=sum(D(weight)*(extended[...,3+j:3+j+size+1]-extended[...,2-j:2-j+size+1]) for j,weight in enumerate(shell.weights))/D(shell.dx)
        extended=np.concatenate((-face[...,2:0:-1],face,-face[...,-2:-4:-1]),axis=-1)
        return sum(D(weight)*(extended[...,3+j:3+j+size]+extended[...,2-j:2-j+size]) for j,weight in enumerate(shell.average))
    ell,bend,tilt,_,trace,shear,cross,tensor=[field(index) for index in range(8)]
    normal=exponential(-ell)
    angular=np.exp(-bend[0])/radius
    bend_gradient=convert(shell.ref_geometry[1][1])+derivative(convert(delta[1].real))
    surface=prod(normal,2*bend_gradient+pack(2/radius,6*tilt[1]/radius))
    volume=exponential(-ell-2*bend)
    radial_j,polar_j=field(18),field(19)[1].copy()
    for spec in range(3 if shell.flag else 2):
        number,potential=field(8+2*spec),field(9+2*spec)
        rest=D(float(shell.rho[spec]))*prod(number,volume)
        radial_j+=prod(rest,prod(normal,derivative(potential)))
        polar_j+=rest[0]*potential[1]*angular
    if not shell.flag:
        amplitude,phase=field(14),field(14,True)
        mu=D(float(shell.mu))
        moment_r=field(15)+trace/(2*mu)
        moment_i=field(15,True)-pack(0*radius+1)
        density=D(float(shell.rho[-1]))*exponential(2*amplitude)
        radial_j-=prod(density,prod(normal,prod(moment_r,derivative(amplitude))+prod(moment_i,derivative(phase))))/mu
        polar_j-=density[0]*(moment_r[0]*amplitude[1]+moment_i[0]*phase[1])*angular/mu
    radial_res=prod(normal,derivative(shear-2*trace/3))+3*prod(surface,shear)/2-radial_j
    radial_res[1]-=6*angular*cross[1]
    polar_res=normal[0]*(derivative(cross[1])+3*(1/radius+bend_gradient[0])*cross[1])+angular*(-shear[1]/2-2*tensor[1]-3*shear[0]*ell[1]/2-2*trace[1]/3)-polar_j
    ricci,gauss=prior.fixed_tide(shell,initial,delta)
    return dict(ham=6*(gauss-ricci),mom_r=radial_res,mom_theta=pack(0*radius,polar_res))

def run():
    verified()
    getcontext().prec=40
    comparisons=[]
    profiles={}
    for scheme in ("original","adm"):
        for flag in (0,1):
            for seed in (0,1,-1):
                guard()
                shell=system(flag,seed,scheme)
                use=(shell.r>.6)&(shell.r<2.1)
                launch=components(shell,np.zeros_like(shell.initial))
                if seed==1 and scheme=="original":
                    probe=np.zeros_like(shell.initial)
                    shape=prior.pair(.013*np.cos(shell.r),.017*np.sin(shell.r))
                    for index in (2,3,4,5,6,7,9,11,13,15,18,19):
                        probe[index]=shape
                    probe[6:8,0]=0
                    direct=shell.dynamics(0.,shell.initial+probe,True)
                    result=components(shell,probe)
                    for key in result:
                        np.testing.assert_allclose(result[key][:,use].astype(float),direct[key][:,use],rtol=5e-11,atol=5e-15,err_msg=key)
                with np.load(HERE/f"{scheme}-off{flag}-s{seed}.npz") as bank:
                    for count,delta in zip(bank["steps"],bank["delta"],strict=True):
                        selected=components(shell,delta)
                        for key,value in selected.items():
                            profiles[scheme,flag,seed,int(count),key]=(value[:,use]-launch[key][:,use]).astype(float)
    for scheme in ("original","adm"):
        for seed in (1,-1):
            for key in ("ham","mom_r","mom_theta"):
                def contrast(count):
                    return ((profiles[scheme,0,seed,count,key]-profiles[scheme,0,0,count,key])-
                            (profiles[scheme,1,seed,count,key]-profiles[scheme,1,0,count,key]))
                ref=contrast(132)
                for count in (1,4,33,66):
                    error=contrast(count)-ref
                    for harmonic in ((1,) if key=="mom_theta" else (0,1)):
                        scale=np.linalg.norm(ref[harmonic])/np.sqrt(ref.shape[1])
                        absolute=np.linalg.norm(error[harmonic])/np.sqrt(ref.shape[1])
                        comparisons.append(dict(scheme=scheme,seed=seed,quantity=key,ell=harmonic*2,steps=count,reference_steps=132,
                            signed_reference_increment_rms=scale,signed_error_rms=absolute,relative=absolute/scale if scale else ""))
    table("precise-signed-constraints.csv",comparisons)
    print(len(comparisons),"nontrivial high-precision signed comparisons")

if __name__=="__main__":
    run()
