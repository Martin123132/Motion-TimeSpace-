from math import fsum
from unittest.mock import patch
from local_case import HERE,core,guard,table,verified
import detector

def main():
    verified()
    fraction=8.25/4096
    rows=[]
    fields={}
    for steps in (4,8):
        with patch.object(detector,"DURATION",core.DURATION*fraction):
            fields[steps]=detector.evolve(steps)
    for member in core.read(HERE/"short-tide-scores.csv"):
        guard()
        seed,width=int(member["seed"]),float(member["width"])
        def actual(steps):
            bank=fields[steps]
            return fsum(sign*float(bank[host,flag,1.,width][0]) for flag,host,sign in ((0,seed,1),(0,0,-1),(1,seed,-1),(1,0,1)))
        newton=actual(8)
        error=float(member["error"])/abs(newton)*1e6
        refinement=1e6*(actual(4)-newton)/abs(newton)
        rows.append(dict(**member,early_newton=newton,newton_time_check_ppm=refinement,
                    estimated_scale_relative=float(member["estimated_newton_scale"])/abs(newton)-1,
                    direct_error_ppm=error,passes_tide_comparison_only=abs(error)<=20 and abs(refinement)<=20))
    table("matched-clock-tides.csv",rows)
    print("matched Newton",len(rows),max(abs(row["direct_error_ppm"]) for row in rows),max(abs(row["newton_time_check_ppm"]) for row in rows))

if __name__=="__main__":
    main()
