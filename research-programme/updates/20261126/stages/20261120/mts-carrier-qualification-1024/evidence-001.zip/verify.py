import itertools
import json
import sys
from math import fsum,isclose,isfinite
from local_case import HERE,core,np,save,verified

def run(seal=False):
    verified()
    inputs=core.read(HERE/"launches.csv")
    assert {(int(row["flag"]),int(row["seed"])) for row in inputs}==set(itertools.product((0,1),(0,1,-1)))
    members={}
    for row in inputs:
        for field in ("bank","source"):
            assert core.sha(HERE/row[field])==row[field+"_sha"]
        guard_seed,flag=int(row["seed"]),int(row["flag"])
        for scheme in ("original","adm"):
            stem=f"{scheme}-off{flag}-s{guard_seed}"
            with np.load(HERE/(stem+".npz")) as packet:
                assert tuple(packet["steps"])==(1,4,33,66,132)
                assert packet["delta"].shape==(5,20,2,480) and np.isfinite(packet["delta"]).all()
            for line in core.read(HERE/(stem+".csv")):
                key=scheme,flag,guard_seed,float(line["width"]),line["channel"],int(line["steps"])
                assert key not in members
                members[key]=float(line["scaled_tide"])
    assert len(members)==240
    scores=core.read(HERE/"matched-clock-tides.csv")
    assert len(scores)==64 and len({tuple(row[key] for key in ("seed","width","scheme","channel","steps")) for row in scores})==64
    for row in scores:
        seed=int(row["seed"])
        def difference(steps):
            return fsum(sign*members[row["scheme"],flag,host,float(row["width"]),row["channel"],steps] for flag,host,sign in ((0,seed,1),(0,0,-1),(1,seed,-1),(1,0,1)))
        err=(difference(int(row["steps"]))-difference(132))/abs(float(row["early_newton"]))*1e6
        assert isclose(err,float(row["direct_error_ppm"]),rel_tol=2e-15)
        assert (abs(err)<=20 and abs(float(row["newton_time_check_ppm"]))<=20)==(row["passes_tide_comparison_only"]=="True")
    for table,size in (("precise-signed-constraints.csv",80),("excitation-and-energy.csv",192),("decimal-signed-energy.csv",64)):
        rows=core.read(HERE/table)
        assert len(rows)==size and len({tuple(row[k] for k in ("seed","scheme","quantity","ell","steps")) for row in rows})==size
        for row in rows:
            denominator=float(row.get("reference_rms",row.get("signed_reference_increment_rms")))
            error=float(row.get("error_rms",row.get("signed_error_rms")))
            assert denominator>0 and isfinite(error) and isclose(error/denominator,float(row["relative"]),rel_tol=3e-15)
    lmc=HERE.parent/"mts-lmc-axisymmetric-retarded-replay-20261120"/"replay.json"
    assert core.sha(lmc)=="ac3e29395d6ceeeca6a4dfb52528cf429c000dcdd981ddd14650ed9e95840cbf"
    bands=json.loads(lmc.read_bytes())["bands"]
    assert len(bands)==192
    grouped={}
    for row in bands:
        assert (row["low"]<=row["total"]<=row["high"])==row["inside"]==(row["R"]==8.3 and row["component"]=="polar")
        grouped.setdefault((row["model"],row["ground"],row["history"]),set()).add((row["R"],row["z"],row["component"]))
    assert len(grouped)==24 and all(len(keys)==8 for keys in grouped.values())
    files={item.name:core.sha(item) for item in sorted(HERE.iterdir()) if item.name!="seal.json" and item.is_file()}
    assert not any(name.endswith(".partial") for name in files)
    manifest=dict(prior_seal="30c453a9aecb635f2f74d6863dce04089c53b077240eae3c228ddb3cc1b1b8c6",q=1024,carrier_rotations=8.25,tidal_checks=len(scores),input_lmc_sha=core.sha(lmc),files=files)
    if seal:
        save("seal.json",(json.dumps(manifest,indent=2)+"\n").encode())
    assert json.loads((HERE/"seal.json").read_bytes())==manifest
    print(core.sha(HERE/"seal.json"),len(files),"files;",len(bands),"retained LMC decisions checked")

if __name__=="__main__":
    run(sys.argv[1:]==["seal"])
