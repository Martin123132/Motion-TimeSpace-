from math import fsum
from local_case import HERE, PRIOR, core, guard, np, prior, system, table, verified

pair, mul, exp, square = prior.pair, prior.mul, prior.exp, prior.square

def minus_one(field):
    return pair(np.expm1(field[0]), np.exp(field[0])*field[1])

def cross(first, second):
    return mul(first.conj(),second).real

def length_change(initial, increment):
    return 2*cross(initial,increment)+cross(increment,increment)

def energy(shell, delta):
    initial = shell.initial
    unit = pair(np.ones_like(shell.r))
    ell, bend = initial[:2].real
    dell, dbend = delta[:2].real
    normal = exp(-ell)
    volume = exp(-ell-2*bend)
    minus_v = -dell-2*dbend
    total = delta[17].real.copy()
    output = {}
    for spec in range(3 if shell.flag else 2):
        density, phase = initial[8+2*spec:10+2*spec].real
        ddensity, dphase = delta[8+2*spec:10+2*spec].real
        velocity = mul(normal,shell.diff(phase))
        dvel = mul(normal,mul(minus_one(-dell),shell.diff(phase)) + mul(exp(-dell),shell.diff(dphase)))
        squared = unit + square(velocity)
        dsq = length_change(velocity,dvel)
        def root(field):
            base = np.sqrt(field[0])
            return pair(base, field[1]/(2*base))
        gamma = root(squared)
        dgamma = mul(dsq,prior.inv(root(squared+dsq)+gamma))
        rest = mul(volume,density)
        dr = mul(volume,mul(minus_one(minus_v),density)+mul(exp(minus_v),ddensity))
        component = shell.rho[spec]*(mul(dr,gamma)+mul(rest+dr,dgamma))
        total += component
        if shell.flag and spec==2:
            output["heavy_energy"] = component
    if not shell.flag:
        wave, zeta = initial[14:16]
        dwave, dzeta = delta[14:16]
        unit_velocity = zeta+initial[4].real/(2*shell.mu)-1j*unit
        dvel = dzeta+delta[4].real/(2*shell.mu)
        output["normal_wave_momentum"] = mul(exp(wave),mul(minus_one(dwave),unit_velocity)+mul(exp(dwave),dvel))
        initial_grad = shell.diff(wave.real)+1j*shell.diff(wave.imag)
        delta_grad = shell.diff(dwave.real)+1j*shell.diff(dwave.imag)
        field_grad = mul(normal,initial_grad)/shell.mu
        dgrad = mul(normal,mul(minus_one(-dell),initial_grad)+mul(exp(-dell),delta_grad))/shell.mu
        kinetic = unit+cross(unit_velocity,unit_velocity)+cross(field_grad,field_grad)
        dk = length_change(unit_velocity,dvel)+length_change(field_grad,dgrad)
        heavy = shell.rho[-1]/2*mul(exp(2*wave.real),mul(minus_one(2*dwave.real),kinetic)+mul(exp(2*dwave.real),dk))
        output["heavy_energy"] = heavy
        total += heavy
    output["total_energy"] = total
    return output

def diagnostics(shell, delta, time, launch_constraints):
    fields = energy(shell,delta)
    details = shell.dynamics(time,shell.initial+delta,True)
    for name in ("ham","mom_r","mom_theta"):
        fields["change_"+name] = details[name]-launch_constraints[name]
        fields["absolute_"+name] = details[name]
    return fields

def check_formula(shell):
    from constraint_rate import spatial
    import mpmath as mp
    def primitive(change,scope):
        ids=np.flatnonzero(scope)
        def collect(state):
            values={idx:state[idx].real for idx in (0,1,4,8,10,12,14,15,17)}
            for index in (9,11,13,14):
                values["dr"+str(index)]=shell.diff(state[index].real)
            values["dpi"]=shell.diff(state[14].imag)
            values["zi"]=state[15].imag
            return values
        base,offset=collect(shell.initial),collect(change)
        result=[]
        with mp.workdps(65):
            axis=mp.mpc(0,"1e-27")
            for idx in ids:
                def absolute_on_axis(moved):
                    def at(key):
                        return sum(axis**ell*(mp.mpf(float(base[key][ell,idx]))+moved*mp.mpf(float(offset[key][ell,idx]))) for ell in (0,1))
                    inverse=mp.exp(-at(0))
                    volume=inverse*mp.exp(-2*at(1))
                    total=at(17)
                    for spec in range(3 if shell.flag else 2):
                        total+=float(shell.rho[spec])*at(8+2*spec)*volume*mp.sqrt(1+(inverse*at("dr"+str(9+2*spec)))**2)
                    if not shell.flag:
                        grad=inverse**2*(at("dr14")**2+at("dpi")**2)/mp.mpf(float(shell.mu))**2
                        velocity=(at(15)+at(4)/(2*shell.mu))**2+(at("zi")-1)**2
                        total+=float(shell.rho[-1])/2*mp.exp(2*at(14))*(1+velocity+grad)
                    return total
                value=absolute_on_axis(1)-absolute_on_axis(0)
                result.append((float(value.real),float(value.imag/axis.imag)))
        return np.array(result).T
    def absolute(state):
        trace, radial = state[4:6].real
        return (spatial(shell,state[:4].real)+2*square(trace)/3-1.5*square(radial)-core.ham(shell,state))/2
    probe = np.zeros_like(shell.initial)
    pattern = pair(.008*np.cos(shell.r),.011*np.cos(shell.r*.7))
    for index in (0,1,8,9,10,11,12,13,14,15):
        probe[index] = pattern*(1+.005*index)
    if not shell.flag:
        probe[14:16] *= 1+.4j
    delta = energy(shell,probe)["total_energy"]
    scope=(shell.r>.6)&(shell.r<2.1)
    direct = primitive(probe,scope)
    np.testing.assert_allclose(direct,delta[:,scope],rtol=3e-12,atol=1e-24)
    probe[:2] = 0.
    delta = energy(shell,probe)["total_energy"]
    direct = absolute(shell.initial+probe)-absolute(shell.initial)
    np.testing.assert_allclose(direct[:,scope],delta[:,scope],rtol=3e-12,atol=1e-24)
    zero = energy(shell,np.zeros_like(shell.initial))
    assert all(not np.any(value) for value in zero.values())

def main():
    verified()
    core.ep.getcontext().prec=40
    counts=(1,4,33,66,132)
    comparisons, members, scores = [], {}, []
    quarter_norm = {(int(row["seed"]),float(row["width"])):abs(float(row["full_newton"])) for row in core.read(PRIOR/"frozen-q128.csv") if float(row["fraction"])==.25}
    for scheme in ("original","adm"):
        for flag in (0,1):
            for seed in (0,1,-1):
                guard()
                shell=system(flag,seed,scheme)
                if seed==1 and scheme=="original":
                    check_formula(shell)
                start=shell.dynamics(0.,shell.initial,True)
                stem=f"{scheme}-off{flag}-s{seed}"
                with np.load(HERE/(stem+".npz")) as bank:
                    assert np.array_equal(bank["r"],shell.r) and tuple(bank["steps"])==counts
                    snapshots=bank["delta"]
                    assert snapshots.shape==(5,20,2,480) and np.isfinite(snapshots).all()
                    fields=[diagnostics(shell,change,float(bank["time"]),start) for change in snapshots]
                for row in core.read(HERE/(stem+".csv")):
                    key=(scheme,flag,seed,int(row["steps"]),float(row["width"]),row["channel"])
                    assert key not in members
                    members[key]=float(row["scaled_tide"])
                interior=(shell.r>.6)&(shell.r<2.1)
                for index,count in enumerate(counts[:-1]):
                    for name,ref in fields[-1].items():
                        for mode in (0,1):
                            vals=ref[mode,interior]
                            diff=fields[index][name][mode,interior]-vals
                            norm=float(np.linalg.norm(vals)/np.sqrt(vals.size))
                            error=float(np.linalg.norm(diff)/np.sqrt(vals.size))
                            comparisons.append(dict(scheme=scheme,seed=seed,flag=flag,steps=count,reference_steps=132,quantity=name,ell=2*mode,
                                reference_rms=norm,error_rms=error,relative_error=(error/norm if norm else "")))
    assert len(members)==240
    for scheme in ("original","adm"):
        for seed in (1,-1):
            for width in (.15,.3):
                scale=quarter_norm[seed,width]*(8.25/4096)/.25
                for channel in ("gauss","ricci"):
                    def contrast(count):
                        return fsum(sign*members[scheme,flag,host,count,width,channel] for flag,host,sign in ((0,seed,1),(0,0,-1),(1,seed,-1),(1,0,1)))
                    for count in counts[:-1]:
                        trial, ref=contrast(count),contrast(132)
                        diff=trial-ref
                        scores.append(dict(scheme=scheme,seed=seed,width=width,channel=channel,steps=count,reference_steps=132,trial=trial,reference=ref,error=diff,
                            estimated_newton_scale=scale,error_ppm=1e6*diff/scale,within_screen=abs(diff)<=20e-6*scale))
    assert len(scores)==64
    table("short-tide-scores.csv",scores)
    table("short-field-scores.csv",comparisons)
    for count in counts[:-1]:
        print(count, max(abs(row["error_ppm"]) for row in scores if row["steps"]==count))

if __name__=="__main__":
    main()
