import coupled
from base import *
from coupled import CoupledMatter
from material import subdivide
from independent import constraints
from transport_error import compute
from trace_run import run as trace

BASE="end-g3-n8-balanced"
TAG=BASE+"-labels2"
def load(name):return json.loads((ROOT/name).read_bytes())
def forecast():
    assert not (ROOT/(TAG+".npz")).exists()
    seed,state,a,grid,waves=coupled.setup("end",3,"balanced")
    cases=[(state,a,waves)]
    with np.load(ROOT/(BASE+"-restart.npz"),allow_pickle=False) as packet:
        cases.append(({key:packet[key] for key in state if key!="a"},float(packet["epoch_scale"][0]),packet["wave_u"]))
    variations=[]
    for data,at,field in cases:
        sample=CoupledMatter("end",seed,subdivide(data,2),at,grid,field);variations.append(compute(sample,constraints(sample)))
    coarse=load("transport-heavy-end.json")
    expected=-.084*np.mean(variations,axis=0).sum(axis=1)-np.array(coarse["predicted_dust_projection"])
    initial=-.084*(variations[0]-np.array(coarse["initial_and_final_rates"])[0]).sum(axis=1)
    note("label-trial-forecast.json",dict(change=expected.tolist(),initial_only=initial.tolist(),
        prior_error=coarse["raw_discrepancy"],rule="difference of integrated projected-minus-continuum generators on identical saved physical states, no fine trajectory"))
def run():
    assert (ROOT/"label-trial-forecast.json").is_file()
    old=coupled.setup
    def refined(*args):
        seed,data,a,grid,field=old(*args)
        return seed,subdivide(data,2),a,grid,field
    coupled.setup=refined;coupled.tag_suffix="-labels2"
    try:trace("end",3,8,"balanced")
    finally:coupled.setup=old;coupled.tag_suffix=""
    previous=load(BASE+"-trace.json");now=load(TAG+"-trace.json")
    original=np.diff(previous["absolute_residual"]);measured=np.diff(now["absolute_residual"])
    norm=np.max(abs(np.vstack((np.diff(previous["terms"],axis=1),np.diff(previous["prediction"]),np.diff(previous["delta_h"])))),axis=0)
    frozen=np.array(load("label-trial-forecast.json")["change"])
    output=dict(original=original.tolist(),new=measured.tolist(),change=(measured-original).tolist(),
        forecast=frozen.tolist(),forecast_error_on_gr_scale=((measured-original-frozen)/norm).tolist(),
        remaining_on_gr_scale=(measured/norm).tolist())
    note("label-trial-test.json",output);print(output)
if __name__=="__main__":
    if sys.argv[1:]==["freeze"]:forecast()
    elif sys.argv[1:]==["run"]:run()
    else:raise ValueError("use freeze or run")
