import coupled
from base import *
from phase_work import Auditor
from solve import RADII

class Trace(Auditor):
    def snapshot(self,matter,sol,clock,clock_grad,frame):
        mesh=matter.mesh;at=lambda val:mesh.points(val,RADII);a=matter.a;hubble=matter.H
        self.sites=np.r_[RADII,mesh.edge[-1]]
        self.factor=at(1+sol["beta"]);self.lapse=np.exp(at(clock));self.wave=matter.coef
        hubdot=lambda gap:hubble*(matter.seed.H(a*np.exp(gap))-matter.seed.H(a*np.exp(-gap)))/(2*gap)
        hd=hubdot(1e-6);hd2=hubdot(5e-7)
        pressure_dust=sol["anis"]-matter.coef*matter.gradpower/(1+sol["beta"])**4
        departure=sol["expansion"];vp=sol["vprime"]
        geometric=((clock_grad-vp)/mesh.r+.5*vp**2-clock_grad*vp)/(a**2*(1+sol["beta"])**4)
        eta=a*np.exp(clock)
        terms=np.stack((at(a*np.expm1(clock)*hd),at(-1.5*eta*departure*(2*hubble+departure)),
                        at(eta*geometric),at(-.5*eta*pressure_dust)))
        self.observations.append(dict(h=at(departure),nonwave=terms,hubdot_error=abs(hd2-hd)))
    def sample(self,quad,scale,mass):
        zz,pp,dz=quad
        b=np.r_[self.factor,1.]
        var=pp/b**3-zz*b**3
        dyn=(2*np.real((b**3*zz).conj()*var)+abs(var)**2)/b**6
        excess=.5*(dyn[:-1]-dyn[-1]+abs(dz[:-1]/(scale*mass*b[:-1]**2))**2)
        return np.array([-.5*scale*self.lapse*self.wave*excess])
def integrate(tag,items,segments,steps,duration):
    dt=duration/steps;h=np.stack([row["h"] for row in items])
    rates=np.stack([row["nonwave"] for row in items])
    static=dt/6*(rates[:-1:2]+4*rates[1::2]+rates[2::2]).sum(axis=0)
    scalar=np.stack(segments).sum(axis=0)
    terms=np.vstack((static,scalar));forecast=np.sum(terms,axis=0);measured=h[-1]-h[0]
    ratios=lambda terms,measured: (measured-terms.sum(axis=0))/np.maximum.reduce((abs(measured),abs(terms.sum(axis=0)),np.max(abs(terms),axis=0)))
    spans=np.diff(measured);sterms=np.diff(terms,axis=1)
    archive(tag+"-trace-panels.npz",h=h,nonwave=rates,scalar=np.stack(segments),dt=dt)
    note(tag+"-trace.json",dict(order=["background","expansion","geometry","radial_dust_pressure","radial_wave_pressure"],
        terms=terms.tolist(),delta_h=measured.tolist(),prediction=forecast.tolist(),absolute_residual=(measured-forecast).tolist(),
        site_normalized=ratios(terms,measured).tolist(),span_normalized=ratios(sterms,spans).tolist(),
        max_hdot_step_change=max(row["hubdot_error"] for row in items)))
    print("Trace closure",tag,ratios(terms,measured),ratios(sterms,spans),flush=True)
def run(epoch,ref,steps,lift):
    audit=Trace();coupled.observer=audit.snapshot;coupled.step_observer=audit.segment
    try:coupled.run(epoch,ref,steps,lift)
    finally:coupled.observer=None;coupled.step_observer=None
    tag=f"{epoch}-g{ref}-n{steps}-{lift}"+coupled.tag_suffix
    integrate(tag,audit.observations,audit.segments,steps,.084 if epoch=="start" else -.084)
if __name__=="__main__":run(sys.argv[1],int(sys.argv[2]),int(sys.argv[3]),sys.argv[4])
