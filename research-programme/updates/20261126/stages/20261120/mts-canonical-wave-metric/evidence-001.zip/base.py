import hashlib
import io
import json
import os
import sys
from pathlib import Path

for key in ("OPENBLAS_NUM_THREADS","MKL_NUM_THREADS","OMP_NUM_THREADS","BLIS_NUM_THREADS","NUMEXPR_NUM_THREADS"):
    os.environ[key]="1"
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parent
PARENT=ROOT.parent/"mts-spherical-constraint-reconstruction-20261120"
PIN="2d362dfeca022fd68aaebb624a808de41985acfb2667b4bc91a80e5a4ac102d4"
def digest(path):
    with path.open("rb") as stream:return hashlib.file_digest(stream,"sha256").hexdigest()
assert digest(PARENT/"seal.json")==PIN
manifest=json.loads((PARENT/"seal.json").read_bytes())["files"]
for key in ("records.py","panels.py","matter.py","solve.py","independent.py","galerkin.py","material.py","optical.py","history.py"):
    assert digest(PARENT/key)==manifest[key]
sys.path.insert(0,str(PARENT))
from records import np,TOL,fixture,guard as previous_guard
from solve import RADII,contrast
def hold():
    previous_guard()
    if (ROOT/"STOP-REQUESTED").exists():raise RuntimeError("owner hold")
def save(name,value):
    hold();path=ROOT/name
    if path.exists():assert path.read_bytes()==value,path
    else:
        with path.open("xb") as stream:stream.write(value)
def note(name,value):save(name,(json.dumps(value,sort_keys=True,indent=2,allow_nan=False)+"\n").encode())
def archive(name,**packet):
    stream=io.BytesIO();np.savez_compressed(stream,**packet);save(name,stream.getvalue())
