from coupled import CoupledMatter,setup,geometry
from base import *
from solve import Matter,constraints,RADII
from galerkin import projected_rates
from scipy.special import roots_legendre

def compute(matter,sol):
    mesh=matter.mesh;a=matter.a
    u,v,_,up=geometry(matter,sol);vp=sol["vprime"]
    book=np.zeros((2,3))
    nodes,weights=roots_legendre(8)
    for species,(pos,mom,mass) in matter.lab.dust.items():
        disp=np.diff(pos);dmom=np.diff(mom)
        dx,dp=projected_rates(matter,sol,u,up,None,species,"projected-geodesic")
        ddx=np.diff(dx);ddp=np.diff(dp)
        amp=.5*matter.seed.coeff[species]/a**3
        for arm,(low,high) in enumerate(zip(RADII[:-1],RADII[1:])):
            for sign in (-1,1):
                first=sign*pos[:-1];last=sign*pos[1:]
                small=np.minimum(first,last);large=np.maximum(first,last)
                left=np.maximum(low,small);right=np.minimum(high,large)
                bot=np.clip(np.searchsorted(mesh.edge,left,side="right")-1,0,len(mesh.edge)-2)
                top=np.clip(np.searchsorted(mesh.edge,right,side="left"),0,len(mesh.edge)-1)
                count=np.where(right>left,np.maximum(top-bot,0),0)
                members=np.repeat(np.arange(len(pos)-1),count)
                bins=np.arange(len(members))+np.repeat(bot-(np.cumsum(count)-count),count)
                def local(radius,indices):
                    frac=(sign*radius-pos[indices])/disp[indices];moment=mom[indices]+frac*dmom[indices]
                    def sample(field):return mesh.points(field,radius.ravel()).reshape(radius.shape)
                    space=sample(v);clock=sample(u);uprime=sample(up);vprime=sample(vp)
                    p2=(moment*np.exp(space)/a)**2;gamma=np.sqrt(1+p2)
                    speed=moment/a*np.exp(clock+2*space)/gamma
                    kick=-a*np.exp(clock)*sign*(gamma*uprime+p2/gamma*vprime)
                    speed_error=dx[indices]+frac*ddx[indices]-speed
                    kick_error=dp[indices]+frac*ddp[indices]-kick
                    dens=mass[indices]*(indices+frac)**2/(indices**2+indices+1/3)/abs(disp[indices])
                    weight=amp*dens*np.exp(3*space)/radius**2
                    return weight*sign*kick_error,weight*moment*(3*vprime-2/radius)*speed_error,weight*moment*speed_error
                for start in range(0,len(bins),2500):
                    idx=members[start:start+2500];cell=bins[start:start+2500]
                    begin=np.maximum(left[idx],mesh.edge[cell]);end=np.minimum(right[idx],mesh.edge[cell+1])
                    half=(end-begin)[:,None]/2
                    radii=begin[:,None]+half*(1+nodes)
                    force,drift,_=local(radii,idx[:,None])
                    book[arm,0]+=np.sum(force*half*weights);book[arm,1]+=np.sum(drift*half*weights)
                for face,orientation in ((low,1.),(high,-1.)):
                    idx=np.flatnonzero((small<=face)&(face<large))
                    book[arm,2]+=orientation*sum(local(np.full(len(idx),face),idx)[2])
    return book
def run(model,epoch):
    stamp=f"{model}-{epoch}"
    if model=="heavy":
        seed,state,a,grid,waves=setup(epoch,3,"balanced")
        initial=CoupledMatter(epoch,seed,state,a,grid,waves)
        with np.load(ROOT/(epoch+"-g3-n8-balanced-restart.npz"),allow_pickle=False) as pp:
            final=CoupledMatter(epoch,seed,{key:pp[key] for key in state if key!="a"},float(pp["epoch_scale"][0]),grid,pp["wave_u"])
        mats=(initial,final)
    else:
        mats=(Matter("cold",epoch,.00625,.003125,6,24.),)
    results=[compute(mat,constraints(mat)) for mat in mats]
    duration=.084 if epoch=="start" else -.084
    prediction=duration*np.mean(results,axis=0)
    trace=json.loads((ROOT/((epoch+"-g3-n8-balanced" if model=="heavy" else "cold-"+epoch)+"-trace.json")).read_bytes())
    diff=np.diff(trace["absolute_residual"]);wanted=prediction.sum(axis=1)
    norm=np.max(abs(np.vstack((np.diff(trace["delta_h"]),np.diff(trace["prediction"]),np.diff(trace["terms"],axis=1)))),axis=0)
    note("transport-"+stamp+".json",dict(sampled_states=len(mats),force_drift_face_terms=prediction.tolist(),raw_discrepancy=diff.tolist(),
        predicted_dust_projection=wanted.tolist(),remaining=(diff-wanted).tolist(),initial_and_final_rates=np.array(results).tolist(),
        raw_normalized=(diff/norm).tolist(),remaining_normalized=((diff-wanted)/norm).tolist()))
    print(stamp,"raw",diff/norm,"after known projection",(diff-wanted)/norm,flush=True)
if __name__=="__main__":run(*sys.argv[1:])
