from coupled import setup,geometry,field_spline,CoupledMatter
from wave_step import ShellModes,propagate
from base import *
from independent import constraints
from solve import RADII

def sector_probe(epoch,ref,lift,tag):
    seed,state,scale,grid,waves=setup(epoch,ref,lift)
    output=[]
    for point in ("initial","final"):
        if point=="final":
            with np.load(ROOT/(tag+"-restart.npz"),allow_pickle=False) as packet:
                state={key:packet[key] for key in state if key!="a"}
                scale=float(packet["epoch_scale"][0]);waves=packet["wave_u"]
                np.testing.assert_array_equal(grid.r,packet["wave_r"])
        matter=CoupledMatter(epoch,seed,state,scale,grid,waves);mesh=matter.mesh;sol=constraints(matter)
        u,v,_,ugrad=geometry(matter,sol)
        clock,spatial=(mesh.points(vals,grid.r) for vals in (u,v));clock[-1]=spatial[-1]=0.
        slope=mesh.points(np.exp(u-v)*(ugrad-sol["vprime"])/mesh.r,grid.r)
        field=[]
        for sign in ("positive","negative-dephased"):
            projected=propagate(grid,waves,scale,matter.H,seed.mass,clock,spatial,slope,0.,sector=sign)
            field.append(projected)
        quad=(mesh.r>=RADII[0]) & (mesh.r<RADII[-1])
        nc=mesh.r[quad];weights=(mesh.width[:,None]*mesh.wts/2).ravel()[quad]*nc**2
        assert np.max(abs(field[0]+field[1]-waves))/np.max(abs(waves))<1e-12
        def amplitudes(pair):
            pos,mom=(field_spline(grid.r,entry)(nc) for entry in pair)
            return pos,mom
        zp,pp=amplitudes(field[0]);zm,pm=amplitudes(field[1])
        for arm,mask in enumerate((nc<RADII[1],nc>=RADII[1])):
            measure=lambda quantity:float(np.sum(weights[mask]*quantity[mask]))
            pos=measure(abs(zp)**2);neg=measure(abs(zm)**2)
            cross=measure(np.real(zm.conj()*pp+zp.conj()*pm))
            mixed=measure(np.real((zm+zp).conj()*(pm+pp)))
            charge_plus=measure(np.real(zp.conj()*pp));charge_minus=measure(np.real(zm.conj()*pm))
            assert abs(charge_plus+charge_minus+cross-mixed)/abs(mixed)<1e-12
            output.append(dict(point=point,arm=arm,negative_to_positive_field_rms=float(np.sqrt(neg/pos)),
                negative_to_total_shell_bilinear=charge_minus/mixed,interference_to_total_shell_bilinear=cross/mixed))
    note(tag+"-sectors.json",output)
if __name__=="__main__":
    tag=sys.argv[1];epoch,ref,steps,lift=tag.split("-");sector_probe(epoch,int(ref[1:]),lift,tag)
