from base import *
import geodesic_history as cold
from solve import RADII
from trace_run import integrate

def run(epoch):
    obs=[]
    original=cold.flux_lapse
    def instrument(matter,sol):
        slip=original(matter,sol);clock=sol["spatial"]-slip
        mesh=matter.mesh;a=matter.a;hub=matter.H;v=sol["spatial"];vp=sol["vprime"]
        weight=np.exp(4*v-slip)*(2*vp**2+a*a*(1+sol["beta"])**4*sol["anis"])/mesh.r
        correction=mesh.r*np.exp(-4*v+slip)*mesh.primitive(weight,True)
        at=lambda values:mesh.points(values,RADII)
        hd=lambda gap:hub*(matter.seed.H(a*np.exp(gap))-matter.seed.H(a*np.exp(-gap)))/(2*gap)
        curved=(correction/mesh.r-.5*vp**2-vp*correction)/(a*a*(1+sol["beta"])**4)
        eta=a*np.exp(clock);dh=sol["expansion"]
        rates=np.stack([at(a*np.expm1(clock)*hd(1e-6)),at(-1.5*eta*dh*(2*hub+dh)),
            at(eta*curved),at(-.5*eta*sol["anis"])])
        obs.append(dict(h=at(dh),nonwave=rates,hubdot_error=abs(hd(1e-6)-hd(5e-7))))
        return slip
    def compare(name,body):assert body==(PARENT/name).read_bytes(),name
    def compare_note(name,obj):assert json.loads((PARENT/name).read_bytes())==obj
    cold.put=compare;cold.note=compare_note;cold.flux_lapse=instrument
    cold.run(epoch,1,8,"projected-geodesic",.00625)
    assert len(obs)==17
    tag="cold-"+epoch
    integrate(tag,obs,[np.zeros((1,3)) for _ in range(8)],8,.084 if epoch=="start" else -.084)
if __name__=="__main__":run(sys.argv[1])
