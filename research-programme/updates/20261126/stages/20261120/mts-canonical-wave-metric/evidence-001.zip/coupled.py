from base import *
from wave_step import ShellModes,propagate
from independent import Matter,constraints,flux_lapse
from matter import wave_spline
from galerkin import projected_rates
from history import SITES
from scipy.fft import dst
from scipy.interpolate import make_interp_spline
from scipy.integrate import solve_ivp

observer=None
step_observer=None
tag_suffix=""

def field_spline(radius,canonical):
    edge=canonical[-1]/radius[-1]
    coefs=dst(canonical[1:-1]-radius[1:-1]*edge,type=1)/(len(radius)-1)
    origin=edge+np.dot(coefs,np.arange(1,len(radius)-1)*np.pi/radius[-1])
    data=np.r_[origin,canonical[1:]/radius[1:]]
    return make_interp_spline(np.r_[-radius[5:0:-1],radius],np.r_[data[5:0:-1],data],k=5)

class CoupledMatter(Matter):
    def __init__(self,epoch,seed,state,scale,grid,waves):
        super().__init__("heavy",epoch,.00625,.003125,6,24.,prepared=(seed,state,scale))
        self.coef=seed.coeff["wave"]/scale**3
        self.bg-=self.coef
        zz,pp=(field_spline(grid.r,v) for v in waves)
        self.zz=zz(self.rad);self.pp=pp(self.rad);self.dz=zz(self.rad,nu=1)
        self.gradpower=abs(self.dz/(seed.mass*scale))**2
        self.zpower=abs(self.zz)**2;self.ppower=abs(self.pp)**2
        self.jwave=self.coef*np.imag(self.pp.conj()*self.dz)/seed.mass
        self.bgenergy=.5*(abs(waves[0,-1])**2+abs(waves[1,-1])**2)/grid.r[-1]**2
    def sources(self,beta,grad_beta,lift="unused"):
        energy,current,anis=super().sources(beta,grad_beta)
        b=1+beta
        pressure=self.coef*self.gradpower/b**4
        energy+=.5*self.coef*(self.zpower+self.ppower/b**12-2*self.bgenergy)+.5*pressure
        return energy,current+self.jwave/b**6,anis+pressure

def geometry(matter,source):
    mesh=matter.mesh;v=source["spatial"];slip=flux_lapse(matter,source)
    u=v-slip
    density=np.exp(4*v-slip)*(2*source["vprime"]**2+matter.a**2*(1+source["beta"])**4*source["anis"])/mesh.r
    uprime=source["vprime"]+mesh.r*np.exp(-4*v+slip)*mesh.primitive(density,True)
    return u,v,slip,uprime

def snapshot(epoch,seed,state,scale,grid,waves):
    hold()
    matter=CoupledMatter(epoch,seed,state,scale,grid,waves);mesh=matter.mesh
    sol=constraints(matter);u,v,slip,uprime=geometry(matter,sol)
    togrid=lambda val:mesh.points(val,grid.r)
    clock,space=togrid(u),togrid(v);clock[-1]=0.;space[-1]=0.
    slope=togrid(np.exp(u-v)*(uprime-sol["vprime"])/mesh.r)
    rates={}
    for species in ("baryon","cdm"):
        speed,kick=projected_rates(matter,sol,u,uprime,None,species,"projected-geodesic")
        rates[species+"_x"]=speed;rates[species+"_p"]=kick
    measure=mesh.primitive(mesh.r**2*np.real(matter.zz.conj()*matter.pp))
    current=mesh.r**2*np.exp(u-v)*np.imag(matter.zz.conj()*matter.dz)/(scale*seed.mass)
    rest_density=(matter.rest-matter.bg)+matter.coef*(np.real(matter.zz.conj()*matter.pp)-np.real(waves[0,-1].conj()*waves[1,-1])/grid.r[-1]**2)
    grad=mesh.primitive(.5*scale**2*mesh.r**2*rest_density)/mesh.r**2
    newton=-mesh.primitive(grad,True)
    kin=-scale*(matter.H*np.expm1(u)+np.exp(u)*sol["expansion"])
    frame={key:mesh.points(val,SITES) for key,val in (("V",v),("slip",slip),("N",newton),("Vkin",kin))}
    frame["shell"]=np.diff(mesh.points(measure,RADII))
    frame["face"]=mesh.points(current,RADII)
    frame["background"]=waves[:,-1]/grid.r[-1]
    frame["separation"]=np.max(abs(waves[1]-(np.exp(-3*space))*waves[0]))/np.max(abs(waves[0]))
    if observer is not None:
        observer(matter,sol,u,uprime,frame)
    return (clock,space,slope),rates,frame

def setup(epoch,ref,lift):
    seed,state,scale=fixture("heavy",epoch,0)
    raw=Matter("heavy",epoch,.00625,.003125,6,24.,3,prepared=(seed,state,scale),regular=True)
    sol=constraints(raw,lift);grid=ShellModes(np.linspace(0.,24.,(len(raw.lab.r)-1)*2**ref+1))
    psi=wave_spline(raw.lab.r,raw.lab.psi,3,True)(grid.r)
    b=1+raw.mesh.points(sol["beta"],grid.r);b[-1]=1
    waves=np.stack((psi/b**3,psi*b**3) if lift=="balanced" else (psi,psi))*grid.r
    return seed,{k:v for k,v in state.items() if k!="psi"},scale,grid,waves
def shifted(state,rates,step):
    return dict(state,**{key:state[key]+step*val for key,val in rates.items()})

def run(epoch,ref,steps,lift):
    assert epoch in ("start","end") and lift in ("balanced","coordinate") and ref in (0,1,2,3)
    seed,state,scale,grid,waves=setup(epoch,ref,lift)
    duration=.084 if epoch=="start" else -.084
    times=np.linspace(0.,duration,steps+1)
    calendar=solve_ivp(lambda _,val:val**2*seed.H(float(val[0])),(0.,duration),[scale],
        rtol=1e-13,atol=1e-15,method="DOP853",max_step=.01,dense_output=True).sol
    def cosm(at):
        value=float(calendar(at)[0])
        return value,seed.H(value)
    tag=f"{epoch}-g{ref}-n{steps}-{lift}"+tag_suffix
    frames=[];half_flux=[]
    for idx,at in enumerate(times):
        hold();a,hub=cosm(at)
        metric,rates,frame=snapshot(epoch,seed,state,a,grid,waves)
        frames.append(frame)
        if not idx:
            note(tag+"-freeze.json",dict(eta=0.,radii=RADII.tolist(),shell=frame["shell"].tolist(),
                face=frame["face"].tolist(),Vdot=np.interp(RADII,SITES,frame["Vkin"]).tolist(),
                a=a,mass=float(seed.mass),lift=lift,initial_wave_mode_intervals=grid.count))
        if idx==steps:break
        delta=times[idx+1]-at;half=at+delta/2
        amid,hmid=cosm(half)
        trial=propagate(grid,waves,a,hub,seed.mass,*metric,delta/2)
        midpoint=shifted(state,rates,delta/2)
        metric_mid,rates_mid,frame_mid=snapshot(epoch,seed,midpoint,amid,grid,trial)
        half_flux.append(frame_mid["face"])
        abar=(a+4*amid+cosm(times[idx+1])[0])/6
        if step_observer is not None:
            step_observer(grid,waves,abar,hmid,seed.mass,metric_mid,delta)
        waves=propagate(grid,waves,abar,hmid,seed.mass,*metric_mid,delta)
        state=shifted(state,rates_mid,delta)
    package={key:np.stack([item[key] for item in frames]) for key in frames[0]}
    archive(tag+".npz",eta=times,r=SITES,a=calendar(times)[0],H=np.array([cosm(at)[1] for at in times]),
        midpoint_faces=np.stack(half_flux),**package)
    archive(tag+"-restart.npz",wave_r=grid.r,wave_u=waves,epoch_scale=calendar(times[-1]),**{key:v for key,v in state.items() if key!="a"})
    print(tag,"saved",flush=True)
if __name__=="__main__":run(sys.argv[1],int(sys.argv[2]),int(sys.argv[3]),sys.argv[4])
