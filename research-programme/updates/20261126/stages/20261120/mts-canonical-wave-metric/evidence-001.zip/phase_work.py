import coupled
from work import shellwork
from base import *
from solve import RADII
from wave_step import propagate
from coupled import field_spline
from scipy.special import spherical_jn,roots_legendre,eval_legendre

class Auditor:
    def __init__(self):
        self.observations=[];self.segments=[]
    def snapshot(self,matter,sol,clock,clock_grad,frame):
        self.observations.append(shellwork(matter,sol,clock,clock_grad,frame))
        mesh=matter.mesh;mask=(mesh.r>RADII[0])&(mesh.r<RADII[-1])
        sites=mesh.r[mask];self.split=sites<=RADII[1]
        self.sites=np.r_[sites,RADII]
        self.weights=(mesh.width[:,None]*mesh.wts/2).ravel()[mask]*sites**2
        self.dens=lambda val:np.r_[val[mask],mesh.points(val,RADII)]
        self.factor=self.dens(1+sol["beta"]);self.lapse=np.exp(self.dens(clock))
        self.expansion=self.dens(matter.H+sol["expansion"]);self.uprime=self.dens(clock_grad)
    def sample(self,quad,scale,mass):
        zz,pp,dz=quad;b=self.factor
        var=pp/b**3-zz*b**3
        eps=(abs(var)**2+abs(dz)**2*b**2/(scale*mass)**2)/2
        trace=1.5*(2*np.real((b**3*zz).conj()*var)+abs(var)**2)-.5*abs(dz)**2*b**2/(scale*mass)**2
        full=self.lapse*np.imag(pp.conj()*dz)/(scale*mass*b**4)
        kin=self.lapse*np.imag(var.conj()*dz)/(scale*mass*b)
        occupied=self.lapse*b**2*np.imag(zz.conj()*dz)/(scale*mass)
        shell=lambda val:np.array([np.sum((val[:-3]*self.weights)[sel]) for sel in (self.split,~self.split)])
        return np.array([-np.diff(RADII**2*kin[-3:]),shell(-scale*self.lapse*self.expansion*trace),
            shell(-self.uprime*full),-np.diff(RADII**2*occupied[-3:]),shell(eps)])
    def segment(self,grid,waves,scale,hub,mass,metric,delta):
        nodes,weights=roots_legendre(4);kappa=scale*mass*delta
        def evaluate(t,sector):
            moved=propagate(grid,waves,scale,hub,mass,*metric,delta*t,sector=sector)
            pos,mom=(field_spline(grid.r,val) for val in moved)
            return np.stack((pos(self.sites),mom(self.sites),pos(self.sites,nu=1)))
        avg=[];cross=[]
        for t in (1+nodes)/2:
            slow=evaluate(t,"positive");fast=evaluate(t,"negative-dephased")
            mean=self.sample(slow,scale,mass)+self.sample(fast,scale,mass)
            cc=self.sample(slow+fast,scale,mass)-mean
            ss=self.sample(slow+1j*fast,scale,mass)-mean
            avg.append(mean);cross.append(cc-1j*ss)
        phases=np.exp(1j*kappa)*np.array([(2*degree+1)*(1j*np.sign(kappa))**degree*spherical_jn(degree,abs(kappa)) for degree in range(4)])
        cross_weights=weights*np.array([np.dot(phases,[eval_legendre(degree,node) for degree in range(4)]) for node in nodes])
        integral=.5*delta*(np.tensordot(weights,avg,axes=1)+np.tensordot(cross_weights,cross,axes=1).real)
        self.segments.append(integral)
def run(epoch,ref,steps,lift):
    auditor=Auditor();coupled.observer=auditor.snapshot;coupled.step_observer=auditor.segment
    try:coupled.run(epoch,ref,steps,lift)
    finally:coupled.observer=None;coupled.step_observer=None
    tag=f"{epoch}-g{ref}-n{steps}-{lift}"
    assert len(auditor.observations)==2*steps+1 and len(auditor.segments)==steps
    package={key:np.stack([entry[key] for entry in auditor.observations]) for key in auditor.observations[0]}
    archive(tag+"-work.npz",eta=np.linspace(0.,.084 if epoch=="start" else -.084,2*steps+1),**package)
    parts=np.stack(auditor.segments)
    terms=parts.sum(axis=0);net=package["excess"][-1]-package["excess"][0]
    expected=terms[:3].sum(axis=0);scale=np.max(abs(np.vstack((expected,net,terms[:3]))),axis=0)
    charge=package["shell"][-1]-package["shell"][0]
    archive(tag+"-phase-integrals.npz",panels=parts)
    output=dict(kinetic_change=net.tolist(),kinetic_transport=terms[0].tolist(),pressure_work=terms[1].tolist(),
        lapse_work=terms[2].tolist(),residual=(net-expected).tolist(),relative_work_residual=((net-expected)/scale).tolist(),
        charge_difference=(charge-terms[3]).tolist(),positive_excess_min=float(package["excess"].min()))
    note(tag+"-phase-test.json",output);print(output,flush=True)
if __name__=="__main__":run(sys.argv[1],int(sys.argv[2]),int(sys.argv[3]),sys.argv[4])
