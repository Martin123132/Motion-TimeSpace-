from base import *
from independent import Matter,constraints,flux_lapse
from solve import RADII,contrast

def run():
    data=[]
    for model in ("cold","heavy"):
        for epoch in ("start","end"):
            for outer in (12.,24.):
                hold()
                matter=Matter(model,epoch,.00625,.003125,6,outer,3,regular=True)
                mesh=matter.mesh;sol=constraints(matter);vprime=sol["vprime_edge"];a=matter.a
                anis=float(mesh.points(sol["anis"],np.array([outer]))[0])
                grad=0.
                if matter.wave:
                    wave_grad=(matter.grad-3*sol["gradient"]*matter.psi/(1+sol["beta"]))/(1+sol["beta"])**3
                    pressure=matter.wave*abs(wave_grad/(matter.seed.mass*a*(1+sol["beta"])**2))**2
                    grad=float(mesh.points(pressure,np.array([outer]))[0])
                radial=anis-grad/2
                singular=1/outer-vprime;assert singular>0
                slope=(a*a*radial+vprime**2)/(2*singular)
                fields=[flux_lapse(matter,sol,ex) for ex in (0.,slope)]
                read=[mesh.points(field,RADII) for field in fields]
                far=np.array([outer-v for v in (0.,mesh.width[-1]*.1,mesh.width[-1]*.2)])
                samples=mesh.points(fields[1],far)
                measured=(3*samples[0]-4*samples[1]+samples[2])/(.2*mesh.width[-1])
                result=dict(model=model,epoch=epoch,outer=outer,pressure_8piG=radial,vprime=vprime,slope=slope,
                    trace_defect_original=-a*(.5*radial+.5*(vprime/a)**2),
                    independently_differentiated_slope=-measured,
                    old_contrast=contrast(read[0]),new_contrast=contrast(read[1]),
                    old_clock_span=float(np.diff(read[0])[0]),new_clock_span=float(np.diff(read[1])[0]),
                    mean_lapse_shift_at_probes=float(np.mean(read[0]-read[1])))
                data.append(result)
    note("derived-edge.json",data)
    for row in data:print(row["model"],row["epoch"],row["outer"],row["slope"],row["new_clock_span"]-row["old_clock_span"])
if __name__=="__main__":run()
