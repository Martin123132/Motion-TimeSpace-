from base import *
import csv
from assess import values
from integrals import run as integrate_history

TAGS=[f"{epoch}-{case}" for epoch in ("start","end") for case in ("g1-n8-balanced","g2-n8-balanced","g2-n16-balanced","g2-n8-coordinate","g3-n8-balanced")]
def read(name):return json.loads((ROOT/name).read_bytes())
def csvfile(name,items):
    fp=io.StringIO(newline="")
    writer=csv.DictWriter(fp,items[0],lineterminator="\n")
    writer.writeheader();writer.writerows(items);save(name,fp.getvalue().encode())
def run():
    shell=[];light=[];work=[];traces=[]
    for tag in TAGS:
        item=read(tag+"-test.json")
        integrate_history(tag);budget=read(tag+"-integrated.json")
        for arm in range(2):
            shell.append(dict(run=tag,arm=arm,rate_error=item["rate_residual"][arm],interval_rate_error=budget["canonical"]["relative"][arm],
                charge_error=item["shell_budget"][arm],initial_metric_span_difference=item["initial_span_change_vs_archived"][arm],
                matched_cold_interval_rate_error=budget["cold_geodesic"]["relative"][arm],prior_wave_interval_rate_error=budget["prior_heavy"]["relative"][arm]))
        for arm in range(3):
            light.append(dict(run=tag,arm=arm,received=item["optical"][arm],
                original_change=budget["clock_change"]["actual"][arm],initial_field_only=budget["clock_change"]["initial_field_only"][arm],
                remaining_time_dependence=budget["clock_change"]["remaining_time_dependence"][arm]))
        phase=ROOT/(tag+"-phase-test.json")
        if phase.exists():
            alt=read(tag+"-energy.json");profile=read(phase.name)
            for arm in range(2):
                low=profile["pressure_work"][arm];geometry=profile["lapse_work"][arm]
                trans=profile["kinetic_transport"][arm];change=profile["kinetic_change"][arm]
                norm=max(abs(change),abs(trans),abs(low),abs(geometry),abs(trans+low+geometry))
                work.append(dict(run=tag,arm=arm,actual=change,flux=trans,pressure_work=low,lapse_work=geometry,
                    direct_sample_error=alt["relative_work_residual"][arm],phase_resolved_error=profile["relative_work_residual"][arm],
                    no_pressure_work=(change-trans-geometry)/norm,no_lapse_work=(change-trans-low)/norm))
    for tag in ("cold-start","cold-end","start-g3-n8-balanced","end-g3-n8-balanced"):
        trace=read(tag+"-trace.json")
        for kind in ("site","span"):
            matrix=np.array(trace["terms"]);observed=np.array(trace["delta_h"])
            if kind=="span":matrix=np.diff(matrix,axis=1);observed=np.diff(observed)
            prediction=matrix.sum(axis=0);norm=np.max(abs(np.vstack((observed,prediction,matrix))),axis=0)
            for idx,residual in enumerate(trace[kind+"_normalized"]):
                traces.append(dict(run=tag,readout=kind,idx=idx,observed=observed[idx],predicted=prediction[idx],
                    residual=residual,without_radial_pressure=(observed[idx]-sum(matrix[:3,idx]))/norm[idx]))
    csvfile("shell-score.csv",shell);csvfile("clock-score.csv",light)
    csvfile("work-score.csv",work);csvfile("trace-score.csv",traces)
if __name__=="__main__":run()
