from assess import values,links
from base import *
from solve import RADII
from scipy.integrate import simpson

def integrated(packet):
    order=np.argsort(abs(packet["eta"]))
    times=packet["eta"][order]
    idx=[np.argmin(abs(packet["r"]-radius)) for radius in RADII]
    spans=np.diff(packet["V"][order][:,idx],axis=1)
    pred=np.diff(packet["Vkin"][order][:,idx],axis=1)
    total=simpson(pred,x=times,axis=0);measured=spans[-1]-spans[0]
    scale=np.maximum.reduce((abs(measured),abs(total),abs(np.ptp(times)*packet["a"][order][0]*packet["H"][order][0]*spans[0])))
    return dict(measured=measured.tolist(),predicted=total.tolist(),
        relative=((measured-total)/scale).tolist(),quadrature=((total-simpson(pred[::2],x=times[::2],axis=0))/scale).tolist(),scale=scale.tolist())

def run(tag):
    epoch=tag.split("-")[0]
    main=values(ROOT/(tag+".npz"))
    env=values(PARENT/f"history-heavy-{epoch}-g2-n8-rc0.00625-L24-balanced-regular.npz")
    cold=values(PARENT/f"live-cold-{epoch}-labels1-n8-projected-geodesic-rc0.00625.npz")
    correction={}
    assert np.array_equal(main["r"],env["r"])
    root_env=np.argmin(abs(env["eta"]))
    trial=dict(env)
    for key in ("V","slip","N"):
        trial[key]=env[key]+(main[key][0]-env[key][root_env])
    lfull=links(main)["constraint"];lfixed=links(trial)["constraint"];lold=links(env)["constraint"]
    correction=dict(actual=(lfull-lold).tolist(),initial_field_only=(lfixed-lold).tolist(),
        remaining_time_dependence=(lfull-lfixed).tolist())
    note(tag+"-integrated.json",dict(canonical=integrated(main),prior_heavy=integrated(env),
        cold_geodesic=integrated(cold),clock_change=correction))
if __name__=="__main__":run(sys.argv[1])
