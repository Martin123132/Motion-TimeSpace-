from base import *

def run():
    radius=np.geomspace(.87,12.,120);mass=.7
    rows=[]
    for charge in (0.,.3,.7):
        half=(mass**2-charge**2)/4
        spatial_factor=1+mass/radius+half/radius**2
        vprime=(mass/radius**2+2*half/radius**3)/spatial_factor
        difference=2*half/(radius**3*(1-half/radius**2))
        uprime=vprime+difference
        pressure_4pi=-charge**2/(2*(radius*spatial_factor)**4)
        geometric=(difference/radius+.5*vprime**2-uprime*vprime)/spatial_factor**2
        predicted=(pressure_4pi*spatial_factor**2+.5*vprime**2)/(1/radius-vprime)
        scale=np.maximum(abs(pressure_4pi),vprime**2/(2*spatial_factor**2))
        err=max(abs(geometric-pressure_4pi)/scale)
        slope=max(abs(predicted-difference)/np.maximum(abs(vprime),abs(difference)))
        assert max(err,slope)<3e-13
        rows.append(dict(charge=charge,relative_trace=err,relative_slope_error=slope,
            wrong_zero_slope_max=float(max(abs(difference)))))
    note("trace-electrovac.json",rows)
if __name__=="__main__":run()
