from base import np
from scipy.fft import dst,dct
from numpy.polynomial.chebyshev import chebinterpolate

class ShellModes:
    def __init__(self,radius):
        self.r=radius
        self.count=len(radius)-1
        self.mode=np.arange(1,self.count)*np.pi/radius[-1]
        self.linear=radius/radius[-1]
    def stiffness(self,vectors,weight,slope_over_r):
        reduced=vectors-vectors[...,-1:]*self.linear
        coef=dst(reduced[...,1:-1],type=1,axis=-1)/self.count
        cosines=np.zeros_like(vectors)
        cosines[...,1:-1]=coef*self.mode/2
        weighted=dct(cosines,type=1,axis=-1)*weight
        modes=dct(weighted,type=1,axis=-1)[...,1:-1]/self.count
        result=np.zeros_like(vectors)
        result[...,1:-1]=dst(modes*self.mode,type=1,axis=-1)/2+reduced[...,1:-1]*slope_over_r[1:-1]
        return result

def propagate(grid,vectors,scale,hub,mass,clock,space,slope,delta,degree=12,sector="both"):
    omega=scale*mass
    drag=1.5*hub/mass
    weight=np.exp(clock-space)
    multiplier=np.exp(.5*clock+1.5*space)
    small=np.expm1(2*clock)-drag**2
    bound=1.05*(np.max(abs(small))+max(multiplier)**2*(max(weight)*grid.mode[-1]**2+max(abs(slope)))/omega**2)+1e-14
    assert 0<bound<.4
    def scaled(argument):
        return (small*argument+multiplier*grid.stiffness(argument*multiplier,weight,slope)/omega**2)/bound
    phase=omega*delta
    def functions(nodes):
        shift=bound*nodes
        root=np.sqrt(1+shift)
        slow=phase*shift/(root+1)
        pos=np.exp(-1j*slow)
        if sector=="both":neg=np.exp(2j*phase)*pos.conj()
        elif sector=="positive":neg=np.zeros_like(pos)
        elif sector=="negative-dephased":neg,pos=pos.conj(),np.zeros_like(pos)
        else:raise ValueError(sector)
        average=(pos+neg)/2
        signed=(pos-neg)/(2*root)
        return np.array([average+1j*drag*signed,signed,(1+shift+drag**2)*signed,average-1j*drag*signed]).T
    poly=chebinterpolate(functions,degree)
    xcoord=vectors[0]/multiplier;ycoord=vectors[1]*multiplier
    def combine(index):
        aa,ab,ba,bb=poly[index]
        return np.stack((aa*xcoord+ab*ycoord,ba*xcoord+bb*ycoord))
    later=combine(degree);older=np.zeros_like(later)
    for idx in range(degree-1,0,-1):
        older,later=later,2*scaled(later)-older+combine(idx)
    final=scaled(later)-older+combine(0)
    final[0]*=multiplier;final[1]/=multiplier
    assert np.all(np.isfinite(final)) and np.all(final[:,0]==0)
    return final
