import coupled
from base import *
from solve import RADII

def shellwork(matter,sol,clock,clock_grad,frame):
    mesh=matter.mesh;rad=mesh.r;scale=matter.a;coef=scale*matter.seed.mass
    factor=1+sol["beta"];lapse=np.exp(clock);z=matter.zz
    delta=matter.pp/factor**3-z*factor**3
    grad=matter.dz
    small_pressure=abs(grad)**2*factor**2/coef**2
    excess=.5*(abs(delta)**2+small_pressure)
    trace=1.5*(2*np.real((factor**3*z).conj()*delta)+abs(delta)**2)-.5*small_pressure
    energy_current=lapse*np.imag(matter.pp.conj()*grad)/(coef*factor**4)
    kinetic_current=lapse*np.imag(delta.conj()*grad)/(coef*factor)
    pressure_work=-scale*lapse*(matter.H+sol["expansion"])*trace
    gravity_work=-clock_grad*energy_current
    shell=lambda values:np.diff(mesh.points(mesh.primitive(rad**2*values),RADII))
    return dict(excess=shell(excess),pressure=shell(pressure_work),gravity=shell(gravity_work),
        kinetic_face=mesh.points(rad**2*kinetic_current,RADII),full_face=mesh.points(rad**2*energy_current,RADII),
        current_face=frame["face"],shell=frame["shell"])
def run(epoch,ref,steps,lift):
    observations=[]
    def observe(*args):observations.append(shellwork(*args))
    coupled.observer=observe
    try:coupled.run(epoch,ref,steps,lift)
    finally:coupled.observer=None
    assert len(observations)==steps*2+1
    tag=f"{epoch}-g{ref}-n{steps}-{lift}"
    package={key:np.stack([entry[key] for entry in observations]) for key in observations[0]}
    archive(tag+"-work.npz",eta=np.linspace(0.,.084 if epoch=="start" else -.084,2*steps+1),**package)
if __name__=="__main__":run(sys.argv[1],int(sys.argv[2]),int(sys.argv[3]),sys.argv[4])
