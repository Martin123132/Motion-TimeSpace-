from base import *
from assess import values

def evaluate(tag):
    work=values(ROOT/(tag+"-work.npz"))
    delta=float(work["eta"][2]-work["eta"][0])
    def simpson(val):
        return delta/6*(val[:-1:2]+4*val[1::2]+val[2::2]).sum(axis=0)
    diff=work["excess"][-1]-work["excess"][0]
    flux=-np.diff(simpson(work["kinetic_face"]))
    pressure=simpson(work["pressure"]);gravity=simpson(work["gravity"])
    balance=flux+pressure+gravity
    scale=np.maximum.reduce((abs(diff),abs(flux),abs(pressure),abs(gravity),abs(balance)))
    assert (scale>0).all()
    face_scale=max(np.max(abs(work["full_face"])),np.max(abs(work["current_face"])))
    rate=(work["full_face"]-work["current_face"])-work["kinetic_face"]
    assert np.max(abs(rate))/face_scale<1e-12
    return dict(excess_change=diff.tolist(),transport=flux.tolist(),pressure_work=pressure.tolist(),
        lapse_work=gravity.tolist(),residual=(diff-balance).tolist(),relative_work_residual=((diff-balance)/scale).tolist(),
        kinetic_work_scale=scale.tolist(),rest_subtracted_face_identity=float(np.max(abs(rate))/face_scale))
if __name__=="__main__":
    tag=sys.argv[1];result=evaluate(tag);note(tag+"-energy.json",result);print(json.dumps(result))
