from phase_work import Auditor
from coupled import field_spline
from wave_step import ShellModes,propagate
from base import *
from solve import RADII
from scipy.special import roots_legendre

def test(count):
    rad=np.linspace(0.,1.,count+1);grid=ShellModes(rad);mass=20000.;delta=.019
    depth=.0007
    clock=depth*np.cos(np.pi*rad);spatial=np.zeros_like(rad)
    derivative=-np.pi*depth*np.sin(np.pi*rad)
    slope=np.r_[-depth*np.pi**2*np.exp(clock[0]),np.exp(clock[1:])*derivative[1:]/rad[1:]]
    fields=np.stack((np.sin(2*np.pi*rad)+.3j*np.sin(9*np.pi*rad),
                     (.4-.6j)*np.sin(2*np.pi*rad)+(.27+.13j)*np.sin(5*np.pi*rad)))
    fields[:,[0,-1]]=0
    quads=[];weights=[]
    nodes,ww=roots_legendre(8)
    for lo,hi in zip(RADII[:-1],RADII[1:]):
        bins=np.linspace(lo,hi,30)
        half=np.diff(bins)[:,None]/2
        site=bins[:-1,None]+half*(nodes+1)
        quads.append(site.ravel());weights.append((half*ww*site**2).ravel())
    audit=Auditor()
    audit.sites=np.r_[*quads,RADII];audit.weights=np.concatenate(weights);audit.split=np.concatenate(quads)<RADII[1]
    audit.lapse=np.exp(depth*np.cos(np.pi*audit.sites));audit.uprime=-np.pi*depth*np.sin(np.pi*audit.sites)
    audit.factor=np.ones_like(audit.sites);audit.expansion=np.zeros_like(audit.sites)
    def sample(vec):
        field,can=(field_spline(rad,arr) for arr in vec)
        return audit.sample(np.stack((field(audit.sites),can(audit.sites),field(audit.sites,nu=1))),1.,mass)
    met=(clock,spatial,slope)
    after=propagate(grid,fields,1.,0.,mass,*met,delta,degree=20)
    plus=propagate(grid,fields,1.,0.,mass,*met,delta,degree=20,sector="positive")
    minus=propagate(grid,fields,1.,0.,mass,*met,delta,degree=20,sector="negative-dephased")
    recombine=max(abs((after-plus-minus*np.exp(2j*mass*delta)).ravel()))
    audit.segment(grid,fields,1.,0.,mass,met,delta)
    terms=audit.segments[-1];actual=(sample(after)-sample(fields))[-1]
    predicted=terms[:3].sum(axis=0)
    norm=np.maximum.reduce((abs(predicted),abs(actual),abs(terms[0]),abs(terms[2])))
    metric_work=(actual-predicted)/norm
    omit=(actual-terms[0])/norm
    return dict(points=count,fast_phase=2*mass*delta,recombination=recombine,work_error=metric_work.tolist(),without_lapse=omit.tolist())
if __name__=="__main__":
    result=[test(level) for level in (256,512)]
    assert all(rec["recombination"]<5e-13 for rec in result)
    note("static-shell-energy-control.json",result);print(result)
