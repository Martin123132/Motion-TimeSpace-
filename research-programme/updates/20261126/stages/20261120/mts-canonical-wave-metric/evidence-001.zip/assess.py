from base import *
from optical import Movie,ARMS,derivative

def values(path):
    with np.load(path,allow_pickle=False) as packet:
        result={key:packet[key] for key in packet.files}
    assert all(np.isfinite(val).all() for val in result.values())
    return result

def links(packet):
    direction=1 if packet["eta"][-1]>packet["eta"][0] else -1
    data={key:packet[key][::direction] for key in ("eta","a","H","V","slip","N")}
    data["r"]=packet["r"]
    return {which:np.array([Movie(data,which).link(*arm)["received"] for arm in ARMS])
            for which in ("constraint","newton","common")}

def assessment(tag):
    path=ROOT/(tag+".npz")
    p=values(path);early=json.loads((ROOT/(tag+"-freeze.json")).read_bytes())
    epoch,grid,step,lift=tag.split("-")[:4];clock=p["eta"];dt=clock[1]-clock[0]
    assert np.allclose(np.diff(clock),dt,rtol=1e-14,atol=0) and clock[0]==0 and abs(clock[-1])==.084
    sites=[np.argmin(abs(p["r"]-r)) for r in RADII]
    np.testing.assert_array_equal(p["shell"][0],early["shell"]);np.testing.assert_array_equal(p["face"][0],early["face"])
    np.testing.assert_array_equal(np.interp(RADII,p["r"],p["Vkin"][0]),early["Vdot"])
    spans=np.diff(p["V"][:,sites],axis=1)
    speed=derivative(clock,spans);coarse=derivative(clock[::2],spans[::2])
    expected=np.diff(p["Vkin"][0,sites])
    scale=np.maximum.reduce((abs(speed),abs(expected),abs(p["a"][0]*p["H"][0]*spans[0])))
    integral=dt/6*(p["face"][:-1]+4*p["midpoint_faces"]+p["face"][1:]).sum(axis=0)
    trap=dt*(p["face"][:-1]+p["face"][1:]).sum(axis=0)/2
    physical=-np.diff(integral)
    net=p["shell"][-1]-p["shell"][0]
    fluxnorm=np.maximum.reduce((abs(integral[:-1]),abs(integral[1:]),abs(physical),abs(net)))
    wave=links(p)
    cmp=values(PARENT/f"history-heavy-{epoch}-g2-n8-rc0.00625-L24-balanced-regular.npz")
    newton=links(cmp)
    ref=values(PARENT/f"history-heavy-{epoch}-g1-n8-rc0.00625-L24-balanced-regular.npz")
    eq=np.diff(ref["V"][0 if epoch=="start" else -1,sites])
    return dict(tag=tag,tolerance=TOL,wave_grid_intervals=early["initial_wave_mode_intervals"],
        mass_phase_per_step=float(early["a"]*early["mass"]*abs(dt)),metric_rate_forecast=expected.tolist(),
        metric_rate_measured=speed.tolist(),metric_rate_normalizer=scale.tolist(),rate_residual=((speed-expected)/scale).tolist(),
        derivative_stencil=((speed-coarse)/scale).tolist(),shell_change=net.tolist(),integrated_inflow=physical.tolist(),
        flux_scale=fluxnorm.tolist(),shell_budget=((net-physical)/fluxnorm).tolist(),
        quadrature_check=((-np.diff(trap)-physical)/fluxnorm).tolist(),
        initial_span_change_vs_archived=(spans[0]-eq).tolist(),end_span=spans[-1].tolist(),
        independent_quadratures_separation=float(p["separation"].max()),initial_separation=float(p["separation"][0]),
        optical=wave["constraint"].tolist(),optical_slip=(wave["constraint"]-wave["common"]).tolist(),
        net_clock_change_vs_prior_envelope=(wave["constraint"]-newton["constraint"]).tolist(),
        net_clock_change_vs_own_leading=(wave["constraint"]-wave["newton"]).tolist())
if __name__=="__main__":
    tag=sys.argv[1]
    result=assessment(tag);note(tag+"-test.json",result)
    for key in ("rate_residual","shell_budget","quadrature_check","derivative_stencil","net_clock_change_vs_prior_envelope"):
        print(key,result[key])
