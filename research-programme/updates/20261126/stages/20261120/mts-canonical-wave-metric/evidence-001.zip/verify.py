from base import *
from summarize import TAGS,read
from assess import values
from solve import RADII
import csv

def data(name):
    with (ROOT/name).open(newline="") as fp:return list(csv.DictReader(fp))
def maximum(rows,key):return max(abs(float(row[key])) for row in rows)
def peak(items):return float(np.max(abs(np.asarray(items))))
def run():
    hold();assert len(manifest)==108 and all(digest(PARENT/name)==ref for name,ref in manifest.items())
    passed=0
    for tag in TAGS+["end-g3-n8-balanced-labels2"]:
        packet=values(ROOT/(tag+".npz"));restart=values(ROOT/(tag+"-restart.npz"));freeze=read(tag+"-freeze.json")
        assert packet["eta"][0]==0 and np.ptp(packet["eta"])==.084
        assert abs(restart["epoch_scale"][0]-packet["a"][-1])<1e-14
        assert restart["wave_u"].shape==(2,len(restart["wave_r"]))
        assert np.all(restart["wave_u"][:,0]==0)
        for species in ("cdm","baryon"):assert np.all(np.diff(restart[species+"_M"])>0)
        np.testing.assert_array_equal(freeze["face"],packet["face"][0])
        np.testing.assert_array_equal(freeze["shell"],packet["shell"][0])
        np.testing.assert_array_equal(freeze["Vdot"],np.interp(RADII,packet["r"],packet["Vkin"][0]))
        got=read(tag+"-test.json")
        assert got["independent_quadratures_separation"]>1e-8
        assert len(got["optical"])==3 and all(np.isfinite(got["optical"]))
        if tag.endswith("-labels2"):
            passed+=int(peak(got["rate_residual"])<=TOL and peak(got["shell_budget"])<=TOL)
        elif "-g1-" in tag:
            assert peak(got["rate_residual"])>TOL
        else:
            assert peak(got["rate_residual"])<TOL and peak(got["shell_budget"])<TOL
            passed+=1
    controls=read("manufactured.json")
    assert max(controls[key] for key in controls if key!="mass_phase")<3e-10
    assert peak([row["work_error"] for row in read("static-shell-energy-control.json")])<TOL
    assert peak([row["relative_trace"] for row in read("trace-electrovac.json")])<1e-12
    shell=data("shell-score.csv");light=data("clock-score.csv");work=data("work-score.csv");traces=data("trace-score.csv")
    assert (len(shell),len(light),len(work),len(traces))==(20,30,8,20)
    assert maximum(work,"phase_resolved_error")<TOL and maximum(work,"direct_sample_error")>0.1
    assert min(abs(float(row["no_lapse_work"])) for row in work)>TOL
    assert min(abs(float(row["no_pressure_work"])) for row in work)>TOL
    for row in work:
        tag=row["run"];matrix=values(ROOT/(tag+"-phase-integrals.npz"))["panels"].sum(axis=0)
        arm=int(row["arm"])
        np.testing.assert_array_equal(matrix[:3,arm],[float(row[name]) for name in ("flux","pressure_work","lapse_work")])
    assert {r["run"] for r in traces}=={"cold-start","cold-end","start-g3-n8-balanced","end-g3-n8-balanced"}
    assert all(any(abs(float(row["residual"]))>TOL for row in traces if row["run"]==tag)
        for tag in {row["run"] for row in traces})
    trial=read("label-trial-test.json");frozen=read("label-trial-forecast.json")
    np.testing.assert_array_equal(trial["forecast"],frozen["change"])
    assert (ROOT/"label-trial-forecast.json").stat().st_mtime_ns<(ROOT/"end-g3-n8-balanced-labels2.npz").stat().st_mtime_ns
    edges=read("derived-edge.json");assert len(edges)==8 and all(r["slope"]>0 for r in edges)
    for row in edges:
        assert abs(row["independently_differentiated_slope"]-row["slope"])<max(2e-27,TOL*abs(row["slope"]))
    for tag in ("cold-start","cold-end","start-g3-n8-balanced","end-g3-n8-balanced","end-g3-n8-balanced-labels2"):
        trace=read(tag+"-trace.json")
        pp=values(ROOT/(tag+"-trace-panels.npz"))
        np.testing.assert_array_equal(trace["delta_h"],pp["h"][-1]-pp["h"][0])
        integrated=pp["dt"]/6*(pp["nonwave"][:-1:2]+4*pp["nonwave"][1::2]+pp["nonwave"][2::2]).sum(axis=0)
        np.testing.assert_array_equal(trace["terms"],np.vstack((integrated,pp["scalar"].sum(axis=0))))
    for model in ("cold","heavy"):
        for epoch in ("start","end"):
            err=read(f"transport-{model}-{epoch}.json")
            np.testing.assert_allclose(np.sum(err["force_drift_face_terms"],axis=1),err["predicted_dust_projection"],rtol=1e-14,atol=1e-30)
    for path in ROOT.glob("*-sectors.json"):
        for row in read(path.name):assert float(row["negative_to_positive_field_rms"])>0
    assert len(list(ROOT.glob("*-sectors.json")))==4
    good=[r for r in shell if "-g1-" not in r["run"]]
    return dict(time_histories=len(TAGS)+1,refined_time_histories_with_rate_and_flux_inside=passed,
        worst_refined_primary_rate=maximum(good,"rate_error"),worst_refined_charge_budget=maximum(good,"charge_error"),
        worst_refined_integrated_rate=maximum(good,"interval_rate_error"),cold_integrated_rate=maximum(shell,"matched_cold_interval_rate_error"),
        old_wave_integrated_rate=maximum(shell,"prior_wave_interval_rate_error"),worst_phase_resolved_work=maximum(work,"phase_resolved_error"),
        worst_direct_sample_work=maximum(work,"direct_sample_error"),raw_trace_check_max=maximum(traces,"residual"),
        independent_label_forecast_error=trial["forecast_error_on_gr_scale"],final_label_trace=trial["remaining_on_gr_scale"],
        max_edge_span_shift=max(abs(row["new_clock_span"]-row["old_clock_span"]) for row in edges))
if __name__=="__main__":
    assert sys.argv[1:] in ([],["seal"])
    result=run();seal=ROOT/"seal.json"
    if sys.argv[1:]==["seal"]:note("validation.json",result)
    assert result==read("validation.json")
    assert not any(ROOT.rglob("__pycache__"))
    files={path.relative_to(ROOT).as_posix():digest(path) for path in sorted(ROOT.rglob("*")) if path.is_file() and path!=seal}
    expected=dict(files=files,prior=PIN)
    if sys.argv[1:]==["seal"]:note("seal.json",expected)
    assert read("seal.json")==expected
    print(len(files),"local files and",len(manifest),"parent files verified;",digest(seal));print(json.dumps(result,indent=2))
