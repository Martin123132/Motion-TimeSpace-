from base import np,note
from wave_step import ShellModes,propagate
from scipy.linalg import expm

def run():
    rad=np.linspace(0.,2.,65);grid=ShellModes(rad)
    mass=1.1e4;scale=.71;hub=.03;omega=mass*scale;delta=.081;drag=1.5*scale*hub
    shape=np.sin(rad*11*np.pi/rad[-1]);shape[[0,-1]]=0.
    amp=np.array([.9+.3j,.42-.19j]);potential=.00032;space=-.00021
    result=propagate(grid,amp[:,None]*shape,scale,hub,mass,np.full_like(rad,potential),np.full_like(rad,space),rad*0,delta)
    freq=11*np.pi/rad[-1]
    denom=np.exp(-3*space);lapse=np.exp(potential)
    matrix=np.array([[drag+1j*omega,-1j*omega*lapse/denom],
        [-1j*(omega*lapse*denom+freq**2*np.exp(potential-space)/omega),-drag+1j*omega]])
    exact=(expm(delta*matrix)@amp)[:,None]*shape
    gate=np.max(abs(exact-result))
    curvature=.00033
    clock=potential+curvature*np.cos(np.pi*rad/rad[-1])
    slope=np.empty_like(rad);slope[1:]=-curvature*np.pi/rad[-1]*np.sin(np.pi*rad[1:]/rad[-1])*np.exp(clock[1:]-space)/rad[1:]
    slope[0]=-curvature*(np.pi/rad[-1])**2*np.exp(clock[0]-space)
    fields=np.stack((shape,.71j*shape+.32*np.sin(rad*6*np.pi/rad[-1])));fields[:,[0,-1]]=0
    fields[1]+=.41*shape
    new=propagate(grid,fields,scale,hub,mass,clock,space+rad*0,slope,delta)
    recovered=propagate(grid,new,scale,hub,mass,clock,space+rad*0,slope,-delta)
    perturb=np.eye(len(rad))[1:-1]
    stiffness=grid.stiffness(perturb,np.exp(clock-space),slope)[:,1:-1].T
    sym=np.max(abs(stiffness-stiffness.T))/np.max(abs(stiffness))
    cols=np.diag(np.exp(clock[1:-1]));ident=np.eye(len(rad)-2)
    matrix=np.block([[(drag+1j*omega)*ident,-1j*omega*cols/denom],
                     [-1j*(omega*cols*denom+stiffness/omega),(-drag+1j*omega)*ident]])
    dense=(expm(delta*matrix)@fields[:,1:-1].ravel()).reshape(2,-1)
    err=max(abs((dense-new[:,1:-1]).ravel()))
    charge=lambda v:np.vdot(v[0],v[1]).real
    loss=abs(charge(new)/charge(fields)-1)
    rev=max(abs((fields-recovered).ravel()))
    assert max(gate,sym,err,loss,rev)<3e-10,(gate,sym,err,loss,rev)
    note("manufactured.json",dict(both_frequency_sectors_mode_error=gate,matrix_symmetry=sym,
        variable_metric_dense_exponential_error=err,charge_relative=loss,time_reversal=rev,mass_phase=omega*delta))
if __name__=="__main__":run()
