from local import *
from panels import grid
from variational import integrals
from scipy.linalg import solve_banded

SPECIES=("baryon","cdm")
def split(state,ref):
    step=24/7680
    extrema=[]
    for sp in SPECIES:
        coords=state[sp+"_x"];width=np.diff(coords)
        extrema.extend(abs(coords[1:-1][width[:-1]*width[1:]<0]))
    extent=max(extrema,default=0.)+2*step
    output={};details={}
    for sp in SPECIES:
        x=state[sp+"_x"];p=state[sp+"_p"];dm=np.diff(state[sp+"_M"]);dx=np.diff(x)
        crosses=(np.minimum(x[:-1],x[1:])<=extent)&(np.maximum(x[:-1],x[1:])>=-extent)
        target=np.where(crosses,step/max(ref,1),2*step)
        counts=np.maximum(1,np.ceil(abs(dx)/target-1e-12).astype(int)) if ref else np.ones(len(dx),int)
        child=np.repeat(np.arange(len(dx)),counts);ord=np.arange(len(child))-np.repeat(np.cumsum(counts)-counts,counts)
        n=counts[child];lam=child*n+ord;f=ord/n
        mass=dm[child]*(lam**2+lam+1/3)/(n.astype(float)**3*(child**2+child+1/3))
        xx=np.r_[x[child]+dx[child]*f,x[-1]];pp=np.r_[p[child]+np.diff(p)[child]*f,p[-1]]
        np.testing.assert_allclose(np.bincount(child,mass),dm,rtol=2e-14,atol=1e-24)
        assert np.all(mass>0) and np.all(np.diff(xx)!=0)
        _,one,two=integrals(lam,0.,1.,mass);off=one-two
        diag=np.r_[mass-2*one+two,0.]+np.r_[0.,two];mx=np.zeros((3,len(mass)-1))
        mx[1]=diag[1:-1];mx[0,1:]=off[1:-1];mx[2,:-1]=off[1:-1]
        output[sp]=np.array([xx,pp]);details[sp]=(mass,lam.astype(float),mx,child,n)
    return output,details,extent

class Elements:
    def __init__(self,mesh,state,detail,cut):
        x,p=state;mass,lam,self.matrix,_,_=detail;dx=np.diff(x);dp=np.diff(p)
        border=mesh.edge;rad=mesh.r;self.length=len(x)
        self.batches=[]
        gauss=(mesh.width[:,None]*mesh.wts/2).ravel()
        self.mass=mass
        for sign in (-1,1):
            x0=sign*x[:-1];x1=sign*x[1:];low=np.minimum(x0,x1);hi=np.maximum(x0,x1)
            b=np.searchsorted(rad,np.maximum(low,cut));e=np.maximum(b,np.searchsorted(rad,hi));cnt=e-b
            ids=np.repeat(np.arange(len(x0)),cnt);addr=np.repeat(b-(np.cumsum(cnt)-cnt),cnt)+np.arange(len(ids))
            if len(ids):
                frac=(sign*rad[addr]-x[ids])/dx[ids]
                dm=mass[ids]*(lam[ids]+frac)**2/(lam[ids]**2+lam[ids]+1/3)/abs(dx[ids])
                self.batches.append((False,sign,ids,addr,frac,p[ids]+dp[ids]*frac,dm*gauss[addr],dm/rad[addr]**2))
            for first,last in zip(border[:-1],border[1:]):
                if first>=cut:break
                bot=np.maximum(low,first);top=np.minimum(hi,last);ix=np.flatnonzero(top>bot);half=(top[ix]-bot[ix])/2
                rr=(bot[ix,None]+half[:,None]*(1+mesh.nodes)).ravel();ids=np.repeat(ix,len(mesh.nodes))
                if not len(ids):continue
                frac=(sign*rr-x[ids])/dx[ids]
                dm=mass[ids]*(lam[ids]+frac)**2/(lam[ids]**2+lam[ids]+1/3)/abs(dx[ids])*(half[:,None]*mesh.wts).ravel()
                self.batches.append((True,sign,ids,rr,frac,p[ids]+dp[ids]*frac,dm,dm/(cut**3/3)))
        seen=sum(np.bincount(ids,weights=dm,minlength=len(mass)) for _,_,ids,_,_,_,dm,_ in self.batches)
        assert max(abs(seen-mass))<max(mass)*5e-11
    def project(self,mat,source,u,du):
        mesh=mat.mesh;a=mat.a
        fields=np.stack((np.exp(u),np.exp(2*source["spatial"]),du,source["vprime"]))
        rates=np.zeros((2,self.length))
        for core,sign,ids,addr,frac,p,dm,_ in self.batches:
            N,ev,up,vp=(np.stack([mesh.points(val,addr) for val in fields]) if core else fields[:,addr])
            sq=p**2*ev/a**2;g=np.sqrt(1+sq);vel=N*ev*p/(a*g);force=-sign*a*N*(g*up+sq/g*vp)
            for out,val in zip(rates,(vel,force)):
                load=val*dm;out[:-1]+=np.bincount(ids,(1-frac)*load,minlength=len(out)-1)
                out[1:]+=np.bincount(ids,frac*load,minlength=len(out)-1)
        return np.stack([np.r_[0.,solve_banded((1,1),self.matrix,row[1:-1],check_finite=False),0.] for row in rates])

class Dust:
    def initialize(self,state,labels):
        self.cut=.00625
        self.mesh=grid({sp:(state[sp][0],state[sp][1],labels[sp][0]) for sp in SPECIES},self.cut,.003125,6,24.)
        self.rad=self.mesh.r;self.core=self.rad<self.cut;self.iso=(self.rad[self.core]/self.cut)**2
        self.rest=np.zeros_like(self.rad);self.j0=self.rest.copy()
        self.density=[];self.elements={}
        for sp in SPECIES:
            part=Elements(self.mesh,state[sp],labels[sp],self.cut);self.elements[sp]=part
            for core,sign,ids,addr,frac,p,dm,dens in part.batches:
                load=dens*(self.seed.coeff[sp]/self.a**3);mom=sign*p
                if core:
                    self.rest[self.core]+=load.sum();self.j0[self.core]+=self.iso*(load@mom)
                else:
                    self.rest+=np.bincount(addr,load,minlength=len(self.rad));self.j0+=np.bincount(addr,load*mom,minlength=len(self.rad))
                self.density.append((core,addr,p**2/self.a**2,load))
        self.bg=sum(self.seed.coeff[sp] for sp in SPECIES)/self.a**3
    def dust_source(self,beta):
        b=1+beta;energy=np.zeros_like(b);pressure=energy.copy()
        for core,addr,vsq,load in self.density:
            if core:
                sq=vsq[None,:]/b[self.core,None]**4;g=np.sqrt(1+sq)
                energy[self.core]+=(sq/(g+1))@load;pressure[self.core]+=self.iso*((sq/g)@load)
            else:
                sq=vsq/b[addr]**4;g=np.sqrt(1+sq)
                energy+=np.bincount(addr,load*sq/(g+1),minlength=len(b));pressure+=np.bincount(addr,load*sq/g,minlength=len(b))
        return (self.rest-self.bg)+self.rest*np.expm1(-6*np.log1p(beta))+energy/b**6,self.j0/b**6,pressure/b**6

