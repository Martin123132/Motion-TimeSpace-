"""Inventory the two completed material/metric batches without rerunning evolution."""
import hashlib
import json
import math
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parent
PARENT = ROOT.parent / "mts-canonical-stream-kick-20261120"
PARENT_PIN = "a4240ae90083adddb5f19e1ea2c80c42658b569e703568e211868900b8137eb2"
TOL = 2e-5


def digest(path):
    with path.open("rb") as handle:
        return hashlib.file_digest(handle, "sha256").hexdigest()


def packet(path):
    return json.loads(path.read_bytes())


def tags(model):
    return [f"{model}-{epoch}-d{mesh}-on{feedback}-n{steps}-s2-c1-{state}"
            for epoch, mesh, feedback, steps, state in (
                ("end", 2, 0, 8, "uniform"), ("end", 2, 1, 8, "uniform"),
                ("start", 2, 1, 8, "uniform"), ("end", 2, 1, 8, "linear"),
                ("start", 2, 1, 8, "linear"), ("end", 2, 1, 16, "uniform"),
                ("end", 4, 1, 8, "uniform"))]


def main():
    assert not (ROOT / "STOP-REQUESTED").exists() and (ROOT / "checks.json").is_file()
    assert digest(PARENT / "seal.json") == PARENT_PIN
    upstream = packet(PARENT / "seal.json")["files"]
    assert all(digest(PARENT / name) == value for name, value in upstream.items())
    output = []
    forecast = {}
    for model in ("cold", "heavy"):
        for tag in tags(model):
            for suffix in ("metric.npz", "restart.npz", "trace.npz", "events.npz", "inputs.json"):
                assert (ROOT / f"{tag}-{suffix}").is_file(), tag
            score = packet(ROOT / f"{tag}-score.json")
            spans, sites = score["spans"], score["absolute_sites"]
            assert score["tag"] == tag and len(spans) == 4 and len(sites) == 7
            assert score["min_J"] > .5 and score["mass_rule"] < TOL
            if model == "heavy":
                assert (ROOT / f"{tag}-energy.npz").is_file()
                assert all(abs(value) < TOL for value in score["energy"] + score["charge"])
            if tag.endswith("-linear"):
                initial = packet(ROOT / f"{tag}-formation.json")
                assert initial["modes"] == 99 and initial["max_native_source_roundtrip"] < TOL
            errors = [max(abs(row[key]) for row in group) for group in (spans, sites) for key in ("relative", "metric_fraction")]
            assert all(math.isfinite(val) for val in errors)
            output.append([tag, *(round(val * 1e6, 5) for val in errors)])
        tracer = packet(PARENT / f"{model}-end-translated-n16-b1-slow.json")["spatial_and_time_trials"][-1]
        runs = [packet(ROOT / f"{model}-end-d2-on{switch}-n8-s2-c1-uniform-score.json")["spans"] for switch in (0, 1)]
        forecast[model] = []
        for index, (off, on) in enumerate(zip(*runs)):
            predicted = -tracer["slow_drive"][index]
            measured = on["error"] - off["error"]
            current = (on["measured"] - off["measured"]) / tracer["delta_J"][index] - 1
            forecast[model].append(dict(measured=measured, predicted=predicted, fractional_error=measured/predicted-1,
                                        current_forecast_error=current))
    for row in output:
        print(*row)
    print("columns: branch, worst absolute residual in ppm: signed-span trace / metric, absolute-site trace / metric")
    files = {path.name: digest(path) for path in sorted(ROOT.iterdir()) if path.is_file() and path.name != "seal.json"}
    record = dict(predecessor_sha256=PARENT_PIN, predecessor_files_checked=len(upstream), files=files, runs=output, late_source_forecasts=forecast,
                  precision_gate=TOL, scope="finite spherical batch; not an LMC force comparison")
    destination = ROOT / "seal.json"
    if sys.argv[1:] == ["--seal"]:
        with destination.open("x", encoding="utf-8", newline="\n") as handle:
            json.dump(record, handle, sort_keys=True, indent=2, allow_nan=False)
            handle.write("\n")
    elif destination.exists():
        assert packet(destination) == record
    print(len(files), "local files;", len(upstream), "predecessor files;", len(output), "runs")


if __name__ == "__main__":
    main()
