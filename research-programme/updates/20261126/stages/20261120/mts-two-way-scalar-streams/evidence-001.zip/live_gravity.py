from local import *
from sheet_source import SPECIES,split,Dust
from lightfield import Slow,components
from coupled import setup,geometry,propagate,field_spline
from solve import RADII,constraints
from phase_work import Auditor
from trace_run import Trace
from history import SITES as CLOCKS
from types import SimpleNamespace

class Matter(Dust):
    def __init__(self,seed,state,labels,slow,ss,fields,grid,t,feedback):
        self.seed=seed;self.a,self.phi,self.pi=slow.calendar(t);self.H=seed.H(self.a)
        self.initialize(state,labels);self.coef=0.;self.slow=slow;self.feedback=feedback
        self.ss=slow.samples(ss,self.rad)
        if fields is not None:
            self.coef=seed.coeff["wave"]/self.a**3
            zz,pp=[field_spline(grid.r,val) for val in fields]
            self.zz=zz(self.rad);self.pp=pp(self.rad);self.dz=zz(self.rad,1);self.gradpower=abs(self.dz/(seed.mass*self.a))**2
            self.zpower=abs(self.zz)**2;self.ppower=abs(self.pp)**2;self.jwave=self.coef*np.imag(self.pp.conj()*self.dz)/seed.mass
            self.bgenergy=.5*np.sum(abs(fields[:,-1]/grid.r[-1])**2)
    def sources(self,beta,gradient,lift="balanced"):
        energy,current,anis=self.dust_source(beta);b=1+beta
        if self.coef:
            grad=self.coef*self.gradpower/b**4
            energy+=.5*self.coef*(self.ppower/b**12+self.zpower-2*self.bgenergy)+.5*grad
            current+=self.jwave/b**6;anis+=grad
        if self.feedback:
            e,j,pi,_=self.slow_parts(beta);energy+=e;current+=j;anis+=pi
        return energy,current,anis
    def slow_parts(self,beta):
        return components(beta,self.a,self.phi,self.pi,self.slow.mass,self.ss)

def run(model,epoch,res,feedback,steps,gridref,chart_on=1,prep="uniform"):
    from chart import Domain
    from chart_source import Matter as ActiveMatter
    assert model in ("cold","heavy") and epoch in ("start","end") and feedback in (0,1)
    tag=f"{model}-{epoch}-d{res}-on{feedback}-n{steps}-s{gridref}-c{chart_on}-{prep}"
    hold();duration=.084 if epoch=="start" else -.084
    if model=="heavy":seed,original,a0,grid,field=setup(epoch,3,"balanced")
    else:seed,original,a0=fixture(model,epoch,0);grid=field=None
    state,labels,extent=split(original,0);slow=Slow(seed,model,a0,duration,gridref)
    domain=Domain(original,res);chartstate=domain.empty()
    energy=Auditor();trace=Trace();times=np.linspace(0,duration,steps+1)
    events=[];history=[];full=[];sfields=[]
    def body(t,st,wave,ss,live,ds):
        mat=ActiveMatter(domain.fields(ds),seed,st,labels,slow,ss,wave,grid,t,live);sol=constraints(mat);u,v,slip,up=geometry(mat,sol)
        return mat,sol,u,v,slip,up
    blank=np.zeros((2,len(slow.rad)))
    mat,sol,u,v,_,_=body(0,state,field,blank,False,chartstate)
    smetric=slow.metric(mat.mesh,u,v)
    del mat,sol
    ss=slow.uniform(smetric)
    if prep!="uniform":
        from formation import prepare
        ss,receipt=prepare(seed,model,slow,smetric,prep)
        pibg=slow.calendar(0.)[2];normal_excess=ss[1]*np.exp(3*smetric[1])+pibg*np.expm1(3*smetric[1])
        changes=[]
        if feedback:
            for number in range(6):
                first,solution,uu,vv,_,_=body(0,state,field,ss,True,chartstate)
                _,spatial=slow.metric(first.mesh,uu,vv)
                corrected=normal_excess*np.exp(-3*spatial)+pibg*np.expm1(-3*spatial)
                diff=max(abs(ss[1]-corrected))/abs(pibg)
                ss[1]=corrected;changes.append(diff)
                del first,solution
                if diff<2e-14:break
            else:raise ArithmeticError(("initial volume iteration",changes))
        receipt["initial_metric_volume_iteration"]=changes
        note(tag+"-formation.json",receipt)
    note(tag+"-inputs.json",dict(sites=SITES,spans=SPANS,positive_cells={sp:len(labels[sp][0]) for sp in SPECIES},
        original_cells={sp:len(original[sp+"_x"])-1 for sp in SPECIES},mass={sp:sum(labels[sp][0]) for sp in SPECIES},
        max_children={sp:max(labels[sp][-1]) for sp in SPECIES},fold_extent=extent,background_source=slow.digest,
        feedback=feedback,preparation=prep,eta=times))
    def frame(t,st,wave,ss,ds):
        hold();mat,sol,u,v,slip,up=body(t,st,wave,ss,feedback,ds)
        mesh=mat.mesh;a=mat.a;N=np.exp(u);at=lambda x:mesh.points(x,SITES);beta=sol["beta"];vp=sol["vprime"];dh=sol["expansion"]
        rate,B,A=mat.chart.rates(mat,sol,u,up,chart_on)
        rhs={sp:mat.elements[sp].project(mat,sol,u,up,B,A) for sp in SPECIES}
        sk=slow.metric(mesh,u,v);grav=None
        se,sj,sa,spr=mat.slow_parts(beta);hub=mat.H
        hd=hub*(seed.H(a*np.exp(1e-6))-seed.H(a*np.exp(-1e-6)))/2e-6
        rel=up-vp;geom=(rel/mesh.r-.5*vp**2-vp*rel)/(a**2*(1+beta)**4)
        dust=sol["anis"]-(mat.coef*mat.gradpower/(1+beta)**4 if mat.coef else 0.)-feedback*sa
        terms=np.stack([at(a*np.expm1(u)*hd),at(-1.5*a*N*dh*(dh+2*hub)),at(a*N*geom),at(-.5*a*N*dust),at(-.5*a*N*spr)*feedback])
        hist=dict(eta=t,h=at(dh),terms=terms,slow_h=-.5*at(mesh.primitive(sj,True)),slow_pr=at(spr),slow_energy=at(se),slow_anis=at(sa))
        inverse=mat.chart.inverse(SITES);jac=1+mat.chart.d(inverse,1)
        event=dict(eta=t,a=a,lapse=np.exp(at(u)),b=1+at(beta),s=mat.chart.shift.evaluate(inverse),Q=inverse,J=jac,
                   Q_t=-B(inverse)/jac,min_J=mat.chart.minJ,mass_quadrature=max(part.mass_error for part in mat.elements.values()))
        for sp in SPECIES:
            event.update({sp+"_x":st[sp][0],sp+"_p":st[sp][1],"rate_"+sp+"_x":rhs[sp][0],"rate_"+sp+"_p":rhs[sp][1]})
        events.append(event);history.append(hist)
        kin=-a*(hub*np.expm1(u)+N*dh)
        image={key:mesh.points(val,CLOCKS) for key,val in (("V",v),("Vkin",kin),("slip",slip))}
        if grid is not None:
            grav=[mesh.points(col,grid.r) for col in (u,v,np.exp(u-v)*(up-vp)/mesh.r)]
            grav[0][-1]=grav[1][-1]=0.
            q=np.real(mat.zz.conj()*mat.pp)
            face=mesh.points(mesh.r**2*np.exp(u-v)*np.imag(mat.zz.conj()*mat.dz)/(a*seed.mass),RADII)
            energy.snapshot(mat,sol,u,up,dict(face=face,shell=np.diff(mesh.points(mesh.primitive(mesh.r**2*q),RADII))))
            trace.sites=np.r_[SITES,mesh.edge[-1]];trace.factor=1+at(beta);trace.lapse=np.exp(at(u));trace.wave=mat.coef
        return rhs,grav,sk,image,rate
    def shift(st,rates,delta):return {sp:st[sp]+delta*rates[sp] for sp in SPECIES}
    for idx,t in enumerate(times):
        rhs,metric,sm,image,rate=frame(t,state,field,ss,chartstate);full.append(image);sfields.append(ss)
        if idx==steps:break
        dt=times[idx+1]-t;half=t+dt/2;a=slow.calendar(t)[0];amid=slow.calendar(half)[0];hub=seed.H(amid)
        sw=propagate(grid,field,a,seed.H(a),seed.mass,*metric,dt/2) if grid is not None else None
        middle,wm,smid,_,midrate=frame(half,shift(state,rhs,dt/2),sw,slow.advance(t,dt/2,ss,sm),tuple(x+dt/2*r for x,r in zip(chartstate,rate)))
        if grid is not None:
            abar=(a+4*amid+slow.calendar(t+dt)[0])/6
            trace.segment(grid,field,abar,hub,seed.mass,wm,dt)
            energy.segment(grid,field,abar,hub,seed.mass,wm,dt)
            field=propagate(grid,field,abar,hub,seed.mass,*wm,dt)
        ss=slow.advance(t,dt,ss,smid);state=shift(state,middle,dt);chartstate=tuple(x+dt*r for x,r in zip(chartstate,midrate))
    stack=lambda series:{key:np.stack([row[key] for row in series]) for key in series[0]}
    pack(tag+"-trace.npz",**stack(history),scalar_pressure=np.stack(trace.segments) if field is not None else np.zeros((steps,1,len(SITES))))
    pack(tag+"-metric.npz",**stack(full),r=CLOCKS,a=slow.calendar(times)[0],eta=times,H=np.array([seed.H(x) for x in slow.calendar(times)[0]]))
    pack(tag+"-events.npz",**stack(events),**{sp+"_m":labels[sp][0] for sp in SPECIES},**{sp+"_label":labels[sp][1] for sp in SPECIES},
        **{sp+"_c":seed.coeff[sp] for sp in SPECIES})
    pack(tag+"-restart.npz",slow_qd=ss,r_slow=slow.rad,slow_history=np.stack(sfields),scale_phi_pi=slow.calendar(times),
        Q_displacement_grid=domain.d,displacement=chartstate[0],Q_kick_grid=domain.k.r,kick=chartstate[1],
        wave_u=field if field is not None else np.zeros((2,0)),wave_r=grid.r if grid is not None else np.zeros(0),
        **{sp+"_xp":state[sp] for sp in SPECIES},**{sp+"_parent":labels[sp][3] for sp in SPECIES},
        **{sp+"_nchild":labels[sp][4] for sp in SPECIES})
    if field is not None:pack(tag+"-energy.npz",integrals=np.stack(energy.segments),**stack(energy.observations))
    print(tag,"saved",flush=True)
if __name__=="__main__":run(sys.argv[1],sys.argv[2],*(int(k) for k in sys.argv[3:8]),*sys.argv[8:])

