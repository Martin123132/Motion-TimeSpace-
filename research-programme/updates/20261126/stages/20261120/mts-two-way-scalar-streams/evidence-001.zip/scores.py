from local import *
from time_faces import cubic,evalpoly,crossing
from scipy.special import roots_legendre
from scipy.integrate import simpson
from optical import Movie,ARMS

def face(ev,order):
    nodes,weights=roots_legendre(order);out=np.zeros(len(SITES));jumps=np.zeros(len(SITES),int)
    for base in range(0,len(ev["eta"])-1,2):
        sl=slice(base,base+3);dt=ev["eta"][base+2]-ev["eta"][base]
        def interp(col,z):return (1-z)*(1-2*z)*col[0]+4*z*(1-z)*col[1]+z*(2*z-1)*col[2]
        target=cubic(ev["Q"][base],ev["Q"][base+2],ev["Q_t"][base],ev["Q_t"][base+2],dt)
        for sp in ("baryon","cdm"):
            xx=ev[sp+"_x"][sl];pp=ev[sp+"_p"][sl];vx=ev["rate_"+sp+"_x"][sl];vp=ev["rate_"+sp+"_p"][sl]
            xx=cubic(xx[0],xx[2],vx[0],vx[2],dt);pp=cubic(pp[0],pp[2],vp[0],vp[2],dt)
            mass=ev[sp+"_m"];lam=ev[sp+"_label"]
            for site,r in enumerate(SITES):
                for sign in (-1,1):
                    relative=xx-sign*target[:,site,None]
                    b=relative[0]+relative[1]/3;c=relative[0]+(2*relative[1]+relative[2])/3
                    hull=np.stack((relative[0],b,c,relative.sum(axis=0)))
                    lo=hull.min(axis=0);hi=hull.max(axis=0);ix=np.flatnonzero((lo<=0)&(hi>=0))
                    roots=crossing(relative[:,ix],0.);jumps[site]+=len(roots)
                    ids=np.flatnonzero((np.minimum(lo[:-1],lo[1:])<=0)&(np.maximum(hi[:-1],hi[1:])>=0))
                    lim=np.sort(np.r_[0.,roots,1.])
                    for left,right in zip(lim[:-1],lim[1:]):
                        if right-left<1e-15:continue
                        z=(left+.5*(right-left)*(1+nodes))[:,None]
                        q0=evalpoly(relative[:,ids],z);q1=evalpoly(relative[:,ids+1],z);width=q1-q0
                        active=((q0<=0)&(q1>0))|((q1<=0)&(q0>0))
                        frac=np.where(active,-q0/np.where(active,width,1),0)
                        jac=interp(ev["J"][sl,site],z);sk=interp(ev["s"][sl,site],z)
                        m=mass[ids]*(lam[ids]+frac)**2/(lam[ids]**2+lam[ids]+1/3)
                        dm=np.where(active,m/(np.where(active,abs(width),1)*jac),0.)
                        p0=evalpoly(pp[:,ids],z);p1=evalpoly(pp[:,ids+1],z)
                        physical=(p0+(p1-p0)*frac)/jac+sign*sk
                        a=interp(ev["a"][sl],z);bf=interp(ev["b"][sl,site],z);N=interp(ev["lapse"][sl,site],z)
                        sq=(physical/(a*bf**2))**2
                        rate=-.5*ev[sp+"_c"]*N/(a**2*bf**6*r**2)*np.sum(dm*sq/np.sqrt(1+sq),axis=1,keepdims=True)
                        out[site]+=.5*dt*(right-left)*weights@rate[:,0]
    return out,jumps
def score(tag):
    ev=unpack(ROOT/(tag+"-events.npz"));tr=unpack(ROOT/(tag+"-trace.npz"));metric=unpack(ROOT/(tag+"-metric.npz"))
    fine,roots=face(ev,16);rough,count=face(ev,8)
    np.testing.assert_array_equal(roots,count)
    times=tr["eta"];tt=metric["eta"];delta=tr["h"][-1]-tr["h"][0]
    terms=simpson(tr["terms"],x=times,axis=0);old=terms[3].copy();terms[3]=fine
    terms=np.vstack((terms,tr["scalar_pressure"].sum(axis=0)))
    sel=[np.argmin(abs(metric["r"]-r)) for r in SITES]
    dv=metric["V"][-1,sel]-metric["V"][0,sel];expected=simpson(metric["Vkin"][:,sel],x=tt,axis=0)
    expansion=tt[-1]*metric["a"][0]*metric["H"][0]*metric["V"][0,sel]
    def report(i,j):
        pick=lambda x:x[...,j]-x[...,i] if i!=j else x[...,i]
        change=pick(delta);contrib=pick(terms);pred=contrib.sum()
        norm=max(abs(change),abs(pred),max(abs(contrib)));raw=change-pred
        kin=pick(dv)-pick(expected);base=max(abs(pick(dv)),abs(pick(expected)),abs(pick(expansion)))
        return dict(lo=SITES[i],hi=SITES[j],measured=change,expected=pred,norm=norm,error=raw,relative=raw/norm,
            face_order=(pick(fine)-pick(rough))/norm,sampled_face_difference=pick(old-fine)/norm,
            slow_trace=contrib[4],slow_momentum=pick(tr["slow_h"][-1]-tr["slow_h"][0]),
            metric_change=pick(dv),metric_expected=pick(expected),metric_residual=kin,metric_norm=base,metric_fraction=kin/base)
    rows=[report(i,j) for i,j in SPANS];sites=[report(i,i) for i in range(len(SITES))]
    direction=1 if tt[-1]>0 else -1
    sorted_movie=dict(r=metric["r"],**{k:metric[k][::direction] for k in ("eta","V","slip","a","H")})
    movie=Movie(sorted_movie,"constraint")
    result=dict(tag=tag,spans=rows,absolute_sites=sites,crossings=count,min_J=min(ev["min_J"]),mass_rule=max(ev["mass_quadrature"]),
        clocks=[movie.link(*arm)["received"] for arm in ARMS])
    if tag.startswith("heavy"):
        en=unpack(ROOT/(tag+"-energy.npz"));sums=en["integrals"].sum(axis=0);net=en["excess"][-1]-en["excess"][0]
        w=sums[:3].sum(axis=0);qnet=en["shell"][-1]-en["shell"][0];flux=simpson(en["current_face"],x=times,axis=0)
        result.update(energy=(net-w)/np.max(abs(np.vstack((net,w,sums[:3]))),axis=0),
            charge=(qnet-sums[3])/np.maximum.reduce((abs(flux[:-1]),abs(flux[1:]),abs(qnet),abs(sums[3]))))
    note(tag+"-score.json",result)
    print(tag,"raw trace / raw metric (ppm)",np.array([[r[key] for r in rows] for key in ("relative","metric_fraction")])*1e6,flush=True)
    return result
if __name__=="__main__":score(sys.argv[1])

