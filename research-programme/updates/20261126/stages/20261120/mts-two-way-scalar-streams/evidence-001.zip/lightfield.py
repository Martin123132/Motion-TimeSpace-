from local import *
from slow_response import table
from scipy.integrate import solve_ivp
from scipy.interpolate import CubicSpline
class Slow:
    def __init__(self,seed,model,a0,duration,gridref):
        self.digest,self.mass,field,dphi=table(model)
        self.rad=np.linspace(0.,24.,7680*gridref+1);self.dr=self.rad[1]
        self.area=self.rad[1:-1]**2*self.dr
        self.volface=((self.rad[1:]+self.rad[:-1])/2)**2/self.dr
        self.calendar=solve_ivp(lambda t,y:[y[0]**2*seed.H(y[0]),y[2]/y[0]**2,-y[0]**4*self.mass**2*y[1]],
            (0,duration),[a0,field(np.log(a0)),a0**2*dphi(np.log(a0))],rtol=3e-14,atol=[1e-15,1e-15,1e-20],
            method="DOP853",dense_output=True,max_step=.008).sol
    def metric(self,mesh,u,v):
        U,V=[mesh.points(val,self.rad) for val in (u,v)];U[-1]=V[-1]=0.
        return U,V
    def uniform(self,metric):
        a,phi,pi=self.calendar(0.);return np.stack((np.zeros_like(self.rad),pi*np.expm1(-3*metric[1])))
    def advance(self,t,dt,state,metric):
        U,V=metric;A=np.exp(U+3*V);B=np.expm1(U+3*V);C=np.exp(U-3*V);D=np.expm1(U-3*V)
        faces=self.volface*np.exp(.5*((U-V)[1:]+(U-V)[:-1]))
        steps=max(1,int(np.ceil(abs(dt)*np.exp(U+V).max()/(.55*self.dr))))
        step=dt/steps;y=state
        def rates(at,qp):
            a,phi,pi=self.calendar(at);q,p=qp;flux=faces*np.diff(q)
            dq=(A*p+pi*B)/a**2
            dp=np.zeros_like(dq);dp[0]=6*np.exp(U[0]-V[0])*(q[1]-q[0])/self.dr**2
            dp[1:-1]=np.diff(flux)/self.area
            dp=a**2*dp-a**4*self.mass**2*(C*q+D*phi)
            dq[-1]=dp[-1]=0.;return np.stack((dq,dp))
        for n in range(steps):
            at=t+n*step;k1=rates(at,y);k2=rates(at+step/2,y+step/2*k1);k3=rates(at+step/2,y+step/2*k2);k4=rates(at+step,y+step*k3)
            y=y+(step/6)*(k1+2*k2+2*k3+k4)
        assert np.all(np.isfinite(y)) and np.all(y[:,-1]==0)
        return y
    def samples(self,state,r):
        q,d=state
        interp=CubicSpline(self.rad,q,bc_type=((1,0.),"natural"))
        density=CubicSpline(self.rad,d,bc_type=((1,0.),"natural"))
        return interp(r),density(r),interp(r,1)
def components(beta,a,phi,pi,mass,samples):
    q,d,qr=samples;W=pi/a**3
    inv=np.exp(-6*np.log1p(beta));dw=(d*inv+pi*np.expm1(-6*np.log1p(beta)))/a**3
    anis=qr**2/(a**2*(1+beta)**4);kin=dw*(W+.5*dw)+.5*anis;pot=mass**2*q*(phi+.5*q)
    return kin+pot,-(W+dw)*qr,anis,kin-pot

