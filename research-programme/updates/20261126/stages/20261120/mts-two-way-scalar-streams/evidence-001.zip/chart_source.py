from local import *
from live_gravity import Matter as ScalarMatter
from sheet_source import SPECIES
from panels import grid
from scipy.linalg import solve_banded

class Material:
    def __init__(self,mesh,chart,state,detail,cut):
        pos,pi=state;mass,lam,self.matrix,_,_=detail;step=np.diff(pos);rise=np.diff(pi)
        self.size=len(pos);self.batch=[]
        rad=mesh.r;qq=chart.inverse(rad)
        jac=1+chart.d(qq,1);d2=chart.d(qq,2);sk,skq=chart.shift.evaluate(qq,True)
        gauss=(mesh.width[:,None]*mesh.wts/2).ravel()
        physical=chart.physical(pos)
        for sign in (-1,1):
            first=sign*physical[:-1];last=sign*physical[1:];low=np.minimum(first,last);hi=np.maximum(first,last)
            begin=np.searchsorted(rad,np.maximum(low,cut));end=np.maximum(begin,np.searchsorted(rad,hi))
            cnt=end-begin;ids=np.repeat(np.arange(len(mass)),cnt);addr=np.repeat(begin-(np.cumsum(cnt)-cnt),cnt)+np.arange(len(ids))
            if len(ids):
                frac=(sign*qq[addr]-pos[ids])/step[ids];pp=pi[ids]+frac*rise[ids]
                weight=mass[ids]*(lam[ids]+frac)**2/((lam[ids]**2+lam[ids]+1/3)*abs(step[ids])*jac[addr])
                self.batch.append((False,sign,ids,addr,frac,pp,pp/jac[addr]+sign*sk[addr],weight*gauss[addr],weight/rad[addr]**2))
            for bot,top in zip(mesh.edge[:-1],mesh.edge[1:]):
                if bot>=cut:break
                qbot,qtop=chart.inverse(np.array([bot,top]))
                left=np.maximum(np.minimum(sign*pos[:-1],sign*pos[1:]),qbot)
                right=np.minimum(np.maximum(sign*pos[:-1],sign*pos[1:]),qtop)
                ix=np.flatnonzero(right>left);half=(right[ix]-left[ix])/2
                if not len(ix):continue
                rr=(left[ix,None]+half[:,None]*(1+mesh.nodes)).ravel()
                ids=np.repeat(ix,len(mesh.nodes));frac=(sign*rr-pos[ids])/step[ids]
                pp=pi[ids]+frac*rise[ids];J=1+chart.d(rr,1)
                dm=mass[ids]*(lam[ids]+frac)**2/((lam[ids]**2+lam[ids]+1/3)*abs(step[ids]))*(half[:,None]*mesh.wts).ravel()
                self.batch.append((True,sign,ids,rr,frac,pp,pp/J+sign*chart.shift.evaluate(rr),dm,dm/(cut**3/3)))
        self.qq,self.jac,self.d2,self.skq=qq,jac,d2,skq
        seen=sum(np.bincount(ids,weights=dm,minlength=len(mass)) for _,_,ids,_,_,_,_,dm,_ in self.batch)
        self.mass_error=max(abs(seen-mass))/max(mass)
        assert self.mass_error<2e-9,self.mass_error
    def project(self,mat,sol,u,up,B,A):
        mesh=mat.mesh;a=mat.a;chart=mat.chart;rr=self.qq
        metric=np.stack((np.exp(u),np.exp(2*sol["spatial"]),up,sol["vprime"]))
        bdot=B(rr);bgrad=B(rr,1);akick=A.evaluate(rr)
        outs=np.zeros((2,self.size))
        for core,sign,ids,addr,frac,pi,p,dm,_ in self.batch:
            if core:
                N,ev,ug,vg=[mesh.points(val,chart.physical(addr)) for val in metric]
                J=1+chart.d(addr,1);Jq=sign*chart.d(addr,2);_,sq=chart.shift.evaluate(addr,True)
                beta=sign*B(addr);bq=B(addr,1);acc=sign*A.evaluate(addr)
            else:
                N,ev,ug,vg=metric[:,addr];J=self.jac[addr];Jq=sign*self.d2[addr];sq=self.skq[addr]
                beta=sign*bdot[addr];bq=bgrad[addr];acc=sign*akick[addr]
            star=p**2*ev/a**2;g=np.sqrt(1+star);v=ev*N*p/(a*g)
            force=-sign*a*N*(g*ug+star/g*vg);qdot=(v-beta)/J
            pdot=J*(force-acc-sq*qdot)+(pi/J)*(bq+Jq*qdot)
            for out,rate in zip(outs,(qdot,pdot)):
                load=dm*rate
                out[:-1]+=np.bincount(ids,weights=load*(1-frac),minlength=len(out)-1)
                out[1:]+=np.bincount(ids,weights=load*frac,minlength=len(out)-1)
        return np.stack([np.r_[0.,solve_banded((1,1),self.matrix,out[1:-1],check_finite=False),0.] for out in outs])

class Matter(ScalarMatter):
    def __init__(self,chart,*args):
        self.chart=chart;super().__init__(*args)
    def initialize(self,state,labels):
        self.cut=.00625
        self.mesh=grid({sp:(self.chart.physical(state[sp][0]),state[sp][1],labels[sp][0]) for sp in SPECIES},self.cut,.003125,6,24.)
        self.rad=self.mesh.r;self.core=self.rad<self.cut;self.iso=(self.rad[self.core]/self.cut)**2
        self.rest=np.zeros_like(self.rad);self.j0=self.rest.copy();self.density=[];self.elements={}
        for sp in SPECIES:
            part=Material(self.mesh,self.chart,state[sp],labels[sp],self.cut);self.elements[sp]=part
            for core,sign,ids,addr,frac,pi,p,dm,dens in part.batch:
                load=dens*self.seed.coeff[sp]/self.a**3;mom=sign*p
                if core:self.rest[self.core]+=sum(load);self.j0[self.core]+=self.iso*(load@mom)
                else:
                    self.rest+=np.bincount(addr,weights=load,minlength=len(self.rad))
                    self.j0+=np.bincount(addr,weights=load*mom,minlength=len(self.rad))
                self.density.append((core,addr,p**2/self.a**2,load))
        self.bg=sum(self.seed.coeff[sp] for sp in SPECIES)/self.a**3

