from local import *
from kick import Basis
from scipy.interpolate import CubicSpline

class Domain:
    def __init__(self,original,ref):
        self.k=Basis(original,0)
        self.d=np.linspace(0,24,7680*ref+1)
    def empty(self):return np.zeros_like(self.d),np.zeros_like(self.k.r)
    def fields(self,ds):return Chart(self,ds)

class Chart:
    def __init__(self,domain,ds):
        self.dom=domain;self.shift=domain.k.field(ds[1]);self.zero=not np.any(ds[0])
        self.d=CubicSpline(domain.d,ds[0],bc_type="natural")
        poly=self.d.c;dz=np.diff(domain.d)
        vertex=np.clip(np.divide(-poly[1],3*poly[0],out=np.zeros_like(dz),where=poly[0]!=0),0,dz)
        self.minJ=1+min(self.d(domain.d,1).min(),(poly[2]+vertex*(2*poly[1]+3*poly[0]*vertex)).min())
        assert self.minJ>.5,self.minJ
    def physical(self,q):
        return q if self.zero else q+np.sign(q)*self.d(abs(q))
    def inverse(self,r):
        if self.zero:return r
        q=r-self.d(r)
        for _ in range(2):q-=(q+self.d(q)-r)/(1+self.d(q,1))
        assert max(abs(q+self.d(q)-r),default=0)<1e-12
        return q
    def rates(self,mat,sol,u,up,on):
        mesh=mat.mesh;a=mat.a
        def evaluate(q,velocity):
            r=self.physical(q);cu=mesh.points(u,r);v=mesh.points(sol["spatial"],r)
            if velocity:
                mom=self.shift.evaluate(q);sq=(mom*np.exp(v)/a)**2
                return np.exp(cu+2*v)*mom/(a*np.sqrt(1+sq))
            sq=(self.shift.evaluate(q)*np.exp(v)/a)**2 if on else np.zeros_like(q)
            return -a*np.exp(cu)*(np.sqrt(1+sq)*mesh.points(up,r)+sq/np.sqrt(1+sq)*mesh.points(sol["vprime"],r))
        knots=self.dom.k.r;cont=evaluate(knots,False);cont-=knots/knots[-1]*cont[-1];cont[0]=cont[-1]=0.
        dq=evaluate(self.dom.d,True) if on else np.zeros_like(self.dom.d)
        dq-=self.dom.d/self.dom.d[-1]*dq[-1];dq[0]=dq[-1]=0.
        return (dq,cont),CubicSpline(self.dom.d,dq,bc_type="natural"),self.dom.k.field(cont)

