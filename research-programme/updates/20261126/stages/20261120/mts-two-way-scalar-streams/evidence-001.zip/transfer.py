from local import *
from seeds import SPEC,NATIVE,checked as verify_hash,source,obj
from source import OLD,FILES
sys.path.insert(0,str(SPEC))
from spectrum_common import camb,inherited

def run(model):
    seed,_,a0=fixture(model,"end",0);requested=np.array([.65,a0])
    status=obj(source("runs/"+model+"/status.json"))
    for item in inherited.native_hashes():verify_hash(item,status["input_hashes"][str(item)])
    path=SPEC/"runs/projection/a225-w6-d8.npz" if model=="heavy" else NATIVE/"runs/backgrounds/cold.npz"
    verify_hash(path,status["source_hash"])
    ref="radiation-full-"+model+"-0.npz";orig=unpack(verify_hash(OLD/ref,FILES[ref]));np.testing.assert_array_equal(orig["modes"],seed.k)
    epochs=orig["epochs"];names=orig["names"].tolist()
    cols=["a","H","etak","Weyl","v_newtonian_cdm","mts_dphi_s","mts_dphidot_s","mts_drho_s","mts_dp_s","mts_q_s"]
    idx=[names.index(name) for name in cols]
    params=inherited.params_for(path,background_boost=8.);params.DoLateRadTruncation=False
    native=camb.get_background(params);native.Params.Accuracy.IntTolBoost=6
    batches=[]
    for file in sorted((SPEC/"runs"/model).glob("chunk-*.npz")):
        with np.load(source(file.relative_to(SPEC).as_posix())) as bank:
            selected=bank["modes"][np.isin(bank["modes"],seed.k)]
            if len(selected):batches.append((selected,np.unique(np.r_[selected,bank["modes"].max()])))
    results=[];replays=[];joint=np.sort(np.unique(np.r_[epochs,requested]))
    for cutoff in requested:
        target=joint[joint<=cutoff]
        times=native.conformal_time(1/target-1,tol=1e-10)
        pieces=[]
        for select,batch in batches:
            hold();piece=native.get_time_evolution(batch,times,vars=cols,lAccuracyBoost=4)
            pieces.append(piece[np.searchsorted(batch,select)])
        output=np.concatenate(pieces)
        before=epochs[epochs<requested[0]]
        old=orig["values"][:,np.searchsorted(epochs,before)][:,:,idx]
        replay=output[:,np.searchsorted(target,before)]
        np.testing.assert_allclose(replay,old,rtol=TOL,atol=1e-12)
        results.append(output[:,-1]);replays.append(float(np.max(abs(replay-old)/(1e-12+TOL*abs(old)))))
        if len(results)==2:
            np.testing.assert_allclose(output[:,np.searchsorted(target,requested[0])],results[0],rtol=TOL,atol=1e-12)
    pack("transfer-"+model+".npz",a=requested,k=seed.k,cols=cols,values=np.stack(results),weights=seed.weights)
    note("transfer-"+model+".json",dict(source_hash=status["source_hash"],native_inputs=len(inherited.native_hashes()),
        original_control=FILES[ref],control_samples=len(before)*len(seed.k)*len(cols),max_error_over_tolerance=replays,
        epochs=requested,truncated=False))
    print(model,"saved",results[0].shape,"target background",requested,"replay",replays,flush=True)
if __name__=="__main__":run(sys.argv[1])

