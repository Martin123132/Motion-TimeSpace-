import csv
import hashlib
import io
import json
import os
import sys
from pathlib import Path
for key in ("OPENBLAS_NUM_THREADS","MKL_NUM_THREADS","OMP_NUM_THREADS","BLIS_NUM_THREADS","NUMEXPR_NUM_THREADS"):os.environ[key]="1"
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parent
PREV=ROOT.parent/"mts-canonical-stream-kick-20261120"
PIN="a4240ae90083adddb5f19e1ea2c80c42658b569e703568e211868900b8137eb2"
def sha(path):
    with path.open("rb") as fp:return hashlib.file_digest(fp,"sha256").hexdigest()
assert sha(PREV/"seal.json")==PIN
prior=json.loads((PREV/"seal.json").read_bytes())["files"]
def checked(name):
    assert sha(PREV/name)==prior[name],name
    return PREV/name
for key in ("entry.py","kick.py","slow_response.py","time_faces.py","evolve.py","species.py","measure.py","signed-trace-spans.csv","NEXT.md"):checked(key)
sys.path.insert(0,str(PREV))
from entry import np,SITES,SPANS,TOL,fixture,guard
def hold():
    guard()
    if (ROOT/"STOP-REQUESTED").exists():raise RuntimeError("Owner hold")
def put(name,data):
    hold();path=ROOT/name
    if path.exists():assert path.read_bytes()==data,path
    else:
        with path.open("xb") as f:f.write(data)
def note(name,value):put(name,(json.dumps(value,sort_keys=True,indent=2,allow_nan=False,default=lambda val:val.tolist())+"\n").encode())
def pack(name,**value):
    buf=io.BytesIO();np.savez_compressed(buf,**value);put(name,buf.getvalue())
def unpack(path):
    with np.load(path,allow_pickle=False) as src:return {k:src[k] for k in src}

