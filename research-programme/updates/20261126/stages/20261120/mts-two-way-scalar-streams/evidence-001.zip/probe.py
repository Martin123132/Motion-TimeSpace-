from local import *
from transfer import SPEC,NATIVE,verify_hash,obj,source,camb,inherited
import ctypes as ct
import subprocess

def compile_probe():
    path=NATIVE/"toolchain/mingw64/bin/gfortran.exe";dll=ROOT/"slow_probe.dll"
    status=obj(NATIVE/"runs/build-3/status.json")
    if "compiler_sha256" in status:verify_hash(path,status["compiler_sha256"])
    if not dll.exists():
        environment=dict(os.environ,PATH=str(path.parent)+os.pathsep+os.environ["PATH"])
        subprocess.run([str(path),"-O2","-shared","-static","-Wl,--no-insert-timestamp","slow_probe.f90","-o","slow_probe.dll"],
            env=environment,cwd=ROOT,check=True,timeout=60)
    return ct.CDLL(str(dll))

def generate(model):
    from camb.results import CAMB_TimeEvolution
    from source import OLD,FILES
    seed,_,a0=fixture(model,"end",0);arch=unpack(ROOT/("transfer-"+model+".npz"));targets=arch["a"]
    original=unpack(verify_hash(OLD/("radiation-full-"+model+"-0.npz"),FILES["radiation-full-"+model+"-0.npz"]))
    epochs=np.sort(np.unique(np.r_[original["epochs"][original["epochs"]<a0],targets]))
    status=obj(source("runs/"+model+"/status.json"));path=SPEC/"runs/projection/a225-w6-d8.npz" if model=="heavy" else NATIVE/"runs/backgrounds/cold.npz"
    verify_hash(path,status["source_hash"])
    for item in inherited.native_hashes():verify_hash(item,status["input_hashes"][str(item)])
    lib=compile_probe();function=ct.cast(lib.slow_probe_,ct.c_void_p)
    params=inherited.params_for(path,background_boost=8.);params.DoLateRadTruncation=False
    data=camb.get_background(params);tau=np.ascontiguousarray(data.conformal_time(1/epochs-1,tol=1e-10))
    data.Params.Accuracy.IntTolBoost=6;data.Params.Accuracy.lAccuracyBoost=4.
    names=camb.model.evolve_names;nout=len(names)+4;used=[];primary=[]
    integer=lambda value:ct.byref(ct.c_int(value))
    for file in sorted((SPEC/"runs"/model).glob("chunk-*.npz")):
        with np.load(source(file.relative_to(SPEC).as_posix())) as bank:
            select=bank["modes"][np.isin(bank["modes"],seed.k)]
            if not len(select):continue
            batch=np.ascontiguousarray(np.unique(np.r_[select,bank["modes"].max()]))
        hold();out=np.full((len(batch),len(tau),nout),np.nan)
        err=CAMB_TimeEvolution(ct.byref(data),integer(len(batch)),batch,integer(len(tau)),tau,integer(nout),out,integer(4),ct.byref(function))
        if err:raise RuntimeError(("CAMB_TimeEvolution",err))
        val=out[np.searchsorted(batch,select)][:,np.searchsorted(epochs,targets)]
        custom=val[:,:,-4:]
        np.testing.assert_allclose(custom[:,:,3],np.broadcast_to(select[:,None],custom[:,:,3].shape),rtol=1e-15,atol=0)
        np.testing.assert_array_equal(custom[:,:,1].astype(np.float32).astype(float),val[:,:,names.index("v_newtonian_cdm")])
        prim=val[:,:,[names.index(k) for k in arch["cols"]]]
        used.append(custom);primary.append(prim)
    full=np.concatenate(used).transpose(1,0,2);native=np.concatenate(primary).transpose(1,0,2)
    np.testing.assert_allclose(native,arch["values"],rtol=TOL,atol=1e-12)
    pack("precise-"+model+".npz",a=targets,k=seed.k,source=full,values=native,cols=arch["cols"])
    note("precise-"+model+".json",dict(identical_rounded_velocity=True,standard_source_max_abs_diff=float(abs(native-arch["values"]).max()),
        callback_source_sha=sha(ROOT/"slow_probe.f90"),callback_dll_sha=sha(ROOT/"slow_probe.dll"),
        background_hash=status["source_hash"],original_evolution_unchanged=True))
    print(model,"native double shear returned",full.shape,flush=True)
if __name__=="__main__":generate(sys.argv[1])

