from local import *
from scipy.special import spherical_jn
from collapse import taper

def prepare(seed,model,slow,metric,kind):
    assert kind=="linear"
    bank=unpack(ROOT/("transfer-"+model+".npz"));a,phi,pi=slow.calendar(0.)
    epoch=np.flatnonzero(abs(bank["a"]-a)<2e-12).item()
    cols=list(bank["cols"]);arr=bank["values"][epoch]
    get=lambda name:arr[:,cols.index(name)]
    np.testing.assert_array_equal(seed.k,bank["k"]);np.testing.assert_array_equal(seed.weights,bank["weights"])
    k=seed.k;W=pi/a**3;speed=a*W;hc=get("H");am2=(a*slow.mass)**2
    alpha=-hc*get("v_newtonian_cdm")/k**2
    field=get("mts_dphi_s")+speed*alpha
    normal=get("mts_dphidot_s")+(-3*hc*speed-am2*phi)*alpha
    actual=np.array([speed*normal+am2*phi*field,speed*normal-am2*phi*field,k*speed*field])
    orig=np.array([get("mts_drho_s"),get("mts_dp_s"),get("mts_q_s")])
    expected=orig+np.array([-3*hc*speed**2*alpha,(-3*hc*speed**2-2*am2*phi*speed)*alpha,k*speed**2*alpha])
    error=np.max(abs(actual-expected),axis=0)/np.maximum(np.max(abs(expected),axis=0),np.max(abs(orig),axis=0))
    assert max(error)<TOL,(model,epoch,max(error))
    r=slow.rad;window=taper(r,24.)
    modes=2*seed.weights
    q=seed.transform(r,field,0)*2*window
    dw=seed.transform(r,normal/a,0)*2*window
    U,V=metric
    d=a**3*(np.exp(-3*V)*dw+np.expm1(-3*V)*W)
    assert q[-1]==d[-1]==0
    uncertainty=.5*abs(np.spacing(get("v_newtonian_cdm").astype(np.float32)).astype(float))*abs(hc)/k**2
    qerr=np.sum(abs(modes*speed)*uncertainty);dwerr=np.sum(abs(modes*(3*hc*speed+am2*phi)/a)*uncertainty)
    return np.stack((q,d)),dict(model=model,a=a,source_hash=sha(ROOT/("transfer-"+model+".npz")),
        modes=len(k),amplitude=2.,scope="linear formation-conditioned transfer embedded on this nonlinear slice; not an evolution through the whole nonlinear interval",
        max_native_source_roundtrip=max(error),slow_field_range=[min(q),max(q)],normal_velocity_range=[min(dw),max(dw)],
        float_velocity_contribution_abs_field_bound=qerr,float_velocity_contribution_abs_proper_rate_bound=dwerr,
        velocity_rounding_to_field_max=qerr/max(abs(q)),velocity_rounding_to_rate_max=dwerr/max(abs(dw)),
        initial_perturbed_stress_energy_peak=np.max(abs(W*dw+slow.mass**2*phi*q)),potential_and_metric_preparation_not_refitted=True)

