from gate_sources import *
from functools import lru_cache
from scipy.integrate import simpson
from scipy.interpolate import CubicHermiteSpline, CubicSpline
from scipy.special import roots_legendre, roots_laguerre


@lru_cache(None)
def rule(order):
    return roots_legendre(order)


class Movie:
    def __init__(self, data, stride, spatial, use_kin, exterior):
        eta = data["eta"][::stride]
        radius = data["radius"][::spatial]
        assert radius[-1] == 24.
        self.radius = radius
        self.times = eta
        self.exterior = exterior
        direct = 1 if eta[-1]>0 else -1
        def spline(array):
            return CubicSpline(eta[::direct], array[::direct], axis=0)
        self.a = spline(data["a"][::stride])
        spatial_arrays = lambda name:data[name][::stride,::spatial]
        self.U, self.G = spline(spatial_arrays("U")), spline(spatial_arrays("grad"))
        self.edge = spline(data["vprime_edge"][::stride])
        self.kin = use_kin
        val = spatial_arrays("V")
        self.history = spline(spatial_arrays("Vkin") if use_kin else val-val[0])
        self.frame = lru_cache(maxsize=128)(self.frame)

    def frame(self, time):
        potential = CubicHermiteSpline(self.radius, self.U(time), self.G(time))
        rate = CubicSpline(self.radius, self.history(time, 0 if self.kin else 1))
        return potential, rate, self.edge(time), self.edge(time,1)

    def sample(self, time, radius):
        potential, rate, edge, dedge = self.frame(time)
        limit = self.radius[-1]
        clipped = np.minimum(radius,limit)
        val, grad, vdot = potential(clipped), potential(clipped,1), rate(clipped)
        beyond = radius>limit
        if np.any(beyond):
            if self.exterior == "flat":
                val[beyond] = grad[beyond] = vdot[beyond] = 0.
            else:
                tail = limit*(1-limit/radius[beyond])
                val[beyond] = edge*tail
                grad[beyond] = edge*(limit/radius[beyond])**2
                vdot[beyond] = dedge*tail
        return val, grad, vdot


def kernels(sample, radii, travel, speed, nmu, nball):
    angles, aw = rule(nmu)
    radial, rw = rule(nball)
    frac = np.r_[(radial+1)/2,1.]
    bw = 1.5*rw*frac[:-1]**2
    radii = radii[None,:,None,None]
    dis = travel[:,None,None,None]*frac[None,None,:,None]
    separation = np.sqrt((radii-dis)**2+2*radii*dis*(1-angles))
    local_angle = (radii*angles-dis)/separation
    val, grad, rate = sample(separation)
    derivative = -grad*local_angle
    angular = lambda rows:np.einsum("...m,m->...",rows,aw*.5)
    shell = lambda rows:rows[:,:,-1]
    ball = lambda rows:rows[:,:,:-1]@bw
    U, V, Uprime = map(angular, (val,rate,derivative))
    amplitude = shell(rate)+shell(derivative)/speed[:,None,None]
    integrated = travel[:,None]/3*ball(V)+(shell(U)-(2/3)*ball(U))/speed[:,None]
    longitudinal = shell(V)-(2/3)*ball(V)+(shell(Uprime)-(2/3)*ball(Uprime*frac))/speed[:,None]
    pressure = angular(amplitude*angles**2)
    corrected = longitudinal-longitudinal[:,[-1]]+pressure[:,[-1]]
    return np.stack((angular(amplitude),angular(angles*amplitude),pressure,
                     angular((1.5*angles**2-.5)*amplitude),integrated-integrated[:,[-1]],corrected))


def run(model, epoch, config, resolution):
    key = f"{model}-{epoch}"
    full = unpack(ROOT/(key+"-full.npz"))
    inv = unpack(ROOT/(key+"-inventory.npz"))
    temporal, spatial, nmu, nball, nq, ntime, ntout, exterior, kin = resolution
    movie = Movie(full,temporal,spatial,kin,exterior)
    radii = np.r_[SITES,24.]
    eta = movie.times
    sign = 1 if eta[-1]>0 else -1
    times = np.linspace(0,eta[-1],ntout)
    a0 = inv["a"][0]
    mass = float(inv["mass_Tnu"])
    momenta, laguerre = roots_laguerre(nq)
    fermi = 1+np.exp(-momenta)
    norm = inv["rho_mass_nu"][0]*a0**4/(laguerre@(momenta**2*np.hypot(momenta,a0*mass)/fermi))
    hot_mass = np.r_[0.,np.full(nq,mass)]
    qs = np.r_[1.,momenta]
    nodes, weights = rule(ntime)
    def velocity(time):
        return qs/np.hypot(qs,movie.a(time)*hot_mass)
    series = []
    for end in times:
        hold()
        integrals = np.zeros((6,nq+1,len(radii)))
        panels = np.r_[eta[sign*eta<sign*end-1e-15],end]
        for left,right in zip(panels[:-1],panels[1:]):
            for node, weight in zip(nodes,weights):
                time = (left+right)/2+(right-left)*node/2
                speed = velocity(time)
                travel = (end-time)*(speed+4*velocity((time+end)/2)+velocity(end))/6
                profile = kernels(lambda radius:movie.sample(time,radius),radii,travel,speed,nmu,nball)
                integrals += ((right-left)*weight/2)*profile
        a = movie.a(end)
        nuweight = norm/a**4 *laguerre*momenta**3*np.hypot(momenta,a*mass)/fermi**2
        weight = np.r_[4*(inv["rho_photon"][0]+inv["rho_rel_nu"][0])*(a0/a)**4,nuweight]
        speed = velocity(end)
        moment_weight = np.stack((weight,a*weight*speed,weight*speed**2,weight*speed**2,-.5*a*weight*speed,weight*speed**2))
        moments = integrals*moment_weight[:,:,None]
        series.append(np.stack((moments[:,0],moments[:,1:].sum(axis=1))))
    values = np.array(series)
    a = movie.a(times)
    hubble = CubicSpline(inv["eta"][::sign],inv["H_original"][::sign])(times)
    st = np.searchsorted(full["radius"],radii-1e-12)
    metricU = CubicSpline(full["eta"][::sign],full["U"][::sign,st],axis=0)(times)
    eps = np.hypot(momenta,a[:,None]*mass)
    native_hot = np.stack([4*(inv["rho_photon"][0]+inv["rho_rel_nu"][0])*(a0/a)**4/3,
        norm/a**4*((eps+momenta**2/(3*eps))@(laguerre*momenta**2/fermi))],axis=1)
    target = -.5*simpson(a[:,None,None]*native_hot[:,:,None]*(metricU-metricU[:,[-1]])[:,None,:],x=times,axis=0)
    boundary_pressure = .5*simpson(a[:,None,None]*values[:,:,2,:][:,:,-1:],x=times,axis=0)
    drag = simpson(3*(a*hubble)[:,None,None]*values[:,:,4],x=times,axis=0)
    pressure = .5*simpson(a[:,None,None]*values[:,:,5],x=times,axis=0)
    predicted = values[-1,:,4]+drag+pressure-boundary_pressure
    difference = predicted-target
    pack(key+"-"+config+"-hot.npz", eta=times, radii=radii, moments=values, predicted=predicted, target=target,
         boundary_pressure=boundary_pressure, drag=drag, pressure=pressure, difference=difference)
    print(key, config, "maximum balance difference on each hot drive (ppm)",np.max(abs(difference[:,:-1]/target[:,:-1]),axis=1)*1e6,flush=True)


CONFIG = {
    "base":(1,1,12,6,16,2,17,"matched",False),
    "fine":(1,1,24,10,24,3,33,"matched",False),
    "extra":(1,1,64,16,24,5,65,"matched",False),
    "time":(2,1,12,6,16,2,17,"matched",False),
    "space":(1,2,12,6,16,2,17,"matched",False),
    "flat":(1,1,12,6,16,2,17,"flat",False),
    "kin":(1,1,12,6,16,2,17,"matched",True),
}


if __name__ == "__main__":
    for branch in sys.argv[1].split(","):
        for item in sys.argv[2].split(","):
            for name in sys.argv[3:]:
                run(branch,item,name,CONFIG[name])
