from gate_sources import *
import csv


def main():
    io_buffer=io.StringIO(newline="")
    writer=csv.writer(io_buffer,lineterminator="\n")
    writer.writerow(["run","max_abs_site_trace_ppm","max_abs_site_metric_ppm","max_abs_span_trace_ppm","max_abs_span_metric_ppm",
        "wave_charge_max","wave_energy_max","thermal_integrated_momentum_balance_massless_ppm","thermal_integrated_momentum_balance_massive_ppm",
        "shell_energy_balance_massless_ppm","shell_energy_balance_massive_ppm","shell_energy_vs_independent_massless_ppm","shell_energy_vs_independent_massive_ppm"])
    sums={row["tag"]:np.array(row["error"]) for row in json.loads((ROOT/"live-thermal-energy.json").read_bytes())}
    independent={row["tag"]:np.array(row["relative"]) for row in json.loads((ROOT/"independent-shell-tests.json").read_bytes())}
    for path in sorted(ROOT.glob("*-comparison.json")):
        obj=json.loads(path.read_bytes());tag=obj["tag"]
        peak=lambda arr:float(np.max(np.abs(arr)))
        waves=[peak(obj[field]) if obj[field] else "" for field in ("charge","energy")]
        balance=(np.max(abs(sums[tag]),axis=1)*1e6).tolist() if tag in sums else ["",""]
        external=(np.max(abs(independent[tag]),axis=1)*1e6).tolist() if tag in independent else ["",""]
        writer.writerow([tag,*[peak(obj["raw_"+key+"_ppm"]) for key in ("absolute_trace","absolute_metric","span_trace","span_metric")],
            *waves,*(np.asarray(obj["live_kinetic_balance_rel_max"])*1e6),*balance,*external])
    save("comparison-table.csv",io_buffer.getvalue().encode())


if __name__=="__main__":main()
