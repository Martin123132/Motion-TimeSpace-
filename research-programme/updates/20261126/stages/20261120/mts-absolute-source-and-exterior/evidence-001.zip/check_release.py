import hashlib
import json
import sys
from pathlib import Path


ROOT=Path(__file__).resolve().parent
UPSTREAM=ROOT.parent/"mts-two-way-scalar-streams-20261120"
PIN="d2ee208071042fc7dacc626526f82a64153540d3cfe0d5782723489f73c7f8ff"


def hash_file(path):
    with path.open("rb") as handle:return hashlib.file_digest(handle,"sha256").hexdigest()


def read(path):
    return json.loads(path.read_bytes())


def run():
    assert hash_file(UPSTREAM/"seal.json")==PIN
    parent=read(UPSTREAM/"seal.json")["files"]
    for name,value in parent.items():assert hash_file(UPSTREAM/name)==value,name
    essential={"PROTOCOL.md","FEEDBACK-PROTOCOL.md","DERIVATION.md","FINITE-EVOLUTION.md","RESULTS.md","REPLAY.md",
        "kernel-checks.json","translated-ball-controls.json","unseen-site-tests.json","four-new-site-predictions.json","live-thermal-energy.json","passive-controls.json"}
    essential.update({"comparison-table.csv","independent-shell-tests.json","heavy-start-extra-hot.npz","heavy-start-extra-shell-energy.json"})
    intended=set()
    for branch in ("cold","heavy"):
        for epoch in ("start","end"):
            key=f"{branch}-{epoch}"
            for config in ("base","fine"):
                essential.add(key+"-"+config+"-shell-energy.json")
            for field in ("full.npz","replay.json","calendar.json","inventory.npz","budget.json"):
                essential.add(key+"-"+field)
            for config in ("base","fine","time","space","kin","flat"):
                essential.add(key+"-"+config+"-hot.npz")
            intended |= {f"{key}-thermal1-original-n8",f"{key}-thermal3-original-n8",f"{key}-thermal3-source-n8"}
        intended.add(branch+"-start-thermal1-cubic-n8")
    intended|={"heavy-start-thermal2-original-n8","heavy-start-thermal2-cubic-n16","heavy-start-thermal5-source-n8",
               "cold-start-thermal6-source-n8","heavy-start-thermal6-source-n8"}
    scores={p.name.removesuffix("-score.json") for p in ROOT.glob("*thermal*-score.json")}
    assert intended==scores,(intended-scores,scores-intended)
    worst={key:0. for key in ("source_absolute_trace_ppm","source_absolute_metric_ppm","source_span_trace_ppm","source_span_metric_ppm","wave_energy","wave_charge")}
    for tag in sorted(scores):
        for suffix in ("metric.npz","events.npz","trace.npz","restart.npz","thermal.npz","comparison.json","inputs.json"):
            essential.add(f"{tag}-{suffix}")
        item=read(ROOT/(tag+"-score.json"))
        assert item["tag"]==tag and len(item["spans"])==4 and len(item["absolute_sites"])==7
        assert item["min_J"]>.5 and item["mass_rule"]<2e-5
        for group,label in (("spans","span"),("absolute_sites","absolute")):
            for k,name in (("relative","trace"),("metric_fraction","metric")):
                amount=1e6*max(abs(row[k]) for row in item[group])
                assert amount<20,(tag,group,k,amount)
                if "-thermal3-source-" in tag:
                    key=f"source_{label}_{name}_ppm"
                    worst[key]=max(worst[key],amount)
        if tag.startswith("heavy"):
            for field in ("energy","charge"):
                worst["wave_"+field]=max(worst["wave_"+field],max(map(abs,item[field])))
                assert worst["wave_"+field]<2e-5
            essential.add(tag+"-energy.npz")
    forecasts=read(ROOT/"unseen-site-tests.json")
    for model in ("cold","heavy"):
        for epoch in ("start","end"):
            key=f"{model}-{epoch}-thermal3-original-n8"
            rows=[row for row in forecasts if row["tag"]==key]
            assert len(rows)==4 and len({row["radius"] for row in rows})==4
            assert all(row["within_20ppm"] and row["predicted"]*row["measured"]>0 for row in rows)
    assert len(read(ROOT/"passive-controls.json"))==20
    ledger=read(ROOT/"live-thermal-energy.json")
    assert {entry["tag"] for entry in ledger}==intended-{key for key in intended if "-thermal1-original-n8" in key}
    for row in ledger:
        for suffix in ("-native-work.npz","-native-work.json"):
            essential.add(row["tag"]+suffix)
    actual={item.name:hash_file(item) for item in sorted(ROOT.iterdir()) if item.is_file() and item.name!="seal.json"}
    assert essential<=actual.keys(),essential-actual.keys()
    assert not any(name.endswith((".tmp",".log",".pyc")) for name in actual)
    result=dict(previous_seal_sha256=PIN,previous_checked=len(parent),runs=sorted(scores),files=actual,worst=worst)
    if sys.argv[1:]==["--seal"]:
        with (ROOT/"seal.json").open("x",encoding="utf-8",newline="\n") as handle:
            json.dump(result,handle,sort_keys=True,indent=2,allow_nan=False);handle.write("\n")
    else:
        assert read(ROOT/"seal.json")==result
    print("verified",len(actual),"stage,",len(parent),"parent files;",len(scores),"live histories;",worst)


if __name__=="__main__":run()
