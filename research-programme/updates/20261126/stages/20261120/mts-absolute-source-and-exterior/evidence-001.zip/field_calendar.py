from gate_sources import *
from slow_response import table
from scipy.integrate import solve_ivp
from scipy.special import roots_laguerre


class SourceCalendar:
    def __init__(self, seed, model, a0, inventory):
        _, mass, phi, derivative = table(model)
        self.a0, self.H0 = a0,seed.H(a0)
        initial_W = derivative(np.log(a0))/a0
        self.initial = np.array([0.,phi(np.log(a0)),initial_W/self.H0])
        q, weights = roots_laguerre(48)
        den = 1+np.exp(-q)
        M = float(inventory["mass_Tnu"])
        C = inventory["rho_mass_nu"][0]*a0**4/(weights@(q**2*np.hypot(q,a0*M)/den))
        radiation = (inventory["rho_photon"][0]+inventory["rho_rel_nu"][0])*a0**4
        dust = sum(seed.coeff.get(name,0.) for name in ("baryon","cdm","wave"))
        self.limit = 2e-4
        def source(loga, state):
            a = a0*np.exp(loga)
            ratio = np.exp(state[0]);W = state[2]*self.H0
            eps = np.hypot(q,a*M)
            hot = (4*radiation/3+C*(weights@(q**2*(eps+q**2/(3*eps))/den)))/a**4
            return np.array([-.5*(dust/a**3+hot+W**2)/(self.H0*ratio)**2,state[2]/ratio,
                -3*state[2]-(mass/self.H0)**2*state[1]/ratio])
        self.source = source
        self.sol = []
        for direction in (-1,1):
            result = solve_ivp(source,[0.,direction*self.limit],self.initial,method="DOP853",
                               rtol=8e-14,atol=[1e-19,3e-14,3e-15],max_step=self.limit/8,dense_output=True)
            assert result.success
            self.sol.append(result.sol)

    def state(self, a):
        x = np.asarray(np.log(np.asarray(a)/self.a0))
        flat = x.ravel()
        assert max(abs(flat)) <= self.limit*1.000000001
        out = np.zeros((3,len(flat)))
        for branch,mask in enumerate((flat<0,flat>=0)):
            if np.any(mask):
                out[:,mask] = self.sol[branch](flat[mask])
        return out.reshape((3,)+x.shape)

    def H(self,a):
        return self.H0*np.exp(self.state(a)[0])


def verify(model,epoch):
    from transfer import SPEC,NATIVE,source,obj,verify_hash,camb,inherited
    hold()
    seed, _, a0 = fixture(model,epoch,0)
    inv = unpack(ROOT/(f"{model}-{epoch}-inventory.npz"))
    physical=SourceCalendar(seed,model,a0,inv)
    status = obj(source("runs/"+model+"/status.json"))
    path=SPEC/"runs/projection/a225-w6-d8.npz" if model=="heavy" else NATIVE/"runs/backgrounds/cold.npz"
    verify_hash(path,status["source_hash"])
    for name in inherited.native_hashes():verify_hash(name,status["input_hashes"][str(name)])
    data = camb.get_background(inherited.params_for(path,background_boost=8.))
    shifts = physical.limit*np.array([-.91,-.67,-.37,-.14,-.037,0.,.051,.18,.43,.71,.94])
    scales=a0*np.exp(shifts);mask=shifts!=0
    native = data.hubble_parameter(1/scales-1)/299792.458
    actual = np.log(native/native[~mask][0])
    predicted = physical.state(scales)[0]
    difference = abs((predicted[mask]-actual[mask])/actual[mask])
    old = np.log(seed.H(scales)/physical.H0)
    print(model,epoch,"native delta-H max absolute relative error, source / original",max(difference),max(abs((old[mask]-actual[mask])/actual[mask])),flush=True)
    note(f"{model}-{epoch}-calendar.json",dict(anchor=a0,field_source_sha=status["source_hash"],delta_log_a=shifts,
        native_delta_log_H=actual,predicted_delta_log_H=predicted,original_delta_log_H=old,
        max_relative_local_native_evolution=max(difference),initial_H_preserved=physical.H(a0)==physical.H0,
        heavy_background="original late matched averaged rest energy, not resolved homogeneous mass-frequency oscillations"))
    assert max(difference)<2e-5


if __name__=="__main__":
    for model in ("cold","heavy"):
        for epoch in ("start","end"):verify(model,epoch)
