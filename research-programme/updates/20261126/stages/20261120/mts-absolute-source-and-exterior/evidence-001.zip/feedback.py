from gate_sources import *
from live_hot import Hot
from reference_transport import ReferenceHot
from conserved_thermal import ConservedHot
from shell_work import physical_enthalpy, emit as emit_shells
from scipy.interpolate import CubicSpline
import live_gravity as upstream
import scores as scoring


def run(model, epoch, level, bg, steps):
    key = f"{model}-{epoch}"
    output = f"{key}-thermal{level}-{bg}-n{steps}"
    derived = unpack(ROOT/(key+"-inventory.npz"))
    hot = ConservedHot(derived,level) if level==6 else (ReferenceHot(derived,level) if level>=3 else Hot(derived,level))
    times = np.linspace(0,.084 if epoch=="start" else -.084,2*steps+1)
    frames = []
    shells = []
    original_solve, original_geometry, original_slow = upstream.constraints, upstream.geometry, upstream.Slow
    original_pack, original_note, original_hold = upstream.pack, upstream.note, upstream.hold
    state = dict(current=hot.zero())

    class Calendar(original_slow):
        def __init__(self,seed,*args):
            if bg=="cubic":
                spline = CubicSpline(seed.log_a,seed.log_h)
                seed.H = lambda scale:np.exp(spline(np.log(scale)))
            elif bg=="source":
                from field_calendar import SourceCalendar
                receipt = json.loads((ROOT/(key+"-calendar.json")).read_bytes())
                assert receipt["max_relative_local_native_evolution"]<2e-5 and receipt["initial_H_preserved"]
                self.physical = SourceCalendar(seed,model,args[1],derived)
                seed.H = self.physical.H
            else:
                assert bg=="original"
            super().__init__(seed,*args)

    def solve(mat):
        if not mat.feedback:
            return original_solve(mat)
        index = len(frames)
        assert index < len(times)
        t = times[index]
        hot.time,hot.calendar = t,mat.slow.calendar
        assert abs(mat.slow.calendar(t)[0]-mat.a) < 1e-13
        if index:
            start = index-1 if index%2 else index-2
            amp = mat.slow.calendar((t+times[start])/2)[0]
            field = hot.step(state["current"],amp,state["metric"],t-times[start])
        else:
            field = state["current"]
        if level==6:
            field = hot.prepare(index,t-times[start] if index else 0.,field)
        if index%2==0:
            state["current"] = field
        moments = hot.moments(field,mat.a)
        fields = hot.project(moments,mat.rad) if level>=5 else CubicSpline(hot.r,moments,axis=2,bc_type="natural")(mat.rad)
        total = fields.sum(axis=0)
        old = mat.sources
        def sources(beta, gradient, lift="balanced"):
            energy, momentum, shear = old(beta,gradient,lift)
            return energy+total[0],momentum+mat.a*(1+beta)**2*total[1],shear+total[3]
        mat.sources = sources
        mat.thermal = total
        mat.thermal_species = fields
        state["max_f"]=max(state.get("max_f",0.),hot.amax if level>=3 else np.max(abs(field[1:])*hot.q[:,None,None]/(1+np.exp(-hot.q[:,None,None]))))
        return original_solve(mat)

    def geometry(mat,sol):
        result = original_geometry(mat,sol)
        if not mat.feedback:
            return result
        clock,space,slip,grad = result
        state["metric"] = hot.sample(mat,sol,clock,grad)
        mesh = mat.mesh
        at = lambda val:mesh.points(val,SITES)
        projection = []
        outer_press = []
        trace_kin = -mat.a*(mat.H*np.expm1(clock)+np.exp(clock)*sol["expansion"])
        take_shells = lambda values:np.array([values[hi]-values[lo] for lo,hi in SPANS])
        volume = lambda val:take_shells(at(mesh.primitive(mesh.r**2*val)))
        enthalpy = [hot.radiation/(3*mat.a**4), physical_enthalpy(hot,np.asarray(mat.a))]
        shell_rows = []
        for species, (energy, flux, radial, shear) in enumerate(mat.thermal_species):
            cov = mat.a*(1+sol["beta"])**2*flux
            J = -.5*at(mesh.primitive(cov,True))
            corrected = at(radial-2*mesh.primitive(shear/mesh.r,True))
            projection.append(np.stack((at(energy),at(cov),at(radial),at(shear),J,corrected)))
            outer_press.append(mesh.points(radial,[24.])[0])
            shell_rows.append(np.stack((mat.a**3*volume(energy),
                -mat.a**3*take_shells(SITES**2*at(flux)),
                -3*mat.a**4*mat.H*volume(radial-2*shear/3),
                3*mat.a**3*enthalpy[species]*volume(trace_kin))))
        shells.append(shell_rows)
        frames.append(dict(pressure_term=at(-.5*mat.a*np.exp(clock)*mat.thermal[2]),
            dust_correction=at(.5*mat.a*np.exp(clock)*mat.thermal[3]), projections=np.stack(projection),
            edge_pressure=outer_press, a=mat.a, U=at(clock), max_deltaf_over_massive_f0=state["max_f"]))
        return result

    prefix = f"{key}-d2-on1-n{steps}-s2-c1-uniform"
    def target(name):
        assert name.startswith(prefix+"-")
        return output+name[len(prefix):]
    def emit(name,**kwargs):
        if name.endswith("-trace.npz"):
            terms=kwargs["terms"].copy()
            terms[:,3]+=np.array([row["dust_correction"] for row in frames])
            kwargs["terms"]=np.concatenate((terms,np.array([row["pressure_term"] for row in frames])[:,None,:]),axis=1)
        if name.endswith("-restart.npz"):
            kwargs.update(thermal_theta=hot.full_state(state["current"]) if level>=3 else state["current"],
                thermal_r=hot.r,thermal_mu=hot.mu,thermal_dimensionless_massive_q=hot.q)
            if level>=3:
                kwargs.update(thermal_residual=state["current"],reference_grid=hot.initial.x,reference_polynomial=hot.initial.c)
            if level==6:
                kwargs.update(massive_residual_volume=hot.current_volume)
        pack(target(name),**kwargs)

    upstream.constraints,upstream.geometry,upstream.Slow = solve,geometry,Calendar
    upstream.pack,upstream.note,upstream.hold = emit,lambda name,obj:note(target(name),obj),hold
    try:
        upstream.run(model,epoch,2,1,steps,2,1,"uniform")
    finally:
        upstream.constraints,upstream.geometry,upstream.Slow = original_solve,original_geometry,original_slow
        upstream.pack,upstream.note,upstream.hold = original_pack,original_note,original_hold
    assert len(frames)==len(times)
    pack(output+"-thermal.npz",eta=times,**{k:np.stack([row[k] for row in frames]) for k in frames[0]})
    emit_shells(output,times,np.asarray(shells))
    scoring.ROOT,scoring.note=ROOT,note
    report=scoring.score(output)
    print(output, "raw absolute trace ppm", np.array([row["relative"] for row in report["absolute_sites"]])*1e6,flush=True)


if __name__=="__main__":
    run(sys.argv[1],sys.argv[2],int(sys.argv[3]),sys.argv[4],int(sys.argv[5]))
