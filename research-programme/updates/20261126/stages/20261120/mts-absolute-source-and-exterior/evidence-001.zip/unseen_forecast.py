from hot_characteristics import *


def run(model,epoch):
    key = model+"-"+epoch
    full = unpack(ROOT/(key+"-full.npz"))
    inv = unpack(ROOT/(key+"-inventory.npz"))
    radii = np.array([.1075,.1825,.2400,.3025,24.])
    movie = Movie(full,1,1,False,"matched")
    end = movie.times[-1]
    uq,lag = roots_laguerre(28)
    mass = float(inv["mass_Tnu"])
    m = np.r_[0.,np.full(len(uq),mass)]
    q = np.r_[1.,uq]
    speed = lambda t:q/np.hypot(q,movie.a(t)*m)
    integ = np.zeros((len(q),len(radii)))
    for lo,hi in zip(movie.times[:-1],movie.times[1:]):
        nodes,weights=rule(4)
        for node,weight in zip(nodes,weights):
            t=(lo+hi+(hi-lo)*node)/2
            vs=speed(t)
            distance=(end-t)*(vs+4*speed((t+end)/2)+speed(end))/6
            source=kernels(lambda rad:movie.sample(t,rad),radii,distance,vs,32,12)
            integ += (hi-lo)*weight/2*source[4]
    a=movie.a(end);a0=movie.a(0.)
    den=1+np.exp(-uq)
    C=inv["rho_mass_nu"][0]*a0**4/(lag@(uq**2*np.hypot(uq,a0*mass)/den))
    weights=np.r_[4*(inv["rho_photon"][0]+inv["rho_rel_nu"][0])*(a0/a)**4,
                  C*lag*uq**3*np.hypot(uq,a*mass)/(den**2*a**4)]
    per_q=integ*(-.5*a*weights*speed(end))[:,None]
    return dict(r=radii[:-1],photon_rel_nu=per_q[0,:-1],massive_nu=per_q[1:,:-1].sum(axis=0))


if __name__=="__main__":
    predictions = {model+"-"+epoch:run(model,epoch) for model in ("cold","heavy") for epoch in ("start","end")}
    note("four-new-site-predictions.json",dict(cases=predictions,
        quantity="Predicted change in h-H between independently evolved thermal-on and off states at the final time at fixed comoving radii. Uses the old metric only; predicts the directly added thermal momentum, neglects higher-order feedback on the other streams.",
        gate="20 ppm on each predicted change, signed; also report the finite coarse/refined raw tests. No fit or amplitude recalibration."))
