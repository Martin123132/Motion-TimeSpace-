from gate_sources import *
from hot_characteristics import kernels, rule
from scipy.special import spherical_jn


def run():
    radii = np.array([.2,.5,1.3,3.1])
    travel = np.array([-.14,.03,.18])
    speed = np.array([.87,.01,.8])
    potential = (1.2,-.36,.13)
    temporal = (-.41,.22,-.13)
    def terms(coeff, radius, dist):
        const, quad, quart = coeff
        base = radius**2+dist**2
        energy = const+quad*base+quart*(base**2+4*radius**2*dist**2/3)
        j = -2*radius*dist*(quad+2*quart*base)/3
        radial = (const+quad*base+quart*base**2)/3+4*quart*radius**2*dist**2/5
        anis = 8*quart*radius**2*dist**2/15
        end = radii[-1]
        integrated = -dist*((quad+2*quart*dist**2)*(end**2-radius**2)+quart*(end**4-radius**4))/3
        longitudinal = radial-8*quart*dist**2*(end**2-radius**2)/15
        return np.array([energy,j,radial,anis,integrated,longitudinal])
    def sample(radius):
        return (potential[0]+potential[1]*radius**2+potential[2]*radius**4,
                2*potential[1]*radius+4*potential[2]*radius**3,temporal[0]+temporal[1]*radius**2+temporal[2]*radius**4)
    fixture = kernels(sample,radii,travel,speed,10,7)
    exact = np.stack([terms(temporal,radii,dist)+terms(potential,radii,dist+1e-20j).imag/1e-20/vel
                      for dist,vel in zip(travel,speed)],axis=1)
    error = float(np.max(abs(fixture-exact)))
    assert error < 2e-11, error
    wavenumber = 13.
    def bessel(radius):
        return spherical_jn(0,wavenumber*radius), -wavenumber*spherical_jn(1,wavenumber*radius), np.zeros_like(radius)
    test = kernels(bessel,radii,travel,speed,36,18)
    derivative = [wavenumber*spherical_jn(degree,abs(wavenumber*travel),derivative=True)*np.sign(travel)**(degree+1)/speed for degree in range(3)]
    moments = np.stack([spherical_jn(degree,wavenumber*radii)[None,:]*derivative[degree][:,None] for degree in range(3)])
    bessel_error = max(abs(test[0]-moments[0]).max(),abs(test[1]-moments[1]).max(),abs(test[3]-moments[2]).max())
    assert bessel_error < 2e-11, bessel_error
    note("kernel-checks.json",dict(independent_polynomial_max_abs=error,monochromatic_dipole_quadrupole_max_abs=bessel_error,
        negative_time=True,endpoints=True,independent_analytic_primitives=True))


if __name__ == "__main__":
    run()
