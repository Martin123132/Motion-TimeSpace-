from gate_sources import *


def run():
    forecast=ROOT/"four-new-site-predictions.json"
    assert sha(forecast)=="65c0541784ffb0c4ea42fa8e353192de167e5ac54e5a7b2e8121ff9a6fa44af7"
    rows=[]
    for key,case in json.loads(forecast.read_bytes())["cases"].items():
        orig=unpack(checked(key+"-d2-on1-n8-s2-c1-uniform-metric.npz"))
        radii=np.array(case["r"])
        ix=np.searchsorted(orig["r"],radii-1e-12)
        np.testing.assert_allclose(orig["r"][ix],radii,rtol=0,atol=1e-14)
        assert not np.any(np.isclose(radii[:,None],SITES,rtol=0,atol=1e-12))
        target=np.array(case["photon_rel_nu"])+np.array(case["massive_nu"])
        for path in sorted(ROOT.glob(key+"-thermal*-original-n8-metric.npz")):
            thermal=unpack(path)
            for name in ("eta","a","H","r"):np.testing.assert_array_equal(thermal[name],orig[name])
            U=orig["V"][:,ix]-orig["slip"][:,ix]
            dU=(thermal["V"]-orig["V"]- (thermal["slip"]-orig["slip"]))[:,ix]
            dVk=(thermal["Vkin"]-orig["Vkin"])[:,ix]
            a=orig["a"][:,None];H=orig["H"][:,None]
            delta=np.exp(-U)*((H-orig["Vkin"][:,ix]/a)*np.expm1(-dU)-np.exp(-dU)*dVk/a)
            assert max(abs(delta[0]))<2e-24
            for radius,calc,pred in zip(radii,delta[-1],target):
                rows.append(dict(tag=path.name.removesuffix("-metric.npz"),radius=radius,predicted=pred,measured=calc,
                                 relative=(calc-pred)/pred,within_20ppm=bool(abs(calc-pred)<=2e-5*abs(pred))))
    return rows


if __name__=="__main__":
    rows=run()
    for tag in sorted({row["tag"] for row in rows}):
        selected=[row for row in rows if row["tag"]==tag]
        print(tag, np.round([row["relative"]*1e6 for row in selected],2),flush=True)
    if "--save" in sys.argv:note("unseen-site-tests.json",rows)
