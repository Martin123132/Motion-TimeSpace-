from gate_sources import *
from scipy.integrate import simpson


def evaluate(tag):
    model, epoch = tag.split("-")[:2]
    key = f"{model}-{epoch}"
    score = json.loads((ROOT/(tag+"-score.json")).read_bytes())
    original = json.loads(checked(key+"-d2-on1-n8-s2-c1-uniform-score.json").read_bytes())
    budget = json.loads((ROOT/(key+"-budget.json")).read_bytes())
    live = unpack(ROOT/(tag+"-thermal.npz"))
    direct = unpack(ROOT/(key+"-fine-hot.npz"))
    driver = direct["target"][:,:-1]
    idx=np.linspace(0,len(direct["eta"])-1,len(live["eta"])).astype(int)
    np.testing.assert_allclose(direct["eta"][idx],live["eta"],rtol=0,atol=1e-14)
    assert live["projections"].shape[1:]==(2,6,7)
    currents = live["projections"][-1,:,4]
    unique = direct["moments"][idx,:,:,:-1]
    differences = {}
    for channel, label in enumerate(("density","local_j","radial_pressure","anisotropy","integrated_current","longitudinal_pressure")):
        reference = unique[:,:,channel]
        scale = np.max(abs(reference),axis=(0,2))
        assert np.all(scale>0)
        differences[label] = np.max(abs(live["projections"][:,:,channel]-reference),axis=(0,2))/scale
    a = live["a"]
    metric = unpack(ROOT/(tag+"-metric.npz"))
    hub=np.interp(live["eta"]*np.sign(live["eta"][-1]),metric["eta"]*np.sign(live["eta"][-1]),metric["H"])
    rhs = (3*a*hub)[:,None,None]*live["projections"][:,:,4]+.5*a[:,None,None]*(live["projections"][:,:,5]-live["edge_pressure"][:,:,None])
    kinetic = currents+simpson(rhs,x=live["eta"],axis=0)
    normal = np.array([row["norm"] for row in original["absolute_sites"]])
    residual = np.array([row["error"] for row in score["absolute_sites"]])
    off = np.array([row["error"] for row in original["absolute_sites"]])
    forecast = -np.array(budget["drive"]["native_hot"])
    clocks = np.array(score["clocks"])-np.array(original["clocks"])
    vals = dict(tag=tag,raw_absolute_trace_ppm=[row["relative"]*1e6 for row in score["absolute_sites"]],
        raw_absolute_metric_ppm=[row["metric_fraction"]*1e6 for row in score["absolute_sites"]],
        raw_span_trace_ppm=[row["relative"]*1e6 for row in score["spans"]],
        raw_span_metric_ppm=[row["metric_fraction"]*1e6 for row in score["spans"]],
        new_minus_old_abs=residual-off,original_native_forecast=forecast,
        forecast_error_per_original_norm=(residual-off-forecast)/normal,
        forecast_error_per_forecast=(residual-off-forecast)/forecast,
        passive_vs_live_grid_error_over_peak=differences,
        passive_kinetic_balance_rel_max=np.max(abs(direct["difference"][:,:-1]/driver),axis=1),
        live_kinetic_balance_rel_max=np.max(abs((kinetic-driver)/driver),axis=1),
        live_kinetic_balance_original_norm_max=np.max(abs((kinetic-driver)/normal),axis=1),
        diagnostic_max_deltaf_over_massive_f0=max(live["max_deltaf_over_massive_f0"]),
        clock_differences=clocks,clock_note="Cubic background or outer time-step variations also change the reference trajectory; only the matched original comparison isolates hot feedback.",
        charge=score.get("charge",[]),energy=score.get("energy",[]),chart_min_J=score["min_J"],mass_rule=score["mass_rule"])
    if "-source-" in tag:
        vals["clock_note"]="The source-derived expansion law and thermal perturbations both differ from the old run; this is not a thermal-only clock shift."
    note(tag+"-comparison.json",vals)
    return vals


if __name__=="__main__":
    for file in sorted(ROOT.glob("*thermal*-score.json")):
        report = evaluate(file.name.removesuffix("-score.json"))
        print(report["tag"],*[round(max(abs(np.asarray(report["raw_"+key+"_ppm"]))),3) for key in ("absolute_trace","absolute_metric","span_trace","span_metric")],
              "separate kinetic drive errors",report["live_kinetic_balance_rel_max"], flush=True)
