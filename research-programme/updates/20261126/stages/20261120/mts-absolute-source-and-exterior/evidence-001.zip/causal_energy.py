from hot_characteristics import *
from scipy.interpolate import PPoly


def volume_primitive(spline):
    coef=spline.c[::-1]
    origin=spline.x[:-1]
    poly=np.zeros((coef.shape[0]+2,len(origin)))
    poly[:-2]+=coef*origin**2
    poly[1:-1]+=2*coef*origin
    poly[2:]+=coef
    return PPoly(poly[::-1],spline.x).antiderivative()


def calculate(model,epoch,config):
    key=model+"-"+epoch
    full=unpack(ROOT/(key+"-full.npz")); inv=unpack(ROOT/(key+"-inventory.npz"))
    hot=unpack(ROOT/(key+"-"+config+"-hot.npz"))
    tnodes=hot["eta"]
    fine=config in ("fine","extra")
    mu,wm=rule(96 if config=="extra" else (48 if fine else 24))
    xn,xw=rule(48 if config=="extra" else (24 if fine else 12))
    tn,tw=rule(5 if config=="extra" else (3 if fine else 2))
    q,lag=roots_laguerre(24 if fine else 16)
    movie=Movie(full,1,1,False,"matched")
    mass=float(inv["mass_Tnu"]);a0=inv["a"][0]
    den=1+np.exp(-q)
    norm=inv["rho_mass_nu"][0]*a0**4/(lag@(q**2*np.hypot(q,a0*mass)/den))
    ratios=np.r_[0.,mass/q]
    velocity=lambda t:1/np.hypot(1.,movie.a(t)*ratios)
    @lru_cache(maxsize=256)
    def quantities(t):
        pot,rate,_,_=movie.frame(t)
        return pot,rate,volume_primitive(rate)(SITES)
    def shell(vals):
        return np.stack([vals[...,hi]-vals[...,lo] for lo,hi in SPANS],axis=-1)
    def incoming(t,dist,speed):
        pot,rate,unshifted=quantities(t)
        rr=SITES[None,:,None]; d=dist[:,None,None]
        remote=np.sqrt((rr-d)**2+2*rr*d*(1-mu))
        dipole=((pot(remote)-pot(rr))@(wm*mu/2))
        shift=abs(d[:,:,0]);sites=rr[:,:,0]
        cuts=np.sort(np.stack(np.broadcast_arrays(np.maximum(0.,sites-shift),abs(sites-shift),sites,sites+shift)),axis=0)
        change=np.zeros_like(dipole)
        for left,right in zip(cuts[:-1],cuts[1:]):
            half=(right-left)/2
            y=left[:,:,None]+half[:,:,None]*(1+xn)
            cap=np.clip((rr-y+abs(d))*(rr+y-abs(d))/np.maximum(4*y*abs(d),1e-280),0.,1.)
            change+=half*((y**2*(cap-(y<rr))*(rate(y)-rate(rr)))@xw)
        return shell(unshifted+change-SITES**2*dipole/speed[:,None])
    stored=[];work=[]
    for end in tnodes:
        hold();integrals=np.zeros((len(ratios),len(SPANS)))
        panels=np.r_[movie.times[np.sign(tnodes[-1])*movie.times<np.sign(tnodes[-1])*end-1e-15],end]
        for lft,rgt in zip(panels[:-1],panels[1:]):
            for node,w in zip(tn,tw):
                t=(lft+rgt+(rgt-lft)*node)/2
                vs=velocity(t);dst=(end-t)*(vs+4*velocity((end+t)/2)+velocity(end))/6
                integrals+=(rgt-lft)*w/2*incoming(t,dst,vs)
        a=movie.a(end);vs=velocity(end)
        weight=np.r_[4*(inv["rho_photon"][0]+inv["rho_rel_nu"][0])*(a0/a)**4,norm*lag*q**4/(vs[1:]*den**2*a**4)]
        weighted=integrals*weight[:,None]*a**3
        flux=lambda arr:np.stack([arr[0],arr[1:].sum(axis=0)])
        stored.append((flux(weighted),flux(weighted*(vs[:,None]**2/3))))
        enthalpy=np.array([weight[0],sum(weight[1:])])/3
        work.append(3*a**3*enthalpy[:,None]*shell(quantities(end)[2]))
    store,press=np.array(stored).transpose(1,0,2,3)
    a=movie.a(tnodes);Hconf=movie.a(tnodes,1)/a
    flux=-a[:,None,None]**2*shell(hot["moments"][:,:,1,:-1]*SITES**2)
    factors=np.stack([flux,-3*Hconf[:,None,None]*press,np.array(work)],axis=2)
    terms=simpson(factors,x=tnodes,axis=0)
    change=store[-1]-store[0]
    scale=np.maximum.reduce((abs(change),np.max(abs(terms),axis=1),abs(terms.sum(axis=1))))
    err=(change-terms.sum(axis=1))/scale
    note(f"{key}-{config}-shell-energy.json",dict(measured=change,terms=terms,scale=scale,relative=err,
        independent_surface_current=True,source_volume_from_translated_ball=True,
        coarse_time_difference=(simpson(factors[::2],x=tnodes[::2],axis=0)-terms).sum(axis=1)/scale))
    print(key,config,"direct energy vs independent flux/work ppm",np.round(err*1e6,3),flush=True)


if __name__=="__main__":
    for model in sys.argv[1].split(","):
        for epoch in sys.argv[2].split(","):
            for config in sys.argv[3:]:
                calculate(model,epoch,config)
