from gate_sources import *
from scipy.interpolate import CubicSpline,PPoly
from scipy.special import roots_laguerre,roots_legendre
from scipy.integrate import simpson
from ball_mass import translated_ball_difference
from live_hot import Hot


def run(tag):
    model,epoch=tag.split("-")[:2]
    key=model+"-"+epoch
    restart=unpack(ROOT/(tag+"-restart.npz"))
    ledger=unpack(ROOT/(tag+"-hot-shells.npz"))
    hot=unpack(ROOT/(tag+"-thermal.npz"))
    inv=unpack(ROOT/(key+"-inventory.npz"))
    temp=Hot(inv,2)
    profile=PPoly(restart["reference_polynomial"],restart["reference_grid"])
    limit=profile.x[-1]
    def value(r):
        return np.where(r<=limit,profile(np.minimum(r,limit)),limit*profile(limit,1)*(1-limit/np.maximum(r,limit)))
    q=temp.q;vel0=1/np.hypot(1,inv["a"][0]*temp.ratio)
    times=ledger["eta"];order=1 if times[-1]>0 else -1
    at=CubicSpline(times[::order],hot["a"][::order])
    srows=[];frows=[];prows=[]
    nodes,weights=roots_legendre(96)
    for t in times:
        a=at(t)
        speed=1/np.hypot(1,a*temp.ratio)
        dist=t*(vel0+4/np.hypot(1,at(t/2)*temp.ratio)+speed)/6
        measure=np.r_[temp.radiation,temp.amplitude*q/speed[1:]]/a**4
        E=[];F=[]
        for i,d in enumerate(dist):
            primitive=translated_ball_difference(value,SITES,d,64)
            rr=SITES[:,None]
            sr=np.sqrt((rr-d)**2+2*rr*d*(1-nodes))
            dipole=((value(sr)-value(rr))@(weights*nodes/2))
            E.append(measure[i]/vel0[i]**2*primitive)
            F.append(measure[i]*speed[i]/vel0[i]**2*SITES**2*dipole)
        E=np.array(E);F=np.array(F)
        take=lambda array:np.stack([array[:,hi]-array[:,lo] for lo,hi in SPANS],axis=1)
        props=lambda array:np.stack((array[0],array[1:].sum(axis=0)))
        srows.append(props(take(E))*a**3)
        prows.append(props(take(E*speed[:,None]**2/3))*a**3)
        frows.append(-props(take(F))*a**3)
    srows,prows,frows=map(np.asarray,(srows,prows,frows))
    hub=at(times,1)/hot["a"]
    rhs=simpson(frows-3*hub[:,None,None]*prows,x=times,axis=0)
    scalar=srows[-1]
    residue=restart["thermal_residual"]
    remaining=Hot.moments(temp,residue,at(times[-1]))[:,0]
    radii=temp.r
    x,w=roots_legendre(4)
    direct=[]
    for lo,hi in SPANS:
        sides=np.unique(np.r_[SITES[lo],radii[(radii>SITES[lo])&(radii<SITES[hi])],SITES[hi]])
        h=np.diff(sides)/2;sites=sides[:-1,None]+h[:,None]*(1+x)
        density=CubicSpline(radii,remaining,axis=1,bc_type="natural")(sites)
        direct.append((density*sites**2)@w@h*at(times[-1])**3)
    direct=np.array(direct).T
    live=ledger["shells"][-1,:,0]
    work=simpson(ledger["shells"][:,:,1:],x=times,axis=0).sum(axis=1)
    report=dict(tag=tag,analytic_bulk_reference=scalar,transported_residual=direct,live_measured_energy=live,live_work=work,
        reference_flux_error_on_reference=(scalar-rhs)/np.maximum(abs(rhs),abs(scalar)),
        projection_error_on_shell=(live-scalar-direct)/abs(work),kinetic_energy_error_on_shell=(scalar+direct-work)/abs(work),
        residual_share=direct/abs(work))
    note(tag+"-volume-audit.json",report)
    for name in ("reference_flux_error_on_reference","projection_error_on_shell","kinetic_energy_error_on_shell","residual_share"):
        print(name,np.round(report[name]*1e6,2),flush=True)


if __name__=="__main__":
    for tag in sys.argv[1:]:run(tag)
