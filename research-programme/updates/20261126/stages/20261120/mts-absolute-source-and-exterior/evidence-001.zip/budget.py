from gate_sources import *
from scipy.integrate import simpson
from scipy.interpolate import CubicSpline


def run(model, epoch):
    key = f"{model}-{epoch}"
    inventory = unpack(ROOT/(key+"-inventory.npz"))
    full = unpack(ROOT/(key+"-full.npz"))
    tag = key+"-d2-on1-n8-s2-c1-uniform"
    scores = json.loads(checked(tag+"-score.json").read_bytes())
    sites = np.searchsorted(full["radius"], SITES-1e-12)
    eta = full["eta"]
    ordered = lambda array:array if eta[-1]>0 else array[::-1]
    interpolate = lambda val:CubicSpline(ordered(inventory["eta"]),ordered(val))(eta)
    factor = .5*full["a"][:,None]*np.expm1(full["U"][:,sites])
    drive = {name:simpson(factor*interpolate(inventory[name])[:,None],x=eta,axis=0)
             for name in ("native_hot","effective","effective_cubic","photons","massless","massive")}
    edge = simpson(.5*(full["a"]*full["edge_trace_pressure"]+full["vprime_edge"]**2/full["a"]),x=eta)
    original = np.array([row["error"] for row in scores["absolute_sites"]])
    scale = np.array([row["norm"] for row in scores["absolute_sites"]])
    note(key+"-budget.json",dict(drive=drive,edge=edge,original=original,scale=scale,original_ppm=1e6*original/scale,
         unexplained_effective_ppm=1e6*(original-edge-drive["effective"])/scale,
         unexplained_native_ppm=1e6*(original-edge-drive["native_hot"])/scale,
         uncovered_to_native=inventory["effective"]/inventory["native_hot"],
         max_abs_native_H_to_simulated=max(abs(inventory["H_native"]/inventory["H_original"]-1)),
         max_outer_pressure=abs(full["edge_trace_pressure"]).max(), max_outer_gradient=abs(full["vprime_edge"]).max()))
    print(key, "absolute ppm raw / after native / after effective",np.round(np.stack((original,original-edge-drive["native_hot"],original-edge-drive["effective"]))*1e6/scale,2),
          "edge on smallest norm",edge/min(scale),flush=True)


if __name__ == "__main__":
    for model in ("cold","heavy"):
        for epoch in ("start","end"):
            run(model,epoch)
