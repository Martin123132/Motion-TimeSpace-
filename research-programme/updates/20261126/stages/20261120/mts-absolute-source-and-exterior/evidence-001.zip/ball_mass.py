from gate_sources import *
from scipy.special import roots_legendre, spherical_jn


def translated_ball_difference(profile, radii, distance, order=16):
    shift=abs(distance)
    radii=np.asarray(radii)
    if shift==0.:return np.zeros_like(radii)
    lower=np.maximum(0.,radii-shift)
    cuts=np.sort(np.stack((lower,abs(radii-shift),radii,radii+shift)),axis=0)
    values=profile(radii)[:,None]
    nodes,weights=roots_legendre(order)
    result=np.zeros_like(radii)
    for left,right in zip(cuts[:-1],cuts[1:]):
        half=(right-left)/2
        rr=left[:,None]+half[:,None]*(1+nodes)
        numerator=(radii[:,None]-rr+shift)*(radii[:,None]+rr-shift)
        cap=np.clip(numerator/np.maximum(4*rr*shift,1e-280),0.,1.)
        signed=cap-(rr<radii[:,None])
        result+=half*((rr**2*signed*(profile(rr)-values))@weights)
    return result


def control():
    radii=np.array([0.,.001,.01,.037,.1,.35,3.1,24.])
    error=0.
    for shift in (.084,-.01,.00133,.000013):
        for wave in (1.4,13.7):
            measured=translated_ball_difference(lambda rr:spherical_jn(0,rr*wave),radii,shift)
            z=wave*shift
            factor=-z*z/6+z**4/120-z**6/5040 if abs(z)<.01 else spherical_jn(0,abs(z))-1
            exact=factor*radii**2*spherical_jn(1,wave*radii)/wave
            scale=max(abs(exact))
            error=max(error,max(abs(measured-exact))/scale)
        constant=translated_ball_difference(lambda rr:np.ones_like(rr),radii,shift)
        assert np.all(constant==0)
    assert error<1e-7,error
    note("translated-ball-controls.json",dict(max_fraction_of_max_shell_mass=error,constant_mode_exact=True))


if __name__=="__main__":control()
