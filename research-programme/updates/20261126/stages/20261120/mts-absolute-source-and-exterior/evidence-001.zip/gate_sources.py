import hashlib
import io
import json
import os
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parent
PREV = ROOT.parent / "mts-two-way-scalar-streams-20261120"
PIN = "d2ee208071042fc7dacc626526f82a64153540d3cfe0d5782723489f73c7f8ff"
for name in ("OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS", "NUMEXPR_NUM_THREADS", "BLIS_NUM_THREADS"):
    os.environ[name] = "1"
sys.dont_write_bytecode = True


def sha(path):
    with path.open("rb") as handle:
        return hashlib.file_digest(handle, "sha256").hexdigest()


assert sha(PREV / "seal.json") == PIN
FILES = json.loads((PREV / "seal.json").read_bytes())["files"]


def checked(name):
    path = PREV / name
    assert sha(path) == FILES[name], name
    return path


for name in FILES:
    if name.endswith(".py"):
        checked(name)
sys.path.insert(0, str(PREV))
from local import np, SITES, SPANS, fixture, hold as inherited_hold, unpack


def hold():
    inherited_hold()
    if (ROOT / "STOP-REQUESTED").exists():
        raise RuntimeError("Owner hold")


def save(name, data):
    hold()
    path = ROOT / name
    if path.exists():
        assert path.read_bytes() == data, path
    else:
        with path.open("xb") as handle:
            handle.write(data)


def pack(name, **kwargs):
    buffer = io.BytesIO()
    np.savez_compressed(buffer, **kwargs)
    save(name, buffer.getvalue())


def note(name, value):
    save(name, (json.dumps(value, sort_keys=True, indent=2, allow_nan=False, default=lambda obj: obj.tolist()) + "\n").encode())
