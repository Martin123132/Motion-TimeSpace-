from gate_sources import *
from scipy.integrate import simpson


def run():
    ledger = []
    shell_budget = []
    for model in ("cold","heavy"):
        for epoch in ("start","end"):
            key = model+"-"+epoch
            ref = unpack(ROOT/(key+"-fine-hot.npz"))
            for variation in ("base","time","space","flat","kin"):
                alt = unpack(ROOT/(key+"-"+variation+"-hot.npz"))
                mask = np.arange(0,len(ref["eta"]),2)
                np.testing.assert_allclose(alt["eta"],ref["eta"][mask],atol=1e-14,rtol=0)
                primary = ref["moments"][mask,:,:,:-1]
                compare = alt["moments"][:,:,:,:-1]
                peak = np.max(abs(primary),axis=(0,3))
                ledger.append(dict(key=key,variant=variation,peak_relative_component_differences=np.max(abs(compare-primary),axis=(0,3))/peak,
                                   matched_target_error=np.max(abs(alt["difference"][:,:-1]/alt["target"][:,:-1]),axis=1)))
    for path in sorted(ROOT.glob("*-native-work.npz")):
        full=unpack(path)
        vals=full["shells"]
        assert full["channels"].tolist()==["energy","surface_flux","pressure_work","metric_work"]
        measured=vals[-1,:,0]-vals[0,:,0]
        terms=simpson(vals[:,:,1:],x=full["eta"],axis=0)
        scale=np.maximum.reduce([abs(measured),abs(terms.sum(axis=1)),np.max(abs(terms),axis=1)])
        error=(measured-terms.sum(axis=1))/scale
        coarse=simpson(vals[::2,:,1:],x=full["eta"][::2],axis=0)
        shell_budget.append(dict(tag=path.name.removesuffix("-native-work.npz"),measured=measured,individual_terms=terms,
            error=error,norm=scale,time_quadrature_change=(coarse-terms).sum(axis=1)/scale))
    if "--save" in sys.argv:
        note("passive-controls.json",ledger)
        note("live-thermal-energy.json",shell_budget)
    for entry in shell_budget:print(entry["tag"],"hot energy, worst ppm",np.max(abs(entry["error"]),axis=1)*1e6)


if __name__=="__main__":run()
