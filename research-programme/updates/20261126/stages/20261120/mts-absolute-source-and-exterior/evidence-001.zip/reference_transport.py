from gate_sources import *
from live_hot import Hot
from scipy.interpolate import CubicHermiteSpline, CubicSpline
from ball_mass import translated_ball_difference
from scipy.special import roots_legendre


class ReferenceHot(Hot):
    def __init__(self,inventory,level):
        super().__init__(inventory,2)
        self.v0 = 1/np.hypot(1.,self.a0*self.ratio)
        self.amax = 0.
        self.conservative = level>=5
        order = 48 if level==3 else 80
        self.directions,self.angular = roots_legendre(order)
        self.angular *= .5
        self.initial = None

    def sample(self,mat,sol,clock,gradient):
        grad,rate=super().sample(mat,sol,clock,gradient)
        if self.initial is None:
            native = np.unique(np.round(np.r_[self.r[self.r<=24.],np.linspace(0.,.8,3201),np.linspace(.8,3.,2201),np.linspace(3.,10.,1401),np.linspace(10.,24.,1401)],12))
            potential=mat.mesh.points(clock,native)
            slope=mat.mesh.points(gradient,native)
            potential[-1]=0.;slope[0]=0.;slope[-1]=sol["vprime_edge"]
            self.initial=CubicHermiteSpline(native,potential,slope)
            self.start_grad=grad.copy()
            self.outer=slope[-1]
        return grad,rate

    def eval_reference(self,rad):
        return np.where(rad<=24., self.initial(np.minimum(rad,24.)),24.*self.outer*(1-24./np.maximum(rad,24.)))

    def force_gradient(self,index,velocity,gradient):
        return gradient-(velocity/self.v0[index])**2*self.start_grad

    def reference_theta(self,index,travel,angle):
        distance=travel[index]
        pos=np.sqrt((self.rwork-distance)**2+2*self.rwork*distance*(1-angle))
        return (self.eval_reference(pos)-self.eval_reference(self.rwork))/self.v0[index]**2

    def distance(self):
        t=self.time
        middle=1/np.hypot(1.,self.calendar(.5*t)[0]*self.ratio)
        end=1/np.hypot(1.,self.calendar(t)[0]*self.ratio)
        return t*(self.v0+4*middle+end)/6

    def moments(self,state,a):
        output=super().moments(state,a)
        if self.conservative:
            self.ref_m0=np.zeros((2,2,len(self.r)))
            self.ref_volume=np.zeros_like(self.ref_m0)
        if self.time==0.:return output
        vel=1/np.hypot(1.,self.ratio*a)
        weight=np.r_[self.radiation,self.amplitude*self.q/vel[1:]]/a**4
        travel=self.distance()
        angle=self.directions
        kernel=np.stack((self.angular,self.angular*angle,self.angular*angle**2,self.angular*(1.5*angle**2-.5)))
        for index,speed in enumerate(vel):
            analytic=self.reference_theta(index,travel,angle)
            components=kernel@analytic.T
            components*=weight[index]*np.array([1.,speed,speed**2,speed**2])[:,None]
            output[int(index!=0)]+=components
            if self.conservative:
                species=int(index!=0)
                ratio=np.array([1.,speed**2/3])[:,None]
                self.ref_m0[species]+=components[0]*ratio
                primitive=translated_ball_difference(self.eval_reference,self.r,travel[index],24)
                self.ref_volume[species]+=ratio*(weight[index]/self.v0[index]**2)*primitive
            if index:
                self.amax=max(self.amax,(np.max(abs(analytic))+np.max(abs(state[index])))*self.q[index-1]/(1+np.exp(-self.q[index-1])))
        return output

    def project(self,moments,radii):
        values=CubicSpline(self.r,moments,axis=2,bc_type="natural")(radii)
        if not self.conservative:return values
        direct=CubicSpline(self.r,self.ref_m0,axis=2,bc_type="natural")(radii)
        primitive=CubicHermiteSpline(self.r,self.ref_volume,self.ref_m0*self.r**2,axis=2)
        density=primitive(radii,1)/radii**2
        first=radii<self.r[1]
        start=self.ref_m0[:,:,0]
        slope=self.ref_m0[:,:,1]-start
        mass=self.ref_volume[:,:,1]/self.r[1]**3-start/3
        second=(mass-slope/7)/(1./5-1./7)
        fraction=(radii[first]/self.r[1])**2
        density[:,:,first]=start[:,:,None]+second[:,:,None]*fraction+(slope-second)[:,:,None]*fraction**2
        values[:,0]+=density[:,0]-direct[:,0]
        values[:,2]+=density[:,1]-direct[:,1]
        return values

    def full_state(self,residual):
        travel=self.distance()
        return residual+np.stack([self.reference_theta(index,travel,self.mu) for index in range(len(travel))])
