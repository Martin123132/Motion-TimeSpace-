from gate_sources import *
from reference_transport import ReferenceHot
from scipy.interpolate import CubicSpline


class ConservedHot(ReferenceHot):
    def __init__(self,inventory,level):
        super().__init__(inventory,5)
        self.cauchy=np.zeros((len(self.q),len(self.r)))
        self.current_volume=self.cauchy.copy()
        self.rate=None

    def prepare(self,index,dt,field):
        if index==0:
            self.phase=field
            return field
        self.current_volume=self.cauchy+dt*self.rate
        self.current_volume[:,0]=0.
        if index%2==0:self.cauchy=self.current_volume.copy()
        average=np.zeros_like(self.current_volume)
        average[:,1:]=3*self.current_volume[:,1:]/self.r[1:]**3
        average[:,0]=(4*average[:,1]-average[:,2])/3
        gradient=CubicSpline(self.r,average,axis=1,bc_type=((1,np.zeros(len(self.q))),"natural"))(self.r,1)
        wanted=average+self.r*gradient/3
        present=field[1:]@self.weight
        output=field.copy()
        output[1:]+=(wanted-present)[:,:,None]
        self.phase=output
        return output

    def moments(self,state,a):
        result=super().moments(state,a)
        vel=1/np.hypot(1.,self.ratio[1:]*a)
        weight=self.amplitude*self.q/vel/a**4
        weights=np.stack((weight,weight*vel**2/3))
        self.ref_m0[1]+=weights@(state[1:]@self.weight)
        self.ref_volume[1]+=weights@self.current_volume
        return result

    def sample(self,mat,sol,clock,gradient):
        output=super().sample(mat,sol,clock,gradient)
        kin=-mat.a*(mat.H*np.expm1(clock)+np.exp(clock)*sol["expansion"])
        mesh=mat.mesh
        source=mesh.points(mesh.primitive(mesh.r**2*kin),np.minimum(self.r,24.))
        source[0]=0.
        vel=1/np.hypot(1.,self.ratio[1:]*mat.a)
        dipole=self.phase[1:]@(self.weight*self.mu)
        self.rate=source[None,:]-(vel[:,None]*self.r**2)*dipole
        return output
