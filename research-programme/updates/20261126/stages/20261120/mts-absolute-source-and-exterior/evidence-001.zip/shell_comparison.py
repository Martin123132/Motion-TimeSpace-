from gate_sources import *


def run():
    rows=[]
    for path in sorted(ROOT.glob("*-hot-shells.npz")):
        tag=path.name.removesuffix("-hot-shells.npz")
        key="-".join(tag.split("-")[:2])
        live=unpack(path)
        direct=json.loads((ROOT/(key+"-fine-shell-energy.json")).read_bytes())
        coarse=json.loads((ROOT/(key+"-base-shell-energy.json")).read_bytes())
        measured=live["shells"][-1,:,0]-live["shells"][0,:,0]
        scale=np.array(direct["scale"]);exact=np.array(direct["measured"])
        rows.append(dict(tag=tag,measured=measured,independent_frozen_metric=exact,scale=scale,relative=(measured-exact)/scale,
                         external_order_change=(np.array(coarse["measured"])-exact)/scale))
        print(tag,"max shell-energy discrepancy vs independent L.O.S. (ppm)",np.round(np.max(abs((measured-exact)/scale),axis=1)*1e6,2))
    if "--save" in sys.argv:note("independent-shell-tests.json",rows)


if __name__=="__main__":run()
