from gate_sources import *
import live_gravity as live


def run(model, epoch):
    tag = f"{model}-{epoch}-d2-on1-n8-s2-c1-uniform"
    reference = unpack(checked(tag+"-metric.npz"))
    radius = np.unique(np.r_[np.linspace(0., .8, 3201), np.linspace(.8, 3., 2201), np.linspace(3., 10., 1401), np.linspace(10., 24., 1401)])
    images = []
    saved_geometry = live.geometry
    compared = []

    def observe(mat, sol):
        result = saved_geometry(mat, sol)
        if not mat.feedback:
            return result
        hold()
        clock, space, _, gradient = result
        mesh = mat.mesh
        lapse = np.exp(clock)
        kinematic = -mat.a*(mat.H*np.expm1(clock)+lapse*sol["expansion"])
        sample = lambda value: mesh.points(value, radius)
        potential = sample(clock)
        spatial = sample(space)
        slope = sample(gradient)
        velocity = sample(kinematic)
        measured_edge = np.array([potential[-1], spatial[-1], slope[-1], sol["vprime_edge"]])
        assert max(abs(measured_edge[:2])) < 1e-14
        potential[-1] = spatial[-1] = velocity[-1] = 0.
        slope[0] = 0.
        slope[-1] = sol["vprime_edge"]
        solar = mat.slow_parts(sol["beta"])
        exterior = lambda val: mesh.points(val, [24.])[0]
        _, _, dust = mat.dust_source(sol["beta"])
        face_gradient = exterior(mat.gradpower) if mat.coef else 0.
        pressure = exterior(dust) + exterior(solar[3]) + .5*mat.coef*face_gradient
        images.append(dict(a=mat.a, U=potential, V=spatial, grad=slope, Vkin=velocity, edge_trace_pressure=pressure,
                           vprime_edge=sol["vprime_edge"], edge_extrap=measured_edge))
        return result

    def check_packet(name, **kwargs):
        expected = unpack(checked(name))
        assert expected.keys() == kwargs.keys()
        for key, value in kwargs.items():
            np.testing.assert_array_equal(value, expected[key], err_msg=f"{name}/{key}")
        compared.append(name)

    def check_inputs(name, value):
        ref = json.loads(checked(name).read_bytes())
        assert json.loads(json.dumps(value, default=lambda obj: obj.tolist())) == ref

    saved_io = live.pack, live.note
    live.geometry, live.pack, live.note = observe, check_packet, check_inputs
    try:
        live.run(model, epoch, 2, 1, 8, 2, 1, "uniform")
    finally:
        live.geometry = saved_geometry
        live.pack, live.note = saved_io
    assert len(images) == 17
    data = {key:np.stack([image[key] for image in images]) for key in images[0]}
    eta = np.linspace(0., reference["eta"][-1], 17)
    np.testing.assert_array_equal(data["a"][::2], reference["a"])
    indices = np.searchsorted(radius, SITES-1e-12)
    np.testing.assert_allclose(radius[indices], SITES, atol=1e-14, rtol=0.)
    original = np.searchsorted(reference["r"], SITES-1e-12)
    np.testing.assert_allclose(data["U"][::2, indices], (reference["V"]-reference["slip"])[:, original], atol=1e-15, rtol=0.)
    pack(f"{model}-{epoch}-full.npz", eta=eta, radius=radius, **data)
    note(f"{model}-{epoch}-replay.json", dict(exact_original_packets=compared, frames=len(images), model=model, epoch=epoch))
    print(model, epoch, len(compared), "arrays packets matched; full-radius metric saved", flush=True)


if __name__ == "__main__":
    for item in sys.argv[2:]:
        run(sys.argv[1], item)
