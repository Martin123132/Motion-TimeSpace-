from exact_source_stage import *
from shared_trace import Shared
from unittest.mock import patch
from functools import lru_cache
from copy import copy
import inspect
from scipy.interpolate import BPoly

def combine(grid,sub):
    suffix=f'{grid}-{sub}.npz'
    pieces=[]
    for prefix in ('period','second','third','fourth','partial'):
        with np.load(ROOT/(prefix+'-'+suffix)) as saved:
            pieces.append((saved['t'],saved['obs']));names=saved['names'];routes=saved['routes']
    assert all(left[0][-1]==right[0][0] for left,right in zip(pieces,pieces[1:]))
    dense=np.concatenate([p[0][:-1] for p in pieces[:-1]]+[pieces[-1][0]])
    obs=np.concatenate([p[1][:-1] for p in pieces[:-1]]+[pieces[-1][1]])
    with np.load(pin(PAIR,'matched-'+suffix)) as original:
        t=original['t'];corners=original['corners'];pos=np.searchsorted(dense,t)
        assert np.array_equal(dense[pos],t) and np.all(np.diff(dense)>0) and len(dense)==len(t)+2
    seams=np.stack([[pieces[i][1][-1],pieces[i+1][1][0]] for i in (0,1)])
    pack('full-grid-'+suffix,t=t,obs=obs[pos],seams=seams,corners=corners,names=names,routes=routes)

def run():
    check('entry-freeze.json');trace=Shared();p=import_at(OLD,'partial')
    wave=import_at(REF,'joint77_evolve');first=p.first
    periods=(first,p.second,p.third,p.fourth,p)
    joint=p.joint
    freeze('run-protocol.json',['entry-freeze.json','shared_trace.py','evolve_shared.py','project_shared.py','score_shared.py'])
    def locked(name):
        assert name in ('protocol.json','entry-freeze.json');check('run-protocol.json');guard()
    class Host(p.Host):
        def __init__(self,grid,sub):
            super().__init__(grid,sub);self.external=trace.overlay(self.external,[2,3])
            assert np.array_equal(self.external(np.log(self.t[0]))[[2,3]],trace.value)
    joint.window.ROOT=joint.common.ROOT=ROOT
    for mod in periods:
        mod.ROOT=ROOT;mod.Host=Host;mod.save=save
        if mod==first:mod.verify=locked
        else:mod.locked=locked
    for mod,method,prefix in [(p.second,'source','period-'),(p.third,'parent','second-'),(p.fourth,'parent','third-'),(p,'parent','fourth-')]:
        orig=getattr(mod,method)
        setattr(mod,method,lambda name,orig=orig,prefix=prefix:ROOT/name if name.startswith(prefix) and name.endswith('.npz') else orig(name))
    original=first.pinned
    first.pinned=lambda folder,name: ROOT/name if (folder==PAIR and name.startswith('matched-switch-')) or (folder==EXCH and name=='forecast.json') else original(folder,name)
    factory=first.make_interp_spline
    with np.load(pin(BANK,'material-halfstep/forcing-heavy.npz')) as data:
        times=data['eta'];mask=(times>trace.at-.30)&(times<=trace.at);j_old=data['values'][data['keys'].tolist().index('hJ'),mask,0]
    def history(grid):
        used=[]
        def spline(x,y,**opts):
            if y.ndim==1 and np.array_equal(x,times[mask]) and np.array_equal(y,j_old):
                used.append(1);return lambda t:trace(np.log(t))[...,1]
            return factory(x,y,**opts)
        with patch.object(first,'make_interp_spline',spline):hist=first.History(grid)
        assert used==[1];return hist
    native_source=wave.old.source
    @lru_cache(maxsize=2)
    def prepared_source(grid):
        obj=copy(native_source(grid));base=type(obj);flow=obj.flow
        keys=[list(flow.qkeys).index(k) for k in ('henergy','hJ')]
        spline=inspect.getclosurevars(flow.q).nonlocals['q']
        jets=[trace.incoming(trace.log,order)-spline(trace.log,order)[keys,0] for order in range(3)]
        repair=BPoly.from_derivatives([trace.log,trace.right],[jets,np.zeros((3,2),complex)])
        class Resolved(base):
            def environment(self,t,side=None):
                env=super().environment(t,side);force=dict(env[1]);x=np.log(t)
                inside=(x>trace.log)&(x<trace.right);edge=x==trace.log
                for slot,name in enumerate(('henergy','hJ')):
                    value=force[name].copy();value[inside]+=repair(x[inside])[:,slot];value[edge]=trace.value[slot];force[name]=value
                return (env[0],force,*env[2:])
        obj.__class__=Resolved
        entry=obj.environment(np.array([trace.at]))[1]
        assert np.array_equal([entry['henergy'][0],entry['hJ'][0]],trace.value)
        return obj
    wave.ROOT=ROOT;wave.locked=locked;wave.pack=pack
    resolved_bank=wave.Bank();matched_bank=p.MatchedBank()
    for grid in ('p16','p32'):
        hist=history(grid)
        for sub in (2,4):
            print('physical evolution',grid,sub,flush=True)
            host=Host(grid,sub);stamp=np.array([trace.at]);env=host.environment(stamp);b,q=env[:2]
            ref=prepared_source(grid);refenv=ref.environment(stamp)[1]
            with np.load(ROOT/f'matched-switch-{grid}.npz') as ar:
                x=ar['entry'];v=b['hv'][0];mass2=(b['a'][0]*b['hm'][0])**2;rho=hist.rho0/b['a'][0]
                energy=(v*x[11]+mass2*b['hb'][0]*x[10]+q['henergy'][0]+3*v*v*x[12])/rho
                cur=(host.kk*v*x[10]+q['hJ'][0])/rho
                errs=[100*abs(measured-ar[key])/abs(ar[key]) for key,measured in [('energy',energy),('current',cur)]]
                for slot,key in enumerate(('henergy','hJ')):
                    assert q[key][0]==refenv[key][0]==ar['shared'][slot]
                assert max(errs)<=.5
            far=np.array([host.t[-1]]);unchanged=native_source(grid).environment(far)[1]
            assert all(np.array_equal(unchanged[k],ref.environment(far)[1][k]) for k in ('henergy','hJ'))
            put(f'interface-{grid}-{sub}.json',dict(source_identical=True,energy_replay_pct=errs[0],current_replay_pct=errs[1],resolved_end_source_unchanged=True))
            names=[]
            for mod,label in zip(periods,('period','second','third','fourth','partial')):
                name=f'{label}-{grid}-{sub}.npz'
                if not (ROOT/(name+'.receipt')).exists():
                    mod.run(grid,sub,matched_bank,hist);freeze(name+'.receipt',['run-protocol.json',name])
                check(name+'.receipt');names.append(name)
            combine(grid,sub)
            with patch.object(wave.old,'source',prepared_source):
                name=f'joint-{grid}-{sub}.npz'
                if not (ROOT/(name+'.receipt')).exists():
                    control=wave.run(grid,sub,resolved_bank);put(f'wave-{grid}-{sub}.json',control)
                    freeze(name+'.receipt',['run-protocol.json',name,f'wave-{grid}-{sub}.json'])
                check(name+'.receipt')
    freeze('gravity-freeze.json',['run-protocol.json']+[f'interface-{grid}-{sub}.json' for grid in ('p16','p32') for sub in (2,4)]+[f'{tag}-{grid}-{sub}.npz' for tag in ('joint','full-grid','period','second','third','fourth','partial') for grid in ('p16','p32') for sub in (2,4)])
if __name__=='__main__':run()
