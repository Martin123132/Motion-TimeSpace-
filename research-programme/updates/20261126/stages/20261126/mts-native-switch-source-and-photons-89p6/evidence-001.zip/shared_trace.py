from exact_source_stage import *
from scipy.interpolate import BPoly,make_interp_spline

class Shared:
    def __init__(self):
        check('native-freeze.json')
        with np.load(ROOT/'native-standard.npz') as raw:
            self.at=raw['t'][1];self.value=raw['source'][1];self.right=np.log(raw['t'][2])
        with np.load(pin(BANK,'material-halfstep/forcing-heavy.npz')) as src:
            time=src['eta'];keys=src['keys'].tolist()
            values=src['values'][[keys.index(k) for k in ('henergy','hJ')],:,0].T
        before=(time>self.at-.30)&(time<self.at)
        self.log=np.log(self.at)
        self.incoming=make_interp_spline(np.r_[np.log(time[before]),self.log],np.vstack([values[before],self.value]),k=5)
        self.outer=make_interp_spline(np.log(time),values,k=5)
        diff=[self.incoming(self.log,order)-self.outer(self.log,order) for order in range(3)]
        self.join=BPoly.from_derivatives([self.log,self.right],[diff,np.zeros((3,2),complex)])
        assert np.allclose(self.incoming(self.log),self.value,rtol=1e-14,atol=0)

    def __call__(self,x,nu=0):
        x=np.asarray(x);flat=x.reshape(-1);ans=self.outer(flat,nu)
        left=flat<=self.log;middle=(flat>self.log)&(flat<self.right)
        ans[left]=self.incoming(flat[left],nu)
        if nu==0:ans[flat==self.log]=self.value
        ans[middle]+=self.join(flat[middle],nu)
        return ans.reshape((*x.shape,2))

    def overlay(self,base,cols):
        def read(x,nu=0):
            out=base(x,nu).copy();out[...,cols]=self(x,nu);return out
        return read

    def time_spline(self,base,indices):
        def read(t,nu=0):
            assert nu in (0,1);out=base(t,nu).copy();value=self(np.log(t),nu)
            if nu:value=value/np.asarray(t)[...,None]
            out[...,indices]=value
            return out
        return read
