from exact_source_stage import *

def run():
    check('gravity-freeze.json');ph=import_at(PHOTO,'predict');original=ph.pinned
    ph.ROOT=ROOT;ph.record=save
    def route(folder,name):
        if (folder==ph.MATCH and name.startswith('full-grid-')) or (folder==ph.WAVE and name.startswith('joint-')):
            return ph.track(ROOT/name)
        return original(folder,name)
    ph.pinned=route
    for file in ('predict.py','score.py'):ph.track(pin(PHOTO,file))
    ph.receipt=lambda names:{file:sha(ROOT/file) for file in ['gravity-freeze.json','project_shared.py','score_shared.py',*[f for f in names if f not in ('predict.py','score.py')]]}
    ph.run()
if __name__=='__main__':run()
