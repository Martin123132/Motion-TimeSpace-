import csv,os,subprocess,tempfile
from unittest.mock import patch
from types import SimpleNamespace
from scipy.interpolate import CubicSpline,make_interp_spline
from exact_source_stage import *
from exact_source_stage import ROOT as HERE
cap=import_at(BANK,'capture89')
import early_source as es

def capture(model,func):
    native=cap.diag.native
    with np.load(pin(BANK,'material-halfstep/forcing-heavy.npz')) as old:
        timeline=old['eta'];legs=old['nodes'];coord=old['coord'][0];keys=old['keys'].tolist()
        at=switch();i=np.searchsorted(timeline,at);bracket=timeline[i-1:i+1]
    path=pin(BANK,'canonical-input.npz')
    with np.load(path) as bgdata:
        back={key:bgdata[key] for key in ('heavy_efold','phi_h','phidot_h','heavy_mass_mpc')}
    pars=native.engine.inherited.params_for(path,background_boost=8.);pars.DoLateRadTruncation=False
    bg=native.engine.camb.get_background(pars);bg.Params.Accuracy.IntTolBoost=6
    with cap.pin('capture-heavy.csv').open() as f:blocks=list(csv.DictReader(f))
    extra=['mts_dphi_s','mts_dphidot_s','mts_dphi_h','mts_dphidot_h'];audit=['mts_match_count','mts_match_tau','mts_drho_h','mts_dp_h','mts_q_h']
    columns=extra+audit+cap.NAMES
    keep=['mts_dphi_h','mts_dphidot_h','a','adotoa','phi','sigma','etak','k']
    targets=np.array([bracket[0],at,bracket[1]])
    with patch.object(cap.diag.symbolic,'compile_sympy_to_camb_source_func',return_value=func):
        for tag,added in [('standard',np.array([at])),('refined',np.array([.5*(at+bracket[0]),at,.5*(at+bracket[1])]))]:
            end=i+2;times=np.unique(np.r_[timeline[17:end],added]);pos=np.searchsorted(times,targets);assert np.array_equal(times[pos],targets)
            values=np.empty((len(legs),len(targets),len(keep)));seen=np.zeros(len(legs),int)
            for idx,block in enumerate(blocks):
                guard();begin,last=int(block['first']),int(block['last'])+1;spec=legs[begin:last]
                ks=np.unique(np.r_[spec,float(block['control']),float(block['hierarchy_cap'])])
                file=f'legs-{tag}-{idx:02}.npz';dest=HERE/file
                if dest.exists():
                    with np.load(dest) as arc:
                        assert np.array_equal(arc['k'],spec) and np.array_equal(arc['eta'],targets) and arc['keys'].tolist()==keep
                        small=arc['values']
                else:
                    raw=bg.get_time_evolution(ks,times,vars=extra+audit+[cap.Dummy(key) for key in cap.NAMES],lAccuracyBoost=4)[np.searchsorted(ks,spec)][:,pos]
                    assert not raw[:,:,columns.index('mts_match_count')].any()
                    small=raw[:,:,[columns.index(key) for key in keep]]
                    assert np.isfinite(small).all() and np.allclose(small[:,:,-1],spec[:,None],rtol=1e-13,atol=0)
                    pack(file,k=spec,eta=targets,keys=keep,values=small)
                values[begin:last]=small;seen[begin:last]+=1
                if idx%8==0:print(tag,idx+1,'of',len(blocks),flush=True)
            assert np.all(seen==1)
            raw=dict(zip(keep,values.transpose(2,0,1)))
            shell=np.array(json.loads(es.pin('legs.json').read_bytes())['squared_radii'])
            a=raw['a'];hub=raw['adotoa'];alpha=raw['sigma']/legs[:,None];phi=raw['etak']/legs[:,None]-hub*alpha
            af=a[int(blocks[0]['last'])];assert np.max(abs(a/af-1))<1e-10
            field,speed=[CubicSpline(back['heavy_efold'],back[key])(np.log(af)) for key in ('phi_h','phidot_h')]
            am2=(a*back['heavy_mass_mpc'])**2
            perturb=raw['mts_dphi_h']+speed*alpha
            normal=raw['mts_dphidot_h']+(-3*hub*speed-am2*field)*alpha
            data=SimpleNamespace(nodes=legs,shell=shell,first={'phi':phi,'hn':normal,'hf':perturb,'hu':normal-3*speed*phi})
            mapper=es.Project(data);op=es.Fast(mapper.ops[0],data)
            assert np.array_equal(np.array(es.PROBES[0]),coord)
            product=op.product
            energy=speed*(3*product('phi','hu')+7.5*product('phi','phi')*speed)+.5*(product('hn','hn')+op.grad('hf','hf')+(af*back['heavy_mass_mpc'])**2*product('hf','hf'))
            current=-op.dg('hn','hf');pack(f'native-{tag}.npz',t=targets,source=np.stack([energy,current],axis=1),wave=mapper.ops[0][1],coord=coord,fields=['henergy','hJ'])
            print(tag,'complete',flush=True)

def score_source():
    from scipy.interpolate import make_interp_spline
    with np.load(pin(BANK,'material-halfstep/forcing-heavy.npz')) as old:
        clock=old['eta'];data=old['values'][[old['keys'].tolist().index(k) for k in ('henergy','hJ')],:,0].T
    with np.load(HERE/'native-standard.npz') as first,np.load(HERE/'native-refined.npz') as refined:
        nodes=first['t'];assert np.array_equal(nodes,refined['t']) and nodes[1]==switch()
        left=(clock<nodes[1])&(clock>nodes[1]-.25)
        oldleft=make_interp_spline(np.log(clock[left]),data[left],k=5)(np.log(nodes[1]));right=make_interp_spline(np.log(clock),data,k=5)(np.log(nodes[1]))
        norm=abs(oldleft-right)
        idx=np.searchsorted(clock,nodes[[0,2]]);assert np.array_equal(clock[idx],nodes[[0,2]])
        direct=first['source'][1];fine=refined['source'][1]
        replay=100*abs(first['source'][[0,2]]-data[idx])/norm
        refinement=100*abs(direct-fine)/norm
        results=dict(switch=nodes[1],keys=['henergy','hJ'],native=[enc(z) for z in direct],left=[enc(z) for z in oldleft],bracketed=[enc(z) for z in right],left_error_on_split_pct=(100*abs(oldleft-direct)/norm).tolist(),bracketed_error_on_split_pct=(100*abs(right-direct)/norm).tolist(),refine_on_split_pct=refinement.tolist(),knot_replay_on_split_pct=replay.tolist(),knot_replay_on_source_pct=(100*abs(first['source'][[0,2]]-data[idx])/abs(data[idx])).tolist(),passes=bool(max(refinement)<=.5 and np.max(replay)<=.5))
        put('native-check.json',results);print(results,flush=True)
        assert results['passes'],'native source not resolved at requested precision'
    freeze('native-freeze.json',['PROTOCOL.md','exact_source_stage.py','native_source.py','native-standard.npz','native-refined.npz','native-check.json']+[p.name for p in sorted(HERE.glob('legs-*.npz'))])
if __name__=='__main__':
    if sys.argv[1:2]==['--child']:
        with patch.object(cap.driver,'HERE',HERE),patch.object(cap.driver,'NAMES',cap.NAMES),patch.object(cap.driver,'run',capture),patch.object(cap.driver,'save',save):
            cap.driver.main()
    else:
        with tempfile.TemporaryDirectory(dir=HERE,prefix='reader-') as tmp:
            subprocess.run([sys.executable,'-B',__file__,'--child',tmp,'heavy'],check=True)
        score_source()
