from exact_source_stage import *

def run():
    guard();check('gravity-freeze.json')
    ph=import_at(PHOTO,'predict');ph.ROOT=ROOT;ph.report=put
    sc=import_at(PHOTO,'score');sc.score()
    fresh=json.loads((ROOT/'scores.json').read_bytes());previous=json.loads(pin(PHOTO,'scores.json').read_bytes())
    trials=[]
    for row in fresh['rows']:
        if row['stress']!='comp' or row['setting']!='primary' or row['sub']!=4:continue
        grid=row['grid'];old=next(x for x in previous['rows'] if (x['grid'],x['stress'],x['setting'],x['sub'])==(grid,'comp','primary',4))
        trials.append(dict(grid=grid,previous_pct=old['route_gap_pct'],new_pct=row['route_gap_pct'],pass_routes=row['route_pass'],launch_pct=[row['momentum_pct_launch'],row['density_pct_launch']],launch_pass=row['launch_pass']))
    assert len(trials)==2
    put('result.json',dict(trials=trials,orders=['energy','current','joint'],all_numerical_controls=all(c['passes'] for c in fresh['checks']),all_numerical_control_count=len(fresh['checks']),both_grids_pass=all(t['pass_routes'] for t in trials),cold_source='unchanged archived cold readout',frozen=sha(ROOT/'prediction-freeze.json'),reference_scores=sha(pin(PHOTO,'scores.json'))))
if __name__=='__main__':run()
