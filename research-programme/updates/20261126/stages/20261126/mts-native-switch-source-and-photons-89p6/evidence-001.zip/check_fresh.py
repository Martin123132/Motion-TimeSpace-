from exact_source_stage import *

def verify():
    pre=json.loads((ROOT/'native-check.json').read_bytes())
    scale=abs(np.array([complex(*z) for z in pre['left']])-np.array([complex(*z) for z in pre['bracketed']]))
    labels=('standard','independent2','independent4')
    with np.load(pin(BANK,'material-halfstep/forcing-heavy.npz')) as old:
        clock=old['eta'];fields=old['values'][[old['keys'].tolist().index(k) for k in ('henergy','hJ')],:,0].T
    arrays=[];rows={}
    for label in labels:
        with np.load(ROOT/f'native-{label}.npz') as packet:
            times=packet['t'];assert times[1]==switch();arr=packet['source'];arrays.append(arr)
            rows[label]=(100*abs(arr[[0,2]]-fields[np.searchsorted(clock,times[[0,2]])])/scale).tolist()
    refinement=(100*abs(np.array(arrays)[1:,1]-arrays[0][1])/scale).tolist()
    passed=max(np.max(refinement),max(np.max(x) for x in rows.values()))<=.5
    put('fresh-check.json',dict(replay=rows,refinement=refinement,passes=bool(passed),previous_failed_check=sha(ROOT/'native-check.json'),primary=labels[0],independent=list(labels[1:])))
    print('fresh direct native',passed,rows,refinement,flush=True)
    if not passed:raise ValueError('native refinement failed; stop before photon forecast')
    freeze('native-freeze.json',['PROTOCOL.md','exact_source_stage.py','native_source.py','fresh_native.py','check_fresh.py','native-check.json','fresh-check.json']+[p.name for p in sorted(ROOT.glob('native-*.npz'))]+[p.name for p in sorted(ROOT.glob('legs-*.npz'))])
