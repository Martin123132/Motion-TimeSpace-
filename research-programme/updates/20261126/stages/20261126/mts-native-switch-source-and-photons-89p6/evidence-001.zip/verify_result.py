from exact_source_stage import *

def verify():
    for name in ('native-freeze.json','entry-freeze.json','run-protocol.json','gravity-freeze.json'):check(name)
    for ref,seal in PINS.items():assert sha(ref/'seal.json')==seal
    with np.load(ROOT/'native-standard.npz') as n:source=n['source'][1]
    for grid in ('p16','p32'):
        with np.load(ROOT/f'matched-switch-{grid}.npz') as fresh,np.load(pin(PAIR,f'matched-switch-{grid}.npz')) as old:
            assert np.array_equal(fresh['shared'],source)
            for key in ('lag','shape','target'):assert np.array_equal(fresh[key],old[key])
            state=fresh['entry'];diff=state-old['entry'];diff[10:12]=0;assert not np.any(diff)
            assert sha(ROOT/f'switch-{grid}.npz')==sha(pin(REF,f'switch-{grid}.npz'))
    pred=json.loads((ROOT/'prediction-freeze.json').read_bytes());scores=json.loads((ROOT/'scores.json').read_bytes())
    assert scores['frozen_prediction_sha256']==sha(ROOT/'prediction-freeze.json')
    assert all(sha(ROOT/file)==h for file,h in pred['files'].items()) and all(sha(BASE/file)==h for file,h in pred['inputs'].items())
    for setting in ('primary','angle','time'):
        with np.load(ROOT/f'prediction-{setting}.npz') as fresh,np.load(pin(PHOTO,f'prediction-{setting}.npz')) as old:
            for key in ('scale','cold','original_heavy','labels','models'):assert np.array_equal(fresh[key],old[key]),key
            assert np.isfinite(fresh['energy_current']).all()
    result=json.loads((ROOT/'result.json').read_bytes())
    assert len(scores['rows'])==24 and len(result['trials'])==2
    print(json.dumps(result,indent=2))
if __name__=='__main__':verify()
