from pathlib import Path
import hashlib,io,json,sys
from datetime import datetime,timezone
import numpy as np
ROOT=Path(__file__).resolve().parent
BASE=ROOT.parent
BANK=BASE/'mts-photon-matter-89p6-20261124'
OLD=BASE/'mts-full-window-companion-joint-89p6-20261126'
PHOTO=BASE/'mts-full-window-companion-photons-89p6-20261126'
PREP=BASE/'mts-switch-current-quadratures-89p6-20261125'
REF=BASE/'mts-prepared-joint-77-switch-89p6-20261126'
PAIR=BASE/'mts-matched-joint-77-switch-89p6-20261126'
EXCH=BASE/'mts-switch-companion-exchange-89p6-20261126'
PINS={BANK:'bc32739cb1aa9f24909005b4cfde0d6c056a9508b178a4e0fe126a9ba218a159',OLD:'b97323d32387750279ffca184379a436426ad10bd63407e31fbe4c1f0ca83665',PHOTO:'41336c5e42fd6ea43be92f179f55ced551fd205bfcf883e6a5861e45e0728d2a',PREP:'c865dc7c06afec41b22a7bfeb253821a1020fe663a98e1d133bf786e7962fc15',REF:'73b24e93fea12844c02baaa76fa61c200b63a90096986c912d5f50bbed338a40',PAIR:'3aab615be69d49dcdafeac123dc1c70ecd6cd18516791a15dd0c478d88a51845',EXCH:'972e5431a544dc8c6db9bcbd9e9d6cc98166128cad28e8ad8cc88be8020a6f5e'}
def sha(path):
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
def guard():
    assert not any((folder/'STOP-REQUESTED').exists() for folder in [ROOT,BASE,*PINS])
def pin(folder,name):
    assert sha(folder/'seal.json')==PINS[folder];path=folder/name
    assert sha(path)==json.loads((folder/'seal.json').read_bytes())['files'][name]
    return path
def save(name,data):
    guard();path=ROOT/name
    if path.exists():assert path.read_bytes()==data,name
    else:
        with path.open('xb') as stream:stream.write(data)
def pack(name,**fields):
    buffer=io.BytesIO();np.savez_compressed(buffer,**fields);save(name,buffer.getvalue())
def put(name,data):save(name,(json.dumps(data,sort_keys=True,indent=2,allow_nan=False,default=lambda x:x.item())+'\n').encode())
def freeze(name,files):put(name,{file:sha(ROOT/file) for file in files})
def check(name):
    for file,h in json.loads((ROOT/name).read_bytes()).items():assert sha(ROOT/file)==h,file
def enc(x):return [float(x.real),float(x.imag)]
def switch():
    with np.load(pin(PREP,'launch-p32.npz')) as src:return src['start'].item()
def import_at(folder,module):
    pin(folder,module+'.py');sys.path.insert(0,str(folder));return __import__(module)
