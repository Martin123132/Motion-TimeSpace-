from exact_source_stage import *
from shared_trace import Shared
from unittest.mock import patch

def prep():
    common=Shared();inf=import_at(PREP,'infer_current');junction=import_at(EXCH,'junction')
    original=inf.inputs;factory=junction.make_interp_spline
    def inputs(grid):
        args=list(original(grid));args[8]=common.overlay(args[8],[2,3]);return tuple(args)
    def spline(x,y,**opts):
        out=factory(x,y,**opts)
        return common.time_spline(out,[1,3]) if y.ndim==2 and y.shape[-1]==4 else out
    allrows=[];tests={}
    with patch.object(inf,'inputs',inputs),patch.object(junction,'make_interp_spline',spline):
        for grid in ('p16','p32'):
            high=inf.infer(grid,96,.0015);lo=inf.infer(grid,48,.003);rows=junction.forecast(grid);allrows.extend(rows)
            with np.load(pin(PAIR,f'matched-switch-{grid}.npz')) as old:
                assert old['passed'] and old['t']==common.at
                entry=old['entry'].copy();entry[10:12]=high['live']*np.array([1,high['omega']])
                f,u=entry[10:12];bg=inputs(grid)[6](np.log(common.at));rho=high['rho0']/bg[0];mass2=high['omega']**2;b,v=high['osc']
                energy=(v*u+mass2*b*f+common.value[0]+3*v*v*entry[12])/rho
                current=(high['kk']*v*f+common.value[1])/rho
                target=high['live_data'];assert np.array_equal(target,old['target'])
                err=lambda val,ref:100*np.linalg.norm(val-ref)/np.linalg.norm(ref)
                tested={name:err(lo[name],high[name]) for name in ('matrix','live','delta')}
                tested.update(energy=err(energy,target[0]),instant_current=err(current,old['instant_target']),quadrature=err(complex(*rows[0]['current']),complex(*rows[1]['current'])),exchange_equation=err(complex(*rows[1]['current']),complex(*rows[1]['direct'])))
                tests[grid]=tested;print(grid,tested,flush=True);assert max(tested.values())<=.5 and high['sv_condition']<3
                assert np.array_equal(inputs(grid)[8](np.log(common.at))[[2,3]],common.value)
                pack(f'matched-switch-{grid}.npz',passed=True,t=common.at,entry=entry,lag=old['lag'],shape=old['shape'],shared=common.value,energy=energy,current=current,wave=high['live'],target=target)
            save(f'switch-{grid}.npz',pin(REF,f'switch-{grid}.npz').read_bytes())
    put('forecast.json',dict(predictions=allrows));put('preparation-checks.json',tests)
    freeze('entry-freeze.json',['native-freeze.json','shared_trace.py','prepare_shared.py','preparation-checks.json','forecast.json']+[f'{label}-{grid}.npz' for label in ('matched-switch','switch') for grid in ('p16','p32')])
if __name__=='__main__':prep()
