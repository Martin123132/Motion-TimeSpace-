from energy_io import *
from types import SimpleNamespace
from scipy.interpolate import make_interp_spline

def forecast():
    check('propagation-photon-freeze.json');freeze('current-method.json',['CURRENT-TEST.md','microscopic_current.py','propagation-scores.json','propagation-photon-freeze.json'])
    prior.sealed(prior.EXT,'source_io.py');sys.path.insert(0,str(prior.EXT));from source_io import spatial_module
    es=spatial_module().earlier.es
    get=lambda f:oldio.pin(oldio.PAD,'material-halfstep/'+f)
    with np.load(get('background-heavy.npz')) as ar:
        b=ar['hphi'];v=ar['hphidot'];mass=ar['hmass'].item();t=ar['eta']
    data={key:[] for key in ('f','n','gradient','mass','lapse','pdrate','vpsi','fd','nd','psi','phidot')}
    ks=[];mcounts=np.zeros(2,int);wcounts=mcounts.copy()
    for idx in range(38):
        name=f'linear-heavy-{idx:02}.npz'
        with np.load(get(name)) as ar,np.load(prior.sealed(prior.EXT,'native/'+name)) as mat:
            assert np.array_equal(ar['k'],mat['k']) and np.array_equal(ar['eta'],t) and np.array_equal(t,mat['eta']) and np.all(ar['good']) and np.all(mat['good'])
            k=ar['k'][:,None];ks.extend(ar['k']);arr=ar['values'];names=ar['keys'].tolist()
            col=lambda key:arr[:,:,names.index(key)]
            marr=mat['values'];mkeys=mat['keys'].tolist()
            for index,key in enumerate(('mts_dphi_h','mts_dphidot_h')):
                mcounts[index]+=np.count_nonzero(marr[:,:,mkeys.index(key)]);wcounts[index]+=np.count_nonzero(col(key))
            h=col('adotoa');m2=(mass*col('a'))**2;alpha=col('sigma')/k
            phi=col('etak')/k-h*alpha;psi=2*col('phi')-phi
            pd=(col('dgq')+(col('grho')+col('gpres'))*col('sigma'))/(2*k)-h*psi
            f=col('mts_dphi_h')+v*alpha;n=col('mts_dphidot_h')+(-3*h*v-m2*b)*alpha
            fd=n+v*psi;nd=-2*h*n-(k*k+m2)*f-m2*b*psi+3*v*pd
            for key,val in dict(f=f,n=n,gradient=k*k*f,mass=m2*f,lapse=m2*b*psi,pdrate=v*pd,vpsi=v*psi,fd=fd,nd=nd,psi=psi,phidot=pd).items():data[key].append(val)
    fields={k:np.concatenate(vals,axis=0) for k,vals in data.items()};ks=np.array(ks);assert len(ks)==782
    h=h[0];shell=np.array(json.loads(es.pin('legs.json').read_bytes())['squared_radii'])
    model=SimpleNamespace(nodes=ks,shell=shell,first=fields);projector=es.Project(model)
    sources=[];rates=[];flux=[];labels=['gradient','mass','lapse-field','potential rate','normal kinetic','lapse-momentum']
    for source in projector.ops:
        op=es.Fast(source,model);sources.append(-op.dg('n','f'))
        rates.append(-op.dg('nd','f')-op.dg('n','fd'))
        flux.append(np.column_stack([op.dg('gradient','f'),op.dg('mass','f'),op.dg('lapse','f'),-3*op.dg('pdrate','f'),-op.dg('n','n'),-op.dg('n','vpsi')]))
    j=np.array(sources).T;jd=np.array(rates).T;budget=np.stack(flux,axis=1)
    tmask=(t>=START)&(t<=END);controls={}
    for key,der in [('f','fd'),('n','nd')]:
        independent=make_interp_spline(np.log(t),fields[key].T,k=5)(np.log(t),1).T/t
        refval=independent[:,tmask];norm=np.max(abs(refval),axis=1);assert np.all(norm>0)
        rel=100*np.max(abs(fields[der][:,tmask]-refval),axis=1)/norm
        controls[key]=dict(max_pct=float(np.max(rel)),median_pct=float(np.median(rel)),failing_legs=int(np.sum(rel>.5)),worst_k=ks[np.argmax(rel)])
    pack('native-current-forecast.npz',eta=t,k=ks,j=j,rate=jd,h=h,terms=budget,names=labels)
    put('leg-controls.json',dict(legs=len(ks),nonzero_exported_matched=mcounts.tolist(),nonzero_exported_wave=wcounts.tolist(),kinematic=controls))
    freeze('native-current-freeze.json',['current-method.json','native-current-forecast.npz','leg-controls.json'])
def test():
    check('native-current-freeze.json');rows=[]
    with np.load(ROOT/'native-current-forecast.npz') as pred,np.load(oldio.pin(oldio.PAD,'material-halfstep/forcing-heavy.npz')) as ar:
        t=pred['eta'];sel=(t>=START)&(t<=END);assert np.array_equal(ar['eta'],t)
        j=ar['values'][ar['keys'].tolist().index('hJ')]
        d5=make_interp_spline(np.log(t),j,k=5)(np.log(t),1)/t[:,None]
        d7=make_interp_spline(np.log(t),j,k=7)(np.log(t),1)/t[:,None]
        target=d5+2*pred['h'][:,None]*j
        for idx,k in enumerate(ar['k']):
            col=lambda a:a[sel,idx]
            rows.append(dict(probe=idx,k=k,source_pct=err(col(pred['j']),col(j)),rate_pct=err(col(pred['rate']),col(d5)),rate_vs_order7_pct=err(col(pred['rate']),col(d7)),spline_control_pct=err(col(d5),col(d7)),exchange_pct=err(col(pred['terms'].sum(-1)),col(target)),algebra_pct=err(col(pred['terms'].sum(-1)),col(pred['rate']+2*pred['h'][:,None]*pred['j']))))
    put('current-source-scores.json',dict(freeze=sha(ROOT/'native-current-freeze.json'),rows=rows));print(rows,flush=True)
if __name__=='__main__':forecast();test()
