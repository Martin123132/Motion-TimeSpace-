from energy_io import *
from scipy.interpolate import make_interp_spline,CubicSpline
from scipy.special import roots_laguerre,expit

NAMES=['U rate','H times U','metric slip','Fq','background times current','photon-baryon exchange','cold exchange','light exchange','heavy coefficient redshift','heavy background table','heavy external field and momentum','heavy external energy','heavy external current','companion exchange','collisionless exchange']
def table(path,meta,t):
    with np.load(path) as f:
        knots=f['eta'];keys=f['bgkeys'].tolist();qkeys=f['keys'].tolist()
        bg=f['background'].T;aa=bg[:,keys.index('a')];nodes,weight=roots_laguerre(48)
        eps=np.hypot(meta['mass_over_temperature']*aa[:,None],nodes)
        thermal=meta['massless_limit_coeff']/(aa**2*(7*np.pi**4/120))*((eps*nodes**2)@(weight*nodes*expit(nodes)**2))
        flow=make_interp_spline(np.log(knots),np.column_stack((bg,thermal)),k=5);keys.append('nuE')
        force=make_interp_spline(np.log(knots),f['values'][[qkeys.index(k) for k in ('U','Fq')],:,0].T,k=5)
    log=np.log(t);return dict(zip(keys,flow(log).T)),dict(zip(keys,(flow(log,1)/t[:,None]).T)),force(log),force(log,1)/t[:,None]
def run():
    check('photon-freeze.json')
    freeze('propagation-method.json',['PROPAGATION.md','propagate_constraint.py','photon-freeze.json','energy-scores.json'])
    mod=oldio.prefix();model=mod.import_at(mod.OLD,'partial')
    meta_path=model.old.KIN.ti.parent.pin('radiation-background.json');meta=json.loads(meta_path.read_bytes())['heavy']
    paths=[prior.sealed(prior.EXT,'material/forcing-heavy.npz'),oldio.pin(oldio.PAD,'material-halfstep/forcing-heavy.npz')]
    with np.load(prior.sealed(prior.EXT,'blind-source.npz')) as ar:restore=make_interp_spline(np.log(ar['eta']),ar['restore'],k=5)
    with np.load(paths[1]) as f:
        names=f['keys'].tolist();ext=make_interp_spline(np.log(f['eta']),f['values'][[names.index(key) for key in ('hfield','hmoment','henergy','hJ')],:,0].T,k=5)
    control=[]
    for grid in ('p16','p32'):
        combined=[];raws=[];targets=[]
        with np.load(ROOT/f'field-{grid}.npz') as ar:
            t=ar['t'];log=np.log(t);kk=ar['kk'].item();src=ext(log);ds=ext(log,1)/t[:,None]
            for index,(tag,path) in enumerate(zip(('matched','wave'),paths)):
                bg,db,force,fd=table(path,meta,t)
                if index==0:force[:,0]+=restore(log);fd[:,0]+=restore(log,1)/t
                us,fq=force.T
                fld=ar['field'][:,index];f,w=fld.T
                scale,h,b,v,m2=ar['input_background'][:,index].T;ad,hd,bd,vd,md=ar['input_derivative'][:,index].T
                phi,psi,den=ar['metric'][:,index].T;B=m2*b;rv=vd+2*h*v+B;rb=bd-v
                d=np.column_stack(((4*bg['eg']+3*bg['eb'])/2,1.5*bg['ec'],1.5*bg['sv']**2,1.5*v*v,np.zeros(len(t)),(4*bg['er']+bg['nuE'])/2))
                dd=np.column_stack(((4*db['eg']+3*db['eb'])/2,1.5*db['ec'],3*bg['sv']*db['sv'],3*v*vd,np.zeros(len(t)),(4*db['er']+db['nuE'])/2))
                with np.load(ref(f'work-{tag}-{grid}.npz')) as old:
                    assert np.array_equal(t,old['t']) and kk==old['kk'];E,J=old['values'].transpose(2,0,1);ed,jd=old['rates'][1].transpose(2,0,1)
                    targets.append(old['estimate'][1]);stored_env=old['env']
                ec=E.sum(1);jc=J.sum(1);A=kk-den+3*(h*h-hd)
                general=-(ed+h[:,None]*E)-J-3*h[:,None]/kk*(jd+2*h[:,None]*J)-2*(dd+h[:,None]*d)*phi[:,None]+2*h[:,None]*d*psi[:,None]
                remainders=[(2*h*m2-md)*b*f,-m2*rb*f-rv*(w+3*h*f+6*v*phi),-(B+3*h*v)*src[:,0]-v*src[:,1],-(ds[:,2]+h*src[:,2]),-src[:,3]-3*h*(ds[:,3]+2*h*src[:,3])/kk]
                comp=(ad/scale-h)*(E[:,4]+3*h*J[:,4]/kk)
                factor=2*den
                reduced=np.column_stack((fd[:,0]/den,h*us/den,kk*h*(psi-phi)/den,-fq,A*jc/(kk*factor),general[:,:3]/factor[:,None],np.column_stack(remainders)/factor[:,None],comp/factor,general[:,5]/factor))
                assert reduced.shape==(len(t),len(NAMES)) and np.isfinite(reduced).all()
                base=np.column_stack((reduced[:,:5],general/factor[:,None]))
                alt=(us-ec/2-1.5*h*jc/kk)/den
                canon=ec+2*d.sum(1)*phi+3*h*jc/kk
                closure=2*(us-kk*phi)
                tests=dict(grid=grid,branch=tag,den_pct=err(kk+d.sum(1),den),curvature_pct=err(alt,phi),sum_density_identity_pct=err(canon,closure),forcing_U_pct=err(us,stored_env[:,2]),forcing_Fq_pct=err(fq,stored_env[:,3]),heavy_identity_total_pct=err(np.sum(remainders,axis=0)/factor,general[:,3]/factor),heavy_identity_on_total_R_peak_pct=float(100*np.max(abs((np.sum(remainders,axis=0)-general[:,3])/factor))/max(abs(targets[-1]))),companion_max_absolute=float(max(abs(comp/factor))),companion_identity_on_total_R_peak_pct=float(100*max(abs((comp-general[:,4])/factor))/max(abs(targets[-1]))),raw_on_prior_residual_pct=err(base.sum(1),targets[-1]),reduced_on_prior_residual_pct=err(reduced.sum(1),targets[-1]))
                control.append(tests);combined.append(reduced);raws.append(base)
        pack('propagation-'+grid+'.npz',t=t,names=NAMES,reduced=np.stack(combined,axis=1),raw=np.stack(raws,axis=1),raw_names=NAMES[:5]+['photon-baryon','cold','light','heavy','companion','collisionless'],previous=np.stack(targets,axis=1))
    put('constraint-controls.json',dict(rows=control,thermal_input=sha(meta_path)))
    freeze('constraint-freeze.json',['propagation-method.json','propagation-p16.npz','propagation-p32.npz','constraint-controls.json'])
    print('Paired density/current constraint propagation frozen.')
if __name__=='__main__':run()
