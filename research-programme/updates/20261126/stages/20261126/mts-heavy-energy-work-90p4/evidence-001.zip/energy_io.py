from pathlib import Path
from io import BytesIO
from functools import lru_cache
import hashlib,json,sys
import numpy as np
ROOT=Path(__file__).resolve().parent
BASE=ROOT.parent
WORK=BASE/'mts-density-work-balance-90p4-20261126'
SIGNATURE='ea247071d88148662cd55d46abc4cd25eea6562b4f1fc5f2d63dcc5fe759bece'
def sha(path):
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
assert sha(WORK/'seal.json')==SIGNATURE
files=json.loads((WORK/'seal.json').read_bytes())['files']
@lru_cache()
def ref(name):
    path=WORK/name;assert sha(path)==files[name],name;return path
ref('work_io.py');sys.path.insert(0,str(WORK));import work_io as parent
from work_io import prior,oldio,START,END,edges
def guard():
    parent.guard();assert not (ROOT/'STOP-REQUESTED').exists()
def save(name,data):
    guard();path=ROOT/name
    if path.exists():assert sha(path)==hashlib.sha256(data).hexdigest(),name
    else:
        temp=path.with_suffix(path.suffix+'.partial')
        with temp.open('xb') as stream:stream.write(data)
        temp.rename(path)
def put(name,obj):save(name,(json.dumps(obj,indent=2,sort_keys=True,allow_nan=False,default=lambda v:v.item())+'\n').encode())
def pack(name,**fields):
    buf=BytesIO();np.savez_compressed(buf,**fields);save(name,buf.getvalue())
def freeze(name,names):put(name,{n:sha(ROOT/n) for n in names})
def check(name):
    for f,sig in json.loads((ROOT/name).read_bytes()).items():assert sha(ROOT/f)==sig,f
def err(value,target):
    peak=np.max(abs(target));assert peak>0
    return float(100*np.max(abs(value-target))/peak)
