from energy_io import *
from project90 import modules
from scipy.interpolate import CubicSpline
from scipy.linalg import solve_banded

def run():
    check('field-freeze.json');freeze('transfer-method.json',['field-freeze.json','project_energy.py','compare_energy.py'])
    ph=modules();proj=ph.proj;gate=ph.gate
    scale,eta,medium,peak,weights=proj.measure('heavy')
    with np.load(prior.sealed(prior.EXT,'incident-matched-16.npz')) as ar:k=ar['k'].item()
    with np.load(ph.track(ph.cell89.curve('p32','base'))) as ar:t0=ar['eta']
    count_new=round((END-START)/(t0[-1]-t0[-2]));order,sub,stride=gate.transfer.prior.SETTINGS['primary']
    axis=np.unique(np.r_[proj.base_axis(scale,eta,sub),np.linspace(START,END,count_new+1)[::stride],START,END])
    start,end=np.searchsorted(axis,[START,END]);rates,nodes=proj.coefficients(axis,medium,k);at=nodes[start:end]
    names=[];forces=[]
    for grid in ('p16','p32'):
        def add(labels,curves):
            sample=CubicSpline(t,curves,axis=0,extrapolate=False)(at)
            for idx,label in enumerate(labels):
                item=np.zeros((*at.shape,2),complex);item[:,:,0]=sample[:,:,idx]
                assert np.isfinite(item).all();forces.append(item);names.append(grid+':'+label)
        with np.load(ROOT/f'field-{grid}.npz') as ar:
            t=ar['t'];weight=ar['weight'];direct=ar['direct'].sum(2)
            add(['physical/'+key for key in ar['physical_names'].tolist()],ar['weighted'])
            add(['causal/'+key for key in ar['causal_names'].tolist()],ar['causal'])
            add(['full matched','full resolved','paired rate','coarser integration'],np.column_stack((weight*direct[:,0],weight*direct[:,1],ar['weighted'].sum(1),ar['refinement_weighted'])))
    drive=np.stack(forces,axis=2);integ=np.diff(axis)[start:end,None,None,None]*np.einsum('st,ntch->nsch',proj.RAD,drive)
    bands=proj.transfer.stages(order);length=bands.shape[-1]//2;nc=len(names)
    state=np.zeros((length,2*nc));right=np.empty((2*length,2*nc),order='F')
    slots=np.full(len(axis),-1);slots[np.searchsorted(axis,eta)]=np.arange(len(eta))
    out=np.zeros((len(eta),nc,2),complex)
    for begin in range(start,len(rates),48):
        guard();stop=min(begin+48,len(rates))
        mats=(rates[begin:stop].reshape(-1,8)@bands.reshape(8,-1)).reshape(-1,11,2*length);mats[:,5]+=1
        for step,mat in enumerate(mats,begin):
            right[::2]=state;right[1::2]=state
            if step<end:
                for row,col,fac in ((0,0,4.),(2,1,4*k/3),(4,1,4*k/3)):
                    force=fac*integ[step-start,:,:,col]
                    right[row:row+2,::2]+=force.real;right[row:row+2,1::2]+=force.imag
            state=solve_banded((5,5),mat,right,check_finite=False)[1::2]
            if slots[step+1]>=0:out[slots[step+1]]=(state[[0,2],::2]+1j*state[[0,2],1::2]).T

    pack('photon-work.npz',scale=scale,labels=names,values=out)
    freeze('photon-freeze.json',['transfer-method.json','photon-work.npz'])
    print('Both signed photon channels frozen.',flush=True)
if __name__=='__main__':run()
