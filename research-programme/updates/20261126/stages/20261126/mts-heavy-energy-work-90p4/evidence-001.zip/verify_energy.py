from energy_io import *

def verify():
    for name in ('method.json','field-freeze.json','transfer-method.json','photon-freeze.json','propagation-method.json','constraint-freeze.json','constraint-transfer-method.json','propagation-photon-freeze.json','current-method.json','native-current-freeze.json'):check(name)
    e=json.loads((ROOT/'energy-scores.json').read_bytes());p=json.loads((ROOT/'propagation-scores.json').read_bytes());src=json.loads((ROOT/'current-source-scores.json').read_bytes());leg=json.loads((ROOT/'leg-controls.json').read_bytes())
    assert e['freeze']==sha(ROOT/'photon-freeze.json') and p['freeze']==sha(ROOT/'propagation-photon-freeze.json') and src['freeze']==sha(ROOT/'native-current-freeze.json')
    c=json.loads((ROOT/'constraint-controls.json').read_bytes())['rows']
    for idx,grid in enumerate(('p16','p32')):
        time=e['time_domain'][idx];phot=e['photon'][idx];bal=p['rows'][idx]
        assert time['grid']==phot['grid']==bal['grid']==grid
        for tag in ('matched','wave','difference'):
            assert max(time[tag]['endpoint_field_pct'])<=.5 and time[tag]['energy_rate_pct']<=.5
        assert time['weighted_rate_target_pct']<=.5
        for values in phot['metrics'].values():assert max(values['own_pct'])<=.5
        for values in bal['matches'].values():assert max(values['own_pct'])<=.5
        assert bal['pointwise_pct']<=.5 and max(bal['companion_difference_original_pct'])<=.5 and min(bal['full_gap_as_reconstructed']['norm'])>.5
        for r in (entry for entry in c if entry['grid']==grid):
            assert max(r[k] for k in ('curvature_pct','den_pct','sum_density_identity_pct','raw_on_prior_residual_pct','reduced_on_prior_residual_pct','heavy_identity_on_total_R_peak_pct','companion_identity_on_total_R_peak_pct'))<=.5
        with np.load(ROOT/f'field-{grid}.npz') as ar:
            assert np.array_equal(ar['t'][[0,-1]],[START,END]) and np.all(np.diff(ar['t'])>0)
            assert ar['field'].shape==(len(ar['t']),2,2) and ar['responses'].shape==(len(ar['t']),6,2)
            assert np.all(ar['responses'][0,1:]==0) and np.all(ar['responses'][:,-1]==0)
            assert err(ar['responses'].sum(1),ar['field'][:,0]-ar['field'][:,1])<=.5
            assert np.isfinite(ar['direct']).all() and np.isfinite(ar['causal']).all()
        assert np.allclose(sum(np.array(v['signed']) for v in bal['terms'].values()),bal['residual']['signed'],rtol=1e-6,atol=1e-6)
    assert len(src['rows'])==5 and all(max(row[key] for key in ('source_pct','rate_pct','rate_vs_order7_pct','exchange_pct','algebra_pct'))<=.5 for row in src['rows'])
    assert leg['legs']==782 and all(v['failing_legs']==0 for v in leg['kinematic'].values())
    assert leg['nonzero_exported_matched']==[0,0] and min(leg['nonzero_exported_wave'])>0
    assert sha(WORK/'seal.json')==SIGNATURE and sha(parent.PARENT/'seal.json')==parent.SEAL
    print('Verified both field replays, 60 endpoint pairs by branch/grid, transfers, propagation identities, 782 mode controls and five native-current outputs.')
    if '--seal' in sys.argv:
        assert (ROOT/'RESULTS.md').is_file() and not any(f.name.endswith('.partial') or f.is_dir() for f in ROOT.iterdir())
        put('seal.json',dict(files={f.name:sha(f) for f in sorted(ROOT.iterdir()) if f.name!='seal.json'}));print(sha(ROOT/'seal.json'))
if __name__=='__main__':verify()
