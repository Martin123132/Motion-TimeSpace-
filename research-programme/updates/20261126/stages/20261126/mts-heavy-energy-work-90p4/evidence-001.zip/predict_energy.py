from energy_io import *
from scipy.integrate import solve_ivp
from scipy.interpolate import CubicSpline,make_interp_spline

PHYSICAL=('kinetic dilution','changing mass coefficient','spatial gradient','metric curvature','external field','external momentum','external energy rate','background velocity remainder','background field remainder')
HISTORY=('entry perturbation','expansion in field propagation','frequency in field propagation','background acting on common metric','different metric histories','different external quadratics')
CAUSAL=(*HISTORY,'energy weights on common state','direct background on shared curvature','direct curvature history','background on shared external field','background on shared external momentum','external source difference')
def native_table(folder):
    with np.load(folder) as f:
        t=f['eta'];names=f['bgkeys'].tolist();keys=['a','h','hb','hv','hm']
        return make_interp_spline(np.log(t),f['background'][[names.index(k) for k in keys]].T,k=5)
def inputs(grid):
    paths=[prior.sealed(prior.EXT,'material/forcing-heavy.npz'),oldio.pin(oldio.PAD,'material-halfstep/forcing-heavy.npz')]
    funcs=[native_table(path) for path in paths]
    with np.load(paths[1]) as f:
        names=f['keys'].tolist();qkeys=['hfield','hmoment','henergy']
        external=make_interp_spline(np.log(f['eta']),f['values'][[names.index(k) for k in qkeys],:,0].T,k=5)
    with np.load(prior.sealed(prior.EXT,'incident-wave-16.npz')) as ar:kk=float(ar['k'])**2
    with np.load(prior.sealed(prior.CARRY,f'oscillator-{grid}-4.npz')) as ar:
        assert ar['t'][-1]==START;init=[ar['field'][-1],ar['velocity'][-1]]
        mass=(ar['mass2'][-1])**.5/ar['a'][-1]
    def homogeneous(t,y):
        scale,hub,*_=funcs[0](np.log(t));return y[1],-2*hub*y[1]-(mass*scale)**2*y[0]
    osc=solve_ivp(homogeneous,(START,END),init,method='DOP853',rtol=2e-13,atol=[1e-18,1e-17],max_step=.00065,dense_output=True)
    assert osc.success
    with np.load(parent.pin(f'carry-matched-{grid}-4.npz')) as ar:t=ar['t']
    metric=[];left=[]
    for tag,field in [('matched','final'),('wave','ordinary_end')]:
        with np.load(prior.sealed(prior.CARRY,f'carry-{tag}-{grid}-4.npz')) as ar:
            assert ar['t'][-1]==START;left.append(ar[field][1,10:12])
        with np.load(parent.pin(f'carry-{tag}-{grid}-4.npz')) as ar:
            assert np.array_equal(t,ar['t'])
            metric.append(ar['obs'][:,1][:,[0,3,8]])
    left=np.asarray(left)
    def backgrounds(time):
        log=np.log(time);data=[];dt=[]
        for index,spline in enumerate(funcs):
            a,h,b,v,m=spline(log).T;ad,hd,bd,vd,md=(spline(log,1)/time[:,None]).T
            if index==0:
                m=np.full_like(a,mass);md=np.zeros_like(a)
                b,v=osc.sol(time);bd=v;vd=-2*h*v-(m*a)**2*b
            mass2=(a*m)**2;dm=2*a*m*(ad*m+a*md)
            data.append(np.stack((a,h,b,v,mass2),axis=-1))
            dt.append(np.stack((ad,hd,bd,vd,dm),axis=-1))
        return np.stack(data,axis=1),np.stack(dt,axis=1)
    b,bd=backgrounds(t);q=external(np.log(t));qd=external(np.log(t),1)/t[:,None]
    metric=np.stack(metric,axis=1)
    v=b[:,:,3];m2=b[:,:,4];mass_b=m2*b[:,:,2]
    common=np.column_stack((b[:,:,1],m2,v,mass_b,metric[:,:,0],metric[:,:,1],q[:,:2]))
    spline=CubicSpline(t,common,axis=0,extrapolate=False)
    return t,kk,left,b,bd,q,qd,metric,spline

def evolve(t,kk,left,spline,step):
    freq=np.sqrt(spline(t[0])[2].real);scale=max(np.max(abs(left[:,0])),np.max(abs(left[:,1]))/freq)
    sizes=np.array([scale,freq*scale]);initial=np.zeros((2+len(HISTORY),2),complex)
    initial[:2]=left/sizes;initial[2]=(left[0]-left[1])/sizes
    def rhs(at,flat):
        pars=spline(at);hub,m2,vel,mb,phi,psi=pars[:12].reshape(6,2);qf,qw=pars[12:];g=psi+3*phi;u=3*phi-psi
        y=flat.reshape(-1,2)*sizes;out=np.empty_like(y)
        out[:2,0]=y[:2,1]+vel*g+qf
        out[:2,1]=-2*hub*y[:2,1]-(kk+m2)*y[:2,0]+mb*u+qw
        av=lambda z:(z[0]+z[1])/2
        delta=lambda z:z[0]-z[1]
        out[2:,0]=y[2:,1];out[2:,1]=-2*av(hub)*y[2:,1]-(kk+av(m2))*y[2:,0]
        out[3,1]+=-2*delta(hub)*av(y[:2,1])
        out[4,1]+=-delta(m2)*av(y[:2,0])
        out[5,0]+=delta(vel)*av(g);out[5,1]+=delta(mb)*av(u)
        out[6,0]+=av(vel)*delta(g);out[6,1]+=av(mb)*delta(u)
        return (out/sizes).ravel()
    guard();sol=solve_ivp(rhs,(START,END),initial.ravel(),method='DOP853',rtol=3e-13,atol=4e-18,max_step=step,t_eval=t)
    assert sol.success and np.array_equal(sol.t,t)
    out=sol.y.T.reshape(len(t),-1,2)*sizes
    return out,sol.nfev

def predict(grid):
    t,kk,left,b,bd,q,qd,metric,spline=inputs(grid)
    sol,n1=evolve(t,kk,left,spline,.0012);refined,n2=evolve(t,kk,left,spline,.0006)
    av=lambda x:(x[:,0]+x[:,1])/2
    diff=lambda x:x[:,0]-x[:,1]
    a,h,bg,v,m2=b.transpose(2,0,1);ad,hd,bt,vt,mt=bd.transpose(2,0,1)
    phi,psi,den=metric.transpose(2,0,1);mb=m2*bg;rb=bt-v;rv=vt+2*h*v+mb
    ef=q[:,0,None];em=q[:,1,None];ee=qd[:,2,None]
    weight=-.25*(1/den[:,0]+1/den[:,1])
    def analyze(y):
        yy=y[:,:2];f,w=yy.transpose(2,0,1)
        direct=np.stack((-4*h*v*w,mt*bg*f,-kk*v*f,6*mb*v*phi,mb*ef,v*em,np.broadcast_to(ee,f.shape),rv*w,m2*rb*f),axis=-1)
        scaled=diff(direct)*weight[:,None]
        lhs=np.stack((mt*bg-kk*v+m2*rb,-4*h*v+rv),axis=-1)
        contributions=np.einsum('ni,nci->nc',av(lhs),y[:,2:],optimize=False)
        causal=np.column_stack((contributions,np.sum(diff(lhs)*av(yy),axis=-1),6*diff(mb*v)*av(phi),6*av(mb*v)*diff(phi),diff(mb)*ef[:,0],diff(v)*em[:,0],np.zeros(len(t),complex)))*weight[:,None]
        df=w+v*(psi+3*phi)+ef
        dw=-2*h*w-(kk+m2)*f+mb*(3*phi-psi)+em
        chain=vt*w+v*dw+(mt*bg+m2*bt)*f+mb*df+ee
        return dict(direct=direct,weighted=scaled,causal=causal,chain=chain,step_rate=np.stack((df,dw),axis=-1))
    pre=analyze(sol);fine=analyze(refined)
    delta=diff(refined[:,:2]);parts=refined[:,2:].sum(1)
    checks=dict(rhs_evaluations=[n1,n2],material_refinement_pct=[err(sol[:,i,j],refined[:,i,j]) for i in (0,1) for j in (0,1)],difference_refinement_pct=[err(diff(sol[:,:2])[:,j],delta[:,j]) for j in (0,1)],duhamel_pct=[err(parts[:,j],delta[:,j]) for j in (0,1)],chain_vs_reduced_pct=[err(fine['direct'][:,i,:].sum(1),fine['chain'][:,i]) for i in (0,1)],direct_vs_causal_pct=err(fine['weighted'].sum(1),fine['causal'].sum(1)),refined_rate_pct=err(pre['weighted'].sum(1),fine['weighted'].sum(1)))
    assert max([checks['direct_vs_causal_pct'],checks['refined_rate_pct']]+checks['duhamel_pct']+checks['material_refinement_pct']+checks['difference_refinement_pct']+checks['chain_vs_reduced_pct'])<=.5,checks
    pack('field-'+grid+'.npz',t=t,kk=kk,initial=left,field=refined[:,:2],responses=refined[:,2:],input_background=b,input_derivative=bd,metric=metric,shared=q,shared_rate=qd,weight=weight,physical_names=PHYSICAL,causal_names=CAUSAL,refinement_weighted=pre['weighted'].sum(1),**fine)
    put('internal-'+grid+'.json',checks)
    print(grid,'conditional equation solve verified',flush=True)
def run():
    for file,sig in [('mts-wave-geometric-work-89p6-20261125/blind_native_wave.py','4e288010b1e8692c4b5746954de0d9dc5ec2297d379aee69593c0017daf54b06'),('mts-continuous-angular-work-89p6-20261125/angular_operator.py','74a2cc46316759116069df0e337f702ab11e9385877934beb2e62bcc29bcc93e')]:assert sha(BASE/file)==sig
    freeze('method.json',['PROTOCOL.md','energy_io.py','predict_energy.py'])
    for grid in ('p16','p32'):predict(grid)
    freeze('field-freeze.json',['method.json','field-p16.npz','field-p32.npz','internal-p16.json','internal-p32.json'])
if __name__=='__main__':run()
