from common_shear import *
from kinetics import CUT,SHORT,LONG
from scipy.interpolate import make_interp_spline
from evaluate_shear import metrics

def run():
    check('kinetic-forecast.json');check('transfer-forecast.json');check('native-truth.json')
    out={}
    for tag,end in [('cold',SHORT),('matched',LONG)]:
        native=audit_sources.load_native(tag,before=end)
        arr=data(HERE/f'{tag}-true.npz')
        keep=native.time>=CUT
        k=native.k;t=native.time[keep]
        assert np.array_equal(arr['k'],k) and np.array_equal(arr['t'],t)
        direct=dict(zip(arr['keys'],arr['values'].transpose(1,0,2)))
        trace=(direct['D']+3*direct['P'])/2
        verify={name:audit_sources.ratio(direct[name],var[keep]) for name,var in [('D',native.D),('J',native.J)]}
        assert max(val['worst'] for val in verify.values())<1e-7
        infA=-(make_interp_spline(native.time,native.D,k=7)(t,1)+k*native.J[keep]+native.B[keep]*native.X[keep])/(2*native.H[keep])
        infS=(2*infA-native.D[keep])/3-(make_interp_spline(native.time,native.J,k=7)(t,1)+2*native.H[keep]*native.J[keep])/k
        original={'A':trace,'S':direct['S'],'J':direct['J'],'D':direct['D']}
        scores={}
        for source in ('primary','fine','more-angles','old-tangent'):
            if source!='old-tangent':
                kin=data(HERE/f'{tag}-{source}.npz'); kk=dict(zip(kin['keys'],kin['values'].transpose(1,0,2)))
            elif tag=='cold':
                kin=data(pin('paired-cold-energy-current.npz'));kk=kin
            else:
                kin=data(pin('nu-energy-current.npz'));s0=data(pin('massive-inputs.npz'))['order5']
                kk=dict(D=kin['D'],J=kin['J'],A=kin['sectors'][:,4],S=s0[5]+(kin['t']-CUT)[:,None]*s0[6])
            pos=np.searchsorted(kin['t'],t);assert np.array_equal(kin['t'][pos],t)
            scores[source]={key:{field:metrics(kk[field][pos][mask],v[mask]) for field,v in original.items()} for key,mask in [('common',t<=SHORT),('available',t<=end)]}
        photon={}
        truth={key:native.data[field][keep] for key,field in [('dg','clxg'),('qg','qg'),('vb','vb'),('pig','pig')]}
        for source,order in [('primary',1),('primary',2),('primary',3),('fine',3)]:
            cur=data(HERE/f'thomson-{tag}-{source}-{order}.npz')
            kk=dict(zip(cur['keys'],cur['values'].transpose(1,0,2)))
            pos=np.searchsorted(cur['t'],t);assert np.array_equal(cur['t'][pos],t)
            photon[f'{source}-{order}']={label:{field:metrics(kk[field][pos][mask],ref[mask]) for field,ref in truth.items() if field!='pig' or order!=1} for label,mask in [('common',t<=SHORT),('available',t<=end)]}
            if order==1:
                inc=data(HERE/f'{tag}-primary.npz')
                for field,key in [('dg','photon_density'),('qg','photon_current')]:
                    val=inc['values'][pos,inc['keys'].tolist().index(key)]
                    assert audit_sources.ratio(kk[field][pos],val)['peak']<1e-6
        grab=lambda field:native.data[field][keep]
        weight=grab('grhob_t')/grab('grhog_t')
        b=grab('vb');gg=grab('clxg');qg=grab('qg');H=native.H[keep];pb=grab('delta_p_b');pig=grab('pig')
        thomson=grab('opacity')*(4*b/3-qg)
        radiation=k*(gg-2*pig)/3
        sumref=direct['qgprime']+weight*(direct['vbprime']+H*b)
        identity=audit_sources.ratio(radiation+weight*k*pb,sumref)
        drag=audit_sources.ratio(radiation+thomson,direct['qgprime'])
        out[tag]=dict(native_reference=verify,proxy=dict(A=metrics(infA,trace),S=metrics(infS,direct['S'])),direct=scores,photon=photon,
                      momentum_identity=identity,explicit_drag_check=drag,tight_fraction=np.mean(direct['tight']),t=t[[0,-1]].tolist(),k=k[[0,-1]].tolist())
        print(tag,'direct S peak-error % of change, initial tangent vs kinetic',[(v, scores[v]['available']['S']['change']['peak']) for v in ['old-tangent','primary']],flush=True)
        print('photon error on change:',[(v,[(key,round(entry['change']['peak'],6),entry['change']['over']) for key,entry in row['available'].items() if key in ('dg','qg')]) for v,row in photon.items()],flush=True)
        print('TCA fraction, native collisional summed error %',out[tag]['tight_fraction'],identity['peak'])
    write('physical-readout.json',out)
if __name__=='__main__':run()
