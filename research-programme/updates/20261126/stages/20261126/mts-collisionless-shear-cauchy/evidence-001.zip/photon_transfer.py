from common_shear import *
from scipy.interpolate import make_interp_spline
from scipy.integrate import solve_ivp
from kinetics import CUT,SHORT,LONG

def early(tag):
    tagdir,model=('matched-native','heavy') if tag=='matched' else ('material-halfstep','cold')
    keys=['pig','E(2)','octg','E(3)','opacity','delta_p_b','clxg','qg','vb','grhog_t','grhob_t','adotoa','gpres','polter']
    pieces=[];paths=[];nodes=[]
    for idx in range(38):
        file=prev.native.pin(prev.bank,f'{tagdir}/linear-{model}-{idx:02}.npz')
        paths.append(file)
        with np.load(file) as ar:
            sel=(ar['eta']>=89.15)&(ar['eta']<=CUT)
            assert ar['good'][:,sel].all()
            t=ar['eta'][sel];nodes.extend(ar['k'])
            ids=[ar['keys'].tolist().index(name) for name in keys]
            pieces.append(ar['values'][:,sel][:,:,ids].T)
    assert t[-1]==CUT
    return dict(zip(keys,np.concatenate(pieces,axis=2))),t,np.array(nodes),paths

def predict(tag,source,order):
    arr=data(HERE/f'{tag}-{source}.npz')
    hist,t,k,paths=early(tag)
    assert np.array_equal(k,arr['k'])
    vals=arr['values']; ix=arr['keys'].tolist().index
    metric=make_interp_spline(arr['t'],vals[:,[ix('X'),ix('k_sigma')]],k=5)
    def der(field,n=1):return make_interp_spline(t[-6:],field[-6:],k=5)(CUT,n)
    initial=np.stack([hist[key][-1] for key in ('clxg','qg','vb','pig','E(2)','octg','E(3)')])
    H=hist['adotoa'][-1]; p=hist['gpres'][-1]; scale=hist['grhog_t'][-1]/hist['grhob_t'][-1]
    def coeff(key):return hist[key][-1],der(hist[key])
    op,opp=coeff('opacity'); pb,pbp=coeff('delta_p_b'); pi,pip=coeff('pig')
    g3,g3p=coeff('octg');e3,e3p=coeff('E(3)')
    def tail(key,quad):
        return (der(hist[key])+op*hist[key][-1]-3*k*hist[quad][-1]/7,
            der(hist[key],2)+opp*hist[key][-1]+op*der(hist[key])-3*k*der(hist[quad])/7)
    g4,g4p=tail('octg','pig');e4,e4p=tail('E(3)','E(2)')
    def rhs(tt,vec):
        dg,qg,vb,quad,pol,octg,octe=vec.reshape(7,-1)
        dt=tt-CUT
        fac=1+H*dt+(H*H-p)*dt*dt/4
        hub=(H+(H*H-p)*dt/2)/fac
        X,ksig=metric(tt)
        opacity=op+dt*opp
        slip=opacity*(4*vb/3-qg)
        force=quad if order>=2 else pi+dt*pip
        polter=quad/10+3*pol/5
        thirdg=octg if order>=3 else g3+dt*g3p
        thirde=octe if order>=3 else e3+dt*e3p
        return np.array([-4*X/3-k*qg,k*(dg-2*force)/3+slip,-hub*vb+k*(pb+dt*pbp)-scale/fac*slip,
            k*(2*qg-3*thirdg)/5+8*ksig/15-opacity*(quad-polter),-opacity*(pol-polter)-k*thirde/3,
            3*k*quad/7-opacity*octg+g4+dt*g4p,3*k*pol/7-opacity*octe+e4+dt*e4p]).ravel()
    time=arr['t']
    sol=solve_ivp(rhs,(CUT,time[-1]),initial.ravel(),method='DOP853',max_step=1/(1280 if source=='fine' else 640),
                  t_eval=time,rtol=1e-12,atol=3e-17)
    assert sol.success and np.isfinite(sol.y).all()
    states=sol.y.T.reshape(len(time),7,-1)
    pack(f'thomson-{tag}-{source}-{order}.npz',k=k,t=time,values=states,keys=['dg','qg','vb','pig','E2','G3','E3'])
    return paths

def forecasts():
    check('kinetic-forecast.json')
    files=[]
    for tag in ('cold','matched'):
        hist,tt,k,paths=early(tag)
        files.extend(paths)
    receipt('transfer-method.json',[HERE/'PHOTON-TRANSFER.md',HERE/'photon_transfer.py',HERE/'kinetic-forecast.json',*files])
    for tag in ('cold','matched'):
        for source,order in [('primary',1),('primary',2),('primary',3),('fine',3)]:
            predict(tag,source,order)
            files.append(HERE/f'thomson-{tag}-{source}-{order}.npz')
    receipt('transfer-forecast.json',[HERE/'transfer-method.json',*files])

if __name__=='__main__':forecasts()
