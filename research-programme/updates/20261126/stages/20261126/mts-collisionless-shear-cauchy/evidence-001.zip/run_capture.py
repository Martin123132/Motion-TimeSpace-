import os
from pathlib import Path
import subprocess
import shutil
from unittest.mock import patch
import capture_cut
from common_shear import HERE,receipt

def run():
    chain=capture_cut.TREE/'native-two-field-transfer-20261007/toolchain/mingw64'
    drive=next(letter+':' for letter in 'UTSRQ' if not Path(letter+':/').exists())
    execute=subprocess.run
    def wrapped(command,*args,**kwargs):
        if 'child' in command:
            dest=kwargs['cwd']/'fortran'
            dest.mkdir()
            shutil.copy2(capture_cut.NATIVE/'fortran/HighLExtrapTemplate_lenspotentialCls.dat',dest)
        if str(command[0]).endswith('gfortran.exe'):
            cwd=kwargs['cwd']
            prefix=os.path.relpath(chain,cwd).replace('\\','/')
            mapped=drive+'/'+chain.relative_to(capture_cut.BASE).as_posix()
            command=[mapped+'/bin/gfortran.exe',*[arg.replace(prefix,mapped) for arg in command[1:]]]
            kwargs['cwd']=drive+'/'+cwd.relative_to(capture_cut.BASE).as_posix()
            kwargs['env']=dict(kwargs['env'],PATH=mapped+'/bin;'+kwargs['env']['PATH'])
        return execute(command,*args,**kwargs)
    execute(['subst',drive,str(capture_cut.BASE)],check=True)
    try:
        with patch.object(subprocess,'run',wrapped):
            capture_cut.main()
    finally:
        assert (Path(drive+'/')/chain.relative_to(capture_cut.BASE)/'bin/gfortran.exe').samefile(chain/'bin/gfortran.exe')
        execute(['subst',drive,'/D'],check=True)
        assert not Path(drive+'/').exists()
    receipt('capture-execution.json',[HERE/'snapshot.json',HERE/'run_capture.py'])

if __name__=='__main__':run()
