from kinetics import *
from photon_transfer import early

def run(tag,step,ell=12):
    prep=prepare(tag,ell)
    hist,t,k,paths=early(tag)
    assert np.array_equal(k,prep.grid)
    def der(field,n=1):return make_interp_spline(t[-6:],field[-6:],k=5)(CUT,n)
    op=hist['opacity'][-1];opp=der(hist['opacity'])
    def tail(name,quad):
        return (der(hist[name])+op*hist[name][-1]-3*k*hist[quad][-1]/7,
                der(hist[name],2)+opp*hist[name][-1]+op*der(hist[name])-3*k*der(hist[quad])/7)
    ag,bg=tail('octg','pig')
    ae,be=tail('E(3)','E(2)')
    pi=hist['pig'][-1];pip=der(hist['pig'])
    state=np.vstack([prep.y0,*[hist[key][-1] for key in ('pig','E(2)','octg','E(3)')]])
    def rhs(tt,vec):
        dt=tt-CUT
        inner=vec[:-4]
        base=equations(prep,tt,inner)
        quad,pol,g3,e3=vec[-4:]
        (xx,cd,bd,vb,ph,qg,fd,fj),rad,dist=unpack(prep,inner)
        par=prep.par
        fac,aa,hh,inv,ww=geometry(prep,tt)
        jn=(ww*dist[:,1]).sum(axis=0)
        gb,gg,gr=par.weights[1:]/np.array([fac,fac**2,fac**2])
        heavy=par.rho/aa*fj if tag=='matched' else 0
        sk=xx+1.5*(gb*vb+gg*qg+gr*rad[1]+jn+heavy+prep.sq0+dt*prep.sqp)/k
        opacity=op+dt*opp
        polter=quad/10+3*pol/5
        base[5]-=2*k*(quad-pi-dt*pip)/3
        return np.vstack([base,k*(2*qg-3*g3)/5+8*sk/15-opacity*(quad-polter),-opacity*(pol-polter)-k*e3/3,
                       3*k*quad/7-opacity*g3+ag+dt*bg,3*k*pol/7-opacity*e3+ae+dt*be])
    end=LONG if tag=='matched' else SHORT
    time=np.arange(round(CUT*320),round(end*320)+1)/320
    samples=[]
    for count,tm in enumerate(time):
        out=equations(prep,tm,state[:-4],output=True)
        samples.append(np.vstack([out,state[3],state[-4:]]))
        if count+1==len(time):break
        if count%32==0:guard()
        delta=1/step
        for sub in range(step//320):
            now=tm+sub*delta
            one=rhs(now,state)
            two=rhs(now+delta/2,state+delta*one/2)
            three=rhs(now+delta/2,state+delta*two/2)
            four=rhs(now+delta,state+delta*three)
            state+=delta/6*(one+2*two+2*three+four)
    vals=np.asarray(samples)
    assert np.isfinite(vals).all()
    result=dict(t=time,k=k,values=vals,keys=['X','D','J','A','S','k_sigma','pir','e','j','dg','qg','vb','pig','E2','G3','E3'])
    if tag=='matched':
        oldmetric=data(ep('matched-ordinary-physical.npz'))
        assert np.array_equal(oldmetric['time'],time)
        centers=oldmetric['centers'];m=prep.par.m
        phase=CubicSpline(time,m*oldmetric['scale']).antiderivative()(time)
        fs=make_interp_spline(time,vals[:,0],k=5)
        def metric(tt):
            _,aa,hh,_,_=geometry(prep,tt)
            return aa,hh,fs(tt)
        wave=advance(metric,k,m,CUT,time[-1],data(pin('clock-inputs.npz'))['local_at_cut'],time,1/640)
        centers_idx=np.searchsorted(time,centers)
        result.update(centers=centers,wave=project_state(wave,np.array([geometry(prep,tt)[1] for tt in time]),time,centers,m,prep.par.rho,k,phase),
                      fluid=wave[centers_idx,4:6],evolved_fluid=vals[centers_idx,7:9],terminal=state)
    pack(f'coupled-{tag}-{step}.npz',**result)
    print('frozen feedback',tag,step,flush=True)

if __name__=='__main__':
    check('transfer-forecast.json')
    receipt('feedback-method.json',[HERE/name for name in ('FEEDBACK.md','coupled_thomson.py','kinetic-method.json','transfer-method.json')])
    paths=[]
    for tag in ('cold','matched'):
        for step in (640,1280):
            run(tag,step)
            paths.append(HERE/f'coupled-{tag}-{step}.npz')
    receipt('feedback-forecast.json',[HERE/'feedback-method.json',*paths])
