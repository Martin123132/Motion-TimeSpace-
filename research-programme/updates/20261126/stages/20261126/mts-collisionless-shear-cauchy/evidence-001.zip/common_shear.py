from pathlib import Path
import sys
import json
import hashlib
import csv
import numpy as np

HERE = Path(__file__).resolve().parent
BASE = HERE.parent
PRIOR = BASE/'mts-native-fluid-continuity-audit-20261126'
SIGN = 'c73a8ec2b874d80862a3b772c83957912f16a5638c143d0d91150ecb29f0c8be'
def sha(path):
    with path.open('rb') as handle:
        return hashlib.file_digest(handle,'sha256').hexdigest()
assert sha(PRIOR/'seal.json')==SIGN
def pin(name):
    path = PRIOR/name
    assert sha(path)==json.loads((PRIOR/'seal.json').read_bytes())['files'][name]
    return path
sys.path.insert(0,str(PRIOR))
from paired_source_control import audit_sources,initial
from clock_forecast import parent,prev,cap,ep,old,project_state
from audit_io import guard as previous_guard
def guard():
    previous_guard()
    assert not (HERE/'STOP-REQUESTED').exists()
def write(name,value):
    guard()
    parent.put(HERE/name,value)
def pack(name,**items):
    guard()
    parent.pack(HERE/name,**items)
def receipt(name,files):
    guard()
    parent.receipt(HERE/name,files)
def check(name):
    parent.check(HERE/name)
def data(path):
    with np.load(path) as arc:
        return dict(arc.items())
