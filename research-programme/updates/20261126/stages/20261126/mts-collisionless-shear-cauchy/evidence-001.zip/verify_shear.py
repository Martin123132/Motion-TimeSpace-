from common_shear import *
from kinetics import CUT,SHORT,LONG
from scipy.linalg import expm

def run(seal=False):
    assert not sys.flags.optimize
    guard()
    for name in ('capture-method','snapshot','capture-execution','kinetic-method','kinetic-forecast','reference-method','native-truth','transfer-method','transfer-forecast','feedback-method','feedback-forecast'):
        check(name+'.json')
    evidence=json.loads((HERE/'physical-readout.json').read_bytes())
    diagnostic=json.loads((HERE/'scores.json').read_bytes())
    coupled_scores=json.loads((HERE/'feedback-scores.json').read_bytes())
    shared={}
    for tag,end in [('cold',SHORT),('matched',LONG)]:
        snap=data(HERE/f'{tag}-moments.npz')
        nat=data(HERE/f'{tag}-true.npz')
        run=data(HERE/f'{tag}-primary.npz')
        kin=dict(zip(run['keys'],run['values'].transpose(1,0,2)))
        tf=data(HERE/f'thomson-{tag}-primary-3.npz')
        fine=data(HERE/f'thomson-{tag}-fine-3.npz')
        assert len(run['k'])==782 and np.all(np.diff(run['k'])>0)
        assert all(np.array_equal(run['k'],obj['k']) for obj in (snap,nat,tf,fine))
        assert snap['cut']==CUT and run['t'][0]==tf['t'][0]==nat['t'][0]==CUT
        assert run['t'][-1]==tf['t'][-1]==nat['t'][-1]==end
        assert np.array_equal(run['t'],fine['t']) and set(snap['layouts'][:,0])=={1,5}
        pos=np.searchsorted(run['t'],nat['t'])
        assert np.array_equal(run['t'][pos],nat['t'])
        loc=evidence[tag]
        for field,ref in [('D',nat['values'][:,0]),('J',nat['values'][:,1]),('S',nat['values'][:,3]),('A',(nat['values'][:,0]+3*nat['values'][:,2])/2)]:
            dif=kin[field][pos]-kin[field][pos[0]]
            denom=np.max(abs(ref-ref[0]),axis=0)
            err=100*np.max(abs(dif-(ref-ref[0])),axis=0)/denom
            reported=loc['direct']['primary']['available'][field]['change']
            assert np.isclose(np.max(err),reported['worst'],rtol=1e-10)
            assert int(np.sum(err>.5))==reported['over']
        initial=json.loads((HERE/f'launch-{tag}.json').read_bytes())
        assert initial['Sprime_vs_native']<.001 and initial['omit_octupole_Sprime_error']>50
        assert loc['momentum_identity']['worst']<.5
        assert loc['direct']['primary']['available']['S']['change']['peak']<loc['direct']['old-tangent']['available']['S']['change']['peak']
        assert np.isfinite(tf['values']).all() and np.max(abs(fine['values']-tf['values']))<.005*np.max(abs(tf['values']))
        native=audit_sources.load_native(tag,before=end)
        choose=native.time>=CUT
        def rates(pred,ref):
            return 100*np.max(abs((pred-pred[0])-(ref-ref[0])),axis=0)/np.max(abs(ref-ref[0]),axis=0)
        for step in ('640','1280'):
            packet=data(HERE/f'coupled-{tag}-{step}.npz');truths={}
            assert np.array_equal(packet['k'],snap['k']) and np.array_equal(packet['t'][pos],native.time[choose])
            for field,key in [('dg','clxg'),('qg','qg')]:
                vals=packet['values'][pos,packet['keys'].tolist().index(field)]
                ref=native.data[key][choose]
                error=rates(vals,ref)
                assert error.max()<.5 and np.isclose(error.max(),coupled_scores[tag][step]['available'][field]['change']['worst'])
                truths[field]=(vals[native.time[choose]<=SHORT],ref[native.time[choose]<=SHORT])
            shared[tag,step]=truths
            if tag=='matched':
                truth=data(pin('corrected-reference.npz'))
                for axis in (0,1):
                    gap=packet['fluid'][:,axis]-packet['wave'][:,axis]
                    measured=truth['fluid'][:,axis]-truth['wave'][:,axis]
                    assert rates(gap,measured).max()<.5
                    assert np.max(100*abs(gap-measured)/truth['oldnorm'][axis])<.5
    for step in ('640','1280'):
        for key in ('dg','qg'):
            pred,ref=shared['matched',step][key]
            base,base_ref=shared['cold',step][key]
            error=rates(pred-base,ref-base_ref)
            assert error.max()<.5 and np.isclose(error.max(),coupled_scores['paired_contrast'][step][key]['change']['worst'])
    waves=data(HERE/'matched-primary.npz')
    ref=data(pin('corrected-reference.npz'))
    assert np.array_equal(waves['centers'],ref['time'])
    gap=waves['fluid']-waves['wave'][:,:2]
    truth=ref['fluid']-ref['wave']
    rel=100*np.max(abs(gap-truth),axis=0)/ref['oldnorm']
    assert not np.any(rel>.5)
    dr=100*np.max(abs((gap-gap[0])-(truth-truth[0])),axis=0)/np.max(abs(truth-truth[0]),axis=0)
    assert (dr>.5).sum(axis=1).tolist()==[0,1]
    gains=json.loads((HERE/'kinetic-tail-gains.json').read_bytes())['rows']
    assert len(gains)==6 and all(0<row['constant_boundary_exact']<=row['gain_bound'] for row in gains)
    for path in HERE.iterdir():
        assert path.is_file() and path.suffix not in ('.partial','.dll','.o','.mod','.pyc'),path
        if path.suffix=='.py':compile(path.read_bytes(),str(path),'exec')
        if path.suffix=='.npz':
            with np.load(path,allow_pickle=False) as obj:
                for key in obj.files:
                    item=obj[key]
                    if np.issubdtype(item.dtype,np.number):assert np.isfinite(item).all()
    files={path.name:sha(path) for path in HERE.iterdir() if path.name!='seal.json'}
    record=dict(files=files,parents={PRIOR.name:SIGN},scope='Linear angular stress, local photon transfer on a frozen metric and conditional tail bounds. No sky fit or second-order visibility score.')
    if seal:write('seal.json',record)
    assert json.loads((HERE/'seal.json').read_bytes())==record
    print('Verified',len(files),'files; seal',sha(HERE/'seal.json'))
if __name__=='__main__':
    assert sys.argv[1:] in ([],['--seal'])
    run(bool(sys.argv[1:]))
