from common_shear import *
from scipy.linalg import expm
from math import factorial

def positive_tail(x,start):
    term=x**start/factorial(start)
    total=term
    for order in range(start+1,start+200):
        term*=x/order
        total+=term
        if term<1e-20*total:break
    return total+term*x/(order+1)/(1-x/(order+2))

def run():
    rows=[]
    for tag,length in [('cold',.375),('matched',1.175)]:
        early=data(HERE/f'{tag}-moments.npz')
        maximum=early['k'].max()*length
        for cap_order in (8,12,16):
            matrix=np.zeros((cap_order+2,cap_order+2))
            for ell in range(cap_order+1):
                if ell:matrix[ell,ell-1]=ell/(2*ell+1)
                matrix[ell,ell+1]=-(ell+1)/(2*ell+1)
            magnitude=(cap_order+1)/(2*cap_order+1)*positive_tail(maximum,cap_order-1)
            direct=abs(expm(maximum*matrix)[2,-1])
            assert direct>0 and direct<=magnitude
            rows.append(dict(tag=tag,delta_eta=length,kmax=early['k'].max(),L=cap_order,
                             gain_bound=magnitude,constant_boundary_exact=direct))
    write('kinetic-tail-gains.json',dict(rows=rows,scope='Fixed metric; agreed low initial data. Multiply gain by an upper bound on the difference in the two F_(L+1) histories. Not an absolute error budget for gravity or photons.'))
if __name__=='__main__':run()
