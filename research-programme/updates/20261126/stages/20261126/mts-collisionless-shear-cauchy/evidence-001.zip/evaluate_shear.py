from common_shear import *
from scipy.interpolate import make_interp_spline
import io
from kinetics import CUT,SHORT,LONG

def compare(pred,target):
    return audit_sources.ratio(pred,target)

def metrics(pred,target):
    return dict(full=compare(pred,target),change=compare(pred-pred[0],target-target[0]))

def evaluate():
    check('kinetic-forecast.json')
    scores={};contrast={}; lines=[]
    truth=data(pin('corrected-reference.npz'))
    refgap=truth['fluid']-truth['wave']
    for tag,end in [('cold',SHORT),('matched',LONG)]:
        native=audit_sources.load_native(tag,before=end)
        sel=native.time>=CUT
        tt=native.time[sel]
        assert tt[-1]==end
        k=native.k
        def inferred(degree):
            df=lambda field:make_interp_spline(native.time,field,k=degree)(tt,1)
            energy=-(df(native.D)+k*native.J[sel]+native.B[sel]*native.X[sel])/(2*native.H[sel])
            shear=(2*energy-native.D[sel])/3-(df(native.J)+2*native.H[sel]*native.J[sel])/k
            return energy,shear
        aa,ss=inferred(7)
        refs=dict(A=aa,S=ss,X=native.X[sel],D=native.D[sel],J=native.J[sel],
                  k_sigma=native.X[sel]+1.5*native.data['dgq'][sel]/k,pir=native.data['pir'][sel],
                  photon_density=native.data['clxg'][sel],photon_current=native.data['qg'][sel])
        scores[tag]={}
        for name in ('primary','fine','more-angles','massive-only','old-tangent'):
            if name=='old-tangent':
                if tag=='cold':
                    arr=data(pin('paired-cold-energy-current.npz'))
                    series={key:arr[key] for key in ('X','A','S','D','J')}
                else:
                    arr=data(pin('nu-energy-current.npz'))
                    s0=data(pin('massive-inputs.npz'))['order5']
                    series=dict(X=arr['X'],A=arr['sectors'][:,4],S=s0[5]+(arr['t']-CUT)[:,None]*s0[6],D=arr['D'],J=arr['J'])
            else:
                arr=data(HERE/f'{tag}-{name}.npz')
                series=dict(zip(arr['keys'],arr['values'].transpose(1,0,2)))
            ix=np.searchsorted(arr['t'],tt)
            assert np.array_equal(arr['t'][ix],tt) and np.array_equal(arr['k'],k)
            record={}
            for label,choose in [('common',tt<=SHORT),('available',tt<=end)]:
                record[label]={field:metrics(series[field][ix][choose],target[choose]) for field,target in refs.items() if field in series}
            scores[tag][name]=record
            if tag=='matched':
                gap=arr['fluid']-arr['wave'][:,:2]
                if 'centers' in arr:assert np.array_equal(truth['time'],arr['centers'])
                contrast[name]={}
                for axis,channel in enumerate(('energy','current')):
                    contrast[name][channel]=metrics(gap[:,axis],refgap[:,axis])
                    rates=100*np.max(abs(gap[:,axis]-refgap[:,axis]),axis=0)/truth['oldnorm'][axis]
                    contrast[name][channel]['old_denominator']={'worst':rates.max(),'over':int(np.sum(rates>.5))}
                    if name=='primary':
                        delta=gap[:,axis]-gap[0,axis];true=refgap[:,axis]-refgap[0,axis]
                        drift=100*np.max(abs(delta-true),axis=0)/np.max(abs(true),axis=0)
                        lines.extend(dict(k=float(mode),channel=channel,rate_old_norm_pct=float(rate),drift_pct=float(dd)) for mode,rate,dd in zip(k,rates,drift))
            summary={field:round(val['change']['peak'],6) for field,val in record['available'].items()}
            print(tag,name,summary, flush=True)
    body=io.StringIO(newline='')
    writer=csv.DictWriter(body,fieldnames=list(lines[0]),lineterminator='\n')
    writer.writeheader();writer.writerows(lines)
    parent.save(HERE/'mode-results.csv',body.getvalue().encode())
    write('scores.json',dict(sources=scores,contrasts=contrast))
    print('primary matched',contrast['primary'],flush=True)
if __name__=='__main__':evaluate()
