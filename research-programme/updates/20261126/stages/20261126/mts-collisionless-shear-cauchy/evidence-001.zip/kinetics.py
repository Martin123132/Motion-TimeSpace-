from common_shear import *
from scipy.interpolate import CubicSpline,make_interp_spline
from clock_forecast import advance
from types import SimpleNamespace
CUT=89.275
SHORT=89.65
LONG=90.45

def prepare(tag,limit):
    state=data(HERE/(tag+'-moments.npz'))
    par=initial(tag)
    hist=audit_sources.load_native(tag,before=CUT)
    grid=par.k
    np.testing.assert_equal(grid,state['k'])
    assert state['cut']==CUT and hist.time[-1]==CUT
    layout=state['layouts']
    q=state['q']
    weights=state['weights'][:,None]
    mass=state['mass'].item()
    unit=state['unit'].item()
    qscale=(mass/q)**2/2
    assert np.all(layout[:,3]>=limit)
    n=len(grid)
    rad=state['r'][:,0,:limit+1].T.copy()
    raw=state['f'][:,:,0,:limit+1].transpose(1,2,0).copy()
    vel=state['f'][:,:,1,:limit+1].transpose(1,2,0).copy()
    early_r=state['r'][:,1,:limit+1].T.copy()
    slots=np.arange(len(q))[:,None]>=layout[:,0]
    for index in range(len(q)):
        missing=slots[index]
        if missing.any():
            assert np.all(layout[missing,4]>=limit) and np.all(layout[missing,2]>=limit)
            raw[index][:,missing]=rad[:,missing]+qscale[index]*state['c'][missing,0,:limit+1].T
            vel[index][:,missing]=early_r[:,missing]+qscale[index]*state['c'][missing,1,:limit+1].T
    slowq=grid*hist.v*hist.data['mts_dphi_s']
    sq0=slowq[-1]
    sqp=make_interp_spline(hist.time[-6:],slowq[-6:],k=5)(CUT,1)
    explicit=1. if tag=='matched' else 0.
    other=par.ini
    y0=np.vstack([other[:6],other[11:13],rad,raw.reshape(-1,n)])
    ufa=np.where(layout[:,2]==2,-np.inf,np.maximum(20,layout[:,2]-4)/grid)
    assert np.all((layout[:,2]==2)|(ufa>=CUT-.011))
    return SimpleNamespace(**locals())

def unpack(prep,state):
    last=prep.limit+1
    return state[:8],state[8:8+last],state[8+last:].reshape(len(prep.q),last,-1)

def geometry(prep,tm):
    par=prep.par
    dt=tm-CUT
    coef=par.h0*par.h0-par.pressure
    fac=1+par.h0*dt+coef*dt*dt/4
    aa=par.a0*fac
    hh=(par.h0+coef*dt/2)/fac
    inv=1/np.sqrt(1+(aa*prep.mass/prep.q[:,None])**2)
    ww=prep.weights*prep.unit/aa**2
    return fac,aa,hh,inv,ww

def integrate_moments(ww,inv,dist):
    density=np.sum(ww/inv*dist[:,0],axis=0)
    current=np.sum(ww*dist[:,1],axis=0)
    pressure=np.sum(ww*inv*dist[:,0],axis=0)/3
    shear=(2/3)*np.sum(ww*inv*dist[:,2],axis=0)
    return density,current,pressure,shear

def equations(prep,tm,state,massless_live=True,output=False):
    par=prep.par
    grid=par.k
    dt=tm-CUT
    (xx,cd,bd,vb,ph,qg,fd,fj),rad,dist=unpack(prep,state)
    dg=rad[0]; qr=rad[1]
    fac,aa,hh,inv,ww=geometry(prep,tm)
    den,jn,press,shear=integrate_moments(ww,inv,dist)
    trace=(den+3*press)/2
    gc,gb,gg,gr=par.weights/np.array([fac,fac,fac**2,fac**2])
    pig,pir,opacity,pb=par.forc+dt*par.forcp
    heavyp=heavyq=0.
    fdp=fjp=np.zeros_like(xx)
    if prep.tag=='matched':
        rr=(grid/(aa*par.m))**2
        hp=rr/(np.sqrt(1+rr)+1)**2*(fd+3*hh*fj/grid)
        heavyp=par.rho/aa*(fd+3*hp)/2
        heavyq=par.rho/aa*fj
        fdp,fjp=-3*hh*hp-grid*fj-xx,-hh*fj+grid*hp
    sigma_k=xx+1.5*(gb*vb+gg*qg+gr*qr+jn+heavyq+prep.sq0+dt*prep.sqp)/grid
    if output:return np.array([xx,den,jn,trace,shear,sigma_k,rad[2],fd,fj,ph,qg])
    drag=opacity*(4*vb/3-qg)
    answer=np.empty_like(state)
    dst,dr,df=unpack(prep,answer)
    dst[:]=[-hh*xx-(gc*cd+gb*bd)/2-gg*ph-gr*dg-par.slow-dt*par.slowp-trace-heavyp,
            -xx,-xx-grid*vb,-hh*vb+grid*pb-gg/gb*drag,-4*xx/3-grid*qg,grid*(ph-2*pig)/3+drag,fdp,fjp]
    ell=np.arange(2,prep.limit)[:,None]
    dr[0]=-4*xx/3-grid*qr
    dr[1]=grid*(dg-2*(rad[2] if massless_live else pir))/3
    dr[2:-1]=grid*(ell*rad[1:-2]-(ell+1)*rad[3:])/(2*ell+1)
    dr[2]+=8*sigma_k/15
    dr[2]=np.where(tm>=prep.ufa,-3*rad[2]/tm-dr[0],dr[2])
    dr[-1]=grid*rad[-2]-(prep.limit+1)*rad[-1]/tm
    kv=grid*inv
    df[:,0]=-4*xx/3-kv*dist[:,1]
    df[:,1]=kv*(dist[:,0]-2*dist[:,2])/3
    df[:,2:-1]=kv[:,None,:]*(ell*dist[:,1:-2]-(ell+1)*dist[:,3:])/(2*ell+1)
    df[:,2]+=8*sigma_k/15
    df[:,-1]=kv*dist[:,-2]-(prep.limit+1)*dist[:,-1]/tm
    return answer

def test_launch(prep):
    y=prep.y0;par=prep.par
    fac,aa,hh,inv,ww=geometry(prep,CUT)
    dv=-hh*inv*(1-inv**2)
    native=prep.vel
    calc=unpack(prep,equations(prep,CUT,y))[2]
    out=equations(prep,CUT,y,output=True)
    original=prep.hist
    direct=(2/3)*np.sum(ww*inv*native[:,2],axis=0)
    dilution=-2*hh*out[4]
    redshift=(2/3)*np.sum(ww*dv*prep.raw[:,2],axis=0)
    pref=ww*inv*(2/3)
    flux=np.sum(pref*(prep.grid*inv)*(2*prep.raw[:,1]-3*prep.raw[:,3])/5,axis=0)
    metric=np.sum(pref*(8/15)*out[5],axis=0)
    reference=direct+dilution+redshift
    total=flux+metric+redshift+dilution
    known=par.shearp
    def peak(test,ref):return 100*np.max(abs(test-ref))/np.max(abs(ref))
    scores={key:peak(test,ref) for key,test,ref in [('D',out[1],original.D[-1]),('J',out[2],original.J[-1]),('A',out[3],par.trace),
             ('S',out[4],par.shear),('k_sigma',out[5],original.X[-1]+1.5*original.data['dgq'][-1]/prep.grid),
             ('Sprime_vs_native',total,reference),('native_Sprime_vs_old',reference,known),
             ('F2prime_vs_native',calc[:,2],native[:,2])]}
    no_octupole=total+np.sum(pref*(prep.grid*inv)*3*prep.raw[:,3]/5,axis=0)
    scores['omit_octupole_Sprime_error']=peak(no_octupole,reference)
    return scores,np.stack([flux,metric,redshift,dilution,total,reference,known])

def run(tag,name,limit,step,live):
    prep=prepare(tag,limit)
    launch,work=test_launch(prep)
    assert max(launch['D'],launch['J'],launch['k_sigma'])<.001,launch
    write(f'launch-{tag}.json',launch) if name=='primary' else None
    if name=='primary':pack(f'shear-drive-{tag}.npz',k=prep.grid,terms=work,keys=['stream','metric','redshift','dilution','sum','native','inferred'])
    time=np.arange(round(CUT*320),round((LONG if tag=='matched' else SHORT)*320)+1)/320
    state=prep.y0.copy()
    samples=[]
    for idx,tm in enumerate(time):
        samples.append(equations(prep,tm,state,live,True))
        if idx+1==len(time):break
        if idx%32==0:guard()
        for substep in range(step//320):
            tick=tm+substep/step
            delta=1/step
            slope1=equations(prep,tick,state,live)
            slope2=equations(prep,tick+delta/2,state+slope1*delta/2,live)
            slope3=equations(prep,tick+delta/2,state+slope2*delta/2,live)
            slope4=equations(prep,tick+delta,state+slope3*delta,live)
            state+=delta/6*(slope1+2*slope2+2*slope3+slope4)
    hist=np.asarray(samples)
    assert np.isfinite(hist).all()
    arrays=dict(t=time,k=prep.grid,values=hist,keys=['X','D','J','A','S','k_sigma','pir','e','j','photon_density','photon_current'])
    if tag=='matched':
        older=data(ep('matched-ordinary-physical.npz'))
        assert np.array_equal(time,older['time'])
        centers=older['centers'];mm=prep.par.m
        ruler=CubicSpline(time,mm*older['scale']).antiderivative()(time)
        force=make_interp_spline(time,hist[:,0],k=5)
        def metric(tt):
            _,aa,hh,_,_=geometry(prep,tt)
            return aa,hh,force(tt)
        seed=data(pin('clock-inputs.npz'))['local_at_cut']
        result=advance(metric,prep.grid,mm,CUT,time[-1],seed,time,1/640)
        aa=np.array([geometry(prep,tt)[1] for tt in time])
        wave=project_state(result,aa,time,centers,mm,prep.par.rho,prep.grid,ruler)
        arrays.update(centers=centers,wave=wave,fluid=result[np.searchsorted(time,centers),4:6],
                      fluid_coupling_absolute=np.max(abs(hist[:,7:9]-result[:,4:6]),axis=0))
    pack(f'{tag}-{name}.npz',**arrays)
    print(tag,name,launch if name=='primary' else 'done',flush=True)

if __name__=='__main__':
    check('capture-execution.json')
    receipt('kinetic-method.json',[HERE/'DESIGN.md',HERE/'kinetics.py',HERE/'capture-execution.json',pin('paired_source_control.py'),pin('clock_forecast.py'),pin('clock-inputs.npz')])
    files=[]
    for model in ('cold','matched'):
        for name,order,step,live in [('primary',12,640,True),('more-angles',16,640,True),('fine',12,1280,True),('massive-only',12,640,False)]:
            run(model,name,order,step,live)
            files.append(HERE/f'{model}-{name}.npz')
    receipt('kinetic-forecast.json',[HERE/'kinetic-method.json',*files])
