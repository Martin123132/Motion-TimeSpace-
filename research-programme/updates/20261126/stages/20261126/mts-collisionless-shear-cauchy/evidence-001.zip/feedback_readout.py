from evaluate_shear import metrics
from common_shear import *
from kinetics import CUT,SHORT,LONG
import io

def run():
    check('feedback-forecast.json');check('native-truth.json')
    prior=data(pin('corrected-reference.npz'))
    records={};rows=[];shared={}
    for tag,end in [('cold',SHORT),('matched',LONG)]:
        native=audit_sources.load_native(tag,before=end)
        tt=native.time[native.time>=CUT];idx=np.searchsorted(native.time,tt)
        nt=data(HERE/f'{tag}-true.npz');k=native.k
        assert np.array_equal(tt,nt['t']) and np.array_equal(k,nt['k'])
        D,J,P,S,*_=nt['values'].transpose(1,0,2)
        truth=dict(X=native.X[idx],A=(D+3*P)/2,S=S,J=J,D=D,
                   dg=native.data['clxg'][idx],qg=native.data['qg'][idx],pig=native.data['pig'][idx],vb=native.data['vb'][idx],
                   k_sigma=native.X[idx]+1.5*native.data['dgq'][idx]/k)
        cases={}
        for step in (640,1280):
            arr=data(HERE/f'coupled-{tag}-{step}.npz');pos=np.searchsorted(arr['t'],tt)
            assert np.array_equal(arr['t'][pos],tt) and np.array_equal(arr['k'],k)
            vals=dict(zip(arr['keys'],arr['values'][pos].transpose(1,0,2)))
            row={span:{key:metrics(vals[key][sel],ref[sel]) for key,ref in truth.items()} for span,sel in [('common',tt<=SHORT),('available',tt<=end)]}
            fields=('X','S','A','dg','qg')
            shared[tag,step]=(tt[tt<=SHORT],k,{key:vals[key][tt<=SHORT] for key in fields},{key:truth[key][tt<=SHORT] for key in fields})
            for key in ('dg','qg'):
                corr=vals[key]-vals[key][0]
                ref=truth[key]-truth[key][0]
                errs=100*np.max(abs(corr-ref),axis=0)/np.max(abs(ref),axis=0)
                rows.extend([dict(tag=tag,step=step,field=key,test='change',k=grid,error_pct=error) for grid,error in zip(k,errs)])
            if tag=='matched':
                gap=arr['fluid']-arr['wave'][:,:2]
                target=prior['fluid']-prior['wave']
                assert np.array_equal(arr['centers'],prior['time'])
                row['heavy']={}
                for axis,key in enumerate(('energy','current')):
                    z=metrics(gap[:,axis],target[:,axis])
                    z['oldnorm_worst']=np.max(100*np.max(abs(gap[:,axis]-target[:,axis]),axis=0)/prior['oldnorm'][axis])
                    row['heavy'][key]=z
                    err=(gap[:,axis]-gap[0,axis])-(target[:,axis]-target[0,axis])
                    rates=100*np.max(abs(err),axis=0)/np.max(abs(target[:,axis]-target[0,axis]),axis=0)
                    rows.extend([dict(tag=tag,step=step,field=key,test='heavy-drift',k=grid,error_pct=error) for grid,error in zip(k,rates)])
                row['independent_fluid_integration_pct_of_contrast']=(100*np.max(abs(arr['fluid']-arr['evolved_fluid']),axis=0)/prior['oldnorm']).max(axis=1).tolist()
            cases[str(step)]=row
            print(tag,step,{field:(round(row['available'][field]['change']['peak'],7),round(row['available'][field]['change']['worst'],7),row['available'][field]['change']['over']) for field in ('X','A','S','dg','qg')})
            if tag=='matched':print('heavy',row['heavy'])
        records[tag]=cases
    records['paired_contrast']={}
    for step in (640,1280):
        tm,km,vm,rm=shared['matched',step]
        tc,kc,vc,rc=shared['cold',step]
        assert np.array_equal(tm,tc) and np.array_equal(km,kc)
        scores={}
        for key in vm:
            forecast=vm[key]-vc[key];reference=rm[key]-rc[key]
            scores[key]=metrics(forecast,reference)
            scores[key]['signal_peak_pct_of_cold']=100*np.max(abs(reference))/np.max(abs(rc[key]))
            scores[key]['drift_peak_pct_of_cold_drift']=100*np.max(abs(reference-reference[0]))/np.max(abs(rc[key]-rc[key][0]))
        records['paired_contrast'][str(step)]=scores
        print('matched minus cold',step,[(key,scores[key]['change']['peak'],scores[key]['change']['worst'],scores[key]['change']['over']) for key in ('dg','qg')])
    write('feedback-scores.json',records)
    output=io.StringIO(newline='')
    writer=csv.DictWriter(output,fieldnames=list(rows[0]),lineterminator='\n')
    writer.writeheader();writer.writerows(rows)
    parent.save(HERE/'feedback-mode-checks.csv',output.getvalue().encode())

if __name__=='__main__':run()
