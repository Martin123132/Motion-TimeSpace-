from bank_io import *
from io import StringIO
import csv


def factors():
    import source_bank
    legs=book.read(book.pinned(book.PRE,"native-incoming.npz"))["nodes"]
    op,_=source_bank.spatial_operator(legs)
    selected=np.unique(np.r_[op.field[op.phase!=0],op.metric[op.phase!=0]])
    return legs,selected


def main():
    verified_input();check("all-forecast.json")
    grid,support=factors();expect=np.arange(round(89.55*320),round(90.4*320)+1)/320
    launch=np.flatnonzero(expect==89.65).item();summary={};records=[];models=run_live.MODELS
    for block in range(38):
        data={label:book.read(HERE/f"bank/{label}-{block:02d}.npz") for label in models}
        truth=score_live.columns(data["original"])
        for label in models:
            packet=data[label];ids=packet["indices"];mode=packet["k"]
            assert packet["block"]==block and np.array_equal(mode,grid[ids]) and np.array_equal(packet["t"],expect)
            assert np.isfinite(packet["values"]).all()
            result=score_live.evaluate(packet);cross=score_live.evaluate(packet,3,4)
            if label=="original":reference=result["scale"]
            raw=score_live.columns(packet)
            extra={}
            if label in ("primary","fine"):
                for key in ("sigma","etak","dgrho","dgq","mts_dphi_h","mts_dphidot_h"):
                    previous=truth[key][launch:];error=raw[key][launch:]-previous;drift=score_live.maximum(previous-previous[:1])
                    assert np.all(drift>0)
                    extra["initial_"+key]=100*abs(error[0])/drift
                    extra["archive_change_"+key]=100*score_live.maximum(error-error[:1])/drift
            factor=reference if label!="cold" else result["scale"]
            extras=dict(original_scale_error=result["err"]*result["scale"]/factor,
                        quadrature_spread=score_live.maximum(result["normalized_curve"]-cross["normalized_curve"]),
                        final_signed=result["normalized_curve"][-1],final_ward=result["pressure_free_curve"][-1],
                        ward=result["conservation"][0],curvature_work=result["conservation"][1],
                        raychaudhuri_work=result["conservation"][2],clock_work=result["conservation"][3],**extra)
            for j,idx in enumerate(ids):
                row=dict(model=label,block=block,index=int(idx),k=float(mode[j]),triangle=bool(idx in support))
                for key in ("scale","err","clock_err","native_err","integral_accounting","shear_rate_identity","shear_constraints_pct_of_level","weyl_identity_pct_of_own_rate"):
                    row[key]=float(result[key][j])
                for key,val in extras.items():row[key]=float(val[j])
                records.append(row)
    for label in models:
        rows=[r for r in records if r["model"]==label]
        assert [r["index"] for r in rows]==list(range(782)) and np.isfinite([r["err"] for r in rows]).all()
        keys=list(rows[0])[6:]
        stats={key:dict(max=max(r[key] for r in rows),worst=max(rows,key=lambda r:r[key])["index"],median=float(np.median([r[key] for r in rows]))) for key in keys}
        failures=lambda key:[r["index"] for r in rows if r[key]>=.5]
        summary[label]=dict(modes=len(rows),summary=stats,worst=max(rows,key=lambda r:r["err"]),failed_shear=failures("err"),
           failed_common_scale=failures("original_scale_error"),failed_ward=failures("ward"),failed_launch=sorted({i for key in keys if key.startswith("initial_") for i in failures(key)}),
           largest_on_triangle=max((r for r in rows if r["triangle"]),key=lambda r:r["err"]))
    fields=list(dict.fromkeys(k for r in records for k in r))
    buf=StringIO(newline="");writer=csv.DictWriter(buf,fieldnames=fields,lineterminator="\n");writer.writeheader();writer.writerows(records)
    save("mode-scores.csv",buf.getvalue().encode())
    put("scores.json",dict(gate_pct=.5,per_branch=summary,triangle_support=support.tolist(),forecast=book.sha(HERE/"all-forecast.json")))
    record("scores-freeze.json",[HERE/"all-forecast.json",HERE/"score_bank.py",PILOT/"score_live.py",HERE/"scores.json",HERE/"mode-scores.csv"])
    for key,row in summary.items():
        print(key,"worst",row["worst"]["index"],row["worst"]["err"],"shear fails",len(row["failed_shear"]),"launch fails",len(row["failed_launch"]),"ward fails",len(row["failed_ward"]),flush=True)


if __name__=="__main__":main()
