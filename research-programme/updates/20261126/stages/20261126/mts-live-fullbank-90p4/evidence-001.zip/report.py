from bank_io import *


def fmt(num):return f"{num:.6g}"


def make():
    for name in ("scores","projection","driving","exchange","photon-complex"):check(name+"-freeze.json")
    branches=obj(HERE/"scores.json")["per_branch"];proj=obj(HERE/"projection.json");drive=obj(HERE/"driving-scores.json")
    exchange=obj(HERE/"exchange.json");photons=obj(HERE/"photon-complex.json")
    lines=["# Full-bank coupled gravity and the explicit wave-stress photon test","",
           "The prediction was generated for all 782 original modes. Each of the four runs contains the same 38 mode blocks and 273 time samples, including incoming derivative support. Cold is the retained cold comparator, not the resolved MTS wave. Original and cold pilot packets remain byte-identical to the previous controls. Tables below use percentages, not fractions.","",
           "## Gravity at first order: per-mode change, not absolute level","",
           "| Run | Worst error (%) | Mode (k per Mpc) | Fails / 782 | Worst on target triangle (%) | Failed incoming matches | Worst pressure-free work (%) |",
           "|---|---:|---|---:|---:|---:|---:|"]
    for label,row in branches.items():
        worst=row["worst"];tri=row["largest_on_triangle"]
        lines.append(f"| {label} | {fmt(worst['err'])} | {worst['index']} ({fmt(worst['k'])}) | {len(row['failed_shear'])} | {fmt(tri['err'])} | {len(row['failed_launch']) if label in ('primary','fine') else 'n/a'} | {fmt(row['summary']['ward']['max'])} |")
    lines+=["","The two corrected tables are primary (phase spacing at most 0.04) and fine (0.02). All misses and their tiny-denominator scales are kept in mode-scores.csv, including whether each enters the first output triangle. On the common original normalization, the worst corrected errors are "+", ".join(fmt(branches[key]["summary"]["original_scale_error"]["max"])+"%" for key in ("primary","fine"))+". No mode is dropped. The maximum error in reproducing the signed integrated discrepancy from the separate work terms is "+fmt(max(x["summary"]["integral_accounting"]["max"] for x in branches.values()))+" percentage points. The maximum cubic/quintic diagnostic spread is "+fmt(max(x["summary"]["quadrature_spread"]["max"] for x in branches.values()))+" percentage points.","",
            "## Separate scalar energy and current exchange","",
            "| Model, scalar | Worst energy / current error (%) | Failed modes (energy / current) | Median energy error with metric work omitted (%) |",
            "|---|---:|---:|---:|"]
    for label in run_live.MODELS:
        for tag,row in exchange[label].items():
            lines.append(f"| {label}, {'slow' if tag=='s' else 'heavy'} | "+ " / ".join(map(fmt,row["max_pct"]))+" | "+" / ".join(str(len(v)) for v in row["failed"])+f" | {fmt(row['without_metric_median_pct'])} |")
    lines+=["","The common metric does work on the scalar. Incoming stress is carried rather than reset. The two laws use the actual scalar pressure; see EXCHANGE.md for equations and exchange.json for error and quadrature controls. Ordinary massive-species pressure was not separately measured by this test.","",
            "## Radiation and quadratic source predictions","",
            "| Model | Largest photon energy / current readout change (%) | Number outside 0.5% |",
            "|---|---:|---:|"]
    for label in run_live.MODELS:
        row=proj[label];lines.append(f"| {label} | "+" / ".join(map(fmt,row["radiation_worst_pct"]))+" | "+" / ".join(map(str,row["radiation_over_gate"]))+" |")
    lines+=["","The radiation table changes only the gravity readout on a fixed linear solution. Its volume-density identity cancels to "+fmt(max(proj[key]["radiation_invariant_pct_level"] for key in run_live.MODELS))+"% of the level. It is not a residual against a measured sky spectrum.","",
            "All five spatial outputs, ordered as in driving-scores.json, were retained for the real preparation. For the original wave the maximum replay errors over all 15 driving channels and 121 forward reference samples are "+fmt(np.max(drive["original"]["replay_level_pct"]))+"% of level and "+fmt(np.max(drive["original"]["replay_change_pct"]))+"% of change. The cold control has only 17 published-to-workspace incoming samples in this source chain through the join; its nine channels replay to "+fmt(np.max(drive["cold"]["replay_change_pct"]))+"% of change on those samples. A complete late cold solution has been generated here without a second late cold archive to compare against.","",
            "At the target (4,2,1), changing from the original to the fine wave alters explicit quadratic heavy energy/current by "+" / ".join(map(fmt,proj["fine"]["different_from_original_pct_change"][0]))+"% of their original changes. The primary/fine spread is "+" / ".join(map(fmt,proj["fine_minus_primary_pct_original_change"][0]))+"%. Using integrated shear in place of algebraic shear on the *same* fine solution alters them by "+" / ".join(map(fmt,proj["fine"]["shear_only_effect_pct_change"][0]))+"% of their changes. These are distinct effects. For explicit heavy pressure and its density-constraint numerator the fine-minus-original changes are "+" / ".join(map(fmt,drive["derived_fine_minus_original_pct_change"][0]))+"%. The driven field and compensator also contribute to total stress.","",
            "## What reaches the visibility distribution","",
            "Hold the resolved state, its metric denominator, the matched branch and all other forces fixed. Insert the *difference* in three explicit resolved heavy stress channels into the two-route transfer. The following test measures the direct term only, not a rerun of the 77-bin state. Gap units are percent of the original small photon correction, not percent of the CMB.","",
            "| Grid / table | Prior joint gap | Direct term norm | Signed contribution (points) | Conditional gap with entry | Conditional gap without entry |",
            "|---|---:|---:|---:|---:|---:|"]
    for grid,row in photons.items():
        for model in ("primary","fine"):
            part=row[model];item=part["with_entry"];lines.append(f"| {grid} / {model} | {fmt(row['reference_gap_pct'][2])} | {fmt(item['norm_pct'][2])} | {fmt(item['signed_joint_points'])} | {fmt(item['conditional_gap_pct'][2])} | {fmt(part['interior']['conditional_gap_pct'][2])} |")
    lines+=["","The independent transfer of the saved interval reproduces its photon vector to "+fmt(max(max(row["control_replay_pct"]) for row in photons.values()))+" percentage points. The norm above bounds the improvement available from **these terms alone with other fields held fixed**. It does not bound responding matter, metric force, perturbed wave, phase preparation or feedback.","","## Reproduction and limits","",
            "Use the retained Python 3.13 native environment with numerical libraries restricted to one thread. generate_bank.py reuses the four sealed pilot packets. After all-forecast.json: score_bank.py, exchange.py, project.py, driving.py, photon_probe.py, report.py then verify_bank.py. The stage uses write-once data and separate forecast/score receipts. The raw native numerical warnings are preserved in native-run.log. This is a numerical field-equation test on the retained preparation, not a fit. No changes to GitHub or old checkpoints by this stage."]
    lines.extend(["","Run entry_correction.py after photon_probe.py and before report.py: it restores the complex boundary impulse omitted by a real cast in the first transfer. The corrected forecast in photon-complex.npz keeps every interior vector unchanged. Its independent real/imaginary controls are in entry-check.json. The largest reported quadrature spread for the fine heavy energy/current conservation errors is "+" / ".join(map(fmt,exchange["fine"]["h"]["maximum_quadrature_spread_pct"]))+" percentage points; interpret very small residuals with this numerical floor. Six native Romberg warnings are retained: the largest stated integration error is 1.46e-13, versus 8.32e-14 requested, for an integral near 192.58."])
    lines.extend(["","## What is worth propagating next","",
                  "By the reverse triangle inequality, the smallest joint gap obtainable even by perfectly aligning the *measured norm* of the direct correction against the old gap is "+fmt(photons["p32"]["reference_gap_pct"][2]-photons["p32"]["fine"]["with_entry"]["norm_pct"][2])+"% on p32. Thus these three explicit stress terms cannot reach 0.5% on their own at this size. Their actual signed projection is only "+fmt(photons["p32"]["fine"]["with_entry"]["signed_joint_points"])+" percentage points; most of the vector does not cancel the discrepancy. Following the direct change, at least "+fmt(photons["p32"]["fine"]["with_entry"]["conditional_gap_pct"][2]-.5)+" further points of appropriately directed response are needed on the original small-signal scale.",
                  "Next propagate the corrected force packet, not a tuned rotation of that vector: keep the separate resolved and matched states at 89.65, change the resolved metric and scalar forcing together, evolve ordinary matter, gravity and the 77 momentum bins, and compare the resulting photon vector on p16/p32 to its direct-only prediction. In particular U and Qf/Qw may change the later state even when direct energy/current cannot close the gap. Keep any source not yet supplied identical and label it; do not silently apply the resolved physical orientation to the phase-averaged matched branch."])
    save("RESULTS.md",("\n".join(lines)+"\n").encode("utf-8"))


if __name__=="__main__":make()
