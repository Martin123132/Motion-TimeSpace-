import hashlib
import json
import os
import sys
from pathlib import Path
from unittest.mock import patch

HERE=Path(__file__).resolve().parent
PILOT=HERE.parent/"mts-live-canonical-background-90p4-20261126"
EXPECTED="04a7bcc139b5711a8bce030d7282893bfaaf5843666fcd13f8df859669ab5c24"
assert hashlib.sha256((PILOT/"seal.json").read_bytes()).hexdigest()==EXPECTED
sys.path.insert(0,str(PILOT))
import book
import run_live
import joined_run
import score_live
import numpy as np


def guard():
    book.guard()
    assert not (HERE/"STOP-REQUESTED").exists()


def local(func,*args,**kwargs):
    guard()
    with patch.object(book,"ROOT",HERE),patch.object(book,"guard",lambda:None):
        return func(*args,**kwargs)


def save(name,body):return local(book.save,name,body)
def put(name,body):return local(book.put,name,body)
def pack(name,**body):return local(book.pack,name,**body)
def record(name,paths):return local(book.record,name,paths)
def check(name):return local(book.check,name)
def obj(path):return json.loads(path.read_bytes())


def verified_input():
    guard();book.check("seal.json")
    assert obj(PILOT/"joined/preflight.json")["ready_for_whole_bank"]
    assert not obj(PILOT/"preflight.json")["ready_for_whole_bank"]
    assert set(run_live.MODELS)=={"original","primary","fine","cold"}
    assert score_live.GATE==.5
