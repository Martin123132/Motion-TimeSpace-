from bank_io import *
from types import SimpleNamespace
from scipy.interpolate import CubicSpline
import source_bank as sb


def load_fields(label,grid):
    names=["a","adotoa","sigma","etak","clxg","qg"]
    if label!="cold":names+="mts_dphi_h mts_dphidot_h mts_q_h mts_drho_h".split()
    fields={key:[] for key in names+["shift"]}
    for block in range(38):
        packet=book.read(HERE/f"bank/{label}-{block:02d}.npz");ids=packet["indices"];assert np.array_equal(grid[ids],packet["k"])
        data=score_live.columns(packet);state=score_live.evaluate(packet);start=np.flatnonzero(packet["t"]==89.65).item()
        for key in names:fields[key].append(data[key][start:])
        fields["shift"].append(-state["normalized_curve"]*state["scale"]/100)
    return packet["t"][start:],{key:np.concatenate(vals,axis=1) for key,vals in fields.items()}


def pct(diff,ref):
    scale=np.max(abs(ref-ref[:1]),axis=0);assert np.all(scale>0)
    return 100*np.max(abs(diff-diff[:1]),axis=0)/scale


def bilinear(op,phi,field,normal,velocity,mu2,dphi,dfield,dnormal):
    op.data.first=dict(phi=phi.T,f=field.T,n=normal.T,u=(normal-3*velocity[:,None]*phi).T,
                       dp=dphi.T,df=dfield.T,dn=dnormal.T,du=(dnormal-3*velocity[:,None]*dphi).T)
    def pair(method,a,b,da,db):
        apply=getattr(op,method)
        return apply(da,b)+apply(a,db)
    energy=velocity*(3*pair("product","phi","u","dp","du")+7.5*velocity*pair("product","phi","phi","dp","dp"))
    energy+=(pair("product","n","n","dn","dn")+pair("grad","f","f","df","df")+mu2*pair("product","f","f","df","df"))/2
    return np.stack((energy,-pair("dg","n","f","dn","df")),axis=-1)


def compute(label,table,mass,grid,operators):
    time,raw=load_fields(label,grid)
    alpha=raw["sigma"]/grid;hub=raw["adotoa"];scale=raw["a"]
    phi=raw["etak"]/grid-hub*alpha;shift=raw["shift"]
    dens=raw["clxg"]-4*hub*alpha;cur=raw["qg"]+4*grid*alpha/3
    pred=alpha+shift;other_phi=raw["etak"]/grid-hub*pred
    other_dens=raw["clxg"]-4*hub*pred;other_cur=raw["qg"]+4*grid*pred/3
    radiation=np.stack((dens,cur),axis=-1);other=np.stack((other_dens,other_cur),axis=-1)
    delta=np.stack((-4*hub*shift,4*grid*shift/3),axis=-1)
    drift=pct(delta,radiation);spreads=np.max(abs(other-radiation-delta),axis=0)
    same=other_dens-4*other_phi-(dens-4*phi)
    stats=dict(radiation_worst_pct=drift.max(0).tolist(),radiation_worst_indices=np.argmax(drift,axis=0).tolist(),
               radiation_over_gate=np.sum(drift>=.5,axis=0).tolist(),radiation_median_pct=np.median(drift,axis=0).tolist(),
               radiation_identity_pct_level=(100*spreads/np.max(abs(radiation),axis=0)).max(0).tolist(),
               radiation_invariant_pct_level=float(100*np.max(abs(same))/np.max(abs(dens-4*phi))),
               max_relative_a_mode_spread=float(np.max(abs(scale/scale[:,:1]-1))),max_relative_H_mode_spread=float(np.max(abs(hub/hub[:,:1]-1))))
    pack(f"radiation-{label}.npz",k=grid,t=time,algebraic=radiation,gravity_readout_delta=delta,change_gate_pct=drift,
         normalization=np.max(abs(radiation-radiation[:1]),axis=0))
    if table is None:return stats
    mass2=(mass*scale)**2;back=table[0](np.log(scale));vel=table[1](np.log(scale))
    rho=vel*raw["mts_dphidot_h"]+mass2*back*raw["mts_dphi_h"];current=grid*vel*raw["mts_dphi_h"]
    stats["native_stress_replay_pct_level"]=[float(np.max(100*np.max(abs(local-raw[key]),axis=0)/np.max(abs(raw[key]),axis=0))) for local,key in ((rho,"mts_drho_h"),(current,"mts_q_h"))]
    speed=-3*hub*vel-mass2*back
    field=raw["mts_dphi_h"]+vel*alpha;normal=raw["mts_dphidot_h"]+speed*alpha
    dphi=-hub*shift;df=vel*shift;dn=speed*shift
    outputs=[];corrections=[];linear=[];squares=[]
    for op in operators:
        common=(vel[:,0],mass2[:,0])
        main=sb.contractions(op,phi,field,normal,*common)
        adjusted=sb.contractions(op,phi+dphi,field+df,normal+dn,*common)
        square=sb.contractions(op,dphi,df,dn,*common)
        cross=bilinear(op,phi,field,normal,*common,dphi,df,dn)
        outputs.append(main);corrections.append(adjusted-main);linear.append(cross);squares.append(square)
    output,change,mixed,squared=[np.stack(items,axis=1) for items in (outputs,corrections,linear,squares)]
    stats["shear_only_effect_pct_change"]=pct(change,output).tolist()
    stats["shear_identity_pct_level"]=(100*np.max(abs(change-mixed-squared),axis=0)/np.max(abs(output),axis=0)).tolist()
    pack(f"quadratic-{label}.npz",t=time,stress=output,change=change,cross=mixed,square=squared)
    return stats


def main():
    verified_input();check("all-forecast.json");cap=book.capture_module()
    src=book.config(cap,"original");canonical=book.read(src)
    folder=sb.historic.io.oldio.PAD/"material-halfstep";archive=book.pinned(folder.parent,folder.name+"/forcing-heavy.npz")
    lib=sb.orbit.spatial;legs=lib.pin("legs.json");shell=np.array(obj(legs)["squared_radii"])
    ar=book.read(archive);grid=ar["nodes"];data=SimpleNamespace(shell=shell,nodes=grid,first={})
    kernels=lib.Project(data).ops;assert np.array_equal(np.array(lib.PROBES),ar["coord"])
    assert np.array_equal(np.array([op[1] for op in kernels]),ar["k"])
    operators=[lib.Fast(op,data) for op in kernels]
    record("projection-method.json",[HERE/"QUADRATIC.md",HERE/"project.py",HERE/"all-forecast.json",src,legs,archive,PILOT/"joined/table-freeze.json",book.pinned(book.PRE,"source_bank.py")])
    summary={};stresses={}
    for label in run_live.MODELS:
        table=None
        if label=="original":table=tuple(CubicSpline(canonical["heavy_efold"],canonical[key],bc_type="natural") for key in ("phi_h","phidot_h"))
        elif label!="cold":
            bank=book.read(PILOT/f"joined/table-{label}.npz");table=tuple(CubicSpline(bank["x"],bank[key],bc_type="natural") for key in ("b","v"))
        summary[label]=compute(label,table,float(canonical["heavy_mass_mpc"]),grid,operators)
        if label!="cold":stresses[label]=book.read(HERE/f"quadratic-{label}.npz")["stress"]
    times=book.read(HERE/"quadratic-original.npz")["t"]
    rest=ar["values"][[ar["keys"].tolist().index(key) for key in ("henergy","hJ")]].transpose(1,2,0)
    use=np.isin(ar["eta"],times);assert use.sum()==121 and ar["eta"][use][0]==times[0] and ar["eta"][use][-1]==times[-1]
    control=rest[use];orig=stresses["original"];bias=orig[np.searchsorted(times,ar["eta"][use])]-control
    summary["archived_original"]=dict(shared_time_samples=int(use.sum()),level_pct=(100*np.max(abs(bias),axis=0)/np.max(abs(control),axis=0)).tolist(),
                                     change_pct=pct(bias,control).tolist())
    for label in ("primary","fine"):summary[label]["different_from_original_pct_change"]=pct(stresses[label]-orig,orig).tolist()
    summary["fine_minus_primary_pct_original_change"]=pct(stresses["fine"]-stresses["primary"],orig).tolist()
    summary["coordinates"]=ar["coord"].tolist()
    summary["nonzero_triangle_legs"]=[len(np.unique(np.r_[op.field[op.phase!=0],op.metric[op.phase!=0]])) for op in operators]
    put("projection.json",summary)
    record("projection-freeze.json",[HERE/"projection-method.json",HERE/"projection.json",*sorted(HERE.glob("quadratic-*.npz")),*sorted(HERE.glob("radiation-*.npz"))])
    print("Saved ordered energy/current projection on",len(kernels),"spatial triangles, and direct radiation on both controls.")


if __name__=="__main__":main()
