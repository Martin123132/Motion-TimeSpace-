from bank_io import *
from scipy.interpolate import CubicSpline, make_interp_spline
from numpy.polynomial.legendre import leggauss


def predict(packet,velocities,degree,order):
    raw=score_live.columns(packet);grid=packet["k"];clock=packet["t"];t=clock[clock>=book.ANCHOR]
    quadrature,weights=leggauss(order);width=np.diff(t);sample=(t[:-1,None]+width[:,None]*(1+quadrature)/2).ravel()
    def src(key):return make_interp_spline(clock,raw[key],k=degree)
    def integral(arr):
        terms=(arr.reshape(-1,order,len(grid))*weights[None,:,None]).sum(1)*width[:,None]/2
        return np.row_stack((np.zeros((1,len(grid))),np.cumsum(terms,axis=0)))
    H=src("adotoa");anti=H.antiderivative();h=H(sample);a=src("a")(sample)
    factor=np.exp(anti(sample)-anti(t[0]));endpoint=np.exp(anti(t)-anti(t[0]))
    metric=(src("dgrho")(sample)/2+grid*src("etak")(sample))/h;out={}
    for tag,spline in velocities.items():
        keys=[f"mts_{key}_{tag}" for key in ("drho","dp","q")]
        energy,_,current=[raw[key][clock>=book.ANCHOR] for key in keys]
        press=src(keys[1])(sample);j=src(keys[2])(sample)
        work=integral(-factor*spline(np.log(a))**2*metric)/endpoint
        pterm=integral(-3*factor*h*press)/endpoint;transport=integral(-factor*grid*j)/endpoint
        pred=energy[:1]/endpoint+pterm+transport+work
        predicted_j=(current[:1]+integral(factor**2*grid*press))/endpoint**2
        scale=np.stack((score_live.maximum(energy-energy[:1]),score_live.maximum(current-current[:1])))
        assert np.all(scale>0)
        err=np.stack(((pred-energy)/scale[0],(predicted_j-current)/scale[1]))*100
        out[tag]=dict(error=err,scale=scale,work_pct=100*score_live.maximum(work)/scale[0],
                      omitted_pct=100*score_live.maximum(pred-work-energy)/scale[0])
    return out


def main():
    verified_input();check("all-forecast.json");cap=book.capture_module()
    sources={name:book.config(cap,name) for name in ("original","cold")}
    record("exchange-method.json",[HERE/"EXCHANGE.md",HERE/"exchange.py",HERE/"all-forecast.json",*sources.values(),PILOT/"joined/table-freeze.json"])
    summary={}
    for model in run_live.MODELS:
        ar=book.read(sources["cold" if model=="cold" else "original"])
        vel={"s":CubicSpline(ar["efold"],ar["phidot_s"],bc_type="natural")}
        if model=="original":vel["h"]=CubicSpline(ar["heavy_efold"],ar["phidot_h"],bc_type="natural")
        elif model!="cold":
            tab=book.read(PILOT/f"joined/table-{model}.npz");vel["h"]=CubicSpline(tab["x"],tab["v"],bc_type="natural")
        collected={key:[] for key in vel}
        for block in range(38):
            packet=book.read(HERE/f"bank/{model}-{block:02d}.npz")
            fine=predict(packet,vel,5,6);other=predict(packet,vel,3,4)
            for key in vel:
                row=fine[key];err=row["error"]
                collected[key].append(np.row_stack((packet["indices"],np.max(abs(err),axis=1),row["scale"],row["work_pct"],row["omitted_pct"],
                           np.max(abs(err-other[key]["error"]),axis=1),err[:,-1])))
        summary[model]={}
        for key,blocks in collected.items():
            matrix=np.column_stack(blocks);assert np.array_equal(matrix[0],np.arange(782))
            energy,current=matrix[1:3];diff=matrix[7:9]
            summary[model][key]=dict(max_pct=[float(energy.max()),float(current.max())],median_pct=[float(np.median(energy)),float(np.median(current))],
                                    worst=[int(energy.argmax()),int(current.argmax())],failed=[np.flatnonzero(v>=.5).tolist() for v in (energy,current)],
                                    maximum_quadrature_spread_pct=diff.max(1).tolist(),without_metric_fail_count=int(np.sum(matrix[6]>=.5)),
                                    without_metric_median_pct=float(np.median(matrix[6])),without_metric_max_pct=float(matrix[6].max()))
            pack(f"exchange-{model}-{key}.npz",values=matrix,keys="index energy_pct current_pct energy_scale current_scale metric_work_pct energy_without_metric_pct energy_accuracy_pp current_accuracy_pp final_energy_pct final_current_pct".split())
    put("exchange.json",summary)
    record("exchange-freeze.json",[HERE/"exchange-method.json",HERE/"exchange.json",*sorted(HERE.glob("exchange-*.npz"))])
    print({model:{key:row["max_pct"] for key,row in sectors.items()} for model,sectors in summary.items()})


if __name__=="__main__":main()
