from bank_io import *
import ast
import csv


def verify():
    verified_input()
    for path in sorted(HERE.rglob("*")):
        if path.is_file() and (path.name.endswith(("-freeze.json","-forecast.json","-method.json",".receipt")) or path.name=="live-method.json"):
            check(path.relative_to(HERE))
    assert len(list((HERE/"bank").glob("*.npz")))==152
    assert len(list((HERE/"bank").glob("*.receipt")))==152
    assert not list(HERE.rglob("*.partial")) and not list(HERE.rglob("reader-mts-*")) and not list(HERE.rglob("__pycache__"))
    for path in HERE.glob("*.py"):ast.parse(path.read_text(encoding="utf-8"),filename=str(path))
    with (HERE/"mode-scores.csv").open() as stream:rows=list(csv.DictReader(stream))
    assert len(rows)==3128
    labels=run_live.MODELS;node=book.read(book.pinned(book.PRE,"native-incoming.npz"))["nodes"]
    branch=obj(HERE/"scores.json");assert branch["gate_pct"]==.5 and len(branch["triangle_support"])==106
    projection=obj(HERE/"projection.json");driving=obj(HERE/"driving-scores.json")
    exchange=obj(HERE/"exchange.json");direct=obj(HERE/"photon-complex.json")
    first=book.read(HERE/"direct-photon.npz");fixed=book.read(HERE/"photon-complex.npz")
    entry=np.array([label.endswith(":entry") for label in fixed["labels"].tolist()])
    assert np.array_equal(first["values"][:,~entry],fixed["values"][:,~entry]) and np.any(fixed["entry_potential"][entry].imag!=0)
    np.testing.assert_allclose(fixed["unit_visibility"][:,1],1j*fixed["unit_visibility"][:,0],rtol=2e-13,atol=1e-16)
    for idx in np.flatnonzero(entry):
        jump=fixed["entry_potential"][idx]
        np.testing.assert_allclose(fixed["values"][:,idx],fixed["unit_visibility"][:,0]*jump,rtol=2e-13,atol=0)
    for label in labels:
        scores=[r for r in rows if r["model"]==label];assert [int(r["index"]) for r in scores]==list(range(782))
        assert np.array_equal(np.array([float(r["k"]) for r in scores]),node)
        expected=branch["per_branch"][label]
        for source,col in (("failed_shear","err"),("failed_ward","ward"),("failed_common_scale","original_scale_error")):
            assert expected[source]==[int(r["index"]) for r in scores if float(r[col])>=.5]
        assert book.sha(HERE/f"bank/{label}-04.npz")==book.sha(PILOT/f"joined/bank/{label}-04.npz")
        errors=[]
        for block in range(38):
            pkt=book.read(HERE/f"bank/{label}-{block:02d}.npz");ids=pkt["indices"]
            assert int(pkt["block"])==block and np.array_equal(pkt["k"],node[ids])
            err=score_live.evaluate(pkt)["err"]
            np.testing.assert_allclose(err,[float(scores[i]["err"]) for i in ids],rtol=1e-11)
            errors.extend(err)
        np.testing.assert_allclose(max(errors),expected["worst"]["err"],rtol=1e-12)
        gamma=book.read(HERE/f"radiation-{label}.npz");assert gamma["algebraic"].shape==(241,782,2)
        np.testing.assert_allclose(100*np.max(abs(gamma["gravity_readout_delta"]),axis=0)/gamma["normalization"],gamma["change_gate_pct"],rtol=1e-10,atol=1e-11)
        output=book.read(HERE/f"driving-{label}.npz");assert output["values"].shape==(273,5,9 if label=="cold" else 15)
        for tag,info in exchange[label].items():
            ar=book.read(HERE/f"exchange-{label}-{tag}.npz");m=ar["values"]
            assert list(m.shape)==[11,782] and np.array_equal(m[0],np.arange(782)) and np.isfinite(m).all()
            for idx in range(2):assert np.flatnonzero(m[idx+1]>=.5).tolist()==info["failed"][idx]
        if label=="cold":continue
        quad=book.read(HERE/f"quadratic-{label}.npz")
        assert np.array_equal(quad["t"],output["t"][output["t"]>=book.ANCHOR])
        nums=[output["keys"].tolist().index(key) for key in ("henergy","hJ")]
        projected=output["values"][output["t"]>=book.ANCHOR][:,:,nums]
        diff=np.max(abs(quad["stress"]-projected),axis=0)/np.max(abs(projected),axis=0)
        assert np.max(diff)<1e-10,diff
        squared=quad["cross"]+quad["square"]
        rel=np.max(abs(squared-quad["change"]),axis=0)/np.max(abs(quad["stress"]),axis=0)
        assert rel.max()<1e-10 and np.isfinite(squared).all()
    assert projection["archived_original"]["shared_time_samples"]==121
    assert driving["cold"]["shared_samples"]==17 and driving["original"]["shared_samples"]==121
    for grid in ("p16","p32"):
        assert max(direct[grid]["control_replay_pct"])<1e-5
        for model in ("primary","fine"):
            for sub in ("interior","with_entry"):
                item=direct[grid][model][sub]
                assert abs(item["conditional_gap_pct"][2]-direct[grid]["reference_gap_pct"][2])<=item["norm_pct"][2]+1e-9
    files={p.relative_to(HERE).as_posix():book.sha(p) for p in HERE.rglob("*") if p.is_file() and p.name!="seal.json"}
    assert "native-run.log" in files and "RESULTS.md" in files
    manifest=dict(files=files,parents={PILOT.name:EXPECTED},scope="782 modes, four live branches, scalar exchange, real-orientation quadratic force, direct resolved-wave photon sensitivity at fixed other fields; not full phase-ensemble feedback.")
    if sys.argv[1:]==["--seal"]:put("seal.json",manifest)
    assert obj(HERE/"seal.json")==manifest
    print("Verified",len(files),"files, 3128 mode scores, all pilot receipts, scalar exchange and photon controls. Seal",book.sha(HERE/"seal.json"))


if __name__=="__main__":verify()
