from bank_io import *
from contextlib import ExitStack
import subprocess
import tempfile
import csv


def main():
    verified_input()
    if sys.argv[1:2]==["--child"]:
        assert all(os.environ[key]=="1" for key in ("OPENBLAS_NUM_THREADS","OMP_NUM_THREADS","MKL_NUM_THREADS","NUMEXPR_NUM_THREADS"))
        with ExitStack() as stack:
            for key,func in dict(ROOT=HERE,guard=guard,check=check,pack=pack,save=save,record=record,params=joined_run.install).items():
                stack.enter_context(patch.object(run_live,key,func))
            run_live.child()
        return
    cap=book.capture_module()
    schedule=cap.pin("capture-heavy.csv")
    with schedule.open() as stream:blocks=list(csv.DictReader(stream))
    incoming=book.pinned(book.PRE,"native-incoming.npz")
    with np.load(incoming) as raw:nodes=raw["nodes"]
    assert len(nodes)==782 and len(blocks)==38
    record("live-method.json",[HERE/"PROTOCOL.md",HERE/"generate_bank.py",HERE/"bank_io.py",PILOT/"seal.json",PILOT/"joined/live-method.json",schedule,incoming])
    for label in run_live.MODELS:
        name=f"bank/{label}-04.npz"
        with np.load(PILOT/"joined"/name) as raw:assert np.array_equal(raw["k"],nodes[17:41])
        save(name,(PILOT/"joined"/name).read_bytes())
        record(name+".receipt",[HERE/name,HERE/"live-method.json",PILOT/"joined"/(name+".receipt")])
    with tempfile.TemporaryDirectory(prefix="reader-mts-",dir=HERE) as folder:
        subprocess.run([sys.executable,"-B",str(HERE/"generate_bank.py"),"--child",folder,*run_live.MODELS],check=True,env=dict(os.environ,MTS_LIVE_NATIVE_STAGE="all"))
    receipts=sorted((HERE/"bank").glob("*.receipt"));assert len(receipts)==152
    for path in receipts:check(path.relative_to(HERE))
    assert book.sha(HERE/"live-readout.f90")==book.sha(PILOT/"live-readout.f90")
    record("all-forecast.json",[HERE/"live-method.json",HERE/"live-readout.f90",*receipts])
    print("Full 4 x 782 native forecast complete.",flush=True)


if __name__=="__main__":main()
