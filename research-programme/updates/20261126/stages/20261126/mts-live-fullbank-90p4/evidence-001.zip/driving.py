from bank_io import *
from types import SimpleNamespace
from scipy.interpolate import CubicSpline
import source_bank as sb


def fields(label):
    keys="a adotoa sigma etak phi dgq grho gpres mts_dphi_s mts_dphidot_s".split()
    if label!="cold":keys+="mts_dphi_h mts_dphidot_h".split()
    chunks={key:[] for key in keys}
    for block in range(38):
        packet=book.read(HERE/f"bank/{label}-{block:02d}.npz");use=slice(None);raw=score_live.columns(packet)
        for key in keys:chunks[key].append(raw[key][use])
    return packet["t"][use],{key:np.concatenate(raw,axis=1) for key,raw in chunks.items()}


def calculate(label,source,grid,shell,lib):
    ar=book.read(source);tm,raw=fields(label)
    h=raw["adotoa"];scale=raw["a"];alpha=raw["sigma"]/grid;phi=raw["etak"]/grid-h*alpha
    psi=2*raw["phi"]-phi;flux=-(raw["dgq"]+(raw["grho"]+raw["gpres"])*raw["sigma"])/(2*grid)
    data=SimpleNamespace(shell=shell,nodes=grid,first={key:val.T for key,val in dict(phi=phi,psi=psi,flux=flux,dphi=-flux-h*psi).items()})
    mapper=lib.Project(data);values=[];decomp=[]
    for kernel in mapper.ops:
        op=lib.Fast(kernel,data);p=op.product;dg=op.dg;grad=op.grad
        pp=p("phi","phi");ss=p("psi","psi");sp=p("phi","psi");kk=op.k2
        w_p=-1.5*(op.kp**2/kk-op.p2/3);w_q=-1.5*(op.kq**2/kk-op.q2/3)
        out=dict(U=-kk*pp+2*op.lap("phi","phi")-.5*grad("phi","phi")+1.5*p("flux","flux"),
                 Q=-kk*(pp+ss)+2*(p("phi","phi",w_p,w_q)-p("phi","psi",w_p,w_q))+op.shear("phi","phi")-op.shear("psi","psi")-2*op.shear("phi","psi"),
                 Fq=p("psi","dphi")-2*p("phi","dphi")+1.5*h[:,0]*ss)
        for tag,label2 in (("s","slow"),("h","heavy")):
            if tag=="h" and label=="cold":continue
            if tag=="h" and label!="original":
                tab=book.read(PILOT/f"joined/table-{label}.npz")
                coords=tab["x"];sv=(tab["b"],tab["v"])
            else:
                coords=ar["efold" if tag=="s" else "heavy_efold"];sv=(ar["phi_"+tag],ar["phidot_"+tag])
            base,vel=[CubicSpline(coords,v,bc_type="natural")(np.log(scale)) for v in sv]
            mass2=(scale*float(ar[label2+"_mass_mpc"]))**2;b=base[:,0];v=vel[:,0];mu2=mass2[:,0]
            f=raw["mts_dphi_"+tag]+vel*alpha
            n=raw["mts_dphidot_"+tag]+(-3*h*vel-mass2*base)*alpha
            data.first.update(f=f.T,n=n.T,u=(n-3*vel*phi).T)
            normal=3*p("phi","u")+7.5*v*pp
            out[tag+"field"]=p("psi","u")+3*p("phi","u")+v*(-ss/2+3*sp+7.5*pp)
            out[tag+"moment"]=dg("psi","f")-dg("phi","f")-mu2*(p("psi","f")-3*p("phi","f")+b*(-ss/2-3*sp+1.5*pp))
            out[tag+"energy"]=v*normal+.5*(p("n","n")+grad("f","f")+mu2*p("f","f"))
            out[tag+"trace"]=-2*v*normal-p("n","n")+grad("f","f")+2*mu2*p("f","f")
            out[tag+"J"]=-dg("n","f");out[tag+"shear"]=op.shear("f","f")
        values.append(np.stack(list(out.values()),axis=-1))
        if label!="cold":
            decomp.append(np.stack(((out["henergy"]-out["htrace"])/3,out["henergy"]+3*h[:,0]*out["hJ"]/kk),axis=-1))
    kwargs={} if not decomp else dict(heavy_derived=np.stack(decomp,axis=1),derived_keys=["explicit_pressure","explicit_density_numerator"])
    pack("driving-"+label+".npz",t=tm,coord=lib.PROBES,k=[o[1] for o in mapper.ops],keys=list(out),values=np.stack(values,axis=1),**kwargs)


def grade(delta,ref):
    den=np.max(abs(ref-ref[:1]),axis=0);assert np.all(den>0)
    return 100*np.max(abs(delta-delta[:1]),axis=0)/den


def main():
    verified_input();check("all-forecast.json");cap=book.capture_module()
    lib=sb.orbit.spatial;legs=lib.pin("legs.json");shell=np.array(obj(legs)["squared_radii"]);initial=book.pinned(book.PRE,"native-incoming.npz")
    grid=book.read(initial)["nodes"];cfg={model:book.config(cap,model) for model in ("original","cold")}
    record("driving-method.json",[HERE/"DRIVING.md",HERE/"driving.py",HERE/"all-forecast.json",initial,legs,*cfg.values(),PILOT/"joined/table-freeze.json",Path(lib.sources.__file__)])
    for label in run_live.MODELS:calculate(label,cfg["cold" if label=="cold" else "original"],grid,shell,lib)
    record("driving-forecast.json",[HERE/"driving-method.json",*sorted(HERE.glob("driving-*.npz"))])
    folder=sb.historic.io.oldio.PAD/"material-halfstep";models={key:book.read(HERE/f"driving-{key}.npz") for key in run_live.MODELS}
    rows={};inputs=[]
    for label,tag in (("original","heavy"),("cold","cold")):
        control_folder=folder if label=="original" else sb.old.BANK/"material-halfstep"
        path=book.pinned(control_folder.parent,control_folder.name+f"/forcing-{tag}.npz");inputs.append(path)
        archive=book.read(path);packet=models[label]
        common=np.isin(archive["eta"],packet["t"])
        ids=np.flatnonzero(common & ((archive["eta"]>=book.ANCHOR) if label=="original" else (archive["eta"]<=book.ANCHOR)))
        assert len(ids)==(121 if label=="original" else 17)
        pos=np.searchsorted(packet["t"],archive["eta"][ids]);keys=packet["keys"].tolist()
        assert np.array_equal(archive["coord"],packet["coord"]) and np.array_equal(archive["k"],packet["k"])
        ref=archive["values"][[archive["keys"].tolist().index(key) for key in keys]][:,ids].transpose(1,2,0)
        delta=packet["values"][pos]-ref
        rows[label]=dict(keys=keys,shared_samples=len(ids),first_eta=float(archive["eta"][ids[0]]),last_eta=float(archive["eta"][ids[-1]]),replay_level_pct=(100*np.max(abs(delta),axis=0)/np.max(abs(ref),axis=0)).tolist(),replay_change_pct=grade(delta,ref).tolist())
    for packet in models.values():
        keep=packet["t"]>=book.ANCHOR
        for key in ("values","heavy_derived"):
            if key in packet:packet[key]=packet[key][keep]
    reference=models["original"]["values"]
    for label in ("primary","fine"):
        val=models[label]["values"];rows[label]=dict(change_from_original_pct=grade(val-reference,reference).tolist())
        cold=models["cold"];both=[models[label]["keys"].tolist().index(key) for key in cold["keys"]]
        rows[label]["wave_minus_cold_pct_cold_change"]=grade(val[:,:,both]-cold["values"],cold["values"]).tolist()
    rows["table_spread_pct_original_change"]=grade(models["fine"]["values"]-models["primary"]["values"],reference).tolist()
    rows["derived_keys"]=models["fine"]["derived_keys"].tolist()
    rows["derived_fine_minus_original_pct_change"]=grade(models["fine"]["heavy_derived"]-models["original"]["heavy_derived"],models["original"]["heavy_derived"]).tolist()
    rows["derived_table_spread_pct_original_change"]=grade(models["fine"]["heavy_derived"]-models["primary"]["heavy_derived"],models["original"]["heavy_derived"]).tolist()
    put("driving-scores.json",rows)
    record("driving-freeze.json",[HERE/"driving-forecast.json",HERE/"driving-scores.json",*inputs])
    print("Scored five output modes: original wave 121 forward reference times, cold 17 incoming reference times; no late archived cold source in this replay.")


if __name__=="__main__":main()
