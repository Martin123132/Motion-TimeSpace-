from score_event import collect,surfaces,stats
from junction_io import *

def resolved_and_cold(k,target,sw):
    wave=[];cold=[];ck=[]
    for packet in range(38):
        with np.load(native.pin(bank,f'material-halfstep/linear-heavy-{packet:02}.npz')) as ar:
            names=['sigma','etak','adotoa','mts_dphi_h','mts_dphidot_h','a']
            cols=[ar['keys'].tolist().index(s) for s in names];t=ar['eta'];ix=np.argmin(abs(t[:,None]-target),axis=0)
            assert np.max(abs(t[ix]-target))<3e-13
            wave.append(ar['values'][:,ix][:,:,cols]);ck.extend(ar['k'])
        with np.load(native.pin(bank,f'material-halfstep/linear-cold-{packet:02}.npz')) as ar:
            keys=ar['keys'].tolist();t=ar['eta'];nk=ar['k'];assert np.array_equal(nk,np.array(ck[-len(nk):]))
            idx=np.searchsorted(t,sw);left=slice(idx-4,idx);right=slice(idx,idx+4)
            vals=ar['values'][:,idx-4:idx+4];assert np.all(ar['good'][:,idx-4:idx+4])
            sig=vals[:,:,keys.index('sigma')]/nk[:,None];phi=vals[:,:,keys.index('etak')]/nk[:,None]-vals[:,:,keys.index('adotoa')]*sig
            pair=np.stack([sig,phi],axis=-1)
            cold.append(make_interp_spline(t[right],pair[:,4:],axis=1,k=3)(sw)-make_interp_spline(t[left],pair[:,:4],axis=1,k=3)(sw))
    assert np.array_equal(ck,k)
    return dict(zip(names,np.concatenate(wave).transpose(2,1,0))),np.concatenate(cold)

def run():
    check('cell-freeze.json');check('incoming-only-freeze.json')
    k,tm,raw=collect();sw=native.switch();target=tm[-2:]
    assert np.max(abs(target-[89.15,89.15625]))<1e-12
    tb=table();wave,cold=resolved_and_cold(k,target,sw);pred=read(ROOT/'forecast.npz');ev=read(ROOT/'event-surface.npz')
    measured={}
    for tag in ('matched','wave'):
        with np.load(parent.pin(parent.INVERSE,tag+'-native-prepared-sources.npz')) as ar:
            times=ar['time'];ix=np.argmin(abs(times[:,None]-target),axis=0)
            assert np.max(abs(times[ix]-target))<1e-12 and ar['keys'].tolist()[2:5:2]==['henergy','hJ']
            measured[tag]=ar['values'][[2,4]][:,ix].transpose(1,2,0)
    observed=measured['matched']-measured['wave'];pinrefs={}
    for key in ['alpha','phi']:
        left=wave['sigma']/k;right=raw['sigma'][:,-2:].T/k
        if key=='phi':
            left=wave['etak']/k-wave['adotoa']*left
            right=raw['etak'][:,-2:].T/k-raw['adotoa'][:,-2:].T*right
        pinrefs[key]=(left,right)
    results={};sensitivity={}
    for name in ('native5','native3','inverse5'):
        mat=read(ROOT/f'cell-{name}-retained_mean.npz');con=read(ROOT/f'cell-{name}-conserved.npz')
        assert np.array_equal(mat['time'],con['time'])
        delta=mat['quad'][1:]-con['quad'][1:]
        own=100*abs(delta-observed)/abs(observed)
        row=dict(quad_relative_pct=own.tolist(),identity={},linear_contrast={},absolute_branch={})
        for branch,code in [('mean',mat),('conserved',con)]:
            row['identity'][branch]={res:float(100*np.max(abs(code[mean]+code[res]-code[direct]))/np.max(abs(code[res]))) for mean,res,direct in [('eb','re','energy'),('jb','rj','current')]}
            row['identity'][branch]['relative_background_mode_spread']=float(np.max(np.ptp(code['background'],axis=1))/np.max(abs(code['background'])))
        for key,(left,right) in pinrefs.items():
            row['linear_contrast'][key]=[stats(a,b) for a,b in zip(mat[key][1:]-con[key][1:],right-left)]
            row['absolute_branch'][key]=dict(mat=[stats(a,b) for a,b in zip(mat[key][1:],right)],con=[stats(a,b) for a,b in zip(con[key][1:],left)])
        if name=='native5':primary=delta
        else:sensitivity[name]=(100*abs(delta-primary)/abs(observed)).tolist()
        results[name]=row
    before,after=[surfaces(tm,raw,ev['measured_switch'],s) for s in (-1,1)]
    incoming=read(ROOT/'incoming-only.npz');small={key:stats(incoming[col],ev[key]) for key,col in [('density','de'),('current','dj'),('alpha','dalpha'),('phi','dphi')]}
    z=lambda side:(side['dgrho']/(2*k)+side['etak'])/side['adotoa']
    reconstruct=lambda side:(z(side)+1.5*side['dgq']/k**2)/k
    direct=stats(reconstruct(after)-reconstruct(before),ev['alpha'])
    cold_tests={key:float(100*np.max(abs(cold[:,idx]))/np.max(abs(ev[key]))) for idx,key in enumerate(['alpha','phi'])}
    put('cell-tests.json',dict(tested_times=target.tolist(),branch_tests=results,sensitivity_vs_native5_pct=sensitivity,incoming_only=small,
                               constraint_replay=direct,cold_apparent_jumps_pct_of_mts=cold_tests))
    for name,row in results.items():print(name,'source error percent range by knot/channel',np.max(row['quad_relative_pct'],axis=1),'moment identity',row['identity']['conserved'])
    print('incoming-only',small['alpha'],'measured constraint',direct,'cold',cold_tests)
if __name__=='__main__':run()
