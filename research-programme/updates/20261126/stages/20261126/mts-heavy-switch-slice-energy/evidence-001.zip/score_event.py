from junction_io import *
def surfaces(tm,raw,target,side,coord='time',num=3,skip=0):
    near=np.where((tm-target.mean())*side>0)[0]
    idx=near[skip:skip+num] if side==1 else near[::-1][skip:skip+num]
    ix=np.broadcast_to(tm[idx],(len(target),num)) if coord=='time' else raw['a'][:,idx]
    x0=target if coord=='time' else raw['mts_match_a'][:,-1]
    weights=np.ones_like(ix)
    for i in range(num):
        for j in range(num):
            if j!=i:weights[:,i]*=(x0-ix[:,j])/(ix[:,i]-ix[:,j])
    assert np.max(abs(weights.sum(1)-1))<1e-9
    return {key:np.sum(val[:,idx]*weights,axis=1) for key,val in raw.items()}
def stats(value,target):
    diff=np.abs(value-target);size=np.abs(target)
    valid=size>0
    ratio=100*diff[valid]/size[valid]
    return dict(peak_target=float(np.max(size)),error_peak_pct=float(100*np.max(diff)/np.max(size)),rms_error_pct=float(100*np.linalg.norm(diff)/np.linalg.norm(size)),worst_individual_pct=float(max(ratio)),miss_individual=int((ratio>.5).sum()),exact_zero_targets=int((~valid).sum()))
def collect():
    vals=[];modes=[]
    for i in range(38):
        with np.load(ROOT/f'matched-event-{i:02}.npz') as ar:
            vals.append(ar['values']);modes.append(ar['k']);tm=ar['eta'];keys=ar['keys'].tolist()
    return np.concatenate(modes),tm,dict(zip(keys,np.concatenate(vals).transpose(2,0,1)))
def run():
    check('cell-freeze.json');check('event-freeze.json')
    pred=read(ROOT/'forecast.npz');k,tm,raw=collect();assert np.array_equal(pred['k'],k)
    tb=table();a=pred['matching_scale'].item();switch=raw['mts_match_tau'][:,-1]
    assert np.all((switch>tm[tm<pred['switch']][-1])&(switch<tm[tm>pred['switch']][0]))
    assert not raw['mts_nonheavy_change'].any()
    rho=tb['matching_density'].item()/a;event={};cols={};sides={}
    for name,num,skip,coordinate in [('three',3,0,'time'),('two',2,0,'time'),('four',4,0,'time'),('farther',3,1,'time'),('same_a',3,0,'scale')]:
        before,after=[surfaces(tm,raw,switch,sign,coordinate,num,skip) for sign in (-1,1)]
        sides[name]=(before,after);left=before;right=after
        alpha=left['sigma']/k;ap=right['sigma']/k;phi=left['etak']/k-left['adotoa']*alpha;pp=right['etak']/k-right['adotoa']*ap
        dz=(right['dgrho']/(2*k)+right['etak'])/right['adotoa']-(left['dgrho']/(2*k)+left['etak'])/left['adotoa']
        values=dict(alpha=ap-alpha,phi=pp-phi,density=right['dgrho']-left['dgrho'],current=right['dgq']-left['dgq'],z=dz)
        b,v,m2=back(tb,a);f=left['mts_dphi_h'];w=left['mts_dphidot_h']
        parts=[bilinear(k,f,w,shift,p,H,b,v,m2) for shift,p,H in [(alpha,phi,left['adotoa']),(ap,pp,right['adotoa'])]]
        values['quadratic']=EJ(parts[1])-EJ(parts[0])
        event[name]=values
        if name=='three':
            layers=dict(trace=-k*dz/a,tf=-k*(right['sigma']-left['sigma'])/a,delta_phi=pp-phi,
                        incoming_phi=phi,incoming_shear=-k*left['sigma']/a,incoming_trace=-k*(left['dgrho']/(2*k)+left['etak'])/(left['adotoa']*a))
            surface=dict(event_scale_relative=float(max(abs(raw['mts_match_a'][:,-1]/a-1))),event_time_spread=float(np.ptp(switch)),a_step_rel=float(max(abs(right['a']/left['a']-1))),hub_step_rel=float(max(abs(right['adotoa']/left['adotoa']-1))),etak_jump_over_peak=float(max(abs(right['etak']-left['etak']))/max(abs(left['etak']))),tf_peak_over_incoming_pct=100*peak(layers['tf'])/peak(layers['incoming_shear']),trace_peak_over_incoming_pct=100*peak(layers['trace'])/peak(layers['incoming_trace']),phi_peak_over_incoming_pct=100*peak(pp-phi)/peak(phi),projection_jump_qE_on_incoming_pct=(100*abs(values['quadratic'][:,0])/abs(EJ(parts[0])[:,0])).tolist(),all_nonheavy_unchanged=not bool(raw['mts_nonheavy_change'].any()))
            cols=dict(jump_qE_components=parts[1]-parts[0],direct_before=parts[0],direct_after_conditional=parts[1],**layers)
    primary=event['three'];denom=pred['Hp'];z0=k*pred['alpha']-1.5*(sides['three'][0]['dgq'])/k**2
    theory={'alpha':pred['da'],'phi':pred['dphi'],'density':pred['dd'],'current':pred['dj'],'z':z0*(pred['H']/denom-1)+pred['dd']/(2*k*denom),'quadratic':EJ(pred['plus'])-EJ(pred['initial'])}
    comparisons={key:stats(theory[key],primary[key]) for key in theory if key!='quadratic'}
    comps={key:stats(rho*raw[src][:,-1],primary[key]) for key,src in [('density','mts_delta_jump'),('current','mts_momentum_jump')]}
    q=primary['quadratic'];relative=100*abs(theory['quadratic']-q)/abs(q)
    convergence={}
    for name in ('two','four','farther','same_a'):
        convergence[name]={key:stats(event[name][key],primary[key])['error_peak_pct'] for key in primary}
    tf_floor=np.max(np.stack([abs(event[key]['alpha']-primary['alpha']) for key in ('two','four','farther','same_a')]),axis=0)*k*k/a
    detected=abs(cols['tf'])>10*np.maximum(tf_floor,np.finfo(float).eps*peak(cols['incoming_shear']))
    alternatives={key:(100*abs((EJ(pred[key])-EJ(pred['initial']))-q)/abs(q)).tolist() for key in ('moment_preserving','density_only','current_only','both_same_H')}
    pack('event-surface.npz',k=k,**cols,**primary,tf_floor=tf_floor,detected=detected,measured_switch=switch)
    put('event-scores.json',dict(source_jump_error_pct=relative.tolist(),moment_jumps=comparisons,native_audit=comps,
             tested_extrapolations=convergence,nonzero_tf_above_10x_spread=int(detected.sum()),surface=surface,counterfactual_error_pct=alternatives))
    print('jump',comparisons['alpha'], 'quadratic',relative[0], 'TF',detected.sum(),flush=True)
if __name__=='__main__':run()
