from junction_io import *
def run():
    guard();tb=table()
    freeze('method.json',[ROOT/'PROTOCOL.md',ROOT/'junction_io.py',ROOT/'forecast.py',parent.pin(parent.PREFIX,'native-standard.npz'),native.pin(bank,'exact-phase-extension.npz'),BASE/'condensate-origin-20261003/native-heavy-matching-20261007/native/fortran/MTSTwoField.f90',BASE/'condensate-origin-20261003/native-heavy-matching-20261007/native/fortran/equations.f90'])
    joined=[];mom=[];paths=[];switch=native.switch();a=tb['matching_scale'].item()
    for i in range(38):
        raw=parent.pin(parent.PREFIX,f'legs-standard-{i:02}.npz');src=native.pin(bank,f'material-halfstep/linear-heavy-{i:02}.npz');paths.extend([raw,src])
        with np.load(raw) as ar,np.load(src) as wave:
            assert np.array_equal(ar['k'],wave['k']) and switch==ar['eta'][1]
            joined.append(ar['values'][:,1]);cols=ar['keys'].tolist()
            clock=wave['eta'];take=abs(clock-switch)<.07
            mom.append(make_interp_spline(clock[take],wave['values'][:,take,wave['keys'].tolist().index('dgq')].T,k=5)(switch))
    data=dict(zip(cols,np.concatenate(joined).T));k=data['k'];assert len(k)==782 and np.all(np.diff(k)>0)
    slots=np.argmin(abs(k[:,None]/tb['modes']-1),axis=1);assert np.max(abs(tb['modes'][slots]/k-1))<1e-12
    rho=tb['matching_density'].item()/a;eta=data['etak'];H=data['adotoa'];alpha=data['sigma']/k
    field=data['mts_dphi_h'];rate=data['mts_dphidot_h'];b,v,m2=back(tb,a)
    R=(v*v+m2*b*b)/2;hp=np.sqrt(H*H+(rho-R)/3)
    d1=v*rate+m2*b*field;j1=k*v*field
    d2=rho*tb['matching_delta'][slots];j2=rho*tb['matching_momentum'][slots]
    dd=d2-d1;dj=j2-j1;jtot=np.concatenate(mom)
    z=k*alpha-1.5*jtot/k**2
    def jump(dens,current,newhub):
        return z/k*(H-newhub)/newhub+dens/(2*k*k*newhub)+1.5*current/k**3
    pieces=np.array([jump(dd,0*dj,H),jump(0*dd,dj,H),jump(dd,dj,hp)-jump(dd,dj,H)])
    da=jump(dd,dj,hp);assert np.max(abs(pieces.sum(0)-da))<1e-12*peak(da)
    phi=eta/k-H*alpha;phip=eta/k-hp*(alpha+da)
    def energy(aa,pp,hub):return bilinear(k,field,rate,aa,pp,hub,b,v,m2)
    initial=energy(alpha,phi,H)
    evolved=energy(alpha+da,phip,hp)
    zero=energy(0*alpha,0*phi,H)
    assert np.array_equal(zero,energy(0*alpha,0*phi,hp))
    scenarios={}
    for key,den,cur,hub in [('moment_preserving',0*dd,0*dj,hp),('density_only',dd,0*dj,H),('current_only',0*dd,dj,H),('both_same_H',dd,dj,H)]:
        shift=alpha+jump(den,cur,hub);scenarios[key]=energy(shift,eta/k-hub*shift,hub)
    native_control=read(parent.pin(parent.PREFIX,'native-standard.npz'))['source'][1]
    control=100*abs(EJ(initial)[0]-native_control)/abs(native_control)
    pack('forecast.npz',k=k,switch=switch,matching_scale=a,source_scale=data['a'],H=H,Hp=hp,b=b,v=v,m2=m2,rho=rho,field=field,rate=rate,eta=eta,alpha=alpha,phi=phi,da=da,dphi=phip-phi,alpha_parts=pieces,density=d1,current=j1,dd=dd,dj=dj,initial=initial,plus=evolved,proper_bilinears=zero,parts=PARTS,**scenarios)
    put('forecast.json',dict(switch=switch,scale=a,canonical_scale_rel=float(max(abs(data['a']/a-1))),background_jump_pct=100*(rho/R-1),expansion_jump_pct=float(100*np.mean(hp/H-1)),source_control_pct=control.tolist(),jump=encoded(EJ(evolved)-EJ(initial)),rows=len(k),scale_convention='event a_*; scalar b,v evaluated at that common scale',cold_control='no heavy transition'))
    freeze('forecast-freeze.json',[ROOT/'method.json',ROOT/'forecast.npz',ROOT/'forecast.json',*paths]);print('frozen',control,sha(ROOT/'forecast-freeze.json'))
if __name__=='__main__':run()
