from junction_io import *

def run():
    check('forecast-freeze.json')
    pred=read(ROOT/'forecast.npz');k=pred['k'];sw=pred['switch'].item();a=pred['matching_scale'].item()
    tb=table();idx=np.argmin(abs(k[:,None]/tb['modes']-1),axis=1)
    rho=pred['rho'].item(); energies=rho*tb['matching_delta'][idx];currents=rho*tb['matching_momentum'][idx]
    results=[]
    for packet in range(38):
        with np.load(ROOT/f'matched-event-{packet:02}.npz') as ar:
            cols=ar['keys'].tolist();tm=ar['eta'];ix=np.flatnonzero(tm<sw)[-3:];values=ar['values'][:,ix];mode=ar['k']
            assert not values[:,:,cols.index('mts_match_count')].any()
        def extrap(row):
            scale=row[:,cols.index('a')]
            assert np.all(scale<a)
            return make_interp_spline(scale,row,k=2)(a)
        results.extend(extrap(row) for row in values)
    left=dict(zip(cols,np.array(results).T))
    assert np.allclose(left['k'],k,rtol=2e-14,atol=0)
    de=energies-left['mts_drho_h'];dj=currents-left['mts_q_h'];H=left['adotoa']
    dalpha=de/(2*k*k*H)+1.5*dj/k**3
    pack('incoming-only.npz',de=de,dj=dj,dalpha=dalpha,dphi=-H*dalpha)
    freeze('incoming-only-freeze.json',[ROOT/'incoming_only.py',ROOT/'incoming-only.npz',ROOT/'forecast-freeze.json',ROOT/'event-freeze.json'])
if __name__=='__main__':run()
