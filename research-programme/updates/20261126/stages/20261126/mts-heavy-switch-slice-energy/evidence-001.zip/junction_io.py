from pathlib import Path
from types import SimpleNamespace
import hashlib,sys,json
import numpy as np
from scipy.interpolate import CubicSpline,make_interp_spline
ROOT=Path(__file__).resolve().parent
BASE=ROOT.parent
LAST=BASE/'mts-prepared-source-gravity-photons-90p4-20261126'
def sha(path):
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
assert sha(LAST/'seal.json')=='427ce9fddb4c638e7e7ecdc21910c1912ab26a166b004216e5cc07abba44f248'
assert sha(LAST/'source_pair.py')==json.loads((LAST/'seal.json').read_bytes())['files']['source_pair.py']
sys.path.insert(0,str(LAST))
import source_pair as parent
native=parent.module(parent.PREFIX,'fresh_native');bank=native.BANK
def guard():parent.guard();assert not (ROOT/'STOP-REQUESTED').exists()
def put(name,data):guard();parent.put(ROOT/name,data)
def pack(name,**data):guard();parent.pack(ROOT/name,**data)
def freeze(name,files):guard();parent.receipt(ROOT/name,files)
def check(name):parent.check(ROOT/name)
def read(path):
    with np.load(path) as ar:return {k:ar[k] for k in ar.files}
def table():return read(native.pin(bank,'exact-phase-extension.npz'))
def encoded(z):
    z=np.asarray(z);return np.stack([z.real,z.imag],axis=-1).tolist()
def peak(x):return np.max(np.abs(x),axis=0)
def unpack(tag,key):return parent.pin(parent.INVERSE,tag+key)
def back(table,scale):
    b,v=[CubicSpline(table['heavy_efold'],table[key])(np.log(scale)) for key in ('phi_h','phidot_h')]
    return b,v,(scale*table['heavy_mass_mpc'])**2
def bilinear(k,field,rate,alpha,phi,h,b,v,m2):
    shell=np.array(json.loads(native.es.pin('legs.json').read_bytes())['squared_radii'])
    fg=field+v*alpha;normal=rate-(3*h*v+m2*b)*alpha
    cols={'f':fg,'n':normal,'phi':phi}
    model=SimpleNamespace(nodes=k,shell=shell,first={name:np.atleast_2d(np.asarray(col)).T for name,col in cols.items()})
    mapper=native.es.Project(model);out=[]
    for source in mapper.ops:
        op=native.es.Fast(source,model);prod=op.product
        parts=[.5*prod('n','n'),.5*op.grad('f','f'),.5*m2*prod('f','f'),3*v*prod('phi','n'),-1.5*v*v*prod('phi','phi'),-op.dg('n','f')]
        out.append([np.asarray(val).item() for val in parts])
    return np.array(out)
PARTS=['kinetic','gradient','mass','metric_velocity','metric_squared','current']
def EJ(parts):return np.stack([parts[:,:5].sum(axis=1),parts[:,5]],axis=1)
