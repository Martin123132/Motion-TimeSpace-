from junction_io import *
from photon_forecast import last_pin

def run():
    guard()
    docs=['PROTOCOL.md','DYNAMICS.md','FADE.md','CURRENT-CHANNEL.md','RESULTS.md']
    assert all((ROOT/doc).stat().st_size>100 for doc in docs)
    for root,digest in parent.PINS.items():assert sha(root/'seal.json')==digest
    for name in ('method','forecast-freeze','capture-method','event-freeze','cell-freeze','photon-source-freeze','photon-predictions-freeze','incoming-only-freeze','fade-forecast','current-law-freeze'):
        check(name+'.json')
    for file in ROOT.glob('*.py'):compile(file.read_bytes(),str(file),'exec')
    assert len(list(ROOT.glob('matched-event-*.npz')))==38
    for ar in ROOT.glob('*.npz'):
        with np.load(ar,allow_pickle=False) as data:
            for key in data:
                arr=data[key]
                if arr.dtype.kind in 'fci':assert np.isfinite(arr).all(),(ar,key)
    load=lambda key:json.loads((ROOT/key).read_bytes())
    event=load('event-scores.json');cell=load('cell-tests.json');phot=load('photon-test.json');fade=load('fade-test.json');law=load('current-law-test.json')
    assert event['nonzero_tf_above_10x_spread']==782 and event['surface']['all_nonheavy_unchanged']
    assert np.max(event['source_jump_error_pct'])<.5 and np.shape(event['source_jump_error_pct'])==(5,2)
    assert event['moment_jumps']['alpha']['miss_individual']==100
    assert all(row['miss_individual']==0 for row in cell['incoming_only'].values())
    assert max(cell['cold_apparent_jumps_pct_of_mts'].values())<.000007
    qerr=np.array(cell['branch_tests']['native5']['quad_relative_pct'])
    assert qerr.shape==(2,5,2) and np.argwhere(qerr>.5).tolist()==[[0,0,1]]
    assert cell['branch_tests']['native5']['linear_contrast']['alpha'][0]['error_peak_pct']>.5
    assert len(phot)==8 and len({row['name'] for row in phot})==8
    for row in phot:
        assert row['pass_point5'] and max(row['error_pct_energy_current_joint'])<.5 and min(row['error_pct_energy_current_joint'])>0
        assert 32<row['reference_signed_points']<33 and 32<row['predicted_signed_points']<33
    assert fade['conserved']['switch_above_ten_times_input_and_sampling_spread']==780
    assert law['cases']==36 and law['signs_reproduced']==782 and law['same_incoming']['miss_individual']==0 and law['primary']['miss_individual']==100
    assert max(law['max_algebra_errors'])<4e-14
    for ar in ['prefix/gravity-freeze.json','late/first-cell-photons.npz','late/first-cell-check.json','late/early-direct-vectors.npz','late/photon-primary.npz']:
        last_pin(ar)
    assert not any(path.is_dir() or path.suffix=='.partial' for path in ROOT.iterdir())
    paths=sorted(path for path in ROOT.iterdir() if path.name!='seal.json')
    put('seal.json',dict(files={p.name:sha(p) for p in paths},parents={LAST.name:sha(LAST/'seal.json')},
                      scope='One-sided native moment switch, conditional Hamiltonian source and first-cell photons; smooth mixed stress conservation and required current'))
    sealed=load('seal.json')['files']
    assert len(sealed)==len(paths) and all(sha(ROOT/key)==value for key,value in sealed.items())
    print('Verified',len(sealed),'stage files. Seal',sha(ROOT/'seal.json'))
if __name__=='__main__':run()
