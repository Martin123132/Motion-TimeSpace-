from cell_prediction import bank_inputs
from junction_io import *
from score_event import stats

def predict():
    check('cell-freeze.json')
    pred=read(ROOT/'forecast.npz');k=pred['k'];rho0=pred['matching_scale']*pred['rho'];mass=np.sqrt(pred['m2'])/pred['matching_scale']
    t,data,paths=bank_inputs(pred);arrays={'k':k}
    for name in ('native5','native3','inverse5'):
        fit=make_interp_spline(t[-10:],data[-10:],k=3 if name=='native3' else 5)
        for tag in ('conserved','retained_mean'):
            cell=read(ROOT/f'cell-{name}-{tag}.npz')
            scale=cell['a'];H=cell['H'];tm=cell['time'];jtot=fit(tm)[:,2]+cell['jb']+(cell['rj'] if tag=='conserved' else 0)
            z=k*cell['alpha']-1.5*jtot/k**2
            db=.5*(cell['velocity']**2+(mass*scale*cell['background'])**2)-rho0/scale
            comps=np.stack([cell['re'],3*H*cell['rj']/k,-db*k*z/(3*H)])
            arrays[name+'_'+tag]=comps
            arrays['H_'+name+'_'+tag]=H
            arrays['time']=tm
    pack('fade-requirements.npz',**arrays)
    freeze('fade-forecast.json',[ROOT/'FADE.md',ROOT/'fade_test.py',ROOT/'cell-freeze.json',ROOT/'fade-requirements.npz',*paths])

def run():
    predict();check('fade-forecast.json')
    pred=read(ROOT/'forecast.npz');k=pred['k'];req=read(ROOT/'fade-requirements.npz');ev=read(ROOT/'event-surface.npz')
    incoming=read(ROOT/'incoming-only.npz')
    a=pred['matching_scale'].item();rows={}
    for tag in ('conserved','retained_mean'):
        ref=req['native5_'+tag].sum(0);H=req['H_native5_'+tag]
        measured=-2*k**2*H[0]*ev['alpha']
        controls=[req[name+'_'+tag].sum(0) for name in ('native3','inverse5')]
        uncertainty=np.max(np.stack([abs(alt-ref) for alt in controls]),axis=0)
        numerical=2*k**2*H[0]*ev['tf_floor']*a/k**2
        peaks=np.max(abs(ref),axis=1)
        rows[tag]=dict(D_peak=peaks.tolist(),
            D_rms=np.sqrt(np.mean(ref**2,axis=1)).tolist(),above_ten_times_input_spread=np.sum(abs(ref)>10*np.maximum(uncertainty,8*np.spacing(peaks[:,None])),axis=1).tolist(),
            switch_above_ten_times_input_and_sampling_spread=int(np.sum(abs(ref[0])>10*np.maximum(uncertainty[0],numerical))),
            switch_comparison=stats(ref[0],measured),
            switch_direct_incoming=stats(-(incoming['de']+3*H[0]*incoming['dj']/k),measured),
            single_term_peak_errors_pct=[stats(term[0],measured)['error_peak_pct'] for term in req['native5_'+tag][:2]],
            homogeneous_term_pct_of_D_peak=(100*np.max(abs(req['native5_'+tag][2]),axis=1)/peaks).tolist())
    put('fade-test.json',rows);print(rows['conserved'])
if __name__=='__main__':run()
