from junction_io import *

def last_pin(name):
    path=LAST/name
    assert sha(path)==json.loads((LAST/'seal.json').read_bytes())['files'][name]
    return path

def run():
    check('cell-freeze.json')
    t1=89.15
    pred=read(ROOT/'forecast.npz')
    energy_jump=(EJ(pred['plus'])-EJ(pred['initial']))[0,0]
    reference=read(parent.pin(parent.PREFIX,'native-standard.npz'))
    assert reference['t'][-1]==t1
    common=reference['source'][-1,0]
    sources={};files=[]
    for grid in ('p16','p32'):
        den=[]
        for tag,key in [('full-grid','obs'),('joint','observables')]:
            path=last_pin(f'prefix/{tag}-{grid}-4.npz');files.append(path)
            with np.load(path) as ar:
                hits=np.flatnonzero(abs(ar['t']-t1)<2e-13)
                assert hits.size==1
                den.append(ar[key][hits.item(),1,8])
        dm,dr=den
        sources[grid+':surface']=-energy_jump/(2*dm)
        for name in ('native5','native3','inverse5'):
            def q(tag):
                path=ROOT/f'cell-{name}-{tag}.npz'
                with np.load(path) as ar:
                    assert ar['time'][1]==t1
                    return ar['quad'][1,0,0]
            sources[grid+':'+name]=-(q('retained_mean')-common)/(2*dm)+(q('conserved')-common)/(2*dr)
    pack('photon-amplitudes.npz',names=list(sources),amplitude=list(sources.values()),time=t1)
    freeze('photon-source-freeze.json',[ROOT/'photon_forecast.py',ROOT/'cell-freeze.json',ROOT/'forecast-freeze.json',parent.pin(parent.PREFIX,'native-standard.npz'),ROOT/'photon-amplitudes.npz',*files])
    print('First-cell amplitudes frozen:',[(key,complex(value)) for key,value in sources.items()])

if __name__=='__main__':run()
