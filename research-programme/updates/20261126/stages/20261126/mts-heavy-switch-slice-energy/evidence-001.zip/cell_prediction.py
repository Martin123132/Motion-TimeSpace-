from junction_io import *
from scipy.integrate import solve_ivp
def bank_inputs(pred):
    sw=pred['switch'].item();k=pred['k'];paths=[];pieces=[]
    tb=table()
    for i in range(38):
        path=native.pin(bank,f'material-halfstep/linear-heavy-{i:02}.npz');paths.append(path)
        with np.load(path) as ar:
            t=ar['eta'];keep=(t<sw)&(t>sw-.12);t=t[keep];keys=ar['keys'].tolist()
            cols=['a','grho','dgq','dgrho','mts_dphi_h','mts_dphidot_h'];a,grho,j,e,f,w=ar['values'][:,keep][:,:,[keys.index(s) for s in cols]].transpose(2,1,0)
            b,v,m2=back(tb,a);modes=ar['k'];pieces.append(np.stack([grho-(v*v+m2*b*b)/2,e-v*w-m2*b*f,j-modes*v*f],axis=1))
    data=np.concatenate(pieces,axis=2)
    return t,data,paths
def inverse_fields():
    metric=read(parent.pin(parent.INVERSE,'wave-metric.npz'));k=metric['k'];mass=metric['mass'].item();t=metric['time'];sw=native.switch()
    keep=t<sw
    spl=make_interp_spline(t[keep],metric['metric'][keep,:3],k=5)
    coeff=read(parent.pin(parent.INVERSE,'native-map.npz'))['c'];b,v=metric['background']
    state=np.stack([np.full_like(k,b),np.full_like(k,v),coeff[:,0],coeff[:,1]*mass*metric['metric'][0,0]])
    def rhs(tm,y):
        a,h,force=spl(tm);base,vel,field,rate=y.reshape(4,-1);mm=(mass*a)**2
        return np.stack([vel,-2*h*vel-mm*base,rate,-2*h*rate-(mm+k*k)*field-vel*force]).ravel()
    sol=solve_ivp(rhs,(t[0],sw),state.ravel(),method='DOP853',rtol=1e-12,atol=3e-17,t_eval=[sw],max_step=1/640)
    assert sol.success;return sol.y[:,-1].reshape(4,-1)[2:]
def trial(pred,t,data,tag,degree,field,rate):
    sw=pred['switch'].item();k=pred['k'];a=pred['matching_scale'].item()
    b,v,m2=[pred[key].item() for key in ('b','v','m2')];rho0=pred['rho'].item()*a;mass=np.sqrt(m2)/a
    fit=make_interp_spline(t[-10:],data[-10:],k=degree)
    traj=tag=='retained_mean';solution_times=np.array([sw,89.15,89.15625])
    tb=table();index=np.argmin(abs(k[:,None]/tb['modes']-1),axis=1)
    qbar=rho0/a*np.stack([tb['matching_delta'][index],tb['matching_momentum'][index]])
    exact=np.stack([v*rate+m2*b*field,k*v*field]);res=exact-qbar;unit=np.ones_like(k)
    y0=np.stack([unit*a,unit*b,unit*v,field,rate,pred['eta'],*qbar,*res])
    def rhs(tm,flat,readout=False):
        scale,base,vel,f,w,eta,eb,jb,re,rj=flat.reshape(10,-1)
        mm=(scale*mass)**2;rho=rho0/scale
        other_bg,other_e,other_j=fit(tm)
        H=np.sqrt((other_bg+(rho if traj else (vel*vel+mm*base*base)/2))/3)
        en=other_e+eb+(0 if traj else re);jay=other_j+jb+(0 if traj else rj)
        z=(en/(2*k)+eta)/H;alpha=(z+1.5*jay/k**2)/k;phi=eta/k-H*alpha
        ratio=k*k/mm;cs=ratio/(np.sqrt(1+ratio)+1)**2
        pb=cs*(eb+3*H*jb/k);p=vel*w-mm*base*f;rp=p-pb
        if readout:
            E=vel*w+mm*base*f;J=k*vel*f
            parts=bilinear(k,f,w,alpha,phi,H,base[0],vel[0],mm[0])
            return dict(energy=E,current=J,eb=eb,jb=jb,re=re,rj=rj,alpha=alpha,phi=phi,eta=eta,H=H,a=scale,
                        quad=EJ(parts),parts=parts,field=f,rate=w,background=base,velocity=vel)
        return np.stack([H*scale,vel,-2*H*vel-mm*base,w,-2*H*w-(mm+k*k)*f-vel*k*z,jay/2,
                         -H*(eb+3*pb)-k*jb-rho*k*z,-2*H*jb+k*pb,
                         -H*(re+3*rp)-k*rj-(vel*vel-rho)*k*z,-2*H*rj+k*rp]).ravel()
    ode=solve_ivp(rhs,(sw,solution_times[-1]),y0.ravel(),method='DOP853',rtol=1e-12,atol=1e-18,t_eval=solution_times,max_step=.0004)
    assert ode.success and np.array_equal(ode.y[:,0],y0.ravel())
    out=[rhs(tm,state,True) for tm,state in zip(solution_times,ode.y.T)]
    return {key:np.stack([row[key] for row in out]) for key in out[0]}
def run():
    check('forecast-freeze.json');pred=read(ROOT/'forecast.npz');t,data,paths=bank_inputs(pred)
    f,w=inverse_fields();outfiles=[]
    for name,field,rate,degree in [('native5',pred['field'],pred['rate'],5),('native3',pred['field'],pred['rate'],3),('inverse5',f,w,5)]:
        for tag in ('retained_mean','conserved'):
            res=trial(pred,t,data,tag,degree,field,rate);file=f'cell-{name}-{tag}.npz'
            pack(file,**res,time=[pred['switch'].item(),89.15,89.15625]);outfiles.append(ROOT/file)
    freeze('cell-freeze.json',[ROOT/'forecast-freeze.json',ROOT/'DYNAMICS.md',ROOT/'cell_prediction.py',parent.pin(parent.INVERSE,'wave-metric.npz'),parent.pin(parent.INVERSE,'native-map.npz'),*outfiles,*paths]);print('Both routes frozen; no outgoing data loaded.')
if __name__=='__main__':run()
