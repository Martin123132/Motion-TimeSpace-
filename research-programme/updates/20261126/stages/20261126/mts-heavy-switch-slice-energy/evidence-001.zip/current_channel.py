from junction_io import *
from score_event import stats

def algebra():
    H,k=.29,1.73
    rows=[]
    for z in [-.52,.41]:
        for weight in [.03,.57,1.]:
            for dw in [-.68,.79]:
                for I in [0.,-.21,.13]:
                    b0,b1,p0,p1=1.72,1.83,0.,.45
                    e0,e1,j0,j1,pr0,pr1=.62,.97,-.38,.22,-.12,.09
                    mix=lambda x,y:x+(y-x)*weight
                    br=lambda b,p:-H*(b+3*p)
                    er=lambda b,p,e,j,pr:-H*(e+3*pr)-k*j-(b+p)*k*z
                    jr=lambda j,pr:-2*H*j+k*pr
                    B=mix(b0,b1);pc=-dw*(b1-b0)/(3*H);p=mix(p0,p1)+pc
                    E=mix(e0,e1);J=mix(j0,j1)+I
                    U=(e1-e0)+3*H*(j1-j0)/k-(b1-b0)*k*z/(3*H)
                    pressure=mix(pr0,pr1)+(-dw*(e1-e0)-k*I-pc*k*z)/(3*H)
                    rateI=-(2*H+k*k/(3*H))*I-k*dw*U/(3*H)
                    lhs=[mix(br(b0,p0),br(b1,p1))+dw*(b1-b0),mix(er(b0,p0,e0,j0,pr0),er(b1,p1,e1,j1,pr1))+dw*(e1-e0),mix(jr(j0,pr0),jr(j1,pr1))+dw*(j1-j0)+rateI]
                    rhs=[br(B,p),er(B,p,E,J,pressure),jr(J,pressure)]
                    rows.append(np.abs(np.array(lhs)-rhs))
    err=np.max(rows,axis=0)
    assert max(err)<4e-14
    return dict(cases=len(rows),max_algebra_errors=err.tolist())

def run():
    check('fade-forecast.json');check('incoming-only-freeze.json')
    req=read(ROOT/'fade-requirements.npz');inc=read(ROOT/'incoming-only.npz')
    k=req['k'];H=req['H_native5_conserved'][0];D=req['native5_conserved'][:,0].sum(0)
    primary=-k*D/(3*H);same=k*(inc['de']+3*H*inc['dj']/k)/(3*H)
    damping=2*H+k*k/(3*H)
    pack('current-law.npz',k=k,primary=primary,same_incoming=same,gamma=damping)
    freeze('current-law-freeze.json',[ROOT/'CURRENT-CHANNEL.md',ROOT/'current_channel.py',ROOT/'current-law.npz',ROOT/'fade-forecast.json',ROOT/'incoming-only-freeze.json'])
    ev=read(ROOT/'event-surface.npz');independent=2*k**3*ev['alpha']/3
    checks=algebra()
    checks.update(primary=stats(primary,independent),same_incoming=stats(same,independent),signs_reproduced=int(np.sum(np.sign(same)==np.sign(independent))),wavenumber_range=k[[0,-1]].tolist(),kernel_local_efolding_Mpc=[float(min(1/damping)),float(max(1/damping))],coefficient_range=[float(min(same)),float(max(same))])
    put('current-law-test.json',checks);print(checks)
if __name__=='__main__':run()
