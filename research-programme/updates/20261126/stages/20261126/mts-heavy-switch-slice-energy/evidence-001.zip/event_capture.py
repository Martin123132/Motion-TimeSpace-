from junction_io import *
from unittest.mock import patch
import csv, tempfile, subprocess
cap=native.cap
def collect(model,func):
    assert model=='heavy';guard();pred=read(ROOT/'forecast.npz');k=pred['k'];sw=pred['switch'].item()
    offsets=np.array([-0.0012,-.00055,-.00024,-.00010,-.00004,-.000016,.000016,.00004,.00010,.00024,.00055,.0012])
    targets=np.unique(np.r_[sw+offsets,89.14375,89.15,89.15625])
    with np.load(native.pin(bank,'material-halfstep/forcing-heavy.npz')) as ar:times=np.unique(np.r_[ar['eta'][17:],targets])
    idx=np.searchsorted(times,targets);assert np.array_equal(times[idx],targets)
    spec=native.pin(bank,'exact-phase-extension.npz');ns=cap.diag.native
    params=ns.engine.inherited.params_for(spec,background_boost=8.);params.DoLateRadTruncation=False
    bg=ns.engine.camb.get_background(params);bg.Params.Accuracy.IntTolBoost=6
    extra=['mts_dphi_h','mts_dphidot_h','mts_drho_h','mts_dp_h','mts_q_h','mts_match_count','mts_match_a','mts_match_tau','mts_nonheavy_change','mts_preserved_states','mts_delta_jump','mts_momentum_jump']
    keep=extra+['a','adotoa','sigma','etak','dgq','dgrho','grho','gpres','phi','k']
    names=extra+cap.NAMES
    with cap.pin('capture-heavy.csv').open() as stream:blocks=list(csv.DictReader(stream))
    with patch.object(cap.diag.symbolic,'compile_sympy_to_camb_source_func',return_value=func):
        for num,block in enumerate(blocks):
            guard();begin,end=int(block['first']),int(block['last'])+1;nodes=k[begin:end]
            ks=np.unique(np.r_[nodes,float(block['control']),float(block['hierarchy_cap'])])
            name=f'matched-event-{num:02}.npz'
            if not (ROOT/name).exists():
                raw=bg.get_time_evolution(ks,times,vars=extra+[cap.Dummy(x) for x in cap.NAMES],lAccuracyBoost=4)[np.searchsorted(ks,nodes)][:,idx]
                small=raw[:,:,[names.index(key) for key in keep]]
                assert np.isfinite(small).all() and np.allclose(small[:,:,-1],nodes[:,None],rtol=1e-13,atol=0)
                pack(name,eta=targets,keys=keep,values=small,k=nodes,forecast=sha(ROOT/'forecast-freeze.json'))
            with np.load(ROOT/name) as ar:
                assert np.array_equal(ar['k'],nodes) and np.array_equal(ar['eta'],targets) and ar['forecast'].item()==sha(ROOT/'forecast-freeze.json')
                count=ar['values'][:,:,keep.index('mts_match_count')]
                assert (count[:,targets<sw]==0).all() and (count[:,targets>sw]==1).all(),(num,count.min(0),count.max(0))
                assert not ar['values'][:,:,keep.index('mts_nonheavy_change')].any()
            if num%8==0:print('matched event packet',num+1,'of',len(blocks),flush=True)
    freeze('event-freeze.json',[ROOT/'capture-method.json',ROOT/'readout.f90',*[ROOT/f'matched-event-{i:02}.npz' for i in range(len(blocks))]])
if __name__=='__main__':
    if sys.argv[1:2]==['--child']:
        with patch.object(cap.driver,'HERE',ROOT),patch.object(cap.driver,'NAMES',cap.NAMES),patch.object(cap.driver,'run',collect),patch.object(cap.driver,'save',lambda name,data:parent.save(ROOT/name,data)):cap.driver.main()
    else:
        check('forecast-freeze.json')
        freeze('capture-method.json',[ROOT/'forecast-freeze.json',ROOT/'event_capture.py',parent.pin(parent.PREFIX,'fresh_native.py')])
        with tempfile.TemporaryDirectory(dir=ROOT,prefix='reader-') as tmp:subprocess.run([sys.executable,'-u','-B',__file__,'--child',tmp,'heavy'],check=True)
