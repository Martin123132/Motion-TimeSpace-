from work_io import *
from project90 import modules
from scipy.interpolate import make_interp_spline,CubicSpline
from scipy.integrate import solve_ivp
from scipy.linalg import solve_banded

def forces(grid):
    with np.load(ROOT/f'work-matched-{grid}.npz') as m,np.load(ROOT/f'work-wave-{grid}.npz') as w:
        t=m['t'];kk=m['kk'].item();assert np.array_equal(t,w['t']) and kk==w['kk']
        bases=[];pop=[];known=[]
        for ar in (m,w):
            h,d=ar['env'][:,:2].real.T;hd=make_interp_spline(t,h,k=5)(t,1)
            bases.append(np.column_stack((-1/(2*d),-1.5*h/(kk*d),-1.5*hd/(kk*d)-1/(2*kk))))
            pop.append(np.column_stack((ar['rates'][1,:,3,:],ar['values'][:,3,1])))
            known.append(ar['terms'][1,:,3])
        target=known[0]-known[1]
    mat=prior.sealed(prior.EXT,'material/forcing-heavy.npz');wave=oldio.pin(oldio.PAD,'material-halfstep/forcing-heavy.npz')
    with np.load(wave) as ar:
        names=list(ar['keys']);spl=make_interp_spline(np.log(ar['eta']),ar['values'][[names.index('henergy'),names.index('hJ')],:,0].T,k=5)
        shared=np.column_stack((spl(np.log(t),1)/t[:,None],spl(np.log(t))[:,1]))
    lb,ld=(bases[0]+bases[1])/2,bases[0]-bases[1]
    xb,xd=(pop[0]+pop[1])/2,pop[0]-pop[1]
    row=np.column_stack((lb*xd,ld*(xb-shared),ld*shared))
    replay=err(row.sum(1),target)
    background={}
    for idx,path in enumerate((mat,wave)):
        matched=idx==0
        with np.load(path) as ar:
            names=ar['bgkeys'].tolist();src=make_interp_spline(np.log(ar['eta']),ar['background'].T,k=5)
        dt=src(np.log(t),1)/t[:,None];b=dict(zip(names,src(np.log(t)).T));h=b['h'];hp=dt[:,names.index('h')]
        with np.load(ROOT/f'work-{"matched" if matched else "wave"}-{grid}.npz') as ar:d=ar['env'][:,1].real
        br=kk-d+3*(h**2-hp);br_acc=kk-d+3*(h**2-b['hp'])
        out=dict(normalized_bracket_pct=100*np.max(abs(br))/np.max(abs(d-kk)),Hprime_vs_tabulated_hp_pct=err(hp,b['hp']),acceleration_bracket_shift_pct_of_DminusK=100*np.max(abs(br-br_acc))/np.max(abs(d-kk)))
        if matched:
            with np.load(pin(f'oscillator-{grid}-4.npz')) as ar:
                mass=np.sqrt(ar['mass2'][0])/ar['a'][0];rho=ar['rho0'].item()/b['a']
                start=[ar['field'][0],ar['velocity'][0]];end=[ar['field'][1],ar['velocity'][1]]
            def ode(at,y):
                bg=src(np.log(at));return (y[1],-2*bg[names.index('h')]*y[1]-(mass*bg[names.index('a')])**2*y[0])
            sol=solve_ivp(ode,(t[0],t[-1]),start,rtol=2e-12,atol=[1e-16,1e-15],max_step=.0009,method='DOP853',t_eval=t)
            assert sol.success
            prediction=-1.5*(sol.y[1]**2-rho)
            out.update(oscillator_exit_pct=err(sol.y[:,-1],np.asarray(end)),bracket_vs_kinetic_minus_mean_pct=err(prediction,br),remainder_pct_of_DminusK=100*np.max(abs(br-prediction))/np.max(abs(d-kk)),signed_correlation=float(np.vdot(prediction,br).real/np.linalg.norm(prediction)/np.linalg.norm(br)))
        background['matched' if matched else 'wave']=out
    pack(f'heavy-budget-{grid}.npz',t=t,terms=row,known=target)
    return replay,background

def run():
    check('projection-freeze.json')
    freeze('heavy-method.json',['HEAVY-TEST.md','heavy_split.py','projection-freeze.json','work-score.json'])
    checks={}
    for grid in ('p16','p32'):
        test,bg=forces(grid);checks[grid]=dict(replay_pct=test,background=bg)
    put('heavy-input-checks.json',checks)
    freeze('heavy-input-freeze.json',['heavy-method.json','heavy-input-checks.json','heavy-budget-p16.npz','heavy-budget-p32.npz'])

def project():
    check('heavy-input-freeze.json')
    ph=modules();proj=ph.proj;gate=ph.gate
    scale,eta,medium,peak,weights=proj.measure('heavy')
    with np.load(prior.sealed(prior.EXT,'incident-matched-16.npz')) as ar:k=ar['k'].item()
    with np.load(ph.track(ph.cell89.curve('p32','base'))) as ar:t0=ar['eta']
    count_new=round((END-START)/(t0[-1]-t0[-2]));order,sub,stride=gate.transfer.prior.SETTINGS['primary']
    axis=np.unique(np.r_[proj.base_axis(scale,eta,sub),np.linspace(START,END,count_new+1)[::stride],START,END])
    start,end=np.searchsorted(axis,[START,END]);rates,nodes=proj.coefficients(axis,medium,k);at=nodes[start:end]
    names=[];forces=[]
    for grid in ('p16','p32'):
        with np.load(ROOT/f'heavy-budget-{grid}.npz') as ar:drive=CubicSpline(ar['t'],ar['terms'])(at)
        for idx in range(9):
            pair=np.zeros((*at.shape,2),complex);pair[:,:,0]=drive[:,:,idx];forces.append(pair)
            names.append(grid+':'+('different material state','different weight on mean perturbations','different weight on common source')[idx//3]+'/'+('energy rate','current rate','current')[idx%3])
    drive=np.stack(forces,axis=2);integ=np.diff(axis)[start:end,None,None,None]*np.einsum('st,ntch->nsch',proj.RAD,drive)
    bands=proj.transfer.stages(order);length=bands.shape[-1]//2;nc=len(names)
    state=np.zeros((length,2*nc));right=np.empty((2*length,2*nc),order='F')
    slots=np.full(len(axis),-1);slots[np.searchsorted(axis,eta)]=np.arange(len(eta))
    out=np.zeros((len(eta),nc,2),complex)
    for begin in range(start,len(rates),48):
        guard();stop=min(begin+48,len(rates))
        mats=(rates[begin:stop].reshape(-1,8)@bands.reshape(8,-1)).reshape(-1,11,2*length);mats[:,5]+=1
        for step,mat in enumerate(mats,begin):
            right[::2]=state;right[1::2]=state
            if step<end:
                for row,col,fac in ((0,0,4.),(2,1,4*k/3),(4,1,4*k/3)):
                    force=fac*integ[step-start,:,:,col]
                    right[row:row+2,::2]+=force.real;right[row:row+2,1::2]+=force.imag
            state=solve_banded((5,5),mat,right,check_finite=False)[1::2]
            if slots[step+1]>=0:out[slots[step+1]]=(state[[0,2],::2]+1j*state[[0,2],1::2]).T

    pack('heavy-photons.npz',scale=scale,labels=names,values=out)
    freeze('heavy-projection-freeze.json',['heavy-input-freeze.json','heavy-photons.npz'])
if __name__=='__main__':run();project()
