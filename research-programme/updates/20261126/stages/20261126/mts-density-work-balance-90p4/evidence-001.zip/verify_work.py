from work_io import *

def verify():
    for name in ('method-v2.json','work-freeze.json','companion-freeze.json','projection-method.json','projection-freeze.json','heavy-method.json','heavy-input-freeze.json','heavy-projection-freeze.json'):
        check(name)
    for path in ROOT.glob('*.receipt'):check(path.name)
    assert sha(PARENT/'seal.json')==SEAL
    score=json.loads((ROOT/'work-score.json').read_bytes());heavy=json.loads((ROOT/'heavy-score.json').read_bytes())
    assert score['freeze']==sha(ROOT/'projection-freeze.json') and heavy['freeze']==sha(ROOT/'heavy-projection-freeze.json')
    special=json.loads((ROOT/'heavy-input-checks.json').read_bytes())
    gate=json.loads(pin('scores.json').read_bytes())
    checks=[]
    for grid in ('p16','p32'):
        grp=next(r for r in score['tables'] if r['grid']==grid)
        hgroup=next(r for r in heavy['rows'] if r['grid']==grid)
        original=next(r for r in gate['rows'] if r['grid']==grid and r['sub']==4 and r['stress']=='comp' and r['kind']=='cumulative' and r['setting']=='primary')
        assert max(abs(np.array(original['route_gap_pct'])-grp['gap']['magnitude']))<1e-8
        assert not original['pass_gap'] and score['threshold_pct']==gate['tolerance_pct']==.5
        for tag in ('matched','wave'):
            suffix=tag+'-'+grid
            with np.load(ROOT/('work-'+suffix+'.npz')) as ar,np.load(pin(f'carry-{tag}-{grid}-4.npz')) as original_state:
                assert ar['values'].shape==(len(ar['t']),6,2) and ar['terms'].shape==(2,len(ar['t']),10)
                assert np.array_equal(ar['t'],original_state['t']) and np.isfinite(ar['terms']).all()
                assert np.max(ar['replay_error_pct'])<1e-7 and ar['heavy_current_identity_pct']<1e-7
                estimates=ar['estimate'];local=100*abs(estimates[0]-estimates[1])/max(abs(estimates[1]))
                peak=local.argmax();checks.append(dict(grid=grid,tag=tag,max_method_pct=float(local[peak]),eta_peak=ar['t'][peak],includes_endpoints_pass=bool(max(local)<=.5),interior_max_pct=float(max(local[1:-1])),visible_method_pass=bool(max(grp['methods'][tag]['own_pct'])<=.5)))
                assert max(local[1:-1])<=.5 and max(grp['branches'][tag]['own_pct'])<=.5
        assert grp['pointwise_matched_minus_resolved_pct']<=.5 and max(grp['net_vs_frozen']['own_pct'])<.5
        assert max(grp['methods']['companion identity']['own_pct'])<.5 and max(hgroup['closure_own_pct'])<.5
        assert max(grp['closure']['original_pct'])<1e-5 and special[grid]['background']['matched']['bracket_vs_kinetic_minus_mean_pct']<=.5
        assert grp['native_direct']['magnitude'][2]<original['route_gap_pct'][2]-.5
        total=sum(np.array(row['signed']) for row in hgroup['terms'].values())
        assert np.allclose(total,hgroup['net']['signed'],atol=1e-6)
    put('numerical-checks.json',dict(derivative_order_results=checks,unqualified_pointwise_order_pass=all(r['includes_endpoints_pass'] for r in checks),all_visibility_derivative_order_pass=all(r['visible_method_pass'] for r in checks)))
    print('Source identifications, two grids, full-state links, signed work, visibility norms and honest endpoint flags verified.')
    if '--seal' in sys.argv:
        assert (ROOT/'RESULTS.md').is_file() and not any(f.name.endswith('.partial') or f.is_dir() for f in ROOT.iterdir())
        put('seal.json',dict(files={f.name:sha(f) for f in sorted(ROOT.iterdir()) if f.name!='seal.json'}));print(sha(ROOT/'seal.json'))
if __name__=='__main__':verify()
