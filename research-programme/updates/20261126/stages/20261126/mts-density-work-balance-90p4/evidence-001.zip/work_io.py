from pathlib import Path
import hashlib,json,sys
from io import BytesIO
import numpy as np
from functools import lru_cache
ROOT=Path(__file__).resolve().parent
BASE=ROOT.parent
PARENT=BASE/'mts-carried-gravity-photons-90p4-20261126'
SEAL='9255065ecee560e1933ced73cb9cc0ba3561e6bbfe1259f7c93d7b41c7992680'
def sha(path):
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
assert sha(PARENT/'seal.json')==SEAL
manifest=json.loads((PARENT/'seal.json').read_bytes())['files']
@lru_cache()
def pin(name):
    path=PARENT/name;assert sha(path)==manifest[name],name;return path
sys.path.insert(0,str(PARENT))
for name in ('window_io.py','sources90.py','stepper.py','project90.py'):pin(name)
import window_io as prior
from window_io import START,END,edges,oldio
def guard():
    prior.guard();assert not (ROOT/'STOP-REQUESTED').exists()
def save(name,data):
    guard();path=ROOT/name
    if path.exists():assert sha(path)==hashlib.sha256(data).hexdigest(),name
    else:
        temp=path.with_suffix(path.suffix+'.partial')
        with temp.open('xb') as stream:stream.write(data)
        temp.rename(path)
def put(name,obj):save(name,(json.dumps(obj,indent=2,sort_keys=True,allow_nan=False,default=lambda v:v.item())+'\n').encode())
def pack(name,**fields):
    buffer=BytesIO();np.savez_compressed(buffer,**fields);save(name,buffer.getvalue())
def freeze(name,files):put(name,{f:sha(ROOT/f) for f in files})
def check(name):
    for file,h in json.loads((ROOT/name).read_bytes()).items():assert sha(ROOT/file)==h,file
def err(actual,reference):
    norm=np.max(abs(reference));assert norm>0
    return float(100*np.max(abs(actual-reference))/norm)
