from work_io import *
from scipy.interpolate import CubicSpline,make_interp_spline
from unittest.mock import patch
import sources90

GROUPS=['photon-baryon','cold','light scalar','explicit heavy','companion','collisionless']
METRIC=['geometric U','constraint denominator','metric lapse','momentum forcing Fq']
FIELDS=('gx','bd','W','cd','ct','sf','sw','hf','hw','N0','N1')
def features(p,state,unit):
    fields,lag,shape=state[:3];ind=[p.old.IX[k] for k in FIELDS]
    wave=state[3][1] if len(state)>3 else np.zeros(2)
    assert shape.shape==(69,)
    return np.r_[fields[1,ind],wave,unit,lag[1,:,0],lag[1,:,1],shape[:2]]
INDEX={key:idx for idx,key in enumerate((*FIELDS,'mean','density','one'))}
FIRST=INDEX['one']+1
NF=FIRST+156

def physical_weights(src,mem,bank,t):
    bg,force,_,_,_,_,_,den=src.environment(t);kk=src.kk;wave=src.wave
    energy=np.zeros((len(t),NF),complex);cur=energy.copy()
    idx=INDEX
    groups=[]
    def block(name,ev,jv):
        left=energy.copy();right=cur.copy()
        for key,value in ev.items():left[:,idx[key]]=value
        for key,value in jv.items():right[:,idx[key]]=value
        take=np.flatnonzero(np.any(left!=0,axis=0)|np.any(right!=0,axis=0))
        return [name,take,left[:,take],right[:,take]]
    groups.append(block(GROUPS[0],dict(gx=bg['eg'],bd=bg['eb'],one=force['gE']+force['btrace']+force['bKE']),dict(W=bg['eg'],one=force['gJ']+force['bJq'])))
    groups.append(block(GROUPS[1],dict(cd=bg['ec'],one=force['ctrace']+force['cKE']),dict(ct=bg['ec'],one=force['cJq'])))
    for name,tag in zip(GROUPS[2:4],('s','h')):
        groups.append(block(name,{tag+'f':(bg['a']*bg[tag+'m'])**2*bg[tag+'b'],tag+'w':bg[tag+'v'],'one':force[tag+'energy']},{tag+'f':kk*bg[tag+'v'],'one':force[tag+'J']}))
    rho=mem.rho0/bg['a'] if mem is not None else 0
    groups.append(block(GROUPS[4],dict(density=rho),dict(mean=rho,hf=-kk*bg['hv'] if mem is not None else 0,one=-force['hJ'] if mem is not None else 0)))
    _,_,kernel,shape=bank.coeff(t)
    energy[:,idx['N0']]=4*bg['er']+bg['nuE']
    cur[:,idx['N1']]=wave*(4*bg['er']+bg['nuJ']);cur[:,idx['one']]=force['nuJ']
    unit=bg['enu']
    energy[:,FIRST:FIRST+77]=kernel[:,0]*unit[:,None]
    cur[:,FIRST+77:FIRST+154]=kernel[:,1]*(wave*unit[:,None])
    energy[:,-2]=shape[:,0]*unit;cur[:,-1]=shape[:,1]*wave*unit
    used=np.r_[[idx['N0'],idx['N1'],idx['one']],np.arange(FIRST,NF)]
    groups.append([GROUPS[5],used,energy[:,used],cur[:,used]])
    return groups,np.column_stack((bg['h'],den,force['U'],force['Fq']))

def derivatives(t,x,order):
    if not x.size:return x.copy()
    if order==3:return CubicSpline(t,x)(t,1)
    assert order==5
    return make_interp_spline(t,x,k=5)(t,1)

def replay(p,bank,grid,tag):
    namespace=vars(prior).copy()
    def isolated_osc(name,**fields):
        with np.load(pin(name)) as ar:assert set(fields)==set(ar.files) and all(np.array_equal(v,ar[k]) for k,v in fields.items())
    with patch.object(sources90,'pack',isolated_osc):
        src,mem=sources90.setup(p,grid,4,tag,bank)
    code=pin('stepper.py').read_text()
    changes=[
        ('a=rhs(pos,states);b=rhs(pos+1','a=rhs(pos,states);sample(edges[j],states,a);b=rhs(pos+1'),
        ('    if matched:memories[-1]=states[3]','    sample(t[-1],states,rhs(len(clock)-1,states))\n    if matched:memories[-1]=states[3]')]
    for before,after in changes:
        assert code.count(before)==1;code=code.replace(before,after)
    exec(compile(code,str(pin('stepper.py')),'exec'),namespace)
    namespace['guard']=guard;records=[];grads=[];ob=[];times=[]
    def sample(t,y,rhs):
        records.append(features(p,y,1));grads.append(features(p,rhs,0));times.append(t)
    namespace['sample']=sample
    previous=prior.sealed(prior.CARRY,f'carry-{tag}-{grid}-4.npz')
    for segment,(left,right) in enumerate(zip(edges,edges[1:]),1):
        name=f'part-{tag}-{grid}-4-{segment:02}.npz';reference=pin(name)
        def verify(name,**fields):
            with np.load(reference) as ar:
                assert set(fields)==set(ar.files)
                for key in fields:assert np.array_equal(fields[key],ar[key]),(name,key)
                tr=fields['physical_current_phase']
                if mem:mem.append(tr[:,0,1].real,tr[:,:,0])
                ob.append(fields['obs'][int(segment>1):,1])
        namespace['pack']=verify
        if segment>1:
            times.pop();records.pop();grads.pop()
        namespace['evolve'](p,src,mem,bank,grid,4,tag,left,right,previous,name)
        previous=reference
    t=np.array(times);y=np.asarray(records);dy=np.asarray(grads);obs=np.concatenate(ob)
    assert len(t)==len(obs) and np.all(np.diff(t)>0) and y.shape==(len(t),NF)
    with np.load(pin(f'carry-{tag}-{grid}-4.npz')) as ar:assert np.array_equal(t,ar['t']) and np.array_equal(obs,ar['obs'][:,1])
    groups,env=physical_weights(src,mem,bank,t)
    hub,den,us,fq=env.T;kk=src.kk
    calc=lambda coeff,fields:np.einsum('ij,ij->i',coeff,fields,optimize=False)
    terms=[];values=[];rates=[];estimates=[]
    for order in (3,5):
        totals=[];slope=[]
        for _,inds,eco,jco in groups:
            e=calc(eco,y[:,inds]);j=calc(jco,y[:,inds])
            ed=calc(eco,dy[:,inds])+calc(derivatives(t,eco,order),y[:,inds])
            jd=calc(jco,dy[:,inds])+calc(derivatives(t,jco,order),y[:,inds])
            totals.append([e,j]);slope.append([ed,jd])
        vg=np.transpose(totals,(2,0,1));dg=np.transpose(slope,(2,0,1))
        e,j=vg.sum(1).T;hd,dd,ud,_=derivatives(t,env,order).T
        phi=(us-e/2-1.5*hub*j/kk)/den;psi=obs[:,3]
        momentum=j/(2*kk)-hub*psi+fq
        wg=-dg[:,:,0]/(2*den[:,None])-1.5*(hd[:,None]*vg[:,:,1]+hub[:,None]*dg[:,:,1])/(kk*den[:,None])-vg[:,:,1]/(2*kk)
        total=np.column_stack((wg,ud/den,-dd*phi/den,hub*psi,-fq))
        estimates.append(total.sum(axis=1));terms.append(total);rates.append(dg)
        values=vg
    reconstruction=[err(e,obs[:,5]),err(j,obs[:,6]),err(phi,obs[:,0]),err(momentum,obs[:,4])]
    assert max(reconstruction)<1e-7,reconstruction
    hpair=vg[:,3,1]+vg[:,4,1];heavy_check=0.
    if mem:
        rho_mean=mem.rho0/src.flow.bg(np.log(t))[:,src.flow.bgkeys.index('a')]*y[:,INDEX['mean']]
        heavy_check=err(hpair,rho_mean);assert heavy_check<1e-7
    pack(f'work-{tag}-{grid}.npz',t=t,terms=np.asarray(terms),values=values,rates=np.asarray(rates),estimate=estimates,groups=GROUPS+METRIC,orders=[3,5],kk=kk,env=env,replay_error_pct=reconstruction,heavy_current_identity_pct=heavy_check)
    print('Replayed',grid,tag,'readout error %',max(reconstruction),flush=True)

def run():
    freeze('method-v2.json',['PROTOCOL.md','work_io.py','matter_work.py'])
    mod=oldio.prefix();p=mod.import_at(mod.OLD,'partial')
    for grid in ('p16','p32'):
        for tag in ('matched','wave'):
            name=f'work-{tag}-{grid}.npz';receipt=name+'.receipt'
            if not (ROOT/receipt).exists():
                replay(p,p.MatchedBank() if tag=='matched' else p.joint.Bank(),grid,tag)
                freeze(receipt,[name,'method-v2.json'])
            check(receipt)
    freeze('work-freeze.json',['method-v2.json']+sorted(f.name for f in ROOT.glob('work-*.npz'))+sorted(f.name for f in ROOT.glob('*.receipt')))
if __name__=='__main__':run()
