from work_io import *
from scipy.interpolate import make_interp_spline,CubicSpline

def run():
    check('work-freeze.json')
    with np.load(prior.sealed(prior.EXT,'material/forcing-heavy.npz')) as ar:
        scale=make_interp_spline(np.log(ar['eta']),ar['background'][ar['bgkeys'].tolist().index('a')],k=5)
    rows=[]
    for grid in ('p16','p32'):
        with np.load(ROOT/f'work-matched-{grid}.npz') as ar:
            t=ar['t'];kk=ar['kk'].item();h,d,_,_=ar['env'].T;direct=ar['terms'][1,:,4]
            rho_rate=scale(np.log(t),1)/(t*scale(np.log(t)))
            hd=make_interp_spline(t,h,k=5)(t,1);ed,jd=ar['values'][:,4].T
            background=kk-d+3*(h*h-hd)
            pieces=np.stack((rho_rate*(ed+3*h*jd/kk)/(2*d),background*jd/(2*kk*d)),axis=1)
            reduced=pieces.sum(1);discrepancy=err(reduced,direct)
            raw=ar['rates'][1,:,4]
            big=np.max(abs(raw[:,0]/(2*d)))+np.max(abs(1.5*h*raw[:,1]/(kk*d)))
            rows.append(dict(grid=grid,identity_on_own_pct=discrepancy,terms_over_net=float(big/max(abs(reduced))),fractional_background_defect_pct=float(100*max(abs(background))/max(abs(d-kk))),expansion_rate_vs_h_pct=err(rho_rate,h)))
            pack('companion-'+grid+'.npz',t=t,terms=pieces,full=reduced,raw=direct,background_combination=background,rate_a=rho_rate)
    put('companion-checks.json',rows);freeze('companion-freeze.json',['companion_identity.py','work-freeze.json','companion-checks.json','companion-p16.npz','companion-p32.npz'])
    print('Companion cancellation:',rows)
if __name__=='__main__':run()
