from work_io import *
from project90 import modules
from scipy.interpolate import CubicSpline,make_interp_spline
from scipy.linalg import solve_banded

def run():
    check('companion-freeze.json');freeze('projection-method.json',['PROJECTION.md','project_work.py','score_work.py','work-freeze.json','companion-freeze.json'])
    ph=modules();proj=ph.proj;gate=ph.gate
    scale,eta,medium,peak,weights=proj.measure('heavy')
    with np.load(prior.sealed(prior.EXT,'incident-matched-16.npz')) as ar:k=ar['k'].item()
    with np.load(ph.track(ph.cell89.curve('p32','base'))) as ar:t0=ar['eta']
    count_new=round((END-START)/(t0[-1]-t0[-2]));ref_grid=np.linspace(START,END,count_new+1)
    order,sub,stride=gate.transfer.prior.SETTINGS['primary']
    axis=np.unique(np.r_[proj.base_axis(scale,eta,sub),ref_grid[::stride],START,END])
    start,end=np.searchsorted(axis,[START,END]);rates,nodes=proj.coefficients(axis,medium,k);at=nodes[start:end]
    tables={}
    for name in ('native-target','blind-source'):
        with np.load(prior.sealed(prior.EXT,name+'.npz')) as ar:
            tables[name]=make_interp_spline(np.log(ar['eta']),ar['restore'],k=5)
    names=[];forces=[]
    for grid in ('p16','p32'):
        def add(label,rate,lapse=None):
            pair=np.zeros((*at.shape,2),complex);pair[:,:,0]=rate
            if lapse is not None:pair[:,:,1]=lapse
            assert np.isfinite(pair).all();forces.append(pair);names.append(grid+':'+label)
        cache={}
        for tag in ('matched','wave'):
            with np.load(ROOT/f'work-{tag}-{grid}.npz') as ar:
                t=ar['t'];groups=ar['groups'].tolist();work=ar['terms']
                cache[tag]=CubicSpline(t,work[1],axis=0)(at)
                for level,ordername in enumerate(('cubic','quintic')):
                    add(tag+'/'+ordername,CubicSpline(t,ar['estimate'][level])(at))
                if tag=='matched':
                    den=CubicSpline(t,ar['env'][:,1]);log=np.log(at)
                    delta=tables['native-target'](log)-tables['blind-source'](log)
                    delta_rate=(tables['native-target'](log,1)-tables['blind-source'](log,1))/at
                    shift=delta/den(at);dshift=(delta_rate-den(at,1)*shift)/den(at)
                    add('native U direct',dshift,shift)
        for idx,name in enumerate(groups):
            add('difference/'+name,cache['matched'][:,:,idx]-cache['wave'][:,:,idx])
        with np.load(ROOT/f'companion-{grid}.npz') as ar:
            pieces=CubicSpline(ar['t'],ar['terms'])(at)
            add('companion dilution',pieces[:,:,0]);add('companion background',pieces[:,:,1])
    drive=np.stack(forces,axis=2);integ=np.diff(axis)[start:end,None,None,None]*np.einsum('st,ntch->nsch',proj.RAD,drive)
    bands=proj.transfer.stages(order);length=bands.shape[-1]//2;nc=len(names)
    state=np.zeros((length,2*nc));right=np.empty((2*length,2*nc),order='F')
    slots=np.full(len(axis),-1);slots[np.searchsorted(axis,eta)]=np.arange(len(eta))
    out=np.zeros((len(eta),nc,2),complex)
    for begin in range(start,len(rates),48):
        guard();stop=min(begin+48,len(rates))
        mats=(rates[begin:stop].reshape(-1,8)@bands.reshape(8,-1)).reshape(-1,11,2*length);mats[:,5]+=1
        for step,mat in enumerate(mats,begin):
            right[::2]=state;right[1::2]=state
            if step<end:
                for row,col,fac in ((0,0,4.),(2,1,4*k/3),(4,1,4*k/3)):
                    force=fac*integ[step-start,:,:,col]
                    right[row:row+2,::2]+=force.real;right[row:row+2,1::2]+=force.imag
            state=solve_banded((5,5),mat,right,check_finite=False)[1::2]
            if slots[step+1]>=0:out[slots[step+1]]=(state[[0,2],::2]+1j*state[[0,2],1::2]).T

    pack('work-photons.npz',scale=scale,labels=names,values=out)
    freeze('projection-freeze.json',['work-photons.npz','projection-method.json'])
    print('Signed visibility spectra stored before scoring.',flush=True)
if __name__=='__main__':run()
