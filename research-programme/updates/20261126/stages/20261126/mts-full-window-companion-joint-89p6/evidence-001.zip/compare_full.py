import csv
import json
from io import BytesIO

import numpy as np
from partial import ROOT, first, second, third, fourth, parent, record, save, locked, freeze
third.parent("score_second.py")
from score_second import metrics


def calculate(times, readouts, corners, sides, idx):
    cut=np.searchsorted(times,corners)
    assert np.array_equal(times[cut],corners)
    segments=[]
    for part,(lo,hi) in enumerate(zip([0,*cut],[*cut,len(times)-1])):
        obs=readouts[lo:hi+1,idx].copy()
        if part>0:
            obs[0]=sides[part-1,1,idx]
        if part<len(cut):
            obs[-1]=sides[part,0,idx]
        segments.append((times[lo:hi+1],obs))
    return metrics(segments)


def main():
    locked("protocol.json");locked("forecast-freeze.json")
    data=json.loads((ROOT/"results.json").read_bytes())
    rows=[]
    with first.pinned(first.PAIR,"constraint-tests.csv").open() as stream:
        historical=list(csv.DictReader(stream))
    for grid in ("p16","p32"):
        for sub in (2,4):
            suffix=f"{grid}-{sub}.npz"
            sources=[second.source("period-"+suffix),third.parent("second-"+suffix),fourth.parent("third-"+suffix),parent("fourth-"+suffix),ROOT/("partial-"+suffix)]
            pieces=[]
            for src in sources:
                with np.load(src) as packet:
                    pieces.append((packet["t"],packet["obs"]))
                    channels=packet["names"].tolist()
                    routes=packet["routes"].tolist()
            assert all(piece[0][-1]==following[0][0] for piece,following in zip(pieces,pieces[1:]))
            dense_t=np.concatenate([part[0][:-1] for part in pieces[:-1]]+[pieces[-1][0]])
            dense=np.concatenate([part[1][:-1] for part in pieces[:-1]]+[pieces[-1][1]])
            assert np.all(np.diff(dense_t)>0)
            with np.load(first.pinned(first.PAIR,"matched-"+suffix)) as original:
                times=original["t"];corners=original["corners"];original_obs=original["observables"];original_sides=original["seams"]
                assert channels==original["names"].tolist()
            mask=np.searchsorted(dense_t,times)
            assert np.array_equal(dense_t[mask],times) and len(dense_t)==len(times)+2
            assert times[0]==pieces[0][0][0] and times[-1]==89.6 and np.array_equal(corners,[pieces[0][0][-1],pieces[1][0][-1]])
            obs=dense[mask]
            sides=np.stack([np.stack([pieces[i][1][-1],pieces[i+1][1][0]]) for i in (0,1)])
            output=BytesIO()
            np.savez_compressed(output,t=times,obs=obs,seams=sides,corners=corners,names=channels,routes=routes)
            save("full-grid-"+suffix,output.getvalue())
            for idx,label in enumerate(("momentum","density")):
                archived=float(next(r for r in historical if r["mode"]==grid and int(r["sub"])==sub and r["route"]==label)["rate_pct"])
                replay=calculate(times,original_obs,corners,original_sides,idx)
                off=calculate(times,obs,corners,sides,idx+2)
                on=calculate(times,obs,corners,sides,idx)
                r=next(row for row in data["rows"] if (row["grid"],row["sub"],row["route"])==(grid,sub,label))
                assert abs(replay["rate_pct"]-archived)<1e-11
                rows.append(dict(grid=grid,sub=sub,route=label,archived_pct=archived,replay=replay,disabled=off,corrected=on,
                    partial_pct=r["partial"]["rate_pct"],partial_pass=r["partial"]["rate_pass"],
                    period_weighted_full_pct=r["cumulative"]["rate_pct"],
                    segmentation_difference_pp=on["rate_pct"]-r["cumulative"]["rate_pct"],
                    disabled_replay_error_pct=100*abs(off["rate_pct"]-archived)/archived,
                    change_pp=on["rate_pct"]-archived,relative_reduction_pct=100*(1-on["rate_pct"]/archived)))
    record("full-comparison.json",dict(tolerance_pct=.5,rows=rows))
    freeze("comparison-freeze.json",["results.json","forecast-freeze.json","full-comparison.json"]+
           [f"full-grid-{g}-{s}.npz" for g in ("p16","p32") for s in (2,4)])
    for row in rows:
        print(row["grid"],row["sub"],row["route"],row["partial_pct"],row["archived_pct"],row["disabled"]["rate_pct"],row["corrected"]["rate_pct"])


if __name__=="__main__":
    main()
