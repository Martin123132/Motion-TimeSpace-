from partial import ROOT, first, second, third, fourth, parent, locked, record, History, bounds
import json
import numpy as np
from scipy.interpolate import CubicSpline
third.parent("score_second.py")
from score_second import metrics, pct, primitive


def score():
    locked("forecast-freeze.json");locked("protocol.json")
    results=[];controls=[];series={};restarts=[]
    previous_scores=json.loads(parent("results.json").read_bytes())["rows"]
    for grid in ("p16","p32"):
        hist=History(grid)
        for sub in (2,4):
            with np.load(second.source(f"period-{grid}-{sub}.npz")) as one:
                time1=one["t"];obs1=one["obs"]
            with np.load(third.parent(f"second-{grid}-{sub}.npz")) as two:
                time2=two["t"];obs2=two["obs"]
            with np.load(fourth.parent(f"third-{grid}-{sub}.npz")) as three:
                time3=three["t"];obs3=three["obs"];src3=three["traces"]
            with np.load(parent(f"fourth-{grid}-{sub}.npz")) as left, np.load(ROOT/f"partial-{grid}-{sub}.npz") as pack:
                t=pack["t"];old_t=left["t"];on=pack["obs"];old=left["obs"];tr=pack["traces"];pre=left["traces"]
                cut=pack["delay_cut"].item();cutl=pack["cut_left"];cutr=pack["cut_right"]
                assert time1[-1]==time2[0] and time2[-1]==time3[0] and time3[-1]==old_t[0] and old_t[-1]==t[0] and t[0]<cut<t[1] and tuple(t[[0,-1]])==bounds(grid)
                exact=all(np.array_equal(left[lk],pack[rk]) for lk,rk in
                          [("final","entry"),("final_lag","entry_lag"),("final_shape","entry_shape"),("final_memory","entry_memory"),("routes","routes"),("q","q")])
                assert exact and np.array_equal(pack["entry_memory"],tr[0][:,[1,3]]) and np.array_equal(tr[-1][:,[1,3]],pack["final_memory"])
                assert np.array_equal(old[-1,:,2],on[0,:,2]) and np.array_equal(pack["final"][:,12],on[-1,:,2])
                phase=tr[:,0,9].real;old_phase=pre[:,0,9].real;phase3=src3[:,0,9].real
                assert np.all(tr[:,:,9]==phase[:,None]) and np.all(np.diff(phase)>0)
                assert abs(phase[0]-old_phase[-1])<1e-12 and phase3[-1]==old_phase[0]
                past=phase-np.pi
                assert phase3[0]<past[0]<old_phase[0] and np.all((past[1:]>=old_phase[0])&(past[1:]<=old_phase[-1]))
                restarts.append(dict(grid=grid,sub=sub,period_three_tail_duration=cut-t[0],start=t[0],end=t[-1],
                             phase_fraction=float((phase[-1]-phase[0])/np.pi),cut=cut,end_delay_short_of_seam_rad=old_phase[-1]-past[-1],restart_exact=bool(exact)))
            with np.load(first.pinned(first.PAIR,f"matched-{grid}-{sub}.npz")) as saved:
                times=saved["t"];start=np.searchsorted(times,t[0]);stop=np.searchsorted(times,t[-1])
                assert times[start-1]<t[0]<times[start] and t[-1]==times[stop]==times[-1]==89.6
                assert np.array_equal(times[start:stop],t[1:-1])
                last_corner=np.searchsorted(times,saved["corners"][-1])
                post=saved["observables"][last_corner:].copy();post[0]=saved["seams"][-1,1]
                interp=CubicSpline(times[last_corner:],post,axis=0,extrapolate=False)
                target=np.concatenate((interp(t[:1]),post[start-last_corner:]))
                assert np.isfinite(target).all() and target.shape==on[:,:2].shape
            series[grid,sub]=(t,on,tr)
            for idx,label in enumerate(("momentum","density","disabled_momentum","disabled_density")):
                obs=on[:,idx];base=old[:,idx];src=tr[:,idx]
                segments=[(time1,obs1[:,idx]),(time2,obs2[:,idx]),(time3,obs3[:,idx]),(old_t,base),(t,obs)]
                current=metrics(segments[-1:]);cum=metrics(segments);prior=metrics(segments[:-1])
                saved_prior=next(r for r in previous_scores if (r["grid"],r["sub"],r["route"])==(grid,sub,label))["cumulative"]
                assert abs(prior["rate_pct"]-saved_prior["rate_pct"])<1e-12
                independent=100*np.sqrt((saved_prior["power_error"]+current["power_error"])/(saved_prior["power_reference"]+current["power_reference"]))
                assert abs(cum["rate_pct"]-independent)<1e-12
                results.append(dict(grid=grid,sub=sub,route=label,partial=current,cumulative=cum,four_complete_rate_pct=prior["rate_pct"],
                                    curvature_jump_pct=100*abs((obs[0,1]-base[-1,1])/base[-1,2]),
                                    momentum_shadow_jump_pct=100*abs((obs[0,2]-base[-1,2])/base[-1,2])))
                previous=CubicSpline(old_phase,pre[:,idx,0],extrapolate=False)
                tail=CubicSpline(phase3,src3[:,idx,0],extrapolate=False)
                leave=np.r_[tail(past[0]),previous(past[1:])]
                assert np.array_equal(cutl[:,1],cutr[:,1]) and np.array_equal(cutl[:,3],cutr[:,3])
                incoming_area=tail.integrate(past[0],old_phase[0])
                leaving_area=np.r_[0j,incoming_area+previous.antiderivative()(past[1:])-previous.antiderivative()(old_phase[0])]
                wave,avg,dj,de,pres,delay,mrate=src[:,:7].T
                exp_mean=avg[0]+(primitive(phase,wave)-leaving_area)/np.pi
                energy_work=(-1+3*(CubicSpline(t,obs[:,9])(t,1)-obs[:,9]**2)/hist.kk)*dj
                echeck=de[0]+primitive(t,energy_work)-3*(obs[:,9]*dj-obs[0,9]*dj[0])/hist.kk
                pcheck=(mrate-CubicSpline(t,wave)(t,1)+obs[:,9]*dj)/hist.kk
                current=src[:,12]+(src[:,10]*avg if idx<2 else src[:,11])
                checks=dict(grid=grid,sub=sub,route=label,delayed_owner_pct=pct(t,delay-leave,leave),
                            prefix_limit_pct=100*abs((cutl[idx,5]-tail(old_phase[0]))/tail(old_phase[0])),
                            live_limit_pct=100*abs((cutr[idx,5]-pre[0,idx,0])/pre[0,idx,0]),
                            mean_integral_pct=pct(t,avg-exp_mean,avg),current_ledger_pct=pct(t,obs[:,6]-current,obs[:,6]),
                            density_balance_pct=pct(t,de-echeck,de),pressure_balance_pct=pct(t,pres-pcheck,pres),
                            shadow_check_pct=pct(t,obs[:,2]-obs[0,2]-primitive(t,obs[:,4]),obs[:,2]-obs[0,2]))
                if idx>=2:
                    checks["null_replay_pct"]=max(pct(t,obs[:,i]-target[:,idx-2,i],target[:,idx-2,i]) for i in range(obs.shape[-1]))
                controls.append(checks)
    refinements=[]
    for low,high in [(("p16",2),("p16",4)),(("p32",2),("p32",4)),(("p16",4),("p32",4))]:
        t,val,src=series[low];u,control,inp=series[high]
        for idx,label in enumerate(("momentum","density")):
            delta=CubicSpline(t,val[:,idx,1])(t,1)-val[:,idx,4]
            ref=CubicSpline(u,control[:,idx,1])(u,1)-control[:,idx,4]
            vals={}
            for tag,small,fine in [("rate_residual",delta,ref)]+[(label,src[:,idx,k],inp[:,idx,k]) for k,label in [(2,"comp_current"),(3,"comp_density"),(4,"comp_pressure")]]:
                target=CubicSpline(u,fine)(t)
                vals[tag]=pct(t,small-target,target)
            refinements.append(dict(low=list(low),high=list(high),route=label,**vals))
    record("results.json",dict(tolerance_pct=.5,rows=results,restarts=restarts,controls=controls,refinements=refinements))
    for r in results:
        print(r["grid"],r["sub"],r["route"],*(round(r[k]["rate_pct"],7) for k in ("partial","cumulative")))
    print("maximum control", max(v for row in controls for k,v in row.items() if k.endswith("_pct")),flush=True)


if __name__=="__main__":
    score()
