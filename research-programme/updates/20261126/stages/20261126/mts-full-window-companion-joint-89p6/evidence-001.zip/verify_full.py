import ast
import json
from partial import ROOT, FOURTH, PIN, digest, locked, record


def main():
    locked("protocol.json")
    locked("forecast-freeze.json")
    assert digest(FOURTH/"seal.json")==PIN
    data=json.loads((ROOT/"results.json").read_bytes())
    tol=data["tolerance_pct"];assert tol==.5
    ids={(g,s,r) for g in ("p16","p32") for s in (2,4) for r in ("momentum","density","disabled_momentum","disabled_density")}
    assert {(r["grid"],r["sub"],r["route"]) for r in data["rows"]}==ids and len(data["rows"])==len(ids)
    assert len(data["controls"])==16 and len(data["refinements"])==6
    assert len(data["restarts"])==4 and all(r["restart_exact"] for r in data["restarts"])
    for row in data["rows"]:
        assert row["momentum_shadow_jump_pct"]==0
        for segment in ("partial","cumulative"):
            item=row[segment]
            assert item["rate_pass"]==(item["rate_pct"]<=tol)
            assert item["power_reference"]>0 and item["power_error"]>=0
    for row in data["controls"]:
        assert all(0<=val<tol for key,val in row.items() if key.endswith("_pct")),row
    for row in data["refinements"]:
        assert all(0<=row[key]<tol for key in ("rate_residual","comp_density","comp_pressure","comp_current")),row
    locked("comparison-freeze.json")
    direct=json.loads((ROOT/"full-comparison.json").read_bytes())
    assert direct["tolerance_pct"]==tol and len(direct["rows"])==8
    assert len({(r["grid"],r["sub"],r["route"]) for r in direct["rows"]})==8
    assert all(0<r["phase_fraction"]<1 for r in data["restarts"])
    for row in direct["rows"]:
        assert abs(row["replay"]["rate_pct"]-row["archived_pct"])<1e-11
        assert row["disabled_replay_error_pct"]<tol and abs(row["segmentation_difference_pp"])*100/row["corrected"]["rate_pct"]<tol
        for key in ("corrected","disabled"):
            assert row[key]["rate_pass"]==(row[key]["rate_pct"]<=tol)
    for path in ROOT.glob("*.py"):
        ast.parse(path.read_text())
    assert not (ROOT/"__pycache__").exists() and (ROOT/"RESULTS.md").is_file()
    manifest={f.name:digest(f) for f in sorted(ROOT.iterdir()) if f.is_file() and f.name!="seal.json"}
    record("seal.json",dict(files=manifest,fourth_period=PIN))
    print("Verified",len(data["rows"]),"settings;",digest(ROOT/"seal.json"))


if __name__=="__main__":
    main()
