from response_io import *
import ast


def main():
    guard()
    for folder in PINS:assert sha(folder/"seal.json")==PINS[folder]
    for path in ROOT.rglob("*"):
        if path.is_file() and (path.name.endswith((".receipt","-freeze.json","-forecast.json","-method.json")) or path.name in ("method.json","done.json")):
            check(path)
    for path in ROOT.glob("*.py"):ast.parse(path.read_text("utf8"))
    assert not list(ROOT.rglob("*.partial")) and not list(ROOT.rglob("__pycache__"))
    io,*_=setup_modules();rows=obj(ROOT/"scores.json")["rows"]
    realwork=obj(ROOT/"work-scores.json");three=obj(ROOT/"three-scores.json")
    for grid in GRIDS:
        for model in MODELS:
            folder=stage(model,grid);prev=io.sealed(io.CARRY,f"carry-wave-{grid}-4.npz")
            for part in range(1,16):
                name=f"part-wave-{grid}-4-{part:02d}.npz"
                with np.load(folder/name) as ar:
                    assert ar["parent_hash"].item()==sha(prev)
                    assert np.array_equal(ar["t"][[0,-1]],io.edges[part-1:part+1])
                    assert np.max(ar["seam"])<.5 and ar["rhs_identity_pct"].item()<.5
                    assert ar["lag_end"].shape==(2,77,69) and np.isfinite(ar["lag_end"]).all()
                prev=folder/name
            with np.load(folder/f"carry-wave-{grid}-4.npz") as final,np.load(prev) as last:
                for key in ("ordinary_end","lag_end","shape_end"):assert np.array_equal(final[key],last[key])
                assert len(final["t"])==15*8*int(grid[1:])*4+1
                if model=="control":
                    with np.load(pin(HIST,f"carry-wave-{grid}-4.npz")) as old:assert np.array_equal(old["obs"],final["obs"])
            with np.load(ROOT/f"work-vectors-{grid}-{model}.npz") as v:
                truth=v["observed"];scale=np.max(abs(truth));terms=v["contributions"];subtotal=v["base"]
                err=100*np.max(abs(subtotal+terms.sum(1)-truth))/scale
                np.testing.assert_allclose(err,realwork[grid+":"+model][-1]["full_accounting_pct"],rtol=1e-11)
            with np.load(ROOT/f"three-{grid}-{model}-1.npz") as forecast:
                assert np.array_equal(forecast["t"],vtime(grid,model)) and np.isfinite(forecast["constraint"]).all()
                diff=forecast["constraint"]-forecast["constraint"][0]-truth
                np.testing.assert_allclose(100*np.max(abs(diff))/scale,three[grid+":"+model][1]["change_error_pct"],rtol=1e-8)
            for setting in ("primary","time","angle"):
                row=rows[setting+":"+grid+":"+model]
                assert row["full_pass"]==(max(row["cumulative_gap_pct"])<=.5 and max(row["full_launch_pct"])<=.163)
                if model=="control":assert row["archived_replay_pct"]<1e-7
        with np.load(ROOT/f"retarded-{grid}.npz") as ar:assert ar["lag"].shape==(5,77,69) and np.isfinite(ar["values"]).all()
    with np.load(ROOT/"reduced-photon.npz") as ar:assert ar["values"].shape[1:]==(10,2) and np.isfinite(ar["values"]).all()
    assert set(obj(ROOT/"gap-photon-scores.json"))=={grid+":"+model for grid in GRIDS for model in (*MODELS,"delta-primary","delta-fine")}
    files={p.relative_to(ROOT).as_posix():sha(p) for p in ROOT.rglob("*") if p.is_file() and p.name!="seal.json"}
    assert "RESULTS.md" in files
    manifest=dict(files=files,parents={p.name:s for p,s in PINS.items()},scope="Nonlinear-source, affine two-route resolved-wave response on fixed homogeneous coefficients; independent launch and retarded probes. No refit or new sky likelihood.")
    if sys.argv[1:]==["--seal"]:put(ROOT/"seal.json",manifest)
    assert obj(ROOT/"seal.json")==manifest
    print("Verified",len(files),"local files, all 90 tile chains, both independent controls and frozen forecasts;",sha(ROOT/"seal.json"),flush=True)


def vtime(grid,model):
    with np.load(ROOT/f"work-vectors-{grid}-{model}.npz") as v:return v["t"]


if __name__=="__main__":main()
