from response_io import *
from scipy.interpolate import CubicSpline
from scipy.linalg import solve_banded


def run():
    check(ROOT/"gap-forecast.json");io,*_=setup_modules();import project90
    ph=project90.modules();gate=ph.gate;proj=ph.proj
    scale,eta,medium,_,_=proj.measure("heavy");_,vis,weights,_=proj.old.get_media();measure=gate.previous.make_measure(vis,weights)
    with np.load(io.sealed(io.EXT,"incident-matched-16.npz")) as ar:k=float(ar["k"])
    with np.load(ph.track(ph.cell89.curve("p32","base"))) as ar:dt=np.diff(ar["eta"][-2:]).item()
    order,sub,stride=gate.transfer.prior.SETTINGS["primary"];mesh=np.linspace(START,END,round((END-START)/dt)+1)
    axis=np.unique(np.r_[proj.base_axis(scale,eta,sub),mesh[::stride],START,END]);lo,hi=np.searchsorted(axis,[START,END])
    rates,nodes=proj.coefficients(axis,medium,k);at=nodes[lo:hi];bands=proj.transfer.stages(order);length=bands.shape[-1]//2
    record(ROOT/"gap-photon-method.json",[ROOT/"gap-forecast.json",ROOT/"gap_photons.py",pin(HIST,"project90.py")])
    with np.load(io.sealed(io.CARRY,"photon-primary.npz")) as prior:
        labels=prior["labels"].tolist();incoming=prior["hierarchy_at_exit"][:,2*len(labels):];early=prior["cumulative"][eta<=START]
    names=[];drives=[];initial=[];pre=[]
    for grid in GRIDS:
        d,m=[labels.index(grid+"-4-comp_"+r) for r in ("density","momentum")]
        with np.load(pin(HIST,f"carry-matched-{grid}-4.npz")) as ar:
            forcing=ph.source_piece(ar["t"],ar["obs"][:,1],1)(at)-ph.source_piece(ar["t"],ar["obs"][:,0],0)(at)
        with np.load(ROOT/f"retarded-{grid}.npz") as ar:
            for idx,tag in enumerate(ar["labels"].tolist()):
                t=ar["t"];phi,psi=ar["values"][:,idx,:2].T
                source=-np.stack([CubicSpline(t,phi)(at,1),CubicSpline(t,psi)(at)],axis=-1)
                absolute=not tag.startswith("delta")
                names.append(grid+":"+tag);drives.append(source+forcing if absolute else source)
                initial.append(incoming[:,d]-incoming[:,m] if absolute else np.zeros(length,complex))
                pre.append(early[:,d]-early[:,m] if absolute else np.zeros_like(early[:,d]))
    force=np.stack(drives,axis=2);bound=np.stack(initial,axis=1)
    work=np.diff(axis)[lo:hi,None,None,None]*np.einsum("st,ntch->nsch",proj.RAD,force)
    n=len(names);state=np.empty((length,2*n));state[:,::2]=bound.real;state[:,1::2]=bound.imag
    right=np.empty((2*length,2*n),order="F");slots=np.full(len(axis),-1);slots[np.searchsorted(axis,eta)]=np.arange(len(eta))
    values=np.zeros((len(eta),n,2),complex);values[eta<=START]=np.stack(pre,axis=1)
    for first in range(lo,len(rates),48):
        guard();last=min(first+48,len(rates));mats=(rates[first:last].reshape(-1,8)@bands.reshape(8,-1)).reshape(-1,11,2*length);mats[:,5]+=1
        for idx,mat in enumerate(mats,first):
            right[::2]=state;right[1::2]=state
            if idx<hi:
                for row,col,mult in ((0,0,4.),(2,1,4*k/3),(4,1,4*k/3)):
                    change=mult*work[idx-lo,:,:,col];right[row:row+2,::2]+=change.real;right[row:row+2,1::2]+=change.imag
            state=solve_banded((5,5),mat,right,check_finite=False)[1::2]
            if slots[idx+1]>=0:values[slots[idx+1]]=(state[[0,2],::2]+1j*state[[0,2],1::2]).T
    pack(ROOT/"reduced-photon.npz",scale=scale,labels=names,values=values)
    record(ROOT/"reduced-photon-forecast.json",[ROOT/"gap-photon-method.json",ROOT/"reduced-photon.npz"])
    check(ROOT/"score-freeze.json");result={};norm=lambda x:gate.mag(x,measure);ev=lambda v:CubicSpline(scale,v)(vis)
    ref_file=ph.track(ph.cell89.pin("photon-primary.npz"))
    with np.load(ROOT/"visibility-primary.npz") as true,np.load(ref_file) as early:
        actual=ev(true["values"]);labels=true["labels"].tolist();predict=ev(values)
        for idx,tag in enumerate(names):
            grid,model=tag.split(":");differential=model.startswith("delta-")
            key=model[6:] if differential else model
            ref=early["values"][:,early["labels"].tolist().index([grid,"primary"])];small=norm(ev(ref[:,[0,1,2]].sum(1)))
            take=lambda branch:actual[:,labels.index(f"{grid}:{branch}:density")]-actual[:,labels.index(f"{grid}:{branch}:momentum")]
            target=take(key)-(take("control") if differential else 0)
            predicted=predict[:,idx];error=norm(predicted-target)
            result[tag]=dict(forecast_pct_original=(100*norm(predicted)/small).tolist(),actual_pct_original=(100*norm(target)/small).tolist(),
                error_points_original=(100*error/small).tolist(),error_pct_own_vector=(100*error/norm(target)).tolist())
    put(ROOT/"gap-photon-scores.json",result)
    record(ROOT/"gap-freeze.json",[ROOT/"reduced-photon-forecast.json",ROOT/"score-freeze.json",ROOT/"gap-photon-scores.json",ref_file])
    print({key:row["error_pct_own_vector"][2] for key,row in result.items()},flush=True)


if __name__=="__main__":run()
