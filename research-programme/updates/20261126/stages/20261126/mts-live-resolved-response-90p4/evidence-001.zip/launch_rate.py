from absolute_constraint import *
from unittest.mock import patch
from math import factorial


def run():
    io,sources,step,_=setup_modules();pre=io.oldio.prefix();p=pre.import_at(pre.OLD,"partial")
    record(ROOT/"launch-method.json",[ROOT/"constraint-freeze.json",ROOT/"absolute-method.json",ROOT/"launch_rate.py"])
    predictions={};point=np.array([START])
    for grid in GRIDS:
        bank=p.joint.Bank();src,_=sources.setup(p,grid,4,"wave",bank);state=initial(io,grid)
        original=src.flow.q;rr=row(p,src,bank,point)[0];first=native(p,src,bank,point,state)
        bg,D,*_=p.coefficients(src,point);h=bg["h"]
        d=dict(zip(src.flow.bgkeys,(src.flow.bg(np.log(point),1)/point[:,None]).T))
        dp=(3*(d["ec"]+d["eb"]+2*bg["sv"]*d["sv"]+2*bg["hv"]*d["hv"])+4*(d["eg"]+d["er"])+d["nuE"])/2
        beta=1.5*h/src.kk;bp=1.5*d["h"]/src.kk
        for model in ("primary","fine"):
            spec=forecast(model);k,keys,adj=spec;col=[list(src.flow.qkeys).index(key) for key in keys]
            def changed(log):
                v=original(log);v[...,col,0]+=adj(log);return v
            with patch.object(src.flow,"q",changed):second=native(p,src,bank,point,state)
            delta=[b-a for a,b in zip(first,second)]
            test=dot(rr,compress(*delta))
            b,lam,source=inputs(p,src,bank,point,spec)
            q=dict(zip(keys,adj(np.log(point)).T));rates=dict(zip(keys,(adj(np.log(point),1)/point[:,None]).T))
            bd=(rates["U"]-(rates["senergy"]+rates["henergy"])/2-bp*(q["sJ"]+q["hJ"])-beta*(rates["sJ"]+rates["hJ"])-dp*b)/D
            predictions[grid+":"+model]=(source-bd).item()
            error=abs((test-source)/(source-bd)).item()*100
            assert error<.01,error
    pack(ROOT/"launch-rate.npz",labels=list(predictions),coefficients=list(predictions.values()))
    record(ROOT/"launch-forecast.json",[ROOT/"launch-method.json",ROOT/"launch-rate.npz"])
    errors={}
    for label,rate in predictions.items():
        grid,model=label.split(":")
        with np.load(pin(HIST,f"carry-wave-{grid}-4.npz")) as old,np.load(stage(model,grid)/f"carry-wave-{grid}-4.npz") as new:
            diff=new["obs"]-old["obs"];val=diff[:,0,2]-diff[:,0,1];t=new["t"]
            samples=[]
            for stride in (1,2,4,8):
                for size in (4,6):
                    time=t[:size*stride:stride];ref=val[:size*stride:stride];delta=time-time[0];step=delta[1]
                    powers=np.arange(size)[:,None];weights=np.linalg.solve((delta/step)**powers,np.eye(size)[1])
                    fd=weights@(ref-ref[0])/step
                    samples.append(dict(stride=stride,points=size,error_pct=float(100*abs(fd-rate)/abs(rate)),dt=float(step)))
            errors[label]=dict(amplitude=float(abs(rate)),samples=samples)
    put(ROOT/"launch-rate-scores.json",errors)
    record(ROOT/"launch-freeze.json",[ROOT/"launch-forecast.json",ROOT/"launch-rate-scores.json",ROOT/"gravity-forecast.json"])
    print({key:[entry["error_pct"] for entry in row["samples"]] for key,row in errors.items()},flush=True)


if __name__=="__main__":run()
