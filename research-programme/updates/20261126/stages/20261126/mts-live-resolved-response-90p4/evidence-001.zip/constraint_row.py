from constraint import inputs
from response_io import *


def row(p,src,bank,t):
    k=src.wave;kk=k*k;ix=p.old.IX;t=np.asarray(t);log=np.log(t)
    bg,den,we,wj,*_=p.coefficients(src,t)
    deriv=dict(zip(src.flow.bgkeys,(src.flow.bg(log,1)/t[:,None]).T))
    h=bg["h"];beta=1.5*h/kk;bp=1.5*deriv["h"]/kk
    dp=(3*(deriv["ec"]+deriv["eb"]+2*(bg["sv"]*deriv["sv"]+bg["hv"]*deriv["hv"]))+4*(deriv["eg"]+deriv["er"])+deriv["nuE"])/2
    ef=np.zeros_like(we);jf=np.zeros_like(wj)
    for key,val in (("gx",deriv["eg"]),("N0",4*deriv["er"]+deriv["nuE"]),("cd",deriv["ec"]),("bd",deriv["eb"])):ef[:,ix[key]]=val
    for key,val in (("W",deriv["eg"]),("N1",k*(4*deriv["er"]+deriv["nuJ"])),("ct",deriv["ec"])):jf[:,ix[key]]=val
    for tag in ("s","h"):
        mu2=(bg["a"]*bg[tag+"m"])**2
        ef[:,ix[tag+"f"]]=mu2*(deriv[tag+"b"]+2*(deriv["a"]/bg["a"]+deriv[tag+"m"]/bg[tag+"m"])*bg[tag+"b"])
        ef[:,ix[tag+"w"]]=deriv[tag+"v"];jf[:,ix[tag+"f"]]=kk*deriv[tag+"v"]
    co=(we/2+beta[:,None]*wj)/den[:,None]
    cod=(ef/2+bp[:,None]*wj+beta[:,None]*jf-dp[:,None]*co)/den[:,None]
    co[:,ix["geom"]]+=1
    vel,slow,kernel,weight=bank.coeff(t);e0=bg["enu"][:,None]*kernel[:,0,:];j1=bg["enu"][:,None]*k*kernel[:,1,:];s2=bg["enu"][:,None]*kernel[:,2,:]
    es=bg["enu"]*weight[:,0];js=bg["enu"]*k*weight[:,1];ss=bg["enu"]*weight[:,2]
    cl=np.stack((e0/(2*den[:,None]),beta[:,None]*j1/den[:,None],np.zeros_like(e0)),axis=2)
    cs=np.column_stack((es/(2*den),beta*js/den,np.zeros_like(es)))
    cb=bank.bg(log);cbd=bank.bg(log,1)/t[:,None];ah,nh=(cbd/cb).T
    relative=deriv["enu"]/bg["enu"]-nh-2*ah-dp/den
    cld=np.zeros_like(cl);cld[:,:,0]=cl[:,:,0]*(relative[:,None]+(1-vel**2)*ah[:,None]);cld[:,:,1]=cl[:,:,1]*(relative+bp/beta)[:,None]
    csd=np.zeros_like(cs)
    eps=np.hypot(bank.q,(bank.mass*cb[:,0])[:,None]);gap=(bank.mass*cb[:,0,None])**2/(eps+bank.q)
    moment=bank.weight*bank.q**2*gap*bank.spectral/(cb[:,0]**2*cb[:,1])[:,None]
    csd[:,0]=np.sum(moment*(relative[:,None]+(1+vel)*ah[:,None]),axis=1)*bg["enu"]/(2*den)
    mat,bi,bn=p.old.operator(p.old.Wave(src),t,t);mat[:,:13,p.old.QI]+=bi;mat[:,:13,p.old.QN]+=bn
    ordinary=cod+np.einsum("ti,tij->tj",co,mat[:,:,:p.old.DIM]).real
    injected=co[:,1]*(4/3+bg["eb"]/bg["eg"])*kk+co[:,4]*k/3+co[:,6]*kk-co[:,12]*h
    for tag in ("s","h"):
        injected+=co[:,ix[tag+"f"]]*bg[tag+"v"]-co[:,ix[tag+"w"]]*(bg["a"]*bg[tag+"m"])**2*bg[tag+"b"]
    slope=np.sum(cl[:,:,1]*slow,axis=1)*k/3;slip=-np.sum(cl[:,:,1]*slow/vel,axis=1)*k/3
    ordinary[:,p.N_IND[0]]+=slope;ordinary[:,ix["geom"]]+=slope+slip;ordinary[:,p.N_IND[1]]-=np.sum(cl[:,:,0]*slow,axis=1)*k;ordinary[:,p.N_IND[2]]-=2*slope
    ordinary[:,p.old.QI]-=bg["eg"]*slip/kk;ordinary[:,p.old.QN]-=(4*bg["er"]+bg["nuS"])*slip/kk
    shear=(injected+slip)/kk
    lag=cld.copy();lag[:,:,0]+=k*cl[:,:,1]*vel/3;lag[:,:,1]+=-k*cl[:,:,0]*vel+co[:,12,None]*j1/(2*kk)
    lag[:,:,2]+=-2*k*cl[:,:,1]*vel/3+shear[:,None]*s2
    shape=csd.copy();sv=np.sum(cl[:,:,1]*slow*bank.spectral,axis=1)*k/3
    shape[:,0]+=sv+cs[:,1]*k/3;shape[:,1]+=-np.sum(cl[:,:,0]*slow*bank.spectral,axis=1)*k-k*cs[:,0]+co[:,12]*js/(2*kk)
    shape[:,2]+=-2*sv-2*k*cs[:,1]/3+shear*ss
    lam=ordinary[:,ix["geom"]].copy()
    return (co,cl,cs),(cod,cld,csd),(ordinary-lam[:,None]*co,lag-lam[:,None,None]*cl,shape-lam[:,None]*cs),lam


def dot(rows,state):
    return sum(np.sum(a*b,axis=tuple(range(1,a.ndim))) for a,b in zip(rows,state))


def compress(ordinary,lag,shape):return ordinary,lag[:,:,:3],shape[:,:3]


def native(p,src,bank,t,states):
    fields,lag,shape=states;k=src.wave;kk=k*k
    b,D,we,wj,e0,j0,lapse0,us,fq=p.coefficients(src,t)
    solver=p.old.Wave(src);mat,bi,bn=p.old.operator(solver,t,t);mat[:,:13,p.old.QI]+=bi;mat[:,:13,p.old.QN]+=bn
    vel,slow,kernel,w=bank.coeff(t);micro=bank.micro(np.log(t));spectral=bank.sw(np.log(t))
    field_dot=[];lag_dot=[];shape_dot=[]
    for i in range(len(t)):
        bg={key:value[i] for key,value in b.items()};x=fields[i];st=bank.stress(lag[i:i+1],shape[i:i+1],kernel[i],w[i])[0]*bg["enu"];st[1]*=k
        dx=mat[i,:,:-1]@x+mat[i,:,-1]
        slip=st[2]/kk
        for key,c in (("W",(4/3+bg["eb"]/bg["eg"])*kk),("N1",k/3),("ct",kk),("sf",bg["sv"]),("sw",-(bg["a"]*bg["sm"])**2*bg["sb"]),("hf",bg["hv"]),("hw",-(bg["a"]*bg["hm"])**2*bg["hb"]),("geom",-bg["h"])):
            dx[p.old.IX[key]]+=slip*c
        dx[12]+=st[1]/(2*kk)
        psi=x[12]+lapse0[i]+(st[2]-bg["eg"]*x[p.old.QI]-(4*bg["er"]+bg["nuS"])*x[p.old.QN])/kk
        normal=x[p.N_IND].copy();normal[0]+=x[12]
        dl=bank.bin_rhs(lag[i:i+1],shape[i:i+1],normal[None],np.array([psi]),vel[i],slow[i],micro[i])[0]
        field_dot.append(dx);lag_dot.append(dl);shape_dot.append(p.adv(shape[i],k)+spectral[i])
    return np.asarray(field_dot),np.asarray(lag_dot),np.asarray(shape_dot)


def audit(p,src,bank,t):
    rng=np.random.default_rng(63421);random=lambda dims:rng.normal(size=dims)+1j*rng.normal(size=dims)
    state=[random((len(t),*dims)) for dims in [(p.old.DIM,),(77,69),(69,)]];zero=[np.zeros_like(a) for a in state]
    rr,der,bb,lam=row(p,src,bank,t)
    timestep=1e-5
    left=row(p,src,bank,t-timestep)[0];right=row(p,src,bank,t+timestep)[0]
    sd=compress(*state);slope=(dot(right,sd)-dot(left,sd))/(2*timestep)
    f=native(p,src,bank,t,state);f0=native(p,src,bank,t,zero)
    dynamic=dot(rr,compress(*[v-w for v,w in zip(f,f0)]))
    difference=slope+dynamic-lam*dot(rr,sd)-dot(bb,sd)
    metric=lambda x:float(np.max(abs(x)))
    return dict(row_equality_fraction_of_terms=metric(difference)/max(metric(dynamic),metric(slope),metric(lam*dot(rr,sd))),
                row_derivative_fraction=metric(slope-dot(der,sd))/metric(slope))
