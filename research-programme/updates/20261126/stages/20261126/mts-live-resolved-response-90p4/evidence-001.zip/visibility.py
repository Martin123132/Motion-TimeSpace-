from response_io import *
from evolve_response import forecast
from scipy.interpolate import CubicSpline
from scipy.linalg import solve_banded


def decompose(time,old,new,source,k,at):
    wave,keys,adjust=source;assert np.isclose(wave,k,rtol=1e-12)
    delta=dict(zip(keys,adjust(np.log(time)).T))
    kk=k*k;hub=old[:,0,9].real;den=old[:,0,8].real
    assert np.array_equal(new[:,:,8:10],old[:,:,8:10])
    difference=new-old;zero=np.zeros_like(hub)
    def emit(v,rate,lapse):
        return -np.stack((CubicSpline(time,v)(at,1)-CubicSpline(time,rate)(at),CubicSpline(time,lapse)(at)),axis=-1)
    groups={};ed={};jj={};ss={}
    for tag in ("s","h"):
        ed[tag]=delta[tag+"energy"];jj[tag]=delta[tag+"J"];ss[tag]=delta[tag+"shear"]/kk
        val=-(ed[tag]/2+1.5*hub*jj[tag]/kk)/den
        groups[tag+"-explicit"]=emit(val,jj[tag]/(2*kk)-hub*ss[tag],val)
    val=delta["U"]/den
    groups["U"]=emit(val,zero,val);groups["Q"]=emit(zero,hub*delta["Q"]/kk,zero);groups["Fq"]=emit(zero,delta["Fq"],zero)
    de=difference[:,:,10];dj=difference[:,:,11];slip=difference[:,:,12]/kk
    val=-(de[:,1]/2+1.5*hub*dj[:,1]/kk)/den
    groups["77-bin-state"]=emit(val,dj[:,0]/(2*kk)-hub*slip[:,0],val+slip[:,1]-slip[:,0])
    dyn_e=difference[:,:,5]-de-(ed["s"]+ed["h"])[:,None]
    dyn_j=difference[:,:,6]-dj-(jj["s"]+jj["h"])[:,None]
    dyn_s=difference[:,:,3]-difference[:,:,0]-slip-(ss["s"]+ss["h"]-delta["Q"]/kk)[:,None]
    phi_m=difference[:,0,2];val=-(dyn_e[:,1]/2+1.5*hub*dyn_j[:,1]/kk)/den
    groups["matter-and-stored-curvature"]=emit(val,dyn_j[:,0]/(2*kk)-hub*(phi_m+dyn_s[:,0]),val-phi_m+dyn_s[:,1]-dyn_s[:,0])
    return groups


def operate(setting,io,ph):
    proj=ph.proj;gate=ph.gate;scale,eta,medium,_,_=proj.measure("heavy")
    with np.load(io.sealed(io.EXT,"incident-matched-16.npz")) as ar:k=float(ar["k"])
    with np.load(ph.track(ph.cell89.curve("p32","base"))) as ar:dt=np.diff(ar["eta"][-2:]).item()
    order,sub,stride=gate.transfer.prior.SETTINGS[setting];mesh=np.linspace(START,END,round((END-START)/dt)+1)
    axis=np.unique(np.r_[proj.base_axis(scale,eta,sub),mesh[::stride],START,END])
    lo,hi=np.searchsorted(axis,[START,END]);rates,nodes=proj.coefficients(axis,medium,k);at=nodes[lo:hi];zero=np.zeros((*at.shape,2),complex)
    with np.load(io.sealed(io.CARRY,f"photon-{setting}.npz")) as prior:
        labels=prior["labels"].tolist();incoming=prior["hierarchy_at_exit"][:,2*len(labels):];early=prior["cumulative"][eta<=START];assert np.array_equal(prior["scale"],scale)
    drives=[];names=[];boundary=[];start_early=[]
    def add(key,force,idx=None,kick=0j):
        initial=np.zeros(len(incoming),complex) if idx is None else incoming[:,idx].copy();initial[0]+=4*kick
        boundary.append(initial);drives.append(force);names.append(key);start_early.append(idx)
    check_errors={}
    for grid in GRIDS:
        with np.load(pin(HIST,f"carry-matched-{grid}-4.npz")) as ar:matched=ar["obs"];time=ar["t"]
        with np.load(pin(HIST,f"carry-wave-{grid}-4.npz")) as ar:baseline=ar["obs"];assert np.array_equal(time,ar["t"])
        for label in MODELS:
            path=stage(label,grid)/f"carry-wave-{grid}-4.npz"
            with np.load(path) as ar:new=ar["obs"];assert np.array_equal(time,ar["t"])
            individual=[]
            for route,title in enumerate(("momentum","density")):
                force=ph.source_piece(time,matched[:,route],route)(at)-ph.source_piece(time,new[:,route],route)(at)
                idx=labels.index(f"{grid}-4-comp_{title}")
                add(f"{grid}:{label}:{title}",force,idx);add(f"{grid}:{label}:increment-{title}",force)
                individual.append(-ph.source_piece(time,new[:,route]-baseline[:,route],route)(at))
                if label!="control":add(f"{grid}:{label}:entry-{title}",zero,kick=-(new[0,route,0]-baseline[0,route,0]))
            if label!="control" and setting=="primary":
                pieces=decompose(time,baseline,new,forecast(label),k,at);truth=individual[1]-individual[0]
                err=np.max(abs(sum(pieces.values())-truth),axis=(0,1))/np.max(abs(truth),axis=(0,1))
                check_errors[grid+":"+label]=err.tolist()
                for key,force in pieces.items():add(f"{grid}:{label}:split-{key}",force)
    forces=np.stack(drives,axis=2);entry=np.stack(boundary,axis=1);n=len(names)
    integral=np.diff(axis)[lo:hi,None,None,None]*np.einsum("st,ntch->nsch",proj.RAD,forces)
    bands=proj.transfer.stages(order);length=bands.shape[-1]//2;assert length==len(incoming)
    state=np.empty((length,2*n));state[:,::2]=entry.real;state[:,1::2]=entry.imag
    right=np.empty((2*length,2*n),order="F");slots=np.full(len(axis),-1);slots[np.searchsorted(axis,eta)]=np.arange(len(eta))
    values=np.zeros((len(eta),n,2),complex)
    for block,idx in enumerate(start_early):
        if idx is not None:values[eta<=START,block]=early[:,idx]
    for first in range(lo,len(rates),48):
        guard();last=min(first+48,len(rates));mats=(rates[first:last].reshape(-1,8)@bands.reshape(8,-1)).reshape(-1,11,2*length);mats[:,5]+=1
        for it,mat in enumerate(mats,first):
            right[::2]=state;right[1::2]=state
            if it<hi:
                for row,col,mult in ((0,0,4.),(2,1,4*k/3),(4,1,4*k/3)):
                    change=mult*integral[it-lo,:,:,col];right[row:row+2,::2]+=change.real;right[row:row+2,1::2]+=change.imag
            state=solve_banded((5,5),mat,right,check_finite=False)[1::2]
            if slots[it+1]>=0:values[slots[it+1]]=(state[[0,2],::2]+1j*state[[0,2],1::2]).T
    assert np.isfinite(values).all()
    pack(ROOT/f"visibility-{setting}.npz",values=values,scale=scale,labels=names)
    put(ROOT/f"forcing-accounting-{setting}.json",check_errors)
    print("frozen visibility",setting,flush=True)


def main():
    guard();check(ROOT/"gravity-forecast.json");io,*_=setup_modules()
    import project90
    ph=project90.modules()
    record(ROOT/"visibility-method.json",[ROOT/"gravity-forecast.json",ROOT/"TRANSFER.md",ROOT/"visibility.py",pin(HIST,"project90.py")])
    for setting in ph.SETTINGS:operate(setting,io,ph)
    record(ROOT/"visibility-forecast.json",[ROOT/"visibility-method.json",*sorted(ROOT.glob("visibility-*.npz")),*sorted(ROOT.glob("forcing-accounting-*.json"))])


if __name__=="__main__":main()
