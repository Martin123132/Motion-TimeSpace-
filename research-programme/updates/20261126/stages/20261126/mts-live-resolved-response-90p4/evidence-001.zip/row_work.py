from absolute_constraint import *
from contextlib import ExitStack
from unittest.mock import patch
import inspect
from scipy.interpolate import make_interp_spline


def coefficients(p,src,bank,t):
    rr,der,bb,lam=row(p,src,bank,t)
    bg,D,*_=p.coefficients(src,t)
    d=dict(zip(src.flow.bgkeys,(src.flow.bg(np.log(t),1)/t[:,None]).T))
    h=bg["h"];v=bg["hv"];b=bg["hb"];mu2=(bg["a"]*bg["hm"])**2
    Dp=(3*(d["ec"]+d["eb"]+2*bg["sv"]*d["sv"]+2*v*d["hv"])+4*(d["eg"]+d["er"])+d["nuE"])/2
    A=h+lam+Dp/D;T=D-src.kk+3*(d["h"]-h*h)
    rb=d["hb"]-v;rv=d["hv"]+2*h*v+mu2*b;L=d["a"]/bg["a"]+d["hm"]/bg["hm"]-h
    F=np.column_stack((mu2*rb,3*h*rv,2*L*mu2*b,T*v,-A*(mu2*b+3*h*v)))/(2*D[:,None])
    W=np.column_stack((0*rv,rv,0*rv,0*rv,-A*v))/(2*D[:,None])
    cols=bb[0][:,[p.old.IX["hf"],p.old.IX["hw"]]]
    err=np.max(abs(np.column_stack((F.sum(1),W.sum(1)))-cols)/np.maximum(np.max(abs(cols),axis=0),1e-95),axis=0)
    assert np.max(err)<5e-8,err
    boundary,source=forcing(p,src,bank,t)
    return dict(ordinary=bb[0],bins=bb[1],spectral=bb[2],lam=lam,b=boundary,rhs=source,BF=F,BW=W,identities=np.tile(err,(len(t),1)))


def dense(grid,io,p,src,bank):
    path=ROOT/f"dense-row-{grid}.npz";stamp=path.with_suffix(".receipt")
    if stamp.exists():check(stamp);return
    t=np.arange(round(START*5120),round(END*5120)+1)/5120;chunks=[coefficients(p,src,bank,t[i:i+24]) for i in range(0,len(t),24)]
    pack(path,t=t,**{key:np.concatenate([v[key] for v in chunks]) for key in chunks[0]})
    record(stamp,[ROOT/"work-method.json",path])


def replay(grid,model,io,p,sources,step):
    path=ROOT/f"orbit-work-{grid}-{model}.npz";stamp=path.with_suffix(".receipt")
    if stamp.exists():check(stamp);return
    bank=p.joint.Bank();src,_=sources.setup(p,grid,4,"wave",bank)
    dense(grid,io,p,src,bank)
    rowpath=ROOT/f"dense-row-{grid}.npz"
    with np.load(rowpath) as packet:rows=dict(packet.items())
    folder=stage(model,grid);check(folder/"done.json")
    source=forecast(model);wave,keys,adj=source
    forcing0=src.flow.q;col=[list(src.flow.qkeys).index(key) for key in keys]
    def replace(point):
        val=forcing0(point);val[...,col,0]+=adj(point);return val
    src.flow.q=replace
    t=rows["t"];store=np.full((len(t),10),np.nan+1j*np.nan)
    def note(time,fields,lag,shape):
        pos=round((time-START)*5120)
        if abs(time-t[pos])>1e-11:return
        fld=fields[0];hf,hw=fld[10:12];o=rows["ordinary"][pos]*fld
        scalar=rows["BF"][pos]*hf+rows["BW"][pos]*hw
        rest=o.copy();rest[10:12]=0
        values=np.r_[scalar,np.sum(rest),np.sum(rows["bins"][pos]*lag[0,:,:3]),np.sum(rows["spectral"][pos]*shape[:3]),o[10],o[11]]
        if np.all(np.isfinite(store[pos])):np.testing.assert_allclose(store[pos],values,rtol=3e-11,atol=1e-35)
        store[pos]=values
    def verify(name,**series):
        with np.load(folder/name) as ref:
            for key in ("ordinary_end","lag_end","shape_end","obs"):
                assert np.array_equal(ref[key],series[key]),(grid,model,name,key)
    code=inspect.getsource(step.evolve)
    marker="            if observe:\n";assert code.count(marker)==1
    code=code.replace(marker,marker+"                note(float(clock[i]),fields,lag,shape)\n")
    space=dict(step.__dict__,note=note,pack=verify,guard=guard)
    exec(compile(code,"sealed RK solver with read-only work observer","exec"),space)
    previous=io.sealed(io.CARRY,f"carry-wave-{grid}-4.npz")
    for i,(left,right) in enumerate(zip(io.edges,io.edges[1:]),1):
        name=f"part-wave-{grid}-4-{i:02d}.npz"
        space["evolve"](p,src,None,bank,grid,4,"wave",left,right,previous,name)
        previous=folder/name
    assert np.isfinite(store).all()
    pack(path,t=t,work=store,keys=["background_field_eq","background_velocity_eq","scale_clock","enthalpy_gravity","denominator_clock","remaining_ordinary","77_bins","spectral","heavy_F_all","heavy_W_all"])
    record(stamp,[path,rowpath,folder/"done.json",ROOT/"work-method.json"])
    print("replayed every state; resolved constraint work",grid,model,flush=True)


def integrate(t,lam,z0,sources,b):
    anti=CubicSpline(t,lam).antiderivative();factor=np.exp(anti(t)-anti(t[0]))
    primitive=make_interp_spline(t,sources/factor[:,None],k=5).antiderivative()
    parts=factor[:,None]*(primitive(t)-primitive(t[0]))
    return (z0*factor-b),parts


def account():
    io,sources,step,_=setup_modules();pre=io.oldio.prefix();p=pre.import_at(pre.OLD,"partial")
    record(ROOT/"work-method.json",[ROOT/"absolute-freeze.json",ROOT/"HEAVY-ROW.md",ROOT/"row_work.py",pin(HIST,"stepper.py")])
    for grid in GRIDS:
        for model in MODELS:replay(grid,model,io,p,sources,step)
    result={}
    for grid in GRIDS:
        bank=p.joint.Bank();src,_=sources.setup(p,grid,4,"wave",bank)
        with np.load(ROOT/f"dense-row-{grid}.npz") as ar:t=ar["t"];lam=ar["lam"];b=ar["b"];rhs=ar["rhs"]
        for model in MODELS:
            with np.load(ROOT/f"orbit-work-{grid}-{model}.npz") as ar:work=ar["work"];assert np.array_equal(t,ar["t"])
            if model=="control":bb=b;ss=rhs
            else:
                db,ll,df=inputs(p,src,bank,t,forecast(model));bb=b+db;ss=rhs+df
            with np.load(ROOT/f"absolute-{grid}-{model}-1280.npz") as ar:z0=ar["z0"].item()
            with np.load(stage(model,grid)/f"carry-wave-{grid}-4.npz") as ar:
                tim=ar["t"];real=CubicSpline(tim,ar["obs"][:,0,2]-ar["obs"][:,0,1])(t)
            variants=[];scale=np.max(abs(real-real[:1]))
            for stride in (2,1):
                use=slice(None,None,stride);base,parts=integrate(t[use],lam[use],z0,np.column_stack((ss,work))[use],bb[use]);reference=real[use];reference=reference-reference[:1]
                basic=base+parts[:,0];basic-=basic[0];components=parts[:,1:9]
                total=basic+components.sum(1);missing=reference-basic;norm=np.vdot(missing,missing).real
                align=[float(np.vdot(missing,col).real/norm) for col in components.T]
                score=lambda signal:float(100*np.max(abs(signal-reference))/scale)
                variants.append(dict(res=5120//stride,full_accounting_pct=score(total),bare_pct=score(basic),canonical_background_work_only_pct=score(basic+components[:,:2].sum(1)),
                               all_heavy_work_pct=score(basic+components[:,:5].sum(1)),background_work_signed_shares=align,change_scale=float(scale)))
                if stride==1:pack(ROOT/f"work-vectors-{grid}-{model}.npz",t=t,base=basic,contributions=components,observed=reference)
            result[grid+":"+model]=variants
    put(ROOT/"work-scores.json",result)
    record(ROOT/"work-freeze.json",[ROOT/"work-method.json",ROOT/"work-scores.json",*sorted(ROOT.glob("dense-row-*.receipt")),*sorted(ROOT.glob("orbit-work-*.receipt")),*sorted(ROOT.glob("work-vectors-*.npz"))])
    print({key:[row[-1][s] for s in ("bare_pct","canonical_background_work_only_pct","full_accounting_pct")] for key,row in result.items()})


if __name__=="__main__":account()
