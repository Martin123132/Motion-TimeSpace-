from row_work import integrate
from absolute_constraint import *
from unittest.mock import patch


def generate(grid,model,io,p,sources):
    bank=p.joint.Bank();src,_=sources.setup(p,grid,4,"wave",bank)
    wave,keys,adjust=forecast(model);old=src.flow.q;col=[list(src.flow.qkeys).index(key) for key in keys]
    def modified(log):
        vals=old(log);vals[...,col,0]+=adjust(log);return vals
    path=ROOT/f"dense-row-{grid}.npz";check(path.with_suffix(".receipt"))
    with np.load(path) as ar:rows=dict(ar.items())
    t=rows["t"];k=src.wave;kk=k*k
    state=initial(io,grid);zero=np.array([START]);left=compress(*state)
    ro=row(p,src,bank,zero)[0];z0=dot(ro,left).item()
    with patch.object(src.flow,"q",modified):
        slope=compress(*native(p,src,bank,zero,state))
        b,rhs=forcing(p,src,bank,t)
        bg,D,we,wj,e0,j0,slip,U,Fq=p.coefficients(src,t)
        raw=src.flow.q(np.log(t))[:,:,0];force=dict(zip(src.flow.qkeys,raw.T))
    vel,slow,kr,weight=bank.coeff(t);hub=bg["h"];mu2=(bg["a"]*bg["hm"])**2
    cold0=np.array([left[0][0,i] for i in (10,11,12)])
    for order in (0,1):
        dtime=order*(t-START)
        other=left[0]+dtime[:,None]*slope[0];lag=left[1]+dtime[:,None,None]*slope[1];shape=left[2]+dtime[:,None]*slope[2]
        other[:,[10,11,12]]=0
        bin_j=bg["enu"]*k*(np.sum(lag[:,:,1]*kr[:,1,:],axis=1)+weight[:,1]*shape[:,1])
        bin_s=bg["enu"]*(np.sum(lag[:,:,2]*kr[:,2,:],axis=1)+weight[:,2]*shape[:,2])
        ordinary_j=np.sum(other*wj,axis=1)
        slip_state=(bin_s-bg["eg"]*other[:,p.old.QI]-(4*bg["er"]+bg["nuS"])*other[:,p.old.QN])/kk
        lapse0=slip+slip_state
        coeff=np.column_stack((bg["hv"],mu2*bg["hb"],-2*hub,-(kk+mu2),-hub))
        inhom=np.column_stack((bg["hv"]*lapse0+force["hfield"],-mu2*bg["hb"]*lapse0+force["hmoment"],
                                (j0+bin_j+ordinary_j)/(2*kk)-hub*lapse0+Fq))
        one=CubicSpline(t,coeff);two=CubicSpline(t,inhom)
        unit=np.maximum(np.abs(cold0),np.max(abs(inhom),axis=0)*.05);assert (unit>0).all()
        def rates(time,scaled):
            f,w,kap=scaled*unit;v,mb,fr,elastic,minus_h=one(time)
            return (np.array([w+4*v*kap,fr*w+elastic*f+2*mb*kap,v*f/2+minus_h*kap])+two(time))/unit
        sol=solve_ivp(rates,(START,END),cold0/unit,method="DOP853",max_step=1/640,rtol=2e-12,atol=2e-14,t_eval=t)
        assert sol.success
        pred=sol.y.T*unit;other[:,[10,11,12]]=pred
        work=dot((rows["ordinary"],rows["bins"],rows["spectral"]),(other,lag,shape))
        base,parts=integrate(t,rows["lam"],z0,np.column_stack((rhs,work)),b)
        pack(ROOT/f"three-{grid}-{model}-{order}.npz",t=t,fields=pred,constraint=base+parts.sum(1),state_work=parts[:,1])
    print("frozen three-state",grid,model,flush=True)


def run():
    io,sources,step,_=setup_modules();pre=io.oldio.prefix();p=pre.import_at(pre.OLD,"partial")
    record(ROOT/"three-method.json",[ROOT/"THREE-STATE.md",ROOT/"three_state.py",ROOT/"absolute-forecast.json",ROOT/"work-method.json",*sorted(ROOT.glob("dense-row*.receipt"))])
    for grid in GRIDS:
        for model in MODELS:generate(grid,model,io,p,sources)
    record(ROOT/"three-forecast.json",[ROOT/"three-method.json",*sorted(ROOT.glob("three-*.npz"))])


def score():
    check(ROOT/"three-forecast.json");check(ROOT/"gravity-forecast.json");results={}
    for grid in GRIDS:
        for model in MODELS:
            folder=stage(model,grid);endstates=[]
            for idx in range(1,16):
                with np.load(folder/f"part-wave-{grid}-4-{idx:02d}.npz") as ar:endstates.append(ar["ordinary_end"][0,[10,11,12]])
            values=[]
            for order in (0,1):
                with np.load(ROOT/f"three-{grid}-{model}-{order}.npz") as pred,np.load(folder/f"carry-wave-{grid}-4.npz") as ar:
                    time=pred["t"];r=CubicSpline(ar["t"],ar["obs"][:,0,2]-ar["obs"][:,0,1])(time)
                    delta=pred["constraint"]-r;scale=np.max(abs(r-r[0]));mask=np.searchsorted(time,np.arange(1794,1809)/20)
                    fields=pred["fields"][mask];truth=np.stack(endstates)
                    errs=100*np.max(abs(fields-truth),axis=0)/np.max(abs(truth-pred["fields"][:1]),axis=0)
                    values.append(dict(order=order,change_error_pct=float(100*np.max(abs(delta-delta[0]))/scale),
                                       absolute_level_pct=float(100*np.max(abs(delta))/np.max(abs(r))),field_velocity_curvature_endpoint_error_pct=errs.tolist()))
            results[grid+":"+model]=values
    put(ROOT/"three-scores.json",results)
    record(ROOT/"three-freeze.json",[ROOT/"three-forecast.json",ROOT/"gravity-forecast.json",ROOT/"three-scores.json"])
    print(results,flush=True)


if __name__=="__main__":run();score()
