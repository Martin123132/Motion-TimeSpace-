from response_io import *
from scipy.interpolate import make_interp_spline
from unittest.mock import patch
from contextlib import ExitStack


def method():
    guard()
    record(ROOT/"method.json",[ROOT/"PROTOCOL.md",ROOT/"response_io.py",ROOT/"evolve_response.py",HIST/"seal.json",BANK/"seal.json",pin(BANK,"driving-forecast.json"),
                              *[pin(BANK,f"driving-{model}.npz") for model in ("primary","fine","original","cold")],
                              *[pin(HIST,f"carry-{tag}-{grid}-4.npz") for grid in GRIDS for tag in ("wave","matched")]])
    physical=obj(pin(BANK,"scores.json"))["per_branch"];assert all(not physical[key]["failed_shear"] for key in ("primary","fine","cold"))
    assert all(not physical[key]["failed_launch"] for key in ("primary","fine"))


def forecast(model):
    with np.load(pin(BANK,"driving-original.npz")) as orig,np.load(pin(BANK,f"driving-{'original' if model=='control' else model}.npz")) as source:
        assert np.array_equal(orig["t"],source["t"]) and np.array_equal(orig["keys"],source["keys"]) and tuple(orig["coord"][0])==(4,2,1)
        time=orig["t"];keys=orig["keys"].tolist();delta=source["values"][:,0]-orig["values"][:,0];wave=orig["k"][0]
        assert len(keys)==15 and delta.dtype.kind=="c" and not np.any(~np.isfinite(delta))
        spl=make_interp_spline(np.log(time),delta,k=5);spl.extrapolate=False
        if model!="control":
            assert np.any(delta.imag) and np.any(delta.real)
            err=np.max(abs(spl(np.log(time))-delta),axis=0);assert np.all(err<=1e-12*np.max(abs(delta),axis=0))
    return wave,keys,spl


def run(model,grid):
    guard();folder=stage(model,grid);folder.mkdir(parents=True,exist_ok=True)
    io,sources,step,runner=setup_modules();prefix=io.oldio.prefix();p=prefix.import_at(prefix.OLD,"partial")
    wave,keys,adjust=forecast(model);init=io.sealed(io.CARRY,f"carry-wave-{grid}-4.npz")
    with np.load(init) as original:
        assert original["t"][-1]==START and original["lag_end"].shape==(2,77,69)
    record(folder/"method.json",[ROOT/"method.json",init,pin(HIST,"evolve90.py"),pin(HIST,"stepper.py"),pin(HIST,"sources90.py")])
    setup=sources.setup
    def install(*args):
        src,history=setup(*args);assert history is None and abs(src.wave-wave)<1e-12
        original=src.flow.q
        idx=[list(src.flow.qkeys).index(key) for key in keys]
        def modified(point):
            result=original(point)
            result[...,idx,0]+=adjust(point)
            return result
        src.flow.q=modified
        return src,history
    bank=p.joint.Bank()
    with ExitStack() as scope:
        for module in (runner,step):
            for name,value in (("ROOT",folder),("pack",lambda name,**arr:pack(folder/name,**arr)),("guard",guard)):
                scope.enter_context(patch.object(module,name,value))
        scope.enter_context(patch.object(runner,"freeze",lambda name,names:record(folder/name,[folder/n for n in names])))
        scope.enter_context(patch.object(runner,"check",lambda name:check(folder/name)))
        scope.enter_context(patch.object(runner,"setup",install))
        runner.branch(p,grid,4,"wave",bank)
    paths=sorted(folder.glob("*.npz.receipt"));assert len(paths)==15
    record(folder/"done.json",[folder/"method.json",*paths,folder/f"carry-wave-{grid}-4.npz"])


def validate_control(grid):
    folder=stage("control",grid);check(folder/"done.json");stats={}
    for part in range(1,16):
        name=f"part-wave-{grid}-4-{part:02d}.npz"
        with np.load(folder/name) as new,np.load(pin(HIST,name)) as old:
            for key in ("ordinary_end","lag_end","shape_end","obs"):
                truth=old[key];err=np.max(abs(new[key]-truth))/max(np.max(abs(truth)),1e-90)
                stats[key]=max(stats.get(key,0.),float(err))
    assert max(stats.values())<1e-10,stats
    put(folder/"zero-replay.json",stats)


def main():
    method()
    for model in MODELS:
        for grid in GRIDS:
            folder=stage(model,grid)
            if not (folder/"done.json").exists():run(model,grid)
            check(folder/"done.json")
            if model=="control":validate_control(grid)
    record(ROOT/"gravity-forecast.json",[ROOT/"method.json",*[stage(model,grid)/"done.json" for model in MODELS for grid in GRIDS],
                                       *[stage("control",grid)/"zero-replay.json" for grid in GRIDS]])
    print("Frozen all coupled 77-bin histories.",flush=True)


if __name__=="__main__":main()
