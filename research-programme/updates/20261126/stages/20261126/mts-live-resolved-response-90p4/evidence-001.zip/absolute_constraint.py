from constraint_row import *
from constraint import forecast
from scipy.interpolate import CubicSpline
from scipy.integrate import solve_ivp


def forcing(p,src,bank,t):
    bg,D,we,wj,e0,j0,slip,U,Fq=p.coefficients(src,t);beta=1.5*bg["h"]/src.kk
    env=p.old.Wave(src);frame=env.env(t,t);zero=np.zeros((len(t),13),complex)
    field=env.rhs(frame,zero);vel,slow,kernel,weights=bank.coeff(t);micro=bank.micro(np.log(t));sw=bank.sw(np.log(t))
    e_bin=bg["enu"]*(np.sum(kernel[:,0]*micro[:,:,0],axis=1)+weights[:,0]*sw[:,0])
    j_bin=bg["enu"]*src.wave*(np.sum(kernel[:,1]*(micro[:,:,1]-(slow/vel)*src.wave*slip[:,None]/3),axis=1)+weights[:,1]*sw[:,1])
    Rf=field[:,12]+((np.sum(field*we[:,:13],axis=1)+e_bin)/2+beta*(np.sum(field*wj[:,:13],axis=1)+j_bin))/D
    return (U-e0/2-beta*j0)/D,Rf


def initial(io,grid):
    path=io.sealed(io.CARRY,f"carry-wave-{grid}-4.npz")
    with np.load(path) as ar:return [ar["ordinary_end"][0:1],ar["lag_end"][0:1],ar["shape_end"][None]]


def rt(p,src,bank,t):
    groups=[[],[],[]];lambda_list=[];bb=[];rates=[]
    for i in range(0,len(t),24):
        ts=t[i:i+24];r,dr,B,lam=row(p,src,bank,ts)
        for holder,val in zip(groups,B):holder.append(val)
        lambda_list.append(lam);boundary,rhs=forcing(p,src,bank,ts);bb.append(boundary);rates.append(rhs)
    return [np.concatenate(g) for g in groups],np.concatenate(lambda_list),np.concatenate(bb),np.concatenate(rates)


def prep():
    io,s,_,_=setup_modules();pre=io.oldio.prefix();p=pre.import_at(pre.OLD,"partial")
    record(ROOT/"absolute-method.json",[ROOT/"ABSOLUTE.md",ROOT/"absolute_constraint.py",ROOT/"constraint_row.py",ROOT/"constraint-freeze.json"])
    audits={}
    for grid in GRIDS:
        bank=p.joint.Bank();src,_=s.setup(p,grid,4,"wave",bank);state=initial(io,grid)
        checks=audit(p,src,bank,np.linspace(START+.01,END-.01,5))
        assert max(checks.values())<1e-6,checks
        audits[grid]=checks
        rows=row(p,src,bank,np.array([START]))[0]
        z0=dot(rows,compress(*state)).item()
        for res in (640,1280):
            t=np.arange(round(START*res),round(END*res)+1)/res
            B,lam,boundary,source=rt(p,src,bank,t)
            pack(ROOT/f"transverse-{grid}-{res}.npz",t=t,ordinary=B[0],bins=B[1],spectral=B[2],lam=lam,keys=[key for key,idx in sorted(p.old.IX.items(),key=lambda pair:pair[1])])
            lc=CubicSpline(t,lam)
            for model in MODELS:
                if model=="control":b=boundary;f=source
                else:
                    db,ll,df=inputs(p,src,bank,t,forecast(model))
                    assert np.allclose(lam,ll,rtol=1e-10,atol=1e-13)
                    b=boundary+db;f=source+df
                total=CubicSpline(t,f+lam*z0);scale=max(np.max(abs(f+lam*z0)),1e-95)
                sol=solve_ivp(lambda x,y:lc(x)*y+total(x)/scale,(START,END),[0j],rtol=3e-12,atol=1e-15,method="DOP853",max_step=1/640,t_eval=t)
                assert sol.success
                pack(ROOT/f"absolute-{grid}-{model}-{res}.npz",t=t,b=b,z0=z0,prediction=z0+sol.y[0]*scale-b,source=f,lam=lam)
    put(ROOT/"row-check.json",audits)
    record(ROOT/"absolute-forecast.json",[ROOT/"absolute-method.json",ROOT/"row-check.json",*sorted(ROOT.glob("transverse-*.npz")),*sorted(ROOT.glob("absolute-*.npz"))])


def score():
    check(ROOT/"absolute-forecast.json");check(ROOT/"gravity-forecast.json")
    result={};tiles={}
    for grid in GRIDS:
        for model in MODELS:
            folder=stage(model,grid)
            with np.load(folder/f"carry-wave-{grid}-4.npz") as ar:
                tm=ar["t"];val=ar["obs"][:,0,2]-ar["obs"][:,0,1];curve=CubicSpline(tm,val)
            rs=[]
            for res in (640,1280):
                with np.load(ROOT/f"absolute-{grid}-{model}-{res}.npz") as ar:
                    t=ar["t"];ref=curve(t);pred=ar["prediction"];size=np.max(abs(ref-ref[:1]))
                    rs.append(dict(change_pct=float(100*np.max(abs((pred-pred[:1])-(ref-ref[:1])))/size),level_pct=float(100*np.max(abs(pred-ref))/np.max(abs(ref))),initial_pct=float(100*abs(pred[0]-ref[0])/size),actual_change=float(size)))
                    if res==640:low=pred
                    else:rs[-1]["grid_spread_pct"]=float(100*np.max(abs(pred[::2]-low))/size)
            result[grid+":"+model]=rs
            with np.load(ROOT/f"transverse-{grid}-1280.npz") as rows:
                points=[];partnames=("ordinary_end","lag_end","shape_end")
                for idx in range(1,16):
                    with np.load(folder/f"part-wave-{grid}-4-{idx:02d}.npz") as ar:
                        j=np.searchsorted(rows["t"],ar["t"][-1]);assert rows["t"][j]==ar["t"][-1]
                        pieces=(rows["ordinary"][j]*ar[partnames[0]][0],rows["bins"][j]*ar[partnames[1]][0,:,:3],rows["spectral"][j]*ar[partnames[2]][:3])
                        points.append(np.array([np.sum(item) for item in pieces]))
                tiles[grid+":"+model]=np.stack(points)
    pack(ROOT/"boundary-state-work.npz",labels=list(tiles),values=np.stack(list(tiles.values())),groups=["ordinary","77 bins","spectral"])
    put(ROOT/"absolute-scores.json",result)
    record(ROOT/"absolute-freeze.json",[ROOT/"absolute-forecast.json",ROOT/"gravity-forecast.json",ROOT/"boundary-state-work.npz",ROOT/"absolute-scores.json"])
    print(result,flush=True)


if __name__=="__main__":prep();score()
