from response_io import *
from evolve_response import forecast
from scipy.integrate import solve_ivp
from scipy.interpolate import CubicSpline


def inputs(p,src,bank,t,packet):
    _,names,spline=packet;dq=dict(zip(names,spline(np.log(t)).T));k=src.wave;kk=k*k
    bg,den,we,wj,*_=p.coefficients(src,t);h=bg["h"];nuj=4*bg["er"]+bg["nuJ"]
    vel,slow,kernel,weights=bank.coeff(t);kj=kernel[:,1,:];s2=bg["sv"]**2+bg["hv"]**2
    slip=(-dq["Q"]+dq["sshear"]+dq["hshear"])/kk
    energy=dq["senergy"]+dq["henergy"];current=dq["sJ"]+dq["hJ"]
    explicit=(dq["U"]-energy/2-1.5*h*current/kk)/den
    bin_co=lambda value:bg["enu"]*k*np.sum(kj*value,axis=1)
    lag_source=-(slow/vel)*k*slip[:,None]/3
    lag_curvature=(slow-slow/vel)*k/3
    ework=np.zeros(len(t),complex);jfield=np.zeros_like(ework);emetric=np.zeros(len(t))
    for tag in ("s","h"):
        vm=bg[tag+"v"];mb=(bg["a"]*bg[tag+"m"])**2*bg[tag+"b"]
        ework+=mb*dq[tag+"field"]+vm*dq[tag+"moment"]
        jfield+=kk*vm*dq[tag+"field"];emetric+=6*mb*vm
    jwork=jfield+kk*slip*(4*bg["eg"]/3+bg["eb"]+nuj/3+bg["ec"]+s2)+bin_co(lag_source)
    jmetric=kk*(8*bg["eg"]/3+bg["eb"]+2*nuj/3+bg["ec"]+4*s2)+bin_co(lag_curvature)
    coeff=-h+(emetric/2+1.5*h*jmetric/kk)/den
    given=current/(2*kk)-h*slip+dq["Fq"]+(ework/2+1.5*h*jwork/kk)/den
    return explicit,coeff,given


def native_audit(p,src,bank,t,packet):
    explicit,coeff,given=inputs(p,src,bank,t,packet)
    wave,names,spline=packet;kk=wave**2;dq=dict(zip(names,spline(np.log(t)).T))
    bg,den,we,wj,*_=p.coefficients(src,t);h=bg["h"];solver=p.old.Wave(src)
    env=list(solver.env(t,t));env[1]={key:0*val for key,val in env[1].items()};env[2]=0*env[2];env[4]=0*env[4];env[5]=0*env[5]
    x0=np.zeros((len(t),13),complex);native0=solver.rhs(env,x0)
    assert np.max(abs(native0))==0
    cx=x0.copy();cx[:,12]=1
    curvature=solver.rhs(env,cx);delta=list(env);delta[1]={key:dq.get(key,val) for key,val in env[1].items()}
    source=solver.rhs(delta,x0)
    vel,slow,kernel,weights=bank.coeff(t)
    def apply(row,phi,psi):
        bin_cur=[];bin_en=[]
        for idx in range(len(t)):
            lag=np.zeros((1,77,69),complex);shape=np.zeros((1,69),complex);normal=shape.copy();normal[:,0]=phi[idx]
            dl=bank.bin_rhs(lag,shape,normal,np.array([psi[idx]]),vel[idx],slow[idx],np.zeros((77,69)))
            st=bank.stress(dl,shape,kernel[idx],weights[idx])[0]*bg["enu"][idx]
            bin_en.append(st[0]);bin_cur.append(st[1]*wave)
        ed=np.sum(row*we[:,:13],axis=1)+bin_en;jd=np.sum(row*wj[:,:13],axis=1)+bin_cur
        return row[:,12]+(ed/2+1.5*h*jd/kk)/den
    slip=(-dq["Q"]+dq["sshear"]+dq["hshear"])/kk
    lam=apply(curvature,np.ones(len(t)),np.ones(len(t)));srcval=apply(source,np.zeros(len(t)),slip)
    rel=lambda a,b:float(np.max(abs(a-b))/np.max(abs(b)))
    errors=[rel(lam,coeff),rel(srcval,given)];assert max(errors)<1e-9,errors
    return errors


def predict():
    io,sources,_,_=setup_modules();pre=io.oldio.prefix();p=pre.import_at(pre.OLD,"partial")
    record(ROOT/"constraint-method.json",[ROOT/"method.json",ROOT/"CONSTRAINT.md",ROOT/"constraint.py"])
    audits={}
    for grid in GRIDS:
        bank=p.joint.Bank();src,mem=sources.setup(p,grid,4,"wave",bank);assert mem is None
        for model in ("primary","fine"):
            source=forecast(model);audit=native_audit(p,src,bank,np.linspace(START,END,9),source)
            audits[grid+":"+model]=audit
            for density in (320,640):
                t=np.arange(round(START*density),round(END*density)+1)/density;b,lam,force=inputs(p,src,bank,t,source)
                coeff=CubicSpline(t,lam);f=CubicSpline(t,force)
                ref=np.max(abs(force));assert ref>0
                run=solve_ivp(lambda x,y:coeff(x)*y+f(x)/ref,(START,END),[0j],method="DOP853",rtol=1e-11,atol=2e-15,t_eval=t,max_step=1/320)
                assert run.success
                pack(ROOT/f"constraint-{model}-{grid}-{density}.npz",t=t,explicit=b,lam=lam,source=force,z=run.y[0]*ref,prediction=run.y[0]*ref-b)
    put(ROOT/"constraint-coefficients.json",audits)
    record(ROOT/"constraint-forecast.json",[ROOT/"constraint-method.json",ROOT/"constraint-coefficients.json",*sorted(ROOT.glob("constraint-*.npz"))])


def score():
    check(ROOT/"constraint-forecast.json");check(ROOT/"gravity-forecast.json");result={}
    for grid in GRIDS:
        for model in ("primary","fine"):
            with np.load(pin(HIST,f"carry-wave-{grid}-4.npz")) as old,np.load(stage(model,grid)/f"carry-wave-{grid}-4.npz") as fresh:
                tm=old["t"];diff=fresh["obs"]-old["obs"];actual=diff[:,0,2]-diff[:,0,1]
            outs=[]
            for density in (320,640):
                with np.load(ROOT/f"constraint-{model}-{grid}-{density}.npz") as ar:
                    t=ar["t"];ref=CubicSpline(tm,actual)(t);pred=ar["prediction"];scale=np.max(abs(ref-ref[0]))
                    err=np.max(abs((pred-pred[0])-(ref-ref[0])))/scale*100
                    init=100*abs(pred[0]-ref[0])/scale
                    rate=ar["source"][0]-CubicSpline(t,ar["explicit"])(t[0],1)
                    rate_ref=CubicSpline(tm,actual)(tm[0],1)
                    outs.append(dict(density=density,change_error_pct=float(err),initial_error_pct=float(init),launch_rate_pct=float(100*abs(rate-rate_ref)/abs(rate_ref)),
                                     actual_change=float(scale),signed_alignment=float(np.vdot(ref-ref[0],pred-pred[0]).real/np.vdot(ref-ref[0],ref-ref[0]).real),
                                     rms_error_relative=float(np.linalg.norm((pred-pred[0])-(ref-ref[0]))/np.linalg.norm(ref-ref[0]))))
                    if density==320:first=pred.copy()
                    else:outs[-1]["numerical_spread_pct"]=float(100*np.max(abs(first-pred[::2]))/scale)
            result[grid+":"+model]=outs
    put(ROOT/"constraint-scores.json",result)
    record(ROOT/"constraint-freeze.json",[ROOT/"constraint-forecast.json",ROOT/"gravity-forecast.json",ROOT/"constraint-scores.json"])
    print(result,flush=True)


if __name__=="__main__":predict();score()
