from pathlib import Path
import hashlib
import json
import sys
import os
from io import BytesIO
import numpy as np

ROOT=Path(__file__).resolve().parent
BASE=ROOT.parent
BANK=BASE/"mts-live-fullbank-90p4-20261126"
HIST=BASE/"mts-carried-gravity-photons-90p4-20261126"
PINS={BANK:"4beb37de5e58003d7c6be1cf92220050d001b381301dbbfc96343abd4c76c76a",HIST:"9255065ecee560e1933ced73cb9cc0ba3561e6bbfe1259f7c93d7b41c7992680"}
START=89.65
END=90.4
MODELS=("control","primary","fine")
GRIDS=("p16","p32")


def sha(path):
    with path.open("rb") as stream:return hashlib.file_digest(stream,"sha256").hexdigest()


def obj(path):return json.loads(path.read_bytes())


def pin(folder,name):
    assert sha(folder/"seal.json")==PINS[folder]
    path=folder/name;assert sha(path)==obj(folder/"seal.json")["files"][name]
    return path


def guard():
    assert not any((folder/"STOP-REQUESTED").exists() for folder in (BASE,ROOT,*PINS))
    assert __debug__


def save(path,raw):
    guard()
    if path.exists():assert sha(path)==hashlib.sha256(raw).hexdigest(),path
    else:
        path.parent.mkdir(exist_ok=True,parents=True);tmp=path.with_suffix(path.suffix+".partial")
        with tmp.open("xb") as f:f.write(raw)
        tmp.rename(path)


def put(path,data):save(path,(json.dumps(data,indent=2,sort_keys=True,allow_nan=False,default=lambda x:x.item())+"\n").encode())
def pack(path,**data):
    stream=BytesIO();np.savez_compressed(stream,**data);save(path,stream.getvalue())
def record(path,inputs):put(path,{p.relative_to(BASE).as_posix():sha(p) for p in inputs})
def check(path):
    for key,value in obj(path).items():assert sha(BASE/key)==value,key


def setup_modules():
    for name in ("stepper.py","sources90.py","evolve90.py","project90.py","window_io.py"):pin(HIST,name)
    sys.path.insert(0,str(HIST))
    import window_io as io
    import sources90,stepper,evolve90
    assert all(Path(mod.__file__).parent==HIST for mod in (io,sources90,stepper,evolve90))
    return io,sources90,stepper,evolve90


def stage(model,grid):
    assert model in MODELS and grid in GRIDS
    return ROOT/model/grid
