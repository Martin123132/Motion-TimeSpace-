from response_io import *
from scipy.interpolate import CubicSpline


def run(grid):
    io,sources,_,_=setup_modules();pre=io.oldio.prefix();p=pre.import_at(pre.OLD,"partial");bank=p.joint.Bank()
    src,_=sources.setup(p,grid,4,"wave",bank);solver=p.old.Wave(src);k=src.wave;kk=src.kk
    tags=list(MODELS)+["delta-primary","delta-fine"];curves=[]
    for tag in tags:
        if tag.startswith("delta"):name=f"constraint-{tag[6:]}-{grid}-640.npz";key="prediction"
        else:name=f"three-{grid}-{tag}-1.npz";key="constraint"
        with np.load(ROOT/name) as ar:curves.append(CubicSpline(ar["t"],ar[key],extrapolate=False))
    with np.load(io.sealed(io.CARRY,f"carry-wave-{grid}-4.npz")) as ar:
        fields=np.stack([ar["ordinary_end"][1]-ar["ordinary_end"][0]]*3+[np.zeros_like(ar["ordinary_end"][0])]*2)
        lag=np.stack([ar["lag_end"][1]-ar["lag_end"][0]]*3+[np.zeros_like(ar["lag_end"][0])]*2)
        assert ar["shape_end"].shape==(69,)
    t=np.linspace(START,END,15*8*int(grid[1:])*4+1)
    readout=np.empty((len(t),len(tags),4),complex)
    zeros=np.zeros((len(tags),69),complex)
    bits=np.arange(69)
    for first in range(0,len(t)-1,48):
        guard();end=min(first+48,len(t)-1);edges=t[first:end+1];clock=np.empty(2*len(edges)-1);clock[::2]=edges;clock[1::2]=(edges[:-1]+edges[1:])/2
        vel,slow,kernel,weights=bank.coeff(clock)
        mat,bi,bn=p.old.operator(solver,clock,clock);mat[:,:13,p.old.QI]+=bi;mat[:,:13,p.old.QN]+=bn;op=mat[:,:,:p.old.DIM]
        bg,den,we,wj,*_=p.coefficients(src,clock);h=bg["h"];eg=bg["eg"];nus=4*bg["er"]+bg["nuS"]
        defects=np.column_stack([s(clock) for s in curves]);inj=np.zeros((len(clock),p.old.DIM))
        for idx,v in [(1,(4/3+bg["eb"]/eg)*kk),(4,k/3),(6,kk),(8,bg["sv"]),(9,-(bg["a"]*bg["sm"])**2*bg["sb"]),(10,bg["hv"]),(11,-(bg["a"]*bg["hm"])**2*bg["hb"]),(12,-h)]:inj[:,idx]=v
        def step(pos,x,y,obs=False):
            stress=bank.stress(y,zeros,kernel[pos],weights[pos])*bg["enu"][pos];stress[:,1]*=k
            energy=x@we[pos]+stress[:,0];current=x@wj[pos]+stress[:,1]
            phi=-(energy/2+1.5*h[pos]*current/kk)/den[pos]-defects[pos]
            psi=phi+(stress[:,2]-eg[pos]*x[:,p.old.QI]-nus[pos]*x[:,p.old.QN])/kk
            if obs:return np.column_stack((phi,psi,x[:,12],defects[pos]))
            used=x.copy();used[:,12]=phi
            dx=used@op[pos].T+(stress[:,2]/kk)[:,None]*inj[pos];dx[:,12]+=stress[:,1]/(2*kk)
            normal=used[:,p.N_IND].copy();normal[:,0]+=phi
            dy=bank.bin_rhs(y,zeros,normal,psi,vel[pos],slow[pos],0.)
            return dx,dy
        for j,width in enumerate(np.diff(edges)):
            pos=2*j;readout[first+j]=step(pos,fields,lag,True)
            fa,la=step(pos,fields,lag);fb,lb=step(pos+1,fields+width*fa/2,lag+width*la/2);fc,lc=step(pos+1,fields+width*fb/2,lag+width*lb/2);fd,ld=step(pos+2,fields+width*fc,lag+width*lc)
            fields+=width/6*(fa+2*fb+2*fc+fd);lag+=width/6*(la+2*lb+2*lc+ld)
        readout[end]=step(len(clock)-1,fields,lag,True)
    assert np.isfinite(readout).all() and np.isfinite(lag).all()
    pack(ROOT/f"retarded-{grid}.npz",t=t,labels=tags,values=readout,ordinary=fields,lag=lag)
    print("frozen retarded difference",grid,flush=True)


def main():
    check(ROOT/"three-forecast.json");check(ROOT/"constraint-forecast.json")
    record(ROOT/"gap-method.json",[ROOT/"three-forecast.json",ROOT/"constraint-forecast.json",ROOT/"retarded_gap.py",ROOT/"RESPONSE-IDENTITY.md",pin(HIST,"stepper.py")])
    for grid in GRIDS:run(grid)
    record(ROOT/"gap-forecast.json",[ROOT/"gap-method.json",*[ROOT/f"retarded-{grid}.npz" for grid in GRIDS]])


if __name__=="__main__":main()
