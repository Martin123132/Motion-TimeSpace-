import ast,csv,sys
from recouple_stage import ROOT,CASES,DRIVES,np,previous,sha,locked,freeze,safe
from recouple_score import balance,pct
def reader(name):
    with (ROOT/name).open() as file:return list(csv.DictReader(file))
def synthetic():
    t=np.linspace(0,1,513);hub=.2;kk=2.
    density=t**2+t**3;pressure=t**2/2;current=t
    phi=(1.5*t**2+t**3+hub*(5*t**3/6+t**4/4))/3
    psi=(1+2*hub*t)/kk-pressure
    test=np.stack([phi,psi,phi,current,density,pressure,density,pressure],axis=1)[:,None,:]*np.array([1,1+2j])[None,:,None]
    bg=np.broadcast_to([hub,1.,0.,1.],(len(t),4))
    rec=balance(t,bg,kk,test);assert np.max(pct(t,rec[:,:,0],test[:,:,6]))<1e-5 and np.max(pct(t,rec[:,:,1],test[:,:,3]))<1e-5
    assert np.min(pct(t,rec[:,:,4],test[:,:,6]))>10
def verify(seal=False):
    safe();synthetic()
    for name in ('protocol-freeze','forecast-freeze','reference-freeze','score-receipt'):locked(name+'.json')
    for filename,expected in [('response-scores',192),('clock-tests',96),('curvature-comparison',8),('balance-checks',48),('curvature-attribution',32),('metric-controls',4),('native-controls',8)]:
        rows=reader(filename+'.csv');assert len(rows)==expected,(filename,len(rows))
        for row in rows:
            if 'passes' in row:
                if 'error_pct' in row:errors=[float(row['error_pct'])]
                else:errors=[float(row[k]) for k in ('energy_reconstruction_pct','momentum_reconstruction_pct','energy_quadrature_spread_pct','momentum_quadrature_spread_pct')]
                assert np.isfinite(errors).all() and min(errors)>=0 and (max(errors)<=.5)==(row['passes']=='True')
    for mode,sub in CASES:
        for branch in ('forecast','reference'):
            with np.load(ROOT/f'{branch}-{mode}-{sub}.npz') as ar:
                assert ar['input_sha'].item()==sha(previous(f'drive-{mode}-{sub}.npz'))
                dat=ar['observables'];assert np.isfinite(dat).all() and not dat[0].any() and not dat[:,2].any()
                volume=3*ar['bg'][:,3,None]**2*dat[:,:,0]
                for raw,true in [(4,6),(5,7)]:assert np.max(abs(dat[:,:,true]-dat[:,:,raw]-volume))<1e-12*np.max(abs(dat[:,:,true]))
        rows=reader('curvature-attribution.csv')
        for tag in DRIVES[:2]:
            subtotal=sum(float(r['signed_share_pct']) for r in rows if (r['mode'],r['sub'],r['source'])==(mode,str(sub),tag))
            assert abs(subtotal-100)<1e-6
    for file in ROOT.glob('*.py'):ast.parse(file.read_text())
    assert not list(ROOT.glob('__pycache__'))
    if seal:
        assert (ROOT/'RESULTS.md').exists()
        freeze('seal.json',sorted(p.name for p in ROOT.iterdir() if p.is_file() and p.name!='seal.json'));locked('seal.json');print(sha(ROOT/'seal.json'))
    else:print('Protocol, input provenance, paired nulls, independent balance fixture, scores and controls verified.')
if __name__=='__main__':verify('--seal' in sys.argv)
