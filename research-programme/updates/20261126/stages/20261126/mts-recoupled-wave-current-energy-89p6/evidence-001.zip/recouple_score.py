from scipy.interpolate import CubicSpline
from scipy.integrate import cumulative_trapezoid
from recouple_stage import ROOT,KIN,CASES,DRIVES,np,pinned,previous,table,freeze,locked,rms,safe
from recouple_forecast import CHANNELS
def integral(t,y):
    primitive=CubicSpline(t,y,axis=0,extrapolate=False).antiderivative()
    return primitive(t)-primitive(t[0])
def pct(t,trial,ref):
    den=rms(t,ref);assert np.all(den>0)
    return 100*rms(t,trial-ref)/den
def balance(t,bg,kk,data):
    phi,psi,_,current,_,_,density,pressure=data.transpose(2,0,1)
    hub,_,_,vel=bg.T
    weight=np.exp(integral(t,hub))[:,None];hub=hub[:,None];v2=vel[:,None]**2
    rest=weight*(-3*hub*pressure-current)
    phi_rate=CubicSpline(t,phi).derivative()(t)
    work=3*weight*v2
    density_rec=(integral(t,rest)+integral(t,work*phi_rate))/weight
    mom=weight**2*kk*(pressure+v2*psi)
    current_rec=integral(t,mom)/weight**2
    metric_trap=np.vstack([np.zeros((1,2)),np.cumsum((work[1:]+work[:-1])/2*np.diff(phi,axis=0),axis=0)])
    density_trap=(cumulative_trapezoid(rest,t,axis=0,initial=0)+metric_trap)/weight
    current_trap=cumulative_trapezoid(mom,t,axis=0,initial=0)/weight**2
    return np.stack([density_rec,current_rec,density_trap,current_trap,integral(t,rest)/weight],axis=2)
def load(mode,sub,label):
    with np.load(ROOT/f'{label}-{mode}-{sub}.npz') as ar:
        data=ar['observables'];assert ar['channels'].tolist()==list(CHANNELS) and not data[:,2].any()
        return ar['t'],ar['bg'],ar['kk'].item(),data[:,:2,:]
def run():
    safe();locked('reference-freeze.json')
    scores=[];balances=[];curves=[];clocks=[];attribution=[];runs={}
    for mode,sub in CASES:
        for label in ('forecast','reference'):runs[mode,sub,label]=load(mode,sub,label)
        t,bg,kk,pred=runs[mode,sub,'forecast'];u,nbg,_,ref=runs[mode,sub,'reference'];assert np.array_equal(t,u)
        with np.load(pinned(KIN,f'anchored-{mode}-{sub}.npz')) as arc:edge=arc['first_end'].item()
        with np.load(previous(f'budget-trial-{mode}-{sub}.npz')) as ar:oneway=ar['one_way_phi'][:,:2]
        with np.load(previous(f'response-averaged-{mode}-{sub}.npz')) as ar:old=ar['geom'][:,:2,0]
        for j,tag in enumerate(DRIVES[:2]):
            curves.append(dict(mode=mode,sub=sub,source=tag,old_error_pct=pct(t,old[:,j],ref[:,j,0]),oneway_error_pct=pct(t,oneway[:,j],ref[:,j,0]),coupled_error_pct=pct(t,pred[:,j,0],ref[:,j,0]),coupled_minus_oneway_pct_of_native=100*rms(t,pred[:,j,0]-oneway[:,j])/rms(t,ref[:,j,0])))
        weight=np.exp(integral(t,bg[:,0]))[:,None]
        rate_h=-(bg[:,0]-nbg[:,0])[:,None]*ref[:,:,1]
        rate_j=(pred[:,:,3]-ref[:,:,3])/(2*kk)
        rate_s=-bg[:,0,None]*((pred[:,:,2]-pred[:,:,0])-(ref[:,:,2]-ref[:,:,0]))
        residual=pred[:,:,0]-ref[:,:,0]
        cs=[integral(t,weight*rate)/weight for rate in (rate_h,rate_j,rate_s)]
        for name,part in zip(('expansion','heavy_current','responsive_shear','ordinary_plus_unresolved'),[*cs,residual-sum(cs)]):
            for j,tag in enumerate(DRIVES[:2]):
                den=rms(t,residual[:,j])
                signed=100*np.trapezoid(np.real(part[:,j]*residual[:,j].conj()),t)/((t[-1]-t[0])*den**2)
                attribution.append(dict(mode=mode,sub=sub,source=tag,term=name,signed_share_pct=signed,remainder_pct=100*rms(t,residual[:,j]-part[:,j])/den))
        bp=balance(t,bg,kk,pred);br=balance(t,nbg,kk,ref)
        streams=[CubicSpline(t,val) for val in (pred,ref,bp,br)]
        for label,lo,hi in [('full',t[0],t[-1]),('first',t[0],edge),('later',edge,t[-1])]:
            tick=np.unique(np.r_[lo,t[(t>lo)&(t<hi)],hi]);trial,target,cb,rb=[stream(tick) for stream in streams]
            for j,tag in enumerate(DRIVES[:2]):
                for channel,error,mag in zip(CHANNELS,pct(tick,trial[:,j],target[:,j]),rms(tick,target[:,j])):
                    scores.append(dict(mode=mode,sub=sub,source=tag,window=label,channel=channel,error_pct=error,native_rms=mag,passes=bool(error<=.5)))
                for branch,bank,raw in [('forecast',cb,trial),('reference',rb,target)]:
                    values=bank[:,j];true=raw[:,j]
                    err=[pct(tick,values[:,0],true[:,6]),pct(tick,values[:,1],true[:,3]),100*rms(tick,values[:,0]-values[:,2])/rms(tick,true[:,6]),100*rms(tick,values[:,1]-values[:,3])/rms(tick,true[:,3]),pct(tick,values[:,4],true[:,6])]
                    balances.append(dict(mode=mode,sub=sub,source=tag,window=label,branch=branch,energy_reconstruction_pct=err[0],momentum_reconstruction_pct=err[1],energy_quadrature_spread_pct=err[2],momentum_quadrature_spread_pct=err[3],no_metric_work_pct=err[4],passes=bool(max(err[:4])<=.5)))
    for low,hi in [(('p16',2),('p16',4)),(('p32',2),('p32',4)),(('p16',4),('p32',4))]:
        for label in ('forecast','reference'):
            t,_,_,vals=runs[*low,label];u,_,_,ref=runs[*hi,label]
            assert t[0]==u[0] and t[-1]==u[-1]
            errors=pct(t,vals,CubicSpline(u,ref)(t))
            for j,tag in enumerate(DRIVES[:2]):
                for channel,error in zip(CHANNELS,errors[j]):
                    clocks.append(dict(low=str(low),high=str(hi),branch=label,source=tag,channel=channel,error_pct=error,passes=bool(error<=.5)))
    reports=[('response-scores',scores),('balance-checks',balances),('curvature-comparison',curves),('clock-tests',clocks),('curvature-attribution',attribution)]
    for name,data in reports:table(name+'.csv',data)
    freeze('score-receipt.json',['reference-freeze.json']+[name+'.csv' for name,_ in reports])
if __name__=='__main__':run()
