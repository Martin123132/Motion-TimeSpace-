from scipy.interpolate import CubicSpline
from recouple_stage import CASES,DRIVES,np,table,freeze,locked,rms
from recouple_score import integral,load,balance
def run():
    locked('score-receipt.json');rows=[]
    for mode,sub in CASES:
        for label in ('forecast','reference'):
            t,bg,kk,data=load(mode,sub,label);hub,mass2,back,vel=bg.T
            phi,psi,_,current,energy,pressure,density,_=data.transpose(2,0,1)
            pot=mass2*back
            rvel=CubicSpline(t,vel).derivative()(t)+2*hub*vel+pot
            rpot=CubicSpline(t,pot).derivative()(t)-2*hub*pot-mass2*vel
            denom=vel**2+pot**2/mass2
            assert np.min(denom)>0.5*np.max(denom)
            field=(vel[:,None]*current/kk+(pot/(2*mass2))[:,None]*(energy-pressure))/denom[:,None]
            moment=CubicSpline(t,field).derivative()(t)-vel[:,None]*(psi+3*phi)
            recovered=vel[:,None]*moment+pot[:,None]*field
            weight=np.exp(integral(t,hub))[:,None]
            extra_d=integral(t,weight*(rvel[:,None]*(moment+6*vel[:,None]*phi)+rpot[:,None]*field))/weight
            extra_j=integral(t,weight**2*kk*rvel[:,None]*field)/weight**2
            raw=balance(t,bg,kk,data)
            for j,tag in enumerate(DRIVES[:2]):
                for channel,target,usual,extra in [('density',density[:,j],raw[:,j,0],extra_d[:,j]),('current',current[:,j],raw[:,j,1],extra_j[:,j])]:
                    norm=rms(t,target);err=target-usual
                    rows.append(dict(mode=mode,sub=sub,branch=label,source=tag,channel=channel,bare_error_pct=100*rms(t,err)/norm,after_defect_pct=100*rms(t,err-extra)/norm,error_remaining_pct_of_original=100*rms(t,err-extra)/rms(t,err),energy_reconstruction_from_field_pct=100*rms(t,recovered[:,j]-energy[:,j])/rms(t,energy[:,j])))
    table('background-residual.csv',rows);freeze('background-diagnostic-receipt.json',['score-receipt.json','background_residual.py','background-residual.csv'])
if __name__=='__main__':run()
