from recouple_stage import ROOT, CASES, DRIVES, np, make, operator, DIM, QI, QN, background, previous, pack, table, freeze, locked, safe, sha
CHANNELS=('phi','lapse','induced','current','energy','pressure','density_a2','pressure_a2')
def observables(phi,slip,induced,field,moment,bg,kk):
    hub,mass2,back,vel=bg.T
    kinetic=vel[:,None]*moment
    potential=(mass2*back)[:,None]*field
    volume=(3*vel**2)[:,None]*phi
    return np.stack([phi,induced+slip,induced,kk*vel[:,None]*field,kinetic+potential,kinetic-potential,kinetic+potential+volume,kinetic-potential+volume],axis=-1)

def run(mode,sub):
    path=previous(f'drive-{mode}-{sub}.npz')
    with np.load(path) as ar:t=ar['t'];clock=ar['clock'];physical=ar['physical'];kk=ar['kk'].item()
    src,solver,_,_,_=make(mode,'matched',sub);assert kk==src.kk
    predicted=background(t,mode,sub,False)
    bg_wave=np.column_stack(predicted(clock))
    state=np.zeros((DIM,3),complex);keys=[12,QI,QN,10,11]
    history=np.zeros((len(t),len(keys),3),complex);rate_defect=scale=0.
    for begin in range(0,len(t)-1,32):
        safe();end=min(begin+32,len(t)-1);left,right=t[begin:end],t[begin+1:end+1];mid=(left+right)/2
        steps=[]
        for offset,points in enumerate((left,mid,right)):
            indices=2*np.arange(begin,end)+offset
            assert np.array_equal(clock[indices],points)
            env=solver.env(points,mid);bg=env[0]
            full,bi,bn=operator(solver,points,mid);full[:,:13,QI]+=bi;full[:,:13,QN]+=bn
            mat=full[:,:,:DIM].copy()
            retained=[idx for idx in range(DIM) if idx not in (10,11,12)]
            assert not np.any(mat[:,retained,10:12]) and not np.any(mat[:,12,10])
            assert np.allclose(mat[:,12,11],env[-2]/(2*kk),rtol=1e-8,atol=0)
            mat[:,10:12,:]=0;mat[:,12,11]=0
            hub,mass2,back,vel=bg_wave[indices].T
            assert np.max(abs(hub-bg['h'])/abs(hub))<1e-7
            mat[:,12,10]=vel/2
            eg=bg['eg'];nus=4*bg['er']+bg['nuS']
            mat[:,10,11]=1;mat[:,10,12]=4*vel
            mat[:,10,QI]=-vel*eg/kk;mat[:,10,QN]=-vel*nus/kk
            mat[:,11,10]=-(kk+mass2);mat[:,11,11]=-2*hub;mat[:,11,12]=2*mass2*back
            mat[:,11,QI]=mass2*back*eg/kk;mat[:,11,QN]=mass2*back*nus/kk
            tensor=physical[indices];slip=tensor[:,2]/kk;fixed=tensor[:,1]/(2*kk)
            inj=np.zeros((len(points),DIM,3),complex)
            def put(index,coef):inj[:,index]=coef[:,None]*slip
            put(1,kk*(4/3+bg['eb']/eg));inj[:,4]=src.wave*slip/3;inj[:,6]=kk*slip
            put(8,bg['sv']);put(9,-(bg['a']*bg['sm'])**2*bg['sb'])
            put(10,vel);put(11,-mass2*back);inj[:,12]=fixed-bg['h'][:,None]*slip
            coeff=np.column_stack([eg,nus,bg['h'],bg['ec'],kk*bg['sv'],src.wave*(4*bg['er']+bg['nuJ']),kk*vel])
            steps.append((mat,inj,coeff,slip,fixed))
        for idx,width in enumerate(right-left):
            def rhs(which,trial):
                nonlocal rate_defect,scale
                mat,inj,coeff,slip,fixed=steps[which]
                value=mat[idx]@trial+inj[idx];eg,nus,hub,ec,small,rad,heavy=coeff[idx]
                psi=trial[12]+slip[idx]-(eg*trial[QI]+nus*trial[QN])/kk
                audit=(eg*trial[1]+rad*trial[4]+ec*trial[6]+small*trial[8]+heavy*trial[10])/(2*kk)+fixed[idx]-hub*psi
                rate_defect=max(rate_defect,np.max(abs(audit-value[12])));scale=max(scale,np.max(abs(audit)))
                return value
            first=rhs(0,state);second=rhs(1,state+width*first/2);third=rhs(1,state+width*second/2);fourth=rhs(2,state+width*third)
            state+=width/6*(first+2*second+2*third+fourth);history[begin+idx+1]=state[keys]
    bg=solver.env(t)[0];phi,qi,qn,field,moment=history.transpose(1,0,2)
    slip=physical[::2,2,:]/kk;induced=phi-(bg['eg'][:,None]*qi+(4*bg['er']+bg['nuS'])[:,None]*qn)/kk
    data=observables(phi,slip,induced,field,moment,bg_wave[::2],kk)
    assert rate_defect<=.005*scale and np.isfinite(data).all() and not data[:,2].any()
    pack(f'forecast-{mode}-{sub}.npz',t=t,observables=data,bg=bg_wave[::2],kk=kk,channels=CHANNELS,drives=DRIVES,input_sha=sha(path))
    return dict(mode=mode,sub=sub,metric_rate_error_pct=100*rate_defect/scale,zero_input=0)
def main():
    safe();locked('protocol-freeze.json');table('metric-controls.csv',[run(m,s) for m,s in CASES])
    freeze('forecast-freeze.json',['protocol-freeze.json','metric-controls.csv']+[f'forecast-{m}-{s}.npz' for m,s in CASES])
if __name__=='__main__':main()
