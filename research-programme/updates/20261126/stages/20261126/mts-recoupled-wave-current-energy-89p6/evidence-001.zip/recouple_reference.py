from scipy.integrate import solve_ivp
from scipy.interpolate import CubicSpline
from recouple_stage import CASES,DRIVES,np,previous,background,pack,table,freeze,locked,safe,rms,sha
from recouple_forecast import CHANNELS
def run(mode,sub):
    safe();path=previous(f'drive-{mode}-{sub}.npz')
    with np.load(path) as ar:t=ar['t'];kk=ar['kk'].item()
    with np.load(previous(f'response-native-{mode}-{sub}.npz')) as ar:
        assert np.array_equal(t,ar['t']) and ar['input_hash'].item()==sha(path)
        geom=ar['geom'];native_current=ar['heavy']
    phi=geom[:,:,0];psi=geom[:,:,6];induced=geom[:,:,5]
    norms=np.max(abs(psi),axis=0);norms[2]=1
    metrics=CubicSpline(t,np.stack([phi/norms,psi/norms],axis=1))
    bg=np.column_stack(background(t,mode,sub,True)(t));background_curve=CubicSpline(t,bg)
    vel_unit=max(abs(bg[:,3]));field_unit=vel_unit/np.sqrt(max(bg[:,1]))
    def rhs(time,value):
        field,velocity=value.reshape(2,3)
        hub,mass2,back,vel=background_curve(time);phi,psi=metrics(time)
        field_rate=(vel_unit*velocity+vel*(psi+3*phi))/field_unit
        vel_rate=(-2*hub*velocity-(kk+mass2)*field*(field_unit/vel_unit)+(mass2*back/vel_unit)*(3*phi-psi))
        return np.r_[field_rate,vel_rate]
    sol=solve_ivp(rhs,(t[0],t[-1]),np.zeros(6,dtype=complex),method='DOP853',rtol=2e-12,atol=2e-13,max_step=.0015,t_eval=t)
    assert sol.success
    field=sol.y[:3].T*(field_unit*norms);u=sol.y[3:].T*(vel_unit*norms)
    hub,mass2,back,vel=bg.T
    delta_kin=vel[:,None]*u;delta_pot=(mass2*back)[:,None]*field
    density=vel[:,None]*(u+3*vel[:,None]*phi)+delta_pot;pressure=density-2*delta_pot
    current=kk*vel[:,None]*field
    values=np.stack([phi,psi,induced,current,delta_kin+delta_pot,delta_kin-delta_pot,density,pressure],axis=2)
    errors=100*rms(t,current[:,:2]-native_current[:,:2])/rms(t,native_current[:,:2])
    assert np.max(errors)<=.5 and np.isfinite(values).all() and not values[:,2].any()
    pack(f'reference-{mode}-{sub}.npz',t=t,observables=values,bg=bg,kk=kk,channels=CHANNELS,drives=DRIVES,input_sha=sha(path))
    return [dict(mode=mode,sub=sub,source=tag,native_current_replay_pct=e) for tag,e in zip(DRIVES,errors)]
def main():
    locked('forecast-freeze.json');rows=[]
    for m,s in CASES:rows.extend(run(m,s))
    table('native-controls.csv',rows);freeze('reference-freeze.json',['forecast-freeze.json','native-controls.csv']+[f'reference-{m}-{s}.npz' for m,s in CASES])
if __name__=='__main__':main()
