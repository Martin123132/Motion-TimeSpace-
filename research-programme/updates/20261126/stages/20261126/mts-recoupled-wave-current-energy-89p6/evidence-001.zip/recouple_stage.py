import hashlib
import json
import sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent
PREV=ROOT.parent/'mts-identical-stress-lapse-response-89p6-20261126'
PIN='fa6c16fd699113ab9c6a7712a3c389613fa71ed1a1833991e4c2ac074460ca44'
def sha(path):
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
assert sha(PREV/'seal.json')==PIN
entries=json.loads((PREV/'seal.json').read_bytes())['files']
def previous(name):
    path=PREV/name
    assert sha(path)==entries[name],name
    return path
previous('lapse_stage.py');previous('project_wave.py')
sys.path.insert(0,str(PREV))
from lapse_stage import common,window,np,CASES,DRIVES,pack,table,safe,freeze,locked,rms,KIN,TWIN,pinned
from project_wave import background,make
from native_pair import operator,DIM,QI,QN
common.PINS={**common.PINS,PREV:PIN}
common.ROOT=window.ROOT=ROOT
if __name__=='__main__':
    safe();freeze('protocol-freeze.json',['PROTOCOL.md','recouple_stage.py','recouple_forecast.py','recouple_reference.py','recouple_score.py','recouple_verify.py'])
