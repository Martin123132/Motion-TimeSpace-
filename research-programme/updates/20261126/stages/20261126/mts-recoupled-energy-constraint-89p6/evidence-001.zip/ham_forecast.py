from scipy.interpolate import CubicSpline
from ham_stage import ROOT,CASES,DRIVES,BRANCHES,SECTORS,np,make,DIM,IX,pack,table,safe,freeze,locked,previous,sealed,rms,digest

def primitive(t,values):
    curve=CubicSpline(t,values,axis=0,extrapolate=False).antiderivative()
    return curve(t)-curve(t[0])
def ratios(t,actual,ref):
    return 100*rms(t,actual-ref)/rms(t,ref)

def ordinary(bg,kk,wave,phi,psi):
    n=len(phi);mat=np.zeros((n,DIM,DIM));direct=np.zeros((n,DIM,3),complex)
    hub=bg['h'];opacity=bg['opacity'];ratio=bg['eb']/bg['eg'];inv=1/(ratio+4/3)
    mat[:,0,1]=-4*inv/3;mat[:,0,2]=4*inv/3-1
    for row in (1,2):
        mat[:,row,0]=kk/3;mat[:,row,IX['I2']]=-2*kk/3
    direct[:,1]=kk*((4/3+ratio[:,None])*psi+4*phi/3)
    mat[:,2,1]=4*hub*inv/3;mat[:,2,2]=-4*hub*inv/3-opacity*(1+4/(3*ratio))
    direct[:,2]=4*kk*phi/3
    mat[:,3,4]=-wave;mat[:,4,3]=wave/3;mat[:,4,IX['N2']]=-2*wave/3;direct[:,4]=wave*(phi+psi)/3
    mat[:,5,6]=-1;mat[:,6,6]=-hub;direct[:,6]=kk*psi
    mat[:,7,1]=-inv;mat[:,7,2]=inv
    mass2=(bg['a']*bg['sm'])**2;mat[:,8,9]=1;mat[:,9,8]=-kk-mass2;mat[:,9,9]=-2*hub
    direct[:,8]=bg['sv'][:,None]*(psi+3*phi);direct[:,9]=(mass2*bg['sb'])[:,None]*(3*phi-psi)
    for family in ('I','E'):
        for ell in range(2,7):
            row=IX[f'{family}{ell}'];div=2*ell+1
            if ell>2:mat[:,row,IX[f'{family}{ell-1}']]=wave*ell/div
            elif family=='I':
                weight=4*inv/3;mat[:,row,1]=2*weight/5;mat[:,row,2]=2*(1-weight)/5
            if ell<6:
                upper=ell+1 if family=='I' else (ell+3)*(ell-1)/(ell+1)
                mat[:,row,IX[f'{family}{ell+1}']]=-wave*upper/div
            mat[:,row,row]-=opacity
            if ell==2:
                mat[:,row,IX['I2']]+=.1*opacity;mat[:,row,IX['E2']]+=.6*opacity
    for ell in range(2,69):
        row=IX[f'N{ell}'];mat[:,row,IX[f'N{ell-1}']]=wave*ell/(2*ell+1)
        if ell<68:mat[:,row,IX[f'N{ell+1}']]=-wave*(ell+1)/(2*ell+1)
    return mat,direct

def run(mode,sub,branch):
    path=previous(f'drive-{mode}-{sub}.npz')
    with np.load(path) as packet:t=packet['t'];clock=packet['clock'];kk=packet['kk'].item();fixed_j,external_shear=packet['physical'][::2,1:3,:].transpose(1,0,2)
    with np.load(sealed(f'{branch}-{mode}-{sub}.npz')) as ar:
        assert np.array_equal(ar['t'],t) and ar['input_sha'].item()==digest(path)
        values=ar['observables'];heavy_v=ar['bg'][:,3];assert ar['channels'].tolist()==['phi','lapse','induced','current','energy','pressure','density_a2','pressure_a2']
    src,solver,_,_,_=make(mode,'wave' if branch=='reference' else 'matched',sub)
    assert src.kk==kk and src.flow.phot==6 and src.flow.limit==68
    bg=dict(zip(src.flow.bgkeys,src.flow.bg(np.log(clock)).T))
    metric=CubicSpline(t,values[:,:,:2],axis=0,extrapolate=False)(clock)
    state=np.zeros((DIM,3),complex);rows=[0,1,3,4,5,6,7,8,9,IX['I2'],IX['N2']]
    hist=np.zeros((len(t),len(rows),3),complex)
    for start in range(0,len(t)-1,48):
        safe();end=min(start+48,len(t)-1);sel=slice(2*start,2*end+1)
        mat,source=ordinary({k:val[sel] for k,val in bg.items()},kk,src.wave,metric[sel,: ,0],metric[sel,:,1])
        for pos,width in enumerate(np.diff(t[start:end+1])):
            idx=2*pos
            def deriv(j,trial):return mat[j]@trial+source[j]
            a=deriv(idx,state);b=deriv(idx+1,state+width*a/2);c=deriv(idx+1,state+width*b/2);d=deriv(idx+2,state+width*c)
            state+=width*(a+2*b+2*c+d)/6;hist[start+pos+1]=state[rows]
    bg={k:val[::2,None] for k,val in bg.items()};phi,psi,induced,heavy_j,heavy_e,_,heavy_d,_=values.transpose(2,0,1)
    gx,total_w,n0,n1,cd,ct,bd,sf,sw,qi,qn=hist.transpose(1,0,2)
    hub=bg['h'];eg=bg['eg'];eb=bg['eb'];ec=bg['ec'];sv=bg['sv']
    rad=4*bg['er']+bg['nuE'];radj=4*bg['er']+bg['nuJ'];rads=4*bg['er']+bg['nuS']
    energies=np.stack([eg*gx+eb*bd,rad*n0,ec*cd,sv*sw+(bg['a']*bg['sm'])**2*bg['sb']*sf,heavy_e],axis=-1)
    currents=np.stack([eg*total_w,radj*src.wave*n1,ec*ct,kk*sv*sf,heavy_j],axis=-1)
    volumes=np.column_stack([4*eg+3*eb,rad,3*ec,3*sv**2,3*heavy_v**2])
    coef=kk+volumes.sum(1)/2
    env=solver.env(t)
    check_coef=env[-1] if branch=='reference' else env[-1]+1.5*(heavy_v**2-env[-2])
    assert np.allclose(check_coef,coef,atol=0,rtol=1e-10)
    assert np.max(abs(heavy_d-heavy_e-volumes[:,None,-1]*phi))<=1e-12*np.max(abs(heavy_d))
    net_j=currents.sum(2)+fixed_j
    responsive=-(eg*qi+rads*qn)/kk
    phi_rate=net_j/(2*kk)-hub*psi
    predicted_phi=primitive(t,phi_rate)
    ctrl_shear=ratios(t,responsive[:,:2],(induced-phi)[:,:2])
    ctrl_momentum=ratios(t,predicted_phi[:,:2],phi[:,:2])
    ctrl_lapse=ratios(t,(phi+responsive+external_shear/kk)[:,:2],psi[:,:2])
    rows=[]
    for idx,tag in enumerate(DRIVES[:2]):
        errors=[ctrl_shear[idx],ctrl_momentum[idx],ctrl_lapse[idx]]
        assert max(errors)<.5,(branch,mode,sub,errors)
        rows.append(dict(branch=branch,mode=mode,sub=sub,stress=tag,shear_replay_pct=errors[0],metric_replay_pct=errors[1],lapse_replay_pct=errors[2]))
    required=-2*coef[:,None]*phi-energies.sum(2)-3*hub*net_j/kk
    assert np.isfinite(required).all() and not hist[:, :,2].any() and not required[:,2].any() and not required[0].any()
    pack(f'required-{branch}-{mode}-{sub}.npz',t=t,kk=kk,h=hub[:,0],phi=phi,psi=psi,coef=coef,volume=volumes,energies=energies,currents=currents,fixed_j=fixed_j,heavy_d=heavy_d,required=required,sectors=SECTORS,input_sha=digest(path))
    return rows
def main():
    locked('protocol-freeze.json');results=[]
    for mode,sub in CASES:
        for branch in BRANCHES:results+=run(mode,sub,branch)
    table('independent-replay.csv',results)
    freeze('required-freeze.json',['protocol-freeze.json','independent-replay.csv']+[f'required-{b}-{m}-{s}.npz' for m,s in CASES for b in BRANCHES])
if __name__=='__main__':main()
