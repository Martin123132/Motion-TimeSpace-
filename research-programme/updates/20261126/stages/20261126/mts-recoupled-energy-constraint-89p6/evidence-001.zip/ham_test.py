from scipy.interpolate import CubicSpline
from ham_stage import ROOT,CASES,BRANCHES,DRIVES,SECTORS,np,previous,pinned,KIN,rms,table,pack,locked,freeze,safe,digest

def error(t,trial,ref):
    norm=rms(t,ref);assert np.all(norm>0)
    return 100*rms(t,trial-ref)/norm
def solve_phi(energy,currents,external_e,fixed_j,hub,kk,coef):
    return -((energy.sum(-1)+external_e)/2+1.5*hub[:,None]*(currents.sum(-1)+fixed_j)/kk)/coef[:,None]
def score():
    locked('required-freeze.json');records=[];terms=[];checks=[];pairs=[];refinements=[];banks={}
    names=['metric']+[f'{s}_canonical_energy' for s in SECTORS]+['imposed_energy']+[f'{s}_momentum' for s in SECTORS]+['imposed_momentum']
    for mode,sub in CASES:
        path=previous(f'drive-{mode}-{sub}.npz')
        with np.load(path) as arc:actual=arc['physical'][::2,0,:]
        with np.load(pinned(KIN,f'anchored-{mode}-{sub}.npz')) as arc:edge=arc['first_end'].item()
        for branch in BRANCHES:
            with np.load(ROOT/f'required-{branch}-{mode}-{sub}.npz') as ar:
                assert digest(path)==ar['input_sha'].item() and ar['sectors'].tolist()==list(SECTORS)
                t=ar['t'];phi=ar['phi'];req=ar['required'];energy=ar['energies'];current=ar['currents'];fixed_j=ar['fixed_j']
                h=ar['h'];kk=ar['kk'].item();coef=ar['coef'];physical=energy+ar['volume'][:,None,:]*phi[:,:,None];physical[:,:,-1]=ar['heavy_d']
                derivative=CubicSpline(t,phi,extrapolate=False).derivative()(t)
                derivative_form=kk*phi+(physical.sum(2)+actual)/2+3*h[:,None]*(derivative+h[:,None]*ar['psi'])
            fac=1.5*h[:,None]/kk
            components=np.concatenate([(coef[:,None]*phi)[:,:,None],energy/2,actual[:,:,None]/2,fac[:,:,None]*current,(fac*fixed_j)[:,:,None]],axis=2)
            total=components.sum(2);from_req=(actual-req)/2
            from_density=solve_phi(energy,current,actual,fixed_j,h,kk,coef)
            physical_form=kk*phi+(physical.sum(2)+actual)/2+fac*(current.sum(2)+fixed_j)
            for slot,tag in enumerate(DRIVES[:2]):
                norm=rms(t,coef*phi[:,slot])
                tests=[100*rms(t,value[:,slot]-total[:,slot])/norm for value in (from_req,physical_form,derivative_form)]
                assert max(tests)<=.5,(mode,sub,branch,tests)
                checks.append(dict(mode=mode,sub=sub,branch=branch,stress=tag,identity_on_metric_scale_pct=tests[0],physical_form_pct=tests[1],derivative_form_pct=tests[2]))
            assert not total[:,2].any() and not total[0].any() and np.isfinite(total).all()
            saved=np.stack([phi,from_density,req,actual,total,total/coef[:,None]],axis=-1)
            banks[mode,sub,branch]=(t,saved[:,:2])
            spline=CubicSpline(t,saved,axis=0);ledger=CubicSpline(t,components,axis=0)
            for window,lo,hi in [('full',t[0],t[-1]),('first',t[0],edge),('later',edge,t[-1])]:
                tick=np.unique(np.r_[lo,t[(t>lo)&(t<hi)],hi]);vals=spline(tick);items=ledger(tick)
                for slot,tag in enumerate(DRIVES[:2]):
                    grav,recon,pred,obs,res,asphi=vals[:,slot].T
                    ge=error(tick,recon,grav);ee=error(tick,pred,obs);sources=items[:,slot]
                    rr=rms(tick,res);net_scale=rms(tick,sources).sum()
                    records.append(dict(mode=mode,sub=sub,branch=branch,stress=tag,window=window,metric_error_pct=ge,imposed_energy_error_pct=ee,residual_rms=rr,residual_pct_of_sum_rms=100*rr/net_scale,phi_rms=rms(tick,grav),phi00_rms=rms(tick,recon),required_density_rms=rms(tick,pred),actual_density_rms=rms(tick,obs),metric_pass=bool(ge<=.5),energy_pass=bool(ee<=.5)))
                    for col,title in enumerate(names):
                        val=sources[:,col];share=100*np.trapezoid((val*res.conj()).real,tick)/((hi-lo)*rr**2)
                        terms.append(dict(mode=mode,sub=sub,branch=branch,stress=tag,window=window,term=title,signed_pct_of_residual=share,term_rms=rms(tick,val)))
        t,pred=banks[mode,sub,'forecast'];_,ref=banks[mode,sub,'reference']
        for slot,tag in enumerate(DRIVES[:2]):
            rel=error(t,pred[:,slot,4],ref[:,slot,4])
            pairs.append(dict(mode=mode,sub=sub,stress=tag,residual_difference_pct_of_native_residual=rel,required_density_difference_pct=error(t,pred[:,slot,2],ref[:,slot,2]),residual_difference_on_native_metric_pct=100*rms(t,pred[:,slot,5]-ref[:,slot,5])/rms(t,ref[:,slot,0])))
    for low,hi in [(('p16',2),('p16',4)),(('p32',2),('p32',4)),(('p16',4),('p32',4))]:
        for branch in BRANCHES:
            t,a=banks[*low,branch];u,b=banks[*hi,branch];assert t[0]==u[0] and t[-1]==u[-1]
            errs=error(t,a,CubicSpline(u,b,axis=0)(t))
            for idx,tag in enumerate(DRIVES[:2]):
                for name,err in zip(('momentum_phi','density_phi','required_density','actual_density','residual','potential_equivalent_residual'),errs[idx]):
                    refinements.append(dict(low=str(low),high=str(hi),branch=branch,stress=tag,channel=name,error_pct=err,passes=bool(err<=.5)))
    outputs=[('constraint-scores',records),('residual-ledger',terms),('form-controls',checks),('branch-comparison',pairs),('refinement',refinements)]
    for name,rows in outputs:table(name+'.csv',rows)
    freeze('score-receipt.json',['required-freeze.json']+[name+'.csv' for name,_ in outputs])
if __name__=='__main__':score()
