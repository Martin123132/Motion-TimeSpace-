import sys,json
from scipy.interpolate import CubicSpline
from scipy.special import expit
from ham_stage import ROOT,np,previous,locked,freeze,table,pack,safe,rms,common,window,SECTORS
from ham_forecast import primitive
from cycle3_inputs import earlier
from lapse_stage import wave_input
earlier('one_stage.py');sys.path.insert(0,str(earlier('stress_feedback.py').parent))
import stress_feedback as old

def run(mode):
    safe();src=old.source(mode);kin=old.KIN;k=src.wave
    with np.load(old.pin(f'angular-{mode}-4.npz')) as ar:
        grid=ar['grid'];states=old.evolve(src,grid,ar['wave_entry'],True)[:,:,0]
        historical_check=old.relative(states[-1],ar['wave_final'])
        drive,knots=old.driver(mode,src,grid,states,True)
    meta=json.loads(earlier(f'checks-{mode}-4.json').read_bytes())['wave']
    peak=old.peak(drive)
    assert historical_check<=1e-10 and abs(peak/meta['driver_peak']-1)<.005
    dipole=kin.spline(grid,drive[:,1]/peak)
    with np.load(earlier(f'impulses-{mode}-4.npz')) as ar:
        dense=ar['wave_clock'];vals=ar['wave_stress']
    meta=json.loads(kin.ti.parent.pin('radiation-background.json').read_bytes())['heavy']
    mass=meta['mass_over_temperature'];coeff=meta['massless_limit_coeff']/(7*np.pi**4/120)
    with np.load(wave_input('material-halfstep/forcing-heavy.npz')) as ar:
        bg=dict(zip(ar['bgkeys'],ar['background']))
        scale=kin.spline(ar['eta'],bg['a']);norm=kin.spline(ar['eta'],bg['enu'])
        from scipy.interpolate import make_interp_spline
        packet_norm=make_interp_spline(np.log(ar['eta']),bg['enu'],k=5)
    with np.load(previous(f'drive-{mode}-4.npz')) as ar:
        t=ar['t'];stress=ar['physical'][::2,:,('p32','p16').index(mode)]
    saved=kin.spline(dense,vals);q=kin.MOM;weight=q**2*expit(-q)*expit(q)
    tick=np.unique(np.r_[grid,t,dense,(grid[1:]+grid[:-1])/2])
    log=np.log(tick);a=scale(log);adot=scale.derivative()(log)/tick
    convert=a**2*norm(log)/coeff;phys=packet_norm(log)
    gap=(mass*a[:,None])**2/(np.hypot(q,mass*a[:,None])+q)
    source_weight=k*np.trapezoid(weight*q**2*gap,x=np.log(q),axis=1)
    old_n=dipole(log)*peak
    src_bg=src.flow.bg(log);key=src.flow.bgkeys
    results=[];vectors={'t':t}
    def budget(raw_current,raw_trace,normal):
        base=convert*(adot/a*raw_trace-k*raw_current)
        return primitive(tick,base+source_weight*normal)/convert*phys
    dense_vals=saved(log)
    obs=dense_vals[:,0]*phys
    split0=budget(dense_vals[:,1],dense_vals[:,3],np.zeros_like(old_n))
    true=budget(dense_vals[:,1],dense_vals[:,3],old_n)
    use=np.searchsorted(tick,t)
    knotuse=np.searchsorted(tick,knots)
    packet=kin.spline(knots,vals[np.searchsorted(dense,knots)])(log)
    assert np.max(abs(packet[use,0]*phys[use]-stress[:,0]))<=1e-10*np.max(abs(stress[:,0]))
    for branch in ('forecast','reference'):
        with np.load(ROOT/f'required-{branch}-{mode}-4.npz') as ar:
            j=ar['currents'][:,('p32','p16').index(mode),SECTORS.index('streaming')]
            req=ar['required'][:,('p32','p16').index(mode)]
        if branch=='reference':bg_local=src_bg
        else:
            from ham_stage import make
            src_local=make(mode,'matched',4)[0]
            bg_local=src_local.flow.bg(log);assert list(src_local.flow.bgkeys)==list(key)
        weight_n=k*(4*bg_local[:,list(key).index('er')]+bg_local[:,list(key).index('nuJ')])
        local_n=CubicSpline(t,j)(tick)/weight_n
        held=budget(packet[:,1],packet[:,3],local_n)[use]
        driven=budget(packet[:,1],packet[:,3],old_n)[use]
        without=budget(packet[:,1],packet[:,3],np.zeros_like(old_n))[use]
        def relative(tm,test,ref):return 100*rms(tm,test-ref)/rms(tm,ref)
        results.append(dict(stress=mode,branch=branch,source_replay_peak_relative=abs(peak/json.loads(earlier(f'checks-{mode}-4.json').read_bytes())['wave']['driver_peak']-1),
            dense_old_driver_pct=relative(tick,true,obs),dense_without_driver_pct=relative(tick,split0,obs),
            old_driver_at_original_knots_pct=relative(knots,true[knotuse],obs[knotuse]),dense_vs_knot_energy_pct=relative(t,obs[use],stress[:,0]),
            old_driver_using_packet_moments_pct=relative(t,driven,stress[:,0]),local_dipole_vs_old_size_pct=100*rms(tick,local_n)/rms(tick,old_n),
            local_dipole_energy_error_vs_required_pct=relative(t,held,req),zero_dipole_energy_error_vs_required_pct=relative(t,without,req),
            local_vs_required_on_observed_scale_pct=100*rms(t,held-req)/rms(t,stress[:,0])))
        vectors[branch+'_local_dipole_density']=held;vectors[branch+'_required']=req
    common.ROOT=window.ROOT=ROOT
    pack(f'packet-ledger-{mode}.npz',**vectors,earlier_driver_density=driven,archived_density=stress[:,0])
    return results
def main():
    locked('score-receipt.json');out=[]
    for mode in ('p32','p16'):out.extend(run(mode))
    table('packet-balance.csv',out)
    freeze('packet-receipt.json',['score-receipt.json','packet_energy.py','packet-balance.csv','packet-ledger-p16.npz','packet-ledger-p32.npz'])
if __name__=='__main__':main()
