import ast,csv,sys
from collections import defaultdict
from ham_stage import ROOT,CASES,BRANCHES,DRIVES,SECTORS,np,previous,rms,locked,freeze,safe,digest
from ham_test import solve_phi,error
def rows(name):
    with (ROOT/(name+'.csv')).open() as stream:return list(csv.DictReader(stream))
def fixture():
    t=np.linspace(0,1,257);kk=.22;coef=.24+.01*t;hub=.12+.02*t
    phi=t[:,None]*(1+1j*t[:,None])*np.array([1,-2j])[None,:]
    energy=np.stack([.6*phi,-.1*phi],axis=-1);currents=np.stack([-.15*phi,.02j*phi],axis=-1)
    fixed_j=.04*phi
    e=-2*coef[:,None]*phi-energy.sum(2)-3*hub[:,None]*(currents.sum(2)+fixed_j)/kk
    solved=solve_phi(energy,currents,e,fixed_j,hub,kk,coef)
    mutant=solve_phi(energy,currents,e+.02*coef[:,None]*phi,fixed_j,hub,kk,coef)
    assert np.max(error(t,solved,phi))<1e-10 and np.max(abs(error(t,mutant,phi)-1))<1e-10
def verify(seal=False):
    safe();fixture()
    for receipt in ['protocol-freeze.json','required-freeze.json','score-receipt.json']:locked(receipt)
    for name,count in [('independent-replay',16),('constraint-scores',48),('residual-ledger',624),('form-controls',16),('branch-comparison',8),('refinement',72)]:
        assert len(rows(name))==count,(name,len(rows(name)))
    for r in rows('constraint-scores'):
        for field,flag in [('metric_error_pct','metric_pass'),('imposed_energy_error_pct','energy_pass')]:
            val=float(r[field]);assert np.isfinite(val) and val>=0 and (val<=.5)==(r[flag]=='True')
    for r in rows('refinement'):
        val=float(r['error_pct']);assert np.isfinite(val) and val>=0 and (val<=.5)==(r['passes']=='True')
    totals=defaultdict(float)
    for r in rows('residual-ledger'):
        key=tuple(r[name] for name in ['mode','sub','branch','stress','window'])
        totals[key]+=float(r['signed_pct_of_residual'])
    assert len(totals)==48 and max(abs(100-v) for v in totals.values())<1e-4
    for mode,sub in CASES:
        for branch in BRANCHES:
            with np.load(ROOT/f'required-{branch}-{mode}-{sub}.npz') as arc:
                assert arc['input_sha'].item()==digest(previous(f'drive-{mode}-{sub}.npz'))
                assert arc['sectors'].tolist()==list(SECTORS)
                for k in ['phi','required','fixed_j','energies','currents']:assert not arc[k][:,2].any() and not arc[k][0].any() and np.isfinite(arc[k]).all()
    for file in ROOT.glob('*.py'):ast.parse(file.read_text())
    assert not list(ROOT.glob('__pycache__'))
    if seal:
        assert (ROOT/'RESULTS.md').is_file();freeze('seal.json',sorted(p.name for p in ROOT.iterdir() if p.is_file() and p.name!='seal.json'));locked('seal.json');print(digest(ROOT/'seal.json'))
    else:print('Frozen inputs, numerical controls, sign checks, sector ledgers and physics verdict labels verified.')
if __name__=='__main__':verify('--seal' in sys.argv)
