import hashlib
import json
import sys
from pathlib import Path

ROOT=Path(__file__).resolve().parent
PARENT=ROOT.parent/'mts-recoupled-wave-current-energy-89p6-20261126'
PIN='18f63f9329dcfb2d7685266a24bd64da1789cc2904e7bb4bf259b3f9cd80798c'
def digest(path):
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
assert digest(PARENT/'seal.json')==PIN
entries=json.loads((PARENT/'seal.json').read_bytes())['files']
def sealed(name):
    path=PARENT/name;assert digest(path)==entries[name],name
    return path
sealed('recouple_stage.py')
sys.path.insert(0,str(PARENT))
from recouple_stage import np,common,window,CASES,DRIVES,previous,make,pack,table,safe,freeze,locked,pinned,KIN,rms,DIM
from angular_operator import IX
common.PINS={**common.PINS,PARENT:PIN};common.ROOT=window.ROOT=ROOT
BRANCHES=('forecast','reference')
SECTORS=('photon_baryon','streaming','cold','light_wave','heavy_wave')
if __name__=='__main__':
    safe();freeze('protocol-freeze.json',['PROTOCOL.md','ham_stage.py','ham_forecast.py','ham_test.py','ham_verify.py'])
