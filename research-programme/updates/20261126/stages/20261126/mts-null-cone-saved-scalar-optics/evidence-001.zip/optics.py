from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,sys
import numpy as np
from scipy.integrate import solve_ivp
from scipy.optimize import brentq

ROOT=Path(__file__).resolve().parent
REFERENCE=ROOT.parent/'cosmology-lab-handoff-20261020'/'reference-cases.json'
TIMES=np.array([0.,.1,.5,1.,2.,2.33,3.])
def sha(path):
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
def put(name,data):
    with (ROOT/name).open('x',encoding='utf-8') as file:json.dump(data,file,indent=2,sort_keys=True,allow_nan=False,default=lambda val:val.item())
def cases():
    assert sha(REFERENCE)=='a8aef6c7828f58f31431359c43dbac8f7e565195879630242e3eec22af20928b'
    out={}
    for saved in json.loads(REFERENCE.read_bytes())['cases']:
        pars=saved['parameters'];derived=saved['derived'];scalar=derived['Omega_scalar0'];theta=derived['theta']
        model=saved['model'];matter=pars['Omega_m'];rad=pars['Omega_r'];h0=pars['H0_km_s_Mpc']
        out[model]=(matter,rad,derived['Omega_Lambda'],derived['mu'],-np.sqrt(scalar)*np.sin(theta),np.sqrt(scalar)*np.cos(theta),h0)
        out['LCDM_for_'+model]=(matter,rad,1-matter-rad,0.,0.,0.,h0)
    out['deSitter']=(0.,0.,1.,0.,0.,0.,70.)
    out['EdS']=(1.,0.,0.,0.,0.,0.,70.)
    return out
def evolve(params,step,tol):
    matter,rad,lam,mu,v0,y0,h0=params
    def rates(z,state):
        v,y=state[:2];w=1+z
        hub=np.sqrt(matter*w**3+rad*w**4+lam+v*v+y*y)
        gradient=-np.sqrt(6.)*v*w
        foreground=1.5*matter*w**5+2*rad*w**6
        return w,hub,gradient,foreground,gradient**2/2
    def rhs(z,state):
        v,y,affine,radius,slope,excluded,exslope=state
        w,hub,grad,fg,sc=rates(z,state);conversion=1/(w*w*hub)
        return [(3*v+mu*y/hub)/w,-mu*v/(w*hub),conversion,slope*conversion,-(fg+sc)*radius*conversion,
                exslope*conversion,-fg*excluded*conversion]
    sol=solve_ivp(rhs,(0,3),[v0,y0,0.,0.,1.,0.,1.],method='DOP853',max_step=step,rtol=tol,atol=tol*.01,dense_output=True)
    assert sol.success and np.isfinite(sol.y).all()
    rows=[]
    for z,state in zip(TIMES,sol.sol(TIMES).T):
        w,hub,grad,fg,sc=rates(z,state)
        rows.append(dict(z=z,E=hub,scalar_gradient=grad,scalar_focusing=sc,other_focusing=fg,scalar_pct=None if fg+sc==0 else 100*sc/(fg+sc),
            affine=state[2],D_A_Mpc=state[3]*299792.458/h0,no_scalar_focusing_D_A_Mpc=state[5]*299792.458/h0))
    def first(level,col):
        mask=np.flatnonzero(sol.y[col]>=level)
        if not len(mask):return None
        i=mask[0];redshift=brentq(lambda z:sol.sol(z)[col]-level,sol.t[i-1],sol.t[i],xtol=1e-14)
        state=sol.sol(redshift);assert state[col+1]>0
        return dict(redshift=redshift,affine=state[2])
    points=[]
    for level in (.25,.35):
        on,off=first(level,3),first(level,5)
        points.append(dict(area_radius=level,physical=on,no_scalar_focusing=off,clock_excess_pct=None if on is None or off is None else 100*(on['affine']/off['affine']-1)))
    return dict(rows=rows,clocks=points)
def freeze():
    results={}
    for tag,params in cases().items():
        results[tag]={'inputs':params,'primary':evolve(params,.04,2e-11),'refined':evolve(params,.02,2e-13)}
    put('optical-forecast.json',dict(time=datetime.now(timezone.utc).isoformat(),source=sha(REFERENCE),code={name:sha(ROOT/name) for name in ('PROTOCOL.md','optics.py')},cases=results))
def compare():
    packet=json.loads((ROOT/'optical-forecast.json').read_bytes())
    assert all(sha(ROOT/file)==value for file,value in packet['code'].items()) and sha(REFERENCE)==packet['source']
    archive=json.loads(REFERENCE.read_bytes());tol=archive['comparison_tolerances']['E_H_and_nonzero_distances_relative'];rows=[];controls=[]
    assert tol==1e-6
    def test(tag,key,new,old):
        if old==0:assert new==0;err=0.
        else:err=abs(new/old-1)
        return dict(model=tag,test=key,rel=err,passed=err<=tol)
    for tag,data in packet['cases'].items():
        for a,b in zip(data['primary']['rows'],data['refined']['rows']):
            for key in ('E','D_A_Mpc','affine','scalar_gradient','scalar_focusing','no_scalar_focusing_D_A_Mpc'):controls.append(test(tag,'refine '+key,a[key],b[key]))
            z=a['z'];w=1+z
            if tag in ('deSitter','EdS'):
                if tag=='deSitter':expected=(1-1/w);affine=expected
                else:expected=2*(1-1/np.sqrt(w))/w;affine=2*(1-w**-2.5)/5
                controls+= [test(tag,'analytic distance',a['D_A_Mpc'],expected*299792.458/70),test(tag,'analytic affine',a['affine'],affine)]
        for a,b in zip(data['primary']['clocks'],data['refined']['clocks']):
            for key in ('physical','no_scalar_focusing'):
                assert (a[key] is None)==(b[key] is None)
                if a[key]:controls.extend(test(tag,'refine first area crossing '+col,a[key][col],b[key][col]) for col in ('redshift','affine'))
    for item in archive['cases']:
        tag=item['model']; data=packet['cases'][tag]['primary'];control=packet['cases']['LCDM_for_'+tag]['primary']['rows']
        assert [r['z'] for r in item['predictions']]==TIMES.tolist()
        for predicted,ref,lcdm in zip(data['rows'],item['predictions'],control):
            z=ref['z']; checks=[test(tag,'saved '+key,predicted[key],ref[key]) for key in ('E','D_A_Mpc')]
            rows.append(dict(model=tag,z=z,checks=checks,vs_flat_LCDM_distance_pct=None if not z else 100*(predicted['D_A_Mpc']/lcdm['D_A_Mpc']-1),
                direct_scalar_distance_pct=None if not z else 100*(predicted['D_A_Mpc']/predicted['no_scalar_focusing_D_A_Mpc']-1)))
    assert all(r['passed'] for r in controls) and all(v['passed'] for r in rows for v in r['checks'])
    put('optical-comparison.json',dict(forecast=sha(ROOT/'optical-forecast.json'),tol=tol,controls=controls,rows=rows))
    for r in rows:
        if r['z']==1.:print(r,packet['cases'][r['model']]['primary']['clocks'])
if __name__=='__main__':{'freeze':freeze,'compare':compare}[sys.argv[1]]()
