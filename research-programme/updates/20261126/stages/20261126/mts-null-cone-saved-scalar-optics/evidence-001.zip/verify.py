from pathlib import Path
import hashlib,json,re
ROOT=Path(__file__).resolve().parent
def sha(path):
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
def read(name):return json.loads((ROOT/name).read_bytes())
def finish():
    assert not (ROOT/'__pycache__').exists()
    for target in re.findall(r'\]\(([^)]+)\)',(ROOT/'RESULTS.md').read_text(encoding='utf-8')):
        if not target.startswith('https:'):assert (ROOT/target).is_file()
    files={p.name:sha(p) for p in sorted(ROOT.iterdir()) if p.is_file() and p.name!='seal.json'}
    if (ROOT/'seal.json').exists():assert read('seal.json')['files']==files
    else:
        with (ROOT/'seal.json').open('x',encoding='utf-8') as stream:json.dump({'files':files},stream,sort_keys=True,indent=2)
    print(len(files),'files; seal',sha(ROOT/'seal.json'))
if __name__=='__main__':
    f=read('optical-forecast.json');s=read('optical-comparison.json')
    assert all(sha(ROOT/name)==value for name,value in f['code'].items())
    assert sha(ROOT.parent/'cosmology-lab-handoff-20261020'/'reference-cases.json')==f['source']
    assert s['forecast']==sha(ROOT/'optical-forecast.json') and s['tol']==1e-6
    assert len(s['rows'])==14 and all(c['passed'] for row in s['rows'] for c in row['checks'])
    assert len(s['controls'])==324 and all(c['passed'] for c in s['controls'])
    assert all(all(q['clock_excess_pct']>0 for q in f['cases'][tag]['primary']['clocks']) for tag in ('ParentScalar_Lambda_zero','ParentScalar_Lambda_free'))
    finish()
