from window_io import *

def verify():
    for key in ('method.json','gravity-freeze.json','prediction-freeze.json'):check(key)
    for root,sig in SIGS.items():assert sha(root/'seal.json')==sig
    for name,key in [('gravity-inputs.json','additional'),('photon-provenance.json','inputs'),('scores.json','inputs')]:
        for path,h in json.loads((ROOT/name).read_bytes())[key].items():assert sha(BASE/path)==h,path
    for tag in ('matched','wave'):
        with np.load(sealed(EXT,'incident-end-'+tag+'.npz')) as ar:
            assert ar['t']==END and ar['bins'].shape==(77,*ar['common'].shape)
            assert np.isfinite(ar['bins']).all()
        for grid in ('p16','p32'):
            for sub in (2,4):
                suffix=f'{tag}-{grid}-{sub}';prior=sealed(CARRY,'carry-'+suffix+'.npz')
                with np.load(ROOT/('carry-'+suffix+'.npz')) as combined:
                    offset=0
                    for idx in range(15):
                        name=f'part-{suffix}-{idx+1:02}.npz';check(name+'.receipt')
                        with np.load(ROOT/name) as ar:
                            assert ar['parent_hash']==sha(prior) and sha(ROOT/name)==combined['part_hashes'][idx]
                            t=ar['t'];assert np.array_equal(t[[0,-1]],edges[idx:idx+2])
                            cut=int(idx>0);count=len(t)-cut
                            assert np.array_equal(combined['obs'][offset:offset+count],ar['obs'][cut:])
                            assert max(ar['seam'])<=.5 and ar['rhs_identity_pct']<=.5
                            if tag=='matched':
                                assert np.array_equal(combined['memories'][offset:offset+count],ar['memories'][cut:])
                            offset+=count
                        prior=ROOT/name
                    assert offset==len(combined['t']) and np.all(np.diff(combined['t'])>0)
                    fields=('final','final_lag','final_shape','final_memory') if tag=='matched' else ('ordinary_end','lag_end','shape_end')
                    with np.load(prior) as ar,np.load(sealed(CARRY,'carry-'+suffix+'.npz')) as initial:
                        for key in fields:assert np.array_equal(ar[key],combined[key]) and np.isfinite(ar[key]).all()
                        lag=fields[1];assert combined[lag].shape[-2:]==(77,69) and np.all(np.max(abs(combined[lag]-initial[lag]),axis=2)>0)
                if tag=='matched':
                    hs=json.loads((ROOT/('history-'+suffix+'.json')).read_bytes())
                    assert len(hs)==15 and hs[-1]['fresh_delay_fraction']==1. and max(max(r['pct_mean']+r['pct_current']) for r in hs)<=.5
    for name in ('primary','time','angle'):
        f=f'photon-{name}.npz'
        with np.load(ROOT/f) as ar,np.load(sealed(CARRY,f)) as prior:
            n=len(ar['labels']);entry=ar['hierarchy_at_entry'];old=prior['hierarchy_at_exit'][:,2*n:]
            assert n==16 and np.array_equal(entry[:,:n],old) and np.array_equal(entry[:,2*n:],old)
            assert not entry[:,n:2*n].any() and old[1:].any() and ar['additivity_pct']<.5
            assert np.array_equal(ar['clock'],[START,END]) and np.isfinite(ar['hierarchy_at_exit']).all()
            if name=='primary':assert 0<=ar['adjoint_error_pct']<.5
    s=json.loads((ROOT/'scores.json').read_bytes());assert s['prediction_hash']==sha(ROOT/'prediction-freeze.json')
    assert len(s['rows'])==48 and len(s['controls'])==144 and s['tolerance_pct']==.5 and s['launch_cap_pct']==.163
    for r in s['rows']:
        assert r['pass_gap']==(max(r['route_gap_pct'])<=.5) and r['pass_size']==(max(r['size_pct_launch'])<=.163)
    assert all(r['passed']==(max(r['error_original_pct'])<=.5) for r in s['controls'])
    restart=json.loads((ROOT/'restart90.json').read_bytes())
    def checked_refs(value):
        if isinstance(value,dict):
            if 'file' in value and 'sha256' in value:assert sha(BASE/value['file'])==value['sha256']
            for item in value.values():checked_refs(item)
    assert restart['epoch']==END
    checked_refs(restart)
    budget=json.loads((ROOT/'balance.json').read_bytes())
    assert budget['scores']==sha(ROOT/'scores.json') and len(budget['terms'])==2
    for entry in budget['terms']:
        row=next(r for r in s['rows'] if r['grid']==entry['grid'] and r['sub']==4 and r['stress']=='comp' and r['kind']=='cumulative' and r['setting']=='primary')
        assert max(entry['cumulative_replay_pct']+entry['increment_replay_pct'])<1e-5
        signed=np.sum([r['signed_pct'] for r in entry['terms']],axis=0)
        assert np.max(abs(signed-row['route_gap_pct']))<1e-5
    with np.load(ROOT/'peak-attribution.npz') as pk:
        assert np.max(abs(pk['edges']-edges))<1e-8 and error(pk['carried']+pk['by_drive'].sum((0,2)),pk['direct'])<1e-8
    print('Verified 120 segment links, terminal tensors, 77 bins, delays, inherited photons, projection freeze and checks.')
    if '--seal' in sys.argv:
        assert (ROOT/'RESULTS.md').exists() and not any(f.name.endswith('.partial') for f in ROOT.iterdir())
        put('seal.json',dict(files={f.name:sha(f) for f in sorted(ROOT.iterdir()) if f.is_file() and f.name!='seal.json'}))
        print('Seal',sha(ROOT/'seal.json'))
if __name__=='__main__':verify()
