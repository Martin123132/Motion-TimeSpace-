from window_io import *
from scipy.interpolate import make_interp_spline,CubicSpline
from scipy.integrate import solve_ivp
from scipy.special import roots_laguerre,expit
from copy import copy

def spline(t,values):
    out=make_interp_spline(np.log(t),values,k=5);out.extrapolate=False
    return out

class History:
    def __init__(self,grid,sub):
        self.series=[]
        with np.load(oldio.pin(oldio.PRE,f'partial-{grid}-{sub}.npz')) as ar:
            tr=ar['traces'];self.append(tr[:,0,9].real,tr[:,:,0])
        with np.load(sealed(CARRY,f'carry-matched-{grid}-{sub}.npz')) as ar:
            tr=ar['physical_current_phase'];self.append(tr[:,0,1].real,tr[:,:,0])
        self.old_end=self.series[-1].x[-1]
    def append(self,phase,cur):
        if self.series:assert abs(self.series[-1].x[-1]-phase[0])<2e-10
        self.series.append(CubicSpline(phase,cur,axis=0,extrapolate=False))
    def delayed(self,phase):
        series=self.series
        assert np.min(phase)>=series[0].x[0]-2e-10 and np.max(phase)<=series[-1].x[-1]+2e-10
        inds=np.minimum(len(series)-1,np.searchsorted([s.x[-1] for s in series],phase))
        result=np.empty((len(phase),4),complex)
        for index in np.unique(inds):
            take=inds==index;s=series[index]
            result[take]=s(np.clip(phase[take],s.x[0],s.x[-1]))
        return result
    def mean(self,phase):
        lo=phase-np.pi;hi=phase;assert lo.min()>=self.series[0].x[0]-2e-10 and hi.max()<=self.series[-1].x[-1]+2e-10
        value=np.zeros((len(phase),4),complex)
        for curve in self.series:
            l=np.maximum(lo,curve.x[0]);r=np.minimum(hi,curve.x[-1]);valid=l<r
            if np.any(valid):
                anti=curve.antiderivative();value[valid]+=anti(r[valid])-anti(l[valid])
        return value/np.pi

def setup(p,grid,sub,tag,bank):
    matched=tag=='matched'
    src=p.Host(grid,sub) if matched else copy(p.old.source(grid))
    host=src.matched if matched else src
    host.flow=copy(host.flow);src.flow=flow=host.flow
    raw=lambda name:sealed(EXT,'material/'+name+'-heavy.npz') if matched else oldio.pin(oldio.PAD,'material-halfstep/'+name+'-heavy.npz')
    with np.load(raw('forcing')) as f,np.load(raw('radiation')) as r:
        t=f['eta'];assert np.array_equal(t,r['eta']) and t[0]<START<END<t[-1]
        bg=f['background'].T;names=f['bgkeys'].tolist();vals=np.concatenate((f['values'][:,:,0].T,r['values'][:,:,0].T),axis=1)
        assert f['keys'].tolist()+r['keys'].tolist()==list(flow.qkeys)
    a=bg[:,names.index('a')];meta=json.loads(p.old.KIN.ti.parent.pin('radiation-background.json').read_bytes())['heavy']
    nodes,w=roots_laguerre(48);measure=w*nodes*expit(nodes)**2;am=a*meta['mass_over_temperature'];eps=np.hypot(nodes,am[:,None])
    pref=meta['massless_limit_coeff']/(a*a*(7*np.pi**4/120))
    thermal=[pref*term for term in [(eps*nodes**2)@measure,nodes**3@measure,(nodes**4/eps)@measure,(am[:,None]**2*nodes**2/eps)@measure]]
    assert np.max(abs(thermal[0]/(3*bg[:,names.index('enm')])-1))<1e-6
    assert names+['nuE','nuJ','nuS','nuD']==list(flow.bgkeys)
    flow.bg=spline(t,np.column_stack([bg,*thermal]));forcing=spline(t,vals[:,:,None])
    if matched:
        with np.load(sealed(EXT,'blind-source.npz')) as ar:restore=spline(ar['eta'],ar['restore'])
        idx=flow.qkeys.index('U')
        def with_restore(log):
            values=forcing(log);values[...,idx,0]+=restore(log);return values
        flow.q=with_restore
    else:flow.q=forcing
    bank.bg=CubicSpline(np.log(t),bg[:,[names.index('a'),names.index('enu')]],extrapolate=False)
    with np.load(sealed(EXT,'incident-'+tag+'-16.npz')) as ar:
        log=np.log(ar['t']);assert ar['t'][0]==START and ar['t'][-1]==END and np.array_equal(bank.q,ar['q']) and bank.k==ar['k']
        bank.micro=CubicSpline(log,ar['micro'],extrapolate=False);bank.sw=CubicSpline(log,ar['Sw'],extrapolate=False)
        flow.drive=CubicSpline(log,ar['S'][:,:,None],extrapolate=False)
    host.quads=lambda t:np.zeros((len(t),2),complex)
    host.stress=lambda t:np.zeros((len(t),4),complex)
    if not matched:return src,None
    with np.load(oldio.pin(oldio.PAD,'material-halfstep/forcing-heavy.npz')) as ar:
        src.external=spline(ar['eta'],ar['values'][[ar['keys'].tolist().index(key) for key in src.micro_keys],:,0].T)
    hist=History(grid,sub)
    with np.load(oldio.pin(oldio.SOURCE,'exact-phase-extension.npz')) as ar:
        hist.angle=CubicSpline(ar['heavy_efold'],ar['phase_h'],extrapolate=False)
        hist.rho0=ar['matching_density'].item();assert hist.rho0==flow.rho0
    scale=lambda t:flow.bg(np.log(t))[...,names.index('a')]
    hub=lambda t:flow.bg(np.log(t))[...,names.index('h')]
    with np.load(sealed(CARRY,f'oscillator-{grid}-{sub}.npz')) as ar:
        assert ar['t'][-1]==START and ar['rho0']==hist.rho0
        mass=np.sqrt(ar['mass2'][-1])/ar['a'][-1];left=[ar['field'][-1],ar['velocity'][-1]]
        hist.origin=ar['phase_origin'].item()
    ode=solve_ivp(lambda t,y:(y[1],-2*hub(t)*y[1]-(mass*scale(t))**2*y[0]),(START,END),left,method='DOP853',rtol=2e-12,atol=[1e-16,1e-15],dense_output=True,max_step=.0015)
    assert ode.success and np.array_equal(ode.y[:,0],left)
    src.osc=lambda t:(hub(t),(mass*scale(t))**2,*ode.sol(t))
    ts=np.array([START,END]);hs,m2,field,vel=src.osc(ts);phase=hist.angle(np.log(scale(ts)))-hist.origin
    assert abs(phase[0]-hist.old_end)<2e-10
    pack(f'oscillator-{grid}-{sub}.npz',t=ts,a=scale(ts),hub=hs,mass2=m2,field=field,velocity=vel,phase=phase,rho0=hist.rho0,phase_origin=hist.origin)
    with np.load(sealed(EXT,'shear-extension.npz')) as ar:shear=CubicSpline(ar['eta'],ar['mass_normalized_shear'],extrapolate=False)
    def coeff(t):
        out=np.zeros((len(t),5),complex);out[:,4]=shear(t);return out
    host.coeff=list(host.coeff);host.coeff[-1]=coeff
    return src,hist
