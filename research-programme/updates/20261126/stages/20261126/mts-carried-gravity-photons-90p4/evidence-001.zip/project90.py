from window_io import *
from scipy.interpolate import CubicSpline
from scipy.linalg import solve_banded

def modules():
    sys.path.insert(0,str(oldio.PHOT));oldio.pin(oldio.PHOT,'predict.py');import predict as ph
    return ph

def new_sources(ph,at,labels):
    rows={};routes=('comp_momentum','comp_density','null_momentum','null_density')
    for grid in ('p16','p32'):
        for sub in (2,4):
            suffix=f'{grid}-{sub}.npz'
            with np.load(ROOT/('carry-matched-'+suffix)) as mat,np.load(ROOT/('carry-wave-'+suffix)) as ref:
                t=mat['t'];assert np.array_equal(t,ref['t']) and min(at.ravel())>=t[0] and max(at.ravel())<=t[-1]
                for j,label in enumerate(routes):
                    read=lambda arr,idx:ph.source_piece(t,arr[:,idx],j%2)(at)
                    rows[f'{grid}-{sub}-{label}']=read(mat['obs'],j)-read(ref['obs'],j%2)
    return np.stack([rows[label] for label in labels],axis=2)

def run():
    check('gravity-freeze.json');ph=modules();proj=ph.proj;gate=ph.gate
    scale,eta,medium,peak,weights=proj.measure('heavy')
    with np.load(sealed(EXT,'incident-matched-16.npz')) as ar:k=ar['k'].item()
    with np.load(ph.track(ph.cell89.curve('p32','base'))) as ar:high=ar['eta']
    cnt=round((END-START)/(high[-1]-high[-2]));forecast_grid=np.linspace(START,END,cnt+1)
    for setting in ph.SETTINGS:
        order,sub,stride=gate.transfer.prior.SETTINGS[setting]
        axis=np.unique(np.r_[proj.base_axis(scale,eta,sub),forecast_grid[::stride],START,END])
        start,end=np.searchsorted(axis,[START,END]);assert np.array_equal(axis[[start,end]],[START,END])
        rates,nodes=proj.coefficients(axis,medium,k);bands=proj.transfer.stages(order)
        with np.load(sealed(CARRY,'photon-'+setting+'.npz')) as prior:
            assert prior['clock'][-1]==START and np.array_equal(scale,prior['scale'])
            labels=prior['labels'].tolist();nk=len(labels);assert nk==16
            incoming=prior['hierarchy_at_exit'][:,2*nk:];early=prior['cumulative'][eta<=START]
        boundary=np.concatenate((incoming,np.zeros_like(incoming),incoming),axis=1)
        assert np.any(incoming[1:]) and np.array_equal(boundary[:,:nk],boundary[:,2*nk:])
        nc=3*nk
        force=np.zeros((end-start,nodes.shape[1],nc,2),complex)
        force[:,:,nk:2*nk]=new_sources(ph,nodes[start:end],labels)
        force[:,:,2*nk:]=force[:,:,nk:2*nk]
        integ=np.diff(axis)[start:end,None,None,None]*np.einsum('st,ntch->nsch',proj.RAD,force)
        count=bands.shape[-1]//2;assert count==len(incoming)
        state=np.empty((count,2*nc));state[:,::2]=boundary.real;state[:,1::2]=boundary.imag
        right=np.empty((2*count,2*nc),order='F')
        slots=np.full(len(axis),-1);pos=np.searchsorted(axis,eta);assert np.array_equal(axis[pos],eta);slots[pos]=np.arange(len(eta))
        spectra=np.zeros((len(scale),nc,2),complex)
        spectra[eta<=START,:nk]=early;spectra[eta<=START,2*nk:]=early
        for begin in range(start,len(rates),48):
            guard();stop=min(begin+48,len(rates));matrices=(rates[begin:stop].reshape(-1,8)@bands.reshape(8,-1)).reshape(-1,11,2*count);matrices[:,5]+=1
            for step,mat in enumerate(matrices,begin):
                if step==end:terminal=state[:,::2]+1j*state[:,1::2]
                right[::2]=state;right[1::2]=state
                if step<end:
                    for row,col,factor in ((0,0,4.),(2,1,4*k/3),(4,1,4*k/3)):
                        driving=factor*integ[step-start,:,:,col]
                        right[row:row+2,::2]+=driving.real;right[row:row+2,1::2]+=driving.imag
                state=solve_banded((5,5),mat,right,check_finite=False)[1::2]
                if slots[step+1]>=0:spectra[slots[step+1]]=(state[[0,2],::2]+1j*state[[0,2],1::2]).T
        assert np.isfinite(spectra).all() and np.isfinite(terminal).all()
        residual=error(spectra[:,2*nk:]-spectra[:,:nk],spectra[:,nk:2*nk])
        assert residual<=.5
        adj=None
        if setting=='primary':
            active=(axis[:-1]>=axis[start])&(axis[1:]<=axis[end])
            dual,where,kern=proj.backward(axis,eta,weights,medium,k,proj.transpose_bands(bands),snapshot=[start],active=active)
            assert np.array_equal(where[active],nodes[start:end]);adj=boundary.T@dual[start]+np.einsum('nhtj,ntch->cj',kern[active],force)
            assert np.max(abs(CubicSpline(scale,spectra)(peak)-adj)/abs(adj))<=.005
            active_indices=np.arange(start,end+1)
            cuts=np.array([active_indices[np.argmin(abs(axis[active_indices]-edge))] for edge in edges])
            assert cuts[0]==start and cuts[-1]==end and np.all(np.diff(cuts)>0)
            pieces=[]
            for left,right_edge in zip(cuts,cuts[1:]):
                take=slice(left-start,right_edge-start)
                pieces.append(np.einsum('nhtj,ntch->chj',kern[active][take],force[take,:,nk:2*nk]))
            parts=np.asarray(pieces);carried=incoming.T@dual[start]
            assert error(carried+parts.sum((0,2)),adj[2*nk:])<1e-8
            pack('peak-attribution.npz',labels=labels,edges=axis[cuts],carried=carried,by_drive=parts,direct=adj[2*nk:],channels=['Phi rate','Psi lapse'],output=['photon energy','photon current'])
        pack('photon-'+setting+'.npz',scale=scale,labels=labels,previous=spectra[:,:nk],increment=spectra[:,nk:2*nk],cumulative=spectra[:,2*nk:],hierarchy_at_entry=boundary,hierarchy_at_exit=terminal,clock=[START,END],additivity_pct=residual,adjoint_error_pct=np.max(abs(CubicSpline(scale,spectra)(peak)-adj)/abs(adj))*100 if adj is not None else -1.)
        print('frozen channel vectors',setting,flush=True)
    put('photon-provenance.json',dict(inputs={**oldio.used,**ph.used},parent_seals=SIGS[CARRY],k=k,window=[START,END]))
    freeze('prediction-freeze.json',['PROTOCOL.md','gravity-freeze.json','project90.py','score90.py','photon-provenance.json','peak-attribution.npz']+[f'photon-{s}.npz' for s in ph.SETTINGS])
if __name__=='__main__':run()
