from sources90 import setup
from stepper import *
import sys

def branch(p,grid,sub,tag,bank):
    suffix=f'{tag}-{grid}-{sub}';previous=sealed(CARRY,'carry-'+suffix+'.npz')
    src,history=setup(p,grid,sub,tag,bank);first_offset=None;filenames=[];budget=[]
    for part,(left,right) in enumerate(zip(edges,edges[1:]),1):
        name=f'part-{suffix}-{part:02}.npz';receipt=name+'.receipt'
        if not (ROOT/receipt).exists():
            evolve(p,src,history,bank,grid,sub,tag,left,right,previous,name)
            freeze(receipt,[name,'method.json'])
        check(receipt);path=ROOT/name
        with np.load(path) as ar:
            assert ar['parent_hash'].item()==sha(previous) and np.array_equal(ar['t'][[0,-1]],[left,right])
            if history is not None:
                tr=ar['physical_current_phase'];phase=tr[:,0,1].real;cur=tr[:,:,0];actual=ar['memories'][:,:,0]
                assert phase[-1]-phase[0]<np.pi
                history.append(phase,cur);independent=history.mean(phase)
                if first_offset is None:first_offset=actual[0]-independent[0]
                delta=np.max(abs(actual-independent-first_offset),axis=0);peak=np.max(abs(cur),axis=0);mean_peak=np.max(abs(actual),axis=0)
                row=dict(part=part,window=[left,right],pct_current=(100*delta/peak).tolist(),pct_mean=(100*delta/mean_peak).tolist(),fresh_delay_fraction=float(np.mean(phase-np.pi>history.old_end)))
                budget.append(row)
                assert max(row['pct_current']+row['pct_mean'])<=.5,row
        previous=path;filenames.append(name)
        if part in (1,5,10,15):print(suffix,part,flush=True)
    series=('t','obs','physical_current_phase')+(('memories',) if history is not None else ())
    out={key:[] for key in series}
    seams=[];identities=[];part_hashes=[]
    for idx,name in enumerate(filenames):
        with np.load(ROOT/name) as ar:
            for key in series:out[key].append(ar[key][int(idx>0):])
            seams.append(ar['seam']);identities.append(ar['rhs_identity_pct'].item());part_hashes.append(sha(ROOT/name))
            final={k:ar[k] for k in ar.files if k.startswith('final') or k.endswith('_end')}
    assert np.all(np.diff(np.concatenate(out['t']))>0)
    pack('carry-'+suffix+'.npz',**{k:np.concatenate(v) for k,v in out.items()},**final,seams=seams,identities=identities,part_hashes=part_hashes)
    if budget:put('history-'+suffix+'.json',budget)
    print('complete',suffix,flush=True)

def run():
    freeze('method.json',['PROTOCOL.md','window_io.py','stepper.py','sources90.py','evolve90.py'])
    mod=oldio.prefix();p=mod.import_at(mod.OLD,'partial')
    for grid in ('p16','p32'):
        for tag in ('matched','wave'):
            bank=p.MatchedBank() if tag=='matched' else p.joint.Bank()
            for sub in (2,4):branch(p,grid,sub,tag,bank)
    inputs={str(path.relative_to(BASE)):value for path,value in SIGS.items()}
    put('gravity-inputs.json',dict(parent_seals=inputs,additional=oldio.used))
    freeze('gravity-freeze.json',['method.json','gravity-inputs.json']+sorted(f.name for pattern in ('carry-*.npz','*.receipt','oscillator-*.npz','history-*.json') for f in ROOT.glob(pattern)))
if __name__=='__main__':run()
