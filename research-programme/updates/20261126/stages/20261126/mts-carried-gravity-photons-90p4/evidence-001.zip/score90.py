from window_io import *
from project90 import modules
from scipy.interpolate import CubicSpline
import csv

def score():
    check('prediction-freeze.json');ph=modules();g=ph.gate
    _,axis,weights,_=ph.proj.old.get_media();measure=g.previous.make_measure(axis,weights)
    norm=lambda val:g.mag(val,measure)
    gridnames=('p16','p32')
    with ph.track(g.pin(g.FROZEN,'window-readouts.csv')).open() as f:
        launch={r['gravity']:float(r['launch_norm']) for r in csv.DictReader(f) if r['model']=='MTS-minus-baseline' and r['output']=='joint'}
    rows=[];controls=[];cache={}
    for setting in ph.SETTINGS:
        with np.load(ROOT/f'photon-{setting}.npz') as new,np.load(sealed(CARRY,f'photon-{setting}.npz')) as prev,np.load(ph.track(ph.cell89.pin(f'photon-{setting}.npz'))) as archive:
            scale=new['scale'];assert np.array_equal(scale,prev['scale']) and np.array_equal(scale,archive['grid'])
            vis=lambda arr:CubicSpline(scale,arr)(axis)
            labels=new['labels'].tolist()
            for grid in gridnames:
                a=archive['values'][:,archive['labels'].tolist().index([grid,'primary'])]
                small=norm(vis(a[:,[0,1,2]].sum(1)))
                for sub in (2,4):
                    for stress in ('comp','null'):
                        vals={}
                        for route in ('momentum','density'):
                            label=f'{grid}-{sub}-{stress}_{route}';idx=labels.index(label);prior=vis(prev['cumulative'][:,prev['labels'].tolist().index(label)])
                            for kind in ('previous','increment','cumulative'):
                                vec=vis(new[kind][:,idx]);vals[kind,route]=vec
                                cache[grid,sub,stress,route,kind,setting]=vec
                            vec=vals['previous',route];replay=100*norm(vec-prior)/small
                            controls.append(dict(test='saved photon hierarchy without new forcing on extended mesh',grid=grid,sub=sub,stress=stress,route=route,setting=setting,error_original_pct=replay.tolist(),passed=bool(max(replay)<=.5)))
                        for kind in ('increment','cumulative'):
                            mom=vals[kind,'momentum'];den=vals[kind,'density'];gap=den-mom;pct=100*norm(gap)/small
                            sizes=[100*norm(v)[2]/launch[grid] for v in (mom,den)]
                            rows.append(dict(grid=grid,setting=setting,sub=sub,stress=stress,kind=kind,route_gap_pct=pct.tolist(),pass_gap=bool(max(pct)<=.5),size_pct_launch=sizes,pass_size=bool(max(sizes)<=.163),momentum_size_pct_small=(100*norm(mom)/small).tolist(),density_size_pct_small=(100*norm(den)/small).tolist()))
                for sub in (2,4):
                    for stress in ('comp','null'):
                        for route in ('momentum','density'):
                            for kind in ('increment','cumulative'):
                                key=(grid,sub,stress,route,kind)
                                for lbl,ref in [('time/angle',(*key,'primary'))] if setting!='primary' else []:
                                    controls.append(control(lbl,key,setting,ref,cache,norm,small))
                                if setting=='primary':
                                    if sub==4:controls.append(control('subdivision',key,setting,(grid,2,*key[2:],'primary'),cache,norm,small))
                                    if grid=='p32':controls.append(control('gravity',key,setting,('p16',*key[1:],'primary'),cache,norm,small))
    put('scores.json',dict(prediction_hash=sha(ROOT/'prediction-freeze.json'),order=['energy','current','joint'],normalization='unchanged original small momentum correction, not the new-window norm',tolerance_pct=.5,launch_cap_pct=.163,rows=rows,controls=controls,inputs={**oldio.used,**ph.used}))
    for r in rows:
        if r['setting']=='primary' and r['sub']==4:print(r['grid'],r['stress'],r['kind'],r['route_gap_pct'],r['size_pct_launch'],flush=True)

def control(label,key,setting,ref,cache,norm,small):
    original=cache[ref];diff=norm(cache[*key,setting]-original)
    rel=100*diff/norm(original);pct=100*diff/small
    return dict(test=label,grid=key[0],sub=key[1],stress=key[2],route=key[3],kind=key[4],setting=setting,error_original_pct=pct.tolist(),own_scale_pct=rel.tolist(),passed=bool(max(pct)<=.5),own_scale_pass=bool(max(rel)<=.5))
if __name__=='__main__':score()
