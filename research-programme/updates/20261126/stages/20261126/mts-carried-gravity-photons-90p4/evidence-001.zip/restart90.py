from window_io import *

def run():
    check('prediction-freeze.json')
    states={}
    pathentry=lambda file:dict(file=str(file.relative_to(BASE)),sha256=sha(file))
    for grid in ('p16','p32'):
        for sub in (2,4):
            key=f'{grid}-{sub}'
            mat=ROOT/f'carry-matched-{key}.npz';wave=ROOT/f'carry-wave-{key}.npz'
            osc=ROOT/f'oscillator-{key}.npz'
            with np.load(mat) as ar,np.load(osc) as os:
                tr=ar['physical_current_phase'];phase=tr[:,0,1].real;idx=int(np.searchsorted(phase,phase[-1]-np.pi))
                assert 1<=idx<len(phase)-1 and abs(phase[-1]-os['phase'][-1])<1e-10
                hist=dict(source=pathentry(mat),key='physical_current_phase',current_column=0,phase_column=1,first_bracket_index=idx-1,last_index=len(phase)-1,delayed_time_bracket=ar['t'][idx-1:idx+1].tolist())
            states[key]=dict(matched=pathentry(mat),resolved=pathentry(wave),oscillator=pathentry(osc),history=hist)
    put('restart90.json',dict(epoch=END,perturbations=states,photons={s:pathentry(ROOT/f'photon-{s}.npz') for s in ('primary','time','angle')},photon_state='hierarchy_at_exit[:,2*len(labels):] is the cumulative state including all incident multipoles',incident={tag:pathentry(sealed(EXT,f'incident-end-{tag}.npz')) for tag in ('matched','wave')},frozen_source=pathentry(sealed(EXT,'blind-source.npz')),scope='End of common validated driving at 90.4. Future integration needs new native matched/wave support and frozen forecast. Use prior history until a full new phase period is available.'))
if __name__=='__main__':run()
