from functools import lru_cache
from pathlib import Path
from io import BytesIO
import json,hashlib,sys
import numpy as np
ROOT=Path(__file__).resolve().parent
BASE=ROOT.parent
EXT=BASE/'mts-matched-source-extension-90p4-20261126'
CARRY=BASE/'mts-carried-photon-window-89p65-20261126'
SIGS={EXT:'73460c2005854579ad058d2b1713db78db57b1f2b17c472f620a56dd7e1b52a4',CARRY:'eaea6794d8575dc50213b70bed708bffd881fffa318d57ac2c2faed0300ad2c7'}
def sha(file):
    with file.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
@lru_cache()
def sealed(folder,name):
    assert sha(folder/'seal.json')==SIGS[folder]
    f=folder/name;assert sha(f)==json.loads((folder/'seal.json').read_bytes())['files'][name];return f
sealed(CARRY,'carry_io.py');sys.path.insert(0,str(CARRY));import carry_io as oldio
oldio.PINS.update(SIGS)
START,END=89.65,90.4
edges=np.arange(1793,1809)/20
assert edges[0]==START and edges[-1]==END
def guard():
    oldio.guard();assert not (ROOT/'STOP-REQUESTED').exists()
def save(name,raw):
    guard();p=ROOT/name
    if p.exists():assert sha(p)==hashlib.sha256(raw).hexdigest(),name
    else:
        tmp=p.with_suffix(p.suffix+'.partial')
        with tmp.open('xb') as f:f.write(raw)
        tmp.rename(p)
def put(name,data):save(name,(json.dumps(data,sort_keys=True,indent=2,allow_nan=False,default=lambda x:x.item())+'\n').encode())
def pack(name,**fields):
    buf=BytesIO();np.savez_compressed(buf,**fields);save(name,buf.getvalue())
def freeze(name,files):put(name,{f:sha(ROOT/f) for f in files})
def check(name):
    for file,sig in json.loads((ROOT/name).read_bytes()).items():assert sha(ROOT/file)==sig,file
error=oldio.error
