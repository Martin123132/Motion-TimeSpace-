from window_io import *

def evolve(p,src,mem,bank,grid,sub,label,START,END,input_path,name):
    matched=mem is not None
    with np.load(input_path) as old:
        assert old['t'][-1]==START
        keys=('final','final_lag','final_shape','final_memory') if matched else ('ordinary_end','lag_end','shape_end')
        states=[old[k].copy() for k in keys];previous=old['obs'][-1]
        dt=old['t'][-1]-old['t'][-2]
    steps=int(round((END-START)/dt));assert steps==8*int(grid[1:])*sub
    t=np.linspace(START,END,steps+1)
    on=np.array([1.,1.,0.,0.]) if matched else np.zeros(2)
    grav=np.arange(len(on))%2==0;kk=src.kk;solver=p.old.Wave(src)
    observations=np.empty((len(t),len(on),14),complex);currents=np.empty((len(t),len(on),2),complex)
    memories=np.empty((len(t),len(on),2),complex) if matched else np.empty((0,2),complex)
    identity=0.
    for left in range(0,steps,24):
        guard();end=min(left+24,steps);edges=t[left:end+1];clock=np.empty(2*len(edges)-1);clock[::2]=edges;clock[1::2]=(edges[:-1]+edges[1:])/2
        log=np.log(clock);vel,slow,kernel,weights=bank.coeff(clock);micro=bank.micro(log);spectral=bank.sw(log)
        mat,bi,bn=p.old.operator(solver,clock,clock);mat[:,:13,p.old.QI]+=bi;mat[:,:13,p.old.QN]+=bn
        op=mat[:,:,:p.old.DIM].copy();bias=mat[:,:,-1].copy()
        bg,den,we,wj,e0,j0,slip0,us,fq=p.coefficients(src,clock)
        hub=bg['h'];eg=bg['eg'];nus=4*bg['er']+bg['nuS'];vh=bg['hv'];mass2=(bg['a']*bg['hm'])**2
        if matched:
            a=bg['a'];loga=np.log(a);rho=mem.rho0/a
            rate_a=src.flow.bg(log,1)[:,src.flow.bgkeys.index('a')]/(clock*a)
            theta=mem.angle(loga)-mem.origin;speed=mem.angle(loga,1)*rate_a
            delay=mem.delayed(theta-np.pi);ext=src.external(log)[:,3];ext_rate=src.external(log,1)[:,3]/clock
            acc=-2*hub*vh-mass2*bg['hb']
        inject=np.zeros((len(clock),p.old.DIM))
        for idx,value in [(1,(4/3+bg['eb']/eg)*kk),(4,src.wave/3),(6,kk),(8,bg['sv']),(9,-(bg['a']*bg['sm'])**2*bg['sb']),(10,vh),(11,-mass2*bg['hb']),(12,-hub)]:inject[:,idx]=value
        def rhs(i,state,observe=False):
            nonlocal identity
            fields,lag,shape=state[:3]
            stress=bank.stress(lag,shape,kernel[i],weights[i])*bg['enu'][i];stress[:,1]*=src.wave
            en=fields@we[i]+e0[i]+stress[:,0];cur=fields@wj[i]+j0[i]+stress[:,1]
            extra=0
            if matched:
                wave=(kk*vh[i]*fields[:,10]+ext[i])/rho[i];memory=state[3]
                delta=memory[:,0]-wave;extra=on*rho[i]*delta;en+=on*rho[i]*memory[:,1];cur+=extra
            ep=(us[i]-en/2-1.5*hub[i]*cur/kk)/den[i];phi=np.where(grav,fields[:,12],ep)
            psi=phi+slip0[i]+(stress[:,2]-eg[i]*fields[:,p.old.QI]-nus[i]*fields[:,p.old.QN])/kk
            pd=cur/(2*kk)-hub[i]*psi+fq[i]
            if observe:
                const=lambda x:np.broadcast_to(x,phi.shape)
                return np.stack([phi,ep,fields[:,12],psi,pd,en,cur,const(us[i]),const(den[i]),const(hub[i]),*stress.T],axis=-1),np.stack((wave,const(theta[i])),axis=-1) if matched else np.zeros((2,2))
            live=fields.copy();live[:,12]=phi;dx=live@op[i].T+bias[i]+(stress[:,2]/kk)[:,None]*inject[i];dx[:,12]+=(stress[:,1]+extra)/(2*kk)
            identity=max(identity,error(dx[:,12],pd))
            normal=live[:,p.N_IND].copy();normal[:,0]+=phi
            dl=bank.bin_rhs(lag,shape,normal,psi,vel[i],slow[i],micro[i])
            result=[dx,dl,p.adv(shape,src.wave)+spectral[i]]
            if matched:
                mean_rate=speed[i]*(wave-delay[i])/np.pi
                wr=(kk*(acc[i]*fields[:,10]+vh[i]*dx[:,10])+ext_rate[i])/rho[i]+rate_a[i]*wave
                pressure=(mean_rate-wr+hub[i]*delta)/kk
                result.append(np.stack((mean_rate,-delta-3*hub[i]*pressure),axis=-1))
            return result
        for j,width in enumerate(np.diff(edges)):
            pos=2*j;observations[left+j],currents[left+j]=rhs(pos,states,True)
            if matched:memories[left+j]=states[3]
            a=rhs(pos,states);b=rhs(pos+1,[x+width*y/2 for x,y in zip(states,a)]);c=rhs(pos+1,[x+width*y/2 for x,y in zip(states,b)]);d=rhs(pos+2,[x+width*y for x,y in zip(states,c)])
            for x,aa,bb,cc,dd in zip(states,a,b,c,d):x+=width/6*(aa+2*bb+2*cc+dd)
        observations[end],currents[end]=rhs(len(clock)-1,states,True)
    if matched:memories[-1]=states[3]
    seam=[error(observations[0,:,i],previous[:,i]) for i in range(14)]
    assert max(seam)<.5 and identity<.5 and np.isfinite(observations).all() and all(np.isfinite(x).all() for x in states),(label,grid,seam,identity)
    pack(name,parent_hash=sha(input_path),memories=memories,t=t,obs=observations,seam=seam,rhs_identity_pct=identity,physical_current_phase=currents,**dict(zip(keys,states)))
