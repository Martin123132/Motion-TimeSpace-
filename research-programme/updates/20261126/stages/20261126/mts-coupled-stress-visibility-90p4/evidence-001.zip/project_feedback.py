from pathlib import Path
import json
import sys
import numpy as np
from scipy.interpolate import make_interp_spline
from scipy.integrate import solve_ivp
from types import SimpleNamespace

OUT=Path(__file__).resolve().parent
BASE=OUT.parent
SOURCE=BASE/'mts-collisionless-shear-cauchy-20261126'
sys.path.insert(0,str(SOURCE))
import kinetics as kin
import early_source as spatial

KEYS=['hfield','hmoment','henergy','htrace','hJ','hshear','hJprime']
CUT=kin.CUT
assert kin.sha(SOURCE/'seal.json')=='fc5d536570b0ffbfd2cbf95d291911707f19b5b5c0c27be20d7311cdb4f88d1c'

def signed(name):
    path=SOURCE/name
    assert kin.sha(path)==json.loads((SOURCE/'seal.json').read_bytes())['files'][name]
    return path

def guard():
    kin.guard()
    assert not (OUT/'STOP-REQUESTED').exists()

def contract(op,call,bg,vel,mass2):
    prod=lambda a,b:call(op.product,a,b)
    deriv=lambda a,b:call(op.dg,a,b)
    pp=prod('phi','phi');ss=prod('psi','psi');sp=prod('phi','psi')
    pu=prod('phi','u');nq=3*pu+7.5*pp*vel
    nn=prod('n','n');grad=call(op.grad,'f','f');pot=mass2*prod('f','f')
    return np.array([prod('psi','u')+3*pu+vel*(-ss/2+3*sp+7.5*pp),
        deriv('psi','f')-deriv('phi','f')-mass2*(prod('psi','f')-3*prod('phi','f')+bg*(-ss/2-3*sp+1.5*pp)),
        vel*nq+(nn+grad+pot)/2,-2*vel*nq-nn+grad+2*pot,-deriv('n','f'),call(op.shear,'f','f'),-deriv('nd','f')-deriv('n','fd')])

def run(res,par,hist,seed):
    guard()
    old=kin.data(signed('matched-'+('primary' if res==640 else 'fine')+'.npz'))
    new=kin.data(signed(f'coupled-matched-{res}.npz'))
    time=old['t'];grid=par.k
    assert np.array_equal(time,new['t']) and np.array_equal(grid,new['k']) and np.array_equal(grid,old['k'])
    def pull(ar,key):return ar['values'][:,ar['keys'].tolist().index(key)]
    dt=(time-CUT)[:,None]
    x0=pull(old,'X');dx=pull(new,'X')-x0
    deriv_spl=make_interp_spline(time,np.stack((x0,dx),axis=1),k=5)
    coef=par.h0**2-par.pressure
    def back(elapsed):
        fac=1+par.h0*elapsed+coef*elapsed**2/4
        return fac,par.a0*fac,(par.h0+coef*elapsed/2)/fac
    def rhs(tm,vec):
        _,scale,hub=back(tm-CUT);m2=(scale*par.m)**2
        bg,vel,field,rate,df,dw=vec.reshape(6,-1)
        xx,delta=deriv_spl(tm)
        return np.stack([vel,-2*hub*vel-m2*bg,rate,-2*hub*rate-(grid**2+m2)*field-vel*xx,dw,-2*hub*dw-(grid**2+m2)*df-vel*delta]).ravel()
    start=np.vstack((seed[:4],np.zeros_like(seed[:2])))
    sol=solve_ivp(rhs,(time[0],time[-1]),start.ravel(),t_eval=time,rtol=1e-12,atol=2e-25,max_step=1/res,method='DOP853')
    assert sol.success
    bg,vel,field,rate,df,dw=sol.y.reshape(6,-1,len(time)).transpose(0,2,1)
    fac,scale,hub=back(dt);m2=(scale*par.m)**2
    dg0=pull(old,'k_sigma')
    sig_delta=pull(new,'k_sigma')-dg0
    def chart(sigma,xx,pig,pir,shear,field,rate,eta0):
        eta_rate=(sigma-xx)/3
        integ=make_interp_spline(time,eta_rate,k=5).antiderivative()
        alpha=sigma/grid**2
        phi=eta0+(integ(time)-integ(CUT))-hub*alpha
        slip=((par.weights[2]*pig+par.weights[3]*pir)/fac**2+1.5*shear)/grid**2
        psi=phi-slip
        pd=eta_rate+(3*hub**2+par.pressure/fac**2)*alpha/2-hub*psi
        fg=field+vel*alpha;normal=rate+(-3*hub*vel-m2*bg)*alpha
        return dict(f=fg,n=normal,u=normal-3*vel*phi,phi=phi,psi=psi,fd=normal+vel*psi,nd=-2*hub*normal-(grid**2+m2)*fg-m2*bg*psi+3*vel*pd)
    tangent=par.forc[0]+dt*par.forcp[0]
    base=chart(dg0,x0,tangent,pull(old,'pir'),pull(old,'S'),field,rate,hist.data['etak'][-1]/grid)
    delta=chart(sig_delta,dx,pull(new,'pig')-tangent,pull(new,'pir')-pull(old,'pir'),pull(new,'S')-pull(old,'S'),df,dw,0.)
    assert all(np.count_nonzero(array[0])==0 for array in delta.values())
    model=SimpleNamespace(nodes=grid,shell=np.array(json.loads(spatial.pin('legs.json').read_bytes())['squared_radii']),first={})
    for name in base:
        for label,array in [('a',base[name]),('b',base[name]+delta[name]),('m',base[name]+delta[name]/2),('d',delta[name])]:
            model.first[label+name]=np.ascontiguousarray(array.T)
    vals=[];control=[];original=[];modes=[]
    for raw in spatial.Project(model).ops:
        guard()
        op=spatial.Fast(raw,model)
        def project(fun):return contract(op,fun,bg[:,0],vel[:,0],m2[:,0])
        sa=project(lambda method,l,r:method('a'+l,'a'+r))
        sb=project(lambda method,l,r:method('b'+l,'b'+r))
        inc=project(lambda method,l,r:method('d'+l,'m'+r)+method('m'+l,'d'+r))
        vals.append(inc);original.append(sa);modes.append(raw[1])
        control.append(np.max(abs(sb-sa-inc),axis=1)/np.maximum(np.max(abs(sa),axis=1),1e-100))
    arr=np.stack(vals,axis=-1);ref=np.stack(original,axis=-1)
    checks=np.asarray(control);assert np.isfinite(arr).all() and np.count_nonzero(arr[:,0])==0 and checks.max()<1e-11
    kin.parent.pack(OUT/f'projected-{res}.npz',t=time,k=modes,keys=KEYS,delta=arr,old=ref,direct_minus_polarized_on_source_scale=checks)
    print('projected',res,'peak source fraction by channel for photon mode',np.max(abs(arr[:,:,0]),axis=1)/np.max(abs(ref[:,:,0]),axis=1),flush=True)

if __name__=='__main__':
    guard()
    seed_file=kin.pin('clock-inputs.npz')
    kin.parent.receipt(OUT/'method.json',[OUT/'DESIGN.md',OUT/'project_feedback.py',seed_file,signed('kinetics.py'),signed('coupled_thomson.py'),signed('feedback-forecast.json'),spatial.pin('legs.json'),*[signed(n) for n in ('matched-primary.npz','matched-fine.npz','coupled-matched-640.npz','coupled-matched-1280.npz')]])
    par=kin.initial('matched');hist=kin.audit_sources.load_native('matched',before=CUT)
    for res in (640,1280):run(res,par,hist,kin.data(seed_file)['local_at_cut'])
    kin.parent.receipt(OUT/'source-freeze.json',[OUT/'method.json',OUT/'projected-640.npz',OUT/'projected-1280.npz'])
