from pathlib import Path
import sys
from unittest.mock import patch
import numpy as np
from scipy.interpolate import make_interp_spline

OUT=Path(__file__).resolve().parent
PARENT=OUT.parent
sys.path.insert(0,str(PARENT))
import project_feedback as projection
from project_feedback import kin,CUT,signed

def launch(tag):
    prep=kin.prepare(tag,12);par=prep.par
    _,_,hh,vel,weight=kin.geometry(prep,CUT)
    density,current,pressure,shear=kin.integrate_moments(weight,vel,prep.raw)
    vp=-hh*vel*(1-vel**2)
    density_p=(weight/vel*(prep.vel[:,0]-prep.raw[:,0]*(2*hh+vp/vel))).sum(axis=0)
    press_p=(weight*vel*(prep.vel[:,0]+prep.raw[:,0]*(vp/vel-2*hh))).sum(axis=0)/3
    shear_p=2*(weight*vel*(prep.vel[:,2]+prep.raw[:,2]*(vp/vel-2*hh))).sum(axis=0)/3
    mass=(3*pressure-density)/2;mass_p=(3*press_p-density_p)/2
    state=par.ini.copy();state[8:10]=[density,current];state[6:8]=prep.rad[:2]
    def evaluate(tm,vec,record=False):
        elapsed=tm-CUT;k=par.k
        xx,cd,bd,vb,ph,qg,rd,qr,dn,jn,gn,fd,fj=vec
        dif=par.h0**2-par.pressure
        fac=1+elapsed*par.h0+elapsed**2*dif/4;aa=par.a0*fac;hh=(par.h0+elapsed*dif/2)/fac
        md=mass+elapsed*mass_p;sn=shear+elapsed*shear_p;tb=par.back+elapsed*par.backp
        pig,pir,opacity,pb=par.forc+elapsed*par.forcp
        pir=prep.rad[2]+elapsed*par.forcp[1]
        gc,gb,gg,gr=par.weights/np.array([fac,fac,fac**2,fac**2])
        drag=opacity*(4*vb/3-qg)
        trace=dn+md
        if tag=='matched':
            ratio=(k/(par.m*aa))**2;hp=ratio/(np.sqrt(1+ratio)+1)**2*(fd+3*hh*fj/k)
            heavy=par.rho/aa*(fd+3*hp)/2;heavyq=par.rho/aa*fj
            edot,jdot=-3*hh*hp-k*fj-xx,-hh*fj+k*hp
        else:
            heavy=heavyq=0.;edot=jdot=np.zeros_like(xx)
        if record:
            sigma=xx+1.5*(gb*vb+gg*qg+gr*qr+jn+heavyq+prep.sq0+elapsed*prep.sqp)/k
            return np.stack((xx,dn,jn,trace,sn,sigma,pir,fd,fj,ph,qg))
        return np.stack((-hh*xx-(gc*cd+gb*bd)/2-gg*ph-gr*rd-par.slow-elapsed*par.slowp-trace-heavy,
            -xx,-xx-k*vb,-hh*vb+k*pb-gg/gb*drag,-4*xx/3-k*qg,k*(ph-2*pig)/3+drag,
            -4*xx/3-k*qr,k*(rd-2*pir)/3,-2*hh*trace-k*jn-(4*gn+tb)*xx/3,
            -2*hh*jn+k*((dn+2*md)/3-sn),-hh*(2*gn+tb),edot,jdot))
    return prep,state,evaluate

def integrate(tag,res,prep,start,rhs):
    method=kin.data(signed(f'coupled-{tag}-{res}.npz'))
    time=method['t'];state=start.copy();values=[]
    for idx,tm in enumerate(time):
        if idx%32==0:projection.guard()
        values.append(rhs(tm,state,True))
        if idx+1==len(time):break
        for sub in range(res//320):
            step=1/res;t0=tm+sub*step
            first=rhs(t0,state);second=rhs(t0+step/2,state+step*first/2)
            third=rhs(t0+step/2,state+step*second/2);fourth=rhs(t0+step,state+step*third)
            state+=step*(first+2*second+2*third+fourth)/6
    vals=np.array(values)
    assert np.isfinite(vals).all() and np.array_equal(prep.par.k,method['k'])
    np.testing.assert_allclose(vals[0],method['values'][0,:11],rtol=5e-12,atol=1e-30)
    assert np.array_equal(vals[0,[0,4,5,6]],method['values'][0,[0,4,5,6]])
    path=OUT/f'tangent-{tag}-{res}.npz'
    kin.parent.pack(path,k=prep.grid,t=time,values=vals,keys=['X','D','J','A','S','k_sigma','pir','e','j','dg','qg'])
    return path

def main():
    projection.guard();kin.parent.check(PARENT/'source-freeze.json')
    kin.parent.receipt(OUT/'method.json',[PARENT/'source-freeze.json',PARENT/'project_feedback.py',PARENT/'transport.py',OUT/'all_angles.py',OUT/'DESIGN.md',kin.pin('paired_source_control.py'),kin.pin('clock-inputs.npz')])
    inputs=[];scores={}
    for tag in ('cold','matched'):
        prep,state,func=launch(tag)
        for res in (640,1280):
            path=integrate(tag,res,prep,state,func);inputs.extend([path,signed(f'coupled-{tag}-{res}.npz')])
            if tag=='cold':
                assert prep.par.rho==0 and np.all(state[-2:]==0)
        scores[tag]=dict(launch_k=len(prep.grid),cold_has_no_heavy=(tag=='cold' and prep.par.rho==0))
    kin.parent.receipt(OUT/'controls.json',[OUT/'method.json',*inputs])
    for res in (640,1280):
        expected=signed('matched-'+('primary' if res==640 else 'fine')+'.npz')
        original_data=kin.data
        hits=[]
        def read(path):
            if path==expected:
                hits.append(path)
                return original_data(OUT/f'tangent-matched-{res}.npz')
            return original_data(path)
        with patch.object(projection,'OUT',OUT),patch.object(kin,'data',read):
            projection.run(res,prep.par,prep.hist,kin.data(kin.pin('clock-inputs.npz'))['local_at_cut'])
        assert hits==[expected]
    result=kin.data(OUT/'projected-1280.npz');coarse=kin.data(OUT/'projected-640.npz')
    single=kin.data(PARENT/'projected-1280.npz')
    delta=result['delta'];t=result['t']
    norm=lambda a:np.max(abs(a[:,t<=90.4]),axis=1)
    remaining=delta-single['delta']
    baseline_delta=single['old']-result['old']
    score=lambda a,b:(100*norm(a-b)/norm(b)).tolist()
    scores.update(full_pct_of_source=(100*norm(delta)/norm(result['old'])).tolist(),source_step_pct=score(coarse['delta'],delta),
        neutrino_contribution_against_direct_difference_pct=score(remaining,baseline_delta),
        current_derivative_pct=(100*np.max(abs(make_interp_spline(t,delta[4],k=5)(t[t<=90.4],1)-delta[6,t<=90.4]),axis=0)/norm(delta)[6]).tolist())
    assert max(np.ravel(scores['source_step_pct']))<.5 and max(np.ravel(scores['neutrino_contribution_against_direct_difference_pct']))<.5
    kin.parent.put(OUT/'source-checks.json',scores)
    kin.parent.receipt(OUT/'source-freeze.json',[OUT/n for n in ('method.json','controls.json','projected-640.npz','projected-1280.npz','source-checks.json')])
    kin.parent.save(OUT/'transport.py',(PARENT/'transport.py').read_bytes())
    print('joint source frozen; independent component subtraction max %',np.max(scores['neutrino_contribution_against_direct_difference_pct']),flush=True)
if __name__=='__main__':main()
