import sys
import importlib.util
from pathlib import Path

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parent))
spec=importlib.util.spec_from_file_location('angular_route_transport',HERE.parent/'transport.py')
run=importlib.util.module_from_spec(spec)
spec.loader.exec_module(run)

assert Path(run.__file__).resolve()==HERE.parent/'transport.py'
run.OUT=HERE
run.PRE=HERE/'prefix';run.MID=HERE/'bridge';run.LATE=HERE/'late'
for directory in (run.PRE,run.MID,run.LATE):directory.mkdir(exist_ok=True)
run.guard()
assert run.sha(HERE/'transport.py')==run.sha(HERE.parent/'transport.py')
action=sys.argv[1]
if action in ('prefix','bridge','late'):getattr(run,action)()
else:
    assert action in ('scatter-mid','scatter-late','score')
    run.photons(action)
