from pathlib import Path
import sys
from unittest.mock import patch
from functools import lru_cache

OUT=Path(__file__).resolve().parent
BASE=OUT.parent
LIB=BASE/'mts-prepared-source-gravity-photons-90p4-20261126'
sys.path.insert(0,str(LIB))
import source_pair as store
from source_pair import np,json,sha,pin,module,save,put,pack,receipt,check,make_interp_spline,PREFIX,BRIDGE,FINAL
from scipy.interpolate import CubicSpline
assert sha(LIB/'seal.json')=='427ce9fddb4c638e7e7ecdc21910c1912ab26a166b004216e5cc07abba44f248'
PRE=OUT/'prefix';MID=OUT/'bridge';LATE=OUT/'late'
KEYS=store.KEYS
CUT=89.275

def guard():
    store.guard()
    assert not (OUT/'STOP-REQUESTED').exists()

def method(path,files):
    receipt(path,[OUT/'transport.py',OUT/'source-freeze.json',*files])

class Marginal:
    def __init__(self):
        check(OUT/'source-freeze.json')
        with np.load(OUT/'projected-1280.npz') as ar:
            assert ar['keys'].tolist()==KEYS+['hJprime']
            self.k=ar['k'][0];t=ar['t'];self.knots=np.log(t);self.start=self.knots[0]
            assert t[0]==CUT and np.count_nonzero(ar['delta'][:,0])==0
            self.spline=make_interp_spline(self.knots,ar['delta'][:6,:,0].T,k=5)
    def at(self,x,nu=0):
        x=np.asarray(x);flat=x.reshape(-1);values=np.zeros((len(flat),6),complex)
        assert max(flat)<=self.knots[-1]+1e-14
        inside=flat>self.start
        if np.any(inside):values[inside]=self.spline(flat[inside],nu)
        return values.reshape((*x.shape,6))
    def install(self,src):
        assert np.isclose(src.wave,self.k,rtol=1e-12,atol=0) and src.micro_keys==[KEYS[i] for i in (0,1,2,4)]
        inherited=src.external
        def combined(x,nu=0):return inherited(x,nu)+self.at(x,nu)[...,[0,1,2,4]]
        original=type(src);addon=self
        class Increment(original):
            def environment(self,t,side=None):
                raw=super().environment(t,side)
                force=dict(raw[1]);extra=addon.at(np.log(t))
                force['hshear']=force['hshear']+extra[...,5]
                if 'htrace' in force:force['htrace']=force['htrace']+extra[...,3]
                return (raw[0],force,*raw[2:])
        src.external=combined;src.__class__=Increment
        return src

def prefix():
    guard();aug=Marginal()
    pre=module(PREFIX,'exact_source_stage');join=module(PREFIX,'evolve_shared')
    trace=join.Shared();p=pre.import_at(pre.OLD,'partial')
    first=p.first;items=(first,p.second,p.third,p.fourth,p)
    method(PRE/'method.json',[pin(PREFIX,key) for key in ('entry-freeze.json','evolve_shared.py','shared_trace.py')])
    def locked(key):
        assert key in ('protocol.json','entry-freeze.json');guard();check(PRE/'method.json')
    native=p.Host
    def host(grid,sub):
        src=native(grid,sub);src.external=trace.overlay(src.external,[2,3])
        return aug.install(src)
    for mod in items:
        mod.ROOT=PRE;mod.Host=host;mod.save=lambda name,raw:save(PRE/name,raw)
        if mod is first:mod.verify=locked
        else:mod.locked=locked
    for mod,attr,label in zip(items[1:],('source','parent','parent','parent'),('period-','second-','third-','fourth-')):
        orig=getattr(mod,attr)
        setattr(mod,attr,lambda name,orig=orig,label=label:PRE/name if name.startswith(label) and name.endswith('.npz') else orig(name))
    orig=first.pinned
    first.pinned=lambda folder,name:pin(PREFIX,name) if (folder==pre.PAIR and name.startswith('matched-switch-')) or (folder==pre.EXCH and name=='forecast.json') else orig(folder,name)
    join.ROOT=p.joint.window.ROOT=p.joint.common.ROOT=PRE
    join.pack=lambda name,**fields:pack(PRE/name,**fields)
    with np.load(pre.pin(pre.BANK,'material-halfstep/forcing-heavy.npz')) as data:
        times=data['eta'];take=(times>trace.at-.30)&(times<=trace.at);oldcur=data['values'][data['keys'].tolist().index('hJ'),take,0]
    factory=first.make_interp_spline
    def history(grid):
        calls=[]
        def spline(x,y,**kw):
            if y.ndim==1 and np.array_equal(x,times[take]) and np.array_equal(y,oldcur):
                calls.append(1);return lambda tm:trace(np.log(tm))[...,1]
            return factory(x,y,**kw)
        with patch.object(first,'make_interp_spline',spline):value=first.History(grid)
        assert calls==[1];return value
    bank=p.MatchedBank()
    for grid in ('p16','p32'):
        save(PRE/f'switch-{grid}.npz',pin(PREFIX,f'switch-{grid}.npz').read_bytes());hist=history(grid)
        for sub in (2,4):
            for label in ('period','joint'):
                name=f'{label}-{grid}-{sub}.npz';path=pin(PREFIX,name)
                if label=='period':
                    with np.load(path) as ar:assert ar['t'][-1]<CUT
                save(PRE/name,path.read_bytes())
            for mod,label in zip(items[1:],('second','third','fourth','partial')):
                name=f'{label}-{grid}-{sub}.npz';stamp=PRE/(name+'.receipt')
                if not stamp.exists():mod.run(grid,sub,bank,hist);receipt(stamp,[PRE/'method.json',PRE/name])
                check(stamp)
            join.combine(grid,sub)
            print('prefix',grid,sub,flush=True)
    receipt(PRE/'gravity-freeze.json',[PRE/'method.json',*sorted(PRE.glob('*.npz')),*sorted(PRE.glob('*.receipt'))])

def bridge():
    from scipy.interpolate import CubicSpline
    import continuation as cont
    cont.PREFIX_OUT=PRE
    check(PRE/'gravity-freeze.json');aug=Marginal()
    stage=module(BRIDGE,'carry_gravity');pre=stage.prefix();p=pre.import_at(pre.OLD,'partial')
    kernel=pre.import_at(stage.KER,'wave_kernel') if stage.KER in pre.PINS else cont.module_by(stage.KER,'wave_kernel',stage.pin)
    method(MID/'method.json',[PRE/'gravity-freeze.json',pin(BRIDGE,'carry_gravity.py')])
    stage.pin=cont.link_to_prefix(stage.pin);stage.pack=lambda name,**fields:pack(MID/name,**fields)
    for grid in ('p16','p32'):
        kernels=kernel.read(grid);bank=p.MatchedBank()
        with np.load(pin(BRIDGE,'incident-matched-16.npz')) as data:
            assert np.array_equal(bank.q,data['q']) and bank.k==data['k'];log=np.log(data['t'])
            bank.micro=CubicSpline(log,data['micro'],extrapolate=False);bank.sw=CubicSpline(log,data['Sw'],extrapolate=False)
            for sub in (2,4):
                guard();name=f'carry-wave-{grid}-{sub}.npz';save(MID/name,pin(BRIDGE,name).read_bytes())
                path=MID/f'carry-matched-{grid}-{sub}.npz';stamp=path.with_suffix('.receipt')
                if not stamp.exists():
                    src,mem=stage.env_for(p,grid,sub,'matched',bank,data,kernels)
                    stage.evolve(p,aug.install(src),mem,bank,grid,sub,'matched');receipt(stamp,[MID/'method.json',path])
                check(stamp)
    receipt(MID/'gravity-freeze.json',[MID/'method.json',*sorted(MID.glob('carry-*.npz')),*sorted(MID.glob('*.receipt'))])

def late():
    import continuation as cont
    cont.PREFIX_OUT=PRE
    check(MID/'gravity-freeze.json');aug=Marginal()
    io=module(FINAL,'window_io');sources=module(FINAL,'sources90');step=module(FINAL,'stepper');stage=module(FINAL,'evolve90')
    pre=io.oldio.prefix();p=pre.import_at(pre.OLD,'partial')
    method(LATE/'method.json',[MID/'gravity-freeze.json',*[pin(FINAL,k+'.py') for k in ('window_io','sources90','stepper','evolve90')]])
    def fresh(folder,name):return MID/name if folder==BRIDGE and name.startswith(('carry-','photon-')) else io.sealed(folder,name)
    io.oldio.pin=cont.link_to_prefix(io.oldio.pin)
    for mod in (step,sources,stage):
        mod.ROOT=LATE;mod.sealed=fresh;mod.pack=lambda name,**fields:pack(LATE/name,**fields)
    stage.put=lambda name,data:put(LATE/name,data)
    stage.freeze=lambda name,names:receipt(LATE/name,[LATE/n for n in names])
    stage.check=lambda name:check(LATE/name)
    orig=stage.setup
    def setup(p,grid,sub,tag,bank):
        src,hist=orig(p,grid,sub,tag,bank);return aug.install(src),hist
    stage.setup=setup
    for grid in ('p16','p32'):
        bank=p.MatchedBank()
        for sub in (2,4):
            guard();name=f'carry-wave-{grid}-{sub}.npz';save(LATE/name,pin(FINAL,name).read_bytes())
            stage.branch(p,grid,sub,'matched',bank)
    receipt(LATE/'gravity-freeze.json',[LATE/'method.json',*sorted(LATE.glob('*.npz')),*sorted(LATE.glob('*.receipt')),*sorted(LATE.glob('history-*.json'))])

def photons(which):
    import continuation as cont
    import photon_run as ph
    cont.PREFIX_OUT=ph.PREFIX_OUT=PRE;cont.MID=ph.MID=MID;cont.LATE=ph.LATE=LATE
    native=ph.redirect
    def redirect(stage,path,folder):
        native(stage,path,folder)
        def freeze(name,names):
            inherited=pin(folder,'carry_photons.py' if folder==BRIDGE else 'project90.py')
            receipt(path/name,[OUT/'transport.py',inherited,pin(FINAL,'score90.py'),*[path/n for n in names if (path/n).is_file()]])
        stage.freeze=freeze
    ph.redirect=redirect
    if which=='scatter-mid':ph.mid_photons()
    elif which=='scatter-late':ph.late_photons()
    else:ph.evaluate()

if __name__=='__main__':
    guard()
    for path in (PRE,MID,LATE):path.mkdir(exist_ok=True)
    action=sys.argv[1]
    if action in ('prefix','bridge','late'):globals()[action]()
    else:
        assert action in ('scatter-mid','scatter-late','score')
        photons(action)
