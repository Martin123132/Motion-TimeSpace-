from pathlib import Path
import sys
import json
import hashlib
import numpy as np

ROOT=Path(__file__).resolve().parent
BASE=ROOT.parent

def sha(path):
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()

def read(path):return json.loads(path.read_bytes())

def receipt(path):
    assert path.is_file(),path
    for key,value in read(path).items():assert sha(BASE/key)==value,key

def validate(seal):
    for path in ROOT.rglob('*'):
        assert path.name not in ('STOP-REQUESTED','__pycache__') and path.suffix not in ('.pyc','.partial'),path
        if path.suffix=='.py':compile(path.read_bytes(),str(path),'exec')
    if not (ROOT/'RESULTS.md').is_file():raise RuntimeError('results unavailable')
    for folder in (ROOT,ROOT/'all-angular'):
        for name in ('method.json','source-freeze.json','prefix/gravity-freeze.json','bridge/gravity-freeze.json','late/gravity-freeze.json','bridge/prediction-freeze.json','late/prediction-freeze.json','late/paired-forecast.json'):
            receipt(folder/name)
        for step in (640,1280):
            with np.load(folder/f'projected-{step}.npz') as ar:
                assert ar['delta'].shape==(7,377,5) and np.isfinite(ar['delta']).all() and not np.any(ar['delta'][:,0])
                assert np.max(ar['direct_minus_polarized_on_source_scale'])<1e-11
        scores=read(folder/'late/scores.json');assert sum(r['passed'] for r in scores['controls'])==len(scores['controls'])==144
        rows=[r for r in scores['rows'] if (r['sub'],r['stress'],r['setting'],r['kind'])==(4,'comp','primary','cumulative')]
        assert len(rows)==2 and all(not r['pass_gap'] and r['pass_size'] for r in rows)
    for name in ('method.json','freeze.json','rate-method.json','rate-freeze.json','transport-method.json','transport-freeze.json'):receipt(ROOT/'phase-average'/name)
    receipt(ROOT/'all-angular/controls.json')
    assert sha(ROOT/'transport.py')==sha(ROOT/'all-angular/transport.py')
    vis=read(ROOT/'visibility-comparison.json')
    for row in vis['cases']:
        if 'old_pct' in row:
            for key in ('old_pct','new_pct','signed_change_points','change_vector_points'):assert len(row[key])==3 and np.isfinite(row[key]).all()
            diff=np.array(row['new_pct'])-row['old_pct']
            assert np.allclose(diff,row['signed_change_points'],rtol=1e-12,atol=1e-13) and np.all(abs(diff)<=np.array(row['change_vector_points'])+1e-12)
            assert not row['passes'] and not np.any(np.array(row['maximum_possible_fraction_of_shortfall'])>=1)
    assert len(vis['cases'])==36 and len(vis['intervention_convergence'])==8
    assert max(max(row['step_difference_pct_of_small_intervention']) for row in vis['intervention_convergence'])<.5
    raw=read(ROOT/'phase-average/phase-scores.json')
    for row in raw['rows']:
        if row.get('case')=='transport':
            assert row['passing_full']==[20]*3 and row['passing_drift']==[20]*3
    phases=read(ROOT/'phase-average/transport-scores.json')
    for row in phases['rows']:
        if row['group']=='current rates':
            assert max(row['chain_pct']+row['micro_pct'])<.5 and not any(row['resolvable'])
            assert max(row['comm_difference_pct_of_mean_rate'])<.00001
        else:
            assert row['stress_pass_counts_full']==row['stress_pass_counts_drift']==[20]*3
            assert np.max(np.asarray(row['drift_pct'])[:,:4])<.5
    for res in (640,1280):
        with np.load(ROOT/f'phase-average/transported-{res}.npz') as pair,np.load(ROOT/f'phase-average/forecast-{res}.npz') as older:
            assert np.array_equal(pair['centers'][::2],older['centers']) and len(pair['centers'][1::2])==10
    parents={'mts-collisionless-shear-cauchy-20261126':'fc5d536570b0ffbfd2cbf95d291911707f19b5b5c0c27be20d7311cdb4f88d1c',
        'mts-prepared-source-gravity-photons-90p4-20261126':'427ce9fddb4c638e7e7ecdc21910c1912ab26a166b004216e5cc07abba44f248',
        'mts-carried-gravity-photons-90p4-20261126':'9255065ecee560e1933ced73cb9cc0ba3561e6bbfe1259f7c93d7b41c7992680'}
    for name,sign in parents.items():assert sha(BASE/name/'seal.json')==sign
    files={path.relative_to(ROOT).as_posix():sha(path) for path in ROOT.rglob('*') if path.is_file() and path!=ROOT/'seal.json'}
    record=dict(files=files,parents=parents,scope='Signed, incremental heavy-source intervention on the retained second-order photon probe; local quadratic phase mean and transported common phase ensemble; no astronomical fit.')
    path=ROOT/'seal.json'
    if seal and not path.exists():
        with path.open('x',encoding='utf-8',newline='\n') as stream:json.dump(record,stream,indent=2,sort_keys=True);stream.write('\n')
    assert read(path)==record
    print('Verified',len(files),'files; seal',sha(path),flush=True)
if __name__=='__main__':
    assert sys.argv[1:] in ([],['--seal'])
    validate(bool(sys.argv[1:]))
