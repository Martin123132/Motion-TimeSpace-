from pathlib import Path
import sys
import json
import numpy as np
from scipy.interpolate import CubicSpline

HERE=Path(__file__).resolve().parent
LIB=HERE.parent/'mts-prepared-source-gravity-photons-90p4-20261126'
sys.path.insert(0,str(LIB))
from source_pair import pin,check,put,receipt,sha,PREFIX,BRIDGE,FINAL,module

def load(path):return json.loads(path.read_bytes())

def validate():
    score=module(FINAL,'score90');ph=score.modules();gate=ph.gate
    _,axis,weights,_=ph.proj.old.get_media();measure=gate.previous.make_measure(axis,weights)
    norm=lambda val:gate.mag(val,measure)
    groups=[('photon',HERE),('joint',HERE/'all-angular')]
    results=[];controls=[];vectors={}
    for label,folder in groups:
        check(folder/'source-freeze.json');check(folder/'late/paired-forecast.json')
        summary=load(folder/'late/scores.json')
        assert all(row['passed'] for row in summary['controls'])
        assert len(summary['controls'])==144 and summary['tolerance_pct']==.5 and summary['launch_cap_pct']==.163
        for grid in ('p16','p32'):
            for sub in (2,4):
                suffix=f'{grid}-{sub}.npz'
                for local,remote,file in [('prefix',PREFIX,'period-'),('prefix',PREFIX,'joint-'),('bridge',BRIDGE,'carry-wave-'),('late',FINAL,'carry-wave-')]:
                    assert sha(folder/local/(file+suffix))==sha(pin(remote,file+suffix))
                with np.load(folder/'prefix'/('second-'+suffix)) as new,np.load(pin(PREFIX,'second-'+suffix)) as old:
                    t=new['t'];keep=t<=89.275;assert keep.any() and (~keep).any() and np.array_equal(t,old['t'])
                    for key in ('obs','traces'):assert np.array_equal(new[key][keep],old[key][keep]),key
                prev=folder/'bridge'/('carry-matched-'+suffix)
                for part in range(1,16):
                    file=folder/'late'/(f'part-matched-{grid}-{sub}-{part:02}.npz')
                    with np.load(file) as ar:
                        assert ar['parent_hash'].item()==sha(prev) and ar['seam'].max()<.5 and ar['rhs_identity_pct']<.5
                    prev=file
                with np.load(prev) as last,np.load(folder/'late'/('carry-matched-'+suffix)) as trace:
                    assert np.array_equal(last['final_lag'],trace['final_lag']) and last['final_lag'].shape[-2:]==(77,69)
        for setting in ('primary','time','angle'):
            name=f'photon-{setting}.npz'
            with np.load(folder/'late'/name) as new,np.load(pin(FINAL,name)) as old,np.load(ph.track(ph.cell89.pin(name))) as archive:
                assert np.array_equal(new['scale'],old['scale']) and np.array_equal(new['labels'],old['labels'])
                vis=lambda data:CubicSpline(old['scale'],data)(axis)
                labels=new['labels'].tolist()
                for grid in ('p16','p32'):
                    norm_ref=norm(vis(archive['values'][:,archive['labels'].tolist().index([grid,'primary'])][:,[0,1,2]].sum(1)))
                    for sub in (2,4):
                        sel=[labels.index(f'{grid}-{sub}-comp_'+route) for route in ('momentum','density')]
                        source=lambda ar:vis(ar['cumulative'][:,sel[1]]-ar['cumulative'][:,sel[0]])
                        before=source(old);after=source(new);diff=after-before
                        sizes=[100*norm(x)/norm_ref for x in (before,after,diff)]
                        rows=[r for r in summary['rows'] if (r['grid'],r['sub'],r['setting'],r['kind'],r['stress'])==(grid,sub,setting,'cumulative','comp')]
                        assert len(rows)==1 and np.allclose(rows[0]['route_gap_pct'],sizes[1],atol=1e-9,rtol=0)
                        assert bool(np.all(sizes[1]<=.5))==rows[0]['pass_gap']
                        dist=np.maximum(sizes[0]-.5,0);assert np.all(dist>0)
                        cosine=(norm(before+diff)**2-norm(before-diff)**2)/(4*norm(before)*norm(diff))
                        assert np.max(np.abs(cosine))<=1.000001
                        results.append(dict(case=label,setting=setting,grid=grid,sub=sub,old_pct=sizes[0].tolist(),new_pct=sizes[1].tolist(),
                            signed_change_points=(sizes[1]-sizes[0]).tolist(),change_vector_points=sizes[2].tolist(),cosine=cosine.tolist(),
                            maximum_possible_fraction_of_shortfall=(sizes[2]/dist).tolist(),passes=rows[0]['pass_gap'],size_on_launch_pct=rows[0]['size_pct_launch']))
                        vectors[label,setting,grid,sub]=(diff,norm_ref,before)
        controls.append(dict(case=label,count=len(summary['controls']),pass_count=sum(r['passed'] for r in summary['controls'])))
    for setting in ('primary','time','angle'):
        for grid in ('p16','p32'):
            for sub in (2,4):
                single,den,_=vectors['photon',setting,grid,sub]
                total,_,before=vectors['joint',setting,grid,sub]
                other=total-single
                results.append(dict(case='joint minus photon (collisionless increment on this path)',setting=setting,grid=grid,sub=sub,
                        change_vector_points=(100*norm(other)/den).tolist(),
                        cosine_with_photon=((norm(single+other)**2-norm(single-other)**2)/(4*norm(single)*norm(other))).tolist()))
    conv=[]
    for label,_ in groups:
        base,den,_=vectors[label,'primary','p32',4]
        for setting,grid,sub in [('primary','p16',4),('primary','p32',2),('time','p32',4),('angle','p32',4)]:
            variant=vectors[label,setting,grid,sub][0]
            conv.append(dict(case=label,setting=setting,grid=grid,sub=sub,step_difference_in_points=(100*norm(variant-base)/den).tolist(),
                step_difference_pct_of_small_intervention=(100*norm(variant-base)/norm(base)).tolist()))
    put(HERE/'visibility-comparison.json',dict(output=['energy','current','joint'],cases=results,numerics=controls,intervention_convergence=conv))
    for row in results:
        if row['setting']=='primary' and row['sub']==4:print(row['case'],row['grid'],row.get('new_pct'),row['change_vector_points'],flush=True)
if __name__=='__main__':validate()
