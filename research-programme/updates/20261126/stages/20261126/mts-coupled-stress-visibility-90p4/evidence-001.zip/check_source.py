from pathlib import Path
import sys
import json
import numpy as np
from scipy.interpolate import make_interp_spline
from project_feedback import OUT,BASE,kin,signed,guard,CUT,KEYS

def compare(a,b):
    den=np.max(abs(b),axis=0)
    assert np.min(den)>0
    return (100*np.max(abs(a-b),axis=0)/den).tolist()

def main():
    guard();kin.parent.check(OUT/'source-freeze.json')
    coarse=kin.data(OUT/'projected-640.npz');fine=kin.data(OUT/'projected-1280.npz')
    time=fine['t'];area=time<=90.4;assert np.array_equal(coarse['t'],time)
    vals=fine['delta'][:,area];old=fine['old'][:,area];nodes=fine['k']
    def magnitude(arr):return np.max(abs(arr),axis=1)
    rate=make_interp_spline(time,fine['delta'][4],k=5)(time[area],1)
    oldrate=make_interp_spline(time,fine['old'][4],k=5)(time[area],1)
    result=dict(source_order=KEYS,output_k=nodes.tolist(),
        full_window_fractional_change_pct=(100*magnitude(vals)/magnitude(old)).tolist(),
        source_grid_difference_pct_of_increment=(100*magnitude(vals-coarse['delta'][:,area])/magnitude(vals)).tolist(),
        projected_subtraction_error_pct_of_increment=(100*fine['direct_minus_polarized_on_source_scale'].T*magnitude(old)/magnitude(vals)).tolist(),
        derivative_error_pct_of_increment=compare(rate,vals[6]),derivative_error_pct_of_absolute_rate=compare(oldrate,old[6]),
        derivative_difference_on_full_rate_pct=(100*np.max(abs(rate-vals[6]),axis=0)/magnitude(old)[6]).tolist(),
        zero_launch=bool(np.all(vals[:,0]==0)))
    assert result['zero_launch'] and max(np.ravel(result['source_grid_difference_pct_of_increment']))<.5
    assert max(np.ravel(result['projected_subtraction_error_pct_of_increment']))<.5
    oldlin=kin.data(signed('matched-fine.npz'));newlin=kin.data(signed('coupled-matched-1280.npz'))
    par=kin.initial('matched');hist=kin.audit_sources.load_native('matched',before=CUT)
    truth=kin.data(kin.old.pin('matched-metric.npz'))
    common,idx,ref=np.intersect1d(time[area],truth['time'],return_indices=True)
    assert common[0]==CUT and common[-1]==90.4
    grids=[]
    for saved in (oldlin,newlin):
        at=lambda name:saved['values'][:,saved['keys'].tolist().index(name)]
        sigma=at('k_sigma');xx=at('X');dt=(time-CUT)[:,None];coef=par.h0**2-par.pressure
        fac=1+par.h0*dt+coef*dt**2/4;hub=(par.h0+coef*dt/2)/fac
        integ=make_interp_spline(time,(sigma-xx)/3,k=5).antiderivative()
        alpha=sigma/par.k**2
        pot=hist.data['etak'][-1]/par.k+integ(time)-integ(CUT)-hub*alpha
        pig=at('pig') if 'pig' in saved['keys'] else par.forc[0]+dt*par.forcp[0]
        lapse=pot-((par.weights[2]*pig+par.weights[3]*at('pir'))/fac**2+1.5*at('S'))/par.k**2
        phidot=(sigma-xx)/3+(3*hub**2+par.pressure/fac**2)*alpha/2-hub*lapse
        pred=np.stack((alpha,lapse,phidot),axis=1)[idx];want=truth['metric'][ref,3:]
        frac=lambda diff,norm:(100*np.max(abs(diff),axis=(0,2))/np.max(abs(norm),axis=(0,2))).tolist()
        grids.append(dict(launch=frac(pred[:1]-want[:1],want[:1]),amplitude=frac(pred-want,want),change=frac((pred-pred[0])-(want-want[0]),want-want[0])))
    result.update(gauge_native_order=['shear/k','lapse','Phi_prime'],gauge_native_percent=dict(tangent=grids[0],feedback=grids[1]))
    assert max(grids[1]['launch'])<.005
    kin.parent.put(OUT/'source-checks.json',result)
    print('source grid pct',max(np.ravel(result['source_grid_difference_pct_of_increment'])),'rate error, pct of increment',result['derivative_error_pct_of_increment'],'native metric',grids,flush=True)
if __name__=='__main__':main()
