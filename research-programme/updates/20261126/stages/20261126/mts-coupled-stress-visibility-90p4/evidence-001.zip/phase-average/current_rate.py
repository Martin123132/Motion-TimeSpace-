from phase_stress import HERE,PARENT,prepare,kin,spatial,signed,CUT,guard,np,json,sys,make_interp_spline,SimpleNamespace

def predict(res):
    (b,v,f,w),(om,h,alpha,phi,psi,pd,x),tc,t,clock,k=prepare(res)
    par=kin.initial('matched');co=par.h0**2-par.pressure
    fac=1+par.h0*(tc-CUT)[:,None]+co*((tc-CUT)[:,None])**2/4
    hp=co/(2*fac)-h*h
    drive=kin.data(signed(f'coupled-matched-{res}.npz'))
    ix=drive['keys'].tolist().index
    def derivatives(key):
        val=drive['values'][:,ix(key)]
        return np.stack([make_interp_spline(t[i-5:i+1],val[i-5:i+1],k=5)(t[i],1) for i in np.searchsorted(t,tc)])
    ap=derivatives('k_sigma')/k**2;xp=derivatives('X')
    op=h*om;d=1.5*h;dp=1.5*hp;s=x/2;sp=xp/2;nu=om+k**2/(2*om);nup=h*(om-k**2/(2*om))
    bv=-2*h*v-om**2*b;fw=-2*h*w-(om**2+k**2)*f-v*x
    bq=(v+d*b)/om;vq=-om*b-d*bq;fq=(w+d*f+s*b)/nu;wq=-nu*f-d*fq-s*bq
    dbq=(bv+dp*b+d*v-op*bq)/om
    dvq=-op*b-om*v-dp*bq-d*dbq
    dfq=(fw+dp*f+d*w+sp*b+s*v-nup*fq)/nu
    dwq=-nup*f-nu*w-dp*fq-d*dfq-sp*bq-s*dbq
    def orient(bg,vel,ff,ww,dbg,dv,df,dw):
        shift=-3*h*vel-om**2*bg
        normal=ww+shift*alpha;field=ff+vel*alpha
        normalslope=dw+(-3*hp*vel-3*h*dv-2*om*op*bg-om**2*dbg)*alpha+shift*ap
        fieldslope=df+dv*alpha+vel*ap
        micro_f=normal+vel*psi;micro_n=-2*h*normal-(k*k+om**2)*field-om**2*bg*psi+3*vel*pd
        return dict(n=normal,f=field,dn=normalslope,df=fieldslope,mn=micro_n,mf=micro_f)
    dirs=(orient(b,v,f,w,v,bv,w,fw),orient(bq,vq,fq,wq,dbq,dvq,dfq,dwq))
    shell=np.array(json.loads(spatial.pin('legs.json').read_bytes())['squared_radii']);result=[]
    for fields in dirs:
        data=SimpleNamespace(nodes=k,shell=shell,first={key:value.T for key,value in fields.items()})
        rows=[]
        for raw in spatial.Project(data).ops:
            g=spatial.Fast(raw,data).dg
            rows.append([-g('n','f'),-g('dn','f')-g('n','df'),-g('mn','f')-g('n','mf')])
        result.append(np.stack(rows,axis=-1))
    kin.parent.pack(HERE/f'current-rate-{res}.npz',centers=tc,t=t,phase=clock,keys=['mean_current','chain_rate','microscopic_mean_rate'],values=np.mean(result,axis=0),alpha_eq_residual=ap-(psi-h*alpha))

def compare():
    kin.parent.check(HERE/'rate-freeze.json');records=[]
    for res in (640,1280):
        raw=kin.data(PARENT/f'projected-{res}.npz')
        pred=kin.data(HERE/f'current-rate-{res}.npz')
        val=pred['values'];tc=pred['centers'];assert len(tc)==11
        targets=[]
        for stride in (1,2):
            phase=pred['phase'][::stride];time=raw['t'][::stride]
            q=(raw['old'][[4,6],::stride]+raw['delta'][[4,6],::stride])
            means=[]
            for p in np.searchsorted(time,tc):
                z=(phase-phase[p])/(6*np.pi);mask=abs(z)<1;arg=z[mask];ang=phase[mask]-phase[p]
                mat=np.column_stack([arg**i for i in range(9)]+[arg**i*fn(2*ang) for i in range(7) for fn in (np.cos,np.sin)]+[arg**i*fn(4*ang) for i in range(3) for fn in (np.cos,np.sin)])
                means.append(np.einsum('t,atk->ak',np.linalg.pinv(mat)[0],q[:,mask]))
            avg,mic=np.stack(means,axis=1)
            targets.append((avg,mic))
        full,mic=targets[0];coarse,lowmic=targets[1]
        def rate(arr,order):return make_interp_spline(tc,arr,k=order)(tc[1:-1],1)
        direct=rate(full,5);direct_coarse=rate(coarse,5);direct_alt=rate(full,3);mic=mic[1:-1];lowmic=lowmic[1:-1]
        reference=np.stack([direct,mic,direct-mic]);fc=np.stack([val[1,1:-1],val[2,1:-1],val[1,1:-1]-val[2,1:-1]])
        mx=lambda ar:np.max(abs(ar),axis=1)
        den=mx(reference);assert (den>0).all()
        spread=np.maximum(mx(np.stack([direct-direct_alt,np.zeros_like(mic),direct-direct_alt])),mx(reference-np.stack([direct_coarse,lowmic,direct_coarse-lowmic])))
        err=mx(fc-reference)
        frac=100*err/den
        records.append(dict(res=res,errors_pct=frac.tolist(),passing=[int(i) for i in np.sum(frac<=.5,axis=1)],ref_sensitivity_pct=(100*spread/den).tolist(),
            signal_exceeds_10x_reference_variation=(den>10*spread).tolist(),commutator_pct_of_mean_rate=(100*den[2]/den[0]).tolist(),
            commutator_error_pct_of_mean_rate=(100*err[2]/den[0]).tolist()))
        print(res,'rate checks',records[-1]['passing'],'max errors (%)',np.max(frac,axis=1).tolist(),flush=True)
    kin.parent.put(HERE/'rate-scores.json',dict(order=['time derivative of mean current','mean instantaneous current derivative','first minus second'],rows=records))
if __name__=='__main__':
    guard()
    if sys.argv[1:]==['score']:compare()
    else:
        assert not sys.argv[1:]
        kin.parent.receipt(HERE/'rate-method.json',[HERE/'CURRENT-RATE.md',HERE/'current_rate.py',HERE/'freeze.json'])
        for res in (640,1280):predict(res)
        kin.parent.receipt(HERE/'rate-freeze.json',[HERE/'rate-method.json',*[HERE/f'current-rate-{res}.npz' for res in (640,1280)]])
