from phase_stress import *
from scipy.interpolate import CubicSpline

def freeze_pair(res):
    inputs=kin.data(signed(f'coupled-matched-{res}.npz'));k=inputs['k'];time=inputs['t']
    par=kin.initial('matched');hist=kin.audit_sources.load_native('matched',before=CUT)
    seed=kin.data(kin.pin('clock-inputs.npz'))['local_at_cut'][:4];coef=par.h0**2-par.pressure
    get=lambda key:inputs['values'][:,inputs['keys'].tolist().index(key)]
    xx,sk,pig,pir,shear=[get(key) for key in ('X','k_sigma','pig','pir','S')]
    def geom(at):
        diff=at-CUT;fac=1+par.h0*diff+coef*diff**2/4
        return fac,par.m*par.a0*fac,(par.h0+coef*diff/2)/fac
    def turn(y,omega,h,x):
        b,v,f,w=y;d=1.5*h;nu=omega+k*k/(2*omega);s=x/2
        bq=(v+d*b)/omega;fq=(w+d*f+s*b)/nu
        return np.array([bq,-omega*b-d*bq,fq,-nu*f-d*fq-s*bq])
    fac,omega,hub=geom(CUT)
    other=turn(seed,omega,hub,xx[0]);np.testing.assert_allclose(turn(other,omega,hub,xx[0]),-seed,rtol=2e-14,atol=1e-22)
    state=np.stack((seed,other));lo=CUT;centers=time[(time>=inputs['centers'][0])&(time<=inputs['centers'][-1])]
    assert np.array_equal(centers[::2],inputs['centers'])
    tracks=[];metrics=[];times=np.searchsorted(time,centers)
    for now,ind in zip(centers,times):
        guard();span=slice(0,ind+1);drive=make_interp_spline(time[span],xx[span],k=5)
        def rhs(tt,vec):
            _,om,hh=geom(tt);b,v,f,w=vec.reshape(2,4,-1).transpose(1,0,2)
            return np.stack((v,-2*hh*v-om**2*b,w,-2*hh*w-(om**2+k*k)*f-v*drive(tt)),axis=1).ravel()
        sol=solve_ivp(rhs,(lo,now),state.ravel(),t_eval=[now],max_step=1/res,rtol=1e-12,atol=2e-25,method='DOP853')
        assert sol.success;state=sol.y[:,-1].reshape(2,4,-1);tracks.append(state.copy());lo=now
        fac,om,hh=geom(now);hs=coef/(2*fac)-hh**2;al=sk[ind]/k**2
        rate=(sk[span]-xx[span])/3;eta=make_interp_spline(time[span],rate,k=5).antiderivative()
        phi=hist.data['etak'][-1]/k+eta(now)-eta(CUT)-hh*al
        psi=phi-((par.weights[2]*pig[ind]+par.weights[3]*pir[ind])/fac**2+1.5*shear[ind])/k**2
        pd=rate[-1]+(3*hh**2+par.pressure/fac**2)*al/2-hh*psi
        ap=make_interp_spline(time[ind-5:ind+1],sk[ind-5:ind+1],k=5)(now,1)/k**2
        metrics.append(np.stack((om,hh,hs,al,ap,phi,psi,pd,xx[ind])))
    om,h,hp,al,ap,phi,psi,pd,source=np.stack(metrics,axis=1)
    y0,y1=np.stack(tracks,axis=2)
    shell=np.array(json.loads(spatial.pin('legs.json').read_bytes())['squared_radii'])
    def evaluate(y):
        b,v,f,w=y;dv=-2*h*v-om**2*b;dw=-2*h*w-(k**2+om**2)*f-v*source
        g=-3*h*v-om**2*b;fn=f+v*al;n=w+g*al;fd=n+v*psi
        nd=-2*h*n-(k**2+om**2)*fn-om**2*b*psi+3*v*pd
        dfn=w+dv*al+v*ap;dn=dw+(-3*hp*v-3*h*dv-2*h*om**2*b-om**2*v)*al+g*ap
        fields=dict(f=fn,n=n,u=n-3*v*phi,phi=phi,psi=psi,fd=fd,nd=nd,dfn=dfn,dn=dn)
        data=SimpleNamespace(nodes=k,shell=shell,first={key:v.T for key,v in fields.items()});rows=[]
        for raw in spatial.Project(data).ops:
            op=spatial.Fast(raw,data)
            q=contract(op,lambda method,l,r:method(l,r),b[:,0],v[:,0],om[:,0]**2)
            rows.append(np.vstack((q[2:],-op.dg('dn','f')-op.dg('n','dfn'))))
        return np.stack(rows,axis=-1)
    first=evaluate(y0);quarter=evaluate(y1);half=evaluate((y0+y1)/np.sqrt(2));avg=(first+quarter)/2
    clock=CubicSpline(time,[geom(tm)[1][0] for tm in time]).antiderivative()(time)
    kin.parent.pack(HERE/f'transported-{res}.npz',centers=centers,time=time,phase=clock,
        outputs=['energy','trace','current','shear','micro_rate','chain_rate'],values=np.stack((avg,first-avg,half-avg)))

def scores():
    kin.parent.check(HERE/'transport-freeze.json');rows=[]
    for res in (640,1280):
        pred=kin.data(HERE/f'transported-{res}.npz');source=kin.data(PARENT/f'projected-{res}.npz')
        centers=pred['centers'];time=pred['time'];phase=pred['phase'];vals=pred['values'];raw=source['delta'][2:7]+source['old'][2:7]
        phases=phase[np.searchsorted(time,centers)];results=[]
        for stride in (1,2):
            ts=time[::stride];qq=raw[:,::stride];tt=phase[::stride];reference=[]
            for pc in phases:
                rel=tt-pc;z=rel/(6*np.pi);mask=abs(z)<1
                assert z[0]<-1 and z[-1]>1
                u=z[mask];ang=rel[mask]
                design=np.column_stack([u**p for p in range(9)]+[u**p*fn(2*ang) for p in range(7) for fn in (np.cos,np.sin)]+[u**p*fn(4*ang) for p in range(3) for fn in (np.cos,np.sin)])
                inv=np.linalg.pinv(design)
                reference.append(np.einsum('mt,atk->mak',inv[[0,9,10]],qq[:,mask]))
            results.append(np.stack(reference,axis=2))
        ref,low=results
        for label,idx in [('original',np.arange(0,len(centers),2)),('interlaced',np.arange(1,len(centers),2))]:
            fc=vals[:,:5,idx];want=ref[:,:,idx]
            norm=lambda a:np.max(abs(a),axis=2)
            err=100*norm(fc-want)/norm(want)
            dref=want-want[:,:,:1];dpred=fc-fc[:,:,:1]
            drift=100*norm(dpred-dref)/norm(dref)
            rows.append(dict(res=res,group=label,full_pct=err.tolist(),drift_pct=drift.tolist(),
                stress_pass_counts_full=[int((v[:4]<=.5).sum()) for v in err],stress_pass_counts_drift=[int((v[:4]<=.5).sum()) for v in drift]))
        rate=lambda arr,deg:make_interp_spline(centers,arr,k=deg)(centers[1:-1],1)
        chain=rate(ref[0,2],5);micro=ref[0,4,1:-1];true=chain-micro
        pc=vals[0,5,1:-1];pm=vals[0,4,1:-1];estimate=pc-pm
        mx=lambda a:np.max(abs(a),axis=0)
        spread=np.maximum(mx(rate(low[0,2],5)-low[0,4,1:-1]-true),mx(rate(ref[0,2],3)-chain))
        row=dict(res=res,group='current rates',chain_pct=(100*mx(chain-pc)/mx(chain)).tolist(),micro_pct=(100*mx(micro-pm)/mx(micro)).tolist(),
            comm_difference_pct_of_mean_rate=(100*mx(estimate-true)/mx(chain)).tolist(),reference_comm_pct_of_mean_rate=(100*mx(true)/mx(chain)).tolist(),
            resolvable=(mx(true)>10*spread).tolist())
        rows.append(row)
        print(res,[(r['group'],r.get('stress_pass_counts_full'),r.get('stress_pass_counts_drift')) for r in rows if r['res']==res],row,flush=True)
    kin.parent.put(HERE/'transport-scores.json',dict(order=['mean','cos2','sin2'],outputs=['energy','trace','current','shear','micro_rate'],rows=rows))

if __name__=='__main__':
    guard()
    if sys.argv[1:]==['score']:scores()
    else:
        assert not sys.argv[1:]
        kin.parent.receipt(HERE/'transport-method.json',[HERE/'TRANSPORTED-PAIR.md',HERE/'transported_pair.py',HERE/'rate-freeze.json',HERE/'rate-scores.json',HERE/'phase_stress.py'])
        for res in (640,1280):freeze_pair(res)
        kin.parent.receipt(HERE/'transport-freeze.json',[HERE/'transport-method.json',*[HERE/f'transported-{res}.npz' for res in (640,1280)]])
