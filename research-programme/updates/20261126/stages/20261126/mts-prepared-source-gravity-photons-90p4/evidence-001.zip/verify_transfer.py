from continuation import *
from scipy.integrate import cumulative_simpson
from scipy.interpolate import CubicSpline
def audit():
    check(LATE/'paired-forecast.json');check(MID/'gravity-freeze.json');check(LATE/'gravity-freeze.json');check(PREFIX_OUT/'gravity-freeze.json')
    scores=json.loads((LATE/'scores.json').read_bytes());assert scores['prediction_hash']==sha(LATE/'prediction-freeze.json')
    assert len(scores['controls'])==144 and len(scores['rows'])==48
    assert scores['tolerance_pct']==.5 and scores['launch_cap_pct']==.163
    for row in scores['rows']:
        assert row['pass_gap']==(max(row['route_gap_pct'])<=.5) and row['pass_size']==(max(row['size_pct_launch'])<=.163)
    for driver in (MID,LATE):
        prov=json.loads((driver/'photon-provenance.json').read_bytes())['inputs']
        for key,sig in prov.items():assert sha(BASE/key)==sig
    resolved=[];chain=[];reduced=[]
    kk=Sources('wave').k**2
    def compensate(clock,hub,old,new,label):
        cur,mem=old;newcur,newmem=new
        delta=(newmem[:,:,0]-newcur)-(mem[:,:,0]-cur)
        de=newmem[:,:,1]-mem[:,:,1]
        change=de+3*hub[:,None]*delta/kk
        hdot=CubicSpline(clock,hub)(clock,1)
        factor=-1+3*(hdot-hub*hub)/kk
        pred=change[0]+cumulative_simpson(factor[:,None]*delta,x=clock,axis=0,initial=0)
        peak=np.max(abs(change-change[0]),axis=0);assert np.all(peak>0)
        reduced.append(dict(label=label,n=len(clock),pct_of_earned_change=(100*np.max(abs(pred-change),axis=0)/peak).tolist(),max_earned_change=peak.tolist()))
    for grid in ('p16','p32'):
        for sub in (2,4):
            for tag in ('wave','matched'):
                suffix=f'{tag}-{grid}-{sub}';prev=MID/('carry-'+suffix+'.npz');maxseam=0.;maxrate=0.
                for idx in range(1,16):
                    packet=LATE/f'part-{suffix}-{idx:02}.npz'
                    with np.load(packet) as ar:
                        assert ar['parent_hash'].item()==sha(prev)
                        assert np.allclose(ar['t'][[0,-1]],np.array([1792+idx,1793+idx])/20,rtol=0,atol=2.e-14)
                        maxseam=max(maxseam,max(ar['seam']));maxrate=max(maxrate,ar['rhs_identity_pct'].item())
                    prev=packet
                assert maxseam<.5 and maxrate<.5
                with np.load(prev) as endpoint,np.load(LATE/('carry-'+suffix+'.npz')) as full:
                    key='final_lag' if tag=='matched' else 'lag_end'
                    assert full[key].shape[-2:]==(77,69) and np.array_equal(endpoint[key],full[key]) and np.isfinite(full[key]).all()
                chain.append(dict(tag=suffix,pieces=15,maxseam_pct=maxseam,maxrate_pct=maxrate))
            for folder,prior,prefix,key in [(PREFIX_OUT,PREFIX,'joint','observables'),(MID,BRIDGE,'carry-wave','obs'),(LATE,FINAL,'carry-wave','obs')]:
                name=f'{prefix}-{grid}-{sub}.npz'
                with np.load(pin(prior,name)) as orig,np.load(folder/name) as new:
                    assert np.array_equal(orig['t'],new['t'])
                    target=orig[key];change=new[key]-target;value=100*np.max(abs(change),axis=0)/np.max(abs(target),axis=0)
                    assert np.isfinite(value).all()
                    resolved.append(dict(label=folder.name+'-'+name,per_route_per_observable_pct=value.tolist(),maximum_pct=value.max()))
            for prefix in ('period','second','third','fourth','partial','carry-matched'):
                name=f'{prefix}-{grid}-{sub}.npz';late=prefix=='carry-matched';folder=LATE if late else PREFIX_OUT;oldfolder=FINAL if late else PREFIX
                with np.load(pin(oldfolder,name)) as orig,np.load(folder/name) as new:
                    clock=new['t'];hub=new['obs'][:,0,9].real
                    assert np.array_equal(clock,orig['t']) and np.array_equal(hub,orig['obs'][:,0,9].real)
                    def get(ar):
                        if late:return ar['physical_current_phase'][:,:,0],ar['memories']
                        tr=ar['traces'];return tr[:,:,0],tr[:,:,[1,3]]
                    compensate(clock,hub,get(orig),get(new),name)
    for setting in ('primary','angle','time'):
        name='photon-'+setting+'.npz'
        with np.load(LATE/name) as ar,np.load(MID/name) as prev:
            count=len(ar['labels']);incoming=prev['hierarchy_at_exit'][:,2*count:]
            assert count==16 and np.any(incoming[1:]) and np.array_equal(ar['hierarchy_at_entry'][:,:count],incoming)
            assert np.array_equal(ar['hierarchy_at_entry'][:,2*count:],incoming) and not np.any(ar['hierarchy_at_entry'][:,count:2*count])
    put(ROOT/'validation.json',dict(chain=chain,resolved_control=resolved,compensated_source=reduced,numerical_controls_passed=sum(r['passed'] for r in scores['controls']),numerical_controls_total=len(scores['controls']),max_numerical_control_pct=max(max(r['error_original_pct']) for r in scores['controls'])))
if __name__=='__main__':audit()
