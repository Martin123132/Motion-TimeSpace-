from continuation import *
def redirect(stage,out,which):
    stage.ROOT=out
    stage.pack=lambda name,**fields:pack(out/name,**fields)
    stage.put=lambda name,data:put(out/name,data)
    stage.check=lambda name:check(out/name)
    def lock(name,files):
        use=[out/f for f in files if (out/f).exists()]
        receipt(out/name,[*use,ROOT/'photon_run.py',ROOT/'PROTOCOL.md',pin(which,'carry_photons.py' if which==BRIDGE else 'project90.py'),pin(FINAL,'score90.py')])
    stage.freeze=lock
def mid_photons():
    check(MID/'gravity-freeze.json')
    old=module(BRIDGE,'carry_photons');old.pin=link_to_prefix(old.pin)
    redirect(old,MID,BRIDGE)
    save(MID/'incident-matched-16.npz',pin(BRIDGE,'incident-matched-16.npz').read_bytes())
    old.run()
def late_photons():
    check(LATE/'gravity-freeze.json');check(MID/'prediction-freeze.json')
    old=module(FINAL,'project90');redirect(old,LATE,FINAL);original=old.sealed
    old.sealed=lambda folder,name:MID/name if folder==BRIDGE and name.startswith('photon-') else original(folder,name)
    old.run()
    receipt(LATE/'paired-forecast.json',[LATE/'prediction-freeze.json',MID/'prediction-freeze.json',PREFIX_OUT/'gravity-freeze.json'])
def evaluate():
    check(LATE/'paired-forecast.json')
    old=module(FINAL,'score90');original=old.sealed;old.ROOT=LATE;old.check=lambda name:check(LATE/name)
    old.put=lambda name,data:put(LATE/name,data)
    old.sealed=lambda folder,name:MID/name if folder==BRIDGE and name.startswith('photon-') else original(folder,name)
    old.score()
    ph=old.modules();gate=ph.gate;_,axis,weights,_=ph.proj.old.get_media();measure=gate.previous.make_measure(axis,weights)
    norm=lambda val:gate.mag(val,measure)
    rows=[]
    for grid in ('p16','p32'):
        with np.load(pin(FINAL,'photon-primary.npz')) as prior,np.load(LATE/'photon-primary.npz') as new,np.load(ph.track(ph.cell89.pin('photon-primary.npz'))) as archive:
            assert prior['labels'].tolist()==new['labels'].tolist() and np.array_equal(new['scale'],prior['scale'])
            scale=new['scale'];vis=lambda val:CubicSpline(scale,val)(axis)
            data=archive['values'][:,archive['labels'].tolist().index([grid,'primary'])]
            small=norm(vis(data[:,[0,1,2]].sum(1)))
            energy=[]
            for frame in ('previous','increment','cumulative'):
                labels=new['labels'].tolist();idx=[labels.index(f'{grid}-4-comp_'+r) for r in ('momentum','density')]
                vel=vis(new[frame][:,idx]-prior[frame][:,idx])
                olddiff=vis(prior[frame][:,idx[1]]-prior[frame][:,idx[0]])
                fresh=vis(new[frame][:,idx[1]]-new[frame][:,idx[0]])
                assert max(norm((fresh-olddiff)-(vel[:,1]-vel[:,0]))/small)<1e-10
                rows.append(dict(grid=grid,frame=frame,old_gap_pct=(100*norm(olddiff)/small).tolist(),new_gap_pct=(100*norm(fresh)/small).tolist(),substitution_gap_vector_norm_pct=(100*norm(fresh-olddiff)/small).tolist(),route_substitution_pct=[(100*norm(vel[:,slot])/small).tolist() for slot in (0,1)]))
    put(LATE/'intervention.json',dict(effect=rows,forecast=sha(LATE/'paired-forecast.json')))
if __name__=='__main__':{'bridge':mid_photons,'late':late_photons,'score':evaluate}[sys.argv[1]]()
