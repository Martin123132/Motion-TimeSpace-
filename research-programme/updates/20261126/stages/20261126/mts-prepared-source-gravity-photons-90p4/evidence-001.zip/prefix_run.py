from unittest.mock import patch
from source_pair import *
OUT=ROOT/'prefix'
def run():
    guard();test_sources()
    pre=module(PREFIX,'exact_source_stage');join=module(PREFIX,'evolve_shared')
    trace=join.Shared();period=pre.import_at(pre.OLD,'partial');resolved=pre.import_at(pre.REF,'joint77_evolve')
    models={tag:Sources(tag) for tag in ('matched','wave')}
    method=OUT/'method-v2.json';receipt(method,[ROOT/key for key in ('source_pair.py','prefix_run.py','PROTOCOL.md','source-interface.json')]+[pin(INVERSE,tag+'-native-prepared-sources.npz') for tag in models]+[pin(PREFIX,key) for key in ('entry-freeze.json','evolve_shared.py','shared_trace.py')])
    def locked(name):
        assert name in ('protocol.json','entry-freeze.json');guard();check(method)
    first=period.first;items=(first,period.second,period.third,period.fourth,period)
    parent_host=period.Host
    def host(grid,sub):return models['matched'].install(parent_host(grid,sub))
    for mod in items:
        mod.ROOT=OUT;mod.Host=host;mod.save=lambda name,raw:save(OUT/name,raw)
        if mod is first:mod.verify=locked
        else:mod.locked=locked
    for mod,key,label in zip(items[1:],('source','parent','parent','parent'),('period-','second-','third-','fourth-')):
        orig=getattr(mod,key)
        setattr(mod,key,lambda name,orig=orig,label=label:OUT/name if name.startswith(label) and name.endswith('.npz') else orig(name))
    original=first.pinned
    first.pinned=lambda folder,name:pin(PREFIX,name) if (folder==pre.PAIR and name.startswith('matched-switch-')) or (folder==pre.EXCH and name=='forecast.json') else original(folder,name)
    join.ROOT=resolved.ROOT=period.joint.window.ROOT=period.joint.common.ROOT=OUT
    resolved.locked=locked;join.pack=resolved.pack=lambda name,**fields:pack(OUT/name,**fields)
    native_source=resolved.old.source
    with np.load(pre.pin(pre.BANK,'material-halfstep/forcing-heavy.npz')) as data:
        times=data['eta'];mask=(times>trace.at-.30)&(times<=trace.at);old_current=data['values'][data['keys'].tolist().index('hJ'),mask,0]
    factory=first.make_interp_spline
    def history(grid):
        calls=[]
        def spline(x,y,**kw):
            if y.ndim==1 and np.array_equal(x,times[mask]) and np.array_equal(y,old_current):
                calls.append(1);return lambda t:trace(np.log(t))[...,1]
            return factory(x,y,**kw)
        with patch.object(first,'make_interp_spline',spline):hist=first.History(grid)
        assert calls==[1];return hist
    refbank=resolved.Bank();bank=period.MatchedBank()
    for grid in ('p16','p32'):
        srcfile=f'switch-{grid}.npz';save(OUT/srcfile,pin(PREFIX,srcfile).read_bytes())
        hist=history(grid)
        for sub in (2,4):
            for mod,label in zip(items,('period','second','third','fourth','partial')):
                name=f'{label}-{grid}-{sub}.npz';stamp=OUT/(name+'.receipt')
                if not stamp.exists():mod.run(grid,sub,bank,hist);receipt(stamp,[method,OUT/name])
                check(stamp)
            join.combine(grid,sub)
            with patch.object(resolved.old,'source',lambda grid:models['wave'].install(native_source(grid))):
                name=f'joint-{grid}-{sub}.npz';stamp=OUT/(name+'.receipt')
                if not stamp.exists():
                    control=resolved.run(grid,sub,refbank);put(OUT/(name+'.json'),control);receipt(stamp,[method,OUT/name,OUT/(name+'.json')])
                check(stamp)
            with np.load(OUT/f'period-{grid}-{sub}.npz') as fresh,np.load(pin(PREFIX,f'period-{grid}-{sub}.npz')) as archived:
                assert np.array_equal(fresh['entry'],archived['entry']) and np.array_equal(fresh['traces'][0,:,1],archived['traces'][0,:,1])
            print('carried to 89.6',grid,sub,flush=True)
    receipt(OUT/'gravity-freeze.json',[method,*sorted(OUT.glob('*.npz')),*sorted(OUT.glob('*.receipt'))])
if __name__=='__main__':run()
