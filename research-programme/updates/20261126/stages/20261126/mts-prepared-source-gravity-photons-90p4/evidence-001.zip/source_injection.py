from source_pair import *
def run():
    pre=module(PREFIX,'exact_source_stage');period=pre.import_at(pre.OLD,'partial')
    rows=[]
    for tag in ('wave','matched'):
        bundle=Sources(tag)
        for grid in ('p16','p32'):
            src=period.Host(grid,4) if tag=='matched' else period.old.source(grid)
            if tag=='matched':src.focus=89.18
            times=np.linspace(89.157,89.231,11)
            fresh=bundle.install(src)
            orig=src.environment(times)[1];target=fresh.environment(times)[1]
            assert all(np.array_equal(orig[key],target[key]) for key in orig if key not in KEYS)
            before=period.coefficients(src,times);after=period.coefficients(fresh,times)
            for index in (1,2,3,7,8):assert np.array_equal(before[index],after[index])
            delta={key:target[key]-orig[key] for key in ('henergy','hJ','hshear','hfield','hmoment')}
            slip=delta['hshear']/src.kk
            def err(observed,predicted):return 100*np.max(abs(observed-predicted))/np.max(abs(predicted))
            checks={key:err(after[index]-before[index],delta[key] if key!='hshear' else slip) for index,key in [(4,'henergy'),(5,'hJ'),(6,'hshear')]}
            solvers=[period.old.Wave(x) for x in (src,fresh)]
            biases=[s.rhs(s.env(times,times),np.zeros((len(times),13),complex)) for s in solvers]
            bg=after[0];actual=biases[1]-biases[0]
            expect=[delta['hfield']+bg['hv']*slip,delta['hmoment']-(bg['a']*bg['hm'])**2*bg['hb']*slip,delta['hJ']/(2*src.kk)-bg['h']*slip]
            checks.update({key:err(actual[:,idx],pred) for idx,key,pred in zip((10,11,12),('field_rhs','moment_rhs','phi_rhs'),expect)})
            assert max(checks.values())<=.5,checks
            rows.append(dict(tag=tag,grid=grid,check_pct_of_change=checks))
    put(ROOT/'injection.json',rows);print('Single-insertion force/current/shear checks passed, both grids.')
if __name__=='__main__':run()
