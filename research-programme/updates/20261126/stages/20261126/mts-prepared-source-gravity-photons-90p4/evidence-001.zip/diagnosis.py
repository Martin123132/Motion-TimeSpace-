from continuation import *
def run():
    check(LATE/'paired-forecast.json')
    stage=module(FINAL,'balance90')
    stage.ROOT=LATE;stage.check=lambda name:check(LATE/name)
    stage.put=lambda name,data:put(LATE/name,data);stage.pack=lambda name,**fields:pack(LATE/name,**fields)
    stage.run()
    restart=module(FINAL,'restart90')
    restart.ROOT=LATE;restart.put=stage.put;restart.check=stage.check;restart.run()
if __name__=='__main__':run()
