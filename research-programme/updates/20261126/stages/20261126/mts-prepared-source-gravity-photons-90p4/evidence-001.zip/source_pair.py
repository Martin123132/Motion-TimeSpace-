from functools import lru_cache
from pathlib import Path
from io import BytesIO
from copy import copy
import hashlib
import json
import sys
import numpy as np
from scipy.interpolate import make_interp_spline, BPoly

ROOT=Path(__file__).resolve().parent
BASE=ROOT.parent
INVERSE=BASE/'mts-prepared-quadrature-inverse-90p4-20261126'
PREFIX=BASE/'mts-native-switch-source-and-photons-89p6-20261126'
BRIDGE=BASE/'mts-carried-photon-window-89p65-20261126'
FINAL=BASE/'mts-carried-gravity-photons-90p4-20261126'
PINS={INVERSE:'8b191e3b559690de4266bdf4b2d3324f1d815f67a597d0935a27122413bb0c41',PREFIX:'c42d28f230ca89ae248d7740911cb741ba32f261b261b4ff7e11e03a163d4661',BRIDGE:'eaea6794d8575dc50213b70bed708bffd881fffa318d57ac2c2faed0300ad2c7',FINAL:'9255065ecee560e1933ced73cb9cc0ba3561e6bbfe1259f7c93d7b41c7992680'}
KEYS=['hfield','hmoment','henergy','htrace','hJ','hshear']
def sha(path):
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
@lru_cache()
def pin(folder,name):
    assert sha(folder/'seal.json')==PINS[folder],folder
    path=folder/name;assert sha(path)==json.loads((folder/'seal.json').read_bytes())['files'][name],path
    return path
def guard():
    assert not any((folder/'STOP-REQUESTED').exists() for folder in [ROOT,BASE,*PINS])
def save(path,data):
    guard()
    if path.exists():assert sha(path)==hashlib.sha256(data).hexdigest(),path
    else:
        path.parent.mkdir(exist_ok=True)
        tmp=path.with_suffix(path.suffix+'.partial')
        with tmp.open('xb') as stream:stream.write(data)
        tmp.rename(path)
def put(path,data):save(path,(json.dumps(data,sort_keys=True,indent=2,allow_nan=False,default=lambda value:value.item())+'\n').encode())
def pack(path,**fields):
    stream=BytesIO();np.savez_compressed(stream,**fields);save(path,stream.getvalue())
def receipt(path,files):put(path,{str(f.relative_to(BASE)):sha(f) for f in files})
def check(path):
    for name,digest in json.loads(path.read_bytes()).items():assert sha(BASE/name)==digest,name
def module(folder,name):
    pin(folder,name+'.py');sys.path.insert(0,str(folder))
    result=__import__(name);assert Path(result.__file__).parent==folder
    return result

class Sources:
    def __init__(self,tag):
        with np.load(pin(INVERSE,tag+'-native-prepared-sources.npz')) as data:
            self.k=data['k'][0];self.time=time=data['time'];self.values=data['values'][:,:,0].T
            assert data['keys'].tolist()==KEYS+['hJprime']
        with np.load(pin(PREFIX,'native-standard.npz')) as ar:
            self.start=ar['t'][1];self.common=ar['source'][1];assert ar['wave']==self.k
        self.entry=np.log(self.start)
        right=time>self.start
        self.raw=make_interp_spline(np.log(time),self.values[:,:6],k=5)
        one=make_interp_spline(np.log(time[right]),self.values[right,:6],k=5)
        self.right=np.log(time[right][0])
        self.raw_entry=self.raw(self.entry);self.right_entry=one(self.entry)
        self.target=self.right_entry.copy() if tag=='matched' else self.raw_entry.copy()
        self.target[[2,4]]=self.common
        slope=one(self.entry,1) if tag=='matched' else self.raw(self.entry,1)
        acc=one(self.entry,2) if tag=='matched' else self.raw(self.entry,2)
        self.splice=BPoly.from_derivatives([self.entry,self.right],[[self.target,slope,acc],[self.raw(self.right,nu) for nu in range(3)]])
    def read(self,log,nu=0):
        z=np.asarray(log);x=z.reshape(-1);assert min(x)>=self.entry-1.e-14 and max(x)<=np.log(self.time[-1])
        out=self.raw(x,nu);mask=x<self.right
        if mask.any():out[mask]=self.splice(x[mask],nu)
        if not nu:out[x==self.entry]=self.target
        return out.reshape((*z.shape,6))
    def external(self,log,nu=0):return self.read(log,nu)[...,[0,1,2,4]]
    def install(self,obj):
        obj=copy(obj);base=type(obj);src=self
        if hasattr(obj,'external'):
            assert obj.micro_keys==[KEYS[i] for i in (0,1,2,4)];obj.external=self.external
        assert obj.wave==self.k or np.isclose(obj.wave,self.k,rtol=1e-12,atol=0)
        class Replaced(base):
            def environment(self,t,side=None):
                raw=super().environment(t,side);assert set(KEYS)-set(raw[1])==({'htrace'} if hasattr(self,'external') else set())
                force=dict(raw[1]);force.update(zip(KEYS,src.read(np.log(t)).T))
                return (raw[0],force,*raw[2:])
        obj.__class__=Replaced
        return obj

def test_sources():
    arr={}
    for tag in ('wave','matched'):
        src=Sources(tag);time=src.time[(src.time>src.start)&(src.time<=90.4)]
        values=src.read(np.log(time));native=src.values[(src.time>src.start)&(src.time<=90.4)]
        assert np.max(abs(values-native[:,:6]),axis=0).max()<1e-24
        assert np.array_equal(src.read(src.entry)[[2,4]],src.common)
        d=src.external(np.log(time),1)[:,3]/time
        arr[tag]=dict(pointwise_own_peak_knot_replay_pct=(100*np.max(abs(values-native[:,:6]),axis=0)/np.max(abs(values),axis=0)).tolist(),entry_bracket_minus_exact_pct=(100*abs(src.raw_entry[[2,4]]/src.common-1)).tolist(),right_limit_minus_exact_pct=(100*abs(src.right_entry[[2,4]]/src.common-1)).tolist(),current_derivative_vs_equation_pct=100*np.max(abs(d-native[:,6]))/np.max(abs(native[:,6])),n=len(time))
    put(ROOT/'source-interface.json',arr)
    print(arr,flush=True)
if __name__=='__main__':test_sources()
