from source_pair import *
from scipy.interpolate import CubicSpline
from unittest.mock import patch
PREFIX_OUT=ROOT/'prefix';MID=ROOT/'bridge';LATE=ROOT/'late'
def link_to_prefix(original):
    def read(folder,name):
        if folder==PREFIX and name.startswith(('fourth-','partial-','joint-','full-grid-')) and name.endswith('.npz'):
            return PREFIX_OUT/name
        return original(folder,name)
    return read
def mid():
    check(PREFIX_OUT/'gravity-freeze.json')
    stage=module(BRIDGE,'carry_gravity');pre=stage.prefix();p=pre.import_at(pre.OLD,'partial')
    kernel=pre.import_at(stage.KER,'wave_kernel') if stage.KER in pre.PINS else module_by(stage.KER,'wave_kernel',stage.pin)
    method=MID/'method.json';receipt(method,[PREFIX_OUT/'gravity-freeze.json',ROOT/'continuation.py',ROOT/'source_pair.py',pin(BRIDGE,'carry_gravity.py')])
    stage.pin=link_to_prefix(stage.pin);stage.pack=lambda name,**fields:pack(MID/name,**fields)
    prior_guard=stage.guard
    def protected():guard();prior_guard()
    stage.guard=protected
    files=[]
    for grid in ('p16','p32'):
        kernels=kernel.read(grid)
        for tag in ('matched','wave'):
            bank=p.MatchedBank() if tag=='matched' else p.joint.Bank();srcs=Sources(tag)
            with np.load(pin(BRIDGE,f'incident-{tag}-16.npz')) as data:
                assert np.array_equal(bank.q,data['q']) and bank.k==data['k']
                log=np.log(data['t']);bank.micro=CubicSpline(log,data['micro'],extrapolate=False);bank.sw=CubicSpline(log,data['Sw'],extrapolate=False)
                for sub in (2,4):
                    path=MID/f'carry-{tag}-{grid}-{sub}.npz';stamp=path.with_suffix('.receipt')
                    if not stamp.exists():
                        src,mem=stage.env_for(p,grid,sub,tag,bank,data,kernels)
                        stage.evolve(p,srcs.install(src),mem,bank,grid,sub,tag)
                        receipt(stamp,[method,path])
                    check(stamp);files.extend([path,stamp])
    receipt(MID/'gravity-freeze.json',[method,*files])
def module_by(folder,name,locator):
    locator(folder,name+'.py');sys.path.insert(0,str(folder));return __import__(name)

def late():
    check(MID/'gravity-freeze.json')
    io=module(FINAL,'window_io');sources=module(FINAL,'sources90');step=module(FINAL,'stepper');stage=module(FINAL,'evolve90')
    pre=io.oldio.prefix();p=pre.import_at(pre.OLD,'partial')
    method=LATE/'method.json';receipt(method,[MID/'gravity-freeze.json',ROOT/'continuation.py',ROOT/'source_pair.py',*[pin(FINAL,key+'.py') for key in ('window_io','sources90','stepper','evolve90')]])
    def fresh(folder,name):
        if folder==BRIDGE and (name.startswith('carry-') or name.startswith('photon-')):return MID/name
        return io.sealed(folder,name)
    io.oldio.pin=link_to_prefix(io.oldio.pin)
    oldguard=step.guard
    def protected():guard();oldguard()
    step.guard=protected
    for mod in (step,sources,stage):
        mod.ROOT=LATE;mod.sealed=fresh;mod.pack=lambda name,**fields:pack(LATE/name,**fields)
    stage.put=lambda name,data:put(LATE/name,data)
    stage.freeze=lambda name,names:receipt(LATE/name,[LATE/n for n in names])
    stage.check=lambda name:check(LATE/name)
    orig=stage.setup
    def setup(p,grid,sub,tag,bank):
        src,hist=orig(p,grid,sub,tag,bank);return Sources(tag).install(src),hist
    stage.setup=setup
    for grid in ('p16','p32'):
        for tag in ('matched','wave'):
            bank=p.MatchedBank() if tag=='matched' else p.joint.Bank()
            for sub in (2,4):stage.branch(p,grid,sub,tag,bank)
    receipt(LATE/'gravity-freeze.json',[method,*sorted(LATE.glob('*.npz')),*sorted(LATE.glob('*.receipt')),*sorted(LATE.glob('history-*.json'))])
if __name__=='__main__':{'bridge':mid,'late':late}[sys.argv[1]]()
