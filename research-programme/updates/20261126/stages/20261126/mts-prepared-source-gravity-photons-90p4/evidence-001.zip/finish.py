from continuation import *
def finish():
    for path in (PREFIX_OUT/'gravity-freeze.json',MID/'prediction-freeze.json',LATE/'paired-forecast.json',LATE/'gravity-freeze.json'):check(path)
    for folder,digest in PINS.items():assert sha(folder/'seal.json')==digest
    assert not list(ROOT.rglob('*.partial')) and not list(ROOT.rglob('__pycache__'))
    report=json.loads((ROOT/'validation.json').read_bytes());assert len(report['chain'])==8 and len(report['resolved_control'])==12 and len(report['compensated_source'])==24
    sources=json.loads((ROOT/'injection.json').read_bytes());assert len(sources)==4
    account=json.loads((LATE/'substitution-work.json').read_bytes())
    for row in account:
        total=sum(row['direct_and_state_joint_points'].values())+row['early_substitution_points']+row['prior_gap_projection']
        assert abs(total-row['new_joint_points'])<1e-6
    early=json.loads((LATE/'early-direct-work.json').read_bytes());cell=json.loads((LATE/'first-cell-check.json').read_bytes())
    for initial,edge,late in zip(early,cell,account,strict=True):
        assert initial['grid']==edge['grid']==late['grid'] and initial['kick']==0 and edge['end']==89.15
        assert abs(initial['total_signed_points']-late['early_substitution_points'])<1e-6
        assert abs(edge['exact_cell_signed_points']-initial['signed']['switch_to_first_knot'])<1e-6
        assert max(edge['boundary_error_pct']+edge['ramp_error_pct'])<=.5
    assert sha(LATE/'scores.json')==json.loads((LATE/'balance.json').read_bytes())['scores']
    restart=json.loads((LATE/'restart90.json').read_bytes());assert restart['epoch']==90.4
    def validate(obj):
        if isinstance(obj,dict):
            if 'sha256' in obj:assert sha(BASE/obj['file'])==obj['sha256']
            else:
                for elem in obj.values():validate(elem)
    validate(restart)
    for filename in ('RESULTS.md','CURRENT-TRANSFER.md','PROTOCOL.md','source-interface.json','source_injection.py','direct_transfer.py'):
        assert (ROOT/filename).is_file()
    files={path.relative_to(ROOT).as_posix():sha(path) for path in sorted(ROOT.rglob('*')) if path.is_file() and path!=ROOT/'seal.json'}
    put(ROOT/'seal.json',dict(scope='Paired prepared microscopic forcing from exact switch to 90.4, retained photon diagnostic, two grids',files=files,parents={folder.name:value for folder,value in PINS.items()},historical_nonactive_receipts=['prefix/method.json']))
    print('seal',sha(ROOT/'seal.json'),len(files))
if __name__=='__main__':finish()
