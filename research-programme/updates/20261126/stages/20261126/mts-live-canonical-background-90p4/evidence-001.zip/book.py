from pathlib import Path
import sys
import hashlib
import io
import json
import os
import numpy as np

ROOT=Path(__file__).resolve().parent
BASE=ROOT.parent
PRE=BASE/"mts-native-quadratic-gravity-90p4-20261126"
PIN="8d5eef7334d179a25da791cd074907bdc6c88f281e6a7f6c0cdae8538814f783"

def sha(path):
    with path.open("rb") as stream:return hashlib.file_digest(stream,"sha256").hexdigest()

assert sha(PRE/"seal.json")==PIN
sys.path.insert(0,str(PRE))
from support import pinned
import native_io as inherited

ANCHOR=89.65
END=90.4
GATE=.5

def guard():
    inherited.guard()
    assert not any((folder/"STOP-REQUESTED").exists() for folder in (ROOT,BASE,PRE))

def save(name,raw):
    guard();path=ROOT/name
    if path.exists():
        assert sha(path)==hashlib.sha256(raw).hexdigest(),name
        return
    path.parent.mkdir(exist_ok=True,parents=True)
    temp=path.with_suffix(path.suffix+".partial")
    with temp.open("xb") as stream:stream.write(raw)
    temp.rename(path)

def put(name,obj):
    save(name,(json.dumps(obj,sort_keys=True,allow_nan=False,indent=2,default=lambda v:v.item())+"\n").encode())

def pack(name,**arrays):
    buf=io.BytesIO();np.savez_compressed(buf,**arrays);save(name,buf.getvalue())

def read(path):
    with np.load(path) as data:return dict(data.items())

def record(name,paths):
    put(name,{p.relative_to(BASE).as_posix():sha(p) for p in paths})

def check(name):
    for key,value in json.loads((ROOT/name).read_bytes()).items():assert sha(BASE/key)==value,key

def capture_module():
    sys.path.insert(0,str(inherited.historic.io.EXT))
    import source_io as ext
    return ext.previous.prefix().import_at(ext.SOURCE,"capture89")

def config(cap,label):
    native=cap.diag.native
    status=native.obj(native.source(f"runs/{'cold' if label=='cold' else 'heavy'}/status.json"))
    for file in native.engine.inherited.native_hashes():native.checked(file,status["input_hashes"][str(file)])
    if label=="cold":
        path=native.NATIVE/"runs/backgrounds/cold.npz"
        native.checked(path,status["source_hash"])
    else:
        path=pinned(inherited.historic.io.oldio.PAD,"canonical-input.npz")
    return path

def params(cap,label):
    native=cap.diag.native
    settings=native.engine.inherited.params_for(config(cap,label),background_boost=8.)
    settings.DoLateRadTruncation=False
    if label in ("primary","fine"):
        with np.load(ROOT/f"table-{label}.npz") as ar:
            settings.DarkEnergy.set_table("SetHeavyTable",ar["x"],ar["b"],ar["v"])
    return settings
