from prepare_table import CubicSpline, solve_ivp, exp, sqrt
from book import *


def main():
    check("preflight-freeze.json")
    cap=capture_module();cfg=params(cap,"original");source=config(cap,"original");bank=read(source)
    native=cap.diag.native.engine.camb.get_background(cfg)
    old=read(pinned(PRE,"sectors-heavy.npz"));obs=old["values"][0,:,old["names"].tolist().index("a")]
    start=np.log(obs[np.flatnonzero(old["t"]==ANCHOR).item()])
    grid=bank["heavy_efold"];angle=bank["phase_h"];left=np.searchsorted(grid,start)-1
    assert grid[left]<start<grid[left+1]
    slow=CubicSpline(bank["efold"],bank["phi_s"]);slow_v=CubicSpline(bank["efold"],bank["phidot_s"])
    def outside(points):
        scale=np.ascontiguousarray(np.exp(points))
        dens=native.get_background_densities(scale,vars=["K","cdm","baryon","photon","neutrino","nu"],format="array")
        return dens.sum(1)/scale**2+(slow_v(points)**2+(scale*bank["slow_mass_mpc"]*slow(points))**2)/2
    mesh=np.linspace(start,grid[-1],2049);rest=CubicSpline(mesh,outside(mesh))
    mid=(mesh[1:]+mesh[:-1])/2;interp=float(100*np.max(abs(rest(mid)/outside(mid)-1)))
    assert interp<1e-8
    incoming=CubicSpline(grid,np.column_stack((bank["phi_h"],bank["phidot_h"])),bc_type="natural")
    first=incoming(start);mass=float(bank["heavy_mass_mpc"])
    def rhs(point,state):
        field,speed=state;mu=mass*exp(point);hubble=sqrt((float(rest(point))+(speed**2+(mu*field)**2)/2)/3)
        return [speed/hubble,-2*speed-mu**2*field/hubble]
    sol=solve_ivp(rhs,(start,grid[-1]),first,method="DOP853",rtol=3e-13,atol=np.maximum(abs(first)*1e-15,1e-26),dense_output=True)
    assert sol.success
    mesh=np.r_[start,grid[left+1:]];angles=np.r_[np.interp(start,grid[left:left+2],angle[left:left+2]),angle[left+1:]]
    leftmesh=np.linspace(grid[left],start,17)[:-1];pre=np.r_[grid[:left],leftmesh]
    past=np.vstack((np.column_stack((bank["phi_h"][:left],bank["phidot_h"][:left])),incoming(leftmesh)))
    checks={}
    for label,spacing in (("primary",.04),("fine",.02)):
        counts=np.ceil(np.diff(angles)/spacing).astype(int);assert np.all(counts>=1)
        new=np.concatenate([np.linspace(lo,hi,count,endpoint=False) for lo,hi,count in zip(mesh[:-1],mesh[1:],counts)]+[mesh[-1:]])
        coords=np.r_[pre,new];fv=np.vstack((past,sol.sol(new).T))
        assert (np.diff(coords)>0).all() and np.array_equal(fv[len(pre)],first)
        joined=CubicSpline(coords,fv,bc_type="natural")
        probe=np.linspace(grid[left-5],start,1001)
        delta=np.max(abs(joined(probe)-incoming(probe)),axis=0)/np.max(abs(incoming(probe)),axis=0)
        checks[label]=dict(knot_count=len(coords),join_x=float(start),prejoin_interpolation_difference_pct=(100*delta).tolist(),relative_rest_interpolation_pct=interp)
        pack("joined/table-"+label+".npz",x=coords,b=fv[:,0],v=fv[:,1],launch_index=len(pre))
    put("joined/table-check.json",checks)
    record("joined/table-freeze.json",[ROOT/"EXACT-JOIN.md",ROOT/"joined_table.py",ROOT/"preflight-freeze.json",ROOT/"table-freeze.json",ROOT/"joined/table-check.json",ROOT/"joined/table-primary.npz",ROOT/"joined/table-fine.npz"])
    print(checks,flush=True)


if __name__=="__main__":main()
