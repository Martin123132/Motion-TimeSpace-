from book import *
import run_live
import score_live
import subprocess
import tempfile
from contextlib import ExitStack
from unittest.mock import patch


JOIN=ROOT/"joined"


def install(cap,label):
    cfg=params(cap,"cold" if label=="cold" else "original")
    if label in ("primary","fine"):
        with np.load(JOIN/f"table-{label}.npz") as ar:
            cfg.DarkEnergy.set_table("SetHeavyTable",ar["x"],ar["b"],ar["v"])
    return cfg


def write_scope(module):
    stack=ExitStack()
    stack.enter_context(patch.object(module,"ROOT",JOIN))
    for name,func in (("save",save),("pack",pack),("record",record),("put",put),("check",check)):
        if hasattr(module,name):
            stack.enter_context(patch.object(module,name,lambda path,*args,_func=func,**kw:_func("joined/"+path,*args,**kw)))
    return stack


def main():
    if sys.argv[1:2]==["--child"]:
        with write_scope(run_live),patch.object(run_live,"params",install):
            run_live.child()
        return
    mode=sys.argv[1];guard();check("joined/table-freeze.json")
    if mode=="score":
        with write_scope(score_live),patch.object(score_live,"record",lambda name,paths:record("joined/"+name,[ROOT/"score_live.py" if p==JOIN/"score_live.py" else p for p in paths])):
            score_live.preflight()
        return
    assert mode in ("preflight","all")
    if mode=="all":
        check("joined/preflight-freeze.json")
        assert json.loads((JOIN/"preflight.json").read_bytes())["ready_for_whole_bank"]
    record("joined/live-method.json",[ROOT/"joined_run.py",ROOT/"run_live.py",ROOT/"score_live.py",ROOT/"SCORING.md",ROOT/"joined/table-freeze.json"])
    for label in ("original","cold"):
        name=f"bank/{label}-04.npz"
        check(name+".receipt")
        if not (JOIN/name).exists():
            save("joined/"+name,(ROOT/name).read_bytes())
        assert sha(JOIN/name)==sha(ROOT/name)
        record("joined/"+name+".receipt",[JOIN/name,JOIN/"live-method.json",ROOT/(name+".receipt")])
    with tempfile.TemporaryDirectory(prefix="reader-mts-",dir=JOIN) as tmp:
        env=dict(os.environ,MTS_LIVE_NATIVE_STAGE=mode)
        subprocess.run([sys.executable,"-B",str(ROOT/"joined_run.py"),"--child",tmp,*run_live.MODELS],env=env,check=True)
    receipts=sorted((JOIN/"bank").glob("*.receipt"))
    assert len(receipts)==(4 if mode=="preflight" else 4*38)
    record("joined/"+mode+"-forecast.json",[JOIN/"live-method.json",JOIN/"live-readout.f90",*receipts])


if __name__=="__main__":main()
