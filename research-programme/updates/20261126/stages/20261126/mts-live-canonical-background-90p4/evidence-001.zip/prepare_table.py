from book import *
from scipy.integrate import solve_ivp
from scipy.interpolate import CubicSpline
from math import exp,sqrt


def prepare():
    guard();cap=capture_module();canonical=config(cap,"original");bank=read(canonical)
    settings=params(cap,"original");assert settings.omk==0.
    camb=cap.diag.native.engine.camb;host=camb.get_background(settings)
    old=read(pinned(PRE,"sectors-heavy.npz"));cut=np.flatnonzero(old["t"]==ANCHOR).item()
    arow=old["values"][0,:,old["names"].tolist().index("a")]
    hrow=old["values"][0,:,old["names"].tolist().index("adotoa")]
    grid=bank["heavy_efold"];angle=bank["phase_h"];idx=np.searchsorted(grid,np.log(arow[cut]),side="right")-1
    start=grid[idx];end=grid[-1];mass=float(bank["heavy_mass_mpc"])
    first=np.array([bank["phi_h"][idx],bank["phidot_h"][idx]])
    def ordinary(x):
        a=np.ascontiguousarray(np.exp(x))
        fields=host.get_background_densities(a,vars=["K","cdm","baryon","photon","neutrino","nu"],format="array")
        return fields.sum(1)/a**2
    slow_b=CubicSpline(bank["efold"],bank["phi_s"]);slow_v=CubicSpline(bank["efold"],bank["phidot_s"])
    def rest(x):return ordinary(x)+.5*(slow_v(x)**2+(np.exp(x)*bank["slow_mass_mpc"]*slow_b(x))**2)
    test=np.log(arow);original_b=CubicSpline(grid,bank["phi_h"]);original_v=CubicSpline(grid,bank["phidot_h"])
    h=np.sqrt((rest(test)+.5*(original_v(test)**2+(mass*arow*original_b(test))**2))/3)
    replay=100*np.max(abs(h/hrow-1));assert replay<1e-6,replay
    knots=np.linspace(start,end,2049);fixed=CubicSpline(knots,rest(knots))
    cross=(knots[1:]+knots[:-1])/2
    interp=100*np.max(abs(fixed(cross)/rest(cross)-1));assert interp<1e-8
    def eq(x,y):
        b,v=y;mu=mass*exp(x);H=sqrt((float(fixed(x))+(v*v+(mu*b)**2)/2)/3)
        return [v/H,-2*v-mu*mu*b/H]
    sol=solve_ivp(eq,(start,end),first,rtol=3e-13,atol=np.maximum(abs(first)*1e-15,1e-26),method="DOP853",dense_output=True)
    assert sol.success
    results=[]
    for label,maxphase in (("primary",.04),("fine",.02)):
        pieces=np.ceil(np.diff(angle[idx:])/maxphase).astype(int)
        assert np.all(pieces>=1)
        x=np.concatenate([np.linspace(lo,hi,count,endpoint=False) for lo,hi,count in zip(grid[idx:-1],grid[idx+1:],pieces)]+[grid[-1:]])
        b,v=sol.sol(x);gx=np.r_[grid[:idx],x];bb=np.r_[bank["phi_h"][:idx],b];vv=np.r_[bank["phidot_h"][:idx],v]
        assert len(gx)==len(np.unique(gx)) and np.array_equal(first,[bb[idx],vv[idx]])
        derivative=CubicSpline(gx,bb);velocity=CubicSpline(gx,vv)
        xt=test[(test>=np.log(arow[cut]))];mu=mass*np.exp(xt);fb=derivative(xt);fv=velocity(xt);hh=np.sqrt((fixed(xt)+(fv**2+(mu*fb)**2)/2)/3)
        rb=hh*derivative(xt,1)-fv;rv=hh*velocity(xt,1)+2*hh*fv+mu**2*fb
        results.append(dict(label=label,knot_count=len(gx),max_angle_step=maxphase,
                            rb_pct_of_speed=100*np.max(abs(rb))/np.max(abs(fv)),rv_pct_of_acceleration=100*np.max(abs(rv))/np.max(abs(mu**2*fb))))
        pack(f"table-{label}.npz",x=gx,b=bb,v=vv,launch_index=idx)
    put("table-check.json",dict(start=start,end=end,first_a=exp(start),nominal_a=float(arow[cut]),original_H_replay_pct=replay,
           external_interpolation_pct=interp,native_exact_a_limit=settings.DarkEnergy.heavy_exact_limit,variants=results,
           unchanged="Cold, ordinary thermal species, slow scalar, primordial parameters and late fluid extrapolation; no late two-field completeness assertion."))
    record("table-freeze.json",[ROOT/"book.py",ROOT/"PROTOCOL.md",ROOT/"prepare_table.py",canonical,pinned(PRE,"sectors-heavy.npz"),PRE/"seal.json",ROOT/"table-check.json",ROOT/"table-primary.npz",ROOT/"table-fine.npz"])
    print(results,flush=True)

if __name__=="__main__":prepare()
