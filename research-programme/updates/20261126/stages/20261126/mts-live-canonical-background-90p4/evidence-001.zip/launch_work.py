from score_live import columns, maximum
from book import *


def audit():
    check("preflight-freeze.json");check("joined/preflight-freeze.json")
    wave=read(ROOT/"bank/original-04.npz");raw=columns(wave);k=wave["k"];ids=wave["indices"]
    anchor=np.flatnonzero(wave["t"]==ANCHOR).item()
    scale=maximum((raw["sigma"][anchor:]-raw["sigma"][anchor])/k)
    def at(fields,key):return fields[key][anchor]
    original_h=at(raw,"adotoa");source=at(raw,"dgrho")/2+k*at(raw,"etak")
    results=[]
    for name in ("","joined/"):
        for label in ("primary","fine"):
            state=read(ROOT/(name+"bank/"+label+"-04.npz"));new=columns(state)
            assert np.array_equal(state["indices"],ids) and np.array_equal(state["t"],wave["t"])
            hub=at(new,"adotoa")
            def delta(key):return at(new,key)-at(raw,key)
            terms=np.array([delta("mts_drho_h")/(2*hub*k**2),(delta("dgrho")-delta("mts_drho_h"))/(2*hub*k**2),delta("etak")/(hub*k),
                       -(hub-original_h)*source/(hub*original_h*k**2),1.5*delta("mts_q_h")/k**3,1.5*(delta("dgq")-delta("mts_q_h"))/k**3])
            exact=delta("sigma")/k
            err=float(np.max(100*abs(terms.sum(0)-exact)/scale))
            assert err<1e-6,err
            index=np.argmax(abs(exact)/scale)
            results.append(dict(join="exact" if name else "previous_knot",wave_table=label,index=int(ids[index]),k=float(k[index]),
                  max_offset_pct=float(100*abs(exact[index])/scale[index]),signed_terms_pct=(100*terms[:,index]/scale[index]).tolist(),
                  max_decomposition_error_pct=err))
    put("launch-work.json",dict(units="percent of original mode's own maximum shear change",term_order=["heavy density","other density","curvature","homogeneous H","heavy current","other current"],results=results))
    record("launch-work-freeze.json",[ROOT/"launch_work.py",ROOT/"preflight-freeze.json",ROOT/"joined/preflight-freeze.json",ROOT/"launch-work.json"])
    print(results,flush=True)


if __name__=="__main__":audit()
