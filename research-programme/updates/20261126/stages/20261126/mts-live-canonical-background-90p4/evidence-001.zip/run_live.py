from book import *
from unittest.mock import patch
import subprocess
import tempfile
import csv

NAMES="k tau a adotoa etak etakdot sigma sigmadot phi dgpi dgq dgrho grho gpres grhov_t w_lam clxde qde grhog_t grhor_t grhob_t grhoc_t grhonu_t clxg clxr clxb clxc clxnu qg qr vb pig pir".split()
MODELS=("original","primary","fine","cold")


def collect(label,func):
    guard();cap=capture_module();native=cap.diag.native
    with cap.pin("capture-heavy.csv").open() as stream:blocks=list(csv.DictReader(stream))
    assert len(blocks)==38
    number=lambda block:range(int(block["first"]),int(block["last"])+1)
    assert [index for block in blocks for index in number(block)]==list(range(782))
    selected=os.environ["MTS_LIVE_NATIVE_STAGE"]
    wanted=[i for i,row in enumerate(blocks) if selected=="all" or 37 in number(row)]
    assert len(wanted) in (1,38)
    remain=[]
    for index in wanted:
        name=f"bank/{label}-{index:02d}.npz"
        if (ROOT/(name+".receipt")).exists():check(name+".receipt")
        else:remain.append(index)
    if not remain:return
    cfg=params(cap,label);bg=native.engine.camb.get_background(cfg);bg.Params.Accuracy.IntTolBoost=6
    with np.load(pinned(PRE,"native-incoming.npz")) as ar:nodes_all=ar["nodes"]
    epochs=np.arange(round(89.55*320),round(END*320)+1)/320
    tags=["s"] if label=="cold" else ["s","h"]
    extras=["mts_"+field+"_"+tag for tag in tags for field in ("dphi","dphidot","drho","dp","q")]
    with patch.object(cap.diag.symbolic,"compile_sympy_to_camb_source_func",return_value=func):
        for index in remain:
            guard();row=blocks[index];ids=np.array(number(row));spec=nodes_all[ids]
            nodes=np.unique(np.r_[spec,float(row["control"]),float(row["hierarchy_cap"])])
            data=bg.get_time_evolution(nodes,epochs,vars=extras+[cap.Dummy(key) for key in NAMES],lAccuracyBoost=4)[np.searchsorted(nodes,spec)]
            keys=extras+NAMES
            assert np.isfinite(data).all() and np.max(abs(data[:,:,keys.index("k")]-spec[:,None]))<1e-12
            name=f"bank/{label}-{index:02d}.npz"
            pack(name,t=epochs,k=spec,indices=ids,values=data,names=keys,block=index)
            record(name+".receipt",[ROOT/name,ROOT/"live-method.json"])
            print("saved",label,index,ids[0],ids[-1],flush=True)


def child():
    cap=capture_module()
    with patch.object(cap.driver,"HERE",ROOT),patch.object(cap.driver,"NAMES",NAMES),patch.object(cap.driver,"run",collect),patch.object(cap.driver,"save",lambda name,body:save("live-"+name,body)):
        cap.driver.main()


if __name__=="__main__":
    if sys.argv[1:2]==["--child"]:child()
    else:
        guard();check("table-freeze.json");mode=sys.argv[1]
        assert mode in ("preflight","all")
        if mode=="all":check("preflight-freeze.json");assert json.loads((ROOT/"preflight.json").read_bytes())["ready_for_whole_bank"]
        record("live-method.json",[ROOT/"PROTOCOL.md",ROOT/"table-freeze.json",ROOT/"run_live.py",pinned(PRE,"sectors-heavy.npz"),pinned(PRE,"sectors-cold.npz"),ROOT/"SCORING.md"])
        with tempfile.TemporaryDirectory(prefix="reader-mts-",dir=ROOT) as tmp:
            env=dict(os.environ,MTS_LIVE_NATIVE_STAGE=mode)
            subprocess.run([sys.executable,"-B",str(ROOT/"run_live.py"),"--child",tmp,*MODELS],env=env,check=True)
        receipts=sorted((ROOT/"bank").glob("*.receipt"))
        assert len(receipts)==(4 if mode=="preflight" else 4*38)
        record(mode+"-forecast.json",[ROOT/"live-method.json",ROOT/"live-readout.f90",*receipts])
