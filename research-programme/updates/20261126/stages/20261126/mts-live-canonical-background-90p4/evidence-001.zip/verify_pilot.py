from book import *
from score_live import evaluate, pct_change, MODELS
import ast


def verify():
    assert not list(ROOT.rglob("*.partial")) and not list(ROOT.rglob("reader-mts-*"))
    for folder in (ROOT, ROOT/"joined"):
        for path in sorted([*folder.glob("*-method.json"),*folder.glob("*-freeze.json"),*folder.glob("*-forecast.json"),*(folder/"bank").glob("*.receipt")]):
            check(path.relative_to(ROOT))
        score=json.loads((folder/"preflight.json").read_bytes())
        assert score["gate_pct"]==GATE and score["ready_for_whole_bank"]==(folder!=ROOT)
        data={key:read(folder/"bank"/f"{key}-04.npz") for key in MODELS}
        for label,packet in data.items():
            row=score["rows"][label]
            assert packet["indices"].tolist()==list(range(17,41))
            assert np.array_equal(packet["k"],data["original"]["k"]) and np.array_equal(packet["t"],data["original"]["t"])
            assert np.isfinite(packet["values"]).all() and len(packet["t"])==273
            control=evaluate(packet)
            np.testing.assert_allclose(control["err"].max(),row["worst_pct"],rtol=1e-11)
            assert (control["err"].max()<GATE)==(label!="original")
            if label in ("primary","fine"):
                offset=pct_change(data["original"],packet)["sigma"]["launch_pct_change"]
                assert (offset<GATE)==(folder!=ROOT)
                np.testing.assert_allclose(offset,row["vs_original"]["sigma"]["launch_pct_change"],rtol=1e-11)
                assert row["worst_on_original_scale_pct"]<GATE
            else:
                prior=read(pinned(PRE,"sectors-"+("cold" if label=="cold" else "heavy")+".npz"))
                assert np.array_equal(prior["values"],packet["values"])
    for path in ROOT.glob("*.py"):ast.parse(path.read_text(encoding="utf-8"))
    work=json.loads((ROOT/"launch-work.json").read_bytes())
    assert len(work["results"])==4 and all(x["max_decomposition_error_pct"]<1e-8 for x in work["results"])
    files=sorted(path for path in ROOT.rglob("*") if path.is_file() and path.name!="seal.json" and "__pycache__" not in path.parts)
    assert all(not path.is_symlink() for path in files)
    if sys.argv[1:]==["--seal"]:record("seal.json",files)
    else:
        check("seal.json")
        assert set(json.loads((ROOT/"seal.json").read_bytes()))=={path.relative_to(BASE).as_posix() for path in files}
    print("Verified both live pilots, unchanged cold/original controls, shape, receipts and launch decomposition:",len(files),"files;",sha(ROOT/"seal.json"))


if __name__=="__main__":verify()
