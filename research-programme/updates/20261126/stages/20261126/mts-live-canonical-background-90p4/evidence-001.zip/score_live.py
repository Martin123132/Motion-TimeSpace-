from book import *
from scipy.interpolate import make_interp_spline
from numpy.polynomial.legendre import leggauss

MODELS=("original","primary","fine","cold")


def columns(ar):
    return {key:ar["values"][:,:,idx].T for idx,key in enumerate(ar["names"].tolist())}


def maximum(values):return np.max(abs(values),axis=0)


def evaluate(packet,degree=5,order=6):
    t=packet["t"];k=packet["k"];raw=columns(packet)
    start=np.flatnonzero(t==ANCHOR).item();t=t[start:];delta=np.diff(t)
    index=np.searchsorted(t,ANCHOR);assert index==0 and t[-1]==END
    roots,weights=leggauss(order)
    ts=(t[:-1,None]+delta[:,None]*(1+roots)/2).ravel()
    def spl(key):
        return make_interp_spline(packet["t"],raw[key],k=degree)
    def accumulate(arr):
        assert arr.shape==(len(ts),len(k))
        local=np.sum(arr.reshape(-1,order,len(k))*weights[None,:,None],axis=1)*delta[:,None]/2
        return np.vstack((np.zeros((1,len(k))),np.cumsum(local,axis=0)))
    a=spl("a")(ts);H=spl("adotoa");hub=H(ts);h_int=H.antiderivative()
    E=spl("dgrho");J=spl("dgq");etak=spl("etak");shear=spl("sigma")(ts)/k
    stress=spl("dgpi")(ts);pot=spl("phi")(ts);en=E(ts);cur=J(ts);eta=etak(ts)
    R=spl("grho")(ts);press=spl("gpres")(ts)
    X=(en/2+k*eta)/hub;rhs=eta/k-stress/k**2
    anew=raw["a"][start:];alpha=raw["sigma"][start:]/k
    predicted=(anew[:1]**2*alpha[:1]+accumulate(a**2*rhs))/anew**2
    intfactor=np.exp(2*(h_int(ts)-h_int(ANCHOR)));fac_knots=np.exp(2*(h_int(t)-h_int(ANCHOR)))
    clock_pred=(alpha[:1]+accumulate(intfactor*rhs))/fac_knots
    native=alpha[:1]+accumulate(spl("sigmadot")(ts)/k)
    scale=maximum(alpha-alpha[:1]);assert np.all(scale>0)
    defect=100*(alpha-predicted)/scale
    rel=lambda val:100*maximum(val)/scale
    sr=raw["sigmadot"][start:]/k
    shear_rate=raw["etak"][start:]/k-2*raw["adotoa"][start:]*alpha-raw["dgpi"][start:]/k**2
    eqerr=100*maximum(shear_rate-sr)/maximum(sr)
    alg=(X+1.5*cur/k)/k**2
    resid=E(ts,1)+3*hub*J(ts,1)/k+hub*en+k*cur+(R+press)*X+6*hub**2*cur/k+2*hub*stress
    norm=a**2/(2*hub*k**2)
    pieces=np.stack((accumulate(norm*resid),accumulate(norm*2*k*(etak(ts,1)-cur/2)),accumulate(-norm*(R+press+2*H(ts,1)-2*hub**2)*X),accumulate(2*a**2*(spl("a")(ts,1)/a-hub)*shear)))/anew[None]**2
    terms=100*pieces/scale
    work_mismatch=maximum(terms.sum(0)-defect)
    return dict(scale=scale,err=maximum(defect),clock_err=rel(clock_pred-alpha),native_err=rel(native-alpha),
           conservation=np.max(abs(terms),axis=1),integral_accounting=work_mismatch,
           shear_rate_identity=eqerr,shear_constraints_pct_of_level=100*maximum(alg-shear)/maximum(shear),
           weyl_identity_pct_of_own_rate=100*maximum((2*pot-eta/k)-spl("sigmadot")(ts)/k)/maximum(sr),
           normalized_curve=defect,pressure_free_curve=terms[0])


def pct_change(reference,actual):
    a=columns(reference);b=columns(actual);launch=np.flatnonzero(reference["t"]==ANCHOR).item()
    common=[key for key in ("sigma","dgrho","dgq","etak","mts_dphi_h","mts_dphidot_h") if key in a and key in b]
    out={}
    for key in common:
        orig=a[key][launch:];new=b[key][launch:];scale=maximum(orig-orig[:1]);assert np.all(scale>0)
        val=maximum(orig);diff=new-orig
        out[key]=dict(launch_pct_level=float(np.max(100*abs(diff[0])/val)),launch_pct_change=float(np.max(100*abs(diff[0])/scale)),
                      future_difference_pct_change=float(np.max(100*maximum(diff-diff[0])/scale)))
    return out


def block_files(label):
    return sorted((ROOT/"bank").glob(label+"-*.npz"))


def preflight():
    check("preflight-forecast.json")
    data={label:read(block_files(label)[0]) for label in MODELS}
    rows={};ready=True
    reference=evaluate(data["original"])
    for label,packet in data.items():
        ids=packet["indices"];assert 37 in ids and len(ids)==24
        cur=evaluate(packet);comparison=evaluate(packet,3,4);worst=float(cur["err"].max())
        new=dict(worst_pct=worst,leg37_pct=float(cur["err"][ids.tolist().index(37)]),failed=ids[cur["err"]>=GATE].tolist(),
                 normalization_min=float(cur["scale"].min()),quadrature_spread_pct=float(np.max(abs(cur["normalized_curve"]-comparison["normalized_curve"]))),
                 work_accounting_pct=float(cur["integral_accounting"].max()),rate_check_pct=float(cur["shear_rate_identity"].max()))
        if label in ("original","cold"):
            old=read(pinned(PRE,"sectors-"+("cold" if label=="cold" else "heavy")+".npz"))
            assert np.array_equal(old["k"],packet["k"]) and np.array_equal(old["t"],packet["t"])
            full=np.max(abs(old["values"]),axis=(0,1));err=np.max(abs(old["values"]-packet["values"]),axis=(0,1))
            assert np.array_equal(old["names"],packet["names"])
            new["exact_replay"]=bool(np.array_equal(old["values"],packet["values"]))
            new["worst_channel_replay_pct"]=float(np.max(100*err/np.where(full>0,full,1)))
            ready &= new["worst_channel_replay_pct"]<GATE
        else:
            new["vs_original"]=pct_change(data["original"],packet)
            new["worst_on_original_scale_pct"]=float(np.max(cur["err"]*cur["scale"]/reference["scale"]))
            ready &= new["worst_on_original_scale_pct"]<GATE
            ready &= all(v["launch_pct_change"]<GATE for v in new["vs_original"].values())
        ready &= (new["failed"]==[37] if label=="original" else worst<GATE)
        rows[label]=new
    put("preflight.json",dict(rows=rows,gate_pct=GATE,ready_for_whole_bank=bool(ready)))
    record("preflight-freeze.json",[ROOT/"preflight-forecast.json",ROOT/"preflight.json",ROOT/"score_live.py"])
    print(json.dumps(rows,indent=1),bool(ready),flush=True)


if __name__=="__main__":preflight()
