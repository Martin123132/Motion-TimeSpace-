import hashlib,json,re
from pathlib import Path
root=Path(__file__).resolve().parent
def sha(path):
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
def read(name):return json.loads((root/name).read_bytes())
def verify():
    forecast=read('prediction-freeze.json')
    frozen=sha(root/'prediction-freeze.json')
    assert frozen=='a710751dad61be2fd2dc5e87d00051c513959dabc72be16f4b91e3d120f6605c'
    for name,value in forecast['files'].items():assert sha(root/name)==value
    score=read('scores.json');prepared=read('previous-prepared-readout.json')
    assert score['frozen_prediction_sha256']==prepared['freeze']==frozen
    for source in [forecast['inputs'],score['scoring_inputs'],prepared['sources']]:
        for name,value in source.items():assert sha(root.parent/name)==value
    assert len(score['checks'])==60 and all(row['passes'] for row in score['checks'])
    corrected=[row for row in score['rows'] if row['stress']=='comp']
    assert len(corrected)==len(prepared['rows'])==12 and all(row['launch_pass'] and not row['route_pass'] for row in corrected)
    for row in prepared['rows']:
        assert max(row['comp_density_vs_prepared_pct']+row['comp_momentum_vs_prepared_pct'])<.5
    assert not (root/'__pycache__').exists()
    for target in re.findall(r'\]\(([^)]+)\)',(root/'RESULTS.md').read_text(encoding='utf-8')):assert (root/target).is_file()
    files={p.name:sha(p) for p in sorted(root.iterdir()) if p.is_file() and p.name!='seal.json'}
    if (root/'seal.json').exists():assert files==read('seal.json')['files']
    else:
        with (root/'seal.json').open('x',encoding='utf-8') as stream:json.dump({'files':files,'prediction_freeze':frozen},stream,sort_keys=True,indent=2)
    print(sha(root/'seal.json'),len(files),'files verified')
if __name__=='__main__':verify()
