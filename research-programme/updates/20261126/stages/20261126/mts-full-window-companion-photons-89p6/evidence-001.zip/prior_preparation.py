import csv, sys
from predict import BASE,ROOT,MODES,SETTINGS,cell89,gate,proj,CubicSpline,np,track,used,digest,json,report

def compare():
    anchor=BASE/'mts-switch-kinetic-metric-work-89p6-20261125'
    assert digest(anchor/'seal.json')=='4ef08b61062eb9deeb88ed0c52be6e56ed328080a64596c7cfd25caad3049b49'
    frozen=json.loads((ROOT/'prediction-freeze.json').read_bytes())
    assert all(digest(ROOT/name)==value for name,value in frozen['files'].items())
    files=json.loads((anchor/'seal.json').read_bytes())['files']
    def prior(name):
        path=track(anchor/name);assert digest(path)==files[name];return path
    prior('kinetic_stage.py');prior('launch_size.py');sys.path.insert(0,str(anchor))
    from kinetic_stage import window,pinned
    with prior('launch-sizes.csv').open() as stream:sizes=list(csv.DictReader(stream))
    with prior('photon-score.csv').open() as stream:old_scores=list(csv.DictReader(stream))
    with track(gate.pin(gate.FROZEN,'window-readouts.csv')).open() as stream:
        launch={r['gravity']:float(r['launch_norm']) for r in csv.DictReader(stream) if r['model']=='MTS-minus-baseline' and r['output']=='joint'}
    _,axis,weights,_=proj.old.get_media();measure=gate.previous.make_measure(axis,weights);mag=lambda v:gate.mag(v,measure)
    rows=[]
    for setting in SETTINGS:
        name=f'photons-{setting}.npz'
        with np.load(ROOT/f'prediction-{setting}.npz') as new,np.load(prior(f'route-change-{setting}.npz')) as work,np.load(prior(name)) as inc,np.load(track(pinned(window.ARCHIVE,name))) as ref,np.load(track(window.previous(f'launch-change-{setting}.npz'))) as prep,np.load(track(cell89.pin(f'photon-{setting}.npz'))) as old:
            grid=new['scale'];assert np.array_equal(grid,old['grid']) and all(np.array_equal(grid,pack['scale']) for pack in (work,prep,inc,ref))
            vis=lambda v:CubicSpline(grid,v)(axis)
            for idx,mode in enumerate(MODES):
                original=vis(old['values'][:,old['labels'].tolist().index([mode,'primary']),:3].sum(1))
                small=mag(original)
                for sub,tag,prefix in ((4,'primary',''),(2,'half','half_')):
                    vec=lambda pack:vis(pack['values'][:,pack['labels'].tolist().index([mode,tag])].sum(1))
                    channel=lambda pack,key:vis(pack['values'][:,idx,0,pack['channels'].tolist().index(prefix+key)])
                    momentum=original+vec(prep)+vec(work)
                    gap=channel(inc,'increment')+channel(ref,'full');density=momentum+gap
                    row=next(r for r in sizes if (r['mode'],r['setting'],r['substep'])==(mode,setting,tag))
                    history=next(r for r in old_scores if (r['mode'],r['setting'],int(r['subdivision']))==(mode,setting,sub))
                    archived_gap=100*mag(gap)/small
                    assert max(abs(100*mag(arr)[2]/launch[mode]-float(row[key])) for arr,key in [(momentum,'momentum_pct_launch'),(density,'differentiated_pct_launch')])<1e-10
                    assert np.max(abs(archived_gap-[float(history[f'corrected_{k}_pct']) for k in ('energy','current','joint')]))<1e-8
                    data=dict(grid=mode,sub=sub,setting=setting,prior_route_gap_pct=archived_gap.tolist())
                    for action in ('comp','null'):
                        for route,before in [('momentum',momentum),('density',density)]:
                            label=f'{mode}-{sub}-{action}_{route}';after=vis(new['energy_current'][:,new['labels'].tolist().index(label)])
                            data[action+'_'+route+'_vs_prepared_pct']=(100*mag(after-before)/mag(before)).tolist()
                            data[action+'_'+route+'_difference_pct_original_small']=(100*mag(after-before)/small).tolist()
                    rows.append(data)
    report('previous-prepared-readout.json',dict(freeze=digest(ROOT/'prediction-freeze.json'),note='Post-freeze comparison to the later kinetic/preparation archive. No prediction or scoring gate changed.',rows=rows,sources=used))
    for r in rows:
        if r['setting']=='primary' and r['sub']==4:print(r)
if __name__=='__main__':compare()
