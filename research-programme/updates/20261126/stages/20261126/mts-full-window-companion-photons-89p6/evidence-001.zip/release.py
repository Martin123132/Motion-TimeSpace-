import score as scorer
import numpy as np
from predict import json,record
def write_result(name,data):
    def scalar(value):
        if isinstance(value,np.generic):return value.item()
        raise TypeError(type(value).__name__)
    record(name,(json.dumps(data,indent=2,sort_keys=True,allow_nan=False,default=scalar)+'\n').encode())
if __name__=='__main__':
    scorer.report=write_result
    scorer.score()
