from pathlib import Path
import hashlib, io as streams, json, sys
from datetime import datetime, timezone
import numpy as np
from scipy.interpolate import CubicSpline
from scipy.linalg import solve_banded

ROOT=Path(__file__).resolve().parent
BASE=ROOT.parent
MATCH=BASE/'mts-full-window-companion-joint-89p6-20261126'
WAVE=BASE/'mts-prepared-joint-77-switch-89p6-20261126'
CELL=BASE/'mts-cell-potential-balance-89p6-20261124'
PINS={MATCH:'b97323d32387750279ffca184379a436426ad10bd63407e31fbe4c1f0ca83665',WAVE:'73b24e93fea12844c02baaa76fa61c200b63a90096986c912d5f50bbed338a40',CELL:'a781475df859d3f86c9fba30c2ead37d652a52e1263519a0b55789e7c5c63fdc'}
MODES=('p16','p32')
SETTINGS=('primary','time','angle')
used={}
def digest(path):
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
def track(path):
    used[str(path.relative_to(BASE))]=digest(path)
    return path
def pinned(folder,name):
    assert digest(folder/'seal.json')==PINS[folder]
    path=track(folder/name)
    assert digest(path)==json.loads((folder/'seal.json').read_bytes())['files'][name]
    return path
pinned(CELL,'cell89.py')
sys.path.insert(0,str(CELL))
import cell89
gate=cell89.gate
proj=gate.proj
def record(name,raw):
    with (ROOT/name).open('xb') as stream:stream.write(raw)
def report(name,data):
    record(name,(json.dumps(data,indent=2,sort_keys=True,allow_nan=False)+'\n').encode())
def pack(name,**fields):
    buf=streams.BytesIO();np.savez_compressed(buf,**fields);record(name,buf.getvalue())
def receipt(names):
    return {name:digest(ROOT/name) for name in names}
def source_piece(clock,data,route):
    rate=CubicSpline(clock,data[:,4] if route==0 else data[:,0],extrapolate=False)
    lapse=CubicSpline(clock,data[:,3],extrapolate=False)
    return lambda at:np.stack([rate(at,int(route)),lapse(at)],axis=-1)
def source_bank(at):
    labels=[];pulses=[];kicks=[]
    def add(label,pulse,kick):
        assert pulse.shape==(*at.shape,2) and np.isfinite(pulse).all() and np.isfinite(kick)
        labels.append(label);pulses.append(pulse);kicks.append(kick)
    for mode in MODES:
        with np.load(track(cell89.curve(mode,'base'))) as old:
            time=old['eta']
            for tag,key in [('momentum','delta_pd'),('density','delta_differentiated')]:
                add(mode+'-archive-'+tag,CubicSpline(time,np.column_stack([old[key],old['delta_psi']]),extrapolate=False)(at),old['kick'].item())
        for sub in (2,4):
            suffix=f'{mode}-{sub}.npz'
            with np.load(pinned(MATCH,'full-grid-'+suffix)) as src,np.load(pinned(WAVE,'joint-'+suffix)) as ref:
                times=src['t'];clock=ref['t'];cuts=src['corners'];seams=src['seams'];obs=src['obs'];native=ref['observables']
                assert src['names'].tolist()==ref['names'].tolist() and src['names'][:5].tolist()==['phi','energy_phi','momentum_shadow','psi','momentum_rate']
                assert src['routes'].tolist()==['comp_momentum','comp_density','null_momentum','null_density'] and ref['histories'].tolist()==['momentum','density']
                assert np.array_equal(np.delete(times,np.searchsorted(times,cuts)),clock)
                assert np.array_equal(seams[:,0,:,0],seams[:,1,:,0]) and (clock[[0,-1]]==time[[0,-1]]).all()
                walls=np.r_[0,np.searchsorted(times,cuts),len(times)-1]
                regions=np.searchsorted(cuts,at,side='left')
                for idx,route_name in enumerate(src['routes'].tolist()):
                    route=idx%2
                    control=source_piece(clock,native[:,route],route)(at)
                    raw=np.empty_like(control)
                    for part,(left,right) in enumerate(zip(walls,walls[1:])):
                        segment=obs[left:right+1,idx].copy()
                        if part:segment[0]=seams[part-1,1,idx]
                        if part<len(cuts):segment[-1]=seams[part,0,idx]
                        select=regions==part
                        raw[select]=source_piece(times[left:right+1],segment,route)(at[select])
                    add(f'{mode}-{sub}-{route_name}',raw-control,obs[0,idx,0]-native[0,route,0])
    add('unit-entry',np.zeros((*at.shape,2),complex),1.+0j)
    return labels,np.asarray(kicks),np.stack(pulses,axis=2)
def run():
    if (ROOT/'prediction-freeze.json').exists():raise RuntimeError('Forecast already locked')
    scale,eta,medium,peak,weights=proj.measure('heavy')
    with np.load(track(cell89.io.old.pin('photon-accumulated-heavy.npz'))) as heavy,np.load(track(cell89.io.old.pin('photon-accumulated-cold.npz'))) as cold:
        assert np.array_equal(scale,heavy['scale']) and np.array_equal(scale,cold['scale']) and heavy['k']==cold['k']
        wave=heavy['k'].item()
        base=np.stack([cold['through89p6_'+mode] for mode in MODES],axis=1)
        original=np.stack([heavy['through89p6_'+mode] for mode in MODES],axis=1)
    with np.load(track(cell89.curve('p32','base'))) as clock:high=clock['eta']
    for module in (gate,proj,gate.transfer,proj.transfer,gate.transfer.prior):
        track(Path(module.__file__))
    stats={}
    for setting in SETTINGS:
        order,sub,stride=gate.transfer.prior.SETTINGS[setting]
        axis=np.unique(np.r_[proj.base_axis(scale,eta,sub),high[::stride],high[-1]])
        start,end=np.searchsorted(axis,high[[0,-1]])
        assert axis[start]==cell89.SWITCH and axis[end]==cell89.END
        rates,nodes=proj.coefficients(axis,medium,wave);bands=proj.transfer.stages(order)
        labels,kicks,physical=source_bank(nodes[start:end])
        widths=np.diff(axis)[start:end]
        integrated=widths[:,None,None,None]*np.einsum('st,ntch->nsch',proj.RAD,physical)
        count=bands.shape[-1]//2;cols=len(labels)
        state=np.zeros((count,2*cols));right=np.empty((2*count,2*cols),order='F')
        state[0,::2]=4*kicks.real;state[0,1::2]=4*kicks.imag
        slots=np.full(len(axis),-1);pos=np.searchsorted(axis,eta);assert np.array_equal(axis[pos],eta);slots[pos]=np.arange(len(eta))
        answers=np.zeros((len(scale),cols,2),complex)
        for begin in range(start,len(rates),48):
            if (begin-start)%1536==0:cell89.guard()
            stop=min(begin+48,len(rates))
            matrices=(rates[begin:stop].reshape(-1,8)@bands.reshape(8,-1)).reshape(-1,11,2*count);matrices[:,5]+=1
            for step,mat in enumerate(matrices,begin):
                right[::2]=state;right[1::2]=state
                if step<end:
                    for row,src,factor in ((0,0,4.),(2,1,4*wave/3),(4,1,4*wave/3)):
                        dep=factor*integrated[step-start,:,:,src]
                        right[row:row+2,::2]+=dep.real;right[row:row+2,1::2]+=dep.imag
                state=solve_banded((5,5),mat,right,check_finite=False)[1::2]
                if slots[step+1]>=0:answers[slots[step+1]]=(state[[0,2],::2]+1j*state[[0,2],1::2]).T
        assert np.isfinite(answers).all()
        if setting=='primary':
            active=(axis[:-1]>=axis[start])&(axis[1:]<=axis[end])
            dual,where,kernel=proj.backward(axis,eta,weights,medium,wave,proj.transpose_bands(bands),snapshot=[start],active=active)
            assert np.array_equal(where[active],nodes[start:end])
            peak_ref=4*kicks[:,None]*dual[start][0]+np.einsum('nhtj,ntch->cj',kernel[active],physical)
            predicted=CubicSpline(scale,answers)(peak)
            err=np.abs(predicted-peak_ref)/np.abs(peak_ref);assert np.max(err)<.005
            stats['peak_adjoint_worst_percent']=float(err.max()*100)
        named=[tag for tag in labels if '-comp_' in tag or '-null_' in tag]
        full=np.stack([original[:,MODES.index(tag.split('-')[0])]+answers[:,labels.index(tag)] for tag in named],axis=1)
        pack('prediction-'+setting+'.npz',scale=scale,labels=labels,energy_current=answers,kicks=kicks,full_labels=named,full_heavy=full,cold=base,original_heavy=original,models=MODES)
        print(setting,'complete',flush=True)
    report('prediction-freeze.json',dict(at_utc=datetime.now(timezone.utc).isoformat(),files=receipt(['PROTOCOL.md','predict.py','score.py']+['prediction-'+s+'.npz' for s in SETTINGS]),inputs=used,seals={p.name:h for p,h in PINS.items()},checks=stats))
if __name__=='__main__':run()
