import csv
from datetime import datetime, timezone
from predict import ROOT,BASE,SETTINGS,MODES,cell89,gate,proj,used,np,CubicSpline,track,report,receipt,json,digest

def score():
    freeze=json.loads((ROOT/'prediction-freeze.json').read_bytes())
    assert all(digest(ROOT/name)==value for name,value in freeze['files'].items())
    assert all(digest(BASE/name)==value for name,value in freeze['inputs'].items())
    _,axis,weight,_=proj.old.get_media()
    measure=gate.previous.make_measure(axis,weight)
    mag=lambda val:gate.mag(val,measure)
    with track(gate.pin(gate.FROZEN,'window-readouts.csv')).open() as stream:
        launch={r['gravity']:float(r['launch_norm']) for r in csv.DictReader(stream) if r['model']=='MTS-minus-baseline' and r['output']=='joint'}
    rows=[];checks=[];cache={};splits=[]
    def perc(val,norm):return (100*mag(val)/norm).tolist()
    def check(kind,mode,setting,sub,tag,val,ref):
        diff=perc(val-ref,mag(ref));checks.append(dict(test=kind,grid=mode,setting=setting,sub=sub,route=tag,error_pct=diff,passes=max(diff)<=.5))
        return diff
    for setting in SETTINGS:
        with np.load(ROOT/f'prediction-{setting}.npz') as forecast,np.load(track(cell89.pin(f'photon-{setting}.npz'))) as prior:
            grid=forecast['scale']
            assert np.array_equal(grid,prior['grid']) and forecast['models'].tolist()==list(MODES)
            vis=lambda val:CubicSpline(grid,val)(axis)
            labels=forecast['labels'].tolist()
            bank=forecast['energy_current'];kicks=forecast['kicks']
            lookup=lambda tag:vis(bank[:,labels.index(tag)])
            unit=lookup('unit-entry')
            for gi,mode in enumerate(MODES):
                hist=prior['values'][:,prior['labels'].tolist().index([mode,'primary'])]
                archived={name:vis(hist[:,cols].sum(1)) for name,cols in [('momentum',[0,1,2]),('density',[0,2,3])]}
                small=mag(archived['momentum'])
                for route,ref in archived.items():
                    replay=check('old sources reproduce archived readout',mode,setting,0,route,lookup(mode+'-archive-'+route),ref)
                    assert max(replay)<1e-6,replay
                for sub in (2,4):
                    for action in ('comp','null'):
                        get=lambda route:f'{mode}-{sub}-{action}_{route}'
                        mom=lookup(get('momentum'));den=lookup(get('density'));gap=den-mom
                        entry=(kicks[labels.index(get('density'))]-kicks[labels.index(get('momentum'))])*unit
                        stable=perc(gap,small)
                        row=dict(grid=mode,setting=setting,sub=sub,stress=action,route_gap_pct=stable,route_pass=max(stable)<=.5,
                          own_scale_gap_pct=perc(gap,mag(mom)),old_route_gap_pct=perc(archived['density']-archived['momentum'],small),
                          gap_change_pct=perc(gap-(archived['density']-archived['momentum']),small),entry_gap_pct=perc(entry,small),continuous_gap_pct=perc(gap-entry,small))
                        for route,vector in [('momentum',mom),('density',den)]:
                            tag=get(route);ref=archived[route];key=(mode,sub,setting,action,route)
                            cache[key]=vector
                            diff=perc(vector-ref,mag(ref))
                            row[route+'_vs_archive_pct']=diff;row[route+'_archive_agrees']=max(diff)<=.5
                            row[route+'_pct_launch']=100*mag(vector)[2]/launch[mode]
                            kick=kicks[labels.index(tag)]*unit
                            row[route+'_entry_pct_launch']=100*mag(kick)[2]/launch[mode]
                            row[route+'_continuous_pct_launch']=100*mag(vector-kick)[2]/launch[mode]
                            full=forecast['full_heavy'][:,forecast['full_labels'].tolist().index(tag)]
                            cold=forecast['cold'][:,gi]
                            expected=forecast['original_heavy'][:,gi]+bank[:,labels.index(tag)]
                            assert np.array_equal(full,expected)
                            row[route+'_full_heavy_minus_cold_pct_launch']=100*mag(vis(full-cold))[2]/launch[mode]
                        row['launch_pass']=max(row['momentum_pct_launch'],row['density_pct_launch'])<=.163
                        rows.append(row)
                    for route in ('momentum','density'):
                        on,off=[cache[mode,sub,setting,act,route] for act in ('comp','null')]
                        delta=on-off
                        entry=(kicks[labels.index(f'{mode}-{sub}-comp_{route}')]-kicks[labels.index(f'{mode}-{sub}-null_{route}')])*unit
                        splits.append(dict(grid=mode,setting=setting,sub=sub,route=route,effect_pct_small=perc(delta,small),entry_pct_small=perc(entry,small),smooth_pct_small=perc(delta-entry,small)))
    for mode in MODES:
        for action in ('comp','null'):
            for route in ('momentum','density'):
                for sub in (2,4):
                    key=lambda mode,sub,setting:cache[mode,sub,setting,action,route]
                    ref=key(mode,sub,'primary');tag=action+'_'+route
                    for setting in ('time','angle'):check('photon refinement',mode,setting,sub,tag,key(mode,sub,setting),ref)
                    if sub==4:check('source subdivision',mode,'primary',sub,tag,key(mode,2,'primary'),ref)
                    if mode=='p32':check('gravity refinement',mode,'primary',sub,tag,key('p16',sub,'primary'),ref)
    report('scores.json',dict(as_of_utc=datetime.now(timezone.utc).isoformat(),frozen_prediction_sha256=digest(ROOT/'prediction-freeze.json'),order=['energy','current','joint'],precision_pct=.5,size_pct=.163,launch=launch,rows=rows,checks=checks,stress_change=splits,scoring_inputs=used))
    for row in rows:
        if row['setting']=='primary' and row['sub']==4:
            print(row['grid'],row['stress'],row['route_gap_pct'],row['momentum_pct_launch'],row['density_pct_launch'],row['momentum_vs_archive_pct'],row['density_vs_archive_pct'])
if __name__=='__main__':score()
