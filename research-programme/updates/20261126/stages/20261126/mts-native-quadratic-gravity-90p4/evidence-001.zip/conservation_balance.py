from support import *
from numpy.polynomial.legendre import leggauss
from scipy.interpolate import make_interp_spline


def audit(ar,degree,num):
    k=ar["k"];time=ar["t"];take=time>=89.65;t=time[take]
    assert t[0]==89.65 and t[-1]==90.4
    fields={key:make_interp_spline(time,ar["values"][:,:,i].T,k=degree) for i,key in enumerate(ar["names"])}
    weights,coeff=leggauss(num);width=np.diff(t)
    sample=(t[:-1,None]+width[:,None]*(1+weights)/2).ravel()
    def get(key,der=0):
        return fields[key](sample,der)
    def prim(values):
        local=np.sum(values.reshape(-1,num,len(k))*coeff[None,:,None],axis=1)*width[:,None]/2
        return np.vstack([np.zeros((1,len(k))),np.cumsum(local,axis=0)])
    a,H=get("a"),get("adotoa");E,J=get("dgrho"),get("dgq")
    eta,pi=get("etak"),get("dgpi");R,p=get("grho"),get("gpres")
    alpha=get("sigma")/k;X=(E/2+k*eta)/H
    C=get("dgrho",1)+3*H*get("dgq",1)/k+H*E+k*J+(R+p)*X+6*H**2*J/k+2*H*pi
    common=a**2/(2*H*k**2)
    terms=np.stack((prim(common*C),prim(common*2*k*(get("etak",1)-J/2)),
                    prim(-common*(R+p+2*get("adotoa",1)-2*H**2)*X),prim(2*a**2*(get("a",1)/a-H)*alpha)))
    at=fields["a"](t);actual=fields["sigma"](t)/k
    drive=prim(a**2*(eta/k-pi/k**2))
    residual=(at**2*actual-at[:1]**2*actual[:1])-drive
    native=fields["sigmadot"](t)/k;alternative=fields["etak"](t)/k-2*fields["adotoa"](t)*actual-fields["dgpi"](t)/k**2
    normalization=np.max(abs(actual-actual[:1]),axis=0)
    convert=lambda term:100*term/(at**2*normalization)
    rate_pct=100*np.max(abs(native-alternative),axis=0)/np.max(abs(native),axis=0)
    return convert(terms),convert(residual),rate_pct


if __name__=="__main__":
    check("conservation-freeze.json")
    data=read(ROOT/"conservation-320-6.npz");earlier=read(ROOT/"direct-320-6.npz")
    for key in earlier["names"]:
        assert np.array_equal(data["values"][:,:,data["names"].tolist().index(key)],earlier["values"][:,:,earlier["names"].tolist().index(key)]),key
    terms,direct,rate=audit(data,5,6)
    other,independent,_=audit(data,3,4)
    i=np.flatnonzero(data["indices"]==37).item()
    num=terms.sum(0)-direct
    mags=np.max(abs(terms[:,:,i]),axis=1)
    signed=(terms[:,:,i]@direct[:,i])/(direct[:,i]@direct[:,i])
    row=dict(terms=["pressure-free total conservation","spatial curvature rate vs J/2","background acceleration constraint","expansion clock"],indices=data["indices"].tolist(),
             pointwise_slip_identity_pct=rate.tolist(),integration_error_pct=np.max(abs(num),axis=0).tolist(),
             direct_residual_pct=np.max(abs(direct),axis=0).tolist(),k37=dict(terms_pct=mags.tolist(),signed_shares=signed.tolist(),
                 residual_pct=float(np.max(abs(direct[:,i]))),accounting_error_pct=float(np.max(abs(num[:,i]))),
                 interpolation_spread_pct=np.max(abs(terms-other)[:,:,i],axis=1).tolist()))
    assert rate.max()<1e-8 and np.max(abs(num))<.005
    put("conservation.json",row)
    packet("conservation-series.npz",t=data["t"][data["t"]>=89.65],indices=data["indices"],terms=terms,independent_residual=direct)
    print(row["k37"],flush=True)
