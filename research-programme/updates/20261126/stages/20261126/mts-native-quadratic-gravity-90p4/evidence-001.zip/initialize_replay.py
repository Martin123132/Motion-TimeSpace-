import ast
from support import *


def replay_method(script, name, ctx):
    path=ROOT/script
    module=ast.parse(path.read_text())
    calls=[node for node in ast.walk(module) if isinstance(node,ast.Call) and isinstance(node.func,ast.Name)
           and node.func.id=="freeze" and isinstance(node.args[0],ast.Constant) and node.args[0].value==name]
    assert len(calls)==1
    eval(compile(ast.Expression(calls[0]),script,"eval"),ctx)
    check(name)


if __name__=="__main__":
    guard()
    if sys.argv[1:]==["microscopic"]:
        import native_predict as stage
        check("input-freeze.json")
        replay_method("native_predict.py","prediction-method.json",stage.__dict__)
    elif sys.argv[1:]==["response"]:
        import propagate_native as stage
        check("native-freeze.json")
        assert json.loads((ROOT/"native-control.json").read_bytes())["passes"]
        replay_method("propagate_native.py","response-method.json",stage.__dict__)
    else:
        raise SystemExit("Use microscopic or response")
