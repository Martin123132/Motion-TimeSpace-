from score_native import *
from scipy.integrate import cumulative_simpson
import inspect


def report(grid,res,host):
    ref=read(pinned(SCALAR,f"driven-{grid}-{res}.npz"));angles=read(pinned(PRE,f"angles-{res}.npz"))
    packet0=read(ROOT/f"native-{res}.npz");own=read(ROOT/f"real-{res}.npz")
    modeled=read(ROOT/f"joined-{grid}-{res}-0.npz");original=read(pinned(PRE,f"combined-{grid}-{res}.npz"))
    tm=ref["t"];ph=ref["phase"];ct=angles["centers"];ix=np.searchsorted(tm,ct);idx=np.searchsorted(modeled["t"],ct)
    assert np.array_equal(own["t"],tm)
    obs=split.native_pieces(grid)(tm);H=obs[:,0,9].real;kk=modeled["k"]**2;D=original["obs"][0,0,0,8]
    historical=read(pinned(SCALAR,f"memory-{grid}.npz"));hj=np.searchsorted(historical["t"],tm)
    outside=historical["qe_qj"][hj];source=outside.copy()
    from shared_trace import Shared
    early=tm<=89.6;bridge=(tm>89.6)&(tm<=89.65)
    source[early]=Shared().overlay(host.external,[2,3])(np.log(tm[early]))[:,2:4]
    source[bridge]=host.external(np.log(tm[bridge]))[:,2:4]
    bank,_=canonical(tm,5);finer,_=canonical(tm,7)
    scale=aperture(ph,obs[:,:,1:2].transpose(2,0,1),ph[ix])[:,0]*2*D
    def temporal(arr):
        pairs=np.stack((arr[:,0],3*H*arr[:,1]/kk))
        return aperture(ph,pairs[:,:,None],ph[ix])
    def angular(arr):
        pairs=np.stack((arr[idx,:,0],3*H[ix,None]*arr[idx,:,1]/kk))
        return fourier(pairs[:,:,:,None],16)
    real=temporal(own["values"]);independent=temporal(bank);target=temporal(source)
    native=angular(packet0["values"]);projected=angular(read(pinned(PRE,f"micro-4-{res}.npz"))["quadr"][:,:,[2,4]])
    pieces=[native-real,real-independent,independent-target]
    total=native-target
    np.testing.assert_allclose(sum(pieces),total,atol=5e-28,rtol=2e-8)
    def numbers(arr):
        each=rate(arr,scale[:,None]);combined=arr.sum(1)
        return dict(level=each[1:,:,-1].tolist(),change=rate(drift(arr),scale[:,None])[1:,:,-1].tolist(),
            net_level=rate(combined,scale)[1:,-1].tolist(),net_change=rate(drift(combined),scale)[1:,-1].tolist())
    def median_relative(arr,ref):
        return (100*np.median(abs(arr),axis=0)/np.max(abs(ref),axis=0)).tolist()
    raw_comb=fourier(modeled["explicit_q"][None,idx],16)[:,0];prev_comb=fourier(original["explicit_q"][None,idx],16)[:,0]
    difference=(raw_comb-prev_comb)-(native-projected).sum(1)
    assert rate(difference,scale)[1:].max()<0.02,rate(difference,scale)
    raw_score=100*np.max(abs(own["values"]-bank),axis=0)/np.max(abs(bank),axis=0)
    denom=(bank-bank[:1])
    raw_change=100*np.max(abs(drift((own["values"]-bank).T[:,:,None])[:,:,0]),axis=-1)/np.max(abs(denom),axis=0)
    return dict(grid=grid,res=res,ordering=["temporal vs angular within native forward model","native real forward vs actual canonical bank","actual canonical bank vs historical in-domain assembly"],
                components=[numbers(piece) for piece in pieces],total=numbers(total),old=numbers(projected-target),
                physical_full_window_pct=raw_score.tolist(),physical_full_window_change_pct=raw_change.tolist(),
                wrongly_extrapolated_past_harmonics=numbers(temporal(outside)-target),
                solver_injection_replay_pct=rate(difference,scale)[1:,-1].tolist(),
                memory_launch=dict(time=float(tm[0]),first_allowed=89.55,late_table_extrapolated=[[float(x.real),float(x.imag)] for x in outside[0]],
                    actual_piecewise=[[float(x.real),float(x.imag)] for x in source[0]],
                    difference_pct_of_real= (100*abs(outside[0]-source[0])/abs(source[0])).tolist()))


def old_memory_impact(grid,res):
    import memory_load as historical
    host=split.historic.pre.import_at(split.historic.pre.OLD,"partial").Host(grid,4)
    earlier=read(pinned(SCALAR,f"memory-{grid}.npz"))
    from shared_trace import Shared
    repaired=dict(earlier);repaired["qe_qj"]=earlier["qe_qj"].copy()
    mask=earlier["t"]<=89.6;bridge=(earlier["t"]>89.6)&(earlier["t"]<=89.65)
    repaired["qe_qj"][mask]=Shared().overlay(host.external,[2,3])(np.log(earlier["t"][mask]))[:,2:4]
    repaired["qe_qj"][bridge]=host.external(np.log(earlier["t"][bridge]))[:,2:4]
    manifest=json.loads(pinned(SCALAR,"memory-scores.json").read_bytes())
    baseline=next(row for row in manifest["rows"] if (row["grid"],row["res"])==(grid,res))
    src=inspect.getsource(historical.run)
    key="    print(grid,res,"
    src=src[:src.index(key)]+src[src.index("    return dict(grid=grid,res="):]
    text="original_input,native_rho,c0,rho,eco,y,energy,physical_load"
    ctx=dict(historical.__dict__)
    exec(compile(src,"historical read-only score","exec"),ctx)
    with patch.dict(ctx,read=lambda path: repaired if path==SCALAR/f"memory-{grid}.npz" else read(path)):
        result=ctx["run"](grid,res)
    src2=src[:src.index("    return dict(grid=grid,res=")]+"    return "+text+"\n"
    exec(compile(src2,"inspect signed normalization","exec"),ctx)
    oldvalues=ctx["run"](grid,res)
    with patch.dict(ctx,read=lambda path: repaired if path==SCALAR/f"memory-{grid}.npz" else read(path)):
        newvalues=ctx["run"](grid,res)
    dE=newvalues[0]-oldvalues[0];rho=newvalues[3]
    assert np.allclose(newvalues[4]-oldvalues[4],dE/rho[0],rtol=1e-10,atol=1e-25)
    y_change=newvalues[5]-oldvalues[5];e_change=newvalues[6]-oldvalues[6]
    assert np.max(abs(y_change-dE[None]/rho[0]))<1e-9*np.max(abs(y_change))
    assert np.max(abs(e_change-dE[None]/rho[0]))<1e-9*np.max(abs(e_change))
    net=newvalues[7];prior=oldvalues[7];offset=100*abs(newvalues[0]-oldvalues[0])/abs(oldvalues[0])
    shift=100*np.max(abs(net-prior),axis=0)/np.max(abs(net),axis=0)
    return dict(grid=grid,res=res,correction_pct_of_old_bare_energy=offset.tolist(),total_load_level_change_pct_of_corrected=shift.tolist(),
                prior=baseline,corrected=result,affected="Constant integration offset in normalized energy; physical energy redshifts with rho. Archived routes, comparator pressures and direct Y drift untouched.")


if __name__=="__main__":
    check("real-freeze.json");check("joined-freeze.json")
    part=nio.historic.pre.import_at(nio.historic.pre.OLD,"partial")
    rows=[report(grid,res,part.Host(grid,4)) for grid in ("p16","p32") for res in (640,1280)]
    put("harmonics.json",dict(rows=rows,units="Percent of the small energy-constraint potential harmonic, not of cosmological energy. Component peak magnitudes need not add.",source=digest(ROOT/"harmonic_audit.py")))
    rows=[old_memory_impact(grid,res) for grid in ("p16","p32") for res in (640,1280)]
    put("memory-erratum.json",dict(rows=rows,source=digest(ROOT/"harmonic_audit.py")))
