from score_native import *


def run(grid,res):
    packet=read(ROOT/f"channels-{res}.npz");ref=read(pinned(SCALAR,f"driven-{grid}-{res}.npz"))
    angles=read(pinned(PRE,f"angles-{res}.npz"));ct=angles["centers"];tm=ref["t"];ix=np.searchsorted(tm,ct);theta=ref["phase"]
    obs=split.native_pieces(grid)(tm);H=obs[:,0,9].real;kk=angles["kk"]
    model=read(pinned(PRE,f"combined-{grid}-{res}.npz"))
    scale=aperture(theta,obs[:,:,1:2].transpose(2,0,1),theta[ix])[:,0]*2*model["obs"][0,0,0,8]
    def project(terms,order):
        pair=make_interp_spline(packet["t"],terms.transpose(1,0,2),k=order)(tm)
        total=pair[:,:,0]+3*H[:,None]*pair[:,:,1]/kk
        return aperture(theta,total.T[:,:,None],theta[ix])
    parts=project(packet["terms"],5)
    levels=rate(parts,scale[:,None])
    changes=rate(drift(parts),scale[:,None])
    total=parts.sum(1)
    cross=np.real(np.sum(np.conj(total[:,None])*parts,axis=2)/np.sum(abs(total[:,None])**2,axis=2))
    assert np.allclose(cross.sum(1),1,atol=2e-12)
    spread=rate(project(packet["terms"],7)-parts,scale[:,None])
    full=read(ROOT/f"real-{res}.npz")["values"];bank,_=canonical(tm,5)
    dense=(full[:,0]-bank[:,0])+3*H*(full[:,1]-bank[:,1])/kk
    truth=aperture(theta,dense[None,:,None],theta[ix])[:,0]
    dense_err=rate(total-truth,scale)
    before=aperture(theta,(dense*(tm<89.65))[None,:,None],theta[ix])[:,0];after=truth-before
    ratio=100*np.real(np.sum(np.conj(truth)*after,axis=1)/np.sum(abs(truth)**2,axis=1))
    print(grid,res,"sector levels",np.round(levels[1:,:,-1],2).tolist(),"signed fractions",np.round(100*cross[1:,:,-1],1).tolist(),"post share",np.round(ratio[1:,-1],1),flush=True)
    return dict(grid=grid,res=res,sector_level_pct=levels[1:,:,-1].tolist(),sector_change_pct=changes[1:,:,-1].tolist(),
                signed_fraction_of_total=cross[1:,:,-1].tolist(),interpolation_order_spread_pct=spread[1:,:,-1].tolist(),
                independent_dense_sampling_discrepancy_pct=dense_err[1:,-1].tolist(),signed_post_launch_fraction_pct=ratio[1:,-1].tolist())


if __name__=="__main__":
    check("channels-freeze.json")
    rows=[run(grid,res) for grid in ("p16","p32") for res in (640,1280)]
    put("channel-scores.json",dict(rows=rows,groups=["synchronous field and velocity","homogeneous b,v","a,H","shear slicing alpha","spatial curvature etak/k"],scope="Bilinear difference around the midpoint of prediction and reference; attribution, not held-out improvement."))
