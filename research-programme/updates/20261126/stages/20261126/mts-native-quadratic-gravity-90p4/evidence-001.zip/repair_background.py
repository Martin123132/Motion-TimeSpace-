from support import *
from scipy.interpolate import CubicSpline,make_interp_spline
from scipy.integrate import solve_ivp
import native_io as nio


def solve(model,res):
    ar=read(ROOT/f"sectors-{model}.npz");k=ar["k"];count=len(k);tm=ar["t"];sel=tm>=89.65;t=tm[sel]
    f={str(key):ar["values"][:,:,i].T for i,key in enumerate(ar["names"])}
    raw_a=f["a"];raw_H=f["adotoa"];fullA=f["grho"]+3*f["gpres"]
    if model=="heavy":
        bank=read(pinned(nio.historic.io.oldio.PAD,"canonical-input.npz"))
        mass=float(bank["heavy_mass_mpc"]);bv=CubicSpline(bank["heavy_efold"],bank["phi_h"])(np.log(raw_a))
        vv=CubicSpline(bank["heavy_efold"],bank["phidot_h"])(np.log(raw_a))
        ff=f["mts_dphi_h"];ww=f["mts_dphidot_h"];hE=f["mts_drho_h"];hJ=f["mts_q_h"]
    else:
        mass=0.;bv=vv=ff=ww=hE=hJ=np.zeros_like(raw_a)
    rest=np.stack((fullA-(2*vv**2-(raw_a*mass*bv)**2),f["dgrho"]-hE,f["dgq"]-hJ,f["dgpi"]),axis=1)
    forcing=make_interp_spline(tm,rest,k=5)
    ix=int(np.flatnonzero(sel)[0]);alpha_arch=f["sigma"][sel]/k
    seed=np.stack((raw_a[ix],raw_H[ix],bv[ix],vv[ix],ff[ix],ww[ix],f["etak"][ix],alpha_arch[0]))
    seed=np.stack((seed,seed))
    system=lambda x:x.reshape(2,8,count).transpose(1,0,2)
    def rhs(at,state):
        a,H,b,v,field,w,etak,alpha=system(state)
        ac,re,rj,anis=forcing(at);mu=(mass*a)**2
        E=re+v*w+mu*b*field;J=rj+k*v*field
        xH=(E/2+k*etak)/H;xS=k**2*alpha-1.5*J/k;X=np.stack((xH[0],xS[1]))
        dot=np.stack((a*H,-(ac+2*v**2-mu*b**2)/6,v,-2*H*v-mu*b,w,-2*H*w-(k**2+mu)*field-v*X,
                       J/2,etak/k-2*H*alpha-anis/k**2),axis=1)
        return dot.ravel()
    eps=np.maximum(np.abs(seed)*1e-15,1e-26)
    result=solve_ivp(rhs,(t[0],t[-1]),seed.ravel(),t_eval=t,max_step=1/res,method="DOP853",rtol=3e-13,atol=eps.ravel())
    assert result.success
    state=result.y.T.reshape(len(t),2,8,count);a,H,b,v,field,w,etak,al=np.moveaxis(state,2,0)
    ac,re,rj,anis=forcing(t).transpose(1,0,2)[:, :,None,:];mu=(a*mass)**2
    E=re+v*w+mu*b*field;J=rj+k*v*field
    alg=((E/2+k*etak)/H+1.5*J/k)/k**2
    scale=np.max(abs(alpha_arch-alpha_arch[:1]),axis=0)
    native_delta=(alpha_arch-alpha_arch[:1])[:,None,:];shadow=alg-al
    er=100*np.max(abs(shadow-shadow[:1]),axis=0)/scale
    to_archive=100*np.max(abs((alg-alg[:1])-native_delta),axis=0)/scale
    step0=100*abs(shadow[0])/scale
    packet(f"background-{model}-{res}.npz",t=t,k=k,indices=ar["indices"],state=state,alpha_H=alg,alpha_integrated=al,alpha_archive=alpha_arch,
        native_change_scale=scale,closure_pct=er,launch_constraint_pct=step0,algebraic_vs_archived_change_pct=to_archive)
    return dict(model=model,res=res,k37_closure_pct=er[:,np.flatnonzero(ar["indices"]==37).item()].tolist(),
                max_closure_pct=er.max(1).tolist(),max_launch_err_pct=step0.max(1).tolist(),
                failed_indices=[ar["indices"][x>=.5].tolist() for x in er],vs_archive_k37=to_archive[:,np.flatnonzero(ar["indices"]==37).item()].tolist())


if __name__=="__main__":
    check("sector-freeze.json")
    freeze("repair-method.json",[ROOT/"SECTORS.md",ROOT/"sector-scores.json",ROOT/"sector-freeze.json",ROOT/"repair_background.py"])
    rows=[]
    for model in ("heavy","cold"):
        for res in (640,1280):
            row=solve(model,res);rows.append(row);print(row,flush=True)
    freeze("repair-freeze.json",[ROOT/"repair-method.json",*sorted(ROOT.glob("background-*.npz"))])
    put("repair-scores.json",dict(rows=rows,criterion_pct=.5,sequence=["energy-constraint forcing","propagated shear forcing"],
        scope="Conditional 24-mode background repair on measured surrounding sources, not a replacement of the 782-leg forecast or photon prediction."))
