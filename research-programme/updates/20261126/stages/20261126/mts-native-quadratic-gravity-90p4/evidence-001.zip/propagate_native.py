from support import *
from scipy.interpolate import make_interp_spline, CubicSpline
import inspect
import combined_load as original
import native_io

ANCHOR=89.65


def prepare(grid,res,earlier,host):
    inputs,initial=original.overlay_inputs(grid,res,earlier)
    nat=read(ROOT/f"native-{res}.npz")
    oldpast=read(pinned(PRE,f"past-legs-4-{res}.npz"))
    packet_past=read(pinned(PRE,f"micro-past-{grid}-{res}.npz"))
    tr=nat["past"]
    assert np.array_equal(tr,oldpast["t"]) and np.array_equal(nat["t"],inputs["t"])
    mod=lambda value:value-value[:,:1]
    correction=mod(nat["prior"])-mod(oldpast["q"][:,:,[2,4]])
    forward=mod(nat["values"])-mod(inputs["quadr"][:,:,[2,4]])
    assert np.allclose(correction[-1],forward[0],rtol=4e-9,atol=1e-30)
    ct=packet_past["prior_t"];ends=inputs[grid+"_lag_phase"]
    phase=np.linspace(ends[-1]-3*np.pi,ends[-1],577)
    history=read(pinned(SCALAR,f"history-{grid}.npz"));mass=history["m"].item();kk=host.kk
    early=tr<=89.6
    hub=np.empty(len(tr));aa=hub.copy()
    hub[early],mu,_,_=host.osc(tr[early]);aa[early]=np.sqrt(mu)/mass
    bg=host.flow.bg(np.log(tr[~early]));hub[~early]=bg[:,host.flow.bgkeys.index("h")];aa[~early]=bg[:,host.flow.bgkeys.index("a")]
    clock=make_interp_spline(tr,np.column_stack((aa,hub)),k=5)
    a,H=clock(ct).T;hp=clock(ct,1)[:,1];rho=history["rho0"].item()/a
    energy,current=(make_interp_spline(tr,correction,k=5)(ct)/rho[:,None,None]).transpose(2,0,1)
    current_spline=CubicSpline(phase,current)
    intj=current_spline.antiderivative()
    rolling=(intj(phase[192:])-intj(np.maximum(phase[0],phase[192:]-np.pi)))/np.pi
    factor=-1+3*(hp-H**2)/kk
    integrand=factor[192:,None]*(rolling-current[192:])
    delta_Y=CubicSpline(ct[192:],integrand).antiderivative()
    first=(192,384)[earlier]
    shift=-(energy[first]+3*H[first]*current[first]/kk)+delta_Y(ct[-1])-delta_Y(ct[first])
    assert np.count_nonzero(shift[0])==0
    inputs[grid+"_mean"]+=rolling[-1,:,None]
    inputs[grid+"_lag_current"]+=current_spline(np.clip(ends,phase[0],phase[-1]))[:,:,None]
    y=initial+np.repeat(shift,2)
    clocks=np.linspace(nat["t"][0],nat["t"][-1],2*len(nat["t"])-1)
    change=make_interp_spline(nat["t"],forward,k=5)(clocks)
    return inputs,y,change,shift


def compute(grid,res,earlier,host):
    name=f"response-{grid}-{res}-{earlier}.npz"
    if (ROOT/(name+".receipt")).exists():
        check(name+".receipt");return
    inputs,y,change,boundary=prepare(grid,res,earlier,host)
    template=inspect.getsource(original.generate)
    begin=template.index('    code=(ROOT/')
    end=template.index('    receipt(done,')
    body=template[begin:end]
    preamble="""def run():
"""
    marker="    ns=dict(engine.__dict__,__name__='Z_transport',incoming_y=y)"
    assert body.count(marker)==1
    body=body.replace(marker,"""    replace('ds=qa[:,5]-qreal[5]', 'ds=qa[:,5]-qreal[5];de+=np.repeat(native_change[n,:,0],routes);dj+=np.repeat(native_change[n,:,1],routes)')
    ns=dict(engine.__dict__,__name__='native_energy_current',incoming_y=y,native_change=change)""")
    body=body.replace('pack(name,**result,','save_response(name,delta_Y=boundary,**result,')
    space=dict(original.__dict__,grid=grid,res=res,name=name,inp=inputs,y=y,change=change,boundary=boundary,save_response=packet)
    exec(compile(preamble+body,"sealed Z evolution with native angular load","exec"),space)
    space["run"]()
    freeze(name+".receipt",[ROOT/name,ROOT/"response-method.json"])
    print("frozen",grid,res,earlier,flush=True)


if __name__=="__main__":
    guard();check("native-freeze.json")
    assert json.loads((ROOT/"native-control.json").read_bytes())["passes"]
    freeze("response-method.json",[ROOT/"native-freeze.json",ROOT/"native-control.json",ROOT/"propagate_native.py",
                                   pinned(PRE,"combined_load.py"),pinned(PRE,"gravity_phase.py"),pinned(PRE,"micro-past-freeze.json")])
    part=native_io.historic.pre.import_at(native_io.historic.pre.OLD,"partial")
    for grid in ("p16","p32"):
        host=part.Host(grid,4)
        for res in (640,1280):
            for earlier in (0,1):compute(grid,res,earlier,host)
    freeze("response-freeze.json",[ROOT/"response-method.json",*sorted(ROOT.glob("response-*.npz.receipt"))])
