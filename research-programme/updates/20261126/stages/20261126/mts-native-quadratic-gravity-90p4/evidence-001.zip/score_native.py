from support import *
from score_gravity import fourier, aperture, drift, rate
import split_sources as split
import native_io as nio
import moment_readout as reduced
from scipy.interpolate import make_interp_spline
from unittest.mock import patch


def canonical(reference_time,order):
    banks=[]
    for folder in (nio.old.BANK,nio.historic.io.oldio.PAD):
        with np.load(pinned(folder,"material-halfstep/forcing-heavy.npz")) as archive:
            idx=[archive["keys"].tolist().index(s) for s in ("henergy","hJ")]
            banks.append((archive["eta"],archive["values"][idx,:,0].T))
    left,one=banks[0];right,two=banks[1]
    lo=left>=89.55;overlap=right<=89.65
    assert np.array_equal(left[lo],right[overlap])
    overlap_error=100*np.max(abs(one[lo]-two[overlap]),axis=0)/np.max(abs(one[lo]),axis=0)
    t=np.r_[left,right[~overlap]];src=np.concatenate((one,two[~overlap]))
    return make_interp_spline(t,src,k=order)(reference_time),overlap_error


def score(grid,res,part):
    ref=read(pinned(SCALAR,f"driven-{grid}-{res}.npz"));tm=ref["t"];theta=ref["phase"]
    prev=read(pinned(PRE,f"combined-{grid}-{res}.npz"))
    ang=read(pinned(PRE,f"angles-{res}.npz"));ct=ang["centers"];ticks=prev["t"]
    mark=np.searchsorted(ticks,ct);which=np.searchsorted(tm,ct);phase=theta[which]
    mem=read(pinned(SCALAR,f"memory-{grid}.npz"))
    ix=np.searchsorted(mem["t"],tm);assert np.array_equal(mem["t"][ix],tm)
    hist,obs,replay=split.actual_split(grid,res,tm,part)
    hub=obs[:,:,9].real;kk=prev["k"]**2;D=prev["obs"][0,0,0,8]
    explicit=mem["qe_qj"][ix].copy()
    host=part.Host(grid,4)
    from shared_trace import Shared
    early=tm<=89.6;bridge=(tm>89.6)&(tm<=89.65)
    explicit[early]=Shared().overlay(host.external,[2,3])(np.log(tm[early]))[:,2:4]
    explicit[bridge]=host.external(np.log(tm[bridge]))[:,2:4]
    ex=explicit[:,:1]+3*hub*explicit[:,1:]/kk
    heavy=hist[:,:,2]+hist[:,:,3]+3*hub*(hist[:,:,6]+hist[:,:,7])/kk
    target=aperture(theta,np.stack((heavy-ex,ex,heavy)),phase)
    scale=aperture(theta,obs[:,:,1:2].transpose(2,0,1),phase)[:,0]*2*D
    pmean=aperture(theta,ref["values"][0,1:2],phase)[0,0]
    def score_one(snap):
        readout=fourier(np.stack([snap["Z"],snap["explicit_q"],snap["Z"]+snap["explicit_q"]])[:,mark],16)
        error=readout-target
        pressure=snap["stress"][mark,:,:,1].mean(axis=1)
        return dict(pressure_pct=rate(drift(pressure-pmean),drift(pmean)).tolist(),
                    load_level_pct=rate(error,scale[:,None]).tolist(),load_change_pct=rate(drift(error),scale[:,None]).tolist(),
                    first_center_pct=rate(error[:,:,:1],scale[:,None]).tolist())
    original=score_one(prev)
    sealed_row=next(row for row in json.loads(pinned(PRE,"Z-scores.json").read_bytes())["rows"] if (row["grid"],row["res"])==(grid,res))
    np.testing.assert_allclose(original["load_level_pct"],sealed_row["heavy_component_pct_of_Hamiltonian_harmonic"],atol=4e-5,rtol=2e-6)
    variants={}
    for early in (0,1):
        snap=read(ROOT/f"joined-{grid}-{res}-{early}.npz")
        assert np.array_equal(snap["t"],ticks)
        relative=100*np.max(abs(snap["obs"][:,0]-prev["obs"][:,0]),axis=0)/np.max(abs(prev["obs"][:,0]),axis=0)
        assert np.max(relative)<1e-7
        row=score_one(snap);row["physical_orientation_same_pct"]=float(np.max(relative))
        diffs=rate(drift((snap["stress"][mark,:,:,1]-prev["stress"][mark,:,:,1]).mean(1)),drift(pmean))
        row["increment_on_pressure_drift_pct"]=diffs.tolist()
        if early==0:
            inputs,_=split.overlay_inputs(grid,res,0)
            def route(path):
                if path.name==f"angles-{res}.npz":return inputs
                if path.name.startswith("solved-nativeQ-"):return snap
                return nio.read(path)
            def accept(name):
                assert name==f"solved-nativeQ-{grid}-{res}.npz.receipt"
                check(f"joined-{grid}-{res}-0.npz.receipt")
            with patch.object(reduced,"read",route),patch.object(reduced,"check",accept),patch.object(reduced,"pack",lambda name,**data:packet(f"reduced-{grid}-{res}.npz",**data)):
                rr=reduced.solve("nativeQ",grid,res)
            row["reduced_pressure_pct"]=rr["temporal_drift_error_pct"][1]
        variants[str(early)]=row
    native,overlap=canonical(tm,5);fine,_=canonical(tm,7)
    direct=native[:,:1]+3*hub*native[:,1:]/kk
    interp=fine[:,:1]+3*hub*fine[:,1:]/kk
    raw_vs_effective=aperture(theta,(ex-direct)[None],phase)[:,0]
    resolution=aperture(theta,(interp-direct)[None],phase)[:,0]
    result=dict(grid=grid,res=res,original=original,variants=variants,
                canonical_overlap_pct=overlap.tolist(),reference_seam_level_pct=rate(raw_vs_effective,scale).tolist(),
                reference_seam_change_pct=rate(drift(raw_vs_effective),scale).tolist(),
                interpolator_spread_pct=rate(resolution,scale).tolist())
    print(grid,res,"P old/new",original["pressure_pct"],variants["0"]["pressure_pct"],"explicit/net H cosine sine errors",np.round(np.array(variants["0"]["load_level_pct"])[1:,1:,1],2).tolist(),flush=True)
    return result


if __name__=="__main__":
    check("joined-freeze.json")
    part=nio.historic.pre.import_at(nio.historic.pre.OLD,"partial")
    rows=[score(grid,res,part) for grid in ("p16","p32") for res in (640,1280)]
    put("scores.json",dict(rows=rows,gate_pct=0.5,components=["Z","explicit Qe+3H Qj/K","sum"],
             angles=["mean","cosine 2","sine 2"],forecast=digest(ROOT/"joined-freeze.json"),
             scorer=digest(ROOT/"score_native.py")))
