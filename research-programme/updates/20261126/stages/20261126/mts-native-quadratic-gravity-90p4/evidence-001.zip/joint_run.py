import inspect
import propagate_native as solver
from support import *


def bind(func, changes, env):
    source=inspect.getsource(func)
    for before,after in changes:
        assert source.count(before)==1
        source=source.replace(before,after)
    ctx=dict(func.__globals__,**env)
    exec(compile(source,func.__name__+" with shared Cauchy sample","exec"),ctx)
    return ctx[func.__name__]


def common(surface,launch):
    diff=abs(surface-launch).max(axis=0)
    scale=np.maximum(abs(surface),abs(launch)).max(axis=0)
    assert np.all(diff<=16*np.finfo(float).eps*scale)
    return launch.copy()


if __name__=="__main__":
    guard();check("response-method.json")
    freeze("join-method.json",[ROOT/"response-method.json",ROOT/"joint_run.py"])
    marker='    correction=mod(nat["prior"])-mod(oldpast["q"][:,:,[2,4]])'
    prepare=bind(solver.prepare,[(marker,'    incoming=oldpast["q"][:,:,[2,4]].copy()\n    incoming[-1]=common(incoming[-1],inputs["quadr"][0][:,[2,4]])\n    correction=mod(nat["prior"])-mod(incoming)'),('assert np.allclose(correction[-1],forward[0],rtol=4e-9,atol=1e-30)','assert np.array_equal(correction[-1],forward[0])')],dict(common=common))
    compute=bind(solver.compute,[('name=f"response-', 'name=f"joined-'),('ROOT/"response-method.json"','ROOT/"join-method.json"')],dict(prepare=prepare))
    part=solver.native_io.historic.pre.import_at(solver.native_io.historic.pre.OLD,"partial")
    for grid in ("p16","p32"):
        host=part.Host(grid,4)
        for res in (640,1280):
            for earlier in (0,1):compute(grid,res,earlier,host)
    freeze("joined-freeze.json",[ROOT/"join-method.json",*sorted(ROOT.glob("joined-*.npz.receipt"))])
