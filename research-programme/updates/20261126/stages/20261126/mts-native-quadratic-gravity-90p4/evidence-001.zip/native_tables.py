from functools import lru_cache
import native_predict as driver
from source_bank import *


@lru_cache()
def continuation(res):
    snap=read(orbit.signed(f"coupled-matched-{res}.npz"))
    cols={key:snap["values"][:,idx] for idx,key in enumerate(snap["keys"].tolist())}
    grid=snap["k"];tm=snap["t"];par=orbit.kin.initial("matched")
    assert np.array_equal(grid,par.k)
    delta=(tm-orbit.CUT)[:,None]
    acc=par.h0**2-par.pressure
    fac=1+par.h0*delta+acc*delta**2/4
    hub=(par.h0+acc*delta/2)/fac;rho=par.rho/(par.a0*fac)
    eta=make_interp_spline(tm,(cols["k_sigma"]-cols["X"])/3,k=5).antiderivative()(tm)
    energy=2*(hub*cols["X"]-grid**2*eta)-rho*cols["e"]
    current=2*grid*(cols["k_sigma"]-cols["X"])/3-rho*cols["j"]
    accel=-6*(acc/(2*fac)-hub**2)-rho
    return make_interp_spline(tm,np.column_stack((accel[:,0],energy,current)),k=5)


def source_tables(raw,res,times):
    past=times<=ANCHOR
    values=np.empty((len(times),raw["rest"].shape[1]))
    values[past]=make_interp_spline(raw["time"],raw["rest"],k=5)(times[past])
    if not past.all():
        spline=continuation(res)
        values[~past]=raw["rest"][-1]+(spline(times[~past])-spline(ANCHOR))
    return values


if __name__=="__main__":
    check("prediction-method.json")
    freeze("numeric-method.json",[ROOT/"prediction-method.json",ROOT/"native_tables.py"])
    driver.source_tables=source_tables
    for res in (640,1280):driver.generate(res)
    freeze("native-freeze.json",[ROOT/"numeric-method.json",ROOT/"native-640.npz",ROOT/"native-1280.npz"])
