from support import *
from conservation_balance import audit, leggauss, make_interp_spline
from scipy.interpolate import CubicSpline
import native_io as nio

GROUPS=["baryons plus photons","massless radiation","cold matter","massive radiation with inferred momentum","native dark-sector aggregate","additive reconstruction remainder"]


def split(ar,degree):
    k=ar["k"];tm=ar["t"];t=tm[tm>=89.65];ii=tm>=89.65
    roots,wt=leggauss(6);width=np.diff(t)
    sample=(t[:-1,None]+width[:,None]*(roots+1)/2).ravel()
    fields={key:ar["values"][:,:,index].T for index,key in enumerate(ar["names"].tolist())}
    sp=lambda arr:make_interp_spline(tm,arr,k=degree)
    get=lambda key:sp(fields[key])(sample)
    P=lambda val,der=0:sp(val)(sample,der)
    fn=lambda x:np.vstack((np.zeros((1,len(k))),np.cumsum((x.reshape(-1,6,len(k))*wt[None,:,None]).sum(1)*width[:,None]/2,axis=0)))
    scale=fields["a"][ii];change=(fields["sigma"][ii]-fields["sigma"][ii][:1])/k
    norm=np.max(abs(change),axis=0)
    H=get("adotoa");a=get("a");common=a**2/(2*H*k**2)
    X=(get("dgrho")/2+k*get("etak"))/H
    convert=lambda work:100*fn(common*work)/(scale**2*norm)
    sample_terms=lambda E,J,W,anis:P(E,1)+3*H*P(J,1)/k+H*P(E)+k*P(J)+P(W)*X+6*H**2*P(J)/k+2*H*P(anis)
    f=fields;eg,eb,er,ec,ev,fm=(f[key] for key in ("grhog_t","grhob_t","grhor_t","grhoc_t","grhov_t","grhonu_t"))
    zero=0*eg
    dark=(ev*f["clxde"],ev*f["qde"],ev*(1+f["w_lam"]),zero)
    baryon=(eb*f["clxb"]+eg*f["clxg"],eb*f["vb"]+eg*f["qg"],eb+4*eg/3,eg*f["pig"])
    rad=(er*f["clxr"],er*f["qr"],4*er/3,er*f["pir"]);cdm=(ec*f["clxc"],zero,ec,zero)
    total=(f["dgrho"],f["dgq"],f["grho"]+f["gpres"],f["dgpi"])
    pre=[baryon,rad,cdm,dark]
    massive=tuple([fm*f["clxnu"]]+[total[i]-sum(item[i] for item in pre) for i in (1,2,3)])
    units=[baryon,rad,cdm,massive,dark]
    units.append(tuple(total[i]-sum(item[i] for item in units) for i in range(4)))
    by=np.array([convert(sample_terms(*item)) for item in units]);full=convert(sample_terms(*total))
    accuracy=np.max(abs(by.sum(0)-full),axis=0)
    assert accuracy.max()<.001
    j=np.flatnonzero(ar["indices"]==37).item()
    def numbers(series,ref=full):
        curves=series[:,:,j];target=ref[:,j]
        return dict(peak_pct_of_shear_change=np.max(abs(curves),axis=1).tolist(),
                    signed_shares=(curves@target/(target@target)).tolist())
    result=dict(general=numbers(by),sector_additivity_error_pct=float(accuracy.max()),pressure_free_residual_pct=float(np.max(abs(full[:,j]))))
    if "mts_drho_h" in fields:
        config=read(pinned(nio.historic.io.oldio.PAD,"canonical-input.npz"))
        loga=np.log(a);ad=P(f["a"],1);aslope=ad/a
        base=CubicSpline(config["heavy_efold"],config["phi_h"])
        vel=CubicSpline(config["heavy_efold"],config["phidot_h"])
        bv,v=base(loga),vel(loga);mu2=(config["heavy_mass_mpc"]*a)**2
        dphi,w=get("mts_dphi_h"),get("mts_dphidot_h")
        Rv=vel(loga,1)*aslope+2*H*v+mu2*bv;Rb=base(loga,1)*aslope-v
        Rf=P(f["mts_dphi_h"],1)-w
        Rw=P(f["mts_dphidot_h"],1)+2*H*w+(k**2+mu2)*dphi+v*X
        hh=f["mts_drho_h"];jj=f["mts_q_h"];press=get("mts_dp_h")
        energy=P(hh,1)+H*(P(hh)+3*press)+k*P(jj)+v**2*X
        current=3*H*(P(jj,1)+2*H*P(jj)-k*press)/k
        parts=np.stack((convert(energy),convert(current)))
        work=np.stack([convert(Rv*(w+3*H*dphi)),convert(mu2*dphi*Rb),convert(v*Rw),
            convert((mu2*bv+3*H*v)*Rf),convert(2*(aslope-H)*mu2*bv*dphi)])
        heavy=parts.sum(0)
        result.update(heavy_E_and_weighted_J=numbers(parts),heavy_product_rule=numbers(work),
            heavy_alone_share=numbers(heavy[None])["signed_shares"][0],
            heavy_vs_product_rule_pct=float(np.max(abs(heavy-work.sum(0))[:,j])),
            exact_source_readout_absolute=float(np.max(abs(get("mts_drho_h")-v*w-mu2*bv*dphi))))
    return result


if __name__=="__main__":
    check("sector-freeze.json");results={}
    for label in ("heavy","cold"):
        data=read(ROOT/f"sectors-{label}.npz");parts,err,slip=audit(data,5,6)
        fine=split(data,5);control=split(data,3);j=np.flatnonzero(data["indices"]==37).item()
        results[label]=dict(quintic=fine,cubic=control,worst_shear_pct=float(np.max(abs(err))),k37_shear_pct=float(np.max(abs(err[:,j]))),
                            all_block_pointwise_identity_pct=float(slip.max()),over_gate=data["indices"][np.max(abs(err),axis=0)>=.5].tolist(),
                            k37_absolute_reference_change=float(np.max(abs((data["values"][j,data["t"]>=89.65,data["names"].tolist().index("sigma")]-data["values"][j,np.searchsorted(data["t"],89.65),data["names"].tolist().index("sigma")])/data["k"][j]))))
        print(label,results[label]["k37_shear_pct"],fine,flush=True)
    put("sector-scores.json",dict(rows=results,groups=GROUPS,method=digest(ROOT/"separate_conservation.py"),exposure="diagnosis, not a refit or new photon prediction"))
