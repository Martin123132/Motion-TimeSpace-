from support import *
from unittest.mock import patch
import direct_shear as prior
import inspect
import tempfile
import subprocess

NAMES=prior.NAMES+["dgrho","grho","gpres"]


def child():
    import native_io as nio
    sys.path.insert(0,str(nio.historic.io.EXT));import source_io as ext
    cap=ext.previous.prefix().import_at(ext.SOURCE,"capture89")
    source=inspect.getsource(prior.collect)
    for before,after in [('((160,6),(320,6),(320,12),(320,24))','((320,6),)'),('name=f"direct-', 'name=f"conservation-')]:
        assert source.count(before)==1
        source=source.replace(before,after)
    ctx=dict(prior.__dict__,NAMES=NAMES)
    exec(compile(source,"same native block with total density inputs","exec"),ctx)
    with patch.object(cap.driver,"HERE",ROOT),patch.object(cap.driver,"NAMES",NAMES),patch.object(cap.driver,"run",ctx["collect"]),patch.object(cap.driver,"save",lambda name,body:store("conservation-"+name,body)):
        cap.driver.main()


if __name__=="__main__":
    if sys.argv[1:2]==["--child"]:child()
    else:
        guard();check("direct-control-freeze.json")
        with tempfile.TemporaryDirectory(dir=ROOT,prefix="reader-conservation-") as folder:
            subprocess.run([sys.executable,"-B",str(ROOT/"conservation_readout.py"),"--child",folder,"heavy"],check=True)
        freeze("conservation-freeze.json",[ROOT/"conservation_readout.py",ROOT/"direct-method.json",ROOT/"conservation-320-6.npz",ROOT/"conservation-readout.f90"])
