from support import *
from unittest.mock import patch
import csv
import subprocess
import tempfile

NAMES="k tau a adotoa etak etakdot sigma sigmadot phi dgpi dgq".split()


def collect(model,func):
    import capture89 as cap
    import native_io as nio
    native=cap.diag.native
    status=native.obj(native.source("runs/heavy/status.json"))
    for file in native.engine.inherited.native_hashes():native.checked(file,status["input_hashes"][str(file)])
    source=nio.historic.io.oldio.PAD
    config=pinned(source,"canonical-input.npz")
    pars=native.engine.inherited.params_for(config,background_boost=8.)
    pars.DoLateRadTruncation=False
    bg=native.engine.camb.get_background(pars)
    with cap.pin("capture-heavy.csv").open() as stream:
        blocks=list(csv.DictReader(stream))
    block=next(row for row in blocks if int(row["first"])<=37<=int(row["last"]))
    all_modes=read(ROOT/"native-incoming.npz")["nodes"]
    ids=np.arange(int(block["first"]),int(block["last"])+1)
    spec=all_modes[ids];nodes=np.unique(np.r_[spec,float(block["control"]),float(block["hierarchy_cap"])])
    with patch.object(cap.diag.symbolic,"compile_sympy_to_camb_source_func",return_value=func):
        for res,boost in ((160,6),(320,6),(320,12),(320,24)):
            guard();name=f"direct-{res}-{boost}.npz"
            t=np.arange(round(89.55*res),round(90.4*res)+1)/res
            bg.Params.Accuracy.IntTolBoost=boost
            values=bg.get_time_evolution(nodes,t,vars=[cap.Dummy(key) for key in NAMES],lAccuracyBoost=4)[np.searchsorted(nodes,spec)]
            assert np.isfinite(values).all() and np.max(abs(values[:,:,0]-spec[:,None]))<1e-12
            packet(name,t=t,values=values,k=spec,indices=ids,names=NAMES,boost=boost)
            print("canonical unspliced shear",res,boost,len(spec),len(t),flush=True)


def child(folder):
    import native_io as nio
    sys.path.insert(0,str(nio.historic.io.EXT));import source_io as ext
    cap=ext.previous.prefix().import_at(ext.SOURCE,"capture89")
    with patch.object(cap.driver,"HERE",ROOT),patch.object(cap.driver,"NAMES",NAMES),patch.object(cap.driver,"run",collect),patch.object(cap.driver,"save",lambda name,body:store("direct-"+name,body)):
        cap.driver.main()


if __name__=="__main__":
    if sys.argv[1:2]==["--child"]:
        child(sys.argv[2])
    else:
        guard();check("shear-freeze.json")
        freeze("direct-method.json",[ROOT/"DIRECT-SHEAR.md",ROOT/"shear-control.json",ROOT/"shear-seam.json",ROOT/"direct_shear.py"])
        with tempfile.TemporaryDirectory(dir=ROOT,prefix="reader-direct-") as folder:
            subprocess.run([sys.executable,"-B",str(ROOT/"direct_shear.py"),"--child",folder,"heavy"],check=True)
        freeze("direct-freeze.json",[ROOT/"direct-method.json",ROOT/"direct-readout.f90",*sorted(ROOT.glob("direct-*.npz"))])
