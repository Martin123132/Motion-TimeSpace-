from support import *
from unittest.mock import patch
import csv
import tempfile
import subprocess
import direct_shear as prior

NAMES=prior.NAMES+"dgrho grho gpres grhov_t w_lam clxde qde grhog_t grhor_t grhob_t grhoc_t grhonu_t clxg clxr clxb clxc clxnu qg qr vb pig pir".split()


def collect(model,func):
    import capture89 as cap
    import native_io as nio
    native=cap.diag.native
    status=native.obj(native.source(f"runs/{model}/status.json"))
    for file in native.engine.inherited.native_hashes():native.checked(file,status["input_hashes"][str(file)])
    if model=="heavy":
        config=pinned(nio.historic.io.oldio.PAD,"canonical-input.npz")
    else:
        config=native.NATIVE/"runs/backgrounds/cold.npz";native.checked(config,status["source_hash"])
    pars=native.engine.inherited.params_for(config,background_boost=8.);pars.DoLateRadTruncation=False
    bg=native.engine.camb.get_background(pars);bg.Params.Accuracy.IntTolBoost=6
    with cap.pin("capture-heavy.csv").open() as stream:
        block=next(row for row in csv.DictReader(stream) if int(row["first"])<=37<=int(row["last"]))
    all_modes=read(ROOT/"native-incoming.npz")["nodes"]
    ids=np.arange(int(block["first"]),int(block["last"])+1);spec=all_modes[ids]
    nodes=np.unique(np.r_[spec,float(block["control"]),float(block["hierarchy_cap"])])
    t=np.arange(round(89.55*320),round(90.4*320)+1)/320
    scalar_tags=["s","h"] if model=="heavy" else ["s"]
    extras=["mts_"+field+"_"+tag for tag in scalar_tags for field in ("dphi","dphidot","drho","dp","q")]
    with patch.object(cap.diag.symbolic,"compile_sympy_to_camb_source_func",return_value=func):
        data=bg.get_time_evolution(nodes,t,vars=extras+[cap.Dummy(key) for key in NAMES],lAccuracyBoost=4)[np.searchsorted(nodes,spec)]
    assert np.isfinite(data).all()
    packet("sectors-"+model+".npz",t=t,k=spec,indices=ids,names=extras+NAMES,values=data)
    print("continuous sector readout",model,len(t),len(spec),flush=True)


def child():
    import native_io as nio
    sys.path.insert(0,str(nio.historic.io.EXT));import source_io as ext
    cap=ext.previous.prefix().import_at(ext.SOURCE,"capture89")
    with patch.object(cap.driver,"HERE",ROOT),patch.object(cap.driver,"NAMES",NAMES),patch.object(cap.driver,"run",collect),patch.object(cap.driver,"save",lambda name,body:store("sectors-"+name,body)):
        cap.driver.main()


if __name__=="__main__":
    if sys.argv[1:2]==["--child"]:child()
    else:
        guard();check("conservation-freeze.json")
        freeze("sector-method.json",[ROOT/"sector_readout.py",ROOT/"CONSERVATION.md",ROOT/"conservation.json",ROOT/"conservation-freeze.json"])
        with tempfile.TemporaryDirectory(dir=ROOT,prefix="reader-sectors-") as folder:
            subprocess.run([sys.executable,"-B",str(ROOT/"sector_readout.py"),"--child",folder,"heavy","cold"],check=True)
        freeze("sector-freeze.json",[ROOT/"sector-method.json",ROOT/"sectors-heavy.npz",ROOT/"sectors-cold.npz",ROOT/"sectors-readout.f90"])
