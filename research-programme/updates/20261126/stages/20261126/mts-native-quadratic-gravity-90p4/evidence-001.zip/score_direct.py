from support import *
from scipy.interpolate import make_interp_spline


def run():
    check("direct-method.json")
    assert all((ROOT/f"direct-{res}-6.npz").is_file() for res in (160,320))
    freeze("direct-control-freeze.json",[ROOT/"direct-method.json",ROOT/"direct-readout.f90",*sorted(ROOT.glob("direct-*.npz"))])
    rows=[]
    for res,boost in ((160,6),(320,6),(320,12),(320,24)):
        if not (ROOT/f"direct-{res}-{boost}.npz").exists():
            continue
        data=read(ROOT/f"direct-{res}-{boost}.npz");mask=data["t"]>=89.65;t=data["t"][mask]
        v={key:data["values"][:,mask,i].T for i,key in enumerate(data["names"].tolist())};k=data["k"]
        alpha=v["sigma"]/k;H=v["adotoa"];phi=v["etak"]/k-H*alpha;slip=2*(phi-v["phi"]);actual=v["sigmadot"]/k
        derived=v["etak"]/k-2*H*alpha-slip
        alternative=v["etak"]/k-2*H*alpha-1.5*v["dgpi"]/k**2
        delta=alpha-alpha[:1]
        calc=lambda difference,scale:100*np.max(abs(difference),axis=0)/np.max(abs(scale),axis=0)
        def from_rate(value):
            antider=make_interp_spline(t,value,k=5).antiderivative()
            return antider(t)-antider(t[0])
        rate_error=calc(derived-actual,actual)
        source_error=calc(alternative-actual,actual)
        native_error=calc(from_rate(actual)-delta,delta);derived_error=calc(from_rate(derived)-delta,delta)
        idx=np.flatnonzero(data["indices"]==37).item();assert v["k"][0,idx]==k[idx]
        rows.append(dict(res=res,boost=boost,indices=data["indices"].tolist(),rate_identity_pct=rate_error.tolist(),
                         anisotropic_stress_formula_pct=source_error.tolist(),native_integral_pct=native_error.tolist(),
                         derived_integral_pct=derived_error.tolist(),k37=dict(rate=float(rate_error[idx]),direct=float(native_error[idx]),
                            derived=float(derived_error[idx]),anisotropy=float(source_error[idx])),
                         passing_all_block=bool(np.all(native_error<.5) and np.all(derived_error<.5) and np.all(rate_error<.5))))
        print(res,boost,"k37",rows[-1]["k37"],"all worst",rate_error.max(),derived_error.max(),flush=True)
    put("direct-scores.json",dict(rows=rows,gate_pct=.5,boost12="DVERK failed before first requested output; not scored",boost24="Not launched after boost12 failure",method=digest(ROOT/"score_direct.py"),scope="continuous native capture of the block containing leg 37; percentages relative to its own rate or change as indicated"))


if __name__=="__main__":run()
