import argparse
import ast
from support import *

pinned(SCALAR,"score_total.py")
sys.path.insert(0,str(SCALAR))
from score_total import aperture


def obj(name):
    return json.loads((ROOT/name).read_bytes())


def fixtures():
    for name in ("native-freeze.json","joined-freeze.json","real-freeze.json","channels-freeze.json","shear-freeze.json","direct-control-freeze.json","conservation-freeze.json","sector-freeze.json","repair-freeze.json"):
        check(name)
    for pattern in ("*-method.json","*.receipt","*-freeze.json"):
        for path in ROOT.glob(pattern):check(path.name)
    assert len(list(ROOT.glob("joined-*.npz.receipt")))==8
    assert not list(ROOT.glob("direct-*-12.npz")) and not list(ROOT.glob("direct-*-24.npz"))
    assert not list(ROOT.rglob("*.partial")) and not any(item.is_dir() for item in ROOT.iterdir())
    for path in ROOT.glob("*.py"):
        ast.parse(path.read_text(),filename=str(path))


def recompute():
    native=obj("native-control.json");assert native["passes"]
    assert all(max(row["change_pct"]+row["level_pct"])<.5 for row in native["rows"])
    score=obj("scores.json");assert score["gate_pct"]==.5 and score["forecast"]==digest(ROOT/"joined-freeze.json")
    for row in score["rows"]:
        grid,res=row["grid"],row["res"]
        with np.load(pinned(SCALAR,f"driven-{grid}-{res}.npz")) as saved:
            centers=read(pinned(PRE,f"angles-{res}.npz"))["centers"]
            ix=np.searchsorted(saved["t"],centers);assert np.array_equal(saved["t"][ix],centers) and len(ix)==6
            reference=aperture(saved["phase"],saved["values"][0,1:2],saved["phase"][ix])[0,0]
        scale=np.max(abs(reference-reference[:1]),axis=0)
        for mem in (0,1):
            packet=read(ROOT/f"joined-{grid}-{res}-{mem}.npz")
            assert packet["final_lag"].shape==(32,77,69) and np.isfinite(packet["final_lag"]).all()
            select=np.searchsorted(packet["t"],centers)
            mean=packet["stress"][select,:,:,1].mean(1)
            error=(mean-mean[:1])-(reference-reference[:1])
            checkp=100*np.max(abs(error),axis=0)/scale
            np.testing.assert_allclose(checkp,row["variants"][str(mem)]["pressure_pct"],rtol=5e-7,atol=1e-7)
            assert checkp[0]<.5<checkp[1] and row["original"]["pressure_pct"][1]<checkp[1]
    seam=obj("shear-control.json")
    assert not seam["passes"] and seam["failing_leg_count"]==1 and seam["worst_source_leg"]==37
    assert all(max(row["change"])<.5 for row in seam["rows"])
    assert len(obj("direct-scores.json")["rows"])==2
    cs=obj("conservation.json")
    assert cs["k37"]["residual_pct"]>.5 and cs["k37"]["accounting_error_pct"]<.001
    models=obj("sector-scores.json")["rows"];assert models["cold"]["over_gate"]==[] and models["heavy"]["over_gate"]==[37]
    assert len(obj("memory-erratum.json")["rows"])==4
    for row in obj("memory-erratum.json")["rows"]:
        assert row["prior"]["historical_Y_drift_pct"]==row["corrected"]["historical_Y_drift_pct"]
        assert max(max(s["complete_constraint_load_change_pct"]) for s in row["corrected"]["scales"])<.5
    for row in obj("repair-scores.json")["rows"]:
        model,res=row["model"],row["res"]
        packet=read(ROOT/f"background-{model}-{res}.npz")
        assert len(packet["k"])==24 and len(packet["t"])==241 and np.isfinite(packet["state"]).all()
        assert np.array_equal(packet["state"][0,0],packet["state"][0,1])
        diff=packet["alpha_H"]-packet["alpha_integrated"]
        scale=np.max(abs(packet["alpha_archive"]-packet["alpha_archive"][:1]),axis=0)
        error=100*np.max(abs(diff-diff[:1]),axis=0)/scale
        np.testing.assert_allclose(error.max(1),row["max_closure_pct"],rtol=1e-10)
        assert np.max(100*abs(diff)/scale)<.5 and np.max(error)<.015
        if model=="heavy":
            assert min(row["vs_archive_k37"])>.5


def verify(create):
    if not __debug__:raise RuntimeError("Use ordinary Python without -O")
    guard();fixtures();recompute()
    inputs={path.name:digest(path/"seal.json") for path in (PRE,SCALAR)}
    files={item.name:digest(item) for item in ROOT.iterdir() if item.name!="seal.json" and item.is_file()}
    manifest=dict(files=files,parents=inputs,scope="Native quadratic source forecast, 24-mode conditional repair with cold control, and archived memory erratum. No new photon prediction.")
    if create:put("seal.json",manifest)
    assert obj("seal.json")==manifest
    print("Verified",len(files),"files; stage seal",digest(ROOT/"seal.json"))


if __name__=="__main__":
    parser=argparse.ArgumentParser()
    parser.add_argument("--seal",action="store_true")
    verify(parser.parse_args().seal)
