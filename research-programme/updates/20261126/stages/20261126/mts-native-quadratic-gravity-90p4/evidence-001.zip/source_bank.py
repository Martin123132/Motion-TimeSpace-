from support import *
from types import SimpleNamespace
from scipy.interpolate import make_interp_spline
from phasegrav_io import orbit, historic, old

ANCHOR = 89.65
FIELDS = "a adotoa etak sigma grho gpres dgq dgrho mts_dphi_h mts_dphidot_h".split()


def acquire(folder, end, start):
    parent = folder.parent
    files = sorted(folder.glob("linear-heavy-??.npz"))
    assert len(files) == 38
    chunks, nodes = [], []
    for path in files:
        guard()
        with np.load(pinned(parent, str(path.relative_to(parent).as_posix()))) as saved:
            use = (saved["eta"] >= start) & (saved["eta"] <= end)
            assert np.all(saved["good"][:, use]) and saved["begin"] == sum(map(len, nodes))
            ids = [saved["keys"].tolist().index(col) for col in FIELDS]
            chunks.append(saved["values"][:, use][:, :, ids])
            nodes.append(saved["k"])
            time = saved["eta"][use]
    with np.load(pinned(parent, folder.name + "/background-heavy.npz")) as saved:
        use = np.searchsorted(saved["eta"], time)
        assert np.array_equal(saved["eta"][use], time)
        back, vel, mass = saved["hphi"][use], saved["hphidot"][use], float(saved["hmass"])
    data = dict(zip(FIELDS, np.concatenate(chunks).transpose(2, 1, 0)))
    return SimpleNamespace(**data, t=time, k=np.concatenate(nodes), back=back, vel=vel, mass=mass)


def spatial_operator(nodes):
    lib = orbit.spatial
    shell = np.array(json.loads(lib.pin("legs.json").read_bytes())["squared_radii"])
    data = SimpleNamespace(shell=shell, nodes=nodes, first={})
    kernel = lib.Project(data).ops[0]
    return lib.Fast(kernel, data), kernel[1]**2


def contractions(op, phi, field, normal, vel, mu2):
    op.data.first = dict(phi=phi.T, f=field.T, n=normal.T, u=(normal-3*vel[:,None]*phi).T)
    energy = vel*(3*op.product("phi","u") + 7.5*vel*op.product("phi","phi"))
    energy += (op.product("n","n") + op.grad("f","f") + mu2*op.product("f","f"))/2
    return np.stack((energy, -op.dg("n","f")), axis=-1)


def summarize(raw):
    scale, hub, back, vel = raw.a[:,0], raw.adotoa[:,0], raw.back, raw.vel
    mu2 = (raw.mass*scale)**2
    field, speed, etak = raw.mts_dphi_h, raw.mts_dphidot_h, raw.etak
    energy = vel[:,None]*speed + (mu2*back)[:,None]*field
    current = raw.k*vel[:,None]*field
    rest = np.column_stack((raw.grho[:,0]+3*raw.gpres[:,0]-(2*vel**2-mu2*back**2),
                            raw.dgrho-energy, raw.dgq-current))
    slope = (raw.dgrho/2 + raw.k*etak)/hub[:,None]
    shear = slope/raw.k + 1.5*raw.dgq/raw.k**2
    alpha = raw.sigma/raw.k
    phi = etak/raw.k - hub[:,None]*alpha
    return dict(time=raw.t, nodes=raw.k, scale=scale, hub=hub, back=back, vel=vel, mass=raw.mass,
                field=field, speed=speed, etak=etak, rest=rest, slope=slope, current=raw.dgq,
                reconstructed_shear=shear, shear=raw.sigma, phi=phi)


def replay(raw, data, folder):
    operator, kk = spatial_operator(raw.k)
    alpha = raw.sigma/raw.k
    mu2 = (raw.mass*data["scale"])**2
    f = data["field"] + data["vel"][:,None]*alpha
    n = data["speed"] + (-3*data["hub"]*data["vel"]-mu2*data["back"])[:,None]*alpha
    sources = contractions(operator, data["phi"], f, n, data["vel"], mu2)
    with np.load(pinned(folder.parent, folder.name+"/forcing-heavy.npz")) as archive:
        idx = np.searchsorted(archive["eta"], raw.t)
        assert np.array_equal(archive["eta"][idx],raw.t) and np.isclose(kk,archive["k"][0]**2)
        truth = archive["values"][[archive["keys"].tolist().index(key) for key in ("henergy","hJ")]][:,idx,0].T
    percent = lambda diff,ref:(100*np.max(abs(diff),axis=0)/np.max(abs(ref),axis=0))
    score = percent(sources-truth,truth)
    assert np.all(score<1e-7), score
    shear = percent(raw.sigma-data["reconstructed_shear"],raw.sigma)
    return dict(source_pct=score.tolist(),shear_worst_pct=float(shear.max()),shear_median_pct=float(np.median(shear)),
                count=len(raw.t),legs=len(raw.k))


if __name__ == "__main__":
    folder = old.BANK/"material-halfstep"
    raw = acquire(folder, ANCHOR, 88.8)
    assert raw.t[-1] == ANCHOR
    data = summarize(raw)
    report = replay(raw,data,folder)
    print(report,flush=True)
    put("incoming-replay.json",report)
    packet("native-incoming.npz",**data)
    freeze("input-freeze.json",[ROOT/"native-incoming.npz",ROOT/"incoming-replay.json",ROOT/"source_bank.py",ROOT/"support.py",ROOT/"PROTOCOL.md",folder.parent/"seal.json",PRE/"seal.json"])
