import inspect
import native_predict as driver
from native_tables import source_tables
from support import *


def generate(res):
    source=inspect.getsource(driver.generate)
    for key,replace in [
        ("angles=np.pi*np.arange(16)/16","angles=np.array([0.])"),
        ('forward=read(pinned(PRE,f"angles-{res}.npz"))["t"]','forward=np.arange(round(89.65*res),round(90.4*res)+1)/res'),
        ('packet(f"native-{res}.npz",past=past,prior=before,t=forward,values=after,angles=angles,kk=kk)','packet(f"real-{res}.npz",t=np.r_[past,forward[1:]],values=np.concatenate((before[:,0],after[1:,0])))')]:
        assert source.count(key)==1
        source=source.replace(key,replace)
    ctx=dict(driver.__dict__,source_tables=source_tables)
    exec(compile(source,"one incoming physical orientation, full temporal support","exec"),ctx)
    ctx["generate"](res)
    both=read(ROOT/f"native-{res}.npz");own=read(ROOT/f"real-{res}.npz")
    ix=np.searchsorted(own["t"],both["t"]);assert np.array_equal(own["t"][ix],both["t"])
    diff=100*np.max(abs(own["values"][ix]-both["values"][:,0]),axis=0)/np.max(abs(own["values"][ix]),axis=0)
    assert np.all(diff<1e-8),diff


if __name__=="__main__":
    check("native-freeze.json")
    for res in (640,1280):generate(res)
    freeze("real-freeze.json",[ROOT/"single_history.py",ROOT/"native-freeze.json",ROOT/"real-640.npz",ROOT/"real-1280.npz"])
