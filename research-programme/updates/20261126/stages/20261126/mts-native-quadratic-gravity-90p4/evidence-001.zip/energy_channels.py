import inspect
from source_bank import *
import native_predict as driver
from native_tables import source_tables

GROUPS=["synchronous perturbed field and velocity","homogeneous oscillator b,v","expansion a,H","shear (time slicing)","spatial curvature etak"]


def predicted(res):
    source=inspect.getsource(driver.generate)
    for before,after in [
        ("angles=np.pi*np.arange(16)/16","angles=np.array([0.])"),
        ('forward=read(pinned(PRE,f"angles-{res}.npz"))["t"]','forward=np.arange(round(89.65*res),round(90.4*res)+1)/res'),
        ("return contractions(operator,phi,ff,nn,v[:,0],omega[:,0])","return state[0].copy(),alpha[0].copy()"),
        ("out=[calc(states,tables[0],True)]","out=[np.r_[*calc(states,tables[0],True)]]"),
        ("out.append(calc(states,tables[i+2],True))","out.append(np.r_[*calc(states,tables[i+2],True)])"),
        ('packet(f"native-{res}.npz",past=past,prior=before,t=forward,values=after,angles=angles,kk=kk)','return np.r_[past,forward[1:]],np.concatenate((before,after[1:]))')
    ]:
        assert source.count(before)==1
        source=source.replace(before,after)
    ctx=dict(driver.__dict__,source_tables=source_tables)
    exec(compile(source,"physical trajectory diagnostic","exec"),ctx)
    return ctx["generate"](res)


def run(res,past,future):
    time=np.r_[past.t,future.t[1:]]
    assert future.t[0]==past.t[-1] and np.array_equal(past.k,future.k)
    grid=past.k;mass=past.mass
    combine=lambda before,after:np.concatenate((before,after[1:]))
    real=np.column_stack((combine(past.a[:,0],future.a[:,0]),combine(past.adotoa[:,0],future.adotoa[:,0]),combine(past.back,future.back),combine(past.vel,future.vel),
             combine(past.mts_dphi_h,future.mts_dphi_h),combine(past.mts_dphidot_h,future.mts_dphidot_h),combine(past.etak,future.etak),combine(past.sigma,future.sigma)/grid))
    tm,pred=predicted(res);ids=np.searchsorted(tm,time);assert np.array_equal(tm[ids],time)
    def fields(state):
        a,h,b,v=state[:,:4].T[:,:,None];f,w,eta,alpha=np.split(state[:,4:],4,axis=1)
        mu=a*mass;cc=-3*h*v-mu**2*b;phi=eta/grid-h*alpha
        return dict(h=h,b=b,v=v,f=f,w=w,curv=eta/grid,alpha=alpha,mu=mu,mu2=mu**2,cc=cc,phi=phi,ff=f+v*alpha,nn=w+cc*alpha,pot=mu*(f+v*alpha),vp=v*phi)
    est,actual=map(fields,[pred[ids],real])
    mean={key:(est[key]+actual[key])/2 for key in actual}
    delta={key:est[key]-actual[key] for key in actual}
    d,mid=delta,mean
    nil=np.zeros_like(d["ff"])
    ff=[d["f"],mid["alpha"]*d["v"],nil,mid["v"]*d["alpha"],nil]
    nn=[d["w"],mid["alpha"]*(-3*mid["h"]*d["v"]-mid["mu2"]*d["b"]),mid["alpha"]*(-3*mid["v"]*d["h"]-2*mid["mu"]*mid["b"]*d["mu"]),mid["cc"]*d["alpha"],nil]
    vp=[nil,mid["phi"]*d["v"],-mid["v"]*mid["alpha"]*d["h"],-mid["v"]*mid["h"]*d["alpha"],mid["v"]*d["curv"]]
    pot=[mid["mu"]*piece+(mid["ff"]*d["mu"] if i==2 else 0.) for i,piece in enumerate(ff)]
    op,kk=spatial_operator(grid)
    term=[]
    for i in range(len(GROUPS)):
        op.data.first={key:mid[key].T for key in ("nn","ff","vp","pot")}
        for key,seq in (("dn",nn),("df",ff),("dv",vp),("dp",pot)):
            op.data.first[key]=seq[i].T
        sym=lambda fn,x,y:(fn(x,y)+fn(y,x))/2
        qenergy=sym(op.product,"dn","nn")+sym(op.grad,"df","ff")+sym(op.product,"dp","pot")
        qenergy+=3*(op.product("dv","nn")+op.product("vp","dn"))-3*sym(op.product,"dv","vp")
        qcurrent=-op.dg("dn","ff")-op.dg("nn","df")
        term.append(np.stack((qenergy,qcurrent),axis=-1))
    term=np.array(term)
    true=contractions(op,actual["phi"],actual["ff"],actual["nn"],actual["v"][:,0],actual["mu2"][:,0])
    direct=contractions(op,est["phi"],est["ff"],est["nn"],est["v"][:,0],est["mu2"][:,0])
    realpack=read(ROOT/f"real-{res}.npz")
    np.testing.assert_allclose(direct,realpack["values"][ids],rtol=3e-13,atol=2e-27)
    err=100*np.max(abs(term.sum(0)-(direct-true)),axis=0)/np.max(abs(direct-true),axis=0)
    assert err.max()<1e-5,err
    packet(f"channels-{res}.npz",t=time,terms=term,direct=direct,true=true,closure_pct=err)
    print("signed work split",res,err,flush=True)


if __name__=="__main__":
    check("real-freeze.json")
    incoming=acquire(old.BANK/"material-halfstep",ANCHOR,89.275)
    later=acquire(historic.io.oldio.PAD/"material-halfstep",90.4,ANCHOR)
    for res in (640,1280):run(res,incoming,later)
    freeze("channels-freeze.json",[ROOT/"real-freeze.json",ROOT/"energy_channels.py",ROOT/"channels-640.npz",ROOT/"channels-1280.npz"])
