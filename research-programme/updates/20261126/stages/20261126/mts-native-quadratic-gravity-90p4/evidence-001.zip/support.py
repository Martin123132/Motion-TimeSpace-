import hashlib
import io
import json
import sys
from pathlib import Path
import numpy as np

ROOT = Path(__file__).resolve().parent
BASE = ROOT.parent
PRE = BASE / "mts-phase-resolved-gravity-90p4-20261126"
SCALAR = BASE / "mts-total-phase-stress-90p4-20261126"


def digest(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


assert digest(PRE / "seal.json") == "ac5fc68b299f00e7a8ba628b21de42618d520f09e2f9b59e781028c4f4a58169"
assert digest(SCALAR / "seal.json") == "552d5ba956a576eb651473abfc3f44ae03b63c9db0dcae257513749071472630"
sys.path.insert(0, str(PRE))


def pinned(folder, name):
    source = folder / name
    assert digest(source) == json.loads((folder / "seal.json").read_bytes())["files"][name], name
    return source


def guard():
    assert not any((where / "STOP-REQUESTED").exists() for where in (BASE, ROOT, PRE, SCALAR))


def store(name, body):
    guard()
    path = ROOT / name
    if path.exists():
        assert digest(path) == hashlib.sha256(body).hexdigest(), name
        return
    temp = ROOT / (name + ".partial")
    with temp.open("xb") as stream:
        stream.write(body)
    temp.rename(path)


def put(name, data):
    store(name, (json.dumps(data, indent=2, sort_keys=True, allow_nan=False) + "\n").encode())


def packet(name, **fields):
    stream = io.BytesIO()
    np.savez_compressed(stream, **fields)
    store(name, stream.getvalue())


def freeze(name, paths):
    put(name, {str(path.relative_to(BASE)):digest(path) for path in paths})


def check(name):
    for key, value in json.loads((ROOT / name).read_bytes()).items():
        assert digest(BASE / key) == value, key


def read(path):
    with np.load(path) as data:
        return dict(data.items())
