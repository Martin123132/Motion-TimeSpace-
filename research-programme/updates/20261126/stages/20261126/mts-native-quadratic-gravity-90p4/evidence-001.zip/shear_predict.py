from functools import lru_cache
import inspect
import native_predict as driver
from native_tables import source_tables
from source_bank import *
from scipy.interpolate import CubicSpline


def weyl(folder,start,end):
    arrays=[];nodes=[]
    for path in sorted(folder.glob("linear-heavy-??.npz")):
        with np.load(pinned(folder.parent,folder.name+"/"+path.name)) as ar:
            take=(ar["eta"]>=start)&(ar["eta"]<=end)
            i=ar["keys"].tolist().index("phi")
            arrays.append(ar["values"][:,take,i].T);nodes.extend(ar["k"]);t=ar["eta"][take]
    assert len(nodes)==782
    return t,np.concatenate(arrays,axis=1)


@lru_cache()
def incident_slip():
    data=read(ROOT/"native-incoming.npz")
    time,pot=weyl(old.BANK/"material-halfstep",data["time"][0],ANCHOR)
    assert np.array_equal(time,data["time"])
    return make_interp_spline(time,2*(data["phi"]-pot),k=5)


@lru_cache()
def slip_forecast(res):
    par=orbit.kin.initial("matched");snap=read(orbit.signed(f"coupled-matched-{res}.npz"))
    cols={key:snap["values"][:,idx] for idx,key in enumerate(snap["keys"].tolist())}
    dt=(snap["t"]-orbit.CUT)[:,None]
    fac=1+par.h0*dt+(par.h0**2-par.pressure)*dt**2/4
    source=((par.weights[2]*cols["pig"]+par.weights[3]*cols["pir"])/fac**2+1.5*cols["S"])/snap["k"]**2
    return make_interp_spline(snap["t"],source,k=5)


def shear_tables(raw,res,fine):
    values=source_tables(raw,res,fine)
    before=fine<=ANCHOR
    slip=np.zeros((len(fine),len(raw["nodes"])))
    past=incident_slip();slip[before]=past(fine[before])
    if not before.all():
        forward=slip_forecast(res)
        slip[~before]=past(ANCHOR)+(forward(fine[~before])-forward(ANCHOR))
    return np.column_stack((values,slip))


def generate(res,extended=False):
    source=inspect.getsource(driver.generate)
    seed='    seed=np.column_stack((scale,hub0,odd,even))'
    newseed="""    f0,w0=np.split(odd[:,2:],2,axis=1)
    E0,J0=np.split(raw["rest"][-1,1:],2)
    total_J=J0+grid*odd[:,1:2]*f0
    X0=((E0+odd[:,1:2]*w0+mu2[-1]*odd[:,:1]*f0)/2+grid*even)/hub0[:,None]
    alpha0=(X0+1.5*total_J/grid)/grid**2
    seed=np.column_stack((scale,hub0,odd,even,alpha0))"""
    mods=[(seed,newseed),("field,speed,eta=np.split(state[:,4:],3,axis=1)","field,speed,eta,alpha=np.split(state[:,4:],4,axis=1)"),
          ("external[1+size:]","external[1+size:1+2*size]"),
          ("slope=((rest_e+v*speed+omega*b*field)/2+grid*eta)/h","slope=grid**2*alpha-1.5*total_current/grid"),
          ("shear=(slope+1.5*total_current/grid)/grid;alpha=shear/grid","shear=grid*alpha"),
          ("total_current/2))","total_current/2,eta/grid-2*h*alpha-external[1+2*size:]))"),
          ('packet(f"native-{res}.npz"','packet(f"shear-{res}.npz"')]
    if extended:
        mods.extend([("angles=np.pi*np.arange(16)/16","angles=np.array([0.])"),
                     ('forward=read(pinned(PRE,f"angles-{res}.npz"))["t"]','forward=np.arange(round(89.65*res),round(90.4*res)+1)/res'),
                     ('packet(f"shear-{res}.npz",past=past,prior=before,t=forward,values=after,angles=angles,kk=kk)','packet(f"shear-real-{res}.npz",t=np.r_[past,forward[1:]],values=np.concatenate((before[:,0],after[1:,0])))')])
    for before,after in mods:
        assert source.count(before)==1,before
        source=source.replace(before,after)
    ctx=dict(driver.__dict__,source_tables=shear_tables)
    exec(compile(source,"canonical scalar with Einstein shear propagation","exec"),ctx)
    ctx["generate"](res)


if __name__=="__main__":
    check("channels-freeze.json")
    freeze("shear-method.json",[ROOT/"SHEAR.md",ROOT/"shear_predict.py",ROOT/"channels-freeze.json",ROOT/"channel-scores.json",ROOT/"numeric-method.json"])
    for res in (640,1280):
        generate(res);generate(res,True)
    freeze("shear-freeze.json",[ROOT/"shear-method.json",*sorted(ROOT.glob("shear-*.npz"))])
