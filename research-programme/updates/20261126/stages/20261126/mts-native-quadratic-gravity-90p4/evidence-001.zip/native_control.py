from source_bank import *


def run():
    check("native-freeze.json")
    folder=historic.io.oldio.PAD/"material-halfstep"
    raw=acquire(folder,89.846875,ANCHOR)
    report=replay(raw,summarize(raw),folder)
    with np.load(pinned(folder.parent,folder.name+"/forcing-heavy.npz")) as ar:
        ids=[ar["keys"].tolist().index(name) for name in ("henergy","hJ")]
        source=ar["values"][ids][:,np.searchsorted(ar["eta"],raw.t),0].T
    rows=[]
    for res in (640,1280):
        snap=read(ROOT/f"native-{res}.npz")
        ids=np.searchsorted(snap["t"],raw.t)
        assert np.array_equal(snap["t"][ids],raw.t)
        delta=snap["values"][ids,0]-source
        level=100*np.max(abs(delta),axis=0)/np.max(abs(source),axis=0)
        drift=100*np.max(abs(delta-delta[:1]),axis=0)/np.max(abs(source-source[:1]),axis=0)
        rows.append(dict(res=res,level_pct=level.tolist(),change_pct=drift.tolist()))
        print(res,level,drift)
    put("native-control.json",dict(incoming=json.loads((ROOT/"incoming-replay.json").read_bytes()),raw_knots=report,rows=rows,
        passes=bool(all(max(row["level_pct"]+row["change_pct"])<0.5 for row in rows)),tolerance_pct=0.5,
        meaning="Real orientation is predicted, not normalized to the external source in this check; two fields tested independently."))


if __name__=="__main__":
    run()
