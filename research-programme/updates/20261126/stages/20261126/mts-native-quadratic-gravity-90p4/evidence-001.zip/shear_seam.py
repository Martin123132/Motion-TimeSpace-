from shear_predict import *
from scipy.interpolate import make_interp_spline
from scipy.integrate import cumulative_simpson


def segment(raw,weyl_value,start,stop):
    take=(raw.t>=start)&(raw.t<=stop);t=raw.t[take];a=raw.a[take];h=raw.adotoa[take]
    k=raw.k;actual=raw.sigma[take]/k
    Phi=raw.etak[take]/k-h*actual;slip=2*(Phi-weyl_value[take])
    right=a**2*(raw.etak[take]/k-slip)
    integral=make_interp_spline(t,right,k=5).antiderivative()
    pred=(a[:1]**2*actual[:1]+integral(t)-integral(t[0]))/a**2
    diff=pred-actual;scale=np.max(abs(actual-actual[:1]),axis=0)
    pct=100*np.max(abs(diff),axis=0)/scale;rel=100*np.max(abs(diff),axis=0)/np.max(abs(actual),axis=0)
    incremental=100*np.diff(a**2*diff,axis=0)/(a[1:]**2*scale)
    key=37;i=np.argmax(abs(incremental[:,key]))
    return dict(span=[float(t[0]),float(t[-1])],max_pct=float(pct.max()),median_pct=float(np.median(pct)),
                offside=np.flatnonzero(pct>=.5).tolist(),k37_level_error_pct=float(rel[key]),
                k37_change_error_pct=float(pct[key]),k37_change_pct_of_level=float(100*scale[key]/np.max(abs(actual[:,key]))),
                largest_single_step_k37_pct_of_change=float(incremental[i,key]),largest_step_ends=float(t[i+1]))


if __name__=="__main__":
    check("shear-freeze.json")
    folder=historic.io.oldio.PAD/"material-halfstep"
    raw=acquire(folder,90.4,89.55);_,potential=weyl(folder,89.55,90.4)
    rows=[segment(raw,potential,start,stop) for start,stop in ((89.55,89.65),(89.65,90.4),(89.65625,90.4),(89.6625,90.4))]
    op,_=spatial_operator(raw.k)
    put("shear-seam.json",dict(rows=rows,k37_field_slots=int(np.count_nonzero(op.field==37)),k37_metric_slots=int(np.count_nonzero(op.metric==37)),
                               active_nodes=int(len(set(op.field)|set(op.metric))),pairs=int(len(op.phase)),
                               meaning="Segment integrals only diagnose the archived Weyl/shear relation. Independent shorter segments do not replace the whole-window gate."))
    print(rows,flush=True)
