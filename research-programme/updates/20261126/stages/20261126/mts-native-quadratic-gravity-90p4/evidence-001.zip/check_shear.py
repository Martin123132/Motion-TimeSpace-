from shear_predict import *
from scipy.integrate import cumulative_simpson


def run():
    check("shear-freeze.json")
    src=historic.io.oldio.PAD/"material-halfstep";raw=acquire(src,90.4,ANCHOR)
    t=raw.t;_,weyl_native=weyl(src,ANCHOR,90.4)
    alpha=raw.sigma/raw.k;phi=raw.etak/raw.k-raw.adotoa*alpha
    slip=2*(phi-weyl_native);rhs=raw.a**2*(raw.etak/raw.k-slip)
    def integrate(order):
        anti=make_interp_spline(t,rhs,k=order).antiderivative()
        return (alpha[:1]*raw.a[:1]**2+(anti(t)-anti(t[0])))/raw.a**2
    control=integrate(5);alternative=integrate(3)
    pc=lambda value,ref:100*np.max(abs(value),axis=0)/np.max(abs(ref),axis=0)
    delta=alpha-alpha[:1];identity=pc(control-alpha,delta);error_ctrl=pc(control-alternative,delta)
    worst=int(np.argmax(identity))
    bad=np.flatnonzero(identity>=.5)
    with np.load(pinned(src.parent,src.name+"/forcing-heavy.npz")) as ar:
        ix=np.searchsorted(ar["eta"],t)
        source=ar["values"][[ar["keys"].tolist().index(s) for s in ("henergy","hJ")]][:,ix,0].T
    rows=[]
    for res in (640,1280):
        snap=read(ROOT/f"shear-{res}.npz");whole=read(ROOT/f"shear-real-{res}.npz")
        ix=np.searchsorted(whole["t"],t);assert np.array_equal(whole["t"][ix],t)
        truth=source
        diff=whole["values"][ix]-truth;use=t<=snap["t"][-1]
        jx=np.searchsorted(snap["t"],t[use]);assert np.array_equal(snap["t"][jx],t[use])
        eq=pc(whole["values"][ix[use]]-snap["values"][jx,0],truth[use])
        present=slip_forecast(res);slip_model=incident_slip()(ANCHOR)+(present(t)-present(ANCHOR))
        shared=pc(slip_model-slip,slip)
        level=pc(diff[use],truth[use]);change=pc(diff[use]-diff[0],truth[use]-truth[0])
        rows.append(dict(res=res,level=level.tolist(),change=change.tolist(),full_level=pc(diff,truth).tolist(),
                         full_change=pc(diff-diff[:1],truth-truth[:1]).tolist(),zero_angular_replay_pct=eq.tolist(),
                         predicted_slip_level_pct_max=float(shared.max()),predicted_slip_level_pct_median=float(np.median(shared))))
        assert max(eq)<1e-8
        print("physical shear/short source changes",res,level,change,"full",rows[-1]["full_change"],"independent shear quadrature",identity.max(),flush=True)
    put("shear-control.json",dict(rows=rows,passes=bool(len(bad)==0 and all(max(row["level"]+row["change"])<.5 for row in rows)),fixed_gate_pct=.5,
             failing_leg_count=len(bad),worst_leg_k=float(raw.k[worst]),worst_source_leg=worst,first_increment_error_pct_of_window=float(100*abs(control[1,worst]-alpha[1,worst])/max(abs(delta[:,worst]))),
             stored_shear_change_integral_pct_max=float(identity.max()),stored_shear_change_integral_pct_median=float(np.median(identity)),
             quadrature_spread_pct_max=float(error_ctrl.max()),legs=len(raw.k)))


if __name__=="__main__":run()
