import argparse
import csv
import hashlib
import json
import sys
from io import BytesIO
from pathlib import Path

import numpy as np
from scipy.interpolate import CubicSpline
from scipy.optimize import brentq

ROOT=Path(__file__).resolve().parent
SECOND=ROOT.parent/"mts-second-period-companion-joint-89p33-20261126"
PIN="1cf8f15b958febccef5138a9fbb01bc5b4cef0629dbb8976bd1f8350c466da1a"
CYCLE=ROOT.parent/"mts-wave-transfer-89p15-20261124"
CYCLE_PIN="31f9925322c86a7d9876cd31469a79dbb0f8bc1ae17acf2410c4486f9fdec962"


def digest(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream,"sha256").hexdigest()


def sealed(folder,pin,name):
    assert digest(folder/"seal.json")==pin
    path=folder/name
    assert digest(path)==json.loads((folder/"seal.json").read_bytes())["files"][name],name
    return path


def parent(name):
    return sealed(SECOND,PIN,name)


parent("second.py")
sys.path.insert(0,str(SECOND))
import second
from second import first, joint, old, Host, MatchedBank, History, CHANNELS, NAMES, N_IND, coefficients, adv
joint.window.ROOT=joint.common.ROOT=ROOT


def save(name,data):
    joint.safe()
    path=ROOT/name
    if path.exists():
        assert path.read_bytes()==data,name
    else:
        with path.open("xb") as stream:
            stream.write(data)


def record(name,data):
    save(name,(json.dumps(data,sort_keys=True,indent=2,allow_nan=False)+"\n").encode())


def freeze(name,files):
    record(name,{f:digest(ROOT/f) for f in files})


def locked(name):
    for file,signature in json.loads((ROOT/name).read_bytes()).items():
        assert digest(ROOT/file)==signature,file


def bounds(grid):
    with sealed(CYCLE,CYCLE_PIN,f"cycles-{grid}.csv").open() as stream:
        picks=[r for r in csv.DictReader(stream) if r["cycle"]=="2" and r["seed"]=="0"]
    assert len(picks)==1
    return float(picks[0]["begin"]),float(picks[0]["finish"])


def run(grid,sub,bank,hist):
    locked("protocol.json")
    host=Host(grid,sub)
    solver=old.Wave(host)
    start,end=bounds(grid)
    assert start==host.corners[-1] and end<host.t[-1]
    ticks=np.unique(np.r_[host.t[(host.t>=start)&(host.t<end)],end])
    assert ticks[0]==start and ticks[-1]==end
    host.focus=(start+end)/2
    with np.load(parent(f"second-{grid}-{sub}.npz")) as packet:
        assert packet["t"][-1]==start
        state=packet["final"];lag=packet["final_lag"];shape=packet["final_shape"];companion=packet["final_memory"]
        prior=packet["traces"];prior_obs=packet["obs"][-1]
        oldphase=prior[:,0,9].real
        assert np.all(prior[:,:,9]==oldphase[:,None]) and np.all(np.diff(oldphase)>0)
        assert packet["channels"].tolist()==list(CHANNELS) and np.array_equal(packet["q"],bank.q)
        routes=packet["routes"].tolist()
        assert routes==["comp_momentum","comp_density","null_momentum","null_density"]
        assert np.array_equal(companion,prior[-1][:,[1,3]]) and np.array_equal(state[:,12],prior_obs[:,2])
    with np.load(second.source(f"period-{grid}-{sub}.npz")) as older:
        tail=older["traces"]
        assert tail[-1,0,9]==oldphase[0] and older["routes"].tolist()==routes
        tail_history=CubicSpline(tail[:,0,9].real,tail[:,:,0],axis=0,extrapolate=False)
    route_history=CubicSpline(oldphase,prior[:,:,0],axis=0,extrapolate=False)
    original=state.copy();first_lag=lag.copy();entry_shape=shape.copy();entry_companion=companion.copy()
    origin=hist.angle(np.log(host.environment(host.t[:1])[0]["a"][0]))
    def phase_offset(t):
        scale=host.environment(np.atleast_1d(t))[0]["a"]
        return float(hist.angle(np.log(scale[0]))-origin-np.pi)
    cut=brentq(lambda t: phase_offset(t)-oldphase[0],start,ticks[1],xtol=2e-14)
    assert start<cut<ticks[1] and abs(phase_offset(cut)-oldphase[0])<1e-10
    assert abs(phase_offset(start)+np.pi-oldphase[-1])<1e-10
    assert tail_history.x[0]<phase_offset(start)<oldphase[0]<phase_offset(end)<=oldphase[-1]
    def lookup(phases,early):
        if early:
            assert np.max(phases)<=oldphase[0]+1e-10 and min(phases)>=tail_history.x[0]
            return tail_history(np.minimum(phases,oldphase[0]))
        assert min(phases)>=oldphase[0]-1e-10 and max(phases)<=oldphase[-1]
        return route_history(np.maximum(phases,oldphase[0]))
    scale=CubicSpline(ticks,host.environment(ticks)[0]["a"])
    time=np.r_[ticks[0],cut,ticks[1:]]
    enable=np.array([1.,1.,0.,0.])
    momentum_route=np.array([True,False,True,False])
    observations=np.empty((len(time),4,len(NAMES)),complex)
    traces=np.empty((len(time),4,len(CHANNELS)),complex)
    maxcheck=0.
    blocks=[(0,1,True)]+[(left,min(left+24,len(time)-1),False) for left in range(1,len(time)-1,24)]
    for left,right,early in blocks:
        joint.safe()
        edges=time[left:right+1]
        clock=np.empty(len(edges)*2-1)
        clock[::2]=edges
        clock[1::2]=(edges[:-1]+edges[1:])/2
        log=np.log(clock)
        vel,slow,kernel,weights=bank.coeff(clock)
        micro=bank.micro(log)
        shape_ext=bank.sw(log)
        mat,bi,bn=old.operator(solver,clock,clock)
        mat[:,:13,old.QI]+=bi
        mat[:,:13,old.QN]+=bn
        op=mat[:,:,:old.DIM].copy()
        bias=mat[:,:,-1].copy()
        bg,den,we,wj,e0,j0,slip0,us,fq=coefficients(host,clock)
        hub=bg["h"]
        kk=host.kk
        enu=bg["enu"]
        eg=bg["eg"]
        nus=4*bg["er"]+bg["nuS"]
        rho=hist.rho0/bg["a"]
        rate_a=scale(clock,1)/scale(clock)
        angle=hist.angle(np.log(bg["a"]))-origin
        speed=hist.angle(np.log(bg["a"]),1)*rate_a
        delayed=lookup(angle-np.pi,early)
        vel_h=bg["hv"]
        acc_h=-2*hub*vel_h-(bg["a"]*bg["hm"])**2*bg["hb"]
        ext=host.external(log)[:,3]
        ext_rate=host.external(log,1)[:,3]/clock
        inject=np.zeros((len(clock),old.DIM))
        for idx,value in [(1,(4/3+bg["eb"]/eg)*kk),(4,host.wave/3),(6,kk),(8,bg["sv"]),(9,-(bg["a"]*bg["sm"])**2*bg["sb"]),(10,vel_h),(11,-(bg["a"]*bg["hm"])**2*bg["hb"]),(12,-hub)]:
            inject[:,idx]=value

        def rates(idx,fields,bins,spectral,memory,observe=False):
            nonlocal maxcheck
            stress=bank.stress(bins,spectral,kernel[idx],weights[idx])*enu[idx]
            stress[:,1]*=host.wave
            wave=(kk*vel_h[idx]*fields[:,10]+ext[idx])/rho[idx]
            delta=memory[:,0]-wave
            energy=fields@we[idx]+e0[idx]+stress[:,0]+enable*rho[idx]*memory[:,1]
            bare_current=fields@wj[idx]+j0[idx]+stress[:,1]
            cur=bare_current+enable*rho[idx]*delta
            energy_phi=(us[idx]-energy/2-1.5*hub[idx]*cur/kk)/den[idx]
            phi=np.where(momentum_route,fields[:,12],energy_phi)
            psi=phi+slip0[idx]+(stress[:,2]-eg[idx]*fields[:,old.QI]-nus[idx]*fields[:,old.QN])/kk
            pd=cur/(2*kk)-hub[idx]*psi+fq[idx]
            live=fields.copy()
            live[:,12]=phi
            dx=live@op[idx].T+bias[idx]+(stress[:,2]/kk)[:,None]*inject[idx]
            dx[:,12]+=(stress[:,1]+enable*rho[idx]*delta)/(2*kk)
            maxcheck=max(maxcheck,np.max(abs(dx[:,12]-pd))/max(np.max(abs(pd)),1e-90))
            mean_rate=speed[idx]*(wave-delayed[idx])/np.pi
            wave_rate=(kk*(acc_h[idx]*fields[:,10]+vel_h[idx]*dx[:,10])+ext_rate[idx])/rho[idx]+rate_a[idx]*wave
            delta_rate=mean_rate-wave_rate
            pres=(delta_rate+hub[idx]*delta)/kk
            edot=-delta-3*hub[idx]*pres
            if observe:
                const=lambda val:np.broadcast_to(val,phi.shape)
                return (np.stack([phi,energy_phi,fields[:,12],psi,pd,energy,cur,*[const(v) for v in (us[idx],den[idx],hub[idx])],*stress.T],axis=-1),
                        np.stack([wave,memory[:,0],delta,memory[:,1],pres,const(delayed[idx]),mean_rate,edot,delta_rate,const(angle[idx]),const(rho[idx]),rho[idx]*wave,bare_current-rho[idx]*wave],axis=-1))
            normal=live[:,N_IND].copy()
            normal[:,0]+=phi
            dl=bank.bin_rhs(bins,spectral,normal,psi,vel[idx],slow[idx],micro[idx])
            return dx,dl,adv(spectral,host.wave)+shape_ext[idx],np.stack([mean_rate,edot],axis=1)

        for offset,width in enumerate(np.diff(edges)):
            pos=2*offset
            values=(state,lag,shape,companion)
            observations[left+offset],traces[left+offset]=rates(pos,*values,True)
            one=rates(pos,*values)
            two=rates(pos+1,*[v+width*a/2 for v,a in zip(values,one)])
            three=rates(pos+1,*[v+width*a/2 for v,a in zip(values,two)])
            four=rates(pos+2,*[v+width*a for v,a in zip(values,three)])
            for v,a,b,c,d in zip(values,one,two,three,four):
                v+=width*(a+2*b+2*c+d)/6
        observations[right],traces[right]=rates(len(clock)-1,state,lag,shape,companion,True)
        if early:
            cut_left=traces[right].copy()
    assert maxcheck<.005 and np.isfinite(traces).all() and np.isfinite(observations).all() and np.isfinite(lag).all()
    assert (np.max(abs(lag-first_lag),axis=2)>0).all()
    assert np.array_equal(traces[0][:,[1,3]],entry_companion) and np.array_equal(observations[0,:,2],original[:,12])
    sel=np.searchsorted(time,ticks)
    assert np.array_equal(time[sel],ticks)
    stream=BytesIO()
    np.savez_compressed(stream,t=ticks,obs=observations[sel],traces=traces[sel],names=NAMES,channels=CHANNELS,
        q=bank.q,routes=routes,entry=original,entry_lag=first_lag,entry_shape=entry_shape,entry_memory=entry_companion,
        final=state,final_lag=lag,final_shape=shape,final_memory=companion,delay_cut=cut,
        cut_left=cut_left,cut_right=traces[1],cut_obs=observations[1],rhs_check=maxcheck)
    save(f"third-{grid}-{sub}.npz",stream.getvalue())
    print(grid,sub,len(ticks),"samples to",ticks[-1],flush=True)


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("action",choices=["init","run"])
    if parser.parse_args().action=="init":
        freeze("protocol.json",["PROTOCOL.md","third.py","score_third.py"])
        return
    locked("protocol.json")
    bank=MatchedBank()
    for grid in ("p16","p32"):
        hist=History(grid)
        for sub in (2,4):
            run(grid,sub,bank,hist)
    freeze("forecast-freeze.json",["protocol.json"]+[f"third-{grid}-{sub}.npz" for grid in ("p16","p32") for sub in (2,4)])


if __name__=="__main__":
    main()
