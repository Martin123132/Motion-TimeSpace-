from metric_work_io import *
from incident_prediction import primitive
from scipy.integrate import cumulative_simpson
from scipy.linalg import solve_banded
def predict(setting,io,ph):
    proj=ph.proj;gate=ph.gate;scale,eta,medium,_,_=proj.measure("heavy")
    with np.load(io.sealed(io.EXT,"incident-matched-16.npz")) as data:k=float(data["k"])
    with np.load(ph.track(ph.cell89.curve("p32","base"))) as data:dt=np.diff(data["eta"][-2:]).item()
    order,sub,stride=gate.transfer.prior.SETTINGS[setting]
    mesh=np.linspace(START,END,round((END-START)/dt)+1)
    axis=np.unique(np.r_[proj.base_axis(scale,eta,sub),mesh[::stride],START,END])
    lo,hi=np.searchsorted(axis,[START,END]);rates,nodes=proj.coefficients(axis,medium,k);at=nodes[lo:hi]
    band=proj.transfer.stages(order);depth=band.shape[-1]//2
    with np.load(io.sealed(io.CARRY,"photon-"+setting+".npz")) as packet:
        labels=packet["labels"].tolist();incoming=packet["hierarchy_at_exit"][:,2*len(labels):];early=packet["cumulative"][eta<=START]
        assert np.array_equal(scale,packet["scale"])

    ids=[];forces=[];initial=[];history=[]
    for grid in GRIDS:
        with np.load(io.sealed(io.CARRY,f"carry-matched-{grid}-4.npz")) as ar:entry=ar["obs"][-1,:2]
        with np.load(parent(f"fine/{grid}/carry-wave-{grid}-4.npz")) as ar:
            resolved=ph.source_piece(ar["t"],ar["obs"][:,1],1)(at)-ph.source_piece(ar["t"],ar["obs"][:,0],0)(at)
        with np.load(parent(f"matched-background-{grid}.npz")) as bg:
            clock=bg["t"]
        with np.load(pinned(HIST,f"carry-matched-{grid}-4.npz")) as archived:
            hub=CubicSpline(clock,archived["obs"][:,0,9].real)
        mom,den=entry;shear=(den[3]-den[0])-(mom[3]-mom[0]);current=den[6]-mom[6];c0=den[2]-mom[2]
        d,m=[labels.index(f"{grid}-4-comp_{route}") for route in ("density","momentum")]
        for model in MODELS:
            for count in (960,1920):
                with np.load(ROOT/f"incident-{grid}-{model}-{count}.npz") as pred:
                    t=pred["t"];r=pred["predicted"];h=hub(t);fac=np.exp(cumulative_simpson(h,x=t,initial=0))
                    c=(c0+primitive(fac*(current/(2*k*k)+h*(r-shear)),t))/fac
                    lapse=c-r+shear
                    potential_rate=make_interp_spline(t,pred["b"],k=5)(at,1)-make_interp_spline(t,pred["rf"],k=5)(at)+current/(2*k*k)-hub(at)*CubicSpline(t,lapse)(at)
                    drive=np.stack((potential_rate,CubicSpline(t,lapse)(at)),axis=-1)
                    for which in ("matched","full"):
                        ids.append(f"{grid}:{model}:{count}:{which}")
                        initial.append(incoming[:,d]-incoming[:,m] if which=="full" else np.zeros(depth,complex))
                        history.append(early[:,d]-early[:,m] if which=="full" else np.zeros_like(early[:,d]))
                        forces.append(drive-resolved if which=="full" else drive)
    force=np.stack(forces,axis=2);state0=np.stack(initial,axis=1);count=len(ids)
    work=np.diff(axis)[lo:hi,None,None,None]*np.einsum("st,ntch->nsch",proj.RAD,force)
    state=np.empty((depth,2*count));state[:,::2]=state0.real;state[:,1::2]=state0.imag
    rhs=np.empty((2*depth,2*count),order="F");slots=np.full(len(axis),-1);pos=np.searchsorted(axis,eta)
    assert np.array_equal(axis[pos],eta);slots[pos]=np.arange(len(eta))
    obs=np.zeros((len(eta),count,2),complex);obs[eta<=START]=np.stack(history,axis=1)
    for first in range(lo,len(rates),48):
        guard();last=min(first+48,len(rates));mat=(rates[first:last].reshape(-1,8)@band.reshape(8,-1)).reshape(-1,11,2*depth);mat[:,5]+=1
        for idx,matrix in enumerate(mat,first):
            rhs[::2]=state;rhs[1::2]=state
            if idx<hi:
                for row,col,factor in ((0,0,4.),(2,1,4*k/3),(4,1,4*k/3)):
                    value=factor*work[idx-lo,:,:,col];rhs[row:row+2,::2]+=value.real;rhs[row:row+2,1::2]+=value.imag
            state=solve_banded((5,5),matrix,rhs,check_finite=False)[1::2]
            if slots[idx+1]>=0:obs[slots[idx+1]]=(state[[0,2],::2]+1j*state[[0,2],1::2]).T
    assert np.isfinite(obs).all()

    pack("incident-photon-vectors.npz",labels=ids,scale=scale,values=obs)
def main():
    check("incident-forecast.json");io,*_=saved.prior.setup_modules()
    import project90
    ph=project90.modules()
    inputs=[ROOT/"INCIDENT-PHOTONS.md",ROOT/"incident_photons.py",ROOT/"incident-forecast.json"]
    for grid in GRIDS:
        inputs.extend((io.sealed(io.CARRY,f"carry-matched-{grid}-4.npz"),parent(f"fine/{grid}/carry-wave-{grid}-4.npz"),pinned(HIST,f"carry-matched-{grid}-4.npz"),parent(f"matched-background-{grid}.npz")))
    record("reduced-method.json",inputs);predict("primary",io,ph)
    record("reduced-forecast.json",[ROOT/"reduced-method.json",ROOT/"incident-photon-vectors.npz"])
    check("reduced-forecast.json");check("scores-freeze.json");check("rate-freeze.json");gate=ph.gate
    _,vis,w,_=ph.proj.old.get_media();measure=gate.previous.make_measure(vis,w);norm=lambda v:gate.mag(v,measure)
    with np.load(ROOT/"incident-photon-vectors.npz") as pr,np.load(ROOT/"rate-vectors.npz") as rate,np.load(ROOT/"visibility-primary.npz") as full,np.load(ph.track(ph.cell89.pin("photon-primary.npz"))) as pre:
        ev=lambda val:CubicSpline(pr["scale"],val)(vis);pred=ev(pr["values"]);ca=ev(rate["values"]);fa=ev(full["values"]);scores={}
        for grid in GRIDS:
            small=norm(ev(pre["values"][:,pre["labels"].tolist().index([grid,"primary"]),:3].sum(1)))
            for model in MODELS:
                for which in ("matched","full"):
                    if which=="matched":target=ca[:,rate["labels"].tolist().index(grid+":"+model+":direct")]
                    else:
                        get=lambda route:fa[:,full["labels"].tolist().index(":".join((grid,model,"joined-fine",route,"cumulative")))]
                        target=get("density")-get("momentum")
                    cols=[]
                    for count in (960,1920):
                        key=f"{grid}:{model}:{count}:{which}";vec=pred[:,pr["labels"].tolist().index(key)];cols.append(vec)
                        scores[key]=dict(gap_pct=(100*norm(vec)/small).tolist(),actual_pct=(100*norm(target)/small).tolist(),own_error_pct=(100*norm(vec-target)/norm(target)).tolist())
                    scores[key]["quadrature_change_pct_target"]=(100*norm(cols[1]-cols[0])/norm(target)).tolist()
    put("reduced-scores.json",scores);record("reduced-freeze.json",[ROOT/"reduced-forecast.json",ROOT/"scores-freeze.json",ROOT/"rate-freeze.json",ROOT/"reduced-scores.json"])
    print({key:row["own_error_pct"][-1] for key,row in scores.items() if ":1920:" in key},flush=True)
if __name__=="__main__":main()
