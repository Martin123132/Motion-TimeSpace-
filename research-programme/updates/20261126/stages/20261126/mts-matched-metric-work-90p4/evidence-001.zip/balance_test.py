from metric_work_io import *
from scipy.integrate import cumulative_simpson

def integral(values,time):
    return cumulative_simpson(values.real,x=time,axis=0,initial=0)+1j*cumulative_simpson(values.imag,x=time,axis=0,initial=0)
def peak(values):return np.max(abs(values),axis=0)
def metrics(model,grid,wave):
    out=folder(model,grid);saved.prior.check(out/"done.json")
    with np.load(out/f"carry-matched-{grid}-4.npz") as ar,np.load(out/"stress.npz") as st:
        t=ar["t"];obs=ar["obs"][:,:2];names=st["keys"].tolist()
        X,Y,em,current,press,dp,W,alpha,rho=st["values"][:,:2].transpose(2,0,1)
        assert names==["normal","physical","Em","Jm","Pm","deltaP","W","alpha","rho"]
        H=obs[:,:,9].real;phi=obs[:,:,0];psi=obs[:,:,3];K=wave**2
        phi_rate=make_interp_spline(t,phi,k=5)(t,1);phi_rate[:,0]=obs[:,0,4]
        decay=np.exp(cumulative_simpson(H,x=t,axis=0,initial=0))
        clock=(H-alpha) if model=="metric" else 0*H
        stress=em+Y
        def solve(initial,source,power):
            return (initial+integral(source*decay**power,t))/decay**power
        sy=3*W*(phi_rate+H*psi)-clock*(em+3*H*current/K)
        y=solve(Y[:1],sy,1);energy=solve(stress[:1],3*W*phi_rate-3*H*(press+dp)-current,1)
        momentum=solve(current[:1],K*(press+dp+W*psi),2)
        es=max(1e-90,float(np.max(abs(stress-stress[:1]))));js=max(1e-90,float(np.max(abs(current-current[:1]))))
        normal=lambda val,sc:(100*peak(val)/sc).tolist()
        ye=peak(Y-Y[:1]);assert model=="disabled" or np.all(ye>0)
        stats=dict(energy_error_pct_per_route=normal(energy-stress,peak(stress-stress[:1])),
                   current_error_pct_per_route=normal(momentum-current,peak(current-current[:1])),
                   incremental_physical_energy_error_pct=normal(y-Y,np.maximum(1e-90,ye)),
                   coordinate_reconstruction_pct=normal(X+3*W*phi-Y,es),
                   missing_energy_work_pct=normal(solve(stress[:1],-3*H*(press+dp)-current,1)-stress,peak(stress-stress[:1])),
                   missing_momentum_work_pct=normal(solve(current[:1],K*(press+dp),2)-current,peak(current-current[:1])),
                   stress_peak=[es,js])
        assert max(stats["energy_error_pct_per_route"]+stats["current_error_pct_per_route"]+stats["incremental_physical_energy_error_pct"])<.5,stats
        pack("balance-"+model+"-"+grid+".npz",time=t,pred_energy=energy,pred_current=momentum,pred_Y=y)
    return stats

def main():
    check("gravity-forecast.json");io,*_=saved.prior.setup_modules()
    with np.load(io.sealed(io.EXT,"incident-matched-16.npz")) as ar:wave=float(ar["k"])
    stats={model+":"+grid:metrics(model,grid,wave) for model in MODELS for grid in GRIDS}
    put("balance-scores.json",stats)
    record("balance-freeze.json",[ROOT/"DERIVATION.md",ROOT/"balance_test.py",ROOT/"gravity-forecast.json",ROOT/"balance-scores.json",*sorted(ROOT.glob("balance-*.npz"))])
    print(stats,flush=True)
if __name__=="__main__":main()
