from metric_work_io import *
from scipy.integrate import cumulative_simpson
def integral(values,t):
    return cumulative_simpson(values.real,x=t,axis=0,initial=0)+1j*cumulative_simpson(values.imag,x=t,axis=0,initial=0)
def main():
    guard();io,s,_,_,p=engine();inputs=[ROOT/"CONSTRAINT-WORK.md",ROOT/"passive_prediction.py",ROOT/"DERIVATION.md",JOIN/"seal.json"]
    for grid in GRIDS:
        base=pinned(HIST,f"carry-matched-{grid}-4.npz");hom=parent(f"matched-background-{grid}.npz");inputs.extend([base,hom])
        with np.load(base) as old,np.load(hom) as bg:
            t=old["t"];assert np.array_equal(t,bg["t"]);obs=old["obs"][:,0];H=obs[:,9].real;D=obs[:,8].real;W=-bg["enthalpy"];rho=bg["rho"]
            mem=old["memories"][:,0];Em=rho*mem[:,1];Jm=rho*(mem[:,0]-old["physical_current_phase"][:,0,0])
            K=float(p.joint.Bank().k**2);clock=H+make_interp_spline(t,rho,k=5)(t,1)/rho
            src=3*W*(obs[:,4]+H*obs[:,3])-clock*(Em+3*H*Jm/K)
            factor=np.exp(cumulative_simpson(H,x=t,initial=0))
            Y=integral(factor*src,t)/factor
            C=D*(obs[:,2]-obs[:,1]);pred=C+Y/2
        pack("passive-"+grid+".npz",t=t,C=C,Y=Y,C_pred=pred,r_pred=pred/(D+1.5*W))
    record("passive-forecast.json",inputs+[ROOT/("passive-"+g+".npz") for g in GRIDS])
if __name__=="__main__":main()
