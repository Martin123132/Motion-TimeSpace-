from metric_work_io import *
from scipy.integrate import cumulative_simpson
def primitive(value,t):
    return cumulative_simpson(value.real,x=t,axis=0,initial=0)+1j*cumulative_simpson(value.imag,x=t,axis=0,initial=0)
def coeff(p,src,mem,bank,t,enabled,test):
    log=np.log(t);K=src.kk;k=src.wave;beta0=1.5/K
    bg,D,we,wj,e0,j0,slip,U,Fq=p.coefficients(src,t)
    H=bg["h"];beta=beta0*H;a=bg["a"];v=bg["hv"];rho=mem.rho0/a
    alpha=src.flow.bg(log,1)[:,src.flow.bgkeys.index("a")]/(t*a)
    ext=src.external(log)[:,3];extp=src.external(log,1)[:,3]/t
    W=(rho-v*v)*enabled;acc=-2*H*v-(a*bg["hm"])**2*bg["hb"];Wp=(-alpha*rho-2*v*acc)*enabled
    D=D+1.5*W
    J0=j0-ext;b=(U-e0/2-beta*J0)/D;psi=b+slip;pd=J0/(2*K)-H*psi+Fq
    solver=p.old.Wave(src);env=solver.env(t,t);state=np.zeros((len(t),13),complex);state[:,12]=b
    dx=solver.rhs(env,state)
    vel,slow,kernel,weights=bank.coeff(t);micro=bank.micro(log);sw=bank.sw(log)
    energy=bg["enu"]*(np.sum(kernel[:,0]*micro[:,:,0],axis=1)+weights[:,0]*sw[:,0])
    bin1=micro[:,:,1]+(k/3)*slow*(b[:,None]-psi[:,None]/vel)
    current=bg["enu"]*k*(np.sum(kernel[:,1]*bin1,axis=1)+weights[:,1]*sw[:,1])
    field=np.sum(dx*we[:,:13],axis=1)/2+beta*np.sum(dx*wj[:,:13],axis=1)
    comp=ext/2+beta*(extp+(alpha+H)*ext)
    xp=3*H*W*psi-3*(Wp+H*W)*b+enabled*(H-alpha)*3*H*ext/K
    total=pd+(field+comp+xp/2+energy/2+beta*current)/D
    errors=[]
    if test:
        mat,bi,bn=p.old.operator(solver,t,t);mat[:,:13,p.old.QI]+=bi;mat[:,:13,p.old.QN]+=bn
        for i in range(len(t)):
            full=np.zeros(p.old.DIM,complex);full[12]=b[i]
            deriv=mat[i,:,:-1]@full+mat[i,:,-1];deriv[12]-=ext[i]/(2*K)
            normal=np.zeros((1,69),complex);normal[0,0]=b[i]
            dl=bank.bin_rhs(np.zeros((1,77,69),complex),np.zeros((1,69),complex),normal,psi[i:i+1],vel[i],slow[i],micro[i])
            bins=bank.stress(dl,sw[i:i+1],kernel[i],weights[i])[0]*bg["enu"][i]
            rho_i=rho[i];raw=ext[i]/rho_i;rawdot=(K*v[i]*deriv[10]+extp[i])/rho_i+alpha[i]*raw
            for mdot in (0j,0.7j*max(abs(rawdot),1e-90)):
                pm=(mdot-rawdot-H[i]*raw)/K;edot=raw-3*H[i]*pm
                e=we[i]@deriv+bins[0]+rho_i*edot+xp[i]
                j=wj[i]@deriv+k*bins[1]+rho_i*mdot-K*v[i]*deriv[10]
                rf=deriv[12]+(e/2+beta[i]*j)/D[i]
                errors.append(float(abs(rf-total[i])/max(abs(total[i]),abs(pd[i]),1e-90)))
    return total,b,errors

def prep():
    io,s,_,_,p=engine();inputs=[ROOT/"INCIDENT-TEST.md",ROOT/"incident_prediction.py",ROOT/"method.json"];audit={}
    for grid in GRIDS:
        def confirm(name,**val):
            with np.load(pinned(HIST,name)) as ar:
                for key,value in val.items():np.testing.assert_array_equal(value,ar[key])
        bank=p.MatchedBank()
        with patch.object(s,"pack",confirm):src,hist=s.setup(p,grid,4,"matched",bank)
        control=io.sealed(io.CARRY,f"carry-matched-{grid}-4.npz");inputs.append(control)
        with np.load(control) as ar:
            launch=ar["obs"][-1,1];r0=launch[2]-launch[0]
        for model in MODELS:
            active=int(model=="metric");tag=grid+":"+model
            _,_,checks=coeff(p,src,hist,bank,np.linspace(START+.001,END-.001,9),active,True)
            assert max(checks)<1e-8,checks;audit[tag]=max(checks)
            for count in (960,1920):
                t=np.linspace(START,END,count+1);rows=[coeff(p,src,hist,bank,t0,active,False)[:2] for t0 in np.array_split(t,1+len(t)//64)]
                rf,b=[np.concatenate(values) for values in zip(*rows)];r=r0+primitive(rf,t)-(b-b[0])
                pack(f"incident-{grid}-{model}-{count}.npz",t=t,rf=rf,b=b,predicted=r)
    put("incident-operator-checks.json",audit)
    record("incident-forecast.json",inputs+[ROOT/"incident-operator-checks.json",*sorted(ROOT.glob("incident-*.npz"))])
def score():
    check("incident-forecast.json");check("gravity-forecast.json");scores={}
    for grid in GRIDS:
        for model in MODELS:
            folder0=folder(model,grid)
            with np.load(folder0/f"carry-matched-{grid}-4.npz") as run,np.load(ROOT/f"incident-{grid}-{model}-960.npz") as coarse,np.load(ROOT/f"incident-{grid}-{model}-1920.npz") as fine:
                r=run["obs"][:,1,2]-run["obs"][:,1,0];truth=CubicSpline(run["t"],r)(fine["t"])
                delta=lambda v:v-v[0];true=delta(truth);pred=delta(fine["predicted"]);scale=np.max(abs(true))
                error=lambda v:float(100*np.max(abs(v))/scale)
                stats=dict(drift_prediction_error_pct=error(pred-true),predicted_drift_pct=error(pred),quadrature_change_pct=error(delta(coarse["predicted"])-pred[::2]),
                    complex_overlap=float(np.vdot(true,pred).real/np.vdot(true,true).real),drift_scale=float(scale),launch_mismatch_pct=error(fine["predicted"][0]-truth[0]))
                assert stats["quadrature_change_pct"]<.5,stats
                scores[grid+":"+model]=stats
    put("incident-scores.json",scores);record("incident-freeze.json",[ROOT/"incident-forecast.json",ROOT/"gravity-forecast.json",ROOT/"incident-scores.json"])
    print(scores,flush=True)
if __name__=="__main__":prep();score()
