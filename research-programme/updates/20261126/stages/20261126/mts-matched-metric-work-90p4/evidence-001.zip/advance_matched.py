from metric_work_io import *
parent("matched_background.py")
def run(io,sources,step,runner,p,model,grid):
    import matched_work_step as stage
    out=folder(model,grid);out.mkdir(parents=True,exist_ok=True)
    initial=io.sealed(io.CARRY,f"carry-matched-{grid}-4.npz")
    record(out.relative_to(ROOT)/"method.json",[ROOT/"method.json",initial,pinned(HIST,"evolve90.py"),pinned(HIST,"sources90.py"),pinned(HIST,"stepper.py")])
    bank=p.MatchedBank()
    def confirm(name,**values):
        with np.load(pinned(HIST,name)) as ref:
            assert values.keys()==set(ref.files)
            for key in values:np.testing.assert_array_equal(values[key],ref[key])
    with ExitStack() as scope:
        for mod in (runner,stage):
            for name,val in (("ROOT",out),("pack",lambda name,**data:saved.prior.pack(out/name,**data)),("guard",guard)):
                scope.enter_context(patch.object(mod,name,val))
        scope.enter_context(patch.object(sources,"pack",confirm))
        scope.enter_context(patch.object(stage,"enabled_model",model))
        scope.enter_context(patch.object(runner,"evolve",stage.evolve))
        scope.enter_context(patch.object(runner,"freeze",lambda name,keys:saved.prior.record(out/name,[out/key for key in keys])))
        scope.enter_context(patch.object(runner,"check",lambda name:saved.prior.check(out/name)))
        scope.enter_context(patch.object(runner,"put",lambda name,val:saved.prior.put(out/name,val)))
        runner.branch(p,grid,4,"matched",bank)
    parts=sorted(out.glob("*.npz.receipt"));assert len(parts)==15
    stats={};extras=[];priorpath=initial;compare=slice(None) if model=="disabled" else slice(2,4)
    for idx in range(1,16):
        fname=f"part-matched-{grid}-4-{idx:02d}.npz";path=out/fname
        with np.load(path) as cur,np.load(pinned(HIST,fname)) as old:
            assert cur["parent_hash"].item()==sha(priorpath)
            for key in ("final","final_lag","final_memory","obs","physical_current_phase","memories","final_shape"):
                axis=1 if key in ("obs","physical_current_phase","memories") else 0
                val=cur[key];ref=old[key]
                if key!="final_shape":
                    slices=[slice(None)]*val.ndim;slices[axis]=compare;val=val[tuple(slices)];ref=ref[tuple(slices)]
                err=float(np.max(abs(val-ref))/max(np.max(abs(ref)),1e-90))
                stats[key]=max(stats.get(key,0.),err)
            assert cur["physical_seam"]<.5 and cur["rhs_identity_pct"]<.5
            extras.append(cur["extra_series"][int(idx>1):]);keys=cur["extra_keys"]
        priorpath=path
    assert max(stats.values())<1e-10,stats
    saved.prior.pack(out/"stress.npz",values=np.concatenate(extras),keys=keys)
    saved.prior.put(out/"control.json",stats)
    record(out.relative_to(ROOT)/"done.json",[out/"method.json",*parts,out/f"carry-matched-{grid}-4.npz",out/"stress.npz",out/"control.json",out/f"history-matched-{grid}-4.json"])

def main():
    guard();io,s,st,r,p=engine()
    record("method.json",[ROOT/"DERIVATION.md",ROOT/"PROTOCOL.md",ROOT/"metric_work_io.py",ROOT/"advance_matched.py",ROOT/"matched_work_step.py",JOIN/"seal.json",parent("matched-freeze.json")])
    for model in MODELS:
        for grid in GRIDS:
            done=folder(model,grid)/"done.json"
            if not done.exists():run(io,s,st,r,p,model,grid)
            saved.prior.check(done)
    record("gravity-forecast.json",[ROOT/"method.json",*[folder(model,grid)/"done.json" for model in MODELS for grid in GRIDS]])
if __name__=="__main__":main()
