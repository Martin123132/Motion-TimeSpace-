from metric_work_io import *
def main():
    check("passive-forecast.json");check("gravity-forecast.json");io,s,_,_,p=engine()
    scores={};paths=[]
    for grid in GRIDS:
        def confirm(name,**values):
            with np.load(pinned(HIST,name)) as ar:
                for key,value in values.items():np.testing.assert_array_equal(value,ar[key])
        with patch.object(s,"pack",confirm):src,history=s.setup(p,grid,4,"matched",p.MatchedBank())
        original=pinned(HIST,f"carry-matched-{grid}-4.npz");paths.append(original)
        out=folder("metric",grid)
        with np.load(ROOT/("passive-"+grid+".npz")) as pre,np.load(original) as old,np.load(out/f"carry-matched-{grid}-4.npz") as new,np.load(out/"stress.npz") as stress:
            t=pre["t"];assert np.array_equal(t,new["t"]);o=old["obs"][:,0];n=new["obs"][:,0];K=src.kk
            fq=np.concatenate([p.coefficients(src,t[j:j+256])[-1] for j in range(0,len(t),256)])
            left=o[:,4]+o[:,9]*o[:,3];right=o[:,6]/(2*K)+fq
            left_active=n[:,4]+n[:,9]*n[:,3];right_active=n[:,6]/(2*K)+fq
            mask=lambda x:np.max(abs(x))
            ratio=lambda x,y:float(100*mask(x)/max(mask(y),1e-95))
            C=n[:,8]*(n[:,2]-n[:,1]);forecast=pre["C_pred"];C0=pre["C"];scale=C0-C0[0]
            Y=stress["values"][:,0,stress["keys"].tolist().index("physical")]
            normdiff=lambda x:x-x[0];effect=normdiff(C-C0)
            stats=dict(momentum_source_identity_pct=ratio(left-right,right),new_momentum_source_identity_pct=ratio(left_active-right_active,right_active),
                       new_constraint_drift_pct_original=ratio(normdiff(C),scale),passive_constraint_drift_pct_original=ratio(normdiff(forecast),scale),
                       passive_effect_error_pct_of_actual_effect=ratio(normdiff(forecast-C),effect),
                       other_state_response_pct_original=ratio(normdiff(C-C0-Y/2),scale),
                       self_consistent_Y_change_pct=ratio(Y-pre["Y"],Y),
                       launch_numerator_shift_pct_old_drift=ratio(C[0]-C0[0],scale),peak_drift_original=float(mask(scale)),peak_drift_new=float(mask(normdiff(C))))
            assert max(stats["momentum_source_identity_pct"],stats["new_momentum_source_identity_pct"])<1e-7
            pack("constraint-score-"+grid+".npz",t=t,corrected=C,source_only=forecast,original=C0,actual_direct=Y/2)
            scores[grid]=stats
    put("constraint-scores.json",scores);record("constraint-freeze.json",[ROOT/"constraint_score.py",ROOT/"passive-forecast.json",ROOT/"gravity-forecast.json",ROOT/"constraint-scores.json",*paths,*[ROOT/("constraint-score-"+g+".npz") for g in GRIDS]])
    print(scores,flush=True)
if __name__=="__main__":main()
