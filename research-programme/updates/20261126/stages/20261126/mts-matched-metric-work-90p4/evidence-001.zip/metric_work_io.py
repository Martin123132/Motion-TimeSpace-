from pathlib import Path
import hashlib
import sys
import json
from contextlib import ExitStack
from unittest.mock import patch

ROOT=Path(__file__).resolve().parent
BASE=ROOT.parent
JOIN=BASE/"mts-coupled-background-photons-90p4-20261126"
SIGNATURE="d1eb1bdbdb48787871512452e015a57759013f023d3a8fa4a8ac5736f2258da2"
def sha(path):
    with path.open("rb") as stream:return hashlib.file_digest(stream,"sha256").hexdigest()
def parent(name):
    assert sha(JOIN/"seal.json")==SIGNATURE
    file=JOIN/name;assert sha(file)==json.loads((JOIN/"seal.json").read_bytes())["files"][name]
    return file
parent("wave_join_io.py")
sys.path.insert(0,str(JOIN))
import wave_join_io as saved
from wave_join_io import np, CubicSpline, make_interp_spline, HIST, GRIDS, START, END, engine, pinned
MODELS=("disabled","metric")
def guard():
    saved.ensure();assert not (ROOT/"STOP-REQUESTED").exists()
def put(name,value):
    guard();saved.prior.put(ROOT/name,value)
def pack(name,**value):
    guard();saved.prior.pack(ROOT/name,**value)
def record(name,files):
    guard();saved.prior.record(ROOT/name,files)
def check(name):
    guard();saved.prior.check(ROOT/name)
def read(name):return saved.prior.obj(ROOT/name)
def folder(model,grid):return ROOT/model/grid
