from metric_work_io import *
import ast
def main():
    guard();assert sha(JOIN/"seal.json")==SIGNATURE
    for folder0,signature in saved.PINS.items():assert sha(folder0/"seal.json")==signature
    for module in ROOT.glob("*.py"):ast.parse(module.read_text("utf8"))
    assert not list(ROOT.rglob("*.partial")) and not list(ROOT.rglob("__pycache__"))
    receipts=0
    for path in ROOT.rglob("*"):
        if path.is_file() and (path.name.endswith(("-freeze.json","-forecast.json","-method.json",".receipt")) or path.name in ("method.json","done.json")):
            saved.prior.check(path);receipts+=1
    scores=read("photon-scores.json");assert len(scores)==24
    io,*_=saved.prior.setup_modules()
    for grid in GRIDS:
        for model in MODELS:
            flag=slice(None) if model=="disabled" else slice(2,4);out=folder(model,grid);prev=io.sealed(io.CARRY,f"carry-matched-{grid}-4.npz")
            for index in range(1,16):
                name=f"part-matched-{grid}-4-{index:02d}.npz";path=out/name
                with np.load(path) as packet,np.load(pinned(HIST,name)) as old:
                    assert packet["parent_hash"].item()==sha(prev) and np.array_equal(packet["t"][[0,-1]],io.edges[index-1:index+1])
                    assert packet["final_lag"].shape==(4,77,69) and np.isfinite(packet["extra_series"]).all()
                    assert np.array_equal(packet["obs"][:,flag],old["obs"][:,flag]) and np.array_equal(packet["final_lag"][flag],old["final_lag"][flag])
                    assert packet["physical_seam"]<.5 and packet["rhs_identity_pct"]<.5
                    if index==1:
                        assert np.array_equal(packet["obs"][0,:,2],old["obs"][0,:,2]) and np.max(abs(packet["extra_series"][0,:,1]))<1e-12*np.max(abs(old["obs"][0,:,5]))
                    else:
                        with np.load(prev) as before:assert np.array_equal(packet["extra_series"][0,:,0],before["final_excess"])
                prev=path
            with np.load(prev) as packet,np.load(out/f"carry-matched-{grid}-4.npz") as final:
                for key in ("final","final_lag","final_memory","final_shape","final_excess"):assert np.array_equal(final[key],packet[key])
            row=read("balance-scores.json")[model+":"+grid]
            assert max(row["energy_error_pct_per_route"]+row["current_error_pct_per_route"]+row["incremental_physical_energy_error_pct"])<.5
        for key,row in scores.items():
            if key.split(":")[1]==grid:assert row["passed"]==(max(row["gap_pct"])<=.5 and max(row["full_launch_pct"])<=.163)
        for model in MODELS:
            assert max(read("rate-scores.json")[grid+":"+model]["closure_points"])<1e-5
            for count in (960,1920):
                with np.load(ROOT/f"incident-{grid}-{model}-{count}.npz") as proj:
                    assert len(proj["t"])==count+1 and np.isfinite(proj["predicted"]).all()
                reduced=read("reduced-scores.json")[f"{grid}:{model}:{count}:full"]
                np.testing.assert_allclose(reduced["actual_pct"],scores[f"primary:{grid}:{model}:joined-fine"]["gap_pct"],rtol=1e-9,atol=0)
            with np.load(folder(model,grid)/f"carry-matched-{grid}-4.npz") as orbit,np.load(ROOT/f"incident-{grid}-{model}-1920.npz") as projected:
                obs=orbit["obs"][:,1];ref=CubicSpline(orbit["t"],obs[:,2]-obs[:,0])(projected["t"])
                delta=lambda v:v-v[0]
                err=100*np.max(abs(delta(projected["predicted"])-delta(ref)))/np.max(abs(delta(ref)))
                np.testing.assert_allclose(err,read("incident-scores.json")[grid+":"+model]["drift_prediction_error_pct"])
    for name in ("RESULTS.md","DERIVATION.md","PROTOCOL.md","CONSTRAINT-WORK.md","balance-freeze.json","constraint-freeze.json","scores-freeze.json","rate-freeze.json","incident-freeze.json","reduced-freeze.json"):assert (ROOT/name).is_file()
    files={path.relative_to(ROOT).as_posix():sha(path) for path in ROOT.rglob("*") if path.is_file() and path.name!="seal.json"}
    data=dict(files=files,parents={JOIN.name:SIGNATURE,**{p.name:s for p,s in saved.PINS.items()}},scope="Matched scalar metric work at fixed incoming physical energy/current and fixed incident quadratic forces; 89.65–90.4 conformal Mpc")
    if sys.argv[1:]==["--seal"]:put("seal.json",data)
    assert read("seal.json")==data
    print(len(files),"files,",receipts,"receipts, 60 tile chains/links and four incoming states checked;",sha(ROOT/"seal.json"))
if __name__=="__main__":main()
