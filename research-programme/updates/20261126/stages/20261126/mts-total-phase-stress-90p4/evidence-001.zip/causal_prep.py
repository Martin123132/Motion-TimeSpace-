from data_io import *
from scipy.interpolate import make_interp_spline,CubicSpline
from scipy.integrate import solve_ivp
from types import SimpleNamespace
pin(PREV,'project_feedback.py');sys.path.insert(0,str(PREV))
from project_feedback import kin,spatial,contract,signed

ANCHOR=89.65

def weights(n):
    u=np.pi*(.5+np.arange(n));w=np.ones(n)
    for j in range(n):
        other=np.arange(n)!=j;w[j]=np.prod(u[other]/(u[other]-u[j]))
    for power in range(n):assert abs(w@(-u)**power-(1 if power==0 else 0))<1e-9
    return u,w
def quadrature(spline,phase,n):
    u,w=weights(n)
    return np.tensordot(w*(-1.)**(1+np.arange(n)),spline(phase-u),axes=1)

def calculate(res):
    original=read(ROOT/f'first-{res}.npz')
    t=original['t'];phase=CubicSpline(t,original['bg'][0]).antiderivative()(t);phase-=phase[0]
    anchor=np.flatnonzero(t==ANCHOR).item();valid=(phase-phase[0]>6*np.pi)&(phase[-1]-phase>6*np.pi);target=np.flatnonzero(valid & (np.rint(t*res).astype(int)%(res//320)==0))
    ts=t[anchor:target[-1]+1];ti=np.searchsorted(ts,t[target])
    clock=read(signed(f'coupled-matched-{res}.npz'));k=clock['k'];par=kin.initial('matched');hist=kin.audit_sources.load_native('matched',before=CUT)
    cols=clock['keys'].tolist();bank=clock['values'][:,[cols.index(key) for key in ('X','k_sigma','pir','S','pig')]]
    def geom(tt):
        dt=tt-CUT;coef=par.h0**2-par.pressure;fac=1+par.h0*dt+coef*dt**2/4
        return fac,par.m*par.a0*fac,(par.h0+coef*dt/2)/fac
    drive=make_interp_spline(clock['t'],bank[:,0],k=5)
    def rhs(tt,y):
        _,om,h=geom(tt);b,v,f,w=y.reshape(4,-1);return np.stack((v,-2*h*v-om**2*b,w,-2*h*w-(om**2+k*k)*f-v*drive(tt))).ravel()
    seed=read(kin.pin('clock-inputs.npz'))['local_at_cut'][:4]
    def solve(lo,hi,y,clockt):
        result=solve_ivp(rhs,(lo,hi),y.ravel(),t_eval=clockt,rtol=1e-12,atol=2e-25,max_step=1/res,method='DOP853')
        assert result.success;return result.y.T.reshape(len(clockt),4,-1)
    real=solve(CUT,ts[-1],seed,t[:target[-1]+1]);early=make_interp_spline(phase[:anchor+1],real[:anchor+1],k=5)
    shell=np.array(json.loads(spatial.pin('legs.json').read_bytes())['squared_radii'])
    basis=SimpleNamespace(nodes=k,shell=shell,first={});raw=spatial.Project(basis).ops[0]
    fac,om,hh=geom(ts[:,None]);x,sk,pir,shear,pig=make_interp_spline(clock['t'],bank,k=5)(ts).transpose(1,0,2)
    eta=make_interp_spline(clock['t'],(bank[:,1]-bank[:,0])/3,k=5).antiderivative()
    alpha=sk/k**2;phi=hist.data['etak'][-1]/k+eta(ts)-eta(CUT)-hh*alpha
    psi=phi-((par.weights[2]*pig+par.weights[3]*pir)/fac**2+1.5*shear)/k**2
    pd=(sk-x)/3+(3*hh**2+par.pressure/fac**2)*alpha/2-hh*psi
    def evaluate(y):
        b,v,f,w=y.transpose(1,0,2);fg=f+v*alpha;n=w+(-3*hh*v-om**2*b)*alpha
        fields=dict(f=fg,n=n,u=n-3*v*phi,phi=phi,psi=psi,fd=n+v*psi,nd=-2*hh*n-(om**2+k**2)*fg-om**2*b*psi+3*v*pd)
        basis.first={key:value.T for key,value in fields.items()};return contract(spatial.Fast(raw,basis),lambda method,l,r:method(l,r),b[:,0],v[:,0],om[:,0]**2)
    qr=original['q'][0,:,anchor:target[-1]+1]
    second={grid:read(ROOT/f'driven-{grid}-{res}.npz') for grid in ('p16','p32')}
    freeze=[]
    for samples in (1,2,3,4):
        guard();assert phase[anchor]-weights(samples)[0][-1]>0
        partner=solve(ANCHOR,ts[-1],quadrature(early,phase[anchor],samples),ts)
        qq=evaluate(partner);qd=evaluate((partner+real[anchor:])/np.sqrt(2))
        bq,vq=partner[:,:2,0].T;b,v=real[anchor:,:2,0].T
        for grid,archive in second.items():
            physical=archive['state'][0];pot=archive['metric'][anchor:target[-1]+1]
            phi2,psi2,_=pot.transpose(2,0,1);kk=original['k']**2
            a=vq[:,None]*(psi2+3*phi2)+qq[0,:,None];beta=-om[:,:1]**2*bq[:,None]*(psi2-3*phi2)+qq[1,:,None]
            spline=make_interp_spline(ts,np.stack((a,beta,np.broadcast_to(om[:,:1],a.shape),np.broadcast_to(hh[:,:1],a.shape)),axis=1),k=5)
            def ode(tm,y):
                aa,bb,mu,hub=spline(tm);f,w=y.reshape(2,2)
                return np.stack((w+aa,-2*hub*w-(kk+mu**2)*f+bb)).ravel()
            prev=make_interp_spline(phase[:anchor+1],physical[:,:anchor+1].transpose(1,0,2),k=5)
            st=quadrature(prev,phase[anchor],samples)
            sol=solve_ivp(ode,(ANCHOR,ts[-1]),st.ravel(),t_eval=ts,method='DOP853',rtol=1e-12,atol=5e-27,max_step=1/res)
            assert sol.success
            z=sol.y.reshape(2,2,-1).transpose(0,2,1);yr=physical[:,anchor:target[-1]+1]
            def tensor(b,v,y,q):
                f,w=y;b=b[:,None];v=v[:,None];kinetic=v*w;pot=om[:,:1]**2*b*f
                geo=3*v**2*phi2;e=kinetic+pot+geo+q[2,:,None];p=kinetic-pot+geo+(q[2]-q[3])[:,None]/3
                j=kk*v*f+q[4,:,None];rho=(original['rho0']*original['m']/om[:,:1])
                return np.stack((e,p,j,q[5,:,None]+0*f,e/2+1.5*hh[:,:1]*j/kk,e/rho-3*phi2,j/rho))
            now=tensor(b,v,yr,qr);other=tensor(bq,vq,z,qq);diag=tensor((b+bq)/np.sqrt(2),(v+vq)/np.sqrt(2),(yr+z)/np.sqrt(2),qd)
            absolute=archive['values'][0,:,anchor:target[-1]+1]
            err=np.max(abs(now-absolute),axis=(1,2))/np.max(abs(absolute),axis=(1,2));assert err.max()<1e-9,err
            avg=(now+other)/2
            freeze.append(np.stack((avg,now-avg,diag-avg))[:,:,ti])
    pack(f'causal-{res}.npz',t=t[target],orders=[0,1,2,3],grids=['p16','p32'],anchor=ANCHOR,values=np.array(freeze).reshape(4,2,*freeze[0].shape))
    print('causal preparations frozen',res,flush=True)
if __name__=='__main__':
    guard();check('driven-freeze.json')
    receipt('causal-method.json',[ROOT/p for p in ('CAUSAL-PREPARATION.md','causal_prep.py','total-scores.json','first-freeze.json','driven-freeze.json')])
    for res in (640,1280):calculate(res)
    receipt('causal-freeze.json',[ROOT/'causal-method.json',ROOT/'causal-640.npz',ROOT/'causal-1280.npz'])
