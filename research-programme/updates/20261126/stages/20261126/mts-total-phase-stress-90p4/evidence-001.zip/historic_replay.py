from data_io import *
from scipy.interpolate import make_interp_spline,CubicSpline
from scipy.integrate import solve_ivp

pin(PREFIX,'exact_source_stage.py');sys.path.insert(0,str(PREFIX))
import exact_source_stage as pre
pin(LATE,'window_io.py');sys.path.insert(0,str(LATE))
import window_io as io
def restore(grid):
    guard();p=pre.import_at(pre.OLD,'partial');host=p.Host(grid,4)
    from shared_trace import Shared
    trace=Shared();early=trace.overlay(host.external,[2,3]);kk=host.kk
    archive=pin(MID,f'oscillator-{grid}-4.npz')
    with np.load(archive) as ar:mass=np.sqrt(ar['mass2'][0])/ar['a'][0];rho0=ar['rho0'].item()
    with np.load(io.sealed(io.EXT,'material/forcing-heavy.npz')) as ar:
        ids=[ar['bgkeys'].tolist().index(key) for key in ('a','h')]
        late_bg=make_interp_spline(np.log(ar['eta']),ar['background'][ids].T,k=5)
    srcfile=io.oldio.pin(io.oldio.PAD,'material-halfstep/forcing-heavy.npz')
    with np.load(srcfile) as ar:
        ids=[ar['keys'].tolist().index(key) for key in ('hfield','hmoment','henergy','hJ')]
        late_q=make_interp_spline(np.log(ar['eta']),ar['values'][ids,:,0].T,k=5)
    series=[];prefix=['second','third','fourth','partial']
    files=[pin(PREFIX,f'{key}-{grid}-4.npz') for key in prefix]+[pin(MID,f'carry-matched-{grid}-4.npz')]+[pin(LATE,f'part-matched-{grid}-4-{part:02}.npz') for part in range(1,16)]
    for idx,path in enumerate(files):
        with np.load(path) as ar:
            t=ar['t'];obs=ar['obs'][:,:2]
            if idx==0:
                assert t[0]<CUT<t[-1];seed=ar['entry'][:2,10:12].T
            cur=ar['traces'][:,:2,0] if idx<4 else ar['physical_current_phase'][:,:2,0]
            series.append((t,obs[:,:,[0,3,4]],cur,ar['final'][:2,10:12].T))
    def geom(tt):
        if tt<=89.6:
            h,m2,b,v=host.osc(np.array([tt]));return np.array([np.sqrt(m2[0])/mass,h[0]])
        if tt<=89.65:
            row=host.flow.bg(np.log(tt));return row[[host.flow.bgkeys.index(s) for s in ('a','h')]]
        return late_bg(np.log(tt))
    tbegin=series[0][0][0];h0,m2,b,v=host.osc(np.array([tbegin]))
    state=np.vstack((np.broadcast_to(b,(1,2)),np.broadcast_to(v,(1,2)),seed))
    refs=[];replay=[];clocks=[];met=[];fields=[];current_true=[];current_pred=[];cut_state=None
    for idx,(t,metric,cur,end) in enumerate(series):
        guard();pot=CubicSpline(t,metric,axis=0,extrapolate=False)
        ext=early if idx<4 else (host.external if idx==4 else late_q)
        knots=np.unique(np.r_[t[0],np.arange(np.ceil(t[0]*1280),np.floor(t[-1]*1280)+1)/1280,t[-1]])
        def evaluate(tm,y):
            b,v,f,w=y.reshape(4,2);a,h=geom(tm);om2=(mass*a)**2
            phi,psi,_=pot(tm).T;uf,uw,_,_=ext(np.log(tm))
            return np.array([v,-2*h*v-om2*b,w+v*(psi+3*phi)+uf,-2*h*w-(kk+om2)*f-om2*b*(psi-3*phi)+uw]).ravel()
        ode=solve_ivp(evaluate,(t[0],t[-1]),state.ravel(),t_eval=knots,method='DOP853',rtol=2e-12,atol=1e-25,max_step=1/1280)
        assert ode.success
        y=ode.y.T.reshape(len(knots),4,2);state=y[-1]
        keep=knots>=CUT
        if idx and np.any(keep):keep[0]=False
        if np.any(knots==CUT):cut_state=y[np.flatnonzero(knots==CUT).item()]
        clocks.extend(knots[keep]);met.extend(pot(knots[keep]));fields.extend(y[keep])
        aa=np.array([geom(tm)[0] for tm in knots[keep]]);qj=ext(np.log(knots[keep]))[:,3]
        current_pred.extend((kk*y[keep,1]*y[keep,2]+qj[:,None])*aa[:,None]/rho0);current_true.extend(CubicSpline(t,cur)(knots[keep]))
        refs.append(end);replay.append(state[2:])
    levels=lambda x:np.max(np.abs(x),axis=0)
    endpoints=100*levels(np.array(replay)-refs)/levels(refs)
    currents=100*levels(np.array(current_pred)-current_true)/levels(current_true)
    print(grid,'archived endpoint errors (%)',endpoints,'current',currents,flush=True)
    assert np.isfinite(endpoints).all() and max(endpoints.max(),currents.max())<.5
    assert cut_state is not None and np.all(np.diff(clocks)>0)
    report=dict(endpoint_peak_error_pct=endpoints.tolist(),current_trajectory_error_pct=currents.tolist(),count=len(files))
    pack(f'history-{grid}.npz',k=host.wave,t=clocks,metric=met,metric_names=['Phi','Psi','momentum_Phi_rate'],states=fields,
        cut_state=cut_state,rho0=rho0,m=mass,reference_endpoints=refs,replayed_endpoints=replay,currents=current_true)
    receipt(f'history-{grid}-receipt.json',[ROOT/f'history-{grid}.npz',archive,srcfile,io.sealed(io.EXT,'material/forcing-heavy.npz'),*files,pin(PREFIX,'shared_trace.py')])
    return report

if __name__=='__main__':
    guard();results={grid:restore(grid) for grid in ('p16','p32')}
    put('replay.json',results)
    receipt('replay-freeze.json',[ROOT/k for k in ('data_io.py','historic_replay.py','PROTOCOL.md','history-p16-receipt.json','history-p32-receipt.json','replay.json')])
