from pathlib import Path
from functools import lru_cache
from io import BytesIO
import json
import hashlib
import sys
import numpy as np

ROOT=Path(__file__).resolve().parent
BASE=ROOT.parent
PREV=BASE/'mts-coupled-stress-visibility-90p4-20261126'
PREFIX=BASE/'mts-native-switch-source-and-photons-89p6-20261126'
MID=BASE/'mts-carried-photon-window-89p65-20261126'
LATE=BASE/'mts-carried-gravity-photons-90p4-20261126'
BANK=BASE/'mts-photon-matter-89p6-20261124'
SIG={PREV:'18b857965f015b0122537aefa5742cba54e78e128db53498710d82b79d219108',PREFIX:'c42d28f230ca89ae248d7740911cb741ba32f261b261b4ff7e11e03a163d4661',MID:'eaea6794d8575dc50213b70bed708bffd881fffa318d57ac2c2faed0300ad2c7',LATE:'9255065ecee560e1933ced73cb9cc0ba3561e6bbfe1259f7c93d7b41c7992680',BANK:'bc32739cb1aa9f24909005b4cfde0d6c056a9508b178a4e0fe126a9ba218a159'}
CUT=89.275
END=90.4
def sha(path):
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
@lru_cache()
def pin(folder,name):
    assert sha(folder/'seal.json')==SIG[folder],folder
    path=folder/name
    assert sha(path)==json.loads((folder/'seal.json').read_bytes())['files'][name],path
    return path
def guard():
    assert not any((folder/'STOP-REQUESTED').exists() for folder in (ROOT,BASE,*SIG))
def save(path,blob):
    guard()
    if path.exists():assert sha(path)==hashlib.sha256(blob).hexdigest(),path
    else:
        tmp=path.with_suffix(path.suffix+'.partial')
        with tmp.open('xb') as stream:stream.write(blob)
        tmp.rename(path)
def put(name,obj):save(ROOT/name,(json.dumps(obj,indent=2,sort_keys=True,allow_nan=False,default=lambda x:x.item())+'\n').encode())
def pack(name,**arrays):
    buf=BytesIO();np.savez_compressed(buf,**arrays);save(ROOT/name,buf.getvalue())
def receipt(name,files):put(name,{str(path.relative_to(BASE)):sha(path) for path in files})
def check(name):
    for key,sig in json.loads((ROOT/name).read_bytes()).items():assert sha(BASE/key)==sig,key
def read(path):
    with np.load(path) as ar:return dict(ar.items())
