from data_io import *
from scipy.interpolate import make_interp_spline
from scipy.integrate import solve_ivp
from types import SimpleNamespace

pin(PREV,'project_feedback.py');sys.path.insert(0,str(PREV))
from project_feedback import kin,spatial,contract,signed

def predict(res):
    clock=read(signed(f'coupled-matched-{res}.npz'));k=clock['k'];src_t=clock['t']
    par=kin.initial('matched');hist=kin.audit_sources.load_native('matched',before=CUT)
    coef=par.h0**2-par.pressure
    def geom(at):
        dt=at-CUT;fac=1+par.h0*dt+coef*dt*dt/4
        return fac,par.m*par.a0*fac,(par.h0+coef*dt/2)/fac
    cols=clock['keys'].tolist();lin=make_interp_spline(src_t,clock['values'][:,[cols.index(key) for key in ('X','k_sigma','pir','S','pig')]],k=5)
    drive=make_interp_spline(src_t,clock['values'][:,0],k=5)
    eta=make_interp_spline(src_t,(clock['values'][:,cols.index('k_sigma')]-clock['values'][:,0])/3,k=5).antiderivative()
    seed=read(kin.pin('clock-inputs.npz'))['local_at_cut'][:4];fac,om,hh=geom(CUT)
    d=1.5*hh;nu=om+k*k/(2*om);s=drive(CUT)/2
    b,v,f,w=seed;bq=(v+d*b)/om;fq=(w+d*f+s*b)/nu
    other=np.array([bq,-om*b-d*bq,fq,-nu*f-d*fq-s*bq])
    def rhs(tt,vec):
        _,om,hh=geom(tt);b,v,f,w=vec.reshape(2,4,-1).transpose(1,0,2)
        return np.stack((v,-2*hh*v-om**2*b,w,-2*hh*w-(k*k+om**2)*f-v*drive(tt)),axis=1).ravel()
    t=np.arange(round(CUT*res),round(END*res)+1)/res
    sol=solve_ivp(rhs,(CUT,END),np.stack([seed,other]).ravel(),t_eval=t,method='DOP853',rtol=1e-12,atol=2e-25,max_step=1/res)
    assert sol.success
    state=sol.y.reshape(2,4,len(k),len(t)).transpose(0,1,3,2)
    shell=np.array(json.loads(spatial.pin('legs.json').read_bytes())['squared_radii'])
    pieces=[];g=[];first_k=None
    for beg in range(0,len(t),48):
        guard();ids=slice(beg,beg+48);tt=t[ids];fac,om,hh=geom(tt[:,None]);xx,sk,pir,shear,pig=lin(tt).transpose(1,0,2)
        alpha=sk/k**2;phi=hist.data['etak'][-1]/k+eta(tt)-eta(CUT)-hh*alpha
        psi=phi-((par.weights[2]*pig+par.weights[3]*pir)/fac**2+1.5*shear)/k**2
        pd=(sk-xx)/3+(3*hh**2+par.pressure/fac**2)*alpha/2-hh*psi
        def calculate(arr):
            b,v,f,w=arr;fg=f+v*alpha;n=w+(-3*hh*v-om**2*b)*alpha
            field=dict(f=fg,n=n,u=n-3*v*phi,phi=phi,psi=psi,fd=n+v*psi,nd=-2*hh*n-(k*k+om**2)*fg-om**2*b*psi+3*v*pd)
            model=SimpleNamespace(nodes=k,shell=shell,first={name:value.T for name,value in field.items()})
            raw=spatial.Project(model).ops[0];op=spatial.Fast(raw,model)
            return raw[1],contract(op,lambda method,l,r:method(l,r),b[:,0],v[:,0],om[:,0]**2)
        real=state[0,:,ids];quarter=state[1,:,ids];first_k,q0=calculate(real);_,q1=calculate(quarter);_,q45=calculate((real+quarter)/np.sqrt(2))
        assert np.max(abs(q45[:2]-(q0[:2]+q1[:2])/np.sqrt(2)))<=1e-11*np.max(abs(q0[:2]))
        pieces.append(np.stack([q0,q1,q45]));g.append(np.stack([om[:,0],hh[:,0],real[0,:,0],real[1,:,0],quarter[0,:,0],quarter[1,:,0]]))
    q=np.concatenate(pieces,axis=2);background=np.concatenate(g,axis=1)
    assert np.isfinite(q).all()
    pack(f'first-{res}.npz',t=t,k=first_k,fields=['hfield','hmoment','henergy','htrace','hJ','hshear','hJprime'],q=q,
        bg=background,bg_keys=['omega','H','b','v','bq','vq'],orientations=['real','quarter','diagonal'],rho0=par.rho,m=par.m)
    print('frozen first-order drives',res,first_k,flush=True)

if __name__=='__main__':
    guard();receipt('first-method.json',[ROOT/'PROTOCOL.md',ROOT/'first_pair.py',ROOT/'data_io.py',pin(PREV,'project_feedback.py'),pin(PREV,'phase-average/transported_pair.py'),signed('coupled-matched-640.npz'),signed('coupled-matched-1280.npz'),kin.pin('clock-inputs.npz'),spatial.pin('legs.json')])
    for res in (640,1280):predict(res)
    receipt('first-freeze.json',[ROOT/'first-method.json',ROOT/'first-640.npz',ROOT/'first-1280.npz'])
