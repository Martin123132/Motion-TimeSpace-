from data_io import *
from scipy.interpolate import CubicSpline,make_interp_spline
from scipy.integrate import cumulative_simpson

def primitive(t,arr):
    return cumulative_simpson(arr.real,x=t,axis=0,initial=0)+1j*cumulative_simpson(arr.imag,x=t,axis=0,initial=0)
def pct(d,r):
    den=np.max(abs(r),axis=0);assert np.all(den>0)
    return 100*np.max(abs(d),axis=0)/den
def run(grid,res):
    v=read(ROOT/f'driven-{grid}-{res}.npz');first=read(ROOT/f'first-{res}.npz');hist=read(ROOT/f'history-{grid}.npz');mem=read(ROOT/f'memory-{grid}.npz')
    t=v['t'];kk=v['k']**2;om,h=first['bg'][:2];rho=first['rho0']/(om/first['m'])
    mt=mem['t'];theta=CubicSpline(mt,mem['theta'])(t);original_wave=CubicSpline(mt,hist['currents'])(t)
    roll=CubicSpline(mt,mem['exact_rolling'])(t);delta=roll+mem['memory_offset']-original_wave
    names=[(PREFIX,'second-'+grid+'-4.npz'),(PREFIX,'third-'+grid+'-4.npz'),(PREFIX,'fourth-'+grid+'-4.npz'),(PREFIX,'partial-'+grid+'-4.npz'),(MID,'carry-matched-'+grid+'-4.npz'),(LATE,'carry-matched-'+grid+'-4.npz')]
    ct=[];hh=[]
    for idx,(folder,name) in enumerate(names):
        with np.load(pin(folder,name)) as a:
            sl=slice(int(idx>0),None);ct.extend(a['t'][sl]);hh.extend(a['obs'][sl,0,9].real)
            if idx==0:native_rho=CubicSpline(a['t'],a['traces'][:,0,10].real)(CUT)
    native_h=CubicSpline(ct,hh);hn=native_h(t);fac_old=-1+3*(native_h(t,1)-hn**2)/kk
    coords=CubicSpline(t,h,extrapolate=False);gp=coords(t,1);factor=-1+3*(gp-h*h)/kk
    c0=mem['archival_energy_memory'][0]
    def from_delta(diff,initial,hub,weight):
        y0=initial+3*hub[0]*diff[0]/kk
        y=y0+primitive(t,weight[:,None]*diff)
        return y,y-3*hub[:,None]*diff/kk
    old_y,old_e=from_delta(delta,c0,hn,fac_old)
    keep=((t<89.5999)|(t>89.6501))
    loc=np.searchsorted(mt,t[keep]);assert np.array_equal(mt[loc],t[keep]) and mem['valid'][loc].all()
    legacy_e=mem['archival_energy_memory'][loc];native_y=legacy_e+3*hn[keep,None]*(mem['archival_mean'][loc]-hist['currents'][loc])/kk
    origerr=pct(old_y[keep]-native_y,native_y-native_y[0])
    old_e_err=pct(old_e[keep]-legacy_e,legacy_e-legacy_e[0])
    real=hist['cut_state'];b,vel,f,w=real;phi=hist['metric'][0,:,0]
    qe,qj=mem['qe_qj'][0]
    oldom=hist['rho0']/native_rho*hist['m']
    original_input=vel*w+oldom**2*b*f+3*vel**2*phi+qe
    realval=v['values'][0];j=realval[6]
    eco=(original_input+native_rho*c0-realval[0,0])/rho[0]
    post=CubicSpline(theta,j).antiderivative();precoord=np.r_[mem['pre_theta'],theta[0]]
    prej=np.vstack((mem['pre_j'],hist['currents'][0]));before=CubicSpline(precoord,prej).antiderivative()
    start=theta[0];lower=theta-np.pi;hi=lower>=start
    win=(post(theta)-post(np.maximum(lower,start)))/np.pi
    win[~hi]+=(before(start)-before(lower[~hi]))/np.pi
    off=native_rho*mem['archival_mean'][0]/rho[0]-win[0];mean=win+off
    diff=mean-j;y,energy=from_delta(diff,eco,h,factor)
    total_j=j+diff;total_e=realval[0]+rho[:,None]*energy
    init_rates=np.array([100*np.max(abs(total_j[0]-native_rho*mem['archival_mean'][0]/rho[0]))/np.max(abs(total_j[0])),100*np.max(abs(total_e[0]-original_input-native_rho*c0))/np.max(abs(total_e[0]))])
    assert np.max(init_rates)<1e-10
    avg=(realval[6]+v['values'][1,6])/2;cos=j-avg;sin=v['values'][2,6]-avg
    ca=np.cos(2*theta)[:,None];sa=np.sin(2*theta)[:,None]
    slow=np.stack([avg,ca*cos-sa*sin,sa*cos+ca*sin],axis=1)
    models=np.zeros((3,*avg.shape),complex);models[0]=avg
    for i in range(5,len(t)):
        sl=slice(i-5,i+1);spline=make_interp_spline(theta[sl]-theta[i],slow[sl],k=5)
        av,c,s=spline(0,1);av2,c2,s2=spline(0,2)
        ds=-sa[i]*c+ca[i]*s;dc2=ca[i]*c2+sa[i]*s2;ds2=-sa[i]*c2+ca[i]*s2
        models[1,i]=avg[i]-np.pi*av/2-ds/2
        models[2,i]=models[1,i]+np.pi**2*av2/6+dc2/4+np.pi*ds2/4
    refmean=mean[hi];target=refmean-avg[hi]-off;y0=y[hi][0]
    scales=[]
    for mod in models:
        pred=mod[hi]+off;da=pred-refmean
        dd=pred-j[hi]
        predicted_y=y0+primitive(t[hi],factor[hi,None]*dd)
        physical_load=total_e[hi]/2+(3*h[hi]*rho[hi]/(2*kk))[:,None]*total_j[hi]
        predload=physical_load+rho[hi,None]*(predicted_y-y[hi])/2
        scales.append(dict(mean_level_pct=pct(da,refmean).tolist(),causal_minus_instantaneous_pct=pct(da,target).tolist(),
            mean_change_pct=pct(da-da[0],refmean-refmean[0]).tolist(),Y_drift_pct=pct(predicted_y-y[hi],y[hi]-y0).tolist(),
            complete_constraint_load_change_pct=pct(predload-physical_load,physical_load-physical_load[0]).tolist()))
    print(grid,res,'historical Y',origerr,'after full cycle',scales,flush=True)
    return dict(grid=grid,res=res,historical_Y_drift_pct=origerr.tolist(),historical_energy_memory_drift_pct=old_e_err.tolist(),
        inherited_mismatch_pct=init_rates.tolist(),first_complete_window=float(t[hi][0]),target_defect_pct_of_mean=(100*np.max(abs(target),axis=0)/np.max(abs(refmean),axis=0)).tolist(),
        old_memory_replay_pct=mem['mean_replay_pct'].tolist(),scales=scales)
if __name__=='__main__':
    guard();check('driven-freeze.json')
    receipt('memory-method.json',[ROOT/'MEMORY.md',ROOT/'memory_history.py',ROOT/'memory_load.py',ROOT/'driven-freeze.json',*[ROOT/f'memory-{g}.npz' for g in ('p16','p32')]])
    results=[run(g,res) for g in ('p16','p32') for res in (640,1280)]
    put('memory-scores.json',dict(rows=results,approximations=['instantaneous','retarded first order','retarded second order']))
