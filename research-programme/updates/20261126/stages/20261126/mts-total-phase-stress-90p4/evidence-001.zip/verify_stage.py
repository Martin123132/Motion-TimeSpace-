from data_io import *

def obj(name):
    return json.loads((ROOT/name).read_bytes())

def verify(create):
    guard()
    for folder,expected in SIG.items():
        assert sha(folder/'seal.json')==expected
    receipts=set()
    for pattern in ('*-method.json','*-freeze.json','*-receipt.json','memory-inputs-*.json','load-control/method.json','load-control/prediction-freeze.json','load-control/*.receipt'):
        receipts.update(ROOT.glob(pattern))
    assert len(list((ROOT/'load-control').glob('part-*.npz.receipt')))==60
    for path in receipts:check(path.relative_to(ROOT))
    assert not list(ROOT.rglob('*.partial'))
    history=obj('replay.json')
    assert all(row['count']==20 and np.max(row['endpoint_peak_error_pct'])<.000001 and max(row['current_trajectory_error_pct'])<.000001 for row in history.values())
    scores=obj('orbit-scores.json')
    assert scores['freeze']==sha(ROOT/'orbit-freeze.json') and scores['scorer']==sha(ROOT/'score_orbit.py') and scores['unchanged_tolerance_pct']==.5
    reduced=[r for r in scores['rows'] if r['angles']==16 and r['degree']==3 and r['ambient']=='rotated']
    assert {(r['grid'],r['res']) for r in reduced}=={(grid,res) for grid in ('p16','p32') for res in (640,1280)}
    cold_free=[0,2,3,4,5,6]
    for row in reduced:
        drift_scores=np.array(row['drift_pct'])
        assert np.max(row['level_pct'])<.5 and drift_scores[1:].max()<.5
        assert drift_scores[0,cold_free].max()<.5 and drift_scores[0,1].max()>.5
    assert max(np.amax(row['mean_pressure_8_to_16_pct']) for row in scores['controls'])>.5
    tol=obj('load-control/scores.json')['tolerance_pct']
    assert tol==.5
    primary=[row for row in obj('load-control/equivalence.json')['photons'] if row['setting']=='primary' and row['sub']==4 and row['branch']=='comp']
    assert {r['grid'] for r in primary}=={'p16','p32'}
    assert all(r['joint_gap_after_pct']>tol and abs(r['joint_gap_after_pct']-r['joint_gap_before_pct'])<.000001 for r in primary)
    memory=obj('memory-scores.json')['rows'];assert len(memory)==4
    for row in memory:
        assert max(row['historical_Y_drift_pct'])<.001
        assert max(row['scales'][1]['Y_drift_pct'])<.5 and min(row['scales'][1]['causal_minus_instantaneous_pct'])>.5
    vir=obj('virial-report.json')
    assert vir['original_method']==sha(ROOT/'virial-method.json') and vir['reporter']==sha(ROOT/'virial_report.py')
    for row in vir['rows']:
        controls=row['derivatives']
        assert controls['5']['passes_both_routes']==(row['res']==1280)
        assert all(controls[key]['passes_both_routes'] for key in ('7','9','equations'))
        assert max(row['integrated_V_error_pct'])<.5
    assert len(vir['rows'])==len(primary)*2
    files={item.relative_to(ROOT).as_posix():sha(item) for item in ROOT.rglob('*') if item.is_file() and item!=ROOT/'seal.json'}
    record=dict(files=files,parents={path.name:expected for path,expected in SIG.items()},scope='Conditional driven total heavy stress and pressure; exact memory variable and original-source photon equivalence; no observational fit.')
    if create:put('seal.json',record)
    assert obj('seal.json')==record
    print('Verified',len(files),'files;',len(receipts),'receipt maps; seal',sha(ROOT/'seal.json'))
if __name__=='__main__':
    assert sys.argv[1:] in ([],['--seal'])
    verify(bool(sys.argv[1:]))
