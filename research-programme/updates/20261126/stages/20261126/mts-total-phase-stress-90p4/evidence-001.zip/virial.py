from score_total import aperture, drift, rate, primitive
from scipy.interpolate import make_interp_spline
from data_io import *

def diagnose(grid,res):
    first=read(ROOT/f'first-{res}.npz')
    ref=read(ROOT/f'driven-{grid}-{res}.npz')
    times=first['t']
    assert np.array_equal(times,ref['t'])
    freq,hub,back,vel=first['bg'][:4,:,None]
    field,mom=ref['state'][0]
    phi,psi=ref['metric'].transpose(2,0,1)[:2]
    drive_f=vel*(psi+3*phi)+first['q'][0,0,:,None]
    drive_w=-freq**2*back*(psi-3*phi)+first['q'][0,1,:,None]
    prod=(vel*field+back*mom)/2
    slope=make_interp_spline(times,prod,k=5)(times,1)
    terms=np.stack([slope,2*hub*prod,ref['k']**2*back*field/2,-vel*drive_f/2,-back*drive_w/2,3*vel**2*phi,ref['pieces'][0,1]])
    exact_p=ref['values'][0,1]
    integral=primitive(exact_p-terms[1:].sum(0),times)
    orbit=read(ROOT/f'orbit-{res}.npz')
    target=ref['phase'][np.searchsorted(times,orbit['t'])]
    projected=aperture(ref['phase'],np.concatenate((exact_p[None],terms)),target)[0]
    truth,each=projected[0],projected[1:]
    error=rate(drift(each.sum(0)-truth),drift(truth))
    last=drift(each)[:,-1]/drift(truth)[-1]
    assert np.max(abs(last.sum(0)-1))<.005
    rec=dict(grid=grid,res=res,instantaneous_pressure_pct=rate(terms.sum(0)-exact_p,exact_p).tolist(),integrated_V_pct=rate(integral-drift(prod),drift(prod)).tolist(),
        mean_pressure_change_pct=error.tolist(),term_changes_pct_of_true_change=rate(drift(each),drift(truth)).tolist(),last_over_total_real=last.real.tolist(),last_over_total_imag=last.imag.tolist())
    print(grid,res,'mean change error %',error,'signed final fractions',np.round(last[:,0].real,5),flush=True)
    return rec
if __name__=='__main__':
    guard();check('driven-freeze.json');check('orbit-freeze.json')
    receipt('virial-method.json',[ROOT/k for k in ('VIRIAL.md','virial.py','driven-freeze.json','orbit-freeze.json','score_total.py')])
    put('virial-scores.json',dict(method=sha(ROOT/'virial-method.json'),terms=['Vprime','2HV','KbF/2','-vA/2','-bB/2','3v2Phi','Qp'],rows=[diagnose(grid,res) for grid in ('p16','p32') for res in (640,1280)]))
