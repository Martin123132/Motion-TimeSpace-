from causal_prep import *
from scipy.interpolate import BarycentricInterpolator

def leg_bank(res):
    a=read(ROOT/f'first-{res}.npz');time=a['t'];phase=CubicSpline(time,a['bg'][0]).antiderivative()(time)
    phase-=phase[0];anchor=np.flatnonzero(time==ANCHOR).item()
    ok=(phase-phase[0]>6*np.pi)&(phase[-1]-phase>6*np.pi)&(np.rint(time*res).astype(int)%(res//320)==0)
    centers=np.flatnonzero(ok);end=centers[-1]+1;ts=time[anchor:end]
    forecast=read(signed(f'coupled-matched-{res}.npz'));k=forecast['k'];par=kin.initial('matched')
    hdata=kin.audit_sources.load_native('matched',before=CUT);dt=ts[:,None]-CUT;coef=par.h0**2-par.pressure
    cols=forecast['keys'].tolist();leg=forecast['values'][:,[cols.index(key) for key in ('X','k_sigma','pir','S','pig')]]
    spline=make_interp_spline(forecast['t'],leg,k=5);drive=make_interp_spline(forecast['t'],leg[:,0],k=5)
    eta=make_interp_spline(forecast['t'],(leg[:,1]-leg[:,0])/3,k=5).antiderivative()
    def back(dt):
        fac=1+par.h0*dt+coef*dt**2/4
        return fac,par.m*par.a0*fac,(par.h0+coef*dt/2)/fac
    def rhs(tt,y):
        _,om,hh=back(tt-CUT);b,v,f,w=y.reshape(4,-1)
        return np.stack([v,-2*hh*v-om**2*b,w,-2*hh*w-(k*k+om**2)*f-v*drive(tt)]).ravel()
    def advance(lo,hi,ini,times):
        sol=solve_ivp(rhs,(lo,hi),ini.ravel(),t_eval=times,method='DOP853',rtol=1e-12,atol=2e-25,max_step=1/res)
        assert sol.success;return sol.y.T.reshape(-1,4,len(k))
    real=advance(CUT,ts[-1],read(kin.pin('clock-inputs.npz'))['local_at_cut'][:4],time[:end])
    sp=make_interp_spline(phase[:anchor+1],real[:anchor+1],k=5);quarter=advance(ANCHOR,ts[-1],quadrature(sp,phase[anchor],4),ts)
    real=real[anchor:]
    fac,om,hh=back(dt);x,sk,pir,shear,pig=spline(ts).transpose(1,0,2)
    alpha=sk/k**2;phi=hdata.data['etak'][-1]/k+eta(ts)-eta(CUT)-hh*alpha
    psi=phi-((par.weights[2]*pig+par.weights[3]*pir)/fac**2+1.5*shear)/k**2
    pd=(sk-x)/3+(3*hh**2+par.pressure/fac**2)*alpha/2-hh*psi
    basis=SimpleNamespace(nodes=k,shell=np.array(json.loads(spatial.pin('legs.json').read_bytes())['squared_radii']),first={})
    raw=spatial.Project(basis).ops[0]
    def calc(state):
        b,v,f,w=state.transpose(1,0,2);fg=f+v*alpha;n=w+(-3*hh*v-om**2*b)*alpha
        slots=dict(f=fg,n=n,u=n-3*v*phi,phi=phi,psi=psi,fd=n+v*psi,nd=-2*hh*n-(k*k+om**2)*fg-om**2*b*psi+3*v*pd)
        basis.first={name:value.T for name,value in slots.items()}
        return contract(spatial.Fast(raw,basis),lambda fn,l,r:fn(l,r),b[:,0],v[:,0],om[:,0]**2)
    return time,phase,anchor,end,centers,a,np.stack((a['q'][0,:,anchor:end],calc(quarter),calc((real+quarter)/np.sqrt(2)))),np.stack((real[:,:2,0],quarter[:,:2,0]))

def causal_values(theta,vals,target,angle,degree,odd):
    u=np.pi*np.arange(1,degree+2)-angle
    weights=np.ones(len(u))
    for i in range(len(u)):
        mask=np.arange(len(u))!=i;weights[i]=np.prod(u[mask]/(u[mask]-u[i]))
    for power in range(degree+1):assert abs(weights@(-u)**power-(1 if power==0 else 0))<2e-9
    if odd:weights*=(-1.)**np.arange(1,degree+2)
    answer=0.
    for lag,ww in zip(u,weights):
        pt=target-lag
        assert np.min(pt)>=theta[0]
        central=np.searchsorted(theta,pt)
        left=np.minimum(np.maximum(central-3,0),np.searchsorted(theta,target,side='right')-6)
        ix=left[:,None]+np.arange(6)
        assert np.all(theta[ix[:,-1]]<=target+1e-13)
        coords=theta[ix];coeffs=[]
        for j in range(6):
            rest=np.arange(6)!=j;coeffs.append(np.prod((pt[:,None]-coords[:,rest])/(coords[:,j,None]-coords[:,rest]),axis=1))
        answer+=ww*np.einsum('ti,ti...->t...',np.stack(coeffs,axis=1),vals[ix])
    return answer

def generate(res):
    time,theta,anchor,end,centers,first,qq,basis=leg_bank(res);ts=time[anchor:end];tc=time[centers];ix=centers-anchor
    om,h=first['bg'][:2,anchor:end];rho=first['rho0']*first['m']/om;kk=first['k']**2
    angles=np.pi*np.arange(16)/16;co=np.cos(angles);si=np.sin(angles)
    b=co*basis[0,:,0,None]+si*basis[1,:,0,None];v=co*basis[0,:,1,None]+si*basis[1,:,1,None]
    q=qq[0,:,:,None]*co**2+qq[1,:,:,None]*si**2+np.sin(2*angles)*(qq[2]-(qq[0]+qq[1])/2)[:,:,None]
    q[:2]=qq[0,:2,:,None]*co+qq[1,:2,:,None]*si
    vals=[];error=[];replay=[]
    for grid in ('p16','p32'):
        ref=read(ROOT/f'driven-{grid}-{res}.npz');metric=ref['metric'][:,:,:2];real=ref['state'][0].transpose(1,0,2)
        for degree in (2,3):
            angular=[];seed=[]
            for j,gamma in enumerate(angles):
                angular.append(metric[anchor:end] if j==0 else causal_values(theta,metric,theta[anchor:end],gamma,degree,False))
                seed.append(real[anchor] if j==0 else causal_values(theta,real,theta[anchor:anchor+1],gamma,degree,True)[0])
            rotated=np.stack(angular,axis=1)
            for name,ambient in [('fixed',np.repeat(metric[anchor:end,None],16,axis=1)),('rotated',rotated)]:
                phi=ambient[...,0];psi=ambient[...,1]
                aa=v[:,:,None]*(psi+3*phi)+q[0,:,:,None]
                beta=-om[:,None,None]**2*b[:,:,None]*(psi-3*phi)+q[1,:,:,None]
                spline=make_interp_spline(ts,np.stack([aa,beta],axis=1),k=5)
                geom=make_interp_spline(ts,np.stack([om**2,h],axis=1),k=5)
                ini=np.stack(seed,axis=1)
                def ode(tt,z):
                    f,w=z.reshape(2,16,2);a,bb=spline(tt);m2,hub=geom(tt)
                    return np.stack((w+a,-2*hub*w-(kk+m2)*f+bb)).ravel()
                sol=solve_ivp(ode,(ANCHOR,ts[-1]),ini.ravel(),t_eval=ts,method='DOP853',rtol=1e-12,atol=2e-26,max_step=1/res)
                assert sol.success
                f,w=sol.y.reshape(2,16,2,-1).transpose(0,3,1,2)
                kin=v[:,:,None]*w;pot=om[:,None,None]**2*b[:,:,None]*f;geo=3*v[:,:,None]**2*phi
                energy=kin+pot+geo+q[2,:,:,None];pressure=kin-pot+geo+(q[2]-q[3])[:,:,None]/3
                current=kk*v[:,:,None]*f+q[4,:,:,None]
                allvals=np.stack((energy,pressure,current,q[5,:,:,None]+0*f,energy/2+1.5*h[:,None,None]*current/kk,energy/rho[:,None,None]-3*phi,current/rho[:,None,None]))
                baseline=ref['values'][0,:,anchor:end]
                rep=np.max(abs(allvals[:,:,0]-baseline),axis=1)/np.max(abs(baseline),axis=1);replay.append(rep)
                assert rep.max()<1e-8
                vals.append(allvals[:,ix]);error.append(np.max(abs(ambient-metric[anchor:end,None]),axis=(0,1)))
    vals=np.array(vals).reshape(2,2,2,7,len(ix),16,2)
    pack(f'orbit-{res}.npz',t=tc,grid=['p16','p32'],degrees=[2,3],ambient=['fixed','rotated'],angles=angles,values=vals,real_replay=replay,max_metric_phase_change=error)
    print('frozen metric rotations',res,flush=True)

if __name__=='__main__':
    guard();check('causal-freeze.json')
    receipt('metric-orbit-method.json',[ROOT/k for k in ('METRIC-ORBIT.md','metric_orbit.py','causal-freeze.json','causal-scores.json','driven-freeze.json')])
    for res in (640,1280):generate(res)
    receipt('orbit-freeze.json',[ROOT/'metric-orbit-method.json',ROOT/'orbit-640.npz',ROOT/'orbit-1280.npz'])
