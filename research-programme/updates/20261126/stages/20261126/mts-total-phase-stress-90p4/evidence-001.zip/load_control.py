from data_io import *
from scipy.interpolate import CubicSpline

OUT=ROOT/'load-control'
def packout(name,**data):pack('load-control/'+name,**data)
def putout(name,value):put('load-control/'+name,value)
def checkout(name):check('load-control/'+name)
def freezeout(name,files):receipt('load-control/'+name,[OUT/f for f in files])
def transform():
    old=pin(LATE,'stepper.py').read_text()
    def sub(before,after):
        nonlocal old
        assert old.count(before)==1,before
        old=old.replace(before,after)
    sub("        dt=old['t'][-1]-old['t'][-2]","""        dt=old['t'][-1]-old['t'][-2]
        if matched:
            if 'final_Y' in old:states[3][:,1]=old['final_Y']
            else:
                assert START==89.65
                states[3][:,1]+=3*previous[:,9]*(states[3][:,0]-old['physical_current_phase'][-1,:,0])/src.kk""")
    sub("ext=src.external(log)[:,3];ext_rate=src.external(log,1)[:,3]/clock","ext=src.external(log)[:,3]")
    sub("            acc=-2*hub*vh-mass2*bg['hb']","            hp=src.flow.bg(log,1)[:,src.flow.bgkeys.index('h')]/clock")
    sub("            extra=0","            extra=0;unadjusted=us[i]-en/2-1.5*hub[i]*cur/kk;load=0")
    sub("delta=memory[:,0]-wave;extra=on*rho[i]*delta;en+=on*rho[i]*memory[:,1];cur+=extra",
        "delta=memory[:,0]-wave;extra=on*rho[i]*delta;load=on*rho[i]*memory[:,1]/2;en+=on*rho[i]*(memory[:,1]-3*hub[i]*delta/kk);cur+=extra")
    sub("ep=(us[i]-en/2-1.5*hub[i]*cur/kk)/den[i]","ep=(unadjusted-load)/den[i]")
    sub("""                wr=(kk*(acc[i]*fields[:,10]+vh[i]*dx[:,10])+ext_rate[i])/rho[i]+rate_a[i]*wave
                pressure=(mean_rate-wr+hub[i]*delta)/kk
                result.append(np.stack((mean_rate,-delta-3*hub[i]*pressure),axis=-1))""","""                result.append(np.stack((mean_rate,(-1+3*(hp[i]-hub[i]**2)/kk)*delta),axis=-1))""")
    for key,idx in [('left+j','pos'),('-1','-1')]:
        spaces='            ' if key=='left+j' else '    '
        sub(spaces+'if matched:memories['+key+']=states[3]',spaces+'if matched:\n'+spaces+'    memories['+key+']=states[3];memories['+key+',:,1]-=3*hub['+idx+']*(states[3][:,0]-currents['+key+',:,0])/kk')
    sub("pack(name,parent_hash=sha(input_path)","pack(name,final_Y=states[3][:,1].copy(),parent_hash=sha(input_path)")
    sub("**dict(zip(keys,states))","**dict(zip(keys,[*states[:3],memories[-1]]))")
    assert 'ext_rate' not in old and 'wr=' not in old and 'states[3][:,1]=old[' in old
    return old
def init():
    guard();OUT.mkdir(exist_ok=True);sys.path.insert(0,str(LATE))
    for key in ('stepper','sources90','evolve90','window_io','project90','score90'):pin(LATE,key+'.py')
def gravity():
    init();import window_io as io;import sources90,stepper,evolve90 as stage
    pre=io.oldio.prefix();p=pre.import_at(pre.OLD,'partial')
    recipe=transform();save(OUT/'evolved_load.py',recipe.encode())
    receipt('load-control/method.json',[ROOT/'VARIABLE-CHANGE.md',ROOT/'MEMORY.md',ROOT/'load_control.py',OUT/'evolved_load.py',*[pin(LATE,k+'.py') for k in ('stepper','sources90','evolve90','window_io')]])
    for mod in (sources90,stage):mod.ROOT=OUT;mod.pack=packout
    stage.freeze=freezeout;stage.check=checkout;stage.put=putout
    space={};exec(compile(recipe,str(OUT/'evolved_load.py'),'exec'),space)
    space['guard']=guard;space['pack']=packout;stage.evolve=space['evolve']
    for grid in ('p16','p32'):
        bank=p.MatchedBank()
        for sub in (2,4):
            guard();name=f'carry-wave-{grid}-{sub}.npz';save(OUT/name,pin(LATE,name).read_bytes())
            stage.branch(p,grid,sub,'matched',bank)
    receipt('load-control/gravity-freeze.json',[OUT/'method.json',*sorted(OUT.glob('*.npz')),*sorted(OUT.glob('*.receipt')),*sorted(OUT.glob('history-*.json'))])

def photon():
    init();checkout('gravity-freeze.json');import project90 as proj
    proj.ROOT=OUT;proj.put=putout;proj.pack=packout;proj.check=checkout
    def locked(name,paths):receipt('load-control/'+name,[OUT/p if (OUT/p).is_file() else pin(LATE,p) for p in paths])
    proj.freeze=locked;proj.run()

def score():
    init();checkout('prediction-freeze.json');import score90 as score
    score.ROOT=OUT;score.put=putout;score.check=checkout;score.score()
    ph=score.modules();_,axis,weights,_=ph.proj.old.get_media();measure=ph.gate.previous.make_measure(axis,weights)
    norm=lambda arr:ph.gate.mag(arr,measure)
    levels=[]
    for setting in ph.SETTINGS:
        path=f'photon-{setting}.npz';new=read(OUT/path);old=read(pin(LATE,path));archive=read(ph.track(ph.cell89.pin(path)))
        vis=lambda val:CubicSpline(new['scale'],val)(axis)
        assert np.array_equal(old['scale'],new['scale']) and np.array_equal(new['labels'],old['labels'])
        for grid in ('p16','p32'):
            row=archive['values'][:,archive['labels'].tolist().index([grid,'primary'])]
            standard=norm(vis(row[:,:3].sum(1)));labels=new['labels'].tolist()
            for sub in (2,4):
                for comp in ('comp','null'):
                    inds=[labels.index(f'{grid}-{sub}-{comp}_'+route) for route in ('momentum','density')]
                    oldvec=vis(old['cumulative'][:,inds]);vec=vis(new['cumulative'][:,inds])
                    gap=vec[:,1]-vec[:,0];prior=oldvec[:,1]-oldvec[:,0]
                    levels.append(dict(setting=setting,grid=grid,sub=sub,branch=comp,joint_gap_before_pct=100*norm(prior)[2]/standard[2],
                        joint_gap_after_pct=100*norm(gap)[2]/standard[2],gap_change_vector_pct=(100*norm(gap-prior)/standard).tolist(),
                        route_vector_changes_pct=[(100*norm(vec[:,i]-oldvec[:,i])/standard).tolist() for i in (0,1)]))
    direct=[]
    for grid in ('p16','p32'):
        for sub in (2,4):
            name=f'carry-matched-{grid}-{sub}.npz';old=read(pin(LATE,name));new=read(OUT/name)
            assert np.array_equal(old['t'],new['t']) and old['final_lag'].shape[-2:]==new['final_lag'].shape[-2:]==(77,69)
            def measure(val,ref):
                return (100*np.max(abs(val-ref),axis=0)/np.max(abs(ref),axis=0)).tolist()
            direct.append(dict(grid=grid,sub=sub,obs=measure(new['obs'],old['obs']),mem=measure(new['memories'],old['memories']),terminal_Y=[[z.real,z.imag] for z in new['final_Y']]))
    putout('equivalence.json',dict(photons=levels,gravity=direct))
    print([(r['grid'],r['joint_gap_after_pct'],r['gap_change_vector_pct']) for r in levels if r['setting']=='primary' and r['sub']==4 and r['branch']=='comp'])
if __name__=='__main__':{'gravity':gravity,'photon':photon,'score':score}[sys.argv[1]]()
