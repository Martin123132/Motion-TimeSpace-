from score_total import *

def run():
    check('causal-freeze.json');rows=[]
    for res in (640,1280):
        forecast=read(ROOT/f'causal-{res}.npz')
        for g,grid in enumerate(forecast['grids']):
            v=read(ROOT/f'driven-{grid}-{res}.npz');idx=np.searchsorted(v['t'],forecast['t']);p=v['phase']
            goal=aperture(p,v['values'][0],p[idx]);coarse=aperture(p[::2],v['values'][0,:,::2],p[idx])
            for degree,pred in zip(forecast['orders'],forecast['values'][:,g]):
                err=rate(pred-goal,goal);dr=rate(drift(pred)-drift(goal),drift(goal))
                rows.append(dict(res=res,grid=str(grid),degree=int(degree),keys=v['keys'].tolist(),full_pct=err.tolist(),drift_pct=dr.tolist(),
                    pressure_target_drift_as_pct_of_peak=(100*peak(drift(goal[0,1]))/peak(goal[0,1])).tolist(),
                    reference_drift_sensitivity_pct=rate(drift(coarse)-drift(goal),drift(goal)).tolist()))
                if res==1280:print(grid,degree,'mean-level',np.round(err[0].max(-1),5),'changes',np.round(dr[0].max(-1),4))
    put('causal-scores.json',dict(rows=rows,primary_degree=3,forecast=sha(ROOT/'causal-freeze.json')))
if __name__=='__main__':run()
