from data_io import *
from scipy.interpolate import CubicSpline,make_interp_spline
pin(LATE,'window_io.py');sys.path.insert(0,str(LATE))
import window_io as io

def capture(grid):
    history=read(ROOT/f'history-{grid}.npz');t=history['t'];k=history['k'];tt=[];phase=[];stored=[];calc=[];eff=[];paths=[]
    names=[(PREFIX,key+f'-{grid}-4.npz') for key in ('period','second','third','fourth','partial')]+[(MID,f'carry-matched-{grid}-4.npz')]+[(LATE,f'part-matched-{grid}-4-{p:02}.npz') for p in range(1,16)]
    qfile=io.oldio.pin(io.oldio.PAD,'material-halfstep/forcing-heavy.npz')
    with np.load(qfile) as ar:
        q=make_interp_spline(np.log(ar['eta']),ar['values'][[ar['keys'].tolist().index(key) for key in ('henergy','hJ')],:,0].T,k=5)
    for i,(folder,name) in enumerate(names):
        path=pin(folder,name);paths.append(path)
        with np.load(path) as ar:
            times=ar['t'];cut=slice(int(i>0),None)
            if folder==PREFIX:
                tr=ar['traces'];theta=tr[:,0,9].real;wave=tr[:,:2,0];mean=tr[:,:2,1];memory=tr[:,:2,3]
            else:
                tr=ar['physical_current_phase'];theta=tr[:,0,1].real;wave=tr[:,:2,0]
                if folder==LATE:mean=ar['memories'][:,:2,0];memory=ar['memories'][:,:2,1]
                else:mean=np.full_like(wave,np.nan);memory=np.full_like(wave,np.nan)
            tt.extend(times[cut]);phase.extend(theta[cut]);stored.extend(mean[cut]);calc.extend(wave[cut]);eff.extend(memory[cut])
    tt=np.array(tt);phase=np.array(phase);stored=np.array(stored);calc=np.array(calc);eff=np.array(eff)
    assert np.all(np.diff(tt)>0) and np.all(np.diff(phase)>0)
    dense=CubicSpline(tt,phase)(t);wave=CubicSpline(tt,calc)(t)
    assert np.max(abs(wave-history['currents']))<1e-10*np.max(abs(wave))
    spline=CubicSpline(phase,calc);prim=spline.antiderivative()
    ok=(dense-np.pi)>=phase[0];assert ok.all()
    integral=(prim(dense)-prim(dense-np.pi))/np.pi
    def segmented(rows):
        good=np.isfinite(rows[:,0]);out=np.zeros((len(t),2),complex);valid=np.zeros(len(t),bool)
        chunks=np.split(np.flatnonzero(good),np.flatnonzero(np.diff(np.flatnonzero(good))!=1)+1)
        for ix in chunks:
            mask=(t>=tt[ix[0]])&(t<=tt[ix[-1]]);out[mask]=CubicSpline(tt[ix],rows[ix])(t[mask]);valid|=mask
        return out,valid
    mean,valid=segmented(stored);memory,valid2=segmented(eff);assert np.array_equal(valid,valid2) and valid[0] and valid[-1]
    off=mean[0]-integral[0];err=100*np.max(abs(mean[valid]-integral[valid]-off),axis=0)/np.max(abs(mean[valid]),axis=0)
    print(grid,'native trailing-mean replay %',err,flush=True);assert max(err)<.5
    pack(f'memory-{grid}.npz',t=t,theta=dense,archival_mean=mean,archival_energy_memory=memory,valid=valid,exact_rolling=integral,
        memory_offset=off,mean_replay_pct=err,pre_t=tt[tt<CUT],pre_theta=phase[tt<CUT],pre_j=calc[tt<CUT],qe_qj=q(np.log(t)))
    receipt(f'memory-inputs-{grid}.json',[ROOT/f'history-{grid}.npz',*paths,qfile])
if __name__=='__main__':
    check('replay-freeze.json')
    for grid in ('p16','p32'):capture(grid)
