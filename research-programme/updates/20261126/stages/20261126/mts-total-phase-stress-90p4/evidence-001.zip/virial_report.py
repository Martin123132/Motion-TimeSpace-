from virial import *
def report(grid,res):
    first=read(ROOT/f'first-{res}.npz');physical=read(ROOT/f'driven-{grid}-{res}.npz')
    time=physical['t'];omega,hub,back,vel=first['bg'][:4,:,None]
    field,momentum=physical['state'][0];phi,psi=physical['metric'].transpose(2,0,1)[:2]
    kk=physical['k']**2
    aa=vel*(psi+3*phi)+first['q'][0,0,:,None]
    bb=-omega**2*back*(psi-3*phi)+first['q'][0,1,:,None]
    prod=(vel*field+back*momentum)/2
    regular=np.stack((2*hub*prod,kk*back*field/2,-vel*aa/2,-back*bb/2,3*vel**2*phi,physical['pieces'][0,1]))
    pressure=physical['values'][0,1];target=read(ROOT/f'orbit-{res}.npz')['t']
    where=physical['phase'][np.searchsorted(time,target)]
    algebra=(( -2*hub*vel-omega**2*back)*field+vel*(momentum+aa)+vel*momentum+back*(-2*hub*momentum-(kk+omega**2)*field+bb))/2
    integral=primitive(pressure-regular.sum(0),time)
    def measure(slope):
        grouped=np.concatenate((pressure[None],slope[None],regular))
        projected=aperture(physical['phase'],grouped,where)[0]
        truth=projected[0];terms=projected[1:]
        ratio=drift(terms)[:,-1]/drift(truth)[-1]
        peak_err=rate(drift(terms.sum(0)-truth),drift(truth))
        return dict(derivative_time_replay=rate(slope-algebra,algebra).tolist(),mean_pressure_change_pct=peak_err.tolist(),
            passes_both_routes=bool(peak_err.max()<=.5),signed_end_ratio_real=ratio.real.tolist(),signed_end_ratio_imag=ratio.imag.tolist(),
            term_change_pct=rate(drift(terms),drift(truth)).tolist())
    scores={str(order):measure(make_interp_spline(time,prod,k=order)(time,1)) for order in (5,7,9)}
    scores['equations']=measure(algebra)
    print(grid,res,[(key,round(max(val['mean_pressure_change_pct']),6)) for key,val in scores.items()],flush=True)
    return dict(grid=grid,res=res,primary='5',derivatives=scores,integrated_V_error_pct=rate(integral-drift(prod),drift(prod)).tolist())
if __name__=='__main__':
    guard();check('virial-method.json')
    put('virial-report.json',dict(original_method=sha(ROOT/'virial-method.json'),reporter=sha(ROOT/'virial_report.py'),unchanged_gate_pct=.5,
        original_result='Fifth-order derivative misses on 640 and original fail-fast scorer stops; all primary outcomes retained separately from follow-up derivative controls.',
        terms=['Vprime','2HV','KbF/2','-vA/2','-bB/2','3v2Phi','Qp'],rows=[report(grid,res) for grid in ('p16','p32') for res in (640,1280)]))
