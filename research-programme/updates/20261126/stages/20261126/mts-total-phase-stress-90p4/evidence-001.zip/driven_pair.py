from data_io import *
from scipy.interpolate import CubicSpline,make_interp_spline
from scipy.integrate import solve_ivp

COMP=['energy','pressure','current','shear','energy_constraint_load','flat_normalized_energy','normalized_current']
TERMS=['-H(Ec+3Pc)','-Jc','3v²Phi_prime','vQw','omega²bQf','-2HJc','KPc','Kv²Psi','KvQf']
def predict(res,grid):
    ar=read(ROOT/f'first-{res}.npz');saved=read(ROOT/f'history-{grid}.npz');kk=ar['k'].item()**2
    assert np.isclose(ar['k'],saved['k'],rtol=1e-13) and ar['rho0']==saved['rho0']
    t=ar['t'];assert t[0]==saved['t'][0]==CUT and t[-1]==saved['t'][-1]==END
    model=make_interp_spline(t,ar['bg'].T,k=5)
    stress=make_interp_spline(t,ar['q'].transpose(2,0,1),k=5)
    metric=CubicSpline(saved['t'],saved['metric'],axis=0,extrapolate=False)
    init=saved['cut_state'][2:]
    def drives(tm):
        om,h,b,v,bq,vq=model(tm);phi,psi,_=metric(tm).T
        q=stress(tm)[:2];bg=np.array([b,bq])[:,None];vel=np.array([v,vq])[:,None]
        return om,h,vel*(psi+3*phi)+q[:,0,None],-om**2*bg*(psi-3*phi)+q[:,1,None]
    om,h,aa,bb=drives(CUT);d=1.5*h;nu=om+kk/(2*om)
    f,w=init;fq=(w+d*f+aa[0]/2+bb[1]/(2*om))/nu;wq=-nu*f-d*fq-aa[1]/2+bb[0]/(2*om)
    fq2=(wq+d*fq+aa[1]/2-bb[0]/(2*om))/nu;wq2=-nu*fq-d*fq2+aa[0]/2+bb[1]/(2*om)
    np.testing.assert_allclose([fq2,wq2],-init,rtol=2e-13,atol=1e-26)
    def rhs(tm,y):
        f,w=y.reshape(2,2,2).transpose(1,0,2);om,h,aa,bb=drives(tm)
        return np.stack((w+aa,-2*h*w-(om**2+kk)*f+bb),axis=1).ravel()
    st=np.stack([init,np.stack([fq,wq])])
    sol=solve_ivp(rhs,(CUT,END),st.ravel(),t_eval=t,method='DOP853',rtol=1e-12,atol=5e-27,max_step=1/res)
    assert sol.success
    state=sol.y.reshape(2,2,2,len(t)).transpose(0,1,3,2)
    om,h,b,v,bq,vq=ar['bg'];phi,psi,shadow=metric(t).transpose(2,0,1)
    pd=metric(t,1)[:,:,0];kg0=ar['rho0']/(om/ar['m']);rho=kg0[:,None]
    dphase=CubicSpline(t,om).antiderivative();phase=dphase(t)-dphase(CUT)
    def components(bg,vel,fields,q):
        bg=bg[:,None];vel=vel[:,None];mu=om[:,None]**2;hub=h[:,None]
        f,w=fields;uf,uw,qe,qt,qj,qs,qjp=q[:,:,None]
        qe=qe+0*f;qj=qj+0*f;qs=qs+0*f;qp=(qe-qt)/3
        geom=3*vel**2*phi;kin=vel*w;pot=mu*bg*f
        ec=kin+pot+geom;pc=kin-pot+geom;jc=kk*vel*f
        e=ec+qe;p=pc+qp;j=jc+qj
        well=np.stack((-hub*(ec+3*pc),-jc,3*vel**2*pd,vel*uw+0*f,mu*bg*uf+0*f,-2*hub*jc,kk*pc,kk*vel**2*psi,kk*vel*uf+0*f))
        return np.stack([e,p,j,qs,e/2+1.5*hub*j/kk,e/rho-3*phi,j/rho]),well,np.stack([qe,qp,qj,kin,pot,geom,jc]),np.stack([3*vel**2*(shadow-pd),qjp+0*f])
    orientations=[components(b,v,state[0],ar['q'][0]),components(bq,vq,state[1],ar['q'][1]),
        components((b+bq)/np.sqrt(2),(v+vq)/np.sqrt(2),(state[0]+state[1])/np.sqrt(2),ar['q'][2])]
    def gather(i):return np.stack([row[i] for row in orientations])
    values=gather(0);work=gather(1);pieces=gather(2);supp=gather(3)
    assert all(np.isfinite(a).all() for a in (state,values,work,pieces,supp))
    pack(f'driven-{grid}-{res}.npz',t=t,k=np.sqrt(kk),phase=phase,keys=COMP,terms=TERMS,parts=['Qe','Qp','Qj','vW','m2bF','3v2Phi','KvF'],
        state=state,q=qshape(ar['q']),values=values,work=work,pieces=pieces,supp=supp,metric=metric(t),cut_seed=st,routes=['comp_momentum','comp_density'],
        supplement_keys=['rate_change_using_momentum_shadow','microscopic_Qjprime'])
    print('frozen driven stress',grid,res,flush=True)
def qshape(arr):return arr[:,:2]
if __name__=='__main__':
    guard();check('replay-freeze.json');check('first-freeze.json')
    receipt('driven-method.json',[ROOT/name for name in ('driven_pair.py','TOTAL.md','first-freeze.json','replay-freeze.json','PROTOCOL.md','data_io.py')])
    for grid in ('p16','p32'):
        for res in (640,1280):predict(res,grid)
    receipt('driven-freeze.json',[ROOT/'driven-method.json',*sorted(ROOT.glob('driven-*.npz'))])
