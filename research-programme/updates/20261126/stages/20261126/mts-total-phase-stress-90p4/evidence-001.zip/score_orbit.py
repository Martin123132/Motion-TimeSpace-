from score_total import aperture, drift, peak, rate
from data_io import *

def project(samples, angles, count, harmonic):
    part=samples[:,:,::len(angles)//count]
    phase=angles[::len(angles)//count]
    weight=np.stack([np.ones_like(phase),2*np.cos(harmonic*phase),2*np.sin(harmonic*phase)])
    return np.einsum('har,jcar->hjcr',weight[...,None],part)/count

def fourth(phase,samples,where):
    out=[]
    for center in where:
        offset=phase-center
        mask=abs(offset)<6*np.pi
        angle=offset[mask]
        coord=angle/(6*np.pi)
        mat=np.column_stack([coord**p for p in range(9)]+[coord**p*fn(2*angle) for p in range(7) for fn in (np.cos,np.sin)]+[coord**p*fn(4*angle) for p in range(3) for fn in (np.cos,np.sin)])
        coeff=np.linalg.lstsq(mat,samples[mask],rcond=None)[0]
        out.append(coeff[23:25])
    return np.stack(out,axis=1)

def score():
    guard();check('orbit-freeze.json')
    rows=[];controls=[]
    for res in (640,1280):
        orb=read(ROOT/f'orbit-{res}.npz')
        assert np.max(orb['real_replay'])<1e-8
        for idx,grid in enumerate(orb['grid']):
            physical=read(ROOT/f'driven-{grid}-{res}.npz')
            targets=np.searchsorted(physical['t'],orb['t'])
            assert np.array_equal(physical['t'][targets],orb['t'])
            where=physical['phase'][targets];signal=physical['values'][0]
            ref=aperture(physical['phase'],signal,where)
            half=aperture(physical['phase'][::2],signal[:,::2],where)
            scale=drift(ref[0,1]);four=fourth(physical['phase'],signal[1],where)
            for dj,deg in enumerate(orb['degrees']):
                for aj,ambient in enumerate(orb['ambient']):
                    vals=orb['values'][idx,dj,aj]
                    for count in (2,4,8,16):
                        parts=project(vals,orb['angles'],count,2)
                        used=1 if count==2 else 3
                        diff=parts[:used]-ref[:used]
                        rows.append(dict(res=res,grid=str(grid),degree=int(deg),ambient=str(ambient),angles=count,level_pct=rate(diff,ref[:used]).tolist(),drift_pct=rate(drift(diff),drift(ref[:used])).tolist()))
            primary=orb['values'][idx,1,1]
            angles=orb['angles']
            ave=lambda block,count:project(block,angles,count,2)[0,1]
            p16=ave(primary,16);pfour=project(primary,angles,16,4)[1:,1]
            ctrl=dict(res=res,grid=str(grid),replay_pct=100*np.max(orb['real_replay']),physical_pressure_change_over_level_pct=rate(scale,ref[0,1]).tolist(),
                pressure_temporal_stride_pct=rate(drift(half[0,1]-ref[0,1]),scale).tolist(),mean_pressure_8_to_16_pct=rate(drift(ave(primary,8)-p16),scale).tolist(),mean_pressure_2_to_16_pct=rate(drift(ave(primary,2)-p16),scale).tolist(),
                mean_pressure_degree_2_to_3_pct=rate(drift(ave(orb['values'][idx,0,1],16)-p16),scale).tolist(),mean_pressure_rotating_metric_effect_pct=rate(drift(ave(orb['values'][idx,1,0],16)-p16),scale).tolist(),
                pressure_fourth_change_over_mean_change_pct=rate(drift(four),scale).tolist(),predicted_fourth_change_over_mean_change_pct=rate(drift(pfour),scale).tolist(),fourth_error_over_mean_change_pct=rate(drift(pfour-four),scale).tolist())
            controls.append(ctrl)
            fixed=rows[-5];rot=rows[-1]
            print(grid,res,'fixed/rot mean drift max',np.around(np.array(fixed['drift_pct'])[0].max(axis=-1),5),np.around(np.array(rot['drift_pct'])[0].max(axis=-1),5),'P controls',[(key,np.amax(ctrl[key])) for key in ('mean_pressure_8_to_16_pct','mean_pressure_degree_2_to_3_pct','mean_pressure_rotating_metric_effect_pct')],flush=True)
    put('orbit-scores.json',dict(freeze=sha(ROOT/'orbit-freeze.json'),scorer=sha(ROOT/'score_orbit.py'),unchanged_tolerance_pct=.5,keys=['E','P','J','shear','constraint_load','flat_energy','normalized_current'],rows=rows,controls=controls))
if __name__=='__main__':score()
