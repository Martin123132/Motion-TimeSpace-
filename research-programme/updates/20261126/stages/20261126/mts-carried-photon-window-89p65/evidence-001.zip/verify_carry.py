from carry_io import *
def verify():
    for name in ('incident-freeze.json','gravity-freeze.json','prediction-freeze.json'):check(name)
    for name in ('incident-controls.json','photon-provenance.json','scores.json'):
        for key,h in json.loads((ROOT/name).read_bytes())['inputs'].items():assert sha(BASE/key)==h,key
    for key,h in json.loads((ROOT/'gravity-inputs.json').read_bytes()).items():assert sha(BASE/key)==h,key
    with np.load(ROOT/'incident-wave-16.npz') as w,np.load(ROOT/'incident-matched-16.npz') as m:
        assert np.array_equal(w['q'],m['q']) and len(m['q'])==77 and np.array_equal(m['t'][[0,-1]],[START,END])
    for grid in ('p16','p32'):
        for sub in (2,4):
            for tag,prior,old_obs in [('wave','joint','observables'),('matched','partial','obs')]:
                with np.load(ROOT/f'carry-{tag}-{grid}-{sub}.npz') as a,np.load(pin(PRE,f'{prior}-{grid}-{sub}.npz')) as b:
                    assert a['t'][0]==b['t'][-1] and a['t'][-1]==END and np.all(np.diff(a['t'])>0)
                    for i in range(14):
                        assert error(a['obs'][0,:,i],b[old_obs][-1,:,i])<=.5
                    key='final_lag' if tag=='matched' else 'lag_end'
                    assert np.all(np.max(abs(a[key]-b[key]),axis=2)>0) and np.isfinite(a[key]).all()
    for setting in ('primary','time','angle'):
        with np.load(ROOT/f'photon-{setting}.npz') as ar:
            b=ar['hierarchy_at_entry'];n=len(ar['labels']);assert n==16 and b.shape[1]==3*n
            assert np.array_equal(b[:,:n],b[:,2*n:]) and not b[:,n:2*n].any() and b[2:,:n].any()
            assert ar['additivity_pct']<=.5
    s=json.loads((ROOT/'scores.json').read_bytes());assert s['prediction_hash']==sha(ROOT/'prediction-freeze.json') and len(s['rows'])==48
    assert len({(r['kind'],r['grid'],r['sub'],r['stress'],r['setting']) for r in s['rows']})==48
    assert all(r['pass_gap']==(max(r['route_gap_pct'])<=.5) and r['pass_size']==(max(r['size_pct_launch'])<=.163) for r in s['rows'])
    print('Verified source hashes, restarts, continued photon hierarchy, denominator thresholds and frozen result.')
if __name__=='__main__':
    verify()
    if 'seal' in sys.argv[1:]:
        check('restart-freeze.json')
        for tag in ('wave','matched'):
            with np.load(ROOT/f'incident-end-{tag}.npz') as end:
                assert end['t']==END and end['bins'].shape==(77,*end['common'].shape) and np.isfinite(end['bins']).all()
        assert (ROOT/'RESULTS.md').is_file() and not any(f.is_dir() for f in ROOT.iterdir())
        put('seal.json',dict(files={f.name:sha(f) for f in sorted(ROOT.iterdir()) if f.name!='seal.json'}))
        print(sha(ROOT/'seal.json'))
