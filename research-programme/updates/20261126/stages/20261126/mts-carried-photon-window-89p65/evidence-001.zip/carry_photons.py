from carry_io import *
from scipy.interpolate import CubicSpline
from scipy.linalg import solve_banded

def modules():
    sys.path.insert(0,str(PHOT));pin(PHOT,'predict.py');import predict as ph
    return ph

def new_sources(ph,at,labels):
    rows={};routes=('comp_momentum','comp_density','null_momentum','null_density')
    for grid in ('p16','p32'):
        for sub in (2,4):
            suffix=f'{grid}-{sub}.npz'
            with np.load(ROOT/('carry-matched-'+suffix)) as mat,np.load(ROOT/('carry-wave-'+suffix)) as ref:
                t=mat['t'];assert np.array_equal(t,ref['t']) and min(at.ravel())>=t[0] and max(at.ravel())<=t[-1]
                for j,label in enumerate(routes):
                    read=lambda arr,idx:ph.source_piece(t,arr[:,idx],j%2)(at)
                    rows[f'{grid}-{sub}-{label}']=read(mat['obs'],j)-read(ref['obs'],j%2)
    return np.stack([rows[label] for label in labels],axis=2)

def run():
    check('gravity-freeze.json');ph=modules();proj=ph.proj;gate=ph.gate
    original=ph.pinned
    ph.pinned=lambda folder,name: ph.track(pin(PRE,name)) if folder in (ph.MATCH,ph.WAVE) else original(folder,name)
    scale,eta,medium,peak,weights=proj.measure('heavy')
    with np.load(ROOT/'incident-matched-16.npz') as packet:k=packet['k'].item()
    with np.load(ph.track(ph.cell89.curve('p32','base'))) as packet:high=packet['eta']
    assert high[-1]==START
    cnt=round((END-START)/(high[-1]-high[-2]));forecast_grid=np.linspace(START,END,cnt+1)
    for setting in ph.SETTINGS:
        order,sub,stride=gate.transfer.prior.SETTINGS[setting]
        axis=np.unique(np.r_[proj.base_axis(scale,eta,sub),high[::stride],high[-1],forecast_grid[::stride],END])
        start,at,end=np.searchsorted(axis,[high[0],START,END]);assert np.array_equal(axis[[start,at,end]],[high[0],START,END])
        rates,nodes=proj.coefficients(axis,medium,k);bands=proj.transfer.stages(order)
        all_labels,all_kicks,all_phys=ph.source_bank(nodes[start:at])
        sel=[i for i,label in enumerate(all_labels) if '-comp_' in label or '-null_' in label]
        labels=[all_labels[i] for i in sel];assert len(labels)==16
        nk=len(labels);nc=3*nk;kicks=np.r_[all_kicks[sel],np.zeros(nk,complex),all_kicks[sel]]
        force=np.zeros((end-start,nodes.shape[1],nc,2),complex)
        force[:at-start,:,:nk]=all_phys[:,:,sel,:]
        force[at-start:,:,nk:2*nk]=new_sources(ph,nodes[at:end],labels)
        force[:,:,2*nk:]=force[:,:,:nk]+force[:,:,nk:2*nk]
        integ=np.diff(axis)[start:end,None,None,None]*np.einsum('st,ntch->nsch',proj.RAD,force)
        count=bands.shape[-1]//2;state=np.zeros((count,2*nc));right=np.empty((2*count,2*nc),order='F')
        state[0,::2]=4*kicks.real;state[0,1::2]=4*kicks.imag
        slots=np.full(len(axis),-1);pos=np.searchsorted(axis,eta);assert np.array_equal(axis[pos],eta);slots[pos]=np.arange(len(eta))
        spectra=np.zeros((len(scale),nc,2),complex)
        for begin in range(start,len(rates),48):
            guard();stop=min(begin+48,len(rates));matrices=(rates[begin:stop].reshape(-1,8)@bands.reshape(8,-1)).reshape(-1,11,2*count);matrices[:,5]+=1
            for step,mat in enumerate(matrices,begin):
                if step==at:
                    boundary=state[:,::2]+1j*state[:,1::2]
                    assert np.array_equal(boundary[:,:nk],boundary[:,2*nk:]) and not np.any(boundary[:,nk:2*nk])
                    assert np.any(boundary[1:,:nk])
                if step==end:terminal=state[:,::2]+1j*state[:,1::2]
                right[::2]=state;right[1::2]=state
                if step<end:
                    for row,col,factor in ((0,0,4.),(2,1,4*k/3),(4,1,4*k/3)):
                        driving=factor*integ[step-start,:,:,col]
                        right[row:row+2,::2]+=driving.real;right[row:row+2,1::2]+=driving.imag
                state=solve_banded((5,5),mat,right,check_finite=False)[1::2]
                if slots[step+1]>=0:spectra[slots[step+1]]=(state[[0,2],::2]+1j*state[[0,2],1::2]).T
        assert np.isfinite(spectra).all() and np.isfinite(terminal).all()
        residual=error(spectra[:,2*nk:]-spectra[:,:nk],spectra[:,nk:2*nk])
        assert residual<=.5
        adj=None
        if setting=='primary':
            active=(axis[:-1]>=axis[start])&(axis[1:]<=axis[end])
            dual,where,kern=proj.backward(axis,eta,weights,medium,k,proj.transpose_bands(bands),snapshot=[start],active=active)
            assert np.array_equal(where[active],nodes[start:end]);adj=4*kicks[:,None]*dual[start][0]+np.einsum('nhtj,ntch->cj',kern[active],force)
            assert np.max(abs(CubicSpline(scale,spectra)(peak)-adj)/abs(adj))<=.005
        pack('photon-'+setting+'.npz',scale=scale,labels=labels,previous=spectra[:,:nk],increment=spectra[:,nk:2*nk],cumulative=spectra[:,2*nk:],hierarchy_at_entry=boundary,hierarchy_at_exit=terminal,clock=[high[0],START,END],additivity_pct=residual)
        print('frozen channel vectors',setting,flush=True)
    put('photon-provenance.json',dict(inputs={**used,**ph.used},k=k,window=[START,END]))
    freeze('prediction-freeze.json',['PROTOCOL.md','gravity-freeze.json','carry_photons.py','score_window.py','photon-provenance.json']+[f'photon-{s}.npz' for s in ph.SETTINGS])
if __name__=='__main__':run()
