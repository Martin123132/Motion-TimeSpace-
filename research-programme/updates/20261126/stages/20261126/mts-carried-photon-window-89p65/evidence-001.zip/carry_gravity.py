from carry_io import *
from copy import copy
from scipy.integrate import solve_ivp
from scipy.interpolate import CubicSpline
from types import SimpleNamespace

def env_for(p,grid,sub,tag,bank,data,kernel):
    matched=tag=='matched'
    src=p.Host(grid,sub) if matched else copy(p.old.source(grid))
    host=src.matched if matched else src
    host.flow=copy(host.flow);src.flow=host.flow
    flow=src.flow
    assert np.log(START)>=flow.bg.t[0] and np.log(END)<=flow.bg.t[-1]
    flow.drive=CubicSpline(np.log(data['t']),data['S'][:,:,None],extrapolate=False)
    host.quads=lambda t:np.zeros((len(t),2),complex)
    host.stress=lambda t:np.zeros((len(t),4),complex)
    if matched:
        with np.load(pin(SOURCE,'exact-phase-extension.npz')) as ar:
            angle=CubicSpline(ar['heavy_efold'],ar['phase_h'],extrapolate=False)
            rho0=ar['matching_density'].item()
        with np.load(pin(PRE,f'partial-{grid}-{sub}.npz')) as prev:
            final_theta=prev['traces'][-1,0,9].real
            rho0_check=prev['traces'][-1,0,10].real*flow.bg(np.log(START))[flow.bgkeys.index('a')]
            assert abs(rho0/rho0_check-1)<1e-10
        scaleid=flow.bgkeys.index('a');hubid=flow.bgkeys.index('h')
        scale=lambda t:flow.bg(np.log(t))[...,scaleid]
        hub=lambda t:flow.bg(np.log(t))[...,hubid]
        last=src.osc(np.array([START]));mass=np.sqrt(last[1][0])/scale(START)
        ode=solve_ivp(lambda t,state:(state[1],-2*hub(t)*state[1]-(mass*scale(t))**2*state[0]),(START,END),[last[2][0],last[3][0]],rtol=2e-12,atol=[1e-16,1e-15],max_step=.0015,method='DOP853',dense_output=True)
        assert ode.success and np.array_equal(ode.y[:,0],[last[2][0],last[3][0]])
        src.osc=lambda t:(hub(t),(mass*scale(t))**2,*ode.sol(t))
        origin=angle(np.log(scale(START)))-final_theta
        shear_clock,curves,kk,_,_=kernel
        assert END<=shear_clock.x[-1] and kk==src.kk
        def coeff(t):
            tt=shear_clock(t);arr=np.zeros((len(t),5),complex);arr[:,4]=curves['shear'](tt)[:,0];return arr
        host.coeff[-1]=coeff
        prior=[]
        for name in ('fourth','partial'):
            with np.load(pin(PRE,f'{name}-{grid}-{sub}.npz')) as ar:
                tr=ar['traces'];prior.append(CubicSpline(tr[:,0,9].real,tr[:,:,0],extrapolate=False))
        assert prior[0].x[-1]==prior[1].x[0]
        def delayed(ph):
            assert min(ph)>=prior[0].x[0] and max(ph)<=prior[1].x[-1]
            a=ph<=prior[0].x[-1];values=np.empty((len(ph),4),complex);values[a]=prior[0](ph[a]);values[~a]=prior[1](ph[~a]);return values
        mem=SimpleNamespace(angle=angle,rho0=rho0,origin=origin,delayed=delayed)
    else:mem=None
    return src,mem

def evolve(p,src,mem,bank,grid,sub,label):
    matched=mem is not None
    name=('partial' if matched else 'joint')+f'-{grid}-{sub}.npz'
    with np.load(pin(PRE,name)) as old:
        assert old['t'][-1]==START
        keys=('final','final_lag','final_shape','final_memory') if matched else ('ordinary_end','lag_end','shape_end')
        states=[old[k].copy() for k in keys];previous=old['obs' if matched else 'observables'][-1]
        dt=old['t'][-1]-old['t'][-2]
    steps=int(round((END-START)/dt));assert steps==8*int(grid[1:])*sub
    t=np.linspace(START,END,steps+1)
    on=np.array([1.,1.,0.,0.]) if matched else np.zeros(2)
    grav=np.arange(len(on))%2==0;kk=src.kk;solver=p.old.Wave(src)
    observations=np.empty((len(t),len(on),14),complex);currents=np.empty((len(t),len(on),2),complex)
    identity=0.
    for left in range(0,steps,24):
        guard();end=min(left+24,steps);edges=t[left:end+1];clock=np.empty(2*len(edges)-1);clock[::2]=edges;clock[1::2]=(edges[:-1]+edges[1:])/2
        log=np.log(clock);vel,slow,kernel,weights=bank.coeff(clock);micro=bank.micro(log);spectral=bank.sw(log)
        mat,bi,bn=p.old.operator(solver,clock,clock);mat[:,:13,p.old.QI]+=bi;mat[:,:13,p.old.QN]+=bn
        op=mat[:,:,:p.old.DIM].copy();bias=mat[:,:,-1].copy()
        bg,den,we,wj,e0,j0,slip0,us,fq=p.coefficients(src,clock)
        hub=bg['h'];eg=bg['eg'];nus=4*bg['er']+bg['nuS'];vh=bg['hv'];mass2=(bg['a']*bg['hm'])**2
        if matched:
            a=bg['a'];loga=np.log(a);rho=mem.rho0/a
            rate_a=src.flow.bg(log,1)[:,src.flow.bgkeys.index('a')]/(clock*a)
            theta=mem.angle(loga)-mem.origin;speed=mem.angle(loga,1)*rate_a
            delay=mem.delayed(theta-np.pi);ext=src.external(log)[:,3];ext_rate=src.external(log,1)[:,3]/clock
            acc=-2*hub*vh-mass2*bg['hb']
        inject=np.zeros((len(clock),p.old.DIM))
        for idx,value in [(1,(4/3+bg['eb']/eg)*kk),(4,src.wave/3),(6,kk),(8,bg['sv']),(9,-(bg['a']*bg['sm'])**2*bg['sb']),(10,vh),(11,-mass2*bg['hb']),(12,-hub)]:inject[:,idx]=value
        def rhs(i,state,observe=False):
            nonlocal identity
            fields,lag,shape=state[:3]
            stress=bank.stress(lag,shape,kernel[i],weights[i])*bg['enu'][i];stress[:,1]*=src.wave
            en=fields@we[i]+e0[i]+stress[:,0];cur=fields@wj[i]+j0[i]+stress[:,1]
            extra=0
            if matched:
                wave=(kk*vh[i]*fields[:,10]+ext[i])/rho[i];memory=state[3]
                delta=memory[:,0]-wave;extra=on*rho[i]*delta;en+=on*rho[i]*memory[:,1];cur+=extra
            ep=(us[i]-en/2-1.5*hub[i]*cur/kk)/den[i];phi=np.where(grav,fields[:,12],ep)
            psi=phi+slip0[i]+(stress[:,2]-eg[i]*fields[:,p.old.QI]-nus[i]*fields[:,p.old.QN])/kk
            pd=cur/(2*kk)-hub[i]*psi+fq[i]
            if observe:
                const=lambda x:np.broadcast_to(x,phi.shape)
                return np.stack([phi,ep,fields[:,12],psi,pd,en,cur,const(us[i]),const(den[i]),const(hub[i]),*stress.T],axis=-1),np.stack((wave,const(theta[i])),axis=-1) if matched else np.zeros((2,2))
            live=fields.copy();live[:,12]=phi;dx=live@op[i].T+bias[i]+(stress[:,2]/kk)[:,None]*inject[i];dx[:,12]+=(stress[:,1]+extra)/(2*kk)
            identity=max(identity,error(dx[:,12],pd))
            normal=live[:,p.N_IND].copy();normal[:,0]+=phi
            dl=bank.bin_rhs(lag,shape,normal,psi,vel[i],slow[i],micro[i])
            result=[dx,dl,p.adv(shape,src.wave)+spectral[i]]
            if matched:
                mean_rate=speed[i]*(wave-delay[i])/np.pi
                wr=(kk*(acc[i]*fields[:,10]+vh[i]*dx[:,10])+ext_rate[i])/rho[i]+rate_a[i]*wave
                pressure=(mean_rate-wr+hub[i]*delta)/kk
                result.append(np.stack((mean_rate,-delta-3*hub[i]*pressure),axis=-1))
            return result
        for j,width in enumerate(np.diff(edges)):
            pos=2*j;observations[left+j],currents[left+j]=rhs(pos,states,True)
            a=rhs(pos,states);b=rhs(pos+1,[x+width*y/2 for x,y in zip(states,a)]);c=rhs(pos+1,[x+width*y/2 for x,y in zip(states,b)]);d=rhs(pos+2,[x+width*y for x,y in zip(states,c)])
            for x,aa,bb,cc,dd in zip(states,a,b,c,d):x+=width/6*(aa+2*bb+2*cc+dd)
        observations[end],currents[end]=rhs(len(clock)-1,states,True)
    seam=[error(observations[0,:,i],previous[:,i]) for i in range(14)]
    assert max(seam)<.5 and identity<.5 and np.isfinite(observations).all() and all(np.isfinite(x).all() for x in states),(label,grid,seam,identity)
    pack(f'carry-{label}-{grid}-{sub}.npz',t=t,obs=observations,seam=seam,rhs_identity_pct=identity,physical_current_phase=currents,**dict(zip(keys,states)))
    print(label,grid,sub,steps,'seam %',max(seam),'identity %',identity,flush=True)

def run():
    check('incident-freeze.json');inherited=prefix();p=inherited.import_at(inherited.OLD,'partial')
    sys.path.insert(0,str(KER));pin(KER,'wave_kernel.py');import wave_kernel
    for grid in ('p16','p32'):
        kernels=wave_kernel.read(grid)
        for tag in ('matched','wave'):
            bank=p.MatchedBank() if tag=='matched' else p.joint.Bank()
            with np.load(ROOT/f'incident-{tag}-16.npz') as data:
                assert np.array_equal(bank.q,data['q']) and bank.k==data['k']
                log=np.log(data['t']);bank.micro=CubicSpline(log,data['micro'],extrapolate=False);bank.sw=CubicSpline(log,data['Sw'],extrapolate=False)
                for sub in (2,4):
                    f=f'carry-{tag}-{grid}-{sub}.npz'
                    if not (ROOT/(f+'.receipt')).exists():
                        src,mem=env_for(p,grid,sub,tag,bank,data,kernels)
                        evolve(p,src,mem,bank,grid,sub,tag);freeze(f+'.receipt',[f,'carry_gravity.py','incident-freeze.json'])
                    check(f+'.receipt')
    files=[f'carry-{tag}-{g}-{s}.npz' for tag in ('matched','wave') for g in ('p16','p32') for s in (2,4)]
    put('gravity-inputs.json',used);freeze('gravity-freeze.json',files+['carry_gravity.py','gravity-inputs.json','incident-freeze.json'])
if __name__=='__main__':run()
