from carry_io import *
from types import SimpleNamespace
from scipy.interpolate import CubicSpline

def make(folder,label,intervals,engine):
    clock=np.linspace(START,END,4*intervals+1)
    with np.load(pin(folder,'material-halfstep/incident-input-heavy.npz')) as field,np.load(pin(folder,'material-halfstep/forcing-heavy.npz')) as body:
        old=field['eta'];keep=(old>=START-.12);assert np.array_equal(old,body['eta']) and END<=old[-1]
        ev=lambda v:CubicSpline(old[keep],v[...,keep],axis=-1,extrapolate=False)(clock)
        data=SimpleNamespace(eta=clock,model='heavy',nodes=field['k'],shell=np.array(json.loads(engine.angular12.pin('legs.json').read_bytes())['squared_radii']),
                     first={k:ev(field[k]) for k in ('phi','psi','pd')},background=dict(a=ev(body['background'][body['bgkeys'].tolist().index('a')])))
    mass=json.loads(engine.angular12.ti.parent.pin('radiation-background.json').read_bytes())['heavy']['mass_over_temperature']
    inc=SimpleNamespace(data=data,k=data.nodes,mass=mass);mapper=engine.angular12.Project(data);flight=engine.Flight32(inc);contract=engine.Contraction(mapper)
    with np.load(pin(folder,'common-heavy.npz')) as old:
        assert old['eta'][-1]==START
        start=old['end'].copy();assert np.max(abs(start[1]))<1e-20
        sample=flight.run(np.inf,start);common=contract.project(sample[:,0],sample[:,1],np.inf,mass)
        spectral=contract.project(sample[:,0],sample[:,0],np.inf,mass)-common
        controls=[error(common[:,0],old['S'][:,-1]),error(spectral[:,0],old['Sw'][:,-1])]
        oldS=old['S'][:,-1];oldSw=old['Sw'][:,-1]
    modes=[];momentum=[];seams=[]
    for idx in range(-52,25):
        guard()
        with np.load(pin(folder,f'micro-heavy-{idx}.npz')) as old:
            q=old['q'].item();assert q==2.**(idx/4)
            sample=flight.run(q,old['end']);direct=contract.project(sample[:,0],sample[:,1],q,mass);weight=5-q*np.tanh(q/2)
            seams.append(error(direct[:,0],old['source'][:,-1]+oldS+weight*oldSw));modes.append((direct-common-weight*spectral).T);momentum.append(q)
    assert max(controls+seams)<.5,(label,controls,max(seams))
    name=f'incident-{label}-{intervals}.npz'
    pack(name,t=clock[::4],S=common.T,Sw=spectral.T,micro=np.stack(modes,axis=1),q=momentum,k=mapper.ops[0][1],seams=seams,common_seams=controls)
    print(label,intervals,'seam',max(controls+seams),flush=True)

def main():
    inherited=prefix();engine=inherited.import_at(SOURCE,'incident89');files=[];tests={}
    for folder,label in ((FLUID,'matched'),(SOURCE,'wave')):
        for n in (8,16):
            f=f'incident-{label}-{n}.npz'
            if not (ROOT/f).exists():make(folder,label,n,engine)
            files.append(f)
        with np.load(ROOT/files[-2]) as lo,np.load(ROOT/files[-1]) as hi:
            assert np.allclose(lo['t'],hi['t'][::2],rtol=0,atol=2e-14)
            diff=[error(lo[key],hi[key][::2]) for key in ('S','Sw')]
            m=hi['micro'];fine=lo['micro'];denom=np.max(abs(m),axis=(0,2));assert min(denom)>0
            diff.append(100*np.max(np.max(abs(fine-m[::2]),axis=(0,2))/denom));tests[label]=diff
            assert max(diff)<.5,diff
    put('incident-controls.json',dict(refinements_pct=tests,inputs=used))
    freeze('incident-freeze.json',files+['PROTOCOL.md','incident-controls.json','incident_carry.py','carry_io.py'])
if __name__=='__main__':main()
