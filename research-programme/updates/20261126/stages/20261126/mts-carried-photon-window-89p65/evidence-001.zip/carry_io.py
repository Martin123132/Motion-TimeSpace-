from pathlib import Path
from functools import lru_cache
from io import BytesIO
import sys,hashlib,json
import numpy as np
ROOT=Path(__file__).resolve().parent
BASE=ROOT.parent
PRE=BASE/'mts-native-switch-source-and-photons-89p6-20261126'
SOURCE=BASE/'mts-photon-matter-89p6-20261124'
PAD=BASE/'mts-wave-stress-match-89p15-20261124'
FLUID=PAD/'fluid'
KER=BASE/'mts-wave-transfer-89p15-20261124'
PHOT=BASE/'mts-full-window-companion-photons-89p6-20261126'
START,END=89.6,89.65
PINS={PRE:'c42d28f230ca89ae248d7740911cb741ba32f261b261b4ff7e11e03a163d4661',SOURCE:'bc32739cb1aa9f24909005b4cfde0d6c056a9508b178a4e0fe126a9ba218a159',PAD:'c524e2a487341c78eabce05231c2ea706e1ce564e0d4696341ecd191341bdd91',KER:'31f9925322c86a7d9876cd31469a79dbb0f8bc1ae17acf2410c4486f9fdec962',PHOT:'41336c5e42fd6ea43be92f179f55ced551fd205bfcf883e6a5861e45e0728d2a'}
used={}
def sha(path):
    with path.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def guard():
    assert not any((p/'STOP-REQUESTED').exists() for p in (ROOT,BASE,*PINS))
@lru_cache()
def manifest(folder):
    assert sha(folder/'seal.json')==PINS[folder];return json.loads((folder/'seal.json').read_bytes())['files']
@lru_cache()
def pin(folder,name):
    if folder==FLUID:
        path=folder/name;ledger=json.loads(pin(PAD,'fluid/bank-heavy.json').read_bytes())
        h=ledger[name] if name in ledger else manifest(PAD)['fluid/'+name]
    else:
        path=folder/name;h=manifest(folder)[name]
    assert sha(path)==h,path;used[str(path.relative_to(BASE))]=h;return path
def save(name,data):
    guard();path=ROOT/name
    if path.exists():assert path.read_bytes()==data,name
    else:
        with path.open('xb') as f:f.write(data)
def put(name,val):
    save(name,(json.dumps(val,sort_keys=True,indent=2,allow_nan=False,default=lambda x:x.item())+'\n').encode())
def pack(name,**data):
    buf=BytesIO();np.savez_compressed(buf,**data);save(name,buf.getvalue())
def freeze(name,names):
    put(name,{n:sha(ROOT/n) for n in names})
def check(name):
    for n,sig in json.loads((ROOT/name).read_bytes()).items():assert sha(ROOT/n)==sig,n
def prefix():
    sys.path.insert(0,str(PRE));pin(PRE,'exact_source_stage.py')
    import exact_source_stage as inherited
    return inherited
def error(a,b):
    scale=np.max(abs(b));assert scale>0;return 100*np.max(abs(a-b))/scale
