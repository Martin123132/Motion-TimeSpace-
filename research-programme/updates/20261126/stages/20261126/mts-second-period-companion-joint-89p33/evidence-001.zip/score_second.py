import numpy as np
from scipy.interpolate import CubicSpline
from second import ROOT, first, source, locked, record, History


def power(t,values):
    return np.trapezoid(abs(values)**2,t,axis=0)


def pct(t,diff,scale):
    return float(100*np.sqrt(power(t,diff)/power(t,scale)))


def primitive(t,values):
    integral=CubicSpline(t,values,axis=0).antiderivative()
    return integral(t)-integral(t[0])


def metrics(segments):
    nums=[];dens=[];full=[];basis=[];trend=[];moves=[];samples=[]
    launch=segments[0][1][0]
    for t,val in segments:
        shadow=val[:,2];rate=val[:,4];energy=val[:,1]
        diff=CubicSpline(t,energy)(t,1)-rate
        nums.append(power(t,diff));dens.append(power(t,rate))
        gap=energy-shadow
        full.append(power(t,gap));basis.append(power(t,shadow))
        trend.append(power(t,gap-(launch[1]-launch[2])))
        moves.append(power(t,shadow-launch[2]))
        samples.append((t,diff))
    rms_rate=np.sqrt(sum(dens)/sum(t[-1]-t[0] for t,v in segments))
    crossing=[float(t[index]) for t,diff in samples for index in np.flatnonzero(100*abs(diff)/rms_rate>.5)[:1]]
    score=float(100*np.sqrt(sum(nums)/sum(dens)))
    return dict(rate_pct=score,rate_pass=score<=.5,full_pct=100*np.sqrt(sum(full)/sum(basis)),
                drift_pct=100*np.sqrt(sum(trend)/sum(moves)),peak_pct=100*max(max(abs(d)) for t,d in samples)/rms_rate,
                first_sample_over=min(crossing) if crossing else None,power_error=sum(nums),power_reference=sum(dens))


def score():
    locked("forecast-freeze.json");locked("protocol.json")
    results=[];controls=[];series={};restarts=[]
    for grid in ("p16","p32"):
        hist=History(grid)
        for sub in (2,4):
            with np.load(source(f"period-{grid}-{sub}.npz")) as left, np.load(ROOT/f"second-{grid}-{sub}.npz") as pack:
                t=pack["t"];old_t=left["t"];on=pack["obs"];old=left["obs"];tr=pack["traces"];pre=left["traces"]
                cut=pack["delay_cut"].item();cutl=pack["cut_left"];cutr=pack["cut_right"]
                assert old_t[-1]==t[0] and t[0]<cut<t[1]
                exact=all(np.array_equal(left[lk],pack[rk]) for lk,rk in
                          [("final","entry"),("final_lag","entry_lag"),("final_shape","entry_shape"),("routes","routes"),("q","q")])
                exact=exact and np.array_equal(pre[-1][:,[1,3]],pack["entry_memory"]) and np.array_equal(pack["entry_memory"],tr[0][:,[1,3]])
                assert exact and np.array_equal(tr[-1][:,[1,3]],pack["final_memory"])
                assert np.array_equal(old[-1,:,2],on[0,:,2]) and np.array_equal(pack["final"][:,12],on[-1,:,2])
                phase=tr[:,0,9].real;old_phase=pre[:,0,9].real
                assert np.all(tr[:,:,9]==phase[:,None]) and np.all(np.diff(phase)>0)
                assert abs(phase[0]-old_phase[-1])<1e-12
                past=phase-np.pi
                assert -1e-6<past[0]<0 and np.all((past[1:]>=0)&(past[1:]<=old_phase[-1]))
                restart=dict(grid=grid,sub=sub,other_side_prefix_duration=cut-t[0],start=t[0],end=t[-1],
                             cut=cut,end_delay_short_of_seam_rad=old_phase[-1]-past[-1],restart_exact=bool(exact))
                restarts.append(restart)
            with np.load(first.pinned(first.PAIR,f"matched-{grid}-{sub}.npz")) as saved:
                times=saved["t"];bounds=np.searchsorted(times,[t[0],t[-1]])
                assert np.array_equal(times[bounds[0]:bounds[1]+1],t) and np.array_equal(saved["corners"][:2],t[[0,-1]])
                target=saved["observables"][bounds[0]:bounds[1]+1].copy()
                target[0]=saved["seams"][0,1];target[-1]=saved["seams"][1,0]
            series[grid,sub]=(t,on,tr)
            for idx,label in enumerate(("momentum","density","disabled_momentum","disabled_density")):
                obs=on[:,idx];base=old[:,idx];src=tr[:,idx]
                one=[(old_t,base)];two=[(t,obs)]
                firstm,second,both=[metrics(interval) for interval in (one,two,one+two)]
                combine=100*np.sqrt((firstm["power_error"]+second["power_error"])/(firstm["power_reference"]+second["power_reference"]))
                assert abs(combine-both["rate_pct"])<1e-12
                results.append(dict(grid=grid,sub=sub,route=label,first=firstm,second=second,cumulative=both,
                                    curvature_jump_pct=100*abs((obs[0,1]-base[-1,1])/base[-1,2]),
                                    momentum_shadow_jump_pct=100*abs((obs[0,2]-base[-1,2])/base[-1,2])))
                previous=CubicSpline(old_phase,pre[:,idx,0],extrapolate=False)
                leave=np.r_[hist.past(past[0]),previous(past[1:])]
                assert np.array_equal(cutl[:,1],cutr[:,1]) and np.array_equal(cutl[:,3],cutr[:,3])
                incoming_area=hist.past.integrate(past[0],0)
                leaving_area=np.r_[0j,incoming_area+previous.antiderivative()(past[1:])-previous.antiderivative()(0.)]
                wave,avg,dj,de,pres,delay,mrate=src[:,:7].T
                exp_mean=avg[0]+(primitive(phase,wave)-leaving_area)/np.pi
                energy_work=(-1+3*(CubicSpline(t,obs[:,9])(t,1)-obs[:,9]**2)/hist.kk)*dj
                echeck=de[0]+primitive(t,energy_work)-3*(obs[:,9]*dj-obs[0,9]*dj[0])/hist.kk
                pcheck=(mrate-CubicSpline(t,wave)(t,1)+obs[:,9]*dj)/hist.kk
                current=src[:,12]+(src[:,10]*avg if idx<2 else src[:,11])
                checks=dict(grid=grid,sub=sub,route=label,delayed_owner_pct=pct(t,delay-leave,leave),
                            prefix_limit_pct=100*abs((cutl[idx,5]-hist.past(0))/hist.past(0)),
                            live_limit_pct=100*abs((cutr[idx,5]-pre[0,idx,0])/pre[0,idx,0]),
                            mean_integral_pct=pct(t,avg-exp_mean,avg),current_ledger_pct=pct(t,obs[:,6]-current,obs[:,6]),
                            density_balance_pct=pct(t,de-echeck,de),pressure_balance_pct=pct(t,pres-pcheck,pres),
                            shadow_check_pct=pct(t,obs[:,2]-obs[0,2]-primitive(t,obs[:,4]),obs[:,2]-obs[0,2]))
                if idx>=2:
                    checks["null_replay_pct"]=max(pct(t,obs[:,i]-target[:,idx-2,i],target[:,idx-2,i]) for i in range(obs.shape[-1]))
                controls.append(checks)
    refinements=[]
    for low,high in [(("p16",2),("p16",4)),(("p32",2),("p32",4)),(("p16",4),("p32",4))]:
        t,val,src=series[low];u,control,inp=series[high]
        for idx,label in enumerate(("momentum","density")):
            delta=CubicSpline(t,val[:,idx,1])(t,1)-val[:,idx,4]
            ref=CubicSpline(u,control[:,idx,1])(u,1)-control[:,idx,4]
            vals={}
            for tag,small,fine in [("rate_residual",delta,ref)]+[(label,src[:,idx,k],inp[:,idx,k]) for k,label in [(2,"comp_current"),(3,"comp_density"),(4,"comp_pressure")]]:
                target=CubicSpline(u,fine)(t)
                vals[tag]=pct(t,small-target,target)
            refinements.append(dict(low=list(low),high=list(high),route=label,**vals))
    record("results.json",dict(tolerance_pct=.5,rows=results,restarts=restarts,controls=controls,refinements=refinements))
    for r in results:
        print(r["grid"],r["sub"],r["route"],*(round(r[k]["rate_pct"],7) for k in ("first","second","cumulative")))
    print("maximum control", max(v for row in controls for k,v in row.items() if k.endswith("_pct")),flush=True)


if __name__=="__main__":
    score()
