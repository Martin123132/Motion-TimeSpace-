from fluid_control import control_path
from project import *

def read(name):
    with np.load(ROOT/name) as ar:return {key:ar[key] for key in ar.files}
def stats(value,target):
    error=np.abs(value-target);norm=np.max(np.abs(target),axis=0)
    mask=norm!=0
    rates=100*np.max(error,axis=0)[mask]/norm[mask]
    return dict(peak_error_pct=100*np.max(error)/max(norm),rms_pct=100*np.linalg.norm(error)/np.linalg.norm(target),worst_mode_pct=max(rates),median_mode_pct=np.median(rates),modes_over=int(sum(rates>.5)),zero_count=int(sum(~mask)))
def report_energy(values,target):
    return {name:stats(values[:,index],target[:,index]) for name,index in [('energy',0),('current',1)]}
def G0(tag,tc,k):
    with np.load(pin(tag+'-metric.npz')) as ar:
        t=ar['time'];sel=t>prev.native.switch();geo=ar['metric'][sel,1]
    h=CubicSpline(t[sel],geo).antiderivative();inv=CubicSpline(t[sel],1/geo).antiderivative()
    return np.exp(-(h(tc)-h(tc[0]))-k**2*(inv(tc)-inv(tc[0]))/3)
def verdict(tag):
    primary=read(tag+'-1-4-7.npz');refined=read(tag+'-2-4-7.npz');order=read(tag+'-1-6-9.npz')
    with np.load(pin(tag+'-prediction.npz')) as ar:
        assert np.array_equal(ar['centers'],primary['time']) and np.array_equal(ar['k'],primary['k'])
        target=ar['average'].transpose(0,2,1)[:,[0,2]]
    mean=primary['mean'];tj=target[:,1];budget=primary['budget'];corr=primary['i_terms'].sum(1)
    change=np.diff(target,axis=0)
    comparisons={}
    for name,terms in [('full',[0,1,2,3]),('without_commutator',[0,2,3]),('without_work',[0,1,3]),('without_edge',[0,1,2]),('uncorrected_mean',[0]),('scale_interpolation_included',[0,1,2,3,4])]:
        val=budget[:,terms].sum(1)[:,1:];comparisons[name]=report_energy(val,change)
    frac=lambda x,y:stats(x+y,y)
    parts={str(idx):frac(primary['i_terms'][:,idx],corr) for idx in range(3)}
    finer=refined['i_terms'].sum(1);fineerr=np.max(abs(corr-finer),axis=0)
    ordercorr=order['i_terms'].sum(1)
    summary=dict(centers=primary['time'][[0,-1]].tolist(),cycles=primary['phase_span']/(2*np.pi),events=int(sum(primary['jumps'])),
        replay=report_energy(mean[:,1:3],target),budget=comparisons,
        required_current_on_mean=frac(corr,tj),required_current_on_mean_drift=frac(corr,tj-tj[0]),
        required_current_size=float(np.max(abs(corr))),current_from_energy=stats(primary['direct']-tj,corr),
        temporal_sampling_change_on_required=stats(finer,corr),quadrature_derivative_change_on_required=stats(ordercorr,corr),
        above_10x_finer_change=int(sum(np.max(abs(corr),axis=0)>10*fineerr)),term_sizes_pct_on_required=parts)
    if tag=='matched':
        with np.load(control_path()) as ar:
            assert np.array_equal(ar['k'],primary['k']) and np.array_equal(ar['matched-eta'],primary['time'])
            fluid=ar['matched-native-fluid'];den,press,j=fluid.transpose(2,0,1)
        add0=G0(tag,primary['time'],primary['k'])*(j[0]-tj[0])
        diff=j-tj
        src=read('native-density-only.npz')
        numbers=dict(mean_j_vs_native=stats(tj,j),mean_energy_vs_native=stats(target[:,0],den),mean_pressure_vs_native=stats(mean[:,4],press),
                     current_with_repair_vs_native=stats(tj+corr,j),
                     free_launch_on_gap=stats(add0,diff),coldstart_correction_on_gap=stats(corr,diff),
                     adjusted_correction_on_gap=stats(corr+add0,diff),forced_correction_on_forced_gap=stats(corr,diff-add0),
                     current_control=stats(src['j5'],j),pressure_control=stats(src['p5'],press),
                     control_drift=stats(src['j5']-j[0],j-j[0]),control_on_gap=stats(src['j5']-tj,diff),
                     density_only_degree3=stats(src['j3'],j),density_only_degree7=stats(src['j7'],j))
        summary['native_matched']=numbers
        pack('native-contrast.npz',k=primary['k'],time=primary['time'],native_minus_projected=diff,initial=add0,current=corr,
             unresolved=diff-corr-add0,direct_energy_control_error=src['j5']-j)
    return summary

def run():
    check('budget-freeze.json');check('native-control-freeze.json')
    summary={tag:verdict(tag) for tag in ('wave','matched')}
    put('scores.json',summary)
    for tag,row in summary.items():
        print(tag,'cycles',row['cycles'],'balance (peak, worst)',[(key,res['peak_error_pct'],res['worst_mode_pct']) for key,res in row['budget']['full'].items()])
        for key in ('required_current_on_mean','required_current_on_mean_drift','current_from_energy','temporal_sampling_change_on_required','quadrature_derivative_change_on_required'):
            r=row[key];print(key,*(round(r[score],7) for score in ('peak_error_pct','median_mode_pct','worst_mode_pct')),r['modes_over'])
    for key,row in summary['matched']['native_matched'].items():print(key,*(round(row[s],7) for s in ('peak_error_pct','worst_mode_pct')),row['modes_over'])
if __name__=='__main__':run()
