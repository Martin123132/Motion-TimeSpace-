from early_test import *

def run():
    check('prepared-predictions.json')
    with np.load(control_path()) as ar:
        t=ar['matched-eta'];truth=ar['matched-native-fluid'][:,:,[0,2]].transpose(0,2,1)
    hist=read('contrast-1-2.npz');q=read('prepared-predictions.npz');ref=read('native-inverse-target.npz')['moments'][:,:2];k=q['k'];tc=q['time'];idx=np.searchsorted(t,tc)
    with np.load(early_pin('matched-early.npz')) as ar:cut=ar['cut'].item();cut_native=ar['fluid'];mass=ar['mass'].item()
    with np.load(pin('matched-metric.npz')) as ar:
        tm=ar['time'];choose=tm>prev.native.switch();geo=make_interp_spline(tm[choose],ar['metric'][choose,:2],k=5)
    with np.load(pin('preparation.npz')) as ar:seed=np.stack([ar['density'],ar['momentum']])
    def rhs(time,flat):
        a,H=geo(time);X=source(time);r=(k/(a*mass))**2;c=r/(np.sqrt(1+r)+1)**2
        E,J=flat.reshape(2,-1);P=c*(E+3*H*J/k)
        return np.stack([-3*H*P-k*J-X,-H*J+k*P]).ravel()
    with np.load(pin('matched-metric.npz')) as ar:source=make_interp_spline(tm[choose],ar['metric'][choose,2],k=5)
    sol=solve_ivp(rhs,(prev.native.switch(),cut),seed.ravel(),t_eval=[cut],rtol=1e-12,atol=1e-16,max_step=1/1280,method='DOP853')
    assert sol.success;cut_error=sol.y[:,-1].reshape(2,-1)-cut_native
    def transport(time,flat):
        a,H=geo(time);r=(k/(a*mass))**2;c=r/(np.sqrt(1+r)+1)**2
        E,J=flat.reshape(2,-1);P=c*(E+3*H*J/k);return np.stack([-3*H*P-k*J,-H*J+k*P]).ravel()
    sol=solve_ivp(transport,(cut,tc[-1]),cut_error.ravel(),rtol=1e-12,atol=1e-22,t_eval=tc,max_step=1/320,method='DOP853')
    assert sol.success;carry=sol.y.T.reshape(len(tc),2,-1)
    floor=hist['fluid'][idx]-truth[idx];gap=truth[idx]-ref
    tf=hist['channels'][:,6:8].transpose(0,3,2,1);mats=tf[idx]
    init=np.linalg.solve(mats[0],floor[0].T[:,:,None])
    late=(mats@init)[:,:,:,0].transpose(0,2,1)
    norm=np.max(abs(gap),axis=0)
    total=(100*np.max(abs(floor),axis=0)/norm)>.5
    metrics={}
    parts={'through_cutoff':carry,'cutoff_to_first_center':late-carry,'within_scored_window':floor-late}
    for n,val in parts.items():
        rate=100*np.max(abs(val),axis=0)/norm
        metrics[n]=dict(over_on_existing_fail=(total&(rate>.5)).sum(1).tolist(),projection_on_full_error=(100*np.sum(val*floor,axis=(0,2))/np.sum(floor*floor,axis=(0,2))).tolist(),peak_pct_on_contrast=(100*np.max(abs(val),axis=(0,2))/np.max(norm,axis=1)).tolist())
    put('error-clock.json',dict(total_fail=total.sum(1).tolist(),segments=metrics,cut_error_absolute_peak=np.max(abs(cut_error),axis=1).tolist()))
    print(metrics)
if __name__=='__main__':run()
