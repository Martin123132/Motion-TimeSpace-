from score import *
import csv,io

def run():
    check('prepared-predictions.json')
    pred=read('prepared-predictions.npz');old=read('past-input-physical.npz');ref=read('native-inverse-target.npz')
    with np.load(control_path()) as ar:
        idx=np.searchsorted(ar['matched-eta'],pred['time']);fluid=ar['matched-native-fluid'][idx][:,:,[0,2]].transpose(0,2,1)
    cap=read('contrast-1-2.npz')['fluid'][idx];wave=ref['moments'][:,:2];target=fluid-wave
    forecasts=dict(legacy=old['direct'],continuous=pred['fluid']-pred['continuous'][:,:2],retained=pred['fluid']-pred['retained'][:,:2],known_metric_fluid_error_control=cap-wave)
    relative=lambda forecast:100*np.max(abs(forecast-target),axis=0)/np.max(abs(target),axis=0)
    scores={key:report_energy(value,target) for key,value in forecasts.items()}
    ledger=io.StringIO(newline='');output=csv.writer(ledger,lineterminator='\n')
    output.writerow(['k_per_Mpc','energy_contrast_peak','current_contrast_peak',*[f'{key}_{var}_percent' for key in forecasts for var in ['energy','current']]])
    data=[relative(value) for value in forecasts.values()]
    for ix,k in enumerate(pred['k']):
        output.writerow([k,*np.max(abs(target[:,:,ix]),axis=0),*[rate for item in data for rate in item[:,ix]]])
    parent.save(ROOT/'retained-mode-ledger.csv',ledger.getvalue().encode())
    failures=data[2]>.5;ctrl=data[3]>.5
    summary=dict(same_reference=scores,retained_failing_modes=int(failures.any(0).sum()),both=int(failures.all(0).sum()),
         also_fail_known_metric_fluid_only=(failures&ctrl).sum(1).tolist(),worst_modes=[pred['k'][r.argmax()] for r in data[2]],
         direct_target_replay_max_pct=ref['field_error_pct'].max())
    put('ledger.json',summary)
    print('same-target:',[(key,[(round(s['peak_error_pct'],6),s['modes_over']) for s in row.values()]) for key,row in scores.items()],summary['also_fail_known_metric_fluid_only'],summary['retained_failing_modes'])
if __name__=='__main__':run()
