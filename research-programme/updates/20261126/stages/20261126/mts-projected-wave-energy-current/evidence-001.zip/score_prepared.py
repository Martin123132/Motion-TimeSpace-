from score import *
def run():
    check('prepared-predictions.json');fore=read('prepared-predictions.npz');native=read('native-inverse-target.npz')
    with np.load(control_path()) as ar:
        idx=np.searchsorted(ar['matched-eta'],fore['time']);truth=ar['matched-native-fluid'][idx][:,:,[0,2]].transpose(0,2,1)
    assert np.array_equal(native['time'],fore['time']) and np.array_equal(native['k'],fore['k'])
    targets={'retained':native['moments']}
    with np.load(pin('matched-prediction.npz')) as ar:targets['continuous']=ar['average'][idx][:,:,[0,2,1]].transpose(0,2,1)
    results={}
    for tag,ref in targets.items():
        val=fore[tag];fluid=fore['fluid'];gap=truth-ref[:,:2]
        fc=fluid-val[:,:2];error=fc-gap
        comp=dict(fluid=fluid-truth,wave=ref[:,:2]-val[:,:2])
        signed={name:(100*np.sum(data*error,axis=(0,2))/np.sum(error*error,axis=(0,2))).tolist() for name,data in comp.items()}
        results[tag]=dict(gap=report_energy(fc,gap),projected_absolute=report_energy(val[:,:2],ref[:,:2]),fluid_absolute=report_energy(fluid,truth),
             pressure=stats(val[:,2],ref[:,2]),wrong_convention_gap=report_energy(fc,truth-targets['continuous' if tag=='retained' else 'retained'][:,:2]),
             signed_on_remaining_error_energy_current=signed,
             initial_gap_peak=np.max(abs(gap[0]),axis=1).tolist(),true_peak=np.max(abs(gap),axis=(0,2)).tolist())
        print(tag,[(round(n['peak_error_pct'],7),round(n['worst_mode_pct'],7),n['modes_over']) for n in results[tag]['gap'].values()],signed)
    put('prepared-scores.json',results)
if __name__=='__main__':run()
