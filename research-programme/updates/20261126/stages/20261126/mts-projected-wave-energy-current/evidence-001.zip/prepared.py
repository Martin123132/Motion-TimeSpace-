from early_test import *
def run():
    check('entry-freeze.json');guard()
    native_files=[pin(n) for n in ('inverse.npz','native-map.npz','preparation.npz','matched-metric.npz')]
    freeze('prepared-method.json',[ROOT/'prepared.py',ROOT/'PREPARED.md',ROOT/'native_reference.py',ROOT/'entry-freeze.json',*native_files])
    with np.load(early_pin('matched-ordinary-physical.npz')) as ar:
        times=ar['time'];centers=ar['centers'];asc=ar['scale'];H=ar['hub'];X=ar['force'];k=ar['k']
    cut=times[0];sw=prev.native.switch()
    with np.load(pin('matched-metric.npz')) as ar:
        s=ar['time']<=cut;tp=ar['time'][s];saved=ar['metric'][s,:3];m=ar['mass'].item();b,v=ar['background'];assert np.array_equal(ar['k'],k)
    with np.load(pin('preparation.npz')) as ar:
        fluid0=np.stack([ar['density'],ar['momentum']]);rho=ar['rho'].item()
    y=[np.full_like(k,b),np.full_like(k,v)]
    for path in native_files[:2]:
        with np.load(path) as ar:coef=ar['c'];y.extend([coef[:,0],coef[:,1]*m*saved[0,0]])
    state=np.array(y)
    def segment(left,right,geom,y0,mesh):
        count=len(y0)
        def rhs(t,flat):
            a,h,x=geom(t);b,v,f,w,g,r=flat.reshape(count,-1)[:6];m2=(m*a)**2
            out=[v,-2*h*v-m2*b,w,-2*h*w-(m2+k*k)*f-v*x,r,-2*h*r-(m2+k*k)*g-v*x]
            if count==8:
                E,J=flat.reshape(count,-1)[6:];rr=k*k/m2;cs=rr/(np.sqrt(1+rr)+1)**2;P=cs*(E+3*h*J/k)
                out.extend([-3*h*P-k*J-x,-h*J+k*P])
            return np.array(out).ravel()
        sol=solve_ivp(rhs,(left,right),y0.ravel(),method='DOP853',t_eval=mesh,rtol=1e-12,atol=3e-17,max_step=1/640)
        assert sol.success;return sol.y.T.reshape(-1,count,len(k))
    before=tp<sw;after=tp>sw
    state=segment(tp[0],sw,make_interp_spline(tp[before],saved[before],k=5),state,[sw])[-1]
    state=segment(sw,cut,make_interp_spline(tp[after],saved[after],k=5),np.vstack([state,fluid0]),[cut])[-1]
    ah,xh,fx=(make_interp_spline(times,val,k=5) for val in [asc,H,X])
    hist=segment(cut,times[-1],lambda t:(ah(t),xh(t),fx(t)),state,times)
    phase=CubicSpline(times,m*asc).antiderivative()(times)
    out={};mass2=(m*asc[:,None])**2;bg=hist[:,0];vel=hist[:,1]
    for label,idx in [('continuous',2),('retained',4)]:
        f=hist[:,idx];w=hist[:,idx+1];vals=asc[:,None,None]/rho*np.stack([vel*w+mass2*bg*f,k*vel*f,vel*w-mass2*bg*f],axis=1)
        projected=[]
        for tc in centers:
            pos=np.flatnonzero(times==tc).item();u=(phase-phase[pos])/(6*np.pi);mask=abs(u)<1;ang=phase[mask];u=u[mask]
            design=np.column_stack([u**d for d in range(9)]+[u**d*trig(2*ang) for d in range(7) for trig in (np.cos,np.sin)]+[u**d*trig(4*ang) for d in range(3) for trig in (np.cos,np.sin)])
            weight=np.linalg.pinv(design)[0];projected.append(np.einsum('t,tdk->dk',weight,vals[mask]))
        out[label]=projected
    fluid=hist[np.searchsorted(times,centers),6:8]
    pack('prepared-predictions.npz',time=centers,k=k,fluid=fluid,cut=cut,state_at_cut=state,**out)
    freeze('prepared-predictions.json',[ROOT/'prepared-method.json',ROOT/'prepared-predictions.npz',early_pin('matched-ordinary-physical.npz')])

if __name__=='__main__':run()
