from score import report_energy,read,stats
from project import *
from scipy.integrate import solve_ivp
from fluid_control import control_path

EARLY=ROOT.parent/'mts-causal-pressure-envelope-90p4-20261126'
def early_pin(name):
    assert sha(EARLY/'seal.json')=='06acf2fbc000333a93a049a2719a6d5c1b3ac074053daf3ae13f26dcd5b21758'
    result=EARLY/name;assert sha(result)==json.loads((EARLY/'seal.json').read_bytes())['files'][name]
    return result

def predict(variant):
    with np.load(early_pin('matched-early.npz')) as ar:
        seed=ar['seed'];fluid0=ar['fluid'];mass=ar['mass'].item();cut=ar['cut'].item();k=ar['grid']
    with np.load(early_pin('matched-ordinary-'+variant+'.npz')) as ar:
        assert np.array_equal(k,ar['k']);time=ar['time'];tc=ar['centers'];a=ar['scale'];H=ar['hub'];X=ar['force'];mom=ar['mom'];p0=-ar['correction'];ending=ar['ending']
        assert time[0]==cut and np.all(ar['window_edges'][:,0]>cut)
    spline=lambda array:make_interp_spline(time,array,k=5)
    scale=spline(a);hub=spline(H);force=spline(X);zero=np.zeros_like(k)
    def rates(t,state):
        b,p,l,e,j=state.reshape(5,-1);h=hub(t);mu=mass*scale(t);q=(k/mu)**2;c=q/(np.sqrt(1+q)+1)**2;pres=c*(e+3*h*j/k)
        return np.stack([-3*h*p,-3*h*b-2*mu*l,2*mu*p,-3*h*pres-k*j-force(t),-h*j+k*pres]).ravel()
    result=solve_ivp(rates,(cut,time[-1]),np.concatenate([seed[:3],fluid0]).ravel(),rtol=1e-12,atol=5e-17,method='DOP853',max_step=1/640,t_eval=time)
    assert result.success
    sol=result.y.T.reshape(len(time),5,-1)
    replay=100*np.max(abs(sol[-1]-ending[[0,1,2,10,11]]),axis=1)/np.max(abs(ending[[0,1,2,10,11]]),axis=1)
    phase=CubicSpline(time,mass*a).antiderivative()(time)
    direct=[];enthalpy=[]
    for ix,t in enumerate(tc):
        ii=np.flatnonzero(time==t).item();q=phase-phase[ii];sel=abs(q)<6*np.pi;v=phase[sel];u=q[sel]/(6*np.pi)
        arr=np.column_stack([u**d for d in range(9)]+[u**d*fn(2*v) for d in range(7) for fn in (np.cos,np.sin)]+[u**d*fn(4*v) for d in range(3) for fn in (np.cos,np.sin)])
        weight=np.linalg.pinv(arr)[0];enthalpy.append(weight@(sol[sel,0]+sol[sel,1]-1))
        direct.append(sol[ii,3:]-mom[ix,:2])
    direct=np.array(direct);closed=make_interp_spline(tc,p0,k=5);ambient=make_interp_spline(tc,np.array(enthalpy),k=5)
    init=np.zeros((5,2,len(k)));init[0]=direct[0];init[3,0]=1;init[4,1]=1
    def rhs(t,y):
        state=y.reshape(init.shape);h=hub(t);rr=(k/(mass*scale(t)))**2;c=rr/(np.sqrt(1+rr)+1)**2
        pr=c*(state[:,0]+3*h*state[:,1]/k);out=np.stack([-3*h*pr-k*state[:,1],-h*state[:,1]+k*pr],axis=1)
        p=closed(t);out[1,0]-=3*h*p;out[1,1]+=k*p;out[2,0]+=ambient(t)*force(t)
        return out.ravel()
    fc=solve_ivp(rhs,(tc[0],tc[-1]),init.ravel(),rtol=1e-12,atol=2e-18,t_eval=tc,max_step=1/640,method='DOP853')
    assert fc.success
    name='past-input-'+variant+'.npz';pack(name,time=tc,k=k,cut=cut,direct=direct,channels=fc.y.T.reshape(len(tc),*init.shape),end_replay_pct=replay,pressure=p0,enthalpy=enthalpy)
    return ROOT/name

def score():
    check('past-input-freeze.json')
    with np.load(control_path()) as ar:native=ar['matched-native-fluid'][:,:,[0,2]].transpose(0,2,1);times=ar['matched-eta']
    mean=read('matched-1-4-7.npz')['mean'][:,1:3];data=read('contrast-1-2.npz');tf=data['channels'][:,6:8].transpose(0,3,2,1)
    rows={}
    for variant in ('physical','fine'):
        r=read('past-input-'+variant+'.npz');select=np.searchsorted(times,r['time']);assert np.array_equal(times[select],r['time'])
        target=(native-mean)[select];mats=tf[select];assert np.min(np.linalg.det(mats))>.98
        init=np.linalg.solve(mats[0],target[0].T[:,:,None])
        inherited=(mats@init)[:,:,:,0].transpose(0,2,1);forced=target-inherited;ch=r['channels']
        p=ch[:,1];h=ch[:,2];val=dict(direct=report_energy(r['direct'],target),all_three=report_energy(ch[:,:3].sum(1),target),
                   pressure_only_forced=report_energy(p,forced),pressure_plus_enthalpy_forced=report_energy(p+h,forced),
                   inherited_only=report_energy(ch[:,0],target),own_channel_replay=report_energy(ch[:,:3].sum(1),r['direct']),end_replay_pct=r['end_replay_pct'].tolist())
        physical=read('past-input-physical.npz')
        val['refinement_on_forced']=report_energy(p+h,physical['channels'][:,1:3].sum(1))
        rows[variant]=val
    put('past-input-scores.json',rows)
    for key,row in rows['physical'].items():
        if isinstance(row,dict):print(key,[(var,round(n['peak_error_pct'],6),round(n['worst_mode_pct'],6),n['modes_over']) for var,n in row.items()])
    print('terminal replay',rows['physical']['end_replay_pct'])

if __name__=='__main__':
    check('contrast-freeze.json')
    files=[predict(v) for v in ('physical','fine')]
    freeze('past-input-freeze.json',[ROOT/'EARLY.md',ROOT/'early_test.py',ROOT/'contrast-freeze.json',*[early_pin(n) for n in ('ordinary.py','forecast.py','matched-early.npz','matched-ordinary-physical.npz','matched-ordinary-fine.npz')],*files])
    score()
