from pathlib import Path
import hashlib,json,sys
import numpy as np
from scipy.interpolate import CubicSpline
ROOT_HERE=Path(__file__).resolve().parent
OLD=ROOT_HERE.parent/'mts-prepared-quadrature-inverse-90p4-20261126'
def digest(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
assert digest(OLD/'seal.json')=='8b191e3b559690de4266bdf4b2d3324f1d815f67a597d0935a27122413bb0c41'
for key in ('reconstruct.py','inverse_io.py','matched-metric.npz','native-map.npz','matched-native-prepared-sources.npz','preparation.npz'):
    assert digest(OLD/key)==json.loads((OLD/'seal.json').read_bytes())['files'][key]
sys.path.insert(0,str(OLD))
import reconstruct as rec
assert Path(rec.__file__).parent==OLD
def run():
    for n,sha in json.loads((ROOT_HERE/'prepared-predictions.json').read_bytes()).items():assert digest(ROOT_HERE.parent/n)==sha
    rec.guard();assert not (ROOT_HERE/'STOP-REQUESTED').exists()
    metric=rec.unpack(OLD/'matched-metric.npz');coeff=rec.unpack(OLD/'native-map.npz')['c'];rho=rec.unpack(OLD/'preparation.npz')['rho'].item()
    state,geo,_=rec.propagate(metric,'matched',1/640,coeff)
    with np.load(OLD/'matched-native-prepared-sources.npz') as ar:
        ref=ar['field'];assert np.array_equal(ar['time'],rec.FINE[::2]);abs_err=np.max(abs(state[::2,2:]-ref),axis=0);field_err=100*abs_err/np.max(abs(ref),axis=0)
    assert field_err.max()<1e-7
    bg,vel,f,w=state.transpose(1,0,2);k=metric['k'];a=geo[:,0];m=metric['mass'].item();mm=(m*a)**2
    moments=np.stack([vel*w+mm*bg*f,k*vel*f,vel*w-mm*bg*f],axis=1)*a[:,None,:]/rho
    phase=CubicSpline(rec.FINE,m*a[:,0]).antiderivative();theta=phase(rec.FINE)-phase(rec.LEFT)
    with np.load(ROOT_HERE/'prepared-predictions.npz') as ar:tc=ar['time']
    data=[]
    for tm in tc:
        i=np.flatnonzero(rec.FINE==tm).item();take,weight=rec.weights(theta,theta[i],6,8,1)
        data.append(rec.projected(moments,take,weight))
    from io import BytesIO
    buf=BytesIO();np.savez_compressed(buf,k=k,time=tc,moments=data,field_error_pct=field_err)
    raw=buf.getvalue();path=ROOT_HERE/'native-inverse-target.npz'
    if path.exists():assert digest(path)==hashlib.sha256(raw).hexdigest()
    else:
        tmp=path.with_suffix('.partial')
        with tmp.open('xb') as f:f.write(raw)
        tmp.rename(path)
    print('Archived native prepared fields independently replayed, max relative percent:',field_err.max())
if __name__=='__main__':run()
