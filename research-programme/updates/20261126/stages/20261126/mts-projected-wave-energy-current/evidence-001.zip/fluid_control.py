from project import *

POP=ROOT.parent/'mts-matched-microscopic-population-90p4-20261126'
def control_path():
    assert sha(POP/'seal.json')=='31c063ddda4781779017bbc4326af6b29083acc5aaeea6f683d840ad6c40a827'
    path=POP/'projection-comparison.npz'
    assert sha(path)==json.loads((POP/'seal.json').read_bytes())['files'][path.name]
    return path

def run():
    check('budget-freeze.json')
    with np.load(control_path()) as ar:
        k=ar['k'];t=ar['matched-eta'];e=ar['matched-native-fluid'][:,:,0];start=ar['matched-native-fluid'][0,:,2]
    with np.load(pin('matched-metric.npz')) as ar:
        assert np.array_equal(ar['k'],k)
        times=ar['time'];metric=ar['metric'][:,:3];use=times>prev.native.switch()
    geo=make_interp_spline(times[use],metric[use],k=5);gx,gw=leggauss(8)
    pack('native-density-input.npz',k=k,time=t,e=e,initial_current=start)
    out={}
    for degree in (3,5,7):
        energy=make_interp_spline(t,e,k=degree)
        hist=[start];press=[]
        for left,right in zip(t[:-1],t[1:]):
            tt=(right+left)/2+(right-left)*gx/2;weights=(right-left)*gw/2
            H,X=geo(tt)[:,1:].transpose(1,0,2);A=k/(3*H)
            def G(start):
                grid=(right+start[:,None])/2+(right-start[:,None])*gx/2
                hh=geo(grid)[:,:,1]
                return np.exp(-(right-start)[:,None]/2*np.einsum('g,tgk->tk',gw,hh+k*k/(3*hh)))
            hist.append(G(np.array([left]))[0]*hist[-1]+np.einsum('t,tk->k',weights,G(tt)*(-A*(energy(tt,1)+X))))
        H,X=geo(t)[:,1:].transpose(1,0,2)
        out['j'+str(degree)]=np.array(hist);out['p'+str(degree)]=(-energy(t,1)-k*hist-X)/(3*H)
    pack('native-density-only.npz',**out)
    freeze('native-control-freeze.json',[ROOT/'fluid_control.py',ROOT/'budget-freeze.json',ROOT/'native-density-input.npz',ROOT/'native-density-only.npz',control_path()])
if __name__=='__main__':run()
