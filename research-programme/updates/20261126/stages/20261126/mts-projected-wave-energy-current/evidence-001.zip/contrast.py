from project import *
from scipy.integrate import solve_ivp

def solve(factor,sub):
    o=prepare('matched',factor,7);k=o.k;tm=o.centers
    with np.load(pin('preparation.npz')) as ar:
        initial=np.stack([ar['density'],ar['momentum']]);assert np.array_equal(k,ar['k'])
    def parts(t):
        a,H,X=o.spl(t);ratio=(k/(o.mass*a))**2;c=ratio/(np.sqrt(1+ratio)+1)**2
        return H,X,c
    def fluid(t,flat):
        H,X,c=parts(t);e,j=flat.reshape(2,-1);p=c*(e+3*H*j/k)
        return np.stack([-3*H*p-k*j-X,-H*j+k*p]).ravel()
    full=solve_ivp(fluid,(o.sw,tm[-1]),initial.ravel(),method='DOP853',t_eval=tm,rtol=1e-12,atol=1e-16,max_step=1/(640*sub))
    assert full.success
    hist=full.y.T.reshape(len(tm),2,-1)
    previous=None;lastuse=None;items=np.zeros((8,2,len(k)));out=[]
    for left,right in zip(o.domain[:-1],o.domain[1:]):
        ev,use=coefficients(o,left,right);val=ev(left)[0]
        if previous is None:
            items[0]=hist[0]-val[1:3];items[6,0]=1;items[7,1]=1
            out.append(items.copy())
        elif not np.array_equal(lastuse,use):items[5]-=val[1:3]-previous[1:3]
        def rates(t,state):
            data,deriv=ev(t);b,e,j,pb,p,hpb,hp,work,hj,db,de,dj=data[:12]
            H,X,c=parts(t);p0=c*(e+3*H*j/k)-p
            pr=c*(state[:,0]+3*H*state[:,1]/k)
            result=np.stack([-3*H*pr-k*state[:,1],-H*state[:,1]+k*pr],axis=1)
            result[1,0]-=3*H*p0;result[1,1]+=k*p0
            result[2,0]+=(b+pb-1)*X
            result[3]-=deriv[1:3]-np.stack([de,dj])
            result[4,0]+=3*(hp-H*p)+work-(b+pb)*X;result[4,1]+=hj-H*j
            return result
        for aa,zz in zip(np.linspace(left,right,sub+1)[:-1],np.linspace(left,right,sub+1)[1:]):
            h=zz-aa;mid=(aa+zz)/2
            r1=rates(aa,items);r2=rates(mid,items+h*r1/2);r3=rates(mid,items+h*r2/2);r4=rates(zz,items+h*r3)
            items+=h*(r1+2*r2+2*r3+r4)/6
        previous=ev(right)[0];lastuse=use
        if np.any(right==tm):out.append(items.copy())
    assert len(out)==len(tm)
    name=f'contrast-{factor}-{sub}.npz';pack(name,k=k,time=tm,fluid=hist,channels=out,source=['incoming','pressure','enthalpy','commutator','work','edges','unit_density','unit_current'])
    return ROOT/name
def run():
    check('budget-freeze.json')
    freeze('contrast-method.json',[ROOT/'CONTRAST.md',ROOT/'contrast.py',ROOT/'budget-freeze.json',pin('preparation.npz'),prev.BASE/'condensate-origin-20261003/native-heavy-matching-20261007/native/fortran/MTSTwoField.f90'])
    files=[solve(f,s) for f,s in [(1,1),(1,2),(2,1)]]
    freeze('contrast-freeze.json',[ROOT/'contrast-method.json',*files])
if __name__=='__main__':run()
