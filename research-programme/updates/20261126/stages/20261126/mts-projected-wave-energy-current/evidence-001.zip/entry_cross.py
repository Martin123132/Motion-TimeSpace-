from early_test import *
from score import report_energy

def run():
    check('past-input-freeze.json')
    with np.load(early_pin('matched-early.npz')) as ar:
        y0=ar['seed'];fluid=ar['fluid'];mass=ar['mass'].item();rho=ar['rho'].item();t0=ar['cut'].item();k=ar['grid']
    with np.load(early_pin('matched-ordinary-physical.npz')) as ar:
        time=ar['time'];centers=ar['centers'];old_geo=(ar['scale'],ar['hub'],ar['force'])
    with np.load(pin('matched-metric.npz')) as ar:
        ntime=ar['time'];sel=ntime>prev.native.switch();sp=make_interp_spline(ntime[sel],ar['metric'][sel,:3],k=5)
    with np.load(pin('matched-prediction.npz')) as ar:
        index=np.flatnonzero(ar['time']==t0).item();bg,v,f,w=ar['state'][index];scale=sp(t0)[0];mu=mass*scale;m2=mu*mu
        inv=scale/rho*np.stack([.5*(v*v+m2*bg*bg),.5*(v*v-m2*bg*bg),mu*bg*v,v*w+m2*bg*f,k*v*f,v*w-m2*bg*f,mu*(v*f+bg*w)])
    outputs={}
    for metric in ('early','archived'):
        if metric=='early':
            a,h,x=(make_interp_spline(time,array,k=5) for array in old_geo)
            geo=lambda t:(a(t),h(t),x(t))
        else:geo=sp
        def rhs(t,flat):
            vals=flat.reshape(16,-1);scale,H,X=geo(t);mu=mass*scale;ratio=(k/mu)**2;c=ratio/(np.sqrt(1+ratio)+1)**2
            out=[]
            for b,p,l,e,j,pr,mixed in (vals[:7],vals[7:14]):
                base=-k*j-(b+p)*X
                out.extend([-3*H*p,-3*H*b-2*mu*l,2*mu*p,-3*H*pr+base,-H*j+k*pr,-3*H*e-2*mu*mixed+base,2*mu*(pr+ratio*(pr-e)/4)-l*X])
            den,jay=vals[14:];pf=c*(den+3*H*jay/k)
            return np.array([*out,-3*H*pf-k*jay-X,-H*jay+k*pf]).ravel()
        result=solve_ivp(rhs,(t0,time[-1]),np.vstack([y0,inv,fluid]).ravel(),rtol=1e-12,atol=3e-17,t_eval=time,max_step=1/640,method='DOP853')
        assert result.success;v=result.y.T.reshape(len(time),16,-1)
        aa=old_geo[0] if metric=='early' else sp(time)[:,0,0]
        phase=CubicSpline(time,mass*aa).antiderivative()(time)
        for case,ix in [('old',3),('inverse',10)]:
            rows=[]
            for ts in centers:
                idx=np.flatnonzero(ts==time).item();u=(phase-phase[idx])/(6*np.pi);sel=abs(u)<1;u=u[sel];arg=phase[sel]
                design=np.column_stack([u**d for d in range(9)]+[u**d*fn(2*arg) for d in range(7) for fn in (np.cos,np.sin)]+[u**d*fn(4*arg) for d in range(3) for fn in (np.cos,np.sin)])
                weight=np.linalg.pinv(design)[0];mean=np.einsum('t,tdk->dk',weight,v[sel,ix:ix+2])
                rows.append(v[idx,14:]-mean)
            outputs[metric+'_'+case]=rows
        outputs[metric+'_fluid']=v[np.searchsorted(time,centers),14:]
    pack('crossed-inputs.npz',k=k,time=centers,seed_difference=inv-y0,**outputs)
    freeze('entry-freeze.json',[ROOT/'ENTRY.md',ROOT/'entry_cross.py',ROOT/'past-input-freeze.json',ROOT/'crossed-inputs.npz',pin('matched-prediction.npz'),pin('matched-metric.npz')])
    co=read('contrast-outcome.npz');truth=co['target'][np.searchsorted(co['time'],centers)]
    trials={key:np.array(outputs[key]) for key in ('early_old','early_inverse','archived_old','archived_inverse')}
    rows={key:report_energy(value,truth) for key,value in trials.items()}
    gap=trials['early_old']-truth
    routes=dict(early_to_actual_geometry=trials['early_old']-trials['archived_old'],
                old_to_inverse_preparation=trials['archived_old']-trials['archived_inverse'],
                residue=trials['archived_inverse']-truth)
    contribution={key:(100*np.sum(vals*gap,axis=(0,2))/np.sum(gap*gap,axis=(0,2))).tolist() for key,vals in routes.items()}
    ctl=read('past-input-physical.npz')['direct'];summary=dict(trials=rows,signed_primary_error_percent_energy_current=contribution,early_replay=report_energy(trials['early_old'],ctl))
    put('entry-scores.json',summary)
    for key,row in rows.items():print(key,[(round(x['peak_error_pct'],5),round(x['worst_mode_pct'],5),x['modes_over']) for x in row.values()])
    print('signed proportions',contribution)
if __name__=='__main__':run()
