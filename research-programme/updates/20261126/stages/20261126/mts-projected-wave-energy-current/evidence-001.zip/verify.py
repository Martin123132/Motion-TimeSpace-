from project import *
import csv

def synthetic():
    nodes=np.linspace(-25,28,512);theta=lambda t:np.asarray(t)+.003*np.asarray(t)**2
    def primitive(t,nu=0):return (1+.006*np.asarray(t)) if nu else theta(t)
    th=theta(nodes);slow=lambda z:1+.07*z-.002*z*z+.00017*z**3
    raw=slow(th)+(.31+th*.01)*np.cos(2*th)+(.13-.001*th**2)*np.sin(4*th)
    model=SimpleNamespace(width=6*np.pi,theta=theta,phase_nodes=th,phase=primitive,allvals=np.tile(raw[:,None,None],(1,3,1)))
    errors=[]
    for i in np.arange(-2.5,3,.24):
        ev,_=coefficients(model,i,i+.01);val,rate=ev(i+.005);s=theta(i+.005)
        errors.append([abs(val[0,0]-slow(s)),abs(rate[0,0]-(.07-.004*s+.00051*s*s)*primitive(i+.005,1))])
    assert np.max(errors)<1e-10
    return np.max(errors,axis=0).tolist()

def run():
    guard()
    for path in ROOT.glob('*.py'):compile(path.read_bytes(),str(path),'exec')
    for name in ('method','budget-freeze','native-control-freeze','contrast-method','contrast-freeze','past-input-freeze','entry-freeze','prepared-method','prepared-predictions','role-freeze'):
        check(name+'.json')
    read=lambda file:json.loads((ROOT/file).read_bytes())
    for path in ROOT.glob('*.npz'):
        with np.load(path,allow_pickle=False) as ar:
            for key in ar.files:
                val=ar[key];assert val.dtype.kind not in 'cfi' or np.isfinite(val).all(),(path,key)
    scores=read('scores.json')
    for tag,row in scores.items():
        assert row['events']==121 and row['centers']==[89.70625,89.89375] and 1<row['cycles']<1.02
        assert all(v['modes_over']==0 for v in row['budget']['full'].values())
        assert all(v['worst_mode_pct']<1e-8 for v in row['replay'].values())
    assert scores['wave']['above_10x_finer_change']==782 and scores['matched']['above_10x_finer_change']==0
    assert scores['matched']['current_from_energy']['modes_over']==782
    assert scores['matched']['native_matched']['control_drift']['worst_mode_pct']<.0004
    law=read('retained-roles.json')
    assert law['scores']['driven']['current']['modes_over']==5 and law['scores']['total']['energy']['modes_over']==13
    assert 95<law['channel_signed_pct']['inherited'][1]<96 and 4<law['channel_signed_pct']['pressure'][1]<5
    ledger=read('ledger.json');counts=ledger['same_reference']
    assert ledger['direct_target_replay_max_pct']==0
    assert ledger['retained_failing_modes']==17 and ledger['both']==0 and ledger['also_fail_known_metric_fluid_only']==[13,1]
    with (ROOT/'retained-mode-ledger.csv').open() as stream:rows=list(csv.DictReader(stream))
    assert len(rows)==len({row['k_per_Mpc'] for row in rows})==782
    for method,vals in counts.items():
        for name,r in vals.items():assert sum(float(row[method+'_'+name+'_percent'])>.5 for row in rows)==r['modes_over']
    assert [counts['retained'][var]['modes_over'] for var in ('energy','current')]==[13,4]
    assert read('error-clock.json')['segments']['within_scored_window']['over_on_existing_fail']==[0,0]
    assert not any(item.is_dir() or item.suffix=='.partial' for item in ROOT.iterdir())
    put('validation.json',dict(exact_polynomial_and_oscillation_control_abs_error=synthetic(),modes=len(rows),previous_checkpoint=sha(PRE/'seal.json')))
    files=sorted(p for p in ROOT.iterdir() if p.name!='seal.json')
    put('seal.json',dict(files={p.name:sha(p) for p in files},parents={PRE.name:sha(PRE/'seal.json')},scope='Projected wave stress conservation and early-input retained fluid-minus-wave prediction; no photon propagation or observational fit'))
    assert all(sha(ROOT/key)==digest for key,digest in read('seal.json')['files'].items())
    print('Verified',len(files),'files; seal',sha(ROOT/'seal.json'))
if __name__=='__main__':run()
