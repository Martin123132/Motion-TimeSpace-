from score import *

def run():
    check('contrast-freeze.json');check('native-control-freeze.json')
    with np.load(control_path()) as ar:
        e,p,j=ar['matched-native-fluid'].transpose(2,0,1);truth=np.stack([e,j],axis=1)
    s=read('contrast-1-1.npz');hi=read('contrast-1-2.npz');fine=read('contrast-2-1.npz');coarse=read('matched-1-4-7.npz')
    k=s['k'];tm=s['time'];mean=coarse['mean'][:,1:3]
    target=truth-mean
    propagated=s['channels'];pred=propagated[:,:6].sum(axis=1);names=s['source'][:6]
    transfer=lambda x:propagated[:,6]*x[0]+propagated[:,7]*x[1]
    delta0=truth[0]-s['fluid'][0];pref=transfer(delta0)
    forced=target-(propagated[:,0]+pref);pf=propagated[:,1:6].sum(1)
    scores=dict(absolute_native=report_energy(s['fluid'],truth),native_pred_gap=report_energy(s['fluid']-mean,target),
                all_channels=report_energy(pred,target),matched_entry_conditioned=report_energy(pred+pref,target),
                channel_direct_replay_on_gap=report_energy(pred,s['fluid']-mean),
                new_in_window=report_energy(pf,forced),from_entry_alone=report_energy(propagated[:,0]+pref,target),
                ode_refinement=report_energy(hi['channels'][:,:6].sum(1),pred),
                sample_refinement=report_energy(fine['channels'][:,:6].sum(1),pred))
    signed={};new={}
    for idx,key in enumerate(names):
        ab=propagated[:,idx]
        def weight_on(a,t):
            return [float(100*np.sum(a[:,col]*t[:,col])/np.sum(t[:,col]**2)) for col in (0,1)]
        signed[str(key)]=weight_on(ab,target)
        if idx>0:new[str(key)]=weight_on(ab,forced)
    sizes=dict(absolute_peak=np.max(abs(truth),axis=(0,2)).tolist(),gap_peak=np.max(abs(target),axis=(0,2)).tolist(),window_forcing_peak=np.max(abs(forced),axis=(0,2)).tolist(),entry_error=np.max(abs(delta0),axis=1).tolist())
    pack('contrast-outcome.npz',target=target,pred=pred,entry_error=pref,forced=forced,forced_prediction=pf,time=tm,k=k)
    put('contrast-scores.json',dict(scores=scores,signed_projection_pct_energy_current=signed,signed_new_in_window_pct=new,sizes=sizes))
    for label,row in scores.items():print(label,[(key,round(x['peak_error_pct'],8),round(x['worst_mode_pct'],7),x['modes_over']) for key,x in row.items()])
    print('signed total',signed,'signed new',new)
if __name__=='__main__':run()
