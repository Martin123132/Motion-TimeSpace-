from state_io import *
import csv,io

def main():
    guard()
    for receipt in ('method.json','forecast.json','score-array-fix.json','clock-method.json','clock-forecast.json','pressure-method.json','pressure-forecast.json'):check(receipt)
    base=json.loads((ROOT/'scores.json').read_bytes());clock=json.loads((ROOT/'clock-scores.json').read_bytes());work=json.loads((ROOT/'pressure-scores.json').read_bytes())
    for tag in ('wave','matched'):
        verify=json.loads((ROOT/(tag+'-controls.json')).read_bytes())
        assert max(verify['refinement_max_pct'])<.5 and max(verify['metric_overlap_pct'].values())==0
        assert all(row['max_pct']<.5 for row in verify['cold_derivative'])
        assert max(base[tag]['background_late_pct'])<.5
        assert work[tag]['identity_9']['max']<.5
    assert max(base['wave']['current_error_pct']+base['wave']['current_rate_error_pct'])<.5
    assert base['wave']['projection']['retained']['closure']['failures']==0
    assert base['matched']['projection']['retained']['closure']['failures']==782
    assert base['matched']['post_export_nonzero']==0
    with np.load(ROOT/'projection-comparison.npz') as native,np.load(ROOT/'clock-predictions.npz') as pred:
        ref=native['matched-native-fluid'];grid=native['k'];times=pred['eta']
        assert ref.shape==(31,782,3) and list(times[[0,-1]])==[89.70625,89.89375]
        assert np.array_equal(grid,pred['k']) and np.array_equal(times,native['matched-eta'])
        table=io.StringIO(newline='');csvout=csv.writer(table,lineterminator='\n')
        csvout.writerow(['k_Mpc_inverse','native_pressure_peak','peak_error_epoch_Mpc','signed_error_at_peak','own_pressure_error_pct','max_rest_closure_fraction','own_pressure_pass'])
        scales=np.max(abs(ref),axis=0);assert np.all(scales>0)
        mask=None
        for name in ('core','width4','degree10','native_samples'):
            key='matched-own-'+name
            arr=pred[key];delta=arr-ref
            for idx,channel in enumerate(('density','pressure','current')):
                pct=np.max(abs(delta[:,:,idx]),axis=0)*100/scales[:,idx]
                if channel=='pressure':failed=pct>.5
                assert int(np.sum(pct>.5))==clock[key]['components_pct'][channel]['failures']
                assert np.isclose(float(pct.max()),clock[key]['components_pct'][channel]['max'])
            closure=np.max(abs(pred[key+'-closure']),axis=0);assert max(closure)<2e-6
            if mask is None:
                mask=failed
                for mode,kval in enumerate(grid):
                    row=np.argmax(abs(delta[:,mode,1]));csvout.writerow([kval,scales[mode,1],times[row],delta[row,mode,1],100*abs(delta[row,mode,1])/scales[mode,1],closure[mode],not mask[mode]])
            else:assert np.array_equal(failed,mask)
        assert sum(mask)==43 and work['matched']['modes_failing_pressure']==43
        save('mode-pressure-ledger.csv',table.getvalue().encode())
    assert work['matched']['fluid_replay_pct']['max']<.5 and work['matched']['identity_7']['failures']==2
    if (ROOT/'seal.json').exists():
        manifest=json.loads((ROOT/'seal.json').read_bytes())
        assert set(manifest['files'])=={f.name for f in ROOT.iterdir() if f.name!='seal.json'}
        for name,sig in manifest['files'].items():assert sha(ROOT/name)==sig
    elif '--seal' in sys.argv:
        assert (ROOT/'RESULTS.md').is_file() and not any(f.is_dir() or f.name.endswith('.partial') for f in ROOT.iterdir())
        put('seal.json',dict(parent_sha256=SEAL,files={f.name:sha(f) for f in sorted(ROOT.iterdir()) if f.name!='seal.json'}))
    print('Verified 782 modes, 31 centers, both preparations, four projections, all pressure scores. Seal:',sha(ROOT/'seal.json') if (ROOT/'seal.json').exists() else 'pending')
if __name__=='__main__':main()
