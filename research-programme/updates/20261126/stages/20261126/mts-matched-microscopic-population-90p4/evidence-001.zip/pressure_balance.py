from state_io import *
from predict import acquire,sections,per_mode
from score import stats
from scipy.interpolate import CubicSpline,make_interp_spline

def predict():
    check('clock-forecast.json');freeze('pressure-method.json',['PRESSURE.md','pressure_balance.py','clock-forecast.json','clock-scores.json'])
    with np.load(oldio.pin(oldio.SOURCE,'exact-phase-extension.npz')) as bank:
        rho=bank['matching_density'].item();ruler=CubicSpline(bank['heavy_efold'],bank['phase_h'])
    with np.load(ROOT/'clock-predictions.npz') as pred:times=pred['eta']
    out={'eta':times}
    for tag in ('wave','matched'):
        grid,_,source,_,_,_,mass=acquire(tag)
        with np.load(ROOT/(tag+'.npz')) as ar:
            scale=ar['scale'];hub=ar['hub'];bg,vel,field,vs=ar['state'].transpose(1,0,2)
        mass2=(mass*scale[:,None])**2;factor=scale[:,None]/rho
        energy=factor*(vel*vs+mass2*bg*field)
        mixed=factor*(vel*field+bg*vs)
        phase0=float(ruler(np.log(scale[0])))
        primitive=CubicSpline(FINE,scale*mass).antiderivative()
        phase=phase0+primitive(FINE)-primitive(FINE[0])
        ratio=grid**2/(4*mass2);weights=1/(2*(1+ratio))
        terms=np.empty((len(FINE),len(grid),5))
        for left,right,take in sections(tag):
            fine=(FINE>=left)&(FINE<=right)
            force=make_interp_spline(NATIVE[take],source[take,2],k=5)(FINE[fine])
            terms[fine,:,0]=make_interp_spline(FINE[fine],mixed[fine],k=7)(FINE[fine],1)*weights[fine]
            terms[fine,:,1]=hub[fine,None]*mixed[fine]*weights[fine]
            terms[fine,:,2]=factor[fine]*bg[fine]*vel[fine]*force*weights[fine]
            terms[fine,:,3]=ratio[fine]/(1+ratio[fine])*energy[fine]
            terms[fine,:,4]=make_interp_spline(FINE[fine],mixed[fine],k=9)(FINE[fine],1)*weights[fine]
        data=[];sounds=[];velocities=[]
        for time in times:
            place=np.flatnonzero(FINE==time).item();center=phase[place];chosen=abs(phase-center)<6*np.pi
            angle=phase[chosen];coord=(angle-center)/(6*np.pi)
            design=np.column_stack([coord**p for p in range(9)]+[coord**p*fn(2*angle) for p in range(7) for fn in (np.cos,np.sin)]+[coord**p*fn(4*angle) for p in range(3) for fn in (np.cos,np.sin)])
            coeff=np.linalg.pinv(design)[0];data.append(np.einsum('t,tks->ks',coeff,terms[chosen]))
            rs=4*ratio[place];sounds.append(rs/(np.sqrt(1+rs)+1)**2);velocities.append(3*hub[place]/grid)
        out[tag]=np.asarray(data);out[tag+'-sound']=np.asarray(sounds);out[tag+'-rest']=np.asarray(velocities)
    pack('pressure-work.npz',grid=grid,**out);freeze('pressure-forecast.json',['pressure-method.json','pressure-work.npz'])

def score():
    check('pressure-forecast.json');scores={}
    with np.load(ROOT/'pressure-work.npz') as data,np.load(ROOT/'clock-predictions.npz') as pred,np.load(ROOT/'projection-comparison.npz') as target:
        grid=data['grid'];assert np.array_equal(grid,pred['k']);assert np.array_equal(pred['eta'],data['eta'])
        for tag in ('wave','matched'):
            raw=data[tag];direct=pred[tag+'-own-core'];den,pres,mom=direct.transpose(2,0,1)
            reconstructed=np.sum(raw[:,:,:4],axis=2);higher=reconstructed+raw[:,:,4]-raw[:,:,0]
            item={key:stats(per_mode(value,pres),grid,.5) for key,value in [('identity_7',reconstructed),('identity_9',higher)]}
            if tag=='matched':
                fd,fp,fu=target['matched-native-fluid'].transpose(2,0,1)
                cs=data[tag+'-sound'];rest=data[tag+'-rest']
                diff=pres-fp;mode_errors=per_mode(pres,fp);failed=mode_errors>.5
                norms=np.max(abs(fp),axis=0);selected=np.argmax(abs(diff),axis=0)
                item['fluid_replay_pct']=stats(per_mode(cs*(fd+rest*fu),fp),grid,.5)
                item['modes_failing_pressure']=int(sum(failed))
                for group,keep in [('all',np.ones(len(grid),bool)),('pressure_fails',failed)]:
                    if not np.any(keep):continue
                    delta=diff[:,keep]
                    pieces={'mixed_envelope_derivative':raw[:,:,4],'expansion_envelope':raw[:,:,1],'metric_drive':raw[:,:,2],
                        'gradient_minus_sound_density':raw[:,:,3]-cs*den,'rest_frame':-cs*rest*mom,
                        'from_density_and_current_difference':cs*(den-fd+rest*(mom-fu)),'native_law_residual':cs*(fd+rest*fu)-fp,'derivative_remainder':pres-higher}
                    assert np.allclose(sum(pieces.values()),diff,rtol=1e-6,atol=1e-13)
                    item[group]={key:dict(along_discrepancy=np.sum(val[:,keep]*delta)/np.sum(delta**2),rms_over_discrepancy=np.linalg.norm(val[:,keep])/np.linalg.norm(delta)) for key,val in pieces.items()}
                worst=np.argmax(mode_errors);row=selected[worst]
                item['worst']=dict(k=grid[worst],eta=data['eta'][row],target=fp[row,worst],native_pressure_peak=norms[worst],direct=pres[row,worst],independent=higher[row,worst],own_pct=mode_errors[worst])
            scores[tag]=item
    put('pressure-scores.json',scores);print('identity',scores['matched']['identity_9'],'residual',scores['matched']['pressure_fails']['from_density_and_current_difference'],flush=True)
if __name__=='__main__':predict();score()
