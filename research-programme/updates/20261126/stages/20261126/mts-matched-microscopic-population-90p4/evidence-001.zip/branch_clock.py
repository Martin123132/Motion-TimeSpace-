from state_io import *
from score import stats
from predict import per_mode
from scipy.interpolate import CubicSpline
IMPORT=BASE/'condensate-origin-20261003/radiation-and-slow-field-transfer-20261007/radiation_common.py'
VARIANTS=[('core',6,8,1),('width4',4,8,1),('degree10',6,10,1),('native_samples',6,8,2)]

def calc(theta,center,values,hub,k,mass,scale,width,degree,stride):
    select=(abs(theta-center)<width*np.pi)&(np.arange(len(theta))%stride==0)
    phase=theta[select];u=(phase-center)/(width*np.pi)
    basis=np.column_stack([u**p for p in range(degree+1)]+[u**p*fn(2*phase) for p in range(degree-1) for fn in (np.cos,np.sin)]+[u**p*fn(4*phase) for p in range(3) for fn in (np.cos,np.sin)])
    weights=np.linalg.pinv(basis)[0];out=np.einsum('t,tks->ks',weights,values[select]);h=weights@hub[select]
    den,pres,mom=out.T
    ratio=(k/(mass*scale))**2;cs=ratio/(np.sqrt(1+ratio)+1)**2
    norm=np.maximum.reduce([abs(den),abs(k*mom/h)/np.maximum(1,k*np.sqrt(cs)/h),np.full(len(k),1e-6)])
    return out,(pres-cs*(den+3*h*mom/k))/norm

def predict():
    check('forecast.json');freeze('clock-method.json',['CLOCK.md','branch_clock.py','forecast.json','scores.json'])
    with np.load(oldio.pin(oldio.SOURCE,'exact-phase-extension.npz')) as ar:
        ruler=CubicSpline(ar['heavy_efold'],ar['phase_h']);rho=ar['matching_density'].item()
    model={}
    for tag in ('wave','matched'):
        with np.load(ROOT/(tag+'.npz')) as ar:
            scale=ar['scale'];mass=ar['mass'].item();k=ar['grid'];hub=ar['hub'];values=ar['stress']*(scale/rho)[:,None,None]
        original=ruler(np.log(scale))
        primitive=CubicSpline(FINE,scale*mass).antiderivative()
        own=original[0]+primitive(FINE)-primitive(FINE[0])
        model[tag]=(scale,mass,k,hub,values,original,own)
    centers=np.flatnonzero((model['matched'][5][::2]-6*np.pi>np.interp(SW,FINE,model['matched'][5]))&(model['matched'][5][::2]+6*np.pi<model['matched'][5][-1]))*2
    out={'eta':FINE[centers]};clock={}
    for tag,(scale,mass,k,hub,values,original,own) in model.items():
        freq=CubicSpline(FINE,original)(FINE,1)
        mask=(FINE>SW+.015)&(FINE<90.4)
        clock[tag]=dict(max_integrated_phase_change_rad=max(abs(own-original)),
            max_clock_rate_error_pct=max(100*abs(freq[mask]/(mass*scale[mask])-1)),
            generator_sha256=sha(IMPORT))
        for variant,width,degree,stride in VARIANTS:
            for name,theta in [('own',own),('old',original)]:
                rows=[];closure=[]
                for idx in centers:
                    center=theta[idx]
                    assert center-width*np.pi>np.interp(SW,FINE,theta) and center+width*np.pi<theta[-1]
                    row,gap=calc(theta,center,values,hub,k,mass,scale[idx],width,degree,stride)
                    rows.append(row);closure.append(gap)
                out['-'.join((tag,name,variant))]=np.array(rows)
                out['-'.join((tag,name,variant,'closure'))]=np.array(closure)
    pack('clock-predictions.npz',k=k,**out);put('clock-rate.json',clock)
    freeze('clock-forecast.json',['clock-method.json','clock-rate.json','clock-predictions.npz'])

def score():
    check('clock-forecast.json')
    with np.load(ROOT/'clock-predictions.npz') as pred,np.load(ROOT/'projection-comparison.npz') as old:
        target=old['matched-native-fluid'];grid=pred['k'];assert np.array_equal(old['k'],grid)
        for tag in ('wave','matched'):
            assert np.array_equal(pred['eta'],old[tag+'-eta'])
            assert np.allclose(pred[tag+'-old-core'],old[tag+'-projected'],rtol=1e-9,atol=1e-12)
        results={}
        for tag in ('wave','matched'):
            for var,_,_,_ in VARIANTS:
                name=tag+'-own-'+var;values=pred[name]
                item=dict(closure=stats(np.max(abs(pred[name+'-closure']),axis=0),grid,2e-6))
                if tag=='matched':
                    item['components_pct']={key:stats(per_mode(values[:,:,idx],target[:,:,idx]),grid,.5) for idx,key in enumerate(('density','pressure','current'))}
                results[name]=item
        ref=pred['matched-old-core'];resolved=pred['wave-old-core']
        old_delta=ref[:,:,1]-resolved[:,:,1];new_delta=pred['matched-own-core'][:,:,1]-pred['wave-own-core'][:,:,1]
        results['branch_pressure_difference']=dict(old_peak=np.max(abs(old_delta)),own_peak=np.max(abs(new_delta)),own_rms_over_old=float(np.linalg.norm(new_delta)/np.linalg.norm(old_delta)),
            original_gap_to_fluid_peak=float(np.max(abs(ref[:,:,1]-target[:,:,1]))),own_gap_to_fluid_peak=float(np.max(abs(pred['matched-own-core'][:,:,1]-target[:,:,1]))))
        put('clock-scores.json',results)
        print('clock:',results['matched-own-core'],results['branch_pressure_difference'],flush=True)
if __name__=='__main__':predict();score()
