from pathlib import Path
from io import BytesIO
from functools import lru_cache
import hashlib,json,sys
import numpy as np
ROOT=Path(__file__).resolve().parent
BASE=ROOT.parent
ENERGY=BASE/'mts-heavy-energy-work-90p4-20261126'
SEAL='192ab288e6e312bdcf8c331a8eab79f41d2a23d7bb67f236d9797294d733e16c'
def sha(path):
    with path.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
assert sha(ENERGY/'seal.json')==SEAL
items=json.loads((ENERGY/'seal.json').read_bytes())['files']
def pin(name):
    p=ENERGY/name;assert sha(p)==items[name];return p
pin('energy_io.py');sys.path.insert(0,str(ENERGY));import energy_io as parent
from energy_io import prior,oldio
def guard():
    parent.guard();assert not (ROOT/'STOP-REQUESTED').exists()
def save(name,data):
    guard();path=ROOT/name
    if path.exists():assert sha(path)==hashlib.sha256(data).hexdigest(),name
    else:
        tmp=path.with_suffix(path.suffix+'.partial')
        with tmp.open('xb') as f:f.write(data)
        tmp.rename(path)
def put(name,data):save(name,(json.dumps(data,sort_keys=True,indent=2,allow_nan=False,default=lambda x:x.item())+'\n').encode())
def pack(name,**fields):
    buf=BytesIO();np.savez_compressed(buf,**fields);save(name,buf.getvalue())
def freeze(name,files):put(name,{f:sha(ROOT/f) for f in files})
def check(name):
    for f,sig in json.loads((ROOT/name).read_bytes()).items():assert sha(ROOT/f)==sig,f
def err(x,y):
    s=np.max(abs(y));assert s>0
    return float(100*np.max(abs(x-y))/s)
def raw(tag,late,basename):
    if late:
        return prior.sealed(prior.EXT,'native/'+basename) if tag=='matched' else oldio.pin(oldio.PAD,'material-halfstep/'+basename)
    return oldio.pin(oldio.SOURCE,('matched-native/' if tag=='matched' else 'material-halfstep/')+basename)
LEFT=88.4;RIGHT=90.45
summary=json.loads(oldio.pin(oldio.SOURCE,'switch-audit.json').read_bytes())
SW=(summary['min_switch']+summary['max_switch'])/2
NATIVE=np.arange(round(LEFT*160),round(RIGHT*160)+1)/160
FINE=np.arange(round(LEFT*320),round(RIGHT*320)+1)/320
def joined(tag,basename,reader):
    parts=[]
    for late in (False,True):
        with np.load(raw(tag,late,basename)) as ar:
            t=ar['eta'] if 'eta' in ar else ar['t'];take=(t>=LEFT)&(t<=RIGHT)
            parts.append((t[take],reader(ar,take)))
    left,right=parts;over=(left[0]>=right[0][0]);count=sum(over)
    assert np.array_equal(left[0][over],right[0][:count])
    assert np.array_equal(np.r_[left[0][~over],right[0]],NATIVE)
    data=np.concatenate((left[1][~over],right[1]),axis=0)
    scale=np.max(abs(left[1][over]),axis=(0,1));gap=np.max(abs(left[1][over]-right[1][:count]),axis=(0,1))
    rel=100*gap/np.where(scale,scale,1)
    return data,rel
