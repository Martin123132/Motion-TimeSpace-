from state_io import *

def main():
    check('forecast.json')
    original=ROOT/'score.py';source=original.read_text(encoding='utf-8')
    faulty='np.max(abs(closure),axis=0)'
    assert source.count(faulty)==1
    corrected=source.replace(faulty,'np.max(np.abs(closure),axis=0)')
    freeze('score-array-fix.json',['forecast.json','score.py','replay_score.py'])
    exec(compile(corrected,str(original),'exec'),{'__name__':'__main__','__file__':str(original)})

if __name__=='__main__':main()
