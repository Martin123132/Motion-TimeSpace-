from state_io import *
from scipy.interpolate import make_interp_spline
from types import SimpleNamespace

METRIC=['a','adotoa','etak','sigma','phi','grho','gpres','dgq','dgrho','clxc']
BRANCHES=('wave','matched')

def acquire(tag):
    starts=[];nodes=[];metrics=[];overlap=[]
    for idx in range(38):
        name=f'linear-heavy-{idx:02}.npz'
        with np.load(raw(tag,False,name)) as bank:
            nodes.append(bank['k'])
            row=bank['values'][:,np.flatnonzero(bank['eta']==LEFT).item(),:]
            starts.append(row[:,[bank['keys'].tolist().index(key) for key in ('mts_dphi_h','mts_dphidot_h')]])
        def read(bank,take):
            assert np.array_equal(bank['k'],nodes[-1]) and np.all(bank['good'][:,take])
            cols=[bank['keys'].tolist().index(key) for key in METRIC]
            return bank['values'][:,take,:][:,:,cols].transpose(1,0,2)
        block,gap=joined(tag,name,read);metrics.append(block);overlap.append(gap)
    with np.load(raw(tag,False,'background-heavy.npz')) as bg:
        spot=np.flatnonzero(bg['eta']==LEFT).item()
        startbg=[bg[key][spot] for key in ('hphi','hphidot')];mass=bg['hmass'].item()
    grid=np.concatenate(nodes);assert len(grid)==782 and np.all(np.diff(grid)>0)
    state=np.array([np.full(len(grid),num) for num in startbg]+list(np.concatenate(starts).T))
    values=np.concatenate(metrics,axis=1).transpose(2,0,1)
    scale,hubble,eta,shear,potential,rho,pressure,current,density,cold=values
    alpha=shear/grid;psi=2*potential-(eta/grid-hubble*alpha)
    pd=(current+(rho+pressure)*shear)/(2*grid)-hubble*psi
    source=(density/2+grid*eta)/hubble
    inputs=np.stack([hubble,(mass*scale)**2,source],axis=1)
    coordinates=np.stack([scale,hubble,alpha,psi,pd],axis=1)
    return grid,state,inputs,coordinates,cold,np.max(overlap,axis=0),mass

def sections(tag):
    if tag=='wave':return [(LEFT,RIGHT,np.ones(len(NATIVE),bool))]
    return [(LEFT,SW,NATIVE<SW),(SW,RIGHT,NATIVE>SW)]

def solve(tag,grid,state,inputs,sub):
    square=grid**2
    history=np.empty((len(FINE),4,len(grid)));history[:]=np.nan
    state=state.copy();history[0]=state
    def rhs(value,source):
        hub,mass2,force=source
        return np.stack([value[1],-2*hub*value[1]-mass2*value[0],value[3],
            -2*hub*value[3]-(square+mass2)*value[2]-force*value[1]])
    for left,right,select in sections(tag):
        spl=make_interp_spline(NATIVE[select],inputs[select],k=5,axis=0)
        edges=np.r_[left,FINE[(FINE>left)&(FINE<right)],right]
        for offset in range(0,len(edges)-1,24):
            guard();seg=edges[offset:offset+25]
            micro=(seg[:-1,None]+np.diff(seg)[:,None]*np.arange(sub)/sub).ravel()
            fine=np.r_[micro,seg[-1]];steps=np.diff(fine);mid=fine[:-1]+steps/2
            ends=spl(fine);middle=spl(mid)
            for index,dt in enumerate(steps):
                first=rhs(state,ends[index])
                second=rhs(state+first*(dt/2),middle[index])
                third=rhs(state+second*(dt/2),middle[index])
                last=rhs(state+third*dt,ends[index+1])
                state=state+(dt/6)*(first+2*second+2*third+last)
                if (index+1)%sub==0:
                    point=seg[(index+1)//sub];slot=np.searchsorted(FINE,point)
                    if slot<len(FINE) and FINE[slot]==point:history[slot]=state
    assert np.isfinite(history).all()
    return history

def extra(tag,coords,cold,force):
    result=np.empty((len(FINE),5,coords.shape[2]));scores=[]
    for left,right,select in sections(tag):
        take=(FINE>=left)&(FINE<=right)
        result[take]=make_interp_spline(NATIVE[select],coords[select],k=5)(FINE[take])
        deriv=make_interp_spline(NATIVE[select],cold[select],k=5)(NATIVE[select],1)
        truth=force[select];rel=100*np.max(abs(deriv+truth),axis=0)/np.max(abs(truth),axis=0)
        scores.append(dict(max_pct=rel.max(),median_pct=np.median(rel),fail=int(sum(rel>.5))))
    return result,scores

def per_mode(x,y):
    peak=np.max(abs(y),axis=0);assert np.all(peak>0)
    return 100*np.max(abs(x-y),axis=0)/peak

def currents(grid,fields):
    prior.sealed(prior.EXT,'source_io.py');sys.path.insert(0,str(prior.EXT))
    from source_io import spatial_module
    es=spatial_module().earlier.es
    shell=np.asarray(json.loads(es.pin('legs.json').read_bytes())['squared_radii'])
    model=SimpleNamespace(nodes=grid,shell=shell,first={key:arr.T for key,arr in fields.items()})
    projector=es.Project(model);current=[];rate=[]
    for source in projector.ops:
        op=es.Fast(source,model)
        current.append(-op.dg('n','f'));rate.append(-op.dg('nd','f')-op.dg('n','fd'))
    return np.array(current).T,np.array(rate).T

def main():
    guard();freeze('method.json',['PROTOCOL.md','state_io.py','predict.py','score.py'])
    for tag in BRANCHES:
        grid,start,source,coords,cold,overlap,mass=acquire(tag)
        coordinate,coldcheck=extra(tag,coords,cold,source[:,2])
        coarse=solve(tag,grid,start,source,4);fine=solve(tag,grid,start,source,8)
        scale,hub,alpha,psi,pd=coordinate.transpose(1,0,2)
        back,vel,field,rate=fine.transpose(1,0,2);mass2=(mass*scale)**2
        fg=field+vel*alpha;normal=rate+(-3*hub*vel-mass2*back)*alpha
        fprime=normal+vel*psi;nprime=-2*hub*normal-(grid**2+mass2)*fg-mass2*back*psi+3*vel*pd
        current,derivative=currents(grid,{key:arr[::2] for key,arr in dict(f=fg,n=normal,fd=fprime,nd=nprime).items()})
        controls=np.max(per_mode(coarse,fine),axis=-1)
        assert np.isfinite(current).all() and np.isfinite(derivative).all()
        stress=np.stack([vel*rate+mass2*back*field,vel*rate-mass2*back*field,grid*vel*field],axis=-1)
        pack(tag+'.npz',time=FINE,grid=grid,state=fine,stress=stress,scale=scale[:,0],hub=hub[:,0],mass=mass,current=current,current_rate=derivative)
        put(tag+'-controls.json',dict(field_order=['b','v','f_syn','w_syn'],refinement_max_pct=controls.tolist(),
            relative_scale_spread=np.max(abs(scale/scale[:,:1]-1)),relative_hubble_spread=np.max(abs(hub/hub[:,:1]-1)),
            metric_overlap_pct=dict(zip(METRIC,overlap)),cold_derivative=coldcheck))
        print(tag,'predictions saved',flush=True)
    freeze('forecast.json',['method.json','wave.npz','matched.npz','wave-controls.json','matched-controls.json'])

if __name__=='__main__':main()
