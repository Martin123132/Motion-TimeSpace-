from state_io import *
from scipy.interpolate import CubicSpline
from predict import per_mode

def stats(rel,grid,threshold):
    return dict(max=float(rel.max()),median=float(np.median(rel)),p95=float(np.percentile(rel,95)),
        failures=int(sum(rel>threshold)),worst_k=float(grid[np.argmax(rel)]))

def moments(tag,sol,packet):
    time=sol['time'];scales=sol['scale'];h=sol['hub'];stress=sol['stress']
    rho=packet['matching_density'].item();mass=sol['mass'].item();grid=sol['grid']
    phase_of_n=CubicSpline(packet['heavy_efold'],packet['phase_h'])
    phase=phase_of_n(np.log(scales));assert np.all(np.diff(phase)>0)
    phisw=phase_of_n(np.log(packet['matching_scale'].item()))
    phileft=np.interp(SW,time,phase)
    which=np.flatnonzero((phase[::2]-6*np.pi>phileft)&(phase[::2]+6*np.pi<phase[-1]))
    assert which.size>0
    normstress=stress*(scales/rho)[:,None,None]
    def measure(phic,scale,width,degree,stride):
        take=(abs(phase-phic)<width*np.pi)&(np.arange(len(phase))%stride==0)
        phase_s=phase[take];coord=(phase_s-phic)/(width*np.pi)
        basis=np.column_stack([coord**power for power in range(degree+1)]+
            [coord**power*trig(2*phase_s) for power in range(degree-1) for trig in (np.cos,np.sin)]+
            [coord**power*trig(4*phase_s) for power in range(3) for trig in (np.cos,np.sin)])
        assert sum(take)>=basis.shape[1] and np.linalg.matrix_rank(basis)==basis.shape[1]
        weights=np.linalg.pinv(basis)[0];res=np.einsum('t,tks->ks',weights,normstress[take]);hub=weights@h[take]
        dens,pres,mom=res.T;ratio=(grid/(scale*mass))**2;sound=ratio/(np.sqrt(1+ratio)+1)**2
        norm=np.maximum.reduce([abs(dens),abs(grid*mom/hub)/np.maximum(1,grid*np.sqrt(sound)/hub),np.full(len(grid),1e-6)])
        error=(pres-sound*(dens+3*hub*mom/grid))/norm
        return res,error,np.linalg.cond(basis)
    center=packet['matching_scale'].item()
    assert phase[0]<phisw-6*np.pi and phase[-1]>phisw+6*np.pi
    anchor,closure,cond=measure(phisw,center,6,8,1)
    indices=abs(grid[:,None]-packet['modes']).argmin(axis=1)
    assert max(abs(packet['modes'][indices]/grid-1))<1e-12
    target=np.array([packet[key][indices] for key in ['matching_delta','projected_pressure','matching_momentum']]).T
    oldnorm=packet['projection_norm'][indices]
    sw=dict(time_interpolated=np.interp(phisw,phase,time),method_condition=cond,
        max_abs_difference_over_retained_mode_norm=np.max(abs(anchor-target)/oldnorm[:,None],axis=0).tolist(),
        closure=stats(abs(closure),grid,2e-6))
    result={};arrs={}
    for label,width,degree,stride in [('retained',6,8,1),('width4',4,8,1),('degree10',6,10,1),('native_samples',6,8,2)]:
        samples=[];closure=[];condition=[]
        for idx in which:
            res,delta,cond=measure(phase[2*idx],scales[2*idx],width,degree,stride)
            samples.append(res);closure.append(delta);condition.append(cond)
        arrs[label]=np.asarray(samples)
        result[label]=dict(closure=stats(np.max(abs(closure),axis=0),grid,2e-6),
            condition_max=max(condition))
    return which,arrs,sw,result

def main():
    guard();check('forecast.json');scores={};packets={};datasets={}
    with np.load(oldio.pin(oldio.SOURCE,'exact-phase-extension.npz')) as ar:packet={key:ar[key] for key in ar.files}
    with np.load(pin('native-current-forecast.npz')) as ar:
        target_t=ar['eta'];target_j=ar['j'];target_rate=ar['rate']
    for tag in ('wave','matched'):
        with np.load(ROOT/(tag+'.npz')) as ar:
            dataset={key:ar[key] for key in ar.files}
        grid=dataset['grid'];mask=(NATIVE>=89.65)&(NATIVE<=90.4);nf=dataset['state'][::2]
        fields=[];averaged=[];order=[]
        for idx in range(38):
            name=f'linear-heavy-{idx:02}.npz'
            def read(archive,sel):
                key=archive['keys'].tolist()
                return archive['values'][:,sel,:][:,:,[key.index(k) for k in ('mts_dphi_h','mts_dphidot_h')]].transpose(1,0,2)
            out,_=joined(tag,name,read);fields.append(out)
            if tag=='matched':
                def read_fluid(ar,sel):
                    key=ar['keys'].tolist()
                    return ar['values'][:,sel,:][:,:,[key.index(k) for k in ('mts_drho_h','mts_dp_h','mts_q_h')]].transpose(1,0,2)
                fluid,_=joined(tag,f'phase-audit-{idx:02}.npz',read_fluid);averaged.append(fluid)
                with np.load(raw(tag,False,f'phase-audit-{idx:02}.npz')) as ar:order.extend(ar['k'])
        truth=np.concatenate(fields,axis=1)
        bg,_=joined(tag,'background-heavy.npz',lambda ar,sel:np.stack([ar[k][sel] for k in ('hphi','hphidot')],axis=-1)[:,None,:])
        bgerr=[err(nf[mask,i,0],bg[mask,0,i]) for i in (0,1)]
        owns=dict(background_late_pct=bgerr)
        for name,take in [('before',NATIVE<SW),('late',mask)]:
            if tag=='matched' and name=='late':
                owns['post_export_nonzero']=int(np.count_nonzero(truth[take]));continue
            owns['field_'+name]=[stats(per_mode(nf[take,i+2],truth[take,:,i]),grid,.5) for i in (0,1)]
        select=(target_t>=89.65)&(target_t<=90.4);assert np.array_equal(target_t[select],NATIVE[mask])
        if tag=='wave':
            for name,target in [('current',target_j),('current_rate',target_rate)]:
                owns[name+'_error_pct']=per_mode(dataset[name][mask],target[select]).tolist()
        which,predicted,anchor,variants=moments(tag,dataset,packet)
        owns.update(switch=anchor,first_center=NATIVE[which[0]],last_center=NATIVE[which[-1]],centers=len(which),projection=variants)
        packets[tag+'-eta']=NATIVE[which];packets[tag+'-projected']=predicted['retained']
        if tag=='matched':
            assert np.array_equal(grid,np.array(order))
            control=np.concatenate(averaged,axis=1)[which]*(dataset['scale'][2*which]/packet['matching_density'].item())[:,None,None]
            packets['matched-native-fluid']=control
            for label,values in predicted.items():
                variants[label]['native_component_errors_pct']={key:stats(per_mode(values[:,:,i],control[:,:,i]),grid,.5) for i,key in enumerate(('density','pressure','momentum'))}
                variants[label]['vs_retained_pct']={key:stats(per_mode(values[:,:,i],predicted['retained'][:,:,i]),grid,.5) for i,key in enumerate(('density','pressure','momentum'))}
        scores[tag]=owns;datasets[tag]={key:dataset[key] for key in ('current','current_rate')};datasets[tag]['start']=nf[0].copy()
        del dataset,truth,fields,nf,averaged
    scores['comparison']={key+'_matched_minus_wave_pct':per_mode(datasets['matched'][key][mask],datasets['wave'][key][mask]).tolist() for key in ('current','current_rate')}
    scores['comparison']['preparation_difference_pct']=[err(m,w) for m,w in zip(datasets['matched']['start'],datasets['wave']['start'])]
    put('scores.json',scores);pack('projection-comparison.npz',k=grid,**packets)
    print('wave replay',scores['wave']['field_late'],flush=True)
    print('matched','centers',scores['matched']['centers'],scores['matched']['projection']['retained'],flush=True)
if __name__=='__main__':main()
