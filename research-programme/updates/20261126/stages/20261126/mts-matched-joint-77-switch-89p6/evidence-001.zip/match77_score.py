import ast,csv,sys
from match77_stage import *
def power(t,x):return np.trapezoid(abs(x)**2,t,axis=0)
def err(t,x,y):
    norm=power(t,y);assert np.all(norm>0)
    return 100*np.sqrt(power(t,x-y)/norm)
def first_cross(t,x):
    idx=np.flatnonzero(x>.5);return t[idx[0]] if len(idx) else ''
def score():
    locked('forecast-freeze.json')
    gates=[];versus=[];attribution=[];refinements=[];bank={}
    with np.load(fluid_input('common-heavy.npz')) as inp:kk=inp['k'].item()**2
    for mode in MODES:
        for sub in (2,4):
            with np.load(ROOT/f'matched-{mode}-{sub}.npz') as ar:
                t=ar['t'];data=ar['observables'];corners=ar['corners'];seams=ar['seams'];q=old.KIN.MOM
                lag=ar['lag_end'];assert ar['names'].tolist()==list(NAMES)
            with np.load(sealed(f'joint-{mode}-{sub}.npz')) as ar:
                axis=ar['t'];assert t[0]==axis[0] and t[-1]==axis[-1] and ar['names'].tolist()==list(NAMES) and np.array_equal(ar['q'],q)
                ref=CubicSpline(axis,ar['observables'],axis=0)(t);rlag=ar['lag_end']
            bank[mode,sub]=t,data,ref,lag
            indices=np.searchsorted(t,corners)
            for idx,label in enumerate(('momentum','density')):
                val=data[:,idx,:];control=ref[:,idx,:]
                phi,ep,shadow,psi,rate,en,jcur,u,den,hub=val[:,:10].T
                gap=ep-shadow;drift=gap-gap[0];motion=shadow-shadow[0];rate_norm=rms(t,rate)
                integrals=[0.,0.];peak=0.;first='';jumps=[];shadow_int=0j;replay=[]
                for seg,(lo,hi) in enumerate(zip(np.r_[0,indices],np.r_[indices,len(t)-1])):
                    times=t[lo:hi+1];values=val[lo:hi+1].copy()
                    if seg<len(indices):values[-1]=seams[seg,0,idx];jumps.append(seams[seg,1,idx,1]-values[-1,1])
                    pd=values[:,4];diff=CubicSpline(times,values[:,1])(times,1)-pd
                    integrals[0]+=power(times,diff);integrals[1]+=power(times,pd)
                    local=100*abs(diff)/rate_norm;peak=max(peak,max(local))
                    if first=='':first=first_cross(times,local)
                    predicted=shadow[0]+shadow_int+prim(times,pd);replay.extend(abs(predicted-values[:,2]));shadow_int+=predicted[-1]-predicted[0]
                full=100*rms(t,gap)/rms(t,shadow);delta=100*rms(t,drift)/rms(t,motion);rate_err=100*np.sqrt(integrals[0]/integrals[1])
                control_check=100*max(replay)/max(abs(motion));assert control_check<=.5
                gates.append(dict(mode=mode,sub=sub,route=label,entry_pct=100*abs(gap[0])/abs(shadow[0]),metric_pct=full,drift_pct_of_motion=delta,rate_pct=rate_err,peak_smooth_rate_pct=peak,first_rate_cross=first,first_metric_cross=first_cross(t,100*abs(gap)/abs(shadow[0])),corner_jump_pct_of_launch=100*max(abs(np.array(jumps)))/abs(shadow[0]),momentum_replay_pct=control_check,full_pass=bool(full<=.5),drift_pass=bool(delta<=.5),rate_pass=bool(rate_err<=.5)))
                for col,name in enumerate(NAMES):
                    error=err(t,val[:,col],control[:,col])
                    versus.append(dict(mode=mode,sub=sub,route=label,channel=name,error_pct=error,ref_rms=rms(t,control[:,col]),delta_rms=rms(t,val[:,col]-control[:,col]),passes=bool(error<=.5)))
                for name,col in [('curvature_motion',0),('shadow_motion',2)]:
                    diff=val[:,col]-val[0,col];target=control[:,col]-control[0,col]
                    error=err(t,diff,target)
                    versus.append(dict(mode=mode,sub=sub,route=label,channel=name,error_pct=error,ref_rms=rms(t,target),delta_rms=rms(t,diff-target),passes=bool(error<=.5)))
                def components(a):
                    _,_,sh,_,_,energy,curr,U,B,H=a[:,:10].T
                    return np.stack([U/B,-energy/(2*B),-1.5*H*curr/(kk*B),-sh],axis=1)
                part=components(val)-components(control);res=gap-(control[:,1]-control[:,2]);norm=rms(t,res)
                assert rms(t,part.sum(1)-res)/norm<=.005
                for k,name in enumerate(('U_over_B','energy','momentum','shadow')):
                    frac=100*np.trapezoid((part[:,k]*res.conj()).real,t)/((t[-1]-t[0])*norm**2)
                    attribution.append(dict(mode=mode,sub=sub,route=label,term=name,signed_pct_of_constraint_difference=frac))
                e=np.max(100*np.max(abs(lag[idx]-rlag[idx]),axis=1)/np.max(abs(rlag[idx]),axis=1))
                versus.append(dict(mode=mode,sub=sub,route=label,channel='max_individual_end_bin',error_pct=e,ref_rms='',delta_rms='',passes=bool(e<=.5)))
    for lo,hi in [(('p16',2),('p16',4)),(('p32',2),('p32',4)),(('p16',4),('p32',4))]:
        t,d,c,l=bank[lo];t2,d2,c2,l2=bank[hi];high=CubicSpline(t2,d2)(t);ref=CubicSpline(t2,c2)(t)
        for idx,label in enumerate(('momentum','density')):
            for k in [0,1,3,4,6,10,11,12,13]:
                p=d[:,idx,k];h=high[:,idx,k];a=p-c[:,idx,k];b=h-ref[:,idx,k]
                for tag,v in [('full_'+NAMES[k],err(t,p,h)),('contrast_'+NAMES[k],err(t,a,b))]:
                    refinements.append(dict(low=str(lo),high=str(hi),route=label,channel=tag,error_pct=v,passes=bool(v<=.5)))
            v=err(t,d[:,idx,1]-d[:,idx,2],high[:,idx,1]-high[:,idx,2])
            refinements.append(dict(low=str(lo),high=str(hi),route=label,channel='constraint_gap_own_scale',error_pct=v,passes=bool(v<=.5)))
    for name,rows in [('constraint-tests',gates),('versus-resolved',versus),('constraint-difference-budget',attribution),('refinement',refinements)]:table(name+'.csv',rows)
    freeze('score-receipt.json',['forecast-freeze.json','constraint-tests.csv','versus-resolved.csv','constraint-difference-budget.csv','refinement.csv'])
def verify(seal=False):
    for r in ['protocol.json','entry-receipt.json','forecast-freeze.json','score-receipt.json']:locked(r)
    for name,count in [('entry-tests',2),('constraint-tests',8),('versus-resolved',136),('constraint-difference-budget',32),('refinement',114)]:
        with (ROOT/(name+'.csv')).open() as stream:rows=list(csv.DictReader(stream))
        assert len(rows)==count,(name,len(rows))
        if name in ('versus-resolved','refinement'):
            assert all(np.isfinite(float(r['error_pct'])) and (float(r['error_pct'])<=.5)==(r['passes']=='True') for r in rows)
        if name=='constraint-tests':
            for a,b in [('metric_pct','full_pass'),('rate_pct','rate_pass'),('drift_pct_of_motion','drift_pass')]:assert all((float(r[a])<=.5)==(r[b]=='True') for r in rows)
    for file in ROOT.glob('*.py'):ast.parse(file.read_text())
    assert not list(ROOT.glob('__pycache__'))
    if seal:
        assert (ROOT/'RESULTS.md').is_file();freeze('seal.json',sorted(p.name for p in ROOT.iterdir() if p.is_file() and p.name!='seal.json'));locked('seal.json');print(sha(ROOT/'seal.json'))
if __name__=='__main__':
    if '--seal' in sys.argv:verify(True)
    else:score();verify()
