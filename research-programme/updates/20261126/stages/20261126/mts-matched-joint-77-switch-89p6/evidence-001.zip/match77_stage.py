import json,sys
from pathlib import Path
import hashlib
ROOT=Path(__file__).resolve().parent
CONTROL=ROOT.parent/'mts-prepared-joint-77-switch-89p6-20261126'
PIN='73b24e93fea12844c02baaa76fa61c200b63a90096986c912d5f50bbed338a40'
def sha(path):
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
assert sha(CONTROL/'seal.json')==PIN
entries=json.loads((CONTROL/'seal.json').read_bytes())['files']
def sealed(name):
    path=CONTROL/name;assert sha(path)==entries[name],name
    return path
for name in ('joint77_stage.py','joint77_prepare.py','joint77_evolve.py'):sealed(name)
sys.path.insert(0,str(CONTROL))
from joint77_stage import old,common,window,np,pack,table,freeze,locked,safe,rms,wave_input,CubicSpline,solve_ivp,Bank,adv,expit,IX,N_IND,prim
from joint77_prepare import coefficients
from joint77_evolve import NAMES
from recouple_stage import make,pinned,KIN
from twin_stage import FIRST,CURRENT
from project_wave import background
from current_stage import window as history_window
from scipy.interpolate import make_interp_spline
from copy import copy
common.PINS={**common.PINS,CONTROL:PIN};common.ROOT=window.ROOT=ROOT
MODES=('p16','p32')
FLUID=old.KIN.FLUID
manifest=FLUID/'bank-heavy.json'
assert sha(manifest)=='67900f77c6c0a2c78a7b92c83294150f34cc748927f9d6b6da26659f27bcaf2c'
signatures=json.loads(manifest.read_bytes())
def fluid_input(name):
    path=FLUID/name;assert sha(path)==signatures[name],name
    return path
class MatchedBank(Bank):
    def __init__(self):
        with np.load(fluid_input('common-heavy.npz')) as arc:
            all_times=arc['eta'];times=old.KIN.physical_axis(all_times,89.,89.6);self.k=arc['k'].item()
            self.sw=CubicSpline(np.log(times),CubicSpline(all_times,arc['Sw'].T)(times))
        self.axis=times;self.q=q=old.KIN.MOM
        assert np.array_equal(q,2.**(np.arange(-52,25)/4))
        sources=[]
        for node,mom in enumerate(q,-52):
            with np.load(fluid_input(f'micro-heavy-{node}.npz')) as ar:
                assert ar['id']==node and ar['q']==mom
                sources.append(CubicSpline(all_times,ar['source'].T)(times))
        self.micro=CubicSpline(np.log(times),np.stack(sources,axis=1))
        with np.load(fluid_input('material-halfstep/forcing-heavy.npz')) as ar:
            bg=dict(zip(ar['bgkeys'],ar['background']));self.bg=CubicSpline(np.log(ar['eta']),np.stack([bg['a'],bg['enu']],axis=1))
            assert all(k not in ar['keys'] for k in ('hfield','hmoment','henergy','hJ'))
        meta=json.loads(old.KIN.ti.parent.pin('radiation-background.json').read_bytes())['heavy']
        self.mass=meta['mass_over_temperature'];quadr=np.gradient(np.log(q));quadr[[0,-1]]*=.5
        self.weight=meta['massless_limit_coeff']/(7*np.pi**4/120)*quadr*q**2*expit(q)*expit(-q)
        self.spectral=5-q*np.tanh(q/2)
class Host:
    def __init__(self,mode,sub):
        self.matched,_,grid,self.launch,_=make(mode,'matched',sub)
        src=self.matched;self.wave=src.wave;self.kk=src.kk;self.flow=src.flow;self.corners=src.corners
        with np.load(pinned(KIN,f'absolute-{mode}-{sub}.npz')) as ar:
            self.t=ar['cuts'];self.osc=background(self.t,mode,sub,False)
        assert np.array_equal(self.t,np.unique(np.r_[grid,self.corners])) and self.t[0]==src.time[0]
        with np.load(wave_input('material-halfstep/forcing-heavy.npz')) as ar:
            names=ar['keys'].tolist();self.micro_keys=['hfield','hmoment','henergy','hJ']
            self.external=make_interp_spline(np.log(ar['eta']),ar['values'][[names.index(k) for k in self.micro_keys],:,0].T,k=5)
        self.focus=None;self.blank=lambda t:np.zeros((len(t),4),complex)
        self.quads=lambda t:np.zeros((len(t),2),complex)
    def environment(self,t,side=None):
        choose=np.full_like(t,self.focus) if self.focus is not None else side
        b,q,_,coef,_,stream,rho,den=self.matched.environment(t,choose)
        hub,mass2,field,vel=self.osc(t);assert np.allclose(b['h'],hub,rtol=1e-7,atol=0)
        b=dict(b,hb=field,hv=vel,hm=np.sqrt(mass2)/b['a'])
        q=dict(q,**dict(zip(self.micro_keys,self.external(np.log(t)).T)))
        q['hshear']=rho*coef[4]
        return b,q,self.blank(t),None,self.quads(t).T,stream,None,den+1.5*(vel**2-rho)
def setup():
    safe();freeze('protocol.json',['PROTOCOL.md','match77_stage.py','match77_prepare.py','match77_evolve.py','match77_score.py'])
if __name__=='__main__':setup()
