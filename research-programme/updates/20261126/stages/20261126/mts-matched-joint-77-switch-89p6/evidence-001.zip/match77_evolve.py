from match77_stage import *

def run(mode,sub,bank):
    locked('entry-receipt.json')
    host=Host(mode,sub);src=rawsrc=host;solver=old.Wave(host);t=host.t
    with np.load(ROOT/f'matched-switch-{mode}.npz') as ar:
        assert ar['passed'].item() and ar['t'].item()==t[0] and np.array_equal(ar['fluid_entry'],host.launch)
        x=np.repeat(ar['entry'][None,:],2,axis=0);lag=np.repeat(ar['lag'][None,:,:],2,axis=0);shape=ar['shape'].copy()
    output=np.empty((len(t),2,len(NAMES)),complex);held=lag.copy();checks=0.;seams=[]
    corners=np.searchsorted(t,host.corners);assert np.array_equal(t[corners],host.corners)
    blocks=[]
    for lo,hi in zip(np.r_[0,corners],np.r_[corners,len(t)-1]):
        for first in range(lo,hi,24):blocks.append((first,min(first+24,hi)))
    for first,last in blocks:
        safe();edges=t[first:last+1];clock=np.empty(2*len(edges)-1);clock[::2]=edges;clock[1::2]=(edges[:-1]+edges[1:])/2
        host.focus=(edges[0]+edges[-1])/2
        if first in corners:left=output[first].copy()
        log=np.log(clock);vel,slow,kernel,shape_weight=bank.coeff(clock)
        micro=bank.micro(log);sw=bank.sw(log)
        mat,bi,bn=old.operator(solver,clock,clock);mat[:,:13,old.QI]+=bi;mat[:,:13,old.QN]+=bn
        operator=mat[:,:,:old.DIM].copy();bias=mat[:,:,-1].copy()
        bg,den,we,wj,e0,j0,bare_slip,us,fq=coefficients(rawsrc,clock)
        hub=bg['h'];enu=bg['enu'];eg=bg['eg'];nus=4*bg['er']+bg['nuS']
        inject=np.zeros((len(clock),old.DIM))
        for idx,value in [(1,(4/3+bg['eb']/eg)*src.kk),(4,src.wave/3),(6,src.kk),(8,bg['sv']),(9,-(bg['a']*bg['sm'])**2*bg['sb']),(10,bg['hv']),(11,-(bg['a']*bg['hm'])**2*bg['hb']),(12,-hub)]:inject[:,idx]=value
        def rates(index,X,L,S,observe=False):
            nonlocal checks
            stress=bank.stress(L,S,kernel[index],shape_weight[index])*enu[index]
            stress[:,1]*=src.wave
            en=X@we[index]+e0[index]+stress[:,0];cur=X@wj[index]+j0[index]+stress[:,1]
            energy_phi=(us[index]-en/2-1.5*hub[index]*cur/src.kk)/den[index]
            phi=np.array([X[0,12],energy_phi[1]])
            slip=(stress[:,2]-eg[index]*X[:,old.QI]-nus[index]*X[:,old.QN])/src.kk+bare_slip[index]
            psi=phi+slip
            pd=cur/(2*src.kk)-hub[index]*psi+fq[index]
            if observe:
                return np.stack([phi,energy_phi,X[:,12],psi,pd,en,cur,*[np.full(2,c) for c in (us[index],den[index],hub[index])],*stress.T],axis=-1)
            physical=X.copy();physical[:,12]=phi
            dX=physical@operator[index].T+bias[index]+(stress[:,2]/src.kk)[:,None]*inject[index]
            dX[:,12]+=stress[:,1]/(2*src.kk)
            checks=max(checks,np.max(abs(dX[:,12]-pd))/max(np.max(abs(pd)),1e-90))
            normal=physical[:,N_IND].copy();normal[:,0]+=phi
            dlag=bank.bin_rhs(L,S,normal,psi,vel[index],slow[index],micro[index])
            dshape=adv(S,src.wave)+sw[index]
            return dX,dlag,dshape
        for idx,width in enumerate(np.diff(edges)):
            pos=2*idx;output[first+idx]=rates(pos,x,lag,shape,True)
            a,b,c=rates(pos,x,lag,shape);half=width/2
            d,e,f=rates(pos+1,x+half*a,lag+half*b,shape+half*c)
            g,h,i=rates(pos+1,x+half*d,lag+half*e,shape+half*f)
            j,l,m=rates(pos+2,x+width*g,lag+width*h,shape+width*i)
            x+=width/6*(a+2*d+2*g+j);lag+=width/6*(b+2*e+2*h+l);shape+=width/6*(c+2*f+2*i+m)
        output[last]=rates(len(clock)-1,x,lag,shape,True)
        if first in corners:seams.append(np.stack([left,output[first].copy()]))

    assert checks<.005 and np.isfinite(output).all() and np.isfinite(lag).all() and np.all(np.max(abs(lag-held),axis=2)>0)
    pack(f'matched-{mode}-{sub}.npz',t=t,observables=output,names=NAMES,ordinary_end=x,lag_end=lag,shape_end=shape,corners=host.corners,seams=np.stack(seams))
    return dict(mode=mode,sub=sub,bins=77,angular_orders=69,rate_check_pct=100*checks,seams=len(seams))
def main():
    bank=MatchedBank();rows=[run(m,s,bank) for m in MODES for s in (2,4)]
    table('evolution-controls.csv',rows);freeze('forecast-freeze.json',['entry-receipt.json','evolution-controls.csv']+[f'matched-{m}-{s}.npz' for m in MODES for s in (2,4)])
if __name__=='__main__':main()
