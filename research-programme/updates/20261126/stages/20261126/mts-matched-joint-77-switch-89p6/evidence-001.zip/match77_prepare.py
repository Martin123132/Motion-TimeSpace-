from match77_stage import *

def restore_bins(mode,bank,host):
    switch=host.t[0]
    with np.load(wave_input(f'original-through89/particular-heavy-{mode}.npz')) as ar:
        assert ar['eta'][-1]==89. and np.array_equal(ar['q'],bank.q)
        initial=ar['state'][:,:1];lag0=ar['lagEnd'][:,:,0,0];shape0=ar['shape'][-1,:,0]
    with np.load(wave_input(f'particular-heavy-{mode}.npz')) as ar:
        t=old.KIN.physical_axis(ar['eta'],89.,switch);st_clock=ar['stressClock'];stress=ar['stress']
    pre=old.KIN.get_flow(old.KIN.BASE89,'companion',t,initial)
    ticks,obs,normal,state=pre.evolve(st_clock,stress)
    assert ticks[-1]==switch
    ns=CubicSpline(np.log(ticks),normal[:,:,0,0]);ps=CubicSpline(np.log(ticks),obs[:,1,0,0])
    scale=np.max(abs(lag0),axis=1)[:,None];assert min(scale)>0
    shscale=np.max(abs(shape0))
    def shape_rhs(t,y):return adv(y,bank.k)+bank.sw(np.log(t))/shscale
    shape_sol=solve_ivp(shape_rhs,(89.,89.6),shape0/shscale,dense_output=True,max_step=.012,method='DOP853',rtol=1e-11,atol=1e-13)
    assert shape_sol.success
    shape_curve=CubicSpline(np.log(bank.axis),shape_sol.sol(bank.axis).T*shscale)
    def rhs(t,y):
        log=np.log(t);vel,slow,_,_=bank.coeff(t)
        return (bank.bin_rhs(y.reshape(77,69)*scale,shape_curve(log),ns(log),ps(log),vel,slow,bank.micro(log))/scale).ravel()
    def solve(step):
        sol=solve_ivp(rhs,(89.,switch),(lag0/scale).ravel(),t_eval=[switch],method='DOP853',max_step=step,rtol=1e-11,atol=1e-13)
        assert sol.success
        return sol.y[:,-1].reshape(77,69)*scale
    low=solve(.012);lag=solve(.006);shape=shape_sol.sol(switch)*shscale
    errs=100*np.max(abs(lag-low),axis=1)/np.max(abs(lag),axis=1)
    raw=bank.stress(lag,shape,*bank.coeff(switch)[2:])
    with np.load(old.stage_u.pin(f'matter-{mode}.npz')) as arc:
        target=CubicSpline(np.log(arc['stress_clock']),arc['stress'])(np.log(switch))
    err_st=100*abs(raw-target)/abs(target)
    return lag,shape,raw,errs,err_st,obs[-1,0,0,0]

def run(mode,bank):
    host=Host(mode,4);switch=host.t[0];state=host.launch.copy()
    with np.load(pinned(FIRST,f'launch-{mode}-matched-4.npz')) as ar:assert np.array_equal(state,ar['launch'])
    with np.load(pinned(CURRENT,f'launch-{mode}.npz')) as a:
        omega=a['omega'].item();rho=a['rho0'].item()/host.matched.environment(np.array([switch]))[0]['a'][0]
        target=a['live_data'];wave=a['live'];matrix=a['matrix'];units=a['units'];affine=a['affine'];osc=a['osc'];seam=a['seam_phi'].item()
        cond=np.linalg.cond(matrix);weak=np.linalg.cond(a['instant'])
        assert a['start'].item()==switch and np.allclose(target,[state[10]+3*state[12],state[11]],rtol=1e-12,atol=0)
    with np.load(history_window.previous(f'preparation-{mode}.npz')) as arc:offset=arc['current'][0]
    lag,shape,raw,errs,err_st,pre_phi=restore_bins(mode,bank,host)
    assert abs(pre_phi-seam)<.005*abs(seam)
    f,u=wave*np.array([1,omega]);state[10:12]=[f,u]
    hub,mass2,b,v=[a[0] for a in host.osc(np.array([switch]))];hfield,hmoment,he,hj=host.external(np.log(switch))
    allclose=lambda x,y:100*abs(x-y)/abs(y)
    launch_e=(v*u+mass2*b*f+he+3*v**2*state[12])/rho
    launch_j=(host.kk*v*f+hj)/rho
    obs=affine+units*(matrix@wave)
    rows=dict(mode=mode,condition=cond,instant_only_condition=weak,energy_inversion_pct=allclose(obs[0],target[0]),mean_current_inversion_pct=allclose(obs[1],target[1]),
              actual_energy_pct=allclose(launch_e,target[0]),actual_instant_current_pct=allclose(launch_j,target[1]-offset),
              instant_vs_mean_pct=allclose(launch_j,target[1]),incoming_phi_replay_pct=allclose(pre_phi,seam),
              bin_restart_refinement_pct=max(errs),stress_restart_pct=max(err_st),osc_entry_pct=100*np.linalg.norm([b-osc[0],(v-osc[1])/omega])/np.linalg.norm([osc[0],osc[1]/omega]))
    gates=['energy_inversion_pct','mean_current_inversion_pct','actual_energy_pct','actual_instant_current_pct','incoming_phi_replay_pct','bin_restart_refinement_pct','stress_restart_pct','osc_entry_pct']
    passed=all(np.isfinite(rows[k]) and rows[k]<=.5 for k in gates) and cond<3 and weak>1e6
    pack(f'matched-switch-{mode}.npz',t=switch,entry=state,fluid_entry=host.launch,lag=lag,shape=shape,raw_stress=raw,target=target,instant_target=target[1]-offset,recovered=[launch_e,launch_j],scaled_wave=wave,osc=osc,bin_errors=errs,stress_errors=err_st,passed=passed)
    return dict(**rows,passed=bool(passed))
def main():
    safe();locked('protocol.json');bank=MatchedBank();rows=[run(mode,bank) for mode in MODES]
    table('entry-tests.csv',rows)
    freeze('entry-receipt.json',['protocol.json','entry-tests.csv']+[f'matched-switch-{m}.npz' for m in MODES])
    assert all(row['passed'] for row in rows),rows
if __name__=='__main__':main()
