from match77_stage import *
def seam(mode):
    host=Host(mode,4);src=host.matched
    with np.load(ROOT/f'matched-switch-{mode}.npz') as ar:
        state=ar['entry'];fluid=ar['fluid_entry'];stress0=ar['raw_stress'];time=np.array([ar['t'].item()]);instant=ar['instant_target']
    assert np.array_equal(state[:10],fluid[:10]) and np.array_equal(state[12:],fluid[12:])
    phi=state[12];bg,force,_,coef,_,_,rho,den_f=src.environment(time)
    rho=rho[0];den_f=den_f[0];fac=1.5*bg['h'][0]/src.kk
    b,den_w,e,j,e0,j0,slip,us,fq=coefficients(host,time)
    den_w=den_w[0];vel=b['hv'][0];om=(b['a'][0]*b['hm'][0])**2
    wave_extra=host.external(np.log(time[0]))
    d_wave=vel*state[11]+om*b['hb'][0]*state[10]+wave_extra[2]+3*vel**2*phi
    j_wave=src.kk*vel*state[10]+wave_extra[3]
    d_fluid=rho*(fluid[10]+3*phi);j_fluid=rho*fluid[11]
    dshift=(d_wave-d_fluid)/2;jshift=fac*(j_wave-j_fluid)
    physical=stress0*bg['enu'][0];physical[1]*=src.wave
    fullwave=den_w*phi+(e[0]@state+e0[0]+physical[0])/2+fac*(j[0]@state+j0[0]+physical[1])-us[0]
    env=list(src.environment(time));env[2]=physical[None,:]
    from cycle3_inputs import Blind
    fe,fj=Blind(src).aggregate(env,fluid[None,:12])
    fullfluid=den_f*phi+fe[0]/2+fac*fj[0]-force['U'][0]
    assert abs(fullfluid+dshift+jshift-fullwave)<1e-8*abs(fullwave)
    with np.load(ROOT/f'matched-{mode}-4.npz') as ar:
        v=ar['observables'][0,0];assert abs(fullwave-(v[2]-v[1])*v[8])<1e-8*abs(fullwave)
    frac=lambda z:100*(z*fullwave.conjugate()).real/abs(fullwave)**2
    return dict(mode=mode,wave_entry_pct=100*abs(fullwave/den_w/phi),original_fluid_entry_pct=100*abs(fullfluid/den_f/phi),fluid_signed_share=frac(fullfluid),density_signed_share=frac(dshift),current_signed_share=frac(jshift),
        energy_shift_pct_of_launch=100*abs(dshift/den_w/phi),current_shift_pct_of_launch=100*abs(jshift/den_w/phi),wave_current_vs_original_instant_pct=100*abs(j_wave/rho-instant)/abs(instant))
def main():
    locked('score-receipt.json');rows=[seam(mode) for mode in MODES];table('seam-budget.csv',rows)
    freeze('seam-receipt.json',['score-receipt.json','match77_seam.py','seam-budget.csv'])
if __name__=='__main__':main()
