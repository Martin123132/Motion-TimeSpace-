from match77_stage import *

def forecast(mode,sub,bank):
    host=Host(mode,sub);t=host.t;kk=host.kk;k=host.wave
    bg,den,we,wj,_,_,_,_,_=coefficients(host,t)
    velocities=bg['sv']**2+bg['hv']**2
    potential_work=sum((bg['a']*bg[tag+'m'])**2*bg[tag+'b']*bg[tag+'v'] for tag in ('s','h'))
    energy_rate=6*potential_work
    jrate=kk*((8*bg['eg']/3+bg['eb'])+2*(4*bg['er']+bg['nuJ'])/3+bg['ec']+4*velocities)
    vel,slow,kernel,_=bank.coeff(t)
    lagrate=k*slow*(1-1/vel)/3
    binrate=k*bg['enu']*np.sum(kernel[:,1]*lagrate,axis=1)
    factor=bg['h']-(energy_rate/2+1.5*bg['h']*(jrate+binrate)/kk)/den
    sample=np.unique(np.linspace(0,len(t)-1,21,dtype=int));times=t[sample]
    solver=old.Wave(host);env=solver.env(times);zero=np.zeros((len(times),13),complex);probe=zero.copy();probe[:,12]=1
    response=solver.rhs(env,probe)-solver.rhs(env,zero)
    e_test=np.sum(we[sample,:13]*response,axis=1)
    j_test=np.sum(wj[sample,:13]*response,axis=1)
    pieces=[]
    for idx in sample:
        normal=np.zeros(69);normal[0]=1
        lag=bank.bin_rhs(np.zeros((77,69)),np.zeros(69),normal,np.array(1.),vel[idx],slow[idx],np.zeros((77,69)))
        pieces.append(k*bg['enu'][idx]*(kernel[idx,1]@lag[:,1]))
    numeric=-response[:,12]-(e_test/2+1.5*bg['h'][sample]*(j_test+np.array(pieces))/kk)/den[sample]
    jac_error=100*np.max(abs(numeric-factor[sample]))/np.max(abs(factor[sample]))
    assert jac_error<=.5
    with np.load(ROOT/f'matched-switch-{mode}.npz') as ar:pair=ar['entry'];fluid=ar['fluid_entry']
    host_bg,source,_,_,_,_,rho,_=host.matched.environment(t[:1]);rho=rho.item()
    omega2=(bg['a'][0]*bg['hm'][0])**2;v=bg['hv'][0];b=bg['hb'][0]
    forcing=host.external(np.log(t[0]))
    density=v*pair[11]+omega2*b*pair[10]+forcing[2]+3*v**2*pair[12]
    cur=kk*v*pair[10]+forcing[3]
    off=((density-rho*(fluid[10]+3*fluid[12]))/2+1.5*bg['h'][0]*(cur-rho*fluid[11])/kk)/den[0]
    with np.load(ROOT/f'matched-{mode}-{sub}.npz') as ar:phis=ar['observables'][:,:,0]
    pack(f'rate-pred-{mode}-{sub}.npz',t=t,coefficient=factor,entry=off*factor,live=(phis[:,0]-phis[:,1])*factor,offset=off)
    return dict(mode=mode,sub=sub,formula_vs_full_rhs_pct=jac_error)
def main():
    locked('seam-receipt.json');bank=MatchedBank()
    controls=[forecast(m,s,bank) for m in MODES for s in (2,4)]
    table('rate-jacobian-controls.csv',controls);freeze('rate-predictions.json',['seam-receipt.json','match77_rate.py','rate-jacobian-controls.csv']+[f'rate-pred-{m}-{s}.npz' for m in MODES for s in (2,4)])
    locked('rate-predictions.json');rows=[]
    for mode in MODES:
        for sub in (2,4):
            with np.load(ROOT/f'matched-{mode}-{sub}.npz') as ar:t=ar['t'];o=ar['observables'];corners=np.searchsorted(t,ar['corners']);seams=ar['seams']
            with np.load(ROOT/f'rate-pred-{mode}-{sub}.npz') as ar:forecasts=np.stack([ar['entry'],ar['live']],axis=1)
            sums=np.zeros((2,5))
            for seg,(lo,hi) in enumerate(zip(np.r_[0,corners],np.r_[corners,len(t)-1])):
                ticks=t[lo:hi+1];obs=o[lo:hi+1].copy()
                if seg<len(corners):obs[-1]=seams[seg,0]
                diff=CubicSpline(ticks,obs[:,:,1])(ticks,1)-obs[:,:,4]
                target=diff[:,0]-diff[:,1]
                for idx in (0,1):
                    pred=forecasts[lo:hi+1,idx];rem=target-pred
                    sums[idx]+=np.trapezoid(np.stack([abs(target)**2,abs(rem)**2,(pred*target.conj()).real,abs(obs[:,0,4])**2,abs(diff[:,0])**2],axis=1),ticks,axis=0)
            for label,(power,res,proj,pd,raw) in zip(('switch_offset','observed_phi_difference'),sums):
                rows.append(dict(mode=mode,sub=sub,model=label,unexplained_pct_of_route_difference=100*np.sqrt(res/power),signed_share_pct=100*proj/power,unexplained_pct_of_momentum_rate=100*np.sqrt(res/pd),original_pct_of_momentum_rate=100*np.sqrt(raw/pd)))
    table('rate-origin.csv',rows);freeze('rate-ledger.json',['rate-predictions.json','rate-origin.csv'])
if __name__=='__main__':main()
