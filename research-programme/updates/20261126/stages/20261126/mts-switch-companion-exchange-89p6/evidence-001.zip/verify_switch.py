import ast
import json

from junction import GRIDS, ROOT, SOURCES, TOL, digest, record, verify_freeze


def verify():
    verify_freeze()
    for folder, pin in SOURCES.values():
        assert digest(ROOT.parent / folder / "seal.json") == pin
    scores = json.loads((ROOT / "scores.json").read_text())
    checks = json.loads((ROOT / "crosscheck.json").read_text())
    assert scores["tolerance_pct"] == TOL and scores["coarse_fine_predicted_pct"] < TOL
    assert {(r["grid"],r["subdivisions"]) for r in scores["results"]} == {(m,n) for m in GRIDS for n in (2,4)}
    assert [r["grid"] for r in checks] == list(GRIDS)
    for r in scores["results"]:
        assert r["passes"] and r["sign_correct"] and abs(sum(r["shares"].values()) - r["projected_pct"]) < 1e-10
        assert all(0 <= r[k] < TOL for k in ("error_pct","current_error_pct","pressure_error_pct","direct_current_pct","prep_current_error_pct","quadrature_pct"))
        assert r["no_pressure_error_pct"] > 99 and r["exchange_only_error_pct"] > 99 and r["reverse_error_pct"] > 199
        sizes = r["exchange_integral_pct_of_current"]
        assert 0 < sizes["0.00025"] < sizes["0.0005"] < sizes["0.001"] < .1
    for r in checks:
        assert all(0 <= r[k] < TOL for k in ("density_rate_stencil_pct","density_rate_vs_archive_pct","archive_vs_required_pct","archive_vs_prefix_current_pct","archive_vs_prefix_pressure_pct","archive_vs_direct_pct"))
    assert not (ROOT / "__pycache__").exists()
    for file in ROOT.glob("*.py"):
        ast.parse(file.read_text())
    files = {path.name:digest(path) for path in sorted(ROOT.iterdir()) if path.is_file() and path.name!="seal.json"}
    record("seal.json", dict(files=files, sources=SOURCES))
    print("Verified switch and controls on both grids:", digest(ROOT/"seal.json"))


if __name__ == "__main__":
    verify()
