import argparse
import csv
import hashlib
import json
from pathlib import Path

import numpy as np
from scipy.integrate import solve_ivp
from scipy.interpolate import CubicSpline, make_interp_spline
from scipy.optimize import brentq
from scipy.special import roots_legendre

ROOT = Path(__file__).resolve().parent
SOURCES = {
    "wave": ("mts-photon-matter-89p6-20261124", "bc32739cb1aa9f24909005b4cfde0d6c056a9508b178a4e0fe126a9ba218a159"),
    "start": ("mts-switch-current-quadratures-89p6-20261125", "c865dc7c06afec41b22a7bfeb253821a1020fe663a98e1d133bf786e7962fc15"),
    "mean": ("mts-prehistory-padding-89p6-20261125", "7021f505d0479ad1ad1b0f8e8d3fa89df281ab32ff967ec51b963427b03dad47"),
    "comp": ("mts-wave-transfer-89p15-20261124", "31f9925322c86a7d9876cd31469a79dbb0f8bc1ae17acf2410c4486f9fdec962"),
    "joint": ("mts-matched-joint-77-switch-89p6-20261126", "3aab615be69d49dcdafeac123dc1c70ecd6cd18516791a15dd0c478d88a51845"),
}
GRIDS = ("p16", "p32")
TERMS = ("drag", "pressure", "lapse", "exchange")
TOL = 0.5


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def source(group, name):
    folder, seal = SOURCES[group]
    folder = ROOT.parent / folder
    assert digest(folder / "seal.json") == seal
    path = folder / name
    assert digest(path) == json.loads((folder / "seal.json").read_text())["files"][name]
    return path


def save(name, body):
    path = ROOT / name
    if path.exists():
        assert path.read_bytes() == body, name
    else:
        with path.open("xb") as stream:
            stream.write(body)


def record(name, data):
    save(name, (json.dumps(data, indent=2, allow_nan=False, sort_keys=True) + "\n").encode())


def number(value):
    return [float(value.real), float(value.imag)]


def pct(value, target):
    assert abs(target) > 0
    return float(100 * abs(value - target) / abs(target))


def share(value, target):
    return float(100 * (value / target).real)


def forecast(grid):
    with np.load(source("start", f"launch-{grid}.npz")) as packet:
        end, mass, rho0, kk = [float(packet[key]) for key in ("start", "mass", "rho0", "kk")]
        oscillator = packet["osc"]
    with np.load(source("wave", "material-halfstep/forcing-heavy.npz")) as packet:
        times = packet["eta"]
        select = (times > end - .30) & (times <= end)
        nodes = times[select]
        qkeys = packet["keys"].tolist()
        names = ["hfield", "henergy", "htrace", "hJ"]
        forcing = make_interp_spline(nodes, packet["values"][[qkeys.index(key) for key in names]][:, select, 0].T, k=5)
        keys = packet["bgkeys"].tolist()
        bg = make_interp_spline(nodes, packet["background"][[keys.index("a"), keys.index("h")]][:, select].T, k=5)
    with np.load(source("wave", f"particular-heavy-{grid}.npz")) as packet:
        sample = packet["eta"]
        select = (sample > end - .18) & (sample <= end)
        gridtimes = sample[select]
        obs = packet["obs"][select, :, 0, 0]
        fields = make_interp_spline(gridtimes, obs[:, [0, 1, 10]], k=5)
    with np.load(source("wave", "exact-phase-extension.npz")) as packet:
        angles = CubicSpline(packet["heavy_efold"], packet["phase_h"])
    def clock(time):
        scale = bg(time)[..., 0]
        return angles(np.log(scale)) - angles(np.log(bg(end)[0]))
    def speed(time):
        scale = bg(time)[..., 0]
        return angles(np.log(scale), 1) * bg(time, 1)[..., 0] / scale
    begin = brentq(lambda time: clock(time) + np.pi, end - .14, end - .05, xtol=5e-14)
    def background(time, state):
        scale, hub = bg(time)
        field, velocity = state
        return [velocity, -2 * hub * velocity - (scale * mass) ** 2 * field]
    osc = solve_ivp(background, (end, begin), oscillator, method="DOP853", rtol=2e-12, atol=2e-15,
                    max_step=.001, dense_output=True)
    assert osc.success and gridtimes[-1] <= end and nodes[-1] <= end
    def physical(time):
        scale, hub = bg(time).T
        field, vel = osc.sol(time)
        phi, psi, pert = fields(time).T
        pert_rate = fields(time, 1).T[2]
        drive, energy, trace, extcur = forcing(time).T
        extcur_rate = forcing(time, 1).T[3]
        rho = rho0 / scale
        potential = (mass * scale) ** 2 * field
        velocity = pert_rate - vel * (psi + 3 * phi) - drive
        pforce = (energy - trace) / 3
        current = (kk * vel * pert + extcur) / rho
        pres = (vel * velocity - potential * pert + pforce + 3 * vel**2 * phi) / rho
        sx = (2 * hub * extcur + extcur_rate + kk * (vel * drive - pforce)) / rho + kk * (vel**2 / rho - 1) * psi
        work = np.stack([-hub * current, kk * pres, kk * psi, sx], axis=-1)
        return current, work
    rho = rho0 / bg(end)[0]
    hub = bg(end)[1]
    factor = 1.5 * hub * rho / kk
    rows = []
    for order in (48, 96):
        roots, weights = roots_legendre(order)
        phase = (roots - 1) * np.pi / 2
        times = np.array([brentq(lambda time: clock(time) - angle, begin, end, xtol=5e-14) for angle in phase])
        current, work = physical(times)
        pieces = -np.pi / 2 * (weights * (phase + np.pi) / (np.pi * speed(times))) @ work
        companion = sum(pieces)
        direct = weights @ current / 2 - physical(end)[0]
        mean_rate = speed(end) / np.pi * (physical(end)[0] - physical(begin)[0])
        delta_pressure = (mean_rate - physical(end)[1].sum() + hub * companion) / kk
        impulse = {}
        for width in (.001, .0005, .00025):
            points = end + (roots - 1) * width / 2
            impulse[str(width)] = number(width / 2 * (weights @ physical(points)[1][:, 3]))
        rows.append(dict(grid=grid, order=order, begin=begin, end=end, last_field_time=float(gridtimes[-1]),
                         last_forcing_time=float(nodes[-1]), factor=float(factor), rho=float(rho), hub=float(hub), kk=kk,
                         current=number(companion), direct=number(direct), pressure=number(delta_pressure),
                         constraint=number(factor * companion), terms={k:number(v) for k,v in zip(TERMS,pieces)},
                         exchange_integrals=impulse))
    return rows


def freeze():
    rows = [row for grid in GRIDS for row in forecast(grid)]
    record("forecast.json", dict(sources=SOURCES, predictions=rows))
    record("freeze.json", {key:digest(ROOT / key) for key in ("PROTOCOL.md", "junction.py", "forecast.json")})


def verify_freeze():
    for key, value in json.loads((ROOT / "freeze.json").read_text()).items():
        assert digest(ROOT / key) == value


def score():
    verify_freeze()
    rows = json.loads((ROOT / "forecast.json").read_text())["predictions"]
    results = []
    for grid in GRIDS:
        low, high = [row for row in rows if row["grid"] == grid]
        val = lambda key: complex(*high[key])
        with np.load(source("joint", f"matched-switch-{grid}.npz")) as packet:
            fixed = packet["fluid_entry"][12]
            assert fixed == packet["entry"][12] and np.array_equal(packet["entry"][:10], packet["fluid_entry"][:10])
            needed_j = packet["fluid_entry"][11] - packet["recovered"][1]
        with np.load(source("mean", f"preparation-{grid}.npz")) as packet:
            assert packet["eta"][0] == high["end"] and packet["density"][0,0] == 0.
            previous_mean = packet["current"][0]
            previous_pressure = packet["pressure"][0,0]
        with np.load(source("comp", f"companion-{grid}.npz")) as packet:
            assert packet["eta"][0] == high["end"] and packet["delta_d"][0,0] == 0.
            prior_pressure = previous_pressure + packet["delta_p"][0,0]
        for sub in (2,4):
            with np.load(source("joint", f"matched-{grid}-{sub}.npz")) as packet:
                assert packet["t"][0] == high["end"]
                entry = packet["observables"][0,0]
                assert entry[2] == fixed
                target = (entry[1] - fixed) * entry[8]
            pred = val("constraint")
            relative = pct(pred, target)
            parts = {k:complex(*v)*high["factor"] for k,v in high["terms"].items()}
            results.append(dict(grid=grid, subdivisions=sub, required=number(target), predicted=number(pred),
                                sign_correct=share(pred,target)>0, projected_pct=share(pred,target),
                                error_pct=relative, passes=bool(share(pred,target)>0 and relative<=TOL),
                                remaining_pct_of_launch=float(100*abs(pred-target)/abs(entry[8]*fixed)),
                                size_pct_of_launch=float(100*abs(pred)/abs(entry[8]*fixed)),
                                required_pct_of_launch=float(100*abs(target)/abs(entry[8]*fixed)),
                                current_error_pct=pct(val("current"),needed_j), prep_current_error_pct=pct(val("current"),previous_mean),
                                pressure_error_pct=pct(val("pressure"),prior_pressure), signed_pressure_pct=share(val("pressure"),prior_pressure),
                                quadrature_pct=pct(complex(*low["constraint"]),pred), direct_current_pct=pct(val("current"),val("direct")),
                                reverse_error_pct=pct(-pred,target), null_error_pct=pct(0,target),
                                no_pressure_error_pct=pct(pred-parts["pressure"],target),
                                exchange_only_error_pct=pct(parts["exchange"],target),
                                shares={k:share(v,target) for k,v in parts.items()},
                                exchange_integral_pct_of_current={k:100*abs(complex(*v)/needed_j) for k,v in high["exchange_integrals"].items()}))
    cross = pct(complex(*results[1]["predicted"]),complex(*results[3]["predicted"]))
    assert all(row["null_error_pct"]==100 and row["reverse_error_pct"]>100 and
               row["direct_current_pct"] <= TOL and row["quadrature_pct"]<=TOL for row in results)
    record("scores.json", dict(tolerance_pct=TOL,results=results,coarse_fine_predicted_pct=cross))
    for r in results[1::2]:
        print(json.dumps(r))
    print("cross",cross)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("action", choices=("freeze","score"))
    args = parser.parse_args()
    assert not any((path/"STOP-REQUESTED").exists() for path in [ROOT,ROOT.parent])
    (freeze if args.action=="freeze" else score)()
