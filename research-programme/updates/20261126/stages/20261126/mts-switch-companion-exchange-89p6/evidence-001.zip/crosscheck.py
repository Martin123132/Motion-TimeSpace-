import json
import sys

import numpy as np
from scipy.interpolate import make_interp_spline
from scipy.special import roots_legendre

from junction import GRIDS, ROOT, TERMS, TOL, number, pct, record, share, source, verify_freeze


def slope(times, values, count):
    assert np.all(np.diff(times[:count]) > 0)
    return make_interp_spline(times[:count] - times[0], values[:count], k=3)(0.0, 1)


def run():
    verify_freeze()
    assert (ROOT / 'scores.json').is_file()
    kernel_path = source("comp", "wave_kernel.py")
    source("comp", "local_stage.py")
    sys.path.insert(0, str(kernel_path.parent))
    import wave_kernel
    archive = json.loads((ROOT / "forecast.json").read_text())["predictions"]
    scored = json.loads((ROOT / "scores.json").read_text())["results"]
    checks = []
    for grid in GRIDS:
        row = next(row for row in archive if row["grid"]==grid and row["order"]==96)
        goal = next(row for row in scored if row["grid"]==grid and row["subdivisions"]==4)
        clock, curves, kk, mass, rho0 = wave_kernel.read(grid)
        theta, weights = roots_legendre(96)
        phase = (theta - 1) * np.pi / 2
        end, hub = row["end"], row["hub"]
        assert abs(clock(end)) < 1e-9 and abs(kk-row["kk"]) < 1e-13
        terms = {key:-np.pi/2*(weights*(phase+np.pi)/np.pi)@curves[key+"_phase"](phase)[:,0] for key in TERMS}
        current = sum(terms.values())
        from_values = (weights/2) @ curves["j"](phase)[:,0] - curves["j"](0.)[0]
        rate = clock(end,1)/np.pi*(curves["j"](0.)-curves["j"](-np.pi))[0] - curves["wj"](0.)[0]
        pressure = (rate + hub*current)/kk
        predicted_derivative = -complex(*row["current"]) - 3*hub*complex(*row["pressure"])
        with np.load(source("comp",f"companion-{grid}.npz")) as comp, np.load(source("mean",f"preparation-{grid}.npz")) as extra:
            assert np.array_equal(comp["eta"],extra["eta"])
            times=comp["eta"]
            density=comp["delta_d"][:,0]+extra["density"][:,0]
            assert times[0]==end and density[0]==0
            grad5,grad9=(slope(times,density,n) for n in (5,9))
        target=complex(*goal["required"])
        checks.append(dict(grid=grid, archive_vs_direct_pct=pct(current, from_values),
                           archive_vs_prefix_current_pct=pct(current, complex(*row["current"])),
                           archive_vs_prefix_pressure_pct=pct(pressure,complex(*row["pressure"])),
                           archive_vs_required_pct=pct(current*row["factor"],target),
                           archive_pressure_share_pct=share(terms["pressure"]*row["factor"],target),
                           predicted_density_rate=number(predicted_derivative),
                           archived_density_rate=number(grad9),
                           density_rate_vs_archive_pct=pct(predicted_derivative, grad9),
                           density_rate_stencil_pct=pct(grad5,grad9)))
    record("crosscheck.json", checks)
    print(checks)


if __name__ == "__main__":
    run()
