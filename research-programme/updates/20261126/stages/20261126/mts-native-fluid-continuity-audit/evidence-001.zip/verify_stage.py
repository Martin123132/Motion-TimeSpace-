from audit_io import BASE, ROOT, SIGN, LAST, check, last, sha, read, put
import json
import csv
import sys
import numpy as np

def run(create=False):
    assert sys.flags.optimize==0, 'run without -O'
    digest = lambda name: json.loads((ROOT/name).read_bytes())
    for name in ('method','native-samples','balance-receipt','clock-method','clock-forecast','nu-method','nu-forecast','paired-forecasts'):
        check(name+'.json')
    for path in ROOT.glob('*.py'):
        compile(path.read_bytes(),str(path),'exec')
    assert all(path.is_file() and not path.name.endswith('.partial') for path in ROOT.iterdir())
    selected = read(ROOT/'selected.npz')
    assert len(np.unique(selected['pair']))==34 and selected['failed'].sum()==17
    assert np.array_equal(np.sort(selected['pair'].ravel()),selected['idx'])
    reference = read(ROOT/'corrected-reference.npz')
    truth = reference['fluid']-reference['wave']
    assert truth.shape==(11,2,782) and np.all(np.diff(reference['k'])>0)
    result = digest('neutrino-scores.json')['cases']
    for name,entry in result.items():
        arr = read(ROOT/('nu-'+name+'.npz'))
        assert np.array_equal(arr['k'],reference['k']) and np.array_equal(arr['time'],reference['time'])
        assert np.all(np.diff(arr['t'])>0) and arr['t'][0]==89.275 and arr['t'][-1]==90.45
        gap = arr['fluid']-arr['wave'][:,:2]
        def rates(pred,target,den):
            return np.max(100*abs(pred-target),axis=0)/den
        score = rates(gap,truth,np.max(abs(truth),axis=0))
        legacy = rates(gap,truth,reference['oldnorm'])
        drift = rates(gap-gap[0],truth-truth[0],np.max(abs(truth-truth[0]),axis=0))
        for axis,channel in enumerate(('energy','current')):
            for key,actual in [('gap',score),('change',drift)]:
                saved = entry['contrasts'][key][channel]
                np.testing.assert_allclose(saved['worst'],np.max(actual[axis]),rtol=2e-13)
                assert (actual[axis]>.5).sum()==saved['over']
        np.testing.assert_array_equal((legacy>.5).sum(axis=1),entry['contrasts']['old_denom']['over'])
        expected = [0,3] if name=='old-trace' else [0,0]
        np.testing.assert_array_equal((score>.5).sum(axis=1),expected)
        if name=='energy-current':
            np.testing.assert_array_equal((drift>.5).sum(axis=1),[1,2])
            assert not np.any(legacy>.5)
    old = digest('clock-scores.json')['comparisons']
    assert old['legacy']['as_frozen']['over']==[13,4]
    native = digest('native-balance-scores.json')
    for rate in ('160','640','1280'):
        for route in ('work','tracer'):
            assert max(native[rate][route]['max_pct'])<.5
    pair = digest('paired-scores.json')
    for tag,entry in pair.items():
        previous = entry['old-trace']
        current = entry['energy-current']
        assert current['A']['change']['peak']<previous['A']['change']['peak']/20
        assert current['X']['change']['peak']<previous['X']['change']['peak']/5
        assert current['S']['change']['peak']>30
        assert entry['reference_derivative']['S']['worst']<1e-5
        for name in ('energy-current','old-trace'):
            arr = read(ROOT/('paired-'+tag+'-'+name+'.npz'))
            assert np.array_equal(arr['k'],reference['k']) and len(arr['t'])==61
            assert arr['t'][0]==89.275 and arr['t'][-1]==89.65
    with (ROOT/'source-repair-all-modes.csv').open() as handle:
        rows = list(csv.DictReader(handle))
        assert np.array_equal([float(row['k']) for row in rows],reference['k'])
    for path in ROOT.glob('*.npz'):
        with np.load(path,allow_pickle=False) as packet:
            for key in packet.files:
                vals = packet[key]
                if np.issubdtype(vals.dtype,np.number):
                    assert np.isfinite(vals).all(),(path.name,key)
    names = {path.name:sha(path) for path in ROOT.iterdir() if path.name!='seal.json'}
    seal = dict(files=names,parents={LAST.name:SIGN},scope='Native fluid continuity and ordinary-matter driving; early-input heavy fluid-minus-wave contrasts, shared cold/matched source controls; no new photon or observational comparison.')
    if create:put('seal.json',seal)
    assert digest('seal.json')==seal
    print('Verified',len(names),'files; 782 energy and current modes; cold and matched controls; seal',sha(ROOT/'seal.json'))

if __name__=='__main__':
    assert sys.argv[1:] in ([],['--seal'])
    run(bool(sys.argv[1:]))
