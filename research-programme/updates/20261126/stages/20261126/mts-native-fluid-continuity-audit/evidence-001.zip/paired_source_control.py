from clock_forecast import *
import importlib.util
helper_spec = importlib.util.spec_from_file_location('audit_sources',ROOT/'sources.py')
audit_sources = importlib.util.module_from_spec(helper_spec)
helper_spec.loader.exec_module(audit_sources)
load_native,ratio = audit_sources.load_native,audit_sources.ratio
from types import SimpleNamespace

CUT = 89.275
END = 89.65
TAGS = ('cold','matched')
CASES = ('old-trace','energy-current')

def initial(tag):
    bank = load_native(tag,before=CUT)
    data = bank.data
    assert bank.time[-1] == CUT and len(bank.k) == 782
    def deriv(values,order=1):
        return make_interp_spline(bank.time[-6:],values[-6:],k=5)(CUT,order)
    data0 = lambda names: np.stack([data[name][-1] for name in names])
    dg,jg,gn,hh,xx = (var[-1] for var in (bank.D,bank.J,bank.G,bank.H,bank.X))
    trace = -(deriv(bank.D)+bank.k*jg+bank.B[-1]*xx)/(2*hh)
    slope = -(deriv(bank.D,2)+bank.k*deriv(bank.J)+deriv(bank.B)*xx+bank.B[-1]*deriv(bank.X))/(2*hh)-trace*deriv(bank.H)/hh
    mass = trace-dg
    massp = slope-deriv(bank.D)
    shear = (dg+2*mass)/3-(deriv(bank.J)+2*hh*jg)/bank.k
    shearp = (deriv(bank.D)+2*massp)/3-(deriv(bank.J,2)+2*deriv(bank.H)*jg+2*hh*deriv(bank.J))/bank.k
    back = 3*bank.pnu-bank.G
    drivers = ['pig','pir','opacity','delta_p_b']
    forc = data0(drivers)
    forcp = np.stack([deriv(data[name]) for name in drivers])
    weights = data0(['grhoc_t','grhob_t','grhog_t','grhor_t'])
    slow,slowp = bank.slow[-1],deriv(bank.slow)
    pressure = data['gpres'][-1]
    a0 = bank.a[-1]
    m = rho = 0.
    hf = np.zeros((2,len(bank.k)))
    if tag == 'matched':
        early = read(ep('matched-early.npz'))
        hf = read(ROOT/'clock-inputs.npz')['local_at_cut'][4:6]
        m,rho = early['mass'].item(),early['rho'].item()
        np.testing.assert_allclose(pressure,early['ambient_gpress'],rtol=2e-14)
    ini = np.vstack([xx,data0(['clxc','clxb','vb','clxg','qg','clxr','qr']),dg,jg,gn,hf])
    return SimpleNamespace(k=bank.k,ini=ini,h0=hh,a0=a0,m=m,rho=rho,pressure=pressure,trace=trace,slope=slope,mass=mass,massp=massp,
                 shear=shear,shearp=shearp,back=back[-1],backp=deriv(back),forc=forc,forcp=forcp,
                 weights=weights,slow=slow,slowp=slowp)

def predict(tag,case):
    par = initial(tag)
    grid = par.k
    def evaluate(time,vec):
        elapsed = time-CUT
        xx,cd,bd,vb,ph,qg,rd,qr,dn,jn,gn,fd,fj = vec.reshape(13,-1)
        dif = par.h0**2-par.pressure
        scale = 1+elapsed*par.h0+elapsed**2*dif/4
        ah = (par.h0+elapsed*dif/2)/scale
        mass = par.mass+elapsed*par.massp
        shear = par.shear+elapsed*par.shearp
        tb = par.back+elapsed*par.backp
        trace = dn+mass if case=='energy-current' else par.trace+elapsed*par.slope
        pig,pir,opacity,pb = par.forc+elapsed*par.forcp
        gc,gb,gg,gr = par.weights/np.array([scale,scale,scale**2,scale**2])
        slip = opacity*(4*vb/3-qg)
        if tag=='cold':
            heavy = fdprime = fjprime = np.zeros_like(xx)
        else:
            ascale = par.a0*scale
            rr = (grid/(par.m*ascale))**2
            press = rr/(np.sqrt(1+rr)+1)**2*(fd+3*ah*fj/grid)
            heavy = par.rho/ascale*(fd+3*press)/2
            fdprime,fjprime = -3*ah*press-grid*fj-xx,-ah*fj+grid*press
        return np.asarray([-ah*xx-(gc*cd+gb*bd)/2-gg*ph-gr*rd-par.slow-elapsed*par.slowp-trace-heavy,
                           -xx,-xx-grid*vb,-ah*vb+grid*pb-gg/gb*slip,-4*xx/3-grid*qg,grid*(ph-2*pig)/3+slip,
                           -4*xx/3-grid*qr,grid*(rd-2*pir)/3,-2*ah*(dn+mass)-grid*jn-(4*gn+tb)*xx/3,
                           -2*ah*jn+grid*((dn+2*mass)/3-shear),-ah*(2*gn+tb),fdprime,fjprime]).ravel()
    time = np.arange(round(CUT*160),round(END*160)+1)/160
    sol = solve_ivp(evaluate,(CUT,END),par.ini.ravel(),method='DOP853',rtol=1e-12,atol=3e-17,max_step=1/640,t_eval=time)
    assert sol.success and np.isfinite(sol.y).all()
    hist = sol.y.T.reshape(len(time),13,-1)
    elapsed = (time-CUT)[:,None]
    trace = hist[:,8]+par.mass+elapsed*par.massp if case=='energy-current' else par.trace+elapsed*par.slope
    pack(f'paired-{tag}-{case}.npz',t=time,k=grid,X=hist[:,0],D=hist[:,8],J=hist[:,9],A=trace,S=par.shear+elapsed*par.shearp)

def freeze_pair():
    check('nu-forecast.json')
    files = [ROOT/'paired_source_control.py',ROOT/'sources.py',ROOT/'nu-method.json',ROOT/'clock-forecast.json']
    for tag in TAGS:
        for case in CASES:
            guard()
            predict(tag,case)
            files.append(ROOT/f'paired-{tag}-{case}.npz')
    freeze('paired-forecasts.json',files)

def score():
    check('paired-forecasts.json')
    res = {}
    for tag in TAGS:
        native = load_native(tag,before=END)
        keep = native.time>=CUT
        time = native.time[keep]
        assert time[-1]==END
        def inferred(degree):
            grad = lambda field: make_interp_spline(native.time,field,k=degree)(time,1)
            trace = -(grad(native.D)+native.k*native.J[keep]+native.B[keep]*native.X[keep])/(2*native.H[keep])
            shear = (2*trace-native.D[keep])/3-(grad(native.J)+2*native.H[keep]*native.J[keep])/native.k
            return trace,shear
        trace,shear = inferred(7)
        fifth = inferred(5)
        target = dict(X=native.X[keep],A=trace,D=native.D[keep],J=native.J[keep],S=shear)
        res[tag] = dict(reference_derivative={name:ratio(test,ref) for name,test,ref in zip(('A','S'),fifth,(trace,shear))})
        for case in CASES:
            arr = read(ROOT/f'paired-{tag}-{case}.npz')
            assert np.array_equal(arr['t'],time) and np.array_equal(arr['k'],native.k)
            res[tag][case] = {name:dict(full=ratio(arr[name],ref),change=ratio(arr[name]-arr[name][0],ref-ref[0])) for name,ref in target.items()}
            if tag=='matched':
                core = read(ROOT/f'nu-{case}.npz')
                sel = np.searchsorted(core['t'],time)
                for name,data in [('X',core['X'][sel]),('A',core['sectors'][sel,4])]:
                    err = ratio(arr[name],data)['peak']
                    assert err<2e-6,(name,err)
                    res[tag][case][name]['full_forecast_replay_pct'] = err
            print(tag,case,{name:round(res[tag][case][name]['change']['peak'],7) for name in target})
    put('paired-scores.json',res)

if __name__=='__main__':
    if sys.argv[1:]==['forecast']:freeze_pair()
    elif sys.argv[1:]==['score']:score()
    else:raise SystemExit('select forecast or score')
