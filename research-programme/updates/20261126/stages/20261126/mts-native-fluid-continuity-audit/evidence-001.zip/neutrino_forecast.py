from clock_forecast import *
CUT=89.275
def massive_inputs(k,ordinary):
    fields=['grhonu_t','clxnu','dgq','grhov_t','qde','grhob_t','vb','grhog_t','qg','grhor_t','qr','gpres','a','adotoa','dgrho','etak']
    chunks=[];paths=[];ks=[]
    for n in range(38):
        path=prev.native.pin(prev.bank,f'matched-native/linear-heavy-{n:02}.npz');paths.append(path)
        with np.load(path) as ar:
            sel=(ar['eta']>=89.15)&(ar['eta']<=CUT);tm=ar['eta'][sel];assert ar['good'][:,sel].all()
            ids=[ar['keys'].tolist().index(s) for s in fields];chunks.append(ar['values'][:,sel][:,:,ids].transpose(2,1,0));ks.extend(ar['k'])
    assert np.array_equal(k,ks);q=dict(zip(fields,np.concatenate(chunks,axis=2)))
    bgpath=prev.native.pin(prev.bank,'matched-native/background-heavy.npz')
    with np.load(bgpath) as ar:
        pos=np.searchsorted(ar['eta'],tm);v=ar['sphidot'][pos,None];b=ar['sphi'][pos,None];mu=q['a']*ar['smass'].item()
    Gn=q['grhonu_t'];pressure=q['gpres']-(q['grhog_t']+q['grhor_t'])/3-(v*v-(mu*b)**2)/2
    dn=Gn*q['clxnu'];jn=q['dgq']-q['grhov_t']*q['qde']-q['grhob_t']*q['vb']-q['grhog_t']*q['qg']-q['grhor_t']*q['qr']
    Tb=3*pressure-Gn;H=q['adotoa'];X=(q['dgrho']/2+k*q['etak'])/H;res={}
    for deg in (5,7):
        def der(arr,order=1):return make_interp_spline(tm[-deg-1:],arr[-deg-1:],k=deg)(CUT,order)
        A=ordinary[f'anu{deg}'];Ap=ordinary[f'anuprime{deg}']
        T=A-dn[-1];Tp=Ap-der(dn);p=(dn[-1]+2*T)/3
        S=p-(der(jn)+2*H[-1]*jn[-1])/k
        Sp=(der(dn)+2*Tp)/3-(der(jn,2)+2*der(H)*jn[-1]+2*H[-1]*der(jn))/k
        Acheck=-(der(dn)+k*jn[-1]+(Gn[-1]+pressure[-1])*X[-1])/(2*H[-1])
        assert np.max(abs(A-Acheck))<=1e-10*np.max(abs(A)),np.max(abs(A-Acheck))
        res[str(deg)]=np.stack([dn[-1],jn[-1],Gn[-1],T,Tp,S,Sp,Tb[-1],der(Tb),A,Ap])
    return res,[*paths,bgpath]
def run():
    guard();check('clock-forecast.json')
    ordinary=read(ep('matched-ordinary-input.npz'));early=read(ep('matched-early.npz'));clock=read(ROOT/'clock-inputs.npz')
    k=early['grid'];a0=early['scale'];h0=early['hub'];gp=early['ambient_gpress'];mu0=early['mass'].item();rho=early['rho'].item()
    with np.load(ep('matched-ordinary-physical.npz')) as ar:t=ar['time'];tc=ar['centers'];old_a=ar['scale']
    phase=CubicSpline(t,mu0*old_a).antiderivative()(t)
    def geom(dt):
        f=1+h0*dt+(h0*h0-gp)*dt*dt/4;return a0*f,(h0+(h0*h0-gp)*dt/2)/f,1/f
    aa=geom((t-CUT)[:,None])[0];sources,paths=massive_inputs(k,ordinary)
    pack('massive-inputs.npz',k=k,order5=sources['5'],order7=sources['7'],keys=['D','J','G','T','Tprime','S','Sprime','Tb','Tbprime','A','Aprime'])
    freeze('nu-method.json',[ROOT/'NEUTRINO.md',ROOT/'neutrino_forecast.py',ROOT/'clock-forecast.json',ROOT/'massive-inputs.npz',ep('matched-ordinary-input.npz'),ep('matched-early.npz'),ep('matched-ordinary-physical.npz'),*paths])
    files=[]
    for name,deg,shear,tr,step in [('old-trace',5,1,False,640),('energy-current',5,1,True,640),('constant-shear',5,0,True,640),('stencil7',7,1,True,640),('energy-current-fine',5,1,True,1280)]:
        guard();dn,jn,gn,T,Tp,S,Sp,Tb,Tbp,A,Ap=sources[str(deg)];init=np.vstack([clock['local_at_cut'],early['force'],ordinary['matter'],dn,jn,gn])
        def rhs(tm,y,source=False):
            dt=tm-CUT;a,H,ratio=geom(dt);v=y.reshape(len(init),-1)
            bg,vel,f,w,e,j,X,cold,bary,vb,dg,qg,dr,qr,D,J,G=v
            m2=(a*mu0)**2;rr=k*k/m2;cs=rr/(np.sqrt(1+rr)+1)**2;p=cs*(e+3*H*j/k)
            gc,gb,gg,gr=ordinary['weights']*np.array([ratio,ratio,ratio**2,ratio**2])
            pig,pir,opacity,pb=ordinary['forcing']+dt*ordinary['controls5']
            ss=S+shear*dt*Sp;trace=T+dt*Tp;backtrace=Tb+dt*Tbp
            nu=D+trace if tr else A+dt*Ap
            sector=np.stack([(gc*cold+gb*bary)/2,gg*dg,gr*dr,ordinary['slow']+dt*ordinary['slowprime5'],nu,rho/a*(e+3*p)/2])
            if source:return sector
            slip=opacity*(4*vb/3-qg)
            out=[vel,-2*H*vel-m2*bg,w,-2*H*w-(m2+k*k)*f-vel*X,-3*H*p-k*j-X,-H*j+k*p,
                 -H*X-np.sum(sector,axis=0),-X,-X-k*vb,-H*vb+k*pb-gg/gb*slip,
                 -4*X/3-k*qg,k*(dg-2*pig)/3+slip,-4*X/3-k*qr,k*(dr-2*pir)/3,
                 -2*H*(D+trace)-k*J-(4*G+backtrace)*X/3,-2*H*J+k*((D+2*trace)/3-ss),-H*(2*G+backtrace)]
            return np.asarray(out).ravel()
        sol=solve_ivp(rhs,(CUT,t[-1]),init.ravel(),method='DOP853',rtol=1e-12,atol=3e-17,max_step=1/step,t_eval=t)
        assert sol.success;hist=sol.y.T.reshape(len(t),len(init),-1);mean=project_state(hist[:,:6],aa,t,tc,mu0,rho,k,phase)
        sec=np.stack([rhs(tm,y,True) for tm,y in zip(t,sol.y.T)])
        file=ROOT/('nu-'+name+'.npz');pack(file.name,k=k,t=t,time=tc,wave=mean,fluid=hist[np.searchsorted(t,tc),4:6],X=hist[:,6],
                sectors=sec,D=hist[:,-3],J=hist[:,-2],G=hist[:,-1],evaluations=sol.nfev)
        files.append(file);print('frozen',name,flush=True)
    freeze('nu-forecast.json',[ROOT/'nu-method.json',*files])
if __name__=='__main__':run()
