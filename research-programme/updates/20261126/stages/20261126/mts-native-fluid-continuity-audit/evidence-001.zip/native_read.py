from audit_io import *
from unittest.mock import patch
import tempfile,subprocess

def collect(model,func):
    guard();check('method.json');selected=read(ROOT/'selected.npz');ns=cap.diag.native;assert model=='heavy'
    spec=prev.native.pin(prev.bank,'exact-phase-extension.npz');status=ns.obj(ns.source('runs/heavy/status.json'))
    for file in ns.engine.inherited.native_hashes():ns.checked(file,status['input_hashes'][str(file)])
    params=ns.engine.inherited.params_for(spec,background_boost=8.);params.DoLateRadTruncation=False
    bg=ns.engine.camb.get_background(params);bg.Params.Accuracy.IntTolBoost=6
    with np.load(prev.native.pin(prev.bank,'matched-native/linear-heavy-00.npz')) as ar:oldtimes=ar['eta'][17:]
    original=np.unique(np.r_[oldtimes,np.arange(round(89.55*160),round(90.45*160)+1)/160])
    sw=prev.native.switch();k=read(old.pin('preparation.npz'))['k']
    with cap.pin('capture-heavy.csv').open() as f:groups=list(csv.DictReader(f))
    standard=['a','H','mts_drho_h','mts_dp_h','mts_q_h','mts_match_count','mts_match_a','mts_match_tau','mts_nonheavy_change']
    custom=['tau','k','a','adotoa','etak','sigma','dgq','dgrho','clxc']
    fields=standard[:];fields[0]='a_diag';fields[1]='H_diag';fields+=custom
    idx=[*range(len(standard)),*[len(standard)+cap.NAMES.index(key) for key in custom]]
    with patch.object(cap.diag.symbolic,'compile_sympy_to_camb_source_func',return_value=func):
        for rate in (160,640,1280):
            ticks=original if rate==160 else np.unique(np.r_[original,np.arange(round(89.125*rate),round(89.925*rate)+1)/rate,sw+np.array([-.00012,-.00005,-.00002,.00002,.00005,.00012])])
            keep=(ticks>=89.125)&(ticks<=89.925)
            array=np.zeros((len(selected['k']),keep.sum(),len(fields)));seen=np.zeros(len(array),bool)
            for packet in np.unique(selected['block']):
                guard();row=groups[packet];a,b=int(row['first']),int(row['last']);ks=np.unique(np.r_[k[a:b+1],float(row['control']),float(row['hierarchy_cap'])])
                choose=selected['block']==packet;slot=np.searchsorted(ks,selected['k'][choose]);assert np.array_equal(ks[slot],selected['k'][choose])
                raw=bg.get_time_evolution(ks,ticks,vars=standard+[cap.Dummy(key) for key in cap.NAMES],lAccuracyBoost=4)
                array[choose]=raw[slot][:,keep][:,:,idx];seen[choose]=True
            assert seen.all() and np.isfinite(array).all()
            assert np.max(abs(array[:,:,fields.index('k')]/selected['k'][:,None]-1))<1e-12
            assert np.all(array[:,-1,fields.index('mts_match_count')]==1) and not np.any(array[:,:,fields.index('mts_nonheavy_change')])
            pack('native-'+str(rate)+'.npz',time=ticks[keep],fields=fields,k=selected['k'],values=array,rate=rate,method=sha(ROOT/'method.json'))
            print('Native capture completed:',rate,'per Mpc,',keep.sum(),'times',flush=True)
    freeze('native-samples.json',[ROOT/'method.json',ROOT/'readout.f90',spec,*[ROOT/f'native-{r}.npz' for r in (160,640,1280)]])
if __name__=='__main__':
    if sys.argv[1:2]==['--child']:
        with patch.object(cap.driver,'HERE',ROOT),patch.object(cap.driver,'NAMES',cap.NAMES),patch.object(cap.driver,'run',collect),patch.object(cap.driver,'save',lambda name,data:parent.save(ROOT/name,data)):cap.driver.main()
    else:
        check('method.json')
        with tempfile.TemporaryDirectory(dir=ROOT,prefix='reader-') as folder:subprocess.run([sys.executable,'-B','-u',__file__,'--child',folder,'heavy'],check=True)
