from audit_io import *
from scipy.integrate import solve_ivp
from scipy.interpolate import make_interp_spline
from functools import lru_cache

POP=BASE/'mts-matched-microscopic-population-90p4-20261126'
def pop(name):
    assert sha(POP/'seal.json')=='31c063ddda4781779017bbc4326af6b29083acc5aaeea6f683d840ad6c40a827'
    f=POP/name;assert sha(f)==json.loads((POP/'seal.json').read_bytes())['files'][name]
    return f

def modes_data(rate):
    ar=read(ROOT/f'native-{rate}.npz');sel=read(ROOT/'selected.npz')
    raw=dict(zip(ar['fields'],ar['values'].transpose(2,1,0)));t=ar['time'];k=ar['k'];ix=sel['idx'];sw=raw['mts_match_tau'][-1]
    assert np.array_equal(k,sel['k']) and np.array_equal(raw['tau'],np.broadcast_to(t[:,None],raw['tau'].shape))
    assert np.array_equal(raw['a_diag'],raw['a'])
    mask=t>sw.max();left=t<sw.min();assert (mask|left).all() and (raw['mts_match_count'][mask]==1).all() and not raw['mts_match_count'][left].any()
    prep=read(old.pin('preparation.npz'));mass=read(old.pin('matched-metric.npz'))['mass'].item()
    seed=np.stack([prep['density'][ix],prep['momentum'][ix]]);rho=prep['rho'].item()
    e,p,j=[raw[key]*raw['a_diag']/rho for key in ('mts_drho_h','mts_dp_h','mts_q_h')]
    a=raw['a'];H=raw['adotoa'];C=raw['clxc'];X=(raw['dgrho']/2+k*raw['etak'])/H
    ratio=(k/(a*mass))**2;c=ratio/(np.sqrt(1+ratio)+1)**2
    p_ev=c*(e+3*H*j/k)
    return locals()
def diagonal(spline,at):
    return spline(at)[np.arange(len(at)),np.arange(len(at))]
def run_rate(rate,degree):
    d=modes_data(rate);k=d['k'];t=d['t'];sw=d['sw'];mask=d['mask'];seed=d['seed'];m=d['mass'];pe=d['p_ev'];sel=d['sel'];idx=sel['idx']
    tc=read(last('prepared-predictions.npz'))['time'];targets=np.unique(np.r_[89.15,89.15625,89.275,89.6,tc]);pos=np.searchsorted(t,targets);assert np.array_equal(t[pos],targets)
    spl=lambda y:make_interp_spline(t[mask],y[mask],k=degree)
    geom=spl(np.stack([d[q] for q in ('a','H','C','X')],axis=2))
    c0=diagonal(spl(d['C']),sw)
    cold_before=diagonal(make_interp_spline(t[d['left']],d['C'][d['left']],k=min(3,d['left'].sum()-1)),sw)
    start=prev.native.switch();offset=start-sw
    g0=diagonal(geom,sw);a,h,C,X=g0.T;ratio=(k/(a*m))**2;P=ratio/(np.sqrt(1+ratio)+1)**2*(seed[0]+3*h*seed[1]/k)
    dp=-3*h*P-k*seed[1];jp=-h*seed[1]+k*P
    z0=np.stack([seed[0]+offset*(dp-X),seed[1]+offset*jp,seed[0]+offset*dp,seed[1]+offset*jp])
    def derivative(tm,state):
        a,h,C,X=geom(tm).T;q=(k/(a*m))**2;c=q/(np.sqrt(1+q)+1)**2
        e,j,u,v=state.reshape(4,-1);p=c*(e+3*h*j/k);p2=c*(u+(C-c0)+3*h*v/k)
        return np.stack([-3*h*p-k*j-X,-h*j+k*p,-3*h*p2-k*v,-h*v+k*p2]).ravel()
    ode=solve_ivp(derivative,(start,targets[-1]),z0.ravel(),t_eval=targets,method='DOP853',rtol=2e-13,atol=1e-17,max_step=1/320)
    assert ode.success
    traj=ode.y.T.reshape(len(targets),4,-1)
    measured=np.stack([d['e'][pos],d['j'][pos]],axis=1)
    work=traj[:,:2];tracer=traj[:,2:].copy();tracer[:,0]+=d['C'][pos]-c0
    rates=np.stack([-3*d['H']*pe,-k*d['j'],-d['X'],-d['H']*d['j'],k*pe],axis=2)
    anti=spl(rates).antiderivative()
    terms=anti(targets)-diagonal(anti,sw)
    work_cold=d['C'][pos]-c0
    de=measured[:,0]-seed[0];dj=measured[:,1]-seed[1]
    defects=np.stack([de-terms[:,:,:3].sum(2),de-terms[:,:,:2].sum(2)-work_cold,dj-terms[:,:,3:].sum(2),work_cold-terms[:,:,2]],axis=1)
    pack(f'balance-{rate}-{degree}.npz',k=k,idx=idx,time=targets,seed=seed,measured=measured,work=work,tracer=tracer,
         defects=defects,terms=terms,change_c=work_cold,extrapolation_in_c=c0-cold_before,
         switch_times=sw,relative_scale_spread=np.ptp(d['a'][pos],axis=1)/d['a'][pos,0],
         p_diagnostic_error=(d['p']-pe)[pos],H_diag_minus_H=(d['raw']['H_diag']-d['H'])[pos])
def run():
    check('native-samples.json')
    for rate in (160,640,1280):
        for deg in (3,5):run_rate(rate,deg)
    freeze('balance-receipt.json',[ROOT/'balance.py',ROOT/'native-samples.json',*[ROOT/f'balance-{rate}-{deg}.npz' for rate in (160,640,1280) for deg in (3,5)]])
if __name__=='__main__':run()
