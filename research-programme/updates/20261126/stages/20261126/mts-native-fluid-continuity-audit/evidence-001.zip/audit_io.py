from pathlib import Path
import json,hashlib,sys,csv
import numpy as np
ROOT=Path(__file__).resolve().parent
BASE=ROOT.parent
LAST=BASE/'mts-projected-wave-energy-current-20261126'
SIGN='43f47da8a9ff8e6be989ef8dda783631d96b100127cf855e039fcee84d5af8e7'
def sha(path):
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
assert sha(LAST/'seal.json')==SIGN
def last(name):
    path=LAST/name;assert sha(path)==json.loads((LAST/'seal.json').read_bytes())['files'][name];return path
last('project.py');sys.path.insert(0,str(LAST))
import project as old
assert Path(old.__file__).parent==LAST
prev=old.prev;parent=old.parent;cap=prev.native.cap
def guard():old.guard();assert not (ROOT/'STOP-REQUESTED').exists()
def pack(name,**data):guard();parent.pack(ROOT/name,**data)
def put(name,data):guard();parent.put(ROOT/name,data)
def freeze(name,paths):guard();parent.receipt(ROOT/name,paths)
def check(name):parent.check(ROOT/name)
def read(path):
    with np.load(path) as ar:return {key:ar[key] for key in ar.files}
def select():
    with last('retained-mode-ledger.csv').open() as f:rows=list(csv.DictReader(f))
    k=np.array([float(row['k_per_Mpc']) for row in rows]);rate=np.array([[float(row['retained_'+v+'_percent']) for v in ('energy','current')] for row in rows]);failed=np.flatnonzero(rate.max(axis=1)>.5)
    assert len(failed)==17 and len(k)==782
    unused=list(np.flatnonzero(rate.max(axis=1)<=.5));control=[]
    for ix in failed:
        nearest=min(unused,key=lambda jj:(abs(np.log(k[jj]/k[ix])),jj));unused.remove(nearest);control.append(nearest)
    idx=np.sort(np.r_[failed,control]);with_fail=np.isin(idx,failed);blocks=np.empty(len(idx),int)
    with cap.pin('capture-heavy.csv').open() as f:groups=list(csv.DictReader(f))
    for n,row in enumerate(groups):blocks[(idx>=int(row['first']))&(idx<=int(row['last']))]=n
    pack('selected.npz',k=k[idx],idx=idx,failed=with_fail,pair=np.c_[failed,control],block=blocks,
         norm=np.array([[float(rows[i][v+'_contrast_peak']) for v in ('energy','current')] for i in idx]).T,old_rates=rate[idx])
    freeze('method.json',[ROOT/'PROTOCOL.md',ROOT/'audit_io.py',ROOT/'native_read.py',ROOT/'selected.npz',last('retained-mode-ledger.csv'),last('prepared-predictions.json'),cap.pin('capture-heavy.csv'),BASE/'condensate-origin-20261003/native-heavy-matching-20261007/native/fortran/MTSTwoField.f90',BASE/'condensate-origin-20261003/native-heavy-matching-20261007/native/fortran/equations.f90',BASE/'condensate-origin-20261003/native-heavy-matching-20261007/native/fortran/camb_python.f90'])
    print('Frozen',len(failed),'exceptions and',len(control),'deterministic controls in',len(np.unique(blocks)),'blocks')
if __name__=='__main__':select()
