from balance import *
import io
EXT=BASE/'mts-matched-source-extension-90p4-20261126'
def ext(name):
    assert sha(EXT/'seal.json')=='73460c2005854579ad058d2b1713db78db57b1f2b17c472f620a56dd7e1b52a4'
    path=EXT/('native/'+name);assert sha(path)==json.loads((EXT/'seal.json').read_bytes())['files']['native/'+name];return path
def targets():
    prep=read(old.pin('preparation.npz'));tc=read(last('prepared-predictions.npz'))['time'];k=prep['k'];rho=prep['rho'].item();raw=[];scales=[];ks=[]
    for i in range(38):
        with np.load(ext(f'phase-audit-{i:02}.npz')) as ar:
            times=ar['t'] if 't' in ar else ar['eta'];pos=np.searchsorted(times,tc);assert np.array_equal(times[pos],tc);names=ar['keys'].tolist();ids=[names.index(s) for s in ('mts_drho_h','mts_q_h')]
            raw.append(ar['values'][:,pos][:,:,ids].transpose(1,2,0));ks.extend(ar['k']);nodes=ar['k']
        with np.load(ext(f'linear-heavy-{i:02}.npz')) as ar:
            assert np.array_equal(ar['k'],nodes);pos=np.searchsorted(ar['eta'],tc);assert np.array_equal(ar['eta'][pos],tc)
            scales.append(ar['values'][:,pos,ar['keys'].tolist().index('a')].T)
    assert np.array_equal(ks,k);raw=np.concatenate(raw,axis=2);scales=np.concatenate(scales,axis=1)
    with np.load(pop('matched.npz')) as ar:rep=ar['scale'][np.searchsorted(ar['time'],tc)]
    with np.load(pop('projection-comparison.npz')) as ar:legacy=ar['matched-native-fluid'][np.searchsorted(ar['matched-eta'],tc)][:,:,[0,2]].transpose(0,2,1)
    assert np.array_equal(raw*(rep/rho)[:,None,None],legacy)
    fluid=raw*(scales/rho)[:,None,:];wave=read(ROOT/'own-clock-wave-reference.npz')['wave'][:,:2];old_wave=read(last('native-inverse-target.npz'))['moments'][:,:2]
    return tc,k,legacy,fluid,old_wave,wave
def counts(v,target,norm=None):
    diff=v-target;den=np.max(abs(target),axis=0) if norm is None else norm;assert np.min(den)>0
    scores=100*np.max(abs(diff),axis=0)/den
    return scores,dict(global_peak_pct=(100*np.max(abs(diff),axis=(0,2))/np.max(den,axis=1)).tolist(),worst=scores.max(1).tolist(),
                        median=np.median(scores,axis=1).tolist(),over=(scores>.5).sum(1).tolist(),distinct=int(np.any(scores>.5,axis=0).sum()))
def run():
    check('clock-forecast.json');tc,k,legacy,fluid,old_wave,wave=targets();selected=read(ROOT/'selected.npz');s=selected['idx'];c=read(ROOT/'balance-160-5.npz')
    take=np.searchsorted(c['time'],tc)
    assert np.allclose(c['measured'][take],fluid[:,:,s],atol=1e-15,rtol=5e-16)
    old_target=legacy-old_wave;new_target=fluid-wave;oldnorm=np.max(abs(old_target),axis=0);newnorm=np.max(abs(new_target),axis=0)
    fc=read(last('prepared-predictions.npz'));legacy_fc=fc['fluid']-fc['retained'][:,:2]
    out={};mode={}
    for name in ('legacy','nominal-replay','clock-only','background-only','both','both-fine'):
        if name=='legacy':forecast=legacy_fc
        else:
            ar=read(ROOT/(name+'.npz'));assert np.array_equal(tc,ar['time']);forecast=ar['fluid']-ar['wave'][:,:2]
        row={};mode[name]={}
        for label,target,den in [('as_frozen',old_target,oldnorm),('own_scale_only',fluid-old_wave,oldnorm),('consistent_unchanged_denominator',new_target,oldnorm),('consistent',new_target,newnorm)]:
            mode[name][label],row[label]=counts(forecast,target,den)
        out[name]=row
    full=read(ROOT/'both.npz');fine=read(ROOT/'both-fine.npz')
    gap=full['fluid']-full['wave'][:,:2];err=gap-new_target
    parts={'fluid':full['fluid']-fluid,'wave':wave-full['wave'][:,:2]}
    details=dict(scale_error_on_old=(100*np.max(abs(fluid-legacy),axis=0)/oldnorm).max(1).tolist(),
         wave_reference_shift_on_old=(100*np.max(abs(wave-old_wave),axis=0)/oldnorm).max(1).tolist(),
         denominator_ratio_range=[(newnorm/oldnorm).min(1).tolist(),(newnorm/oldnorm).max(1).tolist()],
         correct_forecast_rk_refinement=counts(fine['fluid']-fine['wave'][:,:2],gap,oldnorm)[1],
         signed_on_remaining_error={key:(100*np.sum(value*err,axis=(0,2))/np.sum(err*err,axis=(0,2))).tolist() for key,value in parts.items()},
         selected_raw_replay_max_absolute=float(np.max(abs(c['measured'][take]-fluid[:,:,s]))))
    table=io.StringIO(newline='');writer=csv.writer(table,lineterminator='\n')
    methods=[('legacy','as_frozen'),('legacy','consistent'),('clock-only','consistent'),('background-only','consistent'),('both','consistent'),('both','consistent_unchanged_denominator')]
    writer.writerow(['k','old_energy_norm','old_current_norm','new_energy_norm','new_current_norm',*[a+'_'+b+'_'+v+'_pct' for a,b in methods for v in ('energy','current')]])
    for i,kk in enumerate(k):writer.writerow([kk,*oldnorm[:,i],*newnorm[:,i],*[p for method,label in methods for p in mode[method][label][:,i]]])
    parent.save(ROOT/'full-mode-ledger.csv',table.getvalue().encode())
    pack('corrected-reference.npz',k=k,time=tc,fluid=fluid,wave=wave,legacy_fluid=legacy,legacy_wave=old_wave,oldnorm=oldnorm,newnorm=newnorm)
    put('clock-scores.json',dict(comparisons=out,diagnostics=details))
    print('name | frozen / own clock+scale (old denom) / own denom ')
    for label,res in out.items():print(label,[(res[scope]['over'],[round(s,6) for s in res[scope]['global_peak_pct']]) for scope in ('as_frozen','consistent_unchanged_denominator','consistent')])
    print(details)
if __name__=='__main__':run()
