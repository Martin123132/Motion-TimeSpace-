import io
from repair_score import ext,counts
from clock_forecast import *
FIELDS=['grhonu_t','clxnu','dgq','grhov_t','qde','grhob_t','vb','grhog_t','qg','grhor_t','qr','gpres','a','adotoa','dgrho','etak','grhoc_t','clxc','clxb','clxg','clxr','mts_dphi_s','mts_dphidot_s','pig','pir','opacity','delta_p_b']
def load_native(tag,before=None):
    assert tag in ('matched','cold')
    segments=['early','late'] if tag=='matched' and (before is None or before>=89.55) else ['early'];chunks=[];tm=[];bgs=[]
    for segment in segments:
        def path(n):return ext(n) if segment=='late' else prev.native.pin(prev.bank,('matched-native/' if tag=='matched' else 'material-halfstep/')+n)
        label='heavy' if tag=='matched' else 'cold';parts=[];keys=[]
        for i in range(38):
            with np.load(path(f'linear-{label}-{i:02}.npz')) as ar:
                t=ar['eta'];choose=(t>=89.15)&(t<=90.45)
                if before is not None:choose&=t<=before
                if tag=='matched':choose&=(t<89.55) if segment=='early' else (t>=89.55)
                assert ar['good'][:,choose].all();ids=[ar['keys'].tolist().index(v) for v in FIELDS]
                parts.append(ar['values'][:,choose][:,:,ids].transpose(2,1,0));keys.extend(ar['k'])
        k=np.array(keys);tm.append(t[choose]);chunks.append(np.concatenate(parts,axis=2))
        with np.load(path(f'background-{label}.npz')) as ar:
            idx=np.searchsorted(ar['eta'],t[choose]);assert np.array_equal(ar['eta'][idx],t[choose])
            bgs.append(np.stack([ar['sphi'][idx],ar['sphidot'][idx]]));m=ar['smass'].item()
    time=np.concatenate(tm);assert np.allclose(np.diff(time),1/160,rtol=0,atol=2e-14)
    data=dict(zip(FIELDS,np.concatenate(chunks,axis=1)));b,v=np.concatenate(bgs,axis=1)[:,:,None]
    a=data['a'];H=data['adotoa'];X=(data['dgrho']/2+k*data['etak'])/H
    D=data['grhonu_t']*data['clxnu'];G=data['grhonu_t']
    J=data['dgq']-data['qde']*data['grhov_t']-data['grhob_t']*data['vb']-data['grhog_t']*data['qg']-data['grhor_t']*data['qr']
    pnu=data['gpres']-(data['grhog_t']+data['grhor_t'])/3-(v*v-(m*a*b)**2)/2
    B=G+pnu;slow=2*v*data['mts_dphidot_s']-(m*a)**2*b*data['mts_dphi_s']
    cb=(data['grhob_t']*data['clxb']+data['grhoc_t']*data['clxc'])/2
    rad=np.stack([data['grhog_t']*data['clxg'],data['grhor_t']*data['clxr']],axis=1)
    return SimpleNamespace(**locals())
from types import SimpleNamespace
def ratio(v,ref):
    den=np.max(abs(ref),axis=0);assert den.min()>0;err=100*np.max(abs(v-ref),axis=0)/den
    return dict(peak=100*np.max(abs(v-ref))/np.max(den),worst=err.max(),median=np.median(err),over=int((err>.5).sum()))
def run():
    check('nu-forecast.json');data=read(ROOT/'corrected-reference.npz');k=data['k'];tc=data['time'];truth=data['fluid']-data['wave'];summary={};rows={}
    d=load_native('matched');assert np.array_equal(k,d.k)
    sel=d.time>=89.275;ts=d.time[sel];A=lambda order:-(make_interp_spline(d.time,d.D,k=order)(ts,1)+k*d.J[sel]+d.B[sel]*d.X[sel])/(2*d.H[sel])
    An=A(7);known=read(ROOT/'both.npz');oldgap=known['fluid']-known['wave'][:,:2]
    for name in ('old-trace','energy-current','constant-shear','stencil7','energy-current-fine'):
        arr=read(ROOT/f'nu-{name}.npz');ar=arr['sectors'];ix=np.searchsorted(arr['t'],ts)
        assert np.array_equal(arr['t'][ix],ts)
        src={'A':(ar[ix,4],An),'D':(arr['D'][ix],d.D[sel]),'J':(arr['J'][ix],d.J[sel]),'X':(arr['X'][ix],d.X[sel])}
        metrics={key:dict(full=ratio(v,target),change=ratio(v-v[0],target-target[0])) for key,(v,target) in src.items()}
        gap=arr['fluid']-arr['wave'][:,:2]
        checks={key:{var:ratio(v[:,i],target[:,i]) for i,var in enumerate(('energy','current'))} for key,v,target in
                [('gap',gap,truth),('change',gap-gap[0],truth-truth[0])]}
        checks['old_denom']=counts(gap,truth,data['oldnorm'])[1]
        summary[name]=dict(sources=metrics,contrasts=checks)
        rows[name]=100*np.max(abs(gap-truth),axis=0)/data['newnorm']
    split=np.flatnonzero(np.max(rows['old-trace'],axis=0)>.5);assert len(split)==3
    first=read(ROOT/'nu-old-trace.npz')
    body=io.StringIO(newline='');writer=csv.writer(body,lineterminator='\n');writer.writerow(['k',*[name+'_'+v+'_pct' for name in rows for v in ('energy','current')]])
    for i,kk in enumerate(k):writer.writerow([kk,*[val for rr in rows.values() for val in rr[:,i]]])
    parent.save(ROOT/'source-repair-all-modes.csv',body.getvalue().encode())
    extras=dict(native_A_derivative_control=ratio(A(5),An),previous_exceptions=k[split].tolist(),
                current_before=rows['old-trace'][1,split].tolist(),current_after=rows['energy-current'][1,split].tolist(),
                old_forcing_replay=ratio(first['X'],read(ep('matched-ordinary-physical.npz'))['force']))
    put('neutrino-scores.json',dict(cases=summary,checks=extras))
    for case in ('old-trace','energy-current','constant-shear','stencil7'):
        row=summary[case];print(case,'A,J,X peak-error % of native change',[(s,round(row['sources'][s]['change']['peak'],5)) for s in ('A','J','X')],
              'current/energy drift',[(k,round(v['peak'],5),round(v['worst'],5),v['over']) for k,v in row['contrasts']['change'].items()])
    print('checks',extras)
if __name__=='__main__':
    run()
