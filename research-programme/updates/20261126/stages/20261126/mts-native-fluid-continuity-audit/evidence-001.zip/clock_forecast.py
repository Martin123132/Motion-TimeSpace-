from balance import *
from scipy.interpolate import CubicSpline

EARLY=BASE/'mts-causal-pressure-envelope-90p4-20261126'
def ep(name):
    assert sha(EARLY/'seal.json')=='06acf2fbc000333a93a049a2719a6d5c1b3ac074053daf3ae13f26dcd5b21758'
    p=EARLY/name;assert sha(p)==json.loads((EARLY/'seal.json').read_bytes())['files'][name]
    return p

def events(k):
    tau=[];modes=[];paths=[]
    for packet in range(38):
        path=prev.native.pin(prev.bank,f'matched-native/phase-audit-{packet:02}.npz');paths.append(path)
        with np.load(path) as ar:
            t=ar['t'];i=np.flatnonzero(t==89.15).item();q=ar['values'][:,i,:];keys=ar['keys'].tolist()
            assert np.all(q[:,keys.index('mts_match_count')]==1)
            tau.extend(q[:,keys.index('mts_match_tau')]);modes.extend(ar['k'])
    assert np.array_equal(k,modes);return np.array(tau),paths

def advance(metric,k,m,left,right,state,times,step):
    coupled=len(state)==6
    def rhs(t,flat):
        a,H,X=metric(t);b,v,f,w=flat.reshape(len(state),-1)[:4];m2=(m*a)**2
        out=[v,-2*H*v-m2*b,w,-2*H*w-(m2+k*k)*f-v*X]
        if coupled:
            e,j=flat.reshape(6,-1)[4:];rr=k*k/m2;c=rr/(np.sqrt(1+rr)+1)**2;P=c*(e+3*H*j/k)
            out.extend([-3*H*P-k*j-X,-H*j+k*P])
        return np.array(out).ravel()
    s=solve_ivp(rhs,(left,right),state.ravel(),t_eval=times,rtol=1e-12,atol=3e-17,max_step=step,method='DOP853')
    assert s.success;return s.y.T.reshape(len(times),len(state),len(k))
def prefix(data,window,cut,coeff,fluid,tau,k,m,step):
    y=np.zeros((6,len(k)));b,v=data['background'];before=window<prev.native.switch();after=~before
    for t0 in np.unique(tau):
        guard();mask=tau==t0;mu=m*data['metric'][0,0,mask];unit=np.ones(mask.sum())
        init=np.stack([b*unit,v*unit,coeff[mask,0],coeff[mask,1]*mu])
        inputs=data['metric'][:len(window),:3,mask]
        l=make_interp_spline(window[before],inputs[before],k=5);r=make_interp_spline(window[after],inputs[after],k=5)
        at=advance(l,k[mask],m,window[0],t0,init,[t0],step)[0]
        y[:,mask]=advance(r,k[mask],m,t0,cut,np.vstack([at,fluid[:,mask]]),[cut],step)[0]
    return y
def project_state(state,aa,t,tc,m,rho,k,clock):
    bg,v,f,w=state[:,:4].transpose(1,0,2);mm=(m*aa)**2
    moments=aa[:,None,:]/rho*np.stack([v*w+mm*bg*f,k*v*f,v*w-mm*bg*f],axis=1)
    result=[]
    for tm in tc:
        i=np.flatnonzero(t==tm).item();u=(clock-clock[i])/(6*np.pi);mask=abs(u)<1;ang=clock[mask];u=u[mask]
        design=np.column_stack([u**d for d in range(9)]+[u**d*trig(2*ang) for d in range(7) for trig in (np.cos,np.sin)]+[u**d*trig(4*ang) for d in range(3) for trig in (np.cos,np.sin)])
        result.append(np.einsum('t,tvk->vk',np.linalg.pinv(design)[0],moments[mask]))
    return np.array(result)

def run():
    guard();prep=read(old.pin('preparation.npz'));k=prep['k'];tau,paths=events(k);rho=prep['rho'].item();seed=np.stack([prep['density'],prep['momentum']])
    with np.load(ep('matched-early.npz')) as ar:cut=ar['cut'].item();a0=ar['scale'];H0=ar['hub'];p0=ar['ambient_gpress'];m=ar['mass'].item()
    with np.load(ep('matched-ordinary-physical.npz')) as ar:t=ar['time'];tc=ar['centers'];a=ar['scale'];H=ar['hub'];X=ar['force'];terminal=ar['ending'][7:9]
    with np.load(old.pin('matched-metric.npz')) as ar:
        keep=ar['time']<=cut;window=ar['time'][keep];data=dict(metric=ar['metric'][keep,:3],background=ar['background'])
    with np.load(last('prepared-predictions.npz')) as ar:base=ar['state_at_cut'][[0,1,4,5,6,7]]
    coeff=read(old.pin('native-map.npz'))['c']
    freeze('clock-method.json',[ROOT/'CLOCK-REPAIR.md',ROOT/'clock_forecast.py',ROOT/'method.json',last('prepared-predictions.npz'),old.pin('native-map.npz'),old.pin('matched-metric.npz'),old.pin('preparation.npz'),ep('matched-early.npz'),ep('matched-ordinary-physical.npz'),*paths])
    local=prefix(data,window,cut,coeff,seed,tau,k,m,1/640)
    nom=prefix(data,window,cut,coeff,seed,np.full_like(k,prev.native.switch()),k,m,1/640)
    def coefficients(dt):
        scale=1+H0*dt+(H0**2-p0)*dt**2/4
        return a0*scale,(H0+(H0**2-p0)*dt/2)/scale
    ah,hh=coefficients((t-cut)[:,None]);assert np.all(ah>0)
    bt=100*abs(np.stack([ah[-1],hh[-1]])-terminal)/abs(terminal)
    bs=(100*np.max(abs(ah[:,0]-a)/a),100*np.max(abs(hh[:,0]-H)/H))
    assert bt.max()<1e-8 and max(bs)<1e-8
    clock=CubicSpline(t,m*a).antiderivative()(t);force=make_interp_spline(t,X,k=5);aspl=make_interp_spline(t,a,k=5);hspl=make_interp_spline(t,H,k=5)
    files=[]
    for name,own,bi,step in [('nominal-replay',False,False,1/640),('clock-only',True,False,1/640),('background-only',False,True,1/640),('both',True,True,1/640),('both-fine',True,True,1/1280)]:
        def met(time):
            ac,hc=coefficients(time-cut) if bi else (aspl(time),hspl(time))
            return ac,hc,force(time)
        arr=advance(met,k,m,cut,t[-1],local if own else base,t,step)
        mean=project_state(arr,ah if bi else a[:,None],t,tc,m,rho,k,clock)
        file=ROOT/(name+'.npz');pack(file.name,k=k,time=tc,fluid=arr[np.searchsorted(t,tc),4:6],wave=mean,final=arr[-1])
        files.append(file)
    pack('clock-inputs.npz',k=k,event_time=tau,cut=cut,local_at_cut=local,nominal_at_cut=nom,old_at_cut=base,terminal_bg_relative_pct=bt,column_zero_pct=bs)
    freeze('clock-forecast.json',[ROOT/'clock-method.json',ROOT/'clock-inputs.npz',*files])
    print('Frozen from pre-cutoff and autonomy inputs; distinct crossing clocks',len(set(tau)),'terminal geometry max pct',bt.max())
if __name__=='__main__':run()
