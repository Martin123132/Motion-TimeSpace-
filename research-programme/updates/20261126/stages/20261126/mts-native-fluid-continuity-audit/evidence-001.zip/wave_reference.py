from pathlib import Path
from unittest.mock import patch
import hashlib,sys,json
import numpy as np
from scipy.interpolate import CubicSpline
HERE=Path(__file__).resolve().parent
OLD=HERE.parent/'mts-prepared-quadrature-inverse-90p4-20261126'
def digest(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
assert digest(OLD/'seal.json')=='8b191e3b559690de4266bdf4b2d3324f1d815f67a597d0935a27122413bb0c41'
for name in ('inverse_io.py','reconstruct.py','native-map.npz','matched-metric.npz','preparation.npz'):
    assert digest(OLD/name)==json.loads((OLD/'seal.json').read_bytes())['files'][name]
sys.path.insert(0,str(OLD))
import reconstruct as rec
def run():
    for key,value in json.loads((HERE/'clock-forecast.json').read_bytes()).items():assert digest(HERE.parent/key)==value
    assert not (HERE/'STOP-REQUESTED').exists();rec.guard()
    data=rec.unpack(OLD/'matched-metric.npz');coef=rec.unpack(OLD/'native-map.npz')['c'];prep=rec.unpack(OLD/'preparation.npz');rho=prep['rho'].item()
    with np.load(HERE/'clock-inputs.npz') as ar:tau=ar['event_time'];k=ar['k']
    with np.load(HERE/'both.npz') as ar:tc=ar['time']
    assert np.array_equal(k,data['k'])
    wave=np.zeros((len(rec.FINE),3,len(k)));metric_a=np.zeros((len(rec.FINE),len(k)))
    for at in np.unique(tau):
        keep=tau==at;small=dict(data,k=k[keep],metric=data['metric'][:,:,keep])
        with patch.object(rec,'SW',float(at)):
            arr,geo,nfev=rec.propagate(small,'matched',1/640,coef[keep])
        a=geo[:,0];m2=(a*data['mass'])**2;b,v,f,w=arr.transpose(1,0,2)
        wave[:,:,keep]=a[:,None,:]/rho*np.stack([v*w+m2*b*f,k[keep]*v*f,v*w-m2*b*f],axis=1)
        metric_a[:,keep]=a
    theta=CubicSpline(rec.FINE,data['mass']*metric_a[:,0]).antiderivative();ph=theta(rec.FINE)-theta(rec.LEFT);results=[]
    for tm in tc:
        i=np.flatnonzero(rec.FINE==tm).item();sel,weight=rec.weights(ph,ph[i],6,8,1)
        results.append(rec.projected(wave,sel,weight))
    from io import BytesIO
    buf=BytesIO();np.savez_compressed(buf,time=tc,k=k,wave=results);blob=buf.getvalue()
    file=HERE/'own-clock-wave-reference.npz'
    if file.exists():assert digest(file)==hashlib.sha256(blob).hexdigest()
    else:
        tmp=file.with_suffix('.partial')
        with tmp.open('xb') as stream:stream.write(blob)
        tmp.rename(file)
if __name__=='__main__':run()
