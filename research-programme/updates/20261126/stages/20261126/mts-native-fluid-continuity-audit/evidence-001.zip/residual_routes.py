from clock_forecast import *
def run():
    check('clock-forecast.json');data=read(ROOT/'corrected-reference.npz');k=data['k'];tc=data['time'];true=(data['fluid']-data['wave'])
    base=read(ROOT/'both.npz');basegap=base['fluid']-base['wave'][:,:2]
    scores=100*np.max(abs(basegap-true),axis=0)/data['newnorm'];fail=np.flatnonzero(scores.max(0)>.5);assert len(fail)==3
    avail=list(np.flatnonzero(scores.max(0)<=.5));controls=[]
    for ix in fail:
        pick=min(avail,key=lambda v:(abs(np.log(k[v]/k[ix])),v));controls.append(pick);avail.remove(pick)
    ix=np.sort(np.r_[fail,controls]);local=k[ix];initial=read(ROOT/'clock-inputs.npz')['local_at_cut'][:,ix]
    with np.load(ep('matched-early.npz')) as ar:a0=ar['scale'][ix];h0=ar['hub'][ix];p0=ar['ambient_gpress'][ix];m=ar['mass'].item();rho=ar['rho'].item();cut=ar['cut'].item()
    with np.load(ep('matched-ordinary-physical.npz')) as ar:t=ar['time'];phase_a=ar['scale'];force=make_interp_spline(t,ar['force'][:,ix],k=5)
    with np.load(old.pin('matched-metric.npz')) as ar:
        native=ar['time'];sel=native>prev.native.switch();original=ar['metric'][sel,:3,:]
        actual=make_interp_spline(native[sel],original[:,:,ix],k=5);phase_actual=make_interp_spline(native[sel],original[:,0,0],k=5)(t)
    ap=CubicSpline(t,m*phase_a).antiderivative()(t);at=CubicSpline(t,m*phase_actual).antiderivative()(t)
    outputs={}
    for bg,src in ((0,0),(0,1),(1,0),(1,1)):
        def geometry(tm):
            g=actual(tm)
            if bg:a,h=g[:2]
            else:
                dt=tm-cut;f=1+h0*dt+(h0**2-p0)*dt*dt/4;a=a0*f;h=(h0+(h0**2-p0)*dt/2)/f
            return a,h,g[2] if src else force(tm)
        hist=advance(geometry,local,m,cut,t[-1],initial,t,1/1280)
        aa=np.stack([geometry(tm)[0] for tm in t]);fluid=hist[np.searchsorted(t,tc),4:6]
        for label,ph in [('a',ap),('t',at)]:
            w=project_state(hist,aa,t,tc,m,rho,local,ph);outputs[f'r{bg}{src}'+label]=fluid-w[:,:2]
    tr=true[:,:,ix];norm=data['newnorm'][:,ix];expected=outputs['r00a'];rem=outputs['r11t']-tr
    effects={'homogeneous':expected-outputs['r10a'],'perturbative':expected-outputs['r01a'],
             'cross':outputs['r10a']+outputs['r01a']-expected-outputs['r11a'],
             'projector':outputs['r11a']-outputs['r11t'],'unexplained':rem}
    error=expected-tr;assert np.max(abs(sum(effects.values())-error))<1e-14
    real=basegap[:,:,ix]-tr
    sizes={name:(100*np.max(abs(value),axis=0)/norm).tolist() for name,value in effects.items()}
    shares={name:(100*np.sum(value[:,1]*real[:,1],axis=0)/np.sum(real[:,1]**2,axis=0)).tolist() for name,value in effects.items()}
    pack('residual-routes.npz',k=local,idx=ix,failed=np.isin(ix,fail),true=tr,**outputs)
    put('residual-routes.json',dict(components_on_contrast_pct=sizes,signed_current_error_shares=shares,k=local.tolist(),failed=np.isin(ix,fail).tolist(),
         primary_replay_on_contrast_pct=(100*np.max(abs(expected-basegap[:,:,ix]),axis=0)/norm).tolist()))
    for i in np.flatnonzero(np.isin(ix,fail)):print(local[i],{key:round(row[i],3) for key,row in shares.items()},{key:round(row[1][i],4) for key,row in sizes.items()})
if __name__=='__main__':run()
