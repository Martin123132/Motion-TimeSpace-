from inputs import *
from forecast import CENTERS
from score_envelope import rows_at
import csv,io

def main():
    guard()
    for label in ('method','inputs','resume-method','predictions','ordinary-method','ordinary-forecast'):check(label+'.json')
    saved=json.loads((ROOT/'scores.json').read_bytes());improved=json.loads((ROOT/'ordinary-scores.json').read_bytes())
    old=unpack(pin('clock-predictions.npz'));coeff=unpack(pin('pressure-work.npz'));native=unpack(pin('projection-comparison.npz'))
    ledger=io.StringIO(newline='');writer=csv.writer(ledger,lineterminator='\n');writer.writerow(['k_Mpc_inverse','old_matched_pressure_fail','resolved_early_pressure_error_pct','matched_early_pressure_error_pct','resolved_early_correction_error_pct','matched_early_correction_error_pct','matched_minus_resolved_correction_error_pct','matched_native_plus_correction_pressure_error_pct'])
    targets={};forecasts={};p_err={};c_err={}
    for tag in ('wave','matched'):
        first=unpack(ROOT/(tag+'-metric.npz'));early=unpack(ROOT/(tag+'-ordinary-physical.npz'));fine=unpack(ROOT/(tag+'-ordinary-fine.npz'))
        assert float(first['launch'])==START and early['time'][0]==CUT and early['time'][-1]==90.45
        assert len(first['centers'])==30 and len(early['centers'])==11 and min(early['window_edges'][:,0])>CUT
        assert np.array_equal(early['centers'],fine['centers']) and fine['evaluations']>early['evaluations']
        for key in ('mom','correction','force','ending'):assert np.isfinite(early[key]).all()
        assert early['ending'].shape==(19,782) and first['ending'].shape==(7,782)
        assert first['invariant']<1e-8
        k=early['k'];indices=rows_at(CENTERS,early['centers'])
        target=old[tag+'-own-core'];den,pres,jay=target.transpose(2,0,1)
        targets[tag]=(pres-coeff[tag+'-sound']*(den+coeff[tag+'-rest']*jay))[indices];forecasts[tag]=early['correction']
        def percent(diff,ref):
            scale=np.max(abs(ref),axis=0);assert np.all(scale>0);return 100*np.max(abs(diff),axis=0)/scale
        p_err[tag]=percent(early['mom'][:,2]-pres[indices],pres[indices]);c_err[tag]=percent(forecasts[tag]-targets[tag],targets[tag])
        row=improved[tag+'-physical']
        for error,item in ((p_err[tag],'own_pressure'),(c_err[tag],'excess')):
            assert int(sum(error>.5))==row[item]['fails'] and np.isclose(max(error),row[item]['max_pct'])
        assert row['metric_driver']['max_pct']<.5 and row['half_step_excess']['max_pct']<.5
        assert saved[tag+'-metric']['correction']['max_pct']<.5 and saved[tag+'-metric']['pressure']['max_pct']<.5
        assert saved[tag+'-early']['correction']['fails']>row['excess']['fails']
    delta=targets['matched']-targets['wave'];diff=percent(forecasts['matched']-forecasts['wave']-delta,delta)
    assert sum(diff>.5)==improved['contrast-physical']['fails']
    fp=native['matched-native-fluid'][:,:,1];p=old['matched-own-core'][:,:,1]
    mask=percent(p-fp,fp)>.5;assert sum(mask)==43 and max(c_err['matched'][mask])<.5
    corrected=percent(fp[indices]+forecasts['matched']-p[indices],p[indices]);assert max(corrected)<.5
    for i,kval in enumerate(k):writer.writerow([kval,bool(mask[i]),p_err['wave'][i],p_err['matched'][i],c_err['wave'][i],c_err['matched'][i],diff[i],corrected[i]])
    save('early-pressure-ledger.csv',ledger.getvalue().encode())
    assert not any(f.name.endswith('.partial') or f.is_dir() for f in ROOT.iterdir())
    if (ROOT/'seal.json').exists():
        rec=json.loads((ROOT/'seal.json').read_bytes());assert rec['parent']==PARENT and set(rec['files'])=={p.name for p in ROOT.iterdir() if p.name!='seal.json'}
        for name,sig in rec['files'].items():assert sig==sha(ROOT/name)
    elif '--seal' in sys.argv:
        assert (ROOT/'RESULTS.md').is_file()
        put('seal.json',dict(parent=PARENT,files={p.name:sha(p) for p in sorted(ROOT.iterdir()) if p.name!='seal.json'}))
    print('Verified 782 modes, 30 conditional and 11 fully future centered windows per branch, paired forecast and refinement; actual early pressure failures:',sum(p_err['wave']>.5),sum(p_err['matched']>.5))
    if (ROOT/'seal.json').is_file():print(sha(ROOT/'seal.json'))
if __name__=='__main__':main()
