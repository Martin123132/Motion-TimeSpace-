from inputs import ROOT,START,CUT,guard,check,freeze,unpack,pack
import sys
import numpy as np
from scipy.integrate import solve_ivp
from scipy.interpolate import make_interp_spline,CubicSpline
END=90.45
CENTERS=np.arange(round(89.70625*160),round(89.89375*160)+1)/160

def product_rhs(values,mu,hub,force,k):
    energy,bgpress,cross,density,current,pressure,mixed=values[:7]
    bulk=-k*current-(energy+bgpress)*force
    small=k*k/(4*mu**2)
    return [-3*hub*bgpress,-3*hub*energy-2*mu*cross,2*mu*bgpress,-3*hub*pressure+bulk,
        -hub*current+k*pressure,-3*hub*density-2*mu*mixed+bulk,2*mu*(pressure+small*(pressure-density))-cross*force]

def project(t,scale,hub,states,mass,k,launch):
    phase=CubicSpline(t,mass*scale[:,0]).antiderivative()(t)
    result=[];used=[];closure=[];mnorm=[];allwindows=[]
    for time in CENTERS:
        center=np.flatnonzero(t==time).item();phasec=phase[center];width=6*np.pi
        if phasec-width<=phase[0] or phasec+width>=phase[-1]:continue
        select=abs(phase-phasec)<width;angle=phase[select];u=(angle-phasec)/width
        design=np.column_stack([u**p for p in range(9)]+[u**p*trig(2*angle) for p in range(7) for trig in (np.cos,np.sin)]+[u**p*trig(4*angle) for p in range(3) for trig in (np.cos,np.sin)])
        weight=np.linalg.pinv(design)[0];assert np.linalg.matrix_rank(design)==design.shape[1] and min(t[select])>=launch
        moments=np.einsum('t,tsk->sk',weight,states[select,3:7,:])
        den,jay,pres,_=moments
        ratio=(k/(mass*scale[center]))**2;sound=ratio/(np.sqrt(1+ratio)+1)**2
        closure.append(pres-sound*(den+3*hub[center]*jay/k))
        avg_h=weight@hub[select]
        mnorm.append(np.maximum.reduce([abs(den),abs(k*jay/avg_h)/np.maximum(1,k*np.sqrt(sound)/avg_h),np.full(len(k),1e-6)]))
        used.append(time);result.append(moments);allwindows.append(t[select][[0,-1]])
    return dict(centers=np.asarray(used),window_edges=np.asarray(allwindows),mom=np.asarray(result),
        correction=np.asarray(closure),mode_norm=np.asarray(mnorm))

def run(tag,kind,stepsize,label,detail):
    cond=kind=='metric'
    data=unpack(ROOT/(tag+('-driver.npz' if cond else '-early.npz')))
    grid=data['grid'];n=len(grid);mass=float(data['mass']);rho=float(data['rho'])
    launch=START if cond else CUT
    t=np.arange(round(launch*320),round(END*320)+1)/320
    if cond:
        metrics=make_interp_spline(data['time'],np.stack([data['scale'],data['hub'],data['force']],axis=1),k=5)
        start=data['seed']
        def rhs(time,state):
            scale,hub,force=metrics(time)
            return np.asarray(product_rhs(state.reshape(-1,n),mass*scale,hub,force,grid)).ravel()
    else:
        assert float(data['cut'])==CUT
        scale0=data['scale']
        start=np.vstack((data['seed'],scale0,data['hub'],data['force'],data['fluid']))
        degree=7 if kind=='stencil7' else 5
        external=data['external'+str(degree)]
        slope=data['slope'+str(degree)] if kind!='constant' else 0
        def rhs(time,state):
            current=state.reshape(-1,n)
            scale,hub,force,fluid_den,fluid_j=current[7:]
            mu=mass*scale;inside=product_rhs(current,mu,hub,force,grid)
            if tag=='matched':
                ratio=(grid/mu)**2;cs=ratio/(np.sqrt(1+ratio)+1)**2
                fp=cs*(fluid_den+3*hub*fluid_j/grid)
                heavy=(rho/scale)*(fluid_den+3*fp)/2;bgp=0.
                dr=-3*hub*fp-grid*fluid_j-force;jr=-hub*fluid_j+grid*fp
            else:
                heavy=(rho/scale)*(current[3]+3*current[5])/2;bgp=rho/scale*current[1]
                dr=np.zeros(n);jr=dr
            ambient_p=data['ambient_gpress']*(scale0/scale)**2
            return np.asarray(inside+[hub*scale,-(hub**2+ambient_p+bgp)/2,-hub*force-heavy-external-(time-CUT)*slope,dr,jr]).ravel()
    sol=solve_ivp(rhs,(launch,END),start.ravel(),t_eval=t,method='DOP853',atol=5e-17,rtol=1e-12,max_step=stepsize)
    assert sol.success and np.array_equal(sol.t,t) and np.isfinite(sol.y).all()
    states=sol.y.T.reshape(len(t),-1,n)
    if cond:scale,hub,force=metrics(t).transpose(1,0,2)
    else:scale,hub,force=states[:,7:10].transpose(1,0,2)
    out=project(t,scale,hub,states,mass,grid,launch)
    nrm=np.max(states[:,0]**2,axis=0)
    invariant=np.max(abs(states[:,0]**2-states[:,1]**2-states[:,2]**2)/nrm)
    if detail:
        out.update(raw_p=states[:,5],raw_mixed=states[:,6],scale=scale[:,0],hub=hub[:,0],force=force)
    pack(tag+'-'+label+'.npz',time=t,k=grid,launch=launch,ending=states[-1],native_steps=sol.nfev,invariant=invariant,**out)
    print(tag,label,len(out['centers']),sol.nfev,flush=True)

def main():
    guard();check('inputs.json');names=[]
    for tag in ('wave','matched'):
        for kind,label,step,detail in [('metric','metric',1/160,True),('metric','metric-fine',1/320,False),
            ('tangent','early',1/160,True),('tangent','early-fine',1/320,False),('constant','constant',1/160,False),('stencil7','stencil7',1/160,False)]:
            guard();run(tag,kind,step,label,detail);names.append(tag+'-'+label+'.npz')
    freeze('predictions.json',['inputs.json']+names)
if __name__=='__main__':main()
