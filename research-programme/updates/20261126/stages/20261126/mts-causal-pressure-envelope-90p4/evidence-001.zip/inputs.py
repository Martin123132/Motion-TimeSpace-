from pathlib import Path
from functools import lru_cache
from io import BytesIO
import json,hashlib,sys
import numpy as np
from scipy.interpolate import make_interp_spline

ROOT=Path(__file__).resolve().parent
PRE=ROOT.parent/'mts-matched-microscopic-population-90p4-20261126'
PARENT='31c063ddda4781779017bbc4326af6b29083acc5aaeea6f683d840ad6c40a827'
START=89.15
CUT=89.275
def sha(path):
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
assert sha(PRE/'seal.json')==PARENT
pre_files=json.loads((PRE/'seal.json').read_bytes())['files']
@lru_cache()
def pin(name):
    path=PRE/name;assert sha(path)==pre_files[name],name
    return path
pin('state_io.py');sys.path.insert(0,str(PRE));import state_io as pre
def guard():
    pre.guard();assert not (ROOT/'STOP-REQUESTED').exists()
def save(name,raw):
    guard();path=ROOT/name
    if path.exists():assert sha(path)==hashlib.sha256(raw).hexdigest(),name
    else:
        tmp=path.with_suffix(path.suffix+'.partial')
        with tmp.open('xb') as stream:stream.write(raw)
        tmp.rename(path)
def put(name,obj):save(name,(json.dumps(obj,default=lambda v:v.item(),sort_keys=True,indent=2,allow_nan=False)+'\n').encode())
def pack(name,**arrays):
    stream=BytesIO();np.savez_compressed(stream,**arrays);save(name,stream.getvalue())
def freeze(name,files):put(name,{f:sha(ROOT/f) for f in files})
def check(name):
    for file,sig in json.loads((ROOT/name).read_bytes()).items():assert sha(ROOT/file)==sig
def unpack(path):
    with np.load(path) as archive:return {key:archive[key] for key in archive.files}

def products(state,scale,grid,mass,rho):
    bg,vel,field,rate=state.transpose(1,0,2);mu=scale*mass;factor=scale/rho
    return np.stack([factor*(vel**2+(mu*bg)**2)/2,factor*(vel**2-(mu*bg)**2)/2,factor*mu*bg*vel,
        factor*(vel*rate+mu**2*bg*field),factor*grid*vel*field,factor*(vel*rate-mu**2*bg*field),factor*mu*(vel*field+bg*rate)],axis=1)

def left_derivative(time,values,degree,order=1):
    return make_interp_spline(time[-degree-1:],values[-degree-1:],k=degree,axis=0)(time[-1],order)

def build(tag,rho):
    metrics=[];fluid=[];nodes=[]
    for idx in range(38):
        name=f'linear-heavy-{idx:02}.npz'
        def read(ar,mask):
            cols=[ar['keys'].tolist().index(key) for key in ('a','adotoa','gpres','dgrho','etak')]
            assert np.all(ar['good'][:,mask]);return ar['values'][:,mask,:][:,:,cols].transpose(1,0,2)
        out,_=pre.joined(tag,name,read);metrics.append(out)
        with np.load(pre.raw(tag,False,name)) as ar:nodes.extend(ar['k'])
        if tag=='matched':
            with np.load(pre.raw(tag,False,f'phase-audit-{idx:02}.npz')) as ar:
                assert np.array_equal(ar['k'],nodes[-len(ar['k']):])
                cols=[ar['keys'].tolist().index(key) for key in ('mts_drho_h','mts_dp_h','mts_q_h')]
                take=(ar['t']>=START)&(ar['t']<=CUT)
                assert np.array_equal(ar['t'][take],pre.NATIVE[(pre.NATIVE>=START)&(pre.NATIVE<=CUT)])
                fluid.append(ar['values'][:,take,:][:,:,cols].transpose(1,0,2))
    grid=np.array(nodes);raw=np.concatenate(metrics,axis=1)
    take=pre.NATIVE>=START;times=pre.NATIVE[take]
    scale,hub,gpress,density,eta=raw[take].transpose(2,0,1)
    force=(density/2+grid*eta)/hub
    early=times<=CUT;near=times[early];sel=(pre.FINE>=START)&(pre.FINE<=CUT)&np.isin(pre.FINE,near)
    with np.load(pin(tag+'.npz')) as ar:
        assert np.array_equal(ar['grid'],grid);mass=ar['mass'].item()
        history=ar['state'][sel];assert len(history)==len(near)
    moments=products(history,scale[early],grid,mass,rho)
    geometry=rho/scale[early]
    if fluid:
        direct=np.concatenate(fluid,axis=1)
        heavy_drive=(direct[:,:,0]+3*direct[:,:,1])/2
        bg_pressure=np.zeros_like(heavy_drive)
        seed_fluid=direct[-1,:,[0,2]]/geometry[-1]
    else:
        heavy_drive=geometry*(moments[:,3]+3*moments[:,5])/2
        bg_pressure=geometry*moments[:,1]
        seed_fluid=np.zeros((2,len(grid)))
    assert seed_fluid.shape==(2,len(grid))
    xx=force[early];hh=hub[early];direct_slope={}
    for degree in (5,7):
        dx=left_derivative(near,xx,degree);ddx=left_derivative(near,xx,degree,2)
        dh=left_derivative(near,hh,degree)
        ext=-dx-hh[-1]*xx[-1]-heavy_drive[-1]
        extdot=-ddx-dh*xx[-1]-hh[-1]*dx-left_derivative(near,heavy_drive,degree)
        direct_slope['external'+str(degree)]=ext;direct_slope['slope'+str(degree)]=extdot
    pack(tag+'-early.npz',cut=CUT,grid=grid,rho=rho,mass=mass,seed=moments[-1],
        scale=scale[early][-1],hub=hh[-1],force=xx[-1],ambient_gpress=gpress[early][-1]-bg_pressure[-1],
        fluid=seed_fluid,**direct_slope)
    pack(tag+'-driver.npz',time=times,scale=scale,hub=hub,force=force,seed=moments[0],mass=mass,grid=grid,rho=rho)

if __name__=='__main__':
    freeze('method.json',['PROTOCOL.md','inputs.py','forecast.py','score_envelope.py'])
    with np.load(pre.oldio.pin(pre.oldio.SOURCE,'exact-phase-extension.npz')) as ar:rho=ar['matching_density'].item()
    for tag in ('wave','matched'):build(tag,rho)
    freeze('inputs.json',['method.json']+[tag+suffix for tag in ('wave','matched') for suffix in ('-early.npz','-driver.npz')])
