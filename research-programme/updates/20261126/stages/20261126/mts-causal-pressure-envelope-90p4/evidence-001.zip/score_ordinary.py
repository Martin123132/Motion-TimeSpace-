from inputs import *
from forecast import CENTERS
from score_envelope import rows_at,summarize
from scipy.interpolate import CubicSpline

def main():
    check('ordinary-forecast.json')
    old=unpack(pin('clock-predictions.npz'));work=unpack(pin('pressure-work.npz'));native=unpack(pin('projection-comparison.npz'))
    scores={};gaps={};stock={}
    for tag in ('wave','matched'):
        driver=unpack(ROOT/(tag+'-driver.npz'));kin=unpack(ROOT/(tag+'-early.npz'));orddata=unpack(ROOT/(tag+'-ordinary-input.npz'));k=kin['grid']
        truth=old[tag+'-own-core'];den,pres,jay=truth.transpose(2,0,1)
        desired=pres-work[tag+'-sound']*(den+work[tag+'-rest']*jay)
        gaps[tag]=desired
        with np.load(pin(tag+'.npz')) as ar:
            time=ar['time'];scale=ar['scale'];clock=CubicSpline(time,ar['mass']*scale).antiderivative()(time)
        for variant in ('physical','constant','stencil7','massless','fine'):
            obj=unpack(ROOT/(tag+'-ordinary-'+variant+'.npz'))
            idx=rows_at(time,obj['centers']);select=(clock[idx]-6*np.pi>np.interp(CUT,time,clock))&(clock[idx]+6*np.pi<clock[-1])
            centers=obj['centers'][select];sel=rows_at(CENTERS,centers);target=desired[sel];corr=obj['correction'][select]
            stock[tag+'-'+variant]=(centers,corr);mom=obj['mom'][select];assert len(centers)>0
            row=dict(centers=len(centers),window=centers[[0,-1]].tolist(),own_pressure=summarize(mom[:,2],pres[sel],k),excess=summarize(corr,target,k),
                density=summarize(mom[:,0],den[sel],k),current=summarize(mom[:,1],jay[sel],k),
                max_norm_pressure=np.max(abs(corr)/obj['mode_norm'][select]))
            if 'force' in obj:
                inds=rows_at(driver['time'],obj['time'][::2]);row['metric_driver']=summarize(obj['force'][::2],driver['force'][inds],k)
            if tag=='matched':
                fp=native['matched-native-fluid'][:,:,1]
                mask=100*np.max(abs(fp-pres),axis=0)/np.max(abs(fp),axis=0)>.5
                row['corrected_fluid']=summarize(fp[sel]+corr,pres[sel],k)
                row['orig43']=summarize(corr[:,mask],target[:,mask],k[mask])
            scores[tag+'-'+variant]=row
        scores[tag+'-source-difference']={key:100*np.linalg.norm(orddata[direct]-kin[method])/np.linalg.norm(orddata[direct])
            for key,direct,method in [('value_pct_of_direct','explicit_source5','external5'),('slope_pct_of_direct','explicit_tangent5','slope5')]}
        ca,aa=stock[tag+'-physical'];cb,ab=stock[tag+'-fine'];assert np.array_equal(ca,cb)
        scores[tag+'-physical']['half_step_excess']=summarize(aa,ab,k)
    for variant in ('physical','constant','stencil7','massless'):
        tw,aw=stock['wave-'+variant];tm,am=stock['matched-'+variant];common=np.intersect1d(tw,tm);sel=rows_at(CENTERS,common)
        scores['contrast-'+variant]=summarize(am[rows_at(tm,common)]-aw[rows_at(tw,common)],gaps['matched'][sel]-gaps['wave'][sel],k)
    put('ordinary-scores.json',scores)
    for tag in ('wave','matched'):
        for variant in ('physical','constant','stencil7','massless'):
            row=scores[tag+'-'+variant]
            print(tag,variant,'pressure',row['own_pressure']['max_pct'],row['own_pressure']['fails'],'excess',row['excess']['rms_pct'],row['excess']['fails'],flush=True)
if __name__=='__main__':main()
