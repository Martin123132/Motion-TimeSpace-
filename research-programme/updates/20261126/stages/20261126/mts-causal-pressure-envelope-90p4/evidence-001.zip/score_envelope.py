from inputs import *
from scipy.interpolate import CubicSpline,make_interp_spline
from forecast import CENTERS

def summarize(val,target,k):
    diff=val-target;peak=np.max(abs(target),axis=0)
    valid=peak>0;assert np.any(valid)
    rel=np.zeros_like(peak);rel[valid]=100*np.max(abs(diff[:,valid]),axis=0)/peak[valid]
    return dict(max_pct=rel[valid].max(),median_pct=np.median(rel[valid]),p95_pct=np.percentile(rel[valid],95),
        rms_pct=100*np.linalg.norm(diff)/np.linalg.norm(target),fails=int(sum(rel[valid]>.5)),undefined=int(sum(~valid)),worst_k=k[valid][np.argmax(rel[valid])],max_abs=np.max(abs(diff)))
def rows_at(master,query):
    loc=np.searchsorted(master,query);assert np.array_equal(master[loc],query);return loc

def main():
    check('predictions.json')
    old=unpack(pin('clock-predictions.npz'));work=unpack(pin('pressure-work.npz'));native=unpack(pin('projection-comparison.npz'))
    assert np.array_equal(old['eta'],CENTERS)
    with np.load(pre.oldio.pin(pre.oldio.SOURCE,'exact-phase-extension.npz')) as ar:rho=ar['matching_density'].item()
    scores={};arrays={};actual_by_tag={}
    for tag in ('wave','matched'):
        with np.load(pin(tag+'.npz')) as ar:
            time=ar['time'];scale=ar['scale'];hub=ar['hub'];grid=ar['grid'];mass=ar['mass'].item()
            rawp=ar['stress'][:,:,1]*scale[:,None]/rho
            bg,vel,field,rate=ar['state'].transpose(1,0,2)
            mixed=mass*scale[:,None]**2/rho*(vel*field+bg*rate)
        clock_phase=CubicSpline(time,mass*scale).antiderivative()(time)
        full=old[tag+'-own-core'];den,pres,jay=full.transpose(2,0,1)
        shift=work[tag+'-sound']*(den+work[tag+'-rest']*jay)
        desired=pres-shift
        driver=unpack(ROOT/(tag+'-driver.npz'))
        for name in ('metric','metric-fine','early','early-fine','constant','stencil7'):
            fc=unpack(ROOT/(tag+'-'+name+'.npz'));k=fc['k'];assert np.array_equal(k,grid)
            centers=fc['centers'];ind=rows_at(time,centers);launch=fc['launch'].item()
            mask=(clock_phase[ind]-6*np.pi>np.interp(launch,time,clock_phase))&(clock_phase[ind]+6*np.pi<clock_phase[-1])
            assert np.any(mask);ind=ind[mask];centers=centers[mask];indices=rows_at(CENTERS,centers)
            got=fc['mom'][mask];excess=fc['correction'][mask];true=desired[indices]
            assert np.min(fc['window_edges'][mask])>=launch
            vals=dict(centers=len(indices),window=[centers[0],centers[-1]],earliest_target_sample=time[np.searchsorted(clock_phase,clock_phase[ind[0]]-6*np.pi)],
                density=summarize(got[:,0],den[indices],k),momentum=summarize(got[:,1],jay[indices],k),pressure=summarize(got[:,2],pres[indices],k),
                correction=summarize(excess,true,k),homogeneous_invariant=fc['invariant'].item(),max_closure_norm=np.max(abs(excess)/fc['mode_norm'][mask]))
            if tag=='matched':
                fluid=native['matched-native-fluid'][:,:,1];orig=summarize(fluid[indices],pres[indices],k)
                fixed=fluid[indices]+excess
                vals.update(old_fluid_on_micro_pressure=orig,corrected_fluid_on_micro_pressure=summarize(fixed,pres[indices],k),
                    corrected_error_on_original_fluid_scale=summarize(fixed-pres[indices]+fluid[indices],fluid[indices],k))
                old43=100*np.max(abs(pres-fluid),axis=0)/np.max(abs(fluid),axis=0)>.5
                assert sum(old43)==43
                vals['old43_correction']=summarize(excess[:,old43],true[:,old43],k[old43])
            if 'force' in fc:
                ix=rows_at(time,fc['time'])
                native_ix=rows_at(driver['time'],fc['time'][::2])
                vals.update(raw_pressure=summarize(fc['raw_p'],rawp[ix],k),mixed=summarize(fc['raw_mixed'],mixed[ix],k),
                    force=summarize(fc['force'][::2],driver['force'][native_ix],k),
                    scale_pct=100*np.max(abs(fc['scale']/scale[ix]-1)),H_pct=100*np.max(abs(fc['hub']/hub[ix]-1)))
            key=tag+'-'+name;scores[key]=vals;arrays[key]=(centers,excess,got)
            if tag not in actual_by_tag:actual_by_tag[tag]=desired
        for kind in ('metric','early'):
            ca,aa,ma=arrays[tag+'-'+kind];cb,ab,mb=arrays[tag+'-'+kind+'-fine'];assert np.array_equal(ca,cb)
            scores[tag+'-'+kind]['half_step_correction']=summarize(aa,ab,grid)
    for kind in ('metric','early','constant','stencil7'):
        tw,aw,_=arrays['wave-'+kind];tm,am,_=arrays['matched-'+kind];common=np.intersect1d(tw,tm)
        li=rows_at(CENTERS,common)
        scores['contrast-'+kind]=summarize(am[rows_at(tm,common)]-aw[rows_at(tw,common)],actual_by_tag['matched'][li]-actual_by_tag['wave'][li],grid)
    put('scores.json',scores)
    for tag in ('wave','matched'):
        for name in ('metric','early','constant','stencil7'):
            row=scores[tag+'-'+name]
            print(tag,name,row['centers'],'pressure',row['pressure']['max_pct'],row['pressure']['fails'],'excess',row['correction']['rms_pct'],row['correction']['fails'],flush=True)
if __name__=='__main__':main()
