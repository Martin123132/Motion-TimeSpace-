from inputs import *
from forecast import product_rhs,project,END
from scipy.integrate import solve_ivp

FIELDS=['clxc','clxb','vb','clxg','qg','clxr','qr','pig','pir','opacity','delta_p_b','grhoc_t','grhob_t','grhog_t','grhor_t','grhonu_t','clxnu','dgq','qde','grhov_t','gpres','mts_dphi_s','mts_dphidot_s','a','adotoa','dgrho','etak']
def source(tag):
    early=unpack(ROOT/(tag+'-early.npz'));grid=early['grid'];columns=[]
    for idx in range(38):
        with np.load(pre.raw(tag,False,f'linear-heavy-{idx:02}.npz')) as ar:
            take=(ar['eta']>=START)&(ar['eta']<=CUT);t=ar['eta'][take]
            cols=[ar['keys'].tolist().index(key) for key in FIELDS]
            columns.append(ar['values'][:,take,:][:,:,cols].transpose(2,1,0))
    data=dict(zip(FIELDS,np.concatenate(columns,axis=2)));last=lambda key:data[key][-1]
    with np.load(pre.raw(tag,False,'background-heavy.npz')) as bg:
        select=np.isin(bg['eta'],t);assert np.array_equal(bg['eta'][select],t)
        sv=bg['sphidot'][select,None];sb=bg['sphi'][select,None];sm=(data['a']*bg['smass'].item())**2
        heavy_p=0 if tag=='matched' else (bg['hphidot'][select,None]**2-(bg['hmass']*data['a']*bg['hphi'][select,None])**2)/2
    gpnu=data['gpres']-(data['grhog_t']+data['grhor_t'])/3-heavy_p-(sv**2-sm*sb**2)/2
    bnu=data['grhonu_t']+gpnu;dn=data['grhonu_t']*data['clxnu'];jn=data['dgq']-data['qde']*data['grhov_t']-data['grhob_t']*data['vb']-data['grhog_t']*data['qg']-data['grhor_t']*data['qr']
    hub=data['adotoa'];force=(data['dgrho']/2+grid*data['etak'])/hub
    slow=2*sv*data['mts_dphidot_s']-sm*sb*data['mts_dphi_s']
    sourcebar=(data['grhoc_t']*data['clxc']+data['grhob_t']*data['clxb'])/2+data['grhog_t']*data['clxg']+data['grhor_t']*data['clxr']
    result={'matter':np.array([last(key) for key in FIELDS[:7]]),'weights':np.array([last(key) for key in FIELDS[11:15]]),
        'forcing':np.array([last(key) for key in FIELDS[7:11]]),'slow':slow[-1],'dnu':dn[-1]}
    for degree in (5,7):
        prime=lambda x:left_derivative(t,x,degree)
        anu=-(prime(dn)+grid*jn[-1]+bnu[-1]*force[-1])/(2*hub[-1])
        anuprime=-(left_derivative(t,dn,degree,2)+grid*prime(jn)+prime(bnu)*force[-1]+bnu[-1]*prime(force))/(2*hub[-1])-anu*prime(hub)/hub[-1]
        result['anu'+str(degree)]=anu;result['anuprime'+str(degree)]=anuprime
        result['dnuprime'+str(degree)]=prime(dn)
        result['controls'+str(degree)]=np.array([prime(data[key]) for key in FIELDS[7:11]])
        result['slowprime'+str(degree)]=prime(slow)
        result['explicit_source'+str(degree)]=sourcebar[-1]+anu+slow[-1]
        result['explicit_tangent'+str(degree)]=prime(sourcebar)+anuprime+prime(slow)
    pack(tag+'-ordinary-input.npz',**result)

def evolve(tag,variant,step):
    early=unpack(ROOT/(tag+'-early.npz'));ordinary=unpack(ROOT/(tag+'-ordinary-input.npz'))
    k=early['grid'];n=len(k);rho=early['rho'].item();mass=early['mass'].item();scale0=early['scale']
    ref=np.vstack((early['seed'],scale0,early['hub'],early['force'],early['fluid'],ordinary['matter']))
    degree='7' if variant=='stencil7' else '5';order=0 if variant=='constant' else 1
    massless=variant=='massless'
    base=ordinary['dnu'] if massless else ordinary['anu'+degree]
    slope=ordinary['dnuprime'+degree] if massless else ordinary['anuprime'+degree]
    def rhs(time,state):
        val=state.reshape(-1,n);scale,hub,force,fd,fj=val[7:12]
        cold,baryon,vb,ph,qg,rad,qr=val[12:];dt=(time-CUT)*order
        pig,pir,opacity,pb=ordinary['forcing']+dt*ordinary['controls'+degree]
        scale_ratio=scale0/scale
        gc,gb,gg,gr=ordinary['weights']*np.array([scale_ratio,scale_ratio,scale_ratio**2,scale_ratio**2])
        other=(gc*cold+gb*baryon)/2+gg*ph+gr*rad+ordinary['slow']+base+dt*(slope+ordinary['slowprime'+degree])
        mu=mass*scale;heavy=product_rhs(val,mu,hub,force,k)
        if tag=='matched':
            ratio=(k/mu)**2;pressure=ratio/(np.sqrt(1+ratio)+1)**2*(fd+3*hub*fj/k)
            trace=rho/scale*(fd+3*pressure)/2;bp=0
            densityprime=-3*hub*pressure-k*fj-force;currentprime=-hub*fj+k*pressure
        else:
            trace=rho/scale*(val[3]+3*val[5])/2;bp=rho/scale*val[1]
            densityprime=np.zeros(n);currentprime=densityprime
        slip=opacity*(4*vb/3-qg)
        return np.asarray(heavy+[hub*scale,-(hub**2+early['ambient_gpress']*scale_ratio**2+bp)/2,
            -hub*force-trace-other,densityprime,currentprime,-force,-force-k*vb,-hub*vb+k*pb-gg/gb*slip,
            -4*force/3-k*qg,k*(ph-2*pig)/3+slip,-4*force/3-k*qr,k*(rad-2*pir)/3]).ravel()
    times=np.arange(round(CUT*320),round(END*320)+1)/320
    sol=solve_ivp(rhs,(CUT,END),ref.ravel(),t_eval=times,method='DOP853',rtol=1e-12,atol=5e-17,max_step=step)
    assert sol.success and np.isfinite(sol.y).all() and np.array_equal(sol.t,times)
    result=sol.y.T.reshape(len(times),-1,n);scale,hub,force=result[:,7:10].transpose(1,0,2)
    out=project(times,scale,hub,result,mass,k,CUT)
    if variant in ('physical','fine'):out.update(force=force,hub=hub[:,0],scale=scale[:,0])
    pack(tag+'-ordinary-'+variant+'.npz',time=times,k=k,ending=result[-1],evaluations=sol.nfev,**out)
    print(tag,variant,len(out['centers']),flush=True)

def main():
    check('predictions.json');freeze('ordinary-method.json',['ORDINARY.md','ordinary.py','score_ordinary.py','predictions.json','scores.json'])
    for tag in ('wave','matched'):source(tag)
    files=['ordinary-method.json']+[tag+'-ordinary-input.npz' for tag in ('wave','matched')]
    for tag in ('wave','matched'):
        for variant in ('physical','constant','stencil7','massless','fine'):
            guard();evolve(tag,variant,1/1280 if variant=='fine' else 1/160);files.append(tag+'-ordinary-'+variant+'.npz')
    freeze('ordinary-forecast.json',files)
if __name__=='__main__':main()
