from source_io import *
from unittest.mock import patch
from scipy.interpolate import CubicSpline
import subprocess,tempfile

def archive_path(name):return 'native/'+name
def capture(model,func):
    import capture89 as cap
    native=cap.diag.native
    cpath=pin(SOURCE,'exact-phase-extension.npz')
    assert json.loads(pin(SOURCE,'matching-validation.json').read_bytes())['passed']
    status=native.obj(native.source('runs/heavy/status.json'))
    for file in native.engine.inherited.native_hashes():native.checked(file,status['input_hashes'][str(file)])
    pars=native.engine.inherited.params_for(cpath,background_boost=8.);pars.DoLateRadTruncation=False
    bg=native.engine.camb.get_background(pars);bg.Params.Accuracy.IntTolBoost=6
    with cap.pin('capture-heavy.csv').open() as f:blocks=list(csv.DictReader(f))
    with np.load(pin(SOURCE,'matched-native/linear-heavy-00.npz')) as a:oldtime=a['eta']
    epochs=np.arange(round(89.55*160),round(90.45*160)+1)/160.;ticks=np.unique(np.r_[oldtime[17:],epochs])
    pos=np.searchsorted(ticks,epochs);assert np.array_equal(ticks[pos],epochs)
    overlap=epochs<=89.65;past=np.searchsorted(oldtime,epochs[overlap]);assert np.array_equal(oldtime[past],epochs[overlap]) and sum(overlap)==17
    extra=['mts_dphi_s','mts_dphidot_s','mts_dphi_h','mts_dphidot_h'];audit=['mts_match_count','mts_match_tau','mts_drho_h','mts_dp_h','mts_q_h']
    cols=extra+cap.NAMES
    with patch.object(cap.diag.symbolic,'compile_sympy_to_camb_source_func',return_value=func):
        rows=[];pol=[];polkeys='pig polter E(2) E(3) octg'.split()
        for idx,block in enumerate(blocks+[blocks[-1]]):
            guard();file=f'linear-heavy-{idx:02}.npz' if idx<len(blocks) else 'output-native-heavy.npz'
            with np.load(pin(SOURCE,'matched-native/'+file)) as old:
                spec=old['k'];names=old['keys'].tolist();assert names==cols
                target=old['values'][:,past];ks=np.unique(np.r_[spec,float(block['control']),float(block['hierarchy_cap'])])
                dest=archive_path(file);afile=archive_path(f'phase-audit-{idx:02}.npz')
                if not (ROOT/dest).exists():
                    raw=bg.get_time_evolution(ks,ticks,vars=extra+audit+[cap.Dummy(k) for k in cap.NAMES],lAccuracyBoost=4)[np.searchsorted(ks,spec)][:,pos]
                    checks=raw[:,:,4:9];out=np.concatenate((raw[:,:,:4],raw[:,:,9:]),axis=2)
                    assert np.all(checks[:,:,0]==1) and np.all(out[:,:,2:4]==0) and np.isfinite(raw).all()
                    pack(afile,eta=epochs,k=spec,values=checks,keys=audit)
                    good=np.isclose(out[:,:,cols.index('k')],spec[:,None],rtol=1e-13,atol=0);assert good.all()
                    pack(dest,k=spec,eta=epochs,keys=cols,values=out,good=good,begin=int(block['first']))
                else:
                    with np.load(ROOT/dest) as saved:out=saved['values'];assert np.array_equal(saved['k'],spec) and np.array_equal(saved['eta'],epochs)
                with np.load(pin(SOURCE,f'matched-native/phase-audit-{idx:02}.npz')) as oldaudit,np.load(ROOT/afile) as au:
                    ids=np.searchsorted(oldaudit['t'],epochs[overlap]);checkold=oldaudit['values'][:,ids]
                    for col,key in enumerate(audit):
                        rows.append(dict(block=idx,field=key,pct=err(au['values'][:,overlap,col],checkold[:,:,col])))
                for col,key in enumerate(cols):rows.append(dict(block=idx,field=key,pct=err(out[:,overlap,col],target[:,:,col])))
            if idx<len(blocks):pol.append(out[:,:,[cols.index(key) for key in polkeys]].transpose(2,0,1))
            if idx==0:
                scale=out[-1,:,cols.index('a')];fields={}
                with np.load(cpath) as par:
                    for tag in ('s','h'):
                        axis=par['heavy_efold' if tag=='h' else 'efold'];loga=np.log(scale)
                        assert min(loga)>=axis[0] and max(loga)<=axis[-1]
                        for v in ('phi','phidot'):
                            spl=CubicSpline(axis,par[v+'_'+tag]);fields[tag+v]=spl(loga)
                            if v=='phidot':fields[tag+'vN']=spl(loga,1);fields[tag+'vNN']=spl(loga,2)
                        fields[tag+'mass']=par[('heavy' if tag=='h' else 'slow')+'_mass_mpc']
                pack(archive_path('background-heavy.npz'),eta=epochs,**fields)
            if idx%8==0:print('matched native block',idx,'of 38',flush=True)
    pack(archive_path('polar-heavy.npz'),eta=epochs,keys=polkeys,values=np.concatenate(pol,axis=1))
    table('mode-overlap.csv',rows);worst=max(rows,key=lambda r:r['pct']);print('native overlap worst',worst,flush=True)
    assert worst['pct']<=.5,worst
    freeze('native-freeze.json',['forecast-freeze.json','native_extension.py','mode-overlap.csv']+[f.as_posix() for f in sorted(Path('native').glob('*'))])

if __name__=='__main__':
    check('forecast-freeze.json');(ROOT/'native').mkdir(exist_ok=True)
    inherited=previous.prefix();cap=inherited.import_at(SOURCE,'capture89')
    if sys.argv[1:2]==['--child']:
        with patch.object(cap.driver,'HERE',ROOT),patch.object(cap.driver,'NAMES',cap.NAMES),patch.object(cap.driver,'save',write),patch.object(cap.driver,'run',capture):cap.driver.main()
    else:
        with tempfile.TemporaryDirectory(dir=ROOT,prefix='reader-') as tmp:subprocess.run([sys.executable,'-B',__file__,'--child',tmp,'heavy'],cwd=ROOT,check=True)
