from source_io import *
from scipy.interpolate import make_interp_spline
from types import SimpleNamespace
PARTS=('potential_square','laplacian','gradient','locked_flux')
def project(side,s):
    values=[];ks=[]
    for idx in range(38):
        name=f'linear-heavy-{idx:02}.npz'
        path=ROOT/('native/'+name) if side=='matched' else pin(PAD,'material-halfstep/'+name)
        with np.load(path) as f:
            assert f['good'].all()
            if idx==0:t=f['eta']
            else:assert np.array_equal(t,f['eta'])
            names=f['keys'].tolist();v=f['values'];k=f['k'][:,None]
            cols=lambda key:v[:,:,names.index(key)]
            phi=(cols('etak')-cols('adotoa')*cols('sigma'))/k
            flux=-(cols('dgq')+(cols('grho')+cols('gpres'))*cols('sigma'))/(2*k)
            values.append((phi,flux));ks.extend(k[:,0])
    es=s.earlier.es;data=SimpleNamespace(nodes=np.array(ks),shell=np.array(json.loads(es.pin('legs.json').read_bytes())['squared_radii']),first={key:np.concatenate([v[j] for v in values]) for j,key in enumerate(('phi','flux'))})
    op=es.Fast(es.Project(data).ops[0],data)
    parts=dict(potential_square=-op.k2*op.product('phi','phi'),laplacian=2*op.lap('phi','phi'),gradient=-.5*op.grad('phi','phi'),locked_flux=1.5*op.product('flux','flux'))
    parts['spatial']=sum(parts[key] for key in PARTS[:3]);parts['restore']=parts['spatial']+parts['locked_flux']
    src=ROOT/'material/forcing-heavy.npz' if side=='matched' else pin(PAD,'material-halfstep/forcing-heavy.npz')
    with np.load(src) as f:
        assert np.array_equal(t,f['eta']);target=f['values'][f['keys'].tolist().index('U'),:,0]
        return t,parts,target

def rate(t,arr,order):
    return arr if order==0 else make_interp_spline(np.log(t),arr,k=5)(np.log(t),nu=1)/t

def run():
    check('forecast-freeze.json');check('material-freeze.json');s=spatial_module()
    tw,w,wu=project('wave',s);tm,m,mu=project('matched',s);assert np.array_equal(tm,tw)
    t=tm;truth={key:v-m[key] for key,v in w.items()}
    cross=err(truth['restore'],wu-mu);assert cross<1e-6,cross
    branch={key:err(v,original) for key,v,original in [('matched',m['restore'],mu),('wave',w['restore'],wu)]}
    assert max(branch.values())<1e-6
    from spatial_io89 import checked
    with np.load(checked('native-U.npz')) as old:
        past=old['eta'];prior={k:old['wave_'+('flux_square' if k=='locked_flux' else k)]-old['matched_'+('flux_square' if k=='locked_flux' else k)] for k in PARTS}
        prior['spatial']=sum(prior[k] for k in PARTS[:3]);prior['restore']=prior['spatial']+prior['locked_flux']
    overlap=(t>=89.6)&(t<=89.65);opos=np.searchsorted(past,t[overlap]);assert np.array_equal(past[opos],t[overlap])
    overlaps={k:err(val[overlap],prior[k][opos]) for k,val in truth.items()};assert max(overlaps.values())<=.5
    rows=[];budget=[]
    with np.load(ROOT/'blind-source.npz') as pred:
        pt=pred['eta'];pos=np.searchsorted(pt,t);assert np.array_equal(pt[pos],t)
        forecast={k:pred[k][pos] for k in truth}
    samples=[];fixed=past<=89.6
    for key,actual in truth.items():
        for order in (0,1):
            obs=rate(t,actual,order);errors=rate(t,forecast[key]-actual,order);oldscale=max(abs(rate(past,prior[key],order)[fixed]))
            for end in (89.7,89.8,90.,90.4):
                mask=(t>89.65)&(t<=end);peak=max(abs(obs[mask]));location=t[mask][np.argmax(abs(errors[mask]))]
                local=100*max(abs(errors[mask]))/peak
                rows.append(dict(key=key,order=order,end=end,n=int(mask.sum()),worst_mpc=location,pct=local,prior_peak_pct=100*max(abs(errors[mask]))/oldscale,passed=bool(local<=.5)))
        if key in ('restore','locked_flux','spatial'):
            grd=(forecast[key]-actual);dr=rate(t,grd,1);tr=rate(t,actual,1)
            for idx in np.flatnonzero((t>89.65)&(t<=90.4)):
                samples.append(dict(t=t[idx],quantity=key,value_err=abs(grd[idx]),rate_err=abs(dr[idx]),native_value_abs=abs(actual[idx]),native_rate_abs=abs(tr[idx])))
    for order in (0,1):
        gaps={key:rate(t,forecast[key]-truth[key],order) for key in ('restore','spatial','locked_flux')}
        for end in (89.7,89.8,90.,90.4):
            mask=(t>89.65)&(t<=end);g=gaps['restore'][mask];terms=[gaps[k][mask] for k in ('spatial','locked_flux')]
            assert err(terms[0]+terms[1],g)<1e-5
            budget.append(dict(order=order,end=end,spatial_share=np.vdot(g,terms[0]).real/np.vdot(g,g).real,flux_share=np.vdot(g,terms[1]).real/np.vdot(g,g).real))
    table('source-scores.csv',rows);table('signed-budget.csv',budget);table('error-history.csv',samples)
    pack('native-target.npz',eta=t,**truth)
    put('score-checks.json',dict(frozen=sha(ROOT/'forecast-freeze.json'),native_branch_closure_pct=branch,correction_closure_pct=cross,prior_overlap_pct=overlaps))
    freeze('score-freeze.json',['score_source.py','forecast-freeze.json','material-freeze.json','native-target.npz','source-scores.csv','signed-budget.csv','error-history.csv','score-checks.json'])
    for key in ('spatial','locked_flux','restore'):
        print(key,[(r['end'],r['order'],round(r['pct'],6)) for r in rows if r['key']==key])
if __name__=='__main__':run()
