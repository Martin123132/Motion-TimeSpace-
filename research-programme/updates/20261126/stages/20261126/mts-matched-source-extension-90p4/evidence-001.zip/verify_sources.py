from source_io import *

def verify():
    for name in ('forecast-freeze.json','native-freeze.json','material-freeze.json','score-freeze.json','incident-freeze.json'):check(name)
    assert sha(CARRY/'seal.json')==UPIN
    for fol,sig in previous.PINS.items():assert sha(fol/'seal.json')==sig
    checks=json.loads((ROOT/'score-checks.json').read_bytes());assert checks['frozen']==sha(ROOT/'forecast-freeze.json')
    rows=list(csv.DictReader((ROOT/'source-scores.csv').read_text().splitlines()))
    assert len(rows)==48 and len({(r['key'],r['order'],r['end']) for r in rows})==48
    assert all((r['passed']=='True')==(float(r['pct'])<=.5) for r in rows)
    mat=json.loads((ROOT/'material-checks.json').read_bytes());assert mat['passed'] and mat['worst']['restart_overlap']['pct']<=.5
    bins=list(csv.DictReader((ROOT/'incident-checks.csv').read_text().splitlines()))
    assert len(bins)==237 and max(float(r['err_pct']) for r in bins)<=.5
    for tag in ('wave','matched'):
        with np.load(ROOT/f'incident-{tag}-16.npz') as new,np.load(ROOT/f'incident-end-{tag}.npz') as state:
            assert new['t'][0]==89.65 and new['t'][-1]==state['t']==90.4 and np.all(np.diff(new['t'])>0)
            assert np.array_equal(state['q'],new['q']) and state['bins'].shape==(77,2,81,782) and state['common'].shape==(2,81,782)
            assert np.isfinite(state['bins']).all() and np.isfinite(new['micro']).all() and max(new['seams'])<=.5
    rates=list(csv.DictReader((ROOT/'rate-control.csv').read_text().splitlines()));assert len(rates)==6
    assert all(max(float(r['native_rate_disagreement_pct']),float(r['source_rate_error_pct']))<=.5 for r in rates)
    with np.load(ROOT/'shear-extension.npz') as s:
        assert s['eta'][0]==89.6 and s['eta'][-1]==90.4 and err(s['matched_force'],s['wave_force']*s['wave_a']/s['matched_a'])<1e-9
    assert max(json.loads((ROOT/'shear-checks.json').read_bytes()).values())<=.5
    assert not list(ROOT.glob('reader-*')) and not list(ROOT.rglob('*.partial'))
    print('Verified forecasts, source/readout overlap, 48 scores, 237 incident controls, and complete 90.4 incident restart states.')
if __name__=='__main__':
    verify()
    if sys.argv[1:]==['seal']:
        assert (ROOT/'RESULTS.md').exists()
        put('seal.json',dict(files={f.relative_to(ROOT).as_posix():sha(f) for f in sorted(ROOT.rglob('*')) if f.is_file() and f!=ROOT/'seal.json'}))
        print('seal:',sha(ROOT/'seal.json'))
