from source_io import *
from unittest.mock import patch
from scipy.integrate import solve_ivp

def run():
    guard();s=spatial_module();time,old,k,pre=s.causal_inputs()
    assert time[-1]<s.SWITCH and old[-1]==89.65
    output=np.arange(round(old[0]*160),round(90.45*160)+1)/160.
    assert np.array_equal(old,output[:len(old)])
    calls=[]
    def record(rhs,span,initial,**opts):
        solution=solve_ivp(rhs,span,initial,**opts);assert solution.success
        calls.append((rhs,span,initial.copy(),opts,solution.sol));return solution
    with patch.object(s.earlier,'solve_ivp',record):
        legacy,cfg=s.earlier.model(6,time,output,k,pre)
    assert len(calls)==2 and calls[1][1][0]==s.SWITCH
    wave=calls[0][-1];rhs,span,initial,opts,_=calls[1]
    a,h,b,v=wave(s.SWITCH)[:4]
    drho=pre['dust']/a-(v*v+(pre['mass']*a*b)**2)/2
    initial[1]=np.sqrt(h*h+drho/3)
    fluid=solve_ivp(rhs,span,initial,**opts);assert fluid.success
    main,_,info=s.predict(4,output,k,pre,wave,fluid.sol,rhs)
    fine,_,_=s.predict(8,output,k,pre,wave,fluid.sol,rhs)
    fields={key:main[key] for key in ('potential_square','laplacian','gradient','delta_phi')}
    fields['spatial']=sum(fields[key] for key in ('potential_square','laplacian','gradient'))
    fields['locked_flux']=legacy['restore'];fields['restore']=fields['spatial']+fields['locked_flux']
    refine={key:err(main[key],fine[key]) for key in ('potential_square','laplacian','gradient','delta_phi')}
    with np.load(pin(SPATIAL,'primary.npz')) as ar:
        assert np.array_equal(ar['eta'],old) and np.array_equal(k,ar['k'])
        replay={key:err(x[...,:len(old)],ar[key]) for key,x in fields.items()}
    assert max(replay.values())<=.5 and max(refine.values())<=.5,(replay,refine)
    pack('blind-source.npz',eta=output,k=k,**fields)
    put('forecast-checks.json',dict(overlap_pct=replay,refinement_pct=refine,prior_last_mpc=time[-1],checks=info,fit_config=cfg))
    freeze('forecast-freeze.json',['PROTOCOL.md','source_io.py','forecast_extension.py','blind-source.npz','forecast-checks.json'])
    print('Frozen pre-switch source predictions through',output[-1],replay,refine)
if __name__=='__main__':run()
