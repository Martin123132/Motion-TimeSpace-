from source_io import *
from scipy.interpolate import make_interp_spline,CubicSpline
def run():
    check('material-freeze.json');check('score-freeze.json')
    sys.path.insert(0,str(previous.KER));pin(previous.KER,'wave_kernel.py');import wave_kernel as wk
    with np.load(pin(SOURCE,'exact-phase-extension.npz')) as p:rho0=p['matching_density'].item()
    with np.load(pin(PAD,'material-halfstep/forcing-heavy.npz')) as w,np.load(ROOT/'material/forcing-heavy.npz') as m:
        t=w['eta'];assert np.array_equal(t,m['eta'])
        fit=lambda a:make_interp_spline(np.log(t),a,k=5)
        aW=fit(w['background'][w['bgkeys'].tolist().index('a')]);aM=fit(m['background'][m['bgkeys'].tolist().index('a')]);stress=fit(w['values'][w['keys'].tolist().index('hshear'),:,0])
    axis=np.arange(round(89.6*1280),round(90.4*1280)+1)/1280;u=np.log(axis)
    shear=stress(u)*aW(u)/rho0;force=rho0/aM(u)*shear
    direct=aW(u)/aM(u)*stress(u);algebra=err(force,direct)
    tests={}
    for grid in ('p16','p32'):
        clock,curves,kk,mass,density=wk.read(grid);assert density==rho0
        inside=(axis>=89.6)&(axis<=clock.x[-1])
        prediction=curves['shear'](clock(axis[inside]))[:,0];tests[grid]=err(shear[inside],prediction)
        ix=np.searchsorted(axis,89.65);tests[grid+'_entry']=err(shear[ix],curves['shear'](clock(89.65))[0])
    tests['algebra']=algebra
    assert max(tests.values())<=.5,tests
    pack('shear-extension.npz',eta=axis,mass_normalized_shear=shear,matched_force=force,wave_force=stress(u),matched_a=aM(u),wave_a=aW(u),rho0=rho0)
    put('shear-checks.json',tests);print(tests)
if __name__=='__main__':run()
