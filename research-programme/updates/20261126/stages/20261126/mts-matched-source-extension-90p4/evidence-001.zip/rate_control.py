from source_io import *
from scipy.interpolate import make_interp_spline
from scipy.special import binom

def run():
    check('score-freeze.json')
    with np.load(ROOT/'blind-source.npz') as p,np.load(ROOT/'native-target.npz') as r:
        ts=r['eta'];pos=np.searchsorted(p['eta'],ts);h=1/160;assert np.max(abs(np.diff(ts)-h))<2e-14
        ids=np.flatnonzero((ts>89.65)&(ts<=90.4));rows=[]
        for key in ('spatial','locked_flux','restore'):
            actual=r[key];difference=p[key][pos]-actual
            prime=lambda a:make_interp_spline(np.log(ts),a,k=5)(np.log(ts[ids]),nu=1)/ts[ids]
            ref=prime(actual);gap=prime(difference)
            for n in (4,5):
                offsets=np.arange(1,n+1);coeff=(-1.)**(offsets+1)*binom(2*n,n-offsets)/(offsets*binom(2*n,n))
                assert ids[0]-n>=0 and ids[-1]+n<len(ts) and abs(2*np.sum(coeff*offsets)-1)<1e-14
                def central(f):
                    return (f[ids[:,None]+offsets]-f[ids[:,None]-offsets])@coeff/h
                val=central(actual);delta=central(difference)
                rows.append(dict(field=key,stencil=2*n+1,native_rate_disagreement_pct=err(val,ref),
                       discrepancy_rate_disagreement_pct=100*max(abs(delta-gap))/max(abs(ref)),
                       source_rate_error_pct=100*max(abs(delta))/max(abs(val))))
    table('rate-control.csv',rows);print(rows,flush=True)
if __name__=='__main__':run()
