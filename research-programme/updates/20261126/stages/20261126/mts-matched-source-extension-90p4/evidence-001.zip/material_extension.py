from source_io import *
from unittest.mock import patch

def material():
    check('native-freeze.json');lib=previous.prefix().import_at(SOURCE,'material89')
    out=ROOT/'material';out.mkdir(exist_ok=True)
    matpack=lambda fname,**data:pack('material/'+fname,**data)
    rowsave=lambda name,rows:table('material/'+name,rows)
    with patch.object(lib.es,'HOME',ROOT/'native'):data=lib.es.read_data('heavy')
    data.scalars.pop('heavy')
    mapper=lib.es.Project(data);modes=lib.es.Mixed();output=[]
    for index,coordinate in enumerate(lib.PROBES):
        guard();op=lib.es.Fast(mapper.ops[index],data)
        with patch.object(lib.es.sources,'Pair',lambda *args:op):
            fields,_=lib.es.sources.make(modes,np.array(coordinate),data,'heavy')
        for species,delta,velocity in [('c','Dcdm','Vcdm'),('b','Db','Vb')]:
            energy=data.background['e'+species];fields[species+'KE']=energy*op.grad(velocity,velocity)
            fields[species+'Jq']=energy*(op.dv(delta,velocity)+3*op.dv('phi',velocity))
        b=data.background;fields.update(gE=4*b['eg']*(op.product('phi','Dg')-op.product('phi','phi')),gJ=3*b['eg']*op.dv('phi','Vg'),
            nuJ=-4*b['er']*op.dv('phi','Vr')/3-b['enm']*op.dv('phi','Vm'),phiSq=op.product('phi','phi'),psiSq=op.product('psi','psi'))
        output.append(fields)
    matpack('forcing-heavy.npz',eta=data.eta,nodes=data.nodes,k=[row[1] for row in mapper.ops],coord=lib.PROBES,keys=list(output[0]),
            values=np.array([list(row.values()) for row in output]).transpose(1,2,0),bgkeys=list(b),background=np.array(list(b.values())))
    r=data.raw;shift=r['sigma']/data.nodes[:,None]
    reference=np.array([r['clxr']/4-r['adotoa']*shift,r['qr']/4+r['sigma']/3,r['pir']/4])
    matpack('incident-input-heavy.npz',eta=data.eta,k=data.nodes,reference=reference,**{key:data.first[key] for key in ('phi','psi','pd')})
    write('material/polar-heavy.npz',(ROOT/'native/polar-heavy.npz').read_bytes())
    rt=lib.rt
    with patch.object(rt,'HOME',out),patch.object(rt,'pack',matpack),patch.object(rt,'table',rowsave),patch.object(rt,'guard',guard),patch.object(rt,'read_data',lambda model:data):rt.run('heavy')
    rows=[]
    def add(group,key,probe,x,y):
        for name,mask in (('full_recomputed_overlap',tm<=89.65),('restart_overlap',(tm>=89.6)&(tm<=89.65)),('interior',(tm>=89.6)&(tm<=89.625))):
            idx=np.searchsorted(oldtm,tm[mask]);assert np.array_equal(tm[mask],oldtm[idx])
            rows.append(dict(group=group,field=key,probe=probe,region=name,pct=err(x[...,mask],y[...,idx])))
    for kind in ('forcing','incident-input','radiation'):
        name=kind+'-heavy.npz'
        with np.load(out/name) as a,np.load(pin(FLUID,'material-halfstep/'+name)) as orig:
            tm=a['eta'];oldtm=orig['eta']
            if kind=='incident-input':
                for key in ('phi','psi','pd','reference'):add(kind,key,'all',a[key],orig[key])
            else:
                assert a['keys'].tolist()==orig['keys'].tolist()
                xx=a['values'];yy=orig['values']
                for idx,k in enumerate(a['keys'].tolist()):
                    for probe in range(xx.shape[-1]):add(kind,k,probe,xx[idx,:,probe],yy[idx,:,probe])
                if kind=='forcing':
                    assert not {'henergy','hJ'}&set(a['keys'].tolist()) and a['bgkeys'].tolist()==orig['bgkeys'].tolist()
                    for k,x,y in zip(a['bgkeys'],a['background'],orig['background']):add('background',k,'all',x,y)
    table('material-overlap.csv',rows)
    worst={name:max((r for r in rows if r['region']==name),key=lambda r:r['pct']) for name in ('full_recomputed_overlap','restart_overlap','interior')}
    rad=list(csv.DictReader((out/'radiation-check-heavy.csv').read_text().splitlines()))
    raderr=max(float(row['relative'])*100 for row in rad)
    passed=max(worst['restart_overlap']['pct'],raderr)<=.5
    put('material-checks.json',dict(worst=worst,radiation_energy_current_identity_pct=raderr,passed=bool(passed)))
    print('material overlap',worst,'radiation',raderr,flush=True)
    assert passed
    freeze('material-freeze.json',['native-freeze.json','material_extension.py','material-overlap.csv','material-checks.json']+[str(f.relative_to(ROOT).as_posix()) for f in sorted(out.iterdir())])
if __name__=='__main__':material()
