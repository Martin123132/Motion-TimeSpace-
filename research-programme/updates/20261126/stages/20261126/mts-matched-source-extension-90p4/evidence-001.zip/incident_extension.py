from source_io import *
from types import SimpleNamespace
from scipy.interpolate import CubicSpline

START,END=89.65,90.4
def load_fields(tag):
    def path(n):
        return ROOT/'material'/n if tag=='matched' else pin(PAD,'material-halfstep/'+n)
    with np.load(path('forcing-heavy.npz')) as body,np.load(path('incident-input-heavy.npz')) as inp:
        epoch=inp['eta'];nodes=inp['k'];assert np.array_equal(body['eta'],epoch) and epoch[0]<START<END<epoch[-1]
        fields={k:CubicSpline(epoch,inp[k],axis=-1,extrapolate=False) for k in ('phi','psi','pd')}
        scale=CubicSpline(epoch,body['background'][body['bgkeys'].tolist().index('a')],extrapolate=False)
    return nodes,fields,scale

def compute(engine,tag,density):
    nodes,fields,scale=load_fields(tag)
    shell=np.array(json.loads(engine.angular12.pin('legs.json').read_bytes())['squared_radii'])
    mass=json.loads(engine.angular12.ti.parent.pin('radiation-background.json').read_bytes())['heavy']['mass_over_temperature']
    with np.load(pin(CARRY,'incident-end-'+tag+'.npz')) as ar:
        assert ar['t']==START;common_state=ar['common'];bins=ar['bins'];q=ar['q']
    with np.load(pin(CARRY,f'incident-{tag}-16.npz')) as ar:
        assert np.array_equal(ar['q'],q) and ar['t'][-1]==START
        previousS=ar['S'][-1];previousW=ar['Sw'][-1];previousM=ar['micro'][-1]
    parts=[];seams=[]
    resolution=20*density*4
    for chunk in range(5):
        guard();ticks=np.arange(round(START*resolution)+12*density*chunk,round(START*resolution)+12*density*(chunk+1)+1)/resolution
        data=SimpleNamespace(eta=ticks,model='heavy',nodes=nodes,shell=shell,first={key:v(ticks) for key,v in fields.items()},background={'a':scale(ticks)})
        inc=SimpleNamespace(data=data,k=nodes,mass=mass);mapper=engine.angular12.Project(data)
        flight=engine.Flight32(inc);contract=engine.Contraction(mapper)
        sample=flight.run(np.inf,common_state);common_state=sample[-1].copy()
        src=contract.project(sample[:,0],sample[:,1],np.inf,mass)
        spec=contract.project(sample[:,0],sample[:,0],np.inf,mass)-src
        joins=[err(src[:,0],previousS),err(spec[:,0],previousW)]
        micro=np.empty((len(src.T),len(q),69),complex)
        for idx,value in enumerate(q):
            sample=flight.run(value,bins[idx]);bins[idx]=sample[-1]
            direct=contract.project(sample[:,0],sample[:,1],value,mass);weight=5-value*np.tanh(value/2)
            joins.append(err(direct[:,0],previousM[idx]+previousS+weight*previousW))
            micro[:,idx]=(direct-src-weight*spec).T
        seams.append(max(joins));assert seams[-1]<=.5,(tag,chunk,seams)
        previousS=src[:,-1];previousW=spec[:,-1];previousM=micro[-1]
        take=slice(1,None) if chunk else slice(None)
        parts.append((ticks[::4][take],src.T[take],spec.T[take],micro[take]))
        print(tag,density,'block',chunk+1,'seam %',seams[-1],flush=True)
    tm,S,Sw,m=[np.concatenate(v) for v in zip(*parts)]
    assert tm[0]==START and tm[-1]==END and np.all(np.diff(tm)>0) and np.isfinite(m).all()
    pack(f'incident-{tag}-{density}.npz',t=tm,k=mapper.ops[0][1],S=S,Sw=Sw,micro=m,q=q,seams=seams)
    if density==16:pack('incident-end-'+tag+'.npz',t=END,q=q,bins=bins,common=common_state)

def run():
    check('score-freeze.json');inherited=previous.prefix();engine=inherited.import_at(SOURCE,'incident89');rows=[];files=[]
    for tag in ('matched','wave'):
        for density in (8,16):
            name=f'incident-{tag}-{density}.npz'
            if not (ROOT/name).exists() or (density==16 and not (ROOT/f'incident-end-{tag}.npz').exists()):compute(engine,tag,density)
            files.append(name)
        with np.load(ROOT/files[-1]) as hi,np.load(ROOT/files[-2]) as lo:
            assert np.array_equal(lo['t'],hi['t'][::2])
            for key in ('S','Sw'):rows.append(dict(branch=tag,test='double sampling',field=key,err_pct=err(lo[key],hi[key][::2])))
            high=hi['micro'];low=lo['micro'];q=hi['q']
            rows.extend(dict(branch=tag,test='double sampling',field=str(value),err_pct=err(low[:,idx],high[::2,idx])) for idx,value in enumerate(q))
            if tag=='wave':
                with np.load(pin(PAD,'common-heavy.npz')) as a:
                    take=(a['eta']>=START)&(a['eta']<=END);pos=np.searchsorted(hi['t'],a['eta'][take]);assert np.array_equal(hi['t'][pos],a['eta'][take])
                    for key in ('S','Sw'):rows.append(dict(branch=tag,test='independent saved wave bank',field=key,err_pct=err(hi[key][pos],a[key].T[take])))
                for idx,value in enumerate(q):
                    with np.load(pin(PAD,f'micro-heavy-{idx-52}.npz')) as a:
                        assert a['q']==value
                        rows.append(dict(branch=tag,test='independent saved wave bank',field=str(value),err_pct=err(high[pos,idx],a['source'].T[take])))
    files.extend('incident-end-'+tag+'.npz' for tag in ('matched','wave'));table('incident-checks.csv',rows)
    top=max(rows,key=lambda r:r['err_pct']);print('overall worst',top,flush=True)
    assert top['err_pct']<=.5
    freeze('incident-freeze.json',['score-freeze.json','incident_extension.py','incident-checks.csv',*files])
if __name__=='__main__':run()
