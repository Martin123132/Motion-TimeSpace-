from pathlib import Path
from io import BytesIO,StringIO
import hashlib,sys,json,csv
import numpy as np
ROOT=Path(__file__).resolve().parent
BASE=ROOT.parent
CARRY=BASE/'mts-carried-photon-window-89p65-20261126'
UPIN='eaea6794d8575dc50213b70bed708bffd881fffa318d57ac2c2faed0300ad2c7'
def sha(file):
    with file.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
assert sha(CARRY/'seal.json')==UPIN
assert sha(CARRY/'carry_io.py')==json.loads((CARRY/'seal.json').read_bytes())['files']['carry_io.py']
sys.path.insert(0,str(CARRY));import carry_io as previous
SOURCE=previous.SOURCE;PAD=previous.PAD;FLUID=previous.FLUID;pin=previous.pin
SPATIAL=BASE/'mts-entry-spatial-U-89p6-20261124'
previous.PINS[SPATIAL]='48102b1a21cc2c87a8dd6e13475587dc4fddad31ef8cf039efb704d67dceaddb'
previous.PINS[CARRY]=UPIN
def guard():
    previous.guard();assert not (ROOT/'STOP-REQUESTED').exists()
def write(name,data):
    guard();file=ROOT/name
    if file.exists():assert sha(file)==hashlib.sha256(data).hexdigest(),name
    else:
        tmp=file.with_name(file.name+'.partial')
        with tmp.open('xb') as out:out.write(data)
        tmp.rename(file)
def put(name,data):write(name,(json.dumps(data,sort_keys=True,allow_nan=False,indent=2,default=lambda x:x.item())+'\n').encode())
def pack(name,**data):
    buf=BytesIO();np.savez_compressed(buf,**data);write(name,buf.getvalue())
def table(name,rows):
    buf=StringIO();w=csv.DictWriter(buf,rows[0],lineterminator='\n');w.writeheader();w.writerows(rows);write(name,buf.getvalue().encode())
def freeze(name,files):put(name,{f:sha(ROOT/f) for f in files})
def check(name):
    for file,h in json.loads((ROOT/name).read_bytes()).items():assert sha(ROOT/file)==h,file
def err(x,y):
    norm=np.max(abs(y));return float(100*np.max(abs(x-y))/norm) if norm else (0. if np.all(x==0) else float('inf'))
def spatial_module():
    sys.path.insert(0,str(SPATIAL));pin(SPATIAL,'predict_spatial89.py');import predict_spatial89
    return predict_spatial89
