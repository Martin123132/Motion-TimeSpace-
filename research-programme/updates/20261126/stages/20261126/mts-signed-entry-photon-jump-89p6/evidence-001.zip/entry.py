from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,sys
from copy import copy
import numpy as np
from scipy.integrate import solve_ivp
from scipy.optimize import brentq
from scipy.special import roots_legendre

ROOT=Path(__file__).resolve().parent
BASE=ROOT.parent
MATCH=BASE/'mts-matched-joint-77-switch-89p6-20261126'
NATIVE=BASE/'mts-prepared-joint-77-switch-89p6-20261126'
EXCH=BASE/'mts-switch-companion-exchange-89p6-20261126'
EARLY=BASE/'mts-switch-current-quadratures-89p6-20261125'
FULL=BASE/'mts-full-window-companion-joint-89p6-20261126'
LIGHT=BASE/'mts-full-window-companion-photons-89p6-20261126'
PINS={MATCH:'3aab615be69d49dcdafeac123dc1c70ecd6cd18516791a15dd0c478d88a51845',NATIVE:'73b24e93fea12844c02baaa76fa61c200b63a90096986c912d5f50bbed338a40',EXCH:'972e5431a544dc8c6db9bcbd9e9d6cc98166128cad28e8ad8cc88be8020a6f5e',EARLY:'c865dc7c06afec41b22a7bfeb253821a1020fe663a98e1d133bf786e7962fc15',FULL:'b97323d32387750279ffca184379a436426ad10bd63407e31fbe4c1f0ca83665',LIGHT:'41336c5e42fd6ea43be92f179f55ced551fd205bfcf883e6a5861e45e0728d2a'}
used={}
def sha(path):
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
def pin(folder,name):
    assert not (folder/'STOP-REQUESTED').exists() and not (ROOT/'STOP-REQUESTED').exists() and not (BASE/'STOP-REQUESTED').exists()
    assert sha(folder/'seal.json')==PINS[folder]
    path=folder/name
    value=sha(path);assert value==json.loads((folder/'seal.json').read_bytes())['files'][name]
    used[str(path.relative_to(BASE))]=value
    return path
def report(name,data):
    with (ROOT/name).open('x',encoding='utf-8') as stream:json.dump(data,stream,sort_keys=True,indent=2,allow_nan=False,default=lambda val:val.item())
def enc(value):return [float(value.real),float(value.imag)]
def now():return datetime.now(timezone.utc).isoformat()
def pct(err,ref):return float(100*abs(err)/abs(ref))

def own_period(grid,field_state,order,step):
    pin(EARLY,'infer_current.py');sys.path.insert(0,str(EARLY))
    from infer_current import inputs
    end,begin,mass,rho0,kk,osc,bg,metric,held,angle,*_=inputs(grid)
    omega=mass*bg(np.log(end))[0];bgscale=np.hypot(osc[0],osc[1]/omega)
    amp=max(abs(field_state[0]),abs(field_state[1]/omega))
    initial=np.r_[osc/[bgscale,omega*bgscale],field_state/[amp,omega*amp]].astype(complex)
    def rhs(at,vec):
        scale,hub=bg(np.log(at));phi,psi=metric(at);drive,moment,*_=held(np.log(at))
        background,speed,field,velocity=vec;om2=(mass*scale)**2
        return [omega*speed,-2*hub*speed-om2*background/omega,
                omega*velocity+(omega*bgscale*speed*(psi+3*phi)+drive)/amp,
                -2*hub*velocity-(kk+om2)*field/omega+(om2*bgscale*background*(3*phi-psi)+moment)/(amp*omega)]
    sol=solve_ivp(rhs,(end,begin),initial,method='DOP853',max_step=step,rtol=2e-12,atol=2e-15,dense_output=True)
    assert sol.success
    nodes,weights=roots_legendre(order);top=angle(end)
    times=np.array([brentq(lambda x:angle(x)-top-phase,begin,end,xtol=5e-14) for phase in (nodes-1)*np.pi/2])
    def current(at):
        scale=bg(np.log(at))[...,0];vec=sol.sol(at)
        return (kk*omega*bgscale*vec[1]*amp*vec[2]+held(np.log(at))[...,3])*scale/rho0
    terminal=current(end);mean=weights@current(times)/2
    return mean,terminal

def calculate(grid):
    pin(MATCH,'match77_stage.py');sys.path.insert(0,str(MATCH))
    import match77_stage as joint
    from cycle3_inputs import Blind
    with np.load(pin(MATCH,f'matched-switch-{grid}.npz')) as arc:
        fields=arc['entry'];fluid=arc['fluid_entry'];t=np.array([arc['t'].item()]);raw=arc['raw_stress'];assert arc['passed']
        assert np.array_equal(fields[:10],fluid[:10]) and np.array_equal(fields[12:],fluid[12:])
    with np.load(pin(EARLY,f'launch-{grid}.npz')) as arc:metric0=arc['seam_phi'].item()
    with np.load(pin(NATIVE,f'switch-{grid}.npz')) as arc:
        assert arc['t']==t[0];entries=arc['entries'];native_stress=arc['raw_stress']
    rows=json.loads(pin(EXCH,'forecast.json').read_bytes())['predictions']
    donation=complex(*next(row for row in rows if row['grid']==grid and row['order']==96)['current'])
    own=[own_period(grid,fields[10:12],order,step) for order,step in ((48,.003),(96,.0015))]
    jc=own[1][0]-own[1][1];jlow=own[0][0]-own[0][1]
    resolution=pct(jc-jlow,jc-donation)
    src=copy(joint.old.source(grid));src.stress=lambda u:np.zeros((len(u),4),complex);src.quads=lambda u:np.zeros((len(u),2),complex)
    bg,bden,we,wj,e0,j0,_,source,_=joint.coefficients(src,t)
    native_energy=we[0]@entries[1]+e0[0]+bg['enu'][0]*native_stress[0]
    native_current=wj[0]@entries[1]+j0[0]+bg['enu'][0]*src.wave*native_stress[1]
    pe=(source[0]-native_energy/2-1.5*bg['h'][0]*native_current/src.kk)/bden[0]
    pm=entries[0,12]
    results=[]
    for sub in (2,4):
        host=joint.Host(grid,sub);host.focus=(t[0]+host.corners[0])/2
        env=list(host.matched.environment(t,np.full_like(t,host.focus)))
        fluid_bg,forcing,_,_,_,_,density,fd=env;rho=density[0]
        stress=raw*fluid_bg['enu'][0];stress[1]*=host.wave;env[2]=stress[None,:]
        energy,current=Blind(host.matched).aggregate(env,fluid[None,:12])
        hub=fluid_bg['h'][0];fac=1.5*hub/host.kk;phi=fluid[12]
        fluid_res=fd[0]*phi+energy[0]/2+fac*current[0]-forcing['U'][0]
        bg,den,*_=joint.coefficients(host,t);den=den[0]
        vel=bg['hv'][0];om=(bg['hm'][0]*bg['a'][0])**2
        _,_,he,hj=host.external(np.log(t[0]))
        bare=vel*fields[11]+om*bg['hb'][0]*fields[10]+he
        volume=3*vel**2*(phi-metric0)/2
        inversion=(bare+3*vel**2*metric0-rho*(fluid[10]+3*phi))/2
        wave_j=host.kk*vel*fields[10]+hj
        native_term=pm-pe
        terms={'fluid_constraint':-fluid_res/den,'density_volume':-volume/den,'density_other':-inversion/den,
               'instant_minus_fluid':-fac*(wave_j-rho*fluid[11])/den,'retained_mean':-fac*rho*donation/den,'resolved_route':native_term}
        shift=-fac*rho*(jc-donation)/den
        predictions={}
        for tag,extra in [('comp',0j),('null',-terms['retained_mean']),('own',shift)]:
            gap=sum(terms.values())+extra
            mom=phi-pm
            predictions[tag]={'momentum':enc(mom),'density':enc(mom+gap),'gap':enc(gap)}
        results.append(dict(grid=grid,sub=sub,t=t[0],terms={k:enc(v) for k,v in terms.items()},pred=predictions,
          current_relative_to_donor_pct=pct(jc-donation,donation),current_change_refinement_pct=resolution,
          own_mean_vs_prepared_mean_pct=pct(own[1][0]-fluid[11],fluid[11]),own_end_vs_live_current_pct=pct(own[1][1]-wave_j/rho,wave_j/rho),
          own_vs_donor_kick_increment=enc(shift),phi_momentum=enc(phi),phi_at_inversion=enc(metric0),phi_native_momentum=enc(pm),phi_native_density=enc(pe)))
    return results

if __name__=='__main__':
    assert not (ROOT/'forecast.json').exists()
    rows=[item for grid in ('p16','p32') for item in calculate(grid)]
    assert all('full-window' not in path for path in used)
    report('forecast.json',{'at':now(),'rows':rows,'inputs':used,'pins':{p.name:s for p,s in PINS.items()},'source_files':{name:sha(ROOT/name) for name in ('PROTOCOL.md','entry.py','compare.py')}})
    print('Switch forecast locked:',sha(ROOT/'forecast.json'))
