import sys
import numpy as np
from entry import BASE,MATCH,EARLY,ROOT,enc,pct,pin,json,report,now,sha

def run():
    fixed=json.loads((ROOT/'forecast.json').read_bytes())
    scored=json.loads((ROOT/'comparison.json').read_bytes())
    assert scored['forecast_sha256']==sha(ROOT/'forecast.json')
    pin(MATCH,'match77_stage.py');sys.path.insert(0,str(MATCH));import match77_stage as joint
    pin(EARLY,'infer_current.py');sys.path.insert(0,str(EARLY));from infer_current import inputs
    info=[]
    for grid in ('p16','p32'):
        start,begin,mass,rho0,kk,osc,bg0,metric0,held,angle,target,prep,lphi=inputs(grid)
        a0,hub0=bg0(np.log(start));r0=rho0/a0;om0=(a0*mass)**2
        field0,vel0=osc;he0,hj0=held(np.log(start))[2:]
        with np.load(pin(MATCH,f'matched-switch-{grid}.npz')) as arc:
            fields=arc['entry'];fluid=arc['fluid_entry'];field,velocity=fields[10:12]
        for sub in (2,4):
            host=joint.Host(grid,sub);host.focus=(start+host.corners[0])/2;time=np.array([start])
            model_bg,den,*_=joint.coefficients(host,time);den=den[0]
            b,v,a,h,m=[model_bg[k][0] for k in ('hb','hv','a','h','hm')]
            rho1=host.matched.environment(time,np.full_like(time,host.focus))[-2][0]
            he1,hj1=host.external(np.log(start))[2:];om1=(a*m)**2
            frozen=next(r for r in fixed['rows'] if r['grid']==grid and r['sub']==sub);gap=complex(*frozen['pred']['comp']['gap'])
            pieces={'oscillator_velocity':(v-vel0)*velocity,'potential_coefficient':(om1*b-om0*field0)*field,
                    'external_heavy_energy':he1-he0,'background_volume_coefficient':3*(v*v-vel0*vel0)*lphi,
                    'density_normalization':(r0-rho1)*target[0],
                    'incoming_inversion':vel0*velocity+om0*field0*field+he0+3*vel0**2*lphi-r0*target[0],
                    'target_definition':rho1*(target[0]-(fluid[10]+3*fluid[12]))}
            scaled={k:-x/(2*den) for k,x in pieces.items()}
            against=complex(*frozen['terms']['density_other'])
            closure=pct(sum(scaled.values())-against,against);assert closure<.005
            fac=1.5*h/kk
            jpieces={'velocity':kk*(v-vel0)*field,'external_heavy_current':hj1-hj0,'density_normalization':(1-rho1/r0)*(kk*vel0*field+hj0)}
            jscaled={k:-fac*x/den for k,x in jpieces.items()}
            summarize=lambda terms:{key:dict(value=enc(val),projection_pct=100*(val/gap).real,norm_pct=pct(val,gap)) for key,val in terms.items()}
            info.append(dict(grid=grid,sub=sub,energy=summarize(scaled),current_end_mapping=summarize(jscaled),closure_pct=closure,
               scale_inversion=float(a0),scale_evolution=float(a),mass_ratio=float(m/mass),
               relative_hub=(h-hub0)/hub0,relative_density=(rho1-r0)/r0,relative_velocity=(v-vel0)/vel0))
    report('energy-origin.json',dict(at=now(),status='post-release source attribution; no fitted corrections',rows=info))
    for row in info:
        if row['sub']==4:print(row['grid'],{k:round(v['projection_pct'],5) for k,v in row['energy'].items()},{k:round(v['projection_pct'],5) for k,v in row['current_end_mapping'].items()})
if __name__=='__main__':run()
