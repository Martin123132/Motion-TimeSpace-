from pathlib import Path
import hashlib,json,re
ROOT=Path(__file__).resolve().parent
def sha(path):
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
def read(name):return json.loads((ROOT/name).read_bytes())
def finish():
    assert not (ROOT/'__pycache__').exists()
    for target in re.findall(r'\]\(([^)]+)\)',(ROOT/'RESULTS.md').read_text(encoding='utf-8')):
        if not target.startswith('https:'):assert (ROOT/target).is_file()
    files={p.name:sha(p) for p in sorted(ROOT.iterdir()) if p.is_file() and p.name!='seal.json'}
    if (ROOT/'seal.json').exists():assert read('seal.json')['files']==files
    else:
        with (ROOT/'seal.json').open('x',encoding='utf-8') as stream:json.dump({'files':files},stream,sort_keys=True,indent=2)
    print(len(files),'files; seal',sha(ROOT/'seal.json'))
if __name__=='__main__':
    forecast=read('forecast.json');s=read('comparison.json');w=read('bank-forecast.json');valid=read('bank-check.json')
    assert sha(ROOT/'forecast.json')==s['forecast_sha256'] and sha(ROOT/'bank-forecast.json')==valid['freeze']
    for name,h in forecast['inputs'].items():assert sha(ROOT.parent/name)==h
    for name,h in forecast['source_files'].items():assert sha(ROOT/name)==h
    for name,h in forecast['pins'].items():assert sha(ROOT.parent/name/'seal.json')==h
    assert sha(ROOT/'bank_witness.py')==w['code']
    assert len(s['gravity'])==8 and max(r['error_pct'] for r in s['gravity'])<1e-8
    assert len(s['photons'])==12 and all(r['nonentry_below_gate'] and not r['own_entry_only_trial_below_gate'] and r['own_change_resolved'] for r in s['photons'])
    assert all(max(r['own_entry_only_joint_launch_pct'])<=s['launch_threshold_pct'] for r in s['photons'])
    assert len(read('energy-origin.json')['rows'])==4 and max(r['closure_pct'] for r in read('energy-origin.json')['rows'])<.005
    assert sorted(r['index'] for r in w['cases'])==sorted(r['index'] for r in valid['rows']) and len(set(r['index'] for r in valid['rows']))==16
    assert all(r['bracket_wins']==[8,8] for r in valid['summary'].values())
    finish()
