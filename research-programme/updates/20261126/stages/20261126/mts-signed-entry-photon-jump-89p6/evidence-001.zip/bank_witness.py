import sys
from scipy.interpolate import make_interp_spline
import numpy as np
from entry import ROOT,BASE,EARLY,enc,now,pin,json,report,sha

def bank():
    pin(EARLY,'current_stage.py');sys.path.insert(0,str(EARLY))
    from current_stage import wave_input
    path=wave_input('material-halfstep/forcing-heavy.npz')
    with np.load(path) as ar:
        keys=ar['keys'].tolist();return ar['eta'],ar['values'][[keys.index('henergy'),keys.index('hJ')],:,0].T,sha(path)
def forecast():
    times,data,source_hash=bank()
    end=json.loads((ROOT/'forecast.json').read_bytes())['rows'][0]['t'];start=np.searchsorted(times,end)
    cases=[];scales=[]
    def estimate(time,mask):
        left=mask&(times<time)&(times>time-.25)
        return [make_interp_spline(np.log(times[sel]),data[sel],k=5)(np.log(time)) for sel in (left,mask)]
    axes=np.arange(len(times));both=estimate(end,np.ones(len(times),bool))
    scales=abs(both[0]-both[1]);assert min(scales)>0
    for index in range(start-8,start+8):
        assert 0<index<len(times)-1
        pred=estimate(times[index],axes!=index)
        cases.append(dict(index=index,time=times[index],side='left' if times[index]<end else 'right',past=[enc(z) for z in pred[0]],bracket=[enc(z) for z in pred[1]]))
    report('bank-forecast.json',dict(at=now(),code=sha(ROOT/'bank_witness.py'),source_hash=source_hash,
        protocol='Leave each of the nearest eight knots on each side out in turn; other held knots may appear as inputs. No fitted parameters or post-selection. Compare errors on each channel separately. This is source cross-validation at knots, not an exact switch evaluation.',scales=list(scales),
        switch=end,last_left=times[start-1],first_right=times[start],fraction=(end-times[start-1])/(times[start]-times[start-1]),cases=cases))
def score():
    packet=json.loads((ROOT/'bank-forecast.json').read_bytes());times,values,source_hash=bank();assert packet['source_hash']==source_hash and packet['code']==sha(ROOT/'bank_witness.py')
    rows=[];summary={}
    for case in packet['cases']:
        idx=case['index'];assert times[idx]==case['time']
        err={key:(100*abs(np.array([complex(*z) for z in case[key]])-values[idx])/packet['scales']).tolist() for key in ('past','bracket')}
        rows.append(dict(index=idx,side=case['side'],**err))
    for side in ('left','right'):
        sample=[r for r in rows if r['side']==side]
        vals=[np.array([row[k] for row in sample]) for k in ('past','bracket')]
        summary[side]=dict(n=len(sample),past_rms=np.sqrt(np.mean(vals[0]**2,axis=0)).tolist(),bracket_rms=np.sqrt(np.mean(vals[1]**2,axis=0)).tolist(),
                           bracket_wins=np.sum(vals[1]<vals[0],axis=0).tolist())
    report('bank-check.json',dict(freeze=sha(ROOT/'bank-forecast.json'),summary=summary,rows=rows))
    print(summary)
if __name__=='__main__':{'forecast':forecast,'score':score}[sys.argv[1]]()
