import csv,json,sys
import numpy as np
from scipy.interpolate import CubicSpline
from entry import ROOT,BASE,FULL,NATIVE,LIGHT,enc,now,pct,pin,sha,report

def main():
    frozen=json.loads((ROOT/'forecast.json').read_bytes())
    for name,value in frozen['source_files'].items():assert sha(ROOT/name)==value
    for name,value in frozen['inputs'].items():assert sha(BASE/name)==value
    pin(LIGHT,'predict.py');sys.path.insert(0,str(LIGHT))
    from predict import cell89,gate,proj
    _,axis,weights,_=proj.old.get_media();measure=gate.previous.make_measure(axis,weights)
    mag=lambda v:gate.mag(v,measure)
    with gate.pin(gate.FROZEN,'window-readouts.csv').open() as stream:
        launch={r['gravity']:float(r['launch_norm']) for r in csv.DictReader(stream) if r['model']=='MTS-minus-baseline' and r['output']=='joint'}
    rows=[];scores=[]
    for calc in frozen['rows']:
        grid=calc['grid'];sub=calc['sub'];suffix=f'{grid}-{sub}.npz'
        with np.load(pin(FULL,'full-grid-'+suffix)) as src,np.load(pin(NATIVE,'joint-'+suffix)) as ref:
            assert src['t'][0]==calc['t']==ref['t'][0]
            vals=src['obs'][0,:,0];native=ref['observables'][0,:,0]
            actual=dict(zip(('comp','null'),(vals[:2]-native,vals[2:]-native)))
        for tag,vec in actual.items():
            predicted=calc['pred'][tag];gap=vec[1]-vec[0];forecast=complex(*predicted['gap'])
            err=pct(forecast-gap,gap)
            rows.append(dict(grid=grid,sub=sub,case=tag,target=enc(gap),predicted=enc(forecast),error_pct=err,
                momentum_error_pct=pct(complex(*predicted['momentum'])-vec[0],vec[0]),
                density_error_pct=pct(complex(*predicted['density'])-vec[1],vec[1]),
                projection_pct=100*(forecast/gap).real,phase_offset_degrees=np.angle(forecast/gap,deg=True),zero_error_pct=100,reverse_error_pct=pct(-forecast-gap,gap),passes=err<=.5))
        tar=actual['comp'][1]-actual['comp'][0];parts={k:complex(*v) for k,v in calc['terms'].items()}
        stable={'energy_volume':parts['density_volume'],'energy_other':parts['density_other'],
                'net_current':parts['retained_mean']+parts['instant_minus_fluid'],'fluid_constraint':parts['fluid_constraint'],'resolved_route':parts['resolved_route']}
        shares={key:dict(projection_pct=100*(val/tar).real,norm_pct=pct(val,tar)) for key,val in stable.items()}
        for setting in ('primary','time','angle'):
            with np.load(pin(LIGHT,f'prediction-{setting}.npz')) as lamp,np.load(cell89.pin(f'photon-{setting}.npz')) as old:
                assert np.array_equal(old['grid'],lamp['scale'])
                view=lambda x:CubicSpline(old['grid'],x)(axis)
                small=mag(view(old['values'][:,old['labels'].tolist().index([grid,'primary']),:3].sum(1)))
                tags=lamp['labels'].tolist();vals=lamp['energy_current']
                unit=view(vals[:,tags.index('unit-entry')]);vector=lambda key:view(vals[:,tags.index(f'{grid}-{sub}-comp_{key}')])
                mom=vector('momentum');den=vector('density');gap=den-mom
                for ci,key in enumerate(('momentum','density')):
                    assert lamp['kicks'][tags.index(f'{grid}-{sub}-comp_{key}')]==actual['comp'][ci]
                ratios=lambda v:(100*mag(v)/small).tolist()
                entry=complex(*calc['pred']['comp']['gap'])*unit;pred_own=complex(*calc['pred']['own']['gap']);shift=(pred_own-complex(*calc['pred']['comp']['gap']))*unit
                gamma=ratios(gap);smooth=ratios(gap-entry);trial=ratios(gap+shift)
                scores.append(dict(grid=grid,sub=sub,setting=setting,physical_gap_pct=gamma,predicted_entry_pct=ratios(entry),
                    prediction_error_pct_small=ratios(entry-tar*unit),nonentry_pct=smooth,nonentry_below_gate=max(smooth)<=.5,
                    term_shares=shares,own_change_resolved=calc['current_change_refinement_pct']<=.5,
                    own_entry_only_trial_gap_pct=trial,own_entry_only_trial_below_gate=max(trial)<=.5,
                    own_entry_only_joint_launch_pct=[100*mag(v)[2]/launch[grid] for v in (mom,den+shift)],
                    entry_signed_share_of_photon_gap_pct=100*np.sum(measure@(entry*gap.conj()).real)/mag(gap)[2]**2))
    assert all(r['passes'] and r['reverse_error_pct']>100 for r in rows)
    report('comparison.json',dict(at=now(),forecast_sha256=sha(ROOT/'forecast.json'),channels=['energy','current','joint'],threshold_pct=.5,launch_threshold_pct=.163,
        gravity=rows,photons=scores,comparison_inputs={folder.name:sha(folder/'seal.json') for folder in (FULL,LIGHT,NATIVE)}))
    for row in scores:
        if row['setting']=='primary' and row['sub']==4:
            print(row['grid'],row['physical_gap_pct'],row['predicted_entry_pct'],row['nonentry_pct'],row['own_entry_only_trial_gap_pct'],row['term_shares'])
if __name__=='__main__':main()
