from pathlib import Path
from functools import lru_cache
import hashlib,json,sys
from io import BytesIO
import numpy as np
ROOT=Path(__file__).resolve().parent
PRE=ROOT.parent/'mts-causal-pressure-envelope-90p4-20261126'
PARENT='06acf2fbc000333a93a049a2719a6d5c1b3ac074053daf3ae13f26dcd5b21758'
def sha(path):
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
assert sha(PRE/'seal.json')==PARENT
pre_files=json.loads((PRE/'seal.json').read_bytes())['files']
def pin(name):
    path=PRE/name;assert sha(path)==pre_files[name],name;return path
pin('inputs.py');sys.path.insert(0,str(PRE));import inputs as earlier
pre=earlier.pre
LEFT=pre.LEFT;RIGHT=pre.RIGHT;SW=pre.SW;FINE=pre.FINE;NATIVE=pre.NATIVE

def guard():
    earlier.guard();assert not (ROOT/'STOP-REQUESTED').exists()
def save(name,raw):
    guard();path=ROOT/name
    if path.exists():assert sha(path)==hashlib.sha256(raw).hexdigest(),name
    else:
        tmp=path.with_suffix(path.suffix+'.partial')
        with tmp.open('xb') as stream:stream.write(raw)
        tmp.rename(path)
def put(name,obj):save(name,(json.dumps(obj,default=lambda v:v.item(),sort_keys=True,indent=2,allow_nan=False)+'\n').encode())
def pack(name,**arrays):
    stream=BytesIO();np.savez_compressed(stream,**arrays);save(name,stream.getvalue())
def freeze(name,names):put(name,{f:sha(ROOT/f) for f in names})
def check(name):
    for name,sig in json.loads((ROOT/name).read_bytes()).items():assert sha(ROOT/name)==sig
def unpack(path):
    with np.load(path) as ar:return {key:ar[key] for key in ar.files}
def build(tag):
    fields=['a','adotoa','etak','dgrho','sigma','phi','dgq','grho','gpres']
    nodes=[];raw=[];gaps=[]
    for block in range(38):
        name=f'linear-heavy-{block:02}.npz'
        with np.load(pre.raw(tag,False,name)) as ar:nodes.extend(ar['k'])
        def read(ar,take):
            assert np.all(ar['good'][:,take]) and np.array_equal(ar['k'],nodes[-len(ar['k']):])
            keys=ar['keys'].tolist();cols=[keys.index(key) for key in fields]
            return ar['values'][:,take,:][:,:,cols].transpose(1,0,2)
        chunk,gap=pre.joined(tag,name,read);raw.append(chunk);gaps.append(gap)
    assert max(np.asarray(gaps).ravel())==0
    k=np.array(nodes);assert len(k)==782 and np.all(np.diff(k)>0)
    scale,hub,eta,density,sigma,phi,dgq,grho,gp=np.concatenate(raw,axis=1).transpose(2,0,1)
    force=(density/2+k*eta)/hub;alpha=sigma/k;psi=2*phi-(eta/k-hub*alpha)
    phidot=(dgq+(grho+gp)*sigma)/(2*k)-hub*psi
    with np.load(pre.raw(tag,False,'background-heavy.npz')) as ar:
        idx=np.flatnonzero(ar['eta']==LEFT).item();mass=ar['hmass'].item();bg=np.array([ar[key][idx] for key in ('hphi','hphidot')])
    pack(tag+'-metric.npz',k=k,mass=mass,background=bg,metric=np.stack([scale,hub,force,alpha,psi,phidot],axis=1),time=NATIVE)
    return k
def main():
    guard();freeze('method.json',['PROTOCOL.md','inverse_io.py','reconstruct.py','test_inverse.py'])
    k=build('wave');assert np.array_equal(k,build('matched'))
    with np.load(pre.oldio.pin(pre.oldio.SOURCE,'exact-phase-extension.npz')) as ar:
        slot=np.argmin(abs(k[:,None]-ar['modes']),axis=1)
        assert np.max(abs(ar['modes'][slot]/k-1))<1e-12 and np.unique(slot).size==k.size
        pack('preparation.npz',k=k,slot=slot,efold=ar['heavy_efold'],phase=ar['phase_h'],center=ar['matching_scale'],rho=ar['matching_density'],
            density=ar['matching_delta'][slot],momentum=ar['matching_momentum'][slot])
    freeze('inputs.json',['method.json','preparation.npz','wave-metric.npz','matched-metric.npz'])
if __name__=='__main__':main()
