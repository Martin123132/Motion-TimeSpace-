from inverse_io import *
from switch_replay import layout
from scipy.interpolate import make_interp_spline,CubicSpline
from scipy.integrate import solve_ivp

def predict():
    check('switch-freeze.json');freeze('native-method.json',['NATIVE-MAP.md','native_map.py','switch-freeze.json','switch-scores.json'])
    prep=unpack(ROOT/'preparation.npz');data=unpack(ROOT/'wave-metric.npz');k=prep['k'];mass=data['mass'].item()
    with np.load(pre.oldio.pin(pre.oldio.SOURCE,'exact-phase-extension.npz')) as ar:
        bt=CubicSpline(ar['heavy_efold'],ar['phi_h']);vt=CubicSpline(ar['heavy_efold'],ar['phidot_h'])
    groups=layout(prep)
    for num,(name,idx,rows,t,scale,ruler,weight,use) in enumerate(groups):
        with np.load(pre.oldio.pin(pre.oldio.SOURCE,name)) as ar:
            times=ar['requested'];take=(times>=LEFT-.05)&(times<=RIGHT+.05)
            cols=[ar['names'].tolist().index(x) for x in ('a','H')]
            if not num:
                knots=times[take];full=np.empty((len(knots),2,len(k)));assert knots[0]<LEFT and knots[-1]>RIGHT
            assert np.array_equal(knots,times[take]);full[:,:,idx]=ar['values'][rows][:,take,:][:,:,cols].transpose(1,2,0)
    aa,hh=full.transpose(1,0,2);force=make_interp_spline(NATIVE,data['metric'][:,2],k=5)(knots)
    drive=np.stack([hh,(mass*aa)**2,vt(np.log(aa))*force],axis=1)
    spl=make_interp_spline(knots,drive,k=7)
    grid=np.unique(np.concatenate([g[3] for g in groups]));assert grid[0]>LEFT
    mu0=mass*data['metric'][0,0];zero=k*0;initial=np.stack([zero,zero,zero+1,zero,zero,mu0])
    def rhs(t,y):
        hub,mm,forcing=spl(t);state=y.reshape(6,-1);res=np.empty_like(state)
        res[::2]=state[1::2];res[1::2]=-2*hub*state[1::2]-(k*k+mm)*state[::2];res[1]-=forcing
        return res.ravel()
    sol=solve_ivp(rhs,(LEFT,grid[-1]),initial.ravel(),t_eval=grid,rtol=1e-12,atol=3e-17,max_step=1/640,method='DOP853')
    assert sol.success and np.array_equal(sol.t,grid)
    st=sol.y.T.reshape(len(grid),6,len(k));out=np.empty((len(k),3,3));rho=prep['rho'].item()
    for name,idx,_,t,scale,ruler,weight,_ in groups:
        ts=np.searchsorted(grid,t);b=bt(np.log(scale));v=vt(np.log(scale))
        for col in range(3):
            f=st[ts,2*col][:,idx];w=st[ts,2*col+1][:,idx];kin=v*w;pot=(mass*scale)**2*b*f
            out[idx,:,col]=np.einsum('t,tks->ks',weight*ruler/rho,np.stack([kin+pot,k[idx]*v*f,kin-pot],axis=-1))
    row_scale=2*mass*prep['center']/k
    matrix=out[:,:2,1:].copy();matrix[:,1]*=row_scale[:,None]
    rhs=np.stack([prep['density']-out[:,0,0],row_scale*(prep['momentum']-out[:,1,0])],axis=1)
    coeff=np.linalg.solve(matrix,rhs[:,:,None])[:,:,0];pressure=out[:,2,0]+np.einsum('ki,ki->k',out[:,2,1:],coeff)
    pack('native-map.npz',k=k,columns=out,c=coeff,predicted_pressure=pressure,condition=np.linalg.cond(matrix))
    freeze('native-map-freeze.json',['native-method.json','native-map.npz'])
def score():
    from test_inverse import summary
    check('native-map-freeze.json');pred=unpack(ROOT/'native-map.npz');prep=unpack(ROOT/'preparation.npz');k=pred['k']
    with np.load(pre.oldio.pin(pre.oldio.SOURCE,'exact-phase-extension.npz')) as ar:
        p=ar['projected_pressure'][prep['slot']];norm=ar['projection_norm'][prep['slot']]
    val=pred['predicted_pressure'];inv=unpack(ROOT/'inverse.npz')
    with np.load(earlier.pin('wave.npz')) as ar:
        state=ar['state'][0];mu0=ar['scale'][0]*ar['mass'];target=np.stack([state[2],state[3]/mu0],axis=1)
    diff=lambda x,y:np.linalg.norm(x-y,axis=1)/np.linalg.norm(y,axis=1)*100
    scores=dict(pressure=summary(100*abs(val-p)/abs(p),k),norm=summary(abs(val-p)/norm,k,2e-6),
        condition_max=max(pred['condition']),seed_vs_primary_pct=summary(diff(pred['c'],inv['c']),k),
        seed_vs_native_pct=summary(diff(pred['c'],target),k))
    put('native-map-scores.json',scores);print(scores)
if __name__=='__main__':predict();score()
