from inverse_io import *
from scipy.interpolate import CubicSpline

def rate(val,target):
    peak=np.max(abs(target),axis=0);gap=np.max(abs(val-target),axis=0)
    if not np.all(peak>0):raise ValueError(('undefined target peaks',int(sum(peak==0))))
    return 100*gap/peak
def summary(arr,k,limit=.5):
    assert np.isfinite(arr).all()
    return dict(worst=arr.max(),median=np.median(arr),p95=np.percentile(arr,95),failures=int(np.sum(arr>limit)),worst_k=k[np.argmax(arr)])
def main():
    guard();check('forecast.json')
    inv=unpack(ROOT/'inverse.npz');k=inv['k'];variants=unpack(ROOT/'inverse-controls.npz');prep=unpack(ROOT/'preparation.npz')
    vecnorm=lambda x:np.linalg.norm(x,axis=-1)
    results=dict(condition_scaled=[inv['condition'].min(),np.median(inv['condition']),inv['condition'].max()],
        condition_unscaled=[inv['raw_condition'].min(),inv['raw_condition'].max()],min_singular=np.min(inv['s'][:,1]),negative_determinants=int(sum(inv['det']<0)),
        min_density_null_momentum_fraction=np.min(abs(inv['density_null_response'][:,1])/inv['s'][:,1]),
        worst_offset_cancellation=inv['cancellation'].max(),wronskian_fraction=inv['wronskian_fraction'].max(),
        worst_amplification_control_rel=np.max(abs(inv['worst_direction_ratio']-1)),input_reproduction_fraction=max(inv['fit_residual']))
    assert np.all(inv['s'][:,1]>0) and max(abs(inv['density_null_response'][:,0])/inv['s'][:,0])<1e-12
    results['variants']={name:summary(100*vecnorm(variants[name]-inv['c'])/vecnorm(inv['c']),k) for name in ('native_samples','width4','degree10','smaller_step')}
    with np.load(pre.oldio.pin(pre.oldio.SOURCE,'exact-phase-extension.npz')) as ar:
        oldp=ar['projected_pressure'][prep['slot']];norm=ar['projection_norm'][prep['slot']]
    results['switch_pressure_mode_fraction']=summary(abs(oldp-inv['switch_pressure'])/norm,k,2e-6)
    assert np.all(oldp!=0)
    results['switch_pressure_pct']=summary(100*abs(inv['switch_pressure']-oldp)/abs(oldp),k)
    original=unpack(earlier.pin('clock-predictions.npz'));fluid=unpack(earlier.pin('projection-comparison.npz'))['matched-native-fluid']
    native=unpack(pre.pin('native-current-forecast.npz'));currents={};averages={};archive={}
    modeledger={'k':k,'condition_scaled':inv['condition'],'sigma_min':inv['s'][:,1],'switch_pressure_own_pct':100*abs(inv['switch_pressure']-oldp)/abs(oldp)}
    for tag in ('wave','matched'):
        fc=unpack(ROOT/(tag+'-prediction.npz'));assert np.array_equal(fc['centers'],original['eta']) and np.array_equal(k,fc['k'])
        saved=unpack(earlier.pin(tag+'.npz'));mask=(FINE>=89.65)&(FINE<=90.4);select=mask[::2];assert np.array_equal(saved['time'],FINE)
        m0=prep['k']*0+saved['mass']*saved['scale'][0]
        target=np.stack([saved['state'][0,2],saved['state'][0,3]/m0],axis=-1)
        row=dict(initial_quadrature_pct=summary(100*vecnorm(inv['c']-target)/vecnorm(target),k))
        for idx,name in [(2,'field'),(3,'velocity')]:row[name+'_late_pct']=summary(rate(fc['state'][mask,idx],saved['state'][mask,idx]),k)
        reference=original[tag+'-own-core']
        for idx,name in enumerate(('density','pressure','momentum')):
            metric=rate(fc['average'][:,:,idx],reference[:,:,idx]);row[name+'_projected_replay_pct']=summary(metric,k)
            if name=='pressure':modeledger[tag+'_pressure_replay_pct']=metric
        row['rest_pressure_mode_fraction']=summary(np.max(abs(fc['closure'])/fc['norm'],axis=0),k,2e-6)
        if tag=='matched':
            for idx,name in enumerate(('density','pressure','momentum')):
                row[name+'_to_actual_fluid_pct']=summary(rate(fc['average'][:,:,idx],fluid[:,:,idx]),k)
        else:
            select_ref=(native['eta']>=89.65)&(native['eta']<=90.4)
            assert np.array_equal(native['eta'][select_ref],NATIVE[select])
            row['independent_native_current_pct']=rate(fc['current'][select],native['j'][select_ref]).tolist()
            row['independent_native_rate_pct']=rate(fc['rate'][select],native['rate'][select_ref]).tolist()
        for name,ref in [('current','current'),('rate','current_rate')]:
            row[name+'_replay_pct']=rate(fc[name][select],saved[ref][select]).tolist()
            currents[tag,name]=fc[name][select];archive[tag,name]=saved[ref][select]
        results[tag]=row;averages[tag]=fc['average']
    pairs={}
    for key in ('current','rate'):
        own=currents['matched',key]-currents['wave',key];arch=archive['matched',key]-archive['wave',key]
        pairs[key]=dict(target_size_on_resolved_pct=rate(archive['matched',key],archive['wave',key]).tolist(),error_on_difference_pct=rate(own,arch).tolist(),peak_abs_per_probe=np.max(abs(own-arch),axis=0).tolist())
    dnew=averages['matched']-averages['wave'];dold=original['matched-own-core']-original['wave-own-core']
    for idx,name in enumerate(('density','pressure','momentum')):pairs[name+'_projected']=summary(rate(dnew[:,:,idx],dold[:,:,idx]),k)
    results['contrast']=pairs
    pack('mode-ledger.npz',**modeledger);put('scores.json',results)
    print('condition',results['condition_scaled'],'switch pressure',results['switch_pressure_pct'],'contrast',pairs['current']['error_on_difference_pct'],flush=True)
if __name__=='__main__':main()
