from inverse_io import *
from reconstruct import propagate
from types import SimpleNamespace
KEYS=('hfield','hmoment','henergy','htrace','hJ','hshear','hJprime')

def pack_sources(tag,stage,state,geo,metric):
    k=metric['k'];mass=metric['mass'].item();a,h,force=geo[::2].transpose(1,0,2);b,v,f,w=state[::2].transpose(1,0,2)
    alpha,psi,pd=metric['metric'][:,3:].transpose(1,0,2);m2=(mass*a)**2;pieces=[]
    for idx in range(38):
        def read(ar,mask):return ar['values'][:,mask,ar['keys'].tolist().index('etak')].T[:,:,None]
        et,_=pre.joined(tag,f'linear-heavy-{idx:02}.npz',read);pieces.append(et[:,:,0])
    phi=np.concatenate(pieces,axis=1)/k-h*alpha
    fg=f+v*alpha;normal=w+(-3*h*v-m2*b)*alpha
    fields=dict(f=fg,n=normal,u=normal-3*v*phi,phi=phi,psi=psi,fd=normal+v*psi,nd=-2*h*normal-(k*k+m2)*fg-m2*b*psi+3*v*pd)
    shell=np.array(json.loads(stage.pin('legs.json').read_bytes())['squared_radii'])
    model=SimpleNamespace(nodes=k,shell=shell,first={key:value.T for key,value in fields.items()})
    mapper=stage.Project(model);allvals=[];outputs=[]
    bg=b[:,0];vel=v[:,0];mass2=m2[:,0]
    for source in mapper.ops:
        op=stage.Fast(source,model);prod=op.product;dg=op.dg
        pp=prod('phi','phi');ss=prod('psi','psi');sp=prod('phi','psi')
        nq=3*prod('phi','u')+7.5*pp*vel
        nn=prod('n','n');grad=op.grad('f','f');pot=mass2*prod('f','f')
        vals=[prod('psi','u')+3*prod('phi','u')+vel*(-ss/2+3*sp+7.5*pp),
            dg('psi','f')-dg('phi','f')-mass2*(prod('psi','f')-3*prod('phi','f')+bg*(-ss/2-3*sp+1.5*pp)),
            vel*nq+(nn+grad+pot)/2,-2*vel*nq-nn+grad+2*pot,-dg('n','f'),op.shear('f','f'),-dg('nd','f')-dg('n','fd')]
        allvals.append(vals);outputs.append(source[1])
    return np.stack(allvals,axis=-1),np.asarray(outputs)
def predict():
    check('native-map-freeze.json');freeze('bundle-method.json',['bundle.py','native-map-freeze.json','native-map-scores.json','forecast.json'])
    assert sys.modules['inputs'] is earlier;del sys.modules['inputs']
    pre.prior.sealed(pre.prior.EXT,'source_io.py');sys.path.insert(0,str(pre.prior.EXT));from source_io import spatial_module
    engine=spatial_module().earlier.es;coeff=unpack(ROOT/'native-map.npz')['c']
    for tag in ('wave','matched'):
        metric=unpack(ROOT/(tag+'-metric.npz'));state,geo,nfev=propagate(metric,tag,1/640,coeff)
        vals,outk=pack_sources(tag,engine,state,geo,metric)
        assert np.isfinite(vals).all() and vals.shape==(7,len(NATIVE),5)
        pack(tag+'-native-prepared-sources.npz',time=NATIVE,k=outk,keys=KEYS,values=vals,field=state[::2,2:],nfev=nfev)
    freeze('bundle-freeze.json',['bundle-method.json','wave-native-prepared-sources.npz','matched-native-prepared-sources.npz'])
def score():
    check('bundle-freeze.json')
    from test_inverse import rate
    data={tag:unpack(ROOT/(tag+'-native-prepared-sources.npz')) for tag in ('wave','matched')}
    true=unpack(pre.oldio.pin(pre.oldio.PAD,'material-halfstep/forcing-heavy.npz'))
    mask=(NATIVE>=89.65)&(NATIVE<=90.4);take=(true['eta']>=89.65)&(true['eta']<=90.4)
    assert np.array_equal(true['eta'][take],NATIVE[mask]) and np.array_equal(true['k'],data['wave']['k'])
    scores={};fc=data['wave']['values'][:,mask];other=data['matched']['values'][:,mask]
    for i,key in enumerate(KEYS[:-1]):
        target=true['values'][true['keys'].tolist().index(key),take]
        scores[key]=dict(native_resolved_pct=rate(fc[i],target).tolist(),matched_minus_resolved_on_wave_pct=rate(other[i],fc[i]).tolist())
    delta=other-fc
    for idx,key,archkey in [(4,'current','current'),(6,'rate','current_rate')]:
        target=[]
        for tag in ('wave','matched'):
            with np.load(earlier.pin(tag+'.npz')) as ar:target.append(ar[archkey][mask])
        scores[key+'_contrast_error_pct']=rate(delta[idx],target[1]-target[0]).tolist()
    put('bundle-scores.json',scores);print({k:max(v['native_resolved_pct']) for k,v in scores.items() if isinstance(v,dict)})
if __name__=='__main__':predict();score()
