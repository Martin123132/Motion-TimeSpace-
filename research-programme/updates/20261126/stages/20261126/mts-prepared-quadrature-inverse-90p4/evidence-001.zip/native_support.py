from inverse_io import *
import native_map

def main():
    assert not (ROOT/'STOP-REQUESTED').exists()
    check('native-method.json')
    groups=native_map.layout(unpack(ROOT/'preparation.npz'))
    native_map.RIGHT=max(group[3][-1] for group in groups)
    assert SW<native_map.RIGHT<RIGHT
    freeze('native-support.json',['native-method.json','native_support.py'])
    native_map.predict();native_map.score()
if __name__=='__main__':main()
