from inverse_io import *
from scipy.integrate import solve_ivp
from scipy.interpolate import make_interp_spline,CubicSpline

def basis(angle,center):
    coord=(angle-center)/(6*np.pi)
    design=np.column_stack([coord**p for p in range(9)]+[coord**p*fn(2*angle) for p in range(7) for fn in (np.cos,np.sin)]+[coord**p*fn(4*angle) for p in range(3) for fn in (np.cos,np.sin)])
    assert np.linalg.matrix_rank(design)==design.shape[1];return np.linalg.pinv(design)[0]
def layout(prep):
    directory=pre.oldio.SOURCE
    info=json.loads(pre.oldio.pin(directory,'matching-validation.json').read_bytes());assert info['passed']
    phase=CubicSpline(prep['efold'],prep['phase']);mid=phase(np.log(prep['center'].item()));lookup=prep['k']
    groups=[];counts=np.zeros(len(lookup),int)
    for name,digest in info['packets'].items():
        path=pre.oldio.pin(directory,name);assert sha(path)==digest
        with np.load(path) as ar:
            nodes=ar['nodes'];ref=ar['anchor'].item();sel=abs(lookup[:,None]/nodes-1)<1e-12
            selected,row=np.where(sel&(abs(nodes/ref-1)>1e-12)[None,:])
            if not len(row):continue
            counts[selected]+=1;scale_idx=ar['names'].tolist().index('a')
            scale=ar['values'][:,:,scale_idx];phase0=phase(np.log(scale[0]))
            take=abs(phase0-mid)<6*np.pi
            t=ar['requested'][take];assert LEFT<t.min()<t.max()<RIGHT
            groups.append((name,selected,row,t,scale[row][:,take].T,scale[0,take],basis(phase0[take],mid),take))
    assert np.all(counts==1)
    return groups

def solve_table(data,coeff,vel_of_a):
    k=data['k'];mass=data['mass'].item();metric=make_interp_spline(NATIVE,data['metric'][:,:3],k=5)
    result=metric(FINE);scale,hub,force=result.transpose(1,0,2)
    coeffs=make_interp_spline(FINE,np.stack([hub,(mass*scale)**2,vel_of_a(np.log(scale))*force],axis=1),k=9)
    initial=np.stack([coeff[:,0],coeff[:,1]*mass*scale[0]])
    def rhs(t,y):
        h,m2,forcing=coeffs(t);field,velocity=y.reshape(2,-1)
        return np.r_[velocity,-2*h*velocity-(k*k+m2)*field-forcing]
    sol=solve_ivp(rhs,(LEFT,RIGHT),initial.ravel(),method='DOP853',rtol=1e-12,atol=3e-17,max_step=1/640,t_eval=FINE)
    assert sol.success;return sol.y.T.reshape(len(FINE),2,-1)
def predict():
    guard();check('forecast.json');freeze('switch-method.json',['SWITCH.md','switch_replay.py','scores.json','forecast.json'])
    prep=unpack(ROOT/'preparation.npz');data=unpack(ROOT/'wave-metric.npz');inv=unpack(ROOT/'inverse.npz');k=prep['k'];rho=prep['rho'].item();mass=data['mass'].item()
    with np.load(pre.oldio.pin(pre.oldio.SOURCE,'exact-phase-extension.npz')) as ar:
        field=CubicSpline(ar['heavy_efold'],ar['phi_h']);vel=CubicSpline(ar['heavy_efold'],ar['phidot_h'])
    tf=solve_table(data,inv['c'],vel)
    with np.load(ROOT/'wave-prediction.npz') as ar:state=ar['state']
    out={label:np.empty((len(k),3)) for label in ('layout','layout7','readout','native_rule')}
    sizes=[]
    for _,idx,_,time,scale,scale0,weight,_ in layout(prep):
        guard();sizes.append(len(time))
        def place(label,back,velocity,pert,rate):
            kin=velocity*rate;pot=(mass*scale)**2*back*pert
            vals=np.stack([kin+pot,kin-pot,k[idx]*velocity*pert],axis=-1)
            out[label][idx]=np.einsum('t,tks->ks',weight*scale0/rho,vals)
        btab=field(np.log(scale));vtab=vel(np.log(scale))
        for degree,name in [(7,'layout7'),(9,'layout')]:
            b,v,f,w=make_interp_spline(FINE,state[:,:,idx],k=degree)(time).transpose(1,0,2)
            place(name,b,v,f,w)
        place('readout',btab,vtab,f,w)
        ft,wt=make_interp_spline(FINE,tf[:,:,idx],k=9)(time).transpose(1,0,2)
        place('native_rule',btab,vtab,ft,wt)
    pack('switch-forecast.npz',k=k,samples=sizes,**out);freeze('switch-freeze.json',['switch-method.json','switch-forecast.npz'])
def score():
    check('switch-freeze.json');prep=unpack(ROOT/'preparation.npz');data=unpack(ROOT/'switch-forecast.npz')
    src=np.empty((len(prep['k']),3));rho=prep['rho'].item();k=prep['k']
    for name,idx,row,_,_,scale0,weights,take in layout(prep):
        with np.load(pre.oldio.pin(pre.oldio.SOURCE,name)) as ar:
            cols=[ar['names'].tolist().index(label) for label in ('mts_drho_h','mts_dp_h','mts_q_h')]
            vals=ar['values'][row][:,take,:][:,:,cols]
            src[idx]=np.einsum('t,kts->ks',weights*scale0/rho,vals)
    with np.load(pre.oldio.pin(pre.oldio.SOURCE,'exact-phase-extension.npz')) as ar:
        slot=prep['slot'];target=np.stack([ar[key][slot] for key in ('matching_delta','projected_pressure','matching_momentum')],axis=-1)
        norm=ar['projection_norm'][slot]
    assert np.all(target!=0);inv=unpack(ROOT/'inverse.npz')
    fields={'source_replay':src,'original':np.stack([prep['density'],inv['switch_pressure'],prep['momentum']],axis=-1)}
    fields.update({key:data[key] for key in ('layout','layout7','readout','native_rule')})
    from test_inverse import summary
    scores={};parts=[]
    for name,val in fields.items():
        rel=100*abs((val-target)/target)
        scores[name]={label:summary(rel[:,i],k) for i,label in enumerate(('density','pressure','momentum'))}
        scores[name]['normalized_pressure']=summary(abs(val[:,1]-target[:,1])/norm,k,2e-6)
    labels=['original','layout','readout','native_rule','source_replay']
    for left,right in zip(labels,labels[1:]):parts.append(fields[right][:,1]-fields[left][:,1])
    scores['numerical_interpolation_pct']=summary(100*abs(data['layout7'][:,1]-data['layout'][:,1])/abs(target[:,1]),k)
    pack('switch-errors.npz',k=k,target=target,norm=norm,original=fields['original'],source=src,parts=np.stack(parts),labels=labels)
    put('switch-scores.json',scores)
    print({label:(scores[label]['pressure']['worst'],scores[label]['pressure']['failures']) for label in labels})
if __name__=='__main__':predict();score()
