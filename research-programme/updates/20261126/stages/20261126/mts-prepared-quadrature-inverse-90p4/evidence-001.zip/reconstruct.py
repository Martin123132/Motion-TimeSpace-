from inverse_io import *
from scipy.interpolate import CubicSpline,make_interp_spline
from scipy.integrate import solve_ivp, cumulative_trapezoid
from scipy.linalg import norm

def propagate(data,tag,cap,start=None):
    k=data['k'];mass=data['mass'].item();metric=data['metric'];mu0=mass*metric[0,0]
    base,vel=data['background'];unit=np.ones(len(k));zero=unit*0
    pieces=[(LEFT,RIGHT,np.ones(len(NATIVE),bool))] if tag=='wave' else [(LEFT,SW,NATIVE<SW),(SW,RIGHT,NATIVE>SW)]
    if start is None:state=np.stack((base*unit,vel*unit,zero,zero,unit,zero,zero,mu0));count=8
    else:state=np.stack((base*unit,vel*unit,start[:,0],start[:,1]*mu0));count=4
    history=np.full((len(FINE),count,len(k)),np.nan);geometry=np.empty((len(FINE),3,len(k)));steps=0
    for left,right,selected in pieces:
        spl=make_interp_spline(NATIVE[selected],metric[selected,:3],k=5)
        def rhs(time,flat):
            row=flat.reshape(count,-1);y=row[::2];v=row[1::2];scale,hub,x=spl(time);m2=(mass*scale)**2
            result=np.empty_like(row);result[::2]=v
            result[1::2]=-2*hub*v-(k*k+m2)*y
            result[1]=-2*hub*v[0]-m2*y[0];result[3]-=v[0]*x
            return result.ravel()
        guard();keep=(FINE>=left)&(FINE<=right);t=np.unique(np.r_[left,FINE[keep],right])
        sol=solve_ivp(rhs,(left,right),state.ravel(),t_eval=t,rtol=1e-12,atol=3e-17,max_step=cap,method='DOP853')
        assert sol.success and np.array_equal(sol.t,t);steps+=sol.nfev
        trail=sol.y.T.reshape(len(t),count,-1);history[keep]=trail[np.searchsorted(t,FINE[keep])];state=trail[-1].copy()
        geometry[keep]=spl(FINE[keep])
    assert np.isfinite(history).all()
    return history,geometry,steps

def weights(phase,middle,width,degree,stride):
    take=(abs(phase-middle)<width*np.pi)&(np.arange(len(phase))%stride==0)
    assert phase[0]<middle-width*np.pi and phase[-1]>middle+width*np.pi
    angle=phase[take];u=(angle-middle)/(width*np.pi)
    design=np.column_stack([u**p for p in range(degree+1)]+[u**p*trig(2*angle) for p in range(degree-1) for trig in (np.cos,np.sin)]+[u**p*trig(4*angle) for p in range(3) for trig in (np.cos,np.sin)])
    assert np.linalg.matrix_rank(design)==design.shape[1]
    return take,np.linalg.pinv(design)[0]
def projected(stress,take,weight):return np.einsum('t,t...->...',weight,stress[take])

def invert(state,geometry,prep,data,width=6,degree=8,stride=1):
    scale=geometry[:,0];k=data['k'];mass=data['mass'].item();center=prep['center'].item()
    mu2=(mass*scale)**2;alpha=scale/prep['rho'];b,v=state[:,:2].transpose(1,0,2)
    ruler=CubicSpline(prep['efold'],prep['phase']);phase=ruler(np.log(scale[:,0]));mid=ruler(np.log(center))
    take,weight=weights(phase,mid,width,degree,stride);outscale=2*mass*center/k
    columns=[];press=[]
    for field,rate in [(state[:,i],state[:,i+1]) for i in (2,4,6)]:
        den=projected(alpha*(v*rate+mu2*b*field),take,weight);jay=projected(alpha*k*v*field,take,weight)
        press.append(projected(alpha*(v*rate-mu2*b*field),take,weight))
        columns.append(np.stack([den,outscale*jay],axis=-1))
    matrix=np.stack(columns[1:],axis=-1);offset=columns[0]
    target=np.stack([prep['density'],outscale*prep['momentum']],axis=-1);right=target-offset
    u,s,vh=np.linalg.svd(matrix,full_matrices=False);assert np.all(s[:,-1]>2*np.finfo(float).eps*s[:,0])
    coeff=np.linalg.solve(matrix,right[:,:,None])[:,:,0]
    apply=lambda arr:np.einsum('koi,ki->ko',matrix,arr)
    predicted=apply(coeff)+offset
    unscaled=matrix.copy();unscaled[:,1]/=outscale[:,None]
    det=np.linalg.det(matrix);cn=s[:,0]/s[:,1]
    null=matrix[:,0,::-1].copy();null[:,0]*=-1;null/=np.linalg.norm(null,axis=-1)[:,None];null_effect=apply(null)
    sized=1e-6*np.linalg.norm(right,axis=1)
    moved=np.linalg.solve(matrix,(right+sized[:,None]*u[:,:,1])[:,:,None])[:,:,0]
    ratio=np.linalg.norm(moved-coeff,axis=1)*s[:,1]/sized
    wr=(state[:,4]*state[:,7]-state[:,5]*state[:,6])/(mass*scale[0]*(scale[0]/scale)**2)
    return dict(c=coeff,A=matrix,h=offset,y=target,s=s,condition=cn,raw_condition=np.linalg.cond(unscaled),det=det,
        cancellation=(np.linalg.norm(target,axis=1)+np.linalg.norm(offset,axis=1))/np.linalg.norm(right,axis=1),
        switch_pressure=press[0]+coeff[:,0]*press[1]+coeff[:,1]*press[2],
        fit_residual=np.linalg.norm(predicted-target,axis=1)/np.linalg.norm(target,axis=1),worst_direction_ratio=ratio,
        density_null_response=null_effect,wronskian_fraction=np.max(abs(wr-1),axis=0))
def fit():
    guard();check('inputs.json');prep=unpack(ROOT/'preparation.npz');wave=unpack(ROOT/'wave-metric.npz')
    results={}
    for name,step in [('primary',1/320),('smaller_step',1/640)]:
        states,geo,nfev=propagate(wave,'wave',step)
        for variant,width,degree,stride in ([('primary',6,8,1),('native_samples',6,8,2),('width4',4,8,1),('degree10',6,10,1)] if name=='primary' else [(name,6,8,1)]):
            result=invert(states,geo,prep,wave,width,degree,stride)
            if variant=='primary':pack('inverse.npz',k=wave['k'],nfev=nfev,**result)
            results[variant]=result['c']
            results[variant+'-pressure']=result['switch_pressure']
            results[variant+'-steps']=nfev
    pack('inverse-controls.npz',**results)
    freeze('inverse-freeze.json',['inputs.json','inverse.npz','inverse-controls.npz'])
def forecast():
    check('inverse-freeze.json');prep=unpack(ROOT/'preparation.npz');coeff=unpack(ROOT/'inverse.npz')['c']
    earlier.pin('predict.py');from predict import currents
    for tag in ('wave','matched'):
        data=unpack(ROOT/(tag+'-metric.npz'));grid=data['k'];mass=data['mass'].item()
        state,geo,nfev=propagate(data,tag,1/640,coeff)
        scale,hub,force=geo.transpose(1,0,2);b,v,f,w=state.transpose(1,0,2);mu2=(mass*scale)**2
        stress=np.stack((v*w+mu2*b*f,v*w-mu2*b*f,grid*v*f),axis=-1)
        half=stress*(scale/prep['rho'])[:,:,None]
        alpha,psi,pdot=data['metric'][:,3:].transpose(1,0,2);bn,vn,fn,wn=state[::2].transpose(1,0,2);hh=hub[::2];mm=mu2[::2]
        fg=fn+vn*alpha;normal=wn+(-3*hh*vn-mm*bn)*alpha
        j,jd=currents(grid,dict(f=fg,n=normal,fd=normal+vn*psi,nd=-2*hh*normal-(grid**2+mm)*fg-mm*bn*psi+3*vn*pdot))
        primitive=CubicSpline(FINE,mass*scale[:,0]).antiderivative();phase=primitive(FINE)-primitive(LEFT)
        centers=[];averages=[];closures=[];norms=[]
        for index in range(0,len(FINE),2):
            if phase[index]-6*np.pi<=np.interp(SW,FINE,phase) or phase[index]+6*np.pi>=phase[-1]:continue
            take,weight=weights(phase,phase[index],6,8,1);out=projected(half,take,weight);havg=projected(hub,take,weight)
            den,pres,jay=out.T;cs=(grid/(mass*scale[index]))**2;cs/= (np.sqrt(1+cs)+1)**2
            norm=np.maximum.reduce([abs(den),abs(grid*jay/havg)/np.maximum(1,grid*np.sqrt(cs)/havg),np.full(len(grid),1e-6)])
            centers.append(FINE[index]);averages.append(out);norms.append(norm);closures.append(pres-cs*(den+3*havg*jay/grid))
        pack(tag+'-prediction.npz',time=FINE,k=grid,state=state,centers=centers,average=averages,norm=norms,closure=closures,current=j,rate=jd,nfev=nfev)
        print(tag,'forecast frozen locally',flush=True)
    freeze('forecast.json',['inverse-freeze.json','wave-prediction.npz','matched-prediction.npz'])
if __name__=='__main__':fit();forecast()
