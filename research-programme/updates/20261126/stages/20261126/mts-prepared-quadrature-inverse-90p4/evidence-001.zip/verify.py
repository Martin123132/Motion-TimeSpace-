from inverse_io import *
from test_inverse import rate
import csv,io

def main():
    guard()
    for receipt in ('method','inputs','inverse-freeze','loader-receipt','forecast','switch-method','switch-freeze','native-method','native-support','native-map-freeze','bundle-method','bundle-freeze'):check(receipt+'.json')
    prep=unpack(ROOT/'preparation.npz');inv=unpack(ROOT/'inverse.npz');native=unpack(ROOT/'native-map.npz')
    fields=unpack(ROOT/'switch-errors.npz');k=prep['k'];assert len(k)==782 and len(np.unique(k))==782
    product=lambda a,x:np.einsum('koi,ki->ko',a,x)
    assert np.allclose(product(inv['A'],inv['c'])+inv['h'],inv['y'],rtol=1e-11,atol=1e-11)
    for keep in (0,1):
        null=inv['A'][:,keep,::-1].copy();null[:,0]*=-1;null/=np.linalg.norm(null,axis=1)[:,None]
        other=product(inv['A'],null)
        assert max(abs(other[:,keep])/inv['s'][:,0])<1e-12 and min(abs(other[:,1-keep])/inv['s'][:,1])>.9999999
    assert np.allclose(inv['worst_direction_ratio'],1,rtol=1e-8,atol=1e-9)
    assert np.max(inv['condition'])<1.0041 and np.all(inv['det']<0)
    arr=product(native['columns'][:,:,1:],native['c'])+native['columns'][:,:,0]
    assert np.allclose(arr[:,0],prep['density'],atol=1e-12,rtol=1e-12) and np.allclose(arr[:,1],prep['momentum'],atol=1e-12,rtol=1e-12)
    assert np.max(abs(arr[:,2]-native['predicted_pressure']))<1e-12
    pt=fields['target'][:,1];scale=fields['norm']
    eps1=100*abs(inv['switch_pressure']-pt)/abs(pt);eps2=100*abs(native['predicted_pressure']-pt)/abs(pt)
    assert sum(eps1>.5)==9 and np.max(eps2)<.5 and max(abs((inv['switch_pressure']-pt)/scale))<2e-6
    assert np.max(abs(fields['parts'].sum(0)-(fields['source'][:,1]-inv['switch_pressure'])))<1e-13
    ledger=io.StringIO(newline='');writer=csv.writer(ledger,lineterminator='\n')
    writer.writerow(['k_inverse_Mpc','condition_continuous','condition_native','native_initial_f','native_initial_w_over_M0','switch_pressure_target','switch_pressure_pred_native','continuous_error_pct','native_error_pct','native_abs_error_over_mode_norm'])
    for idx,kval in enumerate(k):writer.writerow([kval,inv['condition'][idx],native['condition'][idx],*native['c'][idx],pt[idx],arr[idx,2],eps1[idx],eps2[idx],abs(arr[idx,2]-pt[idx])/scale[idx]])
    save('mode-recovery.csv',ledger.getvalue().encode())
    mask=(NATIVE>=89.65)&(NATIVE<=90.4);ref=unpack(pre.oldio.pin(pre.oldio.PAD,'material-halfstep/forcing-heavy.npz'));sel=(ref['eta']>=89.65)&(ref['eta']<=90.4)
    assert np.array_equal(NATIVE[mask],ref['eta'][sel]);new={};old={}
    for tag in ('wave','matched'):
        ar=unpack(ROOT/(tag+'-native-prepared-sources.npz'));assert ar['values'].shape==(7,len(NATIVE),5) and np.array_equal(ar['k'],ref['k'])
        assert np.iscomplexobj(ar['values']) and np.isfinite(ar['values']).all()
        new[tag]=ar['values'][:,mask]
        with np.load(earlier.pin(tag+'.npz')) as hist:old[tag]=np.stack([hist[name][mask] for name in ('current','current_rate')])
    for i,name in enumerate(ar['keys'][:-1]):
        assert max(rate(new['wave'][i],ref['values'][ref['keys'].tolist().index(name),sel]))<.5
    for i,j in [(4,0),(6,1)]:assert max(rate(new['matched'][i]-new['wave'][i],old['matched'][j]-old['wave'][j]))<.5
    assert not any(f.name.endswith('.partial') or f.is_dir() for f in ROOT.iterdir())
    if (ROOT/'seal.json').is_file():
        rec=json.loads((ROOT/'seal.json').read_bytes());assert rec['parent']==PARENT
        assert set(rec['files'])=={f.name for f in ROOT.iterdir() if f.name!='seal.json'}
        for name,sig in rec['files'].items():assert sha(ROOT/name)==sig,name
    elif '--seal' in sys.argv:
        assert (ROOT/'RESULTS.md').is_file()
        put('seal.json',dict(parent=PARENT,files={f.name:sha(f) for f in sorted(ROOT.iterdir()) if f.name!='seal.json'}))
    print('Two-moment inverse and withheld pressure: 782 modes. All six resolved source controls and both paired current checks verified.')
    if (ROOT/'seal.json').exists():print(sha(ROOT/'seal.json'))
if __name__=='__main__':main()
