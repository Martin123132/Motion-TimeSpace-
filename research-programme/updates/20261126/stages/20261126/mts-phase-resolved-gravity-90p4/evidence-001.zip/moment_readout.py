from score_gravity import *
from scipy.integrate import solve_ivp
def solve(tag,grid,res):
    inp=read(ROOT/f'angles-{res}.npz');name=f'solved-{tag}-{grid}-{res}.npz';check(name+'.receipt');full=read(ROOT/name)
    angles=full['angles'];assert len(angles)==16
    t=full['t'];ix=np.searchsorted(t,inp['centers'])
    phi,psi=full['obs'][...,[0,3]].transpose(3,0,1,2)
    basis=np.stack([np.cos(angles),np.sin(angles)])
    def tensor(metric):
        mean=metric.mean(1);cos=2*np.einsum('tar,a->tr',metric,np.cos(2*angles))/len(angles)
        sin=2*np.einsum('tar,a->tr',metric,np.sin(2*angles))/len(angles)
        eye=np.eye(2);diag=np.diag([1.,-1.]);flip=eye[::-1]
        return np.stack((np.einsum('tr,ij->trij',mean,eye),(np.einsum('tr,ij->trij',cos,diag)+np.einsum('tr,ij->trij',sin,flip))/2))
    def odd(values):return (2/len(angles))*np.einsum('ia,ta...->ti...',basis,values)
    bt,vt=np.stack([inp['base_bg'],inp['quad_bg']],axis=1).transpose(2,0,1)
    freq,h=inp['geom'].T;k2=inp['kk']
    def product(m,v):return np.einsum('ltrij,tj->ltir',m,v)
    mm=tensor(phi);ss=tensor(psi);raw=inp['quadr']
    af=np.zeros((4,len(t),2,2),complex);bw=af.copy()
    af[1]=odd(raw[:,:,0])[:,:,None];bw[1]=odd(raw[:,:,1])[:,:,None]
    af[2:]=product(ss+3*mm,vt);bw[2:]=-freq[None,:,None,None]**2*product(ss-3*mm,bt)
    cauchy=inp[grid+'_probe'];ini=np.zeros((2,4,2,2),complex)
    ini[:,0]=(2/len(angles))*np.einsum('ia,axr->xir',basis,cauchy)
    forcing=make_interp_spline(t,np.stack((af,bw)).transpose(2,0,1,3,4),k=5)
    geometry=make_interp_spline(t,inp['geom'],k=5)
    def rhs(tm,state):
        field,mom=state.reshape(2,4,2,2);av,bv=forcing(tm);om,hub=geometry(tm)
        return np.stack((mom+av,-2*hub*mom-(k2+om**2)*field+bv)).ravel()
    sol=solve_ivp(rhs,(t[0],t[-1]),ini.ravel(),t_eval=t,method='DOP853',rtol=4e-13,atol=2e-27,max_step=1/res)
    assert sol.success
    f,w=sol.y.reshape(2,4,2,2,-1).transpose(0,1,4,2,3)
    dot=lambda v,x:np.einsum('ti,ltir->ltr',v,x)/2
    kin=dot(vt,w);pot=dot(bt,f)*(freq**2)[None,:,None];geo=3*dot(vt,product(mm,vt))
    meanq=raw.mean(1)
    explicit=(meanq[:,2]-meanq[:,3])/3
    pp=np.concatenate((kin-pot,geo,(explicit[:,None]+np.zeros((len(t),2)))[None]))
    E=(kin+pot).sum(0)+geo.sum(0)+meanq[:,2,None]
    J=dot(vt,f).sum(0)*k2+meanq[:,4,None]
    vals=np.stack([E,pp.sum(0),J])
    ref=read(parent(f'driven-{grid}-{res}.npz'))
    it=np.searchsorted(ref['t'],inp['centers'])
    refmean=aperture(ref['phase'],ref['values'][0,:3],ref['phase'][it])[0];brute=full['stress'][ix,:,:,:3].mean(1).transpose(2,0,1)
    delta=vals[:,ix]-brute;truth=drift(refmean)
    err=rate(drift(delta),truth)
    own=rate(drift(vals[:,ix]-refmean),truth)
    change=drift(pp[:,ix]);pnum=truth[1]
    part=change[:,-1]/pnum[-1]
    pack(f'moments-{tag}-{grid}-{res}.npz',t=t,centers=inp['centers'],field=f,momentum=w,pressure_pieces=pp,values=vals,reference_mean=refmean)
    out=dict(grid=grid,res=res,solver_vs_sixteen_drift_pct_of_true=err.tolist(),temporal_drift_error_pct=own.tolist(),replay_level_pct=rate(delta,refmean).tolist(),
        pressure_term_pct=rate(change,pnum).tolist(),pressure_endpoint_signed_real=part.real.tolist(),pressure_endpoint_signed_imag=part.imag.tolist())
    print(tag,grid,res,'direct/reduced drift difference pct of physical',np.round(err.max(-1),5),'P temporal errors',np.round(own[1],4),flush=True)
    return out
if __name__=='__main__':
    tag=sys.argv[1];rows=[solve(tag,g,r) for g in ('p16','p32') for r in (640,1280)]
    put('moments-'+tag+'.json',dict(rows=rows,solver=sha(ROOT/'moment_readout.py'),terms=['incoming homogeneous','microscopic driven','mean metric driven','second harmonic metric driven','direct mean Phi','direct second harmonic Phi','quadratic pressure'],channels=['mean energy','mean pressure','mean current']))
