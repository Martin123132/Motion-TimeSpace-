import past_legs as driver
from phasegrav_io import *
import inspect

def run():
    check('past-method.json')
    code=inspect.getsource(driver.run)
    key="    which='sine_seed"
    assert code.count(key)==1
    code=code.replace(key,"    assert code.count('real=advance(CUT,ts[-1],')==1\n    code=code.replace('real=advance(CUT,ts[-1],','real=advance(CUT,time[np.flatnonzero(ok)[-1]],')\n"+key)
    ctx=dict(driver.__dict__);exec(compile(code,'same physical solve span for bitwise anchor','exec'),ctx)
    for res in (640,1280):
        for degree in (0,4):
            name=f'past-legs-{degree}-{res}.npz'
            if not (ROOT/name).exists():ctx['run'](res,degree)
            data=read(ROOT/name);inp=read(ROOT/(f'micro-4-{res}.npz' if degree else f'angles-{res}.npz'))
            assert np.array_equal(data['bg'][-1],inp['quad_bg'][0]) and data['anchor_error'].max()<1e-11
    receipt('past-freeze.json',[ROOT/'past-method.json',ROOT/'stitch_past.py',*sorted(ROOT.glob('past-legs-*.npz'))])
if __name__=='__main__':run()
