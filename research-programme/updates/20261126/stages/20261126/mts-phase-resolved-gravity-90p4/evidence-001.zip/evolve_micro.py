from native_io import *
import gravity_phase as engine
import score_gravity as sc, moment_readout as mr, propagation as cp
from unittest.mock import patch

def overlay_inputs(grid,res,earlier):
    inp=read(ROOT/f'angles-{res}.npz');car=read(ROOT/f'carried-{grid}-{res}.npz');part=read(ROOT/f'micro-4-{res}.npz');past=read(ROOT/f'micro-past-{grid}-{res}.npz')
    inp.update(quadr=part['quadr'],quad_bg=part['quad_bg'])
    for key in ('native','probe'):inp[grid+'_'+key]=car[key]
    for key in ('mean','lag_current'):inp[grid+'_'+key]=past[key]
    return inp,past['Y'][earlier].reshape(-1)
def run(grid,res,earlier,label):
    name=f'solved-{label}-{grid}-{res}.npz';done=name+'.receipt'
    if (ROOT/done).exists():check(done);return
    inp,y=overlay_inputs(grid,res,earlier)
    code=(ROOT/'gravity_phase.py').read_text();key='state[3][:,1]=derived';assert code.count(key)==1
    alt=dict(engine.__dict__,__name__='micro_bath',incoming_y=y)
    exec(compile(code.replace(key,'state[3][:,1]=incoming_y'),str(ROOT/'gravity_phase.py')+'[microscopic preparation]','exec'),alt)
    def output(other,**data):
        assert other==f'solved-geometry_U-{grid}-{res}.npz';pack(name,**data)
    alt['read']=lambda path:inp if path==ROOT/f'angles-{res}.npz' else read(path)
    alt['pack']=output;alt['predict'](grid,res,'geometry_U')
    receipt(done,[ROOT/name,ROOT/'evolve_micro.py',ROOT/'gravity_phase.py',ROOT/'micro-past-freeze.json',ROOT/'U-freeze.json'])
def score(label,earlier):
    receipts=[ROOT/f'solved-{label}-{g}-{r}.npz.receipt' for g in ('p16','p32') for r in (640,1280)]
    receipt('forecast-'+label+'.json',[ROOT/'micro-past-freeze.json',ROOT/'U-freeze.json',*receipts])
    rows=[];moment=[];prop=[]
    for g in ('p16','p32'):
        for r in (640,1280):
            rows.append(sc.scores(label,g,r));inp,_=overlay_inputs(g,r,earlier)
            with patch.object(mr,'read',lambda path:inp if path==ROOT/f'angles-{r}.npz' else read(path)):moment.append(mr.solve(label,g,r))
            prop.append(cp.diagnostic(label,g,r))
    put(label+'-result.json',dict(full=rows,reduced=moment,constraint=prop,gate_pct=.5,forecast=sha(ROOT/('forecast-'+label+'.json')),scorer=sha(ROOT/'evolve_micro.py')))
if __name__=='__main__':
    check('micro-past-freeze.json');assert sys.argv[1] in ('primary','control')
    earlier=int(sys.argv[1]=='control');label='micro_live' if earlier==0 else 'micro_one'
    for g in ('p16','p32'):
        for r in (640,1280):run(g,r,earlier,label)
    score(label,earlier)
