from native_io import *
from scipy.integrate import solve_ivp
def run(grid,res,p):
    inp=read(ROOT/f'angles-{res}.npz');carry=read(ROOT/f'carried-{grid}-{res}.npz')
    priors=[read(ROOT/f'past-legs-{d}-{res}.npz') for d in (0,4)]
    t=priors[0]['t'];assert np.array_equal(t,priors[1]['t']) and t[-1]==ANCHOR
    hist=read(parent(f'history-{grid}.npz'));mem=read(parent(f'memory-{grid}.npz'));kk=float(hist['k'])**2
    host=p.Host(grid,4);m=hist['m'].item();rho0=hist['rho0'].item()
    actual=CubicSpline(hist['t'],hist['states'][:,:2,0])(t)
    phi,psi=CubicSpline(hist['t'],hist['metric'])(t).transpose(2,0,1)[:2]
    tt=[];ep=[]
    for path in [old.pin(old.PREFIX,f'{key}-{grid}-4.npz') for key in ('second','third','fourth','partial')]+[old.pin(old.MID,f'carry-matched-{grid}-4.npz')]:
        with np.load(path) as ar:
            sl=slice(int(bool(tt)),None);tt.extend(ar['t'][sl]);ep.extend(ar['obs'][sl,:2,1])
    ep=CubicSpline(tt,ep)(t)
    early=t<=89.6;hh=np.zeros_like(t);aa=hh.copy()
    h,m2,_,_=host.osc(t[early]);hh[early]=h;aa[early]=np.sqrt(m2)/m
    later=host.flow.bg(np.log(t[~early]));hh[~early]=later[:,host.flow.bgkeys.index('h')];aa[~early]=later[:,host.flow.bgkeys.index('a')]
    om2=(m*aa)**2;geom=make_interp_spline(t,np.stack((hh,om2,aa),axis=1),k=5)
    ang=inp['angles'];co=np.cos(ang);si=np.sin(ang);ext=host.external(np.log(t))[:,:2]
    oldq=priors[0]['q'];dq=priors[1]['q']-oldq;assert np.count_nonzero(dq[:,0])==0
    bo=actual[:,:1]*co+priors[0]['bg'][:,:1]*si;vo=actual[:,1:]*co+priors[0]['bg'][:,1:]*si
    db=(priors[1]['bg'][:,:1]-priors[0]['bg'][:,:1])*si
    dv=(priors[1]['bg'][:,1:]-priors[0]['bg'][:,1:])*si
    uf,uw=(oldq[:,:,:2]+co[None,:,None]*(ext-oldq[:,0,:2])[:,None]).transpose(2,0,1)
    combo=(psi+3*phi)[:,None];diff=(psi-3*phi)[:,None]
    drives=np.stack([vo[:,:,None]*combo+uf[:,:,None],-om2[:,None,None]*bo[:,:,None]*diff+uw[:,:,None],
                      dv[:,:,None]*combo+dq[:,:,0,None],-om2[:,None,None]*db[:,:,None]*diff+dq[:,:,1,None]],axis=1)
    rawdrv=make_interp_spline(t,drives,k=5)
    ends=inp[grid+'_lag_phase'];phase=np.linspace(ends[-1]-3*np.pi,ends[-1],577)
    clock=CubicSpline(mem['theta'],mem['t'])(phase);clock[-1]=ANCHOR
    cauchy=carry['native'].transpose(1,0,2);seed=np.concatenate((cauchy,cauchy*0))
    def eq(at,vec):
        field,mom,df,dw=vec.reshape(seed.shape);hub,mu2,_=geom(at)
        av,bw,da,db=rawdrv(at)
        return np.stack((mom+av,-2*hub*mom-(kk+mu2)*field+bw,dw+da,-2*hub*dw-(kk+mu2)*df+db)).ravel()
    sol=solve_ivp(eq,(ANCHOR,clock[0]),seed.ravel(),t_eval=clock[::-1],rtol=5e-13,atol=5e-30,max_step=1/res,method='DOP853')
    assert sol.success
    field,mom,df,dw=sol.y[:,::-1].reshape(*seed.shape,-1).transpose(0,3,1,2)
    interp=lambda arr:make_interp_spline(t,arr,k=5)(clock)
    hub,mu2,a=geom(clock).T;rho=rho0/a
    ov,ob,dv,db=(interp(v)[:,:,None] for v in (vo,bo,dv,db))
    src=interp(dq)
    dj=(kk*(ov*df+dv*(field+df))+src[:,:,4,None])/rho[:,None,None]
    de=(ov*dw+dv*(mom+dw)+mu2[:,None,None]*(ob*df+db*(field+df))+src[:,:,2,None])/rho[:,None,None]
    geometrical=3*dv*(2*ov+dv)*interp(ep)[:,None]/rho[:,None,None]
    prim=CubicSpline(phase,dj).antiderivative();q=phase[192:];delta_m=(prim(q)-prim(np.maximum(phase[0],q-np.pi)))/np.pi
    hp=geom(clock,1)[:,0];coef=-1+3*(hp-hub**2)/kk
    derivative=coef[192:,None,None]*(delta_m-dj[192:]);anti=CubicSpline(clock[192:],derivative).antiderivative()
    changes=np.stack([-(de[idx]+3*hub[idx]*dj[idx]/kk+geometrical[idx])+anti(clock[-1])-anti(clock[idx]) for idx in (192,384)])
    assert np.max(abs(changes[:,0]))==0 and np.max(abs(dj[:,0]))==0
    pack(f'micro-past-{grid}-{res}.npz',Y=carry['Y']+changes,delta_Y=changes,mean=carry['mean']+delta_m[-1],
        lag_current=carry['lag_current']+CubicSpline(phase,dj)(np.clip(ends,phase[0],phase[-1])),prior_t=clock,delta_current=dj,prior_times=clock[[192,384]])
if __name__=='__main__':
    check('past-freeze.json');check('carried-freeze.json')
    p=historic.pre.import_at(historic.pre.OLD,'partial')
    for grid in ('p16','p32'):
        for res in (640,1280):run(grid,res,p)
    receipt('micro-past-freeze.json',[ROOT/'DYNAMICAL-MICRO.md',ROOT/'micro_memory.py',ROOT/'past-freeze.json',ROOT/'carried-freeze.json',*sorted(ROOT.glob('micro-past-*.npz'))])
