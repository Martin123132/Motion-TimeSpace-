from native_io import *
import gravity_phase as engine
from unittest.mock import patch

def given(grid,res):
    a=read(ROOT/f'angles-{res}.npz');p=read(ROOT/f'carried-{grid}-{res}.npz')
    for key in ('native','probe','mean','lag_current'):
        a[grid+'_'+key]=p[key]
    return a,p
def run(grid,res,earlier):
    label=('carried' if earlier==0 else 'one_period')
    name=f'solved-{label}-{grid}-{res}.npz';done=name+'.receipt'
    if (ROOT/done).exists():check(done);return
    inputs,data=given(grid,res)
    def overlay(path):
        if path==ROOT/f'angles-{res}.npz':return inputs
        return read(path)
    def output(oldname,**values):
        assert oldname==f'solved-geometry_U-{grid}-{res}.npz'
        pack(name,earlier=data['earlier_times'][earlier],**values)
    source=(ROOT/'gravity_phase.py').read_text()
    key='state[3][:,1]=derived'
    assert source.count(key)==1
    source=source.replace(key,'state[3][:,1]=carried_Y')
    space=dict(engine.__dict__,__name__='carried_gravity_equations',read=overlay,pack=output,carried_Y=data['Y'][earlier].reshape(-1))
    exec(compile(source,str(ROOT/'gravity_phase.py')+'[carried Y]', 'exec'),space)
    space['read']=overlay;space['pack']=output
    space['predict'](grid,res,'geometry_U')
    receipt(done,[ROOT/name,ROOT/'evolve_carried.py',ROOT/'gravity_phase.py',ROOT/'carried-freeze.json',ROOT/'U-freeze.json'])
if __name__=='__main__':
    check('carried-freeze.json');assert sys.argv[1] in ('primary','control')
    for grid in ('p16','p32'):
        for res in (640,1280):run(grid,res,int(sys.argv[1]=='control'))
