from score_gravity import *
def evaluate(grid,res):
    tested=read(ROOT/f'incoming-{grid}-{res}.npz')
    results=[]
    for tag in ('matter','geometry_U'):
        live=read(ROOT/f'moments-{tag}-{grid}-{res}.npz')
        ix=np.searchsorted(live['t'],live['centers'])
        ref=live['reference_mean'];unit=drift(ref)
        base=live['values'][:,ix]
        fixed=base+tested['shifts'][:,:,ix,:]
        levels=rate(fixed-ref,ref);changes=rate(drift(fixed-ref),unit)
        spread=[rate(drift(row-fixed[0]),unit).tolist() for row in fixed[1:]]
        results.append(dict(tag=tag,before_pct=rate(drift(base-ref),unit).tolist(),after_pct=changes.tolist(),after_levels_pct=levels.tolist(),control_spread_pct=spread))
    print(grid,res,'metric U pressure changes',np.round(changes[:,1],5),'cond',tested['stats'][:,0].round(0),'incoming error %',np.max(tested['stats'][:,1:],axis=1),flush=True)
    return dict(grid=grid,res=res,rows=results,past_checks=tested['stats'].tolist())
if __name__=='__main__':
    check('incoming-freeze.json')
    put('incoming-scores.json',dict(freeze=sha(ROOT/'incoming-freeze.json'),variants=['primary 4pi 4/2/1','width 3.5pi','degrees 5/3/2'],scorer=sha(ROOT/'score_incoming.py'),rows=[evaluate(g,r) for g in ('p16','p32') for r in (640,1280)]))
