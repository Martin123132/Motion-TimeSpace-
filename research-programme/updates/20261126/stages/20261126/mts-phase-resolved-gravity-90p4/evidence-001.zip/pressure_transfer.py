from phasegrav_io import *
from scipy.integrate import solve_ivp

def pressure_budget(grid,res,tag):
    oldsolve=read(ROOT/f'solved-matter-{grid}-{res}.npz')
    system=read(ROOT/f'solved-{tag}-{grid}-{res}.npz') if tag!='pastmetric' else oldsolve
    inputs=read(ROOT/f'angles-{res}.npz');t=inputs['t'];ref=read(parent(f'driven-{grid}-{res}.npz'))
    k2=inputs['kk'];angles=inputs['angles'];nc=len(angles)
    ts=ref['t'];angle=ref['phase'];ix=np.searchsorted(ts,t);assert np.array_equal(t,ts[ix])
    samp=np.searchsorted(t,inputs['centers']);co=np.cos(angles);si=np.sin(angles)
    b=inputs['base_bg'][:,0,None]*co+inputs['quad_bg'][:,0,None]*si
    v=inputs['base_bg'][:,1,None]*co+inputs['quad_bg'][:,1,None]*si
    freq,h=inputs['geom'].T
    base=oldsolve['obs'][:,:,:,[0,3]]
    if tag=='pastmetric':
        metric=ref['metric'][:,:,:2]
        test=np.stack([metric[ix] if i==0 else orbit.causal_values(angle,metric,angle[ix],g,3,False) for i,g in enumerate(angles)],axis=1)
        target=read(parent(f'orbit-{res}.npz'))['values'][int(grid=='p32'),1,1,1].transpose(0,1,2)
    else:
        test=system['obs'][:,:,:,[0,3]];target=system['stress'][samp,:,:,1]
    dp=test[...,0]-base[...,0];slip=(test[...,1]-test[...,0])-(base[...,1]-base[...,0])
    aa=np.stack([4*v[:,:,None]*dp,v[:,:,None]*slip],axis=1)
    bb=freq[:,None,None,None]**2*np.stack([2*b[:,:,None]*dp,-b[:,:,None]*slip],axis=1)
    drives=make_interp_spline(t,np.stack([aa,bb],axis=1),k=5)
    geom=make_interp_spline(t,np.stack([freq**2,h],axis=1),k=5)
    def eq(at,state):
        field,mom=state.reshape(2,2,nc,2);af,bw=drives(at);om2,hub=geom(at)
        return np.stack([mom+af,-2*hub*mom-(k2+om2)*field+bw]).ravel()
    traj=solve_ivp(eq,(t[0],t[-1]),np.zeros(8*nc,complex),t_eval=t,method='DOP853',atol=1e-29,rtol=2e-12,max_step=1/res)
    assert traj.success
    df,dw=traj.y.reshape(2,2,nc,2,-1).transpose(0,1,4,2,3)
    pressure=v[None,:,:,None]*dw-(freq**2)[None,:,None,None]*b[None,:,:,None]*df
    direct=3*v[:,:,None]**2*dp
    signed=np.stack([pressure[0],pressure[1],direct])[:,samp]
    reference=aperture(ref['phase'],ref['values'][0,1:2],ref['phase'][ix[samp]])[0,0]
    dif=target-oldsolve['stress'][samp,:,:,1]
    unit=drift(reference)
    err=rate(drift(signed.mean(2).sum(0)-dif.mean(1)),unit)
    pend=drift(signed.mean(2))[:,-1]/unit[-1]
    result=dict(grid=grid,res=res,tag=tag,work_pct_of_measured_drift=rate(drift(signed.mean(2)),unit).tolist(),
        actual_metric_change_pct_of_measured_drift=rate(drift(dif.mean(1)),unit).tolist(),replay_error_pct_of_measured_drift=err.tolist(),
        signed_endpoint_real=pend.real.tolist(),signed_endpoint_imag=pend.imag.tolist(),
        target_pressure_error_pct=rate(drift(target.mean(1)-reference),unit).tolist())
    print(tag,grid,res,'response pieces',np.around(result['work_pct_of_measured_drift'],3),'response vs changed solution',np.around(err,5),flush=True)
    return result
if __name__=='__main__':
    tag=sys.argv[1]
    ans=[pressure_budget(grid,res,tag) for grid in ('p16','p32') for res in (640,1280)]
    put('transfer-'+tag+'.json',dict(rows=ans,terms=['retarded Phi','retarded slip','instantaneous Phi'],scorer=sha(ROOT/'pressure_transfer.py'),
        meaning='Finite signed metric intervention from common native-source phase solution with identical incoming probe fields. pastmetric is the earlier data-conditioned diagnostic, not an Einstein solution.'))
