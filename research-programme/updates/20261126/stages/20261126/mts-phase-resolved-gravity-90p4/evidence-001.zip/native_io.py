from pathlib import Path
import hashlib,sys,json
from io import BytesIO
from functools import lru_cache
ROOT=Path(__file__).resolve().parent
BASE=ROOT.parent
PARENT=BASE/'mts-total-phase-stress-90p4-20261126'
def sha(path):
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
assert sha(PARENT/'seal.json')=='552d5ba956a576eb651473abfc3f44ae03b63c9db0dcae257513749071472630'
members=json.loads((PARENT/'seal.json').read_bytes())['files']
@lru_cache()
def parent(name):
    path=PARENT/name;assert sha(path)==members[name];return path
for name in ('historic_replay.py','data_io.py'):parent(name)
sys.path.insert(0,str(PARENT))
import historic_replay as historic,data_io as old
from data_io import np,read
from scipy.interpolate import make_interp_spline,CubicSpline
ANCHOR=89.65
def guard():
    old.guard();assert not (ROOT/'STOP-REQUESTED').exists()
def save(name,raw):old.save(ROOT/name,raw)
def put(name,obj):save(name,(json.dumps(obj,indent=2,sort_keys=True,allow_nan=False,default=lambda v:v.item())+'\n').encode())
def pack(name,**fields):
    buf=BytesIO();np.savez_compressed(buf,**fields);save(name,buf.getvalue())
def receipt(name,files):
    guard();put(name,{p.relative_to(BASE).as_posix():sha(p) for p in files})
def check(name):
    for key,sig in json.loads((ROOT/name).read_bytes()).items():assert sha(BASE/key)==sig,key
