from evolve_micro import *
def generate(grid,res):
    inp,y=overlay_inputs(grid,res,0);name=f'combined-{grid}-{res}.npz';done=name+'.receipt'
    if (ROOT/done).exists():check(done);return
    code=(ROOT/'gravity_phase.py').read_text()
    def replace(origin,after):
        nonlocal code
        assert code.count(origin)==1,origin;code=code.replace(origin,after)
    replace('if init:return 2*(raw-denom*shadows[:,0])/rho[i],j',"""fieldpart=va*fields[:,11]+(m2[i]*ba+3*h[i]*va)*fields[:,10]
            if init:return 2*(raw-denom*shadows[:,0])/rho[i],j,fieldpart,rho[i]""")
    replace('ep=(raw-rho[i]*memory[:,1]/2)/denom',"""rhoY=memory[:,1]-fieldpart
            qej=qext[i,2]+de+3*h[i]*(qext[i,3]+dj)/kk
            other=fields.copy();other[:,10:12]=0
            oe=other@we[i]+e0[i]-qext[i,2]+st[:,0]
            oj=other@wj[i]+j0[i]-qext[i,3]+st[:,1]
            ep=(source-(oe+3*h[i]*oj/kk+memory[:,1]+qej)/2)/denom""")
    replace('if measure:\n                kinetic',"""gv=-1+3*(hp[i]-h[i]**2)/kk
            Rv=(2*(h[i]-oldgeom[n,1])*quarter[n,1]+(m2[i]-oldgeom[n,0]**2)*quarter[n,0])*si
            zterms=np.stack((-h[i]*memory[:,1],gv*(rho[i]*memory[:,0]-qext[i,3]-dj),6*m2[i]*ba*va*phi,3*h[i]*va**2*(psi+3*phi),
                va*(qext[i,1]+dw),(m2[i]*ba+3*h[i]*va)*(qext[i,0]+df),(rate_a[i]-h[i])*(2*m2[i]*ba*fields[:,10]-rhoY),Rv*(fields[:,11]+3*h[i]*fields[:,10])),axis=-1)
            if measure:
                kinetic""")
    replace('base_e+rho[i]*(memory[:,1]-3*h[i]*delta/kk)','base_e+rhoY-3*h[i]*rho[i]*delta/kk')
    replace('return obs,values,j,virt','return obs,values,j,np.column_stack((virt,memory[:,1],rhoY/rho[i],qej,zterms,oe,oj))')
    replace('(-1+3*(hp[i]-h[i]**2)/kk)*delta','zterms.sum(-1)')
    replace('derived,wave_j=rhs(0,state,init=True)','derived,wave_j,partial,rho_entry=rhs(0,state,init=True)')
    replace('state[3][:,1]=derived','state[3][:,1]=incoming_y')
    replace('pre_Y=np.column_stack((derived,state[3][:,1]))','pre_Y=np.column_stack((derived,state[3][:,1]));state[3][:,1]=partial+rho_entry*state[3][:,1]')
    ns=dict(engine.__dict__,__name__='Z_transport',incoming_y=y)
    exec(compile(code,'77-bin solver with Z replacing Y','exec'),ns)
    ns['read']=lambda path:inp if path==ROOT/f'angles-{res}.npz' else read(path)
    def capture(oldname,**result):
        assert oldname==f'solved-geometry_U-{grid}-{res}.npz'
        calc=result.pop('virial')
        pack(name,**result,physical_virial=calc[...,:7],Z=calc[...,7],Y=calc[...,8],explicit_q=calc[...,9],dZ_terms=calc[...,10:18],ordinary_energy=calc[...,18],ordinary_current=calc[...,19])
    ns['pack']=capture;ns['predict'](grid,res,'geometry_U')
    receipt(done,[ROOT/name,ROOT/'combined_load.py',ROOT/'COMBINED-LOAD.md',ROOT/'micro-past-freeze.json',ROOT/'forecast-micro_live.json',ROOT/'gravity_phase.py'])
if __name__=='__main__':
    for g in ('p16','p32'):
        for r in (640,1280):generate(g,r)
    receipt('Z-freeze.json',[ROOT/'COMBINED-LOAD.md',ROOT/'combined_load.py',*sorted(ROOT.glob('combined-*.npz.receipt'))])
