from prepare_micro import *

def run(res,degree):
    code=inspect.getsource(orbit.leg_bank)
    for before,after in [('centers=np.flatnonzero(ok);end=centers[-1]+1;ts=time[anchor:end]','centers=np.array([anchor]);end=anchor+1;ts=time[:end]'),
        ('quarter=advance(ANCHOR,ts[-1],quadrature(sp,phase[anchor],4),ts)','quarter=advance(ANCHOR,ts[0],chosen,ts[::-1])[::-1]'),
        ('real=real[anchor:]','real=real[:end]'),("a['q'][0,:,anchor:end]","a['q'][0,:,:end]")]:
        assert code.count(before)==1
        code=code.replace(before,after)
    which='sine_seed(time[:anchor+1],phase[:anchor+1],real[:anchor+1],rhs,4)' if degree else 'quadrature(sp,phase[anchor],4)'
    code=code.replace('ts[0],chosen,ts[::-1]','ts[0],'+which+',ts[::-1]')
    ctx=dict(orbit.__dict__,sine_seed=sine_seed)
    exec(compile(code,'signed prior incoming leg evolution','exec'),ctx)
    time,phase,anchor,end,centers,first,qq,basis=ctx['leg_bank'](res)
    inputs=read(ROOT/(f'micro-4-{res}.npz' if degree else f'angles-{res}.npz'))
    ang=inputs['angles'];cs=np.cos(ang);sn=np.sin(ang);raw=qq.transpose(0,2,1)
    q=raw[0,:,None]*cs[None,:,None]**2+raw[1,:,None]*sn[None,:,None]**2+(raw[2]-(raw[0]+raw[1])/2)[:,None,:]*np.sin(2*ang)[None,:,None]
    q[:,:,:2]=raw[0,:,None,:2]*cs[None,:,None]+raw[1,:,None,:2]*sn[None,:,None]
    err=np.max(abs(q[-1]-inputs['quadr'][0]),axis=0)/np.max(abs(inputs['quadr'][0]),axis=0)
    assert err.max()<1e-11 and np.array_equal(basis[1,-1],inputs['quad_bg'][0])
    pack(f'past-legs-{degree}-{res}.npz',t=time[:end],q=q,bg=basis[1],anchor_error=err)
if __name__=='__main__':
    check('micro-readout-freeze.json')
    receipt('past-method.json',[ROOT/'past_legs.py',ROOT/'DYNAMICAL-MICRO.md',ROOT/'micro-freeze.json',ROOT/'micro-scores.json'])
    for res in (640,1280):
        for degree in (0,4):run(res,degree)
    receipt('past-freeze.json',[ROOT/'past-method.json',*sorted(ROOT.glob('past-legs-*.npz'))])
