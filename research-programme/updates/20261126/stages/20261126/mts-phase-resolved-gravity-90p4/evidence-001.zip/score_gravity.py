from native_io import *
parent('score_total.py')
from score_total import aperture,rate,drift,peak

def fourier(values,n):
    angles=np.pi*np.arange(n)/n;part=values[:,:,::values.shape[2]//n]
    basis=np.stack([angles*0+1,2*np.cos(2*angles),2*np.sin(2*angles)])
    return np.einsum('ha,jcar->hjcr',basis,part)/n

def physical_work(first,ref,idx):
    freq,hub,back,vel=first['bg'][:4,:,None];field,mom=ref['state'][0]
    phi,psi=ref['metric'].transpose(2,0,1)[:2];kk=ref['k']**2
    aa=vel*(psi+3*phi)+first['q'][0,0,:,None]
    bb=-freq**2*back*(psi-3*phi)+first['q'][0,1,:,None]
    prod=(vel*field+back*mom)/2
    slope=((-2*hub*vel-freq**2*back)*field+vel*(mom+aa)+vel*mom+back*(-2*hub*mom-(kk+freq**2)*field+bb))/2
    terms=np.stack((slope,2*hub*prod,kk*back*field/2,-vel*aa/2,-back*bb/2,3*vel**2*phi,ref['pieces'][0,1]))
    return aperture(ref['phase'],terms,ref['phase'][idx])[0]

def scores(tag,grid,res):
    name=f'solved-{tag}-{grid}-{res}.npz';check(name+'.receipt')
    packet=read(ROOT/name);angles=read(ROOT/f'angles-{res}.npz');first=read(parent(f'first-{res}.npz'));ref=read(parent(f'driven-{grid}-{res}.npz'))
    t=packet['t'];centers=angles['centers'];ix=np.searchsorted(t,centers);it=np.searchsorted(ref['t'],centers)
    assert np.array_equal(t[ix],ref['t'][it])
    pressure=ref['values'][0,1];truth=aperture(ref['phase'],ref['values'][0],ref['phase'][it])
    mtruth=aperture(ref['phase'],ref['metric'][:,:,:2].transpose(2,0,1),ref['phase'][it])
    means=[];step=rate
    for count in (4,8,16):
        model=fourier(packet['stress'][ix].transpose(3,0,1,2),count)
        diff=model-truth
        phi=fourier(packet['obs'][ix][:,:,:,[0,3]].transpose(3,0,1,2),count)
        md=phi-mtruth
        means.append(dict(angles=count,level_pct=rate(diff,truth).tolist(),drift_pct=rate(drift(diff),drift(truth)).tolist(),
            metric_level_pct=rate(md,mtruth).tolist(),metric_drift_pct=rate(drift(md),drift(mtruth)).tolist()))
    prod=packet['virial'][:,:,:,0]
    terms=packet['virial'].copy()
    terms[:,:,:,0]=make_interp_spline(t,prod,k=7)(t,1)
    predicted=terms[ix].mean(axis=1).transpose(2,0,1);target=physical_work(first,ref,it)
    error=drift(predicted-target);norm=drift(truth[0,1]);endpoint=error[:,-1]/norm[-1]
    intrinsic=rate(drift(predicted.sum(0)-model[0,1]),norm)
    comp=dict(predicted_terms_signed_endpoint_real=(drift(predicted)[:,-1]/norm[-1]).real.tolist(),relative_signed_error_real=endpoint.real.tolist(),
        relative_signed_error_imag=endpoint.imag.tolist(),errors_pct_of_pressure_change=rate(error,norm).tolist(),virial_derivative_discrepancy_pct_of_pressure_change=intrinsic.tolist())
    pre=packet['obs'][0];end=packet['obs'][ix[-1]]
    closure=[]
    for what in (pre,end):
        diff=what[:,:,1]-what[:,:,2]
        absolute=100*np.max(abs(diff),axis=0)/np.max(abs(what[:,:,0]),axis=0)
        contrast=100*np.max(abs(diff-diff[0]),axis=0)/np.maximum(1e-50,np.max(abs(what[:,:,0]-what[:1,:,0]),axis=0))
        closure.append(dict(shadow_pct_of_potential=absolute.tolist(),shadow_pct_of_angular_signal=contrast.tolist()))
    real=read(ROOT/f'solved-native-{grid}-{res}.npz')
    a=packet['obs'][:,0];b=real['obs'][:,0]
    zero_check=100*np.max(abs(a-b),axis=0)/np.max(abs(b),axis=0)
    assert np.max(zero_check)<1.e-7
    print(tag,grid,res,'mean drift max/levels',np.array(means[-1]['drift_pct'])[0].max(-1).round(4),np.array(means[-1]['level_pct'])[0].max(-1).round(5),'metric harmonics',np.array(means[-1]['metric_level_pct']).max((1,2)).round(5),'P error term sizes',np.amax(comp['errors_pct_of_pressure_change'],axis=1).round(2),flush=True)
    return dict(grid=grid,res=res,angles=means,terms=comp,entry_and_last_shadow=closure,physical_replay_vectorization_pct=zero_check.tolist(),
        mean_pressure_8_vs_16_pct=rate(drift(fourier(packet['stress'][ix].transpose(3,0,1,2),8)[0,1]-model[0,1]),norm).tolist())
if __name__=='__main__':
    tag=sys.argv[1];names=[ROOT/f'solved-{tag}-{g}-{r}.npz.receipt' for g in ('p16','p32') for r in (640,1280)]
    receipt(tag+'-freeze.json',[ROOT/'PROTOCOL.md',ROOT/'preparation-freeze.json',ROOT/'gravity_phase.py',*names])
    rows=[scores(tag,grid,res) for grid in ('p16','p32') for res in (640,1280)]
    put(tag+'-scores.json',dict(freeze=sha(ROOT/(tag+'-freeze.json')),scorer=sha(ROOT/'score_gravity.py'),criterion_pct=.5,keys=['energy','pressure','current','shear','constraint','flat_energy','normalized_current'],rows=rows))
