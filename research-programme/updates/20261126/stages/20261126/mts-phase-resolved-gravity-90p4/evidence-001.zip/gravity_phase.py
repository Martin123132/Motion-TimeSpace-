from native_io import *
from unittest.mock import patch

class Memory:
    def __init__(self,phase,current):
        self.phase=phase.copy();self.current=current.copy()
    def read(self,query):
        assert query.min()>=self.phase[0]-2e-9 and query.max()<=self.phase[-1]+2e-9
        return CubicSpline(self.phase,self.current,extrapolate=False)(np.clip(query,self.phase[0],self.phase[-1]))
    def append(self,phase,current):
        assert abs(self.phase[-1]-phase[0])<2e-8
        self.phase=np.r_[self.phase,phase[1:]]
        self.current=np.concatenate((self.current,current[1:]))

def predict(grid,res,intervention='matter'):
    guard();check('preparation-freeze.json')
    inputs=read(ROOT/f'angles-{res}.npz');time=inputs['t'];ang=inputs['angles'];kk=inputs['kk'].item();routes=2;count=len(ang)
    if intervention=='native':sel=[0]
    else:sel=list(range(count))
    width=len(sel)*routes
    zeros=np.zeros(width,dtype=complex);co=np.repeat(np.cos(ang[sel]),routes);si=np.repeat(np.sin(ang[sel]),routes)
    mom=np.tile([True,False],len(sel))
    first=lambda key:inputs[grid+'_'+key]
    clocks=np.linspace(time[0],time[-1],2*len(time)-1)
    rawq=make_interp_spline(time,inputs['quadr'],k=5)(clocks)
    def interpolate(key):return make_interp_spline(time,inputs[key],k=5)(clocks)
    original=interpolate('base_bg');quarter=interpolate('quad_bg');oldgeom=interpolate('geom')
    arrays={};controls={};KK=kk
    io=historic.io
    for name in ('stepper.py','sources90.py'):old.pin(old.LATE,name)
    import sources90 as srcmod
    part=historic.pre.import_at(historic.pre.OLD,'partial')
    bank=part.MatchedBank()
    def verify_osc(name,**data):
        previous=read(old.pin(old.LATE,name))
        assert previous.keys()==data.keys() and all(np.array_equal(previous[k],v) for k,v in data.items())
    with patch.object(srcmod,'pack',verify_osc):
        src,hist=srcmod.setup(part,grid,4,'matched',bank)
    assert np.isclose(kk,src.kk,atol=0,rtol=3e-12)
    kk=src.kk
    wave=part.old.Wave(src);oldm=part.old
    restart=read(old.pin(old.MID,f'carry-matched-{grid}-4.npz'))
    routefield=np.tile(restart['final'][:2],(len(sel),1));routefield[:,10:12]=first('native')[sel].transpose(0,2,1).reshape(width,2)
    shadows=first('shadows')[sel].reshape(width,2)
    routefield[:,12]=shadows[:,1]
    lag=np.tile(restart['final_lag'][:2],(len(sel),1,1));assert lag.shape==(width,77,69)
    shape=restart['final_shape'].copy()
    means=first('mean')[sel].reshape(width);probe=first('probe')[sel].transpose(0,2,1).reshape(width,2)
    memories=np.column_stack((means,zeros));state=[routefield,lag,shape,memories,probe]
    delay=Memory(first('lag_phase'),first('lag_current')[:,sel].reshape(-1,width))
    addU=0*clocks[:,None]
    if intervention in ('geometry','geometry_U','geometry_Fq','geometry_slip'):
        srcdata=read(ROOT/f'exterior-{grid}-{res}.npz')
        assert np.array_equal(srcdata['t'],clocks)
        restored={k:np.repeat(srcdata[k][:,sel],routes,axis=1) for k in ('U','Fq','slip')}
        addU=restored['U'] if intervention in ('geometry','geometry_U') else addU
    def argterm(name,index):
        active=intervention=='geometry' or intervention=='geometry_'+name
        if not active:return 0
        return restored[name][index]
    def setup(begin,stop):
        half=slice(2*begin,2*stop+1);clock=clocks[half];log=np.log(clock)
        vel,slow,kernel,weights=bank.coeff(clock);micro=bank.micro(log);spectral=bank.sw(log)
        mat,one,two=oldm.operator(wave,clock,clock)
        mat[:,:13,oldm.QI]+=one;mat[:,:13,oldm.QN]+=two
        matrix=np.ascontiguousarray(mat[:,:,:oldm.DIM].transpose(0,2,1));bias=mat[:,:,-1]
        bg,den,we,wj,e0,j0,slip,us,fq=part.coefficients(src,clock)
        h=bg['h'];eg=bg['eg'];nus=4*bg['er']+bg['nuS'];v0=bg['hv'];b0=bg['hb'];m2=(bg['a']*bg['hm'])**2
        logr=np.log(bg['a']);rate_a=src.flow.bg(log,1)[:,src.flow.bgkeys.index('a')]/(clock*bg['a'])
        hp=src.flow.bg(log,1)[:,src.flow.bgkeys.index('h')]/clock
        ph=hist.angle(logr)-hist.origin;speed=hist.angle(logr,1)*rate_a;rho=hist.rho0/bg['a']
        delayed=delay.read(ph-np.pi)
        qext=src.external(log);inject=np.zeros((len(clock),oldm.DIM))
        for idx,value in [(1,(4/3+bg['eb']/eg)*kk),(4,src.wave/3),(6,kk),(8,bg['sv']),(9,-(bg['a']*bg['sm'])**2*bg['sb']),(10,v0),(11,-m2*b0),(12,-h)]:inject[:,idx]=value
        def rhs(i,state,measure=False,init=False):
            fields,lag,shape,memory,tracer=state
            n=2*begin+i
            qa=np.repeat(rawq[n,sel],routes,axis=0);qreal=rawq[n,0]
            ba=b0[i]*co+quarter[n,0]*si;va=v0[i]*co+quarter[n,1]*si
            df=(co-1)*qext[i,0]+si*rawq[n,len(ang)//2,0]
            dw=(co-1)*qext[i,1]+si*rawq[n,len(ang)//2,1]
            de=qa[:,2]-qreal[2];dj=qa[:,4]-qreal[4];ds=qa[:,5]-qreal[5]
            st=bank.stress(lag,shape,kernel[i],weights[i])*bg['enu'][i];st[:,1]*=src.wave
            dcurrent=kk*(va-v0[i])*fields[:,10]+dj
            base_e=fields@we[i]+e0[i]+st[:,0]+(va-v0[i])*fields[:,11]+m2[i]*(ba-b0[i])*fields[:,10]+de
            base_j=fields@wj[i]+j0[i]+st[:,1]+dcurrent
            j=(kk*va*fields[:,10]+qext[i,3]+dj)/rho[i]
            delta=memory[:,0]-j
            denom=den[i]+1.5*(va**2-v0[i]**2)
            source=us[i]+addU[n]
            raw=source-base_e/2-1.5*h[i]*base_j/kk
            if init:return 2*(raw-denom*shadows[:,0])/rho[i],j
            ep=(raw-rho[i]*memory[:,1]/2)/denom
            phi=np.where(mom,fields[:,12],ep)
            external_slip=argterm('slip',n);external_fq=argterm('Fq',n)
            addslip=(st[:,2]+ds)/kk+external_slip
            psi=phi+slip[i]+addslip-(eg[i]*fields[:,oldm.QI]+nus[i]*fields[:,oldm.QN])/kk
            eff_j=base_j+rho[i]*delta
            pd=eff_j/(2*kk)-h[i]*psi+fq[i]+external_fq
            field,pm=tracer.T
            bt=original[n,0]*co+quarter[n,0]*si;vt=original[n,1]*co+quarter[n,1]*si;om,hub=oldgeom[n]
            af=vt*(psi+3*phi)+qa[:,0];bw=-om**2*bt*(psi-3*phi)+qa[:,1]
            if measure:
                kinetic=vt*pm;potential=om**2*bt*field;geo=3*vt**2*phi;e=kinetic+potential+geo+qa[:,2];pressure=kinetic-potential+geo+(qa[:,2]-qa[:,3])/3
                cur=KK*vt*field+qa[:,4];rhop=hist.rho0*ref_mass/om
                obs=np.stack([phi,ep,fields[:,12],psi,pd,base_e+rho[i]*(memory[:,1]-3*h[i]*delta/kk),eff_j,source+zeros,denom+zeros,h[i]+zeros,*st.T],axis=1)
                values=np.stack([e,pressure,cur,qa[:,5],e/2+1.5*hub*cur/KK,e/rhop-3*phi,cur/rhop],axis=1)
                product=(vt*field+bt*pm)/2
                virt=np.stack((product,2*hub*product,KK*bt*field/2,-vt*af/2,-bt*bw/2,geo,(qa[:,2]-qa[:,3])/3),axis=1)
                return obs,values,j,virt
            live=fields.copy();live[:,12]=phi
            dx=live@matrix[i]+bias[i]+addslip[:,None]*inject[i]
            dx[:,10]+=(va-v0[i])*(psi+3*phi)+df
            dx[:,11]+=m2[i]*(ba-b0[i])*(3*phi-psi)+dw
            dx[:,12]+=(st[:,1]+dcurrent+rho[i]*delta)/(2*kk)+external_fq
            assert np.max(abs(dx[:,12]-pd))<=2e-10*max(np.max(abs(pd)),1e-40)
            normal=live[:,part.N_IND].copy();normal[:,0]+=phi
            dl=bank.bin_rhs(lag,shape,normal,psi,vel[i],slow[i],micro[i])
            return [dx,dl,part.adv(shape,src.wave)+spectral[i],np.column_stack((speed[i]*(j-delayed[i])/np.pi,(-1+3*(hp[i]-h[i]**2)/kk)*delta)),
                np.column_stack((pm+af,-2*hub*pm-(KK+om**2)*field+bw))]
        return rhs,ph
    ref_mass=read(parent(f'history-{grid}.npz'))['m'].item()
    seen=[];source=[];virial=[];raw_current=[];pre_Y=None
    for left in range(0,len(time)-1,12):
        guard();right=min(len(time)-1,left+12)
        rhs,ph=setup(left,right);hit=[]
        if left==0:
            derived,wave_j=rhs(0,state,init=True)
            anchor_h=restart['obs'][-1,:2,9]
            old_y=restart['final_memory'][:2,1]+3*anchor_h*(restart['final_memory'][:2,0]-restart['physical_current_phase'][-1,:2,0])/kk
            native_error=np.max(abs(derived[:2]-old_y))
            state[3][:,1]=derived
            if abs(ang[sel[0]])==0:state[3][:2,1]=old_y
            pre_Y=np.column_stack((derived,state[3][:,1]))
        for idx,dt in enumerate(np.diff(time[left:right+1])):
            j=2*idx
            ob,vals,raw,terms=rhs(j,state,True);hit.append(raw);seen.append(ob);source.append(vals);virial.append(terms);raw_current.append(raw)
            k1=rhs(j,state)
            k2=rhs(j+1,[v+dt*a/2 for v,a in zip(state,k1)])
            k3=rhs(j+1,[v+dt*a/2 for v,a in zip(state,k2)])
            k4=rhs(j+2,[v+dt*a for v,a in zip(state,k3)])
            for val,a,b,c,d in zip(state,k1,k2,k3,k4):val+=dt/6*(a+2*b+2*c+d)
        ob,vals,raw,terms=rhs(len(ph)-1,state,True);hit.append(raw);delay.append(ph[::2],hit)
    seen.append(ob);source.append(vals);virial.append(terms);raw_current.append(raw)
    def finish(a):return np.array(a).reshape(len(time),len(sel),2,-1)
    pack(f'solved-{intervention}-{grid}-{res}.npz',t=time,angles=ang[sel],obs=finish(seen),stress=finish(source),virial=finish(virial),j=finish(raw_current),incoming_Y=pre_Y,
        native_Y_absolute_roundoff=native_error,final=state[0],final_lag=state[1],final_shape=state[2],final_memory=state[3],final_tracer=state[4],k=np.sqrt(kk))
    print('solved',intervention,grid,res,len(time),flush=True)

if __name__=='__main__':
    assert sys.argv[1] in ('native','matter','geometry','geometry_U','geometry_Fq','geometry_slip')
    for grid in ('p16','p32'):
        for res in (640,1280):
            name=f'solved-{sys.argv[1]}-{grid}-{res}.npz'
            path=ROOT/name;done=name+'.receipt'
            if not (ROOT/done).exists():
                predict(grid,res,sys.argv[1])
                refs=[path,ROOT/'gravity_phase.py',ROOT/'native_io.py',ROOT/'preparation-freeze.json',old.pin(old.MID,f'carry-matched-{grid}-4.npz')]
                if sys.argv[1].startswith('geometry'):refs.append(ROOT/f'exterior-{grid}-{res}.npz')
                receipt(done,refs)
            check(done)
