import moment_readout as mr,score_gravity as scoring
from unittest.mock import patch
from native_io import *
def run(label):
    earlier=int(label=='one_period')
    files=[ROOT/f'solved-{label}-{g}-{r}.npz.receipt' for g in ('p16','p32') for r in (640,1280)]
    receipt('forecast-'+label+'.json',[ROOT/'carried-freeze.json',ROOT/'U-freeze.json',*files])
    rows=[];moments=[];memory=[]
    for grid in ('p16','p32'):
        for res in (640,1280):
            inp=read(ROOT/f'angles-{res}.npz')
            carry=read(ROOT/f'carried-{grid}-{res}.npz')
            inp[grid+'_probe']=carry['probe']
            def overlay(path):return inp if path==ROOT/f'angles-{res}.npz' else read(path)
            rows.append(scoring.scores(label,grid,res))
            with patch.object(mr,'read',overlay):moments.append(mr.solve(label,grid,res))
            sol=read(ROOT/f'solved-{label}-{grid}-{res}.npz')
            req,used=sol['incoming_Y'].reshape(16,2,2).transpose(2,0,1)
            delta=lambda x:x-x[:1]
            mag=lambda x:np.max(abs(x),axis=0)
            delta_need=delta(req-carry['prior_Y'])
            assert mag(delta_need).min()>0
            memory.append(dict(grid=grid,res=res,carried_minus_required_pct_of_change=(100*mag(delta(used-req))/mag(delta_need)).tolist(),
                given_pct_of_required_change=(100*mag(delta(used-carry['prior_Y']))/mag(delta_need)).tolist(),earlier=sol['earlier'].item()))
    put(label+'-scores.json',dict(rows=rows,criterion_pct=.5,scorer=sha(ROOT/'score_gravity.py'),freeze=sha(ROOT/('forecast-'+label+'.json')),reporter=sha(ROOT/'report_carried.py')))
    put('reduced-'+label+'.json',dict(rows=moments,solver=sha(ROOT/'moment_readout.py'),carried_memory=memory))
if __name__=='__main__':run(sys.argv[1])
