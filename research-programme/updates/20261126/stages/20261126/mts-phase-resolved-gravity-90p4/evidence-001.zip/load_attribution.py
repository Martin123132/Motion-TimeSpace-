from score_combined import *
import inspect
def separate_work(grid,res,p):
    from score_combined import evaluate
    code=inspect.getsource(evaluate).split('    print(grid,res,')[0]
    assert 'swork=rate(' in code
    code+='    return ct,unit,refs,pred,goal,now\n'
    space=dict(evaluate.__globals__);exec(compile(code,'saved signed load readouts','exec'),space)
    ct,scale,tr,pr,tm,pm=space['evaluate'](grid,res,p)
    zerr=pr[:,0]-tr[:,0];qerr=pr[:,1]-tr[:,1]
    def integrate(arr,order):
        I=make_interp_spline(ct,arr.transpose(1,0,2),k=order).antiderivative()
        return (I(ct)-I(ct[0])).transpose(1,0,2)
    work=integrate((pm-tm).sum(1),5)
    check=integrate((pm-tm).sum(1),3)
    defect=drift(zerr)-work
    dep=drift(qerr);boundary=zerr[:,:1]+qerr[:,:1]
    pieces=np.stack((np.broadcast_to(boundary,zerr.shape),work,defect,dep),axis=1)
    expect=(pr-tr)[:,2]
    assert np.max(abs(pieces.sum(1)-expect))<3e-12*np.max(abs(tr))
    tab=rate(pieces,scale[:,None]);change=rate(drift(expect),scale);quad=rate(work-check,scale)
    print(grid,res,'scale cos/sin H route: entry, work, projection, explicit-change',np.round(tab[1:,:,1],2).tolist(),flush=True)
    return dict(grid=grid,res=res,terms_pct_of_Hamiltonian_harmonic=tab.tolist(),change_pct=change.tolist(),quadrature_order_spread_pct=quad.tolist())
if __name__=='__main__':
    p=historic.pre.import_at(historic.pre.OLD,'partial')
    put('load-attribution.json',dict(terms=['net heavy error already present at first supported center','integrated predicted minus temporal Zprime','projection and integration commutator including solver error','change in explicit quadratic load error'],
        rows=[separate_work(grid,res,p) for grid in ('p16','p32') for res in (640,1280)],method=sha(ROOT/'load_attribution.py'),
        meaning='Diagnostic on the same six centers; the first supported center is not the initial Cauchy surface. No state was reset.'))
