from native_io import *
from contextlib import contextmanager
from unittest.mock import patch
from scipy.integrate import solve_ivp,cumulative_simpson
from types import SimpleNamespace

def load_generator():
    io=historic.io
    io.sealed(io.EXT,'source_io.py');sys.path.insert(0,str(io.EXT))
    import source_io as ext
    lib=ext.spatial_module()
    time,old_t,k,initial=lib.causal_inputs()
    ts=np.arange(round(old_t[0]*160),round(90.45*160)+1)/160
    calls=[]
    def capture(rhs,span,start,**kw):
        solution=solve_ivp(rhs,span,start,**kw);assert solution.success
        calls.append((rhs,span,start.copy(),kw,solution.sol));return solution
    with patch.object(lib.earlier,'solve_ivp',capture):
        flux,_=lib.earlier.model(6,time,ts,k,initial)
    wr=calls[0];fr=calls[1];start=fr[2].copy()
    a,h,b,v=wr[-1](lib.SWITCH)[:4];drho=initial['dust']/a-(v*v+(initial['mass']*a*b)**2)/2
    start[1]=np.sqrt(h*h+drho/3)
    fluid=solve_ivp(fr[0],fr[1],start,**fr[3]);assert fluid.success
    path,_,_=lib.predict(4,ts,k,initial,wr[-1],fluid.sol,fr[0])
    bank=read(io.sealed(io.EXT,'blind-source.npz'))
    assert np.array_equal(bank['eta'],ts) and np.array_equal(bank['k'],k)
    for key in ('potential_square','laplacian','gradient'):
        assert np.array_equal(path[key],bank[key])
    assert np.array_equal(flux['restore'],bank['locked_flux'])
    return SimpleNamespace(**locals())

def run():
    guard();check('preparation-freeze.json')
    g=load_generator();k=g.k;n=len(k);m=g.initial['mass'];dust=g.initial['dust'];wrhs=g.wr[0];wave=g.wr[-1]
    raw=read(ROOT/'angles-1280.npz');angles=raw['angles']
    t=np.linspace(ANCHOR,raw['t'][-1],2*len(raw['t'])-1)
    ts=g.ts
    dense=np.linspace(89.275,ANCHOR,481)
    past=wave(dense);freq=past[0]*m;anti=CubicSpline(dense,freq).antiderivative();theta=anti(dense)-anti(dense[0])
    signed=np.ones(len(past),bool);signed[:2]=False;signed[-n:]=False
    modes=k[:,None]
    def prepare(angle):
        if angle==0:return past[:,-1].copy()
        lags=np.pi*np.arange(1,5)-angle
        coeff=np.array([np.prod(np.delete(lags,i)/(np.delete(lags,i)-point)) for i,point in enumerate(lags)])
        assert min(theta[-1]-lags)>=0
        vals=make_interp_spline(theta,past.T,k=5)(theta[-1]-lags)
        sel=vals*coeff[:,None];sel[:,signed]*=(-1.)**np.arange(1,5)[:,None]
        seed=sel.sum(0);b,v=seed[2:4];aw,hw,b0,v0=past[:4,-1];seed[0]=aw
        seed[1]=np.sqrt(hw**2+((v*v-v0*v0)+(m*aw)**2*(b*b-b0*b0))/6)
        return seed
    def interp(value):
        return make_interp_spline(ts,value.T,k=5)(t).T
    fs=g.fluid.sol(t);af,hf=fs[:2];df,uf,etaf=fs[2:].reshape(3,n,-1)
    rhsf=np.array([g.fr[0](at,fs[:,ix])[2:].reshape(3,n) for ix,at in enumerate(t)]).transpose(1,2,0)
    ratio=(modes/(af*m))**2
    press=ratio/(np.sqrt(1+ratio)+1)**2*(df+3*hf*uf/modes)
    kzf=-rhsf[0]-3*hf*press-modes*uf;total_qf=2*rhsf[2];qf=dust/af*uf
    sigmaf=kzf/modes+1.5*total_qf/modes**2
    phif=(etaf-hf*sigmaf)/modes
    entry=int(np.flatnonzero(ts==ANCHOR).item())
    hist_shear=g.path['dsigma'][:,entry];host=interp(g.flux['host']);sigma=interp(g.flux['sigma'])
    q_legacy=interp(g.flux['qf']);fl_legacy=g.fr[-1](t);rho_legacy=dust/fl_legacy[0]
    shells=np.array(json.loads(g.lib.earlier.es.pin('legs.json').read_bytes())['squared_radii'])
    assert len(shells)==n
    entries=[];wave0=wave(t)
    for idx,angle in enumerate(angles):
        if idx==0:state=wave0
        else:
            seed=prepare(angle);sc=np.maximum(abs(seed),max(abs(seed))*1e-13)
            result=solve_ivp(wrhs,(t[0],t[-1]),seed,t_eval=t,method='DOP853',rtol=2e-11,atol=sc*2e-13,max_step=.003125)
            assert result.success;state=result.y
        aw,hw,back,vel=state[:4];field,deriv,etak=state[4:].reshape(3,n,-1)
        qw=modes*vel*field
        energy=vel*deriv+(aw*m)**2*back*field-dust/af*df
        deta=etak-etaf;dh=hw-hf;kzw=(hf*kzf+.5*energy+modes*deta)/hw
        algebra=(kzw-kzf)/modes+1.5*(qw-qf)/modes**2
        if idx==0:original_alg=algebra[:,0]
        ini=hist_shear+(algebra[:,0]-original_alg)
        ds=(aw[0]**2*ini[:,None]+cumulative_simpson(aw**2*(deta-2*dh*sigmaf),x=t,axis=1,initial=0))/aw**2
        delta=(deta-hw*ds-dh*sigmaf)/modes
        parts=g.lib.project(k,phif,delta)
        change=-(qw-q_legacy+(vel**2-rho_legacy)*sigma)/(2*modes)
        data=SimpleNamespace(shell=shells,nodes=k,first={'host':host,'change':change})
        op=g.lib.earlier.es.Fast(g.lib.earlier.es.Project(data).ops[0],data)
        flux=1.5*(op.product('host','change')+op.product('change','host')+op.product('change','change'))
        entries.append(np.stack([parts[key] for key in ('potential_square','laplacian','gradient')]+[flux]))
    terms=np.stack(entries,axis=-1)
    indices=np.flatnonzero(np.isclose(t*160,np.rint(t*160),rtol=0,atol=1e-9))
    exact=np.rint((t[indices]-ts[0])*160).astype(int);assert np.max(abs(ts[exact]-t[indices]))<3e-12
    keys=['potential_square','laplacian','gradient','locked_flux']
    archive=np.stack([g.bank[key][exact] for key in keys])
    levels=100*np.max(abs(terms[:,indices,0]-archive),axis=1)/np.max(abs(archive),axis=1)
    assert levels.max()<.5,levels
    pack('U-ingredients.npz',t=t,keys=keys,angles=angles,terms=terms,legacy_knot_replay_pct=levels,k=k)
    u=(terms-terms[:,:,:1]).sum(0)
    assert np.count_nonzero(u[:,0])==0
    for res in (640,1280):
        oldnet=read(ROOT/f'angles-{res}.npz')
        mesh=np.linspace(ANCHOR,oldnet['t'][-1],2*len(oldnet['t'])-1)
        ix=np.rint((mesh-ANCHOR)*2560).astype(int);assert np.max(abs(mesh-t[ix]))<3e-12
        for grid in ('p16','p32'):
            pack(f'exterior-{grid}-{res}.npz',t=mesh,U=u[ix],Fq=np.zeros_like(u[ix]),slip=np.zeros_like(u[ix]),angles=angles)
    put('U-control.json',dict(generator='retained pre-switch wave and fluid Einstein/field generators plus Hamiltonian-reconciled spatial shear, phase-dependent wave launched at 89.65',
        original_source_knots=len(indices),gamma0_replay_pct=dict(zip(keys,levels)),leg_count=n,dt=t[1]-t[0],
        conditional='Only U restoration changed; other nonheavy forcing fixed. Assumptions include fixed nonheavy continuation and the inherited differential-shear approximation.'))
    receipt('U-freeze.json',[ROOT/'GEOMETRIC-SOURCE.md',ROOT/'geometric_source.py',ROOT/'preparation-freeze.json',ROOT/'matter-scores.json',ROOT/'U-control.json',ROOT/'U-ingredients.npz',*sorted(ROOT.glob('exterior-*.npz')),historic.io.sealed(historic.io.EXT,'blind-source.npz'),historic.io.sealed(historic.io.EXT,'forecast_extension.py')])
    print('frozen geometric source',n,len(t),levels,flush=True)
if __name__=='__main__':run()
