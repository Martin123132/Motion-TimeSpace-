import gravity_phase as engine
from evolve_micro import overlay_inputs
from constraint_budget import *
from scipy.integrate import cumulative_simpson
def separate(grid,res):
    guard();tag='micro_live';name=f'solved-{tag}-{grid}-{res}.npz'
    check(name+'.receipt');inputs,Y=overlay_inputs(grid,res,0)
    code=(ROOT/'gravity_phase.py').read_text().replace('state[3][:,1]=derived','state[3][:,1]=incoming_Y')
    what='return obs,values,j,virt'
    assert code.count(what)==1
    code=code.replace(what,"""heavy_e=va*fields[:,11]+m2[i]*ba*fields[:,10]+qext[i,2]+de
                heavy_j=rho[i]*j
                comp_j=rho[i]*delta
                comp_e=rho[i]*memory[:,1]-3*h[i]*comp_j/kk
                split=np.stack([base_e-heavy_e-st[:,0],st[:,0],heavy_e,comp_e,base_j-heavy_j-st[:,1],st[:,1],heavy_j,comp_j],axis=-1)
                return obs,values,j,split""")
    ns=dict(engine.__dict__,__name__='diagnostic_split',incoming_Y=Y)
    exec(compile(code,'identical evolution, read component stresses','exec'),ns)
    ns['read']=lambda path:inputs if path==ROOT/f'angles-{res}.npz' else read(path)
    ref=read(ROOT/name)
    def capture(oldname,**sol):
        assert np.array_equal(ref['obs'],sol['obs']) and np.array_equal(ref['stress'],sol['stress']) and np.array_equal(ref['final_lag'],sol['final_lag'])
        pack(f'split-{grid}-{res}.npz',t=sol['t'],parts=sol['virial'])
    ns['pack']=capture;ns['predict'](grid,res,'geometry_U')
def actual_split(grid,res,t,p):
    frame=native_pieces(grid);obs=frame(t);H=obs[:,0,9].real;hp=frame(t,1)[:,0,9].real
    history=read(parent(f'history-{grid}.npz'));mem=read(parent(f'memory-{grid}.npz'));host=p.Host(grid,4);mass=history['m'].item();kk=host.kk
    with np.load(historic.io.sealed(historic.io.EXT,'material/forcing-heavy.npz')) as a:
        bgk=a['bgkeys'].tolist();late_a=make_interp_spline(np.log(a['eta']),a['background'][bgk.index('a')],k=5)
    a=np.zeros(len(t));qe=0*t.astype(complex)
    early=t<=89.6;bridge=(t>89.6)&(t<=ANCHOR);late=t>ANCHOR
    a[early]=np.sqrt(host.osc(t[early])[1])/mass;a[bridge]=host.flow.bg(np.log(t[bridge]))[:,host.flow.bgkeys.index('a')];a[late]=late_a(np.log(t[late]))
    from shared_trace import Shared
    shared=Shared().overlay(host.external,[2,3])
    qe[early]=shared(np.log(t[early]))[:,2];qe[bridge]=host.external(np.log(t[bridge]))[:,2]
    idx=np.searchsorted(mem['t'],t);assert np.array_equal(mem['t'][idx],t)
    qe[late]=mem['qe_qj'][idx[late],0]
    rho=history['rho0']/a
    b,v,f,w=history['states'][idx].transpose(1,0,2);J=history['currents'][idx];delta=mem['exact_rolling'][idx]+mem['memory_offset']-J
    factor=-1+3*(hp-H**2)/kk;term=factor[:,None]*delta
    add=cumulative_simpson(term.real,x=t,initial=0,axis=0)+1j*cumulative_simpson(term.imag,x=t,initial=0,axis=0)
    y=mem['archival_energy_memory'][0]+3*H[0]*delta[0]/kk+add
    ec=(y-3*H[:,None]*delta/kk)*rho[:,None];jc=delta*rho[:,None]
    eh=v*w+((mass*a)**2)[:,None]*b*f+qe[:,None];jh=rho[:,None]*J
    valid=mem['valid'][idx];direct=mem['archival_energy_memory'][idx][valid];error=100*np.max(abs(ec[valid]/rho[valid,None]-direct))/np.max(abs(direct))
    assert error<.0001
    arr=np.stack((obs[:,:,5]-eh-ec-obs[:,:,10],obs[:,:,10],eh,ec,obs[:,:,6]-jh-jc-obs[:,:,11],obs[:,:,11],jh,jc),axis=-1)
    return arr,obs,error
def score(grid,res,p):
    tag='micro_live';model=read(ROOT/f'solved-{tag}-{grid}-{res}.npz');packet=read(ROOT/f'split-{grid}-{res}.npz')
    ref=read(parent(f'driven-{grid}-{res}.npz'));angles=read(ROOT/f'angles-{res}.npz');t=ref['t'];ct=angles['centers'];ix=np.searchsorted(t,ct);im=np.searchsorted(packet['t'],ct)
    actual,obs,memory_error=actual_split(grid,res,t,p)
    kk=model['k']**2;D=model['obs'][0,0,0,8]
    def terms(a,x):
        E=-a[...,:4]/(2*D);J=-1.5*x[...,9,None]*a[...,4:]/(kk*D);arr=np.concatenate((E,J),axis=-1)
        for total,want in [(a[...,:4].sum(-1),x[...,5]),(a[...,4:].sum(-1),x[...,6])]:
            assert np.max(abs(total-want))<1e-11*np.max(abs(want))
        return arr
    source=aperture(ref['phase'],terms(actual,obs).transpose(2,0,1),ref['phase'][ix])
    target=aperture(ref['phase'],obs[:,:,1:2].transpose(2,0,1),ref['phase'][ix])[:,0]
    forecast=fourier(terms(packet['parts'],model['obs'])[im].transpose(3,0,1,2),16)
    delta=forecast-source;err=rate(delta,target[:,None])
    print(grid,res,'cos/sin error % on Hamiltonian route',np.round(err[1:,:,1],2).tolist(),flush=True)
    return dict(grid=grid,res=res,pct_of_Hamiltonian_harmonic=err.tolist(),native_memory_replay_pct=memory_error,
        summed_energy_error_pct=rate(delta[:,:4].sum(1),target).tolist(),summed_current_error_pct=rate(delta[:,4:].sum(1),target).tolist())
if __name__=='__main__':
    grid=sys.argv[1];separate(grid,1280)
    p=historic.pre.import_at(historic.pre.OLD,'partial')
    put('components-'+grid+'.json',dict(row=score(grid,1280,p),keys=['ordinary plus nonheavy sources','77-bin stress','bare heavy','retarded compensation']*2,
        groups=['energy','current'],method=sha(ROOT/'split_sources.py')))
