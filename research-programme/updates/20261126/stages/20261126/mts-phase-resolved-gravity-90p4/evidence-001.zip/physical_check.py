from native_io import *
def rates(diff,reference):
    norm=np.max(abs(reference),axis=0)
    assert norm.min()>0
    return 100*np.max(abs(diff),axis=0)/norm
def archive(grid,t):
    clocks=[];values=[]
    for step in range(1,5):
        data=read(old.pin(old.LATE,f'part-matched-{grid}-4-{step:02}.npz'))
        keep=slice(int(step>1),None);clocks.extend(data['t'][keep]);values.extend(data['obs'][keep,:2])
    return CubicSpline(clocks,values,extrapolate=False)(t)
def score(grid,res):
    name=f'solved-native-{grid}-{res}.npz';check(name+'.receipt')
    a=read(ROOT/name);vals=a['obs'][:,0];ref=archive(grid,a['t'])
    err=vals-ref;dr=lambda x:x-x[:1]
    essential=[0,1,2,3,4,5,6]
    scale=rates(err,ref);drerr=rates(dr(err[:,:,essential]),dr(ref[:,:,essential]))
    stress=read(parent(f'driven-{grid}-{res}.npz'))
    ix=np.searchsorted(stress['t'],a['t'])
    mine=a['stress'][:,0].transpose(0,2,1);actual=stress['values'][0][:,ix].transpose(1,0,2)
    probe=rates(mine-actual,actual)
    cross=ref[:,:,1]-ref[:,:,2]
    out=dict(grid=grid,res=res,archive_level_pct=scale.tolist(),field_change_pct=drerr.tolist(),gamma0_probe_pct=probe.tolist(),
        shadow_difference_pct_of_phi=(100*np.max(abs(cross),axis=0)/np.max(abs(ref[:,:,0]),axis=0)).tolist(),
        max_absolute_Y0_independent=a['native_Y_absolute_roundoff'].item())
    print(grid,res,'physical level/drift, probe',np.max(scale),np.max(drerr),np.max(probe),'shadows',out['shadow_difference_pct_of_phi'],flush=True)
    return out
if __name__=='__main__':
    guard();rows=[score(grid,res) for grid in ('p16','p32') for res in (640,1280)]
    put('physical-check.json',dict(rows=rows,passed=all(np.max(row['field_change_pct'])<.5 and np.max(row['gamma0_probe_pct'])<.5 and np.max(row['archive_level_pct'])<.5 for row in rows)))
