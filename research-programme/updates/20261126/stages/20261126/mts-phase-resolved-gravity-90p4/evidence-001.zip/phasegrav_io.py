from pathlib import Path
from functools import lru_cache
from io import BytesIO
import json,hashlib,sys
import numpy as np
ROOT=Path(__file__).resolve().parent
BASE=ROOT.parent
PARENT=BASE/'mts-total-phase-stress-90p4-20261126'
PIN='552d5ba956a576eb651473abfc3f44ae03b63c9db0dcae257513749071472630'
def sha(path):
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
assert sha(PARENT/'seal.json')==PIN
members=json.loads((PARENT/'seal.json').read_bytes())['files']
@lru_cache()
def parent(name):
    path=PARENT/name
    assert sha(path)==members[name],name
    return path
for mod in ('metric_orbit','causal_prep','first_pair','driven_pair','historic_replay','data_io','score_total','virial_report','virial'):parent(mod+'.py')
sys.path.insert(0,str(PARENT))
import metric_orbit as orbit, historic_replay as historic, data_io as old
from scipy.interpolate import CubicSpline,make_interp_spline
from score_total import rate,drift,aperture
read=old.read
ANCHOR=89.65
def guard():
    old.guard();assert not (ROOT/'STOP-REQUESTED').exists()
def save(name,raw):
    guard();path=ROOT/name
    if path.exists():assert sha(path)==hashlib.sha256(raw).hexdigest(),name
    else:
        temp=path.with_suffix(path.suffix+'.partial')
        with temp.open('xb') as stream:stream.write(raw)
        temp.rename(path)
def put(name,obj):save(name,(json.dumps(obj,sort_keys=True,indent=2,default=lambda v:v.item(),allow_nan=False)+'\n').encode())
def pack(name,**data):
    buf=BytesIO();np.savez_compressed(buf,**data);save(name,buf.getvalue())
def receipt(name,paths):put(name,{str(p.relative_to(BASE)):sha(p) for p in paths})
def check(name):
    for key,sig in json.loads((ROOT/name).read_bytes()).items():assert sha(BASE/key)==sig,key
def local(name):return json.loads((ROOT/name).read_bytes())
