from score_gravity import *
def score(g,res,deg):
    new=read(ROOT/f'micro-response-{deg}-{g}-{res}.npz');orig=read(ROOT/f'moments-carried-{g}-{res}.npz')
    physical=read(parent(f'driven-{g}-{res}.npz'));t=physical['t'];base=read(ROOT/f'angles-{res}.npz')
    ix=np.searchsorted(t,base['centers']);ip=np.searchsorted(orig['t'],base['centers'])
    ref0=orig['reference_mean'];unit=drift(ref0);qref=aperture(physical['phase'],physical['pieces'][0,1:2],physical['phase'][ix])[0,0]
    before=orig['values'][:,ip];after=new['values']
    en=rate(drift(after-ref0),unit);newq=new['pressure_pieces'][-1];oldq=orig['pressure_pieces'][-1,ip]
    out=dict(g=g,res=res,degree=deg,response_vs_temporal_pct=en.tolist(),levels_pct=rate(after-ref0,ref0).tolist(),before_pct=rate(drift(before-ref0),unit).tolist(),
        micro_pressure_before_pct=rate(drift(oldq-qref),unit[1]).tolist(),micro_pressure_after_pct=rate(drift(newq-qref),unit[1]).tolist(),
        response_movement_pct=rate(drift(after-before),unit).tolist(),separated_pressure_changes_pct=rate(drift(new['pressure_pieces']-orig['pressure_pieces'][:,ip]),unit[1]).tolist())
    print(g,res,deg,'pressure',np.round(en[1],5),'Qp',np.round(out['micro_pressure_after_pct'],5),flush=True)
    return out
if __name__=='__main__':
    check('micro-readout-freeze.json')
    put('micro-scores.json',dict(freeze=sha(ROOT/'micro-readout-freeze.json'),scorer=sha(ROOT/'score_micro.py'),rows=[score(g,r,d) for d in (4,5) for g in ('p16','p32') for r in (640,1280)]))
