from phasegrav_io import *

def prepare(res):
    for name in ('first','orbit'):parent(f'{name}-{res}.npz')
    time,phase,anchor,end,centers,first,qq,basis=orbit.leg_bank(res)
    ts=time[anchor:end];assert ts[0]==ANCHOR
    ref=read(parent(f'orbit-{res}.npz'))
    assert np.array_equal(ref['t'],time[centers])
    angles=ref['angles'];cs=np.cos(angles);sn=np.sin(angles)
    raw=qq.transpose(0,2,1)
    quadr=raw[0,:,None,:]*cs[None,:,None]**2+raw[1,:,None,:]*sn[None,:,None]**2+(raw[2]-(raw[0]+raw[1])/2)[:,None,:]*np.sin(2*angles)[None,:,None]
    quadr[:,:,:2]=raw[0,:,None,:2]*cs[None,:,None]+raw[1,:,None,:2]*sn[None,:,None]
    packet=dict(t=ts,centers=time[centers],angles=angles,quadr=quadr,quad_bg=basis[1],base_bg=basis[0],geom=first['bg'][:2,anchor:end].T,kk=first['k']**2,theta=phase[anchor:end])
    for grid in ('p16','p32'):
        past=read(parent(f'history-{grid}.npz'));mem=read(parent(f'memory-{grid}.npz'))
        driven=read(parent(f'driven-{grid}-{res}.npz'))
        pre=read(old.pin(old.MID,f'carry-matched-{grid}-4.npz'))
        halfphase=phase[anchor:anchor+1]
        packets=[old.pin(old.PREFIX,f'{name}-{grid}-4.npz') for name in ('second','third','fourth','partial')]+[old.pin(old.MID,f'carry-matched-{grid}-4.npz')]
        clocks=[];shadow=[]
        for p in packets:
            with np.load(p) as ar:
                sl=slice(int(bool(clocks)),None);clocks.extend(ar['t'][sl]);shadow.extend(ar['obs'][sl,:2,1:3])
        clocks=np.array(clocks);assert clocks[0]<time[0]<clocks[-1]==ANCHOR
        theta0=phase[:anchor+1]
        geom=CubicSpline(clocks,shadow)(time[:anchor+1])
        nat=CubicSpline(past['t'],past['states'][:,2:4])(time[:anchor+1])
        sourced=driven['state'][0,:,:anchor+1].transpose(1,0,2)
        def states(data,odd):
            return np.stack([data[-1] if i==0 else orbit.causal_values(theta0,data,halfphase,g,3,odd)[0] for i,g in enumerate(angles)])
        ph=CubicSpline(mem['t'],mem['theta'])(ANCHOR)
        prior_theta=np.r_[mem['pre_theta'],mem['theta'][mem['t']<=ANCHOR]]
        prior_wave=np.concatenate([mem['pre_j'],past['currents'][mem['t']<=ANCHOR]])
        if prior_theta[-1]<ph:
            prior_theta=np.r_[prior_theta,ph];prior_wave=np.vstack([prior_wave,pre['physical_current_phase'][-1,:2,0]])
        assert np.isclose(prior_theta[-1],ph,atol=1e-10,rtol=0)
        lag_phase=np.linspace(ph-np.pi,ph,193)
        pre_j=CubicSpline(prior_theta,prior_wave)(lag_phase)
        angles_j=np.stack([pre_j if i==0 else orbit.causal_values(prior_theta,prior_wave,lag_phase,g,3,False) for i,g in enumerate(angles)],axis=1)
        anti=CubicSpline(lag_phase,angles_j).antiderivative()
        mean=(anti(ph)-anti(ph-np.pi))/np.pi
        packet.update({grid+'_'+key:value for key,value in dict(native=states(nat,True),probe=states(sourced,True),shadows=states(geom,False),lag_phase=lag_phase,lag_current=angles_j,
            mean=pre['final_memory'][None,:2,0]+(mean-mean[:1]),real_native=pre['final'][:2,10:12].T).items()})
        assert np.max(abs(packet[grid+'_native'][0]-packet[grid+'_real_native']))<1e-8*np.max(abs(packet[grid+'_real_native']))
        packet[grid+'_native'][0]=packet[grid+'_real_native']
    pack(f'angles-{res}.npz',**packet)
    print('prepared',res,flush=True)
if __name__=='__main__':
    guard()
    receipt('preparation-method.json',[ROOT/'PROTOCOL.md',ROOT/'prepare_angles.py',ROOT/'phasegrav_io.py',PARENT/'seal.json'])
    for res in (640,1280):prepare(res)
    receipt('preparation-freeze.json',[ROOT/'preparation-method.json',ROOT/'angles-640.npz',ROOT/'angles-1280.npz'])
