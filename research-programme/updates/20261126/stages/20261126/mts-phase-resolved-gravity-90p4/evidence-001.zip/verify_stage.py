import argparse
import json

from native_io import BASE, PARENT, ROOT, guard, np, old, parent, put, sha

parent("score_total.py")
from score_total import aperture


def read_json(name):
    return json.loads((ROOT / name).read_bytes())


def pressure_error(prediction, reference):
    difference = prediction - reference
    error = np.max(abs(difference - difference[:1]), axis=0)
    scale = np.max(abs(reference - reference[:1]), axis=0)
    assert np.all(scale > 0)
    return 100 * error / scale


def check_gate(score):
    assert score.shape == (2,) and np.all(np.isfinite(score))
    assert score[0] < 0.5 < score[1], score


def check_arrays():
    controls = read_json("physical-check.json")
    assert controls["passed"] and len(controls["rows"]) == 4
    for row in controls["rows"]:
        assert max(np.max(row[key]) for key in ("archive_level_pct", "field_change_pct", "gamma0_probe_pct")) < 0.5
    source = read_json("U-control.json")
    assert source["leg_count"] == 782 and source["original_source_knots"] == 32
    assert max(source["gamma0_replay_pct"].values()) < 1.5e-8
    combined = read_json("Z-scores.json")["rows"]
    results = {label: read_json(label + "-result.json") for label in ("micro_live", "micro_one")}
    for label, result in results.items():
        assert result["gate_pct"] == 0.5 and result["forecast"] == sha(ROOT / ("forecast-" + label + ".json"))
        assert len(result["full"]) == len(result["reduced"]) == 4
    for index, (grid, resolution) in enumerate((grid, resolution) for grid in ("p16", "p32") for resolution in (640, 1280)):
        with np.load(ROOT / f"angles-{resolution}.npz") as inputs:
            centers = inputs["centers"]
        assert len(centers) == 6
        with np.load(parent(f"driven-{grid}-{resolution}.npz")) as archive:
            nodes = np.searchsorted(archive["t"], centers)
            assert np.array_equal(archive["t"][nodes], centers)
            reference = aperture(archive["phase"], archive["values"][0, 1:2], archive["phase"][nodes])[0, 0]
        for label, result in results.items():
            row = result["full"][index]
            assert (row["grid"], row["res"], row["angles"][-1]["angles"]) == (grid, resolution, 16)
            with np.load(ROOT / f"solved-{label}-{grid}-{resolution}.npz") as packet:
                nodes = np.searchsorted(packet["t"], centers)
                assert np.array_equal(packet["t"][nodes], centers)
                assert packet["final_lag"].shape == (32, 77, 69) and np.all(np.isfinite(packet["final_lag"]))
                score = pressure_error(packet["stress"][nodes, :, :, 1].mean(axis=1), reference)
            np.testing.assert_allclose(score, row["angles"][-1]["drift_pct"][0][1], rtol=2e-7, atol=1e-8)
            with np.load(ROOT / f"moments-{label}-{grid}-{resolution}.npz") as packet:
                reduced_score = pressure_error(packet["values"][1, nodes], reference)
            np.testing.assert_allclose(reduced_score, result["reduced"][index]["temporal_drift_error_pct"][1], rtol=2e-7, atol=1e-8)
            if label == "micro_live":
                check_gate(score)
                check_gate(reduced_score)
        row = combined[index]
        assert (row["grid"], row["res"]) == (grid, resolution)
        with np.load(ROOT / f"combined-{grid}-{resolution}.npz") as packet:
            assert np.array_equal(packet["t"][nodes], centers)
            score = pressure_error(packet["stress"][nodes, :, :, 1].mean(axis=1), reference)
        np.testing.assert_allclose(score, row["Z_pressure_pct"], rtol=2e-7, atol=1e-8)
        check_gate(score)
        if resolution == 1280:
            assert np.max(row["integrated_work_pct"]) < 2e-7


def main(create):
    if not __debug__:
        raise RuntimeError("Assertions must be enabled")
    guard()
    assert not list(ROOT.rglob("*.partial"))
    assert not any(item.is_dir() for item in ROOT.iterdir()), "Unexpected stage subdirectory"
    digests = {}
    for pattern in ("*.receipt", "*-method.json", "*-freeze.json", "forecast-*.json"):
        for path in ROOT.glob(pattern):
            entries = read_json(path.name)
            assert entries
            for key, expected in entries.items():
                member = (BASE / key).resolve()
                assert member.is_relative_to(BASE.resolve())
                if member not in digests:
                    digests[member] = sha(member)
                assert digests[member] == expected, (path.name, key)
    check_arrays()
    parents = {folder.name: sha(folder / "seal.json") for folder in [PARENT, *old.SIG]}
    assert all(parents[folder.name] == expected for folder, expected in old.SIG.items())
    files = {item.name: sha(item) for item in ROOT.iterdir() if item.is_file() and item.name != "seal.json"}
    manifest = dict(files=files, parents=parents, scope="Phase-resolved gravitating preparation and compensated Hamiltonian-source test, not a visibility forecast")
    if create:
        put("seal.json", manifest)
    assert read_json("seal.json") == manifest
    print("Verified", len(files), "stage files and", len(digests), "distinct receipt inputs; seal", sha(ROOT / "seal.json"))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--seal", action="store_true")
    main(parser.parse_args().seal)
