from score_gravity import *
def native_pieces(grid):
    packets=[old.pin(old.PREFIX,name+f'-{grid}-4.npz') for name in ('second','third','fourth','partial')]+[old.pin(old.MID,f'carry-matched-{grid}-4.npz')]+[old.pin(old.LATE,f'part-matched-{grid}-4-{part:02}.npz') for part in range(1,16)]
    time=[];values=[]
    for path in packets:
        with np.load(path) as arc:
            skip=slice(int(bool(time)),None);time.extend(arc['t'][skip]);values.extend(arc['obs'][skip,:2])
    return CubicSpline(time,values,extrapolate=False)
def components(obs,k2,dstar):
    phi,ep,shadow,psi,pd,en,cur,uu,den,hub=obs[...,:10].transpose((obs.ndim-1,*range(obs.ndim-1)))
    hd=hub*cur*(1.5/k2)
    return np.stack((uu/dstar,-en/(2*dstar),-hd/dstar,-(den-dstar)*ep/dstar,ep,shadow,psi-phi,pd,cur/(2*k2),-hub*psi,pd-cur/(2*k2)+hub*psi),axis=-1)
def report(tag,grid,res):
    path=f'solved-{tag}-{grid}-{res}.npz';check(path+'.receipt')
    a=read(ROOT/path);src=read(ROOT/f'angles-{res}.npz');p=read(parent(f'driven-{grid}-{res}.npz'))
    centers=src['centers'];ix=np.searchsorted(a['t'],centers);pt=np.searchsorted(p['t'],centers)
    actual=native_pieces(grid)(p['t']);kk=float(a['k'])**2;dstar=a['obs'][0,0,0,8]
    aa=components(actual,kk,dstar);bb=components(a['obs'],kk,dstar)
    def close(val):
        err=np.max(abs(val[...,:4].sum(-1)-val[...,4]))
        return err/np.max(np.abs(val[...,:4]))
    assert max(close(aa),close(bb))<2e-12
    ref=aperture(p['phase'],aa.transpose(2,0,1),p['phase'][pt]);refstride=aperture(p['phase'][::2],aa[::2].transpose(2,0,1),p['phase'][pt])
    pred=fourier(bb[ix].transpose(3,0,1,2),16)
    err=pred-ref
    def budget(look,reference,diff,denom):
        mag=rate(diff[:,look],denom[:,None])
        stride=rate((ref-refstride)[:,look],denom[:,None])
        coeff=np.einsum('hpcr,hcr->hpr',diff[:,look],denom.conj())/np.sum(abs(denom)**2,axis=1)[:,None]
        return dict(component_peak_error_pct=mag.tolist(),reference_change_with_stride_pct=stride.tolist(),signed_projection_error_pct=(100*coeff.real).tolist(),quadrature_projection_error_pct=(100*coeff.imag).tolist())
    density=budget([0,1,2,3,4],ref,err,ref[:,4]);momentum=budget([8,9,10,7],ref,err,ref[:,7])
    frac=lambda a:np.round(np.array(a)[1:, :,1],2)
    print(grid,res,'H pieces pct at density route cos/sin',frac(density['component_peak_error_pct']).tolist(),'M pieces pct at momentum route',np.round(np.array(momentum['component_peak_error_pct'])[1:,:,0],2).tolist(),flush=True)
    return dict(grid=grid,res=res,density=density,momentum_rate=momentum,summed_density_roundoff=max(close(aa),close(bb)))
if __name__=='__main__':
    tag=sys.argv[1];rows=[report(tag,g,r) for g in ('p16','p32') for r in (640,1280)]
    put(tag+'-budget.json',dict(rows=rows,harmonics=['mean','cos2','sin2'],routes=['comp_momentum','comp_density'],density_terms=['U','canonical E','HJ','phase dependent denominator','sum: Hamiltonian Phi'],momentum_terms=['effective J','lapse damping','Fq (inferred diagnostic)','sum: momentum rate'],scope='Signed diagnostic decomposition, not independent Fq forcing or observed cosmology.',scorer=sha(ROOT/'constraint_budget.py')))
