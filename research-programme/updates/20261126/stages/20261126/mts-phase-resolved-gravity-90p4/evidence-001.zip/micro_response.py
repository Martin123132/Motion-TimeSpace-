from native_io import *
import moment_readout as mr
import inspect
def run(grid,res,deg):
    inp=read(ROOT/f'angles-{res}.npz');micro=read(ROOT/f'micro-{deg}-{res}.npz');carry=read(ROOT/f'carried-{grid}-{res}.npz')
    assert np.array_equal(inp['t'],micro['t']) and np.array_equal(inp['angles'],micro['angles'])
    inp[grid+'_probe']=carry['probe']
    inp.update(quadr=micro['quadr'],quad_bg=micro['quad_bg'])
    def overlay(path):
        if path==ROOT/f'angles-{res}.npz':return inp
        assert path==ROOT/f'solved-carried-{grid}-{res}.npz'
        with np.load(path) as ar:return dict(angles=ar['angles'],t=ar['t'],obs=ar['obs'])
    code=inspect.getsource(mr.solve)
    assert code.count('    ref=read(parent(')==1
    forward=code.split('    ref=read(parent(')[0]+"""
    pack(f'micro-response-{deg}-{grid}-{res}.npz',t=t,centers=inp['centers'],values=vals[:,ix],pressure_pieces=pp[:,ix])
"""
    ns=dict(mr.__dict__,read=overlay,deg=deg)
    exec(compile(forward,'signed reduced readout, no temporal targets','exec'),ns)
    ns['solve']('carried',grid,res)
if __name__=='__main__':
    check('micro-freeze.json')
    for deg in (4,5):
        for grid in ('p16','p32'):
            for res in (640,1280):run(grid,res,deg)
    receipt('micro-readout-freeze.json',[ROOT/'micro_response.py',ROOT/'moment_readout.py',ROOT/'micro-freeze.json',ROOT/'forecast-carried.json',*sorted(ROOT.glob('micro-response-*.npz'))])
