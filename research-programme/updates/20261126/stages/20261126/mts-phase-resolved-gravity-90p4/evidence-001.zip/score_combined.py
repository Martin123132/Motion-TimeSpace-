from split_sources import *
def evaluate(grid,res,p):
    packet=read(ROOT/f'combined-{grid}-{res}.npz')
    oldrun=read(ROOT/f'solved-micro_live-{grid}-{res}.npz')
    inp=read(ROOT/f'angles-{res}.npz');time=packet['t'];ct=inp['centers'];ix=np.searchsorted(time,ct)
    fixed=read(parent(f'driven-{grid}-{res}.npz'));t=fixed['t'];it=np.searchsorted(t,ct);phase=fixed['phase']
    split,obs,mem_error=actual_split(grid,res,t,p)
    kk=packet['k']**2;native=read(parent(f'history-{grid}.npz'));host=p.Host(grid,4);mass=native['m'].item();rho0=native['rho0'].item()
    ei=t<=89.6;bi=(t>89.6)&(t<=89.65);li=t>89.65
    a=np.zeros(len(t));a[ei]=np.sqrt(host.osc(t[ei])[1])/mass;a[bi]=host.flow.bg(np.log(t[bi]))[:,host.flow.bgkeys.index('a')]
    with np.load(historic.io.sealed(historic.io.EXT,'material/forcing-heavy.npz')) as ar:
        alate=make_interp_spline(np.log(ar['eta']),ar['background'][ar['bgkeys'].tolist().index('a')],k=5)
    a[li]=alate(np.log(t[li]))
    with np.load(historic.io.oldio.pin(historic.io.oldio.PAD,'material-halfstep/forcing-heavy.npz')) as ar:
        qlate=make_interp_spline(np.log(ar['eta']),ar['values'][[ar['keys'].tolist().index(k) for k in ('hfield','hmoment','henergy','hJ')],:,0].T,k=5)
    from shared_trace import Shared
    early=Shared().overlay(host.external,[2,3]);q=np.empty((len(t),4),complex)
    q[ei]=early(np.log(t[ei]));q[bi]=host.external(np.log(t[bi]));q[li]=qlate(np.log(t[li]))
    uf,uw,qe,qj=q.T;H=obs[:,:,9].real
    explicit=qe[:,None]+3*H*qj[:,None]/kk
    heavy=split[:,:,2]+split[:,:,3]+3*H*(split[:,:,6]+split[:,:,7])/kk
    Z=heavy-explicit;D=oldrun['obs'][0,0,0,8]
    refparts=np.stack([Z,explicit,heavy],axis=0)
    refs=aperture(phase,refparts,phase[it])
    predparts=np.stack([packet['Z'],packet['explicit_q'],packet['Z']+packet['explicit_q']])
    pred=fourier(predparts[:,ix],16)
    unit=aperture(phase,obs[:,:,1:2].transpose(2,0,1),phase[it])[:,0]*D*2
    errors=rate(pred-refs,unit[:,None])
    rt=packet['dZ_terms'];primitive=make_interp_spline(time,rt.sum(-1),k=7).antiderivative()
    integrated=primitive(time)-primitive(time[0]);dz=packet['Z']-packet['Z'][0]
    integ_error=100*np.max(abs(integrated-dz),axis=(0,1))/np.max(abs(dz),axis=(0,1))
    diff=packet['obs']-oldrun['obs']
    eq=100*np.max(abs(diff),axis=(0,1))/np.max(abs(oldrun['obs']),axis=(0,1))
    before=fourier(oldrun['obs'][ix][:,:,:,[0,1]].transpose(3,0,1,2),16);after=fourier(packet['obs'][ix][:,:,:,[0,1]].transpose(3,0,1,2),16)
    induced=rate(after-before,unit[:,None]/(2*D))
    pressure=aperture(phase,fixed['values'][0,1:2],phase[it])[0,0]
    oldp=oldrun['stress'][ix,:,:,1].mean(1);newp=packet['stress'][ix,:,:,1].mean(1);punit=drift(pressure)
    baseline=rate(drift(oldp-pressure),punit);changed=rate(drift(newp-pressure),punit)
    pdiff=rate(drift(newp-oldp),punit)
    yh=packet['Y'][-1];prior=oldrun['final_memory'][:,1].reshape(yh.shape)
    yerr=100*np.max(abs(yh-prior),axis=0)/np.max(abs(prior),axis=0)
    clock=native_pieces(grid);hp=clock(t,1)[:,:,9].real;aH=make_interp_spline(t,a,k=5)(t,1)[:,None]/a[:,None];mu2=(mass*a[:,None])**2
    fld=native['states'][np.searchsorted(native['t'],t)];b,v,f,w=fld.transpose(1,0,2)
    rhoY=split[:,:,3]+3*H*split[:,:,7]/kk
    rhoM=split[:,:,6]+split[:,:,7]
    actualterms=np.stack((-H*Z,(-1+3*(hp-H**2)/kk)*(rhoM-qj[:,None]),6*mu2*b*v*obs[:,:,0],3*H*v**2*(obs[:,:,3]+3*obs[:,:,0]),
        v*uw[:,None],(mu2*b+3*H*v)*uf[:,None],(aH-H)*(2*mu2*b*f-rhoY),Z*0))
    goal=aperture(phase,actualterms,phase[it]);now=fourier(rt[ix].transpose(3,0,1,2),16);total=goal.sum(1)
    work=rate(now-goal,total[:,None]);swork=rate(now.sum(1)-total,total)
    print(grid,res,'Z representation change on P scale',np.round(pdiff,6),'work replay',np.round(integ_error,8),'H cos/sin errors Z/Q/net',np.round(errors[1:,:,1],2).tolist(),flush=True)
    return dict(grid=grid,res=res,direct_gravity_pct=eq.tolist(),Phi_harmonic_equivalence_pct=induced.tolist(),
        integrated_work_pct=integ_error.tolist(),terminal_Y_equivalence_pct=yerr.tolist(),original_pressure_pct=baseline.tolist(),Z_pressure_pct=changed.tolist(),delta_mean_pressure_drift_pct=pdiff.tolist(),
        heavy_component_pct_of_Hamiltonian_harmonic=errors.tolist(),work_terms_pct_of_temporal_Zprime=work.tolist(),work_sum_pct_of_temporal_Zprime=swork.tolist(),historical_memory_pct=mem_error)
if __name__=='__main__':
    check('Z-freeze.json');p=historic.pre.import_at(historic.pre.OLD,'partial')
    put('Z-scores.json',dict(rows=[evaluate(g,r,p) for g in ('p16','p32') for r in (640,1280)],heavy_parts=['Z','explicit Qe + 3HQj/K','sum'],work_terms=['damping','retarded mean minus explicit current','metric 6mu²bvPhi','metric 3Hv²(Psi+3Phi)','v Qw','(mu²b+3Hv) Qf','clock consistency','background-equation residual'],scorer=sha(ROOT/'score_combined.py'),freeze=sha(ROOT/'Z-freeze.json')))
