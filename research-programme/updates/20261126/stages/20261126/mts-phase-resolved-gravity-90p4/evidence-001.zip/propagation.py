from constraint_budget import *
def diagnostic(tag,grid,res):
    name=f'solved-{tag}-{grid}-{res}.npz';check(name+'.receipt')
    data=read(ROOT/name);angles=read(ROOT/f'angles-{res}.npz');obs=data['obs'];kk=data['k']**2
    def ad(x):return x-x[:,:1]
    def change(x):
        contrast=ad(x);return contrast-contrast[:1]
    def mag(x):return np.max(abs(x),axis=(0,1))
    phi,ep,mom,psi,pd,en,cur,us,den,hub=obs[...,:10].transpose(3,0,1,2)
    need=np.stack((change(den*mom),change(en)/2,1.5*change(hub*cur)/kk))
    required=need.sum(0);supplied=change(us);err=supplied-required
    shadow=change(den*(ep-mom))
    assert np.max(abs(err-shadow))<4e-14*np.max(abs(den*mom))
    original=read(parent(f'driven-{grid}-{res}.npz'));t=original['t'];ix=np.searchsorted(t,angles['centers'])
    reference=aperture(original['phase'],original['metric'][:,:,:1].transpose(2,0,1),original['phase'][ix])
    amplitude=np.max(np.sum(abs(reference[1:,0])**2,axis=0)**.5,axis=0)*abs(den[0,0])
    rows=[]
    for label,subset in [('whole_window',np.arange(len(obs))),('supported_centers',np.searchsorted(data['t'],angles['centers']))]:
        used=need[:,subset];expected=required[subset];given=supplied[subset];residual=err[subset]
        scales=mag(expected);through=sum(mag(v) for v in used);assert min(scales)>0 and min(amplitude)>0
        rows.append(dict(scope=label,missing_pct_of_required=(100*mag(residual)/scales).tolist(),missing_pct_of_throughput=(100*mag(residual)/through).tolist(),
            supplied_pct_of_required=(100*mag(given)/scales).tolist(),error_pct_of_temporal_Phi_harmonic_load=(100*mag(residual)/amplitude).tolist(),
            components_pct_of_required=[(100*mag(v)/scales).tolist() for v in used],supplied_alignment=[float(np.vdot(given[:,:,j],expected[:,:,j]).real/(np.linalg.norm(given[:,:,j])*np.linalg.norm(expected[:,:,j]))) if np.linalg.norm(given[:,:,j]) else None for j in (0,1)]))
    print(tag,grid,res,'supported missing % of required and Phi harmonic',rows[-1]['missing_pct_of_required'],rows[-1]['error_pct_of_temporal_Phi_harmonic_load'],flush=True)
    return dict(grid=grid,res=res,rows=rows,initial_shadow_pct_of_temporal_Phi_load=(100*mag(ad(den*(ep-mom))[:1])/amplitude).tolist())
if __name__=='__main__':
    method=sys.argv[1];out=[diagnostic(method,grid,res) for grid in ('p16','p32') for res in (640,1280)]
    put(method+'-propagation.json',dict(terms=['D times momentum shadow','effective energy/2','3H effective current/(2K)'],rows=out,method=sha(ROOT/'propagation.py')))
