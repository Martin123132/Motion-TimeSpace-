from wave_join_io import *
import ast

def main():
    ensure()
    for parent,expected in PINS.items():assert digest(parent/"seal.json")==expected
    manifests=[]
    for file in ROOT.rglob("*"):
        if file.is_file() and (file.name.endswith((".receipt","-freeze.json","-method.json","-forecast.json")) or file.name in ("method.json","done.json")):
            prior.check(file);manifests.append(file)
    for file in ROOT.glob("*.py"):ast.parse(file.read_text(encoding="utf-8"))
    assert not list(ROOT.rglob("*.partial")) and not list(ROOT.rglob("__pycache__"))
    io,*_=prior.setup_modules();rows=read("photon-scores.json");dense=read("dense-checks.json");orbits=read("orbit-scores.json")
    assert len(rows)==30 and len(orbits)==8
    for grid in GRIDS:
        for model in MODELS:
            out=folder(model,grid);prev=io.sealed(io.CARRY,f"carry-wave-{grid}-4.npz")
            for idx in range(1,16):
                path=out/f"part-wave-{grid}-4-{idx:02d}.npz"
                with np.load(path) as packet:
                    assert packet["parent_hash"].item()==digest(prev) and np.array_equal(packet["t"][[0,-1]],io.edges[idx-1:idx+1])
                    assert packet["lag_end"].shape==(2,77,69) and np.isfinite(packet["lag_end"]).all() and np.isfinite(packet["ordinary_end"]).all()
                    assert max(packet["seam"])<.5 and packet["rhs_identity_pct"]<.5
                prev=path
            with np.load(out/f"carry-wave-{grid}-4.npz") as alltime,np.load(prev) as end,np.load(pinned(PRE,model+"/"+grid+f"/carry-wave-{grid}-4.npz")) as ref:
                for key in ("lag_end","shape_end","ordinary_end"):assert np.array_equal(alltime[key],end[key])
                residual=lambda ar:ar["obs"][:,0,2]-ar["obs"][:,0,1]
                drift=lambda ar:np.max(abs(residual(ar)-residual(ar)[0]))
                assert dense[grid+":"+model]["joined_pct_old"]==100*drift(alltime)/drift(ref)
                assert np.array_equal(ref["obs"][0,:,2],alltime["obs"][0,:,2])
            for setting in ("primary","time","angle"):
                row=rows[setting+":"+grid+":joined-"+model]
                assert row["pass_both"]==(max(row["gap_pct"])<=.5 and max(row["full_launch_pct"])<=.163)
            assert max(orbits[grid+":joined-"+model]["closure_points"])<1e-7
    for grid in GRIDS:
        with np.load(ROOT/f"matched-background-{grid}.npz") as ar:
            np.testing.assert_allclose(ar["T_host"]-ar["T_fluid"],1.5*ar["enthalpy"],rtol=0,atol=1e-12*np.max(abs(ar["enthalpy"])))
            np.testing.assert_allclose(ar["E"]+ar["P"],-ar["enthalpy"],rtol=0,atol=1e-12*np.max(abs(ar["rho"])))
            error=100*np.max(abs(ar["energy_prediction"]-ar["E"]))/np.max(abs(ar["E"]-ar["E"][0]))
            assert error==read("matched-background-checks.json")[grid]["companion_energy_forecast_error_pct"]
        for model in MODELS:
            limit=read("branch-limits.json")[grid+":joined-"+model]
            assert limit["resolved_only_removal_lower_bound"][2]<=limit["if_resolved_agrees"][2]+1e-8
    for file in ("RESULTS.md","PROTOCOL.md","ORBIT-TEST.md","MATCHED-BACKGROUND.md","WINDOW-BUDGET.md","background-checks.json","budget-freeze.json","orbit-freeze.json","dense-freeze.json","matched-freeze.json","limits-freeze.json","scores-freeze.json"):assert (ROOT/file).is_file()
    files={path.relative_to(ROOT).as_posix():digest(path) for path in ROOT.rglob("*") if path.is_file() and path.name!="seal.json"}
    seal=dict(files=files,parents={parent.name:expected for parent,expected in PINS.items()},scope="Window-only second-order resolved-background replacement; original matched and thermal scattering controls, both gravity grids, no fits")
    if sys.argv[1:]==["--seal"]:put("seal.json",seal)
    assert read("seal.json")==seal
    print(len(files),"files,",len(manifests),"receipts, 60 carried intervals; sha256",digest(ROOT/"seal.json"))
if __name__=="__main__":main()
