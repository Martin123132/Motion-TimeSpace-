from wave_join_io import *
def main():
    check("orbit-freeze.json");io,*_=prior.setup_modules()
    import project90
    ph=project90.modules();gate=ph.gate;_,vis,weights,_=ph.proj.old.get_media();measure=gate.previous.make_measure(vis,weights)
    norm=lambda value:gate.mag(value,measure);rows={}
    with np.load(ROOT/"orbit-vectors.npz") as orb,np.load(ROOT/"visibility-primary.npz") as ar,np.load(ph.track(ph.cell89.pin("photon-primary.npz"))) as pre:
        ev=lambda value:CubicSpline(ar["scale"],value)(vis)
        vec=ev(orb["values"]);direct=ev(ar["values"]);keys=orb["labels"].tolist();ids=ar["labels"].tolist()
        for grid in GRIDS:
            small=norm(ev(pre["values"][:,pre["labels"].tolist().index([grid,"primary"]),:3].sum(1)))
            for tag in ("joined-primary","joined-fine"):
                part=lambda name:sum(vec[:,keys.index(grid+":"+name+":"+str(i))] for i in (0,1))
                gap=lambda name:direct[:,ids.index(grid+":"+tag+":density:"+name)]-direct[:,ids.index(grid+":"+tag+":momentum:"+name)]
                total=gap("cumulative");past=total-gap("increment");mat=part("matched");wave=part(tag)
                value=lambda vec:(100*norm(vec)/small).tolist()
                rows[grid+":"+tag]=dict(if_resolved_agrees=value(past+mat),if_matched_agrees=value(past-wave),if_both_agree=value(past),
                                         resolved_only_removal_lower_bound=np.maximum(100*(norm(total)-norm(wave))/small,0).tolist())
                assert np.max(100*norm(total-past-mat+wave)/small)<1e-7
    put("branch-limits.json",rows);record("limits-freeze.json",[ROOT/"branch_limits.py",ROOT/"orbit-freeze.json",ROOT/"branch-limits.json"])
    print(rows,flush=True)
if __name__=="__main__":main()
