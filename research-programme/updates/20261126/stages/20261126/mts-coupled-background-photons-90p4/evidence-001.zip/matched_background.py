from wave_join_io import *
from scipy.integrate import cumulative_simpson

def test(io,sources,p,grid):
    bank=p.MatchedBank()
    def replay_oscillator(name,**arrays):
        with np.load(pinned(HIST,name)) as ar:
            assert set(arrays)==set(ar.files)
            for key,val in arrays.items():np.testing.assert_array_equal(val,ar[key])
    with patch.object(sources,"pack",replay_oscillator):
        src,hist=sources.setup(p,grid,4,"matched",bank)
    with np.load(pinned(HIST,f"carry-matched-{grid}-4.npz")) as ar:
        t=ar["t"];stored=ar["obs"][:,0,8:10].real
    hlist=[];dhost=[];dfluid=[]
    for start in range(0,len(t),256):
        sub=t[start:start+256];bg,den,*_=p.coefficients(src,sub)
        other=src.matched.environment(sub)
        hlist.append(bg["h"]);dhost.append(den);dfluid.append(other[-1])
    H=np.concatenate(hlist);host=np.concatenate(dhost);fluid=np.concatenate(dfluid)
    oscH,mu2,b,v=src.osc(t);a=np.sqrt(mu2)/src.flow.bg(np.log(t))[:,src.flow.bgkeys.index("hm")]
    raw=src.flow.bg(np.log(t));a_ref=raw[:,src.flow.bgkeys.index("a")];hp_tab=raw[:,src.flow.bgkeys.index("hp")]
    assert np.allclose(a,a_ref,rtol=2e-15,atol=0) and np.allclose(H,oscH,rtol=3e-15,atol=0)
    assert np.array_equal(stored[:,0],host) and np.array_equal(stored[:,1],H)
    rates=src.flow.bg(np.log(t),1)/t[:,None];alpha=rates[:,src.flow.bgkeys.index("a")]/a
    hp=rates[:,src.flow.bgkeys.index("h")]
    rho=hist.rho0/a;enthalpy=v*v-rho
    T=host-src.kk+3*(hp-H**2);old=fluid-src.kk+3*(hp-H**2)
    E=rho-(v*v+mu2*b*b)/2;P=-(v*v-mu2*b*b)/2
    peak=lambda x:float(np.max(abs(x)))
    pct=lambda val,scale:100*peak(val)/peak(scale)
    e_rate=(H-alpha)*(rho+mu2*b*b)-H*(E+3*P)
    derivative=make_interp_spline(t,E,k=5)(t,1)
    predicted=E[0]+cumulative_simpson(e_rate,x=t,initial=0)
    checks=dict(host_den_identity_pct=pct(host-fluid-1.5*enthalpy,1.5*enthalpy),T_host_pct_enthalpy=pct(T,1.5*enthalpy),
                T_fluid_pct_enthalpy=pct(old,1.5*enthalpy),metric_identity_defect_pct=pct(hp-hp_tab,hp_tab),
                enthalpy_peak_pct_fluid=pct(enthalpy,rho),mean_signed_enthalpy_pct_fluid=100*np.trapezoid(enthalpy,t)/np.trapezoid(rho,t),
                E_plus_P_identity_pct=pct(E+P+enthalpy,rho),companion_derivative_error_pct=pct(derivative-e_rate,e_rate),
                companion_energy_forecast_error_pct=pct(predicted-E,E-E[0]),companion_energy_change_pct_fluid=pct(E-E[0],rho),
                clock_pct=pct(alpha-H,H),wave_field_identity_pct=pct(make_interp_spline(t,b,k=5)(t,1)-v,v),
                wave_velocity_identity_pct=pct(make_interp_spline(t,v,k=5)(t,1)+2*H*v+mu2*b,mu2*b))
    pack("matched-background-"+grid+".npz",t=t,T_host=T,T_fluid=old,enthalpy=v*v-rho,rho=rho,E=E,P=P,energy_prediction=predicted)
    assert max(checks[key] for key in ("host_den_identity_pct","E_plus_P_identity_pct","companion_derivative_error_pct","companion_energy_forecast_error_pct","wave_field_identity_pct","wave_velocity_identity_pct"))<.5,checks
    return checks
def main():
    check("limits-freeze.json")
    io,sources,_,_,p=engine()
    record("matched-method.json",[ROOT/"MATCHED-BACKGROUND.md",ROOT/"matched_background.py",ROOT/"limits-freeze.json",pinned(HIST,"sources90.py"),pinned(HIST,"stepper.py"),*[pinned(HIST,f"carry-matched-{grid}-4.npz") for grid in GRIDS]])
    stats={grid:test(io,sources,p,grid) for grid in GRIDS}
    put("matched-background-checks.json",stats);record("matched-freeze.json",[ROOT/"matched-method.json",ROOT/"matched-background-checks.json",*[ROOT/("matched-background-"+grid+".npz") for grid in GRIDS]])
    print(stats,flush=True)
if __name__=="__main__":main()
