from wave_join_io import *
pinned(PRE,"constraint_row.py")
import constraint_row

NATIVE={"a":"a","et":"grho","pt":"gpres","h":"adotoa","eg":"grhog_t","er":"grhor_t","ec":"grhoc_t","eb":"grhob_t","enu":"grhonu_t"}
def data(model):
    with np.load(native_packet(model)) as packet:
        time=packet["t"];fields=packet["values"];names=packet["names"].tolist()
        out={}
        for name,key in NATIVE.items():
            field=fields[:,:,names.index(key)]
            assert np.allclose(field,field[:1],rtol=1e-12,atol=0),key
            out[name]=field[0].copy()
    return time,out

def assemble(src,model):
    time,raw=data(model);mask=time>=START
    assert time[mask][0]==START and time[-1]==END
    knots=np.linspace(START,END,3073);log=np.log(knots)
    native={key:make_interp_spline(time[mask],values[mask],k=5)(knots) for key,values in raw.items()}
    original=src.flow.bg;keys=list(src.flow.bgkeys);clock=np.linspace(original.t[0],original.t[-1],2049)
    scales=original(clock)[:,keys.index("a")]
    assert np.all(np.diff(scales)>0) and scales[0]<native["a"][0]<native["a"][-1]<scales[-1]
    remapped=CubicSpline(np.log(scales),clock,extrapolate=False)(np.log(native["a"]))
    bg=dict(zip(keys,original(remapped).T))
    for key in ("a","ec","eb","eg","er","enu"):bg[key]=native[key]
    with np.load(pinned(PILOT,"joined/table-"+model+".npz")) as table:
        wave=CubicSpline(table["x"],np.stack((table["b"],table["v"]),axis=1),bc_type="natural",extrapolate=False)
    position=np.log(bg["a"])
    bg["hb"],bg["hv"]=wave(position).T
    bg["hvN"]=wave(position,1)[:,1];bg["hvNN"]=wave(position,2)[:,1]
    kinetic=(bg["sv"]**2+bg["hv"]**2)/2
    potential=sum((bg["a"]*bg[tag+"m"]*bg[tag+"b"])**2 for tag in ("s","h"))/2
    bg["et"]=bg["eb"]+bg["ec"]+bg["eg"]+bg["er"]+bg["enu"]+kinetic+potential
    bg["pt"]=(bg["eg"]+bg["er"])/3+bg["enm"]-bg["enu"]+kinetic-potential
    bg["h"]=np.sqrt(bg["et"]/3);bg["hp"]=-(bg["et"]+3*bg["pt"])/6
    bg["T0"]=(bg["et"]-3*bg["pt"])/bg["eg"];bg["X0"]=bg["et"]/bg["eg"]
    out=np.column_stack([bg[key] for key in keys]);assert np.isfinite(out).all()
    return knots,keys,out,native

def make_bank(src,bank,model):
    with np.load(ROOT/("background-"+model+".npz")) as ar:
        time=ar["t"];keys=ar["keys"].tolist();values=ar["values"]
    assert keys==list(src.flow.bgkeys)
    src.flow.bg=CubicSpline(np.log(time),values,extrapolate=False)
    bank.bg=CubicSpline(np.log(time),values[:,[keys.index("a"),keys.index("enu")]],extrapolate=False)

def metrics(p,src,bank):
    times=np.linspace(START,END,515)
    rows,_,_,lam=constraint_row.row(p,src,bank,times)
    bg,den,*_=p.coefficients(src,times)
    deriv=dict(zip(src.flow.bgkeys,(src.flow.bg(np.log(times),1)/times[:,None]).T))
    H=bg["h"];v=bg["hv"];field=bg["hb"];mass2=(bg["a"]*bg["hm"])**2
    denrate=(3*(deriv["ec"]+deriv["eb"]+2*(v*deriv["hv"]+bg["sv"]*deriv["sv"]))+4*(deriv["eg"]+deriv["er"])+deriv["nuE"])/2
    rel=lambda val,scale:float(100*np.max(abs(val))/np.max(abs(scale)))
    return dict(field_pct=rel(deriv["hb"]-v,v),velocity_pct=rel(deriv["hv"]+2*H*v+mass2*field,mass2*field),
                scale_clock_pct=rel(deriv["a"]/bg["a"]-H,H),enthalpy_pct=rel(den-src.kk+3*(deriv["h"]-H**2),den-src.kk),
                metric_derivative_pct=rel(deriv["h"]-bg["hp"],bg["hp"]),A_pct_H=rel(H+lam+denrate/den,H))

def main():
    io,srcmod,_,_,p=engine();bank=p.joint.Bank();src,_=srcmod.setup(p,"p32",4,"wave",bank)
    stats={"archived":metrics(p,src,bank)}
    for model in MODELS:
        src,_=srcmod.setup(p,"p32",4,"wave",bank)
        time,keys,out,native=assemble(src,model)
        pack("background-"+model+".npz",t=time,keys=keys,values=out)
        make_bank(src,bank,model)
        stats[model]=metrics(p,src,bank)
        stats[model]["native_replay_pct"]={key:float(100*np.max(abs(out[:,keys.index(key)]-native[key]))/np.max(abs(native[key]))) for key in ("h","et","pt")}
    put("background-checks.json",stats)
    record("background-freeze.json",[ROOT/"PROTOCOL.md",ROOT/"wave_join_io.py",ROOT/"background.py",ROOT/"background-checks.json",PRE/"seal.json",HIST/"seal.json",BANK/"seal.json",PILOT/"seal.json",*[path for model in MODELS for path in (ROOT/("background-"+model+".npz"),pinned(PILOT,"joined/table-"+model+".npz"),native_packet(model))]])
    for model in MODELS:
        assert max(stats[model]["native_replay_pct"].values())<.5
        assert max(stats[model][key] for key in ("field_pct","velocity_pct","scale_clock_pct","enthalpy_pct","metric_derivative_pct"))<.5,stats
    print(stats,flush=True)

if __name__=="__main__":main()
