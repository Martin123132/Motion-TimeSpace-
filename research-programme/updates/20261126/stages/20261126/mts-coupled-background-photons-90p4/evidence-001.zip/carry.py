from wave_join_io import *
from importlib.util import spec_from_file_location,module_from_spec
_spec=spec_from_file_location("coupled_background_stage",ROOT/"background.py")
_background=module_from_spec(_spec);_spec.loader.exec_module(_background)
make_bank=_background.make_bank
pinned(PRE,"evolve_response.py")
from evolve_response import forecast

def carry(io,sources,step,runner,p,model,grid):
    out=folder(model,grid);out.mkdir(parents=True,exist_ok=True)
    ensure();check("background-freeze.json")
    initial=io.sealed(io.CARRY,"carry-wave-"+grid+"-4.npz")
    record(out.relative_to(ROOT)/"method.json",[ROOT/"carry.py",ROOT/"background-freeze.json",initial,pinned(BANK,"driving-"+model+".npz"),pinned(BANK,"driving-original.npz"),pinned(PRE,"evolve_response.py"),pinned(HIST,"evolve90.py"),pinned(HIST,"stepper.py")])
    wave,keys,delta=forecast(model);bank=p.joint.Bank()
    def install(*args):
        src,hist=sources.setup(*args);assert hist is None and abs(wave-src.wave)<1e-12
        base=src.flow.q;indices=[list(src.flow.qkeys).index(key) for key in keys]
        def changed(log):
            values=base(log);values[...,indices,0]+=delta(log)
            return values
        src.flow.q=changed
        make_bank(src,bank,model)
        return src,None
    with ExitStack() as scope:
        for module in (step,runner):
            for name,value in (("ROOT",out),("pack",lambda key,**arrays:prior.pack(out/key,**arrays)),("guard",ensure)):
                scope.enter_context(patch.object(module,name,value))
        scope.enter_context(patch.object(runner,"setup",install))
        scope.enter_context(patch.object(runner,"freeze",lambda name,keys:prior.record(out/name,[out/key for key in keys])))
        scope.enter_context(patch.object(runner,"check",lambda name:prior.check(out/name)))
        runner.branch(p,grid,4,"wave",bank)
    outputs=sorted(out.glob("*.npz.receipt"))
    assert len(outputs)==15
    record(out.relative_to(ROOT)/"done.json",[out/"method.json",*outputs,out/f"carry-wave-{grid}-4.npz"])

def main():
    io,sources,step,runner,p=engine()
    for model in MODELS:
        for grid in GRIDS:
            complete=folder(model,grid)/"done.json"
            if not complete.exists():carry(io,sources,step,runner,p,model,grid)
            prior.check(complete)
    record("gravity-forecast.json",[ROOT/"background-freeze.json",*[folder(model,grid)/"done.json" for model in MODELS for grid in GRIDS]])
if __name__=="__main__":main()
