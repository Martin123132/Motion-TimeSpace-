from pathlib import Path
from functools import lru_cache
import hashlib
import sys
import json

ROOT=Path(__file__).resolve().parent
BASE=ROOT.parent
PRE=BASE/"mts-live-resolved-response-90p4-20261126"
PILOT=BASE/"mts-live-canonical-background-90p4-20261126"
PINS={PRE:"3bba23b10d0a608a66d3ad31cca478a5a13e9ccd6b6095841dadd9e877dc70ce",PILOT:"04a7bcc139b5711a8bce030d7282893bfaaf5843666fcd13f8df859669ab5c24"}
def digest(path):
    with path.open("rb") as stream:return hashlib.file_digest(stream,"sha256").hexdigest()
@lru_cache(maxsize=None)
def pinned(folder,name):
    assert digest(folder/"seal.json")==PINS[folder]
    path=folder/name
    manifest=json.loads((folder/"seal.json").read_bytes())
    expected=manifest["files"][name] if "files" in manifest else manifest[path.relative_to(BASE).as_posix()]
    assert digest(path)==expected,path
    return path
pinned(PRE,"response_io.py")
sys.path.insert(0,str(PRE))
import response_io as prior
import numpy as np
from scipy.interpolate import CubicSpline,make_interp_spline
from unittest.mock import patch
from contextlib import ExitStack
for folder,value in prior.PINS.items():PINS[folder]=value
BANK=prior.BANK
HIST=prior.HIST
START,END=prior.START,prior.END
GRIDS=prior.GRIDS
MODELS=("primary","fine")
def ensure():
    prior.guard()
    assert not any((folder/"STOP-REQUESTED").exists() for folder in (ROOT,PILOT))
def put(name,value):
    ensure();prior.put(ROOT/name,value)
def pack(name,**value):
    ensure();prior.pack(ROOT/name,**value)
def record(name,files):
    ensure();prior.record(ROOT/name,files)
def check(name):
    ensure();prior.check(ROOT/name)
def read(name):return prior.obj(ROOT/name)
def engine():
    context=prior.setup_modules()
    prefix=context[0].oldio.prefix()
    return (*context,prefix.import_at(prefix.OLD,"partial"))
def folder(model,grid):return ROOT/model/grid
def native_packet(model):return pinned(BANK,"bank/"+model+"-00.npz")
