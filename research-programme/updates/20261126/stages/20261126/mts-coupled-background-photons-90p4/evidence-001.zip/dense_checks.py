from wave_join_io import *
def main():
    check("state-budget-freeze.json");result={}
    for grid in GRIDS:
        for model in MODELS:
            name=f"carry-wave-{grid}-4.npz"
            with np.load(folder(model,grid)/name) as new,np.load(pinned(PRE,model+"/"+grid+"/"+name)) as old,np.load(ROOT/f"residual-budget-{grid}-{model}.npz") as knots:
                assert np.array_equal(new["t"],old["t"])
                t=new["t"];ind=np.searchsorted(t,knots["t"]);assert np.array_equal(t[ind],knots["t"])
                get=lambda ar:ar["obs"][:,0,2]-ar["obs"][:,0,1]
                before,after=get(old),get(new)
                oldscale=np.max(abs(before-before[0]));drift=after-after[0]
                row=dict(full_mesh_count=len(t),old_drift=float(oldscale),joined_drift=float(np.max(abs(drift))),
                         joined_pct_old=100*np.max(abs(drift))/oldscale,worst_time=float(t[np.argmax(abs(drift))]),
                         sixteen_knots_pct_dense_peak=100*np.max(abs(drift[ind]))/np.max(abs(drift)),maximum_seam_pct=float(np.max(new["seams"])),
                         native_RHS_check_pct=float(np.max(new["identities"])),initial_stored_curvature_identical=bool(np.array_equal(new["obs"][0,:,2],old["obs"][0,:,2])))
                assert row["initial_stored_curvature_identical"] and max(row["maximum_seam_pct"],row["native_RHS_check_pct"])<.5
                result[grid+":"+model]=row
    put("dense-checks.json",result);record("dense-freeze.json",[ROOT/"dense_checks.py",ROOT/"state-budget-freeze.json",ROOT/"dense-checks.json"])
    print(result,flush=True)
if __name__=="__main__":main()
