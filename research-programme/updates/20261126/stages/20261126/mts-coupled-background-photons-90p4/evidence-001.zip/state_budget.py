from wave_join_io import *
from importlib.util import spec_from_file_location,module_from_spec
_spec=spec_from_file_location("joined_pair_runner",ROOT/"carry.py")
_runner=module_from_spec(_spec);_spec.loader.exec_module(_runner)
make_bank,forecast=_runner.make_bank,_runner.forecast

def environment(p,sources,grid,model,joined):
    bank=p.joint.Bank();src,_=sources.setup(p,grid,4,"wave",bank)
    if joined:make_bank(src,bank,model)
    _,keys,delta=forecast(model);indices=[list(src.flow.qkeys).index(k) for k in keys];raw=src.flow.q
    def changed(log):
        out=raw(log);out[...,indices,0]+=delta(log)
        return out
    src.flow.q=changed
    return src,bank

def read_state(path):
    with np.load(path) as ar:return (ar["ordinary_end"],ar["lag_end"],ar["shape_end"])

def residual(p,src,bank,t,state):
    fields,lag,shape=state;bg,den,we,wj,e0,j0,slip,u,fq=p.coefficients(src,np.array([t]))
    _,_,kernel,weights=bank.coeff(np.array([t]));stress=bank.stress(lag,shape,kernel[0],weights[0])*bg["enu"][0]
    energy=fields@we[0]+e0[0]+stress[:,0];current=fields@wj[0]+j0[0]+src.wave*stress[:,1]
    return fields[:,12]-(u[0]-energy/2-1.5*bg["h"][0]*current/src.kk)/den[0]

def main():
    check("gravity-forecast.json");io,sources,_,_,p=engine();results={}
    for grid in GRIDS:
        first=io.sealed(io.CARRY,f"carry-wave-{grid}-4.npz")
        for model in MODELS:
            old=environment(p,sources,grid,model,False);new=environment(p,sources,grid,model,True)
            vals=[]
            for idx,t in enumerate(io.edges):
                name=f"part-wave-{grid}-4-{idx:02d}.npz"
                before=read_state(pinned(PRE,model+"/"+grid+"/"+name) if idx else first)
                after=read_state(folder(model,grid)/name if idx else first)
                vals.append([residual(p,*old,t,before),residual(p,*new,t,before),residual(p,*new,t,after)])
            orig,fixed,live=np.stack(vals).transpose(1,0,2)
            for mat,kind in ((orig,"prior"),(live,"current")):
                packet=pinned(PRE,model+"/"+grid+f"/carry-wave-{grid}-4.npz") if kind=="prior" else folder(model,grid)/f"carry-wave-{grid}-4.npz"
                with np.load(packet) as ar:
                    index=np.searchsorted(ar["t"],io.edges)
                    assert np.array_equal(ar["t"][index],io.edges)
                    measured=ar["obs"][index,:,2]-ar["obs"][index,:,1]
                assert np.max(abs(mat-measured))<=5e-12*np.max(abs(measured))+1e-32
            delta=lambda v:v-v[:1]
            sums=[delta(v[:,0]) for v in (orig,fixed,live)]
            olddrift,atfixed,actual=sums;change=actual-olddrift;scale=np.max(abs(olddrift))
            pct=lambda vec:float(100*np.max(abs(vec))/scale)
            stats=dict(old_drift_at_knots=float(scale),joined_drift_at_knots=float(np.max(abs(actual))),
                       joined_pct_old=pct(actual),difference_pct_old=pct(change),coefficient_only_pct_old=pct(atfixed-olddrift),
                       state_response_pct_old=pct(actual-atfixed),entry_readout_change_pct_old=float(100*abs(live[0,0]-orig[0,0])/scale),
                       absolute_residual_ratio_peak=float(np.max(abs(live[:,0]))/np.max(abs(orig[:,0]))))
            pack("residual-budget-"+grid+"-"+model+".npz",t=io.edges,old=orig,coefficient_only=fixed,joined=live)
            results[grid+":"+model]=stats
    put("state-budget.json",results)
    record("state-budget-freeze.json",[ROOT/"state_budget.py",ROOT/"gravity-forecast.json",ROOT/"state-budget.json",*sorted(ROOT.glob("residual-budget-*.npz"))])
    print(results,flush=True)
if __name__=="__main__":main()
