from scipy.interpolate import make_interp_spline
from lapse_stage import ROOT,TWIN,KIN,np,CASES,DRIVES,pinned,pack,table,freeze,locked,safe,wave_input
pinned(TWIN,'native_pair.py')
from native_pair import stress_curve

def prepare():
    safe();locked('protocol-freeze.json')
    with np.load(wave_input('material-halfstep/forcing-heavy.npz')) as bank:
        idx=bank['bgkeys'].tolist().index('enu')
        normalization=make_interp_spline(np.log(bank['eta']),bank['background'][idx],k=5)
    curves=[stress_curve(m,4) for m in DRIVES[:2]]
    rows=[]
    for mode,sub in CASES:
        with np.load(pinned(KIN,f'absolute-{mode}-{sub}.npz')) as archive:
            t=archive['cuts'];kk=archive['kk'].item()
        clock=np.empty(2*len(t)-1);clock[::2]=t;clock[1::2]=(t[1:]+t[:-1])/2
        vals=np.zeros((len(clock),4,3),complex)
        for idx,curve in enumerate(curves):
            vals[:,:,idx]=curve(np.log(clock))*normalization(np.log(clock))[:,None]
            vals[:,1,idx]*=np.sqrt(kk)
            assert np.linalg.norm(vals[:,:,idx])>0
        assert np.all(np.diff(clock)>0) and not vals[0].any() and np.isfinite(vals).all()
        pack(f'drive-{mode}-{sub}.npz',t=t,clock=clock,physical=vals,kk=kk,drives=DRIVES)
        rows.append(dict(mode=mode,sub=sub,times=len(t),fine_peak=max(abs(vals[:,2,0])),coarse_peak=max(abs(vals[:,2,1]))))
    table('input-audit.csv',rows)
    freeze('input-freeze.json',['protocol-freeze.json','input-audit.csv']+[f'drive-{m}-{s}.npz' for m,s in CASES])
if __name__=='__main__':prepare()
