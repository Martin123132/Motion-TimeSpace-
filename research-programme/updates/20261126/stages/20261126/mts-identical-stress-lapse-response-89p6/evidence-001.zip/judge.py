from scipy.interpolate import CubicSpline
from lapse_stage import ROOT,KIN,TWIN,CASES,DRIVES,np,table,freeze,locked,pinned,rms,sha,safe
NAMES=['phi','fixed_shear','photon_shear','collisionless_shear','response_shear','induced_lapse','lapse','wave_total','wave_phi','wave_fixed','wave_photon','wave_collisionless','wave_induced','direct_heavy','int_heavy','int_other','int_external','int_lapse']
def load(mode,sub,branch):
    files=[ROOT/f'{kind}-{branch}-{mode}-{sub}.npz' for kind in ('response','wave')]
    with np.load(files[0]) as ar,np.load(files[1]) as w:
        t=ar['t']
        assert np.array_equal(t,w['t']) and ar['input_hash'].item()==sha(ROOT/f'drive-{mode}-{sub}.npz')
        data=np.concatenate([ar['geom'],w['momentum'],ar['heavy'][:,:,None],ar['budget']],axis=2)
        assert np.isfinite(data).all() and not data[:,2,:].any()
        return t,data[:,:2,:]
def inner(t,x,y):return np.trapezoid(np.real(x*y.conj()),t)/(t[-1]-t[0])
def run():
    safe();locked('reference-freeze.json');locked('averaged-freeze.json')
    rows=[];replay=[];clocks=[];parts=[];all_data={}
    for mode,sub in CASES:
        for branch in ('native','averaged','plain'):all_data[mode,sub,branch]=load(mode,sub,branch)
        t,ref=all_data[mode,sub,'native']
        with np.load(pinned(KIN,f'anchored-{mode}-{sub}.npz')) as ar:edge=ar['first_end'].item()
        with np.load(pinned(TWIN,f'native-{mode}-{sub}.npz')) as old:
            assert np.array_equal(t,old['times'])
            for j,tag in enumerate(DRIVES[:2]):
                pairs=[('current',ref[:,j,13],old['fixed_'+tag])]
                if sub==4 and mode==tag:pairs.extend([('phi',ref[:,j,0],old['native_geometry'][:,0]),('psi',ref[:,j,6],old['native_geometry'][:,1])])
                for what,x,y in pairs:
                    e=100*rms(t,x-y)/rms(t,y);replay.append(dict(mode=mode,sub=sub,source=tag,channel=what,error_pct=e,passed=bool(e<=.5)))
        for branch in ('averaged','plain'):
            data=all_data[mode,sub,branch][1];stack=np.stack([ref,data],axis=-1)
            cubic=CubicSpline(t,stack,axis=0)
            for win,lo,hi in [('full',t[0],t[-1]),('first',t[0],edge),('later',edge,t[-1])]:
                tick=np.unique(np.r_[lo,t[(t>lo)&(t<hi)],hi]);actual,test=cubic(tick).transpose(3,0,1,2)
                for j,tag in enumerate(DRIVES[:2]):
                    target=actual[:,j];v=test[:,j];den=rms(tick,target);d=v-target;err=rms(tick,d);assert np.all(den>0)
                    for idx,k in enumerate(NAMES):
                        common=6 if idx<7 else 7 if idx<14 else 0
                        rows.append(dict(branch=branch,mode=mode,sub=sub,source=tag,window=win,channel=k,error_pct=100*err[idx]/den[idx],error_pct_of_total=100*err[idx]/den[common],native_rms=den[idx],pass_relative=bool(err[idx]<=.005*den[idx])))
                    for main,inds in [(6,[0,1,2,3]),(7,[8,9,10,11]),(0,[14,15,16,17])]:
                        norm=inner(tick,d[:,main],d[:,main])
                        fractions=[100*inner(tick,d[:,i],d[:,main])/norm for i in inds]
                        for i,frac in zip(inds,fractions):parts.append(dict(branch=branch,mode=mode,sub=sub,source=tag,window=win,total=NAMES[main],component=NAMES[i],signed_error_share_pct=frac))
    for lo,hi in [(('p16',4),('p32',4)),(('p16',2),('p16',4)),(('p32',2),('p32',4))]:
        for branch in ('native','averaged','plain'):
            t,d=all_data[*lo,branch];u,r=all_data[*hi,branch]
            assert t[0]==u[0] and t[-1]==u[-1]
            ref=CubicSpline(u,r)(t)
            for j,tag in enumerate(DRIVES[:2]):
                for idx in [0,4,5,6,7,12,13]:
                    e=100*rms(t,d[:,j,idx]-ref[:,j,idx])/rms(t,ref[:,j,idx])
                    clocks.append(dict(low=str(lo),high=str(hi),branch=branch,source=tag,channel=NAMES[idx],error_pct=e,passed=bool(e<=.5)))
    for name,data in [('frozen-comparisons',rows),('native-replay',replay),('clock-tests',clocks),('signed-error-shares',parts)]:table(name+'.csv',data)
    freeze('score-receipt.json',['reference-freeze.json','averaged-freeze.json','frozen-comparisons.csv','native-replay.csv','clock-tests.csv','signed-error-shares.csv'])
if __name__=='__main__':run()
