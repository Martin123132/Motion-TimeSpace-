import hashlib,json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent
TWIN=ROOT.parent/'mts-paired-wave-momentum-reference-89p6-20261125'
def sha(path):
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
seal='6e7e5a20c817a89e665f800537dc2774e8295e6117e0ff08a9d45a990c65520c'
assert sha(TWIN/'seal.json')==seal
assert sha(TWIN/'twin_stage.py')==json.loads((TWIN/'seal.json').read_bytes())['files']['twin_stage.py']
sys.path.insert(0,str(TWIN))
from twin_stage import np,common,window,KIN,FIRST,CASES,pinned,pack,table,freeze,locked,rms,wave_input
common.PINS={**common.PINS,TWIN:seal}
window.ROOT=common.ROOT=ROOT
DRIVES=('p32','p16','null')
def safe():window.safe()
if __name__=='__main__':
    safe()
    freeze('protocol-freeze.json',['PROTOCOL.md','lapse_stage.py','identical_input.py','respond.py','project_wave.py','judge.py'])
