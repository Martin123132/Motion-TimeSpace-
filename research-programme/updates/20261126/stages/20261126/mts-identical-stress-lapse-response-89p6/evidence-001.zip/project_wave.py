import sys
from scipy.interpolate import CubicSpline, make_interp_spline
from scipy.integrate import solve_ivp
from lapse_stage import ROOT, KIN, TWIN, CASES, np, pinned, pack, table, freeze, locked, safe, wave_input, rms
pinned(TWIN,'native_pair.py')
from native_pair import make

def background(times,mode,sub,native):
    if native:
        with np.load(wave_input('material-halfstep/forcing-heavy.npz')) as bank:
            keys=bank['bgkeys'].tolist()
            curve=make_interp_spline(np.log(bank['eta']),bank['background'][[keys.index(k) for k in ('a','h','hm','hb','hv')]].T,k=5)
        def get(t):
            scale,hub,mass,field,vel=curve(np.log(t)).T
            return hub,(scale*mass)**2,field,vel
    else:
        with np.load(pinned(KIN,f'absolute-{mode}-{sub}.npz')) as arc:
            initial=arc['entry'];mass,rho=arc['controls'][:2];kin=arc['kinetic']
        src,_,_,_,_=make(mode,'matched',sub);bg=src.environment(times)[0]
        hub=CubicSpline(times,bg['h']);scale=CubicSpline(times,bg['a'])
        def rhs(t,state):return [state[1],-2*hub(t)*state[1]-(mass*scale(t))**2*state[0]]
        sol=solve_ivp(rhs,(times[0],times[-1]),initial,dense_output=True,method='DOP853',rtol=2e-12,atol=[1e-16,1e-15],max_step=.0015)
        assert sol.success and np.max(abs(sol.sol(times)[1]**2*bg['a']/rho-1-kin))/max(abs(kin))<.005
        def get(t):
            field,vel=sol.sol(t);return hub(t),(scale(t)*mass)**2,field,vel
    return get

def run(mode,sub,stage):
    native=stage=='native'
    with np.load(ROOT/f'drive-{mode}-{sub}.npz') as arc:times=arc['t'];kk=arc['kk'].item()
    get=background(times,mode,sub,native)
    clock=np.empty(2*len(times)-1);clock[::2]=times;clock[1::2]=(times[:-1]+times[1:])/2
    hub,mass2,field,vel=get(clock);rows=[]
    for label in (['native'] if native else ['averaged','plain']):
        with np.load(ROOT/f'response-{label}-{mode}-{sub}.npz') as arc:
            geom=CubicSpline(times,arc['geom'],extrapolate=False)(clock);direct=arc['heavy']
        phi,shear,gamma,nu,_,induced,total=geom.transpose(2,0,1)
        zero=np.zeros_like(phi)
        p=np.stack([phi,phi,zero,zero,zero,phi],axis=2)
        v=np.stack([total,phi,shear,gamma,nu,induced],axis=2)
        drive=np.stack([vel[:,None,None]*(v+3*p),(mass2*field)[:,None,None]*(3*p-v)],axis=1)
        state=np.zeros((2,3,6),complex);out=np.zeros((len(times),3,6),complex)
        def rhs(i,val):
            return drive[i]+np.stack([val[1],-(kk+mass2[i])*val[0]-2*hub[i]*val[1]])
        for idx,width in enumerate(np.diff(times)):
            if idx%256==0:safe()
            i=2*idx
            one=rhs(i,state);two=rhs(i+1,state+width*one/2);three=rhs(i+1,state+width*two/2);four=rhs(i+2,state+width*three)
            state+=width/6*(one+2*two+2*three+four)
            out[idx+1]=kk*vel[i+2]*state[0]
        assert not out[:,2].any() and np.isfinite(out).all()
        for j,tag in enumerate(('fine','coarse')):
            def err(a,b):return 100*rms(times,a-b)/rms(times,b)
            cur=out[:,j,:];sumcheck=err(cur[:,1:5].sum(1),cur[:,0]);indcheck=err(cur[:,[1,3,4]].sum(1),cur[:,5])
            directcheck=err(cur[:,0],direct[:,j]) if native else None
            assert max(sumcheck,indcheck,directcheck or 0)<=.5,(sumcheck,indcheck,directcheck)
            rows.append(dict(branch=label,mode=mode,sub=sub,input=tag,sum_pct=sumcheck,induced_sum_pct=indcheck,native_direct_pct=directcheck))
        pack(f'wave-{label}-{mode}-{sub}.npz',t=times,momentum=out)
    return rows
def main(stage):
    assert stage in ('native','averaged');receipt=f'{stage}-metric-freeze.json';locked(receipt);rows=[]
    for mode,sub in CASES:rows.extend(run(mode,sub,stage))
    name=f'{stage}-wave-controls.csv';table(name,rows)
    freeze('reference-freeze.json' if stage=='native' else 'averaged-freeze.json',[receipt,name]+sorted({f'wave-{r["branch"]}-{r["mode"]}-{r["sub"]}.npz' for r in rows}))
if __name__=='__main__':main(sys.argv[1])
