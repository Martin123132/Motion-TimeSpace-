import sys
from scipy.interpolate import CubicSpline
from lapse_stage import ROOT, KIN, TWIN, CASES, DRIVES, np, pinned, pack, table, freeze, locked, safe, sha
pinned(TWIN,'native_pair.py')
from native_pair import make, operator, DIM, QI, QN

def run(mode,sub,native):
    drive_file=ROOT/f'drive-{mode}-{sub}.npz'
    with np.load(drive_file) as arc:
        times=arc['t'];physical=arc['physical'];kk=arc['kk'].item()
    with np.load(pinned(KIN,f'absolute-{mode}-{sub}.npz')) as arc:
        kinetic=CubicSpline(times,arc['kinetic'],extrapolate=False)
    src,solver,_,_,_=make(mode,'wave' if native else 'matched',sub)
    assert kk==src.kk
    variants=['native'] if native else ['averaged','plain']
    columns=3*len(variants);state=np.zeros((DIM,columns),complex)
    saved=np.zeros((len(times),5,columns),complex);budget=np.zeros((len(times),4,columns),complex)
    defect=np.zeros(2);scale=np.zeros(2);keys=[12,QI,QN,10,11]
    for begin in range(0,len(times)-1,32):
        safe();end=min(begin+32,len(times)-1);left,right=times[begin:end],times[begin+1:end+1];mid=(left+right)/2
        steps=[]
        for which,clock in enumerate((left,mid,right)):
            env=solver.env(clock,mid);bg=env[0]
            mat,bi,bn=operator(solver,clock,mid);mat[:,:13,QI]+=bi;mat[:,:13,QN]+=bn
            tensor=physical[2*np.arange(begin,end)+which]
            sigma=tensor[:,2]/kk;current=tensor[:,1]/(2*kk)
            inj=np.zeros((len(clock),DIM,3),complex)
            def put(index,coef):inj[:,index]=coef[:,None]*sigma
            put(1,kk*(4/3+bg['eb']/bg['eg']));inj[:,4]=src.wave*sigma/3;inj[:,6]=kk*sigma
            put(8,bg['sv']);put(9,-(bg['a']*bg['sm'])**2*bg['sb'])
            if native:
                put(10,bg['hv']);put(11,-(bg['a']*bg['hm'])**2*bg['hb'])
            else:inj[:,11]=kk*sigma
            inj[:,12]=current-bg['h'][:,None]*sigma
            rep=len(variants)
            coeff=np.column_stack([bg['eg'],4*bg['er']+bg['nuS'],bg['h'],bg['ec'],bg['sv'],src.wave*(4*bg['er']+bg['nuJ']),kk*bg['hv'] if native else env[-2],kinetic(clock)])
            steps.append((mat[:,:,:DIM],np.tile(inj,(1,1,rep)),np.tile(sigma,(1,rep)),np.tile(current,(1,rep)),coeff))
        for idx,width in enumerate(right-left):
            def deriv(which,trial):
                mat,inj,slip,fixed,coef=steps[which]
                eg,nus,hub,ec,sv,rad,heavy,factor=coef[idx]
                psi=trial[12]+slip[idx]-(eg*trial[QI]+nus*trial[QN])/kk
                res=mat[idx]@trial+inj[idx]
                if not native:
                    res[10,:3]+=3*factor*res[12,:3];res[11,:3]+=factor*kk*psi[:3]
                rates=np.stack([heavy*trial[10 if native else 11]/(2*kk),(eg*trial[1]+rad*trial[4]+ec*trial[6]+kk*sv*trial[8])/(2*kk),fixed[idx],-hub*psi])
                check=np.stack([rates.sum(0),kk*psi-hub*trial[6]])
                np.maximum(defect,np.max(abs(check-res[[12,6]]),axis=1),out=defect)
                np.maximum(scale,np.max(abs(check),axis=1),out=scale)
                return res,rates
            one,ra=deriv(0,state);two,rb=deriv(1,state+width*one/2);three,rc=deriv(1,state+width*two/2);four,rd=deriv(2,state+width*three)
            state+=width/6*(one+2*two+2*three+four);pos=begin+idx+1
            budget[pos]=budget[pos-1]+width/6*(ra+2*rb+2*rc+rd);saved[pos]=state[keys]
    env=solver.env(times);bg=env[0];rows=[]
    for idx,label in enumerate(variants):
        cols=slice(3*idx,3*idx+3);phi,qi,qn,hf,hw=saved[:,:,cols].transpose(1,0,2)
        shear=physical[::2,2,:]/kk;gam=-bg['eg'][:,None]*qi/kk;nu=-(4*bg['er']+bg['nuS'])[:,None]*qn/kk
        induced=phi+(gam+nu);geom=np.stack([phi,shear,gam,nu,gam+nu,induced,induced+shear],axis=-1)
        curr=kk*bg['hv'][:,None]*hf if native else env[-2][:,None]*hw
        integrated=budget[:,:,cols].transpose(0,2,1)
        checks=[*list(100*defect/scale),100*np.max(abs(phi-integrated.sum(2)))/np.max(abs(phi))]
        assert np.isfinite(geom).all() and np.isfinite(curr).all() and np.isfinite(checks).all()
        assert not np.any(saved[:,:,3*idx+2]) and not np.any(geom[:,2]) and max(checks)<=.5,checks
        pack(f'response-{label}-{mode}-{sub}.npz',t=times,geom=geom,heavy=curr,budget=integrated,input_hash=sha(drive_file),drives=DRIVES)
        rows.append(dict(branch=label,mode=mode,sub=sub,potential_rate_pct=checks[0],cold_acceleration_pct=checks[1],curvature_integral_pct=checks[2],null_max=0))
    return rows

def main(stage):
    assert stage in ('native','averaged');native=stage=='native'
    parent='averaged-freeze.json' if native else 'input-freeze.json'
    safe();locked(parent);rows=[]
    for mode,sub in CASES:rows.extend(run(mode,sub,native))
    name=f'{stage}-metric-controls.csv';table(name,rows)
    freeze(f'{stage}-metric-freeze.json',[parent,name]+[f'response-{r["branch"]}-{r["mode"]}-{r["sub"]}.npz' for r in rows])
if __name__=='__main__':main(sys.argv[1])
