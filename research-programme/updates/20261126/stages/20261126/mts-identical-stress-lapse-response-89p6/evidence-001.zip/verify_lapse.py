import ast,csv,sys
from collections import defaultdict
from lapse_stage import ROOT,TWIN,CASES,DRIVES,np,locked,freeze,pinned,sha,safe
def rows(name):
    with (ROOT/name).open() as stream:return list(csv.DictReader(stream))
def verify(seal=False):
    safe()
    for rec in ['protocol','input','averaged-metric','averaged','native-metric','reference']:
        locked(rec+'-freeze.json')
    locked('score-receipt.json')
    for fn,count in [('native-replay.csv',12),('clock-tests.csv',126),('frozen-comparisons.csv',864),('signed-error-shares.csv',576)]:
        data=rows(fn);assert len(data)==count,(fn,len(data),count)
        for row in data:
            if 'error_pct' in row:
                e=float(row['error_pct'])
                assert 0<=e<np.inf and (e<=.5)==(row.get('passed',row.get('pass_relative'))=='True')
    groups=defaultdict(float)
    for row in rows('signed-error-shares.csv'):
        key=tuple(row[k] for k in ('branch','mode','sub','source','window','total'))
        groups[key]+=float(row['signed_error_share_pct'])
    assert len(groups)==144 and max(abs(v-100) for v in groups.values())<=.5
    for m,s in CASES:
        with np.load(ROOT/f'drive-{m}-{s}.npz') as a:
            assert a['physical'].shape==(2*len(a['t'])-1,4,3) and a['drives'].tolist()==list(DRIVES)
            assert np.array_equal(a['clock'][::2],a['t']) and not np.any(a['physical'][:,:,2])
            shear=a['physical'][::2,2,:]/a['kk'].item()
        for branch in ('native','averaged','plain'):
            with np.load(ROOT/f'response-{branch}-{m}-{s}.npz') as b:
                dat=b['geom'];assert np.array_equal(dat[:,:,1],shear) and not dat[0].any()
                assert np.array_equal(dat[:,:,5],dat[:,:,0]+dat[:,:,4]) and np.array_equal(dat[:,:,6],dat[:,:,5]+shear)
                assert b['input_hash'].item()==sha(ROOT/f'drive-{m}-{s}.npz')
            with np.load(ROOT/f'wave-{branch}-{m}-{s}.npz') as w:assert not w['momentum'][0].any() and not w['momentum'][:,2].any()
    assert all(r['passed']=='True' for r in rows('native-replay.csv'))
    for file in ROOT.glob('*.py'):ast.parse(file.read_text())
    assert not list(ROOT.glob('__pycache__'))
    if seal:
        locked('budget-receipt.json');locked('budget-trial-freeze.json')
        diag=rows('one-way-current-budget.csv')
        assert len(diag)==8 and all(0<float(r['quadrature_check_pct'])<=.5 and 0<float(r['residual_pct_of_original_error'])<100 for r in diag)
        assert (ROOT/'RESULTS.md').is_file();freeze('seal.json',sorted(p.name for p in ROOT.iterdir() if p.is_file() and p.name!='seal.json'));locked('seal.json');print(sha(ROOT/'seal.json'))
    else:print('Numerical receipts, score labels and null controls verified.')
if __name__=='__main__':verify('--seal' in sys.argv)
