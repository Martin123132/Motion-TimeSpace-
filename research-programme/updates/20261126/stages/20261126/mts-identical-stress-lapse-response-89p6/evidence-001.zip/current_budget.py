from scipy.interpolate import CubicSpline
from scipy.integrate import cumulative_trapezoid
from lapse_stage import ROOT,TWIN,CASES,DRIVES,np,pack,table,freeze,locked,pinned,rms,safe
pinned(TWIN,'native_pair.py')
from native_pair import make

def diagnose():
    safe();locked('averaged-freeze.json');locked('score-receipt.json')
    for mode,sub in CASES:
        with np.load(ROOT/f'response-averaged-{mode}-{sub}.npz') as arc,np.load(ROOT/f'wave-averaged-{mode}-{sub}.npz') as wav:
            t=arc['t'];phi=arc['geom'][:,:,0];direct=arc['heavy'];projected=wav['momentum'][:,:,0]
        src,_,_,_,_=make(mode,'matched',sub)
        hub=src.environment(t)[0]['h']
        primitive=CubicSpline(t,hub).antiderivative()
        weight=np.exp(primitive(t)-primitive(t[0]))
        integrand=weight[:,None]*(projected-direct)/(2*src.kk)
        solution=CubicSpline(t,integrand).antiderivative()
        change=(solution(t)-solution(t[0]))/weight[:,None]
        trap=cumulative_trapezoid(integrand,t,axis=0,initial=0)/weight[:,None]
        assert not change[0].any() and not change[:,2].any() and np.isfinite(change).all()
        pack(f'budget-trial-{mode}-{sub}.npz',t=t,one_way_phi=phi+change,change=change,quadrature=trap)
    freeze('budget-trial-freeze.json',['score-receipt.json','current_budget.py']+[f'budget-trial-{m}-{s}.npz' for m,s in CASES])
    locked('budget-trial-freeze.json');rows=[]
    for mode,sub in CASES:
        with np.load(ROOT/f'budget-trial-{mode}-{sub}.npz') as a,np.load(ROOT/f'response-native-{mode}-{sub}.npz') as b,np.load(ROOT/f'response-averaged-{mode}-{sub}.npz') as c:
            t=a['t'];trial=a['one_way_phi'];change=a['change'];other=a['quadrature'];native=b['geom'][:,:,0];old=c['geom'][:,:,0]
            for idx,source in enumerate(DRIVES[:2]):
                norm=rms(t,native[:,idx]);before=rms(t,old[:,idx]-native[:,idx]);after=rms(t,trial[:,idx]-native[:,idx]);cross=100*rms(t,change[:,idx]-other[:,idx])/rms(t,change[:,idx])
                assert cross<=.5
                rows.append(dict(mode=mode,sub=sub,source=source,original_curvature_error_pct=100*before/norm,one_way_error_pct=100*after/norm,residual_pct_of_original_error=100*after/before,quadrature_check_pct=cross))
    table('one-way-current-budget.csv',rows)
    freeze('budget-receipt.json',['budget-trial-freeze.json','one-way-current-budget.csv'])
if __name__=='__main__':diagnose()
