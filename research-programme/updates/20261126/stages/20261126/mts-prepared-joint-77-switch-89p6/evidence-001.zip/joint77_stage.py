import hashlib,json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent
PARENT=ROOT.parent/'mts-recoupled-energy-constraint-89p6-20261126'
PIN='b2835ab3c49690a41de7f23406ae428e23f7f9c2ebc975be452e83f0accaa14c'
def sha(path):
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
assert sha(PARENT/'seal.json')==PIN
files=json.loads((PARENT/'seal.json').read_bytes())['files']
for file in ('ham_stage.py','ham_forecast.py','packet_energy.py'):assert sha(PARENT/file)==files[file]
sys.path.insert(0,str(PARENT))
from packet_energy import old,wave_input,earlier
from ham_stage import common,window,np,pack,table,freeze,locked,safe,rms
from rebuild_wave import getflow
common.PINS={**common.PINS,PARENT:PIN};common.ROOT=window.ROOT=ROOT
from scipy.interpolate import CubicSpline
from scipy.special import expit
from scipy.integrate import solve_ivp
IX=old.IX
N_IND=[IX[f'N{ell}'] for ell in range(69)]
def pct(x,y):
    norm=np.max(abs(y))
    assert norm>0
    return 100*np.max(abs(x-y))/norm
def prim(t,values):
    curve=CubicSpline(t,values,axis=0).antiderivative()
    return curve(t)-curve(t[0])
def adv(arr,k):
    ell=np.arange(69)
    res=np.zeros_like(arr)
    res[...,1:]+=arr[...,:-1]*(k*ell[1:]/(2*ell[1:]+1))
    res[...,:-1]-=arr[...,1:]*(k*ell[1:]/(2*ell[:-1]+1))
    return res
class Bank:
    def __init__(self):
        with np.load(wave_input('common-heavy.npz')) as arc:
            t=arc['eta'];self.k=arc['k'].item();self.sw=CubicSpline(np.log(t),arc['Sw'].T)
        self.axis=t;self.q=q=old.KIN.MOM;assert len(q)==77
        sources=[]
        for node,mom in enumerate(q,-52):
            with np.load(wave_input(f'micro-heavy-{node}.npz')) as arc:
                assert arc['q'].item()==mom and arc['id'].item()==node
                sources.append(arc['source'].T)
        self.micro=CubicSpline(np.log(t),np.stack(sources,axis=1))
        with np.load(wave_input('material-halfstep/forcing-heavy.npz')) as arc:
            bg=dict(zip(arc['bgkeys'],arc['background']))
            self.bg=CubicSpline(np.log(arc['eta']),np.stack([bg['a'],bg['enu']],axis=1))
        meta=json.loads(old.KIN.ti.parent.pin('radiation-background.json').read_bytes())['heavy']
        self.mass=meta['mass_over_temperature'];coeff=meta['massless_limit_coeff']/(7*np.pi**4/120)
        quadr=np.gradient(np.log(q));quadr[[0,-1]]*=.5
        self.weight=coeff*quadr*q**2*expit(q)*expit(-q)
        self.spectral=5-q*np.tanh(q/2)
    def coeff(self,t):
        bg=self.bg(np.log(t));a=bg[...,0,None];enu=bg[...,1,None];q=self.q
        mass2=(self.mass*a)**2;eps=np.hypot(q,self.mass*a);gap=mass2/(eps+q)
        factor=self.weight/(a**2*enu)
        kernel=np.stack([factor*q**2*eps,factor*np.broadcast_to(q**3,eps.shape),-factor*q**4/eps,factor*q**2*mass2/eps],axis=-2)
        shape=np.stack([np.sum(factor*q**2*gap*self.spectral,axis=-1),np.zeros_like(bg[...,0]),np.sum(factor*q**3*gap/eps*self.spectral,axis=-1),np.sum(factor*q**2*mass2/eps*self.spectral,axis=-1)],axis=-1)
        return q/eps,-gap/eps,kernel,shape
    def stress(self,lag,shape,kernel,shape_weight):
        return np.stack([lag[..., :,ell]@kernel[i]+shape[...,ell]*shape_weight[i] for i,ell in enumerate((0,1,2,0))],axis=-1)
    def bin_rhs(self,lag,shape,normal,lapse,vel,slow,incoming):
        combined=normal[...,None,:]+self.spectral[:,None]*shape[...,None,:]
        result=adv(vel[:,None]*lag+slow[:,None]*combined,self.k)+incoming
        result[...,1]-=(slow/vel)*self.k*lapse[...,None]/3
        return result
if __name__=='__main__':
    safe();freeze('protocol.json',['PROTOCOL.md','joint77_stage.py','joint77_prepare.py','joint77_evolve.py','joint77_score.py'])
