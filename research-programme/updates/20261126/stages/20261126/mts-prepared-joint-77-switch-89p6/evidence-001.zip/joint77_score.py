import csv,sys,ast
from joint77_stage import *
from joint77_evolve import NAMES
def first_cross(t,ratio):
    at=np.flatnonzero(ratio>.5)
    return float(t[at[0]]) if len(at) else ''
def summary():
    locked('evolution-freeze.json');checks=[];onsets=[];refine=[];comparison=[];all_runs={}
    for mode in ('p16','p32'):
        with np.load(wave_input(f'particular-heavy-{mode}.npz')) as ar:
            clock=ar['eta'];endlag=ar['lagEnd'][:,:,0,0]
            arch=CubicSpline(clock,np.column_stack([ar['phi'],ar['psi'],ar['phi_dot']]))
        for sub in (2,4):
            with np.load(ROOT/f'joint-{mode}-{sub}.npz') as ar:
                assert ar['names'].tolist()==list(NAMES);data=ar['observables'];t=ar['t'];full_lag=ar['lag_end']
            all_runs[mode,sub]=t,data,full_lag
            ref=arch(t);total=t[-1]-t[0];scale=rms(t,ref[:,0])
            for idx,label in enumerate(('momentum','density')):
                phi,ep,shadow,psi,rate,energy,current,u,den,hub,*stress=data[:,idx,:].T
                gap=ep-shadow;drift=gap-gap[0];entry=abs(shadow[0])
                assert entry>0 and np.max(abs(den.imag))+np.max(abs(hub.imag))==0
                closure=den*shadow+energy/2+1.5*hub*current/old.source(mode).kk-u
                check=100*rms(t,closure+den*gap)/rms(t,den*shadow)
                expect=prim(t,rate)
                shadow_check=100*rms(t,(shadow-shadow[0])-expect)/rms(t,expect)
                spline=CubicSpline(t,ep)
                diff=spline.derivative()(t)-rate
                rate_scale=rms(t,rate)
                rms_inc=rms(t,shadow-shadow[0])
                delta=np.r_[0.,100*abs(drift[1:])/(rate_scale*(t[1:]-t[0]))]
                assert check<=.5 and shadow_check<=.5,(check,shadow_check)
                rows=dict(mode=mode,sub=sub,history=label,entry_pct=100*abs(gap[0])/entry,full_constraint_pct=100*rms(t,gap)/rms(t,shadow),end_pct_of_launch=100*abs(gap[-1])/entry,max_pct_of_launch=100*np.max(abs(gap))/entry,
                    drift_pct_of_motion=100*rms(t,drift)/rms_inc,rate_error_pct=100*rms(t,diff)/rate_scale,
                    rate_at_switch_pct=100*abs(diff[0])/rate_scale,rate_scale=rate_scale,rate_at_switch_abs=abs(rate[0]),phi_launch=entry,
                    first_full_cross=first_cross(t,100*abs(gap)/entry),first_elapsed_motion_cross=first_cross(t,delta),first_rate_cross=first_cross(t,100*abs(diff)/rate_scale),
                    derivative_integral_check_pct=100*rms(t,prim(t,diff)-drift)/max(rms(t,drift),np.finfo(float).tiny))
                onsets.append(rows)
                lag_err=100*np.max(abs(full_lag[idx]-endlag),axis=1)/np.max(abs(endlag),axis=1)
                checks.append(dict(mode=mode,sub=sub,history=label,canonical_form_check_pct=check,momentum_shadow_check_pct=shadow_check,archive_phi_pct=100*rms(t,phi-ref[:,0])/scale,archive_psi_pct=100*rms(t,psi-ref[:,1])/rms(t,ref[:,1]),archive_rate_pct=100*rms(t,rate-ref[:,2])/rms(t,ref[:,2]),archive_max_terminal_bin_pct=np.max(lag_err)))
            phi_gap=data[:,0,0]-data[:,1,0];prevgap=data[:,0,1]-data[:,0,2];both=data[:,1,1]-data[:,1,2]
            comparison.append(dict(mode=mode,sub=sub,metric_difference_pct_of_archive=100*rms(t,phi_gap)/scale,residual_difference_pct_of_archive=100*rms(t,prevgap-both)/scale,raw_route_residual_rms=rms(t,prevgap),energy_route_residual_rms=rms(t,both)))
    for low,hi in [(('p16',2),('p16',4)),(('p32',2),('p32',4)),(('p16',4),('p32',4))]:
        t,lv,ll=all_runs[low];u,hv,hl=all_runs[hi];assert t[0]==u[0] and t[-1]==u[-1]
        h=CubicSpline(u,hv)(t)
        for idx,tag in enumerate(('momentum','density')):
            gap=lv[:,idx,1]-lv[:,idx,2];ref=h[:,idx,1]-h[:,idx,2]
            for name,col in [('phi',0),('energy_phi',1),('rate',4),('massive_energy',10),('massive_current',11),('massive_shear',12),('massive_trace',13)]:
                err=100*rms(t,lv[:,idx,col]-h[:,idx,col])/rms(t,h[:,idx,col])
                refine.append(dict(low=str(low),high=str(hi),history=tag,channel=name,error_pct=err,passes=bool(err<=.5)))
            for name,err in [('gap_on_metric_scale',100*rms(t,gap-ref)/rms(t,h[:,idx,0])),('gap_on_own_scale',100*rms(t,gap-ref)/rms(t,ref)),('max_end_bin',float(np.max(100*np.max(abs(ll[idx]-hl[idx]),axis=1)/np.max(abs(hl[idx]),axis=1))))]:
                refine.append(dict(low=str(low),high=str(hi),history=tag,channel=name,error_pct=err,passes=bool(err<=.5)))
    for name,val in [('onset',onsets),('independent-controls',checks),('paired-readout',comparison),('refinement',refine)]:table(name+'.csv',val)
    freeze('score-receipt.json',['evolution-freeze.json','onset.csv','independent-controls.csv','paired-readout.csv','refinement.csv'])
def verify(seal=False):
    for name in ('protocol','entry-freeze','evolution-freeze','score-receipt'):locked(name+'.json')
    for name,count in [('onset',8),('refinement',60),('switch-checks',8),('independent-controls',8),('paired-readout',4),('preparation-controls',2)]:
        with (ROOT/(name+'.csv')).open() as stream:rows=list(csv.DictReader(stream))
        assert len(rows)==count
        if name=='refinement':assert all((float(r['error_pct'])<=.5)==(r['passes']=='True') for r in rows)
    for path in ROOT.glob('*.py'):ast.parse(path.read_text())
    assert not list(ROOT.glob('__pycache__'))
    if seal:
        assert (ROOT/'RESULTS.md').exists();freeze('seal.json',sorted(p.name for p in ROOT.iterdir() if p.is_file() and p.name!='seal.json'));locked('seal.json');print(sha(ROOT/'seal.json'))
if __name__=='__main__':
    if '--seal' in sys.argv:verify(True)
    else:summary();verify()
