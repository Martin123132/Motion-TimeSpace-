from joint77_stage import *

def coefficients(src,t):
    bg,force,held,_,_,_,_,den=src.environment(t)
    n=len(t);energy=np.zeros((n,old.DIM));current=np.zeros_like(energy)
    for key,value in [('gx',bg['eg']),('N0',4*bg['er']+bg['nuE']),('cd',bg['ec']),('bd',bg['eb'])]:energy[:,IX[key]]=value
    for key,value in [('W',bg['eg']),('N1',src.wave*(4*bg['er']+bg['nuJ'])),('ct',bg['ec'])]:current[:,IX[key]]=value
    for tag in ('s','h'):
        energy[:,IX[tag+'f']]=(bg['a']*bg[tag+'m'])**2*bg[tag+'b'];energy[:,IX[tag+'w']]=bg[tag+'v']
        current[:,IX[tag+'f']]=src.kk*bg[tag+'v']
    e0=sum(force[key] for key in ('gE','btrace','bKE','ctrace','cKE','senergy','henergy'))
    j0=sum(force[key] for key in ('gJ','bJq','nuJ','cJq','sJ','hJ'))
    slip=(-force['Q']-bg['eg']*force['ph_shift']+sum(force[key] for key in ('cshear','bshear','sshear','hshear')))/src.kk
    return bg,den,energy,current,e0,j0,slip,force['U'],force['Fq']

def run(mode,bank):
    safe();src=old.source(mode);_,wavefile,restart=getflow(mode);switch=src.time[0]
    with np.load(restart) as ar:
        start=ar['eta'][-1];lag0=ar['lagEnd'][:,:,0,0];shape0=ar['shape'][-1,:,0]
        assert np.array_equal(ar['q'],bank.q) and start==83.2
    with np.load(wavefile) as ar:
        eta=ar['eta'];clock=ar['stressClock'];archive_stress=ar['stress'][:,:,0,0];saved_shape=ar['shape'][:,:,0]
        normal=CubicSpline(np.log(eta),ar['normal'][:,:,0,0])
        lapse=CubicSpline(np.log(eta),ar['psi']);saved_phi=CubicSpline(eta,ar['phi'])
        saved_rate=CubicSpline(eta,ar['phi_dot']);endlag=ar['lagEnd'][:,:,0,0]
    assert clock[0]==start and clock[-1]==src.time[-1]
    shape_spline=CubicSpline(np.log(clock),saved_shape)
    scale=np.max(abs(lag0),axis=1)[:,None];assert np.all(scale>0)
    def lag_rhs(t,y):
        log=np.log(t);vel,slow,_,_=bank.coeff(t)
        return (bank.bin_rhs(y.reshape(77,69)*scale,shape_spline(log),normal(log),lapse(log),vel,slow,bank.micro(log))/scale).ravel()
    ticks=np.unique(np.r_[clock,switch]);sol=solve_ivp(lag_rhs,(start,clock[-1]),(lag0/scale).ravel(),method='DOP853',t_eval=ticks,rtol=1e-11,atol=1e-13,max_step=.024)
    assert sol.success
    lag=sol.y.T.reshape(-1,77,69)*scale
    sh_scale=np.max(abs(shape0))
    def sh_rhs(t,y):return adv(y,bank.k)+bank.sw(np.log(t))/sh_scale
    sh=solve_ivp(sh_rhs,(start,clock[-1]),shape0/sh_scale,method='DOP853',t_eval=ticks,rtol=1e-11,atol=1e-13,max_step=.024)
    assert sh.success
    shape=sh.y.T*sh_scale;knots=np.searchsorted(ticks,clock);sid=np.searchsorted(ticks,switch)
    vals=np.array([bank.stress(lag[j],shape[j],*bank.coeff(at)[2:]) for j,at in enumerate(ticks)])
    err_bin=100*np.max(abs(lag[-1]-endlag),axis=1)/np.max(abs(endlag),axis=1)
    errs_stress=100*np.max(abs(vals[knots]-archive_stress),axis=0)/np.max(abs(archive_stress),axis=0)
    entry_moment=100*abs(vals[sid]-src.stress(np.log(switch)))/abs(src.stress(np.log(switch)))
    ctrl=dict(mode=mode,bin_count=len(err_bin),max_terminal_bin_pct=max(err_bin),shape_replay_pct=pct(shape[knots],saved_shape),stress_control_pct=max(errs_stress),switch_moments_vs_interpolated_pct=max(entry_moment))
    assert max(ctrl[k] for k in list(ctrl)[2:])<=.5,ctrl
    with np.load(old.pin(f'angular-{mode}-4.npz')) as ar:momentum=ar['wave_entry']
    high=old.release.switch_levels(old.release.average_stage.pin(f'native-{mode}.npz'),switch,True)
    energy=np.r_[src.interp(switch),high];energy[12]=saved_phi(switch)
    entries=np.stack([momentum,energy])
    assert entries.shape==(2,90) and entries.any() and np.max(abs(entries[:,12]))>0
    bg,den,we,wj,e0,j0,slip,u,fq=coefficients(src,np.array([switch]))
    records=[]
    def metric(state,raw):
        en=we[0]@state+e0[0]+bg['enu'][0]*raw[0]
        curr=wj[0]@state+j0[0]+bg['enu'][0]*src.wave*raw[1]
        phi=(u[0]-en/2-1.5*bg['h'][0]*curr/src.kk)/den[0]
        psi=state[12]+slip[0]+(bg['enu'][0]*raw[2]-bg['eg'][0]*state[old.QI]-(4*bg['er'][0]+bg['nuS'][0])*state[old.QN])/src.kk
        rate=curr/(2*src.kk)-bg['h'][0]*psi+fq[0]
        return phi,rate
    for label,state in zip(('momentum','density'),entries):
        for kind,raw in [('restored_bins',vals[sid]),('archived_spline',src.stress(np.log(switch)))]:
            inferred,rate=metric(state,raw);phi=state[12];derivative=saved_phi(switch,1)
            records.append(dict(mode=mode,history=label,stress=kind,phi_abs=abs(phi),energy_constraint_pct=100*abs(phi-inferred)/abs(phi),
                archived_derivative_vs_momentum_pct=100*abs(derivative-rate)/abs(rate),archive_recorded_rate_replay_pct=100*abs(rate-saved_rate(switch))/abs(rate),U_abs=abs(u[0])))
    pack(f'switch-{mode}.npz',t=switch,lag=lag[sid],shape=shape[sid],entries=entries,raw_stress=vals[sid],terminal_bin_errors=err_bin,stress_errors=errs_stress,
         archive=sha(wavefile),parent_restart=sha(restart),state_difference=momentum-energy)
    return ctrl,records
def main():
    locked('protocol.json');bank=Bank();ctrl=[];records=[]
    for mode in ('p16','p32'):
        checks,rows=run(mode,bank);ctrl.append(checks);records.extend(rows)
    table('preparation-controls.csv',ctrl);table('switch-checks.csv',records)
    freeze('entry-freeze.json',['protocol.json','preparation-controls.csv','switch-checks.csv','switch-p16.npz','switch-p32.npz'])
if __name__=='__main__':main()
