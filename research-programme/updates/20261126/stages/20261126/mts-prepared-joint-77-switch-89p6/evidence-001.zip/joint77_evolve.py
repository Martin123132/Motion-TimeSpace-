from copy import copy
from joint77_stage import *
from joint77_prepare import coefficients
NAMES=('phi','energy_phi','momentum_shadow','psi','momentum_rate','canonical_energy','total_current','U','B','hub','bin_energy','bin_current','bin_shear','bin_trace')
def run(mode,sub,bank):
    locked('entry-freeze.json')
    src=old.source(mode);rawsrc=copy(src);rawsrc.stress=lambda u:np.zeros((len(u),4),complex)
    rawsrc.quads=lambda t:np.zeros((len(t),2),complex)
    solver=old.Wave(rawsrc)
    with np.load(ROOT/f'switch-{mode}.npz') as start:
        x=start['entries'].copy();lag=np.repeat(start['lag'][None,:,:],2,axis=0);shape=start['shape'].copy();at=start['t'].item()
    with np.load(old.pin(f'angular-{mode}-{sub}.npz')) as ar:t=ar['grid']
    assert t[0]==at and x.shape==(2,old.DIM) and lag.shape==(2,77,69)
    output=np.empty((len(t),2,len(NAMES)),complex);held=lag.copy()
    checks=0.
    for first in range(0,len(t)-1,24):
        safe();last=min(first+24,len(t)-1);edges=t[first:last+1];clock=np.empty(2*len(edges)-1);clock[::2]=edges;clock[1::2]=(edges[:-1]+edges[1:])/2
        log=np.log(clock);vel,slow,kernel,shape_weight=bank.coeff(clock)
        micro=bank.micro(log);sw=bank.sw(log)
        mat,bi,bn=old.operator(solver,clock,clock);mat[:,:13,old.QI]+=bi;mat[:,:13,old.QN]+=bn
        operator=mat[:,:,:old.DIM].copy();bias=mat[:,:,-1].copy()
        bg,den,we,wj,e0,j0,bare_slip,us,fq=coefficients(rawsrc,clock)
        hub=bg['h'];enu=bg['enu'];eg=bg['eg'];nus=4*bg['er']+bg['nuS']
        inject=np.zeros((len(clock),old.DIM))
        for idx,value in [(1,(4/3+bg['eb']/eg)*src.kk),(4,src.wave/3),(6,src.kk),(8,bg['sv']),(9,-(bg['a']*bg['sm'])**2*bg['sb']),(10,bg['hv']),(11,-(bg['a']*bg['hm'])**2*bg['hb']),(12,-hub)]:inject[:,idx]=value
        def rates(index,X,L,S,observe=False):
            nonlocal checks
            stress=bank.stress(L,S,kernel[index],shape_weight[index])*enu[index]
            stress[:,1]*=src.wave
            en=X@we[index]+e0[index]+stress[:,0];cur=X@wj[index]+j0[index]+stress[:,1]
            energy_phi=(us[index]-en/2-1.5*hub[index]*cur/src.kk)/den[index]
            phi=np.array([X[0,12],energy_phi[1]])
            slip=(stress[:,2]-eg[index]*X[:,old.QI]-nus[index]*X[:,old.QN])/src.kk+bare_slip[index]
            psi=phi+slip
            pd=cur/(2*src.kk)-hub[index]*psi+fq[index]
            if observe:
                return np.stack([phi,energy_phi,X[:,12],psi,pd,en,cur,*[np.full(2,c) for c in (us[index],den[index],hub[index])],*stress.T],axis=-1)
            physical=X.copy();physical[:,12]=phi
            dX=physical@operator[index].T+bias[index]+(stress[:,2]/src.kk)[:,None]*inject[index]
            dX[:,12]+=stress[:,1]/(2*src.kk)
            checks=max(checks,np.max(abs(dX[:,12]-pd))/max(np.max(abs(pd)),1e-90))
            normal=physical[:,N_IND].copy();normal[:,0]+=phi
            dlag=bank.bin_rhs(L,S,normal,psi,vel[index],slow[index],micro[index])
            dshape=adv(S,src.wave)+sw[index]
            return dX,dlag,dshape
        for idx,width in enumerate(np.diff(edges)):
            pos=2*idx;output[first+idx]=rates(pos,x,lag,shape,True)
            a,b,c=rates(pos,x,lag,shape);half=width/2
            d,e,f=rates(pos+1,x+half*a,lag+half*b,shape+half*c)
            g,h,i=rates(pos+1,x+half*d,lag+half*e,shape+half*f)
            j,l,m=rates(pos+2,x+width*g,lag+width*h,shape+width*i)
            x+=width/6*(a+2*d+2*g+j);lag+=width/6*(b+2*e+2*h+l);shape+=width/6*(c+2*f+2*i+m)
        output[last]=rates(len(clock)-1,x,lag,shape,True)
    assert checks<.005 and np.isfinite(output).all() and np.isfinite(lag).all()
    assert np.all(np.max(abs(lag-held),axis=2)>0)
    pack(f'joint-{mode}-{sub}.npz',t=t,observables=output,names=NAMES,ordinary_end=x,lag_end=lag,shape_end=shape,histories=['momentum','density'],q=bank.q)
    return dict(mode=mode,sub=sub,rate_identity_pct=100*checks,bins_advanced_each=77,ordinary_dimensions=old.DIM,angular_orders=69,both_routes=True)
def main():
    safe();bank=Bank();rows=[]
    for mode in ('p16','p32'):
        for sub in (2,4):rows.append(run(mode,sub,bank))
    table('joint-controls.csv',rows);freeze('evolution-freeze.json',['entry-freeze.json','joint-controls.csv']+[f'joint-{m}-{s}.npz' for m in ('p16','p32') for s in (2,4)])
if __name__=='__main__':main()
