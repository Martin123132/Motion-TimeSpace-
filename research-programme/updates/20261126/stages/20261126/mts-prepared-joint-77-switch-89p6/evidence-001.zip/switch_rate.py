from joint77_stage import *
from joint77_prepare import coefficients
def measure(mode,bank):
    src=old.source(mode)
    with np.load(ROOT/f'switch-{mode}.npz') as arc:
        t=arc['t'].item();lag=arc['lag'];shape=arc['shape'];entries=arc['entries']
    time=np.array([t]);bg,den,we,wj,e0,j0,base,u,fq=coefficients(src,time)
    vel,slow,kern,swgt=bank.coeff(t)
    raw=bank.stress(lag,shape,kern,swgt)
    physical=raw*bg['enu'][0];physical[1]*=src.wave
    def fixed_phi(at,x):
        clock=np.array([at])
        b,d,e,j,es,js,_,s,_=coefficients(src,clock)
        val=bank.stress(lag,shape,*bank.coeff(at)[2:])*b['enu'][0]
        en=e[0]@x+es[0]+val[0];cur=j[0]@x+js[0]+src.wave*val[1]
        return ((s[0]-en/2-1.5*b['h'][0]*cur/src.kk)/d[0])
    rows=[];peaks=[]
    for idx,label in enumerate(('momentum','density')):
        x=entries[idx].copy()
        if idx:x[12]=fixed_phi(t,x)
        env=list(src.environment(time));env[2]=physical[None,:];env[4]=x[[old.QI,old.QN],None]
        dx=old.Wave(src).rhs(env,x[:13][None,:])[0]
        normal=x[N_IND].copy();normal[0]+=x[12]
        psi=x[12]+base[0]+(physical[2]-bg['eg'][0]*x[old.QI]-(4*bg['er'][0]+bg['nuS'][0])*x[old.QN])/src.kk
        dlag=bank.bin_rhs(lag,shape,normal,psi,vel,slow,bank.micro(np.log(t)))
        dshape=adv(shape,src.wave)+bank.sw(np.log(t))
        ds=bank.stress(dlag,dshape,kern,swgt)*bg['enu'][0];ds[1]*=src.wave
        fac=1.5*bg['h'][0]/src.kk
        matter=-(we[0,:13]@dx/2+fac*(wj[0,:13]@dx))/den[0]
        massive=-(ds[0]/2+fac*ds[1])/den[0]
        def fixed_rate(step):return (fixed_phi(t+step,x)-fixed_phi(t-step,x))/(2*step)
        one=fixed_rate(2e-5);two=fixed_rate(1e-5);three=fixed_rate(5e-6)
        rate=three+(three-two)/3+massive+matter
        rate0=two+(two-one)/3+massive+matter
        with np.load(ROOT/f'joint-{mode}-4.npz') as arc:
            clock=arc['t'];o=arc['observables'][:,idx,:]
        check=CubicSpline(clock,o[:,1]).derivative()(clock)-o[:,4];norm=rms(clock,o[:,4]);peak=np.argmax(abs(check))
        entry=100*abs(rate-dx[12])/abs(dx[12])
        num=100*abs(rate-rate0)/abs(dx[12]);derivative_check=100*abs(rate-dx[12]-check[0])/abs(dx[12])
        assert max(num,derivative_check)<.5
        rows.append(dict(mode=mode,history=label,entry_mismatch_pct_of_actual_rate=entry,step_change_pct_of_rate=num,independent_grid_derivative_difference_pct_of_rate=derivative_check,peak_time=clock[peak],peak_rate_disagreement_pct_of_rms=100*abs(check[peak])/norm,largest_elapsed_drift_pct_of_motion=100*np.max(abs(((o[:,1]-o[:,2])-(o[0,1]-o[0,2]))[1:])/(norm*(clock[1:]-clock[0])))))
    return rows
def main():
    locked('score-receipt.json');rows=[];bank=Bank()
    for mode in ('p16','p32'):rows.extend(measure(mode,bank))
    table('switch-rate.csv',rows);freeze('rate-receipt.json',['score-receipt.json','switch_rate.py','switch-rate.csv'])
if __name__=='__main__':main()
