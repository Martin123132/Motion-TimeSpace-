import json
import numpy as np
from scipy.interpolate import CubicSpline
from period import ROOT, PREP, History, pinned, record, verify


def main():
    verify("forecast-freeze.json")
    archive=json.loads(pinned(PREP,"forecast.json").read_bytes())["predictions"]
    summaries=[]
    for grid in ("p16","p32"):
        pre=History(grid)
        saved=next(row for row in archive if row["grid"]==grid and row["order"]==96)
        p0=complex(*saved["pressure"])
        for sub in (2,4):
            with np.load(ROOT/f"period-{grid}-{sub}.npz") as data:
                obs=data["obs"];traces=data["traces"];time=data["t"]
                assert np.array_equal(data["final"][:,12],obs[-1,:,2]) and np.isfinite(data["final_lag"]).all()
                for idx,route in enumerate(("momentum","density")):
                    wave,mean,dj,energy,pressure=traces[:,idx,:5].T
                    theta=traces[:,idx,9].real
                    incoming=pre.past.integrate(-np.pi,0.)/np.pi
                    full_integral=CubicSpline(theta,wave).integrate(0.,theta[-1])/np.pi
                    residual_history=pre.past.integrate(-np.pi,theta[-1]-np.pi)/np.pi
                    expected=full_integral+incoming-residual_history
                    offset=mean[0]-incoming
                    error=100*abs(mean[-1]-expected-offset)/abs(mean[-1])
                    assert error < .5 and energy[0]==0 and abs(theta[-1]-np.pi)<1e-6
                    summaries.append(dict(grid=grid,sub=sub,route=route,phase_error_rad=theta[-1]-np.pi,
                        mean_end_vs_completed_cycle_pct=100*abs(mean[-1]-full_integral)/abs(full_integral),
                        entry_constant_pct_of_end_mean=100*abs(offset/mean[-1]),integral_ledger_pct=error,
                        launch_pressure_vs_prefix_pct=100*abs(pressure[0]-p0)/abs(p0),
                        launch_pressure_real=pressure[0].real,launch_pressure_imag=pressure[0].imag,
                        end_mean=[mean[-1].real,mean[-1].imag],end_complementary_density=[energy[-1].real,energy[-1].imag]))
    record("endpoint.json",summaries)
    print(summaries[-2:])


if __name__=="__main__":
    main()
