import json
import numpy as np
from scipy.interpolate import CubicSpline
from period import ROOT, PAIR, PREP, pinned, record, verify, receipt, sha, NAMES, CHANNELS

TOL=.5


def rms(t,val):
    return np.sqrt(np.trapezoid(abs(val)**2,t,axis=0)/(t[-1]-t[0]))


def pct(t,delta,reference):
    return float(100*rms(t,delta)/rms(t,reference))


def integral(t,val):
    curve=CubicSpline(t,val,axis=0).antiderivative()
    return curve(t)-curve(t[0])


def metrics(t,obs):
    ep,shadow,rate=obs[:,1],obs[:,2],obs[:,4]
    gap=ep-shadow
    dif=CubicSpline(t,ep)(t,1)-rate
    size=100*abs(dif)/rms(t,rate)
    cross=np.flatnonzero(size>TOL)
    calc=pct(t,dif,rate)
    return dict(rate_pct=calc,rate_pass=calc<=TOL,peak_pct=float(max(size)),
                first_sample_over=float(t[cross[0]]) if len(cross) else None,
                entry_pct=float(100*abs(gap[0]/shadow[0])),full_pct=pct(t,gap,shadow),
                drift_pct=pct(t,gap-gap[0],shadow-shadow[0]),
                shadow_check_pct=pct(t,shadow-shadow[0]-integral(t,rate),shadow-shadow[0]))


def check():
    verify("protocol.json")
    verify("forecast-freeze.json")
    results=[]
    controls=[]
    histories={}
    for grid in ("p16","p32"):
        for sub in (2,4):
            with np.load(ROOT/f"period-{grid}-{sub}.npz") as packet:
                t=packet["t"];obs=packet["obs"];traces=packet["traces"]
                assert packet["channels"].tolist()==list(CHANNELS) and packet["names"].tolist()==list(NAMES)
                assert packet["final_lag"].shape==(4,77,69) and -1e-6<packet["phase_error"]<1e-6
            with np.load(pinned(PAIR,f"matched-{grid}-{sub}.npz")) as old:
                assert old["corners"][0]==t[-1] and np.array_equal(old["t"][:len(t)],t)
                control=old["observables"][:len(t)].copy();control[-1]=old["seams"][0,0]
            histories[grid,sub]=t,obs,traces
            prior=json.loads(pinned(PREP,"forecast.json").read_bytes())["predictions"]
            kk=next(row["kk"] for row in prior if row["grid"]==grid and row["order"]==96)
            for idx,label in enumerate(("momentum","density")):
                on=obs[:,idx];off=obs[:,idx+2];src=traces[:,idx]
                metrics_on=metrics(t,on);metrics_off=metrics(t,off)
                errs=[pct(t,off[:,i]-control[:,idx,i],control[:,idx,i]) for i in range(obs.shape[-1])]
                assert max(errs)<1e-5,errs
                rho=src[:,10];wave,avg,dj,de,pres,delay,mrate,erate,jrate,phase=src[:,:10].T
                hub=on[:,9]
                expected=avg[0]+(integral(phase.real,wave-delay))/np.pi
                current=src[:,12]+rho*avg
                w=de+3*hub*dj/kk
                hder=CubicSpline(t,hub)(t,1)
                wdot=(-1+3*(hder-hub**2)/kk)*dj
                d_expected=integral(t,wdot)-3*(hub*dj-hub[0]*dj[0])/kk
                pred_press=(CubicSpline(t,dj)(t,1)+hub*dj)/kk
                checks=dict(null_replay_max_pct=max(errs),mean_independent_pct=pct(t,avg-expected,avg),
                     current_once_pct=pct(t,on[:,6]-current,on[:,6]),density_balance_pct=pct(t,de-d_expected,de),
                     pressure_derivative_pct=pct(t,pres-pred_press,pres),shadow_replay_pct=metrics_on["shadow_check_pct"])
                assert all(np.isfinite(list(checks.values())))
                results.append(dict(grid=grid,sub=sub,route=label,corrected=metrics_on,disabled=metrics_off,
                                  rate_change_pp=metrics_on["rate_pct"]-metrics_off["rate_pct"]))
                controls.append(dict(grid=grid,sub=sub,route=label,**checks))
    refinements=[]
    for pair in [(("p16",2),("p16",4)),(("p32",2),("p32",4)),(("p16",4),("p32",4))]:
        low,high=pair
        t,lo,lc=histories[low];u,hi,hc=histories[high]
        for idx,label in enumerate(("momentum","density")):
            loerr=CubicSpline(t,lo[:,idx,1])(t,1)-lo[:,idx,4]
            hierr=CubicSpline(u,hi[:,idx,1])(u,1)-hi[:,idx,4]
            vals={}
            for tag,first,second in [("rate_residual",loerr,hierr),("complementary_current",lc[:,idx,2],hc[:,idx,2]),("complementary_pressure",lc[:,idx,4],hc[:,idx,4]),("complementary_density",lc[:,idx,3],hc[:,idx,3])]:
                ref=CubicSpline(u,second)(t)
                vals[tag]=pct(t,first-ref,ref)
            refinements.append(dict(low=list(low),high=list(high),route=label,**vals))
    record("results.json",dict(tolerance_pct=TOL,rows=results,controls=controls,refinements=refinements))
    for row in results:
        print(row["grid"],row["sub"],row["route"],*(round(row[case]["rate_pct"],7) for case in ("disabled","corrected")),flush=True)
    print("worst control",max(max(v for k,v in row.items() if k.endswith("_pct")) for row in controls))
    print("refinements",refinements[-2:])


if __name__=="__main__":
    check()
