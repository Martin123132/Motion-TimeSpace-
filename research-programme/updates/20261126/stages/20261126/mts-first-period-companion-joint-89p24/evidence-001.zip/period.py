from pathlib import Path
import argparse
import hashlib
import json
import sys

import numpy as np
from scipy.integrate import solve_ivp
from scipy.interpolate import CubicSpline, make_interp_spline

ROOT = Path(__file__).resolve().parent
PAIR = ROOT.parent / "mts-matched-joint-77-switch-89p6-20261126"
PREP = ROOT.parent / "mts-switch-companion-exchange-89p6-20261126"
PINS = {PAIR:"3aab615be69d49dcdafeac123dc1c70ecd6cd18516791a15dd0c478d88a51845",
        PREP:"972e5431a544dc8c6db9bcbd9e9d6cc98166128cad28e8ad8cc88be8020a6f5e"}


def sha(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream,"sha256").hexdigest()


def pinned(folder, name):
    assert sha(folder/"seal.json")==PINS[folder]
    path=folder/name
    assert sha(path)==json.loads((folder/"seal.json").read_bytes())["files"][name]
    return path


def save(name,data):
    out=ROOT/name
    if out.exists():
        assert out.read_bytes()==data,name
    else:
        with out.open("xb") as stream:
            stream.write(data)


def record(name,data):
    save(name,(json.dumps(data,sort_keys=True,allow_nan=False,indent=2)+"\n").encode())


def receipt(name,files):
    record(name,{file:sha(ROOT/file) for file in files})


def verify(name):
    for file,val in json.loads((ROOT/name).read_bytes()).items():
        assert sha(ROOT/file)==val,file


pinned(PAIR,"match77_stage.py")
sys.path.insert(0,str(PAIR))
import match77_stage as joint
from match77_stage import old, Host, MatchedBank, NAMES, N_IND, adv, coefficients

CHANNELS=("wave_j","mean","comp_j","comp_e","comp_pressure","delayed_j","mean_rate",
          "comp_e_rate","comp_j_rate","gained_phase","rho","physical_heavy_j","other_current")


class History:
    def __init__(self,grid):
        pred=json.loads(pinned(PREP,"forecast.json").read_bytes())["predictions"]
        saved=next(row for row in pred if row["grid"]==grid and row["order"]==96)
        start=saved["end"]
        self.initial=complex(*saved["current"])
        with np.load(joint.pinned(joint.CURRENT,f"launch-{grid}.npz")) as packet:
            mass=float(packet["mass"])
            osc=packet["osc"]
            self.rho0=float(packet["rho0"])
            self.kk=float(packet["kk"])
        with np.load(joint.wave_input("material-halfstep/forcing-heavy.npz")) as packet:
            times=packet["eta"]
            mask=(times>start-.30)&(times<=start)
            keys=packet["bgkeys"].tolist()
            bg=make_interp_spline(times[mask],packet["background"][[keys.index("a"),keys.index("h")]][:,mask].T,k=5)
            key=packet["keys"].tolist().index("hJ")
            ext=make_interp_spline(times[mask],packet["values"][key,mask,0],k=5)
        with np.load(joint.wave_input(f"particular-heavy-{grid}.npz")) as packet:
            times=packet["eta"]
            mask=(times>start-.18)&(times<=start)
            field=make_interp_spline(times[mask],packet["obs"][mask,10,0,0],k=5)
        with np.load(joint.wave_input("exact-phase-extension.npz")) as packet:
            self.angle=CubicSpline(packet["heavy_efold"],packet["phase_h"])
        span=np.linspace(saved["begin"]-1e-6,start,1025)
        def rhs(time,state):
            scale,hub=bg(time)
            return [state[1],-2*hub*state[1]-(scale*mass)**2*state[0]]
        sol=solve_ivp(rhs,(start,span[0]),osc,t_eval=span[::-1],rtol=2e-12,atol=2e-15,max_step=.001,method="DOP853")
        assert sol.success
        scale=bg(span)[:,0]
        theta=self.angle(np.log(scale))-self.angle(np.log(scale[-1]))
        self.past=CubicSpline(theta,(self.kk*sol.y[1,::-1]*field(span)+ext(span))*scale/self.rho0)
        assert theta[0]<-np.pi and theta[-1]==0


def run(grid,sub,bank,hist):
    verify("protocol.json")
    host=Host(grid,sub)
    solver=old.Wave(host)
    edge=host.corners[0]
    time=host.t[host.t<=edge]
    assert time[-1]==edge
    with np.load(pinned(PAIR,f"matched-switch-{grid}.npz")) as packet:
        assert packet["passed"] and packet["t"]==time[0]
        state=np.tile(packet["entry"],(4,1))
        lag=np.repeat(packet["lag"][None],4,axis=0)
        shape=packet["shape"].copy()
    host.focus=(time[0]+edge)/2
    bg=host.environment(time)[0]
    scale=CubicSpline(time,bg["a"])
    hub_curve=CubicSpline(time,bg["h"])
    theta=hist.angle(np.log(scale(time)))-hist.angle(np.log(scale(time[0])))
    assert np.all(np.diff(theta)>0) and abs(theta[-1]-np.pi)<1e-6
    enable=np.array([1.,1.,0.,0.])
    momentum_route=np.array([True,False,True,False])
    companion=np.zeros((4,2),complex)
    rho=hist.rho0/scale(time[0])
    jentry=(host.kk*host.osc(time[:1])[3][0]*state[:,10]+host.external(np.log(time[0]))[3])/rho
    companion[:,0]=jentry+hist.initial
    original=state.copy()
    first_lag=lag.copy()
    observations=np.zeros((len(time),4,len(NAMES)),complex)
    traces=np.zeros((len(time),4,len(CHANNELS)),complex)
    maxcheck=0.
    for left in range(0,len(time)-1,24):
        joint.safe()
        right=min(left+24,len(time)-1)
        edges=time[left:right+1]
        clock=np.empty(len(edges)*2-1)
        clock[::2]=edges
        clock[1::2]=(edges[1:]+edges[:-1])/2
        log=np.log(clock)
        vel,slow,kernel,weights=bank.coeff(clock)
        micro=bank.micro(log)
        shape_ext=bank.sw(log)
        mat,bi,bn=old.operator(solver,clock,clock)
        mat[:,:13,old.QI]+=bi
        mat[:,:13,old.QN]+=bn
        op=mat[:,:,:old.DIM].copy()
        bias=mat[:,:,-1].copy()
        bg,den,we,wj,e0,j0,slip0,us,fq=coefficients(host,clock)
        hub=bg["h"]
        kk=host.kk
        enu=bg["enu"]
        eg=bg["eg"]
        nus=4*bg["er"]+bg["nuS"]
        rho=hist.rho0/bg["a"]
        rate_a=scale(clock,1)/scale(clock)
        angle=hist.angle(np.log(bg["a"]))-hist.angle(np.log(scale(time[0])))
        speed=hist.angle(np.log(bg["a"]),1)*rate_a
        delayed=hist.past(angle-np.pi)
        vel_h=bg["hv"]
        acc_h=-2*hub*vel_h-(bg["a"]*bg["hm"])**2*bg["hb"]
        ext=host.external(log)[:,3]
        ext_rate=host.external(log,1)[:,3]/clock
        inject=np.zeros((len(clock),old.DIM))
        for idx,value in [(1,(4/3+bg["eb"]/eg)*kk),(4,host.wave/3),(6,kk),(8,bg["sv"]),(9,-(bg["a"]*bg["sm"])**2*bg["sb"]),(10,vel_h),(11,-(bg["a"]*bg["hm"])**2*bg["hb"]),(12,-hub)]:
            inject[:,idx]=value

        def rates(idx,fields,bins,spectral,memory,observe=False):
            nonlocal maxcheck
            stress=bank.stress(bins,spectral,kernel[idx],weights[idx])*enu[idx]
            stress[:,1]*=host.wave
            wave=(kk*vel_h[idx]*fields[:,10]+ext[idx])/rho[idx]
            delta=memory[:,0]-wave
            energy=fields@we[idx]+e0[idx]+stress[:,0]+enable*rho[idx]*memory[:,1]
            bare_current=fields@wj[idx]+j0[idx]+stress[:,1]
            cur=bare_current+enable*rho[idx]*delta
            energy_phi=(us[idx]-energy/2-1.5*hub[idx]*cur/kk)/den[idx]
            phi=np.where(momentum_route,fields[:,12],energy_phi)
            psi=phi+slip0[idx]+(stress[:,2]-eg[idx]*fields[:,old.QI]-nus[idx]*fields[:,old.QN])/kk
            pd=cur/(2*kk)-hub[idx]*psi+fq[idx]
            live=fields.copy()
            live[:,12]=phi
            dx=live@op[idx].T+bias[idx]+(stress[:,2]/kk)[:,None]*inject[idx]
            dx[:,12]+=(stress[:,1]+enable*rho[idx]*delta)/(2*kk)
            maxcheck=max(maxcheck,np.max(abs(dx[:,12]-pd))/max(np.max(abs(pd)),1e-90))
            mean_rate=speed[idx]*(wave-delayed[idx])/np.pi
            wave_rate=(kk*(acc_h[idx]*fields[:,10]+vel_h[idx]*dx[:,10])+ext_rate[idx])/rho[idx]+rate_a[idx]*wave
            delta_rate=mean_rate-wave_rate
            pres=(delta_rate+hub[idx]*delta)/kk
            edot=-delta-3*hub[idx]*pres
            if observe:
                const=lambda val:np.broadcast_to(val,phi.shape)
                return (np.stack([phi,energy_phi,fields[:,12],psi,pd,energy,cur,*[const(v) for v in (us[idx],den[idx],hub[idx])],*stress.T],axis=-1),
                        np.stack([wave,memory[:,0],delta,memory[:,1],pres,const(delayed[idx]),mean_rate,edot,delta_rate,const(angle[idx]),const(rho[idx]),rho[idx]*wave,bare_current-rho[idx]*wave],axis=-1))
            normal=live[:,N_IND].copy()
            normal[:,0]+=phi
            dl=bank.bin_rhs(bins,spectral,normal,psi,vel[idx],slow[idx],micro[idx])
            return dx,dl,adv(spectral,host.wave)+shape_ext[idx],np.stack([mean_rate,edot],axis=1)

        for offset,width in enumerate(np.diff(edges)):
            pos=2*offset
            values=(state,lag,shape,companion)
            observations[left+offset],traces[left+offset]=rates(pos,*values,True)
            one=rates(pos,*values)
            two=rates(pos+1,*[v+width*a/2 for v,a in zip(values,one)])
            three=rates(pos+1,*[v+width*a/2 for v,a in zip(values,two)])
            four=rates(pos+2,*[v+width*a for v,a in zip(values,three)])
            for v,a,b,c,d in zip(values,one,two,three,four):
                v+=width*(a+2*b+2*c+d)/6
        observations[right],traces[right]=rates(len(clock)-1,state,lag,shape,companion,True)
    assert maxcheck<.005 and np.isfinite(lag).all() and np.isfinite(traces).all()
    assert (np.max(abs(lag-first_lag),axis=2)>0).all()
    assert np.all(observations[0,:,2]==original[:,12]) and np.all(traces[0,:,3]==0)
    from io import BytesIO
    stream=BytesIO()
    np.savez_compressed(stream,t=time,obs=observations,traces=traces,names=NAMES,channels=CHANNELS,
                        q=bank.q,routes=["comp_momentum","comp_density","null_momentum","null_density"],
                        final=state,final_lag=lag,final_shape=shape,entry=original,
                        rhs_check=maxcheck,phase_error=theta[-1]-np.pi)
    save(f"period-{grid}-{sub}.npz",stream.getvalue())
    print(grid,sub,len(time),"samples to",time[-1],flush=True)


def physical_runs():
    verify("protocol.json")
    bank=MatchedBank()
    for grid in ("p16","p32"):
        hist=History(grid)
        for sub in (2,4):
            run(grid,sub,bank,hist)
    receipt("forecast-freeze.json",["protocol.json"]+[f"period-{g}-{s}.npz" for g in ("p16","p32") for s in (2,4)])


if __name__=="__main__":
    parser=argparse.ArgumentParser()
    parser.add_argument("action",choices=["init","run"])
    action=parser.parse_args().action
    if action=="init":
        receipt("protocol.json",["PROTOCOL.md","period.py","score.py"])
    else:
        physical_runs()
