import ast
import json
from period import ROOT, PINS, sha, record, verify

def main():
    for name in ("protocol.json","launch-receipt.json","forecast-freeze.json"):
        verify(name)
    for folder,signature in PINS.items():
        assert sha(folder/"seal.json")==signature
    result=json.loads((ROOT/"results.json").read_bytes())
    rows=result["rows"]
    assert result["tolerance_pct"]==.5 and len(rows)==8
    assert {(r["grid"],r["sub"],r["route"]) for r in rows}=={(g,s,r) for g in ("p16","p32") for s in (2,4) for r in ("momentum","density")}
    for row in rows:
        on=row["corrected"]
        assert on["rate_pass"] and all(on[key]<.5 for key in ("peak_pct","rate_pct","full_pct","drift_pct"))
        assert row["disabled"]["rate_pass"]==(row["route"]=="density")
    for row in result["controls"]:
        assert all(0<=v<.5 for k,v in row.items() if k.endswith("_pct"))
    for row in result["refinements"]:
        assert all(0<=row[k]<.5 for k in ("rate_residual","complementary_current","complementary_pressure","complementary_density"))
    ends=json.loads((ROOT/"endpoint.json").read_bytes())
    assert len(ends)==8 and all(r["mean_end_vs_completed_cycle_pct"]<.05871 and r["launch_pressure_vs_prefix_pct"]<.245 for r in ends)
    for path in ROOT.glob("*.py"):
        ast.parse(path.read_text())
    assert not (ROOT/"__pycache__").exists()
    files={path.name:sha(path) for path in sorted(ROOT.iterdir()) if path.is_file() and path.name!="seal.json"}
    record("seal.json",dict(files=files,parents={p.name:h for p,h in PINS.items()}))
    print(sha(ROOT/"seal.json"))


if __name__=="__main__":
    main()
