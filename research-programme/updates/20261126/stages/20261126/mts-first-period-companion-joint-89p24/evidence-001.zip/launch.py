from period import ROOT, joint, physical_runs, receipt, verify

if __name__=="__main__":
    verify("protocol.json")
    joint.window.ROOT=ROOT
    joint.common.ROOT=ROOT
    joint.safe()
    receipt("launch-receipt.json",["protocol.json","launch.py"])
    physical_runs()
