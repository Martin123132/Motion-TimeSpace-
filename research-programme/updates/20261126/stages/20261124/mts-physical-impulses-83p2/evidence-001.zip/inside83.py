from impulse83 import *


def rows(name):
    with (ROOT/name).open(newline='') as stream:
        return list(csv.DictReader(stream))


def profiles(medium,mode,count):
    old={model:Packet(model,mode,True) for model in MODELS}
    new={model:Packet(model,mode,False) for model in MODELS}
    begin,switch,end,first=split(medium)
    combined={key:[] for key in CASES}
    clocks=[]
    for lower,upper,fields,nodes in ((begin,switch,{model:(new[model] if model==first else old[model]) for model in MODELS},33),(switch,end,new,count)):
        scale=np.linspace(lower,upper,nodes)
        physical=history.branches(medium,fields,scale)
        clocks.append(medium.native('heavy',scale))
        for name,state in physical.items():
            native='heavy' if name=='paired' else name
            weight,gain,moment=kernel(medium,native,scale,medium.am)
            combined[name].append(np.array([weight*state['refC'],gain*state['Y']+moment*state['refC']]))
    clock=np.concatenate(clocks)
    values={}
    for name,pieces in combined.items():
        for field,curve in zip(('C','Y'),np.concatenate(pieces,axis=1)):
            values[name,field]=(clock,curve)
    return values


def measure():
    guard();med=Medium()
    carries=rows('carry-and-center.csv')
    work=rows('physical-impulses.csv')
    radii={row['quantity']:float(row['radius']) for row in rows('peak-allowances.csv')}
    result=[];estimates={}
    for mode in ('p8','p16'):
        low=profiles(med,mode,16385);high=profiles(med,mode,32769)
        for key,(clock,curve) in high.items():
            name,field=key;mod=np.abs(curve)
            start=next(z(row,'carried_'+field) for row in work if (row['mode'],row['model'],row['target'])==(mode,name,'priority midpoint'))
            stop=-next(z(row,'required_center') for row in carries if (row['mode'],row['model'],row['field'])==(mode,name,field))
            radius=radii[field]
            coarse=abs(low[key][1])
            low_index,high_index=int(mod.argmin()),int(mod.argmax())
            checks=[abs(start-curve[0])/radius,abs(stop-curve[-1])/radius,abs(min(coarse)-mod[low_index])/abs(start),abs(max(coarse)-mod[high_index])/abs(start)]
            result.append(dict(mode=mode,model=name,field=field,minimum_over_start=mod[low_index]/abs(start),minimum_heavy_mpc=clock[low_index],maximum_over_start=mod[high_index]/abs(start),maximum_heavy_mpc=clock[high_index],end_over_start=mod[-1]/abs(start),start_error_in_radii=checks[0],end_error_in_radii=checks[1],sample_min_change_over_start=checks[2],sample_max_change_over_start=checks[3],passed=max(checks)<=.005))
            if name=='paired':estimates[mode,field]=(clock,curve)
    budgets=[]
    for field in ('C','Y'):
        clock,fine=estimates['p16',field];other,control=estimates['p8',field]
        assert np.array_equal(clock,other)
        shifts=abs(fine-control)/radii[field]
        peak=int(shifts.argmax())
        budgets.append(dict(field=field,maximum_sampled_step_shift_in_radii=shifts[peak],heavy_mpc=clock[peak],end_shift_in_radii=shifts[-1],sample_count=len(clock),sampled_everywhere_below_one=shifts[peak]<=1))
    write('within-block-centers.csv',result);write('within-block-step-shifts.csv',budgets)
    print('Sampled paired extrema:',[row for row in result if row['model']=='paired' and row['mode']=='p16'])
    print('Within-block sampled shifts:',budgets,flush=True)


if __name__=='__main__':measure()
