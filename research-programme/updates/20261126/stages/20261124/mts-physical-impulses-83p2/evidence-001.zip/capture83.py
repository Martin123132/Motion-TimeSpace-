from block import *
HERE=ROOT/'material-halfstep'
HERE.mkdir(exist_ok=True)
def save(name,raw):
    from block import save as write
    write('material-halfstep/'+name,raw)
def pack(name,**fields):
    stream=io.BytesIO();np.savez_compressed(stream,**fields);save(name,stream.getvalue())
def table(name,rows):
    from block import table as write
    write('material-halfstep/'+name,rows)
from capture_early import driver,diag,Dummy,tempfile,subprocess,NAMES as RAW
NAMES=RAW+'polter E(2) E(3) octg'.split()
def run(model,func):
    native=diag.native;status=native.obj(native.source(f'runs/{model}/status.json'))
    path=native.SPEC/'runs/projection/a225-w6-d8.npz' if model=='heavy' else native.NATIVE/'runs/backgrounds/cold.npz'
    native.checked(path,status['source_hash'])
    for file in native.engine.inherited.native_hashes():native.checked(file,status['input_hashes'][str(file)])
    pars=native.engine.inherited.params_for(path,background_boost=8.);pars.DoLateRadTruncation=False
    bg=native.engine.camb.get_background(pars);bg.Params.Accuracy.IntTolBoost=6
    with np.load(checked(f'forcing-{model}.npz')) as f:legs=f['nodes'];outk=f['k']
    with pin(f'capture-{model}.csv').open() as fp:blocks=list(csv.DictReader(fp))
    t=(12288+np.arange(-8,1033))/160.
    assert t[8]==76.8 and t[-9]==83.2
    keep=np.arange(len(t))<17
    tags='sh' if model=='heavy' else 's';extra=[p+tag for tag in tags for p in ('mts_dphi_','mts_dphidot_')]
    rows=[];pol=[];polar='pig polter E(2) E(3) octg'.split()
    with patch.object(diag.symbolic,'compile_sympy_to_camb_source_func',return_value=func):
        for ix,block in enumerate(blocks+[blocks[-1]]):
            guard();start,end=int(block['first']),int(block['last'])+1;spec=legs[start:end] if ix<len(blocks) else outk
            ks=np.unique(np.r_[spec,float(block['control']),float(block['hierarchy_cap'])])
            extra_rows=bg.get_time_evolution(ks,t[~keep],vars=extra+[Dummy(key) for key in NAMES],lAccuracyBoost=4)[np.searchsorted(ks,spec)]
            key=f'linear-{model}-{ix:02}.npz' if ix<len(blocks) else f'output-native-{model}.npz'
            with np.load(previous('material-halfstep/'+key)) as saved:
                assert np.allclose(saved['eta'][-17:],t[keep],atol=1e-14,rtol=0) and np.array_equal(saved['k'],spec)
                out=np.empty((len(spec),len(t),extra_rows.shape[-1]));out[:,keep]=saved['values'][:,-17:];out[:,~keep]=extra_rows
            raw=dict(zip(extra+NAMES,out.transpose(2,0,1)))
            good=np.isclose(raw['k'],spec[:,None],rtol=1e-13,atol=0);assert good.all() and np.isfinite(out).all()
            if ix==len(blocks):
                pack(f'output-native-{model}.npz',k=spec,eta=t,keys=extra+NAMES,values=out)
                continue
            old=previous(f'material-halfstep/linear-{model}-{ix:02}.npz')
            with np.load(old) as f:
                ref=f['values'][:,-9];names=f['keys'].tolist()
                for var in ('etak','sigma','phi','clxg','qr','mts_dphi_'+tags[-1]):
                    new=raw[var][:,8];target=ref[:,names.index(var)]
                    rows.append(dict(block=ix,field=var,launch_norm_relative=np.linalg.norm(new-target)/max(np.linalg.norm(target),1e-200)))
            pack(f'linear-{model}-{ix:02}.npz',k=spec,begin=start,eta=t,good=good,keys=extra+NAMES,values=out)
            pol.append([raw[key] for key in polar])
            if ix==0:
                scale=raw['a'][-1];fields={}
                with np.load(path) as bank:
                    for tag in tags:
                        grid=bank['heavy_efold' if tag=='h' else 'efold'];assert np.all((np.log(scale)>=grid[0])&(np.log(scale)<=grid[-1]))
                        for var in ('phi','phidot'):
                            spline=CubicSpline(grid,bank[var+'_'+tag]);fields[tag+var]=spline(np.log(scale))
                            if var=='phidot':fields[tag+'vN']=spline(np.log(scale),1);fields[tag+'vNN']=spline(np.log(scale),2)
                        fields[tag+'mass']=bank[('heavy' if tag=='h' else 'slow')+'_mass_mpc']
                pack(f'background-{model}.npz',eta=t,**fields)
    pack(f'polar-{model}.npz',eta=t,keys=polar,values=np.concatenate(pol,axis=1))
    table('native-seam-'+model+'.csv',rows)
    print(model,'native seam max',max(row['launch_norm_relative'] for row in rows),flush=True)
if __name__=='__main__':
    if sys.argv[1:2]==['--child']:
        with patch.object(driver,'HERE',HERE),patch.object(driver,'NAMES',NAMES),patch.object(driver,'run',run),patch.object(driver,'save',save):driver.main()
    else:
        with tempfile.TemporaryDirectory(dir=HERE,prefix='reader-forward-') as tmp:subprocess.run([sys.executable,'-B',str(ROOT/'capture83.py'),'--child',tmp,*sys.argv[1:]],check=True)
