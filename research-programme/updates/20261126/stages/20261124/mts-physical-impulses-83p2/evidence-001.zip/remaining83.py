from copy import copy

from impulse83 import CASES, MODELS, PRE, ROOT, Medium, Packet, digest, guard, history, kernel, manifest, np, write, z
import csv

assert digest(PRE/'precision_cut.py')==manifest['precision_cut.py']
from precision_cut import bracket


def rows(path):
    with path.open(newline='') as stream:
        return list(csv.DictReader(stream))


def measure():
    guard()
    med=Medium()
    assert digest(PRE/'window-conditions.csv')==manifest['window-conditions.csv']
    ceilings={row['quantity']:float(row['one_at_a_time_necessary_ceiling']) for row in rows(PRE/'window-conditions.csv')}
    cut=min(med.root(model,83.2) for model in MODELS)
    early=med.al
    middle=med.am
    output=[]
    estimates=[]
    inputs=rows(ROOT/'physical-impulses.csv')
    for mode in ('p16','p8'):
        cases={model:Packet(model,mode,False) for model in MODELS}
        endpoints=history.branches(med,cases,cut)
        proxy=copy(med)
        proxy.a0=cut
        for name in CASES:
            model='heavy' if name=='paired' else name
            est,rad=bracket(proxy,model,32)
            wc,gain,tc=kernel(med,model,np.array([cut,middle]),middle)
            row=next(item for item in inputs if (item['mode'],item['model'],item['target'])==(mode,name,'priority midpoint'))
            current=endpoints[name]['refC']
            lapse=endpoints[name]['Y']
            remaining_c=-wc[0]*current
            remaining_y=-gain[0]*lapse-est*current
            saved_c=z(row,'remaining_center_C')
            saved_y=z(row,'remaining_center_Y')
            cert=abs(remaining_y-saved_y)+rad*abs(current)
            estimates.append(dict(mode=mode,model=name,cut_model_time=med.native(model,cut),T_est=est,T_bound_radius=rad,source_anchor_kernel=tc[0],C_difference=abs(remaining_c-saved_c),Y_error_radius=cert,Y_error_over_paired_radius=cert/ceilings['midpoint Y']))
            if name!='paired':continue
            def weight_cap(begin,end):
                grid=np.unique(np.r_[begin,med.grid[(med.grid>begin)&(med.grid<end)],end])
                nodes=np.r_[np.linspace(grid[:-1],grid[1:],64,endpoint=False).T.ravel(),end]
                clock=med.native('heavy',nodes)
                assert np.all(np.diff(clock)>0) and np.all(np.diff(nodes)>0)
                return float(np.sum(np.diff(clock)*(nodes[1:]/middle)**2)*(1+1e-9))
            pre=weight_cap(cut,early)
            hot=weight_cap(early,middle)
            floor=max(0.,(abs(remaining_c)-ceilings['midpoint C']-hot*ceilings['window P'])/pre)
            output.append(dict(mode=mode,covered_through=float(med.native('heavy',cut)),hot_begins=float(med.native('heavy',early)),weighted_pre_gain_upper=pre,weighted_hot_gain_upper=hot,pre_window_production_sup_at_least=floor,hot_production_sup_at_most=ceilings['window P'],pre_to_hot_ratio=floor/ceilings['window P'],independent_C_center_difference=abs(saved_c-remaining_c),independent_Y_center_uncertainty=cert))
    write('independent-end-centers.csv',estimates)
    write('remaining-production.csv',output)
    print('Necessary pre/hot ratios:',[row['pre_to_hot_ratio'] for row in output],flush=True)


if __name__=='__main__':measure()
