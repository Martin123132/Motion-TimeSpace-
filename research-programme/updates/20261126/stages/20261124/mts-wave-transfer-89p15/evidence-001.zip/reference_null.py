import sys
from unittest.mock import patch
import local_stage as ps
import matter
from matter import np
import junction as inherited

class Controls:
    def __init__(self,prefix='null-'):self.prefix=prefix
    def __getattr__(self,key):return getattr(ps,key)
    def pack(self,name,**values):ps.pack(self.prefix+name,**values)
    def record(self,name,body):ps.record(self.prefix+name,body)

def run(mode,case='resolved',policy='both-sides'):
    assert policy in ('both-sides','one-sided')
    real_get=matter.get_flow
    def full(folder,case,clock,initial,projection=None):
        flow=real_get(folder,case,clock,initial,projection)
        if projection is not None and policy=='both-sides':
            base=inherited.get_flow(folder,case,clock,initial)
            flow.bg=base.bg;flow.q=base.q;flow.drive=base.drive
        return flow
    out=Controls('null-' if policy=='both-sides' else 'stencil-')
    with patch.object(matter,'ps',out),patch.object(matter,'FLUID',ps.BASE),patch.object(matter,'get_flow',full):
        matter.evolve(mode,case)
if __name__=='__main__':run(*sys.argv[1:])
