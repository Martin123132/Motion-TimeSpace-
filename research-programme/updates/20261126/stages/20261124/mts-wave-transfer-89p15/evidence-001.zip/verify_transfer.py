import csv
import json
from scipy.integrate import cumulative_trapezoid
import wave_kernel as kernel
import local_stage as ps
import photon_match as radiation
from local_stage import np
from phase_stress import CubicSpline
def rows(path):
    with path.open(newline='') as handle:return list(csv.DictReader(handle))
def compare(label,mode,value):return dict(check=label,mode=mode,value=float(value),passed=bool(value<=ps.TOL))
def main():
    ps.guard()
    wave=[];metrics=[];photon=[];readouts=[];slopes=[]
    for mode in ps.MODES:
        clock,curves,k,mass,rho=kernel.read(mode)
        with np.load(ps.HERE/f'curves-{mode}-primary.npz') as data:t=data['eta']
        theta=clock(t);theta[abs(theta)<1e-10]=0
        with np.load(ps.HERE/f'projected-{mode}.npz') as data:
            take=np.searchsorted(data['eta'],t);assert np.array_equal(data['eta'][take],t)
            mean=data['primary_j'][take]
            meanrate=sum(data['primary_'+key][take] for key in ('drag','pressure','lapse','exchange'))
        raw=curves['j'](theta);res=raw-mean;rawrate=curves['wj'](theta)
        for key,rhs,want in (('wave',rawrate,raw),('mean',meanrate,mean),('remaining oscillation',rawrate-meanrate,res)):
            val=want[0]+cumulative_trapezoid(rhs,t,axis=0,initial=0.)
            for seed in (0,1):
                wave.append(compare(key+' integrated rate, seed '+str(seed),mode,kernel.peak(val[:,seed]-want[:,seed])/kernel.peak(want[:,seed]-want[0,seed])))
        with np.load(ps.HERE/f'curves-{mode}-resolved.npz') as raw:
            error0=raw['derivative']-raw['pd'];amp=kernel.peak(raw['pd'])
        for case in (*ps.CASES,'companion'):
            receipt=json.loads((ps.HERE/f'junction-{mode}-{case}.json').read_bytes())
            with np.load(ps.HERE/f'curves-{mode}-{case}.npz') as data:
                delta=data['derivative']-data['pd'];scale=kernel.peak(data['pd'])
                where=int(np.argmax(abs(delta)))
                slopes.append(dict(mode=mode,case=case,maximum_over_full_rate=kernel.peak(delta)/scale,time_at_max=t[where],extra_vs_resolved_over_resolved_rate=kernel.peak(delta-error0)/amp,integral_abs_difference=abs(np.trapezoid(delta,t)),relative_normal_energy_jump=receipt['normal_energy_jump'],relative_normal_momentum_jump=receipt['normal_momentum_jump']))
            for name in ('normal_energy_jump','normal_momentum_jump','pre_seam','seed0_momentum_follow','seed1_momentum_follow'):
                metrics.append(compare(case+' '+name,mode,receipt[name]))
            for key in ('metric','stress','quadrature'):metrics.append(compare(case+' '+key,mode,receipt['recoupling'][-1][key]))
    _,axis,weight,_=radiation.proj.old.get_media();measure=radiation.previous.make_measure(axis,weight)
    denom=rows(radiation.pin(radiation.FROZEN,'window-readouts.csv'))
    numbers=rows(ps.HERE/'photon-window.csv')
    with np.load(ps.pin('photon-accumulated-heavy.npz')) as heavy,np.load(ps.pin('photon-accumulated-cold.npz')) as cold,np.load(ps.HERE/'photon-transfer-primary.npz') as produced:
        grid=produced['scale'];assert np.array_equal(cold['scale'],grid) and np.array_equal(heavy['scale'],grid)
        for idx,(mode,case) in enumerate(produced['inputs']):
            den=float(next(r['launch_norm'] for r in denom if r['model']=='MTS-minus-baseline' and r['gravity']==mode and r['output']=='joint'))
            hist=CubicSpline(grid,heavy['through89p6_'+mode]-cold['through89p6_'+mode])(axis)
            parts=CubicSpline(grid,produced['values'][:,idx])(axis)
            row=next(r for r in numbers if r['mode']==mode and r['projector']==case and r['transport']=='primary')
            for method,pick in [('momentum',[0,1,2]),('differentiated',[0,3,2])]:
                change=parts[:,pick].sum(1)
                value=100*radiation.mag(change,measure)[-1]/den
                final=100*radiation.mag(hist+change,measure)[-1]/den
                expected=float(row['joint_pct' if method=='momentum' else 'differentiated_pct'])
                photon.append(compare(case+' photon replay '+method,mode,abs(value/expected-1)))
                readouts.append(dict(mode=mode,case=case,method=method,norm=den,correction_pct=value,below_0163=bool(value<.163),final_pair_pct=final))
    ps.table('integrated-current-checks.csv',wave);ps.table('metric-rate-diagnostics.csv',slopes);ps.table('independent-readouts.csv',readouts)
    ps.table('replay-checks.csv',metrics+photon)
    phase_fail=[r for mode in ps.MODES for r in rows(ps.HERE/f'transfer-checks-{mode}.csv') if r['passed']=='False']
    rates=[r for r in numbers if r['transport']=='primary' and float(r['rate_disagreement'])>ps.TOL]
    control_fail=[r for r in rows(ps.HERE/'photon-controls.csv') if r['passed']=='False']
    adj=max(float(r['relative']) for r in rows(ps.HERE/'photon-adjoint.csv'))
    assert adj<=ps.TOL and all(r['passed'] for r in photon)
    ps.record('verdict.json',dict(launch_norm=den,threshold_pct=.163,numerical_tolerance=ps.TOL,conditional_photon_all_below=all(float(r[c])<.163 for r in numbers for c in ('joint_pct','differentiated_pct')),max_conditional_pct=max(float(r[c]) for r in numbers for c in ('joint_pct','differentiated_pct')),source_gate_failures=phase_fail,integrated_current_failures=[r for r in wave if not r['passed']],metric_gate_failures=[dict(mode=r['mode'],case=r['case'],error=r['maximum_over_full_rate']) for r in slopes if r['maximum_over_full_rate']>ps.TOL],rate_disagreement_failures=[(r['mode'],r['projector'],r['rate_disagreement']) for r in rates],photon_controls_failed=control_fail,replay_failures=[r for r in photon+metrics if not r['passed']],max_adjoint_error=adj,unique_physical_layer=False))
if __name__=='__main__':main()
