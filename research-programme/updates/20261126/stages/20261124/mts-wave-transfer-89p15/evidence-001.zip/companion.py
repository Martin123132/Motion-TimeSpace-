import wave_kernel as kernel
import local_stage as ps
from local_stage import np
from scipy.interpolate import CubicSpline

def build(mode):
    clock,curves,kk,mass,rho=kernel.read(mode)
    with np.load(ps.HERE/f'projected-{mode}.npz') as source:
        time=source['eta'];cs=source['cs2'];scale=source['scale'];corners=source['corners']
    theta=clock(time);theta[abs(theta)<1e-10]=0
    with np.load(ps.pin('matched-native/linear-heavy-00.npz')) as src:
        keys=list(src['keys']);hub=CubicSpline(src['eta'],src['values'][0,:,keys.index('adotoa')])(time)[:,None]
    avg,rates,jcheck,_,=kernel.sample('primary',time,clock,curves,96,kk,mass,rho)
    dj=avg['j']-curves['j'](theta);djdot=rates['wj']-curves['wj'](theta)
    dp=(djdot+hub*dj)/kk
    ddot=-dj-3*hub*dp
    keep=np.ones(len(time),bool)
    for edge in corners:keep&=(abs(time-edge)>2e-8)|(time==edge)
    primitive=CubicSpline(time[keep],ddot[keep]).antiderivative();dd=primitive(time)-primitive(time[0])
    pressure=curves['p'](theta)+dp;energy=curves['e'](theta)+dd
    vals=dict(e=energy,j=avg['j'],pres_res=pressure-cs[:,None]*(energy+3*hub*avg['j']/kk),shear=curves['shear'](theta),source_e=curves['se'](theta),source_j=curves['sj'](theta))
    ps.pack('companion-'+mode+'.npz',eta=time,cs2=cs,k2=kk,rho0=rho,scale=scale,corners=corners,delta_p=dp,delta_d=dd,delta_j=dj,**{'companion_'+k:v for k,v in vals.items()})
    metrics=[]
    for seed in (0,1):
        def rel(a,b):return kernel.relative(a[:,seed],b[:,seed])
        checks=dict(required_pressure_vs_averaged=rel(pressure,avg['p']),required_density_vs_averaged=rel(energy,avg['e']),pressure_difference_over_raw_wave_peak=kernel.peak((pressure-avg['p'])[:,seed])/kernel.peak(curves['p'](theta)[:,seed]),pressure_shift_over_raw_wave_peak=kernel.peak(dp[:,seed])/kernel.peak(curves['p'](theta)[:,seed]),momentum_identity=kernel.peak((jcheck+hub*avg['j']-kk*(pressure+curves['psi'](theta))-curves['sj'](theta))[:,seed])/kernel.peak(rates['wj'][:,seed]),energy_identity=kernel.peak((primitive(time,1)+dj+3*hub*dp)[:,seed])/kernel.peak(ddot[:,seed]))
        metrics.extend(dict(mode=mode,seed=seed,check=k,relative=v) for k,v in checks.items())
    ps.table('companion-checks-'+mode+'.csv',metrics)
if __name__=='__main__':
    import sys
    build(sys.argv[1])
