import local_stage as ps
import photon_match as retained
from photon_match import proj,prior,previous,pin,FROZEN,solve_banded,CubicSpline,mag,simpson,np,csv
from unittest.mock import patch
def transfer(*args):
    with patch.object(retained,'ps',ps):return retained.transfer(*args)

def main():
    grid,eta,medium,peak,weights=proj.measure('heavy')
    with np.load(ps.pin('photon-accumulated-heavy.npz')) as data:
        assert np.array_equal(grid,data['scale']);wave=float(data['k']);heavy={m:data['through89p6_'+m] for m in ps.MODES}
    with np.load(ps.pin('photon-accumulated-cold.npz')) as data:
        assert np.array_equal(grid,data['scale']);cold={m:data['through89p6_'+m] for m in ps.MODES}
    refs=list(csv.DictReader(pin(FROZEN,'window-readouts.csv').open()))
    norm={r['gravity']:float(r['launch_norm']) for r in refs if r['model']=='MTS-minus-baseline' and r['output']=='joint'}
    hist={}
    for mode in ps.MODES:
        for case in (*ps.CASES,'companion'):
            with np.load(ps.HERE/f'curves-{mode}-{case}.npz') as raw:hist[mode,case]={n:raw[n] for n in ('eta','delta_pd','delta_psi','delta_differentiated','kick')}
    media,axis,weights,_=proj.old.get_media();measure=previous.make_measure(axis,weights)
    dense=np.linspace(axis[0],axis[-1],16385)
    with np.load(proj.medium_file('medium-cold.npz')) as data:
        weight=CubicSpline(data['scale'],data['visibility'])(dense)*media['cold']['clock'](dense,1)
    fine=previous.make_measure(dense,weight/simpson(weight,x=dense))
    rows=[];vectors={};checks=[]
    for setting in prior.SETTINGS:
        values=transfer(setting,eta,grid,medium,wave,hist)
        ps.pack('photon-transfer-'+setting+'.npz',scale=grid,inputs=list(hist),outputs=['energy','current'],channels=['kick','curvature_momentum_constraint','lapse','curvature_differentiated'],values=values)
        for idx,(mode,case) in enumerate(hist):
            curve=CubicSpline(grid,values[:,idx]);v=curve(axis)
            pct=lambda x:100*mag(x,measure)/norm[mode]
            corr=v[:,:3].sum(1);alt=v[:,[0,2,3]].sum(1)
            full=CubicSpline(grid,heavy[mode]-cold[mode])(axis)
            mags=pct(corr);vectors[mode,case,setting]=corr
            rows.append(dict(mode=mode,projector=case,transport=setting,energy_pct=mags[0],current_pct=mags[1],joint_pct=mags[2],below_0163=bool(mags[2]<.163),kick_pct=pct(v[:,0])[-1],smooth_pct=pct(v[:,1]+v[:,2])[-1],differentiated_pct=pct(alt)[-1],rate_disagreement=mag(alt-corr,measure)[-1]/mag(corr,measure)[-1],full_before_pct=pct(full)[-1],full_after_pct=pct(full+corr)[-1],quadrature_error=float(abs(100*mag(curve(dense)[:,:3].sum(1),fine)[-1]/norm[mode]/mags[2]-1))))
        print(setting,rows[-3],flush=True)
    for (mode,case,setting),vec in vectors.items():
        if setting!='primary':continue
        others=[('time',vectors[mode,case,'time']),('angle',vectors[mode,case,'angle'])]
        if mode=='p32':others.append(('gravity',vectors['p16',case,setting]))
        for label,other in others:
            e=mag(vec-other,measure)/mag(vec,measure)
            checks.append(dict(mode=mode,projector=case,test=label,energy=e[0],current=e[1],joint=e[2],passed=bool(max(e)<=ps.TOL)))
    ps.table('photon-window.csv',rows);ps.table('photon-controls.csv',checks)
if __name__=='__main__':main()
