import local_stage as ps
import junction as retained
from junction import SimpleNamespace,Flow,Matched,BASE89,FLUID,physical_axis,np,CubicSpline,spline,err,json,digest,ti,make_shape,MOM,lag_flight,four_stresses,sys

class Prepared(Matched):
    def injection(self,u,stress):
        result=super().injection(u,stress)
        t=np.exp(u);pressure,energy,current=self.second(t)
        hub=self.bg(u)[self.bgkeys.index('h')]
        result[:,self.ix['hf'],1]+=t*(energy-3*hub*pressure)
        result[:,self.ix['hw'],1]+=t*(current+self.k[:,0]**2*pressure)
        return result

def get_flow(folder,case,clock,initial,projection=None):
    flow=retained.get_flow(folder,case,clock,initial,projection)
    if projection is None:return flow
    flow.__class__=Prepared
    src=projection
    labels=['pres_res','source_e','source_j','shear']
    vals=np.column_stack([src['cs2'],*[src[case+'_'+name][:,0] for name in labels],*[np.diff(src[case+'_'+name],axis=1)[:,0] for name in labels[:3]]])
    time=src['eta'];first,second=src['corners']
    segments=[]
    for left,right in ((-np.inf,first),(first,second),(second,np.inf)):
        take=(time>=left+5e-9)&(time<=right-5e-9)
        segments.append(CubicSpline(time[take],vals[take]))
    def scalar(t):
        return segments[int(t>=first)+int(t>=second)](t)
    flow.coeffs=lambda t:scalar(t)[:5]
    flow.second=lambda t:scalar(t)[5:]
    return flow

def evolve(mode,case):
    ps.guard(); switch=ps.event()
    with np.load(ps.pin('original-through89/particular-heavy-'+mode+'.npz')) as prior:
        start=prior['state'][:,:1];lag=prior['lagEnd'][:,:,:1];shape0=prior['shape'][-1,:,:1];names=list(prior['keys']);start_obs=prior['obs'][-1];assert prior['eta'][-1]==89.
    with np.load(ps.pin('particular-heavy-'+mode+'.npz')) as explicit:
        clock=explicit['eta'];saved_stress=explicit['stress'];stress_time=explicit['stressClock']
        ref=CubicSpline(clock,np.column_stack((explicit['phi'],explicit['psi'],explicit['phi_dot'])))
    with np.load(ps.HERE/(('companion-' if case=='companion' else 'projected-')+mode+'.npz')) as data:g=dict(data.items())
    pre=get_flow(BASE89,case,physical_axis(clock,89.,switch),start)
    assert pre.keys==names
    ta,oa,no,states=pre.evolve(stress_time,saved_stress)
    initial=states[-1].copy()
    reference=case
    post=get_flow(FLUID,reference,physical_axis(clock,switch,89.6),initial,g)
    src=FLUID/'bank-heavy.json';hashes=json.loads(src.read_bytes())
    assert len(hashes)==82 and all(digest(FLUID/path)==sig for path,sig in hashes.items())
    with np.load(FLUID/'common-heavy.npz') as bank:
        tbank=bank['eta'];ell=bank['S'];spectral=bank['Sw'];wave=bank['k']
    kernelclock=physical_axis(tbank,89.,89.6)
    def resample(val):
        return CubicSpline(tbank,val.T)(kernelclock).T[None]
    common=resample(ell);spec=resample(spectral)
    meta=json.loads(ti.parent.pin('radiation-background.json').read_bytes())['heavy']
    with np.load(FLUID/'material-halfstep/forcing-heavy.npz') as data:
        b=dict(zip(data['bgkeys'],data['background']));bc=data['eta']
    win=SimpleNamespace(t=kernelclock,k=wave,mass=meta['mass_over_temperature'],coeff=meta['massless_limit_coeff']/(7*np.pi**4/120),af=spline(bc,b['a']),energy=spline(bc,b['enu']))
    shape=make_shape(dict(eta=kernelclock,k=wave,S=common,Sw=spec),shape0)
    win.shape=spline(kernelclock,shape)
    drivers=[]
    for node,mom in enumerate(MOM,-52):
        with np.load(FLUID/f'micro-heavy-{node}.npz') as bank:
            assert bank['q']==mom
            drivers.append(resample(bank['source']))
    ii=post.ix;h=post.bg(post.log[0]);bg=dict(zip(post.bgkeys,h))
    rho=post.rho0/bg['a'];kk=float(g['k2'])
    den=kk+(3*(bg['ec']+bg['eb']+bg['sv']**2+rho)+4*(bg['eg']+bg['er'])+bg['nuE'])/2
    left,forcing,_=pre.env(np.log(switch));vel=left['hv'];pf=(left['a']*left['hm'])**2*left['hb']
    ef=(vel*initial[ii['hw'],0]+pf*initial[ii['hf'],0]+forcing['henergy'][0]+3*vel**2*oa[-1,0,0])/rho
    jf=(kk*vel*initial[ii['hf'],0]+forcing['hJ'][0])/rho
    e0,j0=ef,jf
    def set_state(times,stress):
        at=CubicSpline(np.log(times),stress)(post.log[0])*bg['enu'];at[1]*=post.k
        st=post.initial[1];st[ii['hf']]=0;st[ii['hw']]=j0
        scaled=np.stack([post.launch(0,free).T for free in range(2)],axis=-1)
        phi0=post.observe(post.log[0],scaled,at)[0][0,0]
        newphi=(phi0-rho*e0/(2*den))/(1-3*rho/(2*den));st[ii['hf']]=e0-3*newphi
    def observe(times,stress):
        set_state(times,stress)
        tb,ob,nn,ss=post.evolve(times,stress)
        return tb,ob,nn,ss
    tb,ob,nn,ss=observe(stress_time,saved_stress)
    def piece(left,right):
        return lambda u:left(u) if u<np.log(switch) else right(u)
    tests=[];curr=spline(stress_time,saved_stress)(np.log(kernelclock))
    for iteration in range(4):
        win.normal=piece(spline(ta,no),spline(tb,nn));win.lapse=piece(spline(ta,oa[:,1]),spline(tb,ob[:,1]))
        low=[]
        for index,mom in enumerate(MOM):
            if index%12==0:ps.guard()
            trace=lag_flight(win,mom,drivers[index],lag[index]);low.append(trace[:,:3])
        new,check=four_stresses(win,np.stack(low,axis=1))
        old_ob=ob;tb,ob,nn,ss=observe(kernelclock,new)
        tests.append(dict(iteration=iteration+1,stress=err(new,curr),metric=err(ob[:,:4],old_ob[:,:4]),quadrature=err(check,new)))
        curr=new
        if iteration>=1 and max(tests[-1]['stress'],tests[-1]['metric'])<.005:break
    else:raise ArithmeticError('77-bin recoupling failed')
    result_e=ss[:,ii['hf'],0]+3*ob[:,0,0];result_j=ss[:,ii['hw'],0]
    lapse=ob[:,1,0,0];phi=ob[:,0,0,0];F=ob[:,3,0,0]/tb
    pd=-F-post.bg(post.log)[:,post.bgkeys.index('h')]*lapse+post.q(post.log)[:,post.qkeys.index('Fq'),0]
    physical=CubicSpline(tb,phi)(tb,1)
    projected=lambda name:CubicSpline(g['eta'],g[reference+'_'+name])(tb)
    diagnostics=dict(recoupling=tests,seed0_energy_follow=err(result_e[:,:1],projected('e')[:,:1]),seed1_energy_follow=err(result_e[:,1:],projected('e')[:,1:]),seed0_momentum_follow=err(result_j[:,:1],projected('j')[:,:1]),seed1_momentum_follow=err(result_j[:,1:],projected('j')[:,1:]),entry_e=err(result_e[:1],projected('e')[:1]),entry_j=err(result_j[:1],projected('j')[:1]),metric_derivative=err(physical,pd),entry_phi_vs_explicit=float(abs(oa[-1,0,0,0]-ref(switch)[0])/abs(ref(switch)[0])),pre_seam=err(oa[:1,:4],start_obs[None,:4]),switch=switch)
    refvals=ref(tb)
    if case in (*ps.CASES,'companion'):
        diagnostics.update(normal_energy_jump=err(result_e[:1],ef[None]),normal_momentum_jump=err(result_j[:1],jf[None]),physical_join='normal heavy energy and longitudinal momentum on the fixed slice')
    kick=phi[0]-refvals[0,0]
    ps.record(f'junction-{mode}-{case}.json',diagnostics)
    ps.pack(f'curves-{mode}-{case}.npz',eta=tb,phi=phi,psi=lapse,pd=pd,derivative=physical,delta_pd=pd-refvals[:,2],delta_psi=lapse-refvals[:,1],delta_differentiated=physical-CubicSpline(clock,ref(clock)[:,0])(tb,1),kick=kick,pre_phi=oa[-1,0,0],post_phi=ob[0,0,0],pre_psi=oa[-1,1,0],post_psi=ob[0,1,0],e=result_e,j=result_j,rest_state=ss[-1],stress=curr)
    print(mode,case,diagnostics,flush=True)
if __name__=='__main__':evolve(*sys.argv[1:])
