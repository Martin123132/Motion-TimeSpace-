from pathlib import Path
import csv
import hashlib
import io
import json
import sys
import numpy as np

HERE=Path(__file__).resolve().parent
PARENT=HERE.parent/'mts-wave-stress-match-89p15-20261124'
def digest(path):
    with path.open('rb') as handle:return hashlib.file_digest(handle,'sha256').hexdigest()
assert digest(PARENT/'seal.json')=='c524e2a487341c78eabce05231c2ea706e1ce564e0d4696341ecd191341bdd91'
manifest=json.loads((PARENT/'seal.json').read_bytes())['files']
def parent(name):
    path=PARENT/name
    assert digest(path)==manifest[name],name
    return path
for name in ('phase_stress.py','matched_flow.py','junction.py','photon_match.py','gravity89.py','block.py','fluid/bank-heavy.json'):parent(name)
sys.path.insert(0,str(PARENT))
import phase_stress as archived
BASE=archived.BASE
MODES=archived.MODES
TOL=archived.TOL
CASES=('primary','two_cycles','progressive','resolved')
pin=archived.pin
event=archived.event
def guard():
    archived.guard()
    assert not (HERE/'STOP-REQUESTED').exists()
def save(name,data):
    guard();path=HERE/name
    if path.exists():assert path.read_bytes()==data,name
    else:
        with path.open('xb') as handle:handle.write(data)
def pack(name,**data):
    buf=io.BytesIO();np.savez_compressed(buf,**data);save(name,buf.getvalue())
def table(name,rows):
    buf=io.StringIO();out=csv.DictWriter(buf,rows[0],lineterminator='\n');out.writeheader();out.writerows(rows);save(name,buf.getvalue().encode())
def record(name,data):save(name,(json.dumps(data,sort_keys=True,indent=2,allow_nan=False)+'\n').encode())
