import local_stage as stage
from local_stage import np
from scipy.interpolate import CubicSpline
from scipy.optimize import brentq
from scipy.special import roots_legendre

def peak(value):return float(np.max(np.abs(value)))
def relative(value,reference):
    return peak(value-reference)/max(peak(reference),1e-80)

def read(mode):
    for name in (f'metric-heavy-{mode}.json',f'particular-heavy-{mode}.npz','material-halfstep/forcing-heavy.npz'):stage.parent(name)
    with np.load(stage.pin('exact-phase-extension.npz')) as packet:
        phase=CubicSpline(packet['heavy_efold'],packet['phase_h']);rho=float(packet['matching_density']);mass=float(packet['heavy_mass_mpc'])
    joined=[stage.archived.wave_series(folder,mode,dict(matching_density=rho)) for folder in (stage.BASE,stage.PARENT)]
    t=np.r_[joined[0][0][:-1],joined[1][0]];scale=np.r_[joined[0][1][:-1],joined[1][1]]
    sel=(t>88.38)&(t<90.36);t=t[sel];scale=scale[sel]
    kk=joined[0][-1];assert kk==joined[1][-1]
    data={key:np.concatenate([joined[0][2][key][:-1],joined[1][2][key]])[sel] for key in joined[0][2]}
    hubs=[]
    for folder,item in zip((stage.BASE,stage.PARENT),joined):
        with np.load(folder/'material-halfstep/forcing-heavy.npz') as raw:
            hubs.append(CubicSpline(np.log(raw['eta']),raw['background'][list(raw['bgkeys']).index('h')])(np.log(item[0])))
    h=np.r_[hubs[0][:-1],hubs[1]][sel,None]
    data.update(drag=-h*data['j'],pressure=kk*data['p'],lapse=kk*data['psi'],exchange=data['sj'],wd=-data['j']-3*h*data['p']+data['se'])
    data['wj']=sum(data[k] for k in ('drag','pressure','lapse','exchange'))
    theta=phase(np.log(scale));clock=CubicSpline(t,theta);theta=theta-clock(stage.event());clock=CubicSpline(t,theta)
    speed=clock(t,1)[:,None];assert np.all(speed>0)
    curves={key:CubicSpline(theta,value,extrapolate=False) for key,value in data.items()}
    for key in ('wd','wj','drag','pressure','lapse','exchange'):
        curves[key+'_phase']=CubicSpline(theta,data[key]/speed,extrapolate=False)
    return clock,curves,kk,mass,rho

def sample(case,mom,clock,curves,nquad,kk,mass,rho):
    theta=clock(mom);theta[abs(theta)<1e-10]=0
    assert min(theta)>=0
    span=(2 if case=='two_cycles' else 1)*np.pi
    if case=='resolved':
        means={key:curves[key](theta) for key in ('flat','e','j','p','phi','psi','shear')}
        rates={key:curves[key](theta) for key in ('wd','wj','drag','pressure','lapse','exchange')}
        rhsj=curves['j'](theta,1)*clock(mom,1)[:,None];rhsd=curves['flat'](theta,1)*clock(mom,1)[:,None]
        return means,rates,rhsj,rhsd
    depth=np.minimum(theta,span)
    nodes,weight=roots_legendre(nquad);frac=(nodes+1)/2;weight=weight/2
    start=theta-depth
    pts=start[:,None]+depth[:,None]*frac
    mean=lambda samples:np.einsum('i,tij->tj',weight,samples)
    growing=case=='progressive'
    part=(np.ones_like(depth) if growing else depth/span)[:,None]
    means={key:(1-part)*curves[key](0.)+part*mean(curves[key](pts)) for key in ('flat','e','j','p','phi','psi','shear')}
    speed=clock(mom,1)[:,None]
    rateweight=np.where((theta<span)[:,None] & growing,frac[None,:],1.)[:,:,None]
    rates={key:speed*part*mean(rateweight*curves[key+'_phase'](pts)) for key in ('wd','wj','drag','pressure','lapse','exchange')}
    def independent(key):
        result=(curves[key](theta)-curves[key](start))/span
        if growing:
            good=(theta>0)&(theta<span)
            result[good]=(curves[key](theta[good])-means[key][good])/theta[good,None]
            result[theta==0]=curves[key](0.,1)/2
        return speed*result
    return means,rates,independent('j'),independent('flat')

def build(mode):
    stage.guard();clock,curves,kk,mass,rho=read(mode);lo=stage.event();hi=89.6
    cycles=int(clock(hi)/np.pi);assert cycles>=3
    end=lambda n:brentq(lambda t:clock(t)-n*np.pi,88.4,90.35,xtol=5e-13)
    with np.load(stage.pin('particular-heavy-'+mode+'.npz')) as raw:
        saved=raw['eta'];mom=np.r_[lo,saved[(saved>lo)&(saved<=hi)]]
    corners=[end(n) for n in (1,2)]
    mom=np.unique(np.r_[mom,*[np.array([edge-1e-8,edge,edge+1e-8]) for edge in corners]])
    with np.load(stage.pin('matched-native/linear-heavy-00.npz')) as src:
        keys=list(src['keys']);bg=CubicSpline(src['eta'],src['values'][0][:,[keys.index('a'),keys.index('adotoa')]])(mom)
    scale,h=bg.T;h=h[:,None];ratio=kk/(scale*mass)**2;cs=ratio/(np.sqrt(1+ratio)+1)**2
    payload=dict(eta=mom,cs2=cs,k2=kk,rho0=rho,scale=scale,corners=corners)
    rows=[];cycle_rows=[];components=[]
    points,weights=roots_legendre(96);frac=(points+1)/2;weights/=2
    for n in range(-4,cycles):
        theta=(n+frac)*np.pi;j=curves['j'](theta);avg=weights@j
        osc=np.sqrt(weights@abs(j-avg)**2)
        fluxes={key:np.pi*(weights@curves[key+'_phase'](theta)) for key in ('drag','pressure','lapse','exchange')}
        delta=curves['j']((n+1)*np.pi)-curves['j'](n*np.pi)
        for seed in (0,1):
            cycle_rows.append(dict(mode=mode,cycle=n,seed=seed,begin=end(n),finish=end(n+1),mean_real=avg[seed].real,mean_imag=avg[seed].imag,osc_rms=osc[seed],delta_real=delta[seed].real,delta_imag=delta[seed].imag,balance_over_osc=abs(sum(fluxes.values())[seed]-delta[seed])/osc[seed]))
            for key,v in fluxes.items():components.append(dict(mode=mode,cycle=n,seed=seed,term=key,re=v[seed].real,im=v[seed].imag))
    for case in stage.CASES:
        means,rates,jrate,drate=sample(case,mom,clock,curves,96,kk,mass,rho)
        alt,other,_,_=sample(case,mom,clock,curves,48,kk,mass,rho)
        vals=dict(e=means['e'],j=means['j'],pres_res=means['p']-cs[:,None]*(means['e']+3*h*means['j']/kk),shear=means['shear'],source_e=rates['wd']+means['j']+3*h*means['p'],source_j=rates['wj']+h*means['j']-kk*(means['p']+means['psi']))
        payload.update({case+'_'+key:value for key,value in vals.items()})
        payload.update({case+'_'+key:value for key,value in rates.items() if key in ('drag','pressure','lapse','exchange')})
        for seed in (0,1):
            measures=dict(momentum_balance=relative(rates['wj'][:,seed],jrate[:,seed]),energy_balance=relative(rates['wd'][:,seed],drate[:,seed]),quadrature_j=relative(other['wj'][:,seed],rates['wj'][:,seed]),quadrature_e=relative(other['wd'][:,seed],rates['wd'][:,seed]),split=relative(sum(rates[k] for k in ('drag','pressure','lapse','exchange'))[:,seed],rates['wj'][:,seed]))
            for key,val in measures.items():rows.append(dict(mode=mode,case=case,seed=seed,check=key,relative=val,passed=val<=stage.TOL))
    stage.pack('projected-'+mode+'.npz',**payload);stage.table('transfer-checks-'+mode+'.csv',rows)
    stage.table('cycles-'+mode+'.csv',cycle_rows);stage.table('impulses-'+mode+'.csv',components)
    print(mode,'cycles',cycles,'duration',corners[0]-lo,'failures',[r for r in rows if not r['passed']],flush=True)
if __name__=='__main__':
    for mode in stage.MODES:build(mode)
