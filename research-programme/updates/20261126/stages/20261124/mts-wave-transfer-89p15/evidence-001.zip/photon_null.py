import photons
from photons import ps,proj,previous,pin,FROZEN,np,mag,CubicSpline,csv,patch,retained
from reference_null import Controls
def main():
    grid,eta,medium,peak,_=proj.measure('heavy')
    with np.load(ps.pin('photon-accumulated-heavy.npz')) as packet:wave=float(packet['k'])
    with pin(FROZEN,'window-readouts.csv').open() as stream:
        denom={r['gravity']:float(r['launch_norm']) for r in csv.DictReader(stream) if r['model']=='MTS-minus-baseline' and r['output']=='joint'}
    _,axis,weights,_=proj.old.get_media();measure=previous.make_measure(axis,weights)
    hist={}
    for mode in ps.MODES:
        for key,case in (('primary','resolved'),('companion','companion')):
            with np.load(ps.HERE/f'null-curves-{mode}-{case}.npz') as data:hist[mode,key]={n:data[n] for n in ('eta','delta_pd','delta_differentiated','delta_psi','kick')}
    controls=Controls();controls.table=lambda name,rows:ps.table('null-'+name,rows)
    rows=[]
    with patch.object(retained,'ps',controls):
        for setting in ('primary','time','angle'):
            values=retained.transfer(setting,eta,grid,medium,wave,hist)
            ps.pack('null-photons-'+setting+'.npz',scale=grid,inputs=list(hist),values=values)
            for index,(mode,case) in enumerate(hist):
                fields=CubicSpline(grid,values[:,index])(axis)
                for tag,target in [(case,fields)]+([('companion_minus_resolved',fields-CubicSpline(grid,values[:,index-1])(axis))] if case=='companion' else []):
                    corr=target[:,:3].sum(1);alt=target[:,[0,2,3]].sum(1)
                    peaknorm=mag(corr,measure)[-1]
                    rows.append(dict(gravity=mode,case=tag if tag!='primary' else 'resolved',transport=setting,joint_pct=100*peaknorm/denom[mode],differentiated_pct=100*mag(alt,measure)[-1]/denom[mode],rate_relative=mag(alt-corr,measure)[-1]/peaknorm))
    ps.table('null-readouts.csv',rows)
if __name__=='__main__':main()
