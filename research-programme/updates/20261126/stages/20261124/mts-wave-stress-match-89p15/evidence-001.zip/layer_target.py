import csv
import phase_stress as ps
from phase_stress import np
def main():
    with (ps.HERE/'photon-window.csv').open() as handle:rows=list(csv.DictReader(handle))
    out=[]
    for mode in ps.MODES:
        for case in ('primary','continuous'):
            row=next(r for r in rows if r['mode']==mode and r['projector']==case and r['transport']=='primary')
            corr=float(row['joint_pct']);kick_pct=float(row['kick_pct'])
            with np.load(ps.HERE/f'curves-{mode}-{case}.npz') as data:jump=float(abs(data['kick']))
            assert jump>0 and kick_pct>0
            gain=kick_pct/jump
            out.append(dict(mode=mode,join=case,known_correction_pct=corr,actual_abs_delta_phi=jump,gain_pct_per_abs_delta_phi=gain,sufficient_max_additional_abs_delta_phi=max(0.,.163-corr)/gain,scope='single extra same-epoch curvature impulse only; no change to forcing or opacity'))
    ps.table('layer-target.csv',out)
if __name__=='__main__':main()
