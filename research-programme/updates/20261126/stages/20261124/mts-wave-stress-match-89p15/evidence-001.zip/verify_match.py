import sys
import phase_stress as ps
from phase_stress import np,CubicSpline,json,csv
sys.path.insert(0,str(ps.BASE))
from score89 import previous,proj,mag,pin,FROZEN
def rows(filename):
    with (ps.HERE/filename).open() as stream:return list(csv.DictReader(stream))
def main():
    ps.guard();ps.pin('window-readouts.csv')
    base_rows=list(csv.DictReader(ps.pin('window-readouts.csv').open()))
    orig=list(csv.DictReader(pin(FROZEN,'window-readouts.csv').open()))
    norm=float(next(r['launch_norm'] for r in orig if r['model']=='MTS-minus-baseline' and r['output']=='joint' and r['gravity']=='p32'))
    _,axis,weights,_=proj.old.get_media();measure=previous.make_measure(axis,weights)
    rr=rows('photon-window.csv');controls=rows('photon-controls.csv')
    checks=[];ratios={};continuity={};wardfail=[]
    def check(name,value,limit):checks.append(dict(check=name,value=float(value),limit=limit,passed=bool(value<=limit)))
    for folder in (ps.HERE,ps.HERE/'fluid'):
        hashes=json.loads((folder/'bank-heavy.json').read_bytes())
        assert len(hashes)==82 and all(ps.digest(folder/n)==s for n,s in hashes.items())
    for mode in ps.MODES:
        d=mode[1:]
        with np.load(ps.pin('photon-accumulated-cold.npz')) as cold,np.load(ps.pin('photon-accumulated-heavy.npz')) as heavy:
            grid=cold['scale'];assert np.array_equal(grid,heavy['scale'])
            before=CubicSpline(grid,heavy['through89p6_'+mode]-cold['through89p6_'+mode])(axis)
            base=next(float(r['through89p6_pct']) for r in base_rows if r['model']=='MTS-minus-baseline' and r['gravity']==mode and r['output']=='joint')
            check(mode+' unchanged paired history',abs(100*mag(before,measure)[-1]/norm/base-1),1e-10)
        for entry in rows('ward-'+mode+'.csv'):
            if float(entry['relative'])>ps.TOL:wardfail.append(entry)
        for case in (*ps.CONFIG,'continuous'):
            entry=next(r for r in rr if r['mode']==mode and r['projector']==case and r['transport']=='primary')
            j=json.loads((ps.HERE/f'junction-{mode}-{case}.json').read_bytes())
            for label in ('stress','metric','quadrature'):check(mode+'/'+case+' coupled '+label,j['recoupling'][-1][label],ps.TOL)
            for label in ('metric_derivative','entry_phi_vs_explicit','pre_seam'):check(mode+'/'+case+' '+label,j[label],ps.TOL)
            if case=='continuous':continuity[mode]={k:j[k] for k in ('normal_energy_jump','normal_momentum_jump','entry_e','entry_j')}
            with np.load(ps.HERE/'photon-transfer-primary.npz') as series:
                idx=list(map(tuple,series['inputs'])).index((mode,case))
                v=CubicSpline(grid,series['values'][:,idx,:3].sum(axis=1))(axis)
                actual=100*mag(v,measure)[-1]/norm
                final=100*mag(before+v,measure)[-1]/norm
                check(mode+'/'+case+' independent correction',abs(actual/float(entry['joint_pct'])-1),1e-9)
                check(mode+'/'+case+' independent sum',abs(final/float(entry['full_after_pct'])-1),1e-9)
            ratios[mode+'/'+case]=float(entry['joint_pct'])
    adj=max(float(r['relative']) for r in rows('photon-adjoint.csv'));check('independent adjoint transfer at peak',adj,ps.TOL)
    ps.table('replay-checks.csv',checks)
    jumps=[r for r in rows('surface-jumps.csv') if r['case']=='primary' and r['readout'] in ('e','j')]
    agree=all(float(r['relative_jump'])<=ps.TOL for r in jumps)
    ps.record('validation.json',dict(limit_pct=.163,numerical_tolerance=ps.TOL,launch_norm=norm,baseline_correction=0,conditional_correction_pct=ratios,all_photon_cases_below=all(float(r['joint_pct'])<.163 and float(r['differentiated_pct'])<.163 for r in rr),replay_checks_passed=all(r['passed'] for r in checks),projected_ward_failures=wardfail,photon_control_failures=[r for r in controls if r['passed']!='True'],rate_control_failures=[r for r in rr if float(r['rate_disagreement'])>ps.TOL],max_quadrature_difference=max(float(r['quadrature_error']) for r in rr),adjoint_peak_error=adj,continuous=continuity,projected_join_matches_instantaneous_normal_flux=agree,unique_physical_correction_bounded=False))
    assert all(c['passed'] for c in checks)
if __name__=='__main__':main()
