from block import *
HERE=ROOT/'material-halfstep'
HERE.mkdir(exist_ok=True)
def pack(name,**fields):
    from block import pack as store
    store('material-halfstep/'+name,**fields)
def table(name,rows):
    from block import table as store
    store('material-halfstep/'+name,rows)
def save(name,data):
    from block import save as store
    store('material-halfstep/'+name,data)
