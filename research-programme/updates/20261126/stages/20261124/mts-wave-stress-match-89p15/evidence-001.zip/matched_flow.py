from gravity89 import *
from incident_tail import up
from scipy.interpolate import make_interp_spline

class Matched(Flow):
    def jac_rhs(self,u,state,mask,ob=False):
        t=np.exp(u);bg,src,drive=self.env(u);kk=self.k;k2=kk**2
        scale=self.factors*t**self.power[:,None,None]
        z=dict(zip(self.keys,state*scale));force={key:val[:,None]*mask for key,val in src.items()}
        v=lambda name:z[name]
        eb=bg['eb'];eg=bg['eg'];op=bg['opacity'];h=bg['h'];ratio=eb/eg
        bt=(v('W')-v('B'))/(ratio+4/3);gj=v('B')+4*bt/3
        ne=4*bg['er']+bg.get('nuE',3*bg['enm']);nj=4*bg['er']+bg.get('nuJ',3*bg['enm']);ns=4*bg['er']+bg.get('nuS',3*bg['enm'])
        drag=4/(3*ratio)
        energy=eg*v('gx')+force['gE']+ne*v('N0');J=eg*gj+force['gJ']+kk*nj*v('N1')+force['nuJ']
        shear=-eg*(v('I2')+force['ph_shift'])-ns*v('N2');jac=4*eg+ne
        trace0=np.zeros_like(energy)+bg.get('nuD',0.)*v('N0');trace1=bg.get('nuD',0.)
        for tag,vel in [('c',v('ct')),('b',bt)]:
            rest=bg['e'+tag]*v(tag+'d')+force[tag+'trace']
            energy+=rest+force[tag+'KE'];J+=bg['e'+tag]*vel+force[tag+'Jq'];shear+=force[tag+'shear']
            jac+=3*bg['e'+tag];trace0+=rest;trace1+=3*bg['e'+tag]
        for tag in self.tags:
            vel=bg[tag+'v'];pot=(bg['a']*bg[tag+'m'])**2*bg[tag+'b']*v(tag+'f');kin=vel*v(tag+'w')
            energy+=kin+pot+force[tag+'energy'];J+=k2*vel*v(tag+'f')+force[tag+'J'];shear+=force[tag+'shear']
            jac+=3*vel**2;trace0+=-2*kin+4*pot+force[tag+'trace'];trace1-=6*vel**2
        rho=self.rho0/bg['a']; cs2,pres,extra_e,extra_j,qs=self.coeffs(t)
        energy+=rho*v('hf');J+=rho*v('hw');jac+=3*rho;shear+=rho*qs*mask
        Fcon=-J/(2*k2);con=(force['U']-.5*energy+3*h*Fcon)/(k2+.5*jac)
        phi,F=(z['geom'],z['flux']) if self.trace else (con,Fcon)
        slip=(shear-force['Q'])/k2;psi=phi+slip;pd=-F-h*psi+force['Fq'];D=trace0+trace1*phi
        if ob:return np.stack([phi,psi,(phi+psi)/2,t*F,con,Fcon*t,z['N0']+phi,z['N2'],bt,gj,z[self.tags[-1]+'f'],slip])
        rhs={}
        rhs['geom']=pd;rhs['flux']=-3*h*F+(bg['hp']-h*h)*psi+k2*(phi-slip)/3+D/6+force['QR']-2*force['U']/3
        for tag in self.tags:
            m2=(bg['a']*bg[tag+'m'])**2
            rhs[tag+'f']=v(tag+'w')+bg[tag+'v']*(psi+3*phi)+force[tag+'field']
            rhs[tag+'w']=-2*h*v(tag+'w')-(k2+m2)*v(tag+'f')+m2*bg[tag+'b']*(3*phi-psi)+force[tag+'moment']
        pressure=cs2*(v('hf')+3*phi+3*h*v('hw')/k2)+pres*mask
        rhs['hf']=-v('hw')-3*h*pressure+extra_e*mask
        rhs['hw']=-h*v('hw')+k2*(pressure+psi)+extra_j*mask
        rhs['cd']=-v('ct')+force['cnumber'];rhs['ct']=-h*v('ct')+k2*psi+force['cspeed']
        rhs['bd']=-bt+force['bnumber']
        bfree=-h*bt+k2*psi+force['bspeed']
        gfree=k2*(v('gx')/3+4*(psi+phi)/3-2*v('I2')/3)+force['ph_momentum']
        rhs['gx']=-gj+force['ph_energy']-op*force['collision_heat']
        rhs['W']=gfree+ratio*(bfree+h*bt)+op*(force['collision_b']-force['collision_ph'])
        rhs['B']=gfree-4*bfree/3-op*((1+drag)*v('B')+force['collision_ph']+drag*force['collision_b'])
        zero=np.zeros_like(gj)
        for sp in 'IE':
            for degree in range(2,self.phot+1):
                key=sp+str(degree);nxt=z.get(sp+str(degree+1),zero)
                lower=z.get(sp+str(degree-1),gj/kk if sp=='I' else zero)
                drift=kk*(degree*lower/(2*degree+1)-up(degree,2*(sp=='E'))*nxt)
                if degree==2:
                    source=force['L2' if sp=='I' else 'Le']+op*(.1*v('I2')+.6*v('E2')+force['C'+sp+'kin']+force['C'+sp+'rate'])
                else:source=force[key+':net']
                rhs[key]=drift-op*v(key)+source
        for degree in range(self.limit+1):
            lo=v('N0')+phi+psi if degree==1 else z.get('N'+str(degree-1),zero)
            hi=z.get('N'+str(degree+1),zero)
            rhs['N'+str(degree)]=kk*(degree*lo-(degree+1)*hi)/(2*degree+1)+drive[degree,:,None]*mask
        if not self.trace:rhs['geom']=0*pd;rhs['flux']=0*F
        result=t*np.stack([rhs[key] for key in self.keys])/scale-self.power[:,None,None]*state
        if not self.trace:result[:2]=0
        return result

    def metric_add(self,u,stress):
        bg=dict(zip(self.bgkeys,self.bg(u)));kk=self.k**2;rho=self.rho0/bg['a']
        jac=3*(bg['ec']+bg['eb']+bg['sv']**2+rho)+4*(bg['eg']+bg['er'])+bg['nuE']
        flux=-stress[1]/(2*kk);phi=(-stress[0]/2+3*bg['h']*flux)/(kk+jac/2);slip=stress[2]/kk
        return bg,phi,flux,slip,phi,flux,phi+slip
    def injection(self,u,stress):
        result=super().injection(u,stress)
        bg,phi,_,_,_,_,psi=self.metric_add(u,stress);t=np.exp(u);cs=self.coeffs(t)[0].real
        result[:,self.ix['hf']]+=-9*t*bg['h']*cs*phi
        result[:,self.ix['hw']]+=t*self.k**2*(3*cs*phi+psi)
        return result
