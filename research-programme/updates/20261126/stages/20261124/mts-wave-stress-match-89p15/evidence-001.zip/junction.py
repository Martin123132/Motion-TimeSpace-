from matched_flow import *
from types import SimpleNamespace
import phase_stress as ps

BASE89=ps.BASE
FLUID=ps.HERE/'fluid'
def physical_axis(clock,lo,hi):
    return np.r_[lo,clock[(clock>lo+2e-12)&(clock<hi-2e-12)],hi]

def get_flow(folder,case,clock,initial,projection=None):
    flow=object.__new__(Matched if projection is not None else Flow)
    with patch.object(regular_flow,'HOME',folder/'material-halfstep'):Flight.__init__(flow,'heavy',68,6,False,True)
    flow.wall=flow.start_offset=None
    init_log=flow.log
    select=np.exp(init_log)>=ps.event() if projection is not None else np.ones(len(init_log),bool)
    orig_q=flow.q(init_log)[select,...,:1];orig_b=flow.bg(init_log)[select]
    flow.q=make_interp_spline(init_log[select],orig_q,k=5)
    flow.bg=make_interp_spline(init_log[select],orig_b,k=5)
    with np.load(folder/'common-heavy.npz') as bank:
        sel=bank['eta']>=ps.event() if projection is not None else np.ones(len(bank['eta']),bool)
        flow.drive=spline(bank['eta'][sel],bank['S'][:,sel].T[:,:,None])
    flow.k=flow.k[:1];flow.factors=flow.factors[:,:1];flow.probe=flow.probe[:,:1]
    flow.t=clock;flow.log=np.log(clock);flow.initial=(flow.keys,initial.copy())
    if projection is not None:
        flow.tags='s';g=projection;flow.rho0=float(g['rho0'])
        flow.coeffs=CubicSpline(g['eta'],np.column_stack((g['cs2'],*[g[case+'_'+name][:,0] for name in ('pres_res','source_e','source_j','shear')])))
    return flow

def evolve(mode,case):
    ps.guard(); switch=ps.event()
    with np.load(ps.pin('original-through89/particular-heavy-'+mode+'.npz')) as prior:
        start=prior['state'][:,:1];lag=prior['lagEnd'][:,:,:1];shape0=prior['shape'][-1,:,:1];names=list(prior['keys']);start_obs=prior['obs'][-1];assert prior['eta'][-1]==89.
    with np.load(ps.pin('particular-heavy-'+mode+'.npz')) as explicit:
        clock=explicit['eta'];saved_stress=explicit['stress'];stress_time=explicit['stressClock']
        ref=CubicSpline(clock,np.column_stack((explicit['phi'],explicit['psi'],explicit['phi_dot'])))
    with np.load(ps.HERE/('projected-'+mode+'.npz')) as data:g=dict(data.items())
    pre=get_flow(BASE89,case,physical_axis(clock,89.,switch),start)
    assert pre.keys==names
    ta,oa,no,states=pre.evolve(stress_time,saved_stress)
    initial=states[-1].copy()
    reference='primary' if case=='continuous' else case
    post=get_flow(FLUID,reference,physical_axis(clock,switch,89.6),initial,g)
    src=FLUID/'bank-heavy.json';hashes=json.loads(src.read_bytes())
    assert len(hashes)==82 and all(digest(FLUID/path)==sig for path,sig in hashes.items())
    with np.load(FLUID/'common-heavy.npz') as bank:
        tbank=bank['eta'];ell=bank['S'];spectral=bank['Sw'];wave=bank['k']
    kernelclock=physical_axis(tbank,89.,89.6)
    def resample(val):
        return CubicSpline(tbank,val.T)(kernelclock).T[None]
    common=resample(ell);spec=resample(spectral)
    meta=json.loads(ti.parent.pin('radiation-background.json').read_bytes())['heavy']
    with np.load(FLUID/'material-halfstep/forcing-heavy.npz') as data:
        b=dict(zip(data['bgkeys'],data['background']));bc=data['eta']
    win=SimpleNamespace(t=kernelclock,k=wave,mass=meta['mass_over_temperature'],coeff=meta['massless_limit_coeff']/(7*np.pi**4/120),af=spline(bc,b['a']),energy=spline(bc,b['enu']))
    shape=make_shape(dict(eta=kernelclock,k=wave,S=common,Sw=spec),shape0)
    win.shape=spline(kernelclock,shape)
    drivers=[]
    for node,mom in enumerate(MOM,-52):
        with np.load(FLUID/f'micro-heavy-{node}.npz') as bank:
            assert bank['q']==mom
            drivers.append(resample(bank['source']))
    ii=post.ix;h=post.bg(post.log[0]);bg=dict(zip(post.bgkeys,h))
    rho=post.rho0/bg['a'];kk=float(g['k2'])
    den=kk+(3*(bg['ec']+bg['eb']+bg['sv']**2+rho)+4*(bg['eg']+bg['er'])+bg['nuE'])/2
    left,forcing,_=pre.env(np.log(switch));vel=left['hv'];pf=(left['a']*left['hm'])**2*left['hb']
    ef=(vel*initial[ii['hw'],0]+pf*initial[ii['hf'],0]+forcing['henergy'][0]+3*vel**2*oa[-1,0,0])/rho
    jf=(kk*vel*initial[ii['hf'],0]+forcing['hJ'][0])/rho
    e0,j0=(ef,jf) if case=='continuous' else (g[reference+'_e'][0],g[reference+'_j'][0])
    def set_state(times,stress):
        at=CubicSpline(np.log(times),stress)(post.log[0])*bg['enu'];at[1]*=post.k
        st=post.initial[1];st[ii['hf']]=0;st[ii['hw']]=j0
        scaled=np.stack([post.launch(0,free).T for free in range(2)],axis=-1)
        phi0=post.observe(post.log[0],scaled,at)[0][0,0]
        newphi=(phi0-rho*e0/(2*den))/(1-3*rho/(2*den));st[ii['hf']]=e0-3*newphi
    def observe(times,stress):
        set_state(times,stress)
        tb,ob,nn,ss=post.evolve(times,stress)
        return tb,ob,nn,ss
    tb,ob,nn,ss=observe(stress_time,saved_stress)
    def piece(left,right):
        return lambda u:left(u) if u<np.log(switch) else right(u)
    tests=[];curr=spline(stress_time,saved_stress)(np.log(kernelclock))
    for iteration in range(4):
        win.normal=piece(spline(ta,no),spline(tb,nn));win.lapse=piece(spline(ta,oa[:,1]),spline(tb,ob[:,1]))
        low=[]
        for index,mom in enumerate(MOM):
            if index%12==0:ps.guard()
            trace=lag_flight(win,mom,drivers[index],lag[index]);low.append(trace[:,:3])
        new,check=four_stresses(win,np.stack(low,axis=1))
        old_ob=ob;tb,ob,nn,ss=observe(kernelclock,new)
        tests.append(dict(iteration=iteration+1,stress=err(new,curr),metric=err(ob[:,:4],old_ob[:,:4]),quadrature=err(check,new)))
        curr=new
        if iteration>=1 and max(tests[-1]['stress'],tests[-1]['metric'])<.005:break
    else:raise ArithmeticError('77-bin recoupling failed')
    result_e=ss[:,ii['hf'],0]+3*ob[:,0,0];result_j=ss[:,ii['hw'],0]
    lapse=ob[:,1,0,0];phi=ob[:,0,0,0];F=ob[:,3,0,0]/tb
    pd=-F-post.bg(post.log)[:,post.bgkeys.index('h')]*lapse+post.q(post.log)[:,post.qkeys.index('Fq'),0]
    physical=CubicSpline(tb,phi)(tb,1)
    projected=lambda name:CubicSpline(g['eta'],g[reference+'_'+name])(tb)
    diagnostics=dict(recoupling=tests,seed0_energy_follow=err(result_e[:,:1],projected('e')[:,:1]),seed1_energy_follow=err(result_e[:,1:],projected('e')[:,1:]),seed0_momentum_follow=err(result_j[:,:1],projected('j')[:,:1]),seed1_momentum_follow=err(result_j[:,1:],projected('j')[:,1:]),entry_e=err(result_e[:1],projected('e')[:1]),entry_j=err(result_j[:1],projected('j')[:1]),metric_derivative=err(physical,pd),entry_phi_vs_explicit=float(abs(oa[-1,0,0,0]-ref(switch)[0])/abs(ref(switch)[0])),pre_seam=err(oa[:1,:4],start_obs[None,:4]),switch=switch)
    refvals=ref(tb)
    if case=='continuous':
        diagnostics.update(normal_energy_jump=err(result_e[:1],ef[None]),normal_momentum_jump=err(result_j[:1],jf[None]),physical_join='normal heavy energy and longitudinal momentum on the fixed slice')
    kick=phi[0]-refvals[0,0]
    ps.record(f'junction-{mode}-{case}.json',diagnostics)
    ps.pack(f'curves-{mode}-{case}.npz',eta=tb,phi=phi,psi=lapse,pd=pd,derivative=physical,delta_pd=pd-refvals[:,2],delta_psi=lapse-refvals[:,1],delta_differentiated=physical-CubicSpline(clock,ref(clock)[:,0])(tb,1),kick=kick,pre_phi=oa[-1,0,0],post_phi=ob[0,0,0],pre_psi=oa[-1,1,0],post_psi=ob[0,1,0],e=result_e,j=result_j,rest_state=ss[-1],stress=curr)
    print(mode,case,diagnostics,flush=True)
if __name__=='__main__':evolve(*sys.argv[1:])
