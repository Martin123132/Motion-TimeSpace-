import phase_stress as ps
from phase_stress import np,CubicSpline
def main():
    rows=[]
    for mode in ps.MODES:
        with np.load(ps.HERE/f'projected-{mode}.npz') as data:g=dict(data.items())
        t,_,original,_,_=ps.wave_series(ps.BASE,mode,dict(matching_density=float(g['rho0'])))
        for case in ps.CONFIG:
            with np.load(ps.HERE/f'curves-{mode}-{case}.npz') as data:
                pre=data['pre_phi'];post=data['post_phi']
                readouts={'phi':(pre,post),'psi':(data['pre_psi'],data['post_psi'])}
                for name in ('e','j','p','shear'):
                    readouts[name]=(CubicSpline(t,original[name])(ps.event()),g[case+'_'+name][0])
                for name,(left,right) in readouts.items():
                    for seed,(one,two) in enumerate(zip(left,right,strict=True)):
                        rows.append(dict(mode=mode,case=case,readout=name,seed=seed,left_real=one.real,left_imag=one.imag,right_real=two.real,right_imag=two.imag,relative_jump=abs(two-one)/max(abs(one),abs(two))))
    ps.table('surface-jumps.csv',rows)
if __name__=='__main__':main()
