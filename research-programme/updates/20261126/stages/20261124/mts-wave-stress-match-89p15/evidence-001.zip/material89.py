from block import *
from capture89 import HERE,save,table,pack
import early_source as es
import radiation_terms as rt

def construct(model):
    guard()
    with patch.object(es,'HOME',HERE):
        data=es.read_data(model)
    background=data.background
    mapper=es.Project(data)
    modes=es.Mixed()
    output=[]
    for index,coordinate in enumerate(PROBES):
        guard()
        operator=es.Fast(mapper.ops[index],data)
        with patch.object(es.sources,'Pair',lambda *args:operator):
            fields,_=es.sources.make(modes,np.array(coordinate),data,model)
        for species,delta,velocity in [('c','Dcdm','Vcdm'),('b','Db','Vb')]:
            energy=background['e'+species]
            fields[species+'KE']=energy*operator.grad(velocity,velocity)
            fields[species+'Jq']=energy*(operator.dv(delta,velocity)+3*operator.dv('phi',velocity))
        photon=background['eg']
        fields.update(gE=4*photon*(operator.product('phi','Dg')-operator.product('phi','phi')),
                      gJ=3*photon*operator.dv('phi','Vg'),nuJ=-4*background['er']*operator.dv('phi','Vr')/3-background['enm']*operator.dv('phi','Vm'),
                      phiSq=operator.product('phi','phi'),psiSq=operator.product('psi','psi'))
        output.append(fields)
    values=np.array([list(fields.values()) for fields in output]).transpose(1,2,0)
    pack(f'forcing-{model}.npz',eta=data.eta,nodes=data.nodes,k=[op[1] for op in mapper.ops],coord=PROBES,keys=list(output[0]),values=values,
         bgkeys=list(background),background=np.array(list(background.values())))
    raw=data.raw
    shift=raw['sigma']/data.nodes[:,None]
    reference=np.array([raw['clxr']/4-raw['adotoa']*shift,raw['qr']/4+raw['sigma']/3,raw['pir']/4])
    pack(f'incident-input-{model}.npz',eta=data.eta,k=data.nodes,reference=reference,**{key:data.first[key] for key in ('phi','psi','pd')})
    with patch.object(rt,'HOME',HERE),patch.object(rt,'pack',pack),patch.object(rt,'table',table),patch.object(rt,'guard',guard),patch.object(rt,'read_data',lambda model:data):
        rt.run(model)
    from block import pack as save_coarse
    for kind in ('forcing','incident-input'):
        with np.load(HERE/f'{kind}-{model}.npz') as raw:
            fields=dict(raw.items())
        cut=slice(8,-8,2)
        fields['eta']=fields['eta'][cut]
        assert fields['eta'].shape==(65,) and fields['eta'][0]==89.6 and fields['eta'][-1]==90.4
        if kind=='forcing':
            fields['values']=fields['values'][:,cut];fields['background']=fields['background'][:,cut]
        else:
            for key in ('phi','psi','pd','reference'):fields[key]=fields[key][...,cut]
        save_coarse(f'{kind}-{model}.npz',**fields)
    print(model,'native material, photon and incident sources ready',flush=True)

if __name__=='__main__':
    for model in sys.argv[1:] or ('cold','heavy'):construct(model)
