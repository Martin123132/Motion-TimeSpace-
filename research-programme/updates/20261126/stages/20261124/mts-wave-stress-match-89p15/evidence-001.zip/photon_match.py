import sys
import phase_stress as ps
sys.path.insert(0,str(ps.BASE))
ps.pin('transport89.py');ps.pin('score89.py')
from score89 import proj,prior,previous,pin,FROZEN,solve_banded,CubicSpline,mag,simpson,np
import csv

def transfer(setting,eta,grid,medium,wave,hist):
    order,sub,stride=prior.SETTINGS[setting]
    high=hist['p32','primary']['eta']
    axis=np.unique(np.r_[proj.base_axis(grid,eta,sub),high[::stride],high[-1]])
    start=int(np.searchsorted(axis,ps.event()));end=int(np.searchsorted(axis,89.6))
    assert axis[start]==ps.event() and axis[end]==89.6
    rates,at=proj.coefficients(axis,medium,wave);bands=proj.transfer.stages(order)
    pos=np.searchsorted(axis,eta);assert np.array_equal(axis[pos],eta)
    slots=np.full(len(axis),-1);slots[pos]=np.arange(len(eta))
    count=bands.shape[-1]//2
    pairs=list(hist);ncol=len(pairs)*4
    state=np.zeros((count,2*ncol));right=np.empty((2*count,2*ncol),order='F')
    values=np.zeros((len(eta),2,ncol),complex)
    for col,data in enumerate(hist.values()):
        state[0,8*col:8*col+2]=[4*data['kick'].real,4*data['kick'].imag]
    curves=[]
    for data in hist.values():
        pulse=np.column_stack([data[name] for name in ('delta_pd','delta_psi','delta_differentiated')])
        curve=CubicSpline(data['eta'],pulse,extrapolate=False)
        at_active=np.clip(at[start:end],ps.event(),89.6)
        assert np.max(abs(at_active-at[start:end]))<1e-11
        curves.append(np.diff(axis)[start:end,None,None]*np.einsum('st,ntc->nsc',proj.RAD,curve(at_active)))
    sources=np.stack(curves,axis=1)
    for begin in range(start,len(rates),48):
        if (begin-start)%1536==0:ps.guard();prior.guard()
        finish=min(begin+48,len(rates))
        mats=(rates[begin:finish].reshape(-1,8)@bands.reshape(8,-1)).reshape(-1,11,2*count);mats[:,5]+=1
        for step,mat in enumerate(mats,begin):
            right[::2]=state;right[1::2]=state
            if step<end:
                terms=sources[step-start].transpose(1,0,2)
                for row,chan,key,factor in ((0,1,0,4.),(2,2,1,4*wave/3),(4,2,1,4*wave/3),(0,3,2,4.)):
                    data=factor*terms[:,:,key]
                    right[row:row+2,2*chan::8]+=data.real
                    right[row:row+2,2*chan+1::8]+=data.imag
            state=solve_banded((5,5),mat,right,check_finite=False)[1::2]
            if slots[step+1]>=0:values[slots[step+1]]=state[[0,2],::2]+1j*state[[0,2],1::2]
    assert np.isfinite(values).all()
    result=values.reshape(len(eta),2,len(pairs),4).transpose(0,2,3,1)
    if setting=='primary':
        _,_,_,peak,pweights=proj.measure('heavy')
        active=(axis[:-1]>=ps.event())&(axis[1:]<=89.6)
        dual,stage,kernel=proj.backward(axis,eta,pweights,medium,wave,proj.transpose_bands(bands),snapshot=[start],active=active)
        rows=[]
        for col,((mode,case),data) in enumerate(hist.items()):
            scalar=CubicSpline(data['eta'],np.column_stack([data['delta_pd'],data['delta_psi']]))
            read=np.einsum('nctj,ntc->cj',kernel[active],scalar(stage[active]))
            expect=np.vstack([4*data['kick']*dual[start][0],read])
            computed=CubicSpline(grid,result[:,col,:3])(peak)
            for idx,(lhs,rhs) in enumerate(zip(computed,expect)):
                rows.append(dict(mode=mode,projector=case,channel=idx,relative=np.linalg.norm(lhs-rhs)/np.linalg.norm(rhs)))
        ps.table('photon-adjoint.csv',rows)
    return result

def main():
    grid,eta,medium,peak,weights=proj.measure('heavy')
    with np.load(ps.pin('photon-accumulated-heavy.npz')) as data:
        assert np.array_equal(grid,data['scale']);wave=float(data['k']);heavy={m:data['through89p6_'+m] for m in ps.MODES}
    with np.load(ps.pin('photon-accumulated-cold.npz')) as data:
        assert np.array_equal(grid,data['scale']);cold={m:data['through89p6_'+m] for m in ps.MODES}
    refs=list(csv.DictReader(pin(FROZEN,'window-readouts.csv').open()))
    norm={r['gravity']:float(r['launch_norm']) for r in refs if r['model']=='MTS-minus-baseline' and r['output']=='joint'}
    hist={}
    for mode in ps.MODES:
        for case in (*ps.CONFIG,'continuous'):
            with np.load(ps.HERE/f'curves-{mode}-{case}.npz') as raw:hist[mode,case]={n:raw[n] for n in ('eta','delta_pd','delta_psi','delta_differentiated','kick')}
    media,axis,weights,_=proj.old.get_media();measure=previous.make_measure(axis,weights)
    dense=np.linspace(axis[0],axis[-1],16385)
    with np.load(proj.medium_file('medium-cold.npz')) as data:
        weight=CubicSpline(data['scale'],data['visibility'])(dense)*media['cold']['clock'](dense,1)
    fine=previous.make_measure(dense,weight/simpson(weight,x=dense))
    rows=[];vectors={};checks=[]
    for setting in prior.SETTINGS:
        values=transfer(setting,eta,grid,medium,wave,hist)
        ps.pack('photon-transfer-'+setting+'.npz',scale=grid,inputs=list(hist),outputs=['energy','current'],channels=['kick','curvature_momentum_constraint','lapse','curvature_differentiated'],values=values)
        for idx,(mode,case) in enumerate(hist):
            curve=CubicSpline(grid,values[:,idx]);v=curve(axis)
            pct=lambda x:100*mag(x,measure)/norm[mode]
            corr=v[:,:3].sum(1);alt=v[:,[0,2,3]].sum(1)
            full=CubicSpline(grid,heavy[mode]-cold[mode])(axis)
            mags=pct(corr);vectors[mode,case,setting]=corr
            rows.append(dict(mode=mode,projector=case,transport=setting,energy_pct=mags[0],current_pct=mags[1],joint_pct=mags[2],below_0163=bool(mags[2]<.163),kick_pct=pct(v[:,0])[-1],smooth_pct=pct(v[:,1]+v[:,2])[-1],differentiated_pct=pct(alt)[-1],rate_disagreement=mag(alt-corr,measure)[-1]/mag(corr,measure)[-1],full_before_pct=pct(full)[-1],full_after_pct=pct(full+corr)[-1],quadrature_error=float(abs(100*mag(curve(dense)[:,:3].sum(1),fine)[-1]/norm[mode]/mags[2]-1))))
        print(setting,rows[-3],flush=True)
    for (mode,case,setting),vec in vectors.items():
        if setting!='primary':continue
        others=[('time',vectors[mode,case,'time']),('angle',vectors[mode,case,'angle'])]
        if mode=='p32':others.append(('gravity',vectors['p16',case,setting]))
        if case=='primary':others+= [(key,vectors[mode,key,setting]) for key in ('width','degree')]
        for label,other in others:
            e=mag(vec-other,measure)/mag(vec,measure)
            checks.append(dict(mode=mode,projector=case,test=label,energy=e[0],current=e[1],joint=e[2],passed=bool(max(e)<=ps.TOL)))
    ps.table('photon-window.csv',rows);ps.table('photon-controls.csv',checks)
if __name__=='__main__':main()
