from post64_inputs import *

CASES=('cold','heavy','MTS-minus-baseline')
WINDOWS={'block1':(0,),'block2':(1,),'reversal':(2,),'first-two':(0,1),'three':(0,1,2)}
OBS=('photon energy','photon current','joint')
CHANNELS=('energy forcing','momentum forcing','combined')
TOL=.005

def magnitude(arr):return float(np.linalg.norm(arr))
def nums(value):
    return dict(energy_re=float(value[0].real),energy_im=float(value[0].imag),current_re=float(value[1].real),current_im=float(value[1].imag))
def choose(result,window,channel):
    part=result[list(WINDOWS[window])].sum(axis=0)
    return part[CHANNELS.index(channel)] if channel!='combined' else part.sum(axis=0)
def inspect(value,label):
    return value if label=='joint' else value[OBS.index(label):OBS.index(label)+1]
def align(left,right):
    length=magnitude(left)*magnitude(right)
    return None if length==0 else float(np.vdot(left,right).real/length)
def test(alternative,reference):
    denominator=magnitude(reference);absolute=magnitude(alternative-reference)
    if denominator==0:return absolute,None,absolute==0
    error=absolute/denominator
    return absolute,error,error<=TOL

def compare():
    guard();raw={};references={};trials={};replayed=[]
    for model in CASES[:2]:
        receipt=json.loads((ROOT/f'inputs-{model}.json').read_bytes())
        control=json.loads((ROOT/f'free-inputs-{model}.json').read_bytes())
        assert receipt['source_sha256']==control['source_sha256'] and len(receipt['source_sha256'])==6
        for kind,filename in [('physical','peak'),('opacity-zero','free')]:
            with np.load(ROOT/f'{filename}-{model}.npz') as data:
                assert data['k']==receipt['wavenumber'] and float(data['peak'])==receipt['peak_scale']
                for setting in (['primary','time','angle','forward'] if kind=='physical' else ['primary','time','angle']):
                    array=data[setting]
                    assert array.shape==(2,3,2,2) and np.isfinite(array).all()
                    for ix,mode in enumerate(MODES):raw[model,kind,mode,setting]=array[ix]
                if kind=='physical':
                    for key in ('launch','frozen_through64','archived_block','archived_channels','replay'):references[model,key]=data[key]
    for key in list(raw):
        if key[0]=='heavy':raw[CASES[2],*key[1:]]=raw[key]-raw['cold',*key[1:]]
    for key in list(references):
        if key[0]=='heavy':references[CASES[2],key[1]]=references[key]-references['cold',key[1]]
    result=[];effects=[];scattering=[];numerics=[];small=[];ratio_checks=[]
    for model in CASES:
        launch=magnitude(references[model,'launch'])
        assert launch>0
        for channel in CHANNELS:
            def one(array):
                return array.sum(axis=0) if channel=='combined' else array[CHANNELS.index(channel)]
            ref=one(references[model,'archived_channels'])
            new=one(references[model,'replay'])
            for name in OBS:
                absolute,error,passed=test(inspect(new,name),inspect(ref,name))
                replayed.append(dict(model=model,witness='saved forcing channels',channel=channel,output=name,error=error,passed=passed))
                if channel=='combined':
                    absolute,error,passed=test(inspect(new,name),inspect(references[model,'archived_block'],name))
                    replayed.append(dict(model=model,witness='archived photon state cubic peak',channel=channel,output=name,error=error,passed=passed))
        for mode in MODES:
            for kind in ('physical','opacity-zero'):
                primary=raw[model,kind,mode,'primary']
                for window in WINDOWS:
                    for channel in CHANNELS:
                        value=choose(primary,window,channel)
                        result.append(dict(model=model,medium=kind,gravity=mode,intervals=window,forcing=channel,**nums(value),abs_energy_over_launch=abs(value[0])/launch,abs_current_over_launch=abs(value[1])/launch,joint_over_launch=magnitude(value)/launch))
                        for setting in (['time','angle','forward'] if kind=='physical' else ['time','angle'])+(['gravity-step'] if mode=='p32' else []):
                            alt=raw[model,kind,'p16','primary'] if setting=='gravity-step' else raw[model,kind,mode,setting]
                            alternative=choose(alt,window,channel)
                            for name in OBS:
                                absolute,error,passed=test(inspect(alternative,name),inspect(value,name))
                                numerics.append(dict(model=model,medium=kind,gravity=mode,intervals=window,forcing=channel,output=name,test=setting,relative_error=error,absolute_over_launch=absolute/launch,passed=passed))
                for channel in CHANNELS:
                    for name in OBS:
                        separate=[inspect(choose(primary,window,channel),name) for window in ('block1','block2','reversal')]
                        two=separate[0]+separate[1];three=two+separate[2];last=separate[2]
                        assert magnitude(three-inspect(choose(primary,'three',channel),name))<=1e-12*sum(map(magnitude,separate))
                        effects.append(dict(model=model,medium=kind,gravity=mode,forcing=channel,output=name,first_two_over_launch=magnitude(two)/launch,reversal_over_launch=magnitude(last)/launch,three_over_launch=magnitude(three)/launch,three_over_first_two=magnitude(three)/magnitude(two),third_alignment_to_first_two=align(last,two),three_over_sum_of_three_magnitudes=magnitude(three)/sum(map(magnitude,separate))))
            for window in WINDOWS:
                for channel in CHANNELS:
                    physical=choose(raw[model,'physical',mode,'primary'],window,channel)
                    free=choose(raw[model,'opacity-zero',mode,'primary'],window,channel)
                    for name in OBS:
                        on=inspect(physical,name);off=inspect(free,name);den=magnitude(off)
                        ratio=magnitude(on)/den if den else None
                        scattering.append(dict(model=model,gravity=mode,intervals=window,forcing=channel,output=name,physical_over_opacity_zero=ratio,alignment_to_opacity_zero=align(on,off),absolute_effect_of_scattering_over_launch=magnitude(on-off)/launch))
                        if ratio is not None and ratio>0 and channel=='combined':
                            for setting in ['angle','time']+(['gravity-step'] if mode=='p32' else []):
                                step,alt=('p16','primary') if setting=='gravity-step' else (mode,setting)
                                num=inspect(choose(raw[model,'physical',step,alt],window,channel),name)
                                div=inspect(choose(raw[model,'opacity-zero',step,alt],window,channel),name)
                                delta=abs(magnitude(num)/magnitude(div)/ratio-1) if magnitude(div)>0 else None
                                ratio_checks.append(dict(model=model,gravity=mode,intervals=window,output=name,test=setting,relative_error=delta,passed=delta is not None and delta<=TOL))
            before=references[model,'frozen_through64']
            after=before+choose(raw[model,'physical',mode,'primary'],'three','combined')
            small.append(dict(model=model,gravity=mode,denominator='original joint launch norm',launch_norm=launch,archived_64_norm_over_launch=magnitude(before)/launch,isolated_three_over_archived64=magnitude(after-before)/magnitude(before),after_over_launch_if_archived_64_held_fixed=magnitude(after)/launch,**nums(after)))
    for fn,rows in [('readouts.csv',result),('signed-reversal.csv',effects),('opacity-counterfactual.csv',scattering),('sensitivity.csv',numerics),('historical-closure.csv',replayed),('scattering-ratio-checks.csv',ratio_checks),('frozen-prehistory-context.csv',small)]:
        table(fn,rows)
    print('Historical closure',sum(x['passed'] for x in replayed),len(replayed),'sensitivity',sum(x['passed'] for x in numerics),len(numerics),'ratio checks',sum(x['passed'] for x in ratio_checks),len(ratio_checks))
    print([x for x in effects if (x['model'],x['gravity'],x['medium'],x['forcing'])==(CASES[2],'p32','physical','combined')],flush=True)
if __name__=='__main__':compare()
