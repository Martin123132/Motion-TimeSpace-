from pathlib import Path
import csv
import hashlib
import io
import json
import sys

ROOT=Path(__file__).resolve().parent
SIX=ROOT.parent/'mts-signed-photon-peak-six-20261123'
FINE=ROOT.parent/'mts-gravity-p16-70p4-20261124'
EIGHT=ROOT.parent/'mts-physical-impulses-76p8-20261124'
NINE=ROOT.parent/'mts-physical-impulses-83p2-20261124'
TOP=ROOT.parent/'mts-gravity-p32-83p2-20261124'
PINS={SIX:'9262f9ad88c48fcbc24037f541389aa154be01cf52aad653e6da8c3a90c4819e',FINE:'a30c6a9168e8dfb20e86db29a8f7a40c02e8c15c4bdb31ac9d296bb5f05b2830',EIGHT:'0d4b212a23c89a4442ebcec6c68d42e03902e2ab19c48e7abeb467f5981de2fc',NINE:'e446924053253ca4c6d3b8c3a09f18f613ea5fed6afe2cf09a012a2c24626318',TOP:'828425a5eb89592c637b4120ea62aab5fb39566da54d605d73b2ec42f9cf0486'}
BLOCKS=((64.,70.4,'to70',FINE),(70.4,76.8,'to76',EIGHT),(76.8,83.2,'to83',NINE))
MODES=('p16','p32')
def sha(file):
    with file.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
def pin(folder,name):
    seal=folder/'seal.json';assert sha(seal)==PINS[folder]
    path=folder/name
    assert sha(path)==json.loads(seal.read_bytes())['files'][name],path
    return path
pin(SIX,'project.py');pin(SIX,'peak_inputs.py')
sys.path.insert(0,str(SIX))
import project as proj
import numpy as np
from scipy.interpolate import CubicSpline
from scipy.linalg import solve_banded

def guard():
    proj.guard()
    assert all(not (path/'STOP-REQUESTED').exists() for path in (ROOT.parent,ROOT,*PINS))
def save(name,data):
    guard();path=ROOT/name
    if path.exists():assert path.read_bytes()==data,name
    else:
        with path.open('xb') as stream:stream.write(data)
def record(name,body):
    save(name,(json.dumps(body,sort_keys=True,indent=2,allow_nan=False)+'\n').encode())
def table(name,rows):
    buffer=io.StringIO();writer=csv.DictWriter(buffer,rows[0],lineterminator='\n')
    writer.writeheader();writer.writerows(rows);save(name,buffer.getvalue().encode())
def pack(name,**values):
    buffer=io.BytesIO();np.savez_compressed(buffer,**values);save(name,buffer.getvalue())
def load_source(model,index,mode):
    begin,end,sub,old=BLOCKS[index]
    folder=TOP if mode=='p32' else old
    prefix=sub+'/' if mode=='p32' or old==FINE else ''
    path=pin(folder,prefix+f'particular-{model}-{mode}.npz')
    receipt=json.loads(pin(folder,prefix+f'metric-{model}-{mode}.json').read_bytes())
    assert receipt['passed'] and receipt['output_digest']==sha(path)
    with np.load(path) as data:
        time=data['eta'];values=np.stack([data['phi_dot'],data['psi']],axis=1);wave=float(data['k'][0])
        assert len(time)==1024*int(mode[1:])+1 and np.array_equal(time[[0,-1]],[begin,end])
        assert len(data['q'])==77 and np.isfinite(values).all()
    return time,CubicSpline(time,values,axis=0,extrapolate=False),wave,receipt['output_digest']
