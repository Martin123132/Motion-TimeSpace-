from compare import CASES, CHANNELS, OBS, WINDOWS, choose, inspect, test
from post64_inputs import *
from scipy.special import spherical_jn
from numpy.polynomial.legendre import leggauss

def independently(model):
    params=json.loads((ROOT/f'inputs-{model}.json').read_bytes())
    _,eta,_,peak,_=proj.measure(model)
    assert params['peak_scale']==peak
    tau=params['peak_native_eta']
    stream,drag,recoil,hub=proj.transfer.operators(128)
    assert stream[0,2]==-1 and stream[2,0]==1/3 and stream[2,3]==-2/3 and np.all(stream[:,1]==0)
    for ell in range(2,128):
        index=3+2*(ell-2);prev=2 if ell==2 else index-2
        assert abs(stream[index,prev]-ell/(2*ell+1))<1e-15 and abs(stream[index,index+2]+(ell+1)/(2*ell+1))<1e-15
    output=np.zeros((2,2,3,2,2),complex)
    for modeidx,mode in enumerate(MODES):
        for idx in range(3):
            time,values,wave,_=load_source(model,idx,mode)
            for case,order in enumerate((2,4)):
                knots,weights=leggauss(order);width=np.diff(time)[:,None]/2
                samples=time[:-1,None]+width*(1+knots);quad=width*weights
                phase=wave*(tau-samples);assert phase.min()>0
                fields=values(samples)
                for col in (0,1):
                    output[case,modeidx,idx,0,col]=np.sum(quad*4*fields[...,0]*spherical_jn(col,phase))
                    output[case,modeidx,idx,1,col]=np.sum(quad*4*wave*fields[...,1]*spherical_jn(col,phase,derivative=True))
    return output

def main():
    guard();tested=[];solution={};numerical={}
    for model in CASES[:2]:
        solution[model]=independently(model)
        with np.load(ROOT/f'free-{model}.npz') as data:numerical[model]=data['primary']
    solution[CASES[-1]]=solution['heavy']-solution['cold']
    numerical[CASES[-1]]=numerical['heavy']-numerical['cold']
    for model in CASES:
        for modeidx,mode in enumerate(MODES):
            for window in WINDOWS:
                for channel in CHANNELS:
                    fine=choose(solution[model][1,modeidx],window,channel);numeric=choose(numerical[model][modeidx],window,channel);low=choose(solution[model][0,modeidx],window,channel)
                    for out in OBS:
                        for label,alt in [('Bessel vs opacity-zero solver',numeric),('Bessel quadrature order',low)]:
                            _,err,passed=test(inspect(alt,out),inspect(fine,out))
                            tested.append(dict(model=model,gravity=mode,intervals=window,forcing=channel,output=out,test=label,relative_error=err,passed=passed))
    table('streaming-analytic-check.csv',tested)
    print(sum(r['passed'] for r in tested),len(tested),max(r['relative_error'] for r in tested),flush=True)
if __name__=='__main__':main()
