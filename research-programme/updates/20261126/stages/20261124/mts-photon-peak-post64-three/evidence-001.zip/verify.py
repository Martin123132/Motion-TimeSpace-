import ast
from post64_inputs import *

def rows(file):
    with (ROOT/file).open(newline='') as stream:return list(csv.DictReader(stream))

def verify():
    guard()
    for folder,pinval in PINS.items():assert sha(folder/'seal.json')==pinval
    for src in ROOT.glob('*.py'):ast.parse(src.read_text(encoding='utf8'))
    pins={}
    controls={}
    for model in ('cold','heavy'):
        rec=json.loads((ROOT/f'inputs-{model}.json').read_bytes())
        ids={}
        for index in range(3):
            for mode in MODES:
                t,field,k,source_id=load_source(model,index,mode)
                ids[f'{BLOCKS[index][2]}-{mode}']=source_id
        assert rec['source_sha256']==ids and rec['medium']==sha(proj.medium_file(f'medium-{model}.npz'))
        assert rec['operator_sha256']==sha(Path(proj.transfer.__file__))
        assert (json.loads((ROOT/f'free-inputs-{model}.json').read_bytes()))['source_sha256']==ids
        pins[model]=ids
        for kind in ('primary','time','angle'):
            with np.load(ROOT/f'{model}-{kind}.npz') as early, np.load(ROOT/f'peak-{model}.npz') as whole:
                assert np.array_equal(early['values'],whole[kind]) and early['values'].shape==(2,3,2,2)
                assert all(early['source_interval_steps']>=np.array([16384 if kind=='time' else 32768]*3))
                assert whole['peak']==rec['peak_scale'] and whole['k']==rec['wavenumber']
    for file,count in [('sensitivity.csv',1620),('historical-closure.csv',36),('scattering-ratio-checks.csv',225),('streaming-analytic-check.csv',540)]:
        data=rows(file);assert len(data)==count
        errors=[];passes=0
        for row in data:
            key='error' if file=='historical-closure.csv' else 'relative_error'
            if row[key]!='':
                err=float(row[key]);assert np.isfinite(err) and err>=0;errors.append(err);ok=err<=.005
            else:
                assert 'absolute_over_launch' in row
                ok=float(row['absolute_over_launch'])==0
            assert ok==(row['passed']=='True')
            passes+=int(ok)
        controls[file]=dict(compared=count,passed=passes,worst=max(errors))
    table_rows=rows('readouts.csv')
    assert len(table_rows)==len({tuple(row[key] for key in ('model','medium','gravity','intervals','forcing')) for row in table_rows})==3*2*2*5*3
    def pair(row):return np.array([complex(float(row[key+'_re']),float(row[key+'_im'])) for key in ('energy','current')])
    for row in table_rows:
        if row['model']!='MTS-minus-baseline':continue
        def pick(model,window):
            return next(pair(item) for item in table_rows if (item['model'],item['medium'],item['gravity'],item['intervals'],item['forcing'])==(model,row['medium'],row['gravity'],window,row['forcing']))
        cold=pick('cold',row['intervals']);heavy=pick('heavy',row['intervals'])
        assert np.linalg.norm(pair(row)-(heavy-cold))<=1e-12*(np.linalg.norm(heavy)+np.linalg.norm(cold))
        if row['intervals']=='three':
            blocks=[pick(row['model'],label) for label in ('block1','block2','reversal')]
            assert np.linalg.norm(pair(row)-sum(blocks))<=1e-12*sum(np.linalg.norm(item) for item in blocks)
    effect=rows('signed-reversal.csv');counter=rows('opacity-counterfactual.csv')
    assert len(effect)==108 and len(counter)==270
    for row in effect:
        assert 0<=float(row['three_over_sum_of_three_magnitudes'])<=1+1e-12
        assert abs(float(row['third_alignment_to_first_two']))<=1+1e-12
    outcome=dict(model_source_sha256=pins,controls=controls,physical_blocks=[list(block[:2]) for block in BLOCKS],
        gravity_steps=list(MODES),photon_output=['energy density','longitudinal current'],criterion=.005,new_matter_intervals=0,observed_spectrum=False,
        combined_paired_p32=[row for row in effect if (row['model'],row['medium'],row['gravity'],row['forcing'])==('MTS-minus-baseline','physical','p32','combined')],
        reversal_scattered_over_free=[row for row in counter if (row['model'],row['gravity'],row['intervals'],row['forcing'])==('MTS-minus-baseline','p32','reversal','combined')])
    record('validation.json',outcome)
    if '--seal' in sys.argv:
        assert (ROOT/'RESULTS.md').is_file() and not list(ROOT.rglob('__pycache__'))
        record('seal.json',dict(files={path.relative_to(ROOT).as_posix():sha(path) for path in sorted(ROOT.rglob('*')) if path.is_file() and path.name!='seal.json'},parents={path.name:val for path,val in PINS.items()}))
    print(controls,flush=True)
if __name__=='__main__':verify()
