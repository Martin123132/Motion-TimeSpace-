from scatter import SETTINGS, mesh
from post64_inputs import *

def run(model):
    guard();grid,eta,medium,peak,weights=proj.measure(model)
    def transparent(times):
        result=medium(times).copy()
        assert result.shape[-1]==3
        result[...,2]=0.
        return result
    inputs={};knots=[];ids={}
    for idx,(_,_,label,_) in enumerate(BLOCKS):
        for mode in MODES:
            time,inputs[mode,idx],wave,marker=load_source(model,idx,mode)
            ids[f'{label}-{mode}']=marker
            if mode=='p32':knots.append(time)
    outputs={}
    for tag,(order,sub,stride) in SETTINGS.items():
        axis,owners=mesh(grid,eta,knots,sub,stride)
        band=proj.transfer.stages(order)
        _,at,kernel=proj.backward(axis,eta,weights,transparent,wave,proj.transpose_bands(band),active=owners>=0)
        values=np.empty((2,3,2,2),complex)
        for method,mode in enumerate(MODES):
            for idx in range(3):
                mask=owners==idx;values[method,idx]=np.einsum('nctj,ntc->cj',kernel[mask],inputs[mode,idx](at[mask]))
        assert np.isfinite(values).all()
        outputs[tag]=values;print(model,'opacity-zero',tag,'done',flush=True)
    pack(f'free-{model}.npz',**outputs,k=wave,peak=peak)
    record(f'free-inputs-{model}.json',dict(measure='physical baseline peak, opacity-zero diagnostic only',source_sha256=ids))
if __name__=='__main__':run(sys.argv[1])
