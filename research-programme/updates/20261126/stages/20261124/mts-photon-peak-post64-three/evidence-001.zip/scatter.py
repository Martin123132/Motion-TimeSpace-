from post64_inputs import *

SETTINGS={'primary':(192,4,1),'time':(192,2,2),'angle':(128,4,1)}

def mesh(grid,eta,times,sub,stride):
    base=proj.base_axis(grid,eta,sub)
    axis=np.unique(np.concatenate([base]+[t[::stride] for t in times]))
    assert np.all(np.diff(axis)>0)
    owners=np.full(len(axis)-1,-1)
    for index,(begin,end,_,_) in enumerate(BLOCKS):
        inside=(axis[:-1]>=begin)&(axis[1:]<=end)
        assert np.any(inside) and np.all(owners[inside]==-1) and abs(np.diff(axis)[inside].sum()-(end-begin))<1e-12
        owners[inside]=index
    assert np.all(np.isin(eta,axis))
    return axis,owners

def propagate(axis,eta,grid,peak,medium,wave,bands,sources,owners):
    rates,stage_t=proj.coefficients(axis,medium,wave)
    nstate=bands.shape[-1]//2
    state=np.zeros((nstate,24));right=np.empty((2*nstate,24),order='F')
    saved=np.zeros((len(grid),2,24));slots=np.searchsorted(axis,eta)
    record_at=np.full(len(axis),-1);record_at[slots]=np.arange(len(grid))
    force=np.zeros((len(rates),2,2,2),complex)
    for mode_idx,mode in enumerate(MODES):
        for idx in range(3):
            active=owners==idx
            values=sources[mode,idx](stage_t[active])
            force[active,mode_idx]=np.diff(axis)[active,None,None]*np.einsum('st,ntc->nsc',proj.RAD,values)
    first=int(np.flatnonzero(owners>=0)[0])
    for start in range(first,len(rates),48):
        if (start-first)%1536==0:guard()
        end=min(start+48,len(rates))
        matrices=(rates[start:end].reshape(-1,8)@bands.reshape(8,-1)).reshape(-1,11,2*nstate);matrices[:,5]+=1
        for step,mat in enumerate(matrices,start):
            right[::2]=state;right[1::2]=state
            block=owners[step]
            if block>=0:
                for method in range(2):
                    for row,fac,channel in ((0,4.,0),(2,4*wave/3,1),(4,4*wave/3,1)):
                        column=((method*3+block)*2+channel)*2
                        value=fac*force[step,method,:,channel]
                        right[row:row+2,column]+=value.real;right[row:row+2,column+1]+=value.imag
            state=solve_banded((5,5),mat,right,check_finite=False)[1::2]
            slot=record_at[step+1]
            if slot>=0:saved[slot]=state[[0,2]]
    peak_samples=CubicSpline(grid,saved,axis=0,extrapolate=False)(peak)
    complex_samples=peak_samples[:,::2]+1j*peak_samples[:,1::2]
    return complex_samples.T.reshape(2,3,2,2)

def run(model):
    guard()
    grid,eta,medium,peak,weights=proj.measure(model)
    files={};splines={};times=[];wavenumbers=[]
    receipt=json.loads(pin(SIX,f'projection-inputs-{model}.json').read_bytes())
    assert sha(Path(proj.transfer.__file__))==receipt['operator_sha256']
    for idx,(_,_,label,_) in enumerate(BLOCKS):
        for mode in MODES:
            time,spline,wave,source_id=load_source(model,idx,mode)
            splines[mode,idx]=spline;wavenumbers.append(wave);files[f'{label}-{mode}']=source_id
            if mode=='p32':times.append(time)
            else:lower=time
        assert np.allclose(time[::2],lower,rtol=0,atol=2e-14)
    wave=wavenumbers[0];assert all(item==wave for item in wavenumbers)
    output={}
    with np.load(pin(SIX,f'primary-kernels-{model}.npz')) as kernels:
        t6,field6,k6=proj.source(5,model,'primary')
        assert wave==k6
        sample=CubicSpline(t6,field6,axis=0,extrapolate=False)(kernels['eta_5'])
        replay=np.einsum('nctj,ntc->cj',kernels['gains_5'],sample)
    with np.load(pin(SIX,f'projection-{model}.npz')) as prior:
        assert float(prior['peak'])==peak and float(prior['k'])==wave
        output['archived_channels']=prior['primary'][5]
    output['replay']=replay
    with np.load(proj.readout(5,model,'primary')) as ref:
        assert np.array_equal(grid,ref['scale'])
        output['archived_block']=CubicSpline(grid,ref['block'],axis=0)(peak)
        output['frozen_through64']=CubicSpline(grid,ref['new_partial'],axis=0)(peak)
    with np.load(proj.readout(0,model,'primary')) as ref:output['launch']=ref['old_free'][0]
    for key,(order,sub,stride) in SETTINGS.items():
        guard()
        axis,owners=mesh(grid,eta,times,sub,stride)
        bands=proj.transfer.stages(order)
        _,at,gains=proj.backward(axis,eta,weights,medium,wave,proj.transpose_bands(bands),active=owners>=0)
        values=np.empty((2,3,2,2),complex)
        for method,mode in enumerate(MODES):
            for idx in range(3):
                mask=owners==idx
                sample=splines[mode,idx](at[mask])
                values[method,idx]=np.einsum('nctj,ntc->cj',gains[mask],sample)
        assert np.isfinite(values).all()
        output[key]=values
        pack(f'{model}-{key}.npz',values=values,source_interval_steps=np.bincount(owners[owners>=0]),total_photon_steps=len(owners),wave=wave,peak=peak)
        print(model,key,'adjoint complete',len(owners),flush=True)
        if key=='primary':
            forward=propagate(axis,eta,grid,peak,medium,wave,bands,splines,owners)
            assert np.isfinite(forward).all()
            output['forward']=forward
            print(model,'forward and cubic readout complete',flush=True)
    pack(f'peak-{model}.npz',peak=peak,peak_eta=CubicSpline(grid,eta)(peak),k=wave,**output)
    record(f'inputs-{model}.json',dict(model=model,measure='common baseline visibility-peak scale',peak_scale=float(peak),peak_redshift=float(1/peak-1),peak_native_eta=float(CubicSpline(grid,eta)(peak)),wavenumber=wave,medium=sha(proj.medium_file(f'medium-{model}.npz')),operator_sha256=receipt['operator_sha256'],source_sha256=files))
if __name__=='__main__':run(sys.argv[1])
