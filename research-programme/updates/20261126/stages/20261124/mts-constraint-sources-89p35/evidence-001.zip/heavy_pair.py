from geometry_sources_89 import inputs,io,es,matter,np,CubicSpline,SimpleNamespace

def diag(directory):
    q=[];kn=[]
    for j in range(38):
        with np.load(io.old.pin(f'{directory}/phase-audit-{j:02}.npz')) as audit:
            time=audit['t'];take=time>=io.old.event()
            keys=list(audit['keys'])
            q.append(audit['values'][:,take,keys.index('mts_q_h')]);kn.extend(audit['k'])
    return time[take],np.array(kn),np.vstack(q)

def main():
    tm,k,m=inputs('matched');tw,kw,w=inputs('wave')
    t1,k1,qm=diag('matched-native');t2,k2,qw=diag('material-halfstep')
    assert all(np.array_equal(tm,x) for x in (tw,t1,t2)) and all(np.array_equal(k,x) for x in (kw,k1,k2))
    with np.load(io.old.pin('exact-phase-extension.npz')) as saved:
        rho=saved['matching_density']/m['a'][0]
        vel=CubicSpline(saved['heavy_efold'],saved['phidot_h'])(np.log(w['a'][0]))
    kk=k[:,None];qcalc=kk*vel*w['mts_dphi_h'];enthalpy=vel**2-rho;dq=qcalc-qm
    err=lambda x,y:float(np.max(abs(x-y))/np.max(abs(y)))
    raw=dict(mF=m['F'],wF=w['F'],restore=-(dq+enthalpy*m['sigma'])/(2*kk),remove=(dq+enthalpy*w['sigma'])/(2*kk))
    data=SimpleNamespace(shell=np.array(io.json.loads(es.pin('legs.json').read_bytes())['squared_radii']),nodes=k,first=raw)
    op=es.Fast(es.Project(data).ops[0],data)
    def shift(f,dx):return 1.5*(op.product(f,dx)+op.product(dx,f)+op.product(dx,dx))
    re=shift('mF','restore');rm=shift('wF','remove')
    with np.load(io.ROOT/'native-U.npz') as src:ref=src['wave_flux_square']-src['matched_flux_square']
    source=io.ROOT.parent/'condensate-origin-20261003/native-heavy-matching-20261007/native/fortran/MTSTwoField.f90'
    report=dict(source=str(source),source_hash=io.digest(source),wave_momentum_vs_independent_native_diagnostic=err(qcalc,qw),total_momentum_difference_prediction=err(dq,w['dgq']-m['dgq']),enthalpy_difference_prediction=err(enthalpy,(w['grho']-m['grho'])+(w['gpres']-m['gpres'])),total_F_difference_prediction=err(raw['restore'],w['F']-m['F']),flux_square_difference_prediction=err(re,ref),wave_reverse_square_prediction=err(rm,-ref))
    io.record('heavy-pair-replay.json',report)
    assert report['wave_momentum_vs_independent_native_diagnostic']<.005,report
    io.pack('heavy-pair-U.npz',eta=tm,restore=re,remove=rm)
    print(report)
if __name__=='__main__':main()
