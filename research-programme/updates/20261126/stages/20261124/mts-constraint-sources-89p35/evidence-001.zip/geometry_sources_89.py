from types import SimpleNamespace
import audit_io as io
import matter
import early_source as es
from audit_io import np
from scipy.interpolate import make_interp_spline,CubicSpline

def inputs(side):
    parent=matter.BASE89
    directory='matched-native' if side=='matched' else 'material-halfstep'
    files=sorted((parent/directory).glob('linear-heavy-??.npz'))
    assert len(files)==38
    raw={key:[] for key in ('etak','adotoa','sigma','dgq','grho','gpres','a','mts_dphi_h')}
    grids=[]
    for path in files:
        io.old.pin(directory+'/'+path.name)
        with np.load(path) as packet:
            assert packet['good'].all()
            if not grids:
                epoch=packet['eta'];sel=epoch>=io.old.event();times=epoch[sel]
            else:assert np.array_equal(epoch,packet['eta'])
            names=list(packet['keys']);values=packet['values'][:,sel]
            for key in raw:raw[key].append(values[:,:,names.index(key)])
            grids.extend(packet['k'])
    raw={k:np.vstack(v) for k,v in raw.items()}
    kk=np.array(grids)[:,None];raw['phi']=raw['etak']/kk-raw['adotoa']*raw['sigma']/kk
    raw['F']=-(raw['dgq']+(raw['grho']+raw['gpres'])*raw['sigma'])/(2*kk)
    return times,kk[:,0],raw
def main():
    tm,k,m=inputs('matched');tw,kw,w=inputs('wave');assert np.array_equal(k,kw) and np.array_equal(tw,tm)
    kk=k[:,None];mu=lambda key:(m[key]+w[key])/2;delta=lambda key:m[key]-w[key]
    first=dict(mp=m['phi'],wp=w['phi'],mF=m['F'],wF=w['F'],p0=mu('phi'),F0=mu('F'))
    first.update(phi_etak=delta('etak')/kk,phi_clock=-mu('sigma')*delta('adotoa')/kk,phi_shift=-mu('adotoa')*delta('sigma')/kk,
                 F_dgq=-delta('dgq')/(2*kk),F_density=-mu('sigma')*delta('grho')/(2*kk),F_pressure=-mu('sigma')*delta('gpres')/(2*kk),F_shift=-(mu('grho')+mu('gpres'))*delta('sigma')/(2*kk))
    shell=np.array(io.json.loads(es.pin('legs.json').read_bytes())['squared_radii'])
    data=SimpleNamespace(shell=shell,nodes=k,first=first)
    op=es.Fast(es.Project(data).ops[0],data);kk2=op.k2
    def parts(p,f):
        return dict(potential_square=-kk2*op.product(p,p),laplacian=2*op.lap(p,p),gradient=-.5*op.grad(p,p),flux_square=1.5*op.product(f,f))
    matched=parts('mp','mF');wave=parts('wp','wF')
    upstream={}
    for field in first:
        if field.startswith('phi_'):
            upstream[field]=-kk2*(op.product(field,'p0')+op.product('p0',field))+2*(op.lap(field,'p0')+op.lap('p0',field))-.5*(op.grad(field,'p0')+op.grad('p0',field))
        if field.startswith('F_'):upstream[field]=1.5*(op.product(field,'F0')+op.product('F0',field))
    checks={}
    for config,parts0,folder in [('matched',matched,matter.FLUID),('wave',wave,matter.BASE89)]:
        with np.load(folder/'material-halfstep/forcing-heavy.npz') as raw:
            select=raw['eta']>=io.old.event();assert np.array_equal(tm,raw['eta'][select])
            original=raw['values'][list(raw['keys']).index('U'),select,0]
            checks[config]=float(max(abs(sum(parts0.values())-original))/max(abs(original)))
    target=sum(matched.values())-sum(wave.values())
    checks['polarized_difference']=float(max(abs(sum(upstream.values())-target))/max(abs(target)))
    assert max(checks.values())<1e-9,checks
    io.record('native-U-replay.json',checks)
    io.pack('native-U.npz',eta=tm,**{'matched_'+k:v for k,v in matched.items()},**{'wave_'+k:v for k,v in wave.items()},**upstream)
    print(checks,flush=True)

def interpolate(axis,value):
    with np.load(io.ROOT/'native-U.npz') as src:
        if value in src.files:data=src[value]
        else:data=src['matched_'+value]-src['wave_'+value]
        return make_interp_spline(np.log(src['eta']),data,k=5)(np.log(axis))
def rank(mode):
    from rank_sources_89 import captured,MARK
    a=captured(mode,'matched');b=captured(mode,'wave')
    t=a['eta'];ix=np.argmin(abs(t-MARK));den1=1/a['den'][:,0];den2=1/b['den'][:,0];h1=a['hub'][:,0];h2=b['hub'][:,0]
    r1=lambda x:CubicSpline(t,x)(t,1)+.5*(h1+h2)*x
    with np.load(io.ROOT/'native-U.npz') as src:
        term=[k.removeprefix('matched_') for k in src.files if k.startswith('matched_')]
        up=[k for k in src.files if k.startswith(('phi_','F_'))]
    which=list(a['keys']).index('U');ph1=a['phi'][which,:,0];ph2=b['phi'][which,:,0]
    Ubar=(ph1/den1+ph2/den2)/2
    fix=r1((den1-den2)*Ubar)+(h1-h2)*(ph1+ph2)/2
    expected=(a['residual']-b['residual'])[which,:,0]
    rows=[];budget={}
    for kind,names in [('terms',term),('inputs',up)]:
        values={name:r1((den1+den2)*.5*interpolate(t,name)) for name in names}
        values['constraint_coefficients']=fix
        closure=float(np.max(abs(sum(values.values())-expected))/np.max(abs(expected)));assert closure<1e-6,closure
        for key,v in values.items():
            proj=(v[ix]/expected[ix]).real
            whole=np.trapezoid((v*expected.conj()).real,t)/np.trapezoid(abs(expected)**2,t)
            rows.append(dict(mode=mode,kind=kind,key=key,peak_share=proj,window_share=whole,norm_ratio=abs(v[ix]/expected[ix]),closure=closure))
            budget[kind+'_'+key]=v
    io.table('upstream-'+mode+'.csv',rows);io.pack('subterms-'+mode+'.npz',eta=t,**budget)
    print(mode,[(r['key'],round(r['peak_share'],4)) for r in rows])
if __name__=='__main__':
    import sys
    if sys.argv[1:] and sys.argv[1]=='rank':rank(sys.argv[2])
    else:main()
