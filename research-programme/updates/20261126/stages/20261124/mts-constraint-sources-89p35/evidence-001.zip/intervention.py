import sys
from rank_sources_89 import captured,MARK
from audit_io import np,record,table

def evaluate(mode,replace_label,insert_label):
    matched=captured(mode,'matched');wave=captured(mode,'wave')
    removed=captured(mode,replace_label);inserted=captured(mode,insert_label)
    time=matched['eta'];index=int(np.argmin(abs(time-MARK)))
    delta=matched['total']-wave['total'];rows=[];main=[]
    for seed in (0,1):
        original=delta[:,seed];norm=np.trapezoid(abs(original)**2,time)
        for label,packet,origin,direction in ((replace_label,removed,matched,-1),(insert_label,inserted,wave,1)):
            assert np.array_equal(packet['eta'],time)
            change=direction*(packet['total'][:,seed]-origin['total'][:,seed])
            share=np.trapezoid(np.real(change*original.conj()),time)/norm
            rem=np.sqrt(np.trapezoid(abs(original-change)**2,time)/norm)
            gate=np.max(abs(packet['total'][:,seed]))/np.max(abs(packet['rate'][:,seed]))
            rows.append(dict(mode=mode,seed=seed,test=label,peak_share=(change[index]/original[index]).real,point_remaining=abs((original[index]-change[index])/original[index]),window_aligned_share=share,remaining_rms_ratio=rem,absolute_constraint_error=gate,passed=bool(gate<=.005)))
    table(f'test-{replace_label}-{mode}.csv',rows)
    print(rows[0],rows[1],flush=True)
if __name__=='__main__':evaluate(*sys.argv[1:])
