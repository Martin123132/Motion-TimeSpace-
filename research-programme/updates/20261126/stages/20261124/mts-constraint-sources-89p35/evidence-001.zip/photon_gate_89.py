from unittest.mock import patch
import csv
import audit_io as io
import photon_match as transfer
from photon_match import np,proj,previous,FROZEN,pin,CubicSpline,mag
class Interface:
    def __getattr__(self,name):return getattr(io.old,name)
    def guard(self):io.guard()
    def table(self,name,rows):io.table(name,rows)
def main():
    grid,eta,medium,peak,weights=proj.measure('heavy');hist={}
    with np.load(io.old.pin('photon-accumulated-heavy.npz')) as heavy,np.load(io.old.pin('photon-accumulated-cold.npz')) as cold:
        assert np.array_equal(grid,heavy['scale']) and np.array_equal(grid,cold['scale'])
        wave=float(heavy['k']);original={m:heavy['through89p6_'+m]-cold['through89p6_'+m] for m in io.old.MODES}
    norm={r['gravity']:float(r['launch_norm']) for r in csv.DictReader(pin(FROZEN,'window-readouts.csv').open()) if r['output']=='joint' and r['model']=='MTS-minus-baseline'}
    for mode in io.old.MODES:
        for case,part in [('primary','pairInMatched'),('U_swap','waveUinMatched'),('original','matched')]:
            with np.load(io.ROOT/f'{part}-curves-{mode}-companion.npz') as data:hist[mode,case]={k:data[k] for k in ('eta','delta_pd','delta_psi','delta_differentiated','kick')}
    _,axis,weights,_=proj.old.get_media();measure=previous.make_measure(axis,weights);rows=[];vectors={};controls=[]
    with patch.object(transfer,'ps',Interface()):
        for setting in ('primary','time','angle'):
            ans=transfer.transfer(setting,eta,grid,medium,wave,hist)
            io.pack('photons-'+setting+'.npz',scale=grid,inputs=list(hist),channels=['kick','constraint_rate','lapse','differentiated'],values=ans)
            for col,(mode,case) in enumerate(hist):
                vals=CubicSpline(grid,ans[:,col])(axis);old=CubicSpline(grid,original[mode])(axis)
                mom=vals[:,:3].sum(1);direct=vals[:,[0,3,2]].sum(1)
                for rate,vec in [('momentum',mom),('differentiated',direct)]:
                    magnitude=100*mag(vec,measure)/norm[mode];vectors[mode,case,setting,rate]=vec
                    rows.append(dict(mode=mode,case=case,transport=setting,rate=rate,energy_pct=magnitude[0],current_pct=magnitude[1],joint_pct=magnitude[2],total_joint_pct=100*mag(old+vec,measure)[2]/norm[mode],below=bool(magnitude[2]<.163)))
    for (mode,case,setting,rate),value in vectors.items():
        if setting!='primary' or rate!='momentum':continue
        other=[('time',vectors[mode,case,'time',rate]),('angle',vectors[mode,case,'angle',rate]),('rate',vectors[mode,case,setting,'differentiated'])]
        if mode=='p32':other.append(('gravity',vectors['p16',case,setting,rate]))
        for key,ref in other:
            rel=mag(ref-value,measure)/mag(value,measure);controls.append(dict(mode=mode,case=case,check=key,relative=rel[-1],passed=bool(max(rel)<=.005)))
    old=list(csv.DictReader(io.checked('independent-readouts.csv').open()))
    for row in rows:
        if row['case']=='original' and row['transport']=='primary':
            want=next(float(r['correction_pct']) for r in old if r['mode']==row['mode'] and r['case']=='companion' and r['method']==row['rate'])
            assert abs(row['joint_pct']/want-1)<1e-9
    io.table('photon-checks.csv',controls);io.table('photon-readouts.csv',rows)
if __name__=='__main__':main()
