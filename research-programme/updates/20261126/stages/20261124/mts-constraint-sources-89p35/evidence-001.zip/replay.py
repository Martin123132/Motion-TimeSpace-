from unittest.mock import patch
import sys
import audit_io as io
import matter
from ledger import decompose
from audit_io import np
from scipy.interpolate import CubicSpline

class Receipts:
    def __init__(self,label):self.label=label
    def __getattr__(self,key):return getattr(io.old,key)
    def guard(self):io.guard()
    def pack(self,name,**values):io.pack(self.label+'-'+name,**values)
    def record(self,name,data):io.record(self.label+'-'+name,data)

def run(mode,label,side,swap=()):
    assert mode in io.old.MODES and side in ('matched','wave')
    folder=matter.FLUID if side=='matched' else matter.BASE89
    other=matter.BASE89 if side=='matched' else matter.FLUID
    oldget=matter.get_flow;captured={}
    def build(folder0,case,clock,initial,projection=None):
        flow=oldget(folder0,case,clock,initial,projection)
        if projection is None:return flow
        if swap:
            alternative=oldget(other,case,clock,initial,projection)
            qkeys=[name for name in swap if not name.startswith('@')]
            bgkeys=[name[4:] for name in swap if name.startswith('@bg:')]
            components=[name[3:] for name in swap if name.startswith('@u:')]
            analytic=any(x in swap for x in ('@heavy-pressure','@heavy-pair'))
            assert len(qkeys)+len(bgkeys)+len(components)+int('@drive' in swap)+int(analytic)==len(swap)
            if qkeys:
                mainq,altq=flow.q,alternative.q
                cols=[flow.qkeys.index(name) for name in qkeys];altcols=[alternative.qkeys.index(name) for name in qkeys]
                def mixed(u):
                    result=mainq(u).copy();result[...,cols,:]=altq(u)[...,altcols,:];return result
                flow.q=mixed
            if bgkeys:
                mainbg,altbg=flow.bg,alternative.bg
                bgcols=[flow.bgkeys.index(key) for key in bgkeys];othercols=[alternative.bgkeys.index(key) for key in bgkeys]
                def changed_bg(u):
                    result=mainbg(u).copy();result[...,bgcols]=altbg(u)[...,othercols];return result
                flow.bg=changed_bg
            if '@drive' in swap:flow.drive=alternative.drive
            if components or analytic:
                assert 'U' not in qkeys
                from scipy.interpolate import make_interp_spline
                packet='heavy-pair-U.npz' if '@heavy-pair' in swap else 'heavy-pressure-U.npz' if analytic else 'native-U.npz'
                with np.load(io.ROOT/packet) as src:
                    slopes=src['restore' if side=='matched' else 'remove'] if analytic else sum(src[name] if name in src.files else src['matched_'+name]-src['wave_'+name] for name in components)
                    sub=make_interp_spline(np.log(src['eta']),slopes,k=5)
                original_q=flow.q;index=flow.qkeys.index('U');sgn=-1. if side=='matched' and not analytic else 1.
                def component_swap(u):
                    result=original_q(u).copy()
                    result[...,index,0]+=sgn*sub(u)
                    return result
                flow.q=component_swap
        original=flow.evolve
        def retain(times,stress):
            result=original(times,stress)
            captured.update(flow=flow,trajectory=result,clock=times,stress=stress)
            return result
        flow.evolve=retain
        return flow
    with patch.object(matter,'ps',Receipts(label)),patch.object(matter,'FLUID',folder),patch.object(matter,'get_flow',build):
        matter.evolve(mode,'companion')
    decompose(label,mode,captured['flow'],captured['trajectory'],captured['clock'],captured['stress'])
    prior={'matched':'','wave':'stencil-'}.get(label)
    if prior is not None and (label=='matched' or mode=='p32'):
        with np.load(io.checked(f'{prior}curves-{mode}-companion.npz')) as old,np.load(io.ROOT/f'{label}-curves-{mode}-companion.npz') as new:
            for field in ('eta','phi','psi','pd','derivative','e','j','stress'):assert np.array_equal(old[field],new[field]),field
    print(label,mode,'constraint reconstruction passed',flush=True)
if __name__=='__main__':run(*sys.argv[1:4],sys.argv[4:])
