from audit_io import np,pack,record
from scipy.interpolate import CubicSpline

def decompose(label,mode,flow,trajectory,source_clock,source_stress):
    times,obs,_,states=trajectory;log=np.log(times);count=len(times)
    state=dict(zip(flow.keys,states[:,:,0,:].transpose(1,0,2)))
    bg={key:value[:,None] for key,value in zip(flow.bgkeys,flow.bg(log).T)}
    force={key:value[:,None] for key,value in zip(flow.qkeys,flow.q(log)[:,:,0].T)}
    hub=bg['h'];wave=float(flow.k[0,0]);kk=wave**2;rho=flow.rho0/bg['a']
    nu=bg['nuE']+4*bg['er'];nj=bg['nuJ']+4*bg['er'];ns=bg['nuS']+4*bg['er']
    den=kk+(3*(bg['ec']+bg['eb']+bg['sv']**2+rho)+4*(bg['eg']+bg['er'])+bg['nuE'])/2
    ratio=bg['eb']/bg['eg']
    baryon=(state['W']-state['B'])/(ratio+4/3)
    photon=state['B']+4*baryon/3
    full=CubicSpline(np.log(source_clock),source_stress,axis=0)(log)[:,:,0,:]*bg['enu'][:,None,:];full[:,1]*=wave
    shear=np.array([flow.coeffs(t)[4] for t in times])[:,None]
    shape=(count,2);groups={};terms={}
    def piece(key,group,energy=0.,current=0.,anisotropy=0.,U=0.,Q=0.,Fq=0.):
        ph=np.broadcast_to((U-.5*energy-1.5*hub*current/kk)/den,shape)
        sl=np.broadcast_to((anisotropy-Q)/kk,shape)
        pd=np.broadcast_to(current/(2*kk)-hub*(ph+sl)+Fq,shape)
        terms[key]=(ph,sl,pd);groups[key]=group
    piece('U','metric',U=force['U']);piece('Q','metric',Q=force['Q']);piece('Fq','metric',Fq=force['Fq'])
    piece('photon_state','photon',bg['eg']*state['gx'],bg['eg']*photon,-bg['eg']*state['I2'])
    piece('gE','photon',energy=force['gE']);piece('gJ','photon',current=force['gJ'])
    piece('ph_shift','photon',anisotropy=-bg['eg']*force['ph_shift'])
    piece('collisionless_state','collisionless',nu*state['N0'],wave*nj*state['N1'],-ns*state['N2'])
    piece('nuJ','collisionless',current=force['nuJ'])
    piece('77_bin_residual','collisionless',full[:,0],full[:,1],full[:,2])
    for tag,velocity,group in (('c',state['ct'],'cold'),('b',baryon,'baryon')):
        piece(group+'_state',group,bg['e'+tag]*state[tag+'d'],bg['e'+tag]*velocity)
        for suffix in ('trace','KE','Jq','shear'):
            key=tag+suffix;piece(key,group,**{dict(trace='energy',KE='energy',Jq='current',shear='anisotropy')[suffix]:force[key]})
    vel=bg['sv'];pot=(bg['a']*bg['sm'])**2*bg['sb']
    piece('slow_state','slow',vel*state['sw']+pot*state['sf'],kk*vel*state['sf'])
    for suffix,channel in [('energy','energy'),('J','current'),('shear','anisotropy')]:piece('s'+suffix,'slow',**{channel:force['s'+suffix]})
    piece('heavy_companion','heavy',rho*state['hf'],rho*state['hw'],rho*shear)
    phi,slip,pds=np.array(list(terms.values())).transpose(1,0,2,3)
    pd0=-obs[:,3,0,:]/times[:,None]-hub*obs[:,1,0,:]+force['Fq']
    deriv=CubicSpline(times,obs[:,0,0,:])(times,1)
    residual=CubicSpline(times,phi,axis=1)(times,1)+(-pds)
    def error(actual,expected):return float(np.max(abs(actual-expected))/np.max(abs(expected)))
    checks=dict(phi=error(phi.sum(0),obs[:,0,0,:]),psi=error((phi+slip).sum(0),obs[:,1,0,:]),pd=error(pds.sum(0),pd0),constraint_residual=error(residual.sum(0),deriv-pd0))
    roundoff=64*np.finfo(float).eps*np.max(np.sum(abs(phi),axis=0))/(np.min(np.diff(times))*np.max(abs(deriv-pd0)))
    assert max(checks[k] for k in ('pd','phi','psi'))<1e-12
    assert checks['constraint_residual']<min(1e-6,max(2e-8,roundoff)),(checks,roundoff)
    pack(f'ledger-{mode}-{label}.npz',eta=times,keys=list(terms),groups=list(groups.values()),residual=residual,phi=phi,pd=pds,slip=slip,den=den,hub=hub,total=deriv-pd0,rate=pd0)
    record(f'closure-{mode}-{label}.json',checks)
