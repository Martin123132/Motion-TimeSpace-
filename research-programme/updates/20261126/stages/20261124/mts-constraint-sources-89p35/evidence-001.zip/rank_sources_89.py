import sys
import audit_io as io
from audit_io import np

MARK=89.3525390625
def captured(mode,label):
    with np.load(io.ROOT/f'ledger-{mode}-{label}.npz') as packet:return dict(packet.items())
def ranking(mode):
    base=captured(mode,'matched');reference=captured(mode,'wave')
    times=base['eta'];assert np.array_equal(times,reference['eta']) and np.array_equal(base['keys'],reference['keys'])
    difference=base['total']-reference['total']
    parts=base['residual']-reference['residual'];ix=int(np.argmin(abs(times-MARK)))
    rows=[];window=[];order={}
    for grouped in (False,True):
        labels=base['groups' if grouped else 'keys'];names=list(dict.fromkeys(labels))
        vals=np.array([parts[labels==key].sum(0) for key in names])
        for branch in (0,1):
            for idx,where in ((ix,'saved_peak'),(np.argmax(abs(difference[:,branch])),'peak_excess')):
                net=difference[idx,branch];values=vals[:,idx,branch]
                weights=(values/net).real
                assert abs(weights.sum()-1)<1e-7
                for ind,name in enumerate(names):
                    rows.append(dict(mode=mode,seed=branch,where=where,eta=times[idx],level='species' if grouped else 'term',name=name,delta_re=values[ind].real,delta_im=values[ind].imag,net_re=net.real,net_im=net.imag,projected_share=weights[ind],norm_ratio=abs(values[ind]/net)))
                if where=='saved_peak' and not grouped:order[str(branch)]=[(str(names[i]),float(weights[i])) for i in np.argsort(-abs(values))[:5]]
            den=np.trapezoid(abs(difference[:,branch])**2,times)
            for ind,key in enumerate(names):
                share=np.trapezoid(np.real(vals[ind,:,branch]*difference[:,branch].conjugate()),times)/den
                window.append(dict(mode=mode,seed=branch,level='species' if grouped else 'term',name=key,window_projected_share=share,rms_ratio=np.sqrt(np.trapezoid(abs(vals[ind,:,branch])**2,times)/den)))
    io.table('rank-'+mode+'.csv',rows);io.table('window-'+mode+'.csv',window)
    print(mode,order,flush=True)
if __name__=='__main__':ranking(sys.argv[1])
