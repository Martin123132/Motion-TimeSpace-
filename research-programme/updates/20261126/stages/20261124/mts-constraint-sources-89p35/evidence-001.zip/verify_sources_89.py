import csv
import audit_io as out
from audit_io import json,np
from rank_sources_89 import captured,MARK

def rows(name):
    with (out.ROOT/name).open(newline='') as fp:return list(csv.DictReader(fp))
def report(mode,label,seed):
    entry=captured(mode,label);d=entry['total'][:,seed];rate=entry['rate'][:,seed];ix=np.argmax(abs(d))
    return dict(mode=mode,label=label,seed=seed,at=entry['eta'][ix],fraction=np.max(abs(d))/np.max(abs(rate)),passed=bool(np.max(abs(d))<=.005*np.max(abs(rate))))
def main():
    out.guard()
    tests=[];results=[];threshold=.005
    flags=[]
    for mode in out.old.MODES:
        pairs=[('waveUinMatched','matchedUinWave'),('analyticInMatched','analyticInWave'),('pairInMatched','pairInWave')]
        if mode=='p32':pairs+=[('waveFluxInMatched','matchedFluxInWave'),('wavePressureInMatched','matchedPressureInWave')]
        labels=['matched','wave',*[v for pair in pairs for v in pair]]
        for name in labels:
            receipt=json.loads((out.ROOT/f'{name}-junction-{mode}-companion.json').read_bytes())
            recon=json.loads((out.ROOT/f'closure-{mode}-{name}.json').read_bytes())
            tests.append(dict(mode=mode,label=name,checks='replay_and_recoupling',passed=bool(receipt['normal_energy_jump']<1e-12 and receipt['normal_momentum_jump']<1e-12 and max(receipt['recoupling'][-1][key] for key in ('stress','metric','quadrature'))<=threshold and recon['constraint_residual']<1e-6)))
            for seed in (0,1):
                r=report(mode,name,seed);results.append(r)
                if seed==0:assert abs(r['fraction']-receipt['metric_derivative'])<1e-14
        for a,b in pairs:
            entries=rows(f'test-{a}-{mode}.csv')
            for row in entries:
                expected=next(r for r in results if r['label']==row['test'] and r['mode']==mode and r['seed']==int(row['seed']))
                assert abs(float(row['absolute_constraint_error'])-expected['fraction'])<1e-14
        for entry in rows('upstream-'+mode+'.csv'):
            assert float(entry['closure'])<1e-6
        for seed in (0,1):
            r=[row for row in rows('rank-'+mode+'.csv') if row['seed']==str(seed) and row['level']=='term' and row['where']=='saved_peak']
            assert max(r,key=lambda row:float(row['norm_ratio']))['name']=='U'
            assert abs(sum(float(row['projected_share']) for row in r)-1)<1e-6
        for label in ['pairInMatched','pairInWave']:
            packet=captured(mode,label)
            assert np.all(np.isfinite(packet['total']))
    raw=json.loads((out.ROOT/'native-U-replay.json').read_bytes());model=json.loads((out.ROOT/'heavy-pair-replay.json').read_bytes())
    assert max(raw.values())<1e-9
    assert all(model[key]<threshold for key in ('wave_momentum_vs_independent_native_diagnostic','flux_square_difference_prediction','total_momentum_difference_prediction','enthalpy_difference_prediction'))
    assert out.digest(out.Path(model['source']))==model['source_hash']
    measures=rows('photon-readouts.csv');controls=rows('photon-checks.csv')
    assert len(measures)==36
    adj=max(float(r['relative']) for r in rows('photon-adjoint.csv'));assert adj<1e-10
    for row in measures:assert (row['below']=='True')==(float(row['joint_pct'])<.163)
    for mode in out.old.MODES:
        target=next(row for row in measures if row['mode']==mode and row['case']=='original' and row['transport']=='primary' and row['rate']=='momentum')
        with out.checked('independent-readouts.csv').open() as handle:
            previous=next(row for row in csv.DictReader(handle) if row['mode']==mode and row['case']=='companion' and row['method']=='momentum')
        assert abs(float(target['joint_pct'])/float(previous['correction_pct'])-1)<1e-9
    assert all(x['passed'] for x in tests)
    out.table('absolute-constraints.csv',results);out.table('numerical-replay.csv',tests)
    orig=[r for r in results if r['label']=='matched' and r['seed']==0];candidate=[r for r in results if r['label']=='pairInMatched']
    out.record('verdict.json',dict(parent_sha256=out.digest(out.PRE/'seal.json'),primary_tolerance=threshold,photon_target_pct=.163,original_gate_passed=all(x['passed'] for x in orig),candidate_gate_passed_for_both_seeds_and_steps=all(r['passed'] for r in candidate),candidate_max_photon_pct=max(float(r['joint_pct']) for r in measures if r['case']=='primary'),adjoint_error=adj,photon_vector_controls_failed=[r for r in controls if r['passed']!='True'],counterfactual_passes_are_not_promotions=True,requires_microscopic_history=True,authoritative_endpoint_promoted=False))
if __name__=='__main__':main()
