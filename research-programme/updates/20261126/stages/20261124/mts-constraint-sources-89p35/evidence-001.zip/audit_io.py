from pathlib import Path
import csv,hashlib,io,json,sys
import numpy as np

ROOT=Path(__file__).resolve().parent
PRE=ROOT.parent/'mts-wave-transfer-89p15-20261124'
def digest(path):
    with path.open('rb') as fp:return hashlib.file_digest(fp,'sha256').hexdigest()
assert digest(PRE/'seal.json')=='31f9925322c86a7d9876cd31469a79dbb0f8bc1ae17acf2410c4486f9fdec962'
manifest=json.loads((PRE/'seal.json').read_bytes())['files']
def checked(name):
    path=PRE/name
    assert digest(path)==manifest[name],name
    return path
for name in ('local_stage.py','matter.py','reference_null.py','companion-p16.npz','companion-p32.npz'):checked(name)
sys.path.insert(0,str(PRE))
import local_stage as old
def guard():
    old.guard();assert not (ROOT/'STOP-REQUESTED').exists()
def write(name,body):
    guard();path=ROOT/name
    if path.exists():assert path.read_bytes()==body,name
    else:
        with path.open('xb') as out:out.write(body)
def pack(name,**values):
    buf=io.BytesIO();np.savez_compressed(buf,**values);write(name,buf.getvalue())
def table(name,rows):
    buf=io.StringIO();writer=csv.DictWriter(buf,rows[0],lineterminator='\n');writer.writeheader();writer.writerows(rows);write(name,buf.getvalue().encode())
def record(name,values):write(name,(json.dumps(values,indent=2,sort_keys=True,allow_nan=False)+'\n').encode())
