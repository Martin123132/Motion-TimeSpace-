import ast
import csv
import json
import os
import sys

import numpy as np
import stage_paths as paths

def rows(name):
    with (paths.HERE/name).open(newline='') as stream:return list(csv.DictReader(stream))
def validation():
    paths.local_guard()
    limits=json.loads((paths.HERE/'decision.json').read_bytes())
    assert limits['tolerance']==.005
    assert limits['steps_mpc']==[.0015625,.00078125,.000390625]
    for folder,pin in paths.PINS.items():assert paths.digest(folder/'seal.json')==pin
    prior=paths.pin(paths.SAVED,'advance70.py').read_text()
    new=(paths.HERE/'p16_advance.py').read_text()
    for start,end in [('    with np.load(source_restart)',"    prefix='material-halfstep/'"),("    with np.load(folder/f'forcing-", '    report=dict(')]:
        physics=prior[prior.index(start):prior.index(end)]
        assert physics.strip() in new
    for source in paths.HERE.glob('*.py'):ast.parse(source.read_text(encoding='utf8'))
    metas=[];q=2.**(np.arange(-52,25)/4.)
    for model in ('cold','heavy'):
        expected_start=paths.pin(paths.START,f'particular-{model}-p4.npz')
        for stage,folder,timing in [('to64',paths.SIX,[57.6,64.]),('to70',paths.SAVED,[64.,70.4])]:
            directory=paths.HERE/stage
            restart=directory/f'particular-{model}-p16.npz'
            receipt=json.loads((directory/f'metric-{model}-p16.json').read_bytes())
            assert receipt['passed'] and receipt['step_mpc']==.000390625
            assert paths.digest(expected_start)==receipt['parent'] and paths.digest(restart)==receipt['output_digest']
            assert paths.PINS[folder]==receipt['source_seal']
            manifest=json.loads((folder/'seal.json').read_bytes())['files']
            bank={f'micro-{model}-{ix}.npz' for ix in range(-52,25)}
            assert bank==set(receipt['micro'])
            for key in bank:assert receipt['micro'][key]==manifest[key]
            assert max(receipt['seam_stress'],receipt['seam_metric'],receipt['time_metric'],receipt['slope_error'],receipt['incident_seam'])<=.005
            assert max(receipt['iterations'][-1][key] for key in ('stress','metric_increment'))<=.005
            assert receipt['quadrature']<1e-12 and receipt['incident_control']<1e-10
            with np.load(restart) as saved:
                assert np.array_equal(q,saved['q']) and np.array_equal(timing,saved['eta'][[0,-1]])
                assert saved['eta'].size==16385 and max(abs(np.diff(saved['eta'])-.000390625))<5e-14
                assert saved['lagEnd'].shape[0]==77 and len(saved['stressClock'])==129
                for key in ('state','lagEnd','shape','obs','stress','phi_dot','phi','psi'):assert np.isfinite(saved[key]).all()
            metas.append(dict(model=model,stage=stage,parent=receipt['parent'],output=receipt['output_digest'],bank_count=len(bank),material_source=folder.name))
            expected_start=restart
    prior_decision=json.loads(paths.pin(paths.SAVED,'verified.json').read_bytes())
    for field in ('C','Y'):
        assert abs(prior_decision['paired_peak_budget'][field]['remaining_center_displacement_over_radius']-limits['center_shifts_in_radius'][field][0])<1e-9
    physics_checks={}
    for filename,count in [('trajectory-checks.csv',48),('impulse-checks.csv',66),('step-comparisons.csv',72)]:
        frame=rows(filename)
        assert len(frame)==count,(filename,len(frame))
        for row in frame:
            err=float(row['relative_error'])
            assert np.isfinite(err) and err>=0 and (row['passed']=='True')==(err<=.005)
        physics_checks[filename]=dict(total=len(frame),passes=sum(row['passed']=='True' for row in frame),worst=max(float(row['relative_error']) for row in frame))
    rates=rows('rate-defects.csv');assert len(rates)==27
    assert len({(row['mode'],row['block'],row['model']) for row in rates})==27
    for row in rates:
        errors=[float(row[key]) for key in ('independent_integral_difference_over_radius','quadrature_change_over_radius','endpoint_closure_over_radius','saved_replay_over_radius') if row[key]!='']
        assert all(np.isfinite(err) and err>=0 for err in errors) and (row['passed']=='True')==(max(errors)<=.005)
    terms=rows('lapse-sensitivity.csv')
    for index,(low,high) in enumerate([('p4','p8'),('p8','p16')]):
        block=[row for row in terms if (row['coarser'],row['finer'])==(low,high)]
        assert len(block)==8
        full=limits['center_shifts_in_radius']['Y'][index]
        distance=sum(float(row['signed_projection_over_radius']) for row in block if row['term']!='final')
        assert abs(full-distance)<1e-8
    paths.record('validation.json',dict(checks=physics_checks,checked_restarts=metas,rate_checks_passed=sum(row['passed']=='True' for row in rates),rate_checks_count=len(rates),seals={folder.name:pin for folder,pin in paths.PINS.items()},both_blocks_same_solver_core=True))
    if '--seal' in sys.argv:
        assert (paths.HERE/'RESULTS.md').is_file() and not list(paths.HERE.rglob('__pycache__'))
        paths.record('seal.json',dict(files={file.relative_to(paths.HERE).as_posix():paths.digest(file) for file in sorted(paths.HERE.rglob('*')) if file.is_file() and file.name!='seal.json'},parents={folder.name:pin for folder,pin in paths.PINS.items()}))
    print(physics_checks,flush=True)

if __name__=='__main__':validation()
