import csv
import io
import json
import sys
from functools import lru_cache
from unittest.mock import patch

import stage_paths as paths
paths.pin(paths.SAVED,'impulse70.py')
sys.path.insert(0,str(paths.SAVED))
import impulse70 as bridge
from impulse70 import Medium, np, CubicSpline, make_interp_spline, history, parts, z, simpson

LIMIT=.005
MODELS=bridge.MODELS
CASES=bridge.CASES

def read(folder,name):
    with paths.pin(folder,name).open(newline='') as stream:return list(csv.DictReader(stream))
def table(name,rows):
    buffer=io.StringIO()
    writer=csv.DictWriter(buffer,rows[0],lineterminator='\n')
    writer.writeheader();writer.writerows(rows)
    paths.save(name,buffer.getvalue().encode())

class RefinedPacket(history.Saved):
    def __init__(self,model,prior):
        self.model=model
        folder=paths.SIX if prior else paths.SAVED
        directory=paths.HERE/('to64' if prior else 'to70')
        save=directory/f'particular-{model}-p16.npz'
        receipt=json.loads((directory/f'metric-{model}-p16.json').read_bytes())
        assert receipt['passed'] and paths.digest(save)==receipt['output_digest']
        paths.pin(folder,f'material-halfstep/forcing-{model}.npz')
        self.path=save
        with np.load(save) as raw:
            self.time=raw['eta'];wave=float(raw['k'][0]);obs=raw['obs'][:,:,0,0]
            assert np.array_equal(self.time[[0,-1]],([57.6,64.] if prior else [64.,70.4])) and len(raw['q'])==77
            fields={'Y':raw['psi'],'phi':raw['phi'],'pd':raw['phi_dot'],'L':obs[:,11],'F':obs[:,3]/self.time}
            assert np.allclose(fields['L'],fields['Y']-fields['phi'],atol=1e-25,rtol=1e-9)
        with np.load(folder/'material-halfstep'/f'forcing-{model}.npz') as src:
            bg=dict(zip(src['bgkeys'],src['background']));q=dict(zip(src['keys'],src['values']));log=np.log(src['eta'])
            for key,val in [('Fq',q['Fq'][:,0]),('Hm',bg['h'])]:
                fields[key]=make_interp_spline(log,val,k=5)(np.log(self.time))
        assert np.max(abs(fields['pd']+fields['F']+fields['Hm']*fields['Y']-fields['Fq']))<1e-9*np.max(abs(fields['pd']))
        self.curves={key:CubicSpline(self.time,val,extrapolate=False) for key,val in fields.items()}

original=bridge.Packet
@lru_cache(maxsize=12)
def packet(model,mode,prior):
    if mode=='p16':return RefinedPacket(model,prior)
    assert mode in ('p4','p8')
    folder=paths.SIX if prior and mode=='p8' else paths.SAVED
    prefix='control64/' if prior and mode=='p4' else ''
    for kind,ext in [('particular','npz'),('metric','json')]:
        paths.pin(folder,f'{prefix}{kind}-{model}-{mode}.{ext}')
    return original(model,'primary' if mode=='p8' else 'control',prior)

def groups(mode):
    return [{model:packet(model,mode,prior) for model in MODELS} for prior in (True,False)]

def defect_intervals(med,mode,nodes):
    old,new=groups(mode)
    begin,cut=med.both({name:entry.time for name,entry in old.items()})
    switch,end=med.both({name:entry.time for name,entry in new.items()})
    assert abs(cut-med.a0)<1e-17 and abs(switch-med.cuts['cold'])<1e-17
    totals={}
    for block,lo,hi,fields,count in [('first',begin,cut,old,nodes),('second',cut,switch,dict(cold=old['cold'],heavy=new['heavy']),33),('second',switch,end,new,nodes)]:
        paths.local_guard()
        scale=np.linspace(lo,hi,count)
        clock=med.native('heavy',scale)
        fields_at={}
        for model,entry in fields.items():
            t,ratio,_,_=med.coord(scale,model)
            t=bridge.limit_time(t,entry.time)
            fields_at[model]=np.array([entry.curves['phi'](t),ratio*entry.curves['phi'](t,1),ratio*entry.curves['pd'](t)])
        fields_at['paired']=fields_at['heavy']-fields_at['cold']
        for name,(phi,slope,rate) in fields_at.items():
            model='heavy' if name=='paired' else name
            time,ratio,hub,_=med.coord(scale,model)
            gain=np.exp(med.primitive[model](time)-med.primitive[model](med.native(model,med.am)))
            direct=simpson(gain*(slope-rate),x=clock)
            boundary=gain[-1]*phi[-1]-gain[0]*phi[0]
            independent=boundary-simpson(gain*(ratio*hub*phi+rate),x=clock)
            key=block,name
            totals[key]=totals.get(key,np.zeros(2,complex))+np.array([direct,independent])
    for name in CASES:totals['both',name]=totals['first',name]+totals['second',name]
    return totals

def peak_norm(arr):
    return float(np.max(abs(arr)))
def trajectory(med):
    tests=[]
    for prior in (True,False):
        block='first' if prior else 'second'
        data={}
        for mode in ('p8','p16'):
            cases={model:packet(model,mode,prior) for model in MODELS}
            lo,hi=med.both({name:entry.time for name,entry in cases.items()})
            scale=np.linspace(lo,hi,16385)
            rows=history.branches(med,cases,scale)
            metrics={}
            for name,entry in cases.items():
                time=bridge.limit_time(med.native(name,scale),entry.time)
                phi=entry.curves['phi']
                metrics[name]=[phi(time),entry.curves['pd'](time),phi(time,1)]
            metrics['paired']=np.array(metrics['heavy'])-np.array(metrics['cold'])
            for name,row in rows.items():
                phi,rate,derivative=metrics[name]
                data[mode,name]=[phi,row['Y'],rate,row['C'],row['refCp'],row['refYp']]
                error=peak_norm(derivative-rate)/peak_norm(rate)
                tests.append(dict(block=block,model=name,test=mode+' derivative vs constraint',relative_error=error,passed=error<=LIMIT))
        for name in CASES:
            for field,low,high in zip(('phi','lapse','phi_dot','C','C slope','Y slope'),data['p8',name],data['p16',name]):
                error=peak_norm(high-low)/peak_norm(high)
                tests.append(dict(block=block,model=name,test='p8 to p16: '+field,relative_error=error,passed=error<=LIMIT))
    return tests

def main():
    paths.local_guard();bridge.guard()
    med=Medium()
    physical=read(paths.SAVED,'physical-impulses.csv')
    saved_defect=read(paths.SAVED,'peak-rate-defect.csv')
    caps=read(paths.BOUND,'required-signed-impulses.csv')
    radii={key:float(row['radius']) for key,row in zip(('C','Y'),caps)}
    results={};audit=[];defects=[];components={}
    for mode,index in [('p4','control'),('p8','primary'),('p16','new')]:
        if mode=='p16':
            with patch.object(bridge,'Packet',packet):
                low,*_=bridge.intervals(med,mode,16385)
                fine,ident,seams=bridge.intervals(med,mode,32769)
            for r in ident:
                audit.append(dict(model=r['model'],target=r['target'],test=r['test'],relative_error=r['relative_error'],passed=r['relative_error']<=LIMIT))
            for orig,new in zip(low,fine):
                for field in ('I_C','I_Y_current','I_Y_shear','I_Y','remaining_center_C','remaining_center_Y'):
                    err=bridge.relative(z(orig,field),z(new,field))
                    audit.append(dict(model=new['model'],target=new['target'],test='quadrature: '+field,relative_error=err,passed=err<=LIMIT))
            table('p16-impulses.csv',fine);table('p16-seams.csv',seams)
        else:
            fine=[row for row in physical if row['mode']==index]
        for item in fine:results[mode,item['model'],item['target']]=item
        low=defect_intervals(med,mode,16385)
        high=defect_intervals(med,mode,32769)
        for (block,name),(direct,independent) in high.items():
            resolution_difference=abs(direct-low[block,name][0])/radii['Y']
            independent_difference=abs(direct-independent)/radii['Y']
            measured=None;old_difference=None
            if block=='second':
                item=results[mode,name,'priority midpoint']
                measured=-z(item,'remaining_center_Y')-sum(z(item,key) for key in ('carried_Y','I_Y','seam_Y'))
                if mode!='p16':
                    earlier=next(row for row in saved_defect if (row['mode'],row['model'])==(index,name))
                    old_difference=abs(direct-z(earlier,'integrated_phi_rate_defect'))/radii['Y']
            discrepancy=abs(direct-measured)/radii['Y'] if measured is not None else None
            errors=[value for value in (resolution_difference,independent_difference,discrepancy,old_difference) if value is not None]
            defects.append(dict(mode=mode,block=block,model=name,**parts('integrated_rate_defect',direct),defect_over_radius=abs(direct)/radii['Y'],independent_integral_difference_over_radius=independent_difference,quadrature_change_over_radius=resolution_difference,endpoint_closure_over_radius=discrepancy,saved_replay_over_radius=old_difference,passed=max(errors)<=LIMIT))
            if block=='second' and name=='paired':
                components[mode]=dict(inherited=z(item,'carried_Y'),current=z(item,'I_Y_current'),shear=z(item,'I_Y_shear'),clock=z(item,'I_Y_clock'),seam=z(item,'seam_Y'),rate_defect=direct,remainder=measured-direct,final=-z(item,'remaining_center_Y'))
    trace=trajectory(med);table('trajectory-checks.csv',trace);table('impulse-checks.csv',audit);table('rate-defects.csv',defects)
    steps=[]; attribution=[]
    for lo,hi in [('p4','p8'),('p8','p16')]:
        for name in CASES:
            for target in ('block end','priority midpoint'):
                lower=results[lo,name,target];upper=results[hi,name,target]
                for field in ('I_C','I_Y_current','I_Y_shear','I_Y','remaining_center_C','remaining_center_Y'):
                    diff=z(lower,field)-z(upper,field)
                    error=abs(diff)/abs(z(upper,field))
                    units=abs(diff)/radii[field[-1]] if field.startswith('remaining_center') and target=='priority midpoint' else None
                    steps.append(dict(coarser=lo,finer=hi,model=name,target=target,quantity=field,**parts('coarser_minus_finer',diff),relative_error=error,passed=error<=LIMIT,change_over_peak_one_term_radius=units))
        changes={key:components[lo][key]-value for key,value in components[hi].items()}
        assert abs(changes['final']-sum(value for key,value in changes.items() if key!='final'))<1e-8*radii['Y']
        for key,value in changes.items():
            attribution.append(dict(coarser=lo,finer=hi,term=key,absolute_over_radius=abs(value)/radii['Y'],signed_projection_over_radius=(value*changes['final'].conjugate()).real/abs(changes['final'])/radii['Y']))
    table('step-comparisons.csv',steps);table('lapse-sensitivity.csv',attribution)
    def center(lo,hi,field):
        return next(row['change_over_peak_one_term_radius'] for row in steps if (row['coarser'],row['finer'],row['target'],row['model'],row['quantity'])==(lo,hi,'priority midpoint','paired','remaining_center_'+field))
    def values(block,name):
        return [float(next(row['defect_over_radius'] for row in defects if (row['mode'],row['block'],row['model'])==(mode,block,name))) for mode in ('p4','p8','p16')]
    readout=results['p16','paired','priority midpoint']
    decision=dict(tolerance=LIMIT,steps_mpc=[.0015625,.00078125,.000390625],physical_end=70.4,peak_target=med.mid,intervals=[[57.6,64.0],[64.0,70.4]],radii=radii,
        center_shifts_in_radius={key:[center('p4','p8',key),center('p8','p16',key)] for key in ('C','Y')},
        second_block_rate_defect_in_radius={name:values('second',name) for name in CASES},two_block_paired_rate_defect_in_radius=values('both','paired'),
        paired_rate_defect_shrinks=values('second','paired')[2]<values('second','paired')[1],paired_lapse_shift_below_one_radius=center('p8','p16','Y')<1,
        relative_checks={label:[sum(bool(row['passed']) for row in rows),len(rows)] for label,rows in [('trajectory',trace),('impulse',audit),('time_step',steps)]},absolute_defect_checks=[sum(bool(row['passed']) for row in defects),len(defects)],
        remaining_over_launch={key:float(readout['remaining_'+key+'_over_initial']) for key in ('C','Y')},no_late_matter_assumption=True)
    paths.record('decision.json',decision)
    print(json.dumps(decision,indent=2),flush=True)

if __name__=='__main__':main()
