import sys
from unittest.mock import patch
import numpy as np
from scipy.interpolate import CubicSpline,make_interp_spline
from entry89_io import ROOT,SWITCH,CYCLE,END,io,checked,check_freeze,digest

def verified():
    check_freeze()
    assert digest(ROOT/'frozen.json')=='7e83f873766cd5a010da599386fc573218fb1fd8880f60f9fc1d28d7a75ce04d'

def sources():
    verified()
    with np.load(checked('native-U.npz')) as src:
        target=src['wave_flux_square']-src['matched_flux_square']
    with np.load(checked('heavy-pair-U.npz')) as pair:
        t=pair['eta']; oracle=pair['restore']
    rows=[]
    for model in ('primary','width','zero'):
        with np.load(ROOT/(('primary' if model=='zero' else model)+'.npz')) as saved:
            assert np.array_equal(t,saved['eta'])
            prediction=saved['restore']*(model!='zero')
        for name,ref in [('native',target),('pair',oracle)]:
            for label,stop in [('cycle',CYCLE),('window',END)]:
                sel=(t>=SWITCH)&(t<=stop)
                for deriv in (0,1):
                    def get(values):
                        if not deriv:return values[sel]
                        return make_interp_spline(np.log(t),values,k=5)(np.log(t[sel]),nu=1)/t[sel]
                    truth=get(ref);estimate=get(prediction)
                    err=float(np.max(abs(estimate-truth))/np.max(abs(truth)))
                    rows.append(dict(model=model,window=label,target=name,derivative=deriv,n=int(sum(sel)),
                                     peak_relative=err,passed=err<=.005))
    io.table('source-scores.csv',rows)
    print([r for r in rows if r['model']=='primary' and r['target']=='native'])
def replay_forecast(mode):
    verified(); checked('replay.py'); checked('ledger.py')
    import replay
    with np.load(ROOT/'primary.npz') as data:
        add=make_interp_spline(np.log(data['eta']),data['restore'],k=5)
    original=replay.matter.get_flow
    def forecast(folder,case,clock,initial,projection=None):
        flow=original(folder,case,clock,initial,projection)
        if projection is not None:
            earlier=flow.q; index=flow.qkeys.index('U')
            def shifted(at):
                values=earlier(at).copy()
                values[...,index,0]+=add(at)
                return values
            flow.q=shifted
        return flow
    with patch.object(replay.matter,'get_flow',forecast):
        replay.run(mode,'entry','matched')
    with np.load(ROOT/f'ledger-{mode}-entry.npz') as ledger:
        rows=[]
        for label,stop in [('cycle',CYCLE),('window',END)]:
            use=(ledger['eta']>=SWITCH-1e-10)&(ledger['eta']<=stop+1e-10)
            for seed in (0,1):
                error=float(max(abs(ledger['total'][use,seed]))/max(abs(ledger['rate'][use,seed])))
                rows.append(dict(mode=mode,window=label,seed=seed,fraction=error,passed=error<=.005))
    io.table(f'metric-{mode}.csv',rows)
    print(rows,flush=True)
if __name__=='__main__':
    sources() if sys.argv[1]=='sources' else replay_forecast(sys.argv[1])
