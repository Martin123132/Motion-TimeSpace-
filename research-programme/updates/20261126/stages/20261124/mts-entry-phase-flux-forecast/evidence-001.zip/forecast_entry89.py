import json
from types import SimpleNamespace
import numpy as np
from scipy.integrate import solve_ivp
from scipy.interpolate import CubicSpline
from entry89_io import ROOT, SWITCH, CYCLE, END, checked, digest, io

checked('geometry_sources_89.py')
from geometry_sources_89 import es

def load_left():
    names = ('a','adotoa','mts_dphi_h','mts_dphidot_h','grho','gpres','dgrho','dgq','etak')
    blocks = {name: [] for name in names}
    nodes = []
    for index in range(38):
        io.guard()
        with np.load(io.old.pin(f'material-halfstep/linear-heavy-{index:02}.npz')) as packet:
            times = packet['eta']
            if index == 0:
                coord = times
                left = (times < SWITCH) & (times > SWITCH - .7)
            assert np.array_equal(coord,times)
            values = packet['values'][:,left]
            assert np.isfinite(values).all()
            for name in names:
                blocks[name].append(values[:,:,packet['keys'].tolist().index(name)])
            nodes.extend(packet['k'])
    pre = {name:np.vstack(pieces) for name,pieces in blocks.items()}
    with np.load(io.old.pin('exact-phase-extension.npz')) as bg:
        logr = bg['heavy_efold']
        boundary = float(np.log(bg['matching_scale']))
        past = (logr < boundary) & (logr > np.log(pre['a'][0,0]) - .002)
        get = lambda key: CubicSpline(logr[past],bg[key][past])
        pre.update(mass=float(bg['heavy_mass_mpc']),dust=float(bg['matching_density']),
                   angle=get('phase_h')(np.log(pre['a'][0])),center=float(get('phase_h')(boundary)),
                   b=get('phi_h')(np.log(pre['a'][0])),vel=get('phidot_h')(np.log(pre['a'][0])),
                   last_bg_loga=float(logr[past][-1]),boundary_loga=boundary)
    assert len(nodes)==782 and np.max(coord[left]) < SWITCH and pre['last_bg_loga'] < boundary
    return coord[left],coord[coord>=SWITCH],np.asarray(nodes),pre

def model(width,time,output,k,pre):
    mass,dust=pre['mass'],pre['dust']
    scale,hub=pre['a'][0],pre['adotoa'][0]
    field,vel=pre['b'],pre['vel']
    delta,dprime=pre['mts_dphi_h'],pre['mts_dphidot_h']
    weight=(scale*mass)**2
    dh=vel*dprime+weight*field*delta
    qh=k[:,None]*vel*delta
    rest_q=pre['dgq']-qh
    rest_e=pre['dgrho']-dh
    rest_w=pre['grho'][0]+pre['gpres'][0]-vel**2
    rest_acc=pre['grho'][0]+3*pre['gpres'][0]-(2*vel**2-weight*field**2)
    angle=pre['angle']
    sel=abs(angle-pre['center'])<=width*np.pi
    span=SWITCH-time[sel][0]
    coord=(time[sel]-SWITCH)/span
    matrix=np.column_stack([coord**power for power in range(5)] +
                           [coord**power*func(mult*angle[sel]) for mult in (2,4)
                            for func in (np.sin,np.cos) for power in range(3)])
    inverse=np.linalg.pinv(matrix)
    def slow(samples):
        return inverse[:5]@np.atleast_2d(samples)[:,sel].T
    def evaluate(coeffs,at):
        return np.polynomial.polynomial.polyval((at-SWITCH)/span,coeffs)
    qcoef,ecoef=slow(rest_q),slow(rest_e)
    wcoef,acoef=slow(rest_w),slow(rest_acc)
    dens0,cur0=slow(dh*scale/dust)[0],slow(qh*scale/dust)[0]
    count=len(k)
    def integrate(rhs,start,stop,initial):
        scalevec=np.maximum(abs(initial),max(abs(initial))*1e-13)
        result=solve_ivp(rhs,(start,stop),initial,method='DOP853',atol=scalevec*2e-13,
                         rtol=2e-11,max_step=.00625,dense_output=True)
        assert result.success
        return result.sol
    def wrhs(at,state):
        a,h,b,v=state[:4]
        df,dv,etak=state[4:].reshape(3,count)
        w2=(mass*a)**2
        k_z=(.5*(evaluate(ecoef,at)+v*dv+w2*b*df)+k*etak)/h
        current=evaluate(qcoef,at)+k*v*df
        return np.r_[a*h,-(evaluate(acoef,at)[0]+2*v*v-w2*b*b)/6,
                     v,-2*h*v-w2*b,dv,-2*h*dv-(k*k+w2)*df-k_z*v,.5*current]
    initial=np.r_[scale[-1],hub[-1],field[-1],vel[-1],delta[:,-1],dprime[:,-1],pre['etak'][:,-1]]
    wave=integrate(wrhs,time[-1],output[-1],initial)
    atswitch=wave(SWITCH)
    def frhs(at,state):
        a,h=state[:2]
        density,current,etak=state[2:].reshape(3,count)
        ratio=(k/(a*mass))**2
        pressure=ratio/(np.sqrt(1+ratio)+1)**2*(density+3*h*current/k)
        kz=(.5*(evaluate(ecoef,at)+dust/a*density)+k*etak)/h
        return np.r_[a*h,-(evaluate(acoef,at)[0]+dust/a)/6,
                     -3*h*pressure-k*current-kz,-h*current+k*pressure,
                     .5*(evaluate(qcoef,at)+dust/a*current)]
    fstart=np.r_[atswitch[:2],dens0,cur0,atswitch[-count:]]
    fluid=integrate(frhs,SWITCH,output[-1],fstart)(output)
    waves=wave(output)
    a,h=fluid[:2]
    df,uf,etaf=fluid[2:].reshape(3,count,-1)
    rho=dust/a
    qf=rho*uf
    qrest=evaluate(qcoef,output)
    zf=(.5*(evaluate(ecoef,output)+rho*df)/k[:,None]+etaf)/h
    sigma=zf+1.5*(qrest+qf)/k[:,None]**2
    wf=waves[4:].reshape(3,count,-1)[0]
    vel=waves[3]
    qw=k[:,None]*vel*wf
    host=-(qrest+qf+(evaluate(wcoef,output)+rho)*sigma)/(2*k[:,None])
    change=-(qw-qf+(vel**2-rho)*sigma)/(2*k[:,None])
    shell=np.array(json.loads(es.pin('legs.json').read_bytes())['squared_radii'])
    data=SimpleNamespace(shell=shell,nodes=k,first={'host':host,'change':change})
    op=es.Fast(es.Project(data).ops[0],data)
    restore=1.5*(op.product('host','change')+op.product('change','host')+op.product('change','change'))
    assert np.isfinite(restore).all()
    return dict(restore=restore,host=host,change=change,qw=qw,qf=qf,sigma=sigma,enthalpy=vel**2-rho,
                density0=dens0,current0=cur0),dict(width=width,pre_samples=int(sum(sel)),
                    fit_condition=float(np.linalg.cond(matrix)),scale_at_entry=float(atswitch[0]))

def main():
    assert not (ROOT/'frozen.json').exists()
    pretime,output,k,pre=load_left()
    configs={}
    for width,label in ((6,'primary'),(4,'width')):
        result,configs[label]=model(width,pretime,output,k,pre)
        io.pack(label+'.npz',eta=output,k=k,**result)
    io.record('frozen.json',dict(switch=SWITCH,cycle=CYCLE,end=END,last_wave_input=float(pretime[-1]),
                last_background_loga=pre['last_bg_loga'],entry_loga=pre['boundary_loga'],settings=configs,
                inputs_seal=io.old.archived.SEAL,files={name:digest(ROOT/name) for name in
                ('PROTOCOL.md','entry89_io.py','forecast_entry89.py','primary.npz','width.npz')}))
    print('FROZEN',digest(ROOT/'frozen.json'),configs)
if __name__=='__main__':main()
