import csv
import json
import sys
import re
import numpy as np
from score_entry89 import verified
from entry89_io import ROOT,PRIOR,io,digest,checked

def read(name):
    with (ROOT/name).open() as handle:return list(csv.DictReader(handle))
def verify():
    verified()
    blind=json.loads((ROOT/'blind-replay.json').read_bytes())
    assert len(blind['predicted_fields_identical'])==9 and blind['wave_packets']==38
    scores=read('source-scores.csv')
    assert len(scores)==24
    assert all((row['model']=='zero')==(row['passed']=='False') for row in scores)
    for mode in io.old.MODES:
        rows=read(f'metric-{mode}.csv')
        assert len(rows)==4 and all(float(row['fraction'])<=.005 for row in rows)
        closure=json.loads((ROOT/f'closure-{mode}-entry.json').read_bytes())
        assert max(closure.values())<1e-6
    checks=read('photon-controls.csv');scores=read('photon-scores.csv')
    assert len(scores)==24 and all(float(row['joint_pct'])<.163 for row in scores)
    assert all((row['check']=='rate')==(row['passed']=='False') for row in checks) and len(checks)==9
    adjoint=read('photon-adjoint.csv')
    assert len(adjoint)==12 and max(float(row['relative']) for row in adjoint)<.005
    for link in re.findall(r'\]\(([^)]+)\)',(ROOT/'RESULTS.md').read_text()):
        assert (ROOT/link).is_file(),link
    for path in ROOT.glob('*.py'):
        compile(path.read_bytes(),str(path),'exec')
    seal=ROOT/'seal.json'
    files={p.name:digest(p) for p in sorted(ROOT.iterdir()) if p.is_file() and p!=seal}
    if seal.exists():
        assert files==json.loads(seal.read_bytes())['files']
    else:
        io.record('seal.json',dict(files=files,prior_seal=digest(PRIOR/'seal.json'),forecast_freeze=digest(ROOT/'frozen.json')))
    print(len(files),'files verified; seal',digest(seal))
if __name__=='__main__':verify()
