from contextlib import contextmanager
from unittest.mock import patch
from pathlib import Path
from types import SimpleNamespace
import json
import numpy as np
from entry89_io import ROOT,SWITCH,io
from score_entry89 import verified
import forecast_entry89 as forecast

def main():
    verified()
    original=np.load
    cleared={'phase_packets':0,'wave_packets':0}
    @contextmanager
    def redacted(name,*args,**kwargs):
        path=Path(name)
        with original(path,*args,**kwargs) as packet:
            if path.name=='exact-phase-extension.npz':
                grid=packet['heavy_efold'];boundary=np.log(packet['matching_scale'])
                keep=grid<boundary
                fields={key:packet[key] for key in ('heavy_mass_mpc','matching_scale','matching_density','heavy_efold')}
                for key in ('phi_h','phidot_h','phase_h'):
                    fields[key]=np.where(keep,packet[key],np.nan)
                cleared['phase_packets']+=1
            elif path.parent.name=='material-halfstep' and path.name.startswith('linear-heavy-'):
                fields={key:packet[key] for key in ('eta','keys','k','values')}
                fields['values'][:,fields['eta']>=SWITCH]=np.nan
                cleared['wave_packets']+=1
            else:
                raise ValueError('Unexpected numerical forecast input: '+str(path))
            yield fields
    with patch.object(np,'load',redacted):
        past,output,k,data=forecast.load_left()
    shells=np.array(json.loads(forecast.es.pin('legs.json').read_bytes())['squared_radii'])
    geometry=forecast.es.Project(SimpleNamespace(shell=shells,nodes=k,first={}))
    def fixed_geometry(request):
        assert np.array_equal(request.nodes,k) and np.array_equal(request.shell,shells)
        return geometry
    with patch.object(np,'load',redacted),patch.object(forecast.es,'Project',fixed_geometry):
        result,config=forecast.model(6,past,output,k,data)
    assert cleared==dict(phase_packets=1,wave_packets=38)
    with original(ROOT/'primary.npz') as frozen:
        assert np.array_equal(output,frozen['eta']) and np.array_equal(k,frozen['k'])
        assert all(np.array_equal(value,frozen[key]) for key,value in result.items())
    io.record('blind-replay.json',dict(**cleared,predicted_fields_identical=sorted(result),
            withheld='All native wave values at and after entry; future phase/field knots; all saved fluid initial-state tables omitted. Geometry and declared fixed scalars retained.'))
    print('Forward prediction identical with post-switch fields masked.')
if __name__=='__main__':main()
