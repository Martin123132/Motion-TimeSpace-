import csv
from unittest.mock import patch
import numpy as np
from scipy.interpolate import CubicSpline
from score_entry89 import verified
from entry89_io import ROOT,io,checked

def main():
    verified();checked('photon_gate_89.py')
    import photon_gate_89 as gate
    grid,eta,medium,_,_=gate.proj.measure('heavy')
    _,axis,weights,_=gate.proj.old.get_media()
    measure=gate.previous.make_measure(axis,weights)
    norms={r['gravity']:float(r['launch_norm']) for r in csv.DictReader(gate.pin(gate.FROZEN,'window-readouts.csv').open()) if r['output']=='joint' and r['model']=='MTS-minus-baseline'}
    hist={}
    with np.load(io.old.pin('photon-accumulated-heavy.npz')) as heavy,np.load(io.old.pin('photon-accumulated-cold.npz')) as cold:
        assert np.array_equal(grid,heavy['scale']) and np.array_equal(grid,cold['scale'])
        wave=float(heavy['k'])
        original={mode:CubicSpline(grid,heavy['through89p6_'+mode]-cold['through89p6_'+mode])(axis) for mode in io.old.MODES}
    for mode in io.old.MODES:
        for case,path in [('primary',ROOT/f'entry-curves-{mode}-companion.npz'),('oracle',checked(f'pairInMatched-curves-{mode}-companion.npz'))]:
            with np.load(path) as data:
                hist[mode,case]={name:data[name] for name in ('eta','delta_pd','delta_psi','delta_differentiated','kick')}
    scores=[];checks=[];vectors={}
    archive=list(csv.DictReader(checked('photon-readouts.csv').open()))
    with patch.object(gate.transfer,'ps',gate.Interface()):
        for setting in ('primary','time','angle'):
            values=gate.transfer.transfer(setting,eta,grid,medium,wave,hist)
            io.pack('photon-'+setting+'.npz',scale=grid,inputs=list(hist),values=values)
            for column,(mode,case) in enumerate(hist):
                vals=CubicSpline(grid,values[:,column])(axis)
                for rate,vec in [('momentum',vals[:,:3].sum(1)),('differentiated',vals[:,[0,3,2]].sum(1))]:
                    vectors[mode,case,setting,rate]=vec
                    energy,current,joint=100*gate.mag(vec,measure)/norms[mode]
                    total=100*gate.mag(original[mode]+vec,measure)[2]/norms[mode]
                    if case=='oracle':
                        ref=next(float(r['joint_pct']) for r in archive if (r['case'],r['mode'],r['transport'],r['rate'])==('primary',mode,setting,rate))
                        assert abs(joint/ref-1)<1e-9
                    scores.append(dict(mode=mode,case=case,transport=setting,rate=rate,energy_pct=energy,current_pct=current,
                                       joint_pct=joint,total_joint_pct=total,passed=bool(joint<.163)))
    for mode in io.old.MODES:
        reference=vectors[mode,'primary','primary','momentum']
        variants={key:vectors[mode,'primary',key,'momentum'] for key in ('time','angle')}
        variants.update(rate=vectors[mode,'primary','primary','differentiated'],oracle=vectors[mode,'oracle','primary','momentum'])
        if mode=='p32':variants['gravity']=vectors['p16','primary','primary','momentum']
        for key,value in variants.items():
            rel=gate.mag(value-reference,measure)/gate.mag(reference,measure)
            checks.append(dict(mode=mode,check=key,energy=rel[0],current=rel[1],joint=rel[2],passed=bool(max(rel)<=.005)))
    io.table('photon-scores.csv',scores);io.table('photon-controls.csv',checks)
    print([r for r in scores if r['case']=='primary' and r['transport']=='primary'])
    print(checks)
if __name__=='__main__':main()
