from pathlib import Path
import hashlib
import json
import sys

ROOT = Path(__file__).resolve().parent
PRIOR = ROOT.parent / 'mts-constraint-sources-89p35-20261124'
SWITCH = 89.14850380306666
CYCLE = 89.24159032
END = 89.6

def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

assert digest(PRIOR / 'seal.json') == '635ccb231b31e72c78e4224cd38494517c61fa08785db5a2d5d466c3894c1c0f'
prior_files = json.loads((PRIOR / 'seal.json').read_bytes())['files']

def checked(name):
    path = PRIOR / name
    assert digest(path) == prior_files[name], name
    return path

sys.path.insert(0, str(PRIOR))
checked('audit_io.py')
import audit_io as io
io.ROOT = ROOT

def check_freeze():
    freeze = json.loads((ROOT / 'frozen.json').read_bytes())
    assert all(digest(ROOT / name) == value for name, value in freeze['files'].items())
    return freeze
