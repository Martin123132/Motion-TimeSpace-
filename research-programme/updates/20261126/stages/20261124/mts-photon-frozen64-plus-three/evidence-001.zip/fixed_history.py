import csv
import hashlib
import io
import json
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
WINDOW = HERE.parent / 'mts-photon-visibility-window-post64-three-20261124'
WINDOW_SHA = '2ce600bc4e9a8172d3b65c81e2c9a34d7022ffd723c9e54620e13d1d09f1a4d0'

def sha(path):
    with path.open('rb') as handle:
        return hashlib.file_digest(handle,'sha256').hexdigest()

def window_file(name):
    assert sha(WINDOW/'seal.json') == WINDOW_SHA
    path = WINDOW/name
    assert sha(path) == json.loads((WINDOW/'seal.json').read_bytes())['files'][name], name
    return path

window_file('window83.py')
window_file('compare_window.py')
sys.path.insert(0,str(WINDOW))
import compare_window as archive
from window83 import np, proj, pinned, guard as prior_guard
from scipy.integrate import simpson
from scipy.interpolate import CubicSpline

MODELS = archive.MODELS
MODES = archive.MODES
OUTPUTS = archive.OUTPUTS
LIMIT = archive.LIMIT

def guard():
    prior_guard()
    assert not (HERE/'STOP-REQUESTED').exists()

def save(name,body):
    guard()
    path=HERE/name
    if path.exists():
        assert path.read_bytes()==body,name
    else:
        with path.open('xb') as handle:
            handle.write(body)

def record(name,payload):
    save(name,(json.dumps(payload,sort_keys=True,indent=2,allow_nan=False)+'\n').encode())

def table(name,rows):
    stream=io.StringIO()
    writer=csv.DictWriter(stream,rows[0].keys(),lineterminator='\n')
    writer.writeheader()
    writer.writerows(rows)
    save(name,stream.getvalue().encode())

def indexed(path,columns):
    with path.open(newline='') as source:
        rows=list(csv.DictReader(source))
    result={tuple(row[key] for key in columns):row for row in rows}
    assert len(result)==len(rows)
    return result

def components(pair):
    return np.append(pair,pair.sum())

def size(values,measure):
    return np.sqrt(components(measure @ (abs(values)**2)))

def inner(left,right,measure):
    return components(measure @ (left.conj()*right).real)

def rowcheck(rows,model,mode,name,quantity,errors):
    for label,error in zip(OUTPUTS,errors,strict=True):
        rows.append(dict(model=model,gravity=mode,test=name,quantity=quantity,output=label,relative_error=float(error),passed=bool(np.isfinite(error) and error<=LIMIT)))

def fields(history):
    frozen,first_two,third=history.transpose(1,0,2)
    return {'through64':frozen, 'through76.8':frozen+first_two, 'through83.2':frozen+first_two+third}

def main():
    guard()
    media,axis,weights,peak=proj.old.get_media()
    assert LIMIT==.005 and len(axis)==8193 and np.allclose([1/axis[-1]-1,1/axis[0]-1],[750,1500])
    measure=archive.make_measure(axis,weights)
    dense=np.linspace(axis[0],axis[-1],16385)
    with np.load(proj.medium_file('medium-cold.npz')) as raw:
        denseweight=CubicSpline(raw['scale'],raw['visibility'])(dense)*media['cold']['clock'](dense,1)
    denseweight/=simpson(denseweight,x=dense)
    dense_measure=archive.make_measure(dense,denseweight)
    assert np.array_equal(axis,dense[::2]) and np.allclose(denseweight[::2],weights,rtol=1e-11,atol=0)
    results64=proj.old.pin(proj.old.PARENT,'results-p8.csv')
    frozen_ref=indexed(results64,['model','source'])
    peak_ref=indexed(pinned('frozen-prehistory-context.csv'),['model','gravity'])
    iso_ref=indexed(window_file('peak-vs-window.csv'),['model','gravity','output'])
    inputs={str(results64):sha(results64)}
    history={}
    launch={}
    for model in MODELS[:2]:
        for path in [proj.medium_file(f'medium-{model}.npz'),proj.medium_file('score.json')]:
            inputs[str(path)]=sha(path)
        prior=proj.readout(5,model,'primary')
        inputs[str(prior)]=sha(prior)
        with np.load(prior) as source:
            grid=source['scale']
            fixed=source['new_partial']
            assert np.array_equal(grid,media[model]['scale']) and np.array_equal(fixed,source['prior_sum']+source['block'])
            assert fixed.shape==(len(grid),2)
            launch[model]=source['old_free'][0]
            wave=float(source['k'].item())
        prior_peak=pinned(f'peak-{model}.npz')
        inputs[str(prior_peak)]=sha(prior_peak)
        with np.load(prior_peak) as archived:
            assert wave==float(archived['k']) and np.array_equal(launch[model],archived['launch'])
            assert np.allclose(CubicSpline(grid,fixed,axis=0)(peak),archived['frozen_through64'],rtol=1e-13,atol=0)
        for setting in archive.SETTINGS:
            path=window_file(f'window-{model}-{setting}.npz')
            inputs[str(path)]=sha(path)
            with np.load(path) as source:
                assert np.array_equal(source['grid'],grid) and float(source['peak'])==peak and float(source['wave'])==wave
                blocks=source['values'].sum(axis=3)
            assert blocks.shape==(len(grid),2,3,2)
            pack={'scale':grid,'through64':fixed,'k':wave,'gravity_modes':np.array(MODES)}
            for idx,mode in enumerate(MODES):
                init=blocks[:,idx,:2].sum(axis=1)
                last=blocks[:,idx,2]
                native=np.stack((fixed,init,last),axis=1)
                assert np.isfinite(native).all()
                history[model,setting,mode]=native
                if setting=='primary':
                    pack['through76p8_'+mode]=fixed+init
                    pack['through83p2_'+mode]=fixed+init+last
            if setting=='primary':
                stream=io.BytesIO()
                np.savez_compressed(stream,**pack)
                save(f'fixed-plus-blocks-{model}.npz',stream.getvalue())
    launch[MODELS[-1]]=launch['heavy']-launch['cold']
    for setting in archive.SETTINGS:
        for mode in MODES:
            history[MODELS[-1],setting,mode]=history['heavy',setting,mode]-history['cold',setting,mode]
    checks,readouts,interference,support=[],[],[],[]
    for model in MODELS:
        scale=float(np.linalg.norm(launch[model]))
        for mode in MODES:
            guard()
            spline=CubicSpline(grid,history[model,'primary',mode],axis=0,extrapolate=False)
            full=spline(axis)
            states=fields(full)
            if model==MODELS[-1]:
                for key in states:
                    direct=fields(history['heavy','primary',mode])[key]-fields(history['cold','primary',mode])[key]
                    assert np.allclose(CubicSpline(grid,direct,axis=0)(axis),states[key],rtol=1e-11,atol=1e-26*scale)
            rms={key:size(value,measure) for key,value in states.items()}
            isolated_two=size(full[:,1],measure)
            isolated_three=size(full[:,1]+full[:,2],measure)
            isolated_ratio=isolated_three/isolated_two
            third=size(full[:,2],measure)
            earlier=rms['through76.8']
            after=rms['through83.2']
            fixed=rms['through64']
            alignment=inner(states['through76.8'],full[:,2],measure)/(earlier*third)
            cross64=2*inner(states['through64'],full[:,2],measure)
            crosstwo=2*inner(full[:,1],full[:,2],measure)
            thirdpower=third**2
            delta_power=after**2-earlier**2
            assert np.allclose(delta_power,thirdpower+crosstwo+cross64,rtol=1e-11,atol=0)
            signed=(after-earlier)/earlier
            delta=abs(states['through83.2'])**2-abs(states['through76.8'])**2
            for oi,label in enumerate(OUTPUTS):
                iso=iso_ref[model,mode,label]
                assert np.isclose(isolated_ratio[oi],float(iso['window_ratio']),rtol=2e-12,atol=0)
                readouts.append(dict(model=model,gravity=mode,output=label,launch_norm=scale,through64_pct=100*fixed[oi]/scale,through76p8_pct=100*earlier[oi]/scale,through83p2_pct=100*after[oi]/scale,third_change_percent=100*signed[oi],all_vs_fixed_change_percent=100*(after[oi]/fixed[oi]-1),isolated_third_change_percent=100*(isolated_ratio[oi]-1)))
                interference.append(dict(model=model,gravity=mode,output=label,units='squared percent of launch',third_power=thirdpower[oi]*1e4/scale**2,cross_first_two=crosstwo[oi]*1e4/scale**2,cross_fixed=cross64[oi]*1e4/scale**2,net_power_change=delta_power[oi]*1e4/scale**2,alignment=alignment[oi]))
                difference=delta[:,oi] if oi<2 else delta.sum(axis=1)
                support.append(dict(model=model,gravity=mode,output=label,visibility_fraction_increased=archive.probability(axis,weights,difference)))
            source_label='MTS-minus-cold' if model==MODELS[-1] else model
            saved=frozen_ref[source_label,'new_partial']
            assert np.isclose(scale,float(saved['input_norm']),rtol=1e-14,atol=0)
            frozen_expected=np.array([float(saved[key]) for key in ('energy_window_over_input','current_window_over_input','window_over_input')])
            rowcheck(checks,model,mode,'archived through64 window','through64',abs(fixed/scale/frozen_expected-1))
            point=spline(peak).sum(axis=0)
            ref=peak_ref[model,mode]
            expected=np.array([complex(float(ref[key+'_re']),float(ref[key+'_im'])) for key in OUTPUTS[:2]])
            rowcheck(checks,model,mode,'archived combined complex peak','through83.2',np.sqrt(components(abs(point-expected)**2)/components(abs(expected)**2)))
            for test in ('time','angle','window quadrature')+(('gravity',) if mode=='p32' else ()):
                if test=='window quadrature':
                    alternatives=fields(spline(dense))
                    sizes={key:size(value,dense_measure) for key,value in alternatives.items()}
                else:
                    native=history[model,'primary','p16'] if test=='gravity' else history[model,test,mode]
                    alternatives=fields(CubicSpline(grid,native,axis=0)(axis))
                    sizes={key:size(value,measure) for key,value in alternatives.items()}
                for key in states:
                    errors=abs(sizes[key]/rms[key]-1) if test=='window quadrature' else size(alternatives[key]-states[key],measure)/rms[key]
                    rowcheck(checks,model,mode,test,key,errors)
                alternate_change=(sizes['through83.2']-sizes['through76.8'])/sizes['through76.8']
                rowcheck(checks,model,mode,test,'signed fractional third change',abs(alternate_change-signed)/abs(signed))
    table('window-readouts.csv',readouts)
    table('third-power-balance.csv',interference)
    table('visibility-support.csv',support)
    table('checks.csv',checks)
    record('validation.json',dict(tolerance=LIMIT,passed=all(item['passed'] for item in checks),checks=len(checks),worst=max(checks,key=lambda item:item['relative_error']),archive_seal=WINDOW_SHA,source_hashes=inputs))
    assert all(item['passed'] for item in checks), 'Inspect retained checks.'
    print('Passed',len(checks),'checks.')

if __name__=='__main__':
    main()
