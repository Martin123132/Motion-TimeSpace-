import csv
import json
import sys
from pathlib import Path
from fixed_history import HERE, MODELS, MODES, OUTPUTS, LIMIT, WINDOW_SHA, np, proj, sha, save, guard, CubicSpline, simpson

def main():
    guard()
    info=json.loads((HERE/'validation.json').read_bytes())
    assert info['passed'] and info['tolerance']==LIMIT and info['archive_seal']==WINDOW_SHA
    assert all(sha(Path(name))==key for name,key in info['source_hashes'].items())
    with (HERE/'checks.csv').open() as handle:
        checks=list(csv.DictReader(handle))
    assert len(checks)==info['checks']==288 and all(row['passed']=='True' and 0<=float(row['relative_error'])<=LIMIT for row in checks)
    with (HERE/'window-readouts.csv').open() as handle:
        report={(row['model'],row['gravity'],row['output']):row for row in csv.DictReader(handle)}
    assert len(report)==18
    _,axis,weight,_=proj.old.get_media()
    native={}
    for model in MODELS[:2]:
        with np.load(HERE/f'fixed-plus-blocks-{model}.npz') as data:
            assert tuple(data['gravity_modes'])==MODES
            grid=data['scale']
            for mode in MODES:
                native[model,mode]=np.stack([data['through64'],data['through76p8_'+mode],data['through83p2_'+mode]],axis=1)
    for mode in MODES:
        native[MODELS[2],mode]=native['heavy',mode]-native['cold',mode]
        for model in MODELS:
            signal=CubicSpline(grid,native[model,mode],axis=0,extrapolate=False)(axis)
            power=simpson(weight[:,None,None]*abs(signal)**2,x=axis,axis=0)
            amplitudes=np.sqrt(np.column_stack([power,power.sum(axis=1)]))
            for index,label in enumerate(OUTPUTS):
                row=report[model,mode,label]
                expected=np.array([float(row[key]) for key in ['through64_pct','through76p8_pct','through83p2_pct']])
                assert np.allclose(100*amplitudes[:,index]/float(row['launch_norm']),expected,rtol=1e-12,atol=0)
    files=('RESULTS.md','fixed_history.py','verify.py','fixed-plus-blocks-cold.npz','fixed-plus-blocks-heavy.npz','window-readouts.csv','third-power-balance.csv','visibility-support.csv','checks.csv','validation.json')
    assert {path.name for path in HERE.iterdir()}-{'seal.json'}==set(files)
    body=(json.dumps(dict(parent=WINDOW_SHA,files={name:sha(HERE/name) for name in sorted(files)}),sort_keys=True,indent=2)+'\n').encode()
    if sys.argv[1:]==['--seal']:
        save('seal.json',body)
    assert (HERE/'seal.json').read_bytes()==body
    print('Verified packed histories for both models, both steps and 54 RMS entries. Seal:',sha(HERE/'seal.json'))

if __name__=='__main__':
    main()
