from pathlib import Path
import hashlib
import json
import sys

import numpy as np
from scipy.interpolate import CubicSpline
from scipy.linalg import solve_banded

ROOT=Path(__file__).resolve().parent
PRE=ROOT.parent/'mts-photon-rate-residual-attribution-89p6-20261124'
def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream,'sha256').hexdigest()
assert digest(PRE/'seal.json')=='0dec918ee446f14c2c5f0b8e1dfd0dc8fe9a361cece477e11ae4271f71c87c09'
manifest=json.loads((PRE/'seal.json').read_bytes())['files']
def prev(name):
    path=PRE/name
    assert digest(path)==manifest[name],name
    return path
sys.path.insert(0,str(PRE))
prev('rate_audit89.py')
import rate_audit89 as old
from rate_audit89 import gate,io
io.ROOT=ROOT
MODES=old.MODES
SETTINGS=('primary','time','angle')
WINDOWS=('post_cycle_interior','complete')
CONTROLS={'no_pair':'matched','full_U':'waveUinMatched','wave_env':'wave'}
def guard():
    old.guard()
    assert not (PRE/'STOP-REQUESTED').exists()
def relative(error,ref):
    return float(np.max(abs(error))/np.max(abs(ref)))
def get(mode,kind):
    name=f'ledger-{mode}-{kind}.npz'
    path=old.parent(name) if kind=='entry' else old.checked(name)
    with np.load(path) as packet:
        time=packet['eta'];keys=packet['keys'].tolist();families=packet['groups'].tolist()
        terms=np.ascontiguousarray(packet['residual'][:,:,0].T)
        direct=packet['total'][:,0]
        independent=CubicSpline(time,packet['phi'][:,:,0],axis=1)(time,1)-packet['pd'][:,:,0]
        err=relative(terms.T-independent,direct)
        assert err<1e-9
        closure=relative(terms.sum(axis=1)-direct,direct)
        assert closure<1e-6
    return time,keys,families,terms,direct,dict(rebuilt=err,sum=closure)
def inputs(mode):
    guard()
    time,keys,families,terms,total,check=get(mode,'entry')
    with np.load(prev('sources-'+mode+'.npz')) as saved:
        assert np.array_equal(time,saved['eta'])
        assert relative(total-saved['matched'],saved['matched'])<1e-10
    data={key:terms[:,index] for index,key in enumerate(keys)}
    data['direct']=total
    checks={'entry':check}
    sectors=list(dict.fromkeys(families))
    for control,label in CONTROLS.items():
        t0,keys0,fams,alternate,total0,checks[control]=get(mode,label)
        assert np.array_equal(t0,time) and keys==keys0 and fams==families
        data['control:'+control]=total0
        difference=terms-alternate
        for family in sectors:
            data['difference:'+control+':'+family]=difference[:,np.array(families)==family].sum(axis=1)
    io.record('inputs-'+mode+'.json',dict(keys=keys,families=families,sectors=sectors,checks=checks))
    return time,list(data),np.column_stack(list(data.values()))
def transport(mode,setting,time,labels,source):
    guard()
    cuts=np.array(json.loads(prev('time-cuts.json').read_bytes())['cuts'])
    with np.load(old.parent('entry-curves-p32-companion.npz')) as saved:
        fine=saved['eta']
    grid,eta,medium,_,_=gate.proj.measure('heavy')
    with np.load(io.old.pin('photon-accumulated-heavy.npz')) as heavy,np.load(io.old.pin('photon-accumulated-cold.npz')) as cold:
        assert np.array_equal(grid,heavy['scale']) and np.array_equal(grid,cold['scale'])
        wave=float(heavy['k'])
    order,sub,stride=gate.transfer.prior.SETTINGS[setting]
    axis=np.unique(np.r_[gate.proj.base_axis(grid,eta,sub),fine[::stride],fine[-1]])
    split=np.searchsorted(axis,cuts)
    assert np.array_equal(axis[split],cuts)
    start,end=split[[0,-1]]
    assert time[0]==cuts[0] and time[-1]==cuts[-1]
    rates,stages=gate.proj.coefficients(axis,medium,wave)
    evals=CubicSpline(time,source,extrapolate=False)(np.clip(stages[start:end],time[0],time[-1]))
    pulse=4*np.diff(axis)[start:end,None,None]*np.einsum('st,ntc->nsc',gate.proj.RAD,evals)
    interior=(np.arange(start,end)>=split[-3])&(np.arange(start,end)<split[-2])
    impulse=np.concatenate([pulse*interior[:,None,None],pulse],axis=2)
    bands=gate.proj.transfer.stages(order)
    size=bands.shape[-1]//2
    cols=impulse.shape[-1]
    state=np.zeros((size,2*cols))
    rhs=np.empty((2*size,2*cols),order='F')
    positions=np.searchsorted(axis,eta)
    assert np.array_equal(axis[positions],eta)
    slots=np.full(len(axis),-1);slots[positions]=np.arange(len(eta))
    history=np.zeros((len(eta),cols,2),complex)
    for begin in range(start,len(rates),64):
        if (begin-start)%1024==0:guard()
        stop=min(begin+64,len(rates))
        mats=(rates[begin:stop].reshape(-1,8)@bands.reshape(8,-1)).reshape(-1,11,2*size);mats[:,5]+=1
        for step,mat in enumerate(mats,begin):
            rhs[::2]=state;rhs[1::2]=state
            if step<end:
                excitation=impulse[step-start]
                rhs[:2,::2]+=excitation.real;rhs[:2,1::2]+=excitation.imag
            state=solve_banded((5,5),mat,rhs,check_finite=False)[1::2]
            if slots[step+1]>=0:
                history[slots[step+1]]=(state[[0,2],::2]+1j*state[[0,2],1::2]).T
    assert np.isfinite(history).all()
    io.pack('responses-'+mode+'-'+setting+'.npz',grid=grid,cuts=cuts,windows=WINDOWS,labels=labels,
            values=history.reshape(len(grid),len(WINDOWS),len(labels),2))
    print(mode,setting,'transported',len(labels),'sources x two windows',flush=True)
if __name__=='__main__':
    for mode in sys.argv[1:]:
        assert mode in MODES
        time,labels,source=inputs(mode)
        for setting in SETTINGS:transport(mode,setting,time,labels,source)
