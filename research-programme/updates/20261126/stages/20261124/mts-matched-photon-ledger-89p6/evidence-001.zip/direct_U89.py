from unittest.mock import patch
from scipy.interpolate import make_interp_spline
from matched_ledger89 import ROOT,MODES,old,io,np,relative,CubicSpline,transport,guard

PARTS=('potential_square','laplacian','gradient','remaining_flux')
def direct_sources(mode):
    with np.load(old.parent(f'ledger-{mode}-entry.npz')) as entry,np.load(old.checked(f'ledger-{mode}-waveUinMatched.npz')) as other:
        times=entry['eta'];groups=entry['groups'].tolist();keys=entry['keys'].tolist()
        assert np.array_equal(times,other['eta']) and np.array_equal(entry['den'],other['den']) and np.array_equal(entry['hub'],other['hub'])
        den=entry['den'][:,0];hub=entry['hub'][:,0]
        actual=entry['residual'][keys.index('U'),:,0]-other['residual'][keys.index('U'),:,0]
        for key in ('Q','Fq'):
            idx=keys.index(key)
            assert np.array_equal(entry['residual'][idx],other['residual'][idx])
    with np.load(old.checked('native-U.npz')) as bank,np.load(old.parent('primary.npz')) as forecast:
        knots=bank['eta'];assert np.array_equal(knots,forecast['eta'])
        terms=[bank['matched_'+key]-bank['wave_'+key] for key in PARTS[:3]]
        terms += [forecast['restore']+bank['matched_flux_square']-bank['wave_flux_square']]
    potentials=make_interp_spline(np.log(knots),np.array(terms).T,k=5,axis=0)(np.log(times))/den[:,None]
    sources=CubicSpline(times,potentials)(times,1)+hub[:,None]*potentials
    err=relative(sources.sum(axis=1)-actual,actual)
    io.record('direct-U-check-'+mode+'.json',dict(relative=err,passed=err<=.005))
    return times,list(PARTS),sources,err
def run(mode):
    times,labels,source,err=direct_sources(mode)
    if err>.005:
        print(mode,'native split failed source gate',err);return
    save=io.pack
    def save_own(name,**kw):save('direct-U-'+name,**kw)
    with patch.object(io,'pack',save_own):
        transport(mode,'primary',times,labels,source)
if __name__=='__main__':
    for mode in MODES:run(mode)
