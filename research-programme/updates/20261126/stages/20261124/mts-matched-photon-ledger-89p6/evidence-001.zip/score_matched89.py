import csv
from matched_ledger89 import ROOT,MODES,WINDOWS,SETTINGS,CONTROLS,prev,old,gate,io,np,json,CubicSpline,guard

MACRO={'geometry':('metric',),'radiation_and_collisionless':('photon','collisionless'),
       'remaining_matter':('cold','baryon','slow','heavy')}

def score():
    guard()
    _,axis,weights,_=gate.proj.old.get_media()
    measure=gate.previous.make_measure(axis,weights)
    norm=lambda vec:gate.mag(vec,measure)
    def projection(ref,val):
        power=norm(ref)**2
        real=measure@(ref.conj()*val).real
        return np.r_[real,real.sum()]/power
    contributions=[];replay=[];alternates=[];conditioning=[];sensitivity=[]
    retained={};denoms={}
    for mode in MODES:
        info=json.loads((ROOT/('inputs-'+mode+'.json')).read_bytes())
        keys,families,sectors=(info[k] for k in ('keys','families','sectors'))
        assert sorted(sum((list(v) for v in MACRO.values()),[]))==sorted(sectors)
        for setting in SETTINGS:
            with np.load(ROOT/f'responses-{mode}-{setting}.npz') as data,np.load(prev('transport-'+setting+'.npz')) as target,np.load(old.parent('photon-'+setting+'.npz')) as original,np.load(old.checked('photons-'+setting+'.npz')) as controlled:
                grid=data['grid'];labels=data['labels'].tolist()
                assert all(np.array_equal(grid,tab[name]) for tab,name in ((target,'grid'),(original,'scale'),(controlled,'scale')))
                assert np.array_equal(data['cuts'],target['cuts']) and data['windows'].tolist()==list(WINDOWS)
                output=data['values'];archive=target['values'][:,list(MODES).index(mode)]
                cols=target['channels'].tolist()
                orig=original['values'][:,original['inputs'].tolist().index([mode,'primary'])]
                denominator=norm(CubicSpline(grid,orig[:,:3].sum(1))(axis))
                fullgap=orig[:,3]-orig[:,1]
                controls=controlled['values']
                for ws,window in enumerate(WINDOWS):
                    zs=['later_interior'] if ws==0 else list(old.ZONES)
                    get=lambda name:sum(archive[:,cols.index(name+'_'+z)] for z in zs)
                    wanted=get('matched');ref=CubicSpline(grid,wanted)(axis)
                    scale=norm(ref);denoms[setting,mode,window]=scale
                    negative_ref=get('negative_reference')
                    def check(name,a,b,s):
                        err=a-b
                        values=norm(CubicSpline(grid,err)(axis))/norm(CubicSpline(grid,s)(axis))
                        pk=np.max(abs(err),axis=0)/np.max(abs(s),axis=0)
                        replay.append(dict(mode=mode,window=window,setting=setting,test=name,
                                      relative_energy=values[0],relative_current=values[1],relative_joint=values[2],
                                      peak_energy=pk[0],peak_current=pk[1]))
                        assert max(*pk,*values)<.005,(name,mode,setting,window,values,pk)
                    block=output[:,ws]
                    mapped={name:block[:,idx] for idx,name in enumerate(labels)}
                    check('direct vs saved matched vector',mapped['direct'],wanted,wanted)
                    check('all leaves vs saved matched vector',sum(mapped[k] for k in keys),wanted,wanted)
                    if ws==1:check('matched minus explicit reference vs saved gap',sum(mapped[k] for k in keys)+negative_ref,fullgap,fullgap)
                    sectors_v={s:sum(mapped[k] for k,fam in zip(keys,families) if fam==s) for s in sectors}
                    macros={s:sum(sectors_v[g] for g in parts) for s,parts in MACRO.items()}
                    def record(family,terms,target_v):
                        total=norm(target_v)
                        cond=0.
                        for key,raw in terms.items():
                            vec=CubicSpline(grid,raw)(axis)
                            norms=norm(vec);proj=projection(target_v,vec)
                            cond+=norms[2]/total[2]
                            contributions.append(dict(mode=mode,window=window,setting=setting,family=family,term=key,
                                signed_energy=proj[0],signed_current=proj[1],signed_joint=proj[2],
                                norm_over_net=norms[2]/total[2],pct_of_small=100*norms[2]/denominator[2]))
                            if family!='leaf':
                                retained[mode,setting,window,family,key]=vec
                        conditioning.append(dict(mode=mode,window=window,setting=setting,family=family,
                                                 sum_norm_over_net=cond,net_pct_small=100*total[2]/denominator[2]))
                    record('leaf',{k:mapped[k] for k in keys},ref);record('sector',sectors_v,ref);record('macro',macros,ref)
                    for variant in CONTROLS:
                        control=mapped['control:'+variant]
                        diff=wanted-control
                        diffterms={s:mapped['difference:'+variant+':'+s] for s in sectors}
                        check('entry minus '+variant+' ledger closure',sum(diffterms.values()),diff,diff)
                        reference=CubicSpline(grid,diff)(axis)
                        record('change_vs_'+variant,diffterms,reference)
                        altvec=CubicSpline(grid,control)(axis)
                        actual=CubicSpline(grid,control+negative_ref)(axis)
                        own=''
                        if variant in ('no_pair','full_U') and ws==1:
                            name='original' if variant=='no_pair' else 'U_swap'
                            idx=controlled['inputs'].tolist().index([mode,name])
                            direct=controls[:,idx,3]-controls[:,idx,1]
                            check(variant+' vs separately saved two-route photons',control+negative_ref,direct,direct)
                            own=100*norm(actual)[2]/norm(CubicSpline(grid,controls[:,idx,:3].sum(1))(axis))[2]
                        alternates.append(dict(mode=mode,setting=setting,window=window,control=variant,
                                           entry_pct_small=100*scale[2]/denominator[2],control_pct_small=100*norm(altvec)[2]/denominator[2],
                                           change_pct_small=100*norm(reference)[2]/denominator[2],
                                           signed_change_over_entry=projection(ref,reference)[2],control_plus_negative_ref_pct_small=100*norm(actual)[2]/denominator[2],
                                           full_route_gap_pct_own_correction=own))
        print(mode,'compared',flush=True)
    for (mode,setting,window,family,key),vec in retained.items():
        if setting!='primary':continue
        for test,alt_mode,alt_setting in [('time',mode,'time'),('angle',mode,'angle')]+([('gravity','p16','primary')] if mode=='p32' else []):
            err=norm(vec-retained[alt_mode,alt_setting,window,family,key])
            rel=err/denoms[setting,mode,window]
            sensitivity.append(dict(mode=mode,window=window,family=family,term=key,test=test,
                            energy_over_matched=rel[0],current_over_matched=rel[1],joint_over_matched=rel[2],below=bool(max(rel)<=.005)))
    for name,data in [('contributions',contributions),('closure',replay),('conditioning',conditioning),
                      ('counterfactuals',alternates),('sensitivity',sensitivity)]:
        io.table(name+'.csv',data)
if __name__=='__main__':score()
