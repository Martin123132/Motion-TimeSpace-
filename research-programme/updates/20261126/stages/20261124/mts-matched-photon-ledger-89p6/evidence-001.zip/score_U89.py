import csv
from direct_U89 import PARTS
from matched_ledger89 import ROOT,MODES,WINDOWS,old,gate,io,np,CubicSpline

def score():
    _,axis,weights,_=gate.proj.old.get_media()
    measure=gate.previous.make_measure(axis,weights)
    norm=lambda x:gate.mag(x,measure)
    rows=[]
    for mode in MODES:
        with np.load(ROOT/f'responses-{mode}-primary.npz') as archived,np.load(ROOT/f'direct-U-responses-{mode}-primary.npz') as parts:
            grid=parts['grid']
            assert np.array_equal(grid,archived['grid']) and list(parts['labels'])==list(PARTS)
            full=archived['values'];labels=archived['labels'].tolist()
            for idx,window in enumerate(WINDOWS):
                metric=CubicSpline(grid,full[:,idx,labels.index('difference:full_U:metric')])(axis)
                matched=CubicSpline(grid,full[:,idx,labels.index('direct')])(axis)
                total=matched-CubicSpline(grid,full[:,idx,labels.index('control:full_U')])(axis)
                vec=CubicSpline(grid,parts['values'][:,idx])(axis)
                err=norm(vec.sum(1)-metric)/norm(metric)
                assert max(err)<.005,(mode,window,err)
                for col,key in enumerate(PARTS):
                    sample=vec[:,col]
                    def share(reference):
                        return float(np.sum(measure@(reference.conj()*sample).real)/norm(reference)[2]**2)
                    rows.append(dict(mode=mode,window=window,source=key,signed_over_direct_metric=share(metric),
                                     signed_over_total_change=share(total),size_over_direct=norm(sample)[2]/norm(metric)[2],
                                     size_over_matched=norm(sample)[2]/norm(matched)[2],closure_joint=err[2]))
    io.table('direct-U-attribution.csv',rows)
    for row in rows:
        if (row['mode'],row['window'])==('p32','complete'): print(row['source'],row['signed_over_direct_metric'])
if __name__=='__main__':score()
