import csv
import re
from matched_ledger89 import ROOT,MODES,SETTINGS,WINDOWS,PRE,old,guard,digest,io,np,json

def read(name):
    with (ROOT/name).open() as stream:
        return list(csv.DictReader(stream))

def verify():
    guard()
    balances=read('closure.csv')
    for mode in MODES:
        for setting in SETTINGS:
            with np.load(ROOT/f'responses-{mode}-{setting}.npz') as data,np.load(old.parent('photon-'+setting+'.npz')) as launch:
                assert data['values'].shape==(4097,2,50,2)
                assert np.isfinite(data['values']).all() and np.array_equal(data['grid'],launch['scale'])
                assert len(set(data['labels'].tolist()))==50
            for window in WINDOWS:
                rows=[r for r in balances if (r['mode'],r['window'],r['setting'])==(mode,window,setting)]
                assert len(rows)==(8 if window=='complete' else 5)
                assert all(max(float(r[c]) for c in ('relative_energy','relative_current','relative_joint','peak_energy','peak_current'))<.005 for r in rows)
    shares=read('contributions.csv')
    for ident in {(r['mode'],r['window'],r['setting'],r['family']) for r in shares}:
        sub=[r for r in shares if (r['mode'],r['window'],r['setting'],r['family'])==ident]
        for channel in ('signed_joint','signed_current','signed_energy'):
            assert abs(sum(float(r[channel]) for r in sub)-1)<.005
    direct=read('direct-U-attribution.csv')
    assert len(direct)==16
    for mode in MODES:
        assert json.loads((ROOT/f'direct-U-check-{mode}.json').read_bytes())['passed']
        for window in WINDOWS:
            sub=[r for r in direct if r['mode']==mode and r['window']==window]
            assert abs(sum(float(r['signed_over_direct_metric']) for r in sub)-1)<.005
    for name in ['RESULTS.md','METHOD.md','PROTOCOL.md']:
        for link in re.findall(r'\]\(([^)]+)\)',(ROOT/name).read_text(encoding='utf-8')):
            assert (ROOT/link).is_file(),link
    for path in ROOT.glob('*.py'):
        compile(path.read_bytes(),str(path),'exec')
    target=ROOT/'seal.json'
    files={p.name:digest(p) for p in sorted(ROOT.iterdir()) if p.is_file() and p!=target}
    if target.exists(): assert files==json.loads(target.read_bytes())['files']
    else: io.record('seal.json',dict(files=files,prior_seal=digest(PRE/'seal.json')))
    print('Verified',len(files),'files;',digest(target))
if __name__=='__main__':verify()
