from pathlib import Path
import sys, hashlib, json
from dataclasses import dataclass
import numpy as np
from scipy.interpolate import CubicSpline
from numpy.polynomial.legendre import leggauss

ROOT=Path(__file__).resolve().parent
PRE=ROOT.parent/'mts-fixed-geometry-resolved-current-89p6-20261124'
PREHASH='900f996efbc512e4b30f0a07458cf356901b5967c70e154e409c3612de4dfd86'
def digest(path):
    with path.open('rb') as fp:return hashlib.file_digest(fp,'sha256').hexdigest()
assert digest(PRE/'seal.json')==PREHASH
manifest=json.loads((PRE/'seal.json').read_bytes())['files']
def pin(name):
    target=PRE/name;assert digest(target)==manifest[name],name
    return target
sys.path.insert(0,str(PRE))
pin('restore89.py');pin('readout89.py')
import restore89 as old
from readout89 import gate
from restore89 import io,SWITCH,END,MODES
io.ROOT=ROOT
def guard():
    old.guard();assert not (PRE/'STOP-REQUESTED').exists()
BRANCHES=('matched_mean','matched_restored','wave')
def curve(mode,cell):
    if cell=='base':return old.path(mode,'base','curves')
    return pin(f'restored-curves-{mode}-companion.npz')
@dataclass
class Source:
    time:np.ndarray
    knots:np.ndarray
    phi:CubicSpline
    momentum:CubicSpline
    archived:CubicSpline
    mean:np.ndarray

def quadrature(splits,order):
    nodes,weights=leggauss(order)
    halves=np.diff(splits)/2;points=splits[:-1,None]+halves[:,None]*(nodes+1)
    return points,halves[:,None]*weights

def scatter(vals,indices,length):
    result=np.zeros(length,dtype=vals.dtype);np.add.at(result,indices,vals);return result

def source(mode,branch):
    with np.load(curve(mode,'restored' if branch=='matched_restored' else 'base')) as data:
        time=data['eta']
        if branch!='wave':
            native=time;phi_samples=data['phi'];rates=data['pd'];legacy=data['derivative']-rates
    if branch=='wave':
        with np.load(io.old.pin(f'particular-heavy-{mode}.npz')) as data:
            native=data['eta'];phi_samples=data['phi'];rates=data['phi_dot']
        assert native[0]<SWITCH and native[-1]>=END and np.max(abs(native[-len(time)+1:]-time[1:]))<1e-12
    assert time[0]==SWITCH and time[-1]==END and np.all(np.diff(time)>0)
    phi=CubicSpline(native,phi_samples,extrapolate=False);mom=CubicSpline(native,rates,extrapolate=False)
    knots=np.unique(np.r_[time,native[(native>time[0])&(native<time[-1])]])
    if branch=='wave':legacy=phi(time,1)-mom(time)
    archive=CubicSpline(time,legacy,extrapolate=False)
    ep=phi(time)
    if branch!='wave':ep=phi_samples
    else:
        exact=np.searchsorted(native,time);valid=exact<len(native)
        valid[valid]=native[exact[valid]]==time[valid];ep[valid]=phi_samples[exact[valid]]
    delta=np.diff(ep);bins=np.searchsorted(time,knots[:-1],side='right')-1
    def integrate(fun,order):
        nodes,w=quadrature(knots,order)
        return scatter(np.sum(w*fun(nodes),axis=1),bins,len(time)-1)
    integral=integrate(mom,4);res=delta-integral;dt=np.diff(time);mean=res/dt
    scale=max(abs(integral/dt));ref=max(abs(mean))
    assert ref>0
    err=lambda v:float(np.max(abs(v/dt))/ref)
    checks=dict(gauss_order=err(integral-integrate(mom,6)),endpoint_derivative=err(integrate(lambda t:phi(t,1),4)-delta),
                sign_identity=err(integrate(lambda t:phi(t,1)-mom(t),4)-res))
    assert max(checks.values())<.005,checks
    worst=int(np.argmax(abs(mean)))
    summary=dict(mode=mode,branch=branch,cells=len(dt),raw_reference_native=branch=='wave',
                 worst_cell_left=time[worst],worst_cell_right=time[worst+1],peak_rate_defect_pct=100*ref/scale,
                 time_rms_defect_pct=100*np.sqrt(sum(dt*abs(mean)**2)/sum(dt*abs(integral/dt)**2)),
                 net_real=sum(res).real,net_imag=sum(res).imag,**checks)
    io.pack(f'cells-{mode}-{branch}.npz',eta=time,endpoint_potential=ep,observed_change=delta,momentum_integral=integral,
            signed_defect=res,mean_defect=mean,local_absolute_relative=abs(res)/np.maximum(abs(integral),np.finfo(float).tiny))
    return Source(time,knots,phi,mom,archive,mean),summary

if __name__=='__main__':
    guard();out=[source(mode,br)[1] for mode in MODES for br in BRANCHES]
    io.table('cells.csv',out)
    for r in out:print(r['mode'],r['branch'],r['cells'],r['peak_rate_defect_pct'],r['sign_identity'])
