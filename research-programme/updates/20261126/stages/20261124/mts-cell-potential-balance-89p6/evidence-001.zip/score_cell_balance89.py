import csv
from scipy.interpolate import CubicSpline
from photons89 import CHANNELS
from cell89 import ROOT,io,pin,old,gate,guard,np,json,digest,MODES,BRANCHES

SETTINGS=('primary','time','angle')
CELLS=('base','restored')
def scores():
    guard()
    _,axis,visibility,_=gate.proj.old.get_media()
    measure=gate.previous.make_measure(axis,visibility);mag=lambda v:gate.mag(v,measure)
    with gate.pin(gate.FROZEN,'window-readouts.csv').open() as fp:
        launch={r['gravity']:float(r['launch_norm']) for r in csv.DictReader(fp) if r['model']=='MTS-minus-baseline' and r['output']=='joint'}
    refdir=ROOT.parent/'mts-photon-rate-residual-attribution-89p6-20261124'
    assert digest(refdir/'seal.json')=='0dec918ee446f14c2c5f0b8e1dfd0dc8fe9a361cece477e11ae4271f71c87c09'
    refhash=json.loads((refdir/'seal.json').read_bytes())['files']
    gates=[];effects=[];proof=[];cache={};branchrows=[];control=[];cell_stats=[]
    for mode in MODES:
        for br in BRANCHES:
            with np.load(ROOT/f'cells-{mode}-{br}.npz') as data:
                time=data['eta'];rat=data['local_absolute_relative'];delta=data['observed_change'];pred=data['momentum_integral'];defect=data['signed_defect']
                cell_stats.append(dict(mode=mode,branch=br,cells=len(rat),cells_over_half_pct_of_own_impulse=int(np.sum(rat>.005)),local_pct_median=100*np.median(rat),local_pct_max=100*rat.max(),worst_relative_left=time[np.argmax(rat)],max_excursion_error_pct=100*np.max(abs(np.cumsum(defect)))/np.max(abs(np.cumsum(pred))),endpoint_telescoping=float(abs(sum(delta)-(data['endpoint_potential'][-1]-data['endpoint_potential'][0]))/max(abs(pred)))))
    for setting in SETTINGS:
        refname=f'transport-{setting}.npz';assert digest(refdir/refname)==refhash[refname]
        with np.load(refdir/refname) as ref,np.load(pin(f'photon-{setting}.npz')) as saved,np.load(ROOT/f'photons-{setting}.npz') as new:
            grid=new['scale'];assert np.array_equal(grid,saved['grid']) and np.array_equal(grid,ref['grid'])
            project=lambda v:CubicSpline(grid,v)(axis)
            labels=saved['labels'].tolist();negs=[i for i,k in enumerate(ref['channels']) if k.startswith('negative_reference_')]
            assert negs
            for mi,mode in enumerate(MODES):
                vec={}
                for bi,br in enumerate(BRANCHES):
                    row=project(new['values'][:,mi,bi]);pieces={k:row[:,j] for j,k in enumerate(CHANNELS)}
                    pieces['integral']=pieces['endpoint_mean']+pieces['within_cell']
                    pieces['sampled_integral']=pieces['integral']+pieces['sampled_minus_true']
                    pieces['collocation_error']=pieces['saved_collocation']-pieces['sampled_integral']
                    vec[br]=pieces
                old_wave=-project(ref['values'][:,mi][:,negs].sum(1))
                for ci,cell in enumerate(CELLS):
                    br=BRANCHES[ci];values=saved['values'][:,labels.index([mode,'primary' if cell=='base' else 'restored'])]
                    momentum=project(values[:,:3].sum(1));orig=project(values[:,3]-values[:,1])
                    if cell=='base':den=mag(momentum);origscale=mag(orig)
                    combined={k:vec[br][k]-vec['wave'][k] for k in vec[br]}
                    for label,actual,expected in [('reference',vec['wave']['saved_collocation'],old_wave),('matched',vec[br]['saved_collocation'],orig+old_wave),('matched_minus_reference',combined['saved_collocation'],orig)]:
                        rel=mag(actual-expected)/mag(expected)
                        proof.append(dict(mode=mode,setting=setting,cell=cell,check=label,energy=rel[0],current=rel[1],joint=rel[2]))
                        assert max(rel)<.005,(mode,setting,cell,label,rel)
                    for label,pieces in [(br,vec[br]),('wave',vec['wave']),('matched_minus_wave',combined)]:
                        if label=='wave' and cell!='base':continue
                        for key,val in pieces.items():
                            cache[mode,setting,label if label!='matched_minus_wave' else cell+':difference',key]=val
                            pct=100*mag(val)/den
                            branchrows.append(dict(mode=mode,setting=setting,cell=cell,branch=label,term=key,energy_common_pct=pct[0],current_common_pct=pct[1],joint_common_pct=pct[2]))
                    for key in ('endpoint_mean','within_cell','sampled_minus_true','collocation_error','integral','saved_collocation'):
                        actual=combined[key];frac=100*mag(actual)/mag(momentum);common=100*mag(actual)/den
                        inner=measure@(orig.conj()*actual).real
                        effects.append(dict(mode=mode,setting=setting,cell=cell,term=key,signed_share=inner.sum()/mag(orig)[2]**2,magnitude_over_old_gap=mag(actual)[2]/mag(orig)[2],common_pct=common[2]))
                        if key in ('endpoint_mean','integral','saved_collocation'):
                            diff=momentum+actual
                            pm=100*mag(momentum)[2]/launch[mode];pd=100*mag(diff)[2]/launch[mode]
                            gates.append(dict(mode=mode,setting=setting,cell=cell,term=key,energy_pct=frac[0],current_pct=frac[1],joint_pct=frac[2],common_joint_pct=common[2],momentum_launch_pct=pm,differentiated_launch_pct=pd,size_pass=bool(max(pm,pd)<.163),rate_pass=bool(max(frac)<=.5)))
    for (mode,setting,br,key),vec in cache.items():
        if setting!='primary' or key not in ('endpoint_mean','integral','saved_collocation'):continue
        for tag,other,alt in [('photon_time',mode,'time'),('photon_angle',mode,'angle')]+([('gravity','p16','primary')] if mode=='p32' else []):
            delta=mag(vec-cache[other,alt,br,key]);ratio=delta/mag(vec)
            control.append(dict(mode=mode,branch=br,term=key,test=tag,energy_relative=ratio[0],current_relative=ratio[1],joint_relative=ratio[2],passes=bool(max(ratio)<=.005)))
    for name,rows in [('endpoint-statistics',cell_stats),('gates',gates),('signed-terms',effects),('branch-projection',branchrows),('replay',proof),('controls',control)]:
        io.table(name+'.csv',rows)
    print([(r['mode'],r['cell'],r['term'],r['common_joint_pct']) for r in gates if r['setting']=='primary'])
if __name__=='__main__':scores()
