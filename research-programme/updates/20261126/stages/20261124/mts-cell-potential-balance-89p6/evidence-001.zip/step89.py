from cell89 import ROOT,io,np,BRANCHES,gate,guard
from score_cell_balance89 import SETTINGS
from scipy.interpolate import CubicSpline

def compare():
    guard()
    rows=[];cells=[]
    _,axis,weights,_=gate.proj.old.get_media();measure=gate.previous.make_measure(axis,weights)
    mag=lambda vec:gate.mag(vec,measure)
    for br in BRANCHES:
        with np.load(ROOT/f'cells-p16-{br}.npz') as coarse,np.load(ROOT/f'cells-p32-{br}.npz') as fine:
            clock=coarse['eta']
            assert np.array_equal(clock,fine['eta'][::2])
            group=lambda k:fine[k].reshape(-1,2).sum(1)
            ep=coarse['observed_change']-group('observed_change');pred=group('momentum_integral')-coarse['momentum_integral']
            delta=coarse['signed_defect']-group('signed_defect')
            error=max(abs(ep+pred-delta))/max(abs(delta))
            assert error<.005
            cells.append(dict(branch=br,paired_cells=len(ep),relative_sum_error=error))
            io.pack(f'paired-cells-{br}.npz',eta=clock,coarse_minus_fine_endpoint_increment=ep,negative_momentum_increment_difference=pred,total=delta)
    for setting in SETTINGS:
        with np.load(ROOT/f'gravity-difference-{setting}.npz') as packet,np.load(ROOT/f'photons-{setting}.npz') as old:
            grid=packet['scale'];assert np.array_equal(grid,old['scale'])
            interp=lambda v:CubicSpline(grid,v)(axis)
            src=old['values'][:,:,:,:2].sum(3)
            for idx,br in enumerate(BRANCHES):
                target=interp(src[:,0,idx]-src[:,1,idx])
                terms=interp(packet['values'][:,idx])
                norm=mag(target)
                err=mag(terms.sum(1)-target)/norm;assert max(err)<.005,(br,err)
                for j,key in enumerate(('endpoint_change','negative_momentum_prediction')):
                    val=terms[:,j];dot=measure@(target.conj()*val).real
                    proj=np.r_[dot,dot.sum()]/norm**2
                    rows.append(dict(setting=setting,branch=br,term=key,energy_signed=proj[0],current_signed=proj[1],joint_signed=proj[2],joint_norm_over_change=mag(val)[2]/norm[2],max_component_closure=max(err)))
    io.table('paired-stats.csv',cells);io.table('gravity-attribution.csv',rows)
    print([r for r in rows if r['setting']=='primary'])
if __name__=='__main__':compare()
