from scipy.linalg import solve_banded
from cell89 import ROOT,io,guard,np,gate,MODES,BRANCHES,SWITCH,END,source,quadrature,sys

CHANNELS=('endpoint_mean','within_cell','sampled_minus_true','saved_collocation')
def stages(axis,at,src):
    step=np.diff(axis);h=step[:,None]
    assert np.max(abs(at-(axis[:-1,None]+h*np.array([1/3,1]))))<2e-12
    cuts=np.unique(np.r_[axis,src.knots])
    idx=np.searchsorted(axis,cuts[:-1],side='right')-1
    cell=np.searchsorted(src.time,cuts[:-1],side='right')-1
    def project(order):
        pos,w=quadrature(cuts,order);frac=(pos-axis[idx,None])/step[idx,None]
        basis=np.stack((1.5*(1-frac)/.75,(1.5*frac-.5)/.25),axis=2)
        true=src.phi(pos,1)-src.momentum(pos)
        mean=np.broadcast_to(src.mean[cell,None],pos.shape)
        channels=np.stack((mean,true-mean,src.archived(pos)-true,np.ones_like(true),frac),axis=2)
        moments=np.einsum('iq,iqs,iqk->isk',w,basis,channels)
        sums=np.zeros((len(step),2,channels.shape[-1]),complex);np.add.at(sums,idx,moments)
        return sums/step[:,None,None]
    moments=project(4);other=project(6)
    assert np.max(abs(moments[:,:,3]-1))<1e-6 and np.max(abs(moments[:,:,4]-[1/3,1]))<1e-6
    precision=np.max(abs(moments[:,:,:3]-other[:,:,:3]))/np.max(abs(moments[:,:,0]))
    assert precision<.005,precision
    values=np.concatenate((moments[:,:,:3],src.archived(np.clip(at,SWITCH,END))[:,:,None]),axis=2)
    return 4*step[:,None,None]*np.einsum('st,ntk->nsk',gate.proj.RAD,values),precision

def pair_stages(axis,coarse,fine):
    assert np.array_equal(coarse.time,fine.time[::2])
    cuts=np.unique(np.r_[axis,coarse.knots,fine.knots])
    ix=np.searchsorted(axis,cuts[:-1],side='right')-1
    steps=np.diff(axis)
    def moments(order):
        pos,w=quadrature(cuts,order)
        frac=(pos-axis[ix,None])/steps[ix,None]
        basis=np.stack((1.5*(1-frac)/.75,(1.5*frac-.5)/.25),axis=2)
        parts=np.stack((coarse.phi(pos,1)-fine.phi(pos,1),fine.momentum(pos)-coarse.momentum(pos)),axis=2)
        values=np.einsum('iq,iqs,iqk->isk',w,basis,parts)
        sums=np.zeros((len(steps),2,2),complex);np.add.at(sums,ix,values)
        return sums
    values=moments(4);check=np.max(abs(moments(6)-values))/np.max(abs(values.sum(axis=2)))
    assert check<.005
    return 4*np.einsum('st,ntk->nsk',gate.proj.RAD,values),check

def transport(setting,paired=False):
    guard()
    sources={(mode,br):source(mode,br)[0] for mode in MODES for br in BRANCHES}
    grid,eta,medium,_,_=gate.proj.measure('heavy')
    with np.load(io.old.pin('photon-accumulated-heavy.npz')) as heavy,np.load(io.old.pin('photon-accumulated-cold.npz')) as cold:
        assert np.array_equal(heavy['scale'],grid) and np.array_equal(cold['scale'],grid) and heavy['k']==cold['k']
        wave=float(heavy['k'])
    order,sub,stride=gate.transfer.prior.SETTINGS[setting]
    fine=sources['p32','matched_mean'].time
    axis=np.unique(np.r_[gate.proj.base_axis(grid,eta,sub),fine[::stride],fine[-1]])
    start,end=np.searchsorted(axis,[SWITCH,END]);assert axis[start]==SWITCH and axis[end]==END
    rates,at=gate.proj.coefficients(axis,medium,wave);impulses=[];checks=[]
    if paired:
        for br in BRANCHES:
            forcing,check=pair_stages(axis[start:end+1],sources['p16',br],sources['p32',br])
            impulses.append(forcing);checks.append(dict(mode='p16-minus-p32',branch=br,relative=check))
    else:
        for key,src in sources.items():
            forcing,check=stages(axis[start:end+1],at[start:end],src)
            impulses.append(forcing);checks.append(dict(mode=key[0],branch=key[1],relative=check))
    impulse=np.concatenate(impulses,axis=2);bands=gate.proj.transfer.stages(order)
    size=bands.shape[-1]//2;count=impulse.shape[-1]
    state=np.zeros((size,2*count));rhs=np.empty((2*size,2*count),order='F')
    positions=np.searchsorted(axis,eta);assert np.array_equal(axis[positions],eta)
    slots=np.full(len(axis),-1);slots[positions]=np.arange(len(eta))
    hist=np.zeros((len(eta),count,2),complex)
    for begin in range(start,len(rates),64):
        if (begin-start)%1024==0:guard()
        endchunk=min(begin+64,len(rates))
        mats=(rates[begin:endchunk].reshape(-1,8)@bands.reshape(8,-1)).reshape(-1,11,2*size);mats[:,5]+=1
        for ix,matrix in enumerate(mats,begin):
            rhs[::2]=state;rhs[1::2]=state
            if ix<end:
                change=impulse[ix-start];rhs[:2,::2]+=change.real;rhs[:2,1::2]+=change.imag
            state=solve_banded((5,5),matrix,rhs,check_finite=False)[1::2]
            if slots[ix+1]>=0:hist[slots[ix+1]]=(state[[0,2],::2]+1j*state[[0,2],1::2]).T
    assert np.isfinite(hist).all()
    if paired:
        io.pack(f'gravity-difference-{setting}.npz',scale=grid,branches=BRANCHES,channels=['potential','minus_momentum'],values=hist.reshape(len(eta),len(BRANCHES),2,2))
        io.table(f'paired-quadrature-{setting}.csv',checks)
    else:
        io.pack(f'photons-{setting}.npz',scale=grid,modes=MODES,branches=BRANCHES,channels=CHANNELS,values=hist.reshape(len(eta),len(MODES),len(BRANCHES),len(CHANNELS),2))
        io.table(f'quadrature-{setting}.csv',checks)
    print(setting,len(axis)-1,'photon steps;',end-start,'in source window',flush=True)

if __name__=='__main__':
    for arg in sys.argv[1:]:transport(arg.removeprefix('pair-'),arg.startswith('pair-'))
