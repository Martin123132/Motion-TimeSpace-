import csv,re
from cell89 import ROOT,io,guard,MODES,BRANCHES,PREHASH,pin,np,json,digest
from score_cell_balance89 import SETTINGS
from scipy.interpolate import CubicSpline

def read(name):
    with (ROOT/name).open() as fp:return list(csv.DictReader(fp))

def verify():
    guard();checks=[]
    def require(name,condition):
        assert condition,name
        checks.append(name)
    for name in ('restore89.py','readout89.py','validation.json','RESULTS.md'):pin(name)
    for mode in MODES:
        for br in BRANCHES:
            with np.load(ROOT/f'cells-{mode}-{br}.npz') as src:
                time=src['eta'];difference=src['observed_change']-src['momentum_integral']
                require('endpoints: '+mode+br,np.array_equal(difference,src['signed_defect']) and np.array_equal(np.diff(src['endpoint_potential']),src['observed_change']) and np.allclose(difference,src['mean_defect']*np.diff(time),rtol=1e-12,atol=0) and np.isfinite(src['local_absolute_relative']).all() and np.all(np.diff(time)>0))
    stats=read('endpoint-statistics.csv')
    require('per cell half-percent outcome',len(stats)==6 and all(int(r['cells_over_half_pct_of_own_impulse'])==0 and float(r['local_pct_max'])<=.5 for r in stats))
    gates=read('gates.csv')
    require('all unique photon comparisons',len(set((r['mode'],r['setting'],r['cell'],r['term']) for r in gates))==36)
    for r in gates:
        require('unchanged acceptance '+str(list(r.values())[:4]),(r['rate_pass']=='True')==(max(float(r[k]) for k in ('energy_pct','current_pct','joint_pct'))<=.5) and (r['size_pass']=='True')==(max(float(r[k]) for k in ('momentum_launch_pct','differentiated_launch_pct'))<.163))
    with pin('photon-gates.csv').open() as fp:previous=list(csv.DictReader(fp))
    for r in previous:
        rows=[s for s in gates if s['term']=='saved_collocation' and all(r[k]==s[k] for k in ('mode','setting','cell'))]
        require('archived photon scores '+r['mode']+r['setting']+r['cell'],len(rows)==1 and all(abs(float(r[k])/float(rows[0][k])-1)<1e-8 for k in ('energy_pct','current_pct','joint_pct','momentum_launch_pct','differentiated_launch_pct')))
    for setting in SETTINGS:
        with np.load(ROOT/f'photons-{setting}.npz') as result:
            require(setting+' finite signed histories',result['values'].shape==(len(result['scale']),2,3,4,2) and np.isfinite(result['values']).all())
        require(setting+' moments',all(float(r['relative'])<.005 for prefix in ('quadrature','paired-quadrature') for r in read(prefix+'-'+setting+'.csv')))
    replay=read('replay.csv');require('separate wave, matched and signed photon replays',len(replay)==36 and all(max(float(r[k]) for k in ('energy','current','joint'))<.005 for r in replay))
    require('paired gravity clocks',len(read('paired-stats.csv'))==3 and all(float(r['relative_sum_error'])<.005 for r in read('paired-stats.csv')))
    paired=read('gravity-attribution.csv')
    require('independent propagated paired gravity differences',len(paired)==18 and all(float(r['max_component_closure'])<.005 for r in paired))
    controls=read('controls.csv')
    require('photon refinements and honest gravity outcomes',len(controls)==75 and all((r['passes']=='True')==(max(float(r[k]) for k in ('energy_relative','current_relative','joint_relative'))<=.005) for r in controls) and all(r['passes']=='True' for r in controls if r['test']!='gravity'))
    for code in ROOT.glob('*.py'):compile(code.read_bytes(),str(code),'exec')
    require('no temporary cache',not (ROOT/'__pycache__').exists())
    for note in ROOT.glob('*.md'):
        for link in re.findall(r'\]\(([^)]+)\)',note.read_text(encoding='utf-8')):require('link '+link,(ROOT/link).is_file())
    io.record('validation.json',dict(integrity_pass=True,photon_rate_agreement=False,photon_size_pass=True,checks=checks))
    seal=ROOT/'seal.json';files={p.name:digest(p) for p in sorted(ROOT.iterdir()) if p.is_file() and p!=seal}
    io.record('seal.json',dict(files=files,prior=PREHASH))
    print(len(checks),'integrity checks;',len(files),'files; seal',digest(seal))
if __name__=='__main__':verify()
