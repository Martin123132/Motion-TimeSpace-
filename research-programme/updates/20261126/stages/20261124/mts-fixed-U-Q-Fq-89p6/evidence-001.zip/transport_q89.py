from fixed89 import ROOT,US,io,previous,archived,checked,guard,packet,MODES,CELLS,np,sys,json,patch,digest
checked('photon_gate_89.py')
import photon_gate_89 as gate
SETTINGS=('primary','time','angle')
def photons():
    guard()
    grid,eta,medium,_,_=gate.proj.measure('heavy')
    with np.load(io.old.pin('photon-accumulated-heavy.npz')) as heavy,np.load(io.old.pin('photon-accumulated-cold.npz')) as cold:
        assert np.array_equal(grid,heavy['scale']) and np.array_equal(grid,cold['scale'])
        wave=float(heavy['k'])
    hist={}
    for mode in MODES:
        for cell in CELLS:
            with np.load(packet(cell,mode,'curves')) as saved:
                hist[mode,'primary' if cell=='base' else cell]={key:saved[key] for key in ('eta','delta_pd','delta_psi','delta_differentiated','kick')}
    with patch.object(gate.transfer,'ps',gate.Interface()):
        for setting in SETTINGS:
            response=gate.transfer.transfer(setting,eta,grid,medium,wave,hist)
            with np.load(archived('photon-'+setting+'.npz')) as base:
                for mode in MODES:
                    old=base['values'][:,base['inputs'].tolist().index([mode,'primary'])]
                    now=response[:,list(hist).index((mode,'primary'))]
                    assert np.max(abs(now-old))/np.max(abs(old))<1e-10
            io.pack('photon-'+setting+'.npz',grid=grid,labels=list(hist),channels=['kick','rate','lapse','differentiated'],values=response)
            print(setting,'all four photon routes complete',flush=True)

def differences(mode):
    guard()
    toolkit=previous.LEDGER
    source=toolkit/'matched_ledger89.py'
    assert digest(source)==json.loads((toolkit/'seal.json').read_bytes())['files'][source.name]
    sys.path.insert(0,str(toolkit))
    import matched_ledger89 as tr
    io.ROOT=ROOT
    terms={}
    with np.load(packet('base',mode,'ledger')) as base:
        keys=base['keys'].tolist();clock=base['eta'];hub=base['hub'][:,0]
        rate0=base['residual'][:,:,0];total0=base['total'][:,0]
        iq,ifi=keys.index('Q'),keys.index('Fq')
        remaining=[i for i,key in enumerate(keys) if key not in ('U','Q','Fq')]
        for cell in ('Q','Fq','both'):
            with np.load(packet(cell,mode,'ledger')) as out:
                assert np.array_equal(clock,out['eta'])
                parts=out['residual'][:,:,0]-rate0
                total=out['total'][:,0]-total0
                direct_q=hub*(out['slip'][iq,:,0]-base['slip'][iq,:,0])
                direct_f=-(out['pd'][ifi,:,0]-base['pd'][ifi,:,0])
                roundoff=128*np.finfo(float).eps*max(abs(base['pd'][iq,:,0]).max(),abs(out['pd'][iq,:,0]).max())
                assert np.max(abs(direct_q-parts[iq]))<=roundoff and np.array_equal(direct_f,parts[ifi])
                terms[cell+':Q']=direct_q;terms[cell+':Fq']=direct_f
                terms[cell+':state']=parts[remaining].sum(0);terms[cell+':total']=total
                assert np.max(abs(parts.sum(0)-total))<.005*np.max(abs(total0))
    assert np.array_equal(terms['both:Q'],terms['Q:Q']) and np.array_equal(terms['both:Fq'],terms['Fq:Fq'])
    assert not np.any(terms['Q:Fq']) and not np.any(terms['Fq:Q'])
    io.pack(f'difference-sources-{mode}.npz',eta=clock,keys=list(terms),values=np.stack(list(terms.values())))
    tr.transport(mode,'primary',clock,list(terms),np.column_stack(list(terms.values())))
if __name__=='__main__':
    for task in sys.argv[1:]:
        if task=='photons':photons()
        else:
            assert task in MODES;differences(task)
