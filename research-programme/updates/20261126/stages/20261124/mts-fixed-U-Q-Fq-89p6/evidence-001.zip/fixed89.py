from pathlib import Path
import hashlib
import json
import sys
from unittest.mock import patch
import numpy as np
from scipy.interpolate import make_interp_spline

ROOT=Path(__file__).resolve().parent
US=ROOT.parent/'mts-entry-spatial-U-89p6-20261124'
def digest(path):
    with path.open('rb') as source:return hashlib.file_digest(source,'sha256').hexdigest()
SEAL='48102b1a21cc2c87a8dd6e13475587dc4fddad31ef8cf039efb704d67dceaddb'
assert digest(US/'seal.json')==SEAL
manifest=json.loads((US/'seal.json').read_bytes())['files']
def archived(name):
    file=US/name
    assert digest(file)==manifest[name],name
    return file
sys.path.insert(0,str(US))
archived('spatial_io89.py')
import spatial_io89 as previous
from spatial_io89 import io,checked,SWITCH,END
previous.frozen()
assert digest(archived('frozen.json'))=='f63de5c7bb73df867f8640b86a22bb6fe8c33e3667faa84a61fcf4e28d86cb03'
io.ROOT=ROOT
MODES=('p16','p32')
CELLS={'base':(),'Q':('Q',),'Fq':('Fq',),'both':('Q','Fq')}
def guard():
    previous.guard()
    assert not (US/'STOP-REQUESTED').exists()
def array_hash(values):
    return hashlib.sha256(np.ascontiguousarray(values).tobytes()).hexdigest()
def packet(cell,mode,kind):
    assert cell in CELLS
    if kind=='ledger':
        return archived(f'ledger-{mode}-entry.npz') if cell=='base' else ROOT/f'ledger-{mode}-{cell}.npz'
    if kind=='curves':
        return archived(f'entry-curves-{mode}-companion.npz') if cell=='base' else ROOT/f'{cell}-curves-{mode}-companion.npz'
    raise ValueError(kind)
def replay_cell(mode,cell):
    guard()
    assert mode in MODES and cell in CELLS and cell!='base'
    checked('replay.py');checked('ledger.py')
    import replay
    original=replay.matter.get_flow
    with np.load(archived('primary.npz')) as data:
        restoration=make_interp_spline(np.log(data['eta']),data['restore'],k=5)
    audit={}
    def fixed(folder,case,clock,initial,projection=None):
        host=original(folder,case,clock,initial,projection)
        if projection is None:return host
        assert Path(folder)==Path(replay.matter.FLUID) and not audit
        donor=original(replay.matter.BASE89,case,clock,initial,projection)
        mainq,donorq=host.q,donor.q
        pick=[host.qkeys.index(k) for k in CELLS[cell]]
        sources=[donor.qkeys.index(k) for k in CELLS[cell]]
        ui=host.qkeys.index('U')
        def mixed(at):
            values=mainq(at).copy()
            values[...,ui,0]+=restoration(at)
            values[...,pick,:]=donorq(at)[...,sources,:]
            return values
        host.q=mixed
        at=host.log;raw=mainq(at);alt=donorq(at);used=mixed(at)
        expected=raw.copy();expected[:,ui,0]+=restoration(at)
        unchanged=[i for i in range(len(host.qkeys)) if i not in pick]
        assert np.array_equal(used[:,unchanged],expected[:,unchanged])
        assert np.array_equal(used[:,pick],alt[:,sources])
        statuses={}
        for key in ('Q','Fq'):
            idx=host.qkeys.index(key);other=alt[:,donor.qkeys.index(key)]
            statuses[key]=dict(host=array_hash(raw[:,idx]),donor=array_hash(other),used=array_hash(used[:,idx]),
                          relative_change_available=float(np.max(abs(other-raw[:,idx]))/np.max(abs(raw[:,idx]))))
        audit.update(mode=mode,cell=cell,swap=CELLS[cell],columns_checked=len(host.qkeys),samples=len(at),
                     forecast_packet=manifest['primary.npz'],U_hash=array_hash(used[:,ui]),U_equals_frozen_plus_host=True,
                     unchanged_columns_exact=True,receipt=statuses)
        return host
    with patch.object(replay.matter,'get_flow',fixed):
        replay.run(mode,cell,'matched')
    with np.load(packet('base',mode,'ledger')) as base,np.load(packet(cell,mode,'ledger')) as run:
        keys=run['keys'].tolist();idx=keys.index('U')
        assert np.array_equal(run['eta'],base['eta']) and np.array_equal(run['den'],base['den']) and np.array_equal(run['hub'],base['hub'])
        for key in ('phi','pd','residual'):
            assert np.array_equal(run[key][idx],base[key][idx]),key
        for name in ('Q','Fq'):
            if name not in CELLS[cell]:
                assert np.array_equal(run['residual'][keys.index(name)],base['residual'][keys.index(name)])
    io.record(f'input-audit-{mode}-{cell}.json',audit)
    print(mode,cell,'fixed-U and swap audit verified',flush=True)
if __name__=='__main__':
    for mode in sys.argv[1:]:
        for cell in ('Q','Fq','both'):replay_cell(mode,cell)
