from fixed89 import packet,MODES,io,np,guard

def main():
    guard();rows=[]
    for mode in MODES:
        for original,added in [('base','Fq'),('Q','both')]:
            with np.load(packet(original,mode,'curves')) as first,np.load(packet(added,mode,'curves')) as second:
                for key in ('eta','phi','psi','derivative','e','j','stress','rest_state','kick','pre_phi','post_phi','pre_psi','post_psi'):
                    rows.append(dict(mode=mode,comparison=original+'->'+added,field=key,
                                identical=np.array_equal(first[key],second[key]),peak_difference=np.max(abs(first[key]-second[key]))))
            with np.load(packet(original,mode,'ledger')) as first,np.load(packet(added,mode,'ledger')) as second:
                only=first['keys'].tolist().index('Fq')
                for key in ('residual','phi','slip','pd'):
                    other=np.arange(len(first['keys']))!=only
                    rows.append(dict(mode=mode,comparison=original+'->'+added,field='all_non_Fq_'+key,
                                  identical=np.array_equal(first[key][other],second[key][other]),peak_difference=np.max(abs(first[key][other]-second[key][other]))))
    io.table('Fq-state-test.csv',rows)
    print(sum(r['identical'] for r in rows),'/',len(rows),'bit-identical')
if __name__=='__main__':main()
