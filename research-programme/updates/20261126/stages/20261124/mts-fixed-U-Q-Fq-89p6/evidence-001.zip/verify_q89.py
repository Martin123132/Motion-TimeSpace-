import csv
import re
from fixed89 import ROOT,US,SEAL,io,MODES,CELLS,archived,packet,np,json,digest,guard

def read(name):
    with (ROOT/name).open() as stream:return list(csv.DictReader(stream))
def main():
    guard(); checks=[]
    def require(key,ok):
        assert ok,key
        checks.append(key)
    for mode in MODES:
        audits={cell:json.loads((ROOT/f'input-audit-{mode}-{cell}.json').read_bytes()) for cell in ('Q','Fq','both')}
        require(mode+' U locked',len({a['U_hash'] for a in audits.values()})==1 and all(a['forecast_packet']==digest(archived('primary.npz')) and a['columns_checked']==57 and a['unchanged_columns_exact'] for a in audits.values()))
        for name in ('Q','Fq'):
            items=[(cell,a['receipt'][name]) for cell,a in audits.items()]
            require(mode+' '+name+' source swap',len({r['donor'] for _,r in items})==len({r['host'] for _,r in items})==1 and all(r['used']==r['donor' if name in CELLS[cell] else 'host'] and r['host']!=r['donor'] for cell,r in items))
        for cell in ('Q','Fq','both'):
            jun=json.loads((ROOT/f'{cell}-junction-{mode}-companion.json').read_bytes())
            require(mode+cell+' recoupling',all(jun['recoupling'][-1][key]<.005 for key in ('stress','metric','quadrature')) and max(jun['normal_energy_jump'],jun['normal_momentum_jump'])<.005)
    rows=read('photon-gates.csv');base=read('gap-explained.csv')
    require('all 24 full-window cells',len(rows)==24 and len({(r['mode'],r['cell'],r['setting']) for r in rows})==24)
    for row in rows:
        require('actual photon gates '+str((row['mode'],row['setting'],row['cell'])),
                (row['passes_rate']=='True')==(max(float(row[k]) for k in ('energy_pct','current_pct','joint_pct'))<=.5) and
                (row['passes_size']=='True')==(max(float(row[k]) for k in ('momentum_launch_pct','differentiated_launch_pct'))<.163))
    for mode in MODES:
        for setting in ('primary','time','angle'):
            points={r['term']:r for r in base if r['mode']==mode and r['setting']==setting}
            for channel in ('signed_joint','signed_energy','signed_current'):
                value=lambda key:float(points[key][channel])
                require(mode+setting+channel+' additive bookkeeping',abs(value('Q_order_average')+value('Fq_order_average')-value('both'))<1e-9 and abs(value('Q')+value('Fq')+value('interaction_removed')-value('both'))<1e-9)
    closures=read('difference-replay.csv')
    require('independent signed transports',len(closures)==12 and max(max(float(r[key]) for key in ('energy_over_gap','current_over_gap','joint_over_gap','peak_over_gap')) for r in closures)<.005)
    require('adjoint cross-check',len(read('photon-adjoint.csv'))==24 and max(float(r['relative']) for r in read('photon-adjoint.csv'))<.005)
    require('both metric launches and windows',len(read('metric-gates.csv'))==32 and all((r['passed']=='True')==(float(r['fraction'])<=.005) for r in read('metric-gates.csv')))
    require('Fq does not alter constraint-branch states',len(read('Fq-state-test.csv'))==68 and all(r['identical']=='True' for r in read('Fq-state-test.csv')))
    fractions=read('Fq-fraction-bound.csv')
    require('bounded fractional Fq replacement',len(fractions)==12 and all((r['cannot_pass']=='True')==(max(float(r[key]) for key in ('energy_lower_pct','current_lower_pct','joint_lower_pct'))>.5) for r in fractions))
    for note in ROOT.glob('*.md'):
        for link in re.findall(r'\]\(([^)]+)\)',note.read_text(encoding='utf-8')):
            require('link '+link,(ROOT/link).is_file())
    for code in ROOT.glob('*.py'):compile(code.read_bytes(),str(code),'exec')
    io.record('validation.json',dict(checks=checks,passed=True))
    seal=ROOT/'seal.json'; files={p.name:digest(p) for p in sorted(ROOT.iterdir()) if p.is_file() and p!=seal}
    if seal.exists():assert files==json.loads(seal.read_bytes())['files']
    else:io.record('seal.json',dict(files=files,prior=SEAL))
    print(len(checks),'integrity checks;',len(files),'verified files; seal',digest(seal))
if __name__=='__main__':main()
