from scipy.interpolate import CubicSpline
from transport_q89 import ROOT,io,MODES,SETTINGS,gate,np,guard

def main():
    guard()
    _,axis,weights,_=gate.proj.old.get_media()
    measure=gate.previous.make_measure(axis,weights)
    mag=lambda v:gate.mag(v,measure)
    rows=[]
    for setting in SETTINGS:
        with np.load(ROOT/f'photon-{setting}.npz') as src:
            grid=src['grid'];values=src['values'];labels=src['labels'].tolist()
            def vec(mode,cell):
                full=values[:,labels.index([mode,cell])]
                return tuple(CubicSpline(grid,v)(axis) for v in (full[:,:3].sum(1),full[:,[0,3,2]].sum(1)))
            for mode in MODES:
                for at0,at1 in [('primary','Fq'),('Q','both')]:
                    m0,d0=vec(mode,at0);m1,d1=vec(mode,at1);gap=d0-m0
                    pulse=m1-m0
                    assert max(mag(d1-d0)/mag(gap))<1e-8
                    lower=100*np.maximum(0,mag(gap)-mag(pulse))/(mag(m0)+mag(pulse))
                    rows.append(dict(mode=mode,setting=setting,Q_choice='host' if at0=='primary' else 'donor',
                                     change_norm_pct_gap=100*mag(pulse)[2]/mag(gap)[2],energy_lower_pct=lower[0],
                                     current_lower_pct=lower[1],joint_lower_pct=lower[2],cannot_pass=bool(max(lower)>.5)))
    io.table('Fq-fraction-bound.csv',rows)
    print([(r['mode'],r['Q_choice'],r['joint_lower_pct']) for r in rows if r['setting']=='primary'])
if __name__=='__main__':main()
