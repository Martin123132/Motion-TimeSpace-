import csv
from scipy.interpolate import CubicSpline
from transport_q89 import ROOT,US,io,archived,guard,packet,MODES,CELLS,SETTINGS,gate,np,json,digest

def main():
    guard()
    _,axis,weights,_=gate.proj.old.get_media()
    measure=gate.previous.make_measure(axis,weights)
    mag=lambda v:gate.mag(v,measure)
    def share(vec,ref):
        val=measure@(ref.conj()*vec).real
        return np.r_[val,val.sum()]/mag(ref)**2
    launches={r['gravity']:float(r['launch_norm']) for r in csv.DictReader(gate.pin(gate.FROZEN,'window-readouts.csv').open()) if r['output']=='joint' and r['model']=='MTS-minus-baseline'}
    prev=ROOT.parent/'mts-photon-rate-residual-attribution-89p6-20261124'
    assert digest(prev/'seal.json')=='0dec918ee446f14c2c5f0b8e1dfd0dc8fe9a361cece477e11ae4271f71c87c09'
    manifest=json.loads((prev/'seal.json').read_bytes())['files']
    gates=[];effects=[];branches=[];coupling=[];convergence=[];decomposed=[];closure=[];metrics=[]
    pools={};sizes={}
    for mode in MODES:
        for cell in CELLS:
            with np.load(packet(cell,mode,'ledger')) as data:
                for window,use in [('first_cycle',data['eta']<=89.24159032),('complete',np.ones(len(data['eta']),bool))]:
                    for seed in (0,1):
                        fraction=np.max(abs(data['total'][use,seed]))/np.max(abs(data['rate'][use,seed]))
                        metrics.append(dict(mode=mode,cell=cell,window=window,seed=seed,fraction=fraction,passed=bool(fraction<=.005)))
        for setting in SETTINGS:
            name='transport-'+setting+'.npz';assert digest(prev/name)==manifest[name]
            with np.load(ROOT/('photon-'+setting+'.npz')) as result,np.load(prev/name) as ref:
                grid=result['grid'];assert np.array_equal(grid,ref['grid'])
                curve=lambda x:CubicSpline(grid,x)(axis)
                negcols=[i for i,s in enumerate(ref['channels'].tolist()) if s.startswith('negative_reference_')]
                negref=curve(ref['values'][:,list(MODES).index(mode)][:,negcols].sum(1))
                labels=result['labels'].tolist();stored=result['values']
                gap={};mom={};diff={};rawgap={}
                for cell in CELLS:
                    col=labels.index([mode,'primary' if cell=='base' else cell])
                    vals=stored[:,col];mom[cell]=curve(vals[:,:3].sum(1))
                    diff[cell]=curve(vals[:,[0,3,2]].sum(1))
                    rawgap[cell]=vals[:,3]-vals[:,1]
                    gap[cell]=curve(rawgap[cell]);assert max(mag(gap[cell]-(diff[cell]-mom[cell]))/mag(gap[cell]))<1e-7
                start=gap['base'];size=mag(start);den=mag(mom['base'])
                sizes[mode,setting]=size
                for cell in CELLS:
                    pct=100*mag(gap[cell])/mag(mom[cell])
                    pm=100*mag(mom[cell])/launches[mode];pd=100*mag(diff[cell])/launches[mode]
                    gates.append(dict(mode=mode,setting=setting,cell=cell,energy_pct=pct[0],current_pct=pct[1],joint_pct=pct[2],
                                      common_den_joint_pct=100*mag(gap[cell])[2]/den[2],passes_rate=bool(max(pct)<=.5),
                                      momentum_launch_pct=pm[2],differentiated_launch_pct=pd[2],passes_size=bool(max(pm[2],pd[2])<.163)))
                    matched=gap[cell]-negref
                    branches.append(dict(mode=mode,setting=setting,cell=cell,matched_pct_common=100*mag(matched)[2]/den[2],
                                    signed_reference_pct_common=100*mag(negref)[2]/den[2],matched_share=share(matched,gap[cell])[2],
                                    negative_reference_share=share(negref,gap[cell])[2]))
                    pools[mode,setting,'momentum:'+cell]=mom[cell]
                    pools[mode,setting,'gap:'+cell]=gap[cell]
                changes={cell:curve(rawgap['base']-rawgap[cell]) for cell in ('Q','Fq','both')}
                inter=changes['both']-changes['Q']-changes['Fq']
                paths={**changes,'interaction_removed':inter,'Q_after_Fq':changes['both']-changes['Fq'],
                       'Fq_after_Q':changes['both']-changes['Q'],'Q_order_average':changes['Q']+.5*inter,'Fq_order_average':changes['Fq']+.5*inter}
                for label,val in paths.items():
                    frac=share(val,start);res=mag(start-val)/size;length=mag(val)/size
                    effects.append(dict(mode=mode,setting=setting,term=label,signed_energy=frac[0],signed_current=frac[1],signed_joint=frac[2],
                                        magnitude_over_gap=length[2],norm_reduction=1-res[2],remaining_common_pct=100*mag(start-val)[2]/den[2]))
                    pools[mode,setting,'removed:'+label]=val
                coupling.append(dict(mode=mode,setting=setting,interaction_over_gap=mag(inter)[2]/size[2],
                                direct_addition_closure=mag(gap['both']-(start-changes['Q']-changes['Fq']-inter))[2]/size[2]))
                if setting=='primary':
                    with np.load(ROOT/f'responses-{mode}-primary.npz') as audit:
                        assert np.array_equal(grid,audit['grid']) and audit['windows'].tolist()==['post_cycle_interior','complete']
                        terms=audit['labels'].tolist();values=audit['values']
                        for cell in ('Q','Fq','both'):
                            test=changes[cell]
                            for wi,win in enumerate(audit['windows'].tolist()):
                                for name0 in ('Q','Fq','state','total'):
                                    raw=-values[:,wi,terms.index(cell+':'+name0)]
                                    vector=curve(raw)
                                    decomposed.append(dict(mode=mode,cell=cell,window=win,source=name0,share_initial_gap=share(vector,start)[2],
                                                        share_cell_change=share(vector,test)[2],magnitude_over_gap=mag(vector)[2]/size[2]))
                            rawtarget=rawgap['base']-rawgap[cell]
                            for label,items in [('direct_difference',['total']),('signed_ledger_sum',['Q','Fq','state'])]:
                                raw=-sum(values[:,1,terms.index(cell+':'+key)] for key in items)
                                e=mag(curve(raw-rawtarget))
                                peak=np.max(abs(raw-rawtarget))/np.max(abs(rawgap['base']))
                                closure.append(dict(mode=mode,cell=cell,test=label,energy_over_gap=e[0]/size[0],current_over_gap=e[1]/size[1],
                                                   joint_over_gap=e[2]/size[2],joint_over_cell_change=e[2]/mag(test)[2],peak_over_gap=peak))
                                assert max(*(e/size),peak)<.005,(cell,label,e/size,peak)
    for (mode,setting,label),val in pools.items():
        if setting!='primary':continue
        for tag,othermode,other in [('time',mode,'time'),('angle',mode,'angle')]+([('gravity','p16','primary')] if mode=='p32' else []):
            delta=mag(val-pools[othermode,other,label]);rel=delta/mag(val);gapref=delta/sizes[mode,setting]
            convergence.append(dict(mode=mode,term=label,test=tag,energy_over_term=rel[0],current_over_term=rel[1],joint_over_term=rel[2],
                                    joint_over_base_gap=gapref[2],term_pass=bool(max(rel)<=.005),base_gap_pass=bool(max(gapref)<=.005)))
    for name,rows in [('photon-gates',gates),('gap-explained',effects),('branch-separation',branches),('interaction',coupling),
                      ('direct-and-induced',decomposed),('difference-replay',closure),('numerical-controls',convergence),('metric-gates',metrics)]:
        io.table(name+'.csv',rows)
    print([r for r in gates if r['setting']=='primary'],flush=True)
if __name__=='__main__':main()
