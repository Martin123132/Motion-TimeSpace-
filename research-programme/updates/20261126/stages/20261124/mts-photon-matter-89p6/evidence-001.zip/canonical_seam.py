from capture89 import *
def main():
    guard()
    paths=sorted(HERE.glob('linear-heavy-??.npz'))
    assert len(paths)==len(list(csv.DictReader(pin('capture-heavy.csv').open())))
    rows=[]
    for idx,path in enumerate(paths):
        with np.load(path) as new,np.load(previous('material-halfstep/'+path.name)) as old:
            assert np.array_equal(new['k'],old['k']) and np.array_equal(new['keys'],old['keys']) and np.array_equal(new['values'][:,:17],old['values'][:,-17:])
            assert new['good'].all() and np.isfinite(new['values']).all()
            names=list(old['keys'])
            for key in ('etak','sigma','phi','clxg','qr','mts_dphi_h'):
                col=names.index(key);ref=old['values'][:,-9,col]
                rows.append(dict(block=idx,field=key,launch_norm_relative=np.linalg.norm(new['values'][:,8,col]-ref)/max(np.linalg.norm(ref),1e-200)))
    assert max(row['launch_norm_relative'] for row in rows)==0
    assert all((HERE/(key+'-heavy.npz')).is_file() for key in ('polar','output-native','background'))
    table('native-seam-heavy.csv',rows)
    print('canonical bank recovered from completed capture; overlap verified',len(rows))
if __name__=='__main__':main()
