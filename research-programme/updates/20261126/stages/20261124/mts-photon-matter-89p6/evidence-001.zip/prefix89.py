from transport89 import *
def sizing(values,measure):
    unit=measure @ abs(values)**2
    return np.sqrt(np.append(unit,unit.sum()))
def main():
    guard();_,axis,weight,_=proj.old.get_media();measure=previous.make_measure(axis,weight)
    rows=[];cases={};look={}
    with pin(FROZEN,'window-readouts.csv').open() as handle:
        for row in csv.DictReader(handle):look[row['model'],row['gravity']]=float(row['launch_norm'])
    for mode_index,mode in enumerate(MODES):
        for setting in ('primary','time','angle'):
            for model in previous.MODELS[:2]:
                with np.load(pin(FROZEN,f'fixed-plus-blocks-{model}.npz')) as fixed,np.load(HERE/f'photons-{model}.npz') as raw:
                    grid=raw['scale'];before=fixed['through83p2_'+mode]
                    early=raw[setting+'_early'][:,mode_index].sum(axis=1)
                    total=raw[setting][:,mode_index].sum(axis=1)
                    cases[model]=np.stack([before,before+early,before+total,total-early],axis=1)
            cases[previous.MODELS[-1]]=cases['heavy']-cases['cold']
            for model,values in cases.items():
                curve=CubicSpline(grid,values,axis=0)(axis)
                before,at89,at_end,late=[sizing(part,measure) for part in curve.transpose(1,0,2)]
                for idx,label in enumerate(previous.OUTPUTS):
                    scale=look[model,mode]
                    rows.append(dict(model=model,mode=mode,control=setting,output=label,before_pct=100*before[idx]/scale,to89_pct=100*at89[idx]/scale,through89p6_pct=100*at_end[idx]/scale,late_norm_pct=100*late[idx]/scale,through89_change_percent=100*(at89[idx]/before[idx]-1),minimum_control_to_matched_mismatch_to_erase_direction_pct_of_launch=100*abs(at_end[idx]-before[idx])/scale))
    table('canonical-source-split.csv',rows)
if __name__=='__main__':main()
