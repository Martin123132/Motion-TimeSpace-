from block import *
from capture89 import diag
from scipy.interpolate import CubicSpline

def main():
    guard()
    physical=ROOT/'material-halfstep';matched=ROOT/'matched-native'
    qa=json.loads((ROOT/'matching-validation.json').read_bytes())
    assert qa['passed']
    source=diag.native.SPEC/'runs/projection/a225-w6-d8.npz'
    assert digest(source)==qa['original_source']
    with np.load(source) as parent,np.load(ROOT/'canonical-input.npz') as canonical,np.load(ROOT/'exact-phase-extension.npz') as extension:
        assert all(np.array_equal(parent[key],canonical[key]) for key in canonical.files)
        assert set(parent.files)-set(canonical.files)=={'matching_scale','matching_density','modes','matching_delta','matching_momentum','projected_pressure','projection_norm','closure_error'}
        assert all(np.array_equal(extension[key],canonical[key]) for key in canonical.files)
    measured=[];before={};after={};examples=[]
    files=sorted(physical.glob('linear-heavy-??.npz'))+[physical/'output-native-heavy.npz']
    assert len(files)==len(list(csv.DictReader(pin('capture-heavy.csv').open())))+1
    for idx,path in enumerate(files):
        with np.load(path) as active,np.load(matched/path.name) as mean,np.load(physical/f'phase-audit-{idx:02}.npz') as aa,np.load(matched/f'phase-audit-{idx:02}.npz') as bb:
            assert np.array_equal(active['eta'],mean['eta']) and np.array_equal(active['k'],mean['k']) and np.array_equal(active['keys'],mean['keys'])
            assert np.array_equal(aa['t'],bb['t']) and np.array_equal(bb['t'],active['eta'][17:])
            on=bb['values'][:,:,0]==1
            assert np.all(np.diff(on.astype(int),axis=1)>=0) and np.all(~on[:,0]) and np.all(on[:,-1])
            assert not np.any(aa['values'][:,:,0])
            events=bb['values'][:,:,1][:,-1]
            measured.extend(events.tolist());names=list(active['keys'])
            plus=active['values'][:,17:];right=mean['values'][:,17:]
            earlier=(~on)&(aa['t'][None,:]>83.25); later=on&(aa['t'][None,:]<=89.6)
            for label in ('a','etak','sigma','phi','clxg','qr','mts_dphi_h','mts_dphidot_h'):
                col=names.index(label)
                for ledger,mask in ((before,earlier),(after,later)):
                    pair=ledger.setdefault(label,[0.,0.])
                    pair[0]=max(pair[0],float(max(abs((plus[:,:,col]-right[:,:,col])[mask]))))
                    pair[1]=max(pair[1],float(max(abs(plus[:,:,col][mask]))))
            assert (right[:,:,names.index('mts_dphi_h')][later]==0).all() and (right[:,:,names.index('mts_dphidot_h')][later]==0).all()
            assert np.max(abs(bb['values'][:,:,2][later]))>0 and np.max(abs(bb['values'][:,:,4][later]))>0
            if idx in (0,len(files)-1):
                examples.append(dict(file=path.name,k=float(active['k'][0]),switch_time=float(events[0]),canonical_dphi=float(plus[0,-9,names.index('mts_dphi_h')]),matched_raw_dphi=float(right[0,-9,names.index('mts_dphi_h')]),matched_density=float(bb['values'][0,-9,2]),matched_momentum=float(bb['values'][0,-9,4])))
    summary=dict(accepted_original_full_quadratic=False,canonical_is_separate=True,packets=len(files),k_rows=len(measured),min_switch=min(measured),max_switch=max(measured),matching_scale=qa['matching_scale'],control='max absolute raw difference / largest canonical value over comparison range; not pointwise ratios',before={key:pair[0]/pair[1] for key,pair in before.items()},after={key:pair[0]/pair[1] for key,pair in after.items()},witness=examples)
    record('switch-audit.json',summary)
    print('native heavy switch range',min(measured),max(measured),'pre-switch comparisons',summary['before'])

if __name__=='__main__':main()
