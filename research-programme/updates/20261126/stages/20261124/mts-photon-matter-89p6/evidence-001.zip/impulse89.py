from pathlib import Path
import csv
import hashlib
import io
import json
import sys

ROOT=Path(__file__).resolve().parent
PRE=ROOT.parent/'mts-64-to-peak-matter-bound-20261123'
PIN='34527715cc80011cc93b6c92b208e075c506cb468a6dfdedc6ba7c50076f6903'
def digest(path):
    with path.open('rb') as fp:return hashlib.file_digest(fp,'sha256').hexdigest()
assert digest(PRE/'seal.json')==PIN
manifest=json.loads((PRE/'seal.json').read_bytes())['files']
for source in ('saved_bridge.py','bridge64_inputs.py'):assert digest(PRE/source)==manifest[source]
sys.path.insert(0,str(PRE))
import saved_bridge as history
from bridge64_inputs import Medium,np,CubicSpline,brentq,make_interp_spline,parts,cumsum,z,limit_time
from scipy.integrate import simpson
PARENT=history.PARENT
assert PARENT.name=='mts-particular-gravity-64-tail-20261123'
MODELS=('cold','heavy')
CASES=(*MODELS,'paired')
def guard():
    history.guard();assert not (ROOT/'STOP-REQUESTED').exists()

def write(name,rows):
    guard();buf=io.StringIO();writer=csv.DictWriter(buf,rows[0],lineterminator='\n');writer.writeheader();writer.writerows(rows)
    path=ROOT/name;encoded=buf.getvalue().encode()
    if path.exists():assert path.read_bytes()==encoded,name
    else:
        with path.open('xb') as fp:fp.write(encoded)

from functools import lru_cache
from types import SimpleNamespace
EIGHT=ROOT.parent/'mts-physical-impulses-76p8-20261124'
SEVEN=ROOT.parent/'mts-physical-impulses-70p4-20261123'
FINE=ROOT.parent/'mts-gravity-p16-70p4-20261124'
PINS={EIGHT:'0d4b212a23c89a4442ebcec6c68d42e03902e2ab19c48e7abeb467f5981de2fc',SEVEN:'1dfc19700055fa4ccfe3fb67386f956c8bbcd216c904c72a1f178b833824ae1a',FINE:'a30c6a9168e8dfb20e86db29a8f7a40c02e8c15c4bdb31ac9d296bb5f05b2830',PRE:PIN}
def pinned(folder,name):
    manifest_file=folder/'seal.json'
    assert digest(manifest_file)==PINS[folder]
    path=folder/name
    assert digest(path)==json.loads(manifest_file.read_bytes())['files'][name]
    return path
def guard():
    history.guard();assert all(not (root/'STOP-REQUESTED').exists() for root in (ROOT,ROOT.parent,EIGHT,SEVEN,FINE,PARENT))
NINE=ROOT.parent/'mts-physical-impulses-83p2-20261124'
TOP=ROOT.parent/'mts-gravity-p32-83p2-20261124'
PINS.update({NINE:'e446924053253ca4c6d3b8c3a09f18f613ea5fed6afe2cf09a012a2c24626318',TOP:'828425a5eb89592c637b4120ea62aab5fb39566da54d605d73b2ec42f9cf0486'})
def split(med):
    cuts={model:med.root(model,83.2) for model in MODELS}
    start=min(cuts.values());switch=max(cuts.values())
    end=min(med.root(model,89.6) for model in MODELS)
    assert start<switch<end<med.am
    return start,switch,end,min(cuts,key=cuts.get)
@lru_cache(maxsize=8)
class Packet(history.Saved):
    def __init__(self,model,mode,prior):
        assert mode in ('p16','p32')
        self.model=model
        folder=NINE if prior else ROOT
        name=f'particular-{model}-{mode}.npz'
        reportname=f'metric-{model}-{mode}.json'
        if prior:
            source=TOP if mode=='p32' else NINE
            prefix='to83/' if mode=='p32' else ''
            save=pinned(source,prefix+name)
            report=json.loads(pinned(source,prefix+reportname).read_bytes())
            pinned(NINE,f'material-halfstep/forcing-{model}.npz')
        else:
            save=ROOT/name
            report=json.loads((ROOT/reportname).read_bytes())
            assert report['output_digest']==digest(save)
        assert report['passed']
        self.path=save
        with np.load(save) as raw:
            self.time=raw['eta'];wave=float(raw['k'][0]);obs=raw['obs'][:,:,0,0]
            assert np.array_equal(self.time[[0,-1]],([76.8,83.2] if prior else [83.2,89.6])) and len(raw['q'])==77
            fields={'Y':raw['psi'],'phi':raw['phi'],'pd':raw['phi_dot'],'L':obs[:,11],'F':obs[:,3]/self.time}
            assert np.allclose(fields['L'],fields['Y']-fields['phi'],atol=1e-25,rtol=1e-9)
        with np.load(folder/'material-halfstep'/f'forcing-{model}.npz') as src:
            bg=dict(zip(src['bgkeys'],src['background']));q=dict(zip(src['keys'],src['values']));log=np.log(src['eta'])
            for key,val in [('Fq',q['Fq'][:,0]),('Hm',bg['h'])]:
                fields[key]=make_interp_spline(log,val,k=5)(np.log(self.time))
        assert np.max(abs(fields['pd']+fields['F']+fields['Hm']*fields['Y']-fields['Fq']))<1e-9*np.max(abs(fields['pd']))
        self.curves={key:CubicSpline(self.time,val,extrapolate=False) for key,val in fields.items()}

def kernel(med,model,scale,target):
    native=med.native(model,scale);terminal=med.native(model,target)
    prim=med.primitive[model];gain=np.exp(prim(native)-prim(terminal))
    w=(scale/target)**2
    inside=med.grid[(med.grid>scale[0])&(med.grid<target)]
    edges=np.unique(np.r_[scale[0],inside,target]);dense=np.r_[np.linspace(edges[:-1],edges[1:],8,endpoint=False).T.ravel(),target]
    t=med.native(model,dense)
    value=np.exp(prim(t)-prim(terminal))*(scale[0]/dense)**2
    rev=cumsum(value[::-1],-t[::-1])[::-1]
    moment=CubicSpline(dense,rev,extrapolate=False)(scale)*(scale/scale[0])**2
    if scale[-1]==target:moment[-1]=0.
    return w,gain,moment

def relative(value,ref):return float(abs(value-ref)/max(abs(ref),1e-100))
def align(left,right):return float(np.real(left*np.conj(right))/(abs(left)*abs(right))) if abs(left)*abs(right)>0 else 0.

def intervals(med,mode,count):
    old={m:Packet(m,mode,True) for m in MODELS}
    new={m:Packet(m,mode,False) for m in MODELS}
    a0,switch,ae,first=split(med)
    assert a0<switch<ae<med.am
    inputs=({model:(new[model] if model==first else old[model]) for model in MODELS},new)
    native=[np.linspace(a0,switch,33),np.linspace(switch,ae,count)]
    left=history.branches(med,old,a0)
    starts={key:{name:left[key][name] for name in ('C','Y','L')} for key in CASES}
    gate=[];sums={};checks=[];endpoint={}
    for scale,cases in zip(native,inputs):
        guard();s=med.native('heavy',scale);values=history.branches(med,cases,scale)
        for name,row in values.items():
            m=name if name!='paired' else 'heavy'
            prev=left[name];dC=row['C'][0]-prev['C'];dY=row['Y'][0]-prev['Y']
            reference=row['refC']
            gate.append(dict(mode=mode,model=name,at_heavy_mpc=s[0],complex_C_jump=abs(dC),complex_Y_jump=abs(dY),
                C_relative_jump=abs(dC)/max(abs(prev['C']),1e-100),Y_relative_jump=abs(dY)/max(abs(prev['Y']),1e-100),
                source_identity=np.max(abs(row['C']-reference))/np.max(abs(reference))))
            for target,label in ((ae,'block end'),(med.am,'priority midpoint')):
                wc,gy,tc=kernel(med,m,scale,target)
                clock_work=row['V']-( (cases['heavy'].state(med,scale)['V']-cases['cold'].state(med,scale)['V']) if name=='paired' else row['V'])
                integral=lambda vec:simpson(vec,x=s)
                direct=np.array([integral(wc*row['P']),integral(tc*row['P']),integral(gy*row['V'])])
                boundary=lambda signal:signal[-1]-signal[0]
                integrated=np.array([boundary(wc*reference),
                    boundary(tc*reference)+integral(gy*row['r']*reference),
                    boundary(gy*row['L'])+integral(gy*(clock_work-row['r']*row['H']*row['L']))])
                jumps=np.array([wc[0]*dC,tc[0]*dC,gy[0]*dY])
                key=name,label
                if key not in sums:sums[key]=[np.zeros(3,complex) for _ in range(3)]+[0j]
                for pile,increment in zip(sums[key][:3],(direct,integrated,jumps)):pile+=increment
                sums[key][3]+=integral(gy*clock_work)
            endpoint[name]={col:row[col][-1] for col in ('C','Y','L')}
        left={key:{col:row[col][-1] for col in ('C','Y','L')} for key,row in values.items()}
    rows=[]
    for (name,label),(direct,ibp,jumps,mismatch) in sums.items():
        m='heavy' if name=='paired' else name;target=ae if label=='block end' else med.am
        wc,gy,tc=kernel(med,m,np.array([a0,ae]),target)
        memC=wc[0]*starts[name]['C'];memY=gy[0]*starts[name]['Y']+tc[0]*starts[name]['C']
        endC=wc[1]*endpoint[name]['C'];endY=gy[1]*endpoint[name]['Y']+tc[1]*endpoint[name]['C']
        netC,netY=ibp[0],ibp[1]+ibp[2]
        for ix,channel in enumerate(('current','current to lapse','shear and clock to lapse')):
            checks.append(dict(mode=mode,model=name,target=label,test='derivative vs parts: '+channel,relative_error=relative(direct[ix],ibp[ix])))
        for channel,ref,carried,measured,jump in [('current',endC,memC,netC,jumps[0]),('lapse',endY,memY,netY,jumps[1:].sum())]:
            checks.append(dict(mode=mode,model=name,target=label,test='reconstruct endpoint: '+channel,relative_error=relative(carried+measured+jump,ref)))
        rows.append(dict(mode=mode,model=name,target=label,covered_until_heavy=med.native('heavy',ae),**parts('I_C',netC),
            **parts('I_Y_current',ibp[1]),**parts('I_Y_shear',ibp[2]-mismatch),**parts('I_Y_clock',mismatch),**parts('I_Y',netY),
            **parts('carried_C',memC),**parts('carried_Y',memY),**parts('seam_C',jumps[0]),**parts('seam_Y',jumps[1:].sum()),
            **parts('remaining_center_C',-endC),**parts('remaining_center_Y',-endY),
            remaining_C_over_initial=abs(endC)/abs(memC),remaining_Y_over_initial=abs(endY)/abs(memY),
            C_work_alignment_to_cancellation=align(netC,-memC),Y_work_alignment_to_cancellation=align(netY,-memY)))
    return rows,checks,gate
