import capture89 as local
from block import *

def main():
    guard()
    source=ROOT.parent/'matched-native'; paths=sorted(source.glob('linear-heavy-??.npz'))+[source/'output-native-heavy.npz']
    assert len(paths)==1+len(list(csv.DictReader(pin('capture-heavy.csv').open())))
    for idx,path in enumerate(paths):
        with np.load(source/f'phase-audit-{idx:02}.npz') as audit:
            assert not np.any(audit['values'][:,audit['t']<=89.05,0])
            assert np.all(audit['values'][:,-1,0]==1)
        with np.load(path) as full:
            data=dict(full.items())
        cut=np.flatnonzero(data['eta']<=89.05)
        assert len(cut)==945 and data['eta'][cut[-1]]==89.05
        data['eta']=data['eta'][cut];data['values']=data['values'][:,cut]
        if 'good' in data:data['good']=data['good'][:,cut]
        local.pack(path.name,**data)
    for kind in ('background','polar'):
        with np.load(source/f'{kind}-heavy.npz') as full:
            payload={key:(value[...,cut] if value.ndim>0 and value.shape[-1]==1041 else value) for key,value in full.items()}
            assert len(payload['eta'])==945
        local.pack(f'{kind}-heavy.npz',**payload)
    for mode in ('p16','p32'):
        path=ROOT.parent/f'particular-cold-{mode}.npz'
        parent=json.loads((ROOT.parent/f'metric-cold-{mode}.json').read_bytes())
        assert parent['passed'] and parent['output_digest']==digest(path)
        with np.load(path) as cold:
            keys=('eta','a','obs','phi','psi','phi_dot')
            keep=cold['eta']<=89.
            payload={key:cold[key][keep] for key in keys}
            assert payload['eta'][-1]==89.
            pack(path.name,**payload,k=cold['k'],q=cold['q'])
        record(f'metric-cold-{mode}.json',dict(passed=True,kind='time slice of verified cold trajectory; source readout only, not a matter restart',parent=digest(path),output_digest=digest(ROOT/path.name)))
    record('prefix-inputs.json',dict(end=89.,padded_end=89.05,prior=83.2,raw='matched-native',all_padded_samples_pre_match=True,pressure_limit=.000002))
    print('Original matched prefix, including padding, precedes every actual switch.',flush=True)
if __name__=='__main__':main()
