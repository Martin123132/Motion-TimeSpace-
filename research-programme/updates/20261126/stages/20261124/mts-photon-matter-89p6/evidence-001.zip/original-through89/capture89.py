from block import *
HERE=ROOT/'material-halfstep'
HERE.mkdir(exist_ok=True)
def save(name,data):
    import block
    block.save('material-halfstep/'+name,data)
def pack(name,**fields):
    stream=io.BytesIO();np.savez_compressed(stream,**fields);save(name,stream.getvalue())
def table(name,rows):
    writer=io.StringIO();out=csv.DictWriter(writer,rows[0],lineterminator='\n');out.writeheader();out.writerows(rows);save(name,writer.getvalue().encode())
