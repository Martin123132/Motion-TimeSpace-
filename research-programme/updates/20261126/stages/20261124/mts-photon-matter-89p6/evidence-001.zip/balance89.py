from impulse89 import *
LIMIT=.005
def read(path):
    with path.open(newline='') as stream:return list(csv.DictReader(stream))
def rate(med,mode,nodes):
    old,new=({model:Packet(model,mode,prior) for model in MODELS} for prior in (True,False))
    cut,switch,end,first=split(med)
    mixed={model:new[model] if model==first else old[model] for model in MODELS}
    totals={}
    for lo,hi,fields,count in [(cut,switch,mixed,33),(switch,end,new,nodes)]:
        guard()
        scale=np.linspace(lo,hi,count)
        clock=med.native('heavy',scale)
        fields_at={}
        for model,entry in fields.items():
            t,ratio,_,_=med.coord(scale,model)
            t=limit_time(t,entry.time)
            fields_at[model]=np.array([entry.curves['phi'](t),ratio*entry.curves['phi'](t,1),ratio*entry.curves['pd'](t)])
        fields_at['paired']=fields_at['heavy']-fields_at['cold']
        for name,(phi,slope,rate) in fields_at.items():
            model='heavy' if name=='paired' else name
            time,ratio,hub,_=med.coord(scale,model)
            gain=np.exp(med.primitive[model](time)-med.primitive[model](med.native(model,med.am)))
            direct=simpson(gain*(slope-rate),x=clock)
            boundary=gain[-1]*phi[-1]-gain[0]*phi[0]
            independent=boundary-simpson(gain*(ratio*hub*phi+rate),x=clock)
            key=name
            totals[key]=totals.get(key,np.zeros(2,complex))+np.array([direct,independent])
    return totals


def peak_norm(arr):
    return float(np.max(abs(arr)))
def trajectory(med):
    tests=[]
    for prior in (False,):
        block='83.2 to 89.6'
        data={}
        for mode in ('p16','p32'):
            cases={model:Packet(model,mode,prior) for model in MODELS}
            lo,hi=med.both({name:entry.time for name,entry in cases.items()})
            scale=np.linspace(lo,hi,16385)
            rows=history.branches(med,cases,scale)
            metrics={}
            for name,entry in cases.items():
                time=limit_time(med.native(name,scale),entry.time)
                phi=entry.curves['phi']
                metrics[name]=[phi(time),entry.curves['pd'](time),phi(time,1)]
            metrics['paired']=np.array(metrics['heavy'])-np.array(metrics['cold'])
            for name,row in rows.items():
                phi,rate,derivative=metrics[name]
                data[mode,name]=[phi,row['Y'],rate,row['C'],row['refCp'],row['refYp']]
                error=peak_norm(derivative-rate)/peak_norm(rate)
                tests.append(dict(block=block,model=name,test=mode+' derivative vs constraint',relative_error=error,passed=error<=LIMIT))
        for name in CASES:
            for field,low,high in zip(('phi','lapse','phi_dot','C','C slope','Y slope'),data['p16',name],data['p32',name]):
                error=peak_norm(high-low)/peak_norm(high)
                tests.append(dict(block=block,model=name,test='p16 to p32: '+field,relative_error=error,passed=error<=LIMIT))
    return tests
