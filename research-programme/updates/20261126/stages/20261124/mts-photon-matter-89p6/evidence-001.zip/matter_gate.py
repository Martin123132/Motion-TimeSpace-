from balance89 import trajectory,rate
from inside89 import profiles
from impulse89 import *
def record_local(name,body):
    guard()
    assert not any((folder/'STOP-REQUESTED').exists() for folder in (ROOT,ROOT.parent,TOP,NINE))
    data=(json.dumps(body,indent=2,sort_keys=True,allow_nan=False)+'\n').encode()
    path=ROOT/name
    if path.exists():assert path.read_bytes()==data
    else:
        with path.open('xb') as stream:stream.write(data)

def read(path):
    with path.open(newline='') as handle:
        return list(csv.DictReader(handle))

def main():
    guard(); med=Medium()
    radii={key:float(row['radius']) for key,row in zip(('C','Y'),read(pinned(PRE,'required-signed-impulses.csv')),strict=True)}
    prior=read(pinned(TOP,'cut-centers.csv'))
    profiles_by_mode={}; efforts={}; checks=[]
    def add(mode,name,field,test,value,limit=.005):
        checks.append(dict(mode=mode,model=name,field=field,test=test,error=float(value),limit=limit,passed=bool(np.isfinite(value) and value<=limit)))
    for row in trajectory(med):
        add('trajectory',row['model'],'trajectory',row['test'],row['relative_error'])
    for mode in ('p16','p32'):
        work,tests,seams=intervals(med,mode,65537)
        coarse=intervals(med,mode,32769)[0]
        efforts[mode]=work
        write(f'work-{mode}.csv',work)
        write(f'seams-{mode}.csv',seams)
        for row in tests:
            add(mode,row['model'],row['target'],row['test'],row['relative_error'])
        for row,control in zip(work,coarse,strict=True):
            for field in ('I_C','I_Y_current','I_Y_shear','I_Y','remaining_center_C','remaining_center_Y'):
                add(mode,row['model'],field,'target-grid '+row['target'],relative(z(control,field),z(row,field)))
        profile=profiles(med,mode,65537); half=profiles(med,mode,32769)
        profiles_by_mode[mode]=profile
        rate_fine=rate(med,mode,65537);rate_coarse=rate(med,mode,32769)
        for name in CASES:
            item=next(row for row in work if row['model']==name and row['target']=='priority midpoint')
            direct,independent=rate_fine[name]
            defect=-z(item,'remaining_center_Y')-z(item,'carried_Y')-z(item,'I_Y')-z(item,'seam_Y')
            for key,value in [('by parts',direct-independent),('rate quadrature',direct-rate_coarse[name][0]),('endpoint closure',defect-direct)]:
                add(mode,name,'lapse',key+' in radii',abs(value)/radii['Y'])
            for field in ('C','Y'):
                start=z(item,'carried_'+field);end=-z(item,'remaining_center_'+field)
                earlier=next(row for row in prior if (row['stage'],row['model'],row['field'])==('to83',name,field))
                add(mode,name,field,'old cut match in radii',abs(start+z(earlier,mode+'_center'))/radii[field])
                clock,curve=profile[name,field];sample=abs(curve);thin=abs(half[name,field][1])
                for key,value in [('initial value',abs(start-curve[0])/radii[field]),('final value',abs(end-curve[-1])/radii[field]),('sampled min change',abs(min(sample)-min(thin))/abs(start)),('sampled max change',abs(max(sample)-max(thin))/abs(start))]:
                    add(mode,name,field,key,value)
    for low,high in zip(efforts['p16'],efforts['p32'],strict=True):
        for field in ('I_C','I_Y_current','I_Y_shear','I_Y','remaining_center_C','remaining_center_Y'):
            add('steps',high['model'],field,high['target'],relative(z(low,field),z(high,field)))
    caps=[]
    for field in ('C','Y'):
        clock,top=profiles_by_mode['p32']['paired',field];other,bottom=profiles_by_mode['p16']['paired',field]
        assert np.array_equal(clock,other)
        shift=abs(top-bottom)/radii[field];index=int(shift.argmax())
        caps.append(dict(field=field,radius=radii[field],start=shift[0],end=shift[-1],maximum=shift[index],where_heavy=clock[index]))
        add('steps','paired',field,'endpoint absolute allowance',shift[-1],1.)
        add('steps','paired',field,'interior absolute allowance',shift[index],1.)
    write('matter-checks.csv',checks);write('absolute-allowances.csv',caps)
    failed=[row for row in checks if not row['passed']]
    record_local('matter-validation.json',dict(tolerance=.005,passed=not failed,count=len(checks),failures=failed,allowances=caps,heavy_route='canonical control; same physical background tables, heavy field kept explicit across the averaging event',matched_quadratic_verified=False))
    print('Matter tests',len(checks),'failures',failed,'allowances',caps,flush=True)

if __name__=='__main__':main()
