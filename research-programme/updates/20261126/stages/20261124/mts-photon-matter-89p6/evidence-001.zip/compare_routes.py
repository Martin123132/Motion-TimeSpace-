import csv
import json
from transport89 import HERE, FROZEN, MODES, pin, np, proj, guard, record, table, previous, CubicSpline

def read(path):
    with path.open(newline='') as handle:return list(csv.DictReader(handle))
def mag(values,weight):
    power=weight @ abs(values)**2
    return np.sqrt(np.append(power,power.sum()))
def main():
    guard()
    safe=HERE/'original-through89'
    assert json.loads((safe/'prefix-inputs.json').read_bytes())['all_padded_samples_pre_match']
    switch=json.loads((HERE/'switch-audit.json').read_bytes())
    assert 89.05<switch['min_switch']<=switch['max_switch']<89.6
    _,axis,weights,_=proj.old.get_media();measure=previous.make_measure(axis,weights)
    ref={(row['model'],row['gravity'],row['output']):row for row in read(pin(FROZEN,'window-readouts.csv'))}
    checks=[];rows=[]
    for idx,mode in enumerate(MODES):
        values={}
        for model in previous.MODELS[:2]:
            with np.load(HERE/f'photons-{model}.npz') as root,np.load(safe/f'photons-{model}.npz') as prefix,np.load(pin(FROZEN,f'fixed-plus-blocks-{model}.npz')) as old:
                grid=old['scale'];assert np.array_equal(grid,root['scale']) and np.array_equal(grid,prefix['scale'])
                values[model]=np.stack([old['through83p2_'+mode],prefix['primary'][:,idx].sum(axis=1),root['primary_early'][:,idx].sum(axis=1),root['primary'][:,idx].sum(axis=1)],axis=1)
        values[previous.MODELS[-1]]=values['heavy']-values['cold']
        for model,entry in values.items():
            entering,safe_part,control_part,control4=CubicSpline(grid,entry,axis=0)(axis).transpose(1,0,2)
            launch=float(ref[model,mode,'joint']['launch_norm'])
            start=mag(entering,measure);partial=mag(entering+safe_part,measure);conditional=mag(entering+control4,measure)
            control_late=mag(control4-control_part,measure)
            mismatch=mag(safe_part-control_part,measure)
            for oi,label in enumerate(previous.OUTPUTS):
                for quantity,denominator in [('early block',mag(safe_part,measure)),('accumulated to 89',partial)]:
                    error=mismatch[oi]/denominator[oi]
                    checks.append(dict(model=model,mode=mode,output=label,quantity=quantity,relative_error=error,passed=bool(error<=.005)))
                rows.append(dict(model=model,mode=mode,output=label,original_start_pct=100*start[oi]/launch,original_at89_pct=100*partial[oi]/launch,canonical_at89p6_pct=100*conditional[oi]/launch,minimum_remaining_response_for_return_to_83p2_pct_of_launch=100*abs(start[oi]-partial[oi])/launch,conditional_last_0p6_response_pct=100*control_late[oi]/launch,original_change_to89_percent=100*(partial[oi]/start[oi]-1),canonical_change_to89p6_percent=100*(conditional[oi]/start[oi]-1),full_matched_heavy_result='not determined'))
    table('original-vs-control.csv',rows);table('pre-switch-comparisons.csv',checks)
    available=json.loads((safe/'window-validation.json').read_bytes())
    record('route-validation.json',dict(pre_switch_comparisons=len(checks),pre_switch_agreement=all(row['passed'] for row in checks),worst=max(checks,key=lambda row:row['relative_error']),original_to89_gates=available['control_passed'],canonical_to89p6_gates=json.loads((HERE/'window-validation.json').read_bytes())['control_passed'],original_to89p6_verified=False))
if __name__=='__main__':main()
