from capture89 import diag,checked,pin as capture_pin
from block import *
import math
from pathlib import Path

native=diag.native
SPEC=native.SPEC
sys.path.insert(0,str(SPEC))
import project_grid as projection

def main():
    guard()
    original=SPEC/'runs/projection/a225-w6-d8.npz'
    exact_status=json.loads((SPEC/'runs/exact-grid/status.json').read_bytes())
    proj_status=json.loads((SPEC/'runs/projection/status.json').read_bytes())
    expected=json.loads(native.source('runs/heavy/status.json').read_bytes())['source_hash']
    assert digest(original)==expected and digest(original)==proj_status['input_hashes'][str(original)]
    assert digest(SPEC/'project_grid.py')==proj_status['script_sha256']
    for path in [projection.BACKGROUND,projection.EARLY/'runs/final-bg8-start/heavy.npz',SPEC/'spectrum_common.py',*native.engine.inherited.native_hashes()]:
        assert exact_status['input_hashes'][str(path)]==digest(path)
    with np.load(checked('forcing-heavy.npz')) as data:
        modes=np.unique(np.r_[data['nodes'],data['k']])
    with capture_pin('capture-heavy.csv').open() as handle:
        rows=list(csv.DictReader(handle))
    needed=np.unique(np.r_[modes,[float(row['control']) for row in rows],[float(row['hierarchy_cap']) for row in rows]])
    with np.load(original) as raw: bank=dict(raw.items())
    available=bank['modes']
    missing=needed[np.min(abs(needed[:,None]/available-1),axis=1)>=1e-12]
    assert len(missing)>0 and np.all(np.diff(missing)>0)
    with np.load(projection.EARLY/'runs/final-bg8-start/heavy.npz') as old:requested=old['requested_scale']
    with np.load(projection.BACKGROUND) as bg: phase=dict(bg.items())
    center=float(bank['matching_scale']);density=float(bank['matching_density'])
    runtime=native.engine.inherited.params_for(projection.BACKGROUND)
    background=native.engine.camb.get_background(runtime)
    clock=background.conformal_time(1/requested-1,tol=1e-10)
    background.Params.Accuracy.IntTolBoost=6
    names=['a','H','mts_drho_h','mts_q_h','mts_dp_h','mts_match_count']
    assert set(names)<=set(native.engine.camb.model.evolve_names)
    combined=[];qa=[]
    for number,start in enumerate(range(0,len(missing),16)):
        guard()
        wanted=missing[start:start+16]
        ref=int(np.argmin(abs(available-np.median(wanted))))
        nodes=np.unique(np.r_[wanted,available[ref]])
        path=ROOT/f'local-match-{number:03}.npz'
        if not path.exists():
            sample=background.get_time_evolution(nodes,clock,vars=names,lAccuracyBoost=4)
            assert np.isfinite(sample).all() and not np.any(sample[:,:,5])
            packet=dict(values=sample,modes=nodes,names=np.array(names))
            saved=projection.projection(packet,phase,center,density,6,8)
            alt=projection.projection(packet,phase,center,density,4,8)
            top=projection.projection(packet,phase,center,density,6,10)
            pack(path.name,nodes=nodes,requested=clock,values=sample,names=names,anchor=available[ref],**{key:saved[key] for key in ('delta','momentum','pressure','closure_error','norm')},window_shift=np.maximum(abs(alt['delta']-saved['delta']),abs(alt['momentum']-saved['momentum']))/saved['norm'],order_shift=np.maximum(abs(top['delta']-saved['delta']),abs(top['momentum']-saved['momentum']))/saved['norm'])
        with np.load(path) as saved:
            assert np.array_equal(saved['nodes'],nodes) and np.array_equal(saved['requested'],clock)
            ai=int(np.searchsorted(nodes,available[ref]));new=np.searchsorted(nodes,wanted)
            err=max(abs(saved[k][ai]-bank[arch][ref])/bank['projection_norm'][ref] for k,arch in [('delta','matching_delta'),('momentum','matching_momentum')])
            row=dict(chunk=number,anchor=float(available[ref]),anchor_relative=float(err),closure=float(max(saved['closure_error'])),window=float(max(saved['window_shift'])),degree=float(max(saved['order_shift'])))
            qa.append(row)
            combined.append({key:saved[key][new] for key in ('delta','momentum','pressure','closure_error','norm')})
        if number%8==0:print('exact-mode batch',number,'/',math.ceil(len(missing)/16),row,flush=True)
    table('matching-controls.csv',qa)
    passed=all(row['closure']<2e-6 and max(row['anchor_relative'],row['window'],row['degree'])<=.005 for row in qa)
    record('matching-validation.json',dict(passed=passed,original_source=expected,source_rows=len(available),missing=len(missing),requested=len(needed),control_limit=.005,pressure_limit=2e-6,matching_scale=center,readout_start=float(clock[0]),readout_end=float(clock[-1]),grid_digest=digest(SPEC/'project_grid.py'),input_hashes={name:digest(Path(name)) for name in [str(projection.BACKGROUND),str(projection.EARLY/'runs/final-bg8-start/heavy.npz')]},packets={f'local-match-{index:03}.npz':digest(ROOT/f'local-match-{index:03}.npz') for index in range(len(combined))}))
    assert passed,'exact phase continuation failed retained checks; do not interpolate'
    grid=np.r_[available,missing];indices=np.argsort(grid)
    merged={**bank,'modes':grid[indices]}
    for dest,src in [('matching_delta','delta'),('matching_momentum','momentum'),('projection_norm','norm'),('projected_pressure','pressure'),('closure_error','closure_error')]:
        merged[dest]=np.concatenate([bank[dest],*[entry[src] for entry in combined]])[indices]
        assert np.array_equal(merged[dest][np.searchsorted(merged['modes'],available)],bank[dest])
    assert np.all(np.min(abs(needed[:,None]/merged['modes']-1),axis=1)<1e-12)
    pack('exact-phase-extension.npz',**merged)
    print('Physical matching rows added',len(missing),'old rows unchanged',len(available),flush=True)

if __name__=='__main__':main()
