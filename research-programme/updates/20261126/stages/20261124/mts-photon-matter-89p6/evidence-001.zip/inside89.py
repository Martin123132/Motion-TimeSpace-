from impulse89 import *


def rows(name):
    with (ROOT/name).open(newline='') as stream:
        return list(csv.DictReader(stream))


def profiles(medium,mode,count):
    old={model:Packet(model,mode,True) for model in MODELS}
    new={model:Packet(model,mode,False) for model in MODELS}
    begin,switch,end,first=split(medium)
    combined={key:[] for key in CASES}
    clocks=[]
    for lower,upper,fields,nodes in ((begin,switch,{model:(new[model] if model==first else old[model]) for model in MODELS},33),(switch,end,new,count)):
        scale=np.linspace(lower,upper,nodes)
        physical=history.branches(medium,fields,scale)
        clocks.append(medium.native('heavy',scale))
        for name,state in physical.items():
            native='heavy' if name=='paired' else name
            weight,gain,moment=kernel(medium,native,scale,medium.am)
            combined[name].append(np.array([weight*state['refC'],gain*state['Y']+moment*state['refC']]))
    clock=np.concatenate(clocks)
    values={}
    for name,pieces in combined.items():
        for field,curve in zip(('C','Y'),np.concatenate(pieces,axis=1)):
            values[name,field]=(clock,curve)
    return values
