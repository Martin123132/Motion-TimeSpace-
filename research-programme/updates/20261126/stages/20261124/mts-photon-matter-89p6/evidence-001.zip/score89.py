from transport89 import *
from scipy.integrate import simpson

def mag(series,measure):
    components=measure @ abs(series)**2
    return np.sqrt(np.append(components,components.sum()))

def vector_power(point):
    components=abs(point)**2
    return np.sqrt(np.append(components,components.sum()))

def main():
    guard()
    media,axis,weights,peak=proj.old.get_media()
    measure=previous.make_measure(axis,weights)
    dense=np.linspace(axis[0],axis[-1],16385)
    with np.load(proj.medium_file('medium-cold.npz')) as raw:
        high_weight=CubicSpline(raw['scale'],raw['visibility'])(dense)*media['cold']['clock'](dense,1)
    high_weight/=simpson(high_weight,x=dense);dense_measure=previous.make_measure(dense,high_weight)
    assert tuple(np.round(1/axis[[0,-1]]-1))==(1500,750)
    before={};earlier={};isolated={};adjoint={};scales={}
    with pin(FROZEN,'window-readouts.csv').open(newline='') as handle:
        reference={(row['model'],row['gravity'],row['output']):row for row in csv.DictReader(handle)}
    models=previous.MODELS
    for model in models[:2]:
        with np.load(pin(FROZEN,f'fixed-plus-blocks-{model}.npz')) as old,np.load(HERE/f'photons-{model}.npz') as new:
            grid=old['scale']
            assert np.array_equal(grid,new['scale']) and float(new['peak'])==peak and float(old['k'])==float(new['k'])
            retained={'scale':grid,'k':old['k'],'gravity_modes':np.array(MODES)}
            for idx,mode in enumerate(MODES):
                before[model,mode]=old['through83p2_'+mode]
                earlier[model,mode]=old['through76p8_'+mode]
                for setting in prior.SETTINGS:
                    isolated[model,mode,setting]=new[setting][:,idx]
                adjoint[model,mode]=new['adjoint'][idx]
                retained['through89p6_'+mode]=before[model,mode]+isolated[model,mode,'primary'].sum(axis=1)
            pack(f'photon-accumulated-{model}.npz',**retained)
    for mode in MODES:
        for collection in (before,earlier,adjoint):
            collection[models[-1],mode]=collection['heavy',mode]-collection['cold',mode]
        for setting in prior.SETTINGS:
            isolated[models[-1],mode,setting]=isolated['heavy',mode,setting]-isolated['cold',mode,setting]
    checks=[];rows=[];support=[]
    def check(model,mode,kind,values):
        for quantity,value in zip(previous.OUTPUTS,values,strict=True):
            checks.append(dict(model=model,mode=mode,test=kind,output=quantity,error=float(value),passed=bool(np.isfinite(value) and value<=.005)))
    for model in models:
        for mode in MODES:
            scale=float(reference[model,mode,'joint']['launch_norm'])
            original=CubicSpline(grid,before[model,mode],axis=0,extrapolate=False)
            third=CubicSpline(grid,earlier[model,mode],axis=0,extrapolate=False)
            channel=CubicSpline(grid,isolated[model,mode,'primary'],axis=0,extrapolate=False)
            entering=original(axis);old=third(axis);block=channel(axis).sum(axis=1)
            combined=entering+block
            prior83=mag(entering,measure);prior76=mag(old,measure);single=mag(block,measure);final=mag(combined,measure)
            for key,actual in [('through76p8_pct',prior76),('through83p2_pct',prior83)]:
                expected=np.array([float(reference[model,mode,label][key]) for label in previous.OUTPUTS])
                check(model,mode,'archived '+key,abs(100*actual/scale/expected-1))
            for idx in range(2):
                ref=adjoint[model,mode][idx]
                check(model,mode,'adjoint channel '+str(idx),vector_power(channel(peak)[idx]-ref)/vector_power(ref))
            change=final/prior83-1
            cross=2*measure @ (entering.conj()*block).real;cross=np.append(cross,cross.sum())
            assert np.allclose(final**2-prior83**2,single**2+cross,atol=0,rtol=2e-11)
            point=vector_power(original(peak)+channel(peak).sum(axis=0))/vector_power(original(peak))-1
            delta=abs(combined)**2-abs(entering)**2
            for oi,label in enumerate(previous.OUTPUTS):
                rows.append(dict(model=model,gravity=mode,output=label,through76p8_pct=100*prior76[oi]/scale,through83p2_pct=100*prior83[oi]/scale,new_alone_pct=100*single[oi]/scale,through89p6_pct=100*final[oi]/scale,window_change_percent=100*change[oi],relative_to76_change_percent=100*(final[oi]/prior76[oi]-1),peak_change_percent=100*point[oi],new_power=1e4*single[oi]**2/scale**2,cross_with_entering=1e4*cross[oi]/scale**2))
                diff=delta[:,oi] if oi<2 else delta.sum(axis=1)
                support.append(dict(model=model,gravity=mode,output=label,fraction_weight_with_decrease=previous.probability(axis,weights,-diff)))
            for setting in ('time','angle','quadrature')+(('gravity',) if mode=='p32' else ()):
                if setting=='quadrature':
                    alt_before=original(dense);alt=channel(dense).sum(axis=1)
                    new=mag(alt_before+alt,dense_measure);base=mag(alt_before,dense_measure)
                    check(model,mode,setting+' isolated',abs(mag(alt,dense_measure)/single-1))
                    check(model,mode,setting+' combined',abs(new/final-1))
                else:
                    step,choice=('p16','primary') if setting=='gravity' else (mode,setting)
                    alt_before=CubicSpline(grid,before[model,step],axis=0)(axis)
                    alt=CubicSpline(grid,isolated[model,step,choice].sum(axis=1),axis=0)(axis)
                    base=mag(alt_before,measure);new=mag(alt_before+alt,measure)
                    check(model,mode,setting+' isolated',mag(alt-block,measure)/single)
                    check(model,mode,setting+' combined',mag(alt_before+alt-combined,measure)/final)
                check(model,mode,setting+' signed fractional change',abs((new/base-1)-change)/abs(change))
    table('window-readouts.csv',rows);table('window-checks.csv',checks);table('visibility-support.csv',support)
    matter=json.loads((HERE/'matter-validation.json').read_bytes());failed=[row for row in checks if not row['passed']]
    record('window-validation.json',dict(tolerance=.005,passed=not failed,matter_passed=matter['passed'],control_passed=matter['passed'] and not failed,matched_quadratic_verified=False,heavy_route=matter['heavy_route'],checks=len(checks),failures=failed,worst=max(checks,key=lambda row:row['error'])))
    print('Window tests',len(checks),'failures',failed,'matter pass',matter['passed'],flush=True)
if __name__=='__main__':main()
