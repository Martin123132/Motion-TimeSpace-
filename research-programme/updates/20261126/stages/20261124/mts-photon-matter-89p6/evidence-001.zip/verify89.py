import hashlib
import json
from pathlib import Path
import csv
import sys
from scipy.integrate import simpson
from scipy.interpolate import CubicSpline
from transport89 import HERE, FROZEN, MODES, digest, guard, np, proj, pin, save, PINS

def obj(name):
    return json.loads((HERE/name).read_bytes())
def csvrows(name):
    with (HERE/name).open(newline='') as handle:return list(csv.DictReader(handle))
def main():
    guard()
    assert obj('matching-validation.json')['passed'] and not obj('switch-audit.json')['accepted_original_full_quadratic']
    for model in ('cold','heavy'):
        for name,expected in obj(f'bank-{model}.json').items():
            assert digest(HERE/name)==expected
        assert len(obj(f'bank-{model}.json'))==82
        for mode in MODES:
            receipt=obj(f'metric-{model}-{mode}.json')
            assert receipt['passed'] and receipt['output_digest']==digest(HERE/f'particular-{model}-{mode}.npz')
            assert receipt['step_mpc']==.00625/int(mode[1:]) and receipt['source_bank']==digest(HERE/f'bank-{model}.json')
            assert receipt['incident_control']<1e-10 and len(receipt['micro'])==77
    for key,value in obj('matching-validation.json')['packets'].items():assert digest(HERE/key)==value
    matter=obj('matter-validation.json')
    assert matter['passed']==all(row['passed']=='True' for row in csvrows('matter-checks.csv'))
    window=obj('window-validation.json')
    assert window['passed']==all(row['passed']=='True' for row in csvrows('window-checks.csv'))
    assert not window['matched_quadratic_verified']
    prefix=HERE/'original-through89'
    strict=obj('original-through89/window-validation.json')
    routes=obj('route-validation.json')
    assert strict['matched_quadratic_verified'] and not routes['original_to89p6_verified']
    assert routes['original_to89_gates']==strict['control_passed']
    assert routes['pre_switch_agreement']==all(row['passed']=='True' for row in csvrows('pre-switch-comparisons.csv'))
    for name,expected in obj('original-through89/bank-heavy.json').items():assert digest(prefix/name)==expected
    for mode in MODES:
        for model in ('cold','heavy'):
            path=prefix/f'particular-{model}-{mode}.npz'
            assert obj('original-through89/'+f'metric-{model}-{mode}.json')['output_digest']==digest(path)
            with np.load(path) as raw:assert raw['eta'][-1]==89.
        for model in ('cold','heavy'):
            with np.load(prefix/f'photon-accumulated-{model}.npz') as out,np.load(pin(FROZEN,f'fixed-plus-blocks-{model}.npz')) as start,np.load(prefix/f'photons-{model}.npz') as fourth:
                assert np.array_equal(out['through89p0_'+mode],start['through83p2_'+mode]+fourth['primary'][:,MODES.index(mode)].sum(axis=1))
    look={(row['model'],row['gravity'],row['output']):row for row in csvrows('window-readouts.csv')}
    _,axis,weights,_=proj.old.get_media()
    for mode in MODES:
        banks={}
        for model in ('cold','heavy'):
            with np.load(HERE/f'photon-accumulated-{model}.npz') as out,np.load(pin(FROZEN,f'fixed-plus-blocks-{model}.npz')) as before,np.load(HERE/f'photons-{model}.npz') as delta:
                grid=out['scale'];value=out['through89p6_'+mode]
                assert np.array_equal(grid,before['scale']) and np.array_equal(value,before['through83p2_'+mode]+delta['primary'][:,MODES.index(mode)].sum(axis=1))
                banks[model]=value
        banks['MTS-minus-baseline']=banks['heavy']-banks['cold']
        for model,value in banks.items():
            power=simpson(weights[:,None]*abs(CubicSpline(grid,value,axis=0)(axis))**2,x=axis,axis=0)
            sizes=np.sqrt(np.append(power,power.sum()))
            for oi,label in enumerate(('energy','current','joint')):
                row=look[model,mode,label]
                ref=float(row['through83p2_pct'])
                with pin(FROZEN,'window-readouts.csv').open() as handle:
                    norm=float(next(x['launch_norm'] for x in csv.DictReader(handle) if (x['model'],x['gravity'],x['output'])==(model,mode,label)))
                assert np.isclose(100*sizes[oi]/norm,float(row['through89p6_pct']),rtol=1e-12,atol=0)
                assert abs((100*sizes[oi]/norm)/ref-1-float(row['window_change_percent'])/100)<1e-12
    assert not list(HERE.rglob('__pycache__')) and not list(HERE.rglob('reader-forward-*'))
    files={path.relative_to(HERE).as_posix():digest(path) for path in sorted(HERE.rglob('*')) if path.is_file() and path.name!='seal.json'}
    body=(json.dumps(dict(parents={path.name:key for path,key in PINS.items()},files=files),sort_keys=True,indent=2)+'\n').encode()
    if sys.argv[1:]==['--seal']:save('seal.json',body)
    else:assert (HERE/'seal.json').read_bytes()==body
    print('Verified',len(files),'stage files, original matched result unscored; control gates:',window['control_passed'],'seal:',digest(HERE/'seal.json'))
if __name__=='__main__':main()
