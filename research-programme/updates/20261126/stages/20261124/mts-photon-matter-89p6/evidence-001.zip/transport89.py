from pathlib import Path
import csv
import hashlib
import io
import json
import sys

HERE=Path(__file__).resolve().parent
FROZEN=HERE.parent/'mts-photon-frozen64-plus-three-20261124'
ARCHIVE=HERE.parent/'mts-photon-visibility-window-post64-three-20261124'
PINS={FROZEN:'ef087cf76f28f64d22e762bc5814ecda7d8152f9cc84f024a0e591ff7f1adba8',ARCHIVE:'2ce600bc4e9a8172d3b65c81e2c9a34d7022ffd723c9e54620e13d1d09f1a4d0'}
def digest(path):
    with path.open('rb') as handle:return hashlib.file_digest(handle,'sha256').hexdigest()
def pin(folder,name):
    seal=folder/'seal.json'; assert digest(seal)==PINS[folder]
    path=folder/name
    assert digest(path)==json.loads(seal.read_bytes())['files'][name]
    return path
for name in ('window83.py','compare_window.py'):pin(ARCHIVE,name)
sys.path.insert(0,str(ARCHIVE))
import compare_window as previous
from window83 import prior,proj,np,solve_banded,MODES
from scipy.interpolate import CubicSpline
def guard():
    prior.guard()
    assert not any((folder/'STOP-REQUESTED').exists() for folder in (HERE,FROZEN,ARCHIVE))
def save(name,body):
    guard();path=HERE/name
    if path.exists():assert path.read_bytes()==body,name
    else:
        with path.open('xb') as handle:handle.write(body)
def pack(name,**fields):
    stream=io.BytesIO();np.savez_compressed(stream,**fields);save(name,stream.getvalue())
def record(name,body):save(name,(json.dumps(body,sort_keys=True,indent=2,allow_nan=False)+'\n').encode())
def table(name,rows):
    stream=io.StringIO();out=csv.DictWriter(stream,rows[0].keys(),lineterminator='\n');out.writeheader();out.writerows(rows);save(name,stream.getvalue().encode())

def integrate(axis,eta,curves,active,medium,wave,bands):
    rates,at=proj.coefficients(axis,medium,wave)
    force=np.stack([np.diff(axis)[active,None,None]*np.einsum('st,ntc->nsc',proj.RAD,curve(at[active])) for curve in curves],axis=1)
    first=int(np.flatnonzero(active)[0]);last=int(np.flatnonzero(active)[-1])
    assert last-first+1==len(force)
    count=bands.shape[-1]//2
    assert 89.0 in axis
    state=np.zeros((count,16));right=np.empty((2*count,16),order='F')
    saved=np.zeros((len(eta),2,16));slots=np.searchsorted(axis,eta)
    assert np.array_equal(axis[slots],eta)
    slots_at=np.full(len(axis),-1);slots_at[slots]=np.arange(len(eta))
    for begin in range(first,len(rates),48):
        if (begin-first)%1536==0:guard()
        end=min(begin+48,len(rates))
        mats=(rates[begin:end].reshape(-1,8)@bands.reshape(8,-1)).reshape(-1,11,2*count);mats[:,5]+=1
        for step,mat in enumerate(mats,begin):
            right[::2]=state;right[1::2]=state
            if step<=last:
                for mode_index in range(2):
                    for row,factor,channel in ((0,4.,0),(2,4*wave/3,1),(4,4*wave/3,1)):
                        section=int(axis[step]>=89.)
                        column=((section*2+mode_index)*2+channel)*2
                        value=factor*force[step-first,mode_index,:,channel]
                        right[row:row+2,column]+=value.real
                        right[row:row+2,column+1]+=value.imag
            state=solve_banded((5,5),mat,right,check_finite=False)[1::2]
            slot=slots_at[step+1]
            if slot>=0:saved[slot]=state[[0,2]]
    return (saved[:,:,::2]+1j*saved[:,:,1::2]).reshape(len(eta),2,2,2,2).transpose(0,2,3,4,1)

def run(model):
    guard();assert model in ('cold','heavy')
    gate=json.loads((HERE/'matter-validation.json').read_bytes())
    assert gate['tolerance']==.005
    grid,eta,medium,peak,weights=proj.measure(model)
    provenance={'matter_gate':digest(HERE/'matter-validation.json'),'matter_passed':gate['passed']}
    with np.load(pin(FROZEN,f'fixed-plus-blocks-{model}.npz')) as before:
        assert np.array_equal(grid,before['scale']) and np.array_equal(before['gravity_modes'],MODES)
        wave=float(before['k'])
    curves={};times={}
    for mode in MODES:
        path=HERE/f'particular-{model}-{mode}.npz'
        receipt=json.loads((HERE/f'metric-{model}-{mode}.json').read_bytes())
        assert receipt['passed'] and receipt['output_digest']==digest(path)
        provenance[mode]=receipt['output_digest']
        with np.load(path) as raw:
            times[mode]=raw['eta'];assert raw['k'][0]==wave and np.array_equal(times[mode][[0,-1]],[83.2,89.6])
            assert len(times[mode])==1024*int(mode[1:])+1 and len(raw['q'])==77
            curves[mode]=CubicSpline(times[mode],np.column_stack([raw['phi_dot'],raw['psi']]),axis=0,extrapolate=False)
    assert np.allclose(times['p32'][::2],times['p16'],atol=2e-14,rtol=0)
    arrays={}
    for label,(order,sub,stride) in prior.SETTINGS.items():
        axis=np.unique(np.r_[proj.base_axis(grid,eta,sub),times['p32'][::stride]])
        active=(axis[:-1]>=83.2)&(axis[1:]<=89.6)
        assert abs(np.diff(axis)[active].sum()-6.4)<1e-12
        bands=proj.transfer.stages(order)
        parts=integrate(axis,eta,[curves[mode] for mode in MODES],active,medium,wave,bands)
        arrays[label]=parts.sum(axis=1)
        arrays[label+'_early']=parts[:,0]
        assert np.isfinite(arrays[label]).all()
        if label=='primary':
            _,at,gains=proj.backward(axis,eta,weights,medium,wave,proj.transpose_bands(bands),active=active)
            arrays['adjoint']=np.array([np.einsum('nctj,ntc->cj',gains[active],curves[mode](at[active])) for mode in MODES])
        print(model,'physical transport',label,'complete',flush=True)
    pack(f'photons-{model}.npz',scale=grid,k=wave,peak=peak,**arrays)
    record(f'photon-inputs-{model}.json',provenance)
if __name__=='__main__':run(sys.argv[1])
