from pathlib import Path
import hashlib
import json
import io
import os
import sys

HERE=Path(__file__).resolve().parent
SAVED=HERE.parent/'mts-physical-impulses-70p4-20261123'
SIX=HERE.parent/'mts-particular-gravity-64-tail-20261123'
START=HERE.parent/'mts-particular-gravity-57p6-20261123'
BOUND=HERE.parent/'mts-64-to-peak-matter-bound-20261123'
PINS={SAVED:'1dfc19700055fa4ccfe3fb67386f956c8bbcd216c904c72a1f178b833824ae1a',SIX:'b512fa19c739b9b912b86b80be0a7e8af67047a63be02e5e8ba3b5a0ac36f19d',START:'af98172b9e9d0f516fdb80bab2c7be5972bbd70bfadbe3c6c3e93a68489f1002',BOUND:'34527715cc80011cc93b6c92b208e075c506cb468a6dfdedc6ba7c50076f6903'}
FINE=HERE.parent/'mts-gravity-p16-70p4-20261124'
EIGHT=HERE.parent/'mts-physical-impulses-76p8-20261124'
NINE=HERE.parent/'mts-physical-impulses-83p2-20261124'
PINS.update({FINE:'a30c6a9168e8dfb20e86db29a8f7a40c02e8c15c4bdb31ac9d296bb5f05b2830',EIGHT:'0d4b212a23c89a4442ebcec6c68d42e03902e2ab19c48e7abeb467f5981de2fc',NINE:'e446924053253ca4c6d3b8c3a09f18f613ea5fed6afe2cf09a012a2c24626318'})
STAGES=(('to64',57.6,64.,SIX),('to70',64.,70.4,SAVED),('to76',70.4,76.8,EIGHT),('to83',76.8,83.2,NINE))
def digest(path):
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
def pin(folder,name):
    manifest=folder/'seal.json'
    assert digest(manifest)==PINS[folder]
    path=folder/name
    assert digest(path)==json.loads(manifest.read_bytes())['files'][name],path
    return path
def local_guard():
    assert all(not (folder/'STOP-REQUESTED').exists() for folder in (*PINS,HERE,HERE.parent))
def save(name,data):
    local_guard()
    path=HERE/name
    assert HERE in path.resolve().parents
    path.parent.mkdir(exist_ok=True)
    if path.exists():assert digest(path)==hashlib.sha256(data).hexdigest(),name
    else:
        with path.open('xb') as stream:stream.write(data)
def record(name,body):
    save(name,(json.dumps(body,indent=2,sort_keys=True,allow_nan=False)+'\n').encode())
def pack(name,**fields):
    import numpy as np
    stream=io.BytesIO()
    np.savez_compressed(stream,**fields)
    save(name,stream.getvalue())
