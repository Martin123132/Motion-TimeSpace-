import stage_paths as paths
import sys
paths.pin(paths.NINE,'block.py')
paths.pin(paths.NINE,'gravity83.py')
sys.path.insert(0,str(paths.NINE))
from block import *
from fluid import Flow
from fixed_bin25 import lag_flight
from fine77_return import four_stresses, MOM
from types import SimpleNamespace
import block as upstream
from stage_paths import pack,record

def guard():
    upstream.guard()
    paths.local_guard()

def err(value,reference):
    return float(np.max(np.max(abs(value-reference),axis=0)/np.maximum(np.max(abs(reference),axis=0),1e-80)))


def run(model,index):
    assert model in ('cold','heavy') and index in range(4)
    guard()
    mode,start,end,inputs=paths.STAGES[index]
    prefix_out=mode+'/'
    refine=32
    padded=True
    output=paths.HERE/mode/f'particular-{model}-p32.npz'
    receiptpath=output.with_name(f'metric-{model}-p32.json')
    folder=inputs/'material-halfstep'
    if not index:
        source_restart=paths.pin(paths.START,f'particular-{model}-p4.npz')
        parent=paths.pin(paths.FINE,f'to64/metric-{model}-p16.json')
        assert json.loads(parent.read_bytes())['parent']==paths.digest(source_restart)
    else:
        last=paths.STAGES[index-1][0]
        source_restart=paths.HERE/last/f'particular-{model}-p32.npz'
        sealed=json.loads(source_restart.with_name(f'metric-{model}-p32.json').read_bytes())
        assert sealed['passed'] and sealed['output_digest']==paths.digest(source_restart)
    if output.exists() or receiptpath.exists():
        previous_result=json.loads(receiptpath.read_bytes())
        assert previous_result['passed'] and previous_result['output_digest']==paths.digest(output) and previous_result['parent']==paths.digest(source_restart) and previous_result['source_seal']==paths.PINS[inputs]
        return
    for name in ('common-'+model+'.npz',*(f'micro-{model}-{i}.npz' for i in range(-52,25)),*(f'material-halfstep/{kind}-{model}.npz' for kind in ('forcing','radiation','collisionless','origin-v2'))):
        paths.pin(inputs,name)
    print('Starting',model,start,end,flush=True)
    with np.load(source_restart) as src:
        assert np.array_equal(src['q'],MOM) and src['eta'][-1]==start
        keys=src['keys'];initial=src['state'][:,:1];lag0=src['lagEnd'][:,:,:1];shape0=src['shape'][-1,:,:1]
        old_obs=src['obs'][-1,:,:1];old_stress=src['stress'][-1,:,:1]
    with np.load(inputs/f'common-{model}.npz') as src:
        t=src['eta'];wave=src['k'];common=src['S'][None];spectral=src['Sw'][None]
    assert t[0]==start and t[-1]==end and common.shape==(1,69,129)
    drivers=[];seams=[];independent=[];src_hash={}
    for node,q in enumerate(MOM,-52):
        path=inputs/f'micro-{model}-{node}.npz';src_hash[path.name]=digest(path)
        with np.load(path) as src:
            assert src['id']==node and src['q']==q
            drivers.append(src['source'][None]);seams.append(float(src['join']));independent.append(float(src['independent']))
    with np.load(folder/f'forcing-{model}.npz') as f:
        clock=f['eta'];bg=dict(zip(f['bgkeys'],f['background']));fields=dict(zip(f['keys'],f['values']))
    meta=json.loads(ti.parent.pin('radiation-background.json').read_bytes())[model]
    win=SimpleNamespace(t=t,k=wave,mass=meta['mass_over_temperature'],coeff=meta['massless_limit_coeff']/(7*np.pi**4/120),af=spline(clock,bg['a']),energy=spline(clock,bg['enu']))
    bank=dict(k=wave,eta=t,S=common,Sw=spectral)
    shape=make_shape(bank,shape0);win.shape=spline(t,shape)
    flow=object.__new__(Flow)
    with patch.object(regular_flow,'HOME',folder):Flight.__init__(flow,model,68,6,False,True)
    assert list(keys)==flow.keys
    flow.initial=(keys,initial);flow.wall=None;flow.start_offset=None
    if padded:
        from scipy.interpolate import make_interp_spline
        flow.q=make_interp_spline(flow.log,flow.q(flow.log),k=5)
        flow.bg=make_interp_spline(flow.log,flow.bg(flow.log),k=5)
    flow.k=flow.k[:1];flow.factors=flow.factors[:,:1];flow.probe=flow.probe[:,:1];qfields=flow.q;flow.q=lambda u:qfields(u)[...,:1]
    flow.drive=spline(t,common.transpose(2,1,0))
    if refine>1 or padded:
        active=clock[8:-8] if padded else clock
        assert active[0]==start and active[-1]==end
        flow.t=np.linspace(active[0],active[-1],(len(active)-1)*refine+1)
        flow.t[::refine]=active;flow.log=np.log(flow.t)
    zeros=np.zeros((len(t),4,1,2),complex)
    times,unforced,normal,_=flow.evolve(t,zeros)
    win.normal=spline(times,normal);win.lapse=spline(times,unforced[:,1])
    tests=[];last_iteration=None
    for iteration in range(1,5):
        low=[];ends=[]
        for index,q in enumerate(MOM):
            if index%8==0:guard()
            track=lag_flight(win,q,drivers[index],lag0[index])
            ends.append(track[-1]);low.append(track[:,:3])
        stress,check=four_stresses(win,np.stack(low,axis=1))
        quadrature=err(check,stress);assert quadrature<1e-12
        times,obs,normal,states=flow.evolve(t,stress)
        delta=obs[:,:4]-unforced[:,:4]
        if last_iteration is not None:
            sc=err(stress,last_iteration[0]);mc=err(delta,last_iteration[1]);tests.append(dict(iteration=iteration,stress=sc,metric_increment=mc));print(model,tests[-1],flush=True)
            if max(sc,mc)<=.005:break
        last_iteration=stress,delta;win.normal=spline(times,normal);win.lapse=spline(times,obs[:,1])
    else:raise ArithmeticError('coupled iteration failed')
    coarse=flow.evolve(t,stress,step=2)[1]
    time_err=err(coarse[:,:2],obs[::2,:2])
    seam_stress=err(stress[:1],old_stress[None]);seam_metric=err(obs[:1,:4],old_obs[None,:4])
    phi=obs[:,0,0,0];psi=obs[:,1,0,0]
    pd=-obs[:,3,0,0]/times-flow.bg(flow.log)[:,flow.bgkeys.index('h')]*psi+flow.q(flow.log)[:,flow.qkeys.index('Fq'),0]
    derivative=CubicSpline(times,phi)(times,1)
    slope_error=err(derivative,pd);interior=err(derivative[2:-2],pd[2:-2])
    suffix=(f'-p{refine}' if padded else f'-s{refine}') if padded or refine!=1 else ''
    pack(prefix_out+f'particular-{model}{suffix}.npz',eta=times,k=wave,a=win.af(flow.log),phi=phi,psi=psi,phi_dot=pd,differentiated=derivative,obs=obs,normal=normal,lagEnd=np.stack(ends),keys=keys,state=states[-1],shape=shape,stress=stress,stressClock=t,q=MOM)
    report=dict(model=model,mode=mode,parent=digest(source_restart),micro=src_hash,iterations=tests,quadrature=quadrature,incident_seam=max(seams),incident_control=max(independent),seam_metric=seam_metric,seam_stress=seam_stress,time_metric=time_err,slope_error=slope_error,interior_slope_error=interior)
    report.update(step_mpc=0.0001953125,source_seal=paths.PINS[inputs],output_digest=paths.digest(paths.HERE/(prefix_out+f'particular-{model}{suffix}.npz')))
    report['passed']=max(seam_stress,seam_metric,time_err,slope_error,max(seams))<=.005
    record(prefix_out+f'metric-{model}{suffix}.json',report)
    print(model,{k:v for k,v in report.items() if k not in ('micro','iterations')},flush=True)

    if not report['passed']:raise ArithmeticError(f'{model} {mode} source/metric gate failed')

if __name__=='__main__':
    for index in range(4):run(sys.argv[1],index)
