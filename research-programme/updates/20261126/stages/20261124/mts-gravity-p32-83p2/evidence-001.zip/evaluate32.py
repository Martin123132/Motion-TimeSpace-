import csv
import io
import json
import sys
from functools import lru_cache
from unittest.mock import patch

import stage_paths as local
for name in ('impulse83.py','inside83.py','balance83.py','remaining83.py'):
    local.pin(local.NINE,name)
sys.path.insert(0,str(local.NINE))
import impulse83 as bridge
import inside83 as interior
import balance83 as balance
import remaining83 as remaining
from impulse83 import Medium, history, np, CubicSpline, make_interp_spline, parts, z, MODELS, CASES
from copy import copy

LIMIT=.005

def rows(path):
    with path.open(newline='') as stream:return list(csv.DictReader(stream))
def write(name,items):
    buffer=io.StringIO()
    writer=csv.DictWriter(buffer,items[0],lineterminator='\n');writer.writeheader();writer.writerows(items)
    local.save(name,buffer.getvalue().encode())

@lru_cache(maxsize=16)
class Profile(history.Saved):
    def __init__(self,model,mode,index):
        self.model=model
        stage,start,end,folder=local.STAGES[index]
        name=f'particular-{model}-{mode}.npz'
        meta=f'metric-{model}-{mode}.json'
        if mode=='p16':
            location=local.FINE if index<2 else folder
            prefix=stage+'/' if index<2 else ''
            save=local.pin(location,prefix+name)
            report=json.loads(local.pin(location,prefix+meta).read_bytes())
        elif mode=='p32':
            save=local.HERE/stage/name
            report=json.loads((local.HERE/stage/meta).read_bytes())
        else:raise ValueError(mode)
        assert report['passed'] and report['output_digest']==local.digest(save)
        local.pin(folder,f'material-halfstep/forcing-{model}.npz')
        self.path=save
        with np.load(save) as raw:
            self.time=raw['eta'];wave=float(raw['k'][0]);obs=raw['obs'][:,:,0,0]
            assert np.array_equal(self.time[[0,-1]],[start,end]) and len(raw['q'])==77
            fields={'Y':raw['psi'],'phi':raw['phi'],'pd':raw['phi_dot'],'L':obs[:,11],'F':obs[:,3]/self.time}
            assert np.allclose(fields['L'],fields['Y']-fields['phi'],atol=1e-25,rtol=1e-9)
        with np.load(folder/'material-halfstep'/f'forcing-{model}.npz') as src:
            bg=dict(zip(src['bgkeys'],src['background']));q=dict(zip(src['keys'],src['values']));log=np.log(src['eta'])
            for key,val in [('Fq',q['Fq'][:,0]),('Hm',bg['h'])]:
                fields[key]=make_interp_spline(log,val,k=5)(np.log(self.time))
        assert np.max(abs(fields['pd']+fields['F']+fields['Hm']*fields['Y']-fields['Fq']))<1e-9*np.max(abs(fields['pd']))
        self.curves={key:CubicSpline(self.time,val,extrapolate=False) for key,val in fields.items()}

def last_packet(model,mode,prior):
    return Profile(model,mode,2 if prior else 3)

def cut_centers(med,index,mode):
    stage,begin,end,source=local.STAGES[index]
    scale=min(med.root(model,end) for model in MODELS)
    group={name:Profile(name,mode,index) for name in MODELS}
    states=history.branches(med,group,scale)
    out={}
    for name in CASES:
        model='heavy' if name=='paired' else name
        weight,gain,moment=bridge.kernel(med,model,np.array([scale,med.am]),med.am)
        state=states[name]
        out[name,'C']=-weight[0]*state['refC']
        out[name,'Y']=-gain[0]*state['Y']-moment[0]*state['refC']
    return out

def trajectories(med):
    result=[]
    for index,(stage,begin,end,source) in enumerate(local.STAGES):
        collected={}
        for mode in ('p16','p32'):
            cases={name:Profile(name,mode,index) for name in MODELS}
            lo,hi=med.both({name:entry.time for name,entry in cases.items()})
            scale=np.linspace(lo,hi,32769)
            physical=history.branches(med,cases,scale)
            native={}
            for name,entry in cases.items():
                time=bridge.limit_time(med.native(name,scale),entry.time)
                phi=entry.curves['phi']
                native[name]=np.array([phi(time),entry.curves['pd'](time),phi(time,1)])
            native['paired']=native['heavy']-native['cold']
            for name,(phi,rate,derivative) in native.items():
                row=physical[name]
                error=np.max(abs(derivative-rate))/np.max(abs(rate))
                result.append(dict(stage=stage,model=name,check=mode+' derivative vs constraint',relative_error=error,passed=error<=LIMIT))
                collected[mode,name]=[phi,row['Y'],rate,row['C'],row['refCp'],row['refYp']]
        for name in CASES:
            for label,low,high in zip(('phi','Y','phi_dot','C','C slope','Y slope'),collected['p16',name],collected['p32',name]):
                error=np.max(abs(low-high))/np.max(abs(high))
                result.append(dict(stage=stage,model=name,check='step: '+label,relative_error=error,passed=error<=LIMIT))
    return result

def main():
    local.local_guard();bridge.guard()
    med=Medium(); radius_rows=rows(local.pin(local.BOUND,'required-signed-impulses.csv'))
    radii={key:float(row['radius']) for key,row in zip(('C','Y'),radius_rows)}
    previous=rows(local.pin(local.NINE,'physical-impulses.csv'))
    old_budgets=rows(local.pin(local.NINE,'within-block-step-shifts.csv'))
    historical=rows(local.pin(local.NINE,'peak-allowances.csv'))
    trajectory=trajectories(med);write('joint-trajectory.csv',trajectory)
    cuts=[];cut_map={};profiles={};allwork=[];checks=[];rates=[];extrema=[];endchecks=[];maxima=[];terms={};identity=[];replays=[];seams=[];mode_caps={}
    for index,(stage,begin,end,source) in enumerate(local.STAGES):
        ref=cut_centers(med,index,'p32');other=cut_centers(med,index,'p16')
        for name,key in ref:
            cuts.append(dict(stage=stage,end_mpc=end,model=name,field=key,**parts('p32_center',ref[name,key]),**parts('p16_center',other[name,key]),shift_over_radius=abs(ref[name,key]-other[name,key])/radii[key]))
            cut_map[index,name,key,'p32']=ref[name,key];cut_map[index,name,key,'p16']=other[name,key]
    for mode in ('p16','p32'):
        with patch.object(bridge,'Packet',last_packet),patch.object(interior,'Packet',last_packet),patch.object(balance,'Packet',last_packet):
            lower,*_=bridge.intervals(med,mode,32769)
            work,qa,jumps=bridge.intervals(med,mode,65537)
            with_coarse=interior.profiles(med,mode,32769)
            profiles[mode]=interior.profiles(med,mode,65537)
            coarse_rate=balance.rate(med,mode,32769);new_rate=balance.rate(med,mode,65537)
        seams.extend(jumps)
        for row in qa:checks.append(dict(mode=mode,model=row['model'],target=row['target'],check=row['test'],relative_error=row['relative_error'],passed=row['relative_error']<=LIMIT))
        for item,alt in zip(work,lower):
            for field in ('I_C','I_Y_current','I_Y_shear','I_Y','remaining_center_C','remaining_center_Y'):
                error=bridge.relative(z(alt,field),z(item,field))
                checks.append(dict(mode=mode,model=item['model'],target=item['target'],check='readout grid: '+field,relative_error=error,passed=error<=LIMIT))
        allwork.extend(work)
        for name in CASES:
            item=next(row for row in work if row['model']==name and row['target']=='priority midpoint')
            full=-z(item,'remaining_center_Y');launch=z(item,'carried_Y');impulse=z(item,'I_Y');seam=z(item,'seam_Y')
            defect=full-launch-impulse-seam;direct,independent=new_rate[name]
            uncert=[abs(direct-independent)/radii['Y'],abs(direct-coarse_rate[name][0])/radii['Y'],abs(defect-direct)/radii['Y']]
            rates.append(dict(mode=mode,model=name,**parts('integrated',direct),in_paired_radii=abs(direct)/radii['Y'],integration_by_parts_change=uncert[0],quadrature_change=uncert[1],endpoint_disagreement=uncert[2],passed=max(uncert)<=LIMIT))
            if name=='paired':terms[mode]=dict(start=launch,current=z(item,'I_Y_current'),shear=z(item,'I_Y_shear'),clock=z(item,'I_Y_clock'),seam=seam,rate_defect=direct,other=defect-direct,final=full)
            for field in ('C','Y'):
                clock,curve=profiles[mode][name,field];absolute=abs(curve);start=z(item,'carried_'+field);end=-z(item,'remaining_center_'+field);radius=radii[field]
                minimum=int(absolute.argmin());maximum=int(absolute.argmax());coarse=abs(with_coarse[name,field][1])
                err=[abs(start+cut_map[2,name,field,mode])/radius,abs(end+cut_map[3,name,field,mode])/radius,abs(start-curve[0])/radius,abs(end-curve[-1])/radius,abs(absolute[minimum]-min(coarse))/abs(start),abs(absolute[maximum]-max(coarse))/abs(start)]
                independent_row=next(r for r in previous if (r['mode'],r['model'],r['target'])==('p16',name,'priority midpoint'))
                if mode=='p16':
                    replay=abs(end+z(independent_row,'remaining_center_'+field))/radius
                    replays.append(dict(model=name,field=field,peak_center_replay_over_radius=replay,passed=replay<=LIMIT))
                extrema.append(dict(mode=mode,model=name,field=field,min_ratio=absolute[minimum]/abs(start),min_eta=clock[minimum],max_ratio=absolute[maximum]/abs(start),max_eta=clock[maximum],end_over_start=abs(end)/abs(start),end_over_64=abs(end)/abs(cut_map[0,name,field,mode]),largest_replay_or_integration_check=max(err),passed=max(err)<=LIMIT))
        cut=bridge.split(med)[2];proxy=copy(med);proxy.a0=cut
        paired=history.branches(med,{m:last_packet(m,mode,False) for m in MODELS},cut)['paired']
        est,rad=remaining.bracket(proxy,'heavy',32)
        wc,gy,tc=bridge.kernel(med,'heavy',np.array([cut,med.am]),med.am)
        bracket_error=(abs(tc[0]-est)+rad)*abs(paired['refC'])/radii['Y']
        endchecks.append(dict(mode=mode,independent_transfer_uncertainty_over_lapse_radius=bracket_error,passed=bracket_error<=LIMIT))
    for field in ('C','Y'):
        clock,fine=profiles['p32']['paired',field];other,control=profiles['p16']['paired',field]
        assert np.array_equal(clock,other)
        disp=abs(fine-control)/radii[field];idx=int(disp.argmax())
        old=next(row for row in old_budgets if row['field']==field)
        start=float(disp[0]);end=float(disp[-1]);high=float(disp[idx])
        val=next(row for row in cuts if row['stage']=='to83' and row['model']=='paired' and row['field']==field)
        assert abs(end-val['shift_over_radius'])<LIMIT
        maxima.append(dict(field=field,initial_p8_p16_cut=float(next(row['end_shift_over_radius'] for row in historical if row['quantity']==field)),initial_p8_p16_max=float(old['maximum_sampled_step_shift_in_radii']),new_start_shift=start,new_end_shift=end,new_maximum_shift=high,maximum_heavy_mpc=clock[idx],endpoint_pass=end<=1,sampled_pass=high<=1))
    for low,high in zip(allwork[:6],allwork[6:]):
        assert (low['model'],low['target'])==(high['model'],high['target'])
        for field in ('I_C','I_Y_current','I_Y_shear','I_Y','remaining_center_C','remaining_center_Y'):
            err=bridge.relative(z(low,field),z(high,field))
            identity.append(dict(model=high['model'],target=high['target'],field=field,relative_error=err,passed=err<=LIMIT))
    delta={key:val-terms['p32'][key] for key,val in terms['p16'].items()}
    assert abs(delta['final']-sum(val for key,val in delta.items() if key!='final'))<1e-8*radii['Y']
    contributions=[dict(term=key,modulus_over_radius=abs(val)/radii['Y'],projection_over_radius=(val*delta['final'].conjugate()).real/abs(delta['final'])/radii['Y']) for key,val in delta.items()]
    for filename,data in [('physical-work.csv',allwork),('impulse-checks.csv',checks),('seams.csv',seams),('rate-checks.csv',rates),('inside-block.csv',extrema),('cut-centers.csv',cuts),('absolute-test.csv',maxima),('independent-kernel.csv',endchecks),('p16-replay.csv',replays),('impulse-time-step.csv',identity),('lapse-attribution.csv',contributions)]:
        write(filename,data)
    print('Absolute allowances:',maxima,'fine paired proportions:',[(row['field'],row['end_over_start']) for row in extrema if row['model']=='paired' and row['mode']=='p32'],flush=True)
if __name__=='__main__':main()
