import ast
import csv
import json
import sys
import math
import numpy as np
import stage_paths as local

TOL=.005

def rows(name):
    with (local.HERE/name).open(newline='') as stream:return list(csv.DictReader(stream))

def check():
    local.local_guard()
    for folder,expected in local.PINS.items():assert local.digest(folder/'seal.json')==expected
    for source in local.HERE.glob('*.py'):ast.parse(source.read_text(encoding='utf8'))
    original=local.pin(local.NINE,'gravity83.py').read_text();latest=(local.HERE/'refine83.py').read_text()
    for first,last in [('    with np.load(source_restart)','    with np.load(folder/f\'forcing-'),("    with np.load(folder/f'forcing-",'    report=dict(')]:
        assert original[original.index(first):original.index(last)].strip() in latest
    expected_mom=2.**(np.arange(-52,25)/4);restarts=[]
    for model in ('cold','heavy'):
        launch=local.pin(local.START,f'particular-{model}-p4.npz')
        for stage,begin,end,folder in local.STAGES:
            path=local.HERE/stage/f'particular-{model}-p32.npz'
            report=json.loads((path.with_name(f'metric-{model}-p32.json')).read_bytes())
            assert report['passed'] and report['parent']==local.digest(launch) and report['output_digest']==local.digest(path)
            assert report['source_seal']==local.PINS[folder] and report['step_mpc']==.0001953125
            manifest=json.loads((folder/'seal.json').read_bytes())['files']
            names={f'micro-{model}-{node}.npz' for node in range(-52,25)}
            assert set(report['micro'])==names and all(report['micro'][name]==manifest[name] for name in names)
            assert report['quadrature']<1e-12 and report['incident_control']<1e-10
            assert max(report[key] for key in ('seam_metric','seam_stress','time_metric','slope_error','incident_seam'))<=TOL
            assert max(report['iterations'][-1][key] for key in ('stress','metric_increment'))<=TOL
            with np.load(path) as raw:
                assert len(raw['eta'])==32769 and np.array_equal(raw['eta'][[0,-1]],[begin,end])
                assert np.max(abs(np.diff(raw['eta'])-report['step_mpc']))<5e-14
                assert np.array_equal(raw['q'],expected_mom) and raw['lagEnd'].shape[0]==77 and len(raw['stressClock'])==129
                assert all(np.isfinite(raw[key]).all() for key in ('phi','psi','phi_dot','obs','state','lagEnd','stress','shape'))
            restarts.append(dict(model=model,stage=stage,source=rootname(folder),launch=report['parent'],output=report['output_digest']))
            launch=path
    for path,count,keys in [('physical-work.csv',12,('mode','model','target')),('cut-centers.csv',24,('stage','model','field')),('inside-block.csv',12,('mode','model','field')),('rate-checks.csv',6,('mode','model')),('absolute-test.csv',2,('field',)),('p16-replay.csv',6,('model','field')),('seams.csv',12,('mode','model','at_heavy_mpc'))]:
        frame=rows(path);assert len(frame)==len({tuple(row[key] for key in keys) for row in frame})==count
    gains=json.loads(local.pin(local.NINE,'validation.json').read_bytes())['target_shift_in_one_term_radii']
    changes=rows('absolute-test.csv')
    for row in changes:
        field=row['field'];assert abs(float(row['initial_p8_p16_cut'])-gains[field]['end'])<1e-8
        assert abs(float(row['initial_p8_p16_max'])-gains[field]['largest_sampled_shift'])<1e-8
        for key,flag in [('new_end_shift','endpoint_pass'),('new_maximum_shift','sampled_pass')]:
            value=float(row[key]);assert math.isfinite(value) and value>=0 and (row[flag]=='True')==(value<=1)
    checks={}
    for name,count,fields in [('joint-trajectory.csv',96,['relative_error']),('impulse-checks.csv',132,['relative_error']),('impulse-time-step.csv',36,['relative_error']),('inside-block.csv',12,['largest_replay_or_integration_check']),('p16-replay.csv',6,['peak_center_replay_over_radius']),('rate-checks.csv',6,['integration_by_parts_change','quadrature_change','endpoint_disagreement']),('independent-kernel.csv',2,['independent_transfer_uncertainty_over_lapse_radius'])]:
        frame=rows(name);assert len(frame)==count
        values=[max(float(row[key]) for key in fields) for row in frame]
        for row,value in zip(frame,values):assert all(math.isfinite(float(row[key])) and float(row[key])>=0 for key in fields) and (row['passed']=='True')==(value<=TOL)
        checks[name]=dict(tests=count,passes=sum(value<=TOL for value in values),worst=max(values))
    seam_max=max(float(row[key]) for row in rows('seams.csv') for key in ('C_relative_jump','Y_relative_jump','source_identity'))
    assert math.isfinite(seam_max) and seam_max>=0
    attr=rows('lapse-attribution.csv');center=float(next(row['new_end_shift'] for row in changes if row['field']=='Y'))
    assert len(attr)==8 and abs(sum(float(row['projection_over_radius']) for row in attr if row['term']!='final')-center)<1e-8
    decision=dict(relative_tolerance=TOL,step_mpc=.0001953125,coverage_end=83.2,pivot=273.3323213627907,physical_late_evolution_at_pivot=False,model_restarts=restarts,tests=checks,seam_error=seam_max,all_tests_and_sampled_allowances_pass=all(item['passes']==item['tests'] for item in checks.values()) and seam_max<=TOL and all(row['endpoint_pass']=='True' and row['sampled_pass']=='True' for row in changes),center_shift=changes)
    local.record('validation.json',decision)
    if '--seal' in sys.argv:
        assert (local.HERE/'RESULTS.md').is_file() and not list(local.HERE.rglob('__pycache__'))
        local.record('seal.json',dict(files={file.relative_to(local.HERE).as_posix():local.digest(file) for file in sorted(local.HERE.rglob('*')) if file.is_file() and file.name!='seal.json'},parents={folder.name:pin for folder,pin in local.PINS.items()}))
    print(json.dumps(dict(checks=checks,accepted=decision['all_tests_and_sampled_allowances_pass']),indent=2))

def rootname(folder):return folder.name

if __name__=='__main__':check()
