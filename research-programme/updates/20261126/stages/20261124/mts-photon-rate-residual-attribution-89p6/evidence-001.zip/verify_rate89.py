import re
from rate_audit89 import HERE,MODES,ZONES,CHANNELS,parent,seal,io,gate,digest,csv,json,np

def rows(name):
    with (HERE/name).open() as stream:
        return list(csv.DictReader(stream))
def verify():
    io.guard()
    primary=rows('signed-attribution.csv')
    tests=rows('vector-replay.csv')
    assert len(tests)==30
    assert max(float(r[key]) for r in tests for key in ('joint','energy','current') if r[key])<1e-5
    limits=rows('rate-gates.csv')
    assert len(limits)==6 and all(r['passes_size']=='True' and r['passes_rate']=='False' for r in limits)
    assert all(float(r['common_stencil_pct_small'])>.5 for r in limits)
    steps=rows('gravity-step-change.csv')
    assert len(steps)==2 and abs(sum(float(r['signed_fraction']) for r in steps)-1)<1e-6
    controls=rows('numerical-controls.csv')
    for mode in MODES:
        for row in controls:
            if row['mode']==mode and row['source']=='archived_source':
                assert (row['passed_on_gap']=='True')==(row['check']!='gravity')
        for setting in ('primary','time','angle'):
            terms={r['term']:r for r in primary if r['mode']==mode and r['setting']==setting}
            assert len(terms)>20
            for key in ('signed_energy','signed_current','signed_joint'):
                for names in [('matched','negative_reference'),('reference_stencil','common_difference'),
                              ('first_cycle','after_cycle'),tuple('pair_'+z for z in ZONES)]:
                    assert abs(sum(float(terms[n][key]) for n in names)-1)<1e-5
            with np.load(HERE/f'transport-{setting}.npz') as series,np.load(parent(f'photon-{setting}.npz')) as saved:
                idx=list(MODES).index(mode);col=saved['inputs'].tolist().index([mode,'primary'])
                ref=saved['values'][:,col,3]-saved['values'][:,col,1]
                merged=series['values'][:,idx,3:].sum(axis=1)
                assert np.max(abs(merged-ref))/np.max(abs(ref))<1e-5
    for name in ('RESULTS.md','PROTOCOL.md'):
        for link in re.findall(r'\]\(([^)]+)\)',(HERE/name).read_text(encoding='utf-8')):
            assert (HERE/link).is_file()
    for path in HERE.glob('*.py'):
        compile(path.read_bytes(),str(path),'exec')
    dest=HERE/'seal.json'
    manifest={p.name:digest(p) for p in sorted(HERE.iterdir()) if p.is_file() and p!=dest}
    if dest.exists():assert manifest==json.loads(dest.read_bytes())['files']
    else:io.record(dest.name,dict(files=manifest,input_seal=digest(seal)))
    print(len(manifest),'files verified; local seal',digest(dest))
if __name__=='__main__':verify()
