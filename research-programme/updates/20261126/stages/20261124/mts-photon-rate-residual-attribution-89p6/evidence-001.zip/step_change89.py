from rate_audit89 import HERE,io,gate,parent,guard,ZONES,CHANNELS,np,CubicSpline

def analyze():
    guard()
    _,axis,weights,_=gate.proj.old.get_media()
    measure=gate.previous.make_measure(axis,weights)
    signed=lambda one,two: np.sum(measure@(one*two.conj()))
    magnitude=lambda values:gate.mag(values,measure)[2]
    with np.load(HERE/'transport-primary.npz') as data:
        grid=data['grid'];curves=CubicSpline(grid,data['values'])(axis)
    with np.load(parent('photon-primary.npz')) as old:
        col=old['inputs'].tolist().index(['p32','primary'])
        reference=CubicSpline(grid,old['values'][:,col,:3].sum(1))(axis)
    delta=curves[:,1]-curves[:,0]
    gap=delta[:,CHANNELS.index('archived_source')]
    gap_power=signed(gap,gap).real
    def select(key):
        return sum(delta[:,CHANNELS.index(key+'_'+zone)] for zone in ZONES)
    parts={name:select(name) for name in ('matched','negative_reference')}
    assert magnitude(sum(parts.values())-gap)/np.sqrt(gap_power)<1e-6
    rows=[]
    for name,value in parts.items():
        share=signed(value,gap)/gap_power
        rows.append(dict(source=name,signed_fraction=share.real,quadrature=share.imag,
                         size_over_step_change=magnitude(value)/np.sqrt(gap_power),
                         pct_fine_small_correction=100*magnitude(value)/magnitude(reference)))
    assert abs(sum(r['signed_fraction'] for r in rows)-1)<1e-6
    io.table('gravity-step-change.csv',rows)
    print(rows)
if __name__=='__main__':analyze()
