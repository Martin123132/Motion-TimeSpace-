from pathlib import Path
import csv
import hashlib
import json
import sys

import numpy as np
from scipy.interpolate import CubicSpline
from scipy.linalg import solve_banded

HERE = Path(__file__).resolve().parent
ENTRY = HERE.parent / 'mts-entry-phase-flux-forecast-20261124'

def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream,'sha256').hexdigest()

seal = ENTRY/'seal.json'
assert digest(seal)=='267d6a22448b273b7828ec6f20ea10ac452fe66eaab2c46b9cd08012a06c0b29'
files=json.loads(seal.read_bytes())['files']
def parent(name):
    path=ENTRY/name
    assert digest(path)==files[name],name
    return path
sys.path.insert(0,str(ENTRY))
parent('entry89_io.py')
from entry89_io import io,checked,SWITCH,CYCLE,END
checked('photon_gate_89.py')
import photon_gate_89 as gate
io.ROOT=HERE
MODES=('p16','p32')
ZONES=('start_to_2','knots_2_to_4','knots_4_to_8','after_8_to_cycle','later_interior','last_4')
CHANNELS=('archived_source','common_difference','reference_stencil')+tuple(
    branch+'_'+zone for branch in ('matched','negative_reference') for zone in ZONES)
def guard():
    io.guard()
    assert not (ENTRY/'STOP-REQUESTED').exists()
def peak(vector):
    return float(np.max(abs(vector)))

def reconstruct(mode):
    with np.load(parent(f'entry-curves-{mode}-companion.npz')) as raw,np.load(io.old.pin(f'particular-heavy-{mode}.npz')) as wave:
        clock=raw['eta']; native=wave['eta']
        assert clock[0]==SWITCH and clock[-1]==END
        assert np.max(abs(native[-(len(clock)-1):]-clock[1:]))<1e-12
        reference=CubicSpline(native,np.column_stack((wave['phi'],wave['psi'],wave['phi_dot'])))
        sampled=reference(clock)
        native_derivative=CubicSpline(native,reference(native)[:,0])(clock,1)
        reference_rate=sampled[:,2]
        derivative=CubicSpline(clock,raw['phi'])(clock,1)
        matched=derivative-raw['pd']
        minus_ref=reference_rate-native_derivative
        gap=raw['delta_differentiated']-raw['delta_pd']
        crop=CubicSpline(clock,sampled[:,0])(clock,1)
        edge=crop-native_derivative
        common=CubicSpline(clock,raw['phi']-sampled[:,0])(clock,1)-(raw['pd']-reference_rate)
        combined=np.r_[native[native<SWITCH],clock]
        inserted=CubicSpline(combined,reference(combined)[:,0])(clock,1)
        scale=peak(gap)
        checks={'separate_sources':peak(matched+minus_ref-gap)/scale,
                'common_plus_stencil':peak(common+edge-gap)/scale,
                'native_after_inserting_switch':peak(inserted-native_derivative)/scale,
                'reconstructed_matched_derivative':peak(derivative-raw['derivative'])/scale}
        assert max(checks.values())<1e-5,checks
        assert all(np.isfinite(x).all() for x in (matched,minus_ref,edge,common,gap))
        io.pack('sources-'+mode+'.npz',eta=clock,gap=gap,matched=matched,negative_reference=minus_ref,
                common_difference=common,reference_stencil=edge)
        return clock,np.column_stack((gap,common,edge,matched,minus_ref)),checks

def sources():
    shared={}
    for mode in MODES:
        _,_,shared[mode]=reconstruct(mode)
    io.record('source-checks.json',shared)

def load_sources():
    source={}
    for mode in MODES:
        with np.load(HERE/f'sources-{mode}.npz') as store:
            clock=store['eta']
            vals=np.column_stack([store[key] for key in ('gap','common_difference','reference_stencil','matched','negative_reference')])
            source[mode]=(clock,CubicSpline(clock,vals,extrapolate=False))
    coarse=source['p16'][0]
    cuts=coarse[[0,2,4,8,np.searchsorted(coarse,CYCLE),len(coarse)-5,len(coarse)-1]]
    assert np.all(np.diff(cuts)>0)
    return source,cuts

def transport(setting):
    guard()
    source,cuts=load_sources()
    grid,eta,medium,_,_=gate.proj.measure('heavy')
    with np.load(io.old.pin('photon-accumulated-heavy.npz')) as heavy,np.load(io.old.pin('photon-accumulated-cold.npz')) as cold:
        assert np.array_equal(heavy['scale'],grid) and np.array_equal(cold['scale'],grid)
        wave=float(heavy['k'])
    order,sub,stride=gate.transfer.prior.SETTINGS[setting]
    high=source['p32'][0]
    axis=np.unique(np.r_[gate.proj.base_axis(grid,eta,sub),high[::stride],high[-1]])
    start,end=np.searchsorted(axis,[SWITCH,END])
    assert np.array_equal(axis[np.searchsorted(axis,cuts)],cuts)
    rate,stage=gate.proj.coefficients(axis,medium,wave)
    bins=np.searchsorted(cuts[1:-1],(axis[start:end]+axis[start+1:end+1])/2)
    times=np.clip(stage[start:end],SWITCH,END)
    assert np.all(times>=cuts[bins,None]-1e-12) and np.all(times<=cuts[bins+1,None]+1e-12)
    forcing=[]
    for mode in MODES:
        values=source[mode][1](times)
        weighted=np.diff(axis)[start:end,None,None]*np.einsum('st,ntc->nsc',gate.proj.RAD,values)
        forcing.extend([weighted[:,:,idx] for idx in range(3)])
        for idx in (3,4):
            forcing.extend([weighted[:,:,idx]*(bins==zone)[:,None] for zone in range(len(ZONES))])
    impulse=4*np.stack(forcing,axis=2)
    bands=gate.proj.transfer.stages(order)
    nc=bands.shape[-1]//2
    columns=impulse.shape[-1]
    state=np.zeros((nc,2*columns))
    right=np.empty((2*nc,2*columns),order='F')
    pos=np.searchsorted(axis,eta);assert np.array_equal(axis[pos],eta)
    slots=np.full(len(axis),-1); slots[pos]=np.arange(len(eta))
    history=np.zeros((len(eta),columns,2),complex)
    for begin in range(start,len(rate),64):
        if (begin-start)%1024==0: guard()
        stop=min(begin+64,len(rate))
        mats=(rate[begin:stop].reshape(-1,8)@bands.reshape(8,-1)).reshape(-1,11,2*nc);mats[:,5]+=1
        for step,matrix in enumerate(mats,begin):
            right[::2]=state;right[1::2]=state
            if step<end:
                terms=impulse[step-start]
                right[:2,::2]+=terms.real;right[:2,1::2]+=terms.imag
            state=solve_banded((5,5),matrix,right,check_finite=False)[1::2]
            if slots[step+1]>=0:
                history[slots[step+1]]=(state[[0,2],::2]+1j*state[[0,2],1::2]).T
    assert np.isfinite(history).all()
    io.pack('transport-'+setting+'.npz',grid=grid,cuts=cuts,modes=MODES,channels=CHANNELS,
            values=history.reshape(len(grid),len(MODES),len(CHANNELS),2))
    print(setting,'transport complete',flush=True)

if __name__=='__main__':
    for job in sys.argv[1:]:
        sources() if job=='sources' else transport(job)
