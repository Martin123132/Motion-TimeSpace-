from rate_audit89 import HERE,MODES,ZONES,CHANNELS,io,gate,parent,guard,peak,np,CubicSpline,csv
SETTINGS=('primary','time','angle')
def compare():
    guard()
    _,axis,weights,_=gate.proj.old.get_media()
    measure=gate.previous.make_measure(axis,weights)
    metric=lambda values:gate.mag(values,measure)
    archival=list(csv.DictReader(parent('photon-controls.csv').open()))
    norms={r['gravity']:float(r['launch_norm']) for r in csv.DictReader(gate.pin(gate.FROZEN,'window-readouts.csv').open()) if r['output']=='joint' and r['model']=='MTS-minus-baseline'}
    ledger=[];checks=[];controls=[];gates=[];vectors={};denoms={}
    for setting in SETTINGS:
        with np.load(HERE/f'transport-{setting}.npz') as packet,np.load(parent('photon-'+setting+'.npz')) as old:
            grid=packet['grid'];cuts=packet['cuts'];saved=old['values'];groups=old['inputs'].tolist()
            assert np.array_equal(grid,old['scale']) and np.array_equal(packet['channels'],CHANNELS)
            assert np.array_equal(packet['modes'],MODES)
            for index,mode in enumerate(MODES):
                col=groups.index([mode,'primary'])
                archived=saved[:,col,3]-saved[:,col,1]
                momentum=CubicSpline(grid,saved[:,col,:3].sum(1))(axis)
                differentiated=CubicSpline(grid,saved[:,col,[0,3,2],:].sum(1))(axis)
                ref=CubicSpline(grid,archived)(axis)
                scale=metric(ref);den=metric(momentum)
                vals=packet['values'][:,index]
                delta=CubicSpline(grid,vals,axis=0)(axis)
                mapped={label:delta[:,key] for key,label in enumerate(CHANNELS)}
                branch=lambda name:sum(mapped[name+'_'+key] for key in ZONES)
                totals={name:branch(name) for name in ('matched','negative_reference')}
                def check(label,a,b):
                    relative=metric(a-b)/scale
                    checks.append(dict(setting=setting,mode=mode,test=label,energy=relative[0],current=relative[1],joint=relative[2]))
                    assert max(relative)<1e-5,(label,relative)
                check('raw rate vs archived complex gap',mapped['archived_source'],ref)
                check('projected complete routes vs archived complex gap',differentiated-momentum,ref)
                check('signed branches vs archived complex gap',sum(totals.values()),ref)
                check('same-stencil plus edge vs archived complex gap',mapped['common_difference']+mapped['reference_stencil'],ref)
                series_error=peak(vals[:,0]-archived)/peak(archived)
                assert series_error<1e-5,series_error
                checks.append(dict(setting=setting,mode=mode,test='full saved readout grid peak error',energy='',current='',joint=series_error))
                zone_pairs={key:mapped['matched_'+key]+mapped['negative_reference_'+key] for key in ZONES}
                pieces={**mapped,**totals,**{'pair_'+key:vec for key,vec in zone_pairs.items()}}
                for width,count in ((2,1),(4,2),(8,3)):
                    entrance=sum(zone_pairs[key] for key in ZONES[:count])
                    pieces['opening_'+str(width)]=entrance
                    pieces['outside_opening_'+str(width)]=sum(zone_pairs[key] for key in ZONES[count:])
                pieces['first_cycle']=sum(zone_pairs[key] for key in ZONES[:4])
                pieces['after_cycle']=sum(zone_pairs[key] for key in ZONES[4:])
                pieces['interior_no_edges']=sum(zone_pairs[key] for key in ZONES[2:-1])
                for name,vec in pieces.items():
                    inn=measure @ (ref.conj()*vec)
                    signed=np.r_[inn.real,inn.real.sum()]/scale**2
                    amplitudes=metric(vec)/scale
                    remaining=metric(ref-vec)/den
                    scaled=metric(vec)/den
                    ledger.append(dict(setting=setting,mode=mode,term=name,
                        signed_energy=signed[0],signed_current=signed[1],signed_joint=signed[2],
                        norm_over_gap=amplitudes[2],pct_of_small_correction=100*scaled[2],
                        pct_if_removed=100*remaining[2]))
                    if name in ('archived_source','opening_4','outside_opening_4','reference_stencil','common_difference','matched','negative_reference','after_cycle','interior_no_edges'):
                        vectors[setting,mode,name]=vec
                gap=scale/den
                if setting=='primary':
                    target=next(float(row['joint']) for row in archival if row['mode']==mode and row['check']=='rate')
                    assert abs(gap[2]/target-1)<1e-9
                gates.append(dict(setting=setting,mode=mode,gap_pct_small=100*gap[2],energy_pct_small=100*gap[0],current_pct_small=100*gap[1],
                                 gap_pct_launch=100*scale[2]/norms[mode],momentum_pct_launch=100*den[2]/norms[mode],
                                 differentiated_pct_launch=100*metric(differentiated)[2]/norms[mode],
                                 common_stencil_pct_small=100*metric(mapped['common_difference'])[2]/den[2],
                                 passes_size=bool(max(den[2],metric(differentiated)[2])/norms[mode]<.00163),passes_rate=bool(max(gap)<=.005)))
                denoms[setting,mode]=den
    for (setting,mode,name),vec in vectors.items():
        if setting!='primary':continue
        for label,alt in [('time',('time',mode)),('angle',('angle',mode))]+([('gravity',('primary','p16'))] if mode=='p32' else []):
            denom=metric(vectors['primary',mode,'archived_source'])
            err=metric(vectors[(*alt,name)]-vec)/denom
            controls.append(dict(mode=mode,source=name,check=label,energy_over_gap=err[0],current_over_gap=err[1],joint_over_gap=err[2],
                                 joint_pct_small=100*metric(vectors[(*alt,name)]-vec)[2]/denoms['primary',mode][2],passed_on_gap=bool(max(err)<=.005)))
    io.table('signed-attribution.csv',ledger)
    io.table('vector-replay.csv',checks);io.table('numerical-controls.csv',controls);io.table('rate-gates.csv',gates)
    io.record('time-cuts.json',dict(cuts=cuts.tolist(),pieces=ZONES))
    print([r for r in gates if r['setting']=='primary'])
    for row in ledger:
        if row['setting']=='primary' and row['term'] in ('opening_4','after_cycle','reference_stencil','last_4','pair_last_4','matched','negative_reference','interior_no_edges'):
            print(row['mode'],row['term'],round(100*row['signed_joint'],6),round(row['pct_of_small_correction'],6))
if __name__=='__main__':compare()
