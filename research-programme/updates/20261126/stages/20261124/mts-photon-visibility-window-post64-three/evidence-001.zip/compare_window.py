import csv
import io
import json
from window83 import HERE, MODES, np, proj, prior, pinned, digest, guard, save
from scipy.integrate import simpson
from scipy.interpolate import CubicSpline

MODELS = ('cold','heavy','MTS-minus-baseline')
SETTINGS = tuple(prior.SETTINGS)
SLICES = {'first':(0,), 'second':(1,), 'first-two':(0,1), 'third':(2,), 'three':(0,1,2)}
OUTPUTS = ('energy','current','joint')
LIMIT = .005

def export(name,rows):
    stream=io.StringIO()
    writer=csv.DictWriter(stream,rows[0].keys(),lineterminator='\n')
    writer.writeheader()
    writer.writerows(rows)
    save(name,stream.getvalue().encode())

def integrate(values):
    return np.einsum('i,i...->...',measure,values,optimize=False)

def powers(values):
    components=integrate(np.abs(values)**2)
    return np.append(components,components.sum())

def norm(values):
    return np.sqrt(powers(values))

def check(category,model,mode,span,channel,errors,names=OUTPUTS):
    for label,error in zip(names,errors,strict=True):
        checks.append(dict(test=category,model=model,gravity=mode,intervals=span,forcing=channel,output=label,error=float(error),passed=bool(np.isfinite(error) and error<=LIMIT)))

def make_measure(axis,weights):
    assert len(axis)%2==1 and np.allclose(np.diff(axis),axis[1]-axis[0],rtol=1e-10,atol=0)
    pattern=np.ones(len(axis))
    pattern[1:-1:2]=4
    pattern[2:-1:2]=2
    answer=weights*pattern*(axis[-1]-axis[0])/(3*(len(axis)-1))
    assert abs(answer.sum()-1)<1e-12 and np.all(answer>=0)
    return answer

def probability(axis,weights,*fields):
    lower=np.zeros(len(axis)-1)
    upper=np.ones(len(axis)-1)
    for field in fields:
        left,right=field[:-1],field[1:]
        upper[(left<=0)&(right<=0)]=0
        up=(left<=0)&(right>0)
        down=(left>0)&(right<=0)
        lower[up]=np.maximum(lower[up],left[up]/(left[up]-right[up]))
        upper[down]=np.minimum(upper[down],left[down]/(left[down]-right[down]))
    upper=np.maximum(lower,upper)
    mass=np.diff(axis)*(upper-lower)*(weights[:-1]+.5*(lower+upper)*np.diff(weights))
    return float(np.sum(mass)/np.trapezoid(weights,x=axis))

def supports(axis,weights,first,last):
    net=first+last
    delta=abs(net)**2-abs(first)**2
    lower_energy=-delta[:,0]
    higher_current=delta[:,1]
    dominant=abs(net[:,1])**2-abs(net[:,0])**2
    return np.array([probability(axis,weights,*fields) for fields in [(lower_energy,),(higher_current,),(lower_energy,higher_current),(dominant,)]])

def sample(source,span,channel):
    selected=source[:,SLICES[span]].sum(axis=1)
    return selected.sum(axis=1) if channel=='combined' else selected[:,{'energy forcing':0,'momentum forcing':1}[channel]]

def primitive(model,setting,axis):
    if model==MODELS[2]:
        return primitive('heavy',setting,axis)-primitive('cold',setting,axis)
    return histories[model,setting](axis)

def compare():
    global measure
    guard()
    media,axis,weights,peak=proj.old.get_media()
    assert np.isclose(1/axis[-1]-1,750) and np.isclose(1/axis[0]-1,1500) and len(axis)==8193
    measure=make_measure(axis,weights)
    dense=np.linspace(axis[0],axis[-1],16385)
    with np.load(proj.medium_file('medium-cold.npz')) as raw:
        dense_w=CubicSpline(raw['scale'],raw['visibility'],extrapolate=False)(dense)*media['cold']['clock'](dense,1)
    dense_w/=simpson(dense_w,x=dense)
    dense_measure=make_measure(dense,dense_w)
    assert np.array_equal(axis,dense[::2]) and np.allclose(dense_w[::2],weights,rtol=1e-11,atol=0)
    for model in MODELS[:2]:
        with np.load(pinned(f'peak-{model}.npz')) as ref:
            launch[model]=ref['launch']
            for setting in SETTINGS:
                peaks[model,setting]=ref[setting]
            assert float(ref['peak'])==peak
        for setting in SETTINGS:
            with np.load(HERE/f'window-{model}-{setting}.npz') as data:
                assert np.array_equal(data['grid'],media[model]['scale']) and float(data['peak'])==peak
                histories[model,setting]=CubicSpline(data['grid'],data['values'],axis=0,extrapolate=False)
    launch[MODELS[2]]=launch['heavy']-launch['cold']
    for setting in SETTINGS:
        peaks[MODELS[2],setting]=peaks['heavy',setting]-peaks['cold',setting]
    for model in MODELS:
        scale=float(np.linalg.norm(launch[model]))
        assert np.isfinite(scale) and scale>0
        values={setting:primitive(model,setting,axis) for setting in SETTINGS}
        fine=primitive(model,'primary',dense)
        for setting in SETTINGS:
            at=primitive(model,setting,peak)
            ref=peaks[model,setting]
            for mi,mode in enumerate(MODES):
                for index in range(3):
                    for ci,channel in enumerate(('energy forcing','momentum forcing')):
                        check('sealed adjoint peak '+setting,model,mode,str(index+1),channel,abs(at[mi,index,ci]-ref[mi,index,ci])/abs(ref[mi,index,ci]),OUTPUTS[:2])
        for mi,mode in enumerate(MODES):
            main=values['primary'][:,mi]
            for span in SLICES:
                for channel in ('combined','energy forcing','momentum forcing'):
                    ref=sample(main,span,channel)
                    refnorm=norm(ref)
                    assert np.all(refnorm>0)
                    for setting in ('angle','time')+ (('gravity',) if mi==1 else ()):
                        alt=values['primary'][:,0] if setting=='gravity' else values[setting][:,mi]
                        check(setting,model,mode,span,channel,norm(sample(alt,span,channel)-ref)/refnorm)
                    refined=sample(fine[:,mi],span,channel)
                    dense_components=np.einsum('i,ij->j',dense_measure,abs(refined)**2)
                    densenorm=np.sqrt(np.append(dense_components,dense_components.sum()))
                    check('window quadrature',model,mode,span,channel,abs(densenorm/refnorm-1))
                    if channel=='combined':
                        independent=np.array([proj.old.norm_window(ref[:,idx],weights,axis) for idx in range(2)])
                        assert np.allclose(independent,refnorm[:2],rtol=1e-12,atol=0)
                        for oi,label in enumerate(OUTPUTS):
                            rms.append(dict(model=model,gravity=mode,intervals=span,output=label,launch_norm=scale,rms=float(refnorm[oi]),percent_of_launch=float(100*refnorm[oi]/scale)))
            first=sample(main,'first-two','combined')
            last=sample(main,'third','combined')
            net=sample(main,'three','combined')
            assert np.max(abs(first+last-net))<1e-14*np.max(abs(main))
            earlier=norm(first)
            third=norm(last)
            total=norm(net)
            cross=integrate((first.conj()*last).real)
            cross=np.append(cross,cross.sum())
            assert np.allclose(total**2,earlier**2+third**2+2*cross,rtol=1e-12,atol=0)
            at=peaks[model,'primary'][mi].sum(axis=1)
            before_peak=at[:2].sum(axis=0)
            after_peak=at.sum(axis=0)
            peak_ratio=np.append(abs(after_peak)/abs(before_peak),np.linalg.norm(after_peak)/np.linalg.norm(before_peak))
            for oi,label in enumerate(OUTPUTS):
                effects.append(dict(model=model,gravity=mode,output=label,first_two_pct=100*earlier[oi]/scale,third_pct=100*third[oi]/scale,three_pct=100*total[oi]/scale,window_ratio=total[oi]/earlier[oi],peak_ratio=peak_ratio[oi],alignment=cross[oi]/(earlier[oi]*third[oi])))
            base_support=supports(axis,weights,first,last)
            fine_support=supports(dense,dense_w,sample(fine[:,mi],'first-two','combined'),sample(fine[:,mi],'third','combined'))
            names=('energy reduced','current increased','both changes','current larger than energy after')
            check('support quadrature absolute probability',model,mode,'three','combined',abs(fine_support-base_support),names)
            for name,fraction in zip(names,base_support,strict=True):
                support.append(dict(model=model,gravity=mode,condition=name,visibility_probability=fraction))
            for setting in ('time','angle')+(('gravity',) if mi==1 else ()):
                alternative=values['primary'][:,0] if setting=='gravity' else values[setting][:,mi]
                alternate_support=supports(axis,weights,sample(alternative,'first-two','combined'),sample(alternative,'third','combined'))
                check('support '+setting+' absolute probability',model,mode,'three','combined',abs(alternate_support-base_support),names)
    for name,rows in [('window-rms.csv',rms),('peak-vs-window.csv',effects),('visibility-support.csv',support),('checks.csv',checks)]:
        export(name,rows)
    worst={}
    for row in checks:
        category=row['test']
        if category not in worst or row['error']>worst[category]['error']:
            worst[category]=row
    info=dict(parent='mts-photon-peak-post64-three-20261124',passed=all(item['passed'] for item in checks),total_checks=len(checks),failed=sum(not item['passed'] for item in checks),worst=worst,peak_z=1/peak-1,window_z=[1/axis[-1]-1,1/axis[0]-1],tolerance=LIMIT)
    save('validation.json',(json.dumps(info,indent=2,allow_nan=False)+'\n').encode())
    print(json.dumps(info),flush=True)
    assert info['passed'], 'Comparison failures retained; inspect checks before interpreting.'

histories,peaks,launch={},{},{}
checks,rms,effects,support=[],[],[],[]
if __name__=='__main__':
    compare()
