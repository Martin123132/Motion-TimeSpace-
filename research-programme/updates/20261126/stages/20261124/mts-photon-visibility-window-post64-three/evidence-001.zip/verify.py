import json
import sys
from pathlib import Path
from window83 import HERE, PEAK, PARENT_HASH, digest, guard, pinned, save

def main():
    guard()
    parent=json.loads((PEAK/'seal.json').read_bytes())
    for name in parent['files']:
        pinned(name)
    validation=json.loads((HERE/'validation.json').read_bytes())
    assert validation['passed'] and validation['failed']==0 and validation['total_checks']==1245
    files={'PROTOCOL.md','RESULTS.md','window83.py','compare_window.py','verify.py','checks.csv','window-rms.csv','peak-vs-window.csv','visibility-support.csv','validation.json'}
    files.update(f'window-{model}-{setting}.npz' for model in ('cold','heavy') for setting in ('primary','angle','time'))
    assert {path.name for path in HERE.iterdir()}-{'seal.json'}==files
    record=dict(parent=PARENT_HASH,files={name:digest(HERE/name) for name in sorted(files)})
    body=(json.dumps(record,indent=2,sort_keys=True)+'\n').encode()
    if sys.argv[1:]==['--seal']:
        save('seal.json',body)
    assert (HERE/'seal.json').read_bytes()==body
    print('verified',len(files),'files; prior seal verified;',digest(HERE/'seal.json'))

if __name__=='__main__':
    main()
