from pathlib import Path
import hashlib
import io
import json
import sys

HERE = Path(__file__).resolve().parent
PEAK = HERE.parent / 'mts-photon-peak-post64-three-20261124'
PARENT_HASH = '9f37412e0c18888741e44dbd65eff52fc7adde0ee3263fd19ffa8314444755d7'

def digest(path):
    with path.open('rb') as handle:
        return hashlib.file_digest(handle, 'sha256').hexdigest()

def pinned(name):
    assert digest(PEAK/'seal.json') == PARENT_HASH
    path = PEAK/name
    assert digest(path) == json.loads((PEAK/'seal.json').read_bytes())['files'][name], name
    return path

pinned('scatter.py')
pinned('post64_inputs.py')
sys.path.insert(0,str(PEAK))
import scatter as prior
from post64_inputs import proj, np, solve_banded, MODES, load_source, BLOCKS

def guard():
    prior.guard()
    assert not (HERE/'STOP-REQUESTED').exists()

def save(name, data):
    guard()
    path = HERE/name
    if path.exists():
        assert path.read_bytes() == data, name
    else:
        with path.open('xb') as handle:
            handle.write(data)

def propagate(axis,eta,grid,peak,medium,wave,bands,sources,owners):
    rates,stage_t=proj.coefficients(axis,medium,wave)
    nstate=bands.shape[-1]//2
    state=np.zeros((nstate,24));right=np.empty((2*nstate,24),order='F')
    saved=np.zeros((len(grid),2,24));slots=np.searchsorted(axis,eta)
    record_at=np.full(len(axis),-1);record_at[slots]=np.arange(len(grid))
    force=np.zeros((len(rates),2,2,2),complex)
    for mode_idx,mode in enumerate(MODES):
        for idx in range(3):
            active=owners==idx
            values=sources[mode,idx](stage_t[active])
            force[active,mode_idx]=np.diff(axis)[active,None,None]*np.einsum('st,ntc->nsc',proj.RAD,values)
    first=int(np.flatnonzero(owners>=0)[0])
    for start in range(first,len(rates),48):
        if (start-first)%1536==0:guard()
        end=min(start+48,len(rates))
        matrices=(rates[start:end].reshape(-1,8)@bands.reshape(8,-1)).reshape(-1,11,2*nstate);matrices[:,5]+=1
        for step,mat in enumerate(matrices,start):
            right[::2]=state;right[1::2]=state
            block=owners[step]
            if block>=0:
                for method in range(2):
                    for row,fac,channel in ((0,4.,0),(2,4*wave/3,1),(4,4*wave/3,1)):
                        column=((method*3+block)*2+channel)*2
                        value=fac*force[step,method,:,channel]
                        right[row:row+2,column]+=value.real;right[row:row+2,column+1]+=value.imag
            state=solve_banded((5,5),mat,right,check_finite=False)[1::2]
            slot=record_at[step+1]
            if slot>=0:saved[slot]=state[[0,2]]
    complex_samples = saved[:,:,::2] + 1j*saved[:,:,1::2]
    return complex_samples.reshape(len(grid),2,2,3,2).transpose(0,2,3,4,1)

def run(model):
    guard()
    assert model in ('heavy','cold')
    source_text = pinned('scatter.py').read_text()
    own_text = Path(__file__).read_text()
    core = source_text.split('def propagate(',1)[1].split('    peak_samples=',1)[0]
    assert ('def propagate('+core) in own_text
    grid,eta,medium,peak,_ = proj.measure(model)
    receipt = json.loads(pinned(f'inputs-{model}.json').read_bytes())
    assert digest(Path(proj.transfer.__file__)) == receipt['operator_sha256']
    assert digest(proj.medium_file(f'medium-{model}.npz')) == receipt['medium']
    assert receipt['peak_scale'] == peak
    wave = receipt['wavenumber']
    splines = {}
    times = []
    for index,(_,_,label,_) in enumerate(BLOCKS):
        for mode in MODES:
            time,splines[mode,index],number,checksum = load_source(model,index,mode)
            assert number == wave and checksum == receipt['source_sha256'][f'{label}-{mode}']
            if mode=='p32':
                times.append(time)
                assert np.allclose(time[::2],coarse,atol=2e-14,rtol=0)
            else:
                coarse=time
    for setting,(order,sub,stride) in prior.SETTINGS.items():
        guard()
        axis,owners = prior.mesh(grid,eta,times,sub,stride)
        with np.load(pinned(f'{model}-{setting}.npz')) as ref:
            assert int(ref['total_photon_steps']) == len(owners)
            assert np.array_equal(ref['source_interval_steps'],np.bincount(owners[owners>=0]))
        values = propagate(axis,eta,grid,peak,medium,wave,proj.transfer.stages(order),splines,owners)
        assert values.shape == (len(grid),2,3,2,2) and np.isfinite(values).all()
        buffer = io.BytesIO()
        np.savez_compressed(buffer,grid=grid,values=values,peak=peak,wave=wave)
        save(f'window-{model}-{setting}.npz',buffer.getvalue())
        print(model,setting,'complete',len(owners),flush=True)

if __name__=='__main__':
    run(sys.argv[1])
