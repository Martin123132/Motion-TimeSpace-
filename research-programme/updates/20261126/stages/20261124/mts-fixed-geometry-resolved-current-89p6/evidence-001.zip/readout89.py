import csv
from unittest.mock import patch
from scipy.interpolate import CubicSpline
from restore89 import ROOT,io,checked,archived,guard,path,MODES,digest,np,json

checked('photon_gate_89.py')
import photon_gate_89 as gate

SETTINGS=('primary','time','angle')
CELLS=('base','restored')

def photons():
    guard()
    grid,eta,medium,_,_=gate.proj.measure('heavy')
    with np.load(io.old.pin('photon-accumulated-heavy.npz')) as heavy,np.load(io.old.pin('photon-accumulated-cold.npz')) as cold:
        assert np.array_equal(grid,heavy['scale']) and np.array_equal(grid,cold['scale']) and heavy['k']==cold['k']
        wave=float(heavy['k'])
    histories={}
    for mode in MODES:
        for cell in CELLS:
            with np.load(path(mode,cell,'curves')) as data:
                histories[mode,'primary' if cell=='base' else cell]={key:data[key] for key in ('eta','delta_pd','delta_psi','delta_differentiated','kick')}
    with patch.object(gate.transfer,'ps',gate.Interface()):
        for setting in SETTINGS:
            guard()
            values=gate.transfer.transfer(setting,eta,grid,medium,wave,histories)
            with np.load(archived('photon-'+setting+'.npz')) as saved:
                for mode in MODES:
                    prev=saved['values'][:,saved['inputs'].tolist().index([mode,'primary'])]
                    now=values[:,list(histories).index((mode,'primary'))]
                    assert np.max(abs(now-prev))/np.max(abs(prev))<1e-10
            assert np.isfinite(values).all()
            io.pack('photon-'+setting+'.npz',grid=grid,labels=list(histories),channels=['kick','rate','lapse','differentiated'],values=values)
            print(setting,'photon transport complete',flush=True)

def scores():
    _,axis,weights,_=gate.proj.old.get_media()
    measure=gate.previous.make_measure(axis,weights)
    mag=lambda vector:gate.mag(vector,measure)
    def share(vector,reference):
        inner=measure@(reference.conj()*vector).real
        return np.r_[inner,inner.sum()]/mag(reference)**2
    with gate.pin(gate.FROZEN,'window-readouts.csv').open() as stream:
        launch={r['gravity']:float(r['launch_norm']) for r in csv.DictReader(stream) if r['output']=='joint' and r['model']=='MTS-minus-baseline'}
    refdir=ROOT.parent/'mts-photon-rate-residual-attribution-89p6-20261124'
    assert digest(refdir/'seal.json')=='0dec918ee446f14c2c5f0b8e1dfd0dc8fe9a361cece477e11ae4271f71c87c09'
    manifest=json.loads((refdir/'seal.json').read_bytes())['files']
    gates=[];effects=[];controls=[];metric=[];cache={}
    for mode in MODES:
        for cell in CELLS:
            with np.load(path(mode,cell,'ledger')) as data:
                for label,mask in [('first_cycle',data['eta']<=89.24159032),('complete',np.ones(len(data['eta']),bool))]:
                    for seed in (0,1):
                        frac=np.max(abs(data['total'][mask,seed]))/np.max(abs(data['rate'][mask,seed]))
                        metric.append(dict(mode=mode,cell=cell,window=label,seed=seed,relative=frac,passed=bool(frac<=.005)))
        for setting in SETTINGS:
            name='transport-'+setting+'.npz';assert digest(refdir/name)==manifest[name]
            with np.load(refdir/name) as reference,np.load(ROOT/('photon-'+setting+'.npz')) as data:
                grid=data['grid'];assert np.array_equal(grid,reference['grid'])
                interp=lambda v:CubicSpline(grid,v)(axis)
                neg=[i for i,k in enumerate(reference['channels'].tolist()) if k.startswith('negative_reference_')]
                assert neg
                negref=interp(reference['values'][:,list(MODES).index(mode)][:,neg].sum(1))
                for cell in CELLS:
                    idx=data['labels'].tolist().index([mode,'primary' if cell=='base' else cell])
                    values=data['values'][:,idx]
                    mom=interp(values[:,:3].sum(1));diff=interp(values[:,[0,3,2]].sum(1))
                    gap=interp(values[:,3]-values[:,1]);assert (mag(gap-(diff-mom))/mag(gap)).max()<1e-7
                    cache[mode,setting,cell]={'momentum':mom,'gap':gap,'differentiated':diff}
                    start=cache[mode,setting,'base'];basegap=mag(start['gap']);baseden=mag(start['momentum'])
                    pct=100*mag(gap)/mag(mom);common=100*mag(gap)/baseden
                    pm=100*mag(mom)[2]/launch[mode];pd=100*mag(diff)[2]/launch[mode]
                    gates.append(dict(mode=mode,setting=setting,cell=cell,energy_pct=pct[0],current_pct=pct[1],joint_pct=pct[2],common_joint_pct=common[2],precision_pass=bool(max(pct)<=.5),momentum_launch_pct=pm,differentiated_launch_pct=pd,size_pass=bool(max(pm,pd)<.163),matched_joint_pct_common=100*mag(gap-negref)[2]/baseden[2],reference_joint_pct_common=100*mag(negref)[2]/baseden[2]))
                    if cell=='restored':
                        removed=start['gap']-gap;proj=share(removed,start['gap']);red=1-mag(gap)/basegap
                        for index,component in enumerate(('energy','current','joint')):
                            effects.append(dict(mode=mode,setting=setting,component=component,signed_removed=proj[index],norm_reduction=red[index],remaining_common_pct=common[index]))
    for mode in MODES:
        for cell in CELLS:
            for term,vec in cache[mode,'primary',cell].items():
                for label,other,setting in [('time',mode,'time'),('angle',mode,'angle')]+([('gravity','p16','primary')] if mode=='p32' else []):
                    distance=mag(vec-cache[other,setting,cell][term]); rel=distance/mag(vec)
                    controls.append(dict(mode=mode,cell=cell,term=term,test=label,energy=rel[0],current=rel[1],joint=rel[2],passed=bool(max(rel)<=.005)))
    for name,rows in [('photon-gates',gates),('gap-effects',effects),('controls',controls),('metric-gates',metric)]:
        io.table(name+'.csv',rows)
    print([r for r in gates if r['setting']=='primary'],flush=True)

if __name__=='__main__':
    photons();scores()
