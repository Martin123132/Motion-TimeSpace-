from pathlib import Path
from unittest.mock import patch
import hashlib
import json
import sys
import numpy as np
from scipy.interpolate import CubicSpline,make_interp_spline

ROOT=Path(__file__).resolve().parent
PRIOR=ROOT.parent/'mts-fixed-U-Q-Fq-89p6-20261124'
def digest(path):
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
SEAL='484a38ba2b67b11c524d8fc8ce624f8082d9094289a44b6b562e51c72a3d4b7f'
assert digest(PRIOR/'seal.json')==SEAL
manifest=json.loads((PRIOR/'seal.json').read_bytes())['files']
def prior(name):
    path=PRIOR/name
    assert digest(path)==manifest[name],name
    return path
sys.path.insert(0,str(PRIOR))
prior('fixed89.py')
import fixed89 as fixed
from fixed89 import io,archived,checked,MODES,SWITCH,END,array_hash
io.ROOT=ROOT
def guard():
    fixed.guard()
    assert not (PRIOR/'STOP-REQUESTED').exists()
def peak(x):return float(np.max(abs(x)))
def ratio(err,scale):
    assert peak(scale)>0
    return peak(err)/peak(scale)
def companion(mode):
    return io.checked(f'companion-{mode}.npz')
def path(mode,cell,kind):
    if cell=='base':return fixed.packet('base',mode,kind)
    assert cell=='restored'
    return ROOT/(f'ledger-{mode}-restored.npz' if kind=='ledger' else f'restored-curves-{mode}-companion.npz')

def prepare(mode):
    guard()
    io.checked('wave_kernel.py');io.checked('companion.py')
    import wave_kernel as kernel
    phase,wave,kk,mass,rho=kernel.read(mode)
    with np.load(companion(mode)) as store:old=dict(store.items())
    time=old['eta'];theta=phase(time);theta[abs(theta)<1e-10]=0
    assert kk==old['k2'] and rho==old['rho0'] and time[0]==SWITCH and time[-1]==END
    with np.load(io.old.pin('matched-native/linear-heavy-00.npz')) as src:
        hub=CubicSpline(src['eta'],src['values'][0,:,src['keys'].tolist().index('adotoa')])(time)[:,None]
    cs=old['cs2'][:,None];key=lambda name:old['companion_'+name]
    change_j=-old['delta_j'];change_e=-old['delta_d'];change_p=-old['delta_p']
    new={name:old[name] for name in ('eta','cs2','k2','rho0','scale','corners')}
    for name in ('shear','source_e','source_j'):new['companion_'+name]=key(name)
    raw_e,raw_j,raw_p=[wave[n](theta) for n in ('e','j','p')]
    raw_res=raw_p-cs*(raw_e+3*hub*raw_j/kk)
    new.update(companion_e=raw_e,companion_j=raw_j,companion_pres_res=raw_res)
    av,rate,ind_j,_,=kernel.sample('primary',time,phase,wave,96,kk,mass,rho)
    momentum_slope=wave['j'](theta,1)*phase(time,1)[:,None]
    flat_slope=wave['flat'](theta,1)*phase(time,1)[:,None]
    keep=np.ones(len(time),bool)
    for corner in old['corners']:keep&=(abs(time-corner)>2e-8)|(time==corner)
    primitive=CubicSpline(time[keep],(-change_j-3*hub*change_p)[keep]).antiderivative()
    eq_e=-raw_j-3*hub*raw_p+key('source_e')
    eq_j=-hub*raw_j+kk*(raw_p+wave['psi'](theta))+key('source_j')
    rows=[]
    for seed in (0,1):
        def test(name,err,scale):
            value=ratio(err[:,seed],scale[:,seed])
            rows.append(dict(mode=mode,seed=seed,test=name,relative=value,passed=bool(value<=.005)))
        test('current reversal reproduces raw current',key('j')+change_j-raw_j,raw_j)
        test('energy reversal reproduces raw density',key('e')+change_e-raw_e,raw_e)
        old_p=key('pres_res')+cs*(key('e')+3*hub*key('j')/kk)
        test('pressure reversal reproduces raw pressure',old_p+change_p-raw_p,raw_p)
        test('pressure shift from independent current slopes',momentum_slope-ind_j+hub*change_j-kk*change_p,kk*change_p)
        test('integrated density shift at fixed common metric',primitive(time)-primitive(time[0])-change_e,change_e)
        test('resolved external-work energy balance',flat_slope-eq_e,eq_e)
        test('resolved external-work momentum balance',momentum_slope-eq_j,eq_j)
        test('unchanged entry density',(raw_e-key('e'))[:1],raw_e)
        test('unchanged entry current',(raw_j-key('j'))[:1],raw_j)
    with np.load(io.checked(f'projected-{mode}.npz')) as split:
        for name,raw in [('e',raw_e),('j',raw_j),('pres_res',raw_res)]:
            assert ratio(split['resolved_'+name]-raw,raw)<1e-10
    for name,alias in [('shear','shear'),('source_e','se'),('source_j','sj')]:
        assert np.array_equal(new['companion_'+name],wave[alias](theta))
    io.table('preparation-'+mode+'.csv',rows)
    failures=[r for r in rows if not r['passed']]
    if failures:
        import csv
        with io.checked(f'transfer-checks-{mode}.csv').open() as handle:
            inherited=list(csv.DictReader(handle))
        for row in failures:
            assert row['test']=='resolved external-work energy balance' and any(r['case']=='resolved' and int(r['seed'])==row['seed'] and r['check']=='energy_balance' and r['passed']=='False' for r in inherited),row
    io.record('preparation-status-'+mode+'.json',dict(complete_pass=not failures,failures=failures,
              use='diagnostic only' if failures else 'eligible for readout tests'))
    io.pack('companion-'+mode+'.npz',**new)
    print(mode,'resolved inputs verified; failed preparation checks:',failures,flush=True)

def replay_current(mode):
    guard();checked('replay.py');checked('ledger.py')
    import replay
    original=replay.matter.get_flow;audit={}
    with np.load(archived('primary.npz')) as src:
        frozen=make_interp_spline(np.log(src['eta']),src['restore'],k=5)
    class Restored(replay.Receipts):
        HERE=ROOT
    def fixed_inputs(folder,case,clock,initial,projection=None):
        flow=original(folder,case,clock,initial,projection)
        if projection is None:return flow
        q=flow.q;index=flow.qkeys.index('U')
        def locked(at):
            raw=q(at).copy();raw[...,index,0]+=frozen(at);return raw
        flow.q=locked
        raw=q(flow.log);used=locked(flow.log)
        remain=np.arange(len(flow.qkeys))!=index
        assert np.array_equal(raw[:,remain],used[:,remain])
        parent=json.loads(prior(f'input-audit-{mode}-both.json').read_bytes())
        assert array_hash(used[:,index])==parent['U_hash']
        for key in ('Q','Fq'):
            assert array_hash(used[:,flow.qkeys.index(key)])==parent['receipt'][key]['host']
        audit.update(U_hash=parent['U_hash'],fixed_external_columns=len(flow.qkeys),clock=len(flow.log))
        return flow
    with patch.object(replay,'Receipts',Restored),patch.object(replay.matter,'get_flow',fixed_inputs):
        replay.run(mode,'restored','matched')
    with np.load(path(mode,'base','ledger')) as base,np.load(path(mode,'restored','ledger')) as new:
        assert np.array_equal(base['eta'],new['eta']) and np.array_equal(base['den'],new['den']) and np.array_equal(base['hub'],new['hub'])
        for name in ('U','Q','Fq'):
            idx=new['keys'].tolist().index(name)
            for col in ('phi','slip','pd','residual'):assert np.array_equal(base[col][idx],new[col][idx])
    with np.load(path(mode,'base','curves')) as base,np.load(path(mode,'restored','curves')) as new:
        for key in ('e','j'):
            assert ratio((new[key]-base[key])[:1],base[key])<1e-10
    junction=json.loads((ROOT/f'restored-junction-{mode}-companion.json').read_bytes())
    tracked={k:v for k,v in junction.items() if k.startswith(('normal_','seed0_','seed1_','entry_e','entry_j'))}
    assert max(tracked.values())<.005,tracked
    io.record('fixed-inputs-'+mode+'.json',dict(audit=audit,tracked=tracked,control=archived('frozen.json').name,
                  forecast_hash=digest(archived('primary.npz')),restored_hash=digest(ROOT/f'companion-{mode}.npz')))
    print(mode,'frozen geometry and normal entry confirmed',flush=True)
if __name__=='__main__':
    for mode in sys.argv[1:]:
        assert mode in MODES
        prepare(mode);replay_current(mode)
