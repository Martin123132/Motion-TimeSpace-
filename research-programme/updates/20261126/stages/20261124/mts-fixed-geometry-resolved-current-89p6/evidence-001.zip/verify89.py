import csv
import re
from restore89 import ROOT,io,digest,SEAL,guard,np,json,MODES,path,prior,archived

def read(name):
    with (ROOT/name).open() as stream:return list(csv.DictReader(stream))

def verify():
    guard();checks=[]
    def require(label,ok):
        assert ok,label
        checks.append(label)
    for mode in MODES:
        coarse=mode=='p16'
        src=read(f'preparation-{mode}.csv')
        require(mode+' source results',len(src)==18 and all((r['passed']=='True')==(float(r['relative'])<=.005) for r in src))
        fails=[r for r in src if r['passed']=='False']
        require(mode+' only inherited exceptions',len(fails)==(2 if coarse else 0) and all(r['test']=='resolved external-work energy balance' for r in fails))
        note=json.loads((ROOT/f'preparation-status-{mode}.json').read_bytes())
        require(mode+' preflight classification',note['complete_pass']==(not coarse) and len(note['failures'])==len(fails))
        receipt=json.loads((ROOT/f'fixed-inputs-{mode}.json').read_bytes())
        require(mode+' frozen forecast',receipt['audit']['U_hash']==json.loads(prior(f'input-audit-{mode}-both.json').read_bytes())['U_hash'] and receipt['forecast_hash']==digest(archived('primary.npz')))
        with np.load(path(mode,'base','ledger')) as base,np.load(path(mode,'restored','ledger')) as out:
            require(mode+' geometry identical',all(np.array_equal(out[key][out['keys'].tolist().index(source)],base[key][base['keys'].tolist().index(source)]) for source in ('U','Q','Fq') for key in ('phi','pd','slip','residual')))
        require(mode+' entry and state tracking',max(receipt['tracked'].values())<.005)
    rows=read('state-balance.csv');require('all actual energy and momentum integrals',len(rows)==16 and all(max(float(r[k]) for k in ('local_rate_relative','path_drift_relative','quadrature_relative'))<=.005 and r['passed']=='True' for r in rows))
    gates=read('photon-gates.csv');require('photon coverage',len({(r['mode'],r['setting'],r['cell']) for r in gates})==12)
    for r in gates:
        require('gate '+str((r['mode'],r['setting'],r['cell'])),(r['precision_pass']=='True')==(max(float(r[k]) for k in ('energy_pct','current_pct','joint_pct'))<=.5) and (r['size_pass']=='True')==(max(float(r[k]) for k in ('momentum_launch_pct','differentiated_launch_pct'))<.163))
    with prior('photon-gates.csv').open() as stream:prev=list(csv.DictReader(stream))
    for r in gates:
        if r['cell']!='base':continue
        old=next(s for s in prev if (s['mode'],s['setting'],s['cell'])==(r['mode'],r['setting'],'base'))
        require('old photon baseline '+r['mode']+r['setting'],all(abs(float(r[key])-float(old[key]))<=1e-9 for key in ('energy_pct','current_pct','joint_pct','momentum_launch_pct')))
    effects=read('gap-effects.csv')
    for r in effects:
        if r['component']!='joint':continue
        cells={v['cell']:v for v in gates if (v['mode'],v['setting'])==(r['mode'],r['setting'])}
        reduction=1-float(cells['restored']['common_joint_pct'])/float(cells['base']['common_joint_pct'])
        require('common denominator '+r['mode']+r['setting'],abs(reduction-float(r['norm_reduction']))<1e-12)
    require('metric gates',all(r['passed']=='True' for r in read('metric-gates.csv')) and len(read('metric-gates.csv'))==16)
    controls=read('controls.csv')
    require('refinement controls',len(controls)==30 and all((r['passed']=='True')==(max(float(r[k]) for k in ('energy','current','joint'))<=.005) for r in controls))
    closure=[r for r in read('change-attribution.csv') if r['term'].endswith('_transfer')]
    require('independent propagated ledger',len(closure)==4 and all(max(float(r[k]) for k in ('max_component_over_old_gap','joint_over_change'))<.005 for r in closure))
    require('adjoint checks',all(np.isfinite(float(r['relative'])) and float(r['relative'])<.005 for r in read('photon-adjoint.csv')))
    for code in ROOT.glob('*.py'):compile(code.read_bytes(),str(code),'exec')
    require('no temporary cache',not (ROOT/'__pycache__').exists())
    io.record('validation.json',dict(checks=checks,integrity_pass=True,coarse_preparation_pass=False,fine_preparation_pass=True,photon_size_pass=True,photon_route_agreement_pass=False))
    for note in ROOT.glob('*.md'):
        for link in re.findall(r'\]\(([^)]+)\)',note.read_text(encoding='utf-8')):assert (ROOT/link).is_file(),link
    seal=ROOT/'seal.json';files={p.name:digest(p) for p in sorted(ROOT.iterdir()) if p.is_file() and p!=seal}
    io.record('seal.json',dict(files=files,prior=SEAL))
    assert files==json.loads(seal.read_bytes())['files']
    print(len(checks),'integrity checks;',len(files),'files;',digest(seal))
if __name__=='__main__':verify()
