from restore89 import ROOT,io,guard,path,MODES,np,json,digest,fixed,sys
from readout89 import gate
from scipy.interpolate import CubicSpline

def compare(mode):
    guard()
    toolkit=fixed.previous.LEDGER
    name='matched_ledger89.py'
    assert digest(toolkit/name)==json.loads((toolkit/'seal.json').read_bytes())['files'][name]
    sys.path.insert(0,str(toolkit))
    import matched_ledger89 as transport
    io.ROOT=ROOT
    with np.load(path(mode,'base','ledger')) as base,np.load(path(mode,'restored','ledger')) as out:
        clock=base['eta'];parts=out['residual'][:,:,0]-base['residual'][:,:,0]
        keys=base['keys'].tolist();assert not np.any(parts[[keys.index(name) for name in ('U','Q','Fq')]])
        heavy=keys.index('heavy_companion')
        terms={'heavy':parts[heavy],'induced':np.delete(parts,heavy,axis=0).sum(0),'all':out['total'][:,0]-base['total'][:,0]}
    transport.transport(mode,'primary',clock,list(terms),np.column_stack(list(terms.values())))

def score():
    _,axis,weights,_=gate.proj.old.get_media()
    measure=gate.previous.make_measure(axis,weights)
    mag=lambda z:gate.mag(z,measure)
    rows=[]
    for mode in MODES:
        with np.load(ROOT/f'responses-{mode}-primary.npz') as terms,np.load(ROOT/'photon-primary.npz') as ph:
            grid=ph['grid'];assert np.array_equal(grid,terms['grid'])
            spline=lambda z:CubicSpline(grid,z)(axis)
            def gap(cell):
                data=ph['values'][:,ph['labels'].tolist().index([mode,cell])]
                return spline(data[:,3]-data[:,1])
            old,new=gap('primary'),gap('restored');change=new-old
            val=terms['values'][:,terms['windows'].tolist().index('complete')]
            parts={key:spline(val[:,i]) for i,key in enumerate(terms['labels'].tolist())}
            for key,piece in {**parts,'sum_minus_transfer':parts['heavy']+parts['induced']-change,'total_minus_transfer':parts['all']-change}.items():
                inner=measure@(change.conj()*piece).real
                rows.append(dict(mode=mode,term=key,signed_share_change=inner.sum()/mag(change)[2]**2,joint_over_change=mag(piece)[2]/mag(change)[2],joint_over_old_gap=mag(piece)[2]/mag(old)[2],max_component_over_old_gap=max(mag(piece)/mag(old))))
            assert max(row['max_component_over_old_gap'] for row in rows if row['term'].endswith('_transfer'))<=.005
    io.table('change-attribution.csv',rows)

if __name__=='__main__':
    for mode in MODES:compare(mode)
    score()
