from numpy.polynomial.legendre import leggauss
from scipy.interpolate import CubicSpline
from restore89 import ROOT,io,companion,path,MODES,guard,np

def audit(mode,cell):
    receipt=companion(mode) if cell=='base' else ROOT/f'companion-{mode}.npz'
    with np.load(receipt) as source,np.load(path(mode,cell,'curves')) as run,np.load(path(mode,cell,'ledger')) as led:
        clock=led['eta'];assert np.array_equal(clock,run['eta'])
        phi=led['phi'].sum(0);psi=phi+led['slip'].sum(0)
        energy=run['e'];current=run['j'];flat=energy-3*phi
        states=np.column_stack((energy,current,psi,led['hub'][:,0]))
        interp=CubicSpline(clock,states);fields=np.column_stack((source['cs2'],*[source['companion_'+key] for key in ('pres_res','source_e','source_j')]))
        knots=source['eta'];cuts=source['corners'];wave2=float(source['k2']);segments=[]
        for left,right in zip(np.r_[-np.inf,cuts],np.r_[cuts,np.inf]):
            use=(knots>=left+5e-9)&(knots<=right-5e-9)
            segments.append(CubicSpline(knots[use],fields[use]))
    t=np.unique(np.r_[clock,cuts]);left=t[:-1];right=t[1:];mid=(left+right)/2
    bins=np.searchsorted(clock,mid,side='right')-1
    branches=np.searchsorted(cuts,mid)
    def integrate(order):
        nodes,weights=leggauss(order);at=mid[:,None]+(right-left)[:,None]*nodes/2
        coef=np.empty((*at.shape,7),dtype=fields.dtype)
        for index,segment in enumerate(segments):
            use=branches==index;coef[use]=segment(at[use])
        state=interp(at);en=state[:,:,:2];curr=state[:,:,2:4];psi=state[:,:,4:6];hub=state[:,:,6:]
        press=coef[:,:,1:3]+coef[:,:,:1]*(en+3*hub*curr/wave2)
        rhs=np.concatenate((-curr-3*hub*press+coef[:,:,3:5],-hub*curr+wave2*(press+psi)+coef[:,:,5:]),axis=2)
        result=np.zeros((len(clock)-1,4),dtype=np.result_type(states,fields))
        np.add.at(result,bins,np.einsum('q,iqc,i->ic',weights,rhs,(right-left)/2))
        return result
    coarse=integrate(4);fine=integrate(8);dt=np.diff(clock);ys=np.column_stack((flat,current));rows=[]
    for i in range(4):
        integral=fine[:,i];change=np.diff(ys[:,i]);err=abs((change-integral)/dt)
        drift=abs((ys[1:,i]-ys[0,i])-np.cumsum(integral))
        rate=err.max()/np.max(abs(integral/dt));acc=drift.max()/np.max(abs(ys[:,i]-ys[0,i]))
        quad=np.max(abs((integral-coarse[:,i])/dt))/np.max(abs(integral/dt))
        rows.append(dict(mode=mode,cell=cell,quantity='flat_energy' if i<2 else 'momentum',seed=i%2,local_rate_relative=rate,path_drift_relative=acc,quadrature_relative=quad,worst_cell_end=clock[1:][np.argmax(err)],passed=bool(max(rate,acc,quad)<=.005)))
    return rows
if __name__=='__main__':
    guard()
    rows=[row for mode in MODES for cell in ('base','restored') for row in audit(mode,cell)]
    io.table('state-balance.csv',rows);print('balance failures:',[r for r in rows if not r['passed']],flush=True)
