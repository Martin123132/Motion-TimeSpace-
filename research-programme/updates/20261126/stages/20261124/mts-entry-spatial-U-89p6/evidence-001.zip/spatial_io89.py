from pathlib import Path
import hashlib
import json
import sys

ROOT=Path(__file__).resolve().parent
ENTRY=ROOT.parent/'mts-entry-phase-flux-forecast-20261124'
LEDGER=ROOT.parent/'mts-matched-photon-ledger-89p6-20261124'
def digest(path):
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
assert digest(LEDGER/'seal.json')=='2e53faf5765e91058141696d746dadcd52d1488bb11952f7a07d2c664860d208'
assert digest(ENTRY/'seal.json')=='267d6a22448b273b7828ec6f20ea10ac452fe66eaab2c46b9cd08012a06c0b29'
files=json.loads((ENTRY/'seal.json').read_bytes())['files']
def entry(name):
    path=ENTRY/name;assert digest(path)==files[name],name
    return path
sys.path.insert(0,str(ENTRY))
entry('entry89_io.py')
from entry89_io import io,checked,SWITCH,CYCLE,END
io.ROOT=ROOT
def guard():
    io.guard()
    assert all(not (folder/'STOP-REQUESTED').exists() for folder in (ENTRY,LEDGER))
def frozen():
    status=json.loads((ROOT/'frozen.json').read_bytes())
    assert all(digest(ROOT/name)==value for name,value in status['files'].items())
    return status
