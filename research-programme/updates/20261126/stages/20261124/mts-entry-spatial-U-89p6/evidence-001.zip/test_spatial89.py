import sys
from unittest.mock import patch
import numpy as np
from scipy.interpolate import make_interp_spline
from spatial_io89 import ROOT,SWITCH,CYCLE,END,entry,digest,io,checked,guard,frozen

PARTS=('potential_square','laplacian','gradient')
def lock():
    guard();frozen()
    assert digest(ROOT/'frozen.json')=='f63de5c7bb73df867f8640b86a22bb6fe8c33e3667faa84a61fcf4e28d86cb03'
def scores():
    lock()
    checked('geometry_sources_89.py')
    from geometry_sources_89 import inputs
    eta,k,fluid=inputs('matched');tw,kw,wave=inputs('wave')
    assert np.array_equal(eta,tw) and np.array_equal(k,kw)
    modes=k[:,None]
    actual=dict(phi_f=fluid['phi'],phi_w=wave['phi'],delta_phi=wave['phi']-fluid['phi'])
    deltah=wave['adotoa']-fluid['adotoa']
    exact_pieces={'synchronous_curvature':(wave['etak']-fluid['etak'])/modes,
                  'shear_difference':-wave['adotoa']*(wave['sigma']-fluid['sigma'])/modes,
                  'expansion_difference':-deltah*fluid['sigma']/modes}
    with np.load(checked('native-U.npz')) as native:
        assert np.array_equal(eta,native['eta'])
        for key in PARTS:actual[key]=native['wave_'+key]-native['matched_'+key]
        actual['spatial']=sum(actual[key] for key in PARTS)
        actual['locked_flux']=native['wave_flux_square']-native['matched_flux_square']
        actual['restore']=actual['spatial']+actual['locked_flux']
    rows=[];budgets=[]
    for method in ('primary','width','algebra','no_spatial'):
        with np.load(ROOT/(('primary' if method=='no_spatial' else method)+'.npz')) as pack:
            assert np.array_equal(pack['eta'],eta) and np.array_equal(pack['k'],k)
            predicted={key:pack[key] for key in (*PARTS,'delta_phi','phi_f','spatial','restore','locked_flux')}
            predicted['phi_w']=predicted['phi_f']+predicted['delta_phi']
            if method=='no_spatial':
                predicted={key:val*0 for key,val in predicted.items() if key in PARTS or key in ('spatial','delta_phi')}
                predicted.update(restore=pack['locked_flux'],locked_flux=pack['locked_flux'])
            else:
                forecast_pieces={'synchronous_curvature':pack['deta']/modes,
                                 'shear_difference':-pack['hw']*pack['dsigma']/modes,
                                 'expansion_difference':-(pack['hw']-pack['hf'])*pack['sigma_f']/modes}
                error=predicted['delta_phi']-actual['delta_phi']
                terms={name:forecast_pieces[name]-exact_pieces[name] for name in exact_pieces}
                relative=np.max(abs(sum(terms.values())-error))/np.max(abs(actual['delta_phi']))
                assert relative<1e-7,relative
                for window,stop in (('cycle',CYCLE),('complete',END)):
                    sel=eta<=stop
                    for name,val in terms.items():
                        total=error[:,sel];piece=val[:,sel]
                        budgets.append(dict(method=method,window=window,piece=name,
                            signed=np.vdot(total,piece).real/np.vdot(total,total).real,
                            max_over_reference=np.max(abs(piece))/np.max(abs(actual['delta_phi'][:,sel]))))
                    change=(error-error[:,:1])[:,sel]
                    budgets.append(dict(method=method,window=window,piece='error_drift_from_first_knot',signed='',
                               max_over_reference=np.max(abs(change))/np.max(abs(actual['delta_phi'][:,sel]))))
            for key,values in predicted.items():
                ref=actual[key]
                for order in (0,1):
                    def rate(series):
                        return series if order==0 else make_interp_spline(np.log(eta),series.T,k=5)(np.log(eta),nu=1).T/eta
                    delta=rate(values-ref);reference=rate(ref)
                    for window,stop in (('cycle',CYCLE),('complete',END)):
                        select=eta<=stop
                        err=np.max(abs(delta[...,select]))/np.max(abs(reference[...,select]))
                        rows.append(dict(method=method,quantity=key,order=order,window=window,
                                         peak_error=err,passed=bool(err<=.005)))
    io.table('source-scores.csv',rows);io.table('modal-error-budget.csv',budgets)
    print([(r['quantity'],round(100*r['peak_error'],5)) for r in rows if r['method']=='primary' and r['window']=='complete' and r['order']==0],flush=True)

def replay(mode):
    lock();entry('score_entry89.py')
    import score_entry89 as worker
    with patch.object(worker,'ROOT',ROOT),patch.object(worker,'verified',lock):
        worker.replay_forecast(mode)
def photons():
    lock();entry('transport_entry89.py')
    import transport_entry89 as worker
    with patch.object(worker,'ROOT',ROOT),patch.object(worker,'verified',lock):
        worker.main()
if __name__=='__main__':
    for task in sys.argv[1:]:
        if task=='scores':scores()
        elif task=='photons':photons()
        else:
            assert task in ('p16','p32')
            replay(task)
