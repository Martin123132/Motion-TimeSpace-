from contextlib import contextmanager
from types import SimpleNamespace
from unittest.mock import patch
from pathlib import Path
import numpy as np
from scipy.interpolate import CubicSpline
from scipy.integrate import solve_ivp
from spatial_io89 import ROOT,entry,digest,SWITCH,CYCLE,END,io,json,guard

entry('forecast_entry89.py')
import forecast_entry89 as earlier

def causal_inputs():
    original=np.load
    seen=[]
    @contextmanager
    def stripped(name,*args,**kwargs):
        path=Path(name)
        with original(path,*args,**kwargs) as raw:
            if path.name=='exact-phase-extension.npz':
                grid=raw['heavy_efold'];used=grid<np.log(raw['matching_scale'])
                data={key:raw[key] for key in ('heavy_mass_mpc','matching_scale','matching_density','heavy_efold')}
                data.update({key:np.where(used,raw[key],np.nan) for key in ('phi_h','phidot_h','phase_h')})
            else:
                assert path.parent.name=='material-halfstep' and path.match('linear-heavy-??.npz')
                data={key:raw[key] for key in ('eta','keys','k','values')}
                data['values'][:,data['eta']>=SWITCH]=np.nan
            seen.append(path.name)
            yield data
    with patch.object(np,'load',stripped):output=earlier.load_left()
    assert len(set(seen))==39
    return output

def evolve(width,pretime,output,k,pre):
    guard();calls=[]
    def retain(rhs,span,initial,**opts):
        solved=solve_ivp(rhs,span,initial,**opts)
        calls.append((rhs,span,initial.copy(),opts,solved.sol))
        return solved
    label='primary' if width==6 else 'width'
    with patch.object(earlier,'solve_ivp',retain):
        legacy,config=earlier.model(width,pretime,output,k,pre)
    with np.load(entry(label+'.npz')) as archived:
        assert np.array_equal(archived['eta'],output)
        for key,val in legacy.items():assert np.array_equal(val,archived[key]),key
    assert len(calls)==2 and calls[1][1][0]==SWITCH
    wave=calls[0][-1];fluid_rhs,span,init,opts,_=calls[1]
    initial=wave(SWITCH)
    aw,hw,background,velocity=initial[:4]
    rho_wave=(velocity**2+(aw*pre['mass']*background)**2)/2
    delta_grho=pre['dust']/aw-rho_wave
    init[1]=np.sqrt(hw**2+delta_grho/3)
    fluid_solver=solve_ivp(fluid_rhs,span,init,**opts)
    assert fluid_solver.success
    fluid=fluid_solver.sol
    return wave,fluid,fluid_rhs,legacy,dict(**config,dust_minus_wave_energy_entry=float(delta_grho),fluid_minus_wave_H_entry=float(init[1]-hw))

def project(k,phif,delta):
    shells=np.array(json.loads(earlier.es.pin('legs.json').read_bytes())['squared_radii'])
    fields=SimpleNamespace(nodes=k,shell=shells,first=dict(matched=phif,diff=delta))
    op=earlier.es.Fast(earlier.es.Project(fields).ops[0],fields)
    def mixed(func):
        return func('matched','diff')+func('diff','matched')+func('diff','diff')
    return dict(potential_square=-op.k2*mixed(op.product),laplacian=2*mixed(op.lap),gradient=-.5*mixed(op.grad))

def predict(sub,output,k,pre,wave,fluid,fluid_rhs):
    base=np.r_[SWITCH,output]
    dense=np.r_[(base[:-1,None]+np.diff(base)[:,None]*np.arange(sub)/sub).ravel(),base[-1]]
    selected=np.arange(sub,len(dense),sub)
    assert np.array_equal(dense[selected],output)
    joined=fluid(dense);waves=wave(dense)
    af,hf=joined[:2];aw,hw,bg,vel=waves[:4]
    modes=k[:,None]
    df,uf,etaf=joined[2:].reshape(3,len(k),-1)
    dw,vw,etaw=waves[4:].reshape(3,len(k),-1)
    rates=np.array([fluid_rhs(at,joined[:,idx])[2:].reshape(3,len(k)) for idx,at in enumerate(dense)])
    ddot,_,edot=rates.transpose(1,2,0)
    rho=pre['dust']/af;qf=rho*uf;qw=modes*vel*dw
    total_qf=2*edot
    ratio=(modes/(af*pre['mass']))**2
    pressure=ratio/(np.sqrt(1+ratio)+1)**2*(df+3*hf*uf/modes)
    kzf=-ddot-3*hf*pressure-modes*uf
    w2=(aw*pre['mass'])**2
    delta_energy=vel*vw+w2*bg*dw-rho*df
    deta=etaw-etaf;dh=hw-hf
    kzw=(hf*kzf+.5*delta_energy+modes*deta)/hw
    sigmaf=kzf/modes+1.5*total_qf/modes**2
    delta_sigma_alg=(kzw-kzf)/modes+1.5*(qw-qf)/modes**2
    matched=(etaf-hf*sigmaf)/modes
    integrand=aw**2*(deta-2*dh*sigmaf)
    integral=CubicSpline(dense,integrand,axis=1).antiderivative()
    delta_sigma_dyn=(aw[0]**2*delta_sigma_alg[:,0,None]+integral(dense)-integral(dense[0])[:,None])/aw**2
    checks={}
    def make(ds):
        dphi=(deta-hw*ds-dh*sigmaf)/modes
        terms=project(k,matched[:,selected],dphi[:,selected])
        return dict(phi_f=matched[:,selected],delta_phi=dphi[:,selected],delta_phi_entry=dphi[:,0],
                    deta=deta[:,selected],dsigma=ds[:,selected],sigma_f=sigmaf[:,selected],
                    hw=hw[selected],hf=hf[selected],**terms)
    path=make(delta_sigma_dyn);control=make(delta_sigma_alg)
    ham=-(delta_energy+3*(hw*(qw-qf)+dh*total_qf)/modes)/(2*modes**2)
    checks['independent_constraint']=float(np.max(abs(ham[:,selected]-control['delta_phi']))/np.max(abs(ham[:,selected])))
    assert checks['independent_constraint']<1e-6
    return path,control,checks

def main():
    guard()
    assert not (ROOT/'frozen.json').exists()
    pretime,output,k,pre=causal_inputs()
    results={}
    for width,label in ((6,'primary'),(4,'width')):
        wave,fluid,rhs,legacy,info=evolve(width,pretime,output,k,pre)
        primary,algebra,checks=predict(4,output,k,pre,wave,fluid,rhs)
        finer,_,_=predict(8,output,k,pre,wave,fluid,rhs)
        for key in ('delta_phi','potential_square','laplacian','gradient'):
            err=float(np.max(abs(primary[key]-finer[key]))/np.max(abs(finer[key])))
            assert err<.005,(key,err)
            checks['refinement_'+key]=err
        results[label]=dict(**info,**checks)
        for name,model in [(label,primary)]+([('algebra',algebra)] if width==6 else []):
            spatial=model['potential_square']+model['laplacian']+model['gradient']
            with np.load(entry('primary.npz')) as locked:flux=locked['restore']
            total=spatial+flux
            assert all(np.isfinite(v).all() for v in model.values())
            io.pack(name+'.npz',eta=output,k=k,restore=total,spatial=spatial,locked_flux=flux,**model)
    names=['PROTOCOL.md','predict_spatial89.py','spatial_io89.py','primary.npz','algebra.npz','width.npz']
    io.record('frozen.json',dict(files={n:digest(ROOT/n) for n in names},checks=results,last_wave_time=float(pretime[-1]),
                last_phase_loga=pre['last_bg_loga'],switch=SWITCH,cycle=CYCLE,end=END,withheld='post-entry fields masked; no fluid projection table'))
    print('frozen',digest(ROOT/'frozen.json'),results)
if __name__=='__main__':main()
