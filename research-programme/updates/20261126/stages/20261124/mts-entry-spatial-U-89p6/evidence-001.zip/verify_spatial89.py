import csv
import re
import numpy as np
from test_spatial89 import lock,PARTS
from spatial_io89 import ROOT,ENTRY,LEDGER,entry,digest,io,json

def read(name):
    with (ROOT/name).open() as handle:return list(csv.DictReader(handle))
def main():
    lock()
    for name in ('primary','width','algebra'):
        with np.load(ROOT/(name+'.npz')) as model,np.load(entry('primary.npz')) as legacy:
            assert np.array_equal(model['locked_flux'],legacy['restore'])
            assert np.array_equal(sum(model[k] for k in PARTS),model['spatial'])
            assert np.array_equal(model['restore'],model['spatial']+model['locked_flux'])
            assert len(model['k'])==782
    scores=read('source-scores.csv')
    assert all((float(r['peak_error'])<=.005)==(r['passed']=='True') for r in scores)
    subset=[r for r in scores if r['method']=='primary' and r['quantity']=='spatial']
    assert len(subset)==4 and all((r['order']=='0')==(r['passed']=='True') for r in subset)
    for mode in ('p16','p32'):
        rows=read(f'metric-{mode}.csv')
        assert len(rows)==4 and all(float(r['fraction'])<=.005 for r in rows)
    pairs=read('donor-comparison.csv')
    assert len(pairs)==6 and all(float(r['forecast_route_pct'])>.5 and float(r['distance_to_donor_over_flux_to_donor'])<.005 for r in pairs)
    assert max(float(r['joint_pct']) for r in read('photon-scores.csv'))<.163
    checks=read('photon-controls.csv')
    assert len(checks)==9 and all((r['check']=='rate')==(r['passed']=='False') for r in checks)
    assert max(float(r['relative']) for r in read('photon-adjoint.csv'))<.005
    for row in read('rate-diagnostic.csv'):
        assert all(float(row[key])<.005 for key in ('physical_error','derivative_halving','native_two_cell_consistency','archived_without_first'))
    for path in ROOT.glob('*.py'):compile(path.read_bytes(),str(path),'exec')
    for note in ROOT.glob('*.md'):
        for link in re.findall(r'\]\(([^)]+)\)',note.read_text(encoding='utf-8')):
            assert (ROOT/link).is_file(),link
    seal=ROOT/'seal.json'
    files={p.name:digest(p) for p in sorted(ROOT.iterdir()) if p.is_file() and p!=seal}
    originals=ROOT.parent/'condensate-origin-20261003/native-heavy-matching-20261007/native/fortran'
    provenance={p:digest(originals/p) for p in ('equations.f90','MTSTwoField.f90')}
    if seal.exists():assert files==json.loads(seal.read_bytes())['files']
    else:io.record('seal.json',dict(files=files,native_code=provenance,entry_seal=digest(ENTRY/'seal.json'),previous_seal=digest(LEDGER/'seal.json')))
    print(len(files),'files verified;',digest(seal))
if __name__=='__main__':main()
