from pathlib import Path
import csv
import numpy as np
from scipy.interpolate import CubicSpline
from spatial_io89 import ROOT,entry,checked,io,digest,json
from test_spatial89 import lock
import photon_gate_89 as gate

def main():
    lock()
    history=ROOT.parent/'mts-photon-rate-residual-attribution-89p6-20261124'
    assert digest(history/'seal.json')=='0dec918ee446f14c2c5f0b8e1dfd0dc8fe9a361cece477e11ae4271f71c87c09'
    bank=json.loads((history/'seal.json').read_bytes())['files']
    _,axis,weights,_=gate.proj.old.get_media()
    measure=gate.previous.make_measure(axis,weights);mag=lambda x:gate.mag(x,measure)
    rows=[]
    for setting in ('primary','time','angle'):
        name='transport-'+setting+'.npz';assert digest(history/name)==bank[name]
        with np.load(history/name) as ref,np.load(ROOT/f'photon-{setting}.npz') as current,np.load(entry(f'photon-{setting}.npz')) as old,np.load(checked(f'photons-{setting}.npz')) as donor:
            grid=current['scale']
            assert np.array_equal(grid,old['scale']) and np.array_equal(grid,ref['grid']) and np.array_equal(grid,donor['scale'])
            eval_at=lambda values:CubicSpline(grid,values)(axis)
            for index,mode in enumerate(('p16','p32')):
                def read(packet,label):
                    idx=packet['inputs'].tolist().index([mode,label]);values=packet['values'][:,idx]
                    return eval_at(values[:,:3].sum(1)),eval_at(values[:,3]-values[:,1])
                start,s_gap=read(old,'primary');new,n_gap=read(current,'primary');end,e_gap=read(donor,'U_swap')
                negref=eval_at(ref['values'][:,index][:,[i for i,s in enumerate(ref['channels'].tolist()) if s.startswith('negative_reference_')]].sum(1))
                leftover=mag(n_gap-e_gap)/mag(s_gap-e_gap)
                rows.append(dict(mode=mode,setting=setting,flux_matched_pct=100*mag(s_gap-negref)[2]/mag(start)[2],
                        forecast_matched_pct=100*mag(n_gap-negref)[2]/mag(start)[2],donor_matched_pct=100*mag(e_gap-negref)[2]/mag(start)[2],
                        forecast_route_pct=100*mag(n_gap)[2]/mag(new)[2],donor_route_pct=100*mag(e_gap)[2]/mag(end)[2],
                        flux_route_pct=100*mag(s_gap)[2]/mag(start)[2],
                        distance_to_donor_over_flux_to_donor=leftover[2],energy_distance=leftover[0],current_distance=leftover[1]))
    io.table('donor-comparison.csv',rows)
    print([r for r in rows if r['setting']=='primary'])
if __name__=='__main__':main()
