from types import SimpleNamespace
import numpy as np
from scipy.interpolate import make_interp_spline
from test_spatial89 import lock,PARTS
from spatial_io89 import ROOT,SWITCH,END,io,json,checked
from predict_spatial89 import earlier,causal_inputs,evolve,predict

def native(branch):
    phi=[];rates=[];nodes=[]
    for idx in range(38):
        with np.load(io.old.pin(f'{branch}/linear-heavy-{idx:02}.npz')) as p:
            t=p['eta'];use=t>=SWITCH
            k=p['k'][:,None];data=p['values'][:,use,:];keys=p['keys'].tolist()
            val=lambda name:data[:,:,keys.index(name)]
            hub=val('adotoa');sigma=val('sigma')
            curvature=(val('etak')-hub*sigma)/k
            lapse=2*val('phi')-curvature
            minusF=(val('dgq')+(val('grho')+val('gpres'))*sigma)/(2*k)
            rates.append(minusF-hub*lapse);phi.append(curvature);nodes.extend(k[:,0])
    return np.array(nodes),t[use],np.vstack(phi),np.vstack(rates)

def main():
    lock()
    pretime,alltime,k,pre=causal_inputs()
    wave,fluid,rhs,_,_=evolve(6,pretime,alltime,k,pre)
    select=alltime<=END;clock=alltime[select]
    data={}
    for step,label in ((1e-4,'coarse'),(5e-5,'fine')):
        models=[]
        for sign in (-1,1):
            trial,_,_=predict(4,clock+sign*step,k,pre,wave,fluid,rhs)
            models.append(np.array([trial[key] for key in PARTS]))
        data[label]=(models[1]-models[0])/(2*step)
    _,_,phif,rf=native('matched-native');nw,nt,phiw,rw=native('material-halfstep')
    assert np.array_equal(nt,alltime) and np.array_equal(nw,k)
    shells=np.array(json.loads(earlier.es.pin('legs.json').read_bytes())['squared_radii'])
    args=SimpleNamespace(nodes=k,shell=shells,first=dict(p=phif,d=phiw-phif,m=rf,r=rw-rf))
    op=earlier.es.Fast(earlier.es.Project(args).ops[0],args)
    def slope(func):
        return sum(func(a,b) for a,b in [('m','d'),('p','r'),('r','p'),('d','m'),('r','d'),('d','r')])
    actual_rates=np.array([-op.k2*slope(op.product),2*slope(op.lap),-.5*slope(op.grad)])
    with np.load(checked('native-U.npz')) as src,np.load(ROOT/'primary.npz') as frozen:
        actual=np.array([src['wave_'+key]-src['matched_'+key] for key in PARTS])
        forecast=np.array([frozen[key] for key in PARTS])
    def interpolate(values):
        return make_interp_spline(np.log(nt),values.T,k=5)(np.log(clock),nu=1).T/clock
    diff=interpolate(forecast-actual)
    rows=[]
    for idx,name in enumerate((*PARTS,'spatial')):
        line=lambda vals:vals[idx] if idx<len(PARTS) else vals.sum(0)
        phys=line(actual_rates)[:len(clock)]
        pred=line(data['fine']);coarse=line(data['coarse'])
        vals=line(actual)[:len(clock)]
        unit=max(abs(phys))
        simpson=(phys[:-2]+4*phys[1:-1]+phys[2:])/6
        two_step=(vals[2:]-vals[:-2])/(clock[2:]-clock[:-2])
        raw=line(diff);spline=line(interpolate(actual))
        rows.append(dict(source=name,physical_error=max(abs(pred-phys))/unit,first_physical_error=abs(pred[0]-phys[0])/unit,
                peak_physical_at=clock[np.argmax(abs(pred-phys))],native_two_cell_consistency=max(abs(two_step-simpson))/unit,
                derivative_halving=max(abs(pred-coarse))/unit,archived_first=abs(raw[0])/max(abs(spline)),
                archived_without_first=max(abs(raw[1:]))/max(abs(spline)),
                native_boundary_stencil=abs(spline[0]-phys[0])/unit,
                model_boundary_stencil=abs(line(interpolate(forecast))[0]-pred[0])/unit))
    io.table('rate-diagnostic.csv',rows)
    io.pack('equation-rate-diagnostic.npz',eta=clock,parts=PARTS,native_rate=actual_rates[:,select],forecast_rate=data['fine'])
    print(rows[-1])
if __name__=='__main__':main()
