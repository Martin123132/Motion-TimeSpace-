import ast
import csv
import hashlib
import json
import math
import sys
from pathlib import Path

import numpy as np

ROOT=Path(__file__).resolve().parent
SEVEN=ROOT.parent/'mts-physical-impulses-70p4-20261123'
FINE=ROOT.parent/'mts-gravity-p16-70p4-20261124'
BOUND=ROOT.parent/'mts-64-to-peak-matter-bound-20261123'
PINS={SEVEN:'1dfc19700055fa4ccfe3fb67386f956c8bbcd216c904c72a1f178b833824ae1a',FINE:'a30c6a9168e8dfb20e86db29a8f7a40c02e8c15c4bdb31ac9d296bb5f05b2830',BOUND:'34527715cc80011cc93b6c92b208e075c506cb468a6dfdedc6ba7c50076f6903'}
LIMIT=.005
def digest(path):
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
def read(path):
    return json.loads(path.read_bytes())
def pin(folder,name):
    seal=folder/'seal.json'
    assert digest(seal)==PINS[folder]
    path=folder/name
    assert digest(path)==read(seal)['files'][name]
    return path
def rows(name):
    with (ROOT/name).open(newline='') as stream:return list(csv.DictReader(stream))
def record(name,value):
    data=(json.dumps(value,sort_keys=True,indent=2,allow_nan=False)+'\n').encode()
    path=ROOT/name
    if path.exists():assert path.read_bytes()==data
    else:
        with path.open('xb') as stream:stream.write(data)
def finite(value):
    value=float(value)
    assert math.isfinite(value) and value>=0
    return value
def verify():
    assert all(not (root/'STOP-REQUESTED').exists() for root in (ROOT,ROOT.parent,*PINS))
    funds={row['quantity']:float(row['one_at_a_time_necessary_ceiling']) for row in csv.DictReader(pin(BOUND,'window-conditions.csv').read_text().splitlines())}
    old=read(pin(FINE,'decision.json'))
    for source in ROOT.glob('*.py'):ast.parse(source.read_text(encoding='utf8'))
    old_core=pin(SEVEN,'advance70.py').read_text()
    new_core=(ROOT/'gravity76.py').read_text()
    for first,last in [('    with np.load(source_restart)',"    prefix='material-halfstep/'"),("    with np.load(folder/f'forcing-",'    report=dict(')]:
        assert old_core[old_core.index(first):old_core.index(last)].strip() in new_core
    nodes=np.arange(-52,25);momentum=2.**(nodes/4)
    restarts=[]
    for model in ('cold','heavy'):
        bankpath=ROOT/f'bank-{model}.json'
        bank=read(bankpath)
        assert len(bank)==82 and all(digest(ROOT/name)==sha for name,sha in bank.items())
        for ix in nodes:
            name=f'micro-{model}-{ix}.npz'
            with np.load(ROOT/name) as micro:
                assert micro['id']==ix and micro['q']==2.**(ix/4)
                assert micro['source'].shape==(69,129) and np.isfinite(micro['source']).all() and np.isfinite(micro['end']).all() and 0<=micro['join']<=LIMIT
                if ix in (-52,0,24):assert 0<=micro['independent']<1e-10
        with np.load(ROOT/f'common-{model}.npz') as common:
            assert np.array_equal(common['eta'][[0,-1]],[70.4,76.8]) and common['S'].shape==(69,129)
        with np.load(ROOT/f'material-halfstep/forcing-{model}.npz') as forcing:
            assert np.array_equal(forcing['eta'][[8,-9]],[70.4,76.8]) and len(forcing['eta'])==1041
        for mode,refine in [('p8',8),('p16',16)]:
            path=ROOT/f'particular-{model}-{mode}.npz';report=read(ROOT/f'metric-{model}-{mode}.json')
            src=pin(FINE,f'to70/particular-{model}-p16.npz') if refine==16 else pin(SEVEN,f'particular-{model}-p8.npz')
            assert report['passed'] and report['parent']==digest(src) and report['source_bank']==digest(bankpath) and report['output_digest']==digest(path)
            assert report['micro']=={key:value for key,value in bank.items() if key.startswith('micro-')}
            assert report['step_mpc']==.00625/refine and report['quadrature']<1e-12
            assert max(report[key] for key in ('time_metric','incident_seam','slope_error','seam_metric','seam_stress'))<=LIMIT
            assert max(report['iterations'][-1][key] for key in ('stress','metric_increment'))<=LIMIT
            with np.load(path) as out:
                assert len(out['eta'])==1024*refine+1 and np.array_equal(out['eta'][[0,-1]],[70.4,76.8])
                assert max(abs(np.diff(out['eta'])-report['step_mpc']))<5e-14
                assert np.array_equal(out['q'],momentum) and out['lagEnd'].shape[0]==77
                for key in ('lagEnd','shape','state','stress','obs','phi_dot','psi','phi'):assert np.isfinite(out[key]).all()
            restarts.append(dict(mode=mode,model=model,parent=report['parent'],result=report['output_digest']))
    relative={}
    for name,count in [('impulse-internal-checks.csv',108),('impulse-time-step.csv',36),('p8-p16-trajectory.csv',24)]:
        data=rows(name);assert len(data)==count and len({tuple((key,row[key]) for key in row if key not in ('relative_error','absolute_difference','passed')) for row in data})==count
        errors=[finite(row['relative_error']) for row in data]
        for row,error in zip(data,errors):
            if 'passed' in row:assert (row['passed']=='True')==(error<=LIMIT)
        relative[name]=dict(tests=count,passes=sum(value<=LIMIT for value in errors),worst=max(errors))
    impulses=rows('physical-impulses.csv')
    assert len(impulses)==len({(row['mode'],row['model'],row['target']) for row in impulses})==12
    carry=rows('carry-and-center.csv');assert len(carry)==12
    rates=rows('rate-defect.csv');assert len(rates)==6
    for row in rates:
        maxerr=max(finite(row[k]) for k in ('quadrature_change','endpoint_unexplained','independent_difference'))
        assert (row['passed']=='True')==(maxerr<=LIMIT)
    for row in carry:assert (row['passed']=='True')==(finite(row['prior_cut_match_over_paired_radius'])<=LIMIT)
    budget=rows('peak-allowances.csv');assert len(budget)==2
    for row in budget:
        key=row['quantity']
        assert float(row['radius'])==funds['midpoint '+key]
        assert abs(float(row['start_shift_over_radius'])-old['center_shifts_in_radius'][key][-1])<LIMIT
        assert (row['passed']=='True')==(finite(row['end_shift_over_radius'])<=1)
    components=rows('lapse-sensitivity.csv');assert len(components)==8
    total=float(next(row['end_shift_over_radius'] for row in budget if row['quantity']=='Y'))
    assert abs(sum(float(row['signed_projection_over_radius']) for row in components if row['term']!='final')-total)<1e-8
    brackets=rows('independent-end-centers.csv');assert len(brackets)==6
    bracket_pass=[finite(row['C_difference'])/funds['midpoint C']<=LIMIT and finite(row['Y_error_over_paired_radius'])<=LIMIT for row in brackets if row['model']=='paired']
    seams=rows('seam-checks.csv');assert len(seams)==12
    seam_pass=all(max(finite(row[key]) for key in ('C_relative_jump','Y_relative_jump','source_identity'))<=LIMIT for row in seams)
    production=rows('remaining-production.csv');assert len(production)==2 and all(finite(row['pre_to_hot_ratio'])>0 for row in production)
    checks=dict(relative=relative,prior_center_replays=[sum(row['passed']=='True' for row in carry),len(carry)],curvature_rate_controls=[sum(row['passed']=='True' for row in rates),len(rates)],end_brackets=[sum(bracket_pass),len(bracket_pass)],seams_pass=seam_pass)
    target={row['quantity']:dict(start=float(row['start_shift_over_radius']),end=float(row['end_shift_over_radius']),within_allowance=row['passed']=='True') for row in budget}
    result=dict(physics_end_mpc=76.8,peak_transport_target_mpc=273.3323213627907,original_relative_tolerance=LIMIT,checks=checks,target_shift_in_one_term_radii=target,restarts=restarts,all_center_allowances_pass=all(value['within_allowance'] for value in target.values()),actual_matter_evolution_at_peak=False)
    record('validation.json',result)
    if '--seal' in sys.argv:
        assert (ROOT/'RESULTS.md').is_file() and not list(ROOT.rglob('__pycache__'))
        record('seal.json',dict(files={file.relative_to(ROOT).as_posix():digest(file) for file in sorted(ROOT.rglob('*')) if file.is_file() and file.name!='seal.json'},parents={folder.name:sha for folder,sha in PINS.items()}))
    print(json.dumps(dict(checks=checks,center_radii=target),indent=2))
if __name__=='__main__':verify()
