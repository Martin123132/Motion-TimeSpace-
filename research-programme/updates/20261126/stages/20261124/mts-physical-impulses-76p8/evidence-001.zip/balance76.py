from impulse76 import *
LIMIT=.005
def read(path):
    with path.open(newline='') as stream:return list(csv.DictReader(stream))
def rate(med,mode,nodes):
    old,new=({model:Packet(model,mode,prior) for model in MODELS} for prior in (True,False))
    cut,switch,end,first=split(med)
    mixed={model:new[model] if model==first else old[model] for model in MODELS}
    totals={}
    for lo,hi,fields,count in [(cut,switch,mixed,33),(switch,end,new,nodes)]:
        guard()
        scale=np.linspace(lo,hi,count)
        clock=med.native('heavy',scale)
        fields_at={}
        for model,entry in fields.items():
            t,ratio,_,_=med.coord(scale,model)
            t=limit_time(t,entry.time)
            fields_at[model]=np.array([entry.curves['phi'](t),ratio*entry.curves['phi'](t,1),ratio*entry.curves['pd'](t)])
        fields_at['paired']=fields_at['heavy']-fields_at['cold']
        for name,(phi,slope,rate) in fields_at.items():
            model='heavy' if name=='paired' else name
            time,ratio,hub,_=med.coord(scale,model)
            gain=np.exp(med.primitive[model](time)-med.primitive[model](med.native(model,med.am)))
            direct=simpson(gain*(slope-rate),x=clock)
            boundary=gain[-1]*phi[-1]-gain[0]*phi[0]
            independent=boundary-simpson(gain*(ratio*hub*phi+rate),x=clock)
            key=name
            totals[key]=totals.get(key,np.zeros(2,complex))+np.array([direct,independent])
    return totals


def peak_norm(arr):
    return float(np.max(abs(arr)))
def trajectory(med):
    tests=[]
    for prior in (False,):
        block='70.4 to 76.8'
        data={}
        for mode in ('p8','p16'):
            cases={model:Packet(model,mode,prior) for model in MODELS}
            lo,hi=med.both({name:entry.time for name,entry in cases.items()})
            scale=np.linspace(lo,hi,16385)
            rows=history.branches(med,cases,scale)
            metrics={}
            for name,entry in cases.items():
                time=limit_time(med.native(name,scale),entry.time)
                phi=entry.curves['phi']
                metrics[name]=[phi(time),entry.curves['pd'](time),phi(time,1)]
            metrics['paired']=np.array(metrics['heavy'])-np.array(metrics['cold'])
            for name,row in rows.items():
                phi,rate,derivative=metrics[name]
                data[mode,name]=[phi,row['Y'],rate,row['C'],row['refCp'],row['refYp']]
                error=peak_norm(derivative-rate)/peak_norm(rate)
                tests.append(dict(block=block,model=name,test=mode+' derivative vs constraint',relative_error=error,passed=error<=LIMIT))
        for name in CASES:
            for field,low,high in zip(('phi','lapse','phi_dot','C','C slope','Y slope'),data['p8',name],data['p16',name]):
                error=peak_norm(high-low)/peak_norm(high)
                tests.append(dict(block=block,model=name,test='p8 to p16: '+field,relative_error=error,passed=error<=LIMIT))
    return tests


def assess():
    guard();med=Medium()
    caps=read(pinned(PRE,'required-signed-impulses.csv'))
    radii={field:float(row['radius']) for field,row in zip(('C','Y'),caps)}
    work=read(ROOT/'physical-impulses.csv')
    carries=[];checks=[];terms={};marks={};rates=[]
    oldwork={'p8':read(pinned(SEVEN,'physical-impulses.csv')),'p16':read(pinned(FINE,'p16-impulses.csv'))}
    for mode in ('p16','p8'):
        low=rate(med,mode,16385);high=rate(med,mode,32769)
        for name in CASES:
            prior=next(row for row in oldwork[mode] if row['model']==name and row['mode']==('primary' if mode=='p8' else 'p16') and row['target']=='priority midpoint')
            item=next(row for row in work if (row['model'],row['mode'],row['target'])==(name,mode,'priority midpoint'))
            direct,independent=high[name];coarse=low[name][0];radius=radii['Y']
            endpoint=-z(item,'remaining_center_Y')
            initial=z(item,'carried_Y');physical=z(item,'I_Y');seam=z(item,'seam_Y')
            closure=endpoint-initial-physical-seam
            diagnostic=[abs(direct-independent)/radius,abs(direct-coarse)/radius,abs(direct-closure)/radius]
            rates.append(dict(mode=mode,model=name,**parts('integrated',direct),**parts('independent_parts',independent),**parts('endpoint_defect',closure),magnitude_over_paired_radius=abs(direct)/radius,independent_difference=diagnostic[0],quadrature_change=diagnostic[1],endpoint_unexplained=diagnostic[2],passed=max(diagnostic)<=LIMIT))
            for field in ('C','Y'):
                radius=radii[field]
                initial=z(item,'carried_'+field)
                previous=-z(prior,'remaining_center_'+field)
                end=-z(item,'remaining_center_'+field)
                original=z(prior,'carried_'+field)
                error=abs(initial-previous)/radius
                carries.append(dict(mode=mode,model=name,field=field,prior_cut_match_over_paired_radius=error,passed=error<=LIMIT,end_over_70p4=abs(end)/abs(initial),end_over_64=abs(end)/abs(original),**parts('required_center',-end)))
            if name=='paired':
                terms[mode]=dict(initial=z(item,'carried_Y'),current=z(item,'I_Y_current'),shear=z(item,'I_Y_shear'),clock=z(item,'I_Y_clock'),seam=z(item,'seam_Y'),rate_defect=direct,unexplained=closure-direct,final=endpoint)
                for field in ('C','Y'):
                    marks[mode,field]=[z(item,'carried_'+field),-z(item,'remaining_center_'+field)]
    comparisons=[];components=[]
    for field in ('C','Y'):
        radius=radii[field]
        start,end=[abs(low-high)/radius for low,high in zip(marks['p8',field],marks['p16',field])]
        comparisons.append(dict(quantity=field,radius=radius,start_shift_over_radius=start,end_shift_over_radius=end,absolute_step_change=end*radius,passed=end<=1))
    shift={key:value-terms['p16'][key] for key,value in terms['p8'].items()}
    assert abs(shift['final']-sum(value for key,value in shift.items() if key!='final'))<1e-8*radii['Y']
    for key,value in shift.items():
        components.append(dict(term=key,**parts('control_minus_fine',value),absolute_over_radius=abs(value)/radii['Y'],signed_projection_over_radius=(value*shift['final'].conjugate()).real/abs(shift['final'])/radii['Y']))
    write('p8-p16-trajectory.csv',trajectory(med));write('carry-and-center.csv',carries);write('rate-defect.csv',rates);write('peak-allowances.csv',comparisons);write('lapse-sensitivity.csv',components)
    print('Absolute center checks:',comparisons,flush=True)

if __name__=='__main__':assess()
