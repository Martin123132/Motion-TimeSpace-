from paired_inputs import *

def inspect(stage_index,model):
    folder=STAGES[stage_index];tag=TAGS[stage_index];end=ENDPOINTS[stage_index]
    path=pin(folder,f'particular-{model}-{tag}.npz')
    for source in ('forcing','radiation','origin-v2','collisionless'):
        pin(folder,f'material-halfstep/{source}-{model}.npz')
    with parent.patch.object(parent.regular_flow,'HOME',folder/'material-halfstep'):
        flow=parent.Flight(model,68,6,False,True)
    with np.load(path) as raw:
        times=raw['eta'];clock=np.log(times);assert times[-1]==end and times[-1]==raw['stressClock'][-1]
        state=dict(zip(raw['keys'],raw['state'][:,0,0]));wave=float(raw['k'][0]);assert wave>0
        phi=raw['phi'];psi=raw['psi'];rate=raw['phi_dot'];obs=raw['obs'][:,:,0,0];flux=obs[:,3]/times;slip=obs[:,11]
        stress=raw['stress'][-1,:,0,0]
    bg=dict(zip(flow.bgkeys,flow.bg(clock[-1])))
    saved_inputs=dict(zip(flow.qkeys,flow.q(clock[-1])[:,0]))
    native_h=make_interp_spline(flow.log,flow.bg(flow.log)[:,flow.bgkeys.index('h')],k=5)(clock)
    native_fq=make_interp_spline(flow.log,flow.q(flow.log)[:,flow.qkeys.index('Fq'),0],k=5)(clock)
    stress=stress*bg['enu']
    square=wave**2;expansion=bg['h'];density_ratio=bg['eb']/bg['eg']
    baryon=(state['W']-state['B'])/(density_ratio+4/3)
    photon_current=state['B']+4*baryon/3
    rad_energy=4*bg['er']+bg['nuE']
    chunks={}
    def put(sector,energy,momentum,shear,energy_geometry=0.,shear_geometry=0.):
        chunks[sector]=(energy_geometry-energy/2,momentum,shear-shear_geometry)
    put('quadratic metric',0.,0.,0.,saved_inputs['U'],saved_inputs['Q'])
    put('photons',bg['eg']*state['gx']+saved_inputs['gE'],bg['eg']*photon_current+saved_inputs['gJ'],-bg['eg']*(state['I2']+saved_inputs['ph_shift']))
    put('radiation common',rad_energy*state['N0'],wave*(4*bg['er']+bg['nuJ'])*state['N1']+saved_inputs['nuJ'],-(4*bg['er']+bg['nuS'])*state['N2'])
    put('finite bin stress',stress[0],wave*stress[1],stress[2])
    susceptibility=4*bg['eg']+rad_energy
    for tag,velocity in [('c',state['ct']),('b',baryon)]:
        density=bg['e'+tag];susceptibility+=3*density
        put({'c':'cold matter','b':'baryons'}[tag],density*state[tag+'d']+saved_inputs[tag+'trace']+saved_inputs[tag+'KE'],density*velocity+saved_inputs[tag+'Jq'],saved_inputs[tag+'shear'])
    for tag in flow.tags:
        velocity=bg[tag+'v'];susceptibility+=3*velocity**2
        put({'s':'slow scalar','h':'heavy scalar'}[tag],velocity*state[tag+'w']+(bg['a']*bg[tag+'m'])**2*bg[tag+'b']*state[tag+'f']+saved_inputs[tag+'energy'],square*velocity*state[tag+'f']+saved_inputs[tag+'J'],saved_inputs[tag+'shear'])
    denom=square+susceptibility/2;assert denom>=square
    energy,current,shear=np.stack(list(chunks.values())).sum(axis=0)
    def project(entry):
        eff_energy,momentum,eff_shear=entry
        potential=(eff_energy-1.5*expansion*momentum/square)/denom
        return np.array([potential,potential+eff_shear/square])
    reconstructed=project((energy,current,shear));actual=np.array([phi[-1],psi[-1]])
    end_error=float(np.max(abs(reconstructed-actual)/abs(actual)))
    assert end_error<1e-9 and abs(flux[-1]+current/(2*square))<1e-10*max(abs(flux[-1]),1e-30)
    assert np.max(abs((psi-phi)-slip))<=1e-10*max(abs(psi))
    assert np.max(abs(rate-(-flux-native_h*(phi+slip)+native_fq)))<=1e-9*max(abs(rate))
    return dict(energy=energy,current=current,shear=shear,denom=denom,hub=expansion,wave=wave,end_error=end_error,
                sectors={key:project(value) for key,value in chunks.items()},actual=actual,reconstructed=reconstructed,
                times=times,phi=phi,psi=psi,flux=flux,slip=slip,native_h=native_h,fq=native_fq,rate=rate)
