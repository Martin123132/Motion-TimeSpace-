from tail_test import get_complex, values
from paired_inputs import *

def closure_test():
    output=[]
    for model in MODELS:
        for source in ('forcing','radiation','origin-v2','collisionless'):
            pin(PARENT,f'material-halfstep/{source}-{model}.npz')
        with parent.patch.object(parent.regular_flow,'HOME',PARENT/'material-halfstep'):
            flow=parent.Flight(model,68,6,False,True)
        log_time=np.log(64.);time=np.exp(log_time)
        scale=flow.factors*time**flow.power[:,None,None]
        state=np.zeros((flow.n,5,1));direction=state.copy()
        direction[flow.ix['I3'],0,0]=1/scale[flow.ix['I3'],0,0]
        change=flow.jac_rhs(log_time,direction,0.,True)-flow.jac_rhs(log_time,state,0.,True)
        derivative=flow.jac_rhs(log_time,direction,0.)-flow.jac_rhs(log_time,state,0.)
        effect=float(np.real_if_close((derivative*scale/time)[flow.ix['I2'],0,0]))
        expected=-3*float(flow.k[0,0])/5
        photon_density=flow.env(log_time)[0]['eg']
        assert abs(change).max()==0. and abs(effect-expected)<1e-12*abs(expected)
        assert photon_density>0.
        output.append(dict(model=model,eta=64.,observable_change_max=abs(change).max(),physical_I2_rate_per_unit_I3=effect,expected_I2_rate=expected,effective_shear_rate_per_unit_I3=-photon_density*effect))
    table('projected-closure.csv',output)

def backtest():
    from paired_tail64 import medium_polys,difference_cap
    medium,*_=get_media();source=rows('paired-tail-backtest.csv')[-1]
    starts=[];ends=[]
    for data in medium.values():
        scale=data['scale'];clock=data['clock']
        limit=lambda time:brentq(lambda value:clock(value)-time,scale[0],scale[-1],xtol=1e-20)
        starts.append(limit(57.6));ends.append(limit(64.))
    start=max(starts);end=min(ends)
    scale,cold_time,cold_rate,*_=medium_polys('cold')
    _,heavy_time,heavy_rate,*_=medium_polys('heavy')
    cells=(scale[1:]>=start)&(scale[:-1]<=end)
    minimum=np.min([cold_rate[0],cold_rate[0]+cold_rate[1]/2,cold_rate.sum(axis=0)],axis=0)
    assert np.min(minimum[cells])>0
    rho=np.max((difference_cap(cold_rate,heavy_rate)/minimum)[cells])
    for model,background in medium.items():
        coeff=background['hub'].c[::-1]
        dx=np.diff(background['eta'])
        controls=[coeff[0],coeff[0]+coeff[1]*dx/3,coeff[0]+2*coeff[1]*dx/3+coeff[2]*dx**2/3,((coeff[3]*dx+coeff[2])*dx+coeff[1])*dx+coeff[0]]
        assert np.min(controls)>0.
    time=medium['heavy']['clock']
    length=time(end)-time(start)
    with np.load(pin(PARENT,'particular-cold-p8.npz')) as raw:wave=float(raw['k'][0])
    cut=get_complex(values('signed-matter-constraints.csv')[-2],'phi')
    measured=get_complex(values('saved-paired-shear.csv')[-1],'mean_slip')
    direct=float(source['integral_signed_force_upper']);cold=float(source['cold_integral_upper'])
    bound=direct/4+np.sqrt(3)/(4*wave*length)*(direct+rho*cold)
    assert 0<abs(measured+cut)<bound
    table('shear-target-backtest.csv',[dict(start_eta=57.6,end_eta=64.,overlap_heavy_mpc=length,clock_ratio_bound=rho,measured_center_distance=abs(measured+cut),available_source_radius=bound,passed=True)])

if __name__=='__main__':
    guard();closure_test();backtest()
    record('crosscheck-inputs.json',PROVENANCE)
