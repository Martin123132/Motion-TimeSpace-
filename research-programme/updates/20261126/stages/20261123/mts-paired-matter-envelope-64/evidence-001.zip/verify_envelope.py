import math
import re
from tail_test import values, get_complex
from paired_inputs import *

def validate():
    guard()
    budgets={row['measure']:row for row in rows('tail-source-budgets.csv')}
    actual=values('signed-matter-constraints.csv')
    assert tuple(float(row['eta']) for row in actual)==ENDPOINTS
    assert all(float(row['paired_identity_rel'])<1e-9 and float(row['psi_abs'])<=float(row['raw_psi_triangle'])*(1+1e-10) for row in actual)
    cases=values('momentum-replay.csv')
    assert {(float(row['eta']),row['model'],row['potential']) for row in cases}=={(eta,model,potential) for eta in ENDPOINTS for model in (*MODELS,'MTS-minus-cold') for potential in ('phi','psi')}
    assert len(cases)==36 and all(max(float(row['error_over_own_peak']),float(row['half_sampling_change']))<=.005 and row['passed']=='True' for row in cases)
    signed=get_complex(actual[-1],'phi')
    biggest=max(float(row['sampled_max_paired_slip']) for row in values('saved-paired-shear.csv'))
    decision=json.loads((HERE/'decision.json').read_bytes())
    assert not decision['remaining_driving_certified_below_half_percent'] and decision['actual_tail_exceeds_half_percent']=='undetermined' and decision['new_intervals']==0
    assert decision['last_matter_eta']==64. and decision['positive_term_floor_exhausts_budget']
    for row in values('surface-certificate-floor.csv'):
        label=row['measure'];limit=float(budgets[label]['retained_contrast_norm'])*.005
        assert math.isclose(float(row['absolute_budget']),limit,rel_tol=1e-14) and math.isclose(float(row['surface_norm'])/limit,decision[label+'_floor_ratio'],rel_tol=1e-12) and decision[label+'_floor_ratio']>1
    for row in values('necessary-shear-target.csv'):
        assert abs(get_complex(row,'required_mean_paired_slip_center')+signed)<1e-10*abs(signed)
        assert math.isclose((abs(signed)-float(row['mean_paired_slip_radius']))/biggest,float(row['slip_min_over_saved_sampled_max']),rel_tol=1e-12)
    for row in values('residual-gains.csv'):assert all(math.isfinite(float(value)) and float(value)>0 for key,value in row.items() if key!='measure')
    assert {row['model'] for row in values('projected-closure.csv') if float(row['observable_change_max'])==0 and float(row['effective_shear_rate_per_unit_I3'])>0}==set(MODELS)
    assert all(row['passed']=='True' for row in values('shear-target-backtest.csv'))
    inputs={}
    for path in HERE.glob('*-inputs.json'):
        for source,digest in json.loads(path.read_bytes()).items():
            if source in inputs:assert inputs[source]==digest
            inputs[source]=digest
    required={folder/f'particular-{model}-{tag}.npz' for folder,tag in zip(STAGES,TAGS) for model in MODELS}
    required.update(folder/'material-halfstep'/f'{source}-{model}.npz' for folder in STAGES for source in ('forcing','radiation','origin-v2','collisionless') for model in MODELS)
    required.update(PARENT/name for name in ('paired_tail64.py','remaining64.py','tail-source-budgets.csv','paired-tail-medium-mismatch.csv','tail-propagation-gains.csv','paired-tail-backtest.csv'))
    required.update(medium_file(name) for name in ('medium-cold.npz','medium-heavy.npz','score.json'))
    assert all(str(path) in inputs for path in required)
    assert all(sha(Path(source))==digest for source,digest in inputs.items())
    for link in re.findall(r'\]\(([^)]+)\)',(HERE/'RESULTS.md').read_text(encoding='utf-8')):
        assert (HERE/link).is_file(),link
    assert not any(path.is_dir() or path.suffix in ('.npz','.npy','.pyc') for path in HERE.iterdir())
    inventory={path.name:sha(path) for path in sorted(HERE.iterdir()) if path.name!='seal.json'}
    record('seal.json',dict(parent=PARENT_SHA,files=inventory,verified_upstream_inputs=len(inputs),new_intervals=0))
    print(len(cases),'replays;',len(inputs),'upstream inputs;',len(inventory),'local files; seal',sha(HERE/'seal.json'))

if __name__=='__main__':validate()
