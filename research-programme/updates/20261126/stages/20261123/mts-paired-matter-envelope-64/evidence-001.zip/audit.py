from paired_inputs import *
from matter import inspect

def replay(packet, stride):
    time=packet['times'];knots=time[::stride];assert knots[-1]==time[-1]
    hub=packet['native_h'][::stride];primitive=CubicSpline(knots,hub).antiderivative()
    decay=np.exp(primitive(knots[0])-primitive(time))
    drive=(-packet['flux']+packet['fq']-packet['native_h']*packet['slip'])[::stride]
    integral=CubicSpline(knots,drive/decay[::stride]).antiderivative()
    predicted=decay*(packet['phi'][0]+integral(time)-integral(knots[0]))
    return np.stack([predicted,predicted+packet['slip']],axis=1)

def main():
    media,axis,weights,peak=get_media();end_rows=[];contributions=[];replays=[];history=[]
    for stage_index,end in enumerate(ENDPOINTS):
        cases={model:inspect(stage_index,model) for model in MODELS}
        cold,heavy=(cases[model] for model in MODELS)
        assert cold['wave']==heavy['wave']
        square=cold['wave']**2
        signed=heavy['actual']-cold['actual']
        parts=np.array([heavy['energy']-cold['energy'],
            -1.5*heavy['hub']*(heavy['current']-cold['current'])/square,
            -1.5*(heavy['hub']-cold['hub'])*cold['current']/square,
            -(heavy['denom']-cold['denom'])*cold['actual'][0]])/heavy['denom']
        shear_diff=(heavy['shear']-cold['shear'])/square
        estimates=np.array([sum(parts),sum(parts)+shear_diff])
        algebra_relative=max(abs(estimates-signed)/abs(signed))
        assert algebra_relative<1e-9
        end_rows.append(dict(eta=end,phi_abs=abs(signed[0]),psi_abs=abs(signed[1]),raw_psi_triangle=sum(abs(parts))+abs(shear_diff),
            two_branch_psi_sum=abs(heavy['actual'][1])+abs(cold['actual'][1]),paired_identity_rel=algebra_relative,
            **complex_fields('phi',signed[0]),**complex_fields('psi',signed[1]),
            **complex_fields('effective_energy_term',parts[0]),**complex_fields('current_term',parts[1]),
            **complex_fields('expansion_term',parts[2]),**complex_fields('susceptibility_term',parts[3]),**complex_fields('shear_term',shear_diff)))
        sector_sum=np.zeros(2,complex)
        for name in sorted(cold['sectors'].keys()|heavy['sectors'].keys()):
            contrast=heavy['sectors'].get(name,0.)-cold['sectors'].get(name,0.)
            sector_sum+=contrast
            contributions.append(dict(eta=end,sector=name,**complex_fields('phi',contrast[0]),**complex_fields('psi',contrast[1]),psi_magnitude=abs(contrast[1])))
        assert np.allclose(sector_sum,signed,atol=0,rtol=1e-9)
        limits=[]
        for model,data in cases.items():
            clock=media[model]['clock'];grid=media[model]['scale']
            limits.append([brentq(lambda val:clock(val)-point,grid[0],grid[-1],xtol=1e-20) for point in data['times'][[0,-1]]])
        common=np.linspace(max(entry[0] for entry in limits),min(entry[1] for entry in limits),1025)
        matched={}
        for model,data in cases.items():
            times=data['times'];actual=np.column_stack((data['phi'],data['psi']))
            native=replay(data,1);other=replay(data,2)
            evaluation=np.clip(media[model]['clock'](common),times[0],times[-1])
            assert max(abs(evaluation-media[model]['clock'](common)))<1e-10
            matched[model]=np.stack([CubicSpline(times,arr,axis=0,extrapolate=False)(evaluation) for arr in (actual,native,other)])
            reference=media[model]['hub'](times)
            history.append(dict(eta=end,model=model,endpoint_identity_rel=data['end_error'],max_H_relative=max(abs(reference/data['native_h']-1)),
                integrated_H_reference_defect_sampled=np.trapezoid(abs((reference-data['native_h'])*data['psi']),x=times)))
        matched['MTS-minus-cold']=matched['heavy']-matched['cold']
        for model,(actual,full,coarse) in matched.items():
            for index,potential in enumerate(('phi','psi')):
                denom=np.max(abs(actual[:,index]))
                rel=np.max(abs(full[:,index]-actual[:,index]))/denom
                refinement=np.max(abs(full[:,index]-coarse[:,index]))/denom
                replays.append(dict(eta=end,model=model,potential=potential,error_over_own_peak=rel,half_sampling_change=refinement,passed=bool(max(rel,refinement)<=.005)))
        if end==64.:
            table('cut-states.csv',[dict(model=model,cut=media[model]['cut'],**complex_fields('phi',data['reconstructed'][0]),**complex_fields('psi',data['reconstructed'][1])) for model,data in cases.items()])
    table('signed-matter-constraints.csv',end_rows);table('matter-sectors.csv',contributions);table('momentum-replay.csv',replays);table('metric-clock-check.csv',history)
    record('matter-audit-inputs.json',PROVENANCE)
    print('Native signed endpoint gap:',end_rows[-1],flush=True)
    print('Worst saved-history reconstruction:',max(row['error_over_own_peak'] for row in replays),'; passes',sum(row['passed'] for row in replays),'/',len(replays),flush=True)

if __name__=='__main__':main()
