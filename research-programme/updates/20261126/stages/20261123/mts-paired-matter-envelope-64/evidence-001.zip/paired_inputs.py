import csv
import hashlib
import io
import json
import sys
from functools import lru_cache
from pathlib import Path

HERE=Path(__file__).resolve().parent
PARENT=HERE.parent/'mts-particular-gravity-64-tail-20261123'
PARENT_SHA='b512fa19c739b9b912b86b80be0a7e8af67047a63be02e5e8ba3b5a0ac36f19d'
sys.path.insert(0,str(PARENT))

def sha(path):
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()

assert sha(PARENT/'seal.json')==PARENT_SHA
assert sha(PARENT/'block.py')==json.loads((PARENT/'seal.json').read_bytes())['files']['block.py']
import block as parent
import numpy as np
from scipy.interpolate import CubicSpline, make_interp_spline
from scipy.integrate import simpson
from scipy.optimize import brentq

MODELS=('cold','heavy')
STAGES=[parent.ANCESTOR,parent.SECOND,parent.THIRD,parent.FOURTH,parent.BASE,PARENT]
TAGS=('p2','p2','p4','p4','p4','p8')
ENDPOINTS=(32.,38.4,44.8,51.2,57.6,64.)
PROVENANCE={}

def guard():
    parent.guard()
    assert not (HERE/'STOP-REQUESTED').exists()
    assert not any((folder/'STOP-REQUESTED').exists() for folder in STAGES)

@lru_cache(None)
def manifest(folder):
    receipt=folder/'seal.json';idx=STAGES.index(folder)
    pin=PARENT_SHA if folder==PARENT else manifest(STAGES[idx+1])['parent']
    assert sha(receipt)==pin,(folder,pin)
    return json.loads(receipt.read_bytes())

@lru_cache(None)
def pin(folder,name):
    guard()
    path=folder/name;key=manifest(folder)['files'][name]
    assert sha(path)==key,path
    PROVENANCE[str(path)]=key
    return path

@lru_cache(None)
def medium_file(name):
    path=parent.inherited.source(name);PROVENANCE[str(path)]=sha(path)
    return path

def save(name,data):
    guard()
    path=HERE/name
    if path.exists():assert path.read_bytes()==data,name
    else:
        with path.open('xb') as stream:stream.write(data)

def table(name,rows):
    text=io.StringIO();writer=csv.DictWriter(text,rows[0],lineterminator='\n')
    writer.writeheader();writer.writerows(rows);save(name,text.getvalue().encode())

def rows(name):
    with pin(PARENT,name).open() as stream:return list(csv.DictReader(stream))

def record(name,value):save(name,(json.dumps(value,indent=2,sort_keys=True,allow_nan=False)+'\n').encode())

def norm_window(values,weights,axis):return float(np.sqrt(simpson(weights*abs(values)**2,x=axis)))

def get_media():
    result={}
    for model in MODELS:
        with np.load(medium_file(f'medium-{model}.npz')) as raw:
            scale=raw['scale'];eta=raw['eta']
            clock=CubicSpline(scale,eta,extrapolate=False)
            hub=CubicSpline(eta,raw['hub'],extrapolate=False)
            if model=='cold':
                axis=np.linspace(1/1501,scale[-1],8193)
                weights=CubicSpline(scale,raw['visibility'])(axis)*clock(axis,1)
                assert np.min(weights)>=0
                weights/=simpson(weights,x=axis)
            else:assert np.array_equal(scale,result['cold']['scale'])
            cut=brentq(lambda val:clock(val)-64.,scale[0],scale[-1],xtol=1e-20)
            result[model]=dict(scale=scale,eta=eta,clock=clock,hub=hub,primitive=hub.antiderivative(),cut=cut)
    peak=json.loads(medium_file('score.json').read_bytes())['visibility']['cold']['peak_scale']
    return result,axis,weights,peak

def complex_fields(key,value):
    return {key+'_real':float(np.real(value)),key+'_imag':float(np.imag(value))}
