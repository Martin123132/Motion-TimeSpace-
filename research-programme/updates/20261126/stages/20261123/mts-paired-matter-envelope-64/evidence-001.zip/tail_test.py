from paired_inputs import *

def values(name):
    with (HERE/name).open() as stream:return list(csv.DictReader(stream))

def get_complex(row,key):
    return complex(float(row[key+'_real']),float(row[key+'_imag']))

def reference_gains(media):
    pin(PARENT,'paired_tail64.py');pin(PARENT,'remaining64.py')
    from paired_tail64 import medium_polys,prod,difference_cap
    scale,cold_time,cold_rate,cold,*_=medium_polys('cold')
    axis,heavy_time,heavy_rate,heavy,*_=medium_polys('heavy')
    assert np.array_equal(scale,axis)
    active=np.maximum(cold_time[1:],heavy_time[1:])>=64.
    differential_clock=difference_cap(cold_rate,heavy_rate)
    differential_hub=difference_cap(prod(cold_rate,cold['hub']),prod(heavy_rate,heavy['hub']))
    beta_bern=np.stack([cold_rate[0],cold_rate[0]+cold_rate[1]/2,cold_rate.sum(axis=0)])
    minimum=beta_bern.min(axis=0);assert minimum.min()>0
    ratio=float(np.max(differential_clock[active]/minimum[active]))
    return ratio,float(differential_clock[active].sum()),float(differential_hub[active].sum())

def saved_shear(media,wave):
    checks=[]
    for folder,tag in zip(STAGES,TAGS):
        values_by_model={}
        for model in MODELS:
            with np.load(pin(folder,f'particular-{model}-{tag}.npz')) as raw:
                values_by_model[model]=(raw['eta'],raw['obs'][:,11,0,0],raw['phi'])
        starts=[];ends=[]
        for model,(times,_,_) in values_by_model.items():
            clock=media[model]['clock'];scale=media[model]['scale']
            roots=[brentq(lambda val:clock(val)-point,scale[0],scale[-1],xtol=1e-20) for point in times[[0,-1]]]
            starts.append(roots[0]);ends.append(roots[1])
        axis=np.linspace(max(starts),min(ends),4097)
        slips=[];potentials=[]
        for model,(times,slip,phi) in values_by_model.items():
            location=np.clip(media[model]['clock'](axis),times[0],times[-1])
            slips.append(CubicSpline(times,slip)(location));potentials.append(CubicSpline(times,phi)(location))
        signed=slips[1]-slips[0];clock=media['heavy']['clock']
        mean=simpson(signed*clock(axis,1),x=axis)/(clock(axis[-1])-clock(axis[0]))
        checks.append(dict(until=times[-1],sampled_max_paired_slip=np.max(abs(signed)),sampled_max_paired_phi=np.max(abs(potentials[1]-potentials[0])),**complex_fields('mean_slip',mean),**complex_fields('mean_shear',wave**2*mean)))
    return checks

def primitive_times(background,scales):
    time=background['clock'](scales);upper=background['eta'][-1]
    assert np.isfinite(time).all() and np.max(time)<=upper+2*np.spacing(upper)
    return np.clip(time,64.,upper)

def memory_upper(media,cuts,loading,rho,epsilon,wave):
    cold=media['cold'];heavy=media['heavy'];start=min(item['cut'] for item in media.values())
    base=cold['scale'];edges=np.unique(np.r_[start,max(item['cut'] for item in media.values()),base[base>start]])
    mid=(edges[1:]+edges[:-1])/2;branch={};spans={}
    for model,background in media.items():
        active=mid>=background['cut'];times=primitive_times(background,edges)
        coeff=np.exp(background['primitive'](64.)-background['primitive'](times))
        limit=get_complex(cuts[model],'phi');spans[model]=np.diff(background['clock'](edges))
        branch[model]=(limit*np.stack((coeff[:-1],coeff[1:]))*active,limit*np.stack((coeff[:-1]-1,coeff[1:]-1))*active)
    differences=[np.max(abs(lhs[:,None]-rhs[None,:]),axis=(0,1)) for lhs,rhs in zip(branch['heavy'],branch['cold'])]
    cold_peaks=[abs(values).max(axis=0) for values in branch['cold']]
    factor=4*wave/np.sqrt(3);high=np.sqrt(loading['heavy']+1);low=np.sqrt(loading['cold']+1)
    paired=spans['heavy']@(high*differences[0]+differences[1])+rho*(spans['cold']@(high*cold_peaks[0]+cold_peaks[1]))
    baseline=spans['cold']@(low*cold_peaks[0]+cold_peaks[1])
    return 4*differences[1].max()+factor*(paired+epsilon*baseline)

def main():
    guard()
    assert all(row['passed']=='True' for row in values('momentum-replay.csv'))
    media,axis,weights,peak=get_media()
    cuts={row['model']:row for row in values('cut-states.csv')}
    budget={row['measure']:row for row in rows('tail-source-budgets.csv')}
    with np.load(pin(PARENT,'particular-cold-p8.npz')) as raw:wave=float(raw['k'][0])
    rho,clock_total,kernel_difference=reference_gains(media)
    epsilon=max(float(row['medium_mismatch_bound']) for row in rows('paired-tail-medium-mismatch.csv') if row['domain']=='post_64')
    start=max(item['cut'] for item in media.values())
    earliest=min(item['cut'] for item in media.values())
    end=axis[-1];span={model:data['clock'](end)-data['clock'](earliest) for model,data in media.items()}
    loading={row['model']:float(row['max_loading']) for row in rows('tail-propagation-gains.csv')}
    spline_gain={row['model']:row for row in rows('tail-propagation-gains.csv')}
    shift={};potential_memory={}
    grid=media['cold']['scale']
    for model,background in media.items():
        phi=get_complex(cuts[model],'phi')
        def memory(scale):
            phase=background['primitive'](64.)-background['primitive'](primitive_times(background,scale))
            return phi*np.expm1(phase)
        shift[model]=memory(grid)
        potential_memory[model]=CubicSpline(grid,shift[model]+phi,extrapolate=False)
    signed0=get_complex(cuts['heavy'],'phi')-get_complex(cuts['cold'],'phi')
    def signed_memory(scale):
        return potential_memory['heavy'](scale)-potential_memory['cold'](scale)-signed0
    diagnostic=saved_shear(media,wave);table('saved-paired-shear.csv',diagnostic)
    sampled_old_max=max(row['sampled_max_paired_slip'] for row in diagnostic)
    floor=[];targets=[];gains=[]
    wave_factor=4*wave/np.sqrt(3.)
    total_time=span['heavy'];lc=span['cold'];high=np.sqrt(1+loading['heavy']);low=np.sqrt(1+loading['cold'])
    coeff_b=4+wave_factor*total_time*(high+1)
    coeff_ic=coeff_b*kernel_difference+wave_factor*(clock_total*(high+1)+epsilon*lc*(low+1))
    coeff_t=wave_factor*total_time*high
    coeff_tc=wave_factor*(clock_total*high+epsilon*lc*low)
    memory_cap=memory_upper(media,cuts,loading,rho,epsilon,wave)
    for measure,stop in [('window',end),('peak',peak)]:
        permitted=float(budget[measure]['absolute_point_five_percent_budget'])
        tau=float(budget[measure]['paired_integral_budget_scored'])
        surface=4*(norm_window(signed_memory(axis),weights,axis) if measure=='window' else abs(signed_memory(peak)))
        floor.append(dict(measure=measure,surface_norm=surface,absolute_budget=permitted,floor_over_budget=surface/permitted,
            best_case_relative_floor=surface/float(budget[measure]['retained_contrast_norm'])))
        length=float(media['heavy']['clock'](stop)-media['heavy']['clock'](start))
        weight=np.sqrt(3)/(4*wave*length)
        radius=tau*max(.25+weight,weight*rho/epsilon)
        targets.append(dict(measure=measure,length_mpc=length,phi_change_radius=tau/4,phi_relative_radius=(tau/4)/abs(signed0),
            **complex_fields('required_mean_paired_slip_center',-signed0),mean_paired_slip_radius=radius,
            mean_paired_slip_min=max(0,abs(signed0)-radius),effective_shear_min=wave**2*max(0,abs(signed0)-radius),
            slip_min_over_saved_sampled_max=(abs(signed0)-radius)/sampled_old_max))
        constant=max(float(row['constant_'+measure+'_gain']) for row in spline_gain.values())
        gains.append(dict(measure=measure,known_memory_upper=constant*memory_cap,integrated_signed_momentum_drive=constant*coeff_b,integrated_baseline_momentum_drive=constant*coeff_ic,peak_paired_slip=constant*coeff_t,peak_baseline_slip=constant*coeff_tc))
    table('surface-certificate-floor.csv',floor);table('necessary-shear-target.csv',targets);table('residual-gains.csv',gains)
    markers=[]
    for label,point in [('z1500',axis[0]),('peak',peak),('z750',axis[-1])]:
        value=signed_memory(point)
        markers.append(dict(marker=label,scale=point,**complex_fields('carried_phi_gap',signed0+value),**complex_fields('needed_momentum_cancellation',-value)))
    table('momentum-cancellation-target.csv',markers)
    record('decision.json',dict(mode='algebra and quadrature on archived data only',last_matter_eta=64.,new_intervals=0,cut_gap_abs=abs(signed0),window_floor_ratio=floor[0]['floor_over_budget'],peak_floor_ratio=floor[1]['floor_over_budget'],
        max_relative_clock_rate_gap=rho,clock_difference_integral_mpc=clock_total,momentum_propagator_mismatch_upper=kernel_difference,medium_transport_mismatch_upper=epsilon,
        positive_term_floor_exhausts_budget=all(bool(row['floor_over_budget']>1) for row in floor),
        remaining_driving_certified_below_half_percent=False,
        direct_paired_certificate='necessary phase and shear targets derived; future constraint combinations not covered',
        actual_tail_exceeds_half_percent='undetermined'))
    record('tail-audit-inputs.json',PROVENANCE)
    print(floor,targets,markers,flush=True)

if __name__=='__main__':main()
