from bridge64_inputs import *

def cumulative(values):return np.r_[0.,np.cumsum(values)]

def clock_limits(med,model):
    grid=med.grid;cells=(grid[1:]>=med.al)&(grid[:-1]<=med.ar)
    def rates(m):
        cubic,quad,linear=med.clock[m].c[:3,cells];width=np.diff(grid)[cells]
        return np.stack([linear,linear+quad*width,linear+2*quad*width+3*cubic*width**2])
    hmin=np.min(rates('heavy'));assert hmin>0
    rate=1. if model=='heavy' else np.max(rates('cold'))/hmin
    hub=med.hub[model];lo=med.native(model,med.al);hi=med.native(model,med.ar)
    take=(hub.x[1:]>=lo)&(hub.x[:-1]<=hi)
    width=np.diff(hub.x)[take];cubic,quad,linear,const=hub.c[:,take]
    controls=np.stack([const,const+linear*width/3,const+2*linear*width/3+quad*width**2/3,((cubic*width+quad)*width+linear)*width+const])
    assert controls.min()>0
    return (1+1e-12)/med.al/hmin,rate*(1+1e-12),controls.max()*(1+1e-12)

def solve(med,model,count):
    edges=np.unique(np.r_[med.a0,med.grid[(med.grid>med.a0)&(med.grid<med.ar)],med.al,med.am,med.ar])
    scale=np.r_[np.linspace(edges[:-1],edges[1:],count,endpoint=False).T.reshape(-1),edges[-1]]
    assert np.all(np.diff(scale)>0) and med.am in scale and med.al in scale
    s=med.native('heavy',scale);t=med.native(model,scale);ds=np.diff(s);dt=np.diff(t)
    w=(scale[0]/scale)**2;primitive=med.primitive[model](t)
    decay=np.exp(primitive[0]-primitive)
    assert np.all(np.diff(decay)<0)
    lower_q=cumulative(ds/w[:-1]);upper_q=cumulative(ds/w[1:])
    lower_t=w[1:]/decay[:-1];upper_t=w[:-1]/decay[1:]
    Tlo=decay*cumulative(dt*lower_t);Thi=decay*cumulative(dt*upper_t)
    Klo=decay*cumulative(dt*lower_t*lower_q[:-1]);Khi=decay*cumulative(dt*upper_t*upper_q[1:])
    Vlo=decay*cumulative(ds/decay[:-1]);Vhi=decay*cumulative(ds/decay[1:])
    q=cumsum(1/w,s);tt=decay*cumsum(w/decay,t)
    exact={'T':tt,'CP':w*q,'YP':decay*cumsum(w/decay*q,t),'YV':decay*cumsum(1/decay,s)}
    limits={'T':(Tlo,Thi),'CP':(w*lower_q,w*upper_q),'YP':(Klo,Khi),'YV':(Vlo,Vhi)}
    for key,(lo,hi) in limits.items():
        lo=lo*(1-1e-9);hi=hi*(1+1e-9)
        assert np.all(exact[key]>=lo) and np.all(exact[key]<=hi),key
        limits[key]=(lo,hi)
    return scale,s,t,w,decay,exact,limits

def main():
    med=Medium();cuts={r['model']:r for r in read('matched-restart.csv')};alt={r['model']:r for r in read('cut-control-values.csv')}
    envelopes=[];centers=[];controls=[];targets=[];necessity=[]
    coeff_c=med.coeff['effective current'];coeff_y=med.coeff['lapse including shear'];budget=med.budget
    for key in ('cold','heavy','paired'):
        model='heavy' if key=='paired' else key
        scale,s,t,w,decay,exact,limit=solve(med,model,64)
        co=solve(med,model,16)
        mid=np.searchsorted(scale,med.am);left=np.searchsorted(scale,med.al)
        im=np.searchsorted(co[0],med.am)
        C0=z(cuts[key],'C');Y0=z(cuts[key],'Y')
        for k,arr in exact.items():
            ratio=abs(co[5][k][im]/arr[mid]-1)
            controls.append(dict(model=key,kernel=k,subdivision_change=ratio,lower=limit[k][0][mid],quadrature=arr[mid],upper=limit[k][1][mid],passed=bool(ratio<=base.TOL)))
        common=key=='paired';span=(s[-1]-s[left])/2
        gm,rmax,hm=clock_limits(med,model)
        memory_c=w*C0;memory_y=decay*Y0+exact['T']*C0
        terr=np.maximum(abs(limit['T'][1]-exact['T']),abs(exact['T']-limit['T'][0]))*abs(C0)
        mid_c=memory_c[mid];mid_y=memory_y[mid]
        dC0=z(alt[key],'C')-C0;dY0=z(alt[key],'Y')-Y0
        centers.append(dict(model=key,pivot_heavy_eta=s[mid],pivot_native_eta=t[mid],elapsed_heavy=s[mid]-s[0],current_retention=w[mid],lapse_retention=decay[mid],current_to_lapse_mpc=exact['T'][mid],**parts('cut_C',C0),**parts('cut_Y',Y0),**parts('from_cut_C',mid_c),**parts('from_cut_Y',mid_y),C_cut_control_displacement=abs(w[mid]*dC0),Y_cut_control_displacement=abs(decay[mid]*dY0+exact['T'][mid]*dC0),Y_quadrature_bracket_radius=terr[mid]))
        def add(quantity,offset,pcoeff,vcoeff):envelopes.append(dict(model=key,quantity=quantity,cut_upper=float(offset),P_sup_gain=float(pcoeff),V_sup_gain=float(vcoeff)))
        add('midpoint abs C',abs(mid_c),limit['CP'][1][mid],0)
        add('midpoint abs Y',abs(mid_y)+terr[mid],limit['YP'][1][mid],limit['YV'][1][mid])
        dx=np.diff(s)[left:];native_dx=np.diff(t)[left:];loc=slice(left,-1)
        Cbase=abs(memory_c[loc]);Cg=limit['CP'][1][loc]+dx
        Ybase=abs(memory_y[loc])+terr[loc]+native_dx*Cbase
        YgP=limit['YP'][1][loc]+native_dx*Cg;YgV=limit['YV'][1][loc]+dx
        add('window sup abs C',max(Cbase),max(Cg),0)
        add('window sup abs Y',max(Ybase),max(YgP),max(YgV))
        add('window sup abs dC/ds',2*gm*max(Cbase),1+2*gm*max(Cg),0)
        add('window sup abs dY/ds',rmax*max(Cbase+hm*Ybase),rmax*max(Cg+hm*YgP),1+rmax*hm*max(YgV))
        if common:
            for label,center,coefficient,displacement in [('longitudinal impulse',mid_c,coeff_c[0],abs(w[mid]*dC0)),('current plus shear work',mid_y,coeff_y[0],abs(decay[mid]*dY0+exact['T'][mid]*dC0))]:
                radius=budget/coefficient
                targets.append(dict(moment=label,**parts('required_center',-center),radius=radius,formal_center_over_radius=abs(center)/radius,alternate_restart_displacement_over_radius=displacement/radius,quadrature_radius=(0 if label=='longitudinal impulse' else terr[mid])))
            for label,value in [('midpoint C',budget/coeff_c[0]),('midpoint Y',budget/coeff_y[0]),('window C slope',budget/coeff_c[1]),('window Y slope',budget/coeff_y[1]),
                ('window P',budget*max(2*gm/coeff_c[0],(1+2*gm*span)/coeff_c[1])),
                ('window V',budget*max(1/coeff_c[0],span/coeff_c[1],hm/coeff_y[0],(1+hm*span)/coeff_y[1]))]:
                necessity.append(dict(quantity=label,one_at_a_time_necessary_ceiling=value,window_halfspan=span,g_max=gm,Hr_max=hm))
    table('bridge-gain-checks.csv',controls);table('transported-cut.csv',centers);table('conditional-bounds.csv',envelopes);table('required-signed-impulses.csv',targets);table('window-conditions.csv',necessity)
    assert all(r['passed'] for r in controls)
    print(centers[-1]);print(targets);print(envelopes[-6:],flush=True)
    
if __name__=='__main__':main()
