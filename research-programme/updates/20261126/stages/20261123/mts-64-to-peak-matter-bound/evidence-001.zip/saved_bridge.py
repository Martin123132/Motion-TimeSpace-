from bridge64_inputs import *

class Saved:
    def __init__(self,index,model):
        item=matter.inspect(index,model);self.time=item['times'];self.model=model
        self.curves={key:CubicSpline(self.time,item[name],extrapolate=False) for key,name in [('Y','psi'),('phi','phi'),('pd','rate'),('L','slip'),('F','flux'),('Fq','fq'),('Hm','native_h')]}
    def state(self,med,scale):
        time,ratio,ref,g=med.coord(scale,self.model);t=limit_time(time,self.time);curve=self.curves
        lapse=curve['Y'](t);rate=curve['pd'](t);slip=curve['L'](t)
        native=curve['Hm'](t);refdiff=ref-native
        current=-curve['F'](t)+curve['Fq'](t)+refdiff*lapse
        actual=rate+ref*lapse
        current_dot=ratio*(-curve['F'](t,1)+curve['Fq'](t,1)+(med.hub[self.model](time,1)-curve['Hm'](t,1))*lapse+refdiff*curve['Y'](t,1))
        ref_dot=ratio*(curve['pd'](t,1)+med.hub[self.model](time,1)*lapse+ref*curve['Y'](t,1))
        return dict(C=current,Y=lapse,L=slip,P=current_dot+2*g*current,V=ratio*curve['L'](t,1),refC=actual,refCp=ref_dot,refYp=ratio*curve['Y'](t,1),r=ratio,H=ref,g=g)
    
def branches(med,cases,scale):
    data={m:cases[m].state(med,scale) for m in MODELS}
    c,h=data['cold'],data['heavy']
    pair={key:h[key]-c[key] for key in ('C','Y','L','P','refC','refCp','refYp')}
    pair.update(r=h['r'],H=h['H'],g=h['g'],V=h['V']-c['V']+(1-c['r'])*c['C']+(c['r']*c['H']-h['H'])*c['Y'])
    data['paired']=pair
    return data

def main():
    guard();med=Medium();tests=[];values=[];alternate=[];rates=[];history_caps=[]
    for index,eta in enumerate(OLD.ENDPOINTS):
        cases={m:Saved(index,m) for m in MODELS};times={m:case.time for m,case in cases.items()}
        lo,hi=med.both(times);scale=np.linspace(lo,hi,16385)
        if eta==64.:
            assert abs(hi-med.a0)<1e-17
            for key,row in branches(med,cases,med.a0).items():
                values.append(dict(model=key,common_scale=med.a0,heavy_eta=med.native('heavy',med.a0),cold_eta=med.native('cold',med.a0),**parts('C',row['C']),**parts('Y',row['Y']),**parts('L',row['L']),**parts('P_at_cut',row['P']),**parts('V_at_cut',row['V'])))
            coarse={}
            for m in MODELS:
                with np.load(pin(PARENT,'larger-step-'+m+'.npz')) as alt:
                    grid=times[m][::2];assert len(grid)==len(alt['pd'])
                    point=limit_time(med.native(m,med.a0),grid)
                    coarse[m]=np.array([CubicSpline(grid,alt['pd'])(point)+med.hub[m](point)*CubicSpline(grid,alt['psi'])(point),CubicSpline(grid,alt['psi'])(point)])
            coarse['paired']=coarse['heavy']-coarse['cold']
            table('cut-control-values.csv',[dict(model=key,**parts('C',ref[0]),**parts('Y',ref[1])) for key,ref in coarse.items()])
            for key,ref in coarse.items():
                fine=next(r for r in values if r['model']==key)
                for col,source in enumerate(('C','Y')):
                    diff=abs(ref[col]-z(fine,source))/abs(z(fine,source))
                    alternate.append(dict(model=key,source=source,relative_change=diff,passed=bool(diff<=base.TOL)))
        data=branches(med,cases,scale);s=med.native('heavy',scale)
        for name,row in data.items():
            model='heavy' if name=='paired' else name;native=med.native(model,scale)
            decay=np.exp(med.primitive[model](native[0])-med.primitive[model](native))
            weight=(scale[0]/scale)**2
            test_c=weight*(row['C'][0]+cumsum(row['P']/weight,s))
            test_y=decay*(row['Y'][0]+cumsum((row['r']*test_c+row['V'])/decay,s))
            metrics=(('C',test_c,row['refC']),('Y',test_y,row['Y']),('C slope',row['P']-2*row['g']*row['C'],row['refCp']),('Y slope',row['r']*(row['C']-row['H']*row['Y'])+row['V'],row['refYp']))
            for label,pred,ref in metrics:
                denom=np.max(abs(ref));err=float(np.max(abs(pred-ref))/denom)
                tests.append(dict(eta_end=eta,model=name,output=label,error_over_own_interval_peak=err,passed=bool(err<=base.TOL)))
            history_caps.append(dict(eta_end=eta,model=name,sampled_P_max=np.max(abs(row['P'])),sampled_V_max=np.max(abs(row['V']))))
    table('real-history-checks.csv',tests);table('matched-restart.csv',values);table('cut-step-check.csv',alternate);table('past-production-only.csv',history_caps)
    record('historical-inputs.json',OLD.PROVENANCE)
    print('Replay passing:',sum(r['passed'] for r in tests),'/',len(tests),'worst',max(r['error_over_own_interval_peak'] for r in tests))
    print('Cut:',values[-1]);print('Alternate:',alternate,flush=True)

if __name__=='__main__':main()
