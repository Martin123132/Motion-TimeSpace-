import csv
import hashlib
import io
import json
import sys
from pathlib import Path

HOME=Path(__file__).resolve().parent
PRE=HOME.parent/'mts-peak-tail-weights-20261123'
PRE_SHA='6b6da0a494214c8a99023f73ad2c078e8944579b318871149e2e0995c64ea442'

def sha(path):
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()

assert sha(PRE/'seal.json')==PRE_SHA
manifest=json.loads((PRE/'seal.json').read_bytes())['files']
def previous(name):
    path=PRE/name
    assert sha(path)==manifest[name]
    return path
previous('peak64_io.py')
sys.path.insert(0,str(PRE))
import peak64_io as base
from peak64_io import np, CubicSpline, brentq, MODELS, PARENT, pin
from scipy.integrate import cumulative_simpson
from scipy.interpolate import make_interp_spline

OLD=base.proj.old
MATH=OLD.HERE/'matter.py'
assert sha(MATH)==json.loads((OLD.HERE/'seal.json').read_bytes())['files']['matter.py']
import matter

def guard():
    base.guard();assert not (HOME/'STOP-REQUESTED').exists()

def save(name,data):
    guard();path=HOME/name
    if path.exists():assert path.read_bytes()==data,name
    else:
        with path.open('xb') as stream:stream.write(data)

def table(name,rows):
    stream=io.StringIO();writer=csv.DictWriter(stream,rows[0],lineterminator='\n')
    writer.writeheader();writer.writerows(rows);save(name,stream.getvalue().encode())

def record(name,value):save(name,(json.dumps(value,indent=2,sort_keys=True,allow_nan=False)+'\n').encode())
def read(name):return base.read_csv(HOME/name)
def parts(name,val):return {name+'_re':float(np.real(val)),name+'_im':float(np.imag(val))}
def z(row,name):return complex(float(row[name+'_re']),float(row[name+'_im']))

class Medium:
    def __init__(self):
        self.grid,self.data,self.clock,self.cuts=base.setup()
        self.hub={};self.primitive={}
        for model in MODELS:
            with np.load(OLD.medium_file('medium-'+model+'.npz')) as raw:
                self.hub[model]=CubicSpline(raw['eta'],raw['hub'],extrapolate=False)
            self.primitive[model]=self.hub[model].antiderivative()
        targets=base.read_csv(previous('priority-matter-targets.csv'))
        self.win=next(r for r in targets if r['window']=='17' and r['channel']=='effective current')
        self.a0=self.cuts['heavy']
        def saved_edge(key):
            value=float(self.win[key]);times=self.data['cold'][1]
            index=np.argmin(abs(times-value));assert abs(times[index]-value)<1e-11
            return self.grid[index]
        self.al=saved_edge('cold_eta_from')
        self.ar=saved_edge('cold_eta_to')
        self.mid=float(next(r['pivot_heavy_eta'] for r in base.read_csv(previous('signed-local-matter-targets.csv')) if r['setting']=='primary' and r['channel']=='effective current' and r['window']=='17'))
        self.am=self.root('heavy',self.mid)
        self.budget=base.budget()
        self.coeff={}
        for row in targets:
            if row['window']=='17':
                self.coeff[row['channel']]=[float(row[key]) for key in ('signed_constant_gain','slope_gain')]
    def root(self,model,time):
        lo,hi=self.grid[[0,-1]];clock=self.clock[model]
        if abs(clock(lo)-time)<1e-12:return lo
        if abs(clock(hi)-time)<1e-12:return hi
        return brentq(lambda scale:clock(scale)-time,lo,hi,xtol=1e-20)
    def native(self,model,scale):
        time=self.clock[model](scale);lo,hi=self.hub[model].x[[0,-1]]
        assert np.all(time>=lo-1e-10) and np.all(time<=hi+1e-10)
        return np.clip(time,lo,hi)
    def coord(self,scale,model):
        time=self.native(model,scale);bh=self.clock['heavy'](scale,1)
        return time,self.clock[model](scale,1)/bh,self.hub[model](time),1/(scale*bh)
    def both(self,times):
        points=[]
        for model in MODELS:
            pts=times[model];points.append([self.root(model,pts[0]),self.root(model,pts[-1])])
        return max(pair[0] for pair in points),min(pair[1] for pair in points)

def limit_time(time,knots):
    assert np.all(time>=knots[0]-1e-9) and np.all(time<=knots[-1]+1e-9)
    return np.clip(time,knots[0],knots[-1])

def cumsum(values,times):
    if np.iscomplexobj(values):return cumulative_simpson(values.real,x=times,initial=0)+1j*cumulative_simpson(values.imag,x=times,initial=0)
    return cumulative_simpson(values,x=times,initial=0)
