import re
from bridge64_inputs import *

def main():
    guard();med=Medium();tests=read('real-history-checks.csv')
    assert len(tests)==72 and {(float(r['eta_end']),r['model'],r['output']) for r in tests}=={(t,model,var) for t in OLD.ENDPOINTS for model in (*MODELS,'paired') for var in ('C','Y','C slope','Y slope')}
    assert all(r['passed']=='True' and float(r['error_over_own_interval_peak'])<=base.TOL for r in tests)
    for name,size in [('cut-step-check.csv',6),('endpoint-slope-step.csv',6),('bridge-gain-checks.csv',12)]:
        rows=read(name);assert len(rows)==size and all(r['passed']=='True' for r in rows)
    cond=read('conditional-bounds.csv');assert len(cond)==18 and all(float(row[k])>=0 and np.isfinite(float(row[k])) for row in cond for k in ('cut_upper','P_sup_gain','V_sup_gain'))
    limits=read('window-conditions.csv');curves=read('required-signed-impulses.csv')
    assert np.isclose(float(curves[0]['radius'])*med.coeff['effective current'][0],med.budget,rtol=1e-12,atol=0)
    assert np.isclose(float(curves[1]['radius'])*med.coeff['lapse including shear'][0],med.budget,rtol=1e-12,atol=0)
    assert med.budget==.005*float(next(r['retained_contrast_norm'] for r in base.read_csv(pin(PARENT,'tail-source-budgets.csv')) if r['measure']=='peak'))
    deriv=json.loads((HOME/'necessary-production.json').read_bytes())
    assert deriv['early_P_sup_at_least']>3*deriv['hot_P_sup_at_most'] and deriv['constant_current_elimination']['required_lower']>0
    assert len(read('projection-freedom-controls.csv'))==4 and all(float(r['replay_relative_error'])<1e-7 for r in read('projection-freedom-controls.csv'))
    assert all(r['supplies_target_particular']=='False' for r in read('source-coverage.csv'))
    precision=next(r for r in read('tight-midpoint-bracket.csv') if r['model']=='paired')
    assert float(precision['scoring_radius_ratio'])<.001
    cutoff=next(r for r in read('transported-cut.csv') if r['model']=='paired')
    assert med.al<med.am<med.ar and abs(float(cutoff['elapsed_heavy'])-(med.mid-64))<1e-10
    for link in re.findall(r'\]\(([^)]+)\)',(HOME/'RESULTS.md').read_text(encoding='utf-8')):assert (HOME/link).is_file()
    provenance=json.loads((HOME/'historical-inputs.json').read_bytes())
    for model in MODELS:
        for name in (f'particular-{model}-p8.npz',f'larger-step-{model}.npz',f'common-{model}.npz',f'material-halfstep/forcing-{model}.npz'):pin(PARENT,name)
    provenance.update(OLD.PROVENANCE)
    assert all(sha(Path(path))==key for path,key in provenance.items())
    record('decision.json',dict(tolerance=base.TOL,absolute_peak_budget=med.budget,matching_eta_MTS=64.,hot_center_eta_MTS=med.mid,
        history_passes=len(tests),worst_historical_relative_error=max(float(r['error_over_own_interval_peak']) for r in tests),
        signed_work_test='conditional on the missing particular momentum and shear production',
        unconditional_midpoint_and_slope_bounds_from_saved_inputs=False,actual_photon_threshold_status='undetermined',
        late_matter_intervals=0,post64_forcing_run=False,verified_source_files=len(provenance)))
    assert not any(p.is_dir() or p.suffix in ('.npz','.pyc') for p in HOME.iterdir())
    files={p.name:sha(p) for p in sorted(HOME.iterdir()) if p.name!='seal.json'}
    record('seal.json',dict(parent=PRE_SHA,files=files,verified_upstream=len(provenance),late_matter_intervals=0))
    print('Verified',len(files),'local files and',len(provenance),'source hashes. Seal',sha(HOME/'seal.json'))

if __name__=='__main__':main()
