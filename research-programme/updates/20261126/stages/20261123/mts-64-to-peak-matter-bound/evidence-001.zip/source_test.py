from saved_bridge import Saved,branches
from bridge64_inputs import *

def at_cut(med):
    cases={m:Saved(5,m) for m in MODELS};vals=branches(med,cases,med.a0);items={}
    for model,case in cases.items():
        row=vals[model];time,ratio,ref,g=med.coord(med.a0,model);time=limit_time(time,case.time);curve=case.curves
        def prod(value,slope):return ratio*slope+2*g*value
        gap=ref-curve['Hm'](time);gap_prime=med.hub[model](time,1)-curve['Hm'](time,1)
        items[model]={
            'P from longitudinal momentum':prod(-curve['F'](time),-curve['F'](time,1)),
            'P from quadratic metric rate':prod(curve['Fq'](time),curve['Fq'](time,1)),
            'P from expansion correction':prod(gap*row['Y'],gap_prime*row['Y']+gap*curve['Y'](time,1)),
            'V from shear rate':row['V']}
    c=vals['cold'];h=vals['heavy']
    items['paired']={k:items['heavy'][k]-items['cold'][k] for k in items['cold']}
    items['paired']['V from clock rate']=(1-c['r'])*c['C']
    items['paired']['V from expansion']=(c['r']*c['H']-h['H'])*c['Y']
    rows=[]
    for model,items_by_term in items.items():
        for quantity in ('P','V'):
            components={k:v for k,v in items_by_term.items() if k.startswith(quantity)}
            ref=vals[model][quantity];assert abs(sum(components.values())-ref)<1e-11*abs(ref)
            for term,value in components.items():
                rows.append(dict(model=model,quantity=quantity,term=term,norm=abs(value),signed_share=float(np.real(value*np.conj(ref)))/abs(ref)**2,**parts('value',value)))
    table('cut-source-decomposition.csv',rows)

def coverage(med):
    rows=[]
    for model in MODELS:
        for name,what,key,folder in [
            (f'particular-{model}-p8.npz','curvature-zero solution','eta',PARENT),
            (f'common-{model}.npz','incident and finite-bin source sampling clock','eta',PARENT),
            (f'material-halfstep/forcing-{model}.npz','padded first-order-product forcing, not a future state','eta',PARENT)]:
            with np.load(pin(folder,name)) as raw:
                t=raw[key];end=float(t[-1])
                if 'particular-' in name:assert raw['q'].size==77 and raw['lagEnd'].shape[:2]==(77,69) and raw['state'].shape[0]==len(raw['keys'])
                assert end<med.native(model,med.al)
                rows.append(dict(model=model,input=name,role=what,eta_min=t[0],eta_max=end,supplies_target_particular=False))
        with np.load(OLD.medium_file('medium-'+model+'.npz')) as data:
            t=data['eta'];assert t[-1]>med.native(model,med.ar)
            rows.append(dict(model=model,input='medium-'+model+'.npz',role='clock and reference expansion only',eta_min=t[0],eta_max=t[-1],supplies_target_particular=False))
    source=OLD.parent.predecessor('source-coverage.csv')
    for row in base.read_csv(source):
        path=Path(row['path']);assert path.is_file()
        if float(row['last_mpc'])>=89:
            rows.append(dict(model=row['model'],input=str(path),role=row['meaning'],eta_min=row['first_mpc'],eta_max=row['last_mpc'],supplies_target_particular=False))
    table('source-coverage.csv',rows)

def freedom(med):
    s=np.linspace(med.mid-3,med.mid+3,8193);a0=med.root('heavy',s[0]);a1=med.root('heavy',s[-1])
    scale=np.linspace(a0,a1,len(s));s=med.native('heavy',scale)
    scale=np.sort(np.r_[scale,med.am]);s=med.native('heavy',scale)
    time,ratio,hub,g=med.coord(scale,'heavy');u=s-med.mid;zeta=u/2
    b=np.zeros_like(s);bp=np.zeros_like(s);inside=abs(zeta)<1.
    b[inside]=np.exp(1-1/(1-zeta[inside]**2))
    bp[inside]=-b[inside]*zeta[inside]/(1-zeta[inside]**2)**2
    pivot=np.argmin(abs(u));assert abs(u[pivot])<1e-11
    win=[float(row['one_at_a_time_necessary_ceiling']) for row in read('window-conditions.csv')[:4]]
    results=[]
    for index,label in enumerate(('C value','Y value','C slope','Y slope')):
        amplitude=10*win[index];v=b if index<2 else u*b
        deriv=bp if index<2 else b+u*bp
        dc=amplitude*v if index%2==0 else np.zeros_like(v)
        dy=amplitude*v if index%2==1 else np.zeros_like(v)
        dcprime=amplitude*deriv if index%2==0 else np.zeros_like(v)
        dyprime=amplitude*deriv if index%2==1 else np.zeros_like(v)
        P=dcprime+2*g*dc;V=dyprime-dc+hub*dy
        w=(scale[0]/scale)**2;decay=np.exp(med.primitive['heavy'](s[0])-med.primitive['heavy'](s))
        cp=w*cumsum(P/w,s);yp=decay*cumsum((cp+V)/decay,s)
        norm=amplitude*max(1.,max(abs(u)));res=max(max(abs(cp-dc)),max(abs(yp-dy)))/norm
        assert res<1e-7 and dc[0]==dy[0]==P[0]==V[0]==0
        measured=[dc[pivot],dy[pivot],dcprime[pivot],dyprime[pivot]]
        assert abs(measured[index]/win[index]-10)<1e-9
        results.append(dict(perturbation=label,center_in_its_own_budget_units=measured[index]/win[index],replay_relative_error=res))
    table('projection-freedom-controls.csv',results)

if __name__=='__main__':
    guard();medium=Medium();at_cut(medium);coverage(medium);freedom(medium)
