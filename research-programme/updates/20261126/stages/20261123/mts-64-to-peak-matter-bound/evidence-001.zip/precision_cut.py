from bridge64_inputs import *
from saved_bridge import Saved,branches

def bracket(med,model,sub):
    nodes=np.unique(np.r_[med.a0,med.grid[(med.grid>med.a0)&(med.grid<med.am)],med.am])
    a=np.r_[np.linspace(nodes[:-1],nodes[1:],sub,endpoint=False).T.ravel(),med.am]
    da=np.diff(a);clock=med.clock[model];t=med.native(model,a);P=med.primitive[model];hub=med.hub[model]
    factor=np.exp(P(t)-P(t[-1]))*(med.a0/a)**2
    beta=clock(a,1)
    estimate=np.trapezoid(factor*beta,x=a)
    idx=np.searchsorted(clock.x,(a[:-1]+a[1:])/2)-1
    dx=np.diff(clock.x)[idx];c3,c2,c1=clock.c[:3,idx]
    b=np.max(abs(np.stack([c1,c1+c2*dx,c1+2*c2*dx+3*c3*dx**2])),axis=0)
    bp=np.maximum(abs(2*c2),abs(2*c2+6*c3*dx));bpp=6*abs(c3)
    keep=(hub.x[:-1]<=t[-1])&(hub.x[1:]>=t[0]);ds=np.diff(hub.x)[keep]
    h3,h2,h1,h0=hub.c[:,keep]
    hc=np.stack([h0,h0+h1*ds/3,h0+2*h1*ds/3+h2*ds**2/3,((h3*ds+h2)*ds+h1)*ds+h0])
    assert hc.min()>0;hm=hc.max();hp=np.max(abs(np.stack([h1,h1+h2*ds,h1+2*h2*ds+3*h3*ds**2])))
    log_rate=hm*b+2/a[:-1]
    second_bound=(bpp+2*log_rate*bp+(log_rate**2+hp*b*b+hm*bp+2/a[:-1]**2)*b)
    error=np.sum(da**3*second_bound)/12*(1+1e-8)+abs(estimate)*1e-11
    return estimate,error

def main():
    med=Medium();rows=[];controls=[];fine={m:Saved(5,m) for m in MODELS}
    old=branches(med,fine,med.a0);other={}
    for m in MODELS:
        eta,ratio,ref,g=med.coord(med.a0,m);t=fine[m].time[::2];point=limit_time(eta,t)
        with np.load(pin(PARENT,'larger-step-'+m+'.npz')) as alt:
            ys=CubicSpline(t,alt['psi']);pd=CubicSpline(t,alt['pd'])
            other[m]=np.array([ys(point,1)*ratio,ratio*(pd(point,1)+med.hub[m](eta,1)*ys(point)+ref*ys(point,1))])
    other['paired']=other['heavy']-other['cold']
    for name,arr in other.items():
        for index,key in enumerate(('refYp','refCp')):
            ref=old[name][key];error=abs(arr[index]-ref)/abs(ref)
            controls.append(dict(model=name,slope=key,relative_change=error,passed=bool(error<=base.TOL)))
    table('endpoint-slope-step.csv',controls)
    for case in read('transported-cut.csv'):
        key=case['model'];m='heavy' if key=='paired' else key
        actual,rad=bracket(med,m,32);coarse,cr=bracket(med,m,8)
        assert abs(actual-coarse)<=rad+cr
        Tc=float(case['current_to_lapse_mpc']);C0=z(case,'cut_C')
        inflation=(abs(Tc-actual)+rad)*abs(C0)
        assert inflation<float(case['Y_quadrature_bracket_radius'])
        rows.append(dict(model=key,T_trapezoid=actual,T_radius=rad,cone_T=Tc,Y_center_integration_radius=inflation,scoring_radius_ratio=inflation/(med.budget/med.coeff['lapse including shear'][0])))
    table('tight-midpoint-bracket.csv',rows)
    print(controls);print(rows[-1],flush=True)

if __name__=='__main__':main()
