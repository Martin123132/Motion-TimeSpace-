from retarded import solve,clock_limits
from bridge64_inputs import *

def main():
    med=Medium();source=next(row for row in read('matched-restart.csv') if row['model']=='paired')
    C0=z(source,'C');Y0=z(source,'Y')
    scale,s,t,w,d,x,limit=solve(med,'heavy',64);mid=np.searchsorted(scale,med.am);hot=np.searchsorted(scale,med.al)
    scale,s,t,w,d=[array[:mid+1] for array in (scale,s,t,w,d)];ds=np.diff(s);tend=t[-1]
    kCupper=w[-1]/w[1:];kClower=w[-1]/w[:-1]
    loTail=np.r_[np.cumsum((np.diff(t)*w[1:]/d[:-1])[::-1])[::-1],0.]
    hiTail=np.r_[np.cumsum((np.diff(t)*w[:-1]/d[1:])[::-1])[::-1],0.]
    kPlo=d[-1]*loTail[1:]/w[:-1];kPhi=d[-1]*hiTail[:-1]/w[1:]
    kVhi=d[-1]/d[1:]
    need={r['quantity']:float(r['one_at_a_time_necessary_ceiling']) for r in read('window-conditions.csv')}
    memC=w[-1]*C0;memY=d[-1]*Y0+x['T'][mid]*C0
    errY=max(x['T'][mid]-limit['T'][0][mid],limit['T'][1][mid]-x['T'][mid])*abs(C0)
    def upper(weights,seg):return (1+1e-9)*np.sum(ds[seg]*weights[seg])
    early=slice(0,hot);late=slice(hot,None)
    earlyC=upper(kCupper,early);hotC=upper(kCupper,late);hotP=upper(kPhi,late);hotV=upper(kVhi,late)
    earlyP=upper(kPhi,early);earlyV=upper(kVhi,early)
    minimum=(abs(memC)-need['midpoint C']-hotC*need['window P'])/earlyC
    scaledY=max(0.,abs(memY)-errY-need['midpoint Y']-hotP*need['window P']-hotV*need['window V'])
    alpha=x['YP'][mid]/x['CP'][mid]
    lower=limit['YP'][0][mid]/limit['CP'][1][mid];higher=limit['YP'][1][mid]/limit['CP'][0][mid]
    assert 0<lower<=alpha<=higher
    alpha_error=max(alpha-lower,higher-alpha)
    kernel=upper(np.maximum(abs(kPlo-higher*kCupper),abs(kPhi-lower*kClower)),slice(None))
    cc=med.coeff['effective current'][0];cy=med.coeff['lapse including shear'][0]
    norm_required=abs(memY-alpha*memC)-errY-alpha_error*abs(memC)-med.budget*max(1/cy,higher/cc)
    assert norm_required>0 and minimum>need['window P'] and scaledY>0
    record('necessary-production.json',dict(early_heavy_from=s[0],early_heavy_to=s[hot],mid=s[-1],
        early_P_sup_at_least=minimum,hot_P_sup_at_most=need['window P'],ratio_early_min_to_hot_max=minimum/need['window P'],
        early_potential_inequality=dict(early_P_gain_upper=earlyP,early_V_gain_upper=earlyV,required_lower=scaledY),
        constant_current_elimination=dict(alpha_mpc=alpha,alpha_lower=lower,alpha_upper=higher,required_lower=norm_required,
            P_deviation_gain_upper=kernel,V_gain_upper=upper(kVhi,slice(None)),min_P_deviation_if_no_V=norm_required/kernel,min_V_if_constant_P=norm_required/upper(kVhi,slice(None))),
        scope='necessary for the inherited positive paired midpoint-and-slope certificate, not for the actual photons to be small'))
    print('Early P floor',minimum,'against hot cap',need['window P'],'ratio',minimum/need['window P'])
    print('Constant P removed',alpha, norm_required,kernel,upper(kVhi,slice(None)),flush=True)

if __name__=='__main__':main()
