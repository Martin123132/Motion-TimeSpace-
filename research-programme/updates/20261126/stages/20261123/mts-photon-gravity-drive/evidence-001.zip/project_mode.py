from common_drive import *

def main():
    guard()
    native=diag.native
    sys.path.insert(0,str(native.SPEC))
    from project_grid import projection
    hist=native.SPEC/'runs/exact-grid/status.json'
    checksum=json.loads(hist.read_bytes())
    proj=native.SPEC/'runs/projection/status.json'
    provenance=json.loads(proj.read_bytes())
    bg=native.NATIVE/'runs/backgrounds/heavy.npz'; requested=native.NATIVE/'runs/final-bg8-start/heavy.npz'
    for file in (bg,requested):
        native.checked(file,checksum['input_hashes'][str(file)])
    for file in (native.SPEC/'project_grid.py',native.SPEC/'spectrum_common.py'):
        native.checked(file,provenance['input_hashes'][str(file)])
    original=native.SPEC/'runs/projection/a225-w6-d8.npz'
    native.checked(original,native.obj(native.source('runs/heavy/status.json'))['source_hash'])
    with np.load(source('medium-heavy.npz')) as bank:wave=bank['modes'][0]
    with np.load(original) as frozen:
        modes=frozen['modes'];anchor=np.argmin(abs(modes-wave));control=modes[anchor]
        assert min(abs(modes/wave-1))>1e-12
        chunk=native.SPEC/f'runs/exact-grid/chunk-{16*(anchor//16):04d}.npz'
        native.checked(chunk,checksum['input_hashes'][str(chunk)])
        with np.load(chunk) as saved:
            assert control in saved['modes']
            cap=saved['modes'][-1]
        sample=np.unique([wave,control,cap]);index=np.searchsorted(sample,control)
        with np.load(requested) as src:scale=src['requested_scale']
        params=native.engine.inherited.params_for(bg)
        engine=native.engine.camb.get_background(params)
        times=engine.conformal_time(1/scale-1,tol=1e-10);engine.Params.Accuracy.IntTolBoost=6
        names=native.engine.camb.model.evolve_names
        values=engine.get_time_evolution(sample,times,vars=names,lAccuracyBoost=4)
        assert np.isfinite(values).all() and np.max(abs(values[:,:,names.index('mts_match_count')]))==0
        keys=['a','H','mts_drho_h','mts_q_h','mts_dp_h']
        compact=values[:,:,[names.index(key) for key in keys]]
        packets={'values':compact,'names':np.asarray(keys),'modes':sample}
        with np.load(bg) as tbl:
            result=projection(packets,tbl,float(frozen['matching_scale']),float(frozen['matching_density']),6,8)
        err=np.abs(np.array([result[key][index]-frozen[label][anchor] for key,label in [('delta','matching_delta'),('momentum','matching_momentum')]]))/result['norm'][index]
        assert np.max(err)<2e-6 and np.max(result['closure_error'][:2])<2e-6,(err,result['closure_error'])
        ix=np.searchsorted(sample,wave)
        pack('exact-matching-row.npz',wave=wave,delta=result['delta'][ix],momentum=result['momentum'][ix],closure=result['closure_error'][ix],control=control,control_error=err,requested=scale,samples=sample,source_fields=compact,names=keys)
        record('projection-inputs.json',{str(file):prior.digest(file) for file in (bg,requested,chunk,original,hist,proj,native.SPEC/'project_grid.py',native.SPEC/'spectrum_common.py')})
        print('matched control errors',err,'target closure',result['closure_error'][ix],flush=True)

if __name__=='__main__':main()
