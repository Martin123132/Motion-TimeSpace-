from common_drive import *

def main():
    guard();seal=HERE/'seal.json'
    sealing=sys.argv[1:]==['--seal'] and not seal.exists()
    if sealing:
        files={path.name:prior.digest(path) for path in sorted(HERE.iterdir()) if path.is_file() and path!=seal}
    else:
        files=json.loads(seal.read_bytes())['files']
        assert all(prior.digest(HERE/name)==value for name,value in files.items())
    cert=json.loads((HERE/'verification.json').read_bytes())
    assert cert['checks']==cert['passed']==42 and cert['inherited_tolerance']==prior.TOL
    assert cert['complete_particular_source'] is False
    assert all(prior.digest(HERE/name)==value for name,value in cert['inputs'].items())
    for file,value in json.loads((HERE/'projection-inputs.json').read_bytes()).items():
        assert prior.digest(Path(file))==value
    ref=source('final-photon-only.npz')
    with np.load(ref) as old:
        for m,key in [('cold','cold'),('heavy','mts')]:
            with np.load(HERE/f'drive-{m}-resolved.npz') as data:
                assert np.array_equal(old[key][0,0],data['free'][0])
                assert np.array_equal(data['regular_drive'][0],np.zeros(2))
                assert np.allclose(data['free']+data['regular_drive'],data['partial_sum'],rtol=2e-10,atol=1e-24)
    with (HERE/'checks.csv').open() as stream:rows=list(csv.DictReader(stream))
    selected=[row for row in rows if row['gate']=='True']
    assert len(selected)==42 and all(max(float(row['rms_delta']),float(row['peak_delta']))<=prior.TOL for row in selected)
    assert any(row['gate']=='False' and row['passed']=='False' for row in rows)
    assert not list(HERE.glob('reader-drive-*'))
    if sealing:record('seal.json',dict(files=files,parent_seal=prior.digest(PRE/'seal.json')))
    print('Verified',len(files),'stage files, native projection provenance, both launch vectors and 42 numerical checks.')

if __name__=='__main__':main()
