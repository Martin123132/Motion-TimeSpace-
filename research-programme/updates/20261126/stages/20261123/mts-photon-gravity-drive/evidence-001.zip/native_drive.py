from common_drive import *
from capture_early import driver, Dummy, patch, tempfile, subprocess
import os

NAMES='tau k a adotoa etak etakdot sigma sigmadot phi grho gpres dgq vb clxg qg pig E(2) octg E(3)'.split()

def run(model,func):
    guard()
    coeff,pair,clock,metric=preparation(model)
    native=diag.native
    status=native.obj(native.source(f'runs/{model}/status.json'))
    bgfile=native.SPEC/'runs/projection/a225-w6-d8.npz' if model=='heavy' else native.NATIVE/'runs/backgrounds/cold.npz'
    native.checked(bgfile,status['source_hash'])
    for path in native.engine.inherited.native_hashes():native.checked(path,status['input_hashes'][str(path)])
    params=native.engine.inherited.params_for(bgfile,background_boost=8.)
    if model=='heavy':
        with np.load(bgfile) as old,np.load(HERE/'exact-matching-row.npz') as row:
            modes=np.append(old['modes'],row['wave']);order=np.argsort(modes)
            assert np.min(np.diff(modes[order]))>0
            params.DarkEnergy.set_table('SetMatching',modes[order],np.append(old['matching_delta'],row['delta'])[order],np.append(old['matching_momentum'],row['momentum'])[order])
    assert str(params.scalar_initial_condition)=='initial_adiabatic'
    params.DoLateRadTruncation=False
    bg=native.engine.camb.get_background(params);bg.Params.Accuracy.IntTolBoost=6
    with np.load(source(f'medium-{model}.npz')) as data:
        scale=data['scale'];eta=data['eta'];wave=data['modes'][0]
    dense=os.environ.get('MTS_DENSE_DRIVE')=='1'
    if dense:
        middle=np.linspace(scale[0],scale[544],544*32+1)
        refined=np.r_[middle,scale[545:]]
        refined[:len(middle):32]=scale[:545]
        eta=CubicSpline(scale,eta,extrapolate=False)(refined)
        scale=refined
    with pin(f'capture-{model}.csv').open() as stream:block=list(csv.DictReader(stream))[-1]
    batch=np.unique([wave,float(block['hierarchy_cap'])])
    pre=clock[::16]
    times=np.unique(np.r_[pre,eta])
    assert times[0]>=clock[0]
    idx=np.searchsorted(times,eta);idx_pre=np.searchsorted(times,pre)
    for boost in (4,8):
        guard()
        with patch.object(diag.symbolic,'compile_sympy_to_camb_source_func',return_value=func):
            output=bg.get_time_evolution(batch,times,vars=[Dummy(key) for key in NAMES],lAccuracyBoost=boost)[0]
        raw=dict(zip(NAMES,output.T))
        assert np.all(np.isfinite(output)) and np.max(abs(raw['tau']-times))<1e-7 and np.max(abs(raw['k']/wave-1))<1e-12
        h=raw['adotoa'];alpha=raw['sigma']/wave
        phi=raw['etak']/wave-h*alpha;psi=2*raw['phi']-phi
        pd=(raw['dgq']+(raw['grho']+raw['gpres'])*raw['sigma'])/(2*wave)-h*psi
        pd2=(raw['etakdot']-h*raw['sigmadot'])/wave+(raw['grho']+3*raw['gpres'])*alpha/6
        delta=np.column_stack((phi,psi))[idx_pre]*pair
        reference=metric[::16,:,1]-metric[::16,:,0]
        overlap=np.max(abs(delta-reference),axis=0)/np.max(abs(reference),axis=0)
        slope_check=np.max(abs(pd-pd2))/np.max(abs(pd))
        print(model,boost,'overlap',overlap,'derivative',slope_check,flush=True)
        assert max(overlap)<prior.TOL and slope_check<prior.TOL
        assert np.max(abs(raw['a'][idx]/scale-1))<1e-5
        density=raw['clxg']-4*h*alpha;flux=raw['qg']+4*raw['sigma']/3;velocity=4*(raw['vb']+raw['sigma'])/3
        launch=np.array([density[idx[0]],velocity[idx[0]],flux[idx[0]],raw['pig'][idx[0]],raw['E(2)'][idx[0]],raw['octg'][idx[0]],raw['E(3)'][idx[0]]])
        prefix='dense' if dense else 'regular'
        pack(f'{prefix}-{model}-{boost}.npz',scale=scale,eta=eta,k=wave,phi=phi[idx],psi=psi[idx],phi_dot=pd[idx],independent_dot=pd2[idx],native=np.column_stack((density,flux))[idx],initial=launch,pair=pair,coef=coeff,overlap=overlap,derivative_check=slope_check,particular_seam=CubicSpline(clock,metric[:,:,0],extrapolate=False)(np.clip(eta[0],clock[0],clock[-1])),regular_seam=coeff*pair*np.array([phi[idx[0]],psi[idx[0]]]))

if __name__=='__main__':
    if sys.argv[1:2]==['--child']:
        with patch.object(driver,'HERE',HERE),patch.object(driver,'NAMES',NAMES),patch.object(driver,'run',run),patch.object(driver,'save',put):
            driver.main()
    else:
        with tempfile.TemporaryDirectory(dir=HERE,prefix='reader-drive-') as folder:
            subprocess.run([sys.executable,'-B',str(HERE/'native_drive.py'),'--child',folder],check=True)
