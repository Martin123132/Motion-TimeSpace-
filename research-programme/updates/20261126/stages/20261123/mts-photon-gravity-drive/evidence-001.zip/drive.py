from common_drive import *
from transfer import stages,physics,solve_banded

CONFIG={'primary':(192,16384,1,8),'time':(192,8192,1,8),'angle':(128,16384,1,8),'source':(192,16384,2,8),'native':(192,16384,1,4)}
CONFIG.update({'resolved':(192,16384,1,8),'dtime':(192,8192,1,8),'dangle':(128,16384,1,8),'dsource':(192,16384,2,8),'dnative':(192,16384,1,4)})
LABELS=['free-real','free-imag','unit-drive','native-control','sum-real','sum-imag','shifted-drive']

def integrate(model,tag):
    guard()
    order,count,stride,boost=CONFIG[tag]
    dense=tag in ('resolved','dtime','dangle','dsource','dnative')
    prefix='dense' if dense else 'regular'
    with np.load(HERE/f'{prefix}-{model}-{boost}.npz') as raw:
        k=float(raw['k']);weight=complex(raw['coef']*raw['pair']);metric=np.column_stack((raw['phi_dot'],raw['psi'],raw['phi']));at0=raw['initial'];native_photons=raw['native']
        source_axis=raw['scale']
    with np.load(source(f'medium-{model}.npz')) as raw:
        grid=raw['scale'];clock=raw['eta'];launch=raw['launch'][:,0]
        rates=physics(*(raw[key] for key in ('scale','eta','hub','loading','opacity')),count)
        medium=np.column_stack([raw[key] for key in ('hub','loading','opacity')])
    assert grid.size==4097
    radau=np.array([[5/12,-1/12],[3/4,1/4]])
    waves=grid[0]+(np.arange(count)[:,None]+[1/3,1])*(grid[-1]-grid[0])/count
    waves[-1,-1]=grid[-1]
    if dense:
        subdivisions=np.full(4096,count//4096)
        subdivisions[:544]=16 if tag=='dtime' else 32
        left=np.repeat(grid[:-1],subdivisions)
        widths=np.repeat(np.diff(grid)/subdivisions,subdivisions)
        ends=np.cumsum(subdivisions);count=ends[-1]
        loc=np.arange(count)-np.repeat(np.r_[0,ends[:-1]],subdivisions)
        waves=left[:,None]+widths[:,None]*(loc[:,None]+[1/3,1])
        waves[ends-1,1]=grid[1:]
        clock_step=CubicSpline(grid,clock)(waves,1)*widths[:,None]
        hub,loading,op=CubicSpline(grid,medium,extrapolate=False)(waves).transpose(2,0,1)
        rates=np.stack([clock_step,clock_step*op,clock_step*op/loading,clock_step*hub],axis=-1)
        saved_idx=np.searchsorted(source_axis,grid)
        assert np.array_equal(source_axis[saved_idx],grid)
        native_photons=native_photons[saved_idx]
    else:
        ends=np.arange(count//4096,count+1,count//4096)
        saved_idx=np.arange(4097)
    emit=np.zeros(count,dtype=int);emit[ends-1]=np.arange(1,4097)
    fields=CubicSpline(source_axis[::stride],metric[::stride],axis=0,extrapolate=False)(waves)
    assert np.isfinite(fields).all()
    phi0=metric[0,2];dphi=fields[:,:,2]-phi0
    base=stages(order);size=base.shape[-1]//2
    columns=len(LABELS);history=np.empty((len(grid),columns,2))
    state=np.zeros((size,columns))
    state[[0,2],0]=launch.real;state[[0,2],1]=launch.imag
    state[:len(at0),3]=at0
    state[:,4:6]=state[:,:2]
    history[0]=state[[0,2]].T
    proportional=np.array([0,0,1,1,weight.real,weight.imag,1])
    source_D=(rates[:,:,0]*(4*fields[:,:,0]))@radau.T
    source_J=(rates[:,:,0]*(4*k/3*fields[:,:,1]))@radau.T
    extra_J=(rates[:,:,0]*(4*k/3*dphi))@radau.T
    source_D=source_D[:,:,None]*proportional
    source_D[:,:,-1]=0
    force_U=source_J[:,:,None]*proportional
    force_J=force_U.copy();force_J[:,:,-1]+=extra_J
    packed=np.empty((size*2,columns),order='F')
    for begin in range(0,count,32):
        if begin%1024==0:guard()
        coeffs=rates[begin:begin+32].copy();coeffs[:,:,0]*=k
        mats=(coeffs.reshape(-1,8)@base.reshape(8,-1)).reshape(-1,11,size*2)
        mats[:,5,:]+=1
        for step,matrix in enumerate(mats,begin):
            packed[::2]=state;packed[1::2]=state
            packed[:2]+=source_D[step];packed[2:4]+=force_U[step];packed[4:6]+=force_J[step]
            state=solve_banded((5,5),matrix,packed,check_finite=False)[1::2]
            if emit[step]:
                pos=emit[step]
                history[pos]=state[[0,2]].T
                history[pos,-1,0]+=4*(metric[saved_idx[pos],2]-phi0)
    assert np.isfinite(history).all()
    unit=history[:,2]
    free=history[:,0]+1j*history[:,1]
    injected=unit*weight
    total=history[:,4]+1j*history[:,5]
    drift=np.max(abs(total-injected-free),axis=0)/abs(total).max(axis=0)
    with np.load(source('final-photon-only.npz')) as old:
        previous=old['cold' if model=='cold' else 'mts'][:,0]
    replay=np.max(abs(free-previous),axis=0)/abs(previous).max(axis=0)
    assert np.max(replay)<prior.TOL and np.max(drift)<1e-9,(drift,replay)
    pack(f'drive-{model}-{tag}.npz',scale=grid,k=k,free=free,regular_drive=injected,partial_sum=total,unit=unit,native_reference=native_photons,native_control=history[:,3],shifted=weight*history[:,-1],additivity=drift,replay=replay,weight=weight)
    print(model,tag,'native replay',np.linalg.norm(history[:,3]-native_photons)/np.linalg.norm(native_photons),'shifted',np.linalg.norm(history[:,-1]-unit)/np.linalg.norm(unit),flush=True)

if __name__=='__main__':
    for tag in sys.argv[1:] or CONFIG:
        for model in ('cold','heavy'):
            integrate(model,tag)
