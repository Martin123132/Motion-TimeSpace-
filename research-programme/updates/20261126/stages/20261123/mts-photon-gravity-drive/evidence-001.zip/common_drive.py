from pathlib import Path
import sys
import csv
import io
import json
import hashlib

HERE=Path(__file__).resolve().parent
PRE=HERE.parent/'mts-photon-scattering-transfer-20261123'
sys.path.insert(0,str(PRE))
from background import np, CubicSpline, prior, diag
from workspace import pin, retained

def guard():
    prior.check()
    assert not (PRE/'STOP-REQUESTED').exists() and not (HERE/'STOP-REQUESTED').exists()

def put(name,data):
    guard()
    path=HERE/name
    if path.exists():
        assert prior.digest(path)==hashlib.sha256(data).hexdigest(),name
    else:
        with path.open('xb') as stream:stream.write(data)

def pack(name,**fields):
    stream=io.BytesIO();np.savez_compressed(stream,**fields);put(name,stream.getvalue())

def table(name,rows):
    stream=io.StringIO()
    out=csv.DictWriter(stream,rows[0],lineterminator='\n')
    out.writeheader();out.writerows(rows);put(name,stream.getvalue().encode())

def record(name,fields):
    put(name,(json.dumps(fields,indent=2,sort_keys=True)+'\n').encode())

def source(name):
    seal=PRE/'seal.json'
    assert prior.digest(seal)=='d8d6904fe2c72f0c91e1b652d2f30915f1007d3bbac04f6d65f819ac7953e894'
    path=PRE/name
    assert prior.digest(path)==json.loads(seal.read_bytes())['files'][name]
    return path

def preparation(model):
    seal=json.loads(source('input-receipt.json').read_bytes())
    file=retained('fixed-early-amplitudes.npz')
    assert prior.digest(file)==seal['source_digests'][file.name]
    with np.load(file) as saved:
        assert tuple(saved['coord'][0])==(4,2,1)
        coeff=saved['coefficients'][0,prior.SLOTS[model]]
    with np.load(retained(f'origin-v2-{model}.npz')) as saved:
        pair=saved['pairs'][0]
    path=prior.HOME/f'fine77-{model}-outer.npz'
    assert prior.digest(path)==seal['source_digests'][path.name]
    with np.load(path) as saved:
        clock=saved['eta'];metric=saved['obs'][:,:2,0,:]
    return coeff,pair,clock,metric
