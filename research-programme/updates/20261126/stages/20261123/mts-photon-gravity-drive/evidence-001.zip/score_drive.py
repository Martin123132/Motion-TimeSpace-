from common_drive import *
from scipy.integrate import simpson

def main():
    guard()
    tags=('resolved','dtime','dsource','dangle','dnative','primary')
    data={};seams=[];hashes={}
    scope=[]
    for model in ('cold','heavy'):
        with np.load(source(f'medium-{model}.npz')) as native:
            if model=='cold':
                grid=native['scale'];clock=native['eta'];vis=native['visibility']
            assert np.array_equal(grid,native['scale'])
            start=native['eta'][0]
        with np.load(HERE/f'dense-{model}-8.npz') as metric:
            weight=complex(metric['pair']*metric['coef'])
            regular=weight*np.array([metric['phi_dot'][0],metric['psi'][0]])
        path=prior.HOME/f'forcing-{model}.npz'
        before=json.loads(source('input-receipt.json').read_bytes())['source_digests']
        assert prior.digest(path)==before[path.name]
        with np.load(path) as force:
            back=dict(zip(force['bgkeys'],force['background']))
            fields=dict(zip(force['keys'],force['values']))
            q=fields['Fq'][:,0];hub=back['h']
        path=prior.HOME/f'fine77-{model}-outer.npz'
        assert prior.digest(path)==before[path.name]
        with np.load(path) as raw:
            eta=raw['eta'];obs=raw['obs'][:,:,0,0];wave=raw['k'][0]
            sample=min(start,eta[-1])
            dot=CubicSpline(eta,obs[:,0])(sample,1)
            constrained=CubicSpline(eta,-obs[:,3]/eta-hub*obs[:,1]+q)(sample)
            lapse=CubicSpline(eta,obs[:,1])(sample)
        error=abs((constrained-dot)/dot);assert error<prior.TOL
        for ix,(label,value) in enumerate([('4Phi_dot',4*constrained),('4kPsi/3',4*wave*lapse/3)]):
            ref=regular[ix]*(4 if ix==0 else 4*wave/3)
            seams.append(dict(model=model,source=label,particular_re=value.real,particular_im=value.imag,regular_re=ref.real,regular_im=ref.imag,particular_over_regular=abs(value/ref),curvature_derivative_independent_relative=error))
        prior87=HERE.parent/'mts-species-constraint-gravity-20261122'/f'linear-{model}-16.npz'
        other=HERE.parent/'mts-recombination-counterflow-20261118'/f'history-{model}.npz'
        for loc,key,desc in [(path,'eta','both 77-bin metric bases; regular origin and frozen coefficients; no extrapolation'),(prior87,'eta','same output k, regular linear reference for separately initialized short calculation; not later forced 77-bin history'),(other,'time','different two-wave experiment; not the retained 77-bin source')]:
            with np.load(loc) as raw:
                axis=raw[key]
                scope.append(dict(model=model,path=str(loc),first_mpc=axis[0],last_mpc=axis[-1],meaning=desc))
        path=HERE/f'dense-{model}-8.npz'
        with np.load(path) as raw:scope.append(dict(model=model,path=str(path),first_mpc=raw['eta'][0],last_mpc=raw['eta'][-1],meaning='exact k native regular transfer only; checked against difference of 77-bin bases'))
        for tag in tags:
            path=HERE/f'drive-{model}-{tag}.npz'
            hashes[path.name]=prior.digest(path)
            with np.load(path) as bank:
                assert np.array_equal(grid,bank['scale'])
                values={key:bank[key] for key in ('free','regular_drive','partial_sum','shifted')}
                values['native']=weight*bank['native_reference'];values['control']=weight*bank['native_control']
                assert np.max(bank['additivity'])<1e-9 and np.max(bank['replay'])<prior.TOL
                assert np.array_equal(values['regular_drive'][0],np.zeros(2))
                data[tag,model]=values
    for tag in tags:
        data[tag,'MTS-minus-cold']={key:val-data[tag,'cold'][key] for key,val in data[tag,'heavy'].items()}
    spline=lambda arr: CubicSpline(grid,arr,axis=0,extrapolate=False)
    window=np.linspace(1/1501,grid[-1],8193); peak=json.loads(source('score.json').read_bytes())['visibility']['cold']['peak_scale']
    w=spline(vis)(window)*spline(clock)(window,1)
    w/=simpson(w,x=window)
    def parts(arr):
        return np.sqrt(simpson(w[:,None]*abs(spline(arr)(window))**2,x=window,axis=0))
    def size(arr):
        return np.array([np.linalg.norm(parts(arr)),np.linalg.norm(spline(arr)(peak))])
    comparisons=[];summary=[];markers=[];interference=[]
    for model in ('cold','heavy','MTS-minus-cold'):
        result=data['resolved',model]
        den=np.linalg.norm(result['free'][0])
        def check(tag,component,left,right,gate=True):
            errors=size(left-right)/size(right)
            comparisons.append(dict(model=model,test=tag,component=component,gate=gate,rms_delta=errors[0],peak_delta=errors[1],passed=bool(max(errors)<=prior.TOL)))
        for key in ('free','regular_drive','partial_sum'):
            vec=result[key]
            for tag in ('dtime','dsource','dangle','dnative'):
                check(tag,key,data[tag,model][key],vec)
            summary.append(dict(model=model,signal=key,launch_normalization=den,rms_over_launch=size(vec)[0]/den,peak_over_launch=size(vec)[1]/den,energy_rms_over_launch=parts(vec)[0]/den,current_rms_over_launch=parts(vec)[1]/den))
            for label,at in [('launch',grid[0]),('z1500',1/1501),('peak',peak),('z750',grid[-1])]:
                energy,current=spline(vec)(at);markers.append(dict(model=model,signal=key,marker=label,scale=at,energy_real=energy.real,energy_imag=energy.imag,current_real=current.real,current_imag=current.imag))
        check('shifted variable','regular_drive',result['shifted'],result['regular_drive'])
        check('independent native photon history','control, native initial plasma',result['control'],result['native'])
        check('initial unresolved source grid','dual equation regular drive',data['primary',model]['shifted'],data['primary',model]['regular_drive'],False)
        free=result['free'];drive=result['regular_drive']
        product=2*np.real(simpson(w*np.sum(spline(free)(window).conj()*spline(drive)(window),axis=1),x=window))
        assert abs((size(free)[0]**2+size(drive)[0]**2+product)/size(result['partial_sum'])[0]**2-1)<1e-9
        interference.append(dict(model=model,power_cross_over_launch_squared=product/den**2,weighted_alignment=product/(2*size(free)[0]*size(drive)[0])))
    table('source-coverage.csv',scope);table('seam-forcing.csv',seams);table('results.csv',summary);table('signed-markers.csv',markers);table('checks.csv',comparisons);table('interference.csv',interference)
    gated=[r for r in comparisons if r['gate']]
    record('verification.json',dict(inherited_tolerance=prior.TOL,checks=len(gated),passed=sum(r['passed'] for r in gated),max_rms=max(r['rms_delta'] for r in gated),max_peak=max(r['peak_delta'] for r in gated),complete_particular_source=False,scope='photon-only launch plus regular curvature gravitational drive, not full second-order history',inputs=hashes))
    print([r for r in summary if r['model']=='MTS-minus-cold'])
    print('failed checks',[r for r in gated if not r['passed']],flush=True)
    assert all(r['passed'] for r in gated)

if __name__=='__main__':main()
