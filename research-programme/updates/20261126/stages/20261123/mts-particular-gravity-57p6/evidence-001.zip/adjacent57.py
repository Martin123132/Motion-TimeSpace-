from block import *
from scipy.integrate import simpson


def main():
    guard()
    histories={}
    for model in ('cold','heavy'):
        with np.load(previous(f'transfer-{model}-primary-p4.npz')) as prior, np.load(ROOT/f'transfer-{model}-primary-p4.npz') as current, np.load(inherited.source(f'medium-{model}.npz')) as bath:
            assert np.array_equal(current['scale'],bath['scale']) and np.array_equal(current['scale'],prior['scale'])
            before=bath['eta']<=51.2
            assert before.any() and not np.any(current['block'][before])
            assert np.array_equal(current['prior_sum'],prior['new_partial'])
            histories[model]=dict(first=prior['block'],second=current['block'],earlier=prior['prior_sum'],total=current['new_partial'],launch=prior['old_free'][0])
    histories['MTS-minus-cold']={key:val-histories['cold'][key] for key,val in histories['heavy'].items()}
    with np.load(inherited.source('medium-cold.npz')) as bath:
        grid=bath['scale']; axis=np.linspace(1/1501,grid[-1],8193)
        weights=CubicSpline(grid,bath['visibility'])(axis)*CubicSpline(grid,bath['eta'])(axis,1)
    weights/=simpson(weights,x=axis)
    peak=json.loads(inherited.source('score.json').read_bytes())['visibility']['cold']['peak_scale']
    rows=[]
    for label,saved in histories.items():
        launch=np.linalg.norm(saved['launch'])
        early,first,second,full=[saved[key] for key in ('earlier','first','second','total')]
        assert np.max(abs(early+first+second-full))<1e-10*max(np.max(abs(full)),1e-200)
        for where in ('rms','peak'):
            def inner(left,right):
                if where=='peak':return float(np.vdot(CubicSpline(grid,left)(peak),CubicSpline(grid,right)(peak)).real)
                left=CubicSpline(grid,left)(axis);right=CubicSpline(grid,right)(axis)
                return float(simpson(weights*np.sum((left.conj()*right).real,axis=1),x=axis))
            first2=inner(first,first);second2=inner(second,second);cross=inner(first,second);both=inner(first+second,first+second)
            assert abs(both-first2-second2-2*cross)<=1e-10*(first2+second2)
            rows.append(dict(model=label,measure=where,first_over_launch=first2**.5/launch,second_over_launch=second2**.5/launch,both_blocks_over_launch=both**.5/launch,adjacent_alignment=cross/(first2*second2)**.5,partial_over_launch=inner(full,full)**.5/launch))
    table('adjacent-blocks.csv',rows)


if __name__=='__main__':main()
