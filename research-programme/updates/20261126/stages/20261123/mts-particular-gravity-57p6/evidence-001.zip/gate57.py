from block import *

def check():
    guard()
    fields={}
    for model in ('cold','heavy'):
        with np.load(ROOT/f'particular-{model}-p4.npz') as raw:
            assert np.array_equal(raw['eta'][[0,-1]],[51.2,57.6]) and len(raw['eta'])==4097
            fields[model]=(raw['a'],np.column_stack([raw['phi_dot'],raw['differentiated']]))
        status=json.loads((ROOT/f'metric-{model}-p4.json').read_bytes())
        assert status['passed'] and status['parent']==digest(restart(model))
    common=np.linspace(max(field[0][0] for field in fields.values()),min(field[0][-1] for field in fields.values()),513)
    matched={model:CubicSpline(axis,values,axis=0,extrapolate=False)(common) for model,(axis,values) in fields.items()}
    matched['MTS-minus-cold']=matched['heavy']-matched['cold']
    diffs={model:float(np.max(abs(values[:,0]-values[:,1]))/np.max(abs(values[:,0]))) for model,values in matched.items()}
    with (ROOT/'matched-step-check.csv').open() as stream:
        steps=list(csv.DictReader(stream))
    assert len(steps)==9
    worst=max(float(row['relative']) for row in steps)
    passed=bool(worst<=.005 and max(diffs.values())<=.005)
    record('pre-transport-gate.json',dict(passed=passed,derivative_disagreement=diffs,largest_doubled_step_change=worst,threshold=.005))
    if not passed:raise ArithmeticError('signed metric gate did not pass')

if __name__=='__main__':check()
