from block import *
from scipy.integrate import simpson

def main():
    guard()
    with np.load(inherited.source('medium-cold.npz')) as bath:
        grid=bath['scale'];axis=np.linspace(1/1501,grid[-1],8193)
        weights=CubicSpline(grid,bath['eta'])(axis,1)*CubicSpline(grid,bath['visibility'])(axis)
    weights/=simpson(weights,x=axis)
    peak=json.loads(inherited.source('score.json').read_bytes())['visibility']['cold']['peak_scale']
    def sizes(values):
        signal=CubicSpline(grid,values)
        return np.array([np.sqrt(simpson(weights*np.sum(abs(signal(axis))**2,axis=1),x=axis)),np.linalg.norm(signal(peak))])
    rows=[]
    for tag in ('primary','time','angle','sampling','materialstep'):
        parts={}
        for model in ('cold','heavy'):
            name=f'transfer-{model}-{tag}-p2.npz'
            with np.load(previous(name)) as old,np.load(ROOT/name) as new:
                assert np.array_equal(grid,old['scale']) and np.array_equal(grid,new['scale'])
                parts[model]=(old['new_partial'],new['block'],old['old_free'][0])
        parts['MTS-minus-cold']=tuple(second-first for second,first in zip(parts['heavy'],parts['cold']))
        for model,(prior,block,launch) in parts.items():
            change=100*(sizes(prior+block)-sizes(prior))/np.linalg.norm(launch)
            rows.append(dict(control=tag,model=model,rms_change_percentage_points=change[0],peak_change_percentage_points=change[1]))
    table('direction-under-paired-controls.csv',rows)

if __name__=='__main__':main()
