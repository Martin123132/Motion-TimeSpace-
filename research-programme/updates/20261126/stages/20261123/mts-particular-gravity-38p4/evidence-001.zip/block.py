from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parent
PRE=ROOT.parent/'mts-photon-gravity-drive-20261123'
BASE=ROOT.parent/'mts-particular-gravity-32-20261123'
sys.path.insert(0,str(PRE))
import common_drive as inherited
from workspace import *
import common_drive
import io,csv,json,hashlib

OLD=HOME
def guard():
    inherited.guard()
    assert not (BASE/'STOP-REQUESTED').exists()
    assert not (ROOT/'STOP-REQUESTED').exists()
def save(name,raw):
    guard();path=ROOT/name
    if path.exists():assert digest(path)==hashlib.sha256(raw).hexdigest(),name
    else:
        with path.open('xb') as stream:stream.write(raw)
def pack(name,**fields):
    stream=io.BytesIO();np.savez_compressed(stream,**fields);save(name,stream.getvalue())
def table(name,rows):
    stream=io.StringIO();out=csv.DictWriter(stream,rows[0],lineterminator='\n');out.writeheader();out.writerows(rows);save(name,stream.getvalue().encode())
def record(name,body):save(name,(json.dumps(body,indent=2,sort_keys=True)+'\n').encode())
def predecessor(name):
    guard()
    seal=PRE/'seal.json';assert digest(seal)=='d65afa72b931c22b6462602afca73d745cb042db30e0e4e6cd206195f0c5a80e'
    path=PRE/name;assert digest(path)==json.loads(seal.read_bytes())['files'][name];return path
def previous(name):
    guard()
    seal=BASE/'seal.json'
    assert digest(seal)=='f0038e184106d6885849758e773a129936f71fc0767c020620dd71b2a31676c9'
    path=BASE/name
    assert digest(path)==json.loads(seal.read_bytes())['files'][name],name
    return path
def restart(model):return previous(f'particular-{model}-p2.npz')
