from pathlib import Path
import csv
import hashlib
import io
import json
import sys

ROOT = Path(__file__).resolve().parent
PREVIOUS = ROOT.parent / 'mts-frozen-photon-readout-20261123'
sys.path.insert(0, str(PREVIOUS))
import test_frozen_photons as prior
from capture_early import diag
from workspace import np, CubicSpline

MODELS = ('cold', 'heavy')
END = 1 / 751
RECEIPT = '40716da3cf9c181a5e7ee553bc88ca4a1d9b34642f5e061b7771e68691b7df25'

def guard():
    prior.check()
    assert not (ROOT / 'STOP-REQUESTED').exists()

def save(name, data):
    guard()
    path = ROOT / name
    if path.exists():
        assert prior.digest(path) == hashlib.sha256(data).hexdigest(), name
    else:
        with path.open('xb') as stream:
            stream.write(data)

def archive(name, **values):
    stream = io.BytesIO()
    np.savez_compressed(stream, **values)
    save(name, stream.getvalue())

def table(name, rows):
    stream = io.StringIO()
    writer = csv.DictWriter(stream, rows[0], lineterminator='\n')
    writer.writeheader()
    writer.writerows(rows)
    save(name, stream.getvalue().encode())

def record(name, obj):
    save(name, (json.dumps(obj, indent=2, sort_keys=True) + '\n').encode())

def inputs():
    guard()
    assert prior.digest(PREVIOUS / 'receipt.json') == RECEIPT
    sources, coef, initial, scales, _, _ = prior.load_frozen()
    fixed, _, _, _ = prior.read_grid('fine77', sources, coef, initial, scales)
    return sources, initial, scales[-1], fixed

def main():
    sources, initial, start, fixed = inputs()
    native = diag.native
    scale = np.linspace(start, END, 4097)
    for model in MODELS:
        guard()
        state = native.obj(native.source(f'runs/{model}/status.json'))
        path = native.SPEC/'runs/projection/a225-w6-d8.npz' if model == 'heavy' else native.NATIVE/'runs/backgrounds/cold.npz'
        native.checked(path, state['source_hash'])
        for file in native.engine.inherited.native_hashes():
            native.checked(file, state['input_hashes'][str(file)])
        params = native.engine.inherited.params_for(path, background_boost=8.)
        engine = native.engine.camb.get_background(params)
        redshift = 1 / scale - 1
        eta = engine.conformal_time(redshift, presorted=False)
        thermo = engine.get_background_time_evolution(eta, vars=['opacity','visibility'], format='dict')
        hub = engine.h_of_z(redshift) * scale
        rho = engine.get_background_densities(scale, vars=['baryon','photon'])
        loading = .75 * rho['baryon'] / rho['photon']
        clock, early_scale, modes, eg, eb, *_ = initial[model]
        with np.load(prior.HOME/f'forcing-{model}.npz') as bank:
            early = dict(zip(bank['bgkeys'], bank['background']))
            expected = [np.interp(start, early_scale, arr) for arr in (clock,early['opacity'],early['h'],.75*early['eb']/early['eg'])]
        join = np.array([eta[0],thermo['opacity'][0],hub[0],loading[0]]) / expected - 1
        assert np.max(abs(join)) < prior.TOL and np.all(np.diff(eta)>0), join
        slope = CubicSpline(scale,eta)(scale,1)
        diff = np.max(abs(slope * scale * hub - 1))
        assert diff < prior.TOL and np.min(thermo['opacity'])>0 and np.min(thermo['visibility'])>=0
        archive(f'medium-{model}.npz', scale=scale, eta=eta, hub=hub, loading=loading, opacity=thermo['opacity'], visibility=thermo['visibility'], modes=modes, launch=fixed[model][-1], join=join, clock_derivative_error=diff)
        sources[str(path)] = state['source_hash']
        sources.update(state['input_hashes'])
        print(model, eta[[0,-1]], scale[np.argmax(thermo['visibility'])], join, diff, flush=True)
    record('input-receipt.json', dict(tolerance=prior.TOL, previous_receipt=RECEIPT, source_digests=sources, media={m:prior.digest(ROOT/f'medium-{m}.npz') for m in MODELS}))

if __name__ == '__main__':
    main()
