from background import ROOT, MODELS, np, prior, CubicSpline, guard, table, archive, record
from scipy.integrate import simpson, cumulative_trapezoid
import json

RUNS = ['L64-N8192-b1','L64-N16384-b1','L128-N16384-b1','L192-N16384-b1','L64-N8192-b2']
CONTROL_PAIRS = [(2,3,'128 to 192 angular'),(1,2,'64 to 128 angular diagnostic'),(0,1,'time'),(4,0,'medium')]
GATES = {'128 to 192 angular','time','medium','readout'}

def main():
    guard()
    initial={}
    med={}
    kernels={}
    peak=json.loads((ROOT/'score.json').read_bytes())['visibility']['cold']['peak_scale']
    for model in MODELS:
        with np.load(ROOT/f'medium-{model}.npz') as bank:
            initial[model]=bank['launch'].T
            med[model]={key:bank[key] for key in ('scale','eta','visibility','modes')}
        for run in RUNS:
            with np.load(ROOT/f'kernels-{model}-{run}.npz') as bank:
                kernels[run,model]=bank['K']
                assert np.array_equal(bank['scale'],med[model]['scale'][::4])
    assert np.array_equal(med['cold']['scale'],med['heavy']['scale'])
    axis=med['cold']['scale'][::4]
    waves=med['cold']['modes']
    def curve(data,step=1):
        return CubicSpline(axis[::step],data[::step],axis=0,extrapolate=False)
    def surface(redshift,model='cold'):
        info=med[model];native=info['scale']
        low=1/(1+redshift) if redshift else axis[0]
        nodes=np.linspace(low,axis[-1],8193)
        weight=CubicSpline(native,info['visibility'])(nodes)*CubicSpline(native,info['eta'])(nodes,1)
        weight=np.maximum(weight,0)
        return nodes,weight/simpson(weight,x=nodes)
    window=surface(1500)
    def integrate(sample,window):
        nodes,weight=window
        return simpson(np.abs(sample)**2*weight[:,None,None],x=nodes,axis=0)
    def energy(data,window=window,step=1):
        return integrate(curve(data,step)(window[0]),window)
    def rms(data,window=window):
        return np.sqrt(energy(data,window).sum(axis=1))
    def norm(data):
        return np.linalg.norm(data,axis=-1)
    def apply(matrix,vec):
        return np.einsum('tmij,mj->tmi',matrix,vec)
    details=[];checks=[];markers=[]
    for control in (False,True):
        role='comoving' if control else 'photon-only tag'
        launch={m:np.column_stack((initial[m],initial[m][:,1]*int(control))) for m in MODELS}
        full={}
        for run in RUNS:
            full[run]={m:apply(kernels[run,m],launch[m]) for m in MODELS}
            full[run]['signed contrast']=full[run]['heavy']-full[run]['cold']
        chosen=RUNS[3];targets=full[chosen];contrast=targets['signed contrast']
        start=norm(contrast[0])
        for label in ('cold','heavy','signed contrast'):
            rep=[]
            for low,high,test in CONTROL_PAIRS:
                lhs=full[RUNS[low]][label];rhs=full[RUNS[high]][label]
                delta=lhs-rhs
                rep.append((test,rms(delta)/rms(rhs),norm(curve(delta)(peak))/norm(curve(rhs)(peak)),abs(delta).max(axis=0)/abs(rhs).max(axis=0)))
            primary=targets[label]
            s0,s1=curve(primary),curve(primary,2)
            samples=s0(window[0]);err=samples-s1(window[0])
            err_window=np.sqrt(integrate(err,window).sum(axis=1))/rms(primary)
            err_peak=norm(s0(peak)-s1(peak))/norm(s0(peak))
            amplitude=abs(primary-s1(axis)).max(axis=0)/abs(primary).max(axis=0)
            rep.append(('readout',err_window,err_peak,amplitude))
            for test,movement,point,change in rep:
                for col,wave in enumerate(waves):
                    checks.append(dict(k=wave,baryon_launch=role,quantity=label,control=test,gate=test in GATES,window_change=movement[col],peak_change=point[col],energy_trajectory_change=change[col,0],current_trajectory_change=change[col,1]))
        model_difference=apply((kernels[chosen,'heavy']-kernels[chosen,'cold'])*.5,launch['heavy']+launch['cold'])
        inherited=apply((kernels[chosen,'heavy']+kernels[chosen,'cold'])*.5,launch['heavy']-launch['cold'])
        by_origin={}
        for col0,name in enumerate(('energy','current')):
            vec={m:launch[m].copy() for m in MODELS}
            for arr in vec.values():
                if col0==0:
                    arr[:,1:]=0
                else:
                    arr[:,0]=0
            by_origin[name]=apply(kernels[chosen,'heavy'],vec['heavy'])-apply(kernels[chosen,'cold'],vec['cold'])
        np.testing.assert_allclose(rms(contrast-inherited-model_difference)/start,0,rtol=0,atol=1e-12)
        np.testing.assert_allclose(rms(contrast-by_origin['energy']-by_origin['current'])/start,0,rtol=0,atol=1e-12)
        assert np.array_equal(contrast[0],initial['heavy']-initial['cold'])
        components=np.sqrt(energy(contrast))
        vector=rms(contrast)
        seen=rms(contrast,surface(None))
        alt=rms(contrast,surface(1500,'heavy'))
        area=np.sum(abs(curve(contrast)(window[0]))**2,axis=2)*window[1][:,None]
        cumulative=cumulative_trapezoid(area,x=window[0],axis=0,initial=0)
        for col,wave in enumerate(waves):
            eligible=[r for r in checks if r['k']==wave and r['baryon_launch']==role and r['gate']]
            details.append(dict(k=wave,mode=str(prior.PROBES[col]),baryon_launch=role,input_norm=start[col],window_RMS_over_input=vector[col]/start[col],at_peak_over_input=norm(curve(contrast)(peak))[col]/start[col],energy_RMS_over_input=components[col,0]/start[col],current_RMS_over_input=components[col,1]/start[col],late_current_power_share=components[col,1]**2/vector[col]**2,from_initial_energy_RMS_over_input=rms(by_origin['energy'])[col]/start[col],from_initial_current_RMS_over_input=rms(by_origin['current'])[col]/start[col],inherited_RMS_over_input=rms(inherited)[col]/start[col],medium_difference_RMS_over_input=rms(model_difference)[col]/start[col],include_early_visibility_tail_over_input=seen[col]/start[col],weight_choice_fraction=abs(alt[col]/vector[col]-1),window_signal_median_z=1/np.interp(cumulative[-1,col]/2,cumulative[:,col],window[0])-1,max_window_error=max(r['window_change'] for r in eligible),max_peak_error=max(r['peak_change'] for r in eligible),window_resolved=all(r['window_change']<=prior.TOL for r in eligible),peak_resolved=all(r['peak_change']<=prior.TOL for r in eligible)))
        for tag,at in [('launch',axis[0]),('z3000',1/3001),('z2000',1/2001),('z1500',1/1501),('visibility peak',peak),('z900',1/901),('z750',axis[-1])]:
            for label,arr in targets.items():
                for col,(den,flux) in enumerate(curve(arr)(at)):
                    markers.append(dict(baryon_launch=role,readout=tag,z=1/at-1,k=waves[col],model=label,energy_re=den.real,energy_im=den.imag,current_re=flux.real,current_im=flux.imag))
        archive(f'resolved-{role.split()[0]}.npz',scale=axis,k=waves,baseline=targets['cold'],mts=targets['heavy'],signed_contrast=contrast,from_energy=by_origin['energy'],from_current=by_origin['current'],from_initial_difference=inherited,from_medium_difference=model_difference)
    table('resolved-survival.csv',details)
    table('resolved-convergence.csv',checks)
    table('resolved-markers.csv',markers)
    print([(r['k'],r['window_RMS_over_input'],r['max_window_error'],r['max_peak_error'],r['peak_resolved']) for r in details[:5]],flush=True)

if __name__=='__main__':
    main()
