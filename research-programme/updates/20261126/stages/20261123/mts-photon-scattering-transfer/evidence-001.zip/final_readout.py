from background import ROOT, MODELS, prior, np, CubicSpline, guard, table, record, archive
from scipy.integrate import simpson
import json

TESTS={'primary':'L192-N16384-b1','time':'L192-N8192-b1','angle':'L128-N16384-b1','medium':'L192-N16384-b2'}
SAMPLE=4096

def main():
    guard()
    states={}; medium={}; kernels={};inputs={}
    for model in MODELS:
        path=ROOT/f'medium-{model}.npz'
        with np.load(path) as bank:
            medium[model]={k:bank[k] for k in ('scale','eta','visibility','opacity','modes')}
            states[model]=bank['launch'].T
        for tag,run in TESTS.items():
            path=ROOT/f'kernels-{model}-{run}-o{SAMPLE}.npz'
            inputs[path.name]=prior.digest(path)
            with np.load(path) as bank:
                assert np.array_equal(bank['scale'],medium[model]['scale'])
                kernels[tag,model]=bank['K']
        with np.load(ROOT/f'kernels-{model}-L192-N16384-b1.npz') as sparse:
            assert np.array_equal(sparse['K'],kernels['primary',model][::4])
    book=json.loads((ROOT/'score.json').read_bytes())['visibility']
    axis=medium['cold']['scale']
    assert np.array_equal(axis,medium['heavy']['scale'])
    peak=book['cold']['peak_scale'];waves=medium['cold']['modes']
    window=np.linspace(1/1501,axis[-1],8193)
    full=np.linspace(axis[0],axis[-1],16385)
    def spline(values,step=1):
        return CubicSpline(axis[::step],values[::step],axis=0,extrapolate=False)
    def quadrature(model,nodes,reconstruct):
        data=medium[model];clock=spline(data['eta'])
        tangent=clock(nodes,1)
        if reconstruct:
            optical=spline(data['opacity']*clock(axis,1)).antiderivative()
            tau=optical(axis[-1])-optical(nodes)-np.log(data['visibility'][-1]/data['opacity'][-1])
            assert np.all(np.diff(tau)<0)
            weight=spline(data['opacity'])(nodes)*np.exp(-tau)*tangent
        else:
            weight=spline(data['visibility'])(nodes)*tangent
        assert np.min(weight)>=0
        mass=simpson(weight,x=nodes)
        return weight/mass,mass
    weight,area=quadrature('cold',window,False)
    corrected,physical_area=quadrature('cold',window,True)
    early_weight,_=quadrature('cold',full,True)
    alt,_=quadrature('heavy',window,False)
    def component(values,nodes=window,w=weight):
        return np.sqrt(simpson(abs(values)**2*w[:,None,None],x=nodes,axis=0))
    def norm(values):
        return np.linalg.norm(values,axis=-1)
    def cast(mapping,vec):
        return np.einsum('tmij,mj->tmi',mapping,vec)
    metrics=[];checks=[];rows=[]
    for control in (False,True):
        role='comoving' if control else 'photon-only'
        initial={m:np.column_stack((states[m],states[m][:,1]*int(control))) for m in MODELS}
        runs={}
        for tag in TESTS:
            vals={m:cast(kernels[tag,m],initial[m]) for m in MODELS}
            vals['contrast']=vals['heavy']-vals['cold']
            runs[tag]=vals
        final=runs['primary'];gap=final['contrast'];start=norm(gap[0])
        assert np.array_equal(gap[0],states['heavy']-states['cold'])
        for obj in ('cold','heavy','contrast'):
            stand=spline(final[obj]);sw=stand(window);sp=stand(peak)
            for tag in ('time','angle','medium','output'):
                check=spline(final[obj],2) if tag=='output' else spline(runs[tag][obj])
                pert=check(window)-sw
                ewin=norm(component(pert))/norm(component(sw))
                epoint=norm(check(peak)-sp)/norm(sp)
                for col,wave in enumerate(waves):
                    checks.append(dict(launch=role,quantity=obj,k=wave,test=tag,relative_window_error=ewin[col],relative_peak_error=epoint[col],window_pass=bool(ewin[col]<=prior.TOL),peak_pass=bool(epoint[col]<=prior.TOL)))
        base=kernels['primary','cold']; mts=kernels['primary','heavy']
        inherited=cast(.5*(mts+base),initial['heavy']-initial['cold'])
        change=cast(.5*(mts-base),initial['heavy']+initial['cold'])
        from_energy=cast(mts[:,:,:,:1],initial['heavy'][:,:1])-cast(base[:,:,:,:1],initial['cold'][:,:1])
        from_current=cast(mts[:,:,:,1:],initial['heavy'][:,1:])-cast(base[:,:,:,1:],initial['cold'][:,1:])
        for residual in (gap-inherited-change,gap-from_energy-from_current):
            assert np.max(abs(residual)/abs(gap).max(axis=0))<1e-10
        gap_s=spline(gap);read=gap_s(window);comp=component(read)
        total=norm(comp)
        for col,wave in enumerate(waves):
            selected=[entry for entry in checks if entry['k']==wave and entry['launch']==role]
            metrics.append(dict(mode=str(prior.PROBES[col]),k=wave,baryon_tag=role,launch_norm=start[col],rms_fraction=total[col]/start[col],peak_fraction=norm(gap_s(peak))[col]/start[col],energy_rms_fraction=comp[col,0]/start[col],current_rms_fraction=comp[col,1]/start[col],from_initial_energy_rms_fraction=norm(component(spline(from_energy)(window)))[col]/start[col],from_initial_current_rms_fraction=norm(component(spline(from_current)(window)))[col]/start[col],initial_difference_rms_fraction=norm(component(spline(inherited)(window)))[col]/start[col],medium_difference_rms_fraction=norm(component(spline(change)(window)))[col]/start[col],visibility_floor_removed_full_window_fraction=norm(component(gap_s(full),full,early_weight))[col]/start[col],window_visibility_reconstruction_change=abs(norm(component(read,window,corrected))[col]/total[col]-1),heavy_visibility_weight_change=abs(norm(component(read,window,alt))[col]/total[col]-1),max_window_error=max(e['relative_window_error'] for e in selected),max_peak_error=max(e['relative_peak_error'] for e in selected),window_pass=all(e['window_pass'] for e in selected),peak_pass=all(e['peak_pass'] for e in selected)))
        archive(f'final-{role}.npz',k=waves,scale=axis,cold=final['cold'],mts=final['heavy'],contrast=gap,inherited=inherited,different_medium=change,from_energy=from_energy,from_current=from_current)
        for tag,sample in [('launch',axis[0]),('z3000',1/3001),('z2000',1/2001),('z1500',1/1501),('peak',peak),('z900',1/901),('z750',axis[-1])]:
            for name,array in final.items():
                for col,(energy,current) in enumerate(spline(array)(sample)):
                    rows.append(dict(baryon_tag=role,epoch=tag,z=1/sample-1,k=waves[col],model=name,energy_re=energy.real,energy_im=energy.imag,current_re=current.real,current_im=current.imag))
    table('final-survival.csv',metrics);table('final-checks.csv',checks);table('final-markers.csv',rows)
    assert max(row['window_visibility_reconstruction_change'] for row in metrics)<prior.TOL
    record('final-verification.json',dict(native_visibility_area=area,reconstructed_visibility_area=physical_area,threshold=prior.TOL,peak_redshifts={m:book[m]['peak_z'] for m in MODELS},number=len(checks),window_passes=sum(row['window_pass'] for row in checks),peak_passes=sum(row['peak_pass'] for row in checks),source=prior.digest(ROOT/'input-receipt.json'),transfers=inputs,tests=TESTS))
    print([(row['k'],row['rms_fraction'],row['peak_fraction'],row['max_window_error'],row['max_peak_error'],row['window_pass'],row['peak_pass']) for row in metrics[:5]],flush=True)

if __name__=='__main__':
    main()
