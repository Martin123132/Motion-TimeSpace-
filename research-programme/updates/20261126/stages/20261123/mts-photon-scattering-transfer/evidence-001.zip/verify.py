from pathlib import Path
import csv
import hashlib
import json
import sys
from background import ROOT, MODELS, prior, guard, np, record

def main():
    guard()
    sealed=ROOT/'seal.json'
    if sys.argv[1:]==['--seal'] and not sealed.exists():
        manifest={path.name:prior.digest(path) for path in sorted(ROOT.iterdir()) if path.is_file() and path.name!='seal.json'}
    else:
        assert sys.argv[1:] in ([],['--seal'])
        manifest=json.loads(sealed.read_bytes())['files']
        assert all(prior.digest(ROOT/name)==digest for name,digest in manifest.items())
    check=json.loads((ROOT/'final-verification.json').read_bytes())
    assert check['threshold']==prior.TOL and check['number']==check['window_passes']==check['peak_passes']==120
    for filename,digest in check['transfers'].items():
        assert prior.digest(ROOT/filename)==digest
    with (ROOT/'final-checks.csv').open() as stream:
        comparisons=list(csv.DictReader(stream))
    with (ROOT/'final-survival.csv').open() as stream:
        summary=list(csv.DictReader(stream))
    assert len(comparisons)==120 and len(summary)==10
    assert len({(r['k'],r['quantity'],r['launch'],r['test']) for r in comparisons})==120
    assert all(max(float(r[key]) for key in ('relative_window_error','relative_peak_error'))<=prior.TOL for r in comparisons)
    for launch in ('photon-only','comoving'):
        with np.load(ROOT/f'final-{launch}.npz') as product:
            assert np.array_equal(product['mts']-product['cold'],product['contrast'])
            assert product['contrast'].shape==(4097,5,2)
            assert np.isfinite(product['contrast']).all()
            for model,name in [('cold','cold'),('heavy','mts')]:
                with np.load(ROOT/f'medium-{model}.npz') as data:
                    assert np.array_equal(product[name][0],data['launch'].T)
            for col,wave in enumerate(product['k']):
                rows=[r for r in summary if r['baryon_tag']==launch and float(r['k'])==wave]
                assert len(rows)==1
                row=rows[0]
                direct=np.linalg.norm(product['contrast'][0,col])
                assert abs(direct/float(row['launch_norm'])-1)<1e-12
                pair=np.hypot(float(row['energy_rms_fraction']),float(row['current_rms_fraction']))
                assert abs(pair/float(row['rms_fraction'])-1)<1e-12
    guard()
    if not sealed.exists():
        record('seal.json',dict(files=manifest))
    print('VERIFIED',len(manifest),'sealed files; 120 window plus 120 peak checks; no workers launched.')

if __name__=='__main__':
    main()
