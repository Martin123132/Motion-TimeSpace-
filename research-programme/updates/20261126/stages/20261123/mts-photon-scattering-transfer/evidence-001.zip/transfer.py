import argparse
from background import ROOT, MODELS, np, CubicSpline, prior, guard, archive
from scipy.linalg import solve_banded
from incident_tail import up
import json

def operators(order):
    size = 3 + 2 * (order - 1)
    stream, drag, recoil, hubble = np.zeros((4,size,size))
    stream[0,2] = -1
    stream[2,0], stream[2,3] = 1/3, -2/3
    drag[2,1], drag[2,2] = 1, -1
    recoil[1,1], recoil[1,2] = -1, 1
    hubble[1,1] = -1
    for degree in range(2, order + 1):
        for spin in (0,2):
            row = 3 + 2*(degree-2) + spin//2
            if degree>2 or spin==0:
                stream[row, row-2 if degree>2 else 2] = degree/(2*degree+1)
            if degree<order:
                stream[row,row+2] = -up(degree,spin)
            drag[row,row] = -1
            if degree==2:
                drag[row,3] += .1
                drag[row,4] += .6
    return np.stack((stream,drag,recoil,hubble))

def stages(order):
    mats = operators(order)
    size = mats.shape[-1]
    radau = np.array([[5/12,-1/12],[3/4,1/4]])
    bands = np.zeros((2,4,11,size*2))
    for role,mat in enumerate(mats):
        for row,col in zip(*np.nonzero(mat)):
            for out_stage in range(2):
                for in_stage in range(2):
                    source = 2*col+in_stage
                    bands[in_stage,role,5+2*row+out_stage-source,source] -= radau[out_stage,in_stage]*mat[row,col]
    return bands

def propagate(order, count, rates, modes, count_out=1024):
    bands = stages(order)
    size = bands.shape[-1]//2
    assert count % count_out == 0
    output = np.zeros((count_out+1,len(modes),2,3))
    for probe,mode in enumerate(modes):
        state = np.eye(size,3)[:,[0,2,1]].copy()
        output[0,probe] = state[[0,2]]
        packed = np.empty((size*2,3),order='F')
        for start in range(0,count,64):
            if start%1024==0:
                guard()
            end = min(start+64,count)
            multipliers = rates[start:end].copy()
            multipliers[:,:,0] *= mode
            matrices = (multipliers.reshape(-1,8) @ bands.reshape(8,-1)).reshape(-1,11,size*2)
            matrices[:,5,:] += 1
            for step,matrix in enumerate(matrices,start+1):
                packed[::2] = state
                packed[1::2] = state
                updated = solve_banded((5,5),matrix,packed,overwrite_b=False,check_finite=False)
                state = updated[1::2]
                if step % (count//count_out)==0:
                    output[step//(count//count_out),probe] = state[[0,2]]
    assert np.isfinite(output).all()
    return output

def physics(scale, eta, hub, loading, opacity, count):
    count_axis = np.arange(count)[:,None]+np.array([1/3,1])
    step = (scale[-1]-scale[0])/count
    sample = scale[0]+count_axis*step
    sample[-1,-1]=scale[-1]
    spline = CubicSpline(scale,np.column_stack((hub,loading,opacity)),extrapolate=False)
    expansion, inertia, collision = spline(sample).transpose(2,0,1)
    clock = CubicSpline(scale,eta,extrapolate=False)(sample,1)*step
    assert np.min(clock)>0 and np.min(inertia)>0 and np.min(collision)>0
    return np.stack((clock,clock*collision,clock*collision/inertia,clock*expansion),axis=-1)

def controls():
    order = 16
    stream,collision,recoil,_ = operators(order)
    inertia = .37
    row = np.zeros(len(stream))
    row[[1,2]] = [inertia,1]
    assert np.max(abs(row@(collision+recoil/inertia)))<1e-14
    assert np.max(abs((collision+recoil/inertia)[0]))==0
    common = np.zeros(len(stream)); common[[1,2]]=1
    assert np.max(abs((collision+recoil/inertia)@common))==0
    count=1024
    rates=np.zeros((count,2,4));rates[:,:,0]=1/count
    free=propagate(order,count,rates,[1.0])[-1,0,:,0]
    from scipy.special import spherical_jn
    assert np.max(abs(free-[spherical_jn(0,1),spherical_jn(1,1)]))<1e-8
    rates[:]=0;rates[:,:,1]=4/count;rates[:,:,2]=4/(inertia*count)
    damp=propagate(order,count,rates,[0.0])[-1,0]
    want=(1+inertia*np.exp(-4*(1+1/inertia)))/(1+inertia)
    assert abs(damp[1,1]-want)<1e-10 and abs(damp[1,2]-(1-want))<1e-10
    assert np.max(abs(damp[0]-[1,0,0]))<1e-12

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('order',type=int)
    parser.add_argument('steps',type=int)
    parser.add_argument('--stride',type=int,default=1)
    parser.add_argument('--output',type=int,choices=(1024,4096),default=1024)
    args=parser.parse_args()
    guard()
    controls()
    book=json.loads((ROOT/'input-receipt.json').read_bytes())
    for model in MODELS:
        path=ROOT/f'medium-{model}.npz'
        assert prior.digest(path)==book['media'][model]
        with np.load(path) as data:
            keynames=['scale','eta','hub','loading','opacity']
            rates=physics(*(data[key][::args.stride] for key in keynames),args.steps)
            values=propagate(args.order,args.steps,rates,data['modes'],args.output)
            suffix='' if args.output==1024 else f'-o{args.output}'
            archive(f'kernels-{model}-L{args.order}-N{args.steps}-b{args.stride}{suffix}.npz',K=values,scale=data['scale'][::4096//args.output])
        print(model,args.order,args.steps,args.stride,'done',flush=True)

if __name__=='__main__':
    main()
