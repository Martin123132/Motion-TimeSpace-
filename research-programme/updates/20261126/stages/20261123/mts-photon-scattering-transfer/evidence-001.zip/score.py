from background import ROOT, MODELS, np, prior, CubicSpline, guard, table, record, archive
from scipy.integrate import simpson
from scipy.optimize import minimize_scalar
import json

TAGS = ('L32-N4096-b1','L32-N8192-b1','L64-N8192-b1','L64-N16384-b1','L64-N8192-b2')
MAIN = TAGS[3]

def norm(values):
    return np.linalg.norm(values,axis=-1)

def main():
    guard()
    media = {}
    launch = {}
    waves = None
    primary_surface = {}
    for model in MODELS:
        with np.load(ROOT/f'medium-{model}.npz') as data:
            media[model]={k:data[k] for k in ('scale','eta','visibility','opacity')}
            launch[model]=data['launch'].T
            if waves is not None:
                assert np.array_equal(waves,data['modes'])
            waves=data['modes']
        med=media[model]; scale=med['scale']
        time=CubicSpline(scale,med['eta'])
        visibility=CubicSpline(scale,med['visibility'])
        low=1/1501
        peak=minimize_scalar(lambda x:-visibility(x),bounds=(1/1300,1/900),method='bounded',options={'xatol':1e-15}).x
        mass=simpson(med['visibility'],x=med['eta'])
        assert low<peak<scale[-1] and .8<mass<=1.001
        primary_surface[model]=dict(peak_scale=peak,peak_z=1/peak-1,peak_eta=float(time(peak)),available_visibility_mass=mass,launch_to_peak_optical_depth=float(CubicSpline(scale,med['opacity']*time(scale,1)).integrate(scale[0],peak)))
    assert np.array_equal(media['cold']['scale'],media['heavy']['scale'])
    scale=media['cold']['scale'][::4]
    peak=primary_surface['cold']['peak_scale']
    dense=np.linspace(low,scale[-1],4097)
    def curve(values):
        return CubicSpline(scale,values,axis=0,extrapolate=False)
    def weights(model):
        med=media[model]
        return CubicSpline(med['scale'],med['visibility'])(dense)*CubicSpline(med['scale'],med['eta'])(dense,1)
    weight=weights('cold')
    assert weight.min()>=0
    area=simpson(weight,x=dense)
    for model in MODELS:
        primary_surface[model]['window_visibility_mass']=simpson(weights(model),x=dense)
    def mean_square(values,weighting=weight):
        sampled=curve(values)(dense)
        return simpson(np.abs(sampled)**2 * weighting[:,None,None],x=dense,axis=0)/simpson(weighting,x=dense)
    def rms(values):
        return np.sqrt(mean_square(values).sum(axis=-1))
    kernels={}
    for tag in TAGS:
        kernels[tag]={}
        for model in MODELS:
            with np.load(ROOT/f'kernels-{model}-{tag}.npz') as data:
                assert np.array_equal(data['scale'],scale)
                kernels[tag][model]=data['K']
    def apply(matrix,vector):
        return np.einsum('tmij,mj->tmi',matrix,vector)
    def run(tag,locked=False):
        vectors={m:np.column_stack((launch[m],launch[m][:,1] if locked else np.zeros(len(waves)))) for m in MODELS}
        vals={m:apply(kernels[tag][m],vectors[m]) for m in MODELS}
        gap=vals['heavy']-vals['cold']
        inherited=apply((kernels[tag]['heavy']+kernels[tag]['cold'])/2,vectors['heavy']-vectors['cold'])
        medium=apply(kernels[tag]['heavy']-kernels[tag]['cold'],(vectors['heavy']+vectors['cold'])/2)
        assert np.max(abs(gap-inherited-medium)/abs(gap).max(axis=0))<1e-10
        assert np.array_equal(gap[0],launch['heavy']-launch['cold'])
        return vals,gap,inherited,medium
    vals,gap,inherited,change=run(MAIN)
    checks=[]
    refinements=[('L32-N4096-b1','L32-N8192-b1','time coarse'),('L32-N8192-b1','L64-N8192-b1','angular'),('L64-N8192-b1',MAIN,'time fine'),('L64-N8192-b2','L64-N8192-b1','medium grid')]
    for before,after,label in refinements:
        for locked in (False,True):
            first,g0,*_=run(before,locked)
            second,g1,*_=run(after,locked)
            for name,old,new in [(m,first[m],second[m]) for m in MODELS]+[('heavy-cold',g0,g1)]:
                difference=old-new
                over_peak=abs(difference).max(axis=0)/abs(new).max(axis=0)
                weighted=rms(difference)/rms(new)
                point=norm(curve(difference)(peak))/norm(curve(new)(peak))
                for col,wave in enumerate(waves):
                    checks.append(dict(refinement=label,baryon_launch='comoving' if locked else 'zero tag',quantity=name,k=wave,energy_peak_error=over_peak[col,0],current_peak_error=over_peak[col,1],visibility_vector_error=weighted[col],at_visibility_peak_error=point[col],trajectory_pass=bool(over_peak[col].max()<=prior.TOL),window_pass=bool(weighted[col]<=prior.TOL),peak_pass=bool(point[col]<=prior.TOL)))
    table('convergence.csv',checks)
    summaries=[]
    markers=[]
    for locked in (False,True):
        vals,gap,inherited,change=run(MAIN,locked)
        start=norm(gap[0])
        power=mean_square(gap)
        denom=np.sqrt(power.sum(axis=-1))
        avg=np.sqrt(mean_square(gap,weights('heavy')).sum(axis=-1))
        archive('matched-'+('comoving' if locked else 'tagged')+'.npz',scale=scale,k=waves,baseline=vals['cold'],mts=vals['heavy'],contrast=gap,inherited=inherited,medium_change=change)
        for col,wave in enumerate(waves):
            role='comoving' if locked else 'zero tag'
            filtered=[r for r in checks if r['k']==wave and r['quantity']=='heavy-cold' and r['baryon_launch']==role]
            summaries.append(dict(k=wave,mode=str(prior.PROBES[col]),baryon_launch=role,launch_contrast_norm=start[col],window_rms_over_launch=denom[col]/start[col],peak_norm_over_launch=norm(curve(gap)(peak))[col]/start[col],window_energy_over_launch=np.sqrt(power[col,0])/start[col],window_current_over_launch=np.sqrt(power[col,1])/start[col],initial_current_squared_share=abs(gap[0,col,1]/start[col])**2,window_current_squared_share=power[col,1]/power[col].sum(),inherited_rms_over_launch=rms(inherited)[col]/start[col],different_medium_rms_over_launch=rms(change)[col]/start[col],weight_choice_relative=abs(avg[col]/denom[col]-1),all_window_checks=all(r['window_pass'] for r in filtered),all_peak_checks=all(r['peak_pass'] for r in filtered)))
        for tag,sample in [('launch',scale[0]),('z3000',1/3001),('z2000',1/2001),('z1500',low),('common visibility peak',peak),('z900',1/901),('z750',scale[-1])]:
            for name,history in list(vals.items())+[('heavy-cold',gap)]:
                result=curve(history)(sample)
                for col,wave in enumerate(waves):
                    energy,current=result[col]
                    markers.append(dict(marker=tag,z=1/sample-1,k=wave,baryon_launch=role,quantity=name,energy_re=energy.real,energy_im=energy.imag,current_re=current.real,current_im=current.imag))
    table('survival.csv',summaries)
    table('complex-markers.csv',markers)
    record('score.json',dict(tolerance=prior.TOL,visibility=primary_surface,weighting='cold g d eta normalized across 750<=z<=1500, common scale',all_checks={key:sum(row[key] for row in checks) for key in ('trajectory_pass','window_pass','peak_pass')},comparisons=len(checks),observational=False))
    for row in summaries:
        print(row['baryon_launch'],row['k'],'RMS',row['window_rms_over_launch'],'peak',row['peak_norm_over_launch'],row['all_window_checks'],row['all_peak_checks'])
    print(primary_surface)

if __name__=='__main__':
    main()
