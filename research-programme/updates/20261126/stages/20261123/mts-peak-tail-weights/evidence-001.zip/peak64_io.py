import csv
import hashlib
import io
import json
import sys
from pathlib import Path

HERE=Path(__file__).resolve().parent
PREVIOUS=HERE.parent/'mts-signed-photon-peak-six-20261123'
SEAL='9262f9ad88c48fcbc24037f541389aa154be01cf52aad653e6da8c3a90c4819e'

def digest(path):
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()

assert digest(PREVIOUS/'seal.json')==SEAL
pinned=json.loads((PREVIOUS/'seal.json').read_bytes())['files']
def prior(name):
    path=PREVIOUS/name
    assert digest(path)==pinned[name],name
    return path

prior('project.py');prior('peak_inputs.py')
sys.path.insert(0,str(PREVIOUS))
import project as proj
from peak_inputs import np, transfer, CubicSpline, TOL, MODELS, pin, PARENT
from scipy.optimize import brentq

def guard():
    proj.guard();assert not (HERE/'STOP-REQUESTED').exists()

def store(name,data):
    guard();path=HERE/name
    if path.exists():assert path.read_bytes()==data,name
    else:
        with path.open('xb') as stream:stream.write(data)

def save_arrays(name,**arrays):
    stream=io.BytesIO();np.savez_compressed(stream,**arrays);store(name,stream.getvalue())

def save_json(name,data):store(name,(json.dumps(data,indent=2,sort_keys=True,allow_nan=False)+'\n').encode())

def table(name,rows):
    stream=io.StringIO();writer=csv.DictWriter(stream,rows[0],lineterminator='\n')
    writer.writeheader();writer.writerows(rows);store(name,stream.getvalue().encode())

def read_csv(path):
    with path.open() as stream:return list(csv.DictReader(stream))

def budget():
    peak=next(row for row in read_csv(pin(PARENT,'tail-source-budgets.csv')) if row['measure']=='peak')
    amount=float(peak['absolute_point_five_percent_budget'])
    assert amount==TOL*float(peak['retained_contrast_norm'])
    return amount

def setup():
    media={};clocks={};cuts={}
    for model in MODELS:
        receipt=json.loads(prior(f'projection-inputs-{model}.json').read_bytes())
        assert Path(transfer.__file__).resolve()==Path(receipt['operator_path']).resolve() and digest(Path(transfer.__file__))==receipt['operator_sha256']
        media[model]=proj.measure(model)
        grid,eta,_,peak,_=media[model];clock=CubicSpline(grid,eta,extrapolate=False)
        cuts[model]=brentq(lambda scale:clock(scale)-64.,grid[0],grid[-1],xtol=1e-20);clocks[model]=clock
    assert np.array_equal(media['cold'][0],grid) and media['cold'][3]==peak and cuts['heavy']<cuts['cold']
    return grid,media,clocks,cuts

def test_field(times):
    return np.stack([(.8+.2j)*np.cos(.031*(times-64.))+.2j*np.sin(.11*times),(.4-.8j)*np.sin(.024*(times-64.)+.2)-.35*np.cos(.15*times)],axis=-1)
