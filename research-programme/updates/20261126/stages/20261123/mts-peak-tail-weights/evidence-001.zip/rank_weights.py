from peak64_io import *

TERMS=('paired','medium','clock','single')
CHANNELS={'photon':('energy rate','acceleration potential'),'matter':('effective current','lapse including shear')}

def mag(values):return np.hypot(values[...,0],values[...,1])

def labels(scale,grid,clocks,cuts,peak):
    stamp=clocks['cold'](grid);peak_eta=clocks['cold'](peak);pos=np.searchsorted(grid,peak)
    edges=[(min(cuts.values()),'switch'),(max(cuts.values()),'paired')]
    for target in np.arange(76.8,peak_eta,12.8):
        index=np.argmin(abs(stamp-target));value=grid[index]
        if value<grid[pos-1] and value>edges[-1][0]:edges.append((value,'paired'))
    if grid[pos]!=peak:edges.append((grid[pos-1],'peak interpolation cell'))
    edges.append((grid[pos],'after peak node' if grid[pos]==peak else 'after peak cell'));edges.append((grid[-1],'end'))
    boundaries=np.array([item[0] for item in edges])
    assert (np.diff(boundaries)>0).all() and np.array_equal(scale[np.searchsorted(scale,boundaries)],boundaries)
    ids=np.searchsorted(boundaries,scale[:-1],side='right')-1
    assert set(ids)==set(range(len(edges)-1))
    return edges,ids

def by_window(tag,grid,media,clocks,cuts):
    with np.load(HERE/f'response-{tag}.npz') as saved:
        data={key:saved[key] for key in saved.files}
    scale=data['scale'];edges,ids=labels(scale,grid,clocks,cuts,media['cold'][3])
    cold_axis=data['cold_axis'];paired=data['cold_active']&data['heavy_active'];single=data['heavy_active']&~data['cold_active']
    assert np.all(paired|single) and np.any(single)
    result=[];deltas=[];quantiles=[];total={}
    for basis,channels in CHANNELS.items():
        arrays={model:data[model+'_kernel'].copy() for model in MODELS}
        if basis=='matter':
            for model in MODELS:
                arrays[model][:,1]-=data[model+'_hub'][...,None]*arrays[model][:,0]
        heavy,cold=arrays['heavy'],arrays['cold']
        for ci,channel in enumerate(channels):
            hk,ck=heavy[:,ci],cold[:,ci]
            gn=mag(hk);cn=mag(ck)
            values=dict(paired=gn*paired[:,None],medium=mag(hk-ck)*paired[:,None],clock=gn*data['clock_offset']*paired[:,None],single=gn*single[:,None])
            weights=values['paired'].sum(axis=1);acc=np.cumsum(weights)
            assert acc[-1]>0
            for frac in (.1,.25,.5,.75,.9):
                ix=np.searchsorted(acc,frac*acc[-1])
                quantiles.append(dict(setting=tag,basis=basis,channel=channel,fraction=frac,eta_low=cold_axis[ix],eta_high=cold_axis[ix+1]))
            for ordinal in range(-1,len(edges)-1):
                mask=np.ones_like(ids,dtype=bool) if ordinal==-1 else ids==ordinal
                gains={key:float(val[mask].sum()) for key,val in values.items()}
                coverage=gains['paired']/float(acc[-1])
                indices=np.flatnonzero(mask);begin=cold_axis[indices[0]];end=cold_axis[indices[-1]+1]
                row=dict(setting=tag,basis=basis,channel=channel,window=ordinal,kind='whole' if ordinal==-1 else edges[ordinal][1],eta_from=begin,eta_to=end,redshift_from=1/scale[indices[0]]-1,redshift_to=1/scale[indices[-1]+1]-1,paired_share=coverage,paired_per_mpc=gains['paired']/(end-begin),baseline_gain=float(cn[mask].sum()),mts_gain=float(gn[mask].sum()),**gains)
                result.append(row)
                if ordinal==-1:total[basis,channel]=row
        if basis=='matter':
            for model in MODELS:
                at=data[model+'_at'];physical=test_field(at)
                if model=='heavy':physical*=np.array([.91+.06j,1.04-.03j])
                matter=physical.copy();matter[...,0]+=data[model+'_hub']*physical[...,1]
                raw_value=np.einsum('nctj,ntc->j',data[model+'_kernel'],physical)
                projected=np.einsum('nctj,ntc->j',arrays[model],matter)
                deltas.append(dict(setting=tag,model=model,relative_error=float(np.linalg.norm(projected-raw_value)/np.linalg.norm(raw_value))))
    return result,quantiles,deltas,total

def main():
    guard();grid,media,clocks,cuts=setup();allowance=budget();allrows=[];qrows=[];basis_checks=[];caprows=[];checks=[]
    for tag in ('primary','time','angle'):
        rows,quantiles,deltas,total=by_window(tag,grid,media,clocks,cuts);allrows.extend(rows);qrows.extend(quantiles);basis_checks.extend(deltas)
    keyed={(r['setting'],r['basis'],r['channel'],r['window']):r for r in allrows}
    for row in allrows:
        if row['setting']=='primary':continue
        base=keyed['primary',row['basis'],row['channel'],row['window']]
        whole=keyed['primary',row['basis'],row['channel'],-1]
        for term in ('paired','medium','single','clock'):
            diff=abs(row[term]-base[term]);in_whole=diff/whole[term]
            own=diff/base[term] if base[term]>0 else None
            checks.append(dict(setting=row['setting'],basis=row['basis'],channel=row['channel'],window=row['window'],term=term,own_relative_change=own,change_over_whole_gain=in_whole,passed_own='' if own is None else bool(own<=TOL),passed_whole_scale=in_whole<=TOL))
    for basis,channels in CHANNELS.items():
        for channel in channels:
            for term in TERMS:
                gain=max(keyed[tag,basis,channel,-1][term] for tag in ('primary','angle','time'))
                caprows.append(dict(basis=basis,channel=channel,term=term,max_tested_total_gain=gain,one_term_cap=allowance/gain,one_eighth_budget_cap=allowance/(8*gain)))
    table('per-window-gains.csv',allrows);table('cumulative-sensitivity.csv',qrows);table('uniform-matter-and-source-caps.csv',caprows)
    table('gain-resolution.csv',checks);table('matter-basis-controls.csv',basis_checks)
    assert max(row['relative_error'] for row in basis_checks)<1e-11
    old=read_csv(prior('channel-sensitivity.csv'));failed=[r for r in old if r['passed']=='False'];assert len(failed)==1
    info=dict(absolute_peak_budget=allowance,tolerance=TOL,retained_exception=failed[0],cut_scales=cuts,peak_scale=media['cold'][3],peak_eta={m:float(clocks[m](media[m][3])) for m in MODELS},new_late_matter_states=0,actual_tail='not measured',late_residual_below_budget='conditional only')
    save_json('status.json',info)
    for row in caprows:
        if row['term'] in ('paired','medium'):print(row,flush=True)
    for basis,channels in CHANNELS.items():
        for channel in channels:
            subset=[r for r in allrows if r['setting']=='primary' and r['basis']==basis and r['channel']==channel and r['window']>=0]
            print(channel,[(round(r['eta_from'],2),round(r['eta_to'],2),round(r['paired_share'],4)) for r in sorted(subset,key=lambda r:-r['paired_share'])[:3]],flush=True)

if __name__=='__main__':main()
