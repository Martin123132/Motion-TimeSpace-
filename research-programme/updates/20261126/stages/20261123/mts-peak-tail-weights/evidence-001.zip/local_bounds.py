from peak64_io import *

def curve_slope(spline):
    widths=np.diff(spline.x)
    cubic,quad,linear=spline.c[:3]
    controls=np.stack([linear,linear+quad*widths,linear+2*quad*widths+3*cubic*widths**2])
    return float(np.max(abs(controls))*(1+1e-12))

def gains(kernel,times,pivot):
    absolute=np.hypot(kernel[...,0],kernel[...,1])
    flat=np.linalg.norm(kernel.sum(axis=(0,1)))
    return float(absolute.sum()),float(flat),float((absolute*abs(times-pivot)).sum())

def last_known():
    tests=[]
    for model in MODELS:
        time,field,_=proj.source(5,model,'primary')
        with np.load(prior(f'primary-kernels-{model}.npz')) as raw:at=raw['eta_5'];kernel=raw['gains_5']
        with np.load(prior(f'projection-{model}.npz')) as raw:orig=raw['primary'][5]
        for index,channel in enumerate(('energy rate','acceleration potential')):
            spline=CubicSpline(time,field[:,index]);samples=spline(at)
            signed=np.einsum('ntd,nt->d',kernel[:,index],samples);ref=orig[index]
            error=np.linalg.norm(signed-ref)/np.linalg.norm(ref)
            pivot=(time[0]+time[-1])/2
            uniform,flat,slope=gains(kernel[:,index],at,pivot);derivative=curve_slope(spline)
            upper=flat*abs(spline(pivot))+slope*derivative
            assert error<TOL and np.linalg.norm(signed)<=upper
            tests.append(dict(model=model,channel=channel,pivot=pivot,source_slope_bound=derivative,modelled_peak_norm=np.linalg.norm(signed),midpoint_bound=upper,reconstruction_error=error))
    table('saved-block-bound-check.csv',tests)

def main():
    from rank_weights import CHANNELS,labels
    guard();grid,media,clocks,cuts=setup();allowance=budget();rows=[];priority=[]
    for tag in ('primary','time','angle'):
        with np.load(HERE/f'response-{tag}.npz') as raw:
            scale=raw['scale'];at=raw['heavy_at'];hub=raw['heavy_hub'];kernel=raw['heavy_kernel'];both=raw['cold_active']&raw['heavy_active'];axis=raw['heavy_axis']
        cutspec,ids=labels(scale,grid,clocks,cuts,media['cold'][3])
        for basis,channels in CHANNELS.items():
            weight=kernel.copy()
            if basis=='matter':weight[:,1]-=hub[...,None]*weight[:,0]
            for wi in np.unique(ids[both]):
                mask=(ids==wi)&both
                points=np.flatnonzero(mask);pivot=(axis[points[0]]+axis[points[-1]+1])/2
                for ci,channel in enumerate(channels):
                    total,dc,slope=gains(weight[mask,ci],at[mask],pivot)
                    rows.append(dict(setting=tag,basis=basis,channel=channel,window=int(wi),pivot_heavy_eta=pivot,paired_gain=total,constant_signed_gain=dc,slope_gain=slope,constant_over_arbitrary=dc/total if total else 0.))
    table('signed-local-matter-targets.csv',rows)
    allrows=read_csv(HERE/'per-window-gains.csv')
    for channel in ('effective current','lapse including shear'):
        subset=[row for row in allrows if row['setting']=='primary' and row['basis']=='matter' and row['channel']==channel and row['kind']=='paired']
        high=sorted(subset,key=lambda row:-float(row['paired']))[:2]
        for row in high:
            wi=int(row['window']);cases=[r for r in rows if r['basis']=='matter' and r['channel']==channel and r['window']==wi]
            flat=max(r['constant_signed_gain'] for r in cases);slope=max(r['slope_gain'] for r in cases);total=max(r['paired_gain'] for r in cases)
            priority.append(dict(channel=channel,window=wi,cold_eta_from=row['eta_from'],cold_eta_to=row['eta_to'],paired_share=row['paired_share'],one_term_uniform_cap=allowance/total,signed_constant_gain=flat,slope_gain=slope,one_term_midpoint_cap_if_flat=allowance/flat,one_term_slope_cap_if_center_zero=allowance/slope))
    table('priority-matter-targets.csv',priority);last_known()

if __name__=='__main__':main()
