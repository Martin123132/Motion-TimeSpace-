from peak64_io import *
from rank_weights import CHANNELS, labels, mag

def main():
    guard();grid,media,clocks,cuts=setup();rows=[];envelopes=[]
    cold,heavy=(clocks[key] for key in MODELS)
    for tag in ('primary','time','angle'):
        with np.load(HERE/f'response-{tag}.npz') as archive:data={key:archive[key] for key in archive.files}
        scale=data['scale'];_,ids=labels(scale,grid,clocks,cuts,media['cold'][3])
        ctime=data['cold_at'];htime=data['heavy_at']
        left=scale[:-1];right=scale[1:];cell=np.searchsorted(grid,(left+right)/2)-1
        guess=left+(right-left)/3
        for count in range(3):
            guess=np.clip(guess-(heavy(guess)-htime[:,0])/heavy(guess,1),left,right)
        matched=np.column_stack([cold(guess),ctime[:,1]])
        clock_defect=data['clock_offset']
        assert np.all(abs(matched-ctime)<=clock_defect)
        width=np.diff(grid)[cell]
        def controls(coeff):
            cubic,quad,linear=coeff[:3,cell]
            rate=np.stack([linear,linear+quad*width,linear+2*quad*width+3*cubic*width**2])
            second=np.stack([2*quad,2*quad+6*cubic*width])
            return rate.min(axis=0),abs(rate).max(axis=0),abs(second).max(axis=0)
        lo,hi,hi2=controls(heavy.c);_,delta,delta2=controls(cold.c-heavy.c)
        duration=heavy(grid[cell+1])-heavy(grid[cell])
        safe=duration**2*(delta2*hi+delta*hi2)/(9*lo**3)+64*np.spacing(np.maximum(heavy(grid[cell+1]),cold(grid[cell+1])))
        assert np.all(safe>=clock_defect[:,0])
        paired=data['cold_active'];single=~paired
        for basis,channels in CHANNELS.items():
            hk=data['heavy_kernel'].copy();ck=data['cold_kernel'].copy()
            if basis=='matter':
                hk[:,1]-=data['heavy_hub'][...,None]*hk[:,0];ck[:,1]-=data['cold_hub'][...,None]*ck[:,0]
            for ci,channel in enumerate(channels):
                h=hk[:,ci];c=ck[:,ci];ng=mag(h)
                envelopes.append(dict(setting=tag,basis=basis,channel=channel,shared_clock_gain=float(np.sum((ng[:,0]*paired)*safe))))
                for name,increment in [('exactly common',0.),('unequal with phase',.022)]:
                    frequency=.17 if ci==0 else .031
                    fc=np.exp(1j*frequency*ctime)
                    at_h=np.exp(1j*frequency*matched)
                    extra=increment*np.exp(-1j*.12*matched)
                    fh=at_h+extra
                    integral=lambda kernel,source:np.einsum('ntj,nt->j',kernel,source)
                    measured=integral(h,fh)-integral(c,fc)
                    overlap=paired[:,None];alone=single[:,None]
                    pieces=[integral(h,extra*overlap),integral(h-c,fc*overlap),integral(h,(at_h-fc)*overlap),integral(h,fh*alone)]
                    allowance=[np.sum(ng*overlap)*increment,np.sum(mag(h-c)*overlap),frequency*np.sum(ng*clock_defect*overlap),(1+increment)*np.sum(ng*alone)]
                    for item,cap in zip(pieces,allowance):assert np.linalg.norm(item)<=cap*(1+1e-8)+1e-25,(name,channel,cap,item)
                    absolute=np.linalg.norm(measured-np.sum(pieces,axis=0));round_scale=np.sum(ng)+mag(c).sum()
                    assert absolute<1e-13*round_scale and np.linalg.norm(measured)<=sum(allowance)*(1+1e-8)
                    rows.append(dict(setting=tag,basis=basis,channel=channel,mock=name,peak_norm=np.linalg.norm(measured),bound=sum(allowance),identity_error_over_unsigned=absolute/round_scale))
    table('paired-envelope-controls.csv',rows);table('common-cell-clock-gain.csv',envelopes)

if __name__=='__main__':main()
