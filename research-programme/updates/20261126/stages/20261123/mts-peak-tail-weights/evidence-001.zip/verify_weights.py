import re
from peak64_io import *

def main():
    guard();summary=json.loads((HERE/'status.json').read_bytes());assert summary['tolerance']==.005 and summary['new_late_matter_states']==0 and summary['absolute_peak_budget']==budget()
    direct=read_csv(HERE/'direct-forward-controls.csv');assert len(direct)==18 and all(row['passed']=='True' and float(row['relative_error'])<=TOL for row in direct)
    pair=read_csv(HERE/'paired-envelope-controls.csv');assert len(pair)==24 and all(float(row['peak_norm'])<=float(row['bound'])*(1+1e-9) for row in pair)
    last=read_csv(HERE/'saved-block-bound-check.csv');assert len(last)==4 and all(float(row['midpoint_bound'])>=float(row['modelled_peak_norm'])>0 and float(row['reconstruction_error'])<=TOL for row in last)
    ranks={};rows=read_csv(HERE/'per-window-gains.csv')
    for tag in ('primary','time','angle'):
        for channel in ('energy rate','acceleration potential','effective current','lapse including shear'):
            items=[r for r in rows if r['setting']==tag and r['channel']==channel];pieces=[r for r in items if int(r['window'])>=0];whole=next(r for r in items if r['window']=='-1')
            for key in ('paired','medium','clock','single','baseline_gain','mts_gain'):
                assert np.isclose(sum(float(r[key]) for r in pieces),float(whole[key]),rtol=1e-11,atol=0)
            for key in ('paired','baseline_gain','mts_gain'):
                top=sorted(pieces,key=lambda r:-float(r[key]))[:2]
                assert [r['window'] for r in top]==['17','16']
            ranks[tag,channel]=float(whole['paired'])
    joint=read_csv(HERE/'uniform-matter-and-source-caps.csv');assert len(joint)==16
    for basis in ('matter','photon'):
        total=sum(float(r['max_tested_total_gain'])*float(r['one_eighth_budget_cap']) for r in joint if r['basis']==basis)
        assert np.isclose(total,budget(),rtol=1e-14,atol=0)
    common=read_csv(HERE/'common-cell-clock-gain.csv')
    for row in common:
        channel=row['channel'];value=float(row['shared_clock_gain'])
        ref=float(next(r for r in common if r['channel']==channel and r['setting']=='primary')['shared_clock_gain'])
        assert abs(value/ref-1)<TOL
    source={}
    for tag in ('primary','time','angle'):source.update(json.loads((HERE/f'inputs-{tag}.json').read_bytes()))
    for model in MODELS:
        source.update(json.loads(prior(f'projection-inputs-{model}.json').read_bytes())['saved'])
        prior(f'primary-kernels-{model}.npz');prior(f'projection-{model}.npz')
    assert all(digest(Path(path))==expected for path,expected in source.items())
    assert not any(path.is_dir() for path in HERE.iterdir())
    for target in re.findall(r'\]\(([^)]+)\)',(HERE/'RESULTS.md').read_text(encoding='utf-8')):assert (HERE/target).is_file(),target
    files={p.name:digest(p) for p in sorted(HERE.iterdir()) if p.name!='seal.json'}
    save_json('seal.json',dict(parent=SEAL,files=files,source_hashes_rechecked=len(source),new_matter_intervals=0,retained_error_gate=TOL))
    print('Verified',len(files),'local files and',len(source),'source hashes. Seal',digest(HERE/'seal.json'))

if __name__=='__main__':main()
