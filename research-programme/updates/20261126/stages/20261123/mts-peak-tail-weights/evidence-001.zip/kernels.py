from peak64_io import *

SETTINGS={'primary':(192,4),'time':(192,2),'angle':(128,4)}

def native(clock,scale,grid,times,cut):
    axis=clock(scale)
    slots=np.searchsorted(scale,grid);inside=(slots<len(scale))
    exact=inside.copy();exact[inside]=scale[slots[inside]]==grid[inside]
    axis[slots[exact]]=times[exact]
    axis[scale==cut]=64.
    assert np.all(np.diff(axis)>0) and np.all(np.isfinite(axis))
    return axis

def late_mesh(grid,clocks,cuts,sub):
    base=np.linspace(grid[0],grid[-1],4096*sub+1);base[::sub]=grid
    return np.unique(np.r_[base[base>=min(cuts.values())],list(cuts.values())])

def node_offset(scale,axes,clocks,grid):
    left,right=scale[:-1],scale[1:]
    cell=np.searchsorted(grid,(left+right)/2)-1
    assert np.all(left>=grid[cell]) and np.all(right<=grid[cell+1])
    def bounds(coeff):
        width=grid[cell+1]-grid[cell]
        a3,a2,a1=coeff[:3,cell]
        rate=np.stack([a1,a1+a2*width,a1+2*a2*width+3*a3*width**2])
        accel=np.stack([2*a2,2*a2+6*a3*width])
        return rate.min(axis=0),abs(rate).max(axis=0),abs(accel).max(axis=0)
    heavy=clocks['heavy'];cold=clocks['cold']
    min_rate,high_rate,high_acc=bounds(heavy.c)
    _,delta_rate,delta_acc=bounds(cold.c-heavy.c)
    assert np.min(min_rate)>0
    second=(delta_acc*high_rate+delta_rate*high_acc)/min_rate**3
    rounding=32*np.spacing(np.maximum(axes['heavy'][1:],axes['cold'][1:]))
    estimate=np.stack([np.diff(axes['heavy'])**2*second/9+rounding,np.zeros_like(rounding)],axis=1)
    htime=axes['heavy'][:-1]+np.diff(axes['heavy'])/3
    guess=left+(right-left)/3
    for iteration in range(3):
        guess=np.clip(guess-(heavy(guess)-htime)/heavy(guess,1),left,right)
    actual=cold(guess)-(axes['cold'][:-1]+np.diff(axes['cold'])/3)
    assert np.all(abs(actual)<=estimate[:,0]),abs(actual).max()
    return estimate

def run(tag):
    guard();order,sub=SETTINGS[tag];grid,media,clocks,cuts=setup()
    scale=late_mesh(grid,clocks,cuts,sub)
    bands=transfer.stages(order);trans=proj.transpose_bands(bands);axes={};data={};witness=[]
    for model in MODELS:
        with np.load(prior(f'projection-{model}.npz')) as prev:wave=float(prev['k'])
        _,times,medium,_,weights=media[model]
        axis=native(clocks[model],scale,grid,times,cuts[model]);axes[model]=axis
        assert np.sum(abs(weights[grid<scale[0]]))<1e-12
        active=scale[:-1]>=cuts[model]
        _,at,kernel=proj.backward(axis,times,weights,medium,wave,trans,active=active)
        hub=medium(at)[:,:,0]
        data[model]=dict(at=at,kernel=kernel,hub=hub,active=active,axis=axis)
        if tag=='primary':
            for case in ('common constant','varying pair'):
                def field(arg):
                    if case=='common constant':return np.broadcast_to([1+.3j,.4-.2j],(*arg.shape,2))
                    return test_field(arg)*(np.array([.91+.06j,1.04-.03j]) if model=='heavy' else 1.)
                fwd=proj.forward_control(axis,times,weights,medium,wave,bands,field,64.,axis[-1])
                projected=np.einsum('nctj,ntc->cj',kernel,field(at))
                witness.append((model,case,projected,fwd))
        print(tag,model,'retarded weights complete',flush=True)
    offset=node_offset(scale,axes,clocks,grid)
    save_arrays('response-'+tag+'.npz',scale=scale,clock_offset=offset,**{model+'_'+key:value for model,items in data.items() for key,value in items.items()})
    if witness:
        tests=[]
        for case in ('common constant','varying pair'):
            pairs={model:(projected,fwd) for model,kind,projected,fwd in witness if kind==case}
            pairs['MTS-minus-baseline']=tuple(h-c for h,c in zip(pairs['heavy'],pairs['cold']))
            for model,(projected,fwd) in pairs.items():
                for channel,one,two in zip(('energy','momentum','both'),(*projected,projected.sum(axis=0)),(*fwd,fwd.sum(axis=0))):
                    err=float(np.linalg.norm(one-two)/np.linalg.norm(two))
                    tests.append(dict(model=model,case=case,channel=channel,relative_error=err,passed=bool(err<=TOL)))
        table('direct-forward-controls.csv',tests)
        assert all(row['passed'] for row in tests)
    save_json('inputs-'+tag+'.json',proj.old.PROVENANCE)

if __name__=='__main__':
    for setting in SETTINGS:run(setting)
