from block import *
from fluid import Flow
from scipy.interpolate import make_interp_spline

def run(model):
    guard();folder=ROOT/'material-halfstep'
    with np.load(ROOT/f'particular-{model}-p4.npz') as raw:
        keys=raw['keys'];stress=raw['stress'];clock=raw['stressClock']
    with np.load(restart(model)) as src:initial=src['state'][:,:1]
    with np.load(ROOT/f'common-{model}.npz') as bank:common=bank['S'][None]
    flow=object.__new__(Flow)
    with patch.object(regular_flow,'HOME',folder):Flight.__init__(flow,model,68,6,False,True)
    assert np.array_equal(keys,flow.keys)
    flow.initial=(keys,initial);flow.wall=None;flow.start_offset=None
    flow.k=flow.k[:1];flow.factors=flow.factors[:,:1];flow.probe=flow.probe[:,:1]
    source=make_interp_spline(flow.log,flow.q(flow.log)[:,:,:1],k=5)
    flow.bg=make_interp_spline(flow.log,flow.bg(flow.log),k=5)
    flow.q=source;flow.drive=spline(clock,common.transpose(2,1,0))
    active=flow.t[8:-8];assert active[0]==44.8 and active[-1]==51.2
    flow.t=np.linspace(active[0],active[-1],2*(len(active)-1)+1);flow.t[::2]=active;flow.log=np.log(flow.t)
    eta,obs,_,_=flow.evolve(clock,stress)
    scale=flow.bg(flow.log)[:,flow.bgkeys.index('a')]
    deriv=-obs[:,3,0,0]/eta-flow.bg(flow.log)[:,flow.bgkeys.index('h')]*obs[:,1,0,0]+source(flow.log)[:,flow.qkeys.index('Fq'),0]
    pack(f'larger-step-{model}.npz',a=scale,phi=obs[:,0,0,0],psi=obs[:,1,0,0],pd=deriv)
def score():
    tables={}
    for model in ('cold','heavy'):
        with np.load(ROOT/f'larger-step-{model}.npz') as alt,np.load(ROOT/f'particular-{model}-p4.npz') as fine:
            scale=fine['a'];interval=np.linspace(max(scale[0],alt['a'][0]),min(scale[-1],alt['a'][-1]),1025)
            tables[model]=(interval,*[CubicSpline(bank['a'],np.column_stack((bank['phi'],bank['psi'],bank[key])),axis=0)(interval) for bank,key in [(fine,'phi_dot'),(alt,'pd')]])
    axis=np.linspace(max(row[0][0] for row in tables.values()),min(row[0][-1] for row in tables.values()),1025)
    matched={m:np.stack([CubicSpline(row[0],values)(axis) for values in row[1:]]) for m,row in tables.items()}
    matched['MTS-minus-cold']=matched['heavy']-matched['cold']
    checks=[]
    for m,(fine,other) in matched.items():
        for key,val in zip(('phi','psi','phi_dot'),np.max(abs(other-fine),axis=0)/np.max(abs(fine),axis=0)):
            checks.append(dict(model=m,variable=key,relative=val,passed=bool(val<=.005)))
    table('matched-step-check.csv',checks);print(checks,flush=True)
if __name__=='__main__':
    for model in ('cold','heavy'):run(model)
    score()
    with (ROOT/'matched-step-check.csv').open() as fp:rows=list(csv.DictReader(fp))
    assert len(rows)==9 and all(float(row['relative'])<=.005 for row in rows),'matched signed material step gate failed'
