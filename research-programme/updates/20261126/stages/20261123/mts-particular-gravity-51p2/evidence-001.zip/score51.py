from block import *
from scipy.integrate import simpson

def main():
    guard()
    suffix=sys.argv[1] if len(sys.argv)>1 else ''
    models=('cold','heavy','MTS-minus-cold')
    tags=('primary','time','angle','sampling');values={};fields={}
    checks=[];rows=[];markers=[];cross=[]
    for model in models[:2]:
        with np.load(ROOT/f'particular-{model}{suffix}.npz') as f:
            fields[model]=(f['a'],np.column_stack([f['phi_dot'],f['differentiated']]))
        for tag in tags:
            with np.load(ROOT/f'transfer-{model}-{tag}{suffix}.npz') as f:
                grid=f['scale']
                values[model,tag]={key:f[key] for key in ('block','shifted','free','old_free','regular','prior_sum','new_partial')}
    for tag in tags:
        values[models[-1],tag]={key:arr-values['cold',tag][key] for key,arr in values['heavy',tag].items()}
    with np.load(inherited.source('medium-cold.npz')) as f:
        assert np.array_equal(f['scale'],grid);clock=f['eta'];visibility=f['visibility']
    peak=json.loads(inherited.source('score.json').read_bytes())['visibility']['cold']['peak_scale']
    spline=lambda arr:CubicSpline(grid,arr,axis=0,extrapolate=False)
    window=np.linspace(1/1501,grid[-1],8193);w=spline(visibility)(window)*spline(clock)(window,1);w/=simpson(w,x=window)
    def powers(arr):
        return simpson(w[:,None]*abs(spline(arr)(window))**2,x=window,axis=0)
    def norms(arr):
        return np.array([np.sqrt(powers(arr).sum()),np.linalg.norm(spline(arr)(peak))])
    for model in models:
        main=values[model,'primary']
        initial=np.linalg.norm(main['old_free'][0])
        def compare(label,kind,test,ref):
            rms,point=norms(test-ref)/norms(ref)
            checks.append(dict(model=model,check=label,component=kind,window_relative=rms,peak_relative=point,passed=bool(max(rms,point)<=.005)))
        for key in ('old_free','regular','prior_sum','block','new_partial'):
            arr=main[key]
            size=norms(arr)/initial;p=np.sqrt(powers(arr))/initial
            rows.append(dict(model=model,source=key,input_norm=initial,window_over_input=size[0],peak_over_input=size[1],energy_window_over_input=p[0],current_window_over_input=p[1]))
            if key in ('block','new_partial'):
                for tag in tags[1:]:
                    compare(tag,key,values[model,tag][key],arr)
            for label,sample in [('z1500',1/1501),('peak',peak),('z750',grid[-1])]:
                density,flux=spline(arr)(sample)
                markers.append(dict(model=model,source=key,marker=label,energy_re=density.real,energy_im=density.imag,current_re=flux.real,current_im=flux.imag))
        compare('same freely transported photons','free',main['free'],main['old_free'])
        compare('integrated curvature vs constraint derivative','block',main['shifted'],main['block'])
        compare('integrated curvature vs constraint derivative','partial',main['prior_sum']+main['shifted'],main['new_partial'])
        inst=spline(main['block'])(peak);prev=spline(main['prior_sum'])(peak)
        inner=simpson(w*np.sum((spline(main['block'])(window)*np.conj(spline(main['prior_sum'])(window))).real,axis=1),x=window)
        cross.append(dict(model=model,window_alignment=inner/(norms(main['block'])[0]*norms(main['prior_sum'])[0]),peak_alignment=np.vdot(prev,inst).real/(np.linalg.norm(prev)*np.linalg.norm(inst)),squared_cross_over_launch=2*inner/initial**2))
        assert abs((norms(main['block'])[0]**2+norms(main['prior_sum'])[0]**2+2*inner)/norms(main['new_partial'])[0]**2-1)<1e-10
    common=np.linspace(max(f[0][0] for f in fields.values()),min(f[0][-1] for f in fields.values()),513)
    matched={m:CubicSpline(axis,arr,axis=0,extrapolate=False)(common) for m,(axis,arr) in fields.items()}
    matched['MTS-minus-cold']=matched['heavy']-matched['cold']
    slope_report=[]
    for model,arr in matched.items():
        frac=np.max(abs(arr[:,0]-arr[:,1]))/np.max(abs(arr[:,0]))
        slope_report.append(dict(model=model,max_difference_over_own_peak=frac,passed=bool(frac<=.005)))
    table('results'+suffix+'.csv',rows);table('signed-markers'+suffix+'.csv',markers);table('controls'+suffix+'.csv',checks);table('matched-curvature-check'+suffix+'.csv',slope_report);table('interference'+suffix+'.csv',cross)
    verdict=dict(transport_comparisons=len(checks),transport_passing=sum(row['passed'] for row in checks),curvature_comparisons=slope_report,max_transport_rms_error=max(row['window_relative'] for row in checks),max_transport_peak_error=max(row['peak_relative'] for row in checks),threshold=.005,later_particular_included=False)
    record('verification'+suffix+'.json',verdict)
    print([r for r in rows if r['model']=='MTS-minus-cold']);print(verdict,flush=True)
if __name__=='__main__':main()
