from block import *
from scipy.integrate import simpson

def main():
    guard()
    with np.load(inherited.source('medium-cold.npz')) as bath:
        grid=bath['scale'];axis=np.linspace(1/1501,grid[-1],8193)
        weights=CubicSpline(grid,bath['eta'])(axis,1)*CubicSpline(grid,bath['visibility'])(axis)
    weights/=simpson(weights,x=axis)
    peak=json.loads(inherited.source('score.json').read_bytes())['visibility']['cold']['peak_scale']
    def sizes(values):
        signal=CubicSpline(grid,values)
        return np.array([np.sqrt(simpson(weights*np.sum(abs(signal(axis))**2,axis=1),x=axis)),np.linalg.norm(signal(peak))])
    rows=[];stability=[];primary={};residual=[]
    for tag in ('primary','time','angle','sampling','materialstep'):
        parts={}
        for model in ('cold','heavy'):
            name=f'transfer-{model}-{tag}-p2.npz'
            next_name=name.replace('-p2.npz','-p4.npz')
            with np.load(ancestor(name)) as first,np.load(second(name)) as later,np.load(previous(next_name)) as old,np.load(ROOT/next_name) as new:
                assert all(np.array_equal(grid,packet['scale']) for packet in (first,later,old,new))
                assert all(np.array_equal(first['old_free'][0],packet['old_free'][0]) for packet in (later,old,new))
                first_pair=first['new_partial']+later['block']
                if tag=='primary':assert np.array_equal(first_pair,later['new_partial'])
                preceding=first_pair+old['block']
                if tag=='primary':assert np.array_equal(preceding,old['new_partial'])
                parts[model]=(preceding,new['block'],old['old_free'])
        parts['MTS-minus-cold']=tuple(second-first for second,first in zip(parts['heavy'],parts['cold']))
        for model,(prior,block,free_path) in parts.items():
            launch=free_path[0]
            change=100*(sizes(prior+block)-sizes(prior))/np.linalg.norm(launch)
            rows.append(dict(control=tag,model=model,rms_change_percentage_points=change[0],peak_change_percentage_points=change[1]))
            total=prior+block
            free_size=sizes(free_path);total_size=sizes(total);net_size=sizes(total-free_path)
            assert np.all(net_size+1e-12*total_size>=abs(total_size-free_size))
            residual.append(dict(control=tag,model=model,free_rms_over_launch=free_size[0]/np.linalg.norm(launch),total_rms_over_launch=total_size[0]/np.linalg.norm(launch),net_drive_rms_over_launch=net_size[0]/np.linalg.norm(launch),net_drive_peak_over_launch=net_size[1]/np.linalg.norm(launch)))
            if tag=='primary':primary[model]=total
            rms,peak_change=sizes(total-primary[model])/sizes(primary[model])
            stability.append(dict(control=tag,model=model,rms_relative=rms,peak_relative=peak_change,passed=bool(max(rms,peak_change)<=.005)))
    table('direction-under-paired-controls.csv',rows)
    table('all-four-blocks-control.csv',stability)
    table('net-drive-versus-free.csv',residual)

if __name__=='__main__':main()
