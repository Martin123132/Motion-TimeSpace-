from block import *
import angular12
from scipy.special import eval_legendre
from scipy.sparse import csr_matrix
import ctypes
from numpy.ctypeslib import ndpointer

def real(array):return np.ascontiguousarray(array,dtype=np.float64)

class Flight32:
    def __init__(self,inc):
        self.inc=inc;self.clock=real(inc.data.eta);self.nodes=real(inc.k)
        mid=np.interp(np.arange(2*len(self.clock)-1)/2,np.arange(len(self.clock)),self.clock)
        self.ph,self.ps=[real(CubicSpline(self.clock,inc.data.first[name].T)(mid)) for name in ('phi','psi')]
        self.mass=inc.mass*CubicSpline(self.clock,inc.data.background['a'])(mid)
        ell=np.arange(81)[:,None];self.lower=real(inc.k*ell/(2*ell+1));self.upper=real(inc.k*(ell+1)/(2*ell+1))
        self.lib=ctypes.CDLL(str(flight_library()))
        self.solver=self.lib.flight32;self.solver.restype=None
        self.solver.argtypes=[ctypes.c_int]*3+[ndpointer(dtype=np.float64,flags='C_CONTIGUOUS')]*10
    def run(self,q,start):
        state=real(start.copy());state[0,0]-=self.ph[0]
        speed=real(q/np.hypot(q,self.mass) if np.isfinite(q) else np.ones_like(self.mass))
        out=np.empty((1+(len(self.clock)-1)//4,*state.shape))
        scratch=np.empty((3,*state.shape))
        self.solver(len(self.clock)-1,len(self.nodes),state.shape[1],self.clock,speed,self.lower,self.upper,self.ph,self.ps,self.nodes,state,scratch,out)
        return out

class Contraction:
    def __init__(self,proj):
        op,self.wave,radius,cosine,left,right,phase=proj.ops[0]
        data=proj.data;self.scale=data.background['a'][::4];size=len(data.nodes)
        phi,psi,pd=[data.first[key][:,::4] for key in ('phi','psi','pd')]
        def contract(weights,field):
            matrix=csr_matrix((phase*np.broadcast_to(weights,radius.shape),(left,right)),shape=(size,size))
            return np.ascontiguousarray((matrix@field).T)
        self.const0=2*np.einsum('ti,it->t',contract(1,phi),pd)
        self.const1=(np.einsum('ti,it->t',contract(radius*cosine,phi+psi),psi)-self.wave*np.einsum('ti,it->t',contract(1,psi),psi))/3
        self.rows=[]
        legs=[eval_legendre(degree,cosine) for degree in range(70)]
        for ell in range(69):
            entries=[]
            for idx in (ell-1,ell+1):
                if idx<0:continue
                beta=(ell if idx<ell else -(ell+1))/(2*ell+1)
                a=beta*radius*legs[ell];b=beta*self.wave*legs[idx]-a
                gc=(2+idx*(idx+1)-ell*(ell+1))/2
                entries.append((idx,contract(a,phi+psi)-gc*contract(b,phi),contract(b,psi),gc))
            self.rows.append((contract(legs[ell],pd),entries))
    def project(self,field,slope,q,mass):
        rate=q/np.hypot(q,mass*self.scale) if np.isfinite(q) else np.ones_like(self.scale)
        weight=1-q*np.tanh(q/2) if np.isfinite(q) else -4.
        dot=lambda coeff,val:np.einsum('ti,ti->t',coeff,val)
        out=np.empty((69,len(rate)),complex)
        for ell,(co,entries) in enumerate(self.rows):
            out[ell]=-dot(co,slope[:,ell]+weight*field[:,ell])
            for ix,first,second,gc in entries:
                out[ell]+=rate*dot(first,field[:,ix])-dot(second,slope[:,ix]+(weight+gc)*field[:,ix])/rate
        out[0]+=self.const0;out[1]+=self.const1/rate
        return out

def run(model):
    guard()
    with patch.object(angular12,'HERE',ROOT):
        inc,proj,_,waves=angular12.env(model,False,1)
    engine=Flight32(inc);contract=Contraction(proj)
    with np.load(previous(f'common-{model}.npz')) as earlier:
        initial=earlier['end'].copy();initial[1]=0
        samples=engine.run(np.inf,initial);field=samples[:,0]
        common=contract.project(field,samples[:,1],np.inf,inc.mass)
        spectral=contract.project(field,field,np.inf,inc.mass)-common
        old_common=earlier['S'][:,-1];old_spec=earlier['Sw'][:,-1]
        assert max(abs(common[:,0]-old_common))/max(abs(old_common))<.005
        assert max(abs(spectral[:,0]-old_spec))/max(abs(old_spec))<.005
    pack(f'common-{model}.npz',S=common,Sw=spectral,end=samples[-1],eta=inc.data.eta[::4],k=waves[:1])
    del samples,field
    for node in range(-52,25):
        guard();fname=f'micro-{model}-{node}.npz';path=previous(fname)
        if (ROOT/fname).exists():continue
        q=2.**(node/4)
        with np.load(path) as bank:
            start=bank['end'];old_source=bank['source'][:,-1]
        sample=engine.run(q,start)
        direct=contract.project(sample[:,0],sample[:,1],q,inc.mass)
        weight=5-q*np.tanh(q/2)
        target=old_source+old_common+weight*old_spec
        seam=np.max(abs(direct[:,0]-target))/max(abs(target))
        assert seam<.005,(model,node,seam)
        test=0.
        if node in (-52,0,24):
            start[0,0]-=inc.data.first['phi'][:,0]
            field,slope=inc.flight(q,start)
            test=max(np.max(abs(a-b))/max(abs(b).max(),1e-50) for a,b in [(sample[:,0],field.transpose(2,0,1)),(sample[:,1],slope.transpose(2,0,1))])
            copy=proj.ops;proj.ops=copy[:1]
            try:reference=proj.calculate(field,slope,q,maximum=68,match_bulk=False)[0][0]
            finally:proj.ops=copy
            test=max(test,np.max(abs(direct-reference))/abs(reference).max())
            assert test<1e-10,(node,test)
        pack(fname,q=q,id=node,source=direct-common-weight*spectral,end=sample[-1],join=seam,independent=test)
        if node%8==0:print(model,'saved bin',node,flush=True)

if __name__=='__main__':
    for model in sys.argv[1:] or ['cold','heavy']:run(model)
