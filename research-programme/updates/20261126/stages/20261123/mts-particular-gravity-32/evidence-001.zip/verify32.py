from block import *
from scipy.integrate import simpson

def main():
    guard();manifest=ROOT/'seal.json'
    if manifest.exists():
        saved=json.loads(manifest.read_bytes())
        for name,sha in saved['files'].items():assert digest(ROOT/name)==sha,name
        assert saved['parent']==digest(PRE/'seal.json')
    elif sys.argv[1:]!=['--seal']:raise FileNotFoundError(manifest)
    result=json.loads((ROOT/'verification-p2.json').read_bytes())
    assert result['transport_passing']==result['transport_comparisons']==27 and all(row['passed'] for row in result['curvature_comparisons'])
    with (ROOT/'matched-step-check.csv').open() as fp:
        steps=list(csv.DictReader(fp))
    assert len(steps)==9 and all(float(row['relative'])<=.005 for row in steps)
    states={};models=('cold','heavy')
    for m in models:
        report=json.loads((ROOT/f'metric-{m}-p2.json').read_bytes())
        assert report['passed'] and report['parent']==digest(restart(m)) and len(report['micro'])==77
        for name,sha in report['micro'].items():assert digest(ROOT/name)==sha
        assert max(report['incident_seam'],report['time_metric'],report['slope_error'],report['iterations'][-1]['metric_increment'])<=.005
        with np.load(ROOT/f'particular-{m}-p2.npz') as raw:
            assert np.array_equal(raw['q'],2.**(np.arange(-52,25)/4)) and raw['state'].shape[1:]==(1,2) and raw['lagEnd'].shape==(77,69,1,2)
            assert np.array_equal(raw['eta'][[0,-1]],[25.6,32]) and np.all(np.diff(raw['a'])>0)
        for tag in ('primary','materialstep'):
            with np.load(ROOT/f'transfer-{m}-{tag}-p2.npz') as raw:
                states[m,tag]={s:raw[s] for s in ('block','new_partial','old_free','regular','prior_sum')}
                assert max(raw['additivity'])<1e-10
    for tag in ('primary','materialstep'):
        states['contrast',tag]={key:val-states['cold',tag][key] for key,val in states['heavy',tag].items()}
    with np.load(inherited.source('medium-cold.npz')) as f:
        grid=f['scale'];eta=f['eta'];visibility=f['visibility']
    peak=json.loads(inherited.source('score.json').read_bytes())['visibility']['cold']['peak_scale']
    window=np.linspace(1/1501,grid[-1],8193);w=CubicSpline(grid,eta)(window,1)*CubicSpline(grid,visibility)(window);w/=simpson(w,x=window)
    def norm_history(v):
        calc=CubicSpline(grid,v)
        return np.array([np.sqrt(simpson(w*np.sum(abs(calc(window))**2,axis=1),x=window)),np.linalg.norm(calc(peak))])
    rows=[]
    for m in (*models,'contrast'):
        for key in ('block','new_partial'):
            prima=states[m,'primary'][key]
            errors=norm_history(states[m,'materialstep'][key]-prima)/norm_history(prima)
            rows.append(dict(model=m,quantity=key,rms=errors[0],peak=errors[1],passed=bool(max(errors)<=.005)))
    table('frozen-stress-step-propagated.csv',rows)
    assert all(row['passed'] for row in rows)
    with (ROOT/'results-p2.csv').open() as fp:
        for row in csv.DictReader(fp):
            m='contrast' if row['model']=='MTS-minus-cold' else row['model']
            spectra=states[m,'primary']
            sizes=norm_history(spectra[row['source']])/np.linalg.norm(spectra['old_free'][0])
            assert np.allclose(sizes,[float(row['window_over_input']),float(row['peak_over_input'])],rtol=1e-12,atol=0)
    assert not list(ROOT.rglob('reader-*')) and not list(ROOT.rglob('__pycache__'))
    if not manifest.exists():
        files={f.relative_to(ROOT).as_posix():digest(f) for f in sorted(ROOT.rglob('*')) if f.is_file() and f!=manifest}
        record('seal.json',dict(files=files,parent=digest(PRE/'seal.json'),restarts={m:digest(restart(m)) for m in models}))
    print('Verified 154 finite incident restarts, both coupled endpoints, signed metrics, interference numbers and 33 paired window/peak checks.',flush=True)

if __name__=='__main__':main()
