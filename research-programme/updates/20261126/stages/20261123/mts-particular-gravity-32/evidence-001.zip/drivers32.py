from block import *
import sources12
if __name__=='__main__':
    with patch.object(sources12,'HERE',ROOT),patch.object(sources12,'pack',pack),patch.object(sources12,'table',table),patch.object(sources12,'checked',old):
        for model in ('cold','heavy'):sources12.construct(model)
