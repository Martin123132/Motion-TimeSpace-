from block import *

def main():
    rows=[]
    for model in ('cold','heavy'):
        for kind in ('incident-input','forcing','radiation'):
            path=f'{kind}-{model}.npz'
            with np.load(ROOT/path) as old,np.load(ROOT/'material-halfstep'/path) as new:
                native=old['eta'];middle=new['eta'][9:-8:2];assert len(middle)==512
                assert np.array_equal(native,new['eta'][8:-8:2])
                if kind=='incident-input':
                    fields=[(key,old[key].T,new[key].T) for key in ('phi','psi','pd')]
                else:
                    fields=[(key,a[:,:1],b[:,:1]) for key,a,b in zip(old['keys'],old['values'],new['values'])]
                for key,base,full in fields:
                    pred=CubicSpline(native,base,axis=0,extrapolate=False)(middle)
                    actual=full[9:-8:2]
                    scale=np.maximum(np.max(abs(full[8:-8]),axis=0),1e-80)
                    interior=np.max(np.max(abs(actual-pred)[4:-4],axis=0)/scale)
                    rows.append(dict(model=model,group=kind,field=key,peak_fraction=float(np.max(np.max(abs(actual-pred),axis=0)/scale)),interior_peak_fraction=float(interior)))
    table('new-midpoint-vs-interpolated-input.csv',rows)
    print([r for r in rows if r['group']=='incident-input'],flush=True)

if __name__=='__main__':main()
