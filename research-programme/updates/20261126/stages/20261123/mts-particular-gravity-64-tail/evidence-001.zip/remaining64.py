from block import *
from transfer import operators
from scipy.interpolate import BSpline, make_interp_spline
from scipy.sparse import diags
from scipy.sparse.linalg import spsolve
from scipy.integrate import simpson


def controls(knots, values, piece=None):
    spline=CubicSpline(knots,values,extrapolate=False) if piece is None else piece
    widths=np.diff(knots)
    slopes=spline(knots,1)
    return np.stack((values[:-1],values[:-1]+widths*slopes[:-1]/3,values[1:]-widths*slopes[1:]/3,values[1:]),axis=1)


def symmetrizer(order):
    stream,drag,recoil,hubble=operators(order)
    weights=np.ones(len(stream));weights[1:5]=[3,3,5,30]
    for row in range(5,len(stream)):
        prev=row-2
        weights[row]=-weights[prev]*stream[prev,row]/stream[row,prev]
    assert np.all(weights>0)
    free=weights[:,None]*stream
    assert np.max(abs(free+free.T))/np.max(abs(free))<1e-14
    collision=weights[:,None]*(drag+recoil)
    assert np.max(abs(collision-collision.T))<1e-12
    assert np.linalg.eigvalsh(collision)[-1]<1e-12
    assert np.allclose(collision[1:3,1:3],[[-3,3],[3,-3]]) and np.allclose(collision[3:5,3:5],[[-4.5,3],[3,-12]])
    assert np.count_nonzero(recoil[1])==np.count_nonzero(recoil)==2
    assert np.count_nonzero(hubble)==1 and hubble[1,1]==-1
    return float(weights.min())


def medium_bound(model,grid,window,weights,peak):
    with np.load(inherited.source(f'medium-{model}.npz')) as raw:
        assert np.array_equal(raw['scale'],grid)
        eta=raw['eta'];hub=raw['hub'];loading=raw['loading'];opacity=raw['opacity']
    hub_control=controls(eta,hub);load_control=controls(eta,loading);opacity_control=controls(eta,opacity)
    max_slope=(3*np.diff(load_control,axis=1)/np.diff(eta)[:,None]).max(axis=1)
    friction_margin=2*hub_control.min(axis=1)*load_control.min(axis=1)-max_slope
    assert min(hub_control.min(),load_control.min(),opacity_control.min(),friction_margin.min())>0
    clock=CubicSpline(grid,eta,extrapolate=False)
    rms=lambda values:float(np.sqrt(simpson(weights*values**2,x=window)))
    durations=np.maximum(eta-64.,0.)
    template=make_interp_spline(grid,np.zeros_like(grid))
    knots=template.t;basis=BSpline.design_matrix(grid,knots,3).tocsc()
    comparison=2*diags(basis.diagonal())-abs(basis)
    comparison=comparison.tocsc()
    witness=spsolve(comparison,np.ones(len(grid)))
    assert np.min(witness)>0 and np.min(comparison@witness)>.99
    upper=spsolve(comparison,durations)+1e-9*witness
    assert np.min(upper)>=0 and np.min(comparison@upper-durations)>=0
    lifted=BSpline(knots,upper,3,extrapolate=False)
    unit=witness*(1+1e-9)
    assert np.min(comparison@unit)>=1.
    uniform=BSpline(knots,unit,3,extrapolate=False)
    assert np.min(lifted(window)-np.maximum(clock(window)-64.,0.))>-1e-8
    return dict(model=model,eta_last=float(eta[-1]),eta_peak=float(clock(peak)),max_loading=float(load_control.max()),min_opacity=float(opacity_control.min()),min_friction_margin=float(friction_margin.min()),window_duration=rms(np.maximum(clock(window)-64.,0.)),peak_duration=float(max(clock(peak)-64.,0.)),scored_window_gain=rms(lifted(window)),scored_peak_gain=float(lifted(peak)),constant_window_gain=rms(uniform(window)),constant_peak_gain=float(uniform(peak)))


def main():
    guard()
    with np.load(inherited.source('medium-cold.npz')) as raw:
        grid=raw['scale'];window=np.linspace(1/1501,grid[-1],8193)
        weight=CubicSpline(grid,raw['visibility'])(window)*CubicSpline(grid,raw['eta'])(window,1)
    assert weight.min()>=0
    weight/=simpson(weight,x=window)
    peak=json.loads(inherited.source('score.json').read_bytes())['visibility']['cold']['peak_scale']
    for order in (128,192):symmetrizer(order)
    models=('cold','heavy')
    media=[medium_bound(model,grid,window,weight,peak) for model in models]
    if sys.argv[1:]==['--medium']:
        print(media,flush=True);return
    assert json.loads((ROOT/'pre-transport-gate.json').read_bytes())['passed']
    envelope=[];end_sources=[]
    for model,medium in zip(models,media):
        p2=f'particular-{model}-p2.npz';p4=f'particular-{model}-p4.npz';p8=f'particular-{model}-p8.npz'
        metrics=(ancestor(p2),second(p2),third(p4),fourth(p4),previous(p4),ROOT/p8)
        prior_end=25.6
        for file,transfer in zip(metrics,transfer_paths(model,'primary'),strict=True):
            with np.load(file) as raw,np.load(transfer) as read:
                times=raw['eta'];field=raw['phi_dot'];lapse=raw['psi'];wave=float(raw['k'][0])
                assert times[0]==prior_end and times[-1]<=64. and np.all(np.diff(times)>0)
                prior_end=times[-1]
                field_hi=np.max(abs(controls(times,field)),axis=1)
                lapse_hi=np.max(abs(controls(times,lapse)),axis=1)
                factor=wave**2*(1+medium['max_loading'])/3
                cap=4*np.sqrt(field_hi**2+factor*lapse_hi**2)
                integral=float(np.dot(np.diff(times),cap))
                observed=float(np.max(np.linalg.norm(read['block'],axis=1)))
                assert 0<observed<=integral and np.isfinite(integral)
                envelope.append(dict(model=model,first=times[0],last=times[-1],source_integral_upper=integral,largest_saved_response=observed,ratio=observed/integral))
                if times[-1]==64.:
                    with np.load(inherited.source(f'medium-{model}.npz')) as env:
                        end_loading=float(CubicSpline(env['eta'],env['loading'])(64.))
                    end_sources.append(float(4*np.sqrt(abs(field[-1])**2+wave**2*(1+end_loading)*abs(lapse[-1])**2/3)))
        assert prior_end==64.
    with (ROOT/'results-p8.csv').open() as stream:
        row=next(row for row in csv.DictReader(stream) if row['model']=='MTS-minus-cold' and row['source']=='new_partial')
    launch=float(row['input_norm'])
    budgets=[]
    for measure in ('window','peak'):
        signal=launch*float(row[measure+'_over_input'])
        gain=sum(item['scored_'+measure+'_gain'] for item in media)
        duration=sum(item[measure+'_duration'] for item in media)
        equal_grid_gain=max(item['constant_'+measure+'_gain'] for item in media)
        budgets.append(dict(measure=measure,retained_contrast_norm=signal,absolute_point_five_percent_budget=.005*signal,paired_integral_budget_scored=.005*signal/equal_grid_gain,uniform_cap_per_branch_continuous=.005*signal/duration,uniform_cap_per_branch_scored=.005*signal/gain,combined_gain_mpc=gain))
    table('tail-propagation-gains.csv',media);table('tail-bound-backtest.csv',envelope);table('tail-source-budgets.csv',budgets)
    common_cap=min(row['uniform_cap_per_branch_scored'] for row in budgets)
    coverage=predecessor('source-coverage.csv')
    record('tail-verdict.json',dict(scope='retained finite-angular photon+baryon system; conditional bound, no later forcing evaluated',latest_matched_particular_mpc=64.,coverage_ledger=digest(coverage),source_norm_at_64_per_mpc=dict(zip(models,end_sources)),sufficient_common_cap_per_mpc=common_cap,endpoint_over_common_cap=dict(zip(models,[v/common_cap for v in end_sources])),uniform_cap_satisfied_at_endpoint=all(v<=common_cap for v in end_sources),physical_tail_bounded_below_tolerance=False,measured_blocks_checked=len(envelope)))
    print(media,budgets,end_sources,flush=True)

if __name__=='__main__':main()
