from block import *
from scipy.integrate import simpson


def main():
    guard()
    with np.load(inherited.source('medium-cold.npz')) as medium:
        grid=medium['scale'];axis=np.linspace(1/1501,grid[-1],8193)
        weight=CubicSpline(grid,medium['eta'])(axis,1)*CubicSpline(grid,medium['visibility'])(axis)
        weight/=simpson(weight,x=axis)
    peak=json.loads(inherited.source('score.json').read_bytes())['visibility']['cold']['peak_scale']
    model_parts={}
    for model in ('cold','heavy'):
        blocks=[]
        for packet_path in transfer_paths(model,'primary'):
            with np.load(packet_path) as data:
                assert np.array_equal(data['scale'],grid)
                if not blocks:
                    original=data['prior_sum'];free=data['old_free']
                    running=original.copy()
                assert np.array_equal(running,data['prior_sum']) and np.array_equal(free,data['old_free'])
                blocks.append(data['block']);running=running+blocks[-1]
                assert np.array_equal(running,data['new_partial'])
        model_parts[model]=(np.stack(blocks),original,running,free[0])
    model_parts['MTS-minus-cold']=tuple(heavy-cold for heavy,cold in zip(model_parts['heavy'],model_parts['cold']))
    rows=[];alignments=[]
    with previous('five-interval-coherence.csv').open() as stream:
        saved_five={(row['model'],row['measure']):float(row['net_over_launch']) for row in csv.DictReader(stream)}
    for model,(blocks,original,total,launch) in model_parts.items():
        curve=CubicSpline(grid,blocks,axis=1); reference=CubicSpline(grid,total-original)
        for measure in ('window','peak'):
            profiles=curve(axis) if measure=='window' else curve(peak)
            if measure=='window':
                gram=simpson(np.einsum('itc,jtc->ijt',profiles.conj(),profiles).real*weight,x=axis,axis=-1)
                direct=np.sqrt(simpson(weight*np.sum(abs(reference(axis))**2,axis=1),x=axis))
            else:
                gram=(profiles.conj()@profiles.T).real;direct=np.linalg.norm(reference(peak))
            individual=np.sqrt(np.diag(gram));coherent=np.sqrt(gram.sum());scale=np.linalg.norm(launch)
            assert abs(coherent-direct)<1e-10*individual.sum() and coherent<=individual.sum()*(1+1e-12)
            prior_norm=np.sqrt(gram[:-1,:-1].sum())
            assert np.isclose(prior_norm/scale,saved_five[model,measure],rtol=2e-12,atol=0)
            alignment=gram[-1,:-1].sum()/(individual[-1]*prior_norm)
            assert abs(alignment)<=1+1e-12
            assert np.isclose(coherent**2,prior_norm**2+individual[-1]**2+2*alignment*prior_norm*individual[-1],rtol=1e-11,atol=0)
            alignments.append(dict(model=model,measure=measure,prior_five_over_launch=prior_norm/scale,sixth_over_launch=individual[-1]/scale,sixth_to_prior_five_alignment=alignment,six_over_launch=coherent/scale))
            rows.append(dict(model=model,measure=measure,net_over_launch=coherent/scale,individual_magnitudes_summed_over_launch=individual.sum()/scale,net_over_summed_magnitudes=coherent/individual.sum()))
    table('six-interval-coherence.csv',rows)
    table('sixth-versus-five.csv',alignments)

if __name__=='__main__':main()
