from remaining64 import *


def main():
    guard()
    with (ROOT/'paired-tail-backtest-medium.csv').open() as stream:
        epsilon=float(next(row for row in csv.DictReader(stream) if row['order']=='192')['medium_mismatch_bound'])
    with (ROOT/'tail-bound-backtest.csv').open() as stream:
        branch={row['model']:float(row['source_integral_upper']) for row in csv.DictReader(stream) if float(row['last'])==64.}
    prepared={}
    for model in ('cold','heavy'):
        with np.load(inherited.source(f'medium-{model}.npz')) as data:
            axis=data['scale'];eta=data['eta'];clock=CubicSpline(axis,eta,extrapolate=False)
            coeff=controls(axis,eta);width=np.diff(axis)
            beta=3*np.diff(coeff,axis=1)/width[:,None]
            assert beta.min()>0.
            fastest=float(beta.max());curvature=float(np.max(abs(2*np.diff(beta,axis=1)/width[:,None])))
            loading=float(controls(eta,data['loading']).max())
        with np.load(ROOT/f'particular-{model}-p8.npz') as data:
            times=data['eta'];wave=float(data['k'][0])
            fields=np.stack([data['phi_dot'],data['psi']])
            fields_hi=[];slopes_hi=[]
            for values in fields:
                control=controls(times,values)
                fields_hi.append(np.max(abs(control)))
                slopes_hi.append(np.max(abs(3*np.diff(control,axis=1)/np.diff(times)[:,None])))
            fields_hi=np.array(fields_hi);slopes_hi=np.array(slopes_hi)
        prepared[model]=(clock,CubicSpline(times,fields,axis=1,extrapolate=False),fastest*fields_hi,curvature*fields_hi+fastest**2*slopes_hi,loading)
    use=np.logical_or.reduce([(clock(axis[1:])>=57.6-1e-12)&(clock(axis[:-1])<=64.+1e-12) for clock,*rest in prepared.values()])
    indices=np.flatnonzero(use);assert np.all(np.diff(indices)==1)
    rows=[]
    for subdiv in (32,128):
        edges=np.r_[(axis[indices,None]+np.diff(axis)[indices,None]*np.arange(subdiv)/subdiv).ravel(),axis[indices[-1]+1]]
        mid=(edges[1:]+edges[:-1])/2;width=np.diff(edges);assert width.min()>0
        source={};allowance={};mixed={};flags={}
        for model,(clock,fields,maximum,lipschitz,loading) in prepared.items():
            start=clock(edges[:-1]);end=clock(edges[1:])
            inside=(start>57.6+1e-12)&(end<64.-1e-12)
            active=(end>=57.6-1e-12)&(start<=64.+1e-12)
            flags[model]=inside
            source[model]=np.zeros((2,len(mid)),complex)
            source[model][:,inside]=clock(mid[inside],1)*fields(clock(mid[inside]))
            allowance[model]=lipschitz[:,None]*width[None,:]/2
            mixed[model]=maximum[:,None]*active
        both=flags['cold']&flags['heavy']
        cap=mixed['cold']+mixed['heavy']
        cap[:,both]=(abs(source['heavy']-source['cold'])+allowance['heavy']+allowance['cold'])[:,both]
        signed=float(np.sum(width*4*np.hypot(cap[0],wave*np.sqrt((1+prepared['heavy'][-1])/3)*cap[1])))
        bound=signed+epsilon*branch['cold']
        with np.load(ROOT/'transfer-heavy-primary-p8.npz') as heavy,np.load(ROOT/'transfer-cold-primary-p8.npz') as cold:
            observed=float(np.max(np.linalg.norm(heavy['block']-cold['block'],axis=1)))
        assert observed<=bound and all(np.isfinite([observed,bound,signed]))
        rows.append(dict(subdivisions=subdiv,integral_signed_force_upper=signed,cold_integral_upper=branch['cold'],medium_leakage_coefficient=epsilon,paired_nodal_bound=bound,separate_branch_bound=sum(branch.values()),observed_max_nodal=observed))
    table('paired-tail-backtest.csv',rows);print(rows,flush=True)

if __name__=='__main__':main()
