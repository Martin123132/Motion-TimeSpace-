from block import *


def enclose(model):
    guard()
    with patch.object(regular_flow,'HOME',ROOT/'material-halfstep'):
        flow=Flight(model,68,6,False,True)
    end=np.log(64.)
    assert np.any(flow.t==64.)
    bg=dict(zip(flow.bgkeys,flow.bg(end)))
    inputs=dict(zip(flow.qkeys,flow.q(end)[:,0]))
    with np.load(ROOT/f'particular-{model}-p8.npz') as raw:
        assert raw['eta'][-1]==raw['stressClock'][-1]==64.
        state=dict(zip(raw['keys'],raw['state'][:,0,0]));wave=float(raw['k'][0])
        stress=raw['stress'][-1,:,0,0]*bg['enu']
        target=np.array([raw[key][-1] for key in ('phi','psi','phi_dot')])
    square=wave**2;expansion=bg['h'];ratio=bg['eb']/bg['eg']
    baryon_velocity=(state['W']-state['B'])/(ratio+4/3)
    gas_current=state['B']+4*baryon_velocity/3
    radiation_energy=4*bg['er']+bg['nuE']
    energy=bg['eg']*state['gx']+inputs['gE']+radiation_energy*state['N0']+stress[0]
    current=bg['eg']*gas_current+inputs['gJ']+wave*(4*bg['er']+bg['nuJ'])*state['N1']+inputs['nuJ']+wave*stress[1]
    shear=-bg['eg']*(state['I2']+inputs['ph_shift'])-(4*bg['er']+bg['nuS'])*state['N2']+stress[2]
    susceptibility=4*bg['eg']+radiation_energy
    for tag,velocity in [('c',state['ct']),('b',baryon_velocity)]:
        density=bg['e'+tag]
        energy+=density*state[tag+'d']+inputs[tag+'trace']+inputs[tag+'KE']
        current+=density*velocity+inputs[tag+'Jq'];shear+=inputs[tag+'shear'];susceptibility+=3*density
    for tag in flow.tags:
        velocity=bg[tag+'v']
        energy+=velocity*state[tag+'w']+(bg['a']*bg[tag+'m'])**2*bg[tag+'b']*state[tag+'f']+inputs[tag+'energy']
        current+=square*velocity*state[tag+'f']+inputs[tag+'J'];shear+=inputs[tag+'shear'];susceptibility+=3*velocity**2
    denominator=square+susceptibility/2
    assert susceptibility>=0 and expansion>0
    flux=-current/(2*square);effective_energy=inputs['U']-energy/2;effective_shear=shear-inputs['Q']
    phi=(effective_energy+3*expansion*flux)/denominator
    psi=phi+effective_shear/square
    derivative=-flux-expansion*psi+inputs['Fq']
    maximum=max(abs((np.array([phi,psi,derivative])-target)/target))
    assert maximum<1e-8,(model,maximum)
    phi_hi=(abs(effective_energy)+3*expansion*abs(flux))/denominator
    psi_hi=phi_hi+abs(effective_shear)/square
    derivative_hi=abs(flux)+expansion*psi_hi+abs(inputs['Fq'])
    with np.load(inherited.source(f'medium-{model}.npz')) as medium:
        loading=float(CubicSpline(medium['eta'],medium['loading'])(64.))
    gain=wave*np.sqrt((1+loading)/3)
    bound=4*np.hypot(derivative_hi,gain*psi_hi)
    actual=4*np.hypot(abs(target[2]),gain*abs(target[1]))
    assert actual<=bound*(1+1e-12)
    return dict(model=model,eta=64.,abs_U_minus_E_over_2=abs(effective_energy),abs_J_total=abs(current),abs_shear_minus_Q=abs(effective_shear),abs_Fq=abs(inputs['Fq']),denominator=denominator,phi_bound=phi_hi,psi_bound=psi_hi,phi_prime_bound=derivative_hi,source_norm_actual=actual,source_norm_majorant=bound,reconstruction_relative_error=maximum)


if __name__=='__main__':
    rows=[enclose(model) for model in ('cold','heavy')]
    table('tail-constraint-endpoint.csv',rows);print(rows,flush=True)
