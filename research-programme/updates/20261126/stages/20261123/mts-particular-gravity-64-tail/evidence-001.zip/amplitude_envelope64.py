from remaining64 import *


def main():
    guard()
    with (ROOT/'tail-propagation-gains.csv').open() as stream:media={row['model']:row for row in csv.DictReader(stream)}
    with (ROOT/'tail-source-budgets.csv').open() as stream:budgets=list(csv.DictReader(stream))
    rows=[];wave_numbers={}
    for model,inherited_medium in media.items():
        coarse=f'particular-{model}-p2.npz';fine=f'particular-{model}-p4.npz'
        paths=(ancestor(coarse),second(coarse),third(fine),fourth(fine),previous(fine),ROOT/f'particular-{model}-p8.npz')
        max_loading=float(inherited_medium['max_loading'])
        for path,transfer in zip(paths,transfer_paths(model,'primary'),strict=True):
            with np.load(path) as raw,np.load(transfer) as measured:
                times=raw['eta'];width=np.diff(times);wave=float(raw['k'][0]);wave_numbers[model]=wave
                phi=controls(times,raw['phi']);delta=phi-raw['phi'][0];lapse=controls(times,raw['psi'])
                constraint=controls(times,raw['phi_dot'])
                quad=3*np.diff(phi,axis=1)/width[:,None]
                cubic=np.column_stack((quad[:,0],(quad[:,0]+2*quad[:,1])/3,(2*quad[:,1]+quad[:,2])/3,quad[:,2]))
                residual=4*float(np.dot(width,abs(constraint-cubic).max(axis=1)))
                accel=4*wave/np.sqrt(3)*np.sqrt(max_loading*abs(lapse).max(axis=1)**2+abs(lapse+delta).max(axis=1)**2)
                surface=4*float(np.max(abs(delta)))
                estimate=surface+float(np.dot(width,accel))+residual
                observed=float(np.max(np.linalg.norm(measured['block'],axis=1)))
                assert np.isfinite(estimate) and 0<observed<=estimate
                rows.append(dict(model=model,start=times[0],end=times[-1],surface_upper=surface,integrated_acceleration_upper=np.dot(width,accel),discrete_derivative_defect_upper=residual,amplitude_bound=estimate,max_saved_nodal=observed))
    result=[]
    for row in budgets:
        measure=row['measure'];gain=sum(4*float(item['constant_'+measure+'_gain'])+4*wave_numbers[model]/np.sqrt(3)*np.sqrt(4+float(item['max_loading']))*float(item['scored_'+measure+'_gain']) for model,item in media.items())
        result.append(dict(measure=measure,dimensionless_gain=gain,common_potential_excursion_and_lapse_cap=float(row['absolute_point_five_percent_budget'])/gain))
    table('amplitude-tail-backtest.csv',rows);table('amplitude-tail-budgets.csv',result);print(result,flush=True)

if __name__=='__main__':main()
