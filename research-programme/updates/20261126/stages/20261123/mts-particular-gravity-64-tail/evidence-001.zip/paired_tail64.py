from remaining64 import *
from math import comb


def prod(left,right):
    out=np.zeros((len(left)+len(right)-1,left.shape[1]))
    for index,row in enumerate(left):
        out[index:index+len(right)]+=row*right
    return out


def medium_polys(model):
    with np.load(inherited.source(f'medium-{model}.npz')) as data:
        scale=data['scale'];eta=data['eta'];clock=CubicSpline(scale,eta)
        dx=np.diff(scale);coeff=clock.c[::-1].copy()
        shift=np.vstack([np.zeros_like(dx),coeff[1]*dx,coeff[2]*dx**2,coeff[3]*dx**3])
        beta=shift[1:]*np.array([1,2,3])[:,None]
        rates={}
        for key in ('opacity','loading','hub'):
            raw=CubicSpline(eta,data[key])
            parts=raw.c[::-1]
            poly=parts[3:4].copy()
            for degree in (2,1,0):
                poly=prod(poly,shift);poly[0]+=parts[degree]
            for fraction in (0.,.23,.5,.91,1.):
                at=eta[:-1]+np.polynomial.polynomial.polyval(fraction,shift)
                assert np.allclose(np.polynomial.polynomial.polyval(fraction,poly),raw(at),rtol=3e-12,atol=1e-14)
            rates[key]=poly
        loading=controls(eta,data['loading'])
        return scale,eta,beta,rates,loading.min(axis=1),loading.max(axis=1)


def difference_cap(left,right):
    delta=left-right;degree=len(delta)-1
    coeff=np.zeros_like(delta)
    for index in range(degree+1):
        for power in range(index+1):
            coeff[index]+=comb(index,power)/comb(degree,power)*delta[power]
    return np.max(abs(coeff),axis=0)+1e-11*(np.sum(abs(left),axis=0)+np.sum(abs(right),axis=0))


def op_bounds(order,lower,upper):
    ops=operators(order);stream=ops[0];base=np.ones(len(stream));base[1:5]=[3,3,5,30]
    for row in range(5,len(base)):base[row]=-base[row-2]*stream[row-2,row]/stream[row,row-2]
    small=base.copy();large=base.copy();small[1]*=lower;large[1]*=upper
    answer=[]
    for raw in ops:
        matrix=abs(raw)*np.sqrt(large[:,None]/small[None,:])
        answer.append(float(np.sqrt(np.max(np.sum(matrix,axis=0))*np.max(np.sum(matrix,axis=1)))))
    return np.array(answer)


def main():
    guard()
    scale,cold_time,cold_rate,cold,cold_lo,cold_hi=medium_polys('cold')
    axis,heavy_time,heavy_rate,heavy,heavy_lo,heavy_hi=medium_polys('heavy')
    assert np.array_equal(scale,axis) and np.min(cold_lo)>0 and np.min(heavy_lo)>0
    with np.load(restart('cold')) as src:wave=float(src['k'][0])
    with np.load(restart('heavy')) as src:assert src['k'][0]==wave
    cold_drag=prod(cold_rate,cold['opacity']);heavy_drag=prod(heavy_rate,heavy['opacity'])
    gains=np.stack((wave*difference_cap(cold_rate,heavy_rate),difference_cap(cold_drag,heavy_drag),difference_cap(prod(heavy_drag,cold['loading']),prod(cold_drag,heavy['loading']))/(cold_lo*heavy_lo),difference_cap(prod(cold_rate,cold['hub']),prod(heavy_rate,heavy['hub']))))
    rows=[]
    for order in (128,192):
        for domain,use in [('entire_saved_medium',np.ones(len(scale)-1,dtype=bool)),('post_64',np.maximum(cold_time[1:],heavy_time[1:])>=64.),('backtest_from_57p6',np.maximum(cold_time[1:],heavy_time[1:])>=57.6)]:
            op=op_bounds(order,cold_lo[use].min(),heavy_hi[use].max())
            parts=op*np.sum(gains[:,use],axis=1);epsilon=float(np.sum(parts))
            assert np.isfinite(epsilon) and epsilon>=0
            rows.append(dict(order=order,domain=domain,stream=parts[0],drag=parts[1],recoil=parts[2],expansion=parts[3],medium_mismatch_bound=epsilon))
    table('paired-tail-medium-mismatch.csv',[row for row in rows if row['domain']!='backtest_from_57p6'])
    table('paired-tail-backtest-medium.csv',[row for row in rows if row['domain']=='backtest_from_57p6'])
    print(rows,flush=True)

if __name__=='__main__':main()
