from peak_inputs import *

def transpose_bands(bands):
    result=np.zeros_like(bands);count=bands.shape[-1]
    for offset in range(-5,6):
        col=slice(max(0,-offset),min(count,count-offset))
        row=slice(max(0,offset),min(count,count+offset))
        result[...,5-offset,row]=bands[...,5+offset,col]
    return result

def source_mesh(base,time,tag):
    start=max(base[0],time[0]);end=time[-1]
    left=max(0,int(np.searchsorted(base,start,'right'))-1);right=int(np.searchsorted(base,end))
    inner=time[(time>start)&(time<end)][::(2 if tag=='time' else 1)]
    axis=np.unique(np.r_[base[left:right+1],start,end,inner]);active=(axis[:-1]>=start)&(axis[1:]<=end)
    assert np.isclose(np.sum(np.diff(axis)[active]),end-start,rtol=0,atol=1e-12)
    return axis,right,active

def peak_observations(axis,eta,score):
    slots=np.searchsorted(eta,axis).clip(0,len(eta)-1)
    return np.where(axis==eta[slots],score[slots],0.)

def coefficients(axis,medium,wave):
    steps=np.diff(axis)
    at=axis[:-1,None]+steps[:,None]*[1/3,1];at[:,1]=axis[1:]
    hub,loading,opacity=medium(at).transpose(2,0,1)
    rates=steps[:,None,None]*np.stack([np.full_like(hub,wave),opacity,opacity/loading,hub],axis=-1)
    assert np.isfinite(rates).all() and np.all(steps>0)
    return rates,at

def backward(axis,eta,weights,medium,wave,transposed,right_state=None,snapshot=(),active=None):
    count=transposed.shape[-1]//2
    dual=np.zeros((count,2)) if right_state is None else right_state.copy()
    injections=peak_observations(axis,eta,weights)
    def inject(value):
        dual[0,0]+=value;dual[2,1]+=value
    if right_state is None:inject(injections[-1])
    right_saves=set(snapshot);saved={}
    if len(axis)-1 in right_saves:saved[len(axis)-1]=dual.copy()
    rates,at=coefficients(axis,medium,wave)
    kernel=np.zeros((len(rates),2,2,2)) if active is not None else None
    packed=np.zeros((2*count,2),order='F')
    for stop in range(len(rates),0,-48):
        begin=max(0,stop-48)
        if stop%1536<48:guard()
        mats=(rates[begin:stop].reshape(-1,8)@transposed.reshape(8,-1)).reshape(-1,11,2*count);mats[:,5]+=1
        for step in range(stop-1,begin-1,-1):
            if not dual.any() and injections[step]==0 and step not in right_saves:continue
            packed[1::2]=dual
            lifted=solve_banded((5,5),mats[step-begin],packed,check_finite=False)
            if active is not None and active[step]:
                dt=axis[step+1]-axis[step]
                kernel[step,0]=dt*4*(RAD.T@lifted[0:2])
                kernel[step,1]=dt*4*wave/3*(RAD.T@(lifted[2:4]+lifted[4:6]))
            dual=lifted[::2]+lifted[1::2]
            inject(injections[step])
            if step in right_saves:saved[step]=dual.copy()
    assert len(saved)==len(right_saves)
    return saved,at,kernel

def base_axis(grid,eta,sub):
    assert len(grid)==4097
    axis=CubicSpline(grid,eta,extrapolate=False)(np.linspace(grid[0],grid[-1],4096*sub+1))
    axis[::sub]=eta;assert (np.diff(axis)>0).all()
    return axis

def forward_control(axis,eta,score,medium,wave,bands,spline,start,end):
    rates,at=coefficients(axis,medium,wave);active=(axis[:-1]>=start)&(axis[1:]<=end)
    forcing=np.zeros((*at.shape,2),complex);forcing[active]=spline(at[active])
    size=bands.shape[-1]//2;state=np.zeros((size,4));out=np.zeros((2,4));packed=np.empty((2*size,4),order='F')
    observed=peak_observations(axis,eta,score);upper=np.flatnonzero(observed)[-1]
    for begin in range(0,upper,48):
        if begin%1536==0:guard()
        stop=min(upper,begin+48)
        mats=(rates[begin:stop].reshape(-1,8)@bands.reshape(8,-1)).reshape(-1,11,size*2);mats[:,5]+=1
        for step,mat in enumerate(mats,begin):
            packed[::2]=state;packed[1::2]=state
            if active[step]:
                weighted=(axis[step+1]-axis[step])*(RAD@forcing[step])
                for offset,factor,channel in ((0,4,0),(2,4*wave/3,1),(4,4*wave/3,1)):
                    term=weighted[:,channel]*factor
                    packed[offset:offset+2,channel*2]+=term.real
                    packed[offset:offset+2,channel*2+1]+=term.imag
            state=solve_banded((5,5),mat,packed,check_finite=False)[1::2]
            out+=observed[step+1]*state[[0,2]]
    return (out[:,::2]+1j*out[:,1::2]).T

def run(model):
    guard();grid,eta,medium,peak,score=measure(model)
    collection={};arrays={};witness={};library={}
    for tag,(order,sub,stride) in CONFIG.items():
        packets=[source(index,model,tag) for index in range(6)]
        wave=packets[0][2];assert all(row[2]==wave for row in packets)
        base=base_axis(grid,eta,sub)
        locations=[source_mesh(base,time,tag) for time,_,_ in packets]
        bands=transfer.stages(order);transposed=transpose_bands(bands)
        right_indices=[item[1] for item in locations]
        if (order,sub) not in library:
            library[order,sub]=backward(base,eta,score,medium,wave,transposed,snapshot=right_indices)[0]
        right=library[order,sub];outputs=[]
        for index,((time,field,_),(axis,edge,active)) in enumerate(zip(packets,locations)):
            _,at,kernel=backward(axis,eta,score,medium,wave,transposed,right[edge],active=active)
            spline=CubicSpline(time[::stride],field[::stride],axis=0,extrapolate=False)
            samples=spline(at[active])
            value=np.einsum('nctj,ntc->cj',kernel[active],samples)
            assert value.shape==(2,2) and np.isfinite(value).all()
            outputs.append(value)
            if tag=='primary':
                arrays[f'eta_{index}']=at[active]
                arrays[f'gains_{index}']=kernel[active]
                if index==1:
                    full=np.unique(np.r_[base,axis])
                    witness['forward_second']=forward_control(full,eta,score,medium,wave,bands,spline,max(eta[0],time[0]),time[-1])
        collection[tag]=np.stack(outputs);print(model,tag,'six projected',flush=True)
    stream=io.BytesIO()
    np.savez_compressed(stream,**collection,**witness,peak=peak,k=wave)
    save(f'projection-{model}.npz',stream.getvalue())
    stream=io.BytesIO()
    np.savez_compressed(stream,**arrays)
    save(f'primary-kernels-{model}.npz',stream.getvalue())
    record(f'projection-inputs-{model}.json',dict(saved=old.PROVENANCE,operator_path=transfer.__file__,operator_sha256=sha(Path(transfer.__file__))))

if __name__=='__main__':
    for model in MODELS:run(model)
