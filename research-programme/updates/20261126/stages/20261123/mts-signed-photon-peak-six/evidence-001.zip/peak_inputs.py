import csv
import hashlib
import io
import json
import sys
from pathlib import Path

HERE=Path(__file__).resolve().parent
PREV=HERE.parent/'mts-paired-matter-envelope-64-20261123'
PREV_SHA='a643ff5e61d0e42d68c32fc2dd6714ed8dfefa238536c5658796caf9af1c522a'

def sha(path):
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()

assert sha(PREV/'seal.json')==PREV_SHA
assert sha(PREV/'paired_inputs.py')==json.loads((PREV/'seal.json').read_bytes())['files']['paired_inputs.py']
sys.path.insert(0,str(PREV))
import paired_inputs as old
from paired_inputs import MODELS, STAGES, TAGS, ENDPOINTS, PARENT, pin, medium_file
import numpy as np
from scipy.interpolate import CubicSpline, BSpline, make_interp_spline
from scipy.linalg import solve_banded
from scipy.sparse.linalg import spsolve
import transfer

CONFIG={'primary':(192,4,1),'angle':(128,4,1),'time':(192,2,1),'sampling':(192,4,2),'materialstep':(192,4,1)}
RAD=np.array([[5/12,-1/12],[3/4,1/4]])
TOL=.005

def guard():
    old.guard()
    assert not (HERE/'STOP-REQUESTED').exists()

def save(name,data):
    guard();path=HERE/name
    if path.exists():assert path.read_bytes()==data,name
    else:
        with path.open('xb') as stream:stream.write(data)

def record(name,payload):
    save(name,(json.dumps(payload,sort_keys=True,indent=2,allow_nan=False)+'\n').encode())

def table(name,rows):
    stream=io.StringIO();writer=csv.DictWriter(stream,rows[0].keys(),lineterminator='\n')
    writer.writeheader();writer.writerows(rows);save(name,stream.getvalue().encode())

def measure(model):
    with np.load(medium_file(f'medium-{model}.npz')) as raw:
        grid=raw['scale'];eta=raw['eta'];rates=np.column_stack([raw[key] for key in ('hub','loading','opacity')])
    peak=json.loads(medium_file('score.json').read_bytes())['visibility']['cold']['peak_scale']
    knots=make_interp_spline(grid,np.zeros(len(grid))).t
    collocation=BSpline.design_matrix(grid,knots,3).tocsc()
    sample=BSpline.design_matrix([peak],knots,3).toarray()[0]
    weights=spsolve(collocation.T.tocsc(),sample)
    assert np.isfinite(weights).all() and abs(weights.sum()-1)<1e-13
    assert abs(weights@grid-peak)<1e-15
    return grid,eta,CubicSpline(eta,rates,extrapolate=False),peak,weights

def source(index,model,tag):
    folder=STAGES[index];suffix=TAGS[index]
    with np.load(pin(folder,f'particular-{model}-{suffix}.npz')) as raw:
        time=raw['eta'];field=np.column_stack([raw['phi_dot'],raw['psi']]);wave=float(raw['k'][0])
        scales=raw['a']
    if tag=='materialstep':
        with np.load(pin(folder,f'larger-step-{model}.npz')) as other:
            assert np.allclose(other['a'],scales[::2],rtol=1e-12,atol=0)
            time=time[::2];field=np.column_stack([other['pd'],other['psi']])
    start=25.6 if index==0 else ENDPOINTS[index-1]
    assert time[0]==start and time[-1]==ENDPOINTS[index] and np.isfinite(field).all()
    return time,field,wave

def readout(index,model,tag):
    return pin(STAGES[index],f'transfer-{model}-{tag}-{TAGS[index]}.npz')
