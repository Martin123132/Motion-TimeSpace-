from peak_inputs import *
from check import contents, norm, relative

def main():
    index=3;variants={};interference=[]
    for model in MODELS:
        with np.load(HERE/f'primary-kernels-{model}.npz') as packet:
            at=packet[f'eta_{index}'];kernel=packet[f'gains_{index}']
        with np.load(HERE/f'projection-{model}.npz') as saved:
            check={tag:saved[tag][index] for tag in ('primary','sampling','materialstep')}
        time,field,_=source(index,model,'primary')
        coarse_time,coarse_field,_=source(index,model,'materialstep')
        assert np.array_equal(time[::2],coarse_time)
        states=[]
        for knots,values in ((time,field),(coarse_time,field[::2]),(coarse_time,coarse_field)):
            samples=CubicSpline(knots,values,axis=0,extrapolate=False)(at)
            states.append(np.einsum('nctj,ntc->cj',kernel,samples))
        assert relative(states[0],check['primary'])<1e-12 and relative(states[1],check['sampling'])<1e-12
        variants[model]=np.stack([*states,check['materialstep']])
    variants['MTS-minus-baseline']=variants['heavy']-variants['cold'];rows=[]
    for model,states in variants.items():
        diffs=np.diff(states,axis=0);total=states[-1]-states[0]
        assert relative(diffs.sum(axis=0),total)<1e-10
        for src,channel in enumerate(('energy','momentum')):
            for metric,change in zip(('sampling only','material history at same knots and photon grid','photon integration mesh only','total'),(*diffs,total)):
                rows.append(dict(model=model,source=channel,change=metric,over_primary_channel=norm(change[src])/norm(states[0,src]),over_primary_full_block=norm(change[src])/norm(states[0].sum(axis=0)),**contents(change[src],'shift')))
    table('fourth-block-step-isolation.csv',rows)
    with np.load(HERE/'projection-cold.npz') as cold,np.load(HERE/'projection-heavy.npz') as heavy:
        for model,blocks in (('cold',cold['primary']),('heavy',heavy['primary']),('MTS-minus-baseline',heavy['primary']-cold['primary'])):
            for src,channel in enumerate(('energy','momentum')):
                vec=blocks[:,src];apart=np.linalg.norm(vec,axis=1).sum()
                interference.append(dict(model=model,source=channel,net_over_summed_block_magnitudes=norm(vec.sum(axis=0))/apart))
    table('within-channel-cancellation.csv',interference)

if __name__=='__main__':main()
