from peak_inputs import *

def norm(value):return float(np.linalg.norm(value))

def relative(value,reference):
    denominator=norm(reference)
    assert denominator>0
    return norm(value-reference)/denominator

def contents(value,prefix):
    return {prefix+'_density_real':value[0].real,prefix+'_density_imag':value[0].imag,prefix+'_current_real':value[1].real,prefix+'_current_imag':value[1].imag}

def main():
    guard();pred={};reference={};initial={};base={};whole={};witness={};interp=[];manifest={}
    for model in MODELS:
        grid,eta,medium,peak,weights=measure(model)
        with np.load(HERE/f'projection-{model}.npz') as packet:
            assert packet['peak']==peak
            for tag in CONFIG:pred[model,tag]=packet[tag]
            witness[model]=packet['forward_second']
        for tag in CONFIG:
            history=[]
            for index in range(6):
                with np.load(readout(index,model,tag)) as archive:
                    assert np.array_equal(archive['scale'],grid)
                    block=archive['block']
                    truth=CubicSpline(grid,block,axis=0,extrapolate=False)(peak)
                    interp.append(relative(weights@block,truth))
                    history.append(truth)
                    if tag=='primary':
                        if index==0:base[model]=CubicSpline(grid,archive['prior_sum'],axis=0)(peak);initial[model]=archive['old_free'][0]
                        if index==5:whole[model]=CubicSpline(grid,archive['new_partial'],axis=0)(peak)
            reference[model,tag]=np.stack(history)
    label='MTS-minus-baseline'
    for target in (pred,reference):
        for tag in CONFIG:target[label,tag]=target['heavy',tag]-target['cold',tag]
    for target in (initial,base,whole,witness):target[label]=target['heavy']-target['cold']
    comparisons=[];pairs=[];cross=[];forward=[];complete=[];fractions={}
    for model in (*MODELS,label):
        factors=pred[model,'primary'];launch=norm(initial[model])
        for tag in CONFIG:
            calculated=pred[model,tag];known=reference[model,tag]
            for index,mark in enumerate((*ENDPOINTS,'all-six')):
                response=calculated[index] if index<6 else calculated.sum(axis=0)
                ref=known[index] if index<6 else known.sum(axis=0)
                total=response.sum(axis=0);err=relative(total,ref)
                comps=abs((total-ref)/ref);assert np.isfinite(comps).all()
                comparisons.append(dict(model=model,setting=tag,end_eta=mark,signed_vector_error=err,density_error=comps[0],current_error=comps[1],passed=max(err,*comps)<=TOL))
                if tag!='primary':
                    nominal=factors[index] if index<6 else factors.sum(axis=0)
                    for channel,values,nom in zip(('energy forcing','momentum forcing','sum'),(*response,total),(*nominal,nominal.sum(axis=0))):
                        diff=relative(values,nom)
                        cross.append(dict(model=model,setting=tag,end_eta=mark,source=channel,relative_change=diff,passed=diff<=TOL))
                if tag=='primary':
                    energy,momentum=response;size=norm(total)
                    projection=float(np.vdot(energy,total).real/size**2)
                    retained=size/(norm(energy)+norm(momentum))
                    alignment=float(np.vdot(energy,momentum).real/(norm(energy)*norm(momentum)))
                    assert abs(alignment)<=1+1e-12 and 0<retained<=1+1e-12
                    pairs.append(dict(model=model,end_eta=mark,energy_over_launch=norm(energy)/launch,momentum_over_launch=norm(momentum)/launch,net_over_launch=size/launch,net_over_separate=retained,alignment=alignment,energy_projection_on_net=projection,momentum_projection_on_net=1-projection,**contents(energy,'energy_forcing'),**contents(momentum,'momentum_forcing'),**contents(ref,'archived_net')))
                    if index==6:
                        all_magnitudes=np.linalg.norm(factors,axis=2).sum()
                        fractions[model]=dict(energy=norm(energy)/launch,momentum=norm(momentum)/launch,net=size/launch,retained=retained,alignment=alignment,retained_over_twelve=size/all_magnitudes)
        net=factors.sum(axis=(0,1))
        for name,val,ref in [('six intervals only',net,whole[model]-base[model]),('with pre-existing photon history',net+base[model],whole[model])]:
            error=relative(val,ref)
            complete.append(dict(model=model,comparison=name,error=error,passed=error<=TOL,net_over_launch=norm(ref)/launch))
        for channel,calc,ref in zip(('energy forcing','momentum forcing'),factors[1],witness[model]):
            error=relative(calc,ref)
            forward.append(dict(model=model,source=channel,start=32.,end=38.4,relative_error=error,passed=error<=TOL))
    table('peak-comparisons.csv',comparisons);table('signed-contributions.csv',pairs)
    table('channel-sensitivity.csv',cross);table('independent-split.csv',forward);table('cumulative-readout.csv',complete)
    max_interp=max(interp);assert max_interp<1e-10
    summary=dict(tolerance=TOL,archived_peak_tests=len(comparisons),archived_peak_passes=sum(bool(r['passed']) for r in comparisons),
        primary_passes=sum(bool(r['passed']) for r in comparisons if r['setting']=='primary'),worst_archived_vector_error=max(r['signed_vector_error'] for r in comparisons),
        worst_archived_component_error=float(max(max(r['density_error'],r['current_error']) for r in comparisons)),interpolation_duality_error=max_interp,
        forward_split_max=max(r['relative_error'] for r in forward),forward_split_passes=sum(bool(r['passed']) for r in forward),
        cumulative_error=max(r['error'] for r in complete),cumulative_passes=sum(bool(r['passed']) for r in complete),
        sensitivity_passes=sum(bool(r['passed']) for r in cross),sensitivity_tests=len(cross),worst_sensitivity=max(r['relative_change'] for r in cross),six=fractions,
        new_matter_intervals=0,last_source_eta=64.,new_observations=False)
    record('outcome.json',summary);record('reference-inputs.json',old.PROVENANCE)
    print(json.dumps(summary,indent=2),flush=True)
    assert summary['archived_peak_passes']==105 and summary['forward_split_passes']==6 and summary['cumulative_passes']==6

if __name__=='__main__':main()
