import re
from peak_inputs import *

def rows(file):
    with (HERE/file).open() as stream:return list(csv.DictReader(stream))

def main():
    guard();origin={}
    for model in MODELS:
        packet=json.loads((HERE/f'projection-inputs-{model}.json').read_bytes())
        assert sha(Path(packet['operator_path']))==packet['operator_sha256']
        origin.update(packet['saved'])
        with np.load(HERE/f'primary-kernels-{model}.npz') as kernels:
            for index,end in enumerate(ENDPOINTS):
                at=kernels[f'eta_{index}'];gains=kernels[f'gains_{index}']
                start=25.6 if index==0 else ENDPOINTS[index-1]
                assert at.ndim==2 and at.shape[1]==2 and gains.shape==(len(at),2,2,2)
                assert at.min()>=start and at.max()==end and np.isfinite(gains).all()
    origin.update(json.loads((HERE/'reference-inputs.json').read_bytes()))
    for index,folder in enumerate(STAGES):
        for model in MODELS:
            for name in (f'particular-{model}-{TAGS[index]}.npz',f'larger-step-{model}.npz',*(f'transfer-{model}-{tag}-{TAGS[index]}.npz' for tag in CONFIG)):
                assert str(folder/name) in origin
    assert all(sha(Path(name))==digest for name,digest in origin.items())
    for link in re.findall(r'\]\(([^)]+)\)',(HERE/'RESULTS.md').read_text(encoding='utf-8')):assert (HERE/link).is_file()
    assert len(rows('peak-comparisons.csv'))==105 and all(row['passed']=='True' for row in rows('peak-comparisons.csv'))
    outcomes=rows('channel-sensitivity.csv');failed=[row for row in outcomes if row['passed']=='False']
    assert len(outcomes)==252 and len(failed)==1 and (failed[0]['model'],failed[0]['setting'],failed[0]['source'],failed[0]['end_eta'])==('MTS-minus-baseline','materialstep','energy forcing','51.2')
    assert all((float(row['relative_change'])<=TOL)==(row['passed']=='True') for row in outcomes)
    assert all(row['passed']=='True' for name in ('cumulative-readout.csv','independent-split.csv') for row in rows(name))
    assert not any(path.is_dir() for path in HERE.iterdir())
    files={path.name:sha(path) for path in sorted(HERE.iterdir()) if path.name!='seal.json'}
    record('seal.json',dict(files=files,parent=PREV_SHA,verified_external_files=len(origin),last_material_eta=64.,new_intervals=0,sensitivity_failures=1))
    print('Verified:',len(origin),'saved inputs;',len(files),'local artifacts. Seal:',sha(HERE/'seal.json'))

if __name__=='__main__':main()
