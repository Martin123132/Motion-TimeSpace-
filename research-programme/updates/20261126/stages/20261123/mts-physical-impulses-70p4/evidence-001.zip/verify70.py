import csv
import hashlib
import json
import math
import sys
from pathlib import Path

import numpy as np

ROOT=Path(__file__).resolve().parent
OLD=ROOT.parent/'mts-particular-gravity-64-tail-20261123'
BOUND=ROOT.parent/'mts-64-to-peak-matter-bound-20261123'
MID=ROOT.parent/'mts-particular-gravity-57p6-20261123'
LIMIT=.005

def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream,'sha256').hexdigest()

def read(path):
    return json.loads(path.read_bytes())

def table(name,home=ROOT):
    with (home/name).open(newline='',encoding='utf-8') as stream:
        return list(csv.DictReader(stream))

def number(row,key):
    return complex(float(row[key+'_re']),float(row[key+'_im']))

def stats(name,expected):
    rows=table(name)
    assert len(rows)==expected
    errors=[float(row['relative_error']) for row in rows]
    assert all(math.isfinite(value) and value>=0 for value in errors)
    for row,error in zip(rows,errors):
        if 'passed' in row: assert (row['passed']=='True')==(error<=LIMIT)
    return dict(tested=len(rows),passed=sum(value<=LIMIT for value in errors),worst=max(errors))

def save(name,data):
    path=ROOT/name
    encoded=(json.dumps(data,sort_keys=True,indent=2,allow_nan=False)+'\n').encode()
    if path.exists():
        assert path.read_bytes()==encoded,name
    else:
        with path.open('xb') as stream:stream.write(encoded)

def verify():
    anchors={OLD:'b512fa19c739b9b912b86b80be0a7e8af67047a63be02e5e8ba3b5a0ac36f19d',BOUND:'34527715cc80011cc93b6c92b208e075c506cb468a6dfdedc6ba7c50076f6903',MID:'af98172b9e9d0f516fdb80bab2c7be5972bbd70bfadbe3c6c3e93a68489f1002'}
    for folder,pin in anchors.items(): assert sha(folder/'seal.json')==pin
    assert not (ROOT/'STOP-REQUESTED').exists()
    def pinned(folder,name):
        path=folder/name
        assert sha(path)==read(folder/'seal.json')['files'][name],name
        return path
    pinned(BOUND,'required-signed-impulses.csv')
    pinned(BOUND,'transported-cut.csv')
    nodes=np.arange(-52,25)
    all_receipts=[]
    for model in ('cold','heavy'):
        common=ROOT/f'common-{model}.npz'
        with np.load(common) as packet:
            assert np.array_equal(packet['eta'][[0,-1]],[64,70.4]) and packet['S'].shape==(69,129)
            assert all(np.isfinite(packet[key]).all() for key in ('end','S','Sw'))
        expected={}
        for node in nodes:
            name=f'micro-{model}-{node}.npz'
            expected[name]=sha(ROOT/name)
            with np.load(ROOT/name) as packet:
                assert packet['id']==node and packet['q']==2.**(node/4)
                assert packet['source'].shape==(69,129) and np.isfinite(packet['source']).all() and np.isfinite(packet['end']).all()
                assert 0<=packet['join']<=LIMIT
                if node in (-52,0,24):assert 0<=packet['independent']<1e-10
        for mode,out,src,tag,start,stop in [('control64',ROOT/'control64',MID,4,57.6,64),('primary',ROOT,OLD,8,64,70.4),('control',ROOT,ROOT/'control64',4,64,70.4)]:
            name=f'particular-{model}-p{tag}.npz'
            source=src/name if src==ROOT/'control64' else pinned(src,name)
            report=read(out/f'metric-{model}-p{tag}.json')
            assert report['passed'] and report['mode']==mode and report['model']==model and report['parent']==sha(source)
            assert set(report['micro'])==set(expected)
            if mode!='control64':assert report['micro']==expected
            else:
                oldfiles=read(OLD/'seal.json')['files']
                assert all(oldfiles[path]==key for path,key in report['micro'].items())
            assert max(report[key] for key in ('seam_metric','seam_stress','time_metric','slope_error','incident_seam'))<=LIMIT
            assert report['quadrature']<1e-12 and report['incident_control']<1e-10
            with np.load(out/name) as restart:
                assert np.array_equal(restart['q'],2.**(nodes/4)) and restart['lagEnd'].shape[0]==77
                assert len(restart['eta'])==(8193 if tag==8 else 4097) and np.array_equal(restart['eta'][[0,-1]],[start,stop])
                for key in ('state','shape','lagEnd','phi','psi','phi_dot','stress'):assert np.isfinite(restart[key]).all()
            all_receipts.append(out.name+'/'+name)
    physics=table('physical-impulses.csv');assert len(physics)==12
    assert len({(row['mode'],row['target'],row['model']) for row in physics})==12
    intervals=[row for row in physics if row['target']=='priority midpoint' and row['model']=='paired']
    assert len(intervals)==2
    centers={row['mode']:row for row in intervals}
    prior=next(row for row in table('transported-cut.csv',BOUND) if row['model']=='paired')
    targets=table('required-signed-impulses.csv',BOUND)
    band={}
    for index,key in enumerate(('C','Y')):
        primary=centers['primary'];control=centers['control'];radius=float(targets[index]['radius'])
        remaining=number(primary,'remaining_center_'+key);alt=number(control,'remaining_center_'+key)
        old=number(primary,'carried_'+key);published=number(prior,'from_cut_'+key)
        carry_offset=abs(old-published)/radius
        assert carry_offset<=LIMIT
        band[key]=dict(radius=radius,old_carry_reproduction_over_radius=carry_offset,remaining_center_displacement_over_radius=abs(remaining-alt)/radius,remaining_center_over_radius=abs(remaining)/radius,remaining_over_launch=abs(remaining)/abs(old))
    checks={key:stats(name,count) for key,name,count in [('trajectories','physical-trajectory-checks.csv',27),('control64','rebuilt-control-start.csv',6),('impulse_identities','impulse-internal-checks.csv',108),('impulse_timestep','impulse-time-step.csv',36)]}
    seams=table('seam-checks.csv');assert len(seams)==12
    for row in seams:assert all(math.isfinite(float(row[col])) for col in ('C_relative_jump','Y_relative_jump','source_identity'))
    independent=table('independent-end-centers.csv')
    production=table('remaining-production.csv')
    assert len(independent)==6 and len(production)==2
    assert all(float(row['Y_error_radius'])>=0 and float(row['T_bound_radius'])>0 for row in independent)
    for row in independent:
        if row['model']=='paired':
            assert float(row['C_difference'])<=LIMIT*band['C']['radius']
            assert float(row['Y_error_over_paired_radius'])<=LIMIT
    result=dict(acceptance_tolerance=LIMIT,checks=checks,paired_peak_budget=band,restarts=all_receipts,source_packets=154,peak_matter_evaluated=False,source_coverage_end_mpc=70.4,peak_time_mpc=273.3323213627907,prior_seals={folder.name:key for folder,key in anchors.items()})
    save('verified.json',result)
    defects=table('peak-rate-defect.csv')
    changes=table('peak-sensitivity-attribution.csv')
    assert len(defects)==6 and {(row['mode'],row['model']) for row in defects}=={(mode,model) for mode in ('primary','control') for model in ('cold','heavy','paired')}
    assert len(changes)==8
    max_unexplained=max(float(row['unexplained_over_paired_Y_radius']) for row in defects)
    max_quadrature=max(float(row['quadrature_change_over_paired_Y_radius']) for row in defects)
    assert max(max_unexplained,max_quadrature)<LIMIT
    total=next(float(row['projection_on_total_over_radius']) for row in changes if row['term']=='end')
    summed=sum(float(row['projection_on_total_over_radius']) for row in changes if row['term']!='end')
    assert abs(total-summed)<LIMIT and abs(total-band['Y']['remaining_center_displacement_over_radius'])<LIMIT
    save('defect-verified.json',dict(unchanged_relative_tolerance=LIMIT,unexplained_max_over_paired_radius=max_unexplained,quadrature_change_max_over_paired_radius=max_quadrature,paired_lapse_control_within_one_term_radius=(total<=1),paired_lapse_control_radius_units=total))
    if '--seal' in sys.argv:
        assert (ROOT/'RESULTS.md').is_file() and not list(ROOT.rglob('__pycache__'))
        save('seal.json',dict(files={p.relative_to(ROOT).as_posix():sha(p) for p in sorted(ROOT.rglob('*')) if p.is_file() and p.name!='seal.json'},prior_seals=result['prior_seals']))
    print(json.dumps({'checks':checks,'budget':band},indent=2))

if __name__=='__main__':verify()
