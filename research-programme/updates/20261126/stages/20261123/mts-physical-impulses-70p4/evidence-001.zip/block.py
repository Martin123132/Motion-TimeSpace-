from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parent
PRE=ROOT.parent/'mts-photon-gravity-drive-20261123'
BASE=ROOT.parent/'mts-particular-gravity-64-tail-20261123'
BOUND=ROOT.parent/'mts-64-to-peak-matter-bound-20261123'
MID=ROOT.parent/'mts-particular-gravity-57p6-20261123'
FOURTH=ROOT.parent/'mts-particular-gravity-51p2-20261123'
THIRD=ROOT.parent/'mts-particular-gravity-44p8-20261123'
SECOND=ROOT.parent/'mts-particular-gravity-38p4-20261123'
ANCESTOR=ROOT.parent/'mts-particular-gravity-32-20261123'
sys.path.insert(0,str(PRE))
import common_drive as inherited
from workspace import *
import common_drive
import io,csv,json,hashlib

OLD=HOME
def guard():
    inherited.guard()
    assert all(not (d/'STOP-REQUESTED').exists() for d in (MID,BOUND,ROOT.parent/'mts-peak-tail-weights-20261123',ROOT.parent/'mts-paired-matter-envelope-64-20261123',ROOT.parent/'mts-signed-photon-peak-six-20261123'))
    assert not (FOURTH/'STOP-REQUESTED').exists()
    assert not (THIRD/'STOP-REQUESTED').exists()
    assert not (ANCESTOR/'STOP-REQUESTED').exists()
    assert not (BASE/'STOP-REQUESTED').exists() and not (SECOND/'STOP-REQUESTED').exists()
    assert not (ROOT/'STOP-REQUESTED').exists()
def save(name,raw):
    guard();path=ROOT/name
    if path.exists():assert digest(path)==hashlib.sha256(raw).hexdigest(),name
    else:
        with path.open('xb') as stream:stream.write(raw)
def pack(name,**fields):
    stream=io.BytesIO();np.savez_compressed(stream,**fields);save(name,stream.getvalue())
def table(name,rows):
    stream=io.StringIO();out=csv.DictWriter(stream,rows[0],lineterminator='\n');out.writeheader();out.writerows(rows);save(name,stream.getvalue().encode())
def record(name,body):save(name,(json.dumps(body,indent=2,sort_keys=True)+'\n').encode())
def predecessor(name):
    guard()
    seal=PRE/'seal.json';assert digest(seal)=='d65afa72b931c22b6462602afca73d745cb042db30e0e4e6cd206195f0c5a80e'
    path=PRE/name;assert digest(path)==json.loads(seal.read_bytes())['files'][name];return path
def previous(name):
    guard()
    seal=BASE/'seal.json'
    assert digest(seal)=='b512fa19c739b9b912b86b80be0a7e8af67047a63be02e5e8ba3b5a0ac36f19d'
    path=BASE/name
    assert digest(path)==json.loads(seal.read_bytes())['files'][name],name
    return path
def restart(model):return previous(f'particular-{model}-p8.npz')

def ancestor(name):
    guard();seal=ANCESTOR/'seal.json';assert digest(seal)=='f0038e184106d6885849758e773a129936f71fc0767c020620dd71b2a31676c9'
    path=ANCESTOR/name;assert digest(path)==json.loads(seal.read_bytes())['files'][name]
    return path

def flight_library():return ancestor('flight32.dll')

def second(name):
    guard();seal=SECOND/'seal.json';assert digest(seal)=='d543614c05ca304b42944772f68703487c99b4a04e1ed5730dcf3069bd9f38ca'
    path=SECOND/name;assert digest(path)==json.loads(seal.read_bytes())['files'][name]
    return path

def third(name):
    guard();seal=THIRD/'seal.json';assert digest(seal)=='762ccf727b57fc79352f518744c1f239fd71041f4b931eb5963134d672c16625'
    path=THIRD/name;assert digest(path)==json.loads(seal.read_bytes())['files'][name]
    return path

def unused_sixth_block_transfer_paths(model,tag):
    coarse=f'transfer-{model}-{tag}-p2.npz';fine=f'transfer-{model}-{tag}-p4.npz'
    return (ancestor(coarse),second(coarse),third(fine),fourth(fine),previous(fine),ROOT/fine.replace('-p4','-p8'))

def fourth(name):
    guard();seal=FOURTH/'seal.json';assert digest(seal)=='5f3b5923c1b81f41478a90d38c635d1185cd4bc70146c249d0148bd7cecc429c'
    path=FOURTH/name;assert digest(path)==json.loads(seal.read_bytes())['files'][name]
    return path
