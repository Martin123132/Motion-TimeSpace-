import csv
from scipy.integrate import simpson
from impulse70 import CASES, MODELS, ROOT, PRE, Medium, Packet, np, guard, kernel, parts, write, z

def records(path):
    with path.open(newline='') as stream:return list(csv.DictReader(stream))

def check():
    guard();med=Medium()
    budgets=records(PRE/'required-signed-impulses.csv')
    radius=float(budgets[1]['radius'])
    work=records(ROOT/'physical-impulses.csv')
    end=min(med.root(model,70.4) for model in MODELS)
    rows=[];contributions={}
    for mode in ('primary','control'):
        old={model:Packet(model,mode,True) for model in MODELS}
        new={model:Packet(model,mode,False) for model in MODELS}
        for resolution in (8193,16385):
            integrated={name:0j for name in CASES}
            for lower,upper,fields,size in ((med.a0,med.cuts['cold'],dict(cold=old['cold'],heavy=new['heavy']),33),(med.cuts['cold'],end,new,resolution)):
                scale=np.linspace(lower,upper,size);clock=med.native('heavy',scale)
                residual={}
                for model,packet in fields.items():
                    time,ratio,_,_=med.coord(scale,model)
                    time=np.clip(time,packet.time[0],packet.time[-1])
                    residual[model]=ratio*(packet.curves['phi'](time,1)-packet.curves['pd'](time))
                residual['paired']=residual['heavy']-residual['cold']
                for name in CASES:
                    model='heavy' if name=='paired' else name
                    _,gain,_=kernel(med,model,scale,med.am)
                    integrated[name]+=simpson(gain*residual[name],x=clock)
            if resolution==8193:
                coarse=integrated
                continue
            for name in CASES:
                item=next(row for row in work if (row['mode'],row['model'],row['target'])==(mode,name,'priority midpoint'))
                carried=z(item,'carried_Y');impulse=z(item,'I_Y');seam=z(item,'seam_Y');endpoint=-z(item,'remaining_center_Y')
                defect=endpoint-carried-impulse-seam
                unexplained=defect-integrated[name]
                rows.append(dict(mode=mode,model=name,**parts('endpoint_minus_balance',defect),**parts('integrated_phi_rate_defect',integrated[name]),**parts('unexplained',unexplained),defect_over_paired_Y_radius=abs(defect)/radius,unexplained_over_paired_Y_radius=abs(unexplained)/radius,quadrature_change_over_paired_Y_radius=abs(integrated[name]-coarse[name])/radius))
                if name=='paired':contributions[mode]=dict(start=carried,current_work=z(item,'I_Y_current'),shear_work=z(item,'I_Y_shear'),clock_work=z(item,'I_Y_clock'),seam=seam,rate_defect=integrated[name],other=unexplained,end=endpoint)
    write('peak-rate-defect.csv',rows)
    shift={term:val-contributions['primary'][term] for term,val in contributions['control'].items()}
    final=shift['end']
    assert abs(sum(val for term,val in shift.items() if term!='end')-final)<1e-8*radius
    write('peak-sensitivity-attribution.csv',[dict(term=term,**parts('control_minus_primary',value),modulus_over_radius=abs(value)/radius,projection_on_total_over_radius=(value*final.conjugate()).real/abs(final)/radius) for term,value in shift.items()])
    print('diagnostic: paired parts in units of one-term tolerance:',[(row['mode'],row['defect_over_paired_Y_radius'], row['unexplained_over_paired_Y_radius']) for row in rows if row['model']=='paired'],flush=True)

if __name__=='__main__':check()
