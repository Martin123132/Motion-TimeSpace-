from impulse70 import *

def check():
    guard();med=Medium();picked={};inputs={};rows=[];starts=[]
    for mode in ('primary','control'):
        cases={model:Packet(model,mode,False) for model in MODELS}
        start,end=med.both({m:f.time for m,f in cases.items()});scales=np.linspace(start,end,8193)
        rows_by_model=history.branches(med,cases,scales);picked[mode]={}
        for name,values in rows_by_model.items():
            picked[mode][name]=np.array([values[key] for key in ('C','Y','refCp','refYp')])
        fields={}
        for model,case in cases.items():
            sub=case.path
            with np.load(sub) as raw:
                a=raw['a'];values=np.stack([raw[k] for k in ('phi','psi','phi_dot','differentiated')],axis=1)
            fields[model]=(a,values)
            priorcase=Packet(model,mode,True)
            with np.load(priorcase.path) as old:
                mismatch={}
                if mode=='control':
                    with np.load(history.pin(PARENT,'larger-step-'+model+'.npz')) as ref:
                        for key,other in (('phi','phi'),('psi','psi'),('phi_dot','pd')):
                            error=relative(old[key][-1],ref[other][-1])
                            starts.append(dict(model=model,test='rebuild vs saved fixed-stress alternate at 64: '+key,relative_error=error,passed=error<=.005))
            receipt=json.loads(sub.with_name('metric-'+model+('-p8.json' if mode=='primary' else '-p4.json')).read_bytes())
            assert receipt['parent']==digest(priorcase.path)
        grid=np.linspace(max(a[0] for a,v in fields.values()),min(a[-1] for a,v in fields.values()),2049)
        inputs[mode]={m:CubicSpline(a,v,axis=0)(grid) for m,(a,v) in fields.items()}
        inputs[mode]['paired']=inputs[mode]['heavy']-inputs[mode]['cold']
        if mode=='primary':nominal_grid=grid
        else:assert np.allclose(nominal_grid,grid,rtol=1e-12,atol=0)
        for name,arr in inputs[mode].items():
            err=float(np.max(abs(arr[:,2]-arr[:,3]))/np.max(abs(arr[:,2])))
            rows.append(dict(model=name,test=mode+': independent curvature derivative',relative_error=err,passed=err<=.005))
    for name in CASES:
        for label,a,b in zip(('phi','psi','phi_dot'),inputs['primary'][name].T[:3],inputs['control'][name].T[:3]):
            err=float(np.max(abs(a-b))/np.max(abs(a)))
            rows.append(dict(model=name,test='gravity step: '+label,relative_error=err,passed=err<=.005))
        for label,a,b in zip(('C','Y','dC/ds','dY/ds'),picked['primary'][name],picked['control'][name]):
            err=float(np.max(abs(a-b))/np.max(abs(a)))
            rows.append(dict(model=name,test='source step: '+label,relative_error=err,passed=err<=.005))
    write('physical-trajectory-checks.csv',rows);write('rebuilt-control-start.csv',starts)
    print('trajectory failures:',[r for r in rows+starts if not r['passed']],flush=True)
if __name__=='__main__':check()
