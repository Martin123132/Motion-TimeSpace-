from block import *
from block import previous as last_block
from transfer import stages,solve_banded
from scipy.optimize import brentq

CONFIG={'primary':(192,4,1),'time':(192,2,1),'angle':(128,4,1),'sampling':(192,4,2),'materialstep':(192,4,1)}
def run(model,tag,suffix=''):
    guard();assert json.loads((ROOT/'pre-transport-gate.json').read_bytes())['passed'];order,sub,stride=CONFIG[tag]
    certificate=json.loads((ROOT/f'metric-{model}{suffix}.json').read_bytes())
    assert certificate['passed']
    with np.load(ROOT/f'particular-{model}{suffix}.npz') as raw:
        times=raw['eta'];field=np.column_stack([raw['phi_dot'],raw['psi'],raw['phi']]);k=raw['k'][0]
        if tag=='materialstep':
            with np.load(ROOT/f'larger-step-{model}.npz') as alt:
                assert np.allclose(alt['a'],raw['a'][::2],rtol=1e-12,atol=0)
                times=times[::2];field=np.column_stack([alt['pd'],alt['psi'],alt['phi']])
    with np.load(inherited.source(f'medium-{model}.npz')) as raw:
        grid=raw['scale'];eta=raw['eta'];launch=raw['launch'][:,0]
        medium=CubicSpline(eta,np.column_stack([raw[key] for key in ('hub','loading','opacity')]),extrapolate=False)
    assert eta[0]<25.6+1e-7 and times[0]==38.4 and times[-1]==44.8
    start=max(eta[0],times[0]);end=times[-1]
    axis=CubicSpline(grid,eta,extrapolate=False)(np.linspace(grid[0],grid[-1],4096*sub+1))
    axis[::sub]=eta
    axis=np.unique(np.r_[axis,start,end,times[(times>start)&(times<end)][::(2 if tag=='time' else 1)]])
    emits=np.zeros(len(axis),int)-1
    slots=np.searchsorted(axis,eta);assert np.array_equal(axis[slots],eta)
    emits[slots]=np.arange(len(eta))
    dt=np.diff(axis);at=axis[:-1,None]+dt[:,None]*[1/3,1];at[:,1]=axis[1:]
    mask=(axis[:-1]>=start)&(axis[1:]<=end)
    assert abs(sum(dt[mask])-(end-start))<1e-12
    field_at=CubicSpline(times[::stride],field[::stride],axis=0,extrapolate=False)
    force=np.zeros((*at.shape,3),complex);force[mask]=field_at(at[mask]);force[mask,:,2]-=field_at(start)[2]
    rad=np.array([[5/12,-1/12],[3/4,1/4]])
    impulse=dt[:,None]*(4*force[:,:,0]@rad.T)
    accel=dt[:,None]*(4*k/3*force[:,:,1]@rad.T)
    extra=dt[:,None]*(4*k/3*force[:,:,2]@rad.T)
    hub,inertia,op=medium(at).transpose(2,0,1)
    coeffs=dt[:,None,None]*np.stack([np.full_like(op,k),op,op/inertia,hub],axis=-1)
    bands=stages(order);size=bands.shape[-1]//2;state=np.zeros((size,8))
    state[[0,2],4]=launch.real;state[[0,2],5]=launch.imag;state[:,6:]=state[:,4:6]
    packed=np.empty((size*2,8),order='F')
    read=np.empty((len(grid),4,2),complex)
    def observe(slot,state):
        view=state[[0,2]].T
        read[slot]=view[::2]+1j*view[1::2]
    observe(0,state);inside_shift=False
    for begin in range(0,len(dt),32):
        if begin%1024==0:guard()
        mats=(coeffs[begin:begin+32].reshape(-1,8)@bands.reshape(8,-1)).reshape(-1,11,size*2)
        mats[:,5]+=1
        for step,mat in enumerate(mats,begin):
            packed[::2]=state;packed[1::2]=state
            if mask[step]:
                for col in (0,2,6):
                    for row in (2,4):
                        vector=accel[step]+(extra[step] if row==4 and col==2 else 0)
                        packed[row:row+2,col]+=vector.real;packed[row:row+2,col+1]+=vector.imag
                    if col!=2:
                        packed[:2,col]+=impulse[step].real;packed[:2,col+1]+=impulse[step].imag
            state=solve_banded((5,5),mat,packed,check_finite=False)[1::2]
            inside_shift=mask[step] and axis[step+1]<end
            shift=4*force[step,1,2]
            if mask[step] and not inside_shift:
                state[0,2]+=shift.real;state[0,3]+=shift.imag
            slot=emits[step+1]
            if slot>=0:
                observe(slot,state)
                if inside_shift:read[slot,1,0]+=shift
    assert np.isfinite(read).all()
    block,shifted,free,combined=read.transpose(1,0,2)
    add=np.max(abs(combined-free-block),axis=0)/abs(combined).max(axis=0)
    assert max(add)<1e-10
    with np.load(last_block(f'transfer-{model}-primary-p2.npz')) as raw:
        previous=raw['new_partial'];regular=raw['regular'];old_free=raw['old_free']
    assert np.array_equal(grid,raw_scale(model))
    pack(f'transfer-{model}-{tag}{suffix}.npz',scale=grid,k=k,block=block,shifted=shifted,free=free,free_plus_block=combined,old_free=old_free,regular=regular,prior_sum=previous,new_partial=previous+block,additivity=add)

def raw_scale(model):
    with np.load(last_block(f'transfer-{model}-primary-p2.npz')) as raw:return raw['scale']

if __name__=='__main__':
    for model in [sys.argv[1]] if len(sys.argv)>1 else ('cold','heavy'):
        for tag in sys.argv[3:] or CONFIG:run(model,tag,sys.argv[2] if len(sys.argv)>2 else '')
        print(model,'requested source-restricted transfers saved',flush=True)
