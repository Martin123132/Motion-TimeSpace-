from local_io import *


def suffix(case):
    return f'{case}-64-t16-d1-l25'


def assess():
    guard()
    mass_rows = read(HERE.parent/'mts-rotating-bar-wave-drive-20261119'/'extra-mean.csv')
    source, sensitivity, recoil = [], [], []
    ledger = read(PRE/'combined-force-ledger.csv')
    for case in (0,1):
        primary = suffix(case)
        mass = mass_rows[case]
        ratio = float(mass['dark_mass'])/(float(mass['total_gravitating_mass'])-float(mass['dark_mass']))
        deposited = read(HERE/f'virtual-displacement-{case}.csv')
        reference = {(row['model'], float(row['epoch'])):row for row in read(HERE/f'centroid-forcing-{case}.csv')}
        for model in MODELS:
            rows = [row for row in deposited if row['model']==model]
            for epoch in sorted({float(row['epoch']) for row in rows}):
                pair = sorted((row for row in rows if float(row['epoch'])==epoch), key=lambda row:int(row['component']))
                moment = np.array([float(row['actual']) for row in pair])
                spherical = np.array([float(row['spherical_ground']) for row in pair])
                driver = reference[model,epoch]
                projected = np.array([float(driver[axis]) for axis in ('dx','dy')])
                point = np.array([float(driver[axis]) for axis in ('point_x','point_y')])
                diff = np.linalg.norm(moment-projected)
                source.append(dict(case=case,model=model,epoch=epoch,absolute_difference=diff,
                    relative_to_differential=diff/np.linalg.norm(moment),relative_to_point=diff/np.linalg.norm(point),
                    flattening_over_full=np.linalg.norm(moment-spherical)/np.linalg.norm(moment)))
            with np.load(HERE/f'states/{primary}-{model}.npz') as data:
                position=data['center_minus_i_y']; time=data['time']; base=position[-1]
                mask=np.abs(position).max()
                matter=-ratio*data['bary'][-1]
                recoil.append(dict(case=case,model=model,wave_mass_over_baryons=ratio,
                    mean_ordinary_ax= float(matter.real),mean_ordinary_ay=float(-matter.imag),
                    mean_ordinary_a=float(abs(matter)),wave_baryonic_a=float(abs(data['bary'][-1]))))
            old=[row for row in ledger if row['tag']==TAGS[case] and row['orbit']==model]
            def sky(prefix):
                return {(row['background'],row['R'],row['z'],row['component'],row['convention']):row
                        for row in read(HERE/f'sky/{prefix}.csv') if row['model']==model}
            sky0 = sky(primary)
            for trial, name in [(f'{case}-88-t16-d1-l25','basis'),(f'{case}-64-t8-d1-l25','time'),
                    (f'{case}-64-t16-d2-l25','source_radius'),(f'{case}-64-t16-d1-l15','source_degree'),(suffix(case+2),'domain')]:
                with np.load(HERE/f'states/{trial}-{model}.npz') as data:
                    indices=np.searchsorted(time,data['time']); assert np.array_equal(time[indices],data['time'])
                    relative=abs(base-data['center_minus_i_y'][-1])/abs(base)
                    trace=max(abs(position[indices]-data['center_minus_i_y']))/mask
                skyt = sky(trial); assert skyt.keys()==sky0.keys() and len(old)==16
                changes = [abs(float(row['wave_increment'])-float(sky0[key]['wave_increment'])) for key,row in skyt.items()]
                sensitivity.append(dict(case=case,model=model,test=name,endpoint_vector_relative=relative,trace_over_peak=trace,
                    largest_absolute_sky_change=max(changes),band_changes=sum(row['inside']!=sky0[key]['inside'] for key,row in skyt.items())))
    table('independent-centroid-drive.csv',source);table('numerical-controls.csv',sensitivity);table('ordinary-reaction-readout.csv',recoil)


if __name__=='__main__':assess()
