from local_io import *
from itertools import product
from math import isclose
from assess_centroid import suffix

TOL=2e-5


def verify():
    guard()
    parent=json.loads((PRE/'seal.json').read_bytes())['files']
    assert len(parent)==178 and all(digest(PRE/key)==val for key,val in parent.items())
    ledger={(r['tag'],r['orbit'],r['background'],r['R'],r['z'],r['component']):r for r in read(PRE/'combined-force-ledger.csv')}
    assert len(ledger)==192
    shell=read(HERE/'incident-controls.csv')
    assert len(shell)>=9 and max(float(r['relative_or_absolute_error']) for r in shell)<TOL
    expected=set(product(MODELS,('mts','nfw'),('6.0','8.3'),('1.5','-1.5'),('radial','polar'),('prescribed_origin','site_minus_center')))
    primary=0
    for case,count in ((0,64),(1,64),(0,88),(1,88),(2,64),(3,64)):
        rule,=read(HERE/f'sum-rules-{case}-{count}.csv')
        for key,ref in [('modal_sum','centroid_kinematic_sum'),('modal_compliance','static_compliance'),('spatial_k_native','full_k_native'),('physical_k_native','full_k_native')]:
            assert abs(float(rule[key])/float(rule[ref])-1)<TOL,(case,count,key)
        assert abs(float(rule['centroid_kinematic_sum'])-1)<TOL
    for case in range(4):
        configs=[suffix(case)]
        if case<2:configs.extend([f'{case}-88-t16-d1-l25',f'{case}-64-t8-d1-l25',f'{case}-64-t16-d2-l25',f'{case}-64-t16-d1-l15'])
        for prefix in configs:
            sky=read(HERE/f'sky/{prefix}.csv');response=read(HERE/f'response/{prefix}.csv')
            assert {r['model'] for r in response}==set(MODELS) and len(response)==6
            keys=['model','background','R','z','component','convention']
            assert len(sky)==len(expected) and {tuple(row[k] for k in keys) for row in sky}==expected
            for row in sky:
                prev=ledger[TAGS[case%2],*(row[k] for k in keys[:-1])]
                assert all(float(row[a])==float(prev[b]) for a,b in (('previous','total'),('low','low'),('high','high')))
                new=float(row['total']);inc=float(row['wave_increment'])
                assert np.isfinite(new) and new==float(prev['total'])+inc
                assert (row['inside']=='True')==(float(row['low'])<=new<=float(row['high']))
                if row['background']=='nfw':assert inc==0
            for row in response:
                with np.load(HERE/f"states/{prefix}-{row['model']}.npz") as state:
                    assert all(np.isfinite(val).all() for val in state.values())
                    assert np.all(np.diff(state['time'])>0) and state['time'][-1]==0 and state['time'][0]<0
                    for key in ('center_minus_i_y','velocity','restoring','bary','wall','rigid','driving'):
                        assert state[key].shape==state['time'].shape
                    cm=state['center_minus_i_y']
                    assert cm[0]==state['velocity'][0]==0 and abs(sum(state['mode_centroid'])-cm[-1])<1e-10
                    assert isclose(abs(cm[-1]),float(row['final_kpc']),rel_tol=1e-12)
                    assert abs(cm[-1]*1000-complex(float(row['final_x_pc']),-float(row['final_y_pc'])))<1e-9
                    error=max(abs(state['restoring']-state['bary']-state['wall']))/max(abs(state['restoring']))
                    assert error<TOL and abs(error-float(row['physical_moment_defect_over_peak']))<1e-12
                    assert min(state['energy'])>=0
            if case<2 and prefix==suffix(case):primary+=len(sky)
    diff=read(HERE/'independent-centroid-drive.csv');assert len(diff)==36
    assert max(float(row['relative_to_differential']) for row in diff)<TOL
    sens=read(HERE/'numerical-controls.csv');assert len(sens)==60
    assert all(int(row['band_changes'])==0 for row in sens)
    rec=read(HERE/'ordinary-reaction-readout.csv');assert len(rec)==12
    assert all(isclose(float(row['mean_ordinary_a']),float(row['wave_mass_over_baryons'])*float(row['wave_baryonic_a']),rel_tol=1e-13) for row in rec)
    assert primary==384
    return dict(parent_seal=PRE_PIN,parent_files_verified=len(parent),primary_component_rows=primary,independent_driver_vectors=len(diff),
                control_comparisons=len(sens),original_relative_tolerance=TOL)


if __name__=='__main__':
    result=verify();seal=HERE/'seal.json'
    files={p.relative_to(HERE).as_posix():digest(p) for p in sorted(HERE.rglob('*')) if p.is_file() and p!=seal}
    manifest=dict(**result,files=files)
    assert sys.argv[1:] in ([],['seal'])
    if sys.argv[1:]==['seal']:save('seal.json',(json.dumps(manifest,sort_keys=True,indent=2)+'\n').encode())
    assert json.loads(seal.read_bytes())==manifest
    print(json.dumps(result),len(files),digest(seal))
