import os,sys,hashlib,io,csv,json
from pathlib import Path
for name in ('OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','OMP_NUM_THREADS','BLIS_NUM_THREADS','NUMEXPR_NUM_THREADS'):os.environ[name]='1'
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
PRE=HERE.parent/'mts-lmc-live-quadrupole-20261119'
sys.path.insert(0,str(PRE))
from quad_io import digest,AX,LMC,BAR,MODELS,TAGS,history,positions,GYR,np,read
PRE_PIN='14328952cd5b8ed0c9b8d000f9d26f13e86a1fbaae2951c586eccdd010420df2'
def guard():
    assert digest(PRE/'seal.json')==PRE_PIN and not any((root/'STOP-REQUESTED').exists() for root in (HERE,HERE.parent,PRE,AX,LMC,BAR))
def save(name,raw):
    guard();path=HERE/name;path.parent.mkdir(parents=True,exist_ok=True)
    if path.exists():assert digest(path)==hashlib.sha256(raw).hexdigest(),name
    else:
        with path.open('xb') as stream:stream.write(raw)
def table(name,rows):
    buf=io.StringIO(newline='');writer=csv.DictWriter(buf,rows[0],lineterminator='\n');writer.writeheader();writer.writerows(rows);save(name,buf.getvalue().encode())
def packet(name,**data):
    buf=io.BytesIO();np.savez_compressed(buf,**data);save(name,buf.getvalue())
