from local_io import *
from lmc_field import shape_weights,harmonic,potential
from pulse_space import basis
from scipy.special import roots_legendre
from ctypes import CDLL,c_int
PTR=np.ctypeslib.ndpointer(dtype=np.float64,flags='C_CONTIGUOUS')
LIB=CDLL(str(HERE/'m1_shell.dll'))
LIB.dipole.argtypes=[PTR,PTR,PTR,PTR,c_int,PTR,PTR,c_int,c_int,PTR]

def project(place,knots,shape,radius,top,quad):
    raw=np.empty((len(radius),(top+1)//2,2))
    code=LIB.dipole(*(np.ascontiguousarray(v,dtype=float) for v in (place,knots,shape,radius)),len(radius),*quad,len(quad[0]),top,raw)
    assert code==0,code
    return raw.view(np.complex128)[:,:,0]
def pieces(points,knots,profiles,left,frac):
    ids=np.arange(len(left));rr=np.linalg.norm(points,axis=1);mu=points[:,2]/rr;phi=np.arctan2(points[:,1],points[:,0]);answer=np.zeros(len(ids))
    for degree in range(7):
        pick,ws=shape_weights(rr,knots,degree)
        def radial(order):
            col=degree*(degree+1)+order
            return np.einsum('ij,ij->i',ws,(1-frac[:,None])*profiles[left[:,None],pick,col]+frac[:,None]*profiles[left[:,None]+1,pick,col])
        for order in range(degree+1):
            coeff=harmonic(degree,order,mu,phi)
            answer+=radial(order)*coeff.real*(np.sqrt(2) if order else 1.)
            if order:answer+=np.sqrt(2)*radial(-order)*coeff.imag
    return answer
def derivative(points,knots,profiles,left,frac,step):
    result=[]
    for vec in (np.array([step,0,0]),np.array([0,step,0])):
        evaluate=lambda off:pieces(points+off*vec,knots,profiles,left,frac)
        result.append((evaluate(-2)-8*evaluate(-1)+8*evaluate(1)-evaluate(2))/(12*step))
    return result[0]-1j*result[1]
def name(model,res,top,nq,sub):return f'incident/{model}-{res}-{top}-{nq}-{sub}.npz'
def build(model,res,top,nq,sub):
    guard();times,knots,shapes,tr=history(model);ticks=np.linspace(times[0],0,(len(times)-1)*sub+1);places=positions(tr,ticks)
    left=np.minimum(np.arange(len(ticks))//sub,len(times)-2);frac=np.arange(len(ticks))/sub-left
    grads=derivative(-places,knots,shapes,left,frac,.014);other=derivative(-places,knots,shapes,left,frac,.007)
    radius=np.sinh(np.linspace(0,np.arcsinh(400/35),res+1))*35;quad=roots_legendre(nq)
    raw=np.empty((len(ticks),len(radius),(top+1)//2),complex)
    for idx,place in enumerate(places):
        shape=(1-frac[idx])*shapes[left[idx]]+frac[idx]*shapes[left[idx]+1]
        raw[idx]=project(place,knots,shape,radius,top,quad)
        if idx%128==0:guard()
    packet(name(model,res,top,nq,sub),raw=raw,radius=radius,time=ticks,grad=other,grad_control=grads)
    print('saved',model,flush=True)

def check():
    knots=np.geomspace(200.,1000.,25);shape=np.zeros((50,49));place=np.array([21.,-31.,11.]);radius=np.array([4.,8.,22.,45.])
    gx,gy=.73,-.29
    shape[:25,3]=-gx*knots/np.sqrt(3);shape[:25,1]=-gy*knots/np.sqrt(3);shape[25:]=shape[:25]
    result=project(place,knots,shape,radius,25,roots_legendre(32));result[:,0]+=radius*(gx-1j*gy)/np.sqrt(6)
    assert abs(result).max()<1e-11,(gx,gy,result)
    checks=[dict(model='uniform',epoch=0,radius=45.,relative_or_absolute_error=abs(result).max())]
    mu,w=roots_legendre(128);phi=2*np.pi*(np.arange(256)+.37)/256
    sn=np.sqrt(1-mu**2)[:,None];coords=np.stack(np.broadcast_arrays(sn*np.cos(phi),sn*np.sin(phi),mu[:,None]),axis=-1)
    angular=basis(np.arange(1,26,2),1,mu).T*(w/2)
    for model,t in [('L2M10',0.),('L3M10rad',-3.01953125)]:
        times,knots,profiles,tr=history(model);left=np.clip(np.searchsorted(times,t)-1,0,len(times)-2);frac=(t-times[left])/(times[left+1]-times[left])
        shape=profiles[left]*(1-frac)+profiles[left+1]*frac;place=positions(tr,t)
        radii=np.array([6.,24.,51.,89.]);shell=project(place,knots,shape,radii,25,roots_legendre(32))
        for rad,fast in zip(radii,shell):
            direct=angular@((potential(rad*coords-place,knots,shape)*np.exp(-1j*phi)).mean(axis=1))
            error=np.linalg.norm(direct-fast)/np.linalg.norm(direct);assert error<2e-5,error
            checks.append(dict(model=model,epoch=t,radius=rad,relative_or_absolute_error=error))
    table('incident-controls.csv',checks)
if __name__=='__main__':
    if sys.argv[1]=='check':check()
    else:
        for model in MODELS:build(model,*map(int,sys.argv[1:]))
