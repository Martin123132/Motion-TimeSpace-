import os,sys,csv,io,json,hashlib
from pathlib import Path
for setting in ('OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','OMP_NUM_THREADS','NUMEXPR_NUM_THREADS','BLIS_NUM_THREADS'):
    os.environ[setting]='1'
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parent
LAST=ROOT.parent/'mts-lmc-differential-centroid-20261119'
PIN='962ef822e53f01ebffda859b980242a7dc44e552682569796526c0987977e86b'
sys.path.insert(0,str(LAST))
from local_io import np,read,digest,MODELS,TAGS,PRE
from dipole_operator import setup
from pulse_space import angular,slope
from centroid_run import mapping,solve
from kernel import Lenses,AXES,BAR_NORM,HEIGHT
from gas_common import gases
from feasibility import UNIT
from scipy.special import roots_legendre,k0
from scipy.interpolate import CubicSpline
from scipy.linalg import eigh
MASS=ROOT.parent/'mts-rotating-bar-wave-drive-20261119'/'extra-mean.csv'
def guard():
    assert digest(LAST/'seal.json')==PIN and not any((p/'STOP-REQUESTED').exists() for p in (ROOT,ROOT.parent,LAST,PRE))
def save(filename,data):
    guard();path=ROOT/filename
    if path.exists():assert hashlib.sha256(data).hexdigest()==digest(path),filename
    else:
        with path.open('xb') as stream:stream.write(data)
def table(filename,rows):
    buf=io.StringIO(newline='');out=csv.DictWriter(buf,rows[0],lineterminator='\n');out.writeheader();out.writerows(rows);save(filename,buf.getvalue().encode())
def packet(filename,**arrays):
    buf=io.BytesIO();np.savez_compressed(buf,**arrays);save(filename,buf.getvalue())
