from recoil_io import *
from centroid_source import derivative,project
from lmc_field import history,positions

def build():
    model='L2M11';stamps,knots,shapes,traj=history(model)
    with np.load(LAST/f'incident/{model}-192-25-28-16.npz') as p:
        time=p['time'];grid=p['radius']
    odd=(time[1:]+time[:-1])/2;where=positions(traj,odd)
    left=np.minimum(np.searchsorted(stamps,odd)-1,len(stamps)-2)
    t=(odd-stamps[left])/(stamps[left+1]-stamps[left])
    grads=derivative(-where,knots,shapes,left,t,.007)
    raw=np.empty((len(odd),len(grid),13),complex);quad=roots_legendre(28)
    for idx,(pos,start,frac) in enumerate(zip(where,left,t)):
        if idx%128==0:guard()
        raw[idx]=project(pos,knots,(1-frac)*shapes[start]+frac*shapes[start+1],grid,25,quad)
    packet('time-midpoints-L2M11.npz',time=odd,grad=grads,raw=raw)

if __name__=='__main__':build()
