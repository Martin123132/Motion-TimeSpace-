from recoil_io import *

def evolve(case,via):
    guard();prefix=f'{case}-{via}'
    row=read(MASS)[case];mb=float(row['total_gravitating_mass'])-float(row['dark_mass']);gamma=float(row['dark_mass'])/mb
    with np.load(LAST/f'operators/{case}-64.npz') as data:op=dict(data)
    sigma=op['freq'];meter=op['center'];occ=float(op['mass']);length=float(op['length']);vel=float(op['vel']);unit=vel**2/length
    tangent=occ*meter;kin=meter@tangent;weighted=sigma*meter
    gain=gamma*occ;kernel=np.diag(sigma**2)+gain*np.outer(weighted,weighted)
    evals,rot=eigh(kernel,driver='evd');assert min(evals)>0 and abs(kin-1)<2e-5
    freq=np.sqrt(evals)
    responses=[];skyrows=[];checks=[];source_map=None
    for model in (('L2M11',) if via==32 else MODELS):
        with np.load(LAST/f'incident/{model}-192-25-28-16.npz') as p:
            sub=max(1,16//via);grid=p['radius'];src=p['raw'][::sub];grad=p['grad'][::sub];times=p['time'][::sub]
        with np.load(ROOT/f'drive-{case}-{model}.npz') as p:
            assert np.array_equal(p['time'][::sub],times);delta=p['diff'][::sub]/unit
        if source_map is None:source_map=mapping(op,grid,25)
        if via==32:
            with np.load(ROOT/'time-midpoints-L2M11.npz') as extra, np.load(ROOT/'weights-8-1.npz') as bank:
                assert np.array_equal(extra['time'],(times[1:]+times[:-1])/2)
                factor=np.ones(len(bank['names']))
                ann=next(r for r in read(ROOT.parent/'mts-annular-mass-budget-20261119'/'independent-budget.csv') if
                    (r['family'],r['width'],r['calibration'],r['side'])==('added','2','free','plus'))
                factor[np.char.startswith(bank['names'],'ring_')]=float(ann['amplitude']) if case else 0.
                w=np.einsum('c,crl->rl',factor,bank['weights'])/(factor@bank['masses'])
                fine=extra['raw'];gmid=extra['grad']
                mid_delta=(np.einsum('trl,rl->t',fine,w)+gmid*(w[:,0]@grid)/np.sqrt(6))/unit
                def weave(old,new):
                    out=np.empty((len(old)+len(new),*old.shape[1:]),dtype=old.dtype)
                    out[::2]=old;out[1::2]=new;return out
                src=weave(src,fine);grad=weave(grad,gmid);times=weave(times,extra['time']);delta=weave(delta,mid_delta)
                del fine
        tau=times*vel/length;src[:,:,0]+=grad[:,None]*grid/np.sqrt(6);force=2*src.reshape(len(src),-1)@source_map;del src
        external_wave=-(force@meter)
        driving=(force+delta[:,None]*tangent)*sigma
        pos,speed=solve(driving@rot,tau,freq);cmode=(pos@rot.T)/sigma;vrate=(speed@rot.T)/sigma
        cm=cmode@meter;cm_v=vrate@meter
        restore=-(cmode@(meter*sigma**2));material=cmode@op['bary'];wall=cmode@op['wall']
        feedback=-gamma*restore
        bary_acc=delta[::4]-gamma*material
        relative_acc=((-(pos*evals)@rot.T-driving[::4])/sigma)@meter
        measured_rel=external_wave[::4]+material+wall-bary_acc
        error=max(abs(relative_acc-measured_rel))/max(abs(measured_rel))
        com_num=(gamma*(relative_acc+bary_acc)+bary_acc)/(1+gamma)
        com_ext=(gamma*(external_wave[::4]+wall)+delta[::4])/(1+gamma)
        momentum=max(abs(com_num-com_ext))/max(abs(com_ext))
        com_external=abs(com_ext[-1])*unit
        assert max(error,momentum)<2e-5,(error,momentum)
        base,sbase=solve(force,tau,sigma)
        with np.load(LAST/f'states/{case}-64-t{min(via,16)}-d1-l25-{model}.npz') as p:
            original=p['center_minus_i_y'];common_step=2 if via==32 else 1
            assert np.array_equal(times[::4*common_step],p['time'])
            replay=max(abs((base[::common_step]@meter)*length-original))/max(abs(original))
        assert replay<2e-5
        del base,sbase
        zm,vm=solve(driving,tau,sigma);oneway=zm@(meter/sigma)
        direct=2*(op['sky']@cmode[-1]);origin=direct[-1];actual=-direct
        old=read(PRE/'combined-force-ledger.csv')
        for rec in old:
            if rec['tag']!=TAGS[case] or rec['orbit']!=model:continue
            polar=rec['component']=='polar';rad=float(rec['R']);z=float(rec['z']);sph=np.hypot(rad,z)
            sign=np.sign(z) if polar else 1.
            idx=3*int(rad>6)+int(polar);proj=(z if polar else rad)/sph
            live=rec['background']=='mts'
            wave=actual[idx].real*sign if live else 0.
            for label,offset in [('site_minus_point',origin.real if live else 0.),
                                ('site_minus_material_planar',(delta[-1].real+(feedback[-1].real if live else 0.))*unit*UNIT)]:
                total=float(rec['total'])+wave+proj*offset
                skyrows.append(dict(model=model,background=rec['background'],R=rad,z=z,component=rec['component'],frame=label,
                    previous=rec['total'],wave=wave,reference_shift=proj*offset,total=total,
                    low=rec['low'],high=rec['high'],inside=float(rec['low'])<=total<=float(rec['high'])))
        common=dict(model=model,case=case,via=via)
        responses.append(dict(**common,fixed_pc=1000*abs(original[-1]),one_way_pc=1000*length*abs(oneway[-1]),
            coupled_pc=1000*length*abs(cm[-1]),x_pc=1000*length*cm[-1].real,y_pc=-1000*length*cm[-1].imag,speed_kms=vel*abs(cm_v[-1]),
            external_point=abs(grad[-1]),ordinary_minus_point=abs(delta[-1])*unit,wave_minus_point=abs(external_wave[-1])*unit,
            wave_minus_ordinary=abs(external_wave[-1]-delta[-1])*unit,external_relative_over_point=abs(external_wave[-1]-delta[-1])*unit/abs(grad[-1]),
            mutual_ordinary_acceleration=abs(feedback[-1])*unit,common_differential=com_external))
        checks.append(dict(**common,free_replay=replay,relative_eq=error,momentum_over_peak=momentum,kinematic=kin,
            static_relative_compliance=occ*np.sum((rot.T@(meter/sigma))*(rot.T@weighted)/evals),
            floor_frequency=freq[0],mass_ratio=gamma))
        packet(f'state-{prefix}-{model}.npz',time=times[::4],wave_minus_baryon=cm*length,velocity=cm_v*vel,
            one_way=oneway*length,external_relative=(external_wave[::4]-delta[::4])*unit,ordinary_external_delta=delta[::4]*unit,
            ordinary_reaction=feedback*unit,wave_from_ordinary=material*unit,wall=wall*unit,relative_acceleration=relative_acc*unit,
            common_external=com_ext*unit,mode=cmode[-1],mode_rate=vrate[-1],sky=direct)
    table(f'response-{prefix}.csv',responses);table(f'sky-{prefix}.csv',skyrows);table(f'checks-{prefix}.csv',checks)
    print(prefix,'complete',flush=True)

if __name__=='__main__':evolve(*map(int,sys.argv[1:]))
