from ordinary_measure import *
from shell_bank import shells,radii_for
from lmc_field import history,positions
from numpy.polynomial.legendre import legvander

def energy_weights(grid,top,order):
    spline=CubicSpline(grid,np.eye(len(grid)),axis=0)
    prim=[];ring=[]
    for label,cyl,z,mass in components(order):
        radius=np.hypot(cyl,z);mu=z/radius
        cell=np.clip(np.searchsorted(grid,radius)-1,0,len(grid)-2);dx=radius-grid[cell];powers=np.array([dx**3,dx**2,dx,np.ones_like(dx)])
        degrees=np.arange(0,top+1,2)
        measures=legvander(mu,top)[:,::2]*np.sqrt(2*degrees+1)*mass[:,None]
        mat=[]
        for column in measures.T:
            coef=np.stack([np.bincount(cell,p*column,minlength=len(grid)-1) for p in powers])
            mat.append(np.einsum('kc,kcn->n',coef,spline.c))
        (ring if label.startswith('ring_') else prim).append(np.stack(mat,axis=1))
    amplitude=float(next(r for r in read(ROOT.parent/'mts-annular-mass-budget-20261119'/'independent-budget.csv') if
        (r['family'],r['width'],r['calibration'],r['side'])==('added','2','free','plus'))['amplitude'])
    base=sum(prim);banks=np.stack((base,base+sum(ring)*amplitude))
    return banks/banks[:,:,0].sum(axis=1)[:,None,None]

def check():
    grid=radii_for(384);top=60;weights=energy_weights(grid,top,8);quad=roots_legendre(40)
    rows=[]
    for model in MODELS:
        stamp,knots,shapes,traj=history(model)
        for time in (0.,-.21875,-1.48828125):
            place=positions(traj,time);idx=np.clip(np.searchsorted(stamp,time)-1,0,len(stamp)-2)
            t=(time-stamp[idx])/(stamp[idx+1]-stamp[idx]);source=(1-t)*shapes[idx]+t*shapes[idx+1]
            coords=[]
            for direction in np.eye(3)[:2]:
                def energy(shift):
                    return np.einsum('clh,lh->ch',weights,shells(place+shift*direction,knots,source,grid,top,quad))
                step=.02
                coords.append((energy(-2*step)-8*energy(-step)+8*energy(step)-energy(2*step))/(12*step))
            v=coords[0]-1j*coords[1]
            for case,value in enumerate(v):
                with np.load(ROOT/f'drive-{case}-{model}.npz') as data:
                    loc=np.where(data['time']==time)[0].item();ref=data['diff'][loc]
                rows.append(dict(case=case,model=model,time=time,original_x=ref.real,original_y=-ref.imag,
                    work_x=value.sum().real,work_y=-value.sum().imag,relative_difference=abs(ref-value.sum())/abs(value.sum()),
                    absolute_difference=abs(ref-value.sum()),last_six_degree_norm=abs(value[-6:].sum())/abs(value.sum())))
    table('external-virtual-work.csv',rows)

if __name__=='__main__':check()
