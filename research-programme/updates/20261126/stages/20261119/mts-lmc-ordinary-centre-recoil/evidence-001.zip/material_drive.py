from recoil_io import *

def compute():
    rows=read(MASS)
    ann=next(r for r in read(ROOT.parent/'mts-annular-mass-budget-20261119'/'independent-budget.csv') if
             (r['family'],r['width'],r['calibration'],r['side'])==('added','2','free','plus'))
    assert float(ann['donor_per_unit'])==0
    totals=[];tests=[]
    for order,stride in [(8,1),(6,1),(8,2)]:
        with np.load(ROOT/f'weights-{order}-{stride}.npz') as bank:
            names=list(bank['names']);mass=bank['masses'];grid=bank['grid'];weights=bank['weights']
        for case,row in enumerate(rows[:2]):
            factor=np.ones(len(names))
            factor[[names.index(k) for k in ('ring_thin','ring_thick')]]=float(ann['amplitude']) if case else 0
            effective=mass@factor
            expected=float(row['total_gravitating_mass'])-float(row['dark_mass'])
            assert abs(effective/expected-1)<2e-5,(effective,expected)
            stack=weights.reshape(len(names),-1)
            for model in MODELS:
                with np.load(LAST/f'incident/{model}-192-25-28-16.npz') as p:
                    src=p['raw'][:,::stride];grad=p['grad'];time=p['time']
                src[:,:,0]+=grad[:,None]*grid/np.sqrt(6)
                comp=src.reshape(len(time),-1)@stack.T
                diff=comp@factor/effective
                if order==8 and stride==1:
                    packet(f'drive-{case}-{model}.npz',time=time,diff=diff,external_point=-grad,component_differential=comp/mass,names=names)
                    for name,amplitude,component_mass,force in zip(names,factor,mass,comp[-1]):
                        totals.append(dict(case=case,model=model,component=name,mass=amplitude*component_mass,
                                    relative_ax=force.real/component_mass,relative_ay=-force.imag/component_mass,
                                    weighted_ax=amplitude*force.real/effective,weighted_ay=-amplitude*force.imag/effective,
                                    mass_normalization_relative_error=effective/expected-1))
                else:
                    with np.load(ROOT/f'drive-{case}-{model}.npz') as data:ref=data['diff']
                    tests.append(dict(case=case,model=model,order=order,stride=stride,endpoint_relative=abs(diff[-1]-ref[-1])/abs(ref[-1]),
                        trace_over_peak=max(abs(diff-ref))/max(abs(ref))))
    table('component-drives.csv',totals);table('source-refinements.csv',tests)

if __name__=='__main__':compute()
