from ordinary_measure import *
from lmc_field import history,positions
from ctypes import CDLL,c_int
P=np.ctypeslib.ndpointer(dtype=np.float64,flags='C_CONTIGUOUS')
lib=CDLL(str(ROOT/'gas_ring.dll'))
lib.direct_ring.argtypes=[P,P,P,P,P,P,c_int,P,P,c_int,P,P]

def nodes(gas,rad_order):
    radii,weights=quadrature(np.r_[0,.125,.5,np.arange(1.,37.),np.arange(37.,122.,2.),np.arange(122.,241.,4.)],rad_order)
    u,uw=quadrature([0.,1.,3.,7.,15.,30.,50.],rad_order)
    density=2*np.exp(-u)/(1+np.exp(-u))**2
    rr,zz=np.broadcast_arrays(radii[:,None],gas.height*u)
    mass=2*np.pi*(radii*weights*gas.surface(radii))[:,None]*(uw*density)
    slope=mass*(gas.rm/radii**2-1/gas.rd)[:,None]/gas.mass
    return rr.ravel(),zz.ravel(),slope.ravel(),mass.ravel()/gas.mass

def compute(place,knots,shape,grad,gas_grid,nq):
    quad,weight=roots_legendre(nq)
    rr,zz,slope,_=gas_grid;out=np.zeros(2)
    assert lib.direct_ring(*(np.ascontiguousarray(v,dtype=float) for v in (place,knots,shape,rr,zz,slope)),len(rr),
        quad,weight,nq,np.array([grad.real,-grad.imag]),out)==0
    return out[0]-1j*out[1]

def run(level,models):
    rad_order,az_order={'base':(4,12),'fine':(6,20)}[level]
    comps=gases();grids=[nodes(g,rad_order) for g in comps];rows=[]
    place=np.array([11.,-6.,22.]);knots=np.geomspace(1100.,22000.,25)
    shape=np.zeros((50,49));shape[:25,13]=-knots**3/(1.5*np.sqrt(7/6));shape[25:,13]=3*shape[:25,13]
    xx,yy,zz=-place;grad=(4*zz**2-3*xx**2-yy**2)+2j*xx*yy
    for gas,grid in zip(comps,grids):
        xx=compute(place,knots,shape,grad,grid,az_order);rad,z,_,mass=grid
        true=mass@(2*rad**2-4*z**2)
        assert abs(xx/true-1)<2e-5,(gas.name,xx,true)
    for model in models:
        stamp,knots,history_bank,traj=history(model)
        with np.load(LAST/f'incident/{model}-192-25-28-16.npz') as p:grad=p['grad'][-1]
        with np.load(ROOT/f'drive-0-{model}.npz') as p:names=list(p['names']);projected=p['component_differential'][-1]
        for gas,grid in zip(comps,grids):
            xx=compute(positions(traj,0.),knots,history_bank[-1],grad,grid,az_order)
            prev=projected[names.index(gas.name)]
            rows.append(dict(model=model,component=gas.name,direct_x=xx.real,direct_y=-xx.imag,projected_x=prev.real,
                projected_y=-prev.imag,absolute_difference=abs(xx-prev),relative_difference=abs(xx-prev)/abs(xx)))
        print(level,model,flush=True)
    table(f"direct-gas-{level}-{'all' if len(models)==6 else '-'.join(models)}.csv",rows)
if __name__=='__main__':run(sys.argv[1],MODELS if sys.argv[2]=='all' else sys.argv[2:])
