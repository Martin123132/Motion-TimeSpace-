from recoil_io import *

def build(case):
    with np.load(LAST/f'operators/{case}-64.npz') as op:
        sigma=op['freq'];h=op['center'];occ=float(op['mass']);length=float(op['length']);vel=float(op['vel'])
        sky=op['sky'];unit=vel**2/length*UNIT
    row=read(MASS)[case];gamma=float(row['dark_mass'])/(float(row['total_gravitating_mass'])-float(row['dark_mass']))
    kinetic=occ*(h@h);v=sigma*h;q=h/sigma
    spec,rot=eigh(np.diag(sigma**2)+gamma*occ*np.outer(v,v),driver='evd');omega=np.sqrt(spec)
    weights=occ*(rot.T@q)**2*spec/(1+gamma*kinetic);dc=occ*(q@q)/(1+gamma*kinetic)
    assert abs(sum(weights)/kinetic-1)<2e-5 and abs(sum(weights/spec)/dc-1)<2e-5
    scores=[]
    for s in (0,.1,.5,1.,4.,25.):
        chi0=occ*np.sum(h**2/(sigma**2+s*s))
        chi=chi0/(1+gamma*(kinetic-s*s*chi0));test=np.sum(weights/(spec+s*s))
        scores.append(dict(case=case,laplace=s,rank_one=chi,modal=test,relative=abs(chi-test)/chi))
        assert scores[-1]['relative']<2e-5
    sky_vectors=[];sky_names=[];skybounds=[]
    for rad in (6.,8.3):
        for z in (-1.5,1.5):
            for polar in (False,True):
                idx=3*int(rad>6)+int(polar);sign=np.sign(z) if polar else 1.;proj=(z if polar else rad)/np.hypot(rad,z)
                vec=-2*sign*sky[idx]
                for frame in ('site_minus_point','site_minus_material_planar'):
                    field=vec+(2*proj*sky[-1] if frame=='site_minus_point' else proj*unit*gamma*h*sigma**2)
                    terms=occ*(rot.T@(field/sigma))*(rot.T@v)
                    sky_vectors.append(terms);sky_names.append(f'{rad}/{z}/{int(polar)}/{frame}')
                    skybounds.append(dict(case=case,R=rad,z=z,component='polar' if polar else 'radial',frame=frame,
                        response_bound_per_kms=np.sum(abs(terms)/omega)/vel,
                        instantaneous_per_accel=0 if frame=='site_minus_point' else proj*UNIT))
    packet(f'kernel-{case}.npz',frequency=omega,weights=weights,sky_weights=sky_vectors,sky_keys=sky_names,
           length=length,vel=vel,kinetic=kinetic,static=dc)
    table(f'transfer-checks-{case}.csv',scores);table(f'sky-error-gains-{case}.csv',skybounds)
    return dict(case=case,centroid_pc_per_kms=1000*length*np.sum(weights/omega)/vel,
                inverse_static=1/dc,residue_sum=weights.sum(),lowest_weight=weights[0])

if __name__=='__main__':table('centroid-error-gains.csv',[build(case) for case in (0,1)])
