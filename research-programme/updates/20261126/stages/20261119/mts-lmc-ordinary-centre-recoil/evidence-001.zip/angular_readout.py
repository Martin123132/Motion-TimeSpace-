from ordinary_measure import *
from centroid_source import project
from shell_bank import radii_for
from lmc_field import history,positions

def check():
    grid=radii_for(384);names,bank,rows=weights(grid,65,8)
    masses=np.array([r['mass'] for r in rows]);coeff=np.ones((2,len(names)))
    ann=next(r for r in read(ROOT.parent/'mts-annular-mass-budget-20261119'/'independent-budget.csv') if
               (r['family'],r['width'],r['calibration'],r['side'])==('added','2','free','plus'))
    for key in ('ring_thin','ring_thick'):coeff[:,names.index(key)]=[0.,float(ann['amplitude'])]
    coeff/=((coeff@masses)[:,None]);quad=roots_legendre(40)
    virtual={(r['model'],float(r['time']),int(r['case'])):complex(float(r['work_x']),-float(r['work_y'])) for r in read(ROOT/'external-virtual-work.csv')}
    output=[];tails=[]
    for model in MODELS:
        stamp,knots,shapes,traj=history(model)
        with np.load(LAST/f'incident/{model}-192-25-28-16.npz') as p:time=p['time'];grads=p['grad']
        for epoch in (0.,-.21875,-1.48828125):
            index=np.where(time==epoch)[0].item();idx=np.clip(np.searchsorted(stamp,epoch)-1,0,len(stamp)-2);t=(epoch-stamp[idx])/(stamp[idx+1]-stamp[idx])
            src=project(positions(traj,epoch),knots,(1-t)*shapes[idx]+t*shapes[idx+1],grid,65,quad)
            src[:,0]+=grads[index]*grid/np.sqrt(6)
            piece=np.einsum('crl,rl->cl',bank,src)
            for case,weight in enumerate(coeff):
                value=weight@piece;other=virtual[model,epoch,case]
                with np.load(ROOT/f'drive-{case}-{model}.npz') as p:original=p['diff'][index]
                for top in (15,25,41,51,59,65):
                    total=value[:(top+1)//2].sum()
                    output.append(dict(case=case,model=model,time=epoch,degree=top,ax=total.real,ay=-total.imag,
                        relative_to_virtual=abs(total-other)/abs(other),relative_to_65=abs(total-value.sum())/abs(value.sum()),
                        absolute_to_original=abs(total-original)))
                if epoch==0:
                    for name,delta in zip(names,weight*piece[:,13:].sum(axis=1)):
                        tails.append(dict(case=case,model=model,component=name,added_ax=delta.real,added_ay=-delta.imag))
    table('source-angular-convergence.csv',output);table('component-angular-tail.csv',tails)

if __name__=='__main__':check()
