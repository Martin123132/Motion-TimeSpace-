from recoil_io import *
from itertools import product

def verify():
    guard();manifest=json.loads((LAST/'seal.json').read_bytes())['files']
    assert len(manifest)==136 and all(digest(LAST/key)==val for key,val in manifest.items())
    orig={(r['tag'],r['orbit'],r['background'],r['R'],r['z'],r['component']):r for r in read(PRE/'combined-force-ledger.csv')}
    tol=2e-5;assert len(orig)==192
    source=read(ROOT/'direct-gas-impact.csv');time=read(ROOT/'time-refinements.csv')
    assert len(source)==12 and len(time)==14 and len(read(ROOT/'component-drives.csv'))==108
    for case in (0,1):
        src=[r for r in source if int(r['case'])==case];assert {r['model'] for r in src}==set(MODELS)
        assert max(float(r['gas_refinement_over_ordinary_difference']) for r in src)<tol
        assert all(float(r['correction_over_ordinary_difference'])>tol for r in src)
        for model in MODELS:
            refined=[r for r in time if int(r['case'])==case and r['model']==model]
            assert max(int(r['fine']) for r in refined)==(32 if model=='L2M11' else 16)
            last=max(refined,key=lambda r:int(r['fine']))
            assert float(last['final_relative'])<tol
        with np.load(ROOT/f'kernel-{case}.npz') as k:
            assert min(k['frequency'])>0 and min(k['weights'])>=0
            assert abs(k['weights'].sum()/k['kinetic']-1)<tol
            assert abs((k['weights']/k['frequency']**2).sum()/k['static']-1)<tol
        checks=read(ROOT/f'transfer-checks-{case}.csv');assert len(checks)==6
        assert max(float(r['relative']) for r in checks)<tol
        for via in (8,16,32):
            models=MODELS if via<32 else ['L2M11']
            records=read(ROOT/f'sky-{case}-{via}.csv')
            expected=set(product(models,('mts','nfw'),('6.0','8.3'),('1.5','-1.5'),('radial','polar'),('site_minus_point','site_minus_material_planar')))
            assert len(records)==len(expected) and {tuple(row[k] for k in ('model','background','R','z','component','frame')) for row in records}==expected
            for row in records:
                prev=orig[TAGS[case],*(row[k] for k in ('model','background','R','z','component'))]
                assert all(float(row[k])==float(prev[p]) for k,p in (('previous','total'),('low','low'),('high','high')))
                total=float(row['previous'])+float(row['wave'])+float(row['reference_shift'])
                assert total==float(row['total']) and row['inside']==prev['inside']
                assert (float(row['low'])<=total<=float(row['high']))==(row['inside']=='True')
                if row['background']=='nfw':
                    assert float(row['wave'])==0 and (row['frame']!='site_minus_point' or total==float(prev['total']))
            response=read(ROOT/f'response-{case}-{via}.csv');eq=read(ROOT/f'checks-{case}-{via}.csv')
            assert len(response)==len(eq)==len(models) and {r['model'] for r in response}==set(models)
            for row in eq:assert max(float(row[k]) for k in ('relative_eq','momentum_over_peak','free_replay'))<tol
            for row in response:
                with np.load(ROOT/f"state-{case}-{via}-{row['model']}.npz") as p:
                    assert all(np.isfinite(val).all() for val in p.values())
                    assert np.all(np.diff(p['time'])>0) and p['time'][-1]==0 and p['time'][0]<0
                    trace=p['wave_minus_baryon'];assert trace[0]==p['velocity'][0]==0 and len(trace)==len(p['time'])
                    assert abs(1000*trace[-1]-complex(float(row['x_pc']),-float(row['y_pc'])))<1e-9
                    assert abs(1000*abs(trace[-1])-float(row['coupled_pc']))<1e-9
                    assert abs(abs(p['external_relative'][-1])-float(row['wave_minus_ordinary']))<1e-10
    virtual=read(ROOT/'external-virtual-work.csv');assert len(virtual)==36 and len(read(ROOT/'source-angular-convergence.csv'))==216
    assert max(float(r['relative_difference']) for r in virtual)>tol
    assert len(read(ROOT/'minimum-source-error-impulses.csv'))==72
    return dict(parent_seal=PIN,previous_files_verified=len(manifest),primary_signed_force_rows=384,
        weak_field_histories=12,independent_virtual_vectors=len(virtual),direct_gas_snapshots=6,
        largest_gas_correction_over_relative_drive=max(float(r['correction_over_wave_minus_baryon']) for r in source),
        highest_resolution_endpoint_time_checks='pass',full_history_gas_precision='not established',unchanged_tolerance=tol)


if __name__=='__main__':
    result=verify();seal=ROOT/'seal.json'
    files={p.relative_to(ROOT).as_posix():digest(p) for p in sorted(ROOT.rglob('*')) if p.is_file() and p!=seal}
    inventory=dict(**result,files=files)
    assert sys.argv[1:] in ([],['seal'])
    if sys.argv[1:]==['seal']:save('seal.json',(json.dumps(inventory,sort_keys=True,indent=2)+'\n').encode())
    assert json.loads(seal.read_bytes())==inventory
    print(json.dumps(result),len(files),digest(seal))
