from recoil_io import *
from itertools import product

def assess():
    guard();source=[];timing=[];requirement=[]
    old=read(ROOT/'direct-gas-base-all.csv');fine=read(ROOT/'direct-gas-fine-all.csv')
    comps=read(ROOT/'component-drives.csv')
    for case in (0,1):
        for model in MODELS:
            dg=0j;num=0j
            for gas in ('HI','H2'):
                def vec(row,key):
                    return complex(float(row[key+'_x']),-float(row[key+'_y']))
                current=next(r for r in fine if r['component']==gas and r['model']==model)
                coarse=next(r for r in old if r['component']==gas and r['model']==model)
                group=[r for r in comps if int(r['case'])==case and r['model']==model]
                weight=float(next(r['mass'] for r in group if r['component']==gas))/sum(float(r['mass']) for r in group)
                dg+=weight*(vec(current,'direct')-vec(current,'projected'))
                num+=weight*(vec(current,'direct')-vec(coarse,'direct'))
            with np.load(ROOT/f'state-{case}-16-{model}.npz') as p:
                actual=p['ordinary_external_delta'][-1];ext=p['external_relative'][-1]
            source.append(dict(case=case,model=model,added_bary_ax=dg.real,added_bary_ay=-dg.imag,
                gas_refinement_over_ordinary_difference=abs(num)/abs(actual),correction_over_ordinary_difference=abs(dg)/abs(actual),
                correction_over_wave_minus_baryon=abs(dg)/abs(ext),corrected_external_relative=abs(ext-dg)))
            for lo,hi in ([(8,16),(16,32)] if model=='L2M11' else [(8,16)]):
                with np.load(ROOT/f'state-{case}-{lo}-{model}.npz') as aa,np.load(ROOT/f'state-{case}-{hi}-{model}.npz') as bb:
                    assert np.array_equal(aa['time'],bb['time'][::2]);x=aa['wave_minus_baryon'];y=bb['wave_minus_baryon'][::2]
                    timing.append(dict(case=case,model=model,coarse=lo,fine=hi,final_relative=abs(x[-1]-y[-1])/abs(y[-1]),
                                       trace_over_peak=max(abs(x-y))/max(abs(y))))
        gains=read(ROOT/f'sky-error-gains-{case}.csv')
        for row in read(ROOT/f'sky-{case}-16.csv'):
            if row['frame']!='site_minus_point' or row['background']!='mts' or row['inside']=='True':continue
            g=next(r for r in gains if all(r[k]==row[k] for k in ('frame','R','z','component')))
            missing=max(float(row['low'])-float(row['total']),float(row['total'])-float(row['high']))
            requirement.append(dict(case=case,model=row['model'],R=row['R'],z=row['z'],component=row['component'],
                        necessary_accel_error_impulse_kms=missing/float(g['response_bound_per_kms'])))
    table('direct-gas-impact.csv',source);table('time-refinements.csv',timing);table('minimum-source-error-impulses.csv',requirement)
if __name__=='__main__':assess()
