import os,sys,hashlib,json,csv,io
from pathlib import Path
for key in ('OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','OMP_NUM_THREADS','BLIS_NUM_THREADS','NUMEXPR_NUM_THREADS'):
    os.environ[key]='1'
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parent
AX=ROOT.parent/'mts-lmc-fixed-occupation-axisymmetric-20261119'
LMC=ROOT.parent/'mts-lmc-tidal-history-20261119'
BAR=ROOT.parent/'mts-finite-bar-mean-response-20261119'
PIN='a46d251285faaba640cea0288634284d6d3046a9693e934921a28936060c6f70'
def digest(path):
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
def guard():
    assert digest(AX/'seal.json')==PIN and not any((folder/'STOP-REQUESTED').exists() for folder in (ROOT,ROOT.parent,AX,LMC,BAR))
def save(name,raw):
    guard();path=ROOT/name;path.parent.mkdir(parents=True,exist_ok=True)
    if path.exists():
        assert digest(path)==hashlib.sha256(raw).hexdigest(),name
    else:
        with path.open('xb') as stream:stream.write(raw)
def table(name,rows):
    buf=io.StringIO(newline='');writer=csv.DictWriter(buf,rows[0].keys(),lineterminator='\n');writer.writeheader();writer.writerows(rows)
    save(name,buf.getvalue().encode())
def read(path):
    with path.open(encoding='utf8',newline='') as src:return list(csv.DictReader(src))
def packet(name,**fields):
    buf=io.BytesIO();np.savez_compressed(buf,**fields);save(name,buf.getvalue())
sys.path[:0]=[str(AX),str(LMC),str(BAR)]
import numpy as np
from lmc_field import MODELS,TAGS,history,positions,GYR
