from quad_io import *
from axis_operator import background,sky_map
from scipy.sparse.linalg import splu
from scipy import sparse as sp
from scipy.special import comb
from pulse_space import basis
from quad_evolve import radial_map,angular_kernel
from axis_requirement import box_min
from itertools import product

def shifted_tangent(bg):
    surface=bg.ground.ravel();size=len(surface);column=sp.csc_matrix(surface[:,None])
    coupling=2**.5*bg.coupling;step=sp.eye(size,format='csc');result=None
    for shift in (0.,1.5,1.,.5,.25,.125,.0625,.03125,.015625):
        matrix=sp.bmat([[bg.hzero-shift*step,coupling,column],[coupling.T,bg.grav,None],[column.T,None,sp.csc_matrix((1,1))]],format='csc')
        trial=splu(matrix,permc_spec='MMD_AT_PLUS_A',diag_pivot_thresh=0.,options={'Equil':False,'SymmetricMode':True})
        assert np.array_equal(trial.perm_r,trial.perm_c)
        order=np.argsort(trial.perm_r);pivot=trial.U.diagonal()
        back=trial.L@trial.U-matrix[order,:][:,order];sym=trial.U-sp.diags(pivot)@trial.L.T
        err=max(np.max(abs(back.data))/np.max(abs(matrix.data)),np.max(abs(sym.data),initial=0.)/np.max(abs(trial.U.data)))
        assert err<1e-9 and np.min(abs(pivot))>1e-10
        if shift==0:
            assert (pivot<0).sum()==1;result=trial
        elif (pivot<0).sum()==1:return result,shift,err
    raise ArithmeticError('missing coercive fixed-number shift')

def bands(prior,tag,model,allow_odd):
    bounds=[]
    for radius,component in product((6.,8.3),('radial','polar')):
        corrections=[]
        for height in (1.5,-1.5):
            item=next(row for row in prior if row['tag']==tag and row['model']==model and row['background']=='mts' and float(row['R'])==radius and float(row['z'])==height and row['component']==component)
            sign=-1 if component=='polar' and height<0 else 1
            reference=float(item['base'])+float(item['direct'])
            corrections.append(sorted(sign*(float(item[key])-reference) for key in ('obs_low','obs_high')))
        bounds.append(np.mean(corrections,axis=0) if allow_odd else [max(pair[0] for pair in corrections),min(pair[1] for pair in corrections)])
    return np.array(bounds).T

def joint(case):
    guard();tag=TAGS[case];bg=background(case);ground=bg.ground.ravel();size=len(ground)
    fixed=read(LMC/'present-sky.csv')
    axis_force=2*np.asarray(bg.coupling@sky_map(bg)[[0,1,3,4]].T)
    factor,shift,defect=shifted_tangent(bg)
    sol=factor.solve(np.vstack([axis_force,np.zeros((bg.grav.shape[0]+1,4))]))[:size]
    axis_gram=axis_force.T@sol;axis_gram=(axis_gram+axis_gram.T)/2
    with np.load(ROOT/f'operators/{case}-64.npz') as op:
        inds=[0,1,3,4];full=op['gram_full'][np.ix_(inds,inds)]
        quad_gram=2*(full+full.T)
        incident_basis=angular_kernel(op,24)
    assert np.linalg.eigvalsh(axis_gram)[0]>0 and np.linalg.eigvalsh(quad_gram)[0]>0
    packet(f'joint-response-grams-{case}.npz',axis=axis_gram,quadrupole=quad_gram,
           readout=np.array(['radial6','polar6','radial8','polar8']))
    quad=read(ROOT/f'external-budget-{case}-r192-l24-t16.csv')
    lowest=read(LMC/'response-n6144.csv')
    with np.load(BAR/(tag+'-external-kernel.npz')) as pk:sigma=float(pk['sigma']);wave=pk['mode_vector'].reshape(bg.hshape)
    sample=np.arange(5)/4;bern=np.stack([comb(4,j)*sample**j*(1-sample)**(4-j) for j in range(5)],axis=1)
    convert=np.diff(np.linalg.inv(bern),axis=0)
    angular=np.einsum('ra,ab,bc,b,bd->rcd',bg.ground,bg.harm.T,bg.harm,bg.aw,basis(np.arange(0,41,2),0,bg.mu),optimize=True)/bg.vel**2
    all_rows=[]
    for model in MODELS:
        with np.load(ROOT/f'sources/{model}-r192-l24-q28-t16.npz') as src:
            interpolation=radial_map({'rad':bg.rad*bg.length},src['radius'])
            kernel=np.einsum('rs,ra,ral->sl',interpolation,wave,incident_basis,optimize=True)
            lowest_drive=src['V'].reshape(-1,kernel.size)@kernel.ravel()
        with np.load(AX/f'shell-{model}-r320-l40-q36-t16.npz') as src:times=src['time'];V=src['V'];grid=src['radius']
        radial=radial_map({'rad':bg.rad*bg.length},grid)
        def field(idx):
            sampled=np.einsum('rs,tsl->trl',radial,V[idx],optimize=True)
            raw=np.einsum('trl,ral->tra',sampled,angular,optimize=True).reshape(len(idx),-1)
            return raw-(raw@ground/bg.mass)[:,None]*ground
        def upper(idx):
            return np.linalg.norm(field(idx),axis=1)/np.sqrt(shift)
        state=next(row for row in lowest if row['tag']==tag and row['model']==model and row['source']=='full' and row['start']=='zero' and float(row['start_native'])==times[0])
        low_energy=(sigma**2*(float(state['displacement_re'])**2+float(state['displacement_im'])**2)+float(state['velocity_re'])**2+float(state['velocity_im'])**2)/2
        for step in (1,2):
            samples=np.arange(0,len(times),step);blocks=(len(samples)-1)//4;norm=upper(samples[[0,-1]]).sum()
            for start in range(0,blocks,16):
                stop=min(start+16,blocks);fields=field(samples[start*4:stop*4+1])
                selected=fields[np.arange(stop-start)[:,None]*4+np.arange(5)]
                derivatives=np.einsum('ij,bjd->bid',convert,selected,optimize=True).reshape(-1,size)
                norm+=np.sum(np.linalg.norm(derivatives,axis=1))/np.sqrt(shift)
            axis_ceiling=norm**2
            other=next(row for row in quad if row['model']==model and int(row['substeps'])==16//step and row['allow_odd']=='False')
            first=lowest_drive[samples]
            diffs=convert@first[np.arange(blocks)[:,None]*4+np.arange(5)].T
            low_ceiling=2*((abs(first[0])+abs(first[-1])+abs(diffs).sum())/sigma)**2
            assert low_energy<low_ceiling
            quad_ceiling=float(other['whole_mesh_source_energy_ceiling'])+low_ceiling
            for relax in (False,True):
                low,high=bands(fixed,tag,model,relax)
                pooled=2*(axis_ceiling*axis_gram+2*quad_ceiling*quad_gram)
                _,_,direction=box_min(pooled,low,high);direction/=np.linalg.norm(direction)
                projected=np.maximum(direction,0)@low+np.minimum(direction,0)@high
                axis_max=np.sqrt(axis_ceiling*(direction@axis_gram@direction))
                quad_max=np.sqrt(2*quad_ceiling*(direction@quad_gram@direction))
                all_rows.append(dict(model=model,allow_odd=relax,substeps=16//step,fixed_number_shift=shift,factor_defect=defect,
                    axis_energy_ceiling=axis_ceiling,low_mode_energy=low_energy,low_mode_ceiling=low_ceiling,all_m2_energy_ceiling=quad_ceiling,
                    required_projected_force=projected,axis_force_ceiling=axis_max,m2_force_ceiling=quad_max,
                    required_over_combined_ceiling=projected/(axis_max+quad_max),
                    witness_6r=direction[0],witness_6p=direction[1],witness_8r=direction[2],witness_8p=direction[3]))
        print('joint',case,model,all_rows[-2]['required_over_combined_ceiling'],flush=True)
    table(f'joint-even-source-budget-{case}.csv',all_rows)
if __name__=='__main__':joint(int(sys.argv[1]))
