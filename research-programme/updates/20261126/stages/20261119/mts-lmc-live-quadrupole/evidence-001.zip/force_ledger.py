from quad_io import *

def run():
    guard()
    input_sky=read(LMC/'present-sky.csv');prior=read(AX/'final-force-comparison.csv')
    key=lambda row,orbit:(row['tag'],row[orbit],row['background'],row['component'],row['R'],row['z'])
    original={key(row,'model'):row for row in input_sky}
    axis={key(row,'history'):row for row in prior};output=[]
    for case in (0,1):
        for row in read(ROOT/f'sky/{case}-64-r192-l24-t16-d1.csv'):
            if row['initial_of_remaining']!='zero':continue
            index=key(row,'model');earlier=original[index];circle=axis[index]
            base=float(earlier['base']);direct=float(earlier['direct']);lowest=float(earlier['induced_tracked_mode'])
            even=float(circle['axis_response']);remaining=float(row['new']);value=float(row['total'])
            assert abs((base+direct+lowest+even+remaining)-value)<1e-12
            lo,hi=float(row['low']),float(row['high'])
            need=lo-base if base<lo else (hi-base if base>hi else None)
            output.append(dict(tag=row['tag'],orbit=row['model'],background=row['background'],R=row['R'],z=row['z'],component=row['component'],
                stationary=base,direct_satellite=direct,lowest_m2=lowest,fixed_number_m0=even,remaining_m2=remaining,
                total=value,low=lo,high=hi,inside=row['inside'],signed_change_over_stationary_gap='' if need is None else (value-base)/need))
    table('combined-force-ledger.csv',output)
if __name__=='__main__':run()
