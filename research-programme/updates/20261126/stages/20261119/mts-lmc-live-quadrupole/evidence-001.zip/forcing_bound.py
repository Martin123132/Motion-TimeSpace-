from quad_io import *
from pulse_space import sp,splu
from axis_operator import background
from quad_evolve import angular_kernel,radial_map
from incident import name
from scipy.special import comb
from scipy import linalg

def lower_guard(bg):
    mix=2**.5*bg.bm
    def matrix(shift):
        return sp.bmat([[bg.hm-shift*sp.eye(bg.hm.shape[0],format='csc'),mix],[mix.T,bg.lm]],format='csc')
    def factorized(shift):
        mat=matrix(shift)
        fac=splu(mat,permc_spec='MMD_AT_PLUS_A',diag_pivot_thresh=0.,options={'Equil':False,'SymmetricMode':True})
        assert np.array_equal(fac.perm_r,fac.perm_c)
        pivot=fac.U.diagonal();order=np.argsort(fac.perm_r)
        diff=fac.L@fac.U-mat[order,:][:,order];sym=fac.U-sp.diags(pivot)@fac.L.T
        error=max(np.max(abs(diff.data))/np.max(abs(mat.data)),np.max(abs(sym.data),initial=0.)/np.max(abs(fac.U.data)))
        assert error<1e-9 and np.min(abs(pivot))>1e-10
        return fac,np.min(pivot)>0,error
    original,pos,_=factorized(0.)
    assert pos
    for shift in (1.5,1.,.5,.25,.125,.0625,.03125):
        _,pos,err=factorized(shift)
        if pos:return original,shift,err
    raise ArithmeticError('no certified positive mass shift')

def run(case,count,res,ell,nq,sub):
    guard();assert case in (0,1)
    bg=background(case);tag=TAGS[case]
    fac,lower,fac_error=lower_guard(bg)
    with np.load(BAR/(tag+'-external-kernel.npz')) as low:
        mode=low['mode_vector'];dual=low['conjugate_vector']
    with np.load(ROOT/f'operators/{case}-{count}.npz') as data:
        op={key:data[key] for key in ('ground','mu','aw','vel','rad')}
    assert abs(mode@dual-1)<1e-10
    ang=angular_kernel(op,ell);rule=read(ROOT/f'budget/{case}-{count}-r{res}-l{ell}-t{sub}-d1.csv')
    sample=np.arange(5)/4;bern=np.stack([comb(4,j)*sample**j*(1-sample)**(4-j) for j in range(5)],axis=1)
    coeff=np.diff(np.linalg.inv(bern),axis=0);rows=[]
    for model in MODELS:
        with np.load(ROOT/name(model,res,ell,nq,sub)) as data:
            times=data['times'];radius=data['radius'];bank=data['V']
        radial=radial_map(op,radius)
        def field(idx):
            values=bank[idx];sampled=np.einsum('rs,tsl->trl',radial,values,optimize=True)
            src=np.einsum('trl,ral->tra',sampled,ang,optimize=True).reshape(len(idx),-1)
            return src-(src@mode)[:,None]*dual
        ids=np.unique(np.r_[np.linspace(0,len(times)-1,32,dtype=int),np.where(times>=-1)[0][::max(sub//2,1)],len(times)-1])
        examples=field(ids);examples=np.vstack([examples.real,examples.imag]).T
        candidates,values,_=linalg.svd(examples,full_matrices=False,lapack_driver='gesdd')
        candidates=np.ascontiguousarray(candidates[:,values>values[0]*1e-9])
        extend=np.vstack([candidates,np.zeros((bg.lm.shape[0],candidates.shape[1]))])
        inverse=fac.solve(extend)[:len(mode)]
        gram=candidates.T@inverse
        def enclose(vector):
            coords=vector@candidates;residual=vector-coords@candidates.T
            mapped=coords@inverse.T
            center=np.einsum('bi,bi->b',coords.conj()@gram,coords).real+2*np.einsum('bi,bi->b',mapped.conj(),residual).real
            gap=np.einsum('bi,bi->b',residual.conj(),residual).real/lower
            assert np.min(center+gap)>-1e-13
            return np.sqrt(np.maximum(center,0)),np.sqrt(np.maximum(center+gap,0))
        holdout=np.setdiff1d(np.linspace(1,len(times)-2,19,dtype=int),ids)[::3]
        check=field(holdout); trial=np.vstack([check.real,check.imag]);bounds=enclose(trial)
        oracle=fac.solve(np.vstack([trial.T,np.zeros((bg.lm.shape[0],len(trial)))]))[:len(mode)]
        measured=np.sqrt(np.einsum('bi,ib->b',trial,oracle))
        assert np.all(bounds[0]<=measured*(1+2e-9)) and np.all(bounds[1]>=measured*(1-2e-9))
        batch=16
        for step in (1,2):
            used=np.arange(0,len(times),step);blocks=(len(used)-1)//4
            assert 4*blocks+1==len(used)
            ends=enclose(field(used[[0,-1]]));lo=ends[0].sum();hi=ends[1].sum()
            for start in range(0,blocks,batch):
                stop=min(start+batch,blocks);fields=field(used[start*4:stop*4+1])
                selected=fields[np.arange(stop-start)[:,None]*4+np.arange(5)]
                delta=np.einsum('ij,bjd->bid',coeff,selected,optimize=True)
                weaker,stronger=enclose(delta.reshape(-1,len(mode)))
                lo+=sum(weaker);hi+=sum(stronger)
            for relax in (False,True):
                item=next(row for row in rule if row['model']==model and row['allow_odd']==str(relax));needed=float(item['required_energy'])
                upper=2*hi**2
                rows.append(dict(model=model,allow_odd=relax,substeps=sub//step,minimum_energy=needed,actual_reduced_energy=item['propagated_energy'],
                      whole_mesh_source_energy_ceiling=upper,minimum_over_ceiling=needed/upper,spatial_ceiling_lo=2*lo**2,
                      relative_bracket_width=1-(lo/hi)**2,positive_shift=lower,symmetric_factor_defect=fac_error,
                      independent_direct_solves=len(trial),source_span=candidates.shape[1]))
        print('forcing envelope',case,model,rows[-2]['minimum_over_ceiling'],flush=True)
    table(f'external-budget-{case}-r{res}-l{ell}-t{sub}.csv',rows)
if __name__=='__main__':run(*map(int,sys.argv[1:]))
