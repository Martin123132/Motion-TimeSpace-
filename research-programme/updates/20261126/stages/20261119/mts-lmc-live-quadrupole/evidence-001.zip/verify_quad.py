from quad_io import *
from itertools import product
from math import isfinite,isclose

def validate():
    guard()
    manifest=json.loads((AX/'seal.json').read_bytes())
    assert len(manifest['files'])==227 and all(digest(AX/name)==value for name,value in manifest['files'].items())
    assert digest(LMC/'seal.json')==manifest['parent_seal']
    lm=json.loads((LMC/'seal.json').read_bytes())
    assert len(lm['files'])==1070 and all(digest(LMC/name)==value for name,value in lm['files'].items())
    def peak(rows,field):
        values=[abs(float(row[field])) for row in rows];assert values and all(map(isfinite,values))
        return max(values)
    def local(name):return read(ROOT/name)
    ref=read(AX/'final-force-comparison.csv')
    pack=[];tracked=[];bounds=[];joint_samples=[];complete_samples=[];control={}
    for case,tag in enumerate(TAGS):
        key=f'{case}-64-r192-l24-t16-d1'
        score=local(f'sky/{key}.csv')
        assert len(score)==192
        geometry={'6.0','8.3'};height={'1.5','-1.5'}
        for state_kind in ('zero','equilibrium_and_slope'):
            group=[row for row in score if row['initial_of_remaining']==state_kind]
            expected=set(product(MODELS,('mts','nfw'),geometry,height,('radial','polar')))
            assert len(group)==len(expected)==96 and {(r['model'],r['background'],r['R'],r['z'],r['component']) for r in group}==expected
            for row in group:
                old=next(r for r in ref if r['tag']==tag and r['history']==row['model'] and all(r[k]==row[k] for k in ('R','z','background','component')))
                assert float(row['previous'])==float(old['combined']) and all(row[k]==old[k] for k in ('low','high'))
                total=float(row['total']);delta=float(row['new'])
                assert total==float(row['previous'])+delta and isfinite(total)
                assert (row['inside']=='True')==(float(row['low'])<=total<=float(row['high']))
                if row['background']=='nfw':assert delta==0
            if state_kind=='zero':pack.extend(group)
        tracked.extend(local(f'recovery/{key}.csv'))
        scope=local(f'external-budget-{case}-r192-l24-t16.csv');assert len(scope)==24
        for row in scope:
            assert float(row['minimum_energy'])>0 and 0<float(row['actual_reduced_energy'])<=float(row['whole_mesh_source_energy_ceiling'])
            assert 0<=float(row['relative_bracket_width'])<.01 and int(row['independent_direct_solves'])>=4
            assert float(row['minimum_over_ceiling'])>1 and float(row['symmetric_factor_defect'])<1e-9
        bounds.extend(row for row in scope if row['substeps']=='16')
        jj=local(f'joint-even-source-budget-{case}.csv');assert len(jj)==24
        with np.load(ROOT/f'joint-response-grams-{case}.npz') as grams:
            axis_gram=grams['axis'];quad_gram=grams['quadrupole'];assert list(grams['readout'])==['radial6','polar6','radial8','polar8']
        for row in jj:
            witness=np.array([float(row[key]) for key in ('witness_6r','witness_6p','witness_8r','witness_8p')])
            assert abs(witness@witness-1)<1e-10 and float(row['factor_defect'])<1e-9
            from joint_budget import bands
            lower,upper=bands(read(LMC/'present-sky.csv'),tag,row['model'],row['allow_odd']=='True')
            minimum=np.maximum(witness,0)@lower+np.minimum(witness,0)@upper
            assert isclose(np.sqrt(float(row['axis_energy_ceiling'])*(witness@axis_gram@witness)),float(row['axis_force_ceiling']),rel_tol=1e-10)
            assert isclose(np.sqrt(2*float(row['all_m2_energy_ceiling'])*(witness@quad_gram@witness)),float(row['m2_force_ceiling']),rel_tol=1e-10)
            ceiling=float(row['axis_force_ceiling'])+float(row['m2_force_ceiling'])
            assert isclose(minimum,float(row['required_projected_force']),rel_tol=1e-10)
            assert ceiling>0 and isclose(minimum/ceiling,float(row['required_over_combined_ceiling']),rel_tol=1e-10)
        joint_samples.extend(row for row in jj if row['substeps']=='16')
        independent=local(f'complete-angular-test-{case}.csv');assert len(independent)==24
        for row in independent:
            original=next(r for r in jj if r['model']==row['model'] and r['allow_odd']==row['allow_odd'] and r['substeps']=='16')
            direction=np.array([float(original[key]) for key in ('witness_6r','witness_6p','witness_8r','witness_8p')])
            ceiling=np.sqrt(float(row['axis_energy_ceiling'])*(direction@axis_gram@direction))+np.sqrt(2*float(row['full_m2_energy_ceiling'])*(direction@quad_gram@direction))
            assert isclose(ceiling,float(row['combined_projected_ceiling']),rel_tol=1e-10)
            assert isclose(float(original['required_projected_force'])/ceiling,float(row['minimum_over_full_angular_ceiling']),rel_tol=1e-10)
            assert (int(row['axis_max_degree']),int(row['m2_max_degree']))==((36,38) if case==0 else (68,70))
        complete_samples.extend(row for row in independent if row['substeps']=='8')
        control[f'independent_ode_{case}']=peak(local(f'independent-multiple-mode-{case}.csv'),'relative_phase_error')
    control['direct_cartesian']=peak(local('source-controls.csv'),'relative_complex_shell_error')
    control['angular_complete_cartesian']=peak(local('complete-angular-cartesian.csv'),'whole_angular_shell_relative_error')
    control['analytic']=peak(local('exact-controls.csv'),'error')
    control['old_mode_full_complex_drive_L2']=peak(tracked,'relative_drive_L2')
    control['old_mode_final_phase_space']=peak(tracked,'lowest_phase_relative')
    assert max(control.values())<2e-5, control
    ledger=local('combined-force-ledger.csv');assert len(ledger)==len(pack)==192
    for row in ledger:
        assert isclose(sum(float(row[name]) for name in ('stationary','direct_satellite','lowest_m2','fixed_number_m0','remaining_m2')),
                       float(row['total']),abs_tol=1e-12)
        if row['background']=='nfw':assert all(float(row[name])==0 for name in ('lowest_m2','fixed_number_m0','remaining_m2'))
    sens=local('sensitivity.csv');assert len(sens)==2*5*2*4*6
    summary={name:peak([row for row in sens if row['test']==name],'relative_to_remainder') for name in {r['test'] for r in sens}}
    assert all(row['inside_unchanged']=='True' for row in sens)
    interior=local('spacetime-controls-r192-l24-t16.csv')
    assert len(interior)==24
    return dict(parent=PIN,previous_verified=(len(manifest['files'])+len(lm['files'])),primary_count=len(pack),controls=control,
                raw_shell_offgrid_max=peak(interior,'off_grid_relative'),numerical_sensitivities=summary,original_tolerance=2e-5,
                minimum_m2_only_energy_ratio=min(float(r['minimum_over_ceiling']) for r in bounds),
                minimum_joint_force_ratio=min(float(r['required_over_combined_ceiling']) for r in joint_samples),
                minimum_complete_angular_force_ratio=min(float(r['minimum_over_full_angular_ceiling']) for r in complete_samples))

if __name__=='__main__':
    result=validate();seal=ROOT/'seal.json'
    manifest={p.relative_to(ROOT).as_posix():digest(p) for p in sorted(ROOT.rglob('*')) if p.is_file() and p!=seal}
    inventory=dict(**result,files=manifest)
    if sys.argv[1:]==['seal']:save('seal.json',(json.dumps(inventory,sort_keys=True,indent=2)+'\n').encode())
    assert json.loads(seal.read_bytes())==inventory
    print(json.dumps(result,indent=2),len(manifest),digest(seal))
