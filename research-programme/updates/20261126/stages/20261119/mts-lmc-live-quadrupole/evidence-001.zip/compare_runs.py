from quad_io import *

def compare():
    guard();rows=[]
    for case in (0,1):
        primary=f'{case}-64-r192-l24-t16-d1'
        tests=[('radial_wave_basis',f'{case}-88-r192-l24-t16-d1'),('half_source_time_resolution',f'{case}-64-r192-l24-t8-d1'),
               ('half_source_radius_resolution',f'{case}-64-r192-l24-t16-d2'),('lower_incident_degree',f'{case}-64-r192-l16-t16-d1'),
               ('larger_outer_domain',f'{case+2}-64-r192-l24-t16-d1')]
        for label,key in tests:
            first=read(ROOT/'sky'/(primary+'.csv'));other=read(ROOT/'sky'/(key+'.csv'))
            for a,b in zip(first,other,strict=True):
                assert all(a[k]==b[k] for k in ('model','initial_of_remaining','component','R','z','background','previous'))
                if a['background']!='mts' or a['z']!='1.5':continue
                val=float(a['new']);change=abs(val-float(b['new']))
                rows.append(dict(case=case,model=a['model'],initial=a['initial_of_remaining'],R=a['R'],component=a['component'],
                    test=label,primary=val,comparison=b['new'],absolute_difference=change,relative_to_remainder=change/abs(val) if val else '',
                    inside_unchanged=a['inside']==b['inside']))
    table('sensitivity.csv',rows)
if __name__=='__main__':compare()
