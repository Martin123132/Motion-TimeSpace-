from quad_io import *
from pulse_space import basis
from scipy.special import roots_legendre
from lmc_field import potential

def run():
    guard();mu,weights=roots_legendre(192);phi=2*np.pi*(np.arange(384)+.371)/384
    phase=np.exp(-2j*phi);coords=np.stack(np.broadcast_arrays(np.sqrt(1-mu**2)[:,None]*np.cos(phi),np.sqrt(1-mu**2)[:,None]*np.sin(phi),mu[:,None]),axis=-1)
    azero=basis(np.arange(0,69,2),0,mu).T*(weights/2);atwo=basis(np.arange(2,71,2),2,mu).T*(weights/2)
    rows=[]
    for model,desired in [('L2M10',0.),('L3M10rad',-3.0234375)]:
        with np.load(ROOT/f'complete/{model}.npz') as pk:
            time=pk['times'];idx=np.argmin(abs(time-desired));epoch=time[idx];radii=pk['radius']
            zero=pk['axis'][idx];two=pk['quad'][idx]
        stamp,rr,profiles,tr=history(model);left=np.clip(np.searchsorted(stamp,epoch)-1,0,len(stamp)-2)
        mix=(epoch-stamp[left])/(stamp[left+1]-stamp[left]);shape=(1-mix)*profiles[left]+mix*profiles[left+1]
        place=positions(tr,epoch);center=potential(-place[None,:],rr,shape)[0]
        for rad in (6.,24.,51.,89.):
            ir=np.argmin(abs(radii-rad));value=potential(radii[ir]*coords-place,rr,shape)
            control0=azero@(value-center).mean(axis=1);control2=atwo@(value*phase).mean(axis=1)
            for mode,bank,reference in ((0,zero,control0),(2,two,control2)):
                error=np.linalg.norm(bank[ir]-reference)/np.linalg.norm(reference)
                rows.append(dict(model=model,epoch=epoch,radius=radii[ir],mode=mode,whole_angular_shell_relative_error=error))
    table('complete-angular-cartesian.csv',rows)
    assert max(row['whole_angular_shell_relative_error'] for row in rows)<2e-5,rows
if __name__=='__main__':run()
