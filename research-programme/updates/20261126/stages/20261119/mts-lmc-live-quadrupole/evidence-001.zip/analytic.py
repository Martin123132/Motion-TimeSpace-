from quad_io import *
from incident import project
from scipy.special import roots_legendre
from axis_response import integrate

def run():
    guard();knots=np.geomspace(200.,1000.,25);field=np.zeros((50,49));radii=np.array([4.,8.,29.,50.])
    center=np.array([18.,-44.,11.]);real=0.71;imag=-1.31;quad=roots_legendre(32)
    field[:25,8]=real*knots**2;field[25:,8]=2*real*knots**2
    field[:25,4]=imag*knots**2;field[25:,4]=2*imag*knots**2
    ans=project(center,knots,field,radii,24,quad)
    target=np.zeros_like(ans);target[:,0]=radii**2*(real-1j*imag)/np.sqrt(2)
    errors={'translated_tesseral_quadratic':np.max(np.abs(ans-target))/np.max(np.abs(target))}
    field[:]=0;field[:25,0]=27.;field[:25,3]=knots*1.47;field[25:,3]=knots*1.47
    null=project(center,knots,field,radii,24,quad)
    errors['constant_plus_uniform_acceleration']=np.max(abs(null))/np.linalg.norm(center)
    tau=np.linspace(-3.,0.,385);freq=np.array([.41,1.3,2.7,21.,97.5])
    src=np.array([2.+1j,1.7-.2j,-4.+3.8j,.3+1.6j,-2.4-.6j])
    drive=np.broadcast_to(src,(len(tau),len(src)))
    def answer(values):
        z=integrate(2*values,tau,freq)[-1]
        return z.real,z.imag*freq
    xr,vr=answer(drive.real);xi,vi=answer(drive.imag)
    errors['complex_static_drive_position']=max(abs(xr+1j*xi+2*src*(1-np.cos(3*freq))/freq**2))
    errors['complex_static_drive_velocity']=max(abs(vr+1j*vi+2*src*np.sin(3*freq)/freq))
    assert max(errors.values())<1e-10,errors
    table('exact-controls.csv',[dict(control=key,error=value) for key,value in errors.items()])
if __name__=='__main__':run()
