from quad_io import *
import ctypes
from scipy.special import roots_legendre,comb
from pulse_space import basis
from axis_operator import background
from quad_evolve import angular_kernel,radial_map
from incident import LIB,PTR,project
from shell_bank import shells
from joint_budget import bands
from axis_requirement import box_min

def bank(model):
    guard();key=f'complete/{model}.npz'
    if (ROOT/key).exists():
        with np.load(ROOT/key) as saved:
            assert saved['axis'].shape[-1]==35 and saved['quad'].shape[-1]==35
        return
    full=ctypes.CDLL(str(ROOT/'full_angular.dll'));full.quadrupole.argtypes=LIB.quadrupole.argtypes
    stamp,knots,shapes,traj=history(model);sub=8;ticks=np.linspace(stamp[0],0,(len(stamp)-1)*sub+1)
    radius=np.sinh(np.linspace(0,np.arcsinh(400/35),129))*35
    quadrature=roots_legendre(48);places=positions(traj,ticks)
    axis=np.empty((len(ticks),len(radius),35));quad=np.empty_like(axis,dtype=complex);replay=0.
    for index,place in enumerate(places):
        left=min(index//sub,len(stamp)-2);mix=index/sub-left;shape=np.ascontiguousarray(shapes[left]*(1-mix)+shapes[left+1]*mix)
        axis[index]=shells(place,knots,shape,radius,68,quadrature)
        error=full.quadrupole(np.ascontiguousarray(place),knots.copy(),shape,radius,len(radius),*quadrature,len(quadrature[0]),70,quad[index].view(float))
        assert error==0,error
        if index in (0,len(ticks)//2,len(ticks)-1):
            low=project(place,knots,shape,radius,24,quadrature)
            replay=max(replay,np.linalg.norm(low-quad[index,:,:12])/np.linalg.norm(low))
        if index%128==0:guard()
    assert replay<1e-10
    packet(key,times=ticks,radius=radius,axis=axis,quad=quad,low_projection_replay=replay)
    print('all angular inputs',model,flush=True)

def evaluate(case):
    guard();bg=background(case);tag=TAGS[case];nr,count=bg.ground.shape;g=bg.ground.ravel();quadtop=4*count-2;axistop=4*(count-1)
    primary=read(ROOT/f'joint-even-source-budget-{case}.csv')
    coefficient0=float(primary[0]['fixed_number_shift'])
    coefficient2=float(read(ROOT/f'external-budget-{case}-r192-l24-t16.csv')[0]['positive_shift'])
    with np.load(ROOT/f'joint-response-grams-{case}.npz') as saved:gram0=saved['axis'];gram2=saved['quadrupole']
    prior=read(LMC/'present-sky.csv')
    mu,aw=bg.mu,bg.aw
    kernel0=np.einsum('ra,ab,bc,b,bd->rcd',bg.ground,bg.harm.T,bg.harm,aw,basis(np.arange(0,axistop+1,2),0,mu),optimize=True)/bg.vel**2
    kernel2=angular_kernel({'mu':mu,'aw':aw,'vel':bg.vel,'ground':bg.ground},quadtop)
    rows=[];sample=np.arange(5)/4;bern=np.stack([comb(4,j)*sample**j*(1-sample)**(4-j) for j in range(5)],axis=1)
    convert=np.diff(np.linalg.inv(bern),axis=0)
    for model in MODELS:
        with np.load(ROOT/f'complete/{model}.npz') as data:
            times=data['times'];radius=data['radius'];zero=data['axis'][:,:,:axistop//2+1];two=data['quad'][:,:,:quadtop//2]
        radial=radial_map({'rad':bg.rad*bg.length},radius)
        budgets=[]
        for mode,source,kernel,lower in ((0,zero,kernel0,coefficient0),(2,two,kernel2,coefficient2)):
            def field(idx):
                v=np.einsum('rs,tsl->trl',radial,source[idx],optimize=True)
                body=np.einsum('trl,ral->tra',v,kernel,optimize=True).reshape(len(idx),-1)
                return body-(body@g/bg.mass)[:,None]*g if mode==0 else body
            bounds=[]
            for via in (1,2):
                sample_idx=np.arange(0,len(times),via);blocks=(len(sample_idx)-1)//4
                integrated=np.linalg.norm(field(sample_idx[[0,-1]]),axis=1).sum()
                for start in range(0,blocks,16):
                    stop=min(start+16,blocks);batch=field(sample_idx[4*start:4*stop+1])
                    deriv=np.einsum('ij,bjd->bid',convert,batch[4*np.arange(stop-start)[:,None]+np.arange(5)],optimize=True)
                    integrated+=np.linalg.norm(deriv.reshape(-1,nr*count),axis=1).sum()
                bounds.append((1 if mode==0 else 2)*integrated**2/lower)
            budgets.append(bounds)
        for idx,sub in enumerate((8,4)):
            ezero,etwo=budgets[0][idx],budgets[1][idx]
            for relax in (False,True):
                lo,hi=bands(prior,tag,model,relax)
                old=next(r for r in primary if r['model']==model and r['allow_odd']==str(relax) and int(r['substeps'])==16)
                direction=np.array([float(old[key]) for key in ('witness_6r','witness_6p','witness_8r','witness_8p')])
                rhs=np.maximum(direction,0)@lo+np.minimum(direction,0)@hi
                bound=np.sqrt(ezero*(direction@gram0@direction))+np.sqrt(2*etwo*(direction@gram2@direction))
                rows.append(dict(model=model,allow_odd=relax,substeps=sub,axis_max_degree=axistop,m2_max_degree=quadtop,axis_energy_ceiling=ezero,
                    full_m2_energy_ceiling=etwo,required_projected_force=rhs,combined_projected_ceiling=bound,
                    minimum_over_full_angular_ceiling=rhs/bound,previous_witness_used=True))
        print('complete degree test',case,model,rows[-4]['minimum_over_full_angular_ceiling'],flush=True)
    table(f'complete-angular-test-{case}.csv',rows)

if __name__=='__main__':
    if sys.argv[1]=='bank':
        for model in MODELS:bank(model)
    else:evaluate(int(sys.argv[1]))
