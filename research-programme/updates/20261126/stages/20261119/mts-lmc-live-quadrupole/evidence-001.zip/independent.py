from quad_io import *
from incident import name,project
from scipy.special import roots_legendre
from scipy.interpolate import CubicSpline
from scipy.integrate import solve_ivp
from quad_evolve import source_map

def spacetime(res,ell,nq,sub):
    guard();rows=[]
    for model in MODELS:
        stamp,knots,bank,tr=history(model)
        with np.load(ROOT/name(model,res,ell,nq,sub)) as data:
            times=data['times'];radii=data['radius'];shell=data['V']
        for fraction in (.15,.73,.98,.999):
            block=min(int((len(times)-1)*fraction)//4*4,len(times)-5)
            tau=times[block]+.37*(times[block+4]-times[block]);pts=times[block:block+5]
            w=np.array([np.prod((tau-np.delete(pts,j))/(t-np.delete(pts,j))) for j,t in enumerate(pts)])
            sample=np.array([2.7,6.,12.,35.,51.,73.,119.])
            target=CubicSpline(radii,np.einsum('t,trl->rl',w,shell[block:block+5]),axis=0)(sample)
            left=np.searchsorted(stamp,tau)-1;frac=(tau-stamp[left])/(stamp[left+1]-stamp[left])
            origin=project(positions(tr,tau),knots,(1-frac)*bank[left]+frac*bank[left+1],sample,ell,roots_legendre(42))
            rows.append(dict(model=model,epoch=tau,off_grid_relative=np.linalg.norm(target-origin)/np.linalg.norm(origin),
                             inner_two_relative=np.linalg.norm(target[:2]-origin[:2])/np.linalg.norm(origin[:2])))
    table(f'spacetime-controls-r{res}-l{ell}-t{sub}.csv',rows)

def ode(case,count,res,ell,nq,sub):
    guard();model='L2M10first'
    with np.load(ROOT/f'operators/{case}-{count}.npz') as data:op={key:data[key] for key in data.files}
    with np.load(ROOT/name(model,res,ell,nq,sub)) as data:times=data['times'];shell=data['V'];rs=data['radius']
    idx=np.array([0,1,2,5,11,23]);freq=op['freq'][idx]
    op['waves']=op['waves'][:,idx];drives=shell.reshape(len(times),-1)@source_map(op,rs,ell)
    tau=times*op['vel']/op['length'];step=tau[4]-tau[0]
    inv=np.linalg.inv(np.polynomial.polynomial.polyvander(np.arange(5)/4,4));ticks=np.arange(0,len(tau)-1,4)
    coeffs=np.einsum('jm,bmk->bjk',inv,drives[ticks[:,None]+np.arange(5)],optimize=True)
    def rhs(time,state):
        index=min(int(max((time-tau[0])/step,0)),len(ticks)-1);x=(time-tau[4*index])/step
        co=coeffs[index];force=((((co[4]*x+co[3])*x+co[2])*x+co[1])*x+co[0])
        return np.r_[state[len(idx):],-freq**2*state[:len(idx)]-2*force]
    sol=solve_ivp(rhs,(tau[0],tau[-1]),np.zeros(2*len(idx),complex),method='DOP853',rtol=2e-10,atol=1e-13,max_step=step*.51)
    assert sol.success
    with np.load(ROOT/f'states/{case}-{count}-{model}-r{res}-l{ell}-t{sub}-d1.npz') as data:pos=data['displacement'][idx];vel=data['velocity'][idx]
    err=np.hypot(abs(sol.y[:len(idx),-1]-pos),abs(sol.y[len(idx):,-1]-vel)/freq)
    norm=np.hypot(abs(pos),abs(vel)/freq)
    out=[dict(mode=int(q),frequency=s,absolute_phase_error=e,relative_phase_error=e/n) for q,s,e,n in zip(idx,freq,err,norm)]
    assert max(row['relative_phase_error'] for row in out)<2e-5,out
    table(f'independent-multiple-mode-{case}.csv',out)
if __name__=='__main__':
    if sys.argv[1]=='shell':spacetime(*map(int,sys.argv[2:]))
    else:ode(*map(int,sys.argv[1:]))
