from quad_io import *
from scipy.special import roots_legendre
from pulse_space import basis
from lmc_field import potential
from ctypes import CDLL,c_int
PTR=np.ctypeslib.ndpointer(dtype=np.float64,flags='C_CONTIGUOUS')
LIB=CDLL(str(ROOT/'source_quadrupole.dll'))
LIB.quadrupole.argtypes=[PTR,PTR,PTR,PTR,c_int,PTR,PTR,c_int,c_int,PTR]
def project(place,knots,shape,radius,ell,quad):
    raw=np.empty((len(radius),ell//2,2));nodes,weights=quad
    status=LIB.quadrupole(*(np.ascontiguousarray(v,dtype=float) for v in (place,knots,shape,radius)),len(radius),nodes,weights,len(nodes),ell,raw)
    if status:raise ValueError(('projection failed',status))
    return raw.view(np.complex128)[:,:,0]
def check():
    out=[];mu,weights=roots_legendre(128);phi=2*np.pi*(np.arange(256)+.17)/256
    coords=np.stack(np.broadcast_arrays(np.sqrt(1-mu**2)[:,None]*np.cos(phi),np.sqrt(1-mu**2)[:,None]*np.sin(phi),mu[:,None]),axis=-1)
    angular=basis(np.arange(2,25,2),2,mu).T*(weights/2)
    for model,epoch in [('L2M10',0.),('L3M10rad',-3.01953125)]:
        times,radii,fields,tr=history(model);place=positions(tr,epoch);idx=np.clip(np.searchsorted(times,epoch)-1,0,len(times)-2)
        blend=(epoch-times[idx])/(times[idx+1]-times[idx]);shape=(1-blend)*fields[idx]+blend*fields[idx+1]
        probes=np.array([6.,24.,51.,89.]);fast=project(place,radii,shape,probes,24,roots_legendre(32))
        for radius,estimate in zip(probes,fast):
            direct=angular@((potential(radius*coords-place,radii,shape)*np.exp(-2j*phi)).mean(axis=1))
            err=np.linalg.norm(estimate-direct)/np.linalg.norm(direct)
            out.append(dict(model=model,epoch=epoch,radius=radius,relative_complex_shell_error=err))
    assert max(v['relative_complex_shell_error'] for v in out)<2e-5,out
    table('source-controls.csv',out)
def name(model,res,ell,nq,sub):return f'sources/{model}-r{res}-l{ell}-q{nq}-t{sub}.npz'
def run(model,res,ell,nq,sub):
    guard();stamp,knots,shapes,tr=history(model);ticks=np.linspace(stamp[0],0,(len(stamp)-1)*sub+1)
    rs=np.sinh(np.linspace(0,np.arcsinh(400/35),res+1))*35;places=positions(tr,ticks);quad=roots_legendre(nq)
    src=np.empty((len(ticks),len(rs),ell//2),complex)
    for idx,place in enumerate(places):
        left=min(idx//sub,len(stamp)-2);mix=idx/sub-left
        src[idx]=project(place,knots,shapes[left]*(1-mix)+shapes[left+1]*mix,rs,ell,quad)
        if idx%128==0:guard()
    packet(name(model,res,ell,nq,sub),radius=rs,times=ticks,V=src)
    print(model,src.shape,flush=True)
if __name__=='__main__':
    if sys.argv[1]=='check':check()
    else:
        for model in (MODELS if sys.argv[1]=='all' else [sys.argv[1]]):run(model,*map(int,sys.argv[2:]))
