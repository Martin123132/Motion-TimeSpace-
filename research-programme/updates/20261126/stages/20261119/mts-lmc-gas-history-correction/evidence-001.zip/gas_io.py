import os,sys,json,hashlib,csv,io
from pathlib import Path
from functools import lru_cache
for setting in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','BLIS_NUM_THREADS'):
    os.environ[setting]='1'
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
PARENT=HERE.parent/'mts-lmc-ordinary-centre-recoil-20261119'
PIN='0c76b4493090e03b0afcd95ae1f886d34e590022217e5114ddca6ce2ef787bcf'
sys.path.insert(0,str(PARENT))
from recoil_io import np,read,digest,MODELS,LAST,roots_legendre,UNIT,MASS
from lmc_field import history,positions
from direct_gas import gases,lib
def guard():
    assert digest(PARENT/'seal.json')==PIN
    assert not any((r/'STOP-REQUESTED').exists() for r in (HERE,HERE.parent,PARENT,LAST))
def save(file,raw):
    guard();p=HERE/file;p.parent.mkdir(exist_ok=True,parents=True)
    if p.exists():assert digest(p)==hashlib.sha256(raw).hexdigest(),file
    else:
        with p.open('xb') as fd:fd.write(raw)
def packet(file,**arrays):
    buf=io.BytesIO();np.savez_compressed(buf,**arrays);save(file,buf.getvalue())
def table(file,rows):
    buf=io.StringIO(newline='');out=csv.DictWriter(buf,rows[0],lineterminator='\n');out.writeheader();out.writerows(rows);save(file,buf.getvalue().encode())
