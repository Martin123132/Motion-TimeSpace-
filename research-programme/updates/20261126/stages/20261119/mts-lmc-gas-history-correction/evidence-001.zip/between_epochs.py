from propagate_gas import discrepancy,bernstein,INVERSE
from gas_history import *
from centroid_source import derivative,project
from lmc_field import positions

def freeze(model):
    obj=archive(model);tt,signal,_=discrepancy(model,16,0)
    with np.load(PARENT/f'drive-0-{model}.npz') as p:
        orig=p['component_differential'][:,list(p['names']).index('HI')]
    rows=[]
    for k in range(len(obj.stamps)-1):
        base=k*16
        ranked=[abs(np.diff(orig[base+off:base+off+5],n=4)[0]) for off in (0,4,8,12)]
        j=base+4*int(np.argmax(ranked))
        frac=np.sqrt(2)-1 if k%2 else (3-np.sqrt(5))/2
        coeff=bernstein(frac)@INVERSE
        prediction=coeff@signal[j:j+5];epoch=tt[j]+frac*(tt[j+4]-tt[j])
        rows.append(dict(interval=k,start=j,fraction=frac,time=epoch,hi_real=prediction[0].real,hi_imag=prediction[0].imag,
            h2_real=prediction[1].real,h2_imag=prediction[1].imag))
    table(f'controls/frozen-{model}.csv',rows)
def check(model):
    guard();obj=archive(model);predpath=HERE/f'controls/frozen-{model}.csv';pin=digest(predpath);preds=read(predpath);rows=[]
    times=np.array([float(r['time']) for r in preds]);indices=np.array([int(r['interval']) for r in preds]);tr=history(model)[3]
    loc=positions(tr,times);frac=(times-obj.stamps[indices])/(obj.stamps[indices+1]-obj.stamps[indices])
    grads=derivative(-loc,obj.knots,obj.banks,indices,frac,.007)
    with np.load(PARENT/'weights-8-1.npz') as p:
        names=list(p['names']);ids=[names.index(k) for k in ('HI','H2')];grid=p['grid'];weights=p['weights'][ids]/p['masses'][ids,None,None]
    comps=[r for r in read(PARENT/'component-drives.csv') if int(r['case'])==0 and r['model']==model]
    mw=np.array([next(float(r['mass']) for r in comps if r['component']==g) for g in ('HI','H2')])/sum(float(r['mass']) for r in comps)
    for i,(row,pos,ix,t,grad) in enumerate(zip(preds,loc,indices,frac,grads)):
        if i%32==0:guard()
        shape=(1-t)*obj.banks[ix]+t*obj.banks[ix+1];raw=project(pos,obj.knots,shape,grid,25,gauss(28))
        raw[:,0]+=grad*grid/np.sqrt(6);previous=np.einsum('rl,grl->g',raw,weights)
        direct=np.array([force(pos,obj.knots,shape,grad,g,'main') for g in obj.gas])
        actual=(direct-previous)*mw
        guess=np.array([complex(float(row[g+'_real']),float(row[g+'_imag'])) for g in ('hi','h2')])
        rows.append(dict(interval=ix,time=row['time'],delta_x=actual.sum().real,delta_y=-actual.sum().imag,
            total_discrepancy=abs(actual.sum()-guess.sum()),hi_discrepancy=abs(actual[0]-guess[0]),h2_discrepancy=abs(actual[1]-guess[1]),
            frozen_sha256=pin))
    assert digest(predpath)==pin
    table(f'controls/independent-{model}.csv',rows)
if __name__=='__main__':
    for model in sys.argv[1:]:
        freeze(model);check(model);print('off-grid',model,flush=True)
