from compact import *
from centroid_source import derivative

BLOCK=128
@lru_cache(maxsize=3)
def archive(model,refine=False):
    obj=Archive(model)
    if refine:
        tr=history(model)[3]
        with np.load(PARENT/'time-midpoints-L2M11.npz') as p:
            obj.time=p['time'];obj.grad=p['grad']
        obj.pos=positions(tr,obj.time)
    return obj
def sample(obj,i,refine,level):
    if not refine:return obj.calc(i,level)
    left=i//16;t=(i%16+.5)/16;shape=obj.banks[left]*(1-t)+obj.banks[left+1]*t
    return np.array([force(obj.pos[i],obj.knots,shape,obj.grad[i],gas,level) for gas in obj.gas])
def run(model,refine=False):
    guard();obj=archive(model,refine);name='mid32' if refine else 'orig16'
    for first in range(0,len(obj.time),BLOCK):
        stop=min(first+BLOCK,len(obj.time));indices=np.arange(first,stop)
        path=f'packets/{model}-{name}-{first:04d}.npz'
        if (HERE/path).exists():
            with np.load(HERE/path) as p:
                assert np.array_equal(p['time'],obj.time[indices]) and all(p[k].shape==(len(indices),2) and np.isfinite(p[k]).all() for k in ('pilot','main'))
            continue
        guard();arrays={k:np.stack([sample(obj,i,refine,k) for i in indices]) for k in ('pilot','main')}
        packet(path,time=obj.time[indices],**arrays)
    print(model,name,'completed',len(obj.time),flush=True)
def collect(model,refine=False):
    name='mid32' if refine else 'orig16'
    files=sorted((HERE/'packets').glob(f'{model}-{name}-*.npz'))
    arrays={k:[] for k in ('time','pilot','main')}
    for path in files:
        with np.load(path) as p:
            for k in arrays:arrays[k].append(p[k])
    result={k:np.concatenate(val) for k,val in arrays.items()}
    assert np.array_equal(result['time'],archive(model,refine).time)
    return result

if __name__=='__main__':
    for model in sys.argv[1:]:
        if model=='midpoints':run('L2M11',True)
        else:assert model in MODELS;run(model)
