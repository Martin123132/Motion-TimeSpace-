from propagate_gas import *
from tidal_contrasts import ROWS,PROJ,weights,bounds
from recoil_io import PRE as QUAD
from xml.etree import ElementTree

def verify():
    guard();parent=json.loads((PARENT/'seal.json').read_bytes())['files']
    assert len(parent)==97 and all(digest(PARENT/key)==val for key,val in parent.items())
    test_transforms()
    budgets=read(HERE/'history-budget.csv');assert len(budgets)==12
    vertical=read(HERE/'vertical-tides.csv');nulls=read(HERE/'spherical-and-frame-null.csv')
    req=read(HERE/'tidal-gradient-requirement.csv');joint=read(HERE/'joint-frame-feasibility.csv')
    assert (len(vertical),len(nulls),len(req),len(joint))==(96,48,48,144)
    assert all(r['inside']=='True' for r in nulls)
    counts=off=0
    for model in MODELS:
        h=collect(model);finest=32 if model=='L2M11' else 16
        counts+=len(h['time'])
        if finest==32:counts+=len(collect(model,True)['time'])
        pred=read(HERE/f'controls/frozen-{model}.csv');checks=read(HERE/f'controls/independent-{model}.csv')
        assert len(pred)==len(checks)==(len(h['time'])-1)//16
        off+=len(checks);pin=digest(HERE/f'controls/frozen-{model}.csv')
        for i,(p,r) in enumerate(zip(pred,checks)):
            assert int(p['interval'])==int(r['interval'])==i and pin==r['frozen_sha256']
            t=float(r['time']);assert h['time'][16*i]<t<h['time'][16*(i+1)] and t not in h['time']
            estimate=sum(complex(float(p[k+'_real']),float(p[k+'_imag'])) for k in ('hi','h2'))
            actual=complex(float(r['delta_x']),-float(r['delta_y']))
            assert abs(abs(estimate-actual)-float(r['total_discrepancy']))<1e-15
        for case in (0,1):
            b=next(r for r in budgets if r['model']==model and int(r['case'])==case)
            assert float(b['impulse_low'])<=float(b['impulse_high']) and float(b['unphased_bound_pc'])>=float(b['centroid_change_pc'])
            assert int(b['sampled_times'])==(len(h['time'])-1)*finest//16+1
            for via in ([8,16,32] if finest==32 else [8,16]):
                suffix=f'{case}-{model}-{via}';out,=read(HERE/f'outputs/outcome-{suffix}.csv')
                sky=read(HERE/f'outputs/sky-{suffix}.csv')
                prior=[r for r in read(PARENT/f'sky-{case}-{via}.csv') if r['model']==model];assert len(sky)==len(prior)==32
                with np.load(HERE/f'outputs/state-{suffix}.npz') as p,np.load(PARENT/f'state-{case}-{via}-{model}.npz') as old:
                    assert np.array_equal(old['time'],p['time'][::4]) and all(np.isfinite(v).all() for v in p.values())
                    assert np.allclose(p['position'],old['wave_minus_baryon']+p['correction'],rtol=0,atol=1e-14)
                    assert abs(abs(p['position'][-1])*1000-float(out['present_pc']))<1e-10
                    assert np.allclose(p['external_relative'],old['external_relative']-p['source_main'][::4].sum(axis=1),rtol=0,atol=1e-13)
                    assert np.all(p['gas_position'][0]==0) and max(abs(p['correction']-p['gas_position'].sum(axis=1)))<1e-13
                    assert not np.all(p['source_main']==0)
                for row,a in zip(sky,prior):
                    assert all(row[k]==a[k] for k in ('R','z','component','background','frame','low','high','model'))
                    old_total=float(a['total']);new=float(row['corrected'])
                    assert float(row['old'])==old_total and abs(new-old_total-float(row['history_correction'])-float(row['instantaneous']))<1e-14
                    assert row['inside']==a['inside'] and (row['inside']=='True')==(float(row['low'])<=new<=float(row['high']))
                    assert float(row['any_phase_guard_margin'])>0
                    if row['background']=='nfw':
                        assert float(row['history_correction'])==0 and (row['frame']!='site_minus_point' or old_total==new)
            r=next(v for v in req if v['frame']=='site_minus_point' and v['background']=='mts' and v['model']==model and int(v['case'])==case)
            gap=float(r['inner_low'])-float(r['outer_high']);assert gap>0 and abs(gap/2.3-float(r['minimum_gradient_per_kpc']))<1e-12
            energy=read(HERE/f'joint-energy-{case}.csv');assert len(energy)==12
            saved=read(QUAD/f'joint-even-source-budget-{case}.csv');reference=read(QUAD/f'complete-angular-test-{case}.csv')
            with np.load(LAST/f'operators/{case}-64.npz') as op:
                rad=np.array([6.,6.,8.3,8.3]);proj=np.array([6.,1.5,8.3,1.5])/np.hypot(rad,1.5)
                readout=-2*op['sky'][[0,1,3,4]]+2*proj[:,None]*op['sky'][-1]
                for e in [v for v in energy if v['model']==model]:
                    er=next(v for v in saved if v['model']==model and v['substeps']=='16' and v['allow_odd']==e['allow_odd'])
                    direction=np.array([float(er[k]) for k in ('witness_6r','witness_6p','witness_8r','witness_8p')])
                    ref=[v for v in reference if v['model']==model and v['allow_odd']==e['allow_odd']]
                    assert all(float(e['m0_m2_ceiling'])>=float(v['combined_projected_ceiling'])-1e-10 for v in ref)
                    gram=np.sum(((direction@readout)/op['freq'])**2);co=float(e['m1_energy_ceiling'])
                    assert float(e['m1_actual_energy'])<=co==min(float(e[k]) for k in ('drive_area_ceiling','static_variation_ceiling'))
                    assert abs(float(e['all_ceiling'])-float(e['m0_m2_ceiling'])-np.sqrt(2*co*gram))<1e-10
                    assert float(e['required_over_all_ceiling'])>1
    assert counts==17158 and off==912
    controls=read(HERE/'spatial-controls.csv');assert {r['model'] for r in controls}==set(MODELS) and sum(bool(r['extra_full_absolute']) for r in controls)>=36
    assert all(float(r['scaled_error'])<2e-5 for r in read(HERE/'analytic-controls.csv') if r['level']!='pilot')
    assert all(float(r['endpoint_total_relative'])<2e-5 for r in read(HERE/'time-controls.csv') if r['model']!='L2M11' or r['to_steps']=='32')
    assert all(float(r['relative_eq_difference'])<2e-5 for case in (0,1) for r in read(HERE/f'terminal-checks-{case}.csv'))
    assert all((r['feasible']=='True')==(r['test']=='constant_plus_spherical' or (r['test']=='affine_symmetric' and r['background']=='nfw')) for r in joint)
    assert ElementTree.parse(HERE/'TIDAL-READOUT.svg').getroot().tag.endswith('svg')
    return dict(parent_seal=PIN,verified_parent_files=len(parent),actual_source_times=counts,non_grid_checks=off,
                primary_component_rows=384,curvature_gradient_required_on_both_mts_grounds=True,
                mode_budget='full retained m=0 and m=2 meshes, retained finite m=1 basis and original degree-25 wave drive',
                absolute_physical_continuum_error_proved=False,tolerance=2e-5)

if __name__=='__main__':
    result=verify();seal=HERE/'seal.json'
    files={p.relative_to(HERE).as_posix():digest(p) for p in sorted(HERE.rglob('*')) if p.is_file() and p!=seal}
    manifest=dict(**result,files=files)
    assert sys.argv[1:] in ([],['seal'])
    if sys.argv[1:]==['seal']:save('seal.json',(json.dumps(manifest,sort_keys=True,indent=2)+'\n').encode())
    assert json.loads(seal.read_bytes())==manifest
    print(json.dumps(result),len(files),digest(seal))
