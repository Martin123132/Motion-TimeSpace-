from propagate_gas import *
def tight(time,signal,parts=16):
    hh=time[4]-time[0]
    polys=panels(signal)@INVERSE.T;lo=hi=0.
    for idx in range(parts):
        split=polys@(INVERSE@bernstein((idx+NODES)/parts)).T
        lo+=np.sum(abs(split.mean(axis=1)))*hh/parts
        hi+=np.sum(abs(split).mean(axis=1))*hh/parts
    return lo,hi
def run():
    values=[];timing=[];panelsum=[]
    for case in (0,1):
        cg=next(float(r['centroid_pc_per_kms']) for r in read(PARENT/'centroid-error-gains.csv') if int(r['case'])==case)
        for model in MODELS:
            finest=32 if model=='L2M11' else 16
            for via in ((8,16,32) if finest==32 else (8,16)):
                with np.load(HERE/f'outputs/state-{case}-{model}-{via}.npz') as p:
                    time=p['time'];signal=p['source_main'].sum(axis=1);pilot=p['source_pilot'].sum(axis=1)
                    trace=p['position'];cor=p['correction'];component=p['gas_position'][-1]
                priv=read(HERE/f'outputs/outcome-{case}-{model}-{via}.csv')[0]
                if via==finest:
                    low,upper=tight(time,signal);sensitivity=tight(time,signal-pilot)[1]
                    spatial=read(HERE/'spatial-controls.csv');source=read(HERE/f'controls/independent-{model}.csv')
                    masses=read(PARENT/'component-drives.csv')
                    ratios=[sum(float(r['mass']) for r in masses if r['model']==model and int(r['case'])==c) for c in (0,1)]
                    factor=1. if not case else ratios[0]/ratios[1]
                    use=[r for r in spatial if r['model']==model and r['extra_full_absolute']!='']
                    assert len(source)==(len(time)-1)//finest
                    values.append(dict(case=case,model=model,via=via,sampled_times=len(time),source_epochs=len(source)+1,
                        frozen_offgrid_tests=len(source),offgrid_max_accel_discrepancy=factor*max(float(r['total_discrepancy']) for r in source),
                        max_extra_full_per_gas=max(float(r['extra_full_absolute']) for r in use),
                        impulse_low=low,impulse_high=upper,unphased_bound_pc=upper*cg,
                        centroid_change_pc=1000*abs(cor[-1]),HI_change_pc=1000*abs(component[0]),H2_change_pc=1000*abs(component[1]),
                        spatial_bound_difference_pc=sensitivity*cg,total_final_pc=1000*abs(trace[-1]),peak_applied_error=max(abs(signal)),
                        largest_sky_change=priv['largest_sky_change']))
                    for n in range(0,len(time)-1,finest):
                        sl=slice(n,n+finest+1);ll,uu=norm_bounds(time[sl],signal[sl])
                        panelsum.append(dict(case=case,model=model,via=via,t0=time[n],t1=time[n+finest],low=ll,high=uu))
                if via>8:
                    up=tight(time,signal-lift(last_source))[1]
                    timing.append(dict(case=case,model=model,from_steps=via//2,to_steps=via,
                        input_difference_integral_upper=up,delta_bound_pc=up*cg,
                        endpoint_delta_pc=1000*abs(cor[-1]-last_cor),endpoint_total_relative=abs(trace[-1]-last_trace[-1])/abs(trace[-1]),
                        common_time_total_over_peak=max(abs(trace[::2]-last_trace))/max(abs(trace)),
                        endpoint_correction_relative=abs(cor[-1]-last_cor)/abs(cor[-1])))
                    assert abs(cor[-1]-last_cor)*1000<up*cg*(1+1e-9)+1e-11
                last_trace=trace;last_cor=cor[-1];last_source=signal
    table('history-budget.csv',values);table('time-controls.csv',timing);table('per-interval-impulse.csv',panelsum)
if __name__=='__main__':run()
