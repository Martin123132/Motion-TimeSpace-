from gas_io import *
from propagate_gas import panels
from scipy.linalg import eigh
def end_modes(time,source,sigma,vel,length):
    hh=(time[4]-time[0])*vel/length;x=hh*sigma;z=-1j*x
    phase=np.exp(1j*(time[-1]-time[:-1:4,None])*vel/length*sigma)
    points=np.linspace(0.,1.,5);coeff=panels(source)/(vel**2/length)@np.linalg.inv(np.vander(points,5,increasing=True)).T
    nodes,wg=roots_legendre(12);nodes=(nodes+1)/2;wg/=2;mask=x<1
    values=-np.expm1(z)/(1j*x);q=np.zeros(len(x),complex);v=np.zeros_like(q)
    for degree in range(5):
        if degree:
            values=np.exp(z)/z-degree*values/z
        values[mask]=(wg*nodes**degree)@np.exp(z[None,mask]*nodes[:,None])
        kernel=phase*values
        q-=hh*(coeff[:,degree]@kernel.imag)/sigma;v-=hh*(coeff[:,degree]@kernel.real)
    return q,v
def run(case):
    row=read(MASS)[case];gamma=float(row['dark_mass'])/(float(row['total_gravitating_mass'])-float(row['dark_mass']))
    with np.load(LAST/f'operators/{case}-64.npz') as p:
        sig=p['freq'];h=p['center'];obs=p['sky'];N=float(p['mass']);vel=float(p['vel']);length=float(p['length']);body=p['bary'];wall=p['wall']
    v=sig*h;square,U=eigh(np.diag(sig**2)+gamma*N*np.outer(v,v),driver='evd');omega=np.sqrt(square);drive=N*(U.T@v)
    unit=vel**2/length;scores=[]
    for model in MODELS:
        via=32 if model=='L2M11' else 16
        with np.load(HERE/f'outputs/state-{case}-{model}-{via}.npz') as data:
            signal=data['source_main'].sum(axis=1);q,rate=end_modes(data['time'],signal,omega,vel,length)
            dc=(U@(drive*q))/sig;ds=(U@(drive*rate))/sig;d2c=(U@(drive*(-square*q-signal[-1]/unit)))/sig
            delta=length*(h@dc);check=abs(delta-data['correction'][-1])
            with np.load(PARENT/f'state-{case}-{via}-{model}.npz') as old:
                d_speed=abs(data['velocity_end']-old['velocity'][-1]-vel*(h@ds))
        sky=2*obs@dc;added_body=(dc@body)*unit;added_wall=(dc@wall)*unit
        predicted=(h@d2c)*unit;physical=(1+gamma)*added_body+added_wall-signal[-1]
        escale=max(abs(physical),abs(signal[-1]),abs((1+gamma)*added_body))
        rows=read(HERE/f'outputs/sky-{case}-{model}-{via}.csv')
        sky_error=0.
        for r in rows:
            if r['background']!='mts':continue
            radius=float(r['R']);z=float(r['z']);polar=r['component']=='polar';sgn=np.sign(z) if polar else 1.
            idx=3*int(radius>6)+int(polar);proj=(z if polar else radius)/np.hypot(radius,z)
            acc=sky[-1].real if r['frame']=='site_minus_point' else (signal[-1]-gamma*added_body).real*UNIT
            test=-sky[idx].real*sgn+proj*acc;given=float(r['history_correction'])+float(r['instantaneous'])
            sky_error=max(sky_error,abs(test-given))
        assert check<1e-12 and d_speed<1e-11 and abs(predicted-physical)<2e-5*escale and sky_error<1e-10
        scores.append(dict(case=case,model=model,via=via,centroid_difference_pc=check*1000,velocity_difference_kms=d_speed,
            relative_eq_difference=abs(predicted-physical)/escale,max_force_difference=sky_error))
    table(f'terminal-checks-{case}.csv',scores)
if __name__=='__main__':
    for case in (0,1):run(case)
