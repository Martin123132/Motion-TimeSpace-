from gas_io import *
from scipy.linalg import eigh_tridiagonal
from scipy.special import zeta,factorial
from time import perf_counter
from direct_gas import nodes as full_nodes,compute as full_compute
LEVELS={'pilot':(2,4,9),'main':(3,6,14),'extra':(4,9,20)}
@lru_cache(None)
def gauss(order):
    return roots_legendre(order)
@lru_cache(None)
def heights(order):
    pts,w=gauss(144);x=48*(pts+1);w=96*w*np.exp(-x)/(1+np.exp(-x))**2
    sq=x*x;diag=[];off=[];prev=np.zeros_like(x);vec=np.sqrt(w/w.sum())
    for j in range(order):
        diag.append((vec*sq)@vec);nxt=(sq-diag[-1])*vec
        if j:nxt-=off[-1]*prev
        if j+1<order:off.append(np.linalg.norm(nxt));prev,vec=vec,nxt/off[-1]
    nodes,rot=eigh_tridiagonal(diag,off)
    assert nodes.min()>0
    for k in range(1,2*order):
        expected=2*factorial(2*k)*(1-2**(1-2*k))*zeta(2*k)
        assert abs((rot[0]**2@nodes**k)/expected-1)<2e-9
    return np.sqrt(nodes),rot[0]**2
EDGES=np.array([0.,.1,.25,.5,1.,1.5,2.5,4.,6.,9.,13.,19.,27.,38.,53.,73.,102.,145.,196.,240.])
def gas_nodes(gas,place,knots,height_order,rad_order):
    zs,wz=heights(height_order);pts,weights=gauss(rad_order);dr=np.hypot(*place[:2])
    rr=[];zz=[];dm=[]
    for z,w in zip(zs*gas.height,wz):
        cuts=[EDGES]
        for dz in (place[2]+z,place[2]-z):
            radius=np.sqrt(np.maximum(0.,knots[knots>abs(dz)]**2-dz**2))
            cuts.extend((abs(radius-dr),radius+dr))
        edges=np.unique(np.clip(np.concatenate(cuts),0.,EDGES[-1]));half=np.diff(edges)[:,None]/2
        r=(edges[:-1,None]+half*(1+pts)).ravel()
        weight=(half*weights).ravel()*2*np.pi*r*gas.surface(r)*w/gas.mass
        rr.append(r);zz.append(np.full_like(r,z));dm.append(weight*(gas.rm/r**2-1/gas.rd))
    return tuple(np.concatenate(v) for v in (rr,zz,dm))
def force(place,knots,shape,grad,gas,level):
    hz,rad,az=LEVELS[level];r,z,dm=gas_nodes(gas,place,knots,hz,rad)
    quad,weight=gauss(az);out=np.zeros(2)
    assert lib.direct_ring(*(np.ascontiguousarray(v,dtype=float) for v in (place,knots,shape,r,z,dm)),len(r),
        quad,weight,az,np.array([grad.real,-grad.imag]),out)==0
    return out[0]-1j*out[1]
class Archive:
    def __init__(self,model):
        self.model=model;self.stamps,self.knots,self.banks,tr=history(model)
        with np.load(LAST/f'incident/{model}-192-25-28-16.npz') as p:self.time=p['time'];self.grad=p['grad']
        self.pos=positions(tr,self.time)
        self.gas=gases()
    def source(self,i):
        left=min(i//16,len(self.stamps)-2);frac=i/16-left
        return self.pos[i],self.knots,self.banks[left]*(1-frac)+self.banks[left+1]*frac,self.grad[i]
    def calc(self,i,level):
        args=self.source(i)
        return np.array([force(*args,gas,level) for gas in self.gas])
def pilot():
    rows=[]
    for model in (MODELS[0],'L3M10rad'):
        archive=Archive(model)
        indices=[0,len(archive.time)//2,len(archive.time)-1]
        for idx in indices:
            for level in LEVELS:
                start=perf_counter();val=archive.calc(idx,level)
                for gas,a in zip(archive.gas,val):rows.append(dict(model=model,idx=idx,level=level,gas=gas.name,ax=a.real,ay=-a.imag))
                print(model,idx,level,np.around(val,8),round(perf_counter()-start,3),flush=True)
    table('pilot.csv',rows)
if __name__=='__main__':pilot()
