from gas_history import *
from scipy.special import kv

def run():
    controls=[];analytic=[]
    for model in MODELS:
        obj=archive(model);nt=len(obj.time);dist=np.linalg.norm(obj.pos,axis=1);plane=np.hypot(obj.pos[:,0],obj.pos[:,1])
        near=np.argmin(dist[:-64]);low=np.argmin(np.hypot(np.maximum(plane[:-64]-70.,0.),obj.pos[:-64,2]))
        checks=np.unique(np.r_[np.linspace(1,nt-2,9,dtype=int),nt-1,near,low])
        extended={nt-1,int(low),int(.61*(nt-1))+1}
        for idx in sorted(set(checks)|extended):
            args=obj.source(idx);main=obj.calc(idx,'main');extra=obj.calc(idx,'extra')
            for j,g in enumerate(obj.gas):
                full=None
                if idx in extended:
                    if idx==nt-1:
                        rr=next(r for r in read(PARENT/'direct-gas-fine-all.csv') if r['component']==g.name and r['model']==model)
                        full=complex(float(rr['direct_x']),-float(rr['direct_y']))
                    else:full=full_compute(*args,full_nodes(g,6),20)
                controls.append(dict(model=model,idx=idx,time=obj.time[idx],distance=dist[idx],height=obj.pos[idx,2],gas=g.name,
                    extra_x=extra[j].real,extra_y=-extra[j].imag,main_extra_absolute=abs(main[j]-extra[j]),
                    full_x='' if full is None else full.real,full_y='' if full is None else -full.imag,
                    extra_full_absolute='' if full is None else abs(extra[j]-full)))
        print(model,'spatial controls complete',flush=True)
    pos=np.array([11.,-6.,22.]);knots=np.geomspace(1100.,22000.,25)
    for gas in gases():
        arg=2*np.sqrt(gas.rm/gas.rd)
        expected=2*gas.rm*gas.rd*kv(4,arg)/kv(2,arg)-4*np.pi**2*gas.height**2/3
        for field in ('uniform','shifted_cubic'):
            shape=np.zeros((50,49))
            if field=='uniform':
                grad=.73+.29j;shape[:25,3]=-grad.real*knots/np.sqrt(3)
                shape[:25,1]=grad.imag*knots/np.sqrt(3)
                shape[25:]=shape[:25];target=0.
            else:
                shape[:25,13]=-knots**3/(1.5*np.sqrt(7/6));shape[25:]=3*shape[:25];target=expected
                x,y,z=-pos;grad=4*z*z-3*x*x-y*y+2j*x*y
            for level in LEVELS:
                value=force(pos,knots,shape,grad,gas,level)
                error=abs(value-target)/max(1,abs(target))
                analytic.append(dict(gas=gas.name,field=field,level=level,true=target,real=value.real,imag=value.imag,scaled_error=error))
                if level!='pilot':assert error<2e-5
    table('spatial-controls.csv',controls);table('analytic-controls.csv',analytic)
if __name__=='__main__':run()
