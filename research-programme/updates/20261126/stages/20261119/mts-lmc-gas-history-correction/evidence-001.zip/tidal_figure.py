from gas_io import *
def run():
    rows=[r for r in read(HERE/'vertical-tides.csv') if r['frame']=='site_minus_point']
    xx=lambda val: 220+(val-.3)*900
    bits=['<svg xmlns="http://www.w3.org/2000/svg" width="880" height="430" viewBox="0 0 880 430" role="img" aria-labelledby="title desc">',
          '<title id="title">How strongly does gravity pull back toward the Galactic plane?</title>',
          '<desc id="desc">At each radius, both model ranges lie below the envelope derived from north and south force bands. The inner shortfall is larger for MTS.</desc>',
          '<rect width="880" height="430" fill="white"/>','<g font-family="Arial, sans-serif" fill="#182638">']
    def label(x,y,msg,size=15,color='#182638',bold=False):
        bits.append(f'<text x="{x}" y="{y}" fill="{color}" font-size="{size}" font-weight="{700 if bold else 400}">{msg}</text>')
    label(28,39,'Gravity above and below the Galactic plane',24,bold=True)
    label(28,65,'Mean vertical compression K between z = −1.5 and +1.5 kpc',16)
    for tick in np.arange(.3,1,.1):
        x=xx(tick);bits.append(f'<path d="M{x:.1f} 96V331" stroke="#e0e5eb"/>');label(round(x-9),355,f'{tick:.1f}',13)
    for radius,y in ((6.,118),(8.3,242)):
        rr=[r for r in rows if float(r['R'])==radius];lo,hi=map(float,(rr[0]['band_min'],rr[0]['band_max']))
        label(28,y,f'R = {radius:g} kpc',18,bold=True)
        for name,dy,color in [('Figure 9 envelope',0,'#5b6f80'),('MTS',29,'#007d72'),('Static NFW',56,'#a36a15')]:
            if dy:
                field=[float(r['compression']) for r in rr if r['background']==('mts' if name=='MTS' else 'nfw')]
                low,high=min(field),max(field)
            else:low,high=lo,hi
            label(29,y+dy+22,name,14,color)
            x0=xx(low);x1=xx(high);h=y+dy+16
            bits.append(f'<path d="M{x0:.2f} {h}H{x1:.2f}" stroke="{color}" stroke-width="8" stroke-linecap="round"/>')
    label(240,381,'K in units of 10⁻¹⁰ m s⁻² per kpc',15)
    label(28,413,'Model ranges: two prepared foregrounds × six orbits. Observational envelope is not a joint confidence interval.',13)
    bits.append('</g></svg>');save('TIDAL-READOUT.svg',('\n'.join(bits)+'\n').encode())
if __name__=='__main__':run()
