from propagate_gas import *
from recoil_io import PRE as QUAD
from centroid_run import mapping
from terminal_check import end_modes
from tidal_contrasts import weights as tide_weights,ROWS
from scipy.linalg import eigh

def magnitudes(a,h,ratio):
    return np.sqrt(np.maximum(0.,np.sum(abs(a)**2,axis=-1)-ratio*abs(a@h)**2))

def series(case,model,op,mapping_matrix,grid,via):
    with np.load(LAST/f'incident/{model}-192-25-28-16.npz') as p:
        t=p['time'];g=p['grad'];raw=p['raw']
    raw[:,:,0]+=g[:,None]*grid/np.sqrt(6);base=2*raw.reshape(len(g),-1)@mapping_matrix;del raw
    with np.load(PARENT/f'drive-{case}-{model}.npz') as p:external=p['diff'].copy()
    if via==32:
        with np.load(PARENT/'time-midpoints-L2M11.npz') as p, np.load(PARENT/'weights-8-1.npz') as bank:
            raw=p['raw'];raw[:,:,0]+=p['grad'][:,None]*grid/np.sqrt(6)
            projected=2*raw.reshape(len(raw),-1)@mapping_matrix
            massrows=[r for r in read(PARENT/'component-drives.csv') if int(r['case'])==case and r['model']==model]
            massdict={r['component']:float(r['mass']) for r in massrows};masses=bank['masses']
            factor=np.array([massdict[k] for k in bank['names']])/masses/sum(massdict.values())
            tensor=np.einsum('c,crl->rl',factor,bank['weights']);mid_ext=np.einsum('trl,rl->t',raw,tensor)
            external=blend(external,mid_ext);t=blend(t,p['time']);del raw
            base=blend(base,projected);del projected
    with np.load(HERE/f'outputs/state-{case}-{model}-{via}.npz') as p:
        assert np.array_equal(t,p['time']);cor=p['source_main'].sum(axis=1)
    unit=op['vel']**2/op['length'];base+=((external+cor)/unit)[:,None]*(op['mass']*op['center'])
    return t,base,cor

def run(case):
    with np.load(LAST/f'operators/{case}-64.npz') as p:op=dict(p)
    with np.load(next((LAST/'incident').glob('*.npz'))) as p:grid=p['radius']
    mapp=mapping(op,grid,25)
    N=float(op['mass']);sig=op['freq'];h=op['center'];vel=float(op['vel']);length=float(op['length']);obs=op['sky']
    m=read(MASS)[case];gamma=float(m['dark_mass'])/(float(m['total_gravitating_mass'])-float(m['dark_mass']))
    ratio=gamma*N/(1+gamma*N*(h@h));v=sig*h
    sq,U=eigh(np.diag(sig**2)+gamma*N*np.outer(v,v),driver='evd');omega=np.sqrt(sq);drive=N*(U.T@v)
    rr=np.array([6.,6.,8.3,8.3]);proj=np.array([6.,1.5,8.3,1.5])/np.hypot(rr,1.5)
    north=-2*obs[[0,1,3,4]]+2*proj[:,None]*obs[-1]
    mapped=np.array([(1 if comp=='radial' else np.sign(z))*north[2*int(rad>6)+int(comp=='polar')] for rad,z,comp in ROWS])
    tmap=(tide_weights(6.)-tide_weights(8.3))@mapped
    budget=read(QUAD/f'complete-angular-test-{case}.csv');sources=read(QUAD/f'joint-even-source-budget-{case}.csv')
    with np.load(QUAD/f'joint-response-grams-{case}.npz') as p:ag=p['axis'];qg=p['quadrupole']
    sp=read(HERE/'tidal-gradient-requirement.csv');results=[];curvature=[]
    for model in MODELS:
        via=32 if model=='L2M11' else 16
        t,f,cor=series(case,model,op,mapp,grid,via)
        sc=f-(f@h)[:,None]*(ratio*h);sc/=sig
        var=np.linalg.norm(sc[0])+np.linalg.norm(sc[-1]);area=0.
        delta=(t[4]-t[0])*vel/length
        for i in range(0,len(t)-1,64):
            stop=min(i+65,len(t))
            coeff=INVERSE@panels(sc[i:stop]);var+=np.sum(np.linalg.norm(np.diff(coeff,axis=1),axis=2))
            other=INVERSE@panels(f[i:stop]);area+=delta/5*magnitudes(other,h,ratio).sum()
        del sc,f
        with np.load(PARENT/f'state-{case}-{via}-{model}.npz') as p:
            q,rate=end_modes(t,cor,omega,vel,length)
            c=p['mode']+(U@(drive*q))/sig;speed=p['mode_rate']+(U@(drive*rate))/sig
        potential=np.sum(abs(sig*c)**2)/2;kinetic=magnitudes(speed,h,ratio)**2/2;actual=potential+kinetic;ceiling=min(area,var)**2/2
        assert 0<actual<=ceiling*(1+1e-9)
        record=next(r for r in sp if int(r['case'])==case and r['model']==model and r['background']=='mts' and r['frame']=='site_minus_point')
        target=float(record['inner_low'])-float(record['outer_high']);actual_shape=(tmap@c).real
        need=max(0.,target+actual_shape);gram=np.sum((tmap/sig)**2);req=need**2/(2*gram)
        if need>0:
            best=tmap/(sig**2)*need/gram;assert abs(tmap@best-need)<1e-11 and abs(np.sum((sig*best)**2)/2-req)<1e-8*req
        curvature.append(dict(case=case,model=model,actual_shape=actual_shape,required_if_replacing_m1=need,
            min_energy_for_shape=req,actual_energy=actual,source_ceiling=ceiling,required_over_actual=req/actual,required_over_ceiling=req/ceiling))
        for relaxed in ('False','True'):
            a=next(r for r in sources if r['model']==model and r['allow_odd']==relaxed and r['substeps']=='16')
            matched=[r for r in budget if r['model']==model and r['allow_odd']==relaxed]
            assert len(matched)==2
            witness=np.array([float(a[k]) for k in ('witness_6r','witness_6p','witness_8r','witness_8p')])
            assert abs(np.linalg.norm(witness)-1)<1e-9
            req=float(a['required_projected_force'])
            axis_support=[];quad_support=[]
            for b in matched:
                assert abs(float(b['required_projected_force'])-req)<1e-10
                axis_support.append(np.sqrt(float(b['axis_energy_ceiling'])*(witness@ag@witness)))
                quad_support.append(np.sqrt(2*float(b['full_m2_energy_ceiling'])*(witness@qg@witness)))
                assert abs(axis_support[-1]+quad_support[-1]-float(b['combined_projected_ceiling']))<1e-10
            base=max(axis_support)+max(quad_support)
            gram=np.sum(((witness@north)/sig)**2);allow=np.sqrt(2*ceiling*gram)
            results.append(dict(case=case,model=model,via=via,allow_odd=relaxed,m1_potential=potential,m1_kinetic=kinetic,m1_actual_energy=actual,
                drive_area_ceiling=area**2/2,static_variation_ceiling=var**2/2,m1_energy_ceiling=ceiling,required_projection=req,
                m0_m2_ceiling=base,m1_ceiling_projection=allow,all_ceiling=base+allow,required_over_all_ceiling=req/(base+allow),
                minimum_m1_energy_if_others_optimal=max(0.,req-base)**2/(2*gram),minimum_over_actual=max(0.,req-base)**2/(2*gram*actual)))
    table(f'joint-energy-{case}.csv',results);table(f'curvature-cost-{case}.csv',curvature)
if __name__=='__main__':
    for case in (0,1):run(case)
