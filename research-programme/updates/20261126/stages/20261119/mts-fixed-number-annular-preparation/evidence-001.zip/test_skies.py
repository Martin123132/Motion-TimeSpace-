from prepare import *
from slab_fields import nfw,MODELS
from scipy.optimize import minimize_scalar

def support(vector,points,joint,gram,energy):
    return max(points@(vector@joint)+abs(points)@np.sqrt(np.diag(energy))*np.sqrt(max(0,vector@gram@vector)))
def anchor_support(index,sign,points,joint,gram,energy):
    dim=len(gram);vec=np.eye(dim)[index]*sign;anchor=np.eye(dim)[-1]
    def bound(lam):return support(vec-lam*anchor,points,joint,gram,energy)
    try:
        opt=minimize_scalar(bound,method='brent',options={'xtol':1e-10})
        candidates=[0.,float(opt.x)]
    except ValueError:candidates=[0.]
    coeff=min(candidates,key=bound)
    return bound(coeff),coeff,bound(0.)
def run(case):
    guard(); pack=readop(HERE/f'preparation-{case}.npz'); idx=case%2
    points=pack['vertices']-pack['initial'];direct=pack['direct'];wave=pack['wave'];gram=pack['gram'];energy=pack['energy']
    joint=direct+wave;halo=nfw(idx)
    nout=-halo(OUTER,0.)[0]*UNIT
    dark=np.array([scale for r in (6.,8.3) for scale in [-(r*r+2.25)**.5*(-halo(r,1.5)[0]/r)*UNIT,0.]]+[nout])
    nfwmat=direct-np.outer(dark,direct[-1]/nout)
    rows=[];bounds=[];witness=[];diagnostics=[];frozen=[]
    modes=[name[6:] for name in pack if name.startswith('coeff_')]
    for name in modes:
        coeff=pack['coeff_'+name];shift=direct[-1]@coeff
        live=pack['wave_'+name];assert abs(shift+live[-1])<2e-12
        assert abs((nfwmat@coeff)[-1])<1e-12 and 1-shift/nout>0
        diagnostics.append(dict(case=case,challenge=name,MTS_outer=shift+live[-1],NFW_fixed_outer=shift,NFW_rematched_outer=(nfwmat@coeff)[-1],NFW_halo_ratio=1-shift/nout))
    caps={}
    for pos in range(4):
        for sign in (-1,1):
            limit,lam,free=anchor_support(pos,sign,points,joint,gram,energy)
            assert limit<=free+1e-12 and free>=0 and limit>=-1e-12
            caps[pos,sign]=limit
            bounds.append(dict(case=case,coordinate=('6r','6p','8r','8p')[pos],sign=sign,limit=limit,anchor_multiplier=lam,without_anchor=free,
                stationary_support=max(sign*points@joint[pos]),transient_energy_ceiling=max(abs(points)@np.sqrt(np.diag(energy)))**2))
    for model in MODELS:
        history_rows=read(GAS/f'outputs/sky-{idx}-{model}-{32 if model=="L2M11" else 16}.csv')
        for obs in history_rows:
            rad,z=float(obs['R']),float(obs['z']);polar=obs['component']=='polar';pos=2*int(rad>6)+int(polar)
            basis_sign=int(np.sign(z)) if polar else 1;value=float(obs['corrected'])
            low,high=float(obs['low']),float(obs['high'])
            common=dict(case=case,orbit=model,frame=obs['frame'],R=rad,z=z,component=obs['component'],background=obs['background'],baseline=value,low=low,high=high)
            keys=('mts',) if obs['background']=='mts' else ('nfw-fixed','nfw-rematched')
            for name in modes:
                coeff=pack['coeff_'+name]
                for key in keys:
                    change=(pack['wave_'+name][pos]+direct[pos]@coeff if key=='mts' else (direct if key=='nfw-fixed' else nfwmat)[pos]@coeff)*basis_sign
                    after=value+change
                    rows.append(dict(**common,method=key,challenge=name,increment=change,prediction=after,in_band=low<=after<=high,original_in_band=low<=value<=high))
            for key in keys:
                if key=='mts':
                    lo_ch=-caps[pos,-basis_sign];hi_ch=caps[pos,basis_sign]
                else:
                    shift=basis_sign*points@(nfwmat if key=='nfw-rematched' else direct)[pos]
                    lo_ch,hi_ch=min(shift),max(shift)
                rem=max(0.,low-value-hi_ch,value+lo_ch-high)
                witness.append(dict(**common,method=key,minimum=value+lo_ch,maximum=value+hi_ch,remaining_gap=rem,disjoint=rem>0))
            if obs['background']=='mts' and not (low<=value<=high):
                sign=1 if value<low else -1
                max_static=max(sign*basis_sign*points@joint[pos])
                distance=max(0,max(low-value,value-high)-max_static)
                required=distance**2/gram[pos,pos];ceiling=max(abs(points)@np.sqrt(np.diag(energy)))**2
                frozen.append(dict(**common,required_transient_energy_at_least=required,allowed_transient_energy_at_most=ceiling,ratio=required/ceiling))
    table('history-tests-'+str(case),rows);table('monotone-support-'+str(case),bounds);table('history-envelopes-'+str(case),witness)
    table('energy-witness-'+str(case),frozen);table('outer-controls-'+str(case),diagnostics)
    print(case,len(rows),'finite component rows,',len(witness),'any-rate enclosures',flush=True)
if __name__=='__main__':
    for arg in sys.argv[1:]:run(int(arg))
