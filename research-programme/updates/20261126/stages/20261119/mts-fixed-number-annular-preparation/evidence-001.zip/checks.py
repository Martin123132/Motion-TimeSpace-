from prepare import *
from test_skies import MODELS
from slab_fields import Multipoles
from scipy.optimize import linprog
from scipy.integrate import solve_ivp
from rate_test import rotated
import hashlib

def raw_corridor(points):
    knots=[r for r in read(ANN/'source-knots.csv') if r['family']=='added']
    for point in points:
        lower=0.;upper=np.inf
        for knot in knots:
            rad=float(knot['radius_kpc']);err=float(knot['relative_error'])
            factor=1+sum(x for x,(lo,hi) in zip(point,REGIONS) if lo<rad<hi)
            assert factor>=0
            lower=max(lower,factor/(1+2*err))
            if 2*err<1:upper=min(upper,factor/(1-2*err))
        assert lower<=upper+3e-12

def time_control():
    freq=np.array([.25,np.pi,10.])
    for duration in (.75,1.,2.):
        def rhs(t,arr):
            pos,rate=arr.reshape(2,-1)
            return np.r_[rate, -freq**2*(pos-(1-np.cos(np.pi*t/duration))/2)]
        last=solve_ivp(rhs,(0,duration),np.zeros(6),method='DOP853',rtol=1e-12,atol=2e-14).y[:,-1]
        ideal=rotated(freq*duration)
        assert max(abs(last-np.r_[1-ideal.real,freq*ideal.imag]))<2e-11
    assert abs(rotated(np.array([np.pi]))[0]-1j*np.pi/4)<1e-14

def contrast_checks(case):
    unit=readop(AX/f'operators/{case}-k-100.npz');g0=unit['ground'];length=unit['length']
    rad,weights,vel,deg=unit['r'],unit['weight'],unit['velocity'],unit['orders'];mu=unit['mu'];aw=unit['aw'];harm=basis(deg,0,mu)
    pack=readop(HERE/f'preparation-{case}.npz');delta=[]
    for key in ('plus','minus'):
        if 'coeff_'+key not in pack:continue
        g=pack['state_'+key];c=pack['coeff_'+key];raw_corridor([c+pack['initial']])
        assert abs(np.sum(g**2)-unit['mass'])<2e-12
        fine=((g-g0)@harm.T)*((g+g0)@harm.T)@(aw[:,None]*harm)
        initial_defect=np.sum(g0*g0)-float(unit['mass'])
        assert abs(initial_defect)<2e-12
        assert abs(np.sum(fine[:,0])+initial_defect)<1e-12
        assert abs(np.sum(fine[:,0])-np.sum((g-g0)*(g+g0)))<1e-13
        physical=fine*(vel**2/(weights*(rad*length)**2))[:,None]
        field=Multipoles(rad*length,physical,deg,0,length*(40 if case>=2 else 30))
        probe=[]
        for radius,height in ((6.,1.5),(8.3,1.5),(OUTER,0.)):
            gr,gz,*_=field(radius,np.array([height]));rr=np.hypot(radius,height)
            if height==0:probe.append(-gr[0]*UNIT)
            else:probe.extend([UNIT*(gr[0]*radius+gz[0]*height)/rr,UNIT*(gr[0]*height-gz[0]*radius)/rr])
        err=np.array(probe)-pack['wave_'+key]
        assert max(abs(err))<2e-5*max(abs(np.array(probe)))
        delta.append(dict(case=case,challenge=key,max_independent_wave_force_error=max(abs(err)),outer_crosscheck=abs(err[-1]),initial_norm_defect=initial_defect,integrated_number_change=sum(fine[:,0]),branch_source_norm=np.linalg.norm(g-g0)/np.sqrt(unit['mass'])))
    return delta

def main():
    guard();time_control()
    last=json.loads((SLAB/'seal.json').read_text());assert all(digest(SLAB/k)==v for k,v in last['files'].items())
    mat,rhs,pts,_=corridor();raw_corridor(pts)
    for theta in np.linspace(0,np.pi*2,37):
        vec=np.array([np.cos(theta),np.sin(theta)])
        oracle=linprog(-vec,A_ub=mat,b_ub=rhs,bounds=[(None,None)]*2,method='highs')
        assert oracle.success and abs(np.max(pts@vec)+oracle.fun)<1e-10
    tab=[];counts=[]
    for case in range(4):
        tab.extend(contrast_checks(case))
        stiffness=read(AX/f'requirement-{case}-k-100-r320-l40-q36-t16.csv')
        assert all(int(r['negative_bordered_pivots'])==1 and float(r['backward_error'])<1e-9 for r in stiffness)
        finite=read(HERE/f'history-tests-{case}.csv');hulls=read(HERE/f'history-envelopes-{case}.csv')
        assert len(hulls)==288 and len(finite)==(576 if case%2==0 else 288)
        assert all(r['in_band']==r['original_in_band'] for r in finite)
        assert all(float(r['remaining_gap'])>0 for r in hulls if r['component']=='radial' or (r['component']=='polar' and float(r['R'])==6))
        assert len({(row['frame'],row['method'],row['R'],row['z'],row['component'],row['orbit']) for row in hulls})==len(hulls)
        if case<2:
            ramp=read(HERE/f'ramp-tests-{case}.csv');refine=read(HERE/f'ramp-refinement-{case}.csv')
            assert len(ramp)==(384 if case==0 else 192) and all(r['inside']==r['old'] for r in ramp)
            for test in refine:
                key=test['challenge'];turns=test['turns']
                saved=readop(HERE/f'ramp-{case}_{turns}_{key}.npz')
                assert float(test['wave_difference'])<2e-5*max(abs(saved['wave']))
                assert float(test['energy_relative'])<2e-5
            p,q=[readop(HERE/f'preparation-{index}.npz') for index in (case,case+2)]
            for name in ('energy','gram','wave','direct'):
                assert np.max(abs(p[name]-q[name]))<2e-5*np.max(abs(p[name]))
        counts.append(dict(case=case,finite=len(finite),any_rate=len(hulls),independent_schedules=(len(ramp) if case<2 else 0)))
    table('independent-wave-checks',tab);table('validation-counts',counts)
    assert len(read(HERE/'ramp-nfw-controls.csv'))==1152
    parents={SLAB/'seal.json',GAS/'seal.json',ANN/'512-40-kernel.csv',ANN/'source-knots.csv',ANN/'independent-budget.csv',MASS}
    for case in range(4):
        parents.update([AX/f'operators/{case}-k-100.npz',AX/f'requirement-{case}-k-100-r320-l40-q36-t16.csv'])
        if case<2:
            parents.update([AX/f'operators/{case}-k-64.npz',MASS.parent/f'extra-{CASES[case]}-mean.npz'])
            parents.update(GAS/f'outputs/sky-{case}-{model}-{32 if model=="L2M11" else 16}.csv' for model in MODELS)
    table('primary-inputs',[dict(file=p.relative_to(ROOT).as_posix(),sha256=digest(p)) for p in sorted(parents)])
    files={p.relative_to(STAGE).as_posix():digest(p) for p in sorted(STAGE.rglob('*')) if p.is_file() and p.name!='seal.json'}
    seal=dict(files=files,parent_sha256=PIN,independent_previous_files=len(last['files']),tolerance=2e-5)
    path=STAGE/'seal.json'
    if sys.argv[1:]==['seal'] and not path.exists():
        with path.open('x',encoding='utf8') as stream:json.dump(seal,stream,indent=2,sort_keys=True);stream.write('\n')
    elif sys.argv[1:]!=['check-only']:assert json.loads(path.read_text())==seal
    print(counts,'max independent readout error',max(r['max_independent_wave_force_error'] for r in tab))
if __name__=='__main__':main()
