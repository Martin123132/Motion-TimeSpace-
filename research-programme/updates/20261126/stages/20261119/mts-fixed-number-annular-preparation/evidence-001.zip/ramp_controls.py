from prepare import *
from slab_fields import nfw,MODELS

def run():
    guard();out=[]
    for case in (0,1):
        p=readop(HERE/f'preparation-{case}.npz');halo=nfw(case)
        norm=-halo(OUTER,0.)[0]*UNIT
        dark=np.array([v for radius in (6.,8.3) for v in (halo(radius,1.5)[0]/radius*np.hypot(radius,1.5)*UNIT,0.)])
        direct=p['direct']
        for state in read(HERE/f'ramp-states-{case}.csv'):
            coeff=np.array([float(state['inner']),float(state['donor'])])
            change=direct@coeff
            for model in MODELS:
                for row in read(GAS/f'outputs/sky-{case}-{model}-{32 if model=="L2M11" else 16}.csv'):
                    if row['background']!='nfw':continue
                    polar=row['component']=='polar';pos=2*int(float(row['R'])>6)+int(polar)
                    sign=np.sign(float(row['z'])) if polar else 1.
                    for name,factor in [('fixed',1.),('rematched',1-change[-1]/norm)]:
                        pred=float(row['corrected'])+sign*(change[pos]+(factor-1)*dark[pos])
                        inside=float(row['low'])<=pred<=float(row['high'])
                        assert inside==(row['inside']=='True')
                        out.append(dict(case=case,orbit=model,turns=state['turns'],challenge=state['challenge'],frame=row['frame'],R=row['R'],z=row['z'],component=row['component'],NFW=name,halo_ratio=factor,prediction=pred,in_band=inside))
    table('ramp-nfw-controls',out)
    print(len(out),'NFW finite-duration comparisons')
if __name__=='__main__':run()
