from axis_io import *
from lmc_field import MODELS,history,positions,potential
from shell_bank import shells
from scipy.special import roots_legendre,eval_legendre

def run():
    rows=[]
    mu,w=roots_legendre(56);ph=2*np.pi*(np.arange(112)+.5)/112
    sn=np.sqrt(1-mu**2);coords=np.stack(np.broadcast_arrays(sn[:,None]*np.cos(ph),sn[:,None]*np.sin(ph),mu[:,None]),axis=-1)
    angular=np.stack([np.sqrt(2*j+1)*eval_legendre(j,mu)*w/2 for j in range(0,15,2)])
    for model,t in [('L3M10rad',-3.01953125),('L2M10first',-1.41015625)]:
        times,rr,bank,tr=history(model);p=positions(tr,t)
        i=np.searchsorted(times,t)-1;f=(t-times[i])/(times[i+1]-times[i]);coeff=bank[i]*(1-f)+bank[i+1]*f
        rad=np.array([6.,24.,51.,89.]);native=shells(p,rr,coeff,rad,14,roots_legendre(32))
        scalar=lambda xyz:(1-f)*potential(xyz-p,rr,bank[i])+f*potential(xyz-p,rr,bank[i+1])
        origin=scalar(np.zeros((1,3)))[0]
        for r,expected in zip(rad,native):
            direct=angular@(scalar(r*coords).mean(axis=1)-origin)
            rows.append(dict(model=model,native_time=t,R=r,shape_weight=f,relative_shell_error=np.linalg.norm(direct-expected)/np.linalg.norm(expected)))
    assert max(r['relative_shell_error'] for r in rows)<2e-5
    table('off-snapshot-field-check.csv',rows)
if __name__=='__main__':run()
