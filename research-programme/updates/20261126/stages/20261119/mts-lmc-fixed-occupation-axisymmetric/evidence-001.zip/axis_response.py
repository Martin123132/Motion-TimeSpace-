from axis_io import *
from lmc_field import MODELS,GYR,TAGS
from axis_operator import basis
from scipy.interpolate import CubicSpline
from scipy.special import spherical_jn,eval_legendre
from numpy.polynomial.legendre import legvander
from shell_bank import name
from functools import lru_cache

def source_map(op,radii,jmax):
    rad=op['r']*float(op['length']);wt=op['weight'];mu=op['mu'];aw=op['aw'];orders=op['orders'];blk=op['block'];nl,nr,keep=blk.shape
    inter=CubicSpline(radii,np.eye(len(radii)),axis=0)(np.minimum(rad,radii[-1]))
    inter[rad>radii[-1]]=0
    angle=basis(orders,0,mu);ya=basis(np.arange(0,jmax+1,2),0,mu)
    gsky=(op['ground']/np.sqrt(wt[:,None]))@angle.T
    kernel=np.empty((len(radii),ya.shape[1],nl,keep))
    for idx in range(nl):
        local=(gsky@(aw[:,None]*angle[:,idx,None]*ya))*np.sqrt(wt[:,None])/float(op['velocity'])**2
        kernel[:,:,idx,:]=(inter.T@(local[:,:,None]*blk[idx,:,None,:]).reshape(nr,-1)).reshape(len(radii),ya.shape[1],keep)
    return kernel.reshape(len(radii)*ya.shape[1],nl*keep)

def integrate(f,tau,sigma):
    block=4;dt=(tau[-1]-tau[0])/(len(tau)-1)*block;count=(len(tau)-1)//block
    assert count*block+1==len(tau) and np.max(np.abs(np.diff(tau)-dt/block))<1e-11
    inv=np.linalg.inv(legvander(np.linspace(-1,1,block+1),block))
    x=dt*sigma/2;coef=np.stack([(1j**j)*spherical_jn(j,x) for j in range(block+1)],axis=1)@inv
    coef*=(-1j*dt*np.exp(-1j*x)/sigma)[:,None]
    shift=np.exp(-2j*x);z=np.zeros((count+1,len(sigma)),complex)
    for b in range(count):
        z[b+1]=shift*z[b]+np.einsum('ji,ij->j',coef,f[b*block:b*block+block+1])
    return z

def lift(op,coords,kind):
    weights=(op[kind]@coords).reshape(len(op['orders']),-1)
    return np.einsum('lrk,lk->rl',op['block'],weights)

def run(case,keep,res,ell,nq,sub,via,models):
    guard();tag=TAGS[case%2]
    with np.load(HERE/f'operators/{case}-k{keep}.npz') as pk:
        op={key:pk[key] for key in pk.files}
    previous=read(LMC/'present-sky.csv')
    sigma=op['sigma'];sky=op['sky'];sourced=None
    for model in models:
        with np.load(HERE/name(model,res,ell,nq,sub)) as pk:
            assert sub%via==0;v=pk['V'][::sub//via];time=pk['time'][::sub//via];rr=pk['radius']
        if sourced is None:sourced=source_map(op,rr,ell)
        force=(v.reshape(len(v),-1)@sourced)@op['u']
        tau=time*float(op['velocity'])/float(op['length'])
        z=integrate(force,tau,sigma)
        header=f'{case}-{model}-k{keep}-r{res}-l{ell}-q{nq}-t{sub}-v{via}';display=[]
        for initial in ('zero','adiabatic'):
            extra=np.zeros_like(sigma,dtype=complex)
            if initial=='adiabatic':
                fp=CubicSpline(tau[:via+1],force[:via+1],axis=0)(tau[0],1)
                extra=(-force[0]/sigma**2-1j*fp/sigma**3)*np.exp(-1j*sigma*(tau[-1]-tau[0]))
            end=z[-1]+extra;c=end.real;rate=end.imag*sigma
            delta=sky@c;stat=sky@(-force[-1]/sigma**2)
            delta_wave=lift(op,c,'u');phase_wave=lift(op,rate,'momentum');g=op['ground']
            norm=float(op['mass']);num=2*np.sum(g*delta_wave)/norm
            assert abs(num)<1e-10
            stats=dict(number_fraction=num,added_linear_wave_norm=(np.sum(delta_wave**2)+np.sum(phase_wave**2))/norm,
                       min_freq=sigma[0],max_freq=sigma[-1])
            for idx,(rad,height) in enumerate([(6.,1.5),(6.,-1.5),(8.3,1.5),(8.3,-1.5)]):
                for col,component in enumerate(('radial','polar')):
                    rid=3*(idx//2)+col;sign=np.sign(height) if col==1 else 1.
                    pred=sign*delta[rid];quasi=sign*stat[rid]
                    for bg in ('mts','nfw'):
                        baseline=next(r for r in previous if r['tag']==tag and r['model']==model and r['background']==bg and
                            float(r['R'])==rad and float(r['z'])==height and r['component']==component)
                        last=float(baseline['subtotal']);low=float(baseline['obs_low']);high=float(baseline['obs_high'])
                        total=last+(pred if bg=='mts' else 0.)
                        display.append(dict(tag=tag,history=model,initial=initial,background=bg,R=rad,z=height,component=component,
                            previous=last,axis_response=pred if bg=='mts' else 0.,static_response=quasi if bg=='mts' else 0.,
                            combined=total,low=low,high=high,inside=low<=total<=high,
                            missing=low-total if total<low else (high-total if total>high else 0.),**stats))
            if initial=='zero':
                basis0=basis(op['orders'],0,op['mu']);w=op['weight'];rad=op['r']
                rho=((2*(g@basis0.T)*(delta_wave@basis0.T))/(w*rad**2)[:,None])@(op['aw'][:,None]*basis0)
                packet('states/'+header+'.npz',r=rad*op['length'],delta_rho_multipoles=rho,x=delta_wave,y=phase_wave,
                       fraction_redistributed_shells=(2*g*delta_wave).sum(axis=1)/norm,
                       time_native=time[::4],sky_time=z.real@sky.T,static=stat,number_fraction=num)
        table('scores/'+header+'.csv',display);print(header,delta[:2],flush=True)
if __name__=='__main__':
    args=list(map(int,sys.argv[1:8]));run(*args,MODELS if len(sys.argv)<9 else sys.argv[8:])
