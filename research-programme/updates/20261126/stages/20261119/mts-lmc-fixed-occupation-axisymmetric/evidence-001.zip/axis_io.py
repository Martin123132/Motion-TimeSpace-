import os,sys,hashlib,csv,io,json
from pathlib import Path
for key in ('OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','OMP_NUM_THREADS','BLIS_NUM_THREADS','NUMEXPR_NUM_THREADS'):os.environ[key]='1'
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
LMC=HERE.parent/'mts-lmc-tidal-history-20261119'
PULSE=HERE.parent/'mts-finite-bar-mean-response-20261119'
PIN='531ea26b8437c441d6270233a8d88993dedbf271e161ca5fac17a9d65b5abd35'
def sha(path):
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
def guard():
    assert sha(LMC/'seal.json')==PIN and not any((p/'STOP-REQUESTED').exists() for p in (HERE,HERE.parent,LMC,PULSE))
def put(path,data):
    guard();p=HERE/path;p.parent.mkdir(exist_ok=True,parents=True)
    if p.exists():assert p.read_bytes()==data,path
    else:
        with p.open('xb') as dest:dest.write(data)
def table(path,rows):
    buf=io.StringIO(newline='');w=csv.DictWriter(buf,rows[0].keys(),lineterminator='\n');w.writeheader();w.writerows(rows);put(path,buf.getvalue().encode())
def read(p):
    with p.open(encoding='utf8',newline='') as src:return list(csv.DictReader(src))
sys.path.insert(0,str(LMC));sys.path.insert(0,str(PULSE))
import numpy as np
def packet(name,**fields):
    buf=io.BytesIO();np.savez_compressed(buf,**fields);put(name,buf.getvalue())
