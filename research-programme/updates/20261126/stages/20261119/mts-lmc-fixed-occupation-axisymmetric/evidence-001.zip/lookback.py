from axis_io import *
from lmc_field import MODELS
from axis_response import source_map,integrate
from shell_bank import name

def run(case,keep,res,ell,nq,sub):
    guard()
    with np.load(HERE/f'operators/{case}-k{keep}.npz') as data:op={key:data[key] for key in data.files}
    matrix=None;rows=[]
    for model in MODELS:
        with np.load(HERE/name(model,res,ell,nq,sub)) as data:
            v=data['V'];time=data['time'];rr=data['radius']
        if matrix is None:matrix=source_map(op,rr,ell)
        f=(v.reshape(len(v),-1)@matrix)@op['u'];tau=time*op['velocity']/op['length'];s=op['sigma']
        z=integrate(f,tau,s);tp=tau[::4];times=time[::4]
        cuts=sorted(set([times[0],-4.,-2.,-.5,-.125,0.]))
        total=np.zeros(6)
        for left,right in zip(cuts[:-1],cuts[1:]):
            i=np.argmin(abs(times-left));j=np.argmin(abs(times-right));assert abs(times[i]-left)+abs(times[j]-right)<1e-10
            part=z[j]*np.exp(1j*s*tp[j])-z[i]*np.exp(1j*s*tp[i]);a=op['sky']@part.real;total+=a
            rows.append(dict(model=model,start_native=left,end_native=right,radial6=a[0],polar6=a[1],radial8=a[3],polar8=a[4]))
        assert np.max(abs(total-op['sky']@z[-1].real))<1e-10
    table(f'lookback-{case}-k{keep}.csv',rows)
if __name__=='__main__':run(*map(int,sys.argv[1:]))
