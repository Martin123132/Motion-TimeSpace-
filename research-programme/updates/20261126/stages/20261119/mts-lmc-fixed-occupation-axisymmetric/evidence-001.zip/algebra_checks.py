from axis_io import *
from axis_response import integrate
from shell_bank import shells
from scipy.special import roots_legendre
from lmc_field import history,MODELS
from numpy.polynomial import Polynomial

def run():
    guard();rows=[];sigma=np.array([.8,1.3,9.,37.,81.]);t=np.linspace(0,5.4,17)
    pol=Polynomial([.07,-.02,.03,-.0004,.0002]);f=pol(t)[:,None]*np.ones_like(sigma)
    z=integrate(f,t,sigma)
    tt=t[::4,None];part=-pol(tt)/sigma**2+pol.deriv(2)(tt)/sigma**4-pol.deriv(4)(tt)/sigma**6
    rate=-pol.deriv()(tt)/sigma**2+pol.deriv(3)(tt)/sigma**4
    expected=part+1j*rate/sigma-np.exp(-1j*tt*sigma)*(part[0]+1j*rate[0]/sigma)
    rows.append(dict(check='quartic retarded oscillator',error=float(np.max(abs(z-expected)))))
    stamps,knots,_,traj=history(MODELS[0]);dist=50.;place=np.array([-6.,-34.,np.sqrt(dist**2-6**2-34**2)])
    r=np.array([3.,11.,27.,46.,53.,87.]);coeff=np.zeros((50,49));coeff[:25,0]=np.log(knots);coeff[25:,0]=1.
    vals=shells(place,knots,coeff,r,18,roots_legendre(28))
    km=lambda d:d**2*(np.log(d)-.5)
    analytic=(km(r+dist)-km(abs(r-dist)))/(4*r*dist)-np.log(dist)
    rows.append(dict(check='analytic translated log monopole',error=float(np.max(abs(vals[:,0]-analytic)))))
    coeff[:25,0]+=123.45
    shift=shells(place,knots,coeff,r,18,roots_legendre(28))
    rows.append(dict(check='constant external potential offset',error=float(np.max(abs(shift-vals)))))
    assert max(o['error'] for o in rows)<1e-10
    table('analytic-checks.csv',rows)
if __name__=='__main__':run()
