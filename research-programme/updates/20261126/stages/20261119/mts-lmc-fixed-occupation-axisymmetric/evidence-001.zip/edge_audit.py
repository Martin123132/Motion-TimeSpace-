from axis_io import *
from lmc_field import MODELS,history
from axis_operator import TAGS
from shell_bank import name

def run(keep,res,ell,nq,sub):
    guard();rows=[]
    for case in (2,3):
        with np.load(HERE/f'operators/{case}-k{keep}.npz') as pk:
            g=pk['ground'];length=pk['length'];mass=pk['mass'];vel=pk['velocity'];r=pk['r']*length
        for model in MODELS:
            with np.load(HERE/name(model,res,ell,nq,sub)) as pk:rmax=pk['radius'][-1]
            _,knots,coeff,_=history(model)
            peak=np.max(abs(coeff))
            assert np.max(np.diff(np.log(knots)))<1
            bound=2*49*np.sqrt(26)*10*peak/vel**2
            frac=np.sum(g[r>rmax]**2)/mass;tail=bound*np.sqrt(frac)
            fname=f'{case}-{model}-k{keep}-r{res}-l{ell}-q{nq}-t{sub}-v{sub}.csv'
            large=read(HERE/'scores'/fname);sm=read(HERE/'scores'/(str(case-2)+fname[1:]))
            for a,b in zip(large,sm):
                assert all(a[k]==b[k] for k in ('history','initial','background','R','z','component'))
                if a['initial']!='zero' or a['background']!='mts' or a['z']!='1.5':continue
                big=float(a['axis_response']);base=float(b['axis_response'])
                rows.append(dict(tag=TAGS[case-2],model=model,R=a['R'],component=a['component'],reference=base,extended=big,
                    absolute_edge_change=abs(big-base),edge_change_over_axis=abs(big/base-1),same_band_decision=a['inside']==b['inside'],
                    tail_ground_probability=frac,tail_source_norm_over_ground_norm_at_most=tail))
    table('edge-comparison.csv',rows)
if __name__=='__main__':run(*map(int,sys.argv[1:]))
