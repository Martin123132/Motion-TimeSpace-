from axis_io import *
from budget_axis import cases
from lmc_field import MODELS
def run():
    rows=[]
    for case in (0,1):
        for model in MODELS:
            scores=cases(case,model,-100,320,40,36,16)
            for b in scores:
                if b['initial']!='zero':continue
                a=float(b['previous']);lo=float(b['low']);hi=float(b['high']);delta=float(b['axis_response'])
                miss=lo-a if a<lo else (hi-a if a>hi else 0.)
                rows.append(dict(**b,case=case,earlier_deficit=miss,increment_over_earlier_deficit=delta/miss if miss else ''))
    table('final-force-comparison.csv',rows)
if __name__=='__main__':run()
