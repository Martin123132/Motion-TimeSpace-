from axis_io import *
from lmc_field import history,positions,MODELS
from scipy.special import roots_legendre
import ctypes,time
D=np.ctypeslib.ndpointer(dtype=np.float64,flags='C_CONTIGUOUS')
lib=ctypes.CDLL(str(HERE/'shell_projection.dll'))
lib.shells.argtypes=[D,D,D,D,ctypes.c_int,D,D,ctypes.c_int,ctypes.c_int,D]
def shells(pos,rr,coeff,radii,order,quad):
    gx,gw=quad;out=np.empty((len(radii),order//2+1))
    assert lib.shells(np.ascontiguousarray(pos),np.ascontiguousarray(rr),np.ascontiguousarray(coeff),np.ascontiguousarray(radii),len(radii),gx,gw,len(gx),order,out)==0
    return out
def name(model,res,ell,nq,sub):return f'shell-{model}-r{res}-l{ell}-q{nq}-t{sub}.npz'
def radii_for(res):return np.sinh(np.linspace(0,np.arcsinh(400/35),res+1))*35
def build(model,res,ell,nq,sub):
    guard();key=name(model,res,ell,nq,sub)
    if (HERE/key).exists():
        with np.load(HERE/key) as pk:assert pk['V'].shape==(sub*(len(history(model)[0])-1)+1,res+1,ell//2+1)
        return
    stamp,rr,raw,traj=history(model);native=np.linspace(stamp[0],0,(len(stamp)-1)*sub+1);pos=positions(traj,native)
    radii=radii_for(res);quad=roots_legendre(nq);arr=np.empty((len(native),len(radii),ell//2+1))
    for idx,place in enumerate(pos):
        ind=min(idx//sub,len(stamp)-2);weight=idx/sub-ind
        arr[idx]=shells(place,rr,raw[ind]*(1-weight)+raw[ind+1]*weight,radii,ell,quad)
        if idx%128==0:guard()
    packet(key,V=arr,time=native,radius=radii);print(key,flush=True)
if __name__=='__main__':
    for model in (MODELS if sys.argv[1]=='all' else [sys.argv[1]]):build(model,*map(int,sys.argv[2:]))
