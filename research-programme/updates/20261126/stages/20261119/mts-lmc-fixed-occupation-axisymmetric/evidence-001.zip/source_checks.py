from axis_io import *
from lmc_field import MODELS,history,positions,potential
from shell_bank import shells
from scipy.special import roots_legendre,eval_legendre
from scipy.interpolate import CubicSpline

def run():
    rows=[]
    for model in (MODELS[0],MODELS[-1]):
        time,knots,bank,traj=history(model);xyz=positions(traj,time[-1]);coeff=bank[-1]
        radii=np.array([.1,6.,8.3,17.,37.,49.,60.,125.])
        ell=12;prod=shells(xyz,knots,coeff,radii,ell,roots_legendre(32));central=potential(-xyz[None,:],knots,coeff)[0]
        old=None
        for nmu,nphi in ((36,72),(72,144),(120,240)):
            mu,ws=roots_legendre(nmu);phi=2*np.pi*(np.arange(nphi)+.5)/nphi;st=np.sqrt(1-mu**2)
            xx,yy,zz=np.broadcast_arrays(st[:,None]*np.cos(phi),st[:,None]*np.sin(phi),mu[:,None]);unit=np.stack([xx,yy,zz],axis=-1)
            angles=np.stack([np.sqrt(2*l+1)*eval_legendre(l,mu)*ws/2 for l in range(0,ell+1,2)])
            vals=np.stack([angles@(potential(r*unit-xyz,knots,coeff).mean(axis=1)-central) for r in radii])
            for i,rad in enumerate(radii):
                norm=max(1.,np.linalg.norm(prod[i]))
                rows.append(dict(model=model,radius=rad,nmu=nmu,nphi=nphi,drive_vector_norm=np.linalg.norm(prod[i]),
                    rotated_vs_direct=np.linalg.norm(vals[i]-prod[i])/norm,refinement=np.linalg.norm(vals[i]-old[i])/norm if old is not None else ''))
            old=vals
        scalar=np.zeros_like(coeff);scalar[:25,0]=1
        vals=shells(xyz,knots,scalar,radii,ell,roots_legendre(32))
        assert abs(vals).max()<1e-10
    table('angular-source-controls.csv',rows)
if __name__=='__main__':run()
