from axis_io import *
from lmc_field import TAGS
from pulse_space import Background,basis,angular,slope,sp,splu
from finite_bar_pulse import SETTINGS
from scipy import linalg
from scipy.interpolate import CubicSpline
from feasibility import UNIT
from functools import lru_cache

CASES=('reference','added-free2-plus')
@lru_cache(maxsize=2)
def background(case):
    tag=TAGS[case%2];level=tag.split('-')[0];settings=SETTINGS[level]
    if case>=2:settings=(*settings[:3],40.)
    bg=Background(CASES[case%2],*settings,2)
    with np.load(PULSE/(tag+'-state.npz')) as state:
        size=len(state['rad']);assert np.array_equal(state['rad'],bg.rad[:size])
        assert np.linalg.norm(state['ground']-bg.ground[:size])/np.sqrt(bg.mass)<1e-9
    return bg

def sky_map(bg):
    count=bg.count;mat=[];scale=UNIT*bg.vel**2/bg.length;den=np.arange(count)*2
    for idx,rc in enumerate((6.,8.3)):
        at=bg.mesh.probes[idx];mu=1.5/np.hypot(rc,1.5);st=np.sqrt(1-mu*mu)
        inner=bg.mesh.inner[idx][:,None]*np.minimum(bg.rad[:,None]/at,1.)**(den+1)
        outer=(bg.mesh.weight-bg.mesh.inner[idx])[:,None]*np.minimum(at/bg.rad[:,None],1.)**den
        pot=-(inner+outer)/(2*den+1);grad=-(inner*(den+1)-outer*den)/((2*den+1)*at)
        y=np.array([angular(j,0,mu) for j in den]);dy=np.array([slope(j,0,mu) for j in den])
        for calc in (grad*y,pot*dy*(st/at),grad*y*(den==0)):
            mat.append(np.pad((calc*scale/bg.sqrt[:,None]).ravel(),(0,count)))
    return np.stack(mat)

def make(case,keep):
    guard();bg=background(case);nr,nl=bg.hshape;g=bg.ground.ravel();H=bg.hzero
    block=[];target=abs(keep);extras=None
    if keep<0:
        from axis_dual import force_vectors,enrich
        extras=force_vectors(case,bg,sky_map)
        target=abs(keep)+extras.shape[1]
    for ell in range(nl):
        h=H[ell::nl,ell::nl].toarray()
        _,vectors=linalg.eigh(h,subset_by_index=(0,target-1),driver='evr')
        if extras is not None:vectors=enrich(vectors[:,:abs(keep)],vectors[:,abs(keep):],extras[ell::nl],target)
        block.append(vectors)
    q=sp.block_diag(block,format='csr')[np.arange(nr*nl).reshape(nl,nr).T.ravel()]
    h=np.asarray((q.T@(H@q)).toarray());src=(bg.coupling.T@q).toarray()
    pot=np.empty_like(src)
    for ell in range(nl):
        fac=splu(bg.grav[ell::nl,ell::nl].tocsc())
        pot[ell::nl]=fac.solve(src[ell::nl])
    m=h-2*src.T@pot
    tangent=q.T@g;tangent=tangent/np.linalg.norm(tangent);tangent[0]+=np.copysign(1.,tangent[0]);tangent/=np.linalg.norm(tangent)
    def cut(matrix):
        return (matrix-2*np.outer(matrix@tangent,tangent))[:,1:]
    h=cut(cut(h).T);m=cut(cut(m).T)
    sym=max(np.max(abs(h-h.T)),np.max(abs(m-m.T)))
    chol=linalg.cholesky((h+h.T)/2,lower=True)
    stiff=chol.T@((m+m.T)/2)@chol
    freq2,evec=linalg.eigh((stiff+stiff.T)/2,driver='evd')
    assert freq2.min()>0 and sym<1e-8,(freq2.min(),sym)
    def lift(vec):
        tmp=np.vstack([np.zeros((1,vec.shape[1])),vec])
        return tmp-2*np.outer(tangent,tangent@tmp)
    modes=lift(chol@evec); momentum=lift(linalg.solve_triangular(chol.T,evec,lower=False))
    stored={'sigma':np.sqrt(freq2),'u':modes,'momentum':momentum,'sky':2*(sky_map(bg)@src)@modes,
            'block':np.array(block),'r':bg.rad,'length':bg.length,'velocity':bg.vel,'mass':bg.mass,
            'ground':bg.ground,'weight':bg.mesh.weight,'mu':bg.mu,'aw':bg.aw,'orders':bg.orders,
            'ground_outside_basis':np.linalg.norm(g-q@(q.T@g))/np.sqrt(bg.mass),
            'ground_tangent_defect':max(np.max(abs((q.T@g)@modes)),np.max(abs((q.T@g)@momentum))),'symmetry_defect':sym}
    packet(f'operators/{case}-k{keep}.npz',**stored)
    print(case,keep,'frequencies',np.sqrt(freq2[[0,-1]]),'projected occupation error',stored['ground_tangent_defect'],flush=True)
if __name__=='__main__':
    for case in map(int,sys.argv[2:]):make(case,int(sys.argv[1]))
