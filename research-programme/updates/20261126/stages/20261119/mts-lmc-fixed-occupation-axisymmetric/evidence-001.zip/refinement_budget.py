from axis_io import *
from lmc_field import MODELS,TAGS
from shell_bank import name
from axis_response import source_map,integrate

def study(case,keep):
    guard()
    with np.load(HERE/f'operators/{case}-k{keep}.npz') as pk:op={key:pk[key] for key in pk.files}
    sigma=op['sigma'];rows=[];mats={};source=(320,40,36,16)
    for model in MODELS:
        with np.load(HERE/name(model,*source)) as pk:
            rr=pk['radius'];v=pk['V'];t=pk['time']
        configs=[('full',1,40,16),('time-8',1,40,8),('time-4',1,40,4),('shell-grid-160',2,40,16),('harmonic-32',1,32,16),('harmonic-20',1,20,16)]
        for label,radstep,ell,via in configs:
            key=(radstep,ell)
            if key not in mats:mats[key]=source_map(op,rr[::radstep],ell)
            sampled=v[::16//via,::radstep,:ell//2+1];times=t[::16//via];f=(sampled.reshape(len(times),-1)@mats[key])@op['u']
            z=integrate(f,times*float(op['velocity'])/float(op['length']),sigma)[-1];a=op['sky']@z.real
            if label=='full':ref=a.copy()
            for i,R in enumerate((6.,8.3)):
                for j,coord in enumerate(('radial','polar')):
                    idx=3*i+j;rows.append(dict(model=model,R=R,component=coord,refinement=label,reference=ref[idx],probe=a[idx],
                        absolute_change=abs(a[idx]-ref[idx]),relative_axis_force=abs(a[idx]/ref[idx]-1)))
    table(f'within-bank-{case}-k{keep}.csv',rows)
if __name__=='__main__':study(*map(int,sys.argv[1:]))
