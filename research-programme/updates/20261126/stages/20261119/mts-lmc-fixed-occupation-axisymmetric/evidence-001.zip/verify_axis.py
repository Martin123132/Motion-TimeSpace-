from axis_io import *
from itertools import product
from lmc_field import TAGS, MODELS
from math import isfinite, isclose

def verify():
    guard()
    tolerance = 2e-5
    inherited = json.loads((LMC/'seal.json').read_bytes())['files']
    assert len(inherited) == 1070 and all(sha(LMC/name) == digest for name,digest in inherited.items())
    def rows(name):
        return read(HERE/name)
    def peak(data, key):
        values = [abs(float(item[key])) for item in data]
        assert values and all(map(isfinite, values))
        return max(values)
    def skykey(row, orbit):
        return tuple(row[key] for key in ('tag',orbit,'background','R','z','component'))
    reference = {skykey(row,'model'):row for row in read(LMC/'present-sky.csv')}
    grid = list(product(TAGS, MODELS, ('mts','nfw'), ('6.0','8.3'), ('1.5','-1.5'), ('radial','polar')))
    summary = rows('final-force-comparison.csv')
    assert len(summary)==len(grid)==192 and {skykey(row,'history') for row in summary}==set(grid)
    for row in summary:
        old = reference[skykey(row,'history')]
        val = float(row['axis_response'])
        assert row['initial']=='zero'
        assert all(float(row[here])==float(old[there]) for here,there in [('low','obs_low'),('high','obs_high'),('previous','subtotal')])
        assert float(row['combined'])==float(old['subtotal'])+val and isfinite(val)
        assert (row['inside']=='True')==(float(row['low'])<=float(row['combined'])<=float(row['high']))
        assert row['inside']==old['inside']
        if row['background']=='nfw':
            assert val==0
        else:
            assert val<0 if row['component']=='radial' or row['z']=='1.5' else val>0
    assert peak(summary,'number_fraction')<1e-10
    tested_controls={}
    tested_controls['quartic_and_analytic_source']=peak(rows('analytic-checks.csv'),'error')
    tested_controls['direct_angular_source']=peak([row for row in rows('angular-source-controls.csv') if row['nmu']=='120'],'rotated_vs_direct')
    tested_controls['between_potential_snapshots']=peak(rows('off-snapshot-field-check.csv'),'relative_shell_error')
    tested_controls['nonlinear_static_derivative']=max(peak(rows(f'stationary-derivative-{case}.csv'),'relative_defect') for case in (0,1))
    tested_controls['local_mass_flux']=max(peak(rows(f'mass-flow-{case}-k-100-r320-l40-q36-t16.csv'),'current_fractional_defect') for case in (0,1))
    budget=rows('response-budget.csv')
    tested_controls['enriched64_to_100']=peak([row for row in budget if row['label']=='enriched64-to100'],'relative_axis_force')
    assert all(row['decision_unchanged']=='True' for row in budget)
    for refinement in ('time-8','shell-grid-160','harmonic-32'):
        checked=[row for case in (0,1) for row in rows(f'within-bank-{case}-k-100.csv') if row['refinement']==refinement]
        assert len(checked)==48
        tested_controls[refinement]=peak(checked,'relative_axis_force')
    assert max(tested_controls.values())<=tolerance,tested_controls
    edges=rows('edge-comparison.csv')
    assert len(edges)==48 and all(row['same_band_decision']=='True' for row in edges)
    for case in (0,1):
        required=rows(f'requirement-{case}-k-100-r320-l40-q36-t16.csv')
        wider=rows(f'requirement-{case+2}-k-100-r320-l40-q36-t16.csv')
        assert len(required)==24 and all(float(row['forced_over_N'])>0 and float(row['negative_bordered_pivots'])==1 and float(row['required_over_driven'])>1 for row in required)
        assert max(peak(required,'symmetric_factor_defect'),peak(required,'backward_error'))<1e-9
        assert len(wider)==len(required)
        for small,large in zip(required,wider):
            assert all(small[name]==large[name] for name in ('model','policy','quantity'))
            assert float(large['minimum_abs_pivot'])>1e-10 and int(large['negative_bordered_pivots'])==1
            assert float(large['required_over_driven'])>1 and isclose(float(small['required_over_driven']),float(large['required_over_driven']),rel_tol=.002)
        flows=rows(f'mass-flow-{case}-k-100-r320-l40-q36-t16.csv')
        assert len(flows)==12 and all(float(row['enclosed_delta_msun'])>0 and isclose(float(row['enclosed_delta_msun']),-float(row['exterior_delta_msun']),rel_tol=1e-10) for row in flows)
        accumulated=rows(f'lookback-{case}-k-100.csv')
        for model in MODELS:
            waves=rows(f'scores/{case}-{model}-k-100-r320-l40-q36-t16-v16.csv')
            for initial in ('zero','adiabatic'):
                sel=[row for row in waves if row['initial']==initial and row['background']=='mts']
                assert len(sel)==8
                for row in sel:
                    opposite=next(alt for alt in sel if alt['R']==row['R'] and alt['z']!=row['z'] and alt['component']==row['component'])
                    assert float(opposite['axis_response'])==(1 if row['component']=='radial' else -1)*float(row['axis_response'])
            parts=[row for row in accumulated if row['model']==model]
            assert float(parts[-1]['end_native'])==0 and all(a['end_native']==b['start_native'] for a,b in zip(parts,parts[1:]))
            for component,radius,field in [('radial','6.0','radial6'),('polar','6.0','polar6'),('radial','8.3','radial8'),('polar','8.3','polar8')]:
                obs=next(row for row in waves if row['initial']=='zero' and row['background']=='mts' and row['z']=='1.5' and row['component']==component and row['R']==radius)
                assert isclose(sum(float(row[field]) for row in parts),float(obs['axis_response']),abs_tol=1e-10)
    return dict(parent_seal=PIN,previous_files_verified=len(inherited),primary_sky_rows=len(summary),six_orbits=list(MODELS),controls=tested_controls,threshold=tolerance,edge_max_fractional_force_change=peak(edges,'edge_change_over_axis'),edge_decisions_unchanged=True)

if __name__=='__main__':
    record=verify()
    seal=HERE/'seal.json'
    assert sys.argv[1:] in ([],['seal'])
    files={p.relative_to(HERE).as_posix():sha(p) for p in sorted(HERE.rglob('*')) if p.is_file() and p!=seal}
    manifest=dict(**record,files=files)
    if sys.argv[1:]==['seal']:
        put('seal.json',(json.dumps(manifest,sort_keys=True,indent=2)+'\n').encode())
    assert json.loads(seal.read_bytes())==manifest
    print(f'{len(files)} local files, {record["previous_files_verified"]} parent files; seal {sha(seal)}',flush=True)
