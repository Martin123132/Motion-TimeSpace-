from axis_io import *
from axis_operator import background,sky_map,sp,splu,basis
from lmc_field import MODELS,TAGS
from shell_bank import name
from scipy.interpolate import CubicSpline

def run(case,res,ell,nq,sub):
    bg=background(case);g=bg.ground.ravel();col=sp.csc_matrix(g[:,None]);d=bg.hzero.shape[0]
    matrix=sp.bmat([[bg.hzero,bg.coupling,-col],[2*bg.coupling.T,bg.grav,None],[col.T,None,sp.csc_matrix((1,1))]],format='csc')
    fac=splu(matrix);ang=basis(np.arange(0,ell+1,2),0,bg.mu);readout=sky_map(bg);rows=[]
    for model in MODELS:
        with np.load(HERE/name(model,res,ell,nq,sub)) as pk:
            src=CubicSpline(pk['radius'],pk['V'][-1],axis=0)(bg.rad*bg.length)
        V=src@ang.T/bg.vel**2;F=((bg.sky*V)@(bg.aw[:,None]*bg.harm)*bg.sqrt[:,None]).ravel()
        rhs=np.r_[-F,np.zeros(bg.grav.shape[0]+1)];state=fac.solve(rhs);X=state[:d];mismatch=matrix@state-rhs
        dens=2*(bg.coupling.T@X);a=readout@dens;other=bg.sky_forces(dens[:-bg.count])
        const=fac.solve(np.r_[-g,np.zeros(bg.grav.shape[0]+1)])
        assert abs(g@X)<1e-9 and np.linalg.norm(const[:d])<1e-8
        for j,site in enumerate((6.,8.3)):
            rows.append(dict(tag=TAGS[case],model=model,R=site,polar=a[3*j+1],radial=a[3*j],radial_monopole=a[3*j+2],
                independent_polar=other[j,0],independent_radial=other[j,1],constant_density_defect=np.linalg.norm(const[:d]),
                chemical_shift=state[-1],residual=np.linalg.norm(mismatch)/np.linalg.norm(rhs),number_fraction=2*(g@X)/bg.mass))
    table(f'static-{case}-r{res}-l{ell}-q{nq}-t{sub}.csv',rows)
if __name__=='__main__':run(*map(int,sys.argv[1:]))
