from axis_io import *
from lmc_field import MODELS
def cases(case,model,keep,res,ell,nq,sub):
    return read(HERE/f'scores/{case}-{model}-k{keep}-r{res}-l{ell}-q{nq}-t{sub}-v{sub}.csv')
def run():
    rows=[]
    for case in (0,1):
        for model in MODELS:
            base=cases(case,model,-100,320,40,36,16)
            for label,other in [('enriched64-to100',cases(case,model,-64,320,40,36,16)),('ordinary112-medium-bank',cases(case,model,112,192,32,32,8))]:
                for b,o in zip(base,other):
                    assert all(b[k]==o[k] for k in ('initial','component','background','R','z'))
                    if b['background']!='mts' or b['z']!='1.5':continue
                    val=float(b['axis_response']);change=abs(val-float(o['axis_response']))
                    rows.append(dict(case=case,model=model,label=label,initial=b['initial'],R=b['R'],component=b['component'],
                        absolute_change=change,relative_axis_force=change/abs(val),decision_unchanged=b['inside']==o['inside']))
    table('response-budget.csv',rows)
if __name__=='__main__':run()
