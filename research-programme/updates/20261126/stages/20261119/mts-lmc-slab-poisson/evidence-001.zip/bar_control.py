from ordinary_flux import guard, save, bar
from slab_fields import *

def build(last):
    radii=np.geomspace(.00004,65.,610)
    mu,aw=rule(120,0.,1.);phi,pw=rule(64,0.,np.pi/2)
    planar=np.cos(phi)**2/AXES[0]**2+np.sin(phi)**2/AXES[1]**2
    shape=(((1-mu[:,None]**2)*planar)**2+(mu[:,None]/AXES[2])**4)**.25
    deg=np.arange(0,last+1,2);projection=aw[:,None]*basis(deg,0,mu)
    norm=sum(LENS.central)/BAR_NORM*4*np.pi*G
    out=np.empty((len(radii),len(deg)))
    for idx in range(0,len(radii),32):
        slab=radii[idx:idx+32,None,None]
        out[idx:idx+len(slab)]=((k0(slab*shape)@(pw*2/np.pi))@projection)*norm
    return Multipoles(radii,out,deg,0,68.,spacing=.009)

def main():
    guard();rows=[]
    for last in (44,88):
        field=build(last)
        for radius in RADII:
            compression,column,horizontal,*_=measure(field,0,radius,step=.005,order=32)
            actual=ordinary(0,radius)[-1]/SHEET
            pol=bar().at(radius,HALF,0.)[0]
            original=(radius*pol['polar']-HALF*pol['radial'])/(HALF*np.hypot(radius,HALF))
            rows.append(dict(R=radius,degree=last,K=compression,saved_K=original,horizontal=horizontal,projected_column=column,physical_column=actual,
                            projected_minus_physical=column-actual,slab_residual=compression-column-horizontal))
    save('bar-control.csv',rows)
if __name__=='__main__':main()
