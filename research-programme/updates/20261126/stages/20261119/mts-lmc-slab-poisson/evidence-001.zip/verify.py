from slab_test import guard, PIN, save
from slab_fields import *
from ordinary_flux import probability
import json, sys

def run():
    guard()
    pinned=json.loads((GAS/'seal.json').read_text())
    tol=pinned['tolerance']
    assert all(digest(GAS/file)==val for file,val in pinned['files'].items())
    signed=read(STAGE/'axis-force-replay.csv')
    assert len(signed)==192 and len({tuple(row[key] for key in ('case','orbit','R','z','background','component')) for row in signed})==192
    for row in signed:
        assert row['inside']==row['saved_inside']
        value=float(row['new_total'])
        assert (float(row['low'])<=value<=float(row['high']))==(row['inside']=='True')
        if row['background']=='mts':assert float(row['abs_difference'])<tol*abs(float(row['saved_increment']))
        else:assert float(row['predicted_increment'])==0.
    components=read(STAGE/'components.csv'); tot=read(STAGE/'total.csv');scenarios=read(STAGE/'branch-contrast.csv')
    assert len(components)==216 and len(tot)==48 and len(scenarios)==12
    assert {(int(r['case']),r['orbit']) for r in scenarios}=={(c,m) for c in (0,1) for m in MODELS}
    for row in components:
        assert abs(float(row['K_minus_saved']))<max(1e-12,tol*abs(float(row['saved_K'])))
        if row['component']!='ordinary':assert abs(float(row['slab_error']))<max(1e-12,tol*abs(float(row['K'])))
    truth=read(STAGE/'ordinary-independent-flux.csv');bars=read(STAGE/'bar-control.csv')
    inds=[];pred=read(STAGE/'ordinary-column.csv')
    for row in tot:
        rad=float(row['R']);fg=int(row['case']); group=[p for p in components if all(p[key]==row[key] for key in ('orbit','R','background','case'))]
        control=next(p for p in truth if p['case']==row['case'] and p['R']==row['R'] and p['resolution']=='fine')
        central=next(p for p in bars if float(p['R'])==rad and p['degree']=='44')
        other_bar=next(p for p in bars if float(p['R'])==rad and p['degree']=='88')
        assert abs(float(other_bar['horizontal'])-float(central['horizontal']))<2e-9 and abs(float(central['slab_residual']))<2e-9
        physical=sum(float(control[k]) for k in ('disk','gas','cloud','added'))+float(central['horizontal'])
        rest=sum(float(item['horizontal']) for item in group if item['component']!='ordinary')
        independent=physical+rest+float(row['column_tide'])
        err=independent-float(row['saved_K'])
        assert abs(err)<tol*abs(float(row['saved_K']))
        inds.append(dict(case=fg,orbit=row['orbit'],R=rad,background=row['background'],physical_column_tide=row['column_tide'],independent_horizontal=physical+rest,independent_K=independent,saved_K=row['saved_K'],difference=err))
    save('independent-totals.csv',inds)
    assert all(float(r['gap_with_NFW_horizontal_only'])>0 and abs(float(r['remaining']))<3e-8 for r in scenarios)
    witnesses=read(STAGE/'fixed-shape-witness.csv')
    assert len(witnesses)==24 and len(read(STAGE/'fixed-shape-signed-amplitudes.csv'))==192
    assert len({(r['case'],r['orbit'],r['frame']) for r in witnesses})==24
    assert all(float(r['inner_north_polar_allows_at_most'])<0<float(r['inner_north_radial_requires_at_least']) and float(r['all_lower'])>float(r['all_upper']) for r in witnesses)
    assert sum(float(r['gap_with_NFW_column_only'])<=0 for r in scenarios)==9
    def quadratic(radius,height):
        return -2*radius+0*height,-5*height,radius**2+2.5*height**2,9+0*height
    def vacuum(radius,height):
        return -2*radius+0*height,0*height,radius**2+0*height,0*height
    for rad in RADII:
        assert max(abs(measure(quadratic,0,rad)[:3]/UNIT-[5,9,-4]))<1e-10
        assert max(abs(measure(vacuum,2,rad)[:3]/UNIT))<1e-10
        assert abs(probability(np.array([0.]),.5)[0]+np.expm1(-HALF/.5))<1e-15
    for r in read(STAGE/'input-hashes.csv'):assert digest(ROOT/r['path'])==r['sha256']
    more={GAS/'seal.json',ROOT/'mts-population-resolved-gravity-20261119'/'mass-spherical-fine-main-384-32.npz',
          ROOT/'mts-inner-stellar-height-response-20261119'/'fine-solutions.csv',
          ROOT/'mts-annular-mass-budget-20261119'/'independent-budget.csv', MASS.parent/'bar-extra.npz'}
    for model in MODELS:
        source=LMC/'source'/model
        more.update([source/'trajlmc.txt',source/'potential.ini',*list((source/'pot').glob('lmc*.ini'))])
    assert len(more)>100
    save('source-bank-hashes.csv',[dict(path=str(p.relative_to(ROOT)),sha256=digest(p)) for p in sorted(more)])
    files={p.name:digest(p) for p in sorted(STAGE.iterdir()) if p.is_file() and p.name!='seal.json'}
    seal=dict(files=files,parent_seal=PIN,parent_files_verified=len(pinned['files']),signed_checks=len(signed),number_of_histories=len(MODELS),independent_totals=len(inds),source_tolerance=tol)
    path=STAGE/'seal.json'
    if sys.argv[1:]==['seal'] and not path.exists():
        with path.open('x',encoding='utf8') as fd:json.dump(seal,fd,indent=2,sort_keys=True);fd.write('\n')
    elif sys.argv[1:]!=['check-only']:assert json.loads(path.read_text())==seal
    print('checked',len(signed),'signed probes;',len(inds),'independent totals; maximum absolute mismatch',max(abs(row['difference']) for row in inds))
if __name__=='__main__':run()
