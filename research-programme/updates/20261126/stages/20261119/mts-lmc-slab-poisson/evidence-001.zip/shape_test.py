from slab_test import *
from itertools import product

def run():
    guard();signed=read(STAGE/'axis-force-replay.csv');data=[];intersection=[]
    for case,model in product((0,1),MODELS):
        via=32 if model=='L2M11' else 16
        history_rows=read(GAS/f'outputs/sky-{case}-{model}-{via}.csv')
        for frame in ('site_minus_point','site_minus_material_planar'):
            box=[]
            for radius,z,component in ROWS:
                row=next(rec for rec in history_rows if (rec['background'],rec['frame'],float(rec['R']),float(rec['z']),rec['component'])==('mts',frame,radius,z,component))
                axis=next(rec for rec in signed if (int(rec['case']),rec['orbit'],rec['background'],float(rec['R']),float(rec['z']),rec['component'])==(case,model,'mts',radius,z,component))
                delta=float(axis['saved_increment'])
                base=float(row['corrected'])-delta
                lo,hi=float(row['low']),float(row['high'])
                lower,upper=sorted([(lo-base)/delta,(hi-base)/delta])
                assert np.isclose(base+delta*lower,lo if delta>0 else hi) and np.isclose(base+delta*upper,hi if delta>0 else lo)
                assert (lower<=1<=upper)==(lo<=float(row['corrected'])<=hi)
                obs=dict(case=case,orbit=model,frame=frame,R=radius,z=z,component=component,a0=base,increment=delta,low=lo,high=hi,amplitude_low=lower,amplitude_high=upper)
                data.append(obs);box.append(obs)
            north={r['component']:r for r in box if r['R']==6. and r['z']==1.5}
            radial=north['radial']['amplitude_low'];polar=north['polar']['amplitude_high']
            assert polar<0<radial
            intersection.append(dict(case=case,orbit=model,frame=frame,inner_north_radial_requires_at_least=radial,inner_north_polar_allows_at_most=polar,
                                     all_lower=max(r['amplitude_low'] for r in box),all_upper=min(r['amplitude_high'] for r in box),feasible=False))
    save('fixed-shape-signed-amplitudes.csv',data); save('fixed-shape-witness.csv',intersection)
if __name__=='__main__':run()
