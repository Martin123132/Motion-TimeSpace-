from slab_fields import *
from scipy.linalg import eigh
from terminal_check import end_modes
import csv, json, io, hashlib
from gas_io import guard as parent_guard
from tidal_contrasts import ROWS, weights as sky_weights

PIN='53a6c0b1bbf5ba86680e933814ae23c990c55b4618af87dfada312527317c795'
def guard():
    parent_guard()
    assert digest(GAS/'seal.json')==PIN and not (STAGE/'STOP-REQUESTED').exists()

INPUTS={}
def used(path):
    if path not in INPUTS: INPUTS[path]=digest(path)
    return path
def packet(path,keys):
    with np.load(used(path)) as bank:return {key:bank[key] for key in keys.split()}
def table(path):
    return read(used(path))
def save(name,rows):
    buf=io.StringIO(newline='');writer=csv.DictWriter(buf,rows[0],lineterminator='\n')
    writer.writeheader(); writer.writerows(rows);raw=buf.getvalue().encode()
    path=STAGE/name
    if path.exists():assert path.read_bytes()==raw,path
    else:
        with path.open('xb') as stream:stream.write(raw)

def ground(case):
    source=packet(MASS.parent/f'extra-{CASES[case]}-mean.npz','rad wave mu aw weights edge mass vel length')
    vel,length=source['vel'],source['length'];rad=source['rad']
    deg=np.arange(0,81,2);harm=basis(deg,0,source['mu'])
    rho=(source['wave']/rad[:,None])**2@(source['aw'][:,None]*harm)
    assert abs(source['weights']@(rho[:,0]*rad**2)-source['mass'])<1e-10
    return Multipoles(rad*length,rho*(vel/length)**2,deg,0,source['edge']*length)

def modal(op,pos,mode,weight):
    multip=mode+np.arange(len(op['block']))*2
    physical=np.einsum('lrk,lk->rl',op['block'],(op['waves']@pos.real).reshape(len(multip),-1))
    mu,aw,rad,length=op['mu'],op['aw'],op['rad'],op['length']
    harm=basis(multip,mode,mu)
    density=((op['ground']@basis(multip-mode,0,mu).T)*(physical@harm.T))@(aw[:,None]*harm)
    source=(2*(-1)**mode*op['vel']**2/(weight*rad**2))[:,None]*density
    return Multipoles(rad,source,multip,mode,30*length)

def checked(field,mode,radius):
    fine=measure(field,mode,radius)
    coarse=measure(field,mode,radius,step=.016,order=16)
    return fine,max(abs(fine[:3]-coarse[:3]))

def main():
    guard()
    led=table(QUAD/'combined-force-ledger.csv'); old=table(LMC/'response-n6144.csv')
    totals=table(GAS/'vertical-tides.csv'); scores=table(AX/'final-force-comparison.csv')
    results=[];summary=[];comparisons=[];bandrows=[];ordinary_rows=[]
    for case in (0,1):
        fg=ground(case); nf=nfw(case)
        static={r:(checked(fg,0,r),checked(nf,0,r)) for r in RADII}
        two=packet(QUAD/f'operators/{case}-64.npz','ground rad weight mu aw length vel block waves mass')
        one=packet(LAST/f'operators/{case}-64.npz','ground rad mu aw length vel block waves mass center freq')
        assert np.array_equal(one['rad'],two['rad'])
        mr=table(MASS)[case];gamma=float(mr['dark_mass'])/(float(mr['total_gravitating_mass'])-float(mr['dark_mass']))
        sig=one['freq'];vec=sig*one['center'];sq,rot=eigh(np.diag(sig**2)+gamma*one['mass']*np.outer(vec,vec),driver='evd')
        drive=one['mass']*(rot.T@vec)
        for radius in RADII:
            components=ordinary(case,radius)
            ordinary_rows.append(dict(case=case,R=radius,stars=components[0],added=components[1],HI_H2=components[2],bar_mean=components[3],total=sum(components)))
        for model in MODELS:
            guard()
            via=32 if model=='L2M11' else 16
            ax=packet(AX/f'states/{case}-{model}-k-100-r320-l40-q36-t16-v16.npz','r delta_rho_multipoles number_fraction')
            frac=float(ax['number_fraction'])
            assert abs(frac)<1e-15
            deg=np.arange(ax['delta_rho_multipoles'].shape[1])*2
            mzero=Multipoles(ax['r'],ax['delta_rho_multipoles']*(one['vel']/one['length'])**2,deg,0,30*one['length'])
            mpos=packet(QUAD/f'states/{case}-64-{model}-r192-l24-t16-d1.npz','displacement')['displacement']
            oldrow=next(row for row in old if (row['model'],row['tag'],row['source'],row['start'])==(model,TAGS[case],'full','zero') and float(row['start_native'])==history(model)[0][0])
            mpos[0]=complex(float(oldrow['displacement_re']),float(oldrow['displacement_im']))
            mtwo=modal(two,mpos,2,two['weight'])
            endpoint=packet(PARENT/f'state-{case}-{via}-{model}.npz','mode')['mode']
            fresh=packet(GAS/f'outputs/state-{case}-{model}-{via}.npz','source_main time')
            delta,_=end_modes(fresh['time'],fresh['source_main'].sum(1),np.sqrt(sq),one['vel'],one['length'])
            mone=modal(one,endpoint+(rot@(drive*delta))/sig,1,two['weight'])
            for radius in RADII:
                wave,halo=static[radius]
                sub=[rec for rec in led if rec['orbit']==model and rec['tag']==TAGS[case] and float(rec['R'])==radius]
                def contrast(bg,key):
                    lookup={(float(row['R']),float(row['z']),row['component']):float(row[key]) for row in sub if row['background']==bg}
                    return sky_weights(radius)@np.array([lookup.get(k,0.) for k in ROWS])
                ordinary_k=contrast('nfw','stationary')-halo[0][0]
                base_mismatch=wave[0][0]+ordinary_k-contrast('mts','stationary')
                ext=external(model,radius)
                coarse=external(model,radius,step=.07,order=12)
                satellite=(ext,max(abs(ext-coarse)))
                item={key:checked(field,idx,radius) for key,field,idx in [('m0',mzero,0),('m1',mone,1),('m2',mtwo,2)]}
                for score in scores:
                    if (int(score['case']),score['history'],float(score['R']))!=(case,model,radius):continue
                    polar=score['component']=='polar'; north=float(score['z'])>0
                    addition=item['m0'][0][3+int(polar)]*(1 if north or not polar else -1) if score['background']=='mts' else 0.
                    ref=float(score['axis_response']);val=float(score['previous'])+addition
                    lo,hi=float(score['low']),float(score['high'])
                    bandrows.append(dict(case=case,orbit=model,R=radius,z=score['z'],background=score['background'],component=score['component'],predicted_increment=addition,saved_increment=ref,abs_difference=abs(addition-ref),new_total=val,low=lo,high=hi,inside=lo<=val<=hi,saved_inside=score['inside']))
                for bg in ('mts','nfw'):
                    row=next(rec for rec in totals if (int(rec['case']),rec['model'],rec['background'],rec['frame'],float(rec['R']))==(case,model,bg,'site_minus_point',radius))
                    observed=float(row['compression'])
                    ordinary_col=sum(ordinary(case,radius))/SHEET
                    pieces=[('ordinary',([ordinary_k,ordinary_col,ordinary_k-ordinary_col],0.),ordinary_k,'inferred_horizontal'),
                            ('direct_LMC',satellite,contrast(bg,'direct_satellite'),'3D_archived_potential')]
                    if bg=='nfw':pieces.append(('matched_NFW',halo,halo[0][0],'analytic'))
                    else:
                        prior_m1=observed-contrast(bg,'total')
                        pieces.extend([('wave_ground',wave,wave[0][0]-base_mismatch,'saved_ground'),('m0',item['m0'],contrast(bg,'fixed_number_m0'),'fixed_occupation'),
                                       ('m2',item['m2'],contrast(bg,'lowest_m2')+contrast(bg,'remaining_m2'),'live'),('m1',item['m1'],prior_m1,'coupled_recoil')])
                    for key,(values,refine),prior,source in pieces:
                        kval,col,horiz=values[:3]
                        results.append(dict(case=case,orbit=model,R=radius,background=bg,component=key,source=source,K=kval,column_Msun_pc2=col*SHEET,column_tide=col,horizontal=horiz,slab_error=kval-col-horiz,step_change=refine,saved_K=prior,K_minus_saved=kval-prior))
                    vals=np.sum([pair[1][0][:3] for pair in pieces],axis=0)
                    summary.append(dict(case=case,orbit=model,R=radius,background=bg,K=vals[0],saved_K=observed,closed_K=vals[1]+vals[2],column_tide=vals[1],horizontal=vals[2],band_min=row['band_min'],band_max=row['band_max']))
            print(case,model,'checked',flush=True)
    for case in (0,1):
        for model in MODELS:
            pair={(float(row['R']),row['background']):row for row in summary if (row['case'],row['orbit'])==(case,model)}
            def diff(index,key):
                return pair[RADII[index],'nfw'][key]-pair[RADII[index],'mts'][key]
            def gap(bg):
                inner=pair[6.,bg];outer=pair[8.3,bg]
                return float(inner['band_min'])-inner['saved_K']-float(outer['band_max'])+outer['saved_K']
            column=diff(0,'column_tide')-diff(1,'column_tide')
            horiz=diff(0,'horizontal')-diff(1,'horizontal')
            comparisons.append(dict(case=case,orbit=model,mts_gap=gap('mts'),nfw_gap=gap('nfw'),halo_minus_wave_column_contrast=column,halo_minus_wave_horizontal_contrast=horiz,
                                    gap_with_NFW_column_only=gap('mts')-column,gap_with_NFW_horizontal_only=gap('mts')-horiz,remaining=gap('mts')-gap('nfw')-column-horiz))
    for key,rows in [('components',results),('total',summary),('branch-contrast',comparisons),('axis-force-replay',bandrows),('ordinary-column',ordinary_rows)]:
        save(key+'.csv',rows)
    save('input-hashes.csv',[dict(path=str(path.relative_to(ROOT)),sha256=value) for path,value in sorted(INPUTS.items())])

if __name__=='__main__':main()
