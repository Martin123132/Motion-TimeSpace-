from pathlib import Path
import sys
STAGE = Path(__file__).resolve().parent
ROOT = STAGE.parent
GAS = ROOT / 'mts-lmc-gas-history-correction-20261119'
sys.path.insert(0, str(GAS))
from gas_io import np, read, digest, MODELS, UNIT, MASS, LAST, PARENT, roots_legendre
from local_io import AX, LMC
from recoil_io import PRE as QUAD
from dual_probe import G, OUTER
from pulse_space import basis, slope
from scipy.interpolate import CubicSpline, CubicHermiteSpline
from scipy.special import k0
from lmc_field import TAGS, history, harmonic, potential
from kernel import Lenses, HEIGHT, AXES, BAR_NORM
from rings import sky_ring
from functools import lru_cache
from gas_common import gases

HALF = 1.5
RADII = (6., 8.3)
CASES = ('reference', 'added-free2-plus')
LENS = Lenses()
RING = float(next(row['amplitude'] for row in read(ROOT/'mts-annular-mass-budget-20261119'/'independent-budget.csv')
                  if tuple(row[key] for key in ('family','width','side','calibration')) == ('added','2','plus','free')))
SHEET = 2*HALF/(4*np.pi*G*UNIT*1e6)

def rule(order, lo, hi):
    nodes, weights = roots_legendre(order)
    return lo+(nodes+1)*(hi-lo)/2, weights*(hi-lo)/2

def ordinary(case, radius):
    surface = LENS.stars.radial(np.array([radius]))[0]
    thin = np.full(len(surface), HEIGHT[0])
    thin[0] = LENS.profile.heights(radius)[0]
    enclosed = LENS.stars.mix[:,0]*(-np.expm1(-HALF/thin))+LENS.stars.mix[:,1]*(-np.expm1(-HALF/HEIGHT[1]))
    stars = surface @ enclosed
    added = case*RING*surface[0]*enclosed[0]*int(4 < radius < 7)
    gas = sum(item.surface(radius)*np.tanh(HALF/(2*item.height)) for item in gases())
    angles, weights = rule(48,0,np.pi/2)
    heights, vertical = rule(32,0,HALF)
    axes = (radius*np.cos(angles)/AXES[0])**2+(radius*np.sin(angles)/AXES[1])**2
    bar = 4/np.pi*vertical @ k0((axes[None,:]**2+(heights[:,None]/AXES[2])**4)**.25) @ weights * sum(LENS.central)/BAR_NORM
    return np.array([stars, added, gas, bar])*1e-6

def nfw(case):
    folder = ROOT/'mts-inner-stellar-height-response-20261119'
    row = next(row for row in read(folder/'fine-solutions.csv') if tuple(row[key] for key in ('mode','model','profile'))==('matched','nfw','pooled'))
    with np.load(ROOT/'mts-population-resolved-gravity-20261119'/'mass-spherical-fine-main-384-32.npz') as bank:
        coords = bank['locations']; force = bank['matched_nfw_force']*float(row['amplitude_ratio'])
    index, = np.flatnonzero(np.linalg.norm(coords-[-OUTER,0,0],axis=1)<1e-8)
    extra = float(read(MASS)[case]['outer_speed_material_delta'])+case*RING*sky_ring(LENS.profile,OUTER,0.,'fine',(4.,7.))[0]
    halo = force[index,0]-extra
    def shape(rad):
        ratio = rad/16.
        return np.log1p(ratio)-ratio/(1+ratio)
    amp = OUTER**2*halo/shape(OUTER)
    radii = np.linalg.norm(coords[-4:-2],axis=1)
    assert np.allclose(force[-4:-2]*(halo/force[index,0]), -coords[-4:-2]*(amp*shape(radii)/radii**3)[:,None], rtol=1e-10)
    def field(radius, z):
        rad = np.hypot(radius,z)
        acc = -amp*shape(rad)/rad**3
        return acc*radius,acc*z,-amp*np.log1p(rad/16.)/rad,amp/(rad*(16.+rad)**2)
    return field

class Multipoles:
    def __init__(self, physical_radius, source, degrees, mode, outer, spacing=.035):
        self.deg, self.mode = degrees,mode
        rad = np.r_[0., physical_radius, outer]
        left = np.zeros_like(source[0])
        if degrees[0]==0: left[0]=source[0,0]
        self.source = CubicSpline(rad,np.vstack((left,source,np.zeros_like(left))),axis=0)
        edges=np.unique(np.r_[rad,np.arange(5.8,8.7,spacing)])
        lo,hi=edges[:-1],edges[1:]
        nodes,weights=rule(5,0,1)
        sample=lo[:,None]+(hi-lo)[:,None]*nodes
        dens=self.source(sample)
        measure=(hi-lo)[:,None]*weights
        deg=degrees[None,None,:]
        inn=np.einsum('iq,iqd->id',measure*sample**2/hi[:,None],(sample/hi[:,None])[:,:,None]**deg*dens)
        out=np.einsum('iq,iqd->id',measure*sample,(lo[:,None]/sample)[:,:,None]**deg*dens)
        ratio=(lo/hi)[:,None]**degrees
        forward=np.zeros((len(edges),len(degrees)));backward=forward.copy()
        for idx in range(len(lo)):
            forward[idx+1]=forward[idx]*ratio[idx]*lo[idx]/hi[idx]+inn[idx]
        for idx in range(len(lo)-1,-1,-1):
            backward[idx]=backward[idx+1]*ratio[idx]+out[idx]
        value=-(forward+backward)/(2*degrees+1)
        deriv=((degrees+1)*forward-degrees*backward)/((2*degrees+1)*np.maximum(edges[:,None],1e-100))
        self.gravity=CubicHermiteSpline(edges,value,deriv,axis=0)

    def __call__(self,radius,z):
        rad=np.atleast_1d(np.hypot(radius,z)); mu=np.atleast_1d(z/rad)
        harm=basis(self.deg,self.mode,mu)
        angular_der=np.stack([slope(int(ell),self.mode,mu) for ell in self.deg],axis=1)
        val=self.gravity(rad); der=(self.gravity(rad,1)*harm).sum(1)
        partial=(val*angular_der).sum(1)/rad
        grav_r=-radius/rad*(der-mu*partial)
        grav_z=-mu*der-(1-mu**2)*partial
        return grav_r,grav_z,(val*harm).sum(1),(self.source(rad)*harm).sum(1)

def measure(field,mode,radius,step=.008,order=28):
    height, weights=rule(order,0,HALF)
    radial,_,pot,dens=field(radius,height)
    derivative=sum(coeff*field(radius+idx*step,height)[0] for idx,coeff in [(-2,1),(-1,-8),(1,8),(2,-1)])/(12*step)
    horiz=UNIT*(weights @ (derivative+radial/radius+mode**2*pot/radius**2))/HALF
    column=UNIT*(weights@dens)/HALF
    gr,gz,*_=field(radius,np.array([HALF]))
    compression=-UNIT*gz[0]/HALF
    length=np.hypot(radius,HALF)
    ar=UNIT*(gr[0]*radius+gz[0]*HALF)/length
    polar=UNIT*(gr[0]*HALF-gz[0]*radius)/length
    return np.array([compression,column,horiz,ar,polar])

@lru_cache(maxsize=6)
def external(model,radius,step=.035,order=20):
    _,knots,shapes,traj=history(model);pos=traj[-1,1:4]; coeff=shapes[-1]
    dx2=(-radius-pos[0])**2+pos[1]**2
    cuts=sorted(set([-HALF,HALF]+[float(val) for knot in knots if knot**2>dx2 for val in
                      (pos[2]-np.sqrt(knot**2-dx2),pos[2]+np.sqrt(knot**2-dx2)) if abs(val)<HALF]))
    parts=[rule(order,lo,hi) for lo,hi in zip(cuts,cuts[1:])]
    height,weights=(np.concatenate(arr) for arr in zip(*parts))
    xyz=np.stack((np.full_like(height,-radius),np.zeros_like(height),height),axis=1)-pos
    distance=np.linalg.norm(xyz,axis=1)
    assert min(distance)>knots[0] and max(distance)<knots[-1]
    mu=xyz[:,2]/distance; phi=np.arctan2(xyz[:,1],xyz[:,0]);logr=np.log(distance)
    curve=CubicHermiteSpline(np.log(knots),coeff[:len(knots)],coeff[len(knots):],axis=0)
    vals=curve(logr); der=curve(logr,1)+curve(logr,2); density=np.zeros_like(distance)
    for degree in range(7):
        center=degree*(degree+1)
        term=(der-degree*(degree+1)*vals)/distance[:,None]**2
        density+=term[:,center]*harmonic(degree,0,mu,phi).real
        for order_m in range(1,degree+1):
            ylm=harmonic(degree,order_m,mu,phi)
            density+=np.sqrt(2)*(term[:,center+order_m]*ylm.real+term[:,center-order_m]*ylm.imag)
    def value(points):return potential(points,knots,coeff)
    horiz=np.zeros_like(distance); origin=value(xyz)
    for direction in np.eye(3)[:2]:
        horiz-=(-value(xyz+2*step*direction)+16*value(xyz+step*direction)-30*origin+16*value(xyz-step*direction)-value(xyz-2*step*direction))/(12*step**2)
    ends=np.array([[-radius,0,-HALF],[-radius,0,HALF]])-pos; dz=np.array([0,0,step])
    acc=-(-value(ends+2*dz)+8*value(ends+dz)-8*value(ends-dz)+value(ends-2*dz))/(12*step)
    return UNIT*np.array([(acc[0]-acc[1])/(2*HALF),weights@density/(2*HALF),weights@horiz/(2*HALF)])
