import sys
from datetime import date
from scipy.special import k0
from read_survey import PARENT,HOME,guard,np,save_rows
sys.path.insert(0,str(PARENT))
from kernel import Lenses,Ray,CAP,SUN,Z_SUN,AXES,BAR_NORM,HEIGHT,OLD

BANDS=[("entire",.5,9.),("b1",1.4,2.),("b2",2.,2.5),("b3",2.5,3.),("b4",3.,3.5),("b5",3.5,7.)]
SOURCES=(8.,10.,np.inf)
COUNTS=np.array([630884,829123,976707,931147,2194599])
TOTAL=5569216
EXPOSURE=6.62e9
MAX_DAYS=(date(2002,11,1)-date(1996,7,1)).days

def height_range(profile,rlo,rhi):
    curve=profile.curves[0]
    base=np.interp(SUN,curve[:,0],curve[:,1])
    hlo=np.minimum(np.interp(rlo,curve[:,0],curve[:,1]),np.interp(rhi,curve[:,0],curve[:,1]))
    hhi=np.maximum(np.interp(rlo,curve[:,0],curve[:,1]),np.interp(rhi,curve[:,0],curve[:,1]))
    for radius,value in curve[:,:2]:
        inside=(rlo<=radius)&(radius<=rhi)
        hlo=np.where(inside,np.minimum(hlo,value),hlo)
        hhi=np.where(inside,np.maximum(hhi,value),hhi)
    def smooth(value):
        val=np.clip(value,0.,1.)
        return val**2*(3-2*val)
    wlo=smooth(rlo-3.5)*smooth((SUN-rhi)/(SUN-7.25))
    whi=smooth(rhi-3.5)*smooth((SUN-rlo)/(SUN-7.25))
    ends=np.stack([OLD*(1+weight*(level/base-1)) for weight in (wlo,whi) for level in (hlo,hhi)])
    return ends.min(axis=0),ends.max(axis=0)

def density_ceiling(lenses,left,right,low,high,lmin=0.,lmax=15.):
    low,high,lmin,lmax=np.radians([low,high,lmin,lmax])
    near,far=left*np.cos(high),right*np.cos(low)
    delta=np.maximum.reduce([near-SUN*np.cos(lmin),SUN*np.cos(lmin)-far,np.zeros_like(far)])
    rlo=np.hypot(delta,SUN*np.sin(lmin))
    rhi=np.hypot(np.maximum(abs(near-SUN*np.cos(lmax)),abs(far-SUN*np.cos(lmax))),SUN*np.sin(lmax))
    zlo=np.maximum(0,left*np.sin(low)-Z_SUN)
    zhi=right*np.sin(high)+Z_SUN
    stars=lenses.stars
    cols=np.maximum(stars.radial(rlo),stars.radial(rhi))
    for knot in np.unique(np.r_[stars.knots,stars.bgrid]):
        inside=(rlo<=knot)&(knot<=rhi)
        cols[inside]=np.maximum(cols[inside],stars.radial(knot))
    hlo,hhi=height_range(lenses.profile,rlo,rhi)
    best=np.clip(zlo,hlo,hhi)
    vertical=np.exp(-zlo[:,None]/HEIGHT)/(2*HEIGHT)@stars.mix.T
    vertical[:,0]=stars.mix[0,0]*np.exp(-zlo/best)/(2*best)+stars.mix[0,1]*np.exp(-zlo/HEIGHT[1])/(2*HEIGHT[1])
    disk=(cols*vertical).sum(axis=1)
    living=(cols*vertical)[:,0]*((rlo<=7)&(rhi>=4))
    slo,shi=np.hypot(rlo,zlo),np.hypot(rhi,zhi)
    sph=np.zeros_like(left)
    for inner,outer,gradient in zip(stars.bgrid[:-1],stars.bgrid[1:],stars.bgradient.sum(axis=1),strict=True):
        if gradient==0:continue
        assert gradient<0
        radius=np.clip(inner,slo,shi)
        assert radius.min()>0
        sph+=(-gradient*1e6/np.pi)*(np.arccosh(np.maximum(1,outer/radius))-np.arccosh(np.maximum(1,inner/radius)))
    shape=((rlo/max(AXES[:2]))**4+(zlo/AXES[2])**4)**.25
    assert shape.min()>0
    bar=k0(shape)*sum(lenses.central)/BAR_NORM
    return np.column_stack([disk+sph,disk+bar,living])

def bound(lenses,low,high,source,step):
    end=min(52.,source)
    edges=np.linspace(0,end,round(end/step)+1)
    left,right=edges[:-1],edges[1:]
    den=density_ceiling(lenses,left,right,low,high)
    integral=(right-left)*((right+left)/2-(right**2+right*left+left**2)/(3*source))
    tau=CAP*(integral@den)
    if np.isinf(source):
        assert end*np.cos(np.radians(high))-SUN>lenses.stars.knots[-1]
        length=max(AXES)*2**.25
        arg=(end-np.hypot(SUN,Z_SUN))/length
        tail=np.sqrt(np.pi/(2*arg))*np.exp(-arg)*length*(end+length)
        tau[1]+=CAP*sum(lenses.central)/BAR_NORM*tail
    return tau*(1+2e-12)

def direct(lenses,lon,lat,source):
    ray=Ray(lon,lat)
    dist,weight=lenses.grid(ray,12,[source] if np.isfinite(source) else [],min(65.,source))
    den,cyl=lenses.density(ray,dist)
    proj=CAP*(weight*dist*(1-dist/source))
    return np.array([proj@den[:,:8].sum(axis=1),proj@(den[:,:4].sum(axis=1)+den[:,8:].sum(axis=1)),proj@(den[:,0]*((cyl>=4)&(cyl<=7)))])

def upper_allocation(values,capacities,exposure):
    if sum(capacities)<exposure:raise ValueError("insufficient star days")
    weights=np.zeros(len(values))
    remaining=exposure
    for idx in np.argsort(-np.asarray(values)):
        weights[idx]=min(remaining,capacities[idx])
        remaining-=weights[idx]
    assert remaining==0 and abs(sum(weights)/exposure-1)<1e-12
    return weights@values/exposure

def run():
    guard()
    lenses=Lenses()
    output=[]
    for source in SOURCES:
        cases=[]
        for name,b0,b1 in BANDS:
            low=max(.5,b0-.5)
            high=min(9,b1+.5)
            coarse=bound(lenses,low,high,source,.04)
            fine=bound(lenses,low,high,source,.01)
            assert np.all(fine<=coarse*(1+5e-12))
            ratios=[]
            for lon,lat in [(0.,low),(0.,-low),(15.,high),(-7.,-high),(3.,(low+high)/2)]:
                value=direct(lenses,lon,lat,source)
                assert np.all(value<fine)
                ratios.append(value/fine)
            cases.append(fine)
            for quantity,val,old,check in zip(("spherical","bar","living_annulus"),fine,coarse,np.max(ratios,axis=0),strict=True):
                output.append(dict(source=str(source),region=name,quantity=quantity,tau_upper=val,coarse_upper=old,
                                   max_control_fraction=check,b_min=low,b_max=high))
        caps=np.r_[TOTAL-sum(COUNTS),COUNTS]*float(MAX_DAYS)
        for quantity,vals in zip(("spherical","bar","living_annulus"),np.array(cases).T,strict=True):
            upper=upper_allocation(vals,caps,EXPOSURE-0.005e9)
            assert upper<=vals[0]*(1+1e-10)
            output.append(dict(source=str(source),region="conditional_census",quantity=quantity,tau_upper=upper,
                               coarse_upper="",max_control_fraction="",b_min="",b_max=""))
    save_rows("optical-ceilings.csv",output)

if __name__=="__main__":
    run()
