from pathlib import Path
import hashlib
import json
from urllib.request import urlopen
from fetch_inputs import immutable

BASE = "https://vizier.cfa.harvard.edu/ftp/cats/II/390/"
HOME = Path(__file__).resolve().parent

if __name__ == "__main__":
    provenance = {}
    for name, cap in [("ReadMe", 50000), ("catlist.dat", 1100000), ("xtinfo.dat.gz", 72000000)]:
        path = HOME / name
        if path.is_file():
            data = path.read_bytes()
        else:
            with urlopen(BASE + name, timeout=50) as response:
                data = response.read(cap + 1)
            if not 0 < len(data) <= cap:
                raise ValueError(name)
            immutable(name, data)
        provenance[name] = dict(bytes=len(data), sha256=hashlib.sha256(data).hexdigest(), url=BASE+name)
    immutable("catalog-sources.json", (json.dumps(provenance, sort_keys=True, indent=2)+"\n").encode())
