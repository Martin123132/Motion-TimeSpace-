from collections import defaultdict
from pathlib import Path
import csv
import gzip
import sys
from read_survey import HOME,PARENT,catalog,guard,np,save_rows,sky
from pilot import NAME
from pilot_depth import moments
from kernel import Lenses,Ray,CAP

def run(order):
    guard()
    full=np.loadtxt(PARENT/"ogle3-structure.dat")
    box=catalog()[NAME][0]
    index=np.where((full[:,2]*15<=box[1])&(full[:,3]*15>=box[0])&(full[:,4]<=box[3])&(full[:,5]>=box[2]))[0]
    local=full[index]
    cells=defaultdict(list)
    rc=12+(6172-900)/1500
    with gzip.open(HOME/"pilot-stars.tsv.gz","rt") as stream:
        for row in csv.reader(stream,delimiter="\t"):
            if not row[3].strip() or not row[4].strip():continue
            ra,dec,red,blue=map(float,row[1:5])
            dm,dc=red-rc,blue-red-1.04
            inc=(abs(dm)<1 and abs(dc)<.25)
            printed,drawn=(inc and dm>-4*dc-1),(inc and dm<4*dc+1)
            if not (printed or drawn):continue
            match=moments(local,ra,dec)
            if len(match)!=1 or local[match[0],8]<=0:continue
            cells[match[0]].append((row[0].strip(),printed,drawn,*sky(ra,dec),dm-1.9*dc))
    lenses=Lenses()
    stats=np.zeros((2,2,4))
    diagnostic=[]
    for key,rows in sorted(cells.items()):
        rows.sort()
        n=len(rows)
        assert n>1
        mean,var=local[key,7:9]
        spread=np.sqrt(var*n/(n-n%2))
        rest=sorted(range(n%2,n),key=lambda idx:(int(rows[idx][1])-int(rows[idx][2]),rows[idx][0]))
        sign=np.zeros(n)
        sign[rest[:len(rest)//2]]=-1
        sign[rest[len(rest)//2:]]=1
        for polarity in [1,-1]:
            source=mean+polarity*sign*spread
            assert abs(np.mean(source)-mean)<1e-13 and abs(np.var(source)-var)<2e-14
        diagnostic.append(dict(ogle_row=int(index[key])+1,union_count=n,mu=mean,variance=var,
                               photometric_W_variance=np.var([r[-1] for r in rows]),minus=int(sum(sign<0)),pivot=int(sum(sign==0)),plus=int(sum(sign>0))))
        for idx,(_,printed,drawn,lon,lat,_) in enumerate(rows):
            planes=10**((mean+np.array([1,-1])*sign[idx]*spread-10)/5)
            ray=Ray(lon,lat)
            dist,weight=lenses.grid(ray,order,planes,max(planes))
            density,cyl=lenses.density(ray,dist)
            base=(CAP*dist*weight)[:,None]*np.column_stack([density[:,:8].sum(axis=1),density[:,:4].sum(axis=1)+density[:,8:].sum(axis=1),density[:,0]*((cyl>=4)&(cyl<=7))])
            for state,plane in enumerate(planes):
                window=np.maximum(0,1-dist/plane)
                assert abs((weight*dist)@window/(plane**2/6)-1)<3e-7
                values=np.r_[1.,window@base]
                if printed: stats[state,0]+=values
                if drawn: stats[state,1]+=values
    records=[]
    for state,title in enumerate(("far_to_printed","far_to_drawn")):
        for cut,label in enumerate(("printed","drawn")):
            values=stats[state,cut]
            records.append(dict(state=title,cut=label,n=int(values[0]),tau_spherical=values[1]/values[0],tau_bar=values[2]/values[0],
                                tau_annular_living=values[3]/values[0]))
    save_rows(f"witness-order{order}.csv",records)
    save_rows("witness-moments.csv",diagnostic)

if __name__=="__main__":
    run(int(sys.argv[1]))
