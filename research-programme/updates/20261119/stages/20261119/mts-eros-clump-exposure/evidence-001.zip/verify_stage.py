import csv
import hashlib
import io
import json
import re
from collections import Counter
from itertools import product
from pathlib import Path
from read_survey import HOME,PARENT,catalog,digest,field_counts,guard,immutable,np,sky
from pilot import QUERY, URL, urlencode
from sky_bounds import BANDS,COUNTS,MAX_DAYS,TOTAL,EXPOSURE,upper_allocation

def read(name):
    with (HOME/name).open(newline="",encoding="utf8") as stream:return list(csv.DictReader(stream))

def record(name,obj):
    immutable(name,(json.dumps(obj,indent=2,sort_keys=True,allow_nan=False)+"\n").encode())

def verify():
    guard()
    stats={}
    assert not (HOME/"__pycache__").exists()
    origin=json.loads((HOME/"catalog-sources.json").read_text())
    for name,row in origin.items():
        assert (HOME/name).stat().st_size==row["bytes"] and digest(HOME/name)==row["sha256"]
    stats["pilot_query"]=URL+urlencode(QUERY)
    fields=field_counts()
    assert len(fields)==66 and sum(fields.values())==6830000
    stats["field_labels"]=sum(fields.values())
    stats["excess_over_reported_census"]=sum(fields.values())-TOTAL
    assert stats["excess_over_reported_census"]>len(fields)*10000
    cats=catalog()
    assert len(cats)==2058 and len({key[:5] for key in cats})==66
    coords=np.array([sky(ra,dec) for limits,_ in cats.values() for ra,dec in product(limits[:2],limits[2:])])
    assert np.max(abs(coords[:,0]))<15 and np.min(abs(coords[:,1]))>.5 and np.max(abs(coords[:,1]))<9
    pattern=r"n (\d+) (\d+) m (\d+) (\d+) l (\d+) (\d+) l (\d+) (\d+) l\s+(\d+) (\d+) l\s+cp"
    polygons=np.array(re.findall(pattern,(HOME/"4893f01.eps").read_text()),int).reshape(-1,5,2)
    assert len(polygons)==65 and np.array_equal(polygons[:,0],polygons[:,-1])
    lons=10-(polygons[:,:,0]-900)*17/8000
    lats=7-(polygons[:,:,1]-900)*15/8000
    assert np.min(abs(lats))>.5 and np.max(abs(lats))<9 and np.max(abs(lons))<15 and np.all(lats.min(1)*lats.max(1)>0)
    tex=(HOME/"cg.tex").read_text()
    tab=[r.split("&",3)[:3] for r in tex.splitlines() if r.startswith("$") and "|" in r and "&" in r]
    assert [int(row[2]) for row in tab[:6]]==[TOTAL,*COUNTS.tolist()]
    stats["allocation_residual_stars"]=int(TOTAL-sum(COUNTS))
    stats["mean_days_per_selected_star"]=EXPOSURE/TOTAL
    stats["max_calendar_days"]=MAX_DAYS
    points=read("central-clump-points.csv")
    known=[row for row in points if row["has_archive_geometry"]=="True"]
    assert len(points)==1199 and len(known)==1151 and max(abs(float(row["latitude_crosscheck_deg"])) for row in known)<.022
    assert len({row["slot"] for row in known})==len(known)
    stats["figure5"]={"n":len(points),"registered":sum(bool(row["slot"]) for row in points),"with_catalog":len(known),
                      "sum_digitized":sum(float(row["clump_count_digitized"]) for row in points)}
    seasons=read("field-seasons.csv")
    assert len(seasons)==66*7*2
    for row in seasons:
        if int(row["year"])<2000:assert float(row["ccd2_proxy_days"])==0
        else:assert row["ccd2_proxy_days"]==row["admitted_proxy_days"]
    for policy in sorted({row["policy"] for row in seasons}):
        days=Counter()
        for row in seasons:
            if row["policy"]!=policy:continue
            days[row["field"],False]+=float(row["admitted_proxy_days"])
            days[row["field"],True]+=float(row["ccd2_proxy_days"])
        regular=[v for (_,is2),v in days.items() if not is2]
        sample=sum(float(row["clump_count_digitized"])*days[row["slot"][:5],row["slot"][5]=="2"] for row in points if row["slot"])
        stats[policy]={"regular_field_range_days":[min(regular),max(regular)],"figure5_registered_proxy_star_days":sample}
    cross=Counter()
    for line in tex.splitlines():
        cols=line.split("&",3)
        if len(cols)!=4:continue
        match=re.fullmatch(r"\s*(\d+)\s*-\s*(\d+)\s*-\s*(\d+)\s*-\s*(\d+)\s*",cols[0])
        if not match:continue
        field,ccd,quarter,_=map(int,match.groups())
        ra,dec=map(float,cols[1:3])
        prefix=f"cg{field:03d}{ccd}"
        found=[key for key,(bbox,_) in cats.items() if key.startswith(prefix) and bbox[0]<=ra<=bbox[1] and bbox[2]<=dec<=bbox[3]]
        cross["no_unique" if len(found)!=1 else ("agrees" if found[0][-1]=="klmn"[quarter-1] else "differs")]+=1
    assert sum(cross.values())==120
    stats["coordinate_only_ID_convention"]=dict(cross)
    cuts=read("pilot-cut-controls.csv")
    depth=read("pilot-depth-order14.csv")
    for row in depth:
        control=next(v for v in cuts if v["sample"]=="archive_"+row["photometry"] and v["rule"]==row["cut"])
        assert row["selected"]==control["nominal_count"] and int(row["used"])+int(row["missing"])==int(row["selected"])
    for prefix in ("pilot-depth","witness"):
        fine=read(prefix+"-order14.csv"); base=read(prefix+"-order8.csv")
        assert len(base)==len(fine)
        errors=[]
        for old,new in zip(base,fine,strict=True):
            for key in new:
                if key.startswith("tau_"):
                    errors.append(abs(float(new[key])/float(old[key])-1))
                else:assert new[key]==old[key]
        assert max(errors)<3e-7
        stats[prefix+"_order_relative"]=max(errors)
    rows=read("witness-order14.csv")
    for key in ("tau_spherical","tau_bar","tau_annular_living"):
        delta=[float(rows[i][key])-float(rows[i+1][key]) for i in (0,2)]
        assert delta[0]>0>delta[1]
        stats["witness_delta_"+key]=delta
    moment=read("witness-moments.csv")
    stats["matched_union"]=sum(int(row["union_count"]) for row in moment)
    ratios=[float(row["photometric_W_variance"])/float(row["variance"]) for row in moment]
    stats["variance_ratio_range"]=min(ratios),max(ratios)
    assert stats["matched_union"]==3783 and min(ratios)>3
    ceilings=read("optical-ceilings.csv")
    assert len(ceilings)==63
    for source,kind in product(("8.0","10.0","inf"),("bar","spherical","living_annulus")):
        select={r["region"]:r for r in ceilings if r["source"]==source and r["quantity"]==kind}
        assert len(select)==7
        for name,_,_ in BANDS:
            upper=float(select[name]["tau_upper"])
            assert 0<upper<=float(select[name]["coarse_upper"])*(1+5e-12)
            assert 0<float(select[name]["max_control_fraction"])<1
    assert upper_allocation([7.,3.],np.array([4.,8.]),8.)==5.
    stats["no_event_score"]=True
    record("verification.json",stats)

def seal():
    verify()
    files={path.name:digest(path) for path in sorted(HOME.iterdir()) if path.is_file() and path.name!="seal.json"}
    record("seal.json",dict(parent=digest(PARENT/"seal.json"),files=files))
    print(len(files),"sealed files;",digest(HOME/"seal.json"))

if __name__=="__main__":
    import sys
    seal() if sys.argv[1:]==["seal"] else verify()
