import csv
import hashlib
import io
import json
import re
from pathlib import Path
import os
for key in ("OPENBLAS_NUM_THREADS","OMP_NUM_THREADS","MKL_NUM_THREADS","NUMEXPR_NUM_THREADS"):
    os.environ[key] = "1"
import numpy as np
from fetch_inputs import immutable

HOME = Path(__file__).resolve().parent
PARENT = HOME.parent / "mts-compact-lens-kernel-20261119"
PIN = "d5de9d7965d0876474807a28d187513a0cfbd37c95bbda0df0390af1a95e2e89"
ROT = np.array([[-.0548755604,-.8734370902,-.4838350155],[.4941094279,-.4448296300,.7469822445],[-.8676661490,-.1980763734,.4559837762]])
SLOTS = tuple(str(chip)+quarter for chip in range(8) for quarter in "klmn")

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def guard():
    if any((root/"STOP-REQUESTED").exists() for root in (HOME,HOME.parent,PARENT)):
        raise RuntimeError("owner stop")
    assert digest(PARENT/"seal.json") == PIN
    seal = json.loads((PARENT/"seal.json").read_text())
    assert all(digest(PARENT/name)==value for name,value in seal["files"].items())

def save_rows(name, rows):
    stream = io.StringIO(newline="")
    writer = csv.DictWriter(stream, fieldnames=list(rows[0]),lineterminator="\n")
    writer.writeheader()
    writer.writerows(rows)
    immutable(name,stream.getvalue().encode())

def sky(ra,dec):
    ra,dec = np.radians([ra,dec])
    vec = ROT @ np.array([np.cos(ra)*np.cos(dec),np.sin(ra)*np.cos(dec),np.sin(dec)])
    return np.degrees(np.arctan2(vec[1],vec[0])),np.degrees(np.arcsin(vec[2]))

def field_counts():
    pairs = re.findall(r"333\.1 rot \((\d+)\)",(HOME/"4893f01.eps").read_text())
    counts = {int(field):10000*int(number) for field,number in zip(pairs[::2],pairs[1::2],strict=True)}
    assert len(counts)==65 and 121 not in counts
    counts[121] = 40000
    return counts

def catalog():
    fields=field_counts()
    result={}
    for line in (HOME/"catlist.dat").read_text().splitlines():
        if not line.startswith("cg") or int(line[2:5]) not in fields: continue
        coord=np.array([float(line[left:right]) for left,right in [(14,23),(24,33),(34,43),(44,53)]])
        key=line[:7]
        assert key not in result
        result[key]=(coord,int(line[8:13]))
    return result

def layout():
    centers=catalog()
    arr=np.array([[centers.get(f"cg{field:03d}"+slot,(np.full(4,np.nan),0))[0] for slot in SLOTS] for field in sorted(field_counts())])
    ra=(arr[:,:,0]+arr[:,:,1])/2
    dec=(arr[:,:,2]+arr[:,:,3])/2
    pos=np.stack([ra*np.cos(np.radians(np.nanmedian(dec,axis=1)[:,None])),dec],axis=-1)
    mid=np.nanmedian(pos,axis=1)[:,None,:]
    for _ in range(6):
        template=np.nanmedian(pos-mid,axis=0)
        mid=np.nanmedian(pos-template,axis=1)[:,None,:]
    full=np.where(np.isfinite(pos),pos,mid+template)
    ras=full[:,:,0]/np.cos(np.radians(np.nanmedian(dec,axis=1)[:,None]))
    locs=[(f"cg{field:03d}"+slot,*sky(ras[idx,col],full[idx,col,1]),np.isfinite(ra[idx,col])) for idx,field in enumerate(sorted(field_counts())) for col,slot in enumerate(SLOTS)]
    return locs

def points():
    raw=(HOME/"4893f05.eps").read_text()
    rows=np.array(re.findall(r"n (\d+) (\d+) 10 10 0 360 DrawEllipse",raw),dtype=int)
    return rows[rows[:,1]<8100],rows[rows[:,1]>=8100]

def get_count_rows():
    top,bottom=points()
    labels=layout()
    lat=np.array([row[2] for row in labels])
    top_b=(top[:,0]-4950)/506.25
    delta=np.abs(top_b[:,None]-lat[None,:])
    return labels,delta,top,bottom
