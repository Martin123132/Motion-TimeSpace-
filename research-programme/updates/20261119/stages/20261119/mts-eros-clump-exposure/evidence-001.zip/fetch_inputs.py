from pathlib import Path
from urllib.request import urlopen
import hashlib
import io
import tarfile

HERE = Path(__file__).resolve().parent
URL = "https://arxiv.org/src/astro-ph/0601510v2"

def immutable(name, data):
    path = HERE / name
    if path.exists():
        if path.read_bytes() != data:
            raise ValueError(f"Source changed: {name}")
    else:
        with path.open("xb") as stream:
            stream.write(data)

if __name__ == "__main__":
    with urlopen(URL, timeout=30) as response:
        raw = response.read(2_000_001)
    if len(raw) > 2_000_000:
        raise ValueError("unexpected paper size")
    if hashlib.sha256(raw).hexdigest()!="d87afd5105a5f3fa06fa2a2461c31bbd56925ad413e079cf2a2d6793f3b0439e":
        raise ValueError("unexpected paper-source version")
    with tarfile.open(fileobj=io.BytesIO(raw)) as archive:
        for member in ["cg.tex","4893f01.eps","4893f03.eps","4893f04.eps","4893f05.eps"]:
            immutable(member, archive.extractfile(member).read())
    immutable("paper-source.sha256",(hashlib.sha256(raw).hexdigest()+"  "+URL+"\n").encode())
