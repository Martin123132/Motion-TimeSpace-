from read_survey import HOME,catalog,guard,save_rows,immutable,np
import csv
import gzip
import io
import re
from urllib.parse import urlencode
from urllib.request import urlopen

URL="https://vizier.cfa.harvard.edu/viz-bin/asu-tsv?"
QUERY={"-source":"II/390/xcat","-c":"270.44336 -29.81433","-c.rm":"8.2","-out.max":"90000","-out":"EROS,RAJ2000,DEJ2000,Rmag,Bmag,RmagMed,BmagMed"}
NAME="cg6104l"

def acquire():
    with urlopen(URL+urlencode(QUERY),timeout=80) as resp:
        text=resp.read(12_000_001)
    assert len(text)<12_000_001
    rows=sorted(line for line in text.decode().splitlines() if line.startswith(NAME))
    assert len(rows)==len(set(line.split()[0] for line in rows))==catalog()[NAME][1]
    immutable("pilot-stars.tsv.gz",gzip.compress(("\n".join(rows)+"\n").encode(),mtime=0))

def selections(color,red,round_color,round_red):
    dc=color-1.04
    dm=red-(12+(6172-900)/1500)
    records=[]
    for label in ("box","printed","drawn","both","membership_differs"):
        counts=[]
        for sign in (-1,0,1):
            box=(abs(dc)<.25+sign*round_color)&(abs(dm)<1+sign*round_red)
            tol=sign*(round_red+4*round_color)
            printed=dm+4*dc+1 > -tol
            drawn=4*dc+1-dm > -tol
            if label=="membership_differs":
                if sign: counts.append(""); continue
                which=printed^drawn
            else: which={"box":True,"printed":printed,"drawn":drawn,"both":printed&drawn}[label]
            counts.append(int(np.sum(box&which)))
        records.append(dict(rule=label,inner_count=counts[0],nominal_count=counts[1],outer_count=counts[2]))
    return records

def run():
    guard()
    if not (HOME/"pilot-stars.tsv.gz").exists():acquire()
    text=gzip.decompress((HOME/"pilot-stars.tsv.gz").read_bytes()).decode()
    rows=list(csv.reader(io.StringIO(text),delimiter="\t"))
    assert len(rows)==len(set(row[0].strip() for row in rows))==catalog()[NAME][1]
    assert all(len(row)==7 and row[0].startswith(NAME) for row in rows)
    def phot(col):
        return np.array([float(row[col]) if row[col].strip() else np.nan for row in rows])
    points=np.array(re.findall(r"n (\d+) (\d+) 10 10 0 360 DrawEllipse",(HOME/"4893f03.eps").read_text()),int)
    cases=[("figure3_dots",1+(points[:,0]-4950)/5400,12+(points[:,1]-900)/1500,2/5400,2/1500)]
    for title,idx in (("archive_reference",3),("archive_median",5)):
        red,blue=phot(idx),phot(idx+1)
        usable=(red>0)&(blue>0)&(red<40)&(blue<40)
        cases.append((title,(blue-red)[usable],red[usable],.001+1/5400,.0005+1/1500))
    result=[]
    for title,color,red,dc,dm in cases:
        result.extend(dict(sample=title,usable=len(red),**record) for record in selections(color,red,dc,dm))
    save_rows("pilot-cut-controls.csv",result)

if __name__=="__main__":run()
