import csv
import gzip
import sys
from scipy.special import ndtr
from read_survey import HOME,PARENT,catalog,guard,np,save_rows,sky
from pilot import NAME
sys.path.insert(0,str(PARENT))
from kernel import Lenses,Ray,CAP,windows

def moments(data,ra,dec):
    return np.flatnonzero((data[:,2]<=ra/15)&(ra/15<data[:,3])&(data[:,4]<=dec)&(dec<data[:,5]))

def run(order):
    guard()
    archive=catalog()[NAME][0]
    tracer=np.loadtxt(PARENT/"ogle3-structure.dat")
    idx=moments(tracer,archive[:2].mean(),archive[2:].mean())
    assert len(idx)==1 and tracer[idx[0],8]>0
    pivot=tracer[idx[0],7]
    local=tracer[(tracer[:,2]*15<=archive[1])&(tracer[:,3]*15>=archive[0])&(tracer[:,4]<=archive[3])&(tracer[:,5]>=archive[2])]
    lenses=Lenses()
    stats={}
    rcenter=12+(6172-900)/1500
    unique_ids=set()
    with gzip.open(HOME/"pilot-stars.tsv.gz","rt") as stream:
        for record in csv.reader(stream,delimiter="\t"):
            name=record[0].strip()
            assert name not in unique_ids
            unique_ids.add(name)
            ra,dec=map(float,record[1:3])
            cases={}
            for cat,start in (("reference",3),("median",5)):
                red,blue=[float(v) if v.strip() else np.nan for v in record[start:start+2]]
                dc,dm=blue-red-1.04,red-rcenter
                if abs(dc)<.25 and abs(dm)<1:
                    plane=10**((pivot+dm-1.9*dc-10)/5)
                    for law,passed in (("printed",dm>-4*dc-1),("drawn",dm<4*dc+1)):
                        if passed:cases[cat,law]=plane
            if not cases:continue
            ray=Ray(*sky(ra,dec))
            idx=moments(local,ra,dec)
            found=len(idx)==1 and local[idx[0],8]>0
            params=None
            if found:
                row=local[idx[0]]
                params=((row[7]-10)*np.log(10)/5,np.sqrt(row[8])*np.log(10)/5)
            dist,wgt=lenses.grid(ray,order,list(cases.values()),52.)
            den,cyl=lenses.density(ray,dist)
            assert np.isfinite(den).all() and den.min()>=-1e-6
            base=CAP*(wgt*dist)[:,None]*np.column_stack((den[:,:8].sum(axis=1),den[:,:4].sum(axis=1)+den[:,8:].sum(axis=1),
                                                         den[:,0]*((cyl>=4)&(cyl<=7))))
            if found:
                assert ndtr((params[0]-np.log(52))/params[1])<1e-12
                rc=windows(dist,{},params)["rc_gaussian"]@base
            for (cat,law),plane in cases.items():
                win=np.maximum(0,1-dist/plane)
                assert abs((wgt*dist)@win/(plane**2/6)-1)<3e-7
                candle=win@base
                for label,values in [("fixed_intrinsic_W",candle),("same_RC_moments",rc if found else None)]:
                    summary=stats.setdefault((cat,law,label),np.zeros(6))
                    summary[0]+=1
                    if values is not None:
                        summary[1:4]+=values
                        summary[4]+=1
                        if label=="fixed_intrinsic_W": summary[5]+=plane
    assert len(unique_ids)==catalog()[NAME][1]
    result=[]
    for (cat,law,label),stat in stats.items():
        total,spherical,bar,ann,used,sourcesum=stat
        result.append(dict(photometry=cat,cut=law,distance_law=label,selected=int(total),used=int(used),
                           missing=int(total-used),tau_spherical=spherical/used,tau_bar=bar/used,
                           tau_annular_living=ann/used,assumed_mean_kpc=sourcesum/used if sourcesum else ""))
    save_rows(f"pilot-depth-order{order}.csv",result)

if __name__=="__main__":
    run(int(sys.argv[1]))
