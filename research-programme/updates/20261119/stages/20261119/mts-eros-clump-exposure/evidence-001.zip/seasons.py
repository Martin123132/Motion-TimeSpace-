import gzip
from collections import defaultdict
from read_survey import HOME,field_counts,guard,save_rows

def histories():
    fields=set(field_counts())
    byimage=defaultdict(dict)
    with gzip.open(HOME/"xtinfo.dat.gz","rt",encoding="ascii") as stream:
        for line in stream:
            if not line.startswith("cg"): continue
            name=line[:22].strip()
            if int(name[2:5]) not in fields: continue
            assert name[7:10] in ("trr","tbr") and name[5] == ("0" if name[7:10]=="trr" else "1")
            date=line[98:].strip()[-10:]
            if not "1996-07-01" <= date <= "2002-10-31": continue
            camera,chip=map(int,name[5:7])
            key=(name[:5],name[10:-5])
            mjd=float(line[23:34])
            if mjd<=0: continue
            if (camera,chip) in byimage[key]:
                if byimage[key][camera,chip]!=(mjd,date): raise ValueError(name)
            byimage[key][camera,chip]=mjd,date
    visits=defaultdict(list)
    for (field,token),images in byimage.items():
        chips=[chip for chip in range(8) if (0,chip) in images and (1,chip) in images]
        if not chips: continue
        times=[images[0,chip][0] for chip in chips]
        dates=[images[0,chip][1] for chip in chips]
        assert len(set(dates))==1 and max(times)-min(times)<.01
        day=dates[0]
        visits[field,int(day[:4])].append((min(times),day,len(chips)))
    rows=[]
    for field in sorted(fields):
        for year in range(1996,2003):
            for policy in ("paired_visits","six_chips_nights"):
                sample=sorted((mjd,date) for mjd,date,nchip in visits[f"cg{field:03d}",year]
                              if 2<=int(date[5:7])<=10 and (policy=="paired_visits" or nchip>=6))
                span=sample[-1][0]-sample[0][0] if sample else 0.
                number=len(sample) if policy=="paired_visits" else len({date for _,date in sample})
                passing=number>=2 and span/(number-1)<8.5
                rows.append(dict(field=f"cg{field:03d}",year=year,policy=policy,
                                 visits=len(sample),nights=len({date for _,date in sample}),first_date=sample[0][1] if sample else "",
                                 last_date=sample[-1][1] if sample else "",raw_days=span,
                                 admitted_proxy_days=span if passing else 0.,ccd2_proxy_days=span if passing and year>=2000 else 0.))
    return rows

if __name__=="__main__":
    guard()
    save_rows("field-seasons.csv",histories())
