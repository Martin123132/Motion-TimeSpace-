from read_survey import HOME,SLOTS,catalog,field_counts,get_count_rows,guard,np,save_rows

def feasible(allowed):
    length = allowed.shape[1]
    prefix = np.zeros_like(allowed)
    possible = np.ones(length,dtype=bool)
    for index,row in enumerate(allowed):
        prefix[index] = row & possible
        possible = np.r_[False,np.maximum.accumulate(prefix[index,:-1])]
        if not np.any(prefix[index]):
            raise ValueError(("no monotone alignment",index))
    suffix = np.zeros_like(allowed)
    possible = np.ones(length,dtype=bool)
    for index in reversed(range(len(allowed))):
        suffix[index] = allowed[index] & possible
        possible = np.r_[np.maximum.accumulate(suffix[index,:0:-1])[::-1],False]
    return prefix & suffix

def register(tol):
    labels,delta,top,bottom=get_count_rows()
    top_ok=feasible(delta<tol)
    lon,lat=np.array([[r[1],r[2]] for r in labels]).T
    raw=(bottom[:,0]-4950)/506.25
    options=(abs(raw[:,None]-lat)<tol)&(abs(lon)<3+tol)
    unique=np.flatnonzero(top_ok.sum(axis=1)==1)
    locked=np.full(len(labels),-100)
    locked[top_ok[unique].argmax(axis=1)]=top[unique,0]
    options &= (locked<0)|(abs(bottom[:,0:1]-locked)<=2)
    return labels,top,bottom,top_ok,feasible(options)

def registrations():
    labels,_,bottom,_,wide=register(.5)
    _,_,_,_,narrow=register(.21)
    assert np.all(~narrow|wide)
    records=[]
    for number,(point,allowed) in enumerate(zip(bottom,wide,strict=True)):
        slots=np.flatnonzero(allowed)
        unique=len(slots)==1
        key,lon,lat,observed=labels[slots[0]]
        rawlat=(point[0]-4950)/506.25
        count=(14100-point[1])/0.6
        records.append(dict(point=number+1,plot_lat=rawlat,clump_count_digitized=count,
                            possible_slots=len(slots),slot=key if unique else "",has_archive_geometry=bool(unique and observed),
                            lon=lon if unique and observed else "",lat=lat if unique and observed else "",
                            latitude_crosscheck_deg=lat-rawlat if unique and observed else ""))
    return records

if __name__=="__main__":
    guard()
    records=registrations()
    save_rows("central-clump-points.csv",records)
