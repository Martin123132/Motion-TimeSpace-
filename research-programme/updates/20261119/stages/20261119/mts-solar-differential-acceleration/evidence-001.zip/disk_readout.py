from disk_state import DiskState, np, HOME, families, foreground
from potential import spherical_jn, root_values, CONVERSION, SUN, LIGHT, KPC_KM
from sightline_forecast import targets, geometry
from geometry import write_rows
from scipy.special import eval_jacobi, eval_legendre
import sys


def vacuum_force(system,coef,points):
    reduced=np.einsum("lrk,lk->rl",system.radial,coef,optimize=True)@system.angle.T
    multipoles=reduced**2@(system.aw[:,None]*system.extra)
    scaled=points/system.length
    radii=np.linalg.norm(scaled,axis=1)
    unit=scaled/radii[:,None]
    cosine=unit[:,2]
    tangent=np.array([0.,0.,1.])-cosine[:,None]*unit
    force=np.zeros_like(scaled)
    for index,mode in enumerate(system.full):
        roots=root_values(mode-1,2*system.count+12)
        freq=roots/system.edge
        if mode:
            normal=(.5*system.edge**3*(spherical_jn(mode,roots)**2-spherical_jn(mode-1,roots)*spherical_jn(mode+1,roots)))**-.5
        else:
            normal=roots/np.sqrt(.5*system.edge**3*(1-np.sin(2*roots)/(2*roots)))
        weights=normal*(system.proj[index]@multipoles[:,index])
        argument=radii[:,None]*freq
        potential=spherical_jn(mode,argument)@weights
        radial=spherical_jn(mode,argument,derivative=True)@(weights*freq)
        value=eval_legendre(mode,cosine)
        derivative=.5*(mode+1)*eval_jacobi(mode-1,1,1,cosine) if mode else 0
        force-=np.sqrt(2*mode+1)*(unit*(value*radial)[:,None]+tangent*(derivative*potential/radii)[:,None])
    return force*system.vel**2/system.length


def run(tag):
    rows=geometry()
    names=[row["NAME"] for row in rows]
    directions=targets(rows)
    scale=np.linspace(-1.,1.,17)
    distances=np.array([float(row["DIST"]) for row in rows])[:,None]+scale*np.array([float(row["DIST_ERR"]) for row in rows])[:,None]
    site=np.vstack((SUN,(SUN+directions[:,None,:]*distances[:,:,None]).reshape(-1,3)))
    anchors=np.vstack((np.array([[-8.,0.,0.],[-17.58,0.,0.]]),SUN,SUN+distances[:,8,None]*directions))
    with np.load(HOME/(tag+".npz")) as pkt:
        system=DiskState(str(pkt["label"]),int(pkt["count"]),int(pkt["order"]),float(pkt["edge"]),float(pkt["load"]))
        coef=pkt["coef"]
    field=vacuum_force(system,coef,site)
    direct=system.force(coef,anchors)
    other=vacuum_force(system,coef,anchors)
    controls=[]
    for name,expected,actual in zip(["8 kpc","17.58 kpc","Sun"]+names,direct,other):
        controls.append(dict(point=name,absolute_kms2_kpc=np.linalg.norm(actual-expected),relative=np.linalg.norm(actual-expected)/np.linalg.norm(expected)))
    for idx,name in enumerate(names):
        target=direct[3+idx]-direct[2]
        error=(other[3+idx]-other[2])-target
        controls.append(dict(point=name+" relative",absolute_kms2_kpc=np.linalg.norm(error),relative=np.linalg.norm(error)/np.linalg.norm(target)))
    disk,bulge,halo=foreground(site)
    dist=np.linalg.norm(site,axis=1)
    cloud=-system.material(dist/system.length)[0][:,None]*site/dist[:,None]*system.vel**2/system.length
    project=lambda arr: np.einsum("nmi,ni->nm",(arr[1:]-arr[0]).reshape(len(names),len(scale),3),directions)*CONVERSION
    wave=project(field)
    baryon=project(disk+bulge+cloud)
    smooth=project(halo)+baryon
    total=wave+baryon
    out=[]
    for idx,name in enumerate(names):
        for step,offset in enumerate(scale):
            out.append(dict(source=name,distance_sigma=offset,distance_kpc=distances[idx,step],wave=wave[idx,step],
                            common_ordinary=baryon[idx,step],total_mts=total[idx,step],smooth_reference=smooth[idx,step],
                            fractional_period_rate_s=total[idx,step]/(CONVERSION*KPC_KM*LIGHT)))
    write_rows(tag+"-timing.csv",out)
    write_rows(tag+"-readout-check.csv",controls)
    print(tag,"max relative readout",max(row["relative"] for row in controls),flush=True)


if __name__=="__main__":
    for tag in sys.argv[1:]:
        run(tag)
