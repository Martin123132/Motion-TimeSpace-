from sightline_forecast import geometry,targets
from potential import Wave, np, CONVERSION, SUN
from summarize import rows
from geometry import write_rows


def run(tag):
    field=Wave(tag)
    catalogue=geometry()
    directions=targets(catalogue)
    nominal=np.array([float(row["DIST"]) for row in catalogue])
    points=np.vstack((SUN,SUN+nominal[:,None]*directions))
    result=field.induced(np.vstack((points,points+field.cloud_center)),spacing=None)
    direct={(row["frame"],row["source"]):row for row in rows("newton-"+tag+".csv") if row["channel"]=="induced"}
    checks=[]
    for frame,values in (("host",result[:len(points)]),("ordinary",result[len(points):])):
        projected=np.sum((values[1:]-values[0])*directions,axis=1)*CONVERSION
        for row,actual in zip(catalogue,projected):
            reference=direct[frame,row["NAME"]]
            truth=float(reference["newton_mm_s_yr"])
            checks.append(dict(source=row["NAME"],frame=frame,independent=truth,exact_spectral=actual,
                               interpolated_relative_error=reference["projected_relative"],exact_relative_error=abs(actual/truth-1),
                               exact_absolute_mm_s_yr=abs(actual-truth)))
    write_rows("exact-sightline-"+tag+".csv",checks)
    print(tag,max(row["exact_relative_error"] for row in checks))


if __name__=="__main__":
    run("angular24-cap")
    run("angular28-diff")
