from sightline_forecast import geometry, targets
from potential import Wave, np, SUN, CONVERSION, sl, basis, roots_legendre
from geometry import write_rows
from field_checks import wave_at
from grid_wave import harmonics
import sys


def radial_source(field, query, order=9):
    grid=field.grid
    cuts=np.unique(np.r_[np.linspace(0,grid.edge,1+int(np.ceil(grid.edge/.45))),query])
    nodes,weights=roots_legendre(order)
    spans=np.diff(cuts)[:,None]/2
    radius=(cuts[:-1,None]+spans*(nodes+1)).ravel()
    measure=(spans*weights).ravel()
    multipoles=[];monopoles=[]
    for start in range(0,len(radius),32):
        sub=radius[start:start+32]
        radial=wave_at(grid,field.packet["raw"],sub)
        bare=basis(0,grid.wroots[0],grid.edge,sub)@grid.coef
        radial[:,0]-=bare
        real=grid.synth(radial.real,grid.lmax)
        imag=grid.synth(radial.imag,grid.lmax)
        multipoles.append(grid.analyze(real**2+imag**2+2*bare[:,None]*real,2*grid.lmax))
        monopoles.extend(bare**2)
    return radius,measure,np.vstack(multipoles),np.array(monopoles)


def force(field,points):
    query=points/field.length
    dist=np.linalg.norm(query,axis=1)
    sky=query/dist[:,None]
    rad,weights,source,ground=radial_source(field,np.unique(dist))
    low=rad[None,:]<dist[:,None]
    ratio=np.minimum(rad[None,:],dist[:,None])/np.maximum(rad[None,:],dist[:,None])
    inner=low*(weights*rad**2)/dist[:,None]
    outer=(~low)*(weights*rad)
    max_order=2*field.grid.lmax
    base=harmonics(sky,max_order)
    delta=2e-5
    change=[]
    for axis in np.eye(3):
        def angular(displacement):
            direction=sky+displacement*axis
            return harmonics(direction/np.linalg.norm(direction,axis=1)[:,None],max_order)
        change.append((angular(-2*delta)-8*angular(-delta)+8*angular(delta)-angular(2*delta))/(12*delta))
    tangent=np.stack(change,axis=-1)
    result=np.zeros_like(query)
    weight=np.ones_like(ratio)
    for mode in range(max_order+1):
        span=sl(mode)
        inside=(weight*inner)@source[:,span]
        outside=(weight*outer)@source[:,span]
        potential=-(inside+outside)/(2*mode+1)
        slope=((mode+1)*inside-mode*outside)/((2*mode+1)*dist[:,None])
        result-=np.sum(base[:,span]*slope,axis=1)[:,None]*sky
        result-=np.einsum("nm,nmk->nk",potential,tangent[:,span])/dist[:,None]
        weight*=ratio
    equilibrium=-(inner@ground)[:,None]*sky/dist[:,None]
    return result*field.scale,equilibrium*field.scale


def check(tag):
    field=Wave(tag)
    rows=geometry()
    dirs=targets(rows)
    points=np.vstack((SUN,SUN+np.array([float(row["DIST"]) for row in rows])[:,None]*dirs))
    stacks=np.vstack((points,points+field.cloud_center))
    actual,base=force(field,stacks)
    target=field.induced(stacks)
    original=field.equilibrium(stacks)
    report=[]
    for label,keep in (("host",slice(0,len(points))),("ordinary",slice(len(points),None))):
        for name,first,second in (("induced",actual[keep],target[keep]),("equilibrium",base[keep],original[keep])):
            diff=first[1:]-first[0]
            residual=diff-(second[1:]-second[0])
            for idx,row in enumerate(rows):
                readout=dirs[idx]@diff[idx]
                error=dirs[idx]@residual[idx]
                report.append(dict(frame=label,channel=name,source=row["NAME"],newton_mm_s_yr=readout*CONVERSION,
                                   vector_relative=np.linalg.norm(residual[idx])/np.linalg.norm(diff[idx]),
                                   projected_relative=abs(error)/max(abs(readout),1e-300),absolute_mm_s_yr=abs(error)*CONVERSION))
    write_rows("newton-"+tag+".csv",report)
    print(tag,"independent force",max(row["vector_relative"] for row in report),flush=True)


if __name__=="__main__":
    for tag in sys.argv[1:]:
        check(tag)
