from summarize import rows, nominal
from potential import np, HOME, PARENT, guard, sha, SEAL, foreground, SUN, CONVERSION, LIGHT, KPC_KM, harmonics_and_tangent
from geometry import COMMIT, BLOB
from grid_wave import harmonics
import json
import sys

TOL=2e-5


def inspect():
    guard("angular24-cap")
    guard("angular28-diff")
    parent=json.loads((PARENT/"seal.json").read_bytes())
    assert all(sha(PARENT/name)==expected for name,expected in parent["files"].items())
    assert not (HOME/"__pycache__").exists()
    for path in HOME.glob("*.py"):
        compile(path.read_bytes(),str(path),"exec")
    geo=rows("geometry.csv")
    receipt=json.loads((HOME/"acquisition.json").read_bytes())
    assert receipt["commit"]==COMMIT and receipt["blob"]==BLOB and receipt["bytes"]==4482
    assert receipt["rows"]==len(geo)==26 and list(geo[0])==receipt["retained_columns"]==["NAME","GL","GB","DIST","DIST_ERR"]
    assert not receipt["parsed_timing_values"] and receipt["protocol_sha256"]==sha(HOME/"PROTOCOL.md")
    assert all(float(row["DIST"])-float(row["DIST_ERR"])>0 for row in geo)
    directions=np.array([[1.,0.,0.],[0.,0.,-1.],[-.2,.4,.7],[.81,.4,-.31]])
    directions/=np.linalg.norm(directions,axis=1)[:,None]
    generated=list(harmonics_and_tangent(directions,16))
    sky=np.column_stack([pair[0] for pair in generated])
    assert np.max(abs(sky-harmonics(directions,16)))<1e-12
    gradient=np.concatenate([pair[1] for pair in generated],axis=1)
    assert np.max(abs(np.einsum("nmi,ni->nm",gradient,directions)))<1e-12
    force=foreground(np.array([[-8.,0.,0.]]))
    assert np.allclose([8*piece[0,0]/220**2 for piece in force],[.6,.05,.35],atol=2e-14,rtol=0)
    tide=np.array([[.13,-.61,.9],[-.61,.23,.07],[.9,.07,-.12]])
    common=np.array([.52,-.1,.03])
    for distance in (0.,1.,3.):
        origin=tide@SUN+common
        remote=(SUN+distance*directions)@tide.T+common
        assert np.allclose(np.sum((remote-origin)*directions,axis=1),distance*np.einsum("ni,ij,nj->n",directions,tide,directions),atol=4e-15,rtol=0)
    labels={row["NAME"] for row in geo}
    closure=0.
    for tag in ("angular24-cap","angular28-diff","angular16-cap","angular16-diff","outer16-cap","outer16-diff","exact-angular24-cap","exact-angular28-diff"):
        table=rows("sightlines-"+tag+".csv")
        assert len(table)==26*17*2
        assert len({(row["frame"],row["source"],row["distance_sigma"]) for row in table})==len(table)
        for row in table:
            assert row["source"] in labels
            values={key:float(value) for key,value in row.items() if key not in ("source","state","frame")}
            assert all(np.isfinite(val) for val in values.values())
            for left,right in (("forced_wave",("translation","shape")),("live_wave",("forced_wave","equilibrium")),
                               ("common",("disk","bulge","cloud","satellite")),("total_mts",("common","live_wave")),
                               ("smooth_reference",("common","nfw")),("static_wave_reference",("common","equilibrium"))):
                closure=max(closure,abs(values[left]-sum(values[key] for key in right)))
            assert abs(values["total_mts"]-values["fractional_period_rate_s"]*CONVERSION*KPC_KM*LIGHT)<1e-12
        if not tag.startswith("exact-"):
            assert max(float(row["relative_field_difference"]) for row in rows("radial-check-"+tag+".csv"))<TOL
    assert closure<1e-12
    shell_reference=rows_from_parent("sky-components.csv")
    max_green=0.;max_shell=0.;finite_misses=0
    for label,tag in (("cap","angular24-cap"),("diff","angular28-diff")):
        for row in rows("shell-"+tag+".csv"):
            expected=next(item for item in shell_reference if item["packet"]==tag and item["radius_kpc"]=="8.1")
            target=np.array([float(expected[row["channel"]+"_"+axis]) for axis in "xyz"])
            value=np.array([float(row[axis]) for axis in "xyz"])
            max_shell=max(max_shell,np.linalg.norm(value-target)/np.linalg.norm(target))
        checks=rows("newton-"+tag+".csv")
        assert len(checks)==104
        max_green=max(max_green,max(float(row["vector_relative"]) for row in checks))
        finite_misses+=sum(float(row["projected_relative"])>TOL for row in checks)
        refined=rows("exact-sightline-"+tag+".csv")
        assert len(refined)==52 and max(float(row["exact_relative_error"]) for row in refined)<TOL
        finished=nominal("exact-"+tag)
        for row in refined:
            if row["frame"]=="host":
                saved=float(finished["host",row["source"]]["forced_wave"])
                assert abs(saved-float(row["independent"]))<TOL*abs(float(row["independent"]))
        with np.load(HOME/("disk20-"+label+".npz")) as first,np.load(HOME/("disk20-twin-"+label+".npz")) as twin:
            assert np.linalg.norm(first["coef"]-twin["coef"])<TOL*np.linalg.norm(first["coef"])
        base=rows("static-budget-"+tag+".csv")[-1]
        unloaded=rows("disk0-"+label+"-force.csv")[-1]
        assert abs(float(base["wave_circular_kms"])/float(unloaded["wave_kms"])-1)<TOL
        states=[]
        for prefix in ("disk20-","diskbox-"):
            with np.load(HOME/(prefix+label+".npz")) as pkt:
                assert abs(np.sum(pkt["coef"]**2)/pkt["mass"]-1)<1e-13
                assert float(pkt["projected_residual"])<1e-6 and abs(float(pkt["virial"]))<TOL
            states.append(rows(prefix+label+"-timing.csv"))
            assert len(states[-1])==442
            assert max(float(row["relative"]) for row in rows(prefix+label+"-readout-check.csv"))<TOL
        for left,right in zip(*states):
            assert left["source"]==right["source"] and left["distance_sigma"]==right["distance_sigma"]
            for row in (left,right):
                assert abs(float(row["total_mts"])-float(row["wave"])-float(row["common_ordinary"]))<1e-12
        wave1,wave2=[np.array([float(row["wave"]) for row in state]) for state in states]
        assert np.linalg.norm(wave2-wave1)<TOL*np.linalg.norm(wave1)
        for row in rows("disk20-"+label+"-tangents.csv"):
            assert abs(float(row["norm_response"])-(1 if row["parameter"]=="mass" else 0))<1e-12
            assert float(row["tangent_residual"])<1e-9
        extra=[row for row in rows("disk20-"+label+"-tangent-tests.csv") if row["step"]=="extrapolated"]
        assert len(extra)==8 and max(float(row["relative_error"]) for row in extra)<TOL
    assert max_green<TOL and max_shell<TOL
    files={path.name:sha(path) for path in HOME.iterdir() if path.is_file() and path.name!="seal.json"}
    for name in ("RESULTS.md","DERIVATION.md","REPLAY.md","NEXT.md","PROTOCOL.md","FRAME-CONTROL.md","DISK-PROTOCOL.md","RESPONSE-PROTOCOL.md"):
        assert name in files
    sheets={name:len(rows(name)) for name in files if name.endswith(".csv")}
    return dict(parent=SEAL,geometry_commit=COMMIT,protocol=sha(HOME/"PROTOCOL.md"),files=files,csv_rows=sheets,
                max_green_vector_error=max_green,max_shell_vector_error=max_shell,max_channel_closure_mm_s_yr=closure,
                newton_projected_comparisons_outside_20ppm=finite_misses,
                resolution_comparisons_outside_20ppm=sum(row["within_20ppm"]=="False" for row in rows("field-resolution.csv")),
                scope="geometry-only finite forecasts and separate axisymmetric stationary response; no timing outcomes")


def rows_from_parent(name):
    import csv
    with (PARENT/name).open(encoding="utf8") as src:
        return list(csv.DictReader(src))


if __name__=="__main__":
    result=inspect()
    dest=HOME/"seal.json"
    if sys.argv[1:]==["seal"]:
        with dest.open("x",encoding="utf8") as handle:
            json.dump(result,handle,indent=2,sort_keys=True)
            handle.write("\n")
    if sys.argv[1:]!=["check"]:
        assert json.loads(dest.read_bytes())==result
    print({key:val for key,val in result.items() if key not in ("files","csv_rows")}, len(result["files"]),sum(result["csv_rows"].values()))
    if dest.exists():
        print("seal",sha(dest))
