from potential import Wave, np, SUN, MASS, RADIUS, LIGHT, KPC_KM, CONVERSION, foreground, sky_rule, HOME
from geometry import write_rows
import csv
import sys


def geometry():
    with (HOME/"geometry.csv").open(encoding="utf8") as src:
        return list(csv.DictReader(src))


def targets(rows):
    lon,lat=np.deg2rad([[float(row[key]) for row in rows] for key in ("GL","GB")])
    return np.column_stack((np.cos(lon)*np.cos(lat),np.sin(lon)*np.cos(lat),np.sin(lat)))


def forecast(field,tag,exact=False):
    rows=geometry()
    dirs=targets(rows)
    nominal=np.array([float(row["DIST"]) for row in rows])
    error=np.array([float(row["DIST_ERR"]) for row in rows])
    sigma=np.linspace(-1.,1.,17)
    distances=nominal[:,None]+error[:,None]*sigma
    assert min(distances.ravel())>0
    points=np.vstack((SUN,(SUN+dirs[:,None,:]*distances[:,:,None]).reshape(-1,3)))
    wave=field.accelerations(np.vstack((points,points+field.cloud_center)),spacing=None if exact else .0125)
    samples=[];summary=[]
    for frame,keep in (("host",slice(0,len(points))),("ordinary",slice(len(points),None))):
        fields={key:value[keep].copy() for key,value in wave.items()}
        fields["disk"],fields["bulge"],fields["nfw"]=foreground(points)
        equilibrium=wave["equilibrium"][:len(points)]
        rigid=fields["equilibrium"]+fields["translation"]
        fields["equilibrium"]=equilibrium
        fields["translation"]=rigid-equilibrium
        fields["forced_wave"]=fields["live_wave"]-equilibrium
        fields["shape"]=fields["live_wave"]-rigid
        vectors={key:np.einsum("nsi,ni->ns",(values[1:]-values[0]).reshape(len(rows),len(sigma),3),dirs)*CONVERSION for key,values in fields.items()}
        common=vectors["disk"]+vectors["bulge"]+vectors["cloud"]+vectors["satellite"]
        vectors.update(common=common,total_mts=common+vectors["live_wave"],smooth_reference=common+vectors["nfw"],
                       static_wave_reference=common+vectors["equilibrium"],no_halo=common)
        for idx,row in enumerate(rows):
            for step,offset in enumerate(sigma):
                values={key:arr[idx,step] for key,arr in vectors.items()}
                samples.append(dict(state=tag,frame=frame,source=row["NAME"],distance_sigma=offset,distance_kpc=distances[idx,step],**values,
                                    fractional_period_rate_s=values["total_mts"]/(CONVERSION*KPC_KM*LIGHT)))
            for channel in ("forced_wave","translation","shape","satellite","live_wave","total_mts","smooth_reference"):
                series=vectors[channel][idx]
                summary.append(dict(state=tag,frame=frame,source=row["NAME"],channel=channel,nominal=series[8],
                                    lower_d=series[0],upper_d=series[-1],sample_min=min(series),sample_max=max(series),
                                    monotone=bool(np.all(np.diff(series)>=0) or np.all(np.diff(series)<=0))))
    filetag=("exact-" if exact else "")+tag
    write_rows("sightlines-"+filetag+".csv",samples)
    write_rows("distance-sensitivity-"+filetag+".csv",summary)
    return rows,dirs,nominal


def shell(field,tag):
    sky,weights=sky_rule(32)
    points=field.cloud_center+8.1*sky
    wave=field.induced(points)+field.equilibrium(points)
    observer=field.packet["wave_acc"][-1,0]*field.scale
    delta=field.donor-points
    dist=np.linalg.norm(delta,axis=1)
    sat=field.gcode*MASS*delta/(dist*(dist+RADIUS)**2)[:,None]
    origin_dist=np.linalg.norm(field.donor)
    sat_observer=field.packet["sat_acc"][-1,0]*field.scale+field.gcode*MASS*field.donor/(origin_dist*(origin_dist+RADIUS)**2)
    project=lambda array: 3*(weights*np.sum(array*sky,axis=1))@sky
    return project(wave-observer),project(sat-sat_observer)


def run(tag):
    field=Wave(tag)
    rows,dirs,nominal=forecast(field,tag)
    points=np.vstack((SUN,SUN+dirs*nominal[:,None]))
    sampled=field.induced(points)
    direct=field.induced(points,spacing=None)
    diffs=(sampled[1:]-sampled[0])-(direct[1:]-direct[0])
    ref=direct[1:]-direct[0]
    checks=[dict(source=row["NAME"],relative_field_difference=np.linalg.norm(delta)/np.linalg.norm(raw),
                 los_abs_mm_s_yr=abs(delta@direction)*CONVERSION) for row,delta,raw,direction in zip(rows,diffs,ref,dirs)]
    write_rows("radial-check-"+tag+".csv",checks)
    if tag in ("angular24-cap","angular28-diff"):
        wave,sat=shell(field,tag)
        write_rows("shell-"+tag+".csv",[dict(channel=name,x=vec[0],y=vec[1],z=vec[2]) for name,vec in (("wave",wave),("satellite",sat),("total",wave+sat))])
    disk,bulge,halo=foreground(np.array([[-8.,0.,0.],[-17.58,0.,0.]]))
    masses=[]
    for idx,rad in enumerate((8.,17.58)):
        background=field.equilibrium(np.array([[-rad,0.,0.]]))[0,0]
        baryon=disk[idx,0]+bulge[idx,0]
        masses.append(dict(radius_kpc=rad,wave_circular_kms=np.sqrt(rad*background),foreground_kms=np.sqrt(rad*baryon),
                           wave_plus_foreground_kms=np.sqrt(rad*(baryon+background)),smooth_total_kms=np.sqrt(rad*(baryon+halo[idx,0]))))
    write_rows("static-budget-"+tag+".csv",masses)
    print(tag,len(rows),"sightlines, peak radial comparison",max(row["relative_field_difference"] for row in checks),flush=True)


if __name__=="__main__":
    if sys.argv[1:2]==["exact"]:
        for tag in sys.argv[2:]:
            forecast(Wave(tag),tag,True)
        sys.exit()
    for tag in sys.argv[1:]:
        run(tag)
