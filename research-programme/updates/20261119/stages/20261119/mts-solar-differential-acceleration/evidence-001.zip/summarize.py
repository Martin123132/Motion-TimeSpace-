from potential import np, HOME
from geometry import write_rows
import csv


def rows(name):
    with (HOME/name).open(encoding="utf8",newline="") as src:
        values=list(csv.DictReader(src))
    assert values and all(None not in row and None not in row.values() for row in values),name
    return values


def nominal(tag):
    return {(row["frame"],row["source"]):row for row in rows("sightlines-"+tag+".csv") if float(row["distance_sigma"])==0}


def compare():
    shifts=[];summaries=[];gates=[];stat=[]
    for label,tag in (("cap","angular24-cap"),("diff","angular28-diff")):
        selected=nominal(tag)
        coarse=nominal("angular16-"+label)
        larger=nominal("outer16-"+label)
        channels=("forced_wave","shape","translation","satellite","total_mts","smooth_reference")
        for frame in ("host","ordinary"):
            for channel in channels:
                items=[(key[1],float(row[channel])) for key,row in selected.items() if key[0]==frame]
                top=max(items,key=lambda pair:abs(pair[1]))
                distances=[row for row in rows("distance-sensitivity-"+tag+".csv") if row["frame"]==frame and row["channel"]==channel]
                envelope=[float(row["sample_max"])-float(row["sample_min"]) for row in distances]
                summaries.append(dict(state=label,frame=frame,channel=channel,median_abs=np.median([abs(val) for _,val in items]),
                                      max_abs=abs(top[1]),extreme_name=top[0],signed_extreme=top[1],
                                      median_distance_span=np.median(envelope) if envelope else "",
                                      nonmonotone=sum(row["monotone"]=="False" for row in distances) if distances else ""))
        for key,current in selected.items():
            if key[0]=="host":
                other=selected[("ordinary",key[1])]
                shifts.append(dict(state=label,source=key[1],host_forced=float(current["forced_wave"]),ordinary_forced=float(other["forced_wave"]),
                                   change=float(other["forced_wave"])-float(current["forced_wave"])))
        for kind,first,second in (("higher-angular",coarse,selected),("domain-and-step",coarse,larger)):
            for channel in channels:
                keys=list(first)
                before=np.array([float(first[key][channel]) for key in keys])
                after=np.array([float(second[key][channel]) for key in keys])
                norm=np.linalg.norm(after-before)/np.linalg.norm(after)
                gates.append(dict(state=label,change=kind,channel=channel,relative_sample_norm=norm,max_abs_mm_s_yr=max(abs(after-before)),within_20ppm=norm<2e-5))
        for tier in ("disk0","disk8","disk12","disk16","disk20","diskbox"):
            prefix=tier+"-"+label
            with np.load(HOME/(prefix+".npz")) as data:
                curve=rows(prefix+"-force.csv")
                stat.append(dict(state=label,pack=prefix,total8=curve[0]["composite_kms"],total17=curve[-1]["composite_kms"],
                                 wave17=curve[-1]["wave_kms"],q=float(data["second_axis_ratio"]),rms_kpc=float(data["rms_kpc"]),
                                 virial=float(data["virial"]),projected_residual=float(data["projected_residual"]),
                                 negative_mass_fraction=float(data["negative_amplitude_fraction"])))
    write_rows("field-resolution.csv",gates)
    write_rows("frame-sensitivity.csv",shifts)
    write_rows("sightline-summary.csv",summaries)
    write_rows("stationary-summary.csv",stat)


if __name__=="__main__":
    compare()
