from pathlib import Path
import csv
import hashlib
import io
import json
import math
import urllib.request

HOME = Path(__file__).resolve().parent
COMMIT = "6cb4e31f6b2e732f5973b024634507c2e4f59988"
BLOB = "db71bfb53b9ef4981bf01bef4dae5307cf083af3"
URL = f"https://raw.githubusercontent.com/thomasdonlon/Empirical_Model_MSP_Spindown_Accels/{COMMIT}/v3/binary_only.csv"


def retain(name, value):
    path = HOME / name
    content = value.encode()
    if path.exists():
        assert path.read_bytes() == content, name
    else:
        with path.open("xb") as stream:
            stream.write(content)


def write_rows(name, rows):
    stream = io.StringIO(newline="")
    table = csv.DictWriter(stream,fieldnames=tuple(rows[0]),lineterminator="\n")
    table.writeheader()
    table.writerows(rows)
    retain(name,stream.getvalue())


def extract():
    with urllib.request.urlopen(URL,timeout=25) as response:
        raw = response.read(65536)
    assert len(raw)==4482 and hashlib.sha1(b"blob 4482\0"+raw).hexdigest()==BLOB
    reader=csv.DictReader(io.StringIO(raw.decode("utf-8-sig")))
    keys=("NAME","GL","GB","DIST","DIST_ERR")
    assert set(keys)<=set(reader.fieldnames),reader.fieldnames
    units=next(reader)
    assert [units[key] for key in keys]==["","(deg)","(deg)","(kpc)","(kpc)"]
    rows=[{key:row[key] for key in keys} for row in reader]
    assert len({row["NAME"] for row in rows})==len(rows)
    for row in rows:
        angle,latitude,distance,error=map(float,(row[key] for key in keys[1:]))
        assert all(math.isfinite(val) for val in (angle,latitude,distance,error))
        assert 0<=angle<=360 and abs(latitude)<=90 and distance>0 and error>=0
    write_rows("geometry.csv",rows)
    receipt=dict(url=URL,commit=COMMIT,blob=BLOB,source_sha256=hashlib.sha256(raw).hexdigest(),bytes=len(raw),
                 rows=len(rows),retained_columns=keys,protocol_sha256=hashlib.sha256((HOME/"PROTOCOL.md").read_bytes()).hexdigest(),
                 parsed_timing_values=False)
    retain("acquisition.json",json.dumps(receipt,indent=2)+"\n")
    print(len(rows),"geometry rows")


if __name__=="__main__":
    extract()
