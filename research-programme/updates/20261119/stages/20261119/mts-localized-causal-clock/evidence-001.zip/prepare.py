from assess import table
from launch import HERE, Forecaster, MODELS, guard, bridge
import sys
import numpy as np
from scipy.optimize import brentq, root
from scipy.integrate import solve_ivp
from scipy.interpolate import make_interp_spline
from scipy.special import betainc


def bump(radius):
    phase=np.clip(radius-4.5,0,1)
    base=4*phase*(1-phase)
    return base**6,24*base**5*(1-2*phase)


class Constraint:
    def __init__(self,step):
        self.step=step
        launch=Forecaster(7680,"massive")
        nodes=launch.rad
        hh=launch.initial[0]
        self.spline=make_interp_spline(np.r_[-nodes[8:0:-1],nodes],np.r_[hh[8:0:-1],hh],k=5)
        den0=launch.initial[4,0]
        self.density=lambda rad: den0*max(1-(rad/5)**2,0)**6
        self.charge=lambda rad: .0016*betainc(1.5,7,min((rad/5)**2,1))
        def baseline(rad,state):
            inv=1/rad if rad else 0.
            charge=self.charge(rad)
            fac=1-(2*state[0]-charge**2*inv)*inv
            return [rad**2*(self.density(rad)*np.sqrt(fac)+(fac*self.spline(rad,1)**2+self.spline(rad)**2)/2)
                    +.8*rad*self.density(rad)*charge]
        base=solve_ivp(baseline,(0,5.5),[0.],method="DOP853",rtol=8e-14,atol=1e-21,
                       max_step=max(.05,step),dense_output=True)
        assert base.success
        fine=np.linspace(4.5,5.5,1025)
        fraction=1-2*base.sol(fine)[0]/fine+(.0016*betainc(1.5,7,np.minimum((fine/5)**2,1))/fine)**2
        self.fixture=make_interp_spline(fine,np.column_stack([fraction,self.spline(fine),self.spline(fine,1)]),k=5)

    def response(self,coefficient,power):
        def rhs(rad,states):
            fac,field,grad=self.fixture(rad)
            change=-2*states[0]/rad
            new=fac+change
            assert new>0
            phase=rad-4.5
            form=4*phase*(1-phase)
            envelope=form**6
            slope=24*form**5*(1-2*phase)
            delta_h=coefficient*envelope
            delta_g=coefficient*slope
            total_gradient=grad+delta_g
            den=self.density(rad)
            rr=rad**2
            propagator=-rad*(den/np.sqrt(new)+total_gradient**2+power*envelope**2)
            source=den*change/(np.sqrt(new)+np.sqrt(fac))
            source+=(change*grad**2+new*(2*grad*delta_g+delta_g**2+power*envelope**2)+delta_h*(2*field+delta_h))/2
            return [rr*source,propagator*states[1]+rr*(new*total_gradient*slope+(field+delta_h)*envelope),
                    propagator*states[2]+rr*new*envelope**2/2]
        end=solve_ivp(rhs,(4.5,5.5),[0.,0.,0.],method="DOP853",rtol=2e-12,atol=[1e-20,1e-17,1e-14],max_step=self.step)
        assert end.success
        return end.y[:,-1]

    def solve(self):
        _,linear,powder=self.response(0,0)
        assert linear!=0 and powder>0
        def fold(variables):
            coefficient=variables[0]*1e-4
            power=variables[1]*1e-8
            mismatch,gradient,_=self.response(coefficient,power)
            return [mismatch/1e-7,gradient/.01]
        estimate=root(fold,[-.5,4.])
        assert estimate.success and np.linalg.norm(fold(estimate.x))<1e-7
        turning=estimate.x[0]*1e-4
        crit=np.sqrt(estimate.x[1])*1e-4
        delta,grad,dpow=self.response(turning,crit**2)
        curvature=(self.response(turning+1e-8,crit**2)[1]-self.response(turning-1e-8,crit**2)[1])/(2e-8)
        assert curvature>0 and dpow>0
        folds=[dict(step=self.step,fold_coefficient=turning,fold_impulse=crit,mismatch=delta,gradient=grad,
                    second_derivative=curvature,derivative_wrt_power=dpow,base_dmass_dc=linear,base_dmass_dpower=powder)]
        rows=[]
        for strength in (.0001,.0002):
            unsolved=self.response(0,strength**2)[0]
            inside=self.response(turning,strength**2)[0]
            prediction=-strength**2*powder/linear
            result=dict(step=self.step,impulse=strength,weak_prediction=prediction,untreated_added_mass=unsolved,
                        at_fold_coefficient=inside,coefficient=None,remaining_mass=None,branch_found=unsolved*inside<=0)
            if result["branch_found"]:
                coefficient=brentq(lambda value:self.response(value,strength**2)[0],*sorted((turning,0.)),xtol=1e-18)
                result.update(coefficient=coefficient,remaining_mass=self.response(coefficient,strength**2)[0])
            rows.append(result)
        return folds,rows


def audit(check):
    guard()
    folds,solutions=[],[]
    for step in (.075,.0375):
        found,roots=Constraint(step).solve()
        folds.extend(found)
        solutions.extend(roots)
    external=[]
    for count in (3840,7680,15360):
        polar=Forecaster(count,"massive")
        base=polar.geometry(polar.initial)
        shape,_=bump(polar.rad)
        outside=polar.rad>=5.5
        for solution in solutions[-2:]:
            if not solution["branch_found"]:
                continue
            state=polar.initial.copy()
            state[0]+=solution["coefficient"]*shape
            state[1]=solution["impulse"]*shape
            launch=polar.geometry(state)
            mass=np.max(abs(launch["mass"][outside]-base["mass"][outside]))
            ratio=mass/solution["untreated_added_mass"]
            external.append(dict(mesh=count,impulse=solution["impulse"],max_exterior_mass_error=mass,
                                 error_per_untreated_mass=ratio,passed=ratio<=2e-5,charge_max=np.max(abs(launch["charge"]-base["charge"])),
                                 exterior_lapse_max=np.max(abs(launch["alpha"][outside]-base["alpha"][outside])),
                                 exterior_momentum_max=np.max(abs(launch["current"][outside]-base["current"][outside]))))
    table("launch-fold.csv",folds,check)
    table("compensated-launch.csv",solutions,check)
    table("matched-exterior.csv",external,check)


if __name__=="__main__":
    audit("check" in sys.argv)

