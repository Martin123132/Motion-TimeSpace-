from launch import HERE, PREVIOUS, CLOCK, SITES, NAMES, MODELS, MESH, LOCK, bridge, path, ledger, guard, profile
import csv
import io
import json
import sys
import numpy as np
from scipy.interpolate import CubicSpline
from scipy.special import j0, roots_legendre

TOL = 2e-5
RES = (40,80,160)
PEAK = lambda value: float(np.max(np.abs(value)))


def packet(kind, resolution, model, sign):
    result = bridge.read(path(kind,resolution,model,sign))
    assert np.array_equal(result["clock"],CLOCK) and list(result["names"]) == NAMES
    assert np.isfinite(result["records"]).all() and result["records"].shape == (2,len(CLOCK),4)
    return result


def feature(series, front):
    curve = CubicSpline(CLOCK,series)
    bounds = (front,front+1.25)
    extrema = curve.derivative().roots(extrapolate=False)
    points = np.r_[bounds,extrema[(extrema>=bounds[0]) & (extrema<=bounds[1])]]
    magnitude = PEAK(curve(points))
    assert magnitude > 0
    output = {}
    for pct in (1,5,25,50):
        height = pct/100*magnitude
        roots = np.r_[curve.solve(height,extrapolate=False),curve.solve(-height,extrapolate=False)]
        valid = roots[(roots>=bounds[0]) & (roots<=bounds[1])]
        output[pct] = float(min(valid)) if len(valid) else float("nan")
    early = series[CLOCK<=front-.05]
    return output,magnitude,PEAK(early)/magnitude


def flat_wave(times, site, mu2, order):
    nodes,weights = roots_legendre(order)
    lo = np.maximum(4.5,site-times)
    hi = np.minimum(5.5,site+times)
    width = np.maximum(0,hi-lo)
    space = lo[:,None] + (1+nodes)*width[:,None]/2
    bessel = j0(np.sqrt(mu2*np.maximum(0,times[:,None]**2 - (site-space)**2)))
    return (width/(4*site)) * ((space*profile(space)*bessel) @ weights)


def outputs():
    guard()
    frozen = HERE/"frozen.json"
    assert json.loads(frozen.read_text()) == ledger()
    old = json.loads((PREVIOUS/"closeout.json").read_text())["files"]
    for name in ("bridge.py","polar.py","detector-0.0125-massive.npz","detector-0.025-massive.npz"):
        assert bridge.sha(PREVIOUS/name) == old[name]
    history, timing, controls, fronts, diagnostics, budget, flat, contrast = [], [], [], [], [], [], [], []
    pairs = {}
    def err(first,second):
        return PEAK(first-second)
    for model in MODELS:
        for kind, resolutions in (("polar",MESH),("receiver",RES)):
            for res in resolutions:
                minus,plus = [packet(kind,res,model,sign) for sign in (-1,1)]
                if kind=="receiver":
                    assert str(minus["frozen"]) == str(plus["frozen"]) == bridge.sha(frozen)
                else:
                    assert str(minus["protocol"]) == str(plus["protocol"]) == bridge.sha(HERE/"PROTOCOL.md")
                series = (plus["records"]-minus["records"])/2
                rays = np.stack([minus["front"],plus["front"]])
                assert np.max(np.abs(series[:,0])) < 1e-20
                initial = plus["initial"] - minus["initial"]
                exterior = plus["radial_grid"]>=5.5
                assert np.array_equal(minus["radial_grid"],plus["radial_grid"])
                unchanged = [0,1,2,3,5] if kind=="polar" else [0,1,3,4,5,7,8,9,10,11]
                assert not np.any(initial[:,exterior]) and not np.any(initial[unchanged]) and PEAK(initial)>0
                diagnostics.append(dict(method=kind,resolution=res,model=model,exterior_launch_difference=PEAK(initial[:,exterior]),
                                        unchanged_launch_difference=PEAK(initial[unchanged]),interior_odd_peak=PEAK(initial),
                                        launch_match_energy_flux=(float(plus["match"]) if kind=="polar" else "")))
                landmarks = []
                for index, site in enumerate(SITES):
                    pairfront = np.mean(rays[:,index])
                    features = []
                    for channel, name in enumerate(NAMES):
                        wave = series[index,:,channel]
                        values,magnitude,leak = feature(wave,pairfront)
                        assert all(np.isfinite(list(values.values())))
                        history.append(dict(model=model,method=kind,resolution=res,site=site,channel=name,front=pairfront,
                                            first_window_amplitude=magnitude,prefront_fraction=leak,
                                            peak_full_history=PEAK(wave),at_tau_3_2=wave[1600]))
                        features.append(list(values.values()))
                    landmarks.append(features)
                pairs[model,kind,res]=(series,rays,np.array(landmarks))
    for res in RES:
        source = packet("receiver",res,"massive",0)
        olddx = .025 if res==40 else .0125
        saved = bridge.read(PREVIOUS/f"detector-{olddx:g}-massive.npz")
        for index,site in enumerate(SITES):
            for channel,oldcol in enumerate((6,2,0,1)):
                retained = saved["records"][index,:163,oldcol]
                relative = err(source["records"][index,::10,channel],retained)/PEAK(retained)
                controls.append(dict(resolution=res,old_dx=olddx,site=site,channel=NAMES[channel],relative=relative,passed=relative<=TOL))
    for model in MODELS:
        p1,p2,p3 = [pairs[model,"polar",step] for step in MESH]
        s1,s2,s3 = [pairs[model,"receiver",step] for step in RES]
        for index,site in enumerate(SITES):
            for sign_i,sign in enumerate((-1,1)):
                pt = p3[1][sign_i,index]
                st = s3[1][sign_i,index]
                changes = [abs(pt-st),abs(pt-p2[1][sign_i,index]),abs(st-s2[1][sign_i,index])]
                total = sum(changes)/st
                fronts.append(dict(model=model,site=site,sign=sign,forecast=pt,receiver=st,cross=changes[0],
                                   polar_refinement=changes[1],receiver_refinement=changes[2],budget_fraction=total,passed=total<=TOL))
            denom = np.mean(s3[1][:,index])
            for channel,name in enumerate(NAMES):
                vector = lambda row: row[0][index,:,channel]
                scale = PEAK(vector(s3))
                steps = [err(vector(left),vector(right))/scale for left,right in ((p1,p2),(p2,p3),(s1,s2),(s2,s3),(p3,s3))]
                total = steps[1]+steps[3]+steps[4]
                budget.append(dict(model=model,site=site,channel=name,peak=scale,polar_early=steps[0],polar_fine=steps[1],
                                   receiver_early=steps[2],receiver_fine=steps[3],cross=steps[4],sum=total,passed=total<=TOL))
                for pct_i,pct in enumerate((1,5,25,50)):
                    pick = lambda row: row[2][index,channel,pct_i]
                    cross = abs(pick(p3)-pick(s3))
                    total=(cross+abs(pick(p3)-pick(p2))+abs(pick(s3)-pick(s2)))/denom
                    timing.append(dict(model=model,site=site,channel=name,pct=pct,polar=pick(p3),receiver=pick(s3),
                                       cross=cross,delay=pick(s3)-denom,budget_fraction=total,passed=total<=TOL))
            coarse_flat = flat_wave(CLOCK,site,int(model=="massive"),20)
            fine_flat = flat_wave(CLOCK,site,int(model=="massive"),40)
            coupled = s3[0][index,:,0]
            flat.append(dict(model=model,site=site,flat_geometry_front=site-5.5,prefront=PEAK(fine_flat[CLOCK<=site-5.5]),
                             quadrature_change=err(fine_flat,coarse_flat)/PEAK(fine_flat),
                             curved_minus_flat_relative=err(coupled,fine_flat)/PEAK(coupled),
                             at_3_2_flat=fine_flat[1600],at_3_2_coupled=coupled[1600]))
    for index,site in enumerate(SITES):
        for channel,name in enumerate(NAMES):
            mass = pairs["massive","receiver",160][0][index,:,channel]
            rad = pairs["massless","receiver",160][0][index,:,channel]
            late = CLOCK>=2.75
            contrast.append(dict(site=site,channel=name,massive_peak=PEAK(mass),massless_peak=PEAK(rad),
                                 peak_difference=err(mass,rad),massive_at_3_2=mass[1600],massless_at_3_2=rad[1600],
                                 late_massive_rms=np.sqrt(np.mean(mass[late]**2)),
                                 late_massless_rms=np.sqrt(np.mean(rad[late]**2))))
    return {"response.csv":history,"thresholds.csv":timing,"old-control.csv":controls,"null-front.csv":fronts,
            "initial-match.csv":diagnostics,"signal-budget.csv":budget,"flat-control.csv":flat,"matter-contrast.csv":contrast}


def export(check):
    tables = outputs()
    for name, rows in tables.items():
        stream = io.StringIO(newline="")
        writer = csv.DictWriter(stream,fieldnames=list(rows[0]),lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)
        content = stream.getvalue().encode()
        destination = HERE/name
        if check:
            assert destination.read_bytes()==content
        else:
            with destination.open("xb") as file:
                file.write(content)
        verdict = f"{sum(row['passed'] for row in rows)}/{len(rows)} passed" if "passed" in rows[0] else "measurements"
        print(name,len(rows),verdict,flush=True)


if __name__=="__main__":
    export(sys.argv[1:] == ["check"])

