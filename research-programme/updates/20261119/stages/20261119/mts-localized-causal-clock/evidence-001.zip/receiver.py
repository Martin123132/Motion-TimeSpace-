from launch import HERE, PREVIOUS, LOCK, CLOCK, SITES, NAMES, MODELS, Forecaster, bridge, profile, path, guard, ledger
import json
import sys
import numpy as np
from scipy.integrate import solve_ivp
from scipy.special import betainc
from scipy.interpolate import make_interp_spline, CubicSpline
from scipy.optimize import brentq
from scipy.ndimage import correlate1d


class FreeFall:
    def __init__(self, divisions, model, sign):
        self.dx = 1. / divisions
        self.x = (np.arange(24 * divisions) + .5) * self.dx
        self.model = model
        self.mu2 = int(model == "massive")
        self.d1 = np.array([-1.,9,-45,0,45,-9,1]) / (60*self.dx)
        self.d2 = np.array([2.,-27,270,-490,270,-27,2]) / (180*self.dx**2)
        root = Forecaster(7680, "massive")
        knots = root.rad
        field = root.initial[0]
        spline = make_interp_spline(np.r_[-knots[8:0:-1], knots], np.r_[field[8:0:-1], field], k=5)
        den0 = root.initial[4,0]
        def charge(rad):
            return .0016 * betainc(1.5, 7, np.minimum((rad/5)**2, 1))
        def density(rad):
            return den0 * np.maximum(1-(rad/5)**2, 0)**6
        def hamiltonian(rad, mass):
            inv = 1/rad if rad else 0.
            electric = charge(rad)
            factor = 1 - (2*mass[0] - electric**2*inv)*inv
            scalar_e = (factor*(spline(rad,1)**2 + (sign*profile(rad))**2) + spline(rad)**2)/2
            return [rad**2*(density(rad)*np.sqrt(factor) + scalar_e) + .8*rad*density(rad)*electric]
        xx = self.x
        solution = solve_ivp(hamiltonian, (0.,24.), [0.], method="DOP853", rtol=4e-14, atol=1e-21,
                             max_step=.075, dense_output=True)
        assert solution.success
        mass = solution.sol(xx)[0] - charge(xx)**2/(2*xx)
        deficit = 2*mass/xx
        factor = 1 - deficit
        scalar = spline(xx)
        momentum = sign * profile(xx)
        current = -factor * momentum * spline(xx,1)
        zeros = np.zeros_like(xx)
        self.initial = np.stack((deficit/factor, zeros, xx*current/factor**1.5, zeros, mass/xx**3,
                             scalar, momentum*np.sqrt(factor), zeros, scalar*(1-self.mu2),
                             density(xx), zeros, charge(xx)))
        self.weights = [(round(site/self.dx) + np.arange(-4,4)) for site in SITES]
        locations = np.arange(-3.5,4)
        self.coeff = np.array([np.prod(-np.delete(locations,idx)/(loc-np.delete(locations,idx))) for idx,loc in enumerate(locations)])

    def diff(self, values, weights, odd=False):
        if not odd:
            return correlate1d(values, weights, axis=-1, mode="reflect")
        extra = np.concatenate((-values[...,2::-1], values), axis=-1)
        return correlate1d(extra, weights, axis=-1, mode="nearest")[...,3:]

    def local(self, values):
        return np.stack([values[..., indices] @ self.coeff for indices in self.weights])

    def rate(self, state, light, observe=False):
        radial, angular, krad, kang, mass3, field, normal, other, second, density, impulse, charge = state
        xx = self.x
        aa = 1+radial
        cc = 1+angular
        length = np.sqrt(aa)
        radius = np.sqrt(cc)*xx
        angular_rate = kang/cc
        factor = 1/aa
        field_pair = np.stack((field,other))
        grads = self.diff(field_pair,self.d1)
        lapse_grad, sphere_grad = self.diff(state[[0,1]], self.d1)
        radius_x = np.sqrt(cc)*(1+xx*sphere_grad/(2*cc))
        gam = np.sqrt(1 + impulse**2*factor)
        rho = density/(length*cc*gam)
        flow = impulse*factor/gam
        proper_speed = -radius*angular_rate
        electric = (charge/radius**2)**2
        potential = self.mu2*field**2
        normal_sq = normal**2 + second**2
        nonem_p = rho*impulse**2*factor + .5*(normal_sq+factor*np.sum(grads**2,axis=0)-potential)
        pressure = nonem_p - electric/2
        if observe:
            return self.local(np.stack((field,nonem_p,xx*angular/(1+np.sqrt(cc)),proper_speed)))
        current = (rho*gam*impulse-normal*grads[0]-second*grads[1])/length
        ricci = 2*normal_sq - potential + electric + rho*(2*gam**2-1)
        enclosed = mass3/cc**1.5
        rate = np.empty_like(state)
        rate[0] = -2*krad
        rate[1] = -2*kang
        rate[2] = aa*(ricci-2*enclosed-2*pressure) - krad**2*factor
        rate[3] = cc*(enclosed + pressure-angular_rate**2)
        rate[4] = -cc*(pressure*proper_speed + current*radius_x/length)/xx
        rate[5] = normal
        rate[7] = second
        lap = (self.diff(xx*field_pair,self.d2,True)/xx + (sphere_grad/cc-lapse_grad/(2*aa))*grads)*factor
        trace = krad*factor+2*angular_rate
        rate[6] = lap[0] - self.mu2*field + trace*normal
        rate[8] = lap[1] + trace*second
        rate[9] = -self.diff(xx**2*density*flow,self.d1,True)/xx**2
        rate[10] = -flow*self.diff(impulse,self.d1,True) + lapse_grad*(impulse*factor)**2/(2*gam) + .8*length*charge/radius**2
        rate[11] = -.8*xx**2*density*flow
        mid = int(light/self.dx-.5)
        offsets = np.arange(-2,4)
        delta = (light-self.x[mid])/self.dx
        weights = np.array([np.prod((delta-np.delete(offsets,idx))/(off-np.delete(offsets,idx))) for idx,off in enumerate(offsets)])
        null_rate = weights @ (1/length[mid+offsets])
        return rate, null_rate


def calculate(divisions, model, sign):
    guard()
    sealed = HERE/"frozen.json"
    assert json.loads(sealed.read_text()) == ledger()
    target = path("receiver",divisions,model,sign)
    if target.exists():
        raise FileExistsError(target)
    solver = FreeFall(divisions, model, sign)
    state = solver.initial.copy()
    light = 5.5
    ticks = int(np.ceil(.004/(.26*solver.dx)))
    dt = .004/ticks
    samples, paths = [], []
    for tick in range(810*ticks+1):
        if tick%ticks == 0:
            samples.append(solver.rate(state,light,True))
            paths.append(light)
        if tick%100 == 0:
            guard()
        if tick == 810*ticks:
            break
        first, ray1 = solver.rate(state,light)
        second, ray2 = solver.rate(state+dt*first/2,light+dt*ray1/2)
        third, ray3 = solver.rate(state+dt*second/2,light+dt*ray2/2)
        fourth, ray4 = solver.rate(state+dt*third,light+dt*ray3)
        state += dt/6*(first+2*second+2*third+fourth)
        light += dt/6*(ray1+2*ray2+2*ray3+ray4)
    times = np.arange(811)*.004
    curves = CubicSpline(times,np.array(samples))(CLOCK).transpose(1,0,2)
    ray = CubicSpline(times,np.array(paths))
    fronts = [brentq(lambda time: ray(time)-site,0.,1.5,xtol=1e-14) for site in SITES]
    assert np.isfinite(curves).all()
    bridge.archive(target,records=curves,clock=CLOCK,front=fronts,names=NAMES,
                   initial=solver.initial,radial_grid=solver.x,frozen=bridge.sha(sealed))
    print(target.name,flush=True)


if __name__ == "__main__":
    for resolution in map(int,sys.argv[1:]):
        for variant in MODELS:
            for sign in ((0,-1,1) if variant=="massive" else (-1,1)):
                calculate(resolution,variant,sign)

