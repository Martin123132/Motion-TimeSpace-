from score import packet, feature, TOL, PEAK, HERE, PREVIOUS, CLOCK, SITES, NAMES, MODELS, bridge, guard
import csv
import io
import numpy as np
import sys


def contrast(kind,mesh,model,strength=1):
    lo,hi = [packet(kind,mesh,model,sign*strength) for sign in (-1,1)]
    return (hi["records"]-lo["records"])/2, (hi["front"]+lo["front"])/2


def refinement(mesh):
    budgets = []
    for model in MODELS:
        high,front = contrast("refine",mesh,model)
        low,oldfront = contrast("polar" if mesh==7680 else "refine",mesh//2,model)
        receiver,measured = contrast("receiver",160,model)
        coarse,early = contrast("receiver",80,model)
        def row(site,name,metric,first,second,third,fourth,scale):
            pieces = [PEAK(first-second)/scale, PEAK(third-fourth)/scale, PEAK(first-third)/scale]
            net = sum(pieces)
            return dict(model=model,mesh=mesh,site=site,channel=name,measure=metric,polar_step=pieces[0],
                        receiver_step=pieces[1],cross=pieces[2],budget=net,passed=net<=TOL)
        for idx,site in enumerate(SITES):
            budgets.append(row(site,"ray","front",front[idx],oldfront[idx],measured[idx],early[idx],measured[idx]))
            for channel,name in enumerate(NAMES):
                lines = [data[idx,:,channel] for data in (high,low,receiver,coarse)]
                budgets.append(row(site,name,"history",*lines,PEAK(lines[2])))
                stamps = [feature(line,times[idx])[0] for line,times in zip(lines,(front,oldfront,measured,early))]
                for pct in (1,5,25,50):
                    budgets.append(row(site,name,f"threshold-{pct}",*[picks[pct] for picks in stamps],measured[idx]))
    return budgets


def physical():
    linear,transfer,energy = [],[],[]
    before = packet("receiver",160,"massive",0)
    for model in MODELS:
        full,_ = contrast("receiver",160,model)
        half,_ = contrast("receiver",160,model,.5)
        for idx,site in enumerate(SITES):
            for col,name in enumerate(NAMES):
                top = PEAK(half[idx,:,col])
                relative = PEAK(full[idx,:,col]/2-half[idx,:,col])/top
                linear.append(dict(model=model,site=site,channel=name,half_peak=top,relative_nonlinearity=relative,passed=relative<=TOL))
        for strength in (1,.5):
            arm = packet("receiver",160,model,strength)
            delta = (arm["initial"][4,-1]-before["initial"][4,-1])*before["radial_grid"][-1]**3
            if strength==1:
                base = delta
            energy.append(dict(model=model,strength=strength,exterior_ruler=before["radial_grid"][-1],
                               common_added_mass=delta,quadratic_ratio_to_full=delta/(strength**2*base)))
        for pred in MODELS:
            source = contrast("receiver",160,pred)[0][:,:,2]
            target = half[:,:,2]
            training = (CLOCK>=.8)&(CLOCK<=1.8)
            testing = (CLOCK>=1)&(CLOCK<=3.24)
            template = source[0,training]
            scale = np.dot(template,target[0,training])/np.dot(template,template)
            truth = target[1,testing]
            error = scale*source[1,testing]-truth
            rms = np.linalg.norm(error)/np.linalg.norm(truth)
            transfer.append(dict(target=model,predictor=pred,gain=scale,relative_outer_rms=rms,
                                 relative_outer_peak_error=PEAK(error)/PEAK(truth),passed_rms=rms<=TOL))
    return linear,transfer,energy


def table(name,rows,check):
    out=io.StringIO(newline="")
    writer=csv.DictWriter(out,list(rows[0]),lineterminator="\n")
    writer.writeheader()
    writer.writerows(rows)
    content=out.getvalue().encode()
    if check:
        assert (HERE/name).read_bytes()==content
    else:
        with (HERE/name).open("xb") as stream:
            stream.write(content)
    decisions = [row.get("passed",row.get("passed_rms")) for row in rows]
    verdict = f"{sum(decisions)}/{len(rows)} passed" if all(value is not None for value in decisions) else "measurements"
    print(name,len(rows),verdict,flush=True)


if __name__=="__main__":
    guard()
    check="check" in sys.argv
    if sys.argv[1]=="physical":
        for name,data in zip(("amplitude.csv","clock-transfer.csv","mass-cost.csv"),physical()):
            table(name,data,check)
    else:
        mesh=int(sys.argv[1])
        table(f"refinement-{mesh}.csv",refinement(mesh),check)

