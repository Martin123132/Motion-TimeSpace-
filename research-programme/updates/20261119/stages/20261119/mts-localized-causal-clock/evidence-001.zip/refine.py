from launch import guard, HERE, CLOCK, NAMES, SITES, MODELS, Forecaster, initial, bridge, path, ledger, CubicSpline, brentq
import json
import sys
import numpy as np


def run(mesh,model,sign):
    guard()
    assert json.loads((HERE/"frozen.json").read_text())==ledger()
    limit = 3.26
    target = path("refine",mesh,model,sign)
    if target.exists():
        raise FileExistsError(target)
    system = Forecaster(mesh,model)
    fields,_,_ = initial(system,sign)
    point = np.zeros((4,2))
    point[3] = 5.5
    def rate(state,orbit):
        dfield,dorbit = system.rates(state,orbit[:3])
        light = system.grid.at(system.last_geometry["bridge"],orbit[3])
        return dfield,np.vstack([dorbit,light])
    count = int(np.ceil(.005/(.24*system.grid.step)))
    dt = .005/count
    times,values,gap = [],[],[]
    for tick in range(round(limit/dt)+1):
        if tick%count==0:
            times.append(point[2].copy())
            values.append(system.rates(fields,point[:3],True)[[6,2,0,1]])
            gap.append(point[3]-SITES-point[0])
        if tick%128==0:
            guard()
        if tick==round(limit/dt):
            break
        change,drift = rate(fields,point)
        acc,walk = change.copy(),drift.copy()
        for fraction,weight in ((.5,2),(.5,2),(1.,1)):
            change,drift = rate(fields+fraction*dt*change,point+fraction*dt*drift)
            acc += weight*change
            walk += weight*drift
        fields += dt/6*acc
        point += dt/6*walk
    times = np.array(times)
    assert np.all(times[-1]>CLOCK[-1])
    records = np.array([CubicSpline(times[:,site],np.array(values)[:,:,site])(CLOCK) for site in range(2)])
    front = [brentq(CubicSpline(times[:,site],np.array(gap)[:,site]),0,1.5,xtol=1e-14) for site in range(2)]
    assert np.isfinite(records).all()
    bridge.archive(target,clock=CLOCK,names=NAMES,records=records,front=front,addendum=bridge.sha(HERE/"REFINEMENT.md"))
    print(target.name,flush=True)


if __name__=="__main__":
    for mesh in map(int,sys.argv[1:]):
        for model in MODELS:
            for sign in (-1,1):
                run(mesh,model,sign)

