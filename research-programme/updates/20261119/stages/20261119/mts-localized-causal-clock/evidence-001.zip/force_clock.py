from score import packet, PEAK, TOL
from receiver import FreeFall
from launch import HERE, bridge, guard, MODELS, CLOCK, SITES, LOCK
from assess import table
from scipy.interpolate import CubicSpline
import sys
import numpy as np


def source_name(mesh,model,sign):
    return HERE/f"force-{mesh}-{model}-{sign}.npz"


def capture(mesh,model,sign):
    guard()
    dest = source_name(mesh,model,sign)
    if dest.exists():
        raise FileExistsError(dest)
    solver=FreeFall(mesh,model,sign)
    xx=solver.x
    state=solver.initial.copy()
    ray=5.5
    ticks=int(np.ceil(.004/(.26*solver.dx)))
    dt=.004/ticks
    snapshots=[]
    for tick in range(810*ticks+1):
        if tick%ticks==0:
            aa=1+state[0]
            bb=np.sqrt(1+state[1])
            radius=xx*bb
            gam=np.sqrt(1+state[10]**2/aa)
            rho=state[9]/(np.sqrt(aa)*bb**2*gam)
            grad=solver.diff(state[[5,7]],solver.d1)
            pressure=rho*state[10]**2/aa+(state[6]**2+state[8]**2+np.sum(grad**2,axis=0)/aa-solver.mu2*state[5]**2)/2
            mass=xx**3*state[4]+state[11]**2/(2*radius)
            forces=np.stack((-mass/radius**2,state[11]**2/radius**3,-radius*pressure,xx*state[1]/(bb+1)))
            snapshots.append(solver.local(forces))
        if tick%100==0:
            guard()
        if tick==810*ticks:
            break
        first,ray1=solver.rate(state,ray)
        second,ray2=solver.rate(state+dt*first/2,ray+dt*ray1/2)
        third,ray3=solver.rate(state+dt*second/2,ray+dt*ray2/2)
        fourth,ray4=solver.rate(state+dt*third,ray+dt*ray3)
        state+=dt/6*(first+2*second+2*third+fourth)
        ray+=dt/6*(ray1+2*ray2+2*ray3+ray4)
    data=np.array(snapshots).transpose(1,0,2)
    old=packet("receiver",mesh,model,sign)["records"][:,::2,2]
    assert PEAK(data[:,:,3]-old)<1e-19
    bridge.archive(dest,values=data,clock=CLOCK[::2],replay=PEAK(data[:,:,3]-old),protocol=bridge.sha(HERE/"CLOCK-FORCE.md"))
    print(dest.name,flush=True)


def integrate(mesh,model):
    left,right=[bridge.read(source_name(mesh,model,sign)) for sign in (-1,1)]
    assert str(left["protocol"])==str(right["protocol"])==bridge.sha(HERE/"CLOCK-FORCE.md")
    diff=(right["values"]-left["values"])/2
    times=left["clock"]
    answer=[]
    for site in range(2):
        analytic=CubicSpline(times,diff[site,:,:3]).antiderivative(2)
        answer.append(analytic(CLOCK)-analytic(0)-CLOCK[:,None]*analytic(0,1))
    return np.array(answer)


def score(polar_mesh,check):
    rows=[]
    for model in MODELS:
        reference=integrate(160,model)
        coarse=integrate(80,model)
        def trace(mesh):
            prior="refine" if mesh>=7680 else "polar"
            first,second=[packet(prior,mesh,model,sign) for sign in (-1,1)]
            return (second["records"][:,:,2]-first["records"][:,:,2])/2
        observed=trace(polar_mesh)
        old=trace(polar_mesh//2)
        for index,site in enumerate(SITES):
            actual=observed[index]
            terms=reference[index]
            scale=PEAK(actual)
            total=terms.sum(axis=1)
            predicted=PEAK(total-actual)/scale
            score=predicted+PEAK(old[index]-actual)/scale+PEAK(coarse[index].sum(axis=1)-total)/scale
            rows.append(dict(model=model,site=site,polar_mesh=polar_mesh,clock_at_3_2=actual[1600],
                             mass_at_3_2=terms[1600,0],charge_at_3_2=terms[1600,1],pressure_at_3_2=terms[1600,2],
                             integrated_at_3_2=total[1600],cross_error=predicted,budget=score,passed=score<=TOL,
                             without_pressure_error=PEAK(terms[:,:2].sum(axis=1)-actual)/scale,
                             inverse_square_only_error=PEAK(terms[:,0]-actual)/scale))
    table("gravity-force-budget.csv",rows,check)


if __name__=="__main__":
    if sys.argv[1]=="capture":
        for mesh in (80,160):
            for model in MODELS:
                for sign in (-1,1):
                    capture(mesh,model,sign)
    else:
        score(int(sys.argv[1]),"check" in sys.argv)

