from score import export, packet, flat_wave, TOL, PEAK
from launch import HERE, PREVIOUS, CLOCK, SITES, MODELS, LOCK, bridge, guard, ledger
from assess import refinement, physical, table
from force_clock import score as force_score
from prepare import audit
import numpy as np
import json
import csv
import sys
from pathlib import Path


def read_csv(name):
    with (HERE/name).open(newline="") as stream:
        return list(csv.DictReader(stream))


def details():
    guard()
    for name,digest in json.loads((PREVIOUS/"closeout.json").read_text())["files"].items():
        assert bridge.sha(PREVIOUS/name)==digest
    assert json.loads((HERE/"frozen.json").read_text())==ledger()
    export(True)
    for mesh in (7680,15360):
        table(f"refinement-{mesh}.csv",refinement(mesh),True)
    for name,rows in zip(("amplitude.csv","clock-transfer.csv","mass-cost.csv"),physical()):
        table(name,rows,True)
    force_score(15360,True)
    audit(True)
    for site in SITES:
        for mass2 in (0,1):
            delay=np.array([1e-3,1e-4,1e-5])
            field=flat_wave(site-5.5+delay,site,mass2,40)
            leading=5.5*.0002*4**6*delay**7/(14*site)
            ratios=field/leading
            assert np.all(np.diff(abs(ratios-1))<0) and abs(ratios[-1]-1)<1e-4
            assert not flat_wave(np.array([site-5.5-.001,site-5.5]),site,mass2,40).any()
    folds=read_csv("launch-fold.csv")
    roots=read_csv("compensated-launch.csv")
    for folded in folds:
        assert float(folded["derivative_wrt_power"])>0 and float(folded["second_derivative"])>0
        assert float(folded["fold_impulse"])>.0002
    assert abs(float(folds[0]["fold_impulse"])/float(folds[1]["fold_impulse"])-1)<TOL
    for result in roots:
        assert result["branch_found"]=="True" and abs(float(result["remaining_mass"]))/float(result["untreated_added_mass"])<TOL
    counts={}
    for file in sorted(HERE.glob("*.csv")):
        rows=read_csv(file.name)
        status="passed" if "passed" in rows[0] else "passed_rms" if "passed_rms" in rows[0] else None
        counts[file.name]={"rows":len(rows),"pass":sum(row[status]=="True" for row in rows) if status else None}
    assert counts["old-control.csv"]["pass"]==24 and counts["null-front.csv"]["pass"]==8
    assert counts["matched-exterior.csv"]["pass"]==6 and counts["gravity-force-budget.csv"]["pass"]==4
    separation=read_csv("clock-transfer.csv")
    assert all((row["predictor"]==row["target"])==(row["passed_rms"]=="True") for row in separation)
    assert not list(HERE.glob("*.partial")) and not list(HERE.glob("__pycache__"))
    inherited={}
    for module in list(sys.modules.values()):
        location=getattr(module,"__file__",None)
        if not location:
            continue
        source=Path(location).resolve()
        if source.suffix==".py" and source.is_relative_to(HERE.parent) and not source.is_relative_to(HERE):
            inherited[source.relative_to(HERE.parent).as_posix()]=bridge.sha(source)
    return dict(previous=LOCK,forecasts=bridge.sha(HERE/"frozen.json"),counts=counts,inherited=inherited,
                files={file.name:bridge.sha(file) for file in sorted(HERE.iterdir()) if file.is_file() and file.name!="closeout.json"})


if __name__=="__main__":
    info=details()
    seal=HERE/"closeout.json"
    if "seal" in sys.argv:
        with seal.open("x",encoding="utf8") as stream:
            json.dump(info,stream,sort_keys=True,indent=2)
    else:
        assert json.loads(seal.read_text())==info
    print(bridge.sha(seal),len(info["files"]),"files",sum(v["rows"] for v in info["counts"].values()),"rows",flush=True)

