from shared import HERE,guard,table
import numpy as np
import pandas as pd

def run():
    guard()
    results=[];errors=[]
    for family in ("added","transfer"):
        refs=[pd.read_csv(HERE/(level+"-"+family+"-polar.csv")).set_index(["case","R"]).sort_index() for level in ("fine","512-40")]
        low,high=refs
        assert high.index.equals(low.index)
        for col in ("ordinary_finite","wave_polar","mts_finite"):
            difference=float(np.max(abs(high[col]-low[col])/np.maximum(1,abs(high[col]))))
            assert difference<2e-5
            errors.append(dict(family=family,quantity=col,largest_scaled_change=difference))
        for radius in (6.,8.3):
            series=high.xs(radius,level="R")
            required=series.required_extra_lo-series.required_extra_hi
            assert np.allclose(required,series.observed_lo-series.observed_hi)
            for case in ("fixed1","free2"):
                points=series.loc[[case+"-minus",case+"-plus"]]
                lower,upper=points.amplitude
                subset=series[series.amplitude.between(lower,upper)]
                for col in ("ordinary_finite","required_extra_lo","required_extra_hi"):
                    estimate=np.interp(subset.amplitude,points.amplitude,points[col])
                    assert np.max(abs(estimate-subset[col]))<1e-12
                nearest=float(points.required_extra_lo.min());farthest=float(points.required_extra_hi.max())
                reference=float(points.observed_lo.iloc[0]-points.ordinary_at_zero.iloc[0])
                null_for_all=bool(points.required_extra_lo.max()<=0<=points.required_extra_hi.min())
                results.append(dict(family=family,source_range=case,R=radius,minimum_residual_for_any_amplitude=nearest,
                               maximum_residual_for_any_amplitude=farthest,spherical_zero_allowed_somewhere=nearest<=0<=farthest,
                               spherical_zero_allowed_throughout=null_for_all,reference_residual_lower=reference,
                               smallest_effective_quadrupole_kms2=float(points.effective_phi2_lo_kms2.min()),
                               largest_effective_quadrupole_kms2=float(points.effective_phi2_hi_kms2.max()),
                               maximum_tested_wave=float(subset.wave_polar.max()),minimum_tested_wave=float(subset.wave_polar.min()),
                               minimum_tested_mts_shortfall=float((subset.observed_lo-subset.mts_finite).min()),
                               n_nonzero_amplitudes=len(subset)))
    table("continuous-polar-requirements.csv",results);table("polar-resolution.csv",errors)
if __name__=="__main__":run()
