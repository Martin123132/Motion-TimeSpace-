from shared import HERE,guard,asjson
import numpy as np
import pandas as pd

def run():
    guard();name="512-40"
    with np.load(HERE/(name+"-reference.npz")) as ref:
        original=ref["state"];base=float(ref["mass"])
    assert original.ndim==2 and original.size>1000 and base>0
    discrepancies=[]
    for family in ("added","transfer"):
        cases=pd.read_csv(HERE/f"{name}-{family}-states.csv")
        for row in cases.itertuples():
            with np.load(HERE/f"{name}-{family}-{row.case}.npz") as record:
                state=record["state"];mass=float(record["mass"])
            assert state.shape==original.shape and np.isfinite(state).all()
            overlap=abs(np.vdot(original,state))/(np.linalg.norm(original)*np.linalg.norm(state))
            discrepancies.append(max(abs(overlap-row.shape_overlap),abs(mass/base-row.ground_mass_ratio)))
    assert len(discrepancies)==12 and max(discrepancies)<2e-12
    poles=pd.read_csv(HERE/"continuous-polar-requirements.csv")
    assert len(poles)==8
    assert np.all(poles.spherical_zero_allowed_somewhere==((poles.minimum_residual_for_any_amplitude<=0)&(poles.maximum_residual_for_any_amplitude>=0)))
    assert pd.read_csv(HERE/"polar-resolution.csv").largest_scaled_change.max()<2e-5
    asjson("packet-check.json",dict(stored_finite_states=len(discrepancies),reference_states=1,shape=list(original.shape),
           maximum_record_to_packet_discrepancy=max(discrepancies),inner_excludes_spherical=bool((~poles.loc[poles.R==6.,"spherical_zero_allowed_somewhere"]).all()),
           outer_spherical_compatible_in_all_cases=bool(poles.loc[poles.R==8.3,"spherical_zero_allowed_throughout"].all())))
if __name__=="__main__":run()
