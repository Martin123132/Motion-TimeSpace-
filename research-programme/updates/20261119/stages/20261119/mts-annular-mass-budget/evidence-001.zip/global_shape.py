from shared import HERE,guard,read,table
from budget import ring_mass
from kernel import Lenses
from scipy.integrate import quad
from scipy.optimize import brentq
import numpy as np

def run():
    guard()
    stars=Lenses().stars
    total=2.031e10
    def original(radius):
        return quad(lambda pos:2*np.pi*1e6*pos*stars.factors[0]*stars.raw_sigma(pos)[0],0,radius,
                    points=stars.knots[(stars.knots>0)&(stars.knots<radius)],epsrel=3e-12)[0]
    assert abs(original(30)/total-1)<2e-12
    def partial(lower,upper,radius):
        return 0. if radius<=lower else ring_mass(stars,lower,min(radius,upper))
    output=[]
    for row in read(HERE/"independent-budget.csv"):
        change=float(row["amplitude"]);weight=float(row["donor_per_unit"])
        final=total+float(row["net_mass_change"])
        def enclosed(radius):
            return original(radius)+change*(partial(4,7,radius)+weight*partial(7,8,radius))
        assert abs(enclosed(30)/final-1)<2e-12
        radius=brentq(lambda pos:enclosed(pos)-final/2,0,30.)
        width=float(row["width"])
        output.append(dict(family=row["family"],width=row["width"],calibration=row["calibration"],side=row["side"],
                           mass_solar=final,r50_kpc=radius,mass_in_table_widths=(final-total)/.094e10,
                           radius_in_table_widths=(radius-4.24)/.20,inside_mass=abs(final-total)<=width*.094e10,
                           inside_radius=abs(radius-4.24)<=width*.20))
    table("global-shape-check.csv",output)
if __name__=="__main__":run()
