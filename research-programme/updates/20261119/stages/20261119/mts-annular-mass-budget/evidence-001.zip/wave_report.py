from shared import HERE,HEIGHT_DIR,POP,guard,read,table
import numpy as np
import pandas as pd

def run():
    guard()
    states=[pd.read_csv(HERE/f"{level}-wave-mode-check.csv").set_index(["state","R"]).sort_index() for level in ("coarse","fine")]
    assert len(states[0])==26 and states[0].index.equals(states[1].index)
    spectra=[pd.read_csv(HERE/f"{level}-wave-shell-modes.csv").set_index(["state","R","shell_lo_kpc","shell_hi_kpc","ell"]).sort_index() for level in ("coarse","fine")]
    delta=(spectra[0]-spectra[1]).abs()
    assert spectra[0].index.equals(spectra[1].index) and delta.polar.max()<2e-8
    poles=pd.read_csv(HERE/"continuous-polar-requirements.csv")
    with np.load(POP/"mass-spherical-fine-main-384-32.npz") as data:
        points=data["locations"][[-4,-3]];forces=data["matched_nfw_force"][[-4,-3]]
    assert np.allclose(points,[[-6,0,1.5],[-8.3,0,1.5]])
    cosine=(forces*np.column_stack([-points[:,2],np.zeros(2),points[:,0]])).sum(axis=1)/(np.linalg.norm(forces,axis=1)*np.linalg.norm(points,axis=1))
    assert max(abs(cosine))<1e-14
    rows=[]
    for family in ("added","transfer"):
        for radius in (6.,8.3):
            peak=states[-1].loc[(family+"-free2-plus",radius)];base=states[-1].loc[("reference",radius)]
            target=poles[(poles.family==family)&(poles.R==radius)&(poles.source_range=="free2")].iloc[0]
            spectral=spectra[-1].xs((family+"-free2-plus",radius),level=("state","R")).polar
            orig=spectra[-1].xs(("reference",radius),level=("state","R")).polar
            diff=(spectral-orig).groupby(level=["shell_lo_kpc","shell_hi_kpc"]).sum()
            assert abs(diff.sum()-(peak.from_density-base.from_density))<1e-12
            largest=diff.abs().idxmax()
            rows.append(dict(family=family,R=radius,wave=peak.from_density,monopole=peak.monopole,quadrupole=peak.quadrupole,
                           higher=peak.higher,interior=peak.interior,exterior=peak.exterior,reference_wave=base.from_density,
                           induced_quadrupole=peak.quadrupole-base.quadrupole,induced_higher=peak.higher-base.higher,
                           strongest_change_shell_lo_kpc=largest[0],strongest_change_shell_hi_kpc=largest[1],
                           strongest_shell_signed_change=diff[largest],minimum_required_polar=target.minimum_residual_for_any_amplitude,
                           lower_target_over_wave_at_positive_endpoint=target.minimum_residual_for_any_amplitude/peak.from_density,
                           worst_shell_refinement=delta.polar.max(),spherical_projection_max_cosine=max(abs(cosine))))
    table("wave-origin.csv",rows)
if __name__=="__main__":run()
