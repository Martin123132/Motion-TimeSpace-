from shared import HERE,KERNEL,HEIGHT_DIR,guard,read,table
from rings import sky_ring,source_field
from dual_probe import Lenses,Experiment,Linearization,Readout,StellarPotential,polish,potential,np,G,SUN,OUTER
from height import Run
from pair import Sector
from types import SimpleNamespace
from annular_projection import Polar,save_packet
import sys

def prepared(level):
    if level in ("medium","fine"):
        return Experiment(level,32,2),level
    count,degree=map(int,level.split("-"))
    experiment=Run("main",count,degree)
    fixed=StellarPotential("mass-spherical-fine").mesh(experiment.rad,experiment.sys.mu)[0]
    return SimpleNamespace(run=experiment,system=experiment.sys,sector=Sector(experiment.sys,32,2),
                           ext=experiment.ext+fixed/experiment.sys.vel**2),"fine"

def run(level):
    guard()
    exp,source_level=prepared(level);system=exp.system
    inputs=read(HERE/"independent-budget.csv")
    prior=read(KERNEL/(source_level+"-force-tangents.csv"))
    samples=[record for record in prior if record["model"]=="ground" and record["norm"]=="matched"]
    radii=np.array(sorted({float(row["R"]) for row in samples}))
    locations=np.column_stack([-radii,np.zeros_like(radii),np.full_like(radii,1.1)])
    reader=Readout(system,exp.sector,locations)
    baseline={(float(row["R"]),row["model"]):row for row in read(HEIGHT_DIR/(source_level+"-SEGUE-frozen-forces.csv"))
              if row["height_source"]=="pooled" and row["mode"]=="matched"}
    with np.load(HEIGHT_DIR/(source_level+"-pooled-matched-state.npz")) as saved:
        reference=np.zeros_like(system.kin)
        old=saved["state"];reference[:old.shape[0],:old.shape[1]]=old
        system.mass=float(saved["mass"]);target=float(saved["force"][exp.run.anchor,0])
    stock=StellarPotential("mass-spherical-"+source_level).mesh(exp.run.rad,system.mu)
    adjusted,adjusted_vir=potential(exp,source_level,"pooled")
    base_ext=exp.ext+adjusted
    base_vir=exp.run.work+stock[1]/system.vel**2+adjusted_vir
    system.ext=base_ext;system.vir=base_vir
    for iteration in range(7):
        if level in ("fine","medium") and iteration==0:
            linear=Linearization(system,reference)
        else:
            linear=polish(system,reference.copy());reference=linear.state
        mismatch=exp.run.mass_force(reference)-target
        if abs(mismatch)<1e-8:break
        response=linear.differentiate("mass")[0]
        size=-mismatch/exp.run.mass_force(reference,response)
        system.mass*=np.exp(size);reference=reference+size*response
    else: raise ArithmeticError("reference anchor")
    mass=system.mass;mass_mode=linear.differentiate("mass")[0]
    residual=np.linalg.norm(linear.resid)/(abs(linear.chemical)*np.sqrt(mass))
    assert residual<2e-12
    dark0=reader.field("ground",reference)[:,2]
    saved_dark=np.array([float(baseline[(radius,"ground")]["dark"]) for radius in radii])
    max_base_diff=max(abs(dark0-saved_dark)/np.maximum(1,abs(saved_dark)))
    if level in ("fine","medium"):assert max_base_diff<2e-8
    nfw_dark=np.array([float(baseline[(radius,"nfw")]["dark"]) for radius in radii])
    anchor_rate=float(read(KERNEL/(source_level+"-annulus.csv"))[0]["halo_log_amp_rate"])
    fnfw=-float(read(KERNEL/(source_level+"-annulus.csv"))[0]["anchor_direct"])/anchor_rate
    profile=Lenses().profile
    sky_probe=Polar(exp,source_level,profile,reference) if level!="medium" else None
    if "-" in level:save_packet(level+"-reference.npz",reference,mass)
    kernels=[]
    for bounds in ((4.,7.),(7.,8.)):
        guard()
        ext,vir,actual,integrated=source_field(profile,exp,source_level,bounds)
        kz=np.array([sky_ring(profile,radius,1.1,source_level,bounds)[1] for radius in radii])
        anchor=sky_ring(profile,OUTER,0.,source_level,bounds)[0]
        kernels.append((ext,vir,kz,anchor,actual,integrated))
    stamp=[dict(zone=name,mass=item[4],poisson_mass=item[5],midplane_outer_force=item[3],reference_residual=residual,
                reference_outer_defect=mismatch,reference_wave_relative_change=max_base_diff) for name,item in zip(("inner","donor"),kernels)]
    table(level+"-kernel.csv",stamp)
    conversion=-1/(2*np.pi*G*1e6)
    for family in ("added","transfer"):
        rows=[row for row in inputs if row["family"]==family]
        rho=float(rows[0]["donor_per_unit"])
        delta_ext,delta_vir,delta_kz,delta_anchor=[kernels[0][idx]+rho*kernels[1][idx] for idx in range(4)]
        assert abs(kernels[0][4]-float(rows[0]["inner_base_mass"]))<.01 and abs(kernels[1][4]-float(rows[0]["outer_base_mass"]))<.01
        system.ext=base_ext;system.vir=base_vir;system.mass=mass
        number_fixed=linear.constrained(-linear.read(linear.wave*delta_ext))
        log_rate=-(delta_anchor+exp.run.mass_force(reference,number_fixed))/exp.run.mass_force(reference,mass_mode)
        tangent=number_fixed+log_rate*mass_mode
        dk=conversion*(delta_kz+reader.field("ground",reference,tangent)[:,2])
        if family=="added" and level in ("medium","fine"):
            assert max(abs(dk[np.searchsorted(radii,float(row["R"]))]-float(row["total"])) for row in samples)<1e-7
        cases=[(row["calibration"]+row["width"]+"-"+row["side"],float(row["amplitude"])) for row in rows
               if (row["calibration"],row["width"]) in (("fixed","1"),("free","2"))]
        cases.extend([("interior-"+name,amp/2) for name,amp in cases if name.startswith("free2")])
        outputs=[];states=[];projections=[]
        for name,amp in cases:
            guard()
            system.ext=base_ext+amp*delta_ext;system.vir=base_vir+amp*delta_vir
            system.mass=mass*np.exp(amp*log_rate);trial=reference+amp*tangent
            for iteration in range(8):
                solved=polish(system,trial.copy());state=solved.state
                defect=exp.run.mass_force(state)-target+amp*delta_anchor
                if abs(defect)<1e-8:break
                response=solved.differentiate("mass")[0]
                shift=-defect/exp.run.mass_force(state,response)
                system.mass*=np.exp(shift);trial=state+shift*response
            else:raise ArithmeticError("failed to maintain outer speed")
            residual=np.linalg.norm(solved.resid)/(abs(solved.chemical)*np.sqrt(system.mass))
            assert residual<2e-12 and abs(defect)<1e-8
            nfw_ratio=1-amp*delta_anchor/fnfw
            assert nfw_ratio>0 and abs(amp*delta_anchor+(nfw_ratio-1)*fnfw)<1e-8
            optical_norm=abs(np.vdot(reference,state))/(np.linalg.norm(reference)*np.linalg.norm(state))
            assert optical_norm>.99
            states.append(dict(family=family,case=name,amplitude=amp,ground_mass_ratio=system.mass/mass,
                               nfw_amplitude_ratio=nfw_ratio,shape_overlap=optical_norm,outer_defect=defect,
                               nonlinear_residual=residual,newton_updates=iteration,chemical=solved.chemical))
            wave=reader.field("ground",state)[:,2];direct=amp*delta_kz
            if sky_probe:
                projections.extend(dict(family=family,case=name,amplitude=amp,**entry) for entry in sky_probe.check(state,amp,rho))
            if "-" in level:save_packet(level+"-"+family+"-"+name+".npz",state,system.mass)
            for model,dark_delta,slope in [("ground",wave-dark0,dk),("nfw",nfw_dark*(nfw_ratio-1),conversion*(delta_kz-nfw_dark*delta_anchor/fnfw))]:
                for row in samples:
                    radius=float(row["R"]);idx=np.searchsorted(radii,radius)
                    base=float(baseline[(radius,model)]["Kforce_equiv"])
                    if model=="ground":base+=conversion*(dark0[idx]-saved_dark[idx])
                    change=conversion*(direct[idx]+dark_delta[idx])
                    outputs.append(dict(model=model,case=name,amplitude=amp,R=radius,FeH=row["FeH"],alpha=row["alpha"],
                                        observed=row["observed"],baseline=base,direct=conversion*direct[idx],induced=conversion*dark_delta[idx],
                                        finite_change=change,predicted=base+change,tangent=amp*slope[idx]))
        table(level+"-"+family+"-forces.csv",outputs);table(level+"-"+family+"-states.csv",states)
        if projections:table(level+"-"+family+"-polar.csv",projections)
        print("Saved",level,family,flush=True)
if __name__=="__main__":run(sys.argv[1])
