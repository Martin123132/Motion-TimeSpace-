from shared import HERE,IR,CLUMP,KERNEL,HEIGHT_DIR,guard,read,table,asjson,digest
import numpy as np
import pandas as pd
import sys

TOL=2e-5
def compare_grids(first,last):
    results=[]
    for family in ("added","transfer"):
        frames=[]
        for level in (first,last):
            frame=pd.read_csv(HERE/f"{level}-{family}-forces.csv").set_index(["model","case","FeH","alpha","R"]).sort_index()
            assert len(frame)==516 and frame.index.is_unique
            frames.append(frame)
        assert frames[0].index.equals(frames[1].index)
        for key in ["direct","induced","finite_change","predicted"]:
            delta=abs(frames[0][key]-frames[1][key])
            scaled=delta/np.maximum(1.,abs(frames[1][key]))
            results.append(dict(first=first,last=last,family=family,metric=key,worst=float(scaled.max()),required=TOL,passed=bool(scaled.max()<TOL)))
    return results

def stats(level):
    sites=pd.read_csv(HEIGHT_DIR/"fine-SEGUE-comparison.csv")
    sites=sites[(sites.R0==8.122)&(sites.height_source=="pooled")&(sites["mode"]=="matched")&(sites.model=="ground")]
    errs=sites.set_index(["FeH","alphaFe","R"]).error
    result=[]
    for family in ("added","transfer"):
        df=pd.read_csv(HERE/f"{level}-{family}-forces.csv")
        chosen=df[df.R<6.5].copy()
        chosen["error"]=[errs.loc[(row.FeH,row.alpha,row.R)] for row in chosen.itertuples()]
        for (model,case),block in chosen.groupby(["model","case"]):
            assert len(block)==14 and abs(block.observed.mean()-183.65)<1e-10
            assert np.max(abs(block.baseline+block.direct+block.induced-block.predicted))<1e-10
            if model=="nfw":assert np.max(abs(block.tangent-block.finite_change))<2e-12
            base=block.baseline.mean();change=block.finite_change.mean()
            result.append(dict(family=family,model=model,case=case,amplitude=block.amplitude.iat[0],observed_mean=block.observed.mean(),
                               baseline_mean=base,direct_mean=block.direct.mean(),induced_mean=block.induced.mean(),
                               finite_change_mean=change,finite_mean=block.predicted.mean(),mean_gap_closed_fraction=change/(block.observed.mean()-base),
                               largest_site_tangent_departure=max(abs(block.finite_change-block.tangent)),
                               n_below_reported_one_width=int(sum(block.predicted<block.observed-block.error)),
                               n_below_central=int(sum(block.predicted<block.observed)),count=len(block)))
    return result

def run(levels):
    guard()
    checks=[]
    for first,last in zip(levels[:-1],levels[1:]):checks.extend(compare_grids(first,last))
    table("numerical-comparison-"+levels[-1]+".csv",checks)
    for row in checks:print(row["first"],row["last"],row["family"],row["metric"],row["worst"],flush=True)
    table("force-summary-"+levels[-1]+".csv",stats(levels[-1]))

def light():
    guard()
    bands=pd.read_csv(HERE/"independent-budget.csv")
    base=pd.read_csv(IR/"parallax-depth-order14.csv")
    truth=base[(base.group=="drawn")&(base.compact=="annulus")].iloc[0]
    frames=[pd.read_csv(HERE/f"optical-order{order}.csv").set_index("id").sort_index() for order in (8,14)]
    old,new=frames
    assert old.index.equals(new.index) and new.index.is_unique and len(new)==3760
    checks=[]
    for key in ("add_lo","add_hi","transfer_lo","transfer_hi","donor_lo","donor_hi"):
        err=abs(new[key]-old[key])
        natural=(new.add_hi+new.donor_hi).clip(lower=1e-25)
        site=float((err/natural).max())
        mean=float(err.mean()/max(new[key].abs().mean(),1e-25))
        assert max(site,mean)<TOL,(key,site,mean)
        checks.append(dict(key=key,worst_normalized_by_sightline_positive_kernels=site,mean_absolute_error_over_mean_magnitude=mean))
    assert np.allclose([new.add_lo.mean(),new.add_hi.mean()],[truth.tau_lo,truth.tau_hi],atol=1e-18,rtol=TOL)
    assert (new.transfer_lo>=new.independent_zone_lo-1e-19).all() and (new.transfer_hi<=new.independent_zone_hi+1e-19).all()
    table("optical-resolution.csv",checks)
    out=[]; individual=[]
    ipd=pd.read_csv(IR/"all-foreground-crowding.csv")
    clean=set(ipd.loc[ipd.ipd_clean&ipd.annulus_exact_zero,"id"])
    assert clean=={"cg6104l11414","cg6104l31652"}
    for row in bands.itertuples():
        lo,hi=("add_lo","add_hi") if row.family=="added" else ("transfer_lo","transfer_hi")
        a=row.amplitude
        lower=np.minimum(a*new[lo],a*new[hi]);upper=np.maximum(a*new[lo],a*new[hi])
        out.append(dict(family=row.family,calibration=row.calibration,width=row.width,side=row.side,amplitude=a,
                        delta_ideal_depth_lo=lower.mean(),delta_ideal_depth_hi=upper.mean(),strictly_negative=int(sum(upper<0.)),
                        strictly_positive=int(sum(lower>0.)),fixed_zero=int(sum((upper==0.)&(lower==0.))),n=len(new)))
        for source in sorted(clean):
            individual.append(dict(id=source,family=row.family,calibration=row.calibration,width=row.width,side=row.side,
                                   delta_tau_lo=lower.loc[source],delta_tau_hi=upper.loc[source]))
            if row.family=="added":assert lower.loc[source]==upper.loc[source]==0
            elif a>0:assert upper.loc[source]<0
            else:assert lower.loc[source]>0
    table("pilot-finite-depth.csv",out);table("two-foreground-predictions.csv",individual)
if __name__=="__main__":
    if sys.argv[1]=="light":light()
    else:run(sys.argv[1:])
