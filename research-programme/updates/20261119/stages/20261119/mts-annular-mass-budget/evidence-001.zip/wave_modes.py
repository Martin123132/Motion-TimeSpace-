from shared import HERE,guard,table
from kernel import Lenses
from pair import branch,UNIT
from disk_state import basis,root_values,families
from cross_stress import grid,axes
from scipy.special import roots_legendre
import numpy as np
import pandas as pd
import sys

def run(level):
    guard()
    count,degree=512,40
    with np.load(branch.HERE/"main.npz") as source:length=float(source["length"]);edge=float(source["edge"])
    with np.load(branch.PARENT/"angular28-diff.npz") as source:vel=float(source["velocity_unit_kms"])
    points=np.array([6.,8.3]);spheres=np.hypot(points,1.5);mu=1.5/spheres
    shells=np.unique(np.clip(np.r_[0,4,spheres,7,8,12,20,length*edge],0,length*edge))
    divisions,order=(96,10) if level=="coarse" else (160,14)
    breaks=np.unique(np.r_[shells/length,np.linspace(0,edge,divisions+1)])
    coords,weights=grid(breaks,order);coords=coords.ravel();weights=weights.ravel()
    nodes,angular_weights=roots_legendre(3*degree+40);nodes=(nodes+1)/2;angular_weights/=2
    modes=np.arange(0,degree+1,2);harmonics=np.arange(0,2*degree+1,2)
    angular=families(nodes,modes)
    project=axes(harmonics,nodes)[0]*angular_weights[:,None]
    gradient=axes(harmonics,mu)[1]
    files=[HERE/"512-40-reference.npz"]+sorted(path for path in HERE.glob("512-40-*.npz") if path.name!="512-40-reference.npz")
    assert len(files)==13
    fields=[]
    for path in files:
        with np.load(path) as data:fields.append(data["state"])
    fields=np.stack(fields)
    radial=np.empty((len(files),len(coords),len(modes)))
    for idx,ell in enumerate(modes):
        basis_values=basis(ell,root_values(ell,count),edge,coords)
        radial[:,:,idx]=(basis_values@fields[:,idx,:].T).T
    controls=pd.concat([pd.read_csv(HERE/f"512-40-{family}-polar.csv") for family in ("added","transfer")])
    records=[];sums=[]
    for idx,path in enumerate(files):
        label=path.stem.removeprefix("512-40-")
        if label!="reference":family,case=label.split("-",1)
        src=(radial[idx]@angular.T)**2@project
        for pos,radius in enumerate(points):
            at=spheres[pos]/length
            output=np.zeros(len(harmonics));inner_value=0.
            for low,high in zip(shells[:-1],shells[1:],strict=True):
                use=(coords*length>low)&(coords*length<high)
                inside=high<=spheres[pos]
                loc=coords[use];measure=weights[use];density=src[use]
                kernel=(loc**2/at)[:,None]*(loc[:,None]/at)**harmonics if inside else loc[:,None]*(at/loc[:,None])**harmonics
                phi=-vel**2*((measure[:,None]*kernel*density).sum(axis=0))
                polar=phi*gradient[pos]*UNIT/(np.sqrt(1-mu[pos]**2)*spheres[pos])
                for ell,component in zip(harmonics,polar):
                    records.append(dict(state=label,R=radius,shell_lo_kpc=low,shell_hi_kpc=high,ell=ell,polar=component))
                output+=polar
                if inside:inner_value+=polar.sum()
            subset=controls.loc[controls.R==radius]
            actual=subset.reference_wave_polar.iat[0] if label=="reference" else subset.loc[(subset.family==family)&(subset.case==case),"wave_polar"].iat[0]
            error=abs(output.sum()-actual)
            assert abs(output[0])<1e-18 and error<2e-8,(level,label,radius,error)
            sums.append(dict(state=label,R=radius,monopole=output[0],quadrupole=output[1],higher=output[2:].sum(),
                             interior=inner_value,exterior=output.sum()-inner_value,from_density=output.sum(),direct=actual,error=error))
    table(level+"-wave-shell-modes.csv",records);table(level+"-wave-mode-check.csv",sums)
    print(level,"stored-state multipoles close",max(row["error"] for row in sums),flush=True)
if __name__=="__main__":run(sys.argv[1])
