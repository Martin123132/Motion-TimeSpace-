from shared import HEIGHT_DIR,read,put
from rings import sky_ring
from pair import Readout
from feasibility import bands,UNIT
import io
import numpy as np

class Polar:
    def __init__(self,exp,level,profile,reference):
        self.radii=np.array([6.,8.3]);self.height=1.5
        loc=np.column_stack([-self.radii,np.zeros(2),np.full(2,self.height)])
        self.reader=Readout(exp.system,exp.sector,loc)
        self.direction=np.column_stack([np.full(2,-self.height),np.zeros(2),-self.radii])/np.hypot(self.radii,self.height)[:,None]*UNIT
        self.bounds=bands()
        table=read(HEIGHT_DIR/(level+"-solutions.csv"))
        self.base=np.array([float(next(item["polar_"+str(radius).removesuffix(".0")] for item in table if
                                        (item["profile"],item["mode"],item["model"])==("pooled","matched","nfw"))) for radius in self.radii])
        self.wave0=self.project(self.reader.field("ground",reference))
        self.delta=[]
        for lower,upper in ((4.,7.),(7.,8.)):
            vals=np.array([sky_ring(profile,radius,self.height,level,(lower,upper)) for radius in self.radii])
            self.delta.append(np.sum(vals*self.direction[:,[0,2]],axis=1))
        stock=next(item for item in table if (item["profile"],item["mode"],item["model"])==("pooled","matched","ground"))
        assert max(abs(self.base+self.wave0-[float(stock["polar_6"]),float(stock["polar_8.3"])]))<2e-5
    def project(self,field):return np.sum(field*self.direction,axis=1)
    def check(self,state,amplitude,ratio):
        wave=self.project(self.reader.field("ground",state));rows=[]
        for idx,radius in enumerate(self.radii):
            northern=self.bounds[radius,"atheta","north"];southern=self.bounds[radius,"atheta","south"]
            lower=max(northern[3],-southern[4]);upper=min(northern[4],-southern[3])
            common=self.base[idx]+amplitude*(self.delta[0][idx]+ratio*self.delta[1][idx])
            sphere=np.hypot(radius,self.height);mu=self.height/sphere
            unit=3*mu*np.sqrt(1-mu**2)*UNIT/sphere
            rows.append(dict(R=radius,observed_lo=lower,observed_hi=upper,ordinary_at_zero=self.base[idx],ordinary_finite=common,
                             any_spherical_residual_polar=0.,required_extra_lo=lower-common,required_extra_hi=upper-common,
                             effective_phi2_lo_kms2=(lower-common)/unit,effective_phi2_hi_kms2=(upper-common)/unit,
                             reference_wave_polar=self.wave0[idx],wave_polar=wave[idx],mts_finite=common+wave[idx]))
        return rows

def save_packet(name,state,mass):
    buffer=io.BytesIO();np.savez_compressed(buffer,state=state,mass=np.array(mass));put(name,buffer.getvalue())
