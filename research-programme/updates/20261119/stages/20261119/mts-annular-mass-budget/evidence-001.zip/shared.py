import os
for env_name in ("OPENBLAS_NUM_THREADS","OMP_NUM_THREADS","MKL_NUM_THREADS","BLIS_NUM_THREADS","NUMEXPR_NUM_THREADS"):
    os.environ[env_name]="1"
import csv
import io
import json
import hashlib
from pathlib import Path
import sys

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
IR=ROOT/"mts-eros-infrared-distance-20261119"
KERNEL=ROOT/"mts-compact-lens-kernel-20261119"
POP=ROOT/"mts-population-resolved-gravity-20261119"
HEIGHT_DIR=ROOT/"mts-inner-stellar-height-response-20261119"
CLUMP=ROOT/"mts-eros-clump-exposure-20261119"
PIN="c44696b1aef45965396849e345cdef65db7515a0074821febe5e94ca084dbe55"
def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def guard():
    for folder in (HERE,ROOT,IR,HEIGHT_DIR,KERNEL,POP):
        assert not (folder/"STOP-REQUESTED").exists(),folder
    assert digest(IR/"seal.json")==PIN
def put(name,raw):
    guard()
    path=HERE/name
    if path.is_file():assert path.read_bytes()==raw,name
    else:
        with path.open("xb") as handle:handle.write(raw)
def table(name,rows):
    buf=io.StringIO(newline="")
    writer=csv.DictWriter(buf,list(rows[0]),lineterminator="\n")
    writer.writeheader();writer.writerows(rows);put(name,buf.getvalue().encode())
def asjson(name,obj):
    put(name,(json.dumps(obj,indent=2,sort_keys=True,allow_nan=False)+"\n").encode())
def read(path):
    with path.open(encoding="utf-8",newline="") as handle:return list(csv.DictReader(handle))
sys.path.insert(0,str(KERNEL))
