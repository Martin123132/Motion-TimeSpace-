from shared import HERE,IR,KERNEL,HEIGHT_DIR,POP,CLUMP,PIN,read,table,asjson,digest,guard
from assess import TOL
from kernel import Lenses,Ray,CAP
import hashlib
import json
import sys
import numpy as np
import pandas as pd
sys.path.insert(0,str(CLUMP))
from read_survey import sky

def expect_digest(folder,names):
    manifest=json.loads((folder/"seal.json").read_bytes())["files"]
    for name in names:assert digest(folder/name)==manifest[name],name
    return len(names)

def ray_controls():
    main=pd.read_csv(HERE/"optical-order14.csv").set_index("id")
    stars=pd.read_csv(IR/"registered.csv.gz",usecols=["id","old_ra","old_dec"]).set_index("id")
    bounds=pd.read_csv(IR/"witness-parallaxes.csv.gz").set_index("id")
    ratio=-float(next(row["donor_per_unit"] for row in read(HERE/"independent-budget.csv") if row["family"]=="transfer"))
    ids=list(main.index[::251])+["cg6104l11414","cg6104l31652"]
    left=(1/bounds.pi_upper).reindex(main.index).fillna(0.)
    right=(1/bounds.pi_lower).reindex(main.index)
    for name in ("minimum_at_kpc","maximum_at_kpc"):
        within=main[(main[name]>left+1e-7)&(main[name]<right-1e-7)]
        if len(within):ids+=list(within.index[:4])
    lenses=Lenses();checked=[]
    for name in sorted(set(ids)):
        row=main.loc[name];star=stars.loc[name]
        ray=Ray(*sky(star.old_ra,star.old_dec))
        extra=list(ray.cylindrical(8.))
        start=left[name];end=right[name]
        def direct(source):
            if source==0:return 0.,0.,0.
            dist,weight=lenses.grid(ray,20,[*extra,min(source,24.)],24.)
            dens,cyl=lenses.density(ray,dist)
            lens=dens[:,0]
            pos=(cyl>=4)&(cyl<=7);neg=(cyl>7)&(cyl<=8)
            kernel=CAP*dist*weight*lens
            t=np.maximum(0.,1-dist/source)*kernel
            moment=(dist<source)*dist*kernel
            return t@pos-ratio*(t@neg),moment@pos-ratio*(moment@neg),t@pos+ratio*(t@neg)
        worst=0.;n=0
        for side,key in (("lo","minimum_at_kpc"),("hi","maximum_at_kpc")):
            pos=row[key];calc,moment,scale=direct(pos)
            err=abs(calc-row["transfer_"+side])/max(1e-24,scale)
            assert err<TOL,(name,side,err)
            worst=max(worst,err)
            if start+1e-7<pos<end-1e-7 and scale>1e-18:
                assert abs(moment)/(max(pos,1)*scale)<TOL
                n+=1
        for pos in np.unique(np.r_[start,end,np.clip(np.arange(.25,19.,.47),start,end)]):
            val,_,scale=direct(pos);extra_error=TOL*max(scale,1e-24)
            assert row.transfer_lo-extra_error<=val<=row.transfer_hi+extra_error
        checked.append(dict(id=name,extremum_worst_scaled_error=worst,interior_stationary_checked=n))
    assert sum(row["interior_stationary_checked"] for row in checked)>0
    table("independent-optical-controls.csv",checked)
    return checked

def run(level):
    guard()
    provenance={}
    for folder,files in [(IR,["registered.csv.gz","witness-parallaxes.csv.gz","all-foreground-crowding.csv","parallax-depth-order14.csv"]),
          (POP,["authors-surfm-remnants-260820.txt","population.py","authors-density-dtr-sn-260424.fits"]),
          (KERNEL,["dual_probe.py","kernel.py","fine-annulus.csv","medium-annulus.csv","fine-force-tangents.csv","medium-force-tangents.csv"]),
          (HEIGHT_DIR,[prefix+suffix for prefix in ("medium","fine") for suffix in ("-pooled-matched-state.npz","-SEGUE-frozen-forces.csv","-pooled-potential.npz")])]:
        provenance[folder.name]=expect_digest(folder,files)
    assert digest(KERNEL/"seal.json")==json.loads((CLUMP/"seal.json").read_bytes())["parent"]
    buf=(POP/"authors-surfm-remnants-260820.txt").read_bytes()
    assert hashlib.sha1(b"blob "+str(len(buf)).encode()+b"\0"+buf).hexdigest()=="0966ad278ccd4e722f280f0ae4d29c4926f7e091"
    resolution=pd.read_csv(HERE/("numerical-comparison-"+level+".csv"))
    latest=resolution[resolution["last"]==level]
    assert len(latest)==8 and latest.passed.all()
    bounds=pd.read_csv(HERE/"independent-budget.csv")
    assert len(bounds)==16 and (bounds[bounds.family=="transfer"].net_mass_change.abs()<.1).all()
    checks=pd.read_csv(HERE/"global-shape-check.csv")
    assert len(checks)==len(bounds) and checks.inside_mass.all() and checks.inside_radius.all()
    stat=pd.read_csv(HERE/("force-summary-"+level+".csv"))
    assert len(stat)==24
    states=pd.concat([pd.read_csv(HERE/f"{level}-{family}-states.csv") for family in ("added","transfer")])
    assert len(states)==12 and states.nonlinear_residual.max()<2e-12 and states.outer_defect.abs().max()<1e-8
    for family in ("added","transfer"):
        for model in ("ground","nfw"):
            series=stat[(stat.family==family)&(stat.model==model)].sort_values("amplitude")
            assert (np.diff(series.finite_mean)>0).all() and series.n_below_reported_one_width.min()==14
    optical=ray_controls();light=pd.read_csv(HERE/"pilot-finite-depth.csv")
    assert np.all(light.strictly_negative+light.strictly_positive+light.fixed_zero<=3760) and len(light)==16
    asjson("verification.json",dict(refined_basis=level,source_files_rehashed=provenance,
           worst_final_force_grid_scaled=float(latest.worst.max()),older_grid_failed=int((~resolution.passed).sum()),
           maximum_normalized_wave_residual=float(states.nonlinear_residual.max()),maximum_outer_defect=float(states.outer_defect.abs().max()),
           optical_crosschecks=len(optical),stationary_optical_crosschecks=sum(row["interior_stationary_checked"] for row in optical),
           independent_optical_worst_scaled=max(row["extremum_worst_scaled_error"] for row in optical)))
def seal():
    guard()
    assert all((HERE/name).is_file() for name in ("verification.json","RESULTS.md","REPLAY.md","NEXT.md","packet-check.json","wave-origin.csv","polar-resolution.csv"))
    assert not any(path.is_dir() for path in HERE.iterdir())
    asjson("seal.json",dict(parent=PIN,files={path.name:digest(path) for path in sorted(HERE.iterdir()) if path.name!="seal.json"}))
    print("Seal:",digest(HERE/"seal.json"))
if __name__=="__main__":
    if sys.argv[1]=="seal":seal()
    else:run(sys.argv[1])
