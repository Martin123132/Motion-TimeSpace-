from shared import guard
from dual_probe import np,grid,roots_legendre,ellipkm1,ellipe,legvander,Wave,quadrature,G,vertical,sigma

def sky_ring(profile,observer,zobs,level,bands):
    nr,nz=(10,20) if level=="medium" else (16,32)
    bounds=np.unique(np.clip(np.r_[bands[0],bands[1],profile.cuts,observer],*bands))
    pts,ws=roots_legendre(nr)
    unit=(1+pts)/2
    rad,weight=grid(bounds,nr)
    for idx,(left,right) in enumerate(zip(bounds[:-1],bounds[1:])):
        if observer in (left,right):
            rad[idx]=observer+(1 if left==observer else -1)*(right-left)*unit**3
            weight[idx]=1.5*(right-left)*unit**2*ws
    rad=rad.ravel()[:,None]
    weight=weight.ravel()[:,None]
    pts,ws=roots_legendre(nz)
    zcuts=np.unique(np.r_[-28.,-12.,-6.,-2.,-.6,-.15,0.,.15,.6,2.,6.,12.,28.,zobs])
    sep=abs(observer-rad)
    limits=np.arcsinh((zcuts-zobs)/sep)
    half=np.diff(limits,axis=1)/2
    param=(limits[:,:-1,None]+half[:,:,None]*(1+pts)).reshape(len(rad),-1)
    dz=sep*np.sinh(param)
    measure=(half[:,:,None]*ws).reshape(len(rad),-1)*sep*np.cosh(param)
    small=(observer-rad)**2+dz**2
    large=(observer+rad)**2+dz**2
    ratio=small/large
    ellk,elle=ellipkm1(ratio),ellipe(1-ratio)
    coeff=2*G*rad*weight*measure*vertical(profile,rad,abs(zobs+dz))*sigma(profile,rad[:,0])[:,None]/np.sqrt(large)
    return np.array([(coeff/observer*(ellk+((observer-rad)*(observer+rad)-dz**2)/small*elle)).sum(),
                     (2*coeff*dz/small*elle).sum()])


def source_field(profile,exp,level,bands):
    dx,nang,order,lmax=(.075,26,8,64) if level=="medium" else (.045,40,10,80)
    breaks=np.unique(np.clip(np.r_[bands[0],bands[1],profile.cuts],*bands))
    edges=np.unique(np.r_[np.arange(0,12.,dx),np.arange(12.,28.,.25),28.,32.,breaks])
    points,weights=quadrature(order)
    radii=edges[:-1,None]+np.diff(edges)[:,None]*points
    wr=np.diff(edges)[:,None]*weights
    modes=np.arange(0,lmax+1,2)
    moments=np.zeros((radii.size,len(modes)))
    flat=radii.ravel()
    angles,aw=roots_legendre(nang)
    for inner,outer in zip(breaks[:-1],breaks[1:]):
        idx=np.flatnonzero(flat>inner)
        rad=flat[idx,None]
        low=np.sqrt(np.maximum(0.,1-(outer/rad)**2))
        high=np.sqrt(1-(inner/rad)**2)
        half=(high-low)/2
        mu=low+half*(1+angles)
        cyl=rad*np.sqrt(1-mu**2)
        den=sigma(profile,cyl)*vertical(profile,cyl,rad*mu)
        for start in range(0,len(idx),100):
            sec=slice(start,start+100)
            pol=legvander(mu[sec],lmax)[...,::2]
            moments[idx[sec]]+=np.einsum("ij,ijk->ik",den[sec]*half[sec]*aw,pol)
    wave=Wave(edges,radii,wr,modes,moments)
    radius,weights=grid(breaks,12)
    mass=2*np.pi*np.sum(weights*radius*sigma(profile,radius))
    assert abs(wave.mass/mass-1)<2e-6,(wave.mass,mass)
    actual=exp.run.rad
    values=wave.spline(np.minimum(actual,edges[-1]))
    slope=wave.spline(np.minimum(actual,edges[-1]),1)
    outside=actual>edges[-1]
    values[outside]=wave.phi[-1]*(edges[-1]/actual[outside,None])**(modes+1)
    slope[outside]=-(modes+1)*values[outside]/actual[outside,None]
    proj=legvander(exp.system.mu,lmax)[:,::2].T
    return values@proj/exp.system.vel**2,actual[:,None]*(slope@proj)/exp.system.vel**2,mass,wave.mass
