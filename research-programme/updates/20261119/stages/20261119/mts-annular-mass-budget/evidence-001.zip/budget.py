from shared import HERE,POP,KERNEL,guard,table,read
from kernel import Lenses
from scipy.integrate import quad
from scipy.optimize import linprog
import numpy as np

def ring_mass(stars,lower,upper):
    return quad(lambda radius:2*np.pi*radius*float(stars.radial(radius)[0]),lower,upper,
                points=[knot for knot in stars.knots if lower<knot<upper],epsrel=3e-12)[0]

def run():
    guard()
    stars=Lenses().stars
    raw=np.loadtxt(POP/"authors-surfm-remnants-260820.txt",skiprows=1)
    radii,columns,errors=raw[:,:3].T
    assert len(radii)==17 and list(radii[(radii>4)&(radii<8)])==[4.5,5.5,6.5,7.5]
    actual=stars.radial(radii[(radii>4)&(radii<8)])[:,0]/1e6
    assert np.allclose(actual,stars.factors[0]*columns[(radii>4)&(radii<8)],rtol=1e-12)
    inner=ring_mass(stars,4.,7.);outer=ring_mass(stars,7.,8.)
    assert abs(inner/float(read(KERNEL/"fine-annulus.csv")[0]["mass"])-1)<2e-12
    result=[];knots=[]
    for family,donor in [("added",0.),("transfer",-inner/outer)]:
        shape=np.where((radii>4)&(radii<7),1.,np.where((radii>7)&(radii<8),donor,0.))
        for radius,column,error,slope in zip(radii,columns,errors,shape,strict=True):
            knots.append(dict(family=family,radius_kpc=radius,raw_living=column,raw_error=error,relative_error=error/column,multiplier_slope=slope))
        for width in (1,2):
            low=np.maximum(0.,1-width*errors/columns);high=1+width*errors/columns
            for calibration in ("fixed","free"):
                lower=np.r_[low,1.] if calibration=="fixed" else low
                upper=np.r_[high,1.] if calibration=="fixed" else high
                factor=np.r_[shape,0.] if calibration=="fixed" else shape
                dif=lower[None,:]*factor[:,None]-upper[:,None]*factor[None,:]
                rhs=upper[:,None]-lower[None,:]
                hardlo=max([-1/val for val in shape if val>0],default=-np.inf)
                hardhi=min([-1/val for val in shape if val<0],default=np.inf)
                amin=max(hardlo,np.max(rhs[dif<0]/dif[dif<0]))
                amax=min(hardhi,np.min(rhs[dif>0]/dif[dif>0]))
                assert amin<0<amax and np.all(rhs[dif==0]>=0)
                mat=np.vstack([np.column_stack((factor,-upper)),np.column_stack((-factor,lower))])
                bounds=np.r_[-np.ones(len(factor)),np.ones(len(factor))]
                for sign,amplitude in [(1,amin),(-1,amax)]:
                    fit=linprog([sign,0],A_ub=mat,b_ub=bounds,bounds=[(hardlo,None if np.isinf(hardhi) else hardhi),(0,None)],method="highs")
                    assert fit.success and abs(fit.x[0]-amplitude)<2e-12
                    norm=fit.x[1]
                    multipliers=1+amplitude*shape
                    assert np.all(multipliers>=0) and np.all(multipliers>=norm*low-1e-12) and np.all(multipliers<=norm*high+1e-12)
                    tight=radii[np.isclose(multipliers,norm*low,atol=1e-11,rtol=0)|np.isclose(multipliers,norm*high,atol=1e-11,rtol=0)]
                    result.append(dict(family=family,width=width,calibration=calibration,side="minus" if sign==1 else "plus",
                               amplitude=amplitude,donor_per_unit=donor,comparison_scale=norm,
                               active_radii_kpc=";".join(map(str,tight)),inner_base_mass=inner,outer_base_mass=outer,
                               inner_mass_change=amplitude*inner,donor_mass_change=amplitude*donor*outer,
                               net_mass_change=amplitude*(inner+donor*outer)))
    table("source-knots.csv",knots);table("independent-budget.csv",result)
if __name__=="__main__":run()
