from shared import HERE,IR,CLUMP,guard,read,table
from kernel import Lenses,Ray,CAP
from rings import vertical,sigma
import numpy as np
import pandas as pd
import sys
from scipy.special import roots_legendre
from scipy.optimize import brentq
sys.path.insert(0,str(CLUMP))
from read_survey import sky

def ray_response(lenses,lon,lat,pi_low,pi_high,order,ratio):
    ray=Ray(lon,lat)
    left=1/pi_high if np.isfinite(pi_high) else 0.
    right=1/pi_low if pi_low>0 else np.inf
    maximum=max(ray.cylindrical(8.))
    assert maximum>0 and left<=right
    edges=np.unique(np.clip(np.r_[0.,maximum,left,min(right,maximum),np.arange(0,maximum,.5),ray.tangent,
                                  -0.0208/ray.sinlat,*[item for radius in np.r_[lenses.radial_edges,8.] for item in ray.cylindrical(radius)]],0,maximum))
    nodes,weights=roots_legendre(order);nodes=(nodes+1)/2;weights=weights/2
    def integral(beg,end):
        delta=end-beg
        dist=beg[...,None]+delta[...,None]*nodes
        xpos,ypos,zpos=ray.xyz(dist);radii=np.hypot(xpos,ypos)
        measure=CAP*(delta[...,None]*weights)*dist*sigma(lenses.profile,radii)*vertical(lenses.profile,radii,abs(zpos))
        values=[]
        for zone in (((radii>=4)&(radii<7)),((radii>=7)&(radii<=8))):
            part=measure*zone
            values.append(np.stack([part.sum(axis=-1),(part*dist).sum(axis=-1)],axis=-1))
        return np.stack(values,axis=-2)
    intervals=integral(edges[:-1],edges[1:])
    cumulative=np.concatenate([np.zeros((1,2,2)),intervals.cumsum(axis=0)])
    def value_at(pos):
        if pos>=maximum:return cumulative[-1]
        idx=np.searchsorted(edges,pos,side="right")-1
        if pos==edges[idx]:return cumulative[idx]
        return cumulative[idx]+integral(edges[idx],np.array(pos))
    def tau(pos):
        if pos==0:return np.zeros(2)
        values=value_at(pos)
        return values[:,0]-values[:,1]/pos
    lo,hi=tau(left),tau(right)
    assert min(lo)>=-2e-22 and np.all(hi>=lo-2e-22)
    signed=np.array([1.,-ratio]);mom=cumulative[:,:,1]@signed
    candidates=[(float(lo@signed),left),(float(hi@signed),right)]
    for idx in np.flatnonzero(mom[:-1]*mom[1:]<0):
        if edges[idx+1]<=left or edges[idx]>=right:continue
        root=brentq(lambda pos:value_at(pos)[:,1]@signed,edges[idx],edges[idx+1],xtol=5e-13)
        if left<root<right:candidates.append((float(tau(root)@signed),root))
    for idx in np.flatnonzero((mom==0)&(edges>left)&(edges<right)):
        if idx==0 or idx==len(edges)-1 or mom[idx-1]!=0 or mom[idx+1]!=0:
            candidates.append((float(tau(edges[idx])@signed),edges[idx]))
    low,lower_position=min(candidates,key=lambda pair:pair[0])
    high,upper_position=max(candidates,key=lambda pair:pair[0])
    separate_lo=lo[0]-ratio*hi[1];separate_hi=hi[0]-ratio*lo[1]
    assert low>=separate_lo-1e-20 and high<=separate_hi+1e-20
    for pos in np.unique(np.clip(edges,left,right)):
        direct=tau(pos)@signed
        assert low-1e-19<=direct<=high+1e-19
    return dict(add_lo=lo[0],add_hi=hi[0],donor_lo=lo[1],donor_hi=hi[1],transfer_lo=low,transfer_hi=high,
                minimum_at_kpc=lower_position,maximum_at_kpc=upper_position,
                independent_zone_lo=separate_lo,independent_zone_hi=separate_hi)

def run(order):
    guard()
    stars=pd.read_csv(IR/"registered.csv.gz",usecols=["id","old_ra","old_dec","group"])
    bounds=pd.read_csv(IR/"witness-parallaxes.csv.gz")
    src=stars.loc[stars.group.isin(["drawn_only","common"])].merge(bounds,on="id",validate="one_to_one")
    assert len(src)==3760
    ratio=-float(next(row for row in read(HERE/"independent-budget.csv") if row["family"]=="transfer")["donor_per_unit"])
    lenses=Lenses();records=[]
    for idx,row in enumerate(src.itertuples()):
        if idx%400==0:guard()
        calc=ray_response(lenses,*sky(row.old_ra,row.old_dec),row.pi_lower,row.pi_upper,order,ratio)
        records.append(dict(id=row.id,group=row.group,**calc))
    table(f"optical-order{order}.csv",records)
    print("Completed",order,len(records),"individual sightlines",flush=True)
if __name__=="__main__":run(int(sys.argv[1]))
