import sys
from paired import Paired,prep_lock
from quarter_evolve import HERE,LOCATIONS,TIMES,np,bridge,read_clocks,holds,digest


class ReceiverGauge(Paired):
    def prim(self,values,odd=False):
        result=super().prim(values,odd)
        if self.use_outer and odd:
            vals=values[3]
            dx=1/self.mesh
            index=int(6.5*self.mesh)
            half=dx*(self.weights@vals[index-2:index+4])
            ext=np.r_[-vals[:2][::-1],vals,vals[-2:][::-1]]
            increments=dx/1440*(11*(ext[:-5]+ext[5:])-93*(ext[1:-4]+ext[4:-1])+802*(ext[2:-3]+ext[3:-2]))
            result[3,index:]=half+np.r_[0.,np.cumsum(increments[index:])]
            result[3,:index]=half-np.cumsum(increments[:index][::-1])[::-1]
        return result


def replay(label):
    assert label in ("receiver","halfstep")
    prep_lock("pair-freeze")
    dest=HERE/(label+"-finite.npz")
    if dest.exists() or dest.with_suffix(".partial").exists():
        raise FileExistsError(dest)
    mesh=256
    lab=(ReceiverGauge if label=="receiver" else Paired)(mesh,"finite")
    state=lab.launch()
    divisor=2 if label=="halfstep" else 1
    times=np.arange((len(TIMES)-1)*divisor+1)*(.01/divisor)
    subs=int(np.ceil(mesh*.01/.42))
    dt=.01/(divisor*subs)
    masks={site:(lab.x>=lo-.09)&(lab.x<=lo+.59) for site,lo in LOCATIONS.items()}
    strips={site:[] for site in LOCATIONS}
    dense=[]
    for idx,time in enumerate(times):
        fields=lab.dynamics(state,time,True)
        mass,press,disp,vel,nu=fields[:5]
        lapse=lab.ar.exponential(lab.nu+nu)
        opt=lab.inv(lab.mul(lapse,lab.sqrt(lab.factor-2*mass/lab.x)))-lab.one
        for site,mask in masks.items():
            strips[site].append(np.stack((opt[:,mask],(lapse-lab.one)[:,mask])))
        if idx%divisor==0:
            dense.append(np.stack((mass[3],press[3],nu[3],fields[5][3],fields[6][3],state[0,3],state[1,3]))[:,::16])
        if idx%50==0:
            holds()
        if idx+1<len(times):
            for sub in range(subs):
                start=time+dt*sub
                first=lab.dynamics(state,start)
                second=lab.dynamics(state+dt*first/2,start+dt/2)
                third=lab.dynamics(state+dt*second/2,start+dt/2)
                fourth=lab.dynamics(state+dt*third,start+dt)
                state+=dt/6*(first+2*second+2*third+fourth)
    out=dict(diag=np.array(dense),space=lab.x[::16],t=TIMES,receipt=np.bytes_(digest(HERE/"pair-freeze.json")),
             program=np.bytes_(digest(HERE/"gauge_replay.py")))
    for site,mask in masks.items():
        bank=np.array(strips.pop(site))
        out[site]=read_clocks(times,lab.x[mask],bank,LOCATIONS[site],lab.ar,64,3)
    assert all(np.isfinite(value).all() for value in out.values() if value.dtype.kind in "fic")
    bridge.archive(dest,**out)
    print(dest.name,flush=True)


if __name__=="__main__":
    replay(sys.argv[1])
