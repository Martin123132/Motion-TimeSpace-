import csv
import sys
from functools import lru_cache
from quarter_evolve import HERE,PARENT,file,PREPS,MESHES,SHELLS,TIMES,EMISSIONS,LOCATIONS,bridge,np,TOL,SEC,c,digest
from halo_mean import Profile,peak
from scipy.interpolate import make_interp_spline
from scipy.integrate import cumulative_simpson
from scipy.optimize import brentq

YEAR=365.25*86400
CHANNELS=("one_frequency","echo_frequency","one_delay","echo_delay")


def table(name,items,create):
    rows=list(items)
    path=HERE/name
    if create:
        with path.open("x",encoding="utf8",newline="") as stream:
            writer=csv.DictWriter(stream,fieldnames=rows[0])
            writer.writeheader()
            writer.writerows(rows)
    with path.open(encoding="utf8",newline="") as src:
        assert list(csv.DictReader(src))==[{key:str(value) for key,value in row.items()} for row in rows],name
    return rows


@lru_cache(None)
def raw(mode,prep,mesh):
    record=bridge.read(file(mode,prep,mesh))
    assert record["receipt"].item().decode()==digest(HERE/("frozen.json" if mode=="finite" else "inputs.json"))
    assert np.array_equal(record["t"],TIMES) and np.array_equal(record["shells"],SHELLS) and np.array_equal(record["emissions"],EMISSIONS)
    assert record["diag"].shape==(len(TIMES),16,4,len(SHELLS)) and not record["diag"][:,:11,:2].any()
    return record


def component(data,axis):
    return data[2] if axis=="isolated" else (data[3] if axis=="mixed" else data[2]+data[3])


def signals(mode,prep,mesh,idx,axis):
    return component(raw(mode,prep,mesh)["diag"][:,:,:,idx].transpose(2,1,0),axis)


def motion():
    for prep in PREPS:
        for idx,radius in enumerate(SHELLS):
            for axis in ("isolated","supported","mixed"):
                fine,pred,small,alt=[signals(mode,prep,mesh,idx,axis) for mode,mesh in (
                    ("finite",256),("forecast",256),("finite",128),("forecast",128))]
                def budget(col):
                    return (peak(fine[col]-pred[col])+peak(fine[col]-small[col])+peak(pred[col]-alt[col]))/peak(fine[col])
                dm=fine[0]-fine[0,0]
                flux=-(fine[5]+fine[6])
                integral=cumulative_simpson(flux,x=TIMES,initial=0.)
                half=cumulative_simpson(flux[::2],x=TIMES[::2],initial=0.)
                balance=(peak(dm-integral)+peak(integral[::2]-half))/peak(dm)
                constraint=radius*peak(fine[10])/peak(fine[0])
                row=dict(prep=prep,r=radius,axis=axis,mass=budget(0),pressure=budget(1),displacement=budget(2),
                         speed=budget(3),scalar_flux=budget(5),mass_flux_integral=balance,spatial_constraint=constraint)
                row["passes"]=max(list(row.values())[3:])<=TOL
                yield row


@lru_cache(None)
def mean_pressure_grad():
    radius=np.array(SHELLS)
    def derivative(step):
        field=Profile(1)
        return sum(factor*field.data(radius+offset*step)["press"] for offset,factor in
                   ((-2,1),(-1,-8),(1,8),(2,-1)))/(12*step)
    return derivative(.002),derivative(.004)


def marker(mode,prep,mesh,idx,stride=1):
    packet=raw(mode,prep,mesh)
    cols=packet["diag"][::stride,:,:,idx]
    part=cols[:,:,2]+cols[:,:,3]
    epoch=TIMES[::stride]
    period=2*np.pi/packet["sigma"][:2,idx].sum()
    pos=part[:,2]/(1-part[:,11])
    vel=part[:,3]+part[:,12]*pos
    grad,other=mean_pressure_grad()
    pressure=part[:,1]+pos*(grad[idx]+part[:,13])
    clock=cols[:,14].sum(axis=1)+cols[:,15].sum(axis=1)*pos
    spl=lambda values:make_interp_spline(epoch,values,k=5)
    press_curve=spl(pressure-pressure[0])
    root=brentq(press_curve,period*.90,period*1.10,xtol=8e-15)
    assert press_curve.derivative()(root)*press_curve.derivative()(0)>0.
    orbit=spl(clock).antiderivative()
    baseline_clock=cols[0,14,:2].sum()
    proper_shift=spl(part[:,14]+cols[:,15].sum(axis=1)*pos).antiderivative()
    return np.array([period,root,(orbit(root)-orbit(0))*SEC/YEAR,
            spl(pos)(period)*SEC*c,(spl(vel)(period)-vel[0])*c,
            spl(pos)(root)*SEC*c,(spl(vel)(root)-vel[0])*c,peak(pos)*SEC*c,peak(vel)*c,
            vel[0]*c,peak(part[:,2]-pos)*SEC*c,peak(pressure)*1.,peak(pos)*abs(grad[idx]-other[idx])/peak(pressure),
            (proper_shift(root)-proper_shift(0))*SEC,baseline_clock])


def orbit():
    with (PARENT/"quarter-forecast.csv").open(newline="") as stream:
        frozen={(float(row["radius"]),row["prep"]):row for row in csv.DictReader(stream)}
    for prep in PREPS:
        for idx,radius in enumerate(SHELLS):
            fine=marker("finite",prep,256,idx)
            small=marker("finite",prep,128,idx)
            alt=marker("finite",prep,256,idx,2)
            predicted=frozen[radius,prep]
            oldpos=float(predicted["predicted_cycle_displacement_m"])
            oldvel=float(predicted["predicted_velocity_increment_m_s"])
            oldlaunch=float(predicted["launch_dr_dt_m_s"])
            def budget(col,target,scale):
                return (abs(fine[col]-target)+abs(fine[col]-small[col])+abs(fine[col]-alt[col]))/scale
            poserr=budget(3,oldpos,fine[7])
            velerr=budget(4,oldvel,fine[8])
            yield dict(prep=prep,r=radius,material=radius<5,proper_period_yr=fine[2],
                       initial_speed_m_s=fine[9],launch_error_over_peak=abs(fine[9]-oldlaunch)/fine[8],
                       frozen_disp_m=oldpos,finite_disp_m=fine[3],peak_excursion_m=fine[7],
                       disp_error_over_excursion=poserr,disp_sampling_error_m=abs(fine[3]-small[3])+abs(fine[3]-alt[3]),
                       frozen_net_speed_m_s=oldvel,finite_net_speed_m_s=fine[4],peak_speed_m_s=fine[8],
                       speed_error_over_peak=velerr,return_shift_s=(fine[1]-fine[0])*SEC,
                       pressure_return_disp_m=fine[5],pressure_return_net_speed_m_s=fine[6],max_label_shift_correction_m=fine[10],
                       orbit_proper_excess_at_return_s=fine[13],pressure_grad_check=fine[12],
                       return_disp_error_over_excursion=budget(5,oldpos,fine[7]),
                       passes=max(poserr,velerr,abs(fine[9]-oldlaunch)/fine[8])<TOL)


def clocks():
    for label in (*PREPS,"periodic_minus_rest"):
        for site in LOCATIONS:
            for axis in ("isolated","supported","mixed"):
                for col,name in enumerate(CHANNELS):
                    def wave(mode,mesh=256,rule="64_3"):
                        def value(prep):
                            val=component(raw(mode,prep,mesh)[site+"_"+rule][col],axis)
                            return val-val[0]
                        if label=="periodic_minus_rest":
                            if axis=="supported":
                                def diff(prep):
                                    val=raw(mode,prep,mesh)[site+"_"+rule][col]
                                    return val[:,1:]-val[:,:1]
                                comp=diff(PREPS[1])-diff(PREPS[0])
                                return np.r_[0.,component(comp,axis)]
                            return value(PREPS[1])-value(PREPS[0])
                        return value(label)
                    fine=wave("finite")
                    pred=wave("forecast")
                    size=peak(fine)
                    mismatch=peak(fine-pred)
                    grid=peak(fine-wave("finite",128))+peak(pred-wave("forecast",128))
                    ray=sum(peak(wave(mode)-wave(mode,256,key)) for mode in ("finite","forecast") for key in ("32_3","64_2"))
                    zero=size==0
                    ratio=(mismatch+grid+ray)/size if not zero else (0. if mismatch+grid+ray==0 else np.inf)
                    idx=np.argmax(abs(fine))
                    yield dict(preparation=label,site=site,axis=axis,channel=name,peak_time=EMISSIONS[idx],signed_peak=fine[idx],
                               peak_in_seconds=fine[idx]*SEC if col>=2 else "",exact_zero_control=zero,
                               forecast_absolute=mismatch,grid_absolute=grid,ray_absolute=ray,total_over_own_signal=ratio,passes=ratio<=TOL)


if __name__=="__main__":
    for name,method in (("motion",motion),("orbit",orbit),("clocks",clocks)):
        rows=table(name+".csv",method(),sys.argv[1:] == ["create"])
        print(name,len(rows),sum(row["passes"] for row in rows))
