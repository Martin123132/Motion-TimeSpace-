import sys
import json
from quarter_evolve import HERE,PARENT,OUTER,PREPS,MESHES,PARENT_HASH,OUTER_HASH,lock,digest,bridge,np,TOL
sys.path.insert(0,str(HERE))
from read_quarter import table,motion,orbit,clocks,raw
from paired import prep_lock
from clock_identity import estimates,paired
from gauge_checks import results
from preparation import switches,transport
from shell_gas import comparisons,geometry,hot_mass
from ordinary_budget import analysis


def verify():
    lock("frozen")
    prep_lock("pair-freeze")
    ancestry={}
    for folder,signature in ((PARENT,PARENT_HASH),(OUTER,OUTER_HASH)):
        assert digest(folder/"seal.json")==signature
        data=json.loads((folder/"seal.json").read_bytes())
        assert all(digest(folder/name)==value for name,value in data["files"].items())
        assert all(digest(HERE.parent/name)==value for name,value in data.get("inputs",{}).items())
        ancestry[folder.name]=signature
    for mesh in MESHES:
        for prep in PREPS:
            for mode in ("finite","forecast"):
                data=raw(mode,prep,mesh)
                assert all(np.isfinite(val).all() for val in data.values() if val.dtype.kind in "fic")
                assert data["checks"][:,1:3].max()<TOL
                if mode=="finite":
                    assert data["checks"][:,3].max()<TOL*data["checks"][:,4].max()
                    assert np.max(abs(data["diag"][0,5,2]))>0
                    if prep=="periodic_velocity":
                        assert np.max(abs(data["diag"][0,6,3]))>0
                    else:
                        assert not data["diag"][0,6].any()
                    assert not data["diag"][0,2].any()
                assert paired(mode,mesh)["diag"].shape[1:3]==(8,4)
        first,second=[raw("finite",prep,mesh) for prep in PREPS]
        for site in ("inner","outer","middle"):
            assert np.array_equal(first[site+"_64_3"][:,2],second[site+"_64_3"][:,2])
    counts={}
    for name,fn,size in (("motion",motion,36),("orbit",orbit,12),("clocks",clocks,108),
                        ("paired-clock-identity",estimates,12),("gauge-checks",results,12),
                        ("free-action",transport,12),("retarded-preparation",switches,6),
                        ("gas-geometric-controls",geometry,15),("gas-columns",comparisons,30),
                        ("gas-xray",hot_mass,2),("ordinary-apertures",analysis,24)):
        rows=table(name+".csv",fn(),False)
        assert len(rows)==size
        counts[name+".csv"]=size
        if name=="clocks":
            misses=[row for row in rows if not row["passes"]]
            assert len(misses)==12 and all(row["preparation"]=="periodic_minus_rest" for row in misses)
        elif name=="paired-clock-identity":
            assert all(row["unchanged_rest_waveform_over_total"]<TOL for row in rows)
            assert {row["site"] for row in rows if row["leading_exact_zero"]}=={"outer"}
        elif name=="gauge-checks":
            assert {(row["site"],row["channel"]) for row in rows if not row["passes"]}=={("inner","echo_frequency"),("middle","echo_frequency")}
        elif name=="orbit":
            assert all(row["passes"] and row["return_disp_error_over_excursion"]<TOL and row["pressure_grad_check"]<TOL for row in rows)
        else:
            assert all(row.get("passes",True) for row in rows),name
    assert {path.name for path in HERE.glob("*.csv")}==set(counts)
    assert all(path.is_file() and path.suffix not in (".tmp",".partial",".pyc") for path in HERE.iterdir())
    return dict(ancestors=ancestry,rows=counts,files={p.name:digest(p) for p in sorted(HERE.iterdir()) if p.name!="seal.json"})


if __name__=="__main__":
    report=verify()
    path=HERE/"seal.json"
    if sys.argv[1:]==["seal"]:
        with path.open("x",encoding="utf8") as out:
            json.dump(report,out,indent=2,sort_keys=True)
    assert report==json.loads(path.read_bytes())
    print("VERIFIED",len(report["files"]),sum(report["rows"].values()),digest(path))
