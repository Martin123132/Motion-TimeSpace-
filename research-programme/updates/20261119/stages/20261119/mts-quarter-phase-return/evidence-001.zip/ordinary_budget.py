import csv
import sys
from read_quarter import table
from quarter_evolve import OUTER


def components(radius,high):
    diskstars=7.22e10 if high else 6.08e10
    halostars=1.8e9 if high else 1.4e9
    cold=1.4*(1.05e10+.85e9) if high else 1.4*8.e9
    if radius==50.:
        hot=4.1e9 if high else 3.8e9
    elif radius==100.:
        hot=5.2e10 if high else 4.3e10
    else:
        raise ValueError(radius)
    return diskstars,halostars,cold,hot


def analysis():
    with (OUTER/"tracer-comparison.csv").open(newline="") as stream:
        targets=list(csv.DictReader(stream))
    for row in targets:
        if row["speed_case"] not in ("central_cap","plus3_cap"):
            continue
        radius=float(row["aperture_kpc"])
        for high in (False,True):
            stars,halo,cold,hot=components(radius,high)
            accounted=stars+halo+cold+hot
            estimate=float(row["total"])*1e11
            low=estimate-1e11*(float(row["lower_error"])+float(row["separately_reported_systematic"] or 0))
            wave=float(row["wave_upper"])*1e11
            yield dict(tracer=row["source"],rad_kpc=radius,inner_speed=row["speed_case"],
                       ordinary_scenario="generous" if high else "central",
                       stars_disk_bulge=stars,stars_halo=halo,neutral_disk_allowance=cold,hot_corona_allowance=hot,
                       maximum_radius_used_for_hot_kpc=250 if radius==100 else 50,accounted_ordinary_msun=accounted,
                       deficit_on_tracer_central_msun=max(0.,estimate-wave-accounted),
                       deficit_on_tracer_lower_msun=max(0.,low-wave-accounted),total_minus_wave_minus_ordinary=estimate-wave-accounted,
                       interpretation="listed components; not a total baryon exclusion")


if __name__=="__main__":
    rows=table("ordinary-apertures.csv",analysis(),sys.argv[1:]==["create"])
    print(len(rows))
