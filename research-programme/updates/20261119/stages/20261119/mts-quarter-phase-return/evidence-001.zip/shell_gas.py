import csv
from math import pi
from scipy.constants import parsec, proton_mass
from read_quarter import table
from quarter_evolve import OUTER, np, TOL
from bound_state import MSUN

INNER,EDGE,SUN=50.,100.,np.hypot(8.275,.025)
PC=1000*parsec
COLUMNS=(("M81_total_rounded_up",88.,"measured_total_upper"),
         ("M81_Kirsten_upper",42.,"foreground_decomposition"),
         ("DSA_total_rounded_up",111.,"measured_total_upper"),
         ("DSA_Ravi_pulsar_A",28.7,"foreground_decomposition"),
         ("DSA_Ravi_pulsar_B",47.3,"foreground_decomposition"))


def required():
    with (OUTER/"shell-envelope.csv").open(newline="") as src:
        by_tag={row["speed_case"]:row for row in csv.DictReader(src)}
    return float(by_tag["central_cap"]["minimum_other_shell_at_Gibbons14_central_msun"])


def coefficients(mu_e):
    unit=4*pi*PC**2*parsec*1e6*proton_mass*mu_e/MSUN
    return dict(any_radial=unit*EDGE**2,monotone_shell_only=unit*(EDGE**3-INNER**3)/(3*(EDGE-INNER)),
                monotone_from_sun=unit*(EDGE**3-INNER**3)/(3*(EDGE-SUN)))


def geometry():
    unit=4*pi*PC**2*parsec*1e6*proton_mass/MSUN
    for label,assumed in coefficients(1.).items():
        for angle in (0.,30.,90.,135.,180.):
            cosine=np.cos(np.deg2rad(angle))
            impact2=SUN**2*(1-cosine*cosine)
            def outside(rad):
                return np.sqrt(rad**2-impact2)-SUN*cosine
            if label=="any_radial":
                weights=[unit*EDGE**2*np.sqrt(1-impact2/EDGE**2)]
            else:
                grid=np.r_[np.linspace(INNER+1e-4,EDGE,1000),np.linspace(EDGE+.01,250.,300)]
                stop=np.minimum(EDGE,grid)
                distance=outside(grid) if label=="monotone_from_sun" else outside(grid)-outside(INNER)
                weights=unit*(stop**3-INNER**3)/(3*distance)
            assert max(weights)<=assumed*(1+1e-12) and (angle!=0. or abs(max(weights)/assumed-1)<1e-10)
            yield dict(model=label,angle_from_outward_deg=angle,maximum_mass_per_dm=max(weights),
                       direction_independent_cap=assumed,passes=max(weights)<=assumed*(1+1e-12))


def comparisons():
    demand=required()
    for source,dm,status in COLUMNS:
        for hydrogen in (.70,.75):
            mu_e=2/(1+hydrogen)
            for label,factor in coefficients(mu_e).items():
                allowed=factor*dm
                yield dict(source=source,input_status=status,dm_pc_cm3=dm,H_mass_fraction=hydrogen,mu_e=mu_e,assumptions=label,
                           shell_50_100_ceiling_msun=allowed,min_DM_to_fill_central_requirement=demand/factor,
                           other_still_required_at_central_msun=max(0.,demand-allowed),
                           shell_allowed_by_this_inequality=allowed>=demand)


def hot_mass():
    for name,inner,outer in (("O_VIII_central",3.8e9,4.3e10),("O_VIII_marginal_extremes",3.5e9,5.2e10)):
        cap=outer-inner
        yield dict(source=name,inner_radius_kpc=50.,outer_radius_kpc=250.,reported_mass50_msun=inner,reported_mass250_msun=outer,
                   maximum_mass_in_50_100_msun=cap,remaining_central_requirement_msun=max(0.,required()-cap))


if __name__=="__main__":
    import sys
    for name,method in (("gas-geometric-controls",geometry),("gas-columns",comparisons),("gas-xray",hot_mass)):
        rows=table(name+".csv",method(),sys.argv[1:]==["create"])
        print(name,len(rows))
