import sys
import os
import json
from pathlib import Path
for key in ("OMP_NUM_THREADS","OPENBLAS_NUM_THREADS","MKL_NUM_THREADS","NUMEXPR_NUM_THREADS"):
    os.environ[key]="1"
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
PARENT=HERE.parent/"mts-bound-halo-proper-clocks-20261119"
OUTER=HERE.parent/"mts-halo-outer-mass-20261119"
sys.path.insert(0,str(PARENT))
from bound_cycle import Laboratory, TIMES, SHELLS, LOCATIONS, EMISSIONS, read_clocks, base
from halo_mean import np, TOL, SEC, c, bridge, guard, peak
from scipy.interpolate import make_interp_spline
from math import sqrt

PREPS=("radial_rest","periodic_velocity")
MESHES=(128,256)
PARENT_HASH="730dfa7dc7d9e8663b6387d798e493097d37cd220d0b651c20d539bbfdef8da3"
OUTER_HASH="80d324ba5c2210d2c42527178a604ec9f60a3ad636243c11cf999bd754248f37"


def holds():
    guard()
    if (HERE/"STOP-REQUESTED").exists():
        raise SystemExit("owner hold")


def digest(path):
    return bridge.sha(path)


def file(mode,prep,mesh):
    return HERE/f"{mode}-{prep}-{mesh}.npz"


def lock(kind,create=False):
    holds()
    assert digest(PARENT/"seal.json")==PARENT_HASH and digest(OUTER/"seal.json")==OUTER_HASH
    inputs=[HERE/"PROTOCOL.md",HERE/"quarter_evolve.py",PARENT/"quarter-forecast.csv",PARENT/"bound_cycle.py",
            PARENT/"mean-0.npz",PARENT/"mean-1.npz",PARENT/"seal.json",OUTER/"seal.json"]
    if kind=="frozen":
        lock("inputs")
        inputs=[HERE/"inputs.json",*[file("forecast",prep,mesh) for prep in PREPS for mesh in MESHES]]
    sources={str(item.relative_to(HERE.parent)).replace(chr(92),"/"):digest(item) for item in inputs}
    record=HERE/(kind+".json")
    if create:
        with record.open("x",encoding="utf8") as stream:
            json.dump(sources,stream,indent=2,sort_keys=True)
    assert json.loads(record.read_bytes())==sources


class Quarter(Laboratory):
    def __init__(self,mesh,mode,prep):
        super().__init__(mesh,mode,"turn")
        assert prep in PREPS and self.dust_test
        self.prep=prep
        self.sigma=2*self.omega
        self.needed=self.mul(self.drive,self.mul(self.sigma,self.inv(self.mul(self.sigma,self.sigma)-self.kn)))
        self.canonical=self.lift(self.mul(self.needed,self.mul(self.gamma,self.inv(self.mul(self.lapse,self.factor)))))

    def carrier(self,time):
        co,si=self.trig(time)
        double_cos,double_sin=self.trig(2*time)
        return (co-si)/sqrt(2.),(co+si)/sqrt(2.),-double_sin,double_cos

    def launch(self):
        mul,xx=self.mul,self.x
        zero=0*self.one
        mass=zero.copy()
        mom=self.canonical.copy() if self.prep=="periodic_velocity" else zero.copy()
        psq=mul(mom,mom)
        co,si,_,_=self.carrier(0.)
        grad=mul(self.slope,co)
        for iteration in range(12):
            df=-2*mass/xx
            fac=self.factor+df
            root=self.sqrt(fac)
            base_root=self.sqrt(self.factor)
            sumroot=root+base_root
            fp2=mul(fac,psq)
            gamma=self.sqrt(self.one+self.lam+fp2)
            dust=mul(self.b,mul(df,mul(self.gamma,self.inv(sumroot)))+mul(root,mul(fp2,self.inv(gamma+self.gamma))))
            changed=self.prim(xx**2*(dust+self.z/2*mul(df,mul(grad,grad))))
            if iteration>=2 and np.all(np.max(abs(changed-mass),axis=1)<=1e-13*np.maximum(np.max(abs(changed),axis=1),1e-285)):
                mass=changed
                break
            mass=changed
        else:
            raise ArithmeticError("launch Hamiltonian constraint")
        df=-2*mass/xx
        root=self.sqrt(self.factor+df)
        base_root=self.sqrt(self.factor)
        recip_delta=-mul(df,self.inv(mul(mul(root,base_root),root+base_root)))
        delta_can=mul(-si,mul(self.amp,mul(self.wratio,recip_delta)))
        return np.stack((zero,delta_can,mass,mom,zero,zero,zero))

    def forecast(self,time):
        mul,xx=self.mul,self.x
        co,si=self.trig(2*time)
        spring2=mul(self.kn,self.kn)
        sinc=time*(self.one-self.kn*time**2/6+spring2*time**4/120)
        cosine=self.one-self.kn*time**2/2+spring2*time**4/24
        mismatch=-self.needed if self.prep=="radial_rest" else 0*self.needed
        disp=self.lift(mul(mul(self.needed,self.inv(self.sigma)),si)+mul(mismatch,sinc))
        vel=self.lift(mul(self.needed,co)+mul(mismatch,cosine))
        mass=-self.lift(mul(self.eta,si))-mul(self.bprime,disp)
        press=-self.lift(mul(self.press,si))
        dnu=self.prim(mul(self.ifac,mul(self.gfactor,mass)/xx**2+xx*press),True)
        js=self.lift(mul(self.wave,mul(self.jamp,co)))
        jb=mul(self.bprime/xx**2,vel)
        force=-self.lift(mul(self.drive,si))-mul(self.kn,disp)
        count=-self.diff(xx**2*mul(self.b,disp),True)/xx**2
        return mass,press,disp,vel,dnu,js,jb,force,count,-mul(self.angprime,disp),0*self.one


def integrate(mode,prep,mesh):
    finite=mode=="finite"
    assert mode in ("finite","forecast") and mesh in MESHES
    kind="frozen" if finite else "inputs"
    lock(kind)
    dest=file(mode,prep,mesh)
    if dest.exists() or dest.with_suffix(".partial").exists():
        raise FileExistsError(dest)
    lab=Quarter(mesh,mode,prep)
    xx,ar=lab.x,lab.ar
    mid=np.searchsorted(xx,SHELLS)
    def quart(value):
        return (9*(value[...,mid]+value[...,mid-1])-(value[...,mid+1]+value[...,mid-2]))/16
    masks={site:(xx>=lo-.09)&(xx<=lo+.59) for site,lo in LOCATIONS.items()}
    strips={site:[] for site in LOCATIONS}
    diag,checks=[],[]
    state=lab.launch() if finite else None
    steps=int(np.ceil(mesh*.01/.42))
    dt=.01/steps
    for tick,time in enumerate(TIMES):
        mass,press,disp,vel,dnu,js,jb,force,count,ang,con=lab.dynamics(state,time,True) if finite else lab.forecast(time)
        fac=lab.factor-2*mass/xx
        lapse=ar.exponential(lab.nu+dnu)
        kinetic=lab.mul(fac,lab.mul(state[3],state[3])) if finite else 0*lab.one
        gamma=lab.sqrt(lab.one+lab.lam+ang+kinetic)
        proper=lab.mul(lapse,lab.inv(gamma))
        opt=lab.inv(lab.mul(lapse,lab.sqrt(fac)))-lab.one
        for site,mask in masks.items():
            strips[site].append(np.stack((opt[:,mask],(lapse-lab.one)[:,mask])))
        values=quart(np.stack((mass,press,disp,vel,dnu,xx**2*js,xx**2*jb,force,count,ang,con,
                    lab.diff(disp,True),lab.diff(vel,True),lab.diff(press),proper,lab.diff(proper))))
        assert not values[:11,:2].any()
        diag.append(values)
        if tick%25==0:
            holds()
            area=xx**2*count[3]
            mask=(xx>.15)&(xx<4.95)
            delta_j=ang+lab.mul(lab.angprime,disp)
            checks.append([time,abs(sum(area))/max(sum(abs(area)),1e-285),peak(lab.diff(disp,True)),
                           peak(delta_j[3,mask]),peak(ang[3,mask])])
        if finite and tick<len(TIMES)-1:
            for sub in range(steps):
                start=time+dt*sub
                first=lab.dynamics(state,start)
                second=lab.dynamics(state+dt*first/2,start+dt/2)
                third=lab.dynamics(state+dt*second/2,start+dt/2)
                fourth=lab.dynamics(state+dt*third,start+dt)
                state+=dt/6*(first+2*second+2*third+fourth)
    out=dict(diag=np.array(diag),checks=np.array(checks),shells=SHELLS,t=TIMES,emissions=EMISSIONS,
             sigma=make_interp_spline(xx,lab.sigma,k=5,axis=1)(SHELLS),receipt=np.bytes_(digest(HERE/(kind+".json"))))
    for site,mask in masks.items():
        bank=np.array(strips.pop(site))
        for panels,degree in ((32,3),(64,3),(64,2)):
            out[f"{site}_{panels}_{degree}"]=read_clocks(TIMES,xx[mask],bank,LOCATIONS[site],ar,panels,degree)
    assert all(np.isfinite(val).all() for val in out.values() if val.dtype.kind in "fic")
    bridge.archive(dest,**out)
    print(dest.name,flush=True)


if __name__=="__main__":
    command=sys.argv[1]
    if command in ("inputs","frozen"):
        lock(command,True)
    else:
        for size in sys.argv[3:]:
            integrate(command,sys.argv[2],int(size))
