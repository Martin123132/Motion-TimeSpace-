import sys
from clock_identity import paired,table
from read_quarter import raw,CHANNELS,LOCATIONS,peak
from quarter_evolve import HERE,bridge,np,TOL,SEC,digest


def results():
    alt={}
    for name in ("receiver","halfstep"):
        saved=bridge.read(HERE/f"{name}-finite.npz")
        assert saved["program"].item().decode()==digest(HERE/"gauge_replay.py") and saved["receipt"].item().decode()==digest(HERE/"pair-freeze.json")
        alt[name]=saved
    for site in LOCATIONS:
        for idx,channel in enumerate(CHANNELS):
            def wave(bank,tag,slot):
                val=bank[tag][idx,slot]
                return val-val[0]
            main=wave(paired("finite",256),site+"_64_3",3)
            rest=wave(paired("finite",256),site+"_64_3",2)
            norm=peak(main)
            dt=peak(main-wave(alt["halfstep"],site,3))
            gauge=peak(main-wave(alt["receiver"],site,3))
            grid=peak(main-wave(paired("finite",128),site+"_64_3",3))
            ray=sum(peak(main-wave(paired("finite",256),site+"_"+other,3)) for other in ("32_3","64_2"))
            err=dt+gauge+grid+ray
            yield dict(site=site,channel=channel,relative_time=dt/norm,relative_gauge=gauge/norm,relative_grid=grid/norm,
                       relative_ray=ray/norm,combined_over_own=err/norm,maximum_plus_shifts_over_rest=(norm+err)/peak(rest),
                       combined_absolute_seconds=err*SEC if idx>=2 else "",passes=err<=TOL*norm)


if __name__=="__main__":
    for item in table("gauge-checks.csv",results(),sys.argv[1:]==["create"]):
        print(item["site"],item["channel"],item["relative_gauge"],item["relative_time"],item["passes"])
