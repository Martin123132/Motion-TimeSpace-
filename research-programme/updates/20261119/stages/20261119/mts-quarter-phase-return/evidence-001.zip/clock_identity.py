import sys
from functools import lru_cache
from read_quarter import HERE,LOCATIONS,EMISSIONS,CHANNELS,raw,peak,table
from quarter_evolve import bridge,np,TOL,SEC,digest
from halo_mean import Profile,RHO
from numpy.polynomial.legendre import leggauss


def analytic(site,order):
    profile=Profile(1)
    points,weights=leggauss(order)
    points=(points+1)/2
    weights=weights/2
    left=LOCATIONS[site]
    right=left+.5

    def local(rad):
        rad=np.asarray(rad)
        prep=profile.data(rad.ravel())
        vals={key:val.reshape(rad.shape) for key,val in prep.items()}
        mass,grad,df,press=(vals[key] for key in ("m","g","df","press"))
        amp,slope,density,angular=(vals[key] for key in ("amp","slope","density","lam"))
        lapse=np.exp(vals["nuc"])
        factor=1-2*mass/rad
        baryon_gradient=rad**2*vals["b"]*np.sqrt(factor*(1+angular))
        press_gradient=-(RHO*amp**2+2*press)*grad-2*RHO*factor*slope**2/rad
        slope_grad=(density-2*mass/rad**3+press+rad*press_gradient-df*grad)/factor
        action_grad=(grad+rad*slope_grad)*(1+angular)**2+2*angular/rad
        metric_weight=1+2*rad*grad
        kn=lapse**2*(factor/(1+angular)*(1/rad-grad)*action_grad-metric_weight*baryon_gradient/rad**2)
        harm_mass=RHO/2*rad**2*factor*amp*slope
        harm_pressure=RHO/2*(-(1+np.exp(2*vals["omega_rel"]))*amp**2+factor*slope**2)
        drive=-lapse**2*(metric_weight*harm_mass/rad**2+rad*harm_pressure)
        sigma=2*(1+vals["omega"])
        velocity=drive*sigma/(sigma**2-kn)
        return (1/(lapse*np.sqrt(factor)),lapse,np.sqrt(kn),
                -baryon_gradient*velocity/(rad*factor),-metric_weight*baryon_gradient*velocity/(factor*rad**2))

    radii=left+.5*points
    geom,_,kr,gm,local_r_nu=local(radii)
    subr=left+(radii-left)[:,None]*points
    subw=(radii-left)[:,None]*weights
    subgeom,_,ks,_,gs=local(subr)
    tau=(subw*subgeom).sum(axis=1)
    cone=.5*weights*geom
    flight=sum(cone)
    ne=local(np.array([left]))[1][0]
    nr=local(np.array([right]))[1][0]
    clocks=[]
    for proper in EMISSIONS:
        elapsed=proper/ne
        def delta(kind,offset,frequency):
            half=elapsed/2
            kernel=elapsed*np.sinc(frequency*half/np.pi)
            if kind=="sin_over_k":
                return kernel*np.cos(frequency*(offset+half))
            if kind=="cos":
                return -2*np.sin(frequency*(offset+half))*np.sin(frequency*half)
            return kernel*(offset+half)*np.sinc(frequency*(offset+half)/np.pi)
        def leg(kind,offset):
            grav=(subw*gs*delta(kind,offset[:,None],ks)).sum(axis=1)
            return np.dot(cone,gm*delta(kind,offset,kr)-grav)
        def end(kind):
            return np.dot(.5*weights,local_r_nu*delta(kind,flight,kr))
        out_delay,out_freq=leg("sin_over_k",tau),leg("cos",tau)
        echo_delay=out_delay+leg("sin_over_k",2*flight-tau)
        echo_freq=out_freq+leg("cos",2*flight-tau)
        clocks.append([-ne/nr*(out_freq+end("sin_over_k")),-echo_freq,
                       nr*(out_delay+end("int_sin_over_k")),ne*echo_delay])
    return np.array(clocks).T


@lru_cache(None)
def paired(mode,mesh):
    record=bridge.read(HERE/f"paired-{mode}-{mesh}.npz")
    assert record["receipt"].item().decode()==digest(HERE/("pair-inputs.json" if mode=="forecast" else "pair-freeze.json"))
    return record


def estimates():
    for site in LOCATIONS:
        fine_oracle=analytic(site,24)
        coarse_oracle=analytic(site,16)
        for idx,name in enumerate(CHANNELS):
            def read(mode,mesh=256,rule="64_3",slot=3):
                arr=paired(mode,mesh)[site+"_"+rule][idx,slot]
                return arr-arr[0]
            target=read("finite")
            pred=read("forecast")
            truth=fine_oracle[idx]
            norm=peak(target)
            mesh_shift=peak(target-read("finite",128))
            ray_shift=peak(target-read("finite",256,"32_3"))+peak(target-read("finite",256,"64_2"))
            forecast_shift=peak(pred-read("forecast",128))+peak(pred-read("forecast",256,"32_3"))+peak(pred-read("forecast",256,"64_2"))
            analytic_shift=peak(truth-coarse_oracle[idx])
            rest=raw("finite","radial_rest",256)[site+"_64_3"][idx,2:].sum(axis=0)
            rest=rest-rest[0]
            normalized=lambda amount:amount/norm if norm>0 else (0. if amount==0 else np.inf)
            idxpeak=np.argmax(abs(target))
            fullshift=mesh_shift+ray_shift
            yield dict(site=site,channel=name,finite_signed_peak=target[idxpeak],
                       finite_peak_seconds=target[idxpeak]*SEC if idx>=2 else "",linear_signed_peak=truth[np.argmax(abs(truth))],
                       leading_exact_zero=not truth.any(),paired_linear_vs_identity_over_own=normalized(peak(pred-truth)),
                       finite_numerical_over_own=normalized(fullshift),full_budget_over_own=normalized(fullshift+forecast_shift+analytic_shift+peak(target-truth)),
                       paired_mesh_absolute=mesh_shift,paired_ray_absolute=ray_shift,paired_forecast_error_absolute=forecast_shift,
                       exterior_or_small_signal_over_total=(norm+fullshift)/peak(rest),
                       unchanged_rest_waveform_over_total=peak(read("finite",slot=2)-rest)/peak(rest),
                       finite_numerical_pass=fullshift<=TOL*norm,full_linear_pass=fullshift+forecast_shift+analytic_shift+peak(target-truth)<=TOL*norm)


if __name__=="__main__":
    rows=table("paired-clock-identity.csv",estimates(),sys.argv[1:]==["create"])
    for row in rows:
        print(row["site"],row["channel"],row["finite_numerical_over_own"],row["full_budget_over_own"],row["finite_peak_seconds"])
