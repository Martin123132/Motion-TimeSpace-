import json
import sys
from quarter_evolve import Quarter,HERE,PREPS,MESHES,LOCATIONS,TIMES,EMISSIONS,bridge,digest,lock,holds,np,read_clocks


def prep_lock(stage,create=False):
    lock("frozen")
    files=[HERE/"paired.py",HERE/"frozen.json",HERE/"clocks.csv",HERE/"orbit.csv",
           *[HERE/f"finite-{prep}-{mesh}.npz" for prep in PREPS for mesh in MESHES]]
    if stage=="pair-freeze":
        prep_lock("pair-inputs")
        files=[HERE/"pair-inputs.json",*[HERE/f"paired-forecast-{mesh}.npz" for mesh in MESHES]]
    record=HERE/(stage+".json")
    content={path.name:digest(path) for path in files}
    if create:
        with record.open("x",encoding="utf8") as out:
            json.dump(content,out,sort_keys=True,indent=2)
    assert json.loads(record.read_bytes())==content


class Paired(Quarter):
    def __init__(self,mesh,mode):
        self.use_outer=False
        super().__init__(mesh,mode,"radial_rest")
        for key,val in list(vars(self).items()):
            if isinstance(val,np.ndarray) and val.shape==(4,len(self.x)) and key!="canonical":
                assert not np.any(val[2:])
                merged=val.copy()
                merged[0]+=merged[1]
                merged[1:]=0.
                setattr(self,key,merged)
        self.canonical=self.contrast(self.mul(self.needed,self.mul(self.gamma,self.inv(self.mul(self.lapse,self.factor)))))
        knots=np.arange(6)-1.5
        self.weights=np.linalg.solve(np.array([knots**power for power in range(6)]),np.array([.5**(power+1)/(power+1) for power in range(6)]))
        self.use_outer=True

    def contrast(self,var):
        dest=0*self.one
        dest[3]=var[0]
        return dest

    def prim(self,data,odd=False):
        result=super().prim(data,odd)
        if self.use_outer and odd:
            deriv=data[3]
            dx=1/self.mesh
            mid=int(self.mesh*6)
            start=dx*np.dot(self.weights,deriv[mid-2:mid+4])
            ext=np.r_[-deriv[:2][::-1],deriv,deriv[-2:][::-1]]
            increments=(11*(ext[:-5]+ext[5:])-93*(ext[1:-4]+ext[4:-1])+802*(ext[2:-3]+ext[3:-2]))*(dx/1440)
            result[3,mid:]=start+np.r_[0.,np.cumsum(increments[mid:])]
            result[3,:mid]=start-np.cumsum(increments[:mid][::-1])[::-1]
        return result

    def launch(self):
        self.prep="periodic_velocity"
        try:
            return super().launch()
        finally:
            self.prep="radial_rest"

    def forecast(self,time):
        items=list(super().forecast(time))
        mul=self.mul
        spring2=mul(self.kn,self.kn)
        sinc=time*(self.one-self.kn*time**2/6+spring2*time**4/120)
        cosine=self.one-self.kn*time**2/2+spring2*time**4/24
        disp=self.contrast(mul(self.needed,sinc))
        vel=self.contrast(mul(self.needed,cosine))
        mass=-mul(self.bprime,disp)
        nu=self.prim(mul(self.ifac,mul(self.gfactor,mass))/self.x**2,True)
        for idx,value in ((0,mass),(2,disp),(3,vel),(4,nu),(6,mul(self.bprime/self.x**2,vel)),
                          (7,-mul(self.kn,disp)),(8,-self.diff(self.x**2*mul(self.b,disp),True)/self.x**2),
                          (9,-mul(self.angprime,disp))):
            items[idx]=items[idx]+value
        return items


def run(mode,mesh):
    assert mesh in MESHES and mode in ("forecast","finite")
    stage="pair-inputs" if mode=="forecast" else "pair-freeze"
    prep_lock(stage)
    dest=HERE/f"paired-{mode}-{mesh}.npz"
    if dest.exists() or dest.with_suffix(".partial").exists():
        raise FileExistsError(dest)
    lab=Paired(mesh,mode)
    masks={site:(lab.x>=lo-.09)&(lab.x<=lo+.59) for site,lo in LOCATIONS.items()}
    strips={site:[] for site in LOCATIONS}
    diagnostics=[]
    state=lab.launch() if mode=="finite" else None
    steps=int(np.ceil(mesh*.01/.42))
    dt=.01/steps
    for tick,time in enumerate(TIMES):
        fields=lab.dynamics(state,time,True) if state is not None else lab.forecast(time)
        mass,press,disp,vel,nu=fields[:5]
        lapse=lab.ar.exponential(lab.nu+nu)
        opt=lab.inv(lab.mul(lapse,lab.sqrt(lab.factor-2*mass/lab.x)))-lab.one
        for site,mask in masks.items():
            strips[site].append(np.stack((opt[:,mask],(lapse-lab.one)[:,mask])))
        diag=np.stack((mass,press,disp,vel,nu,fields[5],fields[6],fields[10]))
        diagnostics.append(diag[:,:,::16])
        if tick%25==0:
            holds()
        if state is not None and tick+1<len(TIMES):
            for sub in range(steps):
                start=time+dt*sub
                first=lab.dynamics(state,start)
                second=lab.dynamics(state+dt*first/2,start+dt/2)
                third=lab.dynamics(state+dt*second/2,start+dt/2)
                fourth=lab.dynamics(state+dt*third,start+dt)
                state+=dt/6*(first+2*second+2*third+fourth)
    out=dict(diag=np.array(diagnostics),space=lab.x[::16],receipt=np.bytes_(digest(HERE/(stage+".json"))))
    for site,mask in masks.items():
        banks=np.array(strips.pop(site))
        for panels,degree in ((32,3),(64,3),(64,2)):
            out[f"{site}_{panels}_{degree}"]=read_clocks(TIMES,lab.x[mask],banks,LOCATIONS[site],lab.ar,panels,degree)
    assert all(np.isfinite(val).all() for val in out.values() if val.dtype.kind in "fic")
    bridge.archive(dest,**out)
    print(dest.name,flush=True)


if __name__=="__main__":
    mode=sys.argv[1]
    if mode in ("pair-inputs","pair-freeze"):
        prep_lock(mode,True)
    else:
        for mesh in sys.argv[2:]:
            run(mode,int(mesh))
