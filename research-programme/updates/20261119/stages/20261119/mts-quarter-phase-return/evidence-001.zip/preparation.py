import sys
from read_quarter import PREPS,SHELLS,raw,table,np,SEC,c,YEAR,TOL,TIMES
from quarter_evolve import Quarter
from numpy.polynomial.legendre import leggauss
from scipy.interpolate import make_interp_spline
from scipy.integrate import solve_ivp


def coefficients():
    lab=Quarter(256,"forecast","radial_rest")
    def read(values):
        return make_interp_spline(lab.x,values[:2].sum(axis=0),k=5)(SHELLS)
    return read(lab.needed),np.sqrt(read(lab.kn)),read(lab.sigma)


def transport():
    speeds,naturals,forcing=coefficients()
    for idx,radius in enumerate(SHELLS):
        need,natural,sigma=speeds[idx],naturals[idx],forcing[idx]
        for prep in PREPS:
            fields=raw("finite",prep,256)["diag"][:,:,:,idx]
            whole=fields[:,:,2]+fields[:,:,3]
            xi=whole[:,2]/(1-whole[:,11])
            vel=whole[:,3]+whole[:,12]*xi
            pfree=natural*(xi/need-np.sin(sigma*TIMES)/sigma)
            vfree=vel/need-np.cos(sigma*TIMES)
            q0=0.
            v0=-1. if prep=="radial_rest" else 0.
            ang=natural*TIMES
            qref=np.cos(ang)*q0+np.sin(ang)*v0
            vref=-np.sin(ang)*q0+np.cos(ang)*v0
            error=max(np.max(abs(pfree-qref)),np.max(abs(vfree-vref)))
            inertia=pfree**2+vfree**2
            yield dict(r=radius,material=radius<5,prep=prep,free_epicycle_period_year=2*np.pi*SEC/(natural*YEAR),
                       predicted_homogeneous_amplitude_m=abs(v0)*need*c*SEC/natural,
                       free_energy_initial_over_reference=inertia[0],free_energy_max_over_reference=max(inertia),
                       absolute_energy_variation_over_reference=np.max(abs(inertia-inertia[0])),
                       free_vector_error_over_periodic_speed=error,passes=error<TOL)


def workbench(natural,sigma,cycles,modulation):
    period=2*np.pi/sigma
    duration=cycles*period
    epsilon=natural/sigma
    def rate(t):
        unit=(t+duration)/duration
        return 30*unit**2*(1-unit)**2*(1+modulation*np.cos(sigma*t))/duration
    def project(order):
        nodes,weights=leggauss(order)
        times=(-duration+period*(np.arange(cycles)[:,None]+(nodes+1)/2)).ravel()
        measure=(rate(times).reshape(cycles,order)*(period*weights/2)).ravel()
        norm=measure.sum()
        measure/=norm
        ph=sigma*times
        lag=-natural*times
        q0=-np.dot(measure,epsilon*np.sin(ph)*np.cos(lag)+np.cos(ph)*np.sin(lag))
        v0=-np.dot(measure,-epsilon*np.sin(ph)*np.sin(lag)+np.cos(ph)*np.cos(lag))
        side=sum(abs(np.dot(measure,np.exp(1j*om*times))) for om in (sigma-natural,sigma+natural))*(1+epsilon)/2
        return np.array((q0,v0,side,norm))
    fine=project(20)
    coarse=project(12)
    def rhs(time,state):
        disp,vel,window=state
        return vel,-natural**2*disp-(sigma**2-natural**2)/sigma*window*np.sin(sigma*time),rate(time)/fine[3]
    target=solve_ivp(rhs,[-duration,0.],np.zeros(3),method="DOP853",rtol=2e-11,atol=2e-13,max_step=period/10)
    assert target.success
    disp,vel,window=target.y[:,-1]
    error=max(abs(natural*disp-fine[0]),abs(vel-1-fine[1]),abs(window-1),max(abs(fine-coarse)))
    q0,v0,side,norm=fine
    amp=np.hypot(q0,v0)
    assert amp<=side+1e-12 and error<TOL
    drift_per_VT=(-2*q0*np.sin(natural*period/2)**2+v0*np.sin(natural*period))/(natural*period)
    return amp,side,drift_per_VT,error


def switches():
    speeds,naturals,forcing=coefficients()
    idx=list(SHELLS).index(3.)
    need,natural,sigma=speeds[idx],naturals[idx],forcing[idx]
    for cycles in (1,8,64):
        for modulation in (0.,.5):
            amp,cap,drift,error=workbench(natural,sigma,cycles,modulation)
            yield dict(r=3.,initial_phase="quadrature_at_end",ramp_cycles=cycles,rate_modulation=modulation,
                       residual_free_amplitude_over_V=amp,fourier_upper=cap,
                       next_cycle_displacement_m=drift*need*c*SEC*2*np.pi/sigma,
                       independent_retarded_ode_error=error,interpretation="conditional_net_force_history")


if __name__=="__main__":
    for name,method in (("free-action",transport),("retarded-preparation",switches)):
        rows=table(name+".csv",method(),sys.argv[1:]==["create"])
        print(name,len(rows),rows[-1])
