import sys
import csv
import json
from pathlib import Path
HERE = Path(__file__).resolve().parent
PRE = HERE.parent / "mts-conserved-breathing-mode-20261119"
sys.path.insert(0,str(PRE))
from breathing import np, TOL, SCALE, bridge, background, hold as prior_hold, solve_bvp, cumulative_simpson, simpson, PPoly
from mode_forecast import mode
from excitation import shell
from scipy.linalg import eigh, eigh_tridiagonal
from scipy.interpolate import make_interp_spline
from scipy.constants import c
from numpy.polynomial.legendre import leggauss
from functools import lru_cache

PRIOR = "5981a5ba9ebb50d85c3375fa4a430eb7cded0e8e563c461f50d635d40107ba4e"
FRACTIONS = np.array([1.,.5,.25])
PULSES = (.5,1.,2.)
EDGE = 30.
MU = 1e-4
CARRIER = 4.
DONOR = (2.,4.)
RECEIVER = (.5,1.5)
BRIDGE = (.4,4.1)
SCALES = {"radius384":(384,512),"radius768":(768,512),"time1024":(768,1024)}


def guard():
    prior_hold()
    assert bridge.sha(PRE/"seal.json")==PRIOR
    if (HERE/"STOP-REQUESTED").exists():
        raise SystemExit("owner hold")


def verify_parent():
    guard()
    record=json.loads((PRE/"seal.json").read_bytes())
    for name,digest in record["files"].items():
        assert bridge.sha(PRE/name)==digest
    for name,digest in record["inputs"].items():
        assert bridge.sha(HERE.parent/name)==digest


def table(name,rows,create):
    rows=list(rows)
    path=HERE/name
    if create:
        with path.open("x",newline="",encoding="utf8") as stream:
            writer=csv.DictWriter(stream,fieldnames=rows[0])
            writer.writeheader()
            writer.writerows(rows)
    with path.open(newline="",encoding="utf8") as stream:
        assert list(csv.DictReader(stream))==[{key:str(val) for key,val in row.items()} for row in rows],name
    return rows


def potential(radius,bounds):
    left,right=bounds
    point=np.asarray(radius)
    lower=np.clip(point,left,right)
    half=(right-lower)/2
    return -(shell(point,*bounds)[0]/np.maximum(point,1e-200)+half*np.sum(WEIGHTS*(
        shell(lower[...,None]+half[...,None]*(NODES+1),*bounds)[1]/(lower[...,None]+half[...,None]*(NODES+1))),axis=-1))


NODES,WEIGHTS=leggauss(20)


def static_potential(axis):
    return potential(axis,DONOR)+CARRIER*potential(axis,BRIDGE)


def change_potential(axis):
    return potential(axis,RECEIVER)-potential(axis,DONOR)


def delta_mass(axis):
    return shell(axis,*RECEIVER)[0]-shell(axis,*DONOR)[0]


@lru_cache(None)
def loaded(scale):
    core,eigen,_=background(False,EDGE)
    total=EDGE**2*core(EDGE)[3]
    mass=MU*total*scale
    if scale==0.:
        return core,eigen,total
    mesh=np.linspace(0.,EDGE,601)
    assert np.min(np.diff(mesh))>.049
    def rhs(axis,fields,level):
        amp,slope,phi,grad=fields
        return np.stack((slope,2*(phi+mass*static_potential(axis)-level[0])*amp,grad,amp**2))
    def bc(left,right,level):
        return np.array([left[1],left[3],right[0],right[2]+EDGE*right[3],EDGE**2*right[3]-total])
    result=solve_bvp(rhs,bc,mesh,core(mesh),S=np.diag([0.,-2.,0.,-2.]),p=[eigen],tol=3e-10,bc_tol=2e-13,
                     max_nodes=12000)
    assert result.success, result.message
    return result.sol,float(result.p[0]),total


def overtone(limit):
    core,eigen,_=background(False,limit)
    count=900
    step=limit/count
    axis=np.arange(1,count)*step
    amp,_,pot,_=core(axis)
    energies,vec=eigh_tridiagonal(1/step**2+pot-eigen,-.5*np.ones(count-2)/step**2,select="i",select_range=(0,105))
    diagonal=energies[1:]-energies[0]
    basis=vec[:,1:]
    weighted=amp[:,None]*basis
    integral=step*(np.cumsum(axis[:,None]*weighted,axis=0)+axis[:,None]*(weighted.sum(axis=0)-np.cumsum(weighted,axis=0)))
    mixing=-2*amp[:,None]*integral
    weights=np.sqrt(diagonal)
    values,states=eigh((np.diag(diagonal)+basis.T@mixing)*weights[:,None]*weights[None,:],subset_by_index=[1,1])
    freq=np.sqrt(values[0])
    coeff=weights*states[:,0]
    pform=basis@coeff/axis
    qform=(basis@(diagonal*coeff)+mixing@coeff)/(axis*freq)
    pform,qform=pform/pform[0],qform/pform[0]
    mesh=np.linspace(0.,limit,801)
    def interpolation(data):
        fitted=make_interp_spline(np.r_[0.,axis,limit],np.r_[data[0],data,0.],k=3)
        return fitted(mesh),fitted.derivative()(mesh)
    pf,pg=interpolation(pform)
    qf,qg=interpolation(qform)
    enclosed=cumulative_simpson(2*mesh**2*core(mesh)[0]*pf,x=mesh,initial=0.)
    grad=np.divide(enclosed,mesh**2,out=np.zeros_like(mesh),where=mesh>0.)
    pot=cumulative_simpson(grad,x=mesh,initial=0.)
    pot-=pot[-1]+limit*grad[-1]
    def rhs(rad,fields,level):
        pf,pg,qf,qg,pot,grad=fields
        amp,_,background_phi,_=core(rad)
        centre=background_phi-eigen
        return np.stack((pg,2*(centre*pf+amp*pot-level[0]*qf),qg,2*(centre*qf-level[0]*pf),grad,2*amp*pf))
    def bc(left,right,level):
        return np.array([left[0]-1.,left[1],left[3],left[5],right[0],right[2],right[4]+limit*right[5]])
    result=solve_bvp(rhs,bc,mesh,np.stack((pf,pg,qf,qg,pot,grad)),p=[freq],S=np.diag([0.,-2.,0.,-2.,0.,-2.]),
                     tol=4e-9,bc_tol=5e-12,max_nodes=11000)
    assert result.success, result.message
    return result.sol,float(result.p[0])


def transform(freq,duration):
    def harmonic(rate):
        return duration*np.sinc(rate*duration/(2*np.pi))*np.exp(-.5j*rate*duration)
    return .5*harmonic(freq)-.25*(harmonic(freq-2*np.pi/duration)+harmonic(freq+2*np.pi/duration))


def predictions(create):
    funcs=[mode("isolated")]
    profile,omega=overtone(EDGE)
    other,long_omega=overtone(42.)
    path=HERE/"overtone.npz"
    if create:
        bridge.archive(path,x=profile.x,coeff=profile.c,omega=np.array(omega))
    saved=bridge.read(path)
    assert np.array_equal(profile.c,saved["coeff"]) and omega==saved["omega"]
    funcs.append((profile,omega))
    core,_,total=loaded(0.)
    rows=[]
    axis=np.linspace(0.,EDGE,18001)
    density=core(axis)[0]
    for label,(func,frequency) in enumerate(funcs,1):
        pf,_,qf,_,_,grad=func(axis)
        norm=simpson(axis**2*pf*qf,x=axis)
        overlap=MU*total*simpson(axis**2*pf*density*change_potential(axis),x=axis)
        independent=-.5*MU*total*simpson(grad*delta_mass(axis),x=axis)
        assert abs(overlap/independent-1)<TOL
        for periods in PULSES:
            duration=periods*2*np.pi/funcs[0][1]
            endpoint=-overlap/norm*np.exp(1j*frequency*duration)*transform(frequency,duration)
            if label==1 and periods==2.:
                endpoint=0j
            for coast in (0.,.25):
                signal=endpoint*np.exp(1j*frequency*coast*2*np.pi/funcs[0][1])
                rows.append(dict(mode=label,periods=periods,coast=coast,omega=frequency,action_norm=norm,potential_overlap=overlap,
                                 end_density_coordinate=signal.imag,end_velocity_coordinate=signal.real,
                                 projected_energy=frequency*norm*abs(signal)**2,
                                 long_domain_relative_frequency=abs(long_omega/omega-1) if label==2 else ""))
    return table("predictions.csv",rows,create)


def freeze(create):
    verify_parent()
    rows=predictions(create)
    old=list(csv.DictReader((PRE/"formation-probe-forecast.csv").read_text().splitlines()))
    for row in rows:
        if row["mode"]==1 and row["coast"]==0:
            prior=next(item for item in old if float(item["duration_in_mode_periods"])==row["periods"])
            for a,b in (("end_density_coordinate","end_field_projection"),("end_velocity_coordinate","end_velocity_over_omega")):
                assert abs(row[a]-float(prior[b])) < 1e-12
    paths=[HERE/name for name in ("model.py","transport.py","PROTOCOL.md","overtone.npz","predictions.csv")]
    paths.extend((PRE/"seal.json",PRE/"formation-probe-forecast.csv"))
    record={p.relative_to(HERE.parent).as_posix():bridge.sha(p.with_suffix(".frozen-v1.txt") if p.suffix==".py" else p) for p in paths}
    dest=HERE/"forecast.json"
    if create:
        with dest.open("x",encoding="utf8") as f:
            json.dump(record,f,indent=2,sort_keys=True)
    assert record==json.loads(dest.read_bytes())
    return rows


if __name__=="__main__":
    print(freeze(sys.argv[1:]==["freeze"])[-6:])

