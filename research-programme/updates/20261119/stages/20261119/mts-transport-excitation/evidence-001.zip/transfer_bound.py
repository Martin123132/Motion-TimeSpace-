import sys
from model import HERE,PRE,EDGE,guard,mode,background,np,simpson,table,TOL,delta_mass,loaded
from scipy.constants import parsec
from breathing import KG,MSUN,LENGTH,SCALE
from cap_test import budgets

def bounds():
    guard()
    pair,omega=mode("isolated")
    coord=np.linspace(0.,EDGE,24001)
    values=pair(coord)
    norm=simpson(coord**2*values[0]*values[2],x=coord)
    total=loaded(0.)[2]
    for label,lengthpc in (("illustrative",SCALE*LENGTH/parsec),("central_cap",budgets("central_cap")[0])):
        massunit=KG*LENGTH/(MSUN*parsec*lengthpc)
        for region,left,right in (("full_numerical_domain",0.,EDGE),("frozen_shell_support",.5,4.),
                                  ("all_inside_1kpc",0.,1000/lengthpc),("from_2_to_20kpc",2000/lengthpc,20000/lengthpc),
                                  ("outer_50_to_100kpc",50000/lengthpc,100000/lengthpc)):
            axis=np.linspace(left,right,3201)
            force=pair(axis)[5]
            envelope=simpson(abs(force),x=axis)/(norm*omega)
            coarse=simpson(abs(force[::2]),x=axis[::2])/(norm*omega)
            assert abs(coarse/envelope-1)<TOL
            specified=(simpson(abs(force*delta_mass(axis)),x=axis)/(norm*omega) if region=="frozen_shell_support" else None)
            yield dict(ground_normalization=label,length_pc=lengthpc,region=region,inner_kpc=left*lengthpc/1000,
                       outer_kpc=right*lengthpc/1000,mass_scale_msun=massunit,total_wave_mass_msun=total*massunit,
                       max_amplitude_per_transported_msun=envelope/massunit,
                       necessary_moved_msun_for_amplitude_0p001=.001*massunit/envelope,
                       peak_envelope_for_nominal_source=1e-4*total*envelope,
                       fixed_shell_spatial_envelope_at_nominal_source=1e-4*total*specified if specified is not None else "",
                       quadrature_difference=abs(coarse/envelope-1))
if __name__=="__main__":
    print(table("one-excursion-bound.csv",bounds(),sys.argv[1:]==["create"]))

