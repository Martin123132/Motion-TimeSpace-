import sys
from scipy.interpolate import make_interp_spline
from analysis_transport import (HERE,packet,target,obs,euc,np,table,TOL,PULSES,FRACTIONS,simpson)
from cap_test import read_rows

def integrals(data,arm,pulse):
    stop=int(round(128*pulse))
    axis=data["times"][:stop+1]
    rate=data["work_rates"][:stop+1,arm]
    cubic=make_interp_spline(axis,rate,k=3).integrate(axis[0],axis[-1])
    quintic=make_interp_spline(axis,rate,k=5).integrate(axis[0],axis[-1])
    septic=make_interp_spline(axis,rate,k=7).integrate(axis[0],axis[-1])
    return septic,quintic,cubic

def refined():
    for grid in ("time1024","time2048","time4096"):
        for ratio in FRACTIONS:
            data=packet(grid,ratio)
            for arm,pulse in enumerate(PULSES,1):
                work,fifth,third=integrals(data,arm,pulse)
                for coast in (0.,.25):
                    epoch=pulse+coast
                    change=data["relative_energy"][int(round(epoch*4)),arm]
                    yield dict(grid=grid,ratio=ratio,periods=pulse,coast=coast,net_work=work[0],wave_energy=change,
                               quadrature_change_3_to_5=abs(third[0]/fifth[0]-1),quadrature_change_5_to_7=abs(fifth[0]/work[0]-1),
                               work_reciprocity=abs(work[1]/work[0]-1),net_energy_error=abs(change/work[0]-1),
                               energy_pass=abs(change/work[0]-1)<TOL)

def differences():
    spec=read_rows(HERE/"spectral-work.csv")
    for pulse in PULSES:
        arm=PULSES.index(pulse)+1
        line=next(row for row in spec if float(row["edge"])==30. and row["sines"]=="224" and float(row["periods"])==pulse and float(row["coast"])==0.)
        targetwork=float(line["tangent_total_energy"])
        for grid in ("time1024","time2048","time4096"):
            vals=np.array([integrals(packet(grid,ratio),arm,pulse)[0][0]/ratio**2 for ratio in FRACTIONS])
            for key,val in (("finite_nominal",vals[0]),("two_mass_extrapolation",2*vals[2]-vals[1]),("three_mass_extrapolation",(8*vals[2]-6*vals[1]+vals[0])/3)):
                yield dict(grid=grid,periods=pulse,estimate=key,scaled_net_work=val,spectral_work=targetwork,
                           error=abs(val/targetwork-1),meets_tolerance=abs(val/targetwork-1)<TOL)

def higher_order():
    spec=read_rows(HERE/"spectral-work.csv")
    for (order,pulse,coast),(predict,weight) in target().items():
        arm=PULSES.index(pulse)+1
        scale=euc(predict) or euc(target()[order,1.,coast][0])
        results=[]
        for grid in ("radius384","radius768","time2048","time4096"):
            vals=np.array([obs(packet(grid,ratio),arm,pulse+coast,order)/ratio for ratio in FRACTIONS])
            results.append((8*vals[2]-6*vals[1]+vals[0])/3)
        row=next(line for line in spec if line["sines"]=="224" and float(line["edge"])==30. and float(line["periods"])==pulse and float(line["coast"])==coast)
        prefix="fundamental" if order==1 else "second"
        spectral=np.array([float(row[prefix+"_C"]),float(row[prefix+"_B"])])
        errors=np.array([euc(results[0]-results[1]),euc(results[2]-results[3]),euc(results[3]-predict),euc(spectral-predict)])/scale
        yield dict(mode=order,periods=pulse,coast=coast,space=errors[0],time=errors[1],nonlinear_vs_frozen=errors[2],
                   spectral_vs_frozen=errors[3],independent_methods_budget=sum(errors),passes=sum(errors)<TOL)

if __name__=="__main__":
    for name,fn in (("work-refinement",refined),("tangent-work",differences),("tangent-coordinates",higher_order)):
        rows=table(name+".csv",fn(),sys.argv[1:]==["create"])
        print(name,[row for row in rows if row.get("grid","time4096")=="time4096" and row.get("ratio",1.)==1. and row.get("coast",0.)==0. and row["periods"]==2.])

