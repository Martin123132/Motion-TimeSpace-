import sys
import csv
import json
from functools import lru_cache
from model import (HERE,bridge,np,table,guard,SCALES,FRACTIONS,PULSES,TOL,simpson,mode,loaded,delta_mass,shell,
                   BRIDGE,DONOR,RECEIVER,CARRIER,SCALE,c,EDGE,MU,static_potential)
from importlib.util import spec_from_file_location, module_from_spec
spec=spec_from_file_location("mts_transport_probe",HERE/"transport.py")
worker=module_from_spec(spec)
spec.loader.exec_module(worker)
fingerprint,basis,waveforms=worker.fingerprint,worker.basis,worker.waveforms

@lru_cache(None)
def packet(grid,ratio):
    path=HERE/f"transport-{grid}-{int(ratio*100):03d}.npz"
    data=bridge.read(path)
    assert data["forecast"].item().decode()==fingerprint()
    assert float(data["fraction"])==ratio and data["grid"].item().decode()==grid
    assert len(data["sample_cycles"])==10 and data["raw_fields"].shape[:2]==(10,4)
    return data

@lru_cache(None)
def target():
    rows=list(csv.DictReader((HERE/"predictions.csv").read_text().splitlines()))
    return {(int(row["mode"]),float(row["periods"]),float(row["coast"])):(
        np.array([float(row["end_density_coordinate"]),float(row["end_velocity_coordinate"])]),
        float(row["omega"])*float(row["action_norm"])) for row in rows}

def obs(data,arm,cycles,order):
    sample=int(round(128*cycles))
    return data["coordinates"][sample,arm,order-1]

def euc(val):
    return float(np.linalg.norm(val))

def coordinates():
    for grid in SCALES:
        for (order,pulse,coast),(expected,weight) in target().items():
            arm=PULSES.index(pulse)+1
            scale=euc(expected) or euc(target()[order,1.,coast][0])
            values=[obs(packet(grid,ratio),arm,pulse+coast,order)/ratio for ratio in FRACTIONS]
            levels=values+[2*values[1]-values[0],2*values[2]-values[1]]
            for method,val in zip(("full","half","quarter","tangent_full_half","tangent_half_quarter"),levels):
                err=euc(val-expected)/scale
                yield dict(grid=grid,mode=order,periods=pulse,coast=coast,method=method,nominal_C=val[0],nominal_B=val[1],
                           amplitude_per_nominal_mass=euc(val),predicted_C=expected[0],predicted_B=expected[1],reference_amplitude=scale,
                           error=err,passes=err<TOL)

def budgets():
    for (order,pulse,coast),(expected,weight) in target().items():
        arm=PULSES.index(pulse)+1
        scale=euc(expected) or euc(target()[order,1.,coast][0])
        fine=[]
        alt=[]
        for grid in SCALES:
            values=[obs(packet(grid,ratio),arm,pulse+coast,order)/ratio for ratio in FRACTIONS]
            fine.append(2*values[2]-values[1])
            alt.append(2*values[1]-values[0])
        errors=np.array([euc(fine[0]-fine[1]),euc(fine[1]-fine[2]),euc(fine[2]-alt[2]),euc(fine[2]-expected)])/scale
        yield dict(mode=order,periods=pulse,coast=coast,reference_amplitude=scale,space=errors[0],time=errors[1],
                   amplitude_extrapolation=errors[2],tangent_discrepancy=errors[3],empirical_sum=sum(errors),
                   passes=sum(errors)<TOL)

def energy():
    for grid in SCALES:
        for ratio in FRACTIONS:
            data=packet(grid,ratio)
            for arm,pulse in enumerate(PULSES,1):
                stop=int(round(128*pulse))
                rate=data["work_rates"][:stop+1,arm]
                times=data["times"][:stop+1]
                work,other=simpson(rate,x=times,axis=0)
                assert work>0
                variation=simpson(abs(rate[:,0]),x=times)
                for coast in (0.,.25):
                    cycles=pulse+coast
                    idx=int(round(4*cycles))
                    balance=data["relative_energy"][idx,arm]
                    energies=[target()[order,pulse,coast][1]*euc(obs(data,arm,cycles,order))**2 for order in (1,2)]
                    yield dict(grid=grid,ratio=ratio,periods=pulse,coast=coast,source_work=work,work_from_reciprocal_force=other,
                               transported_work_variation=variation,wave_energy=balance,relative_energy_error=abs(balance/work-1),
                               reciprocal_work_error=abs(other/work-1),first_mode_fraction=energies[0]/work,
                               second_mode_fraction=energies[1]/work,unassigned_fraction=1.-sum(energies)/work,
                               max_number_drift=np.max(data["diagnostics"][:,0]),max_reference_density_drift=np.max(data["diagnostics"][:,1]),
                               energy_pass=abs(balance/work-1)<TOL,reciprocal_pass=abs(other/work-1)<TOL)

def initial_controls():
    axis=np.linspace(0.,EDGE,12001)
    for ratio in FRACTIONS:
        func,eigen,total=loaded(ratio)
        amp,_,pot,grad=func(axis)
        ordinary=MU*ratio*total*static_potential(axis)
        lhs=simpson(axis**2*(.5*func(axis)[1]**2+amp**2*(pot+ordinary)),x=axis)
        enclosed=simpson(axis**2*amp**2,x=axis)
        yield dict(ratio=ratio,eigen=eigen,number_error=abs(enclosed/total-1),energy_identity=abs(lhs/(eigen*enclosed)-1),
                   material_surface_error=abs(EDGE**2*grad[-1]/total-1),central_field=amp[0],min_field_inside=float(min(amp[:-1])))

def material():
    axis=np.linspace(.4,4.1,7401)
    inside,din=shell(axis,*RECEIVER)
    outside,dout=shell(axis,*DONOR)
    _,dcarrier=shell(axis,*BRIDGE)
    difference=inside-outside
    omega=mode("isolated")[1]
    for periods in PULSES:
        duration=periods*2*np.pi/omega
        quick=0.
        always=CARRIER*dcarrier+np.minimum(din,dout)
        upper=np.divide(abs(difference)*np.pi/duration,always,out=np.zeros_like(axis),where=always>0)
        assert np.all(difference[always==0]==0.)
        for moment in np.linspace(0.,duration,129):
            h,speed=waveforms(moment,np.array([duration]))
            total=(1-h)*dout+h*din+CARRIER*dcarrier
            velocity=np.divide(-speed*difference,total,out=np.zeros_like(axis),where=total>0)
            assert total.min()>=0 and not np.any((total==0.)&(difference!=0.))
            quick=max(quick,max(abs(velocity)))
        mask=(axis>1.55)&(axis<1.95)
        yield dict(periods=periods,total_source_mass_in_moved_mass_units=1.+CARRIER,mass_flux_without_carrier_in_empty_gap=True,
                   carrier_min_mass_per_scaled_radius_in_inner_gap=min((CARRIER*dcarrier)[mask]),
                   max_speed_sampled_km_s=quick*c/(1000*SCALE),upper_over_time_sampled_radius_km_s=max(upper)*c/(1000*SCALE),
                   no_superluminal_sample=quick/SCALE<1,source_shape_integral_error=abs(simpson(din-dout,x=axis)))

def run(create):
    for name,fn in (("signed-response",coordinates),("error-budget",budgets),("energy-transfer",energy),("equilibria",initial_controls),("ordinary-transport",material)):
        rows=table(name+".csv",fn(),create)
        print(name,len(rows),flush=True)
        if name=="error-budget":
            for row in rows:
                if row["coast"]==0:
                    print(row,flush=True)
        if name=="energy-transfer":
            for row in rows:
                if row["grid"]=="time1024" and row["ratio"]==1 and row["coast"]==0:
                    print(row,flush=True)

if __name__=="__main__":
    run(sys.argv[1:]==["create"])

