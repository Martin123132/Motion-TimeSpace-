import sys
import shutil
from pathlib import Path
from tempfile import TemporaryDirectory
from analysis_transport import worker
import balanced
from model import HERE,bridge
from balanced_refine import REFINED

def replay(module,tag,ratio):
    original=module.HERE
    names=("forecast.json","balanced.py") if module is balanced else ("forecast.json","numerics-v2.json","model.py","transport.py","NUMERICS-REVISION.md","overtone.npz")
    if module is balanced:
        balanced.GRIDS.update(REFINED)
    prefix="balanced" if module is balanced else "transport"
    filename=f"{prefix}-{tag}-{int(ratio*100):03d}.npz"
    with TemporaryDirectory(prefix=".mts-source-replay-",dir=HERE.parent) as folder:
        place=Path(folder).resolve()
        assert place.parent==HERE.parent.resolve() and place.name.startswith(".mts-source-replay-")
        for name in names:
            shutil.copyfile(HERE/name,place/name)
        try:
            module.HERE=place
            module.run(tag,ratio)
        finally:
            module.HERE=original
        assert bridge.sha(place/filename)==bridge.sha(HERE/filename)
    assert not place.exists()
    print("identical replay",filename,bridge.sha(HERE/filename),flush=True)

if __name__=="__main__":
    replay(worker,"time1024",1.)
    replay(balanced,"eightfold",.25)

