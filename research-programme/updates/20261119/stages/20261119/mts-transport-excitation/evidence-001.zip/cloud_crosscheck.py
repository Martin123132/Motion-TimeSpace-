import sys
from scipy.integrate import solve_ivp
from cloud_overlap import catalogue
from cap_test import budgets,read_rows
from breathing import SCALE,LENGTH,KG,MSUN,SEC,YEAR
from scipy.constants import parsec
from model import HERE,np,mode,simpson,table,TOL

def comparisons():
    source=[row for row in catalogue() if not row["flag"]]
    profile,freq=mode("isolated")
    axis=np.linspace(0.,30.,12001)
    fields=profile(axis)
    norm=simpson(axis**2*fields[0]*fields[2],x=axis)
    for row in read_rows(HERE/"cloud-overlap.csv"):
        launch=float(row["launch_kpc"])
        length=SCALE*LENGTH/parsec if row["ground"]=="illustrative" else budgets("central_cap")[0]
        scale=length*parsec/LENGTH
        omega=freq*(YEAR*1e6)/(SEC*scale**2)
        original=np.array([float(cloud["R"]) for cloud in source])
        radius=original if row["geometry"]=="published" else np.array([cloud["cartesian_radius"] for cloud in source])
        travel=np.array([float(cloud["t"]) for cloud in source])*(radius-launch)/original
        masses=np.array([10**(float(cloud["logMHI"]) if row["mass_source"]=="published" else cloud["flux_logmass"]) for cloud in source])
        masses*=MSUN*scale/KG
        start=1000*launch/length
        initial_phi=profile(start)[4]
        def equilibrium(moment):
            rad=1000*(launch+(radius-launch)*np.clip(1+moment/travel,0.,1.))/length
            return -np.dot(masses,profile(rad)[4]-initial_phi)/(2*freq*norm)
        state=np.zeros(2)
        boundaries=np.unique(np.r_[-travel,0.])
        for left,right in zip(boundaries[:-1],boundaries[1:]):
            sol=solve_ivp(lambda time,coords:(omega*coords[1],-omega*(coords[0]-equilibrium(time))),(left,right),state,
                          method="DOP853",rtol=2e-11,atol=1e-24)
            assert sol.success
            state=sol.y[:,-1]
        eq=equilibrium(0.)
        tests=np.abs(np.array([state[0]/float(row["current_C"]),state[1]/float(row["current_B"]),eq/float(row["equilibrium_shift"])])-1)
        yield dict(ground=row["ground"],launch_kpc=launch,geometry=row["geometry"],mass_source=row["mass_source"],
                   time_evolved_C=state[0],time_evolved_B=state[1],force_potential_endpoint=eq,
                   error_C=tests[0],error_B=tests[1],error_equilibrium=tests[2],passes=max(tests)<TOL)
if __name__=="__main__":
    rows=table("cloud-time-domain.csv",comparisons(),sys.argv[1:]==["create"])
    print(max(row["error_C"] for row in rows),sum(row["passes"] for row in rows))

