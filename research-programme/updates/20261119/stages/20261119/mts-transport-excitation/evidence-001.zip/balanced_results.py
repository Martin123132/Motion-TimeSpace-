import sys
from functools import lru_cache
from model import HERE,bridge,np,guard,table,TOL,PULSES,FRACTIONS
from analysis_transport import target,euc
from cap_test import read_rows
from breathing import KG,SCALE,c,MSUN

LABELS=("small","wide","fine","double","fourfold","eightfold")

@lru_cache(None)
def bank(grid,ratio):
    data=bridge.read(HERE/f"balanced-{grid}-{int(ratio*100):03d}.npz")
    assert data["forecast"].item().decode()==bridge.sha(HERE/"forecast.json") and data["code"].item().decode()==bridge.sha(HERE/"balanced.py")
    assert data["grid"].item().decode()==grid and data["ratio"]==ratio
    assert data["rest_residual"]<1e-13 and np.isfinite(data["records"]).all()
    return data

def finite():
    guard()
    for label in LABELS:
        for ratio in FRACTIONS:
            data=bank(label,ratio)
            unit=KG*c**2/SCALE**3
            for arm,pulse in enumerate(PULSES):
                for coast in (0.,.25):
                    row=data["records"][int(128*(pulse+coast)),arm]
                    first=target()[1,pulse,coast][1]*euc(row[:2])**2
                    overtone=target()[2,pulse,coast][1]*euc(row[2:4])**2
                    yield dict(grid=label,ratio=ratio,periods=pulse,coast=coast,relative_work=row[4],wave_energy=row[5],
                               work_joule=row[4]*unit,physical_E_over_c2_msun=row[4]*unit/(c**2*MSUN),
                               energy_error=abs(row[5]/row[4]-1),energy_pass=abs(row[5]/row[4]-1)<TOL,
                               baseline_equation_residual=float(data["rest_residual"]),number_error=max(abs(data["records"][:,:,6]).flat),
                               leading_energy_allocation_first=first/row[4],leading_energy_allocation_second=overtone/row[4])

def closed_budget():
    levels=read_rows(HERE/"spectral-work.csv")
    for arm,pulse in enumerate(PULSES):
        targetwork=float(next(row["tangent_total_energy"] for row in levels if row["edge"]=="30.0" and row["sines"]=="224" and
                              float(row["periods"])==pulse and row["coast"]=="0.0"))
        all_tangents=[]
        for label in LABELS:
            vals=np.array([bank(label,ratio)["records"][int(128*pulse),arm,4]/ratio**2 for ratio in FRACTIONS])
            tangent=(8*vals[2]-6*vals[1]+vals[0])/3
            all_tangents.append(tangent)
        rich=(16*all_tangents[-1]-all_tangents[-2])/15
        for scheme,work in zip((*LABELS,"time_Richardson"),(*all_tangents,rich)):
            yield dict(periods=pulse,grid=scheme,field_tangent_work=work,independent_spectrum_work=targetwork,
                       relative_error=abs(work/targetwork-1),passes=abs(work/targetwork-1)<TOL)

def leakage():
    for coast in (0.,.25):
        for label in ("fourfold","eightfold"):
            values=np.array([bank(label,ratio)["records"][int(128*(2+coast)),2,:2] for ratio in FRACTIONS])
            for ratio,row in zip(FRACTIONS,values):
                yield dict(grid=label,coast=coast,ratio=ratio,C=row[0],B=row[1],actual_amplitude=euc(row),
                           amp_per_squared_ratio=euc(row)/ratio**2,
                           fraction_of_frozen_one_period=euc(row)/(ratio*euc(target()[1,1.,coast][0])))
if __name__=="__main__":
    for name,fn in (("balanced-energy",finite),("balanced-tangent-work",closed_budget),("null-leakage",leakage)):
        rows=table(name+".csv",fn(),sys.argv[1:]==["create"])
        print(name,[row for row in rows if row.get("grid") in ("eightfold","time_Richardson") and row.get("ratio",1.)==1. and row.get("coast",0.)==0.])

