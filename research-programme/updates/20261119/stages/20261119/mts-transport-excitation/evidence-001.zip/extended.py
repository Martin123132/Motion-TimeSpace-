import sys
from analysis_transport import worker
from model import HERE,SCALES

EXTRA={"time2048":(768,2048),"time4096":(768,4096)}

def run(tag,ratio):
    if tag not in EXTRA or ratio not in (1.,.5,.25):
        raise ValueError((tag,ratio))
    SCALES[tag]=EXTRA[tag]
    worker.run(tag,ratio)

if __name__=="__main__":
    for ratio in (1.,.5,.25):
        run(sys.argv[1],ratio)

