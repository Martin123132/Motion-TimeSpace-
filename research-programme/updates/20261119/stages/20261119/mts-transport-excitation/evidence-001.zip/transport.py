import sys
import json
from scipy.fft import dst,idst
from scipy.interpolate import PPoly
from model import (HERE, PRE, guard, bridge, np, loaded, mode, SCALES, FRACTIONS, PULSES, EDGE, MU, TOL,
                   static_potential,change_potential,delta_mass,simpson,cumulative_simpson)


def fingerprint():
    guard()
    dest=HERE/"forecast.json"
    record=json.loads(dest.read_bytes())
    for name,value in record.items():
        saved=HERE.parent/name
        assert bridge.sha(saved.with_suffix(".frozen-v1.txt") if saved.suffix==".py" else saved)==value
    supplemental=HERE/"numerics-v2.json"
    assert all(bridge.sha(HERE/name)==value for name,value in json.loads(supplemental.read_bytes()).items())
    return bridge.sha(supplemental)


def basis(axis):
    first,freq=mode("isolated")
    raw=bridge.read(HERE/"overtone.npz")
    second=PPoly(raw["coeff"],raw["x"],extrapolate=False)
    pairs=[first(axis),second(axis).T]
    return np.array([axis*row[0] for row in pairs]),np.array([axis*row[2] for row in pairs]),freq


def waveforms(times,durations):
    times=np.asarray(times)
    timing=times/durations
    active=(timing>0.) & (timing<1.) & np.isfinite(durations)
    return (np.where(active,np.sin(np.pi*timing)**2,0.),
            np.where(active,np.pi/durations*np.sin(2*np.pi*timing),0.))


def run(grid,ratio):
    digest=fingerprint()
    dest=HERE/f"transport-{grid}-{int(ratio*100):03d}.npz"
    if dest.exists() or dest.with_suffix(".partial").exists():
        raise FileExistsError(dest)
    size,ticks=SCALES[grid]
    dx=EDGE/size
    rad=np.arange(1,size)*dx
    wave,eigen,total=loaded(ratio)
    weights=np.pi*np.arange(1,size)/EDGE
    pf,qf,freq=basis(rad)
    norm=dx*np.sum(pf*qf,axis=1)
    period=2*np.pi/freq
    dt=period/ticks
    durations=period*np.array([np.inf,*PULSES])
    mass=MU*ratio*total
    unchanged=mass*static_potential(rad)
    source=mass*change_potential(rad)
    enclosed=mass*delta_mass(rad)
    initial=rad*wave(rad)[0]
    assert abs(dx*np.dot(initial,initial)/total-1)<TOL
    initial*=np.sqrt(total/(dx*np.dot(initial,initial)))
    chi=np.broadcast_to(initial,(4,size-1)).astype(complex).copy()
    start=np.abs(chi[0])**2
    def transform(values):
        return dst(values,type=1,axis=-1,norm="ortho",workers=1)
    def inverse(values):
        return idst(values,type=1,axis=-1,norm="ortho",workers=1)
    def grav(dens):
        return inverse(-transform(dens/rad)/weights**2)/rad-(dx/EDGE)*np.sum(dens,axis=-1,keepdims=True)
    const=1/(2-2**(1/3))
    coefficients=(const,1-2*const,const)
    phases={weight:np.exp(-.5j*dt*weight*weights**2) for weight in coefficients}
    times=[]
    coords=[]
    work=[]
    sample_fields=[]
    samples=[]
    diagnostics=[]
    energy=[]
    densities=np.abs(chi)**2
    potentials=grav(densities)
    stride=ticks//128
    for index in range(9*ticks//4+1):
        if index%(ticks//4)==0:
            guard()
        if index%stride==0:
            now=index*dt
            h,hdot=waveforms(now,durations)
            ctrl=chi[0]
            common=np.exp(-1j*np.angle(np.vdot(initial,ctrl)))
            relative=np.exp(-1j*np.angle(np.sum(ctrl.conj()*chi,axis=1)))
            aligned=chi*(common*relative)[:,None]
            base=ctrl*common
            difference=aligned-base
            change_rho=2*(base.conj()*difference).real+abs(difference)**2
            ccoord=dx*np.einsum("ij,kj->ik",difference.real,qf)/norm
            bcoord=dx*np.einsum("ij,kj->ik",difference.imag,pf)/norm
            coords.append(np.stack((ccoord,bcoord),axis=-1))
            delta=densities-start
            primary=hdot*dx*np.sum(delta*source,axis=1)
            full=np.pad(delta,((0,0),(1,1)))
            primitive=cumulative_simpson(full,dx=dx,axis=1,initial=0.)[:,1:-1]
            alt=-hdot*simpson(primitive*enclosed/rad**2,dx=dx,axis=1)
            work.append(np.stack((primary,alt),axis=-1))
            times.append(now)
            diagnostics.append([np.max(abs(dx*np.sum(densities,axis=1)/total-1)),
                                dx*np.sum(abs(densities[0]-start))/total])
            if index%(ticks//4)==0:
                sample_fields.append(chi.copy())
                samples.append(index/ticks)
                kine=inverse(.5*weights**2*transform(base))
                defect=kine+(potentials[0]+unchanged-eigen)*base
                dkin=dx*.5*np.sum(weights**2*abs(transform(difference))**2,axis=1)
                denergy=dx*np.sum(2*(difference.conj()*defect).real
                                  +(potentials[0]+unchanged-eigen)*abs(difference)**2
                                  +.5*change_rho*grav(change_rho),axis=1)+dkin
                energy.append(denergy+dx*h*np.sum(densities*source,axis=1))
        if index==9*ticks//4:
            break
        now=index*dt
        for weight in coefficients:
            h=waveforms(now,durations)[0]
            step=weight*dt
            chi*=np.exp(-.5j*step*(potentials+unchanged+h[:,None]*source))
            chi=inverse(transform(chi)*phases[weight])
            densities=abs(chi)**2
            potentials=grav(densities)
            now+=step
            h=waveforms(now,durations)[0]
            chi*=np.exp(-.5j*step*(potentials+unchanged+h[:,None]*source))
    packet=dict(rad=rad,times=np.array(times),period=np.asarray(period),coordinates=np.array(coords),raw_fields=np.array(sample_fields),
                sample_cycles=np.array(samples),work_rates=np.array(work),relative_energy=np.array(energy),
                diagnostics=np.array(diagnostics),initial=initial,eigen=np.asarray(eigen),number=np.asarray(total),
                grid=np.bytes_(grid),fraction=np.asarray(ratio),forecast=np.bytes_(digest))
    assert all(np.isfinite(v).all() for v in packet.values() if v.dtype.kind in "fc")
    bridge.archive(dest,**packet)
    print(grid,ratio,max(np.array(diagnostics)[:,0]),bridge.sha(dest),flush=True)


if __name__=="__main__":
    grid=sys.argv[1]
    for ratio in FRACTIONS if len(sys.argv)==2 else [float(sys.argv[2])]:
        assert ratio in FRACTIONS
        run(grid,ratio)

