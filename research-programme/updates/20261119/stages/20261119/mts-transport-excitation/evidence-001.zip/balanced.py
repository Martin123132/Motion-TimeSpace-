import sys
from functools import lru_cache
from scipy.linalg import solve
from scipy.fft import dst
from model import HERE,EDGE,bridge,np,guard,loaded,MU,PULSES,FRACTIONS,static_potential,change_potential
from analysis_transport import basis,waveforms,target

GRIDS={"small":(384,72,512),"wide":(768,120,512),"fine":(768,120,1024),"double":(768,120,2048)}

def sine(values):
    return dst(values,type=1,axis=-1,norm="ortho",workers=1)

def initialize(grid,ratio):
    size,count,ticks=GRIDS[grid]
    spacing=EDGE/size
    axis=spacing*np.arange(1,size)
    k2=(np.pi*np.arange(1,size)/EDGE)**2
    modes=np.sqrt(2/size)*np.sin(axis[:,None]*np.sqrt(k2[:count]))
    core,eigen,number=loaded(ratio)
    source=MU*ratio*number*change_potential(axis)
    donor=MU*ratio*number*static_potential(axis)
    coef=sine(axis*core(axis)[0])[:count]*np.sqrt(spacing)
    def grav(dens):
        return sine(-sine(dens/axis)/k2)/axis-spacing*np.sum(dens,axis=-1,keepdims=True)/EDGE
    for iteration in range(6):
        ground=(modes@coef)/np.sqrt(spacing)
        potential=grav(ground**2)+donor
        natural=np.diag(.5*k2[:count]-eigen)+modes.T@(potential[:,None]*modes)
        residual=natural@coef
        mass_error=np.dot(coef,coef)-number
        correction=max(np.max(abs(residual)),abs(mass_error))
        if correction<3e-15:
            break
        field=grav(2*ground*modes.T)
        jac=natural+modes.T@(ground[:,None]*field.T)
        matrix=np.block([[jac,-coef[:,None]],[2*coef[None,:],np.zeros((1,1))]])
        delta=solve(matrix,-np.r_[residual,mass_error],assume_a="gen")
        coef+=delta[:-1]
        eigen+=delta[-1]
    assert correction<1e-13
    return axis,spacing,coef,ground,eigen,potential,k2,source,grav,number,correction

def run(grid,ratio):
    guard()
    path=HERE/f"balanced-{grid}-{int(ratio*100):03d}.npz"
    if path.exists() or path.with_suffix(".partial").exists():
        raise FileExistsError(path)
    size,count,ticks=GRIDS[grid]
    axis,spacing,ground_coeff,ground,eigen,potential,k2,source,grav,number,rest_error=initialize(grid,ratio)
    pf,qf,freq=basis(axis)
    norm=spacing*np.sum(pf*qf,axis=1)
    period=2*np.pi/freq
    duration=period*np.array(PULSES)
    dt=period/ticks
    kinetic=.5*k2[:count]-eigen
    half=np.exp(-.5j*dt*kinetic)
    whole=half*half
    state=np.zeros((3,count),complex)
    work=np.zeros(3)
    def spatial(state):
        return sine(np.pad(state,((0,0),(0,size-1-count))))/np.sqrt(spacing)
    def rhs(state,h,hdot):
        difference=spatial(state)
        drho=2*ground*difference.real+abs(difference)**2
        induced=grav(drho)+h[:,None]*source
        out=potential*difference+induced*(ground+difference)
        rate=spacing*np.sum(drho*source,axis=1)*hdot
        return -1j*np.sqrt(spacing)*sine(out)[:,:count],rate
    times=[]
    records=[]
    for step in range(9*ticks//4+1):
        if step%(ticks//8)==0:
            guard()
        now=step*dt
        if step%(ticks//128)==0:
            delta=spatial(state)
            phase=np.exp(-1j*np.angle(number+state@ground_coeff))
            aligned=delta*phase[:,None]+ground*np.expm1(-1j*np.angle(number+state@ground_coeff))[:,None]
            dc=spacing*aligned.real@qf.T/norm
            db=spacing*aligned.imag@pf.T/norm
            drho=2*ground*delta.real+abs(delta)**2
            count_err=spacing*drho.sum(axis=1)/number
            energy=np.sum(kinetic*abs(state)**2,axis=1)+spacing*np.sum(potential*abs(delta)**2+.5*drho*grav(drho),axis=1)
            records.append(np.column_stack((dc[:,0],db[:,0],dc[:,1],db[:,1],work,energy,count_err)))
            times.append(now)
        if step==9*ticks//4:
            break
        start,starts=waveforms(now,duration)
        mid,mids=waveforms(now+.5*dt,duration)
        end,ends=waveforms(now+dt,duration)
        first,w1=rhs(state,start,starts)
        second,w2=rhs(half*(state+.5*dt*first),mid,mids)
        third,w3=rhs(half*state+.5*dt*second,mid,mids)
        fourth,w4=rhs(whole*state+dt*half*third,end,ends)
        state=whole*state+(dt/6)*(whole*first+2*half*(second+third)+fourth)
        work+=(dt/6)*(w1+2*w2+2*w3+w4)
    records=np.array(records)
    assert records.shape==(289,3,7) and np.isfinite(records).all()
    bridge.archive(path,records=records,times=np.array(times),grid=np.bytes_(grid),ratio=np.asarray(ratio),
                   number=np.asarray(number),rest_residual=np.asarray(rest_error),ground_coeff=ground_coeff,
                   forecast=np.bytes_(bridge.sha(HERE/"forecast.json")),code=np.bytes_(bridge.sha(HERE/"balanced.py")))
    print(grid,ratio,"two-period work",records[256,2,4], "energy/work - 1",records[256,2,5]/records[256,2,4]-1,flush=True)

if __name__=="__main__":
    for label in sys.argv[1:]:
        for ratio in FRACTIONS:
            run(label,ratio)

