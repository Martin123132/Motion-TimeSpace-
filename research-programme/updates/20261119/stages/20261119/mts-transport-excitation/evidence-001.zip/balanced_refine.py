import sys
from balanced import GRIDS,FRACTIONS,run

REFINED={"fourfold":(768,120,4096),"eightfold":(768,120,8192)}

if __name__=="__main__":
    for label in sys.argv[1:]:
        GRIDS[label]=REFINED[label]
        for ratio in FRACTIONS:
            run(label,ratio)

