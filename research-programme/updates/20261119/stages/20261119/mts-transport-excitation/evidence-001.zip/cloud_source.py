import sys
from urllib.request import Request,urlopen
from model import HERE

URL="https://vizier.cfa.harvard.edu/viz-bin/asu-tsv?-source=J/ApJ/855/33/clouds&-out.all&-out.max=150"

def acquire():
    path=HERE/"clouds-J-ApJ-855-33.tsv"
    if path.exists():
        raise FileExistsError(path)
    with urlopen(Request(URL,headers={"User-Agent":"MTS research catalogue replay"}),timeout=15) as response:
        assert response.status==200
        data=response.read(100001)
    assert 0<len(data)<100000 and b"J/ApJ/855/33/clouds" in data
    assert sum(line.split(b"\t",1)[0].strip().isdigit() for line in data.splitlines())==106
    with path.open("xb") as out:
        out.write(data)
    print(path.name,len(data),flush=True)

if __name__=="__main__":
    acquire()

