import csv
import sys
from model import HERE,EDGE,guard,np,mode,simpson,table,leggauss,bridge,TOL
from breathing import SCALE,LENGTH,KG,MSUN,SEC,YEAR
from cap_test import budgets
from scipy.constants import parsec

def catalogue():
    lines=(HERE/"clouds-J-ApJ-855-33.tsv").read_text(encoding="utf8").splitlines()
    keys=next(line for line in lines if line.startswith("recno\t")).split("\t")
    records=[]
    for line in lines:
        parts=line.split("\t")
        if not parts[0].strip().isdigit():
            continue
        assert len(parts)==len(keys)
        row={key:val.strip() for key,val in zip(keys,parts)}
        modeled=not bool(row["flag"])
        if modeled:
            assert all(row[key] for key in ("R","Dist","t","logMHI","x-kpc","y-kpc","z-kpc"))
            row["cartesian_radius"]=np.linalg.norm([float(row[key]) for key in ("x-kpc","y-kpc","z-kpc")])
            dist,mass,radius,age=[float(row[key]) for key in ("Dist","logMHI","R","t")]
            row["flux_logmass"]=float(row["logMHI8.2"])+2*np.log10(dist/8.2)
            assert abs(radius*1000*parsec/(age*1e6*YEAR*1000)-330.)<4
        else:
            assert row["flag"]=="m" and all(not row[key] for key in ("R","Dist","t","logMHI"))
        records.append(row)
    assert len(records)==106 and len({row["Name"] for row in records})==106
    return records


def results(create):
    rows=catalogue()
    freqfunc,omega=mode("isolated")
    grid=np.linspace(0.,EDGE,18001)
    fields=freqfunc(grid)
    norm=simpson(grid**2*fields[0]*fields[2],x=grid)
    nodes,weights=leggauss(32)
    ledgers=[]
    summaries=[]
    for tag,lengthpc in (("illustrative",SCALE*LENGTH/parsec),("central_cap",budgets("central_cap")[0])):
        scale=lengthpc*parsec/LENGTH
        massunit=KG/(MSUN*scale)
        physical_period=2*np.pi/omega*SEC*scale**2/YEAR/1e6
        for launch,geometry,mass_source in ((0.,"published","published"),(.1,"published","published"),(0.,"cartesian","published"),
                                            (.1,"cartesian","published"),(0.,"published","flux_scaled"),(.1,"published","flux_scaled")):
            cohort=[]
            for row in rows:
                result=dict(ground=tag,launch_kpc=launch,geometry=geometry,mass_source=mass_source,cloud=row["Name"],status="no_wind_model" if row["flag"] else "conditional_path",
                            flux_minus_published_dex="" if row["flag"] else row["flux_logmass"]-float(row["logMHI"]),
                            original_mass_agreement="" if row["flag"] else abs(row["flux_logmass"]-float(row["logMHI"]))<.013,
                            cartesian_minus_published_kpc="" if row["flag"] else row["cartesian_radius"]-float(row["R"]),
                            original_centroid_agreement="" if row["flag"] else abs(row["cartesian_radius"]-float(row["R"]))<.014)
                component=dict(radius_kpc="",hi_msun="",flight_myr="",instantaneous_C_equilibrium="",C_at_observation="",B_at_observation="",lag_C="",lag_amplitude="",monotone_bound="")
                if not row["flag"]:
                    radius,age,logmass=[float(row[key]) for key in ("R","t","logMHI")]
                    if mass_source=="flux_scaled":
                        logmass=row["flux_logmass"]
                    if geometry=="cartesian":
                        age*=row["cartesian_radius"]/radius
                        radius=row["cartesian_radius"]
                    mass=10**logmass
                    length=1000*(radius-launch)/lengthpc
                    sample=launch*1000/lengthpc+length*(1+nodes)/2
                    travel=age*(1-launch/radius)
                    phase=2*np.pi*travel/physical_period*(1-nodes)/2
                    kernel=weights*(length/2)*freqfunc(sample)[5]*mass/(2*omega*norm*massunit)
                    eq=-sum(kernel)
                    lag=1j*sum(kernel*np.exp(1j*phase))
                    present=1j*sum(kernel*np.expm1(1j*phase))
                    assert abs((lag+1j*eq)-present)<1e-13*sum(abs(kernel))
                    component=dict(radius_kpc=radius,hi_msun=mass,flight_myr=travel,instantaneous_C_equilibrium=eq,
                                   C_at_observation=present.imag,B_at_observation=present.real,lag_C=lag.imag,
                                   lag_amplitude=abs(lag),monotone_bound=sum(abs(kernel)))
                    cohort.append(component)
                result.update(component)
                ledgers.append(result)
            eq=sum(item["instantaneous_C_equilibrium"] for item in cohort)
            current=sum(item["C_at_observation"] for item in cohort)
            velocity=sum(item["B_at_observation"] for item in cohort)
            maxamp=sum(item["monotone_bound"] for item in cohort)
            summaries.append(dict(ground=tag,launch_kpc=launch,geometry=geometry,mass_source=mass_source,centroid_count=len(cohort),unmodeled=len(rows)-len(cohort),
                                  total_modeled_HI_msun=sum(item["hi_msun"] for item in cohort),
                                  total_all_HI_at_assumed_8p2_kpc_msun=sum(10**float(row["logMHI8.2"]) for row in rows),
                                  minimum_R_kpc=min(item["radius_kpc"] for item in cohort),maximum_R_kpc=max(item["radius_kpc"] for item in cohort),
                                  period_Myr=physical_period,min_flight_Myr=min(item["flight_myr"] for item in cohort),max_flight_Myr=max(item["flight_myr"] for item in cohort),
                                  equilibrium_shift=eq,current_C=current,current_B=velocity,lag_amplitude_if_frozen_now=float(np.hypot(velocity,current-eq)),
                                  phase_independent_monotone_bound=maxamp,ratio_to_tested_0p001=maxamp/.001))
    table("cloud-overlap-ledger.csv",ledgers,create)
    table("cloud-overlap.csv",summaries,create)
    return summaries

if __name__=="__main__":
    print(results(sys.argv[1:]==["create"]))

