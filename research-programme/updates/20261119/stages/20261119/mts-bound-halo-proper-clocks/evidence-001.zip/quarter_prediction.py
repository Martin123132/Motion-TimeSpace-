import sys
from scipy.interpolate import make_interp_spline
from scipy.integrate import solve_ivp
from halo_mean import write_table, TOL, np, SEC, c
from bound_cycle import Laboratory, SHELLS


def predictions():
    lab = Laboratory(256,"forecast","turn")
    def at(radius, array):
        return float(make_interp_spline(lab.x, array[:2].sum(axis=0), k=5)(radius))
    for radius in SHELLS:
        drive, spring, sigma, lapse, factor, gamma = [at(radius,arr) for arr in
                    (lab.drive, lab.kn, 2*lab.omega, lab.lapse, lab.factor, lab.gamma)]
        period = 2*np.pi/sigma
        natural = np.sqrt(spring)
        needed = drive*sigma/(sigma**2-spring)
        for prep in ("radial_rest","periodic_velocity"):
            difference = -needed if prep=="radial_rest" else 0.
            initial = (needed+difference)/needed
            def rhs(time, state):
                return [state[1], -spring*state[0]-drive*np.sin(sigma*time)/needed]
            sol = solve_ivp(rhs, [0.,period], [0.,initial], rtol=8e-13,atol=8e-15,method="DOP853")
            displacement = difference*period*np.sinc(natural*period/np.pi)
            increment = -2*difference*np.sin(natural*period/2)**2
            error = max(abs(sol.y[0,-1]-displacement/needed)/period, abs(sol.y[1,-1]-initial-increment/needed))
            assert sol.success and error < TOL
            yield dict(radius=radius,material=radius<5,prep=prep,launch_dr_dt_m_s=initial*needed*c,
                       canonical_radial_momentum_over_mc=initial*needed*gamma/(lapse*factor),
                       predicted_cycle_displacement_m=displacement*c*SEC,predicted_velocity_increment_m_s=increment*c,
                       independent_linear_ode_error_on_oscillation=error,full_field_test="pending")


if __name__=="__main__":
    print(write_table("quarter-forecast.csv",predictions(),sys.argv[1]=="create")[4:6])
