import sys
from scipy.constants import hbar, c, electron_volt, parsec
from scipy.integrate import quad
from scipy.optimize import brentq
from milkyway import SOL, RC, UNIT, VARIANTS, data, measures
from halo_mean import TOL, np, write_table
from bound_state import LENGTH, solve_edge


def limits(profile):
    def shape_slope(radius):
        amp, slope = profile(radius)[:2]
        return 2*amp + radius*slope

    pivot = brentq(shape_slope, .01, 10., xtol=2e-14)
    density = lambda radius: UNIT*(radius**2*profile(radius)[0])**2/SOL**4
    return pivot, density


def calculate():
    fine = data()
    coarse = solve_edge(18., 301, False, True)[2]
    pivot, density = limits(fine)
    test_pivot, test_density = limits(coarse)
    pole_ev = hbar*c/(LENGTH*electron_volt)
    maximum = density(pivot)
    mesh_error = max(abs(test_pivot/pivot-1), abs(test_density(test_pivot)/maximum-1))
    assert mesh_error < TOL and maximum > max(row[1]+.04 for row in VARIANTS)
    envelope = [dict(peak_scaled_radius=pivot, maximum_density_GeV_cm3=maximum,
                     optimizing_scale_pc=SOL*LENGTH/(parsec*pivot), pole_eV=pole_ev,
                     domain_and_mesh=mesh_error, solar_radius_kpc=SOL*LENGTH/parsec/1000)]
    branches = []
    for name, reported, outer11 in VARIANTS:
        for shift in (-1,0,1):
            value = reported + shift*.04
            for branch in ("diffuse","concentrated"):
                def root(prof, peak_at, dens):
                    low, high = (.001, peak_at) if branch=="diffuse" else (peak_at, min(12., .99*prof.x[-1]*SOL/RC))
                    return brentq(lambda rad: dens(rad)-value, low, high, xtol=1e-14)

                radius = root(fine,pivot,density)
                scale = SOL/radius
                solar, outer = measures(fine, scale)
                coarse_scale = SOL/root(coarse,test_pivot,test_density)
                _, coarse_outer = measures(coarse, coarse_scale)
                radial = RC/scale
                exterior = quad(lambda point: point**2*fine(point)[0]**2, 0., radial, epsabs=1e-10,epsrel=1e-10)[0]
                integral_error = abs(exterior/(radial**2*fine(radial)[3])-1)
                budget = max(abs(outer/coarse_outer-1), abs(solar/value-1), integral_error, abs(coarse_scale/scale-1))
                assert budget < TOL
                branches.append(dict(baryon_variant=name,density_offset_reported_errors=shift,branch=branch,
                            assumed_solar_density_GeV_cm3=value,implied_scale_pc=scale*LENGTH/parsec,
                            predicted_outer_mass_msun=outer,tabulated_outer_mass_msun=outer11*1e11,
                            difference_over_tabulated_mass_error=(outer-outer11*1e11)/3e9,
                            maximum_compatible_pole_eV=pole_ev*np.sqrt(maximum/value),
                            central_potential_over_c2=fine(0.)[2]/scale**2,
                            quadrature_error=integral_error,mesh_and_closure=budget))
    return envelope,branches


if __name__=="__main__":
    for name,rows in zip(("occupation-envelope","density-branches"),calculate()):
        print(name,write_table(name+".csv",rows,sys.argv[1]=="create")[0])
