import sys
from scipy.constants import G, parsec
from scipy.optimize import brentq
from milkyway import RC, SOL, SCALE, data, measures
from halo_mean import write_table, TOL, np
from bound_state import LENGTH, MSUN
from occupation_envelope import limits

RADIUS_KPC = 17.58
SPEED_KMS = 224.03
QUOTED_KMS = 1.91


def controls():
    prof = data()
    peak_at, density = limits(prof)
    assert abs(RC*LENGTH/(1000*parsec)-RADIUS_KPC)<1e-12
    for shift in (-1,0,1,3):
        speed = SPEED_KMS+shift*QUOTED_KMS
        mass_cap = (speed*1000)**2*RC*LENGTH/(G*MSUN)
        scale = brentq(lambda length: measures(prof,length)[1]/mass_cap-1, RC/25, 8*SCALE)
        solar, mass = measures(prof,scale)
        mass_at_peak = measures(prof,SOL/peak_at)[1]
        assert SOL/scale < peak_at and mass_cap < mass_at_peak
        yield dict(outer_kpc=RADIUS_KPC,error_offsets=shift,total_circular_km_s=speed,
                   maximum_halo_mass_msun=mass_cap,minimum_scale_pc=scale*LENGTH/parsec,
                   maximum_solar_density_GeV_cm3=solar,halo_mass_at_unconstrained_density_max_msun=mass_at_peak,
                   mass_equation_error=abs(mass/mass_cap-1),density_equation_error=abs(solar/density(SOL/scale)-1))


def requirements(branches):
    for entry in branches:
        halo_speed_sq = G*entry["predicted_outer_mass_msun"]*MSUN/(RC*LENGTH*1e6)
        yield dict(baryon_variant=entry["baryon_variant"],density_offset=entry["density_offset_reported_errors"],
                   branch=entry["branch"],outer_halo_speed_km_s=np.sqrt(halo_speed_sq),
                   required_inward_baryon_v2_km2_s2=SPEED_KMS**2-halo_speed_sq,
                   max_required_inward_v2_at_plus3_km2_s2=(SPEED_KMS+3*QUOTED_KMS)**2-halo_speed_sq,
                   consistent_with_nonnegative_baryon_force_at_nominal=halo_speed_sq<=SPEED_KMS**2)


if __name__=="__main__":
    from occupation_envelope import calculate
    for name,rows in (("outer-speed-bound",controls()),("outer-force-requirement",requirements(calculate()[1]))):
        print(name,write_table(name+".csv",rows,sys.argv[1]=="create")[0])
