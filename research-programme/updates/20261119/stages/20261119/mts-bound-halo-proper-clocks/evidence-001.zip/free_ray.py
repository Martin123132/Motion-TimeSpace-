import sys
from halo_mean import HOME,Profile,np,weights,SEC,c,parsec,Q,SCALE,write_table,TOL,peak
from bound_state import LENGTH
from cloud_receiver import load_calendar
from numpy.polynomial.legendre import leggauss


def calendar_factors(frequency):
    days,groups,count=load_calendar()
    yr=(days-min(days))/365.25
    times=(days-min(days))*86400/SEC
    _,inv=np.unique(days,return_inverse=True)
    weights_day=count/np.bincount(inv,weights=count)[inv]
    root=np.sqrt(weights_day/np.sum(weights_day))
    age=2*yr/max(yr)-1
    design=np.column_stack((yr*0+1,age,age**2,np.cos(2*np.pi*yr),np.sin(2*np.pi*yr),
                           np.cos(4*np.pi*yr),np.sin(4*np.pi*yr),groups[:,None]==np.unique(groups)[1:]))
    basis,sig,_=np.linalg.svd(root[:,None]*design,full_matrices=False)
    basis=basis[:,sig>sig[0]*1e-12]
    harmonics=root[:,None]*np.column_stack((np.cos(frequency*times),np.sin(frequency*times)))
    filtered=harmonics-basis@(basis.T@harmonics)
    return np.linalg.svd(filtered,compute_uv=False)[::-1]


def through(order,spacing_pc):
    branch=Profile(1)
    launch=2*Q*branch.energy
    sigma=2*np.exp(launch/2)
    lon,lat=np.deg2rad([28.75,25.22])
    earth,zsun=np.array([8275.,25.])*parsec/LENGTH
    start2=earth**2+zsun**2
    direction=-earth*np.cos(lon)*np.cos(lat)+zsun*np.sin(lat)
    def shape(path):
        radius=np.sqrt(start2+2*direction*path+path**2)
        mu=-(direction+path)/radius
        u,du,_,_=branch.spline(radius/SCALE).T
        d2u=branch.spline.derivative()(radius/SCALE).T[1]/SCALE**2
        grad=du/SCALE
        amp=Q**2
        rho=amp*u**2
        potential=amp*radius*u*grad/2
        first=amp/2*(u*grad+radius*(-2*u**2+grad**2))
        second=amp/2*(2*grad**2+u*d2u-2*u**2+radius*(-4*u*grad+2*grad*d2u))
        curvature=mu**2*(second+sigma**2*potential)+(1-mu**2)*first/radius
        return mu,first,potential,rho,curvature
    distpc=np.arange(int(round(1180/spacing_pc))+1)*spacing_pc
    distances=distpc*parsec/LENGTH
    nodes,weightsq=leggauss(order)
    step=distances[1]
    path=(distances[:-1,None]+step*(nodes+1)/2)
    mu,first,pot,rho,tidal=shape(path.ravel())
    phase=np.exp(-1j*sigma*path.ravel())
    def cum(integrand):
        bank=(integrand*phase).reshape(path.shape)
        return np.r_[0j,np.cumsum(step/2*(bank@weightsq))]
    curvature=cum(tidal/sigma**2)
    static=cum(-mu*first-1j*sigma*pot*mu**2)
    cosine,first,_,rho,tidal=shape(distances)
    endings=np.exp(-1j*sigma*distances)
    doppler=1j/sigma*(cosine*first*endings-cosine[0]*first[0])
    direct=-(static+doppler)/(1j*sigma)
    endpoint=(rho*endings-rho[0])/(1j*sigma**3)
    factor=calendar_factors(sigma/np.exp(branch.data(np.array([np.sqrt(start2)]))["nuc"][0]+branch.nu0))
    return distpc,curvature*SEC,direct*SEC,endpoint*SEC,static*SEC/sigma,rho[0]*SEC/sigma**3,factor


def analysis():
    dist,signal,direct,endpoint,static,norm,fac=through(6,.125)
    coarse=through(4,.25)
    rows=[]
    for tag,nom,low,high in (("VLBI",1050,990,1110),("timing",1150,1120,1180)):
        mask=(dist>=low)&(dist<=high)
        idx=int(nom*8)
        err=peak((signal-direct)[mask])/norm
        quad=peak((signal[::2]-coarse[1])[mask[::2]])/norm
        delta=peak((signal-endpoint)[mask])/norm
        rows.append(dict(release=tag,d_nom_pc=nom,d_min_pc=low,d_max_pc=high,earth_term_s=norm,nominal_raw_amplitude_s=abs(signal[idx]),
                    min_sampled_amplitude_s=min(abs(signal[mask])),max_sampled_amplitude_s=max(abs(signal[mask])),
                    nominal_after_nuisance_min_s=abs(signal[idx])*fac[0],nominal_after_nuisance_max_s=abs(signal[idx])*fac[1],
                    bracket_after_nuisance_min_s=min(abs(signal[mask]))*fac[0],bracket_after_nuisance_max_s=max(abs(signal[mask]))*fac[1],
                    held_stationary_nominal_s=abs(static[idx]),endpoint_difference_over_earth=delta,
                    independent_geodesic_over_earth=err,quadrature_over_earth=quad,numerical_pass=err+quad<TOL))
    return rows


if __name__=="__main__":
    print(write_table("free-sightline.csv",analysis(),sys.argv[1]=="create"))
