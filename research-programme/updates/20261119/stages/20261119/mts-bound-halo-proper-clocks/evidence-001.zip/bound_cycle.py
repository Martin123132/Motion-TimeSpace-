import sys
import json
from halo_mean import HOME, PRE, Profile, guard, np, bridge, Q, RHO, weights, TOL, peak
from cycle import Algebra, base, Radial, RADIUS, LOCATIONS, TIMES, EMISSIONS, SHELLS, integral
from proper_clock import read_clocks
from scipy.interpolate import make_interp_spline
from math import factorial


def lock(phase=None,create=False):
    guard()
    paths=[HOME/name for name in ("PROTOCOL.md","halo_mean.py","bound_cycle.py","mean-0.npz","mean-1.npz","mean-checks.csv")]
    paths+= [PRE/name for name in ("proper_clock.py","cycle.py","seal.json")]
    def mark(name,files,new):
        data={p.parent.name+"/"+p.name:bridge.sha(p) for p in files}
        if new:
            with (HOME/name).open("x") as stream:
                json.dump(data,stream,indent=2,sort_keys=True)
        else:
            assert json.loads((HOME/name).read_bytes())==data
    mark("launch.json",paths,phase is None and create)
    if phase:
        mark(phase+"-frozen.json",[HOME/"launch.json",*[HOME/f"forecast-{phase}-{mesh}.npz" for mesh in (128,256)]],create)


class Laboratory:
    def __init__(self,mesh,mode,phase):
        self.mesh=mesh
        self.ar=ar=Algebra(1,int(mode=="finite"))
        self.mode=mode
        self.sign=1. if phase=="turn" else -1.
        self.op=Radial(mesh,"tensor",0.,0.,RADIUS)
        xx=self.x=self.op.x
        self.one=one=base(np.ones_like(xx))
        self.profiles=[Profile(k) for k in range(2)]
        vals=[pr.data(xx) for pr in self.profiles]
        def pair(left,right):
            data=base(left)
            data[1]=right-left
            return data
        def read(key):
            return pair(*(v[key] for v in vals))
        self.mul=mul=ar.product
        self.inv=inv=ar.reciprocal
        self.sqrt=ar.root
        self.z=weights()
        self.mass=read("m")
        self.factor=one-2*self.mass/xx
        self.ifac=inv(self.factor)
        self.g=read("g")
        self.nu=self.prim(self.g,True)
        self.lapse=ar.exponential(self.nu)
        self.b=read("b")
        self.lam=read("lam")
        self.gamma=ar.root(one+self.lam)
        self.bprime=xx**2*mul(self.b,mul(self.gamma,ar.root(self.factor)))
        self.angprime=self.diff(self.lam)+2*self.lam/xx
        self.rho=read("density")
        self.fgrad=read("df")
        self.wave=mul(self.lapse,ar.root(self.factor))
        self.gam=mul(self.lapse,inv(ar.root(self.factor)))
        self.nusq=mul(self.lapse,self.lapse)
        self.omega=one+read("omega")
        self.wratio=ar.exponential(read("omega_rel"))
        self.rel=pair(*(np.expm1(2*v["omega_rel"]) for v in vals))
        self.slope=np.sqrt(2*RHO/self.z)*read("slope")
        self.amp=np.sqrt(2*RHO/self.z)*read("amp")
        integrated=self.prim(self.slope,True)
        self.amp[1]=integrated[1]-make_interp_spline(xx,integrated[1],k=5)(6.)
        self.wcan=mul(self.wratio,inv(ar.root(self.factor)))
        self.dlogk=self.g+mul(self.fgrad,self.ifac)/2
        self.lapamp=-mul(mul(self.rel,self.ifac),self.amp)-mul(self.dlogk,self.slope)
        aa=mul(self.amp,self.amp)
        grad=mul(self.factor,mul(self.slope,self.slope))
        self.eden=self.sign*self.z/4*(-mul(self.rel,aa)+grad)
        self.press=self.sign*self.z/4*(-mul(2*one+self.rel,aa)+grad)
        self.eta=self.sign*self.z/4*xx**2*mul(self.factor,mul(self.amp,self.slope))
        self.jamp=self.sign*self.z/2*mul(self.wratio,mul(ar.root(self.factor),mul(self.amp,self.slope)))
        self.gfactor=one+2*xx*self.g
        self.meansp=read("press")
        self.kn=mul(self.nusq,mul(mul(self.factor,inv(one+self.lam)),mul(one/xx-self.g,self.angprime))-mul(self.gfactor,self.bprime)/xx**2)
        self.drive=-mul(self.nusq,mul(self.gfactor,self.eta)/xx**2+xx*self.press)
        self.dust_test=all(np.min(self.kn[0]+which*self.kn[1])>0 for which in (0.,1.))
        self.stripping=self.z*0+mul(self.nusq,xx*self.meansp+mul(self.gfactor,self.mass)/xx**2)

    def diff(self,data,odd=False):
        return self.op.diff(data,self.op.d1,odd)

    def prim(self,data,odd=False):
        return integral(data,1/self.mesh,odd)

    def trig(self,time):
        pivot=time*self.omega[0]
        delta=time*self.omega[1]
        cs=base(np.cos(pivot))
        sn=base(np.sin(pivot))
        cs[1]=-2*np.sin(pivot+delta/2)*np.sin(delta/2)
        sn[1]=2*np.cos(pivot+delta/2)*np.sin(delta/2)
        return cs,sn

    def lift(self,value):
        return self.ar.stress(value,1.)

    def read_forecast(self,time):
        mul,one,xx=self.mul,self.one,self.x
        co,si=self.trig(2*time)
        k2=self.kn
        ct=one-k2*time**2/2+mul(k2,k2)*time**4/24
        ks=time*k2-time**3*mul(k2,k2)/6
        sigma=2*self.omega
        norm=mul(self.drive,self.inv(mul(sigma,sigma)-k2))
        disp=self.lift(mul(norm,ct-co))
        vel=self.lift(mul(norm,mul(sigma,si)-ks))
        mass=self.lift(mul(self.eta,co))-mul(self.bprime,disp)
        press=self.lift(mul(self.press,co))
        dnu=self.prim(mul(self.ifac,mul(mass,self.gfactor)/xx**2+xx*press),True)
        scalarflow=self.lift(mul(self.wave,mul(self.jamp,si)))
        dustflow=mul(self.bprime/xx**2,vel)
        acceleration=self.lift(mul(self.drive,co))-mul(self.kn,disp)
        den=-self.diff(xx**2*mul(self.b,disp),True)/xx**2
        angular=-mul(self.angprime,disp)
        return mass,press,disp,vel,dnu,scalarflow,dustflow,acceleration,den,angular,0*one

    def carrier(self,time):
        co,si=self.trig(time)
        dco,dsi=self.trig(2*time)
        if self.sign<0:
            co,si=-si,co
        return co,si,dco,dsi

    def launch(self):
        one,xx,mul=self.one,self.x,self.mul
        zero=0*one
        mass=self.lift(self.eta)
        co,si,_,_=self.carrier(0.)
        grad=mul(self.slope,co)
        for iteration in range(12):
            fac=self.factor-2*mass/xx
            drag=mul(2*xx*self.b,mul(self.gamma,self.inv(self.sqrt(fac)+self.sqrt(self.factor))))
            density=self.lift(self.eden)-self.z*mul(mass/xx,mul(grad,grad))
            changed=self.prim(xx**2*density-mul(drag,mass))
            if iteration>=3 and np.all(np.max(abs(mass-changed),axis=1)<=1e-13*np.maximum(1e-290,np.max(abs(changed),axis=1))):
                mass=changed
                break
            mass=changed
        else:
            raise ArithmeticError("initial constraints")
        fac=self.factor-2*mass/xx
        true_can=mul(-si,mul(self.amp,mul(self.wratio,self.inv(self.sqrt(fac)))))
        ref_can=mul(-si,mul(self.amp,self.wcan))
        delta_can=true_can-ref_can
        delta_can[:2]=0.
        return np.stack((zero,delta_can,mass,zero,zero,zero,zero))

    def dynamics(self,state,time,read=False):
        h,w,mass,mom,angular,count,label=state
        mul,inv,one,xx=self.mul,self.inv,self.one,self.x
        co,si,dco,dsi=self.carrier(time)
        height=mul(self.amp,co)
        slope=mul(self.slope,co)
        can=-mul(self.wcan,mul(self.amp,si))
        dh=self.diff(h)
        dF=-2*mass/xx
        fac=self.factor+dF
        root=self.sqrt(fac)
        ifac=inv(fac)
        dkin=mul(dF,mul(can,can)+mul(slope,slope))+mul(fac,mul(w,2*can+w)+mul(dh,2*slope+dh))
        dpot=mul(h,2*height+h)
        press=self.lift(mul(self.press,dco))+self.z/2*(dkin-dpot)
        energy=self.lift(mul(self.eden,dco))+self.z/2*(dkin+dpot)
        jscalar=self.lift(mul(self.jamp,dsi))-self.z*(mul(dF,mul(can,slope))+mul(fac,mul(w,slope)+mul(can+w,dh)))
        psq=mul(mom,mom)
        fp2=mul(fac,psq)
        orbit=self.lam+angular
        gam=self.sqrt(one+orbit+fp2)
        ig=inv(gam)
        density=self.b+count
        press+=mul(mul(density,root),mul(fp2,ig))
        jdust=mul(density,mul(fac,mom))
        dg=mul(ifac,mul(self.gfactor,mass)/xx**2+xx*press)
        dnu=self.prim(dg,True)
        lapse=self.ar.exponential(self.nu+dnu)
        wave=mul(lapse,root)
        nroot=mul(lapse,inv(root))
        vel=mul(lapse,mul(fac,mul(mom,ig)))
        df=self.diff(dF)
        bracket=mul(angular,one/xx-self.g)-mul(fp2,self.g)-mul(one+orbit+fp2,dg)-mul(psq,self.fgrad+df)/2
        pdot=mul(mul(lapse,ig),bracket)-mul(vel,self.diff(mom,True))
        if read:
            drive=mul(pdot,mul(lapse,mul(fac,ig)))
            dp=mul(density,mul(root,gam))-mul(self.b,mul(self.sqrt(self.factor),self.gamma))
            constraint=self.diff(mass,True)-xx**2*(dp+energy)
            return mass,press,-label,vel,dnu,mul(wave,jscalar),mul(wave,jdust),drive,count,angular,constraint
        dk=wave-self.wave
        ddlog=dg+mul(df-mul(self.fgrad,mul(dF,self.ifac)),ifac)/2
        kgrad=mul(wave,self.dlogk+ddlog)
        wh=mul(wave,w)+mul(dk,can)
        lap=self.op.diff(xx*h,self.op.d2,True)/xx
        ww=mul(wave,lap)+mul(kgrad,dh)-mul(nroot,h)
        ww+=mul(dk,mul(self.lapamp,co))+mul(mul(dk,self.dlogk)+mul(wave,ddlog),slope)-mul(nroot-self.gam,height)
        return np.stack((wh,ww,-xx**2*mul(wave,jscalar+jdust),pdot,-mul(vel,self.angprime+self.diff(angular)+2*angular/xx),
                         -self.diff(xx**2*mul(density,vel),True)/xx**2,-mul(vel,one+self.diff(label,True))))


def run(mode,phase,mesh):
    finite=mode=="finite"
    lock(phase if finite else None)
    dest=HOME/f"{mode}-{phase}-{mesh}.npz"
    if dest.exists():
        raise FileExistsError(dest)
    lab=Laboratory(mesh,mode,phase)
    assert lab.dust_test
    xx,ar,one=lab.x,lab.ar,lab.one
    masks={site:(xx>=lo-.09)&(xx<=lo+.59) for site,lo in LOCATIONS.items()}
    strips={site:[] for site in LOCATIONS}
    split=np.searchsorted(xx,SHELLS)
    pick=lambda values:(values[...,split-1]+values[...,split])/2
    steps=int(np.ceil(mesh*.01/.42))
    dt=.01/steps
    state=lab.launch() if finite else None
    diag=[]
    global_checks=[]
    for tick,time in enumerate(TIMES):
        fields=lab.dynamics(state,time,True) if finite else lab.read_forecast(time)
        mass,press,disp,vel,dnu,jscalar,jdust,force,count,angular,constraint=fields
        fac=lab.factor-2*mass/xx
        lapse=ar.exponential(lab.nu+dnu)
        opt=ar.reciprocal(ar.product(lapse,ar.root(fac)))-one
        for site,mask in masks.items():
            strips[site].append(np.stack((opt[:,mask],(lapse-one)[:,mask])))
        diag.append(pick(np.stack((mass,press,disp,vel,dnu,xx**2*jscalar,xx**2*jdust,force,count,angular,constraint))))
        assert not np.any(press[:2]) and not np.any(vel[:2])
        if tick%25==0:
            guard()
            displaced=xx**2*count[3]
            global_checks.append((time,abs(sum(displaced))/max(sum(abs(displaced)),1e-270),peak(lab.diff(disp,True))))
        if finite and tick<450:
            for sub in range(steps):
                pivot=time+dt*sub
                first=lab.dynamics(state,pivot)
                second=lab.dynamics(state+dt*first/2,pivot+dt/2)
                third=lab.dynamics(state+dt*second/2,pivot+dt/2)
                fourth=lab.dynamics(state+dt*third,pivot+dt)
                state+=dt/6*(first+2*second+2*third+fourth)
    out=dict(t=TIMES,r=SHELLS,emission=EMISSIONS,diag=np.array(diag),basic=np.array(global_checks),
             omega=pick(lab.omega),kn=pick(lab.kn),mean_mass=pick(lab.mass),mean_lapse=pick(lab.nu),
             receipt=np.bytes_(bridge.sha(HOME/(phase+"-frozen.json" if finite else "launch.json"))))
    for site,mask in masks.items():
        bank=np.array(strips.pop(site))
        for panels,degree in ((32,3),(64,3),(64,2)):
            out[f"{site}_{panels}_{degree}"]=read_clocks(TIMES,xx[mask],bank,LOCATIONS[site],ar,panels,degree)
    assert all(np.isfinite(item).all() for item in out.values() if hasattr(item,"dtype") and item.dtype.kind in "fic")
    bridge.archive(dest,**out)
    print(dest.name,flush=True)


if __name__=="__main__":
    if sys.argv[1]=="init":
        lock(create=True)
    elif sys.argv[1]=="freeze":
        lock(sys.argv[2],True)
    else:
        for arg in sys.argv[3:]:
            run(sys.argv[1],sys.argv[2],int(arg))
