import sys
from functools import lru_cache
from halo_mean import HOME, PRE, write_table, TOL, np, bridge, SEC
from cycle import TIMES, EMISSIONS, SHELLS, LOCATIONS, Algebra
from scipy.constants import c
from scipy.interpolate import make_interp_spline
from scipy.optimize import brentq
from scipy.integrate import cumulative_simpson
from cloud_receiver import load_calendar, at_arrival

PHASES=("turn","kinetic")
NAMES=("one_frequency","echo_frequency","one_delay","echo_delay")


@lru_cache(None)
def packet(mode,phase,mesh):
    bank=bridge.read(HOME/f"{mode}-{phase}-{mesh}.npz")
    assert np.array_equal(bank["emission"],EMISSIONS) and np.array_equal(bank["r"],SHELLS)
    assert bank["receipt"].item().decode()==bridge.sha(HOME/(phase+"-frozen.json" if mode=="finite" else "launch.json"))
    return bank


def peak(values):
    return np.max(abs(values))


def component(values,axis):
    return values[2] if axis=="isolated" else (values[3] if axis=="mixed" else values[2]+values[3])


def clocks():
    for phase in PHASES:
        for site in LOCATIONS:
            for idx,name in enumerate(NAMES):
                for axis in ("isolated","supported","mixed"):
                    def wave(mode,mesh=256,rule="64_3"):
                        curve=component(packet(mode,phase,mesh)[site+"_"+rule][idx],axis)
                        return curve-curve[0]
                    base=wave("forecast")
                    target=wave("finite")
                    norm=peak(target)
                    terms=[peak(term)/norm for term in (base-target,base-wave("forecast",128),target-wave("finite",128),
                           base-wave("forecast",256,"32_3"),target-wave("finite",256,"32_3"),
                           base-wave("forecast",256,"64_2"),target-wave("finite",256,"64_2"))]
                    at=np.argmax(abs(target))
                    yield dict(phase=phase,site=site,axis=axis,channel=name,peak_emission=EMISSIONS[at],signed_peak=target[at],
                               peak_s=target[at]*SEC if idx>=2 else "",model=terms[0],forecast_grid=terms[1],
                               target_grid=terms[2],forecast_ray=terms[3],target_ray=terms[4],forecast_order=terms[5],
                               target_order=terms[6],total=sum(terms),passes=sum(terms)<=TOL)


def motions():
    for phase in PHASES:
        for idx,radius in enumerate(SHELLS):
            for axis in ("supported","mixed"):
                def curves(mode,mesh):
                    data=packet(mode,phase,mesh)["diag"][:,:,:,idx].transpose(2,1,0)
                    return component(data,axis)
                target=curves("finite",256)
                model=curves("forecast",256)
                small=curves("finite",128)
                coarse=curves("forecast",128)
                budget=lambda col: (peak(target[col]-model[col])+peak(target[col]-small[col])+peak(model[col]-coarse[col]))/peak(target[col])
                mass_budget=budget(0)
                motion=max(budget(k) for k in (1,2,3))
                integrated=cumulative_simpson(-target[5]-target[6],x=TIMES,initial=0)
                half=cumulative_simpson((-target[5]-target[6])[::2],x=TIMES[::2],initial=0)
                changed=target[0]-target[0,0]
                balance=(peak(changed-integrated)+peak(integrated[::2]-half))/peak(changed)
                constraint=radius*peak(target[10])/peak(target[0])
                yield dict(phase=phase,r=radius,axis=axis,conditional_material=radius<5,delta_mass=changed[-1],
                           pressure_peak=peak(target[1]),velocity_peak_m_s=peak(target[3])*c,displacement_peak_m=peak(target[2])*c*SEC,
                           mass_error=mass_budget,motion_error=motion,energy_error=balance,radial_constraint=constraint,
                           passes=max(mass_budget,motion,balance,constraint)<=TOL)


def periods():
    for phase in PHASES:
        for idx,radius in enumerate(SHELLS):
            def measure(mode,mesh):
                data=packet(mode,phase,mesh)["diag"][:,:,:,idx]
                fields=data[:,:,2]+data[:,:,3]
                pressure=make_interp_spline(TIMES,fields[:,1],k=5)
                marks=np.flatnonzero(fields[1:,1]*fields[:-1,1]<0)
                roots=[brentq(pressure,TIMES[it],TIMES[it+1],xtol=1e-14) for it in marks]
                assert len(roots)==3
                low,high=roots[0],roots[-1]
                vel=make_interp_spline(TIMES,fields[:,3],k=5)
                pos=make_interp_spline(TIMES,fields[:,2],k=5)
                lapse=packet(mode,phase,mesh)["mean_lapse"][:2,idx].sum()
                proper=make_interp_spline(TIMES,np.exp(lapse+fields[:,4]),k=5).antiderivative()
                return np.array([low,high,high-low,(proper(high)-proper(low))*SEC/(365.25*86400),
                                 (vel(high)-vel(low))*c,(pos(high)-pos(low))*SEC*c,peak(fields[:,3])*c])
            fine=measure("finite",256)
            pred=measure("forecast",256)
            small=measure("finite",128)
            alt=measure("forecast",128)
            error=abs(fine-small)+abs(pred-alt)
            amplitude=abs(fine[4]-pred[4])+error[4]
            yield dict(phase=phase,r=radius,occupied=radius<5,first=fine[0],third=fine[1],proper_period_yr=fine[3],
                       net_velocity_m_s=fine[4],forecast_net_m_s=pred[4],numerical_shift_m_s=error[4],net_over_peak=fine[4]/fine[6],
                       error_over_peak=amplitude/fine[6],error_over_net=amplitude/max(abs(fine[4]),1e-290),
                       net_displacement_m=fine[5],peak_velocity_m_s=fine[6],net_pass=amplitude<=TOL*abs(fine[4]),
                       oscillation_scale_pass=amplitude<=TOL*fine[6])


def calendars():
    days,groups,counts=load_calendar()
    age=(days-min(days))/365.25
    elapsed=(days-min(days))*86400/SEC
    unique,inv=np.unique(days,return_inverse=True)
    weights=counts/np.bincount(inv,weights=counts)[inv]
    root=np.sqrt(weights/sum(weights))
    age0=2*age/max(age)-1
    design=np.column_stack((age*0+1,age0,age0**2,np.cos(2*np.pi*age),np.sin(2*np.pi*age),
                           np.cos(4*np.pi*age),np.sin(4*np.pi*age),groups[:,None]==np.unique(groups)[1:]))
    left,sig,_=np.linalg.svd(root[:,None]*design,full_matrices=False)
    basis=left[:,sig>sig[0]*1e-12]
    def remove(curve):
        weighted=root*curve
        return weighted-basis@(basis.T@weighted)
    for phase in PHASES:
        for site in LOCATIONS:
            for placement,fraction in (("early",0.),("middle",.5),("late",1.)):
                labels=EMISSIONS[1]+fraction*(EMISSIONS[-2]-EMISSIONS[1]-elapsed[-1])+elapsed
                def sample(mode,mesh=256,stride=1):
                    curve=packet(mode,phase,mesh)[site+"_64_3"][2,:,::stride]
                    return at_arrival(make_interp_spline(EMISSIONS[::stride],curve,axis=1,k=5),labels,3)
                target=sample("finite")
                other=[sample("forecast"),sample("finite",128),sample("finite",256,2)]
                for axis in ("supported","mixed"):
                    wave=component(target,axis)
                    post=np.linalg.norm(remove(wave))
                    err=sum(np.linalg.norm(remove(wave-component(vec,axis))) for vec in other)/post
                    yield dict(phase=phase,site=site,placement=placement,axis=axis,days=len(unique),raw_s=np.linalg.norm(root*wave),
                               post_s=post,comparison_error=err,passes=err<=TOL)


def jacobians():
    for phase in PHASES:
        for site in LOCATIONS:
            bank=packet("finite",phase,256)[site+"_64_3"]
            for idx,name in enumerate(("out","echo")):
                def inverse(stride,degree):
                    val=make_interp_spline(EMISSIONS[::stride],bank[idx+2,:,::stride],axis=1,k=degree).derivative()(EMISSIONS)
                    val[0]+=1
                    return Algebra(1,1).reciprocal(val)
                for axis in ("supported","mixed"):
                    fine,coarse,alt=[component(arr,axis) for arr in (inverse(1,5),inverse(2,5),inverse(1,7))]
                    ref=component(bank[idx],axis)
                    total=sum(peak(term-term[0]) for term in (ref-fine,fine-coarse,fine-alt))/peak(ref-ref[0])
                    yield dict(phase=phase,site=site,axis=axis,leg=name,error=total,passes=total<TOL)


if __name__=="__main__":
    for name,fn in (("clocks",clocks),("motions",motions),("cycles",periods),("calendar",calendars),("jacobians",jacobians)):
        rows=write_table(name+".csv",fn(),sys.argv[1]=="create")
        print(name,len(rows),sum(v.get("passes",v.get("net_pass",False)) for v in rows))
