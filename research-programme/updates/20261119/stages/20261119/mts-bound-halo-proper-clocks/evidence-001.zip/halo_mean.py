import sys
import os
import csv
import json
from pathlib import Path
for key in ("OMP_NUM_THREADS","OPENBLAS_NUM_THREADS","MKL_NUM_THREADS","NUMEXPR_NUM_THREADS"):
    os.environ[key]="1"
sys.dont_write_bytecode=True
HOME=Path(__file__).resolve().parent
PRE=HOME.parent/"mts-supported-cycle-20261119"
sys.path.insert(0,str(PRE))
from cycle import np, bridge, weights, TOL, guard as previous_guard, FRACTION
from bound_state import SCALE, RHO, inputs
from scipy.interpolate import PPoly
from scipy.special import betainc
from scipy.integrate import solve_bvp, cumulative_simpson
Q=SCALE**-2
LOCK="8570356c50d83a1e47e9475792d0c9a4d5972cedbd4ecff9bf7cb6518ed8311a"
from source import background
from evaluate import SEC
from scipy.constants import parsec,c


def guard():
    previous_guard()
    assert bridge.sha(PRE/"seal.json")==LOCK
    if (HOME/"STOP-REQUESTED").exists():
        raise SystemExit("owner hold")


def write_table(name,rows,create):
    rows=list(rows)
    if create:
        with (HOME/name).open("x",newline="",encoding="utf8") as stream:
            writer=csv.DictWriter(stream,fieldnames=rows[0])
            writer.writeheader()
            writer.writerows(rows)
    with (HOME/name).open(newline="",encoding="utf8") as stream:
        assert list(csv.DictReader(stream))==[{key:str(val) for key,val in row.items()} for row in rows],name
    return rows


class Rest:
    def __init__(self,baryons):
        self.b0=baryons*FRACTION*background("massive")[0]
        self.total=baryons*inputs()[4]

    def values(self,grid):
        rad=np.maximum(grid*SCALE,1e-60)
        cut=np.minimum((rad/5)**2,1.)
        count=self.total*betainc(1.5,7.,cut)
        baryon=self.b0*(1-cut)**6
        pot=(-count/rad-self.b0*25/14*(1-cut)**7)/Q
        drag=count/rad**2*SCALE**3
        return drag,pot,baryon/RHO


def local(rest,grid,state,eigen):
    amp,slope,hs,hslope=state
    db,phi,density=rest.values(grid)
    totald=db+hslope
    nu=phi+hs
    df=-2*Q*grid*totald
    factor=1+df
    diff=np.expm1(2*Q*(eigen-nu))
    pressure=(diff*amp**2+Q*factor*slope**2)/2
    rho=amp**2+pressure
    dvs=(hslope+grid*pressure-df*db)/factor
    dv=db+dvs
    speed2=Q*grid*dv
    kinetic=(df+speed2)/((1-speed2)*(np.sqrt(factor/(1-speed2))+1))
    corrected=rho+density*kinetic
    fprime=-2*Q*((density+corrected)*grid-totald)
    return nu,factor,dv,dvs,diff,pressure,corrected,fprime,totald,speed2


def solve(baryons,limit):
    rest=Rest(baryons)
    prior=bridge.read(PRE/("bound-ordinary.npz" if baryons else "bound-isolated.npz"))
    guess=PPoly(prior["coeff"],prior["x"],extrapolate=False)
    core=5/SCALE
    grid=np.unique(np.r_[np.linspace(0.,core,49),np.geomspace(core,.08,45),np.linspace(.08,limit,501)])
    state=guess(grid).T
    energy=np.array([np.log1p(prior["energy"])/Q])
    center=state[0,0]
    def rhs(rad,value,eig):
        amp,slope,hs,hslope=value
        _,fac,dv,dvs,diff,_,corrected,df,_,_=local(rest,rad,value,eig[0])
        return np.stack((slope,-(Q*dv+df/(2*fac))*slope-diff/(Q*fac)*amp,dvs,corrected))
    def boundary(left,right,eig):
        db,phi,_=rest.values(np.array([limit]))
        vb=np.log1p(-2*Q*limit*(db[0]+right[3]))/(2*Q)-phi[0]
        return np.array([left[0]-center,left[1],left[3],right[2]-vb,right[0]])
    for repeat in range(6):
        sol=solve_bvp(rhs,boundary,grid,state,S=np.diag([0.,-2.,0.,-2.]),p=energy,
                      tol=1.5e-9,bc_tol=8e-13,max_nodes=14000)
        if not sol.success:
            raise ArithmeticError(sol.message)
        residual=1-sol.sol(6/SCALE)[0]
        if abs(residual)<2e-13:
            break
        center+=residual
        grid,state,energy=sol.x,sol.y,sol.p
    else:
        raise ArithmeticError("local normalization")
    return sol.sol,sol.p[0],rest,prior


def pack(create):
    guard()
    summaries=[]
    for baryons in (0,1):
        readings=[]
        for limit in (18.,30.):
            spline,energy,rest,prior=solve(baryons,limit)
            edge=np.unique(np.r_[np.linspace(0.,5/SCALE,161),np.geomspace(5/SCALE,.08,151),np.linspace(.08,limit,8001)])
            state=spline(edge)
            nu,fac,dv,dvs,diff,press,corrected,df,totald,v2=local(rest,edge,state,energy)
            amp,slope,hs,hslope=state
            mass=limit**2*totald[-1]
            energy_integral=cumulative_simpson(edge**2*corrected,x=edge,initial=0.)[-1]
            vir=abs(energy_integral/(limit**2*hslope[-1])-1)
            integrand=edge**2*np.exp(Q*nu)*np.sqrt(fac)*slope**2
            rhs=edge**2*np.exp(Q*nu)/np.sqrt(fac)*(diff/Q)*amp**2
            kg=abs(cumulative_simpson(integrand,x=edge,initial=0.)[-1]/cumulative_simpson(rhs,x=edge,initial=0.)[-1]-1)
            assert abs(amp[-1])<1e-10 and min(amp)>-1e-12 and min(fac)>0 and peak(v2)<.01
            readings.append(np.array([mass,Q*energy,nu[0]*Q]))
            summaries.append(dict(baryons=baryons,edge=limit,mass_scaled=mass,log_omega=Q*energy,
                       central_log_lapse=Q*nu[0],density_anchor_error=abs(spline(6/SCALE)[0]-1),
                       mass_integral=vir,kg_integral=kg,newtonian_energy_difference=abs(np.expm1(Q*energy)/prior["energy"]-1)))
            if limit==30.:
                dest=HOME/f"mean-{baryons}.npz"
                if create:
                    assert not dest.exists()
                    bridge.archive(dest,x=spline.x,coeff=spline.c,energy=energy,loss=vir+kg)
                saved=bridge.read(dest)
                assert np.array_equal(saved["coeff"],spline.c) and saved["energy"]==energy
        change=max(abs(readings[1]/readings[0]-1))
        for rec in summaries[-2:]:
            rec["domain_test"]=change
            rec["passes"]=change+rec["mass_integral"]+rec["kg_integral"]<TOL
    return write_table("mean-checks.csv",summaries,create)


def peak(values):
    return np.max(np.abs(values))


class Profile:
    def __init__(self,baryons):
        self.rest=Rest(baryons)
        saved=bridge.read(HOME/f"mean-{baryons}.npz")
        self.spline=PPoly(saved["coeff"],saved["x"],extrapolate=False)
        self.energy=saved["energy"].item()
        self.nu0=Q*(self.rest.values(np.array([0.]))[1][0]+self.spline(0.)[2])

    def data(self,xx):
        grid=xx/SCALE
        state=self.spline(grid).T
        nu,fac,dv,_,_,press,corrected,df,totald,speed2=local(self.rest,grid,state,self.energy)
        amp,slope,hs,hslope=state
        number=self.rest.values(grid)[2]*RHO
        return dict(m=xx**2*totald/SCALE**3,nuc=Q*nu-self.nu0,g=Q*dv/SCALE,df=df/SCALE,
                    omega=np.expm1(Q*self.energy-self.nu0)*np.ones_like(xx),
                    omega_rel=Q*(self.energy-nu),amp=amp,slope=slope/SCALE,
                    press=RHO*press,b=number,lam=speed2/(1-speed2),density=(self.rest.values(grid)[2]+corrected)*RHO)


if __name__=="__main__":
    print(pack(sys.argv[1]=="create"))
