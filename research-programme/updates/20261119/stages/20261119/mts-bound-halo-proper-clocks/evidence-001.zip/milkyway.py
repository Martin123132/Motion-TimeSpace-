import sys
from halo_mean import HOME,PRE,np,bridge,write_table,Profile,SCALE,Q
from bound_state import LENGTH,KG,MSUN,GEVDENS
from scipy.interpolate import PPoly
from scipy.optimize import brentq, minimize_scalar
from scipy.constants import parsec,G,c
from math import pi

RC=17.58*1e3*parsec/LENGTH
SOL=np.hypot(8.275,.025)*1e3*parsec/LENGTH
UNIT=c**2/(4*pi*G*LENGTH**2*GEVDENS)
VARIANTS=(("Pouliasis",.33,1.23),("McMillan",.36,1.35),("Ou",.40,1.46),("Mean",.36,1.35))


def data():
    prior=bridge.read(PRE/"bound-isolated.npz")
    return PPoly(prior["coeff"],prior["x"],extrapolate=False)


def measures(profile,scale):
    solar=SOL/scale
    outer=RC/scale
    assert outer<=30. and solar<=30.
    density=UNIT*profile(solar)[0]**2/scale**4
    mass=KG/MSUN*outer**2*profile(outer)[3]/scale
    return density,mass


def records():
    profile=data()
    for tag,density,mass11 in VARIANTS:
        for sign in (-1,0,1):
            outer=(mass11+sign*.03)*1e11
            length=brentq(lambda scale:measures(profile,scale)[1]/outer-1,RC/25,8*SCALE)
            pred,mass=measures(profile,length)
            isothermal=outer*MSUN/(4*pi*(RC*LENGTH)*(SOL*LENGTH)**2*GEVDENS)
            yield dict(baryon_variant=tag,mass_offset_reported_errors=sign,external_mass_msun=outer,
                       inferred_scale_pc=length*LENGTH/parsec,rest_density_at_40pc_GeV_cm3=UNIT*profile(6/length)[0]**2/length**4,
                       predicted_solar_GeV_cm3=pred,NFW_inferred_density=density,reported_density_error=.04,
                       difference_in_reported_density_errors=(pred-density)/.04,
                       isothermal_same_mass_density=isothermal,isothermal_density_error_units=(isothermal-density)/.04,
                       mass_reproduction=abs(mass/outer-1))


def frozen():
    for baryons in (0,1):
        prof=Profile(baryons)
        val=prof.data(np.array([SOL,RC]))
        src=prof.rest.total*KG/MSUN
        yield dict(ordinary_cloud=baryons,solar_density=UNIT*Q**2*val["amp"][0]**2,
                   outer_mass_msun=val["m"][1]*KG/MSUN-src,solar_radius_kpc=SOL*LENGTH/parsec/1000,
                   outer_radius_kpc=RC*LENGTH/parsec/1000,source_radius_of_density_normalization_pc=6*LENGTH/parsec)


if __name__=="__main__":
    for name,method in (("galactic-scale-control",records),("galactic-frozen",frozen)):
        rows=write_table(name+".csv",method(),sys.argv[1]=="create")
        print(name,rows[len(rows)//2])
