import sys
from halo_mean import HOME, bridge, np, guard, TOL, write_table
from bound_cycle import Laboratory, SHELLS, TIMES
from read_run import packet, peak, PHASES, component


def run(mode,phase,mesh):
    old=packet(mode,phase,mesh)
    dest=HOME/f"shape-{mode}-{phase}-{mesh}.npz"
    if dest.exists():
        raise FileExistsError(dest)
    lab=Laboratory(mesh,mode,phase)
    xx=lab.x
    mid=np.searchsorted(xx,SHELLS)
    mask=(xx<7)&(xx>.15)
    def quart(data):
        return (9*(data[...,mid]+data[...,mid-1])-(data[...,mid+1]+data[...,mid-2]))/16
    finite=mode=="finite"
    state=lab.launch() if finite else None
    data=[]
    inv=[]
    steps=int(np.ceil(mesh*.01/.42))
    dt=.01/steps
    for tick,time in enumerate(TIMES):
        fields=lab.dynamics(state,time,True) if finite else lab.read_forecast(time)
        mass,press,disp,vel,dnu,js,jb,force,den,angular,constraint=fields
        assert np.array_equal((mass[...,mid]+mass[...,mid-1])/2,old["diag"][tick,0])
        data.append(quart(np.stack((mass,xx**2*(js+jb),press,disp,vel,constraint))))
        if tick%10==0:
            ang=angular+lab.mul(lab.angprime,disp)
            inv.append([time,peak(ang[3,mask])/max(peak(angular[3,mask]),1e-290)])
        if tick%50==0:
            guard()
        if finite and tick<450:
            for sub in range(steps):
                start=time+dt*sub
                first=lab.dynamics(state,start)
                second=lab.dynamics(state+dt*first/2,start+dt/2)
                third=lab.dynamics(state+dt*second/2,start+dt/2)
                fourth=lab.dynamics(state+dt*third,start+dt)
                state+=dt/6*(first+2*second+2*third+fourth)
    bridge.archive(dest,result=np.array(data),inv=np.array(inv),receipt=np.bytes_(bridge.sha(HOME/f"{mode}-{phase}-{mesh}.npz")))
    print(dest.name,flush=True)


def records():
    for phase in PHASES:
        banks={}
        for mode in ("finite","forecast"):
            for mesh in (128,256):
                part=bridge.read(HOME/f"shape-{mode}-{phase}-{mesh}.npz")
                assert part["receipt"].item().decode()==bridge.sha(HOME/f"{mode}-{phase}-{mesh}.npz")
                banks[mode,mesh]=part["result"]
        for idx,radius in enumerate(SHELLS):
            for axis in ("supported","mixed"):
                def use(mode,mesh):
                    return component(banks[mode,mesh][:,:,:,idx].transpose(2,1,0),axis)
                fine,pred=use("finite",256),use("forecast",256)
                small,coarse=use("finite",128),use("forecast",128)
                def error(column):
                    return sum(peak(arr) for arr in (fine[column]-pred[column],fine[column]-small[column],pred[column]-coarse[column]))/peak(fine[column])
                yield dict(phase=phase,r=radius,axis=axis,mass=error(0),pressure=error(2),distance=error(3),velocity=error(4),
                           constraint=radius*peak(fine[5])/peak(fine[0]),passes=max(error(k) for k in (0,2,3,4))<=TOL)


if __name__=="__main__":
    if sys.argv[1] in PHASES:
        for mode in ("forecast","finite"):
            for mesh in (128,256):
                run(mode,sys.argv[1],mesh)
    else:
        print(sum(row["passes"] for row in write_table("radial-comparison.csv",records(),sys.argv[1]=="create")))
