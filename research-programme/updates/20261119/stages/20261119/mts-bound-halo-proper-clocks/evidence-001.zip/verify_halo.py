import csv
import json
import sys
from halo_mean import HOME, PRE, LOCK, TOL, bridge, guard, np, pack, write_table
from bound_cycle import lock
from read_run import packet, PHASES, clocks, motions, periods, calendars, jacobians
from radial_readout import records as radial
from occupation_envelope import calculate
from milkyway import records as scales, frozen
from free_ray import analysis
from outer_speed import controls, requirements
from quarter_prediction import predictions
from cloud_receiver import GEOMETRY


def chain(root, expected):
    assert bridge.sha(root/"seal.json")==expected
    receipt=json.loads((root/"seal.json").read_bytes())
    for name, digest in receipt["files"].items():
        assert bridge.sha(root/name)==digest,name
    return receipt


def verify():
    guard()
    parent=chain(PRE,LOCK)
    prior=chain(HOME.parent/"mts-single-cloud-clocks-20261119",parent["parent"])
    earlier=chain(HOME.parent/"mts-mixed-clock-transport-20261119",prior["parent"])
    assert all(bridge.sha(HOME.parent/name)==digest for name,digest in earlier["external"].items())
    assert bridge.sha(HOME.parent/"MTS-HEAVY-BATH-COUNTERFLOW-AND-GALACTIC-STRESS.md")==parent["retained_action"]
    for phase in PHASES:
        lock(phase)
        for mode in ("finite","forecast"):
            for mesh in (128,256):
                raw=packet(mode,phase,mesh)
                assert raw["diag"].shape==(451,11,4,6) and not raw["diag"][:,:,:2].any()
                assert all(np.isfinite(value).all() for value in raw.values() if value.dtype.kind in "fic")
                extra=bridge.read(HOME/f"shape-{mode}-{phase}-{mesh}.npz")
                assert extra["result"].shape==(451,6,4,6) and np.all(np.isfinite(extra["result"]))
                if mode=="finite":
                    assert np.max(raw["basic"][:,1:])<TOL and np.max(extra["inv"][:,1])<TOL
    envelope,branches=calculate()
    mean=pack(False)
    assert len(mean)==4 and all(row["passes"] for row in mean)
    inventory={"mean-checks.csv":4}
    tests=(("clocks",clocks(),72),("motions",motions(),24),("cycles",periods(),12),("calendar",calendars(),36),
           ("jacobians",jacobians(),24),("radial-comparison",radial(),24),("free-sightline",analysis(),2),
           ("galactic-scale-control",scales(),12),("galactic-frozen",frozen(),2),("occupation-envelope",envelope,1),
           ("density-branches",branches,24),("outer-speed-bound",controls(),4),
           ("outer-force-requirement",requirements(branches),24),("quarter-forecast",predictions(),12))
    for name,items,count in tests:
        rows=write_table(name+".csv",items,False)
        assert len(rows)==count,name
        inventory[name+".csv"]=count
        if name=="motions":
            missed={(row["phase"],row["r"],row["axis"]) for row in rows if not row["passes"]}
            assert missed=={(phase,.75,axis) for phase in PHASES for axis in ("mixed","supported")}
            assert all(max(row["energy_error"],row["radial_constraint"])<=TOL for row in rows)
        elif name=="cycles":
            assert all(row["oscillation_scale_pass"] and not row["net_pass"] for row in rows)
        elif name=="radial-comparison":
            assert all(row["passes"] and row["constraint"]<=TOL for row in rows)
        elif name=="galactic-scale-control":
            assert all(row["mass_reproduction"]<TOL for row in rows)
        elif name=="free-sightline":
            assert all(row["numerical_pass"] and row["bracket_after_nuisance_max_s"]<row["max_sampled_amplitude_s"] for row in rows)
        elif name=="outer-force-requirement":
            assert all((row["required_inward_baryon_v2_km2_s2"]>0)==(row["branch"]=="diffuse") for row in rows)
            assert all(row["max_required_inward_v2_at_plus3_km2_s2"]<0 for row in rows if row["branch"]=="concentrated")
        elif name=="outer-speed-bound":
            assert all(max(row["mass_equation_error"],row["density_equation_error"])<TOL for row in rows)
        else:
            assert all(row.get("passes",True) for row in rows),name
    assert {path.name for path in HOME.glob("*.csv")}==set(inventory)
    for name,count in inventory.items():
        with (HOME/name).open(newline="",encoding="utf8") as src:
            rows=list(csv.DictReader(src))
        assert len(rows)==count and all(None not in row and None not in row.values() for row in rows)
    assert not any(path.is_dir() or path.suffix in (".tmp",".pyc") for path in HOME.iterdir())
    files={path.name:bridge.sha(path) for path in sorted(HOME.iterdir()) if path.name!="seal.json"}
    sources={GEOMETRY/"epta-provenance.json",GEOMETRY/"epta-j1713-observing-days.csv"}
    for module in tuple(sys.modules.values()):
        path=getattr(module,"__file__",None)
        if path:
            from pathlib import Path
            src=Path(path).resolve()
            if src.is_relative_to(HOME.parent) and not src.is_relative_to(HOME) and src.suffix==".py":
                sources.add(src)
    dependencies={str(path.relative_to(HOME.parent)).replace(chr(92),"/"):bridge.sha(path) for path in sorted(sources)}
    return dict(parent=LOCK,verified_generations=[len(rec["files"]) for rec in (parent,prior,earlier)],
                inherited_external=len(earlier["external"]),inputs=dependencies,rows=inventory,files=files)


if __name__=="__main__":
    report=verify()
    output=HOME/"seal.json"
    if sys.argv[1:]==["seal"]:
        with output.open("x",encoding="utf8") as stream:
            json.dump(report,stream,sort_keys=True,indent=2)
    assert json.loads(output.read_bytes())==report
    print("VERIFIED",len(report["files"]),"files",sum(report["rows"].values()),"rows",bridge.sha(output))
