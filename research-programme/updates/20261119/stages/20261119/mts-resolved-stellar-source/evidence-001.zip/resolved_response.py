from stellar import HERE, PREV, Stars, np, G, guard, table, sha, json, sys, read
from field import Field, save
from common_shape import branch, disk_fields, disk_force, DISK_GM, OUTER, SPEED, ordinary, polish, ANCHOR
from geometry_state import arrangement, step
from numpy.polynomial.legendre import legvander


CONFIGS = {"mass-shape": ("catalogue", True), "catalogue": ("catalogue", False), "column": ("column", False)}
QUANTITIES = ("slope","Kz","annulus_billion")


def data(system, case, level="finer"):
    guard()
    source, equal_mass = CONFIGS[case]
    stars = Stars()
    field = Field(level+"-"+source)
    scale = DISK_GM/(G*stars.total) if equal_mass else 1.
    locations, radii, count, older, face_radii, heights, weights = arrangement()
    with np.load(HERE/"accepted-rings.npz") as bank:
        assert np.array_equal(bank["locations"], locations)
        rings = bank["values"][:, int(source=="column"), :]
    resolved = np.column_stack((rings[:,1],np.zeros(len(rings)),rings[:,2]))
    force = scale*resolved-disk_force(locations,3.)[0]
    physical = system.rad*system.length
    sphere = physical[:,None]
    legendre = legvander(system.mu,int(field.modes[-1]))[:,::2].T
    phi, gradient = field.multipoles(physical)
    disk, _, virial = disk_fields(sphere*np.sqrt(1-system.mu**2),sphere*system.mu,3.)
    return scale*(phi@legendre)-disk,scale*sphere*(gradient@legendre)-virial,force,scale


def flux(force):
    locations, radii, count, older, rr, zz, weights = arrangement()
    face, inner, outer = np.split(force[len(radii)+1:],3)
    return weights@(-rr*face[:,2]+.75*(9*outer[:,0]-7*inner[:,0]))/(G*1e9)


def freeze():
    system, seed = branch.load("main")
    parent = json.loads((PREV/"seal.json").read_bytes())["files"]
    filename = "arbitrary-source-weights.npz"
    assert sha(PREV/filename)==parent[filename]
    locations, radii, count, *_ = arrangement()
    ids = np.r_[count-1,len(radii)-3:len(radii)-1,len(radii):len(locations)]
    out=[]
    with np.load(PREV/filename) as kernels:
        assert np.array_equal(locations[ids],kernels["readout_xyz_kpc"])
        assert np.array_equal(system.rad*system.length,kernels["physical_radius_kpc"])
        for case in CONFIGS:
            for level in ("high","finer"):
                phi, _, force, scale = data(system,case,level)
                for key in QUANTITIES:
                    rearranged = np.sum(kernels[key]*phi)
                    for model in ("mts","nfw"):
                        direct = np.sum(kernels[key+"_direct_"+model]*force[ids])
                        indirect = rearranged if model=="mts" else 0.
                        out.append(dict(case=case,field_grid=level,model=model,quantity=key,scale=scale,
                                        direct_including_anchor=direct,calibrated_wave_response=indirect,predicted=direct+indirect))
    table("frozen-derivatives.csv",out)


def run(case, mode, seed_name="main", level="finer"):
    guard()
    assert (HERE/"frozen-derivatives.csv").is_file()
    prefix="-".join((case,mode,seed_name,level))
    system,seed=branch.load(seed_name)
    original_mass=float(seed["mass"])
    ext=system.ext.copy()
    vir=system.vir.copy()
    phi,virial,dforce,scale=data(system,case,level)
    loc,rad,count,older,*_=arrangement()
    cut=len(rad)
    bar,cloud,halo=ordinary(system,loc)
    initial=seed["coef"].copy()
    anchor=count-1
    original_halo=float(seed["nfw"])
    table_rows=[]; traces=[]; profiles=[]; packet={}
    incremental=mode!="tangent"
    path=(.25,.5,.75,1.) if incremental else (-1/64,1/64,-1/128,1/128)
    for fraction in path:
        guard()
        if not incremental:
            initial=seed["coef"].copy()
            system.mass=original_mass
        system.ext=ext+fraction*phi/system.vel**2
        system.vir=vir+fraction*virial/system.vel**2
        common=bar+cloud+fraction*dforce
        calibrated=mode!="fixed"
        for iteration in range(14):
            curve=polish(system,initial.copy())
            anchor_wave=system.force(curve.state,ANCHOR)[0,0]
            mismatch=OUTER*(common[anchor,0]+anchor_wave)-SPEED**2
            traces.append(dict(fraction=fraction,iteration=iteration,logmass=np.log(system.mass/original_mass),
                               anchor_speed2_residual=mismatch,residual=np.linalg.norm(curve.resid)))
            if not calibrated or abs(mismatch)<2e-12*SPEED**2:
                break
            tangent,_,_,_=curve.differentiate("mass")
            slope=OUTER*system.force(curve.state,ANCHOR,tangent=tangent)[0,0]
            assert slope>0
            delta=np.clip(-mismatch/slope,-.12,.12)
            system.mass*=np.exp(delta)
            initial=curve.state+delta*tangent
        else:
            raise RuntimeError("outer calibration did not converge")
        initial=curve.state.copy()
        amplitude=(SPEED**2/OUTER-common[anchor,0])/halo[anchor,0] if calibrated else original_halo
        assert amplitude>0 and abs(np.sum(initial**2)/system.mass-1)<1e-12
        wave=system.force(initial,loc)
        packet["state_"+str(fraction)]=initial.copy()
        packet["norm_"+str(fraction)]=system.mass
        for model,excess in (("mts",wave),("nfw",amplitude*halo)):
            total=common+excess
            speed=np.sqrt(rad*total[:cut,0])
            shape=(speed[-2]-speed[-3])/step
            assert np.isfinite(speed).all()
            table_rows.append(dict(case=case,mode=mode,seed=seed_name,field_grid=level,fraction=fraction,model=model,
                                   stellar_scale=scale,mass_msun=float(seed["mass_msun"])*system.mass/original_mass if model=="mts" else "",
                                   nfw_amplitude=amplitude if model=="nfw" else "",V_anchor=speed[anchor],slope=shape,
                                   double_step_slope=(speed[-4]-speed[-5])/(2*step),Kz=total[cut,2],annulus_billion=flux(total),
                                   common_annulus_billion=flux(common)))
            if fraction==1:
                for index in range(count+older):
                    profiles.append(dict(model=model,sample="cepheid" if index<count else "giant",R_kpc=rad[index],
                                         V_kms=speed[index],common_in=common[index,0],extra_in=excess[index,0]))
    save(prefix,**packet)
    table(prefix+"-path.csv",traces)
    table(prefix+"-result.csv",table_rows)
    if profiles:
        table(prefix+"-curves.csv",profiles)
    print(prefix, "finished",len(traces),"polishes",flush=True)


if __name__=="__main__":
    if sys.argv[1]=="freeze":
        freeze()
    else:
        run(*sys.argv[1:])

