from stellar import HERE,np,Stars,G,RCUT,ZCUT,nodes,roots_legendre,table,guard,sys
from scipy.special import ellipkm1,ellipe


def ring(stars,radius,height,nrad=6,nz=12,graded=False):
    edges=np.unique(np.r_[stars.cuts,np.clip([radius],0,RCUT),np.arange(0,30.1,1.)])
    radii,wr=nodes(edges,nrad)
    if graded:
        knots,weights=roots_legendre(nrad)
        fraction=(1+knots)/2
        for index,(lower,upper) in enumerate(zip(edges,edges[1:])):
            if lower==radius or upper==radius:
                span=slice(index*nrad,(index+1)*nrad)
                radii[span]=radius+(upper-lower)*(1 if lower==radius else -1)*fraction**3
                wr[span]=1.5*(upper-lower)*fraction**2*weights
    pts,weights=roots_legendre(nz)
    zs=np.unique(np.clip(np.r_[-10.,-5.,-2.,-.6,-.15,0.,.15,.6,2.,5.,10.,height],-10,10))
    out=np.zeros((2,3))
    for start in range(0,len(radii),32):
        rad=radii[start:start+32,None]
        rw=wr[start:start+32,None]
        separation=np.maximum(abs(radius-rad),1e-14)
        limits=np.arcsinh((zs[None,:]-height)/separation)
        widths=np.diff(limits,axis=1)/2
        uu=limits[:,:-1,None]+widths[:,:,None]*(1+pts)
        uu=uu.reshape(len(rad),-1)
        wz=(widths[:,:,None]*weights).reshape(len(rad),-1)*separation*np.cosh(uu)
        dz=separation*np.sinh(uu)
        small=(radius-rad)**2+dz**2
        big=(radius+rad)**2+dz**2
        complement=small/big
        first=ellipkm1(complement)
        second=ellipe(1-complement)
        fac=2*G*rad*rw*wz/np.sqrt(big)
        kernels=np.stack((-2*fac*first,fac/radius*(first+((radius-rad)*(radius+rad)-dz**2)/small*second),
                          2*fac*dz/small*second),axis=-1)
        expo=np.exp(-abs(height+dz)[:,:,None]/stars.height(rad[:,0])[:,None,:])
        mid=stars.radial(rad[:,0])
        for idx,norm in enumerate((stars.rho0,stars.column_norm)):
            density=np.einsum("rzk,rk->rz",expo,mid*norm,optimize=True)
            out[idx]+=np.einsum("rz,rzj->j",density,kernels,optimize=True)
    return out


def controls():
    stars=Stars()
    points=[(2.,0.),(6.58,0.),(8.3-.0025,0.),(8.3,0.),(8.3+.0025,0.),(8.3,1.5),(17.58,0.),(14.,1.),(37.,0.)]
    rows=[]
    for rr,zz in points:
        for nr,nz in ((5,10),(8,16)):
            fields=ring(stars,rr,zz,nr,nz)
            for kind,field in zip(("catalogue","column"),fields):
                rows.append(dict(R_kpc=rr,z_kpc=zz,radial_order=nr,vertical_order=nz,source=kind,
                                 phi=field[0],g_in=field[1],g_z=field[2]))
        print("ring",rr,zz,flush=True)
    table("ring-controls.csv",rows)


if __name__=="__main__":
    controls()
