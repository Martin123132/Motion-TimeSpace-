from stellar import HERE, Stars, np, read, table, nodes, guard, G
from field import Field, save
from ring_check import ring
from geometry_state import arrangement
from resolved_response import flux

TOL=2e-5


def run():
    stars=Stars()
    loc, rad, count, *_ = arrangement()
    with np.load(HERE/"resolved-direct.npz") as old, np.load(HERE/"resolved-graded.npz") as fine:
        assert np.array_equal(old["locations"],loc) and np.array_equal(fine["locations"],loc)
        base,graded=old["values"],fine["values"]
    error=abs(graded-base)/np.maximum(abs(graded),1.)
    focus=set(np.flatnonzero(np.any(error>TOL/2,axis=(1,2)))) | set(range(len(rad)-5,len(rad)+1)) | {count-1,0}
    vetted=graded.copy()
    rows=[]
    for index in sorted(focus):
        guard()
        radial,vertical=-loc[index,0],loc[index,2]
        extra=ring(stars,radial,vertical,14,30,True)
        for source in range(2):
            for component,name in enumerate(("phi","g_in","g_z")):
                diff=abs(extra[source,component]-graded[index,source,component])/max(abs(extra[source,component]),1.)
                rows.append(dict(index=index,R=radial,z=vertical,source=("catalogue","column")[source],quantity=name,
                                 raw_pair=error[index,source,component],refined_pair=diff,pass_20ppm=diff<TOL))
        vetted[index]=extra
    table("ring-refinement.csv",rows)
    assert all(row["pass_20ppm"] for row in rows),max(rows,key=lambda row:row["refined_pair"])
    volume=[]
    for idx,norm in enumerate((stars.rho0,stars.column_norm)):
        rr,wr=nodes(np.unique(np.clip(stars.cuts,7.,9.)),16)
        mass=2*np.pi*((rr*wr)@stars.column_shape(rr,1.5))@norm
        vec=np.column_stack((vetted[:,idx,1],np.zeros(len(loc)),vetted[:,idx,2]))
        ratio=flux(vec)*1e9/mass-1.
        volume.append(dict(source=("catalogue","column")[idx],volume_msun=mass,flux_msun=flux(vec)*1e9,relative_error=ratio))
    table("ring-annulus.csv",volume)
    assert all(abs(row["relative_error"])<TOL for row in volume),volume
    plummer=Field("base-plummer")
    radii=np.array([2.,6.58,8.3,17.58,37.,125.])
    points=np.column_stack((-radii,np.zeros((len(radii),2))))
    measured,field=plummer.physical(points)
    exact=-G*1e10/np.hypot(radii,2.)+G*1e10*4/(400**2+4)**1.5
    force=G*1e10*radii/(radii**2+4)**1.5
    plrows=[dict(R=rr,phi_rel=pp/qq-1,force_rel=aa/bb-1) for rr,pp,qq,aa,bb in zip(radii,measured,exact,field[:,0],force)]
    table("plummer-control.csv",plrows)
    assert np.max(abs(measured/exact-1))<TOL and np.max(abs(field[:,0]/force-1))<TOL
    central=ring(stars,2.,0.,14,30,True)
    report=[]
    extloc=np.vstack((loc,[[-2.,0.,0.]]))
    for idx,kind in enumerate(("catalogue","column")):
        target=np.vstack((vetted[:,idx],central[idx]))
        for level in ("high","finer"):
            field=Field(level+"-"+kind)
            phi,force=field.physical(extloc)
            calc=np.column_stack((phi,force[:,0],force[:,2]))
            for index in range(len(extloc)):
                delta=abs(calc[index]-target[index])/np.maximum(abs(target[index]),1.)
                report.append(dict(source=kind,grid=level,R=-extloc[index,0],z=extloc[index,2],
                                   phi_rel=delta[0],g_in_rel=delta[1],gz_rel=delta[2]))
            assert np.max(np.abs(calc[:,0]/target[:,0]-1.))<TOL if level=="finer" else True
    table("multipole-vs-ring.csv",report)
    save("accepted-rings",locations=loc,values=vetted)
    print("focus",len(focus),"of",len(loc),"max angular/radial refined difference",max(row["refined_pair"] for row in rows),"volume",volume,flush=True)


if __name__=="__main__":
    run()

