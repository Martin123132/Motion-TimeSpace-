from stellar import HERE, np, table, read, guard
from resolved_response import CONFIGS, data, arrangement, branch, ordinary
from disk_state import basis, families
from scipy.special import roots_legendre, eval_legendre


def angle_potential(system,coef,radius,cosines):
    scaled=radius/system.length
    edges=np.unique(np.r_[np.linspace(0.,system.edge,138),scaled])
    nodes, weights=roots_legendre(11)
    spans=np.diff(edges)[:,None]/2
    radii=(edges[:-1,None]+(1+nodes)*spans).ravel()
    factors=(spans*weights).ravel()
    wave=np.column_stack([basis(mode,root,system.edge,radii)@one for mode,root,one in zip(system.orders,system.roots,coef)])@system.angle.T
    factors*=radii**2/np.maximum(radii,scaled)
    density=(wave**2)@(system.aw[:,None]*system.extra)
    ratio=np.minimum(radii,scaled)/np.maximum(radii,scaled)
    return -system.vel**2*sum((factors*ratio**mode)@density[:,index]/np.sqrt(2*mode+1)*eval_legendre(mode,cosines)
                              for index,mode in enumerate(system.full) if mode!=0)


def run():
    guard()
    loc,rad,*_=arrangement()
    index=len(rad)
    point=loc[index:index+1]
    radius=np.linalg.norm(point)
    cylindrical=-point[0,0]
    height=point[0,2]
    ratio=height/cylindrical
    cosine=height/radius
    def angular(force):
        return force[0,2]+ratio*force[0,0]
    out=[]
    for case in CONFIGS:
        for mode,seed_name,level in (("calibrated","main","finer"),("fixed","main","finer"),("calibrated","above","high")):
            prefix="-".join((case,mode,seed_name,level))
            sysm,seed=branch.load(seed_name)
            with np.load(HERE/(prefix+".npz")) as packet:
                coef=packet["state_1.0"]
            bar,cloud,halo=ordinary(sysm,point)
            _,_,difference,scale=data(sysm,case,level)
            common=bar+cloud+difference[index:index+1]
            from common_shape import disk_force
            stellar=disk_force(point,3.)[0]+difference[index:index+1]
            wave=sysm.force(coef,point)
            controls=read(prefix+"-result.csv")
            amplitude=float(next(row for row in controls if row["model"]=="nfw" and float(row["fraction"])==1)["nfw_amplitude"])
            for model,extra in (("mts",wave),("nfw",amplitude*halo)):
                ang=angular(extra)
                derivatives=[]
                if model=="mts":
                    for spacing in (1e-3,5e-4):
                        samples=angle_potential(sysm,coef,radius,cosine+spacing*np.array([-2.,-1.,1.,2.]))
                        derivatives.append(-np.dot([1.,-8.,8.,-1.],samples)/(12*spacing*radius))
                    assert max(abs(val/ang-1) for val in derivatives)<2e-5
                else:
                    assert abs(ang)<1e-10
                out.append(dict(case=case,mode=mode,seed=seed_name,source_grid=level,model=model,R_kpc=cylindrical,z_kpc=height,
                                stellar_projected=angular(stellar),common_projected=angular(common),
                                excess_projected=ang,total_projected=angular(common+extra),
                                mean_subtraction_fraction_at_fixed_state=abs(ang/angular(stellar)),
                                fixed_radius_check=derivatives[-1] if derivatives else "",zerospherical=angular(halo)))
    table("offplane-shape.csv",out)


if __name__=="__main__":
    run()

