from stellar import HERE, guard, table, np, G, sys
from field import save
from resolved_response import CONFIGS, branch, data, flux, arrangement, ordinary, polish, OUTER, SPEED, ANCHOR, step


def refine(label,count,order):
    guard()
    with np.load(branch.HERE/(label+".npz")) as parent:
        seed=dict(parent)
    sysm=branch.DiskState(str(seed["label"]),count,order,float(seed["edge"]),float(seed["eta"]))
    ext,vir=sysm.ext.copy(),sysm.vir.copy()
    loc,rad,nc,*_=arrangement()
    cut=len(rad)
    bar,compact,halo=ordinary(sysm,loc)
    rows=[]; packets={}
    for case in CONFIGS:
        guard()
        parent_level="finer" if label=="main" else "high"
        with np.load(HERE/(case+"-calibrated-"+label+"-"+parent_level+".npz")) as saved:
            coeff=saved["state_1.0"]
            assert sysm.kin.shape[0]>=coeff.shape[0] and sysm.kin.shape[1]>=coeff.shape[1]
            initial=np.zeros_like(sysm.kin)
            initial[:coeff.shape[0],:coeff.shape[1]]=coeff
            sysm.mass=float(saved["norm_1.0"])
        pot,work,shift,scale=data(sysm,case,"finer")
        sysm.ext=ext+pot/sysm.vel**2
        sysm.vir=vir+work/sysm.vel**2
        common=bar+compact+shift
        for iteration in range(8):
            curve=polish(sysm,initial.copy())
            mismatch=OUTER*(common[nc-1,0]+sysm.force(curve.state,ANCHOR)[0,0])-SPEED**2
            if abs(mismatch)<2e-12*SPEED**2:
                break
            tangent,*_=curve.differentiate("mass")
            jac=OUTER*sysm.force(curve.state,ANCHOR,tangent=tangent)[0,0]
            corr=-mismatch/jac
            assert jac>0 and abs(corr)<.01
            initial=curve.state+corr*tangent
            sysm.mass*=np.exp(corr)
        else:
            raise RuntimeError("refined endpoint calibration failed")
        wave=sysm.force(curve.state,loc,panels=105)
        total=common+wave
        speeds=np.sqrt(rad*total[:cut,0])
        rows.append(dict(case=case,seed=label,count=count,order=order,mass_msun=float(seed["mass_msun"])*sysm.mass/float(seed["mass"]),
                         V_anchor=speeds[nc-1],slope=(speeds[-2]-speeds[-3])/step,Kz=total[cut,2],annulus_billion=flux(total),
                         projected_wave=wave[cut,2]+1.5/8.3*wave[cut,0],projected_total=total[cut,2]+1.5/8.3*total[cut,0],
                         stationarity=np.linalg.norm(curve.resid),virial=sysm.parts(curve.state)[3]))
        packets[case]=curve.state.copy()
        packets[case+"_mass"]=sysm.mass
        print(label,count,order,case,"finished",flush=True)
    tag=f"endpoint-{label}-{count}-{order}"
    save(tag,**packets)
    table(tag+".csv",rows)


if __name__=="__main__":
    refine(sys.argv[1],int(sys.argv[2]),int(sys.argv[3]))

