from stellar import HERE, guard, np, Stars, sys
from field import save
from geometry_state import arrangement
from ring_check import ring


def build(graded=False):
    stars = Stars()
    locations = arrangement()[0]
    memo = {}
    for point in locations:
        guard()
        key = (-point[0], point[2])
        if key not in memo:
            memo[key] = ring(stars, *key, 10 if graded else 8, 20 if graded else 16, graded)
    values = np.stack([memo[(-point[0], point[2])] for point in locations])
    save("resolved-graded" if graded else "resolved-direct", locations=locations, values=values)
    print(f"{len(locations)} readouts, {len(memo)} distinct ring integrations per source", flush=True)


if __name__ == "__main__":
    build("--graded" in sys.argv)
