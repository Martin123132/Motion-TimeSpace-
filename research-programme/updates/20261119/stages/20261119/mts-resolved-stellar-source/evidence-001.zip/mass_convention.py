from stellar import Stars,np,table,R0


def replay():
    stars=Stars()
    pop=stars.pop
    rs=np.linspace(1e-5,30.,1000)
    spacing=20/999
    heights=stars.height(rs)
    ratio=spacing/heights
    zint=2*spacing*np.exp(-ratio/2)*(-np.expm1(-500*ratio)/(-np.expm1(-ratio))-.5*np.exp(-499*ratio))
    normalized=np.trapezoid(stars.radial(rs)*zint,x=rs,axis=0)
    zpos=np.linspace(1e-5,10.,100)
    posint=np.trapezoid(np.exp(-zpos[:,None]/pop["PARAMS_MAX"][:,2]),x=zpos,axis=0)
    pub_scaled=pop["SMD_0"]*1e6/posint
    inferred=np.log(10)*pop["NU_0"]*normalized*pub_scaled*stars.fraction
    rows=[]
    for idx,row in enumerate(pop):
        rows.append(dict(alpha=row["ALPHA_M"].decode().strip(),cell=int(row["INDX_BIN"]),
                         m_tabulated=stars.mass[idx],m_replayed=inferred[idx],m_replay_over_table=inferred[idx]/stars.mass[idx],
                         max_height=row["PARAMS_MAX"][2],median_height=stars.h0[idx],
                         col_assumption_mass=stars.full[idx]*stars.column_norm[idx],
                         one_side_integral_kpc=posint[idx],flat_RZ_integral_kpc2=normalized[idx],axisym_integral_kpc3=stars.full[idx]))
    table("normalization-replay.csv",rows)
    print("notebook replay / archived M", np.min(inferred/stars.mass), np.max(inferred/stars.mass),inferred.sum()/stars.total)


if __name__=="__main__":
    replay()
