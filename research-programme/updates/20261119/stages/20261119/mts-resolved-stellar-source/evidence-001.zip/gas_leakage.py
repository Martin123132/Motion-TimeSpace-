from stellar import np, read, table, nodes, G, HERE, guard
from spatial_null import RADII, HEIGHT
from scipy.special import kv, roots_legendre, ellipkm1, ellipe
from scipy.integrate import quad


def force(row,radius,order,end):
    rd,rm,zd,central=(float(row[key]) for key in ("Rd_kpc","Rm_kpc","zd_kpc","Sigma0_msun_pc2"))
    limits=np.unique(np.r_[0.,np.arange(.5,23,.5),25.,30.,40.,60.,90.,end,radius])
    radii,weights=nodes(limits,order)
    rule,wz=roots_legendre(2*order)
    zcuts=np.unique(np.r_[-5.,-2.,-1.,HEIGHT,1.,2.,5.,0.,zd*np.array([-8.,-4.,-2.,-1.,1.,2.,4.,8.])])
    radius_field=0.;vertical_field=0.
    for start in range(0,len(radii),32):
        radial=radii[start:start+32,None]
        distance=abs(radial-radius)
        breaks=np.arcsinh((zcuts-HEIGHT)/distance)
        spans=np.diff(breaks,axis=1)/2
        tau=(breaks[:,:-1,None]+spans[:,:,None]*(1+rule)).reshape(len(radial),-1)
        dz=distance*np.sinh(tau)
        height=HEIGHT+dz
        thick=np.exp(-abs(height)/zd)
        vertical=thick/(zd*(1+thick)**2)
        measure=(spans[:,:,None]*wz).reshape(len(radial),-1)*distance*np.cosh(tau)
        density=1e6*central*np.exp(-rm/radial-radial/rd)*vertical
        small=distance**2+dz**2
        big=(radius+radial)**2+dz**2
        ratio=small/big
        first,second=ellipkm1(ratio),ellipe(1-ratio)
        base=2*G*radial*weights[start:start+32,None]*measure*density/np.sqrt(big)
        radius_field+=np.sum(base/radius*(first+((radius-radial)*(radius+radial)-dz**2)*second/small))
        vertical_field+=np.sum(2*base*dz*second/small)
    return np.array([radius_field,vertical_field])


def compute():
    guard()
    with np.load(HERE/"spatial-null-weights.npz") as pack:
        weights=pack["weight"]
    output=[]; leakage=[]
    for row in read("gas-source-input.csv"):
        rd,rm,central=(float(row[key]) for key in ("Rd_kpc","Rm_kpc","Sigma0_msun_pc2"))
        mass=4*np.pi*rd*rm*kv(2,2*np.sqrt(rm/rd))*central*1e6
        independent=quad(lambda rr:2*np.pi*rr*np.exp(-rm/rr-rr/rd)*central*1e6,0,np.inf,epsrel=1e-11)[0]
        solar=central*np.exp(-rm/8.33-8.33/rd)
        assert abs(mass/independent-1)<1e-10
        assert abs(mass/float(row["rounded_mass_msun"])-1)<.05 and abs(solar/float(row["Sigma_at_8p33_rounded"])-1)<.04
        previous=None
        for order,end in ((10,150.),(18,220.)):
            forces=np.array([force(row,rr,order,end) for rr in RADII])
            template=forces[:,1]+HEIGHT/RADII*forces[:,0]
            signal=weights@template
            leakage.append(dict(component=row["component"],order=order,radial_limit=end,analytic_mass=mass,
                                direct_mass=independent,solar_column=solar,weighted_angular=signal))
            for rr,fields,angle in zip(RADII,forces,template):
                output.append(dict(component=row["component"],order=order,R=rr,z=HEIGHT,g_in=fields[0],gz=fields[1],angular=angle))
            if previous is not None:
                assert np.max(abs(forces-previous)/np.maximum(1.,abs(forces)))<2e-5
                assert abs(signal/previous_signal-1)<2e-5
            previous,previous_signal=forces,signal
    table("gas-direct-only.csv",output)
    table("gas-null-leakage.csv",leakage)
    print([(row["component"],row["weighted_angular"]) for row in leakage if row["order"]==18],flush=True)


if __name__=="__main__":
    compute()

