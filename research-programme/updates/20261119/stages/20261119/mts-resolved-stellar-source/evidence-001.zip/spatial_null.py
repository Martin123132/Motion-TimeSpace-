from stellar import HERE, np, Stars, guard, table, read, sys
from ring_check import ring
from resolved_response import CONFIGS, branch, ordinary, disk_force
from field import save

RADII=np.array([6.,8.3,12.])
HEIGHT=1.5
POINTS=np.column_stack((-RADII,np.zeros(3),np.full(3,HEIGHT)))


def angular(forces):
    return forces[:,2]+HEIGHT/RADII*forces[:,0]


def freeze():
    stars=Stars()
    rows=[]; vectors=[]
    for order in (10,14):
        fields=np.array([ring(stars,radius,HEIGHT,order,2*order+2,True) for radius in RADII])
        values=fields[:,:,2]+(HEIGHT/RADII)[:,None]*fields[:,:,1]
        weight=np.cross(values[:,0],values[:,1])
        weight=weight*np.sign(weight[0])/np.linalg.norm(weight)
        vectors.append(weight)
        for index,radius in enumerate(RADII):
            rows.append(dict(order=order,R=radius,z=HEIGHT,catalogue=values[index,0],column=values[index,1],weight=weight[index]))
    assert np.linalg.norm(vectors[0]-vectors[1])<1e-7
    assert np.max(abs(weight@values))<1e-10
    table("spatial-null-frozen.csv",rows)
    save("spatial-null-weights",weight=weight,values=values,positions=POINTS)


def test():
    guard()
    with np.load(HERE/"spatial-null-weights.npz") as pack:
        weights,values=pack["weight"],pack["values"]
        assert np.array_equal(POINTS,pack["positions"])
    rows=[]
    for seed,level in (("main","finer"),("above","high")):
        sysm,init=branch.load(seed)
        bar,compact,halo=ordinary(sysm,POINTS)
        spherical_bary=angular(bar+compact-disk_force(POINTS,3.)[0])
        assert np.max(abs(spherical_bary))<1e-9
        for case in CONFIGS:
            idx=int(case=="column")
            for mode in (("calibrated","fixed") if seed=="main" else ("calibrated",)):
                prefix=case+"-"+mode+"-"+seed+"-"+level
                last=[row for row in read(prefix+"-result.csv") if float(row["fraction"])==1.]
                stellar=values[:,idx]*float(last[0]["stellar_scale"])
                amp=float(next(row["nfw_amplitude"] for row in last if row["model"]=="nfw"))
                with np.load(HERE/(prefix+".npz")) as saved:
                    state=saved["state_1.0"]
                nonradial=angular(sysm.force(state,POINTS))
                for model,additional in (("mts",nonradial),("nfw",angular(amp*halo))):
                    total=stellar+spherical_bary+additional
                    retained=weights@total
                    assert abs(retained-weights@additional)<1e-10
                    rows.append(dict(case=case,seed=seed,mode=mode,model=model,T_excess_6=additional[0],
                                     T_excess_8p3=additional[1],T_excess_12=additional[2],weighted_excess=weights@additional,
                                     weighted_total=retained,weighted_stellar=weights@stellar,
                                     residual_fraction_of_wave_norm=abs(retained)/np.linalg.norm(nonradial) if model=="mts" else "",
                                     shape_error_break_even_fraction=abs(retained)/np.sum(abs(weights*stellar))))
    table("spatial-null-results.csv",rows)


if __name__=="__main__":
    (freeze if sys.argv[1]=="freeze" else test)()

