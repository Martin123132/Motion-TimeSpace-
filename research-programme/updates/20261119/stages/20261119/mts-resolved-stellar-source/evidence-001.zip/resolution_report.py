from stellar import np, HERE, table, read, json, guard
from types import SimpleNamespace
from scipy.special import roots_legendre
from disk_state import families,root_values
from resolved_response import branch, CONFIGS
from spatial_null import RADII, HEIGHT
from angular_force import angle_potential


def report():
    guard()
    with np.load(HERE/"spatial-null-weights.npz") as pack:
        frozen=pack["weight"]
    rows=[]; comparisons=[]; saved={}
    for label in ("main","above"):
        with np.load(branch.HERE/(label+".npz")) as source:
            parent=dict(source)
        with np.load(branch.PARENT/("angular24-cap.npz" if label=="above" else "angular28-diff.npz")) as physical:
            vel=float(physical["velocity_unit_kms"])
        for count,order in ((256,24),(320,28),(384,32)):
            tag=f"endpoint-{label}-{count}-{order}"
            params=read(tag+".csv")
            rule,aw=roots_legendre(max(64,3*order+32))
            orders=np.arange(0,order+1,2)
            full=np.arange(0,2*order+1,2)
            sysm=SimpleNamespace(length=float(parent["length"]),vel=vel,edge=float(parent["edge"]),orders=orders,full=full,
                                 roots=[root_values(mode,count) for mode in orders],angle=families((1+rule)/2,orders),aw=aw/2,
                                 extra=families((1+rule)/2,full))
            with np.load(HERE/(tag+".npz")) as states:
                for item in params:
                    case=item["case"]
                    assert abs(float(item["V_anchor"])-224.03)<1e-8 and float(item["stationarity"])<1e-10
                    radius=np.hypot(RADII,HEIGHT)
                    shift=.0005
                    angles=[-np.dot([1.,-8.,8.,-1.],angle_potential(sysm,states[case],rr,HEIGHT/rr+shift*np.array([-2.,-1.,1.,2.])))
                            /(12*shift*rr) for rr in radius]
                    assert abs(angles[1]/float(item["projected_wave"])-1)<2e-5
                    data={key:float(item[key]) for key in ("slope","Kz","annulus_billion","mass_msun","projected_wave")}
                    data["spatial_null"]=float(frozen@angles)
                    rows.append(dict(seed=label,count=count,order=order,case=case,**data))
                    saved[(label,count,case)]=data
    for case in CONFIGS:
        for first,second,kind in [(("main",384),("above",384),"independent_fine_endpoint"),
                                  (("main",384),("main",320),"main_successive"),(("above",384),("above",320),"above_successive")]:
            for key,left in saved[(*first,case)].items():
                right=saved[(*second,case)][key]
                relative=abs(left/right-1.)
                comparisons.append(dict(case=case,comparison=kind,quantity=key,left=left,right=right,
                                        relative=relative,meets_20ppm=relative<2e-5))
    table("resolved-endpoints.csv",rows)
    table("resolved-comparisons.csv",comparisons)
    assert all(row["spatial_null"]>0 for row in rows)
    print("Conservative scales and any precision misses saved",flush=True)


if __name__=="__main__":
    report()

