from transport import *


class Dust:
    def __init__(self,mesh,alg,weight):
        self.d=Radial(mesh,"tensor",0.,0.,RADIUS)
        self.x=self.d.x
        self.unit=base(np.ones_like(self.x))
        self.alg=alg
        self.weight=weight

    def rhs(self,state):
        metric,angular,kr,kt,mass,field,normal,number=state
        ar=self.alg
        mul=ar.product
        aa,cc=self.unit+metric,self.unit+angular
        ia,ic=ar.reciprocal(aa),ar.reciprocal(cc)
        length,root=ar.root(aa),ar.root(cc)
        il,ir=ar.reciprocal(length),ar.reciprocal(root)
        dr,dc,dh=self.d.diff(state[[0,1,5]],self.d.d1)
        slope=mul(dh,il)
        kin=ar.stress(mul(normal,normal),self.weight)
        grad=ar.stress(mul(slope,slope),self.weight)
        pot=ar.stress(mul(field,field),self.weight)
        press=(kin+grad-pot)/2
        rho=mul(number,mul(il,ic))
        current=-ar.stress(mul(normal,slope),self.weight)
        rx=root+self.x*mul(dc,ir)/2
        angular_k=mul(kt,ic)
        radial_k=mul(kr,ia)
        enclosed=mul(mass,mul(ic,ir))
        motion=-self.x*mul(root,angular_k)
        rate=np.empty_like(state)
        rate[0],rate[1]=-2*kr,-2*kt
        rate[2]=mul(aa,rho+kin-grad-2*enclosed)-mul(kr,radial_k)
        rate[3]=mul(cc,enclosed+press-mul(angular_k,angular_k))
        rate[4]=-mul(cc,mul(press,motion)+mul(current,mul(rx,il)))/self.x
        rate[5]=normal
        rate[6]=mul(ia,self.d.diff(self.x*field,self.d.d2,True)/self.x+mul(mul(dc,ic)-mul(dr,ia)/2,dh))-field+mul(radial_k+2*angular_k,normal)
        rate[7]=0.
        return rate


def neutral_lock(create=False):
    signatures("light")
    files={name:bridge.sha(HERE/name) for name in ("light.json","NEUTRAL-PROTOCOL.md","neutral.py","dust_clock.py")}
    if create:
        put("neutral-input.json",files)
    else:
        assert json.loads((HERE/"neutral-input.json").read_bytes())==files


def run(mesh):
    guard()
    neutral_lock()
    ar=Algebra(1,1)
    state,launch=initial(mesh,ar,.01,weights(),1e-6,0.)
    assert not np.any(state[[8,9]])
    state=state[:8].copy()
    scheme=Dust(mesh,ar,weights())
    space=scheme.x
    masks={site:(space>=low-.09)&(space<=low+.59) for site,low in LOCATIONS.items()}
    strips={site:[] for site in masks}
    steps=int(np.ceil(.01*mesh/.42))
    dt=.01/steps
    for tick in range(450*steps+1):
        if tick%steps==0:
            length=ar.root(scheme.unit+state[0])
            shift=ar.product(state[0],ar.reciprocal(scheme.unit+length))
            rate=ar.product(state[2],ar.reciprocal(length))
            for site,mask in masks.items():
                strips[site].append(np.stack((shift[:,mask],rate[:,mask])))
        if tick%(50*steps)==0:
            guard()
        if tick==450*steps:
            break
        first=scheme.rhs(state)
        second=scheme.rhs(state+dt*first/2)
        third=scheme.rhs(state+dt*second/2)
        fourth=scheme.rhs(state+dt*third)
        state+=dt/6*(first+2*second+2*third+fourth)
    assert np.isfinite(state).all()
    out=dict(emission=EMISSIONS,launch=launch,receipt=np.bytes_(bridge.sha(HERE/"neutral-input.json")))
    for site,mask in masks.items():
        raw=np.array(strips.pop(site))
        for panels in (32,64):
            surface=OpticalSurface(np.arange(451)*.01,space[mask],raw,LOCATIONS[site],panels,3)
            out[f"{site}_{panels}"]=clocks(surface,ar,panels,3)
            if panels==64:
                out[f"{site}_quadratic"]=clocks(surface,ar,panels,2)
    archive(f"neutral-{mesh}.npz",**out)
    print("neutral",mesh,flush=True)


if __name__=="__main__":
    if sys.argv[1]=="freeze":
        neutral_lock(True)
    else:
        run(int(sys.argv[1]))
