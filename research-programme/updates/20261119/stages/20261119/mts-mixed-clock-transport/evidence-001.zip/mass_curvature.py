from measure import *
from math import factorial


def complex_initial(mesh,step):
    setup=Launch(mesh,.8)
    radius,inverse=setup.radius,setup.inv
    density,gauss,_,_=profile(radius,WAVE)
    dn=.01*setup.number[0]*density
    dq=.008*setup.number[0]*gauss
    number=base(1j*step*(setup.number+dn/2))
    charge=base(1j*step*(setup.charge+dq/2))
    number[1]=dn
    charge[1]=dq
    ar=Algebra(0,1)
    weight=weights()
    mass=base(np.zeros_like(number[0]))
    unit=base(np.ones_like(radius))
    electric=ar.product(charge,charge)*inverse**4/2
    for attempt in range(24):
        fac=unit-2*mass*inverse
        energy=ar.product(number,ar.root(fac))+electric+ar.stress(base(setup.height**2)+fac*setup.slope**2,weight)/2
        after=np.stack([primitive(radius,line.real*radius**2)+1j*primitive(radius,line.imag*radius**2) for line in energy])
        if attempt>10 and np.all(np.max(abs(mass-after),axis=1)<2e-14*np.maximum(np.max(abs(after),axis=1),1e-290)):
            mass=after
            break
        mass=after
    else:
        raise ArithmeticError("mixed Hessian constraint")
    delta=2*mass*inverse
    metric=ar.product(delta,ar.reciprocal(unit-delta))
    take=setup.picks
    zero=np.zeros((4,len(take)),dtype=complex)
    state=np.stack((metric[:,take],zero,zero,zero,(mass*inverse**3)[:,take],base(setup.height[take]),zero,
                    number[:,take],zero,charge[:,take]))
    return state,mass[:,-1]


def complex_clocks(surface,alg,panels,degree):
    width=.5/panels
    start=base(EMISSIONS.astype(complex))
    def leg(emission,back):
        state=np.zeros((2,4,len(EMISSIONS)),dtype=complex)
        def rhs(node,trial):
            time=emission+trial[0]
            time[0]+=node*width/2
            pivot=time[0].real
            dx=time.copy()
            dx[0]=1j*time[0].imag
            pos=2*panels-node if back else node
            assert min(pivot)>=0 and max(pivot)<=4.5
            result=surface.local[0][pos](pivot).transpose(1,2,0).copy()
            power=dx
            for order in range(1,degree+1):
                rate=surface.local[order][pos](pivot).transpose(2,1,0)
                result+=alg.product(rate,power[:,None,:]).transpose(1,0,2)/factorial(order)
                if order<degree:
                    power=alg.product(power,dx)
            return result
        for panel in range(panels):
            node=2*panel
            first=rhs(node,state)
            second=rhs(node+1,state+width*first/2)
            third=rhs(node+1,state+width*second/2)
            fourth=rhs(node+2,state+width*third)
            state+=width/6*(first+2*second+2*third+fourth)
        return state
    first=leg(start,False)
    reflection=start+first[0]
    reflection[0]+=.5
    back=leg(reflection,True)
    return np.stack((alg.exponential(first[1])[3],alg.exponential(first[1]+back[1])[3],first[0,3],(first[0]+back[0])[3]))


def freeze(step,create=False):
    signatures("light")
    files=["light.json","CURVATURE-PROTOCOL.md","mass_curvature.py"]
    if step=="held":
        freeze("setup")
        files+=["hessian-setup.json"]
        files += [f"hessian-{mesh}-{order}.npz" for mesh in (128,256) for order in (64,128)]
        files += [label("masscoefficient",mesh,"plus") for mesh in (128,256)]
        files += ["mass_forecast.py","mass-forecast.npz"]
    data={name:bridge.sha(HERE/name) for name in files}
    name=f"hessian-{step}.json"
    if create:
        put(name,data)
    else:
        assert json.loads((HERE/name).read_bytes())==data


def run(mesh,order):
    guard()
    held=order==0
    step="held" if held else "setup"
    freeze(step)
    name=f"held-1pct-{mesh}.npz" if held else f"hessian-{mesh}-{order}.npz"
    if (HERE/name).exists():
        raise FileExistsError(name)
    ar=Algebra(1 if held else 0,1)
    if held:
        state,masses=initial(mesh,ar,.01,weights(),.01,.8)
    else:
        state,masses=complex_initial(mesh,1/order)
    scheme=System(mesh,ar,weights(),.8,held)
    space=scheme.space
    masks={site:(space>=low-.09)&(space<=low+.59) for site,low in LOCATIONS.items()}
    strips={site:[] for site in masks}
    steps=int(np.ceil(.01*mesh/.42))
    dt=.01/steps
    for tick in range(450*steps+1):
        if tick%steps==0:
            length=ar.root(scheme.unit+state[0])
            shift=ar.product(state[0],ar.reciprocal(scheme.unit+length))
            rate=ar.product(state[2],ar.reciprocal(length))
            for site,mask in masks.items():
                strips[site].append(np.stack((shift[:,mask],rate[:,mask])))
        if tick%(50*steps)==0:
            guard()
        if tick==450*steps:
            break
        first=scheme.rhs(state)
        second=scheme.rhs(state+dt*first/2)
        third=scheme.rhs(state+dt*second/2)
        fourth=scheme.rhs(state+dt*third)
        state+=dt/6*(first+2*second+2*third+fourth)
    assert np.isfinite(state).all()
    out=dict(emission=EMISSIONS,mass=masses,step=0. if held else 1/order,
             receipt=np.bytes_(bridge.sha(HERE/f"hessian-{step}.json")))
    for site,mask in masks.items():
        strip=np.array(strips.pop(site))
        for panels in (32,64):
            surface=OpticalSurface(np.arange(451)*.01,space[mask],strip,LOCATIONS[site],panels,3)
            for degree in ((3,2) if panels==64 else (3,)):
                key=site+"_"+("quadratic" if degree==2 else str(panels))
                out[key]=(clocks(surface,ar,panels,degree)[:,3] if held else complex_clocks(surface,ar,panels,degree))
    archive(name,**out)
    print(name,flush=True)


if __name__=="__main__":
    if sys.argv[1]=="freeze":
        freeze(sys.argv[2],True)
    else:
        for raw in sys.argv[2:]:
            run(int(sys.argv[1]),int(raw))
