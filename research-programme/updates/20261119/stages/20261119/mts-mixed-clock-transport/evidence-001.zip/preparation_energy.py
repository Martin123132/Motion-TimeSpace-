from measure import *
from scipy.special import betainc
from scipy.interpolate import PchipInterpolator


def run():
    rows=[]
    scales=json.loads((GEO/"physical-clock-scale.json").read_bytes())
    from scipy.constants import G
    unit=scales["length_pc"]*parsec*c**4/G
    for mesh in (128,256):
        setup=Launch(mesh,0.)
        rr,iv=setup.radius,setup.inv
        initial_number=.002*betainc(1.5,7,np.minimum((rr/5)**2,1))
        assert peak(primitive(rr,rr**2*setup.number)-initial_number)<5e-14*initial_number[-1]
        shape,gauss,_,_=profile(rr,WAVE)
        for frac in (1.,.01,.001,1e-6):
            old_n=frac*setup.number
            cumulative=frac*initial_number
            center_u=old_n[0]/3
            angular=np.arccos(1.01**(-1/6))
            time_to_one=(angular+np.sin(angular)*np.cos(angular))/np.sqrt(2*center_u)
            limit=3.4
            theta=limit*np.sqrt(2*center_u)/2
            for iteration in range(8):
                theta-=(theta+np.sin(theta)*np.cos(theta)-limit*np.sqrt(2*center_u))/(2*np.cos(theta)**2)
            center_gain=np.expm1(-6*np.log1p(-2*np.sin(theta/2)**2))
            for eta in (0.,.8,1.):
                charge=eta*cumulative
                if eta==1:
                    mass=cumulative-cumulative**2*iv/2
                else:
                    mass=np.zeros_like(rr)
                    for iteration in range(12):
                        mass=primitive(rr,rr**2*old_n*np.sqrt(1-2*iv*mass)+(charge*iv)**2/2)
                fac=1-2*iv*mass
                root=np.sqrt(fac)
                for sign,e in (("plus",.01),("minus",-.01)):
                    dn=e*old_n[0]*shape
                    dcount=e*old_n[0]*gauss
                    dq=eta*dcount
                    difference=dcount.copy()
                    for iteration in range(16):
                        drag=2*rr*(old_n+dn)/(root+np.sqrt(fac-2*iv*difference))
                        eq=(-rr**2*dn*2*iv*mass/(1+root)-drag*dcount+(charge+dq/2)*dq*iv**2)
                        kernel=np.exp(primitive(rr,drag))
                        after=dcount+primitive(rr,kernel*eq)/kernel
                        if np.array_equal(after,difference):
                            break
                        difference=after
                    assert dcount[-1]==dq[-1]==0.
                    gravitational=-primitive(rr,iv**2*(cumulative+dcount/2)*dcount)[-1]
                    electrostatic=-eta**2*gravitational
                    newtonian=gravitational+electrostatic
                    discrepancy=(abs(difference[-1]-newtonian)/abs(difference[-1]) if eta<1 else
                                 abs(difference[-1])/abs(gravitational))
                    assert discrepancy < (.02 if eta<1 else 2e-8)
                    inside=rr<=3
                    remap=PchipInterpolator((cumulative+dcount)[inside],rr[inside])(cumulative[inside])-rr[inside]
                    rows.append(dict(mesh=mesh,fraction=frac,eta=eta,sign=sign,net_number=dcount[-1],net_charge=dq[-1],
                                     exact_exterior_mass=(difference[-1] if eta<1 else 0.),numerical_exterior_mass=difference[-1],
                                     energy_difference_J=(difference[-1]*unit if eta<1 else 0.),newtonian_gravity=gravitational,
                                     electric_self_energy=electrostatic,newton_plus_em=newtonian,relative_or_extremal_null=discrepancy,
                                     shell_max_outward_pc=max(remap)*scales["length_pc"],shell_max_inward_pc=min(remap)*scales["length_pc"],
                                     neutral_years_for_one_percent_central_compression=(time_to_one*scales["time_unit_years"] if eta==0 else ""),
                                     neutral_central_fraction_at_final_emission=(center_gain if eta==0 else "")))
    return rows


if __name__=="__main__":
    compare("preparation-energy.csv",run(),sys.argv[1]=="create")
