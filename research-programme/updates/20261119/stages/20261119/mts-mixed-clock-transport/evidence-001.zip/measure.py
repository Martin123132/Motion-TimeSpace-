from transport import *
from functools import lru_cache
from scipy.constants import parsec,c

GEO=HERE.parent/"mts-two-radius-pressure-clock-20261119"
SEC=json.loads((GEO/"physical-clock-scale.json").read_bytes())["length_pc"]*parsec/c


def peak(vec):
    return float(np.max(np.abs(vec)))


@lru_cache(None)
def packet(mode,mesh,sign):
    bank=bridge.read(HERE/label(mode,mesh,sign))
    step={"target":"finite","dense":"finite","light3":"light","light6":"light"}.get(mode,"inputs")
    assert bank["receipt"].item().decode()==bridge.sha(HERE/(step+".json"))
    assert np.array_equal(bank["emission"],EMISSIONS)
    for site in LOCATIONS:
        assert bank[site+"_64"].shape==(4,4,len(EMISSIONS))
    return bank


def budgets():
    rows=[]
    for mode in ("target","light3","light6"):
        source="forecast" if mode=="target" else "masscoefficient"
        signs=("plus","minus") if mode=="target" else ("plus",)
        scale=setup(mode)[2]
        for sign in signs:
            for site in LOCATIONS:
                for index,channel in enumerate(CHANNELS):
                    def get(kind,mesh,panels):
                        curve=packet(kind,mesh,sign)[f"{site}_{panels}"][index,3]
                        return scale*curve if kind==source else curve
                    truth=get(mode,256,64)
                    pred=get(source,256,64)
                    norm=peak(truth)
                    assert norm>0
                    delta=(truth-pred,pred-get(source,128,64),truth-get(mode,128,64),
                           pred-get(source,256,32),truth-get(mode,256,32),
                           pred-get(source,256,"quadratic"),truth-get(mode,256,"quadratic"))
                    terms=[peak(term)/norm for term in delta]
                    idx=int(np.argmax(abs(truth)))
                    rows.append(dict(source=mode,sign=sign,link=site,channel=channel,peak_time=EMISSIONS[idx],
                                     signed_peak=truth[idx],delay_seconds=(truth[idx]*SEC if "delay" in channel else ""),
                                     forecast_at_peak=pred[idx],model=terms[0],prediction_grid=terms[1],target_grid=terms[2],
                                     prediction_ray=terms[3],target_ray=terms[4],prediction_composition=terms[5],
                                     target_composition=terms[6],total=sum(terms),passes=sum(terms)<=TOL))
    return rows


def correspondence():
    rows=[]
    for sign in ("plus","minus"):
        real=packet("target",256,sign)
        old=bridge.read(PRE/f"dilute-target-256-{sign}.npz")
        quiet=bridge.read(PRE/"dilute-target-256-quiet.npz")
        ordinary=bridge.read(HERE/f"ordinary-{sign}.npz")
        for site in LOCATIONS:
            for idx,ch in enumerate(CHANNELS):
                key=site+"_64"
                mixed=real[key][idx,3]
                material=real[key][idx,1]
                loading=real[key][idx,2]
                raw=old[key][idx]-quiet[key][idx]
                rows.append(dict(sign=sign,link=site,channel=ch,old_two_history_error=peak(mixed-raw)/peak(mixed),
                                 single_axis_quiet=peak(loading-quiet[key][idx])/peak(loading),
                                 single_axis_material=peak(material-ordinary[site][idx])/peak(material),
                                 electrovac=(peak(material-ordinary["electrovac"][idx])/peak(material) if site=="outer" else "")))
    return rows


def mass_null():
    previous=bridge.read(PRE/"mass-null.npz")
    rows=[]
    for sign in ("plus","minus"):
        for idx,ch in enumerate(CHANNELS):
            wave=packet("target",256,sign)["outer_64"][idx,3]
            static=previous[sign+"_narrow"][idx]
            for name,mask in (("early",EMISSIONS<=1.7),("late",EMISSIONS>=2.8)):
                residual=wave-static
                here=np.flatnonzero(mask)[np.argmax(abs(residual[mask]))]
                rows.append(dict(sign=sign,channel=ch,window=name,signal=peak(wave[mask]),static=peak(static[mask]),
                                 residual_over_signal=peak(residual[mask])/peak(wave[mask]),signed_residual=residual[here],emission=EMISSIONS[here]))
    return rows


def compare(name,rows,create):
    if create:
        table(name,rows)
    with (HERE/name).open(newline="",encoding="utf-8") as stream:
        assert list(csv.DictReader(stream))==[{key:str(val) for key,val in row.items()} for row in rows]


if __name__=="__main__":
    for name,rows in (("clock-budgets.csv",budgets()),("controls-and-old-results.csv",correspondence()),("monopole-residual.csv",mass_null())):
        compare(name,rows,sys.argv[1]=="create")
