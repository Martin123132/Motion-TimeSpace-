from measure import *


def records():
    rows=[]
    for mode in ("forecast","target","light3","light6"):
        mat,occ,_,_=setup(mode)
        alg=Algebra(mat,occ)
        for sign in (("plus","minus") if mode in ("forecast","target") else ("plus",)):
            for site in LOCATIONS:
                waves=packet(mode,256,sign)[site+"_64"]
                for idx,kind in enumerate(("out","echo")):
                    delay=waves[2+idx]
                    def from_delay(stride,degree):
                        fit=make_interp_spline(EMISSIONS[::stride],delay[:,::stride],axis=1,k=degree)
                        deriv=fit.derivative()(EMISSIONS)
                        deriv[0]+=1
                        return alg.reciprocal(deriv)
                    fine=from_delay(1,5)
                    half=from_delay(2,5)
                    alt=from_delay(1,7)
                    for axis,component in ((1,"ordinary_event"),(2,"quiet_occupation"),(3,"mixed")):
                        ref=waves[idx,axis]
                        for name,take in (("interior",slice(4,-4)),("whole",slice(None))):
                            norm=peak(ref[take])
                            assert norm>0
                            eq=peak((ref-fine[axis])[take])/norm
                            coarse=peak((fine[axis]-half[axis])[take])/norm
                            independent=peak((fine[axis]-alt[axis])[take])/norm
                            rows.append(dict(mode=mode,sign=sign,link=site,path=kind,component=component,window=name,
                                             frequency_vs_arrival_derivative=eq,sample_doubling=coarse,interpolant=independent,
                                             total=eq+coarse+independent,passes=eq+coarse+independent<=TOL))
    return rows


if __name__=="__main__":
    compare("frequency-from-arrival.csv",records(),sys.argv[1]=="create")
