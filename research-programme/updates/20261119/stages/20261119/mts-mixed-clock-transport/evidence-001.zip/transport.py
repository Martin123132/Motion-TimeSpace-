from rectangle import *
from scipy.interpolate import make_interp_spline, BSpline
from math import factorial


class OpticalSurface:
    def __init__(self,times,space,bank,low,panels,order):
        self.times=times
        radii=low+np.arange(2*panels+1)*(.5/(2*panels))
        assert radii[0]>=space[0] and radii[-1]<=space[-1]
        transverse=make_interp_spline(space,bank,k=5,axis=-1)(radii)
        temporal=make_interp_spline(times,transverse,k=5,axis=0)
        self.local=[]
        for degree in range(order+1):
            spline=temporal if degree==0 else temporal.derivative(degree)
            self.local.append([BSpline.construct_fast(spline.t,np.ascontiguousarray(spline.c[...,position]),spline.k,extrapolate=False)
                               for position in range(len(radii))])

    def sample(self,alg,time,position,order):
        pivot=time[0]
        increment=time.copy()
        increment[0]=0.
        assert min(pivot)>=self.times[0]-1e-15 and max(pivot)<=self.times[-1]
        output=self.local[0][position](pivot).transpose(1,2,0).copy()
        power=increment
        for degree in range(1,order+1):
            jets=self.local[degree][position](pivot).transpose(2,1,0)
            term=alg.product(jets,power[:,None,:])
            output+=term.transpose(1,0,2)/factorial(degree)
            if degree<order:
                power=alg.product(power,increment)
        return output


def clocks(surface,algebra,panels,order,emissions=EMISSIONS):
    step=.5/panels
    original=base(emissions)
    def leg(launch,reverse):
        result=np.zeros((2,4,len(emissions)))
        def rhs(index,state):
            time=launch+state[0]
            time[0]+=index*step/2
            position=2*panels-index if reverse else index
            return surface.sample(algebra,time,position,order)
        for panel in range(panels):
            index=2*panel
            first=rhs(index,result)
            second=rhs(index+1,result+step*first/2)
            third=rhs(index+1,result+step*second/2)
            fourth=rhs(index+2,result+step*third)
            result+=step/6*(first+2*second+2*third+fourth)
        return result
    one=leg(original,False)
    reflection=original+one[0]
    reflection[0]+=.5
    two=leg(reflection,True)
    single=algebra.exponential(one[1])
    echo=algebra.exponential(one[1]+two[1])
    single[0]=np.expm1(one[1,0])
    echo[0]=np.expm1(one[1,0]+two[1,0])
    return np.stack((single,echo,one[0],one[0]+two[0]))


def label(mode,mesh,sign):
    return f"{mode}-{mesh}-{sign}.npz"


def signatures(step,create=False):
    names=["rectangle.py","transport.py","PROTOCOL.md","controls.py","operator-controls.json"]
    if step in ("finite","light"):
        signatures("inputs")
        names.append("inputs.json")
        names.extend(label("forecast",mesh,sgn) for mesh in (128,256) for sgn in ("plus","minus"))
    if step=="light":
        names.extend(label("masscoefficient",mesh,"plus") for mesh in (128,256))
    values={name:bridge.sha(HERE/name) for name in names}
    values["parent"]=LOCK
    dest=step+".json"
    if create:
        put(dest,values)
    else:
        assert json.loads((HERE/dest).read_bytes())==values


def setup(mode):
    options={"forecast":(1,0,1.,False),"target":(1,1,1.,True),"masscoefficient":(0,1,1.,False),
             "light3":(1,1,1e-3,True),"light6":(1,1,1e-6,True),"dense":(1,1,1.,True)}
    return options[mode]


def simulate(mode,mesh,sign):
    guard()
    step={"target":"finite","dense":"finite","light3":"light","light6":"light"}.get(mode,"inputs")
    signatures(step)
    name=label(mode,mesh,sign)
    if (HERE/name).exists():
        raise FileExistsError(name)
    mat,occ,frac,conservative=setup(mode)
    amp={"plus":.01,"minus":-.01}[sign]
    weight=1. if mode=="dense" else weights()
    ar=Algebra(mat,occ)
    initial_state,launch=initial(mesh,ar,amp,weight,frac,.8)
    scheme=System(mesh,ar,weight,.8,conservative)
    space=scheme.space
    grids={site:(space>=low-.09)&(space<=low+.59) for site,low in LOCATIONS.items()}
    strips={site:[] for site in grids}
    state=initial_state
    steps=int(np.ceil(.01*mesh/.42))
    dt=.01/steps
    for tick in range(450*steps+1):
        if tick%steps==0:
            length=ar.root(scheme.unit+state[0])
            shift=ar.product(state[0],ar.reciprocal(scheme.unit+length))
            rate=ar.product(state[2],ar.reciprocal(length))
            for site,selection in grids.items():
                strips[site].append(np.stack((shift[:,selection],rate[:,selection])))
        if tick%(50*steps)==0:
            guard()
        if tick==450*steps:
            break
        first=scheme.rhs(state)
        second=scheme.rhs(state+dt*first/2)
        third=scheme.rhs(state+dt*second/2)
        fourth=scheme.rhs(state+dt*third)
        state+=dt/6*(first+2*second+2*third+fourth)
    assert np.isfinite(state).all()
    times=np.arange(451)*.01
    result=dict(emission=EMISSIONS,launch=launch,rules=np.array([mat,occ]),weight=weight,fraction=frac,
                amplitude=amp,receipt=np.bytes_(bridge.sha(HERE/(step+".json"))))
    for site,selection in grids.items():
        bank=np.array(strips.pop(site))
        for panels in (32,64):
            surface=OpticalSurface(times,space[selection],bank,LOCATIONS[site],panels,3)
            result[f"{site}_{panels}"]=clocks(surface,ar,panels,3)
            if panels==64:
                result[f"{site}_quadratic"]=clocks(surface,ar,panels,2)
    archive(name,**result)
    print(name,launch,flush=True)


if __name__=="__main__":
    if sys.argv[1]=="freeze":
        guard()
        signatures(sys.argv[2],True)
    else:
        for sign in sys.argv[3:]:
            simulate(sys.argv[1],int(sys.argv[2]),sign)
