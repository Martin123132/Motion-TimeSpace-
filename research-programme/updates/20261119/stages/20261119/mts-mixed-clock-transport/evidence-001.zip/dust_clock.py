from neutral import neutral_lock
from transport import *
from paired_clock import finite_ray
from fractions import Fraction


def coefficients(order):
    values=[Fraction(1)]
    invs=[Fraction(1)]
    for degree in range(order):
        reciprocal_square=sum(invs[idx]*invs[degree-idx] for idx in range(degree+1))
        values.append(-reciprocal_square/((2*degree+2)*(2*degree+1)))
        invs.append(-sum(values[idx]*invs[degree+1-idx] for idx in range(1,degree+2)))
    return np.array([float(entry) for entry in values])


def run(mesh):
    guard()
    neutral_lock()
    coords=Launch(mesh,0.)
    rr,inv=coords.radius,coords.inv
    density=1e-6*coords.number
    central=density[0]
    shape,gauss,_,_=profile(rr,WAVE)
    dn=.01*central*shape
    known=.01*central*gauss
    mass=np.zeros_like(rr)
    for iteration in range(12):
        mass=primitive(rr,rr**2*density*np.sqrt(1-2*inv*mass))
    fac=1-2*inv*mass
    root=np.sqrt(fac)
    delta=known.copy()
    for iteration in range(10):
        drag=2*rr*(density+dn)/(root+np.sqrt(fac-2*inv*delta))
        integrating=np.exp(primitive(rr,drag))
        correction=primitive(rr,integrating*(-rr**2*dn*2*inv*mass/(root+1)-drag*known))/integrating
        delta=known+correction
    new=np.sqrt(fac-2*inv*delta)
    mass_unit=mass*inv**3
    delta_unit=delta*inv**3
    tide=density*root-3*mass_unit
    dtide=dn*new-density*2*inv*delta/(root+new)-3*delta_unit
    coeff=coefficients(6)
    picks=coords.picks
    time=np.arange(451)*.01
    out=dict(emission=EMISSIONS,outer_mass_change=delta[-1],receipt=np.bytes_(bridge.sha(HERE/"neutral-input.json")))
    for site,low in LOCATIONS.items():
        take=picks[(rr[picks]>=low-.09)&(rr[picks]<=low+.59)]
        uu,du=mass_unit[take],delta_unit[take]
        hh,dh=tide[take],dtide[take]
        invroot=1/root[take]
        drroot=(2*inv*delta/(root*new*(root+new)))[take]
        static=(2*inv*mass/(root*(1+root)))[take]
        shape=(len(time),len(take))
        bank=np.zeros((len(time),4,len(take)))
        bank[:,0]+=static
        bank[:,2]+=drroot
        def dpow(exponent):
            return du*sum(uu**index*(uu+du)**(exponent-1-index) for index in range(exponent)) if exponent else np.zeros_like(uu)
        for degree in range(1,7):
            rate=coeff[degree]*(uu**degree+degree*uu**(degree-1)*hh)
            change=coeff[degree]*(dpow(degree)+degree*(dpow(degree-1)*hh+(uu+du)**(degree-1)*dh))
            length=rate*invroot
            mixed=change*(invroot+drroot)+rate*drroot
            power=time[:,None]**(2*degree)
            deriv=(2*degree)*time[:,None]**(2*degree-1)
            bank[:,0]+=power*length
            bank[:,1]-=deriv*length
            bank[:,2]+=power*mixed
            bank[:,3]-=deriv*mixed
            if degree in (4,6):
                data={site:bank,site+"_x":rr[take],"time":time}
                out[f"{site}_{degree}"]=finite_ray(data,site,64)
        assert np.min(1+bank[:,0])>0
    archive(f"dust-clock-{mesh}.npz",**out)
    print("analytic dust",mesh,delta[-1])


if __name__=="__main__":
    run(int(sys.argv[1]))
