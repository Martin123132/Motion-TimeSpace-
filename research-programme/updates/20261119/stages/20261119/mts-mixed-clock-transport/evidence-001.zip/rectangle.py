from pathlib import Path
import sys
import json
import csv
import os

for key in ("OMP_NUM_THREADS","OPENBLAS_NUM_THREADS","MKL_NUM_THREADS","NUMEXPR_NUM_THREADS"):
    os.environ[key]="1"
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
PRE=HERE.parent/"mts-material-driven-clocks-20261119"
sys.path.insert(0,str(PRE))
from clock_run import Launch, Radial, WAVE, RADIUS, STEP, EMISSIONS, TOL, LOCATIONS, CHANNELS, bridge, profile, np, check as parent_check
from finite_repair import primitive
from dilute import weights
from scipy.interpolate import RectBivariateSpline

LOCK="e6b25387fe81e9251fc50d06d4e4c5a4a78386eaba06cb473ebc7ef7122ad787"


def guard():
    parent_check()
    assert bridge.sha(PRE/"seal.json")==LOCK and TOL==2e-5 and WAVE==4
    if (HERE/"STOP-REQUESTED").exists():
        raise SystemExit("owner hold")


def put(name,data):
    with (HERE/name).open("x",encoding="utf-8") as stream:
        json.dump(data,stream,sort_keys=True,indent=2,allow_nan=False)


def table(name,rows):
    with (HERE/name).open("x",encoding="utf-8",newline="") as stream:
        writer=csv.DictWriter(stream,fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def archive(name,**data):
    assert not (HERE/name).exists(),name
    bridge.archive(HERE/name,**data)


def base(values):
    zero=np.zeros_like(values)
    return np.stack((values,zero,zero,zero))


class Algebra:
    def __init__(self,material_rule,occupation_rule):
        self.mat=material_rule
        self.occ=occupation_rule
        assert material_rule in (0,1) and occupation_rule in (0,1)

    def product(self,left,right):
        low,mat,occ,both=left
        ref,event,load,cross=right
        axial=low*event+mat*(ref+self.mat*event)
        weight=low*load+occ*(ref+self.occ*load)
        mixed=(low+self.mat*mat+self.occ*occ+self.mat*self.occ*both)*cross
        mixed+=mat*load+occ*event+both*(ref+self.mat*event+self.occ*load)
        return np.stack((low*ref,axial,weight,mixed))

    def reciprocal(self,value):
        low,mat,occ,both=value
        ref=1/low
        event=-mat*ref/(low+self.mat*mat)
        load=-occ*ref/(low+self.occ*occ)
        cross=-(mat*load+occ*event+both*(ref+self.mat*event+self.occ*load))/(low+self.mat*mat+self.occ*occ+self.mat*self.occ*both)
        return np.stack((ref,event,load,cross))

    def root(self,value):
        low,mat,occ,both=value
        ref=np.sqrt(low)
        event=mat/(ref+np.sqrt(low+self.mat*mat))
        load=occ/(ref+np.sqrt(low+self.occ*occ))
        rem=both-2*event*load
        total=ref+self.mat*event+self.occ*load
        cross=rem/(total+np.sqrt(total**2+self.mat*self.occ*rem))
        return np.stack((ref,event,load,cross))

    def exponential(self,value):
        low,mat,occ,both=value
        ref=np.exp(low)
        event=np.expm1(mat) if self.mat else mat
        load=np.expm1(occ) if self.occ else occ
        cross=np.expm1(both) if self.mat*self.occ else both
        return np.stack((ref,ref*event,ref*load,ref*(event*load+np.exp(self.mat*mat+self.occ*occ)*cross)))

    def stress(self,value,weight):
        low,mat,occ,both=value
        zero=np.zeros_like(low)
        return np.stack((zero,zero,weight*(low+self.occ*occ),weight*(mat+self.occ*both)))


def initial(mesh,algebra,amp,weight,fraction,eta):
    spec=Launch(mesh,eta)
    radius,inverse=spec.radius,spec.inv
    shape,gauss,_,_=profile(radius,WAVE)
    number=base(fraction*spec.number if algebra.mat else np.zeros_like(radius))
    charge=base(fraction*spec.charge if algebra.mat else np.zeros_like(radius))
    number[1]=fraction*amp*spec.number[0]*shape
    charge[1]=fraction*amp*eta*spec.number[0]*gauss
    scalar=base(spec.height)
    unit=base(np.ones_like(radius))
    mass=base(np.zeros_like(radius))
    charge_energy=algebra.product(charge,charge)*inverse**4/2
    for niter in range(24):
        fac=unit-2*mass*inverse
        ordinary=algebra.product(number,algebra.root(fac))+charge_energy
        stress=algebra.stress(base(spec.height**2)+fac*spec.slope**2,weight)/2
        current=np.array([primitive(radius,entry*radius**2) for entry in ordinary+stress])
        err=np.max(abs(current-mass),axis=1)
        if niter>=10 and np.all(err<=2e-14*np.maximum(np.max(abs(current),axis=1),1e-290)):
            mass=current
            break
        mass=current
    else:
        raise ArithmeticError(("constraint",err))
    delta=2*mass*inverse
    radial=algebra.product(delta,algebra.reciprocal(unit-delta))
    picks=spec.picks
    zero=np.zeros((4,len(picks)))
    field=np.stack((radial[:,picks],zero,zero,zero,(mass*inverse**3)[:,picks],scalar[:,picks],zero,
                    number[:,picks],zero,charge[:,picks]))
    length=algebra.root(unit+radial)
    return field,np.array([mass[3,-1],np.interp(6.,radius,length[3])])


class System:
    def __init__(self,mesh,algebra,weight,eta,conservative):
        self.space_op=Radial(mesh,"tensor",0.,eta,RADIUS)
        self.space=self.space_op.x
        self.unit=base(np.ones_like(self.space))
        self.algebra=algebra
        self.eta=eta
        self.weight=weight
        self.conservative=conservative

    def rhs(self,state):
        op=self.space_op
        xx=self.space
        ar=self.algebra
        prod,inv,sqrt=ar.product,ar.reciprocal,ar.root
        metric,angular,krad,kang,mass,field,normal,number,impulse,charge=state
        aa,cc=self.unit+metric,self.unit+angular
        ia,ic=inv(aa),inv(cc)
        length,root=sqrt(aa),sqrt(cc)
        il,ir=inv(length),inv(root)
        dr,dc,dh=op.diff(state[[0,1,5]],op.d1)
        proper=prod(number,prod(ic,il))
        speed=prod(impulse,il)
        speed2=prod(speed,speed)
        gamma=sqrt(self.unit+speed2)
        ig=inv(gamma)
        grad=prod(dh,il)
        electric=prod(charge,ic)/xx**2
        em=prod(electric,electric)
        kinetic=ar.stress(prod(normal,normal),self.weight)
        spatial=ar.stress(prod(grad,grad),self.weight)
        potential=ar.stress(prod(field,field),self.weight)
        pressure=(kinetic+spatial-potential-em)/2+prod(proper,prod(speed2,ig))
        if self.conservative:
            energy=prod(proper,gamma)+(em+kinetic+spatial+potential)/2
            tangential=(em+kinetic-spatial-potential)/2
            focus=energy-pressure+2*tangential
        else:
            focus=kinetic-spatial+2*em+prod(proper,ig)
        current=prod(proper,speed)-ar.stress(prod(normal,grad),self.weight)
        flow=prod(cc,prod(proper,prod(speed,ig)))
        tangent=prod(kang,ic)
        rx=root+xx*prod(dc,ir)/2
        rk=prod(krad,ia)
        encl=prod(mass,prod(ic,ir))
        motion=-xx*prod(root,tangent)
        lap=prod(ia,op.diff(xx*field,op.d2,True)/xx+prod(prod(dc,ic)-prod(dr,ia)/2,dh))
        out=np.empty_like(state)
        out[0],out[1]=-2*krad,-2*kang
        out[2]=prod(aa,focus-2*encl)-prod(krad,rk)
        out[3]=prod(cc,encl+pressure-prod(tangent,tangent))
        out[4]=-prod(cc,prod(pressure,motion)+prod(current,prod(rx,il)))/xx
        out[5],out[6]=normal,lap-field+prod(rk+2*tangent,normal)
        out[7]=(-op.diff(flow*xx**2,op.d1,True)/xx**2 if self.conservative else -op.diff(flow,op.d1,True)-2*flow/xx)
        mom=prod(impulse,ia)
        out[8]=-prod(prod(speed,prod(il,ig)),op.diff(impulse,op.d1,True))+prod(dr,prod(prod(mom,mom),ig))/2+self.eta*prod(length,electric)
        out[9]=-self.eta*xx**2*flow
        return out
