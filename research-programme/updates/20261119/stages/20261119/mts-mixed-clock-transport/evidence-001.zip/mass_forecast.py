from mass_curvature import *
from functools import lru_cache

FRACTIONS={"reference":1.,"held":.01,"light3":.001,"light6":.000001}


@lru_cache(None)
def jet(mesh,order):
    bank=bridge.read(HERE/f"hessian-{mesh}-{order}.npz")
    assert bank["receipt"].item().decode()==bridge.sha(HERE/"hessian-setup.json")
    return bank


def assemble():
    fields={}
    for mesh in (128,256):
        for site in LOCATIONS:
            for panels in ("32","64","quadratic"):
                key=f"{site}_{panels}"
                coarse=jet(mesh,64)[key]
                fine=jet(mesh,128)[key]
                wide,narrow=64*coarse.imag,128*fine.imag
                second=(4*narrow-wide)/3
                linear=packet("masscoefficient",mesh,"plus")[key][:,3]
                fields[f"{mesh}_{key}_realcheck"]=(4*fine.real-coarse.real)/3-linear
                fields[f"{mesh}_{key}_second"]=second
                for name,fraction in FRACTIONS.items():
                    fields[f"{name}_{mesh}_{key}"]=fraction*linear+fraction**2*second
                    fields[f"{name}_{mesh}_{key}_step"]=fraction**2*(second-narrow)
    return fields


def compile_forecast():
    freeze("setup")
    fields=assemble()
    archive("mass-forecast.npz",**fields)
    freeze("held",True)


def results():
    freeze("held")
    saved=bridge.read(HERE/"mass-forecast.npz")
    rows=[]
    for name,fraction in FRACTIONS.items():
        for site in LOCATIONS:
            for idx,channel in enumerate(CHANNELS):
                def pred(mesh,panels):
                    return saved[f"{name}_{mesh}_{site}_{panels}"][idx]
                def true(mesh,panels):
                    if name=="held":
                        bank=bridge.read(HERE/f"held-1pct-{mesh}.npz")
                        assert bank["receipt"].item().decode()==bridge.sha(HERE/"hessian-held.json")
                        return bank[f"{site}_{panels}"][idx]
                    return packet("target" if name=="reference" else name,mesh,"plus")[f"{site}_{panels}"][idx,3]
                measured=true(256,64)
                estimate=pred(256,64)
                size=peak(measured)
                linear=fraction*packet("masscoefficient",256,"plus")[site+"_64"][idx,3]
                diff=(estimate-measured,pred(128,64)-estimate,true(128,64)-measured,pred(256,32)-estimate,
                      true(256,32)-measured,pred(256,"quadratic")-estimate,true(256,"quadratic")-measured,
                      saved[f"{name}_256_{site}_64_step"][idx])
                err=[peak(wave)/size for wave in diff]
                real=fraction*saved[f"256_{site}_64_realcheck"][idx]
                pos=np.argmax(abs(measured))
                rows.append(dict(case=name,fraction=fraction,link=site,channel=channel,peak_time=EMISSIONS[pos],
                                 signed_peak=measured[pos],delay_seconds=(measured[pos]*SEC if "delay" in channel else ""),
                                 first_order_model=peak(linear-measured)/size,second_order_signal=peak(estimate-linear)/size,
                                 second_order_model=err[0],pred_grid=err[1],target_grid=err[2],pred_ray=err[3],target_ray=err[4],
                                 pred_time=err[5],target_time=err[6],complex_step=err[7],linear_crosscheck=peak(real)/size,
                                 total=sum(err)+peak(real)/size,passes=sum(err)+peak(real)/size<=TOL))
    return rows


if __name__=="__main__":
    if sys.argv[1]=="freeze":
        compile_forecast()
    else:
        compare("mass-curvature-budgets.csv",results(),sys.argv[1]=="create")
