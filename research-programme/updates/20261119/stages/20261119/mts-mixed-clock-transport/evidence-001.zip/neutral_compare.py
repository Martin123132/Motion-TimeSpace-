from measure import *
from neutral import neutral_lock


def records():
    neutral_lock()
    rows=[]
    states={mesh:bridge.read(HERE/f"neutral-{mesh}.npz") for mesh in (128,256)}
    exact={mesh:bridge.read(HERE/f"dust-clock-{mesh}.npz") for mesh in (128,256)}
    for bank in (*states.values(),*exact.values()):
        assert bank["receipt"].item().decode()==bridge.sha(HERE/"neutral-input.json")
    for site in LOCATIONS:
        for idx,channel in enumerate(CHANNELS):
            key=site+"_64"
            coarse=states[128][key][idx]
            fine=states[256][key][idx]
            target=fine[3]
            approx=packet("masscoefficient",256,"plus")[key][idx,3]*1e-6
            def source(mesh,panels):
                return packet("masscoefficient",mesh,"plus")[f"{site}_{panels}"][idx,3]*1e-6
            terms=(target-approx,coarse[3]-target,source(128,64)-approx,
                   states[256][site+"_32"][idx,3]-target,source(256,32)-approx,
                   states[256][site+"_quadratic"][idx,3]-target,source(256,"quadratic")-approx)
            norm=peak(target)
            ratios=[peak(term)/norm for term in terms]
            theory=exact[256][site+"_6"][idx]
            material=fine[1]
            null_norm=peak(theory)
            dust=[peak(term)/null_norm for term in (material-theory,coarse[1]-material,exact[128][site+"_6"][idx]-theory,
                                                    states[256][site+"_32"][idx,1]-material,exact[256][site+"_4"][idx]-theory)]
            charge=packet("light6",256,"plus")[key][idx,3]
            rows.append(dict(link=site,channel=channel,prediction_error=ratios[0],mixed_budget=sum(ratios),
                             passed_mixed=sum(ratios)<=TOL,charged_minus_neutral_over_neutral=peak(charge-target)/norm,
                             signed_peak=target[np.argmax(abs(target))],analytic_dust_error=dust[0],dust_mesh=dust[1],
                             analytic_mesh=dust[2],dust_ray=dust[3],dust_series=dust[4],ordinary_budget=sum(dust),
                             passed_ordinary=sum(dust)<=TOL))
    return rows


if __name__=="__main__":
    compare("neutral-and-newton.csv",records(),sys.argv[1]=="create")
