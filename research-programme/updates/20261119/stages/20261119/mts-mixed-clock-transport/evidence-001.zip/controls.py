from transport import *
import mpmath as mp


def corner(value,material,occupation):
    return value[0]+material*value[1]+occupation*value[2]+material*occupation*value[3]


def manufactured():
    mp.mp.dps=65
    stats={}
    emit=np.arange(9)*.09
    times=np.arange(201)*.01
    space=np.arange(71)*.01+5.9
    ar=Algebra(1,1)
    for gain in (1.,1e-5):
        coeff=np.array([[1.013,2e-4,7e-9*gain,3e-13*gain],
                        [.004,-1e-4,4e-9*gain,-8e-13*gain],[.001,6e-5,-2e-9*gain,4e-13*gain]])
        series=[]
        for time in times:
            shift=(coeff[0]-np.array([1.,0.,0.,0.]))+time*coeff[1]+time**2*coeff[2]
            rate=-coeff[1]-2*time*coeff[2]
            series.append(np.stack((shift,rate))[:,:,None]*np.ones(len(space)))
        surface=OpticalSurface(times,space,np.array(series),6.,64,3)
        observed=clocks(surface,ar,64,3,emit)
        answers=[]
        for start in emit:
            high=mp.mpf(float(start))
            partial=[]
            for occupation,material in ((0,0),(0,1),(1,0),(1,1)):
                aa,bb,cc=[sum(mp.mpf(float(x))*mult for x,mult in zip(row,(1,material,occupation,material*occupation))) for row in coeff]
                freq=mp.sqrt(aa*cc-bb**2/4)
                def evolve(distance):
                    sine=mp.sin(freq*distance)/freq
                    cosine=mp.cos(freq*distance)
                    arrive=(high*cosine+(bb*high/2+aa)*sine)/(cosine-(cc*high+bb/2)*sine)
                    return (aa+bb*high+cc*high**2)/(aa+bb*arrive+cc*arrive**2)-1,arrive-high-distance
                single,delay=evolve(mp.mpf(".5"))
                echo,back=evolve(mp.mpf(1))
                partial.append(mp.matrix([single,echo,delay,back]))
            answers.append(np.array(list(partial[3]-partial[2]-partial[1]+partial[0]),float))
        target=np.array(answers).T
        error=np.max(abs(observed[:,3]-target),axis=1)/np.max(abs(target),axis=1)
        assert max(error)<2e-7,error
        stats[str(gain)]=error.tolist()
    return stats


def run():
    guard()
    data={"manufactured_clock_relative":manufactured()}
    rng=np.random.default_rng(6419)
    ar=Algebra(1,1)
    left=rng.uniform(-.2,.2,(4,19))
    left[0]+=1.2
    right=rng.normal(size=(4,19))
    for mat in (0,1):
        for occ in (0,1):
            direct=corner(left,mat,occ)
            for actual,expected in ((ar.product(left,right),direct*corner(right,mat,occ)),(ar.root(left),np.sqrt(direct)),
                                    (ar.reciprocal(left),1/direct),(ar.exponential(left),np.exp(direct))):
                np.testing.assert_allclose(corner(actual,mat,occ),expected,rtol=1e-13,atol=2e-15)
    wave=weights()
    for eta in (0.,.8):
        grid=64
        solver=System(grid,ar,wave,eta,True)
        original=Radial(grid,"tensor",0.,eta,RADIUS)
        state,_=initial(grid,ar,.01,wave,1.,eta)
        worst=0.
        for iteration in range(3):
            direction=solver.rhs(state)
            for mat in (0,1):
                for occ in (0,1):
                    replay=np.stack([corner(entry,mat,occ) for entry in state])
                    rate=np.stack([corner(entry,mat,occ) for entry in direction])
                    replay[5:7]*=np.sqrt(occ*wave)
                    rate[5:7]*=np.sqrt(occ*wave)
                    direct=original.rhs(replay)
                    err=np.max(abs(rate-direct),axis=1)
                    bound=4e-12*np.max(abs(direct),axis=1)+2e-14
                    assert max(err/bound)<1.,(iteration,mat,occ,err,bound)
                    worst=max(worst,float(max(err/bound)))
            state+=.0002*direction
        data[f"endpoint_budget_fraction_q{eta}"]=worst
    for amp,weight in ((0.,wave),(.01,0.)):
        state,_=initial(64,ar,amp,weight,1.,.8)
        solver=System(64,ar,weight,.8,True)
        for tick in range(12):
            change=solver.rhs(state)
            assert np.count_nonzero(change[:,3])==0
            state+=.001*change
        assert np.count_nonzero(state[:,3])==0
    with (PRE/"mixed-launch.csv").open(newline="") as stream:
        refs=list(csv.DictReader(stream))
    errs=[]
    for mesh in (128,256):
        for sign,amp in (("plus",.01),("minus",-.01)):
            row,=[row for row in refs if int(row["mesh"])==mesh and row["sign"]==sign and row["background"]=="dilute" and float(row["eta"])==.8]
            _,launch=initial(mesh,ar,amp,wave,1.,.8)
            target=np.array([float(row["mixed_mass_at_12"]),float(row["mixed_radial_length_at_6"])])
            errs.extend(abs(launch/target-1.))
    assert max(errs)<1e-8,errs
    data["max_independent_mixed_launch_error"]=max(errs)
    data["code"]={name:bridge.sha(HERE/name) for name in ("rectangle.py","controls.py","transport.py","PROTOCOL.md")}
    put("operator-controls.json",data)
    print(data,flush=True)


if __name__=="__main__":
    run()
