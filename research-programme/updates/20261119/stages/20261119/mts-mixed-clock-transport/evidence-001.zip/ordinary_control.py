from rectangle import *
from paired_clock import PairSystem, prod, inv, sqrtp, finite_ray
from clock_interpretation import exterior_forecast
from types import SimpleNamespace


def material_change(radius,fac,inverse,number,drive):
    mass=np.zeros_like(radius)
    for attempt in range(18):
        weight=np.exp(primitive(radius,2*radius*number/(np.sqrt(fac)+np.sqrt(fac-2*inverse*mass))))
        after=primitive(radius,weight*drive)/weight
        if np.max(abs(after-mass))<=4e-15*np.max(abs(after)):
            return after
        mass=after
    raise ArithmeticError("ordinary constraint")


def run(sign):
    guard()
    mesh=256
    amp={"plus":.01,"minus":-.01}[sign]
    spec=Launch(mesh,.8)
    radius,inverse=spec.radius,spec.inv
    dens,gauss,_,_=profile(radius,WAVE)
    dn=amp*spec.number[0]*dens
    dq=.8*amp*spec.number[0]*gauss
    fac=1-2*inverse*spec.ordinary
    drive=radius**2*(np.sqrt(fac)*dn+(spec.charge+dq/2)*dq*inverse**4)
    mass=material_change(radius,fac,inverse,spec.number+dn,drive)
    base_rad=2*inverse*spec.ordinary/fac
    del_rad=2*inverse*mass/(fac*(fac-2*inverse*mass))
    pair=.5+.5j
    take=spec.picks
    zero=np.zeros(len(take),dtype=complex)
    state=np.stack(((base_rad+pair*del_rad)[take],zero,zero,zero,((spec.ordinary+pair*mass)*inverse**3)[take],zero,zero,
                    (spec.number+pair*dn)[take],zero,(spec.charge+pair*dq)[take]))
    scheme=PairSystem(mesh)
    steps=int(np.ceil(.01*mesh/.42))
    dt=.01/steps
    masks={name:(scheme.space>=low-.09)&(scheme.space<=low+.59) for name,low in LOCATIONS.items()}
    strips={name:[] for name in masks}
    for tick in range(450*steps+1):
        if tick%steps==0:
            for site,mask in masks.items():
                metric=state[0,mask]
                length=sqrtp(1+metric)
                rate=prod(state[2,mask],inv(length))
                quiet=metric.real-metric.imag
                strips[site].append(np.stack((quiet/(1+np.sqrt(1+quiet)),rate.real-rate.imag,2*length.imag,2*rate.imag)))
        if tick%(50*steps)==0:
            guard()
        if tick==450*steps:
            break
        first=scheme.rhs(state)
        second=scheme.rhs(state+.5*dt*first)
        third=scheme.rhs(state+.5*dt*second)
        fourth=scheme.rhs(state+dt*third)
        state+=dt/6*(first+2*second+2*third+fourth)
    assert np.isfinite(state).all()
    mid=SimpleNamespace(charge=spec.charge,ordinary=np.array([spec.ordinary[-1]+mass[-1]/2]))
    out=dict(emission=EMISSIONS,mass_change=mass[-1],electrovac=mass[-1]*exterior_forecast(mid))
    for site,mask in masks.items():
        packet={site:np.array(strips[site]),site+"_x":scheme.space[mask],"time":np.arange(451)*.01}
        out[site]=finite_ray(packet,site,64)
    archive(f"ordinary-{sign}.npz",**out)
    print(f"ordinary-{sign}",flush=True)


if __name__=="__main__":
    for sign in sys.argv[1:]:
        run(sign)
