from controls import manufactured
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parent))
from measure import *
import clock_identity
import calendar_transfer
import source_scale
import neutral_compare
import preparation_energy
import mass_forecast
from neutral import neutral_lock
from mass_curvature import freeze as curvature_lock


def verify():
    guard()
    assert __debug__
    parent=json.loads((PRE/"seal.json").read_bytes())["files"]
    assert len(parent)==68 and all(bridge.sha(PRE/name)==value for name,value in parent.items())
    for step in ("inputs","finite","light"):
        signatures(step)
    neutral_lock()
    curvature_lock("held")
    controls=json.loads((HERE/"operator-controls.json").read_bytes())
    assert controls["manufactured_clock_relative"]==manufactured()
    assert all(bridge.sha(HERE/name)==value for name,value in controls["code"].items())
    reconstructed=mass_forecast.assemble()
    pinned=bridge.read(HERE/"mass-forecast.npz")
    assert reconstructed.keys()==pinned.keys() and all(np.array_equal(pinned[key],reconstructed[key]) for key in pinned)
    scale_rows,actuator,meta=source_scale.results()
    assert meta==json.loads((HERE/"observational-input.json").read_bytes())
    outputs={"clock-budgets.csv":budgets(),"controls-and-old-results.csv":correspondence(),"monopole-residual.csv":mass_null(),
             "frequency-from-arrival.csv":clock_identity.records(),"calendar-transfer.csv":calendar_transfer.projection(),
             "ngc3198-source-scale.csv":scale_rows,"actuator-comparison.csv":actuator,
             "neutral-and-newton.csv":neutral_compare.records(),"preparation-energy.csv":preparation_energy.run(),
             "mass-curvature-budgets.csv":mass_forecast.results()}
    expected=[48,24,16,216,144,129,3,12,48,48]
    assert [len(rows) for rows in outputs.values()]==expected
    for name,rows in outputs.items():
        compare(name,rows,False)
        for row in rows:
            assert all(np.isfinite(float(val)) for val in row.values() if isinstance(val,(int,float,np.number)))
    for file in HERE.glob("*.npz"):
        with np.load(file,allow_pickle=False) as bank:
            assert bank.files and all(np.isfinite(bank[key]).all() for key in bank.files if bank[key].dtype.kind in "ficu")
    with (PRE/"dilute-budgets.csv").open(newline="") as stream:
        failed={(row["mode"],row["link"],row["channel"]) for row in csv.DictReader(stream) if row["passes"]=="False"}
    tested={(row["sign"],row["link"],row["channel"]) for row in outputs["clock-budgets.csv"] if row["source"]=="target"}
    assert len(failed)==16 and failed<=tested
    assert all(row["single_axis_quiet"]<TOL and row["single_axis_material"]<TOL for row in outputs["controls-and-old-results.csv"])
    assert all(row["electrovac"]<TOL for row in outputs["controls-and-old-results.csv"] if row["link"]=="outer")
    assert not any(path.is_dir() or path.name.endswith(".partial") for path in HERE.iterdir())
    assert all((HERE/name).is_file() for name in ("RESULTS.md","DERIVATION.md","REPLAY.md","SOURCE-PREPARATION.md"))
    dependencies={}
    for module in tuple(sys.modules.values()):
        filename=getattr(module,"__file__",None)
        if filename:
            path=Path(filename).resolve()
            if path.is_relative_to(HERE.parent) and not path.is_relative_to(HERE) and path.suffix==".py":
                dependencies[str(path.relative_to(HERE.parent))]=bridge.sha(path)
    for name in ("physical-clock-scale.json","epta-j1713-observing-days.csv","epta-provenance.json"):
        dependencies[str((GEO/name).relative_to(HERE.parent))]=bridge.sha(GEO/name)
    manifest=dict(parent=LOCK,parent_files=len(parent),external=dependencies,galaxy_sample=meta["sample_text_sha256"],
                  rows={name:len(rows) for name,rows in outputs.items()},files={file.name:bridge.sha(file) for file in HERE.iterdir() if file.name!="seal.json"})
    if (HERE/"seal.json").exists():
        assert manifest==json.loads((HERE/"seal.json").read_bytes())
    else:
        put("seal.json",manifest)
    print("Verified",len(manifest["files"]),"files",sum(manifest["rows"].values()),"rows",bridge.sha(HERE/"seal.json"))


if __name__=="__main__":
    verify()
