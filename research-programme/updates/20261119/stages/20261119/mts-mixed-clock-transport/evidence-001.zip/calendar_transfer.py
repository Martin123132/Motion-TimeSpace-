from measure import *


def load_calendar():
    path=GEO/"epta-j1713-observing-days.csv"
    provenance=json.loads((GEO/"epta-provenance.json").read_bytes())
    assert provenance["commit"]=="2911d0e52e0c8a4e528c4e3aa46b868ced1910e8"
    with path.open(newline="") as stream:
        rows=list(csv.DictReader(stream))
    date=np.array([int(row["day"]) for row in rows])
    group=np.array([row["instrument"] for row in rows])
    count=np.array([int(row["count"]) for row in rows])
    assert sum(count)==sum(row["active"] for row in provenance["files"])==5011 and len(np.unique(date))==2055
    return date,group,count


def projection():
    day,group,count=load_calendar()
    years=(day-day.min())/365.25
    times=(day-day.min())*86400/SEC
    unique,idx=np.unique(day,return_inverse=True)
    byday=np.bincount(idx,weights=count)
    x=2*years/years[-1]-1
    polynomial=np.stack((x*0+1,x,x*x),axis=1)
    annual=np.stack((np.cos(2*np.pi*years),np.sin(2*np.pi*years),np.cos(4*np.pi*years),np.sin(4*np.pi*years)),axis=1)
    instrument=(group[:,None]==np.unique(group)[1:]).astype(float)
    full=np.column_stack((polynomial,annual,instrument))
    designs={}
    for name,wt in (("equal_TOA",count),("equal_day",count/byday[idx])):
        root=np.sqrt(wt/sum(wt))
        for model,matrix in (("spin",polynomial),("spin_year_groups",full)):
            basis,singular,_=np.linalg.svd(root[:,None]*matrix,full_matrices=False)
            basis=basis[:,singular>singular[0]*1e-12]
            assert np.linalg.norm((root[:,None]*matrix)-basis@(basis.T@(root[:,None]*matrix)))<1e-12
            designs[name,model]=(root,basis)
    results=[]
    for mode,sgn in (("target","plus"),("target","minus"),("light3","plus"),("light6","plus")):
        for site in LOCATIONS:
            data=packet(mode,256,sgn)[site+"_64"][2]
            reference=EMISSIONS+.5+data[0]
            assert min(np.diff(reference))>0 and times[-1]<np.ptp(reference)
            for location,frac in (("early",0.),("middle",.5),("late",1.)):
                stamps=reference[0]+frac*(np.ptp(reference)-times[-1])+times
                assert min(stamps)>=min(reference)-1e-13 and max(stamps)<=max(reference)+1e-13
                def resample(stride):
                    return SEC*make_interp_spline(reference[::stride],data[[1,3],::stride],axis=1,k=5)(stamps)
                ordinary,wave=resample(1)
                half=resample(2)[1]
                for (weight,model),(root,basis) in designs.items():
                    def remove(curve):
                        observation=root*curve
                        return observation-basis@(basis.T@observation)
                    filtered=remove(wave)
                    control=remove(ordinary)
                    norm=np.linalg.norm(control)
                    assert norm>0
                    unit=control/norm
                    def adjusted(curve):
                        residual=remove(curve)
                        return residual-unit*(unit@residual)
                    remainder=adjusted(wave)
                    raw_rms=np.linalg.norm(root*wave)
                    rms=np.linalg.norm(filtered)
                    post=np.linalg.norm(remainder)
                    assert 0<=post<=rms*(1+1e-12)<=raw_rms*(1+2e-12)
                    leakage=np.linalg.norm(adjusted(ordinary))/norm
                    assert leakage<2e-12
                    results.append(dict(mode=mode,sign=sgn,link=site,window=location,weight=weight,nuisance=model,
                                        TOAs=int(sum(count)),span_years=years[-1],raw_rms_s=raw_rms,post_rms_s=rms,
                                        post_plus_source_amp_s=post,post_fraction=rms/raw_rms,source_adjusted_fraction=post/raw_rms,
                                        fractional_ordinary_adjustment=(unit@filtered)/norm,ordinary_control=leakage,
                                        interpolation_shift_over_adjusted=np.linalg.norm(adjusted(half-wave))/max(post,1e-290)))
    return results


if __name__=="__main__":
    compare("calendar-transfer.csv",projection(),sys.argv[1]=="create")
