"""Verify immutable inputs, observable definitions, source laws and the numerical receipt offline."""
from pathlib import Path
from branch import HERE, BASE, PARENT, np, check, read, write, sha, json, OUTER, SURFACE
import sys

TOL=2e-5
FROZEN={"PROTOCOL.md":"d545a96b42b73ea547003fd86b69b357f3ff15e035f6553dec2d503dc801a632",
        "main-grid.csv":"cb9c9ec1857164776ca545323bd55ee8d473f2f06f2a5a4dbf5a94b55040950f",
        "main.npz":"3f56c7f251fdc116afbd6fa6adcd3a91b24ca21b14818b411978df5594e7e58b",
        "main-path.csv":"b03118e316bb427661333d5283e6f56063bf740270c78ed2b6f330fb58f64e92"}
SPECS={"main":("disk20-diff",1,224.03),"above":("diskbox-cap",1,224.03),"outer":("diskbox-diff",1,224.03),
       "coarse":("disk12-diff",1,224.03),"light":("disk20-diff",.9,224.03),"heavy":("disk20-diff",1.1,224.03),
       "slow":("disk20-diff",1,222.12),"fast":("disk20-diff",1,225.94)}


def records():
    check()
    assert all(sha(HERE/name)==h for name,h in FROZEN.items())
    upstream=json.loads((BASE/"seal.json").read_bytes())
    assert all(sha(BASE/name)==value for name,value in upstream["files"].items())
    counts={file.name:len(read(file.name)) for file in HERE.glob("*.csv")}
    assert counts["older-tracer.csv"]==38 and counts["rotation.csv"]==8*2*12
    assert counts["vertical.csv"]==8*2*2*8 and counts["local-gradients.csv"]==7*2*3*2
    assert counts["annulus-mass.csv"]==4*3*2 and counts["poisson-slab.csv"]==4*2*3
    assert counts["small-step-tangent.csv"]==10 and counts["force-readouts.csv"]==164
    ranks=read("rotation-summary.csv")
    obs=read("cepheid-table1.csv")
    assert len(obs)==12 and all(float(row["sigma_kms"])>0 for row in obs)
    for tag in SPECS:
        seed,eta,target=SPECS[tag]
        grid=read(tag+"-grid.csv")
        path=read(tag+"-path.csv")
        ref=read("main-grid.csv")
        assert len(path)>=2 and len(grid)==164
        assert len({(row["kind"],row["R_kpc"],row["z_kpc"]) for row in grid})==164
        assert all((a["kind"],a["R_kpc"],a["z_kpc"])==(b["kind"],b["R_kpc"],b["z_kpc"]) for a,b in zip(grid,ref))
        with np.load(HERE/(tag+".npz")) as pack:
            assert str(pack["seed"])==seed and abs(float(pack["eta"])-eta)<1e-15 and float(pack["target"])==target
            assert str(pack["protocol"])==FROZEN["PROTOCOL.md"]
            assert abs(np.sum(pack["coef"]**2)/pack["mass"]-1)<1e-12
            assert abs(2*np.sum(pack["coef"]*pack["mass_tangent"])/pack["mass"]-1)<1e-11
            assert abs(np.sum(pack["coef"]*pack["baryon_tangent"])/pack["mass"])<1e-11
            assert abs(float(path[-1]["mass_msun"])/float(pack["mass_msun"])-1)<1e-13
            amp=float(pack["nfw"])
        assert abs(float(path[-1]["speed"])-target)<2e-8
        assert max(float(row["stationarity"]) for row in path)<1e-10
        assert all(float(row["speed2_mass_slope"])>0 for row in path)
        for row in grid:
            rr=float(row["R_kpc"])
            if row["kind"]=="speed":
                common=float(row["ordinary_gR"])
                wave=float(row["wave_gR"])
                halo=(float(row["original_nfw"])**2/rr-common)*amp
                assert abs(rr*(common+wave)-float(row["mts"])**2)<1e-8
                assert abs(rr*(common+halo)-float(row["nfw"])**2)<1e-8
                if rr==OUTER:
                    for model in ("mts", "nfw"):
                        assert abs(float(row[model])-target)<2e-8 and abs(float(row[model+"_per_eta"]))<1e-10
                        assert abs(float(row[model+"_per_kms"])-1)<1e-10
            else:
                assert abs((float(row["ordinary_gz"])+float(row["wave_gz"]))/SURFACE+float(row["mts"]))<1e-11
                assert all(float(row[model])>0 for model in ("mts", "nfw"))
        for model in ("mts", "nfw"):
            errors=[float(row[model])-float(point["V_kms"]) for row,point in zip(grid[:11],obs[:11])]
            rmse=(sum(err**2 for err in errors)/11)**.5
            match,=[row for row in ranks if row["case"]==tag and row["model"]==model]
            assert abs(rmse-float(match["rmse"]))<1e-12 and int(match["count"])==11
    source=read("eilers-table1.csv")
    for data,pred in zip(source,read("older-tracer.csv"),strict=True):
        assert float(data["R_kpc"])==float(pred["R_kpc"]) and float(data["V_kms"])==float(pred["V_observed"])
    peak=lambda name,key:max(float(row[key]) for row in read(name))
    assert peak("force-readouts.csv","component_relative")<TOL
    assert max(float(row["relative_error"]) for row in read("poisson-slab.csv") if float(row["step_kpc"])==.01)<TOL
    assert peak("small-step-tangent.csv","max_error_fraction_of_peak")<TOL
    ann=read("annulus-mass.csv")
    for row in ann:
        if row["relative_flux_error"]:
            assert float(row["relative_flux_error"])<TOL
        if int(row["quadrature_order"])==24:
            other,=[candidate for candidate in ann if candidate["component"]==row["component"] and
                    candidate["zmax"]==row["zmax"] and int(candidate["quadrature_order"])==12]
            assert abs(float(other["flux_mass_msun"])/float(row["flux_mass_msun"])-1)<TOL
    misses=[(row["case"],row["kind"]) for row in read("stability.csv") if row["case"] in ("above","outer","coarse")
            and row["model"]=="mts" and float(row["max_relative"])>TOL]
    assert sorted(misses)==[("coarse","speed"),("coarse","vertical")]
    return dict(row_counts=counts,expected_20ppm_misses=misses,source_hash=sha(BASE/"seal.json"),
                forecast=FROZEN,catalogue_assessment="conditional; no catalogue-wide likelihood")


def main():
    report=records()
    write("verification.json",json.dumps(report,indent=2,sort_keys=True)+"\n")
    required={"RESULTS.md","DERIVATION.md","SOURCES.md","REPLAY.md","NEXT.md","verification.json"}
    assert all((HERE/name).is_file() for name in required)
    files={file.name:sha(file) for file in sorted(HERE.iterdir()) if file.is_file() and file.name!="seal.json"}
    assert not any(file.is_dir() for file in HERE.iterdir())
    if sys.argv[1:]==["seal"]:
        write("seal.json",json.dumps(dict(files=files),indent=2,sort_keys=True)+"\n")
    else:
        assert not sys.argv[1:]
    assert json.loads((HERE/"seal.json").read_bytes())["files"]==files
    print("Verified",len(files),"files;",sum(report["row_counts"].values()),"CSV rows. Seal:",sha(HERE/"seal.json"))


if __name__=="__main__":
    main()
