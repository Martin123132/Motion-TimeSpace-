"""Score the sealed forecasts without changing either calibrated model."""
from branch import check, np, table, read, write, json, HERE, SURFACE, RADII, OUTER, SPEED, sha

TAGS = ("main", "outer", "above", "coarse", "light", "heavy", "slow", "fast")
MODELS = ("mts", "nfw")
VERTICAL = (("thin", -2454., 619.), ("thick", -2141., 774.))


def vec(rows, key):
    return np.array([float(row[key]) for row in rows])


def stats(delta):
    return dict(count=len(delta), rmse=np.sqrt(np.mean(delta ** 2)), bias=np.mean(delta),
                max_abs=np.max(np.abs(delta)))


def run():
    check()
    assert sha(HERE/"main-grid.csv") == "cb9c9ec1857164776ca545323bd55ee8d473f2f06f2a5a4dbf5a94b55040950f"
    obs = read("cepheid-table1.csv")
    radii, speeds, errors = (vec(obs, key) for key in ("R_kpc", "V_kms", "sigma_kms"))
    assert np.array_equal(radii, RADII) and speeds[-1] == SPEED and errors[-1] == 1.91
    scores, rotation, vertical, roots, robustness, shape, differences = [], [], [], [], [], [], []
    cache = {}
    for tag in TAGS:
        forecast = read(tag+"-grid.csv")
        cache[tag] = forecast
        rows = [row for row in forecast if row["kind"] == "speed"]
        assert np.array_equal(vec(rows, "R_kpc"), radii)
        with np.load(HERE/(tag+".npz")) as state:
            target = float(state["target"])
            roots.append(dict(case=tag, mass_msun=float(state["mass_msun"]), nfw_amplitude=float(state["nfw"]),
                              eta=float(state["eta"]), target_kms=target, virial=float(state["virial"]),
                              per_eta=float(state["logmass_per_eta"]), per_kms=float(state["logmass_per_kms"])))
        for model in MODELS:
            prediction = vec(rows, model)
            assert abs(prediction[-1] - target) < 2e-8
            delta = prediction - speeds
            rate = vec(rows, model+"_per_kms")
            covariance = np.diag(errors[:-1] ** 2) + errors[-1] ** 2 * np.outer(rate[:-1], rate[:-1])
            scores.append(dict(case=tag, model=model, **stats(delta[:-1]),
                               diagonal_chi2=np.sum((delta[:-1] / errors[:-1]) ** 2),
                               common_anchor_conditional_quadratic=delta[:-1] @ np.linalg.solve(covariance, delta[:-1])))
            for idx, row in enumerate(rows):
                force = prediction[idx] ** 2 / radii[idx] - float(row["ordinary_gR"])
                required = speeds[idx] ** 2 / radii[idx] - float(row["ordinary_gR"])
                rotation.append(dict(case=tag, model=model, R_kpc=radii[idx], role="calibration" if idx==len(rows)-1 else "shape",
                                     V_obs=speeds[idx], V_pred=prediction[idx], delta=delta[idx], sigma_boot=errors[idx],
                                     field_accel=force, required_extra_accel=required, extra_minus_required=force-required,
                                     common_anchor_sigma=errors[-1] * rate[idx]))
            for row in forecast:
                if row["kind"] != "vertical" or float(row["z_kpc"]) != 1.5:
                    continue
                force = -SURFACE * float(row[model])
                for tracer, mean, width in VERTICAL:
                    vertical.append(dict(case=tag, model=model, tracer=tracer, R_kpc=row["R_kpc"],
                                         use="comparison" if float(row["R_kpc"]) == 8.3 else "radius_sensitivity_only",
                                         Kz=force, Kz_observed_at_R0=mean, sigma=width,
                                         residual_over_sigma_at_R0=(force-mean)/width if float(row["R_kpc"])==8.3 else ""))
            if tag == "main":
                for idx in range(len(radii)-1):
                    shape.append(dict(model=model, inner=radii[idx], outer=radii[idx+1],
                                      observed_slope=(speeds[idx+1]-speeds[idx])/(radii[idx+1]-radii[idx]),
                                      predicted_slope=(prediction[idx+1]-prediction[idx])/(radii[idx+1]-radii[idx])))
        if tag=="main":
            for idx,row in enumerate(rows):
                mts,nfw = float(row["mts"]),float(row["nfw"])
                differences.append(dict(R_kpc=radii[idx], mts_minus_nfw=mts-nfw,
                    shared_anchor_sigma_on_difference=abs(float(row["mts_per_kms"])-float(row["nfw_per_kms"]))*errors[-1]))
    for tag in TAGS[1:]:
        for kind in ("speed","vertical"):
            primary=[row for row in cache["main"] if row["kind"]==kind]
            alternative=[row for row in cache[tag] if row["kind"]==kind]
            for model in MODELS:
                values=vec(primary,model)
                gap=vec(alternative,model)-values
                idx=int(np.argmax(np.abs(gap/values)))
                robustness.append(dict(case=tag, kind=kind, model=model, max_abs=np.max(abs(gap)),
                    units="km/s" if kind=="speed" else "force-equivalent Msun/pc2",
                    max_relative=abs(gap[idx]/values[idx]), worst_relative_R=primary[idx]["R_kpc"],
                    worst_relative_z=primary[idx]["z_kpc"]))
    derivatives=[]
    for variable, lower, upper, step in (("eta","light","heavy",.1),("kms","slow","fast",1.91)):
        for kind in ("speed","vertical"):
            for model in MODELS:
                pick=lambda tag,key:vec([row for row in cache[tag] if row["kind"]==kind],key)
                direct=(pick(upper,model)-pick(lower,model))/(2*step)
                estimated=pick("main",model+"_per_"+variable)
                derivatives.append(dict(variable=variable,kind=kind,model=model,step=step,
                    max_slope_error=np.max(abs(direct-estimated)),
                    max_error_fraction_of_peak_slope=np.max(abs(direct-estimated))/np.max(abs(estimated))))
    for name, rows in (("rotation",rotation),("rotation-summary",scores),("vertical",vertical),
                       ("calibrations",roots),("stability",robustness),("shape",shape),("paired",differences),
                       ("jacobian-check",derivatives)):
        table(name+".csv", rows)
    other=read("older-tracer.csv")
    ote=vec(other,"R_kpc")
    table("older-summary.csv",[dict(model=model,region=region,**stats(vec(other,model+"_residual")[mask]))
          for model in MODELS for region,mask in (("all",ote>0),("within_Cepheid_span",(ote>=radii[0])&(ote<=OUTER)),
                                                  ("beyond_anchor",ote>OUTER),("inside_first_Cepheid",ote<radii[0]))])


if __name__ == "__main__":
    run()
