"""Read only the frozen wave to test the Newton source and compare older-star rotation."""
from branch import np, grid, load, predict, read, table, SURFACE, G, check
from disk_readout import vacuum_force
from disk_state import families, basis
from potential import foreground
from scipy.special import roots_legendre


def points(radius, height):
    return np.column_stack((-radius, np.zeros_like(radius), height))


def wave_density(system, state, location):
    scaled = location / system.length
    radii = np.linalg.norm(scaled, axis=1)
    coefficients = np.column_stack([basis(mode, root, system.edge, radii) @ vector
                                    for mode, root, vector in zip(system.orders, system.roots, state["coef"])])
    amplitude = (coefficients * families(scaled[:, 2] / radii, system.orders)).sum(axis=1)
    factor = system.vel ** 2 / (4 * np.pi * G * system.length ** 2)
    return amplitude ** 2 * factor


def source_tests(system, state):
    nodes, weights = roots_legendre(32)
    radius = 8.3
    rows = []
    for height in (.2, .8, 1.5, 2.):
        heights = (nodes + 1) * height / 2
        radii = np.full_like(heights, radius)
        positions = points(radii, heights)
        wave_density_values = wave_density(system, state, positions)
        halo_gm = .35 * 220 ** 2 * 8 * float(state["nfw"]) / (np.log1p(.5) - .5 / 1.5)
        distance = np.linalg.norm(positions, axis=1)
        halo_density_values = halo_gm / (4 * np.pi * G * distance * (16 + distance) ** 2)
        for model, density in (("mts", wave_density_values), ("nfw", halo_density_values)):
            def accel(at):
                if model == "mts":
                    return system.force(state["coef"], at)
                return float(state["nfw"]) * foreground(at)[2]
            exact = -accel(np.array([[-radius, 0., height]]))[0, 2]
            column = height * weights @ density / 1e6
            for step in (.04, .02, .01):
                right = (radius + step) * accel(points(radii + step, heights))[:, 0]
                left = (radius - step) * accel(points(radii - step, heights))[:, 0]
                radial_term = height / 2 * (weights @ ((right - left) / (2 * step * radius)))
                rec = SURFACE * column - radial_term
                rows.append(dict(component=model, R_kpc=radius, z_kpc=height, step_kpc=step,
                                 true_column_msun_pc2=column, force_equivalent_msun_pc2=exact / SURFACE,
                                 radial_term_kms2_kpc=radial_term, reconstructed_downward=rec,
                                 direct_downward=exact, relative_error=abs(rec / exact - 1)))
    table("poisson-slab.csv", rows)


def run():
    check()
    system, state = load("main")
    locations, kinds = grid()
    force = vacuum_force(system, state["coef"], locations)
    direct = system.force(state["coef"], locations)
    table("force-readouts.csv", [dict(kind=kind, R_kpc=-loc[0], z_kpc=loc[2],
                                      vector_relative=float(np.linalg.norm(ref - test) / np.linalg.norm(ref)),
                                      component_relative=abs(test[axis] / ref[axis] - 1))
                                for kind, loc, ref, test in zip(kinds, locations, direct, force)
                                for axis in [0 if kind == "speed" else 2]])
    source_tests(system, state)
    observed = read("eilers-table1.csv")
    radii = np.array([float(row["R_kpc"]) for row in observed])
    assert len(radii) == 38 and np.all(np.diff(radii) > 0) and radii[-1] < system.edge * system.length
    predicted = predict("main", system, state, points(radii, np.zeros_like(radii)), ["speed"] * len(radii))
    table("older-tracer.csv", [dict(**row, V_observed=float(obs["V_kms"]), sigma_minus=obs["minus_kms"],
                                    sigma_plus=obs["plus_kms"], mts_residual=row["mts"] - float(obs["V_kms"]),
                                    nfw_residual=row["nfw"] - float(obs["V_kms"]))
                               for row, obs in zip(predicted, observed)])


if __name__ == "__main__":
    run()
