"""Control-volume source test. No stellar measurements enter this calculation."""
from branch import G, np, ordinary, load, table, check
from force_tests import wave_density, points
from scipy.special import roots_legendre


def integrate(tag, order):
    system, state = load(tag)
    nodes, weights = roots_legendre(order)
    lo, hi = 7., 9.
    radii = (hi-lo)*nodes/2+(hi+lo)/2
    wr = weights*(hi-lo)/2
    rows=[]
    for height in (.2, .8, 1.5, 2.):
        heights=(1+nodes)*height/2
        wz=weights*height/2
        locations=np.vstack([points(radii,np.full_like(radii,height)),
                             points(np.full_like(heights,lo),heights),
                             points(np.full_like(heights,hi),heights)])
        bar,cloud,smooth=ordinary(system,locations)
        common=float(state["eta"])*bar+cloud
        wave=system.force(state["coef"],locations)
        altr,altz=np.meshgrid(radii,heights,indexing="ij")
        loc=points(altr.ravel(),altz.ravel())
        rho_wave=wave_density(system,state,loc)
        dist=np.linalg.norm(loc,axis=1)
        amp=float(state["nfw"])
        gm=.35*220**2*8*amp/(np.log1p(.5)-.5/1.5)
        rho_halo=gm/(4*np.pi*G*dist*(16+dist)**2)
        for name, force, density in (("ordinary",common,None),("wave",wave,rho_wave),("halo",amp*smooth,rho_halo)):
            lid=wr @ (radii * (-force[:order,2])) / G
            wall=wz @ (hi*force[2*order:,0]-lo*force[order:2*order,0]) / G
            mass=lid+wall
            integrated=4*np.pi*((wr*radii) @ density.reshape(order,order) @ wz) if density is not None else None
            rows.append(dict(case=tag,quadrature_order=order,component=name,R_inner=lo,R_outer=hi,zmax=height,
                             top_bottom_equivalent_msun=lid,radial_wall_equivalent_msun=wall,flux_mass_msun=mass,
                             volume_mass_msun=integrated if integrated is not None else "",
                             relative_flux_error=abs(mass/integrated-1) if integrated is not None else ""))
    return rows


def local(tag):
    system,state=load(tag)
    rows=[]
    for rad in (7.,8.3,9.):
        for step in (.02,.01):
            radii=np.array([rad-step,rad,rad+step])
            loc=points(radii,np.zeros_like(radii))
            bar,cloud,halo=ordinary(system,loc)
            common=float(state["eta"])*bar+cloud
            for model,field in (("mts",system.force(state["coef"],loc)),("nfw",float(state["nfw"])*halo)):
                speed=np.sqrt(radii*(common+field)[:,0])
                slope=(speed[2]-speed[0])/(2*step)
                rows.append(dict(case=tag,model=model,R_kpc=rad,derivative_step_kpc=step,
                                 speed_kms=speed[1],gradient_kms_per_kpc=slope,
                                 shear_Oort_A_kms_per_kpc=(speed[1]/rad-slope)/2,
                                 vorticity_Oort_B_kms_per_kpc=-(speed[1]/rad+slope)/2))
    return rows


if __name__=="__main__":
    check()
    table("annulus-mass.csv",[row for order in (12,24) for row in integrate("main",order)])
    table("local-gradients.csv",[row for tag in ("main","outer","above","light","heavy","slow","fast") for row in local(tag)])
