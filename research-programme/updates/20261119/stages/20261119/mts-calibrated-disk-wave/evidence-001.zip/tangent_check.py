"""Small-step independent nonlinear perturbations of the maintained outer-speed constraint."""
from branch import check, load, np, grid, ordinary, OUTER, ANCHOR, SPEED, RADII, DiskState, polish, table, read, SURFACE


def solve(base, saved, eta, target):
    system = DiskState(base.label, base.count, base.order, base.edge, eta)
    system.mass = float(saved["mass"])
    state = saved["coef"].copy()
    def total(coef):
        bar, cloud, halo = ordinary(system, ANCHOR)
        return OUTER * (eta * bar + cloud + system.force(coef, ANCHOR))[0,0]
    for count in range(12):
        solution = polish(system, state)
        state = solution.state
        delta = total(state)-target**2
        if abs(delta) < 1e-13 * target**2:
            break
        system.mass *= np.exp(-delta/float(saved["mass_slope"]))
    else:
        raise ValueError("small-step root")
    points, kinds = grid()
    bar, cloud, halo = ordinary(system, points)
    common=eta*bar+cloud
    outerbar, outercloud, outerhalo = ordinary(system, ANCHOR)
    amplitude=(target**2/OUTER-eta*outerbar[0,0]-outercloud[0,0])/outerhalo[0,0]
    def obs(force):
        cut=len(RADII)
        return np.r_[np.sqrt(RADII*force[:cut,0]),-force[cut:,2]/SURFACE]
    return obs(common+system.force(state,points)), obs(common+amplitude*halo), np.log(system.mass/float(saved["mass"]))


def run():
    check()
    base, saved=load("main")
    rows=read("main-grid.csv")
    result=[]
    for parameter, step in (("eta",.005),("kms",.0955)):
        def pert(sign):
            return solve(base,saved,1+sign*step if parameter=="eta" else 1., SPEED+sign*step if parameter=="kms" else SPEED)
        minus,plus=pert(-1),pert(1)
        for model, calc_low, calc_high in zip(("mts","nfw"),minus[:2],plus[:2]):
            finite=(calc_high-calc_low)/(2*step)
            exact=np.array([float(row[model+"_per_"+parameter]) for row in rows])
            for kind in ("speed","vertical"):
                indices=np.array([row["kind"]==kind for row in rows])
                result.append(dict(parameter=parameter,model=model,measure=kind,step=step,
                                   max_error_fraction_of_peak=np.max(abs(finite[indices]-exact[indices]))/np.max(abs(exact[indices]))))
        slope=(plus[2]-minus[2])/(2*step)
        exact=float(saved["logmass_per_"+parameter])
        result.append(dict(parameter=parameter,model="mts",measure="log_mass",step=step,max_error_fraction_of_peak=abs(slope/exact-1)))
    table("small-step-tangent.csv",result)


if __name__=="__main__":
    run()
