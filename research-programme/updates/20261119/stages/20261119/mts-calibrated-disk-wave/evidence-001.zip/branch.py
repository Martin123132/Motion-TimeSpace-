from pathlib import Path
import sys, csv, io, json, hashlib
HERE=Path(__file__).resolve().parent
BASE=HERE.parent/"mts-solar-differential-acceleration-20261119"
sys.path.insert(0,str(BASE))
from disk_tangent import DiskState, polish
from potential import np, foreground, sha, PARENT
SEAL="3e4c334bd731d29aafad839ddb49f0ac2365fe3c245d700b06d6243e01c210b9"
RADII=np.array([6.58,7.49,8.48,9.50,10.52,11.42,12.50,13.50,14.46,15.21,15.88,17.58])
OUTER=17.58
SPEED=224.03
ANCHOR=np.array([[-OUTER,0.,0.]])
G=4.30091727003628e-6
SURFACE=2*np.pi*G*1e6


def check():
    assert not (HERE/"STOP-REQUESTED").exists() and not (BASE/"STOP-REQUESTED").exists()
    assert sha(BASE/"seal.json")==SEAL


def write(name,content):
    path=HERE/name
    data=content.encode()
    if path.exists():
        assert path.read_bytes()==data,name
    else:
        with path.open("xb") as handle:
            handle.write(data)


def table(name,rows):
    buffer=io.StringIO(newline="")
    writer=csv.DictWriter(buffer,fieldnames=tuple(rows[0]),lineterminator="\n")
    writer.writeheader()
    writer.writerows(rows)
    write(name,buffer.getvalue())


def read(name):
    with (HERE/name).open(encoding="utf8",newline="") as handle:
        result=list(csv.DictReader(handle))
    assert result and all(None not in row and None not in row.values() for row in result)
    return result


def save(name,fields):
    path=HERE/(name+".npz")
    if path.exists():
        with np.load(path) as old:
            assert set(old.files)==set(fields) and all(np.array_equal(old[key],value) for key,value in fields.items()),name
    else:
        with path.open("xb") as dest:
            np.savez_compressed(dest,**fields)


def ordinary(system,points):
    disk,bulge,halo=foreground(points)
    dist=np.linalg.norm(points,axis=1)
    cloud=-system.material(dist/system.length)[0][:,None]*points/dist[:,None]*system.vel**2/system.length
    return disk+bulge,cloud,halo


def solve(tag,seed,eta,target):
    check()
    assert sha(BASE/(seed+".npz"))==json.loads((BASE/"seal.json").read_bytes())["files"][seed+".npz"]
    with np.load(BASE/(seed+".npz")) as initial:
        label=str(initial["label"])
        sysm=DiskState(label,int(initial["count"]),int(initial["order"]),float(initial["edge"]),eta)
        first=initial["coef"]
    with np.load(PARENT/(("angular24-cap" if label=="cap" else "angular28-diff")+".npz")) as parent:
        mass_unit=float(parent["mass_unit_msun"])
    bar,cloud,halo=ordinary(sysm,ANCHOR)
    common=OUTER*(eta*bar[0,0]+cloud[0,0])
    nfw=(target**2-common)/(OUTER*halo[0,0])
    assert nfw>0
    if eta!=1:
        first=sysm.solve(first)["coef"]
    curve=polish(sysm,first.copy())
    rows=[]
    for iteration in range(16):
        check()
        direction,_,_,resid=curve.differentiate("mass")
        value=common+OUTER*sysm.force(curve.state,ANCHOR)[0,0]
        jac=OUTER*sysm.force(curve.state,ANCHOR,tangent=direction)[0,0]
        assert jac>0 and value>0
        rows.append(dict(step=iteration,mass_msun=sysm.mass*mass_unit,speed=np.sqrt(value),speed2_mass_slope=jac,
                         stationarity=np.linalg.norm(curve.resid),norm_error=np.sum(curve.state**2)/sysm.mass-1,tangent_residual=resid))
        if abs(value-target**2)<3e-11*target**2:
            break
        step=np.clip((target**2-value)/jac,-.12,.12)
        sysm.mass*=np.exp(step)
        curve=polish(sysm,curve.state+step*direction)
    else:
        raise RuntimeError("local continuation did not reach calibration")
    other,_,_,_=curve.differentiate("baryons")
    eta_slope=OUTER*(bar[0,0]+sysm.force(curve.state,ANCHOR,tangent=other)[0,0])
    state=dict(coef=curve.state,mass_tangent=direction,baryon_tangent=other,mass=sysm.mass,mass_msun=sysm.mass*mass_unit,
               seed=seed,label=label,eta=eta,target=target,nfw=nfw,length=sysm.length,order=sysm.order,count=sysm.count,
               edge=sysm.edge,mass_slope=jac,eta_slope=eta_slope,logmass_per_eta=-eta_slope/jac,logmass_per_kms=2*target/jac,
               virial=sysm.parts(curve.state)[3],protocol=sha(HERE/"PROTOCOL.md"))
    save(tag,state)
    table(tag+"-path.csv",rows)
    print(tag,len(rows),"mass",state["mass_msun"],"NFW",nfw,"rescued residual",rows[-1]["speed"]-target,flush=True)
    return sysm,state


def predict(tag,system,state,points,kinds):
    bar,cloud,halo=ordinary(system,points)
    wave=system.force(state["coef"],points)
    mass_response=system.force(state["coef"],points,tangent=state["mass_tangent"])
    baryon_response=system.force(state["coef"],points,tangent=state["baryon_tangent"])
    ext0,_,halo0=ordinary(system,ANCHOR)
    smooth=float(state["nfw"])*halo
    eta=float(state["eta"])
    background=eta*bar+cloud
    grav=wave+background
    control=smooth+background
    derivative_eta=bar+baryon_response+state["logmass_per_eta"]*mass_response
    derivative_speed=state["logmass_per_kms"]*mass_response
    smooth_eta=bar-halo*ext0[0,0]/halo0[0,0]
    smooth_speed=halo*2*float(state["target"])/(OUTER*halo0[0,0])
    rows=[]
    for idx,(point,kind) in enumerate(zip(points,kinds)):
        rad=-point[0]
        if kind=="speed":
            factor=rad
            values=[np.sqrt(factor*vec[idx,0]) for vec in (grav,control,halo+background)]
            rates=[factor*vec[idx,0]/(2*base) for vec,base in zip((derivative_eta,smooth_eta,derivative_speed,smooth_speed),[values[0],values[1]]*2)]
        else:
            factor=-1/SURFACE
            values=[factor*vec[idx,2] for vec in (grav,control,halo+background)]
            rates=[factor*vec[idx,2] for vec in (derivative_eta,smooth_eta,derivative_speed,smooth_speed)]
        rows.append(dict(kind=kind,R_kpc=rad,z_kpc=point[2],mts=values[0],nfw=values[1],original_nfw=values[2],
                         mts_per_eta=rates[0],nfw_per_eta=rates[1],mts_per_kms=rates[2],nfw_per_kms=rates[3],
                         wave_gR=wave[idx,0],wave_gz=wave[idx,2],ordinary_gR=background[idx,0],ordinary_gz=background[idx,2]))
    return rows


def grid():
    pins=[[-rad,0.,0.] for rad in RADII]
    vertical=[[-rad,0.,height/10] for rad in (7.,7.5,8.,8.1,8.2,8.3,8.5,9.) for height in range(2,21)]
    return np.array(pins+vertical),["speed"]*len(pins)+["vertical"]*len(vertical)


def load(tag):
    with np.load(HERE/(tag+".npz")) as pack:
        state=dict(pack)
    system=DiskState(str(state["label"]),int(state["count"]),int(state["order"]),float(state["edge"]),float(state["eta"]))
    system.mass=float(state["mass"])
    return system,state


if __name__=="__main__":
    tag,seed,eta,target=sys.argv[1:]
    sysm,state=solve(tag,seed,float(eta),float(target))
    table(tag+"-grid.csv",predict(tag,sysm,state,*grid()))
