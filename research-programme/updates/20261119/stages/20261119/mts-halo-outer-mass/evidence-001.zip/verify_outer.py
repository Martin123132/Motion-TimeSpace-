import sys
import json
import importlib.util
from forecast import HERE,PARENT,PRESEAL,bridge

spec=importlib.util.spec_from_file_location("outer_halo_tracer_comparison",HERE/"compare.py")
comparison=importlib.util.module_from_spec(spec)
spec.loader.exec_module(comparison)


def verify():
    assert bridge.sha(PARENT/"seal.json")==PRESEAL
    assert bridge.sha(HERE/"frozen.json")=="7bd9232c2346b3ff784878df573c9875900526443c6c3f4dd5b9c776b4a2e4ee"
    parent=json.loads((PARENT/"seal.json").read_bytes())
    for name,digest in parent["files"].items():
        assert bridge.sha(PARENT/name)==digest,name
    for name,digest in parent["inputs"].items():
        assert bridge.sha(PARENT.parent/name)==digest,name
    forecast,compare,shell=comparison.process(False)
    assert len(forecast)==12 and len(compare)==18 and len(shell)==2
    for row in shell:
        assert 0<row["shell_at_largest_total_occupation_msun"]<row["max_shell_lower_msun"]<=row["max_shell_upper_msun"]<row["adopted_upper_with_numerical_margin_msun"]
        assert row["minimum_other_shell_at_Gibbons14_marginal_extremes_msun"]==0.
    assert all(0<=row["minimum_other_lower_endpoint"]<=row["minimum_other_central"]<=row["total"] for row in compare)
    assert not any(path.is_dir() or path.suffix in (".tmp",".pyc") for path in HERE.iterdir())
    return dict(parent=PRESEAL,rows={"mass-forecast.csv":len(forecast),"tracer-comparison.csv":len(compare),"shell-envelope.csv":len(shell)},
                files={path.name:bridge.sha(path) for path in sorted(HERE.iterdir()) if path.name!="seal.json"})


if __name__=="__main__":
    report=verify()
    path=HERE/"seal.json"
    if sys.argv[1:]==["seal"]:
        with path.open("x",encoding="utf8") as output:
            json.dump(report,output,sort_keys=True,indent=2)
    assert json.loads(path.read_bytes())==report
    print("VERIFIED",len(report["files"]),"files",sum(report["rows"].values()),"rows",bridge.sha(path))
