import sys
from forecast import freeze,table,data,MSUN,KG,LENGTH,parsec,np,TOL,solve_edge

TRACERS=(
    ("Gibbons14_Table3",50,2.9,.4,.4,0.,"https://arxiv.org/abs/1406.2243"),
    ("Gibbons14_Table3",100,4.1,.7,.7,0.,"https://arxiv.org/abs/1406.2243"),
    ("Erkal19_Orphan",50,3.80,.11,.14,0.,"https://arxiv.org/abs/1812.08192"),
    ("Vasiliev21_Sagittarius",100,5.6,.4,.4,0.,"https://arxiv.org/abs/2009.10726"),
    ("Deason21_halo_stars",100,6.07,.29,.29,1.21,"https://arxiv.org/abs/2010.13801"),
    ("CorreaMagnus_Vasiliev22",100,7.5,1.,1.,0.,"https://arxiv.org/abs/2110.00018"))


def comparisons(forecasts):
    for name,rad,nom,lower,upper,systematic,url in TRACERS:
        for entry in forecasts:
            if entry["preparation"]=="illustrative" or entry["rad_kpc"]!=rad:
                continue
            cap=entry["wave_mass_msun"]/1e11
            yield dict(source=name,aperture_kpc=rad,unit="1e11 Msun",total=nom,lower_error=lower,upper_error=upper,
                       separately_reported_systematic=systematic or "",speed_case=entry["preparation"],wave_upper=cap,
                       minimum_other_central=max(0.,nom-cap),minimum_other_lower_endpoint=max(0.,nom-lower-systematic-cap),
                       isothermal_upper=entry["singular_isothermal_cap_msun"]/1e11,url=url)


def shellmax(profile,scale_floor):
    radius=50000*parsec/LENGTH
    factor=KG/(MSUN*radius)
    def integrated(rad):
        values=profile(rad)
        return rad**2*(values[...,3] if profile.axis==0 else values[3])
    edges=np.linspace(0,50000/scale_floor,129)
    lo,hi=edges[:-1],edges[1:]
    assert hi[-1]*2<profile.x[-1]
    best=0.
    for refinement in range(40):
        center=(lo+hi)/2
        inside=center*(integrated(2*center)-integrated(center))
        idx=np.argmax(inside)
        if inside[idx]>best:
            best=inside[idx]
            best_s=center[idx]
        enclosure=hi*(integrated(2*hi)-integrated(lo))
        upper=max(enclosure)
        if upper/best-1 < 1e-6:
            return best*factor,upper*factor,50000/best_s
        keep=enclosure>=best
        lo,hi,center=lo[keep],hi[keep],center[keep]
        lo,hi=np.r_[lo,center],np.r_[center,hi]
    raise ArithmeticError("shell interval did not close")


def shells(forecasts):
    prof=data()
    alternate=solve_edge(42.,821,False,True)[2]
    for prep in ("central_cap","plus3_cap"):
        scale=next(row["scale_pc"] for row in forecasts if row["preparation"]==prep)
        low,upper,near=shellmax(prof,scale)
        alt_low,alt_upper,_=shellmax(alternate,scale)
        assert max(abs(alt_upper/upper-1),abs(alt_low/low-1),upper/low-1)<TOL
        conservative=max(upper,alt_upper)*(1+TOL)
        base=next(row["wave_mass_msun"] for row in forecasts if row["preparation"]==prep and row["rad_kpc"]==50.)
        edge=next(row["wave_mass_msun"] for row in forecasts if row["preparation"]==prep and row["rad_kpc"]==100.)
        yield dict(speed_case=prep,max_shell_lower_msun=low,max_shell_upper_msun=upper,
                   adopted_upper_with_numerical_margin_msun=conservative,approx_maximizing_scale_pc=near,
                   shell_at_largest_total_occupation_msun=edge-base,
                   minimum_other_shell_at_Gibbons14_central_msun=max(0.,(4.1-2.9)*1e11-conservative),
                   minimum_other_shell_at_Gibbons14_marginal_extremes_msun=max(0.,((4.1-.7)-(2.9+.4))*1e11-conservative),
                   mesh_test=abs(alt_upper/upper-1))


def process(create):
    forecasts=freeze(False)
    from forecast import HERE
    compare=table("tracer-comparison.csv",comparisons(forecasts),create and not (HERE/"tracer-comparison.csv").exists())
    shells_out=table("shell-envelope.csv",shells(forecasts),create and not (HERE/"shell-envelope.csv").exists())
    assert len(compare)==18 and len(shells_out)==2
    assert all(entry["half_mass_kpc"]>0 for entry in forecasts)
    all_caps=[row for row in forecasts if row["preparation"]=="central_cap"]
    assert all_caps[0]["wave_mass_msun"]<all_caps[1]["wave_mass_msun"]<all_caps[2]["wave_mass_msun"]
    print(shells_out)
    return forecasts,compare,shells_out


if __name__=="__main__":
    process(sys.argv[1:]==["create"])
