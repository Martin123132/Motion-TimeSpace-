import sys
import os
from pathlib import Path
for key in ("OPENBLAS_NUM_THREADS","MKL_NUM_THREADS","OMP_NUM_THREADS","NUMEXPR_NUM_THREADS"):
    os.environ[key]="1"
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
PARENT=HERE.parent/"mts-bound-halo-proper-clocks-20261119"
sys.path.insert(0,str(PARENT))
from outer_speed import SPEED_KMS, QUOTED_KMS, controls
from milkyway import measures, data, RC, SCALE
from halo_mean import bridge, np, TOL, guard
from bound_state import solve_edge, KG, LENGTH, MSUN
from scipy.constants import G, parsec, hbar, c
from scipy.optimize import brentq
from scipy.integrate import quad
import csv
import json

PRESEAL="730dfa7dc7d9e8663b6387d798e493097d37cd220d0b651c20d539bbfdef8da3"


def table(name,rows,create=False):
    rows=list(rows)
    target=HERE/name
    if create:
        with target.open("x",newline="",encoding="utf8") as out:
            writer=csv.DictWriter(out,fieldnames=rows[0])
            writer.writeheader()
            writer.writerows(rows)
    with target.open(newline="",encoding="utf8") as inp:
        assert list(csv.DictReader(inp))==[{key:str(val) for key,val in row.items()} for row in rows], name
    return rows


def predict():
    guard()
    assert bridge.sha(PARENT/"seal.json")==PRESEAL
    if (HERE/"STOP-REQUESTED").exists():
        raise SystemExit("owner hold")
    primary=data()
    long=solve_edge(42.,821,False,True)[2]
    rows=[]
    pole_mass=hbar/(LENGTH*c)
    for tag,offset in (("illustrative",None),("central_cap",0),("plus1_cap",1),("plus3_cap",3)):
        speed=SPEED_KMS+(0 if offset is None else offset)*QUOTED_KMS
        cap=(1000*speed)**2*RC*LENGTH/(G*MSUN)
        def summary(profile):
            scale=SCALE if offset is None else brentq(lambda length: measures(profile,length)[1]/cap-1, RC/25,8*SCALE)
            def enclosed(point):
                return point**2*profile(point)[3]
            last=profile.x[-1]
            total=enclosed(last)
            half=brentq(lambda point:enclosed(point)-total/2,.01,10.)
            result=[]
            for radius in (50.,100.,None):
                point=last if radius is None else radius*1000*parsec/(scale*LENGTH)
                assert point<=last
                mass=enclosed(point)*KG/(scale*MSUN)
                integral=quad(lambda rad:rad**2*profile(rad)[0]**2,0.,point,epsrel=1e-9,epsabs=1e-9)[0]
                result.append((mass,abs(integral/enclosed(point)-1)))
            return scale*LENGTH/parsec,half*scale*LENGTH/(parsec*1000),result
        scale,half,values=summary(primary)
        alt_scale,alt_half,other=summary(long)
        for idx,radius in enumerate((50.,100.,None)):
            mass,err=values[idx]
            independent=abs(mass/other[idx][0]-1)
            assert max(err,independent,abs(half/alt_half-1),abs(scale/alt_scale-1))<TOL
            iso=radius*1000*parsec*(1000*speed)**2/(G*MSUN) if radius and offset is not None else ""
            rows.append(dict(preparation=tag,rad_kpc=radius if radius else "total",scale_pc=scale,half_mass_kpc=half,
                             wave_mass_msun=mass,effective_total_quanta=mass*MSUN/pole_mass if radius is None else "",
                             singular_isothermal_cap_msun=iso,mass_integral_error=err,larger_domain_error=independent))
    return rows


def freeze(create):
    rows=table("mass-forecast.csv",predict(),create)
    records={item.name:bridge.sha(item) for item in (HERE/"forecast.py",HERE/"PROTOCOL.md",HERE/"mass-forecast.csv",PARENT/"seal.json")}
    path=HERE/"frozen.json"
    if create:
        with path.open("x",encoding="utf8") as out:
            json.dump(records,out,indent=2,sort_keys=True)
    assert records==json.loads(path.read_bytes())
    return rows


if __name__=="__main__":
    print(freeze(sys.argv[1:]==["freeze"])[3:6])
