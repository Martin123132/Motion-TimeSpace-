from experiment import *
from dilute_test import eligible_lock, portions,maxabs
from fine_even import fine_lock
from driven_energy_check import freeze as driven_lock


def numericclose(actual,expected,tol=5e-11):
    a=np.asarray(actual,dtype=float)
    b=np.asarray(expected,dtype=float)
    assert np.max(abs(a-b))<=tol*max(float(np.max(abs(b))),1e-100), (actual,expected)


def verify_forecasts(rows):
    assert len(rows["energy-preparations.csv"])==24 and len(rows["eligible-preparations.csv"])==8
    for mesh in (128,256):
        dense=bridge.read(HOME/f"forecasts-{mesh}.npz")
        light=bridge.read(HOME/f"eligible-forecast-{mesh}.npz")
        bases=[bridge.read(HOME/f"basis-{mesh}-{name}.npz") for name in ("hu","hv","uu","uv","vv")]
        for prep in ("N","M"):
            archive_rows=[bridge.read(HOME/node_name(mesh,prep,node)) for node in NODES]
            for row in rows["energy-preparations.csv"]:
                if int(row["mesh"])!=mesh or row["prep"]!=prep:
                    continue
                amp=float(row["seed"])
                coeff=np.array([amp,float(row["shell"])])
                numericclose(.5*coeff@dense["gram"]@coeff,float(row["proper_excitation"]),1e-13)
                for site in LOCATIONS:
                    values=np.stack([packet[site+"_delta64"] for packet in archive_rows])
                    for label,indices in (("high",np.arange(7)),("low",np.array([0,2,3,4,6]))):
                        x=NODES[indices]/3
                        powers=np.arange(len(indices))
                        moments=amp*(amp/SCALE)**powers/(1+powers)
                        weights=np.linalg.solve(x[None,:]**powers[:,None],moments)
                        rebuilt=np.tensordot(weights,values[indices],axes=1)
                        numericclose(rebuilt,dense[f"{prep}_{row['case']}_{site}_64_{label}"])
            for sign in (-1,1):
                row,=[r for r in rows["eligible-preparations.csv"] if int(r["mesh"])==mesh and r["prep"]==prep and int(r["sign"])==sign]
                amp,amount,scale=[float(row[k]) for k in ("seed","shell","quiet_scale")]
                numericclose(float(row["energy"]),2.5e-16)
                for site in LOCATIONS:
                    expected=sum(val*packet[site+"_delta64"] for val,packet in
                                 zip((amp*scale,amount*scale,amp**2,amp*amount,amount**2),bases))
                    numericclose(expected,light[f"{prep}_{sign}_{site}_64"])


def verify_table(rows,version):
    dense=version!="eligible"
    withquad=dense
    fore={mesh:bridge.read(HOME/(f"forecasts-{mesh}.npz" if dense else f"eligible-forecast-{mesh}.npz")) for mesh in (128,256)}
    assert len(rows)==len({(r["link"],r["prep"],r["parity"],r["channel"]) for r in rows})==96
    for prep in ("M","N"):
        banks={}
        quiet={}
        for mesh in (128,256):
            if version=="raw":
                quiet[mesh]=bridge.read(HOME/f"held-{mesh}-N-0.npz")
            for sign in (1,-1):
                name={"raw":"held","paired":"paired","eligible":"eligible-target"}[version]
                banks[mesh,sign]=bridge.read(HOME/f"{name}-{mesh}-{prep}-{sign}.npz")
        for row in rows:
            if row["prep"]!=prep:
                continue
            idx=CHANNELS.index(row["channel"])
            site=row["link"]
            parity=row["parity"]
            def get(mesh,panels,truth,coarse=False):
                items=[]
                for sign in (1,-1):
                    if truth and version=="raw":
                        key=f"{site}_base{panels}"
                        curve=banks[mesh,sign][key][idx]-quiet[mesh][key][idx]
                    elif truth:
                        curve=banks[mesh,sign][f"{site}_{panels}"][idx]
                    elif dense:
                        case="energyplus" if sign>0 else "energyminus"
                        order="low" if coarse else "high"
                        curve=fore[mesh][f"{prep}_{case}_{site}_{panels}_{order}"][idx]
                    else:
                        curve=fore[mesh][f"{prep}_{sign}_{site}_{panels}"][idx]
                    items.append(curve)
                return portions(*items)[parity]
            value=get(256,64,False)
            target=get(256,64,True)
            peak=np.argmax(abs(target))
            assert float(row["peak_emit"])==EMISSIONS[peak] and float(row["true_peak"])==target[peak]
            errors=[maxabs(item)/maxabs(target) for item in
                    (value-target,value-get(128,64,False),target-get(128,64,True),value-get(256,32,False),target-get(256,32,True))]
            columns=["model","pred_grid","target_grid","pred_ray","target_ray"]
            if withquad:
                errors.append(maxabs(value-get(256,64,False,True))/maxabs(target))
                columns.append("amp_integral")
            for key,err in zip(columns,errors):
                numericclose(err,float(row[key]))
            numericclose(sum(errors),float(row["total"]))
            assert (row["passes"]=="True")==(sum(errors)<=TOL)


def verify_refinement(rows):
    frozen=bridge.read(HOME/"refined-even-forecast.npz")
    previous=bridge.read(HOME/"forecasts-256.npz")
    terms=("model","pred_grid","target_grid","pred_ray","target_ray","parameter_quadrature")
    assert len(rows)==4 and {(row["background"],row["channel"]) for row in rows}=={
        (model,channel) for model in ("dense","dilute") for channel in ("out","out_delay")}
    for row in rows:
        dense=row["background"]=="dense"
        channel=CHANNELS.index(row["channel"])
        group="paired" if dense else "eligible-target"
        def even(mesh,panels):
            key=f"outer_{panels}"
            pos=bridge.read(HOME/f"{group}-{mesh}-M-1.npz")[key][channel]
            neg=bridge.read(HOME/f"{group}-{mesh}-M--1.npz")[key][channel]
            assert pos.shape==neg.shape==(len(EMISSIONS),)
            return (pos+neg)*.5
        target=even(384,64)
        norm=maxabs(target)
        assert norm>0
        numericclose(norm,float(row["peak"]))
        fit=frozen["dense_64_high" if dense else "dilute_384_64"][channel]
        previous_fit=((previous["M_energyplus_outer_64_high"]+previous["M_energyminus_outer_64_high"])*.5
                      if dense else frozen["dilute_256_64"])[channel]
        low_ray=frozen["dense_32_high" if dense else "dilute_384_32"][channel]
        low_amp=frozen["dense_64_low"][channel] if dense else fit
        diffs=[target-fit,fit-previous_fit,target-even(256,64),fit-low_ray,target-even(384,32),fit-low_amp]
        ratios=[maxabs(delta)/norm for delta in diffs]
        for key,ratio in zip(terms,ratios):
            numericclose(ratio,float(row[key]))
        numericclose(sum(ratios),float(row["total"]))
        assert (sum(ratios)<=TOL)==(row["passes"]=="True")


def verify():
    guard()
    assert __debug__
    assert not any(f.is_dir() or f.name.endswith(".partial") for f in HOME.iterdir())
    prev=json.loads((PARENT/"seal.json").read_bytes())
    assert len(prev["files"])==61 and all(bridge.sha(PARENT/name)==v for name,v in prev["files"].items())
    lock()
    eligible_lock()
    fine_lock()
    driven_lock()
    assert bridge.sha(HOME/"frozen.json")=="76184ba6adf8ab161bb7a5a15eb12b1ac94008cbcc60f2b0548529cff107c750"
    assert bridge.sha(HOME/"eligible-frozen.json")=="e207c3961ce6ca5f034796f99f7a6d1aef12332245feeb11859fe32dcbb14f92"
    tables={}
    for path in sorted(HOME.glob("*.csv")):
        with path.open(newline="",encoding="utf-8") as stream:
            rows=list(csv.DictReader(stream))
        assert rows and all(None not in r and None not in r.values() for r in rows),path
        for row in rows:
            for cell in row.values():
                try:
                    number=float(cell)
                except ValueError:
                    continue
                assert np.isfinite(number), (path,cell)
        tables[path.name]=rows
    for path in HOME.glob("*.npz"):
        with np.load(path,allow_pickle=False) as data:
            assert data.files and all(np.isfinite(data[key]).all() for key in data.files if data[key].dtype.kind in "icfu"),path
    verify_forecasts(tables)
    for key,name in (("raw","held-raw-budgets.csv"),("paired","held-paired-budgets.csv"),("eligible","eligible-clock-budgets.csv")):
        verify_table(tables[name],key)
    verify_refinement(tables["refined-even-budgets.csv"])
    sources=tables["source-ellipse.csv"]
    eligible=[r for r in tables["source-ellipse-exact-checks.csv"] if r["background"]=="conditional_0.1"]
    tested=max(float(r["exact_energy"]) for r in eligible)
    cap=tables["nonlinear-ceiling.csv"]
    assert len(cap)==8 and tested<=float(cap[-1]["necessary_energy_upper"])<1.002*tested
    assert float(sources[-1]["maximum_exact_sampled"])==tested
    assert float(tables["nonlinear-energy-exclusion.csv"][0]["net_mass_lower_over_energy"])>.60
    assert all(row["passes"]=="True" for row in tables["analytic-clock-controls.csv"])
    assert len(tables["material-induced-quartic.csv"])==24
    assert all(r["passes"]=="True" for r in tables["material-induced-quartic.csv"])
    for mesh in (160,320):
        direct=tables[f"material-driven-full-{mesh}.csv"]
        assert len(direct)==len({(r["eta"],r["k"]) for r in direct})==6
        for r in direct:
            suffix=f"{float(r['eta']):g}-{r['k']}-{mesh}.npz"
            target=bridge.read(HOME/("driven-full-"+suffix))
            assert target["freeze"].item().decode()==bridge.sha(HOME/"driven-freeze.json")
            forecast=bridge.read(HOME/("driven-"+suffix))["series"]
            for column,field in ((0,"field_error"),(1,"energy_error")):
                full=target["full"][:,column]
                err=maxabs(full-forecast[:,column])/maxabs(full)
                numericclose(err,float(r[field]))
                assert (err<=TOL)==(r[field.replace("_error","_pass")]=="True")
            numericclose(target["full"][-1,1],float(r["full_energy"]))
            numericclose(forecast[-1,1],float(r["predicted_energy"]))
    for document in ("RESULTS.md","REPLAY.md","DERIVATION.md","MATTER-DRIVE.md","SOURCE-ENERGY-LIMIT.md","NONLINEAR-CEILING.md"):
        assert (HOME/document).stat().st_size>250
    dest=HOME/"seal.json"
    record=dict(parent=PARENT_SHA,parent_files=len(prev["files"]),rows={name:len(r) for name,r in tables.items()},
                files={p.name:bridge.sha(p) for p in sorted(HOME.iterdir()) if p!=dest})
    if dest.exists():
        assert record==json.loads(dest.read_bytes())
    else:
        with dest.open("x") as stream:
            json.dump(record,stream,indent=2,sort_keys=True)
    print("Verified",len(record["files"]),"files",sum(record["rows"].values()),"rows",bridge.sha(dest))


if __name__=="__main__":
    verify()
