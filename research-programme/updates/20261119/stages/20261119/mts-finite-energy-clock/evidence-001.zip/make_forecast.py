from experiment import *
from scipy.constants import G, c, parsec


CASES=("u1","d1","u2","d2","energyplus","energyminus")
INPUTS=(.0001,-.0001,.0002,-.0002)


def weights(amp,nodes):
    ends=amp/SCALE
    knots=np.asarray(nodes)/3
    result=[]
    for index,value in enumerate(knots):
        other=np.delete(knots,index)
        poly=Polynomial.fromroots(other).integ()
        result.append(SCALE*(poly(ends)-poly(0))/np.prod(value-other))
    factors=np.array(result)
    for degree in range(len(nodes)):
        expected=amp*ends**degree/(degree+1)
        assert abs(factors@knots**degree-expected)<2e-18
    return factors


def prepare(mesh):
    current=Preparation(mesh)
    dest={}
    rows=[]
    scale=json.loads((HOME.parent/"mts-two-radius-pressure-clock-20261119/physical-clock-scale.json").read_text())
    energy_unit=c**4*(scale["length_pc"]*parsec)/G
    radius=current.radius
    factor=radius**2/np.sqrt(current.fquiet)
    fields=(current.pulse,current.shell)
    gram=np.array([[simpson(factor*(left[0]*right[0]+current.fquiet*left[1]*right[1]),x=radius)
                    for right in fields] for left in fields])
    assert min(np.linalg.eigvalsh(gram))>0
    mask=radius<=3.
    quiet_energy=.5*simpson((factor*(current.height**2+current.fquiet*current.slope**2))[mask],x=radius[mask])
    for prep in ("N","M"):
        archive_rows=[bridge.read(HOME/node_name(mesh,prep,node)) for node in NODES]
        amps=(*INPUTS,current.seed(1,prep),current.seed(-1,prep))
        for case,amp in zip(CASES,amps):
            amount,slope,ripple,dm,_,energy=current.prepare(amp,prep)
            coeff=np.array([amp,amount])
            assert abs(energy-.5*coeff@gram@coeff)<1e-14*energy
            if case.startswith("energy"):
                assert abs(energy/ENERGY-1)<1e-13
            rows.append(dict(mesh=mesh,prep=prep,case=case,seed=amp,shell=amount,dshell_dseed=slope,
                             proper_excitation=energy,gram_value=.5*coeff@gram@coeff,energy_joule=energy*energy_unit,
                             fraction_quiet_scalar_inside_3=energy/quiet_energy,net_mass_at_3=dm[current.index],
                             net_mass_at_12=dm[-1],mass_monopole_per_excitation=dm[-1]/energy))
            for site in LOCATIONS:
                for panels in (32,64):
                    signal=np.array([row[f"{site}_delta{panels}"] for row in archive_rows])
                    for label,indices in (("high",np.arange(7)),("low",np.array([0,2,3,4,6]))):
                        val=np.tensordot(weights(amp,NODES[indices]),signal[indices],axes=1)
                        dest[f"{prep}_{case}_{site}_{panels}_{label}"]=val
    archive(f"forecasts-{mesh}.npz",gram=gram,**dest)
    return rows


if __name__=="__main__":
    guard()
    table("energy-preparations.csv",prepare(128)+prepare(256))
    lock(True)
