from experiment import *
from make_forecast import CASES, INPUTS


def maxabs(arr):
    return float(np.max(np.abs(arr)))


def portions(plus,minus):
    return {"plus":plus,"minus":minus,"odd":(plus-minus)/2,"even":(plus+minus)/2}


def table_held(version):
    lock()
    preds=[bridge.read(HOME/f"forecasts-{mesh}.npz") for mesh in (128,256)]
    rows=[]
    for prep in ("M","N"):
        targets={}
        for mesh in (128,256):
            if version=="raw":
                quiet=bridge.read(HOME/f"held-{mesh}-N-0.npz")
                src=[bridge.read(HOME/f"held-{mesh}-{prep}-{sign}.npz") for sign in (1,-1)]
            else:
                src=[bridge.read(HOME/f"paired-{mesh}-{prep}-{sign}.npz") for sign in (1,-1)]
            for panels in (32,64):
                for site in LOCATIONS:
                    if version=="raw":
                        key=f"{site}_base{panels}"
                        pair=[item[key]-quiet[key] for item in src]
                    else:
                        pair=[item[f"{site}_{panels}"] for item in src]
                    targets[mesh,site,panels]=portions(*pair)
        for site in LOCATIONS:
            def prediction(index,panels,order):
                return portions(*[preds[index][f"{prep}_energy{sgn}_{site}_{panels}_{order}"] for sgn in ("plus","minus")])
            fine=prediction(1,64,"high")
            small=prediction(0,64,"high")
            lower=prediction(1,64,"low")
            ray=prediction(1,32,"high")
            for parity in fine:
                for idx,channel in enumerate(CHANNELS):
                    truth=targets[256,site,64][parity][idx]
                    value=fine[parity][idx]
                    peak=int(np.argmax(abs(truth)))
                    scale=abs(truth[peak])
                    assert scale>0 and np.isfinite(scale)
                    error=lambda delta:maxabs(delta)/scale
                    comp=[error(value-truth),error(value-small[parity][idx]),error(truth-targets[128,site,64][parity][idx]),
                          error(value-lower[parity][idx]),error(value-ray[parity][idx]),error(truth-targets[256,site,32][parity][idx])]
                    rows.append(dict(prep=prep,link=site,parity=parity,channel=channel,peak_emit=EMISSIONS[peak],
                                     true_peak=truth[peak],forecast_at_peak=value[peak],model=comp[0],pred_grid=comp[1],target_grid=comp[2],
                                     amp_integral=comp[3],pred_ray=comp[4],target_ray=comp[5],total=sum(comp),passes=sum(comp)<=TOL))
    table("held-"+version+"-budgets.csv",rows)


def retrospective():
    lock()
    pred=bridge.read(HOME/"forecasts-128.npz")
    quiet=bridge.read(PARENT/"finite-quiet.npz")
    output=[]
    for prep in ("M","N"):
        for tag,labels,size in (("1",("halfplus","halfminus"),.0001),("2",("plus","minus"),.0002)):
            archives=[bridge.read(PARENT/f"full-{prep}-128-q0.8-{label}.npz") for label in labels]
            for site in ("inner","outer"):
                true=portions(*[data[site+"_base64"]-quiet[site+"_base64"] for data in archives])
                wave=portions(*[pred[f"{prep}_{sgn}{tag}_{site}_64_high"] for sgn in ("u","d")])
                for parity in wave:
                    for idx,name in enumerate(CHANNELS):
                        score=maxabs(wave[parity][idx]-true[parity][idx])/maxabs(true[parity][idx])
                        output.append(dict(prep=prep,size=size,link=site,parity=parity,channel=name,
                                           peak=maxabs(true[parity][idx]),relative=score,meets_model_tolerance=score<=TOL))
    table("saved-event-comparison.csv",output)


def leading():
    lock()
    full=bridge.read(HOME/"forecasts-128.npz")
    basis={name:bridge.read(HOME/f"basis-128-{name}.npz") for name in ("hu","hv","uu","uv","vv")}
    spec=Preparation(128)
    ledger=[]
    shape=[]
    for prep in ("N","M"):
        amps=(*INPUTS,spec.seed(1,prep),spec.seed(-1,prep))
        for case,amplitude in zip(CASES,amps):
            amount=spec.prepare(amplitude,prep)[0]
            weights=np.array([amplitude,amount,amplitude**2,amplitude*amount,amount**2])
            for site in LOCATIONS:
                terms=np.array([item[site+"_delta64"] for item in basis.values()])*weights[:,None,None]
                reference=full[f"{prep}_{case}_{site}_64_high"]
                for idx,ch in enumerate(CHANNELS):
                    norm=maxabs(reference[idx])
                    stat=lambda x:maxabs(x)/norm
                    val=terms[:,idx]
                    leading_sum=val.sum(axis=0)
                    ledger.append(dict(prep=prep,case=case,link=site,channel=ch,peak_full=norm,
                        linear_cross=stat(val[0]),compensating_cross=stat(val[1]),pure_pulse_energy=stat(val[2]),
                        mixed_shell_energy=stat(val[3]),pure_shell_energy=stat(val[4]),net_self=stat(val[2:].sum(axis=0)),
                        total_leading_discrepancy=stat(leading_sum-reference[idx]),omitting_self_discrepancy=stat(val[:2].sum(axis=0)-reference[idx])))
        for site in LOCATIONS:
            original=bridge.read(PARENT/f"forecast-{prep}-128-q0.8-tangent.npz") if site!="middle" else None
            if original is not None:
                ref=original[site+"_response64"]
                calc=basis["hu"][site+"_delta64"]+(spec.match if prep=="M" else 0.)*basis["hv"][site+"_delta64"]
                for idx,ch in enumerate(CHANNELS):
                    shape.append(dict(prep=prep,link=site,channel=ch,relative=maxabs(calc[idx]-ref[idx])/maxabs(ref[idx])))
    table("finite-stress-components.csv",ledger)
    table("factorization-controls.csv",shape)


if __name__=="__main__":
    guard()
    if sys.argv[1]=="saved":
        retrospective()
        leading()
    else:
        table_held(sys.argv[1])
