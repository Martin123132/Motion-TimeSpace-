from experiment import *
from paired_clock import test_operator, finite_ray
import mpmath as mp


def controls():
    guard()
    test_operator()
    mp.mp.dps=60
    clock=np.arange(451)*.01
    base=.002
    rows=[]
    for shift in (1e-10,-1e-18):
        space=np.arange(5.9,6.61,.01)
        bank=np.stack([clock**2*base,-2*clock*base,clock**2*shift,-2*clock*shift],axis=1)
        packet={"time":clock,"outer_x":space,"outer":np.repeat(bank[:,:,None],len(space),axis=2)}
        def branch(time,width,coef):
            root=mp.sqrt(coef)
            arrive=mp.tan(mp.atan(root*time)+root*width)/root
            return arrive-time-width,(1+coef*time**2)/(1+coef*arrive**2)
        curves=[]
        nominal=mp.mpf(str(base))
        increment=mp.mpf(str(shift))
        for value in EMISSIONS:
            time=mp.mpf(str(value))
            legs=[]
            for width in (.5,1):
                quiet=branch(time,width,nominal)
                active=branch(time,width,nominal+increment)
                legs.append(np.array([float(x-y) for x,y in zip(active,quiet)]))
            curves.append((legs[0][1],legs[1][1],legs[0][0],legs[1][0]))
        exact=np.array(curves).T
        for panels in (32,64):
            observed=finite_ray(packet,"outer",panels)
            for idx,ch in enumerate(CHANNELS):
                err=max(abs(exact[idx]-observed[idx]))/max(abs(exact[idx]))
                rows.append(dict(shift=shift,panels=panels,channel=ch,peak=max(abs(exact[idx])),relative=err,passes=err<=TOL))
    assert all(r["passes"] for r in rows)
    table("analytic-clock-controls.csv",rows)


if __name__=="__main__":
    controls()
