from experiment import *
from make_forecast import weights
from dilute_test import Dilute


def combined(mesh,mode):
    spec=Dilute(mesh)
    shapes=[spec.prepare(spec.energy_seed(sign,"M"),"M")[2] for sign in (1,-1)]
    mid=(shapes[0]+shapes[1])/2
    half=(shapes[0]-shapes[1])/2
    if mode=="combined":
        left=np.stack((spec.height,spec.slope))+mid/2
        right=mid
    else:
        left,right=half/2,half
    fac=1-2*spec.ordinary*spec.inv
    dm=kernel(spec.radius,spec.radius*spec.number/np.sqrt(fac),
              spec.radius**2*(left[0]*right[0]+fac*left[1]*right[1]))
    pick=spec.picks
    scale=1e-11
    comp=2*spec.ordinary*spec.inv/fac+1j*STEP*2*spec.inv*dm/fac**2/scale
    mass=spec.ordinary+1j*STEP*dm/scale
    zero=np.zeros(len(pick),dtype=complex)
    initial=np.stack((comp[pick],zero,zero,zero,(mass*spec.inv**3)[pick],spec.number[pick],
                      zero,spec.charge[pick],(left[0]+1j*right[0]/scale)[pick],zero))
    solver=Prediction(mesh,.8)
    snapshots(mesh,initial,solver,solver.system.x,f"combined-{mesh}-{mode}.npz",np.array([scale]))


def freeze():
    lock()
    spec=Preparation(384)
    plus,minus=[spec.seed(sign,"M") for sign in (1,-1)]
    nodes=[bridge.read(HOME/node_name(384,"M",node)) for node in NODES]
    source={}
    for panels in (32,64):
        arr=np.array([v[f"outer_delta{panels}"] for v in nodes])
        for order,indices in (("high",np.arange(7)),("low",np.array([0,2,3,4,6]))):
            coeff=(weights(plus,NODES[indices])+weights(minus,NODES[indices]))/2
            source[f"dense_{panels}_{order}"]=np.tensordot(coeff,arr[indices],axes=1)
    check=[]
    for mesh in (256,384):
        sharp=[bridge.read(HOME/f"combined-{mesh}-{opt}.npz") for opt in ("combined","half")]
        for panels in (32,64):
            small=sum(v["meta"][0]*v[f"outer_delta{panels}"] for v in sharp)
            source[f"dilute_{mesh}_{panels}"]=small
            if mesh==256:
                prev=bridge.read(HOME/f"eligible-forecast-{mesh}.npz")
                old=(prev[f"M_1_outer_{panels}"]+prev[f"M_-1_outer_{panels}"])/2
                for idx,ch in enumerate(CHANNELS):
                    err=max(abs(old[idx]-small[idx]))/max(abs(old[idx]))
                    assert err<1e-7
                    check.append(dict(channel=ch,panels=panels,relative=err))
    table("even-polarization-control.csv",check)
    archive("refined-even-forecast.npz",**source)
    fine_lock(True)


def fine_lock(create=False):
    files=["eligible-frozen.json","frozen.json","fine_even.py","REFINEMENT.md","refined-even-forecast.npz",
           "even-polarization-control.csv"]
    files.extend(node_name(384,"M",n) for n in NODES)
    files.extend(f"combined-{mesh}-{opt}.npz" for mesh in (256,384) for opt in ("combined","half"))
    stamps={name:bridge.sha(HOME/name) for name in files}
    path=HOME/"fine-frozen.json"
    if create:
        with path.open("x") as stream:
            json.dump(stamps,stream,sort_keys=True,indent=2)
    else:
        assert json.loads(path.read_text())==stamps


def score():
    fine_lock()
    forecasts=bridge.read(HOME/"refined-even-forecast.npz")
    out=[]
    for model,kind in (("dense","paired"),("dilute","eligible-target")):
        old=bridge.read(HOME/"forecasts-256.npz") if model=="dense" else None
        src={(m,sign):bridge.read(HOME/f"{kind}-{m}-M-{sign}.npz") for m in (256,384) for sign in (1,-1)}
        def mean(m,panels):
            return sum(src[m,s][f"outer_{panels}"] for s in (1,-1))/2
        for idx in (0,2):
            truth=mean(384,64)[idx]
            peak=max(abs(truth))
            key="dense_64_high" if model=="dense" else "dilute_384_64"
            value=forecasts[key][idx]
            earlier=(sum(old[f"M_energy{sgn}_outer_64_high"] for sgn in ("plus","minus"))/2
                     if model=="dense" else forecasts["dilute_256_64"])[idx]
            small=forecasts["dense_32_high" if model=="dense" else "dilute_384_32"][idx]
            diff=[max(abs(v))/peak for v in (truth-value,value-earlier,mean(256,64)[idx]-truth,value-small,mean(384,32)[idx]-truth)]
            integral=(max(abs(value-forecasts["dense_64_low"][idx]))/peak if model=="dense" else 0.)
            total=sum(diff)+integral
            out.append(dict(background=model,channel=CHANNELS[idx],peak=peak,model=diff[0],pred_grid=diff[1],target_grid=diff[2],
                            pred_ray=diff[3],target_ray=diff[4],parameter_quadrature=integral,total=total,passes=total<=TOL))
    table("refined-even-budgets.csv",out)


if __name__=="__main__":
    guard()
    task=sys.argv[1]
    if task=="freeze":
        freeze()
    elif task=="score":
        score()
    elif task=="target":
        fine_lock()
        from paired_clock import evolve_pair
        model=sys.argv[2]
        spec=Preparation(384) if model=="dense" else Dilute(384)
        for sign in (1,-1):
            amp=spec.seed(sign,"M") if model=="dense" else spec.energy_seed(sign,"M")
            group="paired" if model=="dense" else "eligible-target"
            evolve_pair(spec,"M",amp,384,f"{group}-384-M-{sign}.npz")
    else:
        for opt in ("combined","half"):
            combined(int(task),opt)
