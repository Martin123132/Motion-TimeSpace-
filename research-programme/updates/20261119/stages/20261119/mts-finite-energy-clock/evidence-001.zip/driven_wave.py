from experiment import *
from source import profile, center
from scipy.integrate import cumulative_simpson
from scipy.special import betainc,beta


def predicted(mesh,eta,wave):
    spec=Launch(mesh,eta)
    field,dr=spec.height,spec.slope
    fac=1-2*spec.ordinary*spec.inv
    n=spec.number[0]
    db,dq,_,_=profile(spec.radius,wave)
    db=n*db
    dq=eta*n*dq
    delta=kernel(spec.radius,spec.radius*spec.number/np.sqrt(fac),
                 spec.radius**2*(np.sqrt(fac)*db+spec.charge*dq*spec.inv**4))
    pick=spec.picks
    comp=2*spec.ordinary*spec.inv/fac+1j*STEP*2*spec.inv*delta/fac**2
    mass=spec.ordinary+1j*STEP*delta
    zero=np.zeros(len(pick),dtype=complex)
    initial=np.stack((comp[pick],zero,zero,zero,(mass*spec.inv**3)[pick],
                      (spec.number+1j*STEP*db)[pick],zero,(spec.charge+1j*STEP*dq)[pick],
                      field[pick],zero,zero,zero,spec.pulse[0,pick],zero,spec.shell[0,pick],zero))
    limit=int(5.5*mesh)
    from ordinary_evolution import Ordinary
    metric=Ordinary(mesh,eta,"tensor",0.,5.5)
    radial=Radial(mesh,"tensor",0.,eta,5.5)
    xx=metric.x
    arr=initial[:,:limit].copy()
    def rhs(vec,measure=False):
        raw=vec[:8]
        base=raw.real
        change=raw.imag/STEP
        aa,cc=1+base[0],1+base[1]
        theta=base[2]/aa+2*base[3]/cc
        dt=change[2]/aa-base[2]*change[0]/aa**2+2*(change[3]/cc-base[3]*change[1]/cc**2)
        ar,cr,dar,dcr=metric.diff(np.stack((base[0],base[1],change[0],change[1])))
        spatial=cr/cc-ar/(2*aa)
        shift=dcr/cc-cr*change[1]/cc**2-(dar/aa-ar*change[0]/aa**2)/2
        heights=vec[8::2].real
        speeds=vec[9::2].real
        gradient=radial.diff(heights,radial.d1)
        lap=(radial.diff(xx*heights,radial.d2,True)/xx+spatial*gradient)/aa
        force=-change[0]*lap[0]/aa+shift*gradient[0]/aa+dt*speeds[0]
        if measure:
            density=(speeds[1]**2+gradient[1]**2/aa+heights[1]**2)/2
            jac=xx**2*np.sqrt(aa)*cc
            form=np.clip(xx-3,0,1)
            taper=1-betainc(6,6,form)
            derivative=-form**5*(1-form)**5/beta(6,6)
            total=lambda item:np.sum(item)/mesh
            energy=total(taper*jac*density)
            work=total(taper*jac*speeds[1]*force)
            frame=total(taper*jac*(-theta*(density-speeds[1]**2)+base[2]*gradient[1]**2/aa**2))
            flux=-total(derivative*jac*speeds[1]*gradient[1]/aa)
            products=np.array([[total(taper*jac*(heights[i]*heights[j]+gradient[i]*gradient[j]/aa+speeds[i]*speeds[j]))
                                for j in (1,2,3)] for i in (1,2,3)])
            coeff=np.linalg.solve(products[1:,1:],products[1:,0])
            fraction=float(coeff@products[1:,0]/products[0,0]) if energy>0 else 0.
            return [center(heights[1])/np.sqrt(n),energy,work,frame,flux,fraction,*coeff]
        result=np.empty_like(vec)
        result[:8]=metric.rhs(raw)
        result[8::2]=speeds
        result[9::2]=lap-heights+theta*speeds
        result[11]+=force
        return result
    count=int(np.ceil(.005*mesh/.32))
    step=.005/count
    points=[]
    for tick in range(160*count+1):
        if tick%count==0:
            points.append(rhs(arr,True))
        if tick%(40*count)==0:
            guard()
        if tick==160*count:
            break
        first=rhs(arr)
        second=rhs(arr+step*first/2)
        third=rhs(arr+step*second/2)
        fourth=rhs(arr+step*third)
        arr+=step/6*(first+2*second+2*third+fourth)
    series=np.array(points)
    assert np.isfinite(series).all() and np.max(series[:,5])<=1+1e-12
    times=np.arange(161)*.005
    inside=spec.radius<=3.
    one_percent=.01/max(abs(db[inside]/spec.number[inside]))
    archive(f"driven-{eta:g}-{wave}-{mesh}.npz",series=series,time=times,one_percent=one_percent)
    print("retarded",eta,wave,mesh,flush=True)


def score():
    previous=HOME.parent/"mts-longitudinal-response-20261119"
    stamps=json.loads((previous/"seal.json").read_bytes())["files"]
    rows=[]
    for eta in (0.,.8):
        for wave in (1,4,24):
            scores=[]
            for mesh in (160,320):
                bank=bridge.read(HOME/f"driven-{eta:g}-{wave}-{mesh}.npz")
                vals=bank["series"]
                clock=bank["time"]
                name=f"trajectory-tensor-0-q{eta:g}-k{wave}-density-m{mesh}.npz"
                assert bridge.sha(previous/name)==stamps[name]
                full=bridge.read(previous/name)["wave"][:,1]
                norm=max(abs(full))
                mismatch=max(abs(full-vals[::2,0]))/norm
                integ=cumulative_simpson(vals[:,2:5],x=clock,axis=0,initial=0.)
                residual=max(abs(vals[:,1]-integ.sum(axis=1)))/max(vals[:,1])
                row=dict(mesh=mesh,eta=eta,k=wave,full_peak=norm,field_residual=mismatch,field_pass=mismatch<=TOL,
                         induced_energy=vals[-1,1],driving_work=integ[-1,0],frame_work=integ[-1,1],flux_work=integ[-1,2],
                         work_residual=residual,work_pass=residual<=TOL,template_fraction=vals[-1,5],
                         template_pulse=vals[-1,6],template_shell=vals[-1,7],baryon_seed=float(bank["one_percent"]),
                         energy_for_one_percent=vals[-1,1]*float(bank["one_percent"])**2)
                scores.append((row,vals))
            for row,vals in scores:
                row["central_grid"]=max(abs(scores[0][1][:,0]-scores[1][1][:,0]))/max(abs(scores[1][1][:,0]))
                row["final_energy_grid"]=abs(scores[0][1][-1,1]/scores[1][1][-1,1]-1)
                rows.append(row)
    table("matter-driven-field-and-work.csv",rows)


if __name__=="__main__":
    guard()
    if sys.argv[1]=="score":
        score()
    else:
        mesh=int(sys.argv[1])
        for eta in (0.,.8):
            for wave in (1,4,24):
                predicted(mesh,eta,wave)
