from pathlib import Path
import sys
import json
import csv
import os
import importlib.util

for setting in ("OMP_NUM_THREADS","OPENBLAS_NUM_THREADS","NUMEXPR_NUM_THREADS","MKL_NUM_THREADS"):
    os.environ[setting]="1"
sys.dont_write_bytecode=True
HOME=Path(__file__).resolve().parent
PARENT=HOME.parent/"mts-pulse-backreaction-link-20261119"
sys.path.insert(0,str(PARENT))
from launch_packet import Launch, integrate, kernel, RADIUS, STEP, EMISSIONS, TOL, Radial, np, bridge, guard as parent_guard
from stress_series import Weighted, Prediction, rays, LOCATIONS
from scipy.optimize import brentq
from scipy.integrate import simpson
from numpy.polynomial import Polynomial

PARENT_SHA="9d9097164058f3457256923e3cbf8b277bf29bb7c32304ea2e6e94153318e025"
ENERGY=1.70e-11
SCALE=.00024
NODES=np.arange(-3,4)
CHANNELS=("out","echo","out_delay","echo_delay")


def guard():
    parent_guard()
    assert bridge.sha(PARENT/"seal.json")==PARENT_SHA
    if (HOME/"STOP-REQUESTED").exists():
        raise SystemExit("owner hold")


def archive(name, **data):
    assert not (HOME/name).exists(), name
    bridge.archive(HOME/name,**data)


def table(name,rows):
    with (HOME/name).open("x",newline="",encoding="utf-8") as stream:
        writer=csv.DictWriter(stream,fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


class Preparation(Launch):
    def __init__(self,mesh):
        super().__init__(mesh,.8)
        self.fquiet=1-2*self.quiet*self.inv

    def prepare(self,amp,prep):
        amount=amp*self.match if prep=="M" else 0.
        for iteration in range(16):
            ripple=amp*self.pulse+amount*self.shell
            dm=self.difference(ripple)
            h,grad=self.height+ripple[0],self.slope+ripple[1]
            fac=self.fquiet-2*dm*self.inv
            weight=self.radius*(self.number/np.sqrt(fac)+grad**2)
            def deriv(shape):
                return kernel(self.radius,weight,self.radius**2*(h*shape[0]+fac*grad*shape[1]))
            du,dv=deriv(self.pulse),deriv(self.shell)
            if prep=="N" or abs(dm[self.index])<5e-26:
                break
            amount-=dm[self.index]/dv[self.index]
        else:
            raise ArithmeticError("mass match")
        slope=-du[self.index]/dv[self.index] if prep=="M" else 0.
        change=du+slope*dv
        energy=.5*simpson(self.radius**2/np.sqrt(self.fquiet)*(self.fquiet*ripple[1]**2+ripple[0]**2),x=self.radius)
        return amount,slope,ripple,dm,change,float(energy)

    def seed(self,sign,prep):
        def difference(magnitude):
            return self.prepare(sign*magnitude,prep)[-1]-ENERGY
        return sign*brentq(difference,0.,SCALE,xtol=1e-19,rtol=2e-15)

    def launch(self,amp,prep,derivative):
        amount,slope,ripple,dm,change,energy=self.prepare(amp,prep)
        mass=self.quiet+dm
        fac=1-2*mass*self.inv
        comp=2*mass*self.inv/fac
        h=self.height+ripple[0]
        if derivative:
            mass=mass+1j*STEP*change
            comp=comp+1j*STEP*2*self.inv*change/fac**2
            h=h+1j*STEP*(self.pulse[0]+slope*self.shell[0])
        pick=self.picks
        zero=np.zeros(len(pick),dtype=comp.dtype)
        vec=np.stack((comp[pick],zero,zero,zero,(mass*self.inv**3)[pick],h[pick],zero,
                      self.number[pick],zero,self.charge[pick]))
        return vec,np.array([amp,amount,slope,energy,dm[self.index],dm[-1]])

    def first(self,label):
        combo={"hu":((1,0,0),(0,1,0)),"hv":((1,0,0),(0,0,1)),
               "uu":((0,.5,0),(0,1,0)),"uv":((0,1,0),(0,0,1)),"vv":((0,0,.5),(0,0,1))}[label]
        fields=np.stack((np.stack((self.height,self.slope)),self.pulse,self.shell))
        left,right=[np.tensordot(coeff,fields,axes=(0,0)) for coeff in combo]
        fac=1-2*self.ordinary*self.inv
        shift=kernel(self.radius,self.radius*self.number/np.sqrt(fac),
                     self.radius**2*(left[0]*right[0]+fac*left[1]*right[1]))
        comp=2*self.ordinary*self.inv/fac+1j*STEP*2*self.inv*shift/fac**2
        mass=self.ordinary+1j*STEP*shift
        pick=self.picks
        zero=np.zeros(len(pick),dtype=complex)
        return np.stack((comp[pick],zero,zero,zero,(mass*self.inv**3)[pick],self.number[pick],
                         zero,self.charge[pick],(left[0]+1j*right[0])[pick],zero))


def node_name(mesh,prep,node):
    return f"node-{mesh}-{prep}-{node}.npz"


def snapshots(mesh,field,solver,space,name,meta,save_strip=False):
    assert not (HOME/name).exists()
    masks={key:(space>=pos-.09)&(space<=pos+.59) for key,pos in LOCATIONS.items()}
    strips={key:[] for key in masks}
    count=int(np.ceil(.01*mesh/.42))
    dt=.01/count
    for tick in range(450*count+1):
        if tick%count==0:
            for site,mask in masks.items():
                comp=field[0,mask]
                rad=np.sqrt(1+comp)
                light=comp/(1+rad)
                curve=field[2,mask]/rad
                strips[site].append(np.stack((light.real,curve.real,light.imag/STEP,curve.imag/STEP)))
        if tick%(50*count)==0:
            guard()
        if tick==450*count:
            break
        first=solver.rhs(field)
        second=solver.rhs(field+.5*dt*first)
        third=solver.rhs(field+.5*dt*second)
        fourth=solver.rhs(field+dt*third)
        field+=dt/6*(first+2*second+2*third+fourth)
    assert np.isfinite(field).all()
    dest=dict(meta=meta,emissions=EMISSIONS)
    for site,mask in masks.items():
        bank=np.asarray(strips[site])
        data=dict(time=np.arange(451)*.01)
        data[site]=bank
        data[site+"_x"]=space[mask]
        for panels in (32,64):
            base,delta=rays(data,site,panels)
            dest[f"{site}_base{panels}"]=base
            dest[f"{site}_delta{panels}"]=delta
        if save_strip:
            dest[site+"_geometry"]=bank[:,:2].copy()
            dest[site+"_x"]=space[mask]
    archive(name,**dest)
    print(name,flush=True)


def lock(create=False):
    inputs=["PROTOCOL.md","experiment.py","make_forecast.py","forecasts-128.npz","forecasts-256.npz","energy-preparations.csv"]
    inputs += [node_name(mesh,prep,node) for mesh in (128,256) for prep in ("N","M") for node in NODES]
    stamps={name:bridge.sha(HOME/name) for name in inputs}
    dest=HOME/"frozen.json"
    if create:
        with dest.open("x") as stream:
            json.dump(stamps,stream,sort_keys=True,indent=2)
    else:
        assert json.loads(dest.read_text())==stamps


def run(mode,mesh,prep,arg):
    guard()
    spec=Preparation(mesh)
    if mode=="node":
        node=int(arg)
        assert node in NODES
        field,meta=spec.launch(SCALE*node/3,prep,True)
        solver=Weighted(mesh,1.)
        snapshots(mesh,field[[0,1,2,3,4,7,8,9,5,6]],solver,solver.system.x,node_name(mesh,prep,node),meta)
    elif mode=="basis":
        solver=Prediction(mesh,.8)
        snapshots(mesh,spec.first(arg),solver,solver.system.x,f"basis-{mesh}-{arg}.npz",np.array([mesh]))
    elif mode=="test":
        lock()
        sign=int(arg)
        amp=spec.seed(sign,prep) if sign else 0.
        name=f"held-{mesh}-{prep}-{sign}.npz"
        if amp:
            field,check=spec.data("full",prep,amp)
        else:
            pick=spec.picks
            mass=spec.quiet
            pot=2*mass*spec.inv
            zz=np.zeros(len(pick))
            field=np.stack(((pot/(1-pot))[pick],zz,zz,zz,(mass*spec.inv**3)[pick],spec.height[pick],zz,
                            spec.number[pick],zz,spec.charge[pick]))
        solver=Radial(mesh,"tensor",0.,.8,RADIUS)
        snapshots(mesh,field,solver,solver.x,name,np.array([amp]),True)
    else:
        raise ValueError(mode)


if __name__=="__main__":
    for arg in sys.argv[4:]:
        run(sys.argv[1],int(sys.argv[2]),sys.argv[3],arg)
