from experiment import *
from scipy.interpolate import PPoly
from scipy.special import beta
from scipy.constants import c,G,electron_volt,parsec
from source import background


def spline_bounds(spline,lo,hi):
    poly=PPoly.from_spline(spline)
    knots=poly.x
    keep=(knots[:-1]<hi)&(knots[1:]>lo)&(np.diff(knots)>0)
    assert keep.any()
    width=np.diff(knots)[keep]
    return float(np.max(sum(abs(row[keep])*width**degree for degree,row in enumerate(poly.c[::-1]))))


def test():
    guard()
    spec=Preparation(256)
    _,field=background("massive")
    scale=json.loads((HOME.parent/"mts-two-radius-pressure-clock-20261119/physical-clock-scale.json").read_text())
    length=scale["length_pc"]*parsec
    multiplier=c**4/(4*np.pi*G*length**2)/(1e9*electron_volt*1e6)
    at=np.searchsorted(spec.radius,6.)
    amp_upper=1.000001*np.sqrt(2*scale["normalization_GeV_cm3"]/multiplier)/abs(spec.height[at])
    height,grad=[amp_upper*1.000001*spline_bounds(spl,0.,3.) for spl in (field,field.derivative())]
    n=float(spec.number[0])
    electric=.8*n
    rho=n+(height**2+grad**2+electric**2)/2
    fac_min=1-2*3**2*rho/3
    assert 0<fac_min<1
    lower_height=np.sin(1.98)/1.98-np.sin(2.7)/2.7
    assert lower_height>.30
    eps_max=np.sqrt(2*ENERGY/(.30**2*n*((.22**3-.18**3)/3)))
    shell_min=.96**8
    upper_u=1/(9*2.)+1/(15*2.)
    shell_max=(np.sqrt(2*ENERGY/(n*((2.2**3-2.**3)/3)))+eps_max*upper_u)/shell_min
    window_slope=.25**8/(1.5*beta(9,9))
    vgrad=np.sqrt(n)*(eps_max*(24+2*window_slope)+32*shell_max/1.25)
    exponent=4.5*((grad+vgrad)**2+2*n/np.sqrt(fac_min))
    positive=np.exp(-exponent)*np.sqrt(fac_min)*ENERGY
    quiet_raw=(3**3/6)*(height**2+grad**2)
    negative=2*np.sqrt(ENERGY*quiet_raw)
    ratio=(positive-negative)/ENERGY
    assert ratio>.5
    table("nonlinear-energy-exclusion.csv",[dict(requested=ENERGY,normalization_at_6=scale["normalization_GeV_cm3"],
        amplitude_scale_upper=amp_upper,height_upper=height,derivative_upper=grad,F_quiet_lower=fac_min,
        seed_uniform_upper=eps_max,shell_uniform_upper=shell_max,perturbation_gradient_upper=vgrad,
        exponent_upper=exponent,positive_mass_lower=positive,cross_mass_magnitude_upper=negative,
        net_mass_lower=positive-negative,net_mass_lower_over_energy=ratio,
        scope="all real combinations of these two profiles on a regular untrapped launch at this energy, conditional dilute quiet background")])
    print("mass change / requested energy >",ratio)


if __name__=="__main__":
    test()
