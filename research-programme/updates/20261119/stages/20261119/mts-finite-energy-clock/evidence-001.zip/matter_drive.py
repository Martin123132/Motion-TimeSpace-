from experiment import *
from source import background

def run():
    guard()
    n,field=background("massive")
    predicted=-np.sqrt(n)*(field(0.)+4*field(0.,2))/12
    prior=HOME.parent/"mts-longitudinal-response-20261119"
    stamps=json.loads((prior/"seal.json").read_text())["files"]
    rows=[]
    for eta in (0.,.8):
        for wave in (1,4,24):
            for mesh in (160,320):
                name=f"trajectory-tensor-0-q{eta:g}-k{wave}-density-m{mesh}.npz"
                assert bridge.sha(prior/name)==stamps[name]
                data=bridge.read(prior/name)
                for step in (1,2):
                    indices=step*np.arange(2,6)
                    time=data["time"][indices]
                    square=time**2
                    weights=[np.prod(-np.delete(square,j)/(u-np.delete(square,j))) for j,u in enumerate(square)]
                    value=np.array(weights)@((data["wave"][indices,1]-data["wave"][0,1])/time**4)
                    err=abs(value/predicted-1)
                    rows.append(dict(eta=eta,k=wave,mesh=mesh,start=time[0],end=time[-1],coefficient=predicted,
                                     observed=value,relative=err,passes=err<=TOL,source=name))
    table("material-induced-quartic.csv",rows)

if __name__=="__main__":
    run()
