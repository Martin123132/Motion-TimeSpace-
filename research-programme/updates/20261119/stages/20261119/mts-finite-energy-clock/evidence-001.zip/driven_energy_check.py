from experiment import *
from source import profile,center
from scipy.special import betainc


def freeze(create=False):
    names=["RETARDED-TEST.md","MATTER-DRIVE.md","driven_wave.py","driven_energy_check.py","matter-driven-field-and-work.csv"]
    names.extend(f"driven-{eta:g}-{wave}-{mesh}.npz" for eta in (0.,.8) for wave in (1,4,24) for mesh in (160,320))
    stamps={name:bridge.sha(HOME/name) for name in names}
    dest=HOME/"driven-freeze.json"
    if create:
        with dest.open("x") as stream:
            json.dump(stamps,stream,sort_keys=True,indent=2)
    else:
        assert stamps==json.loads(dest.read_text())


def test(eta,wave,mesh):
    guard()
    spec=Launch(mesh,eta)
    system=Radial(mesh,"tensor",0.,eta,5.5)
    db,dq,_,_=profile(spec.radius,wave)
    db=spec.number[0]*db
    dq=eta*spec.number[0]*dq
    fac=1-2*spec.quiet*spec.inv
    dm=kernel(spec.radius,spec.radius*(spec.number/np.sqrt(fac)+spec.slope**2),
              spec.radius**2*(np.sqrt(fac)*db+spec.charge*dq*spec.inv**4))
    mass=spec.quiet+1j*STEP*dm
    comp=2*spec.quiet*spec.inv/fac+1j*STEP*2*dm*spec.inv/fac**2
    pick=spec.picks[:len(system.x)]
    zero=np.zeros(len(pick),dtype=complex)
    field=np.stack((comp[pick],zero,zero,zero,(mass*spec.inv**3)[pick],spec.height[pick],zero,
                    (spec.number+1j*STEP*db)[pick],zero,(spec.charge+1j*STEP*dq)[pick]))
    xx=system.x
    weight=1-betainc(6,6,np.clip(xx-3,0,1))
    count=int(np.ceil(.005*mesh/.32))
    dt=.005/count
    rows=[]
    for tick in range(160*count+1):
        if tick%count==0:
            aa,cc=1+field[0].real,1+field[1].real
            induced,speed=field[[5,6]].imag/STEP
            grad=system.diff(induced,system.d1)
            energy=np.sum(weight*xx**2*np.sqrt(aa)*cc*(induced**2+speed**2+grad**2/aa))/(2*mesh)
            rows.append((center(induced)/np.sqrt(spec.number[0]),energy))
        if tick%(40*count)==0:
            guard()
        if tick==160*count:
            break
        first=system.rhs(field)
        second=system.rhs(field+dt*first/2)
        third=system.rhs(field+dt*second/2)
        fourth=system.rhs(field+dt*third)
        field+=dt/6*(first+2*second+2*third+fourth)
    full=np.array(rows)
    pred=bridge.read(HOME/f"driven-{eta:g}-{wave}-{mesh}.npz")["series"]
    field_error=max(abs(full[:,0]-pred[:,0]))/max(abs(full[:,0]))
    energy_error=max(abs(full[:,1]-pred[:,1]))/max(abs(full[:,1]))
    archive(f"driven-full-{eta:g}-{wave}-{mesh}.npz",full=full,freeze=np.bytes_(bridge.sha(HOME/"driven-freeze.json")))
    return dict(eta=eta,k=wave,mesh=mesh,field_error=field_error,energy_error=energy_error,
                full_energy=full[-1,1],predicted_energy=pred[-1,1],field_pass=field_error<=TOL,energy_pass=energy_error<=TOL)


if __name__=="__main__":
    if sys.argv[1]=="freeze":
        freeze(True)
    else:
        freeze()
        mesh=int(sys.argv[1])
        table(f"material-driven-full-{mesh}.csv",[test(eta,wave,mesh) for eta in (0.,.8) for wave in (1,4,24)])
