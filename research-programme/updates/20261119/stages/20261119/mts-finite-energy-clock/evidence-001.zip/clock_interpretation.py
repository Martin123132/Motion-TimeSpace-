from experiment import *
from dilute_test import Dilute, ELIGIBLE, maxabs, portions
from ray_transfer import Strip, march
from scipy.integrate import solve_ivp
from scipy.interpolate import make_interp_spline
from scipy.constants import c, parsec


def exterior_forecast(source):
    xx=np.arange(5.8,6.71,.01)
    times=np.arange(451)*.01
    charge=source.charge[-1]
    m=source.ordinary[-1]+charge**2/(2*RADIUS)+1j*1e-9
    en=np.sqrt(1-2*m/xx+charge**2/xx**2)
    def rhs(time,data):
        pos,speed,jac,vel=data.reshape(4,-1)
        return np.stack((speed,-m/pos**2+charge**2/pos**3,vel,(2*m/pos**3-3*charge**2/pos**4)*jac)).ravel()
    sol=solve_ivp(rhs,(0.,4.5),np.stack((xx,0*xx,1+0*xx,0*xx)).astype(complex).ravel(),t_eval=times,method="DOP853",
                  atol=2e-21,rtol=2e-13,max_step=.04)
    assert sol.success
    _,_,jac,vel=sol.y.reshape(4,len(xx),len(times)).transpose(0,2,1)
    length=jac/en
    speed=vel/en
    strip=Strip(dict(time=times,space=xx,bank=np.stack((length.real-1,speed.real,length.imag/1e-9),axis=1)),1)
    emit=np.arange(341)*.01
    def leg(start,direction):
        def prop(offset,state):
            time=start+offset+state[0]
            pos=np.full_like(time,(6 if direction==1 else 6.5)+direction*offset)
            rate=strip.get(1,time,pos)
            return np.stack((strip.get(0,time,pos),strip.get(2,time,pos)+rate*state[1],rate))
        delay,deriv,log=march(prop,3,.5,64,len(start))
        return delay,deriv,np.exp(log)
    first,df,jac1=leg(emit,1)
    _,db,jac2=leg(emit+.5+first,-1)
    ds=(df,db+jac2*df)
    freq=[-make_interp_spline(emit,val,k=5).derivative()(emit)/gain**2 for val,gain in zip(ds,(jac1,jac2*jac1))]
    return np.stack((*freq,*ds))[:,::2]


def run():
    guard()
    geometry=json.loads((HOME.parent/"mts-two-radius-pressure-clock-20261119/physical-clock-scale.json").read_text())
    seconds=geometry["length_pc"]*parsec/c
    rows=[]
    parity_table=[]
    unit=exterior_forecast(Preparation(256))
    early=EMISSIONS<=1.7
    late=EMISSIONS>=2.8
    for model,spec in (("dense",Preparation(256)),("dilute",Dilute(256))):
        for prep in ("M","N"):
            destinations={}
            delta_mass={}
            for sign in (-1,1):
                amp=spec.seed(sign,prep) if model=="dense" else spec.energy_seed(sign,prep)
                delta_mass[sign]=spec.prepare(amp,prep)[3][-1]
                name=(f"paired-256-{prep}-{sign}.npz" if model=="dense" else f"eligible-target-256-{prep}-{sign}.npz")
                destinations[sign]=bridge.read(HOME/name)
            for site in LOCATIONS:
                views=portions(*[destinations[sign][site+"_64"] for sign in (1,-1)])
                for idx,ch in enumerate(CHANNELS):
                    odd,even=views["odd"][idx],views["even"][idx]
                    parity_table.append(dict(background=model,prep=prep,link=site,channel=ch,odd_peak=maxabs(odd),
                                             even_peak=maxabs(even),even_to_odd=maxabs(even)/maxabs(odd),
                                             plus_peak=maxabs(views["plus"][idx]),minus_peak=maxabs(views["minus"][idx])))
                    if site!="outer":
                        continue
                    for sign,tag in ((1,"plus"),(-1,"minus")):
                        wave=views[tag][idx]
                        predicted=unit[idx]*delta_mass[sign]
                        early_peak=maxabs(wave[early])
                        late_peak=maxabs(wave[late])
                        early_error=maxabs(wave[early]-predicted[early])
                        residual=maxabs((wave-predicted)[late])
                        max_index=np.argmax(abs(wave))
                        rows.append(dict(background=model,prep=prep,sign=sign,channel=ch,
                                         peak_emit=EMISSIONS[max_index],signed_full_peak=wave[max_index],
                                         peak_delay_seconds=wave[max_index]*seconds if "delay" in ch else "",
                                         early_peak=early_peak,late_peak=late_peak,static_mass_early_peak=maxabs(predicted[early]),
                                         early_mismatch_ratio=early_error/maxabs(predicted[early]) if prep=="N" else "",
                                         static_mass_late_peak=maxabs(predicted[late]),late_residual_over_late_signal=residual/late_peak))
    table("mass-only-null.csv",rows)
    table("energy-parity-readout.csv",parity_table)


if __name__=="__main__":
    run()
