from experiment import *
compare_spec=importlib.util.spec_from_file_location("finite_clock_scores",HOME/"compare.py")
scores=importlib.util.module_from_spec(compare_spec)
compare_spec.loader.exec_module(scores)
portions,maxabs=scores.portions,scores.maxabs
from paired_clock import evolve_pair
from scipy.constants import G, c, electron_volt, parsec

ELIGIBLE=2.50e-16


class Dilute(Preparation):
    def __init__(self,mesh):
        super().__init__(mesh)
        quiet=self.height.copy()
        grad=self.slope.copy()
        scale=json.loads((HOME.parent/"mts-two-radius-pressure-clock-20261119/physical-clock-scale.json").read_text())
        self.unit=c**4*(scale["length_pc"]*parsec)/G
        factor=self.unit/(4*np.pi*(scale["length_pc"]*parsec)**3)/(1e9*electron_volt*1e6)
        index=np.searchsorted(self.radius,6.)
        def measured(s):
            self.height=s*quiet
            self.slope=s*grad
            self.quiet=self.mass(True)
            self.fquiet=1-2*self.quiet*self.inv
            return factor*(self.height[index]**2+self.fquiet[index]*self.slope[index]**2)/2
        self.mult=brentq(lambda s:measured(s)-scale["normalization_GeV_cm3"],.0001,.001,xtol=1e-17)
        self.normalization=measured(self.mult)
        self.shell_m=self.tangent(self.shell,False)[self.index]
        self.match=-self.tangent(self.pulse,False)[self.index]/self.shell_m

    def prepare(self,amp,prep):
        amount=amp*self.match if prep=="M" else 0.
        for iteration in range(24):
            ripple=amp*self.pulse+amount*self.shell
            delta=self.difference(ripple)
            fac=self.fquiet-2*delta*self.inv
            grad=self.slope+ripple[1]
            field=self.height+ripple[0]
            weight=self.radius*(self.number/np.sqrt(fac)+grad**2)
            def dm(shape):
                return kernel(self.radius,weight,self.radius**2*(field*shape[0]+fac*grad*shape[1]))
            du,dv=dm(self.pulse),dm(self.shell)
            if prep=="N" or abs(delta[self.index])<1e-30:
                break
            amount-=delta[self.index]/dv[self.index]
        else:
            raise ValueError("No local branch near prescribed energy")
        slope=0 if prep=="N" else -du[self.index]/dv[self.index]
        energy=.5*simpson(self.radius**2/np.sqrt(self.fquiet)*(self.fquiet*ripple[1]**2+ripple[0]**2),x=self.radius)
        return amount,slope,ripple,delta,du+slope*dv,float(energy)

    def energy_seed(self,sign,prep):
        return sign*brentq(lambda val:self.prepare(sign*val,prep)[-1]-ELIGIBLE,0.,1e-6,xtol=1e-21,rtol=2e-15)


def freeze():
    lock()
    rows=[]
    for mesh in (128,256):
        spec=Dilute(mesh)
        basis=[bridge.read(HOME/f"basis-{mesh}-{name}.npz") for name in ("hu","hv","uu","uv","vv")]
        curves={}
        for prep in ("M","N"):
            for sign in (-1,1):
                amp=spec.energy_seed(sign,prep)
                amount,_,_,delta,_,energy=spec.prepare(amp,prep)
                assert abs(energy/ELIGIBLE-1)<1e-13
                weights=np.array([spec.mult*amp,spec.mult*amount,amp**2,amp*amount,amount**2])
                rows.append(dict(mesh=mesh,prep=prep,sign=sign,seed=amp,shell=amount,
                                 quiet_scale=spec.mult,density_at_6=spec.normalization,energy=energy,joules=energy*spec.unit,
                                 enclosed_change_at_3=delta[spec.index],enclosed_change_at_12=delta[-1]))
                for site in LOCATIONS:
                    for panels in (32,64):
                        terms=[w*item[f"{site}_delta{panels}"] for w,item in zip(weights,basis)]
                        curves[f"{prep}_{sign}_{site}_{panels}"]=sum(terms)
                        if panels==64:
                            curves[f"{prep}_{sign}_{site}_self"]=sum(terms[2:])
        archive(f"eligible-forecast-{mesh}.npz",**curves)
    table("eligible-preparations.csv",rows)
    eligible_lock(True)


def eligible_lock(create=False):
    names=["SOURCE-ENERGY-LIMIT.md","frozen.json","dilute_test.py","paired_clock.py","eligible-preparations.csv",
           "source-ellipse.csv","nonlinear-energy-exclusion.csv"]
    for mesh in (128,256):
        names.append(f"eligible-forecast-{mesh}.npz")
        names.extend(f"basis-{mesh}-{key}.npz" for key in ("hu","hv","uu","uv","vv"))
    stamps={name:bridge.sha(HOME/name) for name in names}
    dest=HOME/"eligible-frozen.json"
    if create:
        with dest.open("x") as stream:
            json.dump(stamps,stream,indent=2,sort_keys=True)
    else:
        assert stamps==json.loads(dest.read_text())


def score():
    eligible_lock()
    rows=[]
    for prep in ("M","N"):
        pred={mesh:bridge.read(HOME/f"eligible-forecast-{mesh}.npz") for mesh in (128,256)}
        truth={(mesh,sign):bridge.read(HOME/f"eligible-target-{mesh}-{prep}-{sign}.npz") for mesh in (128,256) for sign in (1,-1)}
        for site in LOCATIONS:
            def compare(group,mesh,panels):
                if group=="forecast":
                    return portions(*[pred[mesh][f"{prep}_{sign}_{site}_{panels}"] for sign in (1,-1)])
                return portions(*[truth[mesh,sign][f"{site}_{panels}"] for sign in (1,-1)])
            fine=compare("forecast",256,64)
            target=compare("solver",256,64)
            coarse=compare("forecast",128,64)
            coarse_t=compare("solver",128,64)
            ray=compare("forecast",256,32)
            ray_t=compare("solver",256,32)
            for parity in fine:
                for idx,channel in enumerate(CHANNELS):
                    expected,measured=fine[parity][idx],target[parity][idx]
                    peak=np.argmax(abs(measured))
                    norm=abs(measured[peak])
                    deltas=(expected-measured,expected-coarse[parity][idx],measured-coarse_t[parity][idx],
                            expected-ray[parity][idx],measured-ray_t[parity][idx])
                    errors=[maxabs(x)/norm for x in deltas]
                    rows.append(dict(prep=prep,link=site,parity=parity,channel=channel,peak_emit=EMISSIONS[peak],
                                     true_peak=measured[peak],forecast_at_peak=expected[peak],model=errors[0],pred_grid=errors[1],
                                     target_grid=errors[2],pred_ray=errors[3],target_ray=errors[4],
                                     total=sum(errors),passes=sum(errors)<=TOL))
    table("eligible-clock-budgets.csv",rows)


if __name__=="__main__":
    guard()
    if sys.argv[1]=="freeze":
        freeze()
    elif sys.argv[1]=="score":
        score()
    else:
        eligible_lock()
        mesh=int(sys.argv[1])
        spec=Dilute(mesh)
        prep=sys.argv[2]
        for raw in sys.argv[3:]:
            sign=int(raw)
            evolve_pair(spec,prep,spec.energy_seed(sign,prep),mesh,f"eligible-target-{mesh}-{prep}-{sign}.npz")
