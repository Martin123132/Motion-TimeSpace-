from experiment import *
from ray_transfer import Strip, march


def prod(left,right):
    return (left.real*right.real+left.imag*right.imag)+1j*(left.imag*right.real+left.real*right.imag)


def inv(value):
    return value.conj()/((value.real-value.imag)*(value.real+value.imag))


def sqrtp(value):
    mean=(np.sqrt(value.real+value.imag)+np.sqrt(value.real-value.imag))/2
    return mean+1j*(value.imag/(2*mean))


def pstate(spec,prep,amp):
    amount,_,ripple,dm,_,_=spec.prepare(amp,prep)
    fac=spec.fquiet
    dcomp=2*spec.inv*dm/(fac*(fac-2*dm*spec.inv))
    mixed=.5+.5j
    pick=spec.picks
    zero=np.zeros(len(pick),dtype=complex)
    return np.stack(((2*spec.quiet*spec.inv/fac+mixed*dcomp)[pick],zero,zero,zero,
                     ((spec.quiet+mixed*dm)*spec.inv**3)[pick],(spec.height+mixed*ripple[0])[pick],
                     zero,spec.number[pick],zero,spec.charge[pick]))


class PairSystem:
    def __init__(self,mesh):
        self.radial=Radial(mesh,"tensor",0.,.8,RADIUS)
        self.space=self.radial.x

    def rhs(self,arr):
        radial,angular,krad,kang,mass3,field,normal,number,impulse,charge=arr
        space=self.space
        aa,cc=1+radial,1+angular
        ia,ic=inv(aa),inv(cc)
        length,root=sqrtp(aa),sqrtp(cc)
        il,ir=inv(length),inv(root)
        radius2=cc*space**2
        dr,dc,dh=self.radial.diff(arr[[0,1,5]],self.radial.d1)
        proper=prod(number,prod(ic,il))
        speed=prod(impulse,il)
        gamma=sqrtp(1+prod(speed,speed))
        ig=inv(gamma)
        grad=prod(dh,il)
        electric=prod(charge,ic)/space**2
        electrom=prod(electric,electric)
        timekin=prod(normal,normal)
        spatial=prod(grad,grad)
        pot=prod(field,field)
        pressure=(timekin+spatial-pot-electrom)/2+prod(proper,prod(prod(speed,speed),ig))
        focus=timekin-spatial+2*electrom+prod(proper,ig)
        current=prod(proper,speed)-prod(normal,grad)
        flow=prod(radius2,prod(proper,prod(speed,ig)))
        tangent=prod(kang,ic)
        rx=root+space*prod(dc,ir)/2
        radial_k=prod(krad,ia)
        encl=prod(mass3,prod(ic,ir))
        motion=-space*prod(root,tangent)
        lap=prod(ia,self.radial.diff(space*field,self.radial.d2,True)/space+prod(prod(dc,ic)-prod(dr,ia)/2,dh))
        out=np.empty_like(arr)
        out[0],out[1]=-2*krad,-2*kang
        out[2]=prod(aa,focus-2*encl)-prod(krad,radial_k)
        out[3]=prod(cc,encl+pressure-prod(tangent,tangent))
        out[4]=-prod(cc,prod(pressure,motion)+prod(current,prod(rx,il)))/space
        out[5]=normal
        out[6]=lap-field+prod(radial_k+2*tangent,normal)
        out[7]=-self.radial.diff(flow,self.radial.d1,True)/space**2
        mom=prod(impulse,ia)
        out[8]=-prod(prod(speed,prod(il,ig)),self.radial.diff(impulse,self.radial.d1,True))+prod(dr,prod(prod(mom,mom),ig))/2+.8*prod(length,electric)
        out[9]=-.8*flow
        return out


def finite_ray(bank,site,panels):
    strip=Strip(dict(time=bank["time"],space=bank[site+"_x"],bank=bank[site]),1)
    low=LOCATIONS[site]
    def leg(emission,direction,t_initial):
        def rhs(offset,vec):
            time=emission+offset+vec[0]
            diff=t_initial+vec[2]
            xx=np.full_like(time,low+(.5 if direction<0 else 0.)+direction*offset)
            source=[strip.get(channel,time,xx) for channel in range(4)]
            midday=time+diff/2
            mod=-strip.get(1,midday,xx)-strip.get(3,midday,xx)
            acc=strip.surfaces[1].ev(midday,xx,dx=1)+strip.surfaces[3].ev(midday,xx,dx=1)
            return np.stack((source[0],source[1],source[2]+diff*mod,source[3]+diff*acc))
        return march(rhs,4,.5,panels,len(emission))
    first=leg(EMISSIONS,1,np.zeros_like(EMISSIONS))
    back=leg(EMISSIONS+.5+first[0],-1,first[2])
    return np.stack((np.exp(first[1])*np.expm1(first[3]),
                     np.exp(first[1]+back[1])*np.expm1(first[3]+back[3]),first[2],first[2]+back[2]))


def test_operator():
    spec=Preparation(64)
    solver=PairSystem(64)
    field=pstate(spec,"M",.00015)
    def ordinary(packed,sign):
        return solver.radial.rhs(packed.real+sign*packed.imag)
    for iteration in range(3):
        computed=solver.rhs(field)
        for sign in (1.,-1.):
            expected=ordinary(field,sign)
            for actual,reference in zip(computed.real+sign*computed.imag,expected):
                difference=max(abs(actual-reference))
                assert difference<=2e-11*max(abs(reference))+2e-13, (iteration,difference,max(abs(reference)))
        field+=.0001*computed


def recover(mesh,prep,sign):
    guard()
    lock()
    spec=Preparation(mesh)
    amp=spec.seed(sign,prep)
    evolve_pair(spec,prep,amp,mesh,f"paired-{mesh}-{prep}-{sign}.npz")


def evolve_pair(spec,prep,amp,mesh,destination):
    guard()
    assert not (HOME/destination).exists()
    system=PairSystem(mesh)
    field=pstate(spec,prep,amp)
    masks={name:(system.space>=x-.09)&(system.space<=x+.59) for name,x in LOCATIONS.items()}
    series={name:[] for name in masks}
    count=int(np.ceil(.01*mesh/.42))
    dt=.01/count
    for tick in range(450*count+1):
        if tick%count==0:
            for name,mask in masks.items():
                comp=field[0,mask]
                length=sqrtp(1+comp)
                curve=prod(field[2,mask],inv(length))
                baseline=comp.real-comp.imag
                series[name].append(np.stack((baseline/(1+np.sqrt(1+baseline)),curve.real-curve.imag,
                                              2*length.imag,2*curve.imag)))
        if tick%(50*count)==0:
            guard()
        if tick==450*count:
            break
        first=system.rhs(field)
        second=system.rhs(field+.5*dt*first)
        third=system.rhs(field+.5*dt*second)
        fourth=system.rhs(field+dt*third)
        field+=dt/6*(first+2*second+2*third+fourth)
    assert np.isfinite(field).all()
    output=dict(amp=amp)
    for name,mask in masks.items():
        bank={name:np.array(series[name]),name+"_x":system.space[mask],"time":np.arange(451)*.01}
        for panels in (32,64):
            output[f"{name}_{panels}"]=finite_ray(bank,name,panels)
    archive(destination,**output)
    print(destination,flush=True)


if __name__=="__main__":
    if sys.argv[1]=="algebra":
        test_operator()
    else:
        for sign in sys.argv[3:]:
            recover(int(sys.argv[1]),sys.argv[2],int(sign))
