from gas_common import HOME,OLD,np,read,table,guard,TOL
from resolved_response import branch,SPEED,OUTER
from loaded import CASES


def get(rows,**select):
    found=[row for row in rows if all(row[key]==str(value) for key,value in select.items())]
    assert len(found)==1,(select,len(found))
    return found[0]


def f(row,key):
    return float(row[key])


def small(case):
    prefix=case+"-main-256-24"
    frozen=read(prefix+"-frozen.csv")
    first=read(prefix+"-energy-frozen.csv")
    tests=read(prefix+"-small-results.csv")
    with np.load(HOME/(prefix+"-susceptibility.npz")) as pack:
        matrix=pack["matrix"]
        assert np.all(np.linalg.eigvalsh(matrix)<0) and np.max(abs(matrix-matrix.T))<1e-8
    out=[]
    def compare(mode,model,key,predicted):
        sets=[get(tests,mode=mode,model=model,fraction=amount) for amount in (-1/64,1/64,-1/128,1/128)]
        wide=(f(sets[1],key)-f(sets[0],key))*32
        narrow=(f(sets[3],key)-f(sets[2],key))*64
        ext=(4*narrow-wide)/3
        identity=abs(predicted)<1e-10
        error=abs(ext-predicted)/(1 if identity else abs(predicted))
        out.append(dict(case=case,mode=mode,model=model,quantity=key,analytic=predicted,wide=wide,narrow=narrow,
                        extrapolated=ext,error=error,metric="absolute" if identity else "relative",meets_20ppm=error<TOL))
    for mode in ("fixed","matched"):
        for model in ("mts","nfw"):
            terms=[row for row in frozen if row["model"]==model and row["part"]==mode]
            assert len(terms)==2
            for key in ("outer","slope","Kz","annulus_billion","T_excess","T_total","spatial_excess","spatial_total"):
                predicted=sum(f(row,key) for row in terms)
                compare(mode,model,key,predicted)
        compare(mode,"mts","energy_per_original_mass",sum(f(row,mode+"_first") for row in first))
    compare("fixed","mts","current_gas_pair_per_original_mass",matrix.sum())
    return out


def main():
    guard(True)
    checks=[];scores=[];resolution=[];forecasts=[];changes=[];vertical=[]
    solar=[row for row in branch.read("vertical.csv") if row["case"]=="main" and row["model"]=="mts" and row["use"]=="comparison"]
    assert len(solar)==2
    for case in CASES:
        checks.extend(small(case))
        end={}
        for seed,count,order in (("main",256,24),("main",384,32),("above",384,32)):
            tag=f"{case}-{seed}-{count}-{order}-full"
            results=read(tag+"-results.csv")
            profiles=read(tag+"-curves.csv")
            trace=read(tag+"-stationarity.csv")
            assert max(abs(f(row,"norm_residual")) for row in trace)<2e-12
            assert max(abs(f(row,"stationarity")) for row in trace)<1e-9
            matched=get(results,mode="matched",model="mts",fraction=1.)
            end[(seed,count)]=matched
            for model in ("mts","nfw"):
                base=get(results,mode="fixed",model=model,fraction=0.)
                direct=get(results,mode="direct-only",model=model,fraction=1.)
                fixed=get(results,mode="fixed",model=model,fraction=1.)
                last=get(results,mode="matched",model=model,fraction=1.)
                assert abs(f(last,"outer")-SPEED)<1e-8 and abs(f(base,"outer")-SPEED)<1e-8
                for key in ("outer","slope","Kz","annulus_billion","T_excess","T_total","spatial_excess","spatial_total"):
                    bare,now,loaded,final=[f(row,key) for row in (base,direct,fixed,last)]
                    changes.append(dict(case=case,seed=seed,count=count,model=model,quantity=key,stars_only=bare,direct_only=now,
                                        gas_fixed=loaded,gas_matched=final,direct_change=now-bare,dynamical_change=loaded-now,
                                        recalibration_change=final-loaded))
                    if model=="nfw":
                        assert abs(loaded-now)<1e-11
                for mode in ("fixed","matched"):
                    target=get(results,mode=mode,model=model,fraction=1.)
                    for obs in solar:
                        value=f(target,"Kz")
                        vertical.append(dict(case=case,seed=seed,count=count,mode=mode,model=model,tracer=obs["tracer"],predicted=value,
                                             obs=obs["Kz_observed_at_R0"],sigma=obs["sigma"],
                                             signed_widths=(value-f(obs,"Kz_observed_at_R0"))/f(obs,"sigma")))
                    for sample,name in (("cepheid","cepheid-table1.csv"),("giant","eilers-table1.csv")):
                        actual=branch.read(name)
                        pred=[row for row in profiles if row["fraction"]=="1.0" and row["mode"]==mode and row["model"]==model and row["sample"]==sample]
                        assert np.array_equal([f(row,"R") for row in pred],[f(row,"R_kpc") for row in actual])
                        diff=np.array([f(row,"speed")-f(obs,"V_kms") for row,obs in zip(pred,actual) if sample!="cepheid" or f(row,"R")!=OUTER])
                        assert len(diff)==(11 if sample=="cepheid" else 38)
                        scores.append(dict(case=case,seed=seed,count=count,mode=mode,model=model,sample=sample,n=len(diff),bias=np.mean(diff),
                                           rmse=np.sqrt(np.mean(diff**2)),max_abs=np.max(abs(diff))))
            if seed=="main" and count==384:
                halo=get(results,mode="matched",model="nfw",fraction=1.)
                for name,excess in (("T_total","T_excess"),("spatial_total","spatial_excess")):
                    separation=f(matched,name)-f(halo,name)
                    assert abs(separation-f(matched,excess))<1e-9
                    forecasts.append(dict(case=case,measure=name,wave=f(matched,name),halo=f(halo,name),difference=separation,
                                          one_sigma_equal_signal_abs=abs(separation),fraction_of_common=abs(separation/f(halo,name))))
        for key in ("N_msun","slope","Kz","annulus_billion","T_excess","T_total","spatial_excess","spatial_total"):
            for label,comp in (("between_fine",("above",384)),("main_refinement",("main",256))):
                value=f(end[("main",384)],key)
                alternative=f(end[comp],key)
                error=abs(value/alternative-1)
                resolution.append(dict(case=case,quantity=key,comparison=label,main_fine=value,other=alternative,
                                       relative=error,meets_20ppm=error<TOL))
    table("small-response-checks.csv",checks);table("finite-splits.csv",changes);table("resolution-checks.csv",resolution)
    table("exposed-scores.csv",scores);table("vertical-checks.csv",vertical);table("measurement-thresholds.csv",forecasts)
    print("finite tangent max error",max(row["error"] for row in checks),"resolution misses",sum(not row["meets_20ppm"] for row in resolution))


if __name__=="__main__":
    main()

