from types import SimpleNamespace
from gas_common import HOME,OLD,POINTS,RADII,HEIGHT,np,read,table,guard,roots_legendre
from scipy.constants import parsec
from resolved_response import branch,ordinary
from disk_state import DiskState,root_values,families
from common_shape import disk_force
from ring_check import ring,Stars
from spatial_null import angular

def prediction():
    guard()
    project=[]
    sysm,source=branch.load("main")
    dark=ordinary(sysm,POINTS)[2]
    shared=sum(ordinary(sysm,POINTS)[:2])-disk_force(POINTS,3.)[0]
    stars=Stars()
    direct_stars=np.array([ring(stars,rr,HEIGHT,14,30,True) for rr in RADII])
    with np.load(HOME/"direct-rings.npz") as bank:
        gas=bank["HI"][-3:]+bank["H2"][-3:]
        shared+=np.column_stack((gas[:,1],np.zeros(3),gas[:,2]))
    order,count=32,384
    rule,aw=roots_legendre(max(64,3*order+32))
    orders=np.arange(0,order+1,2); full=np.arange(0,2*order+1,2)
    wave=SimpleNamespace(length=sysm.length,vel=sysm.vel,edge=sysm.edge,orders=orders,full=full,aw=aw/2,
                         roots=[root_values(mode,count) for mode in orders],angle=families((1+rule)/2,orders),extra=families((1+rule)/2,full))
    for case in ("catalogue","column"):
        idx=int(case=="column")
        bar=shared+np.column_stack((direct_stars[:,idx,1],np.zeros(3),direct_stars[:,idx,2]))
        tag=case+"-main-384-32-full"
        results=read(tag+"-results.csv")
        amp=float(next(row["halo_amplitude"] for row in results if row["mode"]=="matched" and row["fraction"]=="1.0" and row["model"]=="nfw"))
        with np.load(HOME/(tag+".npz")) as state:
            field=DiskState.force(wave,state["matched"],POINTS,panels=105)
        for model,exc in (("mts",field),("spherical_nfw",amp*dark)):
            forces=bar+exc
            for side in (1,-1):
                zz=side*HEIGHT
                rr=np.hypot(RADII,zz)
                gin,gz=forces[:,0],side*forces[:,2]
                polar=(-zz*gin-RADII*gz)/rr
                radial=(-RADII*gin+zz*gz)/rr
                assert np.max(abs(polar+side*RADII/rr*angular(forces)))<1e-10
                for cyl,sphere,ar,atheta in zip(RADII,rr,radial,polar):
                    solar_distance=np.hypot(cyl-8.122,zz-.0208)
                    project.append(dict(case=case,model=model,R_kpc=cyl,z_kpc=zz,r_kpc=sphere,d_sun_kpc=solar_distance,
                                  inside_nominal_3kpc=solar_distance<=3,ar_kms2_kpc=ar,atheta_kms2_kpc=atheta,
                                  ar_in_1em10_m_s2=ar*1e13/parsec,atheta_in_1em10_m_s2=atheta*1e13/parsec,
                                  aphi=0.,exposure="forecast only; covariance and tracer overlap not established"))
    table("gaia-spherical-forecast.csv",project)


if __name__=="__main__":
    prediction()

