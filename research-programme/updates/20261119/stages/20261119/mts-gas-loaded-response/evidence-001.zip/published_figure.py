from gas_common import HOME,put,sha,sys,json
from urllib.request import urlopen,Request
import pymupdf

URL="https://arxiv.org/pdf/2305.13358v3"
PDF="lim-2305.13358v3.pdf"


def acquire():
    assert (HOME/"gaia-spherical-forecast.csv").is_file()
    if not (HOME/PDF).is_file():
        with urlopen(Request(URL,headers={"User-Agent":"MTS private research figure verification"}),timeout=50) as stream:
            raw=stream.read(30_000_001)
        assert raw.startswith(b"%PDF") and len(raw)<=30_000_000
        put(PDF,raw)
    with pymupdf.open(HOME/PDF) as paper:
        hits=[page.number for page in paper if "Figure 9. Accelerations" in page.get_text()]
        assert len(hits)==1,hits
        page=paper[hits[0]]
        receipt=dict(url=URL,sha256=sha(HOME/PDF),page_zero=page.number,pages=len(paper),bytes=(HOME/PDF).stat().st_size,
                     vector_objects=len(page.get_drawings()),raster_objects=len(page.get_images()),license="see author/arXiv release; retained private")
        put("gaia-figure-source.json",(json.dumps(receipt,indent=2)+"\n").encode())
        print(receipt)


if __name__=="__main__":
    acquire()

