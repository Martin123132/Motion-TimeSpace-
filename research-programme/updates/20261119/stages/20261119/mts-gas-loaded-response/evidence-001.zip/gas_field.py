from gas_common import HOME,np,G,save,guard,gases,roots_legendre,sys
from numpy.polynomial.legendre import legvander
from scipy.special import eval_jacobi
from scipy.interpolate import CubicHermiteSpline

LEVELS={"base":(48,.125,144,160.),"high":(96,.075,256,240.),"fine":(144,.05,352,320.)}


def build(label):
    maximum,spacing,angular_order,extent=LEVELS[label]
    modes=np.arange(0,maximum+1,2)
    edges=np.unique(np.r_[np.arange(0.,32.,spacing),np.geomspace(32.,extent,1+int(130*(.1/spacing)**.6)),extent])
    node,weight=roots_legendre(7)
    width=np.diff(edges)[:,None]/2
    radii=edges[:-1,None]+(1+node)*width
    wr=width*weight
    flat=radii.ravel()[:,None]
    node,weight=roots_legendre(angular_order)
    mu=(1+node)/2
    project=legvander(mu,maximum)[:,::2]*(weight[:,None]/2)
    for gas in gases():
        density=np.zeros((len(flat),len(modes)))
        for index in range(0,len(flat),128):
            radius=flat[index:index+128]
            sigma,first,second=gas.sheet(radius)
            kernel,grad,profile=gas.vertical(radius*mu)
            physical=gas.surface(radius*np.sqrt(1-mu**2))
            source=(physical-sigma)*profile-(second+2*first/radius)*kernel-2*first*mu*grad
            density[index:index+len(radius)]=source@project
        rho=density.reshape(*radii.shape,len(modes))
        inner=np.zeros((len(edges),len(modes)))
        outer=np.zeros_like(inner)
        for index,(left,right) in enumerate(zip(edges,edges[1:])):
            sample=radii[index,:,None]
            inner[index+1]=(left/right)**(modes+1)*inner[index]+np.sum(wr[index,:,None]*sample**2/right*(sample/right)**modes*rho[index],axis=0)
        for index in range(len(radii)-1,-1,-1):
            left,right=edges[index:index+2]
            sample=radii[index,:,None]
            outer[index]=(left/right)**modes*outer[index+1]+np.sum(wr[index,:,None]*sample*(left/sample)**modes*rho[index],axis=0)
        phi=-4*np.pi*G*(inner+outer)
        derivative=np.zeros_like(phi)
        derivative[1:]=4*np.pi*G*((modes+1)*inner[1:]-modes*outer[1:])/edges[1:,None]
        save(label+"-"+gas.name,rad=edges,mode=modes,phi=phi,derivative=derivative,
             residual_monopole=4*np.pi*edges[-1]*inner[-1,0],mass_exact=gas.mass)
    print(label,"gravity coefficients saved",flush=True)


class Field:
    def __init__(self,level,gas):
        self.gas=gas
        with np.load(HOME/(level+"-"+gas.name+".npz")) as packet:
            self.r,self.modes,self.phi,self.der=(packet[key] for key in ("rad","mode","phi","derivative"))
        self.spline=CubicHermiteSpline(self.r,self.phi,self.der,axis=0)

    def multipoles(self,radius):
        rad=np.atleast_1d(radius)
        near=rad<=self.r[-1]
        phi=np.empty((len(rad),len(self.modes)))
        first=np.empty_like(phi)
        phi[near]=self.spline(rad[near])
        first[near]=self.spline(rad[near],1)
        far=rad[~near,None]
        phi[~near]=self.phi[-1]*(self.r[-1]/far)**(self.modes+1)
        first[~near]=-(self.modes+1)*phi[~near]/far
        return phi,first

    def mesh(self,radii,mu):
        phi,derivative=self.multipoles(radii)
        rad=radii[:,None]
        pol=legvander(mu,int(self.modes[-1]))[:,::2].T
        sigma,first,_=self.gas.sheet(rad)
        kernel,grad,_=self.gas.vertical(rad*mu)
        return phi@pol+4*np.pi*G*sigma*kernel,rad*(derivative@pol+4*np.pi*G*(first*kernel+sigma*mu*grad))

    def evaluate(self,points):
        rad=np.linalg.norm(points,axis=1)
        unit=points/rad[:,None]
        mu=unit[:,2]
        pol=legvander(mu,int(self.modes[-1]))[:,::2]
        phi,derivative=self.multipoles(rad)
        angular=np.column_stack([np.zeros_like(mu)]+[.5*(mode+1)*eval_jacobi(mode-1,1,1,mu) for mode in self.modes[1:]])
        sigma,first,_=self.gas.sheet(rad)
        kernel,grad,_=self.gas.vertical(points[:,2])
        potential=(phi*pol).sum(axis=1)+4*np.pi*G*sigma*kernel
        vertical=np.array([0.,0.,1.])
        force=-unit*((derivative*pol).sum(axis=1)+4*np.pi*G*first*kernel)[:,None]
        force-=(vertical-unit*mu[:,None])*((phi*angular).sum(axis=1)/rad)[:,None]+vertical*(4*np.pi*G*sigma*grad)[:,None]
        return potential,force


if __name__=="__main__":
    guard(True)
    for label in sys.argv[1:]:
        build(label)

