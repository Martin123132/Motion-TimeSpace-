from gas_common import HOME,OLD,np,G,gases,guard,read,save,table,roots_legendre,locations,quad,arrangement,TOL
from gas_field import Field
from resolved_response import flux
from scipy.special import ellipkm1,ellipe


def evaluate(gas,radius,height,order,end):
    edges=np.unique(np.r_[0.,np.arange(.75,30.,.75),30.,40.,60.,90.,130.,end,radius])
    rule,weights=roots_legendre(order)
    width=np.diff(edges)[:,None]/2
    radial=edges[:-1,None]+width*(1+rule)
    measure=width*weights
    for index,(left,right) in enumerate(zip(edges,edges[1:])):
        if left==radius or right==radius:
            unit=(1+rule)/2
            radial[index]=radius+(1 if left==radius else -1)*(right-left)*unit**3
            measure[index]=1.5*(right-left)*unit**2*weights
    radial,measure=radial.ravel(),measure.ravel()
    uz,wz=roots_legendre(2*order)
    zmax=5.
    cuts=np.unique(np.r_[-zmax,-2.,-1.,0.,1.,2.,zmax,np.clip(height,-zmax,zmax),gas.height*np.array([-12.,-6.,-2.,2.,6.,12.])])
    out=np.zeros(3)
    for index in range(0,len(radial),32):
        rings=radial[index:index+32,None]
        dr=abs(radius-rings)
        mapped=np.arcsinh((cuts-height)/dr)
        widths=np.diff(mapped)[:,:,None]/2
        sample=(mapped[:,:-1,None]+(1+uz)*widths).reshape(len(rings),-1)
        dz=dr*np.sinh(sample)
        weight=(widths*wz).reshape(len(rings),-1)*dr*np.cosh(sample)
        small=dr**2+dz**2
        big=(rings+radius)**2+dz**2
        ratio=small/big
        first,second=ellipkm1(ratio),ellipe(1-ratio)
        density=gas.surface(rings)*gas.vertical(height+dz)[2]
        base=2*G*rings*measure[index:index+32,None]*weight*density/np.sqrt(big)
        out+=np.array([np.sum(-2*base*first),np.sum(base/radius*(first+((radius-rings)*(radius+rings)-dz**2)*second/small)),
                       np.sum(2*base*dz*second/small)])
    return out


def build():
    guard(True)
    full=locations()
    points=np.vstack((full,[[-1.,0.,0.],[-2.,0.,.03],[-40.,0.,0.],[-100.,0.,9.]]))
    unique,inverse=np.unique(points,axis=0,return_inverse=True)
    rows=[]; masses=[]; oldrows=read("gas-direct-only.csv",OLD); pack={}; refinements=[]
    for gas in gases():
        coarse=np.array([evaluate(gas,-pt[0],pt[2],9,175.) for pt in unique])[inverse]
        fine=np.array([evaluate(gas,-pt[0],pt[2],15,250.) for pt in unique])[inverse]
        relative=abs(coarse-fine)/np.maximum(abs(fine),1.)
        pack[gas.name]=fine[:len(full)]
        for idx in np.flatnonzero(np.any(relative>=TOL,axis=1)):
            pt=points[idx]
            finer=evaluate(gas,-pt[0],pt[2],24,280.)
            error=np.max(abs(finer-fine[idx])/np.maximum(1.,abs(finer)))
            refinements.append(dict(component=gas.name,index=idx,R=-pt[0],z=pt[2],initial=relative[idx].max(),refined=error))
            assert error<TOL
        for label in ("base","high","fine"):
            field=Field(label,gas)
            phi,acc=field.evaluate(points)
            vals=np.column_stack((phi,acc[:,0],acc[:,2]))
            for idx,pt in enumerate(points):
                rel=abs(vals[idx]-fine[idx])/np.maximum(1.,abs(fine[idx]))
                rows.append(dict(component=gas.name,level=label,index=idx,R=-pt[0],z=pt[2],potential_rel=rel[0],
                                 radial_rel=rel[1],vertical_rel=rel[2],ring_pair_worst=relative[idx].max()))
            with np.load(HOME/(label+"-"+gas.name+".npz")) as coeff:
                mono=float(coeff["residual_monopole"])
            rr=-points[:,0]
            exact=2*np.pi*quad(lambda cyl:cyl*gas.surface(cyl)*np.tanh(1.5/(2*gas.height)),7.,9.,epsrel=1e-11)[0]
            exterior=2*np.pi*quad(lambda cyl:cyl*gas.surface(cyl),30.,np.inf,epsrel=1e-10)[0]
            gr=np.column_stack((fine[:,1],np.zeros(len(points)),fine[:,2]))
            fluxmass=flux(gr[:len(arrangement()[0])])*1e9
            masses.append(dict(component=gas.name,level=label,analytic_mass=gas.mass,mass_outside_R30=exterior,
                               residual_monopole=mono,monopole_rel=mono/gas.mass-1,annulus_density=exact,
                               annulus_from_flux=fluxmass,annulus_rel=fluxmass/exact-1))
        for old in oldrows:
            if old["component"]!=gas.name or old["order"]!="18":
                continue
            find=np.flatnonzero((abs(rr-float(old["R"]))<1e-12)&(points[:,2]==float(old["z"])))
            assert len(find)>0
            assert max(abs(fine[find[0],1:]/[float(old["g_in"]),float(old["gz"])]-1))<TOL
    table("potential-force-controls.csv",rows)
    table("mass-controls.csv",masses)
    if refinements:
        table("direct-refinements.csv",refinements)
    assert max(abs(row["annulus_rel"]) for row in masses)<TOL
    best=[row for row in rows if row["level"]=="fine"]
    assert max(row["potential_rel"] for row in best)<TOL
    assert max(abs(row["monopole_rel"]) for row in masses if row["level"]=="fine")<TOL
    save("direct-rings",locations=full,**pack)
    print("accepted direct banks; fine potential vs rings",max(row["potential_rel"] for row in best),flush=True)


if __name__=="__main__":
    build()

