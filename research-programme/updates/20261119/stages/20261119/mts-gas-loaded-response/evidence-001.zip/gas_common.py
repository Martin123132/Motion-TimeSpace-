from pathlib import Path
import os
import sys
import csv
import io
import json
import hashlib

for setting in ("OPENBLAS_NUM_THREADS","OMP_NUM_THREADS","MKL_NUM_THREADS","NUMEXPR_NUM_THREADS"):
    os.environ[setting]="1"
HOME=Path(__file__).resolve().parent
OLD=HOME.parent/"mts-resolved-stellar-source-20261119"
sys.path.insert(0,str(OLD))
from stellar import np,G
from resolved_response import arrangement
from spatial_null import POINTS,RADII,HEIGHT
from scipy.special import roots_legendre, kv
from scipy.integrate import quad

PARENT_HASH="ca98c3d986b58fea3eecc394da455541c2338738974aeae7793efdaca2be010c"
TOL=2e-5


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def guard(full=False):
    assert sha(OLD/"seal.json")==PARENT_HASH
    assert not any((folder/"STOP-REQUESTED").exists() for folder in (HOME,OLD,HOME.parent))
    if full:
        assert all(sha(OLD/name)==digest for name,digest in json.loads((OLD/"seal.json").read_bytes())["files"].items())


def put(name,raw):
    path=HOME/name
    if path.exists():
        assert path.read_bytes()==raw,name
    else:
        with path.open("xb") as out:
            out.write(raw)


def table(name,rows):
    output=io.StringIO(newline="")
    writer=csv.DictWriter(output,fieldnames=tuple(rows[0]),lineterminator="\n")
    writer.writeheader()
    writer.writerows(rows)
    put(name,output.getvalue().encode())


def read(name,root=HOME):
    with (root/name).open(newline="") as handle:
        return list(csv.DictReader(handle))


def save(name,**values):
    path=HOME/(name+".npz")
    if path.exists():
        with np.load(path) as prev:
            assert set(prev)==set(values) and all(np.array_equal(prev[key],val) for key,val in values.items()),name
    else:
        with path.open("xb") as handle:
            np.savez_compressed(handle,**values)


class Gas:
    def __init__(self,row):
        self.name=row["component"]
        self.rd,self.rm,self.height,self.central=(float(row[key]) for key in ("Rd_kpc","Rm_kpc","zd_kpc","Sigma0_msun_pc2"))
        self.central*=1e6
        self.mass=4*np.pi*self.central*self.rd*self.rm*kv(2,2*np.sqrt(self.rm/self.rd))

    def surface(self,rad):
        return self.central*np.exp(-self.rm/np.maximum(rad,1e-12)-rad/self.rd)

    def sheet(self,rad):
        radius=np.maximum(rad,1e-8)
        value=self.surface(radius)
        log_slope=self.rm/radius**2-1/self.rd
        return value,value*log_slope,value*(log_slope**2-2*self.rm/radius**3)

    def vertical(self,z):
        exponent=abs(z)/self.height
        tail=np.exp(-exponent)
        kernel=self.height*(exponent/2+np.log1p(tail)-np.log(2))
        grad=.5*np.tanh(z/(2*self.height))
        density=tail/(self.height*(1+tail)**2)
        return kernel,grad,density


def gases():
    guard()
    return [Gas(row) for row in read("gas-source-input.csv",OLD)]


def locations():
    return np.vstack((arrangement()[0],POINTS))

