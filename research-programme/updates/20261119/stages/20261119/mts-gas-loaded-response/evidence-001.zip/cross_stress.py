from gas_common import HOME,OLD,np,G,guard,table,gases,roots_legendre,sys,read
from gas_field import Field
from resolved_response import branch,CONFIGS
from disk_state import basis,root_values,families
from numpy.polynomial.legendre import legvander
from scipy.interpolate import CubicHermiteSpline
from scipy import constants
from satellite import MSUN


def grid(edges,order):
    edges=np.unique(edges)
    rule,weights=roots_legendre(order)
    width=np.diff(edges)[:,None]/2
    return edges[:-1,None]+width*(1+rule),width*weights


def axes(modes,mu):
    pol=legvander(mu,int(modes[-1]))
    grad=np.zeros((*mu.shape,len(modes)))
    grad[...,1:]=modes[1:]*(pol[...,1:-1:2]-mu[...,None]*pol[...,2::2])
    return pol[...,::2],grad


class Wave(Field):
    def __init__(self,edges,nodes,wr,modes,rho):
        self.r,self.modes=edges,modes
        inner=np.zeros((len(edges),len(modes)))
        outer=inner.copy()
        rho=rho.reshape(*nodes.shape,len(modes))
        for idx,(left,right) in enumerate(zip(edges,edges[1:])):
            rad=nodes[idx,:,None]
            inner[idx+1]=(left/right)**(modes+1)*inner[idx]+np.sum(wr[idx,:,None]*rad**2/right*(rad/right)**modes*rho[idx],axis=0)
        for idx in range(len(edges)-2,-1,-1):
            left,right=edges[idx:idx+2]
            rad=nodes[idx,:,None]
            outer[idx]=(left/right)**modes*outer[idx+1]+np.sum(wr[idx,:,None]*rad*(left/rad)**modes*rho[idx],axis=0)
        self.phi=-4*np.pi*G*(inner+outer)
        self.der=np.zeros_like(inner)
        self.der[1:]=4*np.pi*G*((modes+1)*inner[1:]-modes*outer[1:])/edges[1:,None]
        self.spline=CubicHermiteSpline(edges,self.phi,self.der,axis=0)
        self.mass=4*np.pi*edges[-1]*inner[-1,0]

    def at(self,rad,mu):
        phi,dr=self.multipoles(rad)
        pol,grad=axes(self.modes,mu)
        return (phi*pol).sum(axis=1),mu*(dr*pol).sum(axis=1)+(phi*grad).sum(axis=1)/rad


def spherical_gas(field,rad,mu):
    pol,grad=axes(field.modes,mu)
    phi,dr=field.multipoles(rad)
    radius=rad[:,None]
    sigma,slope,_=field.gas.sheet(radius)
    kern,first,_=field.gas.vertical(radius*mu)
    potential=phi@pol.T+4*np.pi*G*sigma*kern
    down=(dr@pol.T)*mu+(phi@grad.T)/radius+4*np.pi*G*(slope*mu*kern+sigma*first)
    return potential,down


def gas_integral(wave,gas,spatial,order):
    rad,wr=grid(np.r_[np.arange(0.,36.,spatial),np.geomspace(36.,300.,93)],order)
    rad,wr=rad.ravel(),wr.ravel()
    heights,wz=grid(gas.height*np.array([0.,.5,1.,2.,4.,8.,15.,28.,48.]),order)
    heights,wz=heights.ravel(),wz.ravel()
    zweight=wz*gas.vertical(heights)[2]
    total=np.zeros(2)
    for idx in range(0,len(rad),50):
        cyl=rad[idx:idx+50,None]
        radius=np.hypot(cyl,heights)
        source=gas.surface(cyl)*cyl*wr[idx:idx+50,None]*zweight
        phi,down=wave.at(radius.ravel(),(heights/radius).ravel())
        total+=np.array([4*np.pi*np.sum(source*phi.reshape(radius.shape)),2*np.pi*np.sum(source*down.reshape(radius.shape))])
    return total


def traction(wave,field,spatial,order):
    top=max(500.,wave.r[-1],field.r[-1])
    rad,wr=grid(np.r_[np.arange(0.,43.,spatial),np.geomspace(43.,top,90)],order)
    rad,wr=rad.ravel(),wr.ravel()
    def equator(obj):
        return legvander(np.array([0.]),int(obj.modes[-1]))[0,::2]
    def field_r(obj):
        return obj.multipoles(rad)[1]@equator(obj)
    value=(wr*rad)@(field_r(wave)*field_r(field))/(2*G)
    def outer(obj):
        return obj.multipoles([top])[1][0]*equator(obj)
    tail=top**2*np.sum(outer(wave)[:,None]*outer(field)[None,:]/(wave.modes[:,None]+field.modes[None,:]+2))/(2*G)
    return value+tail,tail


def test(label,count,order,quality):
    guard()
    spacing,rule,nmu=(.65,7,148) if quality=="coarse" else (.30,9,224)
    with np.load(branch.HERE/(label+".npz")) as source:
        parent=dict(source)
    with np.load(branch.PARENT/("angular24-cap.npz" if label=="above" else "angular28-diff.npz")) as source:
        speed=float(source["velocity_unit_kms"])
    length=float(parent["length"])
    edge=float(parent["edge"])
    stop=length*edge
    edges=np.unique(np.r_[0.,np.arange(spacing,52.,spacing),np.geomspace(52.,stop,100 if quality=="fine" else 66),stop])
    nodes,wr=grid(edges,rule)
    rad=nodes.ravel()
    orders=np.arange(0,order+1,2)
    full=np.arange(0,2*order+1,2)
    columns=[basis(mode,root_values(mode,count),edge,rad/length) for mode in orders]
    rule_mu,wmu=roots_legendre(nmu)
    mu=(1+rule_mu)/2
    wmu=wmu/2
    mat=families(mu,orders)
    pol=legvander(mu,int(full[-1]))[:,::2]*wmu[:,None]
    prefactor=speed**2/(4*np.pi*G*length**2)
    inherited_unit=float(parent["mass_msun"])/float(parent["mass"])
    metric_unit=speed**2*length/G
    conversion=metric_unit/inherited_unit
    expected=constants.G*MSUN/(constants.parsec*1e9)/G
    assert abs(conversion/expected-1)<2e-12
    table("mass-convention-"+label+".csv",[dict(unit_saved=inherited_unit,unit_metric=metric_unit,conversion=conversion,
          saved_GM_solar_SI=constants.G*MSUN,metric_GM_solar_SI=G*constants.parsec*1e9)])
    source_mats=[(gas,Field("fine",gas)) for gas in gases()]
    components=[spherical_gas(field,rad,mu) for _,field in source_mats]
    rows=[]
    for case in ("catalogue","column"):
        prefix=f"{case}-{label}-{count}-{order}"
        traces=read(prefix+"-full-stationarity.csv")
        initial=[row for row in read(prefix+"-full-results.csv") if row["mode"]=="fixed" and row["model"]=="mts" and float(row["fraction"])==0][0]
        initial_mass=float(initial["N_msun"])
        with np.load(HOME/(prefix+"-full.npz")) as packet:
            for mode in ("fixed","matched"):
                coef=packet[mode]
                mass=float(packet[mode+"_norm"])*float(parent["mass_msun"])/float(parent["mass"])
                density=prefactor*(np.column_stack([col@one for col,one in zip(columns,coef)])@mat.T)**2
                wave=Wave(edges,nodes,wr,full,density@pol)
                assert abs(wave.mass/(mass*conversion)-1)<2e-6
                measure=2*np.pi*(wr.ravel()*rad**2)[:,None]*wmu*density
                trace=next(row for row in traces if row["mode"]==mode and float(row["fraction"])==1)
                for (gas,field),(potential,down) in zip(source_mats,components):
                    from_gas=2*np.sum(measure*potential)
                    force_on_wave=np.sum(measure*down)
                    from_wave,force_on_gas=gas_integral(wave,gas,spacing,rule)
                    plane,tail=traction(wave,field,spacing,rule)
                    hamiltonian=float(trace[gas.name+"_pair"])*initial_mass*conversion
                    rows.append(dict(case=case,mode=mode,component=gas.name,quality=quality,wave_mass_saved=mass,wave_mass_metric=mass*conversion,
                                     volume_mass=wave.mass,U_wave_in_gas=from_gas,U_gas_in_wave=from_wave,U_hamiltonian=hamiltonian,
                                     reciprocity_rel=from_wave/from_gas-1,action_rel=hamiltonian/from_gas-1,unconverted_action_rel=hamiltonian/conversion/from_gas-1,
                                     half_down_on_wave=force_on_wave,half_down_on_gas=force_on_gas,
                                     boundary_down=plane,tail_included=tail,flux_balance_rel=(force_on_wave+force_on_gas)/plane-1))
    table(f"cross-stress-{label}-{count}-{order}-{quality}.csv",rows)
    print("energy reciprocity, Hamiltonian, stress-flux max rel:",*[max(abs(row[key]) for row in rows) for key in
                                                                   ("reciprocity_rel","action_rel","flux_balance_rel")],flush=True)


if __name__=="__main__":
    test(sys.argv[1],int(sys.argv[2]),int(sys.argv[3]),sys.argv[4])

