from gas_common import HOME,OLD,np,sys,guard,read,table,save,gases,locations,arrangement,POINTS,HEIGHT,RADII,sha
from gas_field import Field
from resolved_response import branch,ordinary,polish,OUTER,SPEED,step,flux,data
from spatial_null import angular
from common_shape import disk_force
from disk_tangent import Linearization

CASES=("catalogue","column")


class Experiment:
    def __init__(self,case,label,count,order):
        guard()
        self.case=case
        self.tag=f"{case}-{label}-{count}-{order}"
        with np.load(branch.HERE/(label+".npz")) as initial:
            self.params=dict(initial)
        params=self.params
        system=branch.DiskState(str(params["label"]),count,order,float(params["edge"]),float(params["eta"]))
        self.system=system
        physical=system.rad*system.length
        prefix=f"endpoint-{label}-{count}-{order}"
        with np.load(OLD/(prefix+".npz")) as saved:
            self.seed=saved[case]
            self.norm0=float(saved[case+"_mass"])
        self.mass_unit=float(params["mass_msun"])/float(params["mass"])
        self.loc=locations()
        loc,self.radii,self.nc,self.no,*_=arrangement()
        self.cut=len(self.radii)
        self.anchor=self.nc-1
        star_phi,star_work,star_change,_=data(system,case)
        self.ext=system.ext+star_phi/system.vel**2
        self.vir=system.vir+star_work/system.vel**2
        self.potential=[];self.work=[];self.forces=[]
        self.halo=ordinary(system,self.loc)[2]
        common,compact,_=ordinary(system,loc)
        self.common=common+compact+star_change
        self.halo0=(SPEED**2/OUTER-self.common[self.anchor,0])/self.halo[self.anchor,0]
        with np.load(OLD/"spatial-null-weights.npz") as angular_pack:
            self.weights=angular_pack["weight"]
            self.common_angles=angular_pack["values"][:,int(case=="column")]+angular(sum(ordinary(system,POINTS)[:2])-disk_force(POINTS,3.)[0])
        with np.load(HOME/"direct-rings.npz") as packet:
            assert np.array_equal(self.loc,packet["locations"])
            for gas in gases():
                potential,work=Field("fine",gas).mesh(physical,system.mu)
                self.potential.append(potential/system.vel**2)
                self.work.append(work/system.vel**2)
                src=packet[gas.name]
                self.forces.append(np.column_stack((src[:,1],np.zeros(len(src)),src[:,2])))
        self.scale=system.vel**2/self.norm0
        self.load(0.)
        system.mass=self.norm0
        self.initial=polish(system,self.seed.copy())
        self.anchor_loc=self.loc[self.anchor:self.anchor+1]
        self.wave0=system.force(self.initial.state,self.loc)

    def load(self,strength):
        self.system.ext=self.ext+strength*(self.potential[0]+self.potential[1])
        self.system.vir=self.vir+strength*(self.work[0]+self.work[1])

    def obs(self,added,gas_force,reference=None):
        size=len(self.common)
        grav=self.common+added[:size]+gas_force[:size] if reference is None else added[:size]+gas_force[:size]
        speeds=np.sqrt(self.radii*grav[:self.cut,0]) if reference is None else self.radii*grav[:self.cut,0]/(2*reference)
        wave_angles=angular(added[-3:])
        total_angles=wave_angles+angular(gas_force[-3:])
        if reference is None:
            total_angles+=self.common_angles
        return dict(outer=speeds[self.anchor],slope=(speeds[-2]-speeds[-3])/step,Kz=grav[self.cut,2],annulus_billion=flux(grav),
                    T_excess=wave_angles[1],T_total=total_angles[1],spatial_excess=self.weights@wave_angles,
                    spatial_total=self.weights@total_angles),speeds

    def root(self,start,calibrate,fraction):
        system=self.system
        gas=self.forces[0]+self.forces[1]
        for index in range(10):
            curve=polish(system,start.copy())
            difference=OUTER*(system.force(curve.state,self.anchor_loc)[0,0]+self.common[self.anchor,0]+fraction*gas[self.anchor,0])-SPEED**2
            if not calibrate or abs(difference)<2e-12*SPEED**2:
                return curve
            direction,*_=curve.differentiate("mass")
            slope=OUTER*system.force(curve.state,self.anchor_loc,tangent=direction)[0,0]
            assert slope>0
            change=np.clip(-difference/slope,-.1,.1)
            system.mass*=np.exp(change)
            start=curve.state+change*direction
        raise RuntimeError("outer calibration failed")


def freeze(case,label,count,order):
    exp=Experiment(case,label,count,order)
    sysm=exp.system
    curve=exp.initial
    mass_dir,_,_,_=curve.differentiate("mass")
    mass_force=sysm.force(curve.state,exp.loc,tangent=mass_dir)
    directions=[]; drives=[]
    rows=[]; energy=[]
    zeros=np.zeros_like(exp.wave0)
    _,wave_speed=exp.obs(exp.wave0,zeros)
    _,halo_speed=exp.obs(exp.halo0*exp.halo,zeros)
    for name,potential,direct in zip(("HI","H2"),exp.potential,exp.forces):
        drive=curve.read(potential*curve.wave)
        delta=curve.constrained(-drive)
        projected=drive+curve.response(delta)
        mu=np.sum(curve.state*projected)/sysm.mass
        assert np.linalg.norm(projected-mu*curve.state)<1e-10 and abs(np.sum(curve.state*delta))<1e-10
        directions.append(delta)
        drives.append(drive)
        field=sysm.force(curve.state,exp.loc,tangent=delta)
        dlog=-(direct+field)[exp.anchor,0]/mass_force[exp.anchor,0]
        halo_delta=-direct[exp.anchor,0]/exp.halo[exp.anchor,0]
        for model,speed,parts in (("mts",wave_speed,(field,mass_force*dlog)),("nfw",halo_speed,(zeros,exp.halo*halo_delta))):
            for part,added,gas in (("direct",zeros,direct),("rearranged",parts[0],zeros),("calibration",parts[1],zeros),
                                   ("fixed",parts[0],direct),("matched",parts[0]+parts[1],direct)):
                measures,_=exp.obs(added,gas,speed)
                rows.append(dict(component=name,model=model,part=part,**measures))
        first=np.sum(sysm.weights[:,None]*sysm.aw*curve.wave**2*potential)*exp.scale
        energy.append(dict(component=name,fixed_first=first,matched_first=first+curve.chemical*exp.norm0*dlog*exp.scale,
                           dlogN=dlog,halo_damplitude=halo_delta,stationarity=np.linalg.norm(projected-mu*curve.state)))
    matrix=2*np.array([[np.sum(drive*delta)*exp.scale for delta in directions] for drive in drives])
    assert np.max(abs(matrix-matrix.T))<1e-8 and np.max(np.linalg.eigvalsh(matrix))<0
    table(exp.tag+"-frozen.csv",rows)
    table(exp.tag+"-energy-frozen.csv",energy)
    save(exp.tag+"-susceptibility",matrix=matrix,eigenvalues=np.linalg.eigvalsh(matrix),HI=directions[0],H2=directions[1],mass=mass_dir)
    print(exp.tag,"energy response matrix",matrix.ravel(),flush=True)


def run(case,label,count,order,checks=False):
    exp=Experiment(case,label,count,order)
    sysm=exp.system
    assert (HOME/(exp.tag+"-frozen.csv")).is_file()
    direct=exp.forces[0]+exp.forces[1]
    zeros=np.zeros_like(direct)
    output=[]; profiles=[]; traces=[]; bundle={}
    def record(fraction,mode,model,exc,gas,occupation,halo,energy,coupling):
        values,speeds=exp.obs(exc,gas)
        output.append(dict(fraction=fraction,mode=mode,model=model,N_msun=occupation,halo_amplitude=halo,
                           energy_per_original_mass=energy,current_gas_pair_per_original_mass=coupling,**values))
        if not checks and fraction in (0.,1.):
            for index in range(exp.nc+exp.no):
                profiles.append(dict(fraction=fraction,mode=mode,model=model,sample="cepheid" if index<exp.nc else "giant",
                                     R=exp.radii[index],speed=speeds[index]))
    for mode in ("fixed","matched"):
        sysm.mass=exp.norm0
        start=exp.seed.copy()
        path=(-1/64,1/64,-1/128,1/128) if checks else (0.,.5,1.)
        for fraction in path:
            guard()
            if checks:
                start=exp.seed.copy()
                sysm.mass=exp.norm0
            exp.load(fraction)
            curve=exp.root(start,mode=="matched",fraction)
            start=curve.state.copy()
            wave=sysm.force(start,exp.loc)
            norm=sysm.mass*exp.mass_unit
            measure=sysm.weights[:,None]*sysm.aw*curve.wave**2
            pairs=[np.sum(measure*potential)*exp.scale for potential in exp.potential]
            record(fraction,mode,"mts",wave,fraction*direct,norm,"",curve.energy*exp.scale,sum(pairs))
            halo=exp.halo0 if mode=="fixed" else exp.halo0-fraction*direct[exp.anchor,0]/exp.halo[exp.anchor,0]
            assert halo>0
            record(fraction,mode,"nfw",halo*exp.halo,fraction*direct,"",halo,"","")
            traces.append(dict(mode=mode,fraction=fraction,stationarity=np.linalg.norm(curve.resid),
                               norm_residual=np.sum(start**2)/sysm.mass-1,chemical=curve.chemical,HI_pair=pairs[0],H2_pair=pairs[1]))
            if not checks and fraction==1.:
                bundle[mode]=start.copy(); bundle[mode+"_norm"]=sysm.mass
        if not checks and mode=="fixed":
            record(1.,"direct-only","mts",exp.wave0,direct,exp.norm0*exp.mass_unit,"","","")
            record(1.,"direct-only","nfw",exp.halo0*exp.halo,direct,"",exp.halo0,"","")
    label=exp.tag+("-small" if checks else "-full")
    table(label+"-results.csv",output)
    table(label+"-stationarity.csv",traces)
    if not checks:
        table(label+"-curves.csv",profiles)
        save(label,**bundle)
    print(label,"finished",flush=True)


if __name__=="__main__":
    action,case,label,count,order=sys.argv[1:]
    if action=="freeze":
        freeze(case,label,int(count),int(order))
    else:
        assert action in ("small","full")
        run(case,label,int(count),int(order),action=="small")

