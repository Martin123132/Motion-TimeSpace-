from gas_common import OLD,HOME,np,read,table,guard,RADII,HEIGHT
from stellar import Stars,R0
from scipy.constants import parsec


def derive():
    guard()
    stars=Stars()
    observed=read("gaia-figure9-comparison.csv")
    solar=[]; bounds=[]; summary=[]
    with np.load(OLD/"spatial-null-weights.npz") as star:
        templates=star["values"]
    with np.load(HOME/"direct-rings.npz") as pkt:
        gas=pkt["HI"][-3:]+pkt["H2"][-3:]
        gas_t=gas[:,2]+HEIGHT/RADII*gas[:,1]
    for case,norm in (("catalogue",stars.rho0),("column",stars.column_norm)):
        total=stars.column_shape(R0,10)@norm/1e6
        inner=stars.column_shape(R0,1.1)@norm/1e6
        low,high=0.,np.inf
        for index,rad in enumerate(RADII[:2]):
            tstar=templates[index,int(case=="column")]
            radius=np.hypot(rad,HEIGHT)
            for side,sign in (("north",1.),("south",-1.)):
                row=next(row for row in observed if row["model"]=="spherical_nfw" and row["case"]==case and row["side"]==side
                         and float(row["R_cylinder_kpc"])==rad and row["component"]=="atheta")
                factor=-sign*radius/rad*parsec/1e13
                def ratio(key):
                    return (float(row[key])*factor-gas_t[index])/tstar
                interval=sorted([ratio("lo95"),ratio("hi95")])
                assert abs(((float(row["predicted"])*factor-gas_t[index])/tstar)-1)<1e-10
                bounds.append(dict(case=case,R=rad,side=side,central_eta=ratio("center"),inside_outer_min=interval[0],inside_outer_max=interval[1]))
                low=max(low,interval[0]);high=min(high,interval[1])
        for label,adjust,adjust_1p1 in (("all_table_components",0.,0.),("omit_brown_dwarf_central_only",1.2,1.1)):
            central=(33.4-adjust)/total
            solar.append(dict(case=case,convention=label,sigma_template_full=total,sigma_template_1p1=inner,
                              scale_from_full=central,scale_from_1p1=(31.2-adjust_1p1)/inner,
                              projected_1p1_at_full_scale=central*inner,census_1p1=31.2-adjust_1p1))
        census_lo,census_hi=(33.4-3)/total,(33.4+3)/total
        summary.append(dict(case=case,angular_intersection_low=low,angular_intersection_high=high,sky_nonempty=low<=high,
                            census_nominal_low=census_lo,census_nominal_high=census_hi,
                            intersection_with_nominal_census=max(low,census_lo)<=min(high,census_hi),
                            nominal_central_passes_angular=low<=33.4/total<=high))
    table("spherical-required-normalization.csv",bounds)
    table("solar-counts-input.csv",solar)
    table("angular-vs-census.csv",summary)
    print(summary)


if __name__=="__main__":
    derive()

