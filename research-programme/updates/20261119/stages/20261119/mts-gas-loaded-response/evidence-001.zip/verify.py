from gas_common import HOME,OLD,np,read,table,guard,put,sha,json,sys,TOL
from loaded import CASES
from published_figure import PDF
from figure_compare import DIGEST

def verify():
    guard(True)
    assert sha(HOME/PDF)==DIGEST==json.loads((HOME/"gaia-figure-source.json").read_bytes())["sha256"]
    checks=read("small-response-checks.csv")
    assert len(checks)==70 and all(row["meets_20ppm"]=="True" and float(row["error"])<TOL for row in checks)
    assert max(float(row["potential_rel"]) for row in read("potential-force-controls.csv") if row["level"]=="fine")<TOL
    assert all(abs(float(row["annulus_rel"]))<TOL for row in read("mass-controls.csv"))
    assert all(float(row["initial"])>=TOL>float(row["refined"]) for row in read("direct-refinements.csv"))
    with np.load(HOME/"direct-rings.npz") as packet:
        assert packet["locations"].shape==(119,3) and packet["HI"].shape==packet["H2"].shape==(119,3)
    for case in CASES:
        for seed,count,order in (("main",256,24),("main",384,32),("above",384,32)):
            tag=f"{case}-{seed}-{count}-{order}"
            with np.load(HOME/(tag+"-susceptibility.npz")) as packet:
                matrix=packet["matrix"]
                assert np.allclose(matrix,matrix.T,rtol=1e-10,atol=1e-10) and max(np.linalg.eigvalsh(matrix))<0
            full=read(tag+"-full-results.csv")
            assert len(full)==14 and all(abs(float(row["outer"])-224.03)<1e-8 for row in full if row["mode"]=="matched")
            with np.load(HOME/(tag+"-full.npz")) as packet:
                for mode in ("fixed","matched"):
                    assert abs(np.sum(packet[mode]**2)/packet[mode+"_norm"]-1)<1e-12
    resolution=read("resolution-checks.csv")
    assert len(resolution)==32 and all((float(row["relative"])<TOL)==(row["meets_20ppm"]=="True") for row in resolution)
    assert all(row["meets_20ppm"]=="True" for row in resolution if row["comparison"]=="between_fine" and row["quantity"]!="spatial_excess")
    for label in ("main-256-24-coarse","main-256-24-fine","main-384-32-fine"):
        rows=read("cross-stress-"+label+".csv")
        assert len(rows)==8
        for row in rows:
            assert all(abs(float(row[key]))<TOL for key in ("action_rel","flux_balance_rel","reciprocity_rel"))
            assert abs(float(row["unconverted_action_rel"]))>TOL and float(row["tail_included"])>0
            assert abs(float(row["volume_mass"])/float(row["wave_mass_metric"])-1)<TOL
            assert float(row["U_wave_in_gas"])<0 and float(row["boundary_down"])>0
    sky=read("gaia-figure9-comparison.csv"); forecasts=read("gaia-spherical-forecast.csv")
    assert len(sky)==32 and len(forecasts)==24
    assert len({(row["R_cylinder_kpc"],row["side"],row["component"]) for row in sky})==8
    assert all(row["R_cylinder_kpc"]!="12.0" and float(row["render_rgb_error"])<.08 for row in sky)
    assert all(row["in_outer_band"]=="False" for row in sky if row["component"]=="atheta")
    assert any(row["in_inner_band"]=="True" for row in sky if row["component"]=="ar")
    angular=read("angular-vs-census.csv"); census=read("census-third-moment.csv")
    assert [row["nominal_central_passes_angular"] for row in angular]==["True","False"]
    assert all(float(row["density_if_both_columns_fit"])>float(row["density_census"]) for row in census)
    assert len(read("exposed-scores.csv"))==48 and len(read("gaia-force-parity.csv"))==24
    for path in HOME.glob("*.csv"):
        rows=read(path.name)
        assert rows and all(None not in row and None not in row.values() for row in rows)
    assert all((HOME/name).is_file() for name in ("PROTOCOL.md","GAIA-COMPARISON-PROTOCOL.md","DERIVATION.md","RESULTS.md","NEXT.md","REPLAY.md"))
    assert not any(path.is_dir() for path in HOME.iterdir())
    return {path.name:sha(path) for path in sorted(HOME.iterdir()) if path.name!="seal.json"}


if __name__=="__main__":
    files=verify()
    manifest=dict(predecessor=sha(OLD/"seal.json"),files=files)
    if sys.argv[1:]==["seal"]:
        put("seal.json",(json.dumps(manifest,sort_keys=True,indent=2)+"\n").encode())
    assert json.loads((HOME/"seal.json").read_bytes())==manifest
    print("Verified",len(files),"files and completed checks. SHA256:",sha(HOME/"seal.json"))

