from gas_common import np,read,table,OLD,guard
from stellar import Stars,R0

def calculate():
    guard()
    stars=Stars()
    rows=[]
    for item in read("census-two-column-shapes.csv"):
        if item["population"]!="all":
            continue
        case=item["case"]
        norm=stars.rho0 if case=="catalogue" else stars.column_norm
        eta=float(item["eta"])
        measured=.043
        scale=eta*norm.sum()/1e9/measured
        partial=eta*(stars.column_shape(R0,min(10.,1.1/scale))@norm)/1e6
        rows.append(dict(case=case,scale_mass=eta,height_from_full_and_1p1=item["b"],density_if_both_columns_fit=item["new_solar_midplane"],
                         density_census=measured,height_from_full_and_density=scale,column_1p1_if_density_fit=partial,
                         column_1p1_census=31.2,positive_exp_mixture_infinite_midplane_min=-33.4*np.log1p(-31.2/33.4)/2200))
    table("census-third-moment.csv",rows)

if __name__=="__main__":
    calculate()

