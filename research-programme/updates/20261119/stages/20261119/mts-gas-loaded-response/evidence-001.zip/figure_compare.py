import pymupdf
from gas_common import HOME,np,read,table,sha,guard
from published_figure import PDF

DIGEST="91cbb7022d1b89083074c5be130f3887bf2513b0d1ab637b27fee552c09fd37e"

def crossing(path,xpos):
    values=[]
    for item in path["items"]:
        assert item[0]=="l"
        start,end=item[1:]
        if (start.x<=xpos<end.x) or (end.x<=xpos<start.x):
            values.append(start.y+(end.y-start.y)*(xpos-start.x)/(end.x-start.x))
    return sorted(values)


def lookup(page,paths,component,side,radius):
    offset=0 if component=="ar" else 404
    panel=paths[offset+1]["rect"]
    xticks=[paths[offset+ix]["items"][0][1].x for ix in range(6,11)]
    yticks=[paths[offset+ix]["items"][0][1].y for ix in (32,34,36)]
    xscale=np.polyfit(range(6,11),xticks,1)
    yvalues=[-3.,-2.,-1.] if component=="ar" else [-1.,0.,1.]
    yscale=np.polyfit(yticks,yvalues,1)
    assert max(abs(np.polyval(xscale,range(6,11))-xticks))<.0001
    assert max(abs(np.polyval(yscale,yticks)-yvalues))<.00001
    xpos=np.polyval(xscale,radius)
    if not panel.x0<xpos<panel.x1:
        return None
    center,inner,outer=[paths[offset+idx] for idx in ((66,2,3) if side=="north" else (67,4,5))]
    assert abs(inner["fill_opacity"]-.4)<1e-6 and abs(outer["fill_opacity"]-.2)<1e-6
    assert np.allclose(inner["fill"],outer["fill"])
    assert (center["color"][0]>center["color"][2])==(side=="north")
    middle,=crossing(center,xpos)
    first=crossing(inner,xpos); second=crossing(outer,xpos)
    assert len(first)==len(second)==2 and panel.y0<middle<panel.y1
    assert second[0]<first[0]<middle<first[1]<second[1]
    pix=page.get_pixmap(matrix=pymupdf.Matrix(10,10),clip=pymupdf.Rect(xpos-1,middle-1,xpos+1,middle+1),alpha=False)
    pixels=np.frombuffer(pix.samples,np.uint8).reshape(pix.height,pix.width,3)/255.
    distance=np.min(np.linalg.norm(pixels-np.array(center["color"]),axis=2))
    assert distance<.08,(component,side,radius,distance)
    middle_value=np.polyval(yscale,middle)
    low,high=sorted(np.polyval(yscale,first))
    lo2,hi2=sorted(np.polyval(yscale,second))
    return dict(center=middle_value,lo68=low,hi68=high,lo95=lo2,hi95=hi2,
                line_vs_band_midpoint=middle_value-(low+high)/2,render_rgb_error=distance)


def run():
    guard()
    assert sha(HOME/PDF)==DIGEST
    forecasts=read("gaia-spherical-forecast.csv")
    rows=[];observed={}
    with pymupdf.open(HOME/PDF) as doc:
        page=doc[14]
        paths=page.get_drawings()
        assert "Figure 9. Accelerations" in page.get_text() and len(paths)==1202
        for row in forecasts:
            side="north" if float(row["z_kpc"])>0 else "south"
            radius=float(row["r_kpc"])
            if row["inside_nominal_3kpc"]!="True":
                assert float(row["R_kpc"])==12.
                continue
            for component in ("atheta","ar"):
                key=(radius,side,component)
                if key not in observed:
                    observed[key]=lookup(page,paths,component,side,radius)
                point=observed[key]
                assert point is not None
                value=float(row[component+"_in_1em10_m_s2"])
                residual=value-point["center"]
                width=(point["hi68"]-point["center"]) if residual>0 else (point["center"]-point["lo68"])
                rows.append(dict(case=row["case"],model=row["model"],R_cylinder_kpc=row["R_kpc"],z_kpc=row["z_kpc"],r_spherical_kpc=radius,side=side,
                                 component=component,predicted=value,**point,residual=residual,pointwise_widths=residual/width,
                                 in_inner_band=point["lo68"]<=value<=point["hi68"],in_outer_band=point["lo95"]<=value<=point["hi95"]))
    assert len(observed)==8 and len(rows)==32
    table("gaia-figure9-comparison.csv",rows)
    print("Verified 8 unique curve reads at two sites and both heights; no joint score.")


if __name__=="__main__":
    run()

