from io_stage import HOME, PRIOR, guard, read, table, sha, json
import sys
sys.path.insert(0,str(PRIOR))
from height import Map, HEIGHT, OLD, SUN, G, np
from scipy.special import beta, k0, ndtr, roots_legendre
from functools import lru_cache

Z_SUN=.0208
LIGHT=299792.458
CAP=4*np.pi*G/LIGHT**2
ANGLE=np.deg2rad(29.4)
AXES=np.array([.67,.29,.27])
VOLUME=np.pi/2*beta(.25,1.5)*np.prod(AXES)
BAR_NORM=3*VOLUME*np.pi/2
CLASSES=("living","wd","ns","bh")


def selected():
    centres=[line.split() for line in (HOME/"ogle4-fields.dat").read_text().splitlines() if line.startswith("BLG")]
    names={row[0] for row in centres if abs((float(row[3])+180)%360-180)<=3 and 2<=abs(float(row[4]))<=5}
    tracer=np.loadtxt(HOME/"ogle3-structure.dat")
    assert tracer.shape==(9019,16) and len(centres)==121 and len(names)==22
    selected_rows=[]
    for line in (HOME/"ogle4-subfields.dat").read_text().splitlines():
        if not line.startswith("BLG"):
            continue
        name,ra,dec,lon,lat,_,_,bright,number=line.split()
        if name.split(".")[0] not in names or int(number)<=0:
            continue
        rah=float(ra)/15
        dec=float(dec)
        index=np.flatnonzero((tracer[:,2]<=rah)&(rah<tracer[:,3])&(tracer[:,4]<=dec)&(dec<tracer[:,5]))
        match=tracer[index[0]] if len(index)==1 else None
        code="unique" if len(index)==1 else "outside" if not len(index) else "overlap"
        if match is not None:
            separation=np.hypot((float(lon)-match[0]+180)%360-180,float(lat)-match[1])
            assert separation<.55
            if match[8]<=0:
                code="nonpositive_variance"
        selected_rows.append(dict(subfield=name,field=name.split(".")[0],ra=float(ra),dec=dec,lon=(float(lon)+180)%360-180,lat=float(lat),
                                  N21=int(number),N18=int(bright),rc_status=code,rc_row=int(index[0])+1 if len(index)==1 else "",
                                  mu=match[7] if match is not None else "",variance=match[8] if match is not None else ""))
    assert len(selected_rows)==len({row["subfield"] for row in selected_rows})==697
    return selected_rows


def sphere_roots(radius,centre,minimum_squared,speed):
    delta=radius*radius-minimum_squared
    if delta<0:
        return ()
    half=np.sqrt(delta)
    return ((centre-half)/speed,(centre+half)/speed)


class Ray:
    def __init__(self,lon,lat):
        lon,lat=np.deg2rad([lon,lat])
        self.coslon,self.sinlon=np.cos(lon),np.sin(lon)
        self.coslat,self.sinlat=np.cos(lat),np.sin(lat)
        self.centre=SUN*self.coslon
        self.tangent=self.centre/self.coslat
        self.minimum_squared=(SUN*self.sinlon)**2
    def xyz(self,dist):
        horiz=dist*self.coslat
        return (SUN-horiz*self.coslon,horiz*self.sinlon,Z_SUN+dist*self.sinlat)
    def cylindrical(self,radius):
        return sphere_roots(radius,self.centre,self.minimum_squared,self.coslat)
    def spherical(self,radius):
        centre=self.centre*self.coslat-Z_SUN*self.sinlat
        return sphere_roots(radius,centre,SUN**2+Z_SUN**2-centre**2,1.)


@lru_cache(maxsize=4)
def quadrature(order):
    points,weights=roots_legendre(order)
    phase=(points+1)*np.pi/2
    return .5*(1-np.cos(phase)),np.pi/4*np.sin(phase)*weights


class Lenses:
    def __init__(self):
        self.profile=Map()
        self.stars=self.profile.stars
        nodes,weights=roots_legendre(8)
        edges=self.stars.bgrid
        radius=(edges[:-1,None]+edges[1:,None]+np.diff(edges)[:,None]*nodes)/2
        self.central=np.einsum("ij,ijk,ij->k",2*np.pi*radius,self.stars.bulge_sigma(radius)*1e6,np.diff(edges)[:,None]*weights/2)
        assert np.all(self.central>0) and abs(sum(self.central)/self.stars.bmass-1)<1e-11
        self.radial_edges=np.unique(np.r_[self.stars.knots,self.profile.cuts,4.,7.])
    def density(self,ray,dist):
        xpos,ypos,zpos=ray.xyz(dist)
        cyl=np.hypot(xpos,ypos)
        radius=np.hypot(cyl,zpos)
        disk=self.stars.radial(cyl)*(np.exp(-abs(zpos)[:,None]/HEIGHT)/(2*HEIGHT)@self.stars.mix.T)
        thin=self.profile.heights(cyl)[0]
        disk[:,0]+=self.profile.column(cyl)*(np.exp(-abs(zpos)/thin)/(2*thin)-np.exp(-abs(zpos)/OLD)/(2*OLD))
        upper=np.arccosh(np.maximum(1,self.stars.bgrid[1:]/radius[:,None]))
        lower=np.arccosh(np.maximum(1,self.stars.bgrid[:-1]/radius[:,None]))
        spherical=-(upper-lower)@self.stars.bgradient*(1e6/np.pi)
        major=(xpos*np.cos(ANGLE)+ypos*np.sin(ANGLE))/AXES[0]
        minor=(-xpos*np.sin(ANGLE)+ypos*np.cos(ANGLE))/AXES[1]
        shape=((major**2+minor**2)**2+(zpos/AXES[2])**4)**.25
        bar=k0(shape)[:,None]*self.central/BAR_NORM
        return np.column_stack((disk,spherical,bar)),cyl
    def grid(self,ray,order,discrete,cutoff):
        edges=list(np.arange(0,cutoff,.5))+[cutoff,ray.tangent,*discrete]
        if ray.sinlat:
            edges.append(-Z_SUN/ray.sinlat)
        for radius in self.radial_edges:
            edges.extend(ray.cylindrical(radius))
        for radius in self.stars.bgrid:
            edges.extend(ray.spherical(radius))
        edges=np.unique(np.clip(edges,0,cutoff))
        points,weights=quadrature(order)
        return ((edges[:-1,None]+np.diff(edges)[:,None]*points).ravel(),(np.diff(edges)[:,None]*weights).ravel())


def source(row):
    planes={f"plane{dist}":float(dist) for dist in (6,8,10)}
    if row["rc_status"]!="unique":
        return planes,None
    mean=(row["mu"]-10)*np.log(10)/5
    spread=np.sqrt(row["variance"])*np.log(10)/5
    return planes,(mean,spread)


def windows(dist,planes,modulus):
    result={name:np.maximum(1-dist/val,0.) for name,val in planes.items()}
    if modulus is not None:
        mean,spread=modulus
        crit=(mean-np.log(dist))/spread
        result["rc_gaussian"]=np.maximum(0.,ndtr(crit)-dist*np.exp(-mean+.5*spread**2)*ndtr(crit-spread))
        result["rc_twopoint"]=.5*(np.maximum(1-dist/np.exp(mean-spread),0.)+np.maximum(1-dist/np.exp(mean+spread),0.))
    return result


def evaluate(lenses,row,order):
    ray=Ray(row["lon"],row["lat"])
    planes,modulus=source(row)
    extra=list(planes.values())
    if modulus is not None:
        extra.extend(np.exp(modulus[0]+np.arange(-8.,9.)*modulus[1]))
    dist,weight=lenses.grid(ray,order,extra,52.)
    densities,cyl=lenses.density(ray,dist)
    assert densities.min()>=-1e-6 and np.isfinite(densities).all()
    mask=(cyl>=4)&(cyl<=7)
    near=mask&(dist<ray.tangent)
    far=mask&~near
    results=[]
    for name,window in windows(dist,planes,modulus).items():
        measure=weight*dist*window
        weighted=CAP*measure
        total=weighted@densities
        annulus=(weighted*mask)@densities
        near_mass=(weighted*near)@densities
        if name.startswith("plane"):
            assert abs(measure.sum()/(planes[name]**2/6)-1)<1e-10
        for geometry,central in (("spherical",slice(4,8)),("bar",slice(8,12))):
            physical=total[:4]+total[central]
            within=annulus[:4]+annulus[central]
            front=near_mass[:4].sum()+near_mass[central].sum()
            results.append(dict(subfield=row["subfield"],field=row["field"],source=name,central=geometry,N21=row["N21"],
                tau=physical.sum(),tau_annulus=within.sum(),tau_near_annulus=front,tau_far_annulus=within.sum()-front,
                tau_disk=total[:4].sum(),tau_central=total[central].sum(),geom_annulus_fraction=measure[mask].sum()/measure.sum(),
                annulus_fraction=within.sum()/physical.sum(),tau_annular_disk_living=annulus[0],
                **{"tau_"+kind:value for kind,value in zip(CLASSES,physical,strict=True)}))
    return results


def run(level):
    guard()
    order={"base":10,"fine":18}[level]
    matches=selected()
    table("sightlines.csv",matches)
    lenses=Lenses()
    results=[item for match in matches for item in evaluate(lenses,match,order)]
    table(level+"-subfield-kernels.csv",results)
    print(level,len(results),"kernels for",len(matches),"survey subfield centres",flush=True)


if __name__=="__main__":
    run(sys.argv[1])
