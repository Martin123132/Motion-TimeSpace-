from dual_probe import *
from types import SimpleNamespace
from height import Run
from pair import Sector


def check(count,degree,source_grid):
    guard()
    run=Run("main",count,degree)
    system=run.sys
    exp=SimpleNamespace(run=run,system=system)
    level="fine"
    fixed_pot,fixed_vir=StellarPotential("mass-spherical-fine").mesh(run.rad,system.mu)
    changed,changed_vir=potential(exp,level,"pooled")
    system.ext=run.ext+fixed_pot/system.vel**2+changed
    system.vir=run.work+fixed_vir/system.vel**2+changed_vir
    with np.load(PRIOR/"fine-pooled-matched-state.npz") as pkt:
        saved=pkt["state"]
        state=np.zeros_like(system.kin)
        state[:saved.shape[0],:saved.shape[1]]=saved
        anchor=float(pkt["force"][run.anchor,0])
        base_mass=system.mass=float(pkt["mass"])
    for iteration in range(6):
        lin=polish(system,state.copy())
        state=lin.state
        diff=run.mass_force(state)-anchor
        if abs(diff)<1e-8:
            break
        tangent=lin.differentiate("mass")[0]
        step=-diff/run.mass_force(state,tangent)
        system.mass*=np.exp(step)
        state=state+step*tangent
    else:
        raise RuntimeError("reference state anchor")
    direct=data(HOME/"fine-annulus.csv")[0]
    profile=Lenses().profile
    pot,_,_,mass_quad=source_field(profile,exp,source_grid)
    deriv=lin.constrained(-lin.read(lin.wave*pot))
    slope=lin.differentiate("mass")[0]
    rate=-(float(direct["anchor_direct"])+run.mass_force(state,deriv))/run.mass_force(state,slope)
    prior=[row for row in data(HOME/"fine-force-tangents.csv") if row["model"]=="ground"]
    rr=np.array(sorted({float(row["R"]) for row in prior}))
    readout=Readout(system,Sector(system,12,2),np.column_stack((-rr,np.zeros_like(rr),np.full_like(rr,1.1))))
    values=[]
    for mode,delta in (("fixed",deriv),("matched",deriv+rate*slope)):
        induced=-readout.field("ground",state,delta)[:,2]/(2*np.pi*G*1e6)
        for radius,value in zip(rr,induced,strict=True):
            old=next(row for row in prior if float(row["R"])==radius and row["norm"]==mode)
            values.append(dict(norm=mode,R=radius,induced=value,baseline=float(old["induced"]),total=float(old["direct"])+value))
    name=f"refined-{count}-{degree}-{source_grid}"
    table(name+".csv",values)
    table(name+"-reference.csv",[dict(count=count,degree=degree,source_grid=source_grid,base_mass_ratio=system.mass/base_mass,
        annular_monopole=mass_quad,log_number_rate=rate,nonlinear_residual=np.linalg.norm(lin.resid)/(np.sqrt(system.mass)*abs(lin.chemical)),
        matched_anchor_error=diff)])
    print(name,"max absolute change in induced force",max(abs(row["induced"]-row["baseline"]) for row in values),flush=True)


if __name__=="__main__":
    check(int(sys.argv[1]),int(sys.argv[2]),sys.argv[3])
