from distance_bounds import annular_atoms,curve
from kernel import Lenses,HOME,read,np,guard,selected,table


def minimum(coef,lower,upper):
    ends=np.minimum(coef[0]+lower*(coef[1]+coef[2]*lower),coef[0]+upper*(coef[1]+coef[2]*upper))
    if coef[2]>0:
        turn=-coef[1]/(2*coef[2])
        return np.where((turn>lower)&(turn<upper),coef[0]+turn*(coef[1]+coef[2]*turn),ends)
    return ends


def run():
    guard()
    lenses=Lenses()
    rows={row["subfield"]:row for row in selected()}
    tracer=np.loadtxt(HOME/"ogle3-structure.dat")
    catalogue={line.split()[0]:line.split() for line in (HOME/"ogle4-subfields.dat").read_text().splitlines() if line.startswith("BLG")}
    bounds=read("rc-distribution-free-bounds.csv")
    checked=[]
    for bound in bounds:
        row=rows[bound["subfield"]]
        source=tracer[row["rc_row"]-1]
        area_deg2=source[6]
        rc_per_deg2=source[9]/area_deg2
        current=catalogue[row["subfield"]]
        ccd_deg2=float(current[8])/float(current[6])/3600
        assert .04<ccd_deg2<.055 and rc_per_deg2>0
        pts=np.linspace(5.,20.,6001)
        position=10**((pts-10)/5)
        low,high=annular_atoms(lenses,row,.05,18)
        mu,var=row["mu"],row["variance"]
        dmean,dvar=source[10:12]
        assert mu==source[7] and var==source[8] and min(dmean,dvar)>0
        upper,lower=[np.array([float(bound[sign+"_c"+str(i)]) for i in range(3)]) for sign in ("upper","lower")]
        xx=pts-mu
        upper_slack=minimum(upper,xx[:-1],xx[1:])-curve(high,position)[1:]
        lower_slack=minimum(-lower,xx[:-1],xx[1:])+curve(low,position)[:-1]
        assert min(upper_slack)>-1e-9 and min(lower_slack)>-1e-9
        assert upper[2]>=0 and lower[2]<=0
        for sign,coef in ((1,upper),(-1,lower)):
            assert sign*(coef[1]+2*coef[2]*xx[0])<=0 and sign*(coef[1]+2*coef[2]*xx[-1])>=0
        assert upper[0]+xx[-1]*(upper[1]+upper[2]*xx[-1]) >= sum(high[1])-1e-9
        assert lower[0]+xx[0]*(lower[1]+lower[2]*xx[0]) <= 1e-9
        wide=[]
        for coef,maximize in ((lower,False),(upper,True)):
            values=[coef[0]+coef[1]*offset+coef[2]*(width+offset**2)
                    for offset in (-dmean,dmean) for width in (max(0.,var-dvar),var+dvar)]
            wide.append(max(values) if maximize else min(values))
        assert wide[0]<=float(bound["lower_micro"]) and wide[1]>=float(bound["upper_micro"])
        checked.append(dict(subfield=row["subfield"],N21=row["N21"],conditional_RC_weight=rc_per_deg2*ccd_deg2,mu_error=dmean,
            variance_error=dvar,minimum_lower_slack_micro=min(lower_slack),minimum_upper_slack_micro=min(upper_slack),
            lower=float(bound["lower_micro"]),upper=float(bound["upper_micro"]),moment_box_lower=max(0,wide[0]),moment_box_upper=wide[1]))
    table("source-moment-controls.csv",checked)
    summary=[]
    for key in ("N21","conditional_RC_weight"):
        weights=np.array([row[key] for row in checked])
        summary.append(dict(weighting=key,**{label:np.average([row[label] for row in checked],weights=weights)
                          for label in ("lower","upper","moment_box_lower","moment_box_upper")}))
    table("source-moment-sensitivity.csv",summary)
    print(summary,flush=True)


if __name__=="__main__":
    run()
