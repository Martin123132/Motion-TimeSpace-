from io_stage import HOME, PRIOR, PIN, SRCS, guard, json, put, read, sha, table
from collections import defaultdict
from math import fsum, isfinite, pi, sqrt
import argparse
import numpy as np

TOL=2e-5


def indexed(rows,keys):
    values={tuple(row[k] for k in keys):row for row in rows}
    assert len(values)==len(rows)
    return values


def avg(rows,key):
    return fsum(float(r[key])*int(r["N21"]) for r in rows)/sum(int(r["N21"]) for r in rows)


def close(val,truth,rtol=2e-11,atol=1e-14):
    assert abs(val-truth)<=atol+rtol*abs(truth),(val,truth)


def audit(mode):
    guard()
    parents=json.loads((PRIOR/"seal.json").read_text())
    for foldername,digest in parents["parents"].items():
        folder=HOME.parent/foldername
        assert sha(folder/"seal.json")==digest
        assert all(sha(folder/name)==sig for name,sig in json.loads((folder/"seal.json").read_text())["files"].items())
    assert all(sha(PRIOR/name)==sig for name,sig in parents["files"].items())
    receipts=json.loads((HOME/"sources.json").read_text())
    assert set(receipts)==set(SRCS)
    for name,ref in receipts.items():
        assert sha(HOME/name)==ref["sha256"] and SRCS[name][0]==ref["url"] and (HOME/name).stat().st_size==ref["bytes"]
    footprint=read("sightlines.csv")
    assert len(footprint)==697 and len(set(r["field"] for r in footprint))==22
    selected={r["subfield"]:r for r in footprint}
    tracers={r["subfield"]:r for r in footprint if r["rc_status"]=="unique"}
    assert len(tracers)==291 and sum(int(r["N21"]) for r in tracers.values())==111273824
    kerkeys=("subfield","source","central")
    base=indexed(read("base-subfield-kernels.csv"),kerkeys)
    fine=indexed(read("fine-subfield-kernels.csv"),kerkeys)
    assert set(fine)==set(base) and len(fine)==5346
    resolution=[]
    def compare(label,values,norm="relative",enforce=True):
        errors=[abs(coarse-high)/(max(1.,abs(high)) if norm=="scaled" else max(1e-28,abs(high))) for coarse,high in values]
        maxerr=max(errors)
        resolution.append(dict(test=label,n=len(errors),norm=norm,maximum=maxerr,outside=sum(e>=TOL for e in errors),required=enforce))
        if enforce:
            assert maxerr<TOL,(label,maxerr)
    for name in ("tau","tau_annulus","tau_annular_disk_living","tau_disk","tau_central","tau_living","tau_wd","tau_ns","tau_bh"):
        compare("light "+name,[(float(base[k][name]),float(r[name])) for k,r in fine.items()])
    aggregate=defaultdict(list)
    for key,row in fine.items():
        assert key[0] in selected and row["N21"]==selected[key[0]]["N21"]
        if key[1].startswith("rc_"):
            assert key[0] in tracers
        total=float(row["tau"])
        assert 0<float(row["tau_annulus"])<=total
        close(total,fsum(float(row["tau_"+s]) for s in ("living","wd","ns","bh")),atol=1e-20)
        close(total,float(row["tau_disk"])+float(row["tau_central"]),atol=1e-20)
        close(float(row["tau_annulus"]),float(row["tau_near_annulus"])+float(row["tau_far_annulus"]),atol=1e-20)
        close(float(row["annulus_fraction"]),float(row["tau_annulus"])/total)
        close(float(row["tau_annular_disk_living"]),float(fine[(key[0],key[1],"spherical")]["tau_annular_disk_living"]),atol=1e-22)
        for field in ("ALL",row["field"]):
            aggregate[field,key[1],key[2]].append(row)
    annmass=float(read("fine-annulus.csv")[0]["mass"])
    grouped=[]
    for (field,source,geom),rows in sorted(aggregate.items()):
        if field=="ALL":
            assert len(rows)==(291 if source.startswith("rc_") else 697)
        total=avg(rows,"tau")
        annulus=avg(rows,"tau_annulus")
        grouped.append(dict(field=field,source=source,central=geom,n=len(rows),N21=sum(int(r["N21"]) for r in rows),
            tau_micro=1e6*total,annulus_micro=1e6*annulus,annulus_share=annulus/total,central_micro=1e6*avg(rows,"tau_central"),
            living_ring_micro=1e6*avg(rows,"tau_annular_disk_living"),micro_per_billion=1e15*avg(rows,"tau_annular_disk_living")/annmass))
    table("weighted-kernels.csv",grouped)
    bounded=read("rc-distribution-free-bounds.csv")
    assert {r["subfield"] for r in bounded}==set(tracers) and len(bounded)==len(tracers)
    for row in bounded:
        for s in ("rc_gaussian","rc_twopoint"):
            target=float(fine[row["subfield"],s,"bar"]["tau_annular_disk_living"])*1e6
            assert float(row["lower_micro"])<=target<=float(row["upper_micro"])
        var=float(row["variance"])
        for side in ("lower","upper"):
            close(float(row[side+"_micro"]),float(row[side+"_c0"])+var*float(row[side+"_c2"]))
        assert float(row["lower_micro"])<=float(row["achievable_low_upper_micro"])
        assert float(row["achievable_high_lower_micro"])<=float(row["upper_micro"])
    independent=read("source-moment-controls.csv")
    assert len(independent)==len(tracers) and {r["subfield"] for r in independent}==set(tracers)
    for row in independent:
        assert min(float(row[name]) for name in ("minimum_lower_slack_micro","minimum_upper_slack_micro"))>=-1e-9
        assert 0<=float(row["moment_box_lower"])<=float(row["lower"])<=float(row["upper"])<=float(row["moment_box_upper"])
    for row in read("source-moment-sensitivity.csv"):
        weights=np.array([float(r[row["weighting"]]) for r in independent])
        for name in ("lower","upper","moment_box_lower","moment_box_upper"):
            close(float(row[name]),np.average([float(r[name]) for r in independent],weights=weights))
    nulls=read("distance-null-control.csv")
    for row in nulls:
        first,last=float(row["ring_only_depth"]),float(row["outside_ring_depth"])
        if float(row["source_kpc"])>=6:
            close(first,last,atol=1e-22)
        else:
            assert abs(first-last)>1e-10
    light=read("weyl-characteristic-check.csv")
    assert len(light)==7 and float(light[-1]["relative_error"])<TOL
    central=read("bar-volume-control.csv")[0]
    close(float(central["analytic"]),float(central["cylindrical_numeric"]),1e-10)
    forcekeys=("model","norm","FeH","alpha")
    old,new=(indexed(read(level+"-force-tangents.csv"),forcekeys) for level in ("medium","fine"))
    assert len(old)==len(new)==172 and set(old)==set(new)
    for name in ("direct","induced","total"):
        compare("dynamics "+name,[(float(old[k][name]),float(row[name])) for k,row in new.items()],"scaled",name!="induced")
    nonlinear=indexed(read("medium-nonlinear.csv"),("norm","step","R"))
    for frac in (1/128,1/256):
        pairs=[]
        for k,row in old.items():
            if k[0]!="ground":
                continue
            center=lambda step:float(nonlinear[k[1],str(step),row["R"]]["change"])
            slope=(center(frac)-center(-frac))/(2*frac)
            pairs.append((slope,float(row["total"])))
        compare("nonlinear +/- "+str(frac),pairs,"scaled")
    modes=[("384-32-medium","512-32-fine"),("512-32-fine","512-40-fine"),("512-40-fine","640-40-fine")]
    high={}
    for tag in {tag for test in modes for tag in test}:
        high[tag]=indexed(read("refined-"+tag+".csv"),("norm","R"))
    for left,right in modes:
        compare(left+" vs "+right+" induced",[(float(r["induced"]),float(high[right][k]["induced"])) for k,r in high[left].items()],"scaled",left!="384-32-medium")
    top=high["640-40-fine"]
    summary=[]
    for model in ("ground","nfw"):
        for norm in ("matched","fixed"):
            subs=[r for r in new.values() if r["model"]==model and r["norm"]==norm and float(r["R"])<6.5]
            assert len(subs)==14
            final=np.mean([float(top[norm,r["R"]]["total"] if model=="ground" else r["total"]) for r in subs])
            per=final*1e9/annmass
            lower,upper=[avg(bounded,name)*1e9/annmass for name in ("lower_micro","upper_micro")]
            summary.append(dict(model=model,norm=norm,n=len(subs),Kforce_per_billion=per,
                measured_mean=np.mean([float(r["observed"]) for r in subs]),model_mean=np.mean([float(r["base"]) for r in subs]),
                ideal_RC_micro_per_billion_lower=lower,ideal_RC_micro_per_billion_upper=upper,
                micro_per_Kforce_lower=lower/per,micro_per_Kforce_upper=upper/per))
    table("light-force-response.csv",summary)
    table("resolution.csv",resolution)
    for case in resolution:
        print(case["test"],case["maximum"],case["outside"],flush=True)
    for path in HOME.glob("*.csv"):
        rows=read(path.name)
        assert rows and all(None not in row and None not in row.values() and not any(x.lower() in ("nan","inf","-inf") for x in row.values()) for row in rows),path
    if mode!="check":
        assert all((HOME/name).is_file() for name in ("LIGHT-COUPLING.md","DERIVATION.md","RESULTS.md","NEXT.md","REPLAY.md"))
        assert all(path.is_file() for path in HOME.iterdir())
        sources=[next(HOME.parent.glob(prefix+"-*.md")) for prefix in ("4931","4932","5211")]
        sources.append(HOME.parent/"MTS-HEAVY-BATH-COUNTERFLOW-AND-GALACTIC-STRESS.md")
        manifest=dict(parent=PIN,authorities={path.name:sha(path) for path in sources},
                      files={p.name:sha(p) for p in sorted(HOME.iterdir()) if p.name!="seal.json"})
        if mode=="seal":
            put("seal.json",(json.dumps(manifest,indent=2,sort_keys=True)+"\n").encode())
        assert json.loads((HOME/"seal.json").read_text())==manifest
        print("verified",len(manifest["files"]),sha(HOME/"seal.json"))


if __name__=="__main__":
    parser=argparse.ArgumentParser()
    parser.add_argument("mode",choices=("check","seal","replay"))
    audit(parser.parse_args().mode)
