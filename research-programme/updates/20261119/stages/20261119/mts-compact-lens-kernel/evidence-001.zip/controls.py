from kernel import Lenses, Ray, CLASSES, G, CAP, AXES, BAR_NORM, SUN, np, guard, selected, source, windows, table, k0
from scipy.integrate import quad
from scipy.constants import parsec
from math import erf, exp, cos, sin, pi, sqrt


def run():
    guard()
    lenses=Lenses()
    direct=4*pi*np.prod(AXES)*quad(lambda theta:sin(theta)*quad(lambda rad:rad**2*k0(rad*(sin(theta)**4+cos(theta)**4)**.25),0,np.inf,epsabs=2e-11)[0],
                                  0,pi/2,epsabs=2e-11)[0]
    assert abs(direct/BAR_NORM-1)<1e-10
    rows=selected()
    coverage=[]
    cases=[row for row in rows if row["rc_status"]=="unique"]
    for row in (cases[0],min(cases,key=lambda row:row["variance"]),max(cases,key=lambda row:row["variance"])):
        _,(mean,spread)=source(row)
        for lens in (1.,3.,6.,8.,10.,13.):
            test=windows(np.array([lens]),{},(mean,spread))["rc_gaussian"][0]
            zcut=(np.log(lens)-mean)/spread
            actual=quad(lambda coord:(1-lens*np.exp(-mean-spread*coord))*np.exp(-coord**2/2)/np.sqrt(2*pi),
                        max(zcut,-12),12,epsabs=2e-13)[0] if zcut<12 else 0.
            assert abs(actual-test)<3e-12
            coverage.append(dict(subfield=row["subfield"],lens_kpc=lens,closed=test,integrated=actual))
    table("source-window-controls.csv",coverage)
    ray=Ray(cases[0]["lon"],cases[0]["lat"])
    centres=np.array([.70,2.50,5.05]);width=.15
    xpos,ypos,_=ray.xyz(centres)
    rad=np.hypot(xpos,ypos)
    assert rad[0]>7 and 4<rad[1]<7 and rad[2]<4
    first=centres
    second=centres**2+width**2/12
    factor=np.linalg.solve(np.stack([first[[0,2]],second[[0,2]]]),np.array([first[1],second[1]]))
    assert min(factor)>0
    examples=[]
    for dist in (1.5,3.,4.,6.,8.,10.,14.):
        def depth(centre):
            lower=centre-width/2
            upper=min(dist,centre+width/2)
            return 0. if upper<=lower else CAP*1e6/width*quad(lambda pos:pos*(1-pos/dist),lower,upper)[0]
        each=np.array([depth(val) for val in centres])
        inner=each[1];elsewhere=each[[0,2]]@factor
        if dist>=6:
            assert abs(inner/elsewhere-1)<2e-13
        else:
            assert abs(inner-elsewhere)>1e-10
        examples.append(dict(subfield=cases[0]["subfield"],source_kpc=dist,ring_only_depth=inner,
            outside_ring_depth=elsewhere,near_slab_column=factor[0],middle_slab_column=1.,far_slab_column=factor[1]))
    table("distance-null-control.csv",examples)
    table("bar-volume-control.csv",[dict(analytic=BAR_NORM,cylindrical_numeric=direct,mass_solar=sum(lenses.central),
        **dict(zip(CLASSES,lenses.central,strict=True)))])
    print("independent central mass normalization, geometry and source controls passed",flush=True)


if __name__=="__main__":
    run()
