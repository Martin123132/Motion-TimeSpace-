from kernel import Lenses, CLASSES, HEIGHT, OLD, SUN, HOME, PRIOR, G, np, table, guard, quadrature
from height import Experiment, StellarPotential, TOL, OUTER, Wave, grid, roots_legendre, ellipkm1, ellipe, legvander, data
from solve_height import potential
from pair import Readout, Linearization, polish
from scipy.interpolate import CubicHermiteSpline
from io_stage import put
import csv
import io
import sys


def sigma(profile,radius):
    return profile.stars.radial(radius)[...,0]


def vertical(profile,radius,absolute_z):
    curve=profile.curves[0]
    clip=lambda value:np.clip(value,0.,1.)**2*(3-2*np.clip(value,0.,1.))
    height=OLD*(1+clip(radius-3.5)*clip((SUN-radius)/(SUN-7.25))*(np.interp(radius,curve[:,0],curve[:,1])/np.interp(SUN,curve[:,0],curve[:,1])-1))
    thin,thick=profile.stars.mix[0]
    return thin*np.exp(-absolute_z/height)/(2*height)+thick*np.exp(-absolute_z/HEIGHT[1])/(2*HEIGHT[1])


def sky_ring(profile,observer,zobs,level):
    nr,nz=(10,20) if level=="medium" else (16,32)
    bounds=np.unique(np.clip(np.r_[4.,7.,profile.cuts,observer],4,7))
    pts,ws=roots_legendre(nr)
    unit=(1+pts)/2
    rad,weight=grid(bounds,nr)
    for idx,(left,right) in enumerate(zip(bounds[:-1],bounds[1:])):
        if observer in (left,right):
            rad[idx]=observer+(1 if left==observer else -1)*(right-left)*unit**3
            weight[idx]=1.5*(right-left)*unit**2*ws
    rad=rad.ravel()[:,None]
    weight=weight.ravel()[:,None]
    pts,ws=roots_legendre(nz)
    zcuts=np.unique(np.r_[-28.,-12.,-6.,-2.,-.6,-.15,0.,.15,.6,2.,6.,12.,28.,zobs])
    sep=abs(observer-rad)
    limits=np.arcsinh((zcuts-zobs)/sep)
    half=np.diff(limits,axis=1)/2
    param=(limits[:,:-1,None]+half[:,:,None]*(1+pts)).reshape(len(rad),-1)
    dz=sep*np.sinh(param)
    measure=(half[:,:,None]*ws).reshape(len(rad),-1)*sep*np.cosh(param)
    small=(observer-rad)**2+dz**2
    large=(observer+rad)**2+dz**2
    ratio=small/large
    ellk,elle=ellipkm1(ratio),ellipe(1-ratio)
    coeff=2*G*rad*weight*measure*vertical(profile,rad,abs(zobs+dz))*sigma(profile,rad[:,0])[:,None]/np.sqrt(large)
    return np.array([(coeff/observer*(ellk+((observer-rad)*(observer+rad)-dz**2)/small*elle)).sum(),
                     (2*coeff*dz/small*elle).sum()])


def source_field(profile,exp,level):
    dx,nang,order,lmax=(.075,26,8,64) if level=="medium" else (.045,40,10,80)
    breaks=np.unique(np.clip(np.r_[4.,7.,profile.cuts],4,7))
    edges=np.unique(np.r_[np.arange(0,12.,dx),np.arange(12.,28.,.25),28.,32.,breaks])
    points,weights=quadrature(order)
    radii=edges[:-1,None]+np.diff(edges)[:,None]*points
    wr=np.diff(edges)[:,None]*weights
    modes=np.arange(0,lmax+1,2)
    moments=np.zeros((radii.size,len(modes)))
    flat=radii.ravel()
    angles,aw=roots_legendre(nang)
    for inner,outer in zip(breaks[:-1],breaks[1:]):
        idx=np.flatnonzero(flat>inner)
        rad=flat[idx,None]
        low=np.sqrt(np.maximum(0.,1-(outer/rad)**2))
        high=np.sqrt(1-(inner/rad)**2)
        half=(high-low)/2
        mu=low+half*(1+angles)
        cyl=rad*np.sqrt(1-mu**2)
        den=sigma(profile,cyl)*vertical(profile,cyl,rad*mu)
        for start in range(0,len(idx),100):
            sec=slice(start,start+100)
            pol=legvander(mu[sec],lmax)[...,::2]
            moments[idx[sec]]+=np.einsum("ij,ijk->ik",den[sec]*half[sec]*aw,pol)
    wave=Wave(edges,radii,wr,modes,moments)
    radius,weights=grid(breaks,12)
    mass=2*np.pi*np.sum(weights*radius*sigma(profile,radius))
    assert abs(wave.mass/mass-1)<2e-6,(wave.mass,mass)
    actual=exp.run.rad
    values=wave.spline(np.minimum(actual,edges[-1]))
    slope=wave.spline(np.minimum(actual,edges[-1]),1)
    outside=actual>edges[-1]
    values[outside]=wave.phi[-1]*(edges[-1]/actual[outside,None])**(modes+1)
    slope[outside]=-(modes+1)*values[outside]/actual[outside,None]
    proj=legvander(exp.system.mu,lmax)[:,::2].T
    return values@proj/exp.system.vel**2,actual[:,None]*(slope@proj)/exp.system.vel**2,mass,wave.mass


def run(level):
    guard()
    exp=Experiment(level,32,2)
    system=exp.system
    profile=Lenses().profile
    prev=data(PRIOR/(level+"-SEGUE-comparison.csv"))
    cases=[row for row in prev if row["R0"]==str(SUN) and row["model"]=="ground" and row["height_source"]=="pooled" and row["mode"]=="matched"]
    assert len(cases)==43
    rr=np.unique([float(row["R"]) for row in cases])
    points=np.column_stack((-rr,np.zeros(len(rr)),np.full(len(rr),1.1)))
    readout=Readout(system,exp.sector,points)
    up,dvir=potential(exp,level,"pooled")
    system.ext=exp.ext+up
    system.vir=exp.run.work+StellarPotential("mass-spherical-"+level).mesh(exp.run.rad,system.mu)[1]/system.vel**2+dvir
    base_pot=system.ext.copy()
    base_vir=system.vir.copy()
    with np.load(PRIOR/(level+"-pooled-matched-state.npz")) as pkt:
        state=pkt["state"]
        mass=system.mass=float(pkt["mass"])
    lin=Linearization(system,state)
    assert np.linalg.norm(lin.resid)/(np.sqrt(mass)*abs(lin.chemical))<3e-13
    derivative,virial,ann_mass,monopole=source_field(profile,exp,level)
    dark0=readout.field("ground",state)[:,2]
    ordinary=np.array([sky_ring(profile,cyl,1.1,level)[1] for cyl in rr])
    anchor=sky_ring(profile,OUTER,0.,level)[0]
    dstate=lin.constrained(-lin.read(lin.wave*derivative))
    dmass=lin.differentiate("mass")[0]
    debt=anchor+exp.run.mass_force(state,dstate)
    mass_rate=-debt/exp.run.mass_force(state,dmass)
    states={"fixed":dstate,"matched":dstate+mass_rate*dmass}
    assert abs(np.sum(state*dstate))<1e-10 and abs(exp.run.mass_force(state,states["matched"])+anchor)<1e-8
    factors=data(PRIOR/(level+"-solutions.csv"))
    fac=float(next(row["amplitude_ratio"] for row in factors if row["profile"]=="pooled" and row["model"]=="nfw" and row["mode"]=="matched"))
    fnfw=fac*exp.halo[exp.run.anchor,0]
    ledger=data(PRIOR/(level+"-SEGUE-frozen-forces.csv"))
    lookup={(float(row["R"]),row["model"]):row for row in ledger if row["height_source"]=="pooled" and row["mode"]=="matched"}
    borrowed=np.array([float(lookup[cyl,"ground"]["dark"]) for cyl in rr])
    assert np.max(abs(dark0-borrowed)/np.maximum(1,abs(borrowed)))<2e-8
    halo=np.array([float(lookup[cyl,"nfw"]["dark"]) for cyl in rr])
    forecasts=[]
    conv=-1/(2*np.pi*G*1e6)
    tangents={mode:readout.field("ground",state,change)[:,2] for mode,change in states.items()}
    for mode in states:
        for model,addition,rate in (("ground",tangents[mode],mass_rate),("nfw",-halo*anchor/fnfw if mode=="matched" else 0.*halo,-anchor/fnfw)):
            for item in cases:
                radius=float(item["R"]);idx=np.searchsorted(rr,radius)
                response=conv*(ordinary[idx]+addition[idx])
                forecasts.append(dict(model=model,norm=mode,FeH=item["FeH"],alpha=item["alphaFe"],R=radius,observed=item["observed"],
                    base=lookup[radius,model]["Kforce_equiv"],direct=conv*ordinary[idx],induced=conv*addition[idx],
                    total=response,per_billion=response*1e9/ann_mass,log_amplitude_rate=rate if mode=="matched" else 0.))
    table(level+"-force-tangents.csv",forecasts)
    table(level+"-annulus.csv",[dict(mass=ann_mass,poisson_monopole=monopole,anchor_direct=anchor,anchor_fixed_total=debt,
                                    wave_log_mass_rate=mass_rate,halo_log_amp_rate=-anchor/fnfw)])
    if level=="medium":
        actual=[]
        for mode,change in states.items():
            for step in (-1/128,1/128,-1/256,1/256):
                guard()
                system.ext=base_pot+step*derivative
                system.vir=base_vir+step*virial
                system.mass=mass*np.exp(step*mass_rate if mode=="matched" else 0.)
                trial=state+step*change
                for iteration in range(6):
                    new=polish(system,trial.copy())
                    newstate=new.state
                    defect=exp.run.mass_force(newstate)-exp.run.mass_force(state)+step*anchor
                    if mode=="fixed" or abs(defect)<1e-9:
                        break
                    delta=new.differentiate("mass")[0]
                    log_step=-defect/exp.run.mass_force(newstate,delta)
                    system.mass*=np.exp(log_step)
                    trial=newstate+log_step*delta
                else:
                    raise RuntimeError("outer condition")
                deltaforce=conv*(readout.field("ground",newstate)[:,2]-dark0+step*ordinary)
                for radius,diff in zip(rr,deltaforce,strict=True):
                    actual.append(dict(norm=mode,step=step,R=radius,change=diff,mass_ratio=system.mass/mass,outer_defect=defect))
        table(level+"-nonlinear.csv",actual)
    print(level,"annular living mass",ann_mass,"monopole",monopole,"fixed/matched response checked",flush=True)


if __name__=="__main__":
    run(sys.argv[1])
