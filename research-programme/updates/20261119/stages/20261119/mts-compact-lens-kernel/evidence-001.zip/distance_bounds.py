from kernel import CAP, HOME, Lenses, Ray, guard, np, quadrature, selected, table
from scipy.optimize import OptimizeWarning, linprog
import warnings
import sys


def linear(*args,**kwargs):
    with warnings.catch_warnings():
        warnings.filterwarnings("ignore",message="Unrecognized options detected:.*threads",category=OptimizeWarning)
        return linprog(*args,method="highs",options={"threads":1,"dual_feasibility_tolerance":1e-9,"primal_feasibility_tolerance":1e-9},**kwargs)


def annular_atoms(lenses,row,step,order):
    ray=Ray(row["lon"],row["lat"])
    end=max(ray.cylindrical(7))
    edges=[*np.arange(0,end,step),end,ray.tangent]
    for radius in lenses.radial_edges:
        edges.extend(ray.cylindrical(radius))
    if ray.sinlat:
        edges.append(-.0208/ray.sinlat)
    edges=np.unique(np.clip(edges,0,end))
    inside=lambda radius: (radius>=4)&(radius<=7)
    middle=(edges[:-1]+edges[1:])/2
    xpos,ypos,_=ray.xyz(middle)
    keep=inside(np.hypot(xpos,ypos))
    left,right=edges[:-1][keep],edges[1:][keep]
    points,weights=quadrature(order)
    dist=left[:,None]+(right-left)[:,None]*points
    dens=lenses.density(ray,dist.ravel())[0][:,0].reshape(dist.shape)
    integ=1e6*CAP*dens*dist*weights*(right-left)[:,None]
    mass=integ.sum(axis=1)
    assert np.all(mass>0)
    avg=(integ*dist).sum(axis=1)/mass
    frac=np.clip((avg-left)/(right-left),0,1)
    return (avg,mass),(np.r_[left,right],np.r_[mass*(1-frac),mass*frac])


def curve(atoms,sources):
    location,weight=atoms
    order=np.argsort(location)
    location,weight=location[order],weight[order]
    end=np.searchsorted(location,sources)
    return np.r_[0.,np.cumsum(weight)][end]-np.r_[0.,np.cumsum(weight*location)][end]/sources


def sandwich(lenses,row,spacing,step,order):
    low_atoms,high_atoms=annular_atoms(lenses,row,step,order)
    mean,var=row["mu"],row["variance"]
    pts=np.linspace(5.,20.,1+round(15/spacing))
    source=10**((pts-10)/5)
    lo,hi=curve(low_atoms,source),curve(high_atoms,source)
    upper_limit=sum(high_atoms[1])
    assert min(hi-lo)>-1e-11 and np.all(np.diff(lo)>=-1e-12) and np.all(np.diff(hi)>=-1e-12)
    xx=pts-mean
    left,right=xx[:-1],xx[1:]
    features=lambda first,second,product:np.stack((first,second,product),axis=1)
    one=np.ones_like(left)
    basis=np.vstack((features(one,left,left**2),features(one,(left+right)/2,left*right),features(one,right,right**2),
                     [1,xx[0],xx[0]**2],[1,xx[-1],xx[-1]**2],[0,-1,-2*xx[0]],[0,1,2*xx[-1]],[0,0,1]))
    upper=np.r_[np.tile(hi[1:],3),hi[0],upper_limit,0.,0.,0.]
    lower=np.r_[np.tile(lo[:-1],3),0.,lo[-1],0.,0.,0.]
    objective=np.array([1.,0.,var])
    coefficients=[]
    for sign,limits in ((1,upper),(-1,lower)):
        sol=linear(sign*objective,A_ub=-sign*basis,b_ub=-sign*limits,bounds=[(None,None)]*3)
        assert sol.success,sol.message
        coef=sol.x.copy()
        assert min(sign*(basis@coef-limits))>-2e-8
        coef[2]+=sign*2e-9
        coef[0]+=sign*(max(0,max(-sign*(basis[:-3]@coef-limits[:-3])))+5e-12)
        assert min(sign*(basis[:-3]@coef-limits[:-3]))>=-1e-12
        assert min(sign*(basis[-3:]@coef))>=0
        coefficients.append(coef)
    upper_bound,lower_bound=[float(objective@coef) for coef in coefficients]
    equality=np.stack((np.ones_like(xx),xx,xx**2))
    primal=[]
    for sign,test in ((1,hi),(-1,lo)):
        sol=linear(sign*test,A_eq=equality,b_eq=objective,bounds=(0,None))
        assert sol.success and max(abs(equality@sol.x-objective))<2e-7
        primal.append(sign*float(sol.fun))
    assert lower_bound<=primal[0]+1e-9 and primal[1]<=upper_bound+1e-9
    return dict(subfield=row["subfield"],field=row["field"],N21=row["N21"],mu=mean,variance=var,
        lower_micro=lower_bound,achievable_low_upper_micro=primal[0],achievable_high_lower_micro=primal[1],upper_micro=upper_bound,
        empty_source=0.,infinite_source_micro=upper_limit,max_atom_sandwich_micro=max(hi-lo),
        **{side+str(i):val for side,coef in zip(("upper_c","lower_c"),coefficients,strict=True) for i,val in enumerate(coef)})


def run():
    guard()
    lenses=Lenses()
    results=[sandwich(lenses,row,.0125,.10,12) for row in selected() if row["rc_status"]=="unique"]
    table("rc-distribution-free-bounds.csv",results)
    print("continuous moment bounds",len(results),flush=True)


if __name__=="__main__":
    run()
