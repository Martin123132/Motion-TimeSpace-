import csv
import hashlib
import io
import json
import os
from pathlib import Path
import urllib.request

HOME=Path(__file__).resolve().parent
PRIOR=HOME.parent/"mts-inner-stellar-height-response-20261119"
PIN="745c599231fd0a7f1a24565bcb95798f5a0f5d241f09308d88ae367cc7c0a6a7"
SRCS={
    "ogle4-subfields.dat":("https://www.astrouw.edu.pl/ogle/ogle4/microlensing_maps/table5.dat",400000),
    "ogle4-fields.dat":("https://www.astrouw.edu.pl/ogle/ogle4/microlensing_maps/table6.dat",12000),
    "ogle3-structure.dat":("https://ftp.astrouw.edu.pl/ogle/ogle3/ext/blg/Table4.dat",3500000),
    "ogle3-readme.txt":("https://ftp.astrouw.edu.pl/ogle/ogle3/ext/blg/README.txt",10000)}
for label in ("OMP_NUM_THREADS","MKL_NUM_THREADS","OPENBLAS_NUM_THREADS","NUMEXPR_NUM_THREADS","BLIS_NUM_THREADS"):
    os.environ[label]="1"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def guard():
    assert not any((folder/"STOP-REQUESTED").exists() for folder in (HOME,PRIOR,HOME.parent))
    assert sha(PRIOR/"seal.json")==PIN


def put(name,payload):
    guard()
    path=HOME/name
    if path.exists():
        assert path.read_bytes()==payload,name
    else:
        with path.open("xb") as handle:
            handle.write(payload)


def table(name,rows):
    stream=io.StringIO(newline="")
    writer=csv.DictWriter(stream,fieldnames=list(rows[0]),lineterminator="\n")
    writer.writeheader()
    writer.writerows(rows)
    put(name,stream.getvalue().encode())


def read(name):
    with (HOME/name).open(newline="",encoding="utf8") as handle:
        return list(csv.DictReader(handle))


def ingest():
    receipt={}
    for name,(url,limit) in SRCS.items():
        if not (HOME/name).exists():
            with urllib.request.urlopen(url,timeout=25) as response:
                payload=response.read(limit+1)
            assert 1000<len(payload)<=limit and b"<html" not in payload[:500].lower(),name
            put(name,payload)
        receipt[name]=dict(url=url,bytes=(HOME/name).stat().st_size,sha256=sha(HOME/name))
    put("sources.json",(json.dumps(receipt,indent=2,sort_keys=True)+"\n").encode())


if __name__=="__main__":
    ingest()
