from io_stage import guard, table
import mpmath as mp
import numpy as np
from scipy.integrate import quad
from scipy.constants import parsec, astronomical_unit

mp.mp.dps=44


def bending(mass,coupling,side):
    def angular(inv_r):
        ratio=(1-8*coupling*mass*inv_r**3)/(1+16*coupling*mass*inv_r**3)
        return ratio**side
    near=mp.findroot(lambda rad:rad**2-(1-2*mass/rad)*angular(1/rad),1)
    def integrand(theta):
        sine=mp.sin(theta)
        inv=sine/near
        weight=angular(inv)
        return mp.cos(theta)*weight/mp.sqrt(1-inv**2*(1-2*mass*inv)*weight)
    return 2/near*mp.quadgl(integrand,[0,mp.pi/2])-mp.pi


def run():
    guard()
    checks=[]
    for parameter in (mp.mpf("1e-5"),mp.mpf("-1e-5"),mp.mpf("1e-8")):
        for transverse,other,side in ((2,-1,1),(-1,2,-1)):
            spatial=-other
            speed2=(1-8*parameter*spatial)/(1+8*parameter*transverse)
            exact=((1-8*parameter)/(1+16*parameter))**side
            assert abs(speed2-exact)<mp.mpf("1e-39")
        low=mp.sqrt((1-8*parameter)/(1+16*parameter))
        split=abs((1/low-low)/parameter)
        checks.append(dict(type="tangential phase-speed split",test=float(parameter),value=float(split),leading=24.,
                           relative_error=float(abs(split/24-1))))
    for ratio in ("0.001","0.0001","0.00001","0.000001"):
        mass=mp.mpf(ratio)
        coupling=mp.mpf(".001")
        first=bending(mass,coupling,1)
        second=bending(mass,coupling,-1)
        measured=abs((first-second)/(2*coupling*4*mass))
        checks.append(dict(type="fixed impact deflection",test=float(mass),value=float(measured),leading=8.,relative_error=float(abs(measured/8-1))))
    assert checks[-1]["relative_error"]<2e-5 and all(checks[k]["relative_error"]<checks[k-1]["relative_error"] for k in range(4,7))
    table("weyl-characteristic-check.csv",checks)
    nominal_gmsun=1.3271244e20
    data=[]
    for mass in (.1,1.,10.):
        for lens,source in ((2.,8.),(4.,8.),(6.,10.)):
            eff=lens*(1-lens/source)*1000*parsec
            ein2=4*mass*nominal_gmsun/(299792458.**2)*eff
            data.append(dict(mass_msun=mass,lens_kpc=lens,source_kpc=source,einstein_AU=np.sqrt(ein2)/astronomical_unit,
                minimum_speed_for_300d_kms=np.sqrt(ein2)/(300*86400*1000),
                abs_parent_fraction=8*7.221914138634598e-72/ein2,abs_electron_fraction=8*9.621568578321357e-31/ein2))
    table("isolated-lens-scales.csv",data)


if __name__=="__main__":
    run()
