from bar_io import HERE,guard,read,put,table
from kernel import G,AXES,ANGLE,BAR_NORM,Lenses
import io,sys
import numpy as np
from scipy.special import gammaln,lpmv,k0,roots_legendre
from scipy.interpolate import CubicHermiteSpline
from feasibility import UNIT

SETTINGS={"base":(20,182,40,40),"fine":(32,286,56,56),"extra":(44,418,72,72)}
def angular(degree,mode,mu):
    norm=np.sqrt(2*degree+1)*np.exp((gammaln(degree-mode+1)-gammaln(degree+mode+1))/2)
    return norm*lpmv(mode,degree,mu)
def slope(degree,mode,mu):
    if degree==0:return np.zeros_like(mu)
    norm=np.sqrt(2*degree+1)*np.exp((gammaln(degree-mode+1)-gammaln(degree+mode+1))/2)
    prev=lpmv(mode,degree-1,mu) if degree>mode else 0.
    return norm*((degree+mode)*prev-degree*mu*lpmv(mode,degree,mu))/(1-mu**2)

def build(level):
    guard();ellmax,count,nmu,nphi=SETTINGS[level]
    edges=np.unique(np.r_[0.,np.geomspace(.0001,60.,count),np.hypot([6.,8.3],1.5)])
    points,weights=roots_legendre(6)
    radii=edges[:-1,None]+np.diff(edges)[:,None]*(points+1)/2;wr=np.diff(edges)[:,None]*weights/2
    mu,aw=roots_legendre(nmu);mu=(mu+1)/2;aw/=2
    phi,pw=roots_legendre(nphi);phi=(phi+1)*np.pi/4;pw/=2
    tags=[(ell,mode) for ell in range(0,ellmax+1,2) for mode in range(0,min(ell,32 if level=="extra" else 16)+1,2)]
    deg,mode=np.array(tags).T
    q=(((1-mu[:,None]**2)*(np.cos(phi)**2/AXES[0]**2+np.sin(phi)**2/AXES[1]**2))**2+(mu[:,None]/AXES[2])**4)**.25
    mass=sum(Lenses().central)
    flat=radii.ravel();coef=np.zeros((len(flat),len(tags)))
    for begin in range(0,len(flat),32):
        sl=slice(begin,begin+32);density=mass/BAR_NORM*k0(flat[sl,None,None]*q)
        for az in np.unique(mode):
            idx=np.where(mode==az)[0]
            harmonics=np.column_stack([angular(ell,az,mu) for ell in deg[idx]])
            coef[sl,idx]=(density@(pw*np.cos(az*phi)))@(aw[:,None]*harmonics)
    coeff=coef.reshape(*radii.shape,-1);interior=np.zeros((len(edges),len(tags)));exterior=np.zeros_like(interior)
    rr=radii[:,:,None];factor=-4*np.pi*G/(2*deg+1)
    for idx in range(len(edges)-1):
        low,high=edges[idx:idx+2]
        interior[idx+1]=interior[idx]*(low/high)**(deg+1)+np.sum(wr[idx,:,None]*rr[idx]**2/high*(rr[idx]/high)**deg*coeff[idx],axis=0)
    for idx in range(len(edges)-2,-1,-1):
        low,high=edges[idx:idx+2]
        exterior[idx]=exterior[idx+1]*(low/high)**deg+np.sum(wr[idx,:,None]*rr[idx]*(low/rr[idx])**deg*coeff[idx],axis=0)
    val=(interior+exterior)*factor
    dr=np.zeros_like(val);dr[1:]=(exterior[1:]*deg-interior[1:]*(deg+1))*factor/edges[1:,None]
    err=abs(-val[-1,0]*edges[-1]/(G*mass)-1)
    delta=mass/BAR_NORM*2*np.pi*np.prod(AXES)*(AXES[0]**2-AXES[1]**2)*(9*np.pi/2)
    quadr=np.where((deg==2)&(mode==2))[0][0]
    qerr=abs(val[-1,quadr]*angular(2,2,0.)*edges[-1]**3/(-3*G*delta/8)-1)
    assert max(err,qerr)<1e-9,(err,qerr)
    stream=io.BytesIO();np.savez_compressed(stream,r=edges,l=deg,m=mode,potential=val,derivative=dr,mass=mass)
    put("bar-"+level+".npz",stream.getvalue())
    table("source-"+level+".csv",[dict(mass_solar=mass,mass_relative_error=err,quadrupole_relative_error=qerr,quadrupole_xx_minus_yy=delta)])
class Field:
    def __init__(self,level):
        with np.load(HERE/("bar-"+level+".npz")) as data:
            self.r,self.deg,self.mode,self.val,self.der,self.mass=[data[k] for k in ("r","l","m","potential","derivative","mass")]
        self.spline=CubicHermiteSpline(self.r,self.val,self.der,axis=0)
    def harmonics(self,radii):
        radii=np.atleast_1d(radii);end=self.r[-1]
        vals=self.spline(np.minimum(end,radii));slopes=self.spline(np.minimum(end,radii),1)
        beyond=radii>end
        vals[beyond]=self.val[-1]*(end/radii[beyond,None])**(self.deg+1)
        slopes[beyond]=-(self.deg+1)*vals[beyond]/radii[beyond,None]
        return vals,slopes
    def grid(self,radii,mu,mode):
        vals,dr=self.harmonics(radii);idx=self.mode==mode
        harm=np.stack([angular(ell,mode,mu) for ell in self.deg[idx]])
        return vals[:,idx]@harm,dr[:,idx]@harm
    def at(self,cyl,z,alpha):
        rad=np.hypot(cyl,z);mu=z/rad;sine=cyl/rad
        pot,dr=self.harmonics([rad]);harm=np.array([angular(ell,az,mu) for ell,az in zip(self.deg,self.mode)])
        deriv=np.array([slope(ell,az,mu) for ell,az in zip(self.deg,self.mode)])
        ans=[]
        for az in np.unique(self.mode):
            mask=self.mode==az;mult=1 if az==0 else 2
            amp=float(pot[0,mask]@harm[mask])
            ans.append(dict(m=int(az),potential=mult*np.cos(az*alpha)*amp,radial=-mult*np.cos(az*alpha)*(dr[0,mask]@harm[mask])*UNIT,
                            polar=mult*np.cos(az*alpha)*(pot[0,mask]@deriv[mask])*sine/rad*UNIT,
                            azimuthal=mult*az*np.sin(az*alpha)*amp/(rad*sine)*UNIT))
        return ans
if __name__=="__main__":build(sys.argv[1])
