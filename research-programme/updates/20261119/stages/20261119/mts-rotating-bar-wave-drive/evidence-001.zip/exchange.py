from bar_io import table
from bar_field import angular
import numpy as np
from scipy.interpolate import CubicSpline
from scipy.integrate import cumulative_simpson

def budget(prefix,grid,solution,logder,force,mix,channels,physical,live,escape,mode,pattern):
    positive=solution[:,:channels];negative=solution[:,channels:2*channels];gravity=solution[:,2*channels:]
    velocity=float(physical["vel"]);length=float(physical["length"])
    kappa=length*velocity;energy=float(physical["energy"])
    orders=mode+2*np.arange(channels)
    spline=CubicSpline(grid,solution,axis=0)
    derivatives=spline(grid,1)
    derivatives[-1,:2*channels]=logder*solution[-1,:2*channels]
    derivatives[-1,2*channels:]=-orders/grid[-1]*gravity[-1]
    currents=(solution.conj()*derivatives).imag.reshape(len(grid),3,channels).sum(axis=2)
    number=currents[:,0]-currents[:,1]
    angular_current=currents[:,0]+currents[:,1]+(2*currents[:,2] if live else 0.)
    potential=force+(np.einsum("rij,rj->ri",mix,gravity) if live else 0.)
    drain=2*((positive-negative).conj()*potential).imag.sum(axis=1)
    torque=2*((positive+negative).conj()*force).imag.sum(axis=1)
    integrate=lambda values:cumulative_simpson(values,x=grid,initial=0.)
    drained=integrate(drain);driven=integrate(torque)
    saved=physical["rad"];angular_nodes=physical["mu"]
    harmonics=np.array([angular(degree,mode,angular_nodes) for degree in orders])
    on_saved=spline(saved);plus=on_saved[:,:channels]@harmonics;minus=on_saved[:,channels:2*channels]@harmonics
    field=(on_saved[:,2*channels:]@harmonics)/saved[:,None]
    weights=physical["weights"][:,None]*physical["aw"]*physical["wave"]
    overlap=lambda potential:float(2*np.sum(weights*(potential.conj()*plus+potential*minus.conj()).imag))
    direct=overlap(physical["drive"]);induced=overlap(field) if live else 0.
    residual=abs(direct+induced+escape)/escape
    test_radii=[6.,8.3,17.58,35.,float(physical["edge"])*length,grid[-1]*length]
    rows=[]
    for radius in test_radii:
        at=min(radius/length,grid[-1])
        current,source,ang,work=[float(CubicSpline(grid,values)(at)) for values in (number,drained,angular_current,driven)]
        rows.append(dict(radius_kpc=radius,sideband_number_flux=current,minus_projected_ground_source=source,
                         angular_flux_per_mkappa=ang,integrated_external_torque_per_mkappa=work,
                         number_difference_over_outgoing=(current-source)/escape,torque_difference_over_outgoing=(ang-work)/escape))
    table(prefix+"-shell-exchange.csv",rows)
    fraction=escape/(float(physical["mass"])*length/velocity*.9777922216807892)
    mass_unit=velocity**2*length
    from kernel import G
    lost=fraction*float(physical["mass"])*mass_unit/G
    quantum=mode*kappa*pattern
    summary=dict(m=mode,omega=pattern,source_external_to_ground=direct,source_self_to_ground=induced,
                 total_projection_to_ground=direct+induced,escaping_number=escape,
                 projection_residual_relative=residual,rate_fraction_per_gyr=fraction,escaping_msun_per_gyr=lost,
                 torque_msun_kpc_kms_per_gyr=mode*kappa*lost,pattern_work_msun_kms2_per_gyr=quantum*lost,
                 unbinding_msun_kms2_per_gyr=-energy*lost,asymptotic_kinetic_msun_kms2_per_gyr=(energy+quantum)*lost)
    table(prefix+"-ground-exchange.csv",[summary])
    assert residual<2e-5,summary
    assert max(abs(row[key]) for row in rows for key in ("number_difference_over_outgoing","torque_difference_over_outgoing"))<2e-5,rows

