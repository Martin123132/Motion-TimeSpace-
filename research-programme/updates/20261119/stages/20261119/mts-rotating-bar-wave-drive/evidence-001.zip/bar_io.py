from pathlib import Path
import csv
import hashlib
import io
import json
import os
import sys
for key in ("OMP_NUM_THREADS","MKL_NUM_THREADS","OPENBLAS_NUM_THREADS","NUMEXPR_NUM_THREADS","BLIS_NUM_THREADS"):
    os.environ[key]="1"
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
PRE=HERE.parent/"mts-annular-mass-budget-20261119"
KERNEL=HERE.parent/"mts-compact-lens-kernel-20261119"
HEIGHT=HERE.parent/"mts-inner-stellar-height-response-20261119"
PIN="0ff91acd78470c7e53c4bafb6120eee8ee165b90c622b763450cf0fc740166cf"
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def guard():
    assert sha(PRE/"seal.json")==PIN
    assert not any((p/"STOP-REQUESTED").exists() for p in (HERE,HERE.parent,PRE,KERNEL,HEIGHT))
def put(name,raw):
    guard();file=HERE/name
    if file.exists():assert file.read_bytes()==raw,name
    else:
        with file.open("xb") as stream:stream.write(raw)
def table(name,rows):
    buf=io.StringIO(newline="");out=csv.DictWriter(buf,list(rows[0]),lineterminator="\n")
    out.writeheader();out.writerows(rows);put(name,buf.getvalue().encode())
def write_json(name,obj):put(name,(json.dumps(obj,indent=2,sort_keys=True,allow_nan=False)+"\n").encode())
def read(path):
    with path.open(newline="",encoding="utf8") as data:return list(csv.DictReader(data))
sys.path.insert(0,str(KERNEL))
sys.path.insert(0,str(PRE))
