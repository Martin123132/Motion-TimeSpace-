from bar_io import HERE,PRE,HEIGHT,KERNEL,guard,table,put,read
from bar_field import Field,angular,slope
from finite import prepared
from dual_probe import Lenses,np,potential,StellarPotential,Readout,polish,G,OUTER
from rings import sky_ring,source_field
from gravity import Bulge
from kernel import ANGLE
from feasibility import UNIT,bands
from gas_common import gases
import io,sys

CASES=("reference","added-free2-plus","transfer-free2-plus")
SPEEDS=(31.48,33.29,35.10,38.,41.,44.)
def details(level):
    return ("fine","fine") if level=="base" else ("512-40",level)
def scalar_terms(field,radii,mu,mode):
    pot,rate=field.grid(radii,mu,mode)
    vals,_=field.harmonics(radii);sel=field.mode==mode
    theta=-np.sqrt(1-mu**2)[None,:]*(vals[:,sel]@np.stack([slope(ell,mode,mu) for ell in field.deg[sel]]))
    kinetic=rate**2+(theta**2+mode**2*pot**2/(1-mu**2)[None,:])/radii[:,None]**2
    return pot,kinetic
def run(level,additional=False):
    guard()
    basis_level,bar_level=details(level)
    if level=="base":bar_level="base"
    exp,src_level=prepared(basis_level);system=exp.system
    f=Field(bar_level);lenses=Lenses();bulge=Bulge(lenses.stars)
    rad=exp.run.rad;mu=system.mu
    patch,dpatch=potential(exp,"fine","pooled")
    base=exp.ext+patch
    base_vir=exp.run.work+StellarPotential("mass-spherical-fine").mesh(rad,mu)[1]/system.vel**2+dpatch
    sphere,sphere_der=bulge.at(rad)
    bar,bar_der=f.grid(rad,mu,0)
    diff=(bar-sphere[:,None])/system.vel**2
    dvir=(bar_der-sphere_der[:,None])*rad[:,None]/system.vel**2
    bary_anchor=-f.at(OUTER,0.,0.)[0]["radial"]/UNIT-G*f.mass/OUTER**2
    at_probe=np.array([6.,8.3]);height=1.5;rprobe=np.hypot(at_probe,height)
    reader=Readout(system,exp.sector,np.column_stack([-at_probe,np.zeros(2),np.full(2,height)]))
    kappa=system.length*system.vel
    massunit=system.vel**2*system.length/G
    ids=read(PRE/"independent-budget.csv")
    control=read(HEIGHT/"fine-solutions.csv")
    nfw0=next(row for row in control if (row["mode"],row["model"],row["profile"])==("matched","nfw","pooled"))
    pop=HERE.parent/"mts-population-resolved-gravity-20261119"
    with np.load(pop/"mass-spherical-fine-main-384-32.npz") as pkt:
        nfw=np.asarray(pkt["matched_nfw_force"])*float(nfw0["amplitude_ratio"])
        ordinary=pkt["base"][[-4,-3]].copy()
    with np.load(HEIGHT/"fine-pooled-direct.npz") as pkt:
        ordinary[:,[0,2]]+=pkt["values"][[-4,-3],1:3]
    radial_dir=np.column_stack([-at_probe,np.zeros(2),np.full(2,height)])/rprobe[:,None]*UNIT
    polar_dir=np.column_stack([np.full(2,-height),np.zeros(2),-at_probe])/rprobe[:,None]*UNIT
    assert max(abs(np.sum(nfw[[-4,-3]]*polar_dir,axis=1)))<1e-12
    assert max(abs(np.sum(ordinary*polar_dir,axis=1)-[float(nfw0["polar_6"]),float(nfw0["polar_8.3"])]))<2e-9
    ring_data=[]
    for interval in [(4.,7.),(7.,8.)]:
        ep,vr,*unused=source_field(lenses.profile,exp,"fine",interval)
        forces=np.array([sky_ring(lenses.profile,pos,height,"fine",interval) for pos in at_probe])
        ring_data.append((ep,vr,forces,sky_ring(lenses.profile,OUTER,0.,"fine",interval)[0]))
    vtwo,gradtwo=scalar_terms(f,rad,mu,2)
    measure=system.weights[:,None]*system.aw
    cloud_r=np.array([system.edge,system.edge*2]);acc,cloud_p,_=system.material(cloud_r)
    assert np.allclose(-cloud_r*cloud_p,cloud_r**2*acc,rtol=1e-11)
    cloud_mass=float(cloud_r[0]**2*acc[0]*massunit);gas_mass=sum(g.mass for g in gases())
    skyrows=[];out=[];spec=[];states=[]
    cases=("added-free2-minus","transfer-free2-minus") if additional else CASES
    for case in cases:
        guard()
        if case=="reference":amplitude=donor=mass_change=0.
        else:
            row=next(row for row in ids if row["family"]==case.split("-")[0] and row["width"]=="2" and row["calibration"]=="free" and row["side"]==case.split("-")[-1])
            amplitude,donor,mass_change=(float(row[key]) for key in ("amplitude","donor_per_unit","net_mass_change"))
        ordinary_now=ordinary.copy()
        ordinary_now[:,[0,2]]+=amplitude*(ring_data[0][2]+donor*ring_data[1][2])
        system.ext=base+amplitude*(ring_data[0][0]+donor*ring_data[1][0])
        system.vir=base_vir+amplitude*(ring_data[0][1]+donor*ring_data[1][1])
        with np.load(PRE/("512-40-"+case+".npz")) as pkt:
            original=pkt["state"][:system.kin.shape[0],:system.kin.shape[1]].copy()
            orig_mass=system.mass=float(pkt["mass"])
        start=polish(system,original);original=start.state
        orig_force=exp.run.mass_force(original)
        esphere=start.chemical*system.vel**2
        system.ext=system.ext+diff;system.vir=system.vir+dvir
        trial=original.copy()
        for it in range(8):
            solution=polish(system,trial.copy());state=solution.state
            residual=np.linalg.norm(solution.resid)/(abs(solution.chemical)*np.sqrt(system.mass))
            defect=exp.run.mass_force(state)-orig_force+bary_anchor
            if it==0:fixed=(system.mass,solution.chemical*system.vel**2,defect)
            if abs(defect)<1e-8:break
            response=solution.differentiate("mass")[0]
            step=-defect/exp.run.mass_force(state,response)
            system.mass*=np.exp(step);trial=state+step*response
        else:raise RuntimeError("mean bar outer anchor")
        assert residual<2e-12
        wave=reader.field("ground",state)
        nfw_anchor=nfw[exp.run.anchor,0]
        halo_factor=1-(bary_anchor+amplitude*(ring_data[0][3]+donor*ring_data[1][3]))/nfw_anchor
        assert halo_factor>0
        for idx,radius in enumerate(at_probe):
            components=f.at(radius,height,np.pi-ANGLE)
            for projection,harmonics in [("azimuthal_mean",components[:1]),("measured_orientation",components)]:
                src_rad=sum(h["radial"] for h in harmonics)+G*f.mass/rprobe[idx]**2*UNIT
                src_pol=sum(h["polar"] for h in harmonics)
                bary_r=ordinary_now[idx]@radial_dir[idx]+src_rad;bary_t=ordinary_now[idx]@polar_dir[idx]+src_pol
                for model,field in [("mts",wave[idx]),("nfw",nfw[[-4,-3]][idx]*halo_factor)]:
                    ar=bary_r+field@radial_dir[idx];at=bary_t+field@polar_dir[idx]
                    north=bands()[radius,"atheta","north"];south=bands()[radius,"atheta","south"]
                    lower=max(north[3],-south[4]);upper=min(north[4],-south[3])
                    nr=bands()[radius,"ar","north"];sr=bands()[radius,"ar","south"]
                    skyrows.append(dict(case=case,R=radius,component=projection,model=model,bar_minus_sphere_radial=src_rad,
                        bar_polar=src_pol,ordinary_polar=bary_t,dark_polar=field@polar_dir[idx],total_polar=at,total_radial=ar,
                        polar_lo=lower,polar_hi=upper,radial_lo=max(nr[3],sr[3]),radial_hi=min(nr[4],sr[4]),
                        remaining_polar_lo=lower-at,remaining_polar_hi=upper-at,
                        bar_azimuthal=sum(h["azimuthal"] for h in harmonics)))
        probs=measure*solution.wave**2/system.mass
        assert abs(probs.sum()-1)<3e-12
        strength=float(np.sum(probs*vtwo**2))
        fsum=kappa**2/2*float(np.sum(probs*gradtwo))
        e0=solution.chemical*system.vel**2
        m_wave=system.mass*massunit;mtotal=m_wave+sum(lenses.stars.masses)+mass_change+gas_mass+cloud_mass
        maxacc=4*G*m_wave*(2*G*mtotal/kappa**2)**2*UNIT
        z0=float(np.max(abs(np.sum(wave*polar_dir,axis=1))))
        for omega in SPEEDS:
            quant=2*kappa*omega
            escape=e0+quant
            assert escape>0
            pp=4*strength/escape**2;pm=4*strength/quant**2
            spec.append(dict(case=case,omega=omega,absorbed_specific_energy=quant,final_specific_energy=escape,
                             direct_bound_co_probability_ceiling=pp,direct_bound_counter_probability_ceiling=pm,
                             dephased_bound_mass_msun_at_most=(pp+pm)*m_wave,hardy_unit_population_force=maxacc,
                             angular_change_bound=(pp+pm)*(maxacc+z0),energy_weighted_tail_fraction_limit=min(1.,fsum/(quant*strength))))
        out.append(dict(case=case,kappa=kappa,ground_specific_energy=e0,old_specific_energy=esphere,all_channel_strength_per_sign=strength,
                        rms_complex_m2=np.sqrt(strength),energy_weighted_strength=fsum,mean_gap_of_drive=fsum/strength,
                        dark_mass=m_wave,total_gravitating_mass=mtotal,cloud_mass=cloud_mass,gas_mass=gas_mass,
                        outer_speed_material_delta=bary_anchor,stationary_number_ratio=system.mass/orig_mass,
                        fixed_number_outer_force_defect=fixed[2],fixed_number_energy=fixed[1],outer_force_defect=defect,normalized_residual=residual))
        if level!="base":
            stream=io.BytesIO()
            np.savez_compressed(stream,state=state,mass=system.mass,energy=e0,
                rad=system.rad,weights=system.weights,mu=mu,aw=system.aw,wave=solution.wave,hamiltonian=system.ext+solution.potential,
                drive=vtwo/system.vel**2,edge=system.edge,vel=system.vel,length=system.length)
            put(level+"-"+case+"-mean.npz",stream.getvalue())
        print("Computed",level,case,"binding",round(-e0),"rms",round(np.sqrt(strength),3),flush=True)
    tag=level+("-additional" if additional else "")
    table(tag+"-mean.csv",out);table(tag+"-sky.csv",skyrows);table(tag+"-drive.csv",spec)
if __name__=="__main__":run(sys.argv[1],len(sys.argv)>2 and sys.argv[2]=="additional")
