from bar_io import HERE,guard,table
from bar_field import Field
from kernel import G,AXES,BAR_NORM,ANGLE,Lenses
from feasibility import UNIT
from scipy.special import roots_legendre,k0
import numpy as np
def integrate(cyl,z,phase,order,mass):
    distance=np.hypot(cyl,z);center=np.array([cyl*np.cos(phase),cyl*np.sin(phase),z])
    inward=-center/distance
    az=np.array([-np.sin(phase),np.cos(phase),0])
    polar=np.cross(inward,az)
    assert polar[2]<0
    theta_nodes,theta_weight=roots_legendre(order)
    edges=np.array([0,.015,.045,.11,.24,.5,1.,1.6,2.3,np.pi])
    theta=(edges[:-1,None]+np.diff(edges)[:,None]*(theta_nodes+1)/2).ravel()
    weights=(np.diff(edges)[:,None]*theta_weight/2).ravel()
    azi=2*np.pi*np.arange(8*order)/(8*order)
    around=np.cos(azi)[:,None]*polar+np.sin(azi)[:,None]*az
    total=np.zeros(4)
    for angle,wgt in zip(theta,weights):
        ct,st=np.cos(angle),np.sin(angle)
        dirs=inward*ct+around*st
        impact=distance*st;nearest=distance*ct
        begin=np.arcsinh(-nearest/impact);end=np.arcsinh((72-nearest)/impact)
        sub=np.linspace(begin,end,max(2,int(np.ceil((end-begin)/.65))+1))
        vals=(sub[:-1,None]+np.diff(sub)[:,None]*(theta_nodes+1)/2).ravel()
        w=(np.diff(sub)[:,None]*theta_weight/2).ravel()*impact*np.cosh(vals)
        travel=nearest+impact*np.sinh(vals)
        coords=center[None,None,:]+travel[None,:,None]*dirs[:,None,:]
        xs,ys,zs=(coords/AXES).transpose(2,0,1)
        rho=mass/BAR_NORM*k0(((xs**2+ys**2)**2+zs**4)**.25)
        weight=st*wgt*2*np.pi/len(azi)
        total[0]-=weight*(rho@(w*travel)).sum()
        total[1:]+=weight*((rho@w)@dirs)
    force=G*UNIT*total[1:]
    return dict(potential=G*total[0],radial=force@(-inward),polar=force@polar,azimuthal=force@az)
def run():
    guard();records=[];mass=sum(Lenses().central)
    for radius,vertical,phase in [(6.,1.5,np.pi-ANGLE),(8.3,1.5,np.pi-ANGLE),(2.,.8,.39),(1.,.5,.7)]:
        previous=None
        for order in (12,18):
            value=integrate(radius,vertical,phase,order,mass)
            last=previous;previous=value
        for level in ("base","fine","extra"):
            field=Field(level);harm=field.at(radius,vertical,phase)
            for key,target in value.items():
                estimate=sum(row[key] for row in harm)
                records.append(dict(R=radius,z=vertical,phase_rad=phase,level=level,quantity=key,green_harmonics=estimate,
                                    direct_newton=target,relative_error=abs((estimate-target)/target),direct_order_relative_change=abs((target-last[key])/target)))
    table("independent-direct-gravity.csv",records)
    for item in records:
        if item["level"]=="extra":assert max(item["relative_error"],item["direct_order_relative_change"])<2e-5,item
if __name__=="__main__":run()
