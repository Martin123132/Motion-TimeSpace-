from bar_io import HERE,PRE,guard,read,table,sha,write_json,PIN
from bar_field import Field
import math
import json
from pathlib import Path

TOL=2e-5
CASES=("reference","added-free2-plus","transfer-free2-plus")
FULL=CASES[:2]
def rows(name):return read(HERE/name)
def pack(case,level="far",mode=2,bank="extra",speed=33.29,model="live"):
    tag=(bank+"-bank-" if bank!="fine" else "")+(f"m{mode}-" if mode!=2 else "")+f"{level}-{case}-{speed:g}-{model}"
    return tag,rows(tag+"-checks.csv")[0],rows(tag+"-force.csv")
def value(row,key):return float(row[key])
def polar(row):return complex(value(row,"polar_real"),value(row,"polar_imag"))
def relative(left,right):return abs(left-right)/abs(right) if right!=0 else (0. if left==0 else float("inf"))
def sample(left,right,category):
    _,old,old_force=left;_,new,new_force=right
    errors=[relative(polar(first),polar(second)) for first,second in zip(old_force[:2],new_force[:2])]
    radial=[relative(value(first,"max_radial"),value(second,"max_radial")) for first,second in zip(old_force,new_force)]
    error=relative(value(old,"number_flux"),value(new,"number_flux"))
    return dict(comparison=category,first=left[0],second=right[0],flux_relative=error,
                complex_polar_relative=max(errors),radial_amplitude_relative=max(radial),
                within_original_tolerance=max(error,*errors,*radial)<TOL)
def main():
    guard()
    precursor=json.loads((PRE/"seal.json").read_bytes())["files"]
    assert len(precursor)==73 and all(sha(PRE/name)==digest for name,digest in precursor.items())
    sets=(("pilot","radial"),("radial","angular"),("angular","exterior"),("exterior","high"),("high","far"))
    compare=[sample(pack("reference",left,bank="fine"),pack("reference",right,bank="fine"),"reference refinement") for left,right in sets]
    for case in CASES:
        compare.append(sample(pack(case,"high",bank="fine"),pack(case),"induced m2 source and solver refinement"))
    for speed in (31.48,44.):
        compare.append(sample(pack("reference","high",bank="fine",speed=speed),pack("reference","far",bank="fine",speed=speed),"range ends"))
    for case in FULL:
        for mode in range(2,33,2):compare.append(sample(pack(case,"high",mode),pack(case,"far",mode),"fixed extra source high to far"))
        for mode in (2,4,6,8):compare.append(sample(pack(case,"high",mode),pack(case,"more_angles",mode),"fixed extra source 14 to 18 angular channels"))
    table("paired-refinements.csv",compare)
    modes=[];totals=[];sky=rows("extra-sky.csv");field=Field("extra")
    for case in FULL:
        fine_sums={}
        for level in ("high","far"):
            packets=[pack(case,level,mode) for mode in range(2,33,2)]
            for mode,(tag,metrics,force) in enumerate(packets,1):
                mode*=2
                modes.append(dict(case=case,level=level,m=mode,rate_fraction_per_gyr=value(metrics,"test_mass_fraction_per_gyr"),
                                  polar_at_6=value(force[0],"measured_polar"),peak_at_6=value(force[0],"max_polar"),
                                  local_density_peak_at_6=value(force[0],"max_fractional_density"),
                                  relative_work_flux=value(metrics,"relative_flux_balance"),relative_poisson=value(metrics,"poisson_crosscheck"),
                                  relative_identities_resolved=max(value(metrics,"relative_flux_balance"),value(metrics,"poisson_crosscheck"))<TOL))
                assert abs(value(force[2],"max_polar"))<1e-16
            for idx,radius in enumerate((6.,8.3)):
                direct_cap=sum(abs(item["polar"]) for item in field.at(radius,1.5,0.) if item["m"]>0)
                contributions=[force[idx] for _,_,force in packets]
                combined={key:math.fsum(value(row,key) for row in contributions) for key in (
                    "measured_polar","measured_radial","max_polar","reflected_orientation_polar","max_fractional_density")}
                rate=math.fsum(value(metrics,"test_mass_fraction_per_gyr") for _,metrics,_ in packets)
                if level=="high":
                    fine_sums[radius]=(combined,rate)
                    continue
                old,oldrate=fine_sums[radius]
                for key in combined:assert relative(old[key],combined[key])<TOL,(case,radius,key)
                assert relative(oldrate,rate)<TOL
                for model in ("mts","nfw"):
                    select=lambda kind:next(row for row in sky if (row["case"],float(row["R"]),row["model"],row["component"])==(case,radius,model,kind))
                    measured=select("measured_orientation");mean=select("azimuthal_mean");active=model=="mts"
                    wave=combined["measured_polar"] if active else 0.
                    total=value(measured,"total_polar")+wave
                    upper=value(mean,"total_polar")+direct_cap+(combined["max_polar"] if active else 0.)
                    radial=value(measured,"total_radial")+(combined["measured_radial"] if active else 0.)
                    totals.append(dict(case=case,R_kpc=radius,model=model,matched_ordinary_polar=value(measured,"ordinary_polar"),
                        ground_or_halo_polar=value(measured,"dark_polar"),bar_alone_polar=value(measured,"bar_polar"),induced_sum_polar=wave,
                        polar_measured_direction=total,reflected_direction=value(measured,"total_polar")+(combined["reflected_orientation_polar"] if active else 0.),
                        polar_azimuthal_mean_first_order=value(mean,"total_polar"),polar_phase_upper_bound=upper,
                        polar_lo=value(mean,"polar_lo"),polar_hi=value(mean,"polar_hi"),missing_to_polar_lo=value(mean,"polar_lo")-total,
                        radial_measured_direction=radial,radial_lo=value(mean,"radial_lo"),radial_hi=value(mean,"radial_hi"),
                        matches_polar=value(mean,"polar_lo")<=total<=value(mean,"polar_hi"),matches_radial=value(mean,"radial_lo")<=radial<=value(mean,"radial_hi"),
                        relative_density_modulation_cap=combined["max_fractional_density"] if active else 0.))
    table("retained-harmonic-budget.csv",modes);table("forces-versus-local-data.csv",totals)
    sweep=[]
    for path in sorted(HERE.glob("high-*-live-checks.csv")):
        row=read(path)[0];force=rows(path.name.replace("-checks","-force"));case=row["case"]
        sweep.append(dict(case=case,pattern_speed=row["omega"],energy_open=row["energy_open"],
                          rate_fraction_per_gyr=row["test_mass_fraction_per_gyr"],polar_at_6=force[0]["measured_polar"],
                          polar_at_8p3=force[1]["measured_polar"],peak_polar_at_6=force[0]["max_polar"]))
    assert len(sweep)==26
    table("m2-speed-sensitivity.csv",sweep)
    analytic=max(value(row,"relative_complex_error") for row in rows("analytic-free-wave-control.csv"))
    gravity=max(max(value(row,"relative_error"),value(row,"direct_order_relative_change")) for row in rows("independent-direct-gravity.csv") if row["level"]=="extra")
    local=max(value(read(path)[0],"projection_residual_relative") for path in HERE.glob("*-ground-exchange.csv"))
    assert max(analytic,gravity,local)<TOL
    primary=[row for row in compare if row["comparison"] in ("range ends","induced m2 source and solver refinement")]
    assert all(row["within_original_tolerance"] for row in primary),primary
    assert all(row["polar_phase_upper_bound"]<row["polar_lo"] for row in totals if row["R_kpc"]==6.)
    assert all(row["matches_polar"] for row in totals if row["R_kpc"]==8.3)
    assert all(not row["matches_radial"] for row in totals)
    verification=dict(parent_seal=PIN,parent_files_verified=len(precursor),tolerance=TOL,analytic_green_error=analytic,
        direct_gravity_error=gravity,ground_projection_error=local,paired_refinements=len(compare),
        m2_sampled_background_speed_pairs=len(sweep),source_modes_per_full_case=16,
        fine_harmonics_with_failed_identities=[(row["case"],row["m"]) for row in modes if row["level"]=="far" and not row["relative_identities_resolved"]],
        fixed_source_refinement_failures=[row["second"] for row in compare if row["comparison"]=="fixed extra source high to far" and not row["within_original_tolerance"]],
        angular_refinement_failures=[row["second"] for row in compare if row["comparison"]=="fixed extra source 14 to 18 angular channels" and not row["within_original_tolerance"]],
        external_inputs_fitted_here=False)
    write_json("verification.json",verification)
    print(json.dumps(verification))
if __name__=="__main__":main()

