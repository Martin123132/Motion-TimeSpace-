from bar_io import HERE,PRE,PIN,guard,read,sha,write_json
import json
import sys

def verify(folder,document):
    model=json.loads(document.read_bytes())
    for name,expected in model["files"].items():
        assert sha(folder/name)==expected,name
    return model
def main():
    guard()
    old=verify(PRE,PRE/"seal.json");assert len(old["files"])==73
    mandatory=("PROTOCOL.md","OPEN-CHANNEL.md","HARMONIC-CONTROL.md","DERIVATION.md","RESULTS.md","NEXT.md","REPLAY.md",
               "verification.json","paired-refinements.csv","retained-harmonic-budget.csv","forces-versus-local-data.csv",
               "analytic-free-wave-control.csv","extra-mean.csv","fine-additional-mean.csv","m2-speed-sensitivity.csv",
               "m28-radial-cancellation.csv","m28-refined-green.csv")
    assert all((HERE/name).is_file() for name in mandatory)
    for path in HERE.glob("*.py"):compile(path.read_bytes(),str(path),"exec")
    for path in HERE.glob("*.csv"):
        values=read(path);assert values and all(None not in row and None not in row.values() for row in values),path.name
    for path in HERE.glob("*-checks.csv"):
        force=read(HERE/path.name.replace("-checks.csv","-force.csv"))
        assert [float(row["R"]) for row in force]==[6.,8.3,17.58] and len(read(path))==1
    assert len(list(HERE.glob("*-ground-exchange.csv")))==7
    assert len(read(HERE/"retained-harmonic-budget.csv"))==64
    assert not any(path.is_dir() for path in HERE.iterdir()),"unexpected subdirectory"
    files={path.name:sha(path) for path in sorted(HERE.iterdir()) if path.name!="seal.json"}
    if sys.argv[1:]==["seal"]:write_json("seal.json",dict(files=files,parent=PIN))
    recorded=verify(HERE,HERE/"seal.json")
    assert recorded==dict(files=files,parent=PIN)
    print(len(files),"current and",len(old["files"]),"predecessor files verified; stage seal",sha(HERE/"seal.json"))
if __name__=="__main__":main()

