from bar_io import guard,table
from mts_bar_radial import numerov,tail_factor
import numpy as np
from scipy.integrate import quad
from scipy.interpolate import CubicSpline
from scipy.special import spherical_jn,spherical_yn,spherical_in,spherical_kn

def probe(degree,perunit):
    radius=10.;support=2.7;wavenumber=1.7;decay=1.3
    grid=np.arange(round(radius*perunit)+1)/perunit;step=1/perunit
    bump=lambda rad:rad**(degree+1)*np.maximum(1-(rad/support)**2,0.)**6
    source=np.tile((2*bump(grid))[:,None],(1,2))
    diagonal=degree*(degree+1)/np.maximum(grid,step)**2
    coeff=lambda idx:np.diag([diagonal[idx]-wavenumber**2,diagonal[idx]+decay**2])
    boundary=[tail_factor(degree,energy,0.,radius,step) for energy in (wavenumber**2/2,-decay**2/2)]
    solution=numerov(grid,coeff,source,np.array([pair[0] for pair in boundary]))
    rows=[]
    for branch,scale in enumerate((wavenumber,decay)):
        def regular(rad):
            arg=scale*rad
            return arg*(spherical_jn(degree,arg) if branch==0 else spherical_in(degree,arg))
        def outward(rad):
            arg=scale*rad
            if branch==0:return arg*(-spherical_yn(degree,arg)+1j*spherical_jn(degree,arg))
            return (2/np.pi)*arg*spherical_kn(degree,arg)
        def integral(func,lo,hi):
            if lo>=hi:return 0j
            return quad(lambda rad:float(np.real(func(rad)))*bump(rad),lo,hi,epsabs=1e-14)[0]+1j*quad(lambda rad:float(np.imag(func(rad)))*bump(rad),lo,hi,epsabs=1e-14)[0]
        amplitude=-2/scale*integral(regular,0,support)
        for at in (.49,1.31,2.11,3.53,7.89):
            target=-2/scale*(outward(at)*integral(regular,0,min(at,support))+regular(at)*integral(outward,at,support))
            estimate=CubicSpline(grid,solution[:,branch])(at)
            rows.append(dict(degree=degree,perunit=perunit,channel=("open","closed")[branch],probe=at,
                             expected_real=target.real,expected_imag=target.imag,actual_real=estimate.real,actual_imag=estimate.imag,
                             relative_complex_error=abs(estimate-target)/abs(target)))
        if branch==0:
            predicted=scale*abs(amplitude)**2;computed=abs(solution[-1,branch])**2*boundary[branch][1].imag
            rows.append(dict(degree=degree,perunit=perunit,channel="outgoing_flux",probe=radius,expected_real=predicted,
                             expected_imag=0.,actual_real=computed,actual_imag=0.,relative_complex_error=abs(computed/predicted-1)))
    return rows
if __name__=="__main__":
    guard()
    rows=[row for degree in (2,4) for perunit in (80,160) for row in probe(degree,perunit)]
    assert max(row["relative_complex_error"] for row in rows)<2e-5
    table("analytic-free-wave-control.csv",rows)
    print("max relative error",max(row["relative_complex_error"] for row in rows))

