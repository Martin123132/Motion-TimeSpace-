from bar_io import guard
import mpmath as mp
import numpy as np

def tail_factor(ell,energy,mass,radius,step):
    with mp.workdps(32):
        k=mp.sqrt(2*abs(energy))
        arg=-2j*k if energy>0 else 2*k
        param=1j*mass/k if energy>0 else mass/k
        def wave(rad):return mp.whitw(param,ell+.5,arg*rad)
        end=wave(radius)
        ratio=end/wave(radius-step)
        slope_=mp.diff(wave,radius)/end
    return complex(ratio),complex(slope_)

def numerov(grid,coeff,forcing,boundary):
    h=grid[1]-grid[0];size=forcing.shape[1];ident=np.eye(size)
    transition=np.zeros((len(grid),size,size));part=np.zeros((len(grid),size))
    qs=coeff(1);past=coeff(0);coef=h*h/12
    for idx in range(1,len(grid)-1):
        future=coeff(idx+1);left=ident-coef*past;right=ident-coef*future
        mid=-2*ident-10*coef*qs+left@transition[idx-1]
        rhs=coef*(forcing[idx-1]+10*forcing[idx]+forcing[idx+1])-left@part[idx-1]
        values=np.linalg.solve(mid,np.column_stack([-right,rhs]))
        transition[idx]=values[:,:size];part[idx]=values[:,-1]
        past,qs=qs,future
    solution=np.zeros((len(grid),size),complex)
    solution[-1]=np.linalg.solve(ident-boundary[:,None]*transition[-2],boundary*part[-2])
    for idx in range(len(grid)-2,0,-1):solution[idx]=transition[idx]@solution[idx+1]+part[idx]
    del transition
    return solution

