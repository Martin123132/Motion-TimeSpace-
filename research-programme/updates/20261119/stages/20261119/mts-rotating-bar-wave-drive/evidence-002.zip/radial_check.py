from bar_io import HERE,read,table,guard

def main():
    guard()
    ordinary=read(HERE/"extra-bank-far-reference-33.29-live-radial-green.csv")
    assert max(float(row["relative_difference"]) for row in ordinary)<2e-5
    rows=[]
    for case in ("reference","added-free2-plus"):
        load=lambda level:read(HERE/f"extra-bank-m28-{level}-{case}-33.29-live-radial-green.csv")
        for first,second in zip(load("high"),load("far")):
            number=lambda row,kind:complex(float(row[kind+"_real"]),float(row[kind+"_imag"]))
            fine=number(second,"green");old=number(first,"green")
            derivative=number(second,"spline");prior=number(first,"spline")
            difference=abs(fine-old)/abs(fine)
            rows.append(dict(case=case,R=second["R"],green_harmonic_amplitude=2*abs(fine),
                radial_green_relative_refinement=difference,radial_spline_relative_refinement=abs(derivative-prior)/abs(derivative),
                fine_green_vs_spline_relative=abs(fine-derivative)/abs(fine),
                fine_green_vs_spline_force_amplitude_difference=2*abs(fine-derivative),
                green_refinement_within_original_tolerance=difference<2e-5))
    table("m28-radial-cancellation.csv",rows)
    detailed=[]
    for left,right in (("far","green300"),("green300","green360")):
        load_added=lambda level:read(HERE/f"extra-bank-m28-{level}-added-free2-plus-33.29-live-radial-green.csv")
        for first,second in zip(load_added(left),load_added(right)):
            fine=complex(float(second["green_real"]),float(second["green_imag"]))
            old=complex(float(first["green_real"]),float(first["green_imag"]))
            change=abs(fine-old)/abs(fine)
            detailed.append(dict(first=left,second=right,R=second["R"],amplitude=2*abs(fine),
                relative_refinement=change,absolute_amplitude_difference=2*abs(fine-old),within_original_tolerance=change<2e-5))
    table("m28-refined-green.csv",detailed)
    print("m28 max paired integral change",max(row["radial_green_relative_refinement"] for row in rows),
          "max absolute difference from far spline",max(row["fine_green_vs_spline_force_amplitude_difference"] for row in rows))
if __name__=="__main__":main()

