from bar_io import HERE,guard,put,table,read
from bar_field import Field,angular,slope
from kernel import ANGLE
from feasibility import UNIT
import numpy as np
from scipy.interpolate import CubicSpline
from scipy.integrate import simpson
from scipy.special import roots_legendre
from mts_bar_radial import numerov,tail_factor
import sys
import io

CONFIG={"pilot":(6,80,38.),"radial":(6,160,38.),"angular":(10,160,38.),"exterior":(10,160,48.),
        "high":(14,200,48.),"far":(14,240,60.),"more_angles":(18,200,48.),
        "green300":(14,300,60.),"green360":(14,360,60.)}
def prepare(packet,channels,rgrid,omega,mode):
    rad,mu,aw,background,ham,forcing=[packet[k] for k in ("rad","mu","aw","wave","hamiltonian","drive")]
    edge=float(packet["edge"]);energy=float(packet["energy"])/float(packet["vel"])**2
    orders=mode+2*np.arange(channels)
    ang=np.stack([angular(ell,mode,mu) for ell in orders],axis=1)
    assert np.max(abs(ang.T@(aw[:,None]*ang)-np.eye(channels)))<2e-12
    proj=(aw[:,None,None]*ang[:,:,None]*ang[:,None,:]).reshape(len(mu),-1)
    potential=ham@proj
    coupling=(background/rad[:,None])@proj
    source=(background*forcing)@(aw[:,None]*ang)
    cube=lambda data:CubicSpline(rad,data,axis=0)(np.minimum(rgrid,edge))
    pot=cube(potential).reshape(-1,channels,channels);mix=cube(coupling).reshape(-1,channels,channels)
    drive=cube(source)
    outside=rgrid>=edge
    leg=np.stack([angular(ell,0,mu) for ell in np.arange(0,2*orders[-1]+1,2)],axis=1)
    coefficients=CubicSpline(rad,ham,axis=0)(edge)@(aw[:,None]*leg)
    exterior_coeff=coefficients*(edge/rgrid[outside,None])**np.arange(1,2*orders[-1]+2,2)
    pot[outside]=(exterior_coeff@(leg.T@proj)).reshape(-1,channels,channels)
    drive[outside]=0;mix[outside]=0;drive[0]=0
    return orders,pot,mix,drive,energy,-edge*coefficients[0]
def evaluate(grid,solutions,orders,physical,frequency,case,model,mode):
    channels=len(orders);probes=[]
    spl=CubicSpline(grid,solutions,axis=0)
    bmu=physical["mu"];ground=CubicSpline(physical["rad"],physical["wave"],axis=0)
    for radius in (6.,8.3,17.58):
        height=1.5 if radius!=17.58 else 0.
        dist=np.hypot(radius,height);at=dist/physical["length"];mu=height/dist;sine=radius/dist
        values=spl(at);dvalues=spl(at,1);amp=values[2*channels:]/at
        dr=(dvalues[2*channels:]-amp)/at
        harmonics=np.array([angular(ell,mode,mu) for ell in orders])
        derivatives=np.array([slope(ell,mode,mu) for ell in orders])
        scale=physical["vel"]**2/physical["length"]*UNIT
        polar=amp@derivatives*sine/at*scale
        radial=-dr@harmonics*scale
        az=-mode*1j*(amp@harmonics)/(at*sine)*scale
        u0=float(CubicSpline(bmu,ground(at))(mu))
        phase=np.exp(mode*1j*(np.pi-ANGLE))
        pert=(values[:channels]+values[channels:2*channels])@harmonics
        probes.append(dict(case=case,omega=frequency,model=model,R=radius,polar_real=polar.real,polar_imag=polar.imag,
                          max_polar=2*abs(polar),measured_polar=2*(phase*polar).real,
                          measured_radial=2*(phase*radial).real,measured_azimuthal=2*(phase*az).real,
                          max_radial=2*abs(radial),reflected_orientation_polar=2*(phase.conjugate()*polar).real,
                          max_fractional_density=2*abs(pert/u0)))
    return probes

def run(level,case,frequency,live,mode=2,bank="fine",balance=False,green_radial=False):
    guard()
    channels,perunit,outer=CONFIG[level]
    model="live" if live else "test";prefix=f"{level}-{case}-{frequency:g}-{model}"
    if mode!=2:prefix=f"m{mode}-"+prefix
    if bank!="fine":prefix=bank+"-bank-"+prefix
    grid=np.arange(round(perunit*outer)+1)/perunit;h=1/perunit
    with np.load(HERE/f"{bank}-{case}-mean.npz") as file:
        physical={key:file[key] for key in file.files}
    if mode!=2:physical["drive"]=Field(bank).grid(physical["rad"]*physical["length"],physical["mu"],mode)[0]/physical["vel"]**2
    vel,length,mass,edge=map(float,(physical[k] for k in ("vel","length","mass","edge")))
    omega=mode*length/vel*frequency
    orders,pot,mix,force,energy,monopole=prepare(physical,channels,grid,omega,mode)
    size=3*channels;ident=np.eye(size);eye=np.eye(channels)
    denom=np.maximum(grid,h)**2
    angular_term=orders*(orders+1)/denom[:,None]
    pos=slice(0,channels);neg=slice(channels,2*channels);grav=slice(2*channels,size)
    diag=np.arange(channels)
    def coeff(idx):
        mat=np.zeros((size,size));diagv=angular_term[idx]
        mat[pos,pos]=2*pot[idx];mat[neg,neg]=2*pot[idx]
        mat[diag,diag]+=diagv-2*(energy+omega)
        mat[diag+channels,diag+channels]+=diagv-2*(energy-omega)
        mat[diag+2*channels,diag+2*channels]=diagv
        if live:mat[pos,grav]=2*mix[idx];mat[neg,grav]=2*mix[idx]
        mat[grav,pos]=mix[idx];mat[grav,neg]=mix[idx]
        return mat
    assert energy+omega>0 and energy-omega<0
    boundary=[];logder=[]
    for en in (energy+omega,energy-omega):
        for ell in orders:
            ratio,der=tail_factor(int(ell),en,monopole,outer,h);boundary.append(ratio);logder.append(der)
    boundary=np.r_[boundary,((outer-h)/outer)**orders];logder=np.array(logder)
    assert min(logder[pos].imag)>0 and max(abs(logder[neg].imag))<1e-15
    ledger=bank+("-additional" if case.endswith("minus") else "")+"-mean.csv"
    fluxmass=float(next(row["total_gravitating_mass"] for row in read(HERE/ledger) if row["case"]==case))
    from kernel import G
    assert abs(monopole/(fluxmass*G/(length*vel**2))-1)<2e-5
    forcing=np.column_stack([2*force,2*force,0*force])
    solution=numerov(grid,coeff,forcing,boundary)
    escaping=float(np.sum(abs(solution[-1,pos])**2*logder[pos].imag))
    if balance:
        from exchange import budget
        budget(prefix,grid,solution,logder,force,mix,channels,physical,live,escaping,mode,frequency)
    sourcework=2*simpson(np.sum((solution[:,pos]+solution[:,neg]).conj()*force,axis=1).imag,x=grid)
    tunit=length/vel*.9777922216807892
    density=np.einsum("rij,rj->ri",mix,solution[:,pos]+solution[:,neg])
    dspl=CubicSpline(grid,density,axis=0);wspl=CubicSpline(grid,solution[:,grav],axis=0)
    gx,gw=roots_legendre(5);controls=[];radial_controls=[]
    for cyl,rp in ((6.,np.hypot(6,1.5)),(8.3,np.hypot(8.3,1.5)),(17.58,17.58)):
        at=rp/length;edges=np.unique(np.r_[grid,at])
        rr=(edges[:-1,None]+np.diff(edges)[:,None]*(gx+1)/2).ravel()
        wr=(np.diff(edges)[:,None]*gw/2).ravel()
        kern=np.where(rr[:,None]<at,(rr/at)[:,None]**(orders+1),(at/rr)[:,None]**orders)
        predicted=-(wr[:,None]*dspl(rr)*kern).sum(axis=0)/(2*orders+1)
        actual=wspl(at)/at
        controls.append(np.linalg.norm(predicted-actual)/max(1e-20,np.linalg.norm(actual)))
        if green_radial:
            weighted=wr[:,None]*dspl(rr)*kern
            inner=weighted[rr<at].sum(axis=0);outer_part=weighted[rr>at].sum(axis=0)
            basis=np.array([angular(ell,mode,1.5/rp if cyl!=17.58 else 0.) for ell in orders])
            scale=vel**2/length*UNIT
            green=-scale*((((orders+1)*inner-orders*outer_part)/((2*orders+1)*at))@basis)
            spline_value=-scale*((wspl(at,1)-actual)@basis)/at
            radial_controls.append(dict(R=cyl,mode=mode,green_real=green.real,green_imag=green.imag,
                spline_real=spline_value.real,spline_imag=spline_value.imag,relative_difference=abs(spline_value/green-1)))
    if green_radial:table(prefix+"-radial-green.csv",radial_controls)
    obs=evaluate(grid,solution,orders,physical,frequency,case,model,mode)
    packets=simpson(np.sum(abs(solution[:,:2*channels])**2,axis=1)*(grid*length<=35),x=grid)/mass
    metrics=dict(case=case,omega=frequency,model=model,channels=channels,radial_step_dimless=h,edge_dimless=outer,
                 number_flux=escaping,source_work=sourcework,relative_flux_balance=abs(escaping-sourcework)/escaping,
                 poisson_crosscheck=max(controls),test_mass_fraction_per_gyr=escaping/(tunit*mass),
                 driven_norm_inside_35kpc_per_total=packets,energy_open=(energy+omega)*vel**2,
                 mass_ratio_at_boundary=monopole/(fluxmass*G/(length*vel**2)))
    table(prefix+"-checks.csv",[metrics]);table(prefix+"-force.csv",obs)
    print(prefix, "flux/Gyr",metrics["test_mass_fraction_per_gyr"],"balance",metrics["relative_flux_balance"],"Poisson",max(controls),"polar",obs[0]["measured_polar"],flush=True)
if __name__=="__main__":run(sys.argv[1],sys.argv[2],float(sys.argv[3]),sys.argv[4]=="live",int(sys.argv[5]) if len(sys.argv)>5 else 2,sys.argv[6] if len(sys.argv)>6 else "fine","balance" in sys.argv[7:],"green" in sys.argv[7:])
