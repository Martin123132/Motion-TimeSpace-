from project_io import HERE,OLD,guard,table,encode
from collections import defaultdict,Counter
from datetime import date
import calendar
import gzip
import fitz
import numpy as np
import pandas as pd
import re

def source_inputs():
    with fitz.open(HERE/"hamadache-2004.pdf") as doc:
        def pages(nums):return " ".join(" ".join(doc[i-1].get_text().split()) for i in nums)
        raw=pages([106,107]); prod=pages([83,84])
        form=pages([104])
        assert "2.5*log10(baser)-2.5*positionclump" in form and "2.5*log10(baser/baseb)" in form
        assert "5, 57" in form and "23%" in form and "(6.9)" in form
        assert "1704 jours" in pages([137])
    star=re.findall(r"\b(cg\d{3})\s+(\d+)\s+(\d+)\s+(\d+)\s+(\d+)\s+(\d+)\s+(\d+)\b",raw)
    image=re.findall(r"\b(cg\d{3})\s+(\d+)\s+(\d+)\s+(\d+)\s+(\d+)\s+(\d+)\s+(\d+)\s+(\d+)\s+(\d+)\s+(\w+)\s+(200[12])\b",prod)
    assert len(star)==len(image)==66
    months=dict(mai=5,juillet=7,octobre=10,novembre=11,juin=6,septembre=9,août=8,avril=4,mars=3)
    img={row[0]:row[1:] for row in image}
    rows=[]
    for name,*values in star:
        bright,be,bc,clump,ce,cc=map(int,values)
        visits=img[name];num=[int(v) for v in visits[:8]]
        assert be==bright*50 and ce==clump*50 and max(abs(bc-be*.77),abs(cc-ce*.77))<=1.01
        month=months[visits[8]];year=int(visits[9])
        rows.append(dict(field=name,random_bright_2pct=bright,bright_extrap=be,bright_margin_removed=bc,random_clump_2pct=clump,
                         clump_extrap=ce,clump_margin_removed=cc,total_frames=num[0],**{f"frames_{1996+i}":v for i,v in enumerate(num[1:])},
                         production_end_first=str(date(year,month,1)),production_end_last=str(date(year,month,calendar.monthrange(year,month)[1])),
                         annual_sum_minus_reported=sum(num[1:])-num[0]))
    assert sum(r["clump_margin_removed"] for r in rows)==5574780
    return rows

def images(fields):
    by=defaultdict(dict)
    with gzip.open(OLD/"xtinfo.dat.gz","rt") as f:
        for line in f:
            name=line[:22].strip()
            if name[:5] not in fields:continue
            day=line[98:].strip()[-10:];mjd=float(line[23:34])
            if mjd<=0 or day<"1996-07-01" or day>"2002-10-31" or not 2<=int(day[5:7])<=10:continue
            key=name[:5],name[10:-5]
            camera,chip=map(int,name[5:7])
            if (camera,chip) in by[key]:assert by[key][camera,chip]==(day,mjd)
            by[key][camera,chip]=day,mjd
    seasons=defaultdict(list)
    for (field,_),rec in by.items():
        paired=[chip for chip in range(8) if (0,chip) in rec and (1,chip) in rec]
        if not paired:continue
        days={rec[0,chip][0] for chip in paired};assert len(days)==1
        day=days.pop()
        seasons[field,int(day[:4])].append((day,min(rec[0,chip][1] for chip in paired),len(paired)))
    return seasons

def run():
    guard();data=source_inputs();table("thesis-field-inputs.csv",data)
    fields={r["field"] for r in data};visits=images(fields)
    ref=pd.read_csv(OLD/"field-seasons.csv").set_index(["field","policy","year"])
    rows=[];total=[]
    for cap in ("full_archive","first_of_month","end_of_month"):
        for policy in ("paired_visits","six_chips_nights"):
            for r in data:
                end="2002-10-31" if cap=="full_archive" else r["production_end_first" if cap=="first_of_month" else "production_end_last"]
                reg=ccd=0.
                for y in range(1996,2003):
                    good=[v for v in visits[r["field"],y] if v[0]<=end and (policy=="paired_visits" or v[2]>=6)]
                    count=len(good) if policy=="paired_visits" else len({v[0] for v in good})
                    span=max(v[1] for v in good)-min(v[1] for v in good) if count>1 else 0.
                    days=span if count>1 and span/(count-1)<8.5 else 0.
                    if cap=="full_archive":
                        assert abs(days-ref.loc[(r["field"],policy,y),"admitted_proxy_days"])<1e-8
                    reg+=days
                    if y>=2000:ccd+=days
                rows.append(dict(case=cap,policy=policy,field=r["field"],N=r["clump_margin_removed"],regular_days=reg,ccd2_days=ccd))
            recent=rows[-66:]
            reg=sum(v["N"]*v["regular_days"] for v in recent);ccd=sum(v["N"]*v["ccd2_days"] for v in recent)
            total.append(dict(case=cap,policy=policy,all_regular_star_days=reg,all_CCD2_star_days=ccd,
                              equal_area_one_eighth=(7*reg+ccd)/8,required_gap_weighted_CCD2_fraction=(reg-6.62e9)/(reg-ccd)))
    table("thesis-time-proxies.csv",rows);table("exposure-transport.csv",total)
    encode("historical-checks.json",{"random_clump_sum":sum(v["random_clump_2pct"] for v in data),"raw_extrap":sum(v["clump_extrap"] for v in data),
            "net_extrap":sum(v["clump_margin_removed"] for v in data),"journal_difference":5574780-5569216,
            "production_months":dict(Counter(v["production_end_first"][:7] for v in data)),
            "fields_with_nonclosing_image_sum":[v["field"] for v in data if v["annual_sum_minus_reported"]!=0],
            "thesis_duration_days":1704,"final_2006_denominator_is_not_the_thesis_denominator":True})
if __name__=="__main__":run()
