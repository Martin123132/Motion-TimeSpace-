from project_io import HERE,OLD,guard,table
import sys
import re
import numpy as np
import pandas as pd
from scipy.optimize import linprog
sys.path.insert(0,str(OLD))
from read_survey import sky,catalog
from sky_bounds import density_ceiling
from kernel import Lenses,SUN,Z_SUN,AXES,CAP,BAR_NORM,Ray

def footprints():
    eps=(OLD/"4893f01.eps").read_text()
    shape=r"n (\d+) (\d+) m (\d+) (\d+) l (\d+) (\d+) l (\d+) (\d+) l\s+(\d+) (\d+) l\s+cp"
    polygons=np.array(re.findall(shape,eps),int).reshape(-1,5,2)[:,:4,:]
    nums=np.array(re.findall(r"(\d+) (\d+) m\s+gs 1 -1 sc  333\.1 rot \((\d+)\)",eps),int)[::2]
    point=nums[:,:2]+np.array([120,0])
    centers=polygons.mean(axis=1)
    idx=np.linalg.norm(point[:,None,:]-centers,axis=-1).argmin(axis=1)
    assert len(idx)==len(set(idx))==65
    items={}
    for row,poly in zip(nums,polygons[idx],strict=True):
        xy=np.column_stack([10-(poly[:,0]-900)*17/8000,7-(poly[:,1]-900)*15/8000])
        items[f"cg{row[2]:03d}"]=xy
    items["cg121"]=np.array([[11.5,2.5]])
    archive={key:[] for key in items}
    for key,(bbox,_) in catalog().items():
        archive[key[:5]].extend([sky(ra,dec) for ra in bbox[:2] for dec in bbox[2:]])
    result={}
    for field,coords in items.items():
        ar=np.array(archive[field])
        assert np.max(np.abs(coords.mean(axis=0)-ar.mean(axis=0)))<.5
        allsky=np.vstack([coords,ar]);lo=allsky.min(axis=0)-.1;hi=allsky.max(axis=0)+.1
        assert lo[1]*hi[1]>0
        lonlo=0. if lo[0]*hi[0]<=0 else min(abs(lo[0]),abs(hi[0]))
        result[field]=(lonlo,max(abs(lo[0]),abs(hi[0])),min(abs(lo[1]),abs(hi[1])),max(abs(lo[1]),abs(hi[1])))
    return result
def ceilings(order):
    lenses=Lenses();records=[]
    for field,(lmin,lmax,bmin,bmax) in footprints().items():
        for source in (8.,10.,np.inf):
            end=min(52.,source);edges=np.linspace(0,end,round(end/order)+1)
            left,right=edges[:-1],edges[1:]
            dens=density_ceiling(lenses,left,right,bmin,bmax,lmin,lmax)
            weight=(right-left)*((right+left)/2-(right**2+right*left+left**2)/(3*source))
            caps=CAP*(weight@dens)
            if np.isinf(source):
                assert end*np.cos(np.radians(bmax))-SUN>30
                length=max(AXES)*2**.25;arg=(end-np.hypot(SUN,Z_SUN))/length
                caps[1]+=CAP*lenses.central.sum()/BAR_NORM*np.sqrt(np.pi/(2*arg))*np.exp(-arg)*length*(end+length)
            records.append(dict(field=field,source=source,lmin=lmin,lmax=lmax,bmin=bmin,bmax=bmax,
                                **dict(zip(("sphere","bar","annulus"),caps*(1+2e-12),strict=True))))
    return pd.DataFrame(records)
def maxmean(values,low,high,total):
    assert np.all(low<=high) and sum(low)<=total<=sum(high)
    left=total-sum(low);put=low.copy()
    for idx in np.argsort(-values):
        extra=min(left,high[idx]-low[idx]);put[idx]+=extra;left-=extra
    assert abs(left)<1e-5
    return values@put/total
def range_max(values,low,high,start,stop):
    low=np.asarray(low,dtype=float);high=np.asarray(high,dtype=float)
    start=max(start,low.sum());stop=min(stop,high.sum())
    assert 0<start<=stop and np.all(high>=low)
    order=np.argsort(-values)
    turns=low.sum()+np.cumsum((high-low)[order])
    budgets=np.unique(np.r_[start,turns[(turns>start)&(turns<stop)],stop])
    means=[maxmean(values,low,high,budget) for budget in budgets]
    winner=int(np.argmax(means))
    count=len(values);scale=float(np.max(np.abs(values))) or 1.
    eye=np.eye(count)
    inequalities=np.vstack([np.column_stack([eye,-high/stop]),np.column_stack([-eye,low/stop])])
    sol=linprog(np.r_[-values/scale,0.],A_ub=inequalities,b_ub=np.zeros(2*count),
                A_eq=np.r_[np.ones(count),0.][None,:],b_eq=[1.],bounds=[(0,None)]*count+[(1,stop/start)],method="highs")
    assert sol.success and abs(-sol.fun-means[winner]/scale)<2e-8
    return means[winner],budgets[winner],-sol.fun*scale,len(budgets)
def run():
    guard()
    coarse=ceilings(.04);fine=ceilings(.01)
    for key in ("sphere","bar","annulus"):assert (fine[key]<=coarse[key]*(1+2e-11)).all()
    table("field-kernel-ceilings.csv",fine.to_dict("records"))
    fig=pd.read_csv(OLD/"central-clump-points.csv").dropna(subset=["slot"]).copy()
    fig["field"]=fig.slot.str[:5];fig["num2"]=fig.clump_count_digitized*(fig.slot.str[5]=="2")
    counts=fig.groupby("field").agg(n=("slot","nunique"),nall=("clump_count_digitized","sum"),n2=("num2","sum"))
    counts=counts[counts.n==32].copy();assert len(counts)==27
    counts["ccd2_fraction"]=counts.n2/counts.nall
    table("complete-field-CCD2.csv",counts.reset_index().to_dict("records"))
    time=pd.read_csv(HERE/"thesis-time-proxies.csv")
    demo=range_max(np.array([3.,1.]),np.array([0.,1.]),np.array([1.,2.]),1.5,2.5)
    assert np.allclose(demo[:3],[2,2,2]) and demo[3]==3
    output=[];balances=[];certified=[]
    for (cap,policy),data in time.groupby(["case","policy"]):
        data=data.set_index("field").sort_index()
        reg=(data.N*data.regular_days).to_numpy();chip=(data.N*data.ccd2_days).to_numpy()
        gap=reg-chip
        frac=counts.ccd2_fraction.reindex(data.index);known=frac.notna().to_numpy();val=frac.fillna(0).to_numpy()
        other=~known;target=6.62e9
        balances.append(dict(case=cap,policy=policy,known_fields=int(sum(known)),known_gap_share=gap[known].sum()/gap.sum(),
                             measured_fraction=gap[known]@val[known]/gap[known].sum(),
                             required_other_gap_fraction=(reg.sum()-target-gap[known]@val[known])/gap[other].sum()))
        for assumption in ("no_chip_fractions","fig5_complete_fraction_proxy"):
            if assumption=="no_chip_fractions":
                low,high=chip.copy(),reg.copy()
            else:
                nn=counts.nall.reindex(data.index).fillna(1).to_numpy()
                n2=counts.n2.reindex(data.index).fillna(0).to_numpy()
                frac_min=np.clip((n2-4*2)/(nn+32*2),0,1)
                frac_max=np.clip((n2+4*2)/np.maximum(nn-32*2,1),0,1)
                low=np.where(known,reg-gap*frac_max,chip);high=np.where(known,reg-gap*frac_min,reg)
            for s,dat in fine.groupby("source"):
                field=dat.set_index("field").loc[data.index]
                for key in ("sphere","bar","annulus"):
                    vals=field[key].to_numpy()
                    first=maxmean(vals,low,high,6.615e9);last=maxmean(vals,low,high,6.625e9)
                    maximum,budget,check,count=range_max(vals,low,high,6.615e9,6.625e9)
                    certified.append(dict(case=cap,policy=policy,chip=assumption,source=s,compact=key,
                                          all_breakpoints_upper=maximum,attaining_total_source_days=budget,
                                          independent_lp=check,number_of_budgets=count,endpoint_only=max(first,last)))
                    output.append(dict(case=cap,policy=policy,chip=assumption,source=s,compact=key,
                                       rounded_low_exp_upper=first,rounded_high_exp_upper=last,
                                       valid_through_rounding_upper=max(first,last)))
    table("survey-exposure-envelopes.csv",output);table("CCD2-mixing-check.csv",balances)
    table("survey-exposure-certified.csv",certified)
if __name__=="__main__":run()
