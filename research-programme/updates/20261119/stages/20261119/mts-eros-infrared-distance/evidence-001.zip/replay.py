from project_io import HERE, guard
import subprocess
import sys

STEPS = [
    ("historical_source.py",), ("match_catalogs.py",), ("compare.py",),
    ("lens_test.py","8"), ("lens_test.py","14"), ("foreground.py",),
    ("precision_design.py","8"), ("precision_design.py","14"), ("field_envelope.py",),
    ("verify_stage.py",)
]
DRIVER = """
import runpy,sys
def deny(event,args):
    if event.startswith("socket.") and event not in ("socket.__new__","socket.gethostname"):
        raise RuntimeError("network access forbidden in replay: "+event)
sys.addaudithook(deny)
sys.argv=sys.argv[1:]
runpy.run_path(sys.argv[0],run_name="__main__")
"""

if __name__=="__main__":
    for step in STEPS:
        guard()
        print("Checking", *step, flush=True)
        subprocess.run([sys.executable,"-B","-c",DRIVER,*step],cwd=HERE,check=True)
