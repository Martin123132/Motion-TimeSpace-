from project_io import HERE,guard,table
from match_catalogs import catalog
from lens_test import OLD,PARENT,Ray,Lenses,CAP,sky
import numpy as np
import pandas as pd
import sys

def run(order):
    guard()
    src=pd.read_csv(HERE/"registered.csv.gz",dtype={"g_id":str})
    ipd=catalog("gaia_ipd")
    ipd["g_id"]=ipd.source_id.astype(str)
    data=src.merge(ipd[["g_id","ipd_frac_multi_peak","ipd_frac_odd_win","ipd_gof_harmonic_amplitude"]],how="left",on="g_id",validate="many_to_one")
    image=(data.ipd_frac_multi_peak<=2)&(data.ipd_frac_odd_win<=2)&(data.ipd_gof_harmonic_amplitude<=.2)
    if order==14:
        flags=pd.read_csv(HERE/"geometric-foreground.csv")
        rows=[]
        for record in flags.itertuples():
            pos=data.index[data.id==record.id][0]
            rows.append(dict(id=record.id,nearer_than_both=record.nearer_than_both,annulus_exact_zero=record.annulus_exact_zero,
                             ipd_clean=bool(image[pos]),multi_peak=data.ipd_frac_multi_peak[pos],odd_win=data.ipd_frac_odd_win[pos],
                             harmonic=data.ipd_gof_harmonic_amplitude[pos]))
        table("all-foreground-crowding.csv",rows)
        ipd_stats=[]
        for tag,mask in (("primary",data.gaia_ok),("additional_IPD",data.gaia_ok&image),("additional_IPD_6p",data.gaia_ok&image&(data.g_astrometric_params_solved==95))):
            for group in ("common","printed_only","drawn_only"):
                sample=data.loc[mask&(data.group==group),"g_plx"]
                ipd_stats.append(dict(case=tag,group=group,n=len(sample),mean=sample.mean(),sem=sample.sem(),median=sample.median()))
        table("image-quality-parallax.csv",ipd_stats)
    use=data.group.isin(["common","drawn_only"])
    drawn=data[use&data.gaia_ok]
    passed=image[use&data.gaia_ok].to_numpy()
    cases=[];sig=drawn.g_parallax_error.to_numpy()*1.5
    center=drawn.g_plx.to_numpy()
    lenses=Lenses()
    for row in drawn.itertuples():
        ray=Ray(*sky(row.old_ra,row.old_dec))
        dist,ww=lenses.grid(ray,order,[],2.)
        vals,cyl=lenses.density(ray,dist)
        weight=CAP*ww*dist*vals[:,0]*((cyl>=4)&(cyl<=7))
        cases.append((weight.sum(),weight@dist))
    aa,bb=np.array(cases).T
    assert np.all(aa>0) and np.all(bb>0)
    factor=np.sqrt(59.)
    designed=aa>bb*(1/8+.05+factor*sig)
    mass=pd.read_csv(PARENT/"fine-annulus.csv").mass.iat[0]
    slopes=pd.read_csv(PARENT/"light-force-response.csv");slopes=slopes[(slopes.norm=="matched")].set_index("model").Kforce_per_billion
    outputs=[]
    for name,keep in (("all",np.ones(len(aa),bool)),("precision",designed),("precision_and_image",designed&passed)):
        central=(aa[keep]-bb[keep]*center[keep]).sum()/sum(use)
        bias=.05*sum(bb[keep])/sum(use);penalty=factor*(bb[keep]*sig[keep]).sum()/sum(use)
        floor=max(0,central-bias-penalty);grad=floor*1e9/mass
        outputs.append(dict(variant=name,retained=int(sum(keep)),full_drawn=int(sum(use)),covariance_free_multiplier=factor,
                            tangent_mean=central,bias_penalty=bias,arbitrary_correlation_penalty=penalty,contribution_floor=floor,
                            per_billion_floor=grad,per_inner_force_ground=grad/slopes["ground"],
                            per_inner_force_NFW=grad/slopes["nfw"]))
    table(f"precision-tangent-order{order}.csv",outputs)

if __name__=="__main__":run(int(sys.argv[1]))
