from project_io import HERE,guard,table
from match_catalogs import GROUPS
import numpy as np
import pandas as pd

def analysis():
    guard()
    d=pd.read_csv(HERE/"registered.csv.gz",dtype={"id":str,"g_id":str,"v_id":str,"s_id":str})
    d=d[d.group!="other"].copy()
    d["cell"]=np.clip(np.floor((d.ra-270.34545)/(.19582/4)).astype(int),0,3)+4*np.clip(np.floor((d.dec+29.90090)/(.17315/4)).astype(int),0,3)
    rng=np.random.default_rng(20261119)
    draws=rng.multinomial(16,np.full(16,1/16),size=2000)
    retention=[];summary=[];comparisons=[]
    def weighted_median(values,weight):
        rank=np.argsort(values); vals=values[rank]; weights=weight[rank]; cs=np.cumsum(weights)
        if cs[-1]<=0:return np.nan
        lo=np.searchsorted(cs,(cs[-1]-1)//2+1);hi=np.searchsorted(cs,cs[-1]//2+1)
        return .5*(vals[lo]+vals[hi])
    def calculate(label,use,values,err=None,med=False):
        data=d.loc[use].copy()
        data["v"]=values[use]
        if err is not None:data["e"]=err[use]
        data=data[np.isfinite(data.v)]
        result=[];means=[];stderrs=[];errors=[];nblocks=[];est=[]
        for group in GROUPS:
            part=data[data.group==group]
            val=part.v.to_numpy(); cell=part.cell.to_numpy();n=len(part)
            if n<2:
                summary.append(dict(metric=label,group=group,n=n,blocks=n,mean="",median="",sample_sem="",propagated_sem="",negative=0))
                errors.append(np.nan);means.append(np.nan);stderrs.append(np.nan);nblocks.append(n);est.append(np.nan)
                result.append((np.full(len(draws),np.nan),np.full(16,np.nan)))
                continue
            errors.append(np.sqrt(np.sum(part.e**2))/n if err is not None else np.nan)
            avg=val.mean();se=val.std(ddof=1)/np.sqrt(n)
            means.append(avg);stderrs.append(se);nblocks.append(len(np.unique(cell)))
            counts=np.bincount(cell,minlength=16);sums=np.bincount(cell,weights=val,minlength=16)
            if med:
                est.append(np.median(val))
                bs=np.array([weighted_median(val,weight[cell]) if np.any(weight[cell]) else np.nan for weight in draws])
                loo=[np.median(val[cell!=k]) for k in range(16) if np.any(cell!=k)]
            else:
                est.append(avg)
                bs=np.divide(draws@sums,draws@counts,out=np.full(len(draws),np.nan),where=(draws@counts)>0)
                loo=[(sum(sums)-sums[k])/(n-counts[k]) for k in range(16) if n!=counts[k]]
            result.append((bs,np.array(loo)))
            summary.append(dict(metric=label,group=group,n=n,blocks=nblocks[-1],mean=avg,median=np.median(val),
                                sample_sem=se,propagated_sem=errors[-1] if err is not None else "",negative=int(sum(val<0))))
        diff=est[0]-est[1];boot=result[0][0]-result[1][0];loo=result[0][1]-result[1][1]
        if not np.isfinite(diff):
            comparisons.append(dict(metric=label,statistic="unavailable_missing_group",printed_only_minus_drawn_only="",scatter_se_mean="",propagated_se_mean="",
                                    block_boot_lo="",block_boot_hi="",loo_min="",loo_max="",populated_blocks_min=min(nblocks[:2])))
            return
        blo,bhi=np.nanpercentile(boot,[2.5,97.5])
        comparisons.append(dict(metric=label,statistic="median" if med else "mean",printed_only_minus_drawn_only=diff,
                                scatter_se_mean=np.hypot(*stderrs[:2]),propagated_se_mean=np.hypot(*errors[:2]) if err is not None else "",
                                block_boot_lo=blo,block_boot_hi=bhi,loo_min=min(loo),loo_max=max(loo),populated_blocks_min=min(nblocks[:2])))
    for group in GROUPS:
        sub=d[d.group==group]
        for key,mask in (("all",np.ones(len(sub),bool)),("gaia_position",sub.g_id.notna()),("virac_position",sub.v_id.notna()),
                         ("surot_2014",sub.surot_epoch2014),("ir_registered",sub.ir_registered),("ir_quality",sub.ir_quality),("ir_clean",sub.ir_clean),
                         ("giant_color",sub.giant_color),("gaia_ok",sub.gaia_ok),("virac_ok",sub.virac_ok),("both_astrometry",sub.gaia_ok&sub.virac_ok),
                         ("joint_clean_gaia",sub.ir_clean&sub.gaia_ok),("joint_clean_virac",sub.ir_clean&sub.virac_ok)):
            retention.append(dict(group=group,stage=key,num=int(sum(mask)),den=len(sub)))
    for tag,mask in (("registered",d.ir_registered),("quality",d.ir_quality),("clean",d.ir_clean),("giantcolor",d.giant_color)):
        calculate("K0_"+tag,mask&d.s_KCOR.between(0,30),d.s_KCOR,med=True)
    for tag,mag in [("raw_K",d.s_K),("JK0",d.s_JCOR-d.s_KCOR),("EJK",d.s_EJK)]+[(f"K_slope{a}",d.s_K-a*d.s_EJK) for a in [.4,.6,.8]]:
        calculate(tag,d.ir_clean,mag,med=True)
    for tag,mask,plx,err in [
            ("Gaia_all",d.gaia_ok,d.g_plx,d.g_parallax_error),("Gaia_uncorrected",d.gaia_ok,d.g_parallax,d.g_parallax_error),
            ("Gaia_tight_position",d.gaia_ok&d.gaia_tight_same,d.g_plx,d.g_parallax_error),("Gaia_5p",d.gaia_ok&(d.g_astrometric_params_solved==31),d.g_plx,d.g_parallax_error),
            ("Gaia_6p",d.gaia_ok&(d.g_astrometric_params_solved==95),d.g_plx,d.g_parallax_error),
            ("VIRAC_all",d.virac_ok,d.v_parallax,d.v_parallax_error),("VIRAC_tight_position",d.virac_ok&d.virac_tight_same,d.v_parallax,d.v_parallax_error),
            ("Gaia_same_as_VIRAC",d.gaia_ok&d.virac_ok,d.g_plx,d.g_parallax_error),("VIRAC_same_as_Gaia",d.gaia_ok&d.virac_ok,d.v_parallax,d.v_parallax_error)]:
        calculate(tag,mask,plx,err)
    calculate("VIRAC_minus_Gaia_same_IDs",d.gaia_ok&d.virac_ok,d.v_parallax-d.g_plx)
    for survey,mask,plx,err in [("Gaia",d.gaia_ok,d.g_plx,d.g_parallax_error),("VIRAC",d.virac_ok,d.v_parallax,d.v_parallax_error)]:
        keep=mask&d.ir_clean
        factor=10**(.2*(d.s_KCOR-13))
        calculate(survey+"_IR_matched_pi",keep,plx,err)
        calculate(survey+"_IR_matched_K",keep,d.s_KCOR,med=True)
        calculate(survey+"_IR_luminosity_stat",keep,plx*factor,err*factor)
    table("retention.csv",retention);table("population-stats.csv",summary);table("exclusive-differences.csv",comparisons)
if __name__=="__main__":analysis()
