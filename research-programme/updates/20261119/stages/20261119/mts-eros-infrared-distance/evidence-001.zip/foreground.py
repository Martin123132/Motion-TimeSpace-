from project_io import HERE,OLD,guard,table,put,encode
from ir_acquire import tap,GAIA
import sys
import io
import numpy as np
import pandas as pd
sys.path.insert(0,str(OLD))
from read_survey import sky
from pilot_depth import Ray

def run():
    guard()
    src=pd.read_csv(HERE/"registered.csv.gz",dtype={"g_id":str,"v_id":str,"s_id":str})
    w=pd.read_csv(HERE/"witness-parallaxes.csv.gz")
    data=src.merge(w,on="id",validate="one_to_one")
    bad=data.pi_lower>np.maximum(data.pi_far_printed,data.pi_far_drawn)
    selected=data[bad].copy()
    assert len(selected)==6
    identifiers=sorted(selected.g_id)
    fields="source_id,ipd_frac_multi_peak,ipd_frac_odd_win,ipd_gof_harmonic_amplitude,astrometric_excess_noise_sig,astrometric_n_good_obs_al"
    query="SELECT "+fields+" FROM gaiadr3.gaia_source WHERE source_id IN ("+",".join(identifiers)+")"
    if not (HERE/"gaia-foreground-quality.csv").exists():
        result=pd.read_csv(io.StringIO(tap(GAIA,query)),dtype={"source_id":str}).sort_values("source_id")
        assert result.source_id.tolist()==identifiers
        put("gaia-foreground-quality.csv",result.to_csv(index=False,lineterminator="\n").encode())
    encode("gaia-foreground-source.json",dict(base=GAIA,query=query))
    qual=pd.read_csv(HERE/"gaia-foreground-quality.csv",dtype={"source_id":str}).set_index("source_id")
    out=[]
    for row in data[data.gaia_ok&(data.pi_lower>0)].itertuples():
        ray=Ray(*sky(row.old_ra,row.old_dec));edge=min(x for x in ray.cylindrical(7.) if x>0)
        maximum=1/row.pi_lower
        is_witness=np.isfinite(row.pi_far_printed) and row.pi_lower>max(row.pi_far_printed,row.pi_far_drawn)
        if maximum>=edge and not is_witness:continue
        q=qual.loc[row.g_id] if row.g_id in qual.index else None
        out.append(dict(id=row.id,group=row.group,gaia=row.g_id,gaia_mas=row.g_plx,gaia_error_mas=row.g_parallax_error,
                        lower_mas=row.pi_lower,max_kpc=maximum,annulus_entry_kpc=edge,annulus_exact_zero=maximum<edge,
                        nearer_than_both=is_witness,gaia_sep_arcsec=row.gaia_arcsec,virac_sep_arcsec=row.virac_arcsec,
                        tight_both=bool(row.gaia_tight_same and row.virac_tight_same),
                        pm_vectors_diff_masyr=np.hypot(row.g_pmra-row.v_pmra,row.g_pmdec-row.v_pmde) if np.isfinite(row.v_pmra) else "",
                        virac_mas=row.v_parallax if np.isfinite(row.v_parallax) else "",virac_error_mas=row.v_parallax_error if np.isfinite(row.v_parallax_error) else "",
                        multi_peak_pct=int(q.ipd_frac_multi_peak) if q is not None else "",odd_window_pct=int(q.ipd_frac_odd_win) if q is not None else "",
                        gof_harmonic=q.ipd_gof_harmonic_amplitude if q is not None else "",good_observations=int(q.astrometric_n_good_obs_al) if q is not None else ""))
    table("geometric-foreground.csv",out)
if __name__=="__main__":run()
