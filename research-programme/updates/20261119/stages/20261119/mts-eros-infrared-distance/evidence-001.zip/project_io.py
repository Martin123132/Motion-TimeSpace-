import csv
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
for setting in ("OPENBLAS_NUM_THREADS","OMP_NUM_THREADS","MKL_NUM_THREADS","NUMEXPR_NUM_THREADS","BLIS_NUM_THREADS"):
    os.environ[setting]="1"

HERE=Path(__file__).resolve().parent
OLD=HERE.parent/"mts-eros-clump-exposure-20261119"
PIN="f6c288ed5057e63c577597c0364c5ae958b141a2898795f818d320f1306d537f"
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def guard():
    assert not any((folder/"STOP-REQUESTED").exists() for folder in (HERE,HERE.parent,OLD))
    assert sha(OLD/"seal.json")==PIN
def put(name,data):
    guard()
    path=HERE/name
    if path.exists():assert path.read_bytes()==data,name
    else:
        with path.open("xb") as stream:stream.write(data)
def encode(name,data):
    put(name,(json.dumps(data,sort_keys=True,indent=2,allow_nan=False)+"\n").encode())
def table(name,rows):
    stream=io.StringIO(newline="")
    writer=csv.DictWriter(stream,list(rows[0]),lineterminator="\n")
    writer.writeheader(); writer.writerows(rows)
    raw=stream.getvalue().encode()
    put(name,gzip.compress(raw,mtime=0) if name.endswith(".gz") else raw)
