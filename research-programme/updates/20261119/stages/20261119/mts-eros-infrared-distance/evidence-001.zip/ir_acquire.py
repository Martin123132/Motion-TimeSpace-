from project_io import HERE,guard,put,encode,sha
from urllib.request import urlopen, Request
from urllib.parse import urlencode
import csv
import io
import gzip
import json
import hashlib
import zipfile
import sys

ESO="https://archive.eso.org/tap_cat/sync"
GAIA="https://gea.esac.esa.int/tap-server/tap/sync"
SPECS={
"surot":(ESO,"safcat.MW_BULGE_PSFPHOT_V1","RA2000","DEC2000","SOURCEID,RA2000,DEC2000,J,JCOMBERR,K,KCOMBERR,P,SHARP,CHI,EJK,EJKERR,JCOR,KCOR,REP,FL"),
"virac":(ESO,"safcat.VVVX_VIRAC_V2_SOURCES","ra","de","sourceid,ra,de,ref_epoch,pmra,pmde,pmra_error,pmde_error,parallax,parallax_error,astfit_params,astfit_epochs,duplicate,uwe,phot_j_mean_mag,phot_ks_mean_mag,ks_med_err,ks_n_obs,ks_n_amb"),
"gaia":(GAIA,"gaiadr3.gaia_source","ra","dec","source_id,ra,dec,ref_epoch,pmra,pmdec,pmra_error,pmdec_error,parallax,parallax_error,ruwe,duplicated_source,visibility_periods_used,astrometric_params_solved,phot_g_mean_mag,nu_eff_used_in_astrometry,pseudocolour,ecl_lat,bp_rp"),
"gaia_ipd":(GAIA,"gaiadr3.gaia_source","ra","dec","source_id,ra,dec,ipd_frac_multi_peak,ipd_frac_odd_win,ipd_gof_harmonic_amplitude,astrometric_excess_noise_sig,astrometric_n_good_obs_al")}
def fetch(url,limit):
    with urlopen(Request(url,headers={"User-Agent":"MTS-research/1.0","Accept-Encoding":"gzip"}),timeout=100) as resp:
        data=resp.read(limit+1)
        if len(data)>limit:raise ValueError("response too large")
        data=gzip.decompress(data) if resp.headers.get("Content-Encoding")=="gzip" else data
        if len(data)>limit:raise ValueError("uncompressed response too large")
        return data

def tap(base,query):
    url=base+"?"+urlencode(dict(REQUEST="doQuery",LANG="ADQL",FORMAT="csv",MAXREC=250000,QUERY=query))
    data=fetch(url,80_000_000)
    assert not data.lstrip().startswith(b"<"),data[:400]
    return data.decode("utf-8-sig")

def catalogs(key):
    base,source,ra,dec,fields=SPECS[key]
    edges=[270.341,270.393,270.445,270.497,270.546]
    for idx,(left,right) in enumerate(zip(edges[:-1],edges[1:])):
        name=f"{key}-{idx}.csv.gz"
        if (HERE/name).exists() and (HERE/(name+".json")).exists():continue
        mask=f"{ra}>={left} AND {ra}<{right} AND {dec}>=-29.905 AND {dec}<-29.723"
        suffix=f" FROM {source} WHERE {mask}"
        from decimal import Decimal
        count_value=Decimal(list(csv.reader(io.StringIO(tap(base,"SELECT COUNT(*) AS ct"+suffix))))[1][0])
        count=int(count_value)
        assert count==count_value
        assert 0<count<250000
        query="SELECT "+fields+suffix
        raw=tap(base,query)
        reader=csv.reader(io.StringIO(raw));header=next(reader);rows=list(reader)
        assert len(rows)==count and [v.lower() for v in header]==fields.lower().split(",")
        assert all(len(row)==len(header) for row in rows)
        rows.sort(key=lambda row:(row[0],row[1],row[2]))
        output=io.StringIO(newline="")
        writer=csv.writer(output,lineterminator="\n");writer.writerow(header);writer.writerows(rows)
        put(name,gzip.compress(output.getvalue().encode(),mtime=0))
        encode(name+".json",dict(base=base,query=query,expected=count,sha256=sha(HERE/name)))
        print(name,count,flush=True)

def optical():
    args={"-source":"II/390/xcat","-c":"270.44336 -29.81433","-c.rm":"8.2","-out.max":"90000","-out.all":""}
    url="https://vizier.cfa.harvard.edu/viz-bin/asu-tsv?"+urlencode(args)
    lines=fetch(url,22000000).decode().splitlines()
    header=next(v for v in lines if not v.startswith("#") and "RAGdeg" in v).split("\t")
    idx=[header.index(k) for k in ("EROS","RAJ2000","DEJ2000","RAGdeg","DEGdeg")]
    rows=[]
    for line in lines:
        parts=line.split("\t")
        if len(parts)==len(header) and parts[idx[0]].startswith("cg6104l"):
            rows.append("\t".join(parts[i].strip() for i in idx))
    rows.sort()
    assert len(rows)==20922 and len(set(row.split()[0] for row in rows))==len(rows)
    put("eros-positions.tsv.gz",gzip.compress(("\n".join(rows)+"\n").encode(),mtime=0))
    encode("eros-positions.json",dict(url=url,sha256=sha(HERE/"eros-positions.tsv.gz")))

def zeropoint():
    meta=json.loads(fetch("https://pypi.org/pypi/gaiadr3-zeropoint/0.1.0/json",200000))
    wheel=next(rec for rec in meta["urls"] if rec["filename"].endswith(".whl"))
    data=fetch(wheel["url"],24000)
    assert hashlib.sha256(data).hexdigest()==wheel["digests"]["sha256"]=="39b6ab4c58807a5313674767b494684bd8bea263b3c55a4ea489c8b13b1fe7fb"
    with zipfile.ZipFile(io.BytesIO(data)) as zf:
        for name in zf.namelist():
            if name.endswith(".txt") and "/coefficients/" in name:
                put(name.split("/")[-1],zf.read(name))
        print(zf.namelist(),flush=True)
    put("official-zp.whl",data)

if __name__=="__main__":
    guard()
    for target in sys.argv[1:]:
        if target in SPECS:catalogs(target)
        elif target=="optical":optical()
        elif target=="zeropoint":zeropoint()
