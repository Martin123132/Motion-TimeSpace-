from project_io import HERE,OLD,guard,table
import sys
import numpy as np
import pandas as pd
from scipy.stats import norm
sys.path.insert(0,str(OLD))
from read_survey import sky
from pilot_depth import moments
from kernel import CAP,Lenses,Ray,AXES,SUN,Z_SUN,BAR_NORM
PARENT=OLD.parent/"mts-compact-lens-kernel-20261119"
CUTS=np.array([2.,4.,6.,8.,10.])
KINDS=("sphere","bar","annulus")
def witness(frame):
    full=np.loadtxt(PARENT/"ogle3-structure.dat")
    center=np.array([270.34545,270.54127,-29.90090,-29.72775])
    sub=np.where((full[:,2]*15<=center[1])&(full[:,3]*15>=center[0])&(full[:,4]<=center[3])&(full[:,5]>=center[2]))[0]
    expected=pd.read_csv(OLD/"witness-moments.csv").set_index("ogle_row")
    pairs=np.full((len(frame),2),np.nan);cells=np.full(len(frame),-1)
    for i,row in enumerate(frame.itertuples(index=False)):
        hits=moments(full[sub],row.old_ra,row.old_dec)
        if len(hits)==1 and full[sub[hits[0]],8]>0:cells[i]=sub[hits[0]]
    rank={"printed_only":1,"common":0,"drawn_only":-1}
    for cell in np.unique(cells[cells>=0]):
        indices=sorted(np.flatnonzero(cells==cell),key=lambda i:frame.id.iat[i])
        n=len(indices);mean,var=full[cell,7:9]
        assert int(expected.loc[cell+1,"union_count"])==n
        ordered=sorted(indices[n%2:],key=lambda i:(rank[frame.group.iat[i]],frame.id.iat[i]))
        sign=np.zeros(len(frame))
        sign[ordered[:len(ordered)//2]]=-1
        sign[ordered[len(ordered)//2:]]=1
        shifts=sign[indices]*np.sqrt(var*n/(n-n%2))
        pairs[indices]=10**((10-mean+np.column_stack([-shifts,shifts]))/5)
    assert np.isfinite(pairs[:,0]).sum()==3783
    return pairs,cells
def run(order):
    guard();frame=pd.read_csv(HERE/"registered.csv.gz",dtype={"id":str,"g_id":str,"v_id":str,"s_id":str})
    frame=frame[frame.group!="other"].reset_index(drop=True)
    ga=frame.gaia_ok.to_numpy()
    center=frame.g_plx.to_numpy();err=frame.g_parallax_error.to_numpy()*1.5
    z=norm.isf(.05/(2*ga.sum()))
    lo=np.where(ga,np.maximum(0,center-.05-z*err),0)
    hi=np.where(ga,center+.05+z*err,np.inf)
    inconsistent=hi<=0;hi[inconsistent]=np.inf;lo[inconsistent]=0
    preds,cells=witness(frame)
    tests=[]
    for name,mask in group_masks(frame).items():
        use=mask&ga&np.isfinite(preds[:,0])
        bad=(preds<lo[:,None])|(preds>hi[:,None])
        tests.append(dict(group=name,matched_witness=int((mask&np.isfinite(preds[:,0])).sum()),tested=int(use.sum()),
                          excluded_printed_far=int(sum(use&bad[:,0])),excluded_drawn_far=int(sum(use&bad[:,1])),
                          excluded_both=int(sum(use&bad.all(axis=1))),nearer_than_both=int(sum(use&(lo>np.max(preds,axis=1)))),
                          farther_than_both=int(sum(use&(hi<np.min(preds,axis=1)))),z=z,gaia_family=int(ga.sum()),
                          empty_physical=int(sum(mask&inconsistent))))
    table("witness-exclusions.csv",tests)
    pairlist=pd.DataFrame({"id":frame.id,"cell":np.where(cells>=0,cells+1,-1),"pi_far_printed":preds[:,0],"pi_far_drawn":preds[:,1],
                          "pi_lower":lo,"pi_upper":hi})
    from match_catalogs import dump
    dump(pairlist,"witness-parallaxes.csv.gz")
    lenses=Lenses()
    length=max(AXES)*2**.25
    arg=(52-np.hypot(SUN,Z_SUN))/length
    bar_tail=CAP*sum(lenses.central)/BAR_NORM*np.sqrt(np.pi/(2*arg))*np.exp(-arg)*length*(52+length)
    lowvals=np.zeros((len(frame),3));highvals=np.zeros_like(lowvals)
    avec=np.zeros((len(frame),len(CUTS),3));bvec=np.zeros_like(avec)
    for i,row in enumerate(frame.itertuples(index=False)):
        if i%1000==0:guard()
        ray=Ray(*sky(row.old_ra,row.old_dec))
        ps=[v for v in [lo[i],hi[i]] if np.isfinite(v) and v>0]
        dist,weights=lenses.grid(ray,order,[*CUTS,*[min(52.,1/v) for v in ps]],52.)
        dens,cyl=lenses.density(ray,dist)
        assert np.isfinite(dens).all() and dens.min()>=-1e-6
        comp=np.column_stack([dens[:,:8].sum(axis=1),dens[:,:4].sum(axis=1)+dens[:,8:].sum(axis=1),dens[:,0]*((cyl>=4)&(cyl<=7))])
        assert comp.min()>=0
        base=(CAP*weights*dist)[:,None]*comp
        mask=dist[None,:]<CUTS[:,None]
        avec[i]=mask@base;bvec[i]=mask@(dist[:,None]*base)
        highvals[i]=np.maximum(0,1-lo[i]*dist)@base
        highvals[i,1]+=bar_tail
        if np.isfinite(hi[i]):lowvals[i]=np.maximum(0,1-hi[i]*dist)@base
        tangent=avec[i]-bvec[i]/CUTS[:,None]
        direct=np.maximum(0,1-dist[None,:]/CUTS[:,None])@base
        assert np.max(abs(tangent-direct))<2e-18
        assert np.all(lowvals[i]<=highvals[i]+1e-18)
    normmass=float(pd.read_csv(PARENT/"fine-annulus.csv").mass.iat[0])
    vals=[];lines=[]
    masks=group_masks(frame)
    masks["printed_minus_drawn"]=masks["printed"].astype(float)/masks["printed"].sum()-masks["drawn"].astype(float)/masks["drawn"].sum()
    for name,use in masks.items():
        if name=="printed_minus_drawn": factor=use
        else:factor=use.astype(float)/sum(use)
        cl=np.maximum(factor,0)@lowvals+np.minimum(factor,0)@highvals
        ch=np.maximum(factor,0)@highvals+np.minimum(factor,0)@lowvals
        for col,kind in enumerate(KINDS):
            vals.append(dict(group=name,compact=kind,tau_lo=cl[col],tau_hi=ch[col],response_per_billion_lo=cl[col]*1e9/normmass if col==2 else "",
                             response_per_billion_hi=ch[col]*1e9/normmass if col==2 else ""))
        if name=="printed_minus_drawn":continue
        sel=use&ga
        for pos,u in enumerate(CUTS):
            aa=avec[sel,pos];bb=bvec[sel,pos];sig=bb*err[sel,None]
            lower=(aa-bb*(center[sel,None]+.05)).sum(axis=0)
            for col,kind in enumerate(KINDS):
                normal=max(0,(lower[col]-norm.isf(.05)*np.linalg.norm(sig[:,col]))/sum(use))
                arbitrary=max(0,(lower[col]-np.sqrt(19)*sig[:,col].sum())/sum(use))
                lines.append(dict(group=name,n=int(sum(use)),n_plx=int(sum(sel)),cut_kpc=u,compact=kind,
                                  plug_in=(aa-bb*center[sel,None]).sum(axis=0)[col]/sum(use),bias_allowance=.05*bb.sum(axis=0)[col]/sum(use),
                                  independent_normal_lower=normal,arbitrary_covariance_cantelli_lower=arbitrary,
                                  cantelli_response_per_billion=arbitrary*1e9/normmass if col==2 else ""))
    table(f"parallax-depth-order{order}.csv",vals);table(f"support-lines-order{order}.csv",lines)
def group_masks(frame):
    group=frame.group.to_numpy()
    return {**{key:group==key for key in ("common","printed_only","drawn_only")},
            "printed":group!="drawn_only","drawn":group!="printed_only"}
if __name__=="__main__":run(int(sys.argv[1]))
