from ir_acquire import fetch,guard,put,encode,sha,HERE
URL="https://publication-theses.unistra.fr/public/theses_doctorat/2004/HAMADACHE_Clarisse_2004.pdf"
if __name__=="__main__":
    guard()
    if not (HERE/"hamadache-2004.pdf").exists():
        data=fetch(URL,24_000_000)
        assert data.startswith(b"%PDF") and len(data)>1_000_000
        put("hamadache-2004.pdf",data)
    encode("thesis-source.json",dict(url=URL,sha256=sha(HERE/"hamadache-2004.pdf")))
