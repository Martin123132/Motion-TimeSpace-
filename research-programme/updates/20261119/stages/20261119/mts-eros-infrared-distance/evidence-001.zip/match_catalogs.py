from project_io import HERE,OLD,guard,sha,put,table
import gzip
import io
import sys
import numpy as np
import pandas as pd
from scipy.spatial import cKDTree

EPOCH=2000+155/366
ARC=180*3600/np.pi
GROUPS=("printed_only","drawn_only","common")
def vec(ra,dec):
    lon,lat=np.deg2rad(ra),np.deg2rad(dec)
    return ARC*np.column_stack([np.cos(lat)*np.cos(lon),np.cos(lat)*np.sin(lon),np.sin(lat)])
def uv(ra,dec,pmra,pmdec,delta):
    coslat=np.cos(np.deg2rad(dec))
    return vec(ra+np.nan_to_num(pmra)*delta/(3.6e6*coslat),dec+np.nan_to_num(pmdec)*delta/3.6e6)
def catalog(key):
    frames=[pd.read_csv(HERE/f"{key}-{idx}.csv.gz") for idx in range(4)]
    result=pd.concat(frames,ignore_index=True)
    assert not result.iloc[:,0].isna().any() and result.iloc[:,0].is_unique
    return result
def classify(red,blue):
    dm=red-(12+(6172-900)/1500);dc=blue-red-1.04
    box=(np.abs(dm)<1)&(np.abs(dc)<.25)&(red>0)&(blue>0)&(red<40)&(blue<40)
    printed=box&(dm>-4*dc-1); drawn=box&(dm<4*dc+1)
    return np.select([printed&~drawn,drawn&~printed,printed&drawn],GROUPS,default="other")
def source():
    old=pd.read_csv(OLD/"pilot-stars.tsv.gz",sep="\t",names=["id","old_ra","old_dec","R","B","Rm","Bm"],skipinitialspace=True)
    new=pd.read_csv(HERE/"eros-positions.tsv.gz",sep="\t",names=["id","check_ra","check_dec","ra","dec"])
    old["id"]=old.id.str.strip()
    frame=old.merge(new,on="id",how="inner",validate="one_to_one").sort_values("id").reset_index(drop=True)
    assert len(frame)==20922 and np.array_equal(frame.old_ra,frame.check_ra) and np.array_equal(frame.old_dec,frame.check_dec)
    frame["group"]=classify(frame.R,frame.B)
    assert list(frame.group.value_counts()[list(GROUPS)])==[415,105,3655]
    assert np.isfinite(frame[["ra","dec"]]).all().all()
    return frame
def pairing(left,right,radius=.35,separation=.60):
    dist,idx=cKDTree(right).query(left,k=2)
    back,other=cKDTree(left).query(right,k=2)
    first=idx[:,0]
    good=(dist[:,0]<=radius)&(dist[:,1]>=separation)&(other[first,0]==np.arange(len(left)))&(back[first,1]>=separation)
    return np.where(good,first,-1),dist[:,0],dist[:,1]
def motion(frame,year):
    de=frame["dec"] if "dec" in frame else frame["de"]
    pmde=frame["pmdec"] if "pmdec" in frame else frame["pmde"]
    return uv(frame.ra,de,frame.pmra,pmde,year-frame.ref_epoch)
def zpt(frame):
    mag=frame.phot_g_mean_mag.to_numpy()
    sine=np.sin(np.deg2rad(frame.ecl_lat.to_numpy()))
    result=np.full(len(frame),np.nan)
    for tag,params,colorcol,low,high in [(5,31,"nu_eff_used_in_astrometry",1.1,1.9),(6,95,"pseudocolour",1.24,1.72)]:
        data=np.loadtxt(HERE/f"z{tag}_200720.txt",delimiter=",")
        color=frame[colorcol].to_numpy()
        ok=(frame.astrometric_params_solved.to_numpy()==params)&(color>low)&(color<high)&(mag>6)&(mag<21)&np.isfinite(sine)
        valid=color[ok]; lat=sine[ok]
        colors=[np.ones_like(valid),np.clip(valid-1.48,-.24,.24),np.clip(1.48-valid,0,.24)**3,np.minimum(0,valid-1.24),np.maximum(0,valid-1.72)]
        angles=[np.ones_like(lat),lat,lat**2-1/3]
        result[ok]=np.round(.001*sum(np.interp(mag[ok],data[2:,0],data[2:,col])*colors[int(data[0,col])]*angles[int(data[1,col])] for col in range(1,data.shape[1])),6)
    return result
def dump(frame,name):
    raw=frame.to_csv(index=False,lineterminator="\n",float_format="%.12g").encode()
    put(name,gzip.compress(raw,mtime=0))
def run():
    guard();src=source();surot=catalog("surot");virac=catalog("virac");gaia=catalog("gaia")
    ega=vec(src.ra,src.dec);raw=vec(src.old_ra,src.old_dec)
    checks=[];ids={}
    def report(cat,case,index,dist):
        for group in (*GROUPS,"all"):
            use=np.ones(len(src),bool) if group=="all" else (src.group==group).to_numpy()
            ok=use&(index>=0)
            checks.append(dict(catalog=cat,case=case,group=group,n=int(use.sum()),matched=int(ok.sum()),
                               median_arcsec=np.median(dist[ok]) if ok.any() else ""))
    for name,frame in (("virac",virac),("gaia",gaia)):
        place=motion(frame,EPOCH)
        for policy,left,right,rad in [("nominal",ega,place,.35),("tight",ega,place,.25),("wide",ega,place,.45),
                                     ("original_plate",raw,place,.35),("stationary",ega,motion(frame,frame.ref_epoch),.35)]:
            idx,dist,_=pairing(left,right,rad)
            report(name,policy,idx,dist)
            if policy=="nominal": ids[name]=idx;src[name+"_arcsec"]=dist
            else:src[name+"_"+policy+"_same"]=(idx>=0)&(idx==ids[name])
        for east,north in [(5,0),(-5,0),(0,5),(0,-5)]:
            offset=vec(src.ra+east/(3600*np.cos(np.deg2rad(src.dec))),src.dec+north/3600)
            idx,dist,_=pairing(offset,place);report(name,f"shift_{east}_{north}",idx,dist)
    ir=vec(surot.RA2000,surot.DEC2000)
    assigns=[]
    for year in [2010,2014,2018]:
        idx,_,_=pairing(motion(virac,year),ir)
        assigns.append(idx)
    vi=ids["virac"];gi=ids["gaia"];vok=vi>=0
    anchor=np.maximum(vi,0)
    within=(assigns[0]==assigns[1])&(assigns[1]==assigns[2])&(assigns[1]>=0)&np.isfinite(virac.pmra)&np.isfinite(virac.pmde)
    si=np.where(vok&np.asarray(within)[anchor],assigns[1][anchor],-1)
    src["surot_epoch2014"]=vok&(assigns[1][anchor]>=0)
    def bring(frame,idx,fields,prefix):
        for key in fields:
            vals=frame[key].to_numpy()
            if key.lower() in ("source_id","sourceid"):
                src[prefix+"id"]=[str(int(vals[i])) if i>=0 else "" for i in idx]
            else:src[prefix+key]=np.where(idx>=0,vals[np.maximum(idx,0)],np.nan)
    gaia["zero_point"]=zpt(gaia)
    bring(gaia,gi,["source_id","parallax","parallax_error","ruwe","duplicated_source","visibility_periods_used","astrometric_params_solved","zero_point","phot_g_mean_mag","pmra","pmdec"],"g_")
    bring(virac,vi,["sourceid","parallax","parallax_error","uwe","astfit_params","astfit_epochs","duplicate","phot_ks_mean_mag","pmra","pmde"],"v_")
    bring(surot,si,surot.columns,"s_")
    valid=(si>=0)
    src["ir_registered"]=valid
    src["ir_quality"]=valid&src.s_K.between(12.5,17,inclusive="neither")&src.s_J.between(0,35,inclusive="neither")&src.s_KCOR.between(0,30)&src.s_JCOR.between(0,35)&src.s_EJK.between(0,8)&src.s_JCOMBERR.between(0,.1)&src.s_KCOMBERR.between(0,.1)&src.s_P.between(.8,1)&(src.s_SHARP.abs()<=.5)&src.s_CHI.between(0,2)
    near=cKDTree(ir).query_ball_point(ir[si[valid]],1.5)
    crowded=np.zeros(len(src),bool)
    for row,neighbors in zip(np.flatnonzero(valid),near,strict=True):
        neighbors=np.array([n for n in neighbors if n!=si[row]],dtype=int)
        crowded[row]=np.any((surot.K.to_numpy()[neighbors]>0)&(surot.K.to_numpy()[neighbors]<src.s_K.iat[row]+2.5))
    src["ir_crowded"]=crowded
    src["ir_clean"]=src.ir_quality&~crowded
    src["giant_color"]=src.ir_clean&(src.s_JCOR-src.s_KCOR).between(.45,.85)
    src["gaia_ok"]=(gi>=0)&src.g_astrometric_params_solved.isin([31,95])&(src.g_duplicated_source==0)&(src.g_visibility_periods_used>=9)&(src.g_ruwe<=1.4)&np.isfinite(src.g_zero_point)&(src.g_parallax_error>0)&np.isfinite(src.g_parallax)
    src["virac_ok"]=vok&(src.v_astfit_params==5)&(src.v_duplicate==0)&(src.v_uwe<=1.4)&(src.v_astfit_epochs>=20)&(src.v_parallax_error>0)&np.isfinite(src.v_parallax)
    src["g_plx"]=src.g_parallax-src.g_zero_point
    dump(src,"registered.csv.gz");table("positions-controls.csv",checks)
if __name__=="__main__":run()
