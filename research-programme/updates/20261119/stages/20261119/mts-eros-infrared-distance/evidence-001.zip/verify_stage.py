from project_io import HERE, OLD, PIN, guard, sha, encode, table
import math
import json
import sys
import zipfile
import hashlib
import numpy as np
import pandas as pd
from scipy.stats import norm
from match_catalogs import catalog,source,zpt
from lens_test import sky,PARENT,Ray,SUN

def load_json(path):
    return json.loads(path.read_text(encoding="utf-8"))

def check_manifest(folder,pin):
    assert sha(folder/"seal.json")==pin
    files=load_json(folder/"seal.json")["files"]
    for name,expected in files.items():
        assert sha(folder/name)==expected,name
    return len(files)

def scalar_zpt(row,coeff):
    solution=row.astrometric_params_solved
    if not (6<row.phot_g_mean_mag<21 and math.isfinite(row.ecl_lat)):return math.nan
    if solution==31:
        color=row.nu_eff_used_in_astrometry
        if not 1.1<color<1.9:return math.nan
    elif solution==95:
        color=row.pseudocolour
        if not 1.24<color<1.72:return math.nan
    else:return math.nan
    rows=coeff[solution]
    sine=math.sin(math.radians(row.ecl_lat))
    angles=(1.,sine,sine*sine-1./3.)
    colors=(1.,max(-.24,min(.24,color-1.48)),max(0.,min(.24,1.48-color))**3,min(0.,color-1.24),max(0.,color-1.72))
    upper=next(idx for idx in range(3,len(rows)) if rows[idx,0]>=row.phot_g_mean_mag)
    lower=upper-1
    def at(idx):
        return math.fsum(rows[idx,col]*angles[int(rows[1,col])]*colors[int(rows[0,col])] for col in range(1,rows.shape[1]))
    width=rows[upper,0]-rows[lower,0]
    return round((at(lower)*(rows[upper,0]-row.phot_g_mean_mag)+at(upper)*(row.phot_g_mean_mag-rows[lower,0]))/(1000.*width),6)

def run():
    guard()
    parent_counts=[check_manifest(OLD,PIN),check_manifest(PARENT,load_json(OLD/"seal.json")["parent"])]
    counts={}
    for key in ("surot","virac","gaia","gaia_ipd"):
        for idx in range(4):
            path=HERE/f"{key}-{idx}.csv.gz";spec=load_json(HERE/(path.name+".json"))
            assert spec["base"].startswith("https://") and spec["sha256"]==sha(path)
            assert len(pd.read_csv(path,usecols=[0]))==spec["expected"]
        counts[key]=len(catalog(key))
    gaia=catalog("gaia")
    assert set(gaia.source_id)==set(catalog("gaia_ipd").source_id)
    assert sha(HERE/"official-zp.whl")=="39b6ab4c58807a5313674767b494684bd8bea263b3c55a4ea489c8b13b1fe7fb"
    coeff={}
    with zipfile.ZipFile(HERE/"official-zp.whl") as archive:
        for tag,number in ((5,31),(6,95)):
            filename=f"z{tag}_200720.txt"
            member=next(name for name in archive.namelist() if name.endswith("/coefficients/"+filename))
            assert archive.read(member)==(HERE/filename).read_bytes()
            coeff[number]=np.loadtxt(HERE/filename,delimiter=",")
    for doc,file in [("thesis-source.json","hamadache-2004.pdf"),("eros-positions.json","eros-positions.tsv.gz")]:
        assert load_json(HERE/doc)["sha256"]==sha(HERE/file)
    expected=np.array([scalar_zpt(row,coeff) for row in gaia.itertuples()])
    actual=zpt(gaia)
    assert np.array_equal(np.isfinite(expected),np.isfinite(actual))
    zp_res=float(np.nanmax(abs(expected-actual)))
    assert zp_res<=.00000100001
    assert {31,95}<=set(gaia.loc[np.isfinite(expected),"astrometric_params_solved"])
    optical=source()
    pivot=12+(6172-900)/1500
    dr=optical.R-pivot;color=optical.B-optical.R-1.04
    flux_ratio=10**(-.4*dr)
    red_native=2.5*np.log10(flux_ratio)
    color_native=2.5*np.log10(10**(.4*color))
    mask=(abs(red_native)<1)&(abs(color_native)<.25)&(red_native> -4*color_native-1)&optical.R.between(0,40,inclusive="neither")&optical.B.between(0,40,inclusive="neither")
    assert np.array_equal(mask,optical.group.isin(["common","drawn_only"]))
    hist=load_json(HERE/"historical-checks.json")
    assert (hist["random_clump_sum"],hist["raw_extrap"],hist["net_extrap"],hist["journal_difference"])==(144800,7240000,5574780,5564)
    intervals=pd.read_csv(HERE/"witness-parallaxes.csv.gz")
    eligible=pd.read_csv(HERE/"registered.csv.gz",usecols=["id","group","gaia_ok","ra","dec","old_ra","old_dec"])
    eligible=eligible[eligible.group!="other"].set_index("id")
    assert len(intervals)==len(eligible) and set(intervals.id)==set(eligible.index)
    assert sum(eligible.gaia_ok)==2633
    zscore=norm.isf(.05/(2*sum(eligible.gaia_ok)))
    image=pd.read_csv(HERE/"all-foreground-crowding.csv").set_index("id")
    fg=pd.read_csv(HERE/"geometric-foreground.csv")
    tipping=[]
    for row in fg[fg.annulus_exact_zero].itertuples():
        star=eligible.loc[row.id]
        lon,lat=np.deg2rad(sky(star.old_ra,star.old_dec))
        near=(SUN**2-7**2)/(np.cos(lat)*(SUN*np.cos(lon)+np.sqrt(7**2-(SUN*np.sin(lon))**2)))
        assert abs(near-row.annulus_entry_kpc)<1e-12
        bias=row.gaia_mas-1/near-zscore*1.5*row.gaia_error_mas
        inflation=(row.gaia_mas-1/near-.05)/(zscore*row.gaia_error_mas)
        assert bias>.05 and inflation>1.5
        tipping.append(dict(id=row.id,passes_extra_image_screen=bool(image.loc[row.id,"ipd_clean"]),edge_kpc=near,
                            largest_bias_mas_at_inflation_1p5=bias,largest_sigma_inflation_at_bias_0p05=inflation))
    assert len(tipping)==3 and sum(r["passes_extra_image_screen"] for r in tipping)==2
    table("foreground-tipping-points.csv",tipping)
    errors={}
    for prefix,col in [("parallax-depth","tau_lo"),("parallax-depth","tau_hi"),("support-lines","plug_in"),("precision-tangent","tangent_mean")]:
        first,last=[pd.read_csv(HERE/f"{prefix}-order{order}.csv")[col].to_numpy() for order in (8,14)]
        scaled=float(np.max(abs(first-last))/np.max(abs(last)))
        assert scaled<5e-7
        errors[prefix+"/"+col]=scaled
    rect=pd.read_csv(HERE/"survey-exposure-certified.csv")
    assert len(rect)==108 and np.all(rect.all_breakpoints_upper>=rect.endpoint_only-1e-19)
    lp_error=float(np.max(abs(rect.independent_lp/rect.all_breakpoints_upper-1)))
    assert lp_error<2e-8
    cols=pd.read_csv(HERE/"field-kernel-ceilings.csv")
    assert cols.field.nunique()==66 and len(cols)==198 and (cols[["sphere","bar","annulus"]]>0).all().all()
    encode("verification.json",dict(catalog_rows=counts,predecessor_sealed_file_counts=parent_counts,
           official_table_scalar_compared=len(expected),supported_zero_points=int(np.isfinite(expected).sum()),max_zp_difference_mas=zp_res,
           native_selection_checked=len(optical),native_drawn=int(mask.sum()),eligible_gaia=int(eligible.gaia_ok.sum()),family_z=zscore,
           geometric_zeros=len(tipping),extra_image_clean_zeros=sum(r["passes_extra_image_screen"] for r in tipping),
           numerical_order_max_changes_over_peak=errors,allocation_lp_cases=len(rect),allocation_max_relative_error=lp_error))
    paths={path.name:sha(path) for path in sorted(HERE.iterdir()) if path.is_file() and path.name!="seal.json"}
    assert not any(path.is_dir() for path in HERE.iterdir())
    for name in ("RESULTS.md","NEXT.md","REPLAY.md","verification.json","foreground-tipping-points.csv"):assert name in paths,name
    encode("seal.json",dict(parent=PIN,files=paths))
    print("Sealed",len(paths),"files",sha(HERE/"seal.json"))

if __name__=="__main__":run()
