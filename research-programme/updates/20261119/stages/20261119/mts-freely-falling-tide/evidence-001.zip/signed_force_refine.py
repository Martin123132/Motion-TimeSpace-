import sys
from satellite import GRIDS, history, table, TOL
from tidal_crosschecks import load_rows


def run(create):
    targets=[]
    previous=next(float(row["inward_field_along_satellite_m_s2"]) for row in load_rows("lmc-extended-field.csv")
                  if row["grid"]=="edge96" and row["scale"]=="central_cap" and row["preparation"]=="unexcited" and float(row["radius_kpc"])==17.58)
    for grid,edge,count in (("edge120",120.,300),("edge144",144.,360)):
        GRIDS[grid]=(edge,count,208,1,6)
        try:
            _,fields,_=history("central_cap",grid,(0.,))
        finally:
            del GRIDS[grid]
        current=next(row for row in fields if row["preparation"]=="unexcited" and row["radius_kpc"]==17.58)
        actual=current["inward_field_along_satellite_m_s2"]
        err=abs(previous/actual-1)
        targets.append(dict(**current,previous=previous,own_scale_error=err,passes=err<TOL))
        previous=actual
    return table("signed-force-extended.csv",targets,create)


if __name__=="__main__":
    print(run(sys.argv[1:]==["create"]))

