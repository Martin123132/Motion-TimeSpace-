import csv
import hashlib
import json
import platform
import subprocess
import sys
from pathlib import Path
from tide import HERE, PRE, PRIOR, bridge, np, TOL, guard
from forecast import freeze
from satellite import orbit, unit_scales, angular_check
from cap_test import reference
import scipy


def rows(name):
    with (HERE/name).open(newline="",encoding="utf8") as handle:
        values=list(csv.DictReader(handle))
    assert values and all(None not in row and all(value is not None for value in row.values()) for row in values)
    return values


def passed(row):
    return row["passes"]=="True"


def inspect():
    guard()
    freeze(False)
    reference()
    angular_check()
    orbit(1)
    assert bridge.sha(PRE/"seal.json")==PRIOR
    assert bridge.sha(HERE/"orphan_orbit.txt")=="dc417e3cb6bffa8687aa59f8704c399668efe14130d9db8fc718c52e9d262150"
    assert not list(HERE.glob("*.partial")) and not (HERE/"__pycache__").exists()
    assert len(list(HERE.glob("*.npz")))==15
    for path in HERE.glob("*.py"):
        compile(path.read_bytes(),path.name,"exec")
    for row in rows("nonlinear-replay.csv"):
        assert row["saved_sha256"]==row["replayed_sha256"]==bridge.sha(HERE/row["packet"])
    assert len(rows("nonlinear-replay.csv"))==5
    for path in HERE.glob("*.npz"):
        with np.load(path,allow_pickle=False) as data:
            assert data["rows"].shape==(41,10) and data["snapshots"].shape[0]==3
            assert all(np.isfinite(data[key]).all() for key in ("rows","snapshots","number","rest","shell_mass"))
            assert data["receipt"].item().decode()==bridge.sha(HERE/"forecast.json")
    uniform=rows("uniform-readback.csv")
    assert len(uniform)==9 and all((row["pass_all"]=="True")==(row["grid"]!="small") for row in uniform)
    shell=rows("shell-readback.csv")
    assert len(shell)==36 and sum(not passed(row) for row in shell)==3 and all(passed(row) for row in shell if row["grid"]!="small")
    checks=rows("independent-checks.csv")
    assert len(checks)==26 and all(passed(row) for row in checks)
    domain=rows("domain-checks.csv")
    misses=[row for row in domain if not passed(row)]
    assert len(domain)==240 and len(misses)==14 and {row["metric"] for row in misses}=={"inward_field_along_satellite_m_s2"}
    last=[row for row in misses if row["grids"]=="edge72_edge96"]
    assert len(last)==1 and last[0]["scale"]=="central_cap" and float(last[0]["kpc"])==17.58
    extra=rows("signed-force-extended.csv")
    assert len(extra)==2 and all(passed(row) for row in extra) and float(extra[-1]["own_scale_error"])<float(extra[0]["own_scale_error"])
    glides=rows("gaia-glide-sensitivity.csv")
    assert len(glides)==8 and all(passed(row) and 0<float(row["optimistic_separation_sigma"])<.027 for row in glides)
    assert len(rows("lmc-response.csv"))==42 and len(rows("lmc-extended-box.csv"))==12
    assert len(rows("lmc-tensors.csv"))==252 and len(rows("lmc-extended-tensors.csv"))==72
    ref=rows("isolated-checks.csv")[-1]
    assert abs(float(ref["invariant_love"])/1149-1)<.0005 and abs(float(ref["numerical_omega"])-.450)<.0005
    assert all(float(row["independent_check"])<TOL and float(row["quadrature_check"])<TOL for row in rows("finite-profile.csv"))
    for label in ("central_cap","illustrative"):
        assert all(number>0 for number in unit_scales(label))
    return {path.name:len(rows(path.name)) for path in sorted(HERE.glob("*.csv"))}


def deep():
    for name in ("tide","forecast","pulse_readback","satellite","box_test","signed_force_refine","tidal_crosschecks","solar_glide","nonlinear_replay"):
        guard()
        completed=subprocess.run([sys.executable,"-B",str(HERE/(name+".py"))],cwd=HERE,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
        if completed.returncode:
            raise RuntimeError(name+" failed: "+completed.stdout[-3000:])
        print(name,"reproduced",flush=True)


def manifest():
    counts=inspect()
    tree=HERE.parent
    ancestors={Path(mod.__file__).resolve() for mod in tuple(sys.modules.values()) if getattr(mod,"__file__",None) and str(mod.__file__).endswith(".py")}
    deps={path.relative_to(tree).as_posix():bridge.sha(path) for path in sorted(ancestors) if path.is_relative_to(tree) and not path.is_relative_to(HERE)}
    return dict(parent=PRIOR,tolerance=TOL,csv_rows=counts,trajectory_rows=5001,external_python_sources=deps,
                runtime=[platform.python_version(),np.__version__,scipy.__version__],
                files={path.name:bridge.sha(path) for path in sorted(HERE.iterdir()) if path.is_file() and path.name!="seal.json"})


if __name__=="__main__":
    mode=sys.argv[1:]
    assert mode in ([],["deep"],["seal"])
    target=HERE/"seal.json"
    if mode==["seal"] and target.exists():
        raise FileExistsError(target)
    if mode:
        deep()
    receipt=manifest()
    if mode==["seal"]:
        with target.open("x",encoding="utf8") as handle:
            json.dump(receipt,handle,indent=2,sort_keys=True)
    assert receipt==json.loads(target.read_bytes())
    print("verified",len(receipt["files"]),"files,",sum(receipt["csv_rows"].values()),"table rows; seal",bridge.sha(target))

