import sys
import json
from tide import HERE,PRE,guard,np,bridge,table,TOL,strengths,spectral,establish

EDGE=30.
DISTANCE=3.
AMPLITUDE=1e-5
PULL=.002
CASES=("uniform","shell")
GRIDS={"small":(36,4,256),"radial":(64,5,256),"fine":(64,5,512)}

def expectations():
    freq,respond,couple,_,_=strengths(EDGE,96,DISTANCE)
    period=2*np.pi/freq[0]
    def harmonic(rate):
        return period*np.sinc(rate*period/(2*np.pi))*np.exp(-.5j*rate*period)
    transform=.5*harmonic(freq)-.25*(harmonic(freq-2*np.pi/period)+harmonic(freq+2*np.pi/period))
    for coast in (0.,.125,.25):
        wave=transform*np.exp(1j*freq*period*(1+coast))
        yield dict(coast=coast,period=period,Q2_per_unit_tide=.4*sum(respond*couple*wave.imag/freq),
                   Q2dot_per_unit_tide=.4*sum(respond*couple*wave.real),energy_per_tide_squared=.2*sum(couple**2*abs(transform)**2),
                   first_fraction_of_work=(couple[0]*abs(transform[0]))**2/sum(couple**2*abs(transform)**2),
                   uniform_position=PULL*period**2*(.25+.5*coast),uniform_velocity=PULL*period/2,
                   uniform_intrinsic_Q2=0.,uniform_internal_energy=0.)

def freeze(create):
    guard()
    parent=json.loads((PRE/"seal.json").read_bytes())
    assert all(bridge.sha(PRE/name)==digest for name,digest in parent["files"].items())
    rows=table("pulse-predictions.csv",expectations(),create)
    paths=[HERE/name for name in ("PROTOCOL.md","tide.py","forecast.py","field_evolution.py","pulse-predictions.csv","finite-profile.csv","isolated-checks.csv")]
    paths.append(PRE/"seal.json")
    checks={path.relative_to(HERE.parent).as_posix():bridge.sha(path) for path in paths}
    target=HERE/"forecast.json"
    if create:
        with target.open("x",encoding="utf8") as stream:
            json.dump(checks,stream,indent=2,sort_keys=True)
    assert json.loads(target.read_bytes())==checks
    return rows

if __name__=="__main__":
    print(freeze(sys.argv[1:]==["freeze"]))

