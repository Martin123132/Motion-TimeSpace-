import sys
import csv
import json
from pathlib import Path
from functools import lru_cache
HERE=Path(__file__).resolve().parent
PRE=HERE.parent/"mts-transport-excitation-20261119"
sys.path.insert(0,str(PRE))
from model import np,bridge,background,guard as previous_guard,TOL
from scipy.special import spherical_jn,roots_legendre
from scipy.linalg import eigh,solve
from scipy.optimize import brentq
from scipy.integrate import solve_bvp,simpson

PRIOR="14fcc4c36cb9a3edb6eceada9663894cebbb45e4e75da73530d527be1fecaec7"

def guard():
    previous_guard()
    assert bridge.sha(PRE/"seal.json")==PRIOR
    if (HERE/"STOP-REQUESTED").exists():
        raise SystemExit("owner hold")

def table(name,rows,create):
    rows=list(rows)
    path=HERE/name
    if create:
        with path.open("x",encoding="utf8",newline="") as stream:
            writer=csv.DictWriter(stream,fieldnames=rows[0])
            writer.writeheader()
            writer.writerows(rows)
    with path.open(encoding="utf8",newline="") as stream:
        assert list(csv.DictReader(stream))==[{k:str(v) for k,v in row.items()} for row in rows],name
    return rows

def gauss(edge,panels,split=()):
    edges=np.unique(np.r_[np.linspace(0.,edge,panels+1),[val for val in split if 0.<val<edge]])
    node,weight=roots_legendre(8)
    half=.5*np.diff(edges)[:,None]
    return (edges[:-1,None]+half*(1+node)).ravel(),(half*weight).ravel()

@lru_cache(None)
def zeros(order,count):
    scale=np.arange(.25,count+order+4,.25)*np.pi
    sample=spherical_jn(order,scale)
    signs=np.flatnonzero(sample[:-1]*sample[1:]<=0.)
    roots=np.unique([brentq(lambda val:spherical_jn(order,val),scale[idx],scale[idx+1]) for idx in signs])
    assert len(roots)>=count
    return roots[:count]

def radial_basis(order,roots,edge,axis):
    normal=np.sqrt(.5*edge**3*(spherical_jn(order,roots)**2-spherical_jn(order-1,roots)*spherical_jn(order+1,roots)))
    return spherical_jn(order,np.outer(axis,roots/edge))/normal

def factor(axis,distance):
    return np.ones_like(axis) if distance is None else np.minimum(1.,(distance/np.maximum(axis,1e-20))**5)

@lru_cache(None)
def spectral(edge,count):
    guard()
    axis,weights=gauss(edge,2*count)
    ground,eigen,_=background(False,edge)
    amp,_,potential,_=ground(axis)
    roots=zeros(2,count)
    proots=zeros(1,count+16)
    vec=axis[:,None]*radial_basis(2,roots,edge,axis)
    vac=axis[:,None]*radial_basis(2,proots,edge,axis)
    assert np.max(abs(vec.T@(weights[:,None]*vec)-np.eye(count)))<1e-10
    ham=np.diag(.5*(roots/edge)**2)+vec.T@((weights*(potential-eigen))[:,None]*vec)
    cross=vac.T@((weights*amp)[:,None]*vec)
    gravity=-2*cross.T@((edge/proots)[:,None]**2*cross)
    diagonal,basis=eigh(ham)
    root=(basis*np.sqrt(diagonal))@basis.T
    inv=(basis/np.sqrt(diagonal))@basis.T
    eig,states=eigh(root@(ham+gravity)@root)
    assert min(eig)>0 and np.all(diagonal>0.)
    return roots,ham,gravity,root,inv,np.sqrt(eig),states

def strengths(edge,count,distance):
    roots,ham,gravity,root,inv,freq,states=spectral(edge,count)
    axis,weights=gauss(edge,2*count,() if distance is None else (distance,))
    base=axis[:,None]*radial_basis(2,roots,edge,axis)
    source=weights*axis**3*background(False,edge)[0](axis)[0]
    quadr=base.T@source
    driver=base.T@(source*factor(axis,distance))
    intrinsic=states.T@root@quadr
    coupling=states.T@root@driver
    pieces=.4*intrinsic*coupling/freq**2
    frozen=.4*quadr@solve(ham,driver,assume_a="pos")
    return freq,intrinsic,coupling,pieces,frozen

@lru_cache(None)
def static(edge,distance,precision=2e-9):
    ground,eigen,_=background(False,edge)
    grid=np.unique(np.r_[np.linspace(0.,edge,801),[] if distance is None or distance>=edge else [distance]])
    def rhs(rad,values):
        amp,_,potential,_=ground(rad)
        shape,slope,induced,grad=values
        return np.stack((slope,2*((potential-eigen)*shape+amp*(induced-factor(rad,distance))),grad,2*amp*shape))
    def bc(left,right):
        return np.array([left[1],left[3],right[0],edge*right[3]+5*right[2]])
    result=solve_bvp(rhs,bc,grid,np.zeros((4,len(grid))),S=np.diag([0.,-6.,0.,-6.]),tol=precision,bc_tol=1e-12,max_nodes=15000)
    assert result.success,result.message
    return result.sol

def response(edge,distance):
    data=static(edge,distance)
    axis,weights=gauss(edge,240)
    amp=background(False,edge)[0](axis)[0]
    shape,_,_,_=data(axis)
    moment=.4*np.dot(weights,axis**6*amp*shape)
    external=-edge**5*data(edge)[2]
    freq,intr,coup,pieces,fixed=strengths(edge,96,distance)
    return dict(edge=edge,distance_scale=distance or "long_tide",static_moment=moment,external_moment=external,
                mode_sum=sum(pieces),positive_fixed_field_response=fixed,fundamental_fraction=pieces[0]/sum(pieces),
                quadrature_check=abs(external/moment-1),independent_check=abs(sum(pieces)/moment-1))

def normal_bvp(edge):
    roots,ham,gravity,root,inv,freq,states=spectral(edge,96)
    grid=np.linspace(0.,edge,701)
    raw=radial_basis(2,roots,edge,grid)
    norm=np.sqrt(.5*edge**3*spherical_jn(3,roots)**2)
    origin=(roots/edge)**2/(15*norm)
    def seed(coeff):
        shape=np.r_[origin@coeff,(raw[1:]@coeff)/grid[1:]**2]
        return shape,np.gradient(shape,grid)
    pshape,pgrad=seed(root@states[:,0])
    qshape,qgrad=seed(freq[0]*inv@states[:,0])
    guess=np.stack((pshape,pgrad,qshape,qgrad,np.zeros_like(grid),np.zeros_like(grid)))/pshape[0]
    ground,eigen,_=background(False,edge)
    def rhs(rad,values,level):
        amp,_,pot,_=ground(rad)
        pf,pg,qf,qg,field,grad=values
        return np.stack((pg,2*((pot-eigen)*pf+amp*field-level[0]*qf),qg,2*((pot-eigen)*qf-level[0]*pf),grad,2*amp*pf))
    def bc(left,right,level):
        return np.r_[left[[1,3,5]],left[0]-1.,right[0],right[2],edge*right[5]+5*right[4]]
    result=solve_bvp(rhs,bc,grid,guess,p=[freq[0]],S=np.diag([0.,-6.,0.,-6.,0.,-6.]),tol=3e-9,bc_tol=2e-12,max_nodes=14000)
    assert result.success,result.message
    return result.sol,float(result.p[0])

def establish(create):
    guard()
    checks=[]
    for edge in (24.,30.,42.):
        sol,omega=normal_bvp(edge)
        ground,eigen,_=background(False,edge)
        mass=edge**2*ground(edge)[3]
        stat=response(edge,None)
        for count in (48,96):
            freq,_,_,_,_=strengths(edge,count,None)
            checks.append(dict(edge=edge,radial_basis=count,numerical_omega=freq[0],bvp_omega=omega,second=freq[1],third=freq[2],
                               fixed_field_omega=eigh(spectral(edge,count)[1],eigvals_only=True)[0],
                               threshold=-eigen,static_alpha=stat["static_moment"],mass=mass,
                               invariant_love=mass**5*stat["static_moment"]/3.,method_delta=abs(freq[0]/omega-1)))
    curves=[response(30.,dist) for dist in (None,1.,2.,3.,4.,6.,8.,12.,18.)]
    rows=table("isolated-checks.csv",checks,create)
    table("finite-profile.csv",curves,create)
    assert all(row["method_delta"]<TOL for row in rows)
    assert all(max(row["quadrature_check"],row["independent_check"])<TOL for row in curves)
    return rows,curves

if __name__=="__main__":
    rows,curves=establish(sys.argv[1:]==["create"])
    print(rows[-1]);print(curves)

