import sys
from satellite import GRIDS, history, table


def run(create):
    rows, fields, components = [], [], []
    for grid, parameters in (("edge72",(72.,180,208,1,6)),("edge96",(96.,240,208,1,6))):
        GRIDS[grid] = parameters
        try:
            for label in ("illustrative","central_cap"):
                snap, local, tensor=history(label,grid,(0.,))
                rows.extend(snap)
                fields.extend(local)
                components.extend(tensor)
        finally:
            del GRIDS[grid]
    table("lmc-extended-box.csv",rows,create)
    table("lmc-extended-field.csv",fields,create)
    table("lmc-extended-tensors.csv",components,create)
    return rows,fields,components


if __name__=="__main__":
    rows,_,_=run(sys.argv[1:]==["create"])
    for row in rows:
        if row["preparation"]=="unexcited":
            print(row["grid"],row["scale"],row["nearest_axis_angle_deg"])

