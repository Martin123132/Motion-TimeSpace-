import io
import sys
from functools import lru_cache
from tide import HERE, TOL, np, gauss, radial_basis, background, spectral, strengths, static, table, guard
from breathing import SCALE, LENGTH, MSUN, KG, SEC, YEAR, parsec
from cap_test import budgets
from orbit_source import orbit_bytes
from scipy.special import roots_legendre
from scipy.interpolate import CubicSpline, CubicHermiteSpline

MASS = 12.657e10
RADIUS = 8.7 * (np.sqrt(MASS / 1.7e10) - 1.)
KMS = YEAR * 1e9 / parsec
GRIDS = {"short_box": (30.,64,96,2,4), "dense": (30.,96,160,1,6), "outer": (48.,128,200,1,6)}
MOMENTS = ((0,0),(1,1),(2,2),(0,1),(0,2),(1,2))


def tensors():
    items = [np.diag([1.,-1,0])/np.sqrt(2.), np.diag([-1.,-1.,2.])/np.sqrt(6.)]
    for left,right in MOMENTS[3:]:
        shear = np.zeros((3,3))
        shear[left,right] = shear[right,left] = 1/np.sqrt(2.)
        items.append(shear)
    return np.array(items)


BASIS = tensors()


def angular_check():
    angle, weights = roots_legendre(12)
    azimuth = np.arange(32)*np.pi/16
    unit = np.stack(np.broadcast_arrays(np.sqrt(1-angle[:,None]**2)*np.cos(azimuth),
                                         np.sqrt(1-angle[:,None]**2)*np.sin(azimuth),
                                         angle[:,None]),axis=-1).reshape(-1,3)
    measure = np.repeat(weights/64,32)
    fields = np.einsum("bi,jik,bk->bj",unit,BASIS,unit)
    assert np.max(abs((fields.T*measure)@fields - (2/15)*np.eye(5)))<1e-14
    return fields,measure


@lru_cache(None)
def orbit(stride):
    raw = np.loadtxt(io.BytesIO(orbit_bytes()))[::-1]
    assert raw.shape == (5001,19) and np.allclose(raw[:,0],np.arange(5001)/1000,atol=1e-14,rtol=0)
    time = raw[:,0]
    rel = raw[:,7:10]-raw[:,13:16]
    speed = raw[:,10:13]-raw[:,16:19]
    assert np.linalg.norm(rel[0])>700 and 48<np.linalg.norm(rel[-1])<55
    error = np.linalg.norm((rel[2:]-rel[:-2])/.002/KMS-speed[1:-1],axis=1)
    assert error.max()<.04
    return CubicHermiteSpline(time[::stride],rel[::stride],speed[::stride]*KMS), np.linalg.norm(rel,axis=1)


@lru_cache(None)
def quadrature(order):
    node,weight = roots_legendre(order)
    return (node+1)/2,weight/2


def positive_profile(distance,rad,soft,order=32):
    if soft == 0:
        return np.minimum(rad,distance)**2 / np.maximum(rad,distance)**3
    node,weight = quadrature(order)
    rad = np.asarray(rad)[:,None]
    lower,upper = abs(distance-rad),distance+rad
    width = 2*np.minimum(distance,rad)
    sep = lower+width*node
    product = rad*distance
    sin2 = (width*(1-node))*(upper+sep)*(width*node)*(sep+lower)/(4*product**2)
    return (5/16*product*width*(sin2**2*(3*sep+soft)/(sep**2*(sep+soft)**3))@weight).ravel()


def unit_scales(label):
    length = SCALE*LENGTH/parsec if label=="illustrative" else budgets("central_cap")[0]
    scale = length*parsec/LENGTH
    return length/1000, KG/(scale*MSUN), SEC*scale**2/(1e9*YEAR)


def history(label,grid,starts=(0.,2.5,4.),observer=None):
    guard()
    edge,count,knots,stride,order = GRIDS[grid]
    length,massunit,timeunit = unit_scales(label)
    track,distances = orbit(stride)
    roots,_,_,root,inv,freq,states = spectral(edge,count)
    axis,weight = gauss(edge,2*count)
    wave = background(False,edge)[0](axis)[0]
    base = axis[:,None]*radial_basis(2,roots,edge,axis)
    folded = (states.T@root@base.T)*(weight*axis*wave)
    readout = folded@axis**2
    mass = np.dot(weight,(axis*wave)**2)
    inertia = np.dot(weight,axis**4*wave**2)
    scaledmass = MASS/massunit
    soft = RADIUS/length
    logdist = np.linspace(np.log(.99*distances.min()/length),np.log(1.01*distances.max()/length),knots)
    profiles = np.array([positive_profile(np.exp(logd),axis,soft) for logd in logdist])
    couples = CubicSpline(logdist,(profiles@folded.T)*scaledmass)
    def driver(times):
        vec = track(times)
        dist = np.linalg.norm(vec,axis=-1)
        unit = vec/dist[...,None]
        parts = np.einsum("...i,jik,...k->...j",unit,BASIS,unit)
        return couples(np.log(dist/length)), parts
    today = track(5.)
    distance = np.linalg.norm(today)
    direction = today/distance
    speed = track(5.,1)/KMS
    outward = speed@direction
    transverse = np.linalg.norm(speed-outward*direction)
    scaled = distance/length
    tide = scaledmass*(3*scaled+soft)/(3*scaled*(scaled+soft)**3)
    profile = positive_profile(scaled,axis,soft)
    static_long = static(edge,None)(axis)[0]*axis**2
    q_direct = .4*scaledmass*np.dot(weight,axis**2*wave*static_long*profile)
    coupled,orient = driver(5.)
    q_static = .4*np.dot(readout,coupled/freq**2)
    eq = (coupled/freq**2)[:,None]*orient
    pt = .4*scaledmass*np.sum(readout*(folded@positive_profile(scaled,axis,0))/freq**2)
    alpha = .4*np.sum((readout/freq)**2)
    assert abs(q_direct/q_static-1)<TOL
    analytic = (RADIUS+3*distance)/(3*distance*(distance+RADIUS)**3)
    assert np.isclose(tide,scaledmass*length**3*analytic)
    snapshots=[]; fields=[]; components=[]
    def read(tag,start,coords,vel):
        coeff = root@states@coords
        imag = inv@states@vel
        signal = .4*(readout@coords)
        tensor = np.einsum("a,aij->ij",signal,BASIS)
        vals,axes = np.linalg.eigh(tensor)
        lag = np.degrees(np.arccos(np.clip(abs(axes[:,-1]@direction),0,1)))
        amp = np.sqrt(1.5)*np.linalg.norm(signal)
        norm = np.sqrt(.3*(np.sum(coeff**2)+np.sum(imag**2))/mass)
        row = dict(scale=label,grid=grid,preparation=tag,start_Gyr=start,distance_kpc=distance,
                   v_radial_kms=outward,v_transverse_kms=transverse,mode_period_Gyr=2*np.pi*timeunit/freq[0],
                   rotation_rate_over_mode=2*transverse*KMS/distance*timeunit/freq[0],
                   Qnorm_over_inertia=amp/inertia,amplitude_over_equilibrium=amp/q_static,
                   nearest_axis_angle_deg=lag,field_perturbation_norm=norm,
                   extended_over_point_Qeq=q_static/pt,finite_wave_over_central_tide_Qeq=q_static/(alpha*tide),
                   projected_static_reciprocity=abs(q_direct/q_static-1))
        snapshots.append(row)
        if observer is not None:
            observer(label,grid,tag,start,edge,count,length,timeunit,roots,coeff)
        for (left,right) in MOMENTS:
            components.append(dict(scale=label,grid=grid,preparation=tag,start_Gyr=start,i=left,j=right,
                                   quadrupole_over_inertia=tensor[left,right]/inertia))
        for rphys in (8.275,17.58,50.):
            site=rphys/length
            sample,ww=gauss(edge,2*count,(site,))
            basis=radial_basis(2,roots,edge,sample)
            amp0=background(False,edge)[0](sample)[0]
            inner=sample<site
            delta=amp0[:,None]*(basis@coeff)
            enclosed=(ww[inner]*sample[inner]**4)@delta[inner]
            exterior=(ww[~inner]/sample[~inner])@delta[~inner]
            potential=-.4*(enclosed/site**3+site**2*exterior)
            slope=.4*(3*enclosed/site**4-2*site*exterior)
            quadrupole=1.5*np.einsum("a,aij->ij",potential,BASIS)
            radial=1.5*np.einsum("a,aij->ij",slope,BASIS)
            vmax=(length*1e3*parsec/(timeunit*1e9*YEAR))**2
            fields.append(dict(scale=label,grid=grid,preparation=tag,start_Gyr=start,radius_kpc=rphys,
                               potential_max_minus_min_m2s2=np.ptp(np.linalg.eigvalsh(quadrupole))*vmax,
                               instantaneous_equal_radius_clock_contrast=np.ptp(np.linalg.eigvalsh(quadrupole))*vmax/299792458.**2,
                               inward_field_along_satellite_m_s2=(direction@radial@direction)*vmax/(length*1e3*parsec),
                               inward_field_axis_span_m_s2=np.ptp(np.linalg.eigvalsh(radial))*vmax/(length*1e3*parsec)))
    read("instantaneous_equilibrium",5.,eq,np.zeros_like(eq))
    node,wq=quadrature(order)
    prefix=np.zeros((count,5),dtype=complex)
    for start,stop in reversed(list(zip(starts,(*starts[1:],5.)))):
        times=np.arange(round(start*1000),round(stop*1000),stride)/1000
        for batch in np.array_split(times,max(1,(len(times)+199)//200)):
            for frac,ww in zip(node,wq):
                stamp=batch+stride*.001*frac
                vals,orient=driver(stamp)
                phase=np.exp(1j*(5.-stamp[:,None])/timeunit*freq)
                prefix+=(vals*phase).T@orient*(stride*.001*ww/timeunit)
        for prep in ("unexcited","static_at_rest"):
            result=prefix.copy()
            if prep=="static_at_rest":
                first,orient=driver(start)
                result+=(1j*np.exp(1j*(5.-start)/timeunit*freq)*first/freq)[:,None]*orient
            read(prep,start,result.imag/freq[:,None],result.real)
    return snapshots,fields,components


def run(create):
    angular_check()
    rows=[];fields=[];components=[]
    for label in ("illustrative","central_cap"):
        for grid in GRIDS:
            snap,newfields,parts=history(label,grid)
            rows.extend(snap);fields.extend(newfields);components.extend(parts)
    table("lmc-response.csv",rows,create)
    table("lmc-local-field.csv",fields,create)
    table("lmc-tensors.csv",components,create)
    return rows,fields,components


if __name__=="__main__":
    rows,_,_=run(sys.argv[1:]==["create"])
    for row in rows:
        if row["grid"]=="outer" and row["start_Gyr"] in (0.,5.):
            print(row)

