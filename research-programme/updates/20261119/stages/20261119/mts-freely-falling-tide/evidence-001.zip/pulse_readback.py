from field_evolution import grid_system
from forecast import EDGE, AMPLITUDE, GRIDS, freeze
from tide import HERE, TOL, background, bridge, np, table
import sys


def read(tag, kind, level, arm):
    path = HERE / f"{kind}-{tag}-{level:03d}-{arm}.npz"
    with np.load(path, allow_pickle=False) as packet:
        assert packet["receipt"].item().decode() == bridge.sha(HERE / "forecast.json")
        assert packet["rest"] < 4e-14
        rows = packet["rows"]
        assert np.array_equal(rows[:, 0], np.arange(41) / 32)
        assert np.max(abs(rows[:, -1])) < TOL
        return rows, packet["snapshots"], float(packet["number"])


def run(create):
    predicted = freeze(False)
    shells, uniforms = [], []
    for tag in GRIDS:
        rad, angle, _, ground, _, _, spatial, _, massint, *_ = grid_system(tag, "uniform", 1.)
        uniform, states, mass = read(tag, "uniform", 100, "plus")
        arms = {(level, sign): read(tag, "shell", level, sign)[0] for level in (100, 50) for sign in ("plus", "minus")}
        for idx, expected in enumerate(predicted):
            row_idx = 32 + idx * 4
            row = uniform[row_idx]
            xref, vref = expected["uniform_position"], expected["uniform_velocity"]
            moved = np.sqrt(rad[:, None]**2 + xref**2 - 2 * rad[:, None] * angle * xref)
            translated = (rad[:, None] * background(False, EDGE)[0](np.minimum(moved.ravel(), EDGE))[0].reshape(moved.shape))**2
            translated[moved > EDGE] = 0.
            actual = abs(ground[:, None] + spatial(states[idx]))**2
            motion = massint(abs(translated - ground[:, None]**2))
            diagnostics = dict(position_error=abs(row[3]/xref-1), speed_error=abs(row[4]/vref-1),
                               intrinsic_Q_fraction=abs(row[7])/(mass*xref**2),
                               heat_over_bulk=abs(row[6])/(.5*mass*vref**2),
                               density_error_over_displaced_density=massint(abs(actual-translated))/motion,
                               energy_work_error=abs(row[5]/row[8]-1))
            uniforms.append(dict(grid=tag, coast=expected["coast"], **diagnostics, pass_all=max(diagnostics.values())<TOL))
            for col, label, parity in [(1,"Q2_per_unit_tide",-1),(2,"Q2dot_per_unit_tide",-1),(5,"energy_per_tide_squared",1),(8,"energy_per_tide_squared",1)]:
                values = [(arms[level,"plus"][row_idx,col]+parity*arms[level,"minus"][row_idx,col])/
                          (2*(AMPLITUDE*level/100)**(2 if parity==1 else 1)) for level in (100,50)]
                extrap = 2*values[1]-values[0]
                err = abs(extrap/expected[label]-1)
                shells.append(dict(grid=tag, coast=expected["coast"], observable=label if col!=8 else "source_work", full=values[0],
                                   half=values[1], isolated_limit=extrap, prediction=expected[label], own_scale_error=err, passes=err<TOL))
    table("shell-readback.csv",shells,create)
    table("uniform-readback.csv",uniforms,create)
    return uniforms,shells


if __name__=="__main__":
    uniforms,shells=run(sys.argv[1:]==["create"])
    for row in uniforms[::3]+shells[-12:]:
        print(row)

