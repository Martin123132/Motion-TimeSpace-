import contextlib
import shutil
import sys
import tempfile
import io
from pathlib import Path
from tide import HERE, bridge, table
import field_evolution


def run(create):
    rows=[]
    cases=(("uniform",1.,1),("shell",1.,1),("shell",1.,-1),("shell",.5,1),("shell",.5,-1))
    original=field_evolution.HERE
    try:
        with tempfile.TemporaryDirectory(prefix="mts-tidal-replay-",dir=HERE.parent) as temp:
            destination=Path(temp)
            assert destination.parent==HERE.parent and destination.name.startswith("mts-tidal-replay-")
            shutil.copyfile(HERE/"forecast.json",destination/"forecast.json")
            field_evolution.HERE=destination
            for kind,ratio,sign in cases:
                with contextlib.redirect_stdout(io.StringIO()):
                    field_evolution.simulate("fine",kind,ratio,sign)
                name=f"{kind}-fine-{round(100*ratio):03d}-{'plus' if sign==1 else 'minus'}.npz"
                fresh=bridge.sha(destination/name)
                saved=bridge.sha(HERE/name)
                assert fresh==saved
                rows.append(dict(packet=name,saved_sha256=saved,replayed_sha256=fresh))
    finally:
        field_evolution.HERE=original
    assert not destination.exists()
    return table("nonlinear-replay.csv",rows,create)


if __name__=="__main__":
    print(len(run(sys.argv[1:]==["create"])),"matched archives")

