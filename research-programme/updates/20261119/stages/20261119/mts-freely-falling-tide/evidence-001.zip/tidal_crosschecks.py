import csv
import sys
from satellite import MASS,RADIUS,MOMENTS,BASIS,positive_profile,orbit,angular_check,unit_scales,quadrature
from field_evolution import grid_system
from pulse_readback import read
from tide import HERE,TOL,np,table,gauss,background,radial_basis,spectral
from scipy.integrate import solve_ivp
from scipy.interpolate import CubicSpline
from scipy.special import roots_legendre,eval_legendre


def signed_projection(dist,axis,soft):
    sample,weight=quadrature(40)
    rad=axis[:,None]
    spread=2*np.minimum(dist,rad)
    low=abs(dist-rad)
    sep=low+spread*sample
    mu=1-spread*sample*(sep+low)/(2*rad*dist)
    middle=np.hypot(rad,dist)
    delta=(2*rad*dist)*mu/(middle+sep)
    remainder=(delta/(middle+soft))**2*(.5/middle+1/(sep+soft))
    return ((2.5*spread*sep/(rad*dist)*eval_legendre(2,mu)*remainder)@weight).ravel()


def tensor_controls():
    angular_check()
    azimuth=np.arange(48)*np.pi/24
    mu,wmu=roots_legendre(18)
    xyz=np.stack(np.broadcast_arrays(np.sqrt(1-mu[:,None]**2)*np.cos(azimuth),np.sqrt(1-mu[:,None]**2)*np.sin(azimuth),mu[:,None]),-1).reshape(-1,3)
    weights=np.repeat(wmu/96,48)
    project=xyz[:,:,None]*xyz[:,None,:]-np.eye(3)/3
    rad,angle,_,ground,_,_,spatial,_,_,_,_,_=grid_system("fine","shell",1.)
    _,weight=gauss(30.,64,(3.,))
    bank,states,_=read("fine","shell",100,"plus")
    axes=np.array([[1,0,0],[0,1,0],[1,1,0],[1,0,1],[0,1,1]],float)
    axes/=np.linalg.norm(axes,axis=1)[:,None]
    assert np.linalg.matrix_rank(np.einsum("bi,jik,bk->bj",axes,BASIS,axes))==5
    for idx,snap in enumerate(states):
        delta=spatial(snap)
        profile=(weight*rad**2)@(2*ground[:,None]*delta.real+abs(delta)**2)
        coeff=np.polynomial.legendre.legfit(angle,profile,8)
        qref=bank[32+idx*4,1]
        for which,direction in enumerate(axes):
            rotated=np.polynomial.legendre.legval(xyz@direction,coeff)
            measured=np.einsum("b,bij->ij",weights*rotated,project)
            predicted=qref*(np.outer(direction,direction)-np.eye(3)/3)
            err=np.linalg.norm(measured-predicted)/np.linalg.norm(predicted)
            yield dict(test="rotation_of_saved_density",case=f"{idx}_{which}",relative_error=err,passes=err<TOL)


def angular_controls():
    for soft in (0.,.8,2.2):
        for dist in (3.,10.,60.):
            rad=dist*np.array([1e-4,.15,.53,.9999,1.,1.0003,2.,30.])
            pred=positive_profile(dist,rad,soft)
            actual=signed_projection(dist,rad,soft)
            err=max(abs(actual/pred-1))
            yield dict(test="independent_satellite_projection",case=f"{soft}_{dist}",relative_error=err,passes=err<TOL)


def load_rows(name):
    with (HERE/name).open(encoding="utf8",newline="") as stream:
        return list(csv.DictReader(stream))


def matrix_reference(label,grid="dense",prep="unexcited",start=0.,filename="lmc-tensors.csv"):
    result=np.zeros((3,3))
    rows=[row for row in load_rows(filename) if row["preparation"]==prep and float(row["start_Gyr"])==start and row["scale"]==label and row["grid"]==grid]
    assert len(rows)==6
    for row in rows:
        left,right=int(row["i"]),int(row["j"])
        result[left,right]=result[right,left]=float(row["quadrupole_over_inertia"])
    return result


def direct_evolution(label):
    edge,count=30.,40
    roots,ham,gravity,*_=spectral(edge,count)
    axis,weights=gauss(edge,120)
    wave=background(False,edge)[0](axis)[0]
    base=axis[:,None]*radial_basis(2,roots,edge,axis)
    folded=base.T*(weights*axis*wave)
    inertia=np.dot(weights,axis**4*wave**2)
    quad=folded@axis**2
    length,massunit,timeunit=unit_scales(label)
    track,distances=orbit(1)
    knots=np.linspace(np.log(.99*distances.min()/length),np.log(1.01*distances.max()/length),201)
    couples=CubicSpline(knots,np.stack([folded@signed_projection(np.exp(logd),axis,RADIUS/length) for logd in knots])*MASS/massunit)
    def rhs(stamp,coordinates):
        real,imag=coordinates.reshape(2,count,6)
        pos=track(stamp)
        distance=np.linalg.norm(pos)
        unit=pos/distance
        wmat=np.outer(unit,unit)-np.eye(3)/3
        force=couples(np.log(distance/length))[:,None]*np.array([wmat[left,right] for left,right in MOMENTS])
        return np.concatenate((ham@imag,force-(ham+gravity)@real)).ravel()/timeunit
    state=solve_ivp(rhs,(0.,5.),np.zeros(12*count),method="DOP853",atol=1e-13,rtol=2e-10,t_eval=[5.])
    assert state.success and state.t[-1]==5.
    result=np.zeros((3,3))
    for (left,right),val in zip(MOMENTS,.4*quad@state.y[:,-1].reshape(2,count,6)[0]/inertia):
        result[left,right]=result[right,left]=val
    truth=matrix_reference(label)
    err=np.linalg.norm(result-truth)/np.linalg.norm(truth)
    return dict(test="cartesian_time_evolution",case=label,relative_error=err,passes=err<TOL)


def comparison():
    rows=[]
    for label in ("illustrative","central_cap"):
        for small,large in (("short_box","dense"),("dense","outer"),("outer","edge72"),("edge72","edge96")):
            def source(which):
                return "lmc-extended-" if which.startswith("edge") else "lmc-"
            for prep in ("unexcited","static_at_rest","instantaneous_equilibrium"):
                start=5. if prep=="instantaneous_equilibrium" else 0.
                def section(which):
                    m=matrix_reference(label,which,prep,start,source(which)+"tensors.csv")
                    data=[row for row in load_rows(source(which)+("field.csv" if which.startswith("edge") else "local-field.csv")) if row["scale"]==label and row["grid"]==which and row["preparation"]==prep and float(row["start_Gyr"])==start]
                    assert len(data)==3
                    return m,data
                old,oldfields=section(small)
                new,newfields=section(large)
                err=np.linalg.norm(old-new)/np.linalg.norm(new)
                rows.append(dict(scale=label,grids=small+"_"+large,prep=prep,metric="tensor_norm_error",kpc="",own_scale_error=err,passes=err<TOL))
                for arow,brow in zip(oldfields,newfields):
                    assert arow["radius_kpc"]==brow["radius_kpc"]
                    for key in ("instantaneous_equal_radius_clock_contrast","inward_field_along_satellite_m_s2","inward_field_axis_span_m_s2"):
                        err=abs(float(arow[key])/float(brow[key])-1)
                        rows.append(dict(scale=label,grids=small+"_"+large,prep=prep,metric=key,kpc=arow["radius_kpc"],own_scale_error=err,passes=err<TOL))
    return rows


def run(create):
    rows=[*tensor_controls(),*angular_controls(),*[direct_evolution(label) for label in ("illustrative","central_cap")]]
    table("independent-checks.csv",rows,create)
    changes=table("domain-checks.csv",comparison(),create)
    return rows,changes


if __name__=="__main__":
    rows,changes=run(sys.argv[1:]==["create"])
    print(rows[-2:]); print("retained domain misses",sum(not row["passes"] for row in changes))

