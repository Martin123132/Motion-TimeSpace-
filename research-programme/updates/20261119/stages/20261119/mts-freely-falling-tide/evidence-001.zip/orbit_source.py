import hashlib
import sys
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parent
FILE = "orphan_orbit.txt"
URL = "https://zenodo.org/records/2661108/files/orphan_orbit.txt?download=1"
SIZE = 1283137
MD5 = "760d4fbd486b4bcec03a70292a399854"


def orbit_bytes(fetch=False):
    path = ROOT / FILE
    if fetch and not path.exists():
        with urllib.request.urlopen(URL, timeout=30) as stream:
            content = stream.read(SIZE + 1)
        assert len(content) == SIZE and hashlib.md5(content).hexdigest() == MD5
        with path.open("xb") as stream:
            stream.write(content)
    content = path.read_bytes()
    assert len(content) == SIZE and hashlib.md5(content).hexdigest() == MD5
    return content


if __name__ == "__main__":
    print(orbit_bytes(sys.argv[1:] == ["fetch"]).splitlines()[:3])

