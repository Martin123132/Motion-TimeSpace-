from comparison import gauge, save_table, contrast
from clock_channels import *


def primitive(tt,field):
    integ=spline(tt,field).antiderivative()
    return integ(tt)-integ(tt[:1])


def split(basis,case,mesh):
    guard()
    output=archive_path("tidal",basis,case,"tangent",mesh)
    if output.exists():
        return
    src=archive_path("history",basis,case,"tangent",mesh)
    data=bridge.read(src)
    tt=data["time"]
    raw=data["bank"]
    eps=data["strength"].item().imag
    rr=raw.real
    dv=raw.imag/eps
    aa=1+rr[:,0]
    norm,grad,hh,rest,flux,w=[rr[:,idx] for idx in range(6,12)]
    mat=material(hh,norm,grad,rest*np.sqrt(1+w*w),w,flux,basis)
    explicit=mat[4]-mat[5]+2*mat[6]
    matter=dv[:,2]-dv[:,4]+2*(dv[:,5]+dv[:,2]-dv[:,4])/2
    parts={"explicit":aa*explicit,"redistributed":aa*matter,"mass":aa*(dv[:,12]-matter-explicit),
           "radial_length":dv[:,0]*rr[:,12],"launch":0*aa}
    output_data={}
    for name,tide in parts.items():
        kc=primitive(tt,tide)+(dv[:1,1] if name=="launch" else 0)
        axis=-primitive(tt,kc)+(dv[:1,0] if name=="launch" else 0)
        packed=rr[:,:2]+1j*np.stack((axis,kc),axis=1)
        prediction=rays(dict(time=tt,space=data["space"],bank=packed,z=np.array(1j)))
        for chan in CHANNELS:
            output_data[name+"_"+chan]=prediction["d"+chan]
    bridge.archive(output,**output_data,source=bridge.sha(src))
    print(output.name,flush=True)


def report(mesh):
    rows=[]
    stats=[]
    for basis in BASES:
        event,quiet=[bridge.read(archive_path("tidal",basis,case,"tangent",mesh)) for case in ("event","quiet")]
        reference=contrast(basis,"tangent",mesh)
        for chan in CHANNELS:
            parts={name:event[name+"_"+chan]-quiet[name+"_"+chan] for name in ("explicit","redistributed","mass","radial_length","launch")}
            actual=reference["metric_"+chan]
            combined=sum(parts.values())
            gauge(rows,"integrated_einstein_tide",basis,chan,combined,actual)
            ix=int(np.argmax(abs(actual)))
            stats.append(dict(basis=basis,channel=chan,emission=float(EMIT[ix]),signed_metric=float(actual[ix]),
                          **{name:float(series[ix]) for name,series in parts.items()}))
    save_table(f"tidal-checks-{mesh}.csv",rows)
    save_table(f"tidal-components-{mesh}.csv",stats)


if __name__=="__main__":
    mesh=int(sys.argv[1])
    for basis in BASES:
        for case in ("event","quiet"):
            split(basis,case,mesh)
    report(mesh)

