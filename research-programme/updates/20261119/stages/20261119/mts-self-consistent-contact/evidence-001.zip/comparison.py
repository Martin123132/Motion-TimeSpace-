from clock_channels import *
from action_checks import exterior
import csv


def readclock(basis,case,level,mesh):
    return bridge.read(archive_path("clock",basis,case,level,mesh))


def contrast(basis,level,mesh):
    event,quiet=[readclock(basis,case,level,mesh) for case in ("event","quiet")]
    return {key:event[key]-quiet[key] for key in event if key!="source"}


def gauge(rows,test,basis,channel,tested,reference):
    amplitude=float(np.max(abs(reference)))
    error=float(np.max(abs(tested-reference)))
    relative=error/amplitude if amplitude else None
    rows.append(dict(test=test,basis=basis,channel=channel,reference=float(reference[int(np.argmax(abs(reference)))]),
                     absolute=error,relative=relative,pass_unchanged=relative<=TOL if relative is not None else error==0))


def waveform(mesh=160,refined=320,finite=True):
    rows=[]
    for basis in BASES:
        sources=contrast(basis,"tangent",mesh)
        coarse=contrast(basis,"tangent",80)
        fine=contrast(basis,"tangent",refined) if refined!=mesh else sources
        for chan in CHANNELS:
            for part in ("metric","probe","total"):
                key=part+"_"+chan
                gauge(rows,"grid_80_to_160",basis,key,coarse[key],sources[key])
                if refined!=mesh:
                    gauge(rows,"grid_160_to_320",basis,key,sources[key],fine[key])
        ordinary=readclock(basis,"ordinary","tangent",mesh)
        exact=exterior(basis)
        all_exact=exterior(basis,probe=True)
        for chan in CHANNELS:
            gauge(rows,"ordinary_static_metric",basis,chan,ordinary["metric_"+chan],exact[chan].imag/.125)
            gauge(rows,"ordinary_static_base",basis,chan,ordinary["base_"+chan],exact[chan].real)
            gauge(rows,"ordinary_static_total",basis,chan,ordinary["total_"+chan],all_exact[chan].imag/.125)
            gauge(rows,"ordinary_static_probe",basis,chan,ordinary["probe_"+chan],(all_exact[chan]-exact[chan]).imag/.125)
        for name,em in (("out",EMIT),("echo",EMIT[MASK])):
            deriv={}
            for case in ("event","quiet"):
                raw=readclock(basis,case,"tangent",mesh)
                deriv[case]=-spline(em,raw["metric_"+name+"_delay"]).derivative()(em)*(1+raw["base_"+name])**2
            gauge(rows,"metric_frequency_from_pulse_spacing",basis,name,deriv["event"]-deriv["quiet"],sources["metric_"+name])
        if finite:
            for plus,minus,factor in (("plus","minus",1.),("halfplus","halfminus",.5)):
                one,two=[contrast(basis,level,mesh) for level in (plus,minus)]
                for chan in CHANNELS:
                    for part in ("metric","probe","total"):
                        key=part+"_"+chan
                        gauge(rows,"independent_real_"+plus,basis,key,(one[key]-two[key])/factor,sources[key])
    return rows


def ledger(mesh):
    rows=[]
    for basis in BASES:
        states={}
        for case in CASES:
            with np.load(archive_path("history",basis,case,"tangent",mesh),allow_pickle=False) as saved:
                states[case]=saved["checks"]
                times=saved["time"]
        states["event_minus_quiet"]=states["event"]-states["quiet"]
        for name,data in states.items():
            for deriv,val in (("base",data.real),("tangent",data.imag/.125)):
                for idx in range(3):
                    mat=val[:,idx,:]
                    for typ,start in (("energy",0),("momentum",3)):
                        primitive=spline(times,mat[:,start+1]+mat[:,start+2]).antiderivative()
                        delta=mat[:,start]-mat[0,start]
                        gauge(rows,f"{typ}_{idx}_{deriv}_{mesh}",basis,name,primitive(times)-primitive(times[0]),delta)
                    for label,err,scale in (("mass_reconstruction",6,7),("hamiltonian_shell",8,9)):
                        gauge(rows,f"{label}_{idx}_{deriv}_{mesh}",basis,name,mat[:,scale]+mat[:,err],mat[:,scale])
    return rows


def save_table(name,rows):
    with (HERE/name).open("x",newline="") as handle:
        writer=csv.DictWriter(handle,fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


if __name__=="__main__":
    for arg in sys.argv[1:]:
        if arg.startswith("weak"):
            mesh=int(arg.split(":")[1])
            save_table(f"weak-balance-{mesh}.csv",ledger(mesh))
        elif arg=="final":
            save_table("clock-budgets.csv",waveform())
        else:
            rows=waveform(refined=160,finite=False)
            print(*[row for row in rows if not row["pass_unchanged"]],sep="\n")

