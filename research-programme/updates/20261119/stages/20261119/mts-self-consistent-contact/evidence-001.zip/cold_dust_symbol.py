from contact_model import *
import sympy as sy
from scipy.linalg import expm


def run():
    guard()
    density,velocity,coupling=sy.symbols("n w g",positive=True)
    lorentz=sy.sqrt(1+velocity**2)
    en=density*lorentz
    press=density*velocity**2/lorentz
    flux=density*velocity
    for invariant in (en**2+press**2-2*flux**2,(-en+press)**2):
        assert sy.simplify(invariant-density**2/lorentz**2)==0
    ham=en-coupling*density**2/(4*lorentz**2)
    nn=sy.diff(ham,density,2).subs(velocity,0)
    ww=sy.diff(ham,velocity,2).subs(velocity,0)
    assert sy.simplify(nn*ww+coupling*density*(1+coupling*density/2)/2)==0
    assert sy.diff(ham,velocity,density).subs(velocity,0)==0
    launch=bridge.read(archive_path("launch","tensor","quiet","tangent"))
    state=launch["state160"].real
    n0=float(np.max(state[7]/np.sqrt(1+state[0])))
    dx=1/160
    angle=np.linspace(0,np.pi,4097)
    kstar=float(np.max((45*np.sin(angle)-9*np.sin(2*angle)+np.sin(3*angle))/(30*dx)))
    rows=[]
    for coeff in (-4.,-2.,0.,2.,4.):
        speed2=-coeff*n0/2*(1+coeff*n0/2)
        for wave in (4.,20.,80.,kstar):
            span=.24
            matrix=np.array([[0.,-wave*n0*(1+coeff*n0/2)],[-wave*coeff/2,0.]])
            state0=np.array([1.,0.])
            exact=(expm(span*matrix)@state0)[0]
            target=np.cosh(span*wave*np.sqrt(-speed2)) if speed2<0 else np.cos(span*wave*np.sqrt(speed2))
            assert abs(exact-target)<3e-13*max(1.,abs(target))
            rows.append(dict(coupling=coeff,k_eff=wave,c_squared_truncated_hamiltonian=speed2,density_amplitude_at_0p24=exact,
                             exponential_efolds_over_full_window=3.24*wave*np.sqrt(max(0.,-speed2))))
    results=dict(eulerian_canonical_density=n0,peak_resolved_stencil_k=kstar,geometry="Independent homogeneous short-wave matter symbol at frozen density. Not a fit or identification of the cause of a nonlinear radial run failing.",hamiltonian="n Gamma - (gamma1+gamma2)*n^2/(4 Gamma^2)",physical_first_order="c_dust^2=-(gamma1+gamma2)n/2",samples=rows,
                 maximum_conditional_efolds_on_this_mesh=3.24*kstar*np.sqrt(n0*(2.5523906183973274e-45+1.2761953091990767e-45)/2))
    with (HERE/"dust-stability.json").open("x") as handle:
        json.dump(results,handle,indent=2)


if __name__=="__main__":
    run()

