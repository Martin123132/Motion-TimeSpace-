from relative_arrival import clocks
from clock_channels import *
from dilute_clock import DiluteLaunch
from comparison import gauge, save_table


def run(mesh,case):
    guard()
    dest=HERE/f"dilute-relative-{mesh}-{case}.npz"
    if dest.exists():
        raise FileExistsError(dest)
    old=PRE/f"dilute-top-160-{case}.npz"
    with np.load(old,allow_pickle=False) as data:
        amplitude=float(data["z"].item().real)
    launch=DiluteLaunch()
    assert abs(amplitude/launch.actual_scale()-1)<1e-12
    cc=launch.match(amplitude) if case=="event" else 0.
    solver,state=launch.initial(mesh,amplitude,cc,.0002 if case=="event" else 0.)
    keep=(solver.x>=5.84)&(solver.x<=6.66)
    stride=int(np.ceil(.004/(.26*solver.dx)))
    step=.004/stride
    bank=[]
    for tick in range(810*stride+1):
        if tick%stride==0:
            aa=np.sqrt(1+state[0,keep])
            grad=solver.diff(state[5:6],solver.d1)[0,keep]/aa
            bank.append(np.stack((state[0,keep]/(aa+1),state[2,keep]/aa,state[6,keep],grad)))
        if tick%120==0:
            guard()
        if tick==810*stride:
            break
        def rate(v):
            return solver.rate(v,5.5)[0]
        first=rate(state)
        second=rate(state+step/2*first)
        third=rate(state+step/2*second)
        fourth=rate(state+step*third)
        state+=step/6*(first+2*second+2*third+fourth)
    strip=np.array(bank)
    assert np.isfinite(strip).all()
    raw=np.zeros((811,8,strip.shape[2]))
    raw[:,0:2]=strip[:,:2]
    raw[:,6:8]=strip[:,2:4]
    sky=clocks(mesh,case,dict(time=np.arange(811)*.004,space=solver.x[keep],bank=raw))
    bridge.archive(dest,strip=strip,space=solver.x[keep],z=amplitude,coef=cc,prior_source=bridge.sha(old),**sky)
    print(dest.name,flush=True)


def compare():
    rows=[]
    waves={}
    results={}
    for mesh in (160,320):
        event,quiet=[bridge.read(HERE/f"dilute-relative-{mesh}-{case}.npz") for case in ("event","quiet")]
        waves[mesh]={key:event[key]-quiet[key] for key in CHANNELS}
    dense=bridge.read(HERE/"relative-arrival.npz")
    scale=float(event["z"])
    for chan in CHANNELS:
        gauge(rows,"dilute_grid_160_to_320","relative_cone",chan,waves[160][chan],waves[320][chan])
        gauge(rows,"test_of_naive_dense_rescaling","relative_cone",chan,scale*dense[chan],waves[320][chan])
        arr=waves[320][chan]
        idx=int(np.argmax(abs(arr)))
        results[chan]=dict(signed_peak=float(arr[idx]),emission=float(EMIT[idx]))
    save_table("dilute-front-checks.csv",rows)
    with (HERE/"dilute-front-peaks.json").open("x") as handle:
        json.dump(dict(z=scale,density_GeV_cm3=.1,assumptions="Retained illustrative scalar mass, event shape and density. Per unit gamma1+2gamma2. Same baryons, new finite-density fields and matched exterior. These are shadow-front comparisons, not measured particles or pulsar data.",peaks=results),handle,indent=2)


if __name__=="__main__":
    for mesh in (160,320):
        for case in ("event","quiet"):
            run(mesh,case)
    compare()

