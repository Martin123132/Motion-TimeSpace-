from clock_channels import *
import csv


def qa():
    guard()
    old=json.loads((PRE/"closeout.json").read_text())
    for name,digest in old["files"].items():
        assert bridge.sha(PRE/name)==digest,name
    frozen= json.loads((HERE/"frozen.json").read_text())
    for name,digest in frozen["sources"].items():
        assert bridge.sha(HERE/name)==digest,name
    curves=list(HERE.glob("clock-*.npz"))
    for path in curves:
        history=HERE/path.name.replace("clock-","history-",1)
        with np.load(path,allow_pickle=False) as raw:
            assert raw["source"].item()==bridge.sha(history)
            assert all(np.isfinite(raw[k]).all() for k in raw if k!="source")
    for path in HERE.glob("history-*.npz"):
        vals=path.stem.split("-")
        launch=archive_path("launch",vals[1],vals[2],vals[3])
        with np.load(path,allow_pickle=False) as raw:
            assert raw["source"].item()==bridge.sha(launch)
            assert raw["time"].shape==(811,) and float(raw["time"][-1])==3.24
    for path in HERE.glob("launch-*.npz"):
        with np.load(path,allow_pickle=False) as raw:
            assert raw["protocol"].item()==bridge.sha(HERE/"PROTOCOL.md")
            assert abs(raw["root_residual"].item())<1e-19
    checks={}
    for path in sorted(HERE.glob("*.csv")):
        with path.open(newline="") as file:
            rows=list(csv.DictReader(file))
        assert rows and all(not (None in row or None in row.values()) for row in rows)
        if "pass_unchanged" in rows[0]:
            assert all(row["pass_unchanged"] in ("True","False") for row in rows)
            checks[path.name]={"rows":len(rows),"pass":sum(row["pass_unchanged"]=="True" for row in rows)}
        else:
            checks[path.name]={"rows":len(rows)}
    required={"clock-budgets.csv","weak-balance-160.csv","weak-balance-320.csv","tidal-checks-160.csv","tidal-components-160.csv","source-and-causal-checks.csv"}
    assert required<=set(checks)
    for name in ("paired-delay-plus.csv","paired-delay-wideplus.csv","relative-arrival-checks.csv","dilute-front-checks.csv","source-and-causal-checks.csv","tidal-checks-160.csv"):
        assert checks[name]["rows"]==checks[name]["pass"]
    for mesh in (160,320):
        assert checks[f"weak-balance-{mesh}.csv"]=={"rows":192,"pass":188}
    for basis in BASES:
        for case in ("event","quiet"):
            for lev in ("doubleplus","doubleminus"):
                note=json.loads((HERE/f"wide-diagnostic-{basis}-{case}-{lev}.json").read_text())
                assert (note["status"]=="stable_to_final_epoch")== (lev=="doubleminus")
                assert note["source_sha"]==bridge.sha(archive_path("launch",basis,case,lev))
        for lev in ("halfplus","halfminus","plus","minus","wideplus","wideminus"):
            row=json.loads((HERE/f"core-{basis}-{lev}.json").read_text())
            assert row["first_negative_beyond_global_resolution"] is None
    symbols=json.loads((HERE/"mixed-characteristics.json").read_text())
    assert len(symbols)==40 and all((max(abs(v) for v in row["slow_imag"])>1e-9)==(row["strength"]>0) for row in symbols)
    assert (HERE/"core-tensor-zero.json").is_file() and (HERE/"dust-stability.json").is_file()
    cases=[(basis,case,level,mesh) for basis in BASES for case in CASES for level,meshes in
           (("tangent",(80,160,320)),("step",(80,)),("plus",(160,)),("minus",(160,)),("halfplus",(160,)),("halfminus",(160,))) for mesh in meshes]
    for kind in ("clock","history"):
        extras=[] if kind=="clock" else [(basis,case,lev,160) for basis in BASES for case in ("event","quiet") for lev in ("wideplus","wideminus","doubleplus","doubleminus")
                    if not lev.startswith("double") or json.loads((HERE/f"wide-diagnostic-{basis}-{case}-{lev}.json").read_text())["status"]=="stable_to_final_epoch"]
        assert set(HERE.glob(kind+"-*.npz"))=={archive_path(kind,*case) for case in cases+extras}
    assert all((HERE/name).exists() for name in ("operator-weights.npz","operator-resolution.json","wave-cone.json","action-checks.json","RESULTS.md","REPLAY.md","DERIVATION.md"))
    assert not list(HERE.glob("*.partial"))
    return dict(previous_files=len(old["files"]),previous_sha=LOCK,frozen_sha=bridge.sha(HERE/"frozen.json"),tables=checks)


def main():
    dest=HERE/"seal.json"
    existing=json.loads(dest.read_text()) if dest.exists() else None
    state=qa()
    files={path.name:bridge.sha(path) for path in sorted(HERE.iterdir()) if path.is_file() and path!=dest}
    state["files"]=files
    if existing is not None:
        assert state==existing
    else:
        with dest.open("x") as handle:
            json.dump(state,handle,indent=2,sort_keys=True)
    print("files",len(files),"previous",state["previous_files"],"sha",bridge.sha(dest),"tables",state["tables"],flush=True)


if __name__=="__main__":
    main()

