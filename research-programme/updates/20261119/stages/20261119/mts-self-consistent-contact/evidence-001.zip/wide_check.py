from contact_model import *
from evolve_contact import run
from evolve_contact import Evolution


def watch(basis,case,level):
    guard()
    src=archive_path("launch",basis,case,level)
    mesh=160
    state=bridge.read(src)["state160"]
    solver=Evolution(mesh,basis,LEVELS[level])
    stride=int(np.ceil(.004/(.26*solver.dx)))
    dt=.004/stride
    banks,tests=[],[]
    trace=[]
    tick=0
    def sample():
        density=state[7]/(np.sqrt(1+state[0])*(1+state[1]))
        idx=int(np.argmax(abs(density)))
        return dict(time=tick*dt,rad_at_max_density=float(solver.x[idx]),max_abs_density=float(abs(density[idx])),
                    min_density=float(np.min(density)),max_abs_impulse=float(max(abs(state[8]))),
                    min_radial_metric=float(min(1+state[0])),max_abs_field=float(max(abs(state[5]))))
    finish="stable_to_final_epoch"
    try:
        with np.errstate(over="raise",invalid="raise",divide="raise"):
            for tick in range(810*stride+1):
                if tick%100==0:
                    guard()
                if tick%stride==0:
                    strip,budgets=solver.rates(state,True)
                    banks.append(strip)
                    tests.append(budgets)
                    if tick%(20*stride)==0:
                        trace.append(sample())
                if tick==810*stride:
                    break
                a=solver.rates(state)
                b=solver.rates(state+dt*a/2)
                c=solver.rates(state+dt*b/2)
                d=solver.rates(state+dt*c)
                candidate=state+dt/6*(a+2*b+2*c+d)
                if not np.isfinite(candidate).all() or min(1+candidate[0])<=0 or min(1+candidate[1])<=0:
                    raise FloatingPointError("nonfinite step or loss of positive spatial metric")
                state=candidate
    except FloatingPointError as fault:
        finish="failed numerical domain: "+str(fault)
    trace.append(sample())
    if finish=="stable_to_final_epoch":
        bridge.archive(archive_path("history",basis,case,level,mesh),bank=banks,checks=tests,time=np.arange(811)*.004,
                       space=solver.x[solver.keep],strength=LEVELS[level],source=bridge.sha(src))
    with (HERE/f"wide-diagnostic-{basis}-{case}-{level}.json").open("x") as handle:
        json.dump(dict(basis=basis,case=case,level=level,source_sha=bridge.sha(src),status=finish,time_reached=tick*dt,trace=trace),handle,indent=2)
    print(basis,case,level,finish,tick*dt,flush=True)


if __name__=="__main__":
    guard()
    assert (HERE/"frozen.json").exists() and (HERE/"REAL-DELAY-CONTROL.md").is_file()
    LEVELS.update(wideplus=2.,wideminus=-2.,doubleplus=4.,doubleminus=-4.)
    for level in (("doubleplus","doubleminus") if sys.argv[1:] else ("wideplus","wideminus","doubleplus","doubleminus")):
        for basis in BASES:
            if not all(archive_path("launch",basis,cc,level).exists() for cc in CASES):
                prepare(basis,level)
            for case in ("event","quiet"):
                if level.startswith("double"):
                    watch(basis,case,level)
                else:
                    run(160,basis,case,level)

