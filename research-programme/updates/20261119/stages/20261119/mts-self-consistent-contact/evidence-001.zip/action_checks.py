from contact_model import *
from scipy.integrate import quad
import sympy as sy


def algebra():
    hh,normal,slope,n,w,flux=sy.symbols("h pi s n w D",real=True)
    g=sy.sqrt(1+w*w)
    energy=(normal**2+slope**2+hh**2+flux**2)/2+n*g
    press=(normal**2+slope**2-hh**2-flux**2)/2+n*w**2/g
    angular=(normal**2-slope**2-hh**2+flux**2)/2
    current=n*w-normal*slope
    Z={"tensor":-(energy**2+press**2+2*angular**2-2*current**2)/4,
       "trace":-(-energy+press+2*angular)**2/4}
    fixtures=(.07,-.041,.033,.002,.32,.013)
    results={}
    for basis,expr in Z.items():
        partial=[sy.diff(expr,k) for k in (normal,slope,hh,n,w,flux)]
        boost=n*w/g*partial[3]+g*partial[4]-slope*partial[0]-normal*partial[1]
        assert sy.simplify(boost)==0
        em=expr.subs({hh:0,slope:0,normal:0,n:0})
        expect=-flux**4/4 if basis=="tensor" else 0
        assert sy.simplify(em-expect)==0
        row=material(*fixtures,basis)
        values=dict(zip((hh,normal,slope,n,w,flux),fixtures))
        target=[float(item.subs(values)) for item in partial]
        num=list(row[7:13])
        num[4]*=fixtures[3]
        assert np.allclose(num,target,atol=1e-18,rtol=3e-14)
        def ham(length,radius):
            return length*radius**2*material(fixtures[0],fixtures[1]/(length*radius**2),fixtures[2]/length,
                       fixtures[3]/(length*radius**2),fixtures[4]/length,fixtures[5]/radius**2,basis)[4]
        vary_r=-ham(1+1e-18j,1).imag/1e-18
        vary_t=-ham(1,1+1e-18j).imag/(2e-18)
        assert np.allclose([vary_r,vary_t],row[5:7],atol=1e-19,rtol=3e-14)
        results[basis]=dict(boost_identity=True,pure_em=str(em.expand()),gradient_abs_error=max(abs(np.array(num)-target)),
                            hilbert_pressure_abs_error=max(abs(np.array([vary_r,vary_t])-row[5:7])))
    return results


def mass_match(basis):
    guard()
    plain=Launch(basis,0.,False)
    coupled=Launch(basis,.125j,False)
    coef=prior.coefficient()
    gc=coupled.collar(coef)(5.5)[0].imag/.125
    dc=(plain.collar(coef+1e-8)(5.5)[0]-plain.collar(coef-1e-8)(5.5)[0])/2e-8
    expected=-gc/dc
    actual=bridge.read(archive_path("launch",basis,"event","tangent"))
    measured=actual["coef"].item().imag/.125
    err=abs(expected-measured)/abs(expected)
    assert err<TOL
    return dict(c_zero=coef,d_mass_d_c=float(dc),partial_mass_d_gamma=float(gc),dc_d_gamma_expected=float(expected),
                dc_d_gamma_measured=measured,relative=float(err),pre_splice_mass_residual=abs(actual["root_residual"].item()))


def exterior(basis,probe=False):
    strength=.125j
    tensor=strength if basis=="tensor" else 0.
    charge=.0016
    launch=bridge.read(archive_path("launch",basis,"ordinary","tangent"))
    mass=launch["outer_U"].item()-tensor*charge**4/(20*24**5)
    def deficit(rad):
        return 2*mass/rad-(charge/rad)**2+tensor*charge**4/(10*rad**6)
    delay=quad(lambda r:deficit(r)/(1-deficit(r)),6,6.5,complex_func=True,epsabs=2e-19)[0]
    orbits=[]
    for radius in SITES:
        charge_contact=tensor*charge**2/2 if probe else 0.
        deficit_clock=deficit(radius)+charge_contact*(1-deficit(radius))/radius**4
        energy=np.sqrt(1-deficit_clock)
        em1=-deficit_clock/(1+energy)
        def rates(t,state,radius=radius,energy=energy,em1=em1):
            rr=radius+state[0]
            speed=state[1]
            conform=1-charge_contact/rr**4
            grad=4*charge_contact/rr**5
            dg=2*mass/rr**2-2*charge**2/rr**3+3*tensor*charge**4/(5*rr**7)
            push=-(conform*dg+(1-deficit(rr))*grad)/(2*conform**2)-grad*speed**2/conform
            return np.array([speed,push,-(em1+conform*speed)/(energy+conform*speed),
                             -(em1-conform*speed)/(energy-conform*speed)])
        orbit=solve_ivp(rates,(0.,3.24),np.zeros(4,dtype=complex),method="DOP853",rtol=3e-14,atol=1e-20,
                         dense_output=True,max_step=.04)
        assert orbit.success
        def state(t,solution=orbit.sol,rates=rates):
            value=solution(t.real)
            return value+1j*t.imag*rates(t.real,value)
        orbits.append((energy,em1,state,radius))
    def leg(emit,direction):
        inner,outer=(0,1) if direction==1 else (1,0)
        ei,di,first,ri=orbits[inner]
        er,dr,last,rf=orbits[outer]
        launch=first(emit)
        slot=2 if direction==1 else 3
        diff=delay+0*emit
        for _ in range(6):
            diff=delay+launch[slot]-last(emit+.5+diff)[slot]
        recv=last(emit+.5+diff)
        vi=(1-charge_contact/(ri+launch[0])**4)*launch[1]
        vr=(1-charge_contact/(rf+recv[0])**4)*recv[1]
        frac=(di-dr+direction*(vi-vr))/(er+direction*vr)
        return frac,diff
    first,out_delay=leg(EMIT,1)
    mask=EMIT<=2.1
    back,back_delay=leg(EMIT[mask]+.5+out_delay[mask],-1)
    return dict(out=first,echo=first[mask]+back+back*first[mask],out_delay=out_delay,echo_delay=out_delay[mask]+back_delay)


if __name__=="__main__":
    guard()
    result=dict(action=algebra(),matching={basis:mass_match(basis) for basis in BASES})
    with (HERE/"action-checks.json").open("x") as output:
        json.dump(result,output,indent=2)
    print(json.dumps(result,indent=2))

