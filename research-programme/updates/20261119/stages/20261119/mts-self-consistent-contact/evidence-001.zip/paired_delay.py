from comparison import *
from ray_transfer import march


def leg(emission,start_shift,sign,qs,ds,es):
    def rhs(offset,values):
        time=emission+offset+values[0]
        delta=start_shift+values[1]
        middle=time+.5*delta
        pos=np.full_like(time,(6. if sign==1 else 6.5)+sign*offset)
        return np.stack((qs.ev(time,pos),ds.ev(time,pos)+delta*es.ev(middle,pos,dx=1)))
    return march(rhs,2,.5,64,len(emission))


def contrast_delay(basis,level):
    skies=[]
    for case in ("quiet","event"):
        with np.load(archive_path("history",basis,case,level,160),allow_pickle=False) as src:
            skies.append(src["bank"][:,0].real)
            tt=src["time"]
            xx=src["space"]
    kwargs=dict(kx=5,ky=5)
    qs,ds,es=[RectBivariateSpline(tt,xx,arr,**kwargs) for arr in (skies[0],skies[1]-skies[0],skies[1])]
    quiet,shift=leg(EMIT,0.,1,qs,ds,es)
    back,diff=leg(EMIT[MASK]+.5+quiet[MASK],shift[MASK],-1,qs,ds,es)
    return dict(out_delay=shift,echo_delay=shift[MASK]+diff)


def run(levels):
    rows=[]
    for basis in BASES:
        ref=contrast(basis,"tangent",160)
        signed=[]
        for plus,minus,span in levels:
            if plus=="doubleplus":
                statuses=[json.loads((HERE/f"wide-diagnostic-{basis}-{case}-{level}.json").read_text())["status"]
                          for level in (plus,minus) for case in ("event","quiet")]
                if any(status!="stable_to_final_epoch" for status in statuses):
                    continue
            a,b=[contrast_delay(basis,k) for k in (plus,minus)]
            signed.append({key:(a[key]-b[key])/span for key in a})
            for chan in ("out_delay","echo_delay"):
                gauge(rows,"paired_real_"+plus,basis,chan,(a[chan]-b[chan])/span,ref["metric_"+chan])
        if levels[0][0]=="wideplus" and len(signed)==2:
            for chan in ("out_delay","echo_delay"):
                gauge(rows,"paired_real_zero_step",basis,chan,(4*signed[0][chan]-signed[1][chan])/3,ref["metric_"+chan])
    save_table("paired-delay-"+levels[0][0]+".csv",rows)
    print(*[(row["test"],row["basis"],row["channel"],row["relative"]) for row in rows],sep="\n")


if __name__=="__main__":
    run([("wideplus","wideminus",4.),("doubleplus","doubleminus",8.)] if sys.argv[1:] else [("plus","minus",1.),("halfplus","halfminus",.5)])

