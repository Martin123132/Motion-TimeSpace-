from contact_model import *
from scipy.ndimage import correlate1d


class Evolution:
    def __init__(self,mesh,basis,strength):
        self.dx=1./mesh
        self.x=(np.arange(24*mesh)+.5)*self.dx
        self.basis=basis
        self.strength=strength
        self.keep=(self.x>=5.84)&(self.x<=6.66)
        self.d1=np.array([-1.,9,-45,0,45,-9,1])/(60*self.dx)
        self.d2=np.array([2.,-27,270,-490,270,-27,2])/(180*self.dx**2)
        self.windows=[]
        for lo,hi in ((.1,6.8),(4.1,5.8),(5.8,6.7)):
            arg=np.clip((self.x-lo)/(hi-lo),0,1)
            form=4*arg*(1-arg)
            self.windows.append((form**6,24*form**5*(1-2*arg)/(hi-lo)))

    def diff(self,values,weights,odd=False):
        if not odd:
            return correlate1d(values,weights,axis=-1,mode="reflect")
        extra=np.concatenate((-values[...,2::-1],values),axis=-1)
        return correlate1d(extra,weights,axis=-1,mode="nearest")[...,3:]

    def rates(self,state,observe=False):
        radial,angular,krad,kang,mass3,field,normal,density,impulse,charge=state
        xx=self.x
        aa=1+radial
        cc=1+angular
        length=np.sqrt(aa)
        shape_r=np.sqrt(cc)
        radius=xx*shape_r
        radius2=xx**2*cc
        jac=length*radius2
        da,dc,dh=self.diff(state[[0,1,5]],self.d1)
        w=impulse/length
        n=density/(length*cc)
        slope=dh/length
        flux=charge/radius2
        gamma=np.sqrt(1+w*w)
        mat=material(field,normal,slope,n,w,flux,self.basis)
        energy,radpress,latpress,current,extra,pex,tex,dpi,ds,dhh,dn,dw,dq=mat
        coupling=self.strength
        en=energy+coupling*extra
        pr=radpress+coupling*pex
        pt=latpress+coupling*tex
        radius_x=shape_r+xx*dc/(2*shape_r)
        tangent=kang/cc
        radial_k=krad/aa
        proper=-radius*tangent
        enclosed=mass3/shape_r**3
        if observe:
            strip=np.stack((radial/(length+1),krad/length,energy,-length*current,radpress,-energy+radpress+2*latpress,
                            normal,slope,field,n/gamma,flux,w,en-pr+2*pt-2*enclosed))[:,self.keep]
            budgets=[]
            mass=xx**3*mass3
            recon=radius/2*(proper**2+(radial-angular-xx*dc-(xx*dc/(2*shape_r))**2)/aa)
            dshell=self.diff(mass,self.d1,True)-radius2*(en*radius_x+length*current*proper)
            boost_error=(gamma+coupling*dn)*n*(w/gamma+coupling*dw)-(normal+coupling*dpi)*(slope+coupling*ds)-current
            for weight,grad in self.windows:
                total=lambda vals:np.sum(vals)*self.dx
                budgets.append([total(weight*jac*en),total(grad*radius2*current),total(weight*jac*(pr*radial_k+2*pt*tangent)),
                                total(weight*jac*length*current),total(grad*jac*pr),
                                total(weight*jac*(pr*da/(2*aa)+2*pt*radius_x/radius)),
                                total(weight*(mass-recon)),total(weight*mass),total(weight*dshell),
                                total(weight*radius2*en*radius_x),total(weight*boost_error)])
            return strip,np.array(budgets)
        speed=w/(length*gamma)
        charge_current=radius2*n*(w/gamma+coupling*dw)
        lap=(self.diff(xx*field,self.d2,True)/xx+(dc/cc-da/(2*aa))*dh)/aa
        rate=np.empty_like(state)
        rate[0]=-2*krad
        rate[1]=-2*kang
        rate[2]=aa*(en-pr+2*pt-2*enclosed)-krad**2/aa
        rate[3]=cc*(enclosed+pr-tangent**2)
        rate[4]=-cc*(pr*proper+current*radius_x/length)/xx
        rate[5]=normal+coupling*dpi
        rate[6]=lap-field+(radial_k+2*tangent)*normal+coupling*(self.diff(radius2*ds,self.d1,True)/jac-dhh)
        rate[7]=-self.diff(charge_current,self.d1,True)/xx**2
        rate[8]=-speed*self.diff(impulse,self.d1,True)+da*(impulse/aa)**2/(2*gamma)+.8*length*(flux+coupling*dq)-coupling*self.diff(dn,self.d1)
        rate[9]=-.8*charge_current
        return rate


def run(mesh,basis,case,level):
    guard()
    launchpath=archive_path("launch",basis,case,level)
    dest=archive_path("history",basis,case,level,mesh)
    if dest.exists():
        raise FileExistsError(dest)
    if level in ("plus","minus","halfplus","halfminus") and not (HERE/"frozen.json").exists():
        raise RuntimeError("tangent predictions not frozen")
    source=bridge.read(launchpath)
    solver=Evolution(mesh,basis,LEVELS[level])
    state=source[f"state{mesh}"].copy()
    stride=int(np.ceil(.004/(.26*solver.dx)))
    step=.004/stride
    banks,tests=[],[]
    for tick in range(810*stride+1):
        if tick%stride==0:
            strip,diagnostics=solver.rates(state,True)
            banks.append(strip)
            tests.append(diagnostics)
        if tick%100==0:
            guard()
        if tick==810*stride:
            break
        first=solver.rates(state)
        second=solver.rates(state+step/2*first)
        third=solver.rates(state+step/2*second)
        fourth=solver.rates(state+step*third)
        state+=step/6*(first+2*second+2*third+fourth)
    assert np.isfinite(banks).all() and np.isfinite(tests).all()
    bridge.archive(dest,bank=banks,checks=tests,time=np.arange(811)*.004,space=solver.x[solver.keep],
                   strength=LEVELS[level],source=bridge.sha(launchpath))
    print(dest.name,flush=True)


if __name__=="__main__":
    for arg in sys.argv[1:]:
        level,mesh=arg.split(":")
        for basis in BASES:
            for case in CASES:
                run(int(mesh),basis,case,level)

