from contact_model import *
from ray_transfer import spline, RectBivariateSpline
from contact_link import Contact
from dilute_clock import rays


CHANNELS=("out","echo","out_delay","echo_delay")
MASK=EMIT<=2.1


class AllStress(Contact):
    def __init__(self,data,basis):
        self.tt=data["time"]
        self.space=data["space"]
        raw=data["bank"].real
        htt,htx,hrr=(raw[:,2],raw[:,3],raw[:,4]) if basis=="tensor" else (-raw[:,5],0*raw[:,5],raw[:,5])
        self.surfaces=[RectBivariateSpline(self.tt,self.space,channel,kx=5,ky=5) for channel in (raw[:,0],raw[:,1],htt,htx,hrr)]


def zero_probe(setup):
    tracks=setup.linear_clocks()
    first=setup.linear(EMIT,1,tracks,64)
    second=setup.linear(EMIT[MASK]+.5+first["delay"][MASK],-1,tracks,64)
    result={}
    for leg,emission,delay,jac in (("out",EMIT,first["total"],first["jac"]),
                                  ("echo",EMIT[MASK],second["jac"]*first["total"][MASK]+second["total"],first["jac"][MASK]*second["jac"])):
        result[leg+"_delay"]=delay
        result[leg]=-spline(emission,delay).derivative()(emission)/jac**2
    return result


def finite_probe(setup,strength):
    tracks=setup.nonlinear_clocks(strength)
    first=setup.nonlinear(EMIT,1,strength,tracks,64)
    second=setup.nonlinear(EMIT[MASK]+.5+first[MASK],-1,strength,tracks,64)
    result={}
    for leg,emission,delay in (("out",EMIT,first),("echo",EMIT[MASK],first[MASK]+second)):
        result[leg+"_delay"]=delay
        slope=spline(emission,delay).derivative()(emission)
        result[leg]=-slope/(1+slope)
    return result


def record(basis,case,level,mesh):
    guard()
    src=archive_path("history",basis,case,level,mesh)
    dest=archive_path("clock",basis,case,level,mesh)
    if dest.exists():
        return
    data=bridge.read(src)
    strength=data["strength"]
    metric=rays(dict(time=data["time"],space=data["space"],bank=data["bank"][:,:2],z=strength))
    setup=AllStress(data,basis)
    tangent=np.iscomplexobj(data["bank"])
    probe=zero_probe(setup) if tangent else finite_probe(setup,float(strength))
    output={}
    for chan in CHANNELS:
        output["base_"+chan]=metric[chan]
        response=metric[("d" if tangent else "")+chan]
        output["metric_"+chan]=response
        output["total_"+chan]=probe[chan]+response if tangent else probe[chan]
        output["probe_"+chan]=probe[chan] if tangent else probe[chan]-response
    bridge.archive(dest,source=bridge.sha(src),**output)
    print(dest.name,flush=True)


def freeze():
    guard()
    dest=HERE/"frozen.json"
    if dest.exists():
        raise FileExistsError(dest)
    sources={}
    predictions={}
    for basis in BASES:
        for mesh in (80,160):
            for case in CASES:
                record(basis,case,"tangent",mesh)
                for kind in ("clock","history"):
                    file=archive_path(kind,basis,case,"tangent",mesh)
                    sources[file.name]=bridge.sha(file)
            event,quiet=[bridge.read(archive_path("clock",basis,case,"tangent",mesh)) for case in ("event","quiet")]
            for chan in CHANNELS:
                for part in ("metric","probe","total"):
                    vec=event[part+"_"+chan]-quiet[part+"_"+chan]
                    idx=int(np.argmax(abs(vec)))
                    predictions[f"{basis}-{mesh}-{part}-{chan}"]={"peak_signed":float(vec[idx]),"epoch_at_peak":float(EMIT[idx])}
    for name in ("PROTOCOL.md","contact_model.py","evolve_contact.py","clock_channels.py"):
        sources[name]=bridge.sha(HERE/name)
    content=json.dumps(dict(sources=sources,predictions=predictions,rule="unchanged own-scale relative maximum 2e-5; numeric derivatives per unit reduced coupling, not astrophysical Wilson coefficients"),indent=2)
    with dest.open("x") as output:
        output.write(content)
    print("frozen",bridge.sha(dest),flush=True)


if __name__=="__main__":
    if sys.argv[1]=="freeze":
        freeze()
    else:
        for arg in sys.argv[1:]:
            level,size=arg.split(":")
            for basis in BASES:
                for case in CASES:
                    record(basis,case,level,int(size))

