from comparison import gauge,save_table
from clock_channels import *
from ray_transfer import march


def clocks(mesh,case,data=None):
    if data is None:
        data=bridge.read(archive_path("history","tensor",case,"tangent",mesh))
    fields=data["bank"].real
    def surface(field):
        return RectBivariateSpline(data["time"],data["space"],field,kx=5,ky=5)
    small=surface(fields[:,0])
    kr=surface(fields[:,1])
    def leg(emission,sign):
        combo=surface((fields[:,6]+sign*fields[:,7])**2/2)
        def rhs(off,state):
            time=emission+off+state[0]
            x=np.full_like(time,(6 if sign==1 else 6.5)+sign*off)
            offset=small.ev(time,x)
            kval=kr.ev(time,x)
            return np.stack((offset,kval,-kval*state[2]+(1+offset)*combo.ev(time,x)))
        return march(rhs,3,.5,64,len(emission))
    out=leg(EMIT,1)
    back=leg(EMIT[MASK]+.5+out[0,MASK],-1)
    echo=back[2]+np.exp(-back[1])*out[2,MASK]
    return dict(out_delay=out[2],echo_delay=echo,out=-spline(EMIT,out[2]).derivative()(EMIT)*np.exp(2*out[1]),
                echo=-spline(EMIT[MASK],echo).derivative()(EMIT[MASK])*np.exp(2*(out[1,MASK]+back[1])))


def main():
    guard()
    rows=[]
    bymesh={}
    for mesh in (160,320):
        event,quiet=[clocks(mesh,case) for case in ("event","quiet")]
        bymesh[mesh]={name:event[name]-quiet[name] for name in event}
    cap={}
    with (PRE/"conditional-coefficients.csv").open(newline="") as handle:
        import csv
        for row in csv.DictReader(handle):
            cap[row["basis"]]=float(row["conditional_cap"])
    peak={}
    for link in ("out","echo"):
        for frag in ("","_delay"):
            chan=link+frag
            key=link+("_light" if frag else "_frequency_light")
            a,b=[bridge.read(PRE/f"contact-tensor-320-massive-{c}.npz")[key] for c in ("event","quiet")]
            gauge(rows,"independent_retained_path_kernel","relative_cone",chan,bymesh[320][chan],a-b)
            gauge(rows,"refinement_160_to_320","relative_cone",chan,bymesh[160][chan],bymesh[320][chan])
            vals=bymesh[320][chan]
            idx=int(np.argmax(abs(vals)))
            peak[chan]={"emission":float(EMIT[idx]),"peak_signed":float(vals[idx]),
                        "absolute_conditional_envelope":float(abs(vals[idx])*(cap["tensor"]+2*cap["trace"]))}
    ordinary=clocks(160,"ordinary")
    assert all(max(abs(value))==0 for value in ordinary.values())
    save_table("relative-arrival-checks.csv",rows)
    bridge.archive(HERE/"relative-arrival.npz",emission=EMIT,**bymesh[320])
    with (HERE/"relative-arrival-peaks.json").open("x") as file:
        json.dump(dict(contrast="compensated event minus quiet, scalar front minus light front at fixed proper emission; per gamma1+2gamma2, positive delay means scalar front is later; ideal identical emitter, reflection and receiver",peaks=peak,ordinary_exact_zero=True),file,indent=2)


if __name__=="__main__":
    main()

