from pathlib import Path
import sys
import json
import os

for name in ("OPENBLAS_NUM_THREADS","OMP_NUM_THREADS","MKL_NUM_THREADS","NUMEXPR_NUM_THREADS"):
    os.environ[name]="1"
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
PRE=HERE.parent/"mts-single-event-light-link-20261119"
sys.path.insert(0,str(PRE))
import shared_link as prior
from shared_link import bridge,Forecaster,shape,np,EMIT,TOL,SITES
from receiver import FreeFall
from scipy.integrate import solve_ivp
from scipy.interpolate import make_interp_spline
from scipy.special import betainc

LOCK="1c9dc60596b289e1b65c570b8281a950a1cf47093367c94fcb7d92a2c19da39f"
CASES=("quiet","event","ordinary")
BASES=("tensor","trace")
LEVELS={"tangent":.125j,"step":.5j,"plus":.5,"minus":-.5,"halfplus":.25,"halfminus":-.25,"zero":0.}


def guard():
    prior.guard()
    assert bridge.sha(PRE/"closeout.json")==LOCK
    if (HERE/"STOP-REQUESTED").exists():
        raise SystemExit("owner hold")


def archive_path(group,basis,case,level,mesh=None):
    return HERE/("-".join(str(i) for i in (group,basis,case,level,mesh) if i is not None)+".npz")


def material(hh,normal,slope,number,velocity,flux,basis):
    gamma=np.sqrt(1+velocity**2)
    imageless=normal**2+slope**2
    energy=(imageless+hh**2+flux**2)/2+number*gamma
    radial=(imageless-hh**2-flux**2)/2+number*velocity**2/gamma
    angular=(normal**2-slope**2-hh**2+flux**2)/2
    current=number*velocity-normal*slope
    if basis=="tensor":
        corr=-(energy**2+radial**2+2*angular**2-2*current**2)/4
        en,pr,pt,fl=-energy/2,-radial/2,-angular,current
    else:
        trace=-energy+radial+2*angular
        corr=-trace**2/4
        en,pr,pt,fl=trace/2,-trace/2,-trace,0.
    dnormal=(en+pr+pt)*normal-fl*slope
    dslope=(en+pr-pt)*slope-fl*normal
    dfield=(en-pr-pt)*hh
    dnumber=en*gamma+pr*velocity**2/gamma+fl*velocity
    dvelocity_over_n=en*velocity/gamma+pr*velocity*(2+velocity**2)/gamma**3+fl
    dflux=(en-pr+pt)*flux
    pextra=-corr+normal*dnormal+slope*dslope+number*(dnumber+velocity*dvelocity_over_n)
    textra=-corr+normal*dnormal+number*dnumber+flux*dflux
    return energy,radial,angular,current,corr,pextra,textra,dnormal,dslope,dfield,dnumber,dvelocity_over_n,dflux


class Launch:
    def __init__(self,basis,strength,ordinary):
        self.basis,self.strength=basis,strength
        seed=Forecaster(7680,"ordinary" if ordinary else "massive")
        axis=seed.rad
        self.potential=make_interp_spline(np.r_[-axis[8:0:-1],axis],np.r_[seed.initial[0,8:0:-1],seed.initial[0]],k=5)
        self.number=lambda rad:seed.initial[4,0]*np.maximum(1-(rad/5)**2,0)**6
        self.charge=lambda rad:.0016*betainc(1.5,7,np.minimum((rad/5)**2,1))
        self.dtype=np.result_type(strength,float)
        self.quiet_solution=self.integrate(lambda rad,mass:[self.mass_rhs(rad,mass[0],0.,0.)],0.,24.,0.)

    def integrate(self,rhs,begin,end,start):
        result=solve_ivp(rhs,(begin,end),np.array([start],dtype=self.dtype),method="DOP853",rtol=5e-14,atol=2e-22,
                         max_step=.08,dense_output=True)
        assert result.success
        return result.sol

    def variables(self,rad,mass,coef,kick):
        with np.errstate(divide="ignore"):
            inv=np.where(np.asarray(rad)==0.,0.,np.divide(1.,rad))
        charge=self.charge(rad)
        fac=1-(2*mass-charge**2*inv)*inv
        root=np.sqrt(fac)
        envelope,deriv=shape(rad)
        hh=self.potential(rad)+coef*envelope
        slope=root*(self.potential(rad,1)+coef*deriv)
        desired=root*kick*envelope
        normal=desired
        velocity=0.*normal
        number=self.number(rad)*root
        flux=charge*inv**2
        for iteration in range(4):
            mat=material(hh,normal,slope,number,velocity,flux,self.basis)
            normal=desired-self.strength*mat[7]
            beta=-self.strength*mat[11]
            velocity=beta/np.sqrt(1-beta**2)
        mat=material(hh,normal,slope,number,velocity,flux,self.basis)
        return fac,hh,slope,normal,velocity,number,charge,mat

    def mass_rhs(self,rad,mass,coef,kick):
        fac,hh,slope,normal,velocity,number,charge,mat=self.variables(rad,mass,coef,kick)
        return rad**2*((normal**2+slope**2+hh**2)/2+number*np.sqrt(1+velocity**2)+self.strength*mat[4])+.8*rad*self.number(rad)*charge

    def collar(self,coef):
        def difference(rad,delta):
            base=self.quiet_solution(rad)[0]
            return [self.mass_rhs(rad,base+delta[0],coef,.0002)-self.mass_rhs(rad,base,0.,0.)]
        return self.integrate(difference,4.5,5.5,0.)

    def matched(self):
        coef=prior.coefficient()+0*self.strength
        for _ in range(3):
            delta=self.collar(coef)(5.5)[0]
            if abs(delta)<1e-22:
                break
            derivative=(self.collar(coef+1e-8)(5.5)[0]-self.collar(coef-1e-8)(5.5)[0])/2e-8
            coef-=delta/derivative
        solution=self.collar(coef)
        raw=solution(5.5)[0]
        assert abs(raw)<1e-19
        return coef,solution,raw

    def initial(self,xx,case,coef,collar):
        mass=self.quiet_solution(xx)[0]
        if case=="event":
            within=(xx>4.5)&(xx<5.5)
            mass=mass.copy()
            mass[within]+=collar(xx[within])[0]
        fac,hh,slope,normal,velocity,number,charge,mat=self.variables(xx,mass,coef,.0002 if case=="event" else 0.)
        mgrav=mass-charge**2/(2*xx)
        zeros=0*normal
        deficit=2*mgrav/xx
        state=np.stack((deficit/fac,zeros,xx*mat[3]/fac**1.5,zeros,mgrav/xx**3,hh,normal,self.number(xx)+zeros,velocity/np.sqrt(fac),charge+zeros))
        assert np.max(abs(normal+self.strength*mat[7]-np.sqrt(fac)*(.0002 if case=="event" else 0.)*shape(xx)[0]))<2e-16
        assert np.max(abs(velocity/np.sqrt(1+velocity**2)+self.strength*mat[11]))<2e-16
        return state


def prepare(basis,level):
    guard()
    strength=LEVELS[level]
    for ordinary in (False,True):
        launch=Launch(basis,strength,ordinary)
        if not ordinary:
            coef,collar,raw=launch.matched()
        for case in (("ordinary",) if ordinary else ("quiet","event")):
            coeff=coef if case=="event" else 0.*strength
            rows={}
            for mesh in (80,160,320):
                xx=(np.arange(24*mesh)+.5)/mesh
                rows[f"state{mesh}"]=launch.initial(xx,case,coeff,collar if case=="event" else None)
            bridge.archive(archive_path("launch",basis,case,level),**rows,coef=coeff,
                           root_residual=raw if case=="event" else 0.,strength=strength,
                           outer_U=launch.quiet_solution(24.)[0],protocol=bridge.sha(HERE/"PROTOCOL.md"))
        print(basis,level,"ordinary" if ordinary else "matched",flush=True)


if __name__=="__main__":
    for level in sys.argv[1:]:
        for basis in BASES:
            prepare(basis,level)

