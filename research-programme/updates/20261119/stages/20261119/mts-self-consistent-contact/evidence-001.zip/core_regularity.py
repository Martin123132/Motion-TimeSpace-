from contact_model import *
from evolve_contact import Evolution


def track(basis,level):
    guard()
    strength={"wideplus":2.,"wideminus":-2.}.get(level,LEVELS.get(level))
    solver=Evolution(160,basis,strength)
    source=archive_path("launch",basis,"quiet",level)
    data=bridge.read(source)
    state=data["state160"].copy()
    stride=int(np.ceil(.004/(.26*solver.dx)))
    dt=.004/stride
    ref=float(max(state[7]/np.sqrt(1+state[0])))
    core=solver.x<4
    lowest=1.
    maxcore=0.
    signloss=None
    min_core=np.inf
    last=None
    for tick in range(810*stride+1):
        if tick%100==0:
            guard()
        if tick%stride==0:
            n=state[7]/(np.sqrt(1+state[0])*(1+state[1]))/ref
            lowest=min(lowest,float(min(n)))
            maxcore=max(maxcore,float(max(n[core])))
            min_core=min(min_core,float(min(n[core])))
            if signloss is None and min(n)<-TOL:
                signloss=dict(time=tick*dt,radius=float(solver.x[np.argmin(n)]))
            last=float(n[0])
        if tick==810*stride:
            break
        a=solver.rates(state)
        b=solver.rates(state+dt*a/2)
        c=solver.rates(state+dt*b/2)
        d=solver.rates(state+dt*c)
        state+=dt/6*(a+2*b+2*c+d)
    assert np.isfinite(state).all()
    return dict(basis=basis,level=level,strength=strength,central_density0=ref,min_over_initial_peak=lowest,
                min_interior4_over_initial_peak=min_core,peak_interior_over_initial_peak=maxcore,
                final_central_over_initial_peak=last,first_negative_beyond_global_resolution=signloss,
                source_sha=bridge.sha(source))


def symbol():
    solver=Evolution(160,"tensor",0.)
    rows=[]
    for basis in BASES:
        for level,number in (("plus",.5),("minus",-.5),("doubleplus",4.),("doubleminus",-4.)):
            state=bridge.read(archive_path("launch",basis,"event",level))["state160"]
            length=np.sqrt(1+state[0])
            ss=solver.diff(state[5],solver.d1)/length
            for radius in (.25,1.,3.,4.65,4.9):
                idx=int(np.argmin(abs(solver.x-radius)))
                vals=np.array([state[6,idx],ss[idx],state[7,idx]/length[idx],state[8,idx]/length[idx]])
                charge=state[9,idx]/solver.x[idx]**2
                def grad(v):
                    mom,slope,n,w=v
                    mat=material(state[5,idx],mom,slope,n,w,charge,basis)
                    lor=np.sqrt(1+w*w)
                    return np.array([mom+number*mat[7],slope+number*mat[8],lor+number*mat[10],n*(w/lor+number*mat[11])])
                columns=[grad(vals+1j*col*1e-19).imag/1e-19 for col in np.eye(4)]
                hess=np.stack(columns,axis=1)
                assert max(abs(hess-hess.T).flat)<3e-14
                smat=np.array([[0,-1,0,0],[-1,0,0,0],[0,0,0,1],[0,0,1,0]])
                ev=np.linalg.eigvals(smat@hess)
                speed=ev[np.argsort(abs(ev))[:2]]
                rows.append(dict(basis=basis,strength=number,radius=float(solver.x[idx]),n=float(vals[2]),
                                 slow_real=list(map(float,speed.real)),slow_imag=list(map(float,speed.imag)),
                                 cold_speed2_leading=float(-number*vals[2]/2)))
    return rows


if __name__=="__main__":
    if sys.argv[1:]:
        basis=sys.argv[1]
        if basis=="tensor":
            prepare(basis,"zero")
        levels=(["zero"] if basis=="tensor" else [])+["halfplus","halfminus","plus","minus","wideplus","wideminus"]
        for level in levels:
            result=track(basis,level)
            with (HERE/f"core-{basis}-{level}.json").open("x") as handle:
                json.dump(result,handle,indent=2)
            print(basis,level,result["min_over_initial_peak"],result["peak_interior_over_initial_peak"],flush=True)
    else:
        with (HERE/"mixed-characteristics.json").open("x") as handle:
            json.dump(symbol(),handle,indent=2)

