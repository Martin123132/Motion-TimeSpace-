from comparison import *
import sympy as sy


def radius_check():
    radius,mass,charge,coupling=sy.symbols("S M Q g",positive=True)
    bare=1-2*mass/radius+(charge/radius)**2
    cubic=-charge**4/(10*radius**6)
    dr=-charge**2/(4*radius**3)
    expression=cubic+dr*sy.diff(bare,radius)-charge**2*bare/(2*radius**4)
    expected=-charge**2/(2*radius**4)+mass*charge**2/(2*radius**5)-charge**4/(10*radius**6)
    assert sy.simplify(expression-expected)==0
    assert sy.simplify(dr+charge**2/(4*radius**3))==0
    return str(expected)


def vector(source,key):
    return np.r_[source[key+"out"][MASK],source[key+"echo"]]


def compression():
    guard()
    frozen=json.loads((HERE/"frozen.json").read_text())
    for file,checksum in frozen["sources"].items():
        assert bridge.sha(HERE/file)==checksum
    basis={key:contrast(key,"tangent",160) for key in BASES}
    matrices=[np.column_stack([vector(basis[key],part+"_") for key in BASES]) for part in ("total","metric")]
    model=vector(basis["tensor"],"base_")
    times=EMIT[MASK]
    ones=np.ones(len(times))
    zeros=0*ones
    design=np.stack((np.r_[ones,zeros],np.r_[times,zeros],np.r_[zeros,ones],np.r_[zeros,times],model/np.linalg.norm(model)),axis=1)
    nuisance,sv,_=np.linalg.svd(design,full_matrices=False)
    assert min(sv)>1e-6
    residual=lambda data:data-nuisance@(nuisance.T@data)
    outputs={}
    sources={}
    for title,matrix in zip(("total","metric"),matrices):
        effective=residual(matrix)
        scale=np.linalg.norm(effective,axis=0)
        unit=effective/scale
        left,singular,right=np.linalg.svd(unit,full_matrices=False)
        dual=(right.T/singular)@left.T
        frozen_weight=dual/scale[:,None]
        identity=frozen_weight@matrix
        assert np.max(abs(identity-np.eye(2)))<1e-11
        fine=np.column_stack([vector(contrast(b,"tangent",320),title+"_") for b in BASES])
        trial=frozen_weight@fine
        finite={}
        for plus,minus,span in (("plus","minus",1.),("halfplus","halfminus",.5)):
            zm=np.column_stack([(vector(contrast(b,plus,160),title+"_")-vector(contrast(b,minus,160),title+"_"))/span for b in BASES])
            finite[plus]=(frozen_weight@zm).tolist()
        outputs[title]=dict(correlation=float(unit[:,0]@unit[:,1]),unit_column_condition=float(singular[0]/singular[-1]),
                        retained_l2_fraction=(scale/np.linalg.norm(matrix,axis=0)).tolist(),transfer_at_320=trial.tolist(),
                        finite_transfer=finite)
        sources[title]=frozen_weight
    caps={}
    with (PRE/"conditional-coefficients.csv").open(newline="") as handle:
        for row in csv.DictReader(handle):
            caps[row["basis"]]=float(row["conditional_cap"])
    bounds=[]
    for chan in CHANNELS:
        one,two=[contrast(b,"tangent",320) for b in BASES]
        for part in ("metric","total"):
            envelope=caps["tensor"]*abs(one[part+"_"+chan])+caps["trace"]*abs(two[part+"_"+chan])
            bounds.append(dict(channel=chan,part=part,max_at_fixed_caps=float(max(envelope)),
                               fraction_of_zero_contact_event=float(max(envelope)/max(abs(one["base_"+chan])))))
    result=dict(convention="Synthetic noiseless equal weighting over times 0..2.1 on both links. Remove independent constant/linear terms and a common multiplicative zero-contact event template. Not a sky likelihood, not proof against other source histories. Columns tensor,trace; rows estimators in same order. Finite tests use independent numerical solutions; weights built only with frozen 160-mesh derivatives.",basis=outputs,conditional= bounds,clock_areal_formula=radius_check())
    with (HERE/"operator-resolution.json").open("x") as handle:
        json.dump(result,handle,indent=2)
    bridge.archive(HERE/"operator-weights.npz",**sources,emission=times)


if __name__=="__main__":
    compression()

