from contact_model import *
import sympy as sy


def independent():
    field,momentum,gradient,electric=sy.symbols("h p s D",real=True)
    energy=(momentum**2+gradient**2+field**2+electric**2)/2
    press=(momentum**2+gradient**2-field**2-electric**2)/2
    angular=(momentum**2-gradient**2-field**2+electric**2)/2
    flux=-momentum*gradient
    exprs=(-(energy**2+press**2+2*angular**2-2*flux**2)/4,-(-energy+press+2*angular)**2/4)
    results=[]
    for idx,zterm in enumerate(exprs):
        pure_scalar=zterm.subs(electric,0)
        pure_electric=zterm.subs({field:0,momentum:0,gradient:0})
        mix=sy.expand(zterm-pure_scalar-pure_electric)
        expected=-(electric**2/4)*(momentum**2-gradient**2) if idx==0 else 0
        assert sy.expand(mix-expected)==0
        for sign in (-1,1):
            fast=-sy.diff(zterm,momentum,gradient)+sign*(sy.diff(zterm,momentum,2)+sy.diff(zterm,gradient,2))/2
            light=flux-sign*(energy+press)/2 if idx==0 else 0
            diff=sy.factor(fast-light)
            assert sy.simplify(diff+sign*(idx+1)*(momentum+sign*gradient)**2/2)==0
            results.append(dict(operator=BASES[idx],direction=sign,mixed_hamiltonian=str(mix),
                                scalar_speed_relative_to_light=str(diff)))
    return results


def run():
    guard()
    exact=independent()
    records=[]
    for mesh in (80,160,320):
        saved={}
        for case in ("event","quiet","ordinary"):
            with np.load(archive_path("history","tensor",case,"tangent",mesh),allow_pickle=False) as data:
                raw=data["bank"].real
                to_use=(data["space"]>=6)&(data["space"]<=6.5)
                saved[case]={sign:-sign*(raw[:,6,to_use]+sign*raw[:,7,to_use])**2/2 for sign in (-1,1)}
                rest=float(np.max(abs(raw[:,9,to_use])))
                assert rest<1e-18
                records.append(dict(mesh=mesh,case=case,max_abs_dust_rest=rest))
        for sign in (-1,1):
            series=saved["event"][sign]-saved["quiet"][sign]
            records.append(dict(mesh=mesh,direction=sign,peak_event_minus_quiet=float(series.flat[np.argmax(abs(series))]),
                                null_ordinary_peak=float(np.max(abs(saved["ordinary"][sign])))))
    meta=dict(assumptions="Radial scalar principal symbol on the negligible-dust strip at fixed displacement. Compare to ideal radial test photon; one coefficient combination gamma1+2 gamma2. Local speeds in leading orthonormal frame, not integrated travel times.",identities=exact,sampled=records)
    with (HERE/"wave-cone.json").open("x") as handle:
        json.dump(meta,handle,indent=2)


if __name__=="__main__":
    run()

