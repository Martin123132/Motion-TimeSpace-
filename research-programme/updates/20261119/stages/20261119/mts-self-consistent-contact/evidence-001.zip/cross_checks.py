from comparison import *


def collect():
    rows=[]
    for basis in BASES:
        low,high=[contrast(basis,level,80) for level in ("tangent","step")]
        for chan in CHANNELS:
            for part in ("metric","probe","total"):
                key=part+"_"+chan
                gauge(rows,"imaginary_increment_x4",basis,key,high[key],low[key])
        c0=bridge.read(archive_path("launch",basis,"event","tangent"))["coef"].item()
        for plus,minus,den in (("plus","minus",1.),("halfplus","halfminus",.5)):
            vals=[bridge.read(archive_path("launch",basis,"event",lev))["coef"].item() for lev in (plus,minus)]
            gauge(rows,"real_launch_"+plus,basis,"compact_coefficient",np.array([(vals[0]-vals[1])/den]),np.array([c0.imag/.125]))
        fine=contrast(basis,"tangent",320)
        for key in ("base_out","metric_out","probe_out","total_out"):
            amplitude=float(max(abs(fine[key])))
            pre=float(max(abs(fine[key][EMIT<.35])))
            rows.append(dict(test="prefront_over_peak",basis=basis,channel=key,reference=amplitude,absolute=pre,
                             relative=pre/amplitude,pass_unchanged=pre<=TOL*amplitude))
    save_table("source-and-causal-checks.csv",rows)


if __name__=="__main__":
    collect()

