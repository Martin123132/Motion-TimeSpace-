from pathlib import Path
import sys
import os
import json
import csv

for setting in ("OMP_NUM_THREADS","OPENBLAS_NUM_THREADS","MKL_NUM_THREADS","NUMEXPR_NUM_THREADS"):
    os.environ[setting]="1"
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
OLD=HERE.parent/"mts-localized-causal-clock-20261119"
sys.path.insert(0,str(OLD))
from launch import guard as previous_guard, bridge, Forecaster, profile, SITES
import numpy as np

LOCK="3582eea1829e37387a6205547c7f332d39fa622168918ac9d94b5cf5d487a050"
CASES=("massive-quiet","massive-event","massless-quiet","massless-event","ordinary-quiet")
EMIT=np.arange(1081)*.0025
TOL=2e-5


def guard():
    previous_guard()
    if (HERE/"STOP-REQUESTED").exists():
        raise SystemExit("owner hold")
    assert bridge.sha(OLD/"closeout.json")==LOCK


def coefficient():
    meta=json.loads((OLD/"closeout.json").read_text())
    source=OLD/"compensated-launch.csv"
    assert bridge.sha(source)==meta["files"][source.name]
    with source.open(newline="") as file:
        rows=[row for row in csv.DictReader(file) if float(row["step"])==.0375 and float(row["impulse"])==.0002]
    assert len(rows)==1 and rows[0]["branch_found"]=="True"
    return float(rows[0]["coefficient"])


def shape(radius):
    part=np.clip(radius-4.5,0.,1.)
    smooth=4*part*(1-part)
    return smooth**6,24*smooth**5*(1-2*part)


def meshes(case):
    return (1920,3840) if case=="ordinary-quiet" else (7680,15360)


def target(method,res,case):
    return HERE/f"{method}-{res}-{case}.npz"


def frozen(verify=True):
    files=[target(kind,res,case) for kind in ("polar","prediction") for case in CASES for res in meshes(case)]
    sources=[HERE/name for name in ("PROTOCOL.md","RADAR-PROTOCOL.md","shared_link.py","predict_metric.py","ray_transfer.py")]
    flat={src.name:bridge.sha(src) for src in [*files,*sources]}
    seal=HERE/"frozen.json"
    if verify:
        assert json.loads(seal.read_text())==flat
    else:
        with seal.open("x") as stream:
            json.dump(flat,stream,sort_keys=True,indent=2)


def dump(path,**entries):
    bridge.archive(path,**entries)

