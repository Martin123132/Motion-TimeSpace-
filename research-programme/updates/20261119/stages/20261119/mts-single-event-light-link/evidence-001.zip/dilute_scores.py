from link_scores import *
from dilute_clock import rays,DiluteLaunch
from scipy.constants import Julian_year


def collect():
    guard()
    states={}
    for mode in ("leading","step","quarter","mid","top"):
        for mesh in ((80,160) if mode=="leading" else (160,)):
            for case in ("quiet","event"):
                packet=bridge.read(target("dilute-"+mode,mesh,case))
                assert str(packet["protocol"])==bridge.sha(HERE/"DILUTE-PROTOCOL.md")
                states[mode,mesh,case]=rays(packet)
    scale=DiluteLaunch().actual_scale()
    context=json.loads((OLD.parent/"mts-two-radius-pressure-clock-20261119/physical-clock-scale.json").read_text())
    timescale=context["time_unit_years"]*Julian_year
    summary=[]
    budgets=[]
    predictions=[]
    for name,primary in (("out","log_ratio"),("echo","echo_log_ratio"),("out_delay","delay"),("echo_delay","echo_delay")):
        times=EMIT if name.startswith("out") else EMIT[EMIT<=2.1]
        key="d"+name
        def delta(mode,mesh,key):
            return states[mode,mesh,"event"][key]-states[mode,mesh,"quiet"][key]
        lead=delta("leading",160,key)
        middle=delta("mid",160,key)
        end=delta("top",160,key)
        weighted=(lead+4*middle+end)/6
        signal=scale*weighted
        halfstep=peak(lead-delta("step",160,key))/peak(weighted)
        spatial=peak(lead-delta("leading",80,key))/peak(weighted)
        integ=peak(weighted-middle)/peak(weighted)
        finite=peak(weighted-lead)/peak(weighted)
        wave=pair(data("reception",160,"massive-event"),data("reception",160,"massive-quiet"),primary)
        quarter=4*delta("quarter",160,name)
        lo=peak(quarter-lead)/peak(lead)
        hi=peak(wave-lead)/peak(lead)
        assert hi>0 and lo<hi
        timing=0.
        if "delay" not in name:
            for mode in ("leading","mid","top"):
                expected=[]
                for case in ("event","quiet"):
                    state=states[mode,160,case]
                    jac=1+spline(times,state[name+"_delay"]).derivative()(times)
                    expected.append(-spline(times,state["d"+name+"_delay"]).derivative()(times)/jac**2)
                timing=max(timing,peak(expected[0]-expected[1]-delta(mode,160,key))/peak(weighted))
        total=halfstep+spatial+integ+timing
        budgets.append(dict(quantity=name,grid=spatial,imaginary_step=halfstep,midpoint_vs_simpson=integ,
                            pulse_derivative_check=timing,total=total,passed=total<TOL))
        idx=np.argmax(abs(signal))
        summary.append(dict(quantity=name,density_GeV_cm3=context["normalization_GeV_cm3"],squared_scale=scale,
                            peak_signed=signal[idx],emit_at_peak=times[idx],example_seconds_if_delay=signal[idx]*timescale if "delay" in name else "",
                            error_if_full_density_shape_rescaled=hi,error_if_quarter_density_shape_rescaled=lo,
                            quarter_over_full_error=lo/hi,finite_density_vs_leading=finite))
        for index,clock in enumerate(times):
            predictions.append(dict(quantity=name,emit=clock,event_minus_quiet=signal[index],leading=scale*lead[index]))
    return summary,budgets,predictions


if __name__=="__main__":
    for filename,rows in zip(("dilute-observables.csv","dilute-budgets.csv","dilute-frequency-and-delay.csv"),collect()):
        output(filename,rows,"check" in sys.argv)

