from shared_link import *
from scipy.interpolate import RectBivariateSpline, make_interp_spline


def spline(times,series):
    return make_interp_spline(times,series,k=5)


class Strip:
    def __init__(self,data,stride):
        self.time=data["time"][::stride]
        self.space=data["space"]
        bank=data["bank"][::stride]
        self.surfaces=[RectBivariateSpline(self.time,self.space,values,kx=5,ky=5) for values in bank.transpose(1,0,2)]

    def get(self,which,time,position):
        assert np.min(time)>=self.time[0]-1e-12 and np.max(time)<=self.time[-1]+1e-12
        assert np.min(position)>=self.space[0] and np.max(position)<=self.space[-1]
        return self.surfaces[which].ev(time,position)


def march(rhs,rows,width,panels,length):
    state=np.zeros((rows,length))
    step=width/panels
    for idx in range(panels):
        start=idx*step
        first=rhs(start,state)
        second=rhs(start+step/2,state+step*first/2)
        third=rhs(start+step/2,state+step*second/2)
        fourth=rhs(start+step,state+step*third)
        state+=step/6*(first+2*second+2*third+fourth)
    assert np.isfinite(state).all()
    return state


def polar(data,panels=32,stride=1,emission=EMIT,direction=1):
    strip=Strip(data,stride)
    times=strip.time
    world=data["world"][::stride]
    start,end=(0,1) if direction==1 else (1,0)
    emit_drift=world[:,1,start]
    emit_coord=emission+spline(times+emit_drift,-emit_drift)(emission)
    paths=spline(times,world)
    def rhs(fraction,state):
        instant=emit_coord+.5*fraction+state[0]
        motion=paths(instant)
        radius=SITES[start]+direction*.5*fraction+(1-fraction)*motion[:,0,start]+fraction*motion[:,0,end]
        width_change=direction*(motion[:,0,end]-motion[:,0,start])
        frame_speed=(1-fraction)*motion[:,2,start]+fraction*motion[:,2,end]
        mod=strip.get(0,instant,radius)-direction*frame_speed
        delta=(width_change-.5*mod)/(1+mod)
        return np.stack((delta,-direction*strip.get(1,instant,radius)*(.5+delta)))
    delay,transport=march(rhs,2,1.,panels,len(emission))
    arrival=emit_coord+.5+delay
    inner=paths(emit_coord)
    outer=paths(arrival)
    endpoints=outer[:,3,end]-inner[:,3,start]
    if direction==-1:
        def rapidity(clock,frame,index):
            speed=frame[:,2,index]
            beam=1+strip.get(0,clock,SITES[index]+frame[:,0,index])
            return np.arctanh(speed/beam)
        endpoints+=2*(rapidity(arrival,outer,end)-rapidity(emit_coord,inner,start))
    observed=endpoints+transport
    travel=delay+outer[:,1,end]-inner[:,1,start]
    return dict(log_ratio=observed,delay=travel,transport=transport,
                endpoints=endpoints,emit=emission)


def synchronous(data,panels=32,stride=1,emission=EMIT,direction=1):
    strip=Strip(data,stride)
    def rhs(offset,state):
        time=emission+offset+state[0]
        xx=np.full_like(time,(6. if direction==1 else 6.5)+direction*offset)
        delta=strip.get(0,time,xx)
        freq=strip.get(1,time,xx)
        weighted=(1+delta)*np.exp(-state[1])
        components=[strip.get(which,time,xx)*weighted for which in range(2,6)]
        return np.stack((delta,freq,*components))
    values=march(rhs,6,.5,panels,len(emission))
    return dict(log_ratio=values[1],delay=values[0],drift_terms=values[2:],emit=emission)


def both(method,bank,panels,stride):
    out=method(bank,panels,stride)
    index=EMIT<=2.1
    reflection=EMIT[index]+.5+out["delay"][index]
    back=method(bank,panels,stride,reflection,-1)
    out["echo_delay"]=out["delay"][index]+back["delay"]
    out["echo_log_ratio"]=out["log_ratio"][index]+back["log_ratio"]
    out["echo_emit"]=EMIT[index]
    if "drift_terms" in out:
        out["echo_drift_terms"]=out["drift_terms"][:,index]+back["drift_terms"]*np.exp(-out["log_ratio"][index])
    return out


def save_case(kind,res,case):
    guard()
    method=polar if kind=="polar" else synchronous
    if kind=="polar" and (HERE/"frozen.json").exists():
        raise FileExistsError("original predictions frozen")
    source=target(kind,res,case)
    bank=bridge.read(source)
    answer=both(method,bank,64,1)
    coarse=both(method,bank,32,1)
    thinned=both(method,bank,64,2)
    for prefix,other in (("coarse",coarse),("thin",thinned)):
        for key in ("log_ratio","delay","drift_terms","echo_delay","echo_log_ratio","echo_drift_terms"):
            if key in other:
                answer[prefix+"_"+key]=other[key]
    dest=target("prediction" if kind=="polar" else "reception",res,case)
    dump(dest,**answer,bank_sha=bridge.sha(source))
    print(dest.name,flush=True)


if __name__=="__main__":
    kind=sys.argv[1]
    if kind=="freeze":
        frozen(False)
    else:
        for case in CASES:
            for res in (meshes(case) if kind=="polar" else (80,160)):
                save_case(kind,res,case)

