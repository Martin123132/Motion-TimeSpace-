from link_scores import *


def scalar_source(record,basis):
    times=record["time"]
    space=record["space"]
    bank=record["bank"]
    length=1+bank[:,0]
    charge=record["init"][11]
    assert np.all(np.abs(charge-.0016)<3e-15)
    assert peak(bank[:,4])<1e-28
    radius_sq=np.sqrt(3)*charge[-1]/np.sqrt(bank[:,3])
    assert peak(radius_sq[0]-space**2)<1e-11
    jac=length*radius_sq
    field,normal,grad=bank[:,6],bank[:,7],bank[:,8]
    kin=grad**2-normal**2
    potential=field**2/2
    if basis=="tensor":
        corr=(kin**2+2*potential*kin+4*potential**2)/4
        coeff=(kin+potential)/2
        pv=kin/2+2*potential
    else:
        corr=(kin+4*potential)**2/4
        coeff=(kin+4*potential)/2
        pv=2*(kin+4*potential)
    dt=lambda matrix:make_interp_spline(times,matrix,k=5)(times,1)
    dx=lambda matrix:make_interp_spline(space,matrix.T,k=5)(space,1).T
    source=2*(coeff*field-dt(coeff)*normal+dx(coeff)*grad/length)-pv*field
    div=2*(-dt(jac*coeff*normal)+dx(radius_sq*coeff*grad))/jac-pv*field
    mask=(times>=.05)&(times<=3.18)
    ss=(space>=5.99)&(space<=6.51)
    linear_error=peak((div-source)[mask][:,ss])/peak(source[mask][:,ss])
    variables={"source":source,"direct_energy":-2*coeff*normal**2-corr,
               "direct_pressure":-2*coeff*grad**2+corr,"direct_flux":2*coeff*normal*grad}
    coords=np.linspace(6.,6.5,49)
    return {key:make_interp_spline(space,values[mask].T,k=5)(coords).T for key,values in variables.items()},linear_error


def rows():
    guard()
    output=[]
    tests=[]
    for basis in ("tensor","trace"):
        curves={}
        for mesh in (80,160,320):
            for case in ("massive-event","massive-quiet"):
                dataset=bridge.read(target("sync",mesh,case))
                curves[mesh,case],err=scalar_source(dataset,basis)
                tests.append(dict(basis=basis,resolution=mesh,case=case,test="flux_divergence_vs_product_rule",relative=err,passed=err<=TOL))
        for key in curves[160,"massive-event"]:
            delta=lambda mesh:curves[mesh,"massive-event"][key]-curves[mesh,"massive-quiet"][key]
            exact=delta(320)
            relative=peak(exact-delta(160))/peak(exact)
            output.append(dict(basis=basis,quantity=key,event_contrast_peak=peak(exact),
                               event_peak=peak(curves[320,"massive-event"][key]),quiet_peak=peak(curves[320,"massive-quiet"][key]),
                               grid_step=relative,previous_step=peak(delta(80)-delta(160))/peak(exact),passed=relative<=TOL))
    return output,tests


if __name__=="__main__":
    for name,records in zip(("feedback-sources.csv","feedback-identities.csv"),rows()):
        output(name,records,"check" in sys.argv)

