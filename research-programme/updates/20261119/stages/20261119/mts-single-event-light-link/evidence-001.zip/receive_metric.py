from shared_link import *
from receiver import FreeFall
from scipy.integrate import solve_ivp
from scipy.interpolate import make_interp_spline
from scipy.special import betainc


def preparation(mesh,case):
    model,kind=case.split("-")
    system=FreeFall(mesh,model,0)
    if model!="ordinary" and kind=="quiet":
        if mesh in (80,160):
            state=bridge.read(OLD/f"receiver-{mesh}-massive-0.npz")["initial"].copy()
        else:
            assert mesh==320 and model=="massive"
            state=system.initial.copy()
        if model=="massless":
            state[8]=state[5]
        return system,state
    template=Forecaster(7680,"massive" if model!="ordinary" else "ordinary")
    knots=template.rad
    vals=template.initial[0]
    spline=make_interp_spline(np.r_[-knots[8:0:-1],knots],np.r_[vals[8:0:-1],vals],k=5)
    scale=coefficient() if kind=="event" else 0.
    den0=template.initial[4,0]
    def density(rad):
        return den0*np.maximum(1-(rad/5)**2,0)**6
    def charge(rad):
        return .0016*betainc(1.5,7,np.minimum((rad/5)**2,1))
    def scalar(rad):
        form,deriv=shape(rad)
        return spline(rad)+scale*form,spline(rad,1)+scale*deriv,.0002*form*int(kind=="event")
    def constraint(rad,mass):
        inv=1/rad if rad else 0.
        electric=charge(rad)
        factor=1-(2*mass[0]-electric**2*inv)*inv
        hh,grad,impulse=scalar(rad)
        energy=(factor*(grad**2+impulse**2)+hh**2)/2
        return [rad**2*(density(rad)*np.sqrt(factor)+energy)+.8*rad*density(rad)*electric]
    sol=solve_ivp(constraint,(0.,24.),[0.],method="DOP853",rtol=4e-14,atol=1e-21,max_step=.075,dense_output=True)
    assert sol.success
    xx=system.x
    mass=sol.sol(xx)[0]-charge(xx)**2/(2*xx)
    deficit=2*mass/xx
    factor=1-deficit
    hh,grad,impulse=scalar(xx)
    zeros=np.zeros_like(xx)
    state=np.stack((deficit/factor,zeros,-xx*impulse*grad/np.sqrt(factor),zeros,mass/xx**3,
                    hh,impulse*np.sqrt(factor),zeros,hh*int(model=="massless"),density(xx),zeros,charge(xx)))
    return system,state


def snapshot(system,state,keep):
    xx=system.x[keep]
    radial,angular,krad,kang,mass3,field,normal,other,second,density,impulse,charge=state[:,keep]
    aa=1+radial
    bb=np.sqrt(1+angular)
    length=np.sqrt(aa)
    radius=xx*bb
    mass=xx**3*mass3+.5*charge**2/radius
    rho=density/(length*bb**2*np.sqrt(1+impulse**2/aa))
    grad=system.diff(state[[5,7]],system.d1)[:,keep]/length
    scalar=normal**2+second**2-np.sum(grad**2,axis=0)
    return np.stack((radial/(length+1),krad/length,-2*mass/radius**3,3*charge**2/radius**4,rho,scalar,field,normal,grad[0],other,second,grad[1]))


def run(mesh,case):
    guard()
    dest=target("sync",mesh,case)
    if dest.exists():
        raise FileExistsError(dest)
    system,state=preparation(mesh,case)
    exterior=system.x>=5.5
    init=state[:,exterior].copy()
    keep=(system.x>=5.84)&(system.x<=6.66)
    ray=5.5
    periods=int(np.ceil(.004/(.26*system.dx)))
    step=.004/periods
    samples,bank,edge=[],[],[]
    for tick in range(810*periods+1):
        if tick%periods==0:
            bank.append(snapshot(system,state,keep))
            samples.append(system.rate(state,ray,True))
            edge.append(ray)
        if tick%100==0:
            guard()
        if tick==810*periods:
            break
        first,one=system.rate(state,ray)
        second,two=system.rate(state+step/2*first,ray+step/2*one)
        third,three=system.rate(state+step/2*second,ray+step/2*two)
        fourth,four=system.rate(state+step*third,ray+step*three)
        state+=step/6*(first+2*second+2*third+fourth)
        ray+=step/6*(one+2*two+2*three+four)
    assert np.isfinite(bank).all() and np.isfinite(samples).all()
    dump(dest,bank=bank,local=samples,ray=edge,time=np.arange(811)*.004,space=system.x[keep],init=init,
         mask=system.x[exterior],previous=LOCK,freeze=bridge.sha(HERE/"frozen.json"))
    print(dest.name,flush=True)


if __name__=="__main__":
    frozen()
    for case in sys.argv[1:]:
        for mesh in (80,160):
            run(mesh,case)

