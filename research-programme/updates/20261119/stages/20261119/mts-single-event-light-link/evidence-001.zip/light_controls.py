from ray_transfer import *
from scipy.integrate import quad, solve_ivp
from scipy.optimize import brentq


def analytic_charged(total,charge):
    rstar=quad(lambda radius:1/(1-2*total/radius+(charge/radius)**2),6,6.5,epsabs=1e-14)[0]
    trajectories=[]
    for index,radius in enumerate(SITES):
        energy=np.sqrt(1-2*total/radius+(charge/radius)**2)
        def rates(proper,state):
            displacement,speed,uplus,uminus=state
            rnow=radius+displacement
            return [speed,-total/rnow**2+charge**2/rnow**3,1/(energy+speed)-1,1/(energy-speed)-1]
        orbit=solve_ivp(rates,(0.,3.24),np.zeros(4),method="DOP853",rtol=2e-13,atol=1e-18,dense_output=True,max_step=.05)
        assert orbit.success
        trajectories.append((energy,orbit.sol))
    def leg(emit,direction):
        start,end=(0,1) if direction==1 else (1,0)
        slot=2 if direction==1 else 3
        ei,first=trajectories[start]
        er,last=trajectories[end]
        launch=first(emit)
        extra=np.full_like(emit,rstar-.5)
        for _ in range(5):
            extra=rstar-.5+launch[slot]-last(emit+.5+extra)[slot]
        recv=last(emit+.5+extra)
        log=np.log1p((ei-er+direction*(launch[1]-recv[1]))/(er+direction*recv[1]))
        return log,extra
    one,delay=leg(EMIT,1)
    mask=EMIT<=2.1
    two,extra=leg(EMIT[mask]+.5+delay[mask],-1)
    return dict(log_ratio=one,delay=delay,echo_log_ratio=one[mask]+two,echo_delay=delay[mask]+extra)


def analytic_controls():
    times=np.arange(876)*.004
    xx=np.linspace(5.84,6.66,34)
    rows=[]
    for rate in (0.,.015):
        length=np.exp(rate*times)
        box=np.ones((len(times),len(xx)))
        vals=np.stack(((length-1)[:,None]*box,(-rate*length)[:,None]*box,-rate**2*box,0*box,0*box,0*box),axis=1)
        data=dict(time=times,space=xx,bank=vals)
        result=both(synchronous,data,32,1)
        for name,span in (("",.5),("echo_",1.)):
            proper=result[name+"emit"]
            expected=np.log1p(-rate*span*np.exp(rate*proper))
            exact_delay=-expected/rate-span if rate else np.zeros_like(proper)
            drift=-rate**2*span*np.exp(rate*proper-expected)
            for key,num,ref in (("log_ratio",result[name+"log_ratio"],expected),("delay",result[name+"delay"],exact_delay),
                                 ("drift",np.sum(result[name+"drift_terms"],axis=0),drift)):
                error=float(max(abs(num-ref)))
                assert error<4e-12
                rows.append(dict(control="flat" if not rate else "expanding",link=name or "direct",quantity=key,absolute=error))
    alpha=1+.0002*np.sin(times)
    drift=.0002*(1-np.cos(times))
    world=np.zeros((len(times),4,2))
    world[:,1]=drift[:,None]
    values=np.stack(((alpha-1)[:,None]*box,0*box),axis=1)
    gauged=both(polar,dict(time=times,space=xx,bank=values,world=world),32,1)
    for name in ("log_ratio","delay","echo_log_ratio","echo_delay"):
        err=float(max(abs(gauged[name])))
        assert err<1e-12
        rows.append(dict(control="flat_changed_time_coordinate",link="echo" if "echo" in name else "direct",quantity=name,absolute=err))
    return rows


if __name__=="__main__":
    print(len(analytic_controls()),"analytic checks")

