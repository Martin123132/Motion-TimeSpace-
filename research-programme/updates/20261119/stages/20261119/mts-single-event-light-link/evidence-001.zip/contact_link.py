from ray_transfer import *
from scipy.integrate import solve_ivp


class Contact:
    def __init__(self,bank,basis):
        self.tt=bank["time"]
        space=bank["space"]
        values=bank["bank"]
        radial=values[:,0]
        length=1+radial
        field,normal,grad=values[:,6],values[:,7],values[:,8]
        trace=normal**2-grad**2-2*field**2
        zeros=np.zeros_like(trace)
        if basis=="tensor":
            htt=(normal**2+grad**2+field**2)/2
            htx=length*normal*grad
            hrr=(normal**2+grad**2-field**2)/2
        else:
            htt,htx,hrr=-trace,zeros,trace
        self.surfaces=[RectBivariateSpline(self.tt,space,channel,kx=5,ky=5) for channel in (radial,values[:,1],htt,htx,hrr)]

    def at(self,idx,time,space,dx=0):
        return self.surfaces[idx].ev(time,space,dy=dx)

    def linear_clocks(self):
        shifts=[]
        for position in SITES:
            tt=self.tt
            xx=np.full_like(tt,position)
            length=1+self.at(0,tt,xx)
            htt=self.at(2,tt,xx)
            htx=self.at(3,tt,xx)
            px=spline(tt,self.at(2,tt,xx,1)/2).antiderivative()
            velocity=(px(tt)-px(0)+htx[0]-htx)/length**2
            dis=spline(tt,velocity).antiderivative()
            proper=spline(tt,-htt/2).antiderivative()
            shifts.append(spline(tt,np.stack((dis(tt)-dis(0),proper(tt)-proper(0)),axis=1)))
        return shifts

    def linear(self,emission,sigma,shifts,panels):
        begin,end=(0,1) if sigma==1 else (1,0)
        def rhs(offset,state):
            tt=emission+offset+state[0]
            xx=np.full_like(tt,SITES[begin]+sigma*offset)
            small=self.at(0,tt,xx)
            length=1+small
            adot=-self.at(1,tt,xx)
            htt,htx,hrr=[self.at(index,tt,xx) for index in (2,3,4)]
            light_source=length*(htt+hrr)/2+sigma*htx
            return np.stack((small,adot,adot*state[2]+light_source))
        delay,log_j,path_only=march(rhs,3,.5,panels,len(emission))
        arrival=emission+.5+delay
        jac=np.exp(log_j)
        def endpoint(index,time):
            offset,proper=shifts[index](time).T
            aa=1+self.at(0,time,np.full_like(time,SITES[index]))
            return proper+sigma*aa*offset
        endpoints=endpoint(end,arrival)-jac*endpoint(begin,emission)
        return dict(delay=delay,jac=jac,light=path_only,clocks=endpoints,total=path_only+endpoints)

    def adm(self,tt,xx,strength,gradient=False):
        radial=self.at(0,tt,xx)
        length=1+radial
        htt,htx,hrr=[self.at(idx,tt,xx) for idx in (2,3,4)]
        spatial=length**2*(1+strength*hrr)
        mixed=strength*htx
        shift=mixed/spatial
        lapse2=1-strength*htt+mixed*shift
        assert np.all(spatial>0) and np.all(lapse2>0)
        lapse=np.sqrt(lapse2)
        if not gradient:
            return spatial,shift,lapse
        dd,dh,dm,dr=[self.at(idx,tt,xx,1) for idx in (0,2,3,4)]
        spatial_x=2*dd*spatial/length+length**2*strength*dr
        shift_x=(strength*dm-shift*spatial_x)/spatial
        lapse_x=(-strength*dh+strength*dm*shift+mixed*shift_x)/(2*lapse)
        return spatial,shift,lapse,spatial_x,shift_x,lapse_x

    def nonlinear_clocks(self,strength):
        history=[]
        for pos in SITES:
            def rate(tt,state):
                offset,momentum,proper=state
                xx=pos+offset
                spatial,shift,lapse,spatial_x,shift_x,lapse_x=self.adm(tt,xx,strength,True)
                gamma=np.sqrt(1+momentum**2/spatial)
                speed=lapse*momentum/(gamma*spatial)-shift
                push=-lapse_x*gamma+lapse*momentum**2*spatial_x/(2*gamma*spatial**2)+shift_x*momentum
                return [speed,push,lapse/gamma-1]
            start=strength*self.at(3,0.,pos)/np.sqrt(1-strength*self.at(2,0.,pos))
            track=solve_ivp(rate,(0.,self.tt[-1]),[0.,start,0.],method="DOP853",rtol=1e-10,
                            atol=[1e-17,1e-17,1e-16],max_step=.025,t_eval=self.tt)
            assert track.success
            offsets,mom,proper=track.y
            spatial,shift,lapse=self.adm(self.tt,pos+offsets,strength)
            velocities=lapse*mom/(spatial*np.sqrt(1+mom**2/spatial))-shift
            history.append((spline(self.tt,np.column_stack((offsets,velocities,proper))),spline(self.tt+proper,-proper)))
        return history

    def nonlinear(self,emission,sigma,strength,paths,panels):
        begin,end=(0,1) if sigma==1 else (1,0)
        start=emission+paths[begin][1](emission)
        def rate(fraction,state):
            tt=start+.5*fraction+state[0]
            first=paths[begin][0](tt)
            second=paths[end][0](tt)
            xx=SITES[begin]+sigma*.5*fraction+(1-fraction)*first[:,0]+fraction*second[:,0]
            width=sigma*(second[:,0]-first[:,0])
            frame=(1-fraction)*first[:,1]+fraction*second[:,1]
            spatial,shift,lapse=self.adm(tt,xx,strength)
            delta=lapse/np.sqrt(spatial)-1-sigma*(shift+frame)
            return np.array([(width-.5*delta)/(1+delta)])
        duration=march(rate,1,1.,panels,len(emission))[0]
        arrival=start+.5+duration
        return duration+paths[end][0](arrival)[:,2]-paths[begin][0](start)[:,2]


def variations(case,mesh,basis):
    guard()
    dest=target("contact-"+basis,mesh,case)
    if dest.exists():
        raise FileExistsError(dest)
    source=target("sync",mesh,case)
    setup=Contact(bridge.read(source),basis)
    clocks=setup.linear_clocks()
    mask=EMIT<=2.1
    first=setup.linear(EMIT,1,clocks,64)
    reflection=EMIT[mask]+.5+first["delay"][mask]
    second=setup.linear(reflection,-1,clocks,64)
    answer={}
    for member in ("light","clocks","total"):
        answer["out_"+member]=first[member]
        answer["echo_"+member]=second["jac"]*first[member][mask]+second[member]
    for prefix,times,jac in (("out_",EMIT,first["jac"]),("echo_",EMIT[mask],second["jac"]*first["jac"][mask])):
        for member in ("light","clocks","total"):
            answer[prefix+"frequency_"+member]=-spline(times,answer[prefix+member]).derivative()(times)/jac**2
    if mesh in (160,320):
        for strength in (-2.,-1.,1.,2.):
            orbits=setup.nonlinear_clocks(strength)
            outgoing=setup.nonlinear(EMIT,1,strength,orbits,64)
            incoming=setup.nonlinear(EMIT[mask]+.5+outgoing[mask],-1,strength,orbits,64)
            for prefix,values,times in (("out",outgoing,EMIT),("echo",outgoing[mask]+incoming,EMIT[mask])):
                answer[f"finite_{strength:g}_{prefix}"]=values
                slope=spline(times,values).derivative()(times)
                answer[f"finite_{strength:g}_{prefix}_freq"]=-slope/(1+slope)
    dump(dest,**answer,source=bridge.sha(source))
    print(dest.name,flush=True)


if __name__=="__main__":
    for case in ("massive-quiet","massive-event"):
        for mesh in (80,160):
            for basis in ("tensor","trace"):
                variations(case,mesh,basis)

