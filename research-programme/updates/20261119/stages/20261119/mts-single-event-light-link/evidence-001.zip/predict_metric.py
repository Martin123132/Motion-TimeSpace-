from shared_link import *
from scipy.interpolate import CubicSpline


def run(case,res):
    guard()
    dest=target("polar",res,case)
    if (HERE/"frozen.json").exists() or dest.exists():
        raise FileExistsError(dest)
    model,kind=case.split("-")
    solver=Forecaster(res,model)
    state=solver.initial.copy()
    state[3]=0
    if kind=="event":
        envelope,_=shape(solver.rad)
        state[0]+=coefficient()*envelope
        state[1]=.0002*envelope
    solver.mu2=int(model!="ordinary")
    reference=solver.geometry(state)
    if model=="massless":
        state[3]=state[0]/np.sqrt(reference["factor"])
        solver.mu2=0
    launch=solver.geometry(state)
    match=max(np.max(abs(launch[key]-reference[key])) for key in ("charge","mass","factor","current","energy"))
    assert match<2e-14
    exterior=solver.rad>=5.5
    mass=launch["mass"][-1]+.5*launch["charge"][-1]**2/solver.rad[-1]
    init=np.stack([launch[key][exterior] for key in ("mass","charge","factor","current","pressure","alpha")])
    keep=(solver.rad>=5.85)&(solver.rad<=6.65)
    world=np.zeros((3,2))
    def rates(fields,orbit):
        values,move=solver.rates(fields,orbit)
        move[2]-=1
        return values,move
    periods=int(np.ceil(.004/(.25*solver.grid.step)))
    step=.004/periods
    banks,clocks=[],[]
    for tick in range(810*periods+1):
        if tick%periods==0:
            geo=solver.geometry(state)
            positions=SITES+world[0]
            fac=solver.grid.at(geo["factor"],positions)
            pcan=world[1]
            boost=np.sqrt(fac)*pcan
            velocity=solver.grid.at(geo["alpha"],positions)*fac*pcan/np.sqrt(1+boost**2)
            log_endpoint=.5*np.log(fac)-np.arcsinh(boost)
            banks.append(np.stack(((geo["bridge"]-1)[keep],(geo["bridge"]*(geo["lp"]-geo["ls"]))[keep])))
            clocks.append(np.stack((world[0],world[2],velocity,log_endpoint)))
        if tick%100==0:
            guard()
        if tick==810*periods:
            break
        first,one=rates(state,world)
        second,two=rates(state+step*first/2,world+step*one/2)
        third,three=rates(state+step*second/2,world+step*two/2)
        fourth,four=rates(state+step*third,world+step*three)
        state+=step/6*(first+2*second+2*third+fourth)
        world+=step/6*(one+2*two+2*three+four)
    assert np.isfinite(banks).all() and np.isfinite(clocks).all()
    dump(dest,bank=banks,world=clocks,space=solver.rad[keep],time=np.arange(811)*.004,init=init,mass=mass,
         charge=launch["charge"][-1],match=match,previous=LOCK,protocol=bridge.sha(HERE/"PROTOCOL.md"))
    print(dest.name,flush=True)


if __name__=="__main__":
    for case in sys.argv[1:]:
        assert case in CASES
        for res in meshes(case):
            run(case,res)

