from receive_metric import preparation
from ray_transfer import *
from scipy.integrate import solve_ivp
from scipy.optimize import brentq
from scipy.special import betainc
from scipy.constants import c as speed_light, G as newton, parsec, electron_volt


class DiluteLaunch:
    def __init__(self):
        seed=Forecaster(7680,"massive")
        knots=seed.rad
        field=seed.initial[0]
        self.h=make_interp_spline(np.r_[-knots[8:0:-1],knots],np.r_[field[8:0:-1],field],k=5)
        self.den=lambda rad: seed.initial[4,0]*np.maximum(1-(rad/5)**2,0)**6
        self.charge=lambda rad:.0016*betainc(1.5,7,np.minimum((rad/5)**2,1))
        def base(rad,state):
            inv=1/rad if rad else 0.
            fac=1-(2*state[0]-self.charge(rad)**2*inv)*inv
            return [rad**2*self.den(rad)*np.sqrt(fac)+.8*rad*self.den(rad)*self.charge(rad)]
        answer=solve_ivp(base,(0.,24.),[0.],method="DOP853",rtol=5e-14,atol=1e-20,max_step=.075,dense_output=True)
        assert answer.success
        domain=np.linspace(0.,24.,12001)
        inv=np.zeros_like(domain)
        inv[1:]=1/domain[1:]
        self.fac=make_interp_spline(domain,1-(2*answer.sol(domain)[0]-self.charge(domain)**2*inv)*inv,k=5)
        self.mass=lambda xx:answer.sol(xx)[0]-self.charge(xx)**2/(2*xx)

    def difference(self,z,coefficient,kick,stop):
        def rhs(rad,state):
            base=self.fac(rad)
            fac=base-(2*z*state[0]/rad if rad else 0)
            envelope,grad=shape(rad)
            scalar=self.h(rad)+coefficient*envelope
            slope=self.h(rad,1)+coefficient*grad
            source=(fac*(slope**2+(kick*envelope)**2)+scalar**2)/2
            return [-2*rad*self.den(rad)*state[0]/(np.sqrt(base)+np.sqrt(fac))+rad**2*source]
        answer=solve_ivp(rhs,(0.,stop),np.zeros(1,dtype=np.result_type(z,float)),method="DOP853",
                         rtol=3e-13,atol=1e-20,max_step=.08,dense_output=True)
        assert answer.success
        return answer.sol

    def match(self,z):
        quiet=self.difference(z,0.,0.,5.5)(5.5)[0]
        obj=lambda value:self.difference(z,value,.0002,5.5)(5.5)[0]-quiet
        return brentq(obj,-3.94e-5,0,xtol=3e-19)

    def actual_scale(self):
        context=json.loads((OLD.parent/"mts-two-radius-pressure-clock-20261119"/"physical-clock-scale.json").read_text())
        length=context["length_pc"]*parsec
        conversion=speed_light**4/(4*np.pi*newton*length**2*1e9*electron_volt*1e6)
        def residual(z):
            delta=self.difference(z,0.,0.,6.)(6.)[0]
            factor=self.fac(6.)-2*z*delta/6
            return z*(factor*self.h(6.,1)**2+self.h(6.)**2)*conversion/2-context["normalization_GeV_cm3"]
        return brentq(residual,0,1e-6,xtol=1e-21)

    def analytic_match(self,z):
        real=self.match(float(np.real(z)))
        quiet=self.difference(z,0.,0.,5.5)(5.5)[0]
        def residual(value):
            return self.difference(z,value,.0002,5.5)(5.5)[0]-quiet
        direction=(residual(real+1e-9)-residual(real-1e-9))/(2e-9)
        result=real-residual(real)/direction
        assert abs(residual(result))<1e-17
        return result

    def initial(self,mesh,z,coefficient,kick):
        solver,state=preparation(mesh,"ordinary-quiet")
        solver.mu2=1.
        xx=solver.x
        delta=self.difference(z,coefficient,kick,24.)(xx)[0]
        mass=self.mass(xx)+z*delta
        deficit=2*mass/xx
        factor=1-deficit
        envelope,slope=shape(xx)
        amp=np.sqrt(z)
        field=amp*(self.h(xx)+coefficient*envelope)
        grad=amp*(self.h(xx,1)+coefficient*slope)
        momentum=amp*kick*envelope
        state=state.astype(np.result_type(z,float))
        state[0]=deficit/factor
        state[2]=-xx*momentum*grad/np.sqrt(factor)
        state[4]=mass/xx**3
        state[5]=field
        state[6]=momentum*np.sqrt(factor)
        return solver,state


def make_bank(mesh,z,name,case):
    guard()
    result=target("dilute-"+name,mesh,case)
    if result.exists():
        raise FileExistsError(result)
    prep=DiluteLaunch()
    if name in ("mid","top"):
        scale=prep.actual_scale()
        z=scale*((.5 if name=="mid" else 1.)+1j)
    cc=(prep.analytic_match(z) if name in ("mid","top") else prep.match(float(np.real(z)))) if case=="event" else 0.
    solver,state=prep.initial(mesh,z,cc,.0002 if case=="event" else 0.)
    keep=(solver.x>=5.84)&(solver.x<=6.66)
    steps=int(np.ceil(.004/(.26*solver.dx)))
    dt=.004/steps
    bank=[]
    for tick in range(810*steps+1):
        if tick%steps==0:
            radial=state[0,keep]
            length=np.sqrt(1+radial)
            bank.append(np.stack((radial/(length+1),state[2,keep]/length)))
        if tick%125==0:
            guard()
        if tick==810*steps:
            break
        first=solver.rate(state,5.5)[0]
        second=solver.rate(state+dt*first/2,5.5)[0]
        third=solver.rate(state+dt*second/2,5.5)[0]
        fourth=solver.rate(state+dt*third,5.5)[0]
        state+=dt/6*(first+2*second+2*third+fourth)
    bank=np.array(bank)
    assert np.isfinite(bank).all()
    dump(result,bank=bank,space=solver.x[keep],time=np.arange(811)*.004,z=z,coefficient=cc,
         protocol=bridge.sha(HERE/"DILUTE-PROTOCOL.md"))
    print(result.name,flush=True)


def rays(bank,panels=64):
    z=bank["z"].item()
    raw=bank["bank"]
    if np.iscomplexobj(raw):
        raw=np.concatenate((raw.real,raw.imag/z.imag),axis=1)
    else:
        raw=np.concatenate((raw,0*raw),axis=1)
    strip=Strip(dict(time=bank["time"],space=bank["space"],bank=raw),1)
    def leg(emission,direction):
        def rhs(offset,state):
            time=emission+offset+state[0]
            xx=np.full_like(time,(6. if direction==1 else 6.5)+direction*offset)
            small,curvature,dsmall,dcurvature=[strip.get(idx,time,xx) for idx in range(4)]
            derivative=strip.surfaces[1].ev(time,xx,dx=1)
            return np.stack((small,curvature,dsmall-curvature*state[2],dcurvature+derivative*state[2],derivative*np.exp(-state[1])))
        return march(rhs,5,.5,panels,len(emission))
    out=leg(EMIT,1)
    mask=EMIT<=2.1
    back=leg(EMIT[mask]+.5+out[0,mask],-1)
    freq=out[1]
    echo=freq[mask]+back[1]
    return {"out":np.expm1(freq),"echo":np.expm1(echo),"out_delay":out[0],"echo_delay":out[0,mask]+back[0],
            "dout":np.exp(freq)*out[3],"decho":np.exp(echo)*(out[3,mask]+back[3]+back[4]*out[2,mask]),
            "dout_delay":out[2],"decho_delay":np.exp(-back[1])*out[2,mask]+back[2]}


if __name__=="__main__":
    mode=sys.argv[1]
    for mesh in ((80,160) if mode=="leading" else (160,)):
        for case in ("quiet","event"):
            make_bank(mesh,{"leading":1e-5j,"step":1e-4j,"quarter":.25,"mid":None,"top":None}[mode],mode,case)

