from link_scores import *
from scipy.constants import physical_constants, c as speed_light, elementary_charge


def score_contacts(finest=160):
    rows=[]
    target_peaks={}
    for name in ("out","echo"):
        key="log_ratio" if name=="out" else "echo_log_ratio"
        target_peaks[name]=peak(pair(data("reception",160,"massive-event"),data("reception",160,"massive-quiet"),key))
    capfile=OLD.parent/"source-intake/functional_rg/4943/interior_stability_benchmarks.csv"
    assert bridge.sha(capfile)=="3c49fdc86490eb936c27fc954b420ab1205fa2e6211e87507cc33cec7f64e3af"
    with capfile.open(newline="") as stream:
        caps=list(csv.DictReader(stream))
    ac=max(float(row["abs_aC_control_cap"]) for row in caps)
    ar=max(float(row["abs_aR_control_cap"]) for row in caps)
    scale=OLD.parent/"mts-two-radius-pressure-clock-20261119/physical-clock-scale.json"
    mass=json.loads(scale.read_text())["example_mass_eV"]
    planck_mass=physical_constants["Planck mass"][0]*speed_light**2/elementary_charge/np.sqrt(8*np.pi)
    ratio=(mass/planck_mass)**2
    cmax={"tensor":16*ac*ratio,"trace":8*(ar+2*ac/3)*ratio}
    conditional=[]
    guard()
    for basis in ("tensor","trace"):
        packets={}
        for mesh in (finest//2,finest):
            for case in ("massive-quiet","massive-event"):
                record=bridge.read(target("contact-"+basis,mesh,case))
                assert str(record["source"])==bridge.sha(target("sync",mesh,case))
                packets[mesh,case]=record
        get=lambda mesh,key:packets[mesh,"massive-event"][key]-packets[mesh,"massive-quiet"][key]
        for link in ("out","echo"):
            for what,post in (("",""),("frequency_","_freq")):
                key=link+"_"+what
                kernel=get(finest,key+"total")
                small=peak(kernel)
                fine=(get(finest,f"finite_1_{link}"+post)-get(finest,f"finite_-1_{link}"+post))/2
                coarse=(get(finest,f"finite_2_{link}"+post)-get(finest,f"finite_-2_{link}"+post))/4
                steps=peak(get(finest//2,key+"total")-kernel)/small
                secant=peak(fine-kernel)/small
                halving=peak(fine-coarse)/small
                budget=steps+secant+halving
                null=peak(get(finest,key+"light"))/small
                rows.append(dict(basis=basis,link=link,observable=what or "travel",peak_derivative=small,
                                 ray_only=peak(get(finest,key+"light")),endpoint_only=peak(get(finest,key+"clocks")),
                                 ray_to_total=null,grid_step=steps,secant_to_analytic=secant,secant_halving=halving,
                                 budget=budget,passed=budget<=TOL))
                if what:
                    conditional.append(dict(link=link,basis=basis,unit_coefficient_response=small,metric_contrast=target_peaks[link],
                                            one_at_a_time_2e5_precision_coefficient=TOL*target_peaks[link]/small,
                                            example_mass_eV=mass,reduced_planck_mass_eV=planck_mass,
                                            conditional_cap=cmax[basis],conditional_fraction_of_metric=cmax[basis]*small/target_peaks[link]))
                if basis=="trace":
                    assert null<1e-10
                assert peak(kernel-get(finest,key+"light")-get(finest,key+"clocks"))/small<1e-10
    return rows,conditional


if __name__=="__main__":
    fine=320 if "320" in sys.argv else 160
    suffix="-320" if fine==320 else ""
    for name,rows in zip((f"contact-budgets{suffix}.csv",f"conditional-coefficients{suffix}.csv"),score_contacts(fine)):
        output(name,rows,"check" in sys.argv)

