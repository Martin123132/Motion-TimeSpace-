from link_scores import *
from scipy.constants import c as speed_light, G as newton, parsec, electron_volt


def context():
    front_rows=[]
    normal=[]
    source=OLD.parent/"mts-two-radius-pressure-clock-20261119/physical-clock-scale.json"
    context=json.loads(source.read_text())
    length=context["length_pc"]*parsec
    conversion=speed_light**4/(4*np.pi*newton*length**2)/(1e9*electron_volt)/1e6
    for case in ("massive-event","massless-event"):
        bank=bridge.read(target("sync",160,case))
        record=data("reception",160,case)
        strip=Strip(bank,1)
        edge=spline(bank["time"],bank["ray"])
        for index in (0,120):
            emit=EMIT[index]
            reflection=emit+.5+record["delay"][index]
            def rhs(distance,travel):
                return [1+strip.get(0,np.asarray(travel),np.array([6.5-distance]))[0]]
            ray=solve_ivp(rhs,(0.,.5),[reflection],method="DOP853",rtol=1e-13,atol=1e-16,
                          dense_output=True,max_step=.02)
            assert ray.success
            crossing=brentq(lambda distance:edge(ray.sol(distance)[0])-(6.5-distance),0.,.5,xtol=1e-14)
            arrival=ray.sol(.5)[0]
            assert abs(arrival-(emit+1+record["echo_delay"][index]))<4e-13
            front_rows.append(dict(model=case,emit=emit,reflect=reflection,meets_edge_at=ray.sol(crossing)[0],
                                   comoving_radius=6.5-crossing,return_time=arrival))
    for case in ("massive-quiet","massive-event"):
        bank=bridge.read(target("sync",160,case))
        fields=bank["bank"]
        eps=(fields[:,6]**2+fields[:,7]**2+fields[:,8]**2)/2
        at_launch=make_interp_spline(bank["space"],eps[0],k=5)(SITES)
        for index,site in enumerate(SITES):
            value=at_launch[index]*conversion
            normal.append(dict(case=case,radius=site,example_length_pc=context["length_pc"],proper_time_unit_years=context["time_unit_years"],
                               initial_rho_code=at_launch[index],initial_GeV_cm3=value,illustrative_comparator_GeV_cm3=context["normalization_GeV_cm3"],
                               ratio_to_comparator=value/context["normalization_GeV_cm3"]))
    return front_rows,normal


if __name__=="__main__":
    for name,records in zip(("echo-front.csv","physical-interpretation.csv"),context()):
        output(name,records,"check" in sys.argv)

