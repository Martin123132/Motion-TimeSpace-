from link_scores import *


def rows():
    result=[]
    for target_model in ("massive","massless"):
        truth={}
        template={}
        other="massless" if target_model=="massive" else "massive"
        for name in ("log_ratio","echo_log_ratio"):
            truth[name]=pair(data("reception",160,target_model+"-event"),data("reception",160,target_model+"-quiet"),name)
            template[name]=pair(data("prediction",15360,other+"-event"),data("prediction",15360,other+"-quiet"),name)
        training=(EMIT>=.65)&(EMIT<=1.175)
        fitted=template["log_ratio"][training]
        gain=np.dot(fitted,truth["log_ratio"][training])/np.dot(fitted,fitted)
        for key in ("log_ratio","echo_log_ratio"):
            use=EMIT>=1.325 if key=="log_ratio" else np.ones(len(truth[key]),dtype=bool)
            signal=truth[key][use]
            residual=gain*template[key][use]-signal
            result.append(dict(target=target_model,predictor=other,link=key,gain=gain,rms= np.linalg.norm(residual)/np.linalg.norm(signal),
                               peak_error=peak(residual)/peak(signal)))
    return result


if __name__=="__main__":
    output("template-transfer.csv",rows(),"check" in sys.argv)

