from link_scores import *
from contact_scores import score_contacts
from feedback_source import rows as feedback
from geometry_context import context
from transfer_shape import rows as shape_results
from dilute_scores import collect
from symbol_link import checks as symbolic_checks
from calendar_transfer import calendar


def audit():
    guard()
    previous=json.loads((OLD/"closeout.json").read_text())
    for name,sha in previous["files"].items():
        assert bridge.sha(OLD/name)==sha
    for name,sha in previous["inherited"].items():
        assert bridge.sha(OLD.parent/name)==sha
    frozen()
    tables=scores()
    tables.update(zip(("echo-front.csv","physical-interpretation.csv"),context()))
    tables["template-transfer.csv"]=shape_results()
    tables["calendar-only-transfer.csv"]=calendar()
    for fine in (160,320):
        suffix="-320" if fine==320 else ""
        tables.update(zip((f"contact-budgets{suffix}.csv",f"conditional-coefficients{suffix}.csv"),score_contacts(fine)))
    tables.update(zip(("feedback-sources.csv","feedback-identities.csv"),feedback()))
    tables.update(zip(("dilute-observables.csv","dilute-budgets.csv","dilute-frequency-and-delay.csv"),collect()))
    counts={}
    for name,rows in tables.items():
        output(name,rows,True)
        counts[name]={"rows":len(rows),"passed":int(sum(row["passed"] for row in rows)) if "passed" in rows[0] else None}
        if name in ("budgets.csv","static-GR-control.csv","contact-budgets-320.csv","identities.csv","feedback-sources.csv","dilute-budgets.csv"):
            assert all(row["passed"] for row in rows),name
    assert not list(HERE.glob("*.partial")) and not (HERE/"__pycache__").exists()
    for case in CASES:
        for mesh in (80,160):
            item=bridge.read(target("sync",mesh,case))
            assert str(item["freeze"])==bridge.sha(HERE/"frozen.json")
    dependency={}
    for module in list(sys.modules.values()):
        path=getattr(module,"__file__",None)
        if path:
            source=Path(path).resolve()
            if source.is_relative_to(HERE.parent) and not source.is_relative_to(HERE) and source.suffix==".py":
                dependency[source.relative_to(HERE.parent).as_posix()]=bridge.sha(source)
    for pattern in ("4933-*.md","4943-*.md","4945-*.md","4964-*.md","MTS-EM-TWO-PHOTON-MOTION-PAIR.md",
                    "MTS-HEAVY-BATH-COUNTERFLOW-AND-GALACTIC-STRESS.md","MTS-ROLLING-BACKGROUND-TWO-PHOTON-MATCH.md",
                    "source-intake/functional_rg/4943/interior_stability_benchmarks.csv",
                    "mts-two-radius-pressure-clock-20261119/physical-clock-scale.json"):
        options=list(HERE.parent.glob(pattern))
        assert len(options)==1,pattern
        source=options[0]
        dependency[source.relative_to(HERE.parent).as_posix()]=bridge.sha(source)
    return dict(previous=LOCK,frozen=bridge.sha(HERE/"frozen.json"),tables=counts,symbolic=symbolic_checks(),dependencies=dependency,
                files={item.name:bridge.sha(item) for item in sorted(HERE.iterdir()) if item.is_file() and item.name!="closeout.json"})


if __name__=="__main__":
    stamp=HERE/"closeout.json"
    summary=audit()
    if sys.argv[1:]==["seal"]:
        payload=json.dumps(summary,sort_keys=True,indent=2)
        if stamp.exists():
            raise FileExistsError(stamp)
        interim=stamp.with_suffix(".partial")
        with interim.open("x") as output_file:
            output_file.write(payload)
        interim.rename(stamp)
    else:
        assert json.loads(stamp.read_text())==summary
    print(bridge.sha(stamp),len(summary["files"]),"files",sum(row["rows"] for row in summary["tables"].values()),"rows",flush=True)

