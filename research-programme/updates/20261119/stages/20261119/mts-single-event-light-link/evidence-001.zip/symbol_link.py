import sympy as sp


def checks():
    omega,radial,theta,weyl,conn,dielectric,quartic,axial,background,flux,response=sp.symbols("omega radial theta W c Z quartic axial E flux response",real=True)
    electric=sp.Matrix([0,background,0,0])
    def bivector(first,second):
        return [first[i]*second[j]-first[j]*second[i] for i,j in ((0,1),(0,2),(0,3),(2,3),(3,1),(1,2))]
    coeffs=[-2,1,1,2,-1,-1]
    relat=[-1,-1,-1,1,1,1]
    physical=sp.Matrix([omega,radial,0,0])
    transverse=sp.Matrix([0,0,1,0])
    wave=bivector(physical,transverse)
    ksq=-omega**2+radial**2
    contraction=sum(c*v*v for c,v in zip(coeffs,wave))*weyl
    angled=sp.Matrix([omega,omega*sp.cos(theta),omega*sp.sin(theta),0])
    responses=[]
    for pol in (sp.Matrix([0,-sp.sin(theta),sp.cos(theta),0]),sp.Matrix([0,0,0,1])):
        wedge=bivector(angled,pol)
        responses.append(sum(c*v*v for c,v in zip(coeffs,wedge))*weyl)
    tangential=bivector(sp.Matrix([omega,0,radial,0]),sp.Matrix([0,1,0,0]))
    quadratic=lambda wave: -dielectric*sum(c*v*v for c,v in zip(relat,wave))/2+4*conn*weyl*sum(c*v*v for c,v in zip(coeffs,wave))
    tagged=[electric[1]+flux*wave[0],*[flux*v for v in wave[1:]]]
    inv=2*sum(c*v*v for c,v in zip(relat,tagged))
    dual=4*sum(left*right for left,right in zip(tagged[:3],tagged[3:]))
    lag=-dielectric*inv/4+quartic*inv**2+axial*dual**2
    identities={
        "radial_weyl_screen":contraction+weyl*ksq,
        "radial_action_hessian":sp.diff(quadratic(wave)*flux**2,flux,2)+(dielectric+8*conn*weyl)*ksq,
        "tilted_first_screen":responses[0]+3*weyl*omega**2*sp.sin(theta)**2,
        "tilted_second_screen":responses[1]-3*weyl*omega**2*sp.sin(theta)**2,
        "radial_F4_hessian":sp.diff(lag,flux,2).subs(flux,0)+(dielectric+16*quartic*background**2)*ksq,
        "radial_FdualF":dual,
        "nonradial_full_action":sp.diff(quadratic(tangential)*flux**2,flux,2).subs(radial,omega)+24*conn*weyl*omega**2,
    }
    pi,space=sp.symbols("Pi s",real=True)
    for sigma in (-1,1):
        identities["stress_cone_"+str(sigma)]=(pi**2+space**2)/2+2*sigma*pi*space+(pi**2+space**2)/2-(pi+sigma*space)**2
    for name,expression in identities.items():
        assert sp.trigsimp(sp.expand(expression))==0,name
    return list(identities)


if __name__=="__main__":
    print(checks())

