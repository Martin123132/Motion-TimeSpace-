from light_controls import *
import io
from scipy.interpolate import CubicSpline

KEYS=("log_ratio","delay","echo_log_ratio","echo_delay")
peak=lambda values:float(np.max(np.abs(values)))


def data(method,res,case):
    path=target(method,res,case)
    record=bridge.read(path)
    bank=target("polar" if method=="prediction" else "sync",res,case)
    assert str(record["bank_sha"])==bridge.sha(bank)
    return record


def pair(a,b,key,prefix=""):
    if b is None:
        return np.expm1(a[prefix+key]) if "ratio" in key else a[prefix+key]
    if "ratio" in key:
        return np.exp(b[prefix+key])*np.expm1(a[prefix+key]-b[prefix+key])
    return a[prefix+key]-b[prefix+key]


def mark(rows,method,link,observable,label,error,scale):
    assert scale>0
    fraction=peak(error)/scale
    rows.append(dict(method=method,link=link,quantity=observable,check=label,relative=fraction,passed=fraction<=TOL))


def identity(arm,quiet,method,prefix,checks,drift_rows):
    times=arm[prefix+"emit"]
    length=len(times)
    flag=lambda entry:0 if quiet is None else quiet[entry]
    difference=(arm[prefix+"log_ratio"]-flag(prefix+"log_ratio"))
    direct=arm[prefix+"log_ratio"]
    diff_delay=arm[prefix+"delay"]-flag(prefix+"delay")
    delay_rate=spline(times,diff_delay).derivative()(times)
    quiet_rate=0. if quiet is None else spline(times,quiet[prefix+"delay"]).derivative()(times)
    by_arrival=-np.log1p(delay_rate/(1+quiet_rate))
    mark(checks,method,prefix or "out","log_ratio","emission_vs_arrival_derivative",difference-by_arrival,peak(difference))
    if prefix+"drift_terms" not in arm:
        return
    terms=arm[prefix+"drift_terms"]-flag(prefix+"drift_terms")
    drift=spline(times,difference).derivative()(times)
    mark(checks,method,prefix or "out","log_frequency_drift","integrated_radial_tide",drift-terms.sum(axis=0),peak(drift))
    mass_only=terms[0]
    without_scalar=terms[:3].sum(axis=0)
    pivot=int(np.argmax(abs(drift)))
    drift_rows.append(dict(case=method,link=prefix or "out",emission_at_peak=times[pivot],frequency_drift=drift[pivot],
                           mass=terms[0,pivot],electric=terms[1,pivot],dust=terms[2,pivot],scalar=terms[3,pivot],
                           mass_only_error=peak(drift-mass_only)/peak(drift),without_scalar_error=peak(drift-without_scalar)/peak(drift)))


def scores():
    guard()
    frozen()
    bank={}
    for case in CASES:
        for method,counts in (("prediction",meshes(case)),("reception",(80,160))):
            for res in counts:
                bank[case,method,res]=data(method,res,case)
    budgets,stability,checks,summary,history,drifts,physics,limits=[],[],[],[],[],[],[],[]
    causal={}
    for model in ("massive","massless"):
        source=bridge.read(target("sync",160,model+"-event"))
        front=brentq(spline(source["time"],source["ray"]-6.),.4,.65,xtol=1e-14)
        outside=brentq(spline(source["time"],source["ray"]-6.5),.9,1.15,xtol=1e-14)
        causal[model]=front
        physics.append(dict(check="two_null_crossings",model=model,value=front,reference=outside,meaning="inner and outer causal proper times"))
    labels=[(case,None) for case in CASES]+[(model+"-event",model+"-quiet") for model in ("massive","massless")]
    for case,quiet in labels:
        label=case if quiet is None else case.split("-")[0]+"-change"
        def packets(method,res):
            return bank[case,method,res],bank.get((quiet,method,res))
        trials=[packets(method,res) for method,res in (("prediction",meshes(case)[0]),("prediction",meshes(case)[1]),
                                                       ("reception",80),("reception",160))]
        for key in KEYS:
            vectors=[pair(arm,base,key) for arm,base in trials]
            finest=vectors[-1]
            peak_size=peak(finest)
            pc,pf,rc,rf=vectors
            contributions=np.array([peak(pc-pf),peak(rc-rf),peak(pf-rf)])/peak_size
            fine_studies=[]
            for method,(arm,base) in zip(("polar","synchronous"),(trials[1],trials[3])):
                for refine in ("coarse_","thin_"):
                    delta=peak(pair(arm,base,key,refine)-pair(arm,base,key))/peak_size
                    stability.append(dict(case=label,method=method,quantity=key,change=refine,relative=delta,passed=delta<=TOL))
                    fine_studies.append(delta)
            error=sum(contributions)+sum(fine_studies)
            budgets.append(dict(case=label,quantity=key,peak=peak_size,polar_grid=contributions[0],sync_grid=contributions[1],
                                independent=contributions[2],propagation_and_sampling=sum(fine_studies),total=error,passed=error<=TOL))
            if quiet:
                prefix="echo_" if key.startswith("echo") else ""
                times=trials[-1][0][prefix+"emit"]
                idx=int(np.argmax(abs(finest)))
                leak=peak(finest[times<=.45])/peak_size if not prefix else None
                threshold=np.flatnonzero(abs(finest)>=.05*peak_size)
                summary.append(dict(model=case.split("-")[0],quantity=key,value_at_release=finest[0],minimum=np.min(finest),maximum=np.max(finest),
                                    signed_peak=finest[idx],peak_emit=times[idx],peak_receive=times[idx]+(1. if prefix else .5)+trials[-1][0][prefix+"delay"][idx],
                                    first_sample_5pct=times[threshold[0]],prefront_fraction=leak))
                if not prefix:
                    assert threshold[0]>0
                if "ratio" in key:
                    for index in range(len(times)):
                        history.append(dict(model=label,link=prefix or "out",emit=times[index],proper_arrival=times[index]+(.5 if not prefix else 1)+trials[-1][0][prefix+"delay"][index],forecast=pf[index],receiver=rf[index],excess_travel=pair(*trials[-1],prefix+"delay")[index]))
        for method,(arm,base) in zip(("polar","synchronous"),(trials[1],trials[3])):
            for prefix in ("","echo_"):
                identity(arm,base,label+"/"+method,prefix,checks,drifts)
        if quiet:
            for method,res in (("polar",meshes(case)[1]),("sync",160)):
                left=bridge.read(target(method,res,quiet))
                right=bridge.read(target(method,res,case))
                if method=="polar":
                    mi=peak(left["init"][0]-right["init"][0])
                    qe=peak(left["init"][1]-right["init"][1])
                    strength=float(next(row["untreated_added_mass"] for row in csv.DictReader((OLD/"compensated-launch.csv").read_text().splitlines()) if float(row["impulse"])==.0002))
                else:
                    xx=right["mask"]
                    mi=peak((left["init"][4]-right["init"][4])*xx**3)
                    qe=peak(left["init"][11]-right["init"][11])
                ratio=mi/strength
                assert qe==0 and ratio<TOL
                physics.append(dict(check="launch_exterior_mass/"+method,model=label,value=mi,reference=ratio,meaning="absolute and relative to uncompensated injected mass"))
    for res in (80,160):
        current=bridge.read(target("sync",res,"massive-quiet"))["local"]
        past=bridge.read(OLD/f"receiver-{res}-massive-0.npz")["records"][:,::2,:].transpose(1,0,2)
        assert np.allclose(current,past,atol=1e-18,rtol=0.)
        ordinary=bridge.read(target("sync",res,"ordinary-quiet"))["local"]
        oldroot=OLD.parent/"mts-two-radius-pressure-clock-20261119"
        dx=.0125
        dead=bridge.read(oldroot/f"detector-{dx:g}-ordinary.npz")["records"][:,:163,:]
        for col,entry in ((2,0),(3,1)):
            error=peak(ordinary[::5,:,col].T-dead[:,:,entry])/peak(dead[:,:,entry])
            physics.append(dict(check="historical_electrovac/"+str(res),model="ordinary",value=error,reference=TOL,meaning="relative to prior untagged fall"))
            assert error<TOL
    raw=bridge.read(target("polar",3840,"ordinary-quiet"))
    analytic=analytic_charged(float(raw["mass"]),float(raw["charge"]))
    for method,grid in (("prediction",3840),("reception",160)):
        for key in KEYS:
            ref=analytic[key]
            distance=peak(bank["ordinary-quiet",method,grid][key]-ref)/peak(ref)
            limits.append(dict(method=method,quantity=key,relative=distance,passed=distance<=TOL))
    return {"budgets.csv":budgets,"propagation-accuracy.csv":stability,"identities.csv":checks,"observables.csv":summary,
            "frequency-history.csv":history,"tidal-sources.csv":drifts,"launch-and-old-controls.csv":physics,
            "static-GR-control.csv":limits,"analytic-controls.csv":analytic_controls()}


def output(name,rows,check):
    stream=io.StringIO(newline="")
    writer=csv.DictWriter(stream,fieldnames=list(rows[0]),lineterminator="\n")
    writer.writeheader()
    writer.writerows(rows)
    payload=stream.getvalue().encode()
    if check:
        assert (HERE/name).read_bytes()==payload,name
    else:
        with (HERE/name).open("xb") as file:
            file.write(payload)
    passed=sum(row["passed"] for row in rows) if "passed" in rows[0] else None
    print(name,len(rows),passed,flush=True)


if __name__=="__main__":
    for name,rows in scores().items():
        output(name,rows,"check" in sys.argv)

