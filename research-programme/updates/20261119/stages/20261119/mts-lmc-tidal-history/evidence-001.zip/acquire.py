from lmc_io import *
import struct,zipfile,zlib,re,time
import requests

URL="https://zenodo.org/records/8015660/files/archive.zip"
def ingest():
    guard()
    result=requests.get("https://zenodo.org/api/records/8015660",timeout=30);result.raise_for_status()
    record=result.json();assert str(record["id"])=="8015660"
    file=next(item for item in record["files"] if item["key"]=="archive.zip")
    size=int(file["size"])
    metadata("archive-receipt.json",dict(url=URL,id=record["id"],doi=record["doi"],archive_bytes=size,publisher_checksum=file["checksum"],
                                        license=record["metadata"].get("license"),title=record["metadata"]["title"]))
    client=requests.Session()
    def block(start,end):
        for attempt in range(3):
            try:
                with client.get(URL+f"?mtsrange={start}-{end}",headers={"Range":f"bytes={start}-{end}","Accept-Encoding":"identity"},timeout=55,stream=True) as res:
                    assert res.status_code==206 and res.headers.get("Content-Range")==f"bytes {start}-{end}/{size}",(res.status_code,res.headers.get("Content-Range"))
                    raw=res.content;assert len(raw)==end-start+1;return raw
            except (requests.RequestException,AssertionError):
                if attempt==2:raise
                time.sleep(2)
    tail=block(size-65557,size-1);ending=struct.unpack_from("<4s4H2IH",tail,tail.rfind(b"PK\x05\x06"));offset=ending[-2]
    directory=block(offset,size-1);save("archive-central-directory.bin",directory)
    archive=zipfile.ZipFile(io.BytesIO(directory))
    take=lambda name:name=="readme.txt" or re.fullmatch(r"[^/]+/(trajlmc\.txt|boundmass\.txt|accel\.txt|potential[^/]*\.ini|pot/lmc\d+\.ini)",name) is not None
    entries=[info for info in archive.infolist() if take(info.filename)]
    rows=[];groups=[]
    for info in sorted(entries,key=lambda item:item.header_offset):
        pos=info.header_offset+offset;end=pos+30+len(info.filename.encode())+len(info.extra)+info.compress_size+160
        if not groups or pos-groups[-1][1]>1024 or end-groups[-1][0]>10000000:groups.append([pos,end,[]])
        groups[-1][1]=max(groups[-1][1],end);groups[-1][2].append(info)
    for start,end,items in groups:
        guard();end=min(end,size-1);raw=None
        for info in items:
            name="source/"+info.filename;dest=HERE/name
            if not dest.exists():
                if raw is None:raw=block(start,end)
                pos=info.header_offset+offset-start
                assert raw[pos:pos+4]==b"PK\x03\x04"
                nlen,xlen=struct.unpack_from("<HH",raw,pos+26);at=pos+30+nlen+xlen
                assert raw[pos+30:pos+30+nlen].decode()==info.filename
                packed=raw[at:at+info.compress_size];data=zlib.decompress(packed,-15) if info.compress_type==8 else packed
                assert len(data)==info.file_size and zlib.crc32(data)==info.CRC;save(name,data)
            data=dest.read_bytes();assert len(data)==info.file_size and zlib.crc32(data)==info.CRC
            rows.append(dict(path=name,bytes=len(data),zip_crc32=f"{info.CRC:08x}",sha256=sha(dest)))
    table("source-files.csv",rows);print("members",len(rows),"uncompressed",sum(row["bytes"] for row in rows),"selected range bytes",sum(b-a+1 for a,b,_ in groups),flush=True)
if __name__=="__main__":ingest()

