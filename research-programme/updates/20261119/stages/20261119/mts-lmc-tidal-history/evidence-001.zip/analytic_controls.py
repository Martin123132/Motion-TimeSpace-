from lmc_field import *
from lmc_io import read,table
from forcing import gaunt
from sky import force
from scipy.special import roots_legendre

def gradient(xyz,rr,coeff):
    rad=np.linalg.norm(xyz,axis=-1);mu=xyz[:,2]/rad;angle=np.arctan2(xyz[:,1],xyz[:,0]);theta=np.arccos(mu);st=np.sin(theta)
    assert np.min(st)>.05 and rr[0]<min(rad)<=max(rad)<rr[-1]
    interp=CubicHermiteSpline(np.log(rr),coeff[:25],coeff[25:],axis=0)
    values=interp(np.log(rad));rates=interp(np.log(rad),1)/rad[:,None]
    partial=np.zeros((len(rad),3))
    for ell in range(7):
        for order in range(-ell,ell+1):
            func,der=sph_harm_y(ell,abs(order),theta,angle,diff_n=1)
            factor=SQ4*(np.sqrt(2) if order else 1.)
            ang=factor*np.column_stack([func,der]);ang=ang.imag if order<0 else ang.real
            index=ell*(ell+1)+order
            partial[:,0]+=ang[:,0]*rates[:,index];partial[:,1:]+=ang[:,1:]*values[:,index,None]
    er=xyz/rad[:,None];et=np.stack([mu*np.cos(angle),mu*np.sin(angle),-st],axis=1)
    ep=np.stack([-np.sin(angle),np.cos(angle),0*mu],axis=1)
    return partial[:,0,None]*er+partial[:,1,None]*et/rad[:,None]+partial[:,2,None]*ep/(rad*st)[:,None]

def run():
    guard();rows=[]
    p=np.array([[0,0,0],[-6,0,1.5],[-6,0,-1.5],[-8.3,0,1.5],[-8.3,0,-1.5]])
    for model in MODELS:
        ts,rr,coeff,traj=history(model);center=traj[-1,1:4]
        direct=force(p,center,rr,coeff[-1],.01);second=-gradient(p-center,rr,coeff[-1])
        direct=direct[1:]-direct[0];second=second[1:]-second[0]
        err=np.max(np.linalg.norm(direct-second,axis=1)/np.linalg.norm(second,axis=1))
        rows.append(dict(check="independent_gradient",model=model,err=err))
    mu,weight=roots_legendre(72);zero=np.zeros_like(mu)
    for ell,degree,out,order in [(2,0,2,0),(2,1,3,1),(2,2,2,-1),(8,6,12,-3),(18,6,20,4),(36,5,37,-4),(66,5,63,0)]:
        num=np.sum(weight*harmonic(ell,-2,mu,zero)*harmonic(degree,order,mu,zero)*harmonic(out,order-2,mu,zero).conj())/2
        rows.append(dict(check="harmonic_product",model=str((ell,degree,out,order)),err=abs(num-gaunt(ell,degree,out,order))))
    tensor=np.array([[2.,3.,-8.],[3.,-5.,2.],[-8.,2.,1.]])
    for radius in (6.,8.3):
        out=[]
        for height in (1.5,-1.5):
            pos=np.array([-radius,0.,height]);rad=np.linalg.norm(pos)
            et=np.array([-height,0.,-radius])/rad
            out.append((-tensor@pos)@et)
        result=(out[0]-out[1])/2*np.hypot(radius,1.5)/(radius*1.5)
        rows.append(dict(check="general_tensor_parity",model=str(radius),err=abs(result-(tensor[2,2]-tensor[0,0]))))
    table("analytic-controls.csv",rows)
if __name__=="__main__":run()

