from lmc_field import *
from lmc_io import read,table
from retarded_lmc import metric

def pair(row):return np.array([complex(float(row[x+"_re"]),float(row[x+"_im"])) for x in ("displacement","velocity")])

def key(row):return tuple(row[k] for k in ("tag","model","source","start_native","start"))

def run():
    archive={name:{key(row):row for row in read(HERE/f"response-n{name}.csv")} for name in ("6144","3072","3072-radius","3072-halfshapes")}
    controls=[];budgets=[]
    for tag in TAGS:
        with np.load(OLD/(tag+"-external-kernel.npz")) as packet:sigma=float(packet["sigma"])
        for model in MODELS:
            with np.load(HERE/f"drives/{tag}-n6144-t32-l72-{model}.npz") as data:
                high=data["drive_by_l"].sum(axis=0);t=data["time"]
            for variant in ("","radius","halfshapes"):
                folder="drives"+("-"+variant if variant else "")
                with np.load(HERE/f"{folder}/{tag}-n3072-t16-l42-{model}.npz") as data:
                    low=data["drive_by_l"].sum(axis=0);assert np.array_equal(t[::2],data["time"])
                delta=abs(low-high[::2]);norm=abs(high[::2])
                controls.append(dict(tag=tag,model=model,comparison=variant or "grid",peak_normalized_max=delta.max()/norm.max(),
                    max_local_relative=(delta/norm).max(),l2_relative=np.linalg.norm(delta)/np.linalg.norm(norm),
                    present_relative=delta[-1]/norm[-1]))
            for keyval,row in archive["6144"].items():
                if keyval[:2]!=(tag,model):continue
                val=pair(row)
                def diff(other):
                    d=pair(other)-val
                    return metric(*d,sigma)/metric(*val,sigma)
                budgets.append(dict(tag=tag,model=model,source=row["source"],start_native=row["start_native"],start=row["start"],
                    grid_relative_phase_space=diff(archive["3072"][keyval]),radial_interpolation=diff(archive["3072-radius"][keyval]),
                    omit_alternate_shapes=diff(archive["3072-halfshapes"][keyval])))
    table("drive-budget.csv",controls);table("final-state-budget.csv",budgets)
if __name__=="__main__":run()

