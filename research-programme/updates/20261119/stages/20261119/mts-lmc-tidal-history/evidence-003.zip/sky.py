from lmc_field import *
from lmc_io import table,read
from retarded_lmc import probe_coefficients
import sys

def force(points,center,radii,coeff,step,degree=6,logarithmic=True):
    values=[]
    for axis in np.eye(3):
        def offset(mul):return potential(points-center+mul*step*axis,radii,coeff,degree,logarithmic)
        values.append((-offset(-2)+8*offset(-1)-8*offset(1)+offset(2))/(12*step))
    return np.stack(values,axis=-1)

def run():
    guard();resolved={tag:probe_coefficients(tag) for tag in TAGS}
    from feasibility import bands
    limits=bands()
    baseline=read(BAR/"extra-sky.csv");states=read(HERE/"response-n6144.csv");rows=[];sources=[];derivs=[]
    probes=[(rad,h) for rad in (6.,8.3) for h in (1.5,-1.5)]
    points=np.array([[0.,0.,0.]]+[[-r,0.,h] for r,h in probes])
    for model in MODELS:
        stamps,radii,pack,traj=history(model);coef=pack[-1];center=traj[-1,1:4]
        saved={}
        for kind,deg,log in [("full",6,True),("monopole",0,True),("radius_Hermite",6,False)]:
            old=None
            for step in (.04,.02,.01):
                field=force(points,center,radii,coef,step,deg,log);delta=(field[1:]-field[0])*UNIT
                if old is not None:
                    change=np.linalg.norm(delta-old,axis=1)/np.linalg.norm(delta,axis=1)
                    derivs.append(dict(model=model,method=kind,step=step,maximum_vector_relative=change.max()))
                old=delta
            saved[kind]=delta
        mono_mass=10.*coef[25+int(np.argmin(abs(radii-10.))),0]*232500.
        assert np.min(abs(radii-10.))<1e-12
        v=traj[-1,4:];d=np.linalg.norm(center)
        sources.append(dict(model=model,start_gyr=stamps[0]*GYR,snapshot_count=len(stamps),r_gal_kpc=d,x=center[0],y=center[1],z=center[2],
            vx=v[0],vy=v[1],vz=v[2],speed=np.linalg.norm(v),radial=center@v/d,mass_inside_10kpc_msun=mono_mass,
            final_bound_mass_msun=np.loadtxt(HERE/"source"/model/"boundmass.txt")[-1,1]))
        for tag in TAGS:
            case="reference" if tag==TAGS[0] else "added-free2-plus"
            state=next(r for r in states if r["tag"]==tag and r["model"]==model and r["source"]=="full" and abs(float(r["start_native"])-stamps[0])<1e-12 and r["start"]=="zero")
            disp=complex(float(state["displacement_re"]),float(state["displacement_im"]))
            for idx,(radius,height) in enumerate(probes):
                length=np.hypot(height,radius);side="north" if height>0 else "south";sign=np.sign(height)
                axes=np.array([[-radius/length,0.,height/length],[-height/length,0.,-radius/length],[0.,-1.,0.]])
                direct=axes@saved["full"][idx];monopole=axes@saved["monopole"][idx];alt=axes@saved["radius_Hermite"][idx]
                add=2*(disp*resolved[tag][radius]).real*np.array([1.,sign,1.])
                for bg in ["mts","nfw"]:
                    orig=next(r for r in baseline if r["case"]==case and r["model"]==bg and float(r["R"])==radius and r["component"]=="azimuthal_mean")
                    for axis,coord,physical in [(0,"ar","radial"),(1,"atheta","polar"),(2,"aphi","azimuthal")]:
                        base=float(orig["total_"+physical])*(sign if axis==1 else 1.) if axis<2 else 0.
                        induced=add[axis] if bg=="mts" else 0.
                        subtotal=base+direct[axis]+induced;band=limits.get((radius,coord,side))
                        rows.append(dict(model=model,tag=tag,background=bg,R=radius,z=height,component=physical,base=base,
                            direct=direct[axis],direct_spherical_only=monopole[axis],direct_alternate_radial_interpolation=alt[axis],
                            induced_tracked_mode=induced,subtotal=subtotal,obs_low=band[3] if band is not None else "",
                            obs_high=band[4] if band is not None else "",inside=band[3]<=subtotal<=band[4] if band is not None else ""))
    table("present-sky.csv",rows);table("present-source.csv",sources);table("direct-gradient-controls.csv",derivs)
if __name__=="__main__":run()

