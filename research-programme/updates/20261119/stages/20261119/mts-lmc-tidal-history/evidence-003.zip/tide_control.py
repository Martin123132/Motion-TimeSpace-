from lmc_field import *
from lmc_io import read,table
from sky import force
from scipy.signal import find_peaks

def run():
    rows=[]
    for model in MODELS:
        stamps,knots,bank,traj=history(model)
        where=positions(traj,stamps);dist=np.linalg.norm(where,axis=1)
        visits=find_peaks(-dist)[0]
        nodes=sorted(set([0,len(stamps)-1,*map(int,visits)]))
        for idx in nodes:
            tests=[]
            for step in (.08,.04):
                axes=np.eye(3);points=np.vstack([step*axes,-step*axes])
                g=force(points,where[idx],knots,bank[idx],.012)
                hess=-(g[:3]-g[3:])/(2*step)
                tests.append((hess[0,0]-hess[1,1])-1j*(hess[0,1]+hess[1,0]))
            for tag in TAGS:
                kernel=read(OLD/(tag+"-external-response.csv"))[0];scalar=float(kernel["overlap_per_unit_planar_tidal_tensor"])
                with np.load(HERE/f"drives/{tag}-n6144-t32-l72-{model}.npz") as data:
                    ent=np.argmin(abs(data["time"]-stamps[idx]));assert abs(data["time"][ent]-stamps[idx])<1e-12
                    spatial=data["drive_by_l"][:,ent].sum()
                tide=tests[-1]*scalar
                rows.append(dict(model=model,tag=tag,time_native=stamps[idx],distance=dist[idx],spatial_re=spatial.real,spatial_im=spatial.imag,
                    tide_re=tide.real,tide_im=tide.imag,fractional_tidal_error=abs(tide-spatial)/abs(spatial),
                    hessian_refinement_over_spatial=abs(tests[1]-tests[0])*abs(scalar)/abs(spatial)))
    table("tidal-approximation.csv",rows)
if __name__=="__main__":run()

