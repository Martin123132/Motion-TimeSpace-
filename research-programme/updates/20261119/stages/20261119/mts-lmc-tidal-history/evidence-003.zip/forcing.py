from lmc_field import *
from lmc_io import save
from scipy.interpolate import CubicSpline
from scipy.fft import fht
from math import lgamma, exp, sqrt, pi, fsum
from functools import lru_cache
import io,sys

@lru_cache(None)
def logfac(num):return lgamma(num+1)

@lru_cache(None)
def wigner(aa,bb,cc,ma,mb,mc):
    if ma+mb+mc or abs(ma)>aa or abs(mb)>bb or abs(mc)>cc or not abs(aa-bb)<=cc<=aa+bb:return 0.
    pref=.5*(logfac(aa+bb-cc)+logfac(aa-bb+cc)+logfac(-aa+bb+cc)-logfac(aa+bb+cc+1)
             +sum(logfac(a+b)+logfac(a-b) for a,b in [(aa,ma),(bb,mb),(cc,mc)]))
    low=max(0,bb-cc-ma,aa+mb-cc)
    high=min(aa+bb-cc,aa-ma,bb+mb)
    return (-1)**(aa-bb-mc)*fsum((-1)**z*exp(pref-sum(logfac(i) for i in
        [z,aa+bb-cc-z,aa-ma-z,bb+mb-z,cc-bb+ma+z,cc-aa-mb+z])) for z in range(low,high+1))

def gaunt(left,degree,out,order):
    emm=order-2
    return (-1)**emm*sqrt((2*left+1)*(2*degree+1)*(2*out+1))*wigner(left,degree,out,0,0,0)*wigner(left,degree,out,-2,order,-emm)

def hankel(samples,coord,dual,step,order):
    return np.sqrt(pi/2)*fht(samples*coord**1.5,step,mu=order+.5)/dual**1.5

def host(tag,radius,kfreq,spacing,limit):
    with np.load(OLD/(tag+"-external-kernel.npz")) as packet,np.load(OLD/(tag+"-state.npz")) as state:
        nodes=packet["radius_kpc"];weights=packet["source_overlap_weights"];mu=packet["mu"];length=nodes[0]/state["rad"][0]
        dr=state["radial_weight"]*length
        lmax=int(state["orders_wave"].max()+state["orders_mean"].max())
        transforms={}
        for ell in range(2,min(lmax,limit)+1,2):
            values=(weights@harmonic(ell,2,mu,0).real)/(dr*nodes**2)
            spline=CubicSpline(nodes,values)
            active=(radius>=nodes[0])&(radius<=nodes[-1])
            real=np.zeros_like(radius);real[active]=spline(radius[active])
            inside=radius<nodes[0];real[inside]=values[0]*(radius[inside]/nodes[0])**ell
            transforms[ell]=hankel(real,radius,kfreq,spacing,ell)
        return transforms

class ReadTimes:
    def __init__(self,dist_grid,sub,skip=False):
        raw=[];times=[];pts=[];left=[];blend=[];self.sections={};spans=0;rows=0
        for model in MODELS:
            stamps,rr,coeff,traj=history(model);self.radii=rr
            tt=np.linspace(stamps[0],0,sub*(len(stamps)-1)+1)
            if skip:
                assert (len(stamps)-1)%2==0
                stamps=stamps[::2];coeff=coeff[::2]
            idx=np.clip(np.searchsorted(stamps,tt,side="right")-1,0,len(stamps)-2)
            left.append(idx+rows);blend.append((tt-stamps[idx])/(stamps[1]-stamps[0]))
            raw.append(coeff);times.append(tt);pts.append(positions(traj,tt))
            self.sections[model]=slice(spans,spans+len(tt));rows+=len(stamps);spans+=len(tt)
        self.raw=np.concatenate(raw);self.time=np.concatenate(times);pos=np.vstack(pts)
        dist=np.linalg.norm(pos,axis=1);self.mu=pos[:,2]/dist;self.phi=np.arctan2(pos[:,1],pos[:,0])
        self.dist=dist;idx=np.searchsorted(dist_grid,dist)-1
        assert idx.min()>0 and idx.max()+2<len(dist_grid)
        step=np.log(dist_grid[-1]/dist_grid[0])/(len(dist_grid)-1)
        frac=np.log(dist/dist_grid[idx])/step
        centers=idx[:,None]+np.arange(-1,3);weights=np.stack([-frac*(frac-1)*(frac-2)/6,(frac+1)*(frac-1)*(frac-2)/2,
            -(frac+1)*frac*(frac-2)/2,(frac+1)*frac*(frac-1)/6],axis=1)
        left=np.concatenate(left);blend=np.concatenate(blend)
        self.weights=np.concatenate([weights*(1-blend[:,None]),weights*blend[:,None]],axis=1)
        pairs=np.concatenate([left[:,None]*len(dist_grid)+centers,(left+1)[:,None]*len(dist_grid)+centers],axis=1)
        ids,self.inverse=np.unique(pairs.ravel(),return_inverse=True);self.inverse=self.inverse.reshape(pairs.shape)
        self.snapshot,self.dnode=np.divmod(ids,len(dist_grid))

def calculate(size,sub,limit,tag,variant=""):
    guard()
    assert variant in ("","radius","halfshapes")
    radius=np.geomspace(1.e-4,3.e4,size);freq=1/radius[::-1];step=np.log(radius[-1]/radius[0])/(size-1)
    sel=(radius>=40)&(radius<650);dgrid=radius[sel];times=ReadTimes(dgrid,sub,variant=="halfshapes")
    assert times.dist.max()+max(np.load(OLD/(tag+"-external-kernel.npz"))["radius_kpc"])<1000.
    transforms=host(tag,radius,freq,step,limit)
    taper=np.where(radius<=1000,1,np.where(radius>=2000,0,(1+np.cos(np.pi*(radius-1000)/1000))/2))
    total=np.zeros((7,len(times.time)),complex)
    for degree in range(7):
        guard()
        ids,frac=shape_weights(radius,times.radii,degree,variant!="radius")
        shape=np.zeros((50,size));np.add.at(shape,(ids.T,np.arange(size)),frac.T)
        satellite=hankel(shape*taper,radius,freq,step,degree)
        orders=range(-degree,degree+1)
        coeff={m:complex_coeff(times.raw,degree,m)[times.snapshot] for m in orders}
        for out in range(degree%2,max(transforms)+degree+1,2):
            tables={}
            for ell,htrans in transforms.items():
                if not abs(ell-degree)<=out<=ell+degree:continue
                part=(2/pi)*(-1)**((ell-degree-out)//2)*hankel(satellite*htrans,freq,radius,step,out)[:,sel]
                for m in orders:
                    factor=gaunt(ell,degree,out,m)
                    if not factor:continue
                    if m not in tables:tables[m]=factor*part
                    else:tables[m]+=factor*part
            for m,matrix in tables.items():
                contracted=np.einsum("ij,ij->i",coeff[m],matrix[:,times.dnode].T)
                projected=np.einsum("ij,ij->i",contracted[times.inverse],times.weights)
                total[degree]+=harmonic(out,m-2,times.mu,times.phi)*projected
    for model,section in times.sections.items():
        buf=io.BytesIO();np.savez_compressed(buf,time=times.time[section],distance=times.dist[section],drive_by_l=total[:,section])
        folder="drives" if not variant else "drives-"+variant
        save(f"{folder}/{tag}-n{size}-t{sub}-l{limit}-{model}.npz",buf.getvalue())
    print(tag,size,sub,limit,total[:,times.sections["L2M10"].stop-1].sum(),flush=True)

if __name__=="__main__":calculate(int(sys.argv[1]),int(sys.argv[2]),int(sys.argv[3]),TAGS[int(sys.argv[4])],*sys.argv[5:])

