from lmc_io import HERE, OLD, BAR, MODELS, guard
from functools import lru_cache
import re
import numpy as np
from scipy.interpolate import CubicHermiteSpline
from scipy.special import sph_harm_y

TAGS=("fine-reference-m2-n256","upper-added-free2-plus-m2-n256")
GYR=0.9777922216807892
UNIT=1e6/3.085677581491367e19/1e-10
SQ4=np.sqrt(4*np.pi)

def harmonic(degree,order,mu,phi):
    return SQ4*sph_harm_y(degree,order,np.arccos(np.clip(mu,-1,1)),phi)

def snapshot(path):
    groups=path.read_text().split("#dPhi/dr")
    assert len(groups)==2
    chunks=[np.loadtxt([line for line in part.splitlines() if line.strip() and line.lstrip()[0].isdigit()]) for part in groups]
    first,second=chunks
    assert first.shape==second.shape==(25,50) and np.array_equal(first[:,0],second[:,0])
    radii=first[:,0]
    assert np.all(np.diff(radii)>0)
    return radii,np.concatenate([first[:,1:],second[:,1:]*radii[:,None]])

@lru_cache(maxsize=6)
def history(model):
    root=HERE/"source"/model
    matches=re.findall(r"^\s*([-\d.]+)\s+(pot/lmc\d+\.ini)\s*$",(root/"potential.ini").read_text().split("[Potential LMC]")[1],re.M)
    times=np.array([float(t) for t,_ in matches])
    packets=[snapshot(root/file) for _,file in matches]
    radii=packets[0][0]
    assert all(np.array_equal(p[0],radii) for p in packets)
    traj=np.loadtxt(root/"trajlmc.txt")
    assert times[0]==traj[0,0] and times[-1]==traj[-1,0]==0 and np.allclose(np.diff(times),.0625)
    return times,radii,np.stack([p[1] for p in packets]),traj

def shape_weights(distance,radii,degree,logarithmic=True):
    flat=np.asarray(distance).reshape(-1)
    idx=np.clip(np.searchsorted(radii,flat)-1,0,len(radii)-2)
    base=radii[idx];end=radii[idx+1]
    if logarithmic:
        width=np.log(end/base);frac=np.log(np.maximum(flat,1e-100)/base)/width
        first=last=width
    else:
        width=end-base;frac=(flat-base)/width;first=width/base;last=width/end
    frac=np.clip(frac,0,1)
    weights=np.stack([(1+2*frac)*(1-frac)**2,frac**2*(3-2*frac),first*frac*(1-frac)**2,last*frac**2*(frac-1)],axis=1)
    indices=np.stack([idx,idx+1,idx+len(radii),idx+len(radii)+1],axis=1)
    inner=flat<radii[0]
    ratio=flat[inner]/radii[0];aux=(ratio*ratio-1)*.5
    weights[inner]=np.stack([ratio**degree*(1-degree*aux),ratio*0,ratio**degree*aux,ratio*0],axis=1)
    outer=flat>radii[-1];ratio=radii[-1]/flat[outer];aux=1-ratio
    weights[outer]=np.stack([ratio*0,ratio**(degree+1)*(1+(degree+1)*aux),ratio*0,ratio**(degree+1)*aux],axis=1)
    return indices,weights

def potential(xyz,radii,coeff,maximum=6,logarithmic=True):
    xyz=np.asarray(xyz);shape=xyz.shape[:-1];xyz=xyz.reshape(-1,3);distance=np.linalg.norm(xyz,axis=1)
    mu=np.divide(xyz[:,2],distance,out=np.zeros_like(distance),where=distance!=0)
    phi=np.arctan2(xyz[:,1],xyz[:,0])
    value=np.zeros(len(xyz))
    for degree in range(maximum+1):
        ids,ws=shape_weights(distance,radii,degree,logarithmic)
        center=degree*(degree+1)
        for order in range(degree+1):
            leg=harmonic(degree,order,mu,phi)
            radial=(coeff[ids,center+order]*ws).sum(axis=1)
            if order:
                neg=(coeff[ids,center-order]*ws).sum(axis=1)
                value+=np.sqrt(2)*(radial*leg.real+neg*leg.imag)
            else:value+=radial*leg.real
    return value.reshape(shape)

def complex_coeff(raw,degree,order):
    center=degree*(degree+1)
    if order==0:return raw[...,center]
    pos=(raw[...,center+abs(order)]-1j*raw[...,center-abs(order)])/np.sqrt(2)
    return pos if order>0 else (-1)**abs(order)*pos.conj()

def positions(traj,time):
    return CubicHermiteSpline(traj[:,0],traj[:,1:4],traj[:,4:7],axis=0,extrapolate=False)(time)

