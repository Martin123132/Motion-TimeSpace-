from lmc_io import *
import zlib
guard()
files=read(HERE/"source-files.csv");assert len(files)==len({r["path"] for r in files})==973
for row in files:
    path=HERE/row["path"];blob=path.read_bytes()
    assert len(blob)==int(row["bytes"]) and f"{zlib.crc32(blob):08x}"==row["zip_crc32"] and sha(path)==row["sha256"]
for row in read(HERE/"final-state-budget.csv"):assert float(row["grid_relative_phase_space"])<2e-5
for row in read(HERE/"ode-control-n6144.csv"):assert float(row["Duhamel_vs_DOP853"])<2e-5
coords=read(HERE/"coordinate-intersections.csv")
assert len([r for r in coords if r["scope"]=="all" and r["compatible_at_any_amplitude"]=="False"])==12
assert len(read(HERE/"present-sky.csv"))==288
for row in read(HERE/"constant-tide-obstruction.csv"):assert row["single_tidal_tensor_not_excluded"]=="False"
controls=list(HERE.glob("spatial-*-q20-32.csv"));assert len(controls)==4
for path in controls:
    row=next(r for r in read(path) if "n6144" in r["packet"] and r["L"]=="-1")
    assert max(float(row[k]) for k in ("independent_refinement_over_total","fft_difference_over_total"))<2e-5
manifest={p.relative_to(HERE).as_posix():sha(p) for p in sorted(HERE.rglob("*")) if p.is_file() and p.name!="seal.json"}
if sys.argv[1:]==["seal"]:metadata("seal.json",dict(parent=PIN,files=manifest))
assert json.loads((HERE/"seal.json").read_bytes())==dict(parent=PIN,files=manifest)
print(len(manifest),sha(HERE/"seal.json"))

