import os,sys,csv,io,json,hashlib
from pathlib import Path
for name in ("OPENBLAS_NUM_THREADS","MKL_NUM_THREADS","OMP_NUM_THREADS","BLIS_NUM_THREADS","NUMEXPR_NUM_THREADS"):os.environ[name]="1"
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
OLD=HERE.parent/"mts-finite-bar-mean-response-20261119"
BAR=HERE.parent/"mts-rotating-bar-wave-drive-20261119"
PIN="aad73be1a2c7615671e1e1b9689648454c06dcf23cdb28bb8b56751d10d49b5d"
MODELS=("L2M10","L2M10first","L2M11","L3M10","L3M10rad","L3M11")
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
def guard():
    assert sha(OLD/"seal.json")==PIN
    assert not any((folder/"STOP-REQUESTED").exists() for folder in (HERE,OLD,HERE.parent,BAR))
def save(name,raw):
    path=HERE/name
    if path.exists():assert path.read_bytes()==raw,name
    else:
        path.parent.mkdir(exist_ok=True,parents=True)
        with path.open("xb") as dest:dest.write(raw)
def table(name,rows):
    buf=io.StringIO(newline="");out=csv.DictWriter(buf,list(rows[0]),lineterminator="\n");out.writeheader();out.writerows(rows);save(name,buf.getvalue().encode())
def read(path):
    with path.open(encoding="utf8",newline="") as source:return list(csv.DictReader(source))
def metadata(name,data):save(name,(json.dumps(data,indent=2,sort_keys=True)+"\n").encode())

