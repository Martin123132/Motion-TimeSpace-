from lmc_field import *
from lmc_io import read,table
from retarded_lmc import probe_coefficients
from sky import force
import itertools

def run():
    guard();sky=read(HERE/"present-sky.csv");resp=read(HERE/"response-n6144.csv");details=[];joint=[];parity=[];distance_rows=[]
    for model in MODELS:
        t,rr,cc,traj=history(model);actual=traj[-1,1:4]
        target=np.array([-.6,-41.,-26.8]);sun=np.array([-8.12,0.,.02]);line=(target-sun)/np.linalg.norm(target-sun)
        p=np.array([[0,0,0],[-6,0,1.5],[-6,0,-1.5],[-8.3,0,1.5],[-8.3,0,-1.5]])
        poles=np.column_stack([-p[1:,2],np.zeros(4),p[1:,0]])/np.linalg.norm(p[1:],axis=1)[:,None]
        for name,pos in [("archive",actual),("target",target),("distance_minus",target-np.hypot(.09,.54)*line),
                         ("distance_plus",target+np.hypot(.09,.54)*line)]:
            field=force(p,pos,rr,cc[-1],.01)
            polar=((field[1:]-field[0])*poles).sum(axis=1)*UNIT
            distance_rows.append(dict(model=model,placement=name,inner_n=polar[0],inner_s=polar[1],outer_n=polar[2],outer_s=polar[3],
                position_miss_kpc=np.linalg.norm(actual-target),velocity_miss_kms=np.linalg.norm(traj[-1,4:]-[-69.9,-221.7,214.2])))
    for tag in TAGS:
        effects=probe_coefficients(tag)
        with np.load(OLD/(tag+"-external-kernel.npz")) as packet,np.load(OLD/(tag+"-state.npz")) as state:
            uweight=np.sum(packet["mode_vector"]**2)/(2*np.sum(state["ground"]**2));sigma=float(packet["sigma"])
        for model in MODELS:
            actual=next(r for r in resp if r["model"]==model and r["tag"]==tag and r["source"]=="full" and r["start"]=="zero")
            disp=complex(float(actual["displacement_re"]),float(actual["displacement_im"]));act=float(actual["action"])
            current=[r for r in sky if r["tag"]==tag and r["background"]=="mts" and r["model"]==model and r["component"]!="azimuthal"]
            constraints=[]
            for (rad,coord),group in itertools.groupby(sorted(current,key=lambda r:(float(r["R"]),r["component"])),lambda r:(float(r["R"]),r["component"])):
                sides={float(r["z"]):r for r in group};north=sides[1.5];south=sides[-1.5];factor=-1 if coord=="polar" else 1
                low,high=(float(south["obs_low"]),float(south["obs_high"]))
                if factor<0:low,high=-high,-low
                lo=(float(north["obs_low"])+low)/2;hi=(float(north["obs_high"])+high)/2
                pred=(float(north["subtotal"])+factor*float(south["subtotal"]))/2
                missing=lo-pred if pred<lo else (hi-pred if pred>hi else 0.)
                parity.append(dict(tag=tag,model=model,R=rad,component=coord,predicted_even_potential_sector=pred,
                    necessary_lo=lo,necessary_hi=hi,minimum_signed_additional_even_force=missing,
                    minimum_signed_dPhi_du_kms2=missing*np.hypot(rad,1.5)**2/rad/UNIT if coord=="polar" else ""))
                for height,row in sides.items():
                    coeff=2*effects[rad][0 if coord=="radial" else 1].real*(np.sign(height) if coord=="polar" else 1)
                    base=float(row["base"])+float(row["direct"]);bounds=sorted([(float(row[k])-base)/coeff for k in ("obs_low","obs_high")])
                    name=f"{rad}:{height}:{coord}"
                    assert abs(float(row["subtotal"])-base-coeff*disp.real)<1e-12
                    constraints.append((name,*bounds))
                    details.append(dict(tag=tag,model=model,site=name,unit_real_displacement_force=coeff,min_real_coordinate=bounds[0],
                        max_real_coordinate=bounds[1],driven_real_coordinate=disp.real,driven_within=bounds[0]<=disp.real<=bounds[1]))
            for scope,subset in [("all",constraints),("polar",[v for v in constraints if v[0].endswith("polar")]),
                    ("inner_polar",[v for v in constraints if v[0].startswith("6.0") and v[0].endswith("polar")]),
                    ("radial",[v for v in constraints if v[0].endswith("radial")])]:
                lower=max(subset,key=lambda v:v[1]);upper=min(subset,key=lambda v:v[2]);ok=lower[1]<=upper[2]
                floor=max(0.,lower[1],-upper[2]) if ok else None
                joint.append(dict(tag=tag,model=model,scope=scope,active_lower=lower[0],lower=lower[1],active_upper=upper[0],upper=upper[2],
                    compatible_at_any_amplitude=ok,driven_re=disp.real,driven_abs=abs(disp),
                    required_abs_at_least=floor if ok else "",lower_bound_sideband_norm_fraction=uweight*floor**2 if ok else "",
                    minimum_action_over_forced=sigma*floor**2/(2*act) if ok else ""))
    table("coordinate-constraints.csv",details);table("coordinate-intersections.csv",joint)
    table("required-even-field.csv",parity);table("distance-placement-sensitivity.csv",distance_rows)
if __name__=="__main__":run()

