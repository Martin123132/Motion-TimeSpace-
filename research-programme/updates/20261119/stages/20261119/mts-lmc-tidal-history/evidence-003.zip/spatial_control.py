from lmc_field import *
from lmc_io import table
from scipy.special import roots_legendre,lpmv,gammaln
import sys

def leg(ell,order,mu):
    mag=abs(order)
    value=np.sqrt(2*ell+1)*np.exp(.5*(gammaln(ell-mag+1)-gammaln(ell+mag+1)))*lpmv(mag,ell,mu)
    return value if order>=0 else (-1)**mag*value

def rotated(ell,orig,keep,axis):
    az=np.arange(2*ell+5)*2*np.pi/(2*ell+5)
    u=np.linspace(-.97,.97,37);s=np.sqrt(1-u*u)
    frame=np.stack(np.broadcast_arrays(s[:,None]*np.cos(az),s[:,None]*np.sin(az),u[:,None]),axis=-1)
    xyz=frame@axis.T
    roll=harmonic(ell,orig,xyz[...,2],np.arctan2(xyz[...,1],xyz[...,0]))
    vals=np.fft.fft(roll,axis=1)/len(az)
    out=[]
    for order in keep:
        base=leg(ell,order,u);idx=np.argmax(abs(base))
        out.append(vals[idx,order%len(az)]/base[idx])
    return np.array(out)

def direct(tag,model,snapshot_idx,nquad):
    stamps,knots,coeff,traj=history(model);coeff=coeff[snapshot_idx]
    displacement=positions(traj,stamps[snapshot_idx]);dist=np.linalg.norm(displacement);axis=displacement/dist
    side=np.cross([0.,0.,1.],axis);side/=np.linalg.norm(side)
    orient=np.column_stack([side,np.cross(axis,side),axis])
    with np.load(OLD/(tag+"-external-kernel.npz")) as packet,np.load(OLD/(tag+"-state.npz")) as state:
        radius=packet["radius_kpc"];mu=packet["mu"];weights=packet["source_overlap_weights"]
        maxhost=int(state["orders_wave"].max()+state["orders_mean"].max())
    gx,gw=roots_legendre(nquad);rr=[];ss=[];ww=[]
    for idx,rad in enumerate(radius):
        lo=abs(rad-dist);hi=rad+dist;edge=np.r_[lo,knots[(knots>lo)&(knots<hi)],hi]
        half=np.diff(edge)/2;sp=(edge[:-1]+half)[:,None]+half[:,None]*gx
        ss.extend(sp.ravel());rr.extend(np.repeat(idx,sp.size))
        ww.extend((half[:,None]*gw*sp/(2*rad*dist)).ravel())
    ss=np.array(ss);rr=np.array(rr);ww=np.array(ww);rad=radius[rr]
    u=np.clip((rad**2+dist**2-ss**2)/(2*rad*dist),-1.,1.);v=np.clip((rad*u-dist)/ss,-1.,1.)
    hk=np.zeros((13,len(ss)),complex)
    for ell in range(2,maxhost+1,2):
        orders=range(-min(ell,6),min(ell,6)+1);rotation=rotated(ell,-2,orders,orient)
        coeff_r=(weights@leg(ell,2,mu))[rr]
        for order,factor in zip(orders,rotation):hk[6-order]+=coeff_r*factor*leg(ell,order,u)
    values=[]
    for degree in range(7):
        orders=range(-degree,degree+1)
        rot=np.array([rotated(degree,m,orders,orient) for m in orders])
        src=np.stack([complex_coeff(coeff,degree,m) for m in orders],axis=-1)@rot
        indices,base=shape_weights(ss,knots,degree)
        total=0j
        for order in orders:
            profile=(src[indices,order+degree]*base).sum(axis=1)
            total+=np.sum(hk[order+6]*ww*profile*leg(degree,order,v))
        values.append(total)
    return np.array(values)

def main(tag,model,idx,coarse=6,fine=10):
    times=history(model)[0];time=times[idx];series=direct(tag,model,idx,coarse);refined=direct(tag,model,idx,fine)
    rows=[]
    for size in [1536,3072,6144]:
        for path in sorted((HERE/"drives").glob(f"{tag}-n{size}-*-{model}.npz")):
            with np.load(path) as data:
                tidx=np.argmin(abs(data["time"]-time));assert abs(data["time"][tidx]-time)<1e-12
                pred=data["drive_by_l"][:,tidx]
            for deg in range(-1,7):
                old,truth,fft=[x.sum() if deg==-1 else x[deg] for x in (series,refined,pred)]
                rows.append(dict(packet=path.name,model=model,time=time,L=deg,independent_real=truth.real,independent_imag=truth.imag,
                    independent_refinement_over_total=abs(truth-old)/abs(refined.sum()),fft_difference_over_total=abs(fft-truth)/abs(refined.sum())))
    assert rows
    fname=f"spatial-{tag}-{model}-snap{idx}-n{size if any('n6144' in r['packet'] for r in rows) else 3072}.csv"
    if (coarse,fine)!=(6,10):fname=fname.replace(".csv",f"-q{coarse}-{fine}.csv")
    table(fname,rows);print([(r["packet"],r["fft_difference_over_total"],r["independent_refinement_over_total"]) for r in rows if r["L"]==-1])
if __name__=="__main__":main(TAGS[int(sys.argv[1])],sys.argv[2],*map(int,sys.argv[3:]))

