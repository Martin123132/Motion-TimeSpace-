from lmc_field import *
from lmc_io import read,table

def run():
    guard();items=read(HERE/"present-sky.csv");out=[]
    for tag in TAGS:
        for bg in ("mts","nfw"):
            for model in MODELS:
                for trial in ("foreground_only","with_LMC"):
                    intervals=[];forces=[]
                    for rad in (6.,8.3):
                        site={float(r["z"]):r for r in items if r["model"]==model and r["background"]==bg and r["tag"]==tag and
                              float(r["R"])==rad and r["component"]=="polar"}
                        north,south=site[1.5],site[-1.5]
                        lo=(float(north["obs_low"])-float(south["obs_high"]))/2
                        hi=(float(north["obs_high"])-float(south["obs_low"]))/2
                        label="base" if trial=="foreground_only" else "subtotal"
                        current=(float(north[label])-float(south[label]))/2
                        fac=np.hypot(rad,1.5)/(rad*1.5*UNIT)
                        intervals.append(((lo-current)*fac,(hi-current)*fac))
                        forces.append(current)
                    low=max(a for a,b in intervals);high=min(b for a,b in intervals)
                    out.append(dict(tag=tag,background=bg,model=model,trial=trial,inner_min=intervals[0][0],inner_max=intervals[0][1],
                        outer_min=intervals[1][0],outer_max=intervals[1][1],single_tidal_tensor_not_excluded=low<=high,
                        minimum_change_kms2_per_kpc2=max(0.,low-high),derivative_floor_kms2_per_kpc3=max(0.,low-high)/(8.3-6.)))
    table("constant-tide-obstruction.csv",out)
if __name__=="__main__":run()

