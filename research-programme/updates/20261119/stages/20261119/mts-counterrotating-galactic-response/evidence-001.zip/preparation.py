from pair import Experiment,HOME,rows,np,sys,Julian_year,parsec
from scipy.special import eval_legendre


def evaluate(mesh,count,channels):
    exp=Experiment(mesh,count,channels);system=exp.system
    with np.load(HOME/(exp.tag+"-frozen.npz")) as bank:
        excited=bank["excited"]
    with (HOME/(exp.tag+"-mode.csv")).open(newline="") as handle:
        from csv import DictReader
        values=next(DictReader(handle))
    timeunit=system.length*1000*parsec/(system.vel*1000)/(Julian_year*1e6)
    gap=float(values["energy"])-float(values["ground_energy"])
    mu=system.mu;sin=np.sqrt(1-mu**2);az=np.arange(64)*2*np.pi/64
    gw=exp.lin.wave/np.sqrt(exp.mass)
    ew=(np.einsum("lrk,lk->rl",exp.sector.radial,excited,optimize=True)@exp.sector.angle.T)/np.sqrt(exp.mass)
    twosided=gw*ew
    rad=system.rad
    result=[]
    for degree in (1,2,3):
        direct=np.mean(eval_legendre(degree,sin[:,None]*np.cos(az))*np.cos(az),axis=1)
        analytic=sin/2 if degree==1 else np.zeros_like(sin) if degree==2 else 15*sin**3/16-3*sin/4
        assert np.max(abs(direct-analytic))<4e-15
        signed=system.weights*rad**degree*(twosided@(system.aw*analytic))
        moment=sum(signed)
        raw=system.weights*rad**degree*np.sum(abs(twosided*(system.aw*analytic)),axis=1)
        if sum(raw)>0:
            radii=[rad[min(len(rad)-1,np.searchsorted(np.cumsum(raw)/sum(raw),target))]*system.length for target in (.95,.99)]
        else:radii=["",""]
        spherical_test=system.aw@(np.sqrt(1.5)*sin*analytic)
        if degree>=2:assert abs(spherical_test)<5e-14
        result.append(dict(degree=degree,overlap=moment,physical_moment_kpc_power=moment*system.length**degree,
                           absolute_integral=sum(raw),abs_radial_support95_kpc=radii[0],abs_radial_support99_kpc=radii[1],
                           spherical_angular_test=spherical_test,gap=gap,velocity_kms=system.vel,length_kpc=system.length,
                           timeunit_Myr=timeunit,frozen_potential_Bohr_rate_per_Gyr=gap/timeunit*1000,frozen_phase_period_Myr=2*np.pi*timeunit/gap,
                           energy_cost_per_transferred_mass_kms2=gap*system.vel**2))
    assert result[0]["overlap"]!=0 and result[1]["overlap"]==0 and result[2]["overlap"]!=0
    rows(exp.tag+"-preparation-kernel.csv",result)
    print(exp.tag,"octupole",result[-1],flush=True)


if __name__=="__main__":evaluate(sys.argv[1],int(sys.argv[2]),int(sys.argv[3]))
