from pair import Experiment,HOME,rows,np,sys,eval_legendre,basis
from scipy.integrate import quad
from scipy.special import spherical_jn
from math import sqrt


def check():
    exp=Experiment("medium",64,7);sysm=exp.system
    cond=[]
    for source,sector in (("ground",sysm),("excited",exp.sector)):
        state=np.zeros_like(sector.kin);state[0,0]=1.
        deg=int(sector.orders[0]);root=float(sector.roots[0][0])
        cutoff=sysm.edge
        normal=1/np.sqrt(.5*cutoff**3*spherical_jn(deg+1,root)**2)
        def density(rad):return (normal*spherical_jn(deg,root*rad/cutoff))**2
        reference=exp.readout.field(source,state)
        for idx in (exp.run.anchor,-4,-3,-1):
            xyz=exp.run.loc[idx]/sysm.length
            dist=np.linalg.norm(xyz);unit=xyz/dist;height=unit[2]
            polar=np.array([0.,0.,1.])-height*unit
            force=np.zeros(3)
            for order,amplitude in ([(0,1.)] if not deg else [(0,1.),(2,-1.)]):
                inside=quad(lambda rad:rad**2*density(rad)*(rad/dist)**order/dist,0,dist,epsabs=1e-14)[0]
                outside=quad(lambda rad:rad*density(rad)*(dist/rad)**order,dist,cutoff,epsabs=1e-14)[0]
                derivative=((order+1)*inside-order*outside)*amplitude/((2*order+1)*dist)
                pot=-(inside+outside)*amplitude/(2*order+1)
                force-=unit*eval_legendre(order,height)*derivative+polar*(3*height if order==2 else 0.)*pot/dist
            expected=force*sysm.vel**2/sysm.length
            err=np.linalg.norm(expected-reference[idx])/np.linalg.norm(expected)
            assert err<1e-9
            cond.append(dict(source=source,index=idx,error=err))
    rows("analytic-angular-control.csv",cond)


if __name__=="__main__":check()
