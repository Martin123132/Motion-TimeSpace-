from continue_pair import Mixture
from pair import Experiment,HOME,np,rows,StellarPotential,branch,basis,root_values,sys
from disk_state import PARENT as SOURCE


def exchange():
    exp=Experiment("alternate",256,16);system=exp.system
    exp.actualvir=exp.run.work+StellarPotential("mass-spherical-fine").mesh(exp.run.rad,system.mu)[1]/system.vel**2
    with np.load(branch.HERE/"main.npz") as old:
        edge=float(old["edge"])
    with np.load(SOURCE/"angular28-diff.npz") as old:
        orig_length=float(old["length_pc"])/1000
        orig_vel=float(old["velocity_unit_kms"])
    with np.load(HOME/"fine-384-16-fixed-1.npz") as old:orig_mass=float(old["mass"])
    assert abs(orig_length*orig_vel/(system.length*system.vel)-1)<1e-10
    org_r=system.rad*system.length/orig_length
    assert max(org_r)<edge
    def project(sec,state):
        result=[]
        for order,radial,coeff in zip(sec.orders,sec.radial,state):
            old_basis=basis(order,root_values(order,len(coeff)),edge,org_r)
            result.append(radial.T@(system.weights*system.rad*(old_basis@coeff)))
        return np.array(result)
    records=[]
    for kind in ("fixed","matched"):
        for index in (4,8):
            with np.load(HOME/(f"fine-384-16-{kind}-{index}.npz")) as old:
                ground=project(system,old["ground"]);excited=project(exp.sector,old["excited"])
                mass=exp.mass*float(old["mass"])/orig_mass
            for turn in range(8):
                model=Mixture(exp,index/8,mass,ground,excited);model.polish()
                field=model.force();error=field[exp.run.anchor,0]-exp.saved[exp.run.anchor,0]
                if kind=="fixed" or abs(error)<3e-12*abs(exp.saved[exp.run.anchor,0]):break
                slope=model.derivative("mass");dlog=-error/model.force(slope)[exp.run.anchor,0]
                mass*=np.exp(dlog);new=[v+b*dlog for v,b in zip(model.states,slope)]
                excited=new[-1];ground=new[0] if index<8 else ground
            else:raise RuntimeError("cross-domain calibration")
            energy,virial=model.energy()
            records.append(dict(branch=kind,fraction=index/8,original_edge_kpc=edge*orig_length,alternate_edge_kpc=system.edge*system.length,
                                mass_ratio=mass/exp.mass,scaled_residual=model.relative,virial=virial,**exp.metrics(field)))
    rows("alternate-domain.csv",records)
    print("second physical radial domain",records[-1],flush=True)


if __name__=="__main__":exchange()
