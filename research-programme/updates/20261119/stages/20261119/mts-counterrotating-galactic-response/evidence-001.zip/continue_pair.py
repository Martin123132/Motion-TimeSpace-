from pair import Experiment,np,protected,packet,rows,HOME,UNIT,LinearOperator,sys,TOL,StellarPotential
from scipy.sparse.linalg import cg


class Mixture:
    def __init__(self,exp,fraction,mass,ground,excited):
        self.exp=exp;self.fraction=fraction;self.mass=mass
        self.labels=["ground","excited"] if fraction<1 else ["excited"]
        self.sectors=[exp.system if key=="ground" else exp.sector for key in self.labels]
        self.norms=[mass*(1-fraction) if key=="ground" else mass*fraction for key in self.labels]
        self.states=self.normalize([ground if key=="ground" else excited for key in self.labels])
        self.pre=[np.sqrt(.4+sector.kin) for sector in self.sectors]
        self.offsets=np.cumsum([0]+[sector.kin.size for sector in self.sectors])

    def normalize(self,states):
        return [state*np.sqrt(norm)/np.linalg.norm(state) for state,norm in zip(states,self.norms)]
    def unpack(self,flat):
        return [flat[self.offsets[index]:self.offsets[index+1]].reshape(sector.kin.shape)
                for index,sector in enumerate(self.sectors)]
    def flatten(self,blocks):
        return np.concatenate([block.ravel() for block in blocks])
    def wave(self,sector,state):
        return np.einsum("lrk,lk->rl",sector.radial,state,optimize=True)@sector.angle.T
    def read(self,sector,values):
        system=self.exp.system
        return np.einsum("lrk,rl->lk",sector.radial,system.weights[:,None]*(values@(system.aw[:,None]*sector.angle)),optimize=True)
    def fields(self):
        exp=self.exp;system=exp.system
        self.waves=[self.wave(sector,state) for sector,state in zip(self.sectors,self.states)]
        self.density=sum(wave**2 for wave in self.waves)
        self.phi=exp.lin.poisson(self.density)
        self.total=exp.ext+self.phi
        ham=[sector.kin*state+self.read(sector,self.total*wave) for sector,state,wave in zip(self.sectors,self.states,self.waves)]
        self.chemical=[np.sum(vector*state)/norm for vector,state,norm in zip(ham,self.states,self.norms)]
        self.residual=[vector-energy*state for vector,energy,state in zip(ham,self.chemical,self.states)]
        self.relative=max(np.linalg.norm(block)/(abs(energy)*np.sqrt(norm)) for block,energy,norm in zip(self.residual,self.chemical,self.norms))
        self.normal=[state/pre/np.linalg.norm(state/pre) for state,pre in zip(self.states,self.pre)]
    def response(self,blocks):
        change=[self.wave(sector,block) for sector,block in zip(self.sectors,blocks)]
        dphi=self.exp.lin.poisson(2*sum(wave*delta for wave,delta in zip(self.waves,change)))
        return [(sector.kin-energy)*block+self.read(sector,self.total*delta+wave*dphi)
                for sector,energy,block,delta,wave in zip(self.sectors,self.chemical,blocks,change,self.waves)]
    def project(self,blocks):
        return [block-normal*np.sum(block*normal) for block,normal in zip(blocks,self.normal)]
    def inverse(self,right):
        def multiply(flat):
            blocks=self.unpack(flat);orth=self.project(blocks)
            action=self.response([block/pre for block,pre in zip(orth,self.pre)])
            tangent=self.project([block/pre for block,pre in zip(action,self.pre)])
            return self.flatten([block+normal*np.sum(normal*src) for block,normal,src in zip(tangent,self.normal,blocks)])
        target=self.flatten(self.project([block/pre for block,pre in zip(right,self.pre)]))
        result,info=cg(LinearOperator((target.size,target.size),matvec=multiply,dtype=float),target,rtol=3e-11,atol=1e-19,maxiter=250)
        assert info==0,("projected inverse",info)
        return [block/pre for block,pre in zip(self.project(self.unpack(result)),self.pre)]
    def polish(self):
        self.fields()
        for iteration in range(15):
            if self.relative<4e-13:break
            update=self.inverse([-block for block in self.residual])
            start=self.states;before=self.relative
            for factor in (1.,.5,.25,.125,.0625,.03125):
                self.states=self.normalize([state+factor*delta for state,delta in zip(start,update)])
                self.fields()
                if self.relative<before:break
            else:raise RuntimeError(("Newton direction",before,self.relative))
        else:raise RuntimeError(("coupled Newton",self.relative))
    def derivative(self,kind):
        if kind=="fraction":
            assert self.fraction!=1
            scales=[-.5/(1-self.fraction),.5/self.fraction]
        else:scales=[.5]*len(self.states)
        seed=[state*scale for state,scale in zip(self.states,scales)]
        correction=self.inverse([-block for block in self.response(seed)])
        return [block+delta for block,delta in zip(seed,correction)]
    def force(self,delta=None):
        if delta is None:
            return sum(self.exp.readout.field(key,state) for key,state in zip(self.labels,self.states))
        return sum(self.exp.readout.field(key,state,block) for key,state,block in zip(self.labels,self.states,delta))
    def energy(self):
        system=self.exp.system
        weights=system.weights[:,None]*system.aw
        kinetic=sum(np.sum(sector.kin*state**2) for sector,state in zip(self.sectors,self.states))
        selfenergy=np.sum(weights*self.density*self.phi)/2
        total=kinetic+selfenergy+np.sum(weights*self.density*self.exp.ext)
        virial=(2*kinetic+selfenergy-np.sum(weights*self.density*self.exp.actualvir))/(2*kinetic)
        return total,virial


def run(mesh,count,channels,kind,first,last):
    protected();exp=Experiment(mesh,count,channels)
    run=exp.run;system=exp.system;prefix=exp.tag+"-"+kind
    level="medium" if mesh=="medium" else "fine"
    exp.actualvir=run.work+StellarPotential("mass-spherical-"+level).mesh(run.rad,system.mu)[1]/system.vel**2
    anchor=run.anchor
    with np.load(HOME/(exp.tag+"-frozen.npz")) as pre:
        initial_exc=pre["excited"];dmass=pre["dmass"];du=pre["delta"];rate=float(pre["rate"]) if kind=="matched" else 0.
    for index in range(first,last+1):
        protected();fraction=index/8
        if index==1:
            mass=exp.mass*np.exp(fraction*rate)
            excited=initial_exc*np.sqrt(fraction*mass/exp.mass)
            ground=exp.state+fraction*(du+rate*dmass)
        else:
            with np.load(HOME/(prefix+f"-{index-1}.npz")) as previous:
                mass=float(previous["mass"])
                ground=previous["ground"];excited=previous["excited"]
                assert float(previous["fraction"])==(index-1)/8
        for outer in range(14):
            model=Mixture(exp,fraction,mass,ground,excited);model.polish()
            field=model.force();diff=field[anchor,0]-exp.saved[anchor,0]
            if kind=="fixed" or abs(diff)<3e-12*abs(exp.saved[anchor,0]):break
            slope=model.derivative("mass");force_rate=model.force(slope)[anchor,0]
            assert force_rate>0,("outer fold",fraction,mass,force_rate)
            logstep=np.clip(-diff/force_rate,-.15,.15);mass*=np.exp(logstep)
            seed=[state+delta*logstep for state,delta in zip(model.states,slope)]
            ground=seed[0] if fraction<1 else exp.state;excited=seed[-1]
        else:raise RuntimeError(("outer solve",fraction,diff))
        assert max(abs(np.sum(state**2)/norm-1) for state,norm in zip(model.states,model.norms))<3e-12
        ground=model.states[0] if fraction<1 else np.zeros_like(exp.state)
        excited=model.states[-1]
        total,virial=model.energy()
        mode_slope=model.derivative("mass")
        outer_slope=model.force(mode_slope)[anchor,0]
        results=dict(fraction=fraction,mass=mass,mass_ratio=mass/exp.mass,
                     zero_energy_per_N=exp.lin.energy/exp.mass,energy_per_original_N=total/exp.mass,
                     velocity_unit_kms=system.vel,excited_mu=model.chemical[-1],
                     ground_mu=model.chemical[0] if fraction<1 else "",virial=virial,
                     scaled_residual=model.relative,outer_sensitivity=outer_slope,
                     **exp.metrics(field))
        rates=[]
        if fraction<1:
            df=model.derivative("fraction");df_field=model.force(df)
            eta=-df_field[anchor,0]/outer_slope if kind=="matched" else 0.
            eta_field=df_field+eta*model.force(mode_slope)
            metrics=exp.metrics(field,eta_field)
            weights=system.weights[:,None]*system.aw
            tangent=[a+eta*b for a,b in zip(df,mode_slope)]
            changes=[model.wave(sec,block) for sec,block in zip(model.sectors,tangent)]
            direct=(2*sum(np.sum(sec.kin*state*block) for sec,state,block in zip(model.sectors,model.states,tangent))
                    +np.sum(weights*model.total*(2*sum(wave*delta for wave,delta in zip(model.waves,changes)))))/exp.mass
            energetic=mass/exp.mass*(model.chemical[1]-model.chemical[0]+eta*((1-fraction)*model.chemical[0]+fraction*model.chemical[1]))
            assert abs(direct-energetic)<1e-9
            rates=[dict(fraction=fraction,dlogmass=eta,energy_rate=energetic,direct_energy_rate=direct,**metrics)]
        if index==8:
            mode,_,energies,residual=exp.sector.eig(model.total,mass)
            overlap=abs(np.sum(mode*excited))/mass
            assert 1-overlap<1e-9 and abs(energies[0]-model.chemical[-1])<1e-9
            results.update(lowest_overlap=overlap,independent_residual=residual)
        packet(prefix+f"-{index}.npz",fraction=fraction,mass=mass,ground=ground,excited=excited,force=field)
        rows(prefix+f"-{index}.csv",[results])
        if rates:rows(prefix+f"-{index}-rates.csv",rates)
        print(prefix,fraction,results["polar_6"],results["radial_6"],results["quasar"],results["energy_per_original_N"],flush=True)


if __name__=="__main__":
    mesh,count,channels,kind,first,last=sys.argv[1:]
    assert kind in ("fixed","matched") and 1<=int(first)<=int(last)<=8
    run(mesh,int(count),int(channels),kind,int(first),int(last))
