from pair import HOME,PARENT,np,json,sha,protected,rows,put,TOL,sys,csv
from feasibility import bands
from inputs import guard


def read(path):
    with path.open(newline="",encoding="utf8") as handle:return list(csv.DictReader(handle))


def audit(seal):
    protected();guard(True)
    for name,digest in json.loads((PARENT/"seal.json").read_bytes())["files"].items():assert sha(PARENT/name)==digest
    def local(name):return read(HOME/name)
    high="fine-384-16";mid="medium-256-12"
    metrics=("polar_6","radial_6","polar_8.3","radial_8.3","outer_speed","slope","quasar","cep11","giant38")
    ref="mass-spherical-fine-main-384-32"
    orig=read(PARENT/(ref+"-results.csv"));sky=read(PARENT/(ref+"-sky.csv"))
    obs=bands();forecasts=[];validation=[]
    def compare(label,values,reference,names):
        for name in names:
            val=float(values[name]);target=float(reference[name])
            validation.append(dict(test=label,metric=name,delta=val-target,scaled=abs(val-target)/max(1.,abs(target))))
    for tag in ("medium-64-7","fine-168-14"):
        checks=local(tag+"-derivative-check.csv");assert len(checks)==18 and max(float(row["scaled_error"]) for row in checks)<TOL
        vals=local(tag+"-finite.csv");assert len(vals)==54
        for row in vals:
            assert float(row["mode_iteration_change"])<4e-13 and row["branch"] in ("fixed","matched")
            if row["branch"]=="matched" and row["observable"]=="outer_speed":assert abs(float(row["finite"])-224.03)<1e-8
    fine={(row["branch"],row["observable"]):row for row in local(high+"-frozen.csv")}
    for tag in (mid,"fine-256-16"):
        for row in local(tag+"-frozen.csv"):
            compare(tag+":"+row["branch"]+":"+row["observable"],row,fine[row["branch"],row["observable"]],["response"])
    assert len(local("analytic-angular-control.csv"))==8 and max(float(r["error"]) for r in local("analytic-angular-control.csv"))<1e-9
    base={}
    for model in ("nfw","mts"):
        record=next(row for row in orig if row["mode"]=="matched" and row["model"]==model)
        base[model]={key:float(record["outer" if key=="outer_speed" else key]) for key in metrics[4:]}
        for rr in (6.,8.3):
            for src,key in (("atheta","polar"),("ar","radial")):
                match=next(r for r in sky if r["mode"]=="matched" and r["model"]==model and float(r["R"])==rr and r["side"]=="north" and r["component"]==src)
                base[model][key+"_"+format(rr,"g")]=float(match["predicted"])
    def register(model,kind,fraction,values):
        counts=[]
        for name,index in (("polar","atheta"),("radial","ar")):
            flags=[]
            for rr in (6.,8.3):
                for side in ("north","south"):
                    value=float(values[name+"_"+format(rr,"g")])*(-1 if side=="south" and index=="atheta" else 1)
                    bound=obs[rr,index,side]
                    flags.append(bound[3]<=value<=bound[4])
            counts.append(sum(flags))
        forecasts.append(dict(model=model,branch=kind,fraction=fraction,**{key:float(values[key]) for key in metrics},polar_in_4=counts[0],radial_in_4=counts[1],joint_all=counts==[4,4]))
    register("nfw","spherical-one-outer-speed","",base["nfw"])
    for kind in ("fixed","matched"):
        register("mts",kind,0,base["mts"])
        for index in range(1,9):
            name=f"{kind}-{index}"
            data=local(high+"-"+name+".csv")[0]
            for tag in (mid,high):
                test=local(tag+"-"+name+".csv")[0]
                assert float(test["scaled_residual"])<4e-13 and abs(float(test["virial"]))<TOL
                with np.load(HOME/(tag+"-"+name+".npz")) as bank:
                    frac=float(bank["fraction"]);mass=float(bank["mass"])
                    assert frac==index/8 and abs(float(test["mass"])/mass-1)<1e-14
                    assert abs(np.sum(bank["ground"]**2)/mass-(1-frac))<2e-12 and abs(np.sum(bank["excited"]**2)/mass-frac)<2e-12
                if kind=="matched":assert abs(float(test["outer_speed"])-224.03)<1e-8
                else:assert float(test["mass_ratio"])==1.
                if index<8:
                    rate=local(tag+"-"+name+"-rates.csv")[0]
                    assert abs(float(rate["direct_energy_rate"])-float(rate["energy_rate"]))<1e-9
                else:assert abs(float(test["lowest_overlap"])-1)<1e-9
            compare(name,local(mid+"-"+name+".csv")[0],data,metrics)
            register("mts",kind,index/8,data)
    for row in local("alternate-domain.csv"):
        compare("alternate:"+row["branch"]+":"+row["fraction"],row,local(high+"-"+row["branch"]+f"-{round(float(row['fraction'])*8)}.csv")[0],metrics)
    assert len(local("alternate-domain.csv"))==4
    assert all(row["scaled"]<TOL for row in validation),sorted(validation,key=lambda r:r["scaled"])[-4:]
    stress=local(high+"-directional-stress.csv");assert len(stress)==18
    for item in stress:assert (float(item["fraction"])==0)==(float(item["phase_stress_to_rest"])==0)
    kmom=local(high+"-preparation-kernel.csv")
    for coarse,exact in zip(local(mid+"-preparation-kernel.csv"),kmom,strict=True):
        assert coarse["degree"]==exact["degree"]
        for key in ("overlap","gap","frozen_phase_period_Myr"):
            assert abs(float(coarse[key])-float(exact[key]))/max(1.,abs(float(exact[key])))<TOL
    assert len(kmom)==3 and float(kmom[1]["overlap"])==0.
    rows("compared-forecasts.csv",forecasts);rows("readout-resolution.csv",validation)
    for file in HOME.glob("*.csv"):
        data=read(file);assert data and all(None not in row and None not in row.values() and not any(v.lower() in ("nan","inf","-inf") for v in row.values()) for row in data)
    if seal in ("seal","replay"):
        assert all((HOME/name).is_file() for name in ("RESULTS.md","DERIVATION.md","PREPARATION.md","NEXT.md","REPLAY.md"))
        assert not any(p.is_dir() for p in HOME.iterdir())
        manifest={"parent":sha(PARENT/"seal.json"),"files":{p.name:sha(p) for p in sorted(HOME.iterdir()) if p.name!="seal.json"}}
        if seal=="seal":put("seal.json",(json.dumps(manifest,sort_keys=True,indent=2)+"\n").encode())
        assert manifest==json.loads((HOME/"seal.json").read_bytes())
        print("verified",len(manifest["files"]),sha(HOME/"seal.json"))
    print("readout comparisons",len(validation),"max",max(row["scaled"] for row in validation),"predictions",len(forecasts))


if __name__=="__main__":
    assert sys.argv[1:] in (["summarize"],["seal"],["replay"])
    audit(sys.argv[1])
