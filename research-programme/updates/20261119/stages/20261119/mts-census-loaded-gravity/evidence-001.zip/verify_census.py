from census_common import np,read,sha,guard,HERE,PREV,OLD,PARENT_HASH,TOL,table,put,json
import sys


def checks(write=False):
    guard(True)
    assert sha(OLD/"seal.json")=="ca98c3d986b58fea3eecc394da455541c2338738974aeae7793efdaca2be010c"
    rows=read("census-comparison.csv");shape=read("spherical-density-shape.csv");solar=read("solar-quasar-dipole.csv")
    assert len(rows)==42 and len(shape)==24 and len(solar)==48
    assert len(read("vertical-comparison.csv"))==2*len(rows)
    shells=read("radial-shell-certificate.csv")
    assert len(shells)==10
    bulge=read("bulge-removal-bound.csv")
    assert len(bulge)==12
    for row in bulge:
        assert abs(float(row["radial_gap_after_full_bulge_removal"])-(float(row["radial_gap_billion"])-float(row["repair_if_bulge_removed_billion"])))<1e-9
    for r in shells:
        if float(r["M_inner_max"])>0:
            assert (float(r["min_shell_to_core_density"])>1)==(float(r["monotone_mass_deficit"])>0)
    for case in ("catalogue","column"):
        for model in ("mts","nfw"):
            for mode in ("fixed","matched"):
                nominal=[float(r["amplitude_uas_y"]) for r in solar if (r["variant"],r["case"],r["model"],r["mode"])==("nominal",case,model,mode)]
                assert len(nominal)==3 and (max(nominal)-min(nominal))/min(nominal)<TOL
    assert all(float(r["Mouter"])+1e-7>=float(r["M8"])>=float(r["M6"])-1e-7 for r in shape)
    assert all((float(r["min_band_factor"])<=1+1e-8)==(r["feasible"]=="True") for r in shape)
    fd=read("frozen-tangent-check.csv")
    assert len(fd)==72 and all(np.isfinite(float(r["error"])) for r in fd)
    measures=[]
    for case in ("catalogue","column"):
        for mode in ("fixed","matched"):
            for key in {r["key"] for r in fd}:
                match=sorted([r for r in fd if (r["case"],r["mode"],r["key"])==(case,mode,key)],key=lambda x:float(x["delta"]))
                assert len(match)==2
                f,c=match
                rich=(4*float(f["central"])-float(c["central"]))/3
                delta=abs(rich-float(f["frozen"]))/max(1.,abs(float(f["frozen"])))
                assert delta<TOL
                measures.append(dict(case=case,mode=mode,key=key,central_fine_relative=f["error"],extrapolated_scaled_difference=delta))
        for grid,count,order in (("main",256,24),("main",384,32),("above",384,32)):
            tag=f"{case}-{grid}-{count}-{order}"
            with np.load(HERE/(tag+"-nominal.npz")) as pkt:
                for mode in ("fixed","matched"):
                    assert pkt[mode].shape==(order//2+1,count)
                    assert abs(np.sum(pkt[mode]**2)/pkt[mode+"_norm"]-1)<1e-11
            mod=read(tag+"-results.csv")
            for mode in ("fixed","matched"):
                sel=[r for r in mod if r["model"]=="mts" and r["mode"]==mode and r["variant"] in ("inherited","low","minusBD","nominal","high")]
                masses=np.array([float(r["N_metric_msun"]) for r in sel])
                assert len(sel)==5 and np.all(masses>0)
                assert (max(masses)/min(masses)-1<1e-11) if mode=="fixed" else all(np.diff(masses)<0)
        base=read(case+"-main-384-32-spherical-feasibility.csv")
        for r in shape:
            if r["case"]==case and r["variant"]=="census-range" and r["shape"]=="nonnegative":
                control=next(v for v in base if (v["census"],v["pointwise"],v["hypothesis"],v["components"])
                             ==("census-range",r["band"],"any-positive-spherical","both"))
                assert control["feasible"]==r["feasible"]
                if r["feasible"]=="True":
                    assert max(abs(float(r[k])-float(control[k])) for k in ("eta_min","eta_max"))<1e-9
    diagnostic=[]
    for case in ("catalogue","column"):
        for label,qual in (("main","fine"),("main","coarse"),("above","fine")):
            tag=f"{case}-{label}-384-32-hilbert-{qual}.csv"
            split=read(tag.replace("-hilbert-","-plane-defect-"))
            for row in read(tag):
                parts=next(r for r in split if r["mode"]==row["mode"])
                assert abs(sum(float(v) for k,v in parts.items() if k not in ("mode","total_gap"))-float(row["onsite_form_rel"]))<2e-10
                for key in ("mass_rel","gradient_check","trace_vs_2K","half_balance","onsite_form_rel","zz_virial","R_virial"):
                    err=abs(float(row[key]))
                    assert np.isfinite(err)
                    diagnostic.append(dict(case=case,label=label,quality=qual,mode=row["mode"],identity=key,absolute_fraction=err,within_target=err<TOL))
                assert float(row["force_plane"])>0 and float(row["force_weight"])>0 and float(row["force_wall"])>=0
                assert float(row["gradient_check"])<1 and 0<float(row["zz_fraction"])<1 and float(row["trace_over_rest"])>0
    if write:
        table("tangent-extrapolation.csv",measures);table("continuum-error-budget.csv",diagnostic)
    assert len(read("continuum-error-budget.csv"))==len(diagnostic)
    assert all(all(None not in r and None not in r.values() for r in read(p.name)) for p in HERE.glob("*.csv"))
    assert all((HERE/k).is_file() for k in ("PROTOCOL.md","STRESS-PROTOCOL.md","DERIVATION.md","REPLAY.md","RESULTS.md","NEXT.md"))
    assert not any(p.is_dir() for p in HERE.iterdir())
    files={p.name:sha(p) for p in sorted(HERE.iterdir()) if p.name!="seal.json"}
    return dict(predecessor=PARENT_HASH,files=files)


if __name__=="__main__":
    assert sys.argv[1:] in (["seal"],["replay"])
    manifest=checks(sys.argv[1]=="seal")
    if sys.argv[1]=="seal": put("seal.json",(json.dumps(manifest,sort_keys=True,indent=2)+"\n").encode())
    assert json.loads((HERE/"seal.json").read_bytes())==manifest
    print("Verified",len(manifest["files"]),"files.",sha(HERE/"seal.json"),flush=True)

