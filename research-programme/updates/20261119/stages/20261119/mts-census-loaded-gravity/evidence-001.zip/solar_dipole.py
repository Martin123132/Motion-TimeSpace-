from census_common import np,branch,read,HERE,table,PREV,old_read,Stars,ring,G,guard
from gas_common import gases,roots_legendre
from gas_rings import evaluate
from disk_state import DiskState,root_values,families
from common_shape import disk_force
from pair_energy import loaded
from scipy.constants import parsec,c,Julian_year
from types import SimpleNamespace


def compare():
    guard()
    point=np.array([[-8.122,0.,.0208]])
    stars=Stars();fields=[]
    for nr,nz,ng,extent in ((14,30,14,230.),(18,38,20,330.)):
        st=ring(stars,8.122,.0208,nr,nz,True)[:,1:]
        gg=sum(evaluate(gas,8.122,.0208,ng,extent)[1:] for gas in gases())
        fields.append((st,gg))
    for lo,hi in zip(fields[0],fields[1]):
        assert np.max(abs(hi-lo)/np.maximum(1,abs(hi)))<2e-5
    stars,gas=fields[-1]
    ret=[]
    for label,count,order in (("main",256,24),("main",384,32),("above",384,32)):
        with np.load(branch.HERE/(label+".npz")) as meta:
            length=float(meta["length"]);edge=float(meta["edge"])
        with np.load(branch.PARENT/("angular24-cap.npz" if label=="above" else "angular28-diff.npz")) as meta:
            vel=float(meta["velocity_unit_kms"]);name=str(meta["label"])
        _,material,*_=loaded(name,edge)
        dist=np.linalg.norm(point)
        cloud=-material(np.array([dist/length]))[0]*vel**2/length*point[0]/dist
        _,bulge,halo=branch.foreground(point)
        baseline=(cloud+bulge[0])[[0,2]]+gas
        modes=np.arange(0,order+1,2);full=np.arange(0,2*order+1,2)
        loc,aw=roots_legendre(max(64,3*order+32))
        speed=SimpleNamespace(length=length,vel=vel,edge=edge,orders=modes,full=full,aw=aw/2,
                              roots=[root_values(m,count) for m in modes],angle=families((1+loc)/2,modes),extra=families((1+loc)/2,full))
        for idx,case in enumerate(("catalogue","column")):
            tag=f"{case}-{label}-{count}-{order}";output=read(tag+"-results.csv")
            with np.load(HERE/(tag+"-nominal.npz")) as states,np.load(PREV/(tag+"-full.npz")) as old:
                for variant,packet in (("nominal",states),("inherited",old)):
                    for mode in ("fixed","matched"):
                        row=next(r for r in output if r["variant"]==variant and r["mode"]==mode and r["model"]=="nfw")
                        normal=baseline+float(row["eta"])*stars[idx]
                        coef=packet[mode] if variant=="nominal" else packet["matched"]
                        fields=DiskState.force(speed,coef,point,panels=105)[0,[0,2]]
                        for model,dark in (("mts",fields),("nfw",float(row["halo_amp"])*halo[0,[0,2]])):
                            accel=(normal+dark)*1e13/parsec
                            factor=1e-10*Julian_year/c*180/np.pi*3600*1e6
                            angular=factor*np.linalg.norm(accel)
                            ret.append(dict(case=case,label=label,count=count,order=order,variant=variant,mode=mode,model=model,
                                            Galactic_inward_1em10=accel[0],Galactic_up_1em10=accel[1],amplitude_uas_y=angular,
                                            residual_uas_y=angular-5.05,residual_per_quoted_width=(angular-5.05)/.35))
    table("solar-quasar-dipole.csv",ret)


if __name__=="__main__": compare()

