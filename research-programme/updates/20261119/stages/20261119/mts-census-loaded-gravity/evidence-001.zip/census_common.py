import sys
from pathlib import Path
import csv
import io
import json

HERE=Path(__file__).resolve().parent
PREV=HERE.parent/"mts-gas-loaded-response-20261119"
sys.path.insert(0,str(PREV))
from gas_common import np,G,OLD,sha,read as old_read,locations,arrangement,POINTS,RADII,HEIGHT
from loaded import Experiment,ordinary,disk_force,polish,OUTER,SPEED,step,flux
from resolved_response import branch
from spatial_null import angular
from ring_check import ring, Stars
from field import Field as StarField
from numpy.polynomial.legendre import legvander
from scipy.constants import parsec

PARENT_HASH="8002945ee5afef9467d324d2035a05533bd844bfc341ba2adb80cf552aba492f"
TOL=2e-5
TAGS={"inherited":None,"low":30.4,"minusBD":32.2,"nominal":33.4,"high":36.4}


def guard(full=False):
    assert sha(PREV/"seal.json")==PARENT_HASH
    assert not any((folder/"STOP-REQUESTED").exists() for folder in (HERE,PREV,OLD,HERE.parent))
    if full:
        for folder in (PREV,OLD):
            assert all(sha(folder/k)==value for k,value in json.loads((folder/"seal.json").read_bytes())["files"].items())


def put(name,data):
    path=HERE/name
    if path.exists():
        assert path.read_bytes()==data,name
    else:
        with path.open("xb") as out:
            out.write(data)


def read(name):
    return old_read(name,HERE)


def table(name,rows):
    buffer=io.StringIO(newline="")
    writer=csv.DictWriter(buffer,fieldnames=tuple(rows[0]),lineterminator="\n")
    writer.writeheader();writer.writerows(rows)
    put(name,buffer.getvalue().encode())


def save(name,**vals):
    path=HERE/(name+".npz")
    if path.exists():
        with np.load(path) as old:
            assert set(old)==set(vals) and all(np.array_equal(old[key],val) for key,val in vals.items()),name
    else:
        with path.open("xb") as handle:
            np.savez_compressed(handle,**vals)


def freeze():
    guard(True)
    stars=Stars()
    loc=locations()
    addition=np.array([ring(stars,rr,HEIGHT,14,30,True) for rr in RADII])
    frozen=[]; forces={}
    with np.load(OLD/"accepted-rings.npz") as initial, np.load(OLD/"spatial-null-weights.npz") as angular_inputs:
        assert np.array_equal(initial["locations"],loc[:-3])
        combined=np.vstack((initial["values"],addition))
        for idx,case in enumerate(("catalogue","column")):
            ref=next(row for row in old_read("solar-counts-input.csv",PREV) if row["case"]==case and row["convention"]=="all_table_components")
            sigma=float(ref["sigma_template_full"])
            for tag,value in TAGS.items():
                eta=1. if value is None else value/sigma
                if tag=="nominal":
                    assert abs(eta/float(ref["scale_from_full"])-1)<1e-13
                frozen.append(dict(case=case,variant=tag,target_column=value if value is not None else sigma,source_column=sigma,eta=eta))
            forces[case]=np.column_stack((combined[:,idx,1],np.zeros(len(loc)),combined[:,idx,2]))
            assert np.allclose(angular(forces[case][-3:]),angular_inputs["values"][:,idx],rtol=1e-10,atol=1e-10)
    table("frozen-source-scales.csv",frozen)
    save("stellar-readout",locations=loc,**forces)


class Census:
    def __init__(self,case,label,count,order):
        guard()
        exp=Experiment(case,label,count,order)
        self.exp=exp
        self.case=case
        self.tag=exp.tag
        sysm=exp.system
        self.sys=sysm
        exp.load(1.)
        self.ext=sysm.ext.copy();self.vir=sysm.vir.copy()
        self.etas={r["variant"]:float(r["eta"]) for r in read("frozen-source-scales.csv") if r["case"]==case}
        prior=exp.tag+"-full"
        with np.load(PREV/(prior+".npz")) as saved:
            self.seed=saved["matched"]
            self.mass0=float(saved["matched_norm"])
        self.mass_unit=sysm.vel**2*sysm.length/G
        self.halo=exp.halo
        self.halo0=float(next(row["halo_amplitude"] for row in old_read(prior+"-results.csv",PREV)
                          if row["model"]=="nfw" and row["mode"]=="matched" and row["fraction"]=="1.0"))
        self.loc=exp.loc
        with np.load(HERE/"stellar-readout.npz") as pkt:
            assert np.array_equal(self.loc,pkt["locations"])
            self.stars=pkt[case]
        compact=sum(ordinary(sysm,self.loc)[:2])-disk_force(self.loc,3.)[0]
        self.common_base=compact+exp.forces[0]+exp.forces[1]
        self.common=self.common_base+self.stars
        field=StarField("finer-"+case)
        rad=sysm.rad*sysm.length
        potential,derivative=field.multipoles(rad)
        pol=legvander(sysm.mu,int(field.modes[-1]))[:,::2].T
        self.pot=(potential@pol)/sysm.vel**2
        self.work=rad[:,None]*(derivative@pol)/sysm.vel**2
        self.load(1.)
        sysm.mass=self.mass0
        self.initial=polish(sysm,self.seed.copy())
        wave_anchor=sysm.force(self.initial.state,exp.anchor_loc)[0,0]
        assert abs(np.sqrt(OUTER*(wave_anchor+self.common[exp.anchor,0]))-SPEED)<1e-8

    def load(self,eta):
        self.sys.ext=self.ext+(eta-1.)*self.pot
        self.sys.vir=self.vir+(eta-1.)*self.work

    def root(self,start,eta,matched):
        sysm=self.sys
        for index in range(12):
            guard()
            curve=polish(sysm,start.copy())
            accel=sysm.force(curve.state,self.exp.anchor_loc)[0,0]
            delta=OUTER*(accel+self.common_base[self.exp.anchor,0]+eta*self.stars[self.exp.anchor,0])-SPEED**2
            if not matched or abs(delta)<2e-12*SPEED**2:
                return curve,index+1
            jacdir,*_=curve.differentiate("mass")
            jac=OUTER*sysm.force(curve.state,self.exp.anchor_loc,tangent=jacdir)[0,0]
            assert jac>0
            corr=np.clip(-delta/jac,-.12,.12)
            start=curve.state+jacdir*corr
            sysm.mass*=np.exp(corr)
        raise RuntimeError("outer amplitude root failed")

    def obs(self,total,wave):
        rr=self.exp.radii; cut=self.exp.cut
        speeds=np.sqrt(rr*total[:cut,0])
        polar=angular(total[-3:]); wave_angles=angular(wave[-3:])
        return dict(outer=speeds[self.exp.anchor],slope=(speeds[-2]-speeds[-3])/step,Kz=total[cut,2],
                    annulus=flux(total[:-3]),T=polar[1],wave_T=wave_angles[1],weighted_wave=self.exp.weights@wave_angles,
                    weighted_total=self.exp.weights@polar),speeds

    def tangent(self):
        curve=self.initial; sysm=self.sys; exp=self.exp
        rhs=curve.read(curve.wave*self.pot)
        du=curve.constrained(-rhs)
        residual=rhs+curve.response(du)
        muprime=np.sum(curve.state*residual)/self.mass0
        assert np.linalg.norm(residual-muprime*curve.state)<2e-10
        dm,*_=curve.differentiate("mass")
        rearr=sysm.force(curve.state,self.loc,tangent=du)
        mforce=sysm.force(curve.state,self.loc,tangent=dm)
        dlog=-(self.stars+rearr)[exp.anchor,0]/mforce[exp.anchor,0]
        dhalo=-self.stars[exp.anchor,0]/self.halo[exp.anchor,0]
        wave=sysm.force(curve.state,self.loc)
        out=[]
        for model,dark,shape,norm in (("mts",wave,rearr,dlog*mforce),("nfw",self.halo0*self.halo,np.zeros_like(wave),dhalo*self.halo)):
            speeds=self.obs(self.common+dark,dark)[1]
            for mode,field in (("direct",np.zeros_like(shape)),("fixed",shape),("matched",shape+norm)):
                total=self.stars+field
                vprime=exp.radii*total[:exp.cut,0]/(2*speeds)
                out.append(dict(model=model,mode=mode,dlogN=dlog if model=="mts" and mode=="matched" else 0.,
                                dA=dhalo if model=="nfw" and mode=="matched" else 0.,outer=vprime[exp.anchor],
                                slope=(vprime[-2]-vprime[-3])/step,Kz=total[exp.cut,2],annulus=flux(total[:-3]),
                                T=angular(total[-3:])[1],wave_T=angular(field[-3:])[1],
                                weighted_wave=exp.weights@angular(field[-3:]),weighted_total=exp.weights@angular(total[-3:])))
        table(self.tag+"-tangent.csv",out)

