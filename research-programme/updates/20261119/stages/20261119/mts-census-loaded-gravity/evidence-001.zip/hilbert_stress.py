from census_common import np,G,HERE,PREV,read,guard,table,StarField,branch
from cross_stress import grid,axes,Wave
from gas_common import gases,roots_legendre
from gas_field import Field as GasField
from disk_state import basis,root_values,families
from pair_energy import loaded
from common_shape import BULGE_GM
from scipy.special import spherical_jn,gammainc,gammaincc,gamma
import sys


def field_components(field,rad,mu):
    leg,grad=axes(field.modes,mu)
    pot,der=field.multipoles(rad)
    radius=rad[:,None]
    phi=pot@leg.T
    dr=der@leg.T
    dz=mu*dr+(pot@grad.T)/radius
    if hasattr(field,"gas"):
        sigma,slope,_=field.gas.sheet(radius)
        kernel,first,_=field.gas.vertical(radius*mu)
        phi+=4*np.pi*G*sigma*kernel
        dz+=4*np.pi*G*(mu*slope*kernel+sigma*first)
        dr+=4*np.pi*G*(slope*kernel+mu*sigma*first)
    return phi,dr,dz


def evaluate(case,label,count,order,quality):
    guard()
    tag=f"{case}-{label}-{count}-{order}"
    with np.load(HERE/(tag+"-nominal.npz")) as pkt:
        states=[(mode,pkt[mode],float(pkt[mode+"_norm"]),float(pkt[mode+"_chemical"])) for mode in ("fixed","matched")]
    with np.load(branch.HERE/(label+".npz")) as pkt:
        length,edge=float(pkt["length"]),float(pkt["edge"])
        assert abs(float(pkt["eta"])-1)<1e-12
    with np.load(branch.PARENT/("angular24-cap.npz" if label=="above" else "angular28-diff.npz")) as pkt:
        vel=float(pkt["velocity_unit_kms"]);name=str(pkt["label"])
    _,material,*_=loaded(name,edge)
    eta=next(float(row["eta"]) for row in read("frozen-source-scales.csv") if row["case"]==case and row["variant"]=="nominal")
    stop=edge*length
    spacing,rule,outer,nmu=(.5,8,94,128) if quality=="coarse" else (.28,10,151,192)
    edges=np.unique(np.r_[np.arange(0.,50.,spacing),np.geomspace(50.,stop,outer)])
    nodes,wr=grid(edges,rule)
    rad=nodes.ravel(); all_rad=np.r_[rad,stop]
    measure=(2*np.pi*rad**2*wr.ravel())[:,None]
    mu,wmu=roots_legendre(nmu); mu=(1+mu)/2;wmu=wmu/2
    cos=np.r_[mu,0.]
    modes=np.arange(0,order+1,2);full=np.arange(0,2*order+1,2)
    pol,grad=axes(modes,cos); scale=np.sqrt(2*modes+1)
    pol*=scale;grad*=scale
    den=np.empty((2,len(all_rad),len(modes)));der=den.copy();lap=den.copy()
    for idx,lorder in enumerate(modes):
        roots=root_values(lorder,count)
        kval=roots/(edge*length)
        b=basis(lorder,roots,edge,all_rad/length)
        norm=(np.sqrt(.5*edge**3*(1-np.sin(2*roots)/(2*roots)))/roots if lorder==0 else
              np.sqrt(.5*edge**3*(spherical_jn(lorder,roots)**2-spherical_jn(lorder-1,roots)*spherical_jn(lorder+1,roots))))
        db=spherical_jn(lorder,all_rad[:,None]*kval,derivative=True)*(kval/norm)
        pair=np.column_stack([coef[idx] for _,coef,_,_ in states])
        den[:,:,idx]=(b@pair).T;der[:,:,idx]=(db@pair).T;lap[:,:,idx]=(b@(-kval[:,None]**2*pair)).T
    pref=vel/np.sqrt(4*np.pi*G)/length
    den*=pref;der*=pref;lap*=pref
    kappa=length*vel
    shared=np.zeros((3,len(rad),len(cos)));components={}
    for field,factor in [(StarField("finer-"+case),eta)]+[(GasField("fine",gas),1.) for gas in gases()]:
        field_data=factor*np.asarray(field_components(field,rad,cos))
        components[getattr(getattr(field,"gas",None),"name","stars")]=field_data[0]
        shared+=field_data
    acc,cloud,_=material(rad/length)
    arg=(rad/1.9)**2
    inward=BULGE_GM*gammainc(.6,arg)/rad**2
    potential=-inward*rad-BULGE_GM*gammaincc(.1,arg)*gamma(.1)/(1.9*gamma(.6))
    shared[0]+=(potential+cloud*vel**2)[:,None]
    shared[1]+=(inward+acc*vel**2/length)[:,None]
    shared[2]+=(inward+acc*vel**2/length)[:,None]*cos
    leg,_=axes(full,mu)
    rows=[];splits=[]
    for index,(mode,coef,mass,chemical) in enumerate(states):
        ff=den[index,:-1]@pol.T; fr=der[index,:-1]@pol.T; lf=lap[index,:-1]@pol.T
        fmu=den[index,:-1]@grad.T
        fz=cos*fr+fmu/rad[:,None]
        fcyl=np.sqrt(1-cos**2)*fr-cos*fmu/(rad[:,None]*np.sqrt(1-cos**2))
        grad2=fz**2+fcyl**2
        rho=ff**2
        wave=Wave(edges,nodes,wr,full,rho[:,:-1]@(leg*wmu[:,None]))
        wave_field=np.asarray(field_components(wave,rad,cos))
        total=shared+wave_field
        eps=chemical*vel**2; pot,dr,dz=total
        source=(eps-pot)*rho-.5*kappa**2*grad2
        hilbert=kappa**2*fz**2+source
        alt=kappa**2*(fz**2-.5*(ff*lf+grad2))
        tt=kappa**2*grad2+3*source
        half=lambda vals:np.sum(measure*wmu*vals[:,:-1])
        trace=2*half(tt)
        doubled_kinetic=2*half(kappa**2*grad2)
        plane=lambda vals:2*np.pi*np.sum(wr.ravel()*rad*vals[:,-1])
        pressure=plane(hilbert);on_shell=plane(alt)
        weight=half(rho*dz)
        axis_weight=(pol[:-1]@pol[-1])*wmu
        def remaining(values):
            return values[:,-1]-values[:,:-1]@axis_weight
        source_map={**components,"wave":wave_field[0],"spherical":np.broadcast_to((potential+cloud*vel**2)[:,None],ff.shape)}
        split={}
        for source_name,phi_j in source_map.items():
            split[source_name]=2*np.pi*np.sum(wr.ravel()*rad*ff[:,-1]*remaining(phi_j*ff))/weight
        residual=(pot-eps)*ff-.5*kappa**2*lf
        low=2*np.pi*np.sum(wr.ravel()*rad*ff[:,-1]*(residual[:,:-1]@axis_weight))/weight
        gap=(on_shell-pressure)/weight
        assert abs(low+sum(split.values())-gap)<2e-10
        splits.append(dict(mode=mode,total_gap=gap,retained_angular=low,**split))
        force_wall=.5*2*np.pi*stop**2*kappa**2*(der[index,-1]@pol[:-1].T)**2
        cap=(wmu*mu)@force_wall
        wall_z=2*stop*(wmu*mu**2)@force_wall
        wall_R=2*stop*(wmu*(1-mu**2))@force_wall
        wz=2*half(rho*dz*rad[:,None]*cos)
        wrad=2*half(rho*(dr-cos*dz)*rad[:,None])
        gradz=2*half(kappa**2*fz**2)
        gradR=2*half(kappa**2*fcyl**2)
        metric_mass=mass*vel**2*length/G
        spectral_2K=sum(np.sum((root_values(lorder,count)/edge)**2*c**2) for lorder,c in zip(modes,coef))*vel**4*length/G
        rows.append(dict(mode=mode,eta=eta,mass_rel=wave.mass/metric_mass-1,force_plane=pressure,force_weight=weight,
                         force_wall=cap,half_balance=(pressure-weight-cap)/weight,onshell_plane=on_shell,
                         onsite_form_rel=(on_shell-pressure)/weight,
                         integrated_trace=trace,integrated_gradient=doubled_kinetic,spectral_2K=spectral_2K,
                         trace_vs_2K=trace/spectral_2K-1,gradient_check=doubled_kinetic/spectral_2K-1,
                         trace_over_rest=trace/(metric_mass*299792.458**2),zz_gradient=gradz,R_gradient=gradR,
                         zz_work=wz,R_work=wrad,wall_zz=wall_z,wall_R=wall_R,
                         zz_virial=(gradz-wz-wall_z)/gradz,R_virial=(gradR-wrad-wall_R)/gradR,
                         wall_wt=cap/weight,zz_fraction=gradz/doubled_kinetic))
    table(tag+"-hilbert-"+quality+".csv",rows)
    table(tag+"-plane-defect-"+quality+".csv",splits)
    print(tag,quality,[(r["half_balance"],r["zz_virial"],r["trace_over_rest"]) for r in rows],flush=True)


if __name__=="__main__":
    for arg in sys.argv[1:]:
        case,label,count,order,quality=arg.split(":")
        evaluate(case,label,int(count),int(order),quality)

