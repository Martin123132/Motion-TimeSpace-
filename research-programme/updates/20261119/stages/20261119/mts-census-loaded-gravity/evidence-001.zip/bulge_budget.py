from census_common import np,read,table,guard,G
from common_shape import BULGE_GM
from scipy.special import gammainc


def evaluate():
    guard()
    output=[]
    for case in ("catalogue","column"):
        rows=[r for r in read("radial-shell-certificate.csv") if r["case"]==case]
        base=next(r for r in rows if r["variant"]=="inherited")
        nominal=next(r for r in rows if r["variant"]=="nominal")
        inner=float(base["inner_kpc"]);outer=float(base["next_kpc"]);ratio=(outer/inner)**3
        bulge=BULGE_GM*gammainc(.6,(np.array([inner,outer])/1.9)**2)/(G*1e9)
        repair=ratio*bulge[0]-bulge[1]
        assert repair>0
        d0=float(base["monotone_mass_deficit"])
        prime=(float(nominal["monotone_mass_deficit"])-d0)/(float(nominal["eta"])-1)
        eta_list=[(r["variant"],float(r["eta"])) for r in rows]
        check=next(r for r in read(case+"-main-384-32-spherical-feasibility.csv")
                   if (r["hypothesis"],r["components"],r["pointwise"],r["census"])==("any-positive-spherical","atheta","95","census-range"))
        if check["feasible"]=="True":
            eta_list.extend((("polar_allowed_min",float(check["eta_min"])),("polar_allowed_max",float(check["eta_max"]))))
        for variant,eta in eta_list:
            gap=d0+prime*(eta-1)
            if variant not in ("polar_allowed_min","polar_allowed_max"):
                assert abs(gap-float(next(r["monotone_mass_deficit"] for r in rows if r["variant"]==variant)))<1e-10
            output.append(dict(case=case,variant=variant,eta=eta,R1=inner,R2=outer,mass_ratio_cap=ratio,
                               radial_gap_billion=gap,pointmass_removal_min_billion=max(0,gap/(ratio-1)),
                               B_inner_billion=bulge[0],B_outer_billion=bulge[1],repair_if_bulge_removed_billion=repair,
                               required_bulge_fraction=max(0,gap/repair),radial_gap_after_full_bulge_removal=gap-repair,
                               polar_census_overlap=check["feasible"]))
    table("bulge-removal-bound.csv",output)


if __name__=="__main__": evaluate()

