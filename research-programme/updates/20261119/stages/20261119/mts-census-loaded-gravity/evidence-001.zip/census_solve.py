from census_common import Census,guard,np,save,table,branch,OUTER,SPEED,HERE
from feasibility import freeze_bounds,projections,bands
import sys


def execute(case,label,count,order):
    cen=Census(case,label,count,order); sysm=cen.sys; exp=cen.exp
    cen.tangent()
    freeze_bounds(cen)
    sky=bands()
    cep=branch.read("cepheid-table1.csv"); giant=branch.read("eilers-table1.csv")
    expected=np.array([float(row["V_kms"]) for row in cep+giant])
    anchor=exp.anchor
    base=cen.initial.state.copy()
    dark0=sysm.force(base,cen.loc)
    rows=[]; comparisons=[]; curves=[]; state={}
    def record(tag,eta,mode,model,dark,N,amp,curve=None):
        total=cen.common_base+eta*cen.stars+dark
        obs,speeds=cen.obs(total,dark)
        diff=speeds[:len(expected)]-expected
        rmse=lambda vals: np.sqrt(np.mean(vals**2))
        rows.append(dict(variant=tag,eta=eta,mode=mode,model=model,N_metric_msun=N,halo_amp=amp,
                         rms_cep11=rmse(np.delete(diff[:len(cep)],anchor)),rms_giant38=rmse(diff[len(cep):]),**obs,
                         norm_rel=np.sum(curve.state**2)/sysm.mass-1 if curve else "",
                         stationary_rel=np.linalg.norm(curve.resid)/(abs(curve.chemical)*np.sqrt(sysm.mass)) if curve else "",
                         virial_rel=sysm.parts(curve.state)[3] if curve else "",chemical=curve.chemical if curve else ""))
        if tag not in cen.etas: return
        p=projections(total)
        for (radius,kind,side),stats in sky.items():
            ind=0 if radius==6. else 1
            value=p[int(kind=="atheta"),ind]*(-1 if side=="south" and kind=="atheta" else 1)
            center,lo,hi,low,high=stats
            comparisons.append(dict(variant=tag,mode=mode,model=model,R=radius,side=side,component=kind,
                               predicted=value,observed=center,residual=value-center,lo68=lo,hi68=hi,lo95=low,hi95=high,
                               inside68=lo<=value<=hi,inside95=low<=value<=high))
        if tag=="nominal":
            for idx,pred in enumerate(speeds[:len(expected)]):
                curves.append(dict(mode=mode,model=model,sample="cepheid" if idx<len(cep) else "giant",R=exp.radii[idx],
                                   predicted=pred,observed=expected[idx],calibration=idx==anchor))
    for mode in ("fixed","matched"):
        sysm.mass=cen.mass0
        prev=1.; current=base.copy()
        def solve(eta):
            nonlocal current,prev
            for val in np.linspace(prev,eta,max(1,int(np.ceil(abs(eta-prev)/.13)))+1)[1:]:
                cen.load(val)
                curve,_=cen.root(current,val,mode=="matched")
                current=curve.state.copy()
            prev=eta
            return curve
        for tag,eta in cen.etas.items():
            guard()
            curve=solve(eta)
            amp=cen.halo0-(eta-1.)*cen.stars[anchor,0]/cen.halo[anchor,0] if mode=="matched" else cen.halo0
            assert amp>0
            wave=sysm.force(current,cen.loc)
            record(tag,eta,mode,"mts",wave,sysm.mass*cen.mass_unit,"",curve)
            record(tag,eta,mode,"nfw",amp*cen.halo,"",amp)
            if tag=="nominal":
                state[mode]=current.copy(); state[mode+"_norm"]=sysm.mass; state[mode+"_chemical"]=curve.chemical
                if mode=="fixed":
                    record(tag,eta,"direct-only","mts",dark0,cen.mass0*cen.mass_unit,"")
        if label=="main" and count==256:
            for delta in (-1/64,1/64,-1/128,1/128):
                sysm.mass=cen.mass0;current=base.copy();prev=1.
                curve=solve(1.+delta)
                record(str(delta),1.+delta,mode,"mts",sysm.force(current,cen.loc),sysm.mass*cen.mass_unit,"",curve)
    table(cen.tag+"-results.csv",rows);table(cen.tag+"-sky.csv",comparisons);table(cen.tag+"-curves.csv",curves)
    save(cen.tag+"-nominal",**state)
    print(cen.tag,"finished",flush=True)


if __name__=="__main__":
    labels=sys.argv[1:]
    for idx in range(0,len(labels),4):
        case,label,count,order=labels[idx:idx+4];execute(case,label,int(count),int(order))

