from census_common import G,np,parsec,PREV,old_read,table,OUTER,SPEED,HEIGHT,RADII
from scipy.optimize import linprog

UNIT=1e13/parsec


def projections(forces):
    rr=np.hypot(RADII,HEIGHT)
    gin,gz=forces[-3:,0],forces[-3:,2]
    return np.stack(((-RADII*gin+HEIGHT*gz)/rr,(-HEIGHT*gin-RADII*gz)/rr))*UNIT


def bands():
    source=old_read("gaia-figure9-comparison.csv",PREV)
    arr={}
    for row in source:
        key=(float(row["R_cylinder_kpc"]),row["component"],row["side"])
        value=tuple(float(row[n]) for n in ("center","lo68","hi68","lo95","hi95"))
        assert arr.setdefault(key,value)==value
    assert len(arr)==8
    return arr


def freeze_bounds(cen):
    base=projections(cen.common_base); stars=projections(cen.stars)
    halo=projections(cen.halo); anchor=cen.exp.anchor
    assert max(abs(halo[1]))<1e-12
    derivative=-cen.stars[anchor,0]/cen.halo[anchor,0]
    output=[]
    for hypothesis in ("fixed-scale-NFW","any-positive-spherical"):
        for components in ("atheta","ar","both"):
            for nominal_band in ("68","95"):
                for census in ("free-positive","census-range"):
                    matrix=[]; bound=[]
                    for (rr,kind,side),stats in bands().items():
                        if components not in ("both",kind):
                            continue
                        loc=list(RADII).index(rr); index=int(kind=="atheta")
                        sign=-1 if side=="south" and index else 1
                        offset=base[index,loc]; slope=stars[index,loc]
                        coeff=np.array([slope,0.,0.])
                        if hypothesis=="fixed-scale-NFW":
                            offset+=(cen.halo0-derivative)*halo[index,loc]
                            coeff[0]+=derivative*halo[index,loc]
                        elif not index:
                            coeff[1+loc]=-G*1e9*UNIT/(rr**2+HEIGHT**2)
                        low,high=stats[1:3] if nominal_band=="68" else stats[3:]
                        matrix.extend((sign*coeff,-sign*coeff));bound.extend((high-sign*offset,sign*offset-low))
                    if hypothesis=="any-positive-spherical":
                        scale=OUTER**2/(G*1e9)
                        matrix.extend(([0,1,-1],[scale*cen.stars[anchor,0],0,1]))
                        bound.extend((0,scale*(SPEED**2/OUTER-cen.common_base[anchor,0])))
                    else:
                        matrix.append([-derivative,0,0]);bound.append(cen.halo0-derivative)
                    bounds=[(0,None) if census=="free-positive" else (cen.etas["low"],cen.etas["high"]),(0,None),(0,None)]
                    sols=[linprog([sgn,0,0],A_ub=matrix,b_ub=bound,bounds=bounds,method="highs") for sgn in (1,-1)]
                    assert all(s.status in (0,2) for s in sols),[(s.status,s.message) for s in sols]
                    assert sols[0].status==sols[1].status
                    row=dict(hypothesis=hypothesis,components=components,pointwise=nominal_band,census=census,feasible=sols[0].success,
                             eta_min="",eta_max="",M6_at_min_billion="",M8_at_min_billion="")
                    if sols[0].success:
                        row.update(eta_min=sols[0].x[0],eta_max=sols[1].x[0])
                        if hypothesis=="any-positive-spherical":
                            row.update(M6_at_min_billion=sols[0].x[1],M8_at_min_billion=sols[0].x[2])
                        assert all(np.max(np.asarray(matrix)@s.x-bound)<1e-8 for s in sols)
                    output.append(row)
    table(cen.tag+"-spherical-feasibility.csv",output)

