from census_common import np,read,table,PREV,old_read,OUTER,SPEED,HERE,POINTS,G,branch,HEIGHT,RADII
from feasibility import projections,bands,UNIT
from scipy.optimize import linprog


def evaluate():
    with np.load(HERE/"stellar-readout.npz") as pkt:
        location=pkt["locations"];sourced={case:pkt[case] for case in ("column","catalogue")}
    nfw=branch.foreground(location)[2]
    rep=old_read("gaia-spherical-forecast.csv",PREV)
    anchor=np.where((location[:,0]==-OUTER)&(location[:,2]==0))[0].item()
    rr=np.hypot(RADII[:2],HEIGHT)
    volumes=np.diff(np.r_[0.,rr**3,OUTER**3])*4*np.pi/3
    output=[]; radial=[]
    for case,star in sourced.items():
        scales={r["variant"]:float(r["eta"]) for r in read("frozen-source-scales.csv") if r["case"]==case}
        prev=old_read(case+"-main-384-32-full-results.csv",PREV)
        amp=float(next(r["halo_amplitude"] for r in prev if r["mode"]=="matched" and r["model"]=="nfw" and float(r["fraction"])==1.))
        common=np.empty((2,2))
        slope=projections(star)[:,:2]
        dark=projections(nfw)
        for idx,R in enumerate(RADII[:2]):
            src=next(r for r in rep if r["case"]==case and r["model"]=="spherical_nfw" and float(r["R_kpc"])==R and float(r["z_kpc"])>0)
            common[:,idx]=[float(src[axis+"_in_1em10_m_s2"]) for axis in ("ar","atheta")]
        common-=slope+amp*dark[:,:2]
        factor=OUTER**2/(1e9*G); intercept=factor*(amp*nfw[anchor,0]+star[anchor,0]); dmass=-factor*star[anchor,0]
        for variant,eta in scales.items():
            lum=common+eta*slope; lower=[];upper=[]
            for j,rad in enumerate(RADII[:2]):
                north,south=(bands()[rad,"ar",side] for side in ("north","south"))
                low=max(north[3],south[3]);high=min(north[4],south[4])
                conv=rr[j]**2/(G*1e9*UNIT)
                lower.append(max(0.,(lum[0,j]-high)*conv))
                upper.append((lum[0,j]-low)*conv)
            upper0=upper[0]; lower1=lower[1]
            radial.append(dict(case=case,variant=variant,eta=eta,M_inner_min=lower[0],M_inner_max=upper[0],
                               M_next_min=lower[1],M_next_max=upper[1],inner_kpc=rr[0],next_kpc=rr[1],
                               min_shell_to_core_density=(lower1/upper0-1)*volumes[0]/volumes[1] if upper0>0 else "",
                               monotone_mass_deficit=lower1-(rr[1]/rr[0])**3*upper0))
        for variant,lim in (("nominal",(scales["nominal"],scales["nominal"])),("census-range",(scales["low"],scales["high"]))):
            for label in ("nonnegative","nonincreasing","slope-at-least-one"):
                geom=[([0,1,-1],0.),([-dmass,0,1],intercept)]
                if label!="nonnegative":
                    moment=volumes if label=="nonincreasing" else np.diff(np.r_[0.,rr**2,OUTER**2])
                    a,b,c=moment
                    geom.extend([([0,-(1+b/a),1],0),([dmass,c/b,-(1+c/b)],-intercept)])
                for band in ("68","95"):
                    lhs=[];right=[];errs=[]
                    for (rad,kind,side),stats in bands().items():
                        j=list(RADII).index(rad);i=int(kind=="atheta");sgn=-1 if i and side=="south" else 1
                        center,lo,hi=stats[:3] if band=="68" else (stats[0],*stats[3:])
                        coeff=np.array([slope[i,j],0.,0.]);offset=common[i,j]
                        if not i: coeff[j+1]=-G*1e9*UNIT/rr[j]**2
                        lhs.extend((sgn*coeff,-sgn*coeff));right.extend((center-sgn*offset,-center+sgn*offset))
                        errs.extend((hi-center,center-lo))
                    for coeff,val in geom:
                        lhs.append(coeff);right.append(val);errs.append(0.)
                    A=np.array(lhs); y=np.array(right); er=np.array(errs)
                    bounds=[lim,(0,None),(0,None)]
                    fit=linprog([0,0,0,1],A_ub=np.column_stack((A,-er)),b_ub=y,bounds=[*bounds,(0,None)],method="highs")
                    assert fit.success and max(A@fit.x[:3]-er*fit.x[-1]-y)<1e-7
                    witness=fit.x
                    mass=np.r_[witness[1:3],intercept+dmass*witness[0]]
                    dens=np.diff(np.r_[0,mass])/volumes
                    low=linprog([1,0,0],A_ub=A,b_ub=y+er,bounds=bounds,method="highs")
                    high=linprog([-1,0,0],A_ub=A,b_ub=y+er,bounds=bounds,method="highs")
                    assert low.success==high.success==(witness[-1]<=1.+1e-8)
                    if label!="nonnegative":
                        assert max(np.diff(dens))<1e-9 and max(np.diff(np.diff(np.r_[0.,mass])/moment))<1e-9
                    out=dict(case=case,variant=variant,shape=label,band=band,feasible=low.success,
                             eta_min=low.x[0] if low.success else "",eta_max=high.x[0] if high.success else "",
                             min_band_factor=witness[-1],eta_witness=witness[0],M6=witness[1],M8=witness[2],
                             Mouter=mass[2],inner_density=dens[0],mid_density=dens[1],outer_density=dens[2])
                    output.append(out)
    table("spherical-density-shape.csv",output)
    table("radial-shell-certificate.csv",radial)


if __name__=="__main__": evaluate()

