from census_common import HERE,np,read,table,guard,TOL,old_read,PREV,branch


def compare():
    guard()
    rows=[]; refinements=[];scored=[];derivatives=[];vertical=[];tags=[("main",256,24),("main",384,32),("above",384,32)]
    skyref=old_read("gaia-figure9-comparison.csv",PREV)
    forecast=old_read("census-spherical-forward.csv",PREV)
    for case in ("catalogue","column"):
        output={}; skysets={}
        for label,count,order in tags:
            tag=f"{case}-{label}-{count}-{order}"
            res=read(tag+"-results.csv");skydata=read(tag+"-sky.csv");skysets[label,count]=skydata
            output[label,count]={(r["variant"],r["mode"],r["model"]):r for r in res}
            for r in res:
                if r["model"]=="mts" and r["stationary_rel"]:
                    assert float(r["stationary_rel"])<3e-13 and abs(float(r["norm_rel"]))<1e-11
                if r["mode"]=="matched": assert abs(float(r["outer"])-224.03)<1e-7
            for row in skydata:
                if row["variant"]=="inherited" and row["mode"]=="matched":
                    target=next(v for v in skyref if v["case"]==case and v["side"]==row["side"] and float(v["R_cylinder_kpc"])==float(row["R"])
                                and v["component"]==row["component"] and v["model"]==("mts" if row["model"]=="mts" else "spherical_nfw"))
                    if label=="main" and count==384:
                        assert abs(float(row["predicted"])-float(target["predicted"]))<TOL
                if row["model"]=="nfw" and row["variant"] in ("nominal","minusBD") and row["component"]=="atheta":
                    target=next(v for v in forecast if v["case"]==case and v["side"]==row["side"] and float(v["R_kpc"])==float(row["R"])
                                and v["population"]==("all" if row["variant"]=="nominal" else "minus_BD_sensitivity")
                                and v["source_choice"]=="mass_only")
                    assert abs(float(row["predicted"])-float(target["forecast_spherical"]))<1e-10
            if count==256:
                exact=read(tag+"-tangent.csv")
                for mode in ("fixed","matched"):
                    parent=next(v for v in exact if v["mode"]==mode and v["model"]=="mts")
                    for h in (1/64,1/128):
                        plus,minus=(output[label,count][str(d),mode,"mts"] for d in (h,-h))
                        for key in ("outer","slope","Kz","annulus","T","wave_T","weighted_wave","weighted_total","dlogN"):
                            target=float(parent[key])
                            if key=="dlogN":
                                value=np.log(float(plus["N_metric_msun"])/float(minus["N_metric_msun"]))/(2*h)
                            else:
                                value=(float(plus[key])-float(minus[key]))/(2*h)
                            err=(value-target)/max(1,abs(target))
                            derivatives.append(dict(case=case,mode=mode,delta=h,key=key,frozen=target,central=value,error=err))
            if label=="main" and count==384:
                for r in res:
                    if r["variant"] not in ("inherited","low","minusBD","nominal","high"): continue
                    grouped=[v for v in skydata if v["variant"]==r["variant"] and v["mode"]==r["mode"] and v["model"]==r["model"]]
                    counts={kind:sum(v["inside95"]=="True" for v in grouped if v["component"]==kind) for kind in ("ar","atheta")}
                    assert len(grouped)==8
                    rows.append(dict(case=case,**r,radial_inside=counts["ar"],polar_inside=counts["atheta"]))
                    for obs in branch.read("vertical.csv"):
                        if obs["case"]=="main" and obs["model"]=="mts" and obs["use"]=="comparison":
                            residual=(float(r["Kz"])-float(obs["Kz_observed_at_R0"]))/float(obs["sigma"])
                            vertical.append(dict(case=case,variant=r["variant"],model=r["model"],mode=r["mode"],tracer=obs["tracer"],
                                               observed=obs["Kz_observed_at_R0"],sigma=obs["sigma"],Kz=r["Kz"],standardized=residual))
            for r in read(tag+"-curves.csv"):
                branchdata=branch.read("cepheid-table1.csv" if r["sample"]=="cepheid" else "eilers-table1.csv")
                assert len([s for s in branchdata if s["R_kpc"]==r["R"] or float(s["R_kpc"])==float(r["R"])])==1
        for key,primary in output["main",384].items():
            for label,count in (("main",256),("above",384)):
                alternate=output[label,count][key]
                for val in ("outer","slope","Kz","T","wave_T","weighted_wave","annulus","rms_cep11","rms_giant38"):
                    left=float(primary[val]);right=float(alternate[val])
                    refinements.append(dict(case=case,variant=key[0],mode=key[1],model=key[2],comparison=f"{label}-{count}",metric=val,
                                            primary=left,other=right,delta=right-left,scaled_difference=(right-left)/max(1,abs(left))))
        for key in ("main",256),("above",384):
            for hi,variant in zip(skysets["main",384],skysets[key]):
                assert all(hi[n]==variant[n] for n in ("variant","mode","model","R","side","component"))
                scored.append(dict(case=case,variant=hi["variant"],mode=hi["mode"],model=hi["model"],R=hi["R"],side=hi["side"],
                                   component=hi["component"],grid=str(key),delta=float(variant["predicted"])-float(hi["predicted"]),
                                   same68=hi["inside68"]==variant["inside68"],same95=hi["inside95"]==variant["inside95"]))
    table("census-comparison.csv",rows);table("grid-differences.csv",refinements);table("sky-grid-differences.csv",scored)
    table("frozen-tangent-check.csv",derivatives);table("vertical-comparison.csv",vertical)


if __name__=="__main__": compare()

