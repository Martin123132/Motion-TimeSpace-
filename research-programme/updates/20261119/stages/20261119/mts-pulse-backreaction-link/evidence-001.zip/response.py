from launch_packet import *


def rays(data, site, panels):
    strip = Strip(dict(time=data["time"], space=data[f"{site}_x"], bank=data[site]), 1)
    low = SITES[site]
    def leg(emission, direction):
        def rhs(offset, state):
            time = emission + offset + state[0]
            position = np.full_like(time, low + (0 if direction > 0 else .5) + direction * offset)
            length, curvature, dlength, dcurvature = [strip.get(index, time, position) for index in range(4)]
            derivative = strip.surfaces[1].ev(time, position, dx=1)
            return np.stack((length, curvature, dlength-curvature*state[2],
                             dcurvature+derivative*state[2], derivative*np.exp(-state[1])))
        return march(rhs, 5, .5, panels, len(emission))
    first = leg(EMISSIONS, 1)
    back = leg(EMISSIONS + .5 + first[0], -1)
    log = first[1] + back[1]
    base = np.stack((np.expm1(first[1]), np.expm1(log), first[0], first[0]+back[0]))
    tangent = np.stack((np.exp(first[1])*first[3], np.exp(log)*(first[3]+back[3]+back[4]*first[2]),
                        first[2], np.exp(-back[1])*first[2]+back[2]))
    return base, tangent


class Prediction:
    def __init__(self, mesh, eta):
        self.system = Ordinary(mesh, eta, "tensor", 0., RADIUS)
        self.radial = Radial(mesh, "tensor", 0., eta, RADIUS)

    def rhs(self, packed):
        metric = packed[:8]
        field, speed = packed[8:]
        geometry = metric.real
        radial, angular, krad, kang = geometry[:4]
        scale = 1 + radial
        area = 1 + angular
        length = np.sqrt(scale)
        root = np.sqrt(area)
        radius = self.system.x
        variation = self.system.rhs(metric)
        drad, dang = self.system.diff(geometry[:2])
        grad = self.radial.diff(field, self.radial.d1)
        slope = grad / length
        kinetic, spatial, potential = speed.real*speed.imag, slope.real*slope.imag, field.real*field.imag
        pressure = kinetic + spatial - potential
        current = -speed.real*slope.imag - speed.imag*slope.real
        radius_x = root + radius*dang/(2*root)
        motion = -radius*kang/root
        variation[2] += 1j*STEP*2*scale*(kinetic-spatial)
        variation[3] += 1j*STEP*area*pressure
        variation[4] -= 1j*STEP*area*(pressure*motion + current*radius_x/length)/radius
        scalar_rate = (self.radial.diff(radius*field, self.radial.d2, True)/radius
                       + (dang/area-drad/(2*scale))*grad)/scale - field + (krad/scale+2*kang/area)*speed
        return np.concatenate((variation, speed[None], scalar_rate[None]))


def evaluate(kind, prep, mesh, eta, label="tangent"):
    guard()
    if kind != "forecast":
        locked()
    dest = tag(kind, prep, mesh, eta, label)
    if (WORK / dest).exists():
        raise FileExistsError(dest)
    amp = {"tangent": 1j*STEP, "plus": .0002, "minus": -.0002, "halfplus": .0001, "halfminus": -.0001}[label]
    launch = Launch(mesh, eta)
    field, info = launch.data(kind, prep, amp)
    if kind == "forecast":
        solver = Prediction(mesh, eta)
        field = field[[0,1,2,3,4,7,8,9,5,6]]
        space = solver.system.x
    else:
        solver = Radial(mesh, "tensor", 0., eta, RADIUS)
        space = solver.x
    selections = {name: (space >= loc-.09) & (space <= loc+.59) for name, loc in SITES.items()}
    keep = {name: [] for name in selections}
    count = int(np.ceil(.01*mesh/.42))
    step = .01 / count
    for tick in range(450*count + 1):
        if tick % count == 0:
            for name, mask in selections.items():
                comp, curve = field[0,mask], field[2,mask]
                length = np.sqrt(1+comp)
                small = comp/(1+length)
                curv = curve/length
                keep[name].append(np.stack((small.real,curv.real,small.imag/STEP,curv.imag/STEP)))
        if tick % (50*count) == 0:
            guard()
        if tick == 450*count:
            break
        first = solver.rhs(field)
        second = solver.rhs(field+.5*step*first)
        third = solver.rhs(field+.5*step*second)
        fourth = solver.rhs(field+step*third)
        field += step/6*(first+2*second+2*third+fourth)
    assert np.isfinite(field).all()
    packet = dict(time=np.arange(451)*.01, launch=info, emission=EMISSIONS, amplitude=amp)
    for name, mask in selections.items():
        packet[name] = np.asarray(keep[name])
        packet[name+"_x"] = space[mask]
        for panels in (32,64):
            base, derivative = rays(packet, name, panels)
            packet[f"{name}_base{panels}"] = base
            packet[f"{name}_response{panels}"] = derivative
    dump(dest, **packet)
    print(dest, "launch", info, flush=True)


def tag(kind, prep, mesh, eta, label):
    return f"{kind}-{prep}-{mesh}-q{eta:g}-{label}.npz"


def locked(create=False):
    files = ["PROTOCOL.md", "response.py", "launch_packet.py"]
    files += [tag("forecast", prep, mesh, eta, "tangent") for mesh in (64,128) for eta in (.8,1.) for prep in ("N","M")]
    stamp = {name: bridge.sha(WORK/name) for name in files}
    seal = WORK/"frozen.json"
    if create:
        with seal.open("x") as stream:
            json.dump(stamp,stream,indent=2,sort_keys=True)
    else:
        assert json.loads(seal.read_text()) == stamp


if __name__ == "__main__":
    guard()
    kind = sys.argv[1]
    if kind == "freeze":
        locked(True)
    else:
        eta = float(sys.argv[2])
        for request in sys.argv[3:]:
            prep, mesh, label = request.split(":")
            evaluate(kind, prep, int(mesh), eta, label)
