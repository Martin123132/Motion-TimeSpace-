from launch_packet import *
import importlib.util

specification = importlib.util.spec_from_file_location("pulse_link_operator", WORK/"response.py")
link_module = importlib.util.module_from_spec(specification)
specification.loader.exec_module(link_module)
Prediction, locked, rays = link_module.Prediction, link_module.locked, link_module.rays

LOCATIONS = dict(SITES, middle=4.)
SITES.update(LOCATIONS)


class Weighted(Prediction):
    def __init__(self, mesh, weight):
        super().__init__(mesh, .8)
        self.weight = weight

    def rhs(self, packed):
        metric = packed[:8]
        field, speed = packed[8:]
        radial, angular, krad, kang = metric[:4]
        scale, area = 1+radial, 1+angular
        length, root = np.sqrt(scale), np.sqrt(area)
        radius = self.system.x
        rate = self.system.rhs(metric)
        drad, dang = self.system.diff(metric[:2])
        grad = self.radial.diff(field, self.radial.d1)
        slope = grad / length
        pressure = (speed**2+slope**2-field**2)/2
        current = -speed*slope
        rx = root+radius*dang/(2*root)
        motion = -radius*kang/root
        rate[2] += self.weight*scale*(speed**2-slope**2)
        rate[3] += self.weight*area*pressure
        rate[4] -= self.weight*area*(pressure*motion+current*rx/length)/radius
        scalar = (self.radial.diff(radius*field,self.radial.d2,True)/radius
                  +(dang/area-drad/(2*scale))*grad)/scale - field + (krad/scale+2*kang/area)*speed
        return np.concatenate((rate,speed[None],scalar[None]))


def weighted_launch(mesh, weight):
    spec = Launch(mesh, .8)
    radius, inv = spec.radius, spec.inv
    ripple = spec.pulse + spec.match*spec.shell
    mass = spec.ordinary.copy()
    for iteration in range(15):
        fac = 1-2*mass*inv
        source = spec.number*np.sqrt(fac)+(spec.charge*inv**2)**2/2
        source += weight*(spec.height**2+fac*spec.slope**2)/2
        updated = integrate(radius, radius**2*source)
        if max(abs(mass-updated)) < 1e-17:
            mass = updated
            break
        mass = updated
    else:
        raise ArithmeticError("weighted launch")
    fac = 1-2*mass*inv
    slope = radius*(spec.number/np.sqrt(fac)+weight*spec.slope**2)
    drive = weight*radius**2*(spec.height*ripple[0]+fac*spec.slope*ripple[1])
    dm = kernel(radius,slope,drive)
    picks = spec.picks
    rad = (2*mass*inv/fac+1j*STEP*2*inv*dm/fac**2)[picks]
    zero = np.zeros_like(rad)
    return np.stack((rad,zero,zero,zero,((mass+1j*STEP*dm)*inv**3)[picks],
                     spec.number[picks],zero,spec.charge[picks],(spec.height+1j*STEP*ripple[0])[picks],zero))


def run(mesh, weight, target=False):
    guard()
    locked()
    if target:
        second_lock()
        scheme = Radial(mesh,"tensor",0.,.8,RADIUS)
        field, _ = Launch(mesh,.8).data("full","M",1j*STEP)
        space = scheme.x
        name = f"new-target-{mesh}.npz"
    else:
        assert weight in (-.25,-.125,.125,.25)
        scheme = Weighted(mesh,weight)
        field = weighted_launch(mesh,weight)
        space = scheme.system.x
        name = f"aux-{mesh}-{weight:g}.npz"
    assert not (WORK/name).exists()
    masks = {site: (space >= loc-.09) & (space <= loc+.59) for site,loc in LOCATIONS.items()}
    series = {site:[] for site in masks}
    count = int(np.ceil(.01*mesh/.42))
    step = .01/count
    for tick in range(450*count+1):
        if tick%count==0:
            for site, mask in masks.items():
                comp = field[0,mask]
                length = np.sqrt(1+comp)
                geo = comp/(1+length)
                freq = field[2,mask]/length
                series[site].append(np.stack((geo.real,freq.real,geo.imag/STEP,freq.imag/STEP)))
        if tick%(50*count)==0:
            guard()
        if tick==450*count:
            break
        first=scheme.rhs(field)
        second=scheme.rhs(field+step*first/2)
        third=scheme.rhs(field+step*second/2)
        fourth=scheme.rhs(field+step*third)
        field+=step/6*(first+2*second+2*third+fourth)
    assert np.isfinite(field).all()
    output=dict(weight=weight,emission=EMISSIONS)
    for site in masks:
        data={"time":np.arange(451)*.01,site:np.array(series[site]),site+"_x":space[masks[site]]}
        for panels in (32,64):
            base,response=rays(data,site,panels)
            output[f"{site}_{panels}"]=response
            if panels==64:
                output[site+"_base"]=base
    dump(name,**output)
    print(name,flush=True)


def synthesis(mesh):
    packs={z:bridge.read(WORK/f"aux-{mesh}-{z:g}.npz") for z in (-.25,-.125,.125,.25)}
    data={}
    for site in LOCATIONS:
        for panels in (32,64):
            key=f"{site}_{panels}"
            def separate(step):
                plus, minus = packs[step][key], packs[-step][key]
                return np.stack(((plus-minus)/(2*step),(plus+minus)/(2*step**2)))
            wide, narrow = separate(.25), separate(.125)
            best=(4*narrow-wide)/3
            data[key+"_orders"]=best
            data[key+"_narrow"]=narrow
    dump(f"second-order-{mesh}.npz",**data)


def second_lock(create=False):
    files=["frozen.json","SECOND-ORDER.md","stress_series.py"]
    for mesh in (128,256):
        files.extend([f"aux-{mesh}-{z:g}.npz" for z in (-.25,-.125,.125,.25)])
        files.append(f"second-order-{mesh}.npz")
    stamp={name:bridge.sha(WORK/name) for name in files}
    dest=WORK/"second-frozen.json"
    if create:
        with dest.open("x") as stream:
            json.dump(stamp,stream,sort_keys=True,indent=2)
    else:
        assert json.loads(dest.read_text())==stamp


if __name__=="__main__":
    task=sys.argv[1]
    if task=="freeze":
        for mesh in (128,256):
            synthesis(mesh)
        second_lock(True)
    elif task=="target":
        run(int(sys.argv[2]),1.,True)
    else:
        mesh=int(sys.argv[2])
        for raw in sys.argv[3:]:
            run(mesh,float(raw))
