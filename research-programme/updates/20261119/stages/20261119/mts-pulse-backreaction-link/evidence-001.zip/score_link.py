from launch_packet import *
import csv


def write(name, rows):
    with (WORK/name).open("x",newline="",encoding="utf-8") as stream:
        writer = csv.DictWriter(stream,fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def maximum(wave):
    return float(np.max(abs(wave)))


CHANNELS=("out","echo","out_delay","echo_delay")


def first():
    rows,finite=[],[]
    for eta in (.8,1.):
        for prep in ("N","M"):
            def get(kind,mesh,suffix="tangent"):
                return bridge.read(WORK/f"{kind}-{prep}-{mesh}-q{eta:g}-{suffix}.npz")
            fore = [get("forecast",mesh) for mesh in (64,128)]
            truth = [get("full",mesh) for mesh in (64,128)]
            real = {label:get("full",128,label) for label in ("plus","minus","halfplus","halfminus")} if eta==.8 else {}
            for site in ("inner","outer"):
                for idx,channel in enumerate(CHANNELS):
                    key=site+"_response64"
                    target=truth[1][key][idx]
                    value=fore[1][key][idx]
                    peak=int(np.argmax(abs(target)))
                    scale=abs(target[peak])
                    err=lambda delta: maximum(delta)/scale
                    model=err(target-value)
                    fg=err(value-fore[0][key][idx])
                    tg=err(target-truth[0][key][idx])
                    fr=err(value-fore[1][site+"_response32"][idx])
                    tr=err(target-truth[1][site+"_response32"][idx])
                    total=model+fg+tg+fr+tr
                    rows.append(dict(eta=eta,prep=prep,link=site,channel=channel,full_peak=target[peak],
                                     peak_emit=EMISSIONS[peak],forecast_at_peak=value[peak],model=model,forecast_grid=fg,
                                     target_grid=tg,forecast_ray=fr,target_ray=tr,total=total,passes=total<=TOL))
                    if real:
                        key=site+"_base64"
                        wide=(real["plus"][key][idx]-real["minus"][key][idx])/.0004
                        narrow=(real["halfplus"][key][idx]-real["halfminus"][key][idx])/.0002
                        extrap=(4*narrow-wide)/3
                        discrepancy=err(extrap-target)
                        correction=err(extrap-narrow)
                        finite.append(dict(prep=prep,link=site,channel=channel,complex_vs_signed=discrepancy,
                                           extrapolation_shift=correction,wide_vs_target=err(wide-target),
                                           passes=discrepancy+correction<=TOL))
    write("leading-budget.csv",rows)
    write("real-controls.csv",finite)


def second():
    prediction=[bridge.read(WORK/f"second-order-{mesh}.npz") for mesh in (128,256)]
    truth=[bridge.read(WORK/f"new-target-{mesh}.npz") for mesh in (128,256)]
    rows=[]
    for site in ("inner","middle","outer"):
        key=site+"_64"
        for idx,channel in enumerate(CHANNELS):
            target=truth[1][key][idx]
            peak=int(np.argmax(abs(target)))
            scale=abs(target[peak])
            err=lambda wave:maximum(wave)/scale
            terms=prediction[1][key+"_orders"][:,idx]
            forecast=terms.sum(axis=0)
            model=err(target-forecast)
            pg=err(forecast-prediction[0][key+"_orders"][:,idx].sum(axis=0))
            tg=err(target-truth[0][key][idx])
            fr=err(forecast-prediction[1][site+"_32_orders"][:,idx].sum(axis=0))
            tr=err(target-truth[1][site+"_32"][idx])
            st=err(forecast-prediction[1][key+"_narrow"][:,idx].sum(axis=0))
            total=model+pg+tg+fr+tr+st
            row=dict(eta=.8,prep="M",link=site,channel=channel,new_location=site=="middle",
                     full_peak=target[peak],peak_emit=EMISSIONS[peak],predicted_at_peak=forecast[peak],
                     leading_only=err(target-terms[0]),correction_peak_over_signal=err(terms[1]),
                     second_residual=model,pred_grid=pg,target_grid=tg,pred_ray=fr,target_ray=tr,
                     stencil=st,total=total,passes=total<=TOL)
            if site!="middle":
                for kind, bank, series in (("full",truth[0],truth[0][key][idx]),
                                          ("forecast",prediction[0],prediction[0][key+"_orders"][0,idx])):
                    prev=bridge.read(WORK/f"{kind}-M-128-q0.8-tangent.npz")[site+"_response64"][idx]
                    row[kind+"_previous_mesh_replay"]=err(series-prev)
            else:
                row.update(full_previous_mesh_replay="",forecast_previous_mesh_replay="")
            rows.append(row)
    write("second-budget.csv",rows)


if __name__=="__main__":
    guard()
    if sys.argv[1]=="leading":
        first()
    else:
        second()
