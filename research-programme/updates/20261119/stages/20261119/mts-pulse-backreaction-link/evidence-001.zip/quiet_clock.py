from launch_packet import *
from stress_series import rays


def main():
    guard()
    mesh=128
    launch=Launch(mesh,.8)
    solver=Radial(mesh,"tensor",0.,.8,RADIUS)
    picks=launch.picks
    potential=2*launch.quiet*launch.inv
    zero=np.zeros(len(picks))
    field=np.stack(((potential/(1-potential))[picks],zero,zero,zero,(launch.quiet*launch.inv**3)[picks],
                    launch.height[picks],zero,launch.number[picks],zero,launch.charge[picks]))
    count=int(np.ceil(.01*mesh/.42))
    step=.01/count
    masks={name:(solver.x>=loc-.09)&(solver.x<=loc+.59) for name,loc in SITES.items() if name!="middle"}
    strips={name:[] for name in masks}
    for tick in range(450*count+1):
        if tick%count==0:
            for name,mask in masks.items():
                value=field[0,mask]
                ax=np.sqrt(1+value)
                z=np.zeros_like(ax)
                strips[name].append(np.stack((value/(1+ax),field[2,mask]/ax,z,z)))
        if tick%(50*count)==0:
            guard()
        if tick==450*count:
            break
        first=solver.rhs(field)
        second=solver.rhs(field+step*first/2)
        third=solver.rhs(field+step*second/2)
        fourth=solver.rhs(field+step*third)
        field+=step/6*(first+2*second+2*third+fourth)
    arrays={}
    for name,mask in masks.items():
        data={"time":np.arange(451)*.01,name:np.asarray(strips[name]),name+"_x":solver.x[mask]}
        arrays[name+"_base64"]=rays(data,name,64)[0]
    dump("finite-quiet.npz",**arrays)


if __name__=="__main__":
    main()
