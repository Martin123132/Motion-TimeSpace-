from launch_packet import *
from scipy.integrate import solve_ivp
from scipy.interpolate import make_interp_spline


def exact(eta):
    launch = Launch(128, eta)
    mass = launch.ordinary[-1] + launch.charge[-1]**2/(2*RADIUS)
    charge = launch.charge[-1]
    x = np.arange(5.8, 6.71, .015)
    times = np.linspace(0, 3, 151)
    small = 1e-9j
    combined = mass + small
    energy = np.sqrt(1 - 2*combined/x + charge**2/x**2)
    def force(time, vec):
        pos, vel, jac, deriv = vec.reshape(4,-1)
        return np.stack((vel,-combined/pos**2+charge**2/pos**3,deriv,(2*combined/pos**3-3*charge**2/pos**4)*jac)).ravel()
    init = np.stack((x,0*x,1+0*x,0*x)).astype(complex)
    orbit = solve_ivp(force,(0.,3.),init.ravel(),t_eval=times,method="DOP853",rtol=2e-13,atol=2e-21,max_step=.04)
    assert orbit.success
    _, _, jac, speed = orbit.y.reshape(4,len(x),len(times)).transpose(0,2,1)
    length = jac/energy
    dot = speed/energy
    strip = Strip(dict(time=times,space=x,bank=np.stack((length.real-1,dot.real,length.imag/small.imag),axis=1)),1)
    emit = np.linspace(0.,1.72,173)
    def leg(start, direction):
        def kernel(offset, delta):
            clock = start+offset+delta[0]
            xx = np.full_like(start, (6 if direction>0 else 6.5) + direction*offset)
            rate = strip.get(1,clock,xx)
            return np.stack((strip.get(0,clock,xx), strip.get(2,clock,xx)+rate*delta[1],rate))
        travel, dtravel, logjac = march(kernel,3,.5,64,len(start))
        return travel, dtravel, np.exp(logjac)
    first, dfirst, jac1 = leg(emit,1)
    back, dback, jac2 = leg(emit+.5+first,-1)
    change = (dfirst, dback+jac2*dfirst)
    observed = [-make_interp_spline(emit,d,k=5).derivative()(emit)/j**2 for d,j in zip(change,(jac1,jac2*jac1))]
    return np.stack((*observed,*change))[:,:171:2], launch


def main():
    import csv
    guard()
    rows = []
    for eta in (.8,1.):
        unit, launch = exact(eta)
        for prep in ("N","M"):
            streams = {}
            for kind in ("forecast","full"):
                with np.load(WORK/f"{kind}-{prep}-128-q{eta:g}-tangent.npz") as archive:
                    streams[kind] = archive["outer_response64"]
                    shift = float(archive["launch"][2].real)
                    for idx, channel in enumerate(("out","echo","out_delay","echo_delay")):
                        wave = streams[kind][idx,:86]
                        analytic = shift*unit[idx]
                        reference = max(abs(analytic))
                        error = max(abs(wave-analytic))
                        scale = max(abs(streams[kind][idx]))
                        rows.append(dict(eta=eta,prep=prep,method=kind,channel=channel,delta_enclosed_mass=shift,
                                         early_peak=max(abs(wave)),late_and_early_peak=scale,external_prediction_peak=reference,
                                         residual=error,relative_to_early_RN=error/reference if prep=="N" else "",
                                         residual_over_total_channel=error/scale))
    with (WORK/"exterior-control.csv").open("x",newline="") as stream:
        writer=csv.DictWriter(stream,fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


if __name__=="__main__":
    main()
