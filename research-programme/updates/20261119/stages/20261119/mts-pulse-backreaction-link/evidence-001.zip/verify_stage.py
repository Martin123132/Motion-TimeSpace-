from launch_packet import *
from score_link import CHANNELS
import csv
from collections import Counter

FREEZES={"frozen.json":"baf73ec4a64401b915d62c90d9b2de5f699bc8419949a6b1cda8e88b481aaad8",
         "second-frozen.json":"4e9645e66146a95d95a4afd87204c1be827889754d141b97dc61a3ea170b7bd5"}


def verify():
    guard()
    assert __debug__
    assert not any(f.is_dir() or f.name.endswith(".partial") for f in WORK.iterdir())
    prev=json.loads((PRE/"seal.json").read_text())
    assert len(prev["files"])==174 and all(bridge.sha(PRE/name)==value for name,value in prev["files"].items())
    for name,value in FREEZES.items():
        assert bridge.sha(WORK/name)==value
        record=json.loads((WORK/name).read_text())
        assert all(bridge.sha(WORK/member)==checksum for member,checksum in record.items())
    tables={}
    for path in WORK.glob("*.csv"):
        with path.open(newline="",encoding="utf-8") as stream:
            rows=list(csv.DictReader(stream))
        assert rows and all(None not in row and None not in row.values() for row in rows),path
        tables[path.name]=rows
    for path in WORK.glob("*.npz"):
        with np.load(path,allow_pickle=False) as archive:
            for key in archive.files:
                assert np.isfinite(archive[key]).all(), (path.name,key)
    expected={f"{kind}-{prep}-{mesh}-q{eta:g}-tangent.npz"
              for kind in ("full","forecast") for prep in ("N","M") for eta in (.8,1.) for mesh in (64,128)}
    expected.update(f"full-{prep}-128-q0.8-{inc}.npz" for prep in ("N","M") for inc in ("plus","minus","halfplus","halfminus"))
    expected.update(f"aux-{mesh}-{weight:g}.npz" for weight in (-.25,-.125,.125,.25) for mesh in (128,256))
    expected.update(f"{name}-{mesh}.npz" for name in ("new-target","second-order") for mesh in (128,256))
    assert {f.name for f in WORK.glob("*.npz")}==expected|{"finite-quiet.npz"}
    led=tables["leading-budget.csv"]
    assert len(led)==len({(r["eta"],r["prep"],r["link"],r["channel"]) for r in led})==32
    for r in led:
        total=sum(float(r[c]) for c in ("model","forecast_grid","target_grid","forecast_ray","target_ray"))
        assert np.isclose(total,float(r["total"]),rtol=1e-13,atol=0)
        assert (r["passes"]=="True")==(total<=TOL)==(r["link"]=="inner")
    for name in ("real-controls.csv","exterior-control.csv","finite-early-clock.csv"):
        assert len(tables[name])== (16 if name=="real-controls.csv" else 32)
    assert all((r["passes"]=="True")==(float(r["complex_vs_signed"])+float(r["extrapolation_shift"])<=TOL)
               for r in tables["real-controls.csv"])
    for mesh in (128,256):
        aux={z:bridge.read(WORK/f"aux-{mesh}-{z:g}.npz") for z in (.25,-.25,.125,-.125)}
        forecast=bridge.read(WORK/f"second-order-{mesh}.npz")
        for site in ("inner","middle","outer"):
            for panels in (32,64):
                key=f"{site}_{panels}"
                diff=lambda z: np.stack(((aux[z][key]-aux[-z][key])/(2*z),(aux[z][key]+aux[-z][key])/(2*z**2)))
                np.testing.assert_array_equal(forecast[key+"_orders"],(4*diff(.125)-diff(.25))/3)
        assert all(np.array_equal(item["emission"],EMISSIONS) for item in aux.values())
    target=[bridge.read(WORK/f"new-target-{mesh}.npz") for mesh in (128,256)]
    forecast=[bridge.read(WORK/f"second-order-{mesh}.npz") for mesh in (128,256)]
    final=tables["second-budget.csv"]
    assert len(final)==len({(r["link"],r["channel"]) for r in final})==12
    for r in final:
        site=r["link"]
        channel=CHANNELS.index(r["channel"])
        key=site+"_64"
        fine=target[1][key][channel]
        scale=max(abs(fine))
        terms=forecast[1][key+"_orders"][:,channel]
        wave=terms.sum(axis=0)
        peak=int(np.argmax(abs(fine)))
        assert EMISSIONS[peak]==float(r["peak_emit"])
        assert bool(r["new_location"]=="True")==bool(site=="middle")
        np.testing.assert_allclose([fine[peak],wave[peak]],[float(r["full_peak"]),float(r["predicted_at_peak"])],atol=0)
        residuals=(fine-wave,wave-forecast[0][key+"_orders"][:,channel].sum(axis=0),fine-target[0][key][channel],
                   wave-forecast[1][site+"_32_orders"][:,channel].sum(axis=0),fine-target[1][site+"_32"][channel],
                   wave-forecast[1][key+"_narrow"][:,channel].sum(axis=0))
        errors=[max(abs(v))/scale for v in residuals]
        cols=("second_residual","pred_grid","target_grid","pred_ray","target_ray","stencil","total")
        np.testing.assert_allclose([*errors,sum(errors)],[float(r[c]) for c in cols],rtol=1e-12,atol=0)
        assert (r["passes"]=="True")==(sum(errors)<=TOL)
    for mesh,count in ((128,216),(256,108)):
        rows=tables[f"constraints-{mesh}.csv"]
        assert len(rows)==count and len({(r["mode"],r["region"],r["identity"],r["component"],r["time"]) for r in rows})==count
        if mesh==128:
            assert all(float(r["absolute"])==0 for r in rows if r["mode"]=="ordinary" and r["component"]=="seed")
    masses=tables["mass-order.csv"]
    assert abs(float(masses[0]["second_observed"])/float(masses[0]["net_second_at_12"])-1)<1e-10
    assert abs(float(masses[1]["compensation_observed"])/float(masses[1]["compensation_quadratic"])-1)<1e-7
    assert all(float(r["absolute"])==0 if r["prep"]=="M" else float(r["relative"])<=TOL for r in tables["finite-early-clock.csv"])
    assert all((WORK/name).stat().st_size>200 for name in ("RESULTS.md","DERIVATION.md","REPLAY.md","PROTOCOL.md","SECOND-ORDER.md"))
    dest=WORK/"seal.json"
    record=dict(parent=LOCK,parent_files=len(prev["files"]),freezes=FREEZES,rows={k:len(v) for k,v in tables.items()},
                files={f.name:bridge.sha(f) for f in sorted(WORK.iterdir()) if f!=dest})
    if dest.exists():
        assert json.loads(dest.read_text())==record
    else:
        with dest.open("x") as stream:
            json.dump(record,stream,indent=2,sort_keys=True)
    print("verified",len(record["files"]),"files",sum(record["rows"].values()),"rows",bridge.sha(dest))


if __name__=="__main__":
    verify()
