from launch_packet import *
import importlib.util
from score_link import CHANNELS,write

reference_spec=importlib.util.spec_from_file_location("pulse_exterior_control",WORK/"exterior.py")
reference_module=importlib.util.module_from_spec(reference_spec)
reference_spec.loader.exec_module(reference_module)
exact=reference_module.exact


def coefficients(spec, prep):
    scalar=spec.pulse+(spec.match*spec.shell if prep=="M" else 0.)
    first=spec.tangent(scalar,False)
    fac=1-2*spec.quiet*spec.inv
    radius=spec.radius
    weight=radius*(spec.number/np.sqrt(fac)+spec.slope**2)
    drive=radius**2*(fac*scalar[1]**2+scalar[0]**2)/2
    drive-=2*radius*first*spec.slope*scalar[1]+spec.number*first**2/(2*fac**1.5)
    second=kernel(radius,weight,drive)
    return first,second


def main():
    guard()
    mesh=128
    unit,spec=exact(.8)
    labels=("plus","minus","halfplus","halfminus")
    rows=[]
    null=[]
    for prep in ("N","M"):
        first,second=coefficients(spec,prep)
        data=[bridge.read(WORK/f"full-{prep}-{mesh}-q0.8-{label}.npz") for label in labels]
        mass_even=[(data[i]["launch"][2]-data[i+1]["launch"][2])/(2*data[i]["amplitude"]) for i in (0,2)]
        coeff_even=[(data[i]["launch"][0]-data[i+1]["launch"][0])/(2*data[i]["amplitude"]) for i in (0,2)]
        nominal_second=second[-1] if prep=="N" else 0.
        match_curve=-second[spec.index]/spec.shell_m if prep=="M" else 0.
        rows.append(dict(prep=prep,first_at_12=first[-1],second_unprojected_at_12=second[-1],
                         net_second_at_12=nominal_second,second_observed=(4*mass_even[1]-mass_even[0])/3,
                         crossover_seed=abs(first[-1]/second[-1]) if prep=="N" else "",
                         compensation_linear=(0. if prep=="N" else spec.match),compensation_quadratic=match_curve,
                         compensation_observed=(4*coeff_even[1]-coeff_even[0])/3))
        quiet=bridge.read(WORK/"finite-quiet.npz")
        for bank in data:
            amp=float(bank["amplitude"])
            dm=amp*first[-1]+amp**2*nominal_second if prep=="N" else 0.
            for idx,channel in enumerate(CHANNELS):
                signal=bank["outer_base64"][idx,:86]-quiet["outer_base64"][idx,:86]
                predicted=unit[idx]*dm
                abs_error=max(abs(signal-predicted))
                scalar=max(abs(predicted))
                null.append(dict(prep=prep,amplitude=amp,channel=channel,mass_forecast=dm,
                                 mass_actual=amp*bank["launch"][2],peak_actual=signal[np.argmax(abs(signal))],
                                 peak_predicted=predicted[np.argmax(abs(predicted))],absolute=abs_error,
                                 relative=abs_error/scalar if prep=="N" else ""))
    write("mass-order.csv", rows)
    write("finite-early-clock.csv",null)


if __name__=="__main__":
    main()
