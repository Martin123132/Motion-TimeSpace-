from launch_packet import *
from score_link import write


def window(space, lo, hi):
    u=(space-lo)/(hi-lo)
    core=4*u*(1-u)
    win=np.where((u>0)&(u<1),core**8,0.)
    der=np.where((u>0)&(u<1),32*core**7*(1-2*u)/(hi-lo),0.)
    return win,der


def inspect(mesh, mode):
    check=Launch(mesh,.8)
    solver=Radial(mesh,"tensor",0.,.8,RADIUS)
    if mode=="M":
        field,_=check.data("full","M",1j*STEP)
    else:
        pick=check.picks
        mass=check.ordinary
        fac=1-2*mass*check.inv
        zero=np.zeros(len(pick),dtype=complex)
        field=np.stack(((2*mass*check.inv/fac)[pick],zero,zero,zero,(mass*check.inv**3)[pick],
                        1j*STEP*check.pulse[0,pick],zero,check.number[pick],zero,check.charge[pick]))
    time_step=.01/int(np.ceil(.01*mesh/.42))
    panels=round(4.5/time_step)
    keep={round(t/time_step) for t in (0,.4,.8,1.7,3.2,4.5)}
    x=solver.x
    regions={name:window(x,*limits) for name,limits in (("core",(.1,2.7)),("edge",(2.5,4.75)),("outside",(5.6,6.9)))}
    rows=[]
    for tick in range(panels+1):
        if tick in keep:
            guard()
            radial, angular, krad, kang, mass3, height, normal, number, impulse, charge=field
            aa,cc=1+radial,1+angular
            length,root=np.sqrt(aa),np.sqrt(cc)
            radius=x*root
            slope=solver.diff(height,solver.d1)/length
            speed=impulse/length
            proper_number=number/(length*cc)
            electric=charge/radius**2
            energy=(normal**2+slope**2+height**2+electric**2)/2+proper_number*np.sqrt(1+speed**2)
            current=proper_number*speed-normal*slope
            dang=solver.diff(angular,solver.d1)
            rx=root+x*dang/(2*root)
            u=-x*kang/root
            mass=x**3*mass3
            reconstructed=radius/2*(u**2+(radial-angular-x*dang-(x*dang/(2*root))**2)/aa)
            for region,(win,der) in regions.items():
                for name,left,right in (
                    ("Hamiltonian",-der*mass,win*radius**2*(energy*rx+length*current*u)),
                    ("Gauss",-der*charge,win*.8*x**2*number),
                    ("geometric_mass",win*mass,win*reconstructed)):
                    for component in ("background","seed"):
                        if component=="seed":
                            first,second=left.imag/STEP,right.imag/STEP
                        else:
                            first,second=left.real,right.real
                        rows.append(dict(mode=mode,mesh=mesh,region=region,time=tick*time_step,identity=name,
                                         component=component,absolute=abs(np.sum(first-second))/mesh,
                                         reference=np.sum(abs(first)+abs(second))/mesh))
            if mode=="ordinary":
                assert np.max(abs(field[[0,1,2,3,4,7,8,9]].imag))==0.
        if tick==panels:
            break
        first=solver.rhs(field)
        second=solver.rhs(field+time_step*first/2)
        third=solver.rhs(field+time_step*second/2)
        fourth=solver.rhs(field+time_step*third)
        field+=time_step/6*(first+2*second+2*third+fourth)
    return rows


if __name__=="__main__":
    guard()
    mesh=int(sys.argv[1])
    rows=inspect(mesh,"M")
    if mesh==128:
        rows+=inspect(mesh,"ordinary")
    write(f"constraints-{mesh}.csv",rows)
