from pulse_io import HERE,OLD,guard,table,metadata,save
from pulse_space import Background,np,sp,splu
import io
import sys

SETTINGS={"pilot":(6,5,.8,30.),"base":(8,6,1.,30.),"fine":(10,7,1.25,30.),
          "angular":(14,7,1.25,30.),"radial":(14,8,1.6,30.),"far":(14,8,1.6,40.),
          "edge":(10,7,1.25,40.),"midang":(12,7,1.25,30.),"radcheck":(10,8,1.6,30.),
          "upper":(18,7,1.25,30.)}

def dot(left,right):return np.vdot(left,right)
def envelope(time,period,on):
    if time<=0 or time>=period or not on:return 0.,0.
    angle=time*np.pi/period
    return np.sin(angle)**4,4*np.sin(angle)**3*np.cos(angle)*np.pi/period
class Step:
    def __init__(self,bg,step,omega):
        size=bg.hm.shape[0];identity=sp.eye(size,format="csc");half=step/2
        self.wave=splu(sp.bmat([[identity+1j*half*(bg.hm-omega*identity),None,1j*half*bg.bm],
            [None,identity-1j*half*(bg.hm+omega*identity),-1j*half*bg.bm],[bg.bm.T,bg.bm.T,bg.lm]],format="csc"))
        self.mean=splu(sp.bmat([[identity,-half*bg.hzero,None],[half*bg.hzero,identity,half*bg.coupling],
                    [2*bg.coupling.T,None,bg.grav]],format="csc"))
        self.size=size;self.zeros=np.zeros(bg.lm.shape[0]);self.half=half
    def advance(self,bg,state,time,period,on):
        half=self.half;size=self.size;plus,minus,real,imag=state
        amp,rate=envelope(time+half,period,on)
        vectors=self.wave.solve(np.r_[plus-1j*half*amp*bg.force,minus+1j*half*amp*bg.force,self.zeros])
        ap,am,gravity=np.split(vectors,[size,2*size]);density,internal,external=bg.components(ap,am,gravity)
        source=amp*external+internal
        mean=self.mean.solve(np.r_[real+half*source.imag,imag-half*source.real,-density,np.zeros(bg.count)])
        xr,xi=mean[:size],mean[size:2*size]
        drive=dot(ap+am,bg.force);torque=2*amp*drive.imag;power=2*rate*drive.real
        return [2*ap-plus,2*am-minus,2*xr-real,2*xi-imag],2*half*np.array([torque,power])
def run(level,case,steps,mode,on=True):
    guard();cfg=SETTINGS[level];bg=Background(case,*cfg,mode)
    pattern=33.29*bg.length/bg.vel;period=2*np.pi/pattern;omega=mode*pattern;tunit=bg.length/bg.vel*.9777922216807892
    step=period/steps
    weights=(1/(2-2**(1/3)),1-2/(2-2**(1/3)))
    stages=[Step(bg,step*weight,omega) for weight in weights]
    n=bg.hm.shape[0];state=[np.zeros(n,dtype=kind) for kind in (complex,complex,float,float)]
    integrated=np.zeros(2);history=[];force_rows=[];budget_rows=[];packets={}
    assert steps%4==0
    for tick in range(2*steps+1):
        time=tick*step
        if tick%(steps//4)==0:
            ap,am,real,imag=state
            source=bg.bm.T@(ap+am)
            pot=-(bg.mlu.solve(source.real)+1j*bg.mlu.solve(source.imag))
            density,unused,unused_ext=bg.components(ap,am,pot)
            deformation=(2*bg.coupling.T@real)[:n]
            vv=dot(ap,ap).real+dot(am,am).real;gterm=2*dot(bg.ground.ravel(),real).real
            delta=dot(ap,ap).real-dot(am,am).real
            amplitude,_=envelope(time,period,on)
            ewave=(dot(ap,bg.hm@ap)+dot(am,bg.hm@am)).real
            internal=dot(source,pot).real;external=2*amplitude*dot(ap+am,bg.force).real
            energy=ewave+internal+external
            row=dict(turn=tick/steps,time_myr=time*tunit*1000,side_number=vv,mean_number=gterm,total_number=vv+gterm,
                     angular_per_m=delta,integrated_torque_per_m=integrated[0],inertial_energy=energy,
                     integrated_inertial_work=integrated[1]+omega*integrated[0],amplitude_work=integrated[1],
                     rotating_energy=energy-omega*delta,wave_energy=ewave,grav_energy=internal,drive_energy=external)
            shaped=abs(ap.reshape(bg.hshape))**2+abs(am.reshape(bg.hshape))**2
            row["side_number_outer_20L"]=float(shaped[bg.rad>20.].sum())
            row["side_number_outer_27L"]=float(shaped[bg.rad>27.].sum())
            history.append(row)
            forces=bg.sky_forces(density);ground=bg.sky_forces(deformation);net=bg.sky_forces(density+deformation)
            full=bg.field(density+deformation)[:-bg.count].reshape(bg.hshape)/bg.sqrt[:,None]
            for idx,(cyl,at) in enumerate(zip((6.,8.3),bg.mesh.probes)):
                from bar_field import slope
                from feasibility import UNIT
                mu=1.5/np.hypot(cyl,1.5);sine=np.sqrt(1-mu**2)
                inode=int(np.argmin(abs(bg.rad-at)));assert abs(bg.rad[inode]-at)<1e-12
                galerkin=full[inode]@np.array([slope(order,0,mu) for order in bg.orders])*sine/at**2*bg.vel**2/bg.length*UNIT
                force_rows.append(dict(turn=tick/steps,R=cyl,side_polar=forces[idx,0],ground_polar=ground[idx,0],
                    mean_polar=net[idx,0],side_radial=forces[idx,1],ground_radial=ground[idx,1],
                    mean_radial=net[idx,1],mean_radial_monopole=net[idx,2],galerkin_polar=galerkin))
            if tick in (steps,2*steps):
                for key,arr in zip(("plus","minus_conjugate","mean_real","mean_imag"),state):packets[key+"_turn"+str(tick//steps)]=arr.copy()
        if tick==2*steps:break
        for which in (0,1,0):
            st=stages[which];state,change=st.advance(bg,state,time,period,on)
            time+=2*st.half;integrated+=change
        if tick%16==0:guard()
    tag=f"{level}-{case}-m{mode}-n{steps}"+("" if on else "-no-drive")
    scale=max([row["side_number"] for row in history]+[1e-60]);escale=max([abs(row["wave_energy"])+abs(row["grav_energy"])+abs(row["drive_energy"]) for row in history]+[1e-60])
    fscale=max([abs(row["side_polar"])+abs(row["ground_polar"]) for row in force_rows]+[1e-60])
    info=dict(**bg.defect,steps_per_turn=steps,mode=mode,domain_L=cfg[-1],case=case,pattern_kms_kpc=33.29,turn_myr=period*tunit*1000,
        peak_side_fraction=scale/bg.mass if on else 0.,
        norm_defect_over_peak_side=max(abs(row["total_number"]) for row in history)/scale,
        torque_defect_over_peak_side=max(abs(row["angular_per_m"]-row["integrated_torque_per_m"]) for row in history)/scale,
        work_defect_over_peak_energy=max(abs(row["inertial_energy"]-row["integrated_inertial_work"]) for row in history)/escale,
        direct_green_defect_over_peak_polar_components=max(abs(row["mean_polar"]-row["galerkin_polar"]) for row in force_rows)/fscale)
    if not on:assert all(row[key]==0. for row in history for key in ("side_number","mean_number","inertial_energy")) and all(row["mean_polar"]==row["mean_radial"]==0. for row in force_rows)
    table(tag+"-history.csv",history);table(tag+"-forces.csv",force_rows);metadata(tag+"-checks.json",info)
    buffer=io.BytesIO();np.savez_compressed(buffer,rad=bg.rad,radial_weight=bg.mesh.weight,ground=bg.ground,orders_mean=bg.orders,orders_wave=bg.morders,**packets)
    save(tag+"-state.npz",buffer.getvalue())
    print(tag,info,"late inner mean",force_rows[-2]["mean_polar"],flush=True)
if __name__=="__main__":run(sys.argv[1],sys.argv[2],int(sys.argv[3]),int(sys.argv[4]),"zero" not in sys.argv[5:])

