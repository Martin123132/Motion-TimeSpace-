from pulse_io import HERE,read,table,guard
import numpy as np

def run():
    guard();rows=[]
    for tag in ("fine-reference-m2-n256","upper-added-free2-plus-m2-n256"):
        row=read(HERE/(tag+"-external-response.csv"))[0]
        tidal=float(row["overlap_per_unit_planar_tidal_tensor"])
        with np.load(HERE/(tag+"-external-kernel.npz")) as data:
            weights=data["source_overlap_weights"];radius=data["radius_kpc"][:,None]
            planar=radius*np.sqrt(1-data["mu"]**2)
            for distance in (25.,50.,100.,200.,500.):
                smoothing=5.;s0=np.hypot(distance,smoothing);gm=s0**5/distance**2
                values=[]
                for order in (48,96):
                    result=0.
                    for phase in np.pi*(np.arange(order)+.5)/order:
                        dot=distance*planar*np.cos(phase);a=radius**2-2*dot
                        sep=np.sqrt(s0**2+a)
                        rest=gm*(a/(sep*s0*(sep+s0))+dot/s0**3)
                        result+=np.sum(weights*rest)*np.cos(2*phase)/order
                    values.append(result)
                rows.append(dict(tag=tag,distance_kpc=distance,plummer_kpc=smoothing,tidal_difference=-3.,
                    unit_tide_prediction=-3*tidal,full_spatial_overlap=values[-1],fractional_difference_from_tide=values[-1]/(-3*tidal)-1,
                    azimuthal_refinement=abs(values[0]/values[-1]-1)))
    table("external-kernel-finite-source-test.csv",rows)
    assert max(row["azimuthal_refinement"] for row in rows)<2e-5
    for tag in sorted({row["tag"] for row in rows}):
        group=[row for row in rows if row["tag"]==tag]
        assert abs(group[-1]["fractional_difference_from_tide"])<.002 and abs(group[-1]["fractional_difference_from_tide"])<abs(group[0]["fractional_difference_from_tide"])
    print(rows[:5])
if __name__=="__main__":run()

