from pulse_io import HERE,OLD,PIN,guard,read,table,metadata,sha
import json
import sys

def main():
    guard()
    prior=json.loads((OLD/"seal.json").read_bytes())["files"]
    assert len(prior)==294 and all(sha(OLD/key)==value for key,value in prior.items())
    for path in HERE.glob("*.py"):compile(path.read_bytes(),str(path),"exec")
    for path in HERE.glob("*.csv"):
        rows=read(path);assert rows and all(None not in row and None not in row.values() for row in rows),path.name
    for path in HERE.glob("*-state.npz"):
        tag=path.name.replace("-state.npz","");assert len(read(HERE/(tag+"-history.csv")))==9 and len(read(HERE/(tag+"-forces.csv")))==18
    assert all((HERE/name).is_file() for name in ("PROTOCOL.md","SPECTRAL-TEST.md","COLLECTIVE-TEST.md","DERIVATION.md","RESULTS.md",
                "NEXT.md","REPLAY.md","post-pulse-coherent-probes.csv","pulse-sky-comparison.csv","frozen-next-duration-prediction.csv"))
    decision=json.loads((HERE/"pulse-verification.json").read_bytes())
    target=decision["original_relative_threshold"]
    assert target==2e-5 and not decision["primary_failed_rows"]
    for case in ("reference","added-free2-plus"):
        checks=decision["mathematical_checks"]["upper-"+case+"-m2-n256-checks.json"]
        assert max(checks.values())<target
    checks=decision["mathematical_checks"]["base-reference-m2-n16-no-drive-checks.json"]
    assert max(checks.values())==0
    for path in HERE.glob("*nonlinear-phase-control.csv"):
        assert max(float(row["relative_norm_error"]) for row in read(path))<target
    prefix="fine-reference-m2-n256"
    first=read(HERE/(prefix+"-collective-predictions.csv"));assert len(first)==6
    test=read(HERE/(prefix+"-two-turn-challenge-1024.csv"))[0]
    assert test["prior_prediction_sha256"]==sha(HERE/(prefix+"-collective-predictions.csv"))
    assert max(float(test[key]) for key in ("relative_action_error","max_complex_error_over_strongest"))<target
    assert all(float(row["max_complex_error_over_strongest"])<target for row in read(HERE/(prefix+"-collective-time-test.csv")))
    fine=read(HERE/"fine-collective-window-ceilings.csv");refined=read(HERE/"radcheck-collective-window-ceilings.csv")
    changes=[]
    for a,b in zip(fine,refined,strict=True):
        assert all(a[key]==b[key] for key in ("case","speed","turns"))
        changes.append(abs(float(a["closed_action_fraction_upper"])/float(b["closed_action_fraction_upper"])-1))
    assert len(changes)==36
    ids=read(HERE/"radcheck-collective-window-mode-ceilings.csv")
    assert len(ids)==576 and min(float(row["positive_frequency_floor"]) for row in ids)>0
    assert all(float(row["schur_pivot_min"])>0 and float(row["shifted_h_pivot_min"])>0 and float(row["backward_error"])<1e-10 for row in ids)
    relative=read(HERE/"radcheck-relative-stability-modes.csv")
    assert len(relative)==576 and all(float(row["relative_coercivity"])==.5 and float(row["min_pivot"])>0 and float(row["backward_error"])<1e-10 for row in relative)
    before=read(HERE/"fine-closed-side-mass-ceiling.csv")
    after=read(HERE/"radcheck-closed-side-mass-ceiling.csv")
    assert len(after)==36 and max(abs(float(a["closed_side_mass_msun_upper"])/float(b["closed_side_mass_msun_upper"])-1) for a,b in zip(before,after,strict=True))<target
    narrow=read(HERE/"fine-reference-m2-n512-collective-time-test.csv")
    assert max(max(float(row[k]) for k in ("positive_complex_relative","negative_complex_relative")) for row in narrow)<target
    assert max(float(row["azimuthal_refinement"]) for row in read(HERE/"external-kernel-finite-source-test.csv"))<target
    for tag in ("fine-reference-m2-n256","upper-added-free2-plus-m2-n256"):
        assert (HERE/(tag+"-external-kernel.npz")).is_file() and float(read(HERE/(tag+"-external-response.csv"))[0]["bar_replay_relative"])<target
    obs=read(HERE/"pulse-sky-comparison.csv")
    assert len(obs)==16 and all((row["matches_polar"]=="True")== (float(row["R"])==8.3) and row["matches_radial"]=="False" for row in obs)
    print("prior",len(prior),"histories",len(list(HERE.glob("*-state.npz"))),"upper-bound max grid change",max(changes),"two-turn action error",test["relative_action_error"])
    if sys.argv[1:] in (["seal"],["sealed"]):
        assert not any(path.is_dir() for path in HERE.iterdir())
        files={path.name:sha(path) for path in sorted(HERE.iterdir()) if path.name!="seal.json"}
        if sys.argv[1]=="seal":metadata("seal.json",dict(parent=PIN,files=files))
        assert json.loads((HERE/"seal.json").read_bytes())==dict(parent=PIN,files=files)
        print("verified",len(files),"files; seal",sha(HERE/"seal.json"))
if __name__=="__main__":main()

