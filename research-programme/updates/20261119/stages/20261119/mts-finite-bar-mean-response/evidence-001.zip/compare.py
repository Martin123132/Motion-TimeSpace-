from pulse_io import HERE,OLD,read,table,guard,metadata
import json
import math
def f(row,key):return float(row[key])
def checks(left,right,category):
    rows=[];old=read(HERE/(left+"-forces.csv"));new=read(HERE/(right+"-forces.csv"))
    for radius in (6.,8.3):
        paired=[(a,b) for a,b in zip(old,new) if f(a,"R")==radius]
        for key in ("mean_polar","mean_radial","ground_polar","side_polar","side_radial"):
            scale=max(abs(f(b,key)) for a,b in paired)
            delta=max(abs(f(a,key)-f(b,key)) for a,b in paired)
            rows.append(dict(category=category,left=left,right=right,R=radius,variable=key,peak=scale,max_abs_difference=delta,
                max_difference_over_peak=delta/scale,relative_at_switch_off=abs(f(paired[4][0],key)/f(paired[4][1],key)-1),
                relative_one_turn_later=abs(f(paired[-1][0],key)/f(paired[-1][1],key)-1),passes_on_peak=delta/scale<2e-5))
    return rows
def main():
    guard();rows=[]
    if not (HERE/"post-pulse-coherent-probes.csv").exists():
        print("Combined readout pending; no decision table written.")
        return
    for case in ("reference","added-free2-plus"):
        comparisons=[("fine","angular",128,128,"angular"),("angular","upper",128,128,"angular"),("upper","upper",128,256,"upper time")]
        if case=="reference":comparisons+= [("base","base",64,128,"time"),("fine","fine",128,256,"time"),("fine","fine",256,512,"time"),
                    ("fine","edge",128,128,"outer boundary"),("fine","radcheck",128,128,"radial")]
        for old,new,nold,nnew,kind in comparisons:
            rows+=checks(f"{old}-{case}-m2-n{nold}",f"{new}-{case}-m2-n{nnew}",kind)
        rows+=checks(f"fine-{case}-m4-n128",f"angular-{case}-m4-n128","secondary harmonic angular")
    table("paired-controls.csv",rows)
    sky=read(OLD/"extra-sky.csv");coherent=read(HERE/"post-pulse-coherent-probes.csv");observed=[]
    for case in ("reference","added-free2-plus"):
        for turn in (1,2):
            for radius in (6.,8.3):
                masks=lambda row:f(row,"turn")==turn and f(row,"R")==radius
                parts=[];waves=[];bounds=[]
                for tag in (f"upper-{case}-m2-n256",f"angular-{case}-m4-n128"):
                    component=next(row for row in read(HERE/(tag+"-forces.csv")) if masks(row))
                    first=next(row for row in coherent if masks(row) and row["tag"]==tag)
                    parts.append(component);waves.append(first)
                for model in ("mts","nfw"):
                    bg=next(row for row in sky if row["case"]==case and row["component"]=="azimuthal_mean" and f(row,"R")==radius and row["model"]==model)
                    select=lambda group,key:sum(f(row,key) for row in group) if model=="mts" else 0.
                    mean=select(parts,"mean_polar");wake=select(waves,"measured_polar")
                    total=f(bg,"total_polar")+mean+wake
                    rad=f(bg,"total_radial")+select(parts,"mean_radial")+select(waves,"measured_radial")
                    observed.append(dict(case=case,R=radius,turn=turn,model=model,unperturbed_polar=f(bg,"total_polar"),mean_second_order_polar=mean,
                        intensity=select(parts,"side_polar"),deformation=select(parts,"ground_polar"),coherent_first_order_polar=wake,
                        polar_subtotal=total,polar_upper_over_orientation=f(bg,"total_polar")+mean+select(waves,"polar_phase_cap"),
                        polar_lo=f(bg,"polar_lo"),polar_hi=f(bg,"polar_hi"),missing_to_polar_lo=f(bg,"polar_lo")-total,radial_subtotal=rad,
                        radial_lo=f(bg,"radial_lo"),radial_hi=f(bg,"radial_hi"),mean_second_order_radial=select(parts,"mean_radial"),
                        matches_polar=f(bg,"polar_lo")<=total<=f(bg,"polar_hi"),matches_radial=f(bg,"radial_lo")<=rad<=f(bg,"radial_hi")))
    table("pulse-sky-comparison.csv",observed)
    stats={}
    for path in sorted(HERE.glob("*-checks.json")):
        item=json.loads(path.read_bytes());stats[path.name]={k:item[k] for k in ("norm_defect_over_peak_side","torque_defect_over_peak_side","work_defect_over_peak_energy","direct_green_defect_over_peak_polar_components")}
    qualifying=[row for row in rows if row["variable"] in ("mean_polar","mean_radial") and (row["category"]=="angular" and row["left"].startswith("angular") or row["category"] in ("outer boundary","radial") or (row["category"]=="time" and row["left"].endswith("n256")))]
    info=dict(original_relative_threshold=2e-5,max_primary_paired_peak_change=max(row["max_difference_over_peak"] for row in qualifying),
        primary_failed_rows=[{k:row[k] for k in ("left","right","variable","R","max_difference_over_peak")} for row in qualifying if not row["passes_on_peak"]],
        explicit_coarser_and_component_failures=sum(not row["passes_on_peak"] for row in rows),
        mathematical_checks=stats,observer_interpretation="partial m=2,4 coherent at order one plus their azimuthal mean at order two; not all order-two angular forces")
    metadata("pulse-verification.json",info)
    print({k:v for k,v in info.items() if k not in ("mathematical_checks","observer_interpretation")})
if __name__=="__main__":main()

