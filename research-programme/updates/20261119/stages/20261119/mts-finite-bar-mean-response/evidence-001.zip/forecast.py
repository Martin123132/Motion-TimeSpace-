from pulse_io import HERE,OLD,read,table,guard
from occupation import fourier
import numpy as np
import json

def main():
    guard()
    tag="fine-reference-m2-n256"
    checks=json.loads((HERE/(tag+"-checks.json")).read_bytes())
    lowest=next(row for row in read(HERE/(tag+"-bound-projections.csv")) if row["turn"]=="1" and row["index"]=="1")
    assert lowest["localized"]=="True"
    with np.load(OLD/"extra-reference-mean.npz") as pkt:
        length,vel,base_energy,number=[float(pkt[key]) for key in ("length","vel","energy","mass")]
    mass=float(read(OLD/"extra-mean.csv")[0]["dark_mass"]);omega=33.29*length/vel
    gap=(float(lowest["energy_kms2"])-base_energy-checks["chemical_shift_kms2"])/vel**2
    matrix=float(lowest["drive_matrix_element"])
    results=[]
    for turns in (1,2,3,5,10):
        period=turns*2*np.pi/omega
        probability=matrix**2*(abs(fourier(gap-2*omega,period))**2+abs(fourier(-gap-2*omega,period))**2)/number
        results.append(dict(turns=turns,case="reference",state_index=1,energy_kms2=lowest["energy_kms2"],
                            predicted_frozen_mass_msun=probability*mass,live_prediction="not equated to frozen; test retarded equations"))
    assert abs(results[0]["predicted_frozen_mass_msun"]/float(lowest["analytic_frozen_mass_msun"])-1)<1e-11
    table("frozen-next-duration-prediction.csv",results)
if __name__=="__main__":main()

