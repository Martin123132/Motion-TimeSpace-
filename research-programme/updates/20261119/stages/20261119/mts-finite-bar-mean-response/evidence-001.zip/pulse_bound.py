from pulse_io import HERE,OLD,read,table,guard
from bar_field import Field
from occupation import fourier
import numpy as np

def kernel_bound(minimum,period):
    spacing=2*np.pi/period
    alternatives=[3*period/8,2/minimum]
    if minimum>2*spacing:
        alternatives.append(3*spacing**4/(minimum*(minimum**2-spacing**2)*(minimum**2-4*spacing**2)))
    return min(alternatives)

def main():
    guard();rows=[];summaries=[];shape=Field("extra")
    for case in ("reference","added-free2-plus"):
        parent=next(row for row in read(OLD/"extra-mean.csv") if row["case"]==case)
        with np.load(OLD/(f"extra-{case}-mean.npz")) as pkt:
            rad,mu,length,velocity=[pkt[key] for key in ("rad","mu","length","vel")]
            prob=pkt["weights"][:,None]*pkt["aw"]*pkt["wave"]**2/pkt["mass"]
            for mode in range(2,33,2):
                drive=pkt["drive"] if mode==2 else shape.grid(rad*length,mu,mode)[0]/velocity**2
                strength=np.sum(prob*drive**2);e0=float(pkt["energy"])/velocity**2
                for speed in (31.48,33.29,44.):
                    pattern=speed*length/velocity;omega=mode*pattern
                    for turns in (1,2,3,5,10,20):
                        period=2*np.pi*turns/pattern
                        upper=kernel_bound(omega+e0,period);lower=kernel_bound(omega,period)
                        gaps=np.linspace(0.,-e0,251)
                        sampled=max(np.max(abs(fourier(gaps-omega,period)))/upper,np.max(abs(fourier(gaps+omega,period)))/lower)
                        assert sampled<1+1e-12
                        fraction=strength*(upper**2+lower**2)
                        rows.append(dict(case=case,speed=speed,turns=turns,m=mode,source_strength_normed=strength,
                                         positive_min_detuning=omega+e0,negative_min_detuning=omega,window_fourier_bound_co=upper,
                                         window_fourier_bound_counter=lower,bound_fraction_upper=fraction,
                                         bound_mass_msun_upper=fraction*float(parent["dark_mass"]),sample_to_bound=sampled))
        for speed in (31.48,33.29,44.):
            for turns in (1,2,3,5,10,20):
                group=[row for row in rows if (row["case"],row["speed"],row["turns"])==(case,speed,turns)]
                assert len(group)==16
                summaries.append(dict(case=case,speed=speed,turns=turns,total_bound_fraction_upper=sum(row["bound_fraction_upper"] for row in group),
                                    total_bound_mass_msun_upper=sum(row["bound_mass_msun_upper"] for row in group)))
    table("frozen-window-all-harmonics.csv",rows);table("frozen-window-mass-ceilings.csv",summaries)
if __name__=="__main__":main()

