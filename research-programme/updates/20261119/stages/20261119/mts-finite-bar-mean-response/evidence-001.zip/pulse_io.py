from pathlib import Path
import csv
import io
import hashlib
import json
import os
import sys
for name in ("OMP_NUM_THREADS","OPENBLAS_NUM_THREADS","MKL_NUM_THREADS","NUMEXPR_NUM_THREADS","BLIS_NUM_THREADS"):
    os.environ[name]="1"
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
OLD=HERE.parent/"mts-rotating-bar-wave-drive-20261119"
PIN="b0f8435970a6fff414297b5e324b7d039a4012eb08407147f0d7d97174a6edcd"
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
def guard():
    assert sha(OLD/"seal.json")==PIN
    assert not any((folder/"STOP-REQUESTED").exists() for folder in (HERE,OLD,HERE.parent))
def save(name,raw):
    guard()
    target=HERE/name
    if target.exists():assert target.read_bytes()==raw,name
    else:
        with target.open("xb") as output:output.write(raw)
def table(name,rows):
    buffer=io.StringIO(newline="")
    writer=csv.DictWriter(buffer,list(rows[0]),lineterminator="\n");writer.writeheader();writer.writerows(rows)
    save(name,buffer.getvalue().encode())
def read(path):
    with path.open(encoding="utf8",newline="") as stream:return list(csv.DictReader(stream))
def metadata(name,obj):save(name,(json.dumps(obj,indent=2,sort_keys=True,allow_nan=False)+"\n").encode())
sys.path.insert(0,str(OLD))

