from acquire import HOME,write
import fitz
import csv
import io
import json
import hashlib
import numpy as np

SECTORS=("pooled","m60_m30","m30_m15","m15_0","p0_p15","p15_p30","p30_p60")


def record(name,rows):
    out=io.StringIO(newline="")
    writer=csv.DictWriter(out,fieldnames=list(rows[0]),lineterminator="\n")
    writer.writeheader();writer.writerows(rows);write(name,out.getvalue().encode())


def readout():
    receipt=json.loads((HOME/"source.json").read_bytes());pdf=HOME/receipt["member"]
    assert hashlib.sha256(pdf.read_bytes()).hexdigest()==receipt["figure_sha256"]
    with fitz.open(pdf) as doc:
        page=doc[0];words=page.get_text("words");draw=page.get_drawings()
    frames=[d["rect"] for d in draw if d["type"]=="f" and len(d["items"])==1 and 300<d["rect"].width<350]
    paths=[d for d in draw if len(d["items"])==34 and d["color"][2]>.7]
    assert len(frames)==len(paths)==7
    labels=[word for word in words if word[4] in ("2","4","6","8","10","12","14") and abs(word[1]-896.5)<2]
    assert len(labels)==7
    coords=[];cal=[]
    for sector,frame,path in zip(SECTORS,frames,paths,strict=True):
        ticks=[d["items"][0] for d in draw if d["type"]=="fs" and len(d["items"])==1 and d["items"][0][0]=="l"]
        bottom=sorted(item[1].x for item in ticks if abs(item[1].y-frame.y1)<.001 and item[1].x==item[2].x)
        left=sorted(item[1].y for item in ticks if abs(item[1].x-frame.x0)<.001 and item[1].y==item[2].y and frame.y0<=item[1].y<=frame.y1)
        assert len(bottom)==7 and np.max(abs(np.asarray(bottom)-[(w[0]+w[2])/2 for w in labels]))<.04
        heights=[]
        for tick in left:
            correct=[w for w in words if w[4].startswith("0.") and w[2]<frame.x0 and abs((w[1]+w[3])/2-tick)<.15]
            assert len(correct)==1
            heights.append(float(correct[0][4]))
        assert len(left)>=3
        conv_r=np.polyfit(bottom,[float(w[4]) for w in labels],1);conv_z=np.polyfit(left,heights,1)
        assert max(abs(np.polyval(conv_z,left)-heights))<1e-6 and max(abs(np.polyval(conv_r,bottom)-np.arange(2,15,2)))<1e-6
        cal.append(dict(sector=sector,xslope=conv_r[0],xoffset=conv_r[1],yslope=conv_z[0],yoffset=conv_z[1],n_y=len(left)))
        points=[path["items"][0][1]]+[item[2] for item in path["items"]]
        for index,pt in enumerate(points):
            dots=[d["rect"] for d in draw if d["type"]=="fs" and len(d["items"])==8 and d["color"][2]>.7 and abs((d["rect"].x0+d["rect"].x1)/2-pt.x)<.002 and abs((d["rect"].y0+d["rect"].y1)/2-pt.y)<.002]
            bars=[d["items"][0] for d in draw if d["type"]=="s" and len(d["items"])==1 and d["color"]==path["color"] and abs(d["items"][0][1].x-pt.x)<.002 and min(d["items"][0][1].y,d["items"][0][2].y)<=pt.y<=max(d["items"][0][1].y,d["items"][0][2].y)]
            assert len(dots)==len(bars)==1,(sector,index,len(dots),len(bars))
            radius=float(np.polyval(conv_r,pt.x));height=float(np.polyval(conv_z,pt.y))
            ends=sorted(np.polyval(conv_z,[bars[0][1].y,bars[0][2].y]))
            assert 0<ends[0]<=height<=ends[1] and frame.x0<pt.x<frame.x1
            coords.append(dict(sector=sector,bin=index,R_kpc=radius,h_kpc=height,lo_kpc=ends[0],hi_kpc=ends[1]))
    record("figure17-rings.csv",coords);record("axis-calibration.csv",cal)
    assert len(coords)==245


if __name__=="__main__":readout()
