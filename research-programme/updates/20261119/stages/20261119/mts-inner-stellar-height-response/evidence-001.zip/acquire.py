from pathlib import Path
import hashlib
import io
import json
import tarfile
import urllib.request

HOME=Path(__file__).resolve().parent
URL="https://arxiv.org/src/2604.24456v1"
NAME="thindiskhz_first.pdf"


def write(name,data):
    path=HOME/name
    if path.exists():assert path.read_bytes()==data,name
    else:
        with path.open("xb") as handle:handle.write(data)


if __name__=="__main__":
    with urllib.request.urlopen(URL,timeout=30) as response:data=response.read(4000001)
    assert 0<len(data)<=4000000
    with tarfile.open(fileobj=io.BytesIO(data)) as archive:
        figure=archive.extractfile(NAME).read()
        tex=archive.extractfile("sample701.tex").read()
        assert b"{thindiskhz_first.pdf}" in tex and b"Scale height of the thin disk as a function" in tex
    write(NAME,figure)
    receipt=dict(source=URL,article="https://arxiv.org/html/2604.24456v1#S5.F17",member=NAME,version="v1",
                 archive_sha256=hashlib.sha256(data).hexdigest(),figure_sha256=hashlib.sha256(figure).hexdigest(),
                 figure_bytes=len(figure),method="unmodified named member, original plot of red-clump tracer thin height; not raw counts")
    write("source.json",(json.dumps(receipt,indent=2)+"\n").encode())
