from height import *
from feasibility import UNIT,bands
from segue import acquire

def run():
    obs=acquire();prev=PARENT/"mass-spherical-fine-main-384-32.npz"
    components=data(HOME/"fine-SEGUE-frozen-forces.csv")
    with np.load(prev) as pk,np.load(HOME/"fine-pooled-direct.npz") as changed:
        radii=-pk["locations"][:,0]
        locations_saved=pk["locations"]
        base=pk["base"]+np.column_stack((changed["values"][:,1],np.zeros(len(radii)),changed["values"][:,2]))
        fixed=np.flatnonzero((radii==OUTER)&(locations_saved[:,2]==0.))[0]
    anchor=(SPEED**2/OUTER-base[fixed,0])*OUTER**2/G/1e10
    assert anchor>0
    groups=[];bounds_out=[]
    for radius0 in (8.,SUN):
        data_rows=[]
        for fe,alpha,_,_,_,offset,observed,error in obs:
            cyl=round(radius0-offset,6);rr=np.hypot(cyl,1.1)
            current=next(row for row in components if row["height_source"]=="pooled" and row["mode"]=="matched" and row["model"]=="ground" and float(row["R"])==cyl)
            ordinary=-sum(float(current[name]) for name in ("old_stars","changed_stars","gas","compact"))
            factor=rr**3/(1.1*G*1e10)
            target=(2*np.pi*G*1e6*observed-ordinary)*factor;width=2*np.pi*G*1e6*error*factor
            data_rows.append(dict(source=f"SEGUE {fe:.2f}/{alpha:.3f}",R=cyl,r=rr,lower=target,upper=target,width=width))
        masks=[dict(source="nonnegative mass",R=0.,r=0.,lower=0.,upper=0.,width=0.),
               dict(source="outer anchor",R=OUTER,r=OUTER,lower=anchor,upper=anchor,width=0.)]
        sky=[]
        for cyl,index in ((6.,-4),(8.3,-3)):
            rr=np.hypot(cyl,1.5)
            bar=(-cyl*base[index,0]+1.5*base[index,2])/rr*UNIT
            for side in ("north","south"):
                band=bands()[cyl,"ar",side]
                sky.append(dict(source=f"Gaia radial {cyl} {side}",R=cyl,r=rr,lower=(bar-band[4])*rr**2/(UNIT*G*1e10),upper=(bar-band[3])*rr**2/(UNIT*G*1e10),width=0.))
        bounds_out.extend(dict(R0=radius0,**row) for row in data_rows+masks+sky)
        for title,extra in (("SEGUE+anchor",[]),("SEGUE+anchor+Gaia_radial",sky)):
            records=data_rows+masks+extra
            pairs=[]
            for first in records:
                for second in records:
                    if first["r"]>second["r"]:continue
                    diff=first["lower"]-second["upper"]
                    scale=first["width"]+second["width"]
                    if scale:
                        pairs.append((diff/scale,first,second))
                    else:assert diff<=1e-10,("fixed source conflict",first,second)
            required,first,second=max(pairs,key=lambda entry:entry[0]);required=max(0.,required)
            candidate=lambda rad:max(row["lower"]-required*row["width"] for row in records if row["r"]<=rad)
            assert all(row["lower"]-required*row["width"]-1e-10<=candidate(row["r"])<=row["upper"]+required*row["width"]+1e-10 for row in records)
            groups.append(dict(R0=radius0,test=title,minimum_printed_width_factor=required,at_one=required<=1.,at_two=required<=2.,
                               limiting_lower=first["source"],lower_R=first["R"],limiting_upper=second["source"],upper_R=second["R"],
                               common_mass_1e10_msun=candidate(first["r"]),anchor_mass_1e10_msun=anchor))
    record("spherical-force-requirements.csv",bounds_out);record("spherical-monotonicity-test.csv",groups)
    print(groups[-2:],flush=True)
if __name__=="__main__":run()
