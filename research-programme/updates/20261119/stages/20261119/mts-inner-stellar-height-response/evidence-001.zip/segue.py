from height import *
from gravity import direct,Bulge
from solve import evaluate,gases,branch
from pair import Readout
import io
import tarfile
import urllib.request
import hashlib


def acquire():
    url="https://arxiv.org/src/1309.0809v3"
    if not (HOME/"Bovy-Rix-surf.txt").exists():
        with urllib.request.urlopen(url,timeout=30) as response:raw=response.read(20000001)
        assert len(raw)<20000001
        with tarfile.open(fileobj=io.BytesIO(raw)) as archive:
            record_bytes=archive.extractfile("surf.txt").read()
            tex=archive.extractfile("ms.tex").read()
            assert b"surf.txt" in tex
        write("Bovy-Rix-surf.txt",record_bytes)
        receipt=dict(source=url,member="surf.txt",archive_sha256=hashlib.sha256(raw).hexdigest(),member_sha256=hashlib.sha256(record_bytes).hexdigest(),height_kpc=1.1)
        write("SEGUE-source.json",(json.dumps(receipt,indent=2)+"\n").encode())
    assert sha(HOME/"Bovy-Rix-surf.txt")==json.loads((HOME/"SEGUE-source.json").read_bytes())["member_sha256"]
    obs=np.array([[float(val) for val in line.rstrip().rstrip(chr(92)).split("&")] for line in (HOME/"Bovy-Rix-surf.txt").read_text().splitlines() if "&" in line])
    assert obs.shape==(43,8) and np.max(abs(obs[:,2]+obs[:,5]-8))<.011 and min(obs[:,-1])>0
    assert len(set(zip(obs[:,0],obs[:,1])))==43
    return obs


def run(level):
    obs=acquire();guard()
    radius=np.unique(np.round(np.r_[8.-obs[:,5],SUN-obs[:,5]],6))
    points=np.column_stack((-radius,np.zeros_like(radius),1.1+np.zeros_like(radius)))
    fine=level=="fine";exp=Experiment(level,384 if fine else 256,16 if fine else 12)
    readout=Readout(exp.system,exp.sector,points)
    profile=Map();bulge=Bulge(profile.stars);r=np.linalg.norm(points,axis=1)
    old_stars=np.array([direct(profile.stars,rr,1.1,16 if fine else 10,32 if fine else 20)[2] for rr in radius])-1.1/r*bulge.at(r)[1]
    new_minus_old=np.array([ring(profile,rr,1.1,level)[0,2] for rr in radius])
    gas=sum(np.array([evaluate(component,rr,1.1,18 if fine else 12,330.)[2] for rr in radius]) for component in gases())
    compact=-1.1/r*exp.system.material(r/exp.system.length)[0]*exp.system.vel**2/exp.system.length
    old=old_stars+gas+compact
    oldhalo=exp.halo[exp.run.anchor,0]/exp.run.halo[exp.run.anchor,0]*branch.foreground(points)[2][:,2]
    forecast={};components=[]
    for version in ("old","pooled"):
        base=old+(new_minus_old if version=="pooled" else 0)
        for mode in ("fixed","matched"):
            cases=data(HOME/(level+"-solutions.csv"))
            factor=float(next(row["amplitude_ratio"] for row in cases if row["mode"]==mode and row["profile"]=="pooled" and row["model"]=="nfw"))
            halo=oldhalo*(factor if version=="pooled" else 1.)
            if version=="old":state=exp.state
            else:
                with np.load(HOME/(level+"-pooled-"+mode+"-state.npz")) as saved:state=saved["state"]
            path=PAIR/(exp.tag+"-"+mode+"-8.npz") if version=="old" else HOME/(level+"-pair-"+mode+".npz")
            with np.load(path) as bank:exc=bank["excited"]
            ground=readout.field("ground",state)[:,2];pair=readout.field("excited",exc)[:,2]
            for model,force in (("ground",ground),("pair",pair),("nfw",halo)):
                forecast[version,mode,model]=-(base+force)/(2*np.pi*G*1e6)
                for idx,rr in enumerate(radius):
                    components.append(dict(R=rr,z=1.1,height_source=version,mode=mode,model=model,old_stars=old_stars[idx],changed_stars=base[idx]-old[idx],gas=gas[idx],compact=compact[idx],dark=force[idx],Kforce_equiv=forecast[version,mode,model][idx]))
    record(level+"-SEGUE-frozen-forces.csv",components)
    records=[];scores=[]
    for rzero in (8.,SUN):
        test_r=np.round(rzero-obs[:,5],6);idx=np.searchsorted(radius,test_r)
        assert np.array_equal(radius[idx],test_r)
        for (version,mode,model),values in forecast.items():
            diff=values[idx]-obs[:,6];standard=diff/obs[:,7]
            for num,line in enumerate(obs):
                records.append(dict(R0=rzero,R=test_r[num],height_source=version,mode=mode,model=model,FeH=line[0],alphaFe=line[1],observed=line[6],error=line[7],predicted=values[idx[num]],standardized=standard[num]))
            for group,mask in (("all",np.ones(len(obs),bool)),("inner",SUN-obs[:,5]<6.5),("outer",SUN-obs[:,5]>=6.5)):
                scores.append(dict(R0=rzero,height_source=version,mode=mode,model=model,group=group,n=int(sum(mask)),
                              bias=np.mean(diff[mask]),rms=np.sqrt(np.mean(diff[mask]**2)),std_rms=np.sqrt(np.mean(standard[mask]**2)),within1=int(np.sum(abs(standard[mask])<=1)),
                              observed_mean=np.mean(obs[mask,6]),predicted_mean=np.mean(values[idx[mask]])))
    record(level+"-SEGUE-comparison.csv",records);record(level+"-SEGUE-scores.csv",scores)
    print(level,len(obs),"published populations",len(components),"forecasts incl controls",flush=True)


if __name__=="__main__":run(sys.argv[1])
