from height import *
from scipy.special import lpmv


def angular(mu,degrees):
    return np.stack([np.sqrt((2*deg+1)/(deg*(deg+1)))*lpmv(1,deg,mu) for deg in degrees],axis=-1)


def source(level):
    profile=Map()
    dx,nmu,radorder=(.09,320,7) if level=="medium" else (.05,512,9)
    edges=np.unique(np.r_[np.arange(0.,16.,dx),profile.cuts,[16.,20.,28.,32.]])
    nodes,wr=grid(edges,radorder);rad=nodes.ravel()
    samples,weights=roots_legendre(nmu);mu=(samples+1)/2;weights/=2
    degrees=np.arange(1,64,2);leg=angular(mu,degrees)*weights[:,None]/(2*degrees+1)
    limits=np.deg2rad([-60,-30,-15,0,15,30,60])
    coefs=np.stack((np.diff(np.sin(limits)),-np.diff(np.cos(limits))))*np.sqrt(2)/(2*np.pi)
    moments=np.zeros((2,len(rad),len(degrees)));dipole_mom=[]
    for start in range(0,len(rad),40):
        radius=rad[start:start+40,None];cyl=radius*np.sqrt(1-mu**2);vertical=radius*mu
        hs=profile.heights(cyl)
        hg=hs[4:];h0=hs[0]
        density=profile.column(cyl)*(np.exp(-vertical/hg)/(2*hg)-np.exp(-vertical/h0)/(2*h0))
        components=np.einsum("sb,bkl->skl",coefs,density,optimize=True)
        moments[:,start:start+len(radius)]=components@leg
    for name,vals in zip(("cos","sin"),moments):
        field=Wave(edges,nodes,wr,degrees,vals)
        save(level+"-odd-"+name,r=edges,mode=degrees,phi=field.phi,der=field.der)
    print(level,"m=1 source projected",flush=True)


if __name__=="__main__":source(sys.argv[1])
