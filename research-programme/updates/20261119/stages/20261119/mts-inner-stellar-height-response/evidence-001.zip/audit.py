from collections import Counter, defaultdict
from itertools import groupby
from math import fsum, isclose, isfinite, pi, sqrt
import argparse
from height import CASES, G, HOME, PAIR, PARENT, SECTORS, SPEED, SUN, TOL, data, guard, json, np, record, sha, write


METRICS = ("polar_6", "radial_6", "polar_8.3", "radial_8.3", "outer_speed", "slope", "quasar", "cep11", "giant38")
IDENTITY = ("profile", "model", "mode")


def read(name):
    return data(HOME / name)


def indexed(rows, fields):
    result = {tuple(row[key] for key in fields): row for row in rows}
    assert len(result) == len(rows), fields
    return result


def exact(left, right):
    assert isclose(float(left), float(right), rel_tol=3e-12, abs_tol=1e-11), (left, right)


def inputs():
    guard()
    for folder in (PAIR, PARENT):
        for name, digest in json.loads((folder / "seal.json").read_bytes())["files"].items():
            assert sha(folder / name) == digest, (folder, name)
    for name, digest in (("Bovy-Rix-surf.txt", "e1fb5370e113eca4fb5ac038fbd4e395bd9f30c39f786a4bf25bc03074a5097d"),
                         ("thindiskhz_first.pdf", "155675a97fde6eb9d9d83643e78e80ad97edd9b5fe4f7592c0b956b7a2fc8b75")):
        assert sha(HOME / name) == digest
    rings = read("figure17-rings.csv")
    assert Counter(row["sector"] for row in rings) == dict.fromkeys(SECTORS, 35)
    for sector in SECTORS:
        subset = [row for row in rings if row["sector"] == sector]
        assert [int(row["bin"]) for row in subset] == list(range(35))
        assert min(np.diff([float(row["R_kpc"]) for row in subset])) > 0
        assert all(0 < float(row["lo_kpc"]) <= float(row["h_kpc"]) <= float(row["hi_kpc"]) for row in subset)


def forecasts(level):
    comparison = read(level + "-SEGUE-comparison.csv")
    indexed(comparison, ("R0", "height_source", "mode", "model", "FeH", "alphaFe"))
    source = [tuple(map(float, line.rstrip(chr(92)).split("&"))) for line in
              (HOME / "Bovy-Rix-surf.txt").read_text().splitlines() if "&" in line]
    obs = {(iron, alpha): (offset, value, uncertainty) for iron, alpha, _, _, _, offset, value, uncertainty in source}
    assert len(obs) == len(source) == 43
    components = indexed(read(level + "-SEGUE-frozen-forces.csv"), ("R", "height_source", "mode", "model"))
    groups = defaultdict(list)
    for row in comparison:
        offset, value, uncertainty = obs[float(row["FeH"]), float(row["alphaFe"])]
        exact(row["R"], float(row["R0"]) - offset)
        exact(row["observed"], value)
        exact(row["error"], uncertainty)
        preds = components[tuple(row[field] for field in ("R", "height_source", "mode", "model"))]
        prediction = -fsum(float(preds[key]) for key in ("old_stars", "changed_stars", "gas", "compact", "dark")) / (2*pi*G*1e6)
        exact(prediction, row["predicted"])
        exact(prediction, preds["Kforce_equiv"])
        deviation = prediction - value
        exact(deviation / uncertainty, row["standardized"])
        branch = tuple(row[field] for field in ("R0", "height_source", "mode", "model"))
        for group in ("all", "inner" if SUN-offset < 6.5 else "outer"):
            groups[branch + (group,)].append((value, prediction, deviation, deviation/uncertainty))
    scores = indexed(read(level + "-SEGUE-scores.csv"), ("R0", "height_source", "mode", "model", "group"))
    assert set(scores) == set(groups) and len(scores) == 72 and len(comparison) == 2*2*2*3*43
    for key, values in groups.items():
        sample = scores[key]
        observed, predicted, residual, standardized = np.array(values).T
        assert len(values) == {"all":43, "inner":14, "outer":29}[key[-1]] == int(sample["n"])
        for name, value in (("observed_mean", observed.mean()), ("predicted_mean", predicted.mean()), ("bias", residual.mean()),
                            ("rms", sqrt(np.mean(residual**2))), ("std_rms", sqrt(np.mean(standardized**2))),
                            ("within1", sum(abs(standardized) <= 1))):
            exact(value, sample[name])
    return components


def spherical():
    source = read("spherical-force-requirements.csv")
    for row in read("spherical-monotonicity-test.csv"):
        rows = [line for line in source if line["R0"] == row["R0"] and ("Gaia" in row["test"] or "Gaia" not in line["source"])]
        ordered = sorted(rows, key=lambda line:float(line["r"]))
        def feasible(width):
            floor = 0.
            for _, cluster in groupby(ordered, key=lambda line:float(line["r"])):
                cluster = list(cluster)
                floor = max(floor, *(float(line["lower"]) - width*float(line["width"]) for line in cluster))
                if floor > min(float(line["upper"]) + width*float(line["width"]) for line in cluster):
                    return False
            return True
        lower, upper = 0., 32.
        assert not feasible(lower) and feasible(upper)
        for iteration in range(60):
            trial = (lower + upper)/2
            if feasible(trial):
                upper = trial
            else:
                lower = trial
        exact(upper, row["minimum_printed_width_factor"])


def audit(mode):
    inputs()
    comparisons = []
    def compare(family, identity, key, coarse, fine):
        coarse, fine = float(coarse), float(fine)
        assert isfinite(coarse) and isfinite(fine)
        error = abs(coarse - fine)/max(1., abs(fine))
        comparisons.append(dict(family=family, case="/".join(identity), quantity=key, coarse=coarse, fine=fine,
                                scaled=error, within_original_tolerance=error<TOL))
    for table, count in (("solutions", 20), ("pair-endpoints", 2)):
        by_level = []
        for level in ("medium", "fine"):
            cases = indexed(read(level+"-"+table+".csv"), IDENTITY)
            assert len(cases) == count
            if table == "solutions":
                assert set(cases) == {(case, model, branch) for case in CASES for model in ("ground","nfw") for branch in ("matched","fixed")}
                frozen = indexed(read(level+"-frozen-tangents.csv"), IDENTITY)
                assert set(frozen) == set(cases)
            for identity, row in cases.items():
                assert float(row["normed_residual"]) < 4e-13
                if table == "solutions":
                    for key in METRICS:
                        exact(float(row["change_"+key])-float(frozen[identity][key]), row["nonlinear_"+key])
                else:
                    assert abs(float(row["virial"])) < TOL
                if row["mode"] == "matched":
                    assert abs(float(row["outer_speed"])-SPEED) < 1e-7
                else:
                    exact(row["amplitude_ratio"], 1.)
            by_level.append(cases)
        assert set(by_level[0]) == set(by_level[1])
        for identity, fine in by_level[1].items():
            for key in METRICS:
                compare(table,identity,key,by_level[0][identity][key],fine[key])
    for first, second in zip(read("medium-wedge-direct.csv"), read("fine-wedge-direct.csv"), strict=True):
        assert all(first[key] == second[key] for key in ("R","z"))
        for key in second.keys()-{"R","z"}:
            compare("wedge",(second["R"],second["z"]),key,first[key],second[key])
    for case in CASES:
        with np.load(HOME/("medium-"+case+"-direct.npz")) as low, np.load(HOME/("fine-"+case+"-direct.npz")) as high:
            assert np.array_equal(low["locations"],high["locations"]) and high["values"].shape==(120,3)
            for site,(coarse,fine) in enumerate(zip(low["values"],high["values"],strict=True)):
                for name,first,last in zip(("phi","inward","vertical"),coarse,fine,strict=True):
                    compare("direct rings",(case,str(site)),name,first,last)
        for level in ("medium","fine"):
            for branch in ("fixed","matched"):
                with np.load(HOME/(level+"-"+case+"-"+branch+"-state.npz")) as bank:
                    exact(np.sum(bank["state"]**2)/bank["mass"],1.)
                    assert bank["force"].shape==(120,3) and np.isfinite(bank["force"]).all()
                if case=="pooled":
                    with np.load(HOME/(level+"-pair-"+branch+".npz")) as bank:
                        exact(np.sum(bank["excited"]**2)/bank["mass"],1.)
    moments = read("exterior-moments.csv")
    assert len(moments)==14 and all(abs(float(row["nonzero_rel"]))<TOL and abs(float(row["zero_moment_relative"]))<TOL for row in moments)
    for key, field in (("inward","pooled_in"),("vertical","pooled_z"),("phi","pooled_phi")):
        assert abs(fsum(float(row[key]) for row in read("annular-force-balance.csv"))-float(read("fine-wedge-direct.csv")[0][field])) < 5e-8
    medium, fine = (forecasts(level) for level in ("medium","fine"))
    assert set(medium) == set(fine)
    for identity, row in fine.items():
        compare("SEGUE force",identity,"Kforce_equiv",medium[identity]["Kforce_equiv"],row["Kforce_equiv"])
    fine_tag="fine-384-16"
    first, last = (read(tag+"-collective-spectrum.csv") for tag in ("fine-320-16",fine_tag))
    assert len(first)==len(last)==4
    for rank,(coarse, fine) in enumerate(zip(first,last,strict=True),1):
        assert float(fine["omega_squared"])>0 and float(fine["residual"])<2e-8
        compare("collective period",(str(rank),),"Myr",coarse["period_Myr"],fine["period_Myr"])
    trans=read(fine_tag+"-translation.csv")[0]
    assert abs(float(trans["recovered_shift"])-1)<TOL and float(trans["state_residual"])<TOL
    odd=read(fine_tag+"-odd-response.csv")
    for row in odd:
        with np.load(HOME/(fine_tag+"-"+row["component"]+"-transfer.npz")) as bank:
            exact(-bank["static"]@bank["source"],row["static_compliance"])
        assert float(row["mutual_balance_error"])<TOL and float(row["linear_residual"])<2e-10
    for tag,full in (("medium-96-8","True"), (fine_tag,"False")):
        energy=read(tag+"-energy-gate.csv")[0]
        assert energy["full_matrix"]==full
        assert float(energy["min_Lplus"])>0 and 0<float(energy["represented_source_fraction"])<=1
        assert 0<float(energy["step_energy_per_mass_kms2"])<=float(energy["spatial_norm_ceiling_kms2"])
        exact(float(energy["spatial_norm_ceiling_kms2"])/float(energy["initial_1percent_energy_scale_kms2"]),energy["ceiling_over_one_percent"])
        cert=read(tag+"-positive-floor.csv")[0]
        assert int(cert["dimension"])==(768 if full=="True" else 6144) and cert["positive_shifted_cholesky"]=="True"
        assert float(cert["min_chol_diagonal"])>0 and float(cert["independent_products_relative"])<1e-8
        floor=float(cert["safe_floor"])
        assert .2999 < floor < float(cert["requested_floor"])
        exact(floor,float(cert["requested_floor"])-float(cert["backward_allowance"]))
        exact(float(cert["spatial_ceiling"])*floor,float(energy["spatial_norm_ceiling_kms2"])*float(energy["min_Lplus"]))
        exact(float(cert["spatial_ceiling"])/float(cert["one_percent_scale"]),cert["ceiling_ratio"])
        assert abs(float(cert["projected_energy_estimate"])/float(energy["step_energy_per_mass_kms2"])-1)<2e-9
        turning=read(tag+"-drive-variation.csv")[0]
        scale=float(cert["one_percent_scale"])
        required=sqrt(scale/float(cert["spatial_ceiling"]))
        exact(required,turning["template_arc_required"])
        exact((required-1)/(2*pi),turning["turns_after_single_rise"])
        controls=[row for row in read("rotating-source-controls.csv") if row["tag"]==tag]
        assert [int(row["turns"]) for row in controls]==[0,1,4]
        for row in controls:
            bound=float(cert["spatial_ceiling"])*(1+2*pi*int(row["turns"]))**2
            exact(bound,row["all_mode_variation_ceiling"])
            assert 0<float(row["resolved_four_mode_energy"])<bound
    spherical()
    comparisons.sort(key=lambda row:(row["family"],row["case"],row["quantity"]))
    for family, items in groupby(comparisons,key=lambda row:row["family"]):
        rows=list(items)
        worst=max(rows,key=lambda row:row["scaled"])
        print(family,len(rows),"outside",sum(not row["within_original_tolerance"] for row in rows),"max",worst["scaled"],worst["case"],worst["quantity"])
    assert len(comparisons)==2810 and all(row["within_original_tolerance"] for row in comparisons)
    for path in HOME.glob("*.csv"):
        parsed=data(path)
        assert parsed and all(None not in row and None not in row.values() and all(v.lower() not in ("nan","inf","-inf") for v in row.values()) for row in parsed),path
    if mode != "check":
        record("resolution-audit.csv",comparisons)
        assert all((HOME/name).is_file() for name in ("RESULTS.md","DERIVATION.md","REPLAY.md","NEXT.md"))
        assert all(path.is_file() for path in HOME.iterdir())
        manifest={"parents":{folder.name:sha(folder/"seal.json") for folder in (PARENT,PAIR)},
                  "files":{path.name:sha(path) for path in sorted(HOME.iterdir()) if path.name!="seal.json"}}
        if mode=="seal":
            write("seal.json",(json.dumps(manifest,indent=2,sort_keys=True)+"\n").encode())
        assert json.loads((HOME/"seal.json").read_bytes())==manifest
        print("verified",len(manifest["files"]),sha(HOME/"seal.json"))


if __name__ == "__main__":
    parser=argparse.ArgumentParser()
    parser.add_argument("mode", choices=("check","seal","replay"))
    audit(parser.parse_args().mode)
