import os
import sys
from pathlib import Path
for name in ("OMP_NUM_THREADS","OPENBLAS_NUM_THREADS","MKL_NUM_THREADS","NUMEXPR_NUM_THREADS"):os.environ[name]="1"
sys.dont_write_bytecode=True
HOME=Path(__file__).resolve().parent
PARENT=HOME.parent/"mts-population-resolved-gravity-20261119"
PAIR=HOME.parent/"mts-counterrotating-galactic-response-20261119"
sys.path.insert(0,str(PAIR))
from pair import protected as oldguard,np,sha,Run,StellarPotential,polish,Experiment,Linearization,TOL,OUTER,SPEED
from population import Profiles,HEIGHT
from gravity import grid,axes,Wave,G,SOLAR,roots_legendre,ellipkm1,ellipe,locations
from scipy.interpolate import CubicHermiteSpline
from numpy.polynomial.legendre import legvander
from digitize import record,SECTORS
from acquire import write
import csv
import json

CASES=("pooled","absolute","low","high","meanwedge")
WIDTH=np.array([30,15,15,15,15,30])/360
OLD=HEIGHT[0]
SUN=8.122


def guard():
    oldguard()
    assert not (HOME/"STOP-REQUESTED").exists() and sha(PAIR/"seal.json")=="ae0ec4e79b29704e38e850cade36d295b1afb9dd6219212de87f8f827fe973ef"


def data(path):
    with path.open(newline="",encoding="utf8") as file:return list(csv.DictReader(file))


def save(name,**fields):
    guard()
    path=HOME/(name+".npz")
    if path.exists():
        with np.load(path) as old:assert set(old)==set(fields) and all(np.array_equal(value,old[key]) for key,value in fields.items())
    else:
        with path.open("xb") as handle:np.savez_compressed(handle,**fields)


def smooth(value):
    clip=np.clip(value,0.,1.);return clip**2*(3-2*clip)


class Map:
    def __init__(self):
        guard();self.stars=Profiles();records=data(HOME/"figure17-rings.csv");self.curves=[]
        self.cuts=np.array([3.5,4.5,7.25,SUN])
        for sector in SECTORS:
            rows=[line for line in records if line["sector"]==sector]
            curve=np.array([[float(line[key]) for key in ("R_kpc","h_kpc","lo_kpc","hi_kpc")] for line in rows])
            assert len(curve)==35 and min(np.diff(curve[:,0]))>0
            self.curves.append(curve)
            self.cuts=np.unique(np.r_[self.cuts,curve[:,0],self.stars.knots])
        self.cuts=self.cuts[(self.cuts>=3.5)&(self.cuts<=SUN)]
    def heights(self,radius):
        window=smooth((radius-3.5)/1.)*smooth((SUN-radius)/(SUN-7.25))
        def get(index,column,absolute=False):
            curve=self.curves[index]
            actual=np.interp(radius,curve[:,0],curve[:,column])
            solar=np.interp(SUN,curve[:,0],curve[:,1])
            return OLD+window*((actual if absolute else OLD*actual/solar)-OLD)
        return np.array([get(0,1),get(0,1,True),get(0,2),get(0,3)]+[get(index,1) for index in range(1,7)])
    def column(self,radius):
        return self.stars.radial(radius)[...,0]*self.stars.mix[0,0]
    def densities(self,radius,z):
        heights=self.heights(radius)
        mass=self.column(radius)
        old=np.exp(-abs(z)/OLD)/(2*OLD)
        delta=mass*(np.exp(-abs(z)/heights)/(2*heights)-old)
        return np.concatenate((delta[:4],(delta[0]*(1-sum(WIDTH))+np.einsum("s,s...->...",WIDTH,delta[4:]))[None]),axis=0)


def gravity(level):
    profile=Map()
    dx,nmu,lmax,radorder=(.09,256,64,7) if level=="medium" else (.055,448,80,9)
    edges=np.unique(np.r_[np.arange(0,16,dx),profile.cuts,[16.,20.,28.,32.]])
    nodes,wr=grid(edges,radorder);rad=nodes.ravel()
    samples,weights=roots_legendre(nmu)
    mu=(1+samples)/2;weights/=2
    modes=np.arange(0,lmax+1,2)
    leg=legvander(mu,lmax)[:,::2]*weights[:,None]
    moments=np.zeros((len(CASES),len(rad),len(modes)))
    for pos in range(0,len(rad),40):
        radius=rad[pos:pos+40,None];cyl=radius*np.sqrt(1-mu**2);vertical=radius*mu
        moments[:,pos:pos+len(radius)]=profile.densities(cyl,vertical)@leg
    for name,source in zip(CASES,moments):
        field=Wave(edges,nodes,wr,modes,source)
        save(level+"-"+name+"-potential",r=edges,mode=modes,phi=field.phi,der=field.der,residual_mass=field.mass)
    print(level,"potentials done",flush=True)


def ring(profile,rr,zz,level,interval=(3.5,SUN)):
    order,vertical=(9,16) if level=="medium" else (14,28)
    cuts=np.unique(np.r_[profile.cuts,rr,interval]);cuts=cuts[(cuts>=interval[0])&(cuts<=interval[1])]
    nodes,weights=roots_legendre(order);unit=(nodes+1)/2
    x,w=grid(cuts,order)
    for idx,(left,right) in enumerate(zip(cuts,cuts[1:])):
        if rr in (left,right):
            x[idx]=rr+(1 if left==rr else -1)*(right-left)*unit**3
            w[idx]=1.5*(right-left)*unit**2*weights
    rad=x.ravel();wr=w.ravel()
    zcuts=np.unique(np.r_[-18.,-6.,-2.,-.6,-.15,0.,.15,.6,2.,6.,18.,zz])
    result=np.zeros((10,3));height_all=profile.heights(rad);mass_all=profile.column(rad)
    vz,zw=roots_legendre(vertical)
    for start in range(0,len(rad),36):
        radius=rad[start:start+36,None]
        mass=mass_all[start:start+len(radius),None]
        heights=height_all[:,start:start+len(radius),None]
        diff=abs(rr-radius);bounds=np.arcsinh((zcuts-zz)/diff)
        half=np.diff(bounds,axis=1)/2
        sample=(bounds[:,:-1,None]+half[:,:,None]*(vz+1)).reshape(len(radius),-1)
        dz=diff*np.sinh(sample)
        measure=(half[:,:,None]*zw).reshape(len(radius),-1)*diff*np.cosh(sample)
        small=(rr-radius)**2+dz**2;large=(rr+radius)**2+dz**2
        ellk,elle=ellipkm1(small/large),ellipe(1-small/large)
        fac=2*G*radius*wr[start:start+len(radius),None]*measure*mass/np.sqrt(large)
        kernel=np.stack([-2*fac*ellk,fac/rr*(ellk+((rr-radius)*(rr+radius)-dz**2)/small*elle),2*fac*dz/small*elle])
        zzabs=abs(zz+dz)
        density=np.exp(-zzabs/heights)/(2*heights)-np.exp(-zzabs/OLD)/(2*OLD)
        result+=density.reshape(10,-1)@kernel.reshape(3,-1).T
    return result


def forces(level):
    profile=Map()
    sites=np.vstack((locations(),SOLAR));unique,inverse=np.unique(sites,axis=0,return_inverse=True)
    each=np.array([ring(profile,-pt[0],pt[2],level) for pt in unique])[inverse]
    assert each.shape==(len(sites),10,3)
    for index,name in enumerate(CASES):
        direct=each[:,index] if index<4 else each[:,0]*(1-sum(WIDTH))+np.einsum("s,nsk->nk",WIDTH,each[:,4:])
        save(level+"-"+name+"-direct",locations=sites,values=direct)
    save(level+"-sector-rings",locations=sites,results=each)
    print(level,"rings done",flush=True)


if __name__=="__main__":
    gravity(sys.argv[1]);forces(sys.argv[1])
