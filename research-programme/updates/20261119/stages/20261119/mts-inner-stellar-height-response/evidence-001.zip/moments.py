from height import *
from odd_source import angular

def run():
    profile=Map()
    edges=np.array([3.5,4.5,5.5,6.,6.5,7.25,SUN]);partition=[]
    for lower,upper in zip(edges,edges[1:]):
        values=ring(profile,6.,1.5,"fine",(lower,upper))[0]
        from feasibility import UNIT
        pol=(-1.5*values[1]-6*values[2])/np.hypot(6.,1.5)*UNIT
        partition.append(dict(Rlo=lower,Rhi=upper,phi=values[0],inward=values[1],vertical=values[2],polar=pol))
    result=np.array([[r[key] for key in ("phi","inward","vertical")] for r in partition]).sum(axis=0)
    control=data(HOME/"fine-wedge-direct.csv")[0]
    assert np.max(abs(result-np.array([float(control[k]) for k in ("pooled_phi","pooled_in","pooled_z")])))<5e-8
    record("annular-force-balance.csv",partition)
    rs,wr=grid(profile.cuts,15);rs=rs.ravel();weight=2*np.pi*wr.ravel()*rs*profile.column(rs)
    heights=profile.heights(rs);changes=2*(heights**2-OLD**2)
    moment2=changes@weight
    widths=np.deg2rad([-60,-30,-15,0,15,30,60]);coefs=np.stack((np.diff(np.sin(widths)),-np.diff(np.cos(widths))))*np.sqrt(2)/(2*np.pi)
    moment3=-6*np.sqrt(7/12)*coefs@(changes[4:]-changes[0])@(weight*rs)
    records=[]
    for level in ("medium","fine"):
        for idx,case in enumerate(CASES):
            correct=moment2[idx] if idx<4 else moment2[0]*(1-sum(WIDTH))+WIDTH@moment2[4:]
            with np.load(HOME/(level+"-"+case+"-potential.npz")) as pk:
                rr=pk["r"][-1]
                actual=-pk["phi"][-1,1]*rr**3/G
                assert abs(float(pk["residual_mass"]))/sum(weight)<TOL
                records.append(dict(level=level,harmonic=case,zero_moment_mass=float(pk["residual_mass"]),zero_moment_relative=abs(float(pk["residual_mass"]))/sum(weight),
                             exact_nonzero=correct,numeric_nonzero=actual,nonzero_rel=actual/correct-1))
        for idx,case in enumerate(("cos","sin")):
            with np.load(HOME/(level+"-odd-"+case+".npz")) as pk:
                rr=pk["r"][-1];dip=-pk["phi"][-1,0]*3*rr**2/G;octu=-pk["phi"][-1,1]*7*rr**4/G
                records.append(dict(level=level,harmonic=case,zero_moment_mass=dip,zero_moment_relative=abs(dip)/sum(weight*rs),
                            exact_nonzero=moment3[idx],numeric_nonzero=octu,nonzero_rel=octu/moment3[idx]-1))
    record("exterior-moments.csv",records)
    outputs=[]
    for rr in (3.5,4.5,6.,6.378914049,7.25,SUN,9.):
        new=profile.heights(np.array(rr))
        for index,key in enumerate(("pooled","absolute","low","high",*SECTORS[1:])):
            oldcol=profile.column(rr)/1e6
            slab=2*np.pi*G*oldcol*1e6*(np.exp(-1.5/OLD)-np.exp(-1.5/new[index]))*UNIT
            outputs.append(dict(R=rr,profile=key,new_h=new[index],old_h=OLD,thin_living_column=oldcol,delta_slab_down=slab))
    record("density-transfer.csv",outputs)
    print("ordinary mass redistributed vertically at each radius; largest signed exterior moment errors",[(r["harmonic"],r["nonzero_rel"]) for r in records[-7:]],flush=True)
if __name__=="__main__":run()
