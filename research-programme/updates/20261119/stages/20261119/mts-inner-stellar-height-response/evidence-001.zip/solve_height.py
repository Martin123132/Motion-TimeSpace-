from height import *
from continue_pair import Mixture
from pair import Experiment


def potential(exp,level,name):
    with np.load(HOME/(level+"-"+name+"-potential.npz")) as pkt:
        rad,orders,phi,der=[pkt[key] for key in ("r","mode","phi","der")]
    spline=CubicHermiteSpline(rad,phi,der,axis=0)
    dist=exp.run.rad;within=np.minimum(dist,rad[-1])
    values=spline(within);slope=spline(within,1)
    mask=dist>rad[-1];outer=dist[mask,None]
    values[mask]=phi[-1]*(rad[-1]/outer)**(orders+1)
    slope[mask]=-(orders+1)*values[mask]/outer
    leg=legvander(exp.system.mu,int(orders[-1]))[:,::2].T
    return values@leg/exp.system.vel**2,dist[:,None]*(slope@leg)/exp.system.vel**2


def run(level):
    guard()
    fine=level=="fine";exp=Experiment(level,384 if fine else 256,16 if fine else 12);system=exp.system;lin=exp.lin
    normal="mass-spherical-"+level
    vir_base=exp.run.work+StellarPotential(normal).mesh(exp.run.rad,system.mu)[1]/system.vel**2
    anchor=exp.run.anchor
    dmass=lin.differentiate("mass")[0];mass_force=exp.readout.field("ground",exp.state,dmass)
    metrics=list(exp.metrics(exp.saved))
    pres=[];results=[];tangents={};changes={}
    for name in CASES:
        pot,vir=potential(exp,level,name)
        with np.load(HOME/(level+"-"+name+"-direct.npz")) as src:
            assert np.array_equal(src["locations"],exp.run.loc)
            direct=src["values"]
        bary=np.column_stack((direct[:,1],np.zeros(len(direct)),direct[:,2]))
        du=lin.constrained(-lin.read(lin.wave*pot))
        fixed=bary+exp.readout.field("ground",exp.state,du)
        rate=-fixed[anchor,0]/mass_force[anchor,0]
        assert abs(np.sum(exp.state*du))<1e-11
        changes[name]=(pot,vir,bary,du,rate)
        for model,control,derivative in (("ground",exp.saved,fixed),("nfw",exp.halo,bary)):
            for mode in ("fixed","matched"):
                total=derivative.copy()
                if mode=="matched":
                    total+=rate*mass_force if model=="ground" else -bary[anchor,0]/exp.halo[anchor,0]*exp.halo
                predict=exp.metrics(control,total);tangents[name,model,mode]=predict
                pres.append(dict(profile=name,model=model,mode=mode,**predict))
    record(level+"-frozen-tangents.csv",pres)
    for name in CASES:
        guard()
        pot,vir,bary,du,rate=changes[name]
        system.ext=exp.ext+pot;system.vir=vir_base+vir
        for model,control in (("ground",exp.saved),("nfw",exp.halo)):
            for mode in ("fixed","matched"):
                mass_ratio=1.;residual=0.
                if model=="nfw":
                    mass_ratio=1-bary[anchor,0]/exp.halo[anchor,0] if mode=="matched" else 1.
                    field=mass_ratio*exp.halo
                else:
                    matched=mode=="matched"
                    system.mass=exp.mass*np.exp(rate if matched else 0.)
                    state=exp.state+du+(rate*dmass if matched else 0.)
                    for it in range(8):
                        curve=polish(system,state.copy());state=curve.state
                        error=exp.run.mass_force(state)+bary[anchor,0]-exp.saved[anchor,0]
                        if not matched or abs(error)<1e-11*abs(exp.saved[anchor,0]):break
                        response=curve.differentiate("mass")[0]
                        step=-error/exp.run.mass_force(state,response)
                        state=state+step*response;system.mass*=np.exp(step)
                    else:raise RuntimeError("outer speed")
                    field=exp.readout.field("ground",state);mass_ratio=system.mass/exp.mass
                    residual=np.linalg.norm(curve.resid)/(abs(curve.chemical)*np.sqrt(system.mass))
                    assert residual<4e-13
                    save(level+"-"+name+"-"+mode+"-state",state=state,mass=system.mass,force=field)
                values=exp.metrics(field+bary);base=exp.metrics(control)
                if mode=="matched":assert abs(values["outer_speed"]-SPEED)<1e-7
                results.append(dict(profile=name,model=model,mode=mode,amplitude_ratio=mass_ratio,
                             normed_residual=residual,**values))
                for key in metrics:
                    pred=tangents[name,model,mode][key];diff=values[key]-base[key]
                    results[-1]["change_"+key]=diff
                    results[-1]["nonlinear_"+key]=diff-pred
    record(level+"-solutions.csv",results)
    name="pooled";pot,vir,bary,*_=changes[name]
    exp.ext=exp.ext+pot;exp.actualvir=vir_base+vir
    endpoint=[]
    for mode in ("fixed","matched"):
        with np.load(PAIR/(exp.tag+"-"+mode+"-8.npz")) as pkt:
            mass=float(pkt["mass"]);previous=mass;exc=pkt["excited"];original=pkt["force"]
        for iteration in range(8):
            mix=Mixture(exp,1.,mass,exp.state,exc);mix.polish();force=mix.force();exc=mix.states[-1]
            mismatch=force[anchor,0]+bary[anchor,0]-exp.saved[anchor,0]
            if mode=="fixed" or abs(mismatch)<1e-11*abs(exp.saved[anchor,0]):break
            tangent=mix.derivative("mass");delta=-mismatch/mix.force(tangent)[anchor,0];mass*=np.exp(delta);exc=exc+delta*tangent[-1]
        else:raise RuntimeError("pure outer")
        _,virial=mix.energy();values=exp.metrics(force+bary);originals=exp.metrics(original)
        endpoint.append(dict(profile=name,model="pure_pair",mode=mode,amplitude_ratio=mass/previous,normed_residual=mix.relative,virial=virial,**values,
                             **{"change_"+key:values[key]-originals[key] for key in metrics}))
        save(level+"-pair-"+mode,excited=exc,mass=mass,force=force)
    record(level+"-pair-endpoints.csv",endpoint)
    print(level,len(results),"ordinary+field comparisons and",len(endpoint),"pair checks",flush=True)


if __name__=="__main__":run(sys.argv[1])
