from math import pi, sqrt
import numpy as np
from scipy.integrate import quad_vec
from acquire import HOME
from digitize import record
import csv


def read(name):
    with (HOME/name).open(newline="",encoding="utf8") as handle:
        return list(csv.DictReader(handle))


def integral(frequency, duration):
    return duration*np.exp(0.5j*frequency*duration)*np.sinc(frequency*duration/(2*pi))


def run():
    rows=[]
    for tag in ("medium-96-8","fine-384-16"):
        floor=read(tag+"-positive-floor.csv")[0]
        upper=float(floor["spatial_ceiling"])
        actual=float(floor["projected_energy_estimate"])
        target=float(floor["one_percent_scale"])
        variation=sqrt(target/upper)
        record(tag+"-drive-variation.csv",[dict(template_arc_required=variation,turns_after_single_rise=(variation-1)/(2*pi),
            interpretation="necessary to reach reference energy only; fixed source template and linearized model")])
        spectrum=read(tag+"-collective-spectrum.csv")
        weights=read(tag+"-oscillator-weights.csv")
        statics={row["component"]:float(row["static_compliance"]) for row in read(tag+"-odd-response.csv")}
        for periods in (0,1,4):
            rate=2*pi/float(spectrum[0]["period_Myr"])
            duration=periods*float(spectrum[0]["period_Myr"])
            known_energy=0.
            for rank,mode in enumerate(spectrum,1):
                omega=2*pi/float(mode["period_Myr"])
                components=[next(row for row in weights if row["component"]==side and int(row["rank"])==rank) for side in ("cos","sin")]
                amplitude=np.sqrt([float(row["drive_squared"]) for row in components])
                direction=amplitude/np.linalg.norm(amplitude)
                def velocity(time):
                    angle=rate*time
                    return rate*np.exp(1j*omega*time)*np.array([-np.sin(angle)*direction[0]-np.cos(angle)*direction[1],
                                                              np.cos(angle)*direction[0]-np.sin(angle)*direction[1]])
                vector=direction+quad_vec(velocity,0,duration,epsabs=2e-12,epsrel=2e-12)[0]
                direct=np.vdot(vector,vector).real
                plus=1+1j*rate*integral(omega+rate,duration)
                minus=1-1j*rate*integral(omega-rate,duration)
                closed=(abs(plus)**2+abs(minus)**2)/2
                assert abs(direct-closed)<2e-11*max(1.,closed)
                assert closed <= (1+abs(rate)*duration)**2 + 1e-10
                if rank==1:
                    assert abs(closed-(1+2*pi*pi*periods**2))<2e-10
                share=sum(float(row["share"])*statics[row["component"]] for row in components)/sum(statics.values())
                known_energy+=share*actual*closed
            bound=upper*(1+2*pi*periods)**2
            assert known_energy<=bound
            rows.append(dict(tag=tag,turns=periods,period_Myr=float(spectrum[0]["period_Myr"]),elapsed_Myr=duration,
                resolved_four_mode_energy=known_energy,all_mode_variation_ceiling=bound,ceiling_over_reference=bound/target))
    record("rotating-source-controls.csv",rows)


if __name__=="__main__":
    run()
