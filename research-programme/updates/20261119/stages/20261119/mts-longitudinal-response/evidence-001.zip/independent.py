from source import *


def slice_accel(mesh,model,basis,gain,eta,k,seed,eps):
    horizon=3.5
    solver=Radial(mesh,basis,gain,eta,horizon)
    first=state(mesh,model,basis,gain,eta,k,seed,eps,horizon)
    velocity=solver.rhs(first)
    second=solver.rhs(first+1e-14j*velocity).imag/1e-14
    logn=second[7]/first[7]-second[0]/(2*(1+first[0]))-second[1]/(1+first[1])
    amp=np.sqrt(background(model)[0])
    return center(np.stack((logn,second[5]/amp)))


def audit(model):
    pred=frozen()
    out=[]
    for row in pred["rows"]:
        if row["model"]!=model:
            continue
        guard()
        basis,gain,eta,k=[row[name] for name in ("basis","gain","eta","k")]
        want=np.array(row["omega2"])
        for mesh in (160,320,640):
            matrices=[]
            for increment in (2**-11,2**-12):
                cols=[]
                for seed in SEEDS:
                    signs=[slice_accel(mesh,model,basis,gain,eta,k,seed,sgn*increment) for sgn in (1,-1)]
                    cols.append(-(signs[0]-signs[1])/(2*increment))
                matrices.append(np.stack(cols,axis=1))
            best=(4*matrices[1]-matrices[0])/3
            norm=np.maximum(abs(want),1e-300)
            for jj,output in enumerate(("density","scalar")):
                for ii,input_name in enumerate(SEEDS):
                    exact=float(want[jj,ii])
                    value=float(best[jj,ii])
                    delta=abs(value-exact)
                    rel=delta/abs(exact) if exact!=0 else None
                    out.append(dict(model=model,basis=basis,gain=gain,eta=eta,k=k,mesh=mesh,output=output,input=input_name,
                                   predicted=exact,measured=value,absolute=delta,relative=rel,
                                   amplitude_shift=abs(float(matrices[0][jj,ii]-matrices[1][jj,ii])),
                                   status=("exact_null" if value==0 else "absolute_null_only") if exact==0 else ("pass" if rel<=TOL else "miss")))
    table(f"direct-{model}.csv",out)
    print(model,len(out),flush=True)


if __name__=="__main__":
    audit(sys.argv[1])

