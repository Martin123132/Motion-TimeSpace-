from source import *
from scipy.linalg import expm


def tag(basis,gain,eta,k,mesh,seed):
    return f"{basis}-{gain:g}-q{eta:g}-k{k:g}-{seed}-m{mesh}"


def initial(mesh,basis,gain,eta,k,seed,mode,horizon):
    if mode=="realplus" or mode=="realminus":
        return state(mesh,"massive",basis,gain,eta,k,seed,(1 if mode=="realplus" else -1)*2**-11,horizon)
    base=state(mesh,"massive",basis,gain,eta,k,seed,0.,horizon)
    if mode=="base":
        return base
    deriv=[]
    for inc in (2**-11,2**-12):
        pert=[state(mesh,"massive",basis,gain,eta,k,seed,sign*inc,horizon) for sign in (1,-1)]
        deriv.append((pert[0]-pert[1])/(2*inc))
    return base+1j*1e-7*(4*deriv[1]-deriv[0])/3


def history(mesh,basis,gain,eta,k,seed,mode="tangent",horizon=4.5):
    guard()
    solver=Radial(mesh,basis,gain,eta,horizon)
    vec=initial(mesh,basis,gain,eta,k,seed,mode,horizon)
    n0,field=background("massive")
    stride=int(np.ceil(.01*mesh/.25))
    dt=.01/stride
    keep=[]
    for tick in range(80*stride+1):
        if tick%stride==0:
            n=vec[7,:5]/(np.sqrt(1+vec[0,:5])*(1+vec[1,:5]))
            keep.append([center(np.log(n/n0)),center(vec[5,:5]/np.sqrt(n0))])
        if tick%(20*stride)==0:
            guard()
        if tick==80*stride:
            break
        first=solver.rhs(vec)
        second=solver.rhs(vec+dt*first/2)
        third=solver.rhs(vec+dt*second/2)
        fourth=solver.rhs(vec+dt*third)
        vec+=dt/6*(first+2*second+2*third+fourth)
    vals=np.array(keep)
    assert np.isfinite(vals).all() and np.isfinite(vec).all()
    return vals


def evolve(basis):
    frozen()
    times=np.arange(81)*.01
    for gain in ((0.,-.5,.5,4.,-4.) if basis=="tensor" else (-.5,.5)):
        for eta in ((0.,.8) if basis=="tensor" and gain==0 else (.8,)):
            for k in ((1.,4.,24.) if abs(gain)<1 else (24.,)):
                for seed in (SEEDS if k==24. and abs(gain)<1 else ("density",)):
                    for mesh in (160,320):
                        label=tag(basis,gain,eta,k,mesh,seed)
                        dest=HERE/("trajectory-"+label+".npz")
                        if dest.exists():
                            raise FileExistsError(dest)
                        signal=history(mesh,basis,gain,eta,k,seed)
                        output=dict(wave=signal.imag/1e-7,unperturbed=signal.real,time=times)
                        if mesh==160 and k==24 and eta==.8 and abs(gain)<1:
                            a,b=[history(mesh,basis,gain,eta,k,seed,m) for m in ("realplus","realminus")]
                            output["real"]=(a-b)*1024
                        bridge.archive(dest,**output)
        print("finished",basis,gain,flush=True)


def score():
    frozen_data=frozen()
    rows=[]
    for path in sorted(HERE.glob("trajectory-*-m320.npz")):
        import re
        match=re.fullmatch(r"trajectory-(tensor|trace)-(-?[.\d]+)-q([.\d]+)-k([.\d]+)-(density|scalar)-m320",path.stem)
        basis,gain,eta,k,seed=match.groups()
        gain,eta,k=map(float,(gain,eta,k))
        fine=bridge.read(path)
        coarse=bridge.read(path.with_name(path.name.replace("m320","m160")))
        if abs(gain)>1:
            from centre_jet import matrix
            coeff,_=matrix("massive",basis,gain,eta,k)
        else:
            row=next(item for item in frozen_data["rows"] if (item["model"],item["basis"],item["gain"],item["eta"],item["k"])==("massive",basis,gain,eta,k))
            coeff=np.array(row["omega2"])
        generator=np.block([[np.zeros((2,2)),np.eye(2)],[-coeff,np.zeros((2,2))]])
        start=np.array([float(seed=="density"),float(seed=="scalar"),0.,0.])
        tt=fine["time"]
        template=np.array([(expm(t*generator)@start)[:2] for t in tt])-start[:2]
        actual=fine["wave"]-fine["wave"][:1]
        other=coarse["wave"]-coarse["wave"][:1]
        independent=coarse.get("real")
        for idx,part in enumerate(SEEDS):
            scale=max(abs(actual[:,idx]))
            err=max(abs(other[:,idx]-actual[:,idx]))
            realerror=max(abs((independent[:,idx]-independent[0,idx])-other[:,idx])) if independent is not None else None
            def relative(value):
                return float(value/scale) if scale!=0 and value is not None else None
            curv=2*(-2.5*actual[0,idx]+4/3*(actual[1,idx]+actual[1,idx])-(actual[2,idx]+actual[2,idx])/12)/(.01**2*2)
            rows.append(dict(basis=basis,gain=gain,eta=eta,k=k,seed=seed,output=part,change_at_end=actual[-1,idx],
                             instantaneous=-(coeff@start[:2])[idx],curvature_from_first_times=curv,static_prediction_end=template[-1,idx],
                             frozen_error_0p8=relative(max(abs(template[:,idx]-actual[:,idx]))),
                             grid_relative=relative(err),grid_absolute=err,finite_relative=relative(realerror),finite_absolute=realerror))
    table("evolution-checks.csv",rows)


if __name__=="__main__":
    if sys.argv[1]=="score":
        score()
    else:
        evolve(sys.argv[1])

