from centre_jet import jets
from source import *
import sympy as sy


def main():
    guard()
    eps,gain,ks=sy.symbols("eps g k2",real=True)
    eta=sy.Rational(4,5)
    nn,ff=background("massive")
    number,hh,h2=[sy.Rational(str(v)) for v in (nn,float(ff(0)),float(ff(0,2)/2))]
    amp=sy.sqrt(number)
    b2=-6*number/25
    base={}
    k2bounds=[]
    source=json.loads((HERE/"regime.json").read_text())
    for basis in ("tensor","trace"):
        coeffs=[]
        for seed in SEEDS:
            n=number+(number*eps if seed=="density" else 0)
            bb=b2-(number*eps*ks/6 if seed=="density" else 0)
            val=hh+(amp*eps if seed=="scalar" else 0)
            jet=h2-(amp*eps*ks/6 if seed=="scalar" else 0)
            out=jets()(n,bb,val,jet,gain if basis=="tensor" else 0,gain if basis=="trace" else 0,eta)
            lhs=[-sum(out[:-1]),-out[-1]/amp]
            coeffs.append([[sy.diff(eq,eps).subs({eps:0,gain:0}).expand(),sy.diff(eq,eps,gain).subs({eps:0,gain:0}).expand()] for eq in lhs])
        lower=coeffs[0][1][1]
        slope=coeffs[0][0][1]
        mixing=coeffs[1][0][0]
        assert not lower.has(ks) and not mixing.has(ks)
        assert abs(float(slope.coeff(ks)+number/2))<1e-15
        assert abs(float(coeffs[0][0][0]+number*(1-eta**2)))<1e-14
        regular=abs(float(slope.subs(ks,0)))+abs(float(lower*mixing))/(1+float(number*(1-eta**2)))
        k2bounds.append(regular)
        base[basis]=dict(constant_element=float(slope.subs(ks,0)),k_squared_element=float(slope.coeff(ks)),
                         lower_coupling=float(lower),minimal_upper=float(mixing),uniform_remainder_per_unit=regular)
    rest=k2bounds[0]*2.5523906183973274e-45+k2bounds[1]*1.2761953091990767e-45
    savejson("mixed-corridor.json",dict(eta=.8,model="massive",constant=base,max_abs_non_k2_shift=rest,
             max_abs_total_shift=rest+nn*source["max_abs_change_in_gravity_over_newton"],zero_contact_slow=-nn*(1-.8**2),
             scope="First-order instantaneous slow eigenvalue at the centre for the two reduced stress operators; the scalar is kept, not replaced by a fitted fluid."))


if __name__=="__main__":
    main()

