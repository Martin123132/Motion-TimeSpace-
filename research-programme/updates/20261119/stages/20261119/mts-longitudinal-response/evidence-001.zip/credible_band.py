from shell_transport import calculate
from source import *
from scipy.constants import physical_constants,c,electron_volt


def main():
    state=json.loads((HERE/"regime.json").read_text())
    coeff=OLD.parent/"source-intake/functional_rg/4943/interior_stability_benchmarks.csv"
    with coeff.open(newline="") as file:
        caps=next(csv.DictReader(file))
    ar,ac=float(caps["abs_aR_control_cap"]),float(caps["abs_aC_control_cap"])
    ratio=state["g_abs_cap_correlated"]/(8*(ar+4*ac/3))
    rows=[]
    tests=[]
    for eta in (.0,.8,1.):
        zero=bridge.read(HERE/f"shell-prediction-q{eta:g}-k0.npz")
        sample=bridge.read(HERE/f"shell-prediction-q{eta:g}-k4.npz")
        time=zero["time"]
        constant=zero["wave"][1:]
        slopes=(sample["wave"][1:]-constant)/16
        assert max(abs(slopes[0]-slopes[1]))<1e-10
        for k in (7.25,24.,33.125):
            target=calculate(eta,k,1e-16j,time)[0][1:].imag/1e-16
            err=float(np.max(abs(target-constant-k*k*slopes)))
            scale=float(np.max(abs(target)))
            assert err/scale<1e-10
            tests.append(dict(eta=eta,k=k,max_absolute=err,relative=err/scale))
        static=ratio*(ac*abs(16*constant[0]-16*constant[1]/3)+ar*8*abs(constant[1]))
        envelope=static+2/60*abs(slopes[0])
        for requested in (.8,3.24,20.,40.):
            idx=int(np.argmin(abs(time-requested)))
            for k in (0.,4.,24.,state["max_k_at_saturated_parent_caps"]):
                tensor,trace=constant[:,idx]+k**2*slopes[:,idx]
                arlim=min(ar,.01/(12*ratio*k**2)) if k else ar
                aclim=min(ac,.01/(4*ratio*k**2)) if k else ac
                exact=ratio*(aclim*abs(16*tensor-16*trace/3)+arlim*8*abs(trace))
                assert exact<=envelope[idx]*(1+2e-12)+1e-54
                rows.append(dict(eta=eta,time=time[idx],independently_evolved_window=requested<=3.24 and eta!=0,
                                 k=k,baseline=zero["wave"][0,idx],zero_wave_bound=static[idx],gradient_transfer=slopes[0,idx],
                                 wave_specific_bound=exact,uniform_all_k_bound=envelope[idx]))
    table("retained-corridor-time-response.csv",rows)
    table("affine-prediction-checks.csv",tests)
    flags=[]
    for row in frozen()["rows"]:
        if row["model"]!="massive":
            continue
        gain,k,eta=float(row["gain"]),float(row["k"]),float(row["eta"])
        tensor=gain if row["basis"]=="tensor" else 0.
        trace=gain if row["basis"]=="trace" else 0.
        d0=(tensor/2+3*trace/2)*k*k
        d2=-tensor*k*k/4
        flags.append(dict(basis=row["basis"],gain=gain,eta=eta,k=k,d0=d0,d2=d2,inside_insertions_at_nominal_k=max(abs(d0),abs(d2))<=.01,
                          inside_prior_coefficient_caps=gain==0,slow_omega2=row["slow_fast"][0]))
    table("trial-regimes.csv",flags)


if __name__=="__main__":
    main()

