import csv
import hashlib
import json
import os
from collections import Counter
from pathlib import Path

for setting in ("OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS", "NUMEXPR_NUM_THREADS"):
    os.environ[setting] = "1"
import numpy as np

HOME = Path(__file__).resolve().parent
PREVIOUS = HOME.parent / "mts-self-consistent-contact-20261119"
TOLERANCE = 2e-5
FROZEN = {
    "forecast.json": "2dbf07140986d790060314dc8055f72e52537643ae75102cec19bbec0fa0ac10",
    "balance-forecast.json": "9b47647c32f6ee37b5b5e7ddc53bb04d1f9f7e9d77594fd74fced961935636a3",
    "shell-forecast.json": "c2b2809a54acc2aa05b28f4218d5f3fd9c717a8c43d1f6911e0faf29399f459c",
    "held-packet-freeze.json": "1be1b3a9cffa1ebac3d46c4199c39ebf33d4e110095df87cd23e6d8727d3864a",
}
PARENT_HASH = "3ea60948784cc68c11b0264702af236e1b5d6dff49d01d9710c17176f75d4076"


def digest(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def check_files(root, files):
    for name, expected in files.items():
        assert digest(root / name) == expected, name


def read(name):
    return json.loads((HOME / name).read_bytes())


def verify_pulse(label, rows):
    pred = []
    true = []
    for mesh in (160, 320):
        with np.load(HOME / f"held-prediction-q{label}-{mesh}.npz", allow_pickle=False) as archive:
            np.testing.assert_array_equal(archive["time"], np.arange(201) * .004)
            assert archive["wave"].shape == (201, 2)
            pred.append(archive["wave"])
    for mesh in (320, 480):
        with np.load(HOME / f"held-real-q{label}-{mesh}.npz", allow_pickle=False) as archive:
            assert str(archive["seal"].item()) == FROZEN["held-packet-freeze.json"]
            narrow = archive["narrow"]
            fitted = (4 * narrow - archive["wide"]) / 3
            assert fitted.shape == (201, 2)
            np.testing.assert_array_equal(fitted, archive["richardson"])
            true.append(fitted)
    answers = {}
    for column, name in enumerate(("number", "field")):
        row, = [entry for entry in rows if entry["channel"] == name and float(entry["eta"]) == float(label)]
        target = true[1][:, column]
        peak = int(np.argmax(abs(target)))
        scale = abs(target[peak])
        assert scale > 0 and abs(target[0]) < scale * 1e-6
        assert .004 * peak == float(row["time"])
        np.testing.assert_allclose([target[peak], pred[1][peak, column]],
                                   [float(row["measured_signed_peak"]), float(row["prediction_at_peak"])], rtol=1e-14, atol=0)
        components = [
            max(abs(target - pred[1][:, column])), max(abs(target - true[0][:, column])),
            max(abs(pred[1][:, column] - pred[0][:, column])), max(abs(target - narrow[:, column])),
        ]
        relative = np.array(components) / scale
        summed = float(sum(relative))
        names = ["model_residual", "full_grid", "predicted_grid", "finite_amplitude", "summed_budget"]
        np.testing.assert_allclose([*relative, summed], [float(row[key]) for key in names], rtol=1e-13, atol=0)
        assert row["passes"] == str(bool(summed <= TOLERANCE))
        answers[name] = {"budget": summed, "passes": summed <= TOLERANCE}
    return answers


def main():
    assert __debug__ and not (HOME / "STOP-REQUESTED").exists()
    assert not any(path.is_dir() or path.name.endswith(".partial") for path in HOME.iterdir())
    check_files(PREVIOUS, {"seal.json": PARENT_HASH})
    parent = json.loads((PREVIOUS / "seal.json").read_bytes())["files"]
    assert len(parent) == 241
    check_files(PREVIOUS, parent)
    check_files(HOME, FROZEN)
    forecast, balance, shell, pulse = [read(name) for name in FROZEN]
    assert len(forecast["rows"]) == 140 and len(balance["rows"]) == 6 and pulse["tol"] == TOLERANCE
    assert all(data["parent"] == PARENT_HASH for data in (forecast, balance, shell))
    check_files(HOME, {**forecast["producer"], **balance["hashes"], **shell["files"],
                       "shell_transport.py": shell["equations"], "shell-predictions.csv": shell["rows"],
                       **pulse["sources"], **pulse["method"]})
    regime = read("regime.json")
    check_files(HOME.parent, {next(HOME.parent.glob("4878-*.md")).name: regime["hash_4878"],
                             "source-intake/functional_rg/4943/interior_stability_benchmarks.csv": regime["hash_4943_caps"],
                             "mts-two-radius-pressure-clock-20261119/physical-clock-scale.json": regime["hash_scale"]})
    tables = {}
    for path in sorted(HOME.glob("*.csv")):
        with path.open(newline="", encoding="utf-8-sig") as stream:
            reader = csv.DictReader(stream)
            assert len(set(reader.fieldnames)) == len(reader.fieldnames)
            rows = list(reader)
        assert rows and all(None not in row and None not in row.values() for row in rows), path.name
        tables[path.name] = rows
    for path in HOME.glob("*.npz"):
        with np.load(path, allow_pickle=False) as archive:
            assert archive.files
            for key in archive.files:
                array = archive[key]
                if array.dtype.kind in "fci":
                    assert np.isfinite(array).all(), (path.name, key)
    axis = tables["conditioned-axis.csv"]
    keys = {(r["model"], r["basis"], float(r["gain"]), float(r["eta"]), float(r["k"]), r["input"], r["output"]) for r in axis}
    expected = {(r["model"], r["basis"], r["gain"], r["eta"], r["k"], inp, out)
                for r in forecast["rows"] for inp in ("density", "scalar") for out in ("density", "scalar")}
    assert len(axis) == len(keys) == 560 and keys == expected
    assert Counter(r["status"] for r in axis) == {"pass": 406, "exact_null": 140, "absolute_null_only": 14}
    for row in axis:
        actual, ref = float(row["actual"]), float(row["reference"])
        if ref:
            assert abs(actual - ref) <= TOLERANCE * abs(ref)
        else:
            assert (actual == 0) == (row["status"] == "exact_null")
    assert len(tables["zero-crossings.csv"]) == 8
    assert all(float(row["relative"]) < 1.4e-7 for row in tables["zero-crossings.csv"])
    ordinary = [r for basis in ("trace", "tensor") for r in tables[f"all-time-{basis}-320.csv"] if float(r["k"]) != 0.]
    assert len(ordinary) == 8 and all(r["unchanged_pass"] == "True" and float(r["relative"]) <= TOLERANCE for r in ordinary)
    zero = tables["zero-mode-conditioned.csv"]
    assert len(zero) == 8 and max(float(r["relative"]) for r in zero) <= TOLERANCE
    fixed = [r for label in ("0.8", "1") for r in tables[f"scalar-controls-q{label}.csv"]
             if r["method"] == "fixed_GR" and r["mesh"] == "320"]
    assert len(fixed) == 8 and all(float(r["relative"]) <= TOLERANCE for r in fixed)
    worked = {label: verify_pulse(label, tables[f"held-result-q{label}.csv"]) for label in ("0.8", "1")}
    checks = tables["early-quartic.csv"]
    assert len(checks) == 4 and all((r["passes"] == "True") == (float(r["relative"]) <= TOLERANCE) for r in checks)
    for required in ("RESULTS.md", "DERIVATION.md", "REPLAY.md", "SCALES.md", "SCALAR-CONTROL.md", "EARLY-PACKET.md"):
        assert (HOME / required).stat().st_size > 100
    dest = HOME / "seal.json"
    record = dict(parent=PARENT_HASH, parent_files=len(parent), frozen=FROZEN, pulse=worked,
                  rows={name: len(items) for name, items in tables.items()},
                  files={path.name: digest(path) for path in sorted(HOME.iterdir()) if path != dest})
    if dest.exists():
        assert record == read(dest.name), "Seal differs; do not overwrite"
    else:
        with dest.open("x", encoding="utf-8") as stream:
            json.dump(record, stream, allow_nan=False, indent=2, sort_keys=True)
    print("Verified", len(record["files"]), "files;", sum(record["rows"].values()), "table rows;", digest(dest))


if __name__ == "__main__":
    main()
