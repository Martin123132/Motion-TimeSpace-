from ordinary_evolution import evolve
from shell_transport import calculate
from source import *


def repair():
    rows=[]
    for eta in (.8,1.):
        for basis in ("tensor","trace"):
            for mesh in (48,96):
                currents=[]
                targets=[]
                times=np.arange(163)*.02
                step=1e-7j
                idx=1 if basis=="tensor" else 2
                for eps in (.08,.04):
                    raw=[evolve(mesh,0.,eta,basis,sign*eps,step)[0] for sign in (1,-1)]
                    pred=[calculate(eta,0.,sign*eps,times)[0][idx] for sign in (1,-1)]
                    current=(raw[0]-raw[1]).imag/(2*eps*step.imag)
                    currents.append(current-current[0])
                    targets.append((pred[0]-pred[1])/(2*eps))
                best=(4*currents[1]-currents[0])/3
                expected=calculate(eta,0.,1e-16j,times)[0][idx].imag/1e-16
                err=max(abs(best-expected))
                rows.append(dict(eta=eta,basis=basis,mesh=mesh,absolute=err,relative=err/max(abs(expected)),expected=expected[-1],
                                 observed=best[-1],max_same_amplitude_error=max(max(abs(a-b)) for a,b in zip(currents,targets)),
                                 first_0p8_relative=max(abs((best-expected)[:41]))/max(abs(expected[:41]))))
    table("zero-mode-conditioned.csv",rows)
    print(*[(row["basis"],row["eta"],row["mesh"],row["relative"]) for row in rows],sep="\n")


if __name__=="__main__":
    repair()

