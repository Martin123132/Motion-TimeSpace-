from source import *


def main():
    guard()
    n0=background("ordinary")[0]
    rows=[]
    for basis in ("tensor","trace"):
        for wave in (0.,4.,24.):
            acceleration=n0*wave**2/2-n0**2*(1/3 if basis=="tensor" else 1)
            rows.append(dict(basis=basis,k=wave,mixed_acceleration=acceleration,
                             law="d_gamma d_seed ln n_center(t) = acceleration*t^2/2 at eta=1",at_0p8=.32*acceleration))
    savejson("balance-forecast.json",dict(rows=rows,n0=n0,parent=LOCK,hashes={name:bridge.sha(HERE/name) for name in ("source.py","balance_forecast.py")},
                  control="Ordinary h=0 charged sphere; eta=1 is a separate exact force-balance control, not a replacement for eta=.8. Full finite-time quadratic law is a first-order prediction about a static family; signs tested at fixed launch number and charge."))
    print("balance forecast",bridge.sha(HERE/"balance-forecast.json"))


if __name__=="__main__":
    main()

