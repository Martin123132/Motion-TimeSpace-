from source import *


def centre_pair(mesh,model,basis,gain,eta,k,seed,eps):
    horizon=3.5
    solver=Radial(mesh,basis,gain,eta,horizon)
    first=state(mesh,model,basis,gain,eta,k,seed,eps,horizon)
    rate=solver.rhs(first)
    shifted=first+1e-14j*rate
    aa=np.sqrt(1+shifted[0])
    cc=1+shifted[1]
    vel=shifted[8]/aa
    nn=shifted[7]/(aa*cc)
    mat=material(shifted[5],shifted[6],solver.diff(shifted[5],solver.d1)/aa,nn,vel,shifted[9]/(solver.x**2*cc),basis)
    flux=cc*nn*(vel/np.sqrt(1+vel**2)+gain*mat[11])
    odd_slope=center(flux[:5].imag/1e-14/solver.x[:5])
    second=solver.rhs(shifted).imag/1e-14
    foc=center(-second[0]/(2*(1+first[0]))-second[1]/(1+first[1]))
    return np.array([foc-3*odd_slope/center(first[7]),center(second[5])/np.sqrt(background(model)[0])])


def measured(mesh,model,basis,gain,eta,k):
    matrices=[]
    for inc in (2**-11,2**-12):
        cols=[]
        for seed in SEEDS:
            a,b=[centre_pair(mesh,model,basis,gain,eta,k,seed,sign*inc) for sign in (1,-1)]
            cols.append(-(a-b)/(2*inc))
        matrices.append(np.stack(cols,axis=1))
    return (4*matrices[1]-matrices[0])/3


def run():
    pred=frozen()
    rows=[]
    for item in pred["rows"]:
        model,basis,gain,eta,k=[item[key] for key in ("model","basis","gain","eta","k")]
        actual=measured(640,model,basis,gain,eta,k)
        for idx,part in enumerate(SEEDS):
            for col,seed in enumerate(SEEDS):
                ref=item["omega2"][idx][col]
                val=float(actual[idx,col])
                err=abs(ref-val)
                rel=err/abs(ref) if ref else None
                rows.append(dict(model=model,basis=basis,gain=gain,eta=eta,k=k,output=part,seed=seed,reference=ref,
                                 direct=val,abs_error=err,relative=rel,status=("pass" if rel<=TOL else "miss") if rel is not None else ("exact_null" if err==0 else "absolute_null_only")))
    table("regular-axis.csv",rows)
    roots=[]
    for item in pred["roots"]:
        for wave in item["k_zero"]:
            model,basis,gain,eta=[item[key] for key in ("model","basis","gain","eta")]
            def det(k):
                return float(np.linalg.det(measured(320,model,basis,gain,eta,k)))
            lo,hi=wave*.99,wave*1.01
            left,right=det(lo),det(hi)
            assert left*right<0
            zero=brentq(det,lo,hi,xtol=8e-10)
            roots.append(dict(model=model,basis=basis,gain=gain,eta=eta,predicted=wave,measured=zero,
                              relative=abs(zero-wave)/wave,left_det=left,right_det=right))
    table("zero-crossings.csv",roots)
    print("regular axis",len(rows),"threshold brackets",len(roots),flush=True)


if __name__=="__main__":
    run()

