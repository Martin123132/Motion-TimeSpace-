from source import HERE, TOL, background, bridge, guard, np, table


def evaluate():
    guard()
    density, field = background("massive")
    height = field(0.)
    acceleration = 3 * field(0., 2) - height
    coefficient = float(12 * np.sqrt(density) * (4 * acceleration - height))
    rows = []
    for eta in (.8, 1.):
        full = bridge.read(HERE / f"held-real-q{eta:g}-480.npz")["richardson"][:, 0]
        for start in (6, 8):
            indices = start * np.array([1, 2, 4, 8])
            times = indices * .004
            square = times**2
            weights = np.array([np.prod(-np.delete(square, pos) / (value - np.delete(square, pos)))
                                for pos, value in enumerate(square)])
            ratio = (full[indices] - full[0]) / times**4
            estimate = weights @ ratio
            relative = abs(estimate / coefficient - 1)
            rows.append(dict(eta=eta, first_time=times[0], last_time=times[-1],
                             predicted=coefficient, extrapolated=estimate, relative=relative, passes=relative <= TOL))
    table("early-quartic.csv", rows)


if __name__ == "__main__":
    evaluate()
