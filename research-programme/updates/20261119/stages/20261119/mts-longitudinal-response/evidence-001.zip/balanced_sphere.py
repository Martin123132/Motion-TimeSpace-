from source import *


def matched(mesh,basis,wave,seed,delta,horizon=3.5):
    n0=background("ordinary")[0]
    ratio=8
    grid=np.arange(int(mesh*horizon)*ratio+1)/(mesh*ratio)
    bb,qq,_,_=profile(grid,wave)
    number=n0*(np.maximum(1-(grid/5)**2,0)**6+seed*bb)
    charge=.002*betainc(1.5,7,np.minimum((grid/5)**2,1))+seed*n0*qq
    inv=np.zeros_like(grid)
    inv[1:]=1/grid[1:]
    root=1-charge*inv
    n=number*root
    electric=charge*inv**2
    z=material(0.,0.,0.,n,0.,electric,basis)[4]
    exponent=cumulative_simpson(grid*number/root,x=grid,initial=0.)
    du=np.exp(-exponent)*cumulative_simpson(grid**2*z*np.exp(exponent),x=grid,initial=0.)
    use=np.arange(ratio//2,int(mesh*horizon)*ratio,ratio)
    x=grid[use]
    fac=root[use]**2
    mass=(charge-charge**2*inv/2)[use]
    zeros=0*fac
    return np.stack((2*mass/(x*fac)+delta*2*du[use]/(x*fac**2),zeros,zeros,zeros,(mass+delta*du[use])/x**3,
                     zeros,zeros,number[use],zeros,charge[use]))


def orbit(mesh,basis,wave,amp,delta):
    horizon=3.5
    solver=Radial(mesh,basis,delta,1.,horizon)
    field=matched(mesh,basis,wave,amp,delta,horizon)
    stride=int(np.ceil(.01*mesh/.24))
    dt=.01/stride
    nbase=background("ordinary")[0]
    rows=[]
    for tick in range(80*stride+1):
        if tick%stride==0:
            proper=field[7,:5]/(np.sqrt(1+field[0,:5])*(1+field[1,:5]))
            rows.append(center(np.log(proper/nbase)))
        if tick%(20*stride)==0:
            guard()
        if tick==80*stride:
            break
        first=solver.rhs(field)
        second=solver.rhs(field+dt/2*first)
        third=solver.rhs(field+dt/2*second)
        fourth=solver.rhs(field+dt*third)
        field+=dt/6*(first+2*second+2*third+fourth)
    assert np.isfinite(field).all()
    return np.array(rows)


def run(basis):
    freeze=json.loads((HERE/"balance-forecast.json").read_text())
    for name,stamp in freeze["hashes"].items():
        assert bridge.sha(HERE/name)==stamp
    rows=[]
    for pred in freeze["rows"]:
        if pred["basis"]!=basis:
            continue
        wave=pred["k"]
        for mesh in (160,320,640):
            for delta in ((1.e-7j,4.e-7j) if wave==4 and mesh==160 else (1.e-7j,)):
                eps=.01
                vals=[orbit(mesh,basis,wave,sgn*eps,delta) for sgn in (1,-1)]
                test=(vals[0]-vals[1])/(2*eps)
                clock=np.arange(81)*.01
                theory=.5*pred["mixed_acceleration"]*clock**2
                measured=(test-test[0]).imag/delta.imag
                err=float(max(abs(measured-theory)))
                rel=err/max(abs(theory))
                rows.append(dict(basis=basis,k=wave,mesh=mesh,imag_step=delta.imag,relative=rel,absolute=err,
                                 predicted_end=theory[-1],measured_end=measured[-1],zero_contact_change=float(max(abs(test.real-test[0].real))),
                                 pass_unchanged=rel<=TOL))
                dest=HERE/f"balance-{basis}-{wave:g}-{mesh}-{delta.imag:g}.npz"
                bridge.archive(dest,time=clock,prediction=theory,measured=measured,null=test.real-test[0].real)
            print("balanced",basis,wave,mesh,rel,flush=True)
    table(f"balance-{basis}.csv",rows)


if __name__=="__main__":
    run(sys.argv[1])

