from scalar_readout import strip,transport
from source import *


def freeze():
    guard()
    clock=np.arange(201)*.004
    sources={}
    for eta in (.8,1.):
        for mesh in (160,320):
            first,second=[strip(mesh,k,eta,"fixed") for k in (9.,15.)]
            assert np.max(abs(first.real-second.real))<1e-12
            source=first.real+1j*(first.imag-second.imag)
            output=transport(source,eta,clock,False)
            signal=np.stack((output[0].imag,source[:,1].imag),axis=1)/1e-7
            path=HERE/f"held-prediction-q{eta:g}-{mesh}.npz"
            bridge.archive(path,time=clock,wave=signal,field_input=source)
            sources[path.name]=bridge.sha(path)
    savejson("held-packet-freeze.json",dict(shape="W [j0(9r) - j0(15r)]; delta h(0)=0; delta number=0; independent real signs and two amplitudes",duration=.8,tol=TOL,
             sources=sources,method={name:bridge.sha(HERE/name) for name in ("held_packet.py","scalar_readout.py","ordinary_evolution.py","source.py")}))
    print("held packet frozen",bridge.sha(HERE/"held-packet-freeze.json"),flush=True)


def real_state(mesh,eta,eps,rmax):
    ratio=4
    xx=np.arange(mesh*int(2*rmax)*ratio//2+1)/(mesh*ratio)
    n,field=background("massive")
    b=n*np.maximum(1-(xx/5)**2,0)**6
    charge=.002*eta*betainc(1.5,7,np.minimum((xx/5)**2,1))
    left=profile(xx,9.)
    right=profile(xx,15.)
    hh=field(xx)+eps*np.sqrt(n)*(left[2]-right[2])
    grad=field(xx,1)+eps*np.sqrt(n)*(left[3]-right[3])
    inv=np.zeros_like(xx)
    inv[1:]=1/xx[1:]
    fac=np.ones_like(xx)
    for _ in range(9):
        en=(fac*grad**2+hh**2+(charge*inv**2)**2)/2+b*np.sqrt(fac)
        mass=cumulative_simpson(xx**2*en,x=xx,initial=0.)
        fac=1-2*mass*inv
    idx=np.arange(ratio//2,len(xx)-1,ratio)
    zero=np.zeros(len(idx))
    return np.stack(((2*mass*inv/fac)[idx],zero,zero,zero,(mass*inv**3)[idx],hh[idx],zero,b[idx],zero,charge[idx]))


def full(mesh,eta,eps):
    rad=3.5
    solver=Radial(mesh,"tensor",0.,eta,rad)
    field=real_state(mesh,eta,eps,rad)
    n0=background("massive")[0]
    stride=int(np.ceil(.004*mesh/.25))
    dt=.004/stride
    series=[]
    for tick in range(200*stride+1):
        if tick%stride==0:
            num=field[7,:5]/(np.sqrt(1+field[0,:5])*(1+field[1,:5]))
            series.append([center(np.log(num/n0)),center(field[5])])
        if tick%(40*stride)==0:
            guard()
        if tick==200*stride:
            break
        a=solver.rhs(field)
        b=solver.rhs(field+dt*a/2)
        c=solver.rhs(field+dt*b/2)
        d=solver.rhs(field+dt*c)
        field+=dt/6*(a+2*b+2*c+d)
    assert np.isfinite(field).all()
    return np.array(series)


def test(eta):
    seal=json.loads((HERE/"held-packet-freeze.json").read_text())
    for name,stamp in {**seal["sources"],**seal["method"]}.items():
        assert bridge.sha(HERE/name)==stamp
    table_rows=[]
    results={}
    errors={}
    for mesh in (320,480):
        signed={}
        for inc in (.01,.005):
            a,b=[full(mesh,eta,sgn*inc) for sgn in (1,-1)]
            signed[inc]=(a-b)/(2*inc)
        best=(4*signed[.005]-signed[.01])/3
        results[mesh]=best
        errors[mesh]=np.max(abs(best-signed[.005]),axis=0)
        bridge.archive(HERE/f"held-real-q{eta:g}-{mesh}.npz",wide=signed[.01],narrow=signed[.005],richardson=best,
                       seal=bridge.sha(HERE/"held-packet-freeze.json"))
    for idx,name in enumerate(("number","field")):
        target=results[480][:,idx]
        scale=max(abs(target))
        one,two=[bridge.read(HERE/f"held-prediction-q{eta:g}-{mesh}.npz")["wave"][:,idx] for mesh in (160,320)]
        residual=max(abs(two-target))/scale
        grid=max(abs(results[320][:,idx]-target))/scale
        predgrid=max(abs(two-one))/scale
        strength=errors[480][idx]/scale
        budget=residual+grid+predgrid+strength
        ix=int(np.argmax(abs(target)))
        table_rows.append(dict(eta=eta,channel=name,measured_signed_peak=target[ix],time=.004*ix,prediction_at_peak=two[ix],
                               model_residual=residual,full_grid=grid,predicted_grid=predgrid,finite_amplitude=strength,
                               summed_budget=budget,passes=budget<=TOL))
    table(f"held-result-q{eta:g}.csv",table_rows)
    print(eta,[(row["channel"],row["summed_budget"]) for row in table_rows],flush=True)


if __name__=="__main__":
    if sys.argv[1]=="freeze":
        freeze()
    else:
        test(float(sys.argv[1]))

