from source import *


def response(mesh,model,basis,gain,eta,k,seed):
    n0=background(model)[0]
    size=3.5
    solver=Radial(mesh,basis,gain,eta,size)
    base=state(mesh,model,basis,gain,eta,k,seed,0.,size)
    dirs=[]
    for inc in (.001,.002):
        dirs.append((state(mesh,model,basis,gain,eta,k,seed,inc,size)-state(mesh,model,basis,gain,eta,k,seed,-inc,size))/(2*inc))
    variation=(4*dirs[0]-dirs[1])/3
    bb,qq,hh,_=profile(solver.x,k)
    variation[5]=hh*np.sqrt(n0) if seed=="scalar" else 0
    variation[7]=n0*bb if seed=="density" else 0
    variation[9]=eta*n0*qq if seed=="density" else 0
    arr=base+1e-15j*variation
    rhs=solver.rhs(arr)
    aa=1+arr[0]
    cc=1+arr[1]
    nn=arr[7]/(np.sqrt(aa)*cc)
    ss=solver.diff(arr[5],solver.d1)/np.sqrt(aa)
    dd=arr[9]/(solver.x**2*cc)
    en,pr,pt=material(arr[5],0.,ss,nn,0.,dd,basis)[:3]
    trace=-en+pr+2*pt
    if basis=="tensor":
        bw=nn+gain*(nn**2-nn*(en+2*pr)/2)
        cross=-gain*nn*ss
        ap=1+gain*(ss**2-(en+pr+2*pt)/2)
    else:
        bw=nn*(1-gain*trace/2)
        cross=0.
        ap=1-gain*trace
    force=rhs[8]/np.sqrt(aa)
    fs=rhs[6]
    current=cc*(bw*force+cross*fs)
    foc=center(rhs[2]/aa+2*rhs[3]/cc)
    density=foc-3*center(current[:5]/solver.x[:5])/center(arr[7])
    scalar=center(ap*fs+cross*force)/np.sqrt(n0)
    return -np.imag([density,scalar])/1e-15


def main():
    forecast=frozen()
    rows=[]
    for row in forecast["rows"]:
        model,basis,gain,eta,k=[row[key] for key in ("model","basis","gain","eta","k")]
        for col,seed in enumerate(SEEDS):
            got=response(640,model,basis,gain,eta,k,seed)
            for idx,output in enumerate(SEEDS):
                ref=row["omega2"][idx][col]
                err=abs(got[idx]-ref)
                rel=err/abs(ref) if ref else None
                rows.append(dict(model=model,basis=basis,gain=gain,eta=eta,k=k,input=seed,output=output,reference=ref,actual=got[idx],
                                 absolute=err,relative=rel,status=("pass" if rel<=TOL else "miss") if rel is not None else ("exact_null" if err==0 else "absolute_null_only")))
    table("conditioned-axis.csv",rows)
    print(len(rows),{label:sum(item["status"]==label for item in rows) for label in ("pass","miss","exact_null","absolute_null_only")})


if __name__=="__main__":
    main()

