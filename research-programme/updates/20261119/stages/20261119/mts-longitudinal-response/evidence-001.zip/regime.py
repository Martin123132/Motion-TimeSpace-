from source import *
import sympy as sy
from scipy.constants import physical_constants, c, G, hbar, electron_volt, parsec, epsilon_0


def check():
    n,hcurv,g1,g2,eta,k,shape=sy.symbols("n b2 g1 g2 eta k v",real=True)
    g=g1+g2
    en=n-g*n**2/4
    press=-g*n**2/4
    ww=n+g*n**2/2
    electric=eta*n/3
    n2=hcurv-en*n/3
    grad=-g*n2/2-g1*electric**2/4
    focus=en+3*press+6*ww*grad/n-3*ww*eta*(1-g1*n/2)*electric/n
    slow=sy.diff(focus,n)*n-sy.diff(focus,hcurv)*n*k**2/6
    weak=slow.subs({g1:shape*g1,g2:shape*g2}).series(shape,0,2).removeO().subs(shape,1).expand()
    assert sy.simplify(weak-((1-eta**2)*n+g*n*k**2/2-eta**2*n**2*(g1/3+g2)))==0
    ar,ac,ratio=sy.symbols("a_R a_C ratio",real=True)
    subs={g1:16*ac*ratio,g2:8*(ar-2*ac/3)*ratio}
    d0=12*ar*ratio*k**2
    d2=-4*ac*ratio*k**2
    assert sy.simplify((g*k**2/2).subs(subs)-(d0-4*d2)/3)==0
    assert sy.simplify((g1/3+g2).subs(subs)-8*ar*ratio)==0
    return str(weak)


def main():
    guard()
    weak=check()
    root=OLD.parent
    scale_file=root/"mts-two-radius-pressure-clock-20261119"/"physical-clock-scale.json"
    cap_file=root/"source-intake/functional_rg/4943/interior_stability_benchmarks.csv"
    parent_doc=next(root.glob("4878-*.md"))
    assert bridge.sha(cap_file)=="3c49fdc86490eb936c27fc954b420ab1205fa2e6211e87507cc33cec7f64e3af"
    sc=json.loads(scale_file.read_text())
    with cap_file.open(newline="") as stream:
        cap=list(csv.DictReader(stream))
    ar=max(float(row["abs_aR_control_cap"]) for row in cap)
    ac=max(float(row["abs_aC_control_cap"]) for row in cap)
    energy=physical_constants["Planck mass"][0]*c**2/(electron_volt*np.sqrt(8*np.pi))
    ratio=(sc["example_mass_eV"]/energy)**2
    gamma=8*(ar+4*ac/3)*ratio
    ell=sc["length_pc"]*parsec
    n=background("ordinary")[0]
    eta=.8
    span=3.24
    beta=.01
    rho=c*c*n/(4*np.pi*G*ell**2)
    mp=1.67262192595e-27
    def bounds(required):
        wave=np.sqrt(2*((required/span)**2/n-(1-eta**2))/gamma)
        length=2*np.pi*ell/wave
        return dict(k=wave,lambda_m=length,one_particle_mass_limit_kg=rho*length**3,protons_per_wavelength_cube=rho*length**3/mp,
                    abs_d0=12*ar*ratio*wave**2,abs_d2=4*ac*ratio*wave**2)
    maxk=np.sqrt(beta/(max(12*ar,4*ac)*ratio))
    bound=5*beta/3
    rr=1-eta**2
    examples={}
    for key,amp in (("neutral",0.),("retained",eta),("balanced",1.)):
        examples[key]={"eta":amp,"minimal_growth_over_n":1-amp**2,"first_order_gravity_multiplier_change_bound":bound}
    bound_mass=span*np.sqrt(n*(rr+bound)+eta**2*n*n*8*ar*ratio)
    control=dict(hash_4878=bridge.sha(parent_doc),hash_4943_caps=bridge.sha(cap_file),hash_scale=bridge.sha(scale_file),
                 stated_source_proton_mass="2022 CODATA https://www.physics.nist.gov/cuu/pdf/wall_2022.pdf",
                 density_geometric=n,density_equivalent_kg_m3=rho,length_unit_m=ell,charge_to_mass_SI=eta*np.sqrt(4*np.pi*epsilon_0*G),
                 g_abs_cap_correlated=gamma,prior_component_triangle=2.5523906183973274e-45+1.2761953091990767e-45,
                 derivative_tolerance=beta,max_k_at_saturated_parent_caps=maxk,min_wavelength_at_saturated_caps_m=2*np.pi*ell/maxk,
                 max_abs_change_in_gravity_over_newton=bound,max_local_remainder_for_resummed_comparator_only=5*beta**2/(3*(1-beta)),
                 max_static_rate_times_window=bound_mass,baseline_static_rate_times_window=span*np.sqrt(n*rr),
                 largest_cosh_from_rest=np.cosh(bound_mass),baseline_cosh_from_rest=np.cosh(span*np.sqrt(n*rr)),
                 mass_particle_spacing_m=(mp/rho)**(1/3),max_critical_waterbag_halfwidth_m_s=c*np.sqrt(n*gamma/2),
                 extrapolated_one_instability_time=bounds(1.),extrapolated_efold_from_rest=bounds(np.arccosh(np.e)),
                 charged_intercept_bound=eta*eta*n*n*8*ar*ratio,ordinary_linear_identity=weak,controls=examples)
    savejson("regime.json",control)
    print(json.dumps(control,indent=2))


if __name__=="__main__":
    main()

