from propagate import initial
from ordinary_evolution import Ordinary
from source import *
from scipy.integrate import solve_ivp
from scipy.special import j1


def curvature_weights(mesh):
    nodes=(np.arange(5)+.5)**2
    return mesh**2*sum(np.eye(5)[idx]*sum(np.prod([-nodes[j] for j in range(5) if j!=idx and j!=omit]) for omit in range(5) if omit!=idx)/np.prod(nodes[idx]-np.delete(nodes,idx)) for idx in range(5))


def strip(mesh,k,eta,kind):
    model="massive"
    radius=3.5
    basis="tensor"
    eps=1e-7
    solver=Radial(mesh,basis,0.,eta,radius)
    if kind=="full":
        arr=initial(mesh,basis,0.,eta,k,"scalar","tangent",radius)
    else:
        arr=state(mesh,"ordinary",basis,0.,eta,k,"density",0.,radius).astype(complex)
        n,field=background(model)
        arr[5]=field(solver.x)+1j*eps*np.sqrt(n)*profile(solver.x,k)[2]
    reduced=Ordinary(mesh,eta,basis,0.,radius)
    slots=[0,1,2,3,4,7,8,9]
    def rhs(vec):
        if kind=="full":
            return solver.rhs(vec)
        out=np.empty_like(vec)
        out[slots]=reduced.rhs(vec[slots])
        aa,cc=1+vec[0],1+vec[1]
        dr,dc,dh=solver.diff(vec[[0,1,5]],solver.d1)
        out[5]=vec[6]
        out[6]=(solver.diff(solver.x*vec[5],solver.d2,True)/solver.x+(dc/cc-dr/(2*aa))*dh)/aa-vec[5]+(vec[2]/aa+2*vec[3]/cc)*vec[6]
        return out
    count=int(np.ceil(.004*mesh/.25))
    dt=.004/count
    wts=curvature_weights(mesh)
    bank=[]
    for tick in range(200*count+1):
        if tick%count==0:
            aa=np.sqrt(1+arr[0,:5])
            cc=1+arr[1,:5]
            w=arr[8,:5]/aa
            h,hdot=center(arr[5]),center(arr[6])
            h2=wts@(arr[5,:5]-arr[5,0])
            ac=center(aa)
            restlap=6*h2/ac**2+3*center(w/solver.x[:5])*hdot/ac
            number=center(np.log(arr[7,:5]/(aa*cc*background(model)[0])))
            bank.append([number,h,hdot,restlap])
        if tick%(40*count)==0:
            guard()
        if tick==200*count:
            break
        a=rhs(arr)
        b=rhs(arr+dt*a/2)
        c=rhs(arr+dt*b/2)
        d=rhs(arr+dt*c)
        arr+=dt/6*(a+2*b+2*c+d)
    vals=np.array(bank)
    assert np.isfinite(vals).all() and np.isfinite(arr).all()
    return vals


def transport(wave,eta,time,spatial):
    n0=background("massive")[0]
    bank=make_interp_spline(time,wave,k=5,axis=0)
    def rate(tt,v):
        ell,theta,h,dot=v
        sig=bank(tt)
        if not spatial:
            h,dot=sig[1:3]
        return [theta,theta**2/3+(1-eta**2)*n0*np.exp(ell)+2*dot**2-h**2,
                v[3],theta*v[3]-v[2]+sig[3] if spatial else 0*v[2]]
    run=solve_ivp(rate,(0.,time[-1]),np.array([0.,0.,wave[0,1],0.],dtype=complex),method="DOP853",t_eval=time,
                  max_step=.009,rtol=2e-13,atol=1e-22)
    assert run.success
    return run.y


def flat(time,k):
    n0,field=background("massive")
    node,weight=np.polynomial.legendre.leggauss(64)
    u=(1+node)/2
    w=weight/2
    def initial_deriv(y):
        return field(y)+y*field(y,1)
    def base(t):
        z=t*np.sqrt(1-u*u)
        ratio=np.full_like(z,.5)
        np.divide(j1(z),z,out=ratio,where=z!=0)
        return initial_deriv(t)-t*t*np.dot(w,initial_deriv(t*u)*ratio)
    h=np.array([base(t) for t in time])
    freq=np.sqrt(1+k*k)
    psi=h+1e-7j*np.sqrt(n0)*np.cos(freq*time)
    dh=make_interp_spline(time,h,k=5).derivative()(time)-1e-7j*np.sqrt(n0)*freq*np.sin(freq*time)
    return np.stack((0*psi,psi,dh,0*psi),axis=1)


def score(mesh,k,eta):
    time=np.arange(201)*.004
    full=strip(mesh,k,eta,"full")
    test=strip(mesh,k,eta,"fixed")
    clear=flat(time,k)
    solutions={}
    for name,wave,use in (("scalar_history",full,False),("rest_laplacian",full,True),("flat",clear,False),("fixed_GR",test,False)):
        sol=transport(wave,eta,time,use)
        solutions[name]=np.stack((sol[0],sol[2] if use else wave[:,1]),axis=1)
    truth=full[:,:2]
    stamp=bridge.sha(HERE/"SCALAR-CONTROL.md")
    dest=HERE/f"scalar-controls-q{eta:g}-k{k:g}-{mesh}.npz"
    bridge.archive(dest,time=time,full=full,fixed=test,**solutions,protocol=stamp)
    rows=[]
    for name,sol in solutions.items():
        for idx,part in enumerate(("number","field")):
            val=(sol[:,idx]-sol[0,idx]).imag/1e-7
            ref=(truth[:,idx]-truth[0,idx]).imag/1e-7
            err=float(max(abs(val-ref)))
            scale=float(max(abs(ref)))
            rows.append(dict(mesh=mesh,k=k,eta=eta,method=name,channel=part,actual_end=ref[-1],predicted_end=val[-1],
                             absolute=err,relative=err/scale,peak_target=scale,passes=err<=TOL*scale,
                             uses_readout_own_field=name=="scalar_history" and idx==1))
    return rows


if __name__=="__main__":
    eta=float(sys.argv[1])
    rows=[]
    for mesh in (160,320):
        for k in (4.,24.):
            rows.extend(score(mesh,k,eta))
            print(eta,mesh,k,flush=True)
    table(f"scalar-controls-q{eta:g}.csv",rows)

