from source import *
import sympy as sy


@lru_cache(maxsize=1)
def jets():
    hh,pi,ss,nn,ww,dd=sy.symbols("h P s n w D",real=True)
    g1,g2,eta,b2,h2=sy.symbols("g1 g2 eta b2 h2",real=True)
    lor=sy.sqrt(1+ww**2)
    en=(pi**2+ss**2+hh**2+dd**2)/2+nn*lor
    pr=(pi**2+ss**2-hh**2-dd**2)/2+nn*ww**2/lor
    pt=(pi**2-ss**2-hh**2+dd**2)/2
    flux=nn*ww-pi*ss
    ham=en-g1*(en**2+pr**2+2*pt**2-2*flux**2)/4-g2*(-en+pr+2*pt)**2/4
    zero={pi:0,ss:0,ww:0,dd:0}
    def deriv(*var):
        return sy.diff(ham,*var).subs(zero) if var else ham.subs(zero)
    rho=deriv()
    press=nn*deriv(nn)-rho
    n2=b2-rho*nn/3
    d1=eta*nn/3
    hn2=deriv(nn,nn)*n2+deriv(nn,hh)*h2+2*deriv(nn,ss,ss)*h2**2+deriv(nn,dd,dd)*d1**2/2
    fs=6*deriv(ss,ss)*h2-deriv(hh)
    vals=[rho+3*press,6*deriv(ww,ww)*hn2/nn,-3*deriv(ww,ww)*eta*deriv(dd,dd)*d1/nn,
          -6*deriv(ww,pi,ss)*h2*fs/nn,deriv(pi,pi)*fs]
    return sy.lambdify((nn,b2,hh,h2,g1,g2,eta),vals,modules="numpy",cse=True)


COMP=("focusing","chemical_gradient","electric","entrained_scalar","scalar_accel")


def acceleration(model,basis,gain,eta,k,seed,eps):
    dens,field=background(model)
    amp=np.sqrt(dens)
    nn=dens
    b2=-6*dens/25
    hh=field(0.).item()
    h2=field(0.,2).item()/2
    if seed=="density":
        nn+=dens*eps
        b2-=dens*eps*k**2/6
    else:
        hh+=eps*amp
        h2-=eps*amp*k**2/6
    parts=np.array(jets()(nn,b2,hh,h2,gain if basis=="tensor" else 0,gain if basis=="trace" else 0,eta))
    parts[-1]/=amp
    return parts


def matrix(model,basis,gain,eta,k):
    parts=np.stack([acceleration(model,basis,gain,eta,k,seed,1e-22j).imag/1e-22 for seed in SEEDS],axis=1)
    return -np.stack([parts[:-1].sum(axis=0),parts[-1]]),parts


def predict():
    guard()
    rows=[]
    roots=[]
    for model in ("ordinary","massive"):
        dens,field=background(model)
        for basis,gain in CASES:
            for eta in (0.,.8):
                low,_=matrix(model,basis,gain,eta,0)
                one,_=matrix(model,basis,gain,eta,1)
                speed=one-low
                powers=[np.linalg.det(speed),low[0,0]*speed[1,1]+low[1,1]*speed[0,0]-low[0,1]*speed[1,0]-low[1,0]*speed[0,1],np.linalg.det(low)]
                positive=[float(np.sqrt(val.real)) for val in np.roots(np.trim_zeros(powers,"f")) if abs(val.imag)<1e-9 and val.real>1e-12]
                roots.append(dict(model=model,basis=basis,gain=gain,eta=eta,k_zero=positive,intercept=low.tolist(),k2=speed.tolist(),density=dens,field=float(field(0)),field2=float(field(0,2)/2)))
                for k in WAVES:
                    result,parts=matrix(model,basis,gain,eta,k)
                    assert np.allclose(result,low+speed*k*k,rtol=5e-13,atol=1e-12)
                    eig=np.linalg.eigvals(result)
                    assert max(abs(eig.imag))<1e-10
                    rows.append(dict(model=model,basis=basis,gain=gain,eta=eta,k=k,omega2=result.tolist(),
                                     slow_fast=sorted(map(float,eig.real)),accel_parts=parts.tolist()))
    savejson("forecast.json",dict(components=COMP,producer={name:bridge.sha(HERE/name) for name in ("centre_jet.py","source.py","PROTOCOL.md")},
                                  parent=LOCK,roots=roots,rows=rows))
    print("frozen",len(rows),bridge.sha(HERE/"forecast.json"),flush=True)


if __name__=="__main__":
    predict()

