from pathlib import Path
import os
import sys
import json
import csv
from functools import lru_cache
for thread in ("OPENBLAS_NUM_THREADS","OMP_NUM_THREADS","MKL_NUM_THREADS","NUMEXPR_NUM_THREADS"):
    os.environ[thread]="1"
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
OLD=HERE.parent/"mts-self-consistent-contact-20261119"
sys.path.insert(0,str(OLD))
from contact_model import material,Forecaster,bridge,guard as parent_guard,TOL,np
from evolve_contact import Evolution
from scipy.interpolate import make_interp_spline
from scipy.special import betainc,spherical_jn
from scipy.integrate import cumulative_simpson
from scipy.optimize import brentq

LOCK="3ea60948784cc68c11b0264702af236e1b5d6dff49d01d9710c17176f75d4076"
CASES=(("tensor",0.),("tensor",-.5),("tensor",.5),("trace",-.5),("trace",.5))
WAVES=(0.,1.,4.,12.,24.,48.,80.)
SEEDS=("density","scalar")


def guard():
    parent_guard()
    assert bridge.sha(OLD/"seal.json")==LOCK
    if (HERE/"STOP-REQUESTED").exists():
        raise SystemExit("owner hold")


def savejson(name,data):
    with (HERE/name).open("x") as stream:
        json.dump(data,stream,indent=2,allow_nan=False)


def table(name,rows):
    with (HERE/name).open("x",newline="") as stream:
        writer=csv.DictWriter(stream,fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


@lru_cache(maxsize=2)
def background(case):
    seed=Forecaster(7680,case)
    axis=seed.rad
    field=make_interp_spline(np.r_[-axis[12:0:-1],axis],np.r_[seed.initial[0,12:0:-1],seed.initial[0]],k=5)
    return float(seed.initial[4,0]),field


def frozen():
    source=json.loads((HERE/"forecast.json").read_text())
    for name,digest in source["producer"].items():
        assert bridge.sha(HERE/name)==digest
    return source


def profile(rad,k):
    arg=np.clip((rad-1.5)/1.5,0,1)
    win=1-betainc(9,9,arg)
    from scipy.special import beta
    slope=-arg**8*(1-arg)**8/(1.5*beta(9,9))
    mono=spherical_jn(0,k*rad)
    bessel=spherical_jn(1,k*rad)
    div=bessel/k if k else rad/3
    return win*mono+slope*div,win*rad**2*div,win*mono,slope*mono-k*win*bessel


def state(mesh,model,basis,gain,eta,k,seed,eps,horizon=24):
    dens,field0=background(model)
    amp=np.sqrt(dens)
    ratio=max(4,int(np.ceil(1280/mesh)))
    if ratio%2:
        ratio+=1
    stop=int(horizon*mesh)
    grid=np.arange(stop*ratio+1)/(ratio*mesh)
    bseed,qseed,hseed,sseed=profile(grid,k)
    bb=dens*(np.maximum(1-(grid/5)**2,0)**6+(eps*bseed if seed=="density" else 0))
    charge=eta*(.002*betainc(1.5,7,np.minimum((grid/5)**2,1))+(eps*dens*qseed if seed=="density" else 0))
    hh=field0(grid)+(eps*amp*hseed if seed=="scalar" else 0)
    slope=field0(grid,1)+(eps*amp*sseed if seed=="scalar" else 0)
    inv=np.zeros_like(grid)
    inv[1:]=1/grid[1:]
    electric=charge*inv**2
    fac=np.ones_like(grid)
    for iteration in range(9):
        root=np.sqrt(fac)
        mat=material(hh,0.,root*slope,bb*root,0.,electric,basis)
        mass=cumulative_simpson(grid**2*(mat[0]+gain*mat[4]),x=grid,initial=0)
        newfac=1-2*mass*inv
        if np.max(abs(newfac-fac))<3e-16:
            break
        fac=newfac
    assert np.max(abs(fac-newfac))<2e-14
    picks=np.arange(ratio//2,stop*ratio,ratio)
    xx=grid[picks]
    rootmass=mass[picks]
    zero=np.zeros(stop)
    result=np.stack((2*rootmass/(xx*newfac[picks]),zero,zero,zero,rootmass/xx**3,hh[picks],zero,bb[picks],zero,charge[picks]))
    return result


def center(values):
    nodes=np.arange(5)+.5
    weights=np.array([np.prod([-other**2/(node**2-other**2) for other in nodes if other!=node]) for node in nodes])
    return np.asarray(values)[...,:5]@weights


class Radial(Evolution):
    def __init__(self,mesh,basis,gain,eta,horizon=24):
        super().__init__(mesh,basis,gain)
        self.eta=eta
        self.x=self.x[:int(mesh*horizon)]

    def rhs(self,state):
        ans=self.rates(state)
        if self.eta!=.8:
            aa=np.sqrt(1+state[0])
            cc=1+state[1]
            electric=state[9]/(self.x**2*cc)
            mat=material(state[5],state[6],self.diff(state[5],self.d1)/aa,state[7]/(aa*cc),state[8]/aa,electric,self.basis)
            ans[8]+=(self.eta-.8)*aa*(electric+self.strength*mat[12])
            ans[9]*=self.eta/.8
        return ans

