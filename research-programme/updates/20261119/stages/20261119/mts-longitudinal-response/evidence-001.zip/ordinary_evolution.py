from source import *
from scipy.ndimage import correlate1d


def initial(mesh,wave,eps,eta,basis,delta,rmax):
    ratio=6
    xx=np.arange(round(mesh*rmax)*ratio+1)/(mesh*ratio)
    inv=np.zeros_like(xx)
    inv[1:]=1/xx[1:]
    dens=background("ordinary")[0]
    bp,qp,_,_=profile(xx,wave)
    bb=dens*(np.maximum(1-(xx/5)**2,0)**6+eps*bp)
    q=eta*(.002*betainc(1.5,7,np.minimum((xx/5)**2,1))+eps*dens*qp)
    electric=q*inv**2
    if eta==1:
        mass=q-q*q*inv/2
    else:
        mass=0*xx
        for _ in range(9):
            root=np.sqrt(1-2*mass*inv)
            mass=cumulative_simpson(xx**2*(bb*root+electric**2/2),x=xx,initial=0.)
    fac=1-2*mass*inv
    root=np.sqrt(fac)
    rn=bb*root
    z=-rn**2/4
    if basis=="tensor":
        z-=rn*electric**2/4+electric**4/4
    weight=cumulative_simpson(xx*bb/root,x=xx,initial=0.)
    dm=np.exp(-weight)*cumulative_simpson(np.exp(weight)*xx**2*z,x=xx,initial=0.)
    idx=np.arange(ratio//2,len(xx)-1,ratio)
    zero=np.zeros(len(idx))
    return np.stack(((2*mass*inv/fac+delta*2*dm*inv/fac**2)[idx],zero,zero,zero,
                     ((mass+delta*dm)*inv**3)[idx],bb[idx],zero,q[idx]))


class Ordinary:
    def __init__(self,mesh,eta,basis,delta,rmax):
        self.x=(np.arange(round(mesh*rmax))+.5)/mesh
        self.weights=np.array([-1.,9.,-45.,0.,45.,-9.,1.])*mesh/60
        self.eta=eta
        self.delta=delta
        self.ten=delta if basis=="tensor" else 0.

    def diff(self,vec,odd=False):
        if odd:
            ext=np.concatenate((-vec[...,2::-1],vec),axis=-1)
            return correlate1d(ext,self.weights,axis=-1,mode="nearest")[...,3:]
        return correlate1d(vec,self.weights,axis=-1,mode="reflect")

    def rhs(self,arr):
        rad,ang,kr,kt,m3,b,imp,charge=arr
        xx=self.x
        aa=1+rad
        cc=1+ang
        length=np.sqrt(aa)
        bb=np.sqrt(cc)
        n=b/(length*cc)
        w=imp/length
        lor=np.sqrt(1+w*w)
        d=charge/(xx**2*cc)
        g=self.delta
        t=self.ten
        extra=-g*(n/lor)**2/4-t*(n*d*d/lor+d**4)/4
        press=n*w*w/lor-d*d/2+g*n*n*(-1/(4*lor**2)+w*w/(2*lor**4))+t*(n*d*d*w*w/lor**3+d**4)/4
        pt=d*d/2-g*n*n/(4*lor**2)-t*n*d*d/(2*lor)-3*t*d**4/4
        en=n*lor+d*d/2+extra
        flux=n*w
        transport=n*w*(1/lor+g*n/(2*lor**4)+t*d*d/(4*lor**3))
        proper=-xx*kt/bb
        ar,ac=self.diff(arr[:2])
        rx=bb+xx*ac/(2*bb)
        er=m3/bb**3
        result=np.empty_like(arr)
        result[0]=-2*kr
        result[1]=-2*kt
        result[2]=aa*(en-press+2*pt-2*er)-kr**2/aa
        result[3]=cc*(er+press-(kt/cc)**2)
        result[4]=-cc*(press*proper+flux*rx/length)/xx
        flow=cc*transport
        result[5]=-self.diff(flow,True)-2*flow/xx
        result[6]=-w*self.diff(imp,True)/(length*lor)+ar*(imp/aa)**2/(2*lor)+self.diff(g*n/(2*lor**2)+t*d*d/(4*lor))+self.eta*length*(d-t*(n*d/(2*lor)+d**3))
        result[7]=-self.eta*xx**2*flow
        return result


def evolve(mesh,k,eta,basis,eps,step=1e-7j,rmax=5.):
    guard()
    system=Ordinary(mesh,eta,basis,step,rmax)
    field=initial(mesh,k,eps,eta,basis,step,rmax)
    stride=int(np.ceil(.02*mesh/.55))
    dt=.02/stride
    history=[]
    errors=[]
    for tick in range(162*stride+1):
        if tick%stride==0:
            den=field[5]/(np.sqrt(1+field[0])*(1+field[1]))
            history.append(center(np.log(den[:5]/background("ordinary")[0])))
            if tick%(10*stride)==0:
                xx=system.x
                weight=np.maximum(1-((xx-1.5)/1.3)**2,0)**6
                grad=np.maximum(1-((xx-1.5)/1.3)**2,0)**5*(-12*(xx-1.5)/1.3**2)
                value=np.sum(grad*field[7]+weight*eta*xx**2*field[5])/mesh
                scale=np.sum(weight*abs(eta*xx**2*field[5]))/mesh
                errors.append(value/scale if scale else 0.)
                guard()
        if tick==162*stride:
            break
        a=system.rhs(field)
        b=system.rhs(field+dt*a/2)
        c=system.rhs(field+dt*b/2)
        d=system.rhs(field+dt*c)
        field+=dt/6*(a+2*b+2*c+d)
    assert np.isfinite(field).all()
    return np.array(history),np.array(errors)


def run(basis,mesh):
    seal=json.loads((HERE/"shell-forecast.json").read_text())
    for name,stamp in seal["files"].items():
        assert bridge.sha(HERE/name)==stamp
    rows=[]
    for eta,k in ((.8,0.),(.8,4.),(.8,24.),(1.,0.),(1.,4.),(1.,24.)):
        ref=bridge.read(HERE/f"shell-prediction-q{eta:g}-k{k:g}.npz")
        times=np.arange(163)*.02
        eps=.005
        step=1e-7j
        (pos,e1),(neg,e2)=[evolve(mesh,k,eta,basis,sign*eps,step) for sign in (1,-1)]
        waveform=(pos-neg)/(2*eps)
        corr=(waveform-waveform[0]).imag/step.imag
        reference=np.interp(times,ref["time"],ref["wave"][1 if basis=="tensor" else 2])
        mini=np.interp(times,ref["time"],ref["wave"][0])
        reference-=reference[0]
        mini-=mini[0]
        observed=waveform.real-waveform[0].real
        err=max(abs(corr-reference))
        rel=err/max(abs(reference))
        rows.append(dict(basis=basis,mesh=mesh,eta=eta,k=k,predicted=reference[-1],measured=corr[-1],abs_error=err,
                         relative=rel,unchanged_pass=rel<=TOL,zero_contact_abs=max(abs(observed-mini)),
                         charge_weak_abs=max(max(abs(e1)),max(abs(e2)))))
        bridge.archive(HERE/f"ordinary-q{eta:g}-{basis}-{mesh}-k{k:g}.npz",time=times,analytic=reference,wave=corr,
                       ordinary=observed,ordinary_analytic=mini,gauss_plus=e1,gauss_minus=e2)
        print(basis,mesh,eta,k,rel,flush=True)
    table(f"all-time-{basis}-{mesh}.csv",rows)


if __name__=="__main__":
    run(sys.argv[1],int(sys.argv[2]))

