from source import *
from scipy.integrate import solve_ivp


def calculate(eta,k,seed,times):
    dens=background("ordinary")[0]
    n=dens*(1+seed)
    b2=-6*dens/25-dens*seed*k**2/6
    n3=n/3
    n5=b2/5
    q3,q5=eta*n3,eta*n5
    m5=n5+(eta**2-1)*n*n3/5
    def rate(time,v):
        axis,bend,vel,vel3,y1,dy1,y2,dy2=v
        gamma2=(eta**2-1)*n3-eta*q3/axis
        phi2=eta*q3/(2*axis)
        f1=(eta**2-1)*n3/axis**2
        f3=(-m5+eta*q5+eta*q3*gamma2)/axis**2-2*bend/axis*f1+q3**2/axis**3
        nu=n/axis**3
        lap=6*(b2+n*(gamma2-5*bend/axis))/axis**5
        forcing=-lap/2-nu**2
        common=lambda value,rate_y: -2*vel/axis*rate_y+(1-eta**2)*nu*value+forcing
        return [vel,vel3+phi2*vel,f1,f3+phi2*f1,dy1,common(y1,dy1)-eta**2*nu**2/6,
                dy2,common(y2,dy2)-eta**2*nu**2/2]
    result=solve_ivp(rate,(0.,float(times[-1])),np.array([1,0,0,0,0,0,0,0],dtype=np.result_type(seed,float)),method="DOP853",
                     t_eval=times,rtol=3e-13,atol=1e-18,max_step=.1)
    assert result.success and min(result.y[0].real)>.5
    ell=np.log(n/dens)-3*np.log(result.y[0])
    return np.stack((ell,result.y[4],result.y[6])),result.y[0].real


def main():
    guard()
    times=np.unique(np.r_[np.arange(325)*.01,10.,20.,40.])
    rows=[]
    for eta in (.0,.8,1.):
        for k in (0.,4.,24.):
            a,axis=calculate(eta,k,1e-16j,times)
            wave=a.imag/1e-16
            bridge.archive(HERE/f"shell-prediction-q{eta:g}-k{k:g}.npz",wave=wave,time=times,axis=axis)
            for idx,basis in enumerate(("minimal","tensor","trace")):
                peak=float(wave[idx,-1])
                early=float(wave[idx,np.argmin(abs(times-.8))])
                end=float(wave[idx,np.argmin(abs(times-3.24))])
                rows.append(dict(eta=eta,k=k,channel=basis,response_at_0p8=early,response_at_3p24=end,
                                 mathematical_center_response_at_40=peak,axis_at_40=axis[-1]))
            if eta==1:
                target=json.loads((HERE/"balance-forecast.json").read_text())
                assert np.max(abs(wave[0]-1))<1e-13 and np.max(abs(axis-1))<1e-13
                for idx,name in ((1,"tensor"),(2,"trace")):
                    ref=next(row["mixed_acceleration"] for row in target["rows"] if row["basis"]==name and row["k"]==k)
                    assert max(abs(wave[idx]-times**2*ref/2)) < 1e-9*max(abs(wave[idx]))+2e-15
    table("shell-predictions.csv",rows)
    savejson("shell-forecast.json",dict(equations=bridge.sha(HERE/"shell_transport.py"),rows=bridge.sha(HERE/"shell-predictions.csv"),
                    files={f.name:bridge.sha(f) for f in sorted(HERE.glob("shell-prediction-*.npz"))},parent=LOCK))
    print("shell forecast frozen",bridge.sha(HERE/"shell-forecast.json"))


if __name__=="__main__":
    main()

