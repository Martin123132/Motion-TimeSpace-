from field_checks import load_packet, rec_grid, write
from pair_energy import np, guard, basis, root_values, spherical_jn, factorial2, roots_legendre, harmonics, sl, orbit, RADIUS, MASS
from scipy.interpolate import CubicSpline
import sys


def sky_rule(order):
    polar, weights = roots_legendre(order)
    phase = np.arange(2 * order + 1) * (2 * np.pi / (2 * order + 1))
    sine = np.sqrt(1 - polar[:, None] ** 2)
    sky = np.stack(np.broadcast_arrays(sine * np.cos(phase), sine * np.sin(phase), polar[:, None]), axis=-1).reshape(-1, 3)
    return sky, np.repeat(weights / (2 * len(phase)), len(phase))


def potential_modes(grid, cloud, packet, maximum):
    state = packet["raw"]
    amplitude = grid.spatial(state[0])[0]
    density = (grid.ground[:, None] + amplitude[0]) ** 2 + amplitude[1] ** 2
    angular = (density @ grid.Yw[:, :(maximum + 1) ** 2]) * grid.w[:, None]
    data = []
    for order in range(maximum + 1):
        roots = root_values(order - 1, int(float(packet["vac"]) * grid.count) + 12)
        freq = roots / grid.edge
        modes = basis(order, roots, grid.edge, grid.rad)
        coeff = -(modes.T @ angular[:, sl(order)]) / freq[:, None] ** 2
        data.append((roots, freq, coeff))
    return data


def center_weights(grid, cloud, data, center, radius, style):
    gradient = np.stack(cloud.poly.dcoef) @ cloud.poly.powers_at(center)
    terms = []
    for order, group in enumerate(cloud.poly.groups):
        roots, freq, coeff = data[order]
        if order:
            norm = (.5 * grid.edge ** 3 * (spherical_jn(order, roots) ** 2 - spherical_jn(order - 1, roots) * spherical_jn(order + 1, roots))) ** -.5
        else:
            norm = roots / np.sqrt(.5 * grid.edge ** 3 * (1 - np.sin(2 * roots) / (2 * roots)))
        factors = 3 * spherical_jn(1, radius * freq, derivative=True) if style == "los" else spherical_jn(0, radius * freq)
        weight = norm * freq ** order / factorial2(2 * order + 1) * factors
        for power in range((cloud.poly.degree - order) // 2 + 1):
            terms.extend(weight @ coeff)
            weight = -weight * freq ** 2 / (2 * (power + 1) * (2 * order + 2 * power + 3))
    return -gradient @ (np.array(terms) @ cloud.poly.coeff)


def direct_shell(grid, data, center, radius, sky, weights):
    separation = np.linalg.norm(center)
    step = radius * .00015
    span = separation + 3 * step
    radial = np.linspace(radius - span, radius + span, 17)
    arrays = [basis(order, entry[0], grid.edge, radial) @ entry[2] for order, entry in enumerate(data)]
    curve = CubicSpline(radial, np.column_stack(arrays))
    def first_moment(displacement):
        points = center + (radius + displacement) * sky
        radii = np.linalg.norm(points, axis=1)
        values = harmonics(points / radii[:, None], len(data) - 1)
        potentials = np.sum(values * curve(radii), axis=1)
        return (weights * (potentials - potentials.mean())) @ sky
    return -3 * (first_moment(-2 * step) - 8 * first_moment(-step) + 8 * first_moment(step) - first_moment(2 * step)) / (12 * step)


def source_dipole(sky, weights, center, donor, radius, soft, mass):
    delta = donor - (center + radius * sky)
    dist = np.linalg.norm(delta, axis=1)
    force = mass * delta / (dist * (dist + soft) ** 2)[:, None]
    return 3 * (weights * np.sum(force * sky, axis=1)) @ sky


def measure(tag):
    packet = load_packet(tag)
    grid, cloud = rec_grid(packet)
    unit = float(packet["length_pc"]) / 1e3
    scale = float(packet["velocity_unit_kms"]) ** 2 / unit
    center = packet["last_body"][0, :3]
    donor = orbit(1)[0](float(packet["time_Gyr"][-1])) / unit
    mass = MASS * float(packet["strength"]) / float(packet["mass_unit_msun"])
    soft = RADIUS / unit
    dist = np.linalg.norm(donor)
    frame = mass * donor / (dist * (dist + soft) ** 2)
    center_source = frame + cloud.satellite_acc(center, donor, soft, mass)
    center_wave = packet["wave_acc"][-1, 0]
    data = potential_modes(grid, cloud, packet, 8)
    sky, weights = sky_rule(28)
    sky_low, weights_low = sky_rule(14)
    rows = []
    for kpc in (1., 4., 8.1, 17.58):
        radius = kpc / unit
        wave = center_weights(grid, cloud, data, center, radius, "los") - center_wave
        check = direct_shell(grid, data, center, radius, sky, weights) - center_wave
        source = source_dipole(sky, weights, center, donor, radius, soft, mass) - center_source
        source_low = source_dipole(sky_low, weights_low, center, donor, radius, soft, mass) - center_source
        vector = (wave + source) * scale
        norm = np.linalg.norm
        rows.append(dict(packet=tag, radius_kpc=kpc, x_kms2_per_kpc=vector[0], y_kms2_per_kpc=vector[1], z_kms2_per_kpc=vector[2],
                         total_norm_kms2_per_kpc=norm(vector), wave_norm_kms2_per_kpc=norm(wave)*scale,
                         external_norm_kms2_per_kpc=norm(source)*scale, signed_wave_fraction=wave @ (wave+source)/norm(wave+source)**2,
                         wave_direct_vector_error=norm(check-wave)/max(norm(wave),1e-30),
                         source_sky_vector_error=norm(source-source_low)/max(norm(source),1e-30)))
    return rows


if __name__ == "__main__":
    guard()
    rows = [row for tag in sys.argv[2:] for row in measure(tag)]
    write(sys.argv[1], rows)
    for row in rows:
        print(row["packet"], row["radius_kpc"], row["total_norm_kms2_per_kpc"], row["wave_direct_vector_error"])
