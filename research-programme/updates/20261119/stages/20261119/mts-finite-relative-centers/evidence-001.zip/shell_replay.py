from tidal_contour import scalar_response,rotation,assembled,inputs
from continuum_cloud import Susceptibility
from field_checks import load_packet,write
from pair_energy import np,HOME,guard
from satellite import BASIS
from scipy.linalg import expm
from scipy.interpolate import CubicSpline
import sys

def replay(label,tier,number):
    tag="potential-"+label+"-"+tier
    ret=load_packet(tag)
    bank=assembled(["orbit-"+label,"angular16-"+label])
    tt=ret["time_Gyr"]/bank["timeunit_Gyr"]
    source_time=bank["time_Gyr"]/bank["timeunit_Gyr"]
    hess,third,trace,tensor=inputs(bank,source_time)
    external=CubicSpline(source_time,tensor)(tt)
    mono=CubicSpline(source_time,trace)(tt)
    system=Susceptibility(str(bank["label"]),int(ret["rank"]),number)
    radial=scalar_response(system.omega0**2,system.rad,tt,mono)
    dt=tt[1]
    assert max(abs(np.diff(tt)-dt))<1e-10
    recorded=np.arange(0,len(tt),max(1,(len(tt)-1)//1024))
    predicted=(2/3)*(radial[recorded]@(system.rad*system.frac))
    covariance=predicted[:,None,None]*np.eye(3)
    pick=ret["self_coeff"]
    reports=[]
    for idx,rad in enumerate(system.rad):
        omega=system.omega[idx]
        rot=rotation(np.array([omega]))
        stiffness=-np.diag([system.kappa2[idx]-3*omega**2]*3+[omega**2]*5)
        matrix=np.block([[-rot,np.eye(8)],[stiffness,-rot]])
        augmented=np.zeros((24,24));augmented[:16,:16]=dt*matrix
        augmented[8,16]=-dt;augmented[12,20]=-2*dt;augmented[14,20]=-2*dt
        for start in (16,20):
            for degree in range(3):
                augmented[start+degree,start+degree+1]=degree+1
        evolution=expm(augmented)
        slope=rad*external+np.einsum("trc,r->tc",pick,system.grad[idx])
        tang=rad*external/2+np.einsum("trc,r->tc",pick,system.side[idx])
        inputs_at=np.concatenate([CubicSpline(tt,curve).c[::-1]*dt**np.arange(4)[:,None,None] for curve in (slope,tang)])
        kicks=np.einsum("ij,jtc->tic",evolution[:16,16:],inputs_at)
        solution=np.zeros((len(tt),16,5))
        for tick in range(len(kicks)):
            solution[tick+1]=evolution[:16,:16]@solution[tick]+kicks[tick]
        coeff=solution[:,:8]
        strength=np.abs(radial[:,idx])/rad+np.linalg.norm(coeff[:,:3],axis=2).sum(axis=1)/rad
        planar=np.linalg.norm(coeff[:,3:6],axis=2).sum(axis=1)/rad
        normal=np.linalg.norm(coeff[:,6:8],axis=2).sum(axis=1)/rad
        quad=4*(coeff[:,0]-.5*coeff[:,2])/15+(coeff[:,4]+coeff[:,6])/5
        covariance+=system.frac[idx]*rad*np.einsum("ta,aij->tij",quad[recorded],BASIS)
        reports.append(dict(label=label,tier=tier,r_over_core=rad/system.core,mass_weight=system.frac[idx],
                            radial_strain_envelope=max(strength),tangential_phase_envelope=max(planar),normal_tilt_envelope=max(normal)))
    stored=ret["covariance"][recorded]
    delta=np.linalg.norm(covariance-stored,axis=(1,2))
    denom=system.inertia
    file=HOME/f"shells-{label}-{tier}-n{number}.npz"
    content=dict(time_Gyr=ret["time_Gyr"][recorded],cov=covariance,direct_mean_change=np.max(np.linalg.norm(covariance,axis=(1,2)))/denom,
                 cq_difference_over_initial_component=max(delta)/denom,peak_radial_strain=max(one["radial_strain_envelope"] for one in reports),
                 finite_radial_nodes=number,source=tag,endpoint_cov_error=np.linalg.norm(covariance[-1]-stored[-1])/denom)
    if file.exists():
        with np.load(file) as old:
            assert all(np.array_equal(value,old[key]) for key,value in content.items())
    else:
        with file.open("xb") as out:
            np.savez_compressed(out,**content)
    write(file.stem+".csv",reports)
    print(file.stem,content["direct_mean_change"],content["cq_difference_over_initial_component"],content["peak_radial_strain"],flush=True)

if __name__=="__main__":
    guard()
    replay(sys.argv[1],sys.argv[2],int(sys.argv[3]))
