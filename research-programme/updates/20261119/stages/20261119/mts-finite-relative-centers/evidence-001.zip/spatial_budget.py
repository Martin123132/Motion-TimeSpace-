from field_checks import load_packet, write
from pair_energy import np, guard
from pathlib import Path
import csv


def comparisons():
    rows = []
    for label in ("cap", "diff"):
        for before, after, changed in (("orbit", "time", "time only"), ("time", "outer", "domain and radial basis"),
                                       ("angular16", "time16", "time only"), ("time16", "outer16", "domain and radial basis")):
            first, last = [load_packet(prefix+"-"+label) for prefix in (before,after)]
            if changed=="time only":
                assert first["count"]==last["count"] and first["edge"]==last["edge"] and first["steps"]!=last["steps"]
            else:
                assert first["steps"]==last["steps"] and first["edge"]!=last["edge"]
            assert first["order"]==last["order"] and first["label"]==last["label"]
            for measure in ("final_relative_pc","final_relative_kms"):
                error=np.linalg.norm(last[measure]-first[measure])
                fraction=error/np.linalg.norm(last[measure])
                rows.append(dict(state=label,changed=changed,before=before,after=after,measure=measure,absolute=error,fraction=fraction,within_20ppm=fraction<=2e-5))
    write("time-and-space.csv",rows)
    return rows


if __name__=="__main__":
    guard()
    print(comparisons())
