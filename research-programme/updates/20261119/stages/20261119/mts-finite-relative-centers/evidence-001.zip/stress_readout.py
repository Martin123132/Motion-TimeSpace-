from pair_energy import np,basis,sl,harmonics,roots_legendre,spherical_jn
from scipy.special import eval_legendre

class StressProbe:
    def __init__(self,grid):
        self.grid=grid
        self.panels=max(52,grid.count)
        self.width=grid.edge/self.panels
        nodes,ww=roots_legendre(8)
        self.unit=(1+nodes)/2
        self.quad=ww/2
        self.rad=((np.arange(self.panels)[:,None]+self.unit)*self.width).ravel()
        self.w=np.tile(self.quad*self.width,self.panels)
        self.radials=self.space(self.rad)
        self.orders=np.repeat(np.arange(2*grid.lmax+1),2*np.arange(2*grid.lmax+1)+1)
        self.degree=np.arange(2*grid.lmax+1)
        self.node,self.weight=roots_legendre(max(32,2*grid.lmax+12))
        self.node=(self.node+1)/2; self.weight/=2
        self.surface=[]
        for order,roots in enumerate(grid.wroots):
            if order:
                norm=np.sqrt(.5*grid.edge**3*(spherical_jn(order,roots)**2-spherical_jn(order-1,roots)*spherical_jn(order+1,roots)))
            else:
                norm=np.sqrt(.5*grid.edge**3*(1-np.sin(2*roots)/(2*roots)))/roots
            self.surface.append(spherical_jn(order,roots,derivative=True)*roots/(grid.edge*norm))

    def space(self,rad):
        return [basis(order,roots,self.grid.edge,rad) for order,roots in enumerate(self.grid.wroots)]

    def density(self,state,matrices):
        grid=self.grid
        coeff=np.empty((2,len(matrices[0]),grid.nh))
        for order,radial in enumerate(matrices):
            selection=sl(order)
            part=state[0,:,selection].reshape(2,grid.count,-1).copy()
            if order==0:
                part[0,:,0]+=grid.coef
            coeff[:,:,selection]=radial@part
        if hasattr(grid,"analyze"):
            space=grid.synth(coeff,grid.lmax)
            return grid.analyze(space[0]**2+space[1]**2,2*grid.lmax)
        space=coeff@grid.Y[:,:grid.nh].T
        return (space[0]**2+space[1]**2)@grid.Yw

    def surface_force(self,state):
        grid=self.grid
        coeff=np.empty((2,grid.nh))
        for order,rim in enumerate(self.surface):
            selection=sl(order)
            part=state[0,:,selection].reshape(2,grid.count,-1).copy()
            if order==0:
                part[0,:,0]+=grid.coef
            coeff[:,selection]=rim@part
        angular=coeff@grid.Y[:,:grid.nh].T
        return -.5*grid.edge**2*((angular[0]**2+angular[1]**2)*grid.aw)@grid.unit

    def source(self,state,donor,soft,mass):
        grid=self.grid
        dist=np.linalg.norm(donor);axis=donor/dist
        den=self.density(state,self.radials)
        rad=self.rad;weights=self.w
        if dist<grid.edge:
            cell=int(dist/self.width)
            lower,upper=cell*self.width,(cell+1)*self.width
            left,right=dist-lower,upper-dist
            alt=np.r_[lower+left*self.unit,dist+right*self.unit]
            aw=np.r_[left*self.quad,right*self.quad]
            keep=np.arange(len(rad))//8!=cell
            den=np.vstack((den[keep],self.density(state,self.space(alt))))
            rad=np.r_[rad[keep],alt];weights=np.r_[weights[keep],aw]
        sky=harmonics(axis,2*grid.lmax)[0]
        step=2e-5
        pert=lambda vec:harmonics(vec/np.linalg.norm(vec),2*grid.lmax)[0]
        tangent=np.stack([(pert(axis+step*each)-pert(axis-step*each))/(2*step) for each in np.eye(3)],axis=1)
        rr=rad[:,None]
        lo=abs(rr-dist);width=2*np.minimum(rr,dist)
        sep=lo+width*self.node
        mu=1-(sep-lo)*(sep+lo)/(2*rr*dist)
        delta=(rr**2-2*rr*dist*mu)/(sep+dist)
        diff=( -rr*mu-delta)/(sep*(sep+soft)**2)-delta*(sep+dist+2*soft)/((sep+soft)*(dist+soft))**2
        measure=width*sep*self.weight/(2*rr*dist)
        potential=delta/((sep+soft)*(dist+soft))*measure
        slope=diff*measure
        force=np.zeros(3)
        rrw=weights*rad**2
        for order in self.degree:
            leg=eval_legendre(order,mu)
            amplitudes=den[:,sl(order)]
            parallel=(rrw*np.sum(slope*leg,axis=1))@amplitudes
            transverse=(rrw*np.sum(potential*leg,axis=1))@amplitudes
            force+=(parallel@sky[sl(order)])*axis+(transverse@tangent[sl(order)])/dist
        return mass*force,self.surface_force(state)
