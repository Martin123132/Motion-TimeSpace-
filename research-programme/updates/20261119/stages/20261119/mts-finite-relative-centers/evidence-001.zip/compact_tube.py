from field_checks import load_packet,write
from pair_energy import np,orbit,MASS,RADIUS,KMS,guard,HOME
from scipy.interpolate import CubicSpline
from scipy.integrate import solve_ivp
from scipy.special import roots_legendre
from math import factorial
import sys

def assembled(tags):
    last=load_packet(tags[-1])
    blocks=[load_packet(tag) for tag in tags]
    keys=("time_Gyr","point_poly","spherical_poly","body","wave_center","wave_vel")
    for key in keys:
        stack=[]
        for idx,block in enumerate(blocks):
            assert block["degree"]==last["degree"] and block["label"]==last["label"]
            if idx+1<len(blocks):
                assert blocks[idx+1]["parent"]==__import__("hashlib").sha256((HOME/(tags[idx]+".npz")).read_bytes()).hexdigest()
                final=blocks[idx+1]["time_Gyr"][0]
                mask=block["time_Gyr"]<final-1e-12
            else:
                mask=slice(None)
            stack.append(block[key][mask])
        last[key]=np.concatenate(stack)
    assert last["time_Gyr"][0]==0 and abs(last["time_Gyr"][-1]-5)<1e-12 and (np.diff(last["time_Gyr"])>0).all()
    return last

def derivatives(exponents):
    seq=[tuple(val) for val in exponents.tolist()]
    transform=[]
    for axis in range(3):
        matrix=np.zeros((len(seq),len(seq)))
        for idx,power in enumerate(seq):
            if power[axis]:
                lower=list(power);lower[axis]-=1
                matrix[idx,seq.index(tuple(lower))]=power[axis]
        transform.append(matrix)
    return np.stack(transform)

def satellite(pos,dist,soft,ms):
    ref=np.linalg.norm(dist)
    delta=dist-pos
    rr=np.linalg.norm(delta)
    dr=(pos@pos-2*dist@pos)/(rr+ref)
    axis=delta/rr
    return ms*((-pos-axis*dr)/(ref*(ref+soft)**2)-axis*dr*(rr+ref+2*soft)/((rr+soft)*(ref+soft))**2)

def certificate(label,tags):
    bank=assembled(tags)
    scale=bank["length_pc"]/1000
    tt=bank["time_Gyr"]/bank["timeunit_Gyr"]
    pows=bank["exponents"]
    sph=CubicSpline(tt,bank["spherical_poly"])
    wave=CubicSpline(tt,bank["point_poly"])
    track,distances=orbit(1)
    soft=RADIUS/scale;ms=MASS/bank["mass_unit_msun"]*bank["strength"]
    derivative=derivatives(pows)
    core=float(bank["core"])
    step=np.diff(tt)
    phase=bank["body"][:,0,3:]
    root=np.zeros(len(pows));root[0]=1
    hess=np.einsum("k,ikm,jmn,n->ij",bank["point_poly"][0],derivative,derivative,root,optimize=True)
    harmonic=hess.trace()/3
    assert harmonic>0 and np.linalg.norm(hess-harmonic*np.eye(3))<1e-9
    def motion(time,state):
        pos=state[:3]
        powers=np.prod(pos[None,:]**pows,axis=1)
        force=-(derivative@powers)@wave(time)
        return np.r_[state[3:],force+satellite(pos,track(time*bank["timeunit_Gyr"])/scale,soft,ms)]
    dynamic=solve_ivp(motion,(0.,tt[-1]),np.zeros(6),t_eval=tt,rtol=4e-11,atol=5e-16,method="DOP853")
    assert dynamic.success
    rel=lambda first,second: np.linalg.norm(first-second)/np.linalg.norm(second)
    errors=dict(state=label,steps=len(tt)-1,
                endpoint_point_pc_error=rel(dynamic.y[:3,-1],phase[-1]),
                endpoint_point_speed_error=rel(dynamic.y[3:,-1],bank["body"][-1,1,3:]),
                interpolation_absolute_peak_pc=np.max(np.linalg.norm(dynamic.y[:3].T-phase,axis=1))*scale*1000)
    limits=[]
    coeffs=wave(tt);slope=wave(tt,1)
    controls=np.stack((coeffs[:-1],coeffs[:-1]+step[:,None]*slope[:-1]/3,coeffs[1:]-step[:,None]*slope[1:]/3,coeffs[1:]),axis=1)
    for idx,power in enumerate(pows):
        if list(sorted(power))==[0,0,2]:
            controls[:,:,idx]-=harmonic/2
    amp=np.max(abs(controls),axis=1)
    orbit_time=track.x
    pos=track(orbit_time);vel=track(orbit_time,1)
    span=np.diff(orbit_time)[:,None]/3
    hull=np.stack((pos[:-1],pos[:-1]+span*vel[:-1],pos[1:]-span*vel[1:],pos[1:]),axis=1)
    small=hull.min(axis=1);large=hull.max(axis=1)
    separation=np.linalg.norm(np.maximum(0.,np.maximum(small,-large)),axis=1)/scale
    minimum=[]
    for ta,tb in zip(bank["time_Gyr"][:-1],bank["time_Gyr"][1:]):
        lo=max(0,np.searchsorted(orbit_time,ta,side="right")-1)
        hi=min(len(separation),max(lo+1,np.searchsorted(orbit_time,tb,side="left")+1))
        minimum.append(separation[lo:hi].min())
    for radial_mult,rms_mult in ((1.,np.sqrt(3/17)),(1.,1.),(2.,2.)):
        radius=core*radial_mult
        rms=core*rms_mult
        envelope=.03
        space=np.max(abs(phase))+envelope+radius
        reach=space**pows.sum(axis=1)
        second=np.stack([(first@(other@reach)) for first in derivative for other in derivative],axis=1)
        third=np.stack([first@(other@(last@reach)) for first in derivative for other in derivative for last in derivative],axis=1)
        if min(minimum)<=np.sqrt(3)*space:
            raise ValueError("tube touches donor")
        near=np.asarray(minimum)-np.sqrt(3)*space
        mass=abs(ms)
        second_sat=np.maximum(2*mass/(near+soft)**3,mass/(near*(near+soft)**2))
        third_sat=6*mass/(near+soft)**4+12*mass/(near*(near+soft)**3)+6*mass/(near**2*(near+soft)**2)
        vari=np.linalg.norm(amp@second,axis=1)+second_sat
        lips=np.linalg.norm(amp@third,axis=1)+third_sat
        rates=vari/(2*np.sqrt(harmonic))
        energy=0.;peak=0.
        for duration,rate,lip in zip(step,rates,lips):
            eta=rate*duration
            kernel=duration*np.expm1(eta)/eta if eta else duration
            energy=np.exp(eta)*energy+kernel*lip*rms**2/2
            peak=max(peak,energy)
        bound=peak/np.sqrt(harmonic)
        first_deriv=np.stack([matrix@reach for matrix in derivative],axis=1)
        raw_amp=amp.copy()
        for idx,power in enumerate(pows):
            if list(sorted(power))==[0,0,2]:
                raw_amp[:,idx]+=harmonic/2
        force_cap=np.linalg.norm(raw_amp@first_deriv,axis=1)+2*mass/(near+soft)**2
        step_reach=step*np.linalg.norm(dynamic.y[3:,:-1],axis=0)+.5*step**2*force_cap
        room=np.max(np.max(abs(dynamic.y[:3,:-1]),axis=0)+step_reach)-np.max(abs(phase))
        valid=bound+max(0,room)<envelope
        limits.append(dict(state=label,support_over_R=radial_mult,rms_over_R=rms_mult,
                           conditional_position_bound_pc=bound*scale*1000,conditional_speed_bound_kms=energy*bank["velocity_unit_kms"],
                           bootstrap_room_pc=(envelope-max(0,room))*scale*1000,bootstrap_pass=valid,energy_growth_exponent=step@rates,
                           position_bound_over_finite_separation=bound*scale*1000/np.linalg.norm(bank["final_relative_pc"]),
                           peak_lipschitz_code=max(lips),curve="archived point-field cubic plus exact satellite"))
    return errors,limits

if __name__=="__main__":
    guard()
    suffix=sys.argv[1]
    precision=[];bounds=[]
    for label in ("cap","diff"):
        article=["orbit-"+label]+([suffix+"-"+label] if suffix!="orbit" else [])
        proof,rows=certificate(label,article)
        precision.append(proof);bounds.extend(rows)
    write("cloud-replay-"+suffix+".csv",precision)
    write("cloud-tube-"+suffix+".csv",bounds)
    print(precision,bounds)
