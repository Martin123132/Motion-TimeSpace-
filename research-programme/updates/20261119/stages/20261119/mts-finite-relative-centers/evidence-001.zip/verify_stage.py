from pair_energy import np, guard, HOME, LIVE, SEAL, TOL
from pathlib import Path
from hashlib import sha256
import csv
import json
import sys


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


def rows(name):
    with (HOME/name).open(encoding="utf8", newline="") as handle:
        values = list(csv.DictReader(handle))
    assert values and all(None not in row and None not in row.values() for row in values), name
    return values


def vector(row, prefix):
    return np.array([float(row[prefix+axis]) for axis in "xyz"])


def verify():
    guard()
    assert not (HOME/"__pycache__").exists()
    for path in HOME.glob("*.py"):
        compile(path.read_bytes(),str(path),"exec")
    ancestors = json.loads((LIVE/"seal.json").read_bytes())
    for name, expected in ancestors["files"].items():
        assert digest(LIVE/name) == expected, name
    for name, expected in ancestors["parents"].items():
        assert digest(HOME.parent/name) == expected, name
    files = {path.name:digest(path) for path in HOME.iterdir() if path.is_file() and path.name != "seal.json"}
    datasets = {path.name:len(rows(path.name)) for path in HOME.glob("*.csv")}
    for name in ("PROTOCOL.md","RESULTS.md","DERIVATION.md","CLOUD.md","REPLAY.md","NEXT.md"):
        assert name in files and (HOME/name).stat().st_size > 250
    packets = {fingerprint:name for name,fingerprint in files.items() if name.endswith(".npz")}
    finite_count, restart_count = 0,0
    for name in packets.values():
        with np.load(HOME/name, allow_pickle=False) as packet:
            for key in packet.files:
                value = packet[key]
                if value.dtype.kind in "fc" and not np.isfinite(value).all():
                    assert name.startswith("contour-") and not bool(packet["full_window"]) and key in ("position_pc","speed_kms") and np.isnan(value).all(), (name,key)
            if name.startswith("jet"):
                assert str(packet["seal"]) == SEAL and packet["relative_pc"].shape[1:]==(2,3)
                assert np.max(abs(packet["number_error"]))<TOL
            if "final_relative_pc" not in packet:
                continue
            finite_count += 1
            assert str(packet["seal"]) == SEAL
            history = packet["time_Gyr"]
            assert len(history)>1 and min(np.diff(history))>0 and abs(history[-1]-5)<1e-12
            assert np.max(abs(packet["number_error"]))<TOL
            for index, (saved,field,unit) in enumerate((("final_relative_pc","wave_center","length_pc"),("final_relative_kms","wave_vel","velocity_unit_kms"))):
                assert np.array_equal(packet[saved], (packet["last_body"][index,:3] - packet[field][-1])*packet[unit])
            parent_hash = str(packet["parent"])
            if parent_hash:
                restart_count += 1
                with np.load(HOME/packets[parent_hash]) as source:
                    assert packet["label"]==source["label"] and packet["steps"]==source["steps"]
                    index = np.flatnonzero(source["snap_idx"]==packet["start"])
                    target = source["last_body"] if packet["start"]==source["stop"] else source["snap_body"][index.item()]
                    assert np.array_equal(target,packet["body"][0]),name
            else:
                assert not packet["body"][0].any() and history[0]==0.
    norm=np.linalg.norm
    for label,top,duplicate,checks in (("cap","angular24-cap","dense-ward-cap","dense-momentum-cap-spline.csv"),
                                     ("diff","angular28-diff","ward28-diff","momentum-diff-spline.csv")):
        with np.load(HOME/(top+".npz")) as src, np.load(HOME/(duplicate+".npz")) as retry:
            for key in ("raw","last_body","final_relative_pc","final_relative_kms"):
                assert np.array_equal(src[key],retry[key]),(top,key)
            for row in [item for item in rows("finite-outcomes.csv") if item["state"]==label]:
                assert np.allclose(vector(row,""),src[row["measure"]],rtol=0,atol=1e-13)
                assert float(row["matched_l16_quadratic_vector_error"]) < float(row["matched_l16_linear_vector_error"])
        measured = [float(row["raw_vector_error"]) for row in rows(checks) if row["boundary"]=="with-wall" and row["stride"]=="1"]
        assert len(measured)==2 and max(measured)<TOL
        with np.load(HOME/f"still-{label}.npz") as still, np.load(HOME/f"common-{label}.npz") as common:
            assert not still["final_relative_pc"].any() and not still["final_relative_kms"].any()
            shift=norm(common["last_body"][0,:3])*float(common["length_pc"])
            assert shift>50 and norm(common["final_relative_pc"])<TOL*shift
        with np.load(HOME/f"shells-{label}-tail-n32.npz") as sample:
            assert float(sample["cq_difference_over_initial_component"])<TOL and 0<float(sample["peak_radial_strain"])<.001
    assert max(float(row["matched_grid_error"]) for row in rows("weak-and-quadratic.csv"))<1e-8
    assert max(float(row["against_sealed_linear"]) for row in rows("weak-and-quadratic.csv") if row["coefficient"]=="1")<TOL
    for row in rows("direct-force.csv"):
        assert max(float(row[key]) for key in ("opposite_force_work_error","averaged_green_error","force_from_energy_error","core_correction_own_error"))<TOL
    assert max(float(row["error"]) for row in rows("operator-controls.csv")) < TOL
    assert all(row["bootstrap_pass"]=="True" for row in rows("cloud-tube-angular16.csv"))
    comparisons=rows("candidate-poles.csv")
    for row in [one for one in comparisons if one["stream_nodes"]==one["integrated_nodes"]]:
        ref=next(one for one in comparisons if one["integrated_nodes"]=="1024" and one["state"]==row["state"] and one["stream_nodes"]==row["stream_nodes"])
        assert float(row["relative_singular_value"]) < 1e-7 and float(ref["relative_singular_value"])>1e-3
    sky=rows("sky-dipole.csv")
    components=rows("sky-components.csv")
    assert len(sky)==8 and len(components)==16
    for row in components:
        total=vector(row,"total_")
        assert np.allclose(total,vector(row,"wave_")+vector(row,"satellite_"),rtol=1e-14,atol=1e-12)
        assert np.allclose(vector(row,"wave_"),vector(row,"rigid_")+vector(row,"distortion_"),rtol=1e-14,atol=1e-12)
        if row["packet"].startswith("still"):
            assert norm(total)<1e-9
        else:
            ref=next(item for item in sky if item["packet"]==row["packet"] and item["radius_kpc"]==row["radius_kpc"])
            assert abs(norm(total)-float(ref["total_norm_kms2_per_kpc"])) < 1e-10
            assert max(float(ref[key]) for key in ("wave_direct_vector_error","source_sky_vector_error"))<TOL
    assert len(rows("time-and-space.csv"))==16
    assert all(row["within_20ppm"]=="True" for row in rows("time-and-space.csv") if row["changed"]=="time only")
    assert max(float(row["rigid_vector_error"]) for row in rows("rigid-sky-control.csv"))<TOL
    catalog=rows("packet-index.csv")
    assert {row["packet"]:row["sha256"] for row in catalog}=={name:value for name,value in files.items() if name.endswith(".npz")}
    coarse=[row for row in rows("grid-refinements.csv") if row["within_20ppm"]=="False"]
    assert coarse and any(float(row["raw_vector_error"])>TOL for row in rows("momentum-cap-spline.csv") if row["stride"]=="1")
    return dict(scope="Conditional five-Gyr wave/ordinary relative centers and centered line-of-sight acceleration, not a fitted halo or a Galactic observation",
                parent=SEAL,control_tolerance=TOL,files=files,rows=datasets,finite_wave_packets=finite_count,
                linked_finite_restarts=restart_count,coarse_comparisons_outside_tolerance=len(coarse))


if __name__=="__main__":
    report=verify()
    output=HOME/"seal.json"
    if sys.argv[1:]==["seal"]:
        with output.open("x",encoding="utf8") as dest:
            json.dump(report,dest,indent=2,sort_keys=True)
            dest.write("\n")
    assert json.loads(output.read_bytes())==report
    print(digest(output),len(report["files"]),"files;",sum(report["rows"].values()),"rows;",report["finite_wave_packets"],"finite packets;",report["linked_finite_restarts"],"restarts")
