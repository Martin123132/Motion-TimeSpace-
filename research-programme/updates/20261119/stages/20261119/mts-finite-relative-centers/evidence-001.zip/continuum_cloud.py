from tidal_contour import Contour,rotation,assembled,inputs
from field_checks import write
from pair_energy import HOME,np,loaded,basis,root_values,roots_legendre,spherical_jn,guard
from satellite import BASIS
from scipy.linalg import eigvals
from scipy.interpolate import CubicSpline
from scipy.integrate import solve_ivp
from scipy.fft import next_fast_len,rfft,irfft
import sys

def gains(stamp,omega,kappa2):
    free=1/(stamp**2+kappa2)
    xp=0j;xt=0j;ep=0j;et=0j;bp=0j;bt=0j
    for sign in (-1,1):
        dop=stamp+sign*2j*omega
        denom=1/(dop**2+kappa2)
        grad=-denom
        tan=-4j*sign*omega/dop*denom
        ygrad=-2*omega/dop*grad
        ytan=-2j*sign/dop**2-2*omega/dop*tan
        xp+=grad;xt+=tan
        ep-=.5j*sign*ygrad;et-=.5j*sign*ytan
        bp-=.5j*sign*grad;bt-=.5j*sign*tan
    aa=-.25*free+.375*xp
    ab=.375*xt
    sa=.5*ep
    sb=.5*(et-2/(stamp**2+4*omega**2))
    return aa,ab,sa,sb,(-.5*free+.25*xp,.25*xt,bp,bt,-.5*free-.25*xp,-.25*xt)

class Susceptibility:
    def __init__(self,label,rank,number):
        core,material,ground,_,_=loaded(label,40.)
        self.core=core;self.rank=rank
        node,weights=roots_legendre(number)
        rad=(node+1)*core/2
        mass=weights*core/2*rad**2*material(rad)[2]
        self.rad,self.frac=rad,mass/mass.sum()
        drag,_,density=material(rad)
        amp,_,_,der=ground(rad)
        self.omega=np.sqrt((drag+der)/rad)
        self.kappa2=density+amp**2+self.omega**2
        if rank:
            root=root_values(1,rank)
            freq=root/core
            normal=np.sqrt(.5*core**3*(spherical_jn(2,root)**2-spherical_jn(1,root)*spherical_jn(3,root)))
            vac=basis(2,root,core,rad)
            grad=spherical_jn(2,np.outer(rad,freq),derivative=True)*(freq/normal)
            self.grad=grad/freq
            self.side=vac/(rad[:,None]*freq)
        else:
            self.grad=np.zeros((number,0));self.side=self.grad
        self.gmat=np.column_stack((self.grad,rad))
        self.bmat=np.column_stack((self.side,rad/2))
        self.proj_a=np.vstack(((mass[:,None]*self.grad).T,4*self.frac*rad/15))
        self.proj_s=np.vstack(((3*mass[:,None]*self.side).T,2*self.frac*rad/5))
        self.inertia=self.frac@rad**2/3
        self.omega0=np.sqrt(amp**2+self.omega**2)
        self.kin=self.kappa2

    def matrix(self,stamp):
        aa,ab,sa,sb,_=gains(stamp,self.omega,self.kappa2)
        coupled=self.proj_a@(aa[:,None]*self.gmat+ab[:,None]*self.bmat)+self.proj_s@(sa[:,None]*self.gmat+sb[:,None]*self.bmat)
        return coupled

    def det(self,stamp):
        block=self.matrix(stamp)[:-1,:-1]
        return np.linalg.det(np.eye(self.rank)+block)

    def scalar(self,stamp):
        block=self.matrix(stamp)
        response=np.linalg.solve(np.eye(self.rank)+block[:-1,:-1],-block[:-1,-1]) if self.rank else np.array([])
        cov=block[-1,-1]+block[-1,:-1]@response
        iso=-(2/3)*(self.frac*self.rad**2)@(1/(stamp**2+self.omega0**2))
        return cov,iso

def resolve():
    rows=[]
    for label in ("central_cap","illustrative"):
        for number in (24,48,96):
            rank=6
            obj=Contour(label,number,rank)
            vals=eigvals(obj.mat)
            peak=vals[np.argmax(vals.real)]
            peak=peak.real+1j*abs(peak.imag)
            targets=[(size,Susceptibility(label,rank,size)) for size in (number,256,512,1024)]
            for sample,system in targets:
                block=np.eye(rank)+system.matrix(peak)[:-1,:-1]
                singular=np.linalg.svd(block,compute_uv=False)
                rows.append(dict(state=label,stream_nodes=number,integrated_nodes=sample,rank=rank,real=peak.real,
                                 imag=peak.imag,relative_singular_value=singular[-1]/singular[0],
                                 absolute_determinant=abs(np.linalg.det(block))))
    write("candidate-poles.csv",rows)
    print(rows[-4:])

def causal_inverse(kernel,rank,steps):
    weights=kernel[:steps+1,:rank,:rank].copy()
    weights[0]+=np.eye(rank)
    right=-kernel[:steps+1,:rank,rank].copy()
    result=np.zeros_like(right)
    inverse=np.linalg.inv(weights[0])
    def interval(lo,hi):
        width=hi-lo
        if width<=32:
            for idx in range(lo,hi):
                local=right[idx].copy()
                if idx>lo:
                    local-=np.einsum("tij,tj->i",weights[1:idx-lo+1],result[lo:idx][::-1])
                result[idx]=inverse@local
            return
        mid=(lo+hi)//2
        interval(lo,mid)
        size=next_fast_len((mid-lo)+width-1)
        product=np.einsum("fij,fj->fi",rfft(weights[:width],n=size,axis=0),rfft(result[lo:mid],n=size,axis=0))
        right[mid:hi]-=irfft(product,n=size,axis=0)[mid-lo:width]
        interval(mid,hi)
    if rank:
        interval(0,steps+1)
    size=next_fast_len(2*steps+1)
    induced=np.sum(rfft(kernel[:steps+1,rank,:rank],n=size,axis=0)*rfft(result,n=size,axis=0),axis=1)
    return kernel[:steps+1,rank,rank]+irfft(induced,n=size)[:steps+1],result

def transfer_run(tag,label,rank,number,steps,damping):
    bank=assembled(["orbit-"+label,"angular16-"+label])
    time=bank["time_Gyr"]/bank["timeunit_Gyr"]
    hess,third,isotropic,tensor=inputs(bank,time)
    syslabel=str(bank["label"])
    system=Susceptibility(syslabel,rank,number)
    dt=time[-1]/steps
    target=np.arange(steps+1)*dt
    forcing=CubicSpline(time,np.column_stack((tensor,isotropic)))(target)
    length=2*steps
    decay=np.exp(-damping/length)
    phase=np.arange(length//2+1)*2*np.pi/length
    zeta=decay*np.exp(-1j*phase)
    stamp=(1-zeta)*(3-zeta)/(2*dt)
    spectral=np.array([system.matrix(val) for val in stamp])
    closed=np.linalg.solve(np.eye(rank)[None,:,:]+spectral[:,:rank,:rank],-spectral[:,:rank,rank,None])[:,:,0] if rank else spectral[:,:0,rank]
    gain=np.column_stack((spectral[:,rank,rank]+np.sum(spectral[:,rank,:rank]*closed,axis=1),
                          [-(2/3)*(system.frac*system.rad**2)@(1/(val**2+system.omega0**2)) for val in stamp]))
    kernel=irfft(spectral,n=length,axis=0)
    causal,back=causal_inverse(kernel,rank,steps)
    data=np.zeros((length,6))
    data[:steps+1]=forcing*(decay**np.arange(steps+1))[:,None]
    response=np.fft.rfft(data,axis=0)
    response[:,:5]*=gain[:,:1]
    response[:,5]*=gain[:,1]
    circular=np.fft.irfft(response,n=length,axis=0)[:steps+1]/(decay**np.arange(steps+1))[:,None]
    pad=next_fast_len(2*steps+1)
    mono=irfft(gain[:,1],n=length)[:steps+1]
    forward=np.column_stack((np.repeat(causal[:,None],5,axis=1),mono))
    result=irfft(rfft(forward,n=pad,axis=0)*rfft(data[:steps+1],n=pad,axis=0),n=pad,axis=0)[:steps+1]/(decay**np.arange(steps+1))[:,None]
    cov=np.einsum("ti,ijk->tjk",result[:,:5],BASIS)+result[:,5,None,None]*np.eye(3)
    cubic=CubicSpline(time,third)(target)
    accel=-.5*np.einsum("tijk,tjk->ti",cubic,cov)
    acceleration=CubicSpline(target,accel)
    environment=CubicSpline(time,hess)
    def rhs(stamp,st):
        return np.r_[st[3:],-environment(stamp)@st[:3]+acceleration(stamp)]
    correction=solve_ivp(rhs,(0.,target[-1]),np.zeros(6),rtol=1e-8,atol=5e-18,method="DOP853")
    assert correction.success
    size=np.max(np.linalg.norm(cov,axis=(1,2)))/system.inertia
    endpoint=correction.y[:,-1]
    saved=dict(label=label,rank=rank,radial_nodes=number,time_steps=steps,damping=damping,
               time_Gyr=target*bank["timeunit_Gyr"],covariance=cov,covariance_over_initial_component_max=size,
               mean_force=accel,final_position_pc=endpoint[:3]*bank["length_pc"],final_velocity_kms=endpoint[3:]*bank["velocity_unit_kms"],
               launch_response_relative=np.linalg.norm(cov[0])/system.inertia,max_gain=np.max(abs(gain),axis=0),
               periodic_inverse_difference=np.max(abs(result-circular))/max(np.max(abs(result)),1e-300))
    if tag.startswith("potential-"):
        freq_response=rfft(back,n=pad,axis=0)[:,:,None]*rfft(data[:steps+1,:5],n=pad,axis=0)[:,None,:]
        saved["self_coeff"]=irfft(freq_response,n=pad,axis=0)[:steps+1]/(decay**np.arange(steps+1))[:,None,None]
    path=HOME/(tag+".npz")
    if path.exists():
        with np.load(path) as prev:
            assert all(np.array_equal(prev[key],value) for key,value in saved.items())
    else:
        with path.open("xb") as output:
            np.savez_compressed(output,**saved)
    print(tag,size,saved["final_position_pc"],saved["final_velocity_kms"],flush=True)

if __name__=="__main__":
    guard()
    if sys.argv[1]=="poles":
        resolve()
    else:
        tag,label,rank,number,steps,damping=sys.argv[1:]
        transfer_run(tag,label,int(rank),int(number),int(steps),float(damping))
