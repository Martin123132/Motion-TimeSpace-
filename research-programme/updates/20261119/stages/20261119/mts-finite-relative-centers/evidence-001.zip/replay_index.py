from pair_energy import np, HOME, guard
from field_checks import write
from hashlib import sha256


def catalog():
    raw = sorted(HOME.glob("*.npz"))
    reverse = {sha256(path.read_bytes()).hexdigest():path.stem for path in raw}
    entries=[]
    for path in raw:
        with np.load(path, allow_pickle=False) as packet:
            if "final_relative_pc" in packet:
                keys = ("label","count","edge","order","degree","vac","feedback","strength","steps","start","stop","save_every")
                flags = [f"--{key.replace('_','-')} {packet[key]}" for key in keys]
                if str(packet["parent"]):
                    flags.append("--parent "+reverse[str(packet["parent"])])
                if "fast" in packet and bool(packet["fast"]):
                    flags.append("--fast")
                if "external_force" in packet:
                    flags.append("--budget")
                if path.stem.startswith("common-"):
                    flags.append("--law uniform")
                command = "finite_centers.py --tag "+path.stem+" "+" ".join(flags)+" --replay"
            elif path.stem.startswith("jet"):
                flags=[f"--{key} {packet[key]}" for key in ("label","count","edge","order","steps","start")]
                if str(packet["parent"]):
                    flags.append("--parent "+reverse[str(packet["parent"])])
                command="second_response.py --tag "+path.stem+" "+" ".join(flags)+" --replay"
            elif path.stem.startswith("contour-"):
                command=f"tidal_contour.py {packet['label']} {packet['number']} {packet['rank']}"
            elif path.stem.startswith(("potential-","retarded-")):
                command=f"continuum_cloud.py {path.stem} {packet['label']} {packet['rank']} {packet['radial_nodes']} {packet['time_steps']} {packet['damping']}"
            elif path.stem.startswith("shells-"):
                _,label,tier,number=path.stem.split("-")
                command=f"shell_replay.py {label} {tier} {int(number[1:])}"
            else:
                raise ValueError(path.name)
        entries.append(dict(packet=path.name,sha256=sha256(path.read_bytes()).hexdigest(),replay="python -B "+command))
    write("packet-index.csv",entries)


if __name__=="__main__":
    guard()
    catalog()
