from sky_dipole import load_packet, rec_grid, sky_rule, write
from pair_energy import np, basis, roots_legendre, guard, HOME
import csv


def enclosed_ratio(grid, sizes):
    nodes, weights = roots_legendre(24)
    fraction = (nodes+1)/2
    original = np.asarray(sizes)
    radius = original.ravel()[:,None] * fraction
    ground = basis(0,grid.wroots[0],grid.edge,radius.ravel()) @ grid.coef
    return ((ground.reshape(radius.shape)**2) @ (fraction**2 * weights/2)).reshape(original.shape)


def read(tag, reference):
    packet = load_packet(tag)
    grid, cloud = rec_grid(packet)
    length = float(packet["length_pc"])/1000
    scale = float(packet["velocity_unit_kms"])**2/length
    offset = packet["final_relative_pc"]/float(packet["length_pc"])
    distance = np.linalg.norm(offset)
    axis = offset/distance
    cosine, weights = roots_legendre(36)
    unit = weights/2
    thickness = cloud.radii[:,None]
    sizes = np.sqrt(distance**2+thickness**2+2*distance*thickness*cosine)
    center = -(cloud.shell @ (((distance+thickness*cosine) * enclosed_ratio(grid,sizes)) @ unit))
    rows = []
    for row in (item for item in reference if item["packet"]==tag):
        radius=float(row["radius_kpc"])/length
        sizes=np.sqrt(distance**2+radius**2+2*distance*radius*cosine)
        los=-3*unit @ (cosine*(radius+distance*cosine)*enclosed_ratio(grid,sizes))
        calculated=(los-center)*axis*scale
        expected=np.array([float(row["rigid_"+component]) for component in "xyz"])
        error=np.linalg.norm(calculated-expected)/np.linalg.norm(expected)
        rows.append(dict(packet=tag,radius_kpc=float(row["radius_kpc"]),direct_rigid_norm=np.linalg.norm(calculated),rigid_vector_error=error))
    return rows


if __name__=="__main__":
    guard()
    sky, weights=sky_rule(28)
    uniform=np.array([.39,-.12,1.3])
    tide=np.array([[.6,.01,-.12],[.01,-.04,.32],[-.12,.32,.09]])
    assert np.linalg.norm(3*(weights*(sky@uniform))@sky-uniform)<2e-14
    assert np.linalg.norm(3*(weights*np.einsum("ni,ij,nj->n",sky,tide,sky))@sky)<2e-14
    with (HOME/"sky-components.csv").open(encoding="utf8") as handle:
        reference=list(csv.DictReader(handle))
    rows=[row for tag in ("angular24-cap","angular28-diff") for row in read(tag,reference)]
    write("rigid-sky-control.csv",rows)
    print(rows)
    assert max(row["rigid_vector_error"] for row in rows)<2e-5
