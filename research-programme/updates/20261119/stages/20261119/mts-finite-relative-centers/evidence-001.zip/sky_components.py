from sky_dipole import load_packet, rec_grid, potential_modes, center_weights, source_dipole, sky_rule, orbit, guard, write
from pair_energy import np, basis, spherical_jn, MASS, RADIUS
import sys


def rigid_wave(grid, cloud, monopole, offset, radius):
    roots, freq, _ = monopole
    normal = roots / np.sqrt(.5 * grid.edge ** 3 * (1 - np.sin(2 * roots) / (2 * roots)))
    eigenfunctions = basis(0, roots, grid.edge, grid.rad)
    potential = -(eigenfunctions.T @ (grid.w * grid.ground ** 2)) / freq ** 2
    size = np.linalg.norm(offset)
    if size == 0:
        return np.zeros(3)
    reference = cloud.shell @ spherical_jn(0, np.outer(cloud.radii, freq))
    radial_filter = 3 * spherical_jn(1, radius * freq, derivative=True) - reference
    return ((potential * normal * freq * radial_filter) @ spherical_jn(1, freq * size)) * (offset / size)


def measure(tag):
    packet = load_packet(tag)
    grid, cloud = rec_grid(packet)
    data = potential_modes(grid, cloud, packet, 6)
    length = float(packet["length_pc"]) / 1000
    scale = float(packet["velocity_unit_kms"]) ** 2 / length
    center = packet["last_body"][0, :3]
    offset = center - packet["wave_center"][-1]
    stamp = float(packet["time_Gyr"][-1])
    donor = orbit(1)[0](stamp) / length
    mass = MASS * float(packet["strength"]) / float(packet["mass_unit_msun"])
    soft = RADIUS / length
    dist = np.linalg.norm(donor)
    center_source = mass * donor / (dist * (dist + soft) ** 2) + packet["sat_acc"][-1, 0]
    sky, weights = sky_rule(28)
    rows = []
    for kpc in (1., 4., 8.1, 17.58):
        radius = kpc / length
        wave = (center_weights(grid, cloud, data, center, radius, "los") - packet["wave_acc"][-1, 0]) * scale
        rigid = rigid_wave(grid, cloud, data[0], offset, radius) * scale
        external = (source_dipole(sky, weights, center, donor, radius, soft, mass) - center_source) * scale
        total = wave + external
        parts = dict(wave=wave, rigid=rigid, distortion=wave-rigid, satellite=external, total=total)
        rows.append(dict(packet=tag, radius_kpc=kpc, **{f"{name}_{axis}":value for name, vector in parts.items()
                         for axis,value in zip("xyz",vector)}, total_norm=np.linalg.norm(total), rigid_wave_norm=np.linalg.norm(rigid),
                         live_wave_norm=np.linalg.norm(wave), wave_minus_rigid_norm=np.linalg.norm(wave-rigid)))
    return rows


if __name__ == "__main__":
    guard()
    rows = [row for tag in sys.argv[2:] for row in measure(tag)]
    write(sys.argv[1], rows)
    for row in rows:
        print(row["packet"], row["radius_kpc"], row["rigid_wave_norm"], row["live_wave_norm"], row["wave_minus_rigid_norm"])
