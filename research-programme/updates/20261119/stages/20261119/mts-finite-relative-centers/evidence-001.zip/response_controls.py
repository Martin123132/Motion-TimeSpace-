from continuum_cloud import gains, causal_inverse
from tidal_contour import rotation
from field_checks import load_packet, write
from pair_energy import np, guard
import sys


def resolvent_checks():
    rows = []
    for omega, kappa2 in ((.4, .5), (7., 175.), (30., 3500.)):
        transform = rotation(np.array([omega]))
        hessian = np.diag([kappa2 - 3 * omega ** 2] * 3 + [omega ** 2] * 5)
        for stamp in (.2 + 1.3j, 1.2 + 2.1j * omega, .8 + 8.j * omega):
            operator = stamp * np.eye(8) + transform
            jacobian = operator @ operator + hessian
            forcing = np.zeros((8, 2))
            forcing[0, 0] = -1.
            forcing[[4, 6], 1] = -2.
            solved = np.linalg.solve(jacobian, forcing)
            expected = np.r_[solved[0] - .5 * solved[2], .5 * (solved[4] + solved[6])]
            measured = np.array(gains(stamp, omega, kappa2)[:4])
            rows.append(dict(control="orbit gain", setup=f"{omega}:{stamp}", error=np.linalg.norm(measured-expected)/np.linalg.norm(expected)))
    steps = 384
    for growth in (.98, 1.04):
        kernel = np.zeros((steps+1, 2, 2))
        kernel[0, 0, 1] = -1
        kernel[0, 1, 0] = 1
        kernel[1, 0, 0] = -growth
        solved, internal = causal_inverse(kernel, 1, steps)
        answer = growth ** np.arange(steps+1)
        err = max(np.max(abs(solved / answer - 1)), np.max(abs(internal[:,0] / answer - 1)))
        rows.append(dict(control="manufactured causal pole", setup=f"{growth}, {steps} steps", error=err))
    return rows


def summaries():
    norm = np.linalg.norm
    grid_rows = []
    shape_rows = []
    for label in ("cap", "diff"):
        pairs = [("reference", "orbit"), ("orbit", "outer"), ("angular10", "angular16"), ("angular16", "outer16")]
        pairs += [("angular16", "angular24")] if label == "cap" else [("angular16", "angular22"), ("angular22", "earlier22"), ("earlier22", "angular28")]
        for old, new in pairs:
            first, second = (load_packet(name+"-"+label) for name in (old, new))
            for measure in ("final_relative_pc", "final_relative_kms"):
                change = norm(second[measure]-first[measure])
                grid_rows.append(dict(state=label, before=old, after=new, measure=measure, absolute=change,
                                      vector_fraction=change/norm(second[measure]), within_20ppm=change<=2e-5*norm(second[measure])))
        for name in ("retarded-"+label+"-2048","retarded-"+label+"-4096","retarded-"+label+"-8192",
                     "potential-"+label+"-high","potential-"+label+"-damping","potential-"+label+"-tail"):
            packet = load_packet(name)
            shape_rows.append(dict(packet=name, rank=int(packet["rank"]), nodes=int(packet["radial_nodes"]), steps=int(packet["time_steps"]),
                                   damping=float(packet["damping"]), peak_covariance_over_initial=float(packet["covariance_over_initial_component_max"]),
                                   endpoint_shift_pc=norm(packet["final_position_pc"]), endpoint_shift_kms=norm(packet["final_velocity_kms"]),
                                   periodic_causal_peak_difference=float(packet["periodic_inverse_difference"])))
    write("grid-refinements.csv", grid_rows)
    write("contour-refinements.csv", shape_rows)


if __name__ == "__main__":
    guard()
    if sys.argv[1] == "roots":
        rows = resolvent_checks()
        write("operator-controls.csv", rows)
        print(rows)
        assert max(row["error"] for row in rows) < 2e-5
    else:
        summaries()
