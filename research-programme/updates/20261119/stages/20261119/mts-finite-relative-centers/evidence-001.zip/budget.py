from field_checks import load_packet,write,np,HOME
from pair_energy import guard,KMS,LIVE
from scipy.integrate import simpson
from scipy.interpolate import make_interp_spline
from pathlib import Path
import csv
import sys

def norm(array):
    return np.linalg.norm(array)

def ward(tags,spline=False):
    blocks=[load_packet(tag) for tag in tags]
    last=blocks[-1]
    fields={}
    for key in ("time_Gyr","external_force","wall_force","sat_acc"):
        chunks=[]
        for idx,packet in enumerate(blocks):
            mask=packet["time_Gyr"]<blocks[idx+1]["time_Gyr"][0]-1e-12 if idx+1<len(blocks) else slice(None)
            chunks.append(packet[key][mask])
        fields[key]=np.concatenate(chunks)
    tt=fields["time_Gyr"]/last["timeunit_Gyr"]
    assert tt[0]==0 and abs(fields["time_Gyr"][-1]-5)<1e-12 and min(np.diff(tt))>0
    mw=float(last["scalar_mass"]);mb=float(last["cloud_mass"])
    ext=fields["external_force"]+mb*fields["sat_acc"][:,0]
    wall=fields["wall_force"]
    cloud=last["last_body"][:,:3]; result=[]
    for include,force in (("isolated",ext),("with-wall",ext+wall)):
        for stride in (1,2):
            used=np.arange(0,len(tt),stride)
            if used[-1]!=len(tt)-1:
                used=np.r_[used,len(tt)-1]
            total=np.stack((simpson(force[used]*(tt[-1]-tt[used,None]),x=tt[used],axis=0),simpson(force[used],x=tt[used],axis=0)))
            if spline:
                curve=make_interp_spline(tt[used],force[used],k=7)
                prime=curve.antiderivative();double=prime.antiderivative()
                total=np.stack((double(tt[-1])-double(0)-tt[-1]*prime(0),prime(tt[-1])-prime(0)))
            predicted=((mw+mb)*cloud-total)/mw
            for idx,(refkey,unit) in enumerate((("final_relative_pc",last["length_pc"]),("final_relative_kms",last["velocity_unit_kms"]))):
                value=predicted[idx]*unit
                reference=last[refkey]
                result.append(dict(packet=tags[-1],boundary=include,stride=stride,measure=refkey,x=value[0],y=value[1],z=value[2],
                                   norm=norm(value),raw_vector_error=norm(value-reference)/norm(reference)))
    return result

def weak():
    saved=list(csv.DictReader((LIVE/"motion-history.csv").open(encoding="utf8")))
    rows=[]
    for idx,label in enumerate(("central_cap","illustrative")):
        stem="cap" if idx==0 else "diff"
        packet=load_packet("jet-weak-"+stem)
        fine=next(row for row in saved if row["state"]==label and float(row["time_Gyr"])==5)
        for measure,field,old in (("final_relative_pc","relative_pc",["d"+col+"_pc" for col in "xyz"]),
                                  ("final_relative_kms","relative_kms",["dv"+col+"_kms" for col in "xyz"])):
            reference=np.array([float(fine[col]) for col in old])
            estimates=[];second=[]
            for offset in (0,2):
                pos=load_packet(f"weak-{idx}-{offset}")
                neg=load_packet(f"weak-{idx}-{offset+1}")
                amp=float(pos["strength"])
                slope=(pos[measure]-neg[measure])/(2*amp)
                curv=(pos[measure]+neg[measure])/(2*amp**2)
                estimates.append(slope);second.append(curv)
            for order,(sequence,target) in enumerate(((estimates,packet[field][-1,0]),(second,packet[field][-1,1])),1):
                extrap=(4*sequence[1]-sequence[0])/3
                rows.append(dict(state=label,measure=measure,coefficient=order,matched_grid_error=norm(extrap-target)/norm(target),
                                 half_scale_error=norm(sequence[1]-target)/norm(target),signed_extrapolated_norm=norm(extrap),
                                 against_sealed_linear=(norm(extrap-reference)/norm(reference) if order==1 else "")))
    write("weak-and-quadratic.csv",rows)
    print(rows)

def impact():
    rows=[]
    for label,tag,stage in (("cap","angular24-cap","jet16-cap"),("diff","angular28-diff","jet16-diff")):
        src=load_packet(tag);jet=load_packet(stage)
        same=load_packet("angular16-"+label);base=load_packet("reference-"+label);trace=load_packet("tracer-"+label)
        for measure,key in (("final_relative_pc","relative_pc"),("final_relative_kms","relative_kms")):
            value=src[measure]
            linear,quadratic=jet[key][-1]
            rows.append(dict(state=label,measure=measure,x=value[0],y=value[1],z=value[2],finite_norm=norm(value),linear_norm=norm(linear),
                             quadratic_coefficient_norm=norm(quadratic),full_minus_linear_norm=norm(value-linear),
                             finite_over_linear_norm=norm(value)/norm(linear),matched_l16_linear_vector_error=norm(same[measure]-linear)/norm(same[measure]),
                             matched_l16_quadratic_vector_error=norm(same[measure]-linear-quadratic)/norm(same[measure]),
                             l5_cloud_feedback_vector_change=norm(base[measure]-trace[measure]),l5_cloud_feedback_fraction=norm(base[measure]-trace[measure])/norm(base[measure])))
    write("finite-outcomes.csv",rows)
    print(rows)

if __name__=="__main__":
    guard()
    if sys.argv[1]=="weak":
        weak()
    elif sys.argv[1]=="impact":
        impact()
    else:
        rows=ward(sys.argv[2:],"-spline." in sys.argv[1])
        write(sys.argv[1],rows)
        print(rows[:2],rows[4:6])
