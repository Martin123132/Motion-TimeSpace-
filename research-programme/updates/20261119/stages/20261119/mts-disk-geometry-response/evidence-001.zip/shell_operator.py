from source_kernel import (np, branch, support, coefficient_gradient, shell_change, shell_force,
                           roots_legendre, basis, HERE, G, read, record, guard, step, OUTER, SPEED)
from disk_tangent import Linearization
from common_shape import sys, ordinary


def matrices(system,inner,outer,order=12):
    nodes,weights=roots_legendre(order)
    ends=np.unique(np.clip(np.r_[np.linspace(0,system.edge,1+system.count//2),inner/system.length,outer/system.length],0,system.edge))
    widths=np.diff(ends)[:,None]/2
    radius=(ends[:-1,None]+(1+nodes)*widths).ravel()
    phys=radius*system.length
    field=(shell_change(phys,inner,outer)-shell_change(0.,inner,outer))/system.vel**2
    vir=G*1e9*((phys>inner).astype(float)-(phys>outer).astype(float))/phys/system.vel**2
    integration=(widths*weights).ravel()*radius**2
    pot=[]; stress=[]
    for mode,root in zip(system.orders,system.roots):
        proj=basis(mode,root,system.edge,radius)
        pot.append(proj.T@((integration*field)[:,None]*proj))
        stress.append(proj.T@((integration*vir)[:,None]*proj))
    return np.array(pot),np.array(stress)


def apply(matrix,coef):
    return np.einsum("lij,lj->li",matrix,coef,optimize=True)


def belt(radius):
    upper=min(1.5/radius,np.sqrt(max(1-(7/radius)**2,0)))
    lower=np.sqrt(max(1-(9/radius)**2,0))
    return max(0.,upper-lower)


def corrected(seed_tag):
    guard()
    system,seed=branch.load(seed_tag)
    curve=Linearization(system,seed["coef"])
    loc,ww,hw,halo=support(system,curve.state,float(seed["nfw"]))
    grad=coefficient_gradient(system,curve.state,loc,ww)
    mass_dir,_,_,_=curve.differentiate("mass")
    mj=np.array([np.sum(term*mass_dir) for term in grad])
    rows=[]
    split=[]
    for inner,outer in ((9.,12.),(25.,40.),(40.,60.)):
        mat,_=matrices(system,inner,outer)
        ref,_=matrices(system,inner,outer,16)
        drive=apply(mat,curve.state)
        assert np.linalg.norm(drive-apply(ref,curve.state))<5e-13
        fixed=-curve.constrained(drive)
        ordinary_change=shell_force(loc,inner,outer)
        anchor_source=np.sum(ww[0]*ordinary_change)
        du=-(anchor_source+np.sum(grad[0]*fixed))/mj[0]
        for idx,name in enumerate(("slope","Kz","annulus_billion"),1):
            gamma=mj[idx]/mj[0]
            adjoint=curve.constrained(grad[idx]-gamma*grad[0])
            direct=(belt(inner)-belt(outer)) if idx==3 else np.sum(ww[idx]*ordinary_change)
            nfw=direct if idx==3 else np.sum(hw[idx]*ordinary_change)
            nfw-=np.sum(hw[idx]*halo)/np.sum(hw[0]*halo)*anchor_source
            adj=direct-gamma*anchor_source-np.sum(adjoint*drive)
            forward=direct+np.sum(grad[idx]*(fixed+du*mass_dir))
            split.append(dict(seed=seed_tag,source=f"shell-{outer:g}-to-{inner:g}",quantity=name,direct=direct,
                              induced_at_fixed_occupation=np.sum(grad[idx]*fixed),occupation_recalibration=du*mj[idx],
                              fixed_occupation_total=direct+np.sum(grad[idx]*fixed),calibrated_total=forward))
            rows.append(dict(seed=seed_tag,source=f"shell-{outer:g}-to-{inner:g}",quantity=name,direct=direct,
                             dlogmass_per_billion=du,mts=adj,forward=forward,nfw=nfw,
                             quadrature_pair_abs=np.linalg.norm(apply(mat-ref,curve.state))))
    record("split-shell-"+seed_tag+".csv",rows)
    record("occupation-split-"+seed_tag+".csv",split)


class ExternalShell(Linearization):
    def __init__(self,system,state,strength,matrix):
        super().__init__(system,state)
        self.matrix=matrix
        self.strength=strength
        change=strength*apply(matrix,state)
        chemical_add=np.sum(state*change)/system.mass
        self.chemical+=chemical_add
        self.resid+=change-chemical_add*state

    def response(self,direction):
        return super().response(direction)+self.strength*apply(self.matrix,direction)


def finite():
    guard()
    sysm,seed=branch.load("main")
    ref=seed["coef"]
    initial=float(seed["mass"])
    matrix,_=matrices(sysm,25.,40.,16)
    loc,weights,_,_=support(sysm,ref,float(seed["nfw"]))
    bar,cloud,_=ordinary(sysm,loc)
    base_wave=sysm.force(ref,loc)
    base=bar+cloud+base_wave
    rad=-loc[1:3,0]
    speed=np.sqrt(rad*base[1:3,0])
    rows=[]
    for strength in (-1.,-.5,-.25,.25,.5,1.):
        sysm.mass=initial
        state=ref.copy()
        for iteration in range(12):
            lin=ExternalShell(sysm,state,strength,matrix)
            norm=abs(np.sum(state**2)/sysm.mass-1)
            if np.linalg.norm(lin.resid)>1.5e-14 or norm>2e-15:
                state+=lin.constrained(-lin.resid)
                state*=np.sqrt(sysm.mass)/np.linalg.norm(state)
                continue
            delta=sysm.force((ref+state)/2,loc,tangent=state-ref)
            mismatch=OUTER*(delta[0,0]+base[0,0])-SPEED**2
            if abs(mismatch)<2e-15*SPEED**2:
                break
            tangent,_,_,_=lin.differentiate("mass")
            jac=OUTER*sysm.force(state,loc[:1],tangent=tangent)[0,0]
            jump=-mismatch/jac
            sysm.mass*=np.exp(jump)
            state+=tangent*jump
            state*=np.sqrt(sysm.mass)/np.linalg.norm(state)
        else:
            raise RuntimeError(("shell equilibrium",strength,iteration,np.linalg.norm(lin.resid),norm))
        increment=rad*delta[1:3,0]/(np.sqrt(rad*(base+delta)[1:3,0])+speed)
        rows.append(dict(strength_billion_msun=strength,slope=(increment[1]-increment[0])/step,
                         Kz=delta[3,2],annulus_billion=np.sum(weights[3]*delta),dlogmass=np.log(sysm.mass/initial),
                         stationarity=np.linalg.norm(lin.resid),anchor_speed2_residual=mismatch))
    record("shell-nonlinear.csv",rows)


if __name__=="__main__":
    for flag in sys.argv[1:]:
        finite() if flag=="finite" else corrected(flag)
