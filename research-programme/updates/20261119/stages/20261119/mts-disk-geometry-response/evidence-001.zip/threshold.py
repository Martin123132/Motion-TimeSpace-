from geometry_state import report
from common_shape import HERE, read, record, np, guard


def roots():
    guard()
    base_tags=["short","ir-low","ir","ir-high","retained-bt","center","stars-low","stars","stars-high","long"]
    result=[]
    for model in ("mts","nfw"):
        def measured(tag):
            row,=[row for row in read(tag+"-forces.csv") if row["model"]==model]
            deriv,=[row for row in read(tag+"-jacobian.csv") if row["model"]==model and row["term"]=="total"]
            return tuple(float(val) for val in (row["a_kpc"],row["slope"],deriv["dslope_da"]))
        samples=sorted((measured(tag),tag) for tag in base_tags)
        bounds=[(left,right) for left,right in zip(samples,samples[1:]) if left[0][1]*right[0][1]<=0]
        if len(bounds)!=1:
            raise ValueError((model,bounds))
        (left,lo_tag),(right,hi_tag)=bounds[0]
        near=left if abs(left[1])<abs(right[1]) else right
        for iteration in range(6):
            guess=near[0]-near[1]/near[2]
            if not left[0]<guess<right[0]:
                guess=(left[0]+right[0])/2
            tag=model+"-zero-"+str(iteration)
            if not (HERE/(tag+".npz")).exists():
                report(tag,"main",guess)
            new=measured(tag)
            assert abs(new[0]-guess)<1e-10
            if abs(new[1])<1e-7:
                break
            if new[1]*left[1]<0:
                right=new
            else:
                left=new
            near=new
        else:
            raise RuntimeError("root diagnostic")
        extra_tag=model+"-zero-alt"
        report(extra_tag,"above",guess)
        alt=measured(extra_tag)
        result.append(dict(model=model,first_left=lo_tag,first_right=hi_tag,critical_a_kpc=guess,
                           residual_slope=new[1],local_rate=new[2],nonlinear_packet=tag,
                           alternate_slope=alt[1],alternate_linearized_root_shift=-alt[1]/alt[2]))
    record("sign-thresholds.csv",result)


if __name__=="__main__":
    roots()
