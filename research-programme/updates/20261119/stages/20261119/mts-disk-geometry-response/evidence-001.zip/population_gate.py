"""Validate stellar mass convention directly from the author's released population table."""
from common_shape import HERE,np,read,record,put,json
from freeze_source import run
import re


def populations():
    receipt=json.loads((HERE/"imig-source-receipt.json").read_bytes())
    fields=read("imig-fits-fields.csv")
    types=[]
    for row in fields:
        match=re.fullmatch(r"(\d*)([AKD])",row["binary_format"])
        assert match,row
        repeat=int(match[1] or "1")
        form=match[2]
        if form=="A":
            types.append((row["field"],f"S{repeat}"))
        else:
            dtype=">f8" if form=="D" else ">i8"
            types.append((row["field"],dtype) if repeat==1 else (row["field"],dtype,(repeat,)))
    dt=np.dtype(types,align=False)
    assert dt.itemsize==receipt["row_bytes"]
    return np.frombuffer((HERE/"imig2025-density-params.fits").read_bytes(),
                         dtype=dt,count=receipt["rows"],offset=receipt["table_offset_bytes"])


def gate():
    run()
    data=populations()
    init=data["LOG_STELLAR_MASS"]
    aged=data["AGED_LOG_STELLAR_MASS"]
    frac=data["AGED_MASS_FRACTION"]
    stars=data["N_STARS_OBS"]
    rows=[]
    for tag,keep in (("all_physically_finite",np.ones(len(data),dtype=bool)),("count_gt100",stars>100),("count_ge100",stars>=100)):
        valid=keep & np.isfinite(init) & np.isfinite(aged) & (init>0) & (aged>0) & (frac>0) & (frac<=1)
        born,now=10.**init[valid],10.**aged[valid]
        check=np.max(abs(now/(born*frac[valid])-1)) if np.any(valid) else None
        rows.append(dict(selection=tag,selected=int(keep.sum()),positive_mass_rows=int(valid.sum()),
                         initial_msun=born.sum(),surviving_msun=now.sum(),max_aged_identity_relative=check,
                         bins_exactly_100=int(np.sum(stars==100))))
    record("imig-mass-gate.csv",rows)
    print(rows)


if __name__=="__main__":
    gate()
