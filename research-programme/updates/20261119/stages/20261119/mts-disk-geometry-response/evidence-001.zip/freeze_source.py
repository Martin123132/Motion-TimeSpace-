"""Acquire one immutable author-supplied data table, not their code or their star-by-star catalogue."""
from common_shape import HERE,guard,sha,put,record,json,sys
import urllib.request
import hashlib

COMMIT="06ae695be167cb45bf5499e0752ec93aca41c059"
BLOB="7238f8c31ec1f02e5e1ccff953aa2fef01cbc974"
SIZE=27881280
URL=f"https://raw.githubusercontent.com/astrojimig/mw_density_imig2025/{COMMIT}/results/mw_density_params.fits"


def header(data,offset):
    result={}
    for cursor in range(offset,offset+2880*100,80):
        card=data[cursor:cursor+80].decode("ascii")
        key=card[:8].strip()
        if key=="END":
            return result,offset+2880*((cursor+80-offset+2879)//2880)
        if card[8:10]=="= ":
            value=card[10:].strip()
            if value.startswith("'"):
                value=value[1:value.index("'",1)].strip()
            else:
                value=value.split("/")[0].strip()
            result[key]=value
    raise ValueError("missing FITS END")


def run():
    guard()
    path=HERE/"imig2025-density-params.fits"
    if not path.exists():
        assert sys.argv[1:]==["fetch"]
        with urllib.request.urlopen(URL,timeout=40) as resp:
            data=resp.read(SIZE+1)
    else:
        data=path.read_bytes()
    assert len(data)==SIZE and hashlib.sha1(f"blob {SIZE}\0".encode()+data).hexdigest()==BLOB
    primary,offset=header(data,0)
    assert primary["SIMPLE"]=="T" and int(primary["NAXIS"])==0
    ext,start=header(data,offset)
    assert ext["XTENSION"]=="BINTABLE" and start+int(ext["NAXIS2"])*int(ext["NAXIS1"])<=SIZE
    columns=[dict(number=idx,field=ext["TTYPE"+str(idx)],binary_format=ext["TFORM"+str(idx)],
                  unit=ext.get("TUNIT"+str(idx),""),dimensions=ext.get("TDIM"+str(idx),""))
             for idx in range(1,int(ext["TFIELDS"])+1)]
    put(path.name,data)
    record("imig-fits-fields.csv",columns)
    info=dict(authors="Imig et al. (2025)",doi="10.3847/1538-4357/adf723",archive="10.5281/zenodo.16423243",
              commit=COMMIT,git_blob=BLOB,url=URL,bytes=SIZE,sha256=sha(path),rows=int(ext["NAXIS2"]),
              row_bytes=int(ext["NAXIS1"]),table_offset_bytes=start,columns=len(columns),
              usage="Source acquired and binary layout checked only; no density or gravity selected from it in this stage.")
    put("imig-source-receipt.json",(json.dumps(info,indent=2)+"\n").encode())
    print(info["rows"],info["columns"],sha(path))


if __name__=="__main__":
    run()
