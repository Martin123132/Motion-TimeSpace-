from pathlib import Path
import os
import sys
import json
import hashlib
import csv
import io
for variable in ("OPENBLAS_NUM_THREADS","OMP_NUM_THREADS","MKL_NUM_THREADS","NUMEXPR_NUM_THREADS"):
    os.environ[variable]="1"
HERE=Path(__file__).resolve().parent
PREV=HERE.parent/"mts-calibrated-disk-wave-20261119"
sys.path.insert(0,str(PREV))
import branch
from branch import np, G, ordinary, OUTER, SPEED, ANCHOR
from disk_tangent import polish
from disk_state import families, basis
from scipy.special import roots_legendre, gammainc, gammaln
from scipy.integrate import quad
from scipy.optimize import brentq
SEAL="9cd7c6a1e2c1380a4df35f7edea8ad2adc4c853c67b8e380bce1203c9d373329"
DISK_GM=.6*220**2*(8**2+3.28**2)**1.5/8**2
BULGE_GM=.05*220**2*8/gammainc(.6,(8/1.9)**2)
HEIGHT=.28


def sha(file):
    return hashlib.sha256(file.read_bytes()).hexdigest()


def guard():
    branch.check()
    assert sha(PREV/"seal.json")==SEAL
    assert not any((root/"STOP-REQUESTED").exists() for root in (HERE,PREV,HERE.parent))


def put(name,data):
    file=HERE/name
    if file.exists():
        assert file.read_bytes()==data,name
    else:
        with file.open("xb") as stream:
            stream.write(data)


def record(name,rows):
    output=io.StringIO(newline="")
    writer=csv.DictWriter(output,fieldnames=tuple(rows[0]),lineterminator="\n")
    writer.writeheader()
    writer.writerows(rows)
    put(name,output.getvalue().encode())


def read(name):
    with (HERE/name).open(newline="",encoding="utf8") as stream:
        return list(csv.DictReader(stream))


def disk_fields(rad,vertical,scale):
    thick=np.hypot(HEIGHT,vertical)
    side=scale+thick
    denom=np.hypot(rad,side)
    phi=-DISK_GM/denom
    pot_a=DISK_GM*side/denom**3
    work=DISK_GM*(rad**2+side*vertical**2/thick)/denom**3
    return phi,pot_a,work


def disk_force(points,scale):
    rad=np.hypot(points[:,0],points[:,1])
    thick=np.hypot(HEIGHT,points[:,2])
    side=scale+thick
    denom=np.hypot(rad,side)
    scale_fac=-DISK_GM/denom**3
    force=scale_fac[:,None]*points
    force[:,2]*=side/thick
    derivative=force*(-3*side/denom**2)[:,None]
    derivative[:,2]+=scale_fac*points[:,2]/thick
    return force,derivative


def projected(rad,scale,order=96):
    nodes,weights=roots_legendre(order)
    theta=(nodes+1)*np.pi/4
    measure=weights*np.pi/4*np.cos(theta)
    thick=HEIGHT/np.cos(theta)
    side=scale+thick
    denom=np.hypot(rad,side)
    frac=measure @ (1-scale/denom-thick*side**2/denom**3)
    surface=measure @ (scale/denom**3+3*thick*side**2/denom**5)/(2*np.pi)
    return frac,surface


def bulge_fraction(rad):
    arg=(rad/1.9)**2
    outside=quad(lambda t: np.exp(-t-.4*np.log(t)-gammaln(.6))*np.sqrt(1-arg/t),arg,np.inf,epsabs=2e-13)[0]
    return 1-outside


def shape_rows(corrected=False):
    guard()
    rows=[]
    exponential=brentq(lambda t: (1+t)*np.exp(-t)-.5,1.,2.)
    measured=.673/2.607
    retained=BULGE_GM/(DISK_GM+BULGE_GM)
    width=np.hypot(.39,.16 if corrected else .15)
    for case,radius,bulge in [("ir-low",2.38*exponential,0.),("ir",2.51*exponential,0.),
                              ("ir-high",2.66*exponential,0.),("stars-low",4.12-width,measured),
                              ("stars",4.12,measured),("stars-high",4.12+width,measured),
                              ("retained-bt",4.12,retained)]:
        within=bulge_fraction(radius)
        def solve(order):
            return brentq(lambda scale: (1-bulge)*projected(radius,scale,order)[0]+bulge*within-.5,.01,10.,xtol=2e-13)
        geom=solve(96)
        assert abs(solve(144)-geom)<2e-10
        outer_ratio=projected(14.,geom)[1]/projected(8.,geom)[1]
        if corrected and case not in ("stars-low","stars-high"):
            continue
        name="erratum-"+case if corrected else case
        rows.append(dict(case=name,Rhalf=radius,stellar_bulge_fraction=bulge,bulge_within=within,a_kpc=geom,
                         disk_gm=DISK_GM,outer_ratio=outer_ratio,outer_efold_kpc=-6/np.log(outer_ratio),
                         data_living_ratio=np.exp(-6/2.1)))
    return rows


if __name__=="__main__":
    record("shape-inputs.csv",shape_rows())
    record("corrected-shape-inputs.csv",shape_rows(True))
