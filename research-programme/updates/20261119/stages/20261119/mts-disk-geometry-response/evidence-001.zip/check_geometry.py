from common_shape import (np, HERE, PREV, branch, guard, sha, json, sys, read, record, put, projected,
                          disk_fields, disk_force, G, HEIGHT, DISK_GM, bulge_fraction, quad)
from scipy.special import roots_legendre


def curve_scores():
    datasets=[branch.read("cepheid-table1.csv"),branch.read("eilers-table1.csv")]
    rows=[]
    for name in sorted(HERE.glob("*-forces.csv")):
        tag=name.name.removesuffix("-forces.csv")
        for model in ("mts","nfw"):
            predictions=read(tag+"-"+model+"-curve.csv")
            for sample,source in zip(("cepheid","giant"),datasets):
                vals=[row for row in predictions if row["sample"]==sample]
                assert np.array_equal([float(row["R_kpc"]) for row in vals],[float(row["R_kpc"]) for row in source])
                delta=np.array([float(row["V_kms"])-float(data["V_kms"]) for row,data in zip(vals,source,strict=True)])
                if sample=="cepheid":
                    assert abs(delta[-1])<1e-8
                    delta=delta[:-1]
                rows.append(dict(case=tag,model=model,tracer=sample,bins=len(delta),mean=np.mean(delta),
                                 rmse=np.sqrt(np.mean(delta**2)),max_abs=max(abs(delta))))
    record("scores.csv",rows)


def online_checks():
    lo,hi=8.,14.
    uniform=(lo/hi)**5
    rows=[]
    for row in read("shape-inputs.csv")+read("corrected-shape-inputs.csv"):
        scale=float(row["a_kpc"])
        target=float(row["Rhalf"])
        bulge=float(row["stellar_bulge_fraction"])
        def direct(rad,z):
            thick=np.hypot(HEIGHT,z)
            side=scale+thick
            return HEIGHT**2*(scale*rad**2+(scale+3*thick)*side**2)/(4*np.pi*thick**3*(rad**2+side**2)**2.5)
        alt_surface=2*quad(lambda z:direct(hi,z),0,np.inf,epsabs=2e-14)[0]
        alt_mass=2*np.pi*quad(lambda rad:rad*2*quad(lambda z:direct(rad,z),0,np.inf,epsabs=3e-13)[0],0,target)[0]
        mass,area=projected(target,scale)[0],projected(hi,scale)[1]
        total=(1-bulge)*alt_mass+bulge*bulge_fraction(target)
        assert abs(total-.5)<2e-10 and abs(alt_mass-mass)<3e-10 and abs(alt_surface/area-1)<2e-10
        ratio=area/projected(lo,scale)[1]
        sharpened=((lo**2+(scale+HEIGHT)**2)/(hi**2+(scale+HEIGHT)**2))**2.5
        assert ratio>sharpened>uniform>np.exp(-(hi-lo)/2.1)
        rows.append(dict(case=row["case"],a_kpc=scale,volume_vs_projected_fraction=abs(alt_mass-mass),
                         direct_half_mass_residual=total-.5,Sigma14_over_Sigma8=ratio,
                         scale_specific_ratio_floor=sharpened,positive_MN_family_floor=uniform,
                         exact_reference_exponential_ratio=np.exp(-(hi-lo)/2.1)))
    record("source-shape-checks.csv",rows)


def quantities(tag,model):
    row,=[row for row in read(tag+"-forces.csv") if row["model"]==model]
    return {key:float(row[key]) for key in ("slope","Kz","annulus_mass","extra_flux_mass","ordinary_mass","V_anchor")}


def method_checks():
    jac=read("center-jacobian.csv")
    records=[]
    for step,lower,upper in ((.01,"fine-minus","fine-plus"),(.005,"half-minus","half-plus")):
        for model in ("mts","nfw"):
            total,=[row for row in jac if row["model"]==model and row["term"]=="total"]
            high,low=quantities(upper,model),quantities(lower,model)
            for key,derived in (("slope","dslope_da"),("Kz","dKz_da"),("annulus_mass","d_annulus_msun_da")):
                finite=(high[key]-low[key])/(2*step)
                exact=float(total[derived])
                err=abs(finite/exact-1)
                records.append(dict(model=model,step=step,quantity=key,finite=finite,analytic=exact,relative=err))
                assert err<2e-5
    record("derivative-checks.csv",records)
    packet=read("shell-nonlinear.csv")
    rows=[]
    for step in (1.,.5,.25):
        plus,=[row for row in packet if float(row["strength_billion_msun"])==step]
        minus,=[row for row in packet if float(row["strength_billion_msun"])==-step]
        for row in read("split-shell-main.csv"):
            if row["source"]!="shell-40-to-25":
                continue
            key=row["quantity"]
            finite=(float(plus[key])-float(minus[key]))/(2*step)
            analytic=float(row["mts"])
            rows.append(dict(step=step,quantity=key,finite=finite,analytic=analytic,relative=abs(finite/analytic-1)))
    record("shell-derivative-checks.csv",rows)
    cols=[]
    alt=read("split-shell-above.csv")
    for row in read("split-shell-main.csv"):
        raw,=[item for item in read("source-susceptibility.csv") if item["source"]==row["source"] and item["quantity"]==row["quantity"]]
        other,=[item for item in alt if item["source"]==row["source"] and item["quantity"]==row["quantity"]]
        value=float(row["mts"])
        assert abs(float(row["forward"])/value-1)<2e-8
        cols.append(dict(source=row["source"],quantity=row["quantity"],relative_raw_split=abs(float(raw["mts"])/value-1),
                         relative_between_grids=abs(float(other["mts"])/value-1)))
    record("shell-convergence.csv",cols)


def verify():
    guard()
    parent=json.loads((PREV/"seal.json").read_bytes())["files"]
    assert all(sha(PREV/name)==digest for name,digest in parent.items())
    curve_scores()
    online_checks()
    method_checks()
    for row in read("sign-thresholds.csv"):
        assert 1<float(row["critical_a_kpc"])<5 and abs(float(row["residual_slope"]))<1e-7
    for forces in HERE.glob("*-forces.csv"):
        tag=forces.name.removesuffix("-forces.csv")
        with np.load(HERE/(tag+".npz")) as pack:
            for key in ("coef","fixed_mass_shape_dir","log_mass_dir"):
                assert np.isfinite(pack[key]).all()
            assert abs(2*np.sum(pack["coef"]*pack["log_mass_dir"])/np.sum(pack["coef"]**2)-1)<2e-10
            assert abs(np.sum(pack["coef"]*pack["fixed_mass_shape_dir"]))<1e-11 and pack["shape_residual"]<2e-10
        for row in read(forces.name):
            assert abs(float(row["V_anchor"])-224.03)<1e-8
            if row["model"]=="mts":
                assert abs(float(row["extra_flux_mass"])/float(row["volume_wave"])-1)<2e-5
                jacs=[item for item in read(tag+"-jacobian.csv") if item["model"]=="mts"]
                only_wave=sum(float(item["d_annulus_msun_da"]) for item in jacs if item["term"] in ("wave_rearrangement","outer_recalibration"))
                assert abs(only_wave-float(row["volume_wave_per_kpc"]))<10
    for row in read("source-susceptibility.csv"):
        if row["source"]=="constant":
            assert abs(float(row["mts"]))<1e-12
        elif row["source"]=="disk_scale":
            key={"slope":"dslope_da","Kz":"dKz_da","annulus_billion":"d_annulus_msun_da"}[row["quantity"]]
            for model in ("mts","nfw"):
                deriv,=[it for it in read("center-jacobian.csv") if it["model"]==model and it["term"]=="total"]
                assert abs(float(row[model])*(1e9 if key.startswith("d_ann") else 1)/float(deriv[key])-1)<1e-8
    controls=read("shell-derivative-checks.csv")
    assert max(float(row["relative"]) for row in controls if float(row["step"])==.25)<2e-5
    for seed in ("main","above"):
        for row in read("occupation-split-"+seed+".csv"):
            parts=sum(float(row[key]) for key in ("direct","induced_at_fixed_occupation","occupation_recalibration"))
            assert abs(parts-float(row["calibrated_total"]))<1e-11
    receipt=json.loads((HERE/"imig-source-receipt.json").read_bytes())
    assert sha(HERE/"imig2025-density-params.fits")==receipt["sha256"]
    pop,=[row for row in read("imig-mass-gate.csv") if row["selection"]=="count_gt100"]
    assert int(pop["positive_mass_rows"])==186 and int(pop["selected"])==186 and receipt["rows"]==360
    assert round(float(pop["initial_msun"])/1e10,2)==5.27 and round(float(pop["surviving_msun"])/1e10,1)==3.7
    assert float(pop["max_aged_identity_relative"])<1e-12
    return {p.name:len(read(p.name)) for p in sorted(HERE.glob("*.csv"))}


if __name__=="__main__":
    counts=verify()
    print("Checked",len(counts),"tables,",sum(counts.values()),"rows.",flush=True)
    if sys.argv[1:] in (["seal"],["replay"]):
        assert all((HERE/name).is_file() for name in ("RESULTS.md","DERIVATION.md","NEXT.md","REPLAY.md"))
        assert not any(p.is_dir() for p in HERE.iterdir())
        files={p.name:sha(p) for p in sorted(HERE.iterdir()) if p.name!="seal.json"}
        manifest=dict(predecessor=sha(PREV/"seal.json"),files=files,rows=counts)
        if sys.argv[1:]==["seal"]:
            put("seal.json",(json.dumps(manifest,indent=2,sort_keys=True)+"\n").encode())
        assert json.loads((HERE/"seal.json").read_bytes())==manifest
        print("Verified",len(files),"files; SHA256",sha(HERE/"seal.json"))
