from common_shape import (np, sys, json, HERE, PREV, branch, guard, read, record, put, sha, polish,
                          ordinary, OUTER, SPEED, ANCHOR, disk_force, disk_fields, roots_legendre, basis, families, G)

SMALL=.01
RLOCAL=8.3
step=.005


def arrangement():
    cep=branch.read("cepheid-table1.csv")
    old=branch.read("eilers-table1.csv")
    radii=np.array([float(row["R_kpc"]) for row in cep+old]+[RLOCAL-step,RLOCAL+step,RLOCAL-step/2,RLOCAL+step/2,RLOCAL])
    pins=np.column_stack((-radii,np.zeros((len(radii),2))))
    nodes,weights=roots_legendre(20)
    radii_q=8+nodes
    heights=(1+nodes)*.75
    loc=lambda rad,z:np.column_stack((-rad,np.zeros_like(rad),z))
    locations=np.vstack((pins,[[-RLOCAL,0.,1.5]],loc(radii_q,np.full_like(nodes,1.5)),
                         loc(np.full_like(nodes,7.),heights),loc(np.full_like(nodes,9.),heights)))
    return locations,radii,len(cep),len(old),radii_q,heights,weights


def calibrate(system,seed,scale):
    previous=3.
    initial=seed["coef"]
    rad=system.rad[:,None]*system.length
    vertical=rad*system.mu
    cylinder=rad*np.sqrt(1-system.mu**2)
    base_phi,_,base_vir=disk_fields(cylinder,vertical,previous)
    ext=system.ext.copy()
    vir=system.vir.copy()
    old_disk=disk_force(ANCHOR,previous)[0]
    bary,cloud,halo=ordinary(system,ANCHOR)
    log=[]
    for intermediate in np.linspace(previous,scale,1+max(1,int(np.ceil(abs(scale-previous)/.50))))[1:]:
        phi,pert,virial=disk_fields(cylinder,vertical,intermediate)
        system.ext=ext+(phi-base_phi)/system.vel**2
        system.vir=vir+(virial-base_vir)/system.vel**2
        new_disk,direct=disk_force(ANCHOR,intermediate)
        background=bary+cloud+new_disk-old_disk
        for count in range(10):
            guard()
            curve=polish(system,initial)
            mass_dir,_,_,_=curve.differentiate("mass")
            accel=system.force(curve.state,ANCHOR)
            response=system.force(curve.state,ANCHOR,tangent=mass_dir)
            mismatch=OUTER*(background+accel)[0,0]-SPEED**2
            log.append(dict(a_kpc=intermediate,iteration=count,norm=system.mass,speed2_minus_anchor=mismatch,
                            stationarity=np.linalg.norm(curve.resid)))
            if abs(mismatch)<2e-12*SPEED**2:
                break
            correction=np.clip(-mismatch/(OUTER*response[0,0]),-.1,.1)
            system.mass*=np.exp(correction)
            initial=curve.state+correction*mass_dir
        else:
            raise RuntimeError("fixed outer-speed root failed")
        initial=curve.state
    drive=curve.read(pert*curve.wave/system.vel**2)
    shape_dir=curve.constrained(-drive)
    value=curve.response(shape_dir)+drive
    muprime=np.sum(curve.state*value)/system.mass
    resid=np.linalg.norm(value-muprime*curve.state)
    du=-float((direct+system.force(curve.state,ANCHOR,tangent=shape_dir))[0,0]/response[0,0])
    nfw=float((SPEED**2/OUTER-background[0,0])/halo[0,0])
    dnorm=-float(direct[0,0]/halo[0,0])
    assert resid<2e-10 and abs(np.sum(curve.state*shape_dir))<1e-10 and nfw>0
    return curve.state,shape_dir,mass_dir,du,nfw,dnorm,log,resid


def report(tag,seed_tag,scale,detail=True):
    guard()
    seal=json.loads((PREV/"seal.json").read_bytes())["files"]
    assert sha(PREV/(seed_tag+".npz"))==seal[seed_tag+".npz"]
    sysm,seed=branch.load(seed_tag)
    state,shaped,massdir,du,amp,damp,log,resid=calibrate(sysm,seed,scale)
    loc,radii,nc,no,rq,zq,weights=arrangement()
    newdisk,direct=disk_force(loc,scale)
    olddisk,_=disk_force(loc,3.)
    bar,cloud,halo=ordinary(sysm,loc)
    common=bar+cloud+newdisk-olddisk
    wave=sysm.force(state,loc)
    rearrange=sysm.force(state,loc,tangent=shaped)
    mass_reaction=sysm.force(state,loc,tangent=massdir)*du
    zeros=np.zeros_like(common)
    start=len(radii)
    def annulus(force):
        faces,inside,outside=np.split(force[start+1:],3)
        return (weights @ (-rq*faces[:,2]+.75*(9*outside[:,0]-7*inside[:,0])))/G
    def mass_volume():
        rr,zz=np.meshgrid(rq,zq,indexing="ij")
        radius=np.hypot(rr,zz).ravel()/sysm.length
        cos=zz.ravel()/(radius*sysm.length)
        columns=[basis(mode,root,sysm.edge,radius) for mode,root in zip(sysm.orders,sysm.roots)]
        angular=families(cos,sysm.orders)
        expand=lambda coef:(np.column_stack([col@one for col,one in zip(columns,coef)])*angular).sum(axis=1)
        field=expand(state)
        factor=sysm.vel**2/(4*np.pi*G*sysm.length**2)
        integrate=lambda density:4*np.pi*.75*((weights*rq)@density.reshape(rr.shape)@weights)
        return integrate(factor*field**2), integrate(2*factor*field*expand(shaped+du*massdir))
    material,material_rate=mass_volume()
    mass=float(seed["mass_msun"])*sysm.mass/float(seed["mass"])
    bundle={"coef":state,"fixed_mass_shape_dir":shaped,"log_mass_dir":massdir,"du_da":du,"halo_amplitude":amp,
            "halo_per_kpc":damp,"a_kpc":scale,"mass_msun":mass,"seed_tag":seed_tag,"shape_residual":resid}
    def slope(speed):
        return (speed[-2]-speed[-3])/step
    rows=[]
    trace=[]
    for model,exc,reorg,recal in (("mts",wave,rearrange,mass_reaction),("nfw",amp*halo,zeros,damp*halo)):
        total=common+exc
        speed=np.sqrt(radii*total[:start,0])
        slope0=slope(speed)
        larger=(speed[-4]-speed[-5])/(2*step)
        counts=[("direct_disk",direct),("wave_rearrangement",reorg),("outer_recalibration",recal),("total",direct+reorg+recal)]
        for term,deriv in counts:
            speed_der=radii*deriv[:start,0]/(2*speed)
            trace.append(dict(model=model,term=term,dslope_da=slope(speed_der),dKz_da=deriv[start,2],
                              d_annulus_msun_da=annulus(deriv),dV_outer_da=speed_der[nc-1]))
        item=dict(model=model,a_kpc=scale,occupation_msun=mass if model=="mts" else "",nfw_amplitude=amp if model=="nfw" else "",
                  dlogmass_da=du if model=="mts" else "",d_nfw_da=damp if model=="nfw" else "",
                  slope=slope0,twice_step_slope=larger,Kz=total[start,2],annulus_mass=annulus(total),
                  ordinary_mass=annulus(common),extra_flux_mass=annulus(exc),
                  volume_wave=material if model=="mts" else "",volume_wave_per_kpc=material_rate if model=="mts" else "",
                  V_anchor=speed[nc-1])
        assert abs(item["V_anchor"]-SPEED)<1e-8
        rows.append(item)
        if detail:
            record(tag+"-"+model+"-curve.csv",[dict(sample="cepheid" if idx<nc else "giant",R_kpc=radius,V_kms=value,
                                                     dV_da=rate) for idx,(radius,value,rate) in enumerate(zip(radii[:nc+no],speed,speed_der))])
    if detail:
        record(tag+"-calibration.csv",log)
        record(tag+"-forces.csv",rows)
        record(tag+"-jacobian.csv",trace)
        filename=HERE/(tag+".npz")
        if filename.exists():
            with np.load(filename) as old:
                assert set(old.files)==set(bundle) and all(np.array_equal(old[key],val) for key,val in bundle.items())
        else:
            with filename.open("xb") as handle:
                np.savez_compressed(handle,**bundle)
    print(tag,seed_tag,scale,"slopes",*[row["slope"] for row in rows],flush=True)
    return rows,trace


def known(tag):
    values={"center":3., "fine-minus":3.-SMALL,"fine-plus":3.+SMALL,"half-minus":3.-SMALL/2,"half-plus":3.+SMALL/2,
            "short":1., "long":5., "center-above":3.}
    values.update({row["case"]:float(row["a_kpc"]) for row in read("shape-inputs.csv")})
    if tag.startswith("erratum-"):
        values.update({row["case"]:float(row["a_kpc"]) for row in read("corrected-shape-inputs.csv")})
    return values[tag]


if __name__=="__main__":
    for name in sys.argv[1:]:
        report(name,"above" if name=="center-above" else "main",known(name))
