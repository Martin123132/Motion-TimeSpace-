from population import *
from census_common import G,locations
from cross_stress import grid,axes,Wave
from scipy.special import ellipkm1,ellipe
from scipy.integrate import quad
from scipy.interpolate import CubicHermiteSpline

SOLAR=np.array([[-8.122,0.,.0208]])


class Bulge:
    def __init__(self,p):
        self.mass=p.bmass
        edges=np.unique(np.r_[np.linspace(0,4,1601),p.bgrid])
        nodes,wr=grid(edges,14)
        rho=p.bulge_density(nodes)
        cumulative=4*np.pi*np.r_[0.,np.cumsum(np.sum(wr*nodes**2*rho,axis=1))]
        shell=4*np.pi*np.r_[np.cumsum(np.sum(wr*nodes*rho,axis=1)[::-1])[::-1],0.]
        self.integration=cumulative[-1]; self.err=(self.integration-self.mass)/max(1.,self.mass)
        assert abs(self.err)<2e-7
        inv=np.divide(1.,edges,out=np.zeros_like(edges),where=edges>0)
        self.field=CubicHermiteSpline(edges,-G*(cumulative*inv+shell),G*cumulative*inv**2)
    def at(self,rad):
        rad=np.asarray(rad);inner=np.minimum(rad,4)
        return (np.where(rad<=4,self.field(inner),-G*self.mass/np.maximum(rad,4)),
                np.where(rad<=4,self.field(inner,1),G*self.mass/np.maximum(rad,4)**2))


def direct(p,rr,zz,order,angular):
    cuts=np.unique(np.r_[p.knots,rr,np.arange(0.,30.1,1.)])
    cuts=cuts[cuts<=EDGE]; knots,weights=roots_legendre(order)
    unit=(1+knots)/2
    xr,wr=grid(cuts,order)
    for idx,(lo,hi) in enumerate(zip(cuts[:-1],cuts[1:])):
        if rr in (lo,hi):
            xr[idx]=rr+(1 if lo==rr else -1)*(hi-lo)*unit**3
            wr[idx]=1.5*(hi-lo)*unit**2*weights
    rad,wr=xr.ravel()[:,None],wr.ravel()[:,None]
    pts,wz=roots_legendre(angular)
    zcuts=np.unique(np.r_[-25.,-10.,-5.,-2.,-.6,-.15,0.,.15,.6,2.,5.,10.,25.,zz])
    out=np.zeros(3)
    for start in range(0,len(rad),36):
        x=rad[start:start+36];rw=wr[start:start+36]
        sep=abs(rr-x);limits=np.arcsinh((zcuts-zz)/sep);half=np.diff(limits,axis=1)/2
        u=(limits[:,:-1,None]+half[:,:,None]*(1+pts)).reshape(len(x),-1)
        dz=sep*np.sinh(u)
        v=(half[:,:,None]*wz).reshape(len(x),-1)*sep*np.cosh(u)
        small=(rr-x)**2+dz**2;big=(rr+x)**2+dz**2
        k,e=ellipkm1(small/big),ellipe(1-small/big)
        mass=p.radial(x[:,0])@p.mix
        density=np.sum(mass[:,None,:]*np.exp(-abs(zz+dz)[:,:,None]/HEIGHT)/(2*HEIGHT),axis=-1)
        fac=2*G*x*rw*v*density/np.sqrt(big)
        out+=[np.sum(-2*fac*k),np.sum(fac/rr*(k+((rr-x)*(rr+x)-dz**2)/small*e)),
              np.sum(2*fac*dz/small*e)]
    return out


def build(normal,geometry,level):
    p=Profiles(normal,geometry);bulge=Bulge(p)
    dx,nmu,lmax,order=(.13,192,100,7) if level=="medium" else (.065,320,180,8)
    edges=np.unique(np.r_[np.arange(0,32,dx),p.knots,np.linspace(32,48,25)])
    nodes,wr=grid(edges,order);rad=nodes.ravel()
    mus,aw=roots_legendre(nmu);mu=(1+mus)/2;weights=aw/2
    modes=np.arange(0,lmax+1,2);leg=axes(modes,mu)[0]*weights[:,None]
    moments=np.empty((len(rad),len(modes)))
    for idx in range(0,len(rad),32):
        radius=rad[idx:idx+32,None]
        moments[idx:idx+len(radius)]=p.density(radius*np.sqrt(1-mu**2),radius*mu)@leg
    wave=Wave(edges,nodes,wr,modes,moments)
    tag=f"{normal}-{geometry}-{level}"
    bphi,bdr=bulge.at(edges)
    wave.phi[:,0]+=bphi;wave.der[:,0]+=bdr
    save(tag+"-gravity",r=edges,phi=wave.phi,der=wave.der,mode=modes)
    table(tag+"-mass-check.csv",[dict(expected_total=sum(p.masses),disk_expected=sum(p.masses)-p.bmass,disk_field=wave.mass,
                                       bulge_projection=p.bmass,bulge_abel_integral=bulge.integration,
                                       mass_rel=(wave.mass+p.bmass)/sum(p.masses)-1)])
    loc=np.vstack((locations(),SOLAR))
    nrad,nz=(10,20) if level=="medium" else (16,32)
    val=np.array([direct(p,-pt[0],pt[2],nrad,nz) for pt in loc])
    rad=np.linalg.norm(loc,axis=1);phi,dr=bulge.at(rad)
    val+=np.column_stack((phi,-loc[:,0]/rad*dr,-loc[:,2]/rad*dr))
    save(tag+"-readout",locations=loc,values=val)
    print(tag,"mass discrepancy",(wave.mass+p.bmass)/sum(p.masses)-1,flush=True)


if __name__=="__main__":
    for param in sys.argv[1:]:build(*param.split(":"))

