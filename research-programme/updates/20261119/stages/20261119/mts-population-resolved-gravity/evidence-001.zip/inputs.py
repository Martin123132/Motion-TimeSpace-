import csv
import hashlib
import io
import json
import os
import sys
import urllib.request
from pathlib import Path

HERE=Path(__file__).resolve().parent
CENSUS=HERE.parent/"mts-census-loaded-gravity-20261119"
sys.path.insert(0,str(CENSUS))
from census_common import np,guard as previous_guard,sha
from scipy.special import roots_legendre

PIN="78ba3c4e8e92a2d3b6e03842e437d6e95df6e9fd"
BASE=f"https://raw.githubusercontent.com/lianjianhui/Source-data-for-MW-mass-paper/{PIN}/"
FILES={"README.md":"23db1fee9d60b6acaaa25f5076d735245d486187","density-dtr-sn-260424.fits":"f5a8a01b16f83ebdb975b0092468356867c10582","surfm-remnants-260820.txt":"0966ad278ccd4e722f280f0ae4d29c4926f7e091"}
LABELS=("living","white_dwarf","neutron_star","black_hole")
TOL=2e-5


def guard(full=False):
    previous_guard(full)
    assert sha(CENSUS/"seal.json")=="fbfba899c429a57c0c86bb04168dd325aa66560c6ba8ebe5edeaac54ef152e69"
    if full: assert all(sha(CENSUS/k)==v for k,v in json.loads((CENSUS/"seal.json").read_bytes())["files"].items())
    assert not any((p/"STOP-REQUESTED").exists() for p in (HERE,CENSUS,HERE.parent))


def put(name,data):
    p=HERE/name
    if p.exists(): assert p.read_bytes()==data,name
    else:
        with p.open("xb") as h: h.write(data)


def save(name,**fields):
    p=HERE/(name+".npz")
    if p.exists():
        with np.load(p) as old:
            assert set(old)==set(fields) and all(np.array_equal(old[k],v) for k,v in fields.items()),name
    else:
        with p.open("xb") as h: np.savez_compressed(h,**fields)


def table(name,rows):
    buf=io.StringIO(newline="")
    out=csv.DictWriter(buf,fieldnames=tuple(rows[0]),lineterminator="\n")
    out.writeheader();out.writerows(rows);put(name,buf.getvalue().encode())


def read(name):
    with (HERE/name).open(newline="",encoding="utf8") as h: return list(csv.DictReader(h))


def acquire():
    guard(True);rows=[]
    for k,blob in FILES.items():
        p="authors-"+k
        data=(HERE/p).read_bytes() if (HERE/p).exists() else urllib.request.urlopen(BASE+k,timeout=25).read(100001)
        assert 0<len(data)<100000 and hashlib.sha1(b"blob "+str(len(data)).encode()+b"\0"+data).hexdigest()==blob
        put(p,data)
        rows.append(dict(file=p,url=BASE+k,commit=PIN,bytes=len(data),git_blob=blob,sha256=hashlib.sha256(data).hexdigest()))
    table("source-receipts.csv",rows)


def fits_images():
    data=(HERE/"authors-density-dtr-sn-260424.fits").read_bytes()
    offset=0;result=[]
    while offset<len(data):
        cards={}
        while True:
            line=data[offset:offset+80].decode("ascii");offset+=80
            if line[:8].strip()=="END": break
            if line[8:10]=="= ": cards[line[:8].strip()]=line[10:].split("/")[0].strip().strip("'").strip()
        offset=(offset+2879)//2880*2880
        axes=[int(cards["NAXIS"+str(i+1)]) for i in range(int(cards["NAXIS"]))]
        bit=int(cards["BITPIX"]);size=int(np.prod(axes))*abs(bit)//8 if axes else 0
        if size:
            assert cards.get("XTENSION","IMAGE")=="IMAGE" and bit in (-32,-64) and int(cards.get("PCOUNT",0))==0
            arr=np.frombuffer(data[offset:offset+size],dtype=">f"+str(abs(bit)//8)).astype(float).reshape(axes[::-1])
            result.append(arr)
        print("HDU",axes,bit, list(cards)[-8:]) if __name__=="__main__" else None
        offset=(offset+size+2879)//2880*2880
    assert offset==len(data);return result


if __name__=="__main__":
    acquire()
    for arr in fits_images():
        print(arr.shape,arr[:3] if arr.shape[-1]<10 else arr[:,:4])

