from inputs import *
from scipy.integrate import quad
from scipy.optimize import brentq

LOCAL=np.array([25.438,4.599,.682,1.560])
MASS=1e10*np.array([2.031,.435,.058,.132])
HALF=np.array([4.24,3.62,3.98,4.0])
HEIGHT=np.array([.265,.795])
R0=8.2
EDGE=30.
ARCH="https://raw.githubusercontent.com/lianjianhui/Source-data-for-MW-mass-paper/a4f8fe81f97e7012600b8dcf3a1c5416aa4ecd5d/density-dtr-sn-250615.fits"


def archive_axis():
    name="archive-axis-witness.fits"
    raw=(HERE/name).read_bytes() if (HERE/name).exists() else urllib.request.urlopen(ARCH,timeout=20).read(100001)
    assert hashlib.sha1(b"blob "+str(len(raw)).encode()+b"\0"+raw).hexdigest()=="efa1e1334cb9d1c2fde26b1b567095c4ced41624"
    put(name,raw)
    return np.frombuffer(raw,offset=2880,count=357*6,dtype=">f8").reshape(357,6)[:,-1]


class Profiles:
    def __init__(self,normal="mass",geometry="spherical"):
        guard()
        raw=np.loadtxt(HERE/"authors-surfm-remnants-260820.txt",skiprows=1)
        self.centres=raw[:,0];self.data=raw[:,1:9:2];self.err=raw[:,2:10:2]
        assert np.max(abs(self.data.sum(axis=1)-raw[:,-2]))<.0021
        upper=normal in ("upper1","upper2")
        if upper:
            assert geometry=="spherical"
            with np.load(HERE/("angular-maximizer-"+normal[-1]+".npz")) as pk:
                new=pk["physical"]
                assert np.max(abs(new/pk["normalizations"]-self.data)/self.err)<float(normal[-1])+1e-8
                self.data=new
        arr,errors=fits_images()
        z=archive_axis();self.z=z;self.local=arr[:,:4]
        assert np.allclose(arr[:,-1]*1e9,z,rtol=3e-15,atol=1e-16) and np.array_equal(arr[:,-1],errors[:,-1])
        assert np.max(abs(self.local.sum(axis=1)-arr[:,4]))<1e-14 and np.min(self.local)>0
        self.H=min(abs(z[0]),z[-1]);axis=np.unique(np.r_[0.,abs(z[abs(z)<self.H]),self.H])
        self.axis=axis
        self.fold=np.array([np.interp(axis,z,d)+np.interp(-axis,z,d) for d in self.local.T]).T
        f0=1-np.exp(-self.H/HEIGHT);f1=HEIGHT*(1-(1+self.H/HEIGHT)*np.exp(-self.H/HEIGHT))
        self.mean=np.trapezoid(axis[:,None]*self.fold,axis,axis=0)/np.trapezoid(self.fold,axis,axis=0)
        a=f1[0]-self.mean*f0[0];b=f1[1]-self.mean*f0[1]
        self.thick=a/(a-b)
        assert min(self.thick)>0 and max(self.thick)<1
        self.mix=np.stack([1-self.thick,self.thick],axis=-1)
        self.knots=np.unique(np.r_[0.,self.centres,4.,EDGE])
        def integ(j,pmax):
            cuts=self.knots[self.knots<pmax]
            return sum(quad(lambda rad:2*np.pi*rad*self.raw_sigma(rad)[j]*1e6,l,u)[0] for l,u in zip(cuts,np.r_[cuts[1:],pmax]))
        self.rawmass=np.array([integ(j,EDGE) for j in range(4)])
        self.factors=np.ones(4) if upper else MASS/self.rawmass if normal=="mass" else LOCAL/self.raw_sigma(R0)
        if upper:assert np.max(abs(self.rawmass/MASS-1))<2e-9
        self.normal=normal;self.geometry=geometry
        self.bgrid=np.array([0.,.5,1.5,2.5,3.5,4.])
        at4=self.raw_sigma(4.);slope=(self.raw_sigma(6.5)-self.raw_sigma(4.5))/2
        bg=at4+(np.maximum(self.bgrid,.5)-4)[:,None]*slope
        self.bcentral=(self.raw_sigma(self.bgrid)-bg)*self.factors if geometry=="spherical" else np.zeros_like(bg)
        self.bgradient=np.diff(self.bcentral,axis=0)/np.diff(self.bgrid)[:,None]
        assert np.max(self.bgradient)<1e-10 and np.min(self.bcentral)>-1e-10
        self.bmass=sum(2*np.pi*quad(lambda rad: rad*self.bulge_sigma(rad).sum()*1e6,l,u)[0] for l,u in zip(self.bgrid,self.bgrid[1:]))
        self.masses=self.factors*self.rawmass
        self.half=np.array([brentq(lambda rad:integ(j,rad)-.5*self.rawmass[j],.5,16.5) for j in range(4)])
    def raw_sigma(self,r):
        r=np.asarray(r)
        tab=np.stack([np.interp(r,self.centres,col) for col in self.data.T],axis=-1)
        return tab*np.exp(-np.maximum(r-16.5,0)/2.1)[...,None]*(r[...,None]<=EDGE)
    def bulge_sigma(self,r):
        return np.stack([np.interp(r,self.bgrid,col,right=0.) for col in self.bcentral.T],axis=-1)
    def radial(self,r):
        return (self.raw_sigma(r)*self.factors-self.bulge_sigma(r))*1e6
    def density(self,r,z):
        return np.sum((self.radial(r)@self.mix)*np.exp(-abs(z)[...,None]/HEIGHT)/(2*HEIGHT),axis=-1)
    def bulge_density(self,r):
        r=np.maximum(np.asarray(r),1e-12)
        upper=np.arccosh(np.maximum(1,self.bgrid[1:]/r[...,None]))
        lower=np.arccosh(np.maximum(1,self.bgrid[:-1]/r[...,None]))
        return -(upper-lower)@self.bgradient.sum(axis=1)*1e6/np.pi


def diagnostic():
    rows=[];vertical=[];components=[]
    for normal in ("mass","local"):
        for geometry in ("flat","spherical"):
            p=Profiles(normal,geometry)
            for j,kind in enumerate(LABELS):
                sigma=p.raw_sigma(R0)[j]*p.factors[j]
                rows.append(dict(normal=normal,geometry=geometry,population=kind,table_raw_mass=p.rawmass[j],normalization=p.factors[j],
                                 mass=p.masses[j],published_mass=MASS[j],local=sigma,published_local=LOCAL[j],half=p.half[j],published_half=HALF[j],
                                 fraction_thick=p.thick[j],mean_abs_z_observed=p.mean[j],bulge_total=p.bmass))
            if geometry=="spherical":
                for r in np.r_[0.,p.centres,R0]:
                    for j,kind in enumerate(LABELS):components.append(dict(normal=normal,R=r,population=kind,total=p.factors[j]*p.raw_sigma(r)[j],
                        disk=p.radial(r)[j]/1e6,bulge=p.bulge_sigma(r)[j]))
        if normal!="mass":continue
        for h in (.1,.3,.6,1.1,1.5,2.,p.H):
            axis=np.unique(np.r_[p.axis[p.axis<h],h])
            for j,kind in enumerate(LABELS):
                plus,minus=[np.trapezoid(np.interp(sign*axis,p.z,p.local[:,j]),axis)*1e3 for sign in (1,-1)]
                model=np.sum(p.mix[j]*(1-np.exp(-h/HEIGHT)))*LOCAL[j]
                vertical.append(dict(population=kind,height=h,observed_north=plus,observed_south=minus,model=model,
                                     difference_as_fraction_of_full=(model-plus-minus)/LOCAL[j]))
    table("source-calibration.csv",rows);table("vertical-shape-test.csv",vertical);table("projected-source.csv",components)


if __name__=="__main__":diagnostic()

