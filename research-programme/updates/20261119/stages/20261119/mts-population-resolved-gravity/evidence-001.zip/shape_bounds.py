from population import *
from census_common import G,OUTER,SPEED,branch,locations,PREV
from feasibility import UNIT,bands
from common_shape import BULGE_GM
from scipy.special import ellipkm1,ellipe
from scipy.optimize import linprog

RADIUS=np.array([6.,8.3,OUTER]); ZED=np.array([1.5,1.5,0.])
GEOM=np.hypot(RADIUS,ZED)
POSITIONS=np.column_stack((-RADIUS,np.zeros(3),ZED))


def make(p,geom,order):
    basis17=np.eye(17)
    def interp(r):
        x=np.asarray(r)
        return np.stack([np.interp(x,p.centres,vals) for vals in basis17],axis=-1)*np.exp(-np.maximum(x-16.5,0)/2.1)[...,None]
    centre=np.array([0.,.5,1.5,2.5,3.5,4.])
    bg=interp(4.)+(np.maximum(centre,.5)-4.)[:,None]*(interp(6.5)-interp(4.5))/2
    excess=(interp(centre)-bg)*int(geom=="spherical")
    def split(r):
        return np.stack([np.interp(r,centre,vals,right=0.) for vals in excess.T],axis=-1)
    def moment(fun,cuts):
        xx,ww=roots_legendre(18);res=0.
        for left,right in zip(cuts,cuts[1:]):
            r=(left+right)/2+xx*(right-left)/2
            res+=2*np.pi*((ww*(right-left)/2*r)@fun(r))*1e6
        return res
    bulgem=moment(split,centre)
    norm=moment(interp,p.knots)
    output=[]
    for rr,z in zip(RADIUS,ZED):
        cuts=np.unique(np.r_[p.knots,rr,np.arange(31)])
        x,w=roots_legendre(order);u=(x+1)/2
        vz,vw=roots_legendre(2*order)
        points=np.unique(np.r_[-25.,-10.,-5.,-2.,-.6,-.15,0.,.15,.6,2.,5.,10.,25.,z])
        transfer=np.zeros((2,2,17))
        for l,h in zip(cuts,cuts[1:]):
            r=l+(h-l)*u;wr=w*(h-l)/2
            if l==rr or h==rr:
                r=rr+(1 if l==rr else -1)*(h-l)*u**3;wr=1.5*w*(h-l)*u**2
            frame=interp(r)-split(r)
            rad=r[:,None];sep=abs(rad-rr)
            bounds=np.arcsinh((points-z)/sep)
            scale=np.diff(bounds,axis=1)/2
            vs=(bounds[:,:-1,None]+scale[:,:,None]*(1+vz)).reshape(order,-1)
            dz=sep*np.sinh(vs)
            wz=(scale[:,:,None]*vw).reshape(order,-1)*sep*np.cosh(vs)
            small=sep**2+dz**2;big=(rad+rr)**2+dz**2;ratio=small/big
            kk,ee=ellipkm1(ratio),ellipe(1-ratio)
            common=2*G*rad*wr[:,None]*wz/np.sqrt(big)*1e6
            inc=common/rr*(kk+((rr-rad)*(rr+rad)-dz**2)/small*ee)
            vertical=2*common*dz/small*ee
            for j,height in enumerate(HEIGHT):
                den=np.exp(-abs(z+dz)/height)/(2*height)
                transfer[0,j]+=np.sum(inc*den,axis=1)@frame
                transfer[1,j]+=np.sum(vertical*den,axis=1)@frame
        shapes=np.einsum("qhb,ph->qpb",transfer,p.mix)
        dist=np.hypot(rr,z)
        shapes+=G*np.array([rr,-z])[:,None,None]/dist**3*bulgem[None,None,:]
        output.append(shapes.reshape(2,68))
    return np.stack(output),norm,interp(R0),excess,bg


def solve():
    bands_data=bands();outputs=[];residuals=[];witnesses=[];angular_limits=[]
    for geom in ("flat","spherical"):
        for normal in ("mass","local"):
            p=Profiles(normal,geom)
            tag=f"{normal}-{geom}-fine-main-384-32"
            kernel,global_w,local_w,excess,bg=make(p,geom,16)
            pkt=np.load(HERE/(tag+".npz"));loc=pkt["locations"];direct=pkt["base"]
            radidx=[len(loc)-4,len(loc)-3,int(np.where((loc[:,0]==-OUTER)&(loc[:,2]==0))[0][0])]
            assert np.allclose(loc[radidx],POSITIONS)
            with np.load(HERE/(f"{normal}-{geom}-fine-readout.npz")) as bank:values=bank["values"][radidx,1:]
            stellar=kernel@(p.data*p.factors).T.ravel()
            assert np.max(abs(stellar-values))<1e-7
            base=direct[radidx][:,[0,2]]-values
            wr=global_w/1e9 if normal=="mass" else local_w
            goal=MASS/1e9 if normal=="mass" else LOCAL
            for halo in ("fixed-scale","arbitrary-positive","nonincreasing","slope-at-least-one"):
                for component in ("polar","radial","both"):
                    alt=halo!="fixed-scale"; num=74
                    eq=np.zeros((4,num));indices=np.arange(68)
                    for j in range(4): eq[j,j*17:(j+1)*17]=wr
                    hm=branch.foreground(POSITIONS)[2][:,[0,2]]
                    for width in (0.,1.,2.):
                        mat=[];bounds=[]
                        def add(coeff,rhs):
                            mat.append(coeff);bounds.append(rhs)
                        for i in indices:
                            j,b=divmod(i,17);mean=p.data[b,j];error=p.err[b,j]
                            upper=np.zeros(num);upper[i]=1;upper[68+j]=-(mean+width*error)
                            lower=np.zeros(num);lower[i]=-1;lower[68+j]=max(0,mean-width*error)
                            add(upper,0);add(lower,0)
                        if geom=="spherical":
                            for j in range(4):
                                for drow in np.r_[np.diff(excess,axis=0),-bg]:
                                    cons=np.zeros(num);cons[17*j:17*j+17]=drow;add(cons,0.)
                        if halo=="fixed-scale" and component=="polar":
                            for j,rr in enumerate(RADIUS[:2]):
                                direct=np.array([-1.5,-rr])*UNIT/GEOM[j]
                                coeff=np.zeros(num);coeff[:68]=direct@kernel[j]
                                vals=[]
                                for sign in (1,-1):
                                    sol=linprog(sign*coeff,A_ub=mat,b_ub=bounds,A_eq=eq,b_eq=goal,bounds=(0,None),method="highs")
                                    assert sol.success,sol.message
                                    vals.append(direct@base[j]+coeff@sol.x)
                                    if (normal,geom,j,sign)==("mass","spherical",0,-1) and width in (1.,2.):
                                        save("angular-maximizer-"+str(int(width)),physical=sol.x[:68].reshape(4,17).T,
                                             normalizations=sol.x[68:72],radius=rr,width=width,predicted=vals[-1])
                                n,s=bands_data[rr,"atheta","north"],bands_data[rr,"atheta","south"]
                                angular_limits.append(dict(normal=normal,geometry=geom,R=rr,width=width,bar_min=vals[0],bar_max=vals[1],
                                              dark_min=max(n[3],-s[4])-vals[1],dark_max=min(n[4],-s[3])-vals[0]))
                        outer0=(SPEED**2/OUTER-base[-1,0]);outerk=-kernel[-1,0]
                        positive=np.zeros(num);positive[:68]=-outerk
                        add(positive,outer0)
                        if alt:
                            scale=OUTER**2/(G*1e9)
                            ma=np.zeros(num);ma[72:]=[1,-1];add(ma,0.)
                            ma=np.zeros(num);ma[73]=1;ma[:68]=-scale*outerk;add(ma,scale*outer0)
                            if halo in ("nonincreasing","slope-at-least-one"):
                                power=3 if halo=="nonincreasing" else 2
                                v1,v2,v3=np.diff(np.r_[0.,GEOM**power])
                                ma=np.zeros(num);ma[72:]=[-(1+v2/v1),1];add(ma,0)
                                ma=np.zeros(num);ma[72:]=[v3/v2,-(1+v3/v2)];ma[:68]=scale*outerk;add(ma,-scale*outer0)
                        for (rr,kind,side),stats in bands_data.items():
                            ang=kind=="atheta"
                            if component=="polar" and not ang or component=="radial" and ang:continue
                            j=0 if rr==6. else 1
                            orient=np.array([-1.5,-rr]) if ang else np.array([-rr,1.5])
                            orient=orient*UNIT/GEOM[j]*(-1 if ang and side=="south" else 1)
                            a=np.zeros(num);a[:68]=orient@kernel[j];offset=orient@base[j]
                            if not alt:
                                dark=orient@hm[j]/hm[-1,0]
                                offset+=dark*outer0;a[:68]+=dark*outerk
                            elif not ang:a[72+j]=-G*1e9*UNIT/GEOM[j]**2
                            add(a,stats[4]-offset);add(-a,offset-stats[3])
                        def feasible():return linprog(np.zeros(num),A_ub=mat,b_ub=bounds,A_eq=eq,b_eq=goal,bounds=(0,None),method="highs")
                        sol=feasible()
                        assert sol.status in (0,2),sol.message
                        outputs.append(dict(normal=normal,geometry=geom,halo=halo,component=component,raw_bin_width=width,feasible=sol.success))
                        if sol.success:
                            violation=np.max(np.array(mat)@sol.x-bounds)
                            assert violation<1e-6 and max(abs(eq@sol.x-goal))<1e-7 and min(sol.x[68:72])>0.
                            if component=="both" and width==1:
                                witnesses.append(dict(normal=normal,geometry=geom,halo=halo,max_violation=violation,
                                     M1_billion=sol.x[72] if alt else "",M2_billion=sol.x[73] if alt else "",
                                     raw_sigmas=json.dumps(((sol.x[:68].reshape(4,17)/sol.x[68:72,None]-p.data.T)/p.err.T).round(9).tolist())))
            residuals.append(dict(normal=normal,geometry=geom,error_max_kms2kpc=np.max(abs(stellar-values))))
    table("stellar-bin-cone.csv",outputs);table("kernel-replay.csv",residuals)
    table("bounded-angular-source.csv",angular_limits)
    if witnesses:table("diagnostic-witnesses.csv",witnesses)


if __name__=="__main__":solve()

