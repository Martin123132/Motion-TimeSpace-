from inputs import *
from population import archive_axis,MASS,LOCAL
from feasibility import UNIT,bands


def audit(write):
    guard(True)
    for row in read("source-receipts.csv"):
        filename=row["file"];assert sha(HERE/filename)==row["sha256"]
        data=(HERE/filename).read_bytes()
        assert hashlib.sha1(b"blob "+str(len(data)).encode()+b"\0"+data).hexdigest()==row["git_blob"]
    arr,err=fits_images()
    assert arr.shape==err.shape==(357,6) and max(abs(archive_axis()-arr[:,-1]*1e9))<1e-14
    assert abs(32.378-sum(LOCAL)-.099)<1e-10 and abs(2.659e10-sum(MASS)-3e7)<1
    assert len(read("source-calibration.csv"))==16
    scores=read("matched-and-control-scores.csv");assert len(scores)==24
    compare=read("observable-refinements.csv"); assert len(compare)==180 and all(x["within_target"]=="True" for x in compare)
    assert max(float(x["mixed_max"]) for x in read("readout-quadrature.csv"))<TOL
    for row in read("global-and-vertical-budgets.csv"):
        assert abs(float(row["abel_mass_rel"]))<TOL and 0<float(row["outer_fraction"])<1.
    checked=read("stellar-bin-cone.csv"); assert len(checked)==144
    assert len(read("bounded-angular-source.csv"))==24 and len(read("kernel-replay.csv"))==4
    sets=[("main",256,24,"medium"),("main",384,32,"fine"),("above",384,32,"fine")]
    for grid,count,order,q in sets:
        angular=read(f"{grid}-{count}-{order}-required-angular-source.csv")
        assert len(angular)==(2 if grid=="above" else 8)
        if grid!="above":
            vals=read(f"mass-spherical-{q}-{grid}-{count}-{order}-angular-susceptibility.csv")
            assert len(vals)==2 and all(float(r["taylor_rel"])<TOL for r in vals)
        for prefix in (["mass-spherical"] if grid=="above" else ["mass-flat","mass-spherical","local-flat","local-spherical"]):
            tag=f"{prefix}-{q}-{grid}-{count}-{order}"
            rows=read(tag+"-residual.csv");assert len(rows)==4 and all(float(r["relative"])<3e-13 and abs(float(r["normerr"]))<1e-11 for r in rows)
    extremes=[]
    for width in (1,2):
        prefix=f"upper{width}-spherical-fine-main-384-32"
        assert max(float(row["relative"]) for row in read(prefix+"-residual.csv"))<3e-13
        with np.load(HERE/(prefix+".npz")) as pkt,np.load(HERE/(f"angular-maximizer-{width}.npz")) as expected:
            direction=np.array([-1.5,0.,-6.])/np.hypot(6.,1.5)*UNIT
            bary=direction@pkt["base"][-4]
            assert abs(bary-float(expected["predicted"]))<1e-9
            bound=next(r for r in read("bounded-angular-source.csv") if (r["normal"],r["geometry"],float(r["width"]),float(r["R"]))==("mass","spherical",width,6.))
            required=float(bound["dark_min"])
            for model in ("nfw","mts"):
                other=direction@pkt["matched_"+model+"_force"][-4]
                north=bands()[6.,"atheta","north"]
                src=next(r for r in read(prefix+"-results.csv") if r["mode"]=="matched" and r["model"]==model)
                assert abs(float(src["outer"])-224.03)<1e-7
                extremes.append(dict(width=width,model=model,bar=bary,extra=other,total=bary+other,
                                     needed_extra=required,remaining_to_nearer_edge=required-other,quasar=src["quasar"],cep11=src["cep11"],giant38=src["giant38"]))
    if write:table("relaxed-bin-extremes.csv",extremes)
    saved_extremes=read("relaxed-bin-extremes.csv")
    assert len(saved_extremes)==len(extremes)==4
    for original,recomputed in zip(saved_extremes,extremes,strict=True):
        assert original=={key:str(value) for key,value in recomputed.items()}
    for file in HERE.glob("*.csv"):
        parsed=read(file.name)
        assert parsed and all(None not in r and None not in r.values() and not any(v.lower() in ("nan","inf","-inf") for v in r.values()) for r in parsed)
    assert all((HERE/n).exists() for n in ("RESULTS.md","DERIVATION.md","REPLAY.md","PROTOCOL.md","NEXT.md"))
    assert not any(p.is_dir() for p in HERE.iterdir())
    return dict(previous=sha(CENSUS/"seal.json"),files={p.name:sha(p) for p in sorted(HERE.iterdir()) if p.name!="seal.json"})


if __name__=="__main__":
    assert sys.argv[1:] in (["seal"],["replay"])
    manifest=audit(sys.argv[1]=="seal")
    if sys.argv[1]=="seal":put("seal.json",(json.dumps(manifest,sort_keys=True,indent=2)+"\n").encode())
    assert json.loads((HERE/"seal.json").read_bytes())==manifest
    print("verified",len(manifest["files"]),"files",sha(HERE/"seal.json"))

