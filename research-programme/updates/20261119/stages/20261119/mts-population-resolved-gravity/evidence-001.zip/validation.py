from inputs import *
from gravity import Profiles,Bulge,direct,SOLAR
from population import MASS,LOCAL,HEIGHT,R0
from scipy.integrate import quad
from census_common import TOL,G,PREV,branch
from feasibility import UNIT


def inspect():
    guard(True);budgets=[];shapes=[];grids=[];sky=[];scores=[];tails=[]
    for normal in ("mass","local"):
        for geom in ("flat","spherical"):
            p=Profiles(normal,geom);b=Bulge(p);key=f"{normal}-{geom}"
            sigma=p.raw_sigma(R0)*p.factors
            zhalf=np.sum(sigma[:,None]*p.mix*(1-np.exp(-1.1/HEIGHT)))
            mid=np.sum(sigma[:,None]*p.mix/(2000*HEIGHT))
            mass=sum(p.masses);tail=quad(lambda r:2*np.pi*r*1e6*np.sum(p.raw_sigma(r)*p.factors),16.5,30)[0]
            budgets.append(dict(normal=normal,geometry=geom,total_mass=mass,bulge_mass=b.mass,local_column=sum(sigma),
                                column_1p1=zhalf,midplane=mid,extrapolated_outer_mass=tail,outer_fraction=tail/mass,
                                r50_min=min(p.half),r50_max=max(p.half),abel_mass_rel=b.err))
            if geom=="spherical":
                for rr in (0.,.3,.5,1.05,1.5,2.5,3.9):
                    knots=np.unique(np.sqrt(np.maximum(p.bgrid**2-rr**2,0)))
                    back=sum(2*quad(lambda z:p.bulge_density(np.hypot(rr,z)),l,u,epsrel=2e-10)[0] for l,u in zip(knots,knots[1:]))/1e6
                    target=p.bulge_sigma(rr).sum()
                    assert abs(back/target-1)<TOL
                    shapes.append(dict(normal=normal,R=rr,reprojected=back,input=target,relative=back/target-1))
            class Outer:
                knots=p.knots
                mix=p.mix
                @staticmethod
                def radial(r):return p.radial(r)*(r>16.5)[:,None]
            for r,z in ((17.58,0.),(8.122,.0208),(6.,1.5),(8.3,1.5)):
                val=direct(Outer,r,z,16,32);tails.append(dict(normal=normal,geometry=geom,R=r,z=z,
                              exterior_gin=val[1],exterior_gz=val[2],direct_only=True))
            hi=key+"-fine-main-384-32"
            for alt in [key+"-medium-main-256-24"]+([key+"-fine-above-384-32"] if key=="mass-spherical" else []):
                for a,c in zip(read(hi+"-results.csv"),read(alt+"-results.csv")):
                    assert (a["model"],a["mode"])==(c["model"],c["mode"])
                    for name in ("outer","slope","cep11","giant38","Kz","quasar"):
                        delta=(float(c[name])-float(a[name]))/max(1.,abs(float(a[name])))
                        grids.append(dict(normal=normal,geometry=geom,alternative=alt,mode=a["mode"],model=a["model"],
                                          metric=name,scaled_difference=delta,within_target=abs(delta)<TOL))
            for a in read(hi+"-results.csv"):
                rows=[r for r in read(hi+"-sky.csv") if (r["mode"],r["model"])==(a["mode"],a["model"])]
                assert len(rows)==8
                angular=sum(r["inside"]=="True" for r in rows if r["component"]=="atheta");radial=sum(r["inside"]=="True" for r in rows if r["component"]=="ar")
                scores.append(dict(normal=normal,geometry=geom,**a,polar_count=angular,radial_count=radial,quasar_diff_over_width=(float(a["quasar"])-5.05)/.35))
                if a["mode"]=="matched":assert abs(float(a["outer"])-224.03)<1e-7
            with np.load(HERE/(hi+".npz")) as pkt:
                np.testing.assert_allclose(np.sum(pkt["state"]**2),pkt["mass"],rtol=1e-13)
            for variant in ("medium","fine"):
                t=read(key+"-"+variant+"-mass-check.csv")[0]
                assert abs(float(t["mass_rel"]))<TOL
            with np.load(HERE/(key+"-medium-readout.npz")) as coarse,np.load(HERE/(key+"-fine-readout.npz")) as fine:
                diff=coarse["values"]-fine["values"]
                assert np.allclose(coarse["locations"],fine["locations"])
                for j,meas in enumerate(("phi","gin","gz")):
                    sky.append(dict(normal=normal,geometry=geom,channel=meas,absolute_max=max(abs(diff[:,j])),
                                    mixed_max=max(abs(diff[:,j])/np.maximum(1.,abs(fine["values"][:,j])))))
    table("global-and-vertical-budgets.csv",budgets);table("projected-bulge-replay.csv",shapes);table("readout-quadrature.csv",sky)
    table("observable-refinements.csv",grids);table("direct-tail-sensitivity.csv",tails);table("matched-and-control-scores.csv",scores)


if __name__=="__main__":inspect()

