from inputs import *
from census_common import branch,G,locations
from disk_state import basis,root_values,families
from cross_stress import grid,axes
from feasibility import bands,UNIT

def project(sys_tag,count,order):
    with np.load(branch.HERE/(sys_tag+".npz")) as ref:
        length=float(ref["length"]);edge=float(ref["edge"])
    with np.load(branch.PARENT/("angular24-cap.npz" if sys_tag=="above" else "angular28-diff.npz")) as ref:
        vel=float(ref["velocity_unit_kms"])
    rad=np.array([6,8.3]);sphere=np.hypot(rad,1.5);unit=sphere/length;mu=1.5/sphere
    cuts=np.unique(np.r_[0,unit,np.linspace(0,edge,131)])
    r,w=grid(cuts,12);r=r.ravel();w=w.ravel()
    nodes,weights=roots_legendre(3*order+40);u=(nodes+1)/2;weights=weights/2
    modes=np.arange(0,order+1,2);full=np.arange(0,2*order+1,2)
    bmat=[basis(m,root_values(m,count),edge,r) for m in modes]
    angular=families(u,modes);pol=axes(full,u)[0]*weights[:,None]
    leg,grad=axes(full,mu)
    records=[]; totals=[]; labels=("mass-spherical-fine",) if sys_tag=="above" else tuple(n+"-"+g+"-"+("medium" if count==256 else "fine") for n in ("mass","local") for g in ("spherical","flat"))
    for label in labels:
        tag=f"{label}-{sys_tag}-{count}-{order}"
        with np.load(HERE/(tag+".npz")) as ref:
            state=ref["state"];base=ref["base"];wave=ref["matched_mts_force"];loc=ref["locations"]
        density=(np.column_stack([m@v for m,v in zip(bmat,state)])@angular.T)**2
        src=density@pol
        for i,rr in enumerate(rad):
            at=unit[i];left=r<at; right=~left
            phi=-vel**2*np.array([np.sum(w[left]*r[left]**2/at*(r[left]/at)**l*src[left,j])+
                    np.sum(w[right]*r[right]*(at/r[right])**l*src[right,j]) for j,l in enumerate(full)])
            angles=phi*grad[i]/(np.sqrt(1-mu[i]**2)*sphere[i])*UNIT
            direction=np.array([-1.5,0.,-rr])/sphere[i]*UNIT;idx=-4+i
            bary=direction@base[idx]
            expected=direction@wave[idx];assert abs(angles.sum()-expected)<2e-8
            factor=3*mu[i]*np.sqrt(1-mu[i]**2)*UNIT/sphere[i]
            north=bands()[rr,"atheta","north"];south=bands()[rr,"atheta","south"]
            lo=max(north[3],-south[4])-bary;hi=min(north[4],-south[3])-bary
            for j,l in enumerate(full):
                records.append(dict(tag=tag,R=rr,mode=l,phi_kms2=phi[j],a_theta=angles[j]))
            totals.append(dict(tag=tag,R=rr,stellar_plus_common=bary,wave_directional=expected,quadrupole=angles[1],
                             higher=angles[2:].sum(),required_lo=lo,required_hi=hi,
                             effective_phi_wave=expected/factor,effective_phi_low=lo/factor,effective_phi_high=hi/factor,
                             required_ratio_min=lo/expected,zero_allowed=lo<=0<=hi,wave_allowed=lo<=expected<=hi))
    prefix=f"{sys_tag}-{count}-{order}"
    table(prefix+"-angular-multipoles.csv",records);table(prefix+"-required-angular-source.csv",totals)


if __name__=="__main__":
    for args in (("main",256,24),("main",384,32),("above",384,32)):project(*args)

