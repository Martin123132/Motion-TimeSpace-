from live_dipole import HOME,np,Live,CONFIGS,guard
from independent_readout import write
import sympy as sp

def characteristic():
    rate,omega,self_gravity,density=sp.symbols("z omega b rho")
    harmonic=omega**2-self_gravity
    rotation=omega*sp.Matrix([[0,-1,-1,0],[1,0,0,-1],[1,0,0,-1],[0,1,1,0]])
    curvature=sp.diag(2*self_gravity-harmonic,2*self_gravity-density-harmonic,-omega**2,-omega**2)
    det=((rate*sp.eye(4)+rotation)**2-curvature).det(method="domain-ge")
    aa=4*self_gravity+density+10*harmonic
    bb=3*harmonic*(3*harmonic+density)
    assert sp.expand(det-(rate**2+omega**2)**2*(rate**4+aa*rate**2+bb))==0
    assert sp.expand(aa**2-4*bb-((4*self_gravity+density)**2+80*self_gravity*harmonic+8*density*harmonic+64*harmonic**2))==0

def control(label):
    count,number,edge,_,_,_,balanced=CONFIGS["balanced-core"]
    system=Live(label,count,number,edge,balanced)
    outer=system.core
    depth=system.ground(outer)[2]+system.material(np.array([outer]))[1][0]-system.eigen
    assert depth<0
    limit=system.ground(0.)[0]**2-system.ground(outer)[0]**2
    assert limit>0
    rr=np.linspace(0.,outer,301)[1:]
    amp,_,_,gradient=system.ground(rr)
    hessian=np.r_[amp**2-2*gradient/rr,gradient/rr]
    delta=np.max(abs(hessian-system.harmonic))
    assert delta<=limit
    with np.load(HOME/f"restart-{label}.npz") as pkt:
        data=pkt["state"]
    stresses=[]; bounds=[]
    for state in data:
        _,_,shape,_,_,_=system.parts(state[:system.dim])
        full=system.reconstruct(shape)
        rms=np.sqrt(np.einsum("n,snj,snj->",system.fraction,full,full)/3)
        force=-system.fraction@((system.hess_w[:,None]-system.harmonic)*full[0]+
                                (system.omega_w[:,None]-system.harmonic)*(full[3]+full[4]))/3
        stresses.append(np.linalg.norm(force))
        bounds.append(limit*rms)
    assert np.all(np.array(stresses)<=bounds)
    return dict(state=label,material_edge_potential_minus_energy=depth,central_wave_curvature=system.harmonic,
                proven_core_hessian_deviation_upper_code=limit,relative_bound=limit/system.harmonic,sampled_hessian_deviation_code=delta,
                peak_sampled_internal_acceleration=np.max(stresses),peak_sampled_force_bound=np.max(bounds),
                largest_force_over_own_epoch_bound=np.max(np.array(stresses[1:])/bounds[1:]),tested_epochs=len(data),
                harmonic_planar_determinant_identity=True)

if __name__=="__main__":
    guard()
    characteristic()
    write("cloud-limit.csv",[control(label) for label in ("central_cap","illustrative")])
