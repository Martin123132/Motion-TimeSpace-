from live_dipole import np,HOME,Live,orbit,CONFIGS,CubicSpline,integrate_channels,guard,TOL
from independent_readout import write

def run(label):
    cfg=CONFIGS["balanced-core"]
    count,number,edge,knots,angular,steps,balanced=cfg
    system=Live(label,count,number,edge,balanced)
    _,distance=orbit(1)
    axis=np.linspace(np.log(.99*min(distance)/system.length),np.log(1.01*max(distance)/system.length),knots)
    bank=np.stack([system.forcing(np.exp(point),angular) for point in axis])
    source=CubicSpline(axis,bank)
    history=integrate_channels(system,source,steps,True)
    dim=system.dim
    with np.load(HOME/f"balanced-core-{label}.npz") as prior:
        error=np.max(abs(history[:,dim-2]*system.length*1000-prior["relative_pc"]))/np.max(abs(prior["relative_pc"]))
        assert error<TOL
    rad=np.unique(np.r_[0.,system.radius,system.core,np.geomspace(system.core,.15,100),np.linspace(.15,edge,1600)])
    packet=dict(state=history,log_distance=axis,force=bank,core_radius=system.radius,cloud_shell_mass=system.bmass,
                roots=system.root,background_r=rad,background=system.ground(rad),eigen=system.eigen,
                wave_mass=system.mw,cloud_mass=system.mb,length_kpc=system.length,time_unit_Gyr=system.timeunit,
                mass_unit_Msun=system.massunit,time_Gyr=np.linspace(0.,5.,65),config=np.array(cfg))
    path=HOME/f"restart-{label}.npz"
    if path.exists():
        with np.load(path) as prior:
            assert all(np.array_equal(prior[key],value) for key,value in packet.items())
    else:
        with path.open("xb") as out:
            np.savez_compressed(out,**packet)
    with np.load(path) as saved:
        rep=integrate_channels(system,CubicSpline(saved["log_distance"],saved["force"]),steps,True,(steps//2,saved["state"][32]))
        assert np.array_equal(rep,saved["state"][32:])
    return dict(state=label,restart_at_Gyr=2.5,checkpoints_compared=len(rep),variables_per_axis=history.shape[1],axes=3,
                all_arrays_equal=True,position_difference_relative_to_original_peak=error)

if __name__=="__main__":
    guard()
    write("restart-receipts.csv",[run(label) for label in ("central_cap","illustrative")])
