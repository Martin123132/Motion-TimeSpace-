import hashlib
import csv
import json
import sys
from live_dipole import HOME,PRIOR,SEAL,CONFIGS,TOL,np,guard
from independent_readout import write

def digest(path):
    with path.open("rb") as reader:
        return hashlib.file_digest(reader,"sha256").hexdigest()

def rows(name):
    with (HOME/name).open(encoding="utf8",newline="") as reader:
        return list(csv.DictReader(reader))

def qualify():
    guard()
    assert digest(PRIOR/"seal.json")==SEAL
    for name,expected in json.loads((PRIOR/"seal.json").read_bytes())["files"].items():
        assert digest(PRIOR/name)==expected,name
    refinements=rows("refinements.csv")
    fine=rows("refined-independent-controls.csv")
    assert len(fine)==42 and all(row["passes"]=="True" for row in fine)
    assert len(refinements)==132
    for row in refinements:
        if row["first"] in ("time","source","core","wave","outer","wider","deep","balanced") and row["measure"] in ("wave_pc","com_pc","ordinary_pc","relative_pc","rigid_pc"):
            assert row["final_pass"]==row["history_pass"]=="True",row
    assert all(row["passes"]=="True" for row in rows("balance-history-checks.csv"))
    assert all(row["passes"]=="True" for row in rows("cartesian-orbits.csv") if float(row["force_scale"])<.001)
    output=[]
    centers=rows("centers.csv")
    for label in ("central_cap","illustrative"):
        for cfg in CONFIGS:
            with np.load(HOME/f"{cfg}-{label}.npz") as packet:
                assert packet["label"].item()==label and np.array_equal(packet["config"],CONFIGS[cfg])
                assert np.array_equal(packet["time_Gyr"],np.linspace(0.,5.,65))
                offset=packet["ordinary_pc"]-packet["wave_pc"]
                assert np.allclose(offset,packet["relative_pc"],atol=1e-11,rtol=0)
                assert not np.any(offset[0]) and np.isfinite(offset).all()
        with np.load(HOME/f"restart-{label}.npz") as packet:
            state=packet["state"]
            assert not np.any(state[0]) and state.shape==(65,924,3) and np.isfinite(state).all()
            assert int(packet["config"][-1])==1
            pull=(state[:,-6]+state[:,-4]+state[:,-2])*packet["length_kpc"]*1000
            relative=state[:,state.shape[1]-12]*packet["length_kpc"]*1000
            err=np.max(np.linalg.norm(relative-pull,axis=1))/np.max(np.linalg.norm(relative,axis=1))
            assert err<1e-10
        row=next(row for row in rows("motion-history.csv") if row["state"]==label and float(row["time_Gyr"])==5)
        vel=np.array([float(row[f"dv{col}_kms"]) for col in "xyz"])
        reference=next(row for row in rows("independent-velocities.csv") if row["state"]==label and int(row["steps"])==16384)
        other=np.array([float(reference[f"dv{col}_kms"]) for col in "xyz"])
        velocity_error=np.linalg.norm(vel-other)/np.linalg.norm(vel)
        assert velocity_error<TOL,velocity_error
        summary=next(row for row in centers if row["state"]==label)
        assert abs(np.linalg.norm(relative[-1])/float(summary["separation_pc"])-1)<1e-10
        output.append(dict(state=label,independent_velocity_relative_error=velocity_error,all_epochs_vector_budget_error=err,
                           center_resolution_gates=True,cold_cloud_kept_fixed=True))
    assert abs(float(centers[0]["cloud_msun"])/float(centers[1]["cloud_msun"])-1)<1e-12
    assert abs(float(centers[0]["radius_pc"])/float(centers[1]["radius_pc"])-1)<1e-12
    assert all(row["all_arrays_equal"]=="True" and int(row["checkpoints_compared"])==33 for row in rows("restart-receipts.csv"))
    write("qualified-centers.csv",output)
    return output

def main():
    qualified=qualify()
    names=("live_dipole","grid_wave","satellite","breathing","tide","orbit_source","bound_state","halo_mean","cap_test")
    imports=[__import__(name) for name in names[1:]]
    from pathlib import Path
    parents=[Path(mod.__file__).resolve() for mod in imports]
    parents.extend([PRIOR/"seal.json",PRIOR/"centre-theorem.csv",PRIOR/"RESULTS.md",PRIOR/"NEXT.md",
                    PRIOR.parent/"mts-freely-falling-tide-20261119"/"orphan_orbit.txt",
                    PRIOR.parent/"mts-supported-cycle-20261119"/"bound-isolated.npz"])
    files={path.name:digest(path) for path in sorted(HOME.iterdir()) if path.is_file() and path.name!="seal.json"}
    assert len(list(HOME.glob("restart-*.npz")))==2
    receipt=dict(scope="two live linear centers, conditional on saved positive occupations and external orbit",parent=SEAL,
                 parents={path.relative_to(HOME.parent).as_posix():digest(path) for path in parents},
                 files=files,rows={path.name:len(rows(path.name)) for path in HOME.glob("*.csv")},
                 control_tolerance=TOL,qualified=qualified)
    path=HOME/"seal.json"
    if sys.argv[1:]==["seal"]:
        with path.open("x",encoding="utf8") as out:
            json.dump(receipt,out,sort_keys=True,indent=2)
            out.write("\n")
    assert json.loads(path.read_bytes())==receipt
    print("seal",digest(path),"files",len(files),"rows",sum(receipt["rows"].values()),qualified)

if __name__=="__main__":
    main()
