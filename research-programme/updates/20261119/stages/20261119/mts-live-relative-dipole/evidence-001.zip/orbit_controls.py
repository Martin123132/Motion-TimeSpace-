from independent_readout import write
from live_dipole import np,Live,comm,HOME,TOL,guard
from scipy.integrate import solve_ivp
from scipy.linalg import eigvals

def direct(system,state):
    wave,phase,disp,speed,relative,velocity=system.parts(state)
    aa,bb,cc,dd,ee=disp
    omega=system.omega[:,None]
    density=system.rho[:,None]
    low=system.lower@(density*(aa+dd+ee))
    high=system.upper@(density*(dd+ee-2*aa))
    gradient=(2*low-high)/3-density*aa
    tan=-(low+high)/3
    radial=2*system.dr@wave
    tangent=2*system.dt@wave
    hrr=system.hess_w[:,None]
    htan=system.omega_w[:,None]
    internal=-system.fraction@(hrr*aa+htan*(dd+ee)+radial+2*tangent)/3
    bulk=internal-system.k_over_mb*relative
    force=-np.stack((system.hrr[:,None]*aa+gradient+radial+hrr*relative,system.hrr[:,None]*bb,
                     omega**2*cc,omega**2*dd+tan+tangent+htan*relative,omega**2*ee+tan+tangent+htan*relative))
    ddisp=system.center(speed-comm(disp,omega))
    dspeed=system.center(force-comm(speed,omega))
    response=system.dr.T@(system.bmass[:,None]*aa)+system.dt.T@(system.bmass[:,None]*(dd+ee))+system.cross[:,None]*relative
    return np.vstack((system.px@(system.ham@phase),system.pv@(-(system.ham+system.grav)@wave-response),
                      ddisp.reshape(5*system.number,-1),dspeed.reshape(5*system.number,-1),velocity,(1+system.mb/system.mw)*bulk))

def unstable():
    rows=[]
    for number in (8,12,20,36):
        raw=Live("illustrative",36,number,30.)
        repaired=Live("illustrative",36,number,30.,True)
        matrix=direct(raw,np.eye(raw.dim))
        old=max(eigvals(matrix).real)
        rows.append(dict(core_nodes=number,direct_max_real_eigen=old,
                         enclosed_max_real_eigen=max(eigvals(raw.matrix).real),
                         harmonic_balanced_max_real_eigen=max(eigvals(repaired.matrix).real)))
        if number==12:
            with np.load(HOME/"trial-illustrative.npz") as failed:
                assert abs(old-failed["max_real_eigen"])<1e-9
    write("discretization-growth.csv",rows)

def orbit_check(system,fraction):
    radius=fraction*system.core
    gradient,_,density=system.material(np.array([radius]))
    amp,_,_,gw=system.ground(radius)
    omega=np.sqrt((gradient[0]+gw)/radius)
    hrr=amp**2+density[0]-2*omega**2
    duration=1.25*2*np.pi/omega
    moment=np.linspace(0,duration,97)
    normal=np.array([1.,2.,3.])/np.sqrt(14)
    tangent=np.cross([0.,0.,1.],normal)
    tangent/=np.linalg.norm(tangent)
    axis=np.cross(normal,tangent)
    probe=np.array([2.,1.,-1.])/np.sqrt(6)
    def pulse(time):
        return np.sin(np.pi*time/duration)**2*(1+.35*np.cos(3*omega*time))
    def force(time,state):
        shape,vel=state.reshape(2,5,1)
        radial=3*omega**2*radius*pulse(time)
        side=radial/3
        val=-np.array([hrr,hrr,omega**2,omega**2,omega**2])[:,None]*shape
        val-=np.array([radial,0.,0.,side,side])[:,None]
        return np.stack((vel-comm(shape,omega),val-comm(vel,omega))).ravel()
    def solve(fun,initial):
        solution=solve_ivp(fun,(0.,duration),initial,t_eval=moment,method="DOP853",rtol=5e-13,atol=5e-15*radius)
        assert solution.success
        return solution.y
    linear=solve(force,np.zeros(10))
    def vectors(coeff):
        theta=moment*omega
        nvec=normal[:,None]*np.cos(theta)+tangent[:,None]*np.sin(theta)
        tvec=tangent[:,None]*np.cos(theta)-normal[:,None]*np.sin(theta)
        return nvec*(coeff[0]*(probe@nvec)+coeff[1]*(probe@tvec))+tvec*(coeff[2]*(probe@nvec)+coeff[3]*(probe@tvec))+axis[:,None]*(coeff[4]*(axis@probe))
    expected=np.vstack((vectors(linear[:5]),vectors(linear[5:])/omega))
    rows=[]
    for contrast in (.001,.00025,.0000625):
        pair=[]
        for sign in (-1,1):
            def cart(time,state):
                pos=state[:3]
                rad=np.linalg.norm(pos)
                gravity=system.material(np.array([rad]))[0][0]+system.ground(rad)[3]
                applied=omega**2/radius*(probe*rad**2+2*(probe@pos)*pos)
                return np.r_[state[3:],-gravity*pos/rad-sign*contrast*pulse(time)*applied]
            pair.append(solve(cart,np.r_[normal*radius,tangent*radius*omega]))
        measured=(pair[1]-pair[0])/(2*contrast)
        measured[3:]/=omega
        error=np.linalg.norm(measured-expected)/np.linalg.norm(expected)
        rows.append(dict(state=system.label,r_over_core=fraction,force_scale=contrast,phase_space_error=error,passes=error<TOL))
    return rows

if __name__=="__main__":
    guard()
    unstable()
    rows=[]
    for tag in ("central_cap","illustrative"):
        system=Live(tag,40,18,30.,True)
        for fraction in (.35,.85):
            rows.extend(orbit_check(system,fraction))
    write("cartesian-orbits.csv",rows)
    print(rows)
