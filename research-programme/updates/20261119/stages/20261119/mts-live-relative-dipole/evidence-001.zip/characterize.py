from independent_readout import write,shell_controls,precise_final
from live_dipole import np,HOME,PRIOR,Live,CONFIGS,CubicSpline,integrate_channels,orbit,TOL,guard
from scipy.linalg import eigvals
from satellite import KMS,unit_scales
from cap_test import RADIUS_KPC
from breathing import SCALE,background
import csv
import sys

LABELS=("central_cap","illustrative")

def size(values):
    return float(np.linalg.norm(values))

def validate():
    rows=[]
    totals=[]
    velocities=[]
    for label in LABELS:
        system=Live(label,160,46,40.,True)
        shell_controls(system,rows)
        totals.append(precise_final(system,rows,"deep",velocities))
    write("refined-independent-controls.csv",rows)
    write("refined-inertial-readout.csv",totals)
    write("independent-velocities.csv",velocities)
    print("Independent refined comparisons",[(r["state"],r["check"],r["error"]) for r in rows if not r["passes"]])

def channels():
    contributions=[]
    checks=[]
    motion=[]
    normalization=[]
    for label in LABELS:
        count,number,edge,knots,angular,steps,balanced=CONFIGS["balanced"]
        system=Live(label,count,number,edge,balanced)
        _,dists=orbit(1)
        logs=np.linspace(np.log(.99*min(dists)/system.length),np.log(1.01*max(dists)/system.length),knots)
        source=CubicSpline(logs,np.stack([system.forcing(np.exp(lp),angular) for lp in logs]))
        states=integrate_channels(system,source,steps,True)*system.length*1000
        dim=system.dim
        total=states[:,dim-2]
        pieces={"external differential force":states[:,dim+4],"wave polarization":states[:,dim+6],"cloud internal shape":states[:,dim+8]}
        time=np.linspace(0.,5.,len(total))
        orbit_pos=orbit(1)[0](time)
        for index,epoch in enumerate(time):
            relative=total[index]
            velocity=states[index,dim-1]/(system.timeunit*1000*KMS)
            cloud_v=(states[index,dim+1]/(system.timeunit*1000*KMS)+system.mw/(system.mb+system.mw)*velocity)
            along=orbit_pos[index]/size(orbit_pos[index])
            motion.append(dict(state=label,time_Gyr=epoch,dx_pc=relative[0],dy_pc=relative[1],dz_pc=relative[2],
                               dvx_kms=velocity[0],dvy_kms=velocity[1],dvz_kms=velocity[2],
                               relative_speed_kms=size(velocity),ordinary_speed_in_frame_kms=size(cloud_v),
                               separation_along_satellite_pc=along@relative,relative_speed_along_satellite_kms=along@velocity))
        isolated=background(False,edge)[0]
        rad=RADIUS_KPC/system.length
        fixed=6/(SCALE*(system.length/unit_scales("illustrative")[0]))
        original_mass=rad**2*isolated(rad)[3]
        loaded_mass=rad**2*system.ground(rad)[3]
        normalization.append(dict(state=label,anchor_kpc=RADIUS_KPC,fixed_cloud_Msun=system.mb*system.massunit,
                                  anchor_isolated_msun=original_mass*system.massunit,anchor_loaded_wave_msun=loaded_mass*system.massunit,
                                  relative_circular_speed_shift_including_cloud=np.sqrt((loaded_mass+system.mb)/original_mass)-1,
                                  fixed_source_probe_density_loaded_over_isolated=(system.ground(fixed)[0]/isolated(fixed)[0])**2))
        for name,array in pieces.items():
            contributions.append(dict(state=label,term=name,x_pc=array[-1,0],y_pc=array[-1,1],z_pc=array[-1,2],norm_pc=size(array[-1]),
                                      signed_fraction=array[-1]@total[-1]/(total[-1]@total[-1])))
        peak=np.max(np.linalg.norm(total,axis=1))
        err=np.max(np.linalg.norm(sum(pieces.values())-total,axis=1))/peak
        with np.load(HOME/f"balanced-{label}.npz") as packet:
            replay=np.max(np.linalg.norm(total-packet["relative_pc"],axis=1))/peak
        checks.append(dict(state=label,all_times_budget_error=err,augmented_replay=replay,passes=(max(err,replay)<TOL)))
    write("physical-contributions.csv",contributions)
    write("balance-history-checks.csv",checks)
    write("motion-history.csv",motion)
    write("normalizations.csv",normalization)

def results():
    refs=list(csv.DictReader((PRIOR/"centre-theorem.csv").open(encoding="utf8")))
    rows=[];summary=[]
    for label in LABELS:
        target="balanced-core"
        with np.load(HOME/f"{target}-{label}.npz") as data:
            rel=data["relative_pc"][-1]
            src=next(row for row in refs if row["scale"]==label and row["source"]=="extended" and row["check_grid"]=="radial")
            isolated=np.array([float(src[col+"_kpc"])*1000 for col in "XYZ"])
            summary.append(dict(state=label,sense="ordinary minus wave",x_pc=rel[0],y_pc=rel[1],z_pc=rel[2],
                                separation_pc=size(rel),ordinary_pc=size(data["ordinary_pc"][-1]),wave_pc=size(data["wave_pc"][-1]),
                                rigid_pc=size(data["rigid_pc"][-1]),previous_isolated_pc=size(isolated),
                                rigid_fractional_vector_error=size(data["rigid_pc"][-1]-rel)/size(rel),
                                ratio_to_isolated=size(rel)/size(isolated),cloud_internal_rms_pc=data["ordinary_internal_rms_pc"][-1],
                                rigid_period_Gyr=2*np.pi/data["omega_rigid_Gyr"],radius_pc=float(data["cloud_radius_pc"]),
                                cloud_msun=float(data["cloud_mass_Msun"]),wave_msun=float(data["wave_mass_Msun"]),
                                max_discrete_growth_code=float(data["max_real_eigen"]),dimensionless_density_at_source_probe=float(data["wave_density_reference"])))
        pairs=[("enclosed-trial","base"),("base","fine"),("time","fine"),("source","fine"),("core","fine"),("wave","fine"),
               ("fine","outer"),("outer","deep"),("wider","deep"),("deep","balanced"),("balanced","balanced-core")]
        for first,last in pairs:
            with np.load(HOME/f"{first}-{label}.npz") as one,np.load(HOME/f"{last}-{label}.npz") as two:
                for key in ("relative_pc","wave_pc","ordinary_pc","com_pc","rigid_pc","ordinary_internal_rms_pc"):
                    vals=two[key]
                    diff=one[key]-vals
                    peak=max(np.linalg.norm(np.atleast_1d(val)) for val in vals)
                    err=size(diff[-1])/size(vals[-1])
                    hist=max(np.linalg.norm(np.atleast_1d(val)) for val in diff)/peak
                    rows.append(dict(state=label,first=first,second=last,measure=key,final_error=err,history_error_over_peak=hist,
                                     final_pass=err<TOL,history_pass=hist<TOL))
    write("centers.csv",summary)
    write("refinements.csv",rows)
    print(summary)

if __name__=="__main__":
    guard()
    {"independent":validate,"channels":channels,"summary":results}[sys.argv[1]]()
