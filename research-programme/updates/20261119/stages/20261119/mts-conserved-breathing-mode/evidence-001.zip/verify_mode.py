import sys
import json
from pathlib import Path
from breathing import HERE, PRE, CLOCK, PRIOR, BRANCHES, TOL, bridge, np, table, hold, experiment
from mode_forecast import freeze, EPS
from cap_test import OUTER, OUTER_HASH, forecast, compare
from accuracy import wave_checks, energy_checks, inventory
from excitation import forecasts

def verify():
    hold()
    parents = {PRE:PRIOR,CLOCK:"730dfa7dc7d9e8663b6387d798e493097d37cd220d0b651c20d539bbfdef8da3",
               OUTER:OUTER_HASH, HERE.parent/"mts-supported-cycle-20261119":"8570356c50d83a1e47e9475792d0c9a4d5972cedbd4ecff9bf7cb6518ed8311a"}
    for folder,digest in parents.items():
        assert bridge.sha(folder/"seal.json")==digest
        recorded=json.loads((folder/"seal.json").read_bytes())
        assert all(bridge.sha(folder/name)==value for name,value in recorded["files"].items())
    counts = {}
    for branch in BRANCHES:
        rows=experiment(branch,False)
        assert len(rows)==3 and all(row["passes"] and row["omega_scaled"]<row["threshold"] for row in rows)
        counts["checks-"+branch+".csv"]=len(rows)
    local,other=freeze(False)
    assert len(local)==30 and len(other)==8
    assert all(row["versus_collocation"]<TOL for row in other if row["scheme"]=="second_order_extrapolation")
    assert all(abs(row["mode_current_scaled"]-row["predicted_mode_current_scaled"]) < TOL*abs(row["predicted_mode_current_scaled"])
               for row in local if row["location"]=="core_pc")
    counts.update({"local-source.csv":len(local),"independent-frequency.csv":len(other),"cap-forecast.csv":len(forecast(False))})
    for name,fn,count in (("cap-evolution",compare,240),("wave-accuracy",wave_checks,66),("coupled-energy",energy_checks,6),
                          ("outer-inventory-response",inventory,8),("formation-probe-forecast",forecasts,3)):
        rows=table(name+".csv",fn(),False)
        assert len(rows)==count,name
        counts[name+".csv"]=count
        if name=="cap-evolution":
            assert all(row["linear_response_pass"] for row in rows)
            assert any(row["positive_arm_linear_error"]>TOL for row in rows)
        if name=="wave-accuracy":
            assert all(row["meets_tolerance"] for row in rows if row["required_for_linear_result"])
            assert len([row for row in rows if not row["meets_tolerance"]])==12
        if name=="coupled-energy":
            assert all(row["passes"] for row in rows)
        if name=="formation-probe-forecast":
            assert [row["exact_null"] for row in rows]==[False,False,True]
            assert rows[1]["free_amplitude"]>rows[0]["free_amplitude"]>rows[2]["free_amplitude"]==0.
    nonlinear_digests={"space512":"6a7f498bb0d1f210e5bb4075988f85d5c476281da9ddc3aa41120dfa83250b2d",
                       "space1024":"978f345c9094f527c6416956a6fbffe29a777f8ecf1880295abab6e966abccc8",
                       "time8192":"ce1bc8123e1e544d950091bb5d500e28680fa20ccc95ce163384ca7ade9bdc45"}
    for tag,digest in nonlinear_digests.items():
        path=HERE/f"nonlinear-{tag}.npz"
        assert bridge.sha(path)==digest
        packet=bridge.read(path)
        assert packet["receipt"].item().decode()==bridge.sha(HERE/"forecast.json")
        assert packet["quarter_phase_counts"].shape[:2]==(5,5)
        assert np.all(np.diff(packet["quarter_phase_counts"],axis=2)>=0.)
    assert set(counts)=={path.name for path in HERE.glob("*.csv")}
    assert all(path.is_file() and path.suffix not in (".partial",".tmp",".pyc") for path in HERE.iterdir())
    deps={}
    for module in tuple(sys.modules.values()):
        path=getattr(module,"__file__",None)
        if not path:
            continue
        path=Path(path).resolve()
        if path.suffix==".py" and path.is_relative_to(HERE.parent) and not path.is_relative_to(HERE):
            deps[path.relative_to(HERE.parent).as_posix()]=bridge.sha(path)
    return dict(parents={folder.name:value for folder,value in parents.items()},inputs=deps,rows=counts,
                files={path.name:bridge.sha(path) for path in sorted(HERE.iterdir()) if path.name!="seal.json"})

if __name__=="__main__":
    report=verify()
    dest=HERE/"seal.json"
    if sys.argv[1:]==["seal"]:
        with dest.open("x",encoding="utf8") as stream:
            json.dump(report,stream,indent=2,sort_keys=True)
    assert json.loads(dest.read_bytes())==report
    print("VERIFIED",len(report["files"]),sum(report["rows"].values()),len(report["inputs"]),bridge.sha(dest))

