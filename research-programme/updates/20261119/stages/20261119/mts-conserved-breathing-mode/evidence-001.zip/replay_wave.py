import shutil
import sys
from tempfile import TemporaryDirectory
from pathlib import Path
import nonlinear
from breathing import HERE, bridge, hold, np

def replay(tag):
    hold()
    with TemporaryDirectory(prefix=".mts-mode-replay-", dir=HERE.parent) as name:
        temp = Path(name).resolve()
        assert temp.parent == HERE.parent.resolve() and temp.name.startswith(".mts-mode-replay-")
        shutil.copyfile(HERE/"forecast.json",temp/"forecast.json")
        original = nonlinear.HERE
        try:
            nonlinear.HERE = temp
            nonlinear.evolve(tag)
        finally:
            nonlinear.HERE = original
        filename = f"nonlinear-{tag}.npz"
        repeat = bridge.read(temp/filename)
        saved = bridge.read(HERE/filename)
        assert set(repeat)==set(saved) and all(np.array_equal(repeat[key],value) for key,value in saved.items())
        assert bridge.sha(temp/filename)==bridge.sha(HERE/filename)
    assert not temp.exists()
    print("REPLAY VERIFIED",tag,bridge.sha(HERE/filename),flush=True)

if __name__=="__main__":
    for label in sys.argv[1:]:
        if label not in nonlinear.CASES:
            raise ValueError(label)
        replay(label)

