import sys
import json
from breathing import HERE,PRE,CLOCK,BRANCHES,TOL,SEC,SCALE,LENGTH,KG,MSUN,YEAR,bridge,np,table,solve,static,background,hold,PPoly
from scipy.constants import parsec,c
from scipy.optimize import brentq

EPS=.001


def mode(branch):
    data=bridge.read(HERE/f"mode-{branch}.npz")
    profile=PPoly(data["coeff"],data["x"],extrapolate=False)
    return lambda points: profile(points).T,float(data["omega"])


def radial():
    labels=[("core_pc",rad*LENGTH/parsec) for rad in (.75,2.,3.,4.,4.75)]
    labels += [("halo_kpc",rad) for rad in (8.275,17.58,24.64,50.,100.)]
    for branch in BRANCHES:
        sol,freq=mode(branch)
        for label,value in labels:
            rad=value*(1000 if label=="halo_kpc" else 1)*parsec/(SCALE*LENGTH)
            point=np.array([rad])
            core,_,bd,kn=static(branch,30.,point)
            pform,_,qform,qprime,pot,force=sol(point)
            amp,slope,_,grad=background(branch!="isolated",30.)[0](point)
            disp=-force/(kn-freq**2) if branch=="live" and bd[0]>0 else np.zeros(1)
            mass=rad**2*grad
            own=rad**2*force
            dust=-rad**2*bd*disp
            current=qform*slope-amp*qprime
            def scalar(val):
                return float(val[0])
            yield dict(branch=branch,location=label,coordinate=value,mode_cosine_peak="overdensity_at_origin",
                       displayed_field_amplitude=EPS,fractional_local_density=scalar(2*EPS*pform/core),
                       wave_delta_mass_msun=scalar(EPS*own*KG/(SCALE*MSUN)),wave_fraction_inside=scalar(EPS*own/mass),
                       baryon_delta_mass_msun=scalar(EPS*dust*KG/(SCALE*MSUN)),
                       material_shift_pc=scalar(EPS*disp*SCALE*LENGTH/parsec) if branch=="live" and bd[0]>0 else "",
                       total_radial_accel_inward_m_s2=scalar(EPS*(force-bd*disp)*c**2/(SCALE**3*LENGTH)),
                       mode_current_scaled=scalar(current),predicted_mode_current_scaled=scalar(freq*force),
                       pressure_upper_sideband_fraction=scalar(EPS*(pform+qform)/core),
                       pressure_lower_sideband_fraction=scalar(EPS*(pform-qform)/core))


def frequency_bench():
    from breathing import spectrum
    for branch in ("isolated","rigid"):
        saved=mode(branch)[1]
        values=[]
        for count in (400,800,1600):
            axis,pform,qform,bands,zero=spectrum(branch,30.,count,130)
            values.append(bands[0])
            yield dict(branch=branch,scheme="radial_spectral_grid",intervals=count,omega=bands[0],
                       numerical_phase_zero=zero,second_monopole=bands[1],third_monopole=bands[2],
                       versus_collocation=abs(bands[0]/saved-1))
        rich=(4*values[-1]-values[-2])/3
        yield dict(branch=branch,scheme="second_order_extrapolation",intervals=1600,omega=rich,numerical_phase_zero="",
                   second_monopole="",third_monopole="",versus_collocation=abs(rich/saved-1))


def freeze(create):
    hold()
    radial_rows=table("local-source.csv",radial(),create)
    bench=table("independent-frequency.csv",frequency_bench(),create)
    paths=[HERE/name for name in ("PROTOCOL.md","breathing.py","mode_forecast.py","nonlinear.py","local-source.csv","independent-frequency.csv")]
    paths += [HERE/f"mode-{branch}.npz" for branch in BRANCHES]
    paths += [HERE/f"checks-{branch}.csv" for branch in BRANCHES]
    paths += [PRE/"seal.json"]
    records={str(path.relative_to(HERE.parent)).replace(chr(92),"/"):bridge.sha(path) for path in paths}
    dest=HERE/"forecast.json"
    if create:
        with dest.open("x",encoding="utf8") as out:
            json.dump(records,out,sort_keys=True,indent=2)
    assert json.loads(dest.read_bytes())==records
    return radial_rows,bench


if __name__=="__main__":
    rows,bench=freeze(sys.argv[1:]==["freeze"])
    print(bench)
