import sys
import json
from breathing import HERE,bridge,hold,np,background,TOL
from mode_forecast import mode,EPS
from scipy.fft import dst,idst
from scipy.optimize import brentq
from scipy.interpolate import make_interp_spline

CASES={"space512":(512,4096),"space1024":(1024,4096),"time8192":(1024,8192)}


def evolve(tag):
    hold()
    receipt=HERE/"forecast.json"
    assert all(bridge.sha(HERE.parent/name)==digest for name,digest in json.loads(receipt.read_bytes()).items())
    target=HERE/("nonlinear-"+tag+".npz")
    if target.exists() or target.with_suffix(".partial").exists():
        raise FileExistsError(target)
    num,steps=CASES[tag]
    extent=30.
    dx=extent/num
    axis=dx*np.arange(1,num)
    wave,_,_=background(False,extent)
    amp,prime,_,_=wave(axis)
    solved,omega=mode("isolated")
    pform,_,qform,qprime,_,force=solved(axis)
    scalar=axis*amp
    number=np.dot(scalar,scalar)*dx
    arms=np.array([0.,EPS,-EPS,EPS/2,-EPS/2])
    chi=(scalar+arms[:,None]*axis*pform).astype(complex)
    start=np.sum(abs(chi)**2,axis=1)*dx
    chi*=np.sqrt(number/start)[:,None]
    kgrid=np.pi*np.arange(1,num)/extent
    dt=(2*np.pi/omega)/steps
    phase=np.exp(-.5j*dt*kgrid**2)
    template=2*axis**2*amp*pform
    current=axis**2*(qform*prime-amp*qprime)
    current_norm=np.sum(abs(current))*dx
    template_norm=np.sum(abs(template))*dx
    assert np.sum(abs(current-omega*axis**2*force))*dx/current_norm<TOL
    def potential(density):
        source=density/axis
        coeff=dst(source,type=1,axis=-1,norm="ortho",workers=1)
        result=idst(-coeff/kgrid**2,type=1,axis=-1,norm="ortho",workers=1)/axis
        return result-(density.sum(axis=1)*dx/extent)[:,None]
    def derivative(values):
        full=np.pad(values,((0,0),(1,1)))
        block=np.concatenate((-full[:,1:4][:,::-1],full,-full[:,-4:-1][:,::-1]),axis=1)
        fine=(-block[:,:-6]+9*block[:,1:-5]-45*block[:,2:-4]+45*block[:,4:-2]-9*block[:,5:-1]+block[:,6:])/(60*dx)
        return fine[:,1:-1]
    density=abs(chi)**2
    pot=potential(density)
    rows=[]
    radial=[]
    timebank=[]
    for idx in range(steps*9//8+1):
        if idx%(steps//128)==0:
            time=idx*dt
            if idx%(steps//8)==0:
                hold()
            flux=np.imag(np.conj(chi)*derivative(chi))
            out=[]
            for high,low in ((1,2),(3,4)):
                size=arms[high]
                dd=(density[high]-density[low])/(2*size)
                jj=(flux[high]-flux[low])/(2*size)
                single_over=(density[high]-density[0])/size
                single_under=(density[low]-density[0])/(-size)
                projected=np.dot(template,dd)/np.dot(template,template)
                jf=np.dot(current,jj)/np.dot(current,current)
                ref=template*np.cos(omega*time)
                jref=current*np.sin(omega*time)
                l1=lambda val:np.sum(abs(val))*dx
                out.append([projected,jf,l1(dd-ref)/template_norm,l1(jj-jref)/current_norm,
                            l1(single_over-ref)/template_norm,l1(single_under-ref)/template_norm,
                            np.max(abs(density.sum(axis=1)*dx/number-1)),l1(density[0]-scalar**2)/number,
                            l1(dd)/template_norm])
            rows.append(out)
            radial.append([np.cumsum(density[j])*dx for j in range(5)] if idx%(steps//4)==0 else [])
            timebank.append(time)
        if idx==steps*9//8:
            break
        chi*=np.exp(-.5j*dt*pot)
        chi=idst(dst(chi,type=1,axis=-1,norm="ortho",workers=1)*phase,type=1,axis=-1,norm="ortho",workers=1)
        density=abs(chi)**2
        pot=potential(density)
        chi*=np.exp(-.5j*dt*pot)
    times=np.array(timebank)
    result=np.array(rows)
    frequencies=[]
    for side in range(2):
        signal=result[:,side,0]
        spline=make_interp_spline(times,signal,k=5)
        flips=np.flatnonzero(signal[:-1]*signal[1:]<0)
        assert len(flips)==2
        roots=[brentq(spline,times[cut],times[cut+1]) for cut in flips]
        frequencies.append(np.pi/(roots[1]-roots[0]))
    bank=np.array([row for row in radial if len(row)])
    assert np.isfinite(result).all() and np.isfinite(bank).all()
    bridge.archive(target,t=times,metrics=result,omega_measured=np.array(frequencies),radial=axis,
                   quarter_phase_counts=bank,radial_phase_cycles=np.arange(len(bank))*.25,
                   receipt=np.bytes_(bridge.sha(receipt)))
    print(tag,frequencies,result.max(axis=0),flush=True)


if __name__=="__main__":
    evolve(sys.argv[1])
