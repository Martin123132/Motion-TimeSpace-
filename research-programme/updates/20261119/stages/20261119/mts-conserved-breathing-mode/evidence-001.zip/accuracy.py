import sys
from breathing import (HERE, BRANCHES, TOL, SCALE, background, static, table, bridge,
                       hold, np, simpson, cumulative_simpson, make_interp_spline)
from mode_forecast import mode, EPS
from cap_test import TAGS, forecast, read_rows, PRE


def wave_checks():
    omega = mode("isolated")[1]
    packets = [bridge.read(HERE/f"nonlinear-{tag}.npz") for tag in ("space512","space1024","time8192")]
    assert all(np.array_equal(packet["t"], packets[0]["t"]) for packet in packets)
    for tag, packet in zip(("space512","space1024","time8192"),packets):
        assert packet["receipt"].item().decode() == bridge.sha(HERE/"forecast.json")
        times = packet["t"]
        for side, amplitude in enumerate((EPS,EPS/2)):
            values = packet["metrics"][:,side]
            assert values.shape == (145,9)
            for name, err, linear in (
                    ("frequency_from_free_crossings", abs(packet["omega_measured"][side]/omega-1),True),
                    ("density_mode_projection",max(abs(values[:,0]-np.cos(omega*times))),True),
                    ("current_mode_projection",max(abs(values[:,1]-np.sin(omega*times))),True),
                    ("paired_radial_density_L1",max(values[:,2]),True),
                    ("paired_radial_current_L1",max(values[:,3]),True),
                    ("positive_only_density_L1",max(values[:,4]),False),
                    ("negative_only_density_L1",max(values[:,5]),False),
                    ("number_drift",max(values[:,6]),True),
                    ("unexcited_density_drift_L1",max(values[:,7]),True)):
                yield dict(grid=tag,amplitude=amplitude,test=name,error=err,tolerance=TOL,
                           meets_tolerance=err<TOL,required_for_linear_result=linear)
    for side,amplitude in enumerate((EPS,EPS/2)):
        for index,label,component in ((0,"density",2),(1,"current",3)):
            values = [packet["metrics"][:,side,index] for packet in packets]
            space = max(abs(values[1]-values[0]))
            time = max(abs(values[2]-values[1]))
            fine = max(packets[2]["metrics"][:,side,component])
            for name,err in (("space_refinement",space),("time_refinement",time),("empirical_budget",space+time+fine)):
                yield dict(grid="all",amplitude=amplitude,test=f"{label}_{name}",error=err,
                           tolerance=TOL,meets_tolerance=err<TOL,required_for_linear_result=True)


def energy_checks():
    for branch in BRANCHES:
        for resolution in (1,2):
            support = 5/SCALE
            axis = np.unique(np.r_[np.linspace(0.,support,200*resolution+1),np.geomspace(support,.15,240),
                                   np.linspace(.15,30.,4500*resolution+1)])
            core, centr, ordinary, effective = static(branch,30.,axis)
            pair, omega = mode(branch)
            pf, pg, qf, qg, potential, waveforce = pair(axis)
            active = ordinary>0.
            displacement = np.zeros_like(axis)
            if branch=="live":
                displacement[active] = -waveforce[active]/(effective[active]-omega**2)
            total_force = waveforce-ordinary*displacement
            field_integral = lambda val: simpson(axis**2*val,x=axis)
            def hamiltonian(field,gradient):
                return field_integral(.5*gradient**2+centr*field**2)
            gravity = -.5*(field_integral(total_force**2)-axis[-1]**2*potential[-1]*total_force[-1])
            full_kappa = effective+ordinary
            matter_potential = .5*field_integral(ordinary*full_kappa*displacement**2)
            matter_kinetic = .5*omega**2*field_integral(ordinary*displacement**2)
            turning = hamiltonian(pf,pg)+gravity+matter_potential
            crossing = hamiltonian(qf,qg)+matter_kinetic
            shell_error = 0.
            core_force_error = 0.
            if branch=="live":
                mask = axis<=support
                radius = axis[mask]
                flux = radius**2*(ordinary*displacement)[mask]
                density_times_area = -make_interp_spline(radius,flux,k=5).derivative()(radius)
                measured_ordinary = cumulative_simpson(density_times_area,x=radius,initial=0.)
                wave_mass = cumulative_simpson(2*core[mask]*pf[mask]*radius**2,x=radius,initial=0.)
                force_independent = (measured_ordinary[1:]+wave_mass[1:])/radius[1:]**2
                restoring = (full_kappa[mask][1:]-omega**2)*displacement[mask][1:]
                core_force_error = max(abs((restoring+force_independent)[ordinary[mask][1:]>0]))/max(abs(force_independent))
                exchange = .5*simpson(flux[1:]*force_independent,x=radius[1:])
                shell_error = abs(matter_potential-matter_kinetic+exchange)/abs(exchange)
            yield dict(branch=branch,resolution=resolution,turning_energy=turning,crossing_energy=crossing,
                       selfgravity_turning=gravity,ordinary_potential= matter_potential,ordinary_kinetic=matter_kinetic,
                       energy_error=abs(turning/crossing-1),live_source_momentum_error=core_force_error if branch=="live" else "",
                       live_work_error=shell_error if branch=="live" else "",
                       passes=max(abs(turning/crossing-1),core_force_error,shell_error)<TOL and min(turning,crossing)>0)


def inventory():
    frozen = forecast(False)
    rows = read_rows(HERE/"cap-evolution.csv")
    ordinary = read_rows(PRE/"ordinary-apertures.csv")
    for tag in TAGS:
        def select(row):
            return row["grid"]=="time8192" and row["radius_kpc"]=="100.0" and row["cap"]==tag and float(row["amplitude"])==EPS
        kept = list(filter(select, rows))
        assert len(kept)==5
        finite_gain = max(float(row[arm]) for row in kept for arm in ("positive_minus_control_msun","negative_minus_control_msun"))
        peak = abs(next(row["peak_change_at_test_amplitude_msun"] for row in frozen if row["radius_kpc"]==100. and row["cap"]==tag))
        for row in ordinary:
            if row["inner_speed"]!=tag or float(row["rad_kpc"])!=100. or row["ordinary_scenario"]!="generous":
                continue
            gap = float(row["deficit_on_tracer_central_msun"])
            yield dict(cap=tag,tracer=row["tracer"],wave_amplitude=EPS,listed_ordinary_msun=row["accounted_ordinary_msun"],
                       original_central_deficit_msun=gap,linear_peak_gain_msun=peak,
                       largest_sampled_finite_gain_relative_to_matched_control_msun=finite_gain,
                       remaining_central_deficit_at_linear_peak_msun=max(0.,gap-peak),
                       fraction_of_original_central_deficit_covered=peak/gap if gap else "")


def run(create):
    hold()
    for name, generator in (("wave-accuracy.csv",wave_checks),("coupled-energy.csv",energy_checks),("outer-inventory-response.csv",inventory)):
        rows = table(name,generator(),create)
        print(name,len(rows),[row for row in rows if row.get("passes")==False],flush=True)


if __name__ == "__main__":
    run(sys.argv[1:]==["create"])

