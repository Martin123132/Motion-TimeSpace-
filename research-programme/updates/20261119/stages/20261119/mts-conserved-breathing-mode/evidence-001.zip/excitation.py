import sys
from scipy.integrate import quad, solve_ivp
from scipy.special import betainc, beta
from breathing import HERE, np, table, hold, background, TOL, KG, SCALE, MSUN
from mode_forecast import mode

def shell(rad,left,right):
    edge=np.clip((rad-left)/(right-left),0.,1.)
    return betainc(3,3,edge),edge**2*(1-edge)**2/(beta(3,3)*(right-left))

def forecasts():
    hold()
    wave=background(False,30.)[0]
    fields,omega=mode("isolated")
    breaks=(0.,.5,1.5,2.,4.,30.)
    def integrate(func):
        return sum(quad(func,left,right,epsabs=3e-12,epsrel=3e-10)[0] for left,right in zip(breaks[:-1],breaks[1:]))
    inner_product=integrate(lambda rad:rad**2*fields(rad)[0]*fields(rad)[2])
    assert inner_product>0.
    total=30**2*wave(30.)[3]
    moved=1e-4*total
    scale_mass=KG/(SCALE*MSUN)
    def mass_shape(rad):
        return shell(rad,.5,1.5)[0]-shell(rad,2.,4.)[0]
    def potential(rad):
        outside=sum(quad(lambda point:shell(point,left,right)[1]/point,max(rad,left),right,epsabs=2e-13)[0]*sign
                    for left,right,sign in ((.5,1.5,1.),(2.,4.,-1.)) if rad<right)
        return -moved*((mass_shape(rad)/rad if rad else 0.)+outside)
    overlap=integrate(lambda rad:rad**2*wave(rad)[0]*fields(rad)[0]*potential(rad))
    force_overlap=-.5*moved*integrate(lambda rad:fields(rad)[5]*mass_shape(rad))
    assert abs(overlap/force_overlap-1)<TOL
    drive=-omega*overlap/inner_product
    for periods in (.5,1.,2.):
        duration=periods*2*np.pi/omega
        def harmonic(harm):
            return duration*np.sinc(harm*duration/(2*np.pi))*np.exp(-.5j*harm*duration)
        transform=.5*harmonic(omega)-.25*(harmonic(omega-2*np.pi/duration)+harmonic(omega+2*np.pi/duration))
        outgoing=drive*np.exp(1j*omega*duration)*transform/omega
        traj=solve_ivp(lambda moment,state:(state[1],drive*np.sin(np.pi*moment/duration)**2-omega**2*state[0]),
                       (0.,duration),(0.,0.),atol=3e-16,rtol=2e-11,method="DOP853")
        assert traj.success
        cosine,vfinal=traj.y[:,-1]
        comparison=abs(complex(vfinal/omega,cosine)-outgoing)/(abs(drive)*duration/omega)
        assert comparison<TOL
        yield dict(duration_in_mode_periods=periods,moved_peak_fraction_of_wave_mass=moved/total,
                   moved_peak_equivalent_msun=moved*scale_mass,action_overlap=inner_product,
                   signed_potential_overlap=overlap,force_overlap=force_overlap,
                   forcing_coefficient=drive,end_field_projection=outgoing.imag,end_velocity_over_omega=outgoing.real,
                   free_amplitude=abs(outgoing) if periods!=2. else 0.,oscillator_ode_error_on_drive_scale=comparison,
                   exact_null=(periods==2.),result_scope="isolated tangent; externally specified mass transport; not a formation measurement")

if __name__=="__main__":
    print(table("formation-probe-forecast.csv",forecasts(),sys.argv[1:]==["create"]))

