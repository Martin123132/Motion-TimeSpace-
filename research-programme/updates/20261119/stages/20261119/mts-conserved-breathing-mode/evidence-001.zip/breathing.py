import os
import sys
from pathlib import Path
for key in ("OMP_NUM_THREADS","OPENBLAS_NUM_THREADS","MKL_NUM_THREADS","NUMEXPR_NUM_THREADS"):
    os.environ[key]="1"
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
PRE=HERE.parent/"mts-quarter-phase-return-20261119"
CLOCK=HERE.parent/"mts-bound-halo-proper-clocks-20261119"
sys.path.insert(0,str(CLOCK))
from halo_mean import bridge,np,Rest,RHO,SCALE,Q,SEC,TOL,guard
from bound_state import solve_edge,LENGTH,KG,MSUN
from scipy.integrate import solve_bvp,simpson,cumulative_simpson
from scipy.interpolate import PchipInterpolator,make_interp_spline,PPoly
from scipy.linalg import eigh_tridiagonal,eigh
from scipy.constants import parsec,c
from functools import lru_cache
import csv
import json

BRANCHES=("isolated","rigid","live")
YEAR=365.25*86400
PRIOR="224d256cdecd9f0685a2fc17d30f16ed8088d171593f30f5e6028e0a168b5859"


def hold():
    guard()
    assert bridge.sha(PRE/"seal.json")==PRIOR
    if (HERE/"STOP-REQUESTED").exists():
        raise SystemExit("owner hold")


def table(name,items,create):
    rows=list(items)
    path=HERE/name
    if create:
        with path.open("x",newline="",encoding="utf8") as stream:
            writer=csv.DictWriter(stream,fieldnames=rows[0])
            writer.writeheader()
            writer.writerows(rows)
    with path.open(newline="",encoding="utf8") as stream:
        assert list(csv.DictReader(stream))==[{key:str(val) for key,val in row.items()} for row in rows],name
    return rows


@lru_cache(None)
def background(baryons,limit):
    rest=Rest(int(baryons))
    if limit==30.:
        bank=bridge.read(CLOCK.parent/"mts-supported-cycle-20261119"/("bound-ordinary.npz" if baryons else "bound-isolated.npz"))
        patch=PPoly(bank["coeff"],bank["x"],extrapolate=False)
        return lambda points:patch(points).T,float(bank["energy"])/Q,rest
    summary,_,func=solve_edge(limit,601,baryons,True)
    return func,summary["eigen_scaled"],rest


def static(branch,limit,rad):
    source,eigen,rest=background(branch!="isolated",limit)
    amp,_,potential,grad=source(rad)
    bggrad,bgpot,bgden=rest.values(rad)
    ratio=np.divide(grad+bggrad,rad,out=np.zeros_like(rad),where=rad>0.)
    ratio=np.where(rad>0.,ratio,(amp**2+bgden)/3)
    return amp,potential+bgpot-eigen,bgden,amp**2+ratio


def spectrum(branch,limit,intervals,nmodes):
    hold()
    step=limit/intervals
    grid=np.arange(1,intervals)*step
    amp,potential,bd,k2=static(branch,limit,grid)
    band,vec=eigh_tridiagonal(1/step**2+potential,-.5/step**2*np.ones(len(grid)-1),
                               select="i",select_range=(0,nmodes))
    energies=band[1:]-band[0]
    basis=vec[:,1:]
    weighted=basis*amp[:,None]
    integral=step*(np.cumsum(grid[:,None]*weighted,axis=0)+grid[:,None]*(weighted.sum(axis=0)-np.cumsum(weighted,axis=0)))
    gravity=-2*amp[:,None]*integral
    projected=basis.T@gravity
    assert np.max(abs(projected-projected.T))<1e-10
    weights=np.sqrt(energies)
    sym=(np.diag(energies)+projected)*weights[:,None]*weights[None,:]
    eig,trans=eigh(sym,subset_by_index=[0,2])
    assert np.min(eig)>0.
    freq=np.sqrt(eig[0])
    coeff=weights*trans[:,0]
    shape=basis@coeff
    imag=(basis@(energies*coeff)+gravity@coeff)/freq
    scale=grid[0]/shape[0]
    norm=shape*scale/grid
    phase=imag*scale/grid
    return grid,norm,phase,np.sqrt(eig),float(band[0])


def seed(branch,limit,grid):
    axis,amp,phase,freq,zero=spectrum(branch,limit,640,90)
    def interp(vals):
        func=make_interp_spline(np.r_[0.,axis,limit],np.r_[vals[0],vals,0.],k=3)
        return func(grid),func.derivative()(grid)
    pform,pgrad=interp(amp)
    qform,qgrad=interp(phase)
    core,_,_,_=static(branch,limit,grid)
    enclosed=cumulative_simpson(2*core*pform*grid**2,x=grid,initial=0.)
    force=np.divide(enclosed,grid**2,out=np.zeros_like(grid),where=grid>0.)
    potential=cumulative_simpson(force,x=grid,initial=0.)
    potential-=potential[-1]+limit*force[-1]
    return np.stack((pform,pgrad,qform,qgrad,potential,force)),freq[0]


@lru_cache(None)
def solve(branch,limit,precision):
    hold()
    core=5/SCALE
    grid=np.unique(np.r_[np.linspace(0,core,43),np.geomspace(core,.15,64),np.linspace(.15,limit,471)])
    state,frequency=seed(branch,limit,grid)
    def rhs(rad,fields,eig):
        pform,pgrad,qform,qgrad,potential,force=fields
        amp,centr,bd,kn=static(branch,limit,rad)
        denom=kn-eig[0]**2
        mult=np.divide(bd,denom,out=np.zeros_like(rad),where=bd>0.) if branch=="live" else np.zeros_like(rad)
        return np.stack((pgrad,2*(centr*pform+amp*potential-eig[0]*qform),
                         qgrad,2*(centr*qform-eig[0]*pform),force*(1+mult),2*amp*pform))
    def bc(left,right,eig):
        return np.array([left[0]-1,left[1],left[3],left[5],right[0],right[2],right[4]+limit*right[5]])
    sol=solve_bvp(rhs,bc,grid,state,S=np.diag([0.,-2.,0.,-2.,0.,-2.]),p=np.array([frequency]),
                  tol=precision,bc_tol=1e-11,max_nodes=16000)
    if not sol.success:
        raise ArithmeticError((branch,limit,sol.message,len(sol.x)))
    assert 0<sol.p[0]<abs(background(branch!="isolated",limit)[1])
    return sol.sol,float(sol.p[0])


def observables(branch,limit,solution,eig):
    core=5/SCALE
    grid=np.unique(np.r_[np.linspace(0.,core,161),np.geomspace(core,.15,241),np.linspace(.15,limit,9001)])
    amp,centr,bd,kn=static(branch,limit,grid)
    pform,pgrad,qform,qgrad,potential,force=solution(grid)
    denom=kn-eig**2
    material=bd>0
    assert not np.any(denom[material]<=0.)
    disp=np.divide(-force,denom,out=np.zeros_like(grid),where=material) if branch=="live" else np.zeros_like(grid)
    actual_force=force-bd*disp
    def integral(val):
        return simpson(val*grid**2,x=grid)
    density2=2*amp*pform
    mass=cumulative_simpson(density2*grid**2,x=grid,initial=0.)
    massnorm=integral(abs(density2))
    overlap=integral(pform*qform)*eig
    pressure=integral(.5*pgrad**2+centr*pform**2)
    kinetic=integral(.5*qgrad**2+centr*qform**2)
    grav=integral(amp*pform*potential)
    grav2=-.5*integral(force*actual_force)+.5*limit**2*force[-1]*potential[-1]
    inner=grid<min(12.,limit)
    swaps=np.count_nonzero(pform[:-1][inner[:-1]]*pform[1:][inner[:-1]]<0.)
    rigid=False if branch=="isolated" else branch=="rigid"
    return dict(branch=branch,edge=limit,omega_scaled=eig,period_yr=2*np.pi*SEC*SCALE**2/(eig*YEAR),
                threshold=-background(branch!="isolated",limit)[1],nodes_below_12=int(swaps),
                number_source_integral=abs(mass[-1])/massnorm,mass_primitive=np.max(abs(grid**2*force-mass))/massnorm,
                p_energy=abs(pressure+grav-overlap)/abs(overlap),q_energy=abs(kinetic-overlap)/abs(overlap),
                gravitational_work=abs(grav-grav2)/abs(grav),force_law_residual=np.max(abs(solution.derivative()(grid)[4]-actual_force))/max(abs(actual_force)),
                material_shell_margin_over_freq_squared=min(denom[material])/eig**2 if np.any(material) else "",
                peak_material_displacement_per_unit_pc=np.max(abs(disp))*SCALE*LENGTH/parsec,
                peak_density_fraction_inside_core=max(abs(density2[grid<=core]/amp[grid<=core]**2)),
                norm_density_at_centre=2*pform[0]/amp[0],integrated_perturbed_mass_over_ground=mass[-1]/integral(amp**2))


def experiment(branch,create):
    reports=[]
    for limit,precision in ((22.,1e-7),(30.,7e-9),(42.,7e-9)):
        profile,eig=solve(branch,limit,precision)
        reports.append(observables(branch,limit,profile,eig))
        if limit==30.:
            dest=HERE/f"mode-{branch}.npz"
            if create:
                bridge.archive(dest,x=profile.x,coeff=profile.c,omega=np.asarray(eig),receipt=np.bytes_(PRIOR))
            data=bridge.read(dest)
            assert np.array_equal(data["coeff"],profile.c) and data["omega"]==eig
    last=reports[-1]["omega_scaled"]
    for row in reports:
        row["change_from_long_domain"]=abs(row["omega_scaled"]/last-1)
        gates=("change_from_long_domain","number_source_integral","mass_primitive","p_energy","q_energy","gravitational_work","force_law_residual")
        row["passes"]=row["nodes_below_12"]==1 and max(row[key] for key in gates)<TOL
    return table("checks-"+branch+".csv",reports,create)


if __name__=="__main__":
    rows=experiment(sys.argv[1],sys.argv[2:]==["create"])
    for row in rows:
        print(row)
