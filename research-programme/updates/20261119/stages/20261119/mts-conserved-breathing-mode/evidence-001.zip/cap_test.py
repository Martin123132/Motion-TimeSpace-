import csv
import json
import sys
from breathing import HERE, PRE, LENGTH, KG, MSUN, TOL, bridge, hold, np, background, table
from mode_forecast import mode, EPS
from outer_speed import RADIUS_KPC, SPEED_KMS, QUOTED_KMS
from scipy.constants import G, parsec
from scipy.interpolate import make_interp_spline
from scipy.optimize import brentq

OUTER = HERE.parent / "mts-halo-outer-mass-20261119"
OUTER_HASH = "80d324ba5c2210d2c42527178a604ec9f60a3ad636243c11cf999bd754248f37"
ARMS = (0., EPS, -EPS, EPS/2, -EPS/2)
RADII = (RADIUS_KPC, 50., 100., "total")
TAGS = ("central_cap", "plus3_cap")


def read_rows(path):
    with path.open(newline="", encoding="utf8") as stream:
        return list(csv.DictReader(stream))


def reference():
    hold()
    assert bridge.sha(OUTER/"seal.json") == OUTER_HASH
    for name, digest in json.loads((OUTER/"seal.json").read_bytes())["files"].items():
        assert bridge.sha(OUTER/name) == digest
    return read_rows(OUTER/"mass-forecast.csv")


def budgets(tag):
    lines = [row for row in reference() if row["preparation"] == tag]
    scale_pc = float(lines[0]["scale_pc"])
    mass_unit = KG * LENGTH / (MSUN * parsec * scale_pc)
    speed = SPEED_KMS + (3 if tag == "plus3_cap" else 0)*QUOTED_KMS
    anchor_mass = (speed*1000)**2 * RADIUS_KPC*1000*parsec/(G*MSUN)
    return scale_pc, mass_unit, anchor_mass, lines


def theory():
    profile = background(False, 30.)[0]
    fields = mode("isolated")[0]
    for tag in TAGS:
        scale_pc, mass_unit, anchor, lines = budgets(tag)
        def pieces(radius):
            edge = 30. if radius == "total" else 1000*radius/scale_pc
            amp, _, _, grad = profile(edge)
            shape = edge**2 * grad
            slope = shape + (0. if radius == "total" else edge**3 * amp**2)
            wave = 0. if radius == "total" else edge**2 * fields(edge)[5]
            return mass_unit*np.array([shape, slope, wave])
        centre, derivative, perturbation = pieces(RADIUS_KPC)
        assert abs(centre/anchor-1) < TOL
        adjustment = -perturbation/derivative
        for radius in RADII:
            mass, slope, source = pieces(radius)
            legacy = anchor if radius == RADIUS_KPC else float(next(row["wave_mass_msun"] for row in lines if row["rad_kpc"] == str(radius)))
            assert abs(mass/legacy-1) < TOL
            tangent = source + slope*adjustment if radius != RADIUS_KPC else 0.
            yield dict(cap=tag, radius_kpc=radius, unperturbed_msun=mass,
                       derivative_at_fixed_occupation_msun=source, derivative_log_inverse_scale_msun=slope,
                       dlog_inverse_scale_depsilon=adjustment, anchored_derivative_msun=tangent,
                       peak_change_at_test_amplitude_msun=EPS*tangent, fractional_change_at_test_amplitude=EPS*tangent/mass)


def forecast(create):
    rows = table("cap-forecast.csv", theory(), create)
    paths = (HERE/"cap-forecast.csv", HERE/"cap_test.py", HERE/"forecast.json", OUTER/"seal.json", PRE/"ordinary-apertures.csv")
    hashes = {str(path.relative_to(HERE.parent)).replace(chr(92), "/"):bridge.sha(path) for path in paths}
    path = HERE/"cap-forecast.json"
    if create:
        with path.open("x", encoding="utf8") as stream:
            json.dump(hashes, stream, sort_keys=True, indent=2)
    assert json.loads(path.read_bytes()) == hashes
    return rows


def count_profiles(data, phase):
    axis = data["radial"]
    spacing = axis[0]
    extent = axis[-1]+spacing
    assert abs(extent-30.) < 1e-10
    for cumulative in data["quarter_phase_counts"][phase]:
        shell = np.diff(cumulative, prepend=0.) / spacing
        assert min(shell) >= 0.
        nodes = np.r_[0., axis, extent]
        primitive = make_interp_spline(nodes, np.r_[0.,shell,0.], k=5).antiderivative()
        assert abs(primitive(extent)/cumulative[-1]-1) < TOL
        yield primitive


def compare():
    predicted = forecast(False)
    for grid in ("space512", "space1024", "time8192"):
        data = bridge.read(HERE/f"nonlinear-{grid}.npz")
        assert data["receipt"].item().decode() == bridge.sha(HERE/"forecast.json")
        assert np.array_equal(data["radial_phase_cycles"], np.arange(5)*.25)
        for phase, cycles in enumerate(data["radial_phase_cycles"]):
            states = list(count_profiles(data, phase))
            for tag in TAGS:
                scale, unit, anchor, _ = budgets(tag)
                def count(state, radius, inverse_ratio):
                    end = 30. if radius == "total" else 1000*radius*inverse_ratio/scale
                    assert 0 < end <= 30.
                    return unit*inverse_ratio*state(end)
                factors = [brentq(lambda fac: count(state, RADIUS_KPC, fac)/anchor-1, .96, 1.04,
                                  xtol=1e-14) for state in states]
                for radius in RADII:
                    ref = next(row for row in predicted if row["radius_kpc"] == radius and row["cap"] == tag)
                    masses = np.array([count(state, radius, fac) for state,fac in zip(states, factors)])
                    assert np.all(np.isfinite(masses))
                    for upper,lower in ((1,2),(3,4)):
                        test_amplitude = ARMS[upper]
                        actual = (masses[upper]-masses[lower])/2.
                        envelope = abs(ref["anchored_derivative_msun"])*test_amplitude
                        expected = ref["anchored_derivative_msun"]*test_amplitude*np.cos(2*np.pi*cycles)
                        error = (abs(actual-expected)/envelope if envelope else max(abs(masses/anchor-1)))
                        denom = envelope if envelope else anchor
                        yield dict(grid=grid, cap=tag, radius_kpc=radius, phase_cycles=cycles,
                                   amplitude=test_amplitude, control_msun=masses[0],
                                   positive_minus_control_msun=masses[upper]-masses[0],negative_minus_control_msun=masses[lower]-masses[0],
                                   signed_half_difference_msun=actual, expected_msun=expected,
                                   tested_peak_envelope_msun=envelope,error_on_peak_scale=error,
                                   positive_arm_linear_error=abs(masses[upper]-masses[0]-expected)/denom,
                                   negative_arm_linear_error=abs(masses[lower]-masses[0]+expected)/denom,
                                   linear_response_pass=error<TOL)


if __name__ == "__main__":
    if sys.argv[1:] == ["freeze"]:
        print(forecast(True))
    else:
        rows = table("cap-evolution.csv", compare(), sys.argv[1:] == ["test"])
        print(len(rows), sum(row["linear_response_pass"] for row in rows), max(row["error_on_peak_scale"] for row in rows))

