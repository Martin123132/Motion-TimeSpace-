import sys
from math import factorial
from reduce_cloud import packet, save_table, peak, Algebra, np, SEC, LOCATIONS, EMISSIONS, TOL
from reduce_cloud import GEOMETRY, csv
import json
from scipy.interpolate import make_interp_spline


def load_calendar():
    source=json.loads((GEOMETRY/"epta-provenance.json").read_bytes())
    assert source["commit"]=="2911d0e52e0c8a4e528c4e3aa46b868ced1910e8"
    with (GEOMETRY/"epta-j1713-observing-days.csv").open(newline="") as stream:
        rows=list(csv.DictReader(stream))
    day=np.array([int(row["day"]) for row in rows])
    group=np.array([row["instrument"] for row in rows])
    count=np.array([int(row["count"]) for row in rows])
    assert sum(count)==sum(row["active"] for row in source["files"])==5011 and len(np.unique(day))==2055
    return day,group,count


def at_arrival(splines, labels, degree):
    ar=Algebra(1,1)
    jets=[splines.derivative(order)(labels) for order in range(degree+1)]
    readout=jets[0].copy()
    for iteration in range(10):
        power=-readout
        updated=jets[0].copy()
        for order in range(1,degree+1):
            updated+=ar.product(jets[order],power)/factorial(order)
            if order<degree:
                power=ar.product(power,-readout)
        difference=np.max(abs(readout-updated),axis=1)
        readout=updated
        if np.all(difference<=1e-14*np.maximum(np.max(abs(readout),axis=1),1e-290)):
            break
    else:
        raise ArithmeticError("equal-arrival inversion")
    return SEC*readout


def records():
    day,group,counts=load_calendar()
    elapsed=(day-day.min())*86400/SEC
    years=(day-day.min())/365.25
    normalized=2*years/years[-1]-1
    columns=np.column_stack((1+years*0,normalized,normalized**2,np.cos(2*np.pi*years),np.sin(2*np.pi*years),
                             np.cos(4*np.pi*years),np.sin(4*np.pi*years),group[:,None]==np.unique(group)[1:]))
    unique,index=np.unique(day,return_inverse=True)
    weights=counts/np.bincount(index,weights=counts)[index]
    root=np.sqrt(weights/sum(weights))
    left,sv,_=np.linalg.svd(root[:,None]*columns,full_matrices=False)
    basis=left[:,sv>sv[0]*1e-12]
    def remove(curve):
        weighted=root*curve
        return weighted-basis@(basis.T@weighted)
    for site in LOCATIONS:
        for name,pos in (("early",0.),("middle",.5),("late",1.)):
            start,end=EMISSIONS[1],EMISSIONS[-2]
            labels=start+pos*(end-start-elapsed[-1])+elapsed
            assert min(labels)>=start-1e-12 and max(labels)<=end+1e-12
            def evaluate(mode,mesh,step,degree):
                delay=packet(mode,mesh)[site+"_64"][2,:,::step]
                assert sum(np.max(abs(delay),axis=1))<EMISSIONS[1]/10
                return at_arrival(make_interp_spline(EMISSIONS[::step],delay,axis=1,k=5),labels,degree)
            ordinary,scalar,mixed=evaluate("target",256,1,3)[1:]
            def values(curve):
                filtered=remove(curve)
                return np.linalg.norm(filtered),np.linalg.norm(root*curve)
            post,raw=values(mixed)
            terms=[values(mixed-other)[0]/post for other in (evaluate("target",128,1,3)[3],evaluate("physical",256,1,3)[3],
                          evaluate("target",256,2,3)[3],evaluate("target",256,1,2)[3])]
            yield dict(site=site,window=name,TOAs=int(sum(counts)),unique_days=len(unique),years=years[-1],raw_s=raw,
                       after_nuisance_s=post,retained_fraction=post/raw,dust_after_nuisance_s=values(ordinary)[0],
                       scalar_after_nuisance_s=values(scalar)[0],grid=terms[0],forecast=terms[1],sampling=terms[2],
                       inverse_order=terms[3],error_sum=sum(terms),passes=sum(terms)<=TOL)


if __name__=="__main__":
    save_table("receiver-calendar.csv",records(),sys.argv[1]=="create")
