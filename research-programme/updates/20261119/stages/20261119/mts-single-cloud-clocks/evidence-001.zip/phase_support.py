import sys
from support import system
from cloud import np, weights, TOL
from reduce_cloud import SEC, save_table
from scipy.constants import c
from scipy.integrate import solve_ivp


def records():
    fraction=1e-6
    sol,field=system(fraction)
    phases=np.pi*np.arange(16)/16
    projected=np.cos(phases)**2
    selected=np.array([.75,2.,3.,4.,4.75,6.5])
    from source import background
    density,_=background("massive")
    def shifted(radius,values):
        inv=1/radius if radius else 0.
        rest,bind=sol(radius)[:2]
        mass=fraction*(rest+fraction*bind)
        factor=1-2*mass*inv
        gamma=np.sqrt(factor/(1-3*mass*inv))
        number=fraction*density*max(1-(radius/5)**2,0.)**6
        facet=factor-2*inv*weights()*values
        return radius**2*(field(radius)**2+projected*facet*field(radius,1)**2)/2-2*radius*number*gamma*values/(np.sqrt(factor)+np.sqrt(facet))
    shifted_sol=solve_ivp(shifted,(0.,7.),np.zeros(16),method="DOP853",atol=1e-23,rtol=1e-12,max_step=.06,t_eval=selected)
    assert shifted_sol.success
    for idx,radius in enumerate(selected):
        rest,bind,_,_,checkmass,_=sol(radius)
        mass=fraction*(rest+fraction*bind)
        facet=1-2*mass/radius
        orbital=mass/(radius-3*mass)
        poles=shifted_sol.y[:,idx]
        assert abs(poles[0]-checkmass)<=2e-12*abs(checkmass)
        def acceleration(delta,square):
            corrected=facet-2*weights()*delta/radius
            pressure=((1-2*square)*field(radius)**2+square*corrected*field(radius,1)**2)/2
            return weights()*(-(1+3*orbital)*delta/radius**2-(1+orbital)*radius*pressure)*c/SEC
        forced=acceleration(poles,projected)
        mean_force=float(np.mean(forced))
        mean_pressure=weights()/4*(1+orbital)*radius*facet*field(radius,1)**2*c/SEC
        mean_mass=weights()*(1+3*orbital)*np.mean(poles)/radius**2*c/SEC
        forecast=-(mean_mass+mean_pressure)
        endpoint_average=(forced[0]+forced[8])/2
        ensemble_refinement=abs(mean_force-np.mean(forced[::2]))/abs(mean_force)
        closure=(abs(forecast-mean_force)+abs(endpoint_average-mean_force))/abs(mean_force)
        assert forced[0]>0 and forced[8]<0 and mean_force<0
        yield dict(r=radius,occupied=radius<5,turning_phase=forced[0],kinetic_phase=forced[8],
                   equal_phase_mean=mean_force,mean_attraction_from_mass=-mean_mass,mean_pressure_leading=-mean_pressure,
                   phase_refinement=ensemble_refinement,closure_error=closure,passes=closure+ensemble_refinement<=TOL)


if __name__=="__main__":
    save_table("supported-phase.csv",records(),sys.argv[1]=="create")
