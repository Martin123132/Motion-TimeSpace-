from pathlib import Path
from functools import lru_cache
import csv
import sys

from cloud import HOME, check, freeze, EMISSIONS, LOCATIONS, TOL, bridge, Algebra, TIMES, np
import json
from rectangle import CHANNELS
from scipy.constants import parsec, c
from scipy.integrate import cumulative_simpson
from scipy.interpolate import make_interp_spline

GEOMETRY=HOME.parent/"mts-two-radius-pressure-clock-20261119"
SEC=json.loads((GEOMETRY/"physical-clock-scale.json").read_bytes())["length_pc"]*parsec/c


@lru_cache(None)
def packet(mode,mesh):
    data = bridge.read(HOME/f"{mode}-{mesh}.npz")
    assert data["receipt"].item().decode()==bridge.sha(HOME/("frozen.json" if mode=="target" else "launch.json"))
    assert np.array_equal(data["emission"],EMISSIONS) and np.array_equal(data["times"],TIMES)
    assert data["mode"].item().decode()==mode and data["mesh"]==mesh
    return data


def peak(curve):
    return float(np.max(abs(curve)))


def wave(mode,mesh,site,rule,channel,axis,referenced):
    curve = packet(mode,mesh)[f"{site}_{rule}"][channel,axis]
    return curve-curve[0] if referenced else curve


def budgets():
    for site in LOCATIONS:
        for channel,name in enumerate(CHANNELS):
            for kind in ("absolute","after_launch"):
                args = (channel,3,kind=="after_launch")
                def pull(mode,mesh=256,rule=64):
                    return wave(mode,mesh,site,rule,*args)
                truth,pred = pull("target"),pull("physical")
                norm = peak(truth)
                idx = int(np.argmax(abs(truth)))
                terms = [peak(diff)/norm for diff in (truth-pred,pred-pull("physical",128),truth-pull("target",128),
                        pred-pull("physical",256,32),truth-pull("target",256,32),
                        pred-pull("physical",256,"quadratic"),truth-pull("target",256,"quadratic"))]
                yield dict(site=site,channel=name,kind=kind,peak_emission=EMISSIONS[idx],signed_peak=truth[idx],
                           seconds=truth[idx]*SEC if channel>=2 else "",model=terms[0],forecast_grid=terms[1],
                           target_grid=terms[2],forecast_ray=terms[3],target_ray=terms[4],forecast_order=terms[5],
                           target_order=terms[6],total=sum(terms),passes=sum(terms)<=TOL)


def response():
    for site in LOCATIONS:
        for channel,name in enumerate(CHANNELS):
            def split(mesh,panels):
                flat,static,full = [wave(mode,mesh,site,panels,channel,3,True) for mode in ("flat","static","physical")]
                return flat,static-flat,full-static
            components = split(256,64)
            coarse,short,order = split(128,64),split(256,32),split(256,"quadratic")
            physical = wave("physical",256,site,64,channel,3,True)
            assert peak(sum(components)-physical)<1e-14*peak(physical)
            idx = int(np.argmax(abs(physical)))
            for label,piece,grid,ray,alt in zip(("flat_scalar_history","initial_curvature_on_scalar","evolving_dust_geometry_on_scalar"),
                                                components,coarse,short,order):
                error = (peak(piece-grid)+peak(piece-ray)+peak(piece-alt))/max(peak(piece),1e-300)
                yield dict(site=site,channel=name,piece=label,peak_emission=EMISSIONS[idx],
                           signed_at_physical_peak=piece[idx],signed_fraction=piece[idx]/physical[idx],
                           piece_peak=peak(piece),internal_numerical_fraction=error,internally_resolved=error<=TOL)


def energy():
    for mode in ("physical","target"):
        data = packet(mode,256)
        low = packet(mode,128)
        for tube,radius in enumerate(data["tube_r"]):
            for axis,label in ((0,"empty"),(1,"dust"),(2,"scalar"),(3,"mixed")):
                def fields(bank):
                    mass,geom,work,flux = bank["tubes"][:,:,axis,tube].T
                    return mass,geom,work,flux
                mass,geom,work,flux = fields(data)
                changed = mass-mass[0]
                def integ(series,stride):
                    return cumulative_simpson(series[::stride],x=TIMES[::stride],initial=0.)
                pdv,flow = integ(work,1),integ(flux,1)
                transfer = pdv+flow
                scale = peak(changed)
                eps = max(scale,1e-300)
                defect = peak(changed-transfer)/eps
                quad = peak((transfer[::2]-integ(work+flux,2)))/eps
                scale_geom = max(peak(mass),1e-300)
                geometry = peak(geom-mass)/scale_geom
                lowmass,lowgeom,_,_ = fields(low)
                coarse = peak((geom-mass)-(lowgeom-lowmass))/scale_geom
                yield dict(mode=mode,r=radius,axis=label,delta_final=changed[-1],pressure_work=pdv[-1],flux=flow[-1],
                           max_mass_change=scale,balance=defect,quadrature=quad,geometry=geometry,
                           geometry_mesh=coarse,balance_pass=defect+quad<=TOL,geom_pass=geometry+coarse<=TOL)


def frequencies():
    for site in LOCATIONS:
        waves = packet("target",256)[site+"_64"]
        for index,name in enumerate(("out","echo")):
            def inverse(stride,degree):
                deriv=make_interp_spline(EMISSIONS[::stride],waves[2+index,:,::stride],axis=1,k=degree).derivative()(EMISSIONS)
                deriv[0]+=1
                return Algebra(1,1).reciprocal(deriv)
            fine,half,other=inverse(1,5),inverse(2,5),inverse(1,7)
            for axis,label in ((1,"dust"),(2,"scalar"),(3,"mixed")):
                truth=waves[index,axis]
                norm=peak(truth-truth[0])
                errors=[peak(vec-vec[0])/norm for vec in (truth-fine[axis],fine[axis]-half[axis],fine[axis]-other[axis])]
                yield dict(site=site,path=name,axis=label,identity=errors[0],coarsening=errors[1],degree=errors[2],
                           total=sum(errors),passes=sum(errors)<=TOL)


def controls():
    for mesh in (128,256):
        target=packet("target",mesh)
        forecast=packet("physical",mesh)
        for site in LOCATIONS:
            for channel,name in enumerate(CHANNELS):
                datum=target[f"{site}_64"][channel]
                pred=forecast[f"{site}_64"][channel]
                assert not np.any(datum[0]) and not np.any(pred[0])
                for axis,label in ((1,"dust"),(2,"scalar")):
                    curve=datum[axis]-datum[axis,0]
                    diff=(datum[axis]-pred[axis])
                    err=peak(diff-diff[0])/peak(curve)
                    yield dict(mesh=mesh,site=site,channel=name,axis=label,peak=peak(curve),forecast_error=err,passes=err<=TOL)


def save_table(filename,rows,create):
    rows = list(rows)
    target=HOME/filename
    if create:
        with target.open("x",encoding="utf8",newline="") as stream:
            writer=csv.DictWriter(stream,fieldnames=rows[0])
            writer.writeheader()
            writer.writerows(rows)
    with target.open("r",encoding="utf8",newline="") as stream:
        old=list(csv.DictReader(stream))
    assert old==[{key:str(val) for key,val in row.items()} for row in rows],filename
    print(filename,len(rows),flush=True)


if __name__=="__main__":
    freeze()
    for filename,func in (("clock-budgets",budgets),("history-split",response),("energy",energy),
                          ("frequency-identity",frequencies),("controls",controls)):
        save_table(filename+".csv",func(),sys.argv[1]=="create")
