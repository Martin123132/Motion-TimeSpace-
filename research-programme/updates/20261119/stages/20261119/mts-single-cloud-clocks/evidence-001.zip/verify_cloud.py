from pathlib import Path
import sys
import csv
import json
from cloud import HOME, PREVIOUS, SEAL, freeze, bridge, stamp, np, TOL, TIMES, LOCATIONS, EMISSIONS, weights
sys.path.insert(0,str(HOME))
from reduce_cloud import budgets, response, energy, frequencies, controls, packet, save_table
from cloud_receiver import records as calendar
from binding import evidence
from shell_acceleration import predictions
from support import tables
from phase_support import records as phases


def manifest():
    freeze()
    source=json.loads((PREVIOUS/"seal.json").read_bytes())
    assert all(bridge.sha(PREVIOUS/name)==digest for name,digest in source["files"].items())
    assert all(bridge.sha(HOME.parent/name)==digest for name,digest in source["external"].items())
    rows={}
    profiles,virial=tables()
    for label,gen in (("clock-budgets",budgets()),("history-split",response()),("energy",energy()),
                      ("frequency-identity",frequencies()),("controls",controls()),("receiver-calendar",calendar()),
                      ("launch-binding",evidence()),("shell-acceleration",predictions()),("supported-shells",profiles),
                      ("supported-virial",virial),("supported-phase",phases())):
        values=list(gen)
        save_table(label+".csv",values,False)
        assert all(all(np.isfinite(cell) for cell in row.values() if isinstance(cell,(float,np.floating))) for row in values)
        for row in values:
            for gate in ("passes","internally_resolved","balance_pass","geom_pass"):
                if gate in row:
                    assert row[gate],(label,row)
        rows[label+".csv"]=len(values)
    assert [row["weak_limit_within_tolerance"] for row in virial]==[True,True,False]
    assert len(profiles)==30 and rows["clock-budgets.csv"]==24
    for mesh in (128,256):
        for mode in ("physical","flat","static","target"):
            bank=packet(mode,mesh)
            for name in bank:
                arr=bank[name]
                if arr.dtype.kind in "fci":
                    assert np.all(np.isfinite(arr)),(mode,name)
            assert bank["weight"]==weights() and bank["fraction"]==1e-6
            assert bank["tubes"].shape==(451,4,4,3)
            for site in LOCATIONS:
                for rule in ("32","64","quadratic"):
                    arr=bank[f"{site}_{rule}"]
                    assert arr.shape==(4,4,len(EMISSIONS)) and not np.any(arr[:,0])
                    if mode in ("flat","static"):
                        assert np.array_equal(arr[:,1:3],packet("physical",mesh)[f"{site}_{rule}"][:,1:3])
            assert np.max(bank["dust_error"])<1e-16
        data=packet("target",mesh)
        density_rise=np.expm1(-1.5*np.log1p(data["trace"][340,2]))
        predicted=data["central"]*TIMES[340]**2/2
        assert abs(density_rise/predicted-1)<TOL
    files={path.name:bridge.sha(path) for path in sorted(HOME.iterdir()) if path.is_file() and path.name!="seal.json"}
    expected={f"{mode}-{mesh}.npz" for mode in ("physical","target","flat","static") for mesh in (128,256)}
    assert {name for name in files if name.endswith(".npz")}==expected
    assert set(rows)=={name for name in files if name.endswith(".csv")}
    assert not any(path.is_dir() or path.suffix in (".tmp",".pyc") for path in HOME.iterdir())
    return dict(parent=SEAL,parent_files=len(source["files"]),parent_external=len(source["external"]),files=files,rows=rows)


if __name__=="__main__":
    output=manifest()
    stamp("seal.json",output,len(sys.argv)>1 and sys.argv[1]=="seal")
    print("verified",len(output["files"]),"files",sum(output["rows"].values()),"rows",bridge.sha(HOME/"seal.json"),flush=True)
