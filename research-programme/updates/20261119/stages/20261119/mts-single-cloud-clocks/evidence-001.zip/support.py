import sys
from reduce_cloud import save_table, peak, SEC, TOL
from source import background
from cloud import np, weights
from scipy.integrate import solve_ivp
from scipy.constants import c


def system(fraction):
    density,field=background("massive")
    def rhs(radius,state):
        rest, binding, potential, loglapse, finite, tangent=state
        inv=1/radius if radius else 0.
        mass=fraction*(rest+fraction*binding)
        compact=mass*inv
        factor=1-2*compact
        root=np.sqrt(1-3*compact)
        bzero=density*max(1-(radius/5)**2,0.)**6
        gamma=np.sqrt(factor)/root
        acc=(rest+fraction*binding)*inv**2/factor
        fieldval,slope=float(field(radius)),float(field(radius,1))
        def loaded(delta,weight):
            fact=factor-2*inv*weight*delta
            assert fact>0
            return radius**2*(fieldval**2+fact*slope**2)/2-2*radius*fraction*bzero*gamma*delta/(np.sqrt(factor)+np.sqrt(fact))
        binding_integrand=(rest+fraction*binding)*inv*(4*compact-1)/(root*(factor+root))
        return np.array([radius**2*bzero,radius**2*bzero*binding_integrand,
                         -radius*bzero*rest,acc,loaded(finite,weights()),loaded(tangent,0.)])
    sol=solve_ivp(rhs,(0.,12.),np.zeros(6),rtol=2e-13,atol=5e-24,max_step=.04,method="DOP853",dense_output=True)
    if not sol.success:
        raise ArithmeticError(sol.message)
    return sol.sol,field


def tables():
    profiles,checks=[],[]
    for fraction in (1e-6,.001,1.):
        solution,field=system(fraction)
        end=solution(12.)
        rest,mass_binding= end[0]*fraction,end[1]*fraction**2
        grav=end[2]*fraction**2
        for radius in (.25,.75,1.25,2.,3.,4.,4.75,5.,6.,6.5):
            wide=np.longdouble
            count,bind,_,_,finite,tangent=solution(radius)
            mass=fraction*(count+fraction*bind)
            compact=mass/radius
            factor=1-2*compact
            ell2=radius**2*compact/(1-3*compact)
            velocity2=compact/factor
            orbital=ell2/radius**2
            def nu_grad(step):
                pts=radius+step*np.array([-2.,-1.,1.,2.])
                nufrac=solution(pts)[3]
                return fraction*(nufrac[0]-8*nufrac[1]+8*nufrac[2]-nufrac[3])/(12*step)
            lapse=fraction*solution(radius)[3]+.5*np.log1p(-2*(mass_binding+rest)/12.)-fraction*end[3]
            gradient=nu_grad(.002)
            static_force=factor*(-(1+orbital)*gradient+orbital/radius)
            static_error=abs(static_force)/(mass/radius**2)
            step_error=abs(gradient-nu_grad(.001))/(mass/radius**2/factor)
            height,slope=field(radius),field(radius,1)
            def force_parts(delta,strength):
                frac_pressure=((factor-2*strength*delta/radius)*slope**2-height**2)/2
                return np.array([-(1+3*orbital)*delta/radius**2,-(1+orbital)*radius*frac_pressure])*weights()
            pieces=force_parts(finite,weights())
            pred=force_parts(tangent,0.)
            load=wide(mass)+wide(finite)*wide(weights())
            denom=1-2*load/wide(radius)
            pressure=wide(weights())*(denom*wide(slope)**2-wide(height)**2)/2
            nu=(load+wide(radius)**3*pressure)/(wide(radius)**2*denom)
            mom=wide(orbital)
            direct=denom*(-(1+mom)*nu+mom/wide(radius))
            off=factor*(-(1+mom)*wide(mass)/(wide(radius)**2*wide(factor))+mom/wide(radius))
            absolute=max(abs(pieces).sum(),1e-290)
            loss=abs(float(direct-off)-sum(pieces))/absolute
            expansion=peak(pred-pieces)/absolute
            profiles.append(dict(fraction=fraction,r=radius,occupied=radius<5,speed_km_s=c/1000*np.sqrt(velocity2),
                      specific_L_geom=ell2**.5,log_lapse=lapse,zero_scalar_balance=static_error,
                      lapse_refinement=step_error,scalar_enclosed_force=pieces[0],scalar_pressure_force=pieces[1],
                      net_scalar_on_m_s2=pieces.sum()*c/SEC,first_stress_error=expansion,direct_geodesic_error=loss,
                      passes=static_error+step_error+expansion+loss<=TOL))
        checks.append(dict(fraction=fraction,rest=rest,exterior_mass=rest+mass_binding,exact_binding=mass_binding,
                  newtonian_potential=grav,newtonian_orbital_energy=-grav/2,newtonian_net=grav/2,
                  relative_virial_limit_error=abs(mass_binding-grav/2)/abs(mass_binding),
                  weak_limit_within_tolerance=abs(mass_binding-grav/2)/abs(mass_binding)<=TOL))
    return profiles,checks


if __name__=="__main__":
    create=sys.argv[1]=="create"
    profiles,checks=tables()
    save_table("supported-shells.csv",profiles,create)
    save_table("supported-virial.csv",checks,create)
