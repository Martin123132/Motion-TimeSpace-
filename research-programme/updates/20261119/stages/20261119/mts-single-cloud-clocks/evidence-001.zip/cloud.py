from pathlib import Path
import sys
import json
import os

HOME = Path(__file__).resolve().parent
PREVIOUS = HOME.parent / "mts-mixed-clock-transport-20261119"
sys.path.insert(0, str(PREVIOUS))
from neutral import Dust
from rectangle import Algebra, System, Launch, base, guard, np, primitive, weights, RADIUS, EMISSIONS, LOCATIONS, TOL, bridge
from transport import OpticalSurface, clocks
from dust_clock import coefficients

SEAL = "5646a3ba63cfb1ca5f13be82eccd64ef78af9c791050e22f2aaa31d3fdd19168"
TIMES = np.arange(451)*.01
TUBES = np.array([2., 5., 6.5])


def check():
    guard()
    if (HOME/"STOP-REQUESTED").exists():
        raise SystemExit("owner hold")
    assert bridge.sha(PREVIOUS/"seal.json") == SEAL and TOL == 2e-5


def hashes(paths):
    return {path.name: bridge.sha(path) for path in paths}


def stamp(name, value, create):
    path = HOME/name
    if create:
        with path.open("x", encoding="utf8") as stream:
            json.dump(value, stream, indent=2, sort_keys=True)
    else:
        assert json.loads(path.read_bytes()) == value, name


def lock(create=False):
    check()
    value = hashes([HOME/"PROTOCOL.md", HOME/"cloud.py", PREVIOUS/"seal.json"])
    old = json.loads((PREVIOUS/"seal.json").read_bytes())["files"]
    assert all(bridge.sha(PREVIOUS/name) == old[name] for name in ("rectangle.py","transport.py","neutral.py","dust_clock.py","measure.py"))
    stamp("launch.json", value, create)


def freeze(create=False):
    lock()
    names = [HOME/f"physical-{mesh}.npz" for mesh in (128,256)]
    stamp("frozen.json", hashes([HOME/"launch.json", *names]), create)


def prepare(mesh, algebra, fraction):
    source = Launch(mesh, 0.)
    radius, inverse = source.radius, source.inv
    unit = base(np.ones_like(radius))
    number = base(np.zeros_like(radius))
    number[1] = fraction*source.number
    mass = 0*unit
    for iteration in range(24):
        factor = unit-2*mass*inverse
        density = algebra.product(number, algebra.root(factor))
        stress = algebra.stress(base(source.height**2)+factor*source.slope**2, weights())/2
        updated = np.stack([primitive(radius, component*radius**2) for component in density+stress])
        err = np.max(abs(updated-mass),axis=1)
        mass = updated
        if iteration >= 10 and np.all(err<=2e-14*np.maximum(np.max(abs(mass),axis=1),1e-290)):
            break
    else:
        raise ArithmeticError("initial mass constraint")
    delta = 2*mass*inverse
    radial = algebra.product(delta,algebra.reciprocal(unit-delta))
    picks = source.picks
    zero = 0*radial[:,picks]
    state = np.stack((radial[:,picks],zero,zero,zero,(mass*inverse**3)[:,picks],base(source.height[picks]),zero,number[:,picks],zero,zero))
    return state, mass[:,-1], number[1,0], radius[picks]


class Shells:
    def __init__(self, state, space):
        ordinary = state[4,1]
        self.delta = 2*ordinary*space**2
        self.factor = 1-self.delta
        tide = state[7,1]*np.sqrt(self.factor)-3*ordinary
        coeff = coefficients(6)
        self.series = np.stack([np.stack((coeff[degree]*ordinary**degree,
                    coeff[degree]*ordinary**(degree-1)*(ordinary+degree*tide))) for degree in range(1,7)])
        assert max(abs(ordinary))*TIMES[-1]**2 < .001

    def evaluate(self, time):
        increment = np.zeros_like(self.series[0])
        derivative = np.zeros_like(increment)
        for degree in range(6,0,-1):
            increment = self.series[degree-1]+time**2*increment
            derivative = 2*degree*self.series[degree-1]+time**2*derivative
        radius, radial = time**2*increment
        speed, shear = time*derivative
        return ((radial*(2+radial)+self.delta)/self.factor, radius*(2+radius),
                -(1+radial)*shear/self.factor, -(1+radius)*speed)


def kg_geometry(dust, state, launch, mode):
    ar = dust.alg
    if mode == "flat":
        return dust.d.diff(dust.x*state[5],dust.d.d2,True)/dust.x - state[5]
    metric = launch[0]
    ia = ar.reciprocal(dust.unit+metric)
    slope = dust.d.diff(state[5],dust.d.d1)
    return ar.product(ia, dust.d.diff(dust.x*state[5],dust.d.d2,True)/dust.x
                      -ar.product(ar.product(dust.d.diff(metric,dust.d.d1),ia),slope)/2)-state[5]


def tube_values(scheme, state, ar, xx, unit, op):
    metric, angular, kr, kt, mass, field, normal = state[:7]
    mul, inv, root = ar.product, ar.reciprocal, ar.root
    aa, cc = unit+metric, unit+angular
    ir, il = inv(root(cc)), inv(root(aa))
    derivative, gradient = op.diff(state[[1,5]],op.d1)
    slope = mul(gradient,il)
    press = ar.stress(mul(normal,normal)+mul(slope,slope)-mul(field,field),weights())/2
    current = -ar.stress(mul(normal,slope),weights())
    rx = root(cc)+xx*mul(derivative,ir)/2
    speed = -xx*mul(kt,ir)
    area = xx**2*cc
    work, flux = -mul(area,mul(press,speed)), -mul(area,mul(current,mul(rx,il)))
    shape = metric-angular-xx*derivative-xx**2*mul(derivative,mul(derivative,inv(cc)))/4
    geometric = xx/2*mul(root(cc),mul(speed,speed)+mul(shape,inv(aa)))
    samples = np.stack((xx**3*mass,geometric,work,flux))
    index = np.searchsorted(xx,TUBES)
    prop = (TUBES-xx[index-1])/(xx[index]-xx[index-1])
    return samples[...,index-1]*(1-prop)+samples[...,index]*prop


def run(mode,mesh):
    assert mode in ("physical","target","flat","static") and mesh in (128,256)
    finite = mode=="target"
    freeze() if finite else lock()
    output = HOME/f"{mode}-{mesh}.npz"
    if output.exists():
        raise FileExistsError(output)
    ar = Algebra(1,int(finite))
    state, initmass, central, xx = prepare(mesh,ar,1e-6)
    initial = state.copy()
    shells = Shells(state,xx)
    if finite:
        scheme = System(mesh,ar,weights(),0.,True)
        op = scheme.space_op
    else:
        state = state[:8].copy()
        scheme = Dust(mesh,ar,weights())
        op = scheme.d
    assert np.array_equal(op.x,xx)
    unit = scheme.unit
    steps = int(np.ceil(.01*mesh/.42))
    dt = .01/steps
    masks = {site:(xx>=low-.09)&(xx<=low+.59) for site,low in LOCATIONS.items()}
    strips = {site:[] for site in masks}
    tubes, dust_error, trace = [], [], []
    def anchor(data, time):
        if not finite:
            data[:4,1] = shells.evaluate(time)
    def rhs(data,time):
        anchor(data,time)
        result = scheme.rhs(data)
        if not finite and mode != "physical":
            result[6] = kg_geometry(scheme,data,initial,mode)
        if not finite:
            result[:4,1] = 0.
            result[5:7,2:] = 0.
        return result
    for tick in range(450*steps+1):
        time = tick*dt
        if tick%steps==0:
            anchor(state,time)
            length = ar.root(unit+state[0])
            shift = ar.product(state[0],ar.reciprocal(unit+length))
            rate = ar.product(state[2],ar.reciprocal(length))
            for site,mask in masks.items():
                strips[site].append(np.stack((shift[:,mask],rate[:,mask])))
            tubes.append(tube_values(scheme,state,ar,xx,unit,op))
            shell = np.array(shells.evaluate(time))
            dust_error.append(np.max(abs(state[:4,1]-shell),axis=1))
            trace.append(np.array([state[5,1,0], state[6,1,0], state[1,1,0]]))
        if tick%(50*steps)==0:
            check()
        if tick == 450*steps:
            break
        first = rhs(state,time)
        second = rhs(state+dt/2*first,time+dt/2)
        third = rhs(state+dt/2*second,time+dt/2)
        fourth = rhs(state+dt*third,time+dt)
        state += dt/6*(first+2*second+2*third+fourth)
    assert np.isfinite(state).all() and not np.any(state[7]-initial[7])
    if finite:
        assert not np.any(state[8:])
    out = dict(times=TIMES,emission=EMISSIONS,tubes=np.array(tubes),tube_r=TUBES,
               trace=np.array(trace),dust_error=np.array(dust_error),weight=weights(),fraction=1e-6,
               launch_mass=initmass,central=central,mesh=mesh,mode=np.bytes_(mode),
               receipt=np.bytes_(bridge.sha(HOME/("frozen.json" if finite else "launch.json"))))
    for site,mask in masks.items():
        raw = np.array(strips.pop(site))
        for panels in (32,64):
            surface = OpticalSurface(TIMES,xx[mask],raw,LOCATIONS[site],panels,3)
            out[f"{site}_{panels}"] = clocks(surface,ar,panels,3)
            if panels==64:
                out[f"{site}_quadratic"] = clocks(surface,ar,panels,2)
    bridge.archive(output,**out)
    print(mode,mesh,"saved",flush=True)


if __name__=="__main__":
    if sys.argv[1]=="init":
        lock(True)
    elif sys.argv[1]=="freeze":
        freeze(True)
    else:
        for arg in sys.argv[2:]:
            run(sys.argv[1],int(arg))
