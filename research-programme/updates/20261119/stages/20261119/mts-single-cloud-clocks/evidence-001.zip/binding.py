import sys
from cloud import prepare, Algebra, np, weights, TOL, TUBES, RADIUS
from reduce_cloud import save_table
from source import background
from scipy.integrate import solve_ivp


def oracle(fraction, step):
    density, height = background("massive")
    occupancy = weights()
    def derivative(radius, state):
        baryon, scalar, volume, gradient = state
        inverse = 1/radius if radius else 0.
        ordinary = density*fraction*max(1-(radius/5)**2,0.)**6
        value, slope = float(height(radius)), float(height(radius,1))
        mass = fraction*baryon+occupancy*scalar+fraction*occupancy*(volume+gradient)
        fb = 1-2*inverse*fraction*baryon
        fs = 1-2*inverse*occupancy*scalar
        ft = 1-2*inverse*mass
        assert min(fb,fs,ft)>0.
        drag = 2*radius*ordinary/(np.sqrt(ft)+np.sqrt(fb))
        redshift = radius*occupancy*slope**2
        return (radius**2*(ordinary/fraction)*np.sqrt(fb),radius**2*(value**2+fs*slope**2)/2,
                -(drag+redshift)*volume-drag/fraction*scalar,
                -(drag+redshift)*gradient-redshift/occupancy*baryon)
    result = solve_ivp(derivative,(0.,float(RADIUS)),np.zeros(4),method="DOP853",atol=1e-23,rtol=1e-12,
                       max_step=step,dense_output=True)
    assert result.success
    return result.sol


def evidence():
    for fraction in (1e-6,.001,1.):
        fine,wide = oracle(fraction,.06),oracle(fraction,.12)
        state,end,_,xx=prepare(256,Algebra(1,1),fraction)
        for radius in (*TUBES,float(RADIUS)):
            if radius==RADIUS:
                take=np.array([radius])
                expected=end[3]
                proj=lambda vals: vals[:,0]
            else:
                right=np.searchsorted(xx,radius)
                take=xx[right-1:right+1]
                relative=(radius-take[0])/(take[1]-take[0])
                proj=lambda vals: (1-relative)*vals[:,0]+relative*vals[:,1]
                expected=proj((state[4,3,right-1:right+1]*take**3)[None,:])[0]
            volume,gradient=proj(fine(take))[2:]*weights()*fraction
            comp_volume,comp_gradient=proj(wide(take))[2:]*weights()*fraction
            predicted=volume+gradient
            err=abs(predicted-expected)/abs(expected)
            refinement=(abs(volume-comp_volume)+abs(gradient-comp_gradient))/abs(expected)
            assert volume<0 and gradient<0 and expected<0
            yield dict(fraction=fraction,r=radius,volume=volume,gradient=gradient,gradient_fraction=gradient/predicted,
                       integral=predicted,mixed_launch=expected,relative_error=err,refinement=refinement,passes=err+refinement<=TOL)


if __name__=="__main__":
    save_table("launch-binding.csv",evidence(),sys.argv[1]=="create")
