import sys
from binding import oracle, evidence
from cloud import prepare, System, Algebra, np, weights, TOL, TUBES
from reduce_cloud import save_table, peak
from source import background


def predictions():
    from scipy.constants import parsec, c
    length_unit = 6.671281904479002*parsec
    _,height=background("massive")
    for fraction in (1e-6,.001,1.):
        solution=oracle(fraction,.06)
        ar=Algebra(1,1)
        state,_,_,radius=prepare(256,ar,fraction)
        baryon,scalar,volume,gradient=solution(radius)
        hmass=(volume+gradient)*fraction*weights()
        added=baryon*fraction+hmass
        press_term=weights()*radius**(-1)*added*height(radius,1)**2
        mass_term=-hmass/radius**3
        prediction=press_term+mass_term
        assert np.all(added>=0) and np.all(prediction>=0)
        model=System(256,ar,weights(),0.,True)
        independent=-model.rhs(state)[3,3]
        select=(radius>=.125)&(radius<=8)
        full=peak((prediction-independent)[select])/peak(prediction[select])
        for site in (.75,2.,4.,5.,6.,6.5):
            idx=np.argmin(abs(radius-site))
            err=abs(prediction[idx]-independent[idx])/abs(prediction[idx])
            yield dict(fraction=fraction,r=radius[idx],binding_term=mass_term[idx],pressure_term=press_term[idx],
                       interaction_Rddot_over_r=prediction[idx],target=independent[idx],
                       physical_acceleration_m_s2=prediction[idx]*radius[idx]*c**2/length_unit,
                       local_error=err,full_shape_error=full,passes=err+full<=TOL)


if __name__=="__main__":
    save_table("shell-acceleration.csv",predictions(),sys.argv[1]=="create")
