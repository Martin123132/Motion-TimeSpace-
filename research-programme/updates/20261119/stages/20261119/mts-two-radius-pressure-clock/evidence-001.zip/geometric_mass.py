from bridge import *
from functools import lru_cache
from scipy.interpolate import RectBivariateSpline
from numpy.polynomial.legendre import leggauss

WINDOWS=((.25,.95),(2.55,3.65),(5.7,6.3))
BANK=ROOT/"mts-released-neutral-cloud-20261118"


@lru_cache(maxsize=8)
def curves(count,arm,degree):
    member=f"strip-{count}-eta0.8-h{arm}.npz"
    path=BANK/member
    assert sha(path)==json.loads((BANK/"closeout.json").read_text())["files"][member]
    block=read(path)
    assert list(block["columns"][:3])==["mass","F_minus_one","h"]
    return [RectBivariateSpline(block["time"],block["radius"],block["values"][:,idx],kx=degree,ky=degree,s=0) for idx in (0,1,2)]


def geometric(cases,clock,rad):
    mass,ff,field=cases;rgrid=rad[None,:];raw=mass(clock,rad);factor=1-2*raw/rgrid
    lapse=1+ff(clock,rad);mr=mass(clock,rad,dy=1);fr=ff(clock,rad,dy=1)
    indicator=2*mr/rgrid**2-factor*fr/(lapse*rgrid)-.0016**2/rgrid**4
    bridge=lapse*factor
    dt=ff(clock,rad,dx=1)*factor-2*lapse*mass(clock,rad,dx=1)/rgrid
    dr=fr*factor+lapse*(2*raw/rgrid**2-2*mr/rgrid)
    return indicator,lapse,bridge,dt,dr,field(clock,rad)


def kernel(nodes,width):
    rest=1-nodes**2
    return rest**5,-10*nodes*rest**4/width,(-10*rest**4+80*nodes**2*rest**3)/width**2


def patch_data(site,window,order):
    nodes,weights=leggauss(order);half=(window[1]-window[0])/2
    time=np.mean(window)+half*nodes;rad=site+.30*nodes
    return time,rad,np.outer(weights,weights)*half*.30,kernel(nodes,half),kernel(nodes,.30)


def operators(rad,phi_time,phi_rad,lapse,bridge,dt,dr):
    rr=rad[None,:];pt,pt1,pt2=(elem[:,None] for elem in phi_time);pr,pr1,pr2=phi_rad
    phi=pt*pr
    wave=-rr**2*pr*(pt2/bridge-pt1*dt/bridge**2)+pt*((2*rr*bridge+rr**2*dr)*pr1+rr**2*bridge*pr2)
    return wave,lapse*rr**2*phi


def ratio(amplitude,quad,wave,dens):
    den=np.sum(quad*amplitude*dens)
    if den<=0:raise ValueError("undefined quotient")
    return float(np.sum(quad*amplitude*wave)/den)


def fixtures():
    time,rad,quad,pt,pr=patch_data(6.,(.25,.95),36)
    ones=np.ones((len(time),len(rad)));zeros=ones*0
    wave,dens=operators(rad,pt,pr,ones,ones,zeros,zeros)
    kk=.19;mu=.8
    field=np.cos(np.sqrt(kk**2+mu**2)*time[:,None])*np.sinc(kk*rad[None,:]/np.pi)
    flat=ratio(field,quad,wave,dens)
    lam=.002;f=1-lam*rad**2/3;wave,dens=operators(rad,pt,pr,ones,f*ones,zeros,(-2*lam*rad/3)*ones)
    constant=ratio(ones*np.sqrt(lam),quad,wave,dens)
    charge=.0016;mass=.002-charge**2/(2*rad);dm=charge**2/(2*rad**2)
    rn=np.max(abs(2*dm/rad**2-charge**2/rad**4))
    assert abs(flat-mu**2)<1e-11 and abs(constant)<1e-11 and rn<1e-20
    return dict(flat_mass_squared=flat,expected=mu**2,de_sitter_mass_squared=constant,RN_residual=rn)


def evaluate():
    checks=fixtures();rows=[];robust=[]
    for count in (960,1920):
        for degree in (3,5):
            ordinary=curves(count,0,degree);massive=curves(count,1,degree)
            for site in SITES:
                for begin,end in WINDOWS:
                    window=(begin,end)
                    dense_t=np.linspace(begin,end,65);dense_r=np.linspace(site-.30,site+.30,65)
                    floor=np.max(abs(geometric(ordinary,dense_t,dense_r)[0]))
                    local=geometric(massive,dense_t,dense_r);mmin=np.min(local[0]);mmax=np.max(local[0])
                    signcheck=np.all(local[-1]>0) or np.all(local[-1]<0)
                    geom_ok=mmin>max(0.,50*floor)
                    for order in (12,24,36):
                        time,rad,quad,pt,pr=patch_data(site,window,order)
                        indicator,lapse,bridge,dt,dr,field=geometric(massive,time,rad)
                        wave,dens=operators(rad,pt,pr,lapse,bridge,dt,dr)
                        ok=bool(geom_ok and np.min(indicator)>50*floor)
                        geom=ratio(np.sqrt(indicator),quad,wave,dens) if ok else None
                        direct=ratio(abs(field),quad,wave,dens) if signcheck else None
                        cancellation=ratio(np.sqrt(indicator),quad,abs(wave),dens) if ok else None
                        rows.append(dict(count=count,degree=degree,site=site,begin=begin,end=end,order=order,
                            geometry_positive_resolved=ok,matter_nodal_check=bool(signcheck),ordinary_abs_floor=floor,
                            minimum_S=mmin,peak_S=mmax,geometry_vs_matter=np.max(abs(local[0]-local[-1]**2))/mmax,
                            metric_mass_squared=geom,field_control_mass_squared=direct,absolute_wave_ratio=cancellation,
                            hits_target=bool(geom is not None and abs(geom-1)<=TOL)))
    for site in SITES:
        for begin,end in WINDOWS:
            def pick(n,k,q):
                return next(v["metric_mass_squared"] for v in rows if
                        (v["site"],v["begin"],v["count"],v["degree"],v["order"])==(site,begin,n,k,q))
            fine=pick(1920,5,36);others=(pick(960,5,36),pick(1920,3,36),pick(1920,5,24))
            if fine is None or None in others:
                errors=[None]*3;budget=None
            else:
                errors=[abs(fine-val) for val in others];budget=abs(fine-1)+sum(errors)
            conditioning=next(v["absolute_wave_ratio"] for v in rows if (v["site"],v["begin"],v["count"],v["degree"],v["order"])==(site,begin,1920,5,36))
            allowance=None if budget is None else min(1.,max(0.,(abs(fine)-budget)/conditioning))
            robust.append(dict(site=site,begin=begin,end=end,inferred_mu_squared=fine,grid_change=errors[0],
                interpolation_change=errors[1],quadrature_change=errors[2],error_plus_changes=budget,
                sign_only_fractional_S_allowance_at_fixed_operator=None if allowance is None else allowance*(2-allowance),
                meets_target=bool(budget is not None and budget<=TOL)))
    return {"weak-mass-readings.csv":rows,"weak-mass-robustness.csv":robust},checks


if __name__=="__main__":
    records,checks=evaluate()
    for key,rows in records.items():write(key,rows)
    print(json.dumps(checks),flush=True)
