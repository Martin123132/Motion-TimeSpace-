from bridge import *
from collections import Counter
from urllib.parse import quote
import urllib.request
import re
import time
from scipy.constants import c, hbar, elementary_charge, parsec, G, Julian_year
from scipy.linalg import eigvalsh

COMMIT="2911d0e52e0c8a4e528c4e3aa46b868ced1910e8"
BASE="EPTA-DR2/DR2full/J1713+0747/"
API="https://gitlab.in2p3.fr/api/v4/projects/21664/repository/files/"
ENERGY=9.585761787277403e-25


def fetch(replay=False):
    targets=[];counts=Counter();seen=set();total=0
    def intake(name):
        nonlocal total
        assert name not in seen and (name=="J1713+0747_all.tim" or re.fullmatch(r"tims/[A-Za-z0-9_.+\-]+\.tim",name))
        seen.add(name);url=API+quote(BASE+name,safe="")+"/raw?ref="+COMMIT
        for attempt in range(3):
            try:
                with urllib.request.urlopen(url,timeout=20) as response:raw=response.read(1_200_001)
                break
            except OSError:
                if attempt==2:raise
                time.sleep(1.)
        total+=len(raw);assert len(raw)<=1_200_000 and total<12_000_000
        skipped=False;active=0;comments=0;links=[]
        for line in raw.decode("utf-8").splitlines():
            words=line.split()
            if not words:continue
            head=words[0].upper()
            if head.startswith("#") or head in ("C","CC","CCC"):comments+=1;continue
            if head in ("FORMAT","MODE"):continue
            if head=="SKIP":skipped=True;continue
            if head=="NOSKIP":skipped=False;continue
            if skipped:continue
            if head=="END":break
            if head=="INCLUDE":
                assert name=="J1713+0747_all.tim" and len(words)==2
                links.append(words[1]);continue
            if head in ("TIME","EFAC","EQUAD","T2EFAC","T2EQUAD","JUMP","INFO"):continue
            if len(words)<5 or not re.fullmatch(r"\d{5}(?:\.\d+)?",words[2]):
                raise ValueError(f"unhandled TIM record in {name}: {head[:20]}")
            day=int(words[2].split(".")[0]);assert 48000<day<61000
            label=words[words.index("-group")+1] if "-group" in words else name[5:-4]
            counts[day,label]+=1;active+=1
        targets.append(dict(path=BASE+name,sha256=hashlib.sha256(raw).hexdigest(),bytes=len(raw),active=active,comments=comments))
        for child in links:intake(child)
    intake("J1713+0747_all.tim")
    rows=[dict(day=day,instrument=instrument,count=value) for (day,instrument),value in sorted(counts.items())]
    assert rows and len(targets)>1 and sum(r["count"] for r in rows)==sum(r["active"] for r in targets)
    receipt=dict(commit=COMMIT,source=API,files=targets,total_bytes=total)
    if replay:
        with (HERE/"epta-j1713-observing-days.csv").open(newline="") as file:old=list(csv.DictReader(file))
        assert old==[{key:str(val) for key,val in row.items()} for row in rows]
        assert json.loads((HERE/"epta-provenance.json").read_text())==receipt
    else:
        write("epta-j1713-observing-days.csv",rows)
        with (HERE/"epta-provenance.json").open("x") as stream:json.dump(receipt,stream,sort_keys=True,indent=2)
    print(len(rows),sum(counts.values()),len(targets),total)


def scales():
    evidence=(ROOT/"MTS-HEAVY-BATH-COUNTERFLOW-AND-GALACTIC-STRESS.md").read_text(encoding="utf8")
    assert "9.585761787277403" in evidence and "Stage50" in evidence
    omega=ENERGY*elementary_charge/hbar
    density=.1*1e9*elementary_charge*1e6/c**2
    psi=np.pi*G*density/omega**2
    return dict(example_mass_eV=ENERGY,length_pc=c/omega/parsec,time_unit_years=1/omega/Julian_year,
            pressure_frequency_nHz=omega/np.pi*1e9,pressure_period_years=np.pi/omega/Julian_year,
            normalization_GeV_cm3=.1,potential_one_endpoint=psi,seconds_per_endpoint_amplitude=psi/(2*omega))


def residual(values,matrix,weight):
    root=np.sqrt(weight/np.sum(weight))[:,None]
    fit=np.linalg.lstsq(root*matrix,root*values,rcond=1e-12)[0]
    return root*(values-matrix@fit)


def experiment():
    results=[];conv=scales()
    with (HERE/"epta-j1713-observing-days.csv").open(newline="") as file:rows=list(csv.DictReader(file))
    receipt=json.loads((HERE/"epta-provenance.json").read_text())
    assert receipt["commit"]==COMMIT and sum(block["bytes"] for block in receipt["files"])==receipt["total_bytes"]
    day=np.array([int(row["day"]) for row in rows]);label=np.array([row["instrument"] for row in rows])
    count=np.array([int(row["count"]) for row in rows])
    assert sum(count)==sum(block["active"] for block in receipt["files"]) and min(count)>0
    tau=(day-(day.min()+day.max())/2)/365.25;norm=tau/max(abs(tau))
    groups=np.unique(label);step=(label[:,None]==groups[1:]).astype(float)
    phase=2*np.pi*tau/conv["pressure_period_years"]
    signals=np.column_stack((np.cos(phase),np.sin(phase)))
    poly=np.stack((norm**0,norm,norm**2),axis=1)
    year=np.stack((np.sin(2*np.pi*tau),np.cos(2*np.pi*tau),np.sin(4*np.pi*tau),np.cos(4*np.pi*tau)),axis=1)
    totals=Counter()
    for dayidx,num in zip(day,count):totals[dayidx]+=num
    for weighting,wt in (("equal_TOA",count),("equal_observing_day",np.array([num/totals[dayidx] for num,dayidx in zip(count,day)]))):
        null=signals*np.sqrt(wt/wt.sum())[:,None];before=null.T@null
        for nuisance,design_matrix in (("spin",poly),("spin+annual",np.column_stack((poly,year))),
                                      ("spin+annual+instrument_offsets",np.column_stack((poly,year,step)))):
            filtered=residual(signals,design_matrix,wt)
            test=residual(design_matrix,design_matrix,wt)
            assert np.max(abs(test))<1e-12
            mat=filtered.T@filtered;fraction=np.sqrt(eigvalsh(mat,before));rms=np.sqrt(eigvalsh(mat))
            assert min(fraction)>0 and max(fraction)<=1.+1e-12
            results.append(dict(weighting=weighting,nuisance=nuisance,release="EPTA DR2full",pulsar="J1713+0747",
                  active_TOAs=int(sum(count)),unique_days=len(totals),groups=len(groups),start_day=min(day),end_day=max(day),
                  duration_years=(max(day)-min(day))/365.25,pressure_cycles=np.ptp(tau)/conv["pressure_period_years"],
                  min_same_phase_rms_fraction=fraction[0],max_same_phase_rms_fraction=fraction[1],
                  min_postfit_rms_per_unit_amplitude=rms[0],max_postfit_rms_per_unit_amplitude=rms[1],
                  min_illustrative_endpoint_ns=1e9*conv["seconds_per_endpoint_amplitude"]*rms[0],
                  max_illustrative_endpoint_ns=1e9*conv["seconds_per_endpoint_amplitude"]*rms[1]))
    return results,conv


if __name__=="__main__":
    if sys.argv[1:] in (["acquire"],["check-source"]):fetch(sys.argv[1]=="check-source")
    else:
        rows,conv=experiment();write("pulsar-schedule-transfer.csv",rows)
        with (HERE/"physical-clock-scale.json").open("x") as file:json.dump(conv,file,indent=2)
