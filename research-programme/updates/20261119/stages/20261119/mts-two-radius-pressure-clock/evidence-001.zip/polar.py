from bridge import *
from charged import Charged
from math import comb
from scipy.special import betainc


class System:
    def __init__(self,count,model):
        self.grid=Charged(count,.8);self.rad=self.grid.r;self.inv=self.grid.inv
        self.mu2=1. if model=="massive" else 0.
        self.model=model
        seed=original.regular.Model(1920,.8,int(model!="ordinary"),0)
        nodes=np.linspace(0.,48.,7681);inner=np.minimum(nodes,3.);den=seed.dens[0]
        strength=.0008*int(model!="ordinary")
        smoothed=seed.h[0]-strength*25*den*inner**2/42
        for degree in range(7):
            smoothed+=strength*2*den*comb(6,degree)*(-1/25)**degree*inner**(4+2*degree)/((3+2*degree)*(2+2*degree)*(5+2*degree)*(4+2*degree))
        blend=np.clip((nodes-1)/2,0,1);blend=blend**4*(35-84*blend+70*blend**2-20*blend**3)
        profile=smoothed*(1-blend)+seed.scalar(nodes)*blend
        h=make_interp_spline(np.r_[-nodes[8:0:-1],nodes],np.r_[profile[8:0:-1],profile],k=5)(self.rad)
        baryons=den*np.maximum(1-(self.rad/5)**2,0)**6
        zeros=np.zeros_like(h)
        self.initial=np.stack((h,zeros,zeros,zeros,baryons,zeros))
        if model=="massless":
            self.mu2=1.
            start=self.geometry(self.initial)
            self.mu2=0.
            self.initial[3]=h/np.sqrt(start["factor"])
            test=self.geometry(self.initial)
            self.match=max(np.max(abs(test[key]-start[key])) for key in ("factor","energy","current","mass"))
            assert self.match<2e-14
        else:self.match=0.

    def geometry(self,state):
        hh,pp,ss,kk,dens,flow=state;grid=self.grid;rad=self.rad;inv=self.inv
        dh=grid.first(hh,1);ds=grid.first(ss,1);kin=(pp**2+kk**2+dh**2+ds**2)/2;pot=self.mu2*hh**2/2
        charge=.8*grid.integral(rad**2*dens);em=(charge*inv**2)**2/2
        factor=np.ones_like(rad)
        for repeat in range(12):
            lor=np.sqrt(1+factor*flow**2);dust=dens*np.sqrt(factor)*lor
            mass=grid.integral(rad**2*(dust+factor*kin+pot)+.8*rad*dens*charge)-charge**2*inv/2
            new=1-2*mass*inv
            if np.max(abs(new-factor))<2e-15:break
            factor=new
        else:raise ArithmeticError("Hamiltonian solve failed")
        speed=flow*np.sqrt(factor)/lor
        energy=dust+kin*factor+pot+em;pressure=dust*speed**2+kin*factor-pot-em
        current=dust*speed-factor*(dh*pp+ds*kk)
        lapsegrad=(mass*inv**2+rad*pressure)/factor
        spacegrad=(rad*energy-mass*inv**2)/factor
        logF=grid.integral(rad*(dust*(1+speed**2)+2*kin*factor)/factor)
        bigF=np.exp(logF-logF[-1]);alpha=bigF*np.sqrt(factor)
        return dict(factor=factor,mass=mass,charge=charge,dh=dh,ds=ds,lor=lor,dust=dust,speed=speed,
            energy=energy,pressure=pressure,current=current,lp=lapsegrad,ls=spacegrad,F=bigF,alpha=alpha,bridge=bigF*factor)

    def rates(self,state,world,observation=False):
        geo=self.geometry(state);get=lambda key:self.grid.at(geo[key],np.array(SITES)+world[0])
        localf=get("factor");impulse=world[1];gam=np.sqrt(1+localf*impulse**2);boost=impulse*np.sqrt(localf);vel=boost/gam
        if observation:
            at=lambda axis:self.grid.at(axis,np.array(SITES)+world[0])
            field,mom,other,second,dens,flow=state
            hh=at(field)
            kinetic=localf*((gam*at(mom)+boost*get("dh"))**2+(gam*get("dh")+boost*at(mom))**2+
                            (gam*at(second)+boost*get("ds"))**2+(gam*get("ds")+boost*at(second))**2)/2
            scalar_p=kinetic-self.mu2*hh**2/2
            proper_dust=get("dust")*(1-get("speed")**2)
            material_p=get("dust")*(gam*(get("speed")-vel))**2
            outward_wave=-localf*((gam*at(mom)+boost*get("dh"))*(gam*get("dh")+boost*at(mom))+
                                  (gam*at(second)+boost*get("ds"))*(gam*get("ds")+boost*at(second)))
            outward_dust=get("dust")*gam**2*(get("speed")-vel)*(1-vel*get("speed"))
            inward=-(np.array(SITES)+world[0])**2*np.sqrt(localf)*gam*(outward_wave+outward_dust)
            return np.stack((world[0],localf*impulse,scalar_p+material_p,inward,get("mass"),get("charge"),hh,self.mu2*hh**2,proper_dust))
        field,mom,other,second,dens,flow=state;grid=self.grid
        def laplace(field,deriv):
            lap=grid.second(field);lap[1:]+=2*self.inv[1:]*deriv[1:];lap[0]*=3
            return lap+(geo["lp"]-geo["ls"])*deriv
        bb=geo["bridge"];F=geo["F"]
        flux=dens*bb*geo["speed"];drflux=grid.first(flux,-1)
        div=drflux+2*self.inv*flux;div[0]=3*drflux[0]
        dustdot=(-geo["alpha"]*geo["lor"]*(geo["lp"]-geo["speed"]**2*geo["ls"])
                -bb*geo["speed"]*grid.first(flow,-1)+.8*F*geo["charge"]*self.inv**2)
        values=np.stack((bb*mom,bb*laplace(field,geo["dh"])-F*self.mu2*field,
                         bb*second,bb*laplace(other,geo["ds"]),-div,dustdot))
        clock=get("alpha")/gam
        orbit=np.stack((clock*localf*impulse,-get("alpha")*gam*(get("lp")-vel**2*get("ls")),clock))
        return values,orbit


def run(count,model):
    guard();assert model in MODELS and count in (960,1920)
    if (HERE/"frozen.json").exists() or list(HERE.glob("detector-*.npz")):raise RuntimeError("forecast already frozen")
    target=forecast(count,model)
    if target.exists():raise FileExistsError(target)
    system=System(count,model);state=system.initial.copy();world=np.zeros((3,2))
    steps=int(np.ceil(6.5/(.26*system.grid.step)/512))*512;dt=6.5/steps;history=[];clocks=[]
    launch=system.geometry(state);axis=system.grid.r
    light=make_interp_spline(axis,1/launch["bridge"],k=5).integrate(*SITES)
    light*=system.grid.at(launch["alpha"],np.array([SITES[-1]]))[0]
    for tick in range(steps+1):
        if tick%(steps//512)==0:
            clocks.append(world[2].copy());history.append(system.rates(state,world,True))
        if tick%128==0:guard()
        if tick==steps:break
        one,p1=system.rates(state,world);two,p2=system.rates(state+dt*one/2,world+dt*p1/2)
        three,p3=system.rates(state+dt*two/2,world+dt*p2/2);four,p4=system.rates(state+dt*three,world+dt*p3)
        state+=dt/6*(one+2*two+2*three+four);world+=dt/6*(p1+2*p2+2*p3+p4)
    clocks=np.array(clocks);hist=np.array(history);assert np.all(clocks[-1]>6.4)
    records=np.stack([make_interp_spline(clocks[:,site],hist[:,:,site],k=5)(CLOCK) for site in range(2)])
    assert np.isfinite(records).all()
    archive(target,clock=CLOCK,records=records,columns=NAMES,sites=SITES,launch_light_time=light,
        energy_match=system.match,initial_mass=launch["mass"][-1],launch_charge=launch["charge"][-1],
        parent=LOCK,protocol=sha(HERE/"PROTOCOL.md"))
    print(target.name,flush=True)


if __name__=="__main__":
    for count in (960,1920):
        for model in MODELS:run(count,model)
