from bridge import *
from scores import physical
from geometric_mass import evaluate as geometry, BANK
from cadence import experiment
from timing_budget import results as lag_budget


def validate():
    check_forecast()
    for model in MODELS:
        for count in (960,1920):
            block=read(forecast(count,model))
            assert str(block["parent"])==LOCK and str(block["protocol"])==sha(HERE/"PROTOCOL.md")
            assert block["records"].shape==(2,321,9) and np.array_equal(block["clock"],CLOCK)
            assert np.array_equal(block["sites"],SITES) and list(block["columns"])==NAMES
            assert np.isfinite(block["records"]).all()
            assert np.all(block["records"][:,0,:2]==0)
            if model=="massless":assert block["energy_match"]<2e-14
        if model!="massless":
            for dx in (.025,.0125):
                block=read(detector(dx,model))
                assert str(block["parent"])==LOCK and str(block["protocol"])==sha(HERE/"PROTOCOL.md")
    readings=physical();weak,fixtures=geometry();readings.update(weak)
    readings["lag-budget.csv"]=lag_budget(readings)
    readings["pulsar-schedule-transfer.csv"],scales=experiment()
    assert json.loads((HERE/"physical-clock-scale.json").read_text())==scales
    total=0
    for key,rows in readings.items():
        with (HERE/key).open(newline="",encoding="utf8") as file:saved=list(csv.DictReader(file))
        assert len(rows)==len(saved) and len(rows)>0,key
        for source,result in zip(rows,saved):
            assert set(source)==set(result),key
            for field,val in source.items():assert result[field]==("" if val is None else str(val)),(key,field,val,result[field])
        total+=len(rows)
    assert len(list(HERE.glob("forecast-*.npz")))==6 and len(list(HERE.glob("detector-*.npz")))==4
    assert not list(HERE.glob("*.partial")) and not (HERE/"__pycache__").exists()
    protected={}
    def keep(path):
        protected[str(path.relative_to(ROOT))]=sha(path)
    keep(OLD/"closeout.json")
    keep(ROOT/"MTS-HEAVY-BATH-COUNTERFLOW-AND-GALACTIC-STRESS.md")
    keep(ROOT/"mts-coupled-spherical-tides-20261118"/"EQUATIONS.md")
    for name in ("free_fall.py","vacuum_stress_control.py","hidden_run.py","focusing_witness.py","clock-source-balance.csv"):
        assert sha(OLD/name)==json.loads((OLD/"closeout.json").read_text())["files"][name];keep(OLD/name)
    for path in (original.BASE/"closeout.json",BANK/"closeout.json"):keep(path)
    for member in ("mass_flux.py","regular.py","signed_equations.py","smooth_launch.py","centre_base.py"):
        keep(original.inherited(member))
    for path,files in ((ROOT/"mts-charged-exterior-rulers-20261118",["charged.py",*[f"charged-1920-eta0.8-h{am}-b1.npz" for am in (0,1)]]),
                       (ROOT/"mts-coupled-spherical-tides-20261118",["evolve.py"]),
                       (ROOT/"mts-released-neutral-cloud-20261118",[f"strip-{n}-eta0.8-h{am}.npz" for n in (960,1920) for am in (0,1)])):
        prior=json.loads((path/"closeout.json").read_text())["files"]
        for file in files:
            assert sha(path/file)==prior[file];keep(path/file)
    for dx in (.025,.0125):
        for base,file in ((ROOT/"mts-coherent-current-ruler-20261118",original.name(dx,.8,0,"minus")),
                          (ROOT/"mts-three-current-magnetic-test-20261118",original.name(dx,.8,1,"matched3"))):
            assert sha(base/file)==json.loads((base/"closeout.json").read_text())["files"][file];keep(base/file)
    selected=("forecast-comparisons.csv","geometric-stress.csv","old-control.csv","pressure-replay.csv")
    tally={key:dict(passed=sum(int(item["passes"]) for item in readings[key]),total=len(readings[key])) for key in selected}
    tally["weak-mass-robustness.csv"]=dict(passed=sum(int(item["meets_target"]) for item in readings["weak-mass-robustness.csv"]),total=6)
    return dict(previous=LOCK,protected=protected,counts=tally,scored_rows=total,fixtures=fixtures,
                files={p.name:sha(p) for p in sorted(HERE.iterdir()) if p.is_file() and p.name not in ("closeout.json","STOP-REQUESTED")})


if __name__=="__main__":
    info=validate();path=HERE/"closeout.json"
    if sys.argv[1:]==["seal"]:
        with path.open("x") as stream:json.dump(info,stream,indent=2,sort_keys=True)
    else:assert json.loads(path.read_text())==info
    print("verified",len(info["files"]),"files,",info["scored_rows"],"rows",info["counts"],sha(path))
