from bridge import *
from focusing_witness import packet
from scipy.integrate import solve_ivp
from functools import lru_cache
import math


def peak(value):
    return float(np.max(abs(value)))


@lru_cache(maxsize=32)
def temporal_weights(offsets,degree):
    points=np.array(offsets,dtype=float)
    matrix=np.vstack([points**power for power in range(len(points))])
    target=np.zeros(len(points));target[degree]=math.factorial(degree)
    return np.linalg.solve(matrix,target)


def rates(values,order=1,width=7,stride=1):
    result=np.zeros_like(values)
    for index in range(len(values)):
        begin=max(index%stride,min(index-width//2*stride,index+((len(values)-1-index)//stride-width+1)*stride))
        positions=begin+stride*np.arange(width);assert index in positions
        result[index]=temporal_weights(tuple((positions-index)//stride),order)@(values[positions]-values[index])/(.02*stride)**order
    return result


def invariant(records,jets,site,width,stride):
    disp=records[:,0];rad=site+disp
    da,ax,delta_rx,rxx=jets.T;aa=1+da;rx=1+delta_rx
    adot=rates(da,1,width,stride);velocity=rates(disp,1,width,stride);accel=rates(disp,2,width,stride)
    curvature=(velocity**2+(da-delta_rx)*(2+da+delta_rx)/aa**2)/rad**2
    wave=-accel-adot/aa*velocity+(rxx-ax*rx/aa)/aa**2
    return curvature-wave/rad-records[:,5]**2/rad**4-records[:,8]


def reconstruct(records,site,stride,degree):
    raw=records[::stride];rad=site+raw[:,0];mass0=raw[0,4]+raw[0,5]**2/(2*rad[0]);charge=raw[0,5]
    assert peak(raw[:,5]-charge)<abs(charge)*1e-12
    sources=make_interp_spline(CLOCK[::stride],np.column_stack((raw[:,2],-raw[:,3]/rad**2)),k=degree)
    def equation(clock,values):
        dis,vel,dm=values;radius=site+dis;press,out=sources(clock)
        return [vel,-(mass0+dm)/radius**2+charge**2/radius**3-radius*press,-radius**2*(press*vel+out)]
    sol=solve_ivp(equation,(0.,6.4),[0.,0.,0.],method="DOP853",rtol=1e-12,atol=[1e-18,1e-19,1e-21],t_eval=CLOCK,max_step=.05)
    assert sol.success
    return certificate(sol.y[0],sol.y[1],site)


def physical():
    check_forecast();comparisons=[];arrivals=[];lags=[];invariants=[];controls=[];budgets=[];conventional=[];time_sampling=[]
    for mesh,spacing in ((960,.025),(1920,.0125)):
        forecasts={model:read(forecast(mesh,model)) for model in MODELS}
        archives={model:read(detector(spacing,model)) for model in MODELS[:2]}
        for model,block in archives.items():
            assert str(block["frozen"])==sha(HERE/"frozen.json") and np.array_equal(block["clock"],CLOCK)
            assert list(block["columns"])==NAMES and block["records"].shape==(2,321,9) and block["jets"].shape==(2,321,4)
            assert np.all(block["records"][:,0,0:2]==0)
            archive=packet(spacing,int(model=="massive"),"centre");src=archive["mass"]
            rec=block["records"][0]
            for key,error,scale in (
                ("radius",peak((SITES[0]+rec[:,0])-archive["rows"][:,6]),peak(rec[:,0])),
                ("speed",peak(rec[::10,1]-src[:,7]),peak(rec[:,1])),
                ("mass",peak(rec[::10,4]-src[:,8]),peak(rec[:,4])),
                ("non_coulomb_pressure",peak(rec[::10,2]+(src[:,14]+src[:,16])/src[:,11]),peak(archives["massive"]["records"][0,:,2])),
                ("inward_energy_flux",peak(rec[::10,3]-src[:,13]),peak(archives["massive"]["records"][0,:,3]))):
                controls.append(dict(mesh=mesh,model=model,control=key,absolute=error,reference=scale,passes=bool(error<=TOL*scale)))
        for index,site in enumerate(SITES):
            primary=archives["massive"]["records"][index];bare=archives["ordinary"]["records"][index]
            reference=certificate(primary[:,0],rates(primary[:,0]),site)
            pscale=peak(primary[:,2]);fluxscale=peak(primary[:,3]);sscale=peak(primary[:,7]);vscale=peak(primary[:,1]-bare[:,1]);rscale=peak(primary[:,0]-bare[:,0])
            for model,block in archives.items():
                raw=block["records"][index];pred=forecasts[model]["records"][index]
                geom=certificate(raw[:,0],rates(raw[:,0]),site);estimated=certificate(pred[:,0],pred[:,1],site)
                for channel,error,scale in (
                    ("pressure",peak(pred[:,2]-raw[:,2]),pscale),("energy_flux",peak(pred[:,3]-raw[:,3]),fluxscale),
                    ("radius_displacement",peak(pred[:,0]-raw[:,0]),rscale),("speed",peak(pred[:,1]-raw[:,1]),vscale),
                    ("four_clock_geometry",abs(estimated-geom),abs(reference)),
                    ("bank_speed_vs_radius",abs(certificate(raw[:,0],raw[:,1],site)-geom),abs(reference))):
                    comparisons.append(dict(mesh=mesh,model=model,site=site,channel=channel,absolute=error,norm=scale,
                        ratio=error/scale,passes=bool(error<=TOL*scale)))
                for stride,degree in ((1,5),(2,5),(10,5),(10,3),(20,5)):
                    replay=reconstruct(raw,site,stride,degree)
                    budgets.append(dict(mesh=mesh,model=model,site=site,dt=.02*stride,degree=degree,geometric=geom,
                        predicted_from_stress=replay,error_on_massive=abs(replay-geom)/abs(reference),passes=bool(abs(replay-geom)<=TOL*abs(reference))))
                for width,stride in ((7,1),(5,1),(7,2)):
                    computed=invariant(raw,block["jets"][index],site,width,stride)
                    err=peak(computed-raw[:,7])/sscale
                    invar=dict(mesh=mesh,model=model,site=site,width=width,stride=stride,peak_direct=peak(raw[:,7]),
                        peak_metric=peak(computed),peak_error=peak(computed-raw[:,7]),error_on_massive=err,
                        interior_error_on_massive=peak((computed-raw[:,7])[6:-6])/sscale,passes=bool(err<=TOL))
                    invariants.append(invar)
                if model=="massive":
                    dense=features(CLOCK,raw[:,2])
                    for stride in (1,2,10,20):
                        times=features(CLOCK[::stride],raw[::stride,2])
                        for label,exact,test in zip(("zero","first_max","second_max"),dense,times):
                            time_sampling.append(dict(mesh=mesh,site=site,dt=.02*stride,feature=label,measured=test,
                                shift_vs_dense=None if test is None or exact is None else test-exact))
            rad=forecasts["massless"]["records"][index]
            gold=forecasts["massive"]["records"][index]
            ordinary=forecasts["ordinary"]["records"][index]
            for label,values in (("ordinary",ordinary),("massive",gold),("massless",rad),("synchronous_massive",primary)):
                cert=certificate(values[:,0],rates(values[:,0]) if label=="synchronous_massive" else values[:,1],site)
                f=features(CLOCK,values[:,2])
                arrivals.append(dict(mesh=mesh,model=label,site=site,first_zero=f[0],first_max=f[1],second_max=f[2],
                    final_displacement=values[-1,0],release_pressure=values[0,2],certificate=cert,
                    pressure_peak=peak(values[:,2]),flux_peak=peak(values[:,3])))
            reference_h=primary[0,6]
            naive=-.5*reference_h**2*np.cos(2*CLOCK)
            conventional.append(dict(mesh=mesh,site=site,equal_energy_mismatch=float(forecasts["massless"]["energy_match"]),
                ADM_difference=float(forecasts["massless"]["initial_mass"]-forecasts["massive"]["initial_mass"]),
                ordinary_pressure_error=peak(ordinary[:,2]-primary[:,2])/pscale,
                massless_pressure_error=peak(rad[:,2]-primary[:,2])/pscale,
                massless_clock_error=abs(certificate(rad[:,0],rad[:,1],site)-reference)/abs(reference),
                local_oscillator_pressure_error=peak(naive-primary[:,2])/pscale,
                local_oscillator_h_error=peak(reference_h*np.cos(CLOCK)-primary[:,6])/peak(primary[:,6])))
        for label in ("ordinary","massive","massless","synchronous_massive"):
            entries=[row for row in arrivals if row["mesh"]==mesh and row["model"]==label]
            for feature in ("first_zero","first_max","second_max"):
                first,second=[row[feature] for row in entries]
                light=float(forecasts["massive" if label=="synchronous_massive" else label]["launch_light_time"])
                lag=None if first is None or second is None else second-first
                lags.append(dict(mesh=mesh,model=label,feature=feature,lag=lag,launch_light_time=light,
                    lag_to_crossing=None if lag is None else lag/light))
    return dict(zip(("forecast-comparisons.csv","feature-times.csv","radius-lags.csv","geometric-stress.csv","old-control.csv",
                     "pressure-replay.csv","conventional-source.csv","timing-sampling.csv"),
                    (comparisons,arrivals,lags,invariants,controls,budgets,conventional,time_sampling)))


if __name__=="__main__":
    for key,rows in physical().items():write(key,rows)
