from bridge import *
from hidden_family import data
from focusing_witness import packet
from unittest.mock import patch
from scipy.ndimage import correlate1d


def run(dx,model):
    check_forecast()
    assert dx in (.025,.0125) and model in ("ordinary","massive")
    arm=int(model=="massive");target=detector(dx,model)
    if target.exists():raise FileExistsError(target)
    seed=packet(dx,arm,"centre");weights=tuple(seed["weights"])
    holder=original.Centre(dx,.8,arm,cap=12,reduced=True,damping=.5,mass_form=True)
    holder.profile=weights
    with patch.object(original.smooth_launch,"spin",original.law):
        original.smooth_launch.refresh(holder,.8,arm,False,weights)
    state=holder.y0.copy();samples=[];jets=[]
    stencils=[]
    for site in SITES:
        middle=round(site/dx);indices=np.arange(middle-4,middle+4);xx=(holder.rad[indices,0]-site)/dx
        coeff=np.array([np.prod(-np.delete(xx,pos)/(node-np.delete(xx,pos))) for pos,node in enumerate(xx)])
        stencils.append((indices,coeff))
    stride=int(np.ceil(.02/(.30*dx)-1e-12));dt=.02/stride
    with patch.object(original.signed_equations,"spin",original.law):
        for idx in range(321):
            guard()
            ext=holder.extend(state);axis=holder.x[:,0];mat=ext.real[:,:,0];factor=1+mat[0]
            aa=np.sqrt(factor);bb=np.sqrt(1+mat[2]);dR=axis*mat[2]/(1+bb);rad=axis*bb
            da=mat[0]/(aa+1);dra=holder.dr(da);drb=holder.dr(dR);drrb=holder.drr(dR)
            speed=-rad*mat[6]/(bb**2);mom=mat[9]/(aa*rad**2)
            grad=holder.dr(mat[8])/aa;lor=np.hypot(1,mat[14]/aa);rho=mat[13]/(aa*rad**2*lor)
            press=(mom**2+grad**2-mat[8]**2)/2+rho*(mat[14]/aa)**2
            outward=rho*lor*mat[14]/aa-mom*grad
            inward=-rad**2*outward*(1+drb)/aa
            arrays=np.stack((dR,speed,press,inward,mat[23]*axis**3,mat[10],mat[8],mat[8]**2,rho,
                             da,dra,drb,drrb))[:,holder.ghost:]
            probe=np.stack([arrays[:,indices]@coeff for indices,coeff in stencils])
            samples.append(probe[:,:9]);jets.append(probe[:,9:])
            if idx==320:break
            for substep in range(stride):
                first=holder.rhs(state);second=holder.rhs(state+dt*first/2);third=holder.rhs(state+dt*second/2)
                state+=dt*(first+2*second+2*third+holder.rhs(state+dt*third))/6
    result=np.transpose(samples,(1,0,2));geometric=np.transpose(jets,(1,0,2))
    assert np.isfinite(result).all() and np.isfinite(geometric).all()
    archive(target,records=result,jets=geometric,jet_names=["a_minus_1","a_x","R_x_minus_1","R_xx"],
        columns=NAMES,clock=CLOCK,sites=SITES,weights=weights,protocol=sha(HERE/"PROTOCOL.md"),
        frozen=sha(HERE/"frozen.json"),parent=LOCK)
    print(target.name,flush=True)


if __name__=="__main__":
    for dx in (.0125,.025):run(dx,sys.argv[1])
