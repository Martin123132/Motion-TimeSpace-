import os
import sys
from pathlib import Path
import hashlib
import json
import csv

for setting in ("OPENBLAS_NUM_THREADS","OMP_NUM_THREADS","MKL_NUM_THREADS","NUMEXPR_NUM_THREADS"):
    os.environ[setting]="1"
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
OLD=ROOT/"mts-fourth-hidden-current-20261118"
LOCK="52682cca527bfb606e84648f5d777cfd22d4376855e6fef552dcb46fb498eb76"
sys.path.insert(0,str(OLD))
from hidden_run import original, parent, fast_hold
from free_fall import derivative
from vacuum_stress_control import design,weight
import numpy as np
from scipy.interpolate import make_interp_spline, CubicSpline

SITES=(6.,6.5)
CLOCK=np.arange(321)*.02
PICKS=np.array([150,200,250,320])
TOL=2e-5
MODELS=("ordinary","massive","massless")
NAMES="displacement speed pressure inward_flux_term enclosed_mass charge h h_squared rest_density".split()


def sha(path):
    with path.open("rb") as stream:return hashlib.file_digest(stream,"sha256").hexdigest()


def guard():
    fast_hold()
    assert sha(OLD/"closeout.json")==LOCK
    if (HERE/"STOP-REQUESTED").exists():raise SystemExit("owner hold")


def archive(path,**fields):
    transient=path.with_suffix(".partial")
    if path.exists() or transient.exists():raise FileExistsError(path)
    with transient.open("xb") as stream:np.savez_compressed(stream,**fields)
    transient.rename(path)


def read(path):
    with np.load(path,allow_pickle=False) as source:return dict(source)


def forecast(mesh,model):
    return HERE/f"forecast-{mesh}-{model}.npz"


def detector(dx,model):
    return HERE/f"detector-{dx:g}-{model}.npz"


def seal_forecast():
    guard()
    paths=[forecast(mesh,model) for mesh in (960,1920) for model in MODELS]
    inputs=[source for source in ("PROTOCOL.md","bridge.py","polar.py")]
    return dict(parent=LOCK,files={path.name:sha(path) for path in paths},inputs={name:sha(HERE/name) for name in inputs})


def check_forecast():
    guard()
    assert json.loads((HERE/"frozen.json").read_text())==seal_forecast()


def write(member,rows):
    with (HERE/member).open("x",newline="",encoding="utf8") as file:
        out=csv.DictWriter(file,fieldnames=list(rows[0]));out.writeheader();out.writerows(rows)


def certificate(displacement,speed,site):
    dis=displacement[PICKS]
    inv=-dis/(site*(site+dis))
    ordinates=speed[PICKS]**2/inv
    coeff=weight(design(inv,site))
    assert min(inv)>0 and min(np.diff(inv))>0
    return float(coeff@(ordinates-ordinates[0]))


def features(clock,pressure):
    if max(abs(pressure))<1e-18:return (None,None,None)
    fit=CubicSpline(clock,pressure)
    roots=[value for value in fit.roots(extrapolate=False) if 0<value<2 and fit(value,1)>0]
    extrema=fit.derivative().roots(extrapolate=False)
    picks=[]
    for left,right in ((.8,2.4),(3.8,5.6)):
        choices=[value for value in extrema if left<value<right and fit(value)>0 and fit(value,2)<0]
        picks.append(float(min(choices)) if choices else None)
    return (float(min(roots)) if roots else None,*picks)


if __name__=="__main__":
    guard()
    assert not list(HERE.glob("detector-*.npz"))
    with (HERE/"frozen.json").open("x") as out:json.dump(seal_forecast(),out,indent=2,sort_keys=True)
