from bridge import *


def results(saved=None):
    def load(key):
        if saved is not None:return saved[key]
        with (HERE/key).open(newline="") as file:return list(csv.DictReader(file))
    lags=load("radius-lags.csv");timing=load("timing-sampling.csv")
    out=[]
    for index,channel in enumerate(("first_zero","first_max","second_max")):
        def value(count,model):
            return float(next(row["lag"] for row in lags if int(row["mesh"])==count and row["model"]==model and row["feature"]==channel))
        def offsets(stride):
            readout=[row for row in timing if int(row["mesh"])==1920 and float(row["dt"])==stride and
                     row["feature"]==("zero" if index==0 else channel)]
            assert [float(row["site"]) for row in readout]==list(SITES)
            return float(readout[1]["shift_vs_dense"])-float(readout[0]["shift_vs_dense"])
        actual=value(1920,"synchronous_massive");expected=value(1920,"massive")
        spread=abs(actual-value(960,"synchronous_massive"))+abs(expected-value(960,"massive"))
        dt=abs(offsets(.04))
        stress=abs(expected-actual)+spread+dt
        out.append(dict(feature=channel,frozen_lag=expected,direct_lag=actual,forecast_error=abs(expected-actual),
                 spatial_changes=spread,time_change_to_point04=dt,point2_lag_shift=offsets(.2),
                 budget_in_proper_time=stress,budget_over_lag=stress/abs(actual),passes_time_scale=bool(stress<=TOL),
                 passes_lag_scale=bool(stress<=TOL*abs(actual))))
    return out


if __name__=="__main__":write("lag-budget.csv",results())
