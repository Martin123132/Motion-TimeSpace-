import sys
from field_readout import write,make_grid
from grid_wave import HERE,np,Forcing,TOL
from propagate import apply,residual
from satellite import unit_scales


def checks():
    rows=[]
    for label in ("central_cap","illustrative"):
        grid=make_grid(30.,44,5)
        drive=Forcing(grid,label,"all")
        with np.load(HERE/f"l5-{label}-jet-1000-all.npz") as bank:
            raw=bank["raw"]
        source=drive.source(5/drive.time)
        rhs=apply(grid.mat,raw)+residual(grid,source,"jet",1.,raw)
        def cx(mat):
            return mat[:grid.count]+1j*mat[grid.count:]
        degree1,degree2=[cx(state) for state in raw]
        deriv1,deriv2=[cx(state) for state in rhs]
        num=2*np.vdot(grid.coef,deriv1[:,0]).real
        pieces=2*np.array([np.vdot(grid.coef,deriv2[:,0]).real,np.vdot(degree1,deriv1).real])
        err=abs(pieces.sum())/max(abs(pieces))
        assert abs(num)<1e-11 and err<TOL
        rows.append(dict(scale=label,check="signed_second_number_derivative",left=pieces[0],right=-pieces[1],relative_error=err,passes=err<TOL))
        for scale in (.125,.25,.5,1.):
            results=[]
            def total(frac):
                field=(frac*raw[0]+frac**2*raw[1])[None,...]
                return (apply(grid.mat,field)+residual(grid,source,"finite",frac,field))[0]
            for sign in (1,-1):
                results.append(total(scale*sign))
            even=.5*(results[0]+results[1])/scale**2
            pe=.5*(total(scale/2)+total(-scale/2))/(scale/2)**2
            ppe=.5*(total(scale/4)+total(-scale/4))/(scale/4)**2
            projected=(64*ppe-20*pe+even)/45
            err=np.linalg.norm(projected-rhs[1])/np.linalg.norm(rhs[1])
            rows.append(dict(scale=label,check=f"quadratic_RHS_coefficient_{scale}",left=np.linalg.norm(projected),right=np.linalg.norm(rhs[1]),relative_error=err,passes=err<TOL))
    return rows


if __name__=="__main__":
    items=checks()
    write("balance-identities.csv",items,sys.argv[1:]==["create"])
    print([(row["check"],row["relative_error"]) for row in items[:5]])

