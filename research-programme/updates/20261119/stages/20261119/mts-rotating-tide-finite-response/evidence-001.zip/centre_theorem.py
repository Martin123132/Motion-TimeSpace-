import csv
import sys
from grid_wave import HERE,PRE,TOL,np,background,gauss
from satellite import unit_scales,orbit,quadrature,MASS,RADIUS
from scipy.integrate import cumulative_simpson,simpson
from scipy.interpolate import CubicSpline


def mean_accel(rad,dist,soft,ms):
    lo=abs(dist-rad)
    hi=dist+rad
    width=2*np.minimum(dist,rad)
    integral=width-soft*np.log1p(width/(lo+soft)) if soft else width
    deriv=hi/(hi+soft)-np.sign(dist-rad)*lo/(lo+soft) if soft else 1.-np.sign(dist-rad)
    return ms*(integral/dist-deriv)/(2*rad*dist)


def radial_accel(label,model,dist):
    length,mass_unit,_=unit_scales(label)
    scaled=dist/length
    soft=RADIUS/length if model=="extended" else 0.
    source=MASS/mass_unit
    rad,weights=gauss(40.,128,(scaled,))
    profile=background(False,40.)[0](rad)
    wave,slope=profile[:2]
    dens=wave**2
    mass=weights@(rad**2*dens)
    central=source/(scaled+soft)**2
    direct=weights@(rad**2*dens*(mean_accel(rad,scaled,soft,source)-central))/mass
    if model=="point":
        other=-source/scaled**2*np.sum(weights[rad>scaled]*rad[rad>scaled]**2*dens[rad>scaled])/mass
    else:
        node,ww=quadrature(32)
        rr=rad[:,None]; lower=abs(scaled-rr); spread=2*np.minimum(scaled,rr)
        separation=lower+spread*node
        mu=1-spread*node*(separation+lower)/(2*rr*scaled)
        delta=(rr**2-2*rr*scaled*mu)/(separation+scaled)
        v=source*(delta/((separation+soft)*(scaled+soft))+rr*mu/(scaled+soft)**2)
        u1=1.5*np.sum(v*mu*ww*spread*separation/(rr*scaled),axis=1)
        other=np.dot(weights*rad**2*2*wave*slope,u1)/(3*mass)
    return direct,other


def run():
    rows=[];histories=[]
    for label in ("central_cap","illustrative"):
        length,_,timeunit=unit_scales(label)
        times=np.linspace(0.,5.,5001)
        track,dists=orbit(1)
        pos=track(times); dist=np.linalg.norm(pos,axis=1)
        knots=np.geomspace(.99*min(dists),1.01*max(dists),121)
        for model in ("extended","point"):
            samples=np.array([radial_accel(label,model,d) for d in knots])
            scale=np.max(abs(samples))
            assert np.max(abs(samples[:,0]-samples[:,1]))/max(scale,1e-300)<TOL
            assert max(samples[:,1])<1.e-14
            acc=CubicSpline(np.log(knots),samples[:,1])(np.log(dist))[:,None]*pos/dist[:,None]
            tt=times/timeunit
            final=simpson((tt[-1]-tt)[:,None]*acc,x=tt,axis=0)
            centre=(tt[:,None]*cumulative_simpson(acc,x=tt,axis=0,initial=0.)-cumulative_simpson(tt[:,None]*acc,x=tt,axis=0,initial=0.))
            assert np.linalg.norm(centre[-1]-final)/np.linalg.norm(final)<1e-8
            for which in range(0,len(times),125):
                histories.append(dict(scale=label,source=model,time_Gyr=times[which],X_kpc=centre[which,0]*length,
                                      Y_kpc=centre[which,1]*length,Z_kpc=centre[which,2]*length))
            for key in ("radial","l5","box48"):
                path=HERE/f"{key}-{label}-jet-1000-all.npz"
                if model=="extended" and path.exists():
                    with np.load(path) as pkt:
                        saved=pkt["dip"][-1,0]
                    err=np.linalg.norm(saved-final)/np.linalg.norm(final)
                else:
                    err=""
                rows.append(dict(scale=label,source=model,check_grid=key,present_relative_accel_code=np.dot(acc[-1],pos[-1]/dist[-1]),
                                 offset_pc=np.linalg.norm(final)*1000*length,X_kpc=final[0]*length,Y_kpc=final[1]*length,Z_kpc=final[2]*length,
                                 max_kernel_check=np.max(abs(samples[:,0]-samples[:,1]))/scale,field_offset_error=err,within_budget=(err<TOL if err!="" else "")))
    return rows,histories


if __name__=="__main__":
    from field_readout import write
    rows,histories=run()
    write("centre-theorem.csv",rows,sys.argv[1:]==["create"])
    write("centre-history.csv",histories,sys.argv[1:]==["create"])
    for row in rows[::3]:
        print(row)

