import sys
from field_readout import write,make_grid
from grid_wave import np,TOL
from propagate import evolve,CONFIG,apply,residual
from torque_wave import spin,momentum

PERIOD=14.
ACCEL=.002


class Uniform:
    def __init__(self,grid):
        self.grid=grid
        self.time=5/PERIOD

    def source(self,stamp):
        if not 0.<stamp<PERIOD:
            return np.zeros((len(self.grid.rad),len(self.grid.aw)))
        axis=int(stamp>=PERIOD/2)
        return -ACCEL*np.sin(2*np.pi*stamp/PERIOD)**2*self.grid.rad[:,None]*self.grid.unit[:,axis]


def checks():
    mass_rows=[]
    v=ACCEL*PERIOD/4*np.array([1.,1.,0.])
    centre=ACCEL*PERIOD**2/16*np.array([3.,1.,0.])
    for count in (32,48):
        tag=f"turn{count}"
        CONFIG[tag]=(30.,count,3,512)
        grid=make_grid(30.,count,3)
        driver=Uniform(grid)
        for kind in ("jet","finite"):
            packet=evolve(tag,"uniform",kind,1.,save=False,existing=(grid,driver))
            state=packet["raw"]
            mass=grid.mass
            rate=apply(grid.mat,state)+residual(grid,driver.source(PERIOD),kind,1.,state)
            action,_=spin(grid,state[0],rate[0])
            mom=momentum(grid,state[0],kind=="jet")
            targetL=mass*np.cross(centre,v)
            lc=packet["dip"][-1,0]
            expectedQ=mass*(np.outer(centre,centre)-np.eye(3)*np.dot(centre,centre)/3)/grid.inertia
            obs=packet["moments"][-1]
            intrinsic=obs[1] if kind=="jet" else obs[0]
            values=dict(centre_error=np.linalg.norm(lc-centre)/np.linalg.norm(centre),momentum_error=np.linalg.norm(mom/mass-v)/np.linalg.norm(v),
                        lab_spin_error=np.linalg.norm(action-targetL)/np.linalg.norm(targetL),
                        intrinsic_spin_fraction=np.linalg.norm(action-np.cross(lc,mom))/np.linalg.norm(targetL),
                        intrinsic_shape_fraction=np.linalg.norm(intrinsic)/np.linalg.norm(expectedQ),
                        displaced_Q_error=np.linalg.norm(obs[-1]-expectedQ)/np.linalg.norm(expectedQ))
            mass_rows.append(dict(count=count,kind=kind,**values,passes=max(values.values())<TOL))
        del CONFIG[tag]
    return mass_rows


if __name__=="__main__":
    rows=checks()
    write("turning-uniform-control.csv",rows,sys.argv[1:]==["create"])
    print(rows)

