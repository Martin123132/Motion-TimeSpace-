import sys
from pathlib import Path
from field_readout import data_rows,write,targets,metric
from grid_wave import HERE,np,TOL
from propagate import target
from satellite import orbit
from scipy.integrate import newton_cotes,simpson


def packet(cfg,label,kind,strength=1.,src="all"):
    with np.load(target(cfg,label,kind,strength,src),allow_pickle=False) as data:
        return data["moments"][-1],data["dip"][-1],data["mass_errors"],data["time"],data["power"],data["energy"]


def amplitude_rows(label):
    linear,centre,_,_,_,_=packet("l5",label,"jet")
    fixed=targets()[label]
    direction=orbit(1)[0](5.)
    direction/=np.linalg.norm(direction)
    previous=None
    for strength in (.0625,.125,.25,.5,1.):
        if not target("l5",label,"finite",strength,"all").exists():
            continue
        full,_,_,_,_,_=packet("l5",label,"finite",strength)
        leading=linear[0]*strength
        with_second=leading+linear[1]*strength**2
        resid1=np.linalg.norm(full[0]-leading)
        resid2=np.linalg.norm(full[0]-with_second)
        yield dict(scale=label,strength=strength,finite_axis_deg=metric(full[0],direction)[1],
                   first_order_axis_deg=metric(leading,direction)[1],second_order_axis_deg=metric(with_second,direction)[1],
                   first_error_fraction_of_full=resid1/np.linalg.norm(full[0]),second_error_fraction_of_full=resid2/np.linalg.norm(full[0]),
                   first_remainder_power=(np.log(resid1/previous[1])/np.log(strength/previous[0]) if previous else ""),
                   second_remainder_power=(np.log(resid2/previous[2])/np.log(strength/previous[0]) if previous else ""),
                   relative_error_of_derived_second_tensor=resid2/(strength**2*np.linalg.norm(linear[1])),
                   tangent_relative_to_sealed=np.linalg.norm(linear[0]-fixed)/np.linalg.norm(fixed))
        previous=strength,resid1,resid2


def compare(label,small,large,kind):
    if not target(small,label,kind,1.,"all").exists() or not target(large,label,kind,1.,"all").exists():
        return
    low,c0,*_=packet(small,label,kind);high,c1,*_=packet(large,label,kind)
    direction=orbit(1)[0](5.)
    direction/=np.linalg.norm(direction)
    signals=[("central_Q",low[0],high[0])]
    if kind=="jet":
        signals.append(("central_second_Q",low[1],high[1]))
    for observable,left,right in signals:
        err=np.linalg.norm(left-right)/np.linalg.norm(right)
        amp_l,ang_l=metric(left,direction);amp_h,ang_h=metric(right,direction)
        yield dict(scale=label,lower=small,higher=large,kind=kind,observable=observable,relative_error=err,
                   amplitude_change=abs(amp_l/amp_h-1),axis_change_degrees=abs(ang_l-ang_h),passes=err<TOL)
    err=np.linalg.norm(c0[0]-c1[0])/np.linalg.norm(c1[0])
    yield dict(scale=label,lower=small,higher=large,kind=kind,observable="centre",relative_error=err,amplitude_change="",axis_change_degrees="",passes=err<TOL)


def component_rows(label):
    for src in ("all","no_dip","quadr"):
        tensors,dip,*_=packet("l5",label,"jet",1.,src)
        allterms=packet("l5",label,"jet")[0]
        yield dict(scale=label,source=src,linear_tensor_change=np.linalg.norm(tensors[0]-allterms[0])/np.linalg.norm(allterms[0]),
                   quadratic_tensor_change=np.linalg.norm(tensors[1]-allterms[1])/np.linalg.norm(allterms[1]),
                   quadratic_recenter_change=np.linalg.norm(tensors[2]-tensors[1])/np.linalg.norm(allterms[1]),
                   first_centre_norm=np.linalg.norm(dip[0]),second_centre_norm=np.linalg.norm(dip[1]))


def work(path):
    with np.load(path,allow_pickle=False) as data:
        time,power,energy=[data[key] for key in ("time","power","energy")]
    if len(power)==0 or not energy[-1]:
        return []
    rows=[]
    for stride in (4,2,1):
        knots=time[::stride];values=power[::stride]
        for order in (2,4,8):
            assert (len(knots)-1)%order==0
            weights=newton_cotes(order,equal=1)[0]
            samples=np.array([values[idx:idx+order+1] for idx in range(0,len(knots)-1,order)])
            result=(knots[-1]-knots[0])/(len(knots)-1)*np.sum(samples@weights)
            err=abs(result/energy[-1]-1)
            rows.append(dict(packet=path.name,samples=len(knots),integration_order=order,source_work=result,energy=energy[-1],relative_gap=err,passes=err<TOL))
    return rows


def run(create):
    cases=sorted(path for path in HERE.glob("*.npz") if not path.name.startswith("level"))
    fields=[];probes=[];works=[];tests=[];amp=[];terms=[]
    for path in cases:
        label=path.stem.split("-")
        local=label[0] in ("l5","l7","l8","fast9","fast10","fine10","box48","large10","edge10","wide10") and label[3]=="1000" and label[4]=="all"
        summary,subset=data_rows(path,local)
        fields.append(summary);probes.extend(subset)
        works.extend(work(path))
    for label in ("central_cap","illustrative"):
        amp.extend(amplitude_rows(label))
        terms.extend(component_rows(label))
        for small,large in (("pilot","time"),("time","radial"),("radial","l4"),("l4","l5"),("l5","l6"),("l6","l7"),("l7","l8"),("l8","fast9"),("fast9","fast10"),("fast10","fine10"),("fine10","large10"),("large10","edge10"),("edge10","wide10"),("l5","halfstep"),("l5","rad64"),("rad64","box48")):
            for kind in ("jet","finite"):
                tests.extend(compare(label,small,large,kind))
    for name,items in (("field-response.csv",fields),("local-observables.csv",probes),("work-budgets.csv",works),
                       ("refinements.csv",tests),("amplitude-law.csv",amp),("source-channel-controls.csv",terms)):
        write(name,items,create)
    return fields,probes,tests


if __name__=="__main__":
    print([len(items) for items in run(sys.argv[1:]==["create"])])

