import sys
from functools import lru_cache
from field_readout import make_grid,write
from torque_wave import spin,momentum
from grid_wave import HERE,np,basis,spherical_jn,TOL
from window_wave import BASES
from satellite import unit_scales,orbit,YEAR,parsec
from scipy.interpolate import CubicSpline


@lru_cache(4)
def ground_shape(grid):
    radius=np.linspace(0,grid.edge,12001)
    shape=basis(0,grid.wroots[0],grid.edge,radius)@grid.coef
    return CubicSpline(radius,shape,bc_type=((1,0.),"not-a-knot"),extrapolate=False)


def occupation(grid,state,kind,centre,mass_error):
    real,imag=grid.spatial(state)[0]
    phase=real+1j*imag
    mass=grid.mass*(1+mass_error) if kind=="finite" else grid.mass
    mom=momentum(grid,state,kind=="jet")
    speed=mom/mass
    def inner(left,right):
        return grid.w@(np.broadcast_to(left.conj()*right,(len(grid.rad),len(grid.aw)))@grid.aw)
    def project(ground,wave):
        norm=inner(ground,ground).real
        common=inner(ground,wave)/norm
        ortho=wave-common*ground
        return inner(ortho,ortho).real/mass,norm
    interpolant=ground_shape(grid)
    if kind=="jet":
        displacement=interpolant(grid.rad,1)[:,None]*grid.rad[:,None]*(grid.unit@centre)
        boost=grid.ground[:,None]*grid.rad[:,None]*(grid.unit@speed)
        comoving=phase+displacement-1j*boost
        exc,_=project(grid.ground[:,None],comoving)
        lab,_=project(grid.ground[:,None],phase)
        norm=grid.mass
    else:
        axis=grid.rad[:,None]
        shifted=np.sqrt(np.maximum(0.,axis**2-2*axis*(grid.unit@centre)+centre@centre))
        moved=axis*interpolant(np.minimum(shifted,grid.edge))
        moved[shifted>grid.edge]=0.
        moving=moved*np.exp(1j*axis*(grid.unit@speed))
        full=grid.ground[:,None]+phase
        exc,norm=project(moving,full)
        lab,_=project(grid.ground[:,None],full)
    angular,_=spin(grid,state,np.zeros_like(state))
    internal=angular-np.cross(centre,mom)
    return exc,lab,abs(norm/grid.mass-1),internal


def run(create):
    rows=[]
    for path in sorted(HERE.glob("*.npz")):
        window=path.name.startswith("level")
        if window:
            with np.load(path) as data:
                if data["stop"]!=data["steps"] or data["highest"]<13:
                    continue
                label=data["label"].item();kind=data["kind"].item();cfg=data["base"].item()
                edge,count=BASES[cfg];highest=int(data["highest"]);cfg+=f"_l{highest}"
                raw=data["raw"][0];centre=data["dip"][0];masserr=data["mass_errors"][0]
                strength=float(data["strength"])
        else:
            cfg,label,kind,_,src=path.stem.split("-")
            if cfg not in ("l5","l7","box48") or kind not in ("jet","finite") or src!="all":
                continue
            with np.load(path) as data:
                edge,count,highest,_,strength=data["params"];count=int(count);highest=int(highest)
                raw=data["raw"][0];centre=data["dip"][-1,0];masserr=data["mass_errors"][-1,0]
        grid=make_grid(edge,count,highest)
        exc,lab,loss,intrinsic=occupation(grid,raw,kind,centre,masserr)
        length,massunit,tunit=unit_scales(label)
        unit=(length*1e3*parsec)**2/(tunit*1e9*YEAR)/(1000*1e3*parsec)
        track=orbit(1)[0];normal=np.cross(track(5.),track(5.,1));normal/=np.linalg.norm(normal)
        rows.append(dict(packet=path.name,scale=label,grid=cfg,kind=kind,strength=strength,
                         outside_comoving_ground_fraction=exc,outside_lab_ground_fraction=lab,comoving_mass_scale_msun=exc*grid.mass*massunit,
                         moved_basis_number_error=loss,specific_internal_spin_kpc_kms=np.linalg.norm(intrinsic)/grid.mass*unit,
                         spin_parallel_fraction=intrinsic@normal/np.linalg.norm(intrinsic)))
    write("conditional-population.csv",rows,create)
    return rows


if __name__=="__main__":
    data=run(sys.argv[1:]==["create"])
    print([(row["scale"],row["outside_comoving_ground_fraction"]) for row in data if row["grid"]=="outer72_l16"])

