import sys
from batch_wave import run as regular,check_freeze
from window_wave import advance,label_path,STEPS
from grid_wave import HERE


def campaign(label,action,base="core44",kind="finite"):
    check_freeze(False)
    if action=="small-amplitudes":
        regular(label,[("l5",kind,frac,"all") for frac in (.0625,.125)])
        return
    first=advance(base,label,kind,5,0,1152,1.)
    later=advance(base,label,kind,5,1152,1344,1.,first)
    if action=="initial":
        for start,prefix,level in ((1152,first,7),(1152,first,10),(1344,later,10),(1344,later,13)):
            advance(base,label,kind,level,start,1536,1.,prefix)
    else:
        start,level=[int(value) for value in action.split(":")]
        advance(base,label,kind,level,start,1536,1.,first if start==1152 else later)


if __name__=="__main__":
    campaign(*sys.argv[1:])

