import os
import sys
import tempfile
from pathlib import Path
from functools import lru_cache
from field_readout import make_grid,write
from grid_wave import HERE,PRIOR,np,gauss,basis,sl,harmonics,bridge,TOL
from endpoint import sky_grid
from window_wave import BASES
import window_wave
from propagate import evolve,target,remove_cm


@lru_cache(2)
def measurement(edge,count,highest):
    grid=make_grid(edge,count,highest)
    rad,weights=gauss(edge,max(48,count))
    dirs,aw=sky_grid(highest+4,2*highest+9)
    yy=harmonics(dirs,highest)
    basis_values=[rad[:,None]*basis(ell,roots,edge,rad) for ell,roots in enumerate(grid.wroots)]
    base=basis_values[0]@grid.coef
    mass=np.dot(weights,base**2)
    inertia=np.dot(weights,(rad*base)**2)
    trace=dirs[:,:,None]*dirs[:,None,:]-np.eye(3)/3
    def moment(density):
        return (weights@(density@aw),(weights*rad)@(density@(aw[:,None]*dirs)),
                np.einsum("q,qij->ij",((weights*rad**2)@density)*aw,trace))
    def field(state):
        coeff=np.empty((2,len(rad),yy.shape[1]))
        for ell,values in enumerate(basis_values):
            coeff[:,:,sl(ell)]=values@state[:,sl(ell)].reshape(2,count,-1)
        return coeff@yy.T
    return base,mass,inertia,moment,field


def independent():
    rows=[]
    for path in sorted(HERE.glob("*.npz")):
        window=path.name.startswith("level")
        with np.load(path,allow_pickle=False) as bank:
            if window:
                kind=bank["kind"].item()
                edge,count=BASES[bank["base"].item()]
                highest=int(bank["highest"])
                expected=bank["moments"];centre=bank["dip"];saved_mass=bank["mass_errors"]
            else:
                edge,count,highest,_,_=bank["params"];count=int(count);highest=int(highest)
                kind=path.stem.split("-")[2]
                expected=bank["moments"][-1];centre=bank["dip"][-1];saved_mass=bank["mass_errors"][-1]
            raw=bank["raw"]
        base,mass,inertia,moment,field=measurement(edge,count,highest)
        first=field(raw[0]);d1=2*base[:,None]*first[0]
        square=first[0]**2+first[1]**2
        mn,dip,qq=moment(d1+square if kind=="finite" else d1)
        mass_ref=(mn+mass) if kind=="finite" else mass
        intrinsic=remove_cm(qq,dip,mass_ref) if kind=="finite" else qq
        matrix=[intrinsic]
        if kind=="finite":
            matrix.append(qq)
        if kind=="jet":
            _,_,second=moment(2*base[:,None]*field(raw[1])[0]+square)
            matrix.extend((remove_cm(second,dip,mass),second))
        measured=np.array(matrix)/inertia
        err=np.linalg.norm(measured-expected)/max(1e-24,np.linalg.norm(expected))
        cerr=np.linalg.norm(dip/mass_ref-centre[0])
        nerr=abs(mn/mass-saved_mass[0])
        rows.append(dict(packet=path.name,tensor_error=err,absolute_centre_check=cerr,absolute_number_check=nerr,passes=max(err,cerr,nerr)<TOL))
    return rows


def repeat():
    rows=[]
    for label in ("central_cap","illustrative"):
        for kind in ("jet","finite"):
            cfg="radial";strength=1.
            saved=target(cfg,label,kind,strength,"all")
            fresh=evolve(cfg,label,kind,strength,save=False)
            with np.load(saved) as data:
                assert all(np.array_equal(fresh[k],data[k]) for k in fresh),saved.name
            rows.append(dict(packet=saved.name,check="all_saved_arrays_byte_values",digest=bridge.sha(saved)))
    original=window_wave.HERE
    try:
        with tempfile.TemporaryDirectory(prefix="private-replay-",dir=HERE) as temp:
            output=Path(temp)
            assert output.parent==HERE and output.name.startswith("private-replay-")
            for label in ("central_cap","illustrative"):
                previous=next(HERE.glob(f"level5-core44_{label}_finite*1152-1344*.npz"))
                window_wave.HERE=output
                result=window_wave.advance("core44",label,"finite",10,1344,1536,1.,previous)
                assert bridge.sha(result)==bridge.sha(HERE/result.name)
                rows.append(dict(packet=result.name,check="compressed_archive_byte_identical",digest=bridge.sha(result)))
    finally:
        window_wave.HERE=original
    assert not output.exists()
    return rows


if __name__=="__main__":
    create=sys.argv[1:]==["create"]
    audits=independent()
    write("independent-moments.csv",audits,create)
    assert all(row["passes"] for row in audits)
    matched=repeat()
    write("rerun-receipts.csv",matched,create)
    print("checked",len(audits),"fields and reran",len(matched),"packets")

