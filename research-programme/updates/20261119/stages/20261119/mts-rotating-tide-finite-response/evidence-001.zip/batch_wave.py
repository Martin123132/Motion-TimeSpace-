import json
import sys
import time
from propagate import CONFIG,Grid,Forcing,evolve,target
from grid_wave import HERE,PRIOR,bridge,verify_parent,guard,np

CONFIG.update({"l7":(30.,44,7,1536),"l8":(30.,44,8,1536),"halfstep":(30.,44,5,3072),
               "rad64":(30.,64,5,1536),"box48":(48.,72,5,1536),"early_quick":(30.,28,3,384)})
BATCHES={
    "weak":[("time","tangent",1.,"all"),("radial","jet",1.,"all"),("l4","jet",1.,"all"),("l5","jet",1.,"all")],
    "finite":[("radial","finite",1.,"all"),("l4","finite",1.,"all"),("l5","finite",.25,"all"),("l5","finite",.5,"all"),("l5","finite",1.,"all")],
    "angular":[("l6","jet",1.,"all"),("l6","finite",1.,"all"),("l7","jet",1.,"all"),("l7","finite",1.,"all")],
    "controls":[("radial","finite",0.,"all"),("l5","jet",1.,"quadr"),("l5","jet",1.,"no_dip"),("halfstep","finite",1.,"all"),("halfstep","jet",1.,"all")],
    "radbox":[("rad64","jet",1.,"all"),("rad64","finite",1.,"all"),("box48","jet",1.,"all"),("box48","finite",1.,"all")]
}


def check_freeze(create=False):
    verify_parent()
    initial=json.loads((HERE/"frozen.json").read_bytes())
    for name,digest in initial["digests"].items():
        file=HERE/("trial-v1/grid_wave.py" if name=="grid_wave.py" else name)
        assert bridge.sha(file)==digest
    receipt=dict(prior=PRIOR,predictions=bridge.sha(HERE/"frozen.json"),
                 working={name:bridge.sha(HERE/name) for name in ("grid_wave.py","propagate.py","batch_wave.py")})
    saved=HERE/"qualified.json"
    if create:
        with saved.open("x",encoding="utf8") as stream:
            json.dump(receipt,stream,indent=2,sort_keys=True)
    assert json.loads(saved.read_bytes())==receipt


def run(label,cases):
    check_freeze(False)
    grid=None; old=None; loaded={}
    for cfg,kind,strength,filtering in cases:
        guard()
        if target(cfg,label,kind,strength,filtering).exists():
            raise FileExistsError(target(cfg,label,kind,strength,filtering))
        params=CONFIG[cfg][:3]
        if params!=old:
            loaded={}
            grid=Grid(*params)
            old=params
        if filtering not in loaded:
            loaded[filtering]=Forcing(grid,label,filtering)
        start=time.monotonic()
        result=evolve(cfg,label,kind,strength,filtering,existing=(grid,loaded[filtering]))
        print(target(cfg,label,kind,strength,filtering).name,round(time.monotonic()-start,2),np.max(abs(result["mass_errors"]),axis=0),flush=True)


if __name__=="__main__":
    if sys.argv[1:]==["freeze"]:
        check_freeze(True)
    else:
        label=sys.argv[1]
        run(label,[item for group in sys.argv[2:] for item in BATCHES[group]])

