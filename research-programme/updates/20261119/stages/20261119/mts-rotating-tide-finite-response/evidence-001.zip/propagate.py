import argparse
import json
import time
from grid_wave import HERE,PRE,PRIOR,Grid,Forcing,guard,verify_parent,sl,np,bridge,TOL
from scipy.linalg import expm
from scipy.integrate import solve_ivp,simpson
from scipy.special import roots_legendre

CONFIG={"pilot":(30.,28,3,768),"time":(30.,28,3,1536),"radial":(30.,44,3,1536),
        "l4":(30.,44,4,1536),"l5":(30.,44,5,1536),"l6":(30.,44,6,1536)}


def apply(matrices,values):
    result=np.empty_like(values)
    for order,mat in enumerate(matrices):
        result[:,:,sl(order)]=mat@values[:,:,sl(order)]
    return result


def lagrange(nodes,points):
    polys=[]
    for node in nodes:
        val=np.ones_like(points)
        for other in nodes:
            if other!=node:
                val*=(points-other)/(node-other)
        polys.append(val)
    return np.array(polys)


def weights(grid,dt):
    nodes,weights0=roots_legendre(12)
    frac=(nodes+1)/2
    interp=lagrange([0,-1,-2,-3],frac)
    corr=lagrange([1,0,-1,-2],frac)
    whole=[];predict=[[] for _ in range(4)];correct=[[] for _ in range(4)]
    for mat in grid.mat:
        whole.append(expm(dt*mat))
        taps=np.stack([expm((1-point)*dt*mat) for point in frac])
        for idx in range(4):
            predict[idx].append(np.einsum("i,ijk->jk",dt/2*weights0*interp[idx],taps))
            correct[idx].append(np.einsum("i,ijk->jk",dt/2*weights0*corr[idx],taps))
    return whole,predict,correct


def residual(grid,source,kind,strength,state):
    ground=grid.ground[:,None]
    empty=np.zeros_like(source)
    forcing=strength*source
    if kind=="finite":
        parts,live=grid.spatial(state[0])
        nonlinear=grid.density_potential(parts[0]**2+parts[1]**2)
        field=forcing+live+nonlinear
        return grid.project((forcing+nonlinear)*ground+field*parts[0],field*parts[1])[None,...]
    first=grid.project(forcing*ground,empty)
    if kind=="tangent":
        return first[None,...]
    parts,live=grid.spatial(state[0])
    nonlinear=grid.density_potential(parts[0]**2+parts[1]**2)
    field=forcing+live
    second=grid.project(field*parts[0]+nonlinear*ground,field*parts[1])
    return np.stack((first,second))


def remove_cm(moment,dip,mass):
    return moment-(np.outer(dip,dip)-np.eye(3)*(dip@dip)/3)/mass


def read_state(grid,state,kind):
    first=grid.spatial(state[0])[0]
    linear=2*grid.ground[:,None]*first[0]
    square=first[0]**2+first[1]**2
    if kind=="finite":
        dens=linear+square
        number,dip,moment=grid.moments(dens)
        norm=grid.mass+number
        result=np.stack((remove_cm(moment,dip,norm),moment))
        return result/grid.inertia,dip[None,:]/norm,np.array([number/grid.mass]),dens
    mass1,dip1,moment1=grid.moments(linear)
    if kind=="tangent":
        return moment1[None,...]/grid.inertia,dip1[None,:]/grid.mass,np.array([mass1/grid.mass]),linear
    second=grid.spatial(state[1])[0]
    den2=2*grid.ground[:,None]*second[0]+square
    mass2,dip2,moment2=grid.moments(den2)
    return np.stack((moment1,remove_cm(moment2,dip1,grid.mass),moment2))/grid.inertia,np.stack((dip1,dip2))/grid.mass,np.array([mass1,mass2])/grid.mass,den2


def energy(grid,delta,density):
    total=0.
    for order,mat in enumerate(grid.mat):
        for fields in delta.reshape(2,grid.count,-1):
            values=fields[:,sl(order)]
            total+=np.sum(values*(mat[:grid.count,grid.count:]@values))
    induced=grid.density_potential(density)
    return total+.5*grid.w@((density*induced)@grid.aw)


def target(cfg,label,kind,strength,filtering):
    return HERE/f"{cfg}-{label}-{kind}-{round(1000*strength):04d}-{filtering}.npz"


def evolve(cfg,label,kind,strength,filtering="all",save=True,existing=None):
    guard()
    path=target(cfg,label,kind,strength,filtering)
    if save and (path.exists() or path.with_suffix(".partial").exists()):
        raise FileExistsError(path)
    edge,count,lmax,steps=CONFIG[cfg]
    grid,driver=(Grid(edge,count,lmax),None) if existing is None else existing
    driver=Forcing(grid,label,filtering) if driver is None else driver
    dt=5/driver.time/steps
    whole,predict,correct=weights(grid,dt)
    size=2 if kind=="jet" else 1
    values=np.zeros((size,2*count,grid.nh))
    def rhs(stamp,flat):
        field=flat.reshape(values.shape)
        return (apply(grid.mat,field)+residual(grid,driver.source(stamp),kind,strength,field)).ravel()
    active=strength!=0.
    if active:
        first=solve_ivp(rhs,(0.,3*dt),values.ravel(),t_eval=dt*np.arange(4),method="DOP853",rtol=1e-10,atol=2e-15)
        assert first.success
        states=first.y.T.copy().reshape(4,*values.shape)
    else:
        states=np.zeros((4,*values.shape))
    hist=[];moments=[];positions=[];number=[];clocks=[];powers=[];energies=[]
    for step in range(steps+1):
        stamp=dt*step
        source=driver.source(stamp)
        if step<4:
            values=states[step]
            hist.insert(0,residual(grid,source,kind,strength,values))
        else:
            drift=apply(whole,values)
            estimate=drift.copy()
            for mats,sample in zip(predict,hist):
                estimate+=apply(mats,sample)
            future=residual(grid,source,kind,strength,estimate)
            values=drift.copy()
            for mats,sample in zip(correct,[future]+hist[:3]):
                values+=apply(mats,sample)
            hist=[residual(grid,source,kind,strength,values)]+hist[:3]
        if step%max(1,steps//256)==0 or step==steps:
            if not np.isfinite(values).all():
                raise ArithmeticError((cfg,label,kind,step,"nonfinite"))
            signal,dip,mass,density=read_state(grid,values,kind)
            moments.append(signal);positions.append(dip);number.append(mass);clocks.append(stamp)
            if kind=="finite":
                width=min(.00001,dt/8)
                left=max(0.,stamp-width)
                right=min(5/driver.time,stamp+width)
                deriv=(driver.source(right)-driver.source(left))/(right-left)
                powers.append(strength*(grid.w@((deriv*density)@grid.aw)))
                energies.append(energy(grid,values[0],density)+strength*(grid.w@((source*density)@grid.aw)))
        if step%64==0:
            guard()
    result=dict(raw=values,moments=np.array(moments),dip=np.array(positions),mass_errors=np.array(number),time=np.array(clocks),
                power=np.array(powers),energy=np.array(energies),params=np.array([edge,count,lmax,steps,strength]),
                parent_sha=np.bytes_(PRIOR),inertia=np.array(grid.inertia),number=np.array(grid.mass))
    if save:
        bridge.archive(path,**result)
    return result


if __name__=="__main__":
    parser=argparse.ArgumentParser()
    for key in ("cfg","label","kind"):
        parser.add_argument(key)
    parser.add_argument("strength",type=float,nargs="?",default=1.)
    parser.add_argument("filtering",nargs="?",default="all")
    args=parser.parse_args()
    assert args.kind in ("finite","jet","tangent") and args.label in ("central_cap","illustrative")
    begin=time.monotonic()
    packet=evolve(**vars(args))
    print(args,"seconds",round(time.monotonic()-begin,2),"number errors",np.max(abs(packet["mass_errors"]),axis=0),"last tensor",packet["moments"][-1].tolist())

