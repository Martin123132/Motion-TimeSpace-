import sys
from field_readout import write
from centre_theorem import mean_accel
from grid_wave import np,gauss,background,TOL
from satellite import unit_scales,orbit,MASS,RADIUS


def evaluate(label,epoch,shrink):
    length,mu,timeunit=unit_scales(label)
    dist=np.linalg.norm(orbit(1)[0](epoch))/length
    soft=RADIUS/length
    src=MASS/mu
    ground=background(False,40.)[0]
    grid,ww=gauss(40.,150,(dist/shrink,))
    shell=grid*shrink
    weight=ww*(grid*ground(grid)[0])**2
    weight/=weight.sum()
    inside=shell<dist
    tail=np.sum(weight[~inside])
    central=src/(dist+soft)**2
    direct=(central-mean_accel(shell,dist,soft,src))/central
    measured=weight@direct
    exact_out=weight[~inside]@direct[~inside]
    coord=(shell[inside]/(dist+soft))**2
    scale=src*soft/(dist*(dist+soft))/central
    partial=np.zeros_like(coord)
    for order in range(33):
        if order>0:
            partial+=scale*coord**order*(1/((2*order+1)*dist)+1/(dist+soft))
        if order not in (0,1,2,4,8,16,32):
            continue
        remainder=scale*coord**(order+1)/(1-coord)*(1/((2*order+3)*dist)+1/(dist+soft))
        low=weight[inside]@partial
        prior_width=weight[inside]@remainder
        epsilon=5e-12
        assert low-epsilon<=measured<=low+prior_width+tail+epsilon
        assert low+exact_out-epsilon<=measured<=low+exact_out+prior_width+epsilon
        predicted=soft*(4*dist+soft)*(weight@(shell**2))/(3*dist**2*(dist+soft)**2)
        yield dict(scale=label,archive_Gyr=epoch,probe_length_factor=shrink,series_order=order,exact_fractional_deficit=measured,
                   compact_quadratic_term=predicted,exact_over_quadratic=measured/predicted,
                   inside_partial=low,inside_remainder_bound=prior_width,wave_outside_fraction=tail,
                   exact_outer_deficit=exact_out,upper_with_unknown_outer=low+prior_width+tail,upper_with_exact_outer=low+prior_width+exact_out,
                   lower_with_exact_outer=low+exact_out)


def run(create):
    rows=[]
    for label in ("central_cap","illustrative"):
        for epoch in (0.,2.5,4.,4.75,5.):
            for shrink in ((1.,.5,.25,.125,.0625) if epoch==5. else (1.,)):
                rows.extend(evaluate(label,epoch,shrink))
    write("finite-size-limit.csv",rows,create)
    return rows


if __name__=="__main__":
    for row in run(sys.argv[1:]==["create"]):
        if row["archive_Gyr"]==5. and row["probe_length_factor"]==1. and row["series_order"]==2:
            print(row)

