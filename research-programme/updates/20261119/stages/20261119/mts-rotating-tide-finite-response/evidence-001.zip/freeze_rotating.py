import json
import sys
from grid_wave import HERE,PRE,PRIOR,bridge,verify_parent
from tidal_crosschecks import matrix_reference


def freeze(create=False):
    verify_parent()
    files=["PROTOCOL.md","grid_wave.py","propagate.py","freeze_rotating.py"]
    result=dict(parent_seal=PRIOR,targets={label:matrix_reference(label,"edge96",filename="lmc-extended-tensors.csv").tolist() for label in ("illustrative","central_cap")},
                digests={name:bridge.sha(HERE/name) for name in files},numerical_tolerance=2.e-5)
    target=HERE/"frozen.json"
    if create:
        with target.open("x",encoding="utf8") as handle:
            json.dump(result,handle,indent=2,sort_keys=True)
    assert json.loads(target.read_bytes())==result
    return result


if __name__=="__main__":
    print(freeze(sys.argv[1:]==["create"]))

