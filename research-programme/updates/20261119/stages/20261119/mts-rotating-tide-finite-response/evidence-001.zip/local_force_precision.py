import sys
from field_readout import make_grid,write,green_force,vector_field
from grid_wave import HERE,np,sl,basis,harmonics,gauss,TOL
from field_evolution import root_values
from window_wave import BASES
from satellite import unit_scales,YEAR,parsec


def run(create):
    rows=[]
    for label in ("central_cap","illustrative"):
        path=next(HERE.glob(f"level16-outer72_{label}_finite*1344-1536*.npz"))
        with np.load(path) as packet:
            edge,count=BASES[packet["base"].item()];highest=int(packet["highest"]);raw=packet["raw"]
        grid=make_grid(edge,count,highest)
        length,_,tunit=unit_scales(label)
        accel=length*1000*parsec/(tunit*1e9*YEAR)**2
        rad,weights=gauss(edge,112)
        coeff=np.empty((len(rad),grid.nh),complex)
        for ell,roots in enumerate(grid.wroots):
            section=sl(ell)
            coeff[:,section]=rad[:,None]*(basis(ell,roots,edge,rad)@(raw[0,:count,section]+1j*raw[0,count:,section]))
        wave=coeff@grid.Y[:,:grid.nh].T
        ground=rad*(basis(0,grid.wroots[0],edge,rad)@grid.coef)
        den=(2*ground[:,None]*wave.real+abs(wave)**2)@grid.Yw
        direction=np.array([-1.,0.,0.])
        references={site:green_force(grid,raw,"finite",site/length,direction) for site in (8.1,17.58)}
        for extra in (12,48,96):
            levels=[]
            for ell in range(2*highest+1):
                roots=root_values(ell-1,count+extra)
                source=-((edge/roots)**2)[:,None]*(basis(ell,roots,edge,rad).T@(weights[:,None]*den[:,sl(ell)]))
                levels.append((roots,source))
            def potential(xyz):
                rr=np.linalg.norm(xyz,axis=1)
                sky=harmonics(xyz/rr[:,None],2*highest)
                return sum(np.sum((basis(ell,root,edge,rr)@field)*sky[:,sl(ell)],axis=1) for ell,(root,field) in enumerate(levels))
            for site,value in references.items():
                force=vector_field(potential,site/length*direction,4e-5)
                err=np.linalg.norm(force-value)/np.linalg.norm(value)
                rows.append(dict(scale=label,solar_line_kpc=site,vacuum_modes_per_l=count+extra,
                                 fixed_all_induced_ms2=np.linalg.norm(force)*accel,split_green_ms2=np.linalg.norm(value)*accel,relative_force_error=err,passes=err<TOL))
    write("local-force-precision.csv",rows,create)
    return rows


if __name__=="__main__":
    for row in run(sys.argv[1:]==["create"]):
        print(row)

