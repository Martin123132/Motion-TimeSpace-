import sys
import time
from angular_fast import Separable
from batch_wave import check_freeze,CONFIG
from propagate import residual,apply,weights,read_state,energy,solve_ivp
from grid_wave import HERE,PRIOR,Grid,Forcing,guard,bridge,np

BASES={"core44":(30.,44),"core64":(30.,64),"outer72":(48.,72)}
STEPS=1536


def label_path(base,label,kind,highest,start,stop,strength,gap0,steps):
    chain=f"from{gap0.name.split('_')[0]}" if gap0 else "rest"
    return HERE/f"level{highest}-{base}_{label}_{kind}_s{round(strength*1000)}_{start}-{stop}_{chain}_n{steps}.npz"


def advance(base,label,kind,highest,start,stop,strength,previous=None,steps=STEPS):
    guard()
    tic=time.monotonic()
    path=label_path(base,label,kind,highest,start,stop,strength,previous,steps)
    edge,count=BASES[base]
    if path.exists():
        wanted=bridge.sha(previous) if previous is not None else PRIOR
        with np.load(path,allow_pickle=False) as packet:
            assert packet["parent"].item()==wanted and np.isfinite(packet["raw"]).all()
            assert tuple(packet[key].item() for key in ("base","label","kind","highest","start","stop","steps","strength"))==(base,label,kind,highest,start,stop,steps,strength)
        return path
    grid=Separable(edge,count,highest)
    angular_err=grid.qualify()
    driver=Forcing(grid,label,"all")
    dt=5/(driver.time*steps)
    whole,pred,corr=weights(grid,dt)
    nfield=2 if kind=="jet" else 1
    state=np.zeros((nfield,2*count,grid.nh))
    parent_digest=PRIOR
    if previous is not None:
        with np.load(previous,allow_pickle=False) as packet:
            assert packet["label"].item()==label and packet["kind"].item()==kind
            assert int(packet["stop"])*steps==start*int(packet["steps"])
            assert packet["base"].item()==base and packet["strength"]==strength
            raw=packet["raw"]
            assert raw.shape[:2]==state.shape[:2] and raw.shape[2]<=state.shape[2]
            state[:,:,:raw.shape[2]]=raw
        parent_digest=bridge.sha(previous)
    else:
        assert not start
    assert not path.with_suffix(".partial").exists()
    def rhs(offset,flat):
        values=flat.reshape(state.shape)
        return (apply(grid.mat,values)+residual(grid,driver.source(start*dt+offset),kind,strength,values)).ravel()
    starter=solve_ivp(rhs,(0.,3*dt),state.ravel(),t_eval=dt*np.arange(4),method="DOP853",rtol=3e-10,atol=3e-15)
    assert starter.success
    states=starter.y.T.copy().reshape(4,*state.shape)
    past=[]
    for idx in range(4):
        state=states[idx]
        past.insert(0,residual(grid,driver.source((start+idx)*dt),kind,strength,state))
    for idx in range(start+4,stop+1):
        if idx%32==0:
            guard()
        source=driver.source(idx*dt)
        drift=apply(whole,state)
        estimated=drift.copy()
        for matrices,forcing in zip(pred,past):
            estimated+=apply(matrices,forcing)
        endpoint=residual(grid,source,kind,strength,estimated)
        state=drift.copy()
        for matrices,forcing in zip(corr,[endpoint]+past[:3]):
            state+=apply(matrices,forcing)
        past=[residual(grid,source,kind,strength,state)]+past[:3]
    moment,dip,mass,density=read_state(grid,state,kind)
    assert np.isfinite(state).all() and np.max(abs(mass))<2e-5
    source=driver.source(stop*dt)
    stored=energy(grid,state[0],density)+strength*(grid.w@((source*density)@grid.aw)) if kind=="finite" else 0.
    bridge.archive(path,raw=state,moments=moment,dip=dip,mass_errors=mass,number=grid.mass,inertia=grid.inertia,
                   energy=stored,base=np.str_(base),label=np.str_(label),kind=np.str_(kind),start=start,stop=stop,
                   steps=steps,strength=strength,parent=np.str_(parent_digest),highest=highest,angular_error=angular_err)
    print(path.name,round(time.monotonic()-tic,2),"sec",flush=True)
    return path


if __name__=="__main__":
    check_freeze(False)
    base,label,kind,level,start,end,amp,prior=sys.argv[1:9]
    advance(base,label,kind,int(level),int(start),int(end),float(amp),None if prior=="rest" else HERE/prior)

