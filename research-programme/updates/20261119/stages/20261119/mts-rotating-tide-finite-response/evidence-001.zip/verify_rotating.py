import csv
import json
import sys
from pathlib import Path
from batch_wave import check_freeze
from grid_wave import HERE,PRE,PRIOR,bridge,np,TOL
from satellite import orbit
from curvature_force import run as force
from finite_size_limit import run as limit
from field_readout import write
from balance_identities import checks
from centre_theorem import run as centre
from replay_fields import independent


def rows(name):
    with (HERE/name).open(encoding="utf8",newline="") as handle:
        out=list(csv.DictReader(handle))
    assert out and all(None not in row and all(item is not None for item in row.values()) for row in out),name
    return out


def verify(deep=False):
    check_freeze(False)
    assert not list(HERE.rglob("__pycache__")) and not list(HERE.rglob("*.partial")) and not list(HERE.glob("private-replay-*"))
    for path in HERE.rglob("*.py"):
        compile(path.read_bytes(),path.name,"exec")
    files=sorted(HERE.glob("*.npz"))
    assert len(files)==71
    packets={bridge.sha(path):path for path in files}
    assert len(packets)==len(files)
    norm_checks={row["packet"]:row for row in rows("independent-moments.csv")}
    assert len(norm_checks)==len(files)
    for path in files:
        with np.load(path,allow_pickle=False) as p:
            assert np.isfinite(p["raw"]).all() and max(abs(p["mass_errors"].ravel()))<TOL
            assert norm_checks[path.name]["passes"]=="True"
            if path.name.startswith("level"):
                assert p["angular_error"]<1e-12
                parent=p["parent"].item()
                if p["start"]:
                    assert parent in packets
                    with np.load(packets[parent],allow_pickle=False) as previous:
                        assert previous["stop"]==p["start"] and previous["highest"]<=p["highest"] and previous["label"]==p["label"]
                        assert previous["strength"]==p["strength"] and previous["steps"]==p["steps"] and previous["base"]==p["base"] and previous["kind"]==p["kind"]
                else:
                    assert parent==PRIOR
            else:
                assert p["parent_sha"].item().decode()==PRIOR
                assert p["time"][0]==0 and np.all(np.diff(p["time"])>0)
                if p["params"][-1]==0:
                    assert not p["raw"].any() and not p["moments"].any() and not p["energy"].any()
    replays=rows("rerun-receipts.csv")
    assert len(replays)==6 and all(bridge.sha(HERE/row["packet"])==row["digest"] for row in replays)
    subs=rows("field-response.csv")
    assert len(subs)==49
    for label in ("central_cap","illustrative"):
        tangent=next(row for row in subs if row["grid"]=="l5" and row["kind"]=="jet" and row["source"]=="all" and row["scale"]==label)
        assert float(tangent["tensor_change_per_unit_linear_norm"])<TOL
        small=[row for row in rows("amplitude-law.csv") if row["scale"]==label]
        assert [float(row["strength"]) for row in small]==[.0625,.125,.25,.5,1.]
        assert all(float(row["second_error_fraction_of_full"])<float(row["first_error_fraction_of_full"]) for row in small)
        assert 2.9<float(small[1]["second_remainder_power"])<3.1
    windows=rows("window-tests.csv")
    assert {row["label"] for row in windows if row["test"]=="radial_30_to_48" and row["passes"]=="True"}=={"illustrative","central_cap"}
    assert any(row["label"]=="illustrative" and row["test"]=="ell_19_to_22" and row["passes"]=="True" for row in windows)
    assert any(row["label"]=="central_cap" and row["test"]=="ell_13_to_16" and row["passes"]=="True" for row in windows)
    assert all(row["passes"]=="True" for row in windows if "extension" in row["test"])
    for row in rows("turning-uniform-control.csv"):
        assert (row["passes"]=="True")==(row["count"]=="48")
    work=rows("work-budgets.csv")
    best=[row for row in work if row["samples"]=="257" and row["integration_order"]=="8"]
    assert len(best)==24 and all(row["passes"]=="True" for row in best)
    assert any(row["passes"]=="False" for row in work)
    assert all(row["passes"]=="True" for row in rows("balance-identities.csv")+rows("torque-balance.csv"))
    assert all(row["within_budget"]=="True" for row in rows("centre-theorem.csv") if row["source"]=="extended")
    fields=rows("local-force-precision.csv")
    assert all(row["passes"]=="True" for row in fields if int(row["vacuum_modes_per_l"])>84)
    assert any(row["passes"]=="False" for row in fields)
    for row in rows("finite-size-limit.csv"):
        exact=float(row["exact_fractional_deficit"])
        assert float(row["inside_partial"])-5e-12<=exact<=float(row["upper_with_unknown_outer"])+5e-12
    for row in rows("curvature-force.csv"):
        assert float(row["derivative_step_error"])<TOL
    occupations=rows("conditional-population.csv")
    assert all(0<float(row["outside_comoving_ground_fraction"])<1 for row in occupations)
    assert max(float(row["moved_basis_number_error"]) for row in occupations)<TOL
    if deep:
        write("independent-moments.csv",independent(),False)
        write("balance-identities.csv",checks(),False)
        tracks,vectors=centre()
        write("centre-theorem.csv",tracks,False);write("centre-history.csv",vectors,False)
        force(False);limit(False)
    counts={path.name:len(rows(path.name)) for path in sorted(HERE.glob("*.csv"))}
    return dict(prior=PRIOR,tolerance=TOL,packets=len(files),table_rows=counts,
                files={path.relative_to(HERE).as_posix():bridge.sha(path) for path in sorted(HERE.rglob("*")) if path.is_file() and path!=HERE/"seal.json"})


if __name__=="__main__":
    args=sys.argv[1:]
    assert args in ([],["deep"],["seal"])
    result=verify(bool(args))
    seal=HERE/"seal.json"
    if args==["seal"]:
        with seal.open("x",encoding="utf8") as handle:
            json.dump(result,handle,indent=2,sort_keys=True)
    assert result==json.loads(seal.read_bytes())
    print("verified",result["packets"],"state archives",len(result["files"]),"files",sum(result["table_rows"].values()),"derived rows;",bridge.sha(seal))

