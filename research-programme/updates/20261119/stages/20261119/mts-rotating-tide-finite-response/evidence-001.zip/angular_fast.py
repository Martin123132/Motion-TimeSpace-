from grid_wave import Grid,np,sl
from scipy.fft import rfft,irfft


class Separable(Grid):
    def __init__(self,edge,count,lmax):
        super().__init__(edge,count,lmax)
        self.nmu=2*lmax+2
        self.naz=4*lmax+3
        polar=(self.Y.reshape(self.nmu,self.naz,-1)[:,0,:])
        self.angle_groups={}
        for limit in (lmax,2*lmax):
            group=[]
            for az in range(limit+1):
                indices=np.array([order**2+(2*az-1 if az else 0) for order in range(az,limit+1)])
                pval=np.ascontiguousarray(polar[:,indices])
                pw=np.ascontiguousarray(pval*(self.aw.reshape(self.nmu,self.naz).sum(axis=1)[:,None]))
                group.append((indices,pval,pw))
            self.angle_groups[limit]=group

    def synth(self,fields,limit):
        spectra=np.zeros((*fields.shape[:-1],self.nmu,self.naz//2+1),dtype=complex)
        for az,(idx,pol,_) in enumerate(self.angle_groups[limit]):
            real=fields[...,idx]@pol.T
            if az:
                imag=fields[...,idx+1]@pol.T
                spectra[...,az]=.5*(real-1j*imag)
            else:
                spectra[...,az]=real
        return irfft(spectra,n=self.naz,axis=-1,norm="forward",workers=1).reshape(*fields.shape[:-1],-1)

    def analyze(self,space,limit):
        modes=rfft(space.reshape(*space.shape[:-1],self.nmu,self.naz),axis=-1,norm="forward",workers=1)
        fields=np.empty((*space.shape[:-1],(limit+1)**2))
        for az,(idx,_,pw) in enumerate(self.angle_groups[limit]):
            fields[...,idx]=modes[...,az].real@pw
            if az:
                fields[...,idx+1]=-modes[...,az].imag@pw
        return fields

    def spatial(self,state):
        parts=np.empty((3,len(self.rad),self.nh))
        for order,radial in enumerate(self.radial):
            section=sl(order)
            parts[:2,:,section]=radial@state[:,section].reshape(2,self.count,-1)
            parts[2,:,section]=self.gravlin[order]@state[:self.count,section]
        values=self.synth(parts,self.lmax)
        return values[:2],values[2]

    def density_potential(self,density):
        fields=self.analyze(density,2*self.lmax)
        for order,vac in enumerate(self.vac):
            section=sl(order)
            fields[:,section]=vac@(self.proj[order]@fields[:,section])
        return self.synth(fields,2*self.lmax)

    def project(self,real,imag):
        source=self.analyze(np.stack((imag,-real)),self.lmax)
        result=np.empty((2,self.count,self.nh))
        for order,radial in enumerate(self.radial):
            section=sl(order)
            result[:,:,section]=(radial.T*self.w)@source[:,:,section]
        return result.reshape(2*self.count,self.nh)

    def qualify(self):
        rng=np.random.default_rng(879930)
        checks=[]
        for limit in self.angle_groups:
            test=rng.normal(size=(7,(limit+1)**2))
            wave=self.synth(test,limit)
            truth=test@self.Y[:,:test.shape[-1]].T
            checks.append(np.linalg.norm(wave-truth)/np.linalg.norm(truth))
            checks.append(np.linalg.norm(self.analyze(truth,limit)-test)/np.linalg.norm(test))
        state=rng.normal(size=(2*self.count,self.nh))
        for left,right in zip(self.spatial(state),super().spatial(state)):
            checks.append(np.linalg.norm(left-right)/np.linalg.norm(right))
        sky=rng.normal(size=(len(self.rad),len(self.aw)))
        for left,right in ((self.density_potential(sky),super().density_potential(sky)),(self.project(sky,sky),super().project(sky,sky))):
            checks.append(np.linalg.norm(left-right)/np.linalg.norm(right))
        assert max(checks)<1e-12,checks
        return max(checks)

