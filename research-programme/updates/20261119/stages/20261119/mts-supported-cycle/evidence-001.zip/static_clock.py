import sys
from cycle import np, PHASES, LOCATIONS, EMISSIONS, TOL
from occupation_test import inputs, integral
from evaluate import load, save, peak


def controls():
    _,metric,_,_,_,depth=inputs()
    from support import system
    from cycle import FRACTION
    sol,_=system(FRACTION)
    for site,radius in LOCATIONS.items():
        def geodesic(rad):
            mass=FRACTION*(sol(rad)[0]+FRACTION*sol(rad)[1])
            return np.expm1(-FRACTION*sol(rad)[3]-.5*np.log1p(-2*mass/rad))
        delta=integral(geodesic,radius,radius+.5,36)
        nl=FRACTION*sol(radius)[3]
        nr=FRACTION*sol(radius+.5)[3]
        out=np.expm1(nl-nr)
        single=np.expm1(nr-nl)*EMISSIONS+.5*np.expm1(nr)+np.exp(nr)*delta
        echo=np.expm1(nl)+2*np.exp(nl)*delta
        for phase in PHASES:
            waves=load("target",phase,256)[site+"_64_3"][:,1]
            errors=[peak(waves[0]-out)/peak(out),peak(waves[1])/peak(out),
                    peak(waves[2]-single)/peak(single),peak(waves[3]-echo)/peak(echo)]
            yield dict(phase=phase,site=site,frequency=errors[0],closed_echo_over_one_way_frequency=errors[1],
                       one_way_delay=errors[2],echo_delay=errors[3],worst=max(errors),passes=max(errors)<=TOL)


if __name__=="__main__":
    print(save("ordinary-clock.csv",controls(),sys.argv[1]=="create"))
