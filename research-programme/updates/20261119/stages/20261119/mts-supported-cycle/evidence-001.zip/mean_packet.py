import sys
from scipy.interpolate import PPoly
from scipy.special import betainc
from cycle import np, bridge, HOME, weights, FRACTION
from bound_state import solve_edge, SCALE, RHO, inputs, LENGTH, RC
from evaluate import save
from scipy.constants import c


def bank(create):
    reports=[]
    _,_,potential,_,rest,_=inputs()
    for baryons in (False,True):
        report,_,profile=solve_edge(30.,531,baryons,True)
        dest=HOME/("bound-ordinary.npz" if baryons else "bound-isolated.npz")
        if create:
            if dest.exists():
                raise FileExistsError(dest)
            bridge.archive(dest,x=profile.x,coeff=profile.c,scale=SCALE,rho=RHO,
                           energy=report["energy_over_rest"],receipt=np.bytes_(bridge.sha(HOME/"self-bound-controls.csv")))
        data=bridge.read(dest)
        assert data["receipt"].item().decode()==bridge.sha(HOME/"self-bound-controls.csv")
        assert np.array_equal(data["coeff"],profile.c) and np.array_equal(data["x"],profile.x)
        spline=PPoly(data["coeff"],data["x"],extrapolate=False)
        for radius in (.75,2.,3.,4.,5.,6.,6.5,12.):
            scaled=radius/SCALE
            amp,slope,pot,grad=spline(scaled)
            carrier=np.sqrt(2*RHO/weights())*amp
            carrier_prime=np.sqrt(2*RHO/weights())*slope/SCALE
            mass=scaled**2*grad/SCALE+rest*baryons*betainc(1.5,7.,min((radius/RC)**2,1.))
            nu=pot/SCALE**2+baryons*potential(np.array([radius]))[0]
            factor=1-2*mass/radius
            relative=np.expm1(2*(np.log1p(report["energy_over_rest"])-nu))
            press=weights()/4*(relative*carrier**2+factor*carrier_prime**2)
            correction=press
            rho=RHO*amp**2
            v2=(mass/radius+radius**2*press)/factor
            reports.append(dict(baryons=baryons,r=radius,normalized_real_field=carrier,normalized_field_slope=carrier_prime,
                    mean_mass_function=mass,log_lapse_newton=nu,omega_at_infinity=1+report["energy_over_rest"],
                    weak_field_density_correction_over_rest=correction/rho,mean_radial_pressure_over_rest=press/rho,
                    circular_speed_with_pressure_km_s=c*np.sqrt(v2)/1000,
                    nominal_pressure_period_in_local_time=np.pi*np.exp(nu)/(1+report["energy_over_rest"])))
    return save("bound-to-real-launch.csv",reports,create)


if __name__=="__main__":
    bank(sys.argv[1]=="create")
