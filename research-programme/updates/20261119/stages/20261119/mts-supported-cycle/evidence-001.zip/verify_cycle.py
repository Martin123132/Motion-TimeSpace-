import sys
import json
import csv
from cycle import HOME, PRE, SEAL, PHASES, TOL, np, bridge, lock, stamp
sys.path.insert(0,str(HOME))
from evaluate import budgets, currents, mechanics, save, load
from observables import cycles, calendar, jacobians, repair
from occupation_test import bounds, spectral
from bound_state import experiment
from mean_packet import bank
from coarse_bridge import check as grid_bridge
from source_scale import scale
from static_clock import controls


def verify():
    for phase in PHASES:
        lock(phase)
    predecessor=json.loads((PRE/"seal.json").read_bytes())
    assert all(bridge.sha(PRE/name)==digest for name,digest in predecessor["files"].items())
    earlier=PRE.parent/"mts-mixed-clock-transport-20261119"
    assert bridge.sha(earlier/"seal.json")==predecessor["parent"]
    old=json.loads((earlier/"seal.json").read_bytes())
    assert all(bridge.sha(earlier/name)==digest for name,digest in old["files"].items())
    assert all(bridge.sha(HOME.parent/name)==digest for name,digest in old["external"].items())
    for mode in ("target","prediction"):
        for phase in PHASES:
            for mesh in (128,256):
                data=load(mode,phase,mesh)
                assert all(np.all(np.isfinite(arr)) for arr in data.values() if arr.dtype.kind in "fic")
                assert data["diag"].shape==(451,11,4,6)
                assert not np.any(data["diag"][:,[0,1,2,3,4,5,6,7,10],:2])
    for name,fn in (("timing.csv",budgets),("flux.csv",currents),("mechanics.csv",mechanics),
                    ("calendar.csv",calendar),("pressure-cycles.csv",cycles),("clock-identity.csv",jacobians),
                    ("tube-energy.csv",repair),("stationary-source.csv",spectral),("occupation-bounds.csv",bounds),
                    ("source-scale.csv",scale),("independent-mesh-bridge.csv",grid_bridge),("ordinary-clock.csv",controls)):
        rows=save(name,fn(),False)
        fails=[row for row in rows if "passes" in row and not row["passes"]]
        if name=="flux.csv":
            assert [(r["phase"],r["r"],r["axis"]) for r in fails]==[("turn",.75,2)]
        else:
            assert not fails,name
        if name=="stationary-source.csv":
            assert all(row["omega2_minus_rest2"]>0 and row["quadrature_over_offset"]<TOL for row in rows)
        if name=="pressure-cycles.csv":
            assert all(row["coordinate_velocity_increment_m_s"]<0 for row in rows)
        if name=="occupation-bounds.csv":
            row=rows[0]
            assert row["minimum_escape_km_s"]>700*row["baryon_escape_km_s"] and row["min_isolated_self_grav_ratio"]>9000
        if name=="independent-mesh-bridge.csv":
            assert all(row["raw_mismatch"]>TOL and row["extrapolated_mismatch"]<TOL for row in rows)
    assert all(row["passes"] for row in experiment(False))
    bank(False)
    for phase in PHASES:
        receipt=bridge.read(HOME/f"tubes-{phase}.npz")
        assert np.max(receipt["invariants"][:,1:])<TOL
    counts={}
    for path in HOME.glob("*.csv"):
        with path.open(newline="") as stream:
            records=list(csv.DictReader(stream))
            assert records and all(None not in row and None not in row.values() for row in records)
            counts[path.name]=len(records)
    assert len(counts)==15 and sum(counts.values())>200
    assert not any(path.is_dir() or path.suffix in (".pyc",".tmp") for path in HOME.iterdir())
    files={path.name:bridge.sha(path) for path in sorted(HOME.iterdir()) if path.is_file() and path.name!="seal.json"}
    source=HOME.parent/"MTS-HEAVY-BATH-COUNTERFLOW-AND-GALACTIC-STRESS.md"
    return dict(parent=SEAL,verified_parent=len(predecessor["files"]),earlier=len(old["files"]),external=len(old["external"]),
                retained_action=bridge.sha(source),rows=counts,files=files)


if __name__=="__main__":
    full=verify()
    stamp("seal.json",full,sys.argv[1:]==["seal"])
    print("verified",len(full["files"]),"files",sum(full["rows"].values()),"rows",bridge.sha(HOME/"seal.json"))
