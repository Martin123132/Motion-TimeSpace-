import sys
from functools import lru_cache
from numpy.polynomial.legendre import leggauss
from cycle import np, weights, FRACTION, TOL, HOME
from support import system
from source import background
from evaluate import save, SEC
from scipy.special import betainc
from scipy.optimize import brentq
from scipy.constants import c,G,parsec,electron_volt

MSUN=1.98847e30
LENGTH=SEC*c
KG=LENGTH*c**2/G
RC=5.
GEVDENS=1e15*electron_volt/c**2


def integral(func,low,high,order):
    points,wt=leggauss(order)
    return (high-low)/2*np.dot(wt,func((low+high)/2+(high-low)/2*points))


@lru_cache(None)
def inputs():
    sol,field=system(FRACTION)
    central,_=background("massive")
    end=sol(12.)
    mass=FRACTION*(end[0]+FRACTION*end[1])
    ni=.5*np.log1p(-2*mass/12)-FRACTION*end[3]
    rest=FRACTION*end[0]
    def metric(radius):
        raw=sol(radius)
        fac=1-2*FRACTION*(raw[0]+FRACTION*raw[1])/radius
        nu=ni+FRACTION*raw[3]
        return nu,fac
    def potential(radius):
        compact=np.minimum((radius/RC)**2,1.)
        return -rest*betainc(1.5,7.,compact)/radius-FRACTION*central*RC**2/14*(1-compact)**7
    return field,metric,potential,mass,rest,FRACTION*central*RC**2/14


def spectral():
    field,metric,phi,_,_,_=inputs()
    for low,high in ((0.,.75),(.75,2.),(2.,3.),(3.,4.),(4.,5.),(5.,6.5)):
        def radial_flux(radius):
            if not radius:
                return 0.
            nu,fac=metric(radius)
            return radius**2*np.exp(nu)*np.sqrt(fac)*field(radius,1)
        def estimate(order):
            avgphase=lambda rad:rad**2*field(rad)*np.exp(-metric(rad)[0])/np.sqrt(metric(rad)[1])
            shift=lambda rad:avgphase(rad)*np.expm1(2*metric(rad)[0])
            gr=(integral(shift,low,high,order)-radial_flux(high)+radial_flux(low))/integral(avgphase,low,high,order)
            norm=integral(lambda rad:rad**2*field(rad),low,high,order)
            curv=(high**2*field(high,1)-low**2*field(low,1))/(2*norm)
            potential=integral(lambda rad:phi(rad)*rad**2*field(rad),low,high,order)/norm
            return gr,curv,potential
        gr,curv,potential=estimate(40)
        coarse=estimate(20)
        yield dict(r_low=low,r_high=high,omega2_minus_rest2=gr,nonrel_energy=potential-curv,
                   shape_curvature=curv,baryon_potential=potential,
                   quadrature_over_offset=abs(coarse[0]-gr)/max(abs(gr),1e-300),
                   freq_below_escape=gr<0)


def bounds():
    field,metric,potential,grav,rest,depth=inputs()
    ref=field(0.)
    variation=abs(field(RC)/ref-1)
    def growth(arg):
        return arg**2/6*(1+arg**2/20+arg**4/840) if arg<.01 else np.sinh(arg)/arg-1
    allowed=growth(RC*np.sqrt(2*depth))
    necessary=brentq(lambda arg:growth(arg)-variation,1e-12,20.)/RC
    core=weights()/2*integral(lambda rad:rad**2*field(rad)**2,0.,RC,48)
    rest_density=weights()*field(6.)**2/(8*np.pi)*c**2/G/LENGTH**2
    rho_total=rest_density*(1+metric(6.)[1]*(field(6.,1)/field(6.))**2)
    core_fraction=min(1.,16*(rest*RC)**2)
    conservative=brentq(lambda ratio:16*(rest*RC)**2*ratio*(1+ratio)**2-core/rest,0.,1e12)
    yield dict(source_rest_msun=rest*KG/MSUN,core_radius_pc=RC*LENGTH/parsec,
               local_rest_density_GeV_cm3=rest_density/GEVDENS,local_launch_total_GeV_cm3=rho_total/GEVDENS,
               conditional_core_scalar_msun=core*KG/MSUN,profile_fractional_drop=variation,
               baryon_escape_km_s=np.sqrt(2*depth)*c/1000.,max_bound_shape_variation=allowed,minimum_escape_km_s=necessary*c/1000,
               baryon_bohr_radius_pc=LENGTH/rest/parsec,baryon_hydrogenic_relative_energy_bracket=4*(rest*RC)**2,
               bound_core_probability_ceiling=core_fraction,min_scalar_test_mass_msun=core/core_fraction*KG/MSUN,
               min_isolated_self_grav_ratio=conservative,min_isolated_self_grav_mass_msun=conservative*rest*KG/MSUN)


if __name__=="__main__":
    create=sys.argv[1]=="create"
    save("stationary-source.csv",spectral(),create)
    save("occupation-bounds.csv",bounds(),create)
