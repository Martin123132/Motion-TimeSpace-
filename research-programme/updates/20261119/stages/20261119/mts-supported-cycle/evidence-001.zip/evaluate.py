import csv
import sys
from functools import lru_cache
from cycle import HOME, PRE, MODES, PHASES, LOCATIONS, TOL, EMISSIONS, SHELLS, TIMES, np, lock, bridge
from reduce_cloud import SEC, save_table as previous_table
from scipy.interpolate import make_interp_spline
from scipy.integrate import cumulative_simpson
from scipy.optimize import brentq

CHANNELS=("out_frequency","echo_frequency","out_delay","echo_delay")


def save(name,rows,create):
    rows=list(rows)
    if create:
        with (HOME/name).open("x",newline="",encoding="utf8") as stream:
            writer=csv.DictWriter(stream,fieldnames=list(rows[0]))
            writer.writeheader()
            writer.writerows(rows)
    with (HOME/name).open(newline="",encoding="utf8") as stream:
        assert list(csv.DictReader(stream))==[{key:str(val) for key,val in row.items()} for row in rows],name
    return rows


@lru_cache(None)
def load(mode,phase,mesh):
    path=HOME/f"{mode}-{phase}-{mesh}.npz"
    data=bridge.read(path)
    assert data["receipt"].item().decode()==bridge.sha(HOME/(phase+"-freeze.json" if mode=="target" else "inputs.json"))
    assert np.array_equal(data["emission"],EMISSIONS) and np.array_equal(data["times"],TIMES) and np.array_equal(data["r"],SHELLS)
    return data


def peak(value):
    return float(np.max(abs(value)))


def budgets():
    for phase in PHASES:
        for site in LOCATIONS:
            for idx,name in enumerate(CHANNELS):
                for ax in (2,3):
                    def wave(mode,mesh=256,rule="64_3"):
                        curve=load(mode,phase,mesh)[site+"_"+rule][idx,ax]
                        return curve-curve[0]
                    target=wave("target")
                    forecast=wave("prediction")
                    norm=peak(target)
                    pos=np.argmax(abs(target))
                    terms=[peak(item)/norm for item in (target-forecast,target-wave("target",128),forecast-wave("prediction",128),
                           target-wave("target",256,"32_3"),forecast-wave("prediction",256,"32_3"),
                           target-wave("target",256,"64_2"),forecast-wave("prediction",256,"64_2"))]
                    yield dict(phase=phase,site=site,channel=name,axis=("scalar" if ax==2 else "mixed"),
                               at=EMISSIONS[pos],signed_peak=target[pos],seconds=(target[pos]*SEC if idx>=2 else ""),
                               model=terms[0],target_grid=terms[1],prediction_grid=terms[2],target_ray=terms[3],
                               prediction_ray=terms[4],target_order=terms[5],prediction_order=terms[6],
                               cycle_value=make_interp_spline(EMISSIONS,target,k=5)(np.pi).item(),
                               total=sum(terms),passes=sum(terms)<=TOL)


def currents():
    for phase in PHASES:
        data=load("target",phase,256)["diag"]
        for loc,radius in enumerate(SHELLS):
            for ax in (2,3):
                mass,_,flow,_,_,_,_,_,constraint,_,_=data[:,:,ax,loc].T
                changed=mass-mass[0]
                integral=-radius**2*cumulative_simpson(flow,x=TIMES,initial=0.)
                coarse=-radius**2*cumulative_simpson(flow[::2],x=TIMES[::2],initial=0.)
                err=peak(changed-integral)/peak(changed)
                quadrature=peak(integral[::2]-coarse)/peak(changed)
                source=load("prediction",phase,256)["diag"][:,0,ax,loc]
                agreement=peak(mass-source)/peak(mass)
                yield dict(phase=phase,r=radius,axis=ax,mass_change=changed[-1],flux_integral=integral[-1],
                           relative_balance=err,quadrature=quadrature,forecast_mass=agreement,
                           constraint_scale_r_over_mass=peak(constraint)*radius/peak(mass),
                           passes=err+quadrature+agreement<=TOL)


def mechanics():
    with (PRE/"supported-phase.csv").open(newline="") as stream:
        anchors=list(csv.DictReader(stream))
    for phase in PHASES:
        name="turning_phase" if phase=="turn" else "kinetic_phase"
        for idx,radius in enumerate(SHELLS):
            for ax in ("material_particle","interaction"):
                def series(mode,mesh,column):
                    curves=load(mode,phase,mesh)["diag"][:,column,:,idx]
                    return curves[:,3] if ax=="interaction" else curves[:,2]+curves[:,3]
                terms=[]
                for column in (3,4,7):
                    pred=series("prediction",256,column)
                    target=series("target",256,column)
                    if column==7 and radius>5 and ax=="interaction":
                        pass
                    norm=peak(target)
                    if norm:
                        terms.append((peak(pred-target)+peak(target-series("target",128,column))+peak(pred-series("prediction",128,column)))/norm)
                accel=series("target",256,5)[0]*299792458/SEC
                ref=float(anchors[idx][name])
                launch=abs(accel-ref)/abs(ref) if ax=="material_particle" else None
                disp=series("target",256,3)
                vel=series("target",256,4)
                pressure=series("target",256,1)
                cross=np.flatnonzero((pressure[:-1]*pressure[1:])<0)
                spline=make_interp_spline(TIMES,pressure,k=5)
                roots=[brentq(spline,TIMES[it],TIMES[it+1]) for it in cross]
                read=lambda curve:make_interp_spline(TIMES,curve,k=5)(np.pi).item()
                proper=make_interp_spline(TIMES,vel,k=5)
                cycle_delta=read(disp)
                total_time=SEC
                yield dict(phase=phase,r=radius,axis=ax,source_material=radius<5,initial_accel_m_s2=accel,
                           previous_relative=(launch if launch is not None else ""),displacement_after_pi_m=cycle_delta*total_time*299792458,
                           velocity_after_pi_m_s=read(vel)*299792458,peak_displacement_m=peak(disp)*total_time*299792458,
                           first_pressure_zero=(roots[0] if roots else ""),second_pressure_zero=(roots[1] if len(roots)>1 else ""),
                           motion_error=max(terms),passes=max(terms)<=TOL and (launch is None or launch<=TOL))


if __name__=="__main__":
    for phase in PHASES:
        lock(phase)
    for filename,fn in (("timing.csv",budgets),("flux.csv",currents),("mechanics.csv",mechanics)):
        rows=save(filename,fn(),sys.argv[1]=="create")
        print(filename,len(rows),sum(row["passes"] for row in rows),flush=True)
