import sys
import json
from source_scale import scale, HOME, save


def check():
    current=next(scale())
    older=json.loads((HOME.parent/"mts-wave-state-20261107"/"result.json").read_bytes())["states"][0]
    for current_key,prior_key in (("mass_radius_dimensionless","halfMass"),("normalized_energy","energy")):
        coarse=older[0][prior_key]
        fine=older[1][prior_key]
        assert older[0]["box"]==older[1]["box"] and older[0]["step"]==2*older[1]["step"]
        extrapolated=fine+(fine-coarse)/3
        actual=current[current_key]
        yield dict(quantity=current_key,higher_order_value=actual,prior_fine=fine,prior_coarse=coarse,
                   raw_mismatch=abs(fine/actual-1),second_order_extrapolation=extrapolated,
                   extrapolated_mismatch=abs(extrapolated/actual-1),
                   prior_box_shift=abs(older[2][prior_key]/fine-1))


if __name__=="__main__":
    print(save("independent-mesh-bridge.csv",check(),sys.argv[1]=="create"))
