from pathlib import Path
import sys
import json
import os
for key in ("OMP_NUM_THREADS","OPENBLAS_NUM_THREADS","MKL_NUM_THREADS","NUMEXPR_NUM_THREADS"):
    os.environ[key]="1"
sys.dont_write_bytecode=True
HOME=Path(__file__).resolve().parent
PRE=HOME.parent/"mts-single-cloud-clocks-20261119"
sys.path.insert(0,str(PRE))
from cloud import Algebra, base, np, bridge, weights, TOL, LOCATIONS, EMISSIONS, TIMES, RADIUS, check as prior_check
from rectangle import Radial
from support import system
from source import background
from scipy.interpolate import make_interp_spline
from scipy.integrate import cumulative_simpson
SEAL="d0d7a8e6e2f58e6c01500fe3f960e15aaa3e8d9d95f489df36604c52667e9238"
FRACTION=1e-6
SHELLS=np.array([.75,2.,3.,4.,4.75,6.5])
MODES=("prediction","target")
PHASES=("turn","kinetic")


def guard():
    prior_check()
    if (HOME/"STOP-REQUESTED").exists():
        raise SystemExit("owner hold")
    assert bridge.sha(PRE/"seal.json")==SEAL and TOL==2e-5


def stamp(name,data,new=False):
    path=HOME/name
    if new:
        with path.open("x") as stream:
            json.dump(data,stream,sort_keys=True,indent=2)
    else:
        assert json.loads(path.read_bytes())==data,name


def lock(phase=None,new=False):
    guard()
    files=[HOME/"PROTOCOL.md",HOME/"cycle.py",HOME/"proper_clock.py",PRE/"seal.json"]
    stamp("inputs.json",{path.name:bridge.sha(path) for path in files},new and phase is None)
    if phase is not None:
        files=[HOME/"inputs.json",*[HOME/f"prediction-{phase}-{mesh}.npz" for mesh in (128,256)]]
        stamp(phase+"-freeze.json",{path.name:bridge.sha(path) for path in files},new)


def midpoint_weights():
    nodes=np.arange(6)+.5
    return np.linalg.solve(np.array([nodes**deg for deg in range(6)]),np.array([.5**(deg+1)/(deg+1) for deg in range(6)]))


LEFT=midpoint_weights()


def integral(values,spacing,odd=False):
    ext=np.concatenate(((-1 if odd else 1)*values[...,:2][...,::-1],values,values[...,-2:][...,::-1]),axis=-1)
    increments=(11*(ext[...,:-5]+ext[...,5:])-93*(ext[...,1:-4]+ext[...,4:-1])+802*(ext[...,2:-3]+ext[...,3:-2]))*(spacing/1440)
    first=np.sum(values[...,:6]*LEFT,axis=-1,keepdims=True)*spacing
    return np.concatenate((first,first+np.cumsum(increments,axis=-1)),axis=-1)


class Cluster:
    def __init__(self,mesh,finite,phase):
        self.mesh=mesh
        self.finite=finite
        self.ar=ar=Algebra(1,int(finite))
        self.op=Radial(mesh,"tensor",0.,0.,RADIUS)
        self.x=xx=self.op.x
        self.one=one=base(np.ones_like(xx))
        self.mul=mul=ar.product
        self.inv=inv=ar.reciprocal
        self.root=ar.root
        self.w=weights()
        sol,field=system(FRACTION)
        rest,bind,_,lognu,_,_=sol(xx)
        self.mass=mass=0*one
        mass[1]=FRACTION*(rest+FRACTION*bind)
        self.fb=fb=one-2*mass/xx
        self.ib=inv(fb)
        self.lam=mul(mass/xx,inv(one-3*mass/xx))
        self.gamma=ar.root(one+self.lam)
        self.nu=nu=0*one
        nu[1]=FRACTION*lognu
        self.lapse=ar.exponential(nu)
        self.nb2=mul(self.lapse,self.lapse)
        self.dnu=mul(mass/xx**2,self.ib)
        self.b=0*one
        dens,_=background("massive")
        self.b[1]=FRACTION*dens*np.maximum(1-(xx/5)**2,0)**6
        self.mprime=xx**2*mul(self.b,mul(ar.root(fb),self.gamma))
        self.jprime=2*self.lam/xx+self.diff(self.lam)
        self.tidal=mul(self.nb2,mul(mass/xx**3,mul(one-6*mass/xx,self.ib)))
        self.factor=mul(self.lapse,inv(ar.root(fb)))
        self.wave=mul(self.lapse,ar.root(fb))
        self.gradwave=self.diff(self.wave-one)
        self.height=field(xx)
        self.slope=field(xx,1)
        self.sin=1. if phase=="kinetic" else 0.
        self.cos=1.-self.sin

    def diff(self,data,odd=False):
        return self.op.diff(data,self.op.d1,odd)

    def prim(self,data,odd=False):
        return integral(data,1/self.mesh,odd)

    def stress(self,field,can,factor,slope):
        mul=self.mul
        sq=mul(can,can)
        grad=mul(slope,slope)
        stiff=mul(factor,sq+grad)
        pot=mul(field,field)
        weigh=self.ar.stress
        return weigh(stiff+pot,self.w)/2,weigh(stiff-pot,self.w)/2,-weigh(mul(factor,mul(can,slope)),self.w)

    def launch(self):
        one,xx,mul=self.one,self.x,self.mul
        field=base(self.cos*self.height)
        normal=base(-self.sin*self.height)
        rho=self.ar.stress(base(self.height**2)+self.fb*(self.cos*self.slope)**2,self.w)/2
        delta=mul(self.inv(self.factor),self.prim(xx**2*mul(self.factor,rho)))
        if self.finite:
            for iteration in range(12):
                fac=self.fb-2*delta/xx
                drag=mul(2*xx*self.b,mul(self.gamma,self.inv(self.root(fac)+self.root(self.fb))))
                rho=self.ar.stress(base(self.height**2)+fac*(self.cos*self.slope)**2,self.w)/2
                after=self.prim(xx**2*rho-mul(drag,delta))
                if iteration>2 and np.all(np.max(abs(after-delta),axis=1)<=1e-13*np.maximum(1e-290,np.max(abs(after),axis=1))):
                    delta=after
                    break
                delta=after
            else:
                raise ArithmeticError("launch mass")
            fac=self.fb-2*delta/xx
            zero=0*one
            return np.stack((field,mul(normal,self.inv(self.root(fac))),delta,zero,zero,zero,zero))
        zero=0*one
        return np.stack((field,mul(normal,self.inv(self.root(self.fb))),zero,zero))

    def kg(self,field,can,wave,dwave,n_over_root):
        lap=self.op.diff(self.x*field,self.op.d2,True)/self.x
        return (self.mul(wave,can),self.mul(wave,lap)+self.mul(dwave,self.diff(field))-self.mul(n_over_root,field))

    def predict(self,state,read=False):
        field,can,disp,vel=state
        xx,mul=self.x,self.mul
        rho,press,current=self.stress(field,can,self.fb,self.diff(field))
        eta=mul(self.inv(self.factor),self.prim(xx**2*mul(self.factor,rho)))
        change=eta-mul(self.mprime,disp)
        force=-mul(self.tidal,disp)-mul(self.nb2,mul(eta,self.ib)/xx**2+xx*press)
        if read:
            dnu=mul(self.ib,mul(change,self.ib)/xx**2+xx*press)
            nu=self.nu+self.prim(dnu,True)
            fac=self.fb-2*change/xx
            density=-self.diff(mul(self.b,disp)*xx**2,True)/xx**2
            angular=-mul(disp,self.jprime)
            fullpress=press
            flux=mul(self.wave,current)+mul(self.mprime/xx**2,vel)
            return nu,fac,change,fullpress,flux,disp,vel,force,density,angular
        first,second=self.kg(field,can,self.wave,self.gradwave,self.factor)
        return np.stack((first,second,vel,force))

    def target(self,state,read=False):
        field,can,change,momentum,angular,count,label=state
        xx,one,mul,inv=self.x,self.one,self.mul,self.inv
        fac=self.fb-2*change/xx
        root=self.root(fac)
        orbit=self.lam+angular
        psq=mul(momentum,momentum)
        fp2=mul(fac,psq)
        gam=self.root(one+orbit+fp2)
        ig=inv(gam)
        density=self.b+count
        sden,spress,sflux=self.stress(field,can,fac,self.diff(field))
        particles=mul(density,root)
        press=spress+mul(particles,mul(fp2,ig))
        current=sflux+mul(density,mul(fac,momentum))
        dnu=mul(inv(fac),mul(change,self.ib)/xx**2+xx*press)
        nu=self.nu+self.prim(dnu,True)
        lapse=self.ar.exponential(nu)
        wave=mul(lapse,root)
        vel=mul(wave,mul(root,mul(momentum,ig)))
        dface=self.diff(fac-one)
        bracket=mul(angular,one/xx-self.dnu)-mul(fp2,self.dnu)-mul(one+orbit+fp2,dnu)-mul(psq,dface)/2
        pdot=mul(mul(lapse,ig),bracket)-mul(vel,self.diff(momentum,True))
        if read:
            return nu,fac,change,press,mul(wave,current),-label,vel,pdot,count,angular
        first,second=self.kg(field,can,wave,mul(wave,self.dnu+dnu+mul(dface,inv(fac))/2),mul(lapse,inv(root)))
        return np.stack((first,second,-xx**2*mul(wave,current),pdot,
                         -mul(vel,self.jprime+self.diff(angular)+2*angular/xx),
                         -self.diff(xx**2*mul(density,vel),True)/xx**2,-mul(vel,one+self.diff(label,True))))

    def read(self,state):
        return self.target(state,True) if self.finite else self.predict(state,True)


def run(mode,phase,mesh):
    from proper_clock import read_clocks
    finite=mode=="target"
    lock(phase if finite else None)
    dest=HOME/f"{mode}-{phase}-{mesh}.npz"
    if dest.exists():
        raise FileExistsError(dest)
    sim=Cluster(mesh,finite,phase)
    state=sim.launch()
    xx,ar=sim.x,sim.ar
    rate=sim.target if finite else sim.predict
    masks={site:(xx>=low-.09)&(xx<=low+.59) for site,low in LOCATIONS.items()}
    strips={site:[] for site in masks}
    take=np.searchsorted(xx,SHELLS)
    diag=[]
    for tick in range(451):
        nu,fac,change,press,flux,disp,vel,drive,count,angular=sim.read(state)
        lapse=ar.exponential(nu)
        optical=ar.reciprocal(ar.product(lapse,ar.root(fac)))-sim.one
        for site,mask in masks.items():
            strips[site].append(np.stack((optical[:,mask],(lapse-sim.one)[:,mask])))
        mat=state[3] if finite else ar.product(vel,ar.product(sim.gamma,ar.reciprocal(ar.product(sim.lapse,sim.fb))))
        proper_acc=ar.product(drive,ar.product(ar.product(sim.gamma,sim.gamma),ar.reciprocal(sim.nb2)))
        if finite:
            proper_acc=ar.product(drive,ar.product(ar.reciprocal(lapse),ar.product(fac,sim.gamma)))
        field,can=state[:2]
        rho,_,jscalar=sim.stress(field,can,fac if finite else sim.fb,sim.diff(field))
        if finite:
            en=ar.root(sim.one+sim.lam+angular+ar.product(fac,ar.product(mat,mat)))
            density=ar.product(sim.b+count,ar.product(ar.root(fac),en))+rho
            gradient_constraint=sim.diff(sim.mass+change,True)-xx**2*density
        else:
            gradient_constraint=0*change
        traces=np.stack((change,press,flux,disp,vel,proper_acc,count,angular,gradient_constraint,lapse-sim.one,jscalar))
        radset=(traces[...,take-1]+traces[...,take])/2
        diag.append(radset)
        assert not np.any(np.stack((change,disp,vel,press,count,angular))[:,:2])
        if tick%50==0:
            guard()
        if tick==450:
            break
        steps=int(np.ceil(mesh*.01/.42))
        dt=.01/steps
        for substep in range(steps):
            first=rate(state)
            second=rate(state+dt*first/2)
            third=rate(state+dt*second/2)
            fourth=rate(state+dt*third)
            state+=dt/6*(first+2*second+2*third+fourth)
    output=dict(times=TIMES,emission=EMISSIONS,r=SHELLS,diag=np.array(diag),
                stage=np.bytes_(mode),phase=np.bytes_(phase),mesh=mesh,
                receipt=np.bytes_(bridge.sha(HOME/(phase+"-freeze.json" if finite else "inputs.json"))))
    for site,mask in masks.items():
        bank=np.array(strips.pop(site))
        for panels in (32,64):
            for degree in ((3,) if panels==32 else (3,2)):
                output[f"{site}_{panels}_{degree}"]=read_clocks(TIMES,xx[mask],bank,LOCATIONS[site],ar,panels,degree)
    assert np.isfinite(output["diag"]).all()
    bridge.archive(dest,**output)
    print(dest.name,flush=True)


if __name__=="__main__":
    if sys.argv[1]=="init":
        lock(new=True)
    elif sys.argv[1]=="freeze":
        lock(sys.argv[2],True)
    else:
        assert sys.argv[1] in MODES and sys.argv[2] in PHASES
        for mesh in sys.argv[3:]:
            run(sys.argv[1],sys.argv[2],int(mesh))
