from math import factorial
from cycle import np, base, EMISSIONS
from transport import OpticalSurface
from scipy.interpolate import make_interp_spline


def compose(spline,time,ar,degree):
    head=time[0]
    small=time.copy()
    small[0]=0.
    out=spline(head).T.copy()
    power=small
    for index in range(1,degree+1):
        out+=ar.product(spline.derivative(index)(head).T,power)/factorial(index)
        if index<degree:
            power=ar.product(power,small)
    return out


def read_clocks(times,space,bank,low,ar,panels,degree):
    delay=bank[:,0]
    deriv=make_interp_spline(times,delay,k=5).derivative()(times)
    assert np.max(abs(delay[:,1]-delay[0,1]))==0.
    deriv[:,:2]=0.
    surface=OpticalSurface(times,space,np.stack((delay,-deriv),axis=1),low,panels,degree)
    values=make_interp_spline(space,bank[:,1],k=5,axis=-1)([low,low+.5])
    lapses=[make_interp_spline(times,values[:,:,end],k=5) for end in range(2)]
    clocks=[lapse.antiderivative() for lapse in lapses]
    emit=base(EMISSIONS)
    ones=base(np.ones_like(EMISSIONS))
    offset=0*emit
    for iteration in range(7):
        offset=-compose(clocks[0],emit+offset,ar,degree)
    launch=emit+offset
    step=.5/panels
    def leg(start,reverse):
        result=np.zeros((2,*emit.shape))
        def rhs(index,work):
            time=start+work[0]
            time[0]+=index*step/2
            pos=2*panels-index if reverse else index
            return surface.sample(ar,time,pos,degree)
        for seg in range(panels):
            idx=2*seg
            first=rhs(idx,result)
            second=rhs(idx+1,result+step*first/2)
            third=rhs(idx+1,result+step*second/2)
            fourth=rhs(idx+2,result+step*third)
            result+=step/6*(first+2*second+2*third+fourth)
        return result
    first=leg(launch,False)
    reflection=launch+first[0]
    reflection[0]+=.5
    second=leg(reflection,True)
    end=reflection+second[0]
    end[0]+=.5
    output=[]
    for dest,finish,coord,exponent in ((1,reflection,first[0],first[1]),(0,end,first[0]+second[0],first[1]+second[1])):
        start_rate=ones+compose(lapses[0],launch,ar,degree)
        end_rate=ones+compose(lapses[dest],finish,ar,degree)
        ratio=ar.product(ar.product(start_rate,ar.reciprocal(end_rate)),ar.exponential(exponent))-ones
        duration=offset+coord+compose(clocks[dest],finish,ar,degree)
        output.append((ratio,duration))
    return np.array([output[0][0],output[1][0],output[0][1],output[1][1]])
