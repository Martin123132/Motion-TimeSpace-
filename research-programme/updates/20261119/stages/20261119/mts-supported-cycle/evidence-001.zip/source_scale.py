import sys
import csv
import json
from cycle import HOME, bridge, np
from occupation_test import KG, LENGTH, MSUN
from evaluate import save
from scipy.constants import c,parsec


def scale():
    prior=HOME.parent/"mts-wave-state-20261107"/"result.json"
    assert bridge.sha(prior)=="e44e79ca5e4c928d0b3b5969a433c569683b045b737ebd69810ad9d5b9f73c52"
    states=json.loads(prior.read_bytes())["states"][0]
    with (HOME/"self-bound-controls.csv").open(newline="") as stream:
        reports=list(csv.DictReader(stream))
    for rec in (row for row in reports if float(row["edge"])==30):
        mass=float(rec["scalar_mass_msun"])*MSUN/KG
        half=float(rec["half_mass_radius_kpc"])*1000*parsec/LENGTH
        normalized=float(rec["energy_over_rest"])/mass**2
        product=mass*half
        baryons=rec["baryons"]=="True"
        yield dict(ordinary_source=baryons,mass_radius_dimensionless=product,normalized_energy=normalized,
                   isolated_prior_radius=states[-1]["halfMass"],isolated_prior_energy=states[-1]["energy"],
                   relative_radius_difference=abs(product/states[-1]["halfMass"]-1),
                   relative_energy_difference=abs(normalized/states[-1]["energy"]-1),
                   scalar_only_circular_speed_at_halfmass_km_s=c*np.sqrt(mass/(2*half))/1000,
                   interpretation="baryon-perturbed comparison" if baryons else "independent pure-wave comparison")


if __name__=="__main__":
    print(save("source-scale.csv",scale(),sys.argv[1]=="create"))
