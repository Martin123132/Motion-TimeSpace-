import sys
from scipy.integrate import solve_bvp, simpson, cumulative_simpson
from scipy.optimize import brentq
from scipy.special import betainc
from occupation_test import inputs, KG, LENGTH, MSUN, GEVDENS, RC
from cycle import HOME, np, TOL, bridge
from evaluate import save
from scipy.constants import parsec,c,G

RHO=.1*GEVDENS*4*np.pi*G*LENGTH**2/c**2
SCALE=RHO**(-.25)


def solve_edge(limit,base_points,has_baryons,retain=False):
    field,_,phi,_,rest,_=inputs()
    soft=RC/SCALE
    edge=np.unique(np.r_[np.linspace(0.,soft,27),np.geomspace(soft,.08,30),np.linspace(.08,limit,base_points)])
    def external(rad):
        xx=np.maximum(rad*SCALE,1e-200)
        return SCALE**2*phi(xx)*has_baryons
    def rhs(rad,state,energy):
        amp,slope,potential,gradient=state
        return np.stack((slope,2*(potential+external(rad)-energy[0])*amp,gradient,amp**2))
    center=1.
    def boundary(left,right,eigen):
        return np.array([left[0]-center,left[1],left[3],right[2]+limit*right[3],right[0]])
    guess=(1+.09*edge**2)**-4
    potential=-2./np.sqrt(1+edge**2/3)
    state=np.stack((guess,-.72*edge*(1+.09*edge**2)**-5,potential,2*edge/3*(1+edge**2/3)**-1.5))
    eig=[-.7]
    singular=np.diag([0.,-2.,0.,-2.])
    for iteration in range(6):
        sol=solve_bvp(rhs,boundary,edge,state,S=singular,p=eig,tol=2e-8,bc_tol=1e-11,max_nodes=16000)
        if not sol.success:
            raise ArithmeticError(sol.message)
        error=1.-sol.sol(6/SCALE)[0]
        if abs(error)<2e-12:
            break
        center+=error
        edge,state,eig=sol.x,sol.y,sol.p
    else:
        raise ArithmeticError("reference density did not match")
    rad=np.unique(np.r_[np.linspace(0.,soft,61),np.geomspace(soft,.08,61),np.linspace(.08,limit,9001)])
    amp,slope,pot,grad=sol.sol(rad)
    assert min(amp)>-1e-11 and sol.p[0]<0
    shell=rad**2*amp**2
    cumulative=cumulative_simpson(shell,x=rad,initial=0.)
    mass=cumulative[-1]
    half=brentq(lambda place:place**2*sol.sol(place)[3]-mass/2,.1,limit)
    kinetic=simpson(rad**2*slope**2/2,x=rad)
    binding=simpson(shell*pot/2,x=rad)
    ext=simpson(shell*external(rad),x=rad)
    mb=rest*SCALE*has_baryons*betainc(1.5,7,np.minimum((rad/soft)**2,1.))
    virial_ext=simpson(shell*mb/np.where(rad>0.,rad,1.),x=rad)
    eig_check=(kinetic+2*binding+ext)/mass
    core_state=sol.sol(RC/SCALE)
    core_mass=(RC/SCALE)**2*core_state[3]/SCALE
    probes=np.array([.75,2.,3.,4.,5.,6.,6.5])
    obs=sol.sol(probes/SCALE)
    final_mass=(probes/SCALE)**2*obs[3]/SCALE
    baryons=rest*has_baryons*betainc(1.5,7.,np.minimum((probes/RC)**2,1.))
    rows=[dict(baryons=bool(has_baryons),r=radius,density_GeV_cm3=.1*record**2,scalar_enclosed_msun=inside*KG/MSUN,
            scalar_only_circular_km_s=c/1e3*np.sqrt(inside/radius),
            total_circular_km_s=c/1e3*np.sqrt((inside+baryon)/radius)) for radius,record,inside,baryon in zip(probes,obs[0],final_mass,baryons)]
    result=dict(baryons=bool(has_baryons),edge=limit,eigen_scaled=sol.p[0],energy_over_rest=sol.p[0]/SCALE**2,
                scalar_mass_msun=mass/SCALE*KG/MSUN,half_mass_radius_kpc=half*SCALE*LENGTH/parsec/1000,
                core_enclosed_msun=core_mass*KG/MSUN,core_shape_drop=1-core_state[0]/center,
                central_total_potential_over_c2=(pot[0]+external(rad[:1])[0])/SCALE**2,
                virial_error=abs(2*kinetic+binding-virial_ext)/(2*kinetic),
                eigen_error=abs(eig_check/sol.p[0]-1),mass_error=abs(limit**2*grad[-1]/mass-1),
                ref_normalization_error=abs(sol.sol(6/SCALE)[0]-1))
    if retain:
        return result,rows,sol.sol
    return result,rows


def experiment(create):
    reports=[]
    profiles=[]
    for baryons in (False,True):
        coarse,_=solve_edge(18.,301,baryons)
        fine,local=solve_edge(30.,531,baryons)
        compare_fields=("eigen_scaled","scalar_mass_msun","half_mass_radius_kpc","core_enclosed_msun","central_total_potential_over_c2")
        delta=max(abs(coarse[name]/fine[name]-1) for name in compare_fields)
        for row in (coarse,fine):
            row.update(edge_mesh_shift=delta,passes=delta+sum(row[name] for name in ("virial_error","eigen_error","mass_error","ref_normalization_error"))<=TOL)
        reports.extend((coarse,fine))
        profiles.extend(local)
    save("self-bound-controls.csv",reports,create)
    save("self-bound-profile.csv",profiles,create)
    return reports


if __name__=="__main__":
    for row in experiment(sys.argv[1]=="create"):
        print(row["baryons"],row["edge"],row["scalar_mass_msun"],row["half_mass_radius_kpc"],row["passes"])
