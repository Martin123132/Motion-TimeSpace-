import sys
from scipy.interpolate import make_interp_spline
from scipy.integrate import cumulative_simpson
from scipy.optimize import brentq
from scipy.constants import c
from cycle import HOME, PHASES, LOCATIONS, TIMES, EMISSIONS, SHELLS, Algebra, np, TOL, bridge
from evaluate import load, save, peak, SEC
from cloud_receiver import load_calendar, at_arrival


def calendar():
    days,groups,counts=load_calendar()
    years=(days-min(days))/365.25
    elapsed=(days-min(days))*86400/SEC
    unique,idx=np.unique(days,return_inverse=True)
    weights=counts/np.bincount(idx,weights=counts)[idx]
    root=np.sqrt(weights/sum(weights))
    age=2*years/max(years)-1
    design=np.column_stack((1+0*age,age,age**2,np.cos(2*np.pi*years),np.sin(2*np.pi*years),
                           np.cos(4*np.pi*years),np.sin(4*np.pi*years),groups[:,None]==np.unique(groups)[1:]))
    left,sig,_=np.linalg.svd(root[:,None]*design,full_matrices=False)
    basis=left[:,sig>sig[0]*1e-12]
    def remove(curve):
        scaled=root*curve
        return scaled-basis@(basis.T@scaled)
    for phase in PHASES:
        for site in LOCATIONS:
            for window,shift in (("early",0.),("middle",.5),("late",1.)):
                labels=EMISSIONS[1]+shift*(EMISSIONS[-2]-EMISSIONS[1]-elapsed[-1])+elapsed
                def calc(mode,mesh=256,stride=1,degree=3):
                    delay=load(mode,phase,mesh)[site+"_64_3"][2,:,::stride]
                    return at_arrival(make_interp_spline(EMISSIONS[::stride],delay,axis=1,k=5),labels,degree)[3]
                target=calc("target")
                post=np.linalg.norm(remove(target))
                raw=np.linalg.norm(root*target)
                err=sum(np.linalg.norm(remove(target-other))/post for other in (calc("prediction"),calc("target",128),
                                    calc("target",256,2),calc("target",256,1,2)))
                yield dict(phase=phase,site=site,window=window,dates=len(unique),years=years[-1],
                           raw_rms_s=raw,post_rms_s=post,fraction=post/raw,total=err,passes=err<=TOL)


def repair():
    for phase in PHASES:
        packet=bridge.read(HOME/f"tubes-{phase}.npz")
        assert packet["receipt"].item().decode()==bridge.sha(HOME/f"target-{phase}-256.npz")
        bank=packet["flux"]
        for pos,radius in enumerate(SHELLS):
            for axis in (2,3):
                mass=load("target",phase,256)["diag"][:,0,axis,pos]
                changed=mass-mass[0]
                area=bank[:,:,axis,pos]
                integrated=-cumulative_simpson(area,x=TIMES,axis=0,initial=0)
                coarse=-cumulative_simpson(area[::2],x=TIMES[::2],axis=0,initial=0)
                balance=peak(changed-integrated[:,2])/peak(changed)
                quadrature=peak(coarse[:,2]-integrated[::2,2])/peak(changed)
                split=peak(integrated[:,2]-integrated[:,0]-integrated[:,1])/peak(changed)
                yield dict(phase=phase,r=radius,axis=axis,change=changed[-1],material=integrated[-1,0],
                           scalar=integrated[-1,1],balance=balance,quadrature=quadrature,split=split,
                           passes=balance+quadrature+split<=TOL)


def cycles():
    for phase in PHASES:
        for pos,radius in enumerate(SHELLS):
            def metrics(mode,mesh):
                data=load(mode,phase,mesh)["diag"][:,:,:,pos]
                curves=data[:,:,2]+data[:,:,3]
                pcurve=curves[:,1]
                pspline=make_interp_spline(TIMES,pcurve,k=5)
                marks=np.flatnonzero(pcurve[1:]*pcurve[:-1]<0)
                roots=[brentq(pspline,TIMES[it],TIMES[it+1]) for it in marks]
                assert len(roots)==3 and np.sign(pspline.derivative()(roots[0]))==np.sign(pspline.derivative()(roots[2]))
                vfit=make_interp_spline(TIMES,curves[:,4],k=5)
                dfit=make_interp_spline(TIMES,curves[:,3],k=5)
                low,high=roots[0],roots[2]
                lapse=1+data[:,9,1]+curves[:,9]
                proper=make_interp_spline(TIMES,lapse,k=5).antiderivative()
                lapse_duration=proper(high)-proper(low)
                return np.array([low,high,lapse_duration*SEC/(365.25*86400),
                         (vfit(high)-vfit(low))*c, (dfit(high)-dfit(low))*SEC*c,
                         (vfit(high)-vfit(low))/(high-low)*c/SEC])
            result=metrics("target",256)
            errors=np.abs(metrics("prediction",256)-result)+np.abs(metrics("target",128)-result)
            ratio=max(errors/abs(result))
            yield dict(phase=phase,r=radius,occupied=radius<5,first_cross=result[0],next_like_cross=result[1],
                       supported_observer_cycle_years=result[2],coordinate_velocity_increment_m_s=result[3],
                       displacement_increment_m=result[4],cycle_mean_coordinate_accel_m_s2=result[5],
                       relative_budget=ratio,passes=ratio<=TOL)


def jacobians():
    for phase in PHASES:
        for site in LOCATIONS:
            data=load("target",phase,256)[site+"_64_3"]
            for idx,name in enumerate(("out","echo")):
                def calc(stride,degree):
                    derivative=make_interp_spline(EMISSIONS[::stride],data[2+idx,:,::stride],axis=1,k=degree).derivative()(EMISSIONS)
                    derivative[0]+=1
                    return Algebra(1,1).reciprocal(derivative)
                fine,coarse,alt=calc(1,5),calc(2,5),calc(1,7)
                for ax in (2,3):
                    ref=data[idx,ax]-data[idx,ax,0]
                    curves=[data[idx,ax]-fine[ax],fine[ax]-coarse[ax],fine[ax]-alt[ax]]
                    err=sum(peak(curve-curve[0])/peak(ref) for curve in curves)
                    yield dict(phase=phase,site=site,path=name,axis=ax,total=err,passes=err<=TOL)


if __name__=="__main__":
    for name,func in (("calendar.csv",calendar),("pressure-cycles.csv",cycles),
                      ("clock-identity.csv",jacobians),("tube-energy.csv",repair)):
        rows=save(name,func(),sys.argv[1]=="create")
        print(name,len(rows),sum(row["passes"] for row in rows),flush=True)
