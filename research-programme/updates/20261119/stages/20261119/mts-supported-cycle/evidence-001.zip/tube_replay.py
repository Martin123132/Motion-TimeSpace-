import sys
from cycle import HOME, TIMES, SHELLS, np, Cluster, lock, guard, bridge
from evaluate import load, peak


def run(phase):
    lock(phase)
    dest=HOME/f"tubes-{phase}.npz"
    if dest.exists():
        raise FileExistsError(dest)
    mesh=256
    solver=Cluster(mesh,True,phase)
    xx,ar=solver.x,solver.ar
    take=np.searchsorted(xx,SHELLS)
    sel=(xx>.125)&(xx<6.75)
    def sample(values):
        return (values[...,take-1]+values[...,take])/2
    saved=load("target",phase,mesh)["diag"]
    state=solver.launch()
    fluxes,checks=[],[]
    probe_inds=np.array([np.searchsorted(xx,val)-1 for val in (2.,3.,4.)])
    for tick in range(451):
        nu,fac,mass,press,flux,disp,vel,_,count,angular=solver.read(state)
        assert np.array_equal(sample(mass),saved[tick,0]) and np.array_equal(sample(flux),saved[tick,2])
        wave=ar.product(ar.exponential(nu),ar.root(fac))
        _,_,js=solver.stress(state[0],state[1],fac,solver.diff(state[0]))
        scalar=ar.product(wave,js)
        ordinary=ar.product(wave,ar.product(solver.b+count,ar.product(fac,state[3])))
        fluxes.append(np.array([sample(xx**2*term) for term in (ordinary,scalar,flux)]))
        if tick%5==0:
            jac=solver.diff(state[6],True)
            ang_delta=-ar.product(solver.jprime,disp)
            shape_err=peak((angular-ang_delta)[3,sel])/max(peak(angular[3,sel]),1e-270)
            displaced=xx**2*count[3]
            number=abs(np.sum(displaced))/max(np.sum(abs(displaced)),1e-270)
            dispph=disp[2]+disp[3]
            advection=peak(dispph[sel])*peak((jac[2]+jac[3])[sel])/max(peak(dispph[sel]),1e-270)
            checks.append([tick*.01,number,shape_err,peak(jac[:,sel]),advection])
        if tick%50==0:
            guard()
        if tick==450:
            break
        steps=int(np.ceil(mesh*.01/.42))
        dt=.01/steps
        for substep in range(steps):
            first=solver.target(state)
            second=solver.target(state+dt*first/2)
            third=solver.target(state+dt*second/2)
            fourth=solver.target(state+dt*third)
            state+=dt/6*(first+2*second+2*third+fourth)
    bridge.archive(dest,flux=np.array(fluxes),invariants=np.array(checks),receipt=np.bytes_(bridge.sha(HOME/f"target-{phase}-256.npz")))
    print(dest.name,flush=True)


if __name__=="__main__":
    run(sys.argv[1])
