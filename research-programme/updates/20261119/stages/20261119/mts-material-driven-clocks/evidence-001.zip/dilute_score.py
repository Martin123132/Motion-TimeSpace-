from score import peak, compare_or_write, SECONDS
from functools import lru_cache
from dilute import *


@lru_cache(None)
def read(kind,mesh,mode):
    packet=bridge.read(HERE/filename(kind,mesh,mode))
    expected="dilute-prediction.json" if kind=="target" else "dilute-setup.json"
    assert packet["lock_sha256"].item().decode()==bridge.sha(HERE/expected)
    assert float(packet["z"])==weights() and np.array_equal(packet["emissions"],EMISSIONS)
    return packet


def waveform(kind,mesh,mode,site,panels,index):
    key=f"{site}_{panels}"
    state=read(kind,mesh,mode)[key][index]
    return state if mode=="quiet" else state-read(kind,mesh,"quiet")[key][index]


def compute():
    check()
    signature("prediction")
    results=[]
    nulls=[]
    external=bridge.read(HERE/"mass-null.npz")
    for mode in ("plus","minus","quiet"):
        for site in LOCATIONS:
            for index,channel in enumerate(CHANNELS):
                def get(kind,mesh,panels):
                    return waveform(kind,mesh,mode,site,panels,index)
                target,pred=get("target",256,64),get("prediction",256,64)
                norm=peak(target)
                assert norm>0
                diffs=(target-pred,pred-get("prediction",128,64),target-get("target",128,64),
                       pred-get("prediction",256,32),target-get("target",256,32))
                errors=[peak(term)/norm for term in diffs]
                imax=np.argmax(abs(target))
                results.append(dict(mode=mode,link=site,channel=channel,peak_time=EMISSIONS[imax],
                                    signed_peak=target[imax],predicted_at_peak=pred[imax],
                                    peak_delay_seconds=(target[imax]*SECONDS if "delay" in channel else ""),
                                    model=errors[0],prediction_grid=errors[1],target_grid=errors[2],
                                    prediction_ray=errors[3],target_ray=errors[4],total=sum(errors),passes=sum(errors)<=TOL))
                if site!="outer" or mode=="quiet":
                    continue
                mass=external[mode+"_narrow"][index]
                wide=external[mode+"_wide"][index]
                for label,win in (("early",EMISSIONS<=1.7),("late",EMISSIONS>=2.8)):
                    denom=peak(target[win])
                    resid=target[win]-mass[win]
                    where=np.flatnonzero(win)[np.argmax(abs(resid))]
                    nulls.append(dict(mode=mode,channel=channel,window=label,target_peak=denom,mass_peak=peak(mass[win]),
                                      signed_residual=target[where]-mass[where],emission=EMISSIONS[where],
                                      residual_over_signal=peak(resid)/denom,
                                      null_step_change_over_signal=peak((mass-wide)[win])/denom,
                                      residual_seconds=((target[where]-mass[where])*SECONDS if "delay" in channel else "")))
    return {"dilute-budgets.csv":results,"mass-only-clock-comparison.csv":nulls}


if __name__=="__main__":
    compare_or_write(compute(),sys.argv[1]=="create")

