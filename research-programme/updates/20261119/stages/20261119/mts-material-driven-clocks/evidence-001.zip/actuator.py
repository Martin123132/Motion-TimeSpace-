from score import compare_or_write, SCALE_RECORD, SECONDS, peak
from clock_run import *
from scipy.constants import G, c, parsec
from scipy.integrate import simpson
from scipy.interpolate import PchipInterpolator
from scipy.optimize import brentq


def compute(mesh,amplitude):
    setup=Launch(mesh,.8)
    pc=json.loads(SCALE_RECORD.read_bytes())["length_pc"]
    unit=pc*parsec*c**2/G
    radius=setup.radius
    density,gauss,_,_=profile(radius,WAVE)
    source=amplitude*setup.number[0]*density
    initial=integrate(radius,radius**2*setup.number)
    variation=amplitude*setup.number[0]*gauss
    numerical=integrate(radius,radius**2*source)
    assert peak(variation-numerical)<1e-9*peak(variation)
    mask=radius<=3
    rings=radius[mask]
    amount=initial[mask]
    after=amount+variation[mask]
    assert after[-1]==amount[-1] and np.all(np.diff(after)>0)
    remapped=PchipInterpolator(after,rings)(amount)
    distance=remapped-rings
    first=np.zeros_like(rings)
    first[1:]=-variation[mask][1:]/(rings[1:]**2*setup.number[mask][1:])
    maxima=(density[1:]*density[:-1])<0
    roots=[0.]+[brentq(lambda val:profile(np.array([val]),WAVE)[0][0],radius[idx],radius[idx+1])
                 for idx in np.flatnonzero(maxima)]+[3.]
    values=amplitude*setup.number[0]*profile(np.array(roots),WAVE)[1]
    moved=np.maximum(np.diff(values),0.).sum()
    outward=np.maximum(-np.diff(values),0.).sum()
    assert np.isclose(moved,outward,rtol=1e-14,atol=0.)
    assert abs(moved-.5*simpson(radius**2*abs(source),x=radius))<1e-5*moved
    loc=np.argmax(abs(distance))
    return dict(mesh=mesh,seed=amplitude,mass_unit_kg=unit,length_pc=pc,time_unit_seconds=SECONDS,
                total_baryon_mass_kg=initial[-1]*unit,baryon_mass_inside_source_kg=amount[-1]*unit,
                redistributed_baryon_mass_kg=moved*unit,share_of_total=moved/initial[-1],source_radius_pc=3*pc,
                ordinary_radius_pc=5*pc,initial_label_pc=rings[loc]*pc,signed_shell_displacement_pc=distance[loc]*pc,
                percent_tangent_error=100*peak(distance-first)/peak(distance),
                central_density_kg_m3=setup.number[0]*unit/(4*np.pi*(pc*parsec)**3),
                initial_velocity=0.,inner_clock_label_pc=.75*pc,far_clock_label_pc=6*pc)


def rows():
    return {"actuator-scale.csv":[compute(mesh,amp) for mesh in MESHES for amp in (.01,-.01)]}


if __name__=="__main__":
    compare_or_write(rows(),sys.argv[1]=="create")

