from score import peak, packet, SECONDS, compare_or_write
from dilute_score import read, waveform
from dilute import *


def calculate():
    signature("prediction")
    rows=[]
    machine=np.finfo(float).eps
    for mode in ("plus","minus"):
        for site in LOCATIONS:
            for index,channel in enumerate(CHANNELS):
                key=f"{site}_64"
                target=waveform("target",256,mode,site,64,index)
                forecast=waveform("prediction",256,mode,site,64,index)
                dense=weights()*(packet("event",256,.8,mode)[key][index]-packet("event",256,.8,"quiet")[key][index])
                norm=max(abs(target))
                row=dict(mode=mode,link=site,channel=channel,source_max=max(abs(target)))
                for kind in ("prediction","target"):
                    finite=read(kind,256,mode)[key][index]
                    quiet=read(kind,256,"quiet")[key][index]
                    condition=peak(abs(finite)+abs(quiet))/peak(finite-quiet)
                    row[kind+"_condition"]=condition
                    row[kind+"_one_eps_reference"]=condition*machine
                row["finite_z_vs_scaled_dense"]=peak(target-dense)/norm
                row["first_z_vs_scaled_dense"]=peak(forecast-dense)/norm
                rows.append(row)
    return {"cancellation-diagnostics.csv":rows}


if __name__=="__main__":
    compare_or_write(calculate(),sys.argv[1]=="create")

