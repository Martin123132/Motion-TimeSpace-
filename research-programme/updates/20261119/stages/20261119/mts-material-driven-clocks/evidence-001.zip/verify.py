import sys
from pathlib import Path
from score import records, compare_or_write, peak, SCALE_RECORD
from dilute_score import compute
from clock_run import *
from dilute import weights, signature
from monopole import constraint
from finite_repair import repair_lock, construct
from conditioning import calculate as conditioning
from actuator import rows as actuator_rows
from mixed_launch import tables as mixed_rows


def verify():
    check()
    lock("forecast")
    signature("prediction")
    repair_lock()
    for mode in ("plus","minus","quiet"):
        packet=bridge.read(HERE/tag("event",256,.8,mode))
        assert packet["repair_sha256"].item().decode()==bridge.sha(HERE/"finite-repair-lock.json")
        for index,mesh in enumerate(MESHES):
            _,test=construct(mesh,float(packet["amplitude"]))
            assert packet["original_constraint"][index]==test["old"]
            assert packet["repaired_constraint"][index]==test["new"]<2e-17
    assert __debug__
    stage_files = json.loads((PRE/"seal.json").read_bytes())["files"]
    assert len(stage_files)==158 and all(bridge.sha(PRE/name)==digest for name,digest in stage_files.items())
    all_tables = {**records(),**compute(),**conditioning(),**mixed_rows(),**actuator_rows(),
                  "launch-mass.csv":[row for mesh in MESHES for row in constraint(mesh)]}
    compare_or_write(all_tables,False)
    assert {name:len(rows) for name,rows in all_tables.items()}=={
        "clock-budgets.csv":72,"source-decomposition.csv":24,"finite-event-check.csv":12,"prior-driven-field-check.csv":8,
        "dilute-budgets.csv":36,"mass-only-clock-comparison.csv":16,"launch-mass.csv":4,"cancellation-diagnostics.csv":24,
        "mixed-launch.csv":16,"actuator-scale.csv":4}
    assert all(row["outer_charge_change"]==0 for row in all_tables["launch-mass.csv"])
    assert all(row["passes"] for row in all_tables["prior-driven-field-check.csv"])
    for path in HERE.glob("*.npz"):
        with np.load(path,allow_pickle=False) as data:
            assert data.files and all(np.isfinite(data[key]).all() for key in data.files if data[key].dtype.kind in "fcui")
    assert not any(path.is_dir() or path.name.endswith(".partial") for path in HERE.iterdir())
    assert all((HERE/name).is_file() for name in ("RESULTS.md","DERIVATION.md","REPLAY.md"))
    files={}
    for module in tuple(sys.modules.values()):
        path=getattr(module,"__file__",None)
        if path:
            path=Path(path).resolve()
            if path.is_relative_to(HERE.parent) and not path.is_relative_to(HERE) and path.suffix==".py":
                files[path]=bridge.sha(path)
    files[SCALE_RECORD]=bridge.sha(SCALE_RECORD)
    for path,digest in files.items():
        seal=path.parent/"seal.json"
        if seal.exists():
            index=json.loads(seal.read_bytes()).get("files",{})
            if isinstance(index,dict) and path.name in index:
                assert index[path.name]==digest,path
    manifest=dict(parent=SEAL,prior_count=len(stage_files),tolerance=TOL,occupation_weight=weights(),
                  rows={name:len(rows) for name,rows in all_tables.items()},
                  dependencies={str(path.relative_to(HERE.parent)):digest for path,digest in files.items()},
                  files={path.name:bridge.sha(path) for path in HERE.iterdir() if path.name!="seal.json"})
    dest=HERE/"seal.json"
    if not dest.exists():
        write_json("seal.json",manifest)
    else:
        assert manifest==json.loads(dest.read_bytes())
    print(len(manifest["files"]),"files",sum(manifest["rows"].values()),"rows",bridge.sha(dest))


if __name__=="__main__":
    verify()

