from types import SimpleNamespace
from dilute import *
from clock_interpretation import exterior_forecast


def constraint(mesh):
    setup = Launch(mesh,.8)
    radius,inverse=setup.radius,setup.inv
    number,charge=setup.number,setup.charge
    density,gauss,_,_=profile(radius,WAVE)
    density*=number[0]
    gauss*=.8*number[0]
    mass=setup.ordinary
    fac=1-2*inverse*mass
    root=np.sqrt(fac)
    attenuation=radius*number/root
    initial=(setup.height**2+fac*setup.slope**2)/2
    ordinary=kernel(radius,attenuation,radius**2*(root*density+charge*gauss*inverse**4))
    loading=kernel(radius,attenuation,radius**2*initial)
    gradient=kernel(radius,attenuation,-radius*ordinary*setup.slope**2
                    -(radius*density/root+number*ordinary/root**3)*loading)
    seed=float(bridge.read(PRE/"driven-0.8-4-320.npz")["one_percent"])
    rows=[]
    for mode,amplitude in (("plus",seed),("minus",-seed)):
        dn,dq=amplitude*density,amplitude*gauss
        driver=radius**2*(dn*root+dq*(charge+dq/2)*inverse**4)
        delta=np.zeros_like(radius)
        for iteration in range(20):
            changed=np.sqrt(fac-2*inverse*delta)
            after=kernel(radius,2*radius*(number+dn)/(root+changed),driver)
            if max(abs(after-delta))<4e-15*max(abs(after)):
                delta=after
                break
            delta=after
        else:
            raise ArithmeticError("ordinary constraint difference")
        newroot=np.sqrt(fac-2*inverse*delta)
        newweight=radius*(number+dn)/newroot
        shift=radius*dn/newroot+2*number*delta/(root*newroot*(root+newroot))
        ds=kernel(radius,newweight,-radius*delta*setup.slope**2-shift*loading)
        direct=kernel(radius,newweight,radius**2*(setup.height**2+newroot**2*setup.slope**2)/2)
        assert max(abs((direct-loading)-ds)) < 2e-12*max(abs(loading))
        baryon=integrate(radius,radius**2*dn)[-1]
        assert abs(baryon)<1e-13*max(abs(integrate(radius,radius**2*dn))) and dq[-1]==0
        rows.append(dict(mesh=mesh,mode=mode,seed=amplitude,net_baryon=baryon,outer_charge_change=dq[-1],
                         ordinary_mass=mass[-1],quiet_scalar_mass_coefficient=loading[-1],ordinary_tangent=ordinary[-1],
                         mixed_tangent=gradient[-1],event_ordinary_mass_delta=delta[-1],event_scalar_coefficient_delta=ds[-1],
                         launch_length_mixed_at_6=np.interp(6.,radius,gradient*inverse/root**3+3*ordinary*loading*inverse**2/root**5)))
    return rows


def calculate():
    check()
    signature("setup")
    z=weights()
    rows=[row for mesh in MESHES for row in constraint(mesh)]
    source=Launch(256,.8)
    def transfer(mass):
        return exterior_forecast(SimpleNamespace(charge=source.charge,ordinary=np.array([mass])))
    out=dict(emissions=EMISSIONS,z=z)
    for row in rows:
        if row["mesh"]!=256:
            continue
        mass=row["ordinary_mass"]
        delta=row["event_ordinary_mass_delta"]
        jm=transfer(mass)
        for step,label in ((.0002,"wide"),(.0001,"narrow")):
            mid=mass+delta/2
            slope=(transfer(mid+step)-transfer(mid-step))/(2*step)
            event_delta_jm=slope*delta
            out[row["mode"]+"_"+label]=z*(jm*row["event_scalar_coefficient_delta"]
                                        +event_delta_jm*(row["quiet_scalar_mass_coefficient"]+row["event_scalar_coefficient_delta"]))
    with (HERE/"launch-mass.csv").open("x",newline="") as stream:
        writer=csv.DictWriter(stream,fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    assert not (HERE/"mass-null.npz").exists()
    bridge.archive(HERE/"mass-null.npz",**out)


if __name__=="__main__":
    calculate()

