from functools import lru_cache
from clock_run import *
from scipy.constants import c, parsec

SCALE_RECORD = HERE.parent/"mts-two-radius-pressure-clock-20261119"/"physical-clock-scale.json"
SECONDS = json.loads(SCALE_RECORD.read_bytes())["length_pc"]*parsec/c


def peak(array):
    return float(np.max(np.abs(array)))


@lru_cache(None)
def packet(kind,mesh,eta,mode):
    data = bridge.read(HERE/tag(kind,mesh,eta,mode))
    freeze = "inputs" if kind == "prediction" else "forecast"
    assert data["lock_sha256"].item().decode() == bridge.sha(HERE/(freeze+".json"))
    assert np.array_equal(data["emissions"],EMISSIONS)
    assert all(np.isfinite(data[key]).all() for key in data if data[key].dtype.kind in "fci")
    return data


def response(kind, mesh, eta, part, site, panels):
    key = f"{site}_{panels}"
    def run(mode):
        return packet(kind,mesh,eta,mode)[key]
    if part in ("empty","occupied"):
        return run(part)
    if part == "excess":
        return run("occupied")-run("empty")
    if part == "driven":
        return run("occupied")-run("load")
    return run("load")-run("empty")


def row_error(eta,site,channel,part):
    index = CHANNELS.index(channel)
    def curve(kind,mesh,panels):
        return response(kind,mesh,eta,part,site,panels)[index]
    target = curve("target",256,64)
    value = curve("prediction",256,64)
    index_peak = int(np.argmax(abs(target)))
    norm = peak(target)
    assert norm>0
    terms = [value-target,value-curve("prediction",128,64),target-curve("target",128,64),
             value-curve("prediction",256,32),target-curve("target",256,32)]
    errors = [peak(term)/norm for term in terms]
    total = sum(errors)
    return dict(eta=eta,link=site,channel=channel,part=part,signed_peak=target[index_peak],emission=EMISSIONS[index_peak],
                predicted_at_peak=value[index_peak],model=errors[0],prediction_grid=errors[1],target_grid=errors[2],
                prediction_ray=errors[3],target_ray=errors[4],total=total,passes=total<=TOL)


def source_row(eta,site,channel):
    index = CHANNELS.index(channel)
    all_curves = [response("prediction",256,eta,part,site,64)[index] for part in ("empty","loaded","driven","excess")]
    ordinary,loading,driven,total = all_curves
    norm = peak(total)
    imax = np.argmax(abs(total))
    seed = float(packet("prediction",256,eta,"occupied")["one_percent"])
    assert peak(loading+driven-total)<=1e-12*norm
    def change(part):
        return peak(response("prediction",128,eta,part,site,64)[index]-response("prediction",256,eta,part,site,64)[index])
    return dict(eta=eta,link=site,channel=channel,peak_time=EMISSIONS[imax],seed=seed,ordinary_at_excess_peak=seed*ordinary[imax],
                loading_at_excess_peak=seed*loading[imax],driven_at_excess_peak=seed*driven[imax],excess_at_peak=seed*total[imax],
                excess_vs_ordinary_peak=norm/peak(ordinary),driven_peak_over_excess_peak=peak(driven)/norm,
                loading_grid_over_own_peak=change("loaded")/peak(loading),driven_grid_over_own_peak=change("driven")/peak(driven),
                excess_delay_seconds=(total[imax]*seed*SECONDS if "delay" in channel else ""))


def finite_row(site,channel):
    index = CHANNELS.index(channel)
    def curve(mode):
        return packet("event",256,.8,mode)[f"{site}_64"][index]
    seed = float(packet("event",256,.8,"plus")["amplitude"])
    assert float(packet("event",256,.8,"minus")["amplitude"])==-seed
    assert float(packet("event",256,.8,"quiet")["amplitude"])==0
    positive,negative = curve("plus")-curve("quiet"),curve("minus")-curve("quiet")
    prediction = seed*response("prediction",256,.8,"excess",site,64)[index]
    independent = seed*response("target",256,.8,"excess",site,64)[index]
    odd,even = (positive-negative)/2,(positive+negative)/2
    imax = np.argmax(abs(positive))
    return dict(link=site,channel=channel,positive_peak=positive[imax],positive_peak_time=EMISSIONS[imax],
                negative_peak=negative[np.argmax(abs(negative))],predicted_at_positive_peak=prediction[imax],
                positive_linearity_error=peak(positive-prediction)/peak(positive),
                negative_linearity_error=peak(negative+prediction)/peak(negative),
                odd_vs_forecast=peak(odd-prediction)/peak(odd),odd_vs_independent=peak(odd-independent)/peak(odd),
                even_over_odd=peak(even)/peak(odd),actual_positive_delay_seconds=(positive[imax]*SECONDS if "delay" in channel else ""))


def records():
    check()
    lock("forecast")
    budgets = [row_error(eta,site,channel,part) for eta in CHARGES for site in LOCATIONS
               for channel in CHANNELS for part in ("empty","occupied","excess")]
    sources = [source_row(eta,site,channel) for eta in CHARGES for site in LOCATIONS for channel in CHANNELS]
    finite = [finite_row(site,channel) for site in LOCATIONS for channel in CHANNELS]
    history = []
    for eta in CHARGES:
        prior = bridge.read(PRE/f"driven-{eta:g}-{WAVE}-320.npz")
        saved = prior["series"][::2,0]
        for mesh in MESHES:
            for kind in ("prediction","target"):
                control = packet(kind,mesh,eta,"empty")["central_field"]
                assert np.count_nonzero(control)==0
                wave = packet(kind,mesh,eta,"occupied")["central_field"][:81]
                assert wave[0]==0
                err = peak(saved-wave)/peak(wave)
                history.append(dict(eta=eta,mesh=mesh,solver=kind,relative_to_saved_source=err,
                                    empty_scalar_max=peak(control),passes=err<=TOL))
    return {"clock-budgets.csv":budgets,"source-decomposition.csv":sources,
            "finite-event-check.csv":finite,"prior-driven-field-check.csv":history}


def compare_or_write(tables,create):
    for name,rows in tables.items():
        path = HERE/name
        if create:
            with path.open("x",encoding="utf-8",newline="") as stream:
                writer = csv.DictWriter(stream,fieldnames=list(rows[0]))
                writer.writeheader()
                writer.writerows(rows)
        with path.open(newline="",encoding="utf-8") as stream:
            assert list(csv.DictReader(stream))==[{key:str(val) for key,val in row.items()} for row in rows]


if __name__=="__main__":
    compare_or_write(records(),sys.argv[1]=="create")

