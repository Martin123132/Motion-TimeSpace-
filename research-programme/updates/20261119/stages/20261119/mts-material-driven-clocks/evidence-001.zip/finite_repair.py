from clock_run import *
from math import fsum


def primitive(radius,values):
    assert len(radius)%2==1
    step=radius[1]-radius[0]
    assert np.allclose(np.diff(radius),step,rtol=3e-12,atol=2e-15)
    left,mid,right=values[:-2:2],values[1::2],values[2::2]
    pairs=step/3*(left+4*mid+right)
    out=np.zeros_like(values)
    total=0.
    carry=0.
    for start in range(0,len(pairs),32):
        chunk=pairs[start:start+32]
        end=start+len(chunk)
        out[2*start+2:2*end+1:2]=total+np.cumsum(chunk)
        adjusted=fsum(chunk)-carry
        after=total+adjusted
        carry=(after-total)-adjusted
        total=after
        out[2*end]=total
    out[1::2]=out[:-2:2]+step/12*(5*left+8*mid-right)
    return out


def construct(mesh,amp):
    setup=Launch(mesh,.8)
    radius,inverse=setup.radius,setup.inv
    density,gauss,_,_=profile(radius,WAVE)
    number=setup.number+amp*setup.number[0]*density
    charge=setup.charge+amp*.8*setup.number[0]*gauss
    def mass(occupied):
        value=np.zeros_like(radius)
        for iteration in range(24):
            fac=1-2*value*inverse
            source=number*np.sqrt(fac)+(charge*inverse**2)**2/2
            if occupied:
                source+=(setup.height**2+fac*setup.slope**2)/2
            after=primitive(radius,radius**2*source)
            if iteration>=10 and max(abs(value-after))<1e-18:
                return after
            value=after
        raise ArithmeticError("direct mass")
    empty=mass(False)
    full=mass(True)
    fac=1-2*inverse*empty
    drive=radius**2*(setup.height**2+fac*setup.slope**2)/2
    delta=np.zeros_like(radius)
    for iteration in range(20):
        drag=radius*(2*number/(np.sqrt(fac)+np.sqrt(fac-2*inverse*delta))+setup.slope**2)
        weight=np.exp(primitive(radius,drag))
        after=primitive(radius,weight*drive)/weight
        if max(abs(after-delta))<1e-23:
            delta=after
            break
        delta=after
    else:
        raise ArithmeticError("paired constraint")
    discrepancy=max(abs(full-empty-delta))
    assert discrepancy<2e-17,discrepancy
    weak=np.zeros_like(radius)
    old_empty=nonlinear_mass(setup,number,charge,weak,weak)
    old_full=nonlinear_mass(setup,number,charge,setup.height,setup.slope)
    old_fac=1-2*inverse*old_empty
    old_delta=np.zeros_like(radius)
    for iteration in range(20):
        drag=radius*(2*number/(np.sqrt(old_fac)+np.sqrt(old_fac-2*inverse*old_delta))+setup.slope**2)
        after=kernel(radius,drag,radius**2*(setup.height**2+old_fac*setup.slope**2)/2)
        if max(abs(old_delta-after))<1e-23:
            old_delta=after
            break
        old_delta=after
    pair=.5+.5j
    radial=2*empty*inverse/fac+pair*2*delta*inverse/(fac*(fac-2*inverse*delta))
    picks=setup.picks
    zero=np.zeros(len(picks),dtype=complex)
    field=np.stack((radial[picks],zero,zero,zero,((empty+pair*delta)*inverse**3)[picks],pair*setup.height[picks],
                    zero,number[picks],zero,charge[picks]))
    return field,dict(mesh=mesh,amplitude=amp,old=max(abs(old_full-old_empty-old_delta)),new=discrepancy,
                      kernel_change=max(abs(delta-old_delta)),limit=2e-17)


def repair_lock(create=False):
    lock("forecast")
    data={name:bridge.sha(HERE/name) for name in ("forecast.json","finite_repair.py","FINITE-REPAIR.md")}
    if create:
        write_json("finite-repair-lock.json",data)
    else:
        assert json.loads((HERE/"finite-repair-lock.json").read_bytes())==data


def run(mode):
    check()
    repair_lock()
    mesh=256
    name=tag("event",mesh,.8,mode)
    if (HERE/name).exists():
        raise FileExistsError(name)
    norm=float(bridge.read(PRE/"driven-0.8-4-320.npz")["one_percent"])
    amplitude={"plus":norm,"minus":-norm,"quiet":0.}[mode]
    state,actual=construct(mesh,amplitude)
    _,coarse=construct(128,amplitude)
    system=PairSystem(mesh)
    masks={site:(system.space>=low-.09)&(system.space<=low+.59) for site,low in LOCATIONS.items()}
    strips={site:[] for site in masks}
    steps=int(np.ceil(.01*mesh/.42))
    dt=.01/steps
    for tick in range(450*steps+1):
        if tick%steps==0:
            for site,mask in masks.items():
                metric=state[0,mask]
                length=sqrtp(1+metric)
                curve=prod(state[2,mask],inv(length))
                base=metric.real-metric.imag
                strips[site].append(np.stack((base/(1+np.sqrt(1+base)),curve.real-curve.imag,2*length.imag,2*curve.imag)))
        if tick%(50*steps)==0:
            check()
        if tick==450*steps:
            break
        first=system.rhs(state)
        second=system.rhs(state+.5*dt*first)
        third=system.rhs(state+.5*dt*second)
        fourth=system.rhs(state+dt*third)
        state+=dt/6*(first+2*second+2*third+fourth)
    assert np.isfinite(state).all()
    result=dict(emissions=EMISSIONS,one_percent=norm,time=np.arange(451)*.01,amplitude=amplitude,
                lock_sha256=np.bytes_(bridge.sha(HERE/"forecast.json")),repair_sha256=np.bytes_(bridge.sha(HERE/"finite-repair-lock.json")),
                original_constraint=np.array([coarse["old"],actual["old"]]),repaired_constraint=np.array([coarse["new"],actual["new"]]))
    for site,mask in masks.items():
        bank={site:np.array(strips[site]),site+"_x":system.space[mask],"time":result["time"]}
        for panels in (32,64):
            result[f"{site}_{panels}"]=finite_ray(bank,site,panels)
    bridge.archive(HERE/name,**result)
    print(name,actual,flush=True)


if __name__=="__main__":
    if sys.argv[1]=="freeze":
        repair_lock(True)
    else:
        for mode in sys.argv[1:]:
            run(mode)

