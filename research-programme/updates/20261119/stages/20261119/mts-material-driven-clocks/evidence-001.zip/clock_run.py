from pathlib import Path
import csv
import json
import os
import sys

for variable in ("OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS", "NUMEXPR_NUM_THREADS"):
    os.environ[variable] = "1"
sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
PRE = HERE.parent / "mts-finite-energy-clock-20261119"
sys.path.insert(0, str(PRE))
from experiment import Launch, STEP, EMISSIONS, TOL, RADIUS, LOCATIONS, CHANNELS, bridge, guard, integrate, kernel, rays, np, Radial, Prediction
from stress_series import Weighted
from source import profile, center
from paired_clock import PairSystem, sqrtp, prod, inv, finite_ray

SEAL = "a7c761025f127477177a7a0747c188035584d1b395e5b52dc55865a6594818db"
CHARGES = (0., .8)
MESHES = (128, 256)
MODES = ("empty", "load", "occupied")
WAVE = 4


def check():
    guard()
    assert bridge.sha(PRE/"seal.json") == SEAL and TOL == 2e-5
    if (HERE/"STOP-REQUESTED").exists():
        raise SystemExit("owner hold")


def write_json(name, data):
    with (HERE/name).open("x", encoding="utf-8") as stream:
        json.dump(data, stream, indent=2, sort_keys=True, allow_nan=False)


def tag(kind, mesh, eta, mode):
    return f"{kind}-{mesh}-q{eta:g}-{mode}.npz"


def inputs():
    names = ["clock_run.py", "PROTOCOL.md"]
    stamps = {name: bridge.sha(HERE/name) for name in names}
    for eta in CHARGES:
        name = f"driven-{eta:g}-{WAVE}-320.npz"
        stamps["prior/"+name] = bridge.sha(PRE/name)
        assert stamps["prior/"+name] == json.loads((PRE/"seal.json").read_bytes())["files"][name]
    return dict(parent=SEAL, files=stamps)


def lock(step, create=False):
    data = inputs()
    if step == "forecast":
        assert data == json.loads((HERE/"inputs.json").read_bytes())
        data = {tag("prediction", mesh, eta, mode): bridge.sha(HERE/tag("prediction", mesh, eta, mode))
                for mesh in MESHES for eta in CHARGES for mode in MODES}
        data["inputs.json"] = bridge.sha(HERE/"inputs.json")
    name = step+".json"
    if create:
        write_json(name, data)
    else:
        assert data == json.loads((HERE/name).read_bytes())


class Split(Weighted):
    def __init__(self, mesh, eta, mode):
        Prediction.__init__(self, mesh, eta)
        self.weight = 1.
        self.mode = mode

    def rhs(self, state):
        if self.mode == "load":
            state = state.copy()
            state[8:] = state[8:].real
        result = super().rhs(state)
        if self.mode == "load":
            result[8:] = result[8:].real
        return result


def prepare(mesh, eta, mode, kind):
    setup = Launch(mesh, eta)
    radius, inverse = setup.radius, setup.inv
    density_seed, charge_seed, _, _ = profile(radius, WAVE)
    density_seed *= setup.number[0]
    charge_seed *= eta * setup.number[0]
    inside = radius <= 3.
    normalization = .01 / max(abs(density_seed[inside]/setup.number[inside]))
    prior = bridge.read(PRE/f"driven-{eta:g}-{WAVE}-320.npz")
    assert abs(normalization - float(prior["one_percent"])) < 1e-15
    scalar = setup.height if mode != "empty" else np.zeros_like(radius)
    slope = setup.slope if mode != "empty" else np.zeros_like(radius)
    number = setup.number + 1j*STEP*density_seed
    charge = setup.charge + 1j*STEP*charge_seed
    if kind == "prediction":
        background = setup.quiet if mode != "empty" else setup.ordinary
        fac = 1 - 2*background*inverse
        source = radius**2 * (np.sqrt(fac)*density_seed + setup.charge*charge_seed*inverse**4)
        delta = kernel(radius, radius*(setup.number/np.sqrt(fac) + slope**2), source)
        radial = 2*background*inverse/fac + 1j*STEP*2*inverse*delta/fac**2
        mass = background + 1j*STEP*delta
    else:
        mass = nonlinear_mass(setup, number, charge, scalar, slope)
        radial = 2*mass*inverse/(1-2*mass*inverse)
    picks = setup.picks
    zero = np.zeros(len(picks), dtype=complex)
    state = np.stack((radial[picks],zero,zero,zero,(mass*inverse**3)[picks],
                      scalar[picks],zero,number[picks],zero,charge[picks]))
    if kind == "prediction":
        state = state[[0,1,2,3,4,7,8,9,5,6]]
    return state, normalization, setup.number[0]


def nonlinear_mass(setup, number, charge, scalar, slope):
    inverse, radius = setup.inv, setup.radius
    mass = np.zeros_like(number)
    for iteration in range(24):
        fac = 1-2*mass*inverse
        source = number*np.sqrt(fac) + ((charge*inverse**2)**2 + scalar**2 + fac*slope**2)/2
        after = integrate(radius, radius**2*source)
        if iteration >= 10 and max(abs(after-mass)) < 1e-18:
            return after
        mass = after
    raise ArithmeticError("radial constraint failed")


def finite_initial(mesh, amplitude):
    setup = Launch(mesh,.8)
    radius, inverse = setup.radius, setup.inv
    density_seed, charge_seed, _, _ = profile(radius,WAVE)
    number = setup.number + amplitude*setup.number[0]*density_seed
    charge = setup.charge + amplitude*.8*setup.number[0]*charge_seed
    zeros = np.zeros_like(radius)
    empty = nonlinear_mass(setup,number,charge,zeros,zeros)
    fac = 1-2*inverse*empty
    delta = zeros.copy()
    for iteration in range(20):
        changing = fac-2*inverse*delta
        drag = radius*(2*number/(np.sqrt(fac)+np.sqrt(changing))+setup.slope**2)
        after = kernel(radius,drag,radius**2*(setup.height**2+fac*setup.slope**2)/2)
        if max(abs(after-delta)) < 1e-23:
            delta = after
            break
        delta = after
    else:
        raise ArithmeticError("paired occupation constraint failed")
    direct = nonlinear_mass(setup, number, charge, setup.height, setup.slope)
    assert max(abs(direct-empty-delta)) < 2e-17
    picks = setup.picks
    pair = .5+.5j
    metric = 2*empty*inverse/fac + pair*2*delta*inverse/(fac*(fac-2*delta*inverse))
    zero = np.zeros(len(picks), dtype=complex)
    return np.stack((metric[picks],zero,zero,zero,((empty+pair*delta)*inverse**3)[picks],
                     pair*setup.height[picks],zero,number[picks],zero,charge[picks]))


def simulate(kind, mesh, eta, mode):
    check()
    lock("inputs" if kind == "prediction" else "forecast")
    name = tag(kind,mesh,eta,mode)
    if (HERE/name).exists():
        raise FileExistsError(name)
    paired = kind == "event"
    if paired:
        assert mesh == 256 and eta == .8 and mode in ("plus","minus","quiet")
        norm = float(bridge.read(PRE/"driven-0.8-4-320.npz")["one_percent"])
        amplitude = {"plus":norm,"minus":-norm,"quiet":0.}[mode]
        state = finite_initial(mesh,amplitude)
        solver = PairSystem(mesh)
        space = solver.space
    else:
        assert kind in ("prediction","target") and mode in (MODES if kind=="prediction" else ("empty","occupied"))
        state,norm,density = prepare(mesh,eta,mode,kind)
        solver = Split(mesh,eta,mode) if kind=="prediction" else Radial(mesh,"tensor",0.,eta,RADIUS)
        space = solver.system.x if kind=="prediction" else solver.x
    masks = {site:(space>=low-.09)&(space<=low+.59) for site,low in LOCATIONS.items()}
    strips = {site:[] for site in masks}
    scalar_history = []
    steps = int(np.ceil(.01*mesh/.42))
    dt = .01/steps
    for tick in range(450*steps+1):
        if tick%steps == 0:
            for site,mask in masks.items():
                metric,extrinsic = state[0,mask],state[2,mask]
                if paired:
                    length = sqrtp(1+metric)
                    curve = prod(extrinsic,inv(length))
                    base = metric.real-metric.imag
                    values = (base/(1+np.sqrt(1+base)),curve.real-curve.imag,2*length.imag,2*curve.imag)
                else:
                    length = np.sqrt(1+metric)
                    shift,curve = metric/(1+length),extrinsic/length
                    values = (shift.real,curve.real,shift.imag/STEP,curve.imag/STEP)
                strips[site].append(np.stack(values))
            if not paired:
                scalar_history.append(center(state[8 if kind=="prediction" else 5].imag/STEP)/np.sqrt(density))
        if tick%(50*steps)==0:
            check()
        if tick==450*steps:
            break
        first = solver.rhs(state)
        second = solver.rhs(state+.5*dt*first)
        third = solver.rhs(state+.5*dt*second)
        fourth = solver.rhs(state+dt*third)
        state += dt/6*(first+2*second+2*third+fourth)
    assert np.isfinite(state).all()
    result = dict(emissions=EMISSIONS, one_percent=norm, time=np.arange(451)*.01)
    if paired:
        result["amplitude"] = amplitude
    else:
        result["central_field"] = np.array(scalar_history)
    for site,mask in masks.items():
        bank = {site:np.array(strips[site]),site+"_x":space[mask],"time":result["time"]}
        for panels in (32,64):
            if paired:
                response = finite_ray(bank,site,panels)
            else:
                _,response = rays(bank,site,panels)
            result[f"{site}_{panels}"] = response
    result["lock_sha256"] = np.bytes_(bridge.sha(HERE/("inputs.json" if kind=="prediction" else "forecast.json")))
    bridge.archive(HERE/name,**result)
    print(name,flush=True)


if __name__ == "__main__":
    check()
    if sys.argv[1] == "freeze":
        lock(sys.argv[2],True)
    else:
        kind,mesh,eta = sys.argv[1],int(sys.argv[2]),float(sys.argv[3])
        for mode in sys.argv[4:]:
            simulate(kind,mesh,eta,mode)

