from clock_run import *

DENSITY_ROWS = PRE/"source-ellipse.csv"


def weights():
    with DENSITY_ROWS.open(newline="") as stream:
        row, = [item for item in csv.DictReader(stream) if item["background"]=="conditional_0.1"]
    assert bridge.sha(DENSITY_ROWS)==json.loads((PRE/"seal.json").read_bytes())["files"][DENSITY_ROWS.name]
    assert float(row["reference_density_at_6_GeV_cm3"])==.1
    return float(row["quiet_scalar_multiplier"])**2


def filename(kind,mesh,mode):
    return f"dilute-{kind}-{mesh}-{mode}.npz"


def signature(step,create=False):
    lock("inputs")
    stamps = {name:bridge.sha(HERE/name) for name in ("inputs.json","dilute.py","DILUTE-PROTOCOL.md")}
    stamps["prior_density"] = bridge.sha(DENSITY_ROWS)
    if step=="prediction":
        signature("setup")
        stamps["dilute-setup.json"] = bridge.sha(HERE/"dilute-setup.json")
        for mesh in MESHES:
            for mode in ("plus","minus","quiet"):
                name = filename("prediction",mesh,mode)
                stamps[name] = bridge.sha(HERE/name)
    dest = f"dilute-{step}.json"
    if create:
        write_json(dest,stamps)
    else:
        assert json.loads((HERE/dest).read_bytes())==stamps


def launch(mesh,mode,source):
    setup = Launch(mesh,.8)
    radius,inverse = setup.radius,setup.inv
    shape,charges,_,_ = profile(radius,WAVE)
    seed = float(bridge.read(PRE/"driven-0.8-4-320.npz")["one_percent"])
    amplitude = {"plus":seed,"minus":-seed,"quiet":0.}[mode]
    number = setup.number+amplitude*setup.number[0]*shape
    charge = setup.charge+amplitude*.8*setup.number[0]*charges
    zeros = np.zeros_like(radius)
    mass = nonlinear_mass(setup,number,charge,zeros,zeros)
    fac = 1-2*inverse*mass
    scalar,slope = setup.height,setup.slope
    index = setup.picks
    zero = np.zeros(len(index),dtype=complex)
    drive = radius**2*(fac*slope**2+scalar**2)/2
    if source=="prediction":
        dm = kernel(radius,radius*number/np.sqrt(fac),drive)
        radial = 2*mass*inverse/fac+1j*STEP*2*inverse*dm/fac**2
        return np.stack((radial[index],zero,zero,zero,((mass+1j*STEP*dm)*inverse**3)[index],
                         number[index],zero,charge[index],(1+.5j)*scalar[index],zero))
    weight = weights()
    delta = zeros.copy()
    for iteration in range(20):
        drag = radius*(2*number/(np.sqrt(fac)+np.sqrt(fac-2*inverse*delta))+weight*slope**2)
        after = kernel(radius,drag,weight*drive)
        if max(abs(delta-after)) <= 4e-15*max(abs(after)):
            delta = after
            break
        delta = after
    else:
        raise ArithmeticError("finite dilute constraint")
    pair = .5+.5j
    radial = 2*mass*inverse/fac+pair*2*inverse*delta/(fac*(fac-2*inverse*delta))
    return np.stack((radial[index],zero,zero,zero,((mass+pair*delta)*inverse**3)[index],
                     pair*np.sqrt(weight)*scalar[index],zero,number[index],zero,charge[index]))


def run(kind,mesh,mode):
    check()
    signature("setup" if kind=="prediction" else "prediction")
    name = filename(kind,mesh,mode)
    if (HERE/name).exists():
        raise FileExistsError(name)
    paired = kind=="target"
    solver = PairSystem(mesh) if paired else Prediction(mesh,.8)
    space = solver.space if paired else solver.system.x
    state = launch(mesh,mode,kind)
    masks = {site:(space>=low-.09)&(space<=low+.59) for site,low in LOCATIONS.items()}
    strips = {site:[] for site in masks}
    steps = int(np.ceil(.01*mesh/.42))
    dt = .01/steps
    for tick in range(450*steps+1):
        if tick%steps==0:
            for site,mask in masks.items():
                comp,extrinsic = state[0,mask],state[2,mask]
                if paired:
                    length=sqrtp(1+comp)
                    curve=prod(extrinsic,inv(length))
                    base=comp.real-comp.imag
                    pieces=(base/(1+np.sqrt(1+base)),curve.real-curve.imag,2*length.imag,2*curve.imag)
                else:
                    length=np.sqrt(1+comp)
                    shift,curve=comp/(1+length),extrinsic/length
                    pieces=(shift.real,curve.real,shift.imag/STEP,curve.imag/STEP)
                strips[site].append(np.stack(pieces))
        if tick%(50*steps)==0:
            check()
        if tick==450*steps:
            break
        first=solver.rhs(state)
        second=solver.rhs(state+.5*dt*first)
        third=solver.rhs(state+.5*dt*second)
        fourth=solver.rhs(state+dt*third)
        state+=dt/6*(first+2*second+2*third+fourth)
    assert np.isfinite(state).all()
    result=dict(emissions=EMISSIONS,z=weights(),lock_sha256=np.bytes_(bridge.sha(HERE/("dilute-prediction.json" if paired else "dilute-setup.json"))))
    for site,mask in masks.items():
        data={site:np.array(strips[site]),site+"_x":space[mask],"time":np.arange(451)*.01}
        for panels in (32,64):
            result[f"{site}_{panels}"] = finite_ray(data,site,panels) if paired else weights()*rays(data,site,panels)[1]
    bridge.archive(HERE/name,**result)
    print(name,flush=True)


if __name__=="__main__":
    check()
    if sys.argv[1]=="freeze":
        signature(sys.argv[2],True)
    else:
        assert sys.argv[1] in ("prediction","target")
        for mode in sys.argv[3:]:
            run(sys.argv[1],int(sys.argv[2]),mode)

