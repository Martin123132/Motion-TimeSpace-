from mean_weight_bound import *


def main():
    modest()
    before=mp.mp.dps
    background=SavedBackground('heavy')
    after=mp.mp.dps
    output=[]
    for frequency in map(mp.mpf,('200000000','300000000','400000000')):
        amplitude=mp.mpf('1.5')
        for theta in map(mp.mpf,('0','.419','1.157','2.287','3')):
            probability=lambda value:mp.sqrt(value**2-amplitude**2)/(mp.pi*(value-amplitude*mp.sin(2*theta)))
            expected=probability(frequency)*amplitude*(amplitude-frequency*mp.sin(2*theta))/((frequency**2-amplitude**2)*(frequency-amplitude*mp.sin(2*theta)))
            default=mp.diff(probability,frequency)
            guarded=mp.diff(probability,frequency,addprec=80)
            output.append(dict(mu=str(frequency),theta=str(theta),default_relative=str(abs(default-expected)/abs(expected)),guarded_relative=str(abs(guarded-expected)/abs(expected))))
    write(STAGE/'weight-diagnosis.json',dict(dps_before=before,dps_after=after,reports=output,physical_gates_changed=False))
    print(json.dumps(output[:5],indent=2),flush=True)


if __name__=='__main__':
    main()
