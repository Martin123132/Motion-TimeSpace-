from common import *
from mean_weight_bound import symbolic


def main():
    modest()
    output=STAGE/'audit'
    output.mkdir(exist_ok=False)
    inputs=verify_inputs()
    sealed={}
    for folder in (FREE,FULL,EXACT):
        sealed.update({str(Path(item['path'])):item['sha256'] for item in read(folder/'closeout.json')['artifacts']})
    consumed={}
    paths=[]
    for label in ('half','balanced','double'):
        parent=FREE/label/('free-01' if label=='half' else 'free-02')
        for model in ('heavy','cold'):
            paths.extend(FREE/'source-envelope'/f'{label}-{model}-{kind}.json' for kind in ('envelope','thermal-jets'))
            paths.extend(FULL/label/'full-01'/(model+suffix) for suffix in ('-constants.json','-thermal.npz'))
            for index in range(3):
                paths.append(EXACT/label/'jets-01'/f'{model}-{index}-freeze.json')
                paths.append(parent/f'{model}-{index}-frozen.npz')
    for path in paths:
        require(str(path) in sealed and digest(path)==sealed[str(path)],'sealed source/bank inputs unchanged')
        consumed[str(path)]=sealed[str(path)]
    accepted={}
    def accept(path):
        result=read(path)
        require(result['passed'] and result['inputs']==inputs,'same-parent accepted result')
        for source,seal in result['sources'].items():
            require(digest(source)==seal,'exact executed sources unchanged')
        for target,seal in result.get('frozen',{}).items():
            require(digest(target)==seal,'prediction/enclosure frozen before check')
        accepted[str(path)]=digest(path)
        return result
    counts=dict(sparse_branch_cases=0,symmetric_branch_cases=0,independent_gradient_entries=0,background_fixtures=0,complete_enclosures=0)
    maxima={}
    def maximum(name,value):
        maxima[name]=max(maxima.get(name,0.),value)
    source=accept(STAGE/'sparse-validation/result.json')
    require(len(source['reports'])==108 and source['full_g192_support'],'full sparse support')
    for report in source['reports']:
        require(report['relative']<ALGEBRA and report['absolute']<GATE and report['remote_entries']>0,'retained dense source and untouched remote rows')
        maximum('sparse_relative',report['relative'])
        maximum('sparse_absolute',report['absolute'])
        counts['sparse_branch_cases']+=1
    sym=accept(STAGE/'symmetric-validation/result.json')
    require(len(sym['reports'])==72,'all symmetric validation states')
    for report in sym['reports']:
        require(report['absolute']<ALGEBRA,'exactly structured symmetric part')
        maximum('symmetric_absolute',report['absolute'])
        counts['symmetric_branch_cases']+=1
    table=[]
    for label in ('half','balanced','double'):
        envelope=accept(STAGE/label/'envelope-01/result.json')
        require(envelope['full_closed_generator_background_envelope'] and len(envelope['reports'])==2,'both full coupled envelopes')
        for report in envelope['reports']:
            require(digest(report['path'])==report['sha256'],'envelope artifact intact')
            value=read(report['path'])
            require(value['full_g192'] and all(len(slots)==190 for slots in value['layout']['tail_by_node']),'all retained G192 levels')
            require(not value['sampled_maximum_used_as_supremum'] and value['interval_digits']==50,'interval rather than sampled bound')
            require(digest(value['parent_free_path'])==value['parent_free_sha256'] and digest(value['thermal_path'])==value['thermal_sha256'],'parent box and thermal jets unchanged')
            accepted[report['path']]=report['sha256']
            counts['complete_enclosures']+=2
            table.append(dict(label=label,**report))
        validation=accept(STAGE/label/'validation-01/result.json')
        require(len(validation['reports'])==6 and validation['full_g192'] and validation['precision_digits']==70,'all independent whole-source states')
        for report in validation['reports']:
            require(report['maximum_derivative_ratio']<=1 and report['maximum_fixture_frobenius_ratio']<=1,'strict reported bound ratios despite arithmetic comparison floor')
            require(report['step_refinement_relative']<1e-30,'independent differentiation step refinement')
            counts['independent_gradient_entries']+=report['gradient_entries']
            counts['background_fixtures']+=report['fixtures']
            for name in ('maximum_derivative_ratio','maximum_fixture_frobenius_ratio','step_refinement_relative'):
                maximum(name,report[name])
    weight=accept(STAGE/'mean-weight/result.json')
    require(weight['phase_measure_included'] and weight['symbolic']==symbolic() and len(weight['reports'])==3,'normalized phase-clock measure proved and evaluated')
    for record in weight['reports']:
        require(record['mu_interval'][0]>1.5,'uniform clock margin')
        for check in record['independent_checks']:
            require(check['integral_relative']<1e-60 and check['maximum_integrand_ratio']<=1,'independent period/weight verification')
        for branch,value in record['branches'].items():
            inherited=read(STAGE/record['label']/'envelope-01/heavy-envelope.json')['branches'][branch]
            require(value['full_mean_replacement']>=inherited['full']['operator_bound'] and value['symmetric_mean_replacement']>=inherited['symmetric']['operator_bound'],'clock-weight uncertainty included, never subtracted')
    for path in STAGE.glob('*.py'):
        compile(path.read_text(encoding='utf-8-sig'),str(path),'exec')
    require(not list(STAGE.rglob('__pycache__')),'no bytecode residue')
    write(output/'result.json',dict(passed=True,inputs=inputs,sources=sources(),consumed=consumed,accepted_results=accepted,
        counts=counts,maxima=maxima,envelopes=table,phase_means=weight['reports'],symbolic=weight['symbolic'],
        failed_attempts_preserved=[],compiler_receipts=[],full_coupled_background_envelope=True,symmetric_growth_error_envelope=True,
        normalized_phase_measure_enclosed=True,total_transport_error=False,new_initial_mode=False,gate=GATE,algebra=ALGEBRA))
    print(json.dumps(dict(passed=True,counts=counts,maxima=maxima),indent=2),flush=True)


if __name__=='__main__':
    main()
