from common import *
from cold_access import SavedBackground
from source_laws import exterior
from background_jet import BackgroundJet,variable
from factored_sparse import evaluate
from symmetric_source import evaluate as symmetric
from interval_math import interval,lower,upper,magnitude
from interval_jets import sparse_bound
import mpmath as mp
import sympy as sp


mp.mp.dps=70


def value_bound(entries):
    row_sums={}
    column_sums={}
    square=interval(0)
    for (row,column),entry in entries.items():
        amount=interval(magnitude(entry.value))
        row_sums[row]=row_sums.get(row,interval(0))+amount
        column_sums[column]=column_sums.get(column,interval(0))+amount
        square+=amount**2
    norm_infinity=max(upper(value) for value in row_sums.values())
    norm_one=max(upper(value) for value in column_sums.values())
    return min(upper(mp.iv.sqrt(square)),upper(mp.iv.sqrt(interval(norm_infinity)*interval(norm_one))))


def symbolic():
    frequency,amplitude,sine=sp.symbols('mu a s',real=True)
    logarithmic=frequency/(frequency**2-amplitude**2)-1/(frequency-amplitude*sine)
    numerator=amplitude*(amplitude-frequency*sine)/((frequency**2-amplitude**2)*(frequency-amplitude*sine))
    checks=dict(normalized_log_derivative=sp.factor(logarithmic-numerator)==0,
        uniform_majorant=sp.factor(amplitude*(frequency+amplitude)/((frequency**2-amplitude**2)*(frequency-amplitude))-amplitude/(frequency-amplitude)**2)==0)
    speed,width,hubble,wave=sp.symbols('v w H k',positive=True)
    first_pair=(-width*wave/(sp.sqrt(3)*hubble)+speed**2*wave/(sp.sqrt(3)*hubble*width))/2
    checks['massive_symmetric_streaming']=sp.factor((first_pair+2*hubble/(sp.sqrt(3)*wave*width))*width).subs(width**2,speed**2+4*hubble**2/wave**2).simplify()==0
    require(all(checks.values()),'exact normalized clock weight and streaming identities')
    return checks


def weight_check(frequency):
    amplitude=mp.mpf('1.5')
    kernel=lambda theta:1/(frequency-amplitude*mp.sin(2*theta))
    integral=mp.quad(kernel,[0,mp.pi/4,mp.pi/2,3*mp.pi/4,mp.pi])
    expected=mp.pi/mp.sqrt(frequency**2-amplitude**2)
    require(abs(integral-expected)<mp.mpf('1e-60')*abs(expected),'independent phase-period integral')
    bound=amplitude/(frequency-amplitude)**2
    largest=mp.mpf(0)
    default_error=mp.mpf(0)
    for theta in map(mp.mpf,('0','.419','1.157','2.287','3')):
        probability=lambda value:mp.sqrt(value**2-amplitude**2)/(mp.pi*(value-amplitude*mp.sin(2*theta)))
        derivative=mp.diff(probability,frequency,addprec=80)
        expected_rate=probability(frequency)*amplitude*(amplitude-frequency*mp.sin(2*theta))/((frequency**2-amplitude**2)*(frequency-amplitude*mp.sin(2*theta)))
        default_error=max(default_error,abs(mp.diff(probability,frequency)-expected_rate)/abs(expected_rate))
        require(abs(derivative-expected_rate)<mp.mpf('1e-55')*abs(expected_rate),'independent normalized-clock derivative')
        ratio=abs(derivative)/(probability(frequency)*bound)
        require(ratio<=1,'normalized derivative L1 integrand bound')
        largest=max(largest,ratio)
    return dict(integral_relative=float(abs(integral-expected)/abs(expected)),maximum_integrand_ratio=float(largest),default_derivative_relative=float(default_error),derivative_addprec_bits=80)


def main():
    modest()
    output=STAGE/'mean-weight-02'
    output.mkdir(exist_ok=False)
    inputs=verify_inputs()
    frozen={str(STAGE/label/'envelope-01'/f'{model}-envelope.json'):digest(STAGE/label/'envelope-01'/f'{model}-envelope.json') for label in ('half','balanced','double') for model in ('heavy','cold')}
    write(output/'freeze.json',dict(inputs=inputs,sources=sources(),frozen=frozen,interval_digits=mp.iv.dps,check_digits=70,
        method='normalized phase-clock measure derivative; no new phase grid or trajectory',gate=GATE,algebra=ALGEBRA))
    checks=symbolic()
    reports=[]
    for label in ('half','balanced','double'):
        guard()
        envelope=read(STAGE/label/'envelope-01/heavy-envelope.json')
        background=SavedBackground('heavy')
        box=envelope['state_box']
        layout=envelope['layout']
        constants=read(FULL/label/'full-01/heavy-constants.json')
        raw=exterior(background,constants,interval(box['efold']),interval,mp.iv.exp)
        source={name:[BackgroundJet(value) for value in item] if isinstance(item,list) else BackgroundJet(item) for name,item in raw.items()}
        thermal_parent=read(FREE/'source-envelope'/f'{label}-heavy-thermal-jets.json')
        thermal={name:{key:BackgroundJet(interval(value)) for key,value in record.items()} for name,record in thermal_parent['extrema'].items()}
        values=[variable(box['slow'],0),variable(box['slow'],1),variable(box['rho'],2),variable(box['clock'],3)]
        cosine,sine=BackgroundJet(interval([-1,1])),BackgroundJet(interval([-1,1]))
        wave=dict(read(WAVES)['waves'])[label]
        full=evaluate(layout,source,background.masses,wave,values,thermal,cosine,sine)
        sym=symmetric(layout,source,background.masses,wave,values,thermal,cosine,sine,full)
        frequency=source['scale']*background.masses[1]/full['metric']['hubble'].value
        minimum,maximum=lower(frequency.value),upper(frequency.value)
        require(minimum>1.5,'positive phase-clock whole-tube margin')
        sensitivity=sparse_bound({(0,0):frequency},envelope['errors'])
        change=sensitivity['operator_bound']
        weight=upper(interval(1.5)*interval(change)/(interval(minimum)-interval(1.5))**2)
        branches={}
        for branch in ('gr','poisson-spatial'):
            full_size=value_bound(full['branches'][branch])
            sym_size=value_bound(sym['branches'][branch])
            full_extra=upper(interval(weight)*interval(full_size))
            sym_extra=upper(interval(weight)*interval(sym_size))
            branches[branch]=dict(full_source_norm=full_size,symmetric_source_norm=sym_size,
                full_clock_measure_extra=full_extra,symmetric_clock_measure_extra=sym_extra,
                full_mean_replacement=upper(interval(envelope['branches'][branch]['full']['operator_bound'])+interval(full_extra)),
                symmetric_mean_replacement=upper(interval(envelope['branches'][branch]['symmetric']['operator_bound'])+interval(sym_extra)))
        precision=[weight_check(mp.mpf(value)) for value in (minimum,(minimum+maximum)/2,maximum)]
        record=dict(label=label,model='heavy',mu_interval=[minimum,maximum],mu_sensitivity=sensitivity,normalized_weight_L1_change=weight,
            branches=branches,independent_checks=precision,baseline='no heavy phase map: retained phase-independent baseline; no extra normalized-weight uncertainty',
            scope='same-N slow-background replacement of continuous phase mean; finite-grid arithmetic and moving-slow averaging remainder remain separate')
        write(output/(label+'-bound.json'),record)
        reports.append(record)
        print(label,'phase-mean source bound',branches,flush=True)
    require(all(digest(path)==value for path,value in frozen.items()),'original envelope frozen')
    write(output/'result.json',dict(passed=True,inputs=inputs,sources=sources(),frozen=frozen,symbolic=checks,reports=reports,
        total_transport_error=False,phase_measure_included=True))


if __name__=='__main__':
    main()
