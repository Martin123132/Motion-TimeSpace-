from common import require
from interval_math import interval,lower


class BackgroundJet:
    def __init__(self,value,gradient=None):
        self.value=value if hasattr(value,'_mpi_') else interval(value)
        self.gradient=[interval(0) for _ in range(4)] if gradient is None else [item if hasattr(item,'_mpi_') else interval(item) for item in gradient]

    @staticmethod
    def cast(value):
        return value if isinstance(value,BackgroundJet) else BackgroundJet(value)

    def __add__(self,other):
        other=self.cast(other)
        return BackgroundJet(self.value+other.value,[left+right for left,right in zip(self.gradient,other.gradient)])

    __radd__=__add__

    def __neg__(self):
        return BackgroundJet(-self.value,[-entry for entry in self.gradient])

    def __sub__(self,other):
        return self+-self.cast(other)

    def __rsub__(self,other):
        return self.cast(other)+-self

    def __mul__(self,other):
        other=self.cast(other)
        return BackgroundJet(self.value*other.value,[left*other.value+self.value*right for left,right in zip(self.gradient,other.gradient)])

    __rmul__=__mul__

    def __truediv__(self,other):
        other=self.cast(other)
        require(lower(abs(other.value))>0,'background divisor excludes zero')
        return BackgroundJet(self.value/other.value,[(left*other.value-self.value*right)/other.value**2 for left,right in zip(self.gradient,other.gradient)])

    def __rtruediv__(self,other):
        return self.cast(other)/self

    def __pow__(self,power):
        require(power in (0,1,2,-1,.5,-.5),'supported exact mixed-jet powers')
        if power==0:
            return BackgroundJet(1)
        if power==1:
            return self
        if power in (-1,.5,-.5):
            require(lower(self.value)>0,'positive source for inverse/root')
        value=self.value**power
        factor=power*self.value**(power-1)
        return BackgroundJet(value,[factor*entry for entry in self.gradient])


def variable(value,component):
    gradient=[0]*4
    gradient[component]=1
    return BackgroundJet(value,gradient)


def is_zero(value):
    if isinstance(value,BackgroundJet):
        return value.value==0 and all(entry==0 for entry in value.gradient)
    return value==0
