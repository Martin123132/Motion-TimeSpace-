from common import *
from cold_access import SavedBackground
from factored_sparse import evaluate
from symmetric_source import evaluate as symmetric
from enclose_free import complete_layout
import numpy as np


def main():
    modest()
    output=STAGE/'symmetric-validation'
    output.mkdir(exist_ok=False)
    inputs=verify_inputs()
    write(output/'freeze.json',dict(inputs=inputs,sources=sources(),angles=[.371,2.109],gate=GATE,algebra=ALGEBRA))
    reports=[]
    for label in ('half','balanced','double'):
        wave=dict(read(WAVES)['waves'])[label]
        for model in ('heavy','cold'):
            masses=SavedBackground(model).masses
            for index in range(3):
                guard()
                saved=read(EXACT/label/'jets-01'/f'{model}-{index}-freeze.json')
                source,values,thermal=(saved[name] for name in ('source','values','thermal'))
                layout=complete_layout(saved['layout'])
                for theta in (.371,2.109):
                    cosine,sine=np.cos(2*theta),np.sin(2*theta)
                    full=evaluate(layout,source,masses,wave,values,thermal,cosine,sine)
                    parts=symmetric(layout,source,masses,wave,values,thermal,cosine,sine,full)
                    for branch in ('gr','poisson-spatial'):
                        actual=full['branches'][branch]
                        expected=parts['branches'][branch]
                        keys=set(actual)|{(column,row) for row,column in actual}|set(expected)
                        maximum=max(abs(expected.get(key,0)-(actual.get(key,0)+actual.get((key[1],key[0]),0))/2) for key in keys)
                        require(maximum<ALGEBRA,'source-derived symmetric part equals full generator symmetric part')
                        reports.append(dict(label=label,model=model,index=index,theta=theta,branch=branch,absolute=maximum,entries=len(keys)))
                print(label,model,index,'structured symmetric part passed',flush=True)
    write(output/'result.json',dict(passed=True,inputs=inputs,sources=sources(),reports=reports,streaming_skew_cancelled_before_interval_estimate=True))


if __name__=='__main__':
    main()
