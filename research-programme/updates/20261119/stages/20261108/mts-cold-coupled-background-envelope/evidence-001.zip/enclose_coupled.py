from common import *
from cold_access import SavedBackground
from source_laws import exterior
from background_jet import BackgroundJet,variable
from factored_sparse import evaluate
from symmetric_source import evaluate as symmetric
from interval_math import interval
from interval_jets import sparse_bound
import mpmath as mp


def main():
    modest()
    require(LABEL!='summary','one inherited family per batch')
    output=ROOT/'envelope-01'
    output.mkdir(parents=True,exist_ok=False)
    inputs=verify_inputs()
    for name in ('sparse-validation','symmetric-validation'):
        require(read(STAGE/name/'result.json')['passed'],'source factorization qualified')
    write(output/'freeze.json',dict(inputs=inputs,sources=sources(),interval_digits=mp.iv.dps,gate=GATE,algebra=ALGEBRA,
        scope='whole saved cold tube at equal N and phase; same retained finite thermal source and full G192; mixed directional/background derivatives'))
    reports=[]
    for model in ('heavy','cold'):
        guard()
        background=SavedBackground(model)
        parent_path=FREE/'source-envelope'/f'{LABEL}-{model}-envelope.json'
        parent=read(parent_path)
        thermal_path=FREE/'source-envelope'/f'{LABEL}-{model}-thermal-jets.json'
        thermal_parent=read(thermal_path)
        box=parent['state_box']
        layout=parent['layout']
        constants=read(FULL/LABEL/f'full-01/{model}-constants.json')
        raw=exterior(background,constants,interval(box['efold']),interval,mp.iv.exp)
        source={name:[BackgroundJet(value) for value in entry] if isinstance(entry,list) else BackgroundJet(entry) for name,entry in raw.items()}
        thermal={name:{key:BackgroundJet(interval(value)) for key,value in record.items()} for name,record in thermal_parent['extrema'].items()}
        values=[variable(box['slow'],0),variable(box['slow'],1),variable(box['rho'],2) if model=='heavy' else BackgroundJet(0),variable(box['clock'],3)]
        cosine,sine=BackgroundJet(interval([-1,1])),BackgroundJet(interval([-1,1]))
        coefficients=evaluate(layout,source,background.masses,WAVE,values,thermal,cosine,sine)
        symmetric_part=symmetric(layout,source,background.masses,WAVE,values,thermal,cosine,sine,coefficients)
        result=dict(label=LABEL,model=model,layout=layout,state_box=box,errors=parent['errors'],
            parent_free_path=str(parent_path),parent_free_sha256=digest(parent_path),thermal_path=str(thermal_path),thermal_sha256=digest(thermal_path),
            normal_free=sparse_bound(coefficients['normal_free'],parent['errors']),
            normal_symmetric=sparse_bound(symmetric_part['normal_free'],parent['errors']),
            branches={branch:dict(full=sparse_bound(entries,parent['errors']),symmetric=sparse_bound(symmetric_part['branches'][branch],parent['errors'])) for branch,entries in coefficients['branches'].items()},
            sampled_maximum_used_as_supremum=False,interval_digits=mp.iv.dps,full_g192=True,
            scope='absolute coefficient replacement at equal N and phase; symmetric bound controls perturbation of logarithmic norm, not total transport error')
        path=output/(model+'-envelope.json')
        write(path,result)
        report=dict(model=model,path=str(path),sha256=digest(path),branches={branch:{name:record[name]['operator_bound'] for name in ('full','symmetric')} for branch,record in result['branches'].items()},
            normal_free=result['normal_free']['operator_bound'],normal_symmetric=result['normal_symmetric']['operator_bound'])
        reports.append(report)
        print(LABEL,model,'coupled background bound',report,flush=True)
    write(output/'result.json',dict(passed=True,inputs=inputs,sources=sources(),reports=reports,
        full_closed_generator_background_envelope=True,total_transport_error=False,gate=GATE,algebra=ALGEBRA))


if __name__=='__main__':
    main()
