from common import *
from cold_access import SavedBackground
from factored_sparse import evaluate
from enclose_free import complete_layout
from coupled_jets import evaluate as direct
from stable_coupled import assemble
from mean_math import relative_error
import numpy as np


def main():
    modest()
    output=STAGE/'sparse-validation'
    output.mkdir(exist_ok=False)
    inputs=verify_inputs()
    write(output/'freeze.json',dict(inputs=inputs,sources=sources(),angles=[.239,1.157,2.613],gate=GATE,algebra=ALGEBRA,
        scope='full G192 sparse support with retained exact-generator block and untouched remote free rows'))
    reports=[]
    for label in ('half','balanced','double'):
        wave=dict(read(WAVES)['waves'])[label]
        for model in ('heavy','cold'):
            masses=SavedBackground(model).masses
            for index in range(3):
                guard()
                freeze=read(EXACT/label/'jets-01'/f'{model}-{index}-freeze.json')
                source,values,thermal,short=(freeze[name] for name in ('source','values','thermal','layout'))
                layout=complete_layout(short)
                for theta in (.239,1.157,2.613):
                    sparse=evaluate(layout,source,masses,wave,values,thermal,np.cos(2*theta),np.sin(2*theta))
                    original=direct(short,source,masses,wave,values,thermal,theta)
                    stable=assemble(short,source,masses,wave,values,thermal,theta,original)
                    for branch in ('gr','poisson-spatial'):
                        local=np.zeros((short['size'],short['size']))
                        remote=0
                        for (row,column),value in sparse['branches'][branch].items():
                            if row<short['size'] and column<short['size']:
                                local[row,column]=value
                            else:
                                require(value==sparse['normal_free'].get((row,column),0),'remote G192 source unchanged by metric correction')
                                remote+=1
                        error=relative_error(local,stable[branch])
                        absolute=float(np.max(abs(local-stable[branch])))
                        require(error<ALGEBRA and absolute<GATE,'sparse cancellation agrees with accepted dense generator')
                        reports.append(dict(label=label,model=model,index=index,theta=theta,branch=branch,relative=error,absolute=absolute,
                            full_size=layout['size'],remote_entries=remote,nonzeros=len(sparse['branches'][branch])))
                print(label,model,index,'sparse full support passed',flush=True)
    write(output/'result.json',dict(passed=True,inputs=inputs,sources=sources(),reports=reports,full_g192_support=True))


if __name__=='__main__':
    main()
