from common import *
from source_laws import metric_arguments
from full_metric_math import rows,multiply,inverse2,add,scale
from metric_math import affine_map
from free_math_v2 import build
from tangent import Tangent
from background_jet import is_zero


def parts(matrix):
    value=[[item.value if isinstance(item,Tangent) else item for item in row] for row in matrix]
    rate=[[item.rate if isinstance(item,Tangent) else 0 for item in row] for row in matrix]
    return value,rate


def sparse(matrix):
    return {(row,column):value for row,entries in enumerate(matrix) for column,value in enumerate(entries) if not is_zero(value)}


def plus(destination,row,column,value):
    if not is_zero(value):
        destination[(row,column)]=destination.get((row,column),0)+value


def product(left,right):
    right_rows={}
    for (row,column),value in right.items():
        right_rows.setdefault(row,[]).append((column,value))
    result={}
    for (row,inner),value in left.items():
        for column,other in right_rows.get(inner,[]):
            plus(result,row,column,value*other)
    return result


def combine(left,right,factor=1):
    result=dict(left)
    for (row,column),value in right.items():
        plus(result,row,column,factor*value)
    return result


def left_heavy(matrix,inverse,heavy):
    result={key:value for key,value in matrix.items() if key[0] not in heavy}
    lookup={row:index for index,row in enumerate(heavy)}
    for (row,column),value in matrix.items():
        if row in lookup:
            for index,target in enumerate(heavy):
                plus(result,target,column,inverse[index][lookup[row]]*value)
    return result


def canonical(alpha,mu,eta0,fraction,cosine,sine):
    mean=[[0,-1],[alpha**2/4,-1-eta0]]
    cos_matrix=[[0,1],[alpha**2/4,-3-fraction]]
    sin_matrix=[[alpha/2,-6/alpha],[0,-alpha/2]]
    generator=add(mean,add(scale(cos_matrix,cosine),scale(sin_matrix,sine)))
    numerator=add(scale(cos_matrix,sine),scale(sin_matrix,cosine),-1)
    primitive=scale(numerator,1/(2*mu))
    eta=eta0+fraction*cosine
    alpha_rate=-(1+eta)*alpha
    fraction_rate=fraction*(-1-2*eta0+(3-2*fraction)*cosine)
    cos_rate=[[0,0],[alpha*alpha_rate/2,-fraction_rate]]
    sin_rate=[[alpha_rate/2,6*alpha_rate/alpha**2],[0,-alpha_rate/2]]
    partial=scale(add(add(scale(cos_rate,sine),scale(sin_rate,cosine),-1),scale(numerator,1-eta),-1),1/(2*mu))
    angular=scale(add(scale(cos_matrix,cosine),scale(sin_matrix,sine)),1/mu)
    remainder=add(add(add(multiply(generator,primitive),multiply(primitive,mean),-1),partial,-1),scale(angular,1.5*sine))
    inverse=inverse2(add([[1,0],[0,1]],primitive))
    transformed=add(mean,multiply(inverse,remainder))
    return transformed,inverse


def evaluate(layout,source,masses,wave,values,thermal,cosine,sine):
    fields,tangents=metric_arguments(source,masses,wave,values,thermal,cosine,sine)
    tangents.pop('clock')
    metric=rows(layout,**fields,**tangents)
    free_source={name:source[name] for name in ('fluid','massive','speeds','density','enthalpy','scale')}
    free=build(layout,free_source,thermal['sound']['value'],thermal['opacity']['value'],masses,wave,*values,cosine,sine)
    heavy=layout['heavy']
    if not heavy:
        branches={branch:combine(free['free'],product(free['injection'],sparse(parts(metric['physical'][branch])[0]))) for branch in ('gr','poisson-spatial')}
        return dict(branches=branches,normal_free=free['free'],corrections={},metric=metric)
    hubble=metric['hubble'].value
    omega=source['scale']*masses[1]
    alpha=wave**2/(omega*hubble)
    mu=omega/hubble
    fraction=values[2]/(2*hubble**2)
    eta0=1-(source['enthalpy']+values[1]**2+values[2])/(2*hubble**2)
    gamma=eta0-.5+(1.5+fraction)*cosine
    transformed,inverse=canonical(alpha,mu,eta0,fraction,cosine,sine)
    normal_free=dict(free['free'])
    for row in range(2):
        for column in range(2):
            normal_free[(heavy[row],heavy[column])]=transformed[row][column]+(gamma if row==column else 0)
    weight=tangents['rho']**.5*metric['hubble']/wave
    affine=affine_map(tangents['rho'],metric['hubble'],fields['scale_factor']*masses[1],wave,tangents['cosine'],tangents['sine'])
    affine_value,affine_rate=parts([[weight*entry for entry in row] for row in affine])
    physical_affine={(heavy[row],column):value for (row,column),value in sparse(affine_value).items()}
    physical_rate={(heavy[row],column):value for (row,column),value in sparse(affine_rate).items()}
    first=combine(combine(product(free['free'],physical_affine),physical_rate,-1),free['injection'])
    branches={}
    corrections={}
    for branch in ('gr','poisson-spatial'):
        value,rate=parts(metric['physical'][branch])
        readout,readout_rate=sparse(value),sparse(rate)
        derivative=combine(combine(readout_rate,product(readout,free['free'])),product(product(readout,free['injection']),readout))
        correction=combine(product(first,readout),product(physical_affine,derivative),-1)
        correction=left_heavy(correction,inverse,heavy)
        forward,_=parts(metric['maps'][branch]['forward_correction'])
        forward={(heavy[row],column):entry for (row,column),entry in sparse(forward).items()}
        correction=combine(correction,product(correction,forward))
        branches[branch]=combine(normal_free,correction)
        corrections[branch]=correction
    return dict(branches=branches,normal_free=normal_free,corrections=corrections,metric=metric)
