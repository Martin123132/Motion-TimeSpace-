from free_math_v2 import build
from factored_sparse import parts,sparse,product,combine,plus


def symmetric(matrix):
    result={}
    pairs={tuple(sorted(key)) for key in matrix}
    for row,column in sorted(pairs):
        value=(matrix.get((row,column),0)+matrix.get((column,row),0))/2
        plus(result,row,column,value)
        if row!=column:
            plus(result,column,row,value)
    return result


def evaluate(layout,source,masses,wave,values,thermal,cosine,sine,factored):
    free_source={name:source[name] for name in ('fluid','massive','speeds','density','enthalpy','scale')}
    free=build(layout,free_source,thermal['sound']['value'],thermal['opacity']['value'],masses,wave,*values,cosine,sine)
    nonstream={}
    for name,entries in free['groups'].items():
        if name not in ('streaming','heavy'):
            nonstream=combine(nonstream,entries)
    for row in layout['heavy']:
        for column in layout['heavy']:
            nonstream[(row,column)]=factored['normal_free'][(row,column)]
    base=symmetric(nonstream)
    hubble=free['hubble']
    for slots,speed in zip(layout['massive'],source['speeds']):
        width=(speed**2+4*(hubble/wave)**2)**.5
        value=-2*hubble/((values[0]*0+3)**.5*wave*width)
        plus(base,slots[0],slots[1],value)
        plus(base,slots[1],slots[0],value)
    branches={}
    for branch in ('gr','poisson-spatial'):
        if layout['heavy']:
            correction=factored['corrections'][branch]
        else:
            correction=product(free['injection'],sparse(parts(factored['metric']['physical'][branch])[0]))
        branches[branch]=combine(base,symmetric(correction))
    return dict(branches=branches,normal_free=base)
