from common import *
from cold_access import SavedBackground
from source_laws import exterior,point_thermal
from factored_sparse import evaluate
from symmetric_source import evaluate as symmetric
import mpmath as mp


mp.mp.dps=70


def calculate(layout,source,masses,wave,values,thermal,cosine,sine):
    full=evaluate(layout,source,masses,wave,values,thermal,cosine,sine)
    sym=symmetric(layout,source,masses,wave,values,thermal,cosine,sine,full)
    return {(branch,kind):(full if kind=='full' else sym)['branches'][branch] for branch in ('gr','poisson-spatial') for kind in ('full','symmetric')}


def main():
    modest()
    require(LABEL!='summary','one inherited family')
    output=ROOT/'validation-01'
    output.mkdir(exist_ok=False)
    inputs=verify_inputs()
    frozen={str(ROOT/'envelope-01'/(model+'-envelope.json')):digest(ROOT/'envelope-01'/(model+'-envelope.json')) for model in ('heavy','cold')}
    write(output/'freeze.json',dict(inputs=inputs,sources=sources(),frozen=frozen,precision_digits=70,angles=[.419,2.287],
        complex_steps=['1e-30','1e-35'],gate=GATE,algebra=ALGEBRA,
        scope='independent complex parameter differentiation of source-law physical pullback and symmetric source; frozen interval mixed-jet enclosure'))
    reports=[]
    for model in ('heavy','cold'):
        envelope=read(ROOT/'envelope-01'/(model+'-envelope.json'))
        layout=envelope['layout']
        limits={(branch,kind):{(item['row'],item['column']):item for item in envelope['branches'][branch][kind]['entries']} for branch in ('gr','poisson-spatial') for kind in ('full','symmetric')}
        background=SavedBackground(model)
        masses=[mp.mpf(float(value)) for value in background.masses]
        wave=mp.mpf(WAVE)
        constants=read(FULL/LABEL/f'full-01/{model}-constants.json')
        table=load(FULL/LABEL/f'full-01/{model}-thermal.npz')
        parent=FREE/LABEL/('free-01' if LABEL=='half' else 'free-02')
        for index in range(3):
            guard()
            saved=load(parent/f'{model}-{index}-frozen.npz')
            state=[mp.mpf(float(value)) for value in saved['state']]
            source=exterior(background,constants,state[0],mp.mpf,mp.exp)
            values=[source['scale']*masses[0]*state[1],state[2],state[3],state[4]]
            thermal,_,_=point_thermal(table,float(saved['thermal'][1]))
            gradients=fixtures=0
            maximum_derivative_ratio=mp.mpf(0)
            maximum_fixture_ratio=mp.mpf(0)
            maximum_step_error=mp.mpf(0)
            for theta in map(mp.mpf,('.419','2.287')):
                cosine,sine=mp.cos(2*theta),mp.sin(2*theta)
                before=calculate(layout,source,masses,wave,values,thermal,cosine,sine)
                for component in range(4):
                    if model=='cold' and component==2:
                        continue
                    guard()
                    derivatives=[]
                    for step in map(mp.mpf,('1e-30','1e-35')):
                        shifted=values.copy()
                        shifted[component]+=mp.j*step
                        candidate=calculate(layout,source,masses,wave,shifted,thermal,cosine,sine)
                        derivatives.append({name:{key:mp.im(value)/step for key,value in entries.items()} for name,entries in candidate.items()})
                    for name,entries in derivatives[-1].items():
                        for key in set(entries)|set(derivatives[0][name]):
                            value=entries.get(key,mp.mpf(0))
                            old=derivatives[0][name].get(key,mp.mpf(0))
                            error=abs(value-old)/max(abs(value),mp.mpf('1e-25'))
                            require(error<mp.mpf('1e-30'),'complex parameter step refinement')
                            maximum_step_error=max(maximum_step_error,error)
                            bound=mp.mpf(limits[name].get(key,{'derivatives':[0]*4})['derivatives'][component])
                            require(abs(value)<=bound+mp.mpf('1e-50'),'mixed directional/background derivative within frozen interval')
                            if bound:
                                maximum_derivative_ratio=max(maximum_derivative_ratio,abs(value)/bound)
                            gradients+=1
                patterns=[(1,-1,1,1),(-1,1,-1,-1),(1,1,-1,1),(-1,-1,1,-1)] if model=='heavy' else [(0,0,0,0)]
                errors=[mp.mpf(value) for value in envelope['errors']]
                for signs in patterns:
                    shifted=[values[component]+signs[component]*errors[component]/(mp.sqrt(2) if component<2 else 2) for component in range(4)]
                    for component,bounds in enumerate((envelope['state_box']['slow'],envelope['state_box']['slow'],envelope['state_box']['rho'],envelope['state_box']['clock'])):
                        require(mp.mpf(bounds[0])<=shifted[component]<=mp.mpf(bounds[1]),'fixture remains in frozen whole-history box')
                    after=calculate(layout,source,masses,wave,shifted,thermal,cosine,sine)
                    for name,entries in before.items():
                        square=mp.mpf(0)
                        for key in set(entries)|set(after[name]):
                            difference=abs(after[name].get(key,0)-entries.get(key,0))
                            bound=mp.mpf(limits[name].get(key,{'bound':0})['bound'])
                            require(difference<=bound+mp.mpf('1e-50'),'actual coefficient change inside frozen entry bound')
                            square+=difference**2
                        norm=mp.sqrt(square)
                        limit=mp.mpf(envelope['branches'][name[0]][name[1]]['frobenius_bound'])
                        require(norm<=limit+mp.mpf('1e-45'),'actual coefficient change inside frozen Frobenius bound')
                        if limit:
                            maximum_fixture_ratio=max(maximum_fixture_ratio,norm/limit)
                    fixtures+=1
            report=dict(model=model,index=index,gradient_entries=gradients,fixtures=fixtures,maximum_derivative_ratio=float(maximum_derivative_ratio),
                maximum_fixture_frobenius_ratio=float(maximum_fixture_ratio),step_refinement_relative=float(maximum_step_error))
            write(output/f'{model}-{index}.json',report)
            reports.append(report)
            print(LABEL,model,index,'mixed derivatives and fixtures passed',report,flush=True)
    require(all(digest(path)==value for path,value in frozen.items()),'bounds not adjusted after independent fixtures')
    write(output/'result.json',dict(passed=True,inputs=inputs,sources=sources(),frozen=frozen,reports=reports,precision_digits=70,
        full_g192=True,interval_supremum_not_inferred_from_samples=True))


if __name__=='__main__':
    main()
