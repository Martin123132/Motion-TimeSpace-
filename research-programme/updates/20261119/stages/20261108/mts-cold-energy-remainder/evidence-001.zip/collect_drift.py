from common import *
from adjoint_operator import open_owned
from physical_energy_map import PhysicalEnergyMap
from matched_cold_fibre import MatchedColdFibre
from native_joint import point_map
from energy_operator import metric_samples,spectral_rate,local_slow_rates,stable_point
from energy_math import transform_bank
import numpy as np

def main():
    modest()
    output=ROOT/'drift-01'
    output.mkdir(parents=True,exist_ok=False)
    (output/'contexts').mkdir()
    inputs=verify_inputs()
    center=load(ROOT/'energy-01/heavy-bank.npz')
    write(output/'freeze.json',dict(inputs=inputs,sources=sources(),center_sha256=digest(ROOT/'energy-01/heavy-bank.npz'),
        orders=[64,128,256],widths=[.002,.001],multipliers=[-4,-2,-1,1,2,4],check_stride=32,
        gate=GATE,algebra=ALGEBRA,scope='same nominal cold midpoint, physical slow-direction derivatives; original histories unchanged'))
    state=center['state']
    angles=np.arange(256)*np.pi/256
    system=open_owned('heavy','drift-01/contexts')
    energy=PhysicalEnergyMap(system)
    records=[]
    with MatchedColdFibre(system) as fibre:
        for name,direction in (('background',center['flow0']),('energy_cosine',center['flowc'])):
            for multiplier in (-4,-2,-1,1,2,4):
                guard()
                shifted=state+multiplier*.001*direction
                metrics,inverses=metric_samples(fibre,energy,shifted,angles)
                phase_rate=spectral_rate(metrics)
                matrices=[]
                angular=[]
                native_errors=[]
                for index,theta in enumerate(angles):
                    slow,_=local_slow_rates(fibre,energy,shifted,float(theta),.001)
                    fibre.install(shifted,float(theta))
                    checked=index%32==0
                    sample=stable_point(fibre,energy,shifted,float(theta),slow+fibre.angular_rate*phase_rate[index],check_native=checked)
                    matrices.append(sample['matrix'])
                    angular.append(sample['angular_rate'])
                    if checked:
                        native_errors.extend(sample['scalar_residual'])
                fibre.install(shifted,0.)
                pars=point_map(system,energy,float(shifted[0]))['parameters']
                matrix,diagonal,gamma=transform_bank(np.array(matrices),np.array(angular),shifted,system.background['masses'][1],
                    system.wave,energy.heavy,pars['eta0'],pars['b'])
                tag=name+'-'+str(multiplier)
                np.savez_compressed(output/(tag+'.npz'),matrix=matrix,angular=angular,state=shifted,
                    direction=direction,diagonal=diagonal,gamma=gamma,native_errors=native_errors)
                record=dict(tag=tag,maximum_native_residual=max(native_errors),native_phase_checks=8,
                    packet_sha256=digest(output/(tag+'.npz')),parameters=pars)
                write(output/(tag+'.json'),record)
                require(max(native_errors)<GATE,'shifted native scalar comparison')
                records.append(record)
                print(LABEL,tag,'saved; native residual',max(native_errors),flush=True)
    system=open_owned('cold','drift-01/contexts')
    energy=PhysicalEnergyMap(system)
    baseline=load(ROOT/'energy-01/cold-bank.npz')
    baseline_checks=[]
    with MatchedColdFibre(system) as fibre:
        for multiplier in (-4,-2,-1,1,2,4):
            shifted=baseline['state']+multiplier*.001*baseline['flow0']
            samples=[]
            for theta in (.0,1.117):
                item=stable_point(fibre,energy,shifted,theta,np.zeros((2,2,energy.size)),check_native=True)
                samples.append(item['matrix'])
            error=float(np.max(abs(samples[0]-samples[1])))
            require(error<ALGEBRA,'baseline phase independence under slow shifts')
            baseline_checks.append(dict(multiplier=multiplier,phase_error=error))
    write(output/'result.json',dict(passed=True,inputs=inputs,sources=sources(),records=records,baseline_checks=baseline_checks))
    print(LABEL,'saved all12 directions and6 baseline controls',flush=True)

if __name__=='__main__':
    main()
