from common import *
from adjoint_operator import open_owned
from physical_energy_map import PhysicalEnergyMap
from matched_cold_fibre import MatchedColdFibre
from native_joint import point_map
from energy_operator import local_slow_rates,stable_point,fourth
from mean_math import remainder,relative_error
from energy_math import symmetric_max
import numpy as np

def evaluate(coefficients,theta):
    modes=np.fft.fftfreq(len(coefficients),d=1/len(coefficients))
    return np.tensordot(np.exp(2j*modes*theta),coefficients,axes=(0,0)).real

def metric_angle_rate(fibre,energy,state,theta):
    values=[]
    for step in (-2,-1,1,2):
        fibre.install(state,theta+step*.0025)
        point=point_map(fibre.system,energy,float(state[0]))
        values.append(np.stack([point['metrics'][branch] for branch in ('gr','poisson-spatial')]))
    return fourth(values,.0025)

def main():
    modest()
    output=ROOT/'independent-01'
    output.mkdir(parents=True,exist_ok=False)
    (output/'contexts').mkdir()
    inputs=verify_inputs()
    result=read(ROOT/'remainder-01/result.json')
    require(result['passed'],'refined physical remainder')
    bank=load(ROOT/'energy-01/heavy-bank.npz')
    saved=load(ROOT/'remainder-01/remainder.npz')
    angles=[.187,1.317,2.713]
    frozen=[]
    for branch,name in enumerate(('gr','poisson-spatial')):
        field=np.fft.fft(bank['matrix'][:,branch],axis=0)/256
        residual=np.fft.fft(saved[name+'_remainder'],axis=0)/256
        frozen.append([(evaluate(field,theta),evaluate(residual,theta)) for theta in angles])
    np.savez_compressed(output/'frozen.npz',predictions=np.array(frozen),angles=angles)
    write(output/'freeze.json',dict(inputs=inputs,sources=sources(),angles=angles,
        remainder_source_sha256=digest(ROOT/'remainder-01/remainder.npz'),
        frozen_sha256=digest(output/'frozen.npz'),gate=GATE,algebra=ALGEBRA))
    records=[]
    system=open_owned('heavy','independent-01/contexts')
    energy=PhysicalEnergyMap(system)
    state=bank['state']
    with MatchedColdFibre(system) as fibre:
        for count,theta in enumerate(angles):
            slow,_=local_slow_rates(fibre,energy,state,theta,.001)
            phase=metric_angle_rate(fibre,energy,state,theta)
            fibre.install(state,theta)
            sample=stable_point(fibre,energy,state,theta,slow+fibre.angular_rate*phase)
            pars=sample['parameters']
            diagonal=bank['diagonal']
            actual=sample['matrix']*diagonal[None,:,None]/diagonal[None,None,:]
            gamma=pars['eta0']-.5+(1.5+pars['b'])*np.cos(2*theta)
            for slot in energy.heavy:
                actual[:,slot,slot]+=gamma
            for branch,name in enumerate(('gr','poisson-spatial')):
                local=evaluate(saved[name+'_coefficients'],theta)
                drift=evaluate(np.fft.fft(saved[name+'_drift'],axis=0)/256,theta)
                expected_field,expected_remainder=frozen[branch][count]
                residual=remainder(actual[branch],saved[name+'_mean'],local,drift)
                q=result['branches'][name]['polynomial']['primitive_bound']
                correction=np.linalg.norm(actual[branch]-expected_field,'fro')*np.linalg.norm(local,'fro')/(1-q)
                bound=result['branches'][name]['polynomial']['remainder_bound']+correction
                row=dict(theta=theta,branch=name,field_error=relative_error(actual[branch],expected_field),
                    remainder_error=relative_error(residual,expected_remainder),native_scalar_residual=sample['scalar_residual'][branch],
                    remainder_frobenius=float(np.linalg.norm(residual,'fro')),polynomial_plus_native_bound=float(bound))
                require(max(row['field_error'],row['remainder_error'],row['native_scalar_residual'])<GATE,'frozen physical remainder prediction')
                require(row['remainder_frobenius']<=bound*(1+ALGEBRA),'finite-polynomial bound plus native coefficient correction')
                records.append(row)
    tail_records=[]
    for model in ('heavy','cold'):
        packet=load(ROOT/'energy-01'/(model+'-bank.npz'))
        core=int(packet['core_size'])
        for branch in (0,1):
            mean=load(ROOT/f'energy-01/{model}-mean-{branch}.npz')['mean']
            full=np.zeros((core+950,core+950))
            full[:core+5,:core+5]=mean[:core+5,:core+5]
            diagonal=np.diag(mean)[core:core+5]
            speeds=np.array([mean[core+5+node,core+node]*np.sqrt(9*7)/4 for node in range(5)])
            for degree in range(3,193):
                slots=core+(degree-3)*5+np.arange(5)
                full[slots,slots]=diagonal
                if degree>3:
                    coefficient=speeds*degree/np.sqrt((2*degree+1)*(2*degree-1))
                    full[slots,slots-5]=coefficient
                    full[slots-5,slots]=-coefficient
            embedding_error=float(np.max(abs(full[:core+10,:core+10]-mean)))
            symmetric=(full+full.T)/2
            support=symmetric.copy()
            support[:core+5,:core+5]=0.
            support[np.arange(core+950),np.arange(core+950)]=0.
            outside=float(np.max(np.sum(abs(support),axis=1)))
            finite=symmetric_max(mean)
            full_bound=max(symmetric_max(full[:core+5,:core+5]),float(np.max(diagonal)))+outside
            require(embedding_error<ALGEBRA and abs(full_bound-finite)<ALGEBRA,'exact G192 symmetric-block reduction')
            tail_records.append(dict(model=model,branch=branch,embedding_error=embedding_error,outside_symmetric_row_bound=outside,
                reduced_logarithmic_norm=finite,full_G192_logarithmic_bound=full_bound))
    write(output/'result.json',dict(passed=True,inputs=inputs,sources=sources(),records=records,tail_records=tail_records))
    print(json.dumps(dict(passed=True,records=records,tail_records=tail_records),indent=2),flush=True)

if __name__=='__main__':
    main()
