from common import *
from mean_math import phase_primitive,fourth_derivative,remainder,relative_error
from remainder_analysis import primitive,polynomial_bound
from run_native import native_provenance
import ast
import numpy as np
import platform

def closure(entry):
    pending=[STAGE/entry]
    result=set()
    while pending:
        path=pending.pop()
        if path in result:
            continue
        result.add(path)
        for node in ast.walk(ast.parse(path.read_text(encoding='utf-8-sig'))):
            names=[node.module] if isinstance(node,ast.ImportFrom) else ([item.name for item in node.names] if isinstance(node,ast.Import) else [])
            for name in names:
                if name:
                    candidate=STAGE/(name.split('.')[0]+'.py')
                    if candidate.exists():
                        pending.append(candidate)
    return result

def sources_unchanged(report,entry):
    for path in closure(entry):
        require(str(path) in report['sources'] and digest(path)==report['sources'][str(path)],'executed source unchanged: '+str(path))

def main():
    modest()
    output=STAGE/'audit'
    output.mkdir(exist_ok=False)
    inputs=verify_inputs()
    provenance=native_provenance()
    accepted={}
    maxima={}
    summary=[]
    for label in ('half','balanced','double'):
        root=STAGE/label
        for folder,entry in (('energy-01','probe_energy.py'),('drift-01','collect_drift.py'),('remainder-01','remainder_analysis.py'),('independent-01','validate_remainder.py')):
            path=root/folder/'result.json'
            report=read(path)
            require(report['passed'] and report['inputs']==inputs,'accepted result and same inputs')
            sources_unchanged(report,entry)
            accepted[str(path)]=digest(path)
        drift=read(root/'drift-01/result.json')
        require(len(drift['records'])==12 and len(drift['baseline_checks'])==6,'complete physical direction pairs and baseline')
        for record in drift['records']:
            require(record['packet_sha256']==digest(root/'drift-01'/(record['tag']+'.npz')),'shifted bank hash')
            require(record['native_phase_checks']==8 and record['maximum_native_residual']<GATE,'independent shifted native reference')
            maxima['shifted_native']=max(maxima.get('shifted_native',0.),record['maximum_native_residual'])
        require(all(row['phase_error']==0 for row in drift['baseline_checks']),'baseline zero phase dependence')
        bank=load(root/'energy-01/heavy-bank.npz')
        numerical=read(root/'remainder-01/result.json')
        packet=load(root/'remainder-01/remainder.npz')
        require(numerical['packet_sha256']==digest(root/'remainder-01/remainder.npz'),'qualified remainder hash')
        for name,error in numerical['errors'].items():
            maxima[name]=max(maxima.get(name,0.),error)
            require(error<GATE,'unchanged relative refinement')
        for branch,name in enumerate(('gr','poisson-spatial')):
            recomputed=primitive(bank['matrix'][:,branch],bank['angular'],int(bank['core_size']))
            require(relative_error(recomputed['mean'],packet[name+'_mean'])<ALGEBRA,'mean reproduced')
            require(relative_error(recomputed['primitive'],packet[name+'_primitive'])<ALGEBRA,'primitive reproduced')
            width=.001
            derivatives={}
            for direction in ('background','energy_cosine'):
                values={}
                for multiplier in (-2,-1,1,2):
                    shifted=load(root/'drift-01'/(direction+'-'+str(multiplier)+'.npz'))
                    values[multiplier]=primitive(shifted['matrix'][:,branch],shifted['angular'],int(bank['core_size']))['primitive']
                derivatives[direction]=fourth_derivative(values,width)
            reconstructed=derivatives['background']+np.cos(2*np.arange(256)*np.pi/256)[:,None,None]*derivatives['energy_cosine']
            require(relative_error(reconstructed,packet[name+'_drift'])<ALGEBRA,'physical flow drift reproduced')
            for index in (0,17,63,129,201,255):
                actual=remainder(bank['matrix'][index,branch],packet[name+'_mean'],packet[name+'_primitive'][index],reconstructed[index])
                require(relative_error(actual,packet[name+'_remainder'][index])<ALGEBRA,'exact transformed remainder reproduced')
            bound=polynomial_bound(bank['matrix'][:,branch],packet[name+'_mean'],packet[name+'_coefficients'],reconstructed)
            require(abs(bound['remainder_bound']/numerical['branches'][name]['polynomial']['remainder_bound']-1)<ALGEBRA,'polynomial numerator bound reproduced')
            require(numerical['branches'][name]['sampled_remainder_frobenius']<=bound['remainder_bound'],'sampled remainders inside polynomial bound')
        independent=read(root/'independent-01/result.json')
        require(len(independent['records'])==6 and len(independent['tail_records'])==4,'independent phases and G192 norms')
        for row in independent['records']:
            for name in ('field_error','remainder_error','native_scalar_residual'):
                maxima['heldout_'+name]=max(maxima.get('heldout_'+name,0.),row[name])
                require(row[name]<GATE,'held-out native source and remainder')
            require(row['remainder_frobenius']<=row['polynomial_plus_native_bound']*(1+ALGEBRA),'fresh native bound')
        for row in independent['tail_records']:
            require(row['embedding_error']<ALGEBRA and row['outside_symmetric_row_bound']<ALGEBRA,'G192 symmetric-tail structure')
            require(abs(row['reduced_logarithmic_norm']-row['full_G192_logarithmic_bound'])<ALGEBRA,'full hierarchy norm reduction')
        summary.append(dict(label=label,branches=numerical['branches'],
            baseline=read(root/'energy-01/result.json')['reports'][1]['branches']))
    identities=read(STAGE/'identities/result.json')
    require(identities['passed'] and all(value=='0' for value in identities['checks'].values()),'symbolic normalization/primitive/tail identities')
    sources_unchanged(identities,'derive_energy.py')
    accepted[str(STAGE/'identities/result.json')]=digest(STAGE/'identities/result.json')
    for path in STAGE.glob('*.py'):
        compile(path.read_text(encoding='utf-8-sig'),str(path),'exec')
    require(not list(STAGE.rglob('__pycache__')),'no bytecode caches')
    write(output/'result.json',dict(passed=True,inputs=inputs,provenance=provenance,accepted_results=accepted,
        sources=sources(),maxima=maxima,summary=summary,failed_attempts_preserved=[],
        shifted_phase_families=36,shifted_coefficients=9216,shifted_native_phase_checks=288,
        baseline_shift_controls=18,heldout_native_angles=9,full_hierarchy_norm_checks=12,
        full_cold_history_bound=False,source_continuum_phase_tail_bound=False,
        platform=platform.platform(),scope='qualified midpoint physical remainder, finite-polynomial bounds and exact transfer theorem; pathwise hypotheses not silently assumed'))
    print(json.dumps(dict(passed=True,maxima=maxima,summary=summary),indent=2),flush=True)

if __name__=='__main__':
    main()
