from common import *
import sympy as sp
import numpy as np
from mean_math import phase_primitive,relative_error

def main():
    modest()
    output=STAGE/'identities'
    output.mkdir(exist_ok=False)
    density,hubble,wave,eta0,fraction,theta,mu=sp.symbols('rho H k eta0 b theta mu',positive=True)
    metric=density*hubble**2/wave**2
    metric_rate=sp.diff(metric,density)*density*(-1+3*sp.cos(2*theta))+sp.diff(metric,hubble)*hubble*(eta0+fraction*sp.cos(2*theta))
    gamma=eta0-sp.Rational(1,2)+(sp.Rational(3,2)+fraction)*sp.cos(2*theta)
    primitive=-(sp.Rational(3,2)+fraction)/3*sp.log(1-sp.Rational(3,2)/mu*sp.sin(2*theta))
    degree=sp.symbols('ell',integer=True,positive=True)
    lower=degree/sp.sqrt((2*degree+1)*(2*degree-1))
    upper=-degree/sp.sqrt((2*degree-1)*(2*degree+1))
    checks=dict(weight_rate=sp.simplify(metric_rate-2*gamma*metric),
        periodic_weight_primitive=sp.simplify(sp.diff(primitive,theta)-(sp.Rational(3,2)+fraction)*sp.cos(2*theta)/(mu-sp.Rational(3,2)*sp.sin(2*theta))),
        remote_tail_skew=sp.simplify(lower+upper))
    require(all(value==0 for value in checks.values()),'exact physical normalization identities')
    records=[]
    for label in ('half','balanced','double'):
        root=STAGE/label
        bank=load(root/'energy-01/heavy-bank.npz')
        parent=load(COLD/label/'cold-midpoint-02/heavy-generator.npz')
        parameters=read(root/'energy-01/result.json')['reports'][0]['parameters']
        angles=np.arange(256)*np.pi/256
        gamma_primitive=-(1.5+parameters['b'])/3*np.log1p(-1.5/parameters['mu']*np.sin(2*angles))
        gamma_primitive-=gamma_primitive.mean()
        diagonal=bank['diagonal']
        for branch in range(2):
            old=phase_primitive(parent['matrix'][:,branch],parent['angular'])
            new=load(root/f'energy-01/heavy-mean-{branch}.npz')
            predicted=old['primitive']*diagonal[None,:,None]/diagonal[None,None,:]
            predicted_mean=old['mean']*diagonal[:,None]/diagonal[None,:]
            for slot in bank['heavy']:
                predicted[:,slot,slot]+=gamma_primitive
                predicted_mean[slot,slot]+=parameters['eta0']-.5
            primitive_error=relative_error(predicted,new['primitive'])
            mean_error=relative_error(predicted_mean,new['mean'])
            require(max(primitive_error,mean_error)<GATE,'independent primitive and mean scaling identity')
            records.append(dict(label=label,branch=branch,primitive_error=primitive_error,mean_error=mean_error))
        baseline=load(root/'energy-01/cold-mean-0.npz')
        require(np.max(abs(baseline['primitive']))==0.,'absent scalar baseline has no phase primitive')
    write(output/'result.json',dict(passed=True,checks={name:str(value) for name,value in checks.items()},records=records,sources=sources()))
    print(json.dumps(dict(passed=True,identities=checks,records=records),default=str),flush=True)

if __name__=='__main__':
    main()
