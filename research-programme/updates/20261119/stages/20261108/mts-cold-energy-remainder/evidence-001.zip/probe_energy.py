from common import *
from adjoint_operator import open_owned
from physical_energy_map import PhysicalEnergyMap
from matched_cold_fibre import MatchedColdFibre
from native_joint import point_map
from energy_math import transform_bank,phase_summary,symmetric_max
import numpy as np

def main():
    modest()
    output=ROOT/'energy-01'
    output.mkdir(parents=True,exist_ok=False)
    (output/'contexts').mkdir()
    inputs=verify_inputs()
    write(output/'freeze.json',dict(inputs=inputs,sources=sources(),gate=GATE,algebra=ALGEBRA,
        normalization='heavy relative pair times sqrt(rho_h)*H/k, same as cold-fluid physical energy coordinates'))
    reports=[]
    for model in ('heavy','cold'):
        system=open_owned(model,'energy-01/contexts')
        energy=PhysicalEnergyMap(system)
        packet=load(COLD/LABEL/'cold-midpoint-02'/(model+'-generator.npz'))
        state=packet['state']
        with MatchedColdFibre(system) as fibre:
            fibre.install(state,0.)
            point=point_map(system,energy,float(state[0]))
            if model=='heavy':
                pars=point['parameters']
                matrix,diagonal,gamma=transform_bank(packet['matrix'],packet['angular'],state,system.background['masses'][1],system.wave,energy.heavy,pars['eta0'],pars['b'])
                flow0=fibre.flow.copy()
                flow0[3]=-state[3]
                flowc=np.zeros(5)
                flowc[3]=3*state[3]
            else:
                matrix=packet['matrix'].copy()
                diagonal=np.ones(matrix.shape[-1])
                gamma=np.zeros(1)
                pars=None
                flow0=fibre.flow.copy()
                flowc=np.zeros(5)
            summaries=phase_summary(matrix,packet['angular'])
            np.savez_compressed(output/(model+'-bank.npz'),matrix=matrix,angular=packet['angular'],state=state,
                diagonal=diagonal,gamma=gamma,heavy=energy.heavy,rest=energy.rest,core_size=energy.size,flow0=flow0,flowc=flowc)
            branches=[]
            for index,summary in enumerate(summaries):
                np.savez_compressed(output/(model+'-mean-'+str(index)+'.npz'),**summary)
                branches.append(dict(logarithmic_norm=summary['logarithmic_norm'],primitive_norm=summary['primitive_norm'],
                    maximum_generator=float(np.max(abs(summary['mean']))),reduced_tail_symmetric=float(np.max(abs((summary['mean'][energy.size:,energy.size:]+summary['mean'][energy.size:,energy.size:].T)/2-np.diag(np.diag(summary['mean'][energy.size:,energy.size:])))))))
            reports.append(dict(model=model,parameters=pars,branches=branches))
            print(LABEL,model,branches,flush=True)
    write(output/'result.json',dict(passed=True,reports=reports,inputs=inputs,sources=sources()))

if __name__=='__main__':
    main()
