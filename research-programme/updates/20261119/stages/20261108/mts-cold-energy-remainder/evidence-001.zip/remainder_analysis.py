from common import *
from mean_math import phase_primitive,fourth_derivative,remainder,relative_error
from energy_math import symmetric_max
import numpy as np

def primitive(matrix,angular,core):
    item=phase_primitive(matrix,angular)
    omitted=item['primitive'].copy()
    omitted[:,:core+5,:core+5]=0.
    dropped=float(np.max(abs(omitted)))
    item['primitive'][:,core+5:]=0.
    item['primitive'][:,:,core+5:]=0.
    item['coefficients'][:,core+5:]=0.
    item['coefficients'][:,:,core+5:]=0.
    require(dropped<ALGEBRA,'exact phase-independent remote-tail support')
    item['support_roundoff']=dropped
    return item

def polynomial_bound(matrix,mean,coefficients,drift):
    count=len(matrix)
    modes=np.rint(np.fft.fftfreq(count,d=1/count)).astype(int)
    field=np.fft.fft(matrix,axis=0)/count
    drift_coeff=np.fft.fft(drift,axis=0)/count
    active=[index for index,mode in enumerate(modes) if abs(mode)<=8]
    tail=[index for index in range(count) if index not in active]
    fnorm=lambda value:float(np.linalg.norm(value,'fro'))
    q=sum(fnorm(value) for value in coefficients)
    require(q<1,'uniform finite-polynomial inverse')
    field_tail=sum(fnorm(field[index]) for index in tail)
    primitive_tail=sum(fnorm(coefficients[index]) for index in tail)
    drift_tail=sum(fnorm(drift_coeff[index]) for index in tail)
    field_active=sum(fnorm(field[index]) for index in active)
    numerator={mode:np.zeros_like(mean,dtype=complex) for mode in range(-16,17)}
    for right in active:
        mode=int(modes[right])
        numerator[mode]+=field[0]@coefficients[right]-coefficients[right]@mean-drift_coeff[right]
        for left in active:
            if left!=0:
                numerator[mode+int(modes[left])]+=field[left]@coefficients[right]
    omitted=field_tail*q+(field_active+fnorm(mean))*primitive_tail+drift_tail
    bound=(sum(fnorm(value) for value in numerator.values())+omitted)/(1-q)
    return dict(primitive_bound=q,remainder_bound=bound,numerator_omitted_bound=omitted,
        field_fourier_tail=field_tail,primitive_fourier_tail=primitive_tail,
        drift_fourier_tail=drift_tail,active_harmonics=8,
        scope='uniform phase bound for retained finite Fourier polynomials; not unsampled continuum/source or full cold-history certificate')

def main():
    modest()
    output=ROOT/'remainder-01'
    output.mkdir(parents=True,exist_ok=False)
    inputs=verify_inputs()
    source=read(ROOT/'drift-01/result.json')
    require(source['passed'],'completed physical directions')
    bank=load(ROOT/'energy-01/heavy-bank.npz')
    core=int(bank['core_size'])
    reports={}
    errors={}
    saved=dict(state=bank['state'],diagonal=bank['diagonal'],heavy=bank['heavy'],core_size=core)
    packets={(name,multiplier):load(ROOT/'drift-01'/(name+'-'+str(multiplier)+'.npz'))
             for name in ('background','energy_cosine') for multiplier in (-4,-2,-1,1,2,4)}
    for branch,name in enumerate(('gr','poisson-spatial')):
        terms={}
        for order in (64,128,256):
            stride=256//order
            center=primitive(bank['matrix'][::stride,branch],bank['angular'][::stride],core)
            derivatives={}
            for direction in ('background','energy_cosine'):
                shifted={}
                for multiplier in (-4,-2,-1,1,2,4):
                    packet=packets[direction,multiplier]
                    shifted[multiplier]=primitive(packet['matrix'][::stride,branch],packet['angular'][::stride],core)['primitive']
                derivatives[direction]={factor:fourth_derivative({step:shifted[step*factor] for step in (-2,-1,1,2)},.001*factor) for factor in (2,1)}
            angles=np.arange(order)*np.pi/order
            for factor in (2,1):
                drift=derivatives['background'][factor]+np.cos(2*angles)[:,None,None]*derivatives['energy_cosine'][factor]
                residual=np.stack([remainder(value,center['mean'],local,rate) for value,local,rate in zip(bank['matrix'][::stride,branch],center['primitive'],drift)])
                terms[order,factor]=dict(drift=drift,remainder=residual,primitive=center['primitive'],
                    mean=center['mean'],coefficients=center['coefficients'],support_roundoff=center['support_roundoff'])
        fine=terms[256,1]
        for key in ('drift','remainder'):
            errors[name+'_'+key+'_width']=relative_error(terms[256,2][key],fine[key])
            errors[name+'_'+key+'_phase']=relative_error(terms[128,1][key],fine[key][::2])
        errors[name+'_mean_phase']=relative_error(terms[128,1]['mean'],fine['mean'])
        errors[name+'_primitive_phase']=relative_error(terms[128,1]['primitive'],fine['primitive'][::2])
        bound=polynomial_bound(bank['matrix'][:,branch],fine['mean'],fine['coefficients'],fine['drift'])
        mu=symmetric_max(fine['mean'])
        report=dict(sampled_remainder_frobenius=max(float(np.linalg.norm(value,'fro')) for value in fine['remainder']),
            sampled_drift_frobenius=max(float(np.linalg.norm(value,'fro')) for value in fine['drift']),
            mean_logarithmic_norm=mu,polynomial=bound,
            conditional_frozen_quarter_efold_transfer_bound=float((1+bound['primitive_bound'])/(1-bound['primitive_bound'])*np.exp(mu*.25)*np.expm1(bound['remainder_bound']*.25)),
            transfer_scope='conditional illustration IF these midpoint constants bound an entire path; not a verified interval prediction',
            support_roundoff=fine['support_roundoff'])
        reports[name]=report
        for key,value in fine.items():
            saved[name+'_'+key]=value
    baseline=load(ROOT/'energy-01/cold-bank.npz')
    require(np.max(abs(load(ROOT/'energy-01/cold-mean-0.npz')['primitive']))==0.,'baseline primitive exactly zero')
    np.savez_compressed(output/'remainder.npz',**saved)
    passed=max(errors.values())<GATE
    write(output/'result.json',dict(passed=passed,inputs=inputs,sources=sources(),errors=errors,branches=reports,
        packet_sha256=digest(output/'remainder.npz'),baseline_remainder_zero=True,
        drift_source_sha256=digest(ROOT/'drift-01/result.json')))
    print(json.dumps(dict(passed=passed,errors=errors,branches=reports),indent=2),flush=True)
    require(passed,'unchanged relative refinement gate; preserve failure')

if __name__=='__main__':
    main()
