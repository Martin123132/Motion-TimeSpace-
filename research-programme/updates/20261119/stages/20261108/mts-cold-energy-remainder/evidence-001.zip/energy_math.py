from common import *
import numpy as np
from mean_math import phase_primitive

def weight(state,mass,wave,mu,size,heavy):
    hubble=np.exp(state[0])*mass/mu
    value=np.sqrt(state[3])*hubble/wave
    require(value>0,'positive cold energy weight')
    diagonal=np.ones(size)
    diagonal[heavy]=value
    return diagonal

def transform_bank(matrix,angular,state,mass,wave,heavy,eta0,fraction):
    mu=float(angular[0])
    diagonal=weight(state,mass,wave,mu,matrix.shape[-1],heavy)
    angles=np.arange(len(angular))*np.pi/len(angular)
    gamma=eta0-.5+(1.5+fraction)*np.cos(2*angles)
    transformed=matrix*diagonal[None,None,:,None]/diagonal[None,None,None,:]
    for slot in heavy:
        transformed[:,:,slot,slot]+=gamma[:,None]
    return transformed,diagonal,gamma

def symmetric_max(matrix):
    return float(np.linalg.eigvalsh((matrix+matrix.T)/2)[-1])

def phase_summary(matrix,angular):
    output=[]
    for branch in range(2):
        item=phase_primitive(matrix[:,branch],angular)
        item['logarithmic_norm']=symmetric_max(item['mean'])
        item['primitive_norm']=float(np.max(np.linalg.norm(item['primitive'],axis=(1,2))))
        output.append(item)
    return output
