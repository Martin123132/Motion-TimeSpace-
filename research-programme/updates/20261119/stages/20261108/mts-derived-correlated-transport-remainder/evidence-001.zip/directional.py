import math


class Directional:
    def __init__(self,value,rate=0.):
        self.value=value
        self.rate=rate

    @staticmethod
    def cast(value):
        return value if isinstance(value,Directional) else Directional(value)

    def __add__(self,other):
        other=self.cast(other)
        return Directional(self.value+other.value,self.rate+other.rate)

    __radd__=__add__

    def __neg__(self):
        return Directional(-self.value,-self.rate)

    def __sub__(self,other):
        return self+-self.cast(other)

    def __rsub__(self,other):
        return self.cast(other)+-self

    def __mul__(self,other):
        other=self.cast(other)
        return Directional(self.value*other.value,self.rate*other.value+self.value*other.rate)

    __rmul__=__mul__

    def __truediv__(self,other):
        other=self.cast(other)
        return Directional(self.value/other.value,(self.rate*other.value-self.value*other.rate)/other.value**2)

    def __rtruediv__(self,other):
        return self.cast(other)/self

    def __pow__(self,power):
        power=self.cast(power)
        if power.rate!=0:
            raise ValueError('only constant powers in retained source')
        value=self.value**power.value
        return Directional(value,power.value*self.value**(power.value-1)*self.rate) if power.value!=0 else Directional(1.,0.)

    def __eq__(self,other):
        other=self.cast(other)
        return self.value==other.value and self.rate==other.rate

    def __float__(self):
        return float(self.value)


def exponential(value):
    value=Directional.cast(value)
    result=math.exp(value.value)
    return Directional(result,result*value.rate)


def parts(value):
    return (value.value,value.rate) if isinstance(value,Directional) else (value,0.)
