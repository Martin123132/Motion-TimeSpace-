from common import *
from directional import Directional,exponential,parts
from correlated_source import CorrelatedSource,correlated,correction,BRANCHES
from early_source import namespace
from source_laws import exterior
from factored_sparse import evaluate as full_source
from full_metric_math import rows
from enclose_free import complete_layout
import numpy as np


def saved_rates(owner,efold):
    _,rate=namespace['dense_values'](owner.saved.dense,np.array([efold]))
    config=owner.saved.configuration
    return np.array([rate[0,0]*config['slow_unit'],rate[0,1]*config['slow_unit'],
        -owner.values(efold)[2],rate[0,2]/config['initial_hubble']])


def invariant_corrector(density,source,coordinate,velocity,omega,theta):
    hubble=((source['density']+(coordinate**2+velocity**2)/2+density)/3)**.5
    inverse=hubble/omega
    fraction=density/(3*hubble**2)
    eta0=(source['density_first']+coordinate**2-2*velocity**2-density)/(6*hubble**2)
    coefficient_a=1.5*(1-eta0)
    coefficient_b=1.125*(2-fraction)
    value=1.5*inverse*np.sin(2*theta)-.5*coefficient_a*inverse**2*np.cos(2*theta)-.25*coefficient_b*inverse**2*np.cos(4*theta)
    return value,hubble


def slow_input(owner,frozen,theta):
    efold=frozen['efold']
    source=exterior(owner.saved,owner.constants,Directional(efold,1.),cast=Directional.cast,exp=exponential)
    rate=saved_rates(owner,efold)
    values=[Directional(value,slope) for value,slope in zip(frozen['values'],rate)]
    physical=frozen
    rho_theta=0.
    if owner.model=='heavy':
        physical,reconstruction=correlated(frozen,theta)
        density=physical['values'][2]
        omega=frozen['source']['scale']*frozen['masses'][1]
        corrected,_=invariant_corrector(Directional(density,0.),source,values[0],values[1],source['scale']*frozen['masses'][1],theta)
        derivative=float(reconstruction['derivative'])
        rho_slow=density*(-1+corrected.rate)/(1-derivative)
        _,hubble,_=correction(density,frozen['source']['density'],frozen['source']['density_first'],
            frozen['values'][0],frozen['values'][1],omega,theta)
        inverse=hubble/omega
        fraction=density/(3*hubble**2)
        eta=(frozen['source']['density_first']+frozen['values'][0]**2-2*frozen['values'][1]**2-density)/(6*hubble**2)
        phase_derivative=3*inverse*np.cos(2*theta)+1.5*(1-eta)*inverse**2*np.sin(2*theta)+1.125*(2-fraction)*inverse**2*np.sin(4*theta)
        rho_theta=density*phase_derivative/(1-derivative)
        values[2]=Directional(density,rho_slow)
    thermal={name:{'value':Directional(item['value'],item['first']),
        'first':Directional(item['first'],item['second']),'second':Directional(item['second'],0.)}
        for name,item in frozen['thermal'].items()}
    hubble=((source['density']+(values[0]**2+values[1]**2)/2+values[2])/3)**.5
    angular=source['scale']*frozen['masses'][1]/hubble-1.5*np.sin(2*theta) if owner.model=='heavy' else Directional(0.,0.)
    actual_rate=np.array([entry.rate for entry in values])
    actual_rate[2]+=rho_theta*angular.value
    coordinate,velocity,density,clock=[entry.value for entry in values]
    omega_s=frozen['source']['scale']*frozen['masses'][0]
    original_rate=np.array([coordinate+omega_s*velocity/hubble.value,-2*velocity-omega_s*coordinate/hubble.value,
        (-1+3*np.cos(2*theta))*density if owner.model=='heavy' else 0.,1/hubble.value])
    return dict(source=source,values=values,thermal=thermal,hubble=hubble,angular=angular,physical=physical,
        rho_theta=rho_theta,actual_rate=actual_rate,original_rate=original_rate,defect=actual_rate-original_rate)


def arrays(entries,compact,remote_keys):
    matrix=np.zeros((compact,compact))
    derivative=np.zeros_like(matrix)
    for (row,column),entry in entries.items():
        if max(row,column)<compact:
            matrix[row,column],derivative[row,column]=parts(entry)
    remote=np.array([parts(entries.get(tuple(key),0.)) for key in remote_keys])
    return matrix,derivative,remote[:,0],remote[:,1]


def evaluate_slow(owner,frozen,theta,remote_keys):
    prepared=slow_input(owner,frozen,theta)
    result=full_source(complete_layout(frozen['layout']),prepared['source'],frozen['masses'],WAVE,
        prepared['values'],prepared['thermal'],np.cos(2*theta),np.sin(2*theta))
    matrices=[arrays(result['branches'][branch],frozen['layout']['size'],remote_keys) for branch in BRANCHES]
    return prepared,dict(matrix=np.array([row[0] for row in matrices]),derivative=np.array([row[1] for row in matrices]),
        remote=matrices[0][2],remote_derivative=matrices[0][3])


def physical_map(layout,source,masses,wave,values,theta):
    coordinate,velocity,density,clock=values
    zero=coordinate*0
    matrix=[[zero for column in range(layout['size'])] for row in range(layout['size'])]
    hubble=((source['density']+(coordinate**2+velocity**2)/2+density)/3)**.5
    gauge=layout['alpha']
    fluid=source['fluid']
    def scalar(slot,weight,shift=0.):
        matrix[slot][slot]=weight
        matrix[slot][gauge]+=weight*shift
    scalar(gauge,fluid[0]**.5*wave)
    scalar(layout['cdm'],fluid[0]**.5*hubble/wave,-3*hubble)
    scalar(layout['baryon'],fluid[1]**.5*hubble/wave,-3*hubble)
    scalar(layout['baryon_velocity'],fluid[1]**.5,wave)
    for name,species in (('photon_all',2),('massless_all',3)):
        slots=layout[name]
        maximum=len(slots)-1
        for degree,slot in enumerate(slots):
            angular=maximum if degree==maximum and maximum>2 else 2*degree+1
            if name=='massless_all' and layout['ufa'] and degree==2:
                angular=2
            shift=-4*hubble if degree==0 else 4*wave/3 if degree==1 else 0.
            scalar(slot,(fluid[species]*angular/4)**.5,shift)
    maximum=len(layout['polar_all'])+1
    for degree,slot in enumerate(layout['polar_all'],2):
        angular=(2*degree+1)*(degree+1)*(degree+2)/(degree*(degree-1))
        if degree==maximum:
            previous=(2*degree-1)*degree*(degree+1)/((degree-1)*(degree-2))
            angular=previous*(degree+2)*(degree-2)/(degree*(2*degree-1))/(degree/(degree-2))
        scalar(slot,(fluid[2]*angular/4)**.5)
    for node,(slots,amount,speed) in enumerate(zip(layout['massive'],source['massive'],source['speeds'])):
        width=(speed**2+4*hubble**2/wave**2)**.5
        for degree,slot in enumerate(slots+layout['tail_by_node'][node]):
            factor=width if degree==0 else speed
            shift=-4*hubble if degree==0 else 4*wave/(3*speed) if degree==1 else 0.
            scalar(slot,factor*(amount*(2*degree+1)/4)**.5,shift)
    omega=source['scale']*masses[0]
    frequency=(wave**2+omega**2)**.5
    position,momentum=layout['slow']
    matrix[position][position]=frequency
    matrix[momentum][momentum]=1.
    matrix[position][gauge]=frequency*velocity
    matrix[momentum][gauge]=-3*hubble*velocity-omega*coordinate
    if layout['heavy']:
        omega=source['scale']*masses[1]
        alpha=wave**2/(omega*hubble)
        position=(2*density)**.5*np.cos(theta)
        velocity=-(2*density)**.5*np.sin(theta)
        weight=density**.5*hubble/wave
        normal=[[2*position/(2*density),2*velocity/(2*density)],
            [alpha*velocity/(2*density),-alpha*position/(2*density)]]
        raw_factor=omega**.5/source['scale']
        shift=[omega*velocity,-3*hubble*velocity-omega*position]
        for row,slot in enumerate(layout['heavy']):
            for column,target in enumerate(layout['heavy']):
                matrix[slot][target]=weight*normal[row][column]*raw_factor
            matrix[slot][gauge]=weight*sum(normal[row][column]*shift[column] for column in range(2))
    return matrix


def dense_parts(matrix):
    parsed=np.array([[parts(entry) for entry in row] for row in matrix])
    return parsed[:,:,0],parsed[:,:,1]


def map_defect(frozen,theta,defect):
    layout=frozen['layout']
    source=frozen['source']
    values=[Directional(value,rate) for value,rate in zip(frozen['values'],defect)]
    value,derivative=dense_parts(physical_map(layout,source,frozen['masses'],WAVE,values,theta))
    logarithmic=np.linalg.solve(value.T,derivative.T).T
    metric=rows(layout,fluid=source['fluid'],massive=source['massive'],speeds=source['speeds'],
        external_density=source['density'],external_enthalpy=source['enthalpy'],defect=source['defect'],
        defect_rate=source['defect_first'],sound=frozen['thermal']['sound']['value'],scale_factor=source['scale'],
        masses=frozen['masses'],wave=WAVE,coordinate=values[0],velocity=values[1],rho=values[2],
        cosine=np.cos(2*theta),sine=np.sin(2*theta))
    answers=[]
    for branch in BRANCHES:
        forward,inverse=np.eye(layout['size']),np.eye(layout['size'])
        inverse_derivative=np.zeros_like(inverse)
        if layout['heavy']:
            forward_value,_=dense_parts(metric['maps'][branch]['forward_correction'])
            inverse_value,inverse_rate=dense_parts(metric['maps'][branch]['inverse_correction'])
            forward[layout['heavy']]+=forward_value
            inverse[layout['heavy']]+=inverse_value
            inverse_derivative[layout['heavy']]+=inverse_rate
        answers.append(inverse_derivative@forward+inverse@logarithmic@forward)
    return np.array(answers),value,logarithmic
