from common import *
from remainder_source import *
from correlated_source import full_endpoint
from mean_math import phase_primitive,interpolate,relative_error
from scipy.sparse.linalg import spsolve
import time


def primitive_with_rate(matrix,rate,angular,angular_rate):
    count=len(angular)
    variable=matrix-matrix[0]
    variable_rate=rate-rate[0]
    weight=1/angular
    weight_rate=-angular_rate/angular**2
    average=phase_primitive(variable,angular)
    mean=average['mean']
    mean_rate=np.einsum('p,pij->ij',weight,variable_rate)/weight.sum()
    mean_rate+=np.einsum('p,pij->ij',weight_rate,variable-mean)/weight.sum()
    forcing_rate=(variable_rate-mean_rate)/angular[:,None,None]-average['forcing']*(angular_rate/angular)[:,None,None]
    modes=np.fft.fftfreq(count,d=1/count)
    coefficients=np.fft.fft(forcing_rate,axis=0)/count
    derivative_coefficients=np.zeros_like(coefficients)
    selected=(modes!=0)&(abs(modes)!=count/2)
    derivative_coefficients[selected]=coefficients[selected]/(2j*modes[selected,None,None])
    slow=np.fft.ifft(derivative_coefficients*count,axis=0).real
    recovered=np.fft.ifft(derivative_coefficients*(2j*modes[:,None,None])*count,axis=0).real
    error=max(float(np.max(abs(coefficients[0]))),float(np.max(abs(recovered-forcing_rate))))/max(float(np.max(abs(forcing_rate))),1e-80)
    require(error<ALGEBRA,'derived slow primitive closure')
    return dict(mean=mean+matrix[0],mean_rate=mean_rate+rate[0],primitive=average['primitive'],
        phase_derivative=average['phase_derivative'],slow=slow,coefficients=average['coefficients'],
        derivative_coefficients=derivative_coefficients,closure=error)


def action(matrix,remote,keys,state):
    result=np.zeros_like(state)
    compact=len(matrix)
    result[:compact]=matrix@state[:compact]
    result+=np.bincount(keys[:,0],remote*state[keys[:,1]],minlength=len(state))
    return result


def node_forcing(owner,frozen,node,state,theta,output):
    compact=frozen['layout']['size']
    keys=node['keys']
    angles=np.arange(256)*np.pi/256 if owner.model=='heavy' else np.array([0.])
    count=len(angles)
    bank=np.empty((count,2,compact,compact))
    derivative=np.empty_like(bank)
    map_changes=np.empty_like(bank)
    remote=np.empty((count,len(keys)))
    remote_rate=np.empty_like(remote)
    inverse=np.empty(count)
    inverse_rate=np.empty(count)
    angular=np.empty(count)
    angular_rate=np.empty(count)
    background_defects=[]
    for number,angle in enumerate(angles):
        guard()
        prepared,result=evaluate_slow(owner,frozen,float(angle),keys)
        bank[number]=result['matrix']
        derivative[number]=result['derivative']
        remote[number]=result['remote']
        remote_rate[number]=result['remote_derivative']
        map_changes[number],_,_=map_defect(prepared['physical'],float(angle),prepared['defect'])
        inverse[number]=1/prepared['hubble'].value
        inverse_rate[number]=-prepared['hubble'].rate/prepared['hubble'].value**2
        angular[number]=prepared['angular'].value if owner.model=='heavy' else 1.
        angular_rate[number]=prepared['angular'].rate if owner.model=='heavy' else 0.
        background_defects.append(prepared['defect'])
        if number%64==0:
            print(LABEL,owner.model,'remainder phase',number,'of',count,'N',frozen['efold'],flush=True)
    parsed=[]
    for branch_index in range(2):
        parsed.append(primitive_with_rate(bank[:,branch_index],derivative[:,branch_index],angular,angular_rate))
    scalar=primitive_with_rate(inverse[:,None,None],inverse_rate[:,None,None],angular,angular_rate)
    scalar_value=scalar['primitive'][:,0,0]
    scalar_slow=scalar['slow'][:,0,0]
    diagonal=keys[:,0]==keys[:,1]
    stream=np.where(diagonal,0.,remote[0]/inverse[0])
    stream_rate=np.where(diagonal,0.,(remote_rate[0]-remote[0]*inverse_rate[0]/inverse[0])/inverse[0])
    drift=np.where(diagonal,remote[0],0.)
    drift_rate=np.where(diagonal,remote_rate[0],0.)
    require(relative_error(remote,drift[None,:]+inverse[:,None]*stream[None,:])<ALGEBRA,'retained complete remote structure')
    require(relative_error(remote_rate,drift_rate[None,:]+inverse_rate[:,None]*stream[None,:]+inverse[:,None]*stream_rate[None,:])<ALGEBRA,'derived complete remote slow derivative')
    mean_remote=drift+float(scalar['mean'][0,0])*stream
    mean_error=max(relative_error(mean_remote,node['remote']),*(relative_error(parsed[index]['mean'],node['mean'][index]) for index in range(2)))
    require(mean_error<ALGEBRA,'rederived means reproduce unchanged parent bank')
    force=np.empty((count,2,state.shape[-1]))
    normal=np.empty_like(force)
    mapped=np.empty_like(force)
    identity_errors=[]
    maximum_condition=0.
    for phase_index in range(count):
        guard()
        for branch_index in range(2):
            current=parsed[branch_index]
            primitive=current['primitive'][phase_index]
            slow=current['slow'][phase_index]
            primitive_remote=scalar_value[phase_index]*stream
            slow_remote=scalar_slow[phase_index]*stream+scalar_value[phase_index]*stream_rate
            vector=state[branch_index]
            periodic=action(primitive,primitive_remote,keys,vector)
            averaged=action(current['mean'],mean_remote,keys,vector)
            remainder=action(bank[phase_index,branch_index],remote[phase_index],keys,periodic)
            remainder-=action(primitive,primitive_remote,keys,averaged)
            remainder-=action(slow,slow_remote,keys,vector)
            map_force=np.zeros_like(vector)
            map_force[:compact]=map_changes[phase_index,branch_index]@(vector+periodic)[:compact]
            endpoint=full_endpoint(primitive,keys,stream,scalar_value[phase_index],len(vector))
            normal[phase_index,branch_index]=spsolve(endpoint,remainder)
            mapped[phase_index,branch_index]=spsolve(endpoint,map_force)
            force[phase_index,branch_index]=normal[phase_index,branch_index]+mapped[phase_index,branch_index]
            direct=action(bank[phase_index,branch_index],remote[phase_index],keys,vector+periodic)+map_force
            chain=endpoint@(averaged+force[phase_index,branch_index])
            phase_remote=float(scalar['phase_derivative'][phase_index,0,0])*stream
            chain+=action(slow+angular[phase_index]*current['phase_derivative'][phase_index],
                slow_remote+angular[phase_index]*phase_remote,keys,vector)
            identity_errors.append(relative_error(chain,direct))
            if max(identity_errors[-1:])>=ALGEBRA:
                raise ValueError('exact directional normal-form chain rule')
    coefficients=np.fft.fft(force,axis=0)/count
    normal_coefficients=np.fft.fft(normal,axis=0)/count
    map_coefficients=np.fft.fft(mapped,axis=0)/count
    modes=np.fft.fftfreq(count,d=1/count)
    physical=np.einsum('p,pbi->bi',np.exp(2j*modes*theta),coefficients).real
    weight=1/angular
    mean_force=np.einsum('p,pbi->bi',weight,force)/weight.sum()
    refinements=[]
    if count==256:
        lower_coefficients=np.fft.fft(force[::2],axis=0)/128
        lower_modes=np.fft.fftfreq(128,d=1/128)
        lower_physical=np.einsum('p,pbi->bi',np.exp(2j*lower_modes*theta),lower_coefficients).real
        lower_mean=np.einsum('p,pbi->bi',weight[::2],force[::2])/weight[::2].sum()
        for branch_index in range(2):
            scale=max(float(np.linalg.norm(force[:,branch_index],axis=1).max()),1e-80)
            error=max(float(np.linalg.norm(physical[branch_index]-lower_physical[branch_index])),
                float(np.linalg.norm(mean_force[branch_index]-lower_mean[branch_index])))/scale
            require(error<GATE,'unchanged phase refinement of omitted forcing')
            refinements.append(error)
    else:
        refinements=[0.,0.]
    np.savez_compressed(output,coefficients=coefficients,normal_coefficients=normal_coefficients,map_coefficients=map_coefficients,
        physical=physical,mean_force=mean_force,background_defect=np.array(background_defects),angular=angular,
        compact_coefficients=np.array([item['coefficients'] for item in parsed]),
        compact_slow_coefficients=np.array([item['derivative_coefficients'] for item in parsed]),
        scalar_coefficients=scalar['coefficients'],scalar_slow_coefficients=scalar['derivative_coefficients'],
        remote_keys=keys,remote_stream=stream,remote_stream_rate=stream_rate,state=state,theta=np.array(theta))
    scales=np.linalg.norm(state,axis=1)
    return dict(mean_relative=mean_error,maximum_chain_identity=max(identity_errors),phase_refinement=refinements,
        slow_closure=max(scalar['closure'],*(item['closure'] for item in parsed)),
        physical_force_per_state=(np.linalg.norm(physical,axis=1)/scales).tolist(),
        mean_force_per_state=(np.linalg.norm(mean_force,axis=1)/scales).tolist(),
        maximum_force_per_state=(np.max(np.linalg.norm(force,axis=2),axis=0)/scales).tolist(),
        maximum_map_force_per_state=(np.max(np.linalg.norm(mapped,axis=2),axis=0)/scales).tolist(),
        maximum_background_flow_defect=np.max(abs(background_defects),axis=0).tolist())


def main():
    modest()
    output=ROOT/'forcing-01'
    output.mkdir(parents=True,exist_ok=False)
    inputs=verify_inputs()
    consumed={}
    write(output/'freeze.json',dict(inputs=inputs,sources=sources(),source_indices=list(range(0,33,4)),phase_count=256,
        algebra=ALGEBRA,gate=GATE,reference_residual_not_used_to_fit=True,original_evolution='saved uncorrected correlated mean'))
    reports=[]
    for model in ('heavy','cold'):
        owner=CorrelatedSource(model)
        bank_path=CORRELATED/LABEL/'source-even-01'/f'{model}-bank.npz'
        evolution_path=CORRELATED/LABEL/'evolution-01'/f'{model}-fine.npz'
        bank,evolved=load(bank_path),load(evolution_path)
        consumed.update({str(path):digest(path) for path in (bank_path,evolution_path)})
        nodes=[]
        for index in range(0,33,4):
            started=time.monotonic()
            source_path=CORRELATED/LABEL/'source-even-01'/f'{model}-{index:02d}-source.json'
            node_path=source_path.with_name(f'{model}-{index:02d}-mean.npz')
            consumed.update({str(path):digest(path) for path in (source_path,node_path)})
            frozen,node=read(source_path),load(node_path)
            bank_index=index//2
            target=output/f'{model}-{index:02d}-forcing.npz'
            record=node_forcing(owner,frozen,node,evolved['state'][bank_index],float(bank['phase'][bank_index]),target)
            record.update(index=index,efold=frozen['efold'],seconds=time.monotonic()-started,path=str(target),sha256=digest(target))
            write(output/f'{model}-{index:02d}-report.json',record)
            nodes.append(record)
            print(LABEL,model,'complete derived forcing',index,record,flush=True)
        reports.append(dict(model=model,nodes=nodes))
    require(all(digest(path)==seal for path,seal in consumed.items()),'original sources unchanged')
    write(output/'result.json',dict(passed=True,inputs=inputs,sources=sources(),consumed=consumed,reports=reports,
        physical_gates_unchanged=True,no_reference_residual_fitted=True))


if __name__=='__main__':
    main()
