from common import *
import numpy as np


def main():
    modest()
    output=STAGE/'audit'
    output.mkdir(exist_ok=False)
    inputs=verify_inputs()
    consumed,accepted={},{}
    records,forcing,refinement,derivatives,probes=[],[],[],[],[]
    observable_controls=[]
    for label in ('half','balanced','double'):
        for phase in ('probe-01','forcing-02','slow-rate-validation-01','evolution-01','predictions-01','comparison-01','control-readout-01'):
            path=STAGE/label/phase/'result.json'
            report=read(path)
            require(report['passed'],'completed numerical work or honest reference comparison')
            accepted[str(path)]=digest(path)
            for field in ('inputs','sources','consumed'):
                for source,seal in report[field].items():
                    require(digest(source)==seal,'executed/imported source unchanged: '+source)
                    consumed[source]=seal
        probe=read(STAGE/label/'probe-01/result.json')
        probes.extend(probe['records'])
        source=read(STAGE/label/'forcing-02/result.json')
        require({row['model'] for row in source['reports']}=={'heavy','cold'},'paired forcing sources')
        for model in source['reports']:
            require([node['index'] for node in model['nodes']]==list(range(0,33,4)),'frozen nine epochs completed')
            for node in model['nodes']:
                require(digest(node['path'])==node['sha256'],'frozen forcing packet unchanged')
                consumed[node['path']]=node['sha256']
                require(node['mean_relative']<ALGEBRA and node['maximum_chain_identity']<ALGEBRA and node['slow_closure']<ALGEBRA and max(node['phase_refinement'])<GATE,'derived forcing gates unchanged')
                packet=load(node['path'])
                difference=packet['coefficients']-packet['normal_coefficients']-packet['map_coefficients']
                require(float(np.max(abs(difference)))<ALGEBRA*max(1.,float(np.max(abs(packet['coefficients'])))),'normal and map forcing sum')
                require(np.isfinite(packet['coefficients']).all() and np.isfinite(packet['compact_slow_coefficients']).all(),'finite derived packets')
                forcing.append(dict(label=label,model=model['model'],**node))
        derivative=read(STAGE/label/'slow-rate-validation-01/result.json')
        require(derivative['exact_normal_form_identity']=='0','exact noncommutative identity')
        for model in derivative['reports']:
            for check in model['checks']:
                require(max(*check['compact_relative'],check['remote_relative'])<GATE,'fixed-phase independent derivative check')
                derivatives.append(dict(label=label,model=model['model'],**check))
        evolution=read(STAGE/label/'evolution-01/result.json')
        for model in evolution['reports']:
            for check in model['checks']:
                require(check['relative']<GATE,'unchanged propagated physical refinement')
                refinement.append(dict(label=label,model=model['model'],**check))
        ended=read(STAGE/f'predictions-{label}-01.end.json')
        started=read(STAGE/f'comparison-{label}-01.start.json')
        require(datetime.fromisoformat(ended['finished'])<=datetime.fromisoformat(started['created']),'new corrected outputs frozen before reference read')
        controls=read(STAGE/label/'control-readout-01/result.json')
        for model in controls['reports']:
            for check in model['checks']:
                require(check['relative']<GATE,'unchanged physical observable uncertainty gate')
                observable_controls.append(dict(label=label,model=model['model'],**check))
        comparison=read(STAGE/label/'comparison-01/result.json')
        prior_path=CORRELATED/label/'comparison-01/result.json'
        previous=read(prior_path)
        consumed[str(prior_path)]=digest(prior_path)
        for model in comparison['reports']:
            packet_path=STAGE/label/'comparison-01'/f"{model['model']}-comparison.npz"
            packet=load(packet_path)
            consumed[str(packet_path)]=digest(packet_path)
            old_model=next(row for row in previous['reports'] if row['model']==model['model'])
            for branch_index,branch in enumerate(model['branches']):
                for column,observable in enumerate(branch['observables']):
                    reference=packet['reference'][:,branch_index,column]
                    predicted=packet['predicted'][:,branch_index,column]
                    relative=float(np.max(abs(predicted-reference))/max(np.max(abs(reference)),1e-80))
                    require(abs(relative-observable['relative'])<ALGEBRA and observable['within_gate']==bool(relative<GATE),'honest recomputed physical verdict')
                require(branch['physical_pass']==all(row['within_gate'] for row in branch['observables']),'branch verdict')
                worst=max(branch['observables'],key=lambda row:row['relative'])
                old=next(row for row in old_model['branches'] if row['branch']==branch['branch'])
                old_worst=max(row['relative'] for row in old['observables'])
                records.append(dict(label=label,model=model['model'],branch=branch['branch'],physical_pass=branch['physical_pass'],
                    worst_relative=worst['relative'],worst_observable=worst['name'],worst_probe=worst['maximum_probe'],
                    previous_worst_relative=old_worst,improvement_factor=old_worst/max(worst['relative'],1e-80),
                    normalized_state_relative=branch['normalized_state_relative'],
                    initial_max_relative=max(row['initial_relative'] for row in branch['observables'])))
    failed=read(STAGE/'forcing-half-01.end.json')
    require(failed['exit_code']==1 and (STAGE/'half/forcing-01/heavy-00-forcing.npz').exists(),'original reporting failure preserved')
    for path in STAGE.glob('*.py'):
        compile(path.read_text(encoding='utf-8-sig'),str(path),'exec',dont_inherit=True)
    require(not list(STAGE.rglob('__pycache__')),'no bytecode caches')
    write(output/'result.json',dict(passed=True,inputs=inputs,sources=sources(),consumed=consumed,accepted_results=accepted,
        failed_attempts_preserved=['forcing-half-01'],compiler_receipts=[],records=records,
        physical_approximation_all_pass=all(row['physical_pass'] for row in records),
        maximum_chain_identity=max(row['maximum_chain_identity'] for row in forcing),
        maximum_slow_closure=max(row['slow_closure'] for row in forcing),
        maximum_forcing_phase_refinement=max(max(row['phase_refinement']) for row in forcing),
        maximum_fixed_phase_derivative_difference=max(max(*row['compact_relative'],row['remote_relative']) for row in derivatives),
        maximum_complex_derivative_difference=max(check['mixed_scaled_error'] for row in probes for check in row['derivative_checks']),
        maximum_native_physical_map_difference=max(max(row['physical_map_relative'],row['physical_map_mixed_error']) for row in probes),
        maximum_time_refinement_relative=max(row['relative'] for row in refinement if row['control']=='step-coarse'),
        maximum_source_refinement_relative=max(row['relative'] for row in refinement if row['control']=='source-coarse'),
        maximum_time_refinement_relative_to_correction=max(row['relative_to_correction'] for row in refinement if row['control']=='step-coarse' and row['model']=='heavy'),
        maximum_source_refinement_relative_to_correction=max(row['relative_to_correction'] for row in refinement if row['control']=='source-coarse' and row['model']=='heavy'),
        maximum_source_observable_control=max(row['relative'] for row in observable_controls if row['control']=='source-coarse'),
        maximum_time_observable_control=max(row['relative'] for row in observable_controls if row['control']=='step-coarse'),
        forcing_nodes=len(forcing),no_fitted_coefficients=True,physical_gates_unchanged=True,first_variation_only=True,
        omitted_second_response_and_true_background_difference=True,no_new_initial_mode=True,no_late_history=True))
    print('derived first-response physical results',[(row['label'],row['model'],row['branch'],row['worst_relative'],row['physical_pass']) for row in records],flush=True)


if __name__=='__main__':
    main()


