from common import *
from early_source import EarlySource,BRANCHES,matrices
from coupled_jets import evaluate
from stable_coupled import assemble
from factored_sparse import evaluate as sparse_evaluate
from enclose_free import complete_layout
from free_math_v2 import build,dense
from mean_math import phase_primitive,interpolate,relative_error
from scipy.integrate import solve_ivp
from scipy.sparse import csr_matrix,coo_matrix,block_diag,eye
from scipy.sparse.linalg import spsolve
import numpy as np


def correction(density,external,external_rate,coordinate,velocity,omega,theta):
    hubble=np.sqrt((external+(coordinate**2+velocity**2)/2+density)/3)
    inverse=hubble/omega
    fraction=density/(3*hubble**2)
    eta0=(external_rate+coordinate**2-2*velocity**2-density)/(6*hubble**2)
    coefficient_a=1.5*(1-eta0)
    coefficient_b=1.125*(2-fraction)
    value=1.5*inverse*np.sin(2*theta)-.5*coefficient_a*inverse**2*np.cos(2*theta)-.25*coefficient_b*inverse**2*np.cos(4*theta)
    derivative=.75*fraction*inverse*np.sin(2*theta)-1.125*fraction*inverse**2*np.cos(2*theta)-.28125*fraction*inverse**2*np.cos(4*theta)
    return value,hubble,derivative


def reconstruct(mean_density,external,external_rate,coordinate,velocity,omega,theta):
    require(mean_density>0 and omega>0,'positive reconstructed heavy branch')
    theta=np.asarray(theta)
    shift=np.zeros_like(theta,dtype=float)
    for iteration in range(12):
        density=mean_density*np.exp(shift)
        candidate,_,_=correction(density,external,external_rate,coordinate,velocity,omega,theta)
        error=float(np.max(abs(candidate-shift)))
        shift=candidate
        if error<1e-16:
            break
    density=mean_density*np.exp(shift)
    value,hubble,derivative=correction(density,external,external_rate,coordinate,velocity,omega,theta)
    residual=float(np.max(abs(value-shift)))
    require(residual<1e-15 and np.max(abs(shift))<.02 and np.max(abs(derivative))<.000759,'proved contraction branch and unchanged arithmetic qualification')
    return dict(density=density,hubble=hubble,log_shift=shift,residual=residual,iterations=iteration+1,derivative=derivative)


def correlated(frozen,theta):
    result=dict(frozen)
    values=list(frozen['values'])
    source=frozen['source']
    reconstruction=reconstruct(values[2],source['density'],source['density_first'],values[0],values[1],
        source['scale']*frozen['masses'][1],theta)
    values[2]=float(reconstruction['density'])
    result['values']=values
    return result,reconstruction


class CorrelatedSource(EarlySource):
    def phase_history(self,efolds,steps):
        if self.model=='cold':
            return np.zeros(len(efolds)),0
        def rhs(efold,theta):
            guard()
            background=self.saved.mean(efold)
            slow=background['slow'][0]
            external=background['external'][0]
            omega=np.exp(efold)*self.saved.masses[1]
            density=reconstruct(float(background['heavy'][0]),float(external[0]),float(external[1]),
                float(slow[0]),float(slow[1]),omega,float(theta[0]))
            return [omega/float(density['hubble'])-1.5*np.sin(2*theta[0])]
        span=efolds[-1]-efolds[0]
        solution=solve_ivp(rhs,(efolds[0],efolds[-1]),[self.original['theta']],t_eval=efolds,
            method='DOP853',rtol=2e-12,atol=2e-14,max_step=span/steps)
        require(solution.success and np.all(np.isfinite(solution.y)),'reconstructed physical phase solve')
        return solution.y[0],solution.nfev


def full_endpoint(compact_matrix,remote_keys,remote_stream,remote_primitive,dimension):
    compact=len(compact_matrix)
    tail=csr_matrix((dimension-compact,dimension-compact))
    remote=coo_matrix((remote_primitive*remote_stream,(remote_keys[:,0],remote_keys[:,1])),shape=(dimension,dimension))
    return (eye(dimension,format='csc')+block_diag((csr_matrix(compact_matrix),tail),format='csc')+remote.tocsc()).tocsc()


def invert_endpoint(closed,compact_matrix,remote_keys,remote_stream,remote_primitive):
    operator=full_endpoint(compact_matrix,remote_keys,remote_stream,remote_primitive,len(closed))
    result=spsolve(operator,closed)
    error=relative_error(operator@result,closed)
    require(error<ALGEBRA,'full G192 periodic endpoint inverse')
    return result,error


def full_average(frozen,model,theta,primitive_path=None):
    layout=frozen['layout']
    compact=layout['size']
    complete=complete_layout(layout)
    angles=np.arange(256)*np.pi/256 if model=='heavy' else np.array([0.])
    bank,collisions,inverses,clocks=[],[],[],[]
    remote_keys=remote_stream=remote_drift=None
    maximum_root=0.
    for number,angle in enumerate(angles):
        if number%32==0:
            guard()
        if model=='heavy':
            current,reconstructed=correlated(frozen,float(angle))
            hubble=float(reconstructed['hubble'])
            maximum_root=max(maximum_root,reconstructed['residual'])
        else:
            current=frozen
            values=current['values']
            hubble=((current['source']['density']+(values[0]**2+values[1]**2)/2)/3)**.5
        source,values=current['source'],current['values']
        arguments=(layout,source,current['masses'],WAVE,values,current['thermal'],float(angle))
        direct=evaluate(*arguments)
        stable=assemble(*arguments,direct)
        bank.append(np.array([stable[branch] for branch in BRANCHES]))
        physical={name:source[name] for name in ('fluid','massive','speeds','density','enthalpy','scale')}
        unit=dense(build(layout,physical,current['thermal']['sound']['value'],hubble,current['masses'],WAVE,*values,1.,0.)['groups']['collision'],compact)
        require(not np.any(unit[:,layout['heavy']]),'retained collision support')
        coefficient=np.array([unit,unit])/hubble
        if model=='heavy':
            for branch_index,branch in enumerate(BRANCHES):
                coefficient[branch_index,layout['heavy']]+=direct['branches'][branch]['inverse']@unit/hubble
        collisions.append(coefficient)
        inverses.append(1/hubble)
        clocks.append(source['scale']*current['masses'][1]/hubble-1.5*np.sin(2*angle) if model=='heavy' else 1.)
        if number in (0,63,127,191):
            full=sparse_evaluate(complete,source,current['masses'],WAVE,values,current['thermal'],np.cos(2*angle),np.sin(2*angle))
            remotes={branch:{key:value for key,value in full['branches'][branch].items() if max(key)>=compact} for branch in BRANCHES}
            require(remotes[BRANCHES[0]]==remotes[BRANCHES[1]],'paired full hierarchy')
            keys=sorted(remotes[BRANCHES[0]])
            entries=np.array([remotes[BRANCHES[0]][key] for key in keys])
            diagonal=np.array([row==column for row,column in keys])
            if remote_keys is None:
                remote_keys=np.array(keys,dtype=int)
                remote_stream=np.where(diagonal,0.,entries*hubble)
                remote_drift=np.where(diagonal,entries,0.)
            require(np.array_equal(remote_keys,np.array(keys)),'complete sparse support fixed')
            remote_error=relative_error(entries,remote_drift+remote_stream/hubble)
            require(remote_error<ALGEBRA,'full remote drift plus variable 1/H streaming identity')
            for branch_index,branch in enumerate(BRANCHES):
                principal=np.zeros((compact,compact))
                for (row,column),value in full['branches'][branch].items():
                    if max(row,column)<compact:
                        principal[row,column]=value
                require(relative_error(principal,bank[-1][branch_index])<ALGEBRA,'full principal source identity')
    bank=np.array(bank)
    collisions=np.array(collisions)
    inverses=np.array(inverses)
    clocks=np.array(clocks)
    require(np.min(clocks)>0,'positive reconstructed phase clock')
    if model=='cold':
        return dict(mean=bank[0],collision=collisions[0],noncollision=bank[0]-frozen['thermal']['opacity']['value']*collisions[0],
            remote=remote_drift+remote_stream*inverses[0],remote_keys=remote_keys,remote_stream=remote_stream,remote_drift=remote_drift,
            endpoint=np.zeros_like(bank[0]),remote_endpoint=0.,mean_inverse_hubble=float(inverses[0]),
            closure=0.,phase_refinement=0.,full_primitive_bound=0.,root_residual=0.)
    weights=1/clocks
    average_collision=np.einsum('p,pbij->bij',weights,collisions)/weights.sum()
    inverse_average=phase_primitive((inverses-inverses[0])[:,None,None],clocks)
    inverse_mean=float(inverse_average['mean'][0,0]+inverses[0])
    remote_endpoint=float(interpolate(inverse_average['coefficients'],theta)[0,0])
    remote_coefficients=inverse_average['coefficients']
    remote_norm=float(np.linalg.norm(remote_stream))
    remote_primitive_bound=float(np.sum(abs(remote_coefficients)))*remote_norm
    inverse_closure=max(inverse_average['closure'],inverse_average['unresolved'])/max(float(np.max(abs(inverse_average['forcing']))),1e-80)
    require(inverse_closure<ALGEBRA,'full hierarchy streaming primitive closure')
    means,ends,coefficients,closures,refinements,bounds=[],[],[],[],[],[]
    for branch_index in range(2):
        variable=bank[:,branch_index]-bank[0,branch_index]
        average=phase_primitive(variable,clocks)
        lower=phase_primitive(variable[::2],clocks[::2])
        mean=average['mean']+bank[0,branch_index]
        endpoint=interpolate(average['coefficients'],theta)
        closure=max(average['closure'],average['unresolved'])/max(float(np.max(abs(average['forcing']))),1e-80)
        refinement=max(relative_error(mean,lower['mean']+bank[0,branch_index]),
            relative_error(endpoint,interpolate(lower['coefficients'],theta)))
        bound=float(np.sum(np.linalg.norm(average['coefficients'],axis=(1,2))))+remote_primitive_bound
        require(closure<ALGEBRA and refinement<GATE and bound<1,'correlated phase mean/primitive unchanged gates')
        means.append(mean);ends.append(endpoint);coefficients.append(average['coefficients'])
        closures.append(closure);refinements.append(refinement);bounds.append(bound)
    if primitive_path is not None:
        np.savez_compressed(primitive_path,coefficients=np.array(coefficients),mean=np.array(means),endpoint=np.array(ends),
            remote_coefficients=remote_coefficients,remote_keys=remote_keys,remote_stream=remote_stream,
            remote_drift=remote_drift,theta=np.array(theta))
    mean=np.array(means)
    return dict(mean=mean,collision=average_collision,noncollision=mean-frozen['thermal']['opacity']['value']*average_collision,
        remote=remote_drift+remote_stream*inverse_mean,remote_keys=remote_keys,remote_stream=remote_stream,remote_drift=remote_drift,
        endpoint=np.array(ends),remote_endpoint=remote_endpoint,mean_inverse_hubble=inverse_mean,
        closure=max(*closures,inverse_closure),phase_refinement=max(refinements),
        full_primitive_bound=max(bounds),root_residual=maximum_root)

