from common import *
import numpy as np


def main():
    modest()
    output=STAGE/'audit'
    output.mkdir(exist_ok=False)
    inputs=verify_inputs()
    consumed,accepted={},{}
    records,source_checks,time_checks,phase_checks,primitive_checks=[],[],[],[],[]
    independent=[]
    preparation=[]
    for label in ('half','balanced','double'):
        for phase in ('source-even-01','preparation-01','source-heldout-01','evolution-01','predictions-01','comparison-01','independent-01'):
            path=STAGE/label/phase/'result.json'
            report=read(path)
            require(report['passed'],'accepted numerical work or completed honest comparison')
            accepted[str(path)]=digest(path)
            for field in ('inputs','sources','consumed'):
                for candidate,seal in report[field].items():
                    require(digest(candidate)==seal,'unchanged source: '+candidate)
                    consumed[candidate]=seal
        source_report=read(STAGE/label/'source-heldout-01/result.json')
        for model in source_report['reports']:
            require(len(model['checks'])==16,'all frozen independent held-out times')
            for check in model['checks']:
                require(max(check[key] for key in ('fine_mean_absolute','coarse_mean_absolute','fine_remote_absolute','coarse_remote_absolute'))<GATE,'unchanged source coefficient gates')
                source_checks.append(check)
        for model in read(STAGE/label/'source-even-01/result.json')['reports']:
            require(model['phase_difference']<ALGEBRA,'physical phase step refinement')
            phase_checks.append(model['phase_difference'])
            for node in model['nodes']:
                require(node['closure']<ALGEBRA and node['phase_refinement']<GATE and node['full_primitive_bound']<1,'qualified correlated full primitive')
                primitive_checks.append(node)
        for model in read(STAGE/label/'preparation-01/result.json')['reports']:
            require(max(model['physical_initial_background_relative'],model['rho_relative'])<ALGEBRA,'original background restored')
            for check in model['checks']:
                require(max(check['full_inverse_relative'],check['original_encoded_relative'])<ALGEBRA and check['original_readout_relative']<GATE,'original preparation restored')
                preparation.append(dict(label=label,model=model['model'],**check))
        for model in read(STAGE/label/'evolution-01/result.json')['reports']:
            for check in model['checks']:
                require(check['relative']<GATE,'unchanged source/time refinement')
                time_checks.append(dict(label=label,model=model['model'],**check))
        independent.append(read(STAGE/label/'independent-01/result.json'))
        prediction_end=read(STAGE/f'predictions-{label}-01.end.json')
        comparison_start=read(STAGE/f'comparison-{label}-01.start.json')
        require(datetime.fromisoformat(prediction_end['finished'])<=datetime.fromisoformat(comparison_start['created']),'frozen physical predictions precede reference comparison')
        report=read(STAGE/label/'comparison-01/result.json')
        prior_path=TRANSPORT/label/'comparison-01/result.json'
        prior=read(prior_path)
        consumed[str(prior_path)]=digest(prior_path)
        for model in report['reports']:
            path=STAGE/label/'comparison-01'/f"{model['model']}-comparison.npz"
            packet=load(path)
            consumed[str(path)]=digest(path)
            for branch_index,branch in enumerate(model['branches']):
                for column,observable in enumerate(branch['observables']):
                    reference=packet['reference'][:,branch_index,column]
                    predicted=packet['predicted'][:,branch_index,column]
                    relative=float(np.max(abs(predicted-reference))/max(np.max(abs(reference)),1e-80))
                    require(abs(relative-observable['relative'])<ALGEBRA and observable['within_gate']==bool(relative<GATE),'independent honest observable verdict')
                require(branch['physical_pass']==all(row['within_gate'] for row in branch['observables']),'branch verdict')
                worst=max(branch['observables'],key=lambda row:row['relative'])
                old_model=next(row for row in prior['reports'] if row['model']==model['model'])
                old_branch=next(row for row in old_model['branches'] if row['branch']==branch['branch'])
                old_worst=max(row['relative'] for row in old_branch['observables'])
                records.append(dict(label=label,model=model['model'],branch=branch['branch'],physical_pass=branch['physical_pass'],
                    worst_observable=worst['name'],worst_relative=worst['relative'],worst_probe=worst['maximum_probe'],
                    normalized_state_relative=branch['normalized_state_relative'],phase_difference=model['maximum_phase_difference'],
                    density_relative=model['maximum_density_relative'],previous_worst_relative=old_worst,
                    improvement_factor=old_worst/max(worst['relative'],1e-80),
                    initial_max_relative=max(row['initial_relative'] for row in branch['observables'])))
            require(model['all_physical_pass']==all(row['physical_pass'] for row in model['branches']),'model verdict')
        require(report['all_physical_comparisons_pass']==all(row['all_physical_pass'] for row in report['reports']),'family verdict')
    for path in STAGE.glob('*.py'):
        compile(path.read_text(encoding='utf-8-sig'),str(path),'exec',dont_inherit=True)
    require(not list(STAGE.rglob('__pycache__')),'no bytecode cache')
    roots=[row for report in independent for row in report['roots']]
    offgrid=[row for report in independent for row in report['primitives']]
    collision=[row for report in independent for row in report['collisions']]
    require(len(roots)==42 and len(offgrid)==36 and len(collision)==48,'complete independent validation coverage')
    summary=dict(passed=True,inputs=inputs,sources=sources(),consumed=consumed,accepted_results=accepted,
        failed_attempts_preserved=[],compiler_receipts=[],records=records,physical_gates_unchanged=True,
        original_preparation_preserved=True,physical_approximation_all_pass=all(row['physical_pass'] for row in records),
        maximum_source_interpolation_absolute=max(row[key] for row in source_checks for key in ('fine_mean_absolute','coarse_mean_absolute','fine_remote_absolute','coarse_remote_absolute')),
        maximum_time_refinement_relative=max(row['relative'] for row in time_checks if row['control']=='step-coarse'),
        maximum_source_refinement_relative=max(row['relative'] for row in time_checks if row['control']=='source-coarse'),
        maximum_phase_step_difference=max(phase_checks),maximum_full_primitive_bound=max(row['full_primitive_bound'] for row in primitive_checks),
        maximum_initial_encoded_relative=max(row['original_encoded_relative'] for row in preparation),
        maximum_root_high_precision_relative=max(row['density_relative'] for row in roots),
        maximum_collision_identity_absolute=max(row['absolute'] for row in collision),
        maximum_offgrid_primitive_absolute=max(max(row['compact_absolute'],row['remote_absolute']) for row in offgrid),
        no_new_fit=True,no_new_initial_mode=True,no_late_history=True,slow_history_and_invariant_remainders_retained=True)
    write(output/'result.json',summary)
    print('correlated early transport verified:',[(row['label'],row['model'],row['branch'],row['worst_relative'],row['physical_pass']) for row in records],flush=True)


if __name__=='__main__':
    main()
