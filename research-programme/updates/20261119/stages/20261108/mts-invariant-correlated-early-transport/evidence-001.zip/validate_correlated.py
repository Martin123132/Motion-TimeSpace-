from common import *
from correlated_source import *
from copy import deepcopy
import mpmath as mp


def independent_root(frozen, angle):
    mp.mp.dps=80
    coordinate,velocity,mean_density=map(mp.mpf,frozen['values'][:3])
    external=mp.mpf(frozen['source']['density'])
    external_rate=mp.mpf(frozen['source']['density_first'])
    omega=mp.mpf(frozen['source']['scale'])*mp.mpf(frozen['masses'][1])
    def terms(shift,phase):
        density=mean_density*mp.exp(shift)
        hubble=mp.sqrt((external+(coordinate**2+velocity**2)/2+density)/3)
        inverse=hubble/omega
        fraction=density/(3*hubble**2)
        eta=(external_rate+coordinate**2-2*velocity**2-density)/(6*hubble**2)
        coefficient_a=mp.mpf('1.5')*(1-eta)
        coefficient_b=mp.mpf('1.125')*(2-fraction)
        value=mp.mpf('1.5')*inverse*mp.sin(2*phase)-coefficient_a*inverse**2*mp.cos(2*phase)/2-coefficient_b*inverse**2*mp.cos(4*phase)/4
        derivative=mp.mpf('.75')*fraction*inverse*mp.sin(2*phase)-mp.mpf('1.125')*fraction*inverse**2*mp.cos(2*phase)-mp.mpf('.28125')*fraction*inverse**2*mp.cos(4*phase)
        phase_derivative=3*inverse*mp.cos(2*phase)+coefficient_a*inverse**2*mp.sin(2*phase)+coefficient_b*inverse**2*mp.sin(4*phase)
        return value,hubble,derivative,phase_derivative
    phase=mp.mpf(angle)
    root=mp.findroot(lambda shift: shift-terms(shift,phase)[0],(mp.mpf('-.002'),mp.mpf('.002')))
    value,hubble,derivative,phase_derivative=terms(root,phase)
    numerical=mp.diff(lambda shift:terms(shift,phase)[0],root)
    implicit=phase_derivative/(1-derivative)
    independent=mp.diff(lambda phase:mp.findroot(lambda shift:shift-terms(shift,phase)[0],root),phase,addprec=100)
    require(abs(derivative-numerical)<mp.mpf('1e-60') and abs(implicit-independent)<mp.mpf('1e-60'),'independent high-precision implicit derivatives')
    float_result=correlated(frozen,angle)[1]
    density_relative=float(abs(mp.mpf(float(float_result['density']))/(mean_density*mp.exp(root))-1))
    hubble_relative=float(abs(mp.mpf(float(float_result['hubble']))/hubble-1))
    require(max(density_relative,hubble_relative)<ALGEBRA,'float reconstruction against independent high-precision root')
    return dict(theta=angle,density_relative=density_relative,hubble_relative=hubble_relative,
        derivative_error=float(abs(derivative-numerical)),implicit_phase_derivative_error=float(abs(implicit-independent)),
        root_residual=float(abs(root-value)),contraction=float(abs(derivative)))


def main():
    modest()
    output=ROOT/'independent-01'
    output.mkdir(exist_ok=False)
    inputs=verify_inputs()
    consumed={}
    roots,primitives,collisions,means=[],[],[],[]
    for model in ('heavy','cold'):
        for index in (0,32):
            source_path=ROOT/'source-even-01'/f'{model}-{index:02d}-source.json'
            node_path=ROOT/'source-even-01'/f'{model}-{index:02d}-mean.npz'
            consumed.update({str(path):digest(path) for path in (source_path,node_path)})
            frozen,node=read(source_path),load(node_path)
            layout=frozen['layout']
            compact=layout['size']
            complete=complete_layout(layout)
            if model=='heavy':
                for angle in (0.,.239,.71,1.157,1.93,2.613,3.01):
                    roots.append(dict(index=index,**independent_root(frozen,angle)))
                primitive_path=ROOT/'source-even-01'/f'{model}-{index:02d}-primitive.npz'
                consumed[str(primitive_path)]=digest(primitive_path)
                primitive=load(primitive_path)
                angles=np.arange(256)*np.pi/256
                values=frozen['values']
                source=frozen['source']
                omega=source['scale']*frozen['masses'][1]
                reconstruction=reconstruct(values[2],source['density'],source['density_first'],values[0],values[1],omega,angles)
                inverse=1/reconstruction['hubble']
                clocks=omega*inverse-1.5*np.sin(2*angles)
                lower=phase_primitive((inverse[::2]-inverse[0])[:,None,None],clocks[::2])
                high_precision=sum(mp.mpf(float(value))/mp.mpf(float(clock)) for value,clock in zip(inverse,clocks))/sum(1/mp.mpf(float(clock)) for clock in clocks)
                mean_error=abs(float(high_precision)/float(node['mean_inverse_hubble'])-1)
                lower_mean_error=abs(float(lower['mean'][0,0]+inverse[0])/float(node['mean_inverse_hubble'])-1)
                primitive_error=relative_error(interpolate(lower['coefficients'],float(primitive['theta'])),
                    interpolate(primitive['remote_coefficients'],float(primitive['theta'])))
                require(max(mean_error,lower_mean_error)<ALGEBRA and primitive_error<GATE,'full-hierarchy mean and primitive independent controls')
                means.append(dict(index=index,mean_high_precision_relative=mean_error,mean_128_relative=lower_mean_error,primitive_128_relative=primitive_error))
            for angle in ((.239,1.157,2.613) if model=='heavy' else (.239,)):
                guard()
                current,reconstruction=correlated(frozen,angle) if model=='heavy' else (frozen,None)
                source,values=current['source'],current['values']
                hubble=((source['density']+(values[0]**2+values[1]**2)/2+values[2])/3)**.5
                arguments=(layout,source,current['masses'],WAVE,values,current['thermal'],angle)
                direct=evaluate(*arguments)
                matrix=assemble(*arguments,direct)
                zero_thermal=deepcopy(current['thermal'])
                zero_thermal['opacity']['value']=0.
                zero=evaluate(layout,source,current['masses'],WAVE,values,zero_thermal,angle)
                physical={name:source[name] for name in ('fluid','massive','speeds','density','enthalpy','scale')}
                unit=dense(build(layout,physical,current['thermal']['sound']['value'],hubble,current['masses'],WAVE,*values,1.,0.)['groups']['collision'],compact)
                require(not np.any(unit[:,layout['heavy']]),'collision annihilates heavy input columns')
                for branch_index,branch in enumerate(BRANCHES):
                    coefficient=unit.copy()/hubble
                    if model=='heavy':
                        coefficient[layout['heavy']]+=direct['branches'][branch]['inverse']@unit/hubble
                    actual=direct['branches'][branch]['closed']-zero['branches'][branch]['closed']
                    expected=current['thermal']['opacity']['value']*coefficient
                    absolute=float(np.max(abs(actual-expected)))
                    relative=relative_error(actual,expected)
                    require(absolute<GATE and relative<ALGEBRA,'independent reconstructed collision identity')
                    collisions.append(dict(model=model,index=index,theta=angle,branch=branch,absolute=absolute,relative=relative))
                if model!='heavy':
                    continue
                angular=source['scale']*current['masses'][1]/hubble-1.5*np.sin(2*angle)
                modes=np.fft.fftfreq(256,d=1/256)
                factor=(2j*modes)[:,None,None]
                full=sparse_evaluate(complete,source,current['masses'],WAVE,values,current['thermal'],np.cos(2*angle),np.sin(2*angle))
                remote_actual=np.array([full['branches'][BRANCHES[0]][tuple(key)] for key in node['keys']])
                remote_expected=node['remote_drift']+node['remote_stream']/hubble
                remote_identity=relative_error(remote_actual,remote_expected)
                remote_derivative=float(interpolate(primitive['remote_coefficients']*factor,angle)[0,0])*angular*node['remote_stream']
                remote_forcing=remote_actual-node['remote']
                remote_absolute=float(np.max(abs(remote_derivative-remote_forcing)))
                require(remote_identity<ALGEBRA and remote_absolute<GATE,'off-grid full G192 source and phase derivative')
                for branch_index,branch in enumerate(BRANCHES):
                    derivative=interpolate(primitive['coefficients'][branch_index]*factor,angle)*angular
                    forcing=matrix[branch]-node['mean'][branch_index]
                    absolute=float(np.max(abs(derivative-forcing)))
                    require(absolute<GATE,'off-grid compact phase derivative')
                    primitives.append(dict(index=index,theta=angle,branch=branch,compact_absolute=absolute,
                        remote_absolute=remote_absolute,remote_source_relative=remote_identity))
    require(all(digest(path)==seal for path,seal in consumed.items()),'independent inputs unchanged')
    write(output/'result.json',dict(passed=True,inputs=inputs,sources=sources(),consumed=consumed,
        roots=roots,means=means,primitives=primitives,collisions=collisions,physical_gates_unchanged=True,
        scope='independent numerical checks of retained finite phase reconstruction; no continuum quadrature theorem'))
    print(LABEL,'independent correlated checks passed',len(roots),len(primitives),len(collisions),flush=True)


if __name__=='__main__':
    main()
