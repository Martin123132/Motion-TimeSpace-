from common import *
from correlated_source import *
from matching_source import frozen_source,to_physical,from_physical,apply_correction
from adjoint_operator import open_owned
from physical_energy_map import PhysicalEnergyMap
from matched_cold_fibre import MatchedColdFibre
import numpy as np


def main():
    modest()
    output=ROOT/'preparation-01'
    output.mkdir(exist_ok=False)
    (output/'contexts').mkdir()
    parent=ROOT/'source-even-01'
    require(read(parent/'result.json')['passed'],'correlated source bank')
    inputs=verify_inputs()
    consumed={str(parent/'result.json'):digest(parent/'result.json')}
    write(output/'freeze.json',dict(inputs=inputs,sources=sources(),consumed=consumed,
        initial_state='original normalized native mode; new correlated primitive and physical maps',
        full_G192_endpoint_inverse=True,gate=GATE,algebra=ALGEBRA))
    reports=[]
    for model in ('heavy','cold'):
        source=CorrelatedSource(model)
        bank_path=parent/f'{model}-bank.npz'
        node_path=parent/f'{model}-00-mean.npz'
        original_path=MATCHING/LABEL/'preparation-01'/f'{model}-exact-prepared.npz'
        original_result_path=MATCHING/LABEL/'preparation-01'/f'{model}-result.json'
        consumed.update({str(path):digest(path) for path in (bank_path,node_path,original_path,original_result_path)})
        bank,node,original=load(bank_path),load(node_path),load(original_path)
        reference=read(original_result_path)
        efold=float(bank['efold'][0])
        theta=float(bank['phase'][0])
        frozen=source.frozen(efold)
        if model=='heavy':
            frozen,reconstruction=correlated(frozen,theta)
        state=np.array([efold,frozen['values'][0]/(np.exp(efold)*source.saved.masses[0]),*frozen['values'][1:]])
        state_error=relative_error(state,original['state'])
        rho_error=abs(state[3]/original['state'][3]-1) if model=='heavy' else 0.
        require(state_error<ALGEBRA and rho_error<ALGEBRA,'derived reconstruction preserves original physical initial background')
        system=open_owned(model,'preparation-01/contexts')
        energy=PhysicalEnergyMap(system)
        require(np.array_equal(system.initial_raw,original['initial_raw']) and np.array_equal(system.units,original['units']),'original native preparation and units')
        mean_states,closed_states,checks=[],[],[]
        with MatchedColdFibre(system) as fibre:
            current,maps,point,direct,paths=frozen_source(fibre,energy,state,theta)
            consumed.update(paths)
            physical=to_physical(original['normalized'],maps,energy.size)
            for index,branch in enumerate(BRANCHES):
                closed=apply_correction(physical,maps['inverse_correction'][index],current['layout']['heavy'],current['layout']['size'])
                mean,error=invert_endpoint(closed,node['endpoint'][index],node['keys'],node['remote_stream'],float(node['remote_endpoint']))
                operator=full_endpoint(node['endpoint'][index],node['keys'],node['remote_stream'],float(node['remote_endpoint']),len(mean))
                restored=operator@mean
                output_physical=apply_correction(restored,maps['forward_correction'][index],current['layout']['heavy'],current['layout']['size'])
                encoded=from_physical(output_physical,maps,energy.size)*system.units
                prepared_error=relative_error(encoded,original['original_encoded'])
                readout=system.evaluate(efold,encoded,branch)[1]
                names=('Phi','Psi','D','Q','Pi','theta_c','delta_c','delta_b','delta_gamma','delta_massless')
                values=np.array([readout[name] for name in names])
                observed_error=relative_error(values,np.array(reference['original_values'][branch]['values']))
                require(max(error,prepared_error)<ALGEBRA and observed_error<GATE,'original physical preparation and all-tail inverse')
                mean_states.append(mean);closed_states.append(closed)
                checks.append(dict(branch=branch,full_inverse_relative=error,original_encoded_relative=prepared_error,
                    original_readout_relative=observed_error,initial_readout=values.tolist()))
        target=output/f'{model}-prepared.npz'
        np.savez_compressed(target,mean_state=np.array(mean_states),closed=np.array(closed_states),physical=physical,
            normalized=original['normalized'],initial_raw=original['initial_raw'],units=system.units,state=state,theta=np.array(theta))
        reports.append(dict(model=model,physical_initial_background_relative=state_error,rho_relative=rho_error,
            checks=checks,path=str(target),sha256=digest(target),dimension=len(system.units)))
        print(LABEL,model,'original correlated preparation passed',rho_error,flush=True)
    require(all(digest(path)==seal for path,seal in consumed.items()),'all preparation inputs retained')
    write(output/'result.json',dict(passed=True,inputs=inputs,sources=sources(),consumed=consumed,reports=reports,
        no_new_initial_mode=True,full_G192_endpoint_inverse=True,physical_gates_unchanged=True))


if __name__=='__main__':
    main()

