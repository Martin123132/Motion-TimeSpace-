from common import *
from correlated_source import CorrelatedSource,BRANCHES
from scipy.interpolate import CubicSpline
from scipy.integrate import solve_ivp
import numpy as np
import time


def evolution(bank,initial,coarse,steps,source):
    selection=slice(None,None,2) if coarse else slice(None)
    noncollision=CubicSpline(bank['efold'][selection],bank['noncollision'][selection])
    collision=CubicSpline(bank['efold'][selection],bank['collision'][selection])
    remote=CubicSpline(bank['efold'][selection],bank['remote'][selection])
    rows,columns=bank['keys'].T
    compact=bank['mean'].shape[-1]
    dimension=initial.shape[-1]
    scales=np.linalg.norm(initial,axis=1)
    require(np.min(scales)>0,'original nonzero preparations')
    def rhs(efold,flat):
        guard()
        state=flat.reshape(2,dimension)
        opacity=source.thermal(float(efold))[0]['opacity']['value']
        matrix=noncollision(efold)+opacity*collision(efold)
        result=np.zeros_like(state)
        result[:,:compact]=np.einsum('bij,bj->bi',matrix,state[:,:compact])
        weights=remote(efold)
        for branch in range(2):
            result[branch]+=np.bincount(rows,weights*state[branch,columns],minlength=dimension)
        return result.ravel()
    start,stop=bank['efold'][[0,-1]]
    started=time.monotonic()
    solved=solve_ivp(rhs,(start,stop),(initial/scales[:,None]).ravel(),method='DOP853',
        t_eval=bank['efold'],rtol=2e-12,atol=2e-14,max_step=(stop-start)/steps)
    require(solved.success and np.isfinite(solved.y).all(),'full correlated mean evolution')
    values=solved.y.T.reshape(-1,2,dimension)*scales[None,:,None]
    return values,dict(nfev=solved.nfev,success=bool(solved.success),seconds=time.monotonic()-started,max_step=(stop-start)/steps)


def main():
    modest()
    output=ROOT/'evolution-01'
    output.mkdir(exist_ok=False)
    inputs=verify_inputs()
    required=[ROOT/'source-heldout-01/result.json',ROOT/'preparation-01/result.json']
    require(all(read(path)['passed'] for path in required),'correlated source/preparation controls')
    consumed={str(path):digest(path) for path in required}
    write(output/'freeze.json',dict(inputs=inputs,sources=sources(),consumed=consumed,gate=GATE,algebra=ALGEBRA,
        main_steps=128,coarse_steps=64,rtol=2e-12,atol=2e-14,reference_performance_not_inspected=True))
    reports=[]
    for model in ('heavy','cold'):
        source=CorrelatedSource(model)
        bank_path=ROOT/'source-even-01'/f'{model}-bank.npz'
        initial_path=ROOT/'preparation-01'/f'{model}-prepared.npz'
        bank=load(bank_path)
        initial=load(initial_path)['mean_state']
        consumed.update({str(path):digest(path) for path in (bank_path,initial_path)})
        packets={}
        runs=[]
        for name,coarse,steps in (('source-coarse',True,128),('step-coarse',False,64),('fine',False,128)):
            values,record=evolution(bank,initial,coarse,steps,source)
            path=output/f'{model}-{name}.npz'
            np.savez_compressed(path,efold=bank['efold'],state=values)
            packets[name]=values
            runs.append(dict(name=name,**record,sha256=digest(path)))
            print(LABEL,model,name,'correlated evolution',record['nfev'],flush=True)
        checks=[]
        for control in ('source-coarse','step-coarse'):
            for branch_index,branch in enumerate(BRANCHES):
                difference=np.linalg.norm(packets[control][:,branch_index]-packets['fine'][:,branch_index],axis=1)
                reference=np.linalg.norm(packets['fine'][:,branch_index],axis=1)
                relative=float(np.max(difference)/max(np.max(reference),1e-80))
                require(relative<GATE,'unchanged source/time propagation refinement')
                checks.append(dict(control=control,branch=branch,absolute=float(np.max(difference)),relative=relative))
        reports.append(dict(model=model,runs=runs,checks=checks))
    require(all(digest(path)==seal for path,seal in consumed.items()),'transport sources unchanged')
    write(output/'result.json',dict(passed=True,inputs=inputs,sources=sources(),consumed=consumed,reports=reports,
        full_G192_preserved=True,physical_gates_unchanged=True,reference_performance_not_inspected=True))


if __name__=='__main__':
    main()

