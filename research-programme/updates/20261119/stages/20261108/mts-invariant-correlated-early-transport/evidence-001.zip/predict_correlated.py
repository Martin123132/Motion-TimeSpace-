from common import *
from correlated_source import *
from matching_source import frozen_source,apply_correction,from_physical
from adjoint_operator import open_owned
from physical_energy_map import PhysicalEnergyMap
from matched_cold_fibre import MatchedColdFibre
import numpy as np

NAMES=('Phi','Psi','D','Q','Pi','theta_c','delta_c','delta_b','delta_gamma','delta_massless')


def main():
    modest()
    output=ROOT/'predictions-01'
    output.mkdir(exist_ok=False)
    (output/'contexts').mkdir()
    inputs=verify_inputs()
    evolution_path=ROOT/'evolution-01/result.json'
    require(read(evolution_path)['passed'],'transport qualified before readout')
    consumed={str(evolution_path):digest(evolution_path)}
    reports=[]
    for model in ('heavy','cold'):
        bank_path=ROOT/'source-even-01'/f'{model}-bank.npz'
        evolution_path=ROOT/'evolution-01'/f'{model}-fine.npz'
        consumed.update({str(path):digest(path) for path in (bank_path,evolution_path)})
        bank=load(bank_path)
        evolved=load(evolution_path)
        source=CorrelatedSource(model)
        system=open_owned(model,'predictions-01/contexts')
        energy=PhysicalEnergyMap(system)
        selected=np.arange(0,17,4)
        times=bank['efold'][selected]
        carriers=np.array([system.owner.phase(efold)[0] if model=='heavy' else 0. for efold in times])
        original_background=[]
        for efold in times:
            point=system.context['point'](efold)
            if model=='heavy':
                position=point[10]*source.saved.masses[1]*(system.background['initial_fields'][1]+point[2])
                velocity=point[3]
                original_background.append([np.arctan2(-velocity,position),(position**2+velocity**2)/2,point[12]])
            else:
                original_background.append([0.,0.,point[12]])
        values=np.empty((5,2,len(NAMES)))
        encoded=np.empty((5,2,len(system.units)))
        states=[]
        checks=[]
        with MatchedColdFibre(system) as fibre:
            for output_index,bank_index in enumerate(selected):
                efold=float(times[output_index])
                theta=float(bank['phase'][bank_index])
                frozen=source.frozen(efold)
                if model=='heavy':
                    frozen,reconstruction=correlated(frozen,theta)
                state=np.array([efold,frozen['values'][0]/(np.exp(efold)*source.saved.masses[0]),*frozen['values'][1:]])
                node_path=ROOT/'source-even-01'/f'{model}-{2*bank_index:02d}-mean.npz'
                node=load(node_path)
                consumed[str(node_path)]=digest(node_path)
                fibre.chart_angle=float(carriers[output_index])
                current,maps,point,direct,paths=frozen_source(fibre,energy,state,theta)
                consumed.update(paths)
                thermal_error=max(abs(current['thermal'][name]['value']/frozen['thermal'][name]['value']-1) for name in ('sound','opacity'))
                require(thermal_error<ALGEBRA,'retained thermal table readback')
                for index,branch in enumerate(BRANCHES):
                    mean=evolved['state'][bank_index,index]
                    operator=full_endpoint(node['endpoint'][index],node['keys'],node['remote_stream'],float(node['remote_endpoint']),len(mean))
                    closed=operator@mean
                    physical=apply_correction(closed,maps['forward_correction'][index],current['layout']['heavy'],current['layout']['size'])
                    normalized=from_physical(physical,maps,energy.size)
                    native=normalized*system.units
                    encoded[output_index,index]=native
                    readout=system.evaluate(efold,native,branch)[1]
                    values[output_index,index]=[readout[name] for name in NAMES]
                states.append(state)
                checks.append(dict(index=int(2*bank_index),efold=efold,theta=theta,thermal_relative=thermal_error,
                    native_hubble_shift=fibre.representation_shift,remote_primitive=float(node['remote_endpoint'])))
        path=output/f'{model}-predicted.npz'
        np.savez_compressed(path,efold=times,indices=bank['indices'][selected],values=values,encoded=encoded,state=np.array(states),
            phase=bank['phase'][selected],original_background=np.array(original_background),
            value_names=np.array(NAMES),branches=np.array(BRANCHES))
        reports.append(dict(model=model,path=str(path),sha256=digest(path),checks=checks))
        print(LABEL,model,'correlated physical readouts frozen',flush=True)
    require(all(digest(path)==seal for path,seal in consumed.items()),'readout sources unchanged')
    write(output/'result.json',dict(passed=True,inputs=inputs,sources=sources(),consumed=consumed,reports=reports,
        reference_perturbations_not_inspected=True,physical_gates_unchanged=True,full_periodic_endpoint_used=True))


if __name__=='__main__':
    main()

