from common import *
from correlated_source import *
import numpy as np


def main():
    modest()
    output=ROOT/'source-even-01'
    output.mkdir(parents=True,exist_ok=False)
    inputs=verify_inputs()
    metadata_path=TRANSPORT/LABEL/'source-even-01/freeze.json'
    original=read(metadata_path)
    consumed={str(metadata_path):digest(metadata_path)}
    write(output/'freeze.json',dict(inputs=inputs,sources=sources(),consumed=consumed,metadata=original['metadata'],
        gate=GATE,algebra=ALGEBRA,phase_count=256,physical_outputs=[0,8,16,24,32],
        source_nodes=list(range(0,33,2)),held_out_nodes=list(range(1,32,2)),density_reconstruction='unique invariant fixed point with retained drift remainder',
        source_clock='same saved mean conformal clock; its error remains separate',reference_performance_not_inspected=True))
    reports=[]
    for model in ('heavy','cold'):
        source=CorrelatedSource(model)
        consumed.update(source.consumed)
        efolds=np.array(original['metadata'][model]['efold'])
        phase_coarse,count_coarse=source.phase_history(efolds,128)
        phase,count_fine=source.phase_history(efolds,256)
        error=float(np.max(abs(phase-phase_coarse)))
        require(error<ALGEBRA,'reconstructed phase step refinement')
        np.savez_compressed(output/f'{model}-phase.npz',efold=efolds,phase=phase,coarse=phase_coarse)
        bank={name:[] for name in ('mean','collision','noncollision','remote','endpoint','remote_endpoint','mean_inverse_hubble')}
        rows=[]
        keys=None
        for index in range(0,33,2):
            frozen=source.frozen(float(efolds[index]))
            write(output/f'{model}-{index:02d}-source.json',frozen)
            keep=model=='heavy' and index in (0,8,16,24,32)
            primitive=output/f'{model}-{index:02d}-primitive.npz' if keep else None
            result=full_average(frozen,model,float(phase[index]),primitive)
            require(keys is None or np.array_equal(keys,result['remote_keys']),'original full hierarchy keys')
            keys=result['remote_keys']
            for name in bank:
                bank[name].append(result[name])
            np.savez_compressed(output/f'{model}-{index:02d}-mean.npz',**{name:result[name] for name in bank},
                keys=keys,remote_stream=result['remote_stream'],remote_drift=result['remote_drift'])
            rows.append(dict(index=index,closure=result['closure'],phase_refinement=result['phase_refinement'],
                full_primitive_bound=result['full_primitive_bound'],root_residual=result['root_residual']))
            print(LABEL,model,'correlated even',index,'passed',flush=True)
        np.savez_compressed(output/f'{model}-bank.npz',efold=efolds[::2],phase=phase[::2],
            indices=np.array(original['metadata'][model]['indices'])[::2],keys=keys,**{name:np.array(values) for name,values in bank.items()})
        reports.append(dict(model=model,phase_difference=error,phase_nfev=[count_coarse,count_fine],nodes=rows))
    require(all(digest(path)==seal for path,seal in consumed.items()),'retained sources unchanged')
    write(output/'result.json',dict(passed=True,inputs=inputs,sources=sources(),consumed=consumed,reports=reports,
        no_new_fit=True,full_G192_remote_primitive=True,physical_gates_unchanged=True))


if __name__=='__main__':
    main()

