from common import *
from correlated_source import BRANCHES
import numpy as np


def main():
    modest()
    output=ROOT/'comparison-01'
    output.mkdir(exist_ok=False)
    inputs=verify_inputs()
    path=ROOT/'predictions-01/result.json'
    predictions=read(path)
    require(predictions['passed'] and predictions['reference_perturbations_not_inspected'],'predictions frozen before comparison')
    consumed={str(path):digest(path)}
    metadata=read(ROOT/'source-even-01/freeze.json')['metadata']
    reports=[]
    for item in predictions['reports']:
        model=item['model']
        require(digest(item['path'])==item['sha256'],'frozen correlated outputs')
        consumed[item['path']]=item['sha256']
        candidate=load(item['path'])
        references=[]
        branches=[]
        for branch_index,branch in enumerate(BRANCHES):
            reference=next(row for row in metadata[model]['reference'] if row['branch']==branch)
            require(digest(reference['packet'])==reference['sha256'],'original reference unchanged')
            consumed[reference['packet']]=reference['sha256']
            with np.load(reference['packet']) as packet:
                require(np.array_equal(packet['value_names'],candidate['value_names']),'same physical channels')
                require(np.array_equal(packet['efold'][candidate['indices']],candidate['efold']),'same frozen original probes')
                values=packet['values'][candidate['indices']]
                state=packet['evolved_state'][candidate['indices']]
                units=packet['units']
            difference=candidate['values'][:,branch_index]-values
            observables=[]
            for column,name in enumerate(candidate['value_names']):
                scale=max(float(np.max(abs(values[:,column]))),1e-80)
                absolute=float(np.max(abs(difference[:,column])))
                relative=absolute/scale
                observables.append(dict(name=str(name),absolute=absolute,reference_scale=scale,relative=relative,
                    within_gate=bool(relative<GATE),maximum_probe=int(np.argmax(abs(difference[:,column]))),
                    initial_relative=abs(float(difference[0,column]))/scale,last_relative=abs(float(difference[-1,column]))/scale))
            normalized_difference=(candidate['encoded'][:,branch_index]-state)/units
            normalized=state/units
            state_error=float(np.max(np.linalg.norm(normalized_difference,axis=1))/max(np.max(np.linalg.norm(normalized,axis=1)),1e-80))
            branches.append(dict(branch=branch,observables=observables,normalized_state_relative=state_error,
                physical_pass=all(row['within_gate'] for row in observables)))
            references.append(values)
        original=candidate['original_background']
        phase_error=np.arctan2(np.sin(candidate['phase']-original[:,0]),np.cos(candidate['phase']-original[:,0])) if model=='heavy' else np.zeros(5)
        density_error=candidate['state'][:,3]-original[:,1]
        density_relative=density_error/original[:,1] if model=='heavy' else np.zeros(5)
        np.savez_compressed(output/f'{model}-comparison.npz',efold=candidate['efold'],reference=np.array(references).transpose(1,0,2),
            predicted=candidate['values'],phase_difference=phase_error,rho_difference=density_error,rho_relative=density_relative)
        reports.append(dict(model=model,branches=branches,maximum_phase_difference=float(np.max(abs(phase_error))),
            maximum_density_relative=float(np.max(abs(density_relative))),all_physical_pass=all(row['physical_pass'] for row in branches)))
        print(LABEL,model,'correlated comparison',reports[-1]['all_physical_pass'],
            'maximum relative',[max(row['relative'] for row in branch['observables']) for branch in branches],flush=True)
    require(all(digest(path)==seal for path,seal in consumed.items()),'comparison sources unchanged')
    write(output/'result.json',dict(passed=True,inputs=inputs,sources=sources(),consumed=consumed,reports=reports,
        all_physical_comparisons_pass=all(row['all_physical_pass'] for row in reports),physical_gates_unchanged=True,
        scope='same frozen short early approximation-versus-original test; no new observational fit or late-history assertion'))


if __name__=='__main__':
    main()

