from common import *
import sympy as sp
import mpmath as mp


def main():
    modest()
    output=STAGE/'density-reconstruction-proof'
    output.mkdir(exist_ok=False)
    inputs=verify_inputs()
    external,numerator,rho,omega,theta=sp.symbols('external numerator rho omega theta',positive=True)
    total=external+rho
    fraction=rho/total
    inverse=sp.sqrt(total/3)/omega
    eta=(numerator-rho)/(2*total)
    first=sp.Rational(3,2)*inverse*sp.sin(2*theta)
    coefficient_a=sp.Rational(3,2)*(1-eta)
    coefficient_b=sp.Rational(9,8)*(2-fraction)
    second=-coefficient_a*inverse**2*sp.cos(2*theta)/2-coefficient_b*inverse**2*sp.cos(4*theta)/4
    derivative=sp.Rational(3,4)*fraction*inverse*sp.sin(2*theta)-sp.Rational(9,8)*fraction*inverse**2*sp.cos(2*theta)-sp.Rational(9,32)*fraction*inverse**2*sp.cos(4*theta)
    angular=3*inverse*sp.cos(2*theta)+coefficient_a*inverse**2*sp.sin(2*theta)+coefficient_b*inverse**2*sp.sin(4*theta)
    checks=dict(inverse_rate=sp.simplify(rho*sp.diff(inverse,rho)-fraction*inverse/2),
        fraction_rate=sp.simplify(rho*sp.diff(fraction,rho)-fraction*(1-fraction)),
        eta_rate=sp.simplify(rho*sp.diff(eta,rho)+fraction*(sp.Rational(1,2)+eta)),
        logarithmic_corrector=sp.simplify(rho*sp.diff(first+second,rho)-derivative),
        angular_corrector=sp.simplify(sp.diff(first+second,theta)-angular))
    require(all(value==0 for value in checks.values()),'exact retained invariant reconstruction identities')
    mp.iv.dps=50
    width=mp.iv.mpf('0.02')
    inverse_bound=mp.iv.mpf('0.001')*mp.iv.exp(width/2)
    displacement=mp.iv.mpf('1.5')*inverse_bound+mp.iv.mpf('2.8125')*inverse_bound**2
    contraction=mp.iv.mpf('0.75')*inverse_bound+mp.iv.mpf('1.40625')*inverse_bound**2
    phase_lipschitz=3+(mp.iv.mpf('1.5')+mp.iv.mpf('3.375')*inverse_bound)/(1-contraction)
    require(float(displacement.b)<.02 and float(contraction.b)<1,'uniform positive fixed point box')
    consumed={}
    initial=[]
    for label in ('half','balanced','double'):
        path=MATCHING/label/'preparation-01/heavy-mean-source.json'
        saved=read(path)
        consumed[str(path)]=digest(path)
        value=1/saved['mu']
        require(value<.001,'original mean branch inside theorem condition')
        initial.append(dict(label=label,inverse_frequency=value))
    write(output/'result.json',dict(passed=True,inputs=inputs,sources=sources(),consumed=consumed,
        identities={name:str(value) for name,value in checks.items()},initial=initial,
        log_density_box=.02,inverse_frequency_upper=float(inverse_bound.b),
        corrector_upper=float(displacement.b),contraction_upper=float(contraction.b),
        phase_lipschitz_upper=float(phase_lipschitz.b),invariant_remainder_must_be_retained=True,
        physical_transport_with_reconstruction_tested=False,
        assumptions=['same slow coordinates and external source for invariant-offset sensitivity','positive source components; -2<=eta0<=1','retained mean u is nonincreasing; initial u<0.001'],
        exact_arithmetic_identities=True,outward_interval_bound=True))
    print('density reconstruction identities and contraction passed',float(contraction.b),float(phase_lipschitz.b),flush=True)


if __name__=='__main__':
    main()

