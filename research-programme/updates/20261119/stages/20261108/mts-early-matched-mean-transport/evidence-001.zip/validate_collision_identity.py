from common import *
from early_source import matrices
from split_collision import collision_mean
from coupled_jets import evaluate
from free_math_v2 import build,dense
from copy import deepcopy
from mean_math import relative_error
import numpy as np


def main():
    modest()
    output=STAGE/'collision-identity'
    output.mkdir(exist_ok=False)
    inputs=verify_inputs()
    consumed={}
    reports=[]
    for label in ('half','balanced','double'):
        for model in ('heavy','cold'):
            for index in (0,32):
                path=STAGE/label/'source-even-01'/f'{model}-{index:02d}-source.json'
                frozen=read(path)
                consumed[str(path)]=digest(path)
                wave=dict(read(WAVES)['waves'])[label]
                layout,source,values=frozen['layout'],frozen['source'],frozen['values']
                hubble=((source['density']+(values[0]**2+values[1]**2)/2+values[2])/3)**.5
                minimal={name:source[name] for name in ('fluid','massive','speeds','density','enthalpy','scale')}
                unit=dense(build(layout,minimal,frozen['thermal']['sound']['value'],hubble,frozen['masses'],wave,*values,1.,0.)['groups']['collision'],layout['size'])
                angles=(.239,1.157,2.613) if model=='heavy' else (.239,)
                for angle in angles:
                    original=evaluate(layout,source,frozen['masses'],wave,values,frozen['thermal'],angle)
                    changed=deepcopy(frozen['thermal'])
                    changed['opacity']['value']=0.
                    zero=evaluate(layout,source,frozen['masses'],wave,values,changed,angle)
                    for branch in ('gr','poisson-spatial'):
                        collision=unit.copy()
                        if layout['heavy']:
                            collision[layout['heavy']]+=original['branches'][branch]['inverse']@unit
                        difference=original['branches'][branch]['closed']-zero['branches'][branch]['closed']
                        expected=frozen['thermal']['opacity']['value']/hubble*collision
                        error=relative_error(difference,expected)
                        absolute=float(np.max(abs(difference-expected)))
                        require(error<ALGEBRA and absolute<GATE,'exact retained collision coefficient identity')
                        reports.append(dict(label=label,model=model,index=index,theta=angle,branch=branch,
                            relative=error,absolute=absolute))
    write(output/'result.json',dict(passed=True,inputs=inputs,sources=sources(),consumed=consumed,reports=reports,
        physical_gates_unchanged=True,identity='partial_opacity A=(R C_unit S)/H, C_unit S=C_unit; opacity absent from R,S and their background derivatives'))
    print('closed collision identity passed',len(reports),max(row['absolute'] for row in reports),flush=True)


if __name__=='__main__':
    main()

