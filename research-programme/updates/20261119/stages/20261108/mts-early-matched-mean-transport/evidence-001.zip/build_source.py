from common import *
from early_source import *
import numpy as np


def main():
    modest()
    output=ROOT/'source-even-01'
    output.mkdir(parents=True,exist_ok=False)
    inputs=verify_inputs()
    consumed={}
    metadata={}
    for model in ('heavy','cold'):
        record,paths=original_metadata(model)
        metadata[model]=record
        consumed.update(paths)
    write(output/'freeze.json',dict(inputs=inputs,sources=sources(),consumed=consumed,metadata=metadata,
        physical_gate=GATE,algebra_gate=ALGEBRA,span_target=.01,physical_outputs=[0,8,16,24,32],
        source_nodes=list(range(0,33,2)),held_out_nodes=list(range(1,32,2)),
        predictions='no perturbation reference values read until source/time controls and predicted outputs are saved'))
    reports=[]
    for model in ('heavy','cold'):
        source=EarlySource(model)
        consumed.update(source.consumed)
        efolds=np.array(metadata[model]['efold'])
        span=efolds[-1]-efolds[0]
        phase_coarse,count_coarse=source.phases(efolds,span/128)
        phases,count_fine=source.phases(efolds,span/256)
        phase_difference=float(np.max(abs(phase_coarse-phases)))
        require(phase_difference<ALGEBRA,'phase integration refinement')
        np.savez_compressed(output/f'{model}-phase.npz',efold=efolds,phase=phases,coarse=phase_coarse)
        means,remotes,endpoints,rows=[],[],[],[]
        keys=None
        for index in range(0,33,2):
            frozen=source.frozen(float(efolds[index]))
            write(output/f'{model}-{index:02d}-source.json',frozen)
            keep=index in (0,8,16,24,32)
            primitive=output/f'{model}-{index:02d}-primitive.npz' if model=='heavy' and keep else None
            result=source_mean(frozen,model,float(phases[index]),primitive)
            require(keys is None or np.array_equal(keys,result['keys']),'fixed original sparse tail support')
            keys=result['keys']
            means.append(result['mean']);remotes.append(result['remote']);endpoints.append(result['endpoint'])
            rows.append(dict(index=index,closure=result['closure'],phase_refinement=result['phase_refinement'],primitive_bound=result['primitive_bound']))
            np.savez_compressed(output/f'{model}-{index:02d}-mean.npz',mean=result['mean'],remote=result['remote'],keys=keys,endpoint=result['endpoint'])
            print(LABEL,model,'even source',index,'passed',flush=True)
        np.savez_compressed(output/f'{model}-bank.npz',efold=efolds[::2],mean=np.array(means),remote=np.array(remotes),keys=keys,
            endpoint=np.array(endpoints),phase=phases[::2],indices=np.array(metadata[model]['indices'])[::2])
        reports.append(dict(model=model,phase_difference=phase_difference,phase_nfev=[count_coarse,count_fine],nodes=rows))
    require(all(digest(path)==seal for path,seal in consumed.items()),'retained inputs unchanged')
    write(output/'result.json',dict(passed=True,inputs=inputs,sources=sources(),consumed=consumed,reports=reports,
        perturbation_reference_performance_inspected=False,source_history_generated=True))


if __name__=='__main__':
    main()

